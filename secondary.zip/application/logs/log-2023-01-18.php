<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2023-01-18 03:39:15 --> Config Class Initialized
<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2023-01-18 03:39:15 --> Config Class Initialized
INFO - 2023-01-18 03:39:15 --> Hooks Class Initialized
INFO - 2023-01-18 03:39:15 --> Hooks Class Initialized
DEBUG - 2023-01-18 03:39:15 --> UTF-8 Support Enabled
DEBUG - 2023-01-18 03:39:15 --> UTF-8 Support Enabled
INFO - 2023-01-18 03:39:15 --> Utf8 Class Initialized
INFO - 2023-01-18 03:39:15 --> Utf8 Class Initialized
INFO - 2023-01-18 03:39:15 --> URI Class Initialized
INFO - 2023-01-18 03:39:15 --> URI Class Initialized
DEBUG - 2023-01-18 03:39:15 --> No URI present. Default controller set.
DEBUG - 2023-01-18 03:39:15 --> No URI present. Default controller set.
INFO - 2023-01-18 03:39:15 --> Router Class Initialized
INFO - 2023-01-18 03:39:15 --> Router Class Initialized
INFO - 2023-01-18 03:39:15 --> Output Class Initialized
INFO - 2023-01-18 03:39:15 --> Output Class Initialized
INFO - 2023-01-18 03:39:15 --> Security Class Initialized
INFO - 2023-01-18 03:39:15 --> Security Class Initialized
DEBUG - 2023-01-18 03:39:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-18 03:39:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-18 03:39:15 --> Input Class Initialized
INFO - 2023-01-18 03:39:15 --> Input Class Initialized
INFO - 2023-01-18 03:39:15 --> Language Class Initialized
INFO - 2023-01-18 03:39:15 --> Language Class Initialized
INFO - 2023-01-18 03:39:15 --> Language Class Initialized
INFO - 2023-01-18 03:39:15 --> Language Class Initialized
INFO - 2023-01-18 03:39:15 --> Config Class Initialized
INFO - 2023-01-18 03:39:15 --> Config Class Initialized
INFO - 2023-01-18 03:39:15 --> Loader Class Initialized
INFO - 2023-01-18 03:39:15 --> Loader Class Initialized
INFO - 2023-01-18 03:39:15 --> Helper loaded: url_helper
INFO - 2023-01-18 03:39:15 --> Helper loaded: url_helper
INFO - 2023-01-18 03:39:15 --> Helper loaded: file_helper
INFO - 2023-01-18 03:39:15 --> Helper loaded: file_helper
INFO - 2023-01-18 03:39:15 --> Helper loaded: form_helper
INFO - 2023-01-18 03:39:15 --> Helper loaded: form_helper
INFO - 2023-01-18 03:39:15 --> Helper loaded: my_helper
INFO - 2023-01-18 03:39:15 --> Helper loaded: my_helper
INFO - 2023-01-18 03:39:15 --> Database Driver Class Initialized
INFO - 2023-01-18 03:39:15 --> Database Driver Class Initialized
DEBUG - 2023-01-18 03:39:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-18 03:39:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-01-18 03:39:15 --> Session: Class initialized using 'files' driver.
INFO - 2023-01-18 03:39:15 --> Session: Class initialized using 'files' driver.
INFO - 2023-01-18 03:39:15 --> Controller Class Initialized
INFO - 2023-01-18 03:39:15 --> Controller Class Initialized
INFO - 2023-01-18 03:39:15 --> Config Class Initialized
INFO - 2023-01-18 03:39:15 --> Hooks Class Initialized
DEBUG - 2023-01-18 03:39:15 --> UTF-8 Support Enabled
INFO - 2023-01-18 03:39:15 --> Utf8 Class Initialized
INFO - 2023-01-18 03:39:15 --> URI Class Initialized
INFO - 2023-01-18 03:39:15 --> Router Class Initialized
INFO - 2023-01-18 03:39:15 --> Output Class Initialized
INFO - 2023-01-18 03:39:15 --> Security Class Initialized
DEBUG - 2023-01-18 03:39:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-18 03:39:15 --> Input Class Initialized
INFO - 2023-01-18 03:39:15 --> Language Class Initialized
INFO - 2023-01-18 03:39:15 --> Language Class Initialized
INFO - 2023-01-18 03:39:15 --> Config Class Initialized
INFO - 2023-01-18 03:39:15 --> Loader Class Initialized
INFO - 2023-01-18 03:39:15 --> Helper loaded: url_helper
INFO - 2023-01-18 03:39:15 --> Helper loaded: file_helper
INFO - 2023-01-18 03:39:15 --> Helper loaded: form_helper
INFO - 2023-01-18 03:39:15 --> Helper loaded: my_helper
INFO - 2023-01-18 03:39:15 --> Database Driver Class Initialized
DEBUG - 2023-01-18 03:39:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-01-18 03:39:15 --> Session: Class initialized using 'files' driver.
INFO - 2023-01-18 03:39:15 --> Controller Class Initialized
DEBUG - 2023-01-18 03:39:15 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/login/views/login.php
DEBUG - 2023-01-18 03:39:15 --> File loaded: C:\xampp\htdocs\myraportk13\application\views\template_utama.php
INFO - 2023-01-18 03:39:15 --> Final output sent to browser
DEBUG - 2023-01-18 03:39:15 --> Total execution time: 0.0751
INFO - 2023-01-18 03:41:16 --> Config Class Initialized
INFO - 2023-01-18 03:41:16 --> Hooks Class Initialized
DEBUG - 2023-01-18 03:41:16 --> UTF-8 Support Enabled
INFO - 2023-01-18 03:41:16 --> Utf8 Class Initialized
INFO - 2023-01-18 03:41:16 --> URI Class Initialized
INFO - 2023-01-18 03:41:16 --> Router Class Initialized
INFO - 2023-01-18 03:41:16 --> Output Class Initialized
INFO - 2023-01-18 03:41:16 --> Security Class Initialized
DEBUG - 2023-01-18 03:41:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-18 03:41:16 --> Input Class Initialized
INFO - 2023-01-18 03:41:16 --> Language Class Initialized
INFO - 2023-01-18 03:41:16 --> Language Class Initialized
INFO - 2023-01-18 03:41:16 --> Config Class Initialized
INFO - 2023-01-18 03:41:16 --> Loader Class Initialized
INFO - 2023-01-18 03:41:16 --> Helper loaded: url_helper
INFO - 2023-01-18 03:41:16 --> Helper loaded: file_helper
INFO - 2023-01-18 03:41:16 --> Helper loaded: form_helper
INFO - 2023-01-18 03:41:16 --> Helper loaded: my_helper
INFO - 2023-01-18 03:41:16 --> Database Driver Class Initialized
DEBUG - 2023-01-18 03:41:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-01-18 03:41:16 --> Session: Class initialized using 'files' driver.
INFO - 2023-01-18 03:41:16 --> Controller Class Initialized
INFO - 2023-01-18 03:41:16 --> Helper loaded: cookie_helper
INFO - 2023-01-18 03:41:16 --> Final output sent to browser
DEBUG - 2023-01-18 03:41:16 --> Total execution time: 0.1344
INFO - 2023-01-18 03:41:16 --> Config Class Initialized
INFO - 2023-01-18 03:41:16 --> Hooks Class Initialized
DEBUG - 2023-01-18 03:41:16 --> UTF-8 Support Enabled
INFO - 2023-01-18 03:41:16 --> Utf8 Class Initialized
INFO - 2023-01-18 03:41:16 --> URI Class Initialized
INFO - 2023-01-18 03:41:16 --> Router Class Initialized
INFO - 2023-01-18 03:41:16 --> Output Class Initialized
INFO - 2023-01-18 03:41:16 --> Security Class Initialized
DEBUG - 2023-01-18 03:41:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-18 03:41:16 --> Input Class Initialized
INFO - 2023-01-18 03:41:16 --> Language Class Initialized
INFO - 2023-01-18 03:41:16 --> Language Class Initialized
INFO - 2023-01-18 03:41:16 --> Config Class Initialized
INFO - 2023-01-18 03:41:16 --> Loader Class Initialized
INFO - 2023-01-18 03:41:16 --> Helper loaded: url_helper
INFO - 2023-01-18 03:41:16 --> Helper loaded: file_helper
INFO - 2023-01-18 03:41:16 --> Helper loaded: form_helper
INFO - 2023-01-18 03:41:16 --> Helper loaded: my_helper
INFO - 2023-01-18 03:41:16 --> Database Driver Class Initialized
DEBUG - 2023-01-18 03:41:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-01-18 03:41:16 --> Session: Class initialized using 'files' driver.
INFO - 2023-01-18 03:41:16 --> Controller Class Initialized
DEBUG - 2023-01-18 03:41:16 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/home/views/v_home_guru.php
DEBUG - 2023-01-18 03:41:16 --> File loaded: C:\xampp\htdocs\myraportk13\application\views\template_utama.php
INFO - 2023-01-18 03:41:16 --> Final output sent to browser
DEBUG - 2023-01-18 03:41:16 --> Total execution time: 0.1259
INFO - 2023-01-18 03:41:18 --> Config Class Initialized
INFO - 2023-01-18 03:41:18 --> Hooks Class Initialized
DEBUG - 2023-01-18 03:41:18 --> UTF-8 Support Enabled
INFO - 2023-01-18 03:41:18 --> Utf8 Class Initialized
INFO - 2023-01-18 03:41:18 --> URI Class Initialized
INFO - 2023-01-18 03:41:18 --> Router Class Initialized
INFO - 2023-01-18 03:41:18 --> Output Class Initialized
INFO - 2023-01-18 03:41:18 --> Security Class Initialized
DEBUG - 2023-01-18 03:41:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-18 03:41:18 --> Input Class Initialized
INFO - 2023-01-18 03:41:18 --> Language Class Initialized
INFO - 2023-01-18 03:41:18 --> Language Class Initialized
INFO - 2023-01-18 03:41:18 --> Config Class Initialized
INFO - 2023-01-18 03:41:18 --> Loader Class Initialized
INFO - 2023-01-18 03:41:18 --> Helper loaded: url_helper
INFO - 2023-01-18 03:41:18 --> Helper loaded: file_helper
INFO - 2023-01-18 03:41:18 --> Helper loaded: form_helper
INFO - 2023-01-18 03:41:18 --> Helper loaded: my_helper
INFO - 2023-01-18 03:41:18 --> Database Driver Class Initialized
DEBUG - 2023-01-18 03:41:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-01-18 03:41:18 --> Session: Class initialized using 'files' driver.
INFO - 2023-01-18 03:41:18 --> Controller Class Initialized
DEBUG - 2023-01-18 03:41:18 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/view_mapel/views/v_view_mapel.php
DEBUG - 2023-01-18 03:41:18 --> File loaded: C:\xampp\htdocs\myraportk13\application\views\template_utama.php
INFO - 2023-01-18 03:41:18 --> Final output sent to browser
DEBUG - 2023-01-18 03:41:18 --> Total execution time: 0.1150
INFO - 2023-01-18 03:41:57 --> Config Class Initialized
INFO - 2023-01-18 03:41:57 --> Hooks Class Initialized
DEBUG - 2023-01-18 03:41:57 --> UTF-8 Support Enabled
INFO - 2023-01-18 03:41:57 --> Utf8 Class Initialized
INFO - 2023-01-18 03:41:57 --> URI Class Initialized
INFO - 2023-01-18 03:41:57 --> Router Class Initialized
INFO - 2023-01-18 03:41:57 --> Output Class Initialized
INFO - 2023-01-18 03:41:57 --> Security Class Initialized
DEBUG - 2023-01-18 03:41:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-18 03:41:57 --> Input Class Initialized
INFO - 2023-01-18 03:41:57 --> Language Class Initialized
INFO - 2023-01-18 03:41:57 --> Language Class Initialized
INFO - 2023-01-18 03:41:57 --> Config Class Initialized
INFO - 2023-01-18 03:41:57 --> Loader Class Initialized
INFO - 2023-01-18 03:41:57 --> Helper loaded: url_helper
INFO - 2023-01-18 03:41:57 --> Helper loaded: file_helper
INFO - 2023-01-18 03:41:57 --> Helper loaded: form_helper
INFO - 2023-01-18 03:41:57 --> Helper loaded: my_helper
INFO - 2023-01-18 03:41:57 --> Database Driver Class Initialized
DEBUG - 2023-01-18 03:41:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-01-18 03:41:57 --> Session: Class initialized using 'files' driver.
INFO - 2023-01-18 03:41:57 --> Controller Class Initialized
DEBUG - 2023-01-18 03:41:57 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/n_pengetahuan/views/list.php
DEBUG - 2023-01-18 03:41:57 --> File loaded: C:\xampp\htdocs\myraportk13\application\views\template_utama.php
INFO - 2023-01-18 03:41:57 --> Final output sent to browser
DEBUG - 2023-01-18 03:41:57 --> Total execution time: 0.0850
INFO - 2023-01-18 03:41:57 --> Config Class Initialized
INFO - 2023-01-18 03:41:57 --> Hooks Class Initialized
DEBUG - 2023-01-18 03:41:57 --> UTF-8 Support Enabled
INFO - 2023-01-18 03:41:57 --> Utf8 Class Initialized
INFO - 2023-01-18 03:41:57 --> URI Class Initialized
INFO - 2023-01-18 03:41:57 --> Router Class Initialized
INFO - 2023-01-18 03:41:57 --> Output Class Initialized
INFO - 2023-01-18 03:41:57 --> Security Class Initialized
DEBUG - 2023-01-18 03:41:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-18 03:41:57 --> Input Class Initialized
INFO - 2023-01-18 03:41:57 --> Language Class Initialized
INFO - 2023-01-18 03:41:57 --> Language Class Initialized
INFO - 2023-01-18 03:41:57 --> Config Class Initialized
INFO - 2023-01-18 03:41:57 --> Loader Class Initialized
INFO - 2023-01-18 03:41:57 --> Helper loaded: url_helper
INFO - 2023-01-18 03:41:57 --> Helper loaded: file_helper
INFO - 2023-01-18 03:41:57 --> Helper loaded: form_helper
INFO - 2023-01-18 03:41:57 --> Helper loaded: my_helper
INFO - 2023-01-18 03:41:57 --> Database Driver Class Initialized
DEBUG - 2023-01-18 03:41:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-01-18 03:41:57 --> Session: Class initialized using 'files' driver.
INFO - 2023-01-18 03:41:57 --> Controller Class Initialized
INFO - 2023-01-18 03:42:01 --> Config Class Initialized
INFO - 2023-01-18 03:42:01 --> Hooks Class Initialized
DEBUG - 2023-01-18 03:42:01 --> UTF-8 Support Enabled
INFO - 2023-01-18 03:42:01 --> Utf8 Class Initialized
INFO - 2023-01-18 03:42:01 --> URI Class Initialized
INFO - 2023-01-18 03:42:01 --> Router Class Initialized
INFO - 2023-01-18 03:42:01 --> Output Class Initialized
INFO - 2023-01-18 03:42:01 --> Security Class Initialized
DEBUG - 2023-01-18 03:42:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-18 03:42:01 --> Input Class Initialized
INFO - 2023-01-18 03:42:01 --> Language Class Initialized
INFO - 2023-01-18 03:42:01 --> Language Class Initialized
INFO - 2023-01-18 03:42:01 --> Config Class Initialized
INFO - 2023-01-18 03:42:01 --> Loader Class Initialized
INFO - 2023-01-18 03:42:01 --> Helper loaded: url_helper
INFO - 2023-01-18 03:42:01 --> Helper loaded: file_helper
INFO - 2023-01-18 03:42:01 --> Helper loaded: form_helper
INFO - 2023-01-18 03:42:01 --> Helper loaded: my_helper
INFO - 2023-01-18 03:42:01 --> Database Driver Class Initialized
DEBUG - 2023-01-18 03:42:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-01-18 03:42:01 --> Session: Class initialized using 'files' driver.
INFO - 2023-01-18 03:42:01 --> Controller Class Initialized
DEBUG - 2023-01-18 03:42:01 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/view_mapel/views/v_view_mapel.php
DEBUG - 2023-01-18 03:42:01 --> File loaded: C:\xampp\htdocs\myraportk13\application\views\template_utama.php
INFO - 2023-01-18 03:42:01 --> Final output sent to browser
DEBUG - 2023-01-18 03:42:01 --> Total execution time: 0.0442
INFO - 2023-01-18 03:42:07 --> Config Class Initialized
INFO - 2023-01-18 03:42:07 --> Hooks Class Initialized
DEBUG - 2023-01-18 03:42:07 --> UTF-8 Support Enabled
INFO - 2023-01-18 03:42:07 --> Utf8 Class Initialized
INFO - 2023-01-18 03:42:07 --> URI Class Initialized
INFO - 2023-01-18 03:42:07 --> Router Class Initialized
INFO - 2023-01-18 03:42:07 --> Output Class Initialized
INFO - 2023-01-18 03:42:07 --> Security Class Initialized
DEBUG - 2023-01-18 03:42:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-18 03:42:07 --> Input Class Initialized
INFO - 2023-01-18 03:42:07 --> Language Class Initialized
INFO - 2023-01-18 03:42:07 --> Language Class Initialized
INFO - 2023-01-18 03:42:07 --> Config Class Initialized
INFO - 2023-01-18 03:42:07 --> Loader Class Initialized
INFO - 2023-01-18 03:42:07 --> Helper loaded: url_helper
INFO - 2023-01-18 03:42:07 --> Helper loaded: file_helper
INFO - 2023-01-18 03:42:07 --> Helper loaded: form_helper
INFO - 2023-01-18 03:42:07 --> Helper loaded: my_helper
INFO - 2023-01-18 03:42:07 --> Database Driver Class Initialized
DEBUG - 2023-01-18 03:42:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-01-18 03:42:07 --> Session: Class initialized using 'files' driver.
INFO - 2023-01-18 03:42:07 --> Controller Class Initialized
DEBUG - 2023-01-18 03:42:07 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/n_pengetahuan/views/list.php
DEBUG - 2023-01-18 03:42:07 --> File loaded: C:\xampp\htdocs\myraportk13\application\views\template_utama.php
INFO - 2023-01-18 03:42:07 --> Final output sent to browser
DEBUG - 2023-01-18 03:42:07 --> Total execution time: 0.0328
INFO - 2023-01-18 03:42:07 --> Config Class Initialized
INFO - 2023-01-18 03:42:07 --> Hooks Class Initialized
DEBUG - 2023-01-18 03:42:07 --> UTF-8 Support Enabled
INFO - 2023-01-18 03:42:07 --> Utf8 Class Initialized
INFO - 2023-01-18 03:42:07 --> URI Class Initialized
INFO - 2023-01-18 03:42:07 --> Router Class Initialized
INFO - 2023-01-18 03:42:07 --> Output Class Initialized
INFO - 2023-01-18 03:42:07 --> Security Class Initialized
DEBUG - 2023-01-18 03:42:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-18 03:42:08 --> Input Class Initialized
INFO - 2023-01-18 03:42:08 --> Language Class Initialized
INFO - 2023-01-18 03:42:08 --> Language Class Initialized
INFO - 2023-01-18 03:42:08 --> Config Class Initialized
INFO - 2023-01-18 03:42:08 --> Loader Class Initialized
INFO - 2023-01-18 03:42:08 --> Helper loaded: url_helper
INFO - 2023-01-18 03:42:08 --> Helper loaded: file_helper
INFO - 2023-01-18 03:42:08 --> Helper loaded: form_helper
INFO - 2023-01-18 03:42:08 --> Helper loaded: my_helper
INFO - 2023-01-18 03:42:08 --> Database Driver Class Initialized
DEBUG - 2023-01-18 03:42:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-01-18 03:42:08 --> Session: Class initialized using 'files' driver.
INFO - 2023-01-18 03:42:08 --> Controller Class Initialized
INFO - 2023-01-18 03:43:39 --> Config Class Initialized
INFO - 2023-01-18 03:43:39 --> Hooks Class Initialized
DEBUG - 2023-01-18 03:43:39 --> UTF-8 Support Enabled
INFO - 2023-01-18 03:43:39 --> Utf8 Class Initialized
INFO - 2023-01-18 03:43:39 --> URI Class Initialized
INFO - 2023-01-18 03:43:39 --> Router Class Initialized
INFO - 2023-01-18 03:43:39 --> Output Class Initialized
INFO - 2023-01-18 03:43:39 --> Security Class Initialized
DEBUG - 2023-01-18 03:43:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-18 03:43:39 --> Input Class Initialized
INFO - 2023-01-18 03:43:39 --> Language Class Initialized
INFO - 2023-01-18 03:43:39 --> Language Class Initialized
INFO - 2023-01-18 03:43:39 --> Config Class Initialized
INFO - 2023-01-18 03:43:39 --> Loader Class Initialized
INFO - 2023-01-18 03:43:39 --> Helper loaded: url_helper
INFO - 2023-01-18 03:43:39 --> Helper loaded: file_helper
INFO - 2023-01-18 03:43:39 --> Helper loaded: form_helper
INFO - 2023-01-18 03:43:39 --> Helper loaded: my_helper
INFO - 2023-01-18 03:43:39 --> Database Driver Class Initialized
DEBUG - 2023-01-18 03:43:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-01-18 03:43:39 --> Session: Class initialized using 'files' driver.
INFO - 2023-01-18 03:43:39 --> Controller Class Initialized
INFO - 2023-01-18 03:43:39 --> Final output sent to browser
DEBUG - 2023-01-18 03:43:39 --> Total execution time: 0.0519
INFO - 2023-01-18 03:43:41 --> Config Class Initialized
INFO - 2023-01-18 03:43:41 --> Hooks Class Initialized
DEBUG - 2023-01-18 03:43:41 --> UTF-8 Support Enabled
INFO - 2023-01-18 03:43:41 --> Utf8 Class Initialized
INFO - 2023-01-18 03:43:41 --> URI Class Initialized
INFO - 2023-01-18 03:43:41 --> Router Class Initialized
INFO - 2023-01-18 03:43:41 --> Output Class Initialized
INFO - 2023-01-18 03:43:41 --> Security Class Initialized
DEBUG - 2023-01-18 03:43:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-18 03:43:41 --> Input Class Initialized
INFO - 2023-01-18 03:43:41 --> Language Class Initialized
INFO - 2023-01-18 03:43:41 --> Language Class Initialized
INFO - 2023-01-18 03:43:41 --> Config Class Initialized
INFO - 2023-01-18 03:43:41 --> Loader Class Initialized
INFO - 2023-01-18 03:43:41 --> Helper loaded: url_helper
INFO - 2023-01-18 03:43:41 --> Helper loaded: file_helper
INFO - 2023-01-18 03:43:41 --> Helper loaded: form_helper
INFO - 2023-01-18 03:43:41 --> Helper loaded: my_helper
INFO - 2023-01-18 03:43:41 --> Database Driver Class Initialized
DEBUG - 2023-01-18 03:43:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-01-18 03:43:41 --> Session: Class initialized using 'files' driver.
INFO - 2023-01-18 03:43:41 --> Controller Class Initialized
INFO - 2023-01-18 03:43:41 --> Final output sent to browser
DEBUG - 2023-01-18 03:43:41 --> Total execution time: 0.0337
INFO - 2023-01-18 03:43:42 --> Config Class Initialized
INFO - 2023-01-18 03:43:42 --> Hooks Class Initialized
DEBUG - 2023-01-18 03:43:42 --> UTF-8 Support Enabled
INFO - 2023-01-18 03:43:42 --> Utf8 Class Initialized
INFO - 2023-01-18 03:43:42 --> URI Class Initialized
INFO - 2023-01-18 03:43:42 --> Router Class Initialized
INFO - 2023-01-18 03:43:42 --> Output Class Initialized
INFO - 2023-01-18 03:43:42 --> Security Class Initialized
DEBUG - 2023-01-18 03:43:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-18 03:43:42 --> Input Class Initialized
INFO - 2023-01-18 03:43:42 --> Language Class Initialized
INFO - 2023-01-18 03:43:42 --> Language Class Initialized
INFO - 2023-01-18 03:43:42 --> Config Class Initialized
INFO - 2023-01-18 03:43:42 --> Loader Class Initialized
INFO - 2023-01-18 03:43:42 --> Helper loaded: url_helper
INFO - 2023-01-18 03:43:42 --> Helper loaded: file_helper
INFO - 2023-01-18 03:43:42 --> Helper loaded: form_helper
INFO - 2023-01-18 03:43:42 --> Helper loaded: my_helper
INFO - 2023-01-18 03:43:42 --> Database Driver Class Initialized
DEBUG - 2023-01-18 03:43:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-01-18 03:43:42 --> Session: Class initialized using 'files' driver.
INFO - 2023-01-18 03:43:42 --> Controller Class Initialized
INFO - 2023-01-18 03:43:42 --> Final output sent to browser
DEBUG - 2023-01-18 03:43:42 --> Total execution time: 0.0452
INFO - 2023-01-18 03:43:42 --> Config Class Initialized
INFO - 2023-01-18 03:43:42 --> Hooks Class Initialized
DEBUG - 2023-01-18 03:43:42 --> UTF-8 Support Enabled
INFO - 2023-01-18 03:43:42 --> Utf8 Class Initialized
INFO - 2023-01-18 03:43:42 --> URI Class Initialized
INFO - 2023-01-18 03:43:42 --> Router Class Initialized
INFO - 2023-01-18 03:43:42 --> Output Class Initialized
INFO - 2023-01-18 03:43:42 --> Security Class Initialized
DEBUG - 2023-01-18 03:43:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-18 03:43:42 --> Input Class Initialized
INFO - 2023-01-18 03:43:42 --> Language Class Initialized
INFO - 2023-01-18 03:43:42 --> Language Class Initialized
INFO - 2023-01-18 03:43:42 --> Config Class Initialized
INFO - 2023-01-18 03:43:42 --> Loader Class Initialized
INFO - 2023-01-18 03:43:42 --> Helper loaded: url_helper
INFO - 2023-01-18 03:43:42 --> Helper loaded: file_helper
INFO - 2023-01-18 03:43:42 --> Helper loaded: form_helper
INFO - 2023-01-18 03:43:42 --> Helper loaded: my_helper
INFO - 2023-01-18 03:43:42 --> Database Driver Class Initialized
DEBUG - 2023-01-18 03:43:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-01-18 03:43:42 --> Session: Class initialized using 'files' driver.
INFO - 2023-01-18 03:43:42 --> Controller Class Initialized
INFO - 2023-01-18 03:43:42 --> Final output sent to browser
DEBUG - 2023-01-18 03:43:42 --> Total execution time: 0.0538
INFO - 2023-01-18 03:43:43 --> Config Class Initialized
INFO - 2023-01-18 03:43:43 --> Hooks Class Initialized
DEBUG - 2023-01-18 03:43:43 --> UTF-8 Support Enabled
INFO - 2023-01-18 03:43:43 --> Utf8 Class Initialized
INFO - 2023-01-18 03:43:43 --> URI Class Initialized
INFO - 2023-01-18 03:43:43 --> Router Class Initialized
INFO - 2023-01-18 03:43:43 --> Output Class Initialized
INFO - 2023-01-18 03:43:43 --> Security Class Initialized
DEBUG - 2023-01-18 03:43:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-18 03:43:43 --> Input Class Initialized
INFO - 2023-01-18 03:43:43 --> Language Class Initialized
INFO - 2023-01-18 03:43:43 --> Language Class Initialized
INFO - 2023-01-18 03:43:43 --> Config Class Initialized
INFO - 2023-01-18 03:43:43 --> Loader Class Initialized
INFO - 2023-01-18 03:43:43 --> Helper loaded: url_helper
INFO - 2023-01-18 03:43:43 --> Helper loaded: file_helper
INFO - 2023-01-18 03:43:43 --> Helper loaded: form_helper
INFO - 2023-01-18 03:43:43 --> Helper loaded: my_helper
INFO - 2023-01-18 03:43:43 --> Database Driver Class Initialized
DEBUG - 2023-01-18 03:43:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-01-18 03:43:43 --> Session: Class initialized using 'files' driver.
INFO - 2023-01-18 03:43:43 --> Controller Class Initialized
INFO - 2023-01-18 03:43:43 --> Final output sent to browser
DEBUG - 2023-01-18 03:43:43 --> Total execution time: 0.0477
INFO - 2023-01-18 03:43:49 --> Config Class Initialized
INFO - 2023-01-18 03:43:49 --> Hooks Class Initialized
DEBUG - 2023-01-18 03:43:49 --> UTF-8 Support Enabled
INFO - 2023-01-18 03:43:49 --> Utf8 Class Initialized
INFO - 2023-01-18 03:43:49 --> URI Class Initialized
INFO - 2023-01-18 03:43:49 --> Router Class Initialized
INFO - 2023-01-18 03:43:49 --> Output Class Initialized
INFO - 2023-01-18 03:43:49 --> Security Class Initialized
DEBUG - 2023-01-18 03:43:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-18 03:43:49 --> Input Class Initialized
INFO - 2023-01-18 03:43:49 --> Language Class Initialized
INFO - 2023-01-18 03:43:49 --> Language Class Initialized
INFO - 2023-01-18 03:43:49 --> Config Class Initialized
INFO - 2023-01-18 03:43:49 --> Loader Class Initialized
INFO - 2023-01-18 03:43:49 --> Helper loaded: url_helper
INFO - 2023-01-18 03:43:49 --> Helper loaded: file_helper
INFO - 2023-01-18 03:43:49 --> Helper loaded: form_helper
INFO - 2023-01-18 03:43:49 --> Helper loaded: my_helper
INFO - 2023-01-18 03:43:49 --> Database Driver Class Initialized
DEBUG - 2023-01-18 03:43:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-01-18 03:43:49 --> Session: Class initialized using 'files' driver.
INFO - 2023-01-18 03:43:49 --> Controller Class Initialized
INFO - 2023-01-18 03:43:49 --> Final output sent to browser
DEBUG - 2023-01-18 03:43:49 --> Total execution time: 0.0309
INFO - 2023-01-18 03:44:33 --> Config Class Initialized
INFO - 2023-01-18 03:44:33 --> Hooks Class Initialized
DEBUG - 2023-01-18 03:44:33 --> UTF-8 Support Enabled
INFO - 2023-01-18 03:44:33 --> Utf8 Class Initialized
INFO - 2023-01-18 03:44:33 --> URI Class Initialized
INFO - 2023-01-18 03:44:33 --> Router Class Initialized
INFO - 2023-01-18 03:44:33 --> Output Class Initialized
INFO - 2023-01-18 03:44:33 --> Security Class Initialized
DEBUG - 2023-01-18 03:44:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-18 03:44:33 --> Input Class Initialized
INFO - 2023-01-18 03:44:33 --> Language Class Initialized
INFO - 2023-01-18 03:44:33 --> Language Class Initialized
INFO - 2023-01-18 03:44:33 --> Config Class Initialized
INFO - 2023-01-18 03:44:33 --> Loader Class Initialized
INFO - 2023-01-18 03:44:33 --> Helper loaded: url_helper
INFO - 2023-01-18 03:44:33 --> Helper loaded: file_helper
INFO - 2023-01-18 03:44:33 --> Helper loaded: form_helper
INFO - 2023-01-18 03:44:33 --> Helper loaded: my_helper
INFO - 2023-01-18 03:44:33 --> Database Driver Class Initialized
DEBUG - 2023-01-18 03:44:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-01-18 03:44:33 --> Session: Class initialized using 'files' driver.
INFO - 2023-01-18 03:44:33 --> Controller Class Initialized
INFO - 2023-01-18 03:44:33 --> Final output sent to browser
DEBUG - 2023-01-18 03:44:33 --> Total execution time: 0.0485
INFO - 2023-01-18 03:45:19 --> Config Class Initialized
INFO - 2023-01-18 03:45:19 --> Hooks Class Initialized
DEBUG - 2023-01-18 03:45:19 --> UTF-8 Support Enabled
INFO - 2023-01-18 03:45:19 --> Utf8 Class Initialized
INFO - 2023-01-18 03:45:19 --> URI Class Initialized
INFO - 2023-01-18 03:45:19 --> Router Class Initialized
INFO - 2023-01-18 03:45:19 --> Output Class Initialized
INFO - 2023-01-18 03:45:19 --> Security Class Initialized
DEBUG - 2023-01-18 03:45:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-18 03:45:19 --> Input Class Initialized
INFO - 2023-01-18 03:45:19 --> Language Class Initialized
INFO - 2023-01-18 03:45:19 --> Language Class Initialized
INFO - 2023-01-18 03:45:19 --> Config Class Initialized
INFO - 2023-01-18 03:45:19 --> Loader Class Initialized
INFO - 2023-01-18 03:45:19 --> Helper loaded: url_helper
INFO - 2023-01-18 03:45:19 --> Helper loaded: file_helper
INFO - 2023-01-18 03:45:19 --> Helper loaded: form_helper
INFO - 2023-01-18 03:45:19 --> Helper loaded: my_helper
INFO - 2023-01-18 03:45:19 --> Database Driver Class Initialized
DEBUG - 2023-01-18 03:45:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-01-18 03:45:19 --> Session: Class initialized using 'files' driver.
INFO - 2023-01-18 03:45:19 --> Controller Class Initialized
INFO - 2023-01-18 03:46:15 --> Config Class Initialized
INFO - 2023-01-18 03:46:15 --> Hooks Class Initialized
DEBUG - 2023-01-18 03:46:15 --> UTF-8 Support Enabled
INFO - 2023-01-18 03:46:15 --> Utf8 Class Initialized
INFO - 2023-01-18 03:46:15 --> URI Class Initialized
INFO - 2023-01-18 03:46:15 --> Router Class Initialized
INFO - 2023-01-18 03:46:15 --> Output Class Initialized
INFO - 2023-01-18 03:46:15 --> Security Class Initialized
DEBUG - 2023-01-18 03:46:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-18 03:46:15 --> Input Class Initialized
INFO - 2023-01-18 03:46:15 --> Language Class Initialized
INFO - 2023-01-18 03:46:15 --> Language Class Initialized
INFO - 2023-01-18 03:46:15 --> Config Class Initialized
INFO - 2023-01-18 03:46:15 --> Loader Class Initialized
INFO - 2023-01-18 03:46:15 --> Helper loaded: url_helper
INFO - 2023-01-18 03:46:15 --> Helper loaded: file_helper
INFO - 2023-01-18 03:46:16 --> Helper loaded: form_helper
INFO - 2023-01-18 03:46:16 --> Helper loaded: my_helper
INFO - 2023-01-18 03:46:16 --> Database Driver Class Initialized
DEBUG - 2023-01-18 03:46:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-01-18 03:46:16 --> Session: Class initialized using 'files' driver.
INFO - 2023-01-18 03:46:16 --> Controller Class Initialized
DEBUG - 2023-01-18 03:46:16 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/n_pengetahuan/views/form.php
DEBUG - 2023-01-18 03:46:16 --> File loaded: C:\xampp\htdocs\myraportk13\application\views\template_utama.php
INFO - 2023-01-18 03:46:16 --> Final output sent to browser
DEBUG - 2023-01-18 03:46:16 --> Total execution time: 0.0561
INFO - 2023-01-18 03:46:22 --> Config Class Initialized
INFO - 2023-01-18 03:46:22 --> Hooks Class Initialized
DEBUG - 2023-01-18 03:46:22 --> UTF-8 Support Enabled
INFO - 2023-01-18 03:46:22 --> Utf8 Class Initialized
INFO - 2023-01-18 03:46:22 --> URI Class Initialized
INFO - 2023-01-18 03:46:22 --> Router Class Initialized
INFO - 2023-01-18 03:46:22 --> Output Class Initialized
INFO - 2023-01-18 03:46:22 --> Security Class Initialized
DEBUG - 2023-01-18 03:46:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-18 03:46:22 --> Input Class Initialized
INFO - 2023-01-18 03:46:22 --> Language Class Initialized
INFO - 2023-01-18 03:46:22 --> Language Class Initialized
INFO - 2023-01-18 03:46:22 --> Config Class Initialized
INFO - 2023-01-18 03:46:22 --> Loader Class Initialized
INFO - 2023-01-18 03:46:22 --> Helper loaded: url_helper
INFO - 2023-01-18 03:46:22 --> Helper loaded: file_helper
INFO - 2023-01-18 03:46:22 --> Helper loaded: form_helper
INFO - 2023-01-18 03:46:22 --> Helper loaded: my_helper
INFO - 2023-01-18 03:46:22 --> Database Driver Class Initialized
DEBUG - 2023-01-18 03:46:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-01-18 03:46:22 --> Session: Class initialized using 'files' driver.
INFO - 2023-01-18 03:46:22 --> Controller Class Initialized
INFO - 2023-01-18 03:46:22 --> Config Class Initialized
INFO - 2023-01-18 03:46:22 --> Hooks Class Initialized
DEBUG - 2023-01-18 03:46:22 --> UTF-8 Support Enabled
INFO - 2023-01-18 03:46:22 --> Utf8 Class Initialized
INFO - 2023-01-18 03:46:22 --> URI Class Initialized
INFO - 2023-01-18 03:46:22 --> Router Class Initialized
INFO - 2023-01-18 03:46:22 --> Output Class Initialized
INFO - 2023-01-18 03:46:22 --> Security Class Initialized
DEBUG - 2023-01-18 03:46:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-18 03:46:22 --> Input Class Initialized
INFO - 2023-01-18 03:46:22 --> Language Class Initialized
INFO - 2023-01-18 03:46:22 --> Language Class Initialized
INFO - 2023-01-18 03:46:22 --> Config Class Initialized
INFO - 2023-01-18 03:46:22 --> Loader Class Initialized
INFO - 2023-01-18 03:46:22 --> Helper loaded: url_helper
INFO - 2023-01-18 03:46:22 --> Helper loaded: file_helper
INFO - 2023-01-18 03:46:22 --> Helper loaded: form_helper
INFO - 2023-01-18 03:46:22 --> Helper loaded: my_helper
INFO - 2023-01-18 03:46:22 --> Database Driver Class Initialized
DEBUG - 2023-01-18 03:46:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-01-18 03:46:22 --> Session: Class initialized using 'files' driver.
INFO - 2023-01-18 03:46:22 --> Controller Class Initialized
DEBUG - 2023-01-18 03:46:22 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/n_pengetahuan/views/list.php
DEBUG - 2023-01-18 03:46:22 --> File loaded: C:\xampp\htdocs\myraportk13\application\views\template_utama.php
INFO - 2023-01-18 03:46:22 --> Final output sent to browser
DEBUG - 2023-01-18 03:46:22 --> Total execution time: 0.0456
INFO - 2023-01-18 03:46:22 --> Config Class Initialized
INFO - 2023-01-18 03:46:22 --> Hooks Class Initialized
DEBUG - 2023-01-18 03:46:22 --> UTF-8 Support Enabled
INFO - 2023-01-18 03:46:22 --> Utf8 Class Initialized
INFO - 2023-01-18 03:46:22 --> URI Class Initialized
INFO - 2023-01-18 03:46:22 --> Router Class Initialized
INFO - 2023-01-18 03:46:22 --> Output Class Initialized
INFO - 2023-01-18 03:46:22 --> Security Class Initialized
DEBUG - 2023-01-18 03:46:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-18 03:46:22 --> Input Class Initialized
INFO - 2023-01-18 03:46:22 --> Language Class Initialized
INFO - 2023-01-18 03:46:22 --> Language Class Initialized
INFO - 2023-01-18 03:46:22 --> Config Class Initialized
INFO - 2023-01-18 03:46:22 --> Loader Class Initialized
INFO - 2023-01-18 03:46:22 --> Helper loaded: url_helper
INFO - 2023-01-18 03:46:22 --> Helper loaded: file_helper
INFO - 2023-01-18 03:46:22 --> Helper loaded: form_helper
INFO - 2023-01-18 03:46:22 --> Helper loaded: my_helper
INFO - 2023-01-18 03:46:22 --> Database Driver Class Initialized
DEBUG - 2023-01-18 03:46:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-01-18 03:46:22 --> Session: Class initialized using 'files' driver.
INFO - 2023-01-18 03:46:22 --> Controller Class Initialized
INFO - 2023-01-18 03:46:26 --> Config Class Initialized
INFO - 2023-01-18 03:46:26 --> Hooks Class Initialized
DEBUG - 2023-01-18 03:46:26 --> UTF-8 Support Enabled
INFO - 2023-01-18 03:46:26 --> Utf8 Class Initialized
INFO - 2023-01-18 03:46:26 --> URI Class Initialized
INFO - 2023-01-18 03:46:26 --> Router Class Initialized
INFO - 2023-01-18 03:46:26 --> Output Class Initialized
INFO - 2023-01-18 03:46:26 --> Security Class Initialized
DEBUG - 2023-01-18 03:46:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-18 03:46:26 --> Input Class Initialized
INFO - 2023-01-18 03:46:26 --> Language Class Initialized
INFO - 2023-01-18 03:46:26 --> Language Class Initialized
INFO - 2023-01-18 03:46:26 --> Config Class Initialized
INFO - 2023-01-18 03:46:26 --> Loader Class Initialized
INFO - 2023-01-18 03:46:26 --> Helper loaded: url_helper
INFO - 2023-01-18 03:46:26 --> Helper loaded: file_helper
INFO - 2023-01-18 03:46:26 --> Helper loaded: form_helper
INFO - 2023-01-18 03:46:26 --> Helper loaded: my_helper
INFO - 2023-01-18 03:46:26 --> Database Driver Class Initialized
DEBUG - 2023-01-18 03:46:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-01-18 03:46:26 --> Session: Class initialized using 'files' driver.
INFO - 2023-01-18 03:46:26 --> Controller Class Initialized
INFO - 2023-01-18 03:46:26 --> Final output sent to browser
DEBUG - 2023-01-18 03:46:26 --> Total execution time: 0.0279
INFO - 2023-01-18 03:46:35 --> Config Class Initialized
INFO - 2023-01-18 03:46:35 --> Hooks Class Initialized
DEBUG - 2023-01-18 03:46:35 --> UTF-8 Support Enabled
INFO - 2023-01-18 03:46:35 --> Utf8 Class Initialized
INFO - 2023-01-18 03:46:35 --> URI Class Initialized
INFO - 2023-01-18 03:46:35 --> Router Class Initialized
INFO - 2023-01-18 03:46:35 --> Output Class Initialized
INFO - 2023-01-18 03:46:35 --> Security Class Initialized
DEBUG - 2023-01-18 03:46:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-18 03:46:35 --> Input Class Initialized
INFO - 2023-01-18 03:46:35 --> Language Class Initialized
INFO - 2023-01-18 03:46:35 --> Language Class Initialized
INFO - 2023-01-18 03:46:35 --> Config Class Initialized
INFO - 2023-01-18 03:46:35 --> Loader Class Initialized
INFO - 2023-01-18 03:46:35 --> Helper loaded: url_helper
INFO - 2023-01-18 03:46:35 --> Helper loaded: file_helper
INFO - 2023-01-18 03:46:35 --> Helper loaded: form_helper
INFO - 2023-01-18 03:46:35 --> Helper loaded: my_helper
INFO - 2023-01-18 03:46:35 --> Database Driver Class Initialized
DEBUG - 2023-01-18 03:46:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-01-18 03:46:35 --> Session: Class initialized using 'files' driver.
INFO - 2023-01-18 03:46:35 --> Controller Class Initialized
INFO - 2023-01-18 03:46:35 --> Final output sent to browser
DEBUG - 2023-01-18 03:46:35 --> Total execution time: 0.0278
INFO - 2023-01-18 03:46:35 --> Config Class Initialized
INFO - 2023-01-18 03:46:35 --> Hooks Class Initialized
DEBUG - 2023-01-18 03:46:35 --> UTF-8 Support Enabled
INFO - 2023-01-18 03:46:35 --> Utf8 Class Initialized
INFO - 2023-01-18 03:46:35 --> URI Class Initialized
INFO - 2023-01-18 03:46:35 --> Router Class Initialized
INFO - 2023-01-18 03:46:35 --> Output Class Initialized
INFO - 2023-01-18 03:46:35 --> Security Class Initialized
DEBUG - 2023-01-18 03:46:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-18 03:46:35 --> Input Class Initialized
INFO - 2023-01-18 03:46:35 --> Language Class Initialized
INFO - 2023-01-18 03:46:35 --> Language Class Initialized
INFO - 2023-01-18 03:46:35 --> Config Class Initialized
INFO - 2023-01-18 03:46:35 --> Loader Class Initialized
INFO - 2023-01-18 03:46:35 --> Helper loaded: url_helper
INFO - 2023-01-18 03:46:35 --> Helper loaded: file_helper
INFO - 2023-01-18 03:46:35 --> Helper loaded: form_helper
INFO - 2023-01-18 03:46:35 --> Helper loaded: my_helper
INFO - 2023-01-18 03:46:35 --> Database Driver Class Initialized
DEBUG - 2023-01-18 03:46:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-01-18 03:46:35 --> Session: Class initialized using 'files' driver.
INFO - 2023-01-18 03:46:35 --> Controller Class Initialized
INFO - 2023-01-18 03:46:35 --> Final output sent to browser
DEBUG - 2023-01-18 03:46:35 --> Total execution time: 0.0246
INFO - 2023-01-18 03:47:05 --> Config Class Initialized
INFO - 2023-01-18 03:47:05 --> Hooks Class Initialized
DEBUG - 2023-01-18 03:47:05 --> UTF-8 Support Enabled
INFO - 2023-01-18 03:47:05 --> Utf8 Class Initialized
INFO - 2023-01-18 03:47:05 --> URI Class Initialized
INFO - 2023-01-18 03:47:05 --> Router Class Initialized
INFO - 2023-01-18 03:47:05 --> Output Class Initialized
INFO - 2023-01-18 03:47:05 --> Security Class Initialized
DEBUG - 2023-01-18 03:47:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-18 03:47:05 --> Input Class Initialized
INFO - 2023-01-18 03:47:05 --> Language Class Initialized
INFO - 2023-01-18 03:47:05 --> Language Class Initialized
INFO - 2023-01-18 03:47:05 --> Config Class Initialized
INFO - 2023-01-18 03:47:05 --> Loader Class Initialized
INFO - 2023-01-18 03:47:05 --> Helper loaded: url_helper
INFO - 2023-01-18 03:47:05 --> Helper loaded: file_helper
INFO - 2023-01-18 03:47:05 --> Helper loaded: form_helper
INFO - 2023-01-18 03:47:05 --> Helper loaded: my_helper
INFO - 2023-01-18 03:47:05 --> Database Driver Class Initialized
DEBUG - 2023-01-18 03:47:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-01-18 03:47:05 --> Session: Class initialized using 'files' driver.
INFO - 2023-01-18 03:47:05 --> Controller Class Initialized
INFO - 2023-01-18 03:47:29 --> Config Class Initialized
INFO - 2023-01-18 03:47:29 --> Hooks Class Initialized
DEBUG - 2023-01-18 03:47:29 --> UTF-8 Support Enabled
INFO - 2023-01-18 03:47:29 --> Utf8 Class Initialized
INFO - 2023-01-18 03:47:29 --> URI Class Initialized
INFO - 2023-01-18 03:47:29 --> Router Class Initialized
INFO - 2023-01-18 03:47:29 --> Output Class Initialized
INFO - 2023-01-18 03:47:29 --> Security Class Initialized
DEBUG - 2023-01-18 03:47:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-18 03:47:29 --> Input Class Initialized
INFO - 2023-01-18 03:47:29 --> Language Class Initialized
INFO - 2023-01-18 03:47:29 --> Language Class Initialized
INFO - 2023-01-18 03:47:29 --> Config Class Initialized
INFO - 2023-01-18 03:47:29 --> Loader Class Initialized
INFO - 2023-01-18 03:47:29 --> Helper loaded: url_helper
INFO - 2023-01-18 03:47:29 --> Helper loaded: file_helper
INFO - 2023-01-18 03:47:29 --> Helper loaded: form_helper
INFO - 2023-01-18 03:47:29 --> Helper loaded: my_helper
INFO - 2023-01-18 03:47:29 --> Database Driver Class Initialized
DEBUG - 2023-01-18 03:47:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-01-18 03:47:29 --> Session: Class initialized using 'files' driver.
INFO - 2023-01-18 03:47:29 --> Controller Class Initialized
DEBUG - 2023-01-18 03:47:29 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/view_mapel/views/v_view_mapel.php
DEBUG - 2023-01-18 03:47:29 --> File loaded: C:\xampp\htdocs\myraportk13\application\views\template_utama.php
INFO - 2023-01-18 03:47:29 --> Final output sent to browser
DEBUG - 2023-01-18 03:47:29 --> Total execution time: 0.0660
INFO - 2023-01-18 03:47:33 --> Config Class Initialized
INFO - 2023-01-18 03:47:33 --> Hooks Class Initialized
DEBUG - 2023-01-18 03:47:33 --> UTF-8 Support Enabled
INFO - 2023-01-18 03:47:33 --> Utf8 Class Initialized
INFO - 2023-01-18 03:47:33 --> URI Class Initialized
INFO - 2023-01-18 03:47:33 --> Router Class Initialized
INFO - 2023-01-18 03:47:33 --> Output Class Initialized
INFO - 2023-01-18 03:47:33 --> Security Class Initialized
DEBUG - 2023-01-18 03:47:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-18 03:47:33 --> Input Class Initialized
INFO - 2023-01-18 03:47:33 --> Language Class Initialized
INFO - 2023-01-18 03:47:33 --> Language Class Initialized
INFO - 2023-01-18 03:47:33 --> Config Class Initialized
INFO - 2023-01-18 03:47:33 --> Loader Class Initialized
INFO - 2023-01-18 03:47:33 --> Helper loaded: url_helper
INFO - 2023-01-18 03:47:33 --> Helper loaded: file_helper
INFO - 2023-01-18 03:47:33 --> Helper loaded: form_helper
INFO - 2023-01-18 03:47:33 --> Helper loaded: my_helper
INFO - 2023-01-18 03:47:33 --> Database Driver Class Initialized
DEBUG - 2023-01-18 03:47:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-01-18 03:47:33 --> Session: Class initialized using 'files' driver.
INFO - 2023-01-18 03:47:33 --> Controller Class Initialized
DEBUG - 2023-01-18 03:47:33 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/n_pengetahuan/views/list.php
DEBUG - 2023-01-18 03:47:33 --> File loaded: C:\xampp\htdocs\myraportk13\application\views\template_utama.php
INFO - 2023-01-18 03:47:33 --> Final output sent to browser
DEBUG - 2023-01-18 03:47:33 --> Total execution time: 0.0381
INFO - 2023-01-18 03:47:33 --> Config Class Initialized
INFO - 2023-01-18 03:47:33 --> Hooks Class Initialized
DEBUG - 2023-01-18 03:47:33 --> UTF-8 Support Enabled
INFO - 2023-01-18 03:47:33 --> Utf8 Class Initialized
INFO - 2023-01-18 03:47:33 --> URI Class Initialized
INFO - 2023-01-18 03:47:33 --> Router Class Initialized
INFO - 2023-01-18 03:47:33 --> Output Class Initialized
INFO - 2023-01-18 03:47:33 --> Security Class Initialized
DEBUG - 2023-01-18 03:47:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-18 03:47:33 --> Input Class Initialized
INFO - 2023-01-18 03:47:33 --> Language Class Initialized
INFO - 2023-01-18 03:47:33 --> Language Class Initialized
INFO - 2023-01-18 03:47:33 --> Config Class Initialized
INFO - 2023-01-18 03:47:33 --> Loader Class Initialized
INFO - 2023-01-18 03:47:33 --> Helper loaded: url_helper
INFO - 2023-01-18 03:47:33 --> Helper loaded: file_helper
INFO - 2023-01-18 03:47:33 --> Helper loaded: form_helper
INFO - 2023-01-18 03:47:33 --> Helper loaded: my_helper
INFO - 2023-01-18 03:47:33 --> Database Driver Class Initialized
DEBUG - 2023-01-18 03:47:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-01-18 03:47:33 --> Session: Class initialized using 'files' driver.
INFO - 2023-01-18 03:47:33 --> Controller Class Initialized
INFO - 2023-01-18 03:51:53 --> Config Class Initialized
INFO - 2023-01-18 03:51:53 --> Hooks Class Initialized
DEBUG - 2023-01-18 03:51:53 --> UTF-8 Support Enabled
INFO - 2023-01-18 03:51:53 --> Utf8 Class Initialized
INFO - 2023-01-18 03:51:53 --> URI Class Initialized
INFO - 2023-01-18 03:51:53 --> Router Class Initialized
INFO - 2023-01-18 03:51:53 --> Output Class Initialized
INFO - 2023-01-18 03:51:53 --> Security Class Initialized
DEBUG - 2023-01-18 03:51:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-18 03:51:53 --> Input Class Initialized
INFO - 2023-01-18 03:51:53 --> Language Class Initialized
INFO - 2023-01-18 03:51:53 --> Language Class Initialized
INFO - 2023-01-18 03:51:53 --> Config Class Initialized
INFO - 2023-01-18 03:51:53 --> Loader Class Initialized
INFO - 2023-01-18 03:51:53 --> Helper loaded: url_helper
INFO - 2023-01-18 03:51:53 --> Helper loaded: file_helper
INFO - 2023-01-18 03:51:53 --> Helper loaded: form_helper
INFO - 2023-01-18 03:51:53 --> Helper loaded: my_helper
INFO - 2023-01-18 03:51:53 --> Database Driver Class Initialized
DEBUG - 2023-01-18 03:51:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-01-18 03:51:53 --> Session: Class initialized using 'files' driver.
INFO - 2023-01-18 03:51:53 --> Controller Class Initialized
DEBUG - 2023-01-18 03:51:53 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/view_mapel/views/v_view_mapel.php
DEBUG - 2023-01-18 03:51:53 --> File loaded: C:\xampp\htdocs\myraportk13\application\views\template_utama.php
INFO - 2023-01-18 03:51:53 --> Final output sent to browser
DEBUG - 2023-01-18 03:51:53 --> Total execution time: 0.0457
INFO - 2023-01-18 03:52:04 --> Config Class Initialized
INFO - 2023-01-18 03:52:04 --> Hooks Class Initialized
DEBUG - 2023-01-18 03:52:04 --> UTF-8 Support Enabled
INFO - 2023-01-18 03:52:04 --> Utf8 Class Initialized
INFO - 2023-01-18 03:52:04 --> URI Class Initialized
INFO - 2023-01-18 03:52:04 --> Router Class Initialized
INFO - 2023-01-18 03:52:04 --> Output Class Initialized
INFO - 2023-01-18 03:52:04 --> Security Class Initialized
DEBUG - 2023-01-18 03:52:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-18 03:52:04 --> Input Class Initialized
INFO - 2023-01-18 03:52:04 --> Language Class Initialized
INFO - 2023-01-18 03:52:04 --> Language Class Initialized
INFO - 2023-01-18 03:52:04 --> Config Class Initialized
INFO - 2023-01-18 03:52:04 --> Loader Class Initialized
INFO - 2023-01-18 03:52:04 --> Helper loaded: url_helper
INFO - 2023-01-18 03:52:04 --> Helper loaded: file_helper
INFO - 2023-01-18 03:52:04 --> Helper loaded: form_helper
INFO - 2023-01-18 03:52:04 --> Helper loaded: my_helper
INFO - 2023-01-18 03:52:04 --> Database Driver Class Initialized
DEBUG - 2023-01-18 03:52:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-01-18 03:52:04 --> Session: Class initialized using 'files' driver.
INFO - 2023-01-18 03:52:04 --> Controller Class Initialized
DEBUG - 2023-01-18 03:52:04 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/n_catatan_guru/views/list.php
DEBUG - 2023-01-18 03:52:04 --> File loaded: C:\xampp\htdocs\myraportk13\application\views\template_utama.php
INFO - 2023-01-18 03:52:04 --> Final output sent to browser
DEBUG - 2023-01-18 03:52:04 --> Total execution time: 0.0831
INFO - 2023-01-18 03:52:06 --> Config Class Initialized
INFO - 2023-01-18 03:52:06 --> Hooks Class Initialized
DEBUG - 2023-01-18 03:52:06 --> UTF-8 Support Enabled
INFO - 2023-01-18 03:52:06 --> Utf8 Class Initialized
INFO - 2023-01-18 03:52:06 --> URI Class Initialized
INFO - 2023-01-18 03:52:06 --> Router Class Initialized
INFO - 2023-01-18 03:52:06 --> Output Class Initialized
INFO - 2023-01-18 03:52:06 --> Security Class Initialized
DEBUG - 2023-01-18 03:52:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-18 03:52:06 --> Input Class Initialized
INFO - 2023-01-18 03:52:06 --> Language Class Initialized
INFO - 2023-01-18 03:52:06 --> Language Class Initialized
INFO - 2023-01-18 03:52:06 --> Config Class Initialized
INFO - 2023-01-18 03:52:06 --> Loader Class Initialized
INFO - 2023-01-18 03:52:06 --> Helper loaded: url_helper
INFO - 2023-01-18 03:52:06 --> Helper loaded: file_helper
INFO - 2023-01-18 03:52:06 --> Helper loaded: form_helper
INFO - 2023-01-18 03:52:06 --> Helper loaded: my_helper
INFO - 2023-01-18 03:52:06 --> Database Driver Class Initialized
DEBUG - 2023-01-18 03:52:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-01-18 03:52:06 --> Session: Class initialized using 'files' driver.
INFO - 2023-01-18 03:52:06 --> Controller Class Initialized
INFO - 2023-01-18 03:52:06 --> Final output sent to browser
DEBUG - 2023-01-18 03:52:06 --> Total execution time: 0.0317
INFO - 2023-01-18 03:52:19 --> Config Class Initialized
INFO - 2023-01-18 03:52:19 --> Hooks Class Initialized
DEBUG - 2023-01-18 03:52:19 --> UTF-8 Support Enabled
INFO - 2023-01-18 03:52:19 --> Utf8 Class Initialized
INFO - 2023-01-18 03:52:19 --> URI Class Initialized
INFO - 2023-01-18 03:52:19 --> Router Class Initialized
INFO - 2023-01-18 03:52:19 --> Output Class Initialized
INFO - 2023-01-18 03:52:19 --> Security Class Initialized
DEBUG - 2023-01-18 03:52:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-18 03:52:19 --> Input Class Initialized
INFO - 2023-01-18 03:52:19 --> Language Class Initialized
INFO - 2023-01-18 03:52:19 --> Language Class Initialized
INFO - 2023-01-18 03:52:19 --> Config Class Initialized
INFO - 2023-01-18 03:52:19 --> Loader Class Initialized
INFO - 2023-01-18 03:52:19 --> Helper loaded: url_helper
INFO - 2023-01-18 03:52:19 --> Helper loaded: file_helper
INFO - 2023-01-18 03:52:19 --> Helper loaded: form_helper
INFO - 2023-01-18 03:52:19 --> Helper loaded: my_helper
INFO - 2023-01-18 03:52:19 --> Database Driver Class Initialized
DEBUG - 2023-01-18 03:52:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-01-18 03:52:19 --> Session: Class initialized using 'files' driver.
INFO - 2023-01-18 03:52:19 --> Controller Class Initialized
DEBUG - 2023-01-18 03:52:19 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/view_mapel/views/v_view_mapel.php
DEBUG - 2023-01-18 03:52:19 --> File loaded: C:\xampp\htdocs\myraportk13\application\views\template_utama.php
INFO - 2023-01-18 03:52:19 --> Final output sent to browser
DEBUG - 2023-01-18 03:52:19 --> Total execution time: 0.0637
INFO - 2023-01-18 03:52:21 --> Config Class Initialized
INFO - 2023-01-18 03:52:21 --> Hooks Class Initialized
DEBUG - 2023-01-18 03:52:21 --> UTF-8 Support Enabled
INFO - 2023-01-18 03:52:21 --> Utf8 Class Initialized
INFO - 2023-01-18 03:52:21 --> URI Class Initialized
INFO - 2023-01-18 03:52:21 --> Router Class Initialized
INFO - 2023-01-18 03:52:21 --> Output Class Initialized
INFO - 2023-01-18 03:52:21 --> Security Class Initialized
DEBUG - 2023-01-18 03:52:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-18 03:52:21 --> Input Class Initialized
INFO - 2023-01-18 03:52:21 --> Language Class Initialized
INFO - 2023-01-18 03:52:21 --> Language Class Initialized
INFO - 2023-01-18 03:52:21 --> Config Class Initialized
INFO - 2023-01-18 03:52:21 --> Loader Class Initialized
INFO - 2023-01-18 03:52:21 --> Helper loaded: url_helper
INFO - 2023-01-18 03:52:21 --> Helper loaded: file_helper
INFO - 2023-01-18 03:52:21 --> Helper loaded: form_helper
INFO - 2023-01-18 03:52:21 --> Helper loaded: my_helper
INFO - 2023-01-18 03:52:21 --> Database Driver Class Initialized
DEBUG - 2023-01-18 03:52:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-01-18 03:52:21 --> Session: Class initialized using 'files' driver.
INFO - 2023-01-18 03:52:21 --> Controller Class Initialized
DEBUG - 2023-01-18 03:52:21 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/n_catatan_guru/views/list.php
DEBUG - 2023-01-18 03:52:21 --> File loaded: C:\xampp\htdocs\myraportk13\application\views\template_utama.php
INFO - 2023-01-18 03:52:21 --> Final output sent to browser
DEBUG - 2023-01-18 03:52:21 --> Total execution time: 0.0415
INFO - 2023-01-18 03:52:23 --> Config Class Initialized
INFO - 2023-01-18 03:52:23 --> Hooks Class Initialized
DEBUG - 2023-01-18 03:52:23 --> UTF-8 Support Enabled
INFO - 2023-01-18 03:52:23 --> Utf8 Class Initialized
INFO - 2023-01-18 03:52:23 --> URI Class Initialized
INFO - 2023-01-18 03:52:23 --> Router Class Initialized
INFO - 2023-01-18 03:52:23 --> Output Class Initialized
INFO - 2023-01-18 03:52:23 --> Security Class Initialized
DEBUG - 2023-01-18 03:52:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-18 03:52:23 --> Input Class Initialized
INFO - 2023-01-18 03:52:23 --> Language Class Initialized
INFO - 2023-01-18 03:52:23 --> Language Class Initialized
INFO - 2023-01-18 03:52:23 --> Config Class Initialized
INFO - 2023-01-18 03:52:23 --> Loader Class Initialized
INFO - 2023-01-18 03:52:23 --> Helper loaded: url_helper
INFO - 2023-01-18 03:52:23 --> Helper loaded: file_helper
INFO - 2023-01-18 03:52:23 --> Helper loaded: form_helper
INFO - 2023-01-18 03:52:23 --> Helper loaded: my_helper
INFO - 2023-01-18 03:52:23 --> Database Driver Class Initialized
DEBUG - 2023-01-18 03:52:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-01-18 03:52:23 --> Session: Class initialized using 'files' driver.
INFO - 2023-01-18 03:52:23 --> Controller Class Initialized
INFO - 2023-01-18 03:52:23 --> Final output sent to browser
DEBUG - 2023-01-18 03:52:23 --> Total execution time: 0.0370
INFO - 2023-01-18 03:53:20 --> Config Class Initialized
INFO - 2023-01-18 03:53:20 --> Hooks Class Initialized
DEBUG - 2023-01-18 03:53:20 --> UTF-8 Support Enabled
INFO - 2023-01-18 03:53:20 --> Utf8 Class Initialized
INFO - 2023-01-18 03:53:20 --> URI Class Initialized
INFO - 2023-01-18 03:53:20 --> Router Class Initialized
INFO - 2023-01-18 03:53:20 --> Output Class Initialized
INFO - 2023-01-18 03:53:20 --> Security Class Initialized
DEBUG - 2023-01-18 03:53:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-18 03:53:20 --> Input Class Initialized
INFO - 2023-01-18 03:53:20 --> Language Class Initialized
INFO - 2023-01-18 03:53:20 --> Language Class Initialized
INFO - 2023-01-18 03:53:20 --> Config Class Initialized
INFO - 2023-01-18 03:53:20 --> Loader Class Initialized
INFO - 2023-01-18 03:53:20 --> Helper loaded: url_helper
INFO - 2023-01-18 03:53:20 --> Helper loaded: file_helper
INFO - 2023-01-18 03:53:20 --> Helper loaded: form_helper
INFO - 2023-01-18 03:53:20 --> Helper loaded: my_helper
INFO - 2023-01-18 03:53:20 --> Database Driver Class Initialized
DEBUG - 2023-01-18 03:53:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-01-18 03:53:20 --> Session: Class initialized using 'files' driver.
INFO - 2023-01-18 03:53:20 --> Controller Class Initialized
INFO - 2023-01-18 03:53:20 --> Final output sent to browser
DEBUG - 2023-01-18 03:53:20 --> Total execution time: 0.0348
INFO - 2023-01-18 03:53:42 --> Config Class Initialized
INFO - 2023-01-18 03:53:42 --> Hooks Class Initialized
DEBUG - 2023-01-18 03:53:42 --> UTF-8 Support Enabled
INFO - 2023-01-18 03:53:42 --> Utf8 Class Initialized
INFO - 2023-01-18 03:53:42 --> URI Class Initialized
INFO - 2023-01-18 03:53:42 --> Router Class Initialized
INFO - 2023-01-18 03:53:42 --> Output Class Initialized
INFO - 2023-01-18 03:53:42 --> Security Class Initialized
DEBUG - 2023-01-18 03:53:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-18 03:53:42 --> Input Class Initialized
INFO - 2023-01-18 03:53:42 --> Language Class Initialized
INFO - 2023-01-18 03:53:42 --> Language Class Initialized
INFO - 2023-01-18 03:53:42 --> Config Class Initialized
INFO - 2023-01-18 03:53:42 --> Loader Class Initialized
INFO - 2023-01-18 03:53:42 --> Helper loaded: url_helper
INFO - 2023-01-18 03:53:42 --> Helper loaded: file_helper
INFO - 2023-01-18 03:53:42 --> Helper loaded: form_helper
INFO - 2023-01-18 03:53:42 --> Helper loaded: my_helper
INFO - 2023-01-18 03:53:42 --> Database Driver Class Initialized
DEBUG - 2023-01-18 03:53:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-01-18 03:53:42 --> Session: Class initialized using 'files' driver.
INFO - 2023-01-18 03:53:42 --> Controller Class Initialized
INFO - 2023-01-18 03:55:21 --> Config Class Initialized
INFO - 2023-01-18 03:55:21 --> Hooks Class Initialized
DEBUG - 2023-01-18 03:55:21 --> UTF-8 Support Enabled
INFO - 2023-01-18 03:55:21 --> Utf8 Class Initialized
INFO - 2023-01-18 03:55:21 --> URI Class Initialized
INFO - 2023-01-18 03:55:21 --> Router Class Initialized
INFO - 2023-01-18 03:55:21 --> Output Class Initialized
INFO - 2023-01-18 03:55:21 --> Security Class Initialized
DEBUG - 2023-01-18 03:55:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-18 03:55:21 --> Input Class Initialized
INFO - 2023-01-18 03:55:21 --> Language Class Initialized
INFO - 2023-01-18 03:55:21 --> Language Class Initialized
INFO - 2023-01-18 03:55:21 --> Config Class Initialized
INFO - 2023-01-18 03:55:21 --> Loader Class Initialized
INFO - 2023-01-18 03:55:21 --> Helper loaded: url_helper
INFO - 2023-01-18 03:55:21 --> Helper loaded: file_helper
INFO - 2023-01-18 03:55:21 --> Helper loaded: form_helper
INFO - 2023-01-18 03:55:21 --> Helper loaded: my_helper
INFO - 2023-01-18 03:55:21 --> Database Driver Class Initialized
DEBUG - 2023-01-18 03:55:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-01-18 03:55:21 --> Session: Class initialized using 'files' driver.
INFO - 2023-01-18 03:55:21 --> Controller Class Initialized
INFO - 2023-01-18 03:55:21 --> Helper loaded: cookie_helper
INFO - 2023-01-18 03:55:21 --> Config Class Initialized
INFO - 2023-01-18 03:55:21 --> Hooks Class Initialized
DEBUG - 2023-01-18 03:55:21 --> UTF-8 Support Enabled
INFO - 2023-01-18 03:55:21 --> Utf8 Class Initialized
INFO - 2023-01-18 03:55:21 --> URI Class Initialized
INFO - 2023-01-18 03:55:21 --> Router Class Initialized
INFO - 2023-01-18 03:55:21 --> Output Class Initialized
INFO - 2023-01-18 03:55:21 --> Security Class Initialized
DEBUG - 2023-01-18 03:55:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-18 03:55:21 --> Input Class Initialized
INFO - 2023-01-18 03:55:21 --> Language Class Initialized
INFO - 2023-01-18 03:55:21 --> Language Class Initialized
INFO - 2023-01-18 03:55:21 --> Config Class Initialized
INFO - 2023-01-18 03:55:21 --> Loader Class Initialized
INFO - 2023-01-18 03:55:21 --> Helper loaded: url_helper
INFO - 2023-01-18 03:55:21 --> Helper loaded: file_helper
INFO - 2023-01-18 03:55:21 --> Helper loaded: form_helper
INFO - 2023-01-18 03:55:21 --> Helper loaded: my_helper
INFO - 2023-01-18 03:55:21 --> Database Driver Class Initialized
DEBUG - 2023-01-18 03:55:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-01-18 03:55:21 --> Session: Class initialized using 'files' driver.
INFO - 2023-01-18 03:55:21 --> Controller Class Initialized
INFO - 2023-01-18 03:55:21 --> Config Class Initialized
INFO - 2023-01-18 03:55:21 --> Hooks Class Initialized
DEBUG - 2023-01-18 03:55:21 --> UTF-8 Support Enabled
INFO - 2023-01-18 03:55:21 --> Utf8 Class Initialized
INFO - 2023-01-18 03:55:21 --> URI Class Initialized
INFO - 2023-01-18 03:55:21 --> Router Class Initialized
INFO - 2023-01-18 03:55:21 --> Output Class Initialized
INFO - 2023-01-18 03:55:21 --> Security Class Initialized
DEBUG - 2023-01-18 03:55:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-18 03:55:21 --> Input Class Initialized
INFO - 2023-01-18 03:55:21 --> Language Class Initialized
INFO - 2023-01-18 03:55:21 --> Language Class Initialized
INFO - 2023-01-18 03:55:21 --> Config Class Initialized
INFO - 2023-01-18 03:55:21 --> Loader Class Initialized
INFO - 2023-01-18 03:55:21 --> Helper loaded: url_helper
INFO - 2023-01-18 03:55:21 --> Helper loaded: file_helper
INFO - 2023-01-18 03:55:21 --> Helper loaded: form_helper
INFO - 2023-01-18 03:55:21 --> Helper loaded: my_helper
INFO - 2023-01-18 03:55:21 --> Database Driver Class Initialized
DEBUG - 2023-01-18 03:55:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-01-18 03:55:21 --> Session: Class initialized using 'files' driver.
INFO - 2023-01-18 03:55:21 --> Controller Class Initialized
DEBUG - 2023-01-18 03:55:21 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/login/views/login.php
DEBUG - 2023-01-18 03:55:21 --> File loaded: C:\xampp\htdocs\myraportk13\application\views\template_utama.php
INFO - 2023-01-18 03:55:21 --> Final output sent to browser
DEBUG - 2023-01-18 03:55:21 --> Total execution time: 0.0247
INFO - 2023-01-18 03:55:25 --> Config Class Initialized
INFO - 2023-01-18 03:55:25 --> Hooks Class Initialized
DEBUG - 2023-01-18 03:55:25 --> UTF-8 Support Enabled
INFO - 2023-01-18 03:55:25 --> Utf8 Class Initialized
INFO - 2023-01-18 03:55:25 --> URI Class Initialized
INFO - 2023-01-18 03:55:25 --> Router Class Initialized
INFO - 2023-01-18 03:55:25 --> Output Class Initialized
INFO - 2023-01-18 03:55:25 --> Security Class Initialized
DEBUG - 2023-01-18 03:55:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-18 03:55:25 --> Input Class Initialized
INFO - 2023-01-18 03:55:25 --> Language Class Initialized
INFO - 2023-01-18 03:55:25 --> Language Class Initialized
INFO - 2023-01-18 03:55:25 --> Config Class Initialized
INFO - 2023-01-18 03:55:25 --> Loader Class Initialized
INFO - 2023-01-18 03:55:25 --> Helper loaded: url_helper
INFO - 2023-01-18 03:55:25 --> Helper loaded: file_helper
INFO - 2023-01-18 03:55:25 --> Helper loaded: form_helper
INFO - 2023-01-18 03:55:25 --> Helper loaded: my_helper
INFO - 2023-01-18 03:55:25 --> Database Driver Class Initialized
DEBUG - 2023-01-18 03:55:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-01-18 03:55:25 --> Session: Class initialized using 'files' driver.
INFO - 2023-01-18 03:55:25 --> Controller Class Initialized
INFO - 2023-01-18 03:55:25 --> Helper loaded: cookie_helper
INFO - 2023-01-18 03:55:25 --> Final output sent to browser
DEBUG - 2023-01-18 03:55:25 --> Total execution time: 0.0308
INFO - 2023-01-18 03:55:25 --> Config Class Initialized
INFO - 2023-01-18 03:55:25 --> Hooks Class Initialized
DEBUG - 2023-01-18 03:55:25 --> UTF-8 Support Enabled
INFO - 2023-01-18 03:55:25 --> Utf8 Class Initialized
INFO - 2023-01-18 03:55:25 --> URI Class Initialized
INFO - 2023-01-18 03:55:25 --> Router Class Initialized
INFO - 2023-01-18 03:55:25 --> Output Class Initialized
INFO - 2023-01-18 03:55:25 --> Security Class Initialized
DEBUG - 2023-01-18 03:55:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-18 03:55:25 --> Input Class Initialized
INFO - 2023-01-18 03:55:25 --> Language Class Initialized
INFO - 2023-01-18 03:55:25 --> Language Class Initialized
INFO - 2023-01-18 03:55:25 --> Config Class Initialized
INFO - 2023-01-18 03:55:25 --> Loader Class Initialized
INFO - 2023-01-18 03:55:25 --> Helper loaded: url_helper
INFO - 2023-01-18 03:55:25 --> Helper loaded: file_helper
INFO - 2023-01-18 03:55:25 --> Helper loaded: form_helper
INFO - 2023-01-18 03:55:25 --> Helper loaded: my_helper
INFO - 2023-01-18 03:55:25 --> Database Driver Class Initialized
DEBUG - 2023-01-18 03:55:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-01-18 03:55:25 --> Session: Class initialized using 'files' driver.
INFO - 2023-01-18 03:55:25 --> Controller Class Initialized
DEBUG - 2023-01-18 03:55:25 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/home/views/v_home_guru.php
DEBUG - 2023-01-18 03:55:25 --> File loaded: C:\xampp\htdocs\myraportk13\application\views\template_utama.php
INFO - 2023-01-18 03:55:25 --> Final output sent to browser
DEBUG - 2023-01-18 03:55:25 --> Total execution time: 0.0439
INFO - 2023-01-18 03:55:52 --> Config Class Initialized
INFO - 2023-01-18 03:55:52 --> Hooks Class Initialized
DEBUG - 2023-01-18 03:55:52 --> UTF-8 Support Enabled
INFO - 2023-01-18 03:55:52 --> Utf8 Class Initialized
INFO - 2023-01-18 03:55:52 --> URI Class Initialized
INFO - 2023-01-18 03:55:52 --> Router Class Initialized
INFO - 2023-01-18 03:55:52 --> Output Class Initialized
INFO - 2023-01-18 03:55:52 --> Security Class Initialized
DEBUG - 2023-01-18 03:55:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-18 03:55:52 --> Input Class Initialized
INFO - 2023-01-18 03:55:52 --> Language Class Initialized
INFO - 2023-01-18 03:55:52 --> Language Class Initialized
INFO - 2023-01-18 03:55:52 --> Config Class Initialized
INFO - 2023-01-18 03:55:52 --> Loader Class Initialized
INFO - 2023-01-18 03:55:52 --> Helper loaded: url_helper
INFO - 2023-01-18 03:55:52 --> Helper loaded: file_helper
INFO - 2023-01-18 03:55:52 --> Helper loaded: form_helper
INFO - 2023-01-18 03:55:52 --> Helper loaded: my_helper
INFO - 2023-01-18 03:55:52 --> Database Driver Class Initialized
DEBUG - 2023-01-18 03:55:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-01-18 03:55:52 --> Session: Class initialized using 'files' driver.
INFO - 2023-01-18 03:55:52 --> Controller Class Initialized
DEBUG - 2023-01-18 03:55:52 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/cetak_raport/views/list.php
DEBUG - 2023-01-18 03:55:52 --> File loaded: C:\xampp\htdocs\myraportk13\application\views\template_utama.php
INFO - 2023-01-18 03:55:52 --> Final output sent to browser
DEBUG - 2023-01-18 03:55:52 --> Total execution time: 0.0976
INFO - 2023-01-18 03:56:08 --> Config Class Initialized
INFO - 2023-01-18 03:56:08 --> Hooks Class Initialized
DEBUG - 2023-01-18 03:56:08 --> UTF-8 Support Enabled
INFO - 2023-01-18 03:56:08 --> Utf8 Class Initialized
INFO - 2023-01-18 03:56:08 --> URI Class Initialized
INFO - 2023-01-18 03:56:08 --> Router Class Initialized
INFO - 2023-01-18 03:56:08 --> Output Class Initialized
INFO - 2023-01-18 03:56:08 --> Security Class Initialized
DEBUG - 2023-01-18 03:56:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-18 03:56:08 --> Input Class Initialized
INFO - 2023-01-18 03:56:08 --> Language Class Initialized
INFO - 2023-01-18 03:56:08 --> Language Class Initialized
INFO - 2023-01-18 03:56:08 --> Config Class Initialized
INFO - 2023-01-18 03:56:08 --> Loader Class Initialized
INFO - 2023-01-18 03:56:08 --> Helper loaded: url_helper
INFO - 2023-01-18 03:56:08 --> Helper loaded: file_helper
INFO - 2023-01-18 03:56:08 --> Helper loaded: form_helper
INFO - 2023-01-18 03:56:08 --> Helper loaded: my_helper
INFO - 2023-01-18 03:56:08 --> Database Driver Class Initialized
DEBUG - 2023-01-18 03:56:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-01-18 03:56:08 --> Session: Class initialized using 'files' driver.
INFO - 2023-01-18 03:56:08 --> Controller Class Initialized
DEBUG - 2023-01-18 03:56:08 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/cetak_raport/views/list.php
DEBUG - 2023-01-18 03:56:08 --> File loaded: C:\xampp\htdocs\myraportk13\application\views\template_utama.php
INFO - 2023-01-18 03:56:08 --> Final output sent to browser
DEBUG - 2023-01-18 03:56:08 --> Total execution time: 0.0462
INFO - 2023-01-18 03:56:21 --> Config Class Initialized
INFO - 2023-01-18 03:56:21 --> Hooks Class Initialized
DEBUG - 2023-01-18 03:56:21 --> UTF-8 Support Enabled
INFO - 2023-01-18 03:56:21 --> Utf8 Class Initialized
INFO - 2023-01-18 03:56:21 --> URI Class Initialized
INFO - 2023-01-18 03:56:21 --> Router Class Initialized
INFO - 2023-01-18 03:56:21 --> Output Class Initialized
INFO - 2023-01-18 03:56:21 --> Security Class Initialized
DEBUG - 2023-01-18 03:56:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-18 03:56:21 --> Input Class Initialized
INFO - 2023-01-18 03:56:21 --> Language Class Initialized
INFO - 2023-01-18 03:56:21 --> Language Class Initialized
INFO - 2023-01-18 03:56:21 --> Config Class Initialized
INFO - 2023-01-18 03:56:21 --> Loader Class Initialized
INFO - 2023-01-18 03:56:21 --> Helper loaded: url_helper
INFO - 2023-01-18 03:56:21 --> Helper loaded: file_helper
INFO - 2023-01-18 03:56:21 --> Helper loaded: form_helper
INFO - 2023-01-18 03:56:21 --> Helper loaded: my_helper
INFO - 2023-01-18 03:56:21 --> Database Driver Class Initialized
DEBUG - 2023-01-18 03:56:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-01-18 03:56:21 --> Session: Class initialized using 'files' driver.
INFO - 2023-01-18 03:56:21 --> Controller Class Initialized
DEBUG - 2023-01-18 03:56:21 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/cetak_raport/views/cetak_mh.php
INFO - 2023-01-18 03:56:23 --> Final output sent to browser
DEBUG - 2023-01-18 03:56:23 --> Total execution time: 2.2256
INFO - 2023-01-18 03:56:26 --> Config Class Initialized
INFO - 2023-01-18 03:56:26 --> Hooks Class Initialized
DEBUG - 2023-01-18 03:56:26 --> UTF-8 Support Enabled
INFO - 2023-01-18 03:56:26 --> Utf8 Class Initialized
INFO - 2023-01-18 03:56:26 --> URI Class Initialized
INFO - 2023-01-18 03:56:26 --> Router Class Initialized
INFO - 2023-01-18 03:56:26 --> Output Class Initialized
INFO - 2023-01-18 03:56:26 --> Security Class Initialized
DEBUG - 2023-01-18 03:56:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-18 03:56:26 --> Input Class Initialized
INFO - 2023-01-18 03:56:26 --> Language Class Initialized
INFO - 2023-01-18 03:56:26 --> Language Class Initialized
INFO - 2023-01-18 03:56:26 --> Config Class Initialized
INFO - 2023-01-18 03:56:26 --> Loader Class Initialized
INFO - 2023-01-18 03:56:26 --> Helper loaded: url_helper
INFO - 2023-01-18 03:56:26 --> Helper loaded: file_helper
INFO - 2023-01-18 03:56:26 --> Helper loaded: form_helper
INFO - 2023-01-18 03:56:26 --> Helper loaded: my_helper
INFO - 2023-01-18 03:56:26 --> Database Driver Class Initialized
DEBUG - 2023-01-18 03:56:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-01-18 03:56:26 --> Session: Class initialized using 'files' driver.
INFO - 2023-01-18 03:56:26 --> Controller Class Initialized
DEBUG - 2023-01-18 03:56:26 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/cetak_raport/views/cetak_mh.php
INFO - 2023-01-18 03:56:27 --> Final output sent to browser
DEBUG - 2023-01-18 03:56:27 --> Total execution time: 1.3654
INFO - 2023-01-18 03:57:59 --> Config Class Initialized
INFO - 2023-01-18 03:57:59 --> Hooks Class Initialized
DEBUG - 2023-01-18 03:57:59 --> UTF-8 Support Enabled
INFO - 2023-01-18 03:57:59 --> Utf8 Class Initialized
INFO - 2023-01-18 03:57:59 --> URI Class Initialized
INFO - 2023-01-18 03:57:59 --> Router Class Initialized
INFO - 2023-01-18 03:57:59 --> Output Class Initialized
INFO - 2023-01-18 03:57:59 --> Security Class Initialized
DEBUG - 2023-01-18 03:57:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-18 03:57:59 --> Input Class Initialized
INFO - 2023-01-18 03:57:59 --> Language Class Initialized
INFO - 2023-01-18 03:57:59 --> Language Class Initialized
INFO - 2023-01-18 03:57:59 --> Config Class Initialized
INFO - 2023-01-18 03:57:59 --> Loader Class Initialized
INFO - 2023-01-18 03:57:59 --> Helper loaded: url_helper
INFO - 2023-01-18 03:57:59 --> Helper loaded: file_helper
INFO - 2023-01-18 03:57:59 --> Helper loaded: form_helper
INFO - 2023-01-18 03:57:59 --> Helper loaded: my_helper
INFO - 2023-01-18 03:57:59 --> Database Driver Class Initialized
DEBUG - 2023-01-18 03:57:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-01-18 03:57:59 --> Session: Class initialized using 'files' driver.
INFO - 2023-01-18 03:57:59 --> Controller Class Initialized
DEBUG - 2023-01-18 03:57:59 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/view_mapel/views/v_view_mapel.php
DEBUG - 2023-01-18 03:57:59 --> File loaded: C:\xampp\htdocs\myraportk13\application\views\template_utama.php
INFO - 2023-01-18 03:57:59 --> Final output sent to browser
DEBUG - 2023-01-18 03:57:59 --> Total execution time: 0.0334
INFO - 2023-01-18 03:58:09 --> Config Class Initialized
INFO - 2023-01-18 03:58:09 --> Hooks Class Initialized
DEBUG - 2023-01-18 03:58:09 --> UTF-8 Support Enabled
INFO - 2023-01-18 03:58:09 --> Utf8 Class Initialized
INFO - 2023-01-18 03:58:09 --> URI Class Initialized
INFO - 2023-01-18 03:58:09 --> Router Class Initialized
INFO - 2023-01-18 03:58:09 --> Output Class Initialized
INFO - 2023-01-18 03:58:09 --> Security Class Initialized
DEBUG - 2023-01-18 03:58:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-18 03:58:09 --> Input Class Initialized
INFO - 2023-01-18 03:58:09 --> Language Class Initialized
INFO - 2023-01-18 03:58:10 --> Language Class Initialized
INFO - 2023-01-18 03:58:10 --> Config Class Initialized
INFO - 2023-01-18 03:58:10 --> Loader Class Initialized
INFO - 2023-01-18 03:58:10 --> Helper loaded: url_helper
INFO - 2023-01-18 03:58:10 --> Helper loaded: file_helper
INFO - 2023-01-18 03:58:10 --> Helper loaded: form_helper
INFO - 2023-01-18 03:58:10 --> Helper loaded: my_helper
INFO - 2023-01-18 03:58:10 --> Database Driver Class Initialized
DEBUG - 2023-01-18 03:58:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-01-18 03:58:10 --> Session: Class initialized using 'files' driver.
INFO - 2023-01-18 03:58:10 --> Controller Class Initialized
DEBUG - 2023-01-18 03:58:10 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/n_icb/views/list.php
DEBUG - 2023-01-18 03:58:10 --> File loaded: C:\xampp\htdocs\myraportk13\application\views\template_utama.php
INFO - 2023-01-18 03:58:10 --> Final output sent to browser
DEBUG - 2023-01-18 03:58:10 --> Total execution time: 0.0635
INFO - 2023-01-18 03:58:10 --> Config Class Initialized
INFO - 2023-01-18 03:58:10 --> Hooks Class Initialized
DEBUG - 2023-01-18 03:58:10 --> UTF-8 Support Enabled
INFO - 2023-01-18 03:58:10 --> Utf8 Class Initialized
INFO - 2023-01-18 03:58:10 --> URI Class Initialized
INFO - 2023-01-18 03:58:10 --> Router Class Initialized
INFO - 2023-01-18 03:58:10 --> Output Class Initialized
INFO - 2023-01-18 03:58:10 --> Security Class Initialized
DEBUG - 2023-01-18 03:58:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-18 03:58:10 --> Input Class Initialized
INFO - 2023-01-18 03:58:10 --> Language Class Initialized
INFO - 2023-01-18 03:58:10 --> Language Class Initialized
INFO - 2023-01-18 03:58:10 --> Config Class Initialized
INFO - 2023-01-18 03:58:10 --> Loader Class Initialized
INFO - 2023-01-18 03:58:10 --> Helper loaded: url_helper
INFO - 2023-01-18 03:58:10 --> Helper loaded: file_helper
INFO - 2023-01-18 03:58:10 --> Helper loaded: form_helper
INFO - 2023-01-18 03:58:10 --> Helper loaded: my_helper
INFO - 2023-01-18 03:58:10 --> Database Driver Class Initialized
DEBUG - 2023-01-18 03:58:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-01-18 03:58:10 --> Session: Class initialized using 'files' driver.
INFO - 2023-01-18 03:58:10 --> Controller Class Initialized
INFO - 2023-01-18 03:58:18 --> Config Class Initialized
INFO - 2023-01-18 03:58:18 --> Hooks Class Initialized
DEBUG - 2023-01-18 03:58:18 --> UTF-8 Support Enabled
INFO - 2023-01-18 03:58:18 --> Utf8 Class Initialized
INFO - 2023-01-18 03:58:18 --> URI Class Initialized
INFO - 2023-01-18 03:58:18 --> Router Class Initialized
INFO - 2023-01-18 03:58:18 --> Output Class Initialized
INFO - 2023-01-18 03:58:18 --> Security Class Initialized
DEBUG - 2023-01-18 03:58:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-18 03:58:18 --> Input Class Initialized
INFO - 2023-01-18 03:58:18 --> Language Class Initialized
INFO - 2023-01-18 03:58:18 --> Language Class Initialized
INFO - 2023-01-18 03:58:18 --> Config Class Initialized
INFO - 2023-01-18 03:58:18 --> Loader Class Initialized
INFO - 2023-01-18 03:58:18 --> Helper loaded: url_helper
INFO - 2023-01-18 03:58:18 --> Helper loaded: file_helper
INFO - 2023-01-18 03:58:18 --> Helper loaded: form_helper
INFO - 2023-01-18 03:58:18 --> Helper loaded: my_helper
INFO - 2023-01-18 03:58:18 --> Database Driver Class Initialized
DEBUG - 2023-01-18 03:58:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-01-18 03:58:18 --> Session: Class initialized using 'files' driver.
INFO - 2023-01-18 03:58:18 --> Controller Class Initialized
INFO - 2023-01-18 03:58:18 --> Final output sent to browser
DEBUG - 2023-01-18 03:58:18 --> Total execution time: 0.0262
INFO - 2023-01-18 03:58:34 --> Config Class Initialized
INFO - 2023-01-18 03:58:34 --> Hooks Class Initialized
DEBUG - 2023-01-18 03:58:34 --> UTF-8 Support Enabled
INFO - 2023-01-18 03:58:34 --> Utf8 Class Initialized
INFO - 2023-01-18 03:58:34 --> URI Class Initialized
INFO - 2023-01-18 03:58:34 --> Router Class Initialized
INFO - 2023-01-18 03:58:34 --> Output Class Initialized
INFO - 2023-01-18 03:58:34 --> Security Class Initialized
DEBUG - 2023-01-18 03:58:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-18 03:58:34 --> Input Class Initialized
INFO - 2023-01-18 03:58:34 --> Language Class Initialized
INFO - 2023-01-18 03:58:34 --> Language Class Initialized
INFO - 2023-01-18 03:58:34 --> Config Class Initialized
INFO - 2023-01-18 03:58:34 --> Loader Class Initialized
INFO - 2023-01-18 03:58:34 --> Helper loaded: url_helper
INFO - 2023-01-18 03:58:34 --> Helper loaded: file_helper
INFO - 2023-01-18 03:58:34 --> Helper loaded: form_helper
INFO - 2023-01-18 03:58:34 --> Helper loaded: my_helper
INFO - 2023-01-18 03:58:34 --> Database Driver Class Initialized
DEBUG - 2023-01-18 03:58:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-01-18 03:58:34 --> Session: Class initialized using 'files' driver.
INFO - 2023-01-18 03:58:34 --> Controller Class Initialized
INFO - 2023-01-18 03:58:34 --> Final output sent to browser
DEBUG - 2023-01-18 03:58:34 --> Total execution time: 0.0332
INFO - 2023-01-18 03:58:37 --> Config Class Initialized
INFO - 2023-01-18 03:58:37 --> Hooks Class Initialized
DEBUG - 2023-01-18 03:58:37 --> UTF-8 Support Enabled
INFO - 2023-01-18 03:58:37 --> Utf8 Class Initialized
INFO - 2023-01-18 03:58:37 --> URI Class Initialized
INFO - 2023-01-18 03:58:37 --> Router Class Initialized
INFO - 2023-01-18 03:58:37 --> Output Class Initialized
INFO - 2023-01-18 03:58:37 --> Security Class Initialized
DEBUG - 2023-01-18 03:58:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-18 03:58:37 --> Input Class Initialized
INFO - 2023-01-18 03:58:37 --> Language Class Initialized
INFO - 2023-01-18 03:58:37 --> Language Class Initialized
INFO - 2023-01-18 03:58:37 --> Config Class Initialized
INFO - 2023-01-18 03:58:37 --> Loader Class Initialized
INFO - 2023-01-18 03:58:37 --> Helper loaded: url_helper
INFO - 2023-01-18 03:58:37 --> Helper loaded: file_helper
INFO - 2023-01-18 03:58:37 --> Helper loaded: form_helper
INFO - 2023-01-18 03:58:37 --> Helper loaded: my_helper
INFO - 2023-01-18 03:58:37 --> Database Driver Class Initialized
DEBUG - 2023-01-18 03:58:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-01-18 03:58:37 --> Session: Class initialized using 'files' driver.
INFO - 2023-01-18 03:58:37 --> Controller Class Initialized
INFO - 2023-01-18 03:58:37 --> Final output sent to browser
DEBUG - 2023-01-18 03:58:37 --> Total execution time: 0.0316
INFO - 2023-01-18 03:58:38 --> Config Class Initialized
INFO - 2023-01-18 03:58:38 --> Hooks Class Initialized
DEBUG - 2023-01-18 03:58:38 --> UTF-8 Support Enabled
INFO - 2023-01-18 03:58:38 --> Utf8 Class Initialized
INFO - 2023-01-18 03:58:38 --> URI Class Initialized
INFO - 2023-01-18 03:58:38 --> Router Class Initialized
INFO - 2023-01-18 03:58:38 --> Output Class Initialized
INFO - 2023-01-18 03:58:38 --> Security Class Initialized
DEBUG - 2023-01-18 03:58:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-18 03:58:38 --> Input Class Initialized
INFO - 2023-01-18 03:58:38 --> Language Class Initialized
INFO - 2023-01-18 03:58:38 --> Language Class Initialized
INFO - 2023-01-18 03:58:38 --> Config Class Initialized
INFO - 2023-01-18 03:58:38 --> Loader Class Initialized
INFO - 2023-01-18 03:58:38 --> Helper loaded: url_helper
INFO - 2023-01-18 03:58:38 --> Helper loaded: file_helper
INFO - 2023-01-18 03:58:38 --> Helper loaded: form_helper
INFO - 2023-01-18 03:58:38 --> Helper loaded: my_helper
INFO - 2023-01-18 03:58:38 --> Database Driver Class Initialized
DEBUG - 2023-01-18 03:58:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-01-18 03:58:38 --> Session: Class initialized using 'files' driver.
INFO - 2023-01-18 03:58:38 --> Controller Class Initialized
INFO - 2023-01-18 03:58:38 --> Final output sent to browser
DEBUG - 2023-01-18 03:58:38 --> Total execution time: 0.0389
INFO - 2023-01-18 03:58:50 --> Config Class Initialized
INFO - 2023-01-18 03:58:50 --> Hooks Class Initialized
DEBUG - 2023-01-18 03:58:50 --> UTF-8 Support Enabled
INFO - 2023-01-18 03:58:50 --> Utf8 Class Initialized
INFO - 2023-01-18 03:58:50 --> URI Class Initialized
INFO - 2023-01-18 03:58:50 --> Router Class Initialized
INFO - 2023-01-18 03:58:50 --> Output Class Initialized
INFO - 2023-01-18 03:58:50 --> Security Class Initialized
DEBUG - 2023-01-18 03:58:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-18 03:58:50 --> Input Class Initialized
INFO - 2023-01-18 03:58:50 --> Language Class Initialized
INFO - 2023-01-18 03:58:50 --> Language Class Initialized
INFO - 2023-01-18 03:58:50 --> Config Class Initialized
INFO - 2023-01-18 03:58:50 --> Loader Class Initialized
INFO - 2023-01-18 03:58:50 --> Helper loaded: url_helper
INFO - 2023-01-18 03:58:50 --> Helper loaded: file_helper
INFO - 2023-01-18 03:58:50 --> Helper loaded: form_helper
INFO - 2023-01-18 03:58:50 --> Helper loaded: my_helper
INFO - 2023-01-18 03:58:50 --> Database Driver Class Initialized
DEBUG - 2023-01-18 03:58:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-01-18 03:58:50 --> Session: Class initialized using 'files' driver.
INFO - 2023-01-18 03:58:50 --> Controller Class Initialized
INFO - 2023-01-18 03:58:50 --> Final output sent to browser
DEBUG - 2023-01-18 03:58:50 --> Total execution time: 0.0279
INFO - 2023-01-18 03:58:59 --> Config Class Initialized
INFO - 2023-01-18 03:58:59 --> Hooks Class Initialized
DEBUG - 2023-01-18 03:58:59 --> UTF-8 Support Enabled
INFO - 2023-01-18 03:58:59 --> Utf8 Class Initialized
INFO - 2023-01-18 03:58:59 --> URI Class Initialized
INFO - 2023-01-18 03:58:59 --> Router Class Initialized
INFO - 2023-01-18 03:58:59 --> Output Class Initialized
INFO - 2023-01-18 03:58:59 --> Security Class Initialized
DEBUG - 2023-01-18 03:58:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-18 03:58:59 --> Input Class Initialized
INFO - 2023-01-18 03:58:59 --> Language Class Initialized
INFO - 2023-01-18 03:58:59 --> Language Class Initialized
INFO - 2023-01-18 03:58:59 --> Config Class Initialized
INFO - 2023-01-18 03:58:59 --> Loader Class Initialized
INFO - 2023-01-18 03:58:59 --> Helper loaded: url_helper
INFO - 2023-01-18 03:58:59 --> Helper loaded: file_helper
INFO - 2023-01-18 03:58:59 --> Helper loaded: form_helper
INFO - 2023-01-18 03:58:59 --> Helper loaded: my_helper
INFO - 2023-01-18 03:58:59 --> Database Driver Class Initialized
DEBUG - 2023-01-18 03:58:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-01-18 03:58:59 --> Session: Class initialized using 'files' driver.
INFO - 2023-01-18 03:58:59 --> Controller Class Initialized
INFO - 2023-01-18 03:58:59 --> Final output sent to browser
DEBUG - 2023-01-18 03:58:59 --> Total execution time: 0.0352
INFO - 2023-01-18 03:59:04 --> Config Class Initialized
INFO - 2023-01-18 03:59:04 --> Hooks Class Initialized
DEBUG - 2023-01-18 03:59:04 --> UTF-8 Support Enabled
INFO - 2023-01-18 03:59:04 --> Utf8 Class Initialized
INFO - 2023-01-18 03:59:04 --> URI Class Initialized
INFO - 2023-01-18 03:59:04 --> Router Class Initialized
INFO - 2023-01-18 03:59:04 --> Output Class Initialized
INFO - 2023-01-18 03:59:04 --> Security Class Initialized
DEBUG - 2023-01-18 03:59:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-18 03:59:04 --> Input Class Initialized
INFO - 2023-01-18 03:59:04 --> Language Class Initialized
INFO - 2023-01-18 03:59:04 --> Language Class Initialized
INFO - 2023-01-18 03:59:04 --> Config Class Initialized
INFO - 2023-01-18 03:59:04 --> Loader Class Initialized
INFO - 2023-01-18 03:59:04 --> Helper loaded: url_helper
INFO - 2023-01-18 03:59:04 --> Helper loaded: file_helper
INFO - 2023-01-18 03:59:04 --> Helper loaded: form_helper
INFO - 2023-01-18 03:59:04 --> Helper loaded: my_helper
INFO - 2023-01-18 03:59:04 --> Database Driver Class Initialized
DEBUG - 2023-01-18 03:59:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-01-18 03:59:04 --> Session: Class initialized using 'files' driver.
INFO - 2023-01-18 03:59:04 --> Controller Class Initialized
DEBUG - 2023-01-18 03:59:04 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/cetak_raport/views/cetak_mh.php
INFO - 2023-01-18 03:59:05 --> Final output sent to browser
DEBUG - 2023-01-18 03:59:05 --> Total execution time: 1.2737
INFO - 2023-01-18 03:59:28 --> Config Class Initialized
INFO - 2023-01-18 03:59:28 --> Hooks Class Initialized
DEBUG - 2023-01-18 03:59:28 --> UTF-8 Support Enabled
INFO - 2023-01-18 03:59:28 --> Utf8 Class Initialized
INFO - 2023-01-18 03:59:28 --> URI Class Initialized
INFO - 2023-01-18 03:59:28 --> Router Class Initialized
INFO - 2023-01-18 03:59:28 --> Output Class Initialized
INFO - 2023-01-18 03:59:28 --> Security Class Initialized
DEBUG - 2023-01-18 03:59:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-18 03:59:28 --> Input Class Initialized
INFO - 2023-01-18 03:59:28 --> Language Class Initialized
INFO - 2023-01-18 03:59:28 --> Language Class Initialized
INFO - 2023-01-18 03:59:28 --> Config Class Initialized
INFO - 2023-01-18 03:59:28 --> Loader Class Initialized
INFO - 2023-01-18 03:59:28 --> Helper loaded: url_helper
INFO - 2023-01-18 03:59:28 --> Helper loaded: file_helper
INFO - 2023-01-18 03:59:28 --> Helper loaded: form_helper
INFO - 2023-01-18 03:59:28 --> Helper loaded: my_helper
INFO - 2023-01-18 03:59:28 --> Database Driver Class Initialized
DEBUG - 2023-01-18 03:59:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-01-18 03:59:28 --> Session: Class initialized using 'files' driver.
INFO - 2023-01-18 03:59:28 --> Controller Class Initialized
INFO - 2023-01-18 03:59:53 --> Config Class Initialized
INFO - 2023-01-18 03:59:53 --> Hooks Class Initialized
DEBUG - 2023-01-18 03:59:53 --> UTF-8 Support Enabled
INFO - 2023-01-18 03:59:53 --> Utf8 Class Initialized
INFO - 2023-01-18 03:59:53 --> URI Class Initialized
INFO - 2023-01-18 03:59:53 --> Router Class Initialized
INFO - 2023-01-18 03:59:53 --> Output Class Initialized
INFO - 2023-01-18 03:59:53 --> Security Class Initialized
DEBUG - 2023-01-18 03:59:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-18 03:59:53 --> Input Class Initialized
INFO - 2023-01-18 03:59:53 --> Language Class Initialized
INFO - 2023-01-18 03:59:53 --> Language Class Initialized
INFO - 2023-01-18 03:59:53 --> Config Class Initialized
INFO - 2023-01-18 03:59:53 --> Loader Class Initialized
INFO - 2023-01-18 03:59:53 --> Helper loaded: url_helper
INFO - 2023-01-18 03:59:53 --> Helper loaded: file_helper
INFO - 2023-01-18 03:59:53 --> Helper loaded: form_helper
INFO - 2023-01-18 03:59:53 --> Helper loaded: my_helper
INFO - 2023-01-18 03:59:53 --> Database Driver Class Initialized
DEBUG - 2023-01-18 03:59:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-01-18 03:59:53 --> Session: Class initialized using 'files' driver.
INFO - 2023-01-18 03:59:53 --> Controller Class Initialized
INFO - 2023-01-18 03:59:53 --> Final output sent to browser
DEBUG - 2023-01-18 03:59:53 --> Total execution time: 0.0676
INFO - 2023-01-18 03:59:56 --> Config Class Initialized
INFO - 2023-01-18 03:59:56 --> Hooks Class Initialized
DEBUG - 2023-01-18 03:59:56 --> UTF-8 Support Enabled
INFO - 2023-01-18 03:59:56 --> Utf8 Class Initialized
INFO - 2023-01-18 03:59:56 --> URI Class Initialized
INFO - 2023-01-18 03:59:56 --> Router Class Initialized
INFO - 2023-01-18 03:59:56 --> Output Class Initialized
INFO - 2023-01-18 03:59:56 --> Security Class Initialized
DEBUG - 2023-01-18 03:59:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-18 03:59:56 --> Input Class Initialized
INFO - 2023-01-18 03:59:56 --> Language Class Initialized
INFO - 2023-01-18 03:59:56 --> Language Class Initialized
INFO - 2023-01-18 03:59:56 --> Config Class Initialized
INFO - 2023-01-18 03:59:56 --> Loader Class Initialized
INFO - 2023-01-18 03:59:56 --> Helper loaded: url_helper
INFO - 2023-01-18 03:59:56 --> Helper loaded: file_helper
INFO - 2023-01-18 03:59:56 --> Helper loaded: form_helper
INFO - 2023-01-18 03:59:56 --> Helper loaded: my_helper
INFO - 2023-01-18 03:59:56 --> Database Driver Class Initialized
DEBUG - 2023-01-18 03:59:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-01-18 03:59:56 --> Session: Class initialized using 'files' driver.
INFO - 2023-01-18 03:59:56 --> Controller Class Initialized
INFO - 2023-01-18 03:59:56 --> Final output sent to browser
DEBUG - 2023-01-18 03:59:56 --> Total execution time: 0.0354
INFO - 2023-01-18 04:00:27 --> Config Class Initialized
INFO - 2023-01-18 04:00:27 --> Hooks Class Initialized
DEBUG - 2023-01-18 04:00:27 --> UTF-8 Support Enabled
INFO - 2023-01-18 04:00:27 --> Utf8 Class Initialized
INFO - 2023-01-18 04:00:27 --> URI Class Initialized
INFO - 2023-01-18 04:00:27 --> Router Class Initialized
INFO - 2023-01-18 04:00:27 --> Output Class Initialized
INFO - 2023-01-18 04:00:27 --> Security Class Initialized
DEBUG - 2023-01-18 04:00:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-18 04:00:27 --> Input Class Initialized
INFO - 2023-01-18 04:00:27 --> Language Class Initialized
INFO - 2023-01-18 04:00:27 --> Language Class Initialized
INFO - 2023-01-18 04:00:27 --> Config Class Initialized
INFO - 2023-01-18 04:00:27 --> Loader Class Initialized
INFO - 2023-01-18 04:00:27 --> Helper loaded: url_helper
INFO - 2023-01-18 04:00:27 --> Helper loaded: file_helper
INFO - 2023-01-18 04:00:27 --> Helper loaded: form_helper
INFO - 2023-01-18 04:00:27 --> Helper loaded: my_helper
INFO - 2023-01-18 04:00:27 --> Database Driver Class Initialized
DEBUG - 2023-01-18 04:00:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-01-18 04:00:27 --> Session: Class initialized using 'files' driver.
INFO - 2023-01-18 04:00:27 --> Controller Class Initialized
DEBUG - 2023-01-18 04:00:27 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/cetak_raport/views/cetak_mh.php
INFO - 2023-01-18 04:00:29 --> Final output sent to browser
DEBUG - 2023-01-18 04:00:29 --> Total execution time: 1.3156
INFO - 2023-01-18 04:00:41 --> Config Class Initialized
INFO - 2023-01-18 04:00:41 --> Hooks Class Initialized
DEBUG - 2023-01-18 04:00:41 --> UTF-8 Support Enabled
INFO - 2023-01-18 04:00:41 --> Utf8 Class Initialized
INFO - 2023-01-18 04:00:41 --> URI Class Initialized
INFO - 2023-01-18 04:00:41 --> Router Class Initialized
INFO - 2023-01-18 04:00:41 --> Output Class Initialized
INFO - 2023-01-18 04:00:41 --> Security Class Initialized
DEBUG - 2023-01-18 04:00:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-18 04:00:41 --> Input Class Initialized
INFO - 2023-01-18 04:00:41 --> Language Class Initialized
INFO - 2023-01-18 04:00:41 --> Language Class Initialized
INFO - 2023-01-18 04:00:41 --> Config Class Initialized
INFO - 2023-01-18 04:00:41 --> Loader Class Initialized
INFO - 2023-01-18 04:00:41 --> Helper loaded: url_helper
INFO - 2023-01-18 04:00:41 --> Helper loaded: file_helper
INFO - 2023-01-18 04:00:41 --> Helper loaded: form_helper
INFO - 2023-01-18 04:00:41 --> Helper loaded: my_helper
INFO - 2023-01-18 04:00:41 --> Database Driver Class Initialized
DEBUG - 2023-01-18 04:00:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-01-18 04:00:41 --> Session: Class initialized using 'files' driver.
INFO - 2023-01-18 04:00:41 --> Controller Class Initialized
DEBUG - 2023-01-18 04:00:41 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/n_catatan/views/list.php
DEBUG - 2023-01-18 04:00:41 --> File loaded: C:\xampp\htdocs\myraportk13\application\views\template_utama.php
INFO - 2023-01-18 04:00:41 --> Final output sent to browser
DEBUG - 2023-01-18 04:00:41 --> Total execution time: 0.0956
INFO - 2023-01-18 04:00:43 --> Config Class Initialized
INFO - 2023-01-18 04:00:43 --> Hooks Class Initialized
DEBUG - 2023-01-18 04:00:43 --> UTF-8 Support Enabled
INFO - 2023-01-18 04:00:43 --> Utf8 Class Initialized
INFO - 2023-01-18 04:00:43 --> URI Class Initialized
INFO - 2023-01-18 04:00:43 --> Router Class Initialized
INFO - 2023-01-18 04:00:43 --> Output Class Initialized
INFO - 2023-01-18 04:00:43 --> Security Class Initialized
DEBUG - 2023-01-18 04:00:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-18 04:00:43 --> Input Class Initialized
INFO - 2023-01-18 04:00:43 --> Language Class Initialized
INFO - 2023-01-18 04:00:43 --> Language Class Initialized
INFO - 2023-01-18 04:00:43 --> Config Class Initialized
INFO - 2023-01-18 04:00:43 --> Loader Class Initialized
INFO - 2023-01-18 04:00:43 --> Helper loaded: url_helper
INFO - 2023-01-18 04:00:43 --> Helper loaded: file_helper
INFO - 2023-01-18 04:00:43 --> Helper loaded: form_helper
INFO - 2023-01-18 04:00:43 --> Helper loaded: my_helper
INFO - 2023-01-18 04:00:43 --> Database Driver Class Initialized
DEBUG - 2023-01-18 04:00:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-01-18 04:00:43 --> Session: Class initialized using 'files' driver.
INFO - 2023-01-18 04:00:43 --> Controller Class Initialized
DEBUG - 2023-01-18 04:00:43 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/n_ekstra/views/list.php
DEBUG - 2023-01-18 04:00:43 --> File loaded: C:\xampp\htdocs\myraportk13\application\views\template_utama.php
INFO - 2023-01-18 04:00:43 --> Final output sent to browser
DEBUG - 2023-01-18 04:00:43 --> Total execution time: 0.1074
INFO - 2023-01-18 04:00:44 --> Config Class Initialized
INFO - 2023-01-18 04:00:44 --> Hooks Class Initialized
DEBUG - 2023-01-18 04:00:44 --> UTF-8 Support Enabled
INFO - 2023-01-18 04:00:44 --> Utf8 Class Initialized
INFO - 2023-01-18 04:00:44 --> URI Class Initialized
INFO - 2023-01-18 04:00:44 --> Router Class Initialized
INFO - 2023-01-18 04:00:44 --> Output Class Initialized
INFO - 2023-01-18 04:00:44 --> Security Class Initialized
DEBUG - 2023-01-18 04:00:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-18 04:00:44 --> Input Class Initialized
INFO - 2023-01-18 04:00:44 --> Language Class Initialized
INFO - 2023-01-18 04:00:44 --> Language Class Initialized
INFO - 2023-01-18 04:00:44 --> Config Class Initialized
INFO - 2023-01-18 04:00:44 --> Loader Class Initialized
INFO - 2023-01-18 04:00:44 --> Helper loaded: url_helper
INFO - 2023-01-18 04:00:44 --> Helper loaded: file_helper
INFO - 2023-01-18 04:00:44 --> Helper loaded: form_helper
INFO - 2023-01-18 04:00:44 --> Helper loaded: my_helper
INFO - 2023-01-18 04:00:44 --> Database Driver Class Initialized
DEBUG - 2023-01-18 04:00:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-01-18 04:00:44 --> Session: Class initialized using 'files' driver.
INFO - 2023-01-18 04:00:44 --> Controller Class Initialized
DEBUG - 2023-01-18 04:00:44 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/riwayat_mengajar/views/list.php
DEBUG - 2023-01-18 04:00:44 --> File loaded: C:\xampp\htdocs\myraportk13\application\views\template_utama.php
INFO - 2023-01-18 04:00:44 --> Final output sent to browser
DEBUG - 2023-01-18 04:00:44 --> Total execution time: 0.0659
INFO - 2023-01-18 04:00:44 --> Config Class Initialized
INFO - 2023-01-18 04:00:44 --> Hooks Class Initialized
DEBUG - 2023-01-18 04:00:44 --> UTF-8 Support Enabled
INFO - 2023-01-18 04:00:44 --> Utf8 Class Initialized
INFO - 2023-01-18 04:00:44 --> URI Class Initialized
INFO - 2023-01-18 04:00:44 --> Router Class Initialized
INFO - 2023-01-18 04:00:44 --> Output Class Initialized
INFO - 2023-01-18 04:00:44 --> Security Class Initialized
DEBUG - 2023-01-18 04:00:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-18 04:00:44 --> Input Class Initialized
INFO - 2023-01-18 04:00:44 --> Language Class Initialized
INFO - 2023-01-18 04:00:44 --> Language Class Initialized
INFO - 2023-01-18 04:00:44 --> Config Class Initialized
INFO - 2023-01-18 04:00:44 --> Loader Class Initialized
INFO - 2023-01-18 04:00:44 --> Helper loaded: url_helper
INFO - 2023-01-18 04:00:44 --> Helper loaded: file_helper
INFO - 2023-01-18 04:00:44 --> Helper loaded: form_helper
INFO - 2023-01-18 04:00:44 --> Helper loaded: my_helper
INFO - 2023-01-18 04:00:44 --> Database Driver Class Initialized
DEBUG - 2023-01-18 04:00:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-01-18 04:00:44 --> Session: Class initialized using 'files' driver.
INFO - 2023-01-18 04:00:44 --> Controller Class Initialized
DEBUG - 2023-01-18 04:00:44 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/view_mapel/views/v_view_mapel.php
DEBUG - 2023-01-18 04:00:44 --> File loaded: C:\xampp\htdocs\myraportk13\application\views\template_utama.php
INFO - 2023-01-18 04:00:44 --> Final output sent to browser
DEBUG - 2023-01-18 04:00:44 --> Total execution time: 0.0301
INFO - 2023-01-18 04:00:46 --> Config Class Initialized
INFO - 2023-01-18 04:00:46 --> Hooks Class Initialized
DEBUG - 2023-01-18 04:00:46 --> UTF-8 Support Enabled
INFO - 2023-01-18 04:00:46 --> Utf8 Class Initialized
INFO - 2023-01-18 04:00:46 --> URI Class Initialized
INFO - 2023-01-18 04:00:46 --> Router Class Initialized
INFO - 2023-01-18 04:00:46 --> Output Class Initialized
INFO - 2023-01-18 04:00:46 --> Security Class Initialized
DEBUG - 2023-01-18 04:00:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-18 04:00:46 --> Input Class Initialized
INFO - 2023-01-18 04:00:46 --> Language Class Initialized
INFO - 2023-01-18 04:00:46 --> Language Class Initialized
INFO - 2023-01-18 04:00:46 --> Config Class Initialized
INFO - 2023-01-18 04:00:46 --> Loader Class Initialized
INFO - 2023-01-18 04:00:46 --> Helper loaded: url_helper
INFO - 2023-01-18 04:00:46 --> Helper loaded: file_helper
INFO - 2023-01-18 04:00:46 --> Helper loaded: form_helper
INFO - 2023-01-18 04:00:46 --> Helper loaded: my_helper
INFO - 2023-01-18 04:00:46 --> Database Driver Class Initialized
DEBUG - 2023-01-18 04:00:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-01-18 04:00:46 --> Session: Class initialized using 'files' driver.
INFO - 2023-01-18 04:00:46 --> Controller Class Initialized
DEBUG - 2023-01-18 04:00:46 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/n_pss/views/list.php
DEBUG - 2023-01-18 04:00:46 --> File loaded: C:\xampp\htdocs\myraportk13\application\views\template_utama.php
INFO - 2023-01-18 04:00:46 --> Final output sent to browser
DEBUG - 2023-01-18 04:00:46 --> Total execution time: 0.0661
INFO - 2023-01-18 04:00:46 --> Config Class Initialized
INFO - 2023-01-18 04:00:46 --> Hooks Class Initialized
DEBUG - 2023-01-18 04:00:46 --> UTF-8 Support Enabled
INFO - 2023-01-18 04:00:46 --> Utf8 Class Initialized
INFO - 2023-01-18 04:00:46 --> URI Class Initialized
INFO - 2023-01-18 04:00:46 --> Router Class Initialized
INFO - 2023-01-18 04:00:46 --> Output Class Initialized
INFO - 2023-01-18 04:00:46 --> Security Class Initialized
DEBUG - 2023-01-18 04:00:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-18 04:00:46 --> Input Class Initialized
INFO - 2023-01-18 04:00:46 --> Language Class Initialized
INFO - 2023-01-18 04:00:46 --> Language Class Initialized
INFO - 2023-01-18 04:00:46 --> Config Class Initialized
INFO - 2023-01-18 04:00:46 --> Loader Class Initialized
INFO - 2023-01-18 04:00:46 --> Helper loaded: url_helper
INFO - 2023-01-18 04:00:46 --> Helper loaded: file_helper
INFO - 2023-01-18 04:00:46 --> Helper loaded: form_helper
INFO - 2023-01-18 04:00:46 --> Helper loaded: my_helper
INFO - 2023-01-18 04:00:46 --> Database Driver Class Initialized
DEBUG - 2023-01-18 04:00:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-01-18 04:00:46 --> Session: Class initialized using 'files' driver.
INFO - 2023-01-18 04:00:46 --> Controller Class Initialized
INFO - 2023-01-18 04:01:09 --> Config Class Initialized
INFO - 2023-01-18 04:01:09 --> Hooks Class Initialized
DEBUG - 2023-01-18 04:01:09 --> UTF-8 Support Enabled
INFO - 2023-01-18 04:01:09 --> Utf8 Class Initialized
INFO - 2023-01-18 04:01:09 --> URI Class Initialized
INFO - 2023-01-18 04:01:09 --> Router Class Initialized
INFO - 2023-01-18 04:01:09 --> Output Class Initialized
INFO - 2023-01-18 04:01:09 --> Security Class Initialized
DEBUG - 2023-01-18 04:01:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-18 04:01:09 --> Input Class Initialized
INFO - 2023-01-18 04:01:09 --> Language Class Initialized
INFO - 2023-01-18 04:01:09 --> Language Class Initialized
INFO - 2023-01-18 04:01:09 --> Config Class Initialized
INFO - 2023-01-18 04:01:09 --> Loader Class Initialized
INFO - 2023-01-18 04:01:09 --> Helper loaded: url_helper
INFO - 2023-01-18 04:01:09 --> Helper loaded: file_helper
INFO - 2023-01-18 04:01:09 --> Helper loaded: form_helper
INFO - 2023-01-18 04:01:09 --> Helper loaded: my_helper
INFO - 2023-01-18 04:01:09 --> Database Driver Class Initialized
DEBUG - 2023-01-18 04:01:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-01-18 04:01:09 --> Session: Class initialized using 'files' driver.
INFO - 2023-01-18 04:01:09 --> Controller Class Initialized
DEBUG - 2023-01-18 04:01:09 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/n_ekstra/views/list.php
DEBUG - 2023-01-18 04:01:09 --> File loaded: C:\xampp\htdocs\myraportk13\application\views\template_utama.php
INFO - 2023-01-18 04:01:09 --> Final output sent to browser
DEBUG - 2023-01-18 04:01:09 --> Total execution time: 0.0366
INFO - 2023-01-18 04:01:16 --> Config Class Initialized
INFO - 2023-01-18 04:01:16 --> Hooks Class Initialized
DEBUG - 2023-01-18 04:01:16 --> UTF-8 Support Enabled
INFO - 2023-01-18 04:01:16 --> Utf8 Class Initialized
INFO - 2023-01-18 04:01:16 --> URI Class Initialized
INFO - 2023-01-18 04:01:16 --> Router Class Initialized
INFO - 2023-01-18 04:01:16 --> Output Class Initialized
INFO - 2023-01-18 04:01:16 --> Security Class Initialized
DEBUG - 2023-01-18 04:01:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-18 04:01:16 --> Input Class Initialized
INFO - 2023-01-18 04:01:16 --> Language Class Initialized
INFO - 2023-01-18 04:01:16 --> Language Class Initialized
INFO - 2023-01-18 04:01:16 --> Config Class Initialized
INFO - 2023-01-18 04:01:16 --> Loader Class Initialized
INFO - 2023-01-18 04:01:16 --> Helper loaded: url_helper
INFO - 2023-01-18 04:01:16 --> Helper loaded: file_helper
INFO - 2023-01-18 04:01:16 --> Helper loaded: form_helper
INFO - 2023-01-18 04:01:16 --> Helper loaded: my_helper
INFO - 2023-01-18 04:01:16 --> Database Driver Class Initialized
DEBUG - 2023-01-18 04:01:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-01-18 04:01:16 --> Session: Class initialized using 'files' driver.
INFO - 2023-01-18 04:01:16 --> Controller Class Initialized
DEBUG - 2023-01-18 04:01:16 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/cetak_raport/views/list.php
DEBUG - 2023-01-18 04:01:16 --> File loaded: C:\xampp\htdocs\myraportk13\application\views\template_utama.php
INFO - 2023-01-18 04:01:16 --> Final output sent to browser
DEBUG - 2023-01-18 04:01:16 --> Total execution time: 0.0402
INFO - 2023-01-18 04:01:19 --> Config Class Initialized
INFO - 2023-01-18 04:01:19 --> Hooks Class Initialized
DEBUG - 2023-01-18 04:01:19 --> UTF-8 Support Enabled
INFO - 2023-01-18 04:01:19 --> Utf8 Class Initialized
INFO - 2023-01-18 04:01:19 --> URI Class Initialized
INFO - 2023-01-18 04:01:19 --> Router Class Initialized
INFO - 2023-01-18 04:01:19 --> Output Class Initialized
INFO - 2023-01-18 04:01:19 --> Security Class Initialized
DEBUG - 2023-01-18 04:01:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-18 04:01:19 --> Input Class Initialized
INFO - 2023-01-18 04:01:19 --> Language Class Initialized
INFO - 2023-01-18 04:01:19 --> Language Class Initialized
INFO - 2023-01-18 04:01:19 --> Config Class Initialized
INFO - 2023-01-18 04:01:19 --> Loader Class Initialized
INFO - 2023-01-18 04:01:19 --> Helper loaded: url_helper
INFO - 2023-01-18 04:01:19 --> Helper loaded: file_helper
INFO - 2023-01-18 04:01:19 --> Helper loaded: form_helper
INFO - 2023-01-18 04:01:19 --> Helper loaded: my_helper
INFO - 2023-01-18 04:01:19 --> Database Driver Class Initialized
DEBUG - 2023-01-18 04:01:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-01-18 04:01:19 --> Session: Class initialized using 'files' driver.
INFO - 2023-01-18 04:01:19 --> Controller Class Initialized
DEBUG - 2023-01-18 04:01:19 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/cetak_raport/views/cetak_rapot.php
INFO - 2023-01-18 04:01:20 --> Final output sent to browser
DEBUG - 2023-01-18 04:01:20 --> Total execution time: 1.2999
INFO - 2023-01-18 04:02:34 --> Config Class Initialized
INFO - 2023-01-18 04:02:34 --> Hooks Class Initialized
DEBUG - 2023-01-18 04:02:34 --> UTF-8 Support Enabled
INFO - 2023-01-18 04:02:34 --> Utf8 Class Initialized
INFO - 2023-01-18 04:02:34 --> URI Class Initialized
INFO - 2023-01-18 04:02:34 --> Router Class Initialized
INFO - 2023-01-18 04:02:34 --> Output Class Initialized
INFO - 2023-01-18 04:02:34 --> Security Class Initialized
DEBUG - 2023-01-18 04:02:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-18 04:02:34 --> Input Class Initialized
INFO - 2023-01-18 04:02:34 --> Language Class Initialized
INFO - 2023-01-18 04:02:34 --> Language Class Initialized
INFO - 2023-01-18 04:02:34 --> Config Class Initialized
INFO - 2023-01-18 04:02:34 --> Loader Class Initialized
INFO - 2023-01-18 04:02:34 --> Helper loaded: url_helper
INFO - 2023-01-18 04:02:34 --> Helper loaded: file_helper
INFO - 2023-01-18 04:02:34 --> Helper loaded: form_helper
INFO - 2023-01-18 04:02:34 --> Helper loaded: my_helper
INFO - 2023-01-18 04:02:34 --> Database Driver Class Initialized
DEBUG - 2023-01-18 04:02:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-01-18 04:02:34 --> Session: Class initialized using 'files' driver.
INFO - 2023-01-18 04:02:34 --> Controller Class Initialized
DEBUG - 2023-01-18 04:02:34 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/n_ekstra/views/list.php
DEBUG - 2023-01-18 04:02:34 --> File loaded: C:\xampp\htdocs\myraportk13\application\views\template_utama.php
INFO - 2023-01-18 04:02:34 --> Final output sent to browser
DEBUG - 2023-01-18 04:02:34 --> Total execution time: 0.0419
INFO - 2023-01-18 04:02:35 --> Config Class Initialized
INFO - 2023-01-18 04:02:35 --> Hooks Class Initialized
DEBUG - 2023-01-18 04:02:35 --> UTF-8 Support Enabled
INFO - 2023-01-18 04:02:35 --> Utf8 Class Initialized
INFO - 2023-01-18 04:02:35 --> URI Class Initialized
INFO - 2023-01-18 04:02:35 --> Router Class Initialized
INFO - 2023-01-18 04:02:35 --> Output Class Initialized
INFO - 2023-01-18 04:02:35 --> Security Class Initialized
DEBUG - 2023-01-18 04:02:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-18 04:02:35 --> Input Class Initialized
INFO - 2023-01-18 04:02:35 --> Language Class Initialized
INFO - 2023-01-18 04:02:35 --> Language Class Initialized
INFO - 2023-01-18 04:02:35 --> Config Class Initialized
INFO - 2023-01-18 04:02:35 --> Loader Class Initialized
INFO - 2023-01-18 04:02:35 --> Helper loaded: url_helper
INFO - 2023-01-18 04:02:35 --> Helper loaded: file_helper
INFO - 2023-01-18 04:02:35 --> Helper loaded: form_helper
INFO - 2023-01-18 04:02:35 --> Helper loaded: my_helper
INFO - 2023-01-18 04:02:35 --> Database Driver Class Initialized
DEBUG - 2023-01-18 04:02:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-01-18 04:02:35 --> Session: Class initialized using 'files' driver.
INFO - 2023-01-18 04:02:35 --> Controller Class Initialized
INFO - 2023-01-18 04:02:35 --> Final output sent to browser
DEBUG - 2023-01-18 04:02:35 --> Total execution time: 0.0302
INFO - 2023-01-18 04:03:57 --> Config Class Initialized
INFO - 2023-01-18 04:03:57 --> Hooks Class Initialized
DEBUG - 2023-01-18 04:03:57 --> UTF-8 Support Enabled
INFO - 2023-01-18 04:03:57 --> Utf8 Class Initialized
INFO - 2023-01-18 04:03:57 --> URI Class Initialized
INFO - 2023-01-18 04:03:57 --> Router Class Initialized
INFO - 2023-01-18 04:03:57 --> Output Class Initialized
INFO - 2023-01-18 04:03:57 --> Security Class Initialized
DEBUG - 2023-01-18 04:03:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-18 04:03:57 --> Input Class Initialized
INFO - 2023-01-18 04:03:57 --> Language Class Initialized
INFO - 2023-01-18 04:03:57 --> Language Class Initialized
INFO - 2023-01-18 04:03:57 --> Config Class Initialized
INFO - 2023-01-18 04:03:57 --> Loader Class Initialized
INFO - 2023-01-18 04:03:57 --> Helper loaded: url_helper
INFO - 2023-01-18 04:03:57 --> Helper loaded: file_helper
INFO - 2023-01-18 04:03:57 --> Helper loaded: form_helper
INFO - 2023-01-18 04:03:57 --> Helper loaded: my_helper
INFO - 2023-01-18 04:03:57 --> Database Driver Class Initialized
DEBUG - 2023-01-18 04:03:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-01-18 04:03:57 --> Session: Class initialized using 'files' driver.
INFO - 2023-01-18 04:03:57 --> Controller Class Initialized
INFO - 2023-01-18 04:03:57 --> Helper loaded: cookie_helper
INFO - 2023-01-18 04:03:57 --> Config Class Initialized
INFO - 2023-01-18 04:03:57 --> Hooks Class Initialized
DEBUG - 2023-01-18 04:03:57 --> UTF-8 Support Enabled
INFO - 2023-01-18 04:03:57 --> Utf8 Class Initialized
INFO - 2023-01-18 04:03:57 --> URI Class Initialized
INFO - 2023-01-18 04:03:57 --> Router Class Initialized
INFO - 2023-01-18 04:03:57 --> Output Class Initialized
INFO - 2023-01-18 04:03:57 --> Security Class Initialized
DEBUG - 2023-01-18 04:03:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-18 04:03:57 --> Input Class Initialized
INFO - 2023-01-18 04:03:57 --> Language Class Initialized
INFO - 2023-01-18 04:03:57 --> Language Class Initialized
INFO - 2023-01-18 04:03:57 --> Config Class Initialized
INFO - 2023-01-18 04:03:57 --> Loader Class Initialized
INFO - 2023-01-18 04:03:57 --> Helper loaded: url_helper
INFO - 2023-01-18 04:03:57 --> Helper loaded: file_helper
INFO - 2023-01-18 04:03:57 --> Helper loaded: form_helper
INFO - 2023-01-18 04:03:57 --> Helper loaded: my_helper
INFO - 2023-01-18 04:03:57 --> Database Driver Class Initialized
DEBUG - 2023-01-18 04:03:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-01-18 04:03:57 --> Session: Class initialized using 'files' driver.
INFO - 2023-01-18 04:03:57 --> Controller Class Initialized
INFO - 2023-01-18 04:03:57 --> Config Class Initialized
INFO - 2023-01-18 04:03:57 --> Hooks Class Initialized
DEBUG - 2023-01-18 04:03:57 --> UTF-8 Support Enabled
INFO - 2023-01-18 04:03:57 --> Utf8 Class Initialized
INFO - 2023-01-18 04:03:57 --> URI Class Initialized
INFO - 2023-01-18 04:03:57 --> Router Class Initialized
INFO - 2023-01-18 04:03:57 --> Output Class Initialized
INFO - 2023-01-18 04:03:57 --> Security Class Initialized
DEBUG - 2023-01-18 04:03:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-18 04:03:57 --> Input Class Initialized
INFO - 2023-01-18 04:03:57 --> Language Class Initialized
INFO - 2023-01-18 04:03:57 --> Language Class Initialized
INFO - 2023-01-18 04:03:57 --> Config Class Initialized
INFO - 2023-01-18 04:03:57 --> Loader Class Initialized
INFO - 2023-01-18 04:03:57 --> Helper loaded: url_helper
INFO - 2023-01-18 04:03:57 --> Helper loaded: file_helper
INFO - 2023-01-18 04:03:57 --> Helper loaded: form_helper
INFO - 2023-01-18 04:03:57 --> Helper loaded: my_helper
INFO - 2023-01-18 04:03:57 --> Database Driver Class Initialized
DEBUG - 2023-01-18 04:03:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-01-18 04:03:57 --> Session: Class initialized using 'files' driver.
INFO - 2023-01-18 04:03:57 --> Controller Class Initialized
DEBUG - 2023-01-18 04:03:57 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/login/views/login.php
DEBUG - 2023-01-18 04:03:57 --> File loaded: C:\xampp\htdocs\myraportk13\application\views\template_utama.php
INFO - 2023-01-18 04:03:57 --> Final output sent to browser
DEBUG - 2023-01-18 04:03:57 --> Total execution time: 0.0309
INFO - 2023-01-18 04:04:01 --> Config Class Initialized
INFO - 2023-01-18 04:04:01 --> Hooks Class Initialized
DEBUG - 2023-01-18 04:04:01 --> UTF-8 Support Enabled
INFO - 2023-01-18 04:04:01 --> Utf8 Class Initialized
INFO - 2023-01-18 04:04:01 --> URI Class Initialized
INFO - 2023-01-18 04:04:01 --> Router Class Initialized
INFO - 2023-01-18 04:04:01 --> Output Class Initialized
INFO - 2023-01-18 04:04:01 --> Security Class Initialized
DEBUG - 2023-01-18 04:04:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-18 04:04:01 --> Input Class Initialized
INFO - 2023-01-18 04:04:01 --> Language Class Initialized
INFO - 2023-01-18 04:04:01 --> Language Class Initialized
INFO - 2023-01-18 04:04:01 --> Config Class Initialized
INFO - 2023-01-18 04:04:01 --> Loader Class Initialized
INFO - 2023-01-18 04:04:01 --> Helper loaded: url_helper
INFO - 2023-01-18 04:04:01 --> Helper loaded: file_helper
INFO - 2023-01-18 04:04:01 --> Helper loaded: form_helper
INFO - 2023-01-18 04:04:01 --> Helper loaded: my_helper
INFO - 2023-01-18 04:04:01 --> Database Driver Class Initialized
DEBUG - 2023-01-18 04:04:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-01-18 04:04:01 --> Session: Class initialized using 'files' driver.
INFO - 2023-01-18 04:04:01 --> Controller Class Initialized
INFO - 2023-01-18 04:04:01 --> Helper loaded: cookie_helper
INFO - 2023-01-18 04:04:01 --> Final output sent to browser
DEBUG - 2023-01-18 04:04:01 --> Total execution time: 0.0285
INFO - 2023-01-18 04:04:01 --> Config Class Initialized
INFO - 2023-01-18 04:04:01 --> Hooks Class Initialized
DEBUG - 2023-01-18 04:04:01 --> UTF-8 Support Enabled
INFO - 2023-01-18 04:04:01 --> Utf8 Class Initialized
INFO - 2023-01-18 04:04:01 --> URI Class Initialized
INFO - 2023-01-18 04:04:01 --> Router Class Initialized
INFO - 2023-01-18 04:04:01 --> Output Class Initialized
INFO - 2023-01-18 04:04:01 --> Security Class Initialized
DEBUG - 2023-01-18 04:04:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-18 04:04:01 --> Input Class Initialized
INFO - 2023-01-18 04:04:01 --> Language Class Initialized
INFO - 2023-01-18 04:04:01 --> Language Class Initialized
INFO - 2023-01-18 04:04:01 --> Config Class Initialized
INFO - 2023-01-18 04:04:01 --> Loader Class Initialized
INFO - 2023-01-18 04:04:01 --> Helper loaded: url_helper
INFO - 2023-01-18 04:04:01 --> Helper loaded: file_helper
INFO - 2023-01-18 04:04:01 --> Helper loaded: form_helper
INFO - 2023-01-18 04:04:01 --> Helper loaded: my_helper
INFO - 2023-01-18 04:04:01 --> Database Driver Class Initialized
DEBUG - 2023-01-18 04:04:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-01-18 04:04:01 --> Session: Class initialized using 'files' driver.
INFO - 2023-01-18 04:04:01 --> Controller Class Initialized
DEBUG - 2023-01-18 04:04:01 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/home/views/v_home.php
DEBUG - 2023-01-18 04:04:01 --> File loaded: C:\xampp\htdocs\myraportk13\application\views\template_utama.php
INFO - 2023-01-18 04:04:01 --> Final output sent to browser
DEBUG - 2023-01-18 04:04:01 --> Total execution time: 0.0476
INFO - 2023-01-18 04:04:04 --> Config Class Initialized
INFO - 2023-01-18 04:04:04 --> Hooks Class Initialized
DEBUG - 2023-01-18 04:04:04 --> UTF-8 Support Enabled
INFO - 2023-01-18 04:04:04 --> Utf8 Class Initialized
INFO - 2023-01-18 04:04:04 --> URI Class Initialized
INFO - 2023-01-18 04:04:04 --> Router Class Initialized
INFO - 2023-01-18 04:04:04 --> Output Class Initialized
INFO - 2023-01-18 04:04:04 --> Security Class Initialized
DEBUG - 2023-01-18 04:04:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-18 04:04:04 --> Input Class Initialized
INFO - 2023-01-18 04:04:04 --> Language Class Initialized
INFO - 2023-01-18 04:04:04 --> Language Class Initialized
INFO - 2023-01-18 04:04:04 --> Config Class Initialized
INFO - 2023-01-18 04:04:04 --> Loader Class Initialized
INFO - 2023-01-18 04:04:04 --> Helper loaded: url_helper
INFO - 2023-01-18 04:04:04 --> Helper loaded: file_helper
INFO - 2023-01-18 04:04:04 --> Helper loaded: form_helper
INFO - 2023-01-18 04:04:04 --> Helper loaded: my_helper
INFO - 2023-01-18 04:04:04 --> Database Driver Class Initialized
DEBUG - 2023-01-18 04:04:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-01-18 04:04:04 --> Session: Class initialized using 'files' driver.
INFO - 2023-01-18 04:04:04 --> Controller Class Initialized
DEBUG - 2023-01-18 04:04:04 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/data_guru/views/list.php
DEBUG - 2023-01-18 04:04:04 --> File loaded: C:\xampp\htdocs\myraportk13\application\views\template_utama.php
INFO - 2023-01-18 04:04:04 --> Final output sent to browser
DEBUG - 2023-01-18 04:04:04 --> Total execution time: 0.0875
INFO - 2023-01-18 04:04:04 --> Config Class Initialized
INFO - 2023-01-18 04:04:04 --> Hooks Class Initialized
DEBUG - 2023-01-18 04:04:04 --> UTF-8 Support Enabled
INFO - 2023-01-18 04:04:04 --> Utf8 Class Initialized
INFO - 2023-01-18 04:04:04 --> URI Class Initialized
INFO - 2023-01-18 04:04:04 --> Router Class Initialized
INFO - 2023-01-18 04:04:04 --> Output Class Initialized
INFO - 2023-01-18 04:04:04 --> Security Class Initialized
DEBUG - 2023-01-18 04:04:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-18 04:04:04 --> Input Class Initialized
INFO - 2023-01-18 04:04:04 --> Language Class Initialized
INFO - 2023-01-18 04:04:04 --> Language Class Initialized
INFO - 2023-01-18 04:04:04 --> Config Class Initialized
INFO - 2023-01-18 04:04:04 --> Loader Class Initialized
INFO - 2023-01-18 04:04:04 --> Helper loaded: url_helper
INFO - 2023-01-18 04:04:04 --> Helper loaded: file_helper
INFO - 2023-01-18 04:04:04 --> Helper loaded: form_helper
INFO - 2023-01-18 04:04:04 --> Helper loaded: my_helper
INFO - 2023-01-18 04:04:04 --> Database Driver Class Initialized
DEBUG - 2023-01-18 04:04:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-01-18 04:04:04 --> Session: Class initialized using 'files' driver.
INFO - 2023-01-18 04:04:04 --> Controller Class Initialized
INFO - 2023-01-18 04:04:12 --> Config Class Initialized
INFO - 2023-01-18 04:04:12 --> Hooks Class Initialized
DEBUG - 2023-01-18 04:04:12 --> UTF-8 Support Enabled
INFO - 2023-01-18 04:04:12 --> Utf8 Class Initialized
INFO - 2023-01-18 04:04:12 --> URI Class Initialized
INFO - 2023-01-18 04:04:12 --> Router Class Initialized
INFO - 2023-01-18 04:04:12 --> Output Class Initialized
INFO - 2023-01-18 04:04:12 --> Security Class Initialized
DEBUG - 2023-01-18 04:04:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-18 04:04:12 --> Input Class Initialized
INFO - 2023-01-18 04:04:12 --> Language Class Initialized
INFO - 2023-01-18 04:04:12 --> Language Class Initialized
INFO - 2023-01-18 04:04:12 --> Config Class Initialized
INFO - 2023-01-18 04:04:12 --> Loader Class Initialized
INFO - 2023-01-18 04:04:12 --> Helper loaded: url_helper
INFO - 2023-01-18 04:04:12 --> Helper loaded: file_helper
INFO - 2023-01-18 04:04:12 --> Helper loaded: form_helper
INFO - 2023-01-18 04:04:12 --> Helper loaded: my_helper
INFO - 2023-01-18 04:04:12 --> Database Driver Class Initialized
DEBUG - 2023-01-18 04:04:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-01-18 04:04:12 --> Session: Class initialized using 'files' driver.
INFO - 2023-01-18 04:04:12 --> Controller Class Initialized
INFO - 2023-01-18 04:04:12 --> Final output sent to browser
DEBUG - 2023-01-18 04:04:12 --> Total execution time: 0.0394
INFO - 2023-01-18 04:04:28 --> Config Class Initialized
INFO - 2023-01-18 04:04:28 --> Hooks Class Initialized
DEBUG - 2023-01-18 04:04:28 --> UTF-8 Support Enabled
INFO - 2023-01-18 04:04:28 --> Utf8 Class Initialized
INFO - 2023-01-18 04:04:28 --> URI Class Initialized
INFO - 2023-01-18 04:04:28 --> Router Class Initialized
INFO - 2023-01-18 04:04:28 --> Output Class Initialized
INFO - 2023-01-18 04:04:28 --> Security Class Initialized
DEBUG - 2023-01-18 04:04:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-18 04:04:28 --> Input Class Initialized
INFO - 2023-01-18 04:04:28 --> Language Class Initialized
INFO - 2023-01-18 04:04:28 --> Language Class Initialized
INFO - 2023-01-18 04:04:28 --> Config Class Initialized
INFO - 2023-01-18 04:04:28 --> Loader Class Initialized
INFO - 2023-01-18 04:04:28 --> Helper loaded: url_helper
INFO - 2023-01-18 04:04:28 --> Helper loaded: file_helper
INFO - 2023-01-18 04:04:28 --> Helper loaded: form_helper
INFO - 2023-01-18 04:04:28 --> Helper loaded: my_helper
INFO - 2023-01-18 04:04:28 --> Database Driver Class Initialized
DEBUG - 2023-01-18 04:04:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-01-18 04:04:28 --> Session: Class initialized using 'files' driver.
INFO - 2023-01-18 04:04:28 --> Controller Class Initialized
INFO - 2023-01-18 04:04:28 --> Final output sent to browser
DEBUG - 2023-01-18 04:04:28 --> Total execution time: 0.0342
INFO - 2023-01-18 04:04:44 --> Config Class Initialized
INFO - 2023-01-18 04:04:44 --> Hooks Class Initialized
DEBUG - 2023-01-18 04:04:44 --> UTF-8 Support Enabled
INFO - 2023-01-18 04:04:44 --> Utf8 Class Initialized
INFO - 2023-01-18 04:04:44 --> URI Class Initialized
INFO - 2023-01-18 04:04:44 --> Router Class Initialized
INFO - 2023-01-18 04:04:44 --> Output Class Initialized
INFO - 2023-01-18 04:04:44 --> Security Class Initialized
DEBUG - 2023-01-18 04:04:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-18 04:04:44 --> Input Class Initialized
INFO - 2023-01-18 04:04:44 --> Language Class Initialized
INFO - 2023-01-18 04:04:44 --> Language Class Initialized
INFO - 2023-01-18 04:04:44 --> Config Class Initialized
INFO - 2023-01-18 04:04:44 --> Loader Class Initialized
INFO - 2023-01-18 04:04:44 --> Helper loaded: url_helper
INFO - 2023-01-18 04:04:44 --> Helper loaded: file_helper
INFO - 2023-01-18 04:04:44 --> Helper loaded: form_helper
INFO - 2023-01-18 04:04:44 --> Helper loaded: my_helper
INFO - 2023-01-18 04:04:44 --> Database Driver Class Initialized
DEBUG - 2023-01-18 04:04:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-01-18 04:04:44 --> Session: Class initialized using 'files' driver.
INFO - 2023-01-18 04:04:44 --> Controller Class Initialized
INFO - 2023-01-18 04:04:44 --> Final output sent to browser
DEBUG - 2023-01-18 04:04:44 --> Total execution time: 0.0407
INFO - 2023-01-18 04:04:44 --> Config Class Initialized
INFO - 2023-01-18 04:04:44 --> Hooks Class Initialized
DEBUG - 2023-01-18 04:04:44 --> UTF-8 Support Enabled
INFO - 2023-01-18 04:04:44 --> Utf8 Class Initialized
INFO - 2023-01-18 04:04:44 --> URI Class Initialized
INFO - 2023-01-18 04:04:44 --> Router Class Initialized
INFO - 2023-01-18 04:04:44 --> Output Class Initialized
INFO - 2023-01-18 04:04:44 --> Security Class Initialized
DEBUG - 2023-01-18 04:04:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-18 04:04:44 --> Input Class Initialized
INFO - 2023-01-18 04:04:44 --> Language Class Initialized
INFO - 2023-01-18 04:04:44 --> Language Class Initialized
INFO - 2023-01-18 04:04:44 --> Config Class Initialized
INFO - 2023-01-18 04:04:44 --> Loader Class Initialized
INFO - 2023-01-18 04:04:44 --> Helper loaded: url_helper
INFO - 2023-01-18 04:04:44 --> Helper loaded: file_helper
INFO - 2023-01-18 04:04:44 --> Helper loaded: form_helper
INFO - 2023-01-18 04:04:44 --> Helper loaded: my_helper
INFO - 2023-01-18 04:04:44 --> Database Driver Class Initialized
DEBUG - 2023-01-18 04:04:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-01-18 04:04:44 --> Session: Class initialized using 'files' driver.
INFO - 2023-01-18 04:04:44 --> Controller Class Initialized
INFO - 2023-01-18 04:05:08 --> Config Class Initialized
INFO - 2023-01-18 04:05:08 --> Hooks Class Initialized
DEBUG - 2023-01-18 04:05:08 --> UTF-8 Support Enabled
INFO - 2023-01-18 04:05:08 --> Utf8 Class Initialized
INFO - 2023-01-18 04:05:08 --> URI Class Initialized
INFO - 2023-01-18 04:05:08 --> Router Class Initialized
INFO - 2023-01-18 04:05:08 --> Output Class Initialized
INFO - 2023-01-18 04:05:08 --> Security Class Initialized
DEBUG - 2023-01-18 04:05:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-18 04:05:08 --> Input Class Initialized
INFO - 2023-01-18 04:05:08 --> Language Class Initialized
INFO - 2023-01-18 04:05:08 --> Language Class Initialized
INFO - 2023-01-18 04:05:08 --> Config Class Initialized
INFO - 2023-01-18 04:05:08 --> Loader Class Initialized
INFO - 2023-01-18 04:05:08 --> Helper loaded: url_helper
INFO - 2023-01-18 04:05:08 --> Helper loaded: file_helper
INFO - 2023-01-18 04:05:08 --> Helper loaded: form_helper
INFO - 2023-01-18 04:05:08 --> Helper loaded: my_helper
INFO - 2023-01-18 04:05:08 --> Database Driver Class Initialized
DEBUG - 2023-01-18 04:05:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-01-18 04:05:08 --> Session: Class initialized using 'files' driver.
INFO - 2023-01-18 04:05:08 --> Controller Class Initialized
INFO - 2023-01-18 04:05:08 --> Final output sent to browser
DEBUG - 2023-01-18 04:05:08 --> Total execution time: 0.0240
INFO - 2023-01-18 04:05:08 --> Config Class Initialized
INFO - 2023-01-18 04:05:08 --> Hooks Class Initialized
DEBUG - 2023-01-18 04:05:08 --> UTF-8 Support Enabled
INFO - 2023-01-18 04:05:08 --> Utf8 Class Initialized
INFO - 2023-01-18 04:05:08 --> URI Class Initialized
INFO - 2023-01-18 04:05:08 --> Router Class Initialized
INFO - 2023-01-18 04:05:08 --> Output Class Initialized
INFO - 2023-01-18 04:05:08 --> Security Class Initialized
DEBUG - 2023-01-18 04:05:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-18 04:05:08 --> Input Class Initialized
INFO - 2023-01-18 04:05:08 --> Language Class Initialized
INFO - 2023-01-18 04:05:08 --> Language Class Initialized
INFO - 2023-01-18 04:05:08 --> Config Class Initialized
INFO - 2023-01-18 04:05:08 --> Loader Class Initialized
INFO - 2023-01-18 04:05:08 --> Helper loaded: url_helper
INFO - 2023-01-18 04:05:08 --> Helper loaded: file_helper
INFO - 2023-01-18 04:05:08 --> Helper loaded: form_helper
INFO - 2023-01-18 04:05:08 --> Helper loaded: my_helper
INFO - 2023-01-18 04:05:08 --> Database Driver Class Initialized
DEBUG - 2023-01-18 04:05:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-01-18 04:05:08 --> Session: Class initialized using 'files' driver.
INFO - 2023-01-18 04:05:08 --> Controller Class Initialized
INFO - 2023-01-18 04:05:35 --> Config Class Initialized
INFO - 2023-01-18 04:05:35 --> Hooks Class Initialized
DEBUG - 2023-01-18 04:05:35 --> UTF-8 Support Enabled
INFO - 2023-01-18 04:05:35 --> Utf8 Class Initialized
INFO - 2023-01-18 04:05:35 --> URI Class Initialized
INFO - 2023-01-18 04:05:35 --> Router Class Initialized
INFO - 2023-01-18 04:05:35 --> Output Class Initialized
INFO - 2023-01-18 04:05:35 --> Security Class Initialized
DEBUG - 2023-01-18 04:05:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-18 04:05:35 --> Input Class Initialized
INFO - 2023-01-18 04:05:35 --> Language Class Initialized
INFO - 2023-01-18 04:05:35 --> Language Class Initialized
INFO - 2023-01-18 04:05:35 --> Config Class Initialized
INFO - 2023-01-18 04:05:35 --> Loader Class Initialized
INFO - 2023-01-18 04:05:35 --> Helper loaded: url_helper
INFO - 2023-01-18 04:05:35 --> Helper loaded: file_helper
INFO - 2023-01-18 04:05:35 --> Helper loaded: form_helper
INFO - 2023-01-18 04:05:35 --> Helper loaded: my_helper
INFO - 2023-01-18 04:05:35 --> Database Driver Class Initialized
DEBUG - 2023-01-18 04:05:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-01-18 04:05:35 --> Session: Class initialized using 'files' driver.
INFO - 2023-01-18 04:05:35 --> Controller Class Initialized
DEBUG - 2023-01-18 04:05:35 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/data_mapel/views/list.php
DEBUG - 2023-01-18 04:05:35 --> File loaded: C:\xampp\htdocs\myraportk13\application\views\template_utama.php
INFO - 2023-01-18 04:05:35 --> Final output sent to browser
DEBUG - 2023-01-18 04:05:35 --> Total execution time: 0.0744
INFO - 2023-01-18 04:05:35 --> Config Class Initialized
INFO - 2023-01-18 04:05:35 --> Hooks Class Initialized
DEBUG - 2023-01-18 04:05:35 --> UTF-8 Support Enabled
INFO - 2023-01-18 04:05:35 --> Utf8 Class Initialized
INFO - 2023-01-18 04:05:35 --> URI Class Initialized
INFO - 2023-01-18 04:05:35 --> Router Class Initialized
INFO - 2023-01-18 04:05:35 --> Output Class Initialized
INFO - 2023-01-18 04:05:35 --> Security Class Initialized
DEBUG - 2023-01-18 04:05:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-18 04:05:35 --> Input Class Initialized
INFO - 2023-01-18 04:05:35 --> Language Class Initialized
INFO - 2023-01-18 04:05:35 --> Language Class Initialized
INFO - 2023-01-18 04:05:35 --> Config Class Initialized
INFO - 2023-01-18 04:05:35 --> Loader Class Initialized
INFO - 2023-01-18 04:05:35 --> Helper loaded: url_helper
INFO - 2023-01-18 04:05:35 --> Helper loaded: file_helper
INFO - 2023-01-18 04:05:35 --> Helper loaded: form_helper
INFO - 2023-01-18 04:05:35 --> Helper loaded: my_helper
INFO - 2023-01-18 04:05:35 --> Database Driver Class Initialized
DEBUG - 2023-01-18 04:05:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-01-18 04:05:35 --> Session: Class initialized using 'files' driver.
INFO - 2023-01-18 04:05:35 --> Controller Class Initialized
INFO - 2023-01-18 04:05:41 --> Config Class Initialized
INFO - 2023-01-18 04:05:41 --> Hooks Class Initialized
DEBUG - 2023-01-18 04:05:41 --> UTF-8 Support Enabled
INFO - 2023-01-18 04:05:41 --> Utf8 Class Initialized
INFO - 2023-01-18 04:05:41 --> URI Class Initialized
INFO - 2023-01-18 04:05:41 --> Router Class Initialized
INFO - 2023-01-18 04:05:41 --> Output Class Initialized
INFO - 2023-01-18 04:05:41 --> Security Class Initialized
DEBUG - 2023-01-18 04:05:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-18 04:05:41 --> Input Class Initialized
INFO - 2023-01-18 04:05:41 --> Language Class Initialized
INFO - 2023-01-18 04:05:41 --> Language Class Initialized
INFO - 2023-01-18 04:05:41 --> Config Class Initialized
INFO - 2023-01-18 04:05:41 --> Loader Class Initialized
INFO - 2023-01-18 04:05:41 --> Helper loaded: url_helper
INFO - 2023-01-18 04:05:41 --> Helper loaded: file_helper
INFO - 2023-01-18 04:05:41 --> Helper loaded: form_helper
INFO - 2023-01-18 04:05:41 --> Helper loaded: my_helper
INFO - 2023-01-18 04:05:41 --> Database Driver Class Initialized
DEBUG - 2023-01-18 04:05:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-01-18 04:05:41 --> Session: Class initialized using 'files' driver.
INFO - 2023-01-18 04:05:41 --> Controller Class Initialized
INFO - 2023-01-18 04:05:41 --> Final output sent to browser
DEBUG - 2023-01-18 04:05:41 --> Total execution time: 0.0427
INFO - 2023-01-18 04:06:06 --> Config Class Initialized
INFO - 2023-01-18 04:06:06 --> Hooks Class Initialized
DEBUG - 2023-01-18 04:06:06 --> UTF-8 Support Enabled
INFO - 2023-01-18 04:06:06 --> Utf8 Class Initialized
INFO - 2023-01-18 04:06:06 --> URI Class Initialized
INFO - 2023-01-18 04:06:06 --> Router Class Initialized
INFO - 2023-01-18 04:06:06 --> Output Class Initialized
INFO - 2023-01-18 04:06:06 --> Security Class Initialized
DEBUG - 2023-01-18 04:06:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-18 04:06:06 --> Input Class Initialized
INFO - 2023-01-18 04:06:06 --> Language Class Initialized
INFO - 2023-01-18 04:06:06 --> Language Class Initialized
INFO - 2023-01-18 04:06:06 --> Config Class Initialized
INFO - 2023-01-18 04:06:06 --> Loader Class Initialized
INFO - 2023-01-18 04:06:06 --> Helper loaded: url_helper
INFO - 2023-01-18 04:06:06 --> Helper loaded: file_helper
INFO - 2023-01-18 04:06:06 --> Helper loaded: form_helper
INFO - 2023-01-18 04:06:06 --> Helper loaded: my_helper
INFO - 2023-01-18 04:06:06 --> Database Driver Class Initialized
DEBUG - 2023-01-18 04:06:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-01-18 04:06:06 --> Session: Class initialized using 'files' driver.
INFO - 2023-01-18 04:06:06 --> Controller Class Initialized
INFO - 2023-01-18 04:06:06 --> Final output sent to browser
DEBUG - 2023-01-18 04:06:06 --> Total execution time: 0.0330
INFO - 2023-01-18 04:06:06 --> Config Class Initialized
INFO - 2023-01-18 04:06:06 --> Hooks Class Initialized
DEBUG - 2023-01-18 04:06:06 --> UTF-8 Support Enabled
INFO - 2023-01-18 04:06:06 --> Utf8 Class Initialized
INFO - 2023-01-18 04:06:06 --> URI Class Initialized
INFO - 2023-01-18 04:06:06 --> Router Class Initialized
INFO - 2023-01-18 04:06:06 --> Output Class Initialized
INFO - 2023-01-18 04:06:06 --> Security Class Initialized
DEBUG - 2023-01-18 04:06:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-18 04:06:06 --> Input Class Initialized
INFO - 2023-01-18 04:06:06 --> Language Class Initialized
INFO - 2023-01-18 04:06:06 --> Language Class Initialized
INFO - 2023-01-18 04:06:06 --> Config Class Initialized
INFO - 2023-01-18 04:06:06 --> Loader Class Initialized
INFO - 2023-01-18 04:06:06 --> Helper loaded: url_helper
INFO - 2023-01-18 04:06:06 --> Helper loaded: file_helper
INFO - 2023-01-18 04:06:06 --> Helper loaded: form_helper
INFO - 2023-01-18 04:06:06 --> Helper loaded: my_helper
INFO - 2023-01-18 04:06:06 --> Database Driver Class Initialized
DEBUG - 2023-01-18 04:06:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-01-18 04:06:06 --> Session: Class initialized using 'files' driver.
INFO - 2023-01-18 04:06:06 --> Controller Class Initialized
INFO - 2023-01-18 04:06:37 --> Config Class Initialized
INFO - 2023-01-18 04:06:37 --> Hooks Class Initialized
DEBUG - 2023-01-18 04:06:37 --> UTF-8 Support Enabled
INFO - 2023-01-18 04:06:37 --> Utf8 Class Initialized
INFO - 2023-01-18 04:06:37 --> URI Class Initialized
INFO - 2023-01-18 04:06:37 --> Router Class Initialized
INFO - 2023-01-18 04:06:37 --> Output Class Initialized
INFO - 2023-01-18 04:06:37 --> Security Class Initialized
DEBUG - 2023-01-18 04:06:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-18 04:06:37 --> Input Class Initialized
INFO - 2023-01-18 04:06:37 --> Language Class Initialized
INFO - 2023-01-18 04:06:37 --> Language Class Initialized
INFO - 2023-01-18 04:06:37 --> Config Class Initialized
INFO - 2023-01-18 04:06:37 --> Loader Class Initialized
INFO - 2023-01-18 04:06:37 --> Helper loaded: url_helper
INFO - 2023-01-18 04:06:37 --> Helper loaded: file_helper
INFO - 2023-01-18 04:06:37 --> Helper loaded: form_helper
INFO - 2023-01-18 04:06:37 --> Helper loaded: my_helper
INFO - 2023-01-18 04:06:37 --> Database Driver Class Initialized
DEBUG - 2023-01-18 04:06:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-01-18 04:06:37 --> Session: Class initialized using 'files' driver.
INFO - 2023-01-18 04:06:37 --> Controller Class Initialized
DEBUG - 2023-01-18 04:06:37 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/data_kelas/views/list.php
DEBUG - 2023-01-18 04:06:37 --> File loaded: C:\xampp\htdocs\myraportk13\application\views\template_utama.php
INFO - 2023-01-18 04:06:37 --> Final output sent to browser
DEBUG - 2023-01-18 04:06:37 --> Total execution time: 0.0544
INFO - 2023-01-18 04:06:38 --> Config Class Initialized
INFO - 2023-01-18 04:06:38 --> Hooks Class Initialized
DEBUG - 2023-01-18 04:06:38 --> UTF-8 Support Enabled
INFO - 2023-01-18 04:06:38 --> Utf8 Class Initialized
INFO - 2023-01-18 04:06:38 --> URI Class Initialized
INFO - 2023-01-18 04:06:38 --> Router Class Initialized
INFO - 2023-01-18 04:06:38 --> Output Class Initialized
INFO - 2023-01-18 04:06:38 --> Security Class Initialized
DEBUG - 2023-01-18 04:06:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-18 04:06:38 --> Input Class Initialized
INFO - 2023-01-18 04:06:38 --> Language Class Initialized
INFO - 2023-01-18 04:06:38 --> Language Class Initialized
INFO - 2023-01-18 04:06:38 --> Config Class Initialized
INFO - 2023-01-18 04:06:38 --> Loader Class Initialized
INFO - 2023-01-18 04:06:38 --> Helper loaded: url_helper
INFO - 2023-01-18 04:06:38 --> Helper loaded: file_helper
INFO - 2023-01-18 04:06:38 --> Helper loaded: form_helper
INFO - 2023-01-18 04:06:38 --> Helper loaded: my_helper
INFO - 2023-01-18 04:06:38 --> Database Driver Class Initialized
DEBUG - 2023-01-18 04:06:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-01-18 04:06:38 --> Session: Class initialized using 'files' driver.
INFO - 2023-01-18 04:06:38 --> Controller Class Initialized
INFO - 2023-01-18 04:06:58 --> Config Class Initialized
INFO - 2023-01-18 04:06:58 --> Hooks Class Initialized
DEBUG - 2023-01-18 04:06:58 --> UTF-8 Support Enabled
INFO - 2023-01-18 04:06:58 --> Utf8 Class Initialized
INFO - 2023-01-18 04:06:58 --> URI Class Initialized
INFO - 2023-01-18 04:06:58 --> Router Class Initialized
INFO - 2023-01-18 04:06:58 --> Output Class Initialized
INFO - 2023-01-18 04:06:58 --> Security Class Initialized
DEBUG - 2023-01-18 04:06:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-18 04:06:58 --> Input Class Initialized
INFO - 2023-01-18 04:06:58 --> Language Class Initialized
INFO - 2023-01-18 04:06:58 --> Language Class Initialized
INFO - 2023-01-18 04:06:58 --> Config Class Initialized
INFO - 2023-01-18 04:06:58 --> Loader Class Initialized
INFO - 2023-01-18 04:06:58 --> Helper loaded: url_helper
INFO - 2023-01-18 04:06:58 --> Helper loaded: file_helper
INFO - 2023-01-18 04:06:58 --> Helper loaded: form_helper
INFO - 2023-01-18 04:06:58 --> Helper loaded: my_helper
INFO - 2023-01-18 04:06:58 --> Database Driver Class Initialized
DEBUG - 2023-01-18 04:06:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-01-18 04:06:58 --> Session: Class initialized using 'files' driver.
INFO - 2023-01-18 04:06:58 --> Controller Class Initialized
INFO - 2023-01-18 04:06:58 --> Final output sent to browser
DEBUG - 2023-01-18 04:06:58 --> Total execution time: 0.0324
INFO - 2023-01-18 04:07:25 --> Config Class Initialized
INFO - 2023-01-18 04:07:25 --> Hooks Class Initialized
DEBUG - 2023-01-18 04:07:25 --> UTF-8 Support Enabled
INFO - 2023-01-18 04:07:25 --> Utf8 Class Initialized
INFO - 2023-01-18 04:07:25 --> URI Class Initialized
INFO - 2023-01-18 04:07:25 --> Router Class Initialized
INFO - 2023-01-18 04:07:25 --> Output Class Initialized
INFO - 2023-01-18 04:07:25 --> Security Class Initialized
DEBUG - 2023-01-18 04:07:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-18 04:07:25 --> Input Class Initialized
INFO - 2023-01-18 04:07:25 --> Language Class Initialized
INFO - 2023-01-18 04:07:25 --> Language Class Initialized
INFO - 2023-01-18 04:07:25 --> Config Class Initialized
INFO - 2023-01-18 04:07:25 --> Loader Class Initialized
INFO - 2023-01-18 04:07:25 --> Helper loaded: url_helper
INFO - 2023-01-18 04:07:25 --> Helper loaded: file_helper
INFO - 2023-01-18 04:07:25 --> Helper loaded: form_helper
INFO - 2023-01-18 04:07:25 --> Helper loaded: my_helper
INFO - 2023-01-18 04:07:25 --> Database Driver Class Initialized
DEBUG - 2023-01-18 04:07:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-01-18 04:07:25 --> Session: Class initialized using 'files' driver.
INFO - 2023-01-18 04:07:25 --> Controller Class Initialized
INFO - 2023-01-18 04:07:25 --> Final output sent to browser
DEBUG - 2023-01-18 04:07:25 --> Total execution time: 0.0290
INFO - 2023-01-18 04:07:25 --> Config Class Initialized
INFO - 2023-01-18 04:07:25 --> Hooks Class Initialized
DEBUG - 2023-01-18 04:07:25 --> UTF-8 Support Enabled
INFO - 2023-01-18 04:07:25 --> Utf8 Class Initialized
INFO - 2023-01-18 04:07:25 --> URI Class Initialized
INFO - 2023-01-18 04:07:25 --> Router Class Initialized
INFO - 2023-01-18 04:07:25 --> Output Class Initialized
INFO - 2023-01-18 04:07:25 --> Security Class Initialized
DEBUG - 2023-01-18 04:07:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-18 04:07:25 --> Input Class Initialized
INFO - 2023-01-18 04:07:25 --> Language Class Initialized
INFO - 2023-01-18 04:07:25 --> Language Class Initialized
INFO - 2023-01-18 04:07:25 --> Config Class Initialized
INFO - 2023-01-18 04:07:25 --> Loader Class Initialized
INFO - 2023-01-18 04:07:25 --> Helper loaded: url_helper
INFO - 2023-01-18 04:07:25 --> Helper loaded: file_helper
INFO - 2023-01-18 04:07:25 --> Helper loaded: form_helper
INFO - 2023-01-18 04:07:25 --> Helper loaded: my_helper
INFO - 2023-01-18 04:07:25 --> Database Driver Class Initialized
DEBUG - 2023-01-18 04:07:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-01-18 04:07:25 --> Session: Class initialized using 'files' driver.
INFO - 2023-01-18 04:07:25 --> Controller Class Initialized
INFO - 2023-01-18 04:07:30 --> Config Class Initialized
INFO - 2023-01-18 04:07:30 --> Hooks Class Initialized
DEBUG - 2023-01-18 04:07:30 --> UTF-8 Support Enabled
INFO - 2023-01-18 04:07:30 --> Utf8 Class Initialized
INFO - 2023-01-18 04:07:30 --> URI Class Initialized
INFO - 2023-01-18 04:07:30 --> Router Class Initialized
INFO - 2023-01-18 04:07:30 --> Output Class Initialized
INFO - 2023-01-18 04:07:30 --> Security Class Initialized
DEBUG - 2023-01-18 04:07:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-18 04:07:30 --> Input Class Initialized
INFO - 2023-01-18 04:07:30 --> Language Class Initialized
INFO - 2023-01-18 04:07:30 --> Language Class Initialized
INFO - 2023-01-18 04:07:30 --> Config Class Initialized
INFO - 2023-01-18 04:07:30 --> Loader Class Initialized
INFO - 2023-01-18 04:07:30 --> Helper loaded: url_helper
INFO - 2023-01-18 04:07:30 --> Helper loaded: file_helper
INFO - 2023-01-18 04:07:30 --> Helper loaded: form_helper
INFO - 2023-01-18 04:07:30 --> Helper loaded: my_helper
INFO - 2023-01-18 04:07:30 --> Database Driver Class Initialized
DEBUG - 2023-01-18 04:07:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-01-18 04:07:30 --> Session: Class initialized using 'files' driver.
INFO - 2023-01-18 04:07:30 --> Controller Class Initialized
INFO - 2023-01-18 04:07:30 --> Final output sent to browser
DEBUG - 2023-01-18 04:07:30 --> Total execution time: 0.0340
INFO - 2023-01-18 04:07:43 --> Config Class Initialized
INFO - 2023-01-18 04:07:43 --> Hooks Class Initialized
DEBUG - 2023-01-18 04:07:43 --> UTF-8 Support Enabled
INFO - 2023-01-18 04:07:43 --> Utf8 Class Initialized
INFO - 2023-01-18 04:07:43 --> URI Class Initialized
INFO - 2023-01-18 04:07:43 --> Router Class Initialized
INFO - 2023-01-18 04:07:43 --> Output Class Initialized
INFO - 2023-01-18 04:07:43 --> Security Class Initialized
DEBUG - 2023-01-18 04:07:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-18 04:07:43 --> Input Class Initialized
INFO - 2023-01-18 04:07:43 --> Language Class Initialized
INFO - 2023-01-18 04:07:43 --> Language Class Initialized
INFO - 2023-01-18 04:07:43 --> Config Class Initialized
INFO - 2023-01-18 04:07:43 --> Loader Class Initialized
INFO - 2023-01-18 04:07:43 --> Helper loaded: url_helper
INFO - 2023-01-18 04:07:43 --> Helper loaded: file_helper
INFO - 2023-01-18 04:07:43 --> Helper loaded: form_helper
INFO - 2023-01-18 04:07:43 --> Helper loaded: my_helper
INFO - 2023-01-18 04:07:43 --> Database Driver Class Initialized
DEBUG - 2023-01-18 04:07:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-01-18 04:07:43 --> Session: Class initialized using 'files' driver.
INFO - 2023-01-18 04:07:43 --> Controller Class Initialized
INFO - 2023-01-18 04:07:43 --> Final output sent to browser
DEBUG - 2023-01-18 04:07:43 --> Total execution time: 0.0237
INFO - 2023-01-18 04:07:43 --> Config Class Initialized
INFO - 2023-01-18 04:07:43 --> Hooks Class Initialized
DEBUG - 2023-01-18 04:07:43 --> UTF-8 Support Enabled
INFO - 2023-01-18 04:07:43 --> Utf8 Class Initialized
INFO - 2023-01-18 04:07:43 --> URI Class Initialized
INFO - 2023-01-18 04:07:43 --> Router Class Initialized
INFO - 2023-01-18 04:07:43 --> Output Class Initialized
INFO - 2023-01-18 04:07:43 --> Security Class Initialized
DEBUG - 2023-01-18 04:07:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-18 04:07:43 --> Input Class Initialized
INFO - 2023-01-18 04:07:43 --> Language Class Initialized
INFO - 2023-01-18 04:07:43 --> Language Class Initialized
INFO - 2023-01-18 04:07:43 --> Config Class Initialized
INFO - 2023-01-18 04:07:43 --> Loader Class Initialized
INFO - 2023-01-18 04:07:43 --> Helper loaded: url_helper
INFO - 2023-01-18 04:07:43 --> Helper loaded: file_helper
INFO - 2023-01-18 04:07:43 --> Helper loaded: form_helper
INFO - 2023-01-18 04:07:43 --> Helper loaded: my_helper
INFO - 2023-01-18 04:07:43 --> Database Driver Class Initialized
DEBUG - 2023-01-18 04:07:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-01-18 04:07:43 --> Session: Class initialized using 'files' driver.
INFO - 2023-01-18 04:07:43 --> Controller Class Initialized
INFO - 2023-01-18 04:07:45 --> Config Class Initialized
INFO - 2023-01-18 04:07:45 --> Hooks Class Initialized
DEBUG - 2023-01-18 04:07:45 --> UTF-8 Support Enabled
INFO - 2023-01-18 04:07:45 --> Utf8 Class Initialized
INFO - 2023-01-18 04:07:45 --> URI Class Initialized
INFO - 2023-01-18 04:07:45 --> Router Class Initialized
INFO - 2023-01-18 04:07:45 --> Output Class Initialized
INFO - 2023-01-18 04:07:45 --> Security Class Initialized
DEBUG - 2023-01-18 04:07:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-18 04:07:45 --> Input Class Initialized
INFO - 2023-01-18 04:07:45 --> Language Class Initialized
INFO - 2023-01-18 04:07:45 --> Language Class Initialized
INFO - 2023-01-18 04:07:45 --> Config Class Initialized
INFO - 2023-01-18 04:07:45 --> Loader Class Initialized
INFO - 2023-01-18 04:07:45 --> Helper loaded: url_helper
INFO - 2023-01-18 04:07:45 --> Helper loaded: file_helper
INFO - 2023-01-18 04:07:45 --> Helper loaded: form_helper
INFO - 2023-01-18 04:07:45 --> Helper loaded: my_helper
INFO - 2023-01-18 04:07:45 --> Database Driver Class Initialized
DEBUG - 2023-01-18 04:07:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-01-18 04:07:45 --> Session: Class initialized using 'files' driver.
INFO - 2023-01-18 04:07:45 --> Controller Class Initialized
INFO - 2023-01-18 04:07:45 --> Final output sent to browser
DEBUG - 2023-01-18 04:07:45 --> Total execution time: 0.0351
INFO - 2023-01-18 04:07:47 --> Config Class Initialized
INFO - 2023-01-18 04:07:47 --> Hooks Class Initialized
DEBUG - 2023-01-18 04:07:47 --> UTF-8 Support Enabled
INFO - 2023-01-18 04:07:47 --> Utf8 Class Initialized
INFO - 2023-01-18 04:07:47 --> URI Class Initialized
INFO - 2023-01-18 04:07:47 --> Router Class Initialized
INFO - 2023-01-18 04:07:47 --> Output Class Initialized
INFO - 2023-01-18 04:07:47 --> Security Class Initialized
DEBUG - 2023-01-18 04:07:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-18 04:07:47 --> Input Class Initialized
INFO - 2023-01-18 04:07:47 --> Language Class Initialized
INFO - 2023-01-18 04:07:47 --> Language Class Initialized
INFO - 2023-01-18 04:07:47 --> Config Class Initialized
INFO - 2023-01-18 04:07:47 --> Loader Class Initialized
INFO - 2023-01-18 04:07:47 --> Helper loaded: url_helper
INFO - 2023-01-18 04:07:47 --> Helper loaded: file_helper
INFO - 2023-01-18 04:07:47 --> Helper loaded: form_helper
INFO - 2023-01-18 04:07:47 --> Helper loaded: my_helper
INFO - 2023-01-18 04:07:47 --> Database Driver Class Initialized
DEBUG - 2023-01-18 04:07:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-01-18 04:07:47 --> Session: Class initialized using 'files' driver.
INFO - 2023-01-18 04:07:47 --> Controller Class Initialized
INFO - 2023-01-18 04:07:47 --> Final output sent to browser
DEBUG - 2023-01-18 04:07:47 --> Total execution time: 0.0295
INFO - 2023-01-18 04:07:47 --> Config Class Initialized
INFO - 2023-01-18 04:07:47 --> Hooks Class Initialized
DEBUG - 2023-01-18 04:07:47 --> UTF-8 Support Enabled
INFO - 2023-01-18 04:07:47 --> Utf8 Class Initialized
INFO - 2023-01-18 04:07:47 --> URI Class Initialized
INFO - 2023-01-18 04:07:47 --> Router Class Initialized
INFO - 2023-01-18 04:07:47 --> Output Class Initialized
INFO - 2023-01-18 04:07:47 --> Security Class Initialized
DEBUG - 2023-01-18 04:07:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-18 04:07:47 --> Input Class Initialized
INFO - 2023-01-18 04:07:47 --> Language Class Initialized
INFO - 2023-01-18 04:07:47 --> Language Class Initialized
INFO - 2023-01-18 04:07:47 --> Config Class Initialized
INFO - 2023-01-18 04:07:47 --> Loader Class Initialized
INFO - 2023-01-18 04:07:47 --> Helper loaded: url_helper
INFO - 2023-01-18 04:07:47 --> Helper loaded: file_helper
INFO - 2023-01-18 04:07:47 --> Helper loaded: form_helper
INFO - 2023-01-18 04:07:47 --> Helper loaded: my_helper
INFO - 2023-01-18 04:07:47 --> Database Driver Class Initialized
DEBUG - 2023-01-18 04:07:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-01-18 04:07:47 --> Session: Class initialized using 'files' driver.
INFO - 2023-01-18 04:07:47 --> Controller Class Initialized
INFO - 2023-01-18 04:08:18 --> Config Class Initialized
INFO - 2023-01-18 04:08:18 --> Hooks Class Initialized
DEBUG - 2023-01-18 04:08:18 --> UTF-8 Support Enabled
INFO - 2023-01-18 04:08:18 --> Utf8 Class Initialized
INFO - 2023-01-18 04:08:18 --> URI Class Initialized
INFO - 2023-01-18 04:08:18 --> Router Class Initialized
INFO - 2023-01-18 04:08:18 --> Output Class Initialized
INFO - 2023-01-18 04:08:18 --> Security Class Initialized
DEBUG - 2023-01-18 04:08:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-18 04:08:18 --> Input Class Initialized
INFO - 2023-01-18 04:08:18 --> Language Class Initialized
INFO - 2023-01-18 04:08:18 --> Language Class Initialized
INFO - 2023-01-18 04:08:18 --> Config Class Initialized
INFO - 2023-01-18 04:08:18 --> Loader Class Initialized
INFO - 2023-01-18 04:08:18 --> Helper loaded: url_helper
INFO - 2023-01-18 04:08:18 --> Helper loaded: file_helper
INFO - 2023-01-18 04:08:18 --> Helper loaded: form_helper
INFO - 2023-01-18 04:08:18 --> Helper loaded: my_helper
INFO - 2023-01-18 04:08:18 --> Database Driver Class Initialized
DEBUG - 2023-01-18 04:08:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-01-18 04:08:18 --> Session: Class initialized using 'files' driver.
INFO - 2023-01-18 04:08:18 --> Controller Class Initialized
DEBUG - 2023-01-18 04:08:18 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/set_mapel/views/list.php
DEBUG - 2023-01-18 04:08:18 --> File loaded: C:\xampp\htdocs\myraportk13\application\views\template_utama.php
INFO - 2023-01-18 04:08:18 --> Final output sent to browser
DEBUG - 2023-01-18 04:08:18 --> Total execution time: 0.0822
INFO - 2023-01-18 04:08:18 --> Config Class Initialized
INFO - 2023-01-18 04:08:18 --> Hooks Class Initialized
DEBUG - 2023-01-18 04:08:18 --> UTF-8 Support Enabled
INFO - 2023-01-18 04:08:18 --> Utf8 Class Initialized
INFO - 2023-01-18 04:08:18 --> URI Class Initialized
INFO - 2023-01-18 04:08:18 --> Router Class Initialized
INFO - 2023-01-18 04:08:18 --> Output Class Initialized
INFO - 2023-01-18 04:08:18 --> Security Class Initialized
DEBUG - 2023-01-18 04:08:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-18 04:08:18 --> Input Class Initialized
INFO - 2023-01-18 04:08:18 --> Language Class Initialized
INFO - 2023-01-18 04:08:18 --> Language Class Initialized
INFO - 2023-01-18 04:08:18 --> Config Class Initialized
INFO - 2023-01-18 04:08:18 --> Loader Class Initialized
INFO - 2023-01-18 04:08:18 --> Helper loaded: url_helper
INFO - 2023-01-18 04:08:18 --> Helper loaded: file_helper
INFO - 2023-01-18 04:08:18 --> Helper loaded: form_helper
INFO - 2023-01-18 04:08:18 --> Helper loaded: my_helper
INFO - 2023-01-18 04:08:18 --> Database Driver Class Initialized
DEBUG - 2023-01-18 04:08:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-01-18 04:08:18 --> Session: Class initialized using 'files' driver.
INFO - 2023-01-18 04:08:18 --> Controller Class Initialized
INFO - 2023-01-18 04:08:41 --> Config Class Initialized
INFO - 2023-01-18 04:08:41 --> Hooks Class Initialized
DEBUG - 2023-01-18 04:08:41 --> UTF-8 Support Enabled
INFO - 2023-01-18 04:08:41 --> Utf8 Class Initialized
INFO - 2023-01-18 04:08:41 --> URI Class Initialized
INFO - 2023-01-18 04:08:41 --> Router Class Initialized
INFO - 2023-01-18 04:08:41 --> Output Class Initialized
INFO - 2023-01-18 04:08:41 --> Security Class Initialized
DEBUG - 2023-01-18 04:08:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-18 04:08:41 --> Input Class Initialized
INFO - 2023-01-18 04:08:41 --> Language Class Initialized
INFO - 2023-01-18 04:08:41 --> Language Class Initialized
INFO - 2023-01-18 04:08:41 --> Config Class Initialized
INFO - 2023-01-18 04:08:41 --> Loader Class Initialized
INFO - 2023-01-18 04:08:41 --> Helper loaded: url_helper
INFO - 2023-01-18 04:08:41 --> Helper loaded: file_helper
INFO - 2023-01-18 04:08:41 --> Helper loaded: form_helper
INFO - 2023-01-18 04:08:41 --> Helper loaded: my_helper
INFO - 2023-01-18 04:08:41 --> Database Driver Class Initialized
DEBUG - 2023-01-18 04:08:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-01-18 04:08:41 --> Session: Class initialized using 'files' driver.
INFO - 2023-01-18 04:08:41 --> Controller Class Initialized
DEBUG - 2023-01-18 04:08:41 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/set_mapel/views/list.php
DEBUG - 2023-01-18 04:08:41 --> File loaded: C:\xampp\htdocs\myraportk13\application\views\template_utama.php
INFO - 2023-01-18 04:08:41 --> Final output sent to browser
DEBUG - 2023-01-18 04:08:41 --> Total execution time: 0.0430
INFO - 2023-01-18 04:08:41 --> Config Class Initialized
INFO - 2023-01-18 04:08:41 --> Hooks Class Initialized
DEBUG - 2023-01-18 04:08:41 --> UTF-8 Support Enabled
INFO - 2023-01-18 04:08:41 --> Utf8 Class Initialized
INFO - 2023-01-18 04:08:41 --> URI Class Initialized
INFO - 2023-01-18 04:08:41 --> Router Class Initialized
INFO - 2023-01-18 04:08:41 --> Output Class Initialized
INFO - 2023-01-18 04:08:41 --> Security Class Initialized
DEBUG - 2023-01-18 04:08:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-18 04:08:41 --> Input Class Initialized
INFO - 2023-01-18 04:08:41 --> Language Class Initialized
INFO - 2023-01-18 04:08:41 --> Language Class Initialized
INFO - 2023-01-18 04:08:41 --> Config Class Initialized
INFO - 2023-01-18 04:08:41 --> Loader Class Initialized
INFO - 2023-01-18 04:08:41 --> Helper loaded: url_helper
INFO - 2023-01-18 04:08:41 --> Helper loaded: file_helper
INFO - 2023-01-18 04:08:41 --> Helper loaded: form_helper
INFO - 2023-01-18 04:08:41 --> Helper loaded: my_helper
INFO - 2023-01-18 04:08:41 --> Database Driver Class Initialized
DEBUG - 2023-01-18 04:08:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-01-18 04:08:41 --> Session: Class initialized using 'files' driver.
INFO - 2023-01-18 04:08:41 --> Controller Class Initialized
INFO - 2023-01-18 04:08:44 --> Config Class Initialized
INFO - 2023-01-18 04:08:44 --> Hooks Class Initialized
DEBUG - 2023-01-18 04:08:44 --> UTF-8 Support Enabled
INFO - 2023-01-18 04:08:44 --> Utf8 Class Initialized
INFO - 2023-01-18 04:08:44 --> URI Class Initialized
INFO - 2023-01-18 04:08:44 --> Router Class Initialized
INFO - 2023-01-18 04:08:44 --> Output Class Initialized
INFO - 2023-01-18 04:08:44 --> Security Class Initialized
DEBUG - 2023-01-18 04:08:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-18 04:08:44 --> Input Class Initialized
INFO - 2023-01-18 04:08:44 --> Language Class Initialized
INFO - 2023-01-18 04:08:44 --> Language Class Initialized
INFO - 2023-01-18 04:08:44 --> Config Class Initialized
INFO - 2023-01-18 04:08:44 --> Loader Class Initialized
INFO - 2023-01-18 04:08:44 --> Helper loaded: url_helper
INFO - 2023-01-18 04:08:44 --> Helper loaded: file_helper
INFO - 2023-01-18 04:08:44 --> Helper loaded: form_helper
INFO - 2023-01-18 04:08:44 --> Helper loaded: my_helper
INFO - 2023-01-18 04:08:44 --> Database Driver Class Initialized
DEBUG - 2023-01-18 04:08:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-01-18 04:08:44 --> Session: Class initialized using 'files' driver.
INFO - 2023-01-18 04:08:44 --> Controller Class Initialized
DEBUG - 2023-01-18 04:08:44 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/set_mapel/views/form.php
DEBUG - 2023-01-18 04:08:44 --> File loaded: C:\xampp\htdocs\myraportk13\application\views\template_utama.php
INFO - 2023-01-18 04:08:44 --> Final output sent to browser
DEBUG - 2023-01-18 04:08:44 --> Total execution time: 0.0788
INFO - 2023-01-18 04:10:06 --> Config Class Initialized
INFO - 2023-01-18 04:10:06 --> Hooks Class Initialized
DEBUG - 2023-01-18 04:10:06 --> UTF-8 Support Enabled
INFO - 2023-01-18 04:10:06 --> Utf8 Class Initialized
INFO - 2023-01-18 04:10:06 --> URI Class Initialized
INFO - 2023-01-18 04:10:06 --> Router Class Initialized
INFO - 2023-01-18 04:10:06 --> Output Class Initialized
INFO - 2023-01-18 04:10:06 --> Security Class Initialized
DEBUG - 2023-01-18 04:10:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-18 04:10:06 --> Input Class Initialized
INFO - 2023-01-18 04:10:06 --> Language Class Initialized
INFO - 2023-01-18 04:10:06 --> Language Class Initialized
INFO - 2023-01-18 04:10:06 --> Config Class Initialized
INFO - 2023-01-18 04:10:06 --> Loader Class Initialized
INFO - 2023-01-18 04:10:06 --> Helper loaded: url_helper
INFO - 2023-01-18 04:10:06 --> Helper loaded: file_helper
INFO - 2023-01-18 04:10:06 --> Helper loaded: form_helper
INFO - 2023-01-18 04:10:06 --> Helper loaded: my_helper
INFO - 2023-01-18 04:10:06 --> Database Driver Class Initialized
DEBUG - 2023-01-18 04:10:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-01-18 04:10:06 --> Session: Class initialized using 'files' driver.
INFO - 2023-01-18 04:10:06 --> Controller Class Initialized
INFO - 2023-01-18 04:10:06 --> Config Class Initialized
INFO - 2023-01-18 04:10:06 --> Hooks Class Initialized
DEBUG - 2023-01-18 04:10:06 --> UTF-8 Support Enabled
INFO - 2023-01-18 04:10:06 --> Utf8 Class Initialized
INFO - 2023-01-18 04:10:06 --> URI Class Initialized
INFO - 2023-01-18 04:10:06 --> Router Class Initialized
INFO - 2023-01-18 04:10:06 --> Output Class Initialized
INFO - 2023-01-18 04:10:06 --> Security Class Initialized
DEBUG - 2023-01-18 04:10:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-18 04:10:06 --> Input Class Initialized
INFO - 2023-01-18 04:10:06 --> Language Class Initialized
INFO - 2023-01-18 04:10:06 --> Language Class Initialized
INFO - 2023-01-18 04:10:06 --> Config Class Initialized
INFO - 2023-01-18 04:10:06 --> Loader Class Initialized
INFO - 2023-01-18 04:10:06 --> Helper loaded: url_helper
INFO - 2023-01-18 04:10:06 --> Helper loaded: file_helper
INFO - 2023-01-18 04:10:06 --> Helper loaded: form_helper
INFO - 2023-01-18 04:10:06 --> Helper loaded: my_helper
INFO - 2023-01-18 04:10:06 --> Database Driver Class Initialized
DEBUG - 2023-01-18 04:10:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-01-18 04:10:06 --> Session: Class initialized using 'files' driver.
INFO - 2023-01-18 04:10:06 --> Controller Class Initialized
DEBUG - 2023-01-18 04:10:06 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/set_mapel/views/list.php
DEBUG - 2023-01-18 04:10:06 --> File loaded: C:\xampp\htdocs\myraportk13\application\views\template_utama.php
INFO - 2023-01-18 04:10:06 --> Final output sent to browser
DEBUG - 2023-01-18 04:10:06 --> Total execution time: 0.0367
INFO - 2023-01-18 04:10:06 --> Config Class Initialized
INFO - 2023-01-18 04:10:06 --> Hooks Class Initialized
DEBUG - 2023-01-18 04:10:06 --> UTF-8 Support Enabled
INFO - 2023-01-18 04:10:06 --> Utf8 Class Initialized
INFO - 2023-01-18 04:10:06 --> URI Class Initialized
INFO - 2023-01-18 04:10:06 --> Router Class Initialized
INFO - 2023-01-18 04:10:06 --> Output Class Initialized
INFO - 2023-01-18 04:10:06 --> Security Class Initialized
DEBUG - 2023-01-18 04:10:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-18 04:10:06 --> Input Class Initialized
INFO - 2023-01-18 04:10:06 --> Language Class Initialized
INFO - 2023-01-18 04:10:06 --> Language Class Initialized
INFO - 2023-01-18 04:10:06 --> Config Class Initialized
INFO - 2023-01-18 04:10:06 --> Loader Class Initialized
INFO - 2023-01-18 04:10:06 --> Helper loaded: url_helper
INFO - 2023-01-18 04:10:06 --> Helper loaded: file_helper
INFO - 2023-01-18 04:10:06 --> Helper loaded: form_helper
INFO - 2023-01-18 04:10:06 --> Helper loaded: my_helper
INFO - 2023-01-18 04:10:06 --> Database Driver Class Initialized
DEBUG - 2023-01-18 04:10:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-01-18 04:10:06 --> Session: Class initialized using 'files' driver.
INFO - 2023-01-18 04:10:06 --> Controller Class Initialized
INFO - 2023-01-18 04:10:09 --> Config Class Initialized
INFO - 2023-01-18 04:10:09 --> Hooks Class Initialized
DEBUG - 2023-01-18 04:10:09 --> UTF-8 Support Enabled
INFO - 2023-01-18 04:10:09 --> Utf8 Class Initialized
INFO - 2023-01-18 04:10:09 --> URI Class Initialized
INFO - 2023-01-18 04:10:09 --> Router Class Initialized
INFO - 2023-01-18 04:10:09 --> Output Class Initialized
INFO - 2023-01-18 04:10:09 --> Security Class Initialized
DEBUG - 2023-01-18 04:10:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-18 04:10:09 --> Input Class Initialized
INFO - 2023-01-18 04:10:09 --> Language Class Initialized
INFO - 2023-01-18 04:10:09 --> Language Class Initialized
INFO - 2023-01-18 04:10:09 --> Config Class Initialized
INFO - 2023-01-18 04:10:09 --> Loader Class Initialized
INFO - 2023-01-18 04:10:09 --> Helper loaded: url_helper
INFO - 2023-01-18 04:10:09 --> Helper loaded: file_helper
INFO - 2023-01-18 04:10:09 --> Helper loaded: form_helper
INFO - 2023-01-18 04:10:09 --> Helper loaded: my_helper
INFO - 2023-01-18 04:10:09 --> Database Driver Class Initialized
DEBUG - 2023-01-18 04:10:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-01-18 04:10:09 --> Session: Class initialized using 'files' driver.
INFO - 2023-01-18 04:10:09 --> Controller Class Initialized
INFO - 2023-01-18 04:10:09 --> Helper loaded: cookie_helper
INFO - 2023-01-18 04:10:09 --> Config Class Initialized
INFO - 2023-01-18 04:10:09 --> Hooks Class Initialized
DEBUG - 2023-01-18 04:10:09 --> UTF-8 Support Enabled
INFO - 2023-01-18 04:10:09 --> Utf8 Class Initialized
INFO - 2023-01-18 04:10:09 --> URI Class Initialized
INFO - 2023-01-18 04:10:09 --> Router Class Initialized
INFO - 2023-01-18 04:10:09 --> Output Class Initialized
INFO - 2023-01-18 04:10:09 --> Security Class Initialized
DEBUG - 2023-01-18 04:10:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-18 04:10:09 --> Input Class Initialized
INFO - 2023-01-18 04:10:09 --> Language Class Initialized
INFO - 2023-01-18 04:10:09 --> Language Class Initialized
INFO - 2023-01-18 04:10:09 --> Config Class Initialized
INFO - 2023-01-18 04:10:09 --> Loader Class Initialized
INFO - 2023-01-18 04:10:09 --> Helper loaded: url_helper
INFO - 2023-01-18 04:10:09 --> Helper loaded: file_helper
INFO - 2023-01-18 04:10:09 --> Helper loaded: form_helper
INFO - 2023-01-18 04:10:09 --> Helper loaded: my_helper
INFO - 2023-01-18 04:10:09 --> Database Driver Class Initialized
DEBUG - 2023-01-18 04:10:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-01-18 04:10:09 --> Session: Class initialized using 'files' driver.
INFO - 2023-01-18 04:10:09 --> Controller Class Initialized
INFO - 2023-01-18 04:10:09 --> Config Class Initialized
INFO - 2023-01-18 04:10:09 --> Hooks Class Initialized
DEBUG - 2023-01-18 04:10:09 --> UTF-8 Support Enabled
INFO - 2023-01-18 04:10:09 --> Utf8 Class Initialized
INFO - 2023-01-18 04:10:09 --> URI Class Initialized
INFO - 2023-01-18 04:10:09 --> Router Class Initialized
INFO - 2023-01-18 04:10:09 --> Output Class Initialized
INFO - 2023-01-18 04:10:09 --> Security Class Initialized
DEBUG - 2023-01-18 04:10:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-18 04:10:09 --> Input Class Initialized
INFO - 2023-01-18 04:10:09 --> Language Class Initialized
INFO - 2023-01-18 04:10:09 --> Language Class Initialized
INFO - 2023-01-18 04:10:09 --> Config Class Initialized
INFO - 2023-01-18 04:10:09 --> Loader Class Initialized
INFO - 2023-01-18 04:10:09 --> Helper loaded: url_helper
INFO - 2023-01-18 04:10:09 --> Helper loaded: file_helper
INFO - 2023-01-18 04:10:09 --> Helper loaded: form_helper
INFO - 2023-01-18 04:10:09 --> Helper loaded: my_helper
INFO - 2023-01-18 04:10:09 --> Database Driver Class Initialized
DEBUG - 2023-01-18 04:10:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-01-18 04:10:09 --> Session: Class initialized using 'files' driver.
INFO - 2023-01-18 04:10:09 --> Controller Class Initialized
DEBUG - 2023-01-18 04:10:09 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/login/views/login.php
DEBUG - 2023-01-18 04:10:09 --> File loaded: C:\xampp\htdocs\myraportk13\application\views\template_utama.php
INFO - 2023-01-18 04:10:09 --> Final output sent to browser
DEBUG - 2023-01-18 04:10:09 --> Total execution time: 0.0250
INFO - 2023-01-18 04:10:15 --> Config Class Initialized
INFO - 2023-01-18 04:10:15 --> Hooks Class Initialized
DEBUG - 2023-01-18 04:10:15 --> UTF-8 Support Enabled
INFO - 2023-01-18 04:10:15 --> Utf8 Class Initialized
INFO - 2023-01-18 04:10:15 --> URI Class Initialized
INFO - 2023-01-18 04:10:15 --> Router Class Initialized
INFO - 2023-01-18 04:10:15 --> Output Class Initialized
INFO - 2023-01-18 04:10:15 --> Security Class Initialized
DEBUG - 2023-01-18 04:10:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-18 04:10:15 --> Input Class Initialized
INFO - 2023-01-18 04:10:15 --> Language Class Initialized
INFO - 2023-01-18 04:10:15 --> Language Class Initialized
INFO - 2023-01-18 04:10:15 --> Config Class Initialized
INFO - 2023-01-18 04:10:15 --> Loader Class Initialized
INFO - 2023-01-18 04:10:15 --> Helper loaded: url_helper
INFO - 2023-01-18 04:10:15 --> Helper loaded: file_helper
INFO - 2023-01-18 04:10:15 --> Helper loaded: form_helper
INFO - 2023-01-18 04:10:15 --> Helper loaded: my_helper
INFO - 2023-01-18 04:10:15 --> Database Driver Class Initialized
DEBUG - 2023-01-18 04:10:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-01-18 04:10:15 --> Session: Class initialized using 'files' driver.
INFO - 2023-01-18 04:10:15 --> Controller Class Initialized
INFO - 2023-01-18 04:10:15 --> Helper loaded: cookie_helper
INFO - 2023-01-18 04:10:15 --> Final output sent to browser
DEBUG - 2023-01-18 04:10:15 --> Total execution time: 0.0366
INFO - 2023-01-18 04:10:15 --> Config Class Initialized
INFO - 2023-01-18 04:10:15 --> Hooks Class Initialized
DEBUG - 2023-01-18 04:10:15 --> UTF-8 Support Enabled
INFO - 2023-01-18 04:10:15 --> Utf8 Class Initialized
INFO - 2023-01-18 04:10:15 --> URI Class Initialized
INFO - 2023-01-18 04:10:15 --> Router Class Initialized
INFO - 2023-01-18 04:10:15 --> Output Class Initialized
INFO - 2023-01-18 04:10:15 --> Security Class Initialized
DEBUG - 2023-01-18 04:10:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-18 04:10:15 --> Input Class Initialized
INFO - 2023-01-18 04:10:15 --> Language Class Initialized
INFO - 2023-01-18 04:10:15 --> Language Class Initialized
INFO - 2023-01-18 04:10:15 --> Config Class Initialized
INFO - 2023-01-18 04:10:15 --> Loader Class Initialized
INFO - 2023-01-18 04:10:15 --> Helper loaded: url_helper
INFO - 2023-01-18 04:10:15 --> Helper loaded: file_helper
INFO - 2023-01-18 04:10:15 --> Helper loaded: form_helper
INFO - 2023-01-18 04:10:15 --> Helper loaded: my_helper
INFO - 2023-01-18 04:10:15 --> Database Driver Class Initialized
DEBUG - 2023-01-18 04:10:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-01-18 04:10:15 --> Session: Class initialized using 'files' driver.
INFO - 2023-01-18 04:10:15 --> Controller Class Initialized
DEBUG - 2023-01-18 04:10:15 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/home/views/v_home_guru.php
DEBUG - 2023-01-18 04:10:15 --> File loaded: C:\xampp\htdocs\myraportk13\application\views\template_utama.php
INFO - 2023-01-18 04:10:15 --> Final output sent to browser
DEBUG - 2023-01-18 04:10:15 --> Total execution time: 0.0497
INFO - 2023-01-18 04:10:16 --> Config Class Initialized
INFO - 2023-01-18 04:10:16 --> Hooks Class Initialized
DEBUG - 2023-01-18 04:10:16 --> UTF-8 Support Enabled
INFO - 2023-01-18 04:10:16 --> Utf8 Class Initialized
INFO - 2023-01-18 04:10:16 --> URI Class Initialized
INFO - 2023-01-18 04:10:16 --> Router Class Initialized
INFO - 2023-01-18 04:10:16 --> Output Class Initialized
INFO - 2023-01-18 04:10:16 --> Security Class Initialized
DEBUG - 2023-01-18 04:10:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-18 04:10:16 --> Input Class Initialized
INFO - 2023-01-18 04:10:16 --> Language Class Initialized
INFO - 2023-01-18 04:10:16 --> Language Class Initialized
INFO - 2023-01-18 04:10:16 --> Config Class Initialized
INFO - 2023-01-18 04:10:16 --> Loader Class Initialized
INFO - 2023-01-18 04:10:16 --> Helper loaded: url_helper
INFO - 2023-01-18 04:10:16 --> Helper loaded: file_helper
INFO - 2023-01-18 04:10:16 --> Helper loaded: form_helper
INFO - 2023-01-18 04:10:16 --> Helper loaded: my_helper
INFO - 2023-01-18 04:10:16 --> Database Driver Class Initialized
DEBUG - 2023-01-18 04:10:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-01-18 04:10:16 --> Session: Class initialized using 'files' driver.
INFO - 2023-01-18 04:10:16 --> Controller Class Initialized
DEBUG - 2023-01-18 04:10:16 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/view_mapel/views/v_view_mapel.php
DEBUG - 2023-01-18 04:10:16 --> File loaded: C:\xampp\htdocs\myraportk13\application\views\template_utama.php
INFO - 2023-01-18 04:10:16 --> Final output sent to browser
DEBUG - 2023-01-18 04:10:16 --> Total execution time: 0.0354
INFO - 2023-01-18 04:10:20 --> Config Class Initialized
INFO - 2023-01-18 04:10:20 --> Hooks Class Initialized
DEBUG - 2023-01-18 04:10:20 --> UTF-8 Support Enabled
INFO - 2023-01-18 04:10:20 --> Utf8 Class Initialized
INFO - 2023-01-18 04:10:20 --> URI Class Initialized
INFO - 2023-01-18 04:10:20 --> Router Class Initialized
INFO - 2023-01-18 04:10:20 --> Output Class Initialized
INFO - 2023-01-18 04:10:20 --> Security Class Initialized
DEBUG - 2023-01-18 04:10:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-18 04:10:20 --> Input Class Initialized
INFO - 2023-01-18 04:10:20 --> Language Class Initialized
INFO - 2023-01-18 04:10:20 --> Language Class Initialized
INFO - 2023-01-18 04:10:20 --> Config Class Initialized
INFO - 2023-01-18 04:10:20 --> Loader Class Initialized
INFO - 2023-01-18 04:10:20 --> Helper loaded: url_helper
INFO - 2023-01-18 04:10:20 --> Helper loaded: file_helper
INFO - 2023-01-18 04:10:20 --> Helper loaded: form_helper
INFO - 2023-01-18 04:10:20 --> Helper loaded: my_helper
INFO - 2023-01-18 04:10:20 --> Database Driver Class Initialized
DEBUG - 2023-01-18 04:10:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-01-18 04:10:20 --> Session: Class initialized using 'files' driver.
INFO - 2023-01-18 04:10:20 --> Controller Class Initialized
DEBUG - 2023-01-18 04:10:20 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/n_pengetahuan/views/list.php
DEBUG - 2023-01-18 04:10:20 --> File loaded: C:\xampp\htdocs\myraportk13\application\views\template_utama.php
INFO - 2023-01-18 04:10:20 --> Final output sent to browser
DEBUG - 2023-01-18 04:10:20 --> Total execution time: 0.0502
INFO - 2023-01-18 04:10:20 --> Config Class Initialized
INFO - 2023-01-18 04:10:20 --> Hooks Class Initialized
DEBUG - 2023-01-18 04:10:20 --> UTF-8 Support Enabled
INFO - 2023-01-18 04:10:20 --> Utf8 Class Initialized
INFO - 2023-01-18 04:10:20 --> URI Class Initialized
INFO - 2023-01-18 04:10:20 --> Router Class Initialized
INFO - 2023-01-18 04:10:20 --> Output Class Initialized
INFO - 2023-01-18 04:10:20 --> Security Class Initialized
DEBUG - 2023-01-18 04:10:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-18 04:10:20 --> Input Class Initialized
INFO - 2023-01-18 04:10:20 --> Language Class Initialized
INFO - 2023-01-18 04:10:20 --> Language Class Initialized
INFO - 2023-01-18 04:10:20 --> Config Class Initialized
INFO - 2023-01-18 04:10:20 --> Loader Class Initialized
INFO - 2023-01-18 04:10:20 --> Helper loaded: url_helper
INFO - 2023-01-18 04:10:20 --> Helper loaded: file_helper
INFO - 2023-01-18 04:10:20 --> Helper loaded: form_helper
INFO - 2023-01-18 04:10:20 --> Helper loaded: my_helper
INFO - 2023-01-18 04:10:20 --> Database Driver Class Initialized
DEBUG - 2023-01-18 04:10:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-01-18 04:10:20 --> Session: Class initialized using 'files' driver.
INFO - 2023-01-18 04:10:20 --> Controller Class Initialized
INFO - 2023-01-18 04:10:21 --> Config Class Initialized
INFO - 2023-01-18 04:10:21 --> Hooks Class Initialized
DEBUG - 2023-01-18 04:10:21 --> UTF-8 Support Enabled
INFO - 2023-01-18 04:10:21 --> Utf8 Class Initialized
INFO - 2023-01-18 04:10:21 --> URI Class Initialized
INFO - 2023-01-18 04:10:21 --> Router Class Initialized
INFO - 2023-01-18 04:10:21 --> Output Class Initialized
INFO - 2023-01-18 04:10:21 --> Security Class Initialized
DEBUG - 2023-01-18 04:10:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-18 04:10:21 --> Input Class Initialized
INFO - 2023-01-18 04:10:21 --> Language Class Initialized
INFO - 2023-01-18 04:10:21 --> Language Class Initialized
INFO - 2023-01-18 04:10:21 --> Config Class Initialized
INFO - 2023-01-18 04:10:21 --> Loader Class Initialized
INFO - 2023-01-18 04:10:21 --> Helper loaded: url_helper
INFO - 2023-01-18 04:10:21 --> Helper loaded: file_helper
INFO - 2023-01-18 04:10:21 --> Helper loaded: form_helper
INFO - 2023-01-18 04:10:21 --> Helper loaded: my_helper
INFO - 2023-01-18 04:10:21 --> Database Driver Class Initialized
DEBUG - 2023-01-18 04:10:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-01-18 04:10:21 --> Session: Class initialized using 'files' driver.
INFO - 2023-01-18 04:10:21 --> Controller Class Initialized
INFO - 2023-01-18 04:10:21 --> Final output sent to browser
DEBUG - 2023-01-18 04:10:21 --> Total execution time: 0.0276
INFO - 2023-01-18 04:10:25 --> Config Class Initialized
INFO - 2023-01-18 04:10:25 --> Hooks Class Initialized
DEBUG - 2023-01-18 04:10:25 --> UTF-8 Support Enabled
INFO - 2023-01-18 04:10:25 --> Utf8 Class Initialized
INFO - 2023-01-18 04:10:25 --> URI Class Initialized
INFO - 2023-01-18 04:10:25 --> Router Class Initialized
INFO - 2023-01-18 04:10:25 --> Output Class Initialized
INFO - 2023-01-18 04:10:25 --> Security Class Initialized
DEBUG - 2023-01-18 04:10:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-18 04:10:25 --> Input Class Initialized
INFO - 2023-01-18 04:10:25 --> Language Class Initialized
INFO - 2023-01-18 04:10:25 --> Language Class Initialized
INFO - 2023-01-18 04:10:25 --> Config Class Initialized
INFO - 2023-01-18 04:10:25 --> Loader Class Initialized
INFO - 2023-01-18 04:10:25 --> Helper loaded: url_helper
INFO - 2023-01-18 04:10:25 --> Helper loaded: file_helper
INFO - 2023-01-18 04:10:25 --> Helper loaded: form_helper
INFO - 2023-01-18 04:10:25 --> Helper loaded: my_helper
INFO - 2023-01-18 04:10:25 --> Database Driver Class Initialized
DEBUG - 2023-01-18 04:10:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-01-18 04:10:25 --> Session: Class initialized using 'files' driver.
INFO - 2023-01-18 04:10:25 --> Controller Class Initialized
INFO - 2023-01-18 04:10:25 --> Final output sent to browser
DEBUG - 2023-01-18 04:10:25 --> Total execution time: 0.0352
INFO - 2023-01-18 04:10:25 --> Config Class Initialized
INFO - 2023-01-18 04:10:25 --> Hooks Class Initialized
DEBUG - 2023-01-18 04:10:25 --> UTF-8 Support Enabled
INFO - 2023-01-18 04:10:25 --> Utf8 Class Initialized
INFO - 2023-01-18 04:10:25 --> URI Class Initialized
INFO - 2023-01-18 04:10:25 --> Router Class Initialized
INFO - 2023-01-18 04:10:25 --> Output Class Initialized
INFO - 2023-01-18 04:10:25 --> Security Class Initialized
DEBUG - 2023-01-18 04:10:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-18 04:10:25 --> Input Class Initialized
INFO - 2023-01-18 04:10:25 --> Language Class Initialized
INFO - 2023-01-18 04:10:25 --> Language Class Initialized
INFO - 2023-01-18 04:10:25 --> Config Class Initialized
INFO - 2023-01-18 04:10:25 --> Loader Class Initialized
INFO - 2023-01-18 04:10:25 --> Helper loaded: url_helper
INFO - 2023-01-18 04:10:25 --> Helper loaded: file_helper
INFO - 2023-01-18 04:10:25 --> Helper loaded: form_helper
INFO - 2023-01-18 04:10:25 --> Helper loaded: my_helper
INFO - 2023-01-18 04:10:25 --> Database Driver Class Initialized
DEBUG - 2023-01-18 04:10:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-01-18 04:10:25 --> Session: Class initialized using 'files' driver.
INFO - 2023-01-18 04:10:25 --> Controller Class Initialized
INFO - 2023-01-18 04:10:26 --> Config Class Initialized
INFO - 2023-01-18 04:10:26 --> Hooks Class Initialized
DEBUG - 2023-01-18 04:10:26 --> UTF-8 Support Enabled
INFO - 2023-01-18 04:10:26 --> Utf8 Class Initialized
INFO - 2023-01-18 04:10:26 --> URI Class Initialized
INFO - 2023-01-18 04:10:26 --> Router Class Initialized
INFO - 2023-01-18 04:10:26 --> Output Class Initialized
INFO - 2023-01-18 04:10:26 --> Security Class Initialized
DEBUG - 2023-01-18 04:10:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-18 04:10:26 --> Input Class Initialized
INFO - 2023-01-18 04:10:26 --> Language Class Initialized
INFO - 2023-01-18 04:10:26 --> Language Class Initialized
INFO - 2023-01-18 04:10:26 --> Config Class Initialized
INFO - 2023-01-18 04:10:26 --> Loader Class Initialized
INFO - 2023-01-18 04:10:26 --> Helper loaded: url_helper
INFO - 2023-01-18 04:10:26 --> Helper loaded: file_helper
INFO - 2023-01-18 04:10:26 --> Helper loaded: form_helper
INFO - 2023-01-18 04:10:26 --> Helper loaded: my_helper
INFO - 2023-01-18 04:10:26 --> Database Driver Class Initialized
DEBUG - 2023-01-18 04:10:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-01-18 04:10:26 --> Session: Class initialized using 'files' driver.
INFO - 2023-01-18 04:10:26 --> Controller Class Initialized
INFO - 2023-01-18 04:10:26 --> Final output sent to browser
DEBUG - 2023-01-18 04:10:26 --> Total execution time: 0.0396
INFO - 2023-01-18 04:10:29 --> Config Class Initialized
INFO - 2023-01-18 04:10:29 --> Hooks Class Initialized
DEBUG - 2023-01-18 04:10:29 --> UTF-8 Support Enabled
INFO - 2023-01-18 04:10:29 --> Utf8 Class Initialized
INFO - 2023-01-18 04:10:29 --> URI Class Initialized
INFO - 2023-01-18 04:10:29 --> Router Class Initialized
INFO - 2023-01-18 04:10:29 --> Output Class Initialized
INFO - 2023-01-18 04:10:29 --> Security Class Initialized
DEBUG - 2023-01-18 04:10:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-18 04:10:29 --> Input Class Initialized
INFO - 2023-01-18 04:10:29 --> Language Class Initialized
INFO - 2023-01-18 04:10:29 --> Language Class Initialized
INFO - 2023-01-18 04:10:29 --> Config Class Initialized
INFO - 2023-01-18 04:10:29 --> Loader Class Initialized
INFO - 2023-01-18 04:10:29 --> Helper loaded: url_helper
INFO - 2023-01-18 04:10:29 --> Helper loaded: file_helper
INFO - 2023-01-18 04:10:29 --> Helper loaded: form_helper
INFO - 2023-01-18 04:10:29 --> Helper loaded: my_helper
INFO - 2023-01-18 04:10:29 --> Database Driver Class Initialized
DEBUG - 2023-01-18 04:10:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-01-18 04:10:29 --> Session: Class initialized using 'files' driver.
INFO - 2023-01-18 04:10:29 --> Controller Class Initialized
INFO - 2023-01-18 04:10:29 --> Final output sent to browser
DEBUG - 2023-01-18 04:10:29 --> Total execution time: 0.0323
INFO - 2023-01-18 04:10:29 --> Config Class Initialized
INFO - 2023-01-18 04:10:29 --> Hooks Class Initialized
DEBUG - 2023-01-18 04:10:29 --> UTF-8 Support Enabled
INFO - 2023-01-18 04:10:29 --> Utf8 Class Initialized
INFO - 2023-01-18 04:10:29 --> URI Class Initialized
INFO - 2023-01-18 04:10:29 --> Router Class Initialized
INFO - 2023-01-18 04:10:29 --> Output Class Initialized
INFO - 2023-01-18 04:10:29 --> Security Class Initialized
DEBUG - 2023-01-18 04:10:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-18 04:10:29 --> Input Class Initialized
INFO - 2023-01-18 04:10:29 --> Language Class Initialized
INFO - 2023-01-18 04:10:29 --> Language Class Initialized
INFO - 2023-01-18 04:10:29 --> Config Class Initialized
INFO - 2023-01-18 04:10:29 --> Loader Class Initialized
INFO - 2023-01-18 04:10:29 --> Helper loaded: url_helper
INFO - 2023-01-18 04:10:29 --> Helper loaded: file_helper
INFO - 2023-01-18 04:10:29 --> Helper loaded: form_helper
INFO - 2023-01-18 04:10:29 --> Helper loaded: my_helper
INFO - 2023-01-18 04:10:29 --> Database Driver Class Initialized
DEBUG - 2023-01-18 04:10:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-01-18 04:10:29 --> Session: Class initialized using 'files' driver.
INFO - 2023-01-18 04:10:29 --> Controller Class Initialized
INFO - 2023-01-18 04:10:36 --> Config Class Initialized
INFO - 2023-01-18 04:10:36 --> Hooks Class Initialized
DEBUG - 2023-01-18 04:10:36 --> UTF-8 Support Enabled
INFO - 2023-01-18 04:10:36 --> Utf8 Class Initialized
INFO - 2023-01-18 04:10:36 --> URI Class Initialized
INFO - 2023-01-18 04:10:36 --> Router Class Initialized
INFO - 2023-01-18 04:10:36 --> Output Class Initialized
INFO - 2023-01-18 04:10:36 --> Security Class Initialized
DEBUG - 2023-01-18 04:10:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-18 04:10:36 --> Input Class Initialized
INFO - 2023-01-18 04:10:36 --> Language Class Initialized
INFO - 2023-01-18 04:10:36 --> Language Class Initialized
INFO - 2023-01-18 04:10:36 --> Config Class Initialized
INFO - 2023-01-18 04:10:36 --> Loader Class Initialized
INFO - 2023-01-18 04:10:36 --> Helper loaded: url_helper
INFO - 2023-01-18 04:10:36 --> Helper loaded: file_helper
INFO - 2023-01-18 04:10:36 --> Helper loaded: form_helper
INFO - 2023-01-18 04:10:36 --> Helper loaded: my_helper
INFO - 2023-01-18 04:10:36 --> Database Driver Class Initialized
DEBUG - 2023-01-18 04:10:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-01-18 04:10:36 --> Session: Class initialized using 'files' driver.
INFO - 2023-01-18 04:10:36 --> Controller Class Initialized
INFO - 2023-01-18 04:10:36 --> Helper loaded: cookie_helper
INFO - 2023-01-18 04:10:36 --> Config Class Initialized
INFO - 2023-01-18 04:10:36 --> Hooks Class Initialized
DEBUG - 2023-01-18 04:10:36 --> UTF-8 Support Enabled
INFO - 2023-01-18 04:10:36 --> Utf8 Class Initialized
INFO - 2023-01-18 04:10:36 --> URI Class Initialized
INFO - 2023-01-18 04:10:36 --> Router Class Initialized
INFO - 2023-01-18 04:10:36 --> Output Class Initialized
INFO - 2023-01-18 04:10:36 --> Security Class Initialized
DEBUG - 2023-01-18 04:10:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-18 04:10:36 --> Input Class Initialized
INFO - 2023-01-18 04:10:36 --> Language Class Initialized
INFO - 2023-01-18 04:10:36 --> Language Class Initialized
INFO - 2023-01-18 04:10:36 --> Config Class Initialized
INFO - 2023-01-18 04:10:36 --> Loader Class Initialized
INFO - 2023-01-18 04:10:36 --> Helper loaded: url_helper
INFO - 2023-01-18 04:10:36 --> Helper loaded: file_helper
INFO - 2023-01-18 04:10:36 --> Helper loaded: form_helper
INFO - 2023-01-18 04:10:36 --> Helper loaded: my_helper
INFO - 2023-01-18 04:10:36 --> Database Driver Class Initialized
DEBUG - 2023-01-18 04:10:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-01-18 04:10:36 --> Session: Class initialized using 'files' driver.
INFO - 2023-01-18 04:10:36 --> Controller Class Initialized
INFO - 2023-01-18 04:10:36 --> Config Class Initialized
INFO - 2023-01-18 04:10:36 --> Hooks Class Initialized
DEBUG - 2023-01-18 04:10:36 --> UTF-8 Support Enabled
INFO - 2023-01-18 04:10:36 --> Utf8 Class Initialized
INFO - 2023-01-18 04:10:36 --> URI Class Initialized
INFO - 2023-01-18 04:10:36 --> Router Class Initialized
INFO - 2023-01-18 04:10:36 --> Output Class Initialized
INFO - 2023-01-18 04:10:36 --> Security Class Initialized
DEBUG - 2023-01-18 04:10:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-18 04:10:36 --> Input Class Initialized
INFO - 2023-01-18 04:10:36 --> Language Class Initialized
INFO - 2023-01-18 04:10:36 --> Language Class Initialized
INFO - 2023-01-18 04:10:36 --> Config Class Initialized
INFO - 2023-01-18 04:10:36 --> Loader Class Initialized
INFO - 2023-01-18 04:10:36 --> Helper loaded: url_helper
INFO - 2023-01-18 04:10:36 --> Helper loaded: file_helper
INFO - 2023-01-18 04:10:36 --> Helper loaded: form_helper
INFO - 2023-01-18 04:10:36 --> Helper loaded: my_helper
INFO - 2023-01-18 04:10:36 --> Database Driver Class Initialized
DEBUG - 2023-01-18 04:10:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-01-18 04:10:36 --> Session: Class initialized using 'files' driver.
INFO - 2023-01-18 04:10:36 --> Controller Class Initialized
DEBUG - 2023-01-18 04:10:36 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/login/views/login.php
DEBUG - 2023-01-18 04:10:36 --> File loaded: C:\xampp\htdocs\myraportk13\application\views\template_utama.php
INFO - 2023-01-18 04:10:36 --> Final output sent to browser
DEBUG - 2023-01-18 04:10:36 --> Total execution time: 0.0439
INFO - 2023-01-18 04:10:41 --> Config Class Initialized
INFO - 2023-01-18 04:10:41 --> Hooks Class Initialized
DEBUG - 2023-01-18 04:10:41 --> UTF-8 Support Enabled
INFO - 2023-01-18 04:10:41 --> Utf8 Class Initialized
INFO - 2023-01-18 04:10:41 --> URI Class Initialized
INFO - 2023-01-18 04:10:41 --> Router Class Initialized
INFO - 2023-01-18 04:10:41 --> Output Class Initialized
INFO - 2023-01-18 04:10:41 --> Security Class Initialized
DEBUG - 2023-01-18 04:10:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-18 04:10:41 --> Input Class Initialized
INFO - 2023-01-18 04:10:41 --> Language Class Initialized
INFO - 2023-01-18 04:10:41 --> Language Class Initialized
INFO - 2023-01-18 04:10:41 --> Config Class Initialized
INFO - 2023-01-18 04:10:41 --> Loader Class Initialized
INFO - 2023-01-18 04:10:41 --> Helper loaded: url_helper
INFO - 2023-01-18 04:10:41 --> Helper loaded: file_helper
INFO - 2023-01-18 04:10:41 --> Helper loaded: form_helper
INFO - 2023-01-18 04:10:41 --> Helper loaded: my_helper
INFO - 2023-01-18 04:10:41 --> Database Driver Class Initialized
DEBUG - 2023-01-18 04:10:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-01-18 04:10:41 --> Session: Class initialized using 'files' driver.
INFO - 2023-01-18 04:10:41 --> Controller Class Initialized
INFO - 2023-01-18 04:10:41 --> Helper loaded: cookie_helper
INFO - 2023-01-18 04:10:41 --> Final output sent to browser
DEBUG - 2023-01-18 04:10:41 --> Total execution time: 0.0250
INFO - 2023-01-18 04:10:41 --> Config Class Initialized
INFO - 2023-01-18 04:10:41 --> Hooks Class Initialized
DEBUG - 2023-01-18 04:10:41 --> UTF-8 Support Enabled
INFO - 2023-01-18 04:10:41 --> Utf8 Class Initialized
INFO - 2023-01-18 04:10:41 --> URI Class Initialized
INFO - 2023-01-18 04:10:41 --> Router Class Initialized
INFO - 2023-01-18 04:10:41 --> Output Class Initialized
INFO - 2023-01-18 04:10:41 --> Security Class Initialized
DEBUG - 2023-01-18 04:10:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-18 04:10:41 --> Input Class Initialized
INFO - 2023-01-18 04:10:41 --> Language Class Initialized
INFO - 2023-01-18 04:10:41 --> Language Class Initialized
INFO - 2023-01-18 04:10:41 --> Config Class Initialized
INFO - 2023-01-18 04:10:41 --> Loader Class Initialized
INFO - 2023-01-18 04:10:41 --> Helper loaded: url_helper
INFO - 2023-01-18 04:10:41 --> Helper loaded: file_helper
INFO - 2023-01-18 04:10:41 --> Helper loaded: form_helper
INFO - 2023-01-18 04:10:41 --> Helper loaded: my_helper
INFO - 2023-01-18 04:10:41 --> Database Driver Class Initialized
DEBUG - 2023-01-18 04:10:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-01-18 04:10:41 --> Session: Class initialized using 'files' driver.
INFO - 2023-01-18 04:10:41 --> Controller Class Initialized
DEBUG - 2023-01-18 04:10:41 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/home/views/v_home.php
DEBUG - 2023-01-18 04:10:41 --> File loaded: C:\xampp\htdocs\myraportk13\application\views\template_utama.php
INFO - 2023-01-18 04:10:41 --> Final output sent to browser
DEBUG - 2023-01-18 04:10:41 --> Total execution time: 0.0346
INFO - 2023-01-18 04:10:43 --> Config Class Initialized
INFO - 2023-01-18 04:10:43 --> Hooks Class Initialized
DEBUG - 2023-01-18 04:10:43 --> UTF-8 Support Enabled
INFO - 2023-01-18 04:10:43 --> Utf8 Class Initialized
INFO - 2023-01-18 04:10:43 --> URI Class Initialized
INFO - 2023-01-18 04:10:43 --> Router Class Initialized
INFO - 2023-01-18 04:10:43 --> Output Class Initialized
INFO - 2023-01-18 04:10:43 --> Security Class Initialized
DEBUG - 2023-01-18 04:10:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-18 04:10:43 --> Input Class Initialized
INFO - 2023-01-18 04:10:43 --> Language Class Initialized
INFO - 2023-01-18 04:10:43 --> Language Class Initialized
INFO - 2023-01-18 04:10:43 --> Config Class Initialized
INFO - 2023-01-18 04:10:43 --> Loader Class Initialized
INFO - 2023-01-18 04:10:43 --> Helper loaded: url_helper
INFO - 2023-01-18 04:10:43 --> Helper loaded: file_helper
INFO - 2023-01-18 04:10:43 --> Helper loaded: form_helper
INFO - 2023-01-18 04:10:43 --> Helper loaded: my_helper
INFO - 2023-01-18 04:10:43 --> Database Driver Class Initialized
DEBUG - 2023-01-18 04:10:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-01-18 04:10:43 --> Session: Class initialized using 'files' driver.
INFO - 2023-01-18 04:10:43 --> Controller Class Initialized
DEBUG - 2023-01-18 04:10:43 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/set_mapel/views/list.php
DEBUG - 2023-01-18 04:10:43 --> File loaded: C:\xampp\htdocs\myraportk13\application\views\template_utama.php
INFO - 2023-01-18 04:10:43 --> Final output sent to browser
DEBUG - 2023-01-18 04:10:43 --> Total execution time: 0.0335
INFO - 2023-01-18 04:10:43 --> Config Class Initialized
INFO - 2023-01-18 04:10:43 --> Hooks Class Initialized
DEBUG - 2023-01-18 04:10:43 --> UTF-8 Support Enabled
INFO - 2023-01-18 04:10:43 --> Utf8 Class Initialized
INFO - 2023-01-18 04:10:43 --> URI Class Initialized
INFO - 2023-01-18 04:10:43 --> Router Class Initialized
INFO - 2023-01-18 04:10:43 --> Output Class Initialized
INFO - 2023-01-18 04:10:43 --> Security Class Initialized
DEBUG - 2023-01-18 04:10:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-18 04:10:43 --> Input Class Initialized
INFO - 2023-01-18 04:10:43 --> Language Class Initialized
INFO - 2023-01-18 04:10:43 --> Language Class Initialized
INFO - 2023-01-18 04:10:43 --> Config Class Initialized
INFO - 2023-01-18 04:10:43 --> Loader Class Initialized
INFO - 2023-01-18 04:10:43 --> Helper loaded: url_helper
INFO - 2023-01-18 04:10:43 --> Helper loaded: file_helper
INFO - 2023-01-18 04:10:43 --> Helper loaded: form_helper
INFO - 2023-01-18 04:10:43 --> Helper loaded: my_helper
INFO - 2023-01-18 04:10:43 --> Database Driver Class Initialized
DEBUG - 2023-01-18 04:10:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-01-18 04:10:43 --> Session: Class initialized using 'files' driver.
INFO - 2023-01-18 04:10:43 --> Controller Class Initialized
INFO - 2023-01-18 04:10:48 --> Config Class Initialized
INFO - 2023-01-18 04:10:48 --> Hooks Class Initialized
DEBUG - 2023-01-18 04:10:48 --> UTF-8 Support Enabled
INFO - 2023-01-18 04:10:48 --> Utf8 Class Initialized
INFO - 2023-01-18 04:10:48 --> URI Class Initialized
INFO - 2023-01-18 04:10:48 --> Router Class Initialized
INFO - 2023-01-18 04:10:48 --> Output Class Initialized
INFO - 2023-01-18 04:10:48 --> Security Class Initialized
DEBUG - 2023-01-18 04:10:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-18 04:10:48 --> Input Class Initialized
INFO - 2023-01-18 04:10:48 --> Language Class Initialized
INFO - 2023-01-18 04:10:48 --> Language Class Initialized
INFO - 2023-01-18 04:10:48 --> Config Class Initialized
INFO - 2023-01-18 04:10:48 --> Loader Class Initialized
INFO - 2023-01-18 04:10:48 --> Helper loaded: url_helper
INFO - 2023-01-18 04:10:48 --> Helper loaded: file_helper
INFO - 2023-01-18 04:10:48 --> Helper loaded: form_helper
INFO - 2023-01-18 04:10:48 --> Helper loaded: my_helper
INFO - 2023-01-18 04:10:48 --> Database Driver Class Initialized
DEBUG - 2023-01-18 04:10:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-01-18 04:10:48 --> Session: Class initialized using 'files' driver.
INFO - 2023-01-18 04:10:48 --> Controller Class Initialized
INFO - 2023-01-18 04:10:48 --> Final output sent to browser
DEBUG - 2023-01-18 04:10:48 --> Total execution time: 0.0494
INFO - 2023-01-18 04:10:48 --> Config Class Initialized
INFO - 2023-01-18 04:10:48 --> Hooks Class Initialized
DEBUG - 2023-01-18 04:10:48 --> UTF-8 Support Enabled
INFO - 2023-01-18 04:10:48 --> Utf8 Class Initialized
INFO - 2023-01-18 04:10:48 --> URI Class Initialized
INFO - 2023-01-18 04:10:48 --> Router Class Initialized
INFO - 2023-01-18 04:10:48 --> Output Class Initialized
INFO - 2023-01-18 04:10:48 --> Security Class Initialized
DEBUG - 2023-01-18 04:10:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-18 04:10:48 --> Input Class Initialized
INFO - 2023-01-18 04:10:48 --> Language Class Initialized
INFO - 2023-01-18 04:10:48 --> Language Class Initialized
INFO - 2023-01-18 04:10:48 --> Config Class Initialized
INFO - 2023-01-18 04:10:48 --> Loader Class Initialized
INFO - 2023-01-18 04:10:48 --> Helper loaded: url_helper
INFO - 2023-01-18 04:10:48 --> Helper loaded: file_helper
INFO - 2023-01-18 04:10:48 --> Helper loaded: form_helper
INFO - 2023-01-18 04:10:48 --> Helper loaded: my_helper
INFO - 2023-01-18 04:10:48 --> Database Driver Class Initialized
DEBUG - 2023-01-18 04:10:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-01-18 04:10:48 --> Session: Class initialized using 'files' driver.
INFO - 2023-01-18 04:10:48 --> Controller Class Initialized
INFO - 2023-01-18 04:10:51 --> Config Class Initialized
INFO - 2023-01-18 04:10:51 --> Hooks Class Initialized
DEBUG - 2023-01-18 04:10:51 --> UTF-8 Support Enabled
INFO - 2023-01-18 04:10:51 --> Utf8 Class Initialized
INFO - 2023-01-18 04:10:51 --> URI Class Initialized
INFO - 2023-01-18 04:10:51 --> Router Class Initialized
INFO - 2023-01-18 04:10:51 --> Output Class Initialized
INFO - 2023-01-18 04:10:51 --> Security Class Initialized
DEBUG - 2023-01-18 04:10:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-18 04:10:51 --> Input Class Initialized
INFO - 2023-01-18 04:10:51 --> Language Class Initialized
INFO - 2023-01-18 04:10:51 --> Language Class Initialized
INFO - 2023-01-18 04:10:51 --> Config Class Initialized
INFO - 2023-01-18 04:10:51 --> Loader Class Initialized
INFO - 2023-01-18 04:10:51 --> Helper loaded: url_helper
INFO - 2023-01-18 04:10:51 --> Helper loaded: file_helper
INFO - 2023-01-18 04:10:51 --> Helper loaded: form_helper
INFO - 2023-01-18 04:10:51 --> Helper loaded: my_helper
INFO - 2023-01-18 04:10:51 --> Database Driver Class Initialized
DEBUG - 2023-01-18 04:10:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-01-18 04:10:51 --> Session: Class initialized using 'files' driver.
INFO - 2023-01-18 04:10:51 --> Controller Class Initialized
INFO - 2023-01-18 04:10:51 --> Final output sent to browser
DEBUG - 2023-01-18 04:10:51 --> Total execution time: 0.0421
INFO - 2023-01-18 04:10:51 --> Config Class Initialized
INFO - 2023-01-18 04:10:51 --> Hooks Class Initialized
DEBUG - 2023-01-18 04:10:51 --> UTF-8 Support Enabled
INFO - 2023-01-18 04:10:51 --> Utf8 Class Initialized
INFO - 2023-01-18 04:10:51 --> URI Class Initialized
INFO - 2023-01-18 04:10:51 --> Router Class Initialized
INFO - 2023-01-18 04:10:51 --> Output Class Initialized
INFO - 2023-01-18 04:10:51 --> Security Class Initialized
DEBUG - 2023-01-18 04:10:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-18 04:10:51 --> Input Class Initialized
INFO - 2023-01-18 04:10:51 --> Language Class Initialized
INFO - 2023-01-18 04:10:51 --> Language Class Initialized
INFO - 2023-01-18 04:10:51 --> Config Class Initialized
INFO - 2023-01-18 04:10:51 --> Loader Class Initialized
INFO - 2023-01-18 04:10:51 --> Helper loaded: url_helper
INFO - 2023-01-18 04:10:51 --> Helper loaded: file_helper
INFO - 2023-01-18 04:10:51 --> Helper loaded: form_helper
INFO - 2023-01-18 04:10:51 --> Helper loaded: my_helper
INFO - 2023-01-18 04:10:51 --> Database Driver Class Initialized
DEBUG - 2023-01-18 04:10:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-01-18 04:10:51 --> Session: Class initialized using 'files' driver.
INFO - 2023-01-18 04:10:51 --> Controller Class Initialized
INFO - 2023-01-18 04:10:51 --> Config Class Initialized
INFO - 2023-01-18 04:10:51 --> Hooks Class Initialized
DEBUG - 2023-01-18 04:10:51 --> UTF-8 Support Enabled
INFO - 2023-01-18 04:10:51 --> Utf8 Class Initialized
INFO - 2023-01-18 04:10:51 --> URI Class Initialized
INFO - 2023-01-18 04:10:51 --> Router Class Initialized
INFO - 2023-01-18 04:10:51 --> Output Class Initialized
INFO - 2023-01-18 04:10:51 --> Security Class Initialized
DEBUG - 2023-01-18 04:10:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-18 04:10:51 --> Input Class Initialized
INFO - 2023-01-18 04:10:51 --> Language Class Initialized
INFO - 2023-01-18 04:10:51 --> Language Class Initialized
INFO - 2023-01-18 04:10:51 --> Config Class Initialized
INFO - 2023-01-18 04:10:51 --> Loader Class Initialized
INFO - 2023-01-18 04:10:51 --> Helper loaded: url_helper
INFO - 2023-01-18 04:10:51 --> Helper loaded: file_helper
INFO - 2023-01-18 04:10:51 --> Helper loaded: form_helper
INFO - 2023-01-18 04:10:51 --> Helper loaded: my_helper
INFO - 2023-01-18 04:10:51 --> Database Driver Class Initialized
DEBUG - 2023-01-18 04:10:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-01-18 04:10:51 --> Session: Class initialized using 'files' driver.
INFO - 2023-01-18 04:10:51 --> Controller Class Initialized
DEBUG - 2023-01-18 04:10:51 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/set_mapel/views/form.php
DEBUG - 2023-01-18 04:10:51 --> File loaded: C:\xampp\htdocs\myraportk13\application\views\template_utama.php
INFO - 2023-01-18 04:10:51 --> Final output sent to browser
DEBUG - 2023-01-18 04:10:51 --> Total execution time: 0.0366
INFO - 2023-01-18 04:11:04 --> Config Class Initialized
INFO - 2023-01-18 04:11:04 --> Hooks Class Initialized
DEBUG - 2023-01-18 04:11:04 --> UTF-8 Support Enabled
INFO - 2023-01-18 04:11:04 --> Utf8 Class Initialized
INFO - 2023-01-18 04:11:04 --> URI Class Initialized
INFO - 2023-01-18 04:11:04 --> Router Class Initialized
INFO - 2023-01-18 04:11:04 --> Output Class Initialized
INFO - 2023-01-18 04:11:04 --> Security Class Initialized
DEBUG - 2023-01-18 04:11:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-18 04:11:04 --> Input Class Initialized
INFO - 2023-01-18 04:11:04 --> Language Class Initialized
INFO - 2023-01-18 04:11:04 --> Language Class Initialized
INFO - 2023-01-18 04:11:04 --> Config Class Initialized
INFO - 2023-01-18 04:11:04 --> Loader Class Initialized
INFO - 2023-01-18 04:11:04 --> Helper loaded: url_helper
INFO - 2023-01-18 04:11:04 --> Helper loaded: file_helper
INFO - 2023-01-18 04:11:04 --> Helper loaded: form_helper
INFO - 2023-01-18 04:11:04 --> Helper loaded: my_helper
INFO - 2023-01-18 04:11:04 --> Database Driver Class Initialized
DEBUG - 2023-01-18 04:11:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-01-18 04:11:04 --> Session: Class initialized using 'files' driver.
INFO - 2023-01-18 04:11:04 --> Controller Class Initialized
INFO - 2023-01-18 04:11:04 --> Config Class Initialized
INFO - 2023-01-18 04:11:04 --> Hooks Class Initialized
DEBUG - 2023-01-18 04:11:04 --> UTF-8 Support Enabled
INFO - 2023-01-18 04:11:04 --> Utf8 Class Initialized
INFO - 2023-01-18 04:11:04 --> URI Class Initialized
INFO - 2023-01-18 04:11:04 --> Router Class Initialized
INFO - 2023-01-18 04:11:04 --> Output Class Initialized
INFO - 2023-01-18 04:11:04 --> Security Class Initialized
DEBUG - 2023-01-18 04:11:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-18 04:11:04 --> Input Class Initialized
INFO - 2023-01-18 04:11:04 --> Language Class Initialized
INFO - 2023-01-18 04:11:04 --> Language Class Initialized
INFO - 2023-01-18 04:11:04 --> Config Class Initialized
INFO - 2023-01-18 04:11:04 --> Loader Class Initialized
INFO - 2023-01-18 04:11:04 --> Helper loaded: url_helper
INFO - 2023-01-18 04:11:04 --> Helper loaded: file_helper
INFO - 2023-01-18 04:11:04 --> Helper loaded: form_helper
INFO - 2023-01-18 04:11:04 --> Helper loaded: my_helper
INFO - 2023-01-18 04:11:04 --> Database Driver Class Initialized
DEBUG - 2023-01-18 04:11:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-01-18 04:11:04 --> Session: Class initialized using 'files' driver.
INFO - 2023-01-18 04:11:04 --> Controller Class Initialized
DEBUG - 2023-01-18 04:11:04 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/set_mapel/views/list.php
DEBUG - 2023-01-18 04:11:04 --> File loaded: C:\xampp\htdocs\myraportk13\application\views\template_utama.php
INFO - 2023-01-18 04:11:04 --> Final output sent to browser
DEBUG - 2023-01-18 04:11:04 --> Total execution time: 0.0454
INFO - 2023-01-18 04:11:04 --> Config Class Initialized
INFO - 2023-01-18 04:11:04 --> Hooks Class Initialized
DEBUG - 2023-01-18 04:11:04 --> UTF-8 Support Enabled
INFO - 2023-01-18 04:11:04 --> Utf8 Class Initialized
INFO - 2023-01-18 04:11:04 --> URI Class Initialized
INFO - 2023-01-18 04:11:04 --> Router Class Initialized
INFO - 2023-01-18 04:11:04 --> Output Class Initialized
INFO - 2023-01-18 04:11:04 --> Security Class Initialized
DEBUG - 2023-01-18 04:11:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-18 04:11:04 --> Input Class Initialized
INFO - 2023-01-18 04:11:04 --> Language Class Initialized
INFO - 2023-01-18 04:11:04 --> Language Class Initialized
INFO - 2023-01-18 04:11:04 --> Config Class Initialized
INFO - 2023-01-18 04:11:04 --> Loader Class Initialized
INFO - 2023-01-18 04:11:04 --> Helper loaded: url_helper
INFO - 2023-01-18 04:11:04 --> Helper loaded: file_helper
INFO - 2023-01-18 04:11:04 --> Helper loaded: form_helper
INFO - 2023-01-18 04:11:04 --> Helper loaded: my_helper
INFO - 2023-01-18 04:11:04 --> Database Driver Class Initialized
DEBUG - 2023-01-18 04:11:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-01-18 04:11:04 --> Session: Class initialized using 'files' driver.
INFO - 2023-01-18 04:11:04 --> Controller Class Initialized
INFO - 2023-01-18 04:11:10 --> Config Class Initialized
INFO - 2023-01-18 04:11:10 --> Hooks Class Initialized
DEBUG - 2023-01-18 04:11:10 --> UTF-8 Support Enabled
INFO - 2023-01-18 04:11:10 --> Utf8 Class Initialized
INFO - 2023-01-18 04:11:10 --> URI Class Initialized
INFO - 2023-01-18 04:11:10 --> Router Class Initialized
INFO - 2023-01-18 04:11:10 --> Output Class Initialized
INFO - 2023-01-18 04:11:10 --> Security Class Initialized
DEBUG - 2023-01-18 04:11:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-18 04:11:10 --> Input Class Initialized
INFO - 2023-01-18 04:11:10 --> Language Class Initialized
INFO - 2023-01-18 04:11:10 --> Language Class Initialized
INFO - 2023-01-18 04:11:10 --> Config Class Initialized
INFO - 2023-01-18 04:11:10 --> Loader Class Initialized
INFO - 2023-01-18 04:11:10 --> Helper loaded: url_helper
INFO - 2023-01-18 04:11:10 --> Helper loaded: file_helper
INFO - 2023-01-18 04:11:10 --> Helper loaded: form_helper
INFO - 2023-01-18 04:11:10 --> Helper loaded: my_helper
INFO - 2023-01-18 04:11:10 --> Database Driver Class Initialized
DEBUG - 2023-01-18 04:11:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-01-18 04:11:10 --> Session: Class initialized using 'files' driver.
INFO - 2023-01-18 04:11:10 --> Controller Class Initialized
INFO - 2023-01-18 04:11:10 --> Helper loaded: cookie_helper
INFO - 2023-01-18 04:11:10 --> Config Class Initialized
INFO - 2023-01-18 04:11:10 --> Hooks Class Initialized
DEBUG - 2023-01-18 04:11:10 --> UTF-8 Support Enabled
INFO - 2023-01-18 04:11:10 --> Utf8 Class Initialized
INFO - 2023-01-18 04:11:10 --> URI Class Initialized
INFO - 2023-01-18 04:11:10 --> Router Class Initialized
INFO - 2023-01-18 04:11:10 --> Output Class Initialized
INFO - 2023-01-18 04:11:10 --> Security Class Initialized
DEBUG - 2023-01-18 04:11:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-18 04:11:10 --> Input Class Initialized
INFO - 2023-01-18 04:11:10 --> Language Class Initialized
INFO - 2023-01-18 04:11:10 --> Language Class Initialized
INFO - 2023-01-18 04:11:10 --> Config Class Initialized
INFO - 2023-01-18 04:11:10 --> Loader Class Initialized
INFO - 2023-01-18 04:11:10 --> Helper loaded: url_helper
INFO - 2023-01-18 04:11:10 --> Helper loaded: file_helper
INFO - 2023-01-18 04:11:10 --> Helper loaded: form_helper
INFO - 2023-01-18 04:11:10 --> Helper loaded: my_helper
INFO - 2023-01-18 04:11:10 --> Database Driver Class Initialized
DEBUG - 2023-01-18 04:11:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-01-18 04:11:10 --> Session: Class initialized using 'files' driver.
INFO - 2023-01-18 04:11:10 --> Controller Class Initialized
INFO - 2023-01-18 04:11:10 --> Config Class Initialized
INFO - 2023-01-18 04:11:10 --> Hooks Class Initialized
DEBUG - 2023-01-18 04:11:10 --> UTF-8 Support Enabled
INFO - 2023-01-18 04:11:10 --> Utf8 Class Initialized
INFO - 2023-01-18 04:11:10 --> URI Class Initialized
INFO - 2023-01-18 04:11:10 --> Router Class Initialized
INFO - 2023-01-18 04:11:10 --> Output Class Initialized
INFO - 2023-01-18 04:11:10 --> Security Class Initialized
DEBUG - 2023-01-18 04:11:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-18 04:11:10 --> Input Class Initialized
INFO - 2023-01-18 04:11:10 --> Language Class Initialized
INFO - 2023-01-18 04:11:10 --> Language Class Initialized
INFO - 2023-01-18 04:11:10 --> Config Class Initialized
INFO - 2023-01-18 04:11:10 --> Loader Class Initialized
INFO - 2023-01-18 04:11:10 --> Helper loaded: url_helper
INFO - 2023-01-18 04:11:10 --> Helper loaded: file_helper
INFO - 2023-01-18 04:11:10 --> Helper loaded: form_helper
INFO - 2023-01-18 04:11:10 --> Helper loaded: my_helper
INFO - 2023-01-18 04:11:10 --> Database Driver Class Initialized
DEBUG - 2023-01-18 04:11:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-01-18 04:11:10 --> Session: Class initialized using 'files' driver.
INFO - 2023-01-18 04:11:10 --> Controller Class Initialized
DEBUG - 2023-01-18 04:11:10 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/login/views/login.php
DEBUG - 2023-01-18 04:11:10 --> File loaded: C:\xampp\htdocs\myraportk13\application\views\template_utama.php
INFO - 2023-01-18 04:11:10 --> Final output sent to browser
DEBUG - 2023-01-18 04:11:10 --> Total execution time: 0.0261
INFO - 2023-01-18 04:11:49 --> Config Class Initialized
INFO - 2023-01-18 04:11:49 --> Hooks Class Initialized
DEBUG - 2023-01-18 04:11:49 --> UTF-8 Support Enabled
INFO - 2023-01-18 04:11:49 --> Utf8 Class Initialized
INFO - 2023-01-18 04:11:49 --> URI Class Initialized
INFO - 2023-01-18 04:11:49 --> Router Class Initialized
INFO - 2023-01-18 04:11:49 --> Output Class Initialized
INFO - 2023-01-18 04:11:49 --> Security Class Initialized
DEBUG - 2023-01-18 04:11:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-18 04:11:49 --> Input Class Initialized
INFO - 2023-01-18 04:11:49 --> Language Class Initialized
INFO - 2023-01-18 04:11:49 --> Language Class Initialized
INFO - 2023-01-18 04:11:49 --> Config Class Initialized
INFO - 2023-01-18 04:11:49 --> Loader Class Initialized
INFO - 2023-01-18 04:11:49 --> Helper loaded: url_helper
INFO - 2023-01-18 04:11:49 --> Helper loaded: file_helper
INFO - 2023-01-18 04:11:49 --> Helper loaded: form_helper
INFO - 2023-01-18 04:11:49 --> Helper loaded: my_helper
INFO - 2023-01-18 04:11:49 --> Database Driver Class Initialized
DEBUG - 2023-01-18 04:11:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-01-18 04:11:49 --> Session: Class initialized using 'files' driver.
INFO - 2023-01-18 04:11:49 --> Controller Class Initialized
INFO - 2023-01-18 04:11:49 --> Helper loaded: cookie_helper
INFO - 2023-01-18 04:11:49 --> Final output sent to browser
DEBUG - 2023-01-18 04:11:49 --> Total execution time: 0.0282
INFO - 2023-01-18 04:11:49 --> Config Class Initialized
INFO - 2023-01-18 04:11:49 --> Hooks Class Initialized
DEBUG - 2023-01-18 04:11:49 --> UTF-8 Support Enabled
INFO - 2023-01-18 04:11:49 --> Utf8 Class Initialized
INFO - 2023-01-18 04:11:49 --> URI Class Initialized
INFO - 2023-01-18 04:11:49 --> Router Class Initialized
INFO - 2023-01-18 04:11:49 --> Output Class Initialized
INFO - 2023-01-18 04:11:49 --> Security Class Initialized
DEBUG - 2023-01-18 04:11:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-18 04:11:49 --> Input Class Initialized
INFO - 2023-01-18 04:11:49 --> Language Class Initialized
INFO - 2023-01-18 04:11:49 --> Language Class Initialized
INFO - 2023-01-18 04:11:49 --> Config Class Initialized
INFO - 2023-01-18 04:11:49 --> Loader Class Initialized
INFO - 2023-01-18 04:11:49 --> Helper loaded: url_helper
INFO - 2023-01-18 04:11:49 --> Helper loaded: file_helper
INFO - 2023-01-18 04:11:49 --> Helper loaded: form_helper
INFO - 2023-01-18 04:11:49 --> Helper loaded: my_helper
INFO - 2023-01-18 04:11:49 --> Database Driver Class Initialized
DEBUG - 2023-01-18 04:11:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-01-18 04:11:49 --> Session: Class initialized using 'files' driver.
INFO - 2023-01-18 04:11:49 --> Controller Class Initialized
DEBUG - 2023-01-18 04:11:49 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/home/views/v_home_guru.php
DEBUG - 2023-01-18 04:11:49 --> File loaded: C:\xampp\htdocs\myraportk13\application\views\template_utama.php
INFO - 2023-01-18 04:11:49 --> Final output sent to browser
DEBUG - 2023-01-18 04:11:49 --> Total execution time: 0.0470
INFO - 2023-01-18 04:11:50 --> Config Class Initialized
INFO - 2023-01-18 04:11:50 --> Hooks Class Initialized
DEBUG - 2023-01-18 04:11:50 --> UTF-8 Support Enabled
INFO - 2023-01-18 04:11:50 --> Utf8 Class Initialized
INFO - 2023-01-18 04:11:50 --> URI Class Initialized
INFO - 2023-01-18 04:11:50 --> Router Class Initialized
INFO - 2023-01-18 04:11:50 --> Output Class Initialized
INFO - 2023-01-18 04:11:50 --> Security Class Initialized
DEBUG - 2023-01-18 04:11:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-18 04:11:50 --> Input Class Initialized
INFO - 2023-01-18 04:11:50 --> Language Class Initialized
INFO - 2023-01-18 04:11:50 --> Language Class Initialized
INFO - 2023-01-18 04:11:50 --> Config Class Initialized
INFO - 2023-01-18 04:11:50 --> Loader Class Initialized
INFO - 2023-01-18 04:11:50 --> Helper loaded: url_helper
INFO - 2023-01-18 04:11:50 --> Helper loaded: file_helper
INFO - 2023-01-18 04:11:50 --> Helper loaded: form_helper
INFO - 2023-01-18 04:11:50 --> Helper loaded: my_helper
INFO - 2023-01-18 04:11:50 --> Database Driver Class Initialized
DEBUG - 2023-01-18 04:11:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-01-18 04:11:50 --> Session: Class initialized using 'files' driver.
INFO - 2023-01-18 04:11:50 --> Controller Class Initialized
DEBUG - 2023-01-18 04:11:50 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/view_mapel/views/v_view_mapel.php
DEBUG - 2023-01-18 04:11:50 --> File loaded: C:\xampp\htdocs\myraportk13\application\views\template_utama.php
INFO - 2023-01-18 04:11:50 --> Final output sent to browser
DEBUG - 2023-01-18 04:11:50 --> Total execution time: 0.0332
INFO - 2023-01-18 04:11:53 --> Config Class Initialized
INFO - 2023-01-18 04:11:53 --> Hooks Class Initialized
DEBUG - 2023-01-18 04:11:53 --> UTF-8 Support Enabled
INFO - 2023-01-18 04:11:53 --> Utf8 Class Initialized
INFO - 2023-01-18 04:11:53 --> URI Class Initialized
INFO - 2023-01-18 04:11:53 --> Router Class Initialized
INFO - 2023-01-18 04:11:53 --> Output Class Initialized
INFO - 2023-01-18 04:11:53 --> Security Class Initialized
DEBUG - 2023-01-18 04:11:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-18 04:11:53 --> Input Class Initialized
INFO - 2023-01-18 04:11:53 --> Language Class Initialized
INFO - 2023-01-18 04:11:53 --> Language Class Initialized
INFO - 2023-01-18 04:11:53 --> Config Class Initialized
INFO - 2023-01-18 04:11:53 --> Loader Class Initialized
INFO - 2023-01-18 04:11:53 --> Helper loaded: url_helper
INFO - 2023-01-18 04:11:53 --> Helper loaded: file_helper
INFO - 2023-01-18 04:11:53 --> Helper loaded: form_helper
INFO - 2023-01-18 04:11:53 --> Helper loaded: my_helper
INFO - 2023-01-18 04:11:53 --> Database Driver Class Initialized
DEBUG - 2023-01-18 04:11:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-01-18 04:11:53 --> Session: Class initialized using 'files' driver.
INFO - 2023-01-18 04:11:53 --> Controller Class Initialized
DEBUG - 2023-01-18 04:11:53 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/n_pengetahuan/views/list.php
DEBUG - 2023-01-18 04:11:53 --> File loaded: C:\xampp\htdocs\myraportk13\application\views\template_utama.php
INFO - 2023-01-18 04:11:53 --> Final output sent to browser
DEBUG - 2023-01-18 04:11:53 --> Total execution time: 0.0420
INFO - 2023-01-18 04:11:53 --> Config Class Initialized
INFO - 2023-01-18 04:11:53 --> Hooks Class Initialized
DEBUG - 2023-01-18 04:11:53 --> UTF-8 Support Enabled
INFO - 2023-01-18 04:11:53 --> Utf8 Class Initialized
INFO - 2023-01-18 04:11:53 --> URI Class Initialized
INFO - 2023-01-18 04:11:53 --> Router Class Initialized
INFO - 2023-01-18 04:11:53 --> Output Class Initialized
INFO - 2023-01-18 04:11:53 --> Security Class Initialized
DEBUG - 2023-01-18 04:11:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-18 04:11:53 --> Input Class Initialized
INFO - 2023-01-18 04:11:53 --> Language Class Initialized
INFO - 2023-01-18 04:11:53 --> Language Class Initialized
INFO - 2023-01-18 04:11:53 --> Config Class Initialized
INFO - 2023-01-18 04:11:53 --> Loader Class Initialized
INFO - 2023-01-18 04:11:53 --> Helper loaded: url_helper
INFO - 2023-01-18 04:11:53 --> Helper loaded: file_helper
INFO - 2023-01-18 04:11:53 --> Helper loaded: form_helper
INFO - 2023-01-18 04:11:53 --> Helper loaded: my_helper
INFO - 2023-01-18 04:11:53 --> Database Driver Class Initialized
DEBUG - 2023-01-18 04:11:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-01-18 04:11:53 --> Session: Class initialized using 'files' driver.
INFO - 2023-01-18 04:11:53 --> Controller Class Initialized
INFO - 2023-01-18 04:11:59 --> Config Class Initialized
INFO - 2023-01-18 04:11:59 --> Hooks Class Initialized
DEBUG - 2023-01-18 04:11:59 --> UTF-8 Support Enabled
INFO - 2023-01-18 04:11:59 --> Utf8 Class Initialized
INFO - 2023-01-18 04:11:59 --> URI Class Initialized
INFO - 2023-01-18 04:11:59 --> Router Class Initialized
INFO - 2023-01-18 04:11:59 --> Output Class Initialized
INFO - 2023-01-18 04:11:59 --> Security Class Initialized
DEBUG - 2023-01-18 04:11:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-18 04:11:59 --> Input Class Initialized
INFO - 2023-01-18 04:11:59 --> Language Class Initialized
INFO - 2023-01-18 04:11:59 --> Language Class Initialized
INFO - 2023-01-18 04:11:59 --> Config Class Initialized
INFO - 2023-01-18 04:11:59 --> Loader Class Initialized
INFO - 2023-01-18 04:11:59 --> Helper loaded: url_helper
INFO - 2023-01-18 04:11:59 --> Helper loaded: file_helper
INFO - 2023-01-18 04:11:59 --> Helper loaded: form_helper
INFO - 2023-01-18 04:11:59 --> Helper loaded: my_helper
INFO - 2023-01-18 04:11:59 --> Database Driver Class Initialized
DEBUG - 2023-01-18 04:11:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-01-18 04:11:59 --> Session: Class initialized using 'files' driver.
INFO - 2023-01-18 04:11:59 --> Controller Class Initialized
DEBUG - 2023-01-18 04:11:59 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/view_mapel/views/v_view_mapel.php
DEBUG - 2023-01-18 04:11:59 --> File loaded: C:\xampp\htdocs\myraportk13\application\views\template_utama.php
INFO - 2023-01-18 04:11:59 --> Final output sent to browser
DEBUG - 2023-01-18 04:11:59 --> Total execution time: 0.0411
INFO - 2023-01-18 04:12:00 --> Config Class Initialized
INFO - 2023-01-18 04:12:00 --> Hooks Class Initialized
DEBUG - 2023-01-18 04:12:00 --> UTF-8 Support Enabled
INFO - 2023-01-18 04:12:00 --> Utf8 Class Initialized
INFO - 2023-01-18 04:12:00 --> URI Class Initialized
INFO - 2023-01-18 04:12:00 --> Router Class Initialized
INFO - 2023-01-18 04:12:00 --> Output Class Initialized
INFO - 2023-01-18 04:12:00 --> Security Class Initialized
DEBUG - 2023-01-18 04:12:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-18 04:12:00 --> Input Class Initialized
INFO - 2023-01-18 04:12:00 --> Language Class Initialized
INFO - 2023-01-18 04:12:00 --> Language Class Initialized
INFO - 2023-01-18 04:12:00 --> Config Class Initialized
INFO - 2023-01-18 04:12:00 --> Loader Class Initialized
INFO - 2023-01-18 04:12:00 --> Helper loaded: url_helper
INFO - 2023-01-18 04:12:00 --> Helper loaded: file_helper
INFO - 2023-01-18 04:12:00 --> Helper loaded: form_helper
INFO - 2023-01-18 04:12:00 --> Helper loaded: my_helper
INFO - 2023-01-18 04:12:00 --> Database Driver Class Initialized
DEBUG - 2023-01-18 04:12:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-01-18 04:12:00 --> Session: Class initialized using 'files' driver.
INFO - 2023-01-18 04:12:00 --> Controller Class Initialized
DEBUG - 2023-01-18 04:12:00 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/n_keterampilan/views/list.php
DEBUG - 2023-01-18 04:12:00 --> File loaded: C:\xampp\htdocs\myraportk13\application\views\template_utama.php
INFO - 2023-01-18 04:12:00 --> Final output sent to browser
DEBUG - 2023-01-18 04:12:00 --> Total execution time: 0.0866
INFO - 2023-01-18 04:12:02 --> Config Class Initialized
INFO - 2023-01-18 04:12:02 --> Hooks Class Initialized
DEBUG - 2023-01-18 04:12:02 --> UTF-8 Support Enabled
INFO - 2023-01-18 04:12:02 --> Utf8 Class Initialized
INFO - 2023-01-18 04:12:02 --> URI Class Initialized
INFO - 2023-01-18 04:12:02 --> Router Class Initialized
INFO - 2023-01-18 04:12:02 --> Output Class Initialized
INFO - 2023-01-18 04:12:02 --> Security Class Initialized
DEBUG - 2023-01-18 04:12:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-18 04:12:02 --> Input Class Initialized
INFO - 2023-01-18 04:12:02 --> Language Class Initialized
INFO - 2023-01-18 04:12:02 --> Language Class Initialized
INFO - 2023-01-18 04:12:02 --> Config Class Initialized
INFO - 2023-01-18 04:12:02 --> Loader Class Initialized
INFO - 2023-01-18 04:12:02 --> Helper loaded: url_helper
INFO - 2023-01-18 04:12:02 --> Helper loaded: file_helper
INFO - 2023-01-18 04:12:02 --> Helper loaded: form_helper
INFO - 2023-01-18 04:12:02 --> Helper loaded: my_helper
INFO - 2023-01-18 04:12:02 --> Database Driver Class Initialized
DEBUG - 2023-01-18 04:12:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-01-18 04:12:02 --> Session: Class initialized using 'files' driver.
INFO - 2023-01-18 04:12:02 --> Controller Class Initialized
DEBUG - 2023-01-18 04:12:02 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/view_mapel/views/v_view_mapel.php
DEBUG - 2023-01-18 04:12:02 --> File loaded: C:\xampp\htdocs\myraportk13\application\views\template_utama.php
INFO - 2023-01-18 04:12:02 --> Final output sent to browser
DEBUG - 2023-01-18 04:12:02 --> Total execution time: 0.0289
INFO - 2023-01-18 04:12:05 --> Config Class Initialized
INFO - 2023-01-18 04:12:05 --> Hooks Class Initialized
DEBUG - 2023-01-18 04:12:05 --> UTF-8 Support Enabled
INFO - 2023-01-18 04:12:05 --> Utf8 Class Initialized
INFO - 2023-01-18 04:12:05 --> URI Class Initialized
INFO - 2023-01-18 04:12:05 --> Router Class Initialized
INFO - 2023-01-18 04:12:05 --> Output Class Initialized
INFO - 2023-01-18 04:12:05 --> Security Class Initialized
DEBUG - 2023-01-18 04:12:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-18 04:12:05 --> Input Class Initialized
INFO - 2023-01-18 04:12:05 --> Language Class Initialized
INFO - 2023-01-18 04:12:05 --> Language Class Initialized
INFO - 2023-01-18 04:12:05 --> Config Class Initialized
INFO - 2023-01-18 04:12:05 --> Loader Class Initialized
INFO - 2023-01-18 04:12:05 --> Helper loaded: url_helper
INFO - 2023-01-18 04:12:05 --> Helper loaded: file_helper
INFO - 2023-01-18 04:12:05 --> Helper loaded: form_helper
INFO - 2023-01-18 04:12:05 --> Helper loaded: my_helper
INFO - 2023-01-18 04:12:05 --> Database Driver Class Initialized
DEBUG - 2023-01-18 04:12:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-01-18 04:12:05 --> Session: Class initialized using 'files' driver.
INFO - 2023-01-18 04:12:05 --> Controller Class Initialized
DEBUG - 2023-01-18 04:12:05 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/n_pengetahuan/views/list.php
DEBUG - 2023-01-18 04:12:05 --> File loaded: C:\xampp\htdocs\myraportk13\application\views\template_utama.php
INFO - 2023-01-18 04:12:05 --> Final output sent to browser
DEBUG - 2023-01-18 04:12:05 --> Total execution time: 0.0305
INFO - 2023-01-18 04:12:05 --> Config Class Initialized
INFO - 2023-01-18 04:12:05 --> Hooks Class Initialized
DEBUG - 2023-01-18 04:12:05 --> UTF-8 Support Enabled
INFO - 2023-01-18 04:12:05 --> Utf8 Class Initialized
INFO - 2023-01-18 04:12:05 --> URI Class Initialized
INFO - 2023-01-18 04:12:05 --> Router Class Initialized
INFO - 2023-01-18 04:12:05 --> Output Class Initialized
INFO - 2023-01-18 04:12:05 --> Security Class Initialized
DEBUG - 2023-01-18 04:12:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-18 04:12:05 --> Input Class Initialized
INFO - 2023-01-18 04:12:05 --> Language Class Initialized
INFO - 2023-01-18 04:12:05 --> Language Class Initialized
INFO - 2023-01-18 04:12:05 --> Config Class Initialized
INFO - 2023-01-18 04:12:05 --> Loader Class Initialized
INFO - 2023-01-18 04:12:05 --> Helper loaded: url_helper
INFO - 2023-01-18 04:12:05 --> Helper loaded: file_helper
INFO - 2023-01-18 04:12:05 --> Helper loaded: form_helper
INFO - 2023-01-18 04:12:05 --> Helper loaded: my_helper
INFO - 2023-01-18 04:12:05 --> Database Driver Class Initialized
DEBUG - 2023-01-18 04:12:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-01-18 04:12:05 --> Session: Class initialized using 'files' driver.
INFO - 2023-01-18 04:12:05 --> Controller Class Initialized
INFO - 2023-01-18 04:12:06 --> Config Class Initialized
INFO - 2023-01-18 04:12:06 --> Hooks Class Initialized
DEBUG - 2023-01-18 04:12:06 --> UTF-8 Support Enabled
INFO - 2023-01-18 04:12:06 --> Utf8 Class Initialized
INFO - 2023-01-18 04:12:06 --> URI Class Initialized
INFO - 2023-01-18 04:12:06 --> Router Class Initialized
INFO - 2023-01-18 04:12:06 --> Output Class Initialized
INFO - 2023-01-18 04:12:06 --> Security Class Initialized
DEBUG - 2023-01-18 04:12:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-18 04:12:06 --> Input Class Initialized
INFO - 2023-01-18 04:12:06 --> Language Class Initialized
INFO - 2023-01-18 04:12:06 --> Language Class Initialized
INFO - 2023-01-18 04:12:06 --> Config Class Initialized
INFO - 2023-01-18 04:12:06 --> Loader Class Initialized
INFO - 2023-01-18 04:12:06 --> Helper loaded: url_helper
INFO - 2023-01-18 04:12:06 --> Helper loaded: file_helper
INFO - 2023-01-18 04:12:06 --> Helper loaded: form_helper
INFO - 2023-01-18 04:12:06 --> Helper loaded: my_helper
INFO - 2023-01-18 04:12:06 --> Database Driver Class Initialized
DEBUG - 2023-01-18 04:12:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-01-18 04:12:06 --> Session: Class initialized using 'files' driver.
INFO - 2023-01-18 04:12:06 --> Controller Class Initialized
DEBUG - 2023-01-18 04:12:06 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/view_mapel/views/v_view_mapel.php
DEBUG - 2023-01-18 04:12:06 --> File loaded: C:\xampp\htdocs\myraportk13\application\views\template_utama.php
INFO - 2023-01-18 04:12:06 --> Final output sent to browser
DEBUG - 2023-01-18 04:12:06 --> Total execution time: 0.0333
INFO - 2023-01-18 04:12:07 --> Config Class Initialized
INFO - 2023-01-18 04:12:07 --> Hooks Class Initialized
DEBUG - 2023-01-18 04:12:07 --> UTF-8 Support Enabled
INFO - 2023-01-18 04:12:07 --> Utf8 Class Initialized
INFO - 2023-01-18 04:12:07 --> URI Class Initialized
INFO - 2023-01-18 04:12:07 --> Router Class Initialized
INFO - 2023-01-18 04:12:07 --> Output Class Initialized
INFO - 2023-01-18 04:12:07 --> Security Class Initialized
DEBUG - 2023-01-18 04:12:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-18 04:12:07 --> Input Class Initialized
INFO - 2023-01-18 04:12:07 --> Language Class Initialized
INFO - 2023-01-18 04:12:07 --> Language Class Initialized
INFO - 2023-01-18 04:12:07 --> Config Class Initialized
INFO - 2023-01-18 04:12:07 --> Loader Class Initialized
INFO - 2023-01-18 04:12:07 --> Helper loaded: url_helper
INFO - 2023-01-18 04:12:07 --> Helper loaded: file_helper
INFO - 2023-01-18 04:12:07 --> Helper loaded: form_helper
INFO - 2023-01-18 04:12:07 --> Helper loaded: my_helper
INFO - 2023-01-18 04:12:07 --> Database Driver Class Initialized
DEBUG - 2023-01-18 04:12:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-01-18 04:12:07 --> Session: Class initialized using 'files' driver.
INFO - 2023-01-18 04:12:07 --> Controller Class Initialized
DEBUG - 2023-01-18 04:12:07 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/n_keterampilan/views/list.php
DEBUG - 2023-01-18 04:12:07 --> File loaded: C:\xampp\htdocs\myraportk13\application\views\template_utama.php
INFO - 2023-01-18 04:12:07 --> Final output sent to browser
DEBUG - 2023-01-18 04:12:07 --> Total execution time: 0.0317
INFO - 2023-01-18 04:12:08 --> Config Class Initialized
INFO - 2023-01-18 04:12:08 --> Hooks Class Initialized
DEBUG - 2023-01-18 04:12:08 --> UTF-8 Support Enabled
INFO - 2023-01-18 04:12:08 --> Utf8 Class Initialized
INFO - 2023-01-18 04:12:08 --> URI Class Initialized
INFO - 2023-01-18 04:12:08 --> Router Class Initialized
INFO - 2023-01-18 04:12:08 --> Output Class Initialized
INFO - 2023-01-18 04:12:08 --> Security Class Initialized
DEBUG - 2023-01-18 04:12:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-18 04:12:08 --> Input Class Initialized
INFO - 2023-01-18 04:12:08 --> Language Class Initialized
INFO - 2023-01-18 04:12:08 --> Language Class Initialized
INFO - 2023-01-18 04:12:08 --> Config Class Initialized
INFO - 2023-01-18 04:12:08 --> Loader Class Initialized
INFO - 2023-01-18 04:12:08 --> Helper loaded: url_helper
INFO - 2023-01-18 04:12:08 --> Helper loaded: file_helper
INFO - 2023-01-18 04:12:08 --> Helper loaded: form_helper
INFO - 2023-01-18 04:12:08 --> Helper loaded: my_helper
INFO - 2023-01-18 04:12:08 --> Database Driver Class Initialized
DEBUG - 2023-01-18 04:12:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-01-18 04:12:08 --> Session: Class initialized using 'files' driver.
INFO - 2023-01-18 04:12:08 --> Controller Class Initialized
DEBUG - 2023-01-18 04:12:08 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/view_mapel/views/v_view_mapel.php
DEBUG - 2023-01-18 04:12:08 --> File loaded: C:\xampp\htdocs\myraportk13\application\views\template_utama.php
INFO - 2023-01-18 04:12:08 --> Final output sent to browser
DEBUG - 2023-01-18 04:12:08 --> Total execution time: 0.0577
INFO - 2023-01-18 04:12:15 --> Config Class Initialized
INFO - 2023-01-18 04:12:15 --> Hooks Class Initialized
DEBUG - 2023-01-18 04:12:15 --> UTF-8 Support Enabled
INFO - 2023-01-18 04:12:15 --> Utf8 Class Initialized
INFO - 2023-01-18 04:12:15 --> URI Class Initialized
INFO - 2023-01-18 04:12:15 --> Router Class Initialized
INFO - 2023-01-18 04:12:15 --> Output Class Initialized
INFO - 2023-01-18 04:12:15 --> Security Class Initialized
DEBUG - 2023-01-18 04:12:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-18 04:12:15 --> Input Class Initialized
INFO - 2023-01-18 04:12:15 --> Language Class Initialized
INFO - 2023-01-18 04:12:15 --> Language Class Initialized
INFO - 2023-01-18 04:12:15 --> Config Class Initialized
INFO - 2023-01-18 04:12:15 --> Loader Class Initialized
INFO - 2023-01-18 04:12:15 --> Helper loaded: url_helper
INFO - 2023-01-18 04:12:15 --> Helper loaded: file_helper
INFO - 2023-01-18 04:12:15 --> Helper loaded: form_helper
INFO - 2023-01-18 04:12:15 --> Helper loaded: my_helper
INFO - 2023-01-18 04:12:15 --> Database Driver Class Initialized
DEBUG - 2023-01-18 04:12:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-01-18 04:12:15 --> Session: Class initialized using 'files' driver.
INFO - 2023-01-18 04:12:15 --> Controller Class Initialized
INFO - 2023-01-18 04:12:15 --> Helper loaded: cookie_helper
INFO - 2023-01-18 04:12:15 --> Config Class Initialized
INFO - 2023-01-18 04:12:15 --> Hooks Class Initialized
DEBUG - 2023-01-18 04:12:15 --> UTF-8 Support Enabled
INFO - 2023-01-18 04:12:15 --> Utf8 Class Initialized
INFO - 2023-01-18 04:12:15 --> URI Class Initialized
INFO - 2023-01-18 04:12:15 --> Router Class Initialized
INFO - 2023-01-18 04:12:15 --> Output Class Initialized
INFO - 2023-01-18 04:12:15 --> Security Class Initialized
DEBUG - 2023-01-18 04:12:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-18 04:12:15 --> Input Class Initialized
INFO - 2023-01-18 04:12:15 --> Language Class Initialized
INFO - 2023-01-18 04:12:15 --> Language Class Initialized
INFO - 2023-01-18 04:12:15 --> Config Class Initialized
INFO - 2023-01-18 04:12:15 --> Loader Class Initialized
INFO - 2023-01-18 04:12:15 --> Helper loaded: url_helper
INFO - 2023-01-18 04:12:15 --> Helper loaded: file_helper
INFO - 2023-01-18 04:12:15 --> Helper loaded: form_helper
INFO - 2023-01-18 04:12:15 --> Helper loaded: my_helper
INFO - 2023-01-18 04:12:15 --> Database Driver Class Initialized
DEBUG - 2023-01-18 04:12:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-01-18 04:12:15 --> Session: Class initialized using 'files' driver.
INFO - 2023-01-18 04:12:15 --> Controller Class Initialized
INFO - 2023-01-18 04:12:15 --> Config Class Initialized
INFO - 2023-01-18 04:12:15 --> Hooks Class Initialized
DEBUG - 2023-01-18 04:12:15 --> UTF-8 Support Enabled
INFO - 2023-01-18 04:12:15 --> Utf8 Class Initialized
INFO - 2023-01-18 04:12:15 --> URI Class Initialized
INFO - 2023-01-18 04:12:15 --> Router Class Initialized
INFO - 2023-01-18 04:12:15 --> Output Class Initialized
INFO - 2023-01-18 04:12:15 --> Security Class Initialized
DEBUG - 2023-01-18 04:12:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-18 04:12:15 --> Input Class Initialized
INFO - 2023-01-18 04:12:15 --> Language Class Initialized
INFO - 2023-01-18 04:12:15 --> Language Class Initialized
INFO - 2023-01-18 04:12:15 --> Config Class Initialized
INFO - 2023-01-18 04:12:15 --> Loader Class Initialized
INFO - 2023-01-18 04:12:15 --> Helper loaded: url_helper
INFO - 2023-01-18 04:12:15 --> Helper loaded: file_helper
INFO - 2023-01-18 04:12:15 --> Helper loaded: form_helper
INFO - 2023-01-18 04:12:15 --> Helper loaded: my_helper
INFO - 2023-01-18 04:12:15 --> Database Driver Class Initialized
DEBUG - 2023-01-18 04:12:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-01-18 04:12:15 --> Session: Class initialized using 'files' driver.
INFO - 2023-01-18 04:12:15 --> Controller Class Initialized
DEBUG - 2023-01-18 04:12:15 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/login/views/login.php
DEBUG - 2023-01-18 04:12:15 --> File loaded: C:\xampp\htdocs\myraportk13\application\views\template_utama.php
INFO - 2023-01-18 04:12:15 --> Final output sent to browser
DEBUG - 2023-01-18 04:12:15 --> Total execution time: 0.0225
INFO - 2023-01-18 04:21:02 --> Config Class Initialized
INFO - 2023-01-18 04:21:02 --> Hooks Class Initialized
DEBUG - 2023-01-18 04:21:02 --> UTF-8 Support Enabled
INFO - 2023-01-18 04:21:02 --> Utf8 Class Initialized
INFO - 2023-01-18 04:21:02 --> URI Class Initialized
INFO - 2023-01-18 04:21:02 --> Router Class Initialized
INFO - 2023-01-18 04:21:02 --> Output Class Initialized
INFO - 2023-01-18 04:21:02 --> Security Class Initialized
DEBUG - 2023-01-18 04:21:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-18 04:21:02 --> Input Class Initialized
INFO - 2023-01-18 04:21:02 --> Language Class Initialized
INFO - 2023-01-18 04:21:02 --> Language Class Initialized
INFO - 2023-01-18 04:21:02 --> Config Class Initialized
INFO - 2023-01-18 04:21:02 --> Loader Class Initialized
INFO - 2023-01-18 04:21:02 --> Helper loaded: url_helper
INFO - 2023-01-18 04:21:02 --> Helper loaded: file_helper
INFO - 2023-01-18 04:21:02 --> Helper loaded: form_helper
INFO - 2023-01-18 04:21:02 --> Helper loaded: my_helper
INFO - 2023-01-18 04:21:02 --> Database Driver Class Initialized
DEBUG - 2023-01-18 04:21:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-01-18 04:21:02 --> Session: Class initialized using 'files' driver.
INFO - 2023-01-18 04:21:02 --> Controller Class Initialized
INFO - 2023-01-18 04:21:02 --> Helper loaded: cookie_helper
INFO - 2023-01-18 04:21:02 --> Final output sent to browser
DEBUG - 2023-01-18 04:21:02 --> Total execution time: 0.0325
INFO - 2023-01-18 04:21:02 --> Config Class Initialized
INFO - 2023-01-18 04:21:02 --> Hooks Class Initialized
DEBUG - 2023-01-18 04:21:02 --> UTF-8 Support Enabled
INFO - 2023-01-18 04:21:02 --> Utf8 Class Initialized
INFO - 2023-01-18 04:21:02 --> URI Class Initialized
INFO - 2023-01-18 04:21:02 --> Router Class Initialized
INFO - 2023-01-18 04:21:02 --> Output Class Initialized
INFO - 2023-01-18 04:21:02 --> Security Class Initialized
DEBUG - 2023-01-18 04:21:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-18 04:21:02 --> Input Class Initialized
INFO - 2023-01-18 04:21:02 --> Language Class Initialized
INFO - 2023-01-18 04:21:02 --> Language Class Initialized
INFO - 2023-01-18 04:21:02 --> Config Class Initialized
INFO - 2023-01-18 04:21:02 --> Loader Class Initialized
INFO - 2023-01-18 04:21:02 --> Helper loaded: url_helper
INFO - 2023-01-18 04:21:02 --> Helper loaded: file_helper
INFO - 2023-01-18 04:21:02 --> Helper loaded: form_helper
INFO - 2023-01-18 04:21:02 --> Helper loaded: my_helper
INFO - 2023-01-18 04:21:02 --> Database Driver Class Initialized
DEBUG - 2023-01-18 04:21:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-01-18 04:21:02 --> Session: Class initialized using 'files' driver.
INFO - 2023-01-18 04:21:02 --> Controller Class Initialized
DEBUG - 2023-01-18 04:21:02 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/home/views/v_home_guru.php
DEBUG - 2023-01-18 04:21:02 --> File loaded: C:\xampp\htdocs\myraportk13\application\views\template_utama.php
INFO - 2023-01-18 04:21:02 --> Final output sent to browser
DEBUG - 2023-01-18 04:21:02 --> Total execution time: 0.0339
INFO - 2023-01-18 04:21:06 --> Config Class Initialized
INFO - 2023-01-18 04:21:06 --> Hooks Class Initialized
DEBUG - 2023-01-18 04:21:06 --> UTF-8 Support Enabled
INFO - 2023-01-18 04:21:06 --> Utf8 Class Initialized
INFO - 2023-01-18 04:21:06 --> URI Class Initialized
INFO - 2023-01-18 04:21:06 --> Router Class Initialized
INFO - 2023-01-18 04:21:06 --> Output Class Initialized
INFO - 2023-01-18 04:21:06 --> Security Class Initialized
DEBUG - 2023-01-18 04:21:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-18 04:21:06 --> Input Class Initialized
INFO - 2023-01-18 04:21:06 --> Language Class Initialized
INFO - 2023-01-18 04:21:06 --> Language Class Initialized
INFO - 2023-01-18 04:21:06 --> Config Class Initialized
INFO - 2023-01-18 04:21:06 --> Loader Class Initialized
INFO - 2023-01-18 04:21:06 --> Helper loaded: url_helper
INFO - 2023-01-18 04:21:06 --> Helper loaded: file_helper
INFO - 2023-01-18 04:21:06 --> Helper loaded: form_helper
INFO - 2023-01-18 04:21:06 --> Helper loaded: my_helper
INFO - 2023-01-18 04:21:06 --> Database Driver Class Initialized
DEBUG - 2023-01-18 04:21:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-01-18 04:21:06 --> Session: Class initialized using 'files' driver.
INFO - 2023-01-18 04:21:06 --> Controller Class Initialized
DEBUG - 2023-01-18 04:21:06 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/n_absensi/views/list.php
DEBUG - 2023-01-18 04:21:06 --> File loaded: C:\xampp\htdocs\myraportk13\application\views\template_utama.php
INFO - 2023-01-18 04:21:06 --> Final output sent to browser
DEBUG - 2023-01-18 04:21:06 --> Total execution time: 0.0698
