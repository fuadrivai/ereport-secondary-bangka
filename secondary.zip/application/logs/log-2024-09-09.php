<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2024-09-09 16:18:31 --> Config Class Initialized
INFO - 2024-09-09 16:18:31 --> Hooks Class Initialized
DEBUG - 2024-09-09 16:18:31 --> UTF-8 Support Enabled
INFO - 2024-09-09 16:18:31 --> Utf8 Class Initialized
INFO - 2024-09-09 16:18:31 --> URI Class Initialized
INFO - 2024-09-09 16:18:31 --> Router Class Initialized
INFO - 2024-09-09 16:18:31 --> Output Class Initialized
INFO - 2024-09-09 16:18:31 --> Security Class Initialized
DEBUG - 2024-09-09 16:18:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-09 16:18:31 --> Input Class Initialized
INFO - 2024-09-09 16:18:31 --> Language Class Initialized
INFO - 2024-09-09 16:18:31 --> Language Class Initialized
INFO - 2024-09-09 16:18:31 --> Config Class Initialized
INFO - 2024-09-09 16:18:31 --> Loader Class Initialized
INFO - 2024-09-09 16:18:31 --> Helper loaded: url_helper
INFO - 2024-09-09 16:18:31 --> Helper loaded: file_helper
INFO - 2024-09-09 16:18:31 --> Helper loaded: form_helper
INFO - 2024-09-09 16:18:31 --> Helper loaded: my_helper
INFO - 2024-09-09 16:18:31 --> Database Driver Class Initialized
INFO - 2024-09-09 16:18:31 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-09 16:18:31 --> Controller Class Initialized
INFO - 2024-09-09 16:18:31 --> Helper loaded: cookie_helper
INFO - 2024-09-09 16:18:31 --> Final output sent to browser
DEBUG - 2024-09-09 16:18:31 --> Total execution time: 0.1289
INFO - 2024-09-09 16:18:32 --> Config Class Initialized
INFO - 2024-09-09 16:18:32 --> Hooks Class Initialized
DEBUG - 2024-09-09 16:18:32 --> UTF-8 Support Enabled
INFO - 2024-09-09 16:18:32 --> Utf8 Class Initialized
INFO - 2024-09-09 16:18:32 --> URI Class Initialized
INFO - 2024-09-09 16:18:32 --> Router Class Initialized
INFO - 2024-09-09 16:18:32 --> Output Class Initialized
INFO - 2024-09-09 16:18:32 --> Security Class Initialized
DEBUG - 2024-09-09 16:18:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-09 16:18:32 --> Input Class Initialized
INFO - 2024-09-09 16:18:32 --> Language Class Initialized
INFO - 2024-09-09 16:18:32 --> Language Class Initialized
INFO - 2024-09-09 16:18:32 --> Config Class Initialized
INFO - 2024-09-09 16:18:32 --> Loader Class Initialized
INFO - 2024-09-09 16:18:32 --> Helper loaded: url_helper
INFO - 2024-09-09 16:18:32 --> Helper loaded: file_helper
INFO - 2024-09-09 16:18:32 --> Helper loaded: form_helper
INFO - 2024-09-09 16:18:32 --> Helper loaded: my_helper
INFO - 2024-09-09 16:18:32 --> Database Driver Class Initialized
INFO - 2024-09-09 16:18:32 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-09 16:18:32 --> Controller Class Initialized
INFO - 2024-09-09 16:18:32 --> Helper loaded: cookie_helper
INFO - 2024-09-09 16:18:32 --> Config Class Initialized
INFO - 2024-09-09 16:18:32 --> Hooks Class Initialized
DEBUG - 2024-09-09 16:18:32 --> UTF-8 Support Enabled
INFO - 2024-09-09 16:18:32 --> Utf8 Class Initialized
INFO - 2024-09-09 16:18:32 --> URI Class Initialized
INFO - 2024-09-09 16:18:32 --> Router Class Initialized
INFO - 2024-09-09 16:18:32 --> Output Class Initialized
INFO - 2024-09-09 16:18:32 --> Security Class Initialized
DEBUG - 2024-09-09 16:18:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-09 16:18:32 --> Input Class Initialized
INFO - 2024-09-09 16:18:32 --> Language Class Initialized
INFO - 2024-09-09 16:18:32 --> Language Class Initialized
INFO - 2024-09-09 16:18:32 --> Config Class Initialized
INFO - 2024-09-09 16:18:32 --> Loader Class Initialized
INFO - 2024-09-09 16:18:32 --> Helper loaded: url_helper
INFO - 2024-09-09 16:18:32 --> Helper loaded: file_helper
INFO - 2024-09-09 16:18:32 --> Helper loaded: form_helper
INFO - 2024-09-09 16:18:32 --> Helper loaded: my_helper
INFO - 2024-09-09 16:18:32 --> Database Driver Class Initialized
INFO - 2024-09-09 16:18:32 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-09 16:18:32 --> Controller Class Initialized
DEBUG - 2024-09-09 16:18:32 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/lihat_raport/views/list.php
DEBUG - 2024-09-09 16:18:32 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-09-09 16:18:32 --> Final output sent to browser
DEBUG - 2024-09-09 16:18:32 --> Total execution time: 0.0558
INFO - 2024-09-09 16:18:37 --> Config Class Initialized
INFO - 2024-09-09 16:18:37 --> Hooks Class Initialized
DEBUG - 2024-09-09 16:18:37 --> UTF-8 Support Enabled
INFO - 2024-09-09 16:18:37 --> Utf8 Class Initialized
INFO - 2024-09-09 16:18:37 --> URI Class Initialized
INFO - 2024-09-09 16:18:37 --> Router Class Initialized
INFO - 2024-09-09 16:18:37 --> Output Class Initialized
INFO - 2024-09-09 16:18:37 --> Security Class Initialized
DEBUG - 2024-09-09 16:18:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-09 16:18:37 --> Input Class Initialized
INFO - 2024-09-09 16:18:37 --> Language Class Initialized
INFO - 2024-09-09 16:18:37 --> Language Class Initialized
INFO - 2024-09-09 16:18:37 --> Config Class Initialized
INFO - 2024-09-09 16:18:37 --> Loader Class Initialized
INFO - 2024-09-09 16:18:37 --> Helper loaded: url_helper
INFO - 2024-09-09 16:18:37 --> Helper loaded: file_helper
INFO - 2024-09-09 16:18:37 --> Helper loaded: form_helper
INFO - 2024-09-09 16:18:37 --> Helper loaded: my_helper
INFO - 2024-09-09 16:18:37 --> Database Driver Class Initialized
INFO - 2024-09-09 16:18:37 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-09 16:18:37 --> Controller Class Initialized
ERROR - 2024-09-09 16:18:37 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1160
ERROR - 2024-09-09 16:18:37 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1692
ERROR - 2024-09-09 16:18:37 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1729
ERROR - 2024-09-09 16:18:37 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1767
ERROR - 2024-09-09 16:18:37 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1806
ERROR - 2024-09-09 16:18:37 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1883
ERROR - 2024-09-09 16:18:37 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1962
ERROR - 2024-09-09 16:18:37 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 2042
ERROR - 2024-09-09 16:18:37 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 2122
ERROR - 2024-09-09 16:18:37 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 2202
ERROR - 2024-09-09 16:18:37 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 2277
ERROR - 2024-09-09 16:18:37 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php 32
ERROR - 2024-09-09 16:18:37 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php 32
DEBUG - 2024-09-09 16:18:37 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php
INFO - 2024-09-09 16:18:40 --> Config Class Initialized
INFO - 2024-09-09 16:18:40 --> Hooks Class Initialized
DEBUG - 2024-09-09 16:18:40 --> UTF-8 Support Enabled
INFO - 2024-09-09 16:18:40 --> Utf8 Class Initialized
INFO - 2024-09-09 16:18:40 --> URI Class Initialized
INFO - 2024-09-09 16:18:40 --> Router Class Initialized
INFO - 2024-09-09 16:18:40 --> Output Class Initialized
INFO - 2024-09-09 16:18:40 --> Security Class Initialized
DEBUG - 2024-09-09 16:18:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-09 16:18:40 --> Input Class Initialized
INFO - 2024-09-09 16:18:40 --> Language Class Initialized
INFO - 2024-09-09 16:18:40 --> Language Class Initialized
INFO - 2024-09-09 16:18:40 --> Config Class Initialized
INFO - 2024-09-09 16:18:40 --> Loader Class Initialized
INFO - 2024-09-09 16:18:40 --> Helper loaded: url_helper
INFO - 2024-09-09 16:18:40 --> Helper loaded: file_helper
INFO - 2024-09-09 16:18:40 --> Helper loaded: form_helper
INFO - 2024-09-09 16:18:40 --> Helper loaded: my_helper
INFO - 2024-09-09 16:18:40 --> Database Driver Class Initialized
INFO - 2024-09-09 16:18:41 --> Final output sent to browser
DEBUG - 2024-09-09 16:18:41 --> Total execution time: 3.6466
INFO - 2024-09-09 16:18:41 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-09 16:18:41 --> Controller Class Initialized
ERROR - 2024-09-09 16:18:41 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1160
ERROR - 2024-09-09 16:18:41 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1692
ERROR - 2024-09-09 16:18:41 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1729
ERROR - 2024-09-09 16:18:41 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1767
ERROR - 2024-09-09 16:18:41 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1806
ERROR - 2024-09-09 16:18:41 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1883
ERROR - 2024-09-09 16:18:41 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1962
ERROR - 2024-09-09 16:18:41 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 2042
ERROR - 2024-09-09 16:18:41 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 2122
ERROR - 2024-09-09 16:18:41 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 2202
ERROR - 2024-09-09 16:18:41 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 2277
ERROR - 2024-09-09 16:18:41 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php 32
ERROR - 2024-09-09 16:18:41 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php 32
DEBUG - 2024-09-09 16:18:41 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php
INFO - 2024-09-09 16:18:43 --> Final output sent to browser
DEBUG - 2024-09-09 16:18:43 --> Total execution time: 3.2185
INFO - 2024-09-09 16:18:44 --> Config Class Initialized
INFO - 2024-09-09 16:18:44 --> Hooks Class Initialized
DEBUG - 2024-09-09 16:18:44 --> UTF-8 Support Enabled
INFO - 2024-09-09 16:18:44 --> Utf8 Class Initialized
INFO - 2024-09-09 16:18:44 --> URI Class Initialized
INFO - 2024-09-09 16:18:44 --> Router Class Initialized
INFO - 2024-09-09 16:18:44 --> Output Class Initialized
INFO - 2024-09-09 16:18:44 --> Security Class Initialized
DEBUG - 2024-09-09 16:18:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-09 16:18:44 --> Input Class Initialized
INFO - 2024-09-09 16:18:44 --> Language Class Initialized
INFO - 2024-09-09 16:18:44 --> Language Class Initialized
INFO - 2024-09-09 16:18:44 --> Config Class Initialized
INFO - 2024-09-09 16:18:44 --> Loader Class Initialized
INFO - 2024-09-09 16:18:44 --> Helper loaded: url_helper
INFO - 2024-09-09 16:18:44 --> Helper loaded: file_helper
INFO - 2024-09-09 16:18:44 --> Helper loaded: form_helper
INFO - 2024-09-09 16:18:44 --> Helper loaded: my_helper
INFO - 2024-09-09 16:18:44 --> Database Driver Class Initialized
INFO - 2024-09-09 16:18:44 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-09 16:18:44 --> Controller Class Initialized
ERROR - 2024-09-09 16:18:44 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1160
ERROR - 2024-09-09 16:18:44 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1692
ERROR - 2024-09-09 16:18:44 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1729
ERROR - 2024-09-09 16:18:44 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1767
ERROR - 2024-09-09 16:18:44 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1806
ERROR - 2024-09-09 16:18:44 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1883
ERROR - 2024-09-09 16:18:44 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1962
ERROR - 2024-09-09 16:18:44 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 2042
ERROR - 2024-09-09 16:18:44 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 2122
ERROR - 2024-09-09 16:18:44 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 2202
ERROR - 2024-09-09 16:18:44 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 2277
ERROR - 2024-09-09 16:18:44 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php 32
ERROR - 2024-09-09 16:18:44 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php 32
DEBUG - 2024-09-09 16:18:44 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php
INFO - 2024-09-09 16:18:47 --> Final output sent to browser
DEBUG - 2024-09-09 16:18:47 --> Total execution time: 2.8492
INFO - 2024-09-09 16:18:47 --> Config Class Initialized
INFO - 2024-09-09 16:18:47 --> Hooks Class Initialized
DEBUG - 2024-09-09 16:18:47 --> UTF-8 Support Enabled
INFO - 2024-09-09 16:18:47 --> Utf8 Class Initialized
INFO - 2024-09-09 16:18:47 --> URI Class Initialized
INFO - 2024-09-09 16:18:47 --> Router Class Initialized
INFO - 2024-09-09 16:18:47 --> Output Class Initialized
INFO - 2024-09-09 16:18:47 --> Security Class Initialized
DEBUG - 2024-09-09 16:18:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-09 16:18:47 --> Input Class Initialized
INFO - 2024-09-09 16:18:47 --> Language Class Initialized
INFO - 2024-09-09 16:18:47 --> Language Class Initialized
INFO - 2024-09-09 16:18:47 --> Config Class Initialized
INFO - 2024-09-09 16:18:47 --> Loader Class Initialized
INFO - 2024-09-09 16:18:47 --> Helper loaded: url_helper
INFO - 2024-09-09 16:18:47 --> Helper loaded: file_helper
INFO - 2024-09-09 16:18:47 --> Helper loaded: form_helper
INFO - 2024-09-09 16:18:47 --> Helper loaded: my_helper
INFO - 2024-09-09 16:18:47 --> Database Driver Class Initialized
INFO - 2024-09-09 16:18:47 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-09 16:18:47 --> Controller Class Initialized
ERROR - 2024-09-09 16:18:47 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1160
ERROR - 2024-09-09 16:18:47 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1692
ERROR - 2024-09-09 16:18:47 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1729
ERROR - 2024-09-09 16:18:47 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1767
ERROR - 2024-09-09 16:18:47 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1806
ERROR - 2024-09-09 16:18:47 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1883
ERROR - 2024-09-09 16:18:47 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1962
ERROR - 2024-09-09 16:18:47 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 2042
ERROR - 2024-09-09 16:18:47 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 2122
ERROR - 2024-09-09 16:18:47 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 2202
ERROR - 2024-09-09 16:18:47 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 2277
ERROR - 2024-09-09 16:18:47 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php 32
ERROR - 2024-09-09 16:18:47 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php 32
DEBUG - 2024-09-09 16:18:47 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php
INFO - 2024-09-09 16:18:50 --> Final output sent to browser
DEBUG - 2024-09-09 16:18:50 --> Total execution time: 3.0178
INFO - 2024-09-09 16:52:53 --> Config Class Initialized
INFO - 2024-09-09 16:52:53 --> Hooks Class Initialized
DEBUG - 2024-09-09 16:52:53 --> UTF-8 Support Enabled
INFO - 2024-09-09 16:52:53 --> Utf8 Class Initialized
INFO - 2024-09-09 16:52:53 --> URI Class Initialized
INFO - 2024-09-09 16:52:53 --> Router Class Initialized
INFO - 2024-09-09 16:52:53 --> Output Class Initialized
INFO - 2024-09-09 16:52:53 --> Security Class Initialized
DEBUG - 2024-09-09 16:52:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-09 16:52:53 --> Input Class Initialized
INFO - 2024-09-09 16:52:53 --> Language Class Initialized
INFO - 2024-09-09 16:52:53 --> Language Class Initialized
INFO - 2024-09-09 16:52:53 --> Config Class Initialized
INFO - 2024-09-09 16:52:53 --> Loader Class Initialized
INFO - 2024-09-09 16:52:53 --> Helper loaded: url_helper
INFO - 2024-09-09 16:52:53 --> Helper loaded: file_helper
INFO - 2024-09-09 16:52:53 --> Helper loaded: form_helper
INFO - 2024-09-09 16:52:53 --> Helper loaded: my_helper
INFO - 2024-09-09 16:52:53 --> Database Driver Class Initialized
INFO - 2024-09-09 16:52:53 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-09 16:52:53 --> Controller Class Initialized
INFO - 2024-09-09 16:52:53 --> Helper loaded: cookie_helper
INFO - 2024-09-09 16:52:53 --> Final output sent to browser
DEBUG - 2024-09-09 16:52:53 --> Total execution time: 0.0660
INFO - 2024-09-09 16:52:53 --> Config Class Initialized
INFO - 2024-09-09 16:52:53 --> Hooks Class Initialized
DEBUG - 2024-09-09 16:52:53 --> UTF-8 Support Enabled
INFO - 2024-09-09 16:52:53 --> Utf8 Class Initialized
INFO - 2024-09-09 16:52:53 --> URI Class Initialized
INFO - 2024-09-09 16:52:53 --> Router Class Initialized
INFO - 2024-09-09 16:52:53 --> Output Class Initialized
INFO - 2024-09-09 16:52:53 --> Security Class Initialized
DEBUG - 2024-09-09 16:52:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-09 16:52:53 --> Input Class Initialized
INFO - 2024-09-09 16:52:53 --> Language Class Initialized
INFO - 2024-09-09 16:52:53 --> Language Class Initialized
INFO - 2024-09-09 16:52:53 --> Config Class Initialized
INFO - 2024-09-09 16:52:53 --> Loader Class Initialized
INFO - 2024-09-09 16:52:53 --> Helper loaded: url_helper
INFO - 2024-09-09 16:52:53 --> Helper loaded: file_helper
INFO - 2024-09-09 16:52:53 --> Helper loaded: form_helper
INFO - 2024-09-09 16:52:53 --> Helper loaded: my_helper
INFO - 2024-09-09 16:52:53 --> Database Driver Class Initialized
INFO - 2024-09-09 16:52:53 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-09 16:52:53 --> Controller Class Initialized
INFO - 2024-09-09 16:52:53 --> Helper loaded: cookie_helper
INFO - 2024-09-09 16:52:53 --> Config Class Initialized
INFO - 2024-09-09 16:52:53 --> Hooks Class Initialized
DEBUG - 2024-09-09 16:52:53 --> UTF-8 Support Enabled
INFO - 2024-09-09 16:52:53 --> Utf8 Class Initialized
INFO - 2024-09-09 16:52:53 --> URI Class Initialized
INFO - 2024-09-09 16:52:53 --> Router Class Initialized
INFO - 2024-09-09 16:52:53 --> Output Class Initialized
INFO - 2024-09-09 16:52:53 --> Security Class Initialized
DEBUG - 2024-09-09 16:52:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-09 16:52:53 --> Input Class Initialized
INFO - 2024-09-09 16:52:53 --> Language Class Initialized
INFO - 2024-09-09 16:52:53 --> Language Class Initialized
INFO - 2024-09-09 16:52:53 --> Config Class Initialized
INFO - 2024-09-09 16:52:53 --> Loader Class Initialized
INFO - 2024-09-09 16:52:53 --> Helper loaded: url_helper
INFO - 2024-09-09 16:52:53 --> Helper loaded: file_helper
INFO - 2024-09-09 16:52:53 --> Helper loaded: form_helper
INFO - 2024-09-09 16:52:53 --> Helper loaded: my_helper
INFO - 2024-09-09 16:52:53 --> Database Driver Class Initialized
INFO - 2024-09-09 16:52:53 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-09 16:52:53 --> Controller Class Initialized
DEBUG - 2024-09-09 16:52:53 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/lihat_raport/views/list.php
DEBUG - 2024-09-09 16:52:53 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-09-09 16:52:53 --> Final output sent to browser
DEBUG - 2024-09-09 16:52:53 --> Total execution time: 0.0455
INFO - 2024-09-09 18:47:50 --> Config Class Initialized
INFO - 2024-09-09 18:47:50 --> Hooks Class Initialized
DEBUG - 2024-09-09 18:47:50 --> UTF-8 Support Enabled
INFO - 2024-09-09 18:47:50 --> Utf8 Class Initialized
INFO - 2024-09-09 18:47:50 --> URI Class Initialized
INFO - 2024-09-09 18:47:50 --> Router Class Initialized
INFO - 2024-09-09 18:47:50 --> Output Class Initialized
INFO - 2024-09-09 18:47:50 --> Security Class Initialized
DEBUG - 2024-09-09 18:47:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-09 18:47:50 --> Input Class Initialized
INFO - 2024-09-09 18:47:50 --> Language Class Initialized
INFO - 2024-09-09 18:47:50 --> Language Class Initialized
INFO - 2024-09-09 18:47:50 --> Config Class Initialized
INFO - 2024-09-09 18:47:50 --> Loader Class Initialized
INFO - 2024-09-09 18:47:50 --> Helper loaded: url_helper
INFO - 2024-09-09 18:47:50 --> Helper loaded: file_helper
INFO - 2024-09-09 18:47:50 --> Helper loaded: form_helper
INFO - 2024-09-09 18:47:50 --> Helper loaded: my_helper
INFO - 2024-09-09 18:47:50 --> Database Driver Class Initialized
INFO - 2024-09-09 18:47:50 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-09 18:47:50 --> Controller Class Initialized
INFO - 2024-09-09 18:47:50 --> Helper loaded: cookie_helper
INFO - 2024-09-09 18:47:50 --> Final output sent to browser
DEBUG - 2024-09-09 18:47:50 --> Total execution time: 0.0970
INFO - 2024-09-09 18:47:51 --> Config Class Initialized
INFO - 2024-09-09 18:47:51 --> Hooks Class Initialized
DEBUG - 2024-09-09 18:47:51 --> UTF-8 Support Enabled
INFO - 2024-09-09 18:47:51 --> Utf8 Class Initialized
INFO - 2024-09-09 18:47:51 --> URI Class Initialized
INFO - 2024-09-09 18:47:51 --> Router Class Initialized
INFO - 2024-09-09 18:47:51 --> Output Class Initialized
INFO - 2024-09-09 18:47:51 --> Security Class Initialized
DEBUG - 2024-09-09 18:47:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-09 18:47:51 --> Input Class Initialized
INFO - 2024-09-09 18:47:51 --> Language Class Initialized
INFO - 2024-09-09 18:47:51 --> Language Class Initialized
INFO - 2024-09-09 18:47:51 --> Config Class Initialized
INFO - 2024-09-09 18:47:51 --> Loader Class Initialized
INFO - 2024-09-09 18:47:51 --> Helper loaded: url_helper
INFO - 2024-09-09 18:47:51 --> Helper loaded: file_helper
INFO - 2024-09-09 18:47:51 --> Helper loaded: form_helper
INFO - 2024-09-09 18:47:51 --> Helper loaded: my_helper
INFO - 2024-09-09 18:47:51 --> Database Driver Class Initialized
INFO - 2024-09-09 18:47:51 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-09 18:47:51 --> Controller Class Initialized
INFO - 2024-09-09 18:47:51 --> Helper loaded: cookie_helper
INFO - 2024-09-09 18:47:51 --> Config Class Initialized
INFO - 2024-09-09 18:47:51 --> Hooks Class Initialized
DEBUG - 2024-09-09 18:47:51 --> UTF-8 Support Enabled
INFO - 2024-09-09 18:47:51 --> Utf8 Class Initialized
INFO - 2024-09-09 18:47:51 --> URI Class Initialized
INFO - 2024-09-09 18:47:51 --> Router Class Initialized
INFO - 2024-09-09 18:47:51 --> Output Class Initialized
INFO - 2024-09-09 18:47:51 --> Security Class Initialized
DEBUG - 2024-09-09 18:47:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-09 18:47:51 --> Input Class Initialized
INFO - 2024-09-09 18:47:51 --> Language Class Initialized
INFO - 2024-09-09 18:47:51 --> Language Class Initialized
INFO - 2024-09-09 18:47:51 --> Config Class Initialized
INFO - 2024-09-09 18:47:51 --> Loader Class Initialized
INFO - 2024-09-09 18:47:51 --> Helper loaded: url_helper
INFO - 2024-09-09 18:47:51 --> Helper loaded: file_helper
INFO - 2024-09-09 18:47:51 --> Helper loaded: form_helper
INFO - 2024-09-09 18:47:51 --> Helper loaded: my_helper
INFO - 2024-09-09 18:47:51 --> Database Driver Class Initialized
INFO - 2024-09-09 18:47:51 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-09 18:47:51 --> Controller Class Initialized
DEBUG - 2024-09-09 18:47:51 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/lihat_raport/views/list.php
DEBUG - 2024-09-09 18:47:51 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-09-09 18:47:51 --> Final output sent to browser
DEBUG - 2024-09-09 18:47:51 --> Total execution time: 0.0332
INFO - 2024-09-09 18:47:59 --> Config Class Initialized
INFO - 2024-09-09 18:47:59 --> Hooks Class Initialized
DEBUG - 2024-09-09 18:47:59 --> UTF-8 Support Enabled
INFO - 2024-09-09 18:47:59 --> Utf8 Class Initialized
INFO - 2024-09-09 18:47:59 --> URI Class Initialized
INFO - 2024-09-09 18:47:59 --> Router Class Initialized
INFO - 2024-09-09 18:47:59 --> Output Class Initialized
INFO - 2024-09-09 18:47:59 --> Security Class Initialized
DEBUG - 2024-09-09 18:47:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-09 18:47:59 --> Input Class Initialized
INFO - 2024-09-09 18:47:59 --> Language Class Initialized
INFO - 2024-09-09 18:47:59 --> Language Class Initialized
INFO - 2024-09-09 18:47:59 --> Config Class Initialized
INFO - 2024-09-09 18:47:59 --> Loader Class Initialized
INFO - 2024-09-09 18:47:59 --> Helper loaded: url_helper
INFO - 2024-09-09 18:47:59 --> Helper loaded: file_helper
INFO - 2024-09-09 18:47:59 --> Helper loaded: form_helper
INFO - 2024-09-09 18:47:59 --> Helper loaded: my_helper
INFO - 2024-09-09 18:47:59 --> Database Driver Class Initialized
INFO - 2024-09-09 18:47:59 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-09 18:47:59 --> Controller Class Initialized
ERROR - 2024-09-09 18:47:59 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1160
ERROR - 2024-09-09 18:47:59 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1692
ERROR - 2024-09-09 18:47:59 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1729
ERROR - 2024-09-09 18:47:59 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1767
ERROR - 2024-09-09 18:47:59 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1806
ERROR - 2024-09-09 18:47:59 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1883
ERROR - 2024-09-09 18:47:59 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1962
ERROR - 2024-09-09 18:47:59 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 2042
ERROR - 2024-09-09 18:47:59 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 2122
ERROR - 2024-09-09 18:47:59 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 2202
ERROR - 2024-09-09 18:47:59 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 2277
ERROR - 2024-09-09 18:48:00 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php 32
ERROR - 2024-09-09 18:48:00 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php 32
DEBUG - 2024-09-09 18:48:00 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php
INFO - 2024-09-09 18:48:01 --> Config Class Initialized
INFO - 2024-09-09 18:48:01 --> Hooks Class Initialized
DEBUG - 2024-09-09 18:48:01 --> UTF-8 Support Enabled
INFO - 2024-09-09 18:48:01 --> Utf8 Class Initialized
INFO - 2024-09-09 18:48:01 --> URI Class Initialized
INFO - 2024-09-09 18:48:02 --> Router Class Initialized
INFO - 2024-09-09 18:48:02 --> Output Class Initialized
INFO - 2024-09-09 18:48:02 --> Security Class Initialized
DEBUG - 2024-09-09 18:48:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-09 18:48:02 --> Input Class Initialized
INFO - 2024-09-09 18:48:02 --> Language Class Initialized
INFO - 2024-09-09 18:48:02 --> Language Class Initialized
INFO - 2024-09-09 18:48:02 --> Config Class Initialized
INFO - 2024-09-09 18:48:02 --> Loader Class Initialized
INFO - 2024-09-09 18:48:02 --> Helper loaded: url_helper
INFO - 2024-09-09 18:48:02 --> Helper loaded: file_helper
INFO - 2024-09-09 18:48:02 --> Helper loaded: form_helper
INFO - 2024-09-09 18:48:02 --> Helper loaded: my_helper
INFO - 2024-09-09 18:48:02 --> Database Driver Class Initialized
INFO - 2024-09-09 18:48:03 --> Final output sent to browser
DEBUG - 2024-09-09 18:48:03 --> Total execution time: 3.8852
INFO - 2024-09-09 18:48:03 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-09 18:48:03 --> Controller Class Initialized
ERROR - 2024-09-09 18:48:03 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1160
ERROR - 2024-09-09 18:48:03 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1692
ERROR - 2024-09-09 18:48:03 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1729
ERROR - 2024-09-09 18:48:03 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1767
ERROR - 2024-09-09 18:48:03 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1806
ERROR - 2024-09-09 18:48:03 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1883
ERROR - 2024-09-09 18:48:03 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1962
ERROR - 2024-09-09 18:48:03 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 2042
ERROR - 2024-09-09 18:48:03 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 2122
ERROR - 2024-09-09 18:48:03 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 2202
ERROR - 2024-09-09 18:48:03 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 2277
ERROR - 2024-09-09 18:48:03 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php 32
ERROR - 2024-09-09 18:48:03 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php 32
DEBUG - 2024-09-09 18:48:03 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php
INFO - 2024-09-09 18:48:06 --> Final output sent to browser
DEBUG - 2024-09-09 18:48:06 --> Total execution time: 4.6315
INFO - 2024-09-09 18:48:06 --> Config Class Initialized
INFO - 2024-09-09 18:48:06 --> Hooks Class Initialized
DEBUG - 2024-09-09 18:48:06 --> UTF-8 Support Enabled
INFO - 2024-09-09 18:48:06 --> Utf8 Class Initialized
INFO - 2024-09-09 18:48:06 --> URI Class Initialized
INFO - 2024-09-09 18:48:06 --> Router Class Initialized
INFO - 2024-09-09 18:48:06 --> Output Class Initialized
INFO - 2024-09-09 18:48:06 --> Security Class Initialized
DEBUG - 2024-09-09 18:48:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-09 18:48:06 --> Input Class Initialized
INFO - 2024-09-09 18:48:06 --> Language Class Initialized
INFO - 2024-09-09 18:48:06 --> Language Class Initialized
INFO - 2024-09-09 18:48:06 --> Config Class Initialized
INFO - 2024-09-09 18:48:06 --> Loader Class Initialized
INFO - 2024-09-09 18:48:06 --> Helper loaded: url_helper
INFO - 2024-09-09 18:48:06 --> Helper loaded: file_helper
INFO - 2024-09-09 18:48:06 --> Helper loaded: form_helper
INFO - 2024-09-09 18:48:06 --> Helper loaded: my_helper
INFO - 2024-09-09 18:48:06 --> Database Driver Class Initialized
INFO - 2024-09-09 18:48:06 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-09 18:48:06 --> Controller Class Initialized
ERROR - 2024-09-09 18:48:06 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1160
ERROR - 2024-09-09 18:48:06 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1692
ERROR - 2024-09-09 18:48:06 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1729
ERROR - 2024-09-09 18:48:06 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1767
ERROR - 2024-09-09 18:48:06 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1806
ERROR - 2024-09-09 18:48:06 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1883
ERROR - 2024-09-09 18:48:06 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1962
ERROR - 2024-09-09 18:48:06 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 2042
ERROR - 2024-09-09 18:48:06 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 2122
ERROR - 2024-09-09 18:48:06 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 2202
ERROR - 2024-09-09 18:48:06 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 2277
ERROR - 2024-09-09 18:48:06 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php 32
ERROR - 2024-09-09 18:48:06 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php 32
DEBUG - 2024-09-09 18:48:06 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php
INFO - 2024-09-09 18:48:09 --> Config Class Initialized
INFO - 2024-09-09 18:48:09 --> Hooks Class Initialized
DEBUG - 2024-09-09 18:48:09 --> UTF-8 Support Enabled
INFO - 2024-09-09 18:48:09 --> Utf8 Class Initialized
INFO - 2024-09-09 18:48:09 --> URI Class Initialized
INFO - 2024-09-09 18:48:09 --> Router Class Initialized
INFO - 2024-09-09 18:48:09 --> Output Class Initialized
INFO - 2024-09-09 18:48:09 --> Security Class Initialized
DEBUG - 2024-09-09 18:48:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-09 18:48:09 --> Input Class Initialized
INFO - 2024-09-09 18:48:09 --> Language Class Initialized
INFO - 2024-09-09 18:48:09 --> Language Class Initialized
INFO - 2024-09-09 18:48:09 --> Config Class Initialized
INFO - 2024-09-09 18:48:09 --> Loader Class Initialized
INFO - 2024-09-09 18:48:09 --> Helper loaded: url_helper
INFO - 2024-09-09 18:48:09 --> Helper loaded: file_helper
INFO - 2024-09-09 18:48:09 --> Helper loaded: form_helper
INFO - 2024-09-09 18:48:09 --> Helper loaded: my_helper
INFO - 2024-09-09 18:48:09 --> Database Driver Class Initialized
INFO - 2024-09-09 18:48:10 --> Final output sent to browser
DEBUG - 2024-09-09 18:48:10 --> Total execution time: 3.2192
INFO - 2024-09-09 18:48:10 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-09 18:48:10 --> Controller Class Initialized
ERROR - 2024-09-09 18:48:10 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1797
ERROR - 2024-09-09 18:48:10 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1804
ERROR - 2024-09-09 18:48:10 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 2022
ERROR - 2024-09-09 18:48:10 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 2022
ERROR - 2024-09-09 18:48:10 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/views/cetak_projek.php 67
ERROR - 2024-09-09 18:48:10 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/views/cetak_projek.php 86
ERROR - 2024-09-09 18:48:10 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/views/cetak_projek.php 98
ERROR - 2024-09-09 18:48:10 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/views/cetak_projek.php 98
ERROR - 2024-09-09 18:48:10 --> Severity: Notice --> Undefined variable: projek /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/views/cetak_projek.php 107
ERROR - 2024-09-09 18:48:10 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/views/cetak_projek.php 297
ERROR - 2024-09-09 18:48:10 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/views/cetak_projek.php 307
DEBUG - 2024-09-09 18:48:10 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/views/cetak_projek.php
ERROR - 2024-09-09 18:48:13 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 2037
ERROR - 2024-09-09 18:48:13 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 2037
INFO - 2024-09-09 18:48:14 --> Final output sent to browser
DEBUG - 2024-09-09 18:48:14 --> Total execution time: 4.2848
INFO - 2024-09-09 18:48:14 --> Config Class Initialized
INFO - 2024-09-09 18:48:14 --> Hooks Class Initialized
DEBUG - 2024-09-09 18:48:14 --> UTF-8 Support Enabled
INFO - 2024-09-09 18:48:14 --> Utf8 Class Initialized
INFO - 2024-09-09 18:48:14 --> URI Class Initialized
INFO - 2024-09-09 18:48:14 --> Router Class Initialized
INFO - 2024-09-09 18:48:14 --> Output Class Initialized
INFO - 2024-09-09 18:48:14 --> Security Class Initialized
DEBUG - 2024-09-09 18:48:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-09 18:48:14 --> Input Class Initialized
INFO - 2024-09-09 18:48:14 --> Language Class Initialized
INFO - 2024-09-09 18:48:14 --> Language Class Initialized
INFO - 2024-09-09 18:48:14 --> Config Class Initialized
INFO - 2024-09-09 18:48:14 --> Loader Class Initialized
INFO - 2024-09-09 18:48:14 --> Helper loaded: url_helper
INFO - 2024-09-09 18:48:14 --> Helper loaded: file_helper
INFO - 2024-09-09 18:48:14 --> Helper loaded: form_helper
INFO - 2024-09-09 18:48:14 --> Helper loaded: my_helper
INFO - 2024-09-09 18:48:14 --> Database Driver Class Initialized
INFO - 2024-09-09 18:48:14 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-09 18:48:14 --> Controller Class Initialized
ERROR - 2024-09-09 18:48:14 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1797
ERROR - 2024-09-09 18:48:14 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1804
ERROR - 2024-09-09 18:48:14 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 2022
ERROR - 2024-09-09 18:48:14 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 2022
ERROR - 2024-09-09 18:48:14 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/views/cetak_projek.php 67
ERROR - 2024-09-09 18:48:14 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/views/cetak_projek.php 86
ERROR - 2024-09-09 18:48:14 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/views/cetak_projek.php 98
ERROR - 2024-09-09 18:48:14 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/views/cetak_projek.php 98
ERROR - 2024-09-09 18:48:14 --> Severity: Notice --> Undefined variable: projek /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/views/cetak_projek.php 107
ERROR - 2024-09-09 18:48:14 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/views/cetak_projek.php 297
ERROR - 2024-09-09 18:48:14 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/views/cetak_projek.php 307
DEBUG - 2024-09-09 18:48:14 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/views/cetak_projek.php
ERROR - 2024-09-09 18:48:18 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 2037
ERROR - 2024-09-09 18:48:18 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 2037
INFO - 2024-09-09 18:48:18 --> Final output sent to browser
DEBUG - 2024-09-09 18:48:18 --> Total execution time: 4.1266
INFO - 2024-09-09 18:48:19 --> Config Class Initialized
INFO - 2024-09-09 18:48:19 --> Hooks Class Initialized
DEBUG - 2024-09-09 18:48:19 --> UTF-8 Support Enabled
INFO - 2024-09-09 18:48:19 --> Utf8 Class Initialized
INFO - 2024-09-09 18:48:19 --> URI Class Initialized
INFO - 2024-09-09 18:48:19 --> Router Class Initialized
INFO - 2024-09-09 18:48:19 --> Output Class Initialized
INFO - 2024-09-09 18:48:19 --> Security Class Initialized
DEBUG - 2024-09-09 18:48:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-09 18:48:19 --> Input Class Initialized
INFO - 2024-09-09 18:48:19 --> Language Class Initialized
INFO - 2024-09-09 18:48:19 --> Language Class Initialized
INFO - 2024-09-09 18:48:19 --> Config Class Initialized
INFO - 2024-09-09 18:48:19 --> Loader Class Initialized
INFO - 2024-09-09 18:48:19 --> Helper loaded: url_helper
INFO - 2024-09-09 18:48:19 --> Helper loaded: file_helper
INFO - 2024-09-09 18:48:19 --> Helper loaded: form_helper
INFO - 2024-09-09 18:48:19 --> Helper loaded: my_helper
INFO - 2024-09-09 18:48:19 --> Database Driver Class Initialized
INFO - 2024-09-09 18:48:19 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-09 18:48:19 --> Controller Class Initialized
ERROR - 2024-09-09 18:48:19 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1797
ERROR - 2024-09-09 18:48:19 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1804
ERROR - 2024-09-09 18:48:19 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 2022
ERROR - 2024-09-09 18:48:19 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 2022
ERROR - 2024-09-09 18:48:19 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/views/cetak_projek.php 67
ERROR - 2024-09-09 18:48:19 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/views/cetak_projek.php 86
ERROR - 2024-09-09 18:48:19 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/views/cetak_projek.php 98
ERROR - 2024-09-09 18:48:19 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/views/cetak_projek.php 98
ERROR - 2024-09-09 18:48:19 --> Severity: Notice --> Undefined variable: projek /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/views/cetak_projek.php 107
ERROR - 2024-09-09 18:48:19 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/views/cetak_projek.php 297
ERROR - 2024-09-09 18:48:19 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/views/cetak_projek.php 307
DEBUG - 2024-09-09 18:48:19 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/views/cetak_projek.php
INFO - 2024-09-09 18:48:23 --> Config Class Initialized
INFO - 2024-09-09 18:48:23 --> Hooks Class Initialized
DEBUG - 2024-09-09 18:48:23 --> UTF-8 Support Enabled
INFO - 2024-09-09 18:48:23 --> Utf8 Class Initialized
INFO - 2024-09-09 18:48:23 --> URI Class Initialized
INFO - 2024-09-09 18:48:23 --> Router Class Initialized
INFO - 2024-09-09 18:48:23 --> Output Class Initialized
INFO - 2024-09-09 18:48:23 --> Security Class Initialized
DEBUG - 2024-09-09 18:48:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-09 18:48:23 --> Input Class Initialized
INFO - 2024-09-09 18:48:23 --> Language Class Initialized
INFO - 2024-09-09 18:48:23 --> Language Class Initialized
INFO - 2024-09-09 18:48:23 --> Config Class Initialized
INFO - 2024-09-09 18:48:23 --> Loader Class Initialized
INFO - 2024-09-09 18:48:23 --> Helper loaded: url_helper
INFO - 2024-09-09 18:48:23 --> Helper loaded: file_helper
INFO - 2024-09-09 18:48:23 --> Helper loaded: form_helper
INFO - 2024-09-09 18:48:23 --> Helper loaded: my_helper
INFO - 2024-09-09 18:48:23 --> Database Driver Class Initialized
ERROR - 2024-09-09 18:48:23 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 2037
ERROR - 2024-09-09 18:48:23 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 2037
INFO - 2024-09-09 18:48:23 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-09 18:48:23 --> Controller Class Initialized
ERROR - 2024-09-09 18:48:23 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1797
ERROR - 2024-09-09 18:48:23 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1804
ERROR - 2024-09-09 18:48:23 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 2022
ERROR - 2024-09-09 18:48:23 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 2022
ERROR - 2024-09-09 18:48:23 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/views/cetak_projek.php 67
ERROR - 2024-09-09 18:48:23 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/views/cetak_projek.php 86
ERROR - 2024-09-09 18:48:23 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/views/cetak_projek.php 98
ERROR - 2024-09-09 18:48:23 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/views/cetak_projek.php 98
ERROR - 2024-09-09 18:48:23 --> Severity: Notice --> Undefined variable: projek /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/views/cetak_projek.php 107
ERROR - 2024-09-09 18:48:23 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/views/cetak_projek.php 297
ERROR - 2024-09-09 18:48:23 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/views/cetak_projek.php 307
DEBUG - 2024-09-09 18:48:23 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/views/cetak_projek.php
ERROR - 2024-09-09 18:48:27 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 2037
ERROR - 2024-09-09 18:48:27 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 2037
INFO - 2024-09-09 18:48:27 --> Final output sent to browser
DEBUG - 2024-09-09 18:48:27 --> Total execution time: 4.1027
INFO - 2024-09-09 18:48:27 --> Config Class Initialized
INFO - 2024-09-09 18:48:27 --> Hooks Class Initialized
DEBUG - 2024-09-09 18:48:27 --> UTF-8 Support Enabled
INFO - 2024-09-09 18:48:27 --> Utf8 Class Initialized
INFO - 2024-09-09 18:48:27 --> URI Class Initialized
INFO - 2024-09-09 18:48:27 --> Router Class Initialized
INFO - 2024-09-09 18:48:27 --> Output Class Initialized
INFO - 2024-09-09 18:48:27 --> Security Class Initialized
DEBUG - 2024-09-09 18:48:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-09 18:48:27 --> Input Class Initialized
INFO - 2024-09-09 18:48:27 --> Language Class Initialized
INFO - 2024-09-09 18:48:27 --> Language Class Initialized
INFO - 2024-09-09 18:48:27 --> Config Class Initialized
INFO - 2024-09-09 18:48:27 --> Loader Class Initialized
INFO - 2024-09-09 18:48:27 --> Helper loaded: url_helper
INFO - 2024-09-09 18:48:27 --> Helper loaded: file_helper
INFO - 2024-09-09 18:48:27 --> Helper loaded: form_helper
INFO - 2024-09-09 18:48:27 --> Helper loaded: my_helper
INFO - 2024-09-09 18:48:27 --> Database Driver Class Initialized
INFO - 2024-09-09 18:48:27 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-09 18:48:27 --> Controller Class Initialized
ERROR - 2024-09-09 18:48:27 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1797
ERROR - 2024-09-09 18:48:27 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1804
ERROR - 2024-09-09 18:48:27 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 2022
ERROR - 2024-09-09 18:48:27 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 2022
ERROR - 2024-09-09 18:48:27 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/views/cetak_projek.php 67
ERROR - 2024-09-09 18:48:27 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/views/cetak_projek.php 86
ERROR - 2024-09-09 18:48:27 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/views/cetak_projek.php 98
ERROR - 2024-09-09 18:48:27 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/views/cetak_projek.php 98
ERROR - 2024-09-09 18:48:27 --> Severity: Notice --> Undefined variable: projek /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/views/cetak_projek.php 107
ERROR - 2024-09-09 18:48:27 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/views/cetak_projek.php 297
ERROR - 2024-09-09 18:48:27 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/views/cetak_projek.php 307
DEBUG - 2024-09-09 18:48:27 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/views/cetak_projek.php
ERROR - 2024-09-09 18:48:31 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 2037
ERROR - 2024-09-09 18:48:31 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 2037
INFO - 2024-09-09 18:48:53 --> Config Class Initialized
INFO - 2024-09-09 18:48:53 --> Hooks Class Initialized
DEBUG - 2024-09-09 18:48:53 --> UTF-8 Support Enabled
INFO - 2024-09-09 18:48:53 --> Utf8 Class Initialized
INFO - 2024-09-09 18:48:53 --> URI Class Initialized
INFO - 2024-09-09 18:48:53 --> Router Class Initialized
INFO - 2024-09-09 18:48:53 --> Output Class Initialized
INFO - 2024-09-09 18:48:53 --> Security Class Initialized
DEBUG - 2024-09-09 18:48:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-09 18:48:53 --> Input Class Initialized
INFO - 2024-09-09 18:48:53 --> Language Class Initialized
INFO - 2024-09-09 18:48:53 --> Language Class Initialized
INFO - 2024-09-09 18:48:53 --> Config Class Initialized
INFO - 2024-09-09 18:48:53 --> Loader Class Initialized
INFO - 2024-09-09 18:48:53 --> Helper loaded: url_helper
INFO - 2024-09-09 18:48:53 --> Helper loaded: file_helper
INFO - 2024-09-09 18:48:53 --> Helper loaded: form_helper
INFO - 2024-09-09 18:48:53 --> Helper loaded: my_helper
INFO - 2024-09-09 18:48:53 --> Database Driver Class Initialized
INFO - 2024-09-09 18:48:53 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-09 18:48:53 --> Controller Class Initialized
INFO - 2024-09-09 18:48:53 --> Helper loaded: cookie_helper
INFO - 2024-09-09 18:48:53 --> Final output sent to browser
DEBUG - 2024-09-09 18:48:53 --> Total execution time: 0.0350
INFO - 2024-09-09 18:48:53 --> Config Class Initialized
INFO - 2024-09-09 18:48:53 --> Hooks Class Initialized
DEBUG - 2024-09-09 18:48:53 --> UTF-8 Support Enabled
INFO - 2024-09-09 18:48:53 --> Utf8 Class Initialized
INFO - 2024-09-09 18:48:53 --> URI Class Initialized
INFO - 2024-09-09 18:48:53 --> Router Class Initialized
INFO - 2024-09-09 18:48:53 --> Output Class Initialized
INFO - 2024-09-09 18:48:53 --> Security Class Initialized
DEBUG - 2024-09-09 18:48:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-09 18:48:53 --> Input Class Initialized
INFO - 2024-09-09 18:48:53 --> Language Class Initialized
INFO - 2024-09-09 18:48:53 --> Language Class Initialized
INFO - 2024-09-09 18:48:53 --> Config Class Initialized
INFO - 2024-09-09 18:48:53 --> Loader Class Initialized
INFO - 2024-09-09 18:48:53 --> Helper loaded: url_helper
INFO - 2024-09-09 18:48:53 --> Helper loaded: file_helper
INFO - 2024-09-09 18:48:53 --> Helper loaded: form_helper
INFO - 2024-09-09 18:48:53 --> Helper loaded: my_helper
INFO - 2024-09-09 18:48:53 --> Database Driver Class Initialized
INFO - 2024-09-09 18:48:53 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-09 18:48:53 --> Controller Class Initialized
INFO - 2024-09-09 18:48:53 --> Helper loaded: cookie_helper
INFO - 2024-09-09 18:48:53 --> Config Class Initialized
INFO - 2024-09-09 18:48:53 --> Hooks Class Initialized
DEBUG - 2024-09-09 18:48:53 --> UTF-8 Support Enabled
INFO - 2024-09-09 18:48:53 --> Utf8 Class Initialized
INFO - 2024-09-09 18:48:53 --> URI Class Initialized
INFO - 2024-09-09 18:48:53 --> Router Class Initialized
INFO - 2024-09-09 18:48:53 --> Output Class Initialized
INFO - 2024-09-09 18:48:53 --> Security Class Initialized
DEBUG - 2024-09-09 18:48:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-09 18:48:53 --> Input Class Initialized
INFO - 2024-09-09 18:48:53 --> Language Class Initialized
INFO - 2024-09-09 18:48:53 --> Language Class Initialized
INFO - 2024-09-09 18:48:53 --> Config Class Initialized
INFO - 2024-09-09 18:48:53 --> Loader Class Initialized
INFO - 2024-09-09 18:48:53 --> Helper loaded: url_helper
INFO - 2024-09-09 18:48:53 --> Helper loaded: file_helper
INFO - 2024-09-09 18:48:53 --> Helper loaded: form_helper
INFO - 2024-09-09 18:48:53 --> Helper loaded: my_helper
INFO - 2024-09-09 18:48:53 --> Database Driver Class Initialized
INFO - 2024-09-09 18:48:53 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-09 18:48:53 --> Controller Class Initialized
DEBUG - 2024-09-09 18:48:53 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/lihat_raport/views/list.php
DEBUG - 2024-09-09 18:48:53 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-09-09 18:48:53 --> Final output sent to browser
DEBUG - 2024-09-09 18:48:53 --> Total execution time: 0.0380
INFO - 2024-09-09 18:49:38 --> Config Class Initialized
INFO - 2024-09-09 18:49:38 --> Hooks Class Initialized
DEBUG - 2024-09-09 18:49:38 --> UTF-8 Support Enabled
INFO - 2024-09-09 18:49:38 --> Utf8 Class Initialized
INFO - 2024-09-09 18:49:38 --> URI Class Initialized
INFO - 2024-09-09 18:49:38 --> Router Class Initialized
INFO - 2024-09-09 18:49:38 --> Output Class Initialized
INFO - 2024-09-09 18:49:38 --> Security Class Initialized
DEBUG - 2024-09-09 18:49:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-09 18:49:38 --> Input Class Initialized
INFO - 2024-09-09 18:49:38 --> Language Class Initialized
INFO - 2024-09-09 18:49:38 --> Language Class Initialized
INFO - 2024-09-09 18:49:38 --> Config Class Initialized
INFO - 2024-09-09 18:49:38 --> Loader Class Initialized
INFO - 2024-09-09 18:49:38 --> Helper loaded: url_helper
INFO - 2024-09-09 18:49:38 --> Helper loaded: file_helper
INFO - 2024-09-09 18:49:38 --> Helper loaded: form_helper
INFO - 2024-09-09 18:49:38 --> Helper loaded: my_helper
INFO - 2024-09-09 18:49:38 --> Database Driver Class Initialized
INFO - 2024-09-09 18:49:38 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-09 18:49:38 --> Controller Class Initialized
INFO - 2024-09-09 18:49:38 --> Helper loaded: cookie_helper
INFO - 2024-09-09 18:49:38 --> Final output sent to browser
DEBUG - 2024-09-09 18:49:38 --> Total execution time: 0.0379
INFO - 2024-09-09 18:49:39 --> Config Class Initialized
INFO - 2024-09-09 18:49:39 --> Hooks Class Initialized
DEBUG - 2024-09-09 18:49:39 --> UTF-8 Support Enabled
INFO - 2024-09-09 18:49:39 --> Utf8 Class Initialized
INFO - 2024-09-09 18:49:39 --> URI Class Initialized
INFO - 2024-09-09 18:49:39 --> Router Class Initialized
INFO - 2024-09-09 18:49:39 --> Output Class Initialized
INFO - 2024-09-09 18:49:39 --> Security Class Initialized
DEBUG - 2024-09-09 18:49:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-09 18:49:39 --> Input Class Initialized
INFO - 2024-09-09 18:49:39 --> Language Class Initialized
INFO - 2024-09-09 18:49:39 --> Language Class Initialized
INFO - 2024-09-09 18:49:39 --> Config Class Initialized
INFO - 2024-09-09 18:49:39 --> Loader Class Initialized
INFO - 2024-09-09 18:49:39 --> Helper loaded: url_helper
INFO - 2024-09-09 18:49:39 --> Helper loaded: file_helper
INFO - 2024-09-09 18:49:39 --> Helper loaded: form_helper
INFO - 2024-09-09 18:49:39 --> Helper loaded: my_helper
INFO - 2024-09-09 18:49:39 --> Database Driver Class Initialized
INFO - 2024-09-09 18:49:39 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-09 18:49:39 --> Controller Class Initialized
INFO - 2024-09-09 18:49:39 --> Helper loaded: cookie_helper
INFO - 2024-09-09 18:49:39 --> Config Class Initialized
INFO - 2024-09-09 18:49:39 --> Hooks Class Initialized
DEBUG - 2024-09-09 18:49:39 --> UTF-8 Support Enabled
INFO - 2024-09-09 18:49:39 --> Utf8 Class Initialized
INFO - 2024-09-09 18:49:39 --> URI Class Initialized
INFO - 2024-09-09 18:49:39 --> Router Class Initialized
INFO - 2024-09-09 18:49:39 --> Output Class Initialized
INFO - 2024-09-09 18:49:39 --> Security Class Initialized
DEBUG - 2024-09-09 18:49:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-09 18:49:39 --> Input Class Initialized
INFO - 2024-09-09 18:49:39 --> Language Class Initialized
INFO - 2024-09-09 18:49:39 --> Language Class Initialized
INFO - 2024-09-09 18:49:39 --> Config Class Initialized
INFO - 2024-09-09 18:49:39 --> Loader Class Initialized
INFO - 2024-09-09 18:49:39 --> Helper loaded: url_helper
INFO - 2024-09-09 18:49:39 --> Helper loaded: file_helper
INFO - 2024-09-09 18:49:39 --> Helper loaded: form_helper
INFO - 2024-09-09 18:49:39 --> Helper loaded: my_helper
INFO - 2024-09-09 18:49:39 --> Database Driver Class Initialized
INFO - 2024-09-09 18:49:39 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-09 18:49:39 --> Controller Class Initialized
DEBUG - 2024-09-09 18:49:39 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/lihat_raport/views/list.php
DEBUG - 2024-09-09 18:49:39 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-09-09 18:49:39 --> Final output sent to browser
DEBUG - 2024-09-09 18:49:39 --> Total execution time: 0.0382
