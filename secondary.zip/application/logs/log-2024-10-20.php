<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2024-10-20 21:35:58 --> Config Class Initialized
INFO - 2024-10-20 21:35:58 --> Hooks Class Initialized
DEBUG - 2024-10-20 21:35:58 --> UTF-8 Support Enabled
INFO - 2024-10-20 21:35:58 --> Utf8 Class Initialized
INFO - 2024-10-20 21:35:58 --> URI Class Initialized
INFO - 2024-10-20 21:35:58 --> Router Class Initialized
INFO - 2024-10-20 21:35:58 --> Output Class Initialized
INFO - 2024-10-20 21:35:58 --> Security Class Initialized
DEBUG - 2024-10-20 21:35:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-20 21:35:58 --> Input Class Initialized
INFO - 2024-10-20 21:35:58 --> Language Class Initialized
INFO - 2024-10-20 21:35:58 --> Language Class Initialized
INFO - 2024-10-20 21:35:58 --> Config Class Initialized
INFO - 2024-10-20 21:35:58 --> Loader Class Initialized
INFO - 2024-10-20 21:35:58 --> Helper loaded: url_helper
INFO - 2024-10-20 21:35:58 --> Helper loaded: file_helper
INFO - 2024-10-20 21:35:58 --> Helper loaded: form_helper
INFO - 2024-10-20 21:35:58 --> Helper loaded: my_helper
INFO - 2024-10-20 21:35:58 --> Database Driver Class Initialized
INFO - 2024-10-20 21:35:58 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-20 21:35:58 --> Controller Class Initialized
INFO - 2024-10-20 21:35:58 --> Helper loaded: cookie_helper
INFO - 2024-10-20 21:35:58 --> Final output sent to browser
DEBUG - 2024-10-20 21:35:58 --> Total execution time: 0.0771
INFO - 2024-10-20 21:35:59 --> Config Class Initialized
INFO - 2024-10-20 21:35:59 --> Hooks Class Initialized
DEBUG - 2024-10-20 21:35:59 --> UTF-8 Support Enabled
INFO - 2024-10-20 21:35:59 --> Utf8 Class Initialized
INFO - 2024-10-20 21:35:59 --> URI Class Initialized
INFO - 2024-10-20 21:35:59 --> Router Class Initialized
INFO - 2024-10-20 21:35:59 --> Output Class Initialized
INFO - 2024-10-20 21:35:59 --> Security Class Initialized
DEBUG - 2024-10-20 21:35:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-20 21:35:59 --> Input Class Initialized
INFO - 2024-10-20 21:35:59 --> Language Class Initialized
INFO - 2024-10-20 21:35:59 --> Language Class Initialized
INFO - 2024-10-20 21:35:59 --> Config Class Initialized
INFO - 2024-10-20 21:35:59 --> Loader Class Initialized
INFO - 2024-10-20 21:35:59 --> Helper loaded: url_helper
INFO - 2024-10-20 21:35:59 --> Helper loaded: file_helper
INFO - 2024-10-20 21:35:59 --> Helper loaded: form_helper
INFO - 2024-10-20 21:35:59 --> Helper loaded: my_helper
INFO - 2024-10-20 21:35:59 --> Database Driver Class Initialized
INFO - 2024-10-20 21:35:59 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-20 21:35:59 --> Controller Class Initialized
INFO - 2024-10-20 21:35:59 --> Helper loaded: cookie_helper
INFO - 2024-10-20 21:35:59 --> Config Class Initialized
INFO - 2024-10-20 21:35:59 --> Hooks Class Initialized
DEBUG - 2024-10-20 21:35:59 --> UTF-8 Support Enabled
INFO - 2024-10-20 21:35:59 --> Utf8 Class Initialized
INFO - 2024-10-20 21:35:59 --> URI Class Initialized
INFO - 2024-10-20 21:35:59 --> Router Class Initialized
INFO - 2024-10-20 21:35:59 --> Output Class Initialized
INFO - 2024-10-20 21:35:59 --> Security Class Initialized
DEBUG - 2024-10-20 21:35:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-20 21:35:59 --> Input Class Initialized
INFO - 2024-10-20 21:35:59 --> Language Class Initialized
INFO - 2024-10-20 21:35:59 --> Language Class Initialized
INFO - 2024-10-20 21:35:59 --> Config Class Initialized
INFO - 2024-10-20 21:35:59 --> Loader Class Initialized
INFO - 2024-10-20 21:35:59 --> Helper loaded: url_helper
INFO - 2024-10-20 21:35:59 --> Helper loaded: file_helper
INFO - 2024-10-20 21:35:59 --> Helper loaded: form_helper
INFO - 2024-10-20 21:35:59 --> Helper loaded: my_helper
INFO - 2024-10-20 21:35:59 --> Database Driver Class Initialized
INFO - 2024-10-20 21:35:59 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-20 21:35:59 --> Controller Class Initialized
DEBUG - 2024-10-20 21:35:59 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/lihat_raport/views/list.php
DEBUG - 2024-10-20 21:35:59 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-10-20 21:35:59 --> Final output sent to browser
DEBUG - 2024-10-20 21:35:59 --> Total execution time: 0.0474
INFO - 2024-10-20 21:36:03 --> Config Class Initialized
INFO - 2024-10-20 21:36:03 --> Hooks Class Initialized
DEBUG - 2024-10-20 21:36:03 --> UTF-8 Support Enabled
INFO - 2024-10-20 21:36:03 --> Utf8 Class Initialized
INFO - 2024-10-20 21:36:03 --> URI Class Initialized
INFO - 2024-10-20 21:36:03 --> Router Class Initialized
INFO - 2024-10-20 21:36:03 --> Output Class Initialized
INFO - 2024-10-20 21:36:03 --> Security Class Initialized
DEBUG - 2024-10-20 21:36:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-20 21:36:03 --> Input Class Initialized
INFO - 2024-10-20 21:36:03 --> Language Class Initialized
INFO - 2024-10-20 21:36:03 --> Language Class Initialized
INFO - 2024-10-20 21:36:03 --> Config Class Initialized
INFO - 2024-10-20 21:36:03 --> Loader Class Initialized
INFO - 2024-10-20 21:36:03 --> Helper loaded: url_helper
INFO - 2024-10-20 21:36:03 --> Helper loaded: file_helper
INFO - 2024-10-20 21:36:03 --> Helper loaded: form_helper
INFO - 2024-10-20 21:36:03 --> Helper loaded: my_helper
INFO - 2024-10-20 21:36:03 --> Database Driver Class Initialized
INFO - 2024-10-20 21:36:03 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-20 21:36:03 --> Controller Class Initialized
ERROR - 2024-10-20 21:36:03 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 107
ERROR - 2024-10-20 21:36:03 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 554
ERROR - 2024-10-20 21:36:03 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 554
ERROR - 2024-10-20 21:36:03 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 616
ERROR - 2024-10-20 21:36:03 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 679
ERROR - 2024-10-20 21:36:03 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 679
ERROR - 2024-10-20 21:36:03 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 686
ERROR - 2024-10-20 21:36:03 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 757
ERROR - 2024-10-20 21:36:03 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 760
ERROR - 2024-10-20 21:36:03 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 760
ERROR - 2024-10-20 21:36:03 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 832
ERROR - 2024-10-20 21:36:03 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 906
ERROR - 2024-10-20 21:36:03 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 906
ERROR - 2024-10-20 21:36:03 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 913
ERROR - 2024-10-20 21:36:03 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 987
ERROR - 2024-10-20 21:36:03 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 987
ERROR - 2024-10-20 21:36:03 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/views/cetak_rapot.php 83
ERROR - 2024-10-20 21:36:03 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/views/cetak_rapot.php 95
ERROR - 2024-10-20 21:36:03 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/views/cetak_rapot.php 95
DEBUG - 2024-10-20 21:36:03 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/views/cetak_rapot.php
INFO - 2024-10-20 21:36:05 --> Final output sent to browser
DEBUG - 2024-10-20 21:36:05 --> Total execution time: 2.5404
INFO - 2024-10-20 21:36:19 --> Config Class Initialized
INFO - 2024-10-20 21:36:19 --> Hooks Class Initialized
DEBUG - 2024-10-20 21:36:19 --> UTF-8 Support Enabled
INFO - 2024-10-20 21:36:19 --> Utf8 Class Initialized
INFO - 2024-10-20 21:36:19 --> URI Class Initialized
INFO - 2024-10-20 21:36:19 --> Router Class Initialized
INFO - 2024-10-20 21:36:19 --> Output Class Initialized
INFO - 2024-10-20 21:36:19 --> Security Class Initialized
DEBUG - 2024-10-20 21:36:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-20 21:36:19 --> Input Class Initialized
INFO - 2024-10-20 21:36:19 --> Language Class Initialized
INFO - 2024-10-20 21:36:19 --> Language Class Initialized
INFO - 2024-10-20 21:36:19 --> Config Class Initialized
INFO - 2024-10-20 21:36:19 --> Loader Class Initialized
INFO - 2024-10-20 21:36:19 --> Helper loaded: url_helper
INFO - 2024-10-20 21:36:19 --> Helper loaded: file_helper
INFO - 2024-10-20 21:36:19 --> Helper loaded: form_helper
INFO - 2024-10-20 21:36:19 --> Helper loaded: my_helper
INFO - 2024-10-20 21:36:19 --> Database Driver Class Initialized
INFO - 2024-10-20 21:36:19 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-20 21:36:19 --> Controller Class Initialized
ERROR - 2024-10-20 21:36:19 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 107
ERROR - 2024-10-20 21:36:19 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 554
ERROR - 2024-10-20 21:36:19 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 554
ERROR - 2024-10-20 21:36:19 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 616
ERROR - 2024-10-20 21:36:19 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 679
ERROR - 2024-10-20 21:36:19 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 679
ERROR - 2024-10-20 21:36:19 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 686
ERROR - 2024-10-20 21:36:19 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 757
ERROR - 2024-10-20 21:36:19 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 760
ERROR - 2024-10-20 21:36:19 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 760
ERROR - 2024-10-20 21:36:19 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 832
ERROR - 2024-10-20 21:36:19 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 906
ERROR - 2024-10-20 21:36:19 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 906
ERROR - 2024-10-20 21:36:19 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 913
ERROR - 2024-10-20 21:36:19 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 987
ERROR - 2024-10-20 21:36:19 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 987
ERROR - 2024-10-20 21:36:19 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/views/cetak_rapot.php 83
ERROR - 2024-10-20 21:36:19 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/views/cetak_rapot.php 95
ERROR - 2024-10-20 21:36:19 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/views/cetak_rapot.php 95
DEBUG - 2024-10-20 21:36:19 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/views/cetak_rapot.php
INFO - 2024-10-20 21:36:21 --> Final output sent to browser
DEBUG - 2024-10-20 21:36:21 --> Total execution time: 2.4096
INFO - 2024-10-20 21:36:28 --> Config Class Initialized
INFO - 2024-10-20 21:36:28 --> Hooks Class Initialized
DEBUG - 2024-10-20 21:36:28 --> UTF-8 Support Enabled
INFO - 2024-10-20 21:36:28 --> Utf8 Class Initialized
INFO - 2024-10-20 21:36:28 --> URI Class Initialized
INFO - 2024-10-20 21:36:28 --> Router Class Initialized
INFO - 2024-10-20 21:36:28 --> Output Class Initialized
INFO - 2024-10-20 21:36:28 --> Security Class Initialized
DEBUG - 2024-10-20 21:36:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-20 21:36:28 --> Input Class Initialized
INFO - 2024-10-20 21:36:28 --> Language Class Initialized
INFO - 2024-10-20 21:36:28 --> Language Class Initialized
INFO - 2024-10-20 21:36:28 --> Config Class Initialized
INFO - 2024-10-20 21:36:28 --> Loader Class Initialized
INFO - 2024-10-20 21:36:28 --> Helper loaded: url_helper
INFO - 2024-10-20 21:36:28 --> Helper loaded: file_helper
INFO - 2024-10-20 21:36:28 --> Helper loaded: form_helper
INFO - 2024-10-20 21:36:28 --> Helper loaded: my_helper
INFO - 2024-10-20 21:36:28 --> Database Driver Class Initialized
INFO - 2024-10-20 21:36:28 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-20 21:36:28 --> Controller Class Initialized
ERROR - 2024-10-20 21:36:28 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1160
ERROR - 2024-10-20 21:36:28 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1691
ERROR - 2024-10-20 21:36:28 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1728
ERROR - 2024-10-20 21:36:28 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1766
ERROR - 2024-10-20 21:36:28 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1805
ERROR - 2024-10-20 21:36:28 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1882
ERROR - 2024-10-20 21:36:28 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1961
ERROR - 2024-10-20 21:36:28 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 2041
ERROR - 2024-10-20 21:36:28 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 2121
ERROR - 2024-10-20 21:36:28 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 2201
ERROR - 2024-10-20 21:36:28 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 2276
ERROR - 2024-10-20 21:36:28 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php 32
ERROR - 2024-10-20 21:36:28 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php 32
DEBUG - 2024-10-20 21:36:28 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php
INFO - 2024-10-20 21:36:30 --> Final output sent to browser
DEBUG - 2024-10-20 21:36:30 --> Total execution time: 2.4572
INFO - 2024-10-20 21:36:46 --> Config Class Initialized
INFO - 2024-10-20 21:36:46 --> Hooks Class Initialized
DEBUG - 2024-10-20 21:36:46 --> UTF-8 Support Enabled
INFO - 2024-10-20 21:36:46 --> Utf8 Class Initialized
INFO - 2024-10-20 21:36:46 --> URI Class Initialized
INFO - 2024-10-20 21:36:46 --> Router Class Initialized
INFO - 2024-10-20 21:36:46 --> Output Class Initialized
INFO - 2024-10-20 21:36:46 --> Security Class Initialized
DEBUG - 2024-10-20 21:36:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-20 21:36:46 --> Input Class Initialized
INFO - 2024-10-20 21:36:46 --> Language Class Initialized
INFO - 2024-10-20 21:36:46 --> Language Class Initialized
INFO - 2024-10-20 21:36:46 --> Config Class Initialized
INFO - 2024-10-20 21:36:46 --> Loader Class Initialized
INFO - 2024-10-20 21:36:46 --> Helper loaded: url_helper
INFO - 2024-10-20 21:36:46 --> Helper loaded: file_helper
INFO - 2024-10-20 21:36:46 --> Helper loaded: form_helper
INFO - 2024-10-20 21:36:46 --> Helper loaded: my_helper
INFO - 2024-10-20 21:36:46 --> Database Driver Class Initialized
INFO - 2024-10-20 21:36:46 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-20 21:36:46 --> Controller Class Initialized
DEBUG - 2024-10-20 21:36:46 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/views/cetak_tahfiz.php
INFO - 2024-10-20 21:36:50 --> Final output sent to browser
DEBUG - 2024-10-20 21:36:50 --> Total execution time: 3.2784
INFO - 2024-10-20 21:36:55 --> Config Class Initialized
INFO - 2024-10-20 21:36:55 --> Hooks Class Initialized
DEBUG - 2024-10-20 21:36:55 --> UTF-8 Support Enabled
INFO - 2024-10-20 21:36:55 --> Utf8 Class Initialized
INFO - 2024-10-20 21:36:55 --> URI Class Initialized
INFO - 2024-10-20 21:36:55 --> Router Class Initialized
INFO - 2024-10-20 21:36:55 --> Output Class Initialized
INFO - 2024-10-20 21:36:55 --> Security Class Initialized
DEBUG - 2024-10-20 21:36:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-20 21:36:55 --> Input Class Initialized
INFO - 2024-10-20 21:36:55 --> Language Class Initialized
INFO - 2024-10-20 21:36:55 --> Language Class Initialized
INFO - 2024-10-20 21:36:55 --> Config Class Initialized
INFO - 2024-10-20 21:36:55 --> Loader Class Initialized
INFO - 2024-10-20 21:36:55 --> Helper loaded: url_helper
INFO - 2024-10-20 21:36:55 --> Helper loaded: file_helper
INFO - 2024-10-20 21:36:55 --> Helper loaded: form_helper
INFO - 2024-10-20 21:36:55 --> Helper loaded: my_helper
INFO - 2024-10-20 21:36:55 --> Database Driver Class Initialized
INFO - 2024-10-20 21:36:55 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-20 21:36:55 --> Controller Class Initialized
DEBUG - 2024-10-20 21:36:55 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/views/cetak_tahfiz.php
INFO - 2024-10-20 21:36:58 --> Final output sent to browser
DEBUG - 2024-10-20 21:36:58 --> Total execution time: 3.1758
INFO - 2024-10-20 21:37:45 --> Config Class Initialized
INFO - 2024-10-20 21:37:45 --> Hooks Class Initialized
DEBUG - 2024-10-20 21:37:45 --> UTF-8 Support Enabled
INFO - 2024-10-20 21:37:45 --> Utf8 Class Initialized
INFO - 2024-10-20 21:37:45 --> URI Class Initialized
INFO - 2024-10-20 21:37:45 --> Router Class Initialized
INFO - 2024-10-20 21:37:45 --> Output Class Initialized
INFO - 2024-10-20 21:37:45 --> Security Class Initialized
DEBUG - 2024-10-20 21:37:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-20 21:37:45 --> Input Class Initialized
INFO - 2024-10-20 21:37:45 --> Language Class Initialized
INFO - 2024-10-20 21:37:45 --> Language Class Initialized
INFO - 2024-10-20 21:37:45 --> Config Class Initialized
INFO - 2024-10-20 21:37:45 --> Loader Class Initialized
INFO - 2024-10-20 21:37:45 --> Helper loaded: url_helper
INFO - 2024-10-20 21:37:45 --> Helper loaded: file_helper
INFO - 2024-10-20 21:37:45 --> Helper loaded: form_helper
INFO - 2024-10-20 21:37:45 --> Helper loaded: my_helper
INFO - 2024-10-20 21:37:45 --> Database Driver Class Initialized
INFO - 2024-10-20 21:37:45 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-20 21:37:45 --> Controller Class Initialized
ERROR - 2024-10-20 21:37:45 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1797
ERROR - 2024-10-20 21:37:45 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1804
ERROR - 2024-10-20 21:37:45 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 2022
ERROR - 2024-10-20 21:37:45 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 2022
ERROR - 2024-10-20 21:37:45 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/views/cetak_projek.php 67
ERROR - 2024-10-20 21:37:45 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/views/cetak_projek.php 86
ERROR - 2024-10-20 21:37:45 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/views/cetak_projek.php 98
ERROR - 2024-10-20 21:37:45 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/views/cetak_projek.php 98
ERROR - 2024-10-20 21:37:45 --> Severity: Notice --> Undefined variable: projek /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/views/cetak_projek.php 107
ERROR - 2024-10-20 21:37:45 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/views/cetak_projek.php 297
ERROR - 2024-10-20 21:37:45 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/views/cetak_projek.php 307
DEBUG - 2024-10-20 21:37:45 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/views/cetak_projek.php
ERROR - 2024-10-20 21:37:48 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 2037
ERROR - 2024-10-20 21:37:48 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 2037
INFO - 2024-10-20 21:37:48 --> Final output sent to browser
DEBUG - 2024-10-20 21:37:48 --> Total execution time: 3.1898
INFO - 2024-10-20 21:39:24 --> Config Class Initialized
INFO - 2024-10-20 21:39:24 --> Hooks Class Initialized
DEBUG - 2024-10-20 21:39:24 --> UTF-8 Support Enabled
INFO - 2024-10-20 21:39:24 --> Utf8 Class Initialized
INFO - 2024-10-20 21:39:24 --> URI Class Initialized
INFO - 2024-10-20 21:39:24 --> Router Class Initialized
INFO - 2024-10-20 21:39:24 --> Output Class Initialized
INFO - 2024-10-20 21:39:24 --> Security Class Initialized
DEBUG - 2024-10-20 21:39:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-20 21:39:24 --> Input Class Initialized
INFO - 2024-10-20 21:39:24 --> Language Class Initialized
INFO - 2024-10-20 21:39:24 --> Language Class Initialized
INFO - 2024-10-20 21:39:24 --> Config Class Initialized
INFO - 2024-10-20 21:39:24 --> Loader Class Initialized
INFO - 2024-10-20 21:39:24 --> Helper loaded: url_helper
INFO - 2024-10-20 21:39:24 --> Helper loaded: file_helper
INFO - 2024-10-20 21:39:24 --> Helper loaded: form_helper
INFO - 2024-10-20 21:39:24 --> Helper loaded: my_helper
INFO - 2024-10-20 21:39:24 --> Database Driver Class Initialized
INFO - 2024-10-20 21:39:24 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-20 21:39:24 --> Controller Class Initialized
ERROR - 2024-10-20 21:39:24 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1160
ERROR - 2024-10-20 21:39:24 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1691
ERROR - 2024-10-20 21:39:24 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1728
ERROR - 2024-10-20 21:39:24 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1766
ERROR - 2024-10-20 21:39:24 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1805
ERROR - 2024-10-20 21:39:24 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1882
ERROR - 2024-10-20 21:39:24 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1961
ERROR - 2024-10-20 21:39:24 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 2041
ERROR - 2024-10-20 21:39:24 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 2121
ERROR - 2024-10-20 21:39:24 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 2201
ERROR - 2024-10-20 21:39:24 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 2276
ERROR - 2024-10-20 21:39:24 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php 32
ERROR - 2024-10-20 21:39:24 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php 32
DEBUG - 2024-10-20 21:39:24 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php
INFO - 2024-10-20 21:39:26 --> Final output sent to browser
DEBUG - 2024-10-20 21:39:26 --> Total execution time: 2.2528
INFO - 2024-10-20 21:39:39 --> Config Class Initialized
INFO - 2024-10-20 21:39:39 --> Hooks Class Initialized
DEBUG - 2024-10-20 21:39:39 --> UTF-8 Support Enabled
INFO - 2024-10-20 21:39:39 --> Utf8 Class Initialized
INFO - 2024-10-20 21:39:39 --> URI Class Initialized
INFO - 2024-10-20 21:39:39 --> Router Class Initialized
INFO - 2024-10-20 21:39:39 --> Output Class Initialized
INFO - 2024-10-20 21:39:39 --> Security Class Initialized
DEBUG - 2024-10-20 21:39:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-20 21:39:39 --> Input Class Initialized
INFO - 2024-10-20 21:39:39 --> Language Class Initialized
INFO - 2024-10-20 21:39:39 --> Language Class Initialized
INFO - 2024-10-20 21:39:39 --> Config Class Initialized
INFO - 2024-10-20 21:39:39 --> Loader Class Initialized
INFO - 2024-10-20 21:39:39 --> Helper loaded: url_helper
INFO - 2024-10-20 21:39:39 --> Helper loaded: file_helper
INFO - 2024-10-20 21:39:39 --> Helper loaded: form_helper
INFO - 2024-10-20 21:39:39 --> Helper loaded: my_helper
INFO - 2024-10-20 21:39:39 --> Database Driver Class Initialized
INFO - 2024-10-20 21:39:39 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-20 21:39:39 --> Controller Class Initialized
DEBUG - 2024-10-20 21:39:39 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php
INFO - 2024-10-20 21:39:41 --> Final output sent to browser
DEBUG - 2024-10-20 21:39:41 --> Total execution time: 2.5391
INFO - 2024-10-20 21:51:16 --> Config Class Initialized
INFO - 2024-10-20 21:51:16 --> Hooks Class Initialized
DEBUG - 2024-10-20 21:51:16 --> UTF-8 Support Enabled
INFO - 2024-10-20 21:51:16 --> Utf8 Class Initialized
INFO - 2024-10-20 21:51:16 --> URI Class Initialized
INFO - 2024-10-20 21:51:16 --> Router Class Initialized
INFO - 2024-10-20 21:51:16 --> Output Class Initialized
INFO - 2024-10-20 21:51:16 --> Security Class Initialized
DEBUG - 2024-10-20 21:51:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-20 21:51:16 --> Input Class Initialized
INFO - 2024-10-20 21:51:16 --> Language Class Initialized
INFO - 2024-10-20 21:51:16 --> Language Class Initialized
INFO - 2024-10-20 21:51:16 --> Config Class Initialized
INFO - 2024-10-20 21:51:16 --> Loader Class Initialized
INFO - 2024-10-20 21:51:16 --> Helper loaded: url_helper
INFO - 2024-10-20 21:51:16 --> Helper loaded: file_helper
INFO - 2024-10-20 21:51:16 --> Helper loaded: form_helper
INFO - 2024-10-20 21:51:16 --> Helper loaded: my_helper
INFO - 2024-10-20 21:51:16 --> Database Driver Class Initialized
INFO - 2024-10-20 21:51:16 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-20 21:51:17 --> Controller Class Initialized
INFO - 2024-10-20 21:51:17 --> Helper loaded: cookie_helper
INFO - 2024-10-20 21:51:17 --> Final output sent to browser
DEBUG - 2024-10-20 21:51:17 --> Total execution time: 0.0345
INFO - 2024-10-20 21:51:17 --> Config Class Initialized
INFO - 2024-10-20 21:51:17 --> Hooks Class Initialized
DEBUG - 2024-10-20 21:51:17 --> UTF-8 Support Enabled
INFO - 2024-10-20 21:51:17 --> Utf8 Class Initialized
INFO - 2024-10-20 21:51:17 --> URI Class Initialized
INFO - 2024-10-20 21:51:17 --> Router Class Initialized
INFO - 2024-10-20 21:51:17 --> Output Class Initialized
INFO - 2024-10-20 21:51:17 --> Security Class Initialized
DEBUG - 2024-10-20 21:51:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-20 21:51:17 --> Input Class Initialized
INFO - 2024-10-20 21:51:17 --> Language Class Initialized
INFO - 2024-10-20 21:51:17 --> Language Class Initialized
INFO - 2024-10-20 21:51:17 --> Config Class Initialized
INFO - 2024-10-20 21:51:17 --> Loader Class Initialized
INFO - 2024-10-20 21:51:17 --> Helper loaded: url_helper
INFO - 2024-10-20 21:51:17 --> Helper loaded: file_helper
INFO - 2024-10-20 21:51:17 --> Helper loaded: form_helper
INFO - 2024-10-20 21:51:17 --> Helper loaded: my_helper
INFO - 2024-10-20 21:51:17 --> Database Driver Class Initialized
INFO - 2024-10-20 21:51:17 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-20 21:51:17 --> Controller Class Initialized
INFO - 2024-10-20 21:51:17 --> Helper loaded: cookie_helper
INFO - 2024-10-20 21:51:17 --> Config Class Initialized
INFO - 2024-10-20 21:51:17 --> Hooks Class Initialized
DEBUG - 2024-10-20 21:51:17 --> UTF-8 Support Enabled
INFO - 2024-10-20 21:51:17 --> Utf8 Class Initialized
INFO - 2024-10-20 21:51:17 --> URI Class Initialized
INFO - 2024-10-20 21:51:17 --> Router Class Initialized
INFO - 2024-10-20 21:51:17 --> Output Class Initialized
INFO - 2024-10-20 21:51:17 --> Security Class Initialized
DEBUG - 2024-10-20 21:51:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-20 21:51:17 --> Input Class Initialized
INFO - 2024-10-20 21:51:17 --> Language Class Initialized
INFO - 2024-10-20 21:51:17 --> Language Class Initialized
INFO - 2024-10-20 21:51:17 --> Config Class Initialized
INFO - 2024-10-20 21:51:17 --> Loader Class Initialized
INFO - 2024-10-20 21:51:17 --> Helper loaded: url_helper
INFO - 2024-10-20 21:51:17 --> Helper loaded: file_helper
INFO - 2024-10-20 21:51:17 --> Helper loaded: form_helper
INFO - 2024-10-20 21:51:17 --> Helper loaded: my_helper
INFO - 2024-10-20 21:51:17 --> Database Driver Class Initialized
INFO - 2024-10-20 21:51:17 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-20 21:51:17 --> Controller Class Initialized
DEBUG - 2024-10-20 21:51:17 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/lihat_raport/views/list.php
DEBUG - 2024-10-20 21:51:17 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-10-20 21:51:17 --> Final output sent to browser
DEBUG - 2024-10-20 21:51:17 --> Total execution time: 0.0906
INFO - 2024-10-20 21:51:19 --> Config Class Initialized
INFO - 2024-10-20 21:51:19 --> Hooks Class Initialized
DEBUG - 2024-10-20 21:51:19 --> UTF-8 Support Enabled
INFO - 2024-10-20 21:51:19 --> Utf8 Class Initialized
INFO - 2024-10-20 21:51:19 --> URI Class Initialized
INFO - 2024-10-20 21:51:19 --> Router Class Initialized
INFO - 2024-10-20 21:51:19 --> Output Class Initialized
INFO - 2024-10-20 21:51:19 --> Security Class Initialized
DEBUG - 2024-10-20 21:51:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-20 21:51:20 --> Input Class Initialized
INFO - 2024-10-20 21:51:20 --> Language Class Initialized
INFO - 2024-10-20 21:51:20 --> Language Class Initialized
INFO - 2024-10-20 21:51:20 --> Config Class Initialized
INFO - 2024-10-20 21:51:20 --> Loader Class Initialized
INFO - 2024-10-20 21:51:20 --> Helper loaded: url_helper
INFO - 2024-10-20 21:51:20 --> Helper loaded: file_helper
INFO - 2024-10-20 21:51:20 --> Helper loaded: form_helper
INFO - 2024-10-20 21:51:20 --> Helper loaded: my_helper
INFO - 2024-10-20 21:51:20 --> Database Driver Class Initialized
INFO - 2024-10-20 21:51:20 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-20 21:51:20 --> Controller Class Initialized
DEBUG - 2024-10-20 21:51:20 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php
INFO - 2024-10-20 21:51:22 --> Final output sent to browser
DEBUG - 2024-10-20 21:51:22 --> Total execution time: 2.9759
