<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2024-08-28 10:26:25 --> Config Class Initialized
INFO - 2024-08-28 10:26:25 --> Hooks Class Initialized
DEBUG - 2024-08-28 10:26:25 --> UTF-8 Support Enabled
INFO - 2024-08-28 10:26:25 --> Utf8 Class Initialized
INFO - 2024-08-28 10:26:25 --> URI Class Initialized
INFO - 2024-08-28 10:26:25 --> Router Class Initialized
INFO - 2024-08-28 10:26:25 --> Output Class Initialized
INFO - 2024-08-28 10:26:25 --> Security Class Initialized
DEBUG - 2024-08-28 10:26:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-08-28 10:26:25 --> Input Class Initialized
INFO - 2024-08-28 10:26:25 --> Language Class Initialized
INFO - 2024-08-28 10:26:25 --> Language Class Initialized
INFO - 2024-08-28 10:26:25 --> Config Class Initialized
INFO - 2024-08-28 10:26:25 --> Loader Class Initialized
INFO - 2024-08-28 10:26:25 --> Helper loaded: url_helper
INFO - 2024-08-28 10:26:25 --> Helper loaded: file_helper
INFO - 2024-08-28 10:26:25 --> Helper loaded: form_helper
INFO - 2024-08-28 10:26:25 --> Helper loaded: my_helper
INFO - 2024-08-28 10:26:25 --> Database Driver Class Initialized
INFO - 2024-08-28 10:26:25 --> Session: Class initialized using 'files' driver.
INFO - 2024-08-28 10:26:25 --> Controller Class Initialized
INFO - 2024-08-28 10:26:25 --> Helper loaded: cookie_helper
INFO - 2024-08-28 10:26:25 --> Final output sent to browser
DEBUG - 2024-08-28 10:26:25 --> Total execution time: 0.1940
INFO - 2024-08-28 10:26:26 --> Config Class Initialized
INFO - 2024-08-28 10:26:26 --> Hooks Class Initialized
DEBUG - 2024-08-28 10:26:26 --> UTF-8 Support Enabled
INFO - 2024-08-28 10:26:26 --> Utf8 Class Initialized
INFO - 2024-08-28 10:26:26 --> URI Class Initialized
INFO - 2024-08-28 10:26:26 --> Router Class Initialized
INFO - 2024-08-28 10:26:26 --> Output Class Initialized
INFO - 2024-08-28 10:26:26 --> Security Class Initialized
DEBUG - 2024-08-28 10:26:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-08-28 10:26:26 --> Input Class Initialized
INFO - 2024-08-28 10:26:26 --> Language Class Initialized
INFO - 2024-08-28 10:26:26 --> Language Class Initialized
INFO - 2024-08-28 10:26:26 --> Config Class Initialized
INFO - 2024-08-28 10:26:26 --> Loader Class Initialized
INFO - 2024-08-28 10:26:26 --> Helper loaded: url_helper
INFO - 2024-08-28 10:26:26 --> Helper loaded: file_helper
INFO - 2024-08-28 10:26:26 --> Helper loaded: form_helper
INFO - 2024-08-28 10:26:26 --> Helper loaded: my_helper
INFO - 2024-08-28 10:26:26 --> Database Driver Class Initialized
INFO - 2024-08-28 10:26:26 --> Session: Class initialized using 'files' driver.
INFO - 2024-08-28 10:26:26 --> Controller Class Initialized
INFO - 2024-08-28 10:26:26 --> Helper loaded: cookie_helper
INFO - 2024-08-28 10:26:26 --> Config Class Initialized
INFO - 2024-08-28 10:26:26 --> Hooks Class Initialized
DEBUG - 2024-08-28 10:26:26 --> UTF-8 Support Enabled
INFO - 2024-08-28 10:26:26 --> Utf8 Class Initialized
INFO - 2024-08-28 10:26:26 --> URI Class Initialized
INFO - 2024-08-28 10:26:26 --> Router Class Initialized
INFO - 2024-08-28 10:26:26 --> Output Class Initialized
INFO - 2024-08-28 10:26:26 --> Security Class Initialized
DEBUG - 2024-08-28 10:26:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-08-28 10:26:26 --> Input Class Initialized
INFO - 2024-08-28 10:26:26 --> Language Class Initialized
INFO - 2024-08-28 10:26:26 --> Language Class Initialized
INFO - 2024-08-28 10:26:26 --> Config Class Initialized
INFO - 2024-08-28 10:26:26 --> Loader Class Initialized
INFO - 2024-08-28 10:26:26 --> Helper loaded: url_helper
INFO - 2024-08-28 10:26:26 --> Helper loaded: file_helper
INFO - 2024-08-28 10:26:26 --> Helper loaded: form_helper
INFO - 2024-08-28 10:26:26 --> Helper loaded: my_helper
INFO - 2024-08-28 10:26:26 --> Database Driver Class Initialized
INFO - 2024-08-28 10:26:26 --> Session: Class initialized using 'files' driver.
INFO - 2024-08-28 10:26:26 --> Controller Class Initialized
DEBUG - 2024-08-28 10:26:26 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/lihat_raport/views/list.php
DEBUG - 2024-08-28 10:26:26 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-08-28 10:26:26 --> Final output sent to browser
DEBUG - 2024-08-28 10:26:26 --> Total execution time: 0.0465
INFO - 2024-08-28 12:35:19 --> Config Class Initialized
INFO - 2024-08-28 12:35:19 --> Hooks Class Initialized
DEBUG - 2024-08-28 12:35:19 --> UTF-8 Support Enabled
INFO - 2024-08-28 12:35:19 --> Utf8 Class Initialized
INFO - 2024-08-28 12:35:19 --> URI Class Initialized
INFO - 2024-08-28 12:35:19 --> Router Class Initialized
INFO - 2024-08-28 12:35:19 --> Output Class Initialized
INFO - 2024-08-28 12:35:19 --> Security Class Initialized
DEBUG - 2024-08-28 12:35:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-08-28 12:35:19 --> Input Class Initialized
INFO - 2024-08-28 12:35:19 --> Language Class Initialized
INFO - 2024-08-28 12:35:19 --> Language Class Initialized
INFO - 2024-08-28 12:35:19 --> Config Class Initialized
INFO - 2024-08-28 12:35:19 --> Loader Class Initialized
INFO - 2024-08-28 12:35:19 --> Helper loaded: url_helper
INFO - 2024-08-28 12:35:19 --> Helper loaded: file_helper
INFO - 2024-08-28 12:35:19 --> Helper loaded: form_helper
INFO - 2024-08-28 12:35:19 --> Helper loaded: my_helper
INFO - 2024-08-28 12:35:19 --> Database Driver Class Initialized
INFO - 2024-08-28 12:35:19 --> Session: Class initialized using 'files' driver.
INFO - 2024-08-28 12:35:19 --> Controller Class Initialized
INFO - 2024-08-28 12:35:19 --> Helper loaded: cookie_helper
INFO - 2024-08-28 12:35:19 --> Final output sent to browser
DEBUG - 2024-08-28 12:35:19 --> Total execution time: 0.0436
INFO - 2024-08-28 12:35:19 --> Config Class Initialized
INFO - 2024-08-28 12:35:19 --> Hooks Class Initialized
DEBUG - 2024-08-28 12:35:19 --> UTF-8 Support Enabled
INFO - 2024-08-28 12:35:19 --> Utf8 Class Initialized
INFO - 2024-08-28 12:35:19 --> URI Class Initialized
INFO - 2024-08-28 12:35:19 --> Router Class Initialized
INFO - 2024-08-28 12:35:19 --> Output Class Initialized
INFO - 2024-08-28 12:35:19 --> Security Class Initialized
DEBUG - 2024-08-28 12:35:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-08-28 12:35:19 --> Input Class Initialized
INFO - 2024-08-28 12:35:19 --> Language Class Initialized
INFO - 2024-08-28 12:35:19 --> Language Class Initialized
INFO - 2024-08-28 12:35:19 --> Config Class Initialized
INFO - 2024-08-28 12:35:19 --> Loader Class Initialized
INFO - 2024-08-28 12:35:19 --> Helper loaded: url_helper
INFO - 2024-08-28 12:35:19 --> Helper loaded: file_helper
INFO - 2024-08-28 12:35:19 --> Helper loaded: form_helper
INFO - 2024-08-28 12:35:19 --> Helper loaded: my_helper
INFO - 2024-08-28 12:35:19 --> Database Driver Class Initialized
INFO - 2024-08-28 12:35:19 --> Session: Class initialized using 'files' driver.
INFO - 2024-08-28 12:35:19 --> Controller Class Initialized
INFO - 2024-08-28 12:35:19 --> Helper loaded: cookie_helper
INFO - 2024-08-28 12:35:19 --> Config Class Initialized
INFO - 2024-08-28 12:35:19 --> Hooks Class Initialized
DEBUG - 2024-08-28 12:35:19 --> UTF-8 Support Enabled
INFO - 2024-08-28 12:35:19 --> Utf8 Class Initialized
INFO - 2024-08-28 12:35:19 --> URI Class Initialized
INFO - 2024-08-28 12:35:19 --> Router Class Initialized
INFO - 2024-08-28 12:35:19 --> Output Class Initialized
INFO - 2024-08-28 12:35:19 --> Security Class Initialized
DEBUG - 2024-08-28 12:35:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-08-28 12:35:19 --> Input Class Initialized
INFO - 2024-08-28 12:35:19 --> Language Class Initialized
INFO - 2024-08-28 12:35:19 --> Language Class Initialized
INFO - 2024-08-28 12:35:19 --> Config Class Initialized
INFO - 2024-08-28 12:35:19 --> Loader Class Initialized
INFO - 2024-08-28 12:35:19 --> Helper loaded: url_helper
INFO - 2024-08-28 12:35:19 --> Helper loaded: file_helper
INFO - 2024-08-28 12:35:19 --> Helper loaded: form_helper
INFO - 2024-08-28 12:35:19 --> Helper loaded: my_helper
INFO - 2024-08-28 12:35:19 --> Database Driver Class Initialized
INFO - 2024-08-28 12:35:19 --> Session: Class initialized using 'files' driver.
INFO - 2024-08-28 12:35:19 --> Controller Class Initialized
DEBUG - 2024-08-28 12:35:19 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/lihat_raport/views/list.php
DEBUG - 2024-08-28 12:35:19 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-08-28 12:35:19 --> Final output sent to browser
DEBUG - 2024-08-28 12:35:19 --> Total execution time: 0.0316
INFO - 2024-08-28 12:35:28 --> Config Class Initialized
INFO - 2024-08-28 12:35:28 --> Hooks Class Initialized
DEBUG - 2024-08-28 12:35:28 --> UTF-8 Support Enabled
INFO - 2024-08-28 12:35:28 --> Utf8 Class Initialized
INFO - 2024-08-28 12:35:28 --> URI Class Initialized
INFO - 2024-08-28 12:35:28 --> Router Class Initialized
INFO - 2024-08-28 12:35:28 --> Output Class Initialized
INFO - 2024-08-28 12:35:28 --> Security Class Initialized
DEBUG - 2024-08-28 12:35:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-08-28 12:35:28 --> Input Class Initialized
INFO - 2024-08-28 12:35:28 --> Language Class Initialized
INFO - 2024-08-28 12:35:28 --> Language Class Initialized
INFO - 2024-08-28 12:35:28 --> Config Class Initialized
INFO - 2024-08-28 12:35:28 --> Loader Class Initialized
INFO - 2024-08-28 12:35:28 --> Helper loaded: url_helper
INFO - 2024-08-28 12:35:28 --> Helper loaded: file_helper
INFO - 2024-08-28 12:35:28 --> Helper loaded: form_helper
INFO - 2024-08-28 12:35:28 --> Helper loaded: my_helper
INFO - 2024-08-28 12:35:28 --> Database Driver Class Initialized
INFO - 2024-08-28 12:35:28 --> Session: Class initialized using 'files' driver.
INFO - 2024-08-28 12:35:28 --> Controller Class Initialized
ERROR - 2024-08-28 12:35:28 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1797
ERROR - 2024-08-28 12:35:28 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1804
ERROR - 2024-08-28 12:35:28 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 2022
ERROR - 2024-08-28 12:35:28 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 2022
ERROR - 2024-08-28 12:35:28 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/views/cetak_projek.php 67
ERROR - 2024-08-28 12:35:28 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/views/cetak_projek.php 86
ERROR - 2024-08-28 12:35:28 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/views/cetak_projek.php 98
ERROR - 2024-08-28 12:35:28 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/views/cetak_projek.php 98
ERROR - 2024-08-28 12:35:28 --> Severity: Notice --> Undefined variable: projek /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/views/cetak_projek.php 107
ERROR - 2024-08-28 12:35:28 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/views/cetak_projek.php 297
ERROR - 2024-08-28 12:35:28 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/views/cetak_projek.php 307
DEBUG - 2024-08-28 12:35:28 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/views/cetak_projek.php
INFO - 2024-08-28 12:35:31 --> Config Class Initialized
INFO - 2024-08-28 12:35:31 --> Hooks Class Initialized
DEBUG - 2024-08-28 12:35:31 --> UTF-8 Support Enabled
INFO - 2024-08-28 12:35:31 --> Utf8 Class Initialized
INFO - 2024-08-28 12:35:31 --> URI Class Initialized
INFO - 2024-08-28 12:35:31 --> Router Class Initialized
INFO - 2024-08-28 12:35:31 --> Output Class Initialized
INFO - 2024-08-28 12:35:31 --> Security Class Initialized
DEBUG - 2024-08-28 12:35:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-08-28 12:35:31 --> Input Class Initialized
INFO - 2024-08-28 12:35:31 --> Language Class Initialized
INFO - 2024-08-28 12:35:31 --> Language Class Initialized
INFO - 2024-08-28 12:35:31 --> Config Class Initialized
INFO - 2024-08-28 12:35:31 --> Loader Class Initialized
INFO - 2024-08-28 12:35:31 --> Helper loaded: url_helper
INFO - 2024-08-28 12:35:31 --> Helper loaded: file_helper
INFO - 2024-08-28 12:35:31 --> Helper loaded: form_helper
INFO - 2024-08-28 12:35:31 --> Helper loaded: my_helper
INFO - 2024-08-28 12:35:31 --> Database Driver Class Initialized
ERROR - 2024-08-28 12:35:31 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 2037
ERROR - 2024-08-28 12:35:31 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 2037
INFO - 2024-08-28 12:35:32 --> Session: Class initialized using 'files' driver.
INFO - 2024-08-28 12:35:32 --> Controller Class Initialized
ERROR - 2024-08-28 12:35:32 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1797
ERROR - 2024-08-28 12:35:32 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1804
ERROR - 2024-08-28 12:35:32 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 2022
ERROR - 2024-08-28 12:35:32 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 2022
ERROR - 2024-08-28 12:35:32 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/views/cetak_projek.php 67
ERROR - 2024-08-28 12:35:32 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/views/cetak_projek.php 86
ERROR - 2024-08-28 12:35:32 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/views/cetak_projek.php 98
ERROR - 2024-08-28 12:35:32 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/views/cetak_projek.php 98
ERROR - 2024-08-28 12:35:32 --> Severity: Notice --> Undefined variable: projek /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/views/cetak_projek.php 107
ERROR - 2024-08-28 12:35:32 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/views/cetak_projek.php 297
ERROR - 2024-08-28 12:35:32 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/views/cetak_projek.php 307
DEBUG - 2024-08-28 12:35:32 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/views/cetak_projek.php
INFO - 2024-08-28 12:35:34 --> Config Class Initialized
INFO - 2024-08-28 12:35:34 --> Hooks Class Initialized
DEBUG - 2024-08-28 12:35:34 --> UTF-8 Support Enabled
INFO - 2024-08-28 12:35:34 --> Utf8 Class Initialized
INFO - 2024-08-28 12:35:34 --> URI Class Initialized
INFO - 2024-08-28 12:35:34 --> Router Class Initialized
INFO - 2024-08-28 12:35:34 --> Output Class Initialized
INFO - 2024-08-28 12:35:34 --> Security Class Initialized
DEBUG - 2024-08-28 12:35:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-08-28 12:35:34 --> Input Class Initialized
INFO - 2024-08-28 12:35:34 --> Language Class Initialized
INFO - 2024-08-28 12:35:34 --> Language Class Initialized
INFO - 2024-08-28 12:35:34 --> Config Class Initialized
INFO - 2024-08-28 12:35:34 --> Loader Class Initialized
INFO - 2024-08-28 12:35:34 --> Helper loaded: url_helper
INFO - 2024-08-28 12:35:34 --> Helper loaded: file_helper
INFO - 2024-08-28 12:35:34 --> Helper loaded: form_helper
INFO - 2024-08-28 12:35:34 --> Helper loaded: my_helper
INFO - 2024-08-28 12:35:34 --> Database Driver Class Initialized
INFO - 2024-08-28 12:35:34 --> Config Class Initialized
INFO - 2024-08-28 12:35:34 --> Hooks Class Initialized
DEBUG - 2024-08-28 12:35:34 --> UTF-8 Support Enabled
INFO - 2024-08-28 12:35:34 --> Utf8 Class Initialized
INFO - 2024-08-28 12:35:34 --> URI Class Initialized
INFO - 2024-08-28 12:35:34 --> Router Class Initialized
INFO - 2024-08-28 12:35:34 --> Output Class Initialized
INFO - 2024-08-28 12:35:34 --> Security Class Initialized
DEBUG - 2024-08-28 12:35:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-08-28 12:35:34 --> Input Class Initialized
INFO - 2024-08-28 12:35:34 --> Language Class Initialized
INFO - 2024-08-28 12:35:34 --> Language Class Initialized
INFO - 2024-08-28 12:35:34 --> Config Class Initialized
INFO - 2024-08-28 12:35:34 --> Loader Class Initialized
INFO - 2024-08-28 12:35:34 --> Helper loaded: url_helper
INFO - 2024-08-28 12:35:34 --> Helper loaded: file_helper
INFO - 2024-08-28 12:35:34 --> Helper loaded: form_helper
INFO - 2024-08-28 12:35:34 --> Helper loaded: my_helper
INFO - 2024-08-28 12:35:34 --> Database Driver Class Initialized
ERROR - 2024-08-28 12:35:35 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 2037
ERROR - 2024-08-28 12:35:35 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 2037
INFO - 2024-08-28 12:35:35 --> Session: Class initialized using 'files' driver.
INFO - 2024-08-28 12:35:35 --> Controller Class Initialized
ERROR - 2024-08-28 12:35:35 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1160
ERROR - 2024-08-28 12:35:35 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1692
ERROR - 2024-08-28 12:35:35 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1729
ERROR - 2024-08-28 12:35:35 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1767
ERROR - 2024-08-28 12:35:35 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1806
ERROR - 2024-08-28 12:35:35 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1883
ERROR - 2024-08-28 12:35:35 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1962
ERROR - 2024-08-28 12:35:35 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 2042
ERROR - 2024-08-28 12:35:35 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 2122
ERROR - 2024-08-28 12:35:35 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 2202
ERROR - 2024-08-28 12:35:35 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 2277
ERROR - 2024-08-28 12:35:35 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php 32
ERROR - 2024-08-28 12:35:35 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php 32
DEBUG - 2024-08-28 12:35:35 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php
INFO - 2024-08-28 12:35:37 --> Final output sent to browser
DEBUG - 2024-08-28 12:35:37 --> Total execution time: 3.1812
INFO - 2024-08-28 12:35:37 --> Session: Class initialized using 'files' driver.
INFO - 2024-08-28 12:35:37 --> Controller Class Initialized
INFO - 2024-08-28 12:35:37 --> Config Class Initialized
INFO - 2024-08-28 12:35:37 --> Hooks Class Initialized
DEBUG - 2024-08-28 12:35:37 --> UTF-8 Support Enabled
INFO - 2024-08-28 12:35:37 --> Utf8 Class Initialized
INFO - 2024-08-28 12:35:37 --> URI Class Initialized
INFO - 2024-08-28 12:35:37 --> Router Class Initialized
INFO - 2024-08-28 12:35:37 --> Output Class Initialized
INFO - 2024-08-28 12:35:37 --> Security Class Initialized
DEBUG - 2024-08-28 12:35:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-08-28 12:35:37 --> Input Class Initialized
INFO - 2024-08-28 12:35:37 --> Language Class Initialized
ERROR - 2024-08-28 12:35:37 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1160
ERROR - 2024-08-28 12:35:37 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1692
ERROR - 2024-08-28 12:35:37 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1729
ERROR - 2024-08-28 12:35:37 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1767
ERROR - 2024-08-28 12:35:37 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1806
ERROR - 2024-08-28 12:35:37 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1883
ERROR - 2024-08-28 12:35:37 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1962
ERROR - 2024-08-28 12:35:37 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 2042
ERROR - 2024-08-28 12:35:37 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 2122
ERROR - 2024-08-28 12:35:37 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 2202
ERROR - 2024-08-28 12:35:37 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 2277
ERROR - 2024-08-28 12:35:37 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php 32
ERROR - 2024-08-28 12:35:37 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php 32
DEBUG - 2024-08-28 12:35:37 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php
INFO - 2024-08-28 12:35:38 --> Language Class Initialized
INFO - 2024-08-28 12:35:38 --> Config Class Initialized
INFO - 2024-08-28 12:35:38 --> Loader Class Initialized
INFO - 2024-08-28 12:35:38 --> Helper loaded: url_helper
INFO - 2024-08-28 12:35:38 --> Helper loaded: file_helper
INFO - 2024-08-28 12:35:38 --> Helper loaded: form_helper
INFO - 2024-08-28 12:35:38 --> Helper loaded: my_helper
INFO - 2024-08-28 12:35:38 --> Database Driver Class Initialized
INFO - 2024-08-28 12:35:40 --> Final output sent to browser
DEBUG - 2024-08-28 12:35:40 --> Total execution time: 5.4712
INFO - 2024-08-28 12:35:40 --> Session: Class initialized using 'files' driver.
INFO - 2024-08-28 12:35:40 --> Controller Class Initialized
ERROR - 2024-08-28 12:35:40 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 2591
ERROR - 2024-08-28 12:35:40 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 3156
ERROR - 2024-08-28 12:35:40 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 3194
ERROR - 2024-08-28 12:35:40 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 3232
ERROR - 2024-08-28 12:35:40 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 3271
ERROR - 2024-08-28 12:35:40 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 3388
ERROR - 2024-08-28 12:35:40 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 3507
ERROR - 2024-08-28 12:35:40 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 3626
ERROR - 2024-08-28 12:35:40 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 3745
ERROR - 2024-08-28 12:35:40 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/views/cetak_mh.php 6
ERROR - 2024-08-28 12:35:40 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/views/cetak_mh.php 6
ERROR - 2024-08-28 12:35:40 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/views/cetak_mh.php 40
ERROR - 2024-08-28 12:35:40 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/views/cetak_mh.php 44
ERROR - 2024-08-28 12:35:40 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/views/cetak_mh.php 44
ERROR - 2024-08-28 12:35:40 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/views/cetak_mh.php 65
ERROR - 2024-08-28 12:35:40 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/views/cetak_mh.php 65
DEBUG - 2024-08-28 12:35:40 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/views/cetak_mh.php
INFO - 2024-08-28 14:31:09 --> Config Class Initialized
INFO - 2024-08-28 14:31:09 --> Hooks Class Initialized
DEBUG - 2024-08-28 14:31:09 --> UTF-8 Support Enabled
INFO - 2024-08-28 14:31:09 --> Utf8 Class Initialized
INFO - 2024-08-28 14:31:09 --> URI Class Initialized
INFO - 2024-08-28 14:31:09 --> Router Class Initialized
INFO - 2024-08-28 14:31:09 --> Output Class Initialized
INFO - 2024-08-28 14:31:09 --> Security Class Initialized
DEBUG - 2024-08-28 14:31:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-08-28 14:31:09 --> Input Class Initialized
INFO - 2024-08-28 14:31:09 --> Language Class Initialized
INFO - 2024-08-28 14:31:09 --> Language Class Initialized
INFO - 2024-08-28 14:31:09 --> Config Class Initialized
INFO - 2024-08-28 14:31:09 --> Loader Class Initialized
INFO - 2024-08-28 14:31:09 --> Helper loaded: url_helper
INFO - 2024-08-28 14:31:09 --> Helper loaded: file_helper
INFO - 2024-08-28 14:31:09 --> Helper loaded: form_helper
INFO - 2024-08-28 14:31:09 --> Helper loaded: my_helper
INFO - 2024-08-28 14:31:09 --> Database Driver Class Initialized
INFO - 2024-08-28 14:31:09 --> Session: Class initialized using 'files' driver.
INFO - 2024-08-28 14:31:09 --> Controller Class Initialized
INFO - 2024-08-28 14:31:09 --> Final output sent to browser
DEBUG - 2024-08-28 14:31:09 --> Total execution time: 0.0671
INFO - 2024-08-28 14:31:15 --> Config Class Initialized
INFO - 2024-08-28 14:31:15 --> Hooks Class Initialized
DEBUG - 2024-08-28 14:31:15 --> UTF-8 Support Enabled
INFO - 2024-08-28 14:31:15 --> Utf8 Class Initialized
INFO - 2024-08-28 14:31:15 --> URI Class Initialized
INFO - 2024-08-28 14:31:15 --> Router Class Initialized
INFO - 2024-08-28 14:31:15 --> Output Class Initialized
INFO - 2024-08-28 14:31:15 --> Security Class Initialized
DEBUG - 2024-08-28 14:31:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-08-28 14:31:15 --> Input Class Initialized
INFO - 2024-08-28 14:31:15 --> Language Class Initialized
INFO - 2024-08-28 14:31:15 --> Language Class Initialized
INFO - 2024-08-28 14:31:15 --> Config Class Initialized
INFO - 2024-08-28 14:31:15 --> Loader Class Initialized
INFO - 2024-08-28 14:31:15 --> Helper loaded: url_helper
INFO - 2024-08-28 14:31:15 --> Helper loaded: file_helper
INFO - 2024-08-28 14:31:15 --> Helper loaded: form_helper
INFO - 2024-08-28 14:31:15 --> Helper loaded: my_helper
INFO - 2024-08-28 14:31:15 --> Database Driver Class Initialized
INFO - 2024-08-28 14:31:15 --> Session: Class initialized using 'files' driver.
INFO - 2024-08-28 14:31:15 --> Controller Class Initialized
INFO - 2024-08-28 14:31:15 --> Final output sent to browser
DEBUG - 2024-08-28 14:31:15 --> Total execution time: 0.0559
INFO - 2024-08-28 14:31:23 --> Config Class Initialized
INFO - 2024-08-28 14:31:23 --> Hooks Class Initialized
DEBUG - 2024-08-28 14:31:23 --> UTF-8 Support Enabled
INFO - 2024-08-28 14:31:23 --> Utf8 Class Initialized
INFO - 2024-08-28 14:31:23 --> URI Class Initialized
INFO - 2024-08-28 14:31:23 --> Router Class Initialized
INFO - 2024-08-28 14:31:23 --> Output Class Initialized
INFO - 2024-08-28 14:31:23 --> Security Class Initialized
DEBUG - 2024-08-28 14:31:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-08-28 14:31:23 --> Input Class Initialized
INFO - 2024-08-28 14:31:23 --> Language Class Initialized
INFO - 2024-08-28 14:31:23 --> Language Class Initialized
INFO - 2024-08-28 14:31:23 --> Config Class Initialized
INFO - 2024-08-28 14:31:23 --> Loader Class Initialized
INFO - 2024-08-28 14:31:23 --> Helper loaded: url_helper
INFO - 2024-08-28 14:31:23 --> Helper loaded: file_helper
INFO - 2024-08-28 14:31:23 --> Helper loaded: form_helper
INFO - 2024-08-28 14:31:23 --> Helper loaded: my_helper
INFO - 2024-08-28 14:31:23 --> Database Driver Class Initialized
INFO - 2024-08-28 14:31:23 --> Session: Class initialized using 'files' driver.
INFO - 2024-08-28 14:31:23 --> Controller Class Initialized
INFO - 2024-08-28 14:31:23 --> Final output sent to browser
DEBUG - 2024-08-28 14:31:23 --> Total execution time: 0.0651
