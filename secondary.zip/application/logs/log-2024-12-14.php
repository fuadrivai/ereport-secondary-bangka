<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2024-12-14 08:28:18 --> Config Class Initialized
INFO - 2024-12-14 08:28:18 --> Hooks Class Initialized
DEBUG - 2024-12-14 08:28:18 --> UTF-8 Support Enabled
INFO - 2024-12-14 08:28:18 --> Utf8 Class Initialized
INFO - 2024-12-14 08:28:18 --> URI Class Initialized
INFO - 2024-12-14 08:28:18 --> Router Class Initialized
INFO - 2024-12-14 08:28:18 --> Output Class Initialized
INFO - 2024-12-14 08:28:18 --> Security Class Initialized
DEBUG - 2024-12-14 08:28:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-14 08:28:18 --> Input Class Initialized
INFO - 2024-12-14 08:28:18 --> Language Class Initialized
INFO - 2024-12-14 08:28:18 --> Language Class Initialized
INFO - 2024-12-14 08:28:18 --> Config Class Initialized
INFO - 2024-12-14 08:28:18 --> Loader Class Initialized
INFO - 2024-12-14 08:28:18 --> Helper loaded: url_helper
INFO - 2024-12-14 08:28:18 --> Helper loaded: file_helper
INFO - 2024-12-14 08:28:18 --> Helper loaded: form_helper
INFO - 2024-12-14 08:28:18 --> Helper loaded: my_helper
INFO - 2024-12-14 08:28:18 --> Database Driver Class Initialized
INFO - 2024-12-14 08:28:18 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-14 08:28:18 --> Controller Class Initialized
INFO - 2024-12-14 08:28:18 --> Config Class Initialized
INFO - 2024-12-14 08:28:18 --> Hooks Class Initialized
DEBUG - 2024-12-14 08:28:18 --> UTF-8 Support Enabled
INFO - 2024-12-14 08:28:18 --> Utf8 Class Initialized
INFO - 2024-12-14 08:28:18 --> URI Class Initialized
INFO - 2024-12-14 08:28:18 --> Router Class Initialized
INFO - 2024-12-14 08:28:18 --> Output Class Initialized
INFO - 2024-12-14 08:28:18 --> Security Class Initialized
DEBUG - 2024-12-14 08:28:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-14 08:28:18 --> Input Class Initialized
INFO - 2024-12-14 08:28:18 --> Language Class Initialized
INFO - 2024-12-14 08:28:18 --> Language Class Initialized
INFO - 2024-12-14 08:28:18 --> Config Class Initialized
INFO - 2024-12-14 08:28:18 --> Loader Class Initialized
INFO - 2024-12-14 08:28:18 --> Helper loaded: url_helper
INFO - 2024-12-14 08:28:18 --> Helper loaded: file_helper
INFO - 2024-12-14 08:28:18 --> Helper loaded: form_helper
INFO - 2024-12-14 08:28:18 --> Helper loaded: my_helper
INFO - 2024-12-14 08:28:18 --> Database Driver Class Initialized
INFO - 2024-12-14 08:28:18 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-14 08:28:18 --> Controller Class Initialized
DEBUG - 2024-12-14 08:28:18 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/login/views/login.php
DEBUG - 2024-12-14 08:28:18 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-12-14 08:28:18 --> Final output sent to browser
DEBUG - 2024-12-14 08:28:18 --> Total execution time: 0.0284
INFO - 2024-12-14 08:28:18 --> Config Class Initialized
INFO - 2024-12-14 08:28:18 --> Hooks Class Initialized
DEBUG - 2024-12-14 08:28:18 --> UTF-8 Support Enabled
INFO - 2024-12-14 08:28:18 --> Utf8 Class Initialized
INFO - 2024-12-14 08:28:18 --> URI Class Initialized
INFO - 2024-12-14 08:28:18 --> Router Class Initialized
INFO - 2024-12-14 08:28:18 --> Output Class Initialized
INFO - 2024-12-14 08:28:18 --> Security Class Initialized
DEBUG - 2024-12-14 08:28:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-14 08:28:18 --> Input Class Initialized
INFO - 2024-12-14 08:28:18 --> Language Class Initialized
INFO - 2024-12-14 08:28:18 --> Language Class Initialized
INFO - 2024-12-14 08:28:18 --> Config Class Initialized
INFO - 2024-12-14 08:28:18 --> Loader Class Initialized
INFO - 2024-12-14 08:28:18 --> Helper loaded: url_helper
INFO - 2024-12-14 08:28:18 --> Helper loaded: file_helper
INFO - 2024-12-14 08:28:18 --> Helper loaded: form_helper
INFO - 2024-12-14 08:28:18 --> Helper loaded: my_helper
INFO - 2024-12-14 08:28:18 --> Database Driver Class Initialized
INFO - 2024-12-14 08:28:18 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-14 08:28:18 --> Controller Class Initialized
INFO - 2024-12-14 08:28:18 --> Config Class Initialized
INFO - 2024-12-14 08:28:18 --> Hooks Class Initialized
DEBUG - 2024-12-14 08:28:18 --> UTF-8 Support Enabled
INFO - 2024-12-14 08:28:18 --> Utf8 Class Initialized
INFO - 2024-12-14 08:28:18 --> URI Class Initialized
INFO - 2024-12-14 08:28:18 --> Router Class Initialized
INFO - 2024-12-14 08:28:18 --> Output Class Initialized
INFO - 2024-12-14 08:28:18 --> Security Class Initialized
DEBUG - 2024-12-14 08:28:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-14 08:28:18 --> Input Class Initialized
INFO - 2024-12-14 08:28:18 --> Language Class Initialized
INFO - 2024-12-14 08:28:18 --> Language Class Initialized
INFO - 2024-12-14 08:28:18 --> Config Class Initialized
INFO - 2024-12-14 08:28:18 --> Loader Class Initialized
INFO - 2024-12-14 08:28:18 --> Helper loaded: url_helper
INFO - 2024-12-14 08:28:18 --> Helper loaded: file_helper
INFO - 2024-12-14 08:28:18 --> Helper loaded: form_helper
INFO - 2024-12-14 08:28:18 --> Helper loaded: my_helper
INFO - 2024-12-14 08:28:18 --> Database Driver Class Initialized
INFO - 2024-12-14 08:28:18 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-14 08:28:18 --> Controller Class Initialized
DEBUG - 2024-12-14 08:28:18 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/login/views/login.php
DEBUG - 2024-12-14 08:28:18 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-12-14 08:28:18 --> Final output sent to browser
DEBUG - 2024-12-14 08:28:18 --> Total execution time: 0.0275
INFO - 2024-12-14 08:28:21 --> Config Class Initialized
INFO - 2024-12-14 08:28:21 --> Hooks Class Initialized
DEBUG - 2024-12-14 08:28:21 --> UTF-8 Support Enabled
INFO - 2024-12-14 08:28:21 --> Utf8 Class Initialized
INFO - 2024-12-14 08:28:21 --> URI Class Initialized
INFO - 2024-12-14 08:28:21 --> Router Class Initialized
INFO - 2024-12-14 08:28:21 --> Output Class Initialized
INFO - 2024-12-14 08:28:21 --> Security Class Initialized
DEBUG - 2024-12-14 08:28:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-14 08:28:21 --> Input Class Initialized
INFO - 2024-12-14 08:28:21 --> Language Class Initialized
INFO - 2024-12-14 08:28:21 --> Language Class Initialized
INFO - 2024-12-14 08:28:21 --> Config Class Initialized
INFO - 2024-12-14 08:28:21 --> Loader Class Initialized
INFO - 2024-12-14 08:28:21 --> Helper loaded: url_helper
INFO - 2024-12-14 08:28:21 --> Helper loaded: file_helper
INFO - 2024-12-14 08:28:21 --> Helper loaded: form_helper
INFO - 2024-12-14 08:28:21 --> Helper loaded: my_helper
INFO - 2024-12-14 08:28:21 --> Database Driver Class Initialized
INFO - 2024-12-14 08:28:21 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-14 08:28:21 --> Controller Class Initialized
INFO - 2024-12-14 08:28:21 --> Helper loaded: cookie_helper
INFO - 2024-12-14 08:28:21 --> Final output sent to browser
DEBUG - 2024-12-14 08:28:21 --> Total execution time: 0.0449
INFO - 2024-12-14 08:28:21 --> Config Class Initialized
INFO - 2024-12-14 08:28:21 --> Hooks Class Initialized
DEBUG - 2024-12-14 08:28:21 --> UTF-8 Support Enabled
INFO - 2024-12-14 08:28:21 --> Utf8 Class Initialized
INFO - 2024-12-14 08:28:21 --> URI Class Initialized
INFO - 2024-12-14 08:28:21 --> Router Class Initialized
INFO - 2024-12-14 08:28:21 --> Output Class Initialized
INFO - 2024-12-14 08:28:21 --> Security Class Initialized
DEBUG - 2024-12-14 08:28:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-14 08:28:21 --> Input Class Initialized
INFO - 2024-12-14 08:28:21 --> Language Class Initialized
INFO - 2024-12-14 08:28:21 --> Language Class Initialized
INFO - 2024-12-14 08:28:21 --> Config Class Initialized
INFO - 2024-12-14 08:28:21 --> Loader Class Initialized
INFO - 2024-12-14 08:28:21 --> Helper loaded: url_helper
INFO - 2024-12-14 08:28:21 --> Helper loaded: file_helper
INFO - 2024-12-14 08:28:21 --> Helper loaded: form_helper
INFO - 2024-12-14 08:28:21 --> Helper loaded: my_helper
INFO - 2024-12-14 08:28:21 --> Database Driver Class Initialized
INFO - 2024-12-14 08:28:21 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-14 08:28:21 --> Controller Class Initialized
DEBUG - 2024-12-14 08:28:21 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/home/views/v_home_guru.php
DEBUG - 2024-12-14 08:28:21 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-12-14 08:28:21 --> Final output sent to browser
DEBUG - 2024-12-14 08:28:21 --> Total execution time: 0.0386
INFO - 2024-12-14 08:28:26 --> Config Class Initialized
INFO - 2024-12-14 08:28:26 --> Hooks Class Initialized
DEBUG - 2024-12-14 08:28:26 --> UTF-8 Support Enabled
INFO - 2024-12-14 08:28:26 --> Utf8 Class Initialized
INFO - 2024-12-14 08:28:26 --> URI Class Initialized
INFO - 2024-12-14 08:28:26 --> Router Class Initialized
INFO - 2024-12-14 08:28:26 --> Output Class Initialized
INFO - 2024-12-14 08:28:26 --> Security Class Initialized
DEBUG - 2024-12-14 08:28:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-14 08:28:26 --> Input Class Initialized
INFO - 2024-12-14 08:28:26 --> Language Class Initialized
INFO - 2024-12-14 08:28:26 --> Language Class Initialized
INFO - 2024-12-14 08:28:26 --> Config Class Initialized
INFO - 2024-12-14 08:28:26 --> Loader Class Initialized
INFO - 2024-12-14 08:28:26 --> Helper loaded: url_helper
INFO - 2024-12-14 08:28:26 --> Helper loaded: file_helper
INFO - 2024-12-14 08:28:26 --> Helper loaded: form_helper
INFO - 2024-12-14 08:28:26 --> Helper loaded: my_helper
INFO - 2024-12-14 08:28:26 --> Database Driver Class Initialized
INFO - 2024-12-14 08:28:26 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-14 08:28:26 --> Controller Class Initialized
DEBUG - 2024-12-14 08:28:26 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/view_mapel/views/v_view_mapel.php
DEBUG - 2024-12-14 08:28:26 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-12-14 08:28:26 --> Final output sent to browser
DEBUG - 2024-12-14 08:28:26 --> Total execution time: 0.1262
INFO - 2024-12-14 08:28:34 --> Config Class Initialized
INFO - 2024-12-14 08:28:34 --> Hooks Class Initialized
DEBUG - 2024-12-14 08:28:34 --> UTF-8 Support Enabled
INFO - 2024-12-14 08:28:34 --> Utf8 Class Initialized
INFO - 2024-12-14 08:28:34 --> URI Class Initialized
INFO - 2024-12-14 08:28:34 --> Router Class Initialized
INFO - 2024-12-14 08:28:34 --> Output Class Initialized
INFO - 2024-12-14 08:28:34 --> Security Class Initialized
DEBUG - 2024-12-14 08:28:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-14 08:28:34 --> Input Class Initialized
INFO - 2024-12-14 08:28:34 --> Language Class Initialized
INFO - 2024-12-14 08:28:34 --> Language Class Initialized
INFO - 2024-12-14 08:28:34 --> Config Class Initialized
INFO - 2024-12-14 08:28:34 --> Loader Class Initialized
INFO - 2024-12-14 08:28:34 --> Helper loaded: url_helper
INFO - 2024-12-14 08:28:34 --> Helper loaded: file_helper
INFO - 2024-12-14 08:28:34 --> Helper loaded: form_helper
INFO - 2024-12-14 08:28:34 --> Helper loaded: my_helper
INFO - 2024-12-14 08:28:34 --> Database Driver Class Initialized
INFO - 2024-12-14 08:28:34 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-14 08:28:34 --> Controller Class Initialized
DEBUG - 2024-12-14 08:28:34 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/views/list.php
DEBUG - 2024-12-14 08:28:34 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-12-14 08:28:34 --> Final output sent to browser
DEBUG - 2024-12-14 08:28:34 --> Total execution time: 0.0421
INFO - 2024-12-14 08:28:36 --> Config Class Initialized
INFO - 2024-12-14 08:28:36 --> Hooks Class Initialized
DEBUG - 2024-12-14 08:28:36 --> UTF-8 Support Enabled
INFO - 2024-12-14 08:28:36 --> Utf8 Class Initialized
INFO - 2024-12-14 08:28:36 --> URI Class Initialized
INFO - 2024-12-14 08:28:36 --> Router Class Initialized
INFO - 2024-12-14 08:28:36 --> Output Class Initialized
INFO - 2024-12-14 08:28:36 --> Security Class Initialized
DEBUG - 2024-12-14 08:28:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-14 08:28:37 --> Input Class Initialized
INFO - 2024-12-14 08:28:37 --> Language Class Initialized
INFO - 2024-12-14 08:28:37 --> Language Class Initialized
INFO - 2024-12-14 08:28:37 --> Config Class Initialized
INFO - 2024-12-14 08:28:37 --> Loader Class Initialized
INFO - 2024-12-14 08:28:37 --> Helper loaded: url_helper
INFO - 2024-12-14 08:28:37 --> Helper loaded: file_helper
INFO - 2024-12-14 08:28:37 --> Helper loaded: form_helper
INFO - 2024-12-14 08:28:37 --> Helper loaded: my_helper
INFO - 2024-12-14 08:28:37 --> Database Driver Class Initialized
INFO - 2024-12-14 08:28:37 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-14 08:28:37 --> Controller Class Initialized
DEBUG - 2024-12-14 08:28:37 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/views/cetak_ikm.php
INFO - 2024-12-14 08:28:38 --> Final output sent to browser
DEBUG - 2024-12-14 08:28:38 --> Total execution time: 1.8033
INFO - 2024-12-14 08:30:00 --> Config Class Initialized
INFO - 2024-12-14 08:30:00 --> Hooks Class Initialized
DEBUG - 2024-12-14 08:30:00 --> UTF-8 Support Enabled
INFO - 2024-12-14 08:30:00 --> Utf8 Class Initialized
INFO - 2024-12-14 08:30:00 --> URI Class Initialized
INFO - 2024-12-14 08:30:00 --> Router Class Initialized
INFO - 2024-12-14 08:30:00 --> Output Class Initialized
INFO - 2024-12-14 08:30:00 --> Security Class Initialized
DEBUG - 2024-12-14 08:30:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-14 08:30:00 --> Input Class Initialized
INFO - 2024-12-14 08:30:00 --> Language Class Initialized
INFO - 2024-12-14 08:30:00 --> Language Class Initialized
INFO - 2024-12-14 08:30:00 --> Config Class Initialized
INFO - 2024-12-14 08:30:00 --> Loader Class Initialized
INFO - 2024-12-14 08:30:00 --> Helper loaded: url_helper
INFO - 2024-12-14 08:30:00 --> Helper loaded: file_helper
INFO - 2024-12-14 08:30:00 --> Helper loaded: form_helper
INFO - 2024-12-14 08:30:00 --> Helper loaded: my_helper
INFO - 2024-12-14 08:30:00 --> Database Driver Class Initialized
INFO - 2024-12-14 08:30:00 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-14 08:30:00 --> Controller Class Initialized
DEBUG - 2024-12-14 08:30:00 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/login/views/login.php
DEBUG - 2024-12-14 08:30:00 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-12-14 08:30:00 --> Final output sent to browser
DEBUG - 2024-12-14 08:30:00 --> Total execution time: 0.0313
INFO - 2024-12-14 08:30:41 --> Config Class Initialized
INFO - 2024-12-14 08:30:41 --> Hooks Class Initialized
DEBUG - 2024-12-14 08:30:41 --> UTF-8 Support Enabled
INFO - 2024-12-14 08:30:41 --> Utf8 Class Initialized
INFO - 2024-12-14 08:30:41 --> URI Class Initialized
INFO - 2024-12-14 08:30:41 --> Router Class Initialized
INFO - 2024-12-14 08:30:41 --> Output Class Initialized
INFO - 2024-12-14 08:30:41 --> Security Class Initialized
DEBUG - 2024-12-14 08:30:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-14 08:30:41 --> Input Class Initialized
INFO - 2024-12-14 08:30:41 --> Language Class Initialized
INFO - 2024-12-14 08:30:41 --> Language Class Initialized
INFO - 2024-12-14 08:30:41 --> Config Class Initialized
INFO - 2024-12-14 08:30:41 --> Loader Class Initialized
INFO - 2024-12-14 08:30:41 --> Helper loaded: url_helper
INFO - 2024-12-14 08:30:41 --> Helper loaded: file_helper
INFO - 2024-12-14 08:30:41 --> Helper loaded: form_helper
INFO - 2024-12-14 08:30:41 --> Helper loaded: my_helper
INFO - 2024-12-14 08:30:41 --> Database Driver Class Initialized
INFO - 2024-12-14 08:30:41 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-14 08:30:41 --> Controller Class Initialized
INFO - 2024-12-14 08:30:41 --> Helper loaded: cookie_helper
INFO - 2024-12-14 08:30:41 --> Final output sent to browser
DEBUG - 2024-12-14 08:30:41 --> Total execution time: 0.0299
INFO - 2024-12-14 08:30:41 --> Config Class Initialized
INFO - 2024-12-14 08:30:41 --> Hooks Class Initialized
DEBUG - 2024-12-14 08:30:41 --> UTF-8 Support Enabled
INFO - 2024-12-14 08:30:41 --> Utf8 Class Initialized
INFO - 2024-12-14 08:30:41 --> URI Class Initialized
INFO - 2024-12-14 08:30:41 --> Router Class Initialized
INFO - 2024-12-14 08:30:41 --> Output Class Initialized
INFO - 2024-12-14 08:30:41 --> Security Class Initialized
DEBUG - 2024-12-14 08:30:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-14 08:30:41 --> Input Class Initialized
INFO - 2024-12-14 08:30:41 --> Language Class Initialized
INFO - 2024-12-14 08:30:41 --> Language Class Initialized
INFO - 2024-12-14 08:30:41 --> Config Class Initialized
INFO - 2024-12-14 08:30:41 --> Loader Class Initialized
INFO - 2024-12-14 08:30:41 --> Helper loaded: url_helper
INFO - 2024-12-14 08:30:41 --> Helper loaded: file_helper
INFO - 2024-12-14 08:30:41 --> Helper loaded: form_helper
INFO - 2024-12-14 08:30:41 --> Helper loaded: my_helper
INFO - 2024-12-14 08:30:41 --> Database Driver Class Initialized
INFO - 2024-12-14 08:30:41 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-14 08:30:41 --> Controller Class Initialized
DEBUG - 2024-12-14 08:30:41 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/home/views/v_home_guru.php
DEBUG - 2024-12-14 08:30:41 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-12-14 08:30:41 --> Final output sent to browser
DEBUG - 2024-12-14 08:30:41 --> Total execution time: 0.0356
INFO - 2024-12-14 08:30:44 --> Config Class Initialized
INFO - 2024-12-14 08:30:44 --> Hooks Class Initialized
DEBUG - 2024-12-14 08:30:44 --> UTF-8 Support Enabled
INFO - 2024-12-14 08:30:44 --> Utf8 Class Initialized
INFO - 2024-12-14 08:30:44 --> URI Class Initialized
INFO - 2024-12-14 08:30:44 --> Router Class Initialized
INFO - 2024-12-14 08:30:44 --> Output Class Initialized
INFO - 2024-12-14 08:30:44 --> Security Class Initialized
DEBUG - 2024-12-14 08:30:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-14 08:30:44 --> Input Class Initialized
INFO - 2024-12-14 08:30:44 --> Language Class Initialized
INFO - 2024-12-14 08:30:44 --> Language Class Initialized
INFO - 2024-12-14 08:30:44 --> Config Class Initialized
INFO - 2024-12-14 08:30:44 --> Loader Class Initialized
INFO - 2024-12-14 08:30:44 --> Helper loaded: url_helper
INFO - 2024-12-14 08:30:44 --> Helper loaded: file_helper
INFO - 2024-12-14 08:30:44 --> Helper loaded: form_helper
INFO - 2024-12-14 08:30:44 --> Helper loaded: my_helper
INFO - 2024-12-14 08:30:44 --> Database Driver Class Initialized
INFO - 2024-12-14 08:30:44 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-14 08:30:44 --> Controller Class Initialized
DEBUG - 2024-12-14 08:30:44 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/home/views/v_ubah_password.php
DEBUG - 2024-12-14 08:30:44 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-12-14 08:30:44 --> Final output sent to browser
DEBUG - 2024-12-14 08:30:44 --> Total execution time: 0.0278
INFO - 2024-12-14 08:30:48 --> Config Class Initialized
INFO - 2024-12-14 08:30:48 --> Hooks Class Initialized
DEBUG - 2024-12-14 08:30:48 --> UTF-8 Support Enabled
INFO - 2024-12-14 08:30:48 --> Utf8 Class Initialized
INFO - 2024-12-14 08:30:48 --> URI Class Initialized
INFO - 2024-12-14 08:30:48 --> Router Class Initialized
INFO - 2024-12-14 08:30:48 --> Output Class Initialized
INFO - 2024-12-14 08:30:48 --> Security Class Initialized
DEBUG - 2024-12-14 08:30:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-14 08:30:48 --> Input Class Initialized
INFO - 2024-12-14 08:30:48 --> Language Class Initialized
INFO - 2024-12-14 08:30:48 --> Language Class Initialized
INFO - 2024-12-14 08:30:48 --> Config Class Initialized
INFO - 2024-12-14 08:30:48 --> Loader Class Initialized
INFO - 2024-12-14 08:30:48 --> Helper loaded: url_helper
INFO - 2024-12-14 08:30:48 --> Helper loaded: file_helper
INFO - 2024-12-14 08:30:48 --> Helper loaded: form_helper
INFO - 2024-12-14 08:30:48 --> Helper loaded: my_helper
INFO - 2024-12-14 08:30:48 --> Database Driver Class Initialized
INFO - 2024-12-14 08:30:48 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-14 08:30:48 --> Controller Class Initialized
DEBUG - 2024-12-14 08:30:48 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/views/list.php
DEBUG - 2024-12-14 08:30:48 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-12-14 08:30:48 --> Final output sent to browser
DEBUG - 2024-12-14 08:30:48 --> Total execution time: 0.0385
INFO - 2024-12-14 08:30:52 --> Config Class Initialized
INFO - 2024-12-14 08:30:52 --> Hooks Class Initialized
DEBUG - 2024-12-14 08:30:52 --> UTF-8 Support Enabled
INFO - 2024-12-14 08:30:52 --> Utf8 Class Initialized
INFO - 2024-12-14 08:30:52 --> URI Class Initialized
INFO - 2024-12-14 08:30:52 --> Router Class Initialized
INFO - 2024-12-14 08:30:52 --> Output Class Initialized
INFO - 2024-12-14 08:30:52 --> Security Class Initialized
DEBUG - 2024-12-14 08:30:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-14 08:30:52 --> Input Class Initialized
INFO - 2024-12-14 08:30:52 --> Language Class Initialized
INFO - 2024-12-14 08:30:52 --> Language Class Initialized
INFO - 2024-12-14 08:30:52 --> Config Class Initialized
INFO - 2024-12-14 08:30:52 --> Loader Class Initialized
INFO - 2024-12-14 08:30:52 --> Helper loaded: url_helper
INFO - 2024-12-14 08:30:52 --> Helper loaded: file_helper
INFO - 2024-12-14 08:30:52 --> Helper loaded: form_helper
INFO - 2024-12-14 08:30:52 --> Helper loaded: my_helper
INFO - 2024-12-14 08:30:52 --> Database Driver Class Initialized
INFO - 2024-12-14 08:30:52 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-14 08:30:52 --> Controller Class Initialized
DEBUG - 2024-12-14 08:30:52 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/views/cetak_ikm.php
INFO - 2024-12-14 08:30:53 --> Final output sent to browser
DEBUG - 2024-12-14 08:30:53 --> Total execution time: 1.6708
INFO - 2024-12-14 08:30:55 --> Config Class Initialized
INFO - 2024-12-14 08:30:55 --> Hooks Class Initialized
DEBUG - 2024-12-14 08:30:55 --> UTF-8 Support Enabled
INFO - 2024-12-14 08:30:55 --> Utf8 Class Initialized
INFO - 2024-12-14 08:30:55 --> URI Class Initialized
INFO - 2024-12-14 08:30:55 --> Router Class Initialized
INFO - 2024-12-14 08:30:55 --> Output Class Initialized
INFO - 2024-12-14 08:30:55 --> Security Class Initialized
DEBUG - 2024-12-14 08:30:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-14 08:30:55 --> Input Class Initialized
INFO - 2024-12-14 08:30:55 --> Language Class Initialized
INFO - 2024-12-14 08:30:55 --> Language Class Initialized
INFO - 2024-12-14 08:30:55 --> Config Class Initialized
INFO - 2024-12-14 08:30:55 --> Loader Class Initialized
INFO - 2024-12-14 08:30:55 --> Helper loaded: url_helper
INFO - 2024-12-14 08:30:55 --> Helper loaded: file_helper
INFO - 2024-12-14 08:30:55 --> Helper loaded: form_helper
INFO - 2024-12-14 08:30:55 --> Helper loaded: my_helper
INFO - 2024-12-14 08:30:55 --> Database Driver Class Initialized
INFO - 2024-12-14 08:30:55 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-14 08:30:55 --> Controller Class Initialized
DEBUG - 2024-12-14 08:30:55 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/views/cetak_mh.php
INFO - 2024-12-14 08:30:56 --> Config Class Initialized
INFO - 2024-12-14 08:30:56 --> Hooks Class Initialized
DEBUG - 2024-12-14 08:30:56 --> UTF-8 Support Enabled
INFO - 2024-12-14 08:30:56 --> Utf8 Class Initialized
INFO - 2024-12-14 08:30:56 --> URI Class Initialized
INFO - 2024-12-14 08:30:56 --> Router Class Initialized
INFO - 2024-12-14 08:30:56 --> Output Class Initialized
INFO - 2024-12-14 08:30:56 --> Security Class Initialized
DEBUG - 2024-12-14 08:30:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-14 08:30:56 --> Input Class Initialized
INFO - 2024-12-14 08:30:56 --> Language Class Initialized
INFO - 2024-12-14 08:30:56 --> Language Class Initialized
INFO - 2024-12-14 08:30:56 --> Config Class Initialized
INFO - 2024-12-14 08:30:56 --> Loader Class Initialized
INFO - 2024-12-14 08:30:56 --> Helper loaded: url_helper
INFO - 2024-12-14 08:30:56 --> Helper loaded: file_helper
INFO - 2024-12-14 08:30:56 --> Helper loaded: form_helper
INFO - 2024-12-14 08:30:56 --> Helper loaded: my_helper
INFO - 2024-12-14 08:30:56 --> Database Driver Class Initialized
INFO - 2024-12-14 08:30:56 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-14 08:30:56 --> Controller Class Initialized
INFO - 2024-12-14 08:30:57 --> Config Class Initialized
INFO - 2024-12-14 08:30:57 --> Hooks Class Initialized
DEBUG - 2024-12-14 08:30:57 --> UTF-8 Support Enabled
INFO - 2024-12-14 08:30:57 --> Utf8 Class Initialized
INFO - 2024-12-14 08:30:57 --> URI Class Initialized
INFO - 2024-12-14 08:30:57 --> Router Class Initialized
INFO - 2024-12-14 08:30:57 --> Output Class Initialized
INFO - 2024-12-14 08:30:57 --> Security Class Initialized
DEBUG - 2024-12-14 08:30:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-14 08:30:57 --> Input Class Initialized
INFO - 2024-12-14 08:30:57 --> Language Class Initialized
INFO - 2024-12-14 08:30:57 --> Language Class Initialized
INFO - 2024-12-14 08:30:57 --> Config Class Initialized
INFO - 2024-12-14 08:30:57 --> Loader Class Initialized
INFO - 2024-12-14 08:30:57 --> Helper loaded: url_helper
INFO - 2024-12-14 08:30:57 --> Helper loaded: file_helper
INFO - 2024-12-14 08:30:57 --> Helper loaded: form_helper
INFO - 2024-12-14 08:30:57 --> Helper loaded: my_helper
INFO - 2024-12-14 08:30:57 --> Database Driver Class Initialized
DEBUG - 2024-12-14 08:30:57 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/views/cetak_ikm.php
INFO - 2024-12-14 08:31:00 --> Final output sent to browser
DEBUG - 2024-12-14 08:31:00 --> Total execution time: 3.5212
INFO - 2024-12-14 08:31:00 --> Final output sent to browser
DEBUG - 2024-12-14 08:31:00 --> Total execution time: 5.7871
INFO - 2024-12-14 08:31:00 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-14 08:31:00 --> Controller Class Initialized
DEBUG - 2024-12-14 08:31:00 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/views/cetak_tahfiz.php
INFO - 2024-12-14 08:31:04 --> Final output sent to browser
DEBUG - 2024-12-14 08:31:04 --> Total execution time: 7.5849
INFO - 2024-12-14 08:31:34 --> Config Class Initialized
INFO - 2024-12-14 08:31:34 --> Hooks Class Initialized
DEBUG - 2024-12-14 08:31:34 --> UTF-8 Support Enabled
INFO - 2024-12-14 08:31:34 --> Utf8 Class Initialized
INFO - 2024-12-14 08:31:34 --> URI Class Initialized
INFO - 2024-12-14 08:31:34 --> Router Class Initialized
INFO - 2024-12-14 08:31:34 --> Output Class Initialized
INFO - 2024-12-14 08:31:34 --> Security Class Initialized
DEBUG - 2024-12-14 08:31:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-14 08:31:34 --> Input Class Initialized
INFO - 2024-12-14 08:31:34 --> Language Class Initialized
INFO - 2024-12-14 08:31:34 --> Language Class Initialized
INFO - 2024-12-14 08:31:34 --> Config Class Initialized
INFO - 2024-12-14 08:31:34 --> Loader Class Initialized
INFO - 2024-12-14 08:31:34 --> Helper loaded: url_helper
INFO - 2024-12-14 08:31:34 --> Helper loaded: file_helper
INFO - 2024-12-14 08:31:34 --> Helper loaded: form_helper
INFO - 2024-12-14 08:31:34 --> Helper loaded: my_helper
INFO - 2024-12-14 08:31:34 --> Database Driver Class Initialized
INFO - 2024-12-14 08:31:34 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-14 08:31:34 --> Controller Class Initialized
DEBUG - 2024-12-14 08:31:34 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/views/cetak_ikm.php
INFO - 2024-12-14 08:31:36 --> Final output sent to browser
DEBUG - 2024-12-14 08:31:36 --> Total execution time: 1.9263
INFO - 2024-12-14 08:32:17 --> Config Class Initialized
INFO - 2024-12-14 08:32:17 --> Hooks Class Initialized
DEBUG - 2024-12-14 08:32:17 --> UTF-8 Support Enabled
INFO - 2024-12-14 08:32:17 --> Utf8 Class Initialized
INFO - 2024-12-14 08:32:17 --> URI Class Initialized
INFO - 2024-12-14 08:32:17 --> Router Class Initialized
INFO - 2024-12-14 08:32:17 --> Output Class Initialized
INFO - 2024-12-14 08:32:17 --> Security Class Initialized
DEBUG - 2024-12-14 08:32:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-14 08:32:17 --> Input Class Initialized
INFO - 2024-12-14 08:32:17 --> Language Class Initialized
INFO - 2024-12-14 08:32:17 --> Language Class Initialized
INFO - 2024-12-14 08:32:17 --> Config Class Initialized
INFO - 2024-12-14 08:32:17 --> Loader Class Initialized
INFO - 2024-12-14 08:32:17 --> Helper loaded: url_helper
INFO - 2024-12-14 08:32:17 --> Helper loaded: file_helper
INFO - 2024-12-14 08:32:17 --> Helper loaded: form_helper
INFO - 2024-12-14 08:32:17 --> Helper loaded: my_helper
INFO - 2024-12-14 08:32:17 --> Database Driver Class Initialized
INFO - 2024-12-14 08:32:17 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-14 08:32:17 --> Controller Class Initialized
DEBUG - 2024-12-14 08:32:17 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/views/cetak_ikm.php
INFO - 2024-12-14 08:32:19 --> Final output sent to browser
DEBUG - 2024-12-14 08:32:19 --> Total execution time: 1.9554
INFO - 2024-12-14 08:32:50 --> Config Class Initialized
INFO - 2024-12-14 08:32:50 --> Hooks Class Initialized
DEBUG - 2024-12-14 08:32:50 --> UTF-8 Support Enabled
INFO - 2024-12-14 08:32:50 --> Utf8 Class Initialized
INFO - 2024-12-14 08:32:50 --> URI Class Initialized
INFO - 2024-12-14 08:32:50 --> Router Class Initialized
INFO - 2024-12-14 08:32:50 --> Output Class Initialized
INFO - 2024-12-14 08:32:50 --> Security Class Initialized
DEBUG - 2024-12-14 08:32:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-14 08:32:50 --> Input Class Initialized
INFO - 2024-12-14 08:32:50 --> Language Class Initialized
INFO - 2024-12-14 08:32:50 --> Language Class Initialized
INFO - 2024-12-14 08:32:50 --> Config Class Initialized
INFO - 2024-12-14 08:32:50 --> Loader Class Initialized
INFO - 2024-12-14 08:32:50 --> Helper loaded: url_helper
INFO - 2024-12-14 08:32:50 --> Helper loaded: file_helper
INFO - 2024-12-14 08:32:50 --> Helper loaded: form_helper
INFO - 2024-12-14 08:32:50 --> Helper loaded: my_helper
INFO - 2024-12-14 08:32:50 --> Database Driver Class Initialized
INFO - 2024-12-14 08:32:50 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-14 08:32:50 --> Controller Class Initialized
DEBUG - 2024-12-14 08:32:50 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/views/cetak_ikm.php
INFO - 2024-12-14 08:32:52 --> Final output sent to browser
DEBUG - 2024-12-14 08:32:52 --> Total execution time: 1.6680
INFO - 2024-12-14 08:33:03 --> Config Class Initialized
INFO - 2024-12-14 08:33:03 --> Hooks Class Initialized
DEBUG - 2024-12-14 08:33:03 --> UTF-8 Support Enabled
INFO - 2024-12-14 08:33:03 --> Utf8 Class Initialized
INFO - 2024-12-14 08:33:03 --> URI Class Initialized
INFO - 2024-12-14 08:33:03 --> Router Class Initialized
INFO - 2024-12-14 08:33:03 --> Output Class Initialized
INFO - 2024-12-14 08:33:03 --> Security Class Initialized
DEBUG - 2024-12-14 08:33:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-14 08:33:03 --> Input Class Initialized
INFO - 2024-12-14 08:33:03 --> Language Class Initialized
INFO - 2024-12-14 08:33:03 --> Language Class Initialized
INFO - 2024-12-14 08:33:03 --> Config Class Initialized
INFO - 2024-12-14 08:33:03 --> Loader Class Initialized
INFO - 2024-12-14 08:33:03 --> Helper loaded: url_helper
INFO - 2024-12-14 08:33:03 --> Helper loaded: file_helper
INFO - 2024-12-14 08:33:03 --> Helper loaded: form_helper
INFO - 2024-12-14 08:33:03 --> Helper loaded: my_helper
INFO - 2024-12-14 08:33:03 --> Database Driver Class Initialized
INFO - 2024-12-14 08:33:03 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-14 08:33:03 --> Controller Class Initialized
DEBUG - 2024-12-14 08:33:03 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_ekstra/views/list.php
DEBUG - 2024-12-14 08:33:03 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-12-14 08:33:03 --> Final output sent to browser
DEBUG - 2024-12-14 08:33:03 --> Total execution time: 0.0290
INFO - 2024-12-14 08:33:06 --> Config Class Initialized
INFO - 2024-12-14 08:33:06 --> Hooks Class Initialized
DEBUG - 2024-12-14 08:33:06 --> UTF-8 Support Enabled
INFO - 2024-12-14 08:33:06 --> Utf8 Class Initialized
INFO - 2024-12-14 08:33:06 --> URI Class Initialized
INFO - 2024-12-14 08:33:06 --> Router Class Initialized
INFO - 2024-12-14 08:33:06 --> Output Class Initialized
INFO - 2024-12-14 08:33:06 --> Security Class Initialized
DEBUG - 2024-12-14 08:33:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-14 08:33:06 --> Input Class Initialized
INFO - 2024-12-14 08:33:06 --> Language Class Initialized
INFO - 2024-12-14 08:33:06 --> Language Class Initialized
INFO - 2024-12-14 08:33:06 --> Config Class Initialized
INFO - 2024-12-14 08:33:06 --> Loader Class Initialized
INFO - 2024-12-14 08:33:06 --> Helper loaded: url_helper
INFO - 2024-12-14 08:33:06 --> Helper loaded: file_helper
INFO - 2024-12-14 08:33:06 --> Helper loaded: form_helper
INFO - 2024-12-14 08:33:06 --> Helper loaded: my_helper
INFO - 2024-12-14 08:33:06 --> Database Driver Class Initialized
INFO - 2024-12-14 08:33:06 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-14 08:33:06 --> Controller Class Initialized
INFO - 2024-12-14 08:33:06 --> Final output sent to browser
DEBUG - 2024-12-14 08:33:06 --> Total execution time: 0.0313
INFO - 2024-12-14 08:33:18 --> Config Class Initialized
INFO - 2024-12-14 08:33:18 --> Hooks Class Initialized
DEBUG - 2024-12-14 08:33:18 --> UTF-8 Support Enabled
INFO - 2024-12-14 08:33:18 --> Utf8 Class Initialized
INFO - 2024-12-14 08:33:18 --> URI Class Initialized
INFO - 2024-12-14 08:33:18 --> Router Class Initialized
INFO - 2024-12-14 08:33:18 --> Output Class Initialized
INFO - 2024-12-14 08:33:18 --> Security Class Initialized
DEBUG - 2024-12-14 08:33:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-14 08:33:18 --> Input Class Initialized
INFO - 2024-12-14 08:33:18 --> Language Class Initialized
INFO - 2024-12-14 08:33:18 --> Language Class Initialized
INFO - 2024-12-14 08:33:18 --> Config Class Initialized
INFO - 2024-12-14 08:33:18 --> Loader Class Initialized
INFO - 2024-12-14 08:33:18 --> Helper loaded: url_helper
INFO - 2024-12-14 08:33:18 --> Helper loaded: file_helper
INFO - 2024-12-14 08:33:18 --> Helper loaded: form_helper
INFO - 2024-12-14 08:33:18 --> Helper loaded: my_helper
INFO - 2024-12-14 08:33:18 --> Database Driver Class Initialized
INFO - 2024-12-14 08:33:18 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-14 08:33:18 --> Controller Class Initialized
INFO - 2024-12-14 08:33:18 --> Final output sent to browser
DEBUG - 2024-12-14 08:33:18 --> Total execution time: 0.0799
INFO - 2024-12-14 08:33:25 --> Config Class Initialized
INFO - 2024-12-14 08:33:25 --> Hooks Class Initialized
DEBUG - 2024-12-14 08:33:25 --> UTF-8 Support Enabled
INFO - 2024-12-14 08:33:25 --> Utf8 Class Initialized
INFO - 2024-12-14 08:33:25 --> URI Class Initialized
INFO - 2024-12-14 08:33:25 --> Router Class Initialized
INFO - 2024-12-14 08:33:25 --> Output Class Initialized
INFO - 2024-12-14 08:33:25 --> Security Class Initialized
DEBUG - 2024-12-14 08:33:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-14 08:33:25 --> Input Class Initialized
INFO - 2024-12-14 08:33:25 --> Language Class Initialized
INFO - 2024-12-14 08:33:25 --> Language Class Initialized
INFO - 2024-12-14 08:33:25 --> Config Class Initialized
INFO - 2024-12-14 08:33:25 --> Loader Class Initialized
INFO - 2024-12-14 08:33:25 --> Helper loaded: url_helper
INFO - 2024-12-14 08:33:25 --> Helper loaded: file_helper
INFO - 2024-12-14 08:33:25 --> Helper loaded: form_helper
INFO - 2024-12-14 08:33:25 --> Helper loaded: my_helper
INFO - 2024-12-14 08:33:25 --> Database Driver Class Initialized
INFO - 2024-12-14 08:33:25 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-14 08:33:25 --> Controller Class Initialized
DEBUG - 2024-12-14 08:33:25 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/view_mapel/views/v_view_mapel.php
DEBUG - 2024-12-14 08:33:25 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-12-14 08:33:25 --> Final output sent to browser
DEBUG - 2024-12-14 08:33:25 --> Total execution time: 0.0333
INFO - 2024-12-14 08:33:30 --> Config Class Initialized
INFO - 2024-12-14 08:33:30 --> Hooks Class Initialized
DEBUG - 2024-12-14 08:33:30 --> UTF-8 Support Enabled
INFO - 2024-12-14 08:33:30 --> Utf8 Class Initialized
INFO - 2024-12-14 08:33:30 --> URI Class Initialized
INFO - 2024-12-14 08:33:30 --> Router Class Initialized
INFO - 2024-12-14 08:33:30 --> Output Class Initialized
INFO - 2024-12-14 08:33:30 --> Security Class Initialized
DEBUG - 2024-12-14 08:33:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-14 08:33:30 --> Input Class Initialized
INFO - 2024-12-14 08:33:30 --> Language Class Initialized
INFO - 2024-12-14 08:33:30 --> Language Class Initialized
INFO - 2024-12-14 08:33:30 --> Config Class Initialized
INFO - 2024-12-14 08:33:30 --> Loader Class Initialized
INFO - 2024-12-14 08:33:30 --> Helper loaded: url_helper
INFO - 2024-12-14 08:33:30 --> Helper loaded: file_helper
INFO - 2024-12-14 08:33:30 --> Helper loaded: form_helper
INFO - 2024-12-14 08:33:30 --> Helper loaded: my_helper
INFO - 2024-12-14 08:33:30 --> Database Driver Class Initialized
INFO - 2024-12-14 08:33:30 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-14 08:33:30 --> Controller Class Initialized
DEBUG - 2024-12-14 08:33:30 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/views/list.php
DEBUG - 2024-12-14 08:33:30 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-12-14 08:33:30 --> Final output sent to browser
DEBUG - 2024-12-14 08:33:30 --> Total execution time: 0.0331
INFO - 2024-12-14 08:33:31 --> Config Class Initialized
INFO - 2024-12-14 08:33:31 --> Hooks Class Initialized
DEBUG - 2024-12-14 08:33:31 --> UTF-8 Support Enabled
INFO - 2024-12-14 08:33:31 --> Utf8 Class Initialized
INFO - 2024-12-14 08:33:31 --> URI Class Initialized
INFO - 2024-12-14 08:33:31 --> Router Class Initialized
INFO - 2024-12-14 08:33:31 --> Output Class Initialized
INFO - 2024-12-14 08:33:31 --> Security Class Initialized
DEBUG - 2024-12-14 08:33:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-14 08:33:31 --> Input Class Initialized
INFO - 2024-12-14 08:33:31 --> Language Class Initialized
INFO - 2024-12-14 08:33:31 --> Language Class Initialized
INFO - 2024-12-14 08:33:31 --> Config Class Initialized
INFO - 2024-12-14 08:33:31 --> Loader Class Initialized
INFO - 2024-12-14 08:33:31 --> Helper loaded: url_helper
INFO - 2024-12-14 08:33:31 --> Helper loaded: file_helper
INFO - 2024-12-14 08:33:31 --> Helper loaded: form_helper
INFO - 2024-12-14 08:33:31 --> Helper loaded: my_helper
INFO - 2024-12-14 08:33:31 --> Database Driver Class Initialized
INFO - 2024-12-14 08:33:31 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-14 08:33:31 --> Controller Class Initialized
DEBUG - 2024-12-14 08:33:31 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/views/cetak_ikm.php
INFO - 2024-12-14 08:33:33 --> Final output sent to browser
DEBUG - 2024-12-14 08:33:33 --> Total execution time: 1.5353
INFO - 2024-12-14 08:33:34 --> Config Class Initialized
INFO - 2024-12-14 08:33:34 --> Hooks Class Initialized
DEBUG - 2024-12-14 08:33:34 --> UTF-8 Support Enabled
INFO - 2024-12-14 08:33:34 --> Utf8 Class Initialized
INFO - 2024-12-14 08:33:34 --> URI Class Initialized
INFO - 2024-12-14 08:33:34 --> Router Class Initialized
INFO - 2024-12-14 08:33:34 --> Output Class Initialized
INFO - 2024-12-14 08:33:34 --> Security Class Initialized
DEBUG - 2024-12-14 08:33:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-14 08:33:34 --> Input Class Initialized
INFO - 2024-12-14 08:33:34 --> Language Class Initialized
INFO - 2024-12-14 08:33:34 --> Language Class Initialized
INFO - 2024-12-14 08:33:34 --> Config Class Initialized
INFO - 2024-12-14 08:33:34 --> Loader Class Initialized
INFO - 2024-12-14 08:33:34 --> Helper loaded: url_helper
INFO - 2024-12-14 08:33:34 --> Helper loaded: file_helper
INFO - 2024-12-14 08:33:34 --> Helper loaded: form_helper
INFO - 2024-12-14 08:33:34 --> Helper loaded: my_helper
INFO - 2024-12-14 08:33:34 --> Database Driver Class Initialized
INFO - 2024-12-14 08:33:34 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-14 08:33:34 --> Controller Class Initialized
DEBUG - 2024-12-14 08:33:34 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/views/cetak_mh.php
INFO - 2024-12-14 08:33:38 --> Config Class Initialized
INFO - 2024-12-14 08:33:38 --> Hooks Class Initialized
DEBUG - 2024-12-14 08:33:38 --> UTF-8 Support Enabled
INFO - 2024-12-14 08:33:38 --> Utf8 Class Initialized
INFO - 2024-12-14 08:33:38 --> URI Class Initialized
INFO - 2024-12-14 08:33:38 --> Router Class Initialized
INFO - 2024-12-14 08:33:38 --> Output Class Initialized
INFO - 2024-12-14 08:33:38 --> Security Class Initialized
DEBUG - 2024-12-14 08:33:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-14 08:33:38 --> Input Class Initialized
INFO - 2024-12-14 08:33:38 --> Language Class Initialized
INFO - 2024-12-14 08:33:38 --> Language Class Initialized
INFO - 2024-12-14 08:33:38 --> Config Class Initialized
INFO - 2024-12-14 08:33:38 --> Loader Class Initialized
INFO - 2024-12-14 08:33:38 --> Helper loaded: url_helper
INFO - 2024-12-14 08:33:38 --> Helper loaded: file_helper
INFO - 2024-12-14 08:33:38 --> Helper loaded: form_helper
INFO - 2024-12-14 08:33:38 --> Helper loaded: my_helper
INFO - 2024-12-14 08:33:38 --> Database Driver Class Initialized
INFO - 2024-12-14 08:33:38 --> Final output sent to browser
DEBUG - 2024-12-14 08:33:38 --> Total execution time: 4.2203
INFO - 2024-12-14 08:33:38 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-14 08:33:38 --> Controller Class Initialized
DEBUG - 2024-12-14 08:33:38 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/views/cetak_ikm.php
INFO - 2024-12-14 08:33:40 --> Final output sent to browser
DEBUG - 2024-12-14 08:33:40 --> Total execution time: 1.8523
INFO - 2024-12-14 08:34:03 --> Config Class Initialized
INFO - 2024-12-14 08:34:03 --> Hooks Class Initialized
DEBUG - 2024-12-14 08:34:03 --> UTF-8 Support Enabled
INFO - 2024-12-14 08:34:03 --> Utf8 Class Initialized
INFO - 2024-12-14 08:34:03 --> URI Class Initialized
INFO - 2024-12-14 08:34:03 --> Router Class Initialized
INFO - 2024-12-14 08:34:03 --> Output Class Initialized
INFO - 2024-12-14 08:34:03 --> Security Class Initialized
DEBUG - 2024-12-14 08:34:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-14 08:34:03 --> Input Class Initialized
INFO - 2024-12-14 08:34:03 --> Language Class Initialized
INFO - 2024-12-14 08:34:04 --> Language Class Initialized
INFO - 2024-12-14 08:34:04 --> Config Class Initialized
INFO - 2024-12-14 08:34:04 --> Loader Class Initialized
INFO - 2024-12-14 08:34:04 --> Helper loaded: url_helper
INFO - 2024-12-14 08:34:04 --> Helper loaded: file_helper
INFO - 2024-12-14 08:34:04 --> Helper loaded: form_helper
INFO - 2024-12-14 08:34:04 --> Helper loaded: my_helper
INFO - 2024-12-14 08:34:04 --> Database Driver Class Initialized
INFO - 2024-12-14 08:34:04 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-14 08:34:04 --> Controller Class Initialized
DEBUG - 2024-12-14 08:34:04 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/views/cetak_ikm.php
INFO - 2024-12-14 08:34:05 --> Final output sent to browser
DEBUG - 2024-12-14 08:34:05 --> Total execution time: 1.8288
INFO - 2024-12-14 08:34:42 --> Config Class Initialized
INFO - 2024-12-14 08:34:42 --> Hooks Class Initialized
DEBUG - 2024-12-14 08:34:42 --> UTF-8 Support Enabled
INFO - 2024-12-14 08:34:42 --> Utf8 Class Initialized
INFO - 2024-12-14 08:34:42 --> URI Class Initialized
INFO - 2024-12-14 08:34:42 --> Router Class Initialized
INFO - 2024-12-14 08:34:42 --> Output Class Initialized
INFO - 2024-12-14 08:34:42 --> Security Class Initialized
DEBUG - 2024-12-14 08:34:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-14 08:34:42 --> Input Class Initialized
INFO - 2024-12-14 08:34:42 --> Language Class Initialized
INFO - 2024-12-14 08:34:42 --> Language Class Initialized
INFO - 2024-12-14 08:34:42 --> Config Class Initialized
INFO - 2024-12-14 08:34:42 --> Loader Class Initialized
INFO - 2024-12-14 08:34:42 --> Helper loaded: url_helper
INFO - 2024-12-14 08:34:42 --> Helper loaded: file_helper
INFO - 2024-12-14 08:34:42 --> Helper loaded: form_helper
INFO - 2024-12-14 08:34:42 --> Helper loaded: my_helper
INFO - 2024-12-14 08:34:42 --> Database Driver Class Initialized
INFO - 2024-12-14 08:34:42 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-14 08:34:42 --> Controller Class Initialized
DEBUG - 2024-12-14 08:34:42 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/views/cetak_ikm.php
INFO - 2024-12-14 08:34:44 --> Final output sent to browser
DEBUG - 2024-12-14 08:34:44 --> Total execution time: 1.6377
INFO - 2024-12-14 08:35:14 --> Config Class Initialized
INFO - 2024-12-14 08:35:14 --> Hooks Class Initialized
DEBUG - 2024-12-14 08:35:14 --> UTF-8 Support Enabled
INFO - 2024-12-14 08:35:14 --> Utf8 Class Initialized
INFO - 2024-12-14 08:35:14 --> URI Class Initialized
INFO - 2024-12-14 08:35:14 --> Router Class Initialized
INFO - 2024-12-14 08:35:14 --> Output Class Initialized
INFO - 2024-12-14 08:35:14 --> Security Class Initialized
DEBUG - 2024-12-14 08:35:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-14 08:35:14 --> Input Class Initialized
INFO - 2024-12-14 08:35:14 --> Language Class Initialized
INFO - 2024-12-14 08:35:14 --> Language Class Initialized
INFO - 2024-12-14 08:35:14 --> Config Class Initialized
INFO - 2024-12-14 08:35:14 --> Loader Class Initialized
INFO - 2024-12-14 08:35:14 --> Helper loaded: url_helper
INFO - 2024-12-14 08:35:14 --> Helper loaded: file_helper
INFO - 2024-12-14 08:35:14 --> Helper loaded: form_helper
INFO - 2024-12-14 08:35:14 --> Helper loaded: my_helper
INFO - 2024-12-14 08:35:14 --> Database Driver Class Initialized
INFO - 2024-12-14 08:35:14 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-14 08:35:14 --> Controller Class Initialized
DEBUG - 2024-12-14 08:35:14 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/views/cetak_ikm.php
INFO - 2024-12-14 08:35:16 --> Final output sent to browser
DEBUG - 2024-12-14 08:35:16 --> Total execution time: 1.8680
INFO - 2024-12-14 08:35:51 --> Config Class Initialized
INFO - 2024-12-14 08:35:51 --> Hooks Class Initialized
DEBUG - 2024-12-14 08:35:51 --> UTF-8 Support Enabled
INFO - 2024-12-14 08:35:51 --> Utf8 Class Initialized
INFO - 2024-12-14 08:35:51 --> URI Class Initialized
INFO - 2024-12-14 08:35:51 --> Router Class Initialized
INFO - 2024-12-14 08:35:51 --> Output Class Initialized
INFO - 2024-12-14 08:35:51 --> Security Class Initialized
DEBUG - 2024-12-14 08:35:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-14 08:35:51 --> Input Class Initialized
INFO - 2024-12-14 08:35:51 --> Language Class Initialized
INFO - 2024-12-14 08:35:51 --> Language Class Initialized
INFO - 2024-12-14 08:35:51 --> Config Class Initialized
INFO - 2024-12-14 08:35:51 --> Loader Class Initialized
INFO - 2024-12-14 08:35:51 --> Helper loaded: url_helper
INFO - 2024-12-14 08:35:51 --> Helper loaded: file_helper
INFO - 2024-12-14 08:35:51 --> Helper loaded: form_helper
INFO - 2024-12-14 08:35:51 --> Helper loaded: my_helper
INFO - 2024-12-14 08:35:51 --> Database Driver Class Initialized
INFO - 2024-12-14 08:35:51 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-14 08:35:51 --> Controller Class Initialized
DEBUG - 2024-12-14 08:35:51 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/views/cetak_ikm.php
INFO - 2024-12-14 08:35:53 --> Final output sent to browser
DEBUG - 2024-12-14 08:35:53 --> Total execution time: 1.8627
INFO - 2024-12-14 08:36:23 --> Config Class Initialized
INFO - 2024-12-14 08:36:23 --> Hooks Class Initialized
DEBUG - 2024-12-14 08:36:23 --> UTF-8 Support Enabled
INFO - 2024-12-14 08:36:23 --> Utf8 Class Initialized
INFO - 2024-12-14 08:36:23 --> URI Class Initialized
INFO - 2024-12-14 08:36:23 --> Router Class Initialized
INFO - 2024-12-14 08:36:23 --> Output Class Initialized
INFO - 2024-12-14 08:36:23 --> Security Class Initialized
DEBUG - 2024-12-14 08:36:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-14 08:36:23 --> Input Class Initialized
INFO - 2024-12-14 08:36:23 --> Language Class Initialized
INFO - 2024-12-14 08:36:23 --> Language Class Initialized
INFO - 2024-12-14 08:36:23 --> Config Class Initialized
INFO - 2024-12-14 08:36:23 --> Loader Class Initialized
INFO - 2024-12-14 08:36:23 --> Helper loaded: url_helper
INFO - 2024-12-14 08:36:23 --> Helper loaded: file_helper
INFO - 2024-12-14 08:36:23 --> Helper loaded: form_helper
INFO - 2024-12-14 08:36:23 --> Helper loaded: my_helper
INFO - 2024-12-14 08:36:23 --> Database Driver Class Initialized
INFO - 2024-12-14 08:36:23 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-14 08:36:23 --> Controller Class Initialized
DEBUG - 2024-12-14 08:36:23 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/views/cetak_ikm.php
INFO - 2024-12-14 08:36:25 --> Final output sent to browser
DEBUG - 2024-12-14 08:36:25 --> Total execution time: 1.7629
INFO - 2024-12-14 08:36:55 --> Config Class Initialized
INFO - 2024-12-14 08:36:55 --> Hooks Class Initialized
DEBUG - 2024-12-14 08:36:55 --> UTF-8 Support Enabled
INFO - 2024-12-14 08:36:55 --> Utf8 Class Initialized
INFO - 2024-12-14 08:36:55 --> URI Class Initialized
INFO - 2024-12-14 08:36:55 --> Router Class Initialized
INFO - 2024-12-14 08:36:55 --> Output Class Initialized
INFO - 2024-12-14 08:36:55 --> Security Class Initialized
DEBUG - 2024-12-14 08:36:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-14 08:36:55 --> Input Class Initialized
INFO - 2024-12-14 08:36:55 --> Language Class Initialized
INFO - 2024-12-14 08:36:55 --> Language Class Initialized
INFO - 2024-12-14 08:36:55 --> Config Class Initialized
INFO - 2024-12-14 08:36:55 --> Loader Class Initialized
INFO - 2024-12-14 08:36:55 --> Helper loaded: url_helper
INFO - 2024-12-14 08:36:55 --> Helper loaded: file_helper
INFO - 2024-12-14 08:36:55 --> Helper loaded: form_helper
INFO - 2024-12-14 08:36:55 --> Helper loaded: my_helper
INFO - 2024-12-14 08:36:55 --> Database Driver Class Initialized
INFO - 2024-12-14 08:36:55 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-14 08:36:55 --> Controller Class Initialized
DEBUG - 2024-12-14 08:36:55 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/views/cetak_ikm.php
INFO - 2024-12-14 08:36:57 --> Final output sent to browser
DEBUG - 2024-12-14 08:36:57 --> Total execution time: 2.0384
INFO - 2024-12-14 08:37:29 --> Config Class Initialized
INFO - 2024-12-14 08:37:29 --> Hooks Class Initialized
DEBUG - 2024-12-14 08:37:29 --> UTF-8 Support Enabled
INFO - 2024-12-14 08:37:29 --> Utf8 Class Initialized
INFO - 2024-12-14 08:37:29 --> URI Class Initialized
INFO - 2024-12-14 08:37:29 --> Router Class Initialized
INFO - 2024-12-14 08:37:29 --> Output Class Initialized
INFO - 2024-12-14 08:37:30 --> Security Class Initialized
DEBUG - 2024-12-14 08:37:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-14 08:37:30 --> Input Class Initialized
INFO - 2024-12-14 08:37:30 --> Language Class Initialized
INFO - 2024-12-14 08:37:30 --> Language Class Initialized
INFO - 2024-12-14 08:37:30 --> Config Class Initialized
INFO - 2024-12-14 08:37:30 --> Loader Class Initialized
INFO - 2024-12-14 08:37:30 --> Helper loaded: url_helper
INFO - 2024-12-14 08:37:30 --> Helper loaded: file_helper
INFO - 2024-12-14 08:37:30 --> Helper loaded: form_helper
INFO - 2024-12-14 08:37:30 --> Helper loaded: my_helper
INFO - 2024-12-14 08:37:30 --> Database Driver Class Initialized
INFO - 2024-12-14 08:37:30 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-14 08:37:30 --> Controller Class Initialized
DEBUG - 2024-12-14 08:37:30 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/views/cetak_ikm.php
INFO - 2024-12-14 08:37:31 --> Final output sent to browser
DEBUG - 2024-12-14 08:37:31 --> Total execution time: 1.8323
INFO - 2024-12-14 08:38:04 --> Config Class Initialized
INFO - 2024-12-14 08:38:04 --> Hooks Class Initialized
DEBUG - 2024-12-14 08:38:04 --> UTF-8 Support Enabled
INFO - 2024-12-14 08:38:04 --> Utf8 Class Initialized
INFO - 2024-12-14 08:38:04 --> URI Class Initialized
INFO - 2024-12-14 08:38:04 --> Router Class Initialized
INFO - 2024-12-14 08:38:04 --> Output Class Initialized
INFO - 2024-12-14 08:38:04 --> Security Class Initialized
DEBUG - 2024-12-14 08:38:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-14 08:38:04 --> Input Class Initialized
INFO - 2024-12-14 08:38:04 --> Language Class Initialized
INFO - 2024-12-14 08:38:04 --> Language Class Initialized
INFO - 2024-12-14 08:38:04 --> Config Class Initialized
INFO - 2024-12-14 08:38:04 --> Loader Class Initialized
INFO - 2024-12-14 08:38:04 --> Helper loaded: url_helper
INFO - 2024-12-14 08:38:04 --> Helper loaded: file_helper
INFO - 2024-12-14 08:38:04 --> Helper loaded: form_helper
INFO - 2024-12-14 08:38:04 --> Helper loaded: my_helper
INFO - 2024-12-14 08:38:04 --> Database Driver Class Initialized
INFO - 2024-12-14 08:38:04 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-14 08:38:04 --> Controller Class Initialized
DEBUG - 2024-12-14 08:38:04 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/views/cetak_ikm.php
INFO - 2024-12-14 08:38:06 --> Final output sent to browser
DEBUG - 2024-12-14 08:38:06 --> Total execution time: 1.8721
INFO - 2024-12-14 08:38:46 --> Config Class Initialized
INFO - 2024-12-14 08:38:46 --> Hooks Class Initialized
DEBUG - 2024-12-14 08:38:46 --> UTF-8 Support Enabled
INFO - 2024-12-14 08:38:46 --> Utf8 Class Initialized
INFO - 2024-12-14 08:38:46 --> URI Class Initialized
INFO - 2024-12-14 08:38:46 --> Router Class Initialized
INFO - 2024-12-14 08:38:46 --> Output Class Initialized
INFO - 2024-12-14 08:38:46 --> Security Class Initialized
DEBUG - 2024-12-14 08:38:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-14 08:38:46 --> Input Class Initialized
INFO - 2024-12-14 08:38:46 --> Language Class Initialized
INFO - 2024-12-14 08:38:46 --> Language Class Initialized
INFO - 2024-12-14 08:38:46 --> Config Class Initialized
INFO - 2024-12-14 08:38:46 --> Loader Class Initialized
INFO - 2024-12-14 08:38:46 --> Helper loaded: url_helper
INFO - 2024-12-14 08:38:46 --> Helper loaded: file_helper
INFO - 2024-12-14 08:38:46 --> Helper loaded: form_helper
INFO - 2024-12-14 08:38:46 --> Helper loaded: my_helper
INFO - 2024-12-14 08:38:46 --> Database Driver Class Initialized
INFO - 2024-12-14 08:38:46 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-14 08:38:46 --> Controller Class Initialized
DEBUG - 2024-12-14 08:38:46 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/views/cetak_ikm.php
INFO - 2024-12-14 08:38:48 --> Final output sent to browser
DEBUG - 2024-12-14 08:38:48 --> Total execution time: 1.7262
INFO - 2024-12-14 08:39:08 --> Config Class Initialized
INFO - 2024-12-14 08:39:08 --> Hooks Class Initialized
DEBUG - 2024-12-14 08:39:08 --> UTF-8 Support Enabled
INFO - 2024-12-14 08:39:08 --> Utf8 Class Initialized
INFO - 2024-12-14 08:39:08 --> URI Class Initialized
INFO - 2024-12-14 08:39:08 --> Router Class Initialized
INFO - 2024-12-14 08:39:08 --> Output Class Initialized
INFO - 2024-12-14 08:39:08 --> Security Class Initialized
DEBUG - 2024-12-14 08:39:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-14 08:39:08 --> Input Class Initialized
INFO - 2024-12-14 08:39:08 --> Language Class Initialized
INFO - 2024-12-14 08:39:08 --> Language Class Initialized
INFO - 2024-12-14 08:39:08 --> Config Class Initialized
INFO - 2024-12-14 08:39:08 --> Loader Class Initialized
INFO - 2024-12-14 08:39:08 --> Helper loaded: url_helper
INFO - 2024-12-14 08:39:08 --> Helper loaded: file_helper
INFO - 2024-12-14 08:39:08 --> Helper loaded: form_helper
INFO - 2024-12-14 08:39:08 --> Helper loaded: my_helper
INFO - 2024-12-14 08:39:08 --> Database Driver Class Initialized
INFO - 2024-12-14 08:39:08 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-14 08:39:08 --> Controller Class Initialized
DEBUG - 2024-12-14 08:39:08 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/views/cetak_ikm.php
INFO - 2024-12-14 08:39:12 --> Final output sent to browser
DEBUG - 2024-12-14 08:39:12 --> Total execution time: 3.8875
INFO - 2024-12-14 08:39:32 --> Config Class Initialized
INFO - 2024-12-14 08:39:32 --> Hooks Class Initialized
DEBUG - 2024-12-14 08:39:32 --> UTF-8 Support Enabled
INFO - 2024-12-14 08:39:32 --> Utf8 Class Initialized
INFO - 2024-12-14 08:39:32 --> URI Class Initialized
INFO - 2024-12-14 08:39:32 --> Router Class Initialized
INFO - 2024-12-14 08:39:32 --> Output Class Initialized
INFO - 2024-12-14 08:39:32 --> Security Class Initialized
DEBUG - 2024-12-14 08:39:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-14 08:39:32 --> Input Class Initialized
INFO - 2024-12-14 08:39:32 --> Language Class Initialized
INFO - 2024-12-14 08:39:32 --> Language Class Initialized
INFO - 2024-12-14 08:39:32 --> Config Class Initialized
INFO - 2024-12-14 08:39:32 --> Loader Class Initialized
INFO - 2024-12-14 08:39:32 --> Helper loaded: url_helper
INFO - 2024-12-14 08:39:32 --> Helper loaded: file_helper
INFO - 2024-12-14 08:39:32 --> Helper loaded: form_helper
INFO - 2024-12-14 08:39:32 --> Helper loaded: my_helper
INFO - 2024-12-14 08:39:32 --> Database Driver Class Initialized
INFO - 2024-12-14 08:39:32 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-14 08:39:32 --> Controller Class Initialized
DEBUG - 2024-12-14 08:39:32 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/views/cetak_ikm.php
INFO - 2024-12-14 08:39:34 --> Final output sent to browser
DEBUG - 2024-12-14 08:39:34 --> Total execution time: 1.5186
INFO - 2024-12-14 08:39:58 --> Config Class Initialized
INFO - 2024-12-14 08:39:58 --> Hooks Class Initialized
DEBUG - 2024-12-14 08:39:58 --> UTF-8 Support Enabled
INFO - 2024-12-14 08:39:58 --> Utf8 Class Initialized
INFO - 2024-12-14 08:39:58 --> URI Class Initialized
INFO - 2024-12-14 08:39:58 --> Router Class Initialized
INFO - 2024-12-14 08:39:58 --> Output Class Initialized
INFO - 2024-12-14 08:39:58 --> Security Class Initialized
DEBUG - 2024-12-14 08:39:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-14 08:39:58 --> Input Class Initialized
INFO - 2024-12-14 08:39:58 --> Language Class Initialized
INFO - 2024-12-14 08:39:58 --> Language Class Initialized
INFO - 2024-12-14 08:39:58 --> Config Class Initialized
INFO - 2024-12-14 08:39:58 --> Loader Class Initialized
INFO - 2024-12-14 08:39:58 --> Helper loaded: url_helper
INFO - 2024-12-14 08:39:58 --> Helper loaded: file_helper
INFO - 2024-12-14 08:39:58 --> Helper loaded: form_helper
INFO - 2024-12-14 08:39:58 --> Helper loaded: my_helper
INFO - 2024-12-14 08:39:58 --> Database Driver Class Initialized
INFO - 2024-12-14 08:39:58 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-14 08:39:58 --> Controller Class Initialized
DEBUG - 2024-12-14 08:39:59 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/views/cetak_ikm.php
INFO - 2024-12-14 08:40:03 --> Final output sent to browser
DEBUG - 2024-12-14 08:40:03 --> Total execution time: 4.6443
INFO - 2024-12-14 08:40:31 --> Config Class Initialized
INFO - 2024-12-14 08:40:31 --> Hooks Class Initialized
DEBUG - 2024-12-14 08:40:31 --> UTF-8 Support Enabled
INFO - 2024-12-14 08:40:31 --> Utf8 Class Initialized
INFO - 2024-12-14 08:40:31 --> URI Class Initialized
INFO - 2024-12-14 08:40:31 --> Router Class Initialized
INFO - 2024-12-14 08:40:31 --> Output Class Initialized
INFO - 2024-12-14 08:40:31 --> Security Class Initialized
DEBUG - 2024-12-14 08:40:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-14 08:40:31 --> Input Class Initialized
INFO - 2024-12-14 08:40:31 --> Language Class Initialized
INFO - 2024-12-14 08:40:31 --> Language Class Initialized
INFO - 2024-12-14 08:40:31 --> Config Class Initialized
INFO - 2024-12-14 08:40:31 --> Loader Class Initialized
INFO - 2024-12-14 08:40:31 --> Helper loaded: url_helper
INFO - 2024-12-14 08:40:31 --> Helper loaded: file_helper
INFO - 2024-12-14 08:40:31 --> Helper loaded: form_helper
INFO - 2024-12-14 08:40:31 --> Helper loaded: my_helper
INFO - 2024-12-14 08:40:31 --> Database Driver Class Initialized
INFO - 2024-12-14 08:40:31 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-14 08:40:31 --> Controller Class Initialized
DEBUG - 2024-12-14 08:40:31 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/views/cetak_ikm.php
INFO - 2024-12-14 08:40:34 --> Final output sent to browser
DEBUG - 2024-12-14 08:40:34 --> Total execution time: 3.2793
INFO - 2024-12-14 08:41:07 --> Config Class Initialized
INFO - 2024-12-14 08:41:07 --> Hooks Class Initialized
DEBUG - 2024-12-14 08:41:07 --> UTF-8 Support Enabled
INFO - 2024-12-14 08:41:07 --> Utf8 Class Initialized
INFO - 2024-12-14 08:41:07 --> URI Class Initialized
INFO - 2024-12-14 08:41:07 --> Router Class Initialized
INFO - 2024-12-14 08:41:07 --> Output Class Initialized
INFO - 2024-12-14 08:41:07 --> Security Class Initialized
DEBUG - 2024-12-14 08:41:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-14 08:41:07 --> Input Class Initialized
INFO - 2024-12-14 08:41:07 --> Language Class Initialized
INFO - 2024-12-14 08:41:07 --> Language Class Initialized
INFO - 2024-12-14 08:41:07 --> Config Class Initialized
INFO - 2024-12-14 08:41:07 --> Loader Class Initialized
INFO - 2024-12-14 08:41:07 --> Helper loaded: url_helper
INFO - 2024-12-14 08:41:07 --> Helper loaded: file_helper
INFO - 2024-12-14 08:41:07 --> Helper loaded: form_helper
INFO - 2024-12-14 08:41:07 --> Helper loaded: my_helper
INFO - 2024-12-14 08:41:07 --> Database Driver Class Initialized
INFO - 2024-12-14 08:41:07 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-14 08:41:07 --> Controller Class Initialized
DEBUG - 2024-12-14 08:41:07 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/views/cetak_ikm.php
INFO - 2024-12-14 08:41:09 --> Final output sent to browser
DEBUG - 2024-12-14 08:41:09 --> Total execution time: 1.4981
INFO - 2024-12-14 08:41:31 --> Config Class Initialized
INFO - 2024-12-14 08:41:31 --> Hooks Class Initialized
DEBUG - 2024-12-14 08:41:31 --> UTF-8 Support Enabled
INFO - 2024-12-14 08:41:31 --> Utf8 Class Initialized
INFO - 2024-12-14 08:41:31 --> URI Class Initialized
INFO - 2024-12-14 08:41:31 --> Router Class Initialized
INFO - 2024-12-14 08:41:31 --> Output Class Initialized
INFO - 2024-12-14 08:41:31 --> Security Class Initialized
DEBUG - 2024-12-14 08:41:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-14 08:41:31 --> Input Class Initialized
INFO - 2024-12-14 08:41:31 --> Language Class Initialized
INFO - 2024-12-14 08:41:31 --> Language Class Initialized
INFO - 2024-12-14 08:41:31 --> Config Class Initialized
INFO - 2024-12-14 08:41:31 --> Loader Class Initialized
INFO - 2024-12-14 08:41:31 --> Helper loaded: url_helper
INFO - 2024-12-14 08:41:31 --> Helper loaded: file_helper
INFO - 2024-12-14 08:41:31 --> Helper loaded: form_helper
INFO - 2024-12-14 08:41:31 --> Helper loaded: my_helper
INFO - 2024-12-14 08:41:31 --> Database Driver Class Initialized
INFO - 2024-12-14 08:41:31 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-14 08:41:31 --> Controller Class Initialized
DEBUG - 2024-12-14 08:41:31 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/views/cetak_ikm.php
INFO - 2024-12-14 08:41:33 --> Final output sent to browser
DEBUG - 2024-12-14 08:41:33 --> Total execution time: 1.7823
INFO - 2024-12-14 08:41:47 --> Config Class Initialized
INFO - 2024-12-14 08:41:47 --> Hooks Class Initialized
DEBUG - 2024-12-14 08:41:47 --> UTF-8 Support Enabled
INFO - 2024-12-14 08:41:47 --> Utf8 Class Initialized
INFO - 2024-12-14 08:41:47 --> URI Class Initialized
INFO - 2024-12-14 08:41:47 --> Router Class Initialized
INFO - 2024-12-14 08:41:47 --> Output Class Initialized
INFO - 2024-12-14 08:41:47 --> Security Class Initialized
DEBUG - 2024-12-14 08:41:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-14 08:41:47 --> Input Class Initialized
INFO - 2024-12-14 08:41:47 --> Language Class Initialized
INFO - 2024-12-14 08:41:47 --> Language Class Initialized
INFO - 2024-12-14 08:41:47 --> Config Class Initialized
INFO - 2024-12-14 08:41:47 --> Loader Class Initialized
INFO - 2024-12-14 08:41:47 --> Helper loaded: url_helper
INFO - 2024-12-14 08:41:47 --> Helper loaded: file_helper
INFO - 2024-12-14 08:41:47 --> Helper loaded: form_helper
INFO - 2024-12-14 08:41:47 --> Helper loaded: my_helper
INFO - 2024-12-14 08:41:47 --> Database Driver Class Initialized
INFO - 2024-12-14 08:41:47 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-14 08:41:47 --> Controller Class Initialized
INFO - 2024-12-14 08:41:47 --> Config Class Initialized
INFO - 2024-12-14 08:41:47 --> Hooks Class Initialized
DEBUG - 2024-12-14 08:41:47 --> UTF-8 Support Enabled
INFO - 2024-12-14 08:41:47 --> Utf8 Class Initialized
INFO - 2024-12-14 08:41:47 --> URI Class Initialized
INFO - 2024-12-14 08:41:47 --> Router Class Initialized
INFO - 2024-12-14 08:41:47 --> Output Class Initialized
INFO - 2024-12-14 08:41:47 --> Security Class Initialized
DEBUG - 2024-12-14 08:41:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-14 08:41:47 --> Input Class Initialized
INFO - 2024-12-14 08:41:47 --> Language Class Initialized
INFO - 2024-12-14 08:41:47 --> Language Class Initialized
INFO - 2024-12-14 08:41:47 --> Config Class Initialized
INFO - 2024-12-14 08:41:47 --> Loader Class Initialized
INFO - 2024-12-14 08:41:47 --> Helper loaded: url_helper
INFO - 2024-12-14 08:41:47 --> Helper loaded: file_helper
INFO - 2024-12-14 08:41:47 --> Helper loaded: form_helper
INFO - 2024-12-14 08:41:47 --> Helper loaded: my_helper
INFO - 2024-12-14 08:41:47 --> Database Driver Class Initialized
INFO - 2024-12-14 08:41:47 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-14 08:41:47 --> Controller Class Initialized
DEBUG - 2024-12-14 08:41:47 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/login/views/login.php
DEBUG - 2024-12-14 08:41:47 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-12-14 08:41:47 --> Final output sent to browser
DEBUG - 2024-12-14 08:41:47 --> Total execution time: 0.0304
INFO - 2024-12-14 08:41:49 --> Config Class Initialized
INFO - 2024-12-14 08:41:49 --> Hooks Class Initialized
DEBUG - 2024-12-14 08:41:49 --> UTF-8 Support Enabled
INFO - 2024-12-14 08:41:49 --> Utf8 Class Initialized
INFO - 2024-12-14 08:41:49 --> URI Class Initialized
INFO - 2024-12-14 08:41:49 --> Router Class Initialized
INFO - 2024-12-14 08:41:49 --> Output Class Initialized
INFO - 2024-12-14 08:41:49 --> Security Class Initialized
DEBUG - 2024-12-14 08:41:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-14 08:41:49 --> Input Class Initialized
INFO - 2024-12-14 08:41:49 --> Language Class Initialized
INFO - 2024-12-14 08:41:49 --> Language Class Initialized
INFO - 2024-12-14 08:41:49 --> Config Class Initialized
INFO - 2024-12-14 08:41:49 --> Loader Class Initialized
INFO - 2024-12-14 08:41:49 --> Helper loaded: url_helper
INFO - 2024-12-14 08:41:49 --> Helper loaded: file_helper
INFO - 2024-12-14 08:41:49 --> Helper loaded: form_helper
INFO - 2024-12-14 08:41:49 --> Helper loaded: my_helper
INFO - 2024-12-14 08:41:49 --> Database Driver Class Initialized
INFO - 2024-12-14 08:41:49 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-14 08:41:49 --> Controller Class Initialized
INFO - 2024-12-14 08:41:49 --> Config Class Initialized
INFO - 2024-12-14 08:41:49 --> Hooks Class Initialized
DEBUG - 2024-12-14 08:41:49 --> UTF-8 Support Enabled
INFO - 2024-12-14 08:41:49 --> Utf8 Class Initialized
INFO - 2024-12-14 08:41:49 --> URI Class Initialized
INFO - 2024-12-14 08:41:49 --> Router Class Initialized
INFO - 2024-12-14 08:41:49 --> Output Class Initialized
INFO - 2024-12-14 08:41:49 --> Security Class Initialized
DEBUG - 2024-12-14 08:41:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-14 08:41:49 --> Input Class Initialized
INFO - 2024-12-14 08:41:49 --> Language Class Initialized
INFO - 2024-12-14 08:41:49 --> Language Class Initialized
INFO - 2024-12-14 08:41:49 --> Config Class Initialized
INFO - 2024-12-14 08:41:49 --> Loader Class Initialized
INFO - 2024-12-14 08:41:49 --> Helper loaded: url_helper
INFO - 2024-12-14 08:41:49 --> Helper loaded: file_helper
INFO - 2024-12-14 08:41:49 --> Helper loaded: form_helper
INFO - 2024-12-14 08:41:49 --> Helper loaded: my_helper
INFO - 2024-12-14 08:41:49 --> Database Driver Class Initialized
INFO - 2024-12-14 08:41:49 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-14 08:41:49 --> Controller Class Initialized
DEBUG - 2024-12-14 08:41:49 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/login/views/login.php
DEBUG - 2024-12-14 08:41:49 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-12-14 08:41:49 --> Final output sent to browser
DEBUG - 2024-12-14 08:41:49 --> Total execution time: 0.0278
INFO - 2024-12-14 08:41:51 --> Config Class Initialized
INFO - 2024-12-14 08:41:51 --> Hooks Class Initialized
DEBUG - 2024-12-14 08:41:51 --> UTF-8 Support Enabled
INFO - 2024-12-14 08:41:51 --> Utf8 Class Initialized
INFO - 2024-12-14 08:41:51 --> URI Class Initialized
INFO - 2024-12-14 08:41:51 --> Router Class Initialized
INFO - 2024-12-14 08:41:51 --> Output Class Initialized
INFO - 2024-12-14 08:41:51 --> Security Class Initialized
DEBUG - 2024-12-14 08:41:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-14 08:41:51 --> Input Class Initialized
INFO - 2024-12-14 08:41:51 --> Language Class Initialized
INFO - 2024-12-14 08:41:51 --> Language Class Initialized
INFO - 2024-12-14 08:41:51 --> Config Class Initialized
INFO - 2024-12-14 08:41:51 --> Loader Class Initialized
INFO - 2024-12-14 08:41:51 --> Helper loaded: url_helper
INFO - 2024-12-14 08:41:51 --> Helper loaded: file_helper
INFO - 2024-12-14 08:41:51 --> Helper loaded: form_helper
INFO - 2024-12-14 08:41:51 --> Helper loaded: my_helper
INFO - 2024-12-14 08:41:51 --> Database Driver Class Initialized
INFO - 2024-12-14 08:41:51 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-14 08:41:51 --> Controller Class Initialized
INFO - 2024-12-14 08:41:51 --> Helper loaded: cookie_helper
INFO - 2024-12-14 08:41:51 --> Final output sent to browser
DEBUG - 2024-12-14 08:41:51 --> Total execution time: 0.0341
INFO - 2024-12-14 08:41:51 --> Config Class Initialized
INFO - 2024-12-14 08:41:51 --> Hooks Class Initialized
DEBUG - 2024-12-14 08:41:51 --> UTF-8 Support Enabled
INFO - 2024-12-14 08:41:51 --> Utf8 Class Initialized
INFO - 2024-12-14 08:41:51 --> URI Class Initialized
INFO - 2024-12-14 08:41:51 --> Router Class Initialized
INFO - 2024-12-14 08:41:51 --> Output Class Initialized
INFO - 2024-12-14 08:41:51 --> Security Class Initialized
DEBUG - 2024-12-14 08:41:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-14 08:41:51 --> Input Class Initialized
INFO - 2024-12-14 08:41:51 --> Language Class Initialized
INFO - 2024-12-14 08:41:51 --> Language Class Initialized
INFO - 2024-12-14 08:41:51 --> Config Class Initialized
INFO - 2024-12-14 08:41:51 --> Loader Class Initialized
INFO - 2024-12-14 08:41:51 --> Helper loaded: url_helper
INFO - 2024-12-14 08:41:51 --> Helper loaded: file_helper
INFO - 2024-12-14 08:41:51 --> Helper loaded: form_helper
INFO - 2024-12-14 08:41:51 --> Helper loaded: my_helper
INFO - 2024-12-14 08:41:51 --> Database Driver Class Initialized
INFO - 2024-12-14 08:41:51 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-14 08:41:51 --> Controller Class Initialized
DEBUG - 2024-12-14 08:41:51 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/home/views/v_home_guru.php
DEBUG - 2024-12-14 08:41:51 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-12-14 08:41:51 --> Final output sent to browser
DEBUG - 2024-12-14 08:41:51 --> Total execution time: 0.0386
INFO - 2024-12-14 08:42:04 --> Config Class Initialized
INFO - 2024-12-14 08:42:04 --> Hooks Class Initialized
DEBUG - 2024-12-14 08:42:04 --> UTF-8 Support Enabled
INFO - 2024-12-14 08:42:04 --> Utf8 Class Initialized
INFO - 2024-12-14 08:42:04 --> URI Class Initialized
INFO - 2024-12-14 08:42:04 --> Router Class Initialized
INFO - 2024-12-14 08:42:04 --> Output Class Initialized
INFO - 2024-12-14 08:42:04 --> Security Class Initialized
DEBUG - 2024-12-14 08:42:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-14 08:42:04 --> Input Class Initialized
INFO - 2024-12-14 08:42:04 --> Language Class Initialized
INFO - 2024-12-14 08:42:04 --> Language Class Initialized
INFO - 2024-12-14 08:42:04 --> Config Class Initialized
INFO - 2024-12-14 08:42:04 --> Loader Class Initialized
INFO - 2024-12-14 08:42:04 --> Helper loaded: url_helper
INFO - 2024-12-14 08:42:04 --> Helper loaded: file_helper
INFO - 2024-12-14 08:42:04 --> Helper loaded: form_helper
INFO - 2024-12-14 08:42:04 --> Helper loaded: my_helper
INFO - 2024-12-14 08:42:04 --> Database Driver Class Initialized
INFO - 2024-12-14 08:42:04 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-14 08:42:04 --> Controller Class Initialized
DEBUG - 2024-12-14 08:42:04 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/view_mapel/views/v_view_mapel.php
DEBUG - 2024-12-14 08:42:04 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-12-14 08:42:04 --> Final output sent to browser
DEBUG - 2024-12-14 08:42:04 --> Total execution time: 0.0327
INFO - 2024-12-14 08:42:10 --> Config Class Initialized
INFO - 2024-12-14 08:42:10 --> Hooks Class Initialized
DEBUG - 2024-12-14 08:42:10 --> UTF-8 Support Enabled
INFO - 2024-12-14 08:42:10 --> Utf8 Class Initialized
INFO - 2024-12-14 08:42:10 --> URI Class Initialized
INFO - 2024-12-14 08:42:10 --> Router Class Initialized
INFO - 2024-12-14 08:42:10 --> Output Class Initialized
INFO - 2024-12-14 08:42:10 --> Security Class Initialized
DEBUG - 2024-12-14 08:42:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-14 08:42:10 --> Input Class Initialized
INFO - 2024-12-14 08:42:10 --> Language Class Initialized
INFO - 2024-12-14 08:42:10 --> Language Class Initialized
INFO - 2024-12-14 08:42:10 --> Config Class Initialized
INFO - 2024-12-14 08:42:10 --> Loader Class Initialized
INFO - 2024-12-14 08:42:10 --> Helper loaded: url_helper
INFO - 2024-12-14 08:42:10 --> Helper loaded: file_helper
INFO - 2024-12-14 08:42:10 --> Helper loaded: form_helper
INFO - 2024-12-14 08:42:10 --> Helper loaded: my_helper
INFO - 2024-12-14 08:42:10 --> Database Driver Class Initialized
INFO - 2024-12-14 08:42:10 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-14 08:42:10 --> Controller Class Initialized
DEBUG - 2024-12-14 08:42:10 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/views/list.php
DEBUG - 2024-12-14 08:42:10 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-12-14 08:42:10 --> Final output sent to browser
DEBUG - 2024-12-14 08:42:10 --> Total execution time: 0.0628
INFO - 2024-12-14 08:42:10 --> Config Class Initialized
INFO - 2024-12-14 08:42:10 --> Hooks Class Initialized
DEBUG - 2024-12-14 08:42:10 --> UTF-8 Support Enabled
INFO - 2024-12-14 08:42:10 --> Utf8 Class Initialized
INFO - 2024-12-14 08:42:10 --> URI Class Initialized
INFO - 2024-12-14 08:42:10 --> Router Class Initialized
INFO - 2024-12-14 08:42:10 --> Output Class Initialized
INFO - 2024-12-14 08:42:10 --> Security Class Initialized
DEBUG - 2024-12-14 08:42:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-14 08:42:10 --> Input Class Initialized
INFO - 2024-12-14 08:42:10 --> Language Class Initialized
INFO - 2024-12-14 08:42:10 --> Language Class Initialized
INFO - 2024-12-14 08:42:10 --> Config Class Initialized
INFO - 2024-12-14 08:42:10 --> Loader Class Initialized
INFO - 2024-12-14 08:42:10 --> Helper loaded: url_helper
INFO - 2024-12-14 08:42:10 --> Helper loaded: file_helper
INFO - 2024-12-14 08:42:10 --> Helper loaded: form_helper
INFO - 2024-12-14 08:42:10 --> Helper loaded: my_helper
INFO - 2024-12-14 08:42:10 --> Database Driver Class Initialized
INFO - 2024-12-14 08:42:10 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-14 08:42:10 --> Controller Class Initialized
INFO - 2024-12-14 08:42:13 --> Config Class Initialized
INFO - 2024-12-14 08:42:13 --> Hooks Class Initialized
DEBUG - 2024-12-14 08:42:13 --> UTF-8 Support Enabled
INFO - 2024-12-14 08:42:13 --> Utf8 Class Initialized
INFO - 2024-12-14 08:42:13 --> URI Class Initialized
INFO - 2024-12-14 08:42:13 --> Router Class Initialized
INFO - 2024-12-14 08:42:13 --> Output Class Initialized
INFO - 2024-12-14 08:42:13 --> Security Class Initialized
DEBUG - 2024-12-14 08:42:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-14 08:42:13 --> Input Class Initialized
INFO - 2024-12-14 08:42:13 --> Language Class Initialized
INFO - 2024-12-14 08:42:13 --> Language Class Initialized
INFO - 2024-12-14 08:42:13 --> Config Class Initialized
INFO - 2024-12-14 08:42:13 --> Loader Class Initialized
INFO - 2024-12-14 08:42:13 --> Helper loaded: url_helper
INFO - 2024-12-14 08:42:13 --> Helper loaded: file_helper
INFO - 2024-12-14 08:42:13 --> Helper loaded: form_helper
INFO - 2024-12-14 08:42:13 --> Helper loaded: my_helper
INFO - 2024-12-14 08:42:13 --> Database Driver Class Initialized
INFO - 2024-12-14 08:42:13 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-14 08:42:13 --> Controller Class Initialized
INFO - 2024-12-14 08:42:13 --> Final output sent to browser
DEBUG - 2024-12-14 08:42:13 --> Total execution time: 0.0298
INFO - 2024-12-14 08:42:17 --> Config Class Initialized
INFO - 2024-12-14 08:42:17 --> Hooks Class Initialized
DEBUG - 2024-12-14 08:42:17 --> UTF-8 Support Enabled
INFO - 2024-12-14 08:42:17 --> Utf8 Class Initialized
INFO - 2024-12-14 08:42:17 --> URI Class Initialized
INFO - 2024-12-14 08:42:17 --> Router Class Initialized
INFO - 2024-12-14 08:42:17 --> Output Class Initialized
INFO - 2024-12-14 08:42:17 --> Security Class Initialized
DEBUG - 2024-12-14 08:42:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-14 08:42:17 --> Input Class Initialized
INFO - 2024-12-14 08:42:17 --> Language Class Initialized
INFO - 2024-12-14 08:42:17 --> Language Class Initialized
INFO - 2024-12-14 08:42:17 --> Config Class Initialized
INFO - 2024-12-14 08:42:17 --> Loader Class Initialized
INFO - 2024-12-14 08:42:17 --> Helper loaded: url_helper
INFO - 2024-12-14 08:42:17 --> Helper loaded: file_helper
INFO - 2024-12-14 08:42:17 --> Helper loaded: form_helper
INFO - 2024-12-14 08:42:17 --> Helper loaded: my_helper
INFO - 2024-12-14 08:42:17 --> Database Driver Class Initialized
INFO - 2024-12-14 08:42:17 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-14 08:42:17 --> Controller Class Initialized
INFO - 2024-12-14 08:42:17 --> Final output sent to browser
DEBUG - 2024-12-14 08:42:17 --> Total execution time: 0.0336
INFO - 2024-12-14 08:42:22 --> Config Class Initialized
INFO - 2024-12-14 08:42:22 --> Hooks Class Initialized
DEBUG - 2024-12-14 08:42:22 --> UTF-8 Support Enabled
INFO - 2024-12-14 08:42:22 --> Utf8 Class Initialized
INFO - 2024-12-14 08:42:22 --> URI Class Initialized
INFO - 2024-12-14 08:42:22 --> Router Class Initialized
INFO - 2024-12-14 08:42:22 --> Output Class Initialized
INFO - 2024-12-14 08:42:22 --> Security Class Initialized
DEBUG - 2024-12-14 08:42:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-14 08:42:22 --> Input Class Initialized
INFO - 2024-12-14 08:42:22 --> Language Class Initialized
INFO - 2024-12-14 08:42:22 --> Language Class Initialized
INFO - 2024-12-14 08:42:22 --> Config Class Initialized
INFO - 2024-12-14 08:42:22 --> Loader Class Initialized
INFO - 2024-12-14 08:42:22 --> Helper loaded: url_helper
INFO - 2024-12-14 08:42:22 --> Helper loaded: file_helper
INFO - 2024-12-14 08:42:22 --> Helper loaded: form_helper
INFO - 2024-12-14 08:42:22 --> Helper loaded: my_helper
INFO - 2024-12-14 08:42:22 --> Database Driver Class Initialized
INFO - 2024-12-14 08:42:22 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-14 08:42:22 --> Controller Class Initialized
INFO - 2024-12-14 08:42:23 --> Final output sent to browser
DEBUG - 2024-12-14 08:42:23 --> Total execution time: 0.2759
INFO - 2024-12-14 08:42:25 --> Config Class Initialized
INFO - 2024-12-14 08:42:25 --> Hooks Class Initialized
DEBUG - 2024-12-14 08:42:25 --> UTF-8 Support Enabled
INFO - 2024-12-14 08:42:25 --> Utf8 Class Initialized
INFO - 2024-12-14 08:42:25 --> URI Class Initialized
INFO - 2024-12-14 08:42:25 --> Router Class Initialized
INFO - 2024-12-14 08:42:25 --> Output Class Initialized
INFO - 2024-12-14 08:42:25 --> Security Class Initialized
DEBUG - 2024-12-14 08:42:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-14 08:42:25 --> Input Class Initialized
INFO - 2024-12-14 08:42:25 --> Language Class Initialized
INFO - 2024-12-14 08:42:25 --> Language Class Initialized
INFO - 2024-12-14 08:42:25 --> Config Class Initialized
INFO - 2024-12-14 08:42:25 --> Loader Class Initialized
INFO - 2024-12-14 08:42:25 --> Helper loaded: url_helper
INFO - 2024-12-14 08:42:25 --> Helper loaded: file_helper
INFO - 2024-12-14 08:42:25 --> Helper loaded: form_helper
INFO - 2024-12-14 08:42:25 --> Helper loaded: my_helper
INFO - 2024-12-14 08:42:25 --> Database Driver Class Initialized
INFO - 2024-12-14 08:42:25 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-14 08:42:25 --> Controller Class Initialized
INFO - 2024-12-14 08:42:25 --> Final output sent to browser
DEBUG - 2024-12-14 08:42:25 --> Total execution time: 0.0346
INFO - 2024-12-14 08:42:34 --> Config Class Initialized
INFO - 2024-12-14 08:42:34 --> Hooks Class Initialized
DEBUG - 2024-12-14 08:42:34 --> UTF-8 Support Enabled
INFO - 2024-12-14 08:42:34 --> Utf8 Class Initialized
INFO - 2024-12-14 08:42:34 --> URI Class Initialized
INFO - 2024-12-14 08:42:34 --> Router Class Initialized
INFO - 2024-12-14 08:42:34 --> Output Class Initialized
INFO - 2024-12-14 08:42:34 --> Security Class Initialized
DEBUG - 2024-12-14 08:42:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-14 08:42:34 --> Input Class Initialized
INFO - 2024-12-14 08:42:34 --> Language Class Initialized
INFO - 2024-12-14 08:42:34 --> Language Class Initialized
INFO - 2024-12-14 08:42:34 --> Config Class Initialized
INFO - 2024-12-14 08:42:34 --> Loader Class Initialized
INFO - 2024-12-14 08:42:34 --> Helper loaded: url_helper
INFO - 2024-12-14 08:42:34 --> Helper loaded: file_helper
INFO - 2024-12-14 08:42:34 --> Helper loaded: form_helper
INFO - 2024-12-14 08:42:34 --> Helper loaded: my_helper
INFO - 2024-12-14 08:42:34 --> Database Driver Class Initialized
INFO - 2024-12-14 08:42:34 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-14 08:42:34 --> Controller Class Initialized
INFO - 2024-12-14 08:42:34 --> Final output sent to browser
DEBUG - 2024-12-14 08:42:34 --> Total execution time: 0.0761
INFO - 2024-12-14 08:42:37 --> Config Class Initialized
INFO - 2024-12-14 08:42:37 --> Hooks Class Initialized
DEBUG - 2024-12-14 08:42:37 --> UTF-8 Support Enabled
INFO - 2024-12-14 08:42:37 --> Utf8 Class Initialized
INFO - 2024-12-14 08:42:37 --> URI Class Initialized
INFO - 2024-12-14 08:42:37 --> Router Class Initialized
INFO - 2024-12-14 08:42:37 --> Output Class Initialized
INFO - 2024-12-14 08:42:37 --> Security Class Initialized
DEBUG - 2024-12-14 08:42:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-14 08:42:37 --> Input Class Initialized
INFO - 2024-12-14 08:42:37 --> Language Class Initialized
INFO - 2024-12-14 08:42:37 --> Language Class Initialized
INFO - 2024-12-14 08:42:37 --> Config Class Initialized
INFO - 2024-12-14 08:42:37 --> Loader Class Initialized
INFO - 2024-12-14 08:42:37 --> Helper loaded: url_helper
INFO - 2024-12-14 08:42:37 --> Helper loaded: file_helper
INFO - 2024-12-14 08:42:37 --> Helper loaded: form_helper
INFO - 2024-12-14 08:42:37 --> Helper loaded: my_helper
INFO - 2024-12-14 08:42:37 --> Database Driver Class Initialized
INFO - 2024-12-14 08:42:37 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-14 08:42:37 --> Controller Class Initialized
DEBUG - 2024-12-14 08:42:37 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/views/list.php
DEBUG - 2024-12-14 08:42:37 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-12-14 08:42:37 --> Final output sent to browser
DEBUG - 2024-12-14 08:42:37 --> Total execution time: 0.0377
INFO - 2024-12-14 08:42:41 --> Config Class Initialized
INFO - 2024-12-14 08:42:41 --> Hooks Class Initialized
DEBUG - 2024-12-14 08:42:41 --> UTF-8 Support Enabled
INFO - 2024-12-14 08:42:41 --> Utf8 Class Initialized
INFO - 2024-12-14 08:42:41 --> URI Class Initialized
INFO - 2024-12-14 08:42:41 --> Router Class Initialized
INFO - 2024-12-14 08:42:41 --> Output Class Initialized
INFO - 2024-12-14 08:42:41 --> Security Class Initialized
DEBUG - 2024-12-14 08:42:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-14 08:42:41 --> Input Class Initialized
INFO - 2024-12-14 08:42:41 --> Language Class Initialized
INFO - 2024-12-14 08:42:41 --> Language Class Initialized
INFO - 2024-12-14 08:42:41 --> Config Class Initialized
INFO - 2024-12-14 08:42:41 --> Loader Class Initialized
INFO - 2024-12-14 08:42:41 --> Helper loaded: url_helper
INFO - 2024-12-14 08:42:41 --> Helper loaded: file_helper
INFO - 2024-12-14 08:42:41 --> Helper loaded: form_helper
INFO - 2024-12-14 08:42:41 --> Helper loaded: my_helper
INFO - 2024-12-14 08:42:41 --> Database Driver Class Initialized
INFO - 2024-12-14 08:42:41 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-14 08:42:41 --> Controller Class Initialized
INFO - 2024-12-14 08:42:41 --> Final output sent to browser
DEBUG - 2024-12-14 08:42:41 --> Total execution time: 0.2490
INFO - 2024-12-14 08:42:43 --> Config Class Initialized
INFO - 2024-12-14 08:42:43 --> Hooks Class Initialized
DEBUG - 2024-12-14 08:42:43 --> UTF-8 Support Enabled
INFO - 2024-12-14 08:42:43 --> Utf8 Class Initialized
INFO - 2024-12-14 08:42:43 --> URI Class Initialized
INFO - 2024-12-14 08:42:43 --> Router Class Initialized
INFO - 2024-12-14 08:42:43 --> Output Class Initialized
INFO - 2024-12-14 08:42:43 --> Security Class Initialized
DEBUG - 2024-12-14 08:42:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-14 08:42:43 --> Input Class Initialized
INFO - 2024-12-14 08:42:43 --> Language Class Initialized
INFO - 2024-12-14 08:42:43 --> Language Class Initialized
INFO - 2024-12-14 08:42:43 --> Config Class Initialized
INFO - 2024-12-14 08:42:43 --> Loader Class Initialized
INFO - 2024-12-14 08:42:43 --> Helper loaded: url_helper
INFO - 2024-12-14 08:42:43 --> Helper loaded: file_helper
INFO - 2024-12-14 08:42:43 --> Helper loaded: form_helper
INFO - 2024-12-14 08:42:43 --> Helper loaded: my_helper
INFO - 2024-12-14 08:42:43 --> Database Driver Class Initialized
INFO - 2024-12-14 08:42:43 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-14 08:42:43 --> Controller Class Initialized
INFO - 2024-12-14 08:42:43 --> Final output sent to browser
DEBUG - 2024-12-14 08:42:43 --> Total execution time: 0.0314
INFO - 2024-12-14 08:42:48 --> Config Class Initialized
INFO - 2024-12-14 08:42:48 --> Hooks Class Initialized
DEBUG - 2024-12-14 08:42:48 --> UTF-8 Support Enabled
INFO - 2024-12-14 08:42:48 --> Utf8 Class Initialized
INFO - 2024-12-14 08:42:48 --> URI Class Initialized
INFO - 2024-12-14 08:42:48 --> Router Class Initialized
INFO - 2024-12-14 08:42:48 --> Output Class Initialized
INFO - 2024-12-14 08:42:48 --> Security Class Initialized
DEBUG - 2024-12-14 08:42:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-14 08:42:48 --> Input Class Initialized
INFO - 2024-12-14 08:42:48 --> Language Class Initialized
INFO - 2024-12-14 08:42:48 --> Language Class Initialized
INFO - 2024-12-14 08:42:48 --> Config Class Initialized
INFO - 2024-12-14 08:42:48 --> Loader Class Initialized
INFO - 2024-12-14 08:42:48 --> Helper loaded: url_helper
INFO - 2024-12-14 08:42:48 --> Helper loaded: file_helper
INFO - 2024-12-14 08:42:48 --> Helper loaded: form_helper
INFO - 2024-12-14 08:42:48 --> Helper loaded: my_helper
INFO - 2024-12-14 08:42:48 --> Database Driver Class Initialized
INFO - 2024-12-14 08:42:48 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-14 08:42:48 --> Controller Class Initialized
INFO - 2024-12-14 08:42:48 --> Final output sent to browser
DEBUG - 2024-12-14 08:42:48 --> Total execution time: 0.4908
INFO - 2024-12-14 08:42:50 --> Config Class Initialized
INFO - 2024-12-14 08:42:50 --> Hooks Class Initialized
DEBUG - 2024-12-14 08:42:50 --> UTF-8 Support Enabled
INFO - 2024-12-14 08:42:50 --> Utf8 Class Initialized
INFO - 2024-12-14 08:42:50 --> URI Class Initialized
INFO - 2024-12-14 08:42:50 --> Router Class Initialized
INFO - 2024-12-14 08:42:50 --> Output Class Initialized
INFO - 2024-12-14 08:42:50 --> Security Class Initialized
DEBUG - 2024-12-14 08:42:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-14 08:42:50 --> Input Class Initialized
INFO - 2024-12-14 08:42:50 --> Language Class Initialized
INFO - 2024-12-14 08:42:50 --> Language Class Initialized
INFO - 2024-12-14 08:42:50 --> Config Class Initialized
INFO - 2024-12-14 08:42:50 --> Loader Class Initialized
INFO - 2024-12-14 08:42:50 --> Helper loaded: url_helper
INFO - 2024-12-14 08:42:50 --> Helper loaded: file_helper
INFO - 2024-12-14 08:42:50 --> Helper loaded: form_helper
INFO - 2024-12-14 08:42:50 --> Helper loaded: my_helper
INFO - 2024-12-14 08:42:50 --> Database Driver Class Initialized
INFO - 2024-12-14 08:42:50 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-14 08:42:50 --> Controller Class Initialized
INFO - 2024-12-14 08:42:50 --> Final output sent to browser
DEBUG - 2024-12-14 08:42:50 --> Total execution time: 0.0301
INFO - 2024-12-14 08:42:57 --> Config Class Initialized
INFO - 2024-12-14 08:42:57 --> Hooks Class Initialized
DEBUG - 2024-12-14 08:42:57 --> UTF-8 Support Enabled
INFO - 2024-12-14 08:42:57 --> Utf8 Class Initialized
INFO - 2024-12-14 08:42:57 --> URI Class Initialized
INFO - 2024-12-14 08:42:57 --> Router Class Initialized
INFO - 2024-12-14 08:42:57 --> Output Class Initialized
INFO - 2024-12-14 08:42:57 --> Security Class Initialized
DEBUG - 2024-12-14 08:42:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-14 08:42:57 --> Input Class Initialized
INFO - 2024-12-14 08:42:57 --> Language Class Initialized
INFO - 2024-12-14 08:42:57 --> Language Class Initialized
INFO - 2024-12-14 08:42:57 --> Config Class Initialized
INFO - 2024-12-14 08:42:57 --> Loader Class Initialized
INFO - 2024-12-14 08:42:57 --> Helper loaded: url_helper
INFO - 2024-12-14 08:42:57 --> Helper loaded: file_helper
INFO - 2024-12-14 08:42:57 --> Helper loaded: form_helper
INFO - 2024-12-14 08:42:57 --> Helper loaded: my_helper
INFO - 2024-12-14 08:42:57 --> Database Driver Class Initialized
INFO - 2024-12-14 08:42:57 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-14 08:42:57 --> Controller Class Initialized
INFO - 2024-12-14 08:42:57 --> Final output sent to browser
DEBUG - 2024-12-14 08:42:57 --> Total execution time: 0.0313
INFO - 2024-12-14 08:42:59 --> Config Class Initialized
INFO - 2024-12-14 08:42:59 --> Hooks Class Initialized
DEBUG - 2024-12-14 08:42:59 --> UTF-8 Support Enabled
INFO - 2024-12-14 08:42:59 --> Utf8 Class Initialized
INFO - 2024-12-14 08:42:59 --> URI Class Initialized
INFO - 2024-12-14 08:42:59 --> Router Class Initialized
INFO - 2024-12-14 08:42:59 --> Output Class Initialized
INFO - 2024-12-14 08:42:59 --> Security Class Initialized
DEBUG - 2024-12-14 08:42:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-14 08:42:59 --> Input Class Initialized
INFO - 2024-12-14 08:42:59 --> Language Class Initialized
INFO - 2024-12-14 08:42:59 --> Language Class Initialized
INFO - 2024-12-14 08:42:59 --> Config Class Initialized
INFO - 2024-12-14 08:42:59 --> Loader Class Initialized
INFO - 2024-12-14 08:42:59 --> Helper loaded: url_helper
INFO - 2024-12-14 08:42:59 --> Helper loaded: file_helper
INFO - 2024-12-14 08:42:59 --> Helper loaded: form_helper
INFO - 2024-12-14 08:42:59 --> Helper loaded: my_helper
INFO - 2024-12-14 08:42:59 --> Database Driver Class Initialized
INFO - 2024-12-14 08:42:59 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-14 08:42:59 --> Controller Class Initialized
INFO - 2024-12-14 08:42:59 --> Final output sent to browser
DEBUG - 2024-12-14 08:42:59 --> Total execution time: 0.0355
INFO - 2024-12-14 08:43:02 --> Config Class Initialized
INFO - 2024-12-14 08:43:02 --> Hooks Class Initialized
DEBUG - 2024-12-14 08:43:02 --> UTF-8 Support Enabled
INFO - 2024-12-14 08:43:02 --> Utf8 Class Initialized
INFO - 2024-12-14 08:43:02 --> URI Class Initialized
INFO - 2024-12-14 08:43:02 --> Router Class Initialized
INFO - 2024-12-14 08:43:02 --> Output Class Initialized
INFO - 2024-12-14 08:43:02 --> Security Class Initialized
DEBUG - 2024-12-14 08:43:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-14 08:43:02 --> Input Class Initialized
INFO - 2024-12-14 08:43:02 --> Language Class Initialized
INFO - 2024-12-14 08:43:02 --> Language Class Initialized
INFO - 2024-12-14 08:43:02 --> Config Class Initialized
INFO - 2024-12-14 08:43:02 --> Loader Class Initialized
INFO - 2024-12-14 08:43:02 --> Helper loaded: url_helper
INFO - 2024-12-14 08:43:02 --> Helper loaded: file_helper
INFO - 2024-12-14 08:43:02 --> Helper loaded: form_helper
INFO - 2024-12-14 08:43:02 --> Helper loaded: my_helper
INFO - 2024-12-14 08:43:02 --> Database Driver Class Initialized
INFO - 2024-12-14 08:43:02 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-14 08:43:02 --> Controller Class Initialized
INFO - 2024-12-14 08:43:02 --> Final output sent to browser
DEBUG - 2024-12-14 08:43:02 --> Total execution time: 0.0744
INFO - 2024-12-14 08:43:07 --> Config Class Initialized
INFO - 2024-12-14 08:43:07 --> Hooks Class Initialized
DEBUG - 2024-12-14 08:43:07 --> UTF-8 Support Enabled
INFO - 2024-12-14 08:43:07 --> Utf8 Class Initialized
INFO - 2024-12-14 08:43:07 --> URI Class Initialized
INFO - 2024-12-14 08:43:07 --> Router Class Initialized
INFO - 2024-12-14 08:43:07 --> Output Class Initialized
INFO - 2024-12-14 08:43:07 --> Security Class Initialized
DEBUG - 2024-12-14 08:43:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-14 08:43:07 --> Input Class Initialized
INFO - 2024-12-14 08:43:07 --> Language Class Initialized
INFO - 2024-12-14 08:43:07 --> Language Class Initialized
INFO - 2024-12-14 08:43:07 --> Config Class Initialized
INFO - 2024-12-14 08:43:07 --> Loader Class Initialized
INFO - 2024-12-14 08:43:07 --> Helper loaded: url_helper
INFO - 2024-12-14 08:43:07 --> Helper loaded: file_helper
INFO - 2024-12-14 08:43:07 --> Helper loaded: form_helper
INFO - 2024-12-14 08:43:07 --> Helper loaded: my_helper
INFO - 2024-12-14 08:43:07 --> Database Driver Class Initialized
INFO - 2024-12-14 08:43:07 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-14 08:43:07 --> Controller Class Initialized
DEBUG - 2024-12-14 08:43:07 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/views/cetak_ikm.php
INFO - 2024-12-14 08:43:07 --> Config Class Initialized
INFO - 2024-12-14 08:43:07 --> Hooks Class Initialized
DEBUG - 2024-12-14 08:43:07 --> UTF-8 Support Enabled
INFO - 2024-12-14 08:43:07 --> Utf8 Class Initialized
INFO - 2024-12-14 08:43:07 --> URI Class Initialized
INFO - 2024-12-14 08:43:07 --> Router Class Initialized
INFO - 2024-12-14 08:43:07 --> Output Class Initialized
INFO - 2024-12-14 08:43:07 --> Security Class Initialized
DEBUG - 2024-12-14 08:43:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-14 08:43:07 --> Input Class Initialized
INFO - 2024-12-14 08:43:07 --> Language Class Initialized
INFO - 2024-12-14 08:43:07 --> Language Class Initialized
INFO - 2024-12-14 08:43:07 --> Config Class Initialized
INFO - 2024-12-14 08:43:07 --> Loader Class Initialized
INFO - 2024-12-14 08:43:07 --> Helper loaded: url_helper
INFO - 2024-12-14 08:43:07 --> Helper loaded: file_helper
INFO - 2024-12-14 08:43:07 --> Helper loaded: form_helper
INFO - 2024-12-14 08:43:07 --> Helper loaded: my_helper
INFO - 2024-12-14 08:43:07 --> Database Driver Class Initialized
INFO - 2024-12-14 08:43:07 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-14 08:43:07 --> Controller Class Initialized
INFO - 2024-12-14 08:43:08 --> Final output sent to browser
DEBUG - 2024-12-14 08:43:08 --> Total execution time: 0.6468
INFO - 2024-12-14 08:43:09 --> Final output sent to browser
DEBUG - 2024-12-14 08:43:09 --> Total execution time: 1.7309
INFO - 2024-12-14 08:43:09 --> Config Class Initialized
INFO - 2024-12-14 08:43:09 --> Hooks Class Initialized
DEBUG - 2024-12-14 08:43:09 --> UTF-8 Support Enabled
INFO - 2024-12-14 08:43:09 --> Utf8 Class Initialized
INFO - 2024-12-14 08:43:09 --> URI Class Initialized
INFO - 2024-12-14 08:43:09 --> Router Class Initialized
INFO - 2024-12-14 08:43:09 --> Output Class Initialized
INFO - 2024-12-14 08:43:09 --> Security Class Initialized
DEBUG - 2024-12-14 08:43:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-14 08:43:09 --> Input Class Initialized
INFO - 2024-12-14 08:43:09 --> Language Class Initialized
INFO - 2024-12-14 08:43:09 --> Language Class Initialized
INFO - 2024-12-14 08:43:09 --> Config Class Initialized
INFO - 2024-12-14 08:43:09 --> Loader Class Initialized
INFO - 2024-12-14 08:43:09 --> Helper loaded: url_helper
INFO - 2024-12-14 08:43:09 --> Helper loaded: file_helper
INFO - 2024-12-14 08:43:09 --> Helper loaded: form_helper
INFO - 2024-12-14 08:43:09 --> Helper loaded: my_helper
INFO - 2024-12-14 08:43:09 --> Database Driver Class Initialized
INFO - 2024-12-14 08:43:09 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-14 08:43:09 --> Controller Class Initialized
DEBUG - 2024-12-14 08:43:09 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/view_mapel/views/v_view_mapel.php
DEBUG - 2024-12-14 08:43:09 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-12-14 08:43:09 --> Final output sent to browser
DEBUG - 2024-12-14 08:43:09 --> Total execution time: 0.0307
INFO - 2024-12-14 09:04:16 --> Config Class Initialized
INFO - 2024-12-14 09:04:16 --> Hooks Class Initialized
DEBUG - 2024-12-14 09:04:16 --> UTF-8 Support Enabled
INFO - 2024-12-14 09:04:16 --> Utf8 Class Initialized
INFO - 2024-12-14 09:04:16 --> URI Class Initialized
INFO - 2024-12-14 09:04:16 --> Router Class Initialized
INFO - 2024-12-14 09:04:16 --> Output Class Initialized
INFO - 2024-12-14 09:04:16 --> Security Class Initialized
DEBUG - 2024-12-14 09:04:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-14 09:04:16 --> Input Class Initialized
INFO - 2024-12-14 09:04:16 --> Language Class Initialized
INFO - 2024-12-14 09:04:16 --> Language Class Initialized
INFO - 2024-12-14 09:04:16 --> Config Class Initialized
INFO - 2024-12-14 09:04:16 --> Loader Class Initialized
INFO - 2024-12-14 09:04:16 --> Helper loaded: url_helper
INFO - 2024-12-14 09:04:16 --> Helper loaded: file_helper
INFO - 2024-12-14 09:04:16 --> Helper loaded: form_helper
INFO - 2024-12-14 09:04:16 --> Helper loaded: my_helper
INFO - 2024-12-14 09:04:16 --> Database Driver Class Initialized
INFO - 2024-12-14 09:04:16 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-14 09:04:16 --> Controller Class Initialized
DEBUG - 2024-12-14 09:04:16 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/views/list.php
DEBUG - 2024-12-14 09:04:16 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-12-14 09:04:16 --> Final output sent to browser
DEBUG - 2024-12-14 09:04:16 --> Total execution time: 0.0374
INFO - 2024-12-14 11:10:32 --> Config Class Initialized
INFO - 2024-12-14 11:10:32 --> Hooks Class Initialized
DEBUG - 2024-12-14 11:10:32 --> UTF-8 Support Enabled
INFO - 2024-12-14 11:10:32 --> Utf8 Class Initialized
INFO - 2024-12-14 11:10:32 --> URI Class Initialized
INFO - 2024-12-14 11:10:32 --> Router Class Initialized
INFO - 2024-12-14 11:10:32 --> Output Class Initialized
INFO - 2024-12-14 11:10:32 --> Security Class Initialized
DEBUG - 2024-12-14 11:10:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-14 11:10:32 --> Input Class Initialized
INFO - 2024-12-14 11:10:32 --> Language Class Initialized
INFO - 2024-12-14 11:10:32 --> Language Class Initialized
INFO - 2024-12-14 11:10:32 --> Config Class Initialized
INFO - 2024-12-14 11:10:32 --> Loader Class Initialized
INFO - 2024-12-14 11:10:32 --> Helper loaded: url_helper
INFO - 2024-12-14 11:10:32 --> Helper loaded: file_helper
INFO - 2024-12-14 11:10:32 --> Helper loaded: form_helper
INFO - 2024-12-14 11:10:32 --> Helper loaded: my_helper
INFO - 2024-12-14 11:10:32 --> Database Driver Class Initialized
INFO - 2024-12-14 11:10:32 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-14 11:10:32 --> Controller Class Initialized
ERROR - 2024-12-14 11:10:32 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 3898
DEBUG - 2024-12-14 11:10:32 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/views/list.php
DEBUG - 2024-12-14 11:10:32 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-12-14 11:10:32 --> Final output sent to browser
DEBUG - 2024-12-14 11:10:32 --> Total execution time: 0.0746
INFO - 2024-12-14 11:10:34 --> Config Class Initialized
INFO - 2024-12-14 11:10:34 --> Hooks Class Initialized
DEBUG - 2024-12-14 11:10:34 --> UTF-8 Support Enabled
INFO - 2024-12-14 11:10:34 --> Utf8 Class Initialized
INFO - 2024-12-14 11:10:34 --> URI Class Initialized
INFO - 2024-12-14 11:10:34 --> Router Class Initialized
INFO - 2024-12-14 11:10:34 --> Output Class Initialized
INFO - 2024-12-14 11:10:34 --> Security Class Initialized
DEBUG - 2024-12-14 11:10:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-14 11:10:34 --> Input Class Initialized
INFO - 2024-12-14 11:10:34 --> Language Class Initialized
INFO - 2024-12-14 11:10:34 --> Language Class Initialized
INFO - 2024-12-14 11:10:34 --> Config Class Initialized
INFO - 2024-12-14 11:10:34 --> Loader Class Initialized
INFO - 2024-12-14 11:10:34 --> Helper loaded: url_helper
INFO - 2024-12-14 11:10:34 --> Helper loaded: file_helper
INFO - 2024-12-14 11:10:34 --> Helper loaded: form_helper
INFO - 2024-12-14 11:10:34 --> Helper loaded: my_helper
INFO - 2024-12-14 11:10:34 --> Database Driver Class Initialized
INFO - 2024-12-14 11:10:34 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-14 11:10:34 --> Controller Class Initialized
ERROR - 2024-12-14 11:10:34 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 3898
DEBUG - 2024-12-14 11:10:34 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/views/list.php
DEBUG - 2024-12-14 11:10:34 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-12-14 11:10:34 --> Final output sent to browser
DEBUG - 2024-12-14 11:10:34 --> Total execution time: 0.0545
INFO - 2024-12-14 11:10:37 --> Config Class Initialized
INFO - 2024-12-14 11:10:37 --> Hooks Class Initialized
DEBUG - 2024-12-14 11:10:37 --> UTF-8 Support Enabled
INFO - 2024-12-14 11:10:37 --> Utf8 Class Initialized
INFO - 2024-12-14 11:10:37 --> URI Class Initialized
INFO - 2024-12-14 11:10:37 --> Router Class Initialized
INFO - 2024-12-14 11:10:37 --> Output Class Initialized
INFO - 2024-12-14 11:10:37 --> Security Class Initialized
DEBUG - 2024-12-14 11:10:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-14 11:10:37 --> Input Class Initialized
INFO - 2024-12-14 11:10:37 --> Language Class Initialized
INFO - 2024-12-14 11:10:37 --> Language Class Initialized
INFO - 2024-12-14 11:10:37 --> Config Class Initialized
INFO - 2024-12-14 11:10:37 --> Loader Class Initialized
INFO - 2024-12-14 11:10:37 --> Helper loaded: url_helper
INFO - 2024-12-14 11:10:37 --> Helper loaded: file_helper
INFO - 2024-12-14 11:10:37 --> Helper loaded: form_helper
INFO - 2024-12-14 11:10:38 --> Helper loaded: my_helper
INFO - 2024-12-14 11:10:38 --> Database Driver Class Initialized
INFO - 2024-12-14 11:10:38 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-14 11:10:38 --> Controller Class Initialized
DEBUG - 2024-12-14 11:10:38 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/login/views/login.php
DEBUG - 2024-12-14 11:10:38 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-12-14 11:10:38 --> Final output sent to browser
DEBUG - 2024-12-14 11:10:38 --> Total execution time: 0.0336
INFO - 2024-12-14 11:10:45 --> Config Class Initialized
INFO - 2024-12-14 11:10:45 --> Hooks Class Initialized
DEBUG - 2024-12-14 11:10:45 --> UTF-8 Support Enabled
INFO - 2024-12-14 11:10:45 --> Utf8 Class Initialized
INFO - 2024-12-14 11:10:45 --> URI Class Initialized
INFO - 2024-12-14 11:10:45 --> Router Class Initialized
INFO - 2024-12-14 11:10:45 --> Output Class Initialized
INFO - 2024-12-14 11:10:45 --> Security Class Initialized
DEBUG - 2024-12-14 11:10:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-14 11:10:45 --> Input Class Initialized
INFO - 2024-12-14 11:10:45 --> Language Class Initialized
INFO - 2024-12-14 11:10:45 --> Language Class Initialized
INFO - 2024-12-14 11:10:45 --> Config Class Initialized
INFO - 2024-12-14 11:10:45 --> Loader Class Initialized
INFO - 2024-12-14 11:10:45 --> Helper loaded: url_helper
INFO - 2024-12-14 11:10:45 --> Helper loaded: file_helper
INFO - 2024-12-14 11:10:46 --> Helper loaded: form_helper
INFO - 2024-12-14 11:10:46 --> Helper loaded: my_helper
INFO - 2024-12-14 11:10:46 --> Database Driver Class Initialized
INFO - 2024-12-14 11:10:46 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-14 11:10:46 --> Controller Class Initialized
INFO - 2024-12-14 11:10:46 --> Helper loaded: cookie_helper
INFO - 2024-12-14 11:10:46 --> Final output sent to browser
DEBUG - 2024-12-14 11:10:46 --> Total execution time: 0.1341
INFO - 2024-12-14 11:10:46 --> Config Class Initialized
INFO - 2024-12-14 11:10:46 --> Hooks Class Initialized
DEBUG - 2024-12-14 11:10:46 --> UTF-8 Support Enabled
INFO - 2024-12-14 11:10:46 --> Utf8 Class Initialized
INFO - 2024-12-14 11:10:46 --> URI Class Initialized
INFO - 2024-12-14 11:10:46 --> Router Class Initialized
INFO - 2024-12-14 11:10:46 --> Output Class Initialized
INFO - 2024-12-14 11:10:46 --> Security Class Initialized
DEBUG - 2024-12-14 11:10:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-14 11:10:46 --> Input Class Initialized
INFO - 2024-12-14 11:10:46 --> Language Class Initialized
INFO - 2024-12-14 11:10:46 --> Language Class Initialized
INFO - 2024-12-14 11:10:46 --> Config Class Initialized
INFO - 2024-12-14 11:10:46 --> Loader Class Initialized
INFO - 2024-12-14 11:10:46 --> Helper loaded: url_helper
INFO - 2024-12-14 11:10:46 --> Helper loaded: file_helper
INFO - 2024-12-14 11:10:46 --> Helper loaded: form_helper
INFO - 2024-12-14 11:10:46 --> Helper loaded: my_helper
INFO - 2024-12-14 11:10:46 --> Database Driver Class Initialized
INFO - 2024-12-14 11:10:46 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-14 11:10:46 --> Controller Class Initialized
DEBUG - 2024-12-14 11:10:46 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/home/views/v_home_guru.php
DEBUG - 2024-12-14 11:10:46 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-12-14 11:10:46 --> Final output sent to browser
DEBUG - 2024-12-14 11:10:46 --> Total execution time: 0.0826
INFO - 2024-12-14 11:10:55 --> Config Class Initialized
INFO - 2024-12-14 11:10:55 --> Hooks Class Initialized
DEBUG - 2024-12-14 11:10:55 --> UTF-8 Support Enabled
INFO - 2024-12-14 11:10:55 --> Utf8 Class Initialized
INFO - 2024-12-14 11:10:55 --> URI Class Initialized
INFO - 2024-12-14 11:10:55 --> Router Class Initialized
INFO - 2024-12-14 11:10:55 --> Output Class Initialized
INFO - 2024-12-14 11:10:55 --> Security Class Initialized
DEBUG - 2024-12-14 11:10:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-14 11:10:55 --> Input Class Initialized
INFO - 2024-12-14 11:10:55 --> Language Class Initialized
INFO - 2024-12-14 11:10:55 --> Language Class Initialized
INFO - 2024-12-14 11:10:55 --> Config Class Initialized
INFO - 2024-12-14 11:10:55 --> Loader Class Initialized
INFO - 2024-12-14 11:10:55 --> Helper loaded: url_helper
INFO - 2024-12-14 11:10:55 --> Helper loaded: file_helper
INFO - 2024-12-14 11:10:55 --> Helper loaded: form_helper
INFO - 2024-12-14 11:10:55 --> Helper loaded: my_helper
INFO - 2024-12-14 11:10:55 --> Database Driver Class Initialized
INFO - 2024-12-14 11:10:55 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-14 11:10:55 --> Controller Class Initialized
DEBUG - 2024-12-14 11:10:55 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/views/list.php
DEBUG - 2024-12-14 11:10:55 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-12-14 11:10:55 --> Final output sent to browser
DEBUG - 2024-12-14 11:10:55 --> Total execution time: 0.0426
INFO - 2024-12-14 11:10:57 --> Config Class Initialized
INFO - 2024-12-14 11:10:57 --> Hooks Class Initialized
DEBUG - 2024-12-14 11:10:57 --> UTF-8 Support Enabled
INFO - 2024-12-14 11:10:57 --> Utf8 Class Initialized
INFO - 2024-12-14 11:10:57 --> URI Class Initialized
INFO - 2024-12-14 11:10:57 --> Router Class Initialized
INFO - 2024-12-14 11:10:57 --> Output Class Initialized
INFO - 2024-12-14 11:10:57 --> Security Class Initialized
DEBUG - 2024-12-14 11:10:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-14 11:10:57 --> Input Class Initialized
INFO - 2024-12-14 11:10:57 --> Language Class Initialized
INFO - 2024-12-14 11:10:57 --> Language Class Initialized
INFO - 2024-12-14 11:10:57 --> Config Class Initialized
INFO - 2024-12-14 11:10:57 --> Loader Class Initialized
INFO - 2024-12-14 11:10:57 --> Helper loaded: url_helper
INFO - 2024-12-14 11:10:57 --> Helper loaded: file_helper
INFO - 2024-12-14 11:10:57 --> Helper loaded: form_helper
INFO - 2024-12-14 11:10:57 --> Helper loaded: my_helper
INFO - 2024-12-14 11:10:57 --> Database Driver Class Initialized
INFO - 2024-12-14 11:10:57 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-14 11:10:57 --> Controller Class Initialized
DEBUG - 2024-12-14 11:10:57 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/views/cetak_ikm.php
INFO - 2024-12-14 11:10:59 --> Final output sent to browser
DEBUG - 2024-12-14 11:10:59 --> Total execution time: 1.7074
INFO - 2024-12-14 13:40:50 --> Config Class Initialized
INFO - 2024-12-14 13:40:50 --> Hooks Class Initialized
DEBUG - 2024-12-14 13:40:50 --> UTF-8 Support Enabled
INFO - 2024-12-14 13:40:50 --> Utf8 Class Initialized
INFO - 2024-12-14 13:40:50 --> URI Class Initialized
INFO - 2024-12-14 13:40:50 --> Router Class Initialized
INFO - 2024-12-14 13:40:50 --> Output Class Initialized
INFO - 2024-12-14 13:40:50 --> Security Class Initialized
DEBUG - 2024-12-14 13:40:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-14 13:40:50 --> Input Class Initialized
INFO - 2024-12-14 13:40:50 --> Language Class Initialized
INFO - 2024-12-14 13:40:50 --> Language Class Initialized
INFO - 2024-12-14 13:40:50 --> Config Class Initialized
INFO - 2024-12-14 13:40:50 --> Loader Class Initialized
INFO - 2024-12-14 13:40:50 --> Helper loaded: url_helper
INFO - 2024-12-14 13:40:50 --> Helper loaded: file_helper
INFO - 2024-12-14 13:40:50 --> Helper loaded: form_helper
INFO - 2024-12-14 13:40:50 --> Helper loaded: my_helper
INFO - 2024-12-14 13:40:50 --> Database Driver Class Initialized
INFO - 2024-12-14 13:40:50 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-14 13:40:50 --> Controller Class Initialized
DEBUG - 2024-12-14 13:40:50 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/login/views/login.php
DEBUG - 2024-12-14 13:40:50 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-12-14 13:40:50 --> Final output sent to browser
DEBUG - 2024-12-14 13:40:50 --> Total execution time: 0.0515
INFO - 2024-12-14 13:40:56 --> Config Class Initialized
INFO - 2024-12-14 13:40:56 --> Hooks Class Initialized
DEBUG - 2024-12-14 13:40:56 --> UTF-8 Support Enabled
INFO - 2024-12-14 13:40:56 --> Utf8 Class Initialized
INFO - 2024-12-14 13:40:56 --> URI Class Initialized
INFO - 2024-12-14 13:40:56 --> Router Class Initialized
INFO - 2024-12-14 13:40:56 --> Output Class Initialized
INFO - 2024-12-14 13:40:56 --> Security Class Initialized
DEBUG - 2024-12-14 13:40:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-14 13:40:56 --> Input Class Initialized
INFO - 2024-12-14 13:40:56 --> Language Class Initialized
INFO - 2024-12-14 13:40:56 --> Language Class Initialized
INFO - 2024-12-14 13:40:56 --> Config Class Initialized
INFO - 2024-12-14 13:40:56 --> Loader Class Initialized
INFO - 2024-12-14 13:40:56 --> Helper loaded: url_helper
INFO - 2024-12-14 13:40:56 --> Helper loaded: file_helper
INFO - 2024-12-14 13:40:56 --> Helper loaded: form_helper
INFO - 2024-12-14 13:40:56 --> Helper loaded: my_helper
INFO - 2024-12-14 13:40:56 --> Database Driver Class Initialized
INFO - 2024-12-14 13:40:56 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-14 13:40:56 --> Controller Class Initialized
INFO - 2024-12-14 13:40:56 --> Helper loaded: cookie_helper
INFO - 2024-12-14 13:40:56 --> Final output sent to browser
DEBUG - 2024-12-14 13:40:56 --> Total execution time: 0.0416
INFO - 2024-12-14 13:40:56 --> Config Class Initialized
INFO - 2024-12-14 13:40:56 --> Hooks Class Initialized
DEBUG - 2024-12-14 13:40:56 --> UTF-8 Support Enabled
INFO - 2024-12-14 13:40:56 --> Utf8 Class Initialized
INFO - 2024-12-14 13:40:56 --> URI Class Initialized
INFO - 2024-12-14 13:40:56 --> Router Class Initialized
INFO - 2024-12-14 13:40:56 --> Output Class Initialized
INFO - 2024-12-14 13:40:56 --> Security Class Initialized
DEBUG - 2024-12-14 13:40:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-14 13:40:56 --> Input Class Initialized
INFO - 2024-12-14 13:40:56 --> Language Class Initialized
INFO - 2024-12-14 13:40:56 --> Language Class Initialized
INFO - 2024-12-14 13:40:56 --> Config Class Initialized
INFO - 2024-12-14 13:40:56 --> Loader Class Initialized
INFO - 2024-12-14 13:40:56 --> Helper loaded: url_helper
INFO - 2024-12-14 13:40:56 --> Helper loaded: file_helper
INFO - 2024-12-14 13:40:56 --> Helper loaded: form_helper
INFO - 2024-12-14 13:40:56 --> Helper loaded: my_helper
INFO - 2024-12-14 13:40:56 --> Database Driver Class Initialized
INFO - 2024-12-14 13:40:56 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-14 13:40:56 --> Controller Class Initialized
DEBUG - 2024-12-14 13:40:56 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/home/views/v_home.php
DEBUG - 2024-12-14 13:40:56 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-12-14 13:40:56 --> Final output sent to browser
DEBUG - 2024-12-14 13:40:56 --> Total execution time: 0.0539
INFO - 2024-12-14 13:40:59 --> Config Class Initialized
INFO - 2024-12-14 13:40:59 --> Hooks Class Initialized
DEBUG - 2024-12-14 13:40:59 --> UTF-8 Support Enabled
INFO - 2024-12-14 13:40:59 --> Utf8 Class Initialized
INFO - 2024-12-14 13:40:59 --> URI Class Initialized
INFO - 2024-12-14 13:40:59 --> Router Class Initialized
INFO - 2024-12-14 13:40:59 --> Output Class Initialized
INFO - 2024-12-14 13:40:59 --> Security Class Initialized
DEBUG - 2024-12-14 13:40:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-14 13:40:59 --> Input Class Initialized
INFO - 2024-12-14 13:40:59 --> Language Class Initialized
INFO - 2024-12-14 13:40:59 --> Language Class Initialized
INFO - 2024-12-14 13:40:59 --> Config Class Initialized
INFO - 2024-12-14 13:40:59 --> Loader Class Initialized
INFO - 2024-12-14 13:40:59 --> Helper loaded: url_helper
INFO - 2024-12-14 13:40:59 --> Helper loaded: file_helper
INFO - 2024-12-14 13:40:59 --> Helper loaded: form_helper
INFO - 2024-12-14 13:40:59 --> Helper loaded: my_helper
INFO - 2024-12-14 13:40:59 --> Database Driver Class Initialized
INFO - 2024-12-14 13:40:59 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-14 13:40:59 --> Controller Class Initialized
DEBUG - 2024-12-14 13:40:59 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/data_siswa/views/list.php
DEBUG - 2024-12-14 13:40:59 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-12-14 13:40:59 --> Final output sent to browser
DEBUG - 2024-12-14 13:40:59 --> Total execution time: 0.0321
INFO - 2024-12-14 13:40:59 --> Config Class Initialized
INFO - 2024-12-14 13:40:59 --> Hooks Class Initialized
DEBUG - 2024-12-14 13:40:59 --> UTF-8 Support Enabled
INFO - 2024-12-14 13:40:59 --> Utf8 Class Initialized
INFO - 2024-12-14 13:40:59 --> URI Class Initialized
INFO - 2024-12-14 13:40:59 --> Router Class Initialized
INFO - 2024-12-14 13:40:59 --> Output Class Initialized
INFO - 2024-12-14 13:40:59 --> Security Class Initialized
DEBUG - 2024-12-14 13:40:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-14 13:40:59 --> Input Class Initialized
INFO - 2024-12-14 13:40:59 --> Language Class Initialized
ERROR - 2024-12-14 13:40:59 --> 404 Page Not Found: /index
INFO - 2024-12-14 13:41:00 --> Config Class Initialized
INFO - 2024-12-14 13:41:00 --> Hooks Class Initialized
DEBUG - 2024-12-14 13:41:00 --> UTF-8 Support Enabled
INFO - 2024-12-14 13:41:00 --> Utf8 Class Initialized
INFO - 2024-12-14 13:41:00 --> URI Class Initialized
INFO - 2024-12-14 13:41:00 --> Router Class Initialized
INFO - 2024-12-14 13:41:00 --> Output Class Initialized
INFO - 2024-12-14 13:41:00 --> Security Class Initialized
DEBUG - 2024-12-14 13:41:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-14 13:41:00 --> Input Class Initialized
INFO - 2024-12-14 13:41:00 --> Language Class Initialized
INFO - 2024-12-14 13:41:00 --> Language Class Initialized
INFO - 2024-12-14 13:41:00 --> Config Class Initialized
INFO - 2024-12-14 13:41:00 --> Loader Class Initialized
INFO - 2024-12-14 13:41:00 --> Helper loaded: url_helper
INFO - 2024-12-14 13:41:00 --> Helper loaded: file_helper
INFO - 2024-12-14 13:41:00 --> Helper loaded: form_helper
INFO - 2024-12-14 13:41:00 --> Helper loaded: my_helper
INFO - 2024-12-14 13:41:00 --> Database Driver Class Initialized
INFO - 2024-12-14 13:41:00 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-14 13:41:00 --> Controller Class Initialized
INFO - 2024-12-14 13:41:03 --> Config Class Initialized
INFO - 2024-12-14 13:41:03 --> Hooks Class Initialized
DEBUG - 2024-12-14 13:41:03 --> UTF-8 Support Enabled
INFO - 2024-12-14 13:41:03 --> Utf8 Class Initialized
INFO - 2024-12-14 13:41:03 --> URI Class Initialized
INFO - 2024-12-14 13:41:03 --> Router Class Initialized
INFO - 2024-12-14 13:41:03 --> Output Class Initialized
INFO - 2024-12-14 13:41:03 --> Security Class Initialized
DEBUG - 2024-12-14 13:41:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-14 13:41:03 --> Input Class Initialized
INFO - 2024-12-14 13:41:03 --> Language Class Initialized
INFO - 2024-12-14 13:41:03 --> Language Class Initialized
INFO - 2024-12-14 13:41:03 --> Config Class Initialized
INFO - 2024-12-14 13:41:03 --> Loader Class Initialized
INFO - 2024-12-14 13:41:03 --> Helper loaded: url_helper
INFO - 2024-12-14 13:41:03 --> Helper loaded: file_helper
INFO - 2024-12-14 13:41:03 --> Helper loaded: form_helper
INFO - 2024-12-14 13:41:03 --> Helper loaded: my_helper
INFO - 2024-12-14 13:41:03 --> Database Driver Class Initialized
INFO - 2024-12-14 13:41:03 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-14 13:41:03 --> Controller Class Initialized
INFO - 2024-12-14 13:41:59 --> Config Class Initialized
INFO - 2024-12-14 13:41:59 --> Hooks Class Initialized
DEBUG - 2024-12-14 13:41:59 --> UTF-8 Support Enabled
INFO - 2024-12-14 13:41:59 --> Utf8 Class Initialized
INFO - 2024-12-14 13:41:59 --> URI Class Initialized
INFO - 2024-12-14 13:41:59 --> Router Class Initialized
INFO - 2024-12-14 13:41:59 --> Output Class Initialized
INFO - 2024-12-14 13:41:59 --> Security Class Initialized
DEBUG - 2024-12-14 13:41:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-14 13:41:59 --> Input Class Initialized
INFO - 2024-12-14 13:41:59 --> Language Class Initialized
INFO - 2024-12-14 13:41:59 --> Language Class Initialized
INFO - 2024-12-14 13:41:59 --> Config Class Initialized
INFO - 2024-12-14 13:41:59 --> Loader Class Initialized
INFO - 2024-12-14 13:41:59 --> Helper loaded: url_helper
INFO - 2024-12-14 13:41:59 --> Helper loaded: file_helper
INFO - 2024-12-14 13:41:59 --> Helper loaded: form_helper
INFO - 2024-12-14 13:41:59 --> Helper loaded: my_helper
INFO - 2024-12-14 13:41:59 --> Database Driver Class Initialized
INFO - 2024-12-14 13:41:59 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-14 13:41:59 --> Controller Class Initialized
ERROR - 2024-12-14 13:41:59 --> Severity: Notice --> Undefined variable: status_form /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/data_siswa/views/form.php 231
DEBUG - 2024-12-14 13:41:59 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/data_siswa/views/form.php
DEBUG - 2024-12-14 13:41:59 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-12-14 13:41:59 --> Final output sent to browser
DEBUG - 2024-12-14 13:41:59 --> Total execution time: 0.0602
INFO - 2024-12-14 13:42:04 --> Config Class Initialized
INFO - 2024-12-14 13:42:04 --> Hooks Class Initialized
DEBUG - 2024-12-14 13:42:04 --> UTF-8 Support Enabled
INFO - 2024-12-14 13:42:04 --> Utf8 Class Initialized
INFO - 2024-12-14 13:42:04 --> URI Class Initialized
INFO - 2024-12-14 13:42:04 --> Router Class Initialized
INFO - 2024-12-14 13:42:04 --> Output Class Initialized
INFO - 2024-12-14 13:42:04 --> Security Class Initialized
DEBUG - 2024-12-14 13:42:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-14 13:42:04 --> Input Class Initialized
INFO - 2024-12-14 13:42:04 --> Language Class Initialized
INFO - 2024-12-14 13:42:04 --> Language Class Initialized
INFO - 2024-12-14 13:42:04 --> Config Class Initialized
INFO - 2024-12-14 13:42:04 --> Loader Class Initialized
INFO - 2024-12-14 13:42:04 --> Helper loaded: url_helper
INFO - 2024-12-14 13:42:04 --> Helper loaded: file_helper
INFO - 2024-12-14 13:42:04 --> Helper loaded: form_helper
INFO - 2024-12-14 13:42:04 --> Helper loaded: my_helper
INFO - 2024-12-14 13:42:04 --> Database Driver Class Initialized
INFO - 2024-12-14 13:42:04 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-14 13:42:04 --> Controller Class Initialized
INFO - 2024-12-14 13:42:04 --> Upload Class Initialized
INFO - 2024-12-14 13:42:04 --> Language file loaded: language/english/upload_lang.php
ERROR - 2024-12-14 13:42:04 --> The upload path does not appear to be valid.
INFO - 2024-12-14 13:42:04 --> Config Class Initialized
INFO - 2024-12-14 13:42:04 --> Hooks Class Initialized
DEBUG - 2024-12-14 13:42:04 --> UTF-8 Support Enabled
INFO - 2024-12-14 13:42:04 --> Utf8 Class Initialized
INFO - 2024-12-14 13:42:04 --> URI Class Initialized
INFO - 2024-12-14 13:42:04 --> Router Class Initialized
INFO - 2024-12-14 13:42:04 --> Output Class Initialized
INFO - 2024-12-14 13:42:04 --> Security Class Initialized
DEBUG - 2024-12-14 13:42:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-14 13:42:04 --> Input Class Initialized
INFO - 2024-12-14 13:42:04 --> Language Class Initialized
INFO - 2024-12-14 13:42:04 --> Language Class Initialized
INFO - 2024-12-14 13:42:04 --> Config Class Initialized
INFO - 2024-12-14 13:42:04 --> Loader Class Initialized
INFO - 2024-12-14 13:42:04 --> Helper loaded: url_helper
INFO - 2024-12-14 13:42:04 --> Helper loaded: file_helper
INFO - 2024-12-14 13:42:04 --> Helper loaded: form_helper
INFO - 2024-12-14 13:42:04 --> Helper loaded: my_helper
INFO - 2024-12-14 13:42:04 --> Database Driver Class Initialized
INFO - 2024-12-14 13:42:04 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-14 13:42:04 --> Controller Class Initialized
DEBUG - 2024-12-14 13:42:04 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/data_siswa/views/list.php
DEBUG - 2024-12-14 13:42:04 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-12-14 13:42:04 --> Final output sent to browser
DEBUG - 2024-12-14 13:42:04 --> Total execution time: 0.0407
INFO - 2024-12-14 13:42:04 --> Config Class Initialized
INFO - 2024-12-14 13:42:04 --> Hooks Class Initialized
DEBUG - 2024-12-14 13:42:04 --> UTF-8 Support Enabled
INFO - 2024-12-14 13:42:04 --> Utf8 Class Initialized
INFO - 2024-12-14 13:42:04 --> URI Class Initialized
INFO - 2024-12-14 13:42:04 --> Router Class Initialized
INFO - 2024-12-14 13:42:04 --> Output Class Initialized
INFO - 2024-12-14 13:42:04 --> Security Class Initialized
DEBUG - 2024-12-14 13:42:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-14 13:42:04 --> Input Class Initialized
INFO - 2024-12-14 13:42:04 --> Language Class Initialized
ERROR - 2024-12-14 13:42:04 --> 404 Page Not Found: /index
INFO - 2024-12-14 13:42:04 --> Config Class Initialized
INFO - 2024-12-14 13:42:04 --> Hooks Class Initialized
DEBUG - 2024-12-14 13:42:04 --> UTF-8 Support Enabled
INFO - 2024-12-14 13:42:04 --> Utf8 Class Initialized
INFO - 2024-12-14 13:42:04 --> URI Class Initialized
INFO - 2024-12-14 13:42:04 --> Router Class Initialized
INFO - 2024-12-14 13:42:04 --> Output Class Initialized
INFO - 2024-12-14 13:42:04 --> Security Class Initialized
DEBUG - 2024-12-14 13:42:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-14 13:42:04 --> Input Class Initialized
INFO - 2024-12-14 13:42:04 --> Language Class Initialized
INFO - 2024-12-14 13:42:04 --> Language Class Initialized
INFO - 2024-12-14 13:42:04 --> Config Class Initialized
INFO - 2024-12-14 13:42:04 --> Loader Class Initialized
INFO - 2024-12-14 13:42:04 --> Helper loaded: url_helper
INFO - 2024-12-14 13:42:04 --> Helper loaded: file_helper
INFO - 2024-12-14 13:42:04 --> Helper loaded: form_helper
INFO - 2024-12-14 13:42:04 --> Helper loaded: my_helper
INFO - 2024-12-14 13:42:04 --> Database Driver Class Initialized
INFO - 2024-12-14 13:42:04 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-14 13:42:04 --> Controller Class Initialized
INFO - 2024-12-14 13:42:10 --> Config Class Initialized
INFO - 2024-12-14 13:42:10 --> Hooks Class Initialized
DEBUG - 2024-12-14 13:42:10 --> UTF-8 Support Enabled
INFO - 2024-12-14 13:42:10 --> Utf8 Class Initialized
INFO - 2024-12-14 13:42:10 --> URI Class Initialized
INFO - 2024-12-14 13:42:10 --> Router Class Initialized
INFO - 2024-12-14 13:42:10 --> Output Class Initialized
INFO - 2024-12-14 13:42:10 --> Security Class Initialized
DEBUG - 2024-12-14 13:42:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-14 13:42:10 --> Input Class Initialized
INFO - 2024-12-14 13:42:10 --> Language Class Initialized
INFO - 2024-12-14 13:42:10 --> Language Class Initialized
INFO - 2024-12-14 13:42:10 --> Config Class Initialized
INFO - 2024-12-14 13:42:10 --> Loader Class Initialized
INFO - 2024-12-14 13:42:10 --> Helper loaded: url_helper
INFO - 2024-12-14 13:42:10 --> Helper loaded: file_helper
INFO - 2024-12-14 13:42:10 --> Helper loaded: form_helper
INFO - 2024-12-14 13:42:10 --> Helper loaded: my_helper
INFO - 2024-12-14 13:42:10 --> Database Driver Class Initialized
INFO - 2024-12-14 13:42:10 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-14 13:42:10 --> Controller Class Initialized
INFO - 2024-12-14 13:54:38 --> Config Class Initialized
INFO - 2024-12-14 13:54:38 --> Hooks Class Initialized
DEBUG - 2024-12-14 13:54:39 --> UTF-8 Support Enabled
INFO - 2024-12-14 13:54:39 --> Utf8 Class Initialized
INFO - 2024-12-14 13:54:39 --> URI Class Initialized
INFO - 2024-12-14 13:54:39 --> Router Class Initialized
INFO - 2024-12-14 13:54:39 --> Output Class Initialized
INFO - 2024-12-14 13:54:39 --> Security Class Initialized
DEBUG - 2024-12-14 13:54:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-14 13:54:39 --> Input Class Initialized
INFO - 2024-12-14 13:54:39 --> Language Class Initialized
INFO - 2024-12-14 13:54:39 --> Language Class Initialized
INFO - 2024-12-14 13:54:39 --> Config Class Initialized
INFO - 2024-12-14 13:54:39 --> Loader Class Initialized
INFO - 2024-12-14 13:54:39 --> Helper loaded: url_helper
INFO - 2024-12-14 13:54:39 --> Helper loaded: file_helper
INFO - 2024-12-14 13:54:39 --> Helper loaded: form_helper
INFO - 2024-12-14 13:54:39 --> Helper loaded: my_helper
INFO - 2024-12-14 13:54:39 --> Database Driver Class Initialized
INFO - 2024-12-14 13:54:39 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-14 13:54:39 --> Controller Class Initialized
INFO - 2024-12-14 13:54:39 --> Helper loaded: cookie_helper
INFO - 2024-12-14 13:54:39 --> Config Class Initialized
INFO - 2024-12-14 13:54:39 --> Hooks Class Initialized
DEBUG - 2024-12-14 13:54:39 --> UTF-8 Support Enabled
INFO - 2024-12-14 13:54:39 --> Utf8 Class Initialized
INFO - 2024-12-14 13:54:39 --> URI Class Initialized
INFO - 2024-12-14 13:54:39 --> Router Class Initialized
INFO - 2024-12-14 13:54:39 --> Output Class Initialized
INFO - 2024-12-14 13:54:39 --> Security Class Initialized
DEBUG - 2024-12-14 13:54:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-14 13:54:39 --> Input Class Initialized
INFO - 2024-12-14 13:54:39 --> Language Class Initialized
INFO - 2024-12-14 13:54:39 --> Language Class Initialized
INFO - 2024-12-14 13:54:39 --> Config Class Initialized
INFO - 2024-12-14 13:54:39 --> Loader Class Initialized
INFO - 2024-12-14 13:54:39 --> Helper loaded: url_helper
INFO - 2024-12-14 13:54:39 --> Helper loaded: file_helper
INFO - 2024-12-14 13:54:39 --> Helper loaded: form_helper
INFO - 2024-12-14 13:54:39 --> Helper loaded: my_helper
INFO - 2024-12-14 13:54:40 --> Database Driver Class Initialized
INFO - 2024-12-14 13:54:40 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-14 13:54:40 --> Controller Class Initialized
INFO - 2024-12-14 13:54:40 --> Config Class Initialized
INFO - 2024-12-14 13:54:40 --> Hooks Class Initialized
DEBUG - 2024-12-14 13:54:40 --> UTF-8 Support Enabled
INFO - 2024-12-14 13:54:40 --> Utf8 Class Initialized
INFO - 2024-12-14 13:54:40 --> URI Class Initialized
INFO - 2024-12-14 13:54:40 --> Router Class Initialized
INFO - 2024-12-14 13:54:40 --> Output Class Initialized
INFO - 2024-12-14 13:54:40 --> Security Class Initialized
DEBUG - 2024-12-14 13:54:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-14 13:54:40 --> Input Class Initialized
INFO - 2024-12-14 13:54:40 --> Language Class Initialized
INFO - 2024-12-14 13:54:40 --> Language Class Initialized
INFO - 2024-12-14 13:54:40 --> Config Class Initialized
INFO - 2024-12-14 13:54:40 --> Loader Class Initialized
INFO - 2024-12-14 13:54:40 --> Helper loaded: url_helper
INFO - 2024-12-14 13:54:40 --> Helper loaded: file_helper
INFO - 2024-12-14 13:54:40 --> Helper loaded: form_helper
INFO - 2024-12-14 13:54:40 --> Helper loaded: my_helper
INFO - 2024-12-14 13:54:40 --> Database Driver Class Initialized
INFO - 2024-12-14 13:54:40 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-14 13:54:40 --> Controller Class Initialized
DEBUG - 2024-12-14 13:54:40 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/login/views/login.php
DEBUG - 2024-12-14 13:54:40 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-12-14 13:54:40 --> Final output sent to browser
DEBUG - 2024-12-14 13:54:40 --> Total execution time: 0.1017
INFO - 2024-12-14 13:54:48 --> Config Class Initialized
INFO - 2024-12-14 13:54:48 --> Hooks Class Initialized
DEBUG - 2024-12-14 13:54:48 --> UTF-8 Support Enabled
INFO - 2024-12-14 13:54:48 --> Utf8 Class Initialized
INFO - 2024-12-14 13:54:48 --> URI Class Initialized
INFO - 2024-12-14 13:54:48 --> Router Class Initialized
INFO - 2024-12-14 13:54:48 --> Output Class Initialized
INFO - 2024-12-14 13:54:48 --> Security Class Initialized
DEBUG - 2024-12-14 13:54:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-14 13:54:48 --> Input Class Initialized
INFO - 2024-12-14 13:54:48 --> Language Class Initialized
INFO - 2024-12-14 13:54:48 --> Language Class Initialized
INFO - 2024-12-14 13:54:48 --> Config Class Initialized
INFO - 2024-12-14 13:54:48 --> Loader Class Initialized
INFO - 2024-12-14 13:54:48 --> Helper loaded: url_helper
INFO - 2024-12-14 13:54:48 --> Helper loaded: file_helper
INFO - 2024-12-14 13:54:48 --> Helper loaded: form_helper
INFO - 2024-12-14 13:54:48 --> Helper loaded: my_helper
INFO - 2024-12-14 13:54:48 --> Database Driver Class Initialized
INFO - 2024-12-14 13:54:48 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-14 13:54:48 --> Controller Class Initialized
INFO - 2024-12-14 13:54:48 --> Helper loaded: cookie_helper
INFO - 2024-12-14 13:54:48 --> Final output sent to browser
DEBUG - 2024-12-14 13:54:48 --> Total execution time: 0.0440
INFO - 2024-12-14 13:54:49 --> Config Class Initialized
INFO - 2024-12-14 13:54:49 --> Hooks Class Initialized
DEBUG - 2024-12-14 13:54:49 --> UTF-8 Support Enabled
INFO - 2024-12-14 13:54:49 --> Utf8 Class Initialized
INFO - 2024-12-14 13:54:49 --> URI Class Initialized
INFO - 2024-12-14 13:54:49 --> Router Class Initialized
INFO - 2024-12-14 13:54:49 --> Output Class Initialized
INFO - 2024-12-14 13:54:49 --> Security Class Initialized
DEBUG - 2024-12-14 13:54:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-14 13:54:49 --> Input Class Initialized
INFO - 2024-12-14 13:54:49 --> Language Class Initialized
INFO - 2024-12-14 13:54:49 --> Language Class Initialized
INFO - 2024-12-14 13:54:49 --> Config Class Initialized
INFO - 2024-12-14 13:54:49 --> Loader Class Initialized
INFO - 2024-12-14 13:54:49 --> Helper loaded: url_helper
INFO - 2024-12-14 13:54:49 --> Helper loaded: file_helper
INFO - 2024-12-14 13:54:49 --> Helper loaded: form_helper
INFO - 2024-12-14 13:54:49 --> Helper loaded: my_helper
INFO - 2024-12-14 13:54:49 --> Database Driver Class Initialized
INFO - 2024-12-14 13:54:49 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-14 13:54:49 --> Controller Class Initialized
DEBUG - 2024-12-14 13:54:49 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/home/views/v_home_guru.php
DEBUG - 2024-12-14 13:54:49 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-12-14 13:54:49 --> Final output sent to browser
DEBUG - 2024-12-14 13:54:49 --> Total execution time: 0.0581
INFO - 2024-12-14 13:54:51 --> Config Class Initialized
INFO - 2024-12-14 13:54:51 --> Hooks Class Initialized
DEBUG - 2024-12-14 13:54:51 --> UTF-8 Support Enabled
INFO - 2024-12-14 13:54:51 --> Utf8 Class Initialized
INFO - 2024-12-14 13:54:51 --> URI Class Initialized
INFO - 2024-12-14 13:54:51 --> Router Class Initialized
INFO - 2024-12-14 13:54:51 --> Output Class Initialized
INFO - 2024-12-14 13:54:51 --> Security Class Initialized
DEBUG - 2024-12-14 13:54:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-14 13:54:51 --> Input Class Initialized
INFO - 2024-12-14 13:54:51 --> Language Class Initialized
INFO - 2024-12-14 13:54:51 --> Language Class Initialized
INFO - 2024-12-14 13:54:51 --> Config Class Initialized
INFO - 2024-12-14 13:54:51 --> Loader Class Initialized
INFO - 2024-12-14 13:54:51 --> Helper loaded: url_helper
INFO - 2024-12-14 13:54:51 --> Helper loaded: file_helper
INFO - 2024-12-14 13:54:51 --> Helper loaded: form_helper
INFO - 2024-12-14 13:54:51 --> Helper loaded: my_helper
INFO - 2024-12-14 13:54:51 --> Database Driver Class Initialized
INFO - 2024-12-14 13:54:51 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-14 13:54:51 --> Controller Class Initialized
DEBUG - 2024-12-14 13:54:51 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/view_mapel/views/v_view_mapel.php
DEBUG - 2024-12-14 13:54:51 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-12-14 13:54:51 --> Final output sent to browser
DEBUG - 2024-12-14 13:54:51 --> Total execution time: 0.0545
INFO - 2024-12-14 13:58:07 --> Config Class Initialized
INFO - 2024-12-14 13:58:07 --> Hooks Class Initialized
DEBUG - 2024-12-14 13:58:07 --> UTF-8 Support Enabled
INFO - 2024-12-14 13:58:07 --> Utf8 Class Initialized
INFO - 2024-12-14 13:58:07 --> URI Class Initialized
INFO - 2024-12-14 13:58:07 --> Router Class Initialized
INFO - 2024-12-14 13:58:07 --> Output Class Initialized
INFO - 2024-12-14 13:58:07 --> Security Class Initialized
DEBUG - 2024-12-14 13:58:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-14 13:58:07 --> Input Class Initialized
INFO - 2024-12-14 13:58:07 --> Language Class Initialized
INFO - 2024-12-14 13:58:07 --> Language Class Initialized
INFO - 2024-12-14 13:58:07 --> Config Class Initialized
INFO - 2024-12-14 13:58:07 --> Loader Class Initialized
INFO - 2024-12-14 13:58:07 --> Helper loaded: url_helper
INFO - 2024-12-14 13:58:07 --> Helper loaded: file_helper
INFO - 2024-12-14 13:58:07 --> Helper loaded: form_helper
INFO - 2024-12-14 13:58:07 --> Helper loaded: my_helper
INFO - 2024-12-14 13:58:07 --> Database Driver Class Initialized
INFO - 2024-12-14 13:58:07 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-14 13:58:07 --> Controller Class Initialized
DEBUG - 2024-12-14 13:58:07 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/views/list.php
DEBUG - 2024-12-14 13:58:07 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-12-14 13:58:07 --> Final output sent to browser
DEBUG - 2024-12-14 13:58:07 --> Total execution time: 0.0495
INFO - 2024-12-14 13:58:07 --> Config Class Initialized
INFO - 2024-12-14 13:58:07 --> Hooks Class Initialized
DEBUG - 2024-12-14 13:58:07 --> UTF-8 Support Enabled
INFO - 2024-12-14 13:58:07 --> Utf8 Class Initialized
INFO - 2024-12-14 13:58:07 --> URI Class Initialized
INFO - 2024-12-14 13:58:07 --> Router Class Initialized
INFO - 2024-12-14 13:58:07 --> Output Class Initialized
INFO - 2024-12-14 13:58:07 --> Security Class Initialized
DEBUG - 2024-12-14 13:58:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-14 13:58:07 --> Input Class Initialized
INFO - 2024-12-14 13:58:07 --> Language Class Initialized
INFO - 2024-12-14 13:58:07 --> Language Class Initialized
INFO - 2024-12-14 13:58:07 --> Config Class Initialized
INFO - 2024-12-14 13:58:07 --> Loader Class Initialized
INFO - 2024-12-14 13:58:07 --> Helper loaded: url_helper
INFO - 2024-12-14 13:58:07 --> Helper loaded: file_helper
INFO - 2024-12-14 13:58:07 --> Helper loaded: form_helper
INFO - 2024-12-14 13:58:07 --> Helper loaded: my_helper
INFO - 2024-12-14 13:58:07 --> Database Driver Class Initialized
INFO - 2024-12-14 13:58:07 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-14 13:58:07 --> Controller Class Initialized
INFO - 2024-12-14 13:58:09 --> Config Class Initialized
INFO - 2024-12-14 13:58:09 --> Hooks Class Initialized
DEBUG - 2024-12-14 13:58:09 --> UTF-8 Support Enabled
INFO - 2024-12-14 13:58:09 --> Utf8 Class Initialized
INFO - 2024-12-14 13:58:09 --> URI Class Initialized
INFO - 2024-12-14 13:58:09 --> Router Class Initialized
INFO - 2024-12-14 13:58:09 --> Output Class Initialized
INFO - 2024-12-14 13:58:09 --> Security Class Initialized
DEBUG - 2024-12-14 13:58:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-14 13:58:09 --> Input Class Initialized
INFO - 2024-12-14 13:58:09 --> Language Class Initialized
INFO - 2024-12-14 13:58:09 --> Language Class Initialized
INFO - 2024-12-14 13:58:09 --> Config Class Initialized
INFO - 2024-12-14 13:58:09 --> Loader Class Initialized
INFO - 2024-12-14 13:58:09 --> Helper loaded: url_helper
INFO - 2024-12-14 13:58:09 --> Helper loaded: file_helper
INFO - 2024-12-14 13:58:09 --> Helper loaded: form_helper
INFO - 2024-12-14 13:58:09 --> Helper loaded: my_helper
INFO - 2024-12-14 13:58:09 --> Database Driver Class Initialized
INFO - 2024-12-14 13:58:09 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-14 13:58:09 --> Controller Class Initialized
INFO - 2024-12-14 14:12:34 --> Config Class Initialized
INFO - 2024-12-14 14:12:34 --> Hooks Class Initialized
DEBUG - 2024-12-14 14:12:34 --> UTF-8 Support Enabled
INFO - 2024-12-14 14:12:34 --> Utf8 Class Initialized
INFO - 2024-12-14 14:12:34 --> URI Class Initialized
INFO - 2024-12-14 14:12:34 --> Router Class Initialized
INFO - 2024-12-14 14:12:34 --> Output Class Initialized
INFO - 2024-12-14 14:12:34 --> Security Class Initialized
DEBUG - 2024-12-14 14:12:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-14 14:12:34 --> Input Class Initialized
INFO - 2024-12-14 14:12:34 --> Language Class Initialized
INFO - 2024-12-14 14:12:34 --> Language Class Initialized
INFO - 2024-12-14 14:12:34 --> Config Class Initialized
INFO - 2024-12-14 14:12:34 --> Loader Class Initialized
INFO - 2024-12-14 14:12:34 --> Helper loaded: url_helper
INFO - 2024-12-14 14:12:34 --> Helper loaded: file_helper
INFO - 2024-12-14 14:12:34 --> Helper loaded: form_helper
INFO - 2024-12-14 14:12:34 --> Helper loaded: my_helper
INFO - 2024-12-14 14:12:34 --> Database Driver Class Initialized
INFO - 2024-12-14 14:12:34 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-14 14:12:34 --> Controller Class Initialized
DEBUG - 2024-12-14 14:12:34 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/views/form.php
DEBUG - 2024-12-14 14:12:34 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-12-14 14:12:34 --> Final output sent to browser
DEBUG - 2024-12-14 14:12:34 --> Total execution time: 0.0437
INFO - 2024-12-14 14:12:41 --> Config Class Initialized
INFO - 2024-12-14 14:12:41 --> Hooks Class Initialized
DEBUG - 2024-12-14 14:12:41 --> UTF-8 Support Enabled
INFO - 2024-12-14 14:12:41 --> Utf8 Class Initialized
INFO - 2024-12-14 14:12:41 --> URI Class Initialized
INFO - 2024-12-14 14:12:41 --> Router Class Initialized
INFO - 2024-12-14 14:12:41 --> Output Class Initialized
INFO - 2024-12-14 14:12:41 --> Security Class Initialized
DEBUG - 2024-12-14 14:12:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-14 14:12:41 --> Input Class Initialized
INFO - 2024-12-14 14:12:41 --> Language Class Initialized
INFO - 2024-12-14 14:12:41 --> Language Class Initialized
INFO - 2024-12-14 14:12:41 --> Config Class Initialized
INFO - 2024-12-14 14:12:41 --> Loader Class Initialized
INFO - 2024-12-14 14:12:41 --> Helper loaded: url_helper
INFO - 2024-12-14 14:12:41 --> Helper loaded: file_helper
INFO - 2024-12-14 14:12:41 --> Helper loaded: form_helper
INFO - 2024-12-14 14:12:41 --> Helper loaded: my_helper
INFO - 2024-12-14 14:12:41 --> Database Driver Class Initialized
INFO - 2024-12-14 14:12:41 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-14 14:12:41 --> Controller Class Initialized
INFO - 2024-12-14 14:12:41 --> Config Class Initialized
INFO - 2024-12-14 14:12:41 --> Hooks Class Initialized
DEBUG - 2024-12-14 14:12:41 --> UTF-8 Support Enabled
INFO - 2024-12-14 14:12:41 --> Utf8 Class Initialized
INFO - 2024-12-14 14:12:41 --> URI Class Initialized
INFO - 2024-12-14 14:12:41 --> Router Class Initialized
INFO - 2024-12-14 14:12:41 --> Output Class Initialized
INFO - 2024-12-14 14:12:41 --> Security Class Initialized
DEBUG - 2024-12-14 14:12:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-14 14:12:41 --> Input Class Initialized
INFO - 2024-12-14 14:12:41 --> Language Class Initialized
INFO - 2024-12-14 14:12:41 --> Language Class Initialized
INFO - 2024-12-14 14:12:41 --> Config Class Initialized
INFO - 2024-12-14 14:12:41 --> Loader Class Initialized
INFO - 2024-12-14 14:12:41 --> Helper loaded: url_helper
INFO - 2024-12-14 14:12:41 --> Helper loaded: file_helper
INFO - 2024-12-14 14:12:41 --> Helper loaded: form_helper
INFO - 2024-12-14 14:12:41 --> Helper loaded: my_helper
INFO - 2024-12-14 14:12:41 --> Database Driver Class Initialized
INFO - 2024-12-14 14:12:41 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-14 14:12:41 --> Controller Class Initialized
DEBUG - 2024-12-14 14:12:41 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/views/list.php
DEBUG - 2024-12-14 14:12:41 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-12-14 14:12:41 --> Final output sent to browser
DEBUG - 2024-12-14 14:12:41 --> Total execution time: 0.0315
INFO - 2024-12-14 14:12:41 --> Config Class Initialized
INFO - 2024-12-14 14:12:41 --> Hooks Class Initialized
DEBUG - 2024-12-14 14:12:41 --> UTF-8 Support Enabled
INFO - 2024-12-14 14:12:41 --> Utf8 Class Initialized
INFO - 2024-12-14 14:12:41 --> URI Class Initialized
INFO - 2024-12-14 14:12:41 --> Router Class Initialized
INFO - 2024-12-14 14:12:41 --> Output Class Initialized
INFO - 2024-12-14 14:12:41 --> Security Class Initialized
DEBUG - 2024-12-14 14:12:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-14 14:12:41 --> Input Class Initialized
INFO - 2024-12-14 14:12:41 --> Language Class Initialized
INFO - 2024-12-14 14:12:41 --> Language Class Initialized
INFO - 2024-12-14 14:12:41 --> Config Class Initialized
INFO - 2024-12-14 14:12:41 --> Loader Class Initialized
INFO - 2024-12-14 14:12:41 --> Helper loaded: url_helper
INFO - 2024-12-14 14:12:41 --> Helper loaded: file_helper
INFO - 2024-12-14 14:12:41 --> Helper loaded: form_helper
INFO - 2024-12-14 14:12:41 --> Helper loaded: my_helper
INFO - 2024-12-14 14:12:41 --> Database Driver Class Initialized
INFO - 2024-12-14 14:12:41 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-14 14:12:41 --> Controller Class Initialized
INFO - 2024-12-14 14:12:45 --> Config Class Initialized
INFO - 2024-12-14 14:12:45 --> Hooks Class Initialized
DEBUG - 2024-12-14 14:12:45 --> UTF-8 Support Enabled
INFO - 2024-12-14 14:12:45 --> Utf8 Class Initialized
INFO - 2024-12-14 14:12:45 --> URI Class Initialized
INFO - 2024-12-14 14:12:45 --> Router Class Initialized
INFO - 2024-12-14 14:12:45 --> Output Class Initialized
INFO - 2024-12-14 14:12:45 --> Security Class Initialized
DEBUG - 2024-12-14 14:12:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-14 14:12:45 --> Input Class Initialized
INFO - 2024-12-14 14:12:45 --> Language Class Initialized
INFO - 2024-12-14 14:12:45 --> Language Class Initialized
INFO - 2024-12-14 14:12:45 --> Config Class Initialized
INFO - 2024-12-14 14:12:45 --> Loader Class Initialized
INFO - 2024-12-14 14:12:45 --> Helper loaded: url_helper
INFO - 2024-12-14 14:12:45 --> Helper loaded: file_helper
INFO - 2024-12-14 14:12:45 --> Helper loaded: form_helper
INFO - 2024-12-14 14:12:45 --> Helper loaded: my_helper
INFO - 2024-12-14 14:12:45 --> Database Driver Class Initialized
INFO - 2024-12-14 14:12:45 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-14 14:12:45 --> Controller Class Initialized
INFO - 2024-12-14 14:12:45 --> Final output sent to browser
DEBUG - 2024-12-14 14:12:45 --> Total execution time: 0.0529
INFO - 2024-12-14 14:12:52 --> Config Class Initialized
INFO - 2024-12-14 14:12:52 --> Hooks Class Initialized
DEBUG - 2024-12-14 14:12:52 --> UTF-8 Support Enabled
INFO - 2024-12-14 14:12:52 --> Utf8 Class Initialized
INFO - 2024-12-14 14:12:52 --> URI Class Initialized
INFO - 2024-12-14 14:12:52 --> Router Class Initialized
INFO - 2024-12-14 14:12:52 --> Output Class Initialized
INFO - 2024-12-14 14:12:52 --> Security Class Initialized
DEBUG - 2024-12-14 14:12:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-14 14:12:52 --> Input Class Initialized
INFO - 2024-12-14 14:12:52 --> Language Class Initialized
INFO - 2024-12-14 14:12:52 --> Language Class Initialized
INFO - 2024-12-14 14:12:52 --> Config Class Initialized
INFO - 2024-12-14 14:12:52 --> Loader Class Initialized
INFO - 2024-12-14 14:12:52 --> Helper loaded: url_helper
INFO - 2024-12-14 14:12:52 --> Helper loaded: file_helper
INFO - 2024-12-14 14:12:52 --> Helper loaded: form_helper
INFO - 2024-12-14 14:12:52 --> Helper loaded: my_helper
INFO - 2024-12-14 14:12:52 --> Database Driver Class Initialized
INFO - 2024-12-14 14:12:52 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-14 14:12:52 --> Controller Class Initialized
INFO - 2024-12-14 14:12:52 --> Final output sent to browser
DEBUG - 2024-12-14 14:12:52 --> Total execution time: 0.0498
INFO - 2024-12-14 14:13:18 --> Config Class Initialized
INFO - 2024-12-14 14:13:18 --> Hooks Class Initialized
DEBUG - 2024-12-14 14:13:18 --> UTF-8 Support Enabled
INFO - 2024-12-14 14:13:18 --> Utf8 Class Initialized
INFO - 2024-12-14 14:13:18 --> URI Class Initialized
INFO - 2024-12-14 14:13:18 --> Router Class Initialized
INFO - 2024-12-14 14:13:18 --> Output Class Initialized
INFO - 2024-12-14 14:13:18 --> Security Class Initialized
DEBUG - 2024-12-14 14:13:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-14 14:13:18 --> Input Class Initialized
INFO - 2024-12-14 14:13:18 --> Language Class Initialized
INFO - 2024-12-14 14:13:18 --> Language Class Initialized
INFO - 2024-12-14 14:13:18 --> Config Class Initialized
INFO - 2024-12-14 14:13:18 --> Loader Class Initialized
INFO - 2024-12-14 14:13:18 --> Helper loaded: url_helper
INFO - 2024-12-14 14:13:18 --> Helper loaded: file_helper
INFO - 2024-12-14 14:13:18 --> Helper loaded: form_helper
INFO - 2024-12-14 14:13:18 --> Helper loaded: my_helper
INFO - 2024-12-14 14:13:18 --> Database Driver Class Initialized
INFO - 2024-12-14 14:13:18 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-14 14:13:18 --> Controller Class Initialized
INFO - 2024-12-14 14:13:18 --> Helper loaded: cookie_helper
INFO - 2024-12-14 14:13:18 --> Config Class Initialized
INFO - 2024-12-14 14:13:18 --> Hooks Class Initialized
DEBUG - 2024-12-14 14:13:18 --> UTF-8 Support Enabled
INFO - 2024-12-14 14:13:18 --> Utf8 Class Initialized
INFO - 2024-12-14 14:13:18 --> URI Class Initialized
INFO - 2024-12-14 14:13:18 --> Router Class Initialized
INFO - 2024-12-14 14:13:18 --> Output Class Initialized
INFO - 2024-12-14 14:13:18 --> Security Class Initialized
DEBUG - 2024-12-14 14:13:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-14 14:13:18 --> Input Class Initialized
INFO - 2024-12-14 14:13:18 --> Language Class Initialized
INFO - 2024-12-14 14:13:18 --> Language Class Initialized
INFO - 2024-12-14 14:13:18 --> Config Class Initialized
INFO - 2024-12-14 14:13:18 --> Loader Class Initialized
INFO - 2024-12-14 14:13:18 --> Helper loaded: url_helper
INFO - 2024-12-14 14:13:18 --> Helper loaded: file_helper
INFO - 2024-12-14 14:13:18 --> Helper loaded: form_helper
INFO - 2024-12-14 14:13:18 --> Helper loaded: my_helper
INFO - 2024-12-14 14:13:18 --> Database Driver Class Initialized
INFO - 2024-12-14 14:13:18 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-14 14:13:18 --> Controller Class Initialized
INFO - 2024-12-14 14:13:18 --> Config Class Initialized
INFO - 2024-12-14 14:13:18 --> Hooks Class Initialized
DEBUG - 2024-12-14 14:13:18 --> UTF-8 Support Enabled
INFO - 2024-12-14 14:13:18 --> Utf8 Class Initialized
INFO - 2024-12-14 14:13:18 --> URI Class Initialized
INFO - 2024-12-14 14:13:18 --> Router Class Initialized
INFO - 2024-12-14 14:13:18 --> Output Class Initialized
INFO - 2024-12-14 14:13:18 --> Security Class Initialized
DEBUG - 2024-12-14 14:13:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-14 14:13:18 --> Input Class Initialized
INFO - 2024-12-14 14:13:18 --> Language Class Initialized
INFO - 2024-12-14 14:13:18 --> Language Class Initialized
INFO - 2024-12-14 14:13:18 --> Config Class Initialized
INFO - 2024-12-14 14:13:18 --> Loader Class Initialized
INFO - 2024-12-14 14:13:18 --> Helper loaded: url_helper
INFO - 2024-12-14 14:13:18 --> Helper loaded: file_helper
INFO - 2024-12-14 14:13:18 --> Helper loaded: form_helper
INFO - 2024-12-14 14:13:18 --> Helper loaded: my_helper
INFO - 2024-12-14 14:13:18 --> Database Driver Class Initialized
INFO - 2024-12-14 14:13:18 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-14 14:13:18 --> Controller Class Initialized
DEBUG - 2024-12-14 14:13:18 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/login/views/login.php
DEBUG - 2024-12-14 14:13:18 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-12-14 14:13:18 --> Final output sent to browser
DEBUG - 2024-12-14 14:13:18 --> Total execution time: 0.0288
INFO - 2024-12-14 14:13:26 --> Config Class Initialized
INFO - 2024-12-14 14:13:26 --> Hooks Class Initialized
DEBUG - 2024-12-14 14:13:26 --> UTF-8 Support Enabled
INFO - 2024-12-14 14:13:26 --> Utf8 Class Initialized
INFO - 2024-12-14 14:13:26 --> URI Class Initialized
INFO - 2024-12-14 14:13:26 --> Router Class Initialized
INFO - 2024-12-14 14:13:26 --> Output Class Initialized
INFO - 2024-12-14 14:13:26 --> Security Class Initialized
DEBUG - 2024-12-14 14:13:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-14 14:13:26 --> Input Class Initialized
INFO - 2024-12-14 14:13:26 --> Language Class Initialized
INFO - 2024-12-14 14:13:26 --> Language Class Initialized
INFO - 2024-12-14 14:13:26 --> Config Class Initialized
INFO - 2024-12-14 14:13:26 --> Loader Class Initialized
INFO - 2024-12-14 14:13:26 --> Helper loaded: url_helper
INFO - 2024-12-14 14:13:26 --> Helper loaded: file_helper
INFO - 2024-12-14 14:13:26 --> Helper loaded: form_helper
INFO - 2024-12-14 14:13:26 --> Helper loaded: my_helper
INFO - 2024-12-14 14:13:26 --> Database Driver Class Initialized
INFO - 2024-12-14 14:13:26 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-14 14:13:26 --> Controller Class Initialized
INFO - 2024-12-14 14:13:26 --> Helper loaded: cookie_helper
INFO - 2024-12-14 14:13:26 --> Final output sent to browser
DEBUG - 2024-12-14 14:13:26 --> Total execution time: 0.0366
INFO - 2024-12-14 14:13:26 --> Config Class Initialized
INFO - 2024-12-14 14:13:26 --> Hooks Class Initialized
DEBUG - 2024-12-14 14:13:26 --> UTF-8 Support Enabled
INFO - 2024-12-14 14:13:26 --> Utf8 Class Initialized
INFO - 2024-12-14 14:13:26 --> URI Class Initialized
INFO - 2024-12-14 14:13:26 --> Router Class Initialized
INFO - 2024-12-14 14:13:26 --> Output Class Initialized
INFO - 2024-12-14 14:13:26 --> Security Class Initialized
DEBUG - 2024-12-14 14:13:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-14 14:13:26 --> Input Class Initialized
INFO - 2024-12-14 14:13:26 --> Language Class Initialized
INFO - 2024-12-14 14:13:26 --> Language Class Initialized
INFO - 2024-12-14 14:13:26 --> Config Class Initialized
INFO - 2024-12-14 14:13:26 --> Loader Class Initialized
INFO - 2024-12-14 14:13:26 --> Helper loaded: url_helper
INFO - 2024-12-14 14:13:26 --> Helper loaded: file_helper
INFO - 2024-12-14 14:13:26 --> Helper loaded: form_helper
INFO - 2024-12-14 14:13:26 --> Helper loaded: my_helper
INFO - 2024-12-14 14:13:26 --> Database Driver Class Initialized
INFO - 2024-12-14 14:13:26 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-14 14:13:26 --> Controller Class Initialized
DEBUG - 2024-12-14 14:13:26 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/home/views/v_home_guru.php
DEBUG - 2024-12-14 14:13:26 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-12-14 14:13:26 --> Final output sent to browser
DEBUG - 2024-12-14 14:13:26 --> Total execution time: 0.0333
INFO - 2024-12-14 14:13:31 --> Config Class Initialized
INFO - 2024-12-14 14:13:31 --> Hooks Class Initialized
DEBUG - 2024-12-14 14:13:31 --> UTF-8 Support Enabled
INFO - 2024-12-14 14:13:31 --> Utf8 Class Initialized
INFO - 2024-12-14 14:13:31 --> URI Class Initialized
INFO - 2024-12-14 14:13:31 --> Router Class Initialized
INFO - 2024-12-14 14:13:31 --> Output Class Initialized
INFO - 2024-12-14 14:13:31 --> Security Class Initialized
DEBUG - 2024-12-14 14:13:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-14 14:13:31 --> Input Class Initialized
INFO - 2024-12-14 14:13:31 --> Language Class Initialized
INFO - 2024-12-14 14:13:31 --> Language Class Initialized
INFO - 2024-12-14 14:13:31 --> Config Class Initialized
INFO - 2024-12-14 14:13:31 --> Loader Class Initialized
INFO - 2024-12-14 14:13:31 --> Helper loaded: url_helper
INFO - 2024-12-14 14:13:31 --> Helper loaded: file_helper
INFO - 2024-12-14 14:13:31 --> Helper loaded: form_helper
INFO - 2024-12-14 14:13:31 --> Helper loaded: my_helper
INFO - 2024-12-14 14:13:31 --> Database Driver Class Initialized
INFO - 2024-12-14 14:13:31 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-14 14:13:31 --> Controller Class Initialized
DEBUG - 2024-12-14 14:13:31 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/views/list.php
DEBUG - 2024-12-14 14:13:31 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-12-14 14:13:31 --> Final output sent to browser
DEBUG - 2024-12-14 14:13:31 --> Total execution time: 0.0414
INFO - 2024-12-14 14:13:34 --> Config Class Initialized
INFO - 2024-12-14 14:13:34 --> Hooks Class Initialized
DEBUG - 2024-12-14 14:13:34 --> UTF-8 Support Enabled
INFO - 2024-12-14 14:13:34 --> Utf8 Class Initialized
INFO - 2024-12-14 14:13:34 --> URI Class Initialized
INFO - 2024-12-14 14:13:34 --> Router Class Initialized
INFO - 2024-12-14 14:13:34 --> Output Class Initialized
INFO - 2024-12-14 14:13:34 --> Security Class Initialized
DEBUG - 2024-12-14 14:13:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-14 14:13:34 --> Input Class Initialized
INFO - 2024-12-14 14:13:34 --> Language Class Initialized
INFO - 2024-12-14 14:13:35 --> Language Class Initialized
INFO - 2024-12-14 14:13:35 --> Config Class Initialized
INFO - 2024-12-14 14:13:35 --> Loader Class Initialized
INFO - 2024-12-14 14:13:35 --> Helper loaded: url_helper
INFO - 2024-12-14 14:13:35 --> Helper loaded: file_helper
INFO - 2024-12-14 14:13:35 --> Helper loaded: form_helper
INFO - 2024-12-14 14:13:35 --> Helper loaded: my_helper
INFO - 2024-12-14 14:13:35 --> Database Driver Class Initialized
INFO - 2024-12-14 14:13:35 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-14 14:13:35 --> Controller Class Initialized
DEBUG - 2024-12-14 14:13:35 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/views/cetak_ikm.php
INFO - 2024-12-14 14:13:37 --> Final output sent to browser
DEBUG - 2024-12-14 14:13:37 --> Total execution time: 2.0201
INFO - 2024-12-14 15:30:00 --> Config Class Initialized
INFO - 2024-12-14 15:30:00 --> Hooks Class Initialized
DEBUG - 2024-12-14 15:30:00 --> UTF-8 Support Enabled
INFO - 2024-12-14 15:30:00 --> Utf8 Class Initialized
INFO - 2024-12-14 15:30:00 --> URI Class Initialized
INFO - 2024-12-14 15:30:00 --> Router Class Initialized
INFO - 2024-12-14 15:30:00 --> Output Class Initialized
INFO - 2024-12-14 15:30:00 --> Security Class Initialized
DEBUG - 2024-12-14 15:30:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-14 15:30:00 --> Input Class Initialized
INFO - 2024-12-14 15:30:00 --> Language Class Initialized
INFO - 2024-12-14 15:30:00 --> Language Class Initialized
INFO - 2024-12-14 15:30:00 --> Config Class Initialized
INFO - 2024-12-14 15:30:00 --> Loader Class Initialized
INFO - 2024-12-14 15:30:00 --> Helper loaded: url_helper
INFO - 2024-12-14 15:30:00 --> Helper loaded: file_helper
INFO - 2024-12-14 15:30:00 --> Helper loaded: form_helper
INFO - 2024-12-14 15:30:00 --> Helper loaded: my_helper
INFO - 2024-12-14 15:30:00 --> Database Driver Class Initialized
INFO - 2024-12-14 15:30:00 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-14 15:30:00 --> Controller Class Initialized
DEBUG - 2024-12-14 15:30:00 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/login/views/login.php
DEBUG - 2024-12-14 15:30:00 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-12-14 15:30:00 --> Final output sent to browser
DEBUG - 2024-12-14 15:30:00 --> Total execution time: 0.0631
INFO - 2024-12-14 15:30:16 --> Config Class Initialized
INFO - 2024-12-14 15:30:16 --> Hooks Class Initialized
DEBUG - 2024-12-14 15:30:16 --> UTF-8 Support Enabled
INFO - 2024-12-14 15:30:16 --> Utf8 Class Initialized
INFO - 2024-12-14 15:30:16 --> URI Class Initialized
INFO - 2024-12-14 15:30:16 --> Router Class Initialized
INFO - 2024-12-14 15:30:16 --> Output Class Initialized
INFO - 2024-12-14 15:30:16 --> Security Class Initialized
DEBUG - 2024-12-14 15:30:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-14 15:30:16 --> Input Class Initialized
INFO - 2024-12-14 15:30:16 --> Language Class Initialized
INFO - 2024-12-14 15:30:16 --> Language Class Initialized
INFO - 2024-12-14 15:30:16 --> Config Class Initialized
INFO - 2024-12-14 15:30:16 --> Loader Class Initialized
INFO - 2024-12-14 15:30:16 --> Helper loaded: url_helper
INFO - 2024-12-14 15:30:16 --> Helper loaded: file_helper
INFO - 2024-12-14 15:30:16 --> Helper loaded: form_helper
INFO - 2024-12-14 15:30:16 --> Helper loaded: my_helper
INFO - 2024-12-14 15:30:16 --> Database Driver Class Initialized
INFO - 2024-12-14 15:30:16 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-14 15:30:16 --> Controller Class Initialized
INFO - 2024-12-14 15:30:16 --> Helper loaded: cookie_helper
INFO - 2024-12-14 15:30:16 --> Final output sent to browser
DEBUG - 2024-12-14 15:30:16 --> Total execution time: 0.1261
INFO - 2024-12-14 15:30:16 --> Config Class Initialized
INFO - 2024-12-14 15:30:16 --> Hooks Class Initialized
DEBUG - 2024-12-14 15:30:16 --> UTF-8 Support Enabled
INFO - 2024-12-14 15:30:16 --> Utf8 Class Initialized
INFO - 2024-12-14 15:30:16 --> URI Class Initialized
INFO - 2024-12-14 15:30:16 --> Router Class Initialized
INFO - 2024-12-14 15:30:16 --> Output Class Initialized
INFO - 2024-12-14 15:30:16 --> Security Class Initialized
DEBUG - 2024-12-14 15:30:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-14 15:30:16 --> Input Class Initialized
INFO - 2024-12-14 15:30:16 --> Language Class Initialized
INFO - 2024-12-14 15:30:16 --> Language Class Initialized
INFO - 2024-12-14 15:30:16 --> Config Class Initialized
INFO - 2024-12-14 15:30:16 --> Loader Class Initialized
INFO - 2024-12-14 15:30:16 --> Helper loaded: url_helper
INFO - 2024-12-14 15:30:16 --> Helper loaded: file_helper
INFO - 2024-12-14 15:30:16 --> Helper loaded: form_helper
INFO - 2024-12-14 15:30:16 --> Helper loaded: my_helper
INFO - 2024-12-14 15:30:16 --> Database Driver Class Initialized
INFO - 2024-12-14 15:30:16 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-14 15:30:16 --> Controller Class Initialized
DEBUG - 2024-12-14 15:30:16 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/home/views/v_home.php
DEBUG - 2024-12-14 15:30:16 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-12-14 15:30:16 --> Final output sent to browser
DEBUG - 2024-12-14 15:30:16 --> Total execution time: 0.0306
INFO - 2024-12-14 15:30:19 --> Config Class Initialized
INFO - 2024-12-14 15:30:19 --> Hooks Class Initialized
DEBUG - 2024-12-14 15:30:19 --> UTF-8 Support Enabled
INFO - 2024-12-14 15:30:19 --> Utf8 Class Initialized
INFO - 2024-12-14 15:30:19 --> URI Class Initialized
INFO - 2024-12-14 15:30:19 --> Router Class Initialized
INFO - 2024-12-14 15:30:19 --> Output Class Initialized
INFO - 2024-12-14 15:30:19 --> Security Class Initialized
DEBUG - 2024-12-14 15:30:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-14 15:30:19 --> Input Class Initialized
INFO - 2024-12-14 15:30:19 --> Language Class Initialized
INFO - 2024-12-14 15:30:19 --> Language Class Initialized
INFO - 2024-12-14 15:30:19 --> Config Class Initialized
INFO - 2024-12-14 15:30:19 --> Loader Class Initialized
INFO - 2024-12-14 15:30:19 --> Helper loaded: url_helper
INFO - 2024-12-14 15:30:19 --> Helper loaded: file_helper
INFO - 2024-12-14 15:30:19 --> Helper loaded: form_helper
INFO - 2024-12-14 15:30:19 --> Helper loaded: my_helper
INFO - 2024-12-14 15:30:19 --> Database Driver Class Initialized
INFO - 2024-12-14 15:30:19 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-14 15:30:19 --> Controller Class Initialized
DEBUG - 2024-12-14 15:30:19 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/data_siswa/views/list.php
DEBUG - 2024-12-14 15:30:19 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-12-14 15:30:19 --> Final output sent to browser
DEBUG - 2024-12-14 15:30:19 --> Total execution time: 0.0284
INFO - 2024-12-14 15:30:19 --> Config Class Initialized
INFO - 2024-12-14 15:30:19 --> Hooks Class Initialized
DEBUG - 2024-12-14 15:30:19 --> UTF-8 Support Enabled
INFO - 2024-12-14 15:30:19 --> Utf8 Class Initialized
INFO - 2024-12-14 15:30:19 --> URI Class Initialized
INFO - 2024-12-14 15:30:19 --> Router Class Initialized
INFO - 2024-12-14 15:30:19 --> Output Class Initialized
INFO - 2024-12-14 15:30:19 --> Security Class Initialized
DEBUG - 2024-12-14 15:30:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-14 15:30:19 --> Input Class Initialized
INFO - 2024-12-14 15:30:19 --> Language Class Initialized
ERROR - 2024-12-14 15:30:19 --> 404 Page Not Found: /index
INFO - 2024-12-14 15:30:19 --> Config Class Initialized
INFO - 2024-12-14 15:30:19 --> Hooks Class Initialized
DEBUG - 2024-12-14 15:30:19 --> UTF-8 Support Enabled
INFO - 2024-12-14 15:30:19 --> Utf8 Class Initialized
INFO - 2024-12-14 15:30:19 --> URI Class Initialized
INFO - 2024-12-14 15:30:19 --> Router Class Initialized
INFO - 2024-12-14 15:30:19 --> Output Class Initialized
INFO - 2024-12-14 15:30:19 --> Security Class Initialized
DEBUG - 2024-12-14 15:30:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-14 15:30:19 --> Input Class Initialized
INFO - 2024-12-14 15:30:19 --> Language Class Initialized
INFO - 2024-12-14 15:30:19 --> Language Class Initialized
INFO - 2024-12-14 15:30:19 --> Config Class Initialized
INFO - 2024-12-14 15:30:19 --> Loader Class Initialized
INFO - 2024-12-14 15:30:19 --> Helper loaded: url_helper
INFO - 2024-12-14 15:30:19 --> Helper loaded: file_helper
INFO - 2024-12-14 15:30:19 --> Helper loaded: form_helper
INFO - 2024-12-14 15:30:19 --> Helper loaded: my_helper
INFO - 2024-12-14 15:30:19 --> Database Driver Class Initialized
INFO - 2024-12-14 15:30:19 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-14 15:30:19 --> Controller Class Initialized
INFO - 2024-12-14 15:30:26 --> Config Class Initialized
INFO - 2024-12-14 15:30:26 --> Hooks Class Initialized
DEBUG - 2024-12-14 15:30:26 --> UTF-8 Support Enabled
INFO - 2024-12-14 15:30:26 --> Utf8 Class Initialized
INFO - 2024-12-14 15:30:26 --> URI Class Initialized
INFO - 2024-12-14 15:30:26 --> Router Class Initialized
INFO - 2024-12-14 15:30:26 --> Output Class Initialized
INFO - 2024-12-14 15:30:26 --> Security Class Initialized
DEBUG - 2024-12-14 15:30:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-14 15:30:26 --> Input Class Initialized
INFO - 2024-12-14 15:30:26 --> Language Class Initialized
INFO - 2024-12-14 15:30:26 --> Language Class Initialized
INFO - 2024-12-14 15:30:26 --> Config Class Initialized
INFO - 2024-12-14 15:30:26 --> Loader Class Initialized
INFO - 2024-12-14 15:30:26 --> Helper loaded: url_helper
INFO - 2024-12-14 15:30:26 --> Helper loaded: file_helper
INFO - 2024-12-14 15:30:26 --> Helper loaded: form_helper
INFO - 2024-12-14 15:30:26 --> Helper loaded: my_helper
INFO - 2024-12-14 15:30:26 --> Database Driver Class Initialized
INFO - 2024-12-14 15:30:26 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-14 15:30:26 --> Controller Class Initialized
INFO - 2024-12-14 15:30:27 --> Config Class Initialized
INFO - 2024-12-14 15:30:27 --> Hooks Class Initialized
DEBUG - 2024-12-14 15:30:27 --> UTF-8 Support Enabled
INFO - 2024-12-14 15:30:27 --> Utf8 Class Initialized
INFO - 2024-12-14 15:30:27 --> URI Class Initialized
INFO - 2024-12-14 15:30:27 --> Router Class Initialized
INFO - 2024-12-14 15:30:27 --> Output Class Initialized
INFO - 2024-12-14 15:30:27 --> Security Class Initialized
DEBUG - 2024-12-14 15:30:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-14 15:30:27 --> Input Class Initialized
INFO - 2024-12-14 15:30:27 --> Language Class Initialized
INFO - 2024-12-14 15:30:27 --> Language Class Initialized
INFO - 2024-12-14 15:30:27 --> Config Class Initialized
INFO - 2024-12-14 15:30:27 --> Loader Class Initialized
INFO - 2024-12-14 15:30:27 --> Helper loaded: url_helper
INFO - 2024-12-14 15:30:27 --> Helper loaded: file_helper
INFO - 2024-12-14 15:30:27 --> Helper loaded: form_helper
INFO - 2024-12-14 15:30:27 --> Helper loaded: my_helper
INFO - 2024-12-14 15:30:27 --> Database Driver Class Initialized
INFO - 2024-12-14 15:30:27 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-14 15:30:27 --> Controller Class Initialized
INFO - 2024-12-14 15:30:27 --> Config Class Initialized
INFO - 2024-12-14 15:30:27 --> Hooks Class Initialized
DEBUG - 2024-12-14 15:30:27 --> UTF-8 Support Enabled
INFO - 2024-12-14 15:30:27 --> Utf8 Class Initialized
INFO - 2024-12-14 15:30:27 --> URI Class Initialized
INFO - 2024-12-14 15:30:27 --> Router Class Initialized
INFO - 2024-12-14 15:30:27 --> Output Class Initialized
INFO - 2024-12-14 15:30:27 --> Security Class Initialized
DEBUG - 2024-12-14 15:30:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-14 15:30:27 --> Input Class Initialized
INFO - 2024-12-14 15:30:27 --> Language Class Initialized
INFO - 2024-12-14 15:30:27 --> Language Class Initialized
INFO - 2024-12-14 15:30:27 --> Config Class Initialized
INFO - 2024-12-14 15:30:27 --> Loader Class Initialized
INFO - 2024-12-14 15:30:27 --> Helper loaded: url_helper
INFO - 2024-12-14 15:30:27 --> Helper loaded: file_helper
INFO - 2024-12-14 15:30:27 --> Helper loaded: form_helper
INFO - 2024-12-14 15:30:27 --> Helper loaded: my_helper
INFO - 2024-12-14 15:30:27 --> Database Driver Class Initialized
INFO - 2024-12-14 15:30:27 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-14 15:30:27 --> Controller Class Initialized
INFO - 2024-12-14 15:30:29 --> Config Class Initialized
INFO - 2024-12-14 15:30:29 --> Hooks Class Initialized
DEBUG - 2024-12-14 15:30:29 --> UTF-8 Support Enabled
INFO - 2024-12-14 15:30:29 --> Utf8 Class Initialized
INFO - 2024-12-14 15:30:29 --> URI Class Initialized
INFO - 2024-12-14 15:30:29 --> Router Class Initialized
INFO - 2024-12-14 15:30:29 --> Output Class Initialized
INFO - 2024-12-14 15:30:29 --> Security Class Initialized
DEBUG - 2024-12-14 15:30:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-14 15:30:29 --> Input Class Initialized
INFO - 2024-12-14 15:30:29 --> Language Class Initialized
INFO - 2024-12-14 15:30:29 --> Language Class Initialized
INFO - 2024-12-14 15:30:29 --> Config Class Initialized
INFO - 2024-12-14 15:30:29 --> Loader Class Initialized
INFO - 2024-12-14 15:30:29 --> Helper loaded: url_helper
INFO - 2024-12-14 15:30:29 --> Helper loaded: file_helper
INFO - 2024-12-14 15:30:29 --> Helper loaded: form_helper
INFO - 2024-12-14 15:30:29 --> Helper loaded: my_helper
INFO - 2024-12-14 15:30:29 --> Database Driver Class Initialized
INFO - 2024-12-14 15:30:29 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-14 15:30:29 --> Controller Class Initialized
INFO - 2024-12-14 15:30:30 --> Config Class Initialized
INFO - 2024-12-14 15:30:30 --> Hooks Class Initialized
DEBUG - 2024-12-14 15:30:30 --> UTF-8 Support Enabled
INFO - 2024-12-14 15:30:30 --> Utf8 Class Initialized
INFO - 2024-12-14 15:30:30 --> URI Class Initialized
INFO - 2024-12-14 15:30:30 --> Router Class Initialized
INFO - 2024-12-14 15:30:30 --> Output Class Initialized
INFO - 2024-12-14 15:30:30 --> Security Class Initialized
DEBUG - 2024-12-14 15:30:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-14 15:30:30 --> Input Class Initialized
INFO - 2024-12-14 15:30:30 --> Language Class Initialized
INFO - 2024-12-14 15:30:30 --> Language Class Initialized
INFO - 2024-12-14 15:30:30 --> Config Class Initialized
INFO - 2024-12-14 15:30:30 --> Loader Class Initialized
INFO - 2024-12-14 15:30:30 --> Helper loaded: url_helper
INFO - 2024-12-14 15:30:30 --> Helper loaded: file_helper
INFO - 2024-12-14 15:30:30 --> Helper loaded: form_helper
INFO - 2024-12-14 15:30:30 --> Helper loaded: my_helper
INFO - 2024-12-14 15:30:30 --> Database Driver Class Initialized
INFO - 2024-12-14 15:30:30 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-14 15:30:30 --> Controller Class Initialized
INFO - 2024-12-14 15:30:31 --> Config Class Initialized
INFO - 2024-12-14 15:30:31 --> Hooks Class Initialized
DEBUG - 2024-12-14 15:30:31 --> UTF-8 Support Enabled
INFO - 2024-12-14 15:30:31 --> Utf8 Class Initialized
INFO - 2024-12-14 15:30:31 --> URI Class Initialized
INFO - 2024-12-14 15:30:31 --> Router Class Initialized
INFO - 2024-12-14 15:30:31 --> Output Class Initialized
INFO - 2024-12-14 15:30:31 --> Security Class Initialized
DEBUG - 2024-12-14 15:30:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-14 15:30:31 --> Input Class Initialized
INFO - 2024-12-14 15:30:31 --> Language Class Initialized
INFO - 2024-12-14 15:30:31 --> Language Class Initialized
INFO - 2024-12-14 15:30:31 --> Config Class Initialized
INFO - 2024-12-14 15:30:31 --> Loader Class Initialized
INFO - 2024-12-14 15:30:31 --> Helper loaded: url_helper
INFO - 2024-12-14 15:30:31 --> Helper loaded: file_helper
INFO - 2024-12-14 15:30:31 --> Helper loaded: form_helper
INFO - 2024-12-14 15:30:31 --> Helper loaded: my_helper
INFO - 2024-12-14 15:30:31 --> Database Driver Class Initialized
INFO - 2024-12-14 15:30:31 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-14 15:30:31 --> Controller Class Initialized
INFO - 2024-12-14 15:30:34 --> Config Class Initialized
INFO - 2024-12-14 15:30:34 --> Hooks Class Initialized
DEBUG - 2024-12-14 15:30:34 --> UTF-8 Support Enabled
INFO - 2024-12-14 15:30:34 --> Utf8 Class Initialized
INFO - 2024-12-14 15:30:34 --> URI Class Initialized
INFO - 2024-12-14 15:30:34 --> Router Class Initialized
INFO - 2024-12-14 15:30:34 --> Output Class Initialized
INFO - 2024-12-14 15:30:34 --> Security Class Initialized
DEBUG - 2024-12-14 15:30:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-14 15:30:34 --> Input Class Initialized
INFO - 2024-12-14 15:30:34 --> Language Class Initialized
INFO - 2024-12-14 15:30:34 --> Language Class Initialized
INFO - 2024-12-14 15:30:34 --> Config Class Initialized
INFO - 2024-12-14 15:30:34 --> Loader Class Initialized
INFO - 2024-12-14 15:30:34 --> Helper loaded: url_helper
INFO - 2024-12-14 15:30:34 --> Helper loaded: file_helper
INFO - 2024-12-14 15:30:34 --> Helper loaded: form_helper
INFO - 2024-12-14 15:30:34 --> Helper loaded: my_helper
INFO - 2024-12-14 15:30:34 --> Database Driver Class Initialized
INFO - 2024-12-14 15:30:34 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-14 15:30:34 --> Controller Class Initialized
INFO - 2024-12-14 15:30:35 --> Config Class Initialized
INFO - 2024-12-14 15:30:35 --> Hooks Class Initialized
DEBUG - 2024-12-14 15:30:35 --> UTF-8 Support Enabled
INFO - 2024-12-14 15:30:35 --> Utf8 Class Initialized
INFO - 2024-12-14 15:30:35 --> URI Class Initialized
INFO - 2024-12-14 15:30:35 --> Router Class Initialized
INFO - 2024-12-14 15:30:35 --> Output Class Initialized
INFO - 2024-12-14 15:30:35 --> Security Class Initialized
DEBUG - 2024-12-14 15:30:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-14 15:30:35 --> Input Class Initialized
INFO - 2024-12-14 15:30:35 --> Language Class Initialized
INFO - 2024-12-14 15:30:35 --> Language Class Initialized
INFO - 2024-12-14 15:30:35 --> Config Class Initialized
INFO - 2024-12-14 15:30:35 --> Loader Class Initialized
INFO - 2024-12-14 15:30:35 --> Helper loaded: url_helper
INFO - 2024-12-14 15:30:35 --> Helper loaded: file_helper
INFO - 2024-12-14 15:30:35 --> Helper loaded: form_helper
INFO - 2024-12-14 15:30:35 --> Helper loaded: my_helper
INFO - 2024-12-14 15:30:35 --> Database Driver Class Initialized
INFO - 2024-12-14 15:30:35 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-14 15:30:35 --> Controller Class Initialized
INFO - 2024-12-14 15:30:36 --> Config Class Initialized
INFO - 2024-12-14 15:30:36 --> Hooks Class Initialized
DEBUG - 2024-12-14 15:30:36 --> UTF-8 Support Enabled
INFO - 2024-12-14 15:30:36 --> Utf8 Class Initialized
INFO - 2024-12-14 15:30:36 --> URI Class Initialized
INFO - 2024-12-14 15:30:36 --> Router Class Initialized
INFO - 2024-12-14 15:30:36 --> Output Class Initialized
INFO - 2024-12-14 15:30:36 --> Security Class Initialized
DEBUG - 2024-12-14 15:30:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-14 15:30:36 --> Input Class Initialized
INFO - 2024-12-14 15:30:36 --> Language Class Initialized
INFO - 2024-12-14 15:30:36 --> Language Class Initialized
INFO - 2024-12-14 15:30:36 --> Config Class Initialized
INFO - 2024-12-14 15:30:36 --> Loader Class Initialized
INFO - 2024-12-14 15:30:36 --> Helper loaded: url_helper
INFO - 2024-12-14 15:30:36 --> Helper loaded: file_helper
INFO - 2024-12-14 15:30:36 --> Helper loaded: form_helper
INFO - 2024-12-14 15:30:36 --> Helper loaded: my_helper
INFO - 2024-12-14 15:30:36 --> Database Driver Class Initialized
INFO - 2024-12-14 15:30:36 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-14 15:30:36 --> Controller Class Initialized
INFO - 2024-12-14 15:30:36 --> Config Class Initialized
INFO - 2024-12-14 15:30:36 --> Hooks Class Initialized
DEBUG - 2024-12-14 15:30:36 --> UTF-8 Support Enabled
INFO - 2024-12-14 15:30:36 --> Utf8 Class Initialized
INFO - 2024-12-14 15:30:36 --> URI Class Initialized
INFO - 2024-12-14 15:30:36 --> Router Class Initialized
INFO - 2024-12-14 15:30:36 --> Output Class Initialized
INFO - 2024-12-14 15:30:36 --> Security Class Initialized
DEBUG - 2024-12-14 15:30:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-14 15:30:36 --> Input Class Initialized
INFO - 2024-12-14 15:30:36 --> Language Class Initialized
INFO - 2024-12-14 15:30:36 --> Language Class Initialized
INFO - 2024-12-14 15:30:36 --> Config Class Initialized
INFO - 2024-12-14 15:30:36 --> Loader Class Initialized
INFO - 2024-12-14 15:30:36 --> Helper loaded: url_helper
INFO - 2024-12-14 15:30:36 --> Helper loaded: file_helper
INFO - 2024-12-14 15:30:36 --> Helper loaded: form_helper
INFO - 2024-12-14 15:30:36 --> Helper loaded: my_helper
INFO - 2024-12-14 15:30:36 --> Database Driver Class Initialized
INFO - 2024-12-14 15:30:36 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-14 15:30:36 --> Controller Class Initialized
INFO - 2024-12-14 15:30:37 --> Config Class Initialized
INFO - 2024-12-14 15:30:37 --> Hooks Class Initialized
DEBUG - 2024-12-14 15:30:37 --> UTF-8 Support Enabled
INFO - 2024-12-14 15:30:37 --> Utf8 Class Initialized
INFO - 2024-12-14 15:30:37 --> URI Class Initialized
INFO - 2024-12-14 15:30:37 --> Router Class Initialized
INFO - 2024-12-14 15:30:37 --> Output Class Initialized
INFO - 2024-12-14 15:30:37 --> Security Class Initialized
DEBUG - 2024-12-14 15:30:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-14 15:30:37 --> Input Class Initialized
INFO - 2024-12-14 15:30:37 --> Language Class Initialized
INFO - 2024-12-14 15:30:37 --> Language Class Initialized
INFO - 2024-12-14 15:30:37 --> Config Class Initialized
INFO - 2024-12-14 15:30:37 --> Loader Class Initialized
INFO - 2024-12-14 15:30:37 --> Helper loaded: url_helper
INFO - 2024-12-14 15:30:37 --> Helper loaded: file_helper
INFO - 2024-12-14 15:30:37 --> Helper loaded: form_helper
INFO - 2024-12-14 15:30:37 --> Helper loaded: my_helper
INFO - 2024-12-14 15:30:37 --> Database Driver Class Initialized
INFO - 2024-12-14 15:30:37 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-14 15:30:37 --> Controller Class Initialized
INFO - 2024-12-14 15:30:38 --> Config Class Initialized
INFO - 2024-12-14 15:30:38 --> Hooks Class Initialized
DEBUG - 2024-12-14 15:30:38 --> UTF-8 Support Enabled
INFO - 2024-12-14 15:30:38 --> Utf8 Class Initialized
INFO - 2024-12-14 15:30:38 --> URI Class Initialized
INFO - 2024-12-14 15:30:38 --> Router Class Initialized
INFO - 2024-12-14 15:30:38 --> Output Class Initialized
INFO - 2024-12-14 15:30:38 --> Security Class Initialized
DEBUG - 2024-12-14 15:30:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-14 15:30:38 --> Input Class Initialized
INFO - 2024-12-14 15:30:38 --> Language Class Initialized
INFO - 2024-12-14 15:30:38 --> Language Class Initialized
INFO - 2024-12-14 15:30:38 --> Config Class Initialized
INFO - 2024-12-14 15:30:38 --> Loader Class Initialized
INFO - 2024-12-14 15:30:38 --> Helper loaded: url_helper
INFO - 2024-12-14 15:30:38 --> Helper loaded: file_helper
INFO - 2024-12-14 15:30:38 --> Helper loaded: form_helper
INFO - 2024-12-14 15:30:38 --> Helper loaded: my_helper
INFO - 2024-12-14 15:30:38 --> Database Driver Class Initialized
INFO - 2024-12-14 15:30:38 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-14 15:30:38 --> Controller Class Initialized
ERROR - 2024-12-14 15:30:38 --> Severity: Notice --> Undefined variable: status_form /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/data_siswa/views/form.php 231
DEBUG - 2024-12-14 15:30:38 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/data_siswa/views/form.php
DEBUG - 2024-12-14 15:30:38 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-12-14 15:30:38 --> Final output sent to browser
DEBUG - 2024-12-14 15:30:38 --> Total execution time: 0.1722
INFO - 2024-12-14 15:30:41 --> Config Class Initialized
INFO - 2024-12-14 15:30:41 --> Hooks Class Initialized
DEBUG - 2024-12-14 15:30:41 --> UTF-8 Support Enabled
INFO - 2024-12-14 15:30:41 --> Utf8 Class Initialized
INFO - 2024-12-14 15:30:41 --> URI Class Initialized
INFO - 2024-12-14 15:30:41 --> Router Class Initialized
INFO - 2024-12-14 15:30:41 --> Output Class Initialized
INFO - 2024-12-14 15:30:41 --> Security Class Initialized
DEBUG - 2024-12-14 15:30:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-14 15:30:41 --> Input Class Initialized
INFO - 2024-12-14 15:30:41 --> Language Class Initialized
ERROR - 2024-12-14 15:30:41 --> 404 Page Not Found: /index
INFO - 2024-12-14 15:31:16 --> Config Class Initialized
INFO - 2024-12-14 15:31:16 --> Hooks Class Initialized
DEBUG - 2024-12-14 15:31:16 --> UTF-8 Support Enabled
INFO - 2024-12-14 15:31:16 --> Utf8 Class Initialized
INFO - 2024-12-14 15:31:16 --> URI Class Initialized
INFO - 2024-12-14 15:31:16 --> Router Class Initialized
INFO - 2024-12-14 15:31:16 --> Output Class Initialized
INFO - 2024-12-14 15:31:16 --> Security Class Initialized
DEBUG - 2024-12-14 15:31:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-14 15:31:16 --> Input Class Initialized
INFO - 2024-12-14 15:31:16 --> Language Class Initialized
INFO - 2024-12-14 15:31:16 --> Language Class Initialized
INFO - 2024-12-14 15:31:16 --> Config Class Initialized
INFO - 2024-12-14 15:31:16 --> Loader Class Initialized
INFO - 2024-12-14 15:31:16 --> Helper loaded: url_helper
INFO - 2024-12-14 15:31:16 --> Helper loaded: file_helper
INFO - 2024-12-14 15:31:16 --> Helper loaded: form_helper
INFO - 2024-12-14 15:31:16 --> Helper loaded: my_helper
INFO - 2024-12-14 15:31:16 --> Database Driver Class Initialized
INFO - 2024-12-14 15:31:16 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-14 15:31:16 --> Controller Class Initialized
ERROR - 2024-12-14 15:31:16 --> Severity: Notice --> Undefined variable: status_form /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/data_siswa/views/form.php 231
DEBUG - 2024-12-14 15:31:16 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/data_siswa/views/form.php
DEBUG - 2024-12-14 15:31:16 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-12-14 15:31:16 --> Final output sent to browser
DEBUG - 2024-12-14 15:31:16 --> Total execution time: 0.0305
INFO - 2024-12-14 15:31:16 --> Config Class Initialized
INFO - 2024-12-14 15:31:16 --> Hooks Class Initialized
DEBUG - 2024-12-14 15:31:16 --> UTF-8 Support Enabled
INFO - 2024-12-14 15:31:16 --> Utf8 Class Initialized
INFO - 2024-12-14 15:31:16 --> URI Class Initialized
INFO - 2024-12-14 15:31:16 --> Router Class Initialized
INFO - 2024-12-14 15:31:16 --> Output Class Initialized
INFO - 2024-12-14 15:31:16 --> Security Class Initialized
DEBUG - 2024-12-14 15:31:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-14 15:31:16 --> Input Class Initialized
INFO - 2024-12-14 15:31:16 --> Language Class Initialized
ERROR - 2024-12-14 15:31:16 --> 404 Page Not Found: /index
INFO - 2024-12-14 15:35:35 --> Config Class Initialized
INFO - 2024-12-14 15:35:35 --> Hooks Class Initialized
DEBUG - 2024-12-14 15:35:35 --> UTF-8 Support Enabled
INFO - 2024-12-14 15:35:35 --> Utf8 Class Initialized
INFO - 2024-12-14 15:35:35 --> URI Class Initialized
INFO - 2024-12-14 15:35:35 --> Router Class Initialized
INFO - 2024-12-14 15:35:35 --> Output Class Initialized
INFO - 2024-12-14 15:35:35 --> Security Class Initialized
DEBUG - 2024-12-14 15:35:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-14 15:35:35 --> Input Class Initialized
INFO - 2024-12-14 15:35:35 --> Language Class Initialized
INFO - 2024-12-14 15:35:35 --> Language Class Initialized
INFO - 2024-12-14 15:35:35 --> Config Class Initialized
INFO - 2024-12-14 15:35:35 --> Loader Class Initialized
INFO - 2024-12-14 15:35:35 --> Helper loaded: url_helper
INFO - 2024-12-14 15:35:35 --> Helper loaded: file_helper
INFO - 2024-12-14 15:35:35 --> Helper loaded: form_helper
INFO - 2024-12-14 15:35:35 --> Helper loaded: my_helper
INFO - 2024-12-14 15:35:35 --> Database Driver Class Initialized
INFO - 2024-12-14 15:35:35 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-14 15:35:35 --> Controller Class Initialized
ERROR - 2024-12-14 15:35:35 --> Severity: Notice --> Undefined variable: status_form /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/data_siswa/views/form.php 228
DEBUG - 2024-12-14 15:35:35 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/data_siswa/views/form.php
DEBUG - 2024-12-14 15:35:35 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-12-14 15:35:35 --> Final output sent to browser
DEBUG - 2024-12-14 15:35:35 --> Total execution time: 0.2626
INFO - 2024-12-14 15:35:36 --> Config Class Initialized
INFO - 2024-12-14 15:35:36 --> Hooks Class Initialized
DEBUG - 2024-12-14 15:35:36 --> UTF-8 Support Enabled
INFO - 2024-12-14 15:35:36 --> Utf8 Class Initialized
INFO - 2024-12-14 15:35:36 --> URI Class Initialized
INFO - 2024-12-14 15:35:36 --> Router Class Initialized
INFO - 2024-12-14 15:35:36 --> Output Class Initialized
INFO - 2024-12-14 15:35:36 --> Security Class Initialized
DEBUG - 2024-12-14 15:35:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-14 15:35:36 --> Input Class Initialized
INFO - 2024-12-14 15:35:36 --> Language Class Initialized
ERROR - 2024-12-14 15:35:36 --> 404 Page Not Found: /index
INFO - 2024-12-14 15:36:22 --> Config Class Initialized
INFO - 2024-12-14 15:36:22 --> Hooks Class Initialized
DEBUG - 2024-12-14 15:36:22 --> UTF-8 Support Enabled
INFO - 2024-12-14 15:36:22 --> Utf8 Class Initialized
INFO - 2024-12-14 15:36:22 --> URI Class Initialized
INFO - 2024-12-14 15:36:22 --> Router Class Initialized
INFO - 2024-12-14 15:36:22 --> Output Class Initialized
INFO - 2024-12-14 15:36:22 --> Security Class Initialized
DEBUG - 2024-12-14 15:36:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-14 15:36:22 --> Input Class Initialized
INFO - 2024-12-14 15:36:22 --> Language Class Initialized
INFO - 2024-12-14 15:36:22 --> Language Class Initialized
INFO - 2024-12-14 15:36:22 --> Config Class Initialized
INFO - 2024-12-14 15:36:22 --> Loader Class Initialized
INFO - 2024-12-14 15:36:22 --> Helper loaded: url_helper
INFO - 2024-12-14 15:36:22 --> Helper loaded: file_helper
INFO - 2024-12-14 15:36:22 --> Helper loaded: form_helper
INFO - 2024-12-14 15:36:22 --> Helper loaded: my_helper
INFO - 2024-12-14 15:36:22 --> Database Driver Class Initialized
INFO - 2024-12-14 15:36:22 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-14 15:36:22 --> Controller Class Initialized
DEBUG - 2024-12-14 15:36:22 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/data_siswa/views/form.php
DEBUG - 2024-12-14 15:36:22 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-12-14 15:36:22 --> Final output sent to browser
DEBUG - 2024-12-14 15:36:22 --> Total execution time: 0.0830
INFO - 2024-12-14 15:36:23 --> Config Class Initialized
INFO - 2024-12-14 15:36:23 --> Hooks Class Initialized
DEBUG - 2024-12-14 15:36:23 --> UTF-8 Support Enabled
INFO - 2024-12-14 15:36:23 --> Utf8 Class Initialized
INFO - 2024-12-14 15:36:23 --> URI Class Initialized
INFO - 2024-12-14 15:36:23 --> Router Class Initialized
INFO - 2024-12-14 15:36:23 --> Output Class Initialized
INFO - 2024-12-14 15:36:23 --> Security Class Initialized
DEBUG - 2024-12-14 15:36:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-14 15:36:23 --> Input Class Initialized
INFO - 2024-12-14 15:36:23 --> Language Class Initialized
ERROR - 2024-12-14 15:36:23 --> 404 Page Not Found: /index
INFO - 2024-12-14 15:38:25 --> Config Class Initialized
INFO - 2024-12-14 15:38:25 --> Hooks Class Initialized
DEBUG - 2024-12-14 15:38:25 --> UTF-8 Support Enabled
INFO - 2024-12-14 15:38:25 --> Utf8 Class Initialized
INFO - 2024-12-14 15:38:25 --> URI Class Initialized
INFO - 2024-12-14 15:38:25 --> Router Class Initialized
INFO - 2024-12-14 15:38:25 --> Output Class Initialized
INFO - 2024-12-14 15:38:25 --> Security Class Initialized
DEBUG - 2024-12-14 15:38:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-14 15:38:25 --> Input Class Initialized
INFO - 2024-12-14 15:38:25 --> Language Class Initialized
INFO - 2024-12-14 15:38:25 --> Language Class Initialized
INFO - 2024-12-14 15:38:25 --> Config Class Initialized
INFO - 2024-12-14 15:38:25 --> Loader Class Initialized
INFO - 2024-12-14 15:38:25 --> Helper loaded: url_helper
INFO - 2024-12-14 15:38:25 --> Helper loaded: file_helper
INFO - 2024-12-14 15:38:25 --> Helper loaded: form_helper
INFO - 2024-12-14 15:38:25 --> Helper loaded: my_helper
INFO - 2024-12-14 15:38:25 --> Database Driver Class Initialized
INFO - 2024-12-14 15:38:25 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-14 15:38:25 --> Controller Class Initialized
ERROR - 2024-12-14 15:38:25 --> Severity: Notice --> Undefined variable: status_form /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/data_siswa/views/form.php 228
DEBUG - 2024-12-14 15:38:25 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/data_siswa/views/form.php
DEBUG - 2024-12-14 15:38:25 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-12-14 15:38:25 --> Final output sent to browser
DEBUG - 2024-12-14 15:38:25 --> Total execution time: 0.1067
INFO - 2024-12-14 15:38:26 --> Config Class Initialized
INFO - 2024-12-14 15:38:26 --> Hooks Class Initialized
DEBUG - 2024-12-14 15:38:26 --> UTF-8 Support Enabled
INFO - 2024-12-14 15:38:26 --> Utf8 Class Initialized
INFO - 2024-12-14 15:38:26 --> URI Class Initialized
INFO - 2024-12-14 15:38:26 --> Router Class Initialized
INFO - 2024-12-14 15:38:26 --> Output Class Initialized
INFO - 2024-12-14 15:38:26 --> Security Class Initialized
DEBUG - 2024-12-14 15:38:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-14 15:38:26 --> Input Class Initialized
INFO - 2024-12-14 15:38:26 --> Language Class Initialized
ERROR - 2024-12-14 15:38:26 --> 404 Page Not Found: /index
INFO - 2024-12-14 15:39:35 --> Config Class Initialized
INFO - 2024-12-14 15:39:35 --> Hooks Class Initialized
DEBUG - 2024-12-14 15:39:35 --> UTF-8 Support Enabled
INFO - 2024-12-14 15:39:35 --> Utf8 Class Initialized
INFO - 2024-12-14 15:39:35 --> URI Class Initialized
INFO - 2024-12-14 15:39:35 --> Router Class Initialized
INFO - 2024-12-14 15:39:35 --> Output Class Initialized
INFO - 2024-12-14 15:39:35 --> Security Class Initialized
DEBUG - 2024-12-14 15:39:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-14 15:39:35 --> Input Class Initialized
INFO - 2024-12-14 15:39:35 --> Language Class Initialized
INFO - 2024-12-14 15:39:35 --> Language Class Initialized
INFO - 2024-12-14 15:39:35 --> Config Class Initialized
INFO - 2024-12-14 15:39:35 --> Loader Class Initialized
INFO - 2024-12-14 15:39:35 --> Helper loaded: url_helper
INFO - 2024-12-14 15:39:35 --> Helper loaded: file_helper
INFO - 2024-12-14 15:39:35 --> Helper loaded: form_helper
INFO - 2024-12-14 15:39:35 --> Helper loaded: my_helper
INFO - 2024-12-14 15:39:35 --> Database Driver Class Initialized
INFO - 2024-12-14 15:39:35 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-14 15:39:35 --> Controller Class Initialized
DEBUG - 2024-12-14 15:39:35 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/data_siswa/views/form.php
DEBUG - 2024-12-14 15:39:35 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-12-14 15:39:35 --> Final output sent to browser
DEBUG - 2024-12-14 15:39:35 --> Total execution time: 0.0292
INFO - 2024-12-14 15:39:35 --> Config Class Initialized
INFO - 2024-12-14 15:39:35 --> Hooks Class Initialized
DEBUG - 2024-12-14 15:39:35 --> UTF-8 Support Enabled
INFO - 2024-12-14 15:39:35 --> Utf8 Class Initialized
INFO - 2024-12-14 15:39:35 --> URI Class Initialized
INFO - 2024-12-14 15:39:35 --> Router Class Initialized
INFO - 2024-12-14 15:39:35 --> Output Class Initialized
INFO - 2024-12-14 15:39:35 --> Security Class Initialized
DEBUG - 2024-12-14 15:39:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-14 15:39:35 --> Input Class Initialized
INFO - 2024-12-14 15:39:35 --> Language Class Initialized
ERROR - 2024-12-14 15:39:35 --> 404 Page Not Found: /index
INFO - 2024-12-14 15:39:53 --> Config Class Initialized
INFO - 2024-12-14 15:39:53 --> Hooks Class Initialized
DEBUG - 2024-12-14 15:39:53 --> UTF-8 Support Enabled
INFO - 2024-12-14 15:39:53 --> Utf8 Class Initialized
INFO - 2024-12-14 15:39:53 --> URI Class Initialized
INFO - 2024-12-14 15:39:53 --> Router Class Initialized
INFO - 2024-12-14 15:39:53 --> Output Class Initialized
INFO - 2024-12-14 15:39:53 --> Security Class Initialized
DEBUG - 2024-12-14 15:39:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-14 15:39:53 --> Input Class Initialized
INFO - 2024-12-14 15:39:53 --> Language Class Initialized
INFO - 2024-12-14 15:39:53 --> Language Class Initialized
INFO - 2024-12-14 15:39:53 --> Config Class Initialized
INFO - 2024-12-14 15:39:53 --> Loader Class Initialized
INFO - 2024-12-14 15:39:53 --> Helper loaded: url_helper
INFO - 2024-12-14 15:39:53 --> Helper loaded: file_helper
INFO - 2024-12-14 15:39:53 --> Helper loaded: form_helper
INFO - 2024-12-14 15:39:53 --> Helper loaded: my_helper
INFO - 2024-12-14 15:39:53 --> Database Driver Class Initialized
INFO - 2024-12-14 15:39:53 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-14 15:39:53 --> Controller Class Initialized
INFO - 2024-12-14 15:39:53 --> Upload Class Initialized
INFO - 2024-12-14 15:39:53 --> Language file loaded: language/english/upload_lang.php
DEBUG - 2024-12-14 15:39:53 --> You did not select a file to upload.
INFO - 2024-12-14 15:39:53 --> Config Class Initialized
INFO - 2024-12-14 15:39:53 --> Hooks Class Initialized
DEBUG - 2024-12-14 15:39:53 --> UTF-8 Support Enabled
INFO - 2024-12-14 15:39:53 --> Utf8 Class Initialized
INFO - 2024-12-14 15:39:53 --> URI Class Initialized
INFO - 2024-12-14 15:39:53 --> Router Class Initialized
INFO - 2024-12-14 15:39:53 --> Output Class Initialized
INFO - 2024-12-14 15:39:53 --> Security Class Initialized
DEBUG - 2024-12-14 15:39:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-14 15:39:53 --> Input Class Initialized
INFO - 2024-12-14 15:39:53 --> Language Class Initialized
INFO - 2024-12-14 15:39:53 --> Language Class Initialized
INFO - 2024-12-14 15:39:53 --> Config Class Initialized
INFO - 2024-12-14 15:39:53 --> Loader Class Initialized
INFO - 2024-12-14 15:39:53 --> Helper loaded: url_helper
INFO - 2024-12-14 15:39:53 --> Helper loaded: file_helper
INFO - 2024-12-14 15:39:53 --> Helper loaded: form_helper
INFO - 2024-12-14 15:39:53 --> Helper loaded: my_helper
INFO - 2024-12-14 15:39:53 --> Database Driver Class Initialized
INFO - 2024-12-14 15:39:53 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-14 15:39:53 --> Controller Class Initialized
DEBUG - 2024-12-14 15:39:53 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/data_siswa/views/list.php
DEBUG - 2024-12-14 15:39:53 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-12-14 15:39:53 --> Final output sent to browser
DEBUG - 2024-12-14 15:39:53 --> Total execution time: 0.0276
INFO - 2024-12-14 15:40:06 --> Config Class Initialized
INFO - 2024-12-14 15:40:06 --> Hooks Class Initialized
DEBUG - 2024-12-14 15:40:06 --> UTF-8 Support Enabled
INFO - 2024-12-14 15:40:06 --> Utf8 Class Initialized
INFO - 2024-12-14 15:40:06 --> URI Class Initialized
INFO - 2024-12-14 15:40:06 --> Router Class Initialized
INFO - 2024-12-14 15:40:06 --> Output Class Initialized
INFO - 2024-12-14 15:40:06 --> Security Class Initialized
DEBUG - 2024-12-14 15:40:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-14 15:40:06 --> Input Class Initialized
INFO - 2024-12-14 15:40:06 --> Language Class Initialized
INFO - 2024-12-14 15:40:06 --> Language Class Initialized
INFO - 2024-12-14 15:40:06 --> Config Class Initialized
INFO - 2024-12-14 15:40:06 --> Loader Class Initialized
INFO - 2024-12-14 15:40:06 --> Helper loaded: url_helper
INFO - 2024-12-14 15:40:06 --> Helper loaded: file_helper
INFO - 2024-12-14 15:40:06 --> Helper loaded: form_helper
INFO - 2024-12-14 15:40:06 --> Helper loaded: my_helper
INFO - 2024-12-14 15:40:06 --> Database Driver Class Initialized
INFO - 2024-12-14 15:40:06 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-14 15:40:06 --> Controller Class Initialized
DEBUG - 2024-12-14 15:40:06 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/data_siswa/views/form.php
DEBUG - 2024-12-14 15:40:06 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-12-14 15:40:06 --> Final output sent to browser
DEBUG - 2024-12-14 15:40:06 --> Total execution time: 0.0530
INFO - 2024-12-14 15:40:06 --> Config Class Initialized
INFO - 2024-12-14 15:40:06 --> Hooks Class Initialized
DEBUG - 2024-12-14 15:40:06 --> UTF-8 Support Enabled
INFO - 2024-12-14 15:40:06 --> Utf8 Class Initialized
INFO - 2024-12-14 15:40:06 --> URI Class Initialized
INFO - 2024-12-14 15:40:06 --> Router Class Initialized
INFO - 2024-12-14 15:40:06 --> Output Class Initialized
INFO - 2024-12-14 15:40:06 --> Security Class Initialized
DEBUG - 2024-12-14 15:40:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-14 15:40:06 --> Input Class Initialized
INFO - 2024-12-14 15:40:06 --> Language Class Initialized
ERROR - 2024-12-14 15:40:06 --> 404 Page Not Found: /index
INFO - 2024-12-14 15:43:10 --> Config Class Initialized
INFO - 2024-12-14 15:43:10 --> Hooks Class Initialized
DEBUG - 2024-12-14 15:43:10 --> UTF-8 Support Enabled
INFO - 2024-12-14 15:43:10 --> Utf8 Class Initialized
INFO - 2024-12-14 15:43:10 --> URI Class Initialized
INFO - 2024-12-14 15:43:10 --> Router Class Initialized
INFO - 2024-12-14 15:43:10 --> Output Class Initialized
INFO - 2024-12-14 15:43:10 --> Security Class Initialized
DEBUG - 2024-12-14 15:43:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-14 15:43:10 --> Input Class Initialized
INFO - 2024-12-14 15:43:10 --> Language Class Initialized
INFO - 2024-12-14 15:43:10 --> Language Class Initialized
INFO - 2024-12-14 15:43:10 --> Config Class Initialized
INFO - 2024-12-14 15:43:10 --> Loader Class Initialized
INFO - 2024-12-14 15:43:10 --> Helper loaded: url_helper
INFO - 2024-12-14 15:43:10 --> Helper loaded: file_helper
INFO - 2024-12-14 15:43:10 --> Helper loaded: form_helper
INFO - 2024-12-14 15:43:10 --> Helper loaded: my_helper
INFO - 2024-12-14 15:43:10 --> Database Driver Class Initialized
INFO - 2024-12-14 15:43:10 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-14 15:43:10 --> Controller Class Initialized
INFO - 2024-12-14 15:43:10 --> Upload Class Initialized
INFO - 2024-12-14 15:43:10 --> Language file loaded: language/english/upload_lang.php
DEBUG - 2024-12-14 15:43:10 --> You did not select a file to upload.
INFO - 2024-12-14 15:43:10 --> Config Class Initialized
INFO - 2024-12-14 15:43:10 --> Hooks Class Initialized
DEBUG - 2024-12-14 15:43:10 --> UTF-8 Support Enabled
INFO - 2024-12-14 15:43:10 --> Utf8 Class Initialized
INFO - 2024-12-14 15:43:10 --> URI Class Initialized
INFO - 2024-12-14 15:43:10 --> Router Class Initialized
INFO - 2024-12-14 15:43:10 --> Output Class Initialized
INFO - 2024-12-14 15:43:10 --> Security Class Initialized
DEBUG - 2024-12-14 15:43:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-14 15:43:10 --> Input Class Initialized
INFO - 2024-12-14 15:43:10 --> Language Class Initialized
INFO - 2024-12-14 15:43:10 --> Language Class Initialized
INFO - 2024-12-14 15:43:10 --> Config Class Initialized
INFO - 2024-12-14 15:43:10 --> Loader Class Initialized
INFO - 2024-12-14 15:43:10 --> Helper loaded: url_helper
INFO - 2024-12-14 15:43:10 --> Helper loaded: file_helper
INFO - 2024-12-14 15:43:10 --> Helper loaded: form_helper
INFO - 2024-12-14 15:43:10 --> Helper loaded: my_helper
INFO - 2024-12-14 15:43:10 --> Database Driver Class Initialized
INFO - 2024-12-14 15:43:10 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-14 15:43:10 --> Controller Class Initialized
DEBUG - 2024-12-14 15:43:10 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/data_siswa/views/list.php
DEBUG - 2024-12-14 15:43:10 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-12-14 15:43:10 --> Final output sent to browser
DEBUG - 2024-12-14 15:43:10 --> Total execution time: 0.0246
INFO - 2024-12-14 15:43:32 --> Config Class Initialized
INFO - 2024-12-14 15:43:32 --> Hooks Class Initialized
DEBUG - 2024-12-14 15:43:32 --> UTF-8 Support Enabled
INFO - 2024-12-14 15:43:32 --> Utf8 Class Initialized
INFO - 2024-12-14 15:43:32 --> URI Class Initialized
INFO - 2024-12-14 15:43:32 --> Router Class Initialized
INFO - 2024-12-14 15:43:32 --> Output Class Initialized
INFO - 2024-12-14 15:43:32 --> Security Class Initialized
DEBUG - 2024-12-14 15:43:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-14 15:43:32 --> Input Class Initialized
INFO - 2024-12-14 15:43:32 --> Language Class Initialized
INFO - 2024-12-14 15:43:32 --> Language Class Initialized
INFO - 2024-12-14 15:43:32 --> Config Class Initialized
INFO - 2024-12-14 15:43:32 --> Loader Class Initialized
INFO - 2024-12-14 15:43:32 --> Helper loaded: url_helper
INFO - 2024-12-14 15:43:32 --> Helper loaded: file_helper
INFO - 2024-12-14 15:43:32 --> Helper loaded: form_helper
INFO - 2024-12-14 15:43:32 --> Helper loaded: my_helper
INFO - 2024-12-14 15:43:32 --> Database Driver Class Initialized
INFO - 2024-12-14 15:43:32 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-14 15:43:32 --> Controller Class Initialized
DEBUG - 2024-12-14 15:43:32 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/data_siswa/views/form.php
DEBUG - 2024-12-14 15:43:32 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-12-14 15:43:32 --> Final output sent to browser
DEBUG - 2024-12-14 15:43:32 --> Total execution time: 0.0397
INFO - 2024-12-14 15:43:32 --> Config Class Initialized
INFO - 2024-12-14 15:43:32 --> Hooks Class Initialized
DEBUG - 2024-12-14 15:43:32 --> UTF-8 Support Enabled
INFO - 2024-12-14 15:43:32 --> Utf8 Class Initialized
INFO - 2024-12-14 15:43:32 --> URI Class Initialized
INFO - 2024-12-14 15:43:32 --> Router Class Initialized
INFO - 2024-12-14 15:43:32 --> Output Class Initialized
INFO - 2024-12-14 15:43:32 --> Security Class Initialized
DEBUG - 2024-12-14 15:43:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-14 15:43:32 --> Input Class Initialized
INFO - 2024-12-14 15:43:32 --> Language Class Initialized
ERROR - 2024-12-14 15:43:32 --> 404 Page Not Found: /index
INFO - 2024-12-14 15:43:53 --> Config Class Initialized
INFO - 2024-12-14 15:43:53 --> Hooks Class Initialized
DEBUG - 2024-12-14 15:43:53 --> UTF-8 Support Enabled
INFO - 2024-12-14 15:43:53 --> Utf8 Class Initialized
INFO - 2024-12-14 15:43:53 --> URI Class Initialized
INFO - 2024-12-14 15:43:53 --> Router Class Initialized
INFO - 2024-12-14 15:43:53 --> Output Class Initialized
INFO - 2024-12-14 15:43:53 --> Security Class Initialized
DEBUG - 2024-12-14 15:43:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-14 15:43:53 --> Input Class Initialized
INFO - 2024-12-14 15:43:53 --> Language Class Initialized
INFO - 2024-12-14 15:43:53 --> Language Class Initialized
INFO - 2024-12-14 15:43:53 --> Config Class Initialized
INFO - 2024-12-14 15:43:53 --> Loader Class Initialized
INFO - 2024-12-14 15:43:53 --> Helper loaded: url_helper
INFO - 2024-12-14 15:43:53 --> Helper loaded: file_helper
INFO - 2024-12-14 15:43:53 --> Helper loaded: form_helper
INFO - 2024-12-14 15:43:53 --> Helper loaded: my_helper
INFO - 2024-12-14 15:43:53 --> Database Driver Class Initialized
INFO - 2024-12-14 15:43:53 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-14 15:43:53 --> Controller Class Initialized
INFO - 2024-12-14 15:43:53 --> Upload Class Initialized
INFO - 2024-12-14 15:43:53 --> Language file loaded: language/english/upload_lang.php
DEBUG - 2024-12-14 15:43:53 --> You did not select a file to upload.
INFO - 2024-12-14 15:43:53 --> Config Class Initialized
INFO - 2024-12-14 15:43:53 --> Hooks Class Initialized
DEBUG - 2024-12-14 15:43:53 --> UTF-8 Support Enabled
INFO - 2024-12-14 15:43:53 --> Utf8 Class Initialized
INFO - 2024-12-14 15:43:53 --> URI Class Initialized
INFO - 2024-12-14 15:43:53 --> Router Class Initialized
INFO - 2024-12-14 15:43:53 --> Output Class Initialized
INFO - 2024-12-14 15:43:53 --> Security Class Initialized
DEBUG - 2024-12-14 15:43:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-14 15:43:53 --> Input Class Initialized
INFO - 2024-12-14 15:43:53 --> Language Class Initialized
INFO - 2024-12-14 15:43:53 --> Language Class Initialized
INFO - 2024-12-14 15:43:53 --> Config Class Initialized
INFO - 2024-12-14 15:43:53 --> Loader Class Initialized
INFO - 2024-12-14 15:43:53 --> Helper loaded: url_helper
INFO - 2024-12-14 15:43:53 --> Helper loaded: file_helper
INFO - 2024-12-14 15:43:53 --> Helper loaded: form_helper
INFO - 2024-12-14 15:43:53 --> Helper loaded: my_helper
INFO - 2024-12-14 15:43:53 --> Database Driver Class Initialized
INFO - 2024-12-14 15:43:53 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-14 15:43:53 --> Controller Class Initialized
DEBUG - 2024-12-14 15:43:53 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/data_siswa/views/list.php
DEBUG - 2024-12-14 15:43:53 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-12-14 15:43:53 --> Final output sent to browser
DEBUG - 2024-12-14 15:43:53 --> Total execution time: 0.0282
INFO - 2024-12-14 15:43:55 --> Config Class Initialized
INFO - 2024-12-14 15:43:55 --> Hooks Class Initialized
DEBUG - 2024-12-14 15:43:55 --> UTF-8 Support Enabled
INFO - 2024-12-14 15:43:55 --> Utf8 Class Initialized
INFO - 2024-12-14 15:43:55 --> URI Class Initialized
INFO - 2024-12-14 15:43:55 --> Router Class Initialized
INFO - 2024-12-14 15:43:55 --> Output Class Initialized
INFO - 2024-12-14 15:43:55 --> Security Class Initialized
DEBUG - 2024-12-14 15:43:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-14 15:43:55 --> Input Class Initialized
INFO - 2024-12-14 15:43:55 --> Language Class Initialized
INFO - 2024-12-14 15:43:55 --> Language Class Initialized
INFO - 2024-12-14 15:43:55 --> Config Class Initialized
INFO - 2024-12-14 15:43:55 --> Loader Class Initialized
INFO - 2024-12-14 15:43:55 --> Helper loaded: url_helper
INFO - 2024-12-14 15:43:55 --> Helper loaded: file_helper
INFO - 2024-12-14 15:43:55 --> Helper loaded: form_helper
INFO - 2024-12-14 15:43:55 --> Helper loaded: my_helper
INFO - 2024-12-14 15:43:55 --> Database Driver Class Initialized
INFO - 2024-12-14 15:43:55 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-14 15:43:55 --> Controller Class Initialized
DEBUG - 2024-12-14 15:43:55 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/data_siswa/views/form.php
DEBUG - 2024-12-14 15:43:55 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-12-14 15:43:55 --> Final output sent to browser
DEBUG - 2024-12-14 15:43:55 --> Total execution time: 0.0461
INFO - 2024-12-14 15:43:55 --> Config Class Initialized
INFO - 2024-12-14 15:43:55 --> Hooks Class Initialized
DEBUG - 2024-12-14 15:43:55 --> UTF-8 Support Enabled
INFO - 2024-12-14 15:43:55 --> Utf8 Class Initialized
INFO - 2024-12-14 15:43:55 --> URI Class Initialized
INFO - 2024-12-14 15:43:55 --> Router Class Initialized
INFO - 2024-12-14 15:43:55 --> Output Class Initialized
INFO - 2024-12-14 15:43:55 --> Security Class Initialized
DEBUG - 2024-12-14 15:43:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-14 15:43:55 --> Input Class Initialized
INFO - 2024-12-14 15:43:55 --> Language Class Initialized
ERROR - 2024-12-14 15:43:55 --> 404 Page Not Found: /index
INFO - 2024-12-14 15:44:37 --> Config Class Initialized
INFO - 2024-12-14 15:44:37 --> Hooks Class Initialized
DEBUG - 2024-12-14 15:44:37 --> UTF-8 Support Enabled
INFO - 2024-12-14 15:44:37 --> Utf8 Class Initialized
INFO - 2024-12-14 15:44:37 --> URI Class Initialized
INFO - 2024-12-14 15:44:37 --> Router Class Initialized
INFO - 2024-12-14 15:44:37 --> Output Class Initialized
INFO - 2024-12-14 15:44:37 --> Security Class Initialized
DEBUG - 2024-12-14 15:44:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-14 15:44:37 --> Input Class Initialized
INFO - 2024-12-14 15:44:37 --> Language Class Initialized
INFO - 2024-12-14 15:44:37 --> Language Class Initialized
INFO - 2024-12-14 15:44:37 --> Config Class Initialized
INFO - 2024-12-14 15:44:37 --> Loader Class Initialized
INFO - 2024-12-14 15:44:37 --> Helper loaded: url_helper
INFO - 2024-12-14 15:44:37 --> Helper loaded: file_helper
INFO - 2024-12-14 15:44:37 --> Helper loaded: form_helper
INFO - 2024-12-14 15:44:37 --> Helper loaded: my_helper
INFO - 2024-12-14 15:44:37 --> Database Driver Class Initialized
INFO - 2024-12-14 15:44:37 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-14 15:44:37 --> Controller Class Initialized
INFO - 2024-12-14 15:44:37 --> Helper loaded: cookie_helper
INFO - 2024-12-14 15:44:37 --> Config Class Initialized
INFO - 2024-12-14 15:44:37 --> Hooks Class Initialized
DEBUG - 2024-12-14 15:44:37 --> UTF-8 Support Enabled
INFO - 2024-12-14 15:44:37 --> Utf8 Class Initialized
INFO - 2024-12-14 15:44:37 --> URI Class Initialized
INFO - 2024-12-14 15:44:37 --> Router Class Initialized
INFO - 2024-12-14 15:44:37 --> Output Class Initialized
INFO - 2024-12-14 15:44:37 --> Security Class Initialized
DEBUG - 2024-12-14 15:44:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-14 15:44:37 --> Input Class Initialized
INFO - 2024-12-14 15:44:37 --> Language Class Initialized
INFO - 2024-12-14 15:44:37 --> Language Class Initialized
INFO - 2024-12-14 15:44:37 --> Config Class Initialized
INFO - 2024-12-14 15:44:37 --> Loader Class Initialized
INFO - 2024-12-14 15:44:37 --> Helper loaded: url_helper
INFO - 2024-12-14 15:44:37 --> Helper loaded: file_helper
INFO - 2024-12-14 15:44:37 --> Helper loaded: form_helper
INFO - 2024-12-14 15:44:37 --> Helper loaded: my_helper
INFO - 2024-12-14 15:44:37 --> Database Driver Class Initialized
INFO - 2024-12-14 15:44:37 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-14 15:44:37 --> Controller Class Initialized
INFO - 2024-12-14 15:44:37 --> Config Class Initialized
INFO - 2024-12-14 15:44:37 --> Hooks Class Initialized
DEBUG - 2024-12-14 15:44:37 --> UTF-8 Support Enabled
INFO - 2024-12-14 15:44:37 --> Utf8 Class Initialized
INFO - 2024-12-14 15:44:37 --> URI Class Initialized
INFO - 2024-12-14 15:44:37 --> Router Class Initialized
INFO - 2024-12-14 15:44:37 --> Output Class Initialized
INFO - 2024-12-14 15:44:37 --> Security Class Initialized
DEBUG - 2024-12-14 15:44:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-14 15:44:37 --> Input Class Initialized
INFO - 2024-12-14 15:44:37 --> Language Class Initialized
INFO - 2024-12-14 15:44:37 --> Language Class Initialized
INFO - 2024-12-14 15:44:37 --> Config Class Initialized
INFO - 2024-12-14 15:44:37 --> Loader Class Initialized
INFO - 2024-12-14 15:44:37 --> Helper loaded: url_helper
INFO - 2024-12-14 15:44:37 --> Helper loaded: file_helper
INFO - 2024-12-14 15:44:37 --> Helper loaded: form_helper
INFO - 2024-12-14 15:44:37 --> Helper loaded: my_helper
INFO - 2024-12-14 15:44:37 --> Database Driver Class Initialized
INFO - 2024-12-14 15:44:37 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-14 15:44:37 --> Controller Class Initialized
DEBUG - 2024-12-14 15:44:37 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/login/views/login.php
DEBUG - 2024-12-14 15:44:37 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-12-14 15:44:37 --> Final output sent to browser
DEBUG - 2024-12-14 15:44:37 --> Total execution time: 0.0369
INFO - 2024-12-14 15:44:37 --> Config Class Initialized
INFO - 2024-12-14 15:44:37 --> Hooks Class Initialized
DEBUG - 2024-12-14 15:44:37 --> UTF-8 Support Enabled
INFO - 2024-12-14 15:44:37 --> Utf8 Class Initialized
INFO - 2024-12-14 15:44:37 --> URI Class Initialized
INFO - 2024-12-14 15:44:37 --> Router Class Initialized
INFO - 2024-12-14 15:44:37 --> Output Class Initialized
INFO - 2024-12-14 15:44:37 --> Security Class Initialized
DEBUG - 2024-12-14 15:44:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-14 15:44:37 --> Input Class Initialized
INFO - 2024-12-14 15:44:37 --> Language Class Initialized
ERROR - 2024-12-14 15:44:37 --> 404 Page Not Found: /index
INFO - 2024-12-14 16:29:11 --> Config Class Initialized
INFO - 2024-12-14 16:29:11 --> Hooks Class Initialized
DEBUG - 2024-12-14 16:29:11 --> UTF-8 Support Enabled
INFO - 2024-12-14 16:29:11 --> Utf8 Class Initialized
INFO - 2024-12-14 16:29:11 --> URI Class Initialized
INFO - 2024-12-14 16:29:11 --> Router Class Initialized
INFO - 2024-12-14 16:29:11 --> Output Class Initialized
INFO - 2024-12-14 16:29:11 --> Security Class Initialized
DEBUG - 2024-12-14 16:29:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-14 16:29:11 --> Input Class Initialized
INFO - 2024-12-14 16:29:11 --> Language Class Initialized
INFO - 2024-12-14 16:29:11 --> Language Class Initialized
INFO - 2024-12-14 16:29:11 --> Config Class Initialized
INFO - 2024-12-14 16:29:11 --> Loader Class Initialized
INFO - 2024-12-14 16:29:11 --> Helper loaded: url_helper
INFO - 2024-12-14 16:29:11 --> Helper loaded: file_helper
INFO - 2024-12-14 16:29:11 --> Helper loaded: form_helper
INFO - 2024-12-14 16:29:11 --> Helper loaded: my_helper
INFO - 2024-12-14 16:29:11 --> Database Driver Class Initialized
INFO - 2024-12-14 16:29:11 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-14 16:29:11 --> Controller Class Initialized
DEBUG - 2024-12-14 16:29:11 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/login/views/login.php
DEBUG - 2024-12-14 16:29:11 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-12-14 16:29:11 --> Final output sent to browser
DEBUG - 2024-12-14 16:29:11 --> Total execution time: 0.0448
INFO - 2024-12-14 16:29:20 --> Config Class Initialized
INFO - 2024-12-14 16:29:20 --> Hooks Class Initialized
DEBUG - 2024-12-14 16:29:20 --> UTF-8 Support Enabled
INFO - 2024-12-14 16:29:20 --> Utf8 Class Initialized
INFO - 2024-12-14 16:29:20 --> URI Class Initialized
INFO - 2024-12-14 16:29:20 --> Router Class Initialized
INFO - 2024-12-14 16:29:20 --> Output Class Initialized
INFO - 2024-12-14 16:29:20 --> Security Class Initialized
DEBUG - 2024-12-14 16:29:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-14 16:29:20 --> Input Class Initialized
INFO - 2024-12-14 16:29:20 --> Language Class Initialized
INFO - 2024-12-14 16:29:20 --> Language Class Initialized
INFO - 2024-12-14 16:29:20 --> Config Class Initialized
INFO - 2024-12-14 16:29:20 --> Loader Class Initialized
INFO - 2024-12-14 16:29:20 --> Helper loaded: url_helper
INFO - 2024-12-14 16:29:20 --> Helper loaded: file_helper
INFO - 2024-12-14 16:29:20 --> Helper loaded: form_helper
INFO - 2024-12-14 16:29:20 --> Helper loaded: my_helper
INFO - 2024-12-14 16:29:20 --> Database Driver Class Initialized
INFO - 2024-12-14 16:29:20 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-14 16:29:20 --> Controller Class Initialized
INFO - 2024-12-14 16:29:20 --> Helper loaded: cookie_helper
INFO - 2024-12-14 16:29:20 --> Final output sent to browser
DEBUG - 2024-12-14 16:29:20 --> Total execution time: 0.0334
INFO - 2024-12-14 16:29:20 --> Config Class Initialized
INFO - 2024-12-14 16:29:20 --> Hooks Class Initialized
DEBUG - 2024-12-14 16:29:20 --> UTF-8 Support Enabled
INFO - 2024-12-14 16:29:20 --> Utf8 Class Initialized
INFO - 2024-12-14 16:29:20 --> URI Class Initialized
INFO - 2024-12-14 16:29:20 --> Router Class Initialized
INFO - 2024-12-14 16:29:20 --> Output Class Initialized
INFO - 2024-12-14 16:29:20 --> Security Class Initialized
DEBUG - 2024-12-14 16:29:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-14 16:29:20 --> Input Class Initialized
INFO - 2024-12-14 16:29:20 --> Language Class Initialized
INFO - 2024-12-14 16:29:20 --> Language Class Initialized
INFO - 2024-12-14 16:29:20 --> Config Class Initialized
INFO - 2024-12-14 16:29:20 --> Loader Class Initialized
INFO - 2024-12-14 16:29:20 --> Helper loaded: url_helper
INFO - 2024-12-14 16:29:20 --> Helper loaded: file_helper
INFO - 2024-12-14 16:29:20 --> Helper loaded: form_helper
INFO - 2024-12-14 16:29:20 --> Helper loaded: my_helper
INFO - 2024-12-14 16:29:20 --> Database Driver Class Initialized
INFO - 2024-12-14 16:29:20 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-14 16:29:20 --> Controller Class Initialized
DEBUG - 2024-12-14 16:29:20 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/home/views/v_home_guru.php
DEBUG - 2024-12-14 16:29:20 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-12-14 16:29:20 --> Final output sent to browser
DEBUG - 2024-12-14 16:29:20 --> Total execution time: 0.0481
INFO - 2024-12-14 16:29:23 --> Config Class Initialized
INFO - 2024-12-14 16:29:23 --> Hooks Class Initialized
DEBUG - 2024-12-14 16:29:23 --> UTF-8 Support Enabled
INFO - 2024-12-14 16:29:23 --> Utf8 Class Initialized
INFO - 2024-12-14 16:29:23 --> URI Class Initialized
INFO - 2024-12-14 16:29:23 --> Router Class Initialized
INFO - 2024-12-14 16:29:23 --> Output Class Initialized
INFO - 2024-12-14 16:29:23 --> Security Class Initialized
DEBUG - 2024-12-14 16:29:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-14 16:29:23 --> Input Class Initialized
INFO - 2024-12-14 16:29:23 --> Language Class Initialized
INFO - 2024-12-14 16:29:23 --> Language Class Initialized
INFO - 2024-12-14 16:29:23 --> Config Class Initialized
INFO - 2024-12-14 16:29:23 --> Loader Class Initialized
INFO - 2024-12-14 16:29:23 --> Helper loaded: url_helper
INFO - 2024-12-14 16:29:23 --> Helper loaded: file_helper
INFO - 2024-12-14 16:29:23 --> Helper loaded: form_helper
INFO - 2024-12-14 16:29:23 --> Helper loaded: my_helper
INFO - 2024-12-14 16:29:23 --> Database Driver Class Initialized
INFO - 2024-12-14 16:29:23 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-14 16:29:23 --> Controller Class Initialized
DEBUG - 2024-12-14 16:29:23 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/views/list.php
DEBUG - 2024-12-14 16:29:23 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-12-14 16:29:23 --> Final output sent to browser
DEBUG - 2024-12-14 16:29:23 --> Total execution time: 0.0366
INFO - 2024-12-14 16:29:26 --> Config Class Initialized
INFO - 2024-12-14 16:29:26 --> Hooks Class Initialized
DEBUG - 2024-12-14 16:29:26 --> UTF-8 Support Enabled
INFO - 2024-12-14 16:29:26 --> Utf8 Class Initialized
INFO - 2024-12-14 16:29:26 --> URI Class Initialized
INFO - 2024-12-14 16:29:26 --> Router Class Initialized
INFO - 2024-12-14 16:29:26 --> Output Class Initialized
INFO - 2024-12-14 16:29:26 --> Security Class Initialized
DEBUG - 2024-12-14 16:29:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-14 16:29:26 --> Input Class Initialized
INFO - 2024-12-14 16:29:26 --> Language Class Initialized
INFO - 2024-12-14 16:29:26 --> Language Class Initialized
INFO - 2024-12-14 16:29:26 --> Config Class Initialized
INFO - 2024-12-14 16:29:26 --> Loader Class Initialized
INFO - 2024-12-14 16:29:26 --> Helper loaded: url_helper
INFO - 2024-12-14 16:29:26 --> Helper loaded: file_helper
INFO - 2024-12-14 16:29:26 --> Helper loaded: form_helper
INFO - 2024-12-14 16:29:26 --> Helper loaded: my_helper
INFO - 2024-12-14 16:29:26 --> Database Driver Class Initialized
INFO - 2024-12-14 16:29:26 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-14 16:29:26 --> Controller Class Initialized
DEBUG - 2024-12-14 16:29:26 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/views/cetak_ikm.php
INFO - 2024-12-14 16:29:28 --> Config Class Initialized
INFO - 2024-12-14 16:29:28 --> Hooks Class Initialized
DEBUG - 2024-12-14 16:29:28 --> UTF-8 Support Enabled
INFO - 2024-12-14 16:29:28 --> Utf8 Class Initialized
INFO - 2024-12-14 16:29:28 --> URI Class Initialized
INFO - 2024-12-14 16:29:28 --> Router Class Initialized
INFO - 2024-12-14 16:29:28 --> Output Class Initialized
INFO - 2024-12-14 16:29:28 --> Security Class Initialized
DEBUG - 2024-12-14 16:29:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-14 16:29:28 --> Input Class Initialized
INFO - 2024-12-14 16:29:28 --> Language Class Initialized
INFO - 2024-12-14 16:29:28 --> Language Class Initialized
INFO - 2024-12-14 16:29:28 --> Config Class Initialized
INFO - 2024-12-14 16:29:28 --> Loader Class Initialized
INFO - 2024-12-14 16:29:28 --> Helper loaded: url_helper
INFO - 2024-12-14 16:29:28 --> Helper loaded: file_helper
INFO - 2024-12-14 16:29:28 --> Helper loaded: form_helper
INFO - 2024-12-14 16:29:28 --> Helper loaded: my_helper
INFO - 2024-12-14 16:29:28 --> Database Driver Class Initialized
INFO - 2024-12-14 16:29:29 --> Final output sent to browser
DEBUG - 2024-12-14 16:29:29 --> Total execution time: 3.6629
INFO - 2024-12-14 16:29:29 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-14 16:29:29 --> Controller Class Initialized
DEBUG - 2024-12-14 16:29:29 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/views/cetak_mh.php
INFO - 2024-12-14 16:29:34 --> Final output sent to browser
DEBUG - 2024-12-14 16:29:34 --> Total execution time: 5.9028
INFO - 2024-12-14 16:32:47 --> Config Class Initialized
INFO - 2024-12-14 16:32:47 --> Hooks Class Initialized
DEBUG - 2024-12-14 16:32:47 --> UTF-8 Support Enabled
INFO - 2024-12-14 16:32:47 --> Utf8 Class Initialized
INFO - 2024-12-14 16:32:47 --> URI Class Initialized
INFO - 2024-12-14 16:32:47 --> Router Class Initialized
INFO - 2024-12-14 16:32:47 --> Output Class Initialized
INFO - 2024-12-14 16:32:47 --> Security Class Initialized
DEBUG - 2024-12-14 16:32:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-14 16:32:47 --> Input Class Initialized
INFO - 2024-12-14 16:32:47 --> Language Class Initialized
INFO - 2024-12-14 16:32:47 --> Language Class Initialized
INFO - 2024-12-14 16:32:47 --> Config Class Initialized
INFO - 2024-12-14 16:32:47 --> Loader Class Initialized
INFO - 2024-12-14 16:32:47 --> Helper loaded: url_helper
INFO - 2024-12-14 16:32:47 --> Helper loaded: file_helper
INFO - 2024-12-14 16:32:47 --> Helper loaded: form_helper
INFO - 2024-12-14 16:32:47 --> Helper loaded: my_helper
INFO - 2024-12-14 16:32:47 --> Database Driver Class Initialized
INFO - 2024-12-14 16:32:47 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-14 16:32:47 --> Controller Class Initialized
DEBUG - 2024-12-14 16:32:47 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/login/views/login.php
DEBUG - 2024-12-14 16:32:47 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-12-14 16:32:47 --> Final output sent to browser
DEBUG - 2024-12-14 16:32:47 --> Total execution time: 0.0312
INFO - 2024-12-14 16:32:53 --> Config Class Initialized
INFO - 2024-12-14 16:32:53 --> Hooks Class Initialized
DEBUG - 2024-12-14 16:32:53 --> UTF-8 Support Enabled
INFO - 2024-12-14 16:32:53 --> Utf8 Class Initialized
INFO - 2024-12-14 16:32:53 --> URI Class Initialized
INFO - 2024-12-14 16:32:53 --> Router Class Initialized
INFO - 2024-12-14 16:32:53 --> Output Class Initialized
INFO - 2024-12-14 16:32:53 --> Security Class Initialized
DEBUG - 2024-12-14 16:32:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-14 16:32:53 --> Input Class Initialized
INFO - 2024-12-14 16:32:53 --> Language Class Initialized
INFO - 2024-12-14 16:32:53 --> Language Class Initialized
INFO - 2024-12-14 16:32:53 --> Config Class Initialized
INFO - 2024-12-14 16:32:53 --> Loader Class Initialized
INFO - 2024-12-14 16:32:53 --> Helper loaded: url_helper
INFO - 2024-12-14 16:32:53 --> Helper loaded: file_helper
INFO - 2024-12-14 16:32:53 --> Helper loaded: form_helper
INFO - 2024-12-14 16:32:53 --> Helper loaded: my_helper
INFO - 2024-12-14 16:32:53 --> Database Driver Class Initialized
INFO - 2024-12-14 16:32:53 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-14 16:32:53 --> Controller Class Initialized
INFO - 2024-12-14 16:32:53 --> Helper loaded: cookie_helper
INFO - 2024-12-14 16:32:53 --> Final output sent to browser
DEBUG - 2024-12-14 16:32:53 --> Total execution time: 0.0308
INFO - 2024-12-14 16:32:53 --> Config Class Initialized
INFO - 2024-12-14 16:32:53 --> Hooks Class Initialized
DEBUG - 2024-12-14 16:32:53 --> UTF-8 Support Enabled
INFO - 2024-12-14 16:32:53 --> Utf8 Class Initialized
INFO - 2024-12-14 16:32:53 --> URI Class Initialized
INFO - 2024-12-14 16:32:53 --> Router Class Initialized
INFO - 2024-12-14 16:32:53 --> Output Class Initialized
INFO - 2024-12-14 16:32:53 --> Security Class Initialized
DEBUG - 2024-12-14 16:32:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-14 16:32:53 --> Input Class Initialized
INFO - 2024-12-14 16:32:53 --> Language Class Initialized
INFO - 2024-12-14 16:32:53 --> Language Class Initialized
INFO - 2024-12-14 16:32:53 --> Config Class Initialized
INFO - 2024-12-14 16:32:53 --> Loader Class Initialized
INFO - 2024-12-14 16:32:53 --> Helper loaded: url_helper
INFO - 2024-12-14 16:32:53 --> Helper loaded: file_helper
INFO - 2024-12-14 16:32:53 --> Helper loaded: form_helper
INFO - 2024-12-14 16:32:53 --> Helper loaded: my_helper
INFO - 2024-12-14 16:32:53 --> Database Driver Class Initialized
INFO - 2024-12-14 16:32:53 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-14 16:32:53 --> Controller Class Initialized
DEBUG - 2024-12-14 16:32:53 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/home/views/v_home.php
DEBUG - 2024-12-14 16:32:53 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-12-14 16:32:53 --> Final output sent to browser
DEBUG - 2024-12-14 16:32:53 --> Total execution time: 0.0266
INFO - 2024-12-14 16:32:58 --> Config Class Initialized
INFO - 2024-12-14 16:32:58 --> Hooks Class Initialized
DEBUG - 2024-12-14 16:32:58 --> UTF-8 Support Enabled
INFO - 2024-12-14 16:32:58 --> Utf8 Class Initialized
INFO - 2024-12-14 16:32:58 --> URI Class Initialized
INFO - 2024-12-14 16:32:58 --> Router Class Initialized
INFO - 2024-12-14 16:32:58 --> Output Class Initialized
INFO - 2024-12-14 16:32:58 --> Security Class Initialized
DEBUG - 2024-12-14 16:32:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-14 16:32:58 --> Input Class Initialized
INFO - 2024-12-14 16:32:58 --> Language Class Initialized
INFO - 2024-12-14 16:32:58 --> Language Class Initialized
INFO - 2024-12-14 16:32:58 --> Config Class Initialized
INFO - 2024-12-14 16:32:58 --> Loader Class Initialized
INFO - 2024-12-14 16:32:58 --> Helper loaded: url_helper
INFO - 2024-12-14 16:32:58 --> Helper loaded: file_helper
INFO - 2024-12-14 16:32:58 --> Helper loaded: form_helper
INFO - 2024-12-14 16:32:58 --> Helper loaded: my_helper
INFO - 2024-12-14 16:32:58 --> Database Driver Class Initialized
INFO - 2024-12-14 16:32:58 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-14 16:32:58 --> Controller Class Initialized
DEBUG - 2024-12-14 16:32:58 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/tahun/views/list.php
DEBUG - 2024-12-14 16:32:58 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-12-14 16:32:58 --> Final output sent to browser
DEBUG - 2024-12-14 16:32:58 --> Total execution time: 0.0295
INFO - 2024-12-14 16:32:58 --> Config Class Initialized
INFO - 2024-12-14 16:32:58 --> Hooks Class Initialized
DEBUG - 2024-12-14 16:32:58 --> UTF-8 Support Enabled
INFO - 2024-12-14 16:32:58 --> Utf8 Class Initialized
INFO - 2024-12-14 16:32:58 --> URI Class Initialized
INFO - 2024-12-14 16:32:58 --> Router Class Initialized
INFO - 2024-12-14 16:32:58 --> Output Class Initialized
INFO - 2024-12-14 16:32:58 --> Security Class Initialized
DEBUG - 2024-12-14 16:32:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-14 16:32:58 --> Input Class Initialized
INFO - 2024-12-14 16:32:58 --> Language Class Initialized
ERROR - 2024-12-14 16:32:58 --> 404 Page Not Found: /index
INFO - 2024-12-14 16:32:58 --> Config Class Initialized
INFO - 2024-12-14 16:32:58 --> Hooks Class Initialized
DEBUG - 2024-12-14 16:32:58 --> UTF-8 Support Enabled
INFO - 2024-12-14 16:32:58 --> Utf8 Class Initialized
INFO - 2024-12-14 16:32:58 --> URI Class Initialized
INFO - 2024-12-14 16:32:58 --> Router Class Initialized
INFO - 2024-12-14 16:32:58 --> Output Class Initialized
INFO - 2024-12-14 16:32:58 --> Security Class Initialized
DEBUG - 2024-12-14 16:32:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-14 16:32:58 --> Input Class Initialized
INFO - 2024-12-14 16:32:58 --> Language Class Initialized
INFO - 2024-12-14 16:32:58 --> Language Class Initialized
INFO - 2024-12-14 16:32:58 --> Config Class Initialized
INFO - 2024-12-14 16:32:58 --> Loader Class Initialized
INFO - 2024-12-14 16:32:58 --> Helper loaded: url_helper
INFO - 2024-12-14 16:32:58 --> Helper loaded: file_helper
INFO - 2024-12-14 16:32:58 --> Helper loaded: form_helper
INFO - 2024-12-14 16:32:58 --> Helper loaded: my_helper
INFO - 2024-12-14 16:32:58 --> Database Driver Class Initialized
INFO - 2024-12-14 16:32:58 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-14 16:32:58 --> Controller Class Initialized
INFO - 2024-12-14 16:33:02 --> Config Class Initialized
INFO - 2024-12-14 16:33:02 --> Hooks Class Initialized
DEBUG - 2024-12-14 16:33:02 --> UTF-8 Support Enabled
INFO - 2024-12-14 16:33:02 --> Utf8 Class Initialized
INFO - 2024-12-14 16:33:02 --> URI Class Initialized
INFO - 2024-12-14 16:33:02 --> Router Class Initialized
INFO - 2024-12-14 16:33:02 --> Output Class Initialized
INFO - 2024-12-14 16:33:02 --> Security Class Initialized
DEBUG - 2024-12-14 16:33:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-14 16:33:02 --> Input Class Initialized
INFO - 2024-12-14 16:33:02 --> Language Class Initialized
INFO - 2024-12-14 16:33:02 --> Language Class Initialized
INFO - 2024-12-14 16:33:02 --> Config Class Initialized
INFO - 2024-12-14 16:33:02 --> Loader Class Initialized
INFO - 2024-12-14 16:33:02 --> Helper loaded: url_helper
INFO - 2024-12-14 16:33:02 --> Helper loaded: file_helper
INFO - 2024-12-14 16:33:02 --> Helper loaded: form_helper
INFO - 2024-12-14 16:33:02 --> Helper loaded: my_helper
INFO - 2024-12-14 16:33:02 --> Database Driver Class Initialized
INFO - 2024-12-14 16:33:02 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-14 16:33:02 --> Controller Class Initialized
INFO - 2024-12-14 16:33:02 --> Final output sent to browser
DEBUG - 2024-12-14 16:33:02 --> Total execution time: 0.0337
INFO - 2024-12-14 16:33:12 --> Config Class Initialized
INFO - 2024-12-14 16:33:12 --> Hooks Class Initialized
DEBUG - 2024-12-14 16:33:12 --> UTF-8 Support Enabled
INFO - 2024-12-14 16:33:12 --> Utf8 Class Initialized
INFO - 2024-12-14 16:33:12 --> URI Class Initialized
INFO - 2024-12-14 16:33:12 --> Router Class Initialized
INFO - 2024-12-14 16:33:12 --> Output Class Initialized
INFO - 2024-12-14 16:33:12 --> Security Class Initialized
DEBUG - 2024-12-14 16:33:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-14 16:33:12 --> Input Class Initialized
INFO - 2024-12-14 16:33:12 --> Language Class Initialized
INFO - 2024-12-14 16:33:12 --> Language Class Initialized
INFO - 2024-12-14 16:33:12 --> Config Class Initialized
INFO - 2024-12-14 16:33:12 --> Loader Class Initialized
INFO - 2024-12-14 16:33:12 --> Helper loaded: url_helper
INFO - 2024-12-14 16:33:12 --> Helper loaded: file_helper
INFO - 2024-12-14 16:33:12 --> Helper loaded: form_helper
INFO - 2024-12-14 16:33:12 --> Helper loaded: my_helper
INFO - 2024-12-14 16:33:12 --> Database Driver Class Initialized
INFO - 2024-12-14 16:33:12 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-14 16:33:12 --> Controller Class Initialized
INFO - 2024-12-14 16:33:12 --> Final output sent to browser
DEBUG - 2024-12-14 16:33:12 --> Total execution time: 0.0546
INFO - 2024-12-14 16:33:12 --> Config Class Initialized
INFO - 2024-12-14 16:33:12 --> Hooks Class Initialized
DEBUG - 2024-12-14 16:33:12 --> UTF-8 Support Enabled
INFO - 2024-12-14 16:33:12 --> Utf8 Class Initialized
INFO - 2024-12-14 16:33:12 --> URI Class Initialized
INFO - 2024-12-14 16:33:12 --> Router Class Initialized
INFO - 2024-12-14 16:33:12 --> Output Class Initialized
INFO - 2024-12-14 16:33:12 --> Security Class Initialized
DEBUG - 2024-12-14 16:33:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-14 16:33:12 --> Input Class Initialized
INFO - 2024-12-14 16:33:12 --> Language Class Initialized
ERROR - 2024-12-14 16:33:12 --> 404 Page Not Found: /index
INFO - 2024-12-14 16:33:13 --> Config Class Initialized
INFO - 2024-12-14 16:33:13 --> Hooks Class Initialized
DEBUG - 2024-12-14 16:33:13 --> UTF-8 Support Enabled
INFO - 2024-12-14 16:33:13 --> Utf8 Class Initialized
INFO - 2024-12-14 16:33:13 --> URI Class Initialized
INFO - 2024-12-14 16:33:13 --> Router Class Initialized
INFO - 2024-12-14 16:33:13 --> Output Class Initialized
INFO - 2024-12-14 16:33:13 --> Security Class Initialized
DEBUG - 2024-12-14 16:33:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-14 16:33:13 --> Input Class Initialized
INFO - 2024-12-14 16:33:13 --> Language Class Initialized
INFO - 2024-12-14 16:33:13 --> Language Class Initialized
INFO - 2024-12-14 16:33:13 --> Config Class Initialized
INFO - 2024-12-14 16:33:13 --> Loader Class Initialized
INFO - 2024-12-14 16:33:13 --> Helper loaded: url_helper
INFO - 2024-12-14 16:33:13 --> Helper loaded: file_helper
INFO - 2024-12-14 16:33:13 --> Helper loaded: form_helper
INFO - 2024-12-14 16:33:13 --> Helper loaded: my_helper
INFO - 2024-12-14 16:33:13 --> Database Driver Class Initialized
INFO - 2024-12-14 16:33:13 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-14 16:33:13 --> Controller Class Initialized
INFO - 2024-12-14 16:33:25 --> Config Class Initialized
INFO - 2024-12-14 16:33:25 --> Hooks Class Initialized
DEBUG - 2024-12-14 16:33:25 --> UTF-8 Support Enabled
INFO - 2024-12-14 16:33:25 --> Utf8 Class Initialized
INFO - 2024-12-14 16:33:25 --> URI Class Initialized
INFO - 2024-12-14 16:33:25 --> Router Class Initialized
INFO - 2024-12-14 16:33:25 --> Output Class Initialized
INFO - 2024-12-14 16:33:25 --> Security Class Initialized
DEBUG - 2024-12-14 16:33:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-14 16:33:25 --> Input Class Initialized
INFO - 2024-12-14 16:33:25 --> Language Class Initialized
INFO - 2024-12-14 16:33:25 --> Language Class Initialized
INFO - 2024-12-14 16:33:25 --> Config Class Initialized
INFO - 2024-12-14 16:33:25 --> Loader Class Initialized
INFO - 2024-12-14 16:33:25 --> Helper loaded: url_helper
INFO - 2024-12-14 16:33:25 --> Helper loaded: file_helper
INFO - 2024-12-14 16:33:25 --> Helper loaded: form_helper
INFO - 2024-12-14 16:33:25 --> Helper loaded: my_helper
INFO - 2024-12-14 16:33:25 --> Database Driver Class Initialized
INFO - 2024-12-14 16:33:25 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-14 16:33:25 --> Controller Class Initialized
INFO - 2024-12-14 16:33:25 --> Helper loaded: cookie_helper
INFO - 2024-12-14 16:33:25 --> Config Class Initialized
INFO - 2024-12-14 16:33:25 --> Hooks Class Initialized
DEBUG - 2024-12-14 16:33:25 --> UTF-8 Support Enabled
INFO - 2024-12-14 16:33:25 --> Utf8 Class Initialized
INFO - 2024-12-14 16:33:25 --> URI Class Initialized
INFO - 2024-12-14 16:33:25 --> Router Class Initialized
INFO - 2024-12-14 16:33:25 --> Output Class Initialized
INFO - 2024-12-14 16:33:25 --> Security Class Initialized
DEBUG - 2024-12-14 16:33:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-14 16:33:25 --> Input Class Initialized
INFO - 2024-12-14 16:33:25 --> Language Class Initialized
INFO - 2024-12-14 16:33:25 --> Language Class Initialized
INFO - 2024-12-14 16:33:25 --> Config Class Initialized
INFO - 2024-12-14 16:33:25 --> Loader Class Initialized
INFO - 2024-12-14 16:33:25 --> Helper loaded: url_helper
INFO - 2024-12-14 16:33:25 --> Helper loaded: file_helper
INFO - 2024-12-14 16:33:25 --> Helper loaded: form_helper
INFO - 2024-12-14 16:33:25 --> Helper loaded: my_helper
INFO - 2024-12-14 16:33:25 --> Database Driver Class Initialized
INFO - 2024-12-14 16:33:25 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-14 16:33:25 --> Controller Class Initialized
INFO - 2024-12-14 16:33:25 --> Config Class Initialized
INFO - 2024-12-14 16:33:25 --> Hooks Class Initialized
DEBUG - 2024-12-14 16:33:25 --> UTF-8 Support Enabled
INFO - 2024-12-14 16:33:25 --> Utf8 Class Initialized
INFO - 2024-12-14 16:33:25 --> URI Class Initialized
INFO - 2024-12-14 16:33:25 --> Router Class Initialized
INFO - 2024-12-14 16:33:25 --> Output Class Initialized
INFO - 2024-12-14 16:33:25 --> Security Class Initialized
DEBUG - 2024-12-14 16:33:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-14 16:33:25 --> Input Class Initialized
INFO - 2024-12-14 16:33:25 --> Language Class Initialized
INFO - 2024-12-14 16:33:25 --> Language Class Initialized
INFO - 2024-12-14 16:33:25 --> Config Class Initialized
INFO - 2024-12-14 16:33:25 --> Loader Class Initialized
INFO - 2024-12-14 16:33:25 --> Helper loaded: url_helper
INFO - 2024-12-14 16:33:25 --> Helper loaded: file_helper
INFO - 2024-12-14 16:33:25 --> Helper loaded: form_helper
INFO - 2024-12-14 16:33:25 --> Helper loaded: my_helper
INFO - 2024-12-14 16:33:25 --> Database Driver Class Initialized
INFO - 2024-12-14 16:33:25 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-14 16:33:25 --> Controller Class Initialized
DEBUG - 2024-12-14 16:33:25 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/login/views/login.php
DEBUG - 2024-12-14 16:33:25 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-12-14 16:33:25 --> Final output sent to browser
DEBUG - 2024-12-14 16:33:25 --> Total execution time: 0.0306
INFO - 2024-12-14 16:33:33 --> Config Class Initialized
INFO - 2024-12-14 16:33:33 --> Hooks Class Initialized
DEBUG - 2024-12-14 16:33:33 --> UTF-8 Support Enabled
INFO - 2024-12-14 16:33:33 --> Utf8 Class Initialized
INFO - 2024-12-14 16:33:33 --> URI Class Initialized
INFO - 2024-12-14 16:33:33 --> Router Class Initialized
INFO - 2024-12-14 16:33:33 --> Output Class Initialized
INFO - 2024-12-14 16:33:33 --> Security Class Initialized
DEBUG - 2024-12-14 16:33:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-14 16:33:33 --> Input Class Initialized
INFO - 2024-12-14 16:33:33 --> Language Class Initialized
INFO - 2024-12-14 16:33:33 --> Language Class Initialized
INFO - 2024-12-14 16:33:33 --> Config Class Initialized
INFO - 2024-12-14 16:33:33 --> Loader Class Initialized
INFO - 2024-12-14 16:33:33 --> Helper loaded: url_helper
INFO - 2024-12-14 16:33:33 --> Helper loaded: file_helper
INFO - 2024-12-14 16:33:33 --> Helper loaded: form_helper
INFO - 2024-12-14 16:33:33 --> Helper loaded: my_helper
INFO - 2024-12-14 16:33:33 --> Database Driver Class Initialized
INFO - 2024-12-14 16:33:33 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-14 16:33:33 --> Controller Class Initialized
INFO - 2024-12-14 16:33:33 --> Helper loaded: cookie_helper
INFO - 2024-12-14 16:33:33 --> Final output sent to browser
DEBUG - 2024-12-14 16:33:33 --> Total execution time: 0.0366
INFO - 2024-12-14 16:33:33 --> Config Class Initialized
INFO - 2024-12-14 16:33:33 --> Hooks Class Initialized
DEBUG - 2024-12-14 16:33:33 --> UTF-8 Support Enabled
INFO - 2024-12-14 16:33:33 --> Utf8 Class Initialized
INFO - 2024-12-14 16:33:33 --> URI Class Initialized
INFO - 2024-12-14 16:33:33 --> Router Class Initialized
INFO - 2024-12-14 16:33:33 --> Output Class Initialized
INFO - 2024-12-14 16:33:33 --> Security Class Initialized
DEBUG - 2024-12-14 16:33:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-14 16:33:33 --> Input Class Initialized
INFO - 2024-12-14 16:33:33 --> Language Class Initialized
INFO - 2024-12-14 16:33:33 --> Language Class Initialized
INFO - 2024-12-14 16:33:33 --> Config Class Initialized
INFO - 2024-12-14 16:33:33 --> Loader Class Initialized
INFO - 2024-12-14 16:33:33 --> Helper loaded: url_helper
INFO - 2024-12-14 16:33:33 --> Helper loaded: file_helper
INFO - 2024-12-14 16:33:33 --> Helper loaded: form_helper
INFO - 2024-12-14 16:33:33 --> Helper loaded: my_helper
INFO - 2024-12-14 16:33:33 --> Database Driver Class Initialized
INFO - 2024-12-14 16:33:33 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-14 16:33:33 --> Controller Class Initialized
DEBUG - 2024-12-14 16:33:33 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/home/views/v_home_guru.php
DEBUG - 2024-12-14 16:33:33 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-12-14 16:33:33 --> Final output sent to browser
DEBUG - 2024-12-14 16:33:33 --> Total execution time: 0.0359
INFO - 2024-12-14 16:34:02 --> Config Class Initialized
INFO - 2024-12-14 16:34:02 --> Hooks Class Initialized
DEBUG - 2024-12-14 16:34:02 --> UTF-8 Support Enabled
INFO - 2024-12-14 16:34:02 --> Utf8 Class Initialized
INFO - 2024-12-14 16:34:02 --> URI Class Initialized
INFO - 2024-12-14 16:34:02 --> Router Class Initialized
INFO - 2024-12-14 16:34:02 --> Output Class Initialized
INFO - 2024-12-14 16:34:02 --> Security Class Initialized
DEBUG - 2024-12-14 16:34:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-14 16:34:02 --> Input Class Initialized
INFO - 2024-12-14 16:34:02 --> Language Class Initialized
INFO - 2024-12-14 16:34:02 --> Language Class Initialized
INFO - 2024-12-14 16:34:02 --> Config Class Initialized
INFO - 2024-12-14 16:34:02 --> Loader Class Initialized
INFO - 2024-12-14 16:34:02 --> Helper loaded: url_helper
INFO - 2024-12-14 16:34:02 --> Helper loaded: file_helper
INFO - 2024-12-14 16:34:02 --> Helper loaded: form_helper
INFO - 2024-12-14 16:34:02 --> Helper loaded: my_helper
INFO - 2024-12-14 16:34:02 --> Database Driver Class Initialized
INFO - 2024-12-14 16:34:02 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-14 16:34:02 --> Controller Class Initialized
DEBUG - 2024-12-14 16:34:02 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/views/list.php
DEBUG - 2024-12-14 16:34:02 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-12-14 16:34:02 --> Final output sent to browser
DEBUG - 2024-12-14 16:34:02 --> Total execution time: 0.2110
INFO - 2024-12-14 16:34:10 --> Config Class Initialized
INFO - 2024-12-14 16:34:10 --> Hooks Class Initialized
DEBUG - 2024-12-14 16:34:10 --> UTF-8 Support Enabled
INFO - 2024-12-14 16:34:10 --> Utf8 Class Initialized
INFO - 2024-12-14 16:34:10 --> URI Class Initialized
INFO - 2024-12-14 16:34:10 --> Router Class Initialized
INFO - 2024-12-14 16:34:10 --> Output Class Initialized
INFO - 2024-12-14 16:34:10 --> Security Class Initialized
DEBUG - 2024-12-14 16:34:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-14 16:34:10 --> Input Class Initialized
INFO - 2024-12-14 16:34:10 --> Language Class Initialized
INFO - 2024-12-14 16:34:10 --> Language Class Initialized
INFO - 2024-12-14 16:34:10 --> Config Class Initialized
INFO - 2024-12-14 16:34:10 --> Loader Class Initialized
INFO - 2024-12-14 16:34:10 --> Helper loaded: url_helper
INFO - 2024-12-14 16:34:10 --> Helper loaded: file_helper
INFO - 2024-12-14 16:34:10 --> Helper loaded: form_helper
INFO - 2024-12-14 16:34:10 --> Helper loaded: my_helper
INFO - 2024-12-14 16:34:10 --> Database Driver Class Initialized
INFO - 2024-12-14 16:34:10 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-14 16:34:10 --> Controller Class Initialized
DEBUG - 2024-12-14 16:34:10 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/views/cetak_ikm.php
INFO - 2024-12-14 16:34:12 --> Final output sent to browser
DEBUG - 2024-12-14 16:34:12 --> Total execution time: 1.9543
INFO - 2024-12-14 16:35:08 --> Config Class Initialized
INFO - 2024-12-14 16:35:08 --> Hooks Class Initialized
DEBUG - 2024-12-14 16:35:08 --> UTF-8 Support Enabled
INFO - 2024-12-14 16:35:08 --> Utf8 Class Initialized
INFO - 2024-12-14 16:35:08 --> URI Class Initialized
INFO - 2024-12-14 16:35:08 --> Router Class Initialized
INFO - 2024-12-14 16:35:08 --> Output Class Initialized
INFO - 2024-12-14 16:35:08 --> Security Class Initialized
DEBUG - 2024-12-14 16:35:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-14 16:35:08 --> Input Class Initialized
INFO - 2024-12-14 16:35:08 --> Language Class Initialized
INFO - 2024-12-14 16:35:08 --> Language Class Initialized
INFO - 2024-12-14 16:35:08 --> Config Class Initialized
INFO - 2024-12-14 16:35:08 --> Loader Class Initialized
INFO - 2024-12-14 16:35:08 --> Helper loaded: url_helper
INFO - 2024-12-14 16:35:08 --> Helper loaded: file_helper
INFO - 2024-12-14 16:35:08 --> Helper loaded: form_helper
INFO - 2024-12-14 16:35:08 --> Helper loaded: my_helper
INFO - 2024-12-14 16:35:08 --> Database Driver Class Initialized
INFO - 2024-12-14 16:35:08 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-14 16:35:08 --> Controller Class Initialized
DEBUG - 2024-12-14 16:35:09 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/views/cetak_mh.php
INFO - 2024-12-14 16:35:18 --> Final output sent to browser
DEBUG - 2024-12-14 16:35:18 --> Total execution time: 9.7060
INFO - 2024-12-14 22:17:43 --> Config Class Initialized
INFO - 2024-12-14 22:17:43 --> Hooks Class Initialized
DEBUG - 2024-12-14 22:17:43 --> UTF-8 Support Enabled
INFO - 2024-12-14 22:17:43 --> Utf8 Class Initialized
INFO - 2024-12-14 22:17:43 --> URI Class Initialized
INFO - 2024-12-14 22:17:43 --> Router Class Initialized
INFO - 2024-12-14 22:17:43 --> Output Class Initialized
INFO - 2024-12-14 22:17:43 --> Security Class Initialized
DEBUG - 2024-12-14 22:17:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-14 22:17:43 --> Input Class Initialized
INFO - 2024-12-14 22:17:43 --> Language Class Initialized
INFO - 2024-12-14 22:17:43 --> Language Class Initialized
INFO - 2024-12-14 22:17:43 --> Config Class Initialized
INFO - 2024-12-14 22:17:43 --> Loader Class Initialized
INFO - 2024-12-14 22:17:43 --> Helper loaded: url_helper
INFO - 2024-12-14 22:17:43 --> Helper loaded: file_helper
INFO - 2024-12-14 22:17:43 --> Helper loaded: form_helper
INFO - 2024-12-14 22:17:43 --> Helper loaded: my_helper
INFO - 2024-12-14 22:17:43 --> Database Driver Class Initialized
INFO - 2024-12-14 22:17:43 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-14 22:17:43 --> Controller Class Initialized
INFO - 2024-12-14 22:17:43 --> Helper loaded: cookie_helper
INFO - 2024-12-14 22:17:43 --> Final output sent to browser
DEBUG - 2024-12-14 22:17:43 --> Total execution time: 0.0590
INFO - 2024-12-14 22:17:43 --> Config Class Initialized
INFO - 2024-12-14 22:17:43 --> Hooks Class Initialized
DEBUG - 2024-12-14 22:17:43 --> UTF-8 Support Enabled
INFO - 2024-12-14 22:17:43 --> Utf8 Class Initialized
INFO - 2024-12-14 22:17:43 --> URI Class Initialized
INFO - 2024-12-14 22:17:43 --> Router Class Initialized
INFO - 2024-12-14 22:17:43 --> Output Class Initialized
INFO - 2024-12-14 22:17:43 --> Security Class Initialized
DEBUG - 2024-12-14 22:17:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-14 22:17:43 --> Input Class Initialized
INFO - 2024-12-14 22:17:43 --> Language Class Initialized
INFO - 2024-12-14 22:17:43 --> Language Class Initialized
INFO - 2024-12-14 22:17:43 --> Config Class Initialized
INFO - 2024-12-14 22:17:43 --> Loader Class Initialized
INFO - 2024-12-14 22:17:43 --> Helper loaded: url_helper
INFO - 2024-12-14 22:17:43 --> Helper loaded: file_helper
INFO - 2024-12-14 22:17:43 --> Helper loaded: form_helper
INFO - 2024-12-14 22:17:43 --> Helper loaded: my_helper
INFO - 2024-12-14 22:17:43 --> Database Driver Class Initialized
INFO - 2024-12-14 22:17:43 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-14 22:17:43 --> Controller Class Initialized
INFO - 2024-12-14 22:17:43 --> Helper loaded: cookie_helper
INFO - 2024-12-14 22:17:43 --> Config Class Initialized
INFO - 2024-12-14 22:17:43 --> Hooks Class Initialized
DEBUG - 2024-12-14 22:17:43 --> UTF-8 Support Enabled
INFO - 2024-12-14 22:17:43 --> Utf8 Class Initialized
INFO - 2024-12-14 22:17:43 --> URI Class Initialized
INFO - 2024-12-14 22:17:43 --> Router Class Initialized
INFO - 2024-12-14 22:17:43 --> Output Class Initialized
INFO - 2024-12-14 22:17:43 --> Security Class Initialized
DEBUG - 2024-12-14 22:17:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-14 22:17:43 --> Input Class Initialized
INFO - 2024-12-14 22:17:43 --> Language Class Initialized
INFO - 2024-12-14 22:17:43 --> Language Class Initialized
INFO - 2024-12-14 22:17:43 --> Config Class Initialized
INFO - 2024-12-14 22:17:43 --> Loader Class Initialized
INFO - 2024-12-14 22:17:43 --> Helper loaded: url_helper
INFO - 2024-12-14 22:17:43 --> Helper loaded: file_helper
INFO - 2024-12-14 22:17:43 --> Helper loaded: form_helper
INFO - 2024-12-14 22:17:43 --> Helper loaded: my_helper
INFO - 2024-12-14 22:17:44 --> Database Driver Class Initialized
INFO - 2024-12-14 22:17:44 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-14 22:17:44 --> Controller Class Initialized
DEBUG - 2024-12-14 22:17:44 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/lihat_raport/views/list.php
DEBUG - 2024-12-14 22:17:44 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-12-14 22:17:44 --> Final output sent to browser
DEBUG - 2024-12-14 22:17:44 --> Total execution time: 0.1309
INFO - 2024-12-14 22:17:50 --> Config Class Initialized
INFO - 2024-12-14 22:17:50 --> Hooks Class Initialized
DEBUG - 2024-12-14 22:17:50 --> UTF-8 Support Enabled
INFO - 2024-12-14 22:17:50 --> Utf8 Class Initialized
INFO - 2024-12-14 22:17:50 --> URI Class Initialized
INFO - 2024-12-14 22:17:50 --> Router Class Initialized
INFO - 2024-12-14 22:17:50 --> Output Class Initialized
INFO - 2024-12-14 22:17:50 --> Security Class Initialized
DEBUG - 2024-12-14 22:17:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-14 22:17:50 --> Input Class Initialized
INFO - 2024-12-14 22:17:50 --> Language Class Initialized
INFO - 2024-12-14 22:17:50 --> Language Class Initialized
INFO - 2024-12-14 22:17:50 --> Config Class Initialized
INFO - 2024-12-14 22:17:50 --> Loader Class Initialized
INFO - 2024-12-14 22:17:50 --> Helper loaded: url_helper
INFO - 2024-12-14 22:17:50 --> Helper loaded: file_helper
INFO - 2024-12-14 22:17:50 --> Helper loaded: form_helper
INFO - 2024-12-14 22:17:50 --> Helper loaded: my_helper
INFO - 2024-12-14 22:17:50 --> Database Driver Class Initialized
INFO - 2024-12-14 22:17:50 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-14 22:17:50 --> Controller Class Initialized
DEBUG - 2024-12-14 22:17:50 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php
INFO - 2024-12-14 22:17:53 --> Final output sent to browser
DEBUG - 2024-12-14 22:17:53 --> Total execution time: 3.1215
