<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2024-06-27 12:08:21 --> Config Class Initialized
INFO - 2024-06-27 12:08:21 --> Hooks Class Initialized
DEBUG - 2024-06-27 12:08:21 --> UTF-8 Support Enabled
INFO - 2024-06-27 12:08:21 --> Utf8 Class Initialized
INFO - 2024-06-27 12:08:21 --> URI Class Initialized
INFO - 2024-06-27 12:08:21 --> Router Class Initialized
INFO - 2024-06-27 12:08:21 --> Output Class Initialized
INFO - 2024-06-27 12:08:21 --> Security Class Initialized
DEBUG - 2024-06-27 12:08:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-27 12:08:21 --> Input Class Initialized
INFO - 2024-06-27 12:08:21 --> Language Class Initialized
INFO - 2024-06-27 12:08:21 --> Language Class Initialized
INFO - 2024-06-27 12:08:21 --> Config Class Initialized
INFO - 2024-06-27 12:08:21 --> Loader Class Initialized
INFO - 2024-06-27 12:08:21 --> Helper loaded: url_helper
INFO - 2024-06-27 12:08:21 --> Helper loaded: file_helper
INFO - 2024-06-27 12:08:21 --> Helper loaded: form_helper
INFO - 2024-06-27 12:08:21 --> Helper loaded: my_helper
INFO - 2024-06-27 12:08:21 --> Database Driver Class Initialized
INFO - 2024-06-27 12:08:21 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-27 12:08:21 --> Controller Class Initialized
DEBUG - 2024-06-27 12:08:21 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/login/views/login.php
DEBUG - 2024-06-27 12:08:21 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-06-27 12:08:21 --> Final output sent to browser
DEBUG - 2024-06-27 12:08:21 --> Total execution time: 0.0534
INFO - 2024-06-27 16:21:59 --> Config Class Initialized
INFO - 2024-06-27 16:21:59 --> Hooks Class Initialized
DEBUG - 2024-06-27 16:21:59 --> UTF-8 Support Enabled
INFO - 2024-06-27 16:21:59 --> Utf8 Class Initialized
INFO - 2024-06-27 16:21:59 --> URI Class Initialized
INFO - 2024-06-27 16:21:59 --> Router Class Initialized
INFO - 2024-06-27 16:21:59 --> Output Class Initialized
INFO - 2024-06-27 16:21:59 --> Security Class Initialized
DEBUG - 2024-06-27 16:21:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-27 16:21:59 --> Input Class Initialized
INFO - 2024-06-27 16:21:59 --> Language Class Initialized
INFO - 2024-06-27 16:21:59 --> Language Class Initialized
INFO - 2024-06-27 16:21:59 --> Config Class Initialized
INFO - 2024-06-27 16:21:59 --> Loader Class Initialized
INFO - 2024-06-27 16:21:59 --> Helper loaded: url_helper
INFO - 2024-06-27 16:21:59 --> Helper loaded: file_helper
INFO - 2024-06-27 16:21:59 --> Helper loaded: form_helper
INFO - 2024-06-27 16:21:59 --> Helper loaded: my_helper
INFO - 2024-06-27 16:21:59 --> Database Driver Class Initialized
INFO - 2024-06-27 16:21:59 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-27 16:21:59 --> Controller Class Initialized
DEBUG - 2024-06-27 16:21:59 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/login/views/login.php
DEBUG - 2024-06-27 16:21:59 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-06-27 16:21:59 --> Final output sent to browser
DEBUG - 2024-06-27 16:21:59 --> Total execution time: 0.0590
