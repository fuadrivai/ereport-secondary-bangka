<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2024-08-13 10:43:54 --> Config Class Initialized
INFO - 2024-08-13 10:43:54 --> Hooks Class Initialized
DEBUG - 2024-08-13 10:43:54 --> UTF-8 Support Enabled
INFO - 2024-08-13 10:43:54 --> Utf8 Class Initialized
INFO - 2024-08-13 10:43:54 --> URI Class Initialized
INFO - 2024-08-13 10:43:54 --> Router Class Initialized
INFO - 2024-08-13 10:43:54 --> Output Class Initialized
INFO - 2024-08-13 10:43:54 --> Security Class Initialized
DEBUG - 2024-08-13 10:43:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-08-13 10:43:54 --> Input Class Initialized
INFO - 2024-08-13 10:43:54 --> Language Class Initialized
INFO - 2024-08-13 10:43:54 --> Language Class Initialized
INFO - 2024-08-13 10:43:54 --> Config Class Initialized
INFO - 2024-08-13 10:43:54 --> Loader Class Initialized
INFO - 2024-08-13 10:43:54 --> Helper loaded: url_helper
INFO - 2024-08-13 10:43:54 --> Helper loaded: file_helper
INFO - 2024-08-13 10:43:54 --> Helper loaded: form_helper
INFO - 2024-08-13 10:43:54 --> Helper loaded: my_helper
INFO - 2024-08-13 10:43:54 --> Database Driver Class Initialized
INFO - 2024-08-13 10:43:54 --> Session: Class initialized using 'files' driver.
INFO - 2024-08-13 10:43:54 --> Controller Class Initialized
INFO - 2024-08-13 10:43:54 --> Helper loaded: cookie_helper
INFO - 2024-08-13 10:43:54 --> Final output sent to browser
DEBUG - 2024-08-13 10:43:54 --> Total execution time: 0.0545
INFO - 2024-08-13 10:43:54 --> Config Class Initialized
INFO - 2024-08-13 10:43:54 --> Hooks Class Initialized
DEBUG - 2024-08-13 10:43:54 --> UTF-8 Support Enabled
INFO - 2024-08-13 10:43:54 --> Utf8 Class Initialized
INFO - 2024-08-13 10:43:54 --> URI Class Initialized
INFO - 2024-08-13 10:43:54 --> Router Class Initialized
INFO - 2024-08-13 10:43:54 --> Output Class Initialized
INFO - 2024-08-13 10:43:54 --> Security Class Initialized
DEBUG - 2024-08-13 10:43:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-08-13 10:43:54 --> Input Class Initialized
INFO - 2024-08-13 10:43:54 --> Language Class Initialized
INFO - 2024-08-13 10:43:54 --> Language Class Initialized
INFO - 2024-08-13 10:43:54 --> Config Class Initialized
INFO - 2024-08-13 10:43:54 --> Loader Class Initialized
INFO - 2024-08-13 10:43:54 --> Helper loaded: url_helper
INFO - 2024-08-13 10:43:54 --> Helper loaded: file_helper
INFO - 2024-08-13 10:43:54 --> Helper loaded: form_helper
INFO - 2024-08-13 10:43:54 --> Helper loaded: my_helper
INFO - 2024-08-13 10:43:54 --> Database Driver Class Initialized
INFO - 2024-08-13 10:43:54 --> Session: Class initialized using 'files' driver.
INFO - 2024-08-13 10:43:54 --> Controller Class Initialized
INFO - 2024-08-13 10:43:54 --> Helper loaded: cookie_helper
INFO - 2024-08-13 10:43:54 --> Config Class Initialized
INFO - 2024-08-13 10:43:54 --> Hooks Class Initialized
DEBUG - 2024-08-13 10:43:54 --> UTF-8 Support Enabled
INFO - 2024-08-13 10:43:54 --> Utf8 Class Initialized
INFO - 2024-08-13 10:43:54 --> URI Class Initialized
INFO - 2024-08-13 10:43:54 --> Router Class Initialized
INFO - 2024-08-13 10:43:54 --> Output Class Initialized
INFO - 2024-08-13 10:43:54 --> Security Class Initialized
DEBUG - 2024-08-13 10:43:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-08-13 10:43:54 --> Input Class Initialized
INFO - 2024-08-13 10:43:54 --> Language Class Initialized
INFO - 2024-08-13 10:43:54 --> Language Class Initialized
INFO - 2024-08-13 10:43:54 --> Config Class Initialized
INFO - 2024-08-13 10:43:54 --> Loader Class Initialized
INFO - 2024-08-13 10:43:54 --> Helper loaded: url_helper
INFO - 2024-08-13 10:43:54 --> Helper loaded: file_helper
INFO - 2024-08-13 10:43:54 --> Helper loaded: form_helper
INFO - 2024-08-13 10:43:54 --> Helper loaded: my_helper
INFO - 2024-08-13 10:43:54 --> Database Driver Class Initialized
INFO - 2024-08-13 10:43:54 --> Session: Class initialized using 'files' driver.
INFO - 2024-08-13 10:43:54 --> Controller Class Initialized
DEBUG - 2024-08-13 10:43:54 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/lihat_raport/views/list.php
DEBUG - 2024-08-13 10:43:54 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-08-13 10:43:54 --> Final output sent to browser
DEBUG - 2024-08-13 10:43:54 --> Total execution time: 0.0293
INFO - 2024-08-13 12:54:03 --> Config Class Initialized
INFO - 2024-08-13 12:54:03 --> Hooks Class Initialized
DEBUG - 2024-08-13 12:54:03 --> UTF-8 Support Enabled
INFO - 2024-08-13 12:54:03 --> Utf8 Class Initialized
INFO - 2024-08-13 12:54:03 --> URI Class Initialized
INFO - 2024-08-13 12:54:03 --> Router Class Initialized
INFO - 2024-08-13 12:54:03 --> Output Class Initialized
INFO - 2024-08-13 12:54:03 --> Security Class Initialized
DEBUG - 2024-08-13 12:54:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-08-13 12:54:03 --> Input Class Initialized
INFO - 2024-08-13 12:54:03 --> Language Class Initialized
INFO - 2024-08-13 12:54:03 --> Language Class Initialized
INFO - 2024-08-13 12:54:03 --> Config Class Initialized
INFO - 2024-08-13 12:54:03 --> Loader Class Initialized
INFO - 2024-08-13 12:54:03 --> Helper loaded: url_helper
INFO - 2024-08-13 12:54:03 --> Helper loaded: file_helper
INFO - 2024-08-13 12:54:03 --> Helper loaded: form_helper
INFO - 2024-08-13 12:54:03 --> Helper loaded: my_helper
INFO - 2024-08-13 12:54:03 --> Database Driver Class Initialized
INFO - 2024-08-13 12:54:03 --> Session: Class initialized using 'files' driver.
INFO - 2024-08-13 12:54:03 --> Controller Class Initialized
INFO - 2024-08-13 12:54:03 --> Helper loaded: cookie_helper
INFO - 2024-08-13 12:54:03 --> Final output sent to browser
DEBUG - 2024-08-13 12:54:03 --> Total execution time: 0.5071
INFO - 2024-08-13 12:54:04 --> Config Class Initialized
INFO - 2024-08-13 12:54:04 --> Hooks Class Initialized
DEBUG - 2024-08-13 12:54:04 --> UTF-8 Support Enabled
INFO - 2024-08-13 12:54:04 --> Utf8 Class Initialized
INFO - 2024-08-13 12:54:04 --> URI Class Initialized
INFO - 2024-08-13 12:54:04 --> Router Class Initialized
INFO - 2024-08-13 12:54:04 --> Output Class Initialized
INFO - 2024-08-13 12:54:04 --> Security Class Initialized
DEBUG - 2024-08-13 12:54:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-08-13 12:54:04 --> Input Class Initialized
INFO - 2024-08-13 12:54:04 --> Language Class Initialized
INFO - 2024-08-13 12:54:04 --> Language Class Initialized
INFO - 2024-08-13 12:54:04 --> Config Class Initialized
INFO - 2024-08-13 12:54:04 --> Loader Class Initialized
INFO - 2024-08-13 12:54:04 --> Helper loaded: url_helper
INFO - 2024-08-13 12:54:04 --> Helper loaded: file_helper
INFO - 2024-08-13 12:54:04 --> Helper loaded: form_helper
INFO - 2024-08-13 12:54:04 --> Helper loaded: my_helper
INFO - 2024-08-13 12:54:04 --> Database Driver Class Initialized
INFO - 2024-08-13 12:54:04 --> Session: Class initialized using 'files' driver.
INFO - 2024-08-13 12:54:04 --> Controller Class Initialized
INFO - 2024-08-13 12:54:04 --> Helper loaded: cookie_helper
INFO - 2024-08-13 12:54:04 --> Config Class Initialized
INFO - 2024-08-13 12:54:04 --> Hooks Class Initialized
DEBUG - 2024-08-13 12:54:04 --> UTF-8 Support Enabled
INFO - 2024-08-13 12:54:04 --> Utf8 Class Initialized
INFO - 2024-08-13 12:54:04 --> URI Class Initialized
INFO - 2024-08-13 12:54:04 --> Router Class Initialized
INFO - 2024-08-13 12:54:04 --> Output Class Initialized
INFO - 2024-08-13 12:54:04 --> Security Class Initialized
DEBUG - 2024-08-13 12:54:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-08-13 12:54:04 --> Input Class Initialized
INFO - 2024-08-13 12:54:04 --> Language Class Initialized
INFO - 2024-08-13 12:54:04 --> Language Class Initialized
INFO - 2024-08-13 12:54:04 --> Config Class Initialized
INFO - 2024-08-13 12:54:04 --> Loader Class Initialized
INFO - 2024-08-13 12:54:04 --> Helper loaded: url_helper
INFO - 2024-08-13 12:54:04 --> Helper loaded: file_helper
INFO - 2024-08-13 12:54:04 --> Helper loaded: form_helper
INFO - 2024-08-13 12:54:04 --> Helper loaded: my_helper
INFO - 2024-08-13 12:54:04 --> Database Driver Class Initialized
INFO - 2024-08-13 12:54:04 --> Session: Class initialized using 'files' driver.
INFO - 2024-08-13 12:54:04 --> Controller Class Initialized
DEBUG - 2024-08-13 12:54:04 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/lihat_raport/views/list.php
DEBUG - 2024-08-13 12:54:04 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-08-13 12:54:04 --> Final output sent to browser
DEBUG - 2024-08-13 12:54:04 --> Total execution time: 0.3740
INFO - 2024-08-13 19:33:28 --> Config Class Initialized
INFO - 2024-08-13 19:33:28 --> Hooks Class Initialized
DEBUG - 2024-08-13 19:33:28 --> UTF-8 Support Enabled
INFO - 2024-08-13 19:33:28 --> Utf8 Class Initialized
INFO - 2024-08-13 19:33:28 --> URI Class Initialized
INFO - 2024-08-13 19:33:28 --> Router Class Initialized
INFO - 2024-08-13 19:33:28 --> Output Class Initialized
INFO - 2024-08-13 19:33:28 --> Security Class Initialized
DEBUG - 2024-08-13 19:33:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-08-13 19:33:28 --> Input Class Initialized
INFO - 2024-08-13 19:33:28 --> Language Class Initialized
INFO - 2024-08-13 19:33:28 --> Language Class Initialized
INFO - 2024-08-13 19:33:28 --> Config Class Initialized
INFO - 2024-08-13 19:33:28 --> Loader Class Initialized
INFO - 2024-08-13 19:33:28 --> Helper loaded: url_helper
INFO - 2024-08-13 19:33:28 --> Helper loaded: file_helper
INFO - 2024-08-13 19:33:28 --> Helper loaded: form_helper
INFO - 2024-08-13 19:33:28 --> Helper loaded: my_helper
INFO - 2024-08-13 19:33:28 --> Database Driver Class Initialized
INFO - 2024-08-13 19:33:29 --> Session: Class initialized using 'files' driver.
INFO - 2024-08-13 19:33:29 --> Controller Class Initialized
INFO - 2024-08-13 19:33:29 --> Helper loaded: cookie_helper
INFO - 2024-08-13 19:33:29 --> Final output sent to browser
DEBUG - 2024-08-13 19:33:29 --> Total execution time: 0.0747
INFO - 2024-08-13 19:33:29 --> Config Class Initialized
INFO - 2024-08-13 19:33:29 --> Hooks Class Initialized
DEBUG - 2024-08-13 19:33:29 --> UTF-8 Support Enabled
INFO - 2024-08-13 19:33:29 --> Utf8 Class Initialized
INFO - 2024-08-13 19:33:29 --> URI Class Initialized
INFO - 2024-08-13 19:33:29 --> Router Class Initialized
INFO - 2024-08-13 19:33:29 --> Output Class Initialized
INFO - 2024-08-13 19:33:29 --> Security Class Initialized
DEBUG - 2024-08-13 19:33:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-08-13 19:33:29 --> Input Class Initialized
INFO - 2024-08-13 19:33:29 --> Language Class Initialized
INFO - 2024-08-13 19:33:29 --> Language Class Initialized
INFO - 2024-08-13 19:33:29 --> Config Class Initialized
INFO - 2024-08-13 19:33:29 --> Loader Class Initialized
INFO - 2024-08-13 19:33:29 --> Helper loaded: url_helper
INFO - 2024-08-13 19:33:29 --> Helper loaded: file_helper
INFO - 2024-08-13 19:33:29 --> Helper loaded: form_helper
INFO - 2024-08-13 19:33:29 --> Helper loaded: my_helper
INFO - 2024-08-13 19:33:29 --> Database Driver Class Initialized
INFO - 2024-08-13 19:33:29 --> Session: Class initialized using 'files' driver.
INFO - 2024-08-13 19:33:29 --> Controller Class Initialized
INFO - 2024-08-13 19:33:29 --> Helper loaded: cookie_helper
INFO - 2024-08-13 19:33:29 --> Config Class Initialized
INFO - 2024-08-13 19:33:29 --> Hooks Class Initialized
DEBUG - 2024-08-13 19:33:29 --> UTF-8 Support Enabled
INFO - 2024-08-13 19:33:29 --> Utf8 Class Initialized
INFO - 2024-08-13 19:33:29 --> URI Class Initialized
INFO - 2024-08-13 19:33:29 --> Router Class Initialized
INFO - 2024-08-13 19:33:29 --> Output Class Initialized
INFO - 2024-08-13 19:33:29 --> Security Class Initialized
DEBUG - 2024-08-13 19:33:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-08-13 19:33:29 --> Input Class Initialized
INFO - 2024-08-13 19:33:29 --> Language Class Initialized
INFO - 2024-08-13 19:33:29 --> Language Class Initialized
INFO - 2024-08-13 19:33:29 --> Config Class Initialized
INFO - 2024-08-13 19:33:29 --> Loader Class Initialized
INFO - 2024-08-13 19:33:29 --> Helper loaded: url_helper
INFO - 2024-08-13 19:33:29 --> Helper loaded: file_helper
INFO - 2024-08-13 19:33:29 --> Helper loaded: form_helper
INFO - 2024-08-13 19:33:29 --> Helper loaded: my_helper
INFO - 2024-08-13 19:33:29 --> Database Driver Class Initialized
INFO - 2024-08-13 19:33:29 --> Session: Class initialized using 'files' driver.
INFO - 2024-08-13 19:33:29 --> Controller Class Initialized
DEBUG - 2024-08-13 19:33:29 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/lihat_raport/views/list.php
DEBUG - 2024-08-13 19:33:29 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-08-13 19:33:29 --> Final output sent to browser
DEBUG - 2024-08-13 19:33:29 --> Total execution time: 0.0452
INFO - 2024-08-13 19:33:32 --> Config Class Initialized
INFO - 2024-08-13 19:33:32 --> Hooks Class Initialized
DEBUG - 2024-08-13 19:33:32 --> UTF-8 Support Enabled
INFO - 2024-08-13 19:33:32 --> Utf8 Class Initialized
INFO - 2024-08-13 19:33:32 --> URI Class Initialized
INFO - 2024-08-13 19:33:32 --> Router Class Initialized
INFO - 2024-08-13 19:33:32 --> Output Class Initialized
INFO - 2024-08-13 19:33:32 --> Security Class Initialized
DEBUG - 2024-08-13 19:33:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-08-13 19:33:32 --> Input Class Initialized
INFO - 2024-08-13 19:33:32 --> Language Class Initialized
INFO - 2024-08-13 19:33:32 --> Language Class Initialized
INFO - 2024-08-13 19:33:32 --> Config Class Initialized
INFO - 2024-08-13 19:33:32 --> Loader Class Initialized
INFO - 2024-08-13 19:33:32 --> Helper loaded: url_helper
INFO - 2024-08-13 19:33:32 --> Helper loaded: file_helper
INFO - 2024-08-13 19:33:32 --> Helper loaded: form_helper
INFO - 2024-08-13 19:33:32 --> Helper loaded: my_helper
INFO - 2024-08-13 19:33:32 --> Database Driver Class Initialized
INFO - 2024-08-13 19:33:32 --> Session: Class initialized using 'files' driver.
INFO - 2024-08-13 19:33:32 --> Controller Class Initialized
ERROR - 2024-08-13 19:33:32 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1160
ERROR - 2024-08-13 19:33:33 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1692
ERROR - 2024-08-13 19:33:33 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1729
ERROR - 2024-08-13 19:33:33 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1767
ERROR - 2024-08-13 19:33:33 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1806
ERROR - 2024-08-13 19:33:33 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1883
ERROR - 2024-08-13 19:33:33 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1962
ERROR - 2024-08-13 19:33:33 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 2042
ERROR - 2024-08-13 19:33:33 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 2122
ERROR - 2024-08-13 19:33:33 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 2202
ERROR - 2024-08-13 19:33:33 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 2277
ERROR - 2024-08-13 19:33:33 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php 32
ERROR - 2024-08-13 19:33:33 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php 32
DEBUG - 2024-08-13 19:33:33 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php
INFO - 2024-08-13 19:33:33 --> Config Class Initialized
INFO - 2024-08-13 19:33:33 --> Hooks Class Initialized
DEBUG - 2024-08-13 19:33:33 --> UTF-8 Support Enabled
INFO - 2024-08-13 19:33:33 --> Utf8 Class Initialized
INFO - 2024-08-13 19:33:33 --> URI Class Initialized
INFO - 2024-08-13 19:33:33 --> Router Class Initialized
INFO - 2024-08-13 19:33:33 --> Output Class Initialized
INFO - 2024-08-13 19:33:33 --> Security Class Initialized
DEBUG - 2024-08-13 19:33:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-08-13 19:33:33 --> Input Class Initialized
INFO - 2024-08-13 19:33:33 --> Language Class Initialized
INFO - 2024-08-13 19:33:33 --> Language Class Initialized
INFO - 2024-08-13 19:33:33 --> Config Class Initialized
INFO - 2024-08-13 19:33:33 --> Loader Class Initialized
INFO - 2024-08-13 19:33:33 --> Helper loaded: url_helper
INFO - 2024-08-13 19:33:33 --> Helper loaded: file_helper
INFO - 2024-08-13 19:33:33 --> Helper loaded: form_helper
INFO - 2024-08-13 19:33:33 --> Helper loaded: my_helper
INFO - 2024-08-13 19:33:33 --> Database Driver Class Initialized
INFO - 2024-08-13 19:33:36 --> Final output sent to browser
DEBUG - 2024-08-13 19:33:36 --> Total execution time: 3.4394
INFO - 2024-08-13 19:33:36 --> Session: Class initialized using 'files' driver.
INFO - 2024-08-13 19:33:36 --> Controller Class Initialized
ERROR - 2024-08-13 19:33:36 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1160
ERROR - 2024-08-13 19:33:36 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1692
ERROR - 2024-08-13 19:33:36 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1729
ERROR - 2024-08-13 19:33:36 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1767
ERROR - 2024-08-13 19:33:36 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1806
ERROR - 2024-08-13 19:33:36 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1883
ERROR - 2024-08-13 19:33:36 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1962
ERROR - 2024-08-13 19:33:36 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 2042
ERROR - 2024-08-13 19:33:36 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 2122
ERROR - 2024-08-13 19:33:36 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 2202
ERROR - 2024-08-13 19:33:36 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 2277
ERROR - 2024-08-13 19:33:36 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php 32
ERROR - 2024-08-13 19:33:36 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php 32
DEBUG - 2024-08-13 19:33:36 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php
INFO - 2024-08-13 19:33:39 --> Final output sent to browser
DEBUG - 2024-08-13 19:33:39 --> Total execution time: 5.3536
