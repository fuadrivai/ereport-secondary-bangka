<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2024-05-29 16:15:17 --> Config Class Initialized
INFO - 2024-05-29 16:15:17 --> Hooks Class Initialized
DEBUG - 2024-05-29 16:15:17 --> UTF-8 Support Enabled
INFO - 2024-05-29 16:15:17 --> Utf8 Class Initialized
INFO - 2024-05-29 16:15:17 --> URI Class Initialized
INFO - 2024-05-29 16:15:17 --> Router Class Initialized
INFO - 2024-05-29 16:15:17 --> Output Class Initialized
INFO - 2024-05-29 16:15:17 --> Security Class Initialized
DEBUG - 2024-05-29 16:15:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-05-29 16:15:17 --> Input Class Initialized
INFO - 2024-05-29 16:15:17 --> Language Class Initialized
INFO - 2024-05-29 16:15:17 --> Language Class Initialized
INFO - 2024-05-29 16:15:17 --> Config Class Initialized
INFO - 2024-05-29 16:15:17 --> Loader Class Initialized
INFO - 2024-05-29 16:15:17 --> Helper loaded: url_helper
INFO - 2024-05-29 16:15:17 --> Helper loaded: file_helper
INFO - 2024-05-29 16:15:17 --> Helper loaded: form_helper
INFO - 2024-05-29 16:15:17 --> Helper loaded: my_helper
INFO - 2024-05-29 16:15:17 --> Database Driver Class Initialized
INFO - 2024-05-29 16:15:17 --> Session: Class initialized using 'files' driver.
INFO - 2024-05-29 16:15:17 --> Controller Class Initialized
DEBUG - 2024-05-29 16:15:17 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/login/views/login.php
DEBUG - 2024-05-29 16:15:17 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-05-29 16:15:17 --> Final output sent to browser
DEBUG - 2024-05-29 16:15:17 --> Total execution time: 0.0557
INFO - 2024-05-29 16:16:09 --> Config Class Initialized
INFO - 2024-05-29 16:16:09 --> Hooks Class Initialized
DEBUG - 2024-05-29 16:16:09 --> UTF-8 Support Enabled
INFO - 2024-05-29 16:16:09 --> Utf8 Class Initialized
INFO - 2024-05-29 16:16:09 --> URI Class Initialized
INFO - 2024-05-29 16:16:09 --> Router Class Initialized
INFO - 2024-05-29 16:16:09 --> Output Class Initialized
INFO - 2024-05-29 16:16:09 --> Security Class Initialized
DEBUG - 2024-05-29 16:16:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-05-29 16:16:09 --> Input Class Initialized
INFO - 2024-05-29 16:16:09 --> Language Class Initialized
INFO - 2024-05-29 16:16:09 --> Language Class Initialized
INFO - 2024-05-29 16:16:09 --> Config Class Initialized
INFO - 2024-05-29 16:16:09 --> Loader Class Initialized
INFO - 2024-05-29 16:16:09 --> Helper loaded: url_helper
INFO - 2024-05-29 16:16:09 --> Helper loaded: file_helper
INFO - 2024-05-29 16:16:09 --> Helper loaded: form_helper
INFO - 2024-05-29 16:16:09 --> Helper loaded: my_helper
INFO - 2024-05-29 16:16:09 --> Database Driver Class Initialized
INFO - 2024-05-29 16:16:09 --> Session: Class initialized using 'files' driver.
INFO - 2024-05-29 16:16:09 --> Controller Class Initialized
INFO - 2024-05-29 16:16:09 --> Helper loaded: cookie_helper
INFO - 2024-05-29 16:16:09 --> Final output sent to browser
DEBUG - 2024-05-29 16:16:09 --> Total execution time: 0.0731
INFO - 2024-05-29 16:16:11 --> Config Class Initialized
INFO - 2024-05-29 16:16:11 --> Hooks Class Initialized
DEBUG - 2024-05-29 16:16:11 --> UTF-8 Support Enabled
INFO - 2024-05-29 16:16:11 --> Utf8 Class Initialized
INFO - 2024-05-29 16:16:11 --> URI Class Initialized
INFO - 2024-05-29 16:16:11 --> Router Class Initialized
INFO - 2024-05-29 16:16:11 --> Output Class Initialized
INFO - 2024-05-29 16:16:11 --> Security Class Initialized
DEBUG - 2024-05-29 16:16:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-05-29 16:16:11 --> Input Class Initialized
INFO - 2024-05-29 16:16:11 --> Language Class Initialized
INFO - 2024-05-29 16:16:11 --> Language Class Initialized
INFO - 2024-05-29 16:16:11 --> Config Class Initialized
INFO - 2024-05-29 16:16:11 --> Loader Class Initialized
INFO - 2024-05-29 16:16:11 --> Helper loaded: url_helper
INFO - 2024-05-29 16:16:11 --> Helper loaded: file_helper
INFO - 2024-05-29 16:16:11 --> Helper loaded: form_helper
INFO - 2024-05-29 16:16:11 --> Helper loaded: my_helper
INFO - 2024-05-29 16:16:11 --> Database Driver Class Initialized
INFO - 2024-05-29 16:16:11 --> Session: Class initialized using 'files' driver.
INFO - 2024-05-29 16:16:11 --> Controller Class Initialized
DEBUG - 2024-05-29 16:16:11 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/home/views/v_home_guru.php
DEBUG - 2024-05-29 16:16:11 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-05-29 16:16:11 --> Final output sent to browser
DEBUG - 2024-05-29 16:16:11 --> Total execution time: 0.0515
