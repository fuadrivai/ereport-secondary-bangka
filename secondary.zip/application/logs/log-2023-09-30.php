<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2023-09-30 10:45:48 --> Config Class Initialized
INFO - 2023-09-30 10:45:48 --> Hooks Class Initialized
DEBUG - 2023-09-30 10:45:48 --> UTF-8 Support Enabled
INFO - 2023-09-30 10:45:48 --> Utf8 Class Initialized
INFO - 2023-09-30 10:45:48 --> URI Class Initialized
INFO - 2023-09-30 10:45:48 --> Router Class Initialized
INFO - 2023-09-30 10:45:48 --> Output Class Initialized
INFO - 2023-09-30 10:45:48 --> Security Class Initialized
DEBUG - 2023-09-30 10:45:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-30 10:45:48 --> Input Class Initialized
INFO - 2023-09-30 10:45:48 --> Language Class Initialized
INFO - 2023-09-30 10:45:48 --> Language Class Initialized
INFO - 2023-09-30 10:45:48 --> Config Class Initialized
INFO - 2023-09-30 10:45:48 --> Loader Class Initialized
INFO - 2023-09-30 10:45:48 --> Helper loaded: url_helper
INFO - 2023-09-30 10:45:48 --> Helper loaded: file_helper
INFO - 2023-09-30 10:45:48 --> Helper loaded: form_helper
INFO - 2023-09-30 10:45:48 --> Helper loaded: my_helper
INFO - 2023-09-30 10:45:48 --> Database Driver Class Initialized
INFO - 2023-09-30 10:45:48 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-30 10:45:48 --> Controller Class Initialized
DEBUG - 2023-09-30 10:45:48 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_catatan_guru/views/list.php
DEBUG - 2023-09-30 10:45:48 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-09-30 10:45:48 --> Final output sent to browser
DEBUG - 2023-09-30 10:45:48 --> Total execution time: 0.6517
INFO - 2023-09-30 18:08:40 --> Config Class Initialized
INFO - 2023-09-30 18:08:40 --> Hooks Class Initialized
DEBUG - 2023-09-30 18:08:40 --> UTF-8 Support Enabled
INFO - 2023-09-30 18:08:40 --> Utf8 Class Initialized
INFO - 2023-09-30 18:08:40 --> URI Class Initialized
INFO - 2023-09-30 18:08:40 --> Router Class Initialized
INFO - 2023-09-30 18:08:40 --> Output Class Initialized
INFO - 2023-09-30 18:08:40 --> Security Class Initialized
DEBUG - 2023-09-30 18:08:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-30 18:08:40 --> Input Class Initialized
INFO - 2023-09-30 18:08:40 --> Language Class Initialized
INFO - 2023-09-30 18:08:40 --> Language Class Initialized
INFO - 2023-09-30 18:08:40 --> Config Class Initialized
INFO - 2023-09-30 18:08:40 --> Loader Class Initialized
INFO - 2023-09-30 18:08:40 --> Helper loaded: url_helper
INFO - 2023-09-30 18:08:40 --> Helper loaded: file_helper
INFO - 2023-09-30 18:08:40 --> Helper loaded: form_helper
INFO - 2023-09-30 18:08:40 --> Helper loaded: my_helper
INFO - 2023-09-30 18:08:40 --> Database Driver Class Initialized
INFO - 2023-09-30 18:08:40 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-30 18:08:40 --> Controller Class Initialized
DEBUG - 2023-09-30 18:08:40 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/login/views/login.php
DEBUG - 2023-09-30 18:08:40 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-09-30 18:08:40 --> Final output sent to browser
DEBUG - 2023-09-30 18:08:40 --> Total execution time: 0.0837
INFO - 2023-09-30 18:09:08 --> Config Class Initialized
INFO - 2023-09-30 18:09:08 --> Hooks Class Initialized
DEBUG - 2023-09-30 18:09:08 --> UTF-8 Support Enabled
INFO - 2023-09-30 18:09:08 --> Utf8 Class Initialized
INFO - 2023-09-30 18:09:08 --> URI Class Initialized
INFO - 2023-09-30 18:09:08 --> Router Class Initialized
INFO - 2023-09-30 18:09:08 --> Output Class Initialized
INFO - 2023-09-30 18:09:08 --> Security Class Initialized
DEBUG - 2023-09-30 18:09:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-30 18:09:08 --> Input Class Initialized
INFO - 2023-09-30 18:09:08 --> Language Class Initialized
INFO - 2023-09-30 18:09:08 --> Language Class Initialized
INFO - 2023-09-30 18:09:08 --> Config Class Initialized
INFO - 2023-09-30 18:09:08 --> Loader Class Initialized
INFO - 2023-09-30 18:09:08 --> Helper loaded: url_helper
INFO - 2023-09-30 18:09:08 --> Helper loaded: file_helper
INFO - 2023-09-30 18:09:08 --> Helper loaded: form_helper
INFO - 2023-09-30 18:09:08 --> Helper loaded: my_helper
INFO - 2023-09-30 18:09:08 --> Database Driver Class Initialized
INFO - 2023-09-30 18:09:08 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-30 18:09:08 --> Controller Class Initialized
INFO - 2023-09-30 18:09:08 --> Helper loaded: cookie_helper
INFO - 2023-09-30 18:09:08 --> Final output sent to browser
DEBUG - 2023-09-30 18:09:08 --> Total execution time: 0.0362
INFO - 2023-09-30 18:09:08 --> Config Class Initialized
INFO - 2023-09-30 18:09:08 --> Hooks Class Initialized
DEBUG - 2023-09-30 18:09:08 --> UTF-8 Support Enabled
INFO - 2023-09-30 18:09:08 --> Utf8 Class Initialized
INFO - 2023-09-30 18:09:08 --> URI Class Initialized
INFO - 2023-09-30 18:09:08 --> Router Class Initialized
INFO - 2023-09-30 18:09:08 --> Output Class Initialized
INFO - 2023-09-30 18:09:08 --> Security Class Initialized
DEBUG - 2023-09-30 18:09:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-30 18:09:08 --> Input Class Initialized
INFO - 2023-09-30 18:09:08 --> Language Class Initialized
INFO - 2023-09-30 18:09:08 --> Language Class Initialized
INFO - 2023-09-30 18:09:08 --> Config Class Initialized
INFO - 2023-09-30 18:09:08 --> Loader Class Initialized
INFO - 2023-09-30 18:09:08 --> Helper loaded: url_helper
INFO - 2023-09-30 18:09:08 --> Helper loaded: file_helper
INFO - 2023-09-30 18:09:08 --> Helper loaded: form_helper
INFO - 2023-09-30 18:09:08 --> Helper loaded: my_helper
INFO - 2023-09-30 18:09:08 --> Database Driver Class Initialized
INFO - 2023-09-30 18:09:08 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-30 18:09:08 --> Controller Class Initialized
DEBUG - 2023-09-30 18:09:08 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/home/views/v_home_guru.php
DEBUG - 2023-09-30 18:09:08 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-09-30 18:09:08 --> Final output sent to browser
DEBUG - 2023-09-30 18:09:08 --> Total execution time: 0.0475
INFO - 2023-09-30 18:09:37 --> Config Class Initialized
INFO - 2023-09-30 18:09:37 --> Hooks Class Initialized
DEBUG - 2023-09-30 18:09:37 --> UTF-8 Support Enabled
INFO - 2023-09-30 18:09:37 --> Utf8 Class Initialized
INFO - 2023-09-30 18:09:37 --> URI Class Initialized
INFO - 2023-09-30 18:09:37 --> Router Class Initialized
INFO - 2023-09-30 18:09:37 --> Output Class Initialized
INFO - 2023-09-30 18:09:37 --> Security Class Initialized
DEBUG - 2023-09-30 18:09:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-30 18:09:37 --> Input Class Initialized
INFO - 2023-09-30 18:09:37 --> Language Class Initialized
INFO - 2023-09-30 18:09:38 --> Language Class Initialized
INFO - 2023-09-30 18:09:38 --> Config Class Initialized
INFO - 2023-09-30 18:09:38 --> Loader Class Initialized
INFO - 2023-09-30 18:09:38 --> Helper loaded: url_helper
INFO - 2023-09-30 18:09:38 --> Helper loaded: file_helper
INFO - 2023-09-30 18:09:38 --> Helper loaded: form_helper
INFO - 2023-09-30 18:09:38 --> Helper loaded: my_helper
INFO - 2023-09-30 18:09:38 --> Database Driver Class Initialized
INFO - 2023-09-30 18:09:38 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-30 18:09:38 --> Controller Class Initialized
DEBUG - 2023-09-30 18:09:38 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/view_mapel/views/v_view_mapel.php
DEBUG - 2023-09-30 18:09:38 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-09-30 18:09:38 --> Final output sent to browser
DEBUG - 2023-09-30 18:09:38 --> Total execution time: 0.1377
INFO - 2023-09-30 18:09:41 --> Config Class Initialized
INFO - 2023-09-30 18:09:41 --> Hooks Class Initialized
DEBUG - 2023-09-30 18:09:41 --> UTF-8 Support Enabled
INFO - 2023-09-30 18:09:41 --> Utf8 Class Initialized
INFO - 2023-09-30 18:09:41 --> URI Class Initialized
INFO - 2023-09-30 18:09:41 --> Router Class Initialized
INFO - 2023-09-30 18:09:41 --> Output Class Initialized
INFO - 2023-09-30 18:09:41 --> Security Class Initialized
DEBUG - 2023-09-30 18:09:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-30 18:09:41 --> Input Class Initialized
INFO - 2023-09-30 18:09:41 --> Language Class Initialized
INFO - 2023-09-30 18:09:41 --> Language Class Initialized
INFO - 2023-09-30 18:09:41 --> Config Class Initialized
INFO - 2023-09-30 18:09:41 --> Loader Class Initialized
INFO - 2023-09-30 18:09:41 --> Helper loaded: url_helper
INFO - 2023-09-30 18:09:41 --> Helper loaded: file_helper
INFO - 2023-09-30 18:09:41 --> Helper loaded: form_helper
INFO - 2023-09-30 18:09:41 --> Helper loaded: my_helper
INFO - 2023-09-30 18:09:41 --> Database Driver Class Initialized
INFO - 2023-09-30 18:09:41 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-30 18:09:41 --> Controller Class Initialized
DEBUG - 2023-09-30 18:09:41 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/views/list.php
DEBUG - 2023-09-30 18:09:41 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-09-30 18:09:41 --> Final output sent to browser
DEBUG - 2023-09-30 18:09:41 --> Total execution time: 0.0547
INFO - 2023-09-30 18:09:42 --> Config Class Initialized
INFO - 2023-09-30 18:09:42 --> Hooks Class Initialized
DEBUG - 2023-09-30 18:09:42 --> UTF-8 Support Enabled
INFO - 2023-09-30 18:09:42 --> Utf8 Class Initialized
INFO - 2023-09-30 18:09:42 --> URI Class Initialized
INFO - 2023-09-30 18:09:42 --> Router Class Initialized
INFO - 2023-09-30 18:09:42 --> Output Class Initialized
INFO - 2023-09-30 18:09:42 --> Security Class Initialized
DEBUG - 2023-09-30 18:09:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-30 18:09:42 --> Input Class Initialized
INFO - 2023-09-30 18:09:42 --> Language Class Initialized
INFO - 2023-09-30 18:09:42 --> Language Class Initialized
INFO - 2023-09-30 18:09:42 --> Config Class Initialized
INFO - 2023-09-30 18:09:42 --> Loader Class Initialized
INFO - 2023-09-30 18:09:42 --> Helper loaded: url_helper
INFO - 2023-09-30 18:09:42 --> Helper loaded: file_helper
INFO - 2023-09-30 18:09:42 --> Helper loaded: form_helper
INFO - 2023-09-30 18:09:42 --> Helper loaded: my_helper
INFO - 2023-09-30 18:09:42 --> Database Driver Class Initialized
INFO - 2023-09-30 18:09:42 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-30 18:09:42 --> Controller Class Initialized
INFO - 2023-09-30 19:47:58 --> Config Class Initialized
INFO - 2023-09-30 19:47:58 --> Hooks Class Initialized
DEBUG - 2023-09-30 19:47:58 --> UTF-8 Support Enabled
INFO - 2023-09-30 19:47:58 --> Utf8 Class Initialized
INFO - 2023-09-30 19:47:58 --> URI Class Initialized
INFO - 2023-09-30 19:47:58 --> Router Class Initialized
INFO - 2023-09-30 19:47:58 --> Output Class Initialized
INFO - 2023-09-30 19:47:58 --> Security Class Initialized
DEBUG - 2023-09-30 19:47:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-30 19:47:58 --> Input Class Initialized
INFO - 2023-09-30 19:47:58 --> Language Class Initialized
INFO - 2023-09-30 19:47:58 --> Language Class Initialized
INFO - 2023-09-30 19:47:58 --> Config Class Initialized
INFO - 2023-09-30 19:47:58 --> Loader Class Initialized
INFO - 2023-09-30 19:47:58 --> Helper loaded: url_helper
INFO - 2023-09-30 19:47:58 --> Helper loaded: file_helper
INFO - 2023-09-30 19:47:58 --> Helper loaded: form_helper
INFO - 2023-09-30 19:47:58 --> Helper loaded: my_helper
INFO - 2023-09-30 19:47:58 --> Database Driver Class Initialized
INFO - 2023-09-30 19:47:58 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-30 19:47:58 --> Controller Class Initialized
DEBUG - 2023-09-30 19:47:58 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/login/views/login.php
DEBUG - 2023-09-30 19:47:58 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-09-30 19:47:58 --> Final output sent to browser
DEBUG - 2023-09-30 19:47:58 --> Total execution time: 0.0442
INFO - 2023-09-30 19:48:07 --> Config Class Initialized
INFO - 2023-09-30 19:48:07 --> Hooks Class Initialized
DEBUG - 2023-09-30 19:48:07 --> UTF-8 Support Enabled
INFO - 2023-09-30 19:48:07 --> Utf8 Class Initialized
INFO - 2023-09-30 19:48:07 --> URI Class Initialized
INFO - 2023-09-30 19:48:07 --> Router Class Initialized
INFO - 2023-09-30 19:48:07 --> Output Class Initialized
INFO - 2023-09-30 19:48:07 --> Security Class Initialized
DEBUG - 2023-09-30 19:48:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-30 19:48:07 --> Input Class Initialized
INFO - 2023-09-30 19:48:07 --> Language Class Initialized
INFO - 2023-09-30 19:48:07 --> Language Class Initialized
INFO - 2023-09-30 19:48:07 --> Config Class Initialized
INFO - 2023-09-30 19:48:07 --> Loader Class Initialized
INFO - 2023-09-30 19:48:07 --> Helper loaded: url_helper
INFO - 2023-09-30 19:48:07 --> Helper loaded: file_helper
INFO - 2023-09-30 19:48:07 --> Helper loaded: form_helper
INFO - 2023-09-30 19:48:07 --> Helper loaded: my_helper
INFO - 2023-09-30 19:48:07 --> Database Driver Class Initialized
INFO - 2023-09-30 19:48:07 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-30 19:48:07 --> Controller Class Initialized
INFO - 2023-09-30 19:48:07 --> Helper loaded: cookie_helper
INFO - 2023-09-30 19:48:07 --> Final output sent to browser
DEBUG - 2023-09-30 19:48:07 --> Total execution time: 0.0824
INFO - 2023-09-30 19:48:08 --> Config Class Initialized
INFO - 2023-09-30 19:48:08 --> Hooks Class Initialized
DEBUG - 2023-09-30 19:48:08 --> UTF-8 Support Enabled
INFO - 2023-09-30 19:48:08 --> Utf8 Class Initialized
INFO - 2023-09-30 19:48:08 --> URI Class Initialized
INFO - 2023-09-30 19:48:08 --> Router Class Initialized
INFO - 2023-09-30 19:48:08 --> Output Class Initialized
INFO - 2023-09-30 19:48:08 --> Security Class Initialized
DEBUG - 2023-09-30 19:48:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-30 19:48:08 --> Input Class Initialized
INFO - 2023-09-30 19:48:08 --> Language Class Initialized
INFO - 2023-09-30 19:48:08 --> Language Class Initialized
INFO - 2023-09-30 19:48:08 --> Config Class Initialized
INFO - 2023-09-30 19:48:08 --> Loader Class Initialized
INFO - 2023-09-30 19:48:08 --> Helper loaded: url_helper
INFO - 2023-09-30 19:48:08 --> Helper loaded: file_helper
INFO - 2023-09-30 19:48:08 --> Helper loaded: form_helper
INFO - 2023-09-30 19:48:08 --> Helper loaded: my_helper
INFO - 2023-09-30 19:48:08 --> Database Driver Class Initialized
INFO - 2023-09-30 19:48:08 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-30 19:48:08 --> Controller Class Initialized
DEBUG - 2023-09-30 19:48:08 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/home/views/v_home_guru.php
DEBUG - 2023-09-30 19:48:08 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-09-30 19:48:08 --> Final output sent to browser
DEBUG - 2023-09-30 19:48:08 --> Total execution time: 0.0537
INFO - 2023-09-30 19:48:18 --> Config Class Initialized
INFO - 2023-09-30 19:48:18 --> Hooks Class Initialized
DEBUG - 2023-09-30 19:48:18 --> UTF-8 Support Enabled
INFO - 2023-09-30 19:48:18 --> Utf8 Class Initialized
INFO - 2023-09-30 19:48:18 --> URI Class Initialized
INFO - 2023-09-30 19:48:18 --> Router Class Initialized
INFO - 2023-09-30 19:48:18 --> Output Class Initialized
INFO - 2023-09-30 19:48:18 --> Security Class Initialized
DEBUG - 2023-09-30 19:48:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-30 19:48:18 --> Input Class Initialized
INFO - 2023-09-30 19:48:18 --> Language Class Initialized
INFO - 2023-09-30 19:48:18 --> Language Class Initialized
INFO - 2023-09-30 19:48:18 --> Config Class Initialized
INFO - 2023-09-30 19:48:18 --> Loader Class Initialized
INFO - 2023-09-30 19:48:18 --> Helper loaded: url_helper
INFO - 2023-09-30 19:48:18 --> Helper loaded: file_helper
INFO - 2023-09-30 19:48:18 --> Helper loaded: form_helper
INFO - 2023-09-30 19:48:18 --> Helper loaded: my_helper
INFO - 2023-09-30 19:48:18 --> Database Driver Class Initialized
INFO - 2023-09-30 19:48:18 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-30 19:48:18 --> Controller Class Initialized
DEBUG - 2023-09-30 19:48:18 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/view_mapel/views/v_view_mapel.php
DEBUG - 2023-09-30 19:48:18 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-09-30 19:48:18 --> Final output sent to browser
DEBUG - 2023-09-30 19:48:18 --> Total execution time: 0.0449
INFO - 2023-09-30 19:48:25 --> Config Class Initialized
INFO - 2023-09-30 19:48:25 --> Hooks Class Initialized
DEBUG - 2023-09-30 19:48:25 --> UTF-8 Support Enabled
INFO - 2023-09-30 19:48:25 --> Utf8 Class Initialized
INFO - 2023-09-30 19:48:25 --> URI Class Initialized
INFO - 2023-09-30 19:48:25 --> Router Class Initialized
INFO - 2023-09-30 19:48:25 --> Output Class Initialized
INFO - 2023-09-30 19:48:25 --> Security Class Initialized
DEBUG - 2023-09-30 19:48:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-30 19:48:25 --> Input Class Initialized
INFO - 2023-09-30 19:48:25 --> Language Class Initialized
INFO - 2023-09-30 19:48:25 --> Language Class Initialized
INFO - 2023-09-30 19:48:25 --> Config Class Initialized
INFO - 2023-09-30 19:48:25 --> Loader Class Initialized
INFO - 2023-09-30 19:48:25 --> Helper loaded: url_helper
INFO - 2023-09-30 19:48:25 --> Helper loaded: file_helper
INFO - 2023-09-30 19:48:25 --> Helper loaded: form_helper
INFO - 2023-09-30 19:48:25 --> Helper loaded: my_helper
INFO - 2023-09-30 19:48:25 --> Database Driver Class Initialized
INFO - 2023-09-30 19:48:25 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-30 19:48:25 --> Controller Class Initialized
DEBUG - 2023-09-30 19:48:25 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/views/list.php
DEBUG - 2023-09-30 19:48:25 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-09-30 19:48:25 --> Final output sent to browser
DEBUG - 2023-09-30 19:48:25 --> Total execution time: 0.0362
INFO - 2023-09-30 19:48:26 --> Config Class Initialized
INFO - 2023-09-30 19:48:26 --> Hooks Class Initialized
DEBUG - 2023-09-30 19:48:26 --> UTF-8 Support Enabled
INFO - 2023-09-30 19:48:26 --> Utf8 Class Initialized
INFO - 2023-09-30 19:48:26 --> URI Class Initialized
INFO - 2023-09-30 19:48:26 --> Router Class Initialized
INFO - 2023-09-30 19:48:26 --> Output Class Initialized
INFO - 2023-09-30 19:48:26 --> Security Class Initialized
DEBUG - 2023-09-30 19:48:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-30 19:48:26 --> Input Class Initialized
INFO - 2023-09-30 19:48:26 --> Language Class Initialized
INFO - 2023-09-30 19:48:26 --> Language Class Initialized
INFO - 2023-09-30 19:48:26 --> Config Class Initialized
INFO - 2023-09-30 19:48:26 --> Loader Class Initialized
INFO - 2023-09-30 19:48:26 --> Helper loaded: url_helper
INFO - 2023-09-30 19:48:26 --> Helper loaded: file_helper
INFO - 2023-09-30 19:48:26 --> Helper loaded: form_helper
INFO - 2023-09-30 19:48:26 --> Helper loaded: my_helper
INFO - 2023-09-30 19:48:26 --> Database Driver Class Initialized
INFO - 2023-09-30 19:48:26 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-30 19:48:26 --> Controller Class Initialized
INFO - 2023-09-30 19:48:35 --> Config Class Initialized
INFO - 2023-09-30 19:48:35 --> Hooks Class Initialized
DEBUG - 2023-09-30 19:48:35 --> UTF-8 Support Enabled
INFO - 2023-09-30 19:48:35 --> Utf8 Class Initialized
INFO - 2023-09-30 19:48:35 --> URI Class Initialized
INFO - 2023-09-30 19:48:35 --> Router Class Initialized
INFO - 2023-09-30 19:48:35 --> Output Class Initialized
INFO - 2023-09-30 19:48:35 --> Security Class Initialized
DEBUG - 2023-09-30 19:48:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-30 19:48:35 --> Input Class Initialized
INFO - 2023-09-30 19:48:35 --> Language Class Initialized
INFO - 2023-09-30 19:48:35 --> Language Class Initialized
INFO - 2023-09-30 19:48:35 --> Config Class Initialized
INFO - 2023-09-30 19:48:35 --> Loader Class Initialized
INFO - 2023-09-30 19:48:35 --> Helper loaded: url_helper
INFO - 2023-09-30 19:48:35 --> Helper loaded: file_helper
INFO - 2023-09-30 19:48:35 --> Helper loaded: form_helper
INFO - 2023-09-30 19:48:35 --> Helper loaded: my_helper
INFO - 2023-09-30 19:48:35 --> Database Driver Class Initialized
INFO - 2023-09-30 19:48:35 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-30 19:48:35 --> Controller Class Initialized
INFO - 2023-09-30 19:48:35 --> Final output sent to browser
DEBUG - 2023-09-30 19:48:35 --> Total execution time: 0.0485
INFO - 2023-09-30 19:51:25 --> Config Class Initialized
INFO - 2023-09-30 19:51:25 --> Hooks Class Initialized
DEBUG - 2023-09-30 19:51:25 --> UTF-8 Support Enabled
INFO - 2023-09-30 19:51:25 --> Utf8 Class Initialized
INFO - 2023-09-30 19:51:25 --> URI Class Initialized
INFO - 2023-09-30 19:51:25 --> Router Class Initialized
INFO - 2023-09-30 19:51:25 --> Output Class Initialized
INFO - 2023-09-30 19:51:25 --> Security Class Initialized
DEBUG - 2023-09-30 19:51:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-30 19:51:25 --> Input Class Initialized
INFO - 2023-09-30 19:51:25 --> Language Class Initialized
INFO - 2023-09-30 19:51:25 --> Language Class Initialized
INFO - 2023-09-30 19:51:25 --> Config Class Initialized
INFO - 2023-09-30 19:51:25 --> Loader Class Initialized
INFO - 2023-09-30 19:51:25 --> Helper loaded: url_helper
INFO - 2023-09-30 19:51:25 --> Helper loaded: file_helper
INFO - 2023-09-30 19:51:25 --> Helper loaded: form_helper
INFO - 2023-09-30 19:51:25 --> Helper loaded: my_helper
INFO - 2023-09-30 19:51:25 --> Database Driver Class Initialized
INFO - 2023-09-30 19:51:25 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-30 19:51:25 --> Controller Class Initialized
DEBUG - 2023-09-30 19:51:25 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/login/views/login.php
DEBUG - 2023-09-30 19:51:25 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-09-30 19:51:25 --> Final output sent to browser
DEBUG - 2023-09-30 19:51:25 --> Total execution time: 0.0671
INFO - 2023-09-30 19:51:40 --> Config Class Initialized
INFO - 2023-09-30 19:51:40 --> Hooks Class Initialized
DEBUG - 2023-09-30 19:51:40 --> UTF-8 Support Enabled
INFO - 2023-09-30 19:51:40 --> Utf8 Class Initialized
INFO - 2023-09-30 19:51:40 --> URI Class Initialized
INFO - 2023-09-30 19:51:40 --> Router Class Initialized
INFO - 2023-09-30 19:51:40 --> Output Class Initialized
INFO - 2023-09-30 19:51:40 --> Security Class Initialized
DEBUG - 2023-09-30 19:51:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-30 19:51:40 --> Input Class Initialized
INFO - 2023-09-30 19:51:40 --> Language Class Initialized
INFO - 2023-09-30 19:51:40 --> Language Class Initialized
INFO - 2023-09-30 19:51:40 --> Config Class Initialized
INFO - 2023-09-30 19:51:40 --> Loader Class Initialized
INFO - 2023-09-30 19:51:40 --> Helper loaded: url_helper
INFO - 2023-09-30 19:51:40 --> Helper loaded: file_helper
INFO - 2023-09-30 19:51:40 --> Helper loaded: form_helper
INFO - 2023-09-30 19:51:40 --> Helper loaded: my_helper
INFO - 2023-09-30 19:51:40 --> Database Driver Class Initialized
INFO - 2023-09-30 19:51:40 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-30 19:51:40 --> Controller Class Initialized
INFO - 2023-09-30 19:51:40 --> Helper loaded: cookie_helper
INFO - 2023-09-30 19:51:40 --> Final output sent to browser
DEBUG - 2023-09-30 19:51:40 --> Total execution time: 0.0323
INFO - 2023-09-30 19:51:40 --> Config Class Initialized
INFO - 2023-09-30 19:51:40 --> Hooks Class Initialized
DEBUG - 2023-09-30 19:51:40 --> UTF-8 Support Enabled
INFO - 2023-09-30 19:51:40 --> Utf8 Class Initialized
INFO - 2023-09-30 19:51:40 --> URI Class Initialized
INFO - 2023-09-30 19:51:40 --> Router Class Initialized
INFO - 2023-09-30 19:51:40 --> Output Class Initialized
INFO - 2023-09-30 19:51:40 --> Security Class Initialized
DEBUG - 2023-09-30 19:51:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-30 19:51:40 --> Input Class Initialized
INFO - 2023-09-30 19:51:40 --> Language Class Initialized
INFO - 2023-09-30 19:51:40 --> Language Class Initialized
INFO - 2023-09-30 19:51:40 --> Config Class Initialized
INFO - 2023-09-30 19:51:40 --> Loader Class Initialized
INFO - 2023-09-30 19:51:40 --> Helper loaded: url_helper
INFO - 2023-09-30 19:51:40 --> Helper loaded: file_helper
INFO - 2023-09-30 19:51:40 --> Helper loaded: form_helper
INFO - 2023-09-30 19:51:40 --> Helper loaded: my_helper
INFO - 2023-09-30 19:51:40 --> Database Driver Class Initialized
INFO - 2023-09-30 19:51:40 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-30 19:51:40 --> Controller Class Initialized
DEBUG - 2023-09-30 19:51:40 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/home/views/v_home_guru.php
DEBUG - 2023-09-30 19:51:40 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-09-30 19:51:40 --> Final output sent to browser
DEBUG - 2023-09-30 19:51:40 --> Total execution time: 0.0397
INFO - 2023-09-30 19:51:44 --> Config Class Initialized
INFO - 2023-09-30 19:51:44 --> Hooks Class Initialized
DEBUG - 2023-09-30 19:51:44 --> UTF-8 Support Enabled
INFO - 2023-09-30 19:51:44 --> Utf8 Class Initialized
INFO - 2023-09-30 19:51:44 --> URI Class Initialized
INFO - 2023-09-30 19:51:44 --> Router Class Initialized
INFO - 2023-09-30 19:51:44 --> Output Class Initialized
INFO - 2023-09-30 19:51:44 --> Security Class Initialized
DEBUG - 2023-09-30 19:51:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-30 19:51:44 --> Input Class Initialized
INFO - 2023-09-30 19:51:44 --> Language Class Initialized
INFO - 2023-09-30 19:51:44 --> Language Class Initialized
INFO - 2023-09-30 19:51:44 --> Config Class Initialized
INFO - 2023-09-30 19:51:44 --> Loader Class Initialized
INFO - 2023-09-30 19:51:44 --> Helper loaded: url_helper
INFO - 2023-09-30 19:51:44 --> Helper loaded: file_helper
INFO - 2023-09-30 19:51:44 --> Helper loaded: form_helper
INFO - 2023-09-30 19:51:44 --> Helper loaded: my_helper
INFO - 2023-09-30 19:51:44 --> Database Driver Class Initialized
INFO - 2023-09-30 19:51:44 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-30 19:51:44 --> Controller Class Initialized
DEBUG - 2023-09-30 19:51:44 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/riwayat_mengajar/views/list.php
DEBUG - 2023-09-30 19:51:44 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-09-30 19:51:44 --> Final output sent to browser
DEBUG - 2023-09-30 19:51:44 --> Total execution time: 0.0382
INFO - 2023-09-30 19:51:48 --> Config Class Initialized
INFO - 2023-09-30 19:51:48 --> Hooks Class Initialized
DEBUG - 2023-09-30 19:51:48 --> UTF-8 Support Enabled
INFO - 2023-09-30 19:51:48 --> Utf8 Class Initialized
INFO - 2023-09-30 19:51:48 --> URI Class Initialized
INFO - 2023-09-30 19:51:48 --> Router Class Initialized
INFO - 2023-09-30 19:51:48 --> Output Class Initialized
INFO - 2023-09-30 19:51:48 --> Security Class Initialized
DEBUG - 2023-09-30 19:51:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-30 19:51:48 --> Input Class Initialized
INFO - 2023-09-30 19:51:48 --> Language Class Initialized
INFO - 2023-09-30 19:51:48 --> Language Class Initialized
INFO - 2023-09-30 19:51:48 --> Config Class Initialized
INFO - 2023-09-30 19:51:48 --> Loader Class Initialized
INFO - 2023-09-30 19:51:48 --> Helper loaded: url_helper
INFO - 2023-09-30 19:51:48 --> Helper loaded: file_helper
INFO - 2023-09-30 19:51:48 --> Helper loaded: form_helper
INFO - 2023-09-30 19:51:48 --> Helper loaded: my_helper
INFO - 2023-09-30 19:51:48 --> Database Driver Class Initialized
INFO - 2023-09-30 19:51:48 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-30 19:51:48 --> Controller Class Initialized
DEBUG - 2023-09-30 19:51:48 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/views/cetak.php
INFO - 2023-09-30 19:51:48 --> Final output sent to browser
DEBUG - 2023-09-30 19:51:48 --> Total execution time: 0.0799
INFO - 2023-09-30 19:52:21 --> Config Class Initialized
INFO - 2023-09-30 19:52:21 --> Hooks Class Initialized
DEBUG - 2023-09-30 19:52:21 --> UTF-8 Support Enabled
INFO - 2023-09-30 19:52:21 --> Utf8 Class Initialized
INFO - 2023-09-30 19:52:21 --> URI Class Initialized
INFO - 2023-09-30 19:52:21 --> Router Class Initialized
INFO - 2023-09-30 19:52:21 --> Output Class Initialized
INFO - 2023-09-30 19:52:21 --> Security Class Initialized
DEBUG - 2023-09-30 19:52:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-30 19:52:21 --> Input Class Initialized
INFO - 2023-09-30 19:52:21 --> Language Class Initialized
INFO - 2023-09-30 19:52:21 --> Language Class Initialized
INFO - 2023-09-30 19:52:21 --> Config Class Initialized
INFO - 2023-09-30 19:52:21 --> Loader Class Initialized
INFO - 2023-09-30 19:52:21 --> Helper loaded: url_helper
INFO - 2023-09-30 19:52:21 --> Helper loaded: file_helper
INFO - 2023-09-30 19:52:21 --> Helper loaded: form_helper
INFO - 2023-09-30 19:52:21 --> Helper loaded: my_helper
INFO - 2023-09-30 19:52:21 --> Database Driver Class Initialized
INFO - 2023-09-30 19:52:21 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-30 19:52:21 --> Controller Class Initialized
DEBUG - 2023-09-30 19:52:21 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_keterampilan/views/cetak.php
INFO - 2023-09-30 19:52:21 --> Final output sent to browser
DEBUG - 2023-09-30 19:52:21 --> Total execution time: 0.0416
INFO - 2023-09-30 19:52:41 --> Config Class Initialized
INFO - 2023-09-30 19:52:41 --> Hooks Class Initialized
DEBUG - 2023-09-30 19:52:41 --> UTF-8 Support Enabled
INFO - 2023-09-30 19:52:41 --> Utf8 Class Initialized
INFO - 2023-09-30 19:52:41 --> URI Class Initialized
DEBUG - 2023-09-30 19:52:41 --> No URI present. Default controller set.
INFO - 2023-09-30 19:52:41 --> Router Class Initialized
INFO - 2023-09-30 19:52:41 --> Output Class Initialized
INFO - 2023-09-30 19:52:41 --> Security Class Initialized
DEBUG - 2023-09-30 19:52:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-30 19:52:41 --> Input Class Initialized
INFO - 2023-09-30 19:52:41 --> Language Class Initialized
INFO - 2023-09-30 19:52:41 --> Language Class Initialized
INFO - 2023-09-30 19:52:41 --> Config Class Initialized
INFO - 2023-09-30 19:52:41 --> Loader Class Initialized
INFO - 2023-09-30 19:52:41 --> Helper loaded: url_helper
INFO - 2023-09-30 19:52:41 --> Helper loaded: file_helper
INFO - 2023-09-30 19:52:41 --> Helper loaded: form_helper
INFO - 2023-09-30 19:52:41 --> Helper loaded: my_helper
INFO - 2023-09-30 19:52:41 --> Database Driver Class Initialized
INFO - 2023-09-30 19:52:41 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-30 19:52:41 --> Controller Class Initialized
DEBUG - 2023-09-30 19:52:41 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/home/views/v_home_guru.php
DEBUG - 2023-09-30 19:52:41 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-09-30 19:52:41 --> Final output sent to browser
DEBUG - 2023-09-30 19:52:41 --> Total execution time: 0.0536
INFO - 2023-09-30 19:52:58 --> Config Class Initialized
INFO - 2023-09-30 19:52:58 --> Hooks Class Initialized
DEBUG - 2023-09-30 19:52:58 --> UTF-8 Support Enabled
INFO - 2023-09-30 19:52:58 --> Utf8 Class Initialized
INFO - 2023-09-30 19:52:58 --> URI Class Initialized
DEBUG - 2023-09-30 19:52:58 --> No URI present. Default controller set.
INFO - 2023-09-30 19:52:58 --> Router Class Initialized
INFO - 2023-09-30 19:52:58 --> Output Class Initialized
INFO - 2023-09-30 19:52:58 --> Security Class Initialized
DEBUG - 2023-09-30 19:52:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-30 19:52:58 --> Input Class Initialized
INFO - 2023-09-30 19:52:58 --> Language Class Initialized
INFO - 2023-09-30 19:52:58 --> Language Class Initialized
INFO - 2023-09-30 19:52:58 --> Config Class Initialized
INFO - 2023-09-30 19:52:58 --> Loader Class Initialized
INFO - 2023-09-30 19:52:58 --> Helper loaded: url_helper
INFO - 2023-09-30 19:52:58 --> Helper loaded: file_helper
INFO - 2023-09-30 19:52:58 --> Helper loaded: form_helper
INFO - 2023-09-30 19:52:58 --> Helper loaded: my_helper
INFO - 2023-09-30 19:52:58 --> Database Driver Class Initialized
INFO - 2023-09-30 19:52:58 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-30 19:52:58 --> Controller Class Initialized
DEBUG - 2023-09-30 19:52:58 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/home/views/v_home_guru.php
DEBUG - 2023-09-30 19:52:58 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-09-30 19:52:58 --> Final output sent to browser
DEBUG - 2023-09-30 19:52:58 --> Total execution time: 0.0723
INFO - 2023-09-30 19:53:01 --> Config Class Initialized
INFO - 2023-09-30 19:53:01 --> Hooks Class Initialized
DEBUG - 2023-09-30 19:53:01 --> UTF-8 Support Enabled
INFO - 2023-09-30 19:53:01 --> Utf8 Class Initialized
INFO - 2023-09-30 19:53:01 --> URI Class Initialized
INFO - 2023-09-30 19:53:01 --> Router Class Initialized
INFO - 2023-09-30 19:53:01 --> Output Class Initialized
INFO - 2023-09-30 19:53:01 --> Security Class Initialized
DEBUG - 2023-09-30 19:53:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-30 19:53:01 --> Input Class Initialized
INFO - 2023-09-30 19:53:01 --> Language Class Initialized
INFO - 2023-09-30 19:53:01 --> Language Class Initialized
INFO - 2023-09-30 19:53:01 --> Config Class Initialized
INFO - 2023-09-30 19:53:01 --> Loader Class Initialized
INFO - 2023-09-30 19:53:01 --> Helper loaded: url_helper
INFO - 2023-09-30 19:53:01 --> Helper loaded: file_helper
INFO - 2023-09-30 19:53:01 --> Helper loaded: form_helper
INFO - 2023-09-30 19:53:01 --> Helper loaded: my_helper
INFO - 2023-09-30 19:53:01 --> Database Driver Class Initialized
INFO - 2023-09-30 19:53:01 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-30 19:53:01 --> Controller Class Initialized
DEBUG - 2023-09-30 19:53:01 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/view_mapel/views/v_view_mapel.php
DEBUG - 2023-09-30 19:53:01 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-09-30 19:53:01 --> Final output sent to browser
DEBUG - 2023-09-30 19:53:01 --> Total execution time: 0.0484
INFO - 2023-09-30 19:53:05 --> Config Class Initialized
INFO - 2023-09-30 19:53:05 --> Hooks Class Initialized
DEBUG - 2023-09-30 19:53:05 --> UTF-8 Support Enabled
INFO - 2023-09-30 19:53:05 --> Utf8 Class Initialized
INFO - 2023-09-30 19:53:05 --> URI Class Initialized
INFO - 2023-09-30 19:53:05 --> Router Class Initialized
INFO - 2023-09-30 19:53:05 --> Output Class Initialized
INFO - 2023-09-30 19:53:05 --> Security Class Initialized
DEBUG - 2023-09-30 19:53:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-30 19:53:05 --> Input Class Initialized
INFO - 2023-09-30 19:53:05 --> Language Class Initialized
INFO - 2023-09-30 19:53:05 --> Language Class Initialized
INFO - 2023-09-30 19:53:05 --> Config Class Initialized
INFO - 2023-09-30 19:53:05 --> Loader Class Initialized
INFO - 2023-09-30 19:53:05 --> Helper loaded: url_helper
INFO - 2023-09-30 19:53:05 --> Helper loaded: file_helper
INFO - 2023-09-30 19:53:05 --> Helper loaded: form_helper
INFO - 2023-09-30 19:53:05 --> Helper loaded: my_helper
INFO - 2023-09-30 19:53:05 --> Database Driver Class Initialized
INFO - 2023-09-30 19:53:05 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-30 19:53:05 --> Controller Class Initialized
DEBUG - 2023-09-30 19:53:05 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_catatan_guru/views/list.php
DEBUG - 2023-09-30 19:53:05 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-09-30 19:53:05 --> Final output sent to browser
DEBUG - 2023-09-30 19:53:05 --> Total execution time: 0.0483
INFO - 2023-09-30 19:53:09 --> Config Class Initialized
INFO - 2023-09-30 19:53:09 --> Hooks Class Initialized
DEBUG - 2023-09-30 19:53:09 --> UTF-8 Support Enabled
INFO - 2023-09-30 19:53:09 --> Utf8 Class Initialized
INFO - 2023-09-30 19:53:09 --> URI Class Initialized
INFO - 2023-09-30 19:53:09 --> Router Class Initialized
INFO - 2023-09-30 19:53:09 --> Output Class Initialized
INFO - 2023-09-30 19:53:09 --> Security Class Initialized
DEBUG - 2023-09-30 19:53:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-30 19:53:09 --> Input Class Initialized
INFO - 2023-09-30 19:53:09 --> Language Class Initialized
INFO - 2023-09-30 19:53:09 --> Language Class Initialized
INFO - 2023-09-30 19:53:09 --> Config Class Initialized
INFO - 2023-09-30 19:53:09 --> Loader Class Initialized
INFO - 2023-09-30 19:53:09 --> Helper loaded: url_helper
INFO - 2023-09-30 19:53:09 --> Helper loaded: file_helper
INFO - 2023-09-30 19:53:09 --> Helper loaded: form_helper
INFO - 2023-09-30 19:53:09 --> Helper loaded: my_helper
INFO - 2023-09-30 19:53:09 --> Database Driver Class Initialized
INFO - 2023-09-30 19:53:09 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-30 19:53:09 --> Controller Class Initialized
INFO - 2023-09-30 19:53:09 --> Final output sent to browser
DEBUG - 2023-09-30 19:53:09 --> Total execution time: 0.0387
INFO - 2023-09-30 20:05:21 --> Config Class Initialized
INFO - 2023-09-30 20:05:21 --> Hooks Class Initialized
DEBUG - 2023-09-30 20:05:21 --> UTF-8 Support Enabled
INFO - 2023-09-30 20:05:21 --> Utf8 Class Initialized
INFO - 2023-09-30 20:05:21 --> URI Class Initialized
INFO - 2023-09-30 20:05:21 --> Router Class Initialized
INFO - 2023-09-30 20:05:21 --> Output Class Initialized
INFO - 2023-09-30 20:05:21 --> Security Class Initialized
DEBUG - 2023-09-30 20:05:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-30 20:05:21 --> Input Class Initialized
INFO - 2023-09-30 20:05:21 --> Language Class Initialized
INFO - 2023-09-30 20:05:21 --> Language Class Initialized
INFO - 2023-09-30 20:05:21 --> Config Class Initialized
INFO - 2023-09-30 20:05:21 --> Loader Class Initialized
INFO - 2023-09-30 20:05:21 --> Helper loaded: url_helper
INFO - 2023-09-30 20:05:21 --> Helper loaded: file_helper
INFO - 2023-09-30 20:05:21 --> Helper loaded: form_helper
INFO - 2023-09-30 20:05:21 --> Helper loaded: my_helper
INFO - 2023-09-30 20:05:21 --> Database Driver Class Initialized
INFO - 2023-09-30 20:05:21 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-30 20:05:21 --> Controller Class Initialized
INFO - 2023-09-30 21:48:15 --> Config Class Initialized
INFO - 2023-09-30 21:48:15 --> Hooks Class Initialized
DEBUG - 2023-09-30 21:48:15 --> UTF-8 Support Enabled
INFO - 2023-09-30 21:48:15 --> Utf8 Class Initialized
INFO - 2023-09-30 21:48:15 --> URI Class Initialized
INFO - 2023-09-30 21:48:15 --> Router Class Initialized
INFO - 2023-09-30 21:48:15 --> Output Class Initialized
INFO - 2023-09-30 21:48:15 --> Security Class Initialized
DEBUG - 2023-09-30 21:48:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-30 21:48:15 --> Input Class Initialized
INFO - 2023-09-30 21:48:15 --> Language Class Initialized
INFO - 2023-09-30 21:48:15 --> Language Class Initialized
INFO - 2023-09-30 21:48:15 --> Config Class Initialized
INFO - 2023-09-30 21:48:15 --> Loader Class Initialized
INFO - 2023-09-30 21:48:15 --> Helper loaded: url_helper
INFO - 2023-09-30 21:48:15 --> Helper loaded: file_helper
INFO - 2023-09-30 21:48:15 --> Helper loaded: form_helper
INFO - 2023-09-30 21:48:15 --> Helper loaded: my_helper
INFO - 2023-09-30 21:48:15 --> Database Driver Class Initialized
INFO - 2023-09-30 21:48:15 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-30 21:48:15 --> Controller Class Initialized
DEBUG - 2023-09-30 21:48:15 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_catatan_guru/views/list.php
DEBUG - 2023-09-30 21:48:15 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-09-30 21:48:15 --> Final output sent to browser
DEBUG - 2023-09-30 21:48:15 --> Total execution time: 0.0492
