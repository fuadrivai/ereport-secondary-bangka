<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2024-06-03 08:03:59 --> Config Class Initialized
INFO - 2024-06-03 08:03:59 --> Hooks Class Initialized
DEBUG - 2024-06-03 08:03:59 --> UTF-8 Support Enabled
INFO - 2024-06-03 08:03:59 --> Utf8 Class Initialized
INFO - 2024-06-03 08:03:59 --> URI Class Initialized
INFO - 2024-06-03 08:03:59 --> Router Class Initialized
INFO - 2024-06-03 08:03:59 --> Output Class Initialized
INFO - 2024-06-03 08:03:59 --> Security Class Initialized
DEBUG - 2024-06-03 08:03:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-03 08:03:59 --> Input Class Initialized
INFO - 2024-06-03 08:03:59 --> Language Class Initialized
INFO - 2024-06-03 08:03:59 --> Language Class Initialized
INFO - 2024-06-03 08:03:59 --> Config Class Initialized
INFO - 2024-06-03 08:03:59 --> Loader Class Initialized
INFO - 2024-06-03 08:03:59 --> Helper loaded: url_helper
INFO - 2024-06-03 08:03:59 --> Helper loaded: file_helper
INFO - 2024-06-03 08:03:59 --> Helper loaded: form_helper
INFO - 2024-06-03 08:03:59 --> Helper loaded: my_helper
INFO - 2024-06-03 08:03:59 --> Database Driver Class Initialized
INFO - 2024-06-03 08:03:59 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-03 08:03:59 --> Controller Class Initialized
DEBUG - 2024-06-03 08:03:59 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/views/list.php
DEBUG - 2024-06-03 08:03:59 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-06-03 08:03:59 --> Final output sent to browser
DEBUG - 2024-06-03 08:03:59 --> Total execution time: 0.0469
INFO - 2024-06-03 08:04:27 --> Config Class Initialized
INFO - 2024-06-03 08:04:27 --> Hooks Class Initialized
DEBUG - 2024-06-03 08:04:27 --> UTF-8 Support Enabled
INFO - 2024-06-03 08:04:27 --> Utf8 Class Initialized
INFO - 2024-06-03 08:04:27 --> URI Class Initialized
INFO - 2024-06-03 08:04:27 --> Router Class Initialized
INFO - 2024-06-03 08:04:27 --> Output Class Initialized
INFO - 2024-06-03 08:04:27 --> Security Class Initialized
DEBUG - 2024-06-03 08:04:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-03 08:04:27 --> Input Class Initialized
INFO - 2024-06-03 08:04:27 --> Language Class Initialized
INFO - 2024-06-03 08:04:27 --> Language Class Initialized
INFO - 2024-06-03 08:04:27 --> Config Class Initialized
INFO - 2024-06-03 08:04:27 --> Loader Class Initialized
INFO - 2024-06-03 08:04:27 --> Helper loaded: url_helper
INFO - 2024-06-03 08:04:27 --> Helper loaded: file_helper
INFO - 2024-06-03 08:04:27 --> Helper loaded: form_helper
INFO - 2024-06-03 08:04:27 --> Helper loaded: my_helper
INFO - 2024-06-03 08:04:27 --> Database Driver Class Initialized
INFO - 2024-06-03 08:04:27 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-03 08:04:27 --> Controller Class Initialized
INFO - 2024-06-03 08:41:38 --> Config Class Initialized
INFO - 2024-06-03 08:41:38 --> Hooks Class Initialized
DEBUG - 2024-06-03 08:41:38 --> UTF-8 Support Enabled
INFO - 2024-06-03 08:41:38 --> Utf8 Class Initialized
INFO - 2024-06-03 08:41:38 --> URI Class Initialized
INFO - 2024-06-03 08:41:38 --> Router Class Initialized
INFO - 2024-06-03 08:41:38 --> Output Class Initialized
INFO - 2024-06-03 08:41:38 --> Security Class Initialized
DEBUG - 2024-06-03 08:41:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-03 08:41:38 --> Input Class Initialized
INFO - 2024-06-03 08:41:38 --> Language Class Initialized
INFO - 2024-06-03 08:41:38 --> Language Class Initialized
INFO - 2024-06-03 08:41:38 --> Config Class Initialized
INFO - 2024-06-03 08:41:38 --> Loader Class Initialized
INFO - 2024-06-03 08:41:38 --> Helper loaded: url_helper
INFO - 2024-06-03 08:41:38 --> Helper loaded: file_helper
INFO - 2024-06-03 08:41:38 --> Helper loaded: form_helper
INFO - 2024-06-03 08:41:38 --> Helper loaded: my_helper
INFO - 2024-06-03 08:41:38 --> Database Driver Class Initialized
INFO - 2024-06-03 08:41:38 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-03 08:41:38 --> Controller Class Initialized
DEBUG - 2024-06-03 08:41:38 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/login/views/login.php
DEBUG - 2024-06-03 08:41:38 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-06-03 08:41:38 --> Final output sent to browser
DEBUG - 2024-06-03 08:41:38 --> Total execution time: 0.0274
INFO - 2024-06-03 15:20:35 --> Config Class Initialized
INFO - 2024-06-03 15:20:35 --> Hooks Class Initialized
DEBUG - 2024-06-03 15:20:35 --> UTF-8 Support Enabled
INFO - 2024-06-03 15:20:35 --> Utf8 Class Initialized
INFO - 2024-06-03 15:20:35 --> URI Class Initialized
INFO - 2024-06-03 15:20:35 --> Router Class Initialized
INFO - 2024-06-03 15:20:35 --> Output Class Initialized
INFO - 2024-06-03 15:20:35 --> Security Class Initialized
DEBUG - 2024-06-03 15:20:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-03 15:20:35 --> Input Class Initialized
INFO - 2024-06-03 15:20:35 --> Language Class Initialized
INFO - 2024-06-03 15:20:35 --> Language Class Initialized
INFO - 2024-06-03 15:20:35 --> Config Class Initialized
INFO - 2024-06-03 15:20:35 --> Loader Class Initialized
INFO - 2024-06-03 15:20:35 --> Helper loaded: url_helper
INFO - 2024-06-03 15:20:35 --> Helper loaded: file_helper
INFO - 2024-06-03 15:20:35 --> Helper loaded: form_helper
INFO - 2024-06-03 15:20:35 --> Helper loaded: my_helper
INFO - 2024-06-03 15:20:35 --> Database Driver Class Initialized
INFO - 2024-06-03 15:20:35 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-03 15:20:35 --> Controller Class Initialized
DEBUG - 2024-06-03 15:20:35 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/views/list.php
DEBUG - 2024-06-03 15:20:35 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-06-03 15:20:35 --> Final output sent to browser
DEBUG - 2024-06-03 15:20:35 --> Total execution time: 0.0624
INFO - 2024-06-03 15:20:36 --> Config Class Initialized
INFO - 2024-06-03 15:20:36 --> Hooks Class Initialized
DEBUG - 2024-06-03 15:20:36 --> UTF-8 Support Enabled
INFO - 2024-06-03 15:20:36 --> Utf8 Class Initialized
INFO - 2024-06-03 15:20:36 --> URI Class Initialized
INFO - 2024-06-03 15:20:36 --> Router Class Initialized
INFO - 2024-06-03 15:20:36 --> Output Class Initialized
INFO - 2024-06-03 15:20:36 --> Security Class Initialized
DEBUG - 2024-06-03 15:20:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-03 15:20:36 --> Input Class Initialized
INFO - 2024-06-03 15:20:36 --> Language Class Initialized
INFO - 2024-06-03 15:20:36 --> Language Class Initialized
INFO - 2024-06-03 15:20:36 --> Config Class Initialized
INFO - 2024-06-03 15:20:36 --> Loader Class Initialized
INFO - 2024-06-03 15:20:36 --> Helper loaded: url_helper
INFO - 2024-06-03 15:20:36 --> Helper loaded: file_helper
INFO - 2024-06-03 15:20:36 --> Helper loaded: form_helper
INFO - 2024-06-03 15:20:36 --> Helper loaded: my_helper
INFO - 2024-06-03 15:20:36 --> Database Driver Class Initialized
INFO - 2024-06-03 15:20:36 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-03 15:20:36 --> Controller Class Initialized
