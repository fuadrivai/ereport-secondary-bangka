<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2024-07-24 08:31:15 --> Config Class Initialized
INFO - 2024-07-24 08:31:15 --> Hooks Class Initialized
DEBUG - 2024-07-24 08:31:15 --> UTF-8 Support Enabled
INFO - 2024-07-24 08:31:15 --> Utf8 Class Initialized
INFO - 2024-07-24 08:31:15 --> URI Class Initialized
INFO - 2024-07-24 08:31:15 --> Router Class Initialized
INFO - 2024-07-24 08:31:15 --> Output Class Initialized
INFO - 2024-07-24 08:31:15 --> Security Class Initialized
DEBUG - 2024-07-24 08:31:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-07-24 08:31:15 --> Input Class Initialized
INFO - 2024-07-24 08:31:15 --> Language Class Initialized
INFO - 2024-07-24 08:31:15 --> Language Class Initialized
INFO - 2024-07-24 08:31:15 --> Config Class Initialized
INFO - 2024-07-24 08:31:15 --> Loader Class Initialized
INFO - 2024-07-24 08:31:15 --> Helper loaded: url_helper
INFO - 2024-07-24 08:31:15 --> Helper loaded: file_helper
INFO - 2024-07-24 08:31:15 --> Helper loaded: form_helper
INFO - 2024-07-24 08:31:15 --> Helper loaded: my_helper
INFO - 2024-07-24 08:31:15 --> Database Driver Class Initialized
INFO - 2024-07-24 08:31:15 --> Session: Class initialized using 'files' driver.
INFO - 2024-07-24 08:31:15 --> Controller Class Initialized
INFO - 2024-07-24 08:31:15 --> Helper loaded: cookie_helper
INFO - 2024-07-24 08:31:15 --> Final output sent to browser
DEBUG - 2024-07-24 08:31:15 --> Total execution time: 0.0620
INFO - 2024-07-24 08:31:15 --> Config Class Initialized
INFO - 2024-07-24 08:31:15 --> Hooks Class Initialized
DEBUG - 2024-07-24 08:31:15 --> UTF-8 Support Enabled
INFO - 2024-07-24 08:31:15 --> Utf8 Class Initialized
INFO - 2024-07-24 08:31:15 --> URI Class Initialized
INFO - 2024-07-24 08:31:15 --> Router Class Initialized
INFO - 2024-07-24 08:31:15 --> Output Class Initialized
INFO - 2024-07-24 08:31:15 --> Security Class Initialized
DEBUG - 2024-07-24 08:31:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-07-24 08:31:15 --> Input Class Initialized
INFO - 2024-07-24 08:31:15 --> Language Class Initialized
INFO - 2024-07-24 08:31:15 --> Language Class Initialized
INFO - 2024-07-24 08:31:15 --> Config Class Initialized
INFO - 2024-07-24 08:31:15 --> Loader Class Initialized
INFO - 2024-07-24 08:31:15 --> Helper loaded: url_helper
INFO - 2024-07-24 08:31:15 --> Helper loaded: file_helper
INFO - 2024-07-24 08:31:15 --> Helper loaded: form_helper
INFO - 2024-07-24 08:31:15 --> Helper loaded: my_helper
INFO - 2024-07-24 08:31:15 --> Database Driver Class Initialized
INFO - 2024-07-24 08:31:15 --> Session: Class initialized using 'files' driver.
INFO - 2024-07-24 08:31:15 --> Controller Class Initialized
INFO - 2024-07-24 08:31:15 --> Helper loaded: cookie_helper
INFO - 2024-07-24 08:31:15 --> Config Class Initialized
INFO - 2024-07-24 08:31:15 --> Hooks Class Initialized
DEBUG - 2024-07-24 08:31:15 --> UTF-8 Support Enabled
INFO - 2024-07-24 08:31:15 --> Utf8 Class Initialized
INFO - 2024-07-24 08:31:15 --> URI Class Initialized
INFO - 2024-07-24 08:31:15 --> Router Class Initialized
INFO - 2024-07-24 08:31:15 --> Output Class Initialized
INFO - 2024-07-24 08:31:15 --> Security Class Initialized
DEBUG - 2024-07-24 08:31:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-07-24 08:31:15 --> Input Class Initialized
INFO - 2024-07-24 08:31:15 --> Language Class Initialized
INFO - 2024-07-24 08:31:15 --> Language Class Initialized
INFO - 2024-07-24 08:31:15 --> Config Class Initialized
INFO - 2024-07-24 08:31:15 --> Loader Class Initialized
INFO - 2024-07-24 08:31:15 --> Helper loaded: url_helper
INFO - 2024-07-24 08:31:15 --> Helper loaded: file_helper
INFO - 2024-07-24 08:31:15 --> Helper loaded: form_helper
INFO - 2024-07-24 08:31:15 --> Helper loaded: my_helper
INFO - 2024-07-24 08:31:15 --> Database Driver Class Initialized
INFO - 2024-07-24 08:31:15 --> Session: Class initialized using 'files' driver.
INFO - 2024-07-24 08:31:15 --> Controller Class Initialized
DEBUG - 2024-07-24 08:31:15 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/lihat_raport/views/list.php
DEBUG - 2024-07-24 08:31:15 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-07-24 08:31:15 --> Final output sent to browser
DEBUG - 2024-07-24 08:31:15 --> Total execution time: 0.1011
INFO - 2024-07-24 11:37:40 --> Config Class Initialized
INFO - 2024-07-24 11:37:40 --> Hooks Class Initialized
DEBUG - 2024-07-24 11:37:40 --> UTF-8 Support Enabled
INFO - 2024-07-24 11:37:40 --> Utf8 Class Initialized
INFO - 2024-07-24 11:37:40 --> URI Class Initialized
INFO - 2024-07-24 11:37:40 --> Router Class Initialized
INFO - 2024-07-24 11:37:40 --> Output Class Initialized
INFO - 2024-07-24 11:37:40 --> Security Class Initialized
DEBUG - 2024-07-24 11:37:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-07-24 11:37:40 --> Input Class Initialized
INFO - 2024-07-24 11:37:40 --> Language Class Initialized
INFO - 2024-07-24 11:37:40 --> Language Class Initialized
INFO - 2024-07-24 11:37:40 --> Config Class Initialized
INFO - 2024-07-24 11:37:40 --> Loader Class Initialized
INFO - 2024-07-24 11:37:40 --> Helper loaded: url_helper
INFO - 2024-07-24 11:37:40 --> Helper loaded: file_helper
INFO - 2024-07-24 11:37:40 --> Helper loaded: form_helper
INFO - 2024-07-24 11:37:40 --> Helper loaded: my_helper
INFO - 2024-07-24 11:37:40 --> Database Driver Class Initialized
INFO - 2024-07-24 11:37:40 --> Session: Class initialized using 'files' driver.
INFO - 2024-07-24 11:37:40 --> Controller Class Initialized
DEBUG - 2024-07-24 11:37:40 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/set_kelas/views/list.php
DEBUG - 2024-07-24 11:37:40 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-07-24 11:37:40 --> Final output sent to browser
DEBUG - 2024-07-24 11:37:40 --> Total execution time: 0.1388
INFO - 2024-07-24 11:37:46 --> Config Class Initialized
INFO - 2024-07-24 11:37:46 --> Hooks Class Initialized
DEBUG - 2024-07-24 11:37:46 --> UTF-8 Support Enabled
INFO - 2024-07-24 11:37:46 --> Utf8 Class Initialized
INFO - 2024-07-24 11:37:46 --> URI Class Initialized
INFO - 2024-07-24 11:37:46 --> Router Class Initialized
INFO - 2024-07-24 11:37:46 --> Output Class Initialized
INFO - 2024-07-24 11:37:46 --> Security Class Initialized
DEBUG - 2024-07-24 11:37:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-07-24 11:37:46 --> Input Class Initialized
INFO - 2024-07-24 11:37:46 --> Language Class Initialized
INFO - 2024-07-24 11:37:46 --> Language Class Initialized
INFO - 2024-07-24 11:37:46 --> Config Class Initialized
INFO - 2024-07-24 11:37:46 --> Loader Class Initialized
INFO - 2024-07-24 11:37:46 --> Helper loaded: url_helper
INFO - 2024-07-24 11:37:46 --> Helper loaded: file_helper
INFO - 2024-07-24 11:37:46 --> Helper loaded: form_helper
INFO - 2024-07-24 11:37:46 --> Helper loaded: my_helper
INFO - 2024-07-24 11:37:46 --> Database Driver Class Initialized
INFO - 2024-07-24 11:37:46 --> Session: Class initialized using 'files' driver.
INFO - 2024-07-24 11:37:46 --> Controller Class Initialized
DEBUG - 2024-07-24 11:37:46 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/set_kelas/views/list.php
DEBUG - 2024-07-24 11:37:46 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-07-24 11:37:46 --> Final output sent to browser
DEBUG - 2024-07-24 11:37:46 --> Total execution time: 0.0312
INFO - 2024-07-24 11:37:54 --> Config Class Initialized
INFO - 2024-07-24 11:37:54 --> Hooks Class Initialized
DEBUG - 2024-07-24 11:37:54 --> UTF-8 Support Enabled
INFO - 2024-07-24 11:37:54 --> Utf8 Class Initialized
INFO - 2024-07-24 11:37:54 --> URI Class Initialized
DEBUG - 2024-07-24 11:37:54 --> No URI present. Default controller set.
INFO - 2024-07-24 11:37:54 --> Router Class Initialized
INFO - 2024-07-24 11:37:54 --> Output Class Initialized
INFO - 2024-07-24 11:37:54 --> Security Class Initialized
DEBUG - 2024-07-24 11:37:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-07-24 11:37:54 --> Input Class Initialized
INFO - 2024-07-24 11:37:54 --> Language Class Initialized
INFO - 2024-07-24 11:37:54 --> Language Class Initialized
INFO - 2024-07-24 11:37:54 --> Config Class Initialized
INFO - 2024-07-24 11:37:54 --> Loader Class Initialized
INFO - 2024-07-24 11:37:54 --> Helper loaded: url_helper
INFO - 2024-07-24 11:37:54 --> Helper loaded: file_helper
INFO - 2024-07-24 11:37:54 --> Helper loaded: form_helper
INFO - 2024-07-24 11:37:54 --> Helper loaded: my_helper
INFO - 2024-07-24 11:37:54 --> Database Driver Class Initialized
INFO - 2024-07-24 11:37:54 --> Session: Class initialized using 'files' driver.
INFO - 2024-07-24 11:37:54 --> Controller Class Initialized
INFO - 2024-07-24 11:37:54 --> Config Class Initialized
INFO - 2024-07-24 11:37:54 --> Hooks Class Initialized
DEBUG - 2024-07-24 11:37:54 --> UTF-8 Support Enabled
INFO - 2024-07-24 11:37:54 --> Utf8 Class Initialized
INFO - 2024-07-24 11:37:54 --> URI Class Initialized
INFO - 2024-07-24 11:37:54 --> Router Class Initialized
INFO - 2024-07-24 11:37:54 --> Output Class Initialized
INFO - 2024-07-24 11:37:54 --> Security Class Initialized
DEBUG - 2024-07-24 11:37:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-07-24 11:37:54 --> Input Class Initialized
INFO - 2024-07-24 11:37:54 --> Language Class Initialized
INFO - 2024-07-24 11:37:54 --> Language Class Initialized
INFO - 2024-07-24 11:37:54 --> Config Class Initialized
INFO - 2024-07-24 11:37:54 --> Loader Class Initialized
INFO - 2024-07-24 11:37:54 --> Helper loaded: url_helper
INFO - 2024-07-24 11:37:54 --> Helper loaded: file_helper
INFO - 2024-07-24 11:37:54 --> Helper loaded: form_helper
INFO - 2024-07-24 11:37:54 --> Helper loaded: my_helper
INFO - 2024-07-24 11:37:54 --> Database Driver Class Initialized
INFO - 2024-07-24 11:37:54 --> Session: Class initialized using 'files' driver.
INFO - 2024-07-24 11:37:54 --> Controller Class Initialized
DEBUG - 2024-07-24 11:37:54 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/login/views/login.php
DEBUG - 2024-07-24 11:37:54 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-07-24 11:37:54 --> Final output sent to browser
DEBUG - 2024-07-24 11:37:54 --> Total execution time: 0.0981
INFO - 2024-07-24 11:37:58 --> Config Class Initialized
INFO - 2024-07-24 11:37:58 --> Hooks Class Initialized
DEBUG - 2024-07-24 11:37:58 --> UTF-8 Support Enabled
INFO - 2024-07-24 11:37:58 --> Utf8 Class Initialized
INFO - 2024-07-24 11:37:58 --> URI Class Initialized
INFO - 2024-07-24 11:37:58 --> Router Class Initialized
INFO - 2024-07-24 11:37:58 --> Output Class Initialized
INFO - 2024-07-24 11:37:58 --> Security Class Initialized
DEBUG - 2024-07-24 11:37:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-07-24 11:37:58 --> Input Class Initialized
INFO - 2024-07-24 11:37:58 --> Language Class Initialized
INFO - 2024-07-24 11:37:58 --> Language Class Initialized
INFO - 2024-07-24 11:37:58 --> Config Class Initialized
INFO - 2024-07-24 11:37:58 --> Loader Class Initialized
INFO - 2024-07-24 11:37:58 --> Helper loaded: url_helper
INFO - 2024-07-24 11:37:58 --> Helper loaded: file_helper
INFO - 2024-07-24 11:37:58 --> Helper loaded: form_helper
INFO - 2024-07-24 11:37:58 --> Helper loaded: my_helper
INFO - 2024-07-24 11:37:58 --> Database Driver Class Initialized
INFO - 2024-07-24 11:37:58 --> Session: Class initialized using 'files' driver.
INFO - 2024-07-24 11:37:58 --> Controller Class Initialized
INFO - 2024-07-24 11:37:58 --> Helper loaded: cookie_helper
INFO - 2024-07-24 11:37:58 --> Final output sent to browser
DEBUG - 2024-07-24 11:37:58 --> Total execution time: 0.0359
INFO - 2024-07-24 11:37:58 --> Config Class Initialized
INFO - 2024-07-24 11:37:58 --> Hooks Class Initialized
DEBUG - 2024-07-24 11:37:58 --> UTF-8 Support Enabled
INFO - 2024-07-24 11:37:58 --> Utf8 Class Initialized
INFO - 2024-07-24 11:37:58 --> URI Class Initialized
INFO - 2024-07-24 11:37:58 --> Router Class Initialized
INFO - 2024-07-24 11:37:58 --> Output Class Initialized
INFO - 2024-07-24 11:37:58 --> Security Class Initialized
DEBUG - 2024-07-24 11:37:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-07-24 11:37:58 --> Input Class Initialized
INFO - 2024-07-24 11:37:58 --> Language Class Initialized
INFO - 2024-07-24 11:37:58 --> Language Class Initialized
INFO - 2024-07-24 11:37:58 --> Config Class Initialized
INFO - 2024-07-24 11:37:58 --> Loader Class Initialized
INFO - 2024-07-24 11:37:58 --> Helper loaded: url_helper
INFO - 2024-07-24 11:37:58 --> Helper loaded: file_helper
INFO - 2024-07-24 11:37:58 --> Helper loaded: form_helper
INFO - 2024-07-24 11:37:58 --> Helper loaded: my_helper
INFO - 2024-07-24 11:37:58 --> Database Driver Class Initialized
INFO - 2024-07-24 11:37:58 --> Session: Class initialized using 'files' driver.
INFO - 2024-07-24 11:37:58 --> Controller Class Initialized
DEBUG - 2024-07-24 11:37:58 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/home/views/v_home.php
DEBUG - 2024-07-24 11:37:58 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-07-24 11:37:58 --> Final output sent to browser
DEBUG - 2024-07-24 11:37:58 --> Total execution time: 0.0347
INFO - 2024-07-24 11:38:01 --> Config Class Initialized
INFO - 2024-07-24 11:38:01 --> Hooks Class Initialized
DEBUG - 2024-07-24 11:38:01 --> UTF-8 Support Enabled
INFO - 2024-07-24 11:38:01 --> Utf8 Class Initialized
INFO - 2024-07-24 11:38:01 --> URI Class Initialized
INFO - 2024-07-24 11:38:01 --> Router Class Initialized
INFO - 2024-07-24 11:38:01 --> Output Class Initialized
INFO - 2024-07-24 11:38:01 --> Security Class Initialized
DEBUG - 2024-07-24 11:38:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-07-24 11:38:01 --> Input Class Initialized
INFO - 2024-07-24 11:38:01 --> Language Class Initialized
INFO - 2024-07-24 11:38:01 --> Language Class Initialized
INFO - 2024-07-24 11:38:01 --> Config Class Initialized
INFO - 2024-07-24 11:38:01 --> Loader Class Initialized
INFO - 2024-07-24 11:38:01 --> Helper loaded: url_helper
INFO - 2024-07-24 11:38:01 --> Helper loaded: file_helper
INFO - 2024-07-24 11:38:01 --> Helper loaded: form_helper
INFO - 2024-07-24 11:38:01 --> Helper loaded: my_helper
INFO - 2024-07-24 11:38:01 --> Database Driver Class Initialized
INFO - 2024-07-24 11:38:01 --> Session: Class initialized using 'files' driver.
INFO - 2024-07-24 11:38:01 --> Controller Class Initialized
DEBUG - 2024-07-24 11:38:01 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/set_kelas/views/list.php
DEBUG - 2024-07-24 11:38:01 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-07-24 11:38:01 --> Final output sent to browser
DEBUG - 2024-07-24 11:38:01 --> Total execution time: 0.0536
INFO - 2024-07-24 14:42:55 --> Config Class Initialized
INFO - 2024-07-24 14:42:55 --> Hooks Class Initialized
DEBUG - 2024-07-24 14:42:55 --> UTF-8 Support Enabled
INFO - 2024-07-24 14:42:55 --> Utf8 Class Initialized
INFO - 2024-07-24 14:42:55 --> URI Class Initialized
INFO - 2024-07-24 14:42:55 --> Router Class Initialized
INFO - 2024-07-24 14:42:55 --> Output Class Initialized
INFO - 2024-07-24 14:42:55 --> Security Class Initialized
DEBUG - 2024-07-24 14:42:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-07-24 14:42:55 --> Input Class Initialized
INFO - 2024-07-24 14:42:55 --> Language Class Initialized
INFO - 2024-07-24 14:42:55 --> Language Class Initialized
INFO - 2024-07-24 14:42:55 --> Config Class Initialized
INFO - 2024-07-24 14:42:55 --> Loader Class Initialized
INFO - 2024-07-24 14:42:55 --> Helper loaded: url_helper
INFO - 2024-07-24 14:42:55 --> Helper loaded: file_helper
INFO - 2024-07-24 14:42:55 --> Helper loaded: form_helper
INFO - 2024-07-24 14:42:55 --> Helper loaded: my_helper
INFO - 2024-07-24 14:42:55 --> Database Driver Class Initialized
INFO - 2024-07-24 14:42:55 --> Session: Class initialized using 'files' driver.
INFO - 2024-07-24 14:42:55 --> Controller Class Initialized
INFO - 2024-07-24 14:42:55 --> Helper loaded: cookie_helper
INFO - 2024-07-24 14:42:55 --> Final output sent to browser
DEBUG - 2024-07-24 14:42:55 --> Total execution time: 0.0492
INFO - 2024-07-24 14:42:56 --> Config Class Initialized
INFO - 2024-07-24 14:42:56 --> Hooks Class Initialized
DEBUG - 2024-07-24 14:42:56 --> UTF-8 Support Enabled
INFO - 2024-07-24 14:42:56 --> Utf8 Class Initialized
INFO - 2024-07-24 14:42:56 --> URI Class Initialized
INFO - 2024-07-24 14:42:56 --> Router Class Initialized
INFO - 2024-07-24 14:42:56 --> Output Class Initialized
INFO - 2024-07-24 14:42:56 --> Security Class Initialized
DEBUG - 2024-07-24 14:42:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-07-24 14:42:56 --> Input Class Initialized
INFO - 2024-07-24 14:42:56 --> Language Class Initialized
INFO - 2024-07-24 14:42:56 --> Language Class Initialized
INFO - 2024-07-24 14:42:56 --> Config Class Initialized
INFO - 2024-07-24 14:42:56 --> Loader Class Initialized
INFO - 2024-07-24 14:42:56 --> Helper loaded: url_helper
INFO - 2024-07-24 14:42:56 --> Helper loaded: file_helper
INFO - 2024-07-24 14:42:56 --> Helper loaded: form_helper
INFO - 2024-07-24 14:42:56 --> Helper loaded: my_helper
INFO - 2024-07-24 14:42:56 --> Database Driver Class Initialized
INFO - 2024-07-24 14:42:56 --> Session: Class initialized using 'files' driver.
INFO - 2024-07-24 14:42:56 --> Controller Class Initialized
INFO - 2024-07-24 14:42:56 --> Helper loaded: cookie_helper
INFO - 2024-07-24 14:42:56 --> Config Class Initialized
INFO - 2024-07-24 14:42:56 --> Hooks Class Initialized
DEBUG - 2024-07-24 14:42:56 --> UTF-8 Support Enabled
INFO - 2024-07-24 14:42:56 --> Utf8 Class Initialized
INFO - 2024-07-24 14:42:56 --> URI Class Initialized
INFO - 2024-07-24 14:42:56 --> Router Class Initialized
INFO - 2024-07-24 14:42:56 --> Output Class Initialized
INFO - 2024-07-24 14:42:56 --> Security Class Initialized
DEBUG - 2024-07-24 14:42:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-07-24 14:42:56 --> Input Class Initialized
INFO - 2024-07-24 14:42:56 --> Language Class Initialized
INFO - 2024-07-24 14:42:56 --> Language Class Initialized
INFO - 2024-07-24 14:42:56 --> Config Class Initialized
INFO - 2024-07-24 14:42:56 --> Loader Class Initialized
INFO - 2024-07-24 14:42:56 --> Helper loaded: url_helper
INFO - 2024-07-24 14:42:56 --> Helper loaded: file_helper
INFO - 2024-07-24 14:42:56 --> Helper loaded: form_helper
INFO - 2024-07-24 14:42:56 --> Helper loaded: my_helper
INFO - 2024-07-24 14:42:56 --> Database Driver Class Initialized
INFO - 2024-07-24 14:42:56 --> Session: Class initialized using 'files' driver.
INFO - 2024-07-24 14:42:56 --> Controller Class Initialized
DEBUG - 2024-07-24 14:42:56 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/lihat_raport/views/list.php
DEBUG - 2024-07-24 14:42:56 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-07-24 14:42:56 --> Final output sent to browser
DEBUG - 2024-07-24 14:42:56 --> Total execution time: 0.0516
INFO - 2024-07-24 15:14:50 --> Config Class Initialized
INFO - 2024-07-24 15:14:50 --> Hooks Class Initialized
DEBUG - 2024-07-24 15:14:50 --> UTF-8 Support Enabled
INFO - 2024-07-24 15:14:50 --> Utf8 Class Initialized
INFO - 2024-07-24 15:14:50 --> URI Class Initialized
INFO - 2024-07-24 15:14:50 --> Router Class Initialized
INFO - 2024-07-24 15:14:50 --> Output Class Initialized
INFO - 2024-07-24 15:14:50 --> Security Class Initialized
DEBUG - 2024-07-24 15:14:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-07-24 15:14:50 --> Input Class Initialized
INFO - 2024-07-24 15:14:50 --> Language Class Initialized
INFO - 2024-07-24 15:14:50 --> Language Class Initialized
INFO - 2024-07-24 15:14:50 --> Config Class Initialized
INFO - 2024-07-24 15:14:50 --> Loader Class Initialized
INFO - 2024-07-24 15:14:50 --> Helper loaded: url_helper
INFO - 2024-07-24 15:14:50 --> Helper loaded: file_helper
INFO - 2024-07-24 15:14:50 --> Helper loaded: form_helper
INFO - 2024-07-24 15:14:50 --> Helper loaded: my_helper
INFO - 2024-07-24 15:14:50 --> Database Driver Class Initialized
INFO - 2024-07-24 15:14:50 --> Session: Class initialized using 'files' driver.
INFO - 2024-07-24 15:14:50 --> Controller Class Initialized
INFO - 2024-07-24 15:14:50 --> Helper loaded: cookie_helper
INFO - 2024-07-24 15:14:50 --> Final output sent to browser
DEBUG - 2024-07-24 15:14:50 --> Total execution time: 0.1339
INFO - 2024-07-24 15:14:51 --> Config Class Initialized
INFO - 2024-07-24 15:14:51 --> Hooks Class Initialized
DEBUG - 2024-07-24 15:14:51 --> UTF-8 Support Enabled
INFO - 2024-07-24 15:14:51 --> Utf8 Class Initialized
INFO - 2024-07-24 15:14:51 --> URI Class Initialized
INFO - 2024-07-24 15:14:51 --> Router Class Initialized
INFO - 2024-07-24 15:14:51 --> Output Class Initialized
INFO - 2024-07-24 15:14:51 --> Security Class Initialized
DEBUG - 2024-07-24 15:14:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-07-24 15:14:51 --> Input Class Initialized
INFO - 2024-07-24 15:14:51 --> Language Class Initialized
INFO - 2024-07-24 15:14:51 --> Language Class Initialized
INFO - 2024-07-24 15:14:51 --> Config Class Initialized
INFO - 2024-07-24 15:14:51 --> Loader Class Initialized
INFO - 2024-07-24 15:14:51 --> Helper loaded: url_helper
INFO - 2024-07-24 15:14:51 --> Helper loaded: file_helper
INFO - 2024-07-24 15:14:51 --> Helper loaded: form_helper
INFO - 2024-07-24 15:14:51 --> Helper loaded: my_helper
INFO - 2024-07-24 15:14:51 --> Database Driver Class Initialized
INFO - 2024-07-24 15:14:51 --> Session: Class initialized using 'files' driver.
INFO - 2024-07-24 15:14:51 --> Controller Class Initialized
INFO - 2024-07-24 15:14:51 --> Helper loaded: cookie_helper
INFO - 2024-07-24 15:14:51 --> Config Class Initialized
INFO - 2024-07-24 15:14:51 --> Hooks Class Initialized
DEBUG - 2024-07-24 15:14:51 --> UTF-8 Support Enabled
INFO - 2024-07-24 15:14:51 --> Utf8 Class Initialized
INFO - 2024-07-24 15:14:51 --> URI Class Initialized
INFO - 2024-07-24 15:14:51 --> Router Class Initialized
INFO - 2024-07-24 15:14:51 --> Output Class Initialized
INFO - 2024-07-24 15:14:51 --> Security Class Initialized
DEBUG - 2024-07-24 15:14:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-07-24 15:14:51 --> Input Class Initialized
INFO - 2024-07-24 15:14:51 --> Language Class Initialized
INFO - 2024-07-24 15:14:51 --> Language Class Initialized
INFO - 2024-07-24 15:14:51 --> Config Class Initialized
INFO - 2024-07-24 15:14:51 --> Loader Class Initialized
INFO - 2024-07-24 15:14:51 --> Helper loaded: url_helper
INFO - 2024-07-24 15:14:51 --> Helper loaded: file_helper
INFO - 2024-07-24 15:14:51 --> Helper loaded: form_helper
INFO - 2024-07-24 15:14:51 --> Helper loaded: my_helper
INFO - 2024-07-24 15:14:51 --> Database Driver Class Initialized
INFO - 2024-07-24 15:14:51 --> Session: Class initialized using 'files' driver.
INFO - 2024-07-24 15:14:51 --> Controller Class Initialized
DEBUG - 2024-07-24 15:14:51 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/lihat_raport/views/list.php
DEBUG - 2024-07-24 15:14:51 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-07-24 15:14:51 --> Final output sent to browser
DEBUG - 2024-07-24 15:14:51 --> Total execution time: 0.0344
INFO - 2024-07-24 15:15:03 --> Config Class Initialized
INFO - 2024-07-24 15:15:03 --> Hooks Class Initialized
DEBUG - 2024-07-24 15:15:03 --> UTF-8 Support Enabled
INFO - 2024-07-24 15:15:03 --> Utf8 Class Initialized
INFO - 2024-07-24 15:15:03 --> URI Class Initialized
INFO - 2024-07-24 15:15:03 --> Router Class Initialized
INFO - 2024-07-24 15:15:03 --> Output Class Initialized
INFO - 2024-07-24 15:15:03 --> Security Class Initialized
DEBUG - 2024-07-24 15:15:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-07-24 15:15:03 --> Input Class Initialized
INFO - 2024-07-24 15:15:03 --> Language Class Initialized
INFO - 2024-07-24 15:15:03 --> Language Class Initialized
INFO - 2024-07-24 15:15:03 --> Config Class Initialized
INFO - 2024-07-24 15:15:03 --> Loader Class Initialized
INFO - 2024-07-24 15:15:03 --> Helper loaded: url_helper
INFO - 2024-07-24 15:15:03 --> Helper loaded: file_helper
INFO - 2024-07-24 15:15:03 --> Helper loaded: form_helper
INFO - 2024-07-24 15:15:03 --> Helper loaded: my_helper
INFO - 2024-07-24 15:15:03 --> Database Driver Class Initialized
INFO - 2024-07-24 15:15:03 --> Session: Class initialized using 'files' driver.
INFO - 2024-07-24 15:15:03 --> Controller Class Initialized
DEBUG - 2024-07-24 15:15:03 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/views/cetak_tahfiz.php
INFO - 2024-07-24 15:15:08 --> Final output sent to browser
DEBUG - 2024-07-24 15:15:08 --> Total execution time: 4.5847
INFO - 2024-07-24 15:15:08 --> Config Class Initialized
INFO - 2024-07-24 15:15:08 --> Hooks Class Initialized
DEBUG - 2024-07-24 15:15:08 --> UTF-8 Support Enabled
INFO - 2024-07-24 15:15:08 --> Utf8 Class Initialized
INFO - 2024-07-24 15:15:08 --> URI Class Initialized
INFO - 2024-07-24 15:15:08 --> Router Class Initialized
INFO - 2024-07-24 15:15:08 --> Output Class Initialized
INFO - 2024-07-24 15:15:08 --> Security Class Initialized
DEBUG - 2024-07-24 15:15:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-07-24 15:15:08 --> Input Class Initialized
INFO - 2024-07-24 15:15:08 --> Language Class Initialized
INFO - 2024-07-24 15:15:08 --> Language Class Initialized
INFO - 2024-07-24 15:15:08 --> Config Class Initialized
INFO - 2024-07-24 15:15:08 --> Loader Class Initialized
INFO - 2024-07-24 15:15:08 --> Helper loaded: url_helper
INFO - 2024-07-24 15:15:08 --> Helper loaded: file_helper
INFO - 2024-07-24 15:15:08 --> Helper loaded: form_helper
INFO - 2024-07-24 15:15:08 --> Helper loaded: my_helper
INFO - 2024-07-24 15:15:08 --> Database Driver Class Initialized
INFO - 2024-07-24 15:15:08 --> Session: Class initialized using 'files' driver.
INFO - 2024-07-24 15:15:08 --> Controller Class Initialized
DEBUG - 2024-07-24 15:15:08 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/views/cetak_tahfiz.php
INFO - 2024-07-24 15:15:08 --> Config Class Initialized
INFO - 2024-07-24 15:15:08 --> Hooks Class Initialized
DEBUG - 2024-07-24 15:15:08 --> UTF-8 Support Enabled
INFO - 2024-07-24 15:15:08 --> Utf8 Class Initialized
INFO - 2024-07-24 15:15:08 --> URI Class Initialized
INFO - 2024-07-24 15:15:08 --> Router Class Initialized
INFO - 2024-07-24 15:15:08 --> Output Class Initialized
INFO - 2024-07-24 15:15:08 --> Security Class Initialized
DEBUG - 2024-07-24 15:15:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-07-24 15:15:08 --> Input Class Initialized
INFO - 2024-07-24 15:15:08 --> Language Class Initialized
INFO - 2024-07-24 15:15:08 --> Language Class Initialized
INFO - 2024-07-24 15:15:08 --> Config Class Initialized
INFO - 2024-07-24 15:15:08 --> Loader Class Initialized
INFO - 2024-07-24 15:15:08 --> Helper loaded: url_helper
INFO - 2024-07-24 15:15:08 --> Helper loaded: file_helper
INFO - 2024-07-24 15:15:08 --> Helper loaded: form_helper
INFO - 2024-07-24 15:15:08 --> Helper loaded: my_helper
INFO - 2024-07-24 15:15:08 --> Database Driver Class Initialized
INFO - 2024-07-24 15:15:11 --> Config Class Initialized
INFO - 2024-07-24 15:15:11 --> Hooks Class Initialized
DEBUG - 2024-07-24 15:15:11 --> UTF-8 Support Enabled
INFO - 2024-07-24 15:15:11 --> Utf8 Class Initialized
INFO - 2024-07-24 15:15:11 --> URI Class Initialized
INFO - 2024-07-24 15:15:11 --> Router Class Initialized
INFO - 2024-07-24 15:15:11 --> Output Class Initialized
INFO - 2024-07-24 15:15:11 --> Security Class Initialized
DEBUG - 2024-07-24 15:15:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-07-24 15:15:11 --> Input Class Initialized
INFO - 2024-07-24 15:15:11 --> Language Class Initialized
INFO - 2024-07-24 15:15:11 --> Language Class Initialized
INFO - 2024-07-24 15:15:11 --> Config Class Initialized
INFO - 2024-07-24 15:15:11 --> Loader Class Initialized
INFO - 2024-07-24 15:15:11 --> Helper loaded: url_helper
INFO - 2024-07-24 15:15:11 --> Helper loaded: file_helper
INFO - 2024-07-24 15:15:11 --> Helper loaded: form_helper
INFO - 2024-07-24 15:15:11 --> Helper loaded: my_helper
INFO - 2024-07-24 15:15:11 --> Database Driver Class Initialized
INFO - 2024-07-24 15:15:11 --> Session: Class initialized using 'files' driver.
INFO - 2024-07-24 15:15:11 --> Controller Class Initialized
DEBUG - 2024-07-24 15:15:11 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/views/cetak_tahfiz.php
INFO - 2024-07-24 15:15:14 --> Session: Class initialized using 'files' driver.
INFO - 2024-07-24 15:15:14 --> Controller Class Initialized
ERROR - 2024-07-24 15:15:14 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1156
ERROR - 2024-07-24 15:15:14 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1688
ERROR - 2024-07-24 15:15:14 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1725
ERROR - 2024-07-24 15:15:14 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1763
ERROR - 2024-07-24 15:15:14 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1802
ERROR - 2024-07-24 15:15:14 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1879
ERROR - 2024-07-24 15:15:14 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1958
ERROR - 2024-07-24 15:15:14 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 2038
ERROR - 2024-07-24 15:15:14 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 2118
ERROR - 2024-07-24 15:15:14 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 2198
ERROR - 2024-07-24 15:15:14 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 2273
ERROR - 2024-07-24 15:15:14 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php 28
ERROR - 2024-07-24 15:15:14 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php 32
ERROR - 2024-07-24 15:15:14 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php 32
ERROR - 2024-07-24 15:15:14 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php 36
ERROR - 2024-07-24 15:15:14 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php 110
ERROR - 2024-07-24 15:15:14 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php 119
ERROR - 2024-07-24 15:15:14 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php 126
DEBUG - 2024-07-24 15:15:14 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php
INFO - 2024-07-24 15:15:17 --> Final output sent to browser
DEBUG - 2024-07-24 15:15:17 --> Total execution time: 6.8400
INFO - 2024-07-24 15:15:18 --> Config Class Initialized
INFO - 2024-07-24 15:15:18 --> Hooks Class Initialized
DEBUG - 2024-07-24 15:15:18 --> UTF-8 Support Enabled
INFO - 2024-07-24 15:15:18 --> Utf8 Class Initialized
INFO - 2024-07-24 15:15:18 --> URI Class Initialized
INFO - 2024-07-24 15:15:18 --> Router Class Initialized
INFO - 2024-07-24 15:15:18 --> Output Class Initialized
INFO - 2024-07-24 15:15:18 --> Security Class Initialized
DEBUG - 2024-07-24 15:15:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-07-24 15:15:18 --> Input Class Initialized
INFO - 2024-07-24 15:15:18 --> Language Class Initialized
INFO - 2024-07-24 15:15:18 --> Language Class Initialized
INFO - 2024-07-24 15:15:18 --> Config Class Initialized
INFO - 2024-07-24 15:15:18 --> Loader Class Initialized
INFO - 2024-07-24 15:15:18 --> Helper loaded: url_helper
INFO - 2024-07-24 15:15:18 --> Helper loaded: file_helper
INFO - 2024-07-24 15:15:18 --> Helper loaded: form_helper
INFO - 2024-07-24 15:15:18 --> Helper loaded: my_helper
INFO - 2024-07-24 15:15:18 --> Database Driver Class Initialized
INFO - 2024-07-24 15:15:18 --> Session: Class initialized using 'files' driver.
INFO - 2024-07-24 15:15:18 --> Controller Class Initialized
ERROR - 2024-07-24 15:15:18 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1156
ERROR - 2024-07-24 15:15:18 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1688
ERROR - 2024-07-24 15:15:18 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1725
ERROR - 2024-07-24 15:15:18 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1763
ERROR - 2024-07-24 15:15:18 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1802
ERROR - 2024-07-24 15:15:18 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1879
ERROR - 2024-07-24 15:15:18 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1958
ERROR - 2024-07-24 15:15:18 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 2038
ERROR - 2024-07-24 15:15:18 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 2118
ERROR - 2024-07-24 15:15:18 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 2198
ERROR - 2024-07-24 15:15:18 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 2273
ERROR - 2024-07-24 15:15:18 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php 28
ERROR - 2024-07-24 15:15:18 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php 32
ERROR - 2024-07-24 15:15:18 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php 32
ERROR - 2024-07-24 15:15:18 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php 36
ERROR - 2024-07-24 15:15:18 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php 110
ERROR - 2024-07-24 15:15:18 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php 119
ERROR - 2024-07-24 15:15:18 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php 126
DEBUG - 2024-07-24 15:15:18 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php
INFO - 2024-07-24 15:15:21 --> Final output sent to browser
DEBUG - 2024-07-24 15:15:21 --> Total execution time: 3.3016
INFO - 2024-07-24 15:15:21 --> Config Class Initialized
INFO - 2024-07-24 15:15:21 --> Hooks Class Initialized
DEBUG - 2024-07-24 15:15:21 --> UTF-8 Support Enabled
INFO - 2024-07-24 15:15:21 --> Utf8 Class Initialized
INFO - 2024-07-24 15:15:21 --> URI Class Initialized
INFO - 2024-07-24 15:15:21 --> Router Class Initialized
INFO - 2024-07-24 15:15:21 --> Output Class Initialized
INFO - 2024-07-24 15:15:21 --> Security Class Initialized
DEBUG - 2024-07-24 15:15:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-07-24 15:15:21 --> Input Class Initialized
INFO - 2024-07-24 15:15:21 --> Language Class Initialized
INFO - 2024-07-24 15:15:21 --> Language Class Initialized
INFO - 2024-07-24 15:15:21 --> Config Class Initialized
INFO - 2024-07-24 15:15:21 --> Loader Class Initialized
INFO - 2024-07-24 15:15:21 --> Helper loaded: url_helper
INFO - 2024-07-24 15:15:21 --> Helper loaded: file_helper
INFO - 2024-07-24 15:15:21 --> Helper loaded: form_helper
INFO - 2024-07-24 15:15:21 --> Helper loaded: my_helper
INFO - 2024-07-24 15:15:21 --> Database Driver Class Initialized
INFO - 2024-07-24 15:15:21 --> Session: Class initialized using 'files' driver.
INFO - 2024-07-24 15:15:21 --> Controller Class Initialized
ERROR - 2024-07-24 15:15:21 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1156
ERROR - 2024-07-24 15:15:21 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1688
ERROR - 2024-07-24 15:15:21 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1725
ERROR - 2024-07-24 15:15:21 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1763
ERROR - 2024-07-24 15:15:21 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1802
ERROR - 2024-07-24 15:15:21 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1879
ERROR - 2024-07-24 15:15:21 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1958
ERROR - 2024-07-24 15:15:21 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 2038
ERROR - 2024-07-24 15:15:21 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 2118
ERROR - 2024-07-24 15:15:21 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 2198
ERROR - 2024-07-24 15:15:21 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 2273
ERROR - 2024-07-24 15:15:21 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php 28
ERROR - 2024-07-24 15:15:21 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php 32
ERROR - 2024-07-24 15:15:21 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php 32
ERROR - 2024-07-24 15:15:21 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php 36
ERROR - 2024-07-24 15:15:21 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php 110
ERROR - 2024-07-24 15:15:21 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php 119
ERROR - 2024-07-24 15:15:21 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php 126
DEBUG - 2024-07-24 15:15:21 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php
INFO - 2024-07-24 15:15:24 --> Final output sent to browser
DEBUG - 2024-07-24 15:15:24 --> Total execution time: 2.9932
INFO - 2024-07-24 15:15:24 --> Config Class Initialized
INFO - 2024-07-24 15:15:24 --> Hooks Class Initialized
DEBUG - 2024-07-24 15:15:24 --> UTF-8 Support Enabled
INFO - 2024-07-24 15:15:24 --> Utf8 Class Initialized
INFO - 2024-07-24 15:15:24 --> URI Class Initialized
INFO - 2024-07-24 15:15:24 --> Router Class Initialized
INFO - 2024-07-24 15:15:24 --> Output Class Initialized
INFO - 2024-07-24 15:15:24 --> Security Class Initialized
DEBUG - 2024-07-24 15:15:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-07-24 15:15:24 --> Input Class Initialized
INFO - 2024-07-24 15:15:24 --> Language Class Initialized
INFO - 2024-07-24 15:15:24 --> Language Class Initialized
INFO - 2024-07-24 15:15:24 --> Config Class Initialized
INFO - 2024-07-24 15:15:24 --> Loader Class Initialized
INFO - 2024-07-24 15:15:24 --> Helper loaded: url_helper
INFO - 2024-07-24 15:15:24 --> Helper loaded: file_helper
INFO - 2024-07-24 15:15:24 --> Helper loaded: form_helper
INFO - 2024-07-24 15:15:24 --> Helper loaded: my_helper
INFO - 2024-07-24 15:15:24 --> Database Driver Class Initialized
INFO - 2024-07-24 15:15:24 --> Session: Class initialized using 'files' driver.
INFO - 2024-07-24 15:15:24 --> Controller Class Initialized
ERROR - 2024-07-24 15:15:24 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1156
ERROR - 2024-07-24 15:15:24 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1688
ERROR - 2024-07-24 15:15:24 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1725
ERROR - 2024-07-24 15:15:24 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1763
ERROR - 2024-07-24 15:15:24 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1802
ERROR - 2024-07-24 15:15:24 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1879
ERROR - 2024-07-24 15:15:24 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1958
ERROR - 2024-07-24 15:15:24 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 2038
ERROR - 2024-07-24 15:15:24 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 2118
ERROR - 2024-07-24 15:15:24 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 2198
ERROR - 2024-07-24 15:15:24 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 2273
ERROR - 2024-07-24 15:15:24 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php 28
ERROR - 2024-07-24 15:15:24 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php 32
ERROR - 2024-07-24 15:15:24 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php 32
ERROR - 2024-07-24 15:15:24 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php 36
ERROR - 2024-07-24 15:15:24 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php 110
ERROR - 2024-07-24 15:15:24 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php 119
ERROR - 2024-07-24 15:15:24 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php 126
DEBUG - 2024-07-24 15:15:24 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php
INFO - 2024-07-24 15:15:27 --> Final output sent to browser
DEBUG - 2024-07-24 15:15:27 --> Total execution time: 3.3945
INFO - 2024-07-24 15:15:28 --> Config Class Initialized
INFO - 2024-07-24 15:15:28 --> Hooks Class Initialized
DEBUG - 2024-07-24 15:15:28 --> UTF-8 Support Enabled
INFO - 2024-07-24 15:15:28 --> Utf8 Class Initialized
INFO - 2024-07-24 15:15:28 --> URI Class Initialized
INFO - 2024-07-24 15:15:28 --> Router Class Initialized
INFO - 2024-07-24 15:15:28 --> Output Class Initialized
INFO - 2024-07-24 15:15:28 --> Security Class Initialized
DEBUG - 2024-07-24 15:15:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-07-24 15:15:28 --> Input Class Initialized
INFO - 2024-07-24 15:15:28 --> Language Class Initialized
INFO - 2024-07-24 15:15:28 --> Language Class Initialized
INFO - 2024-07-24 15:15:28 --> Config Class Initialized
INFO - 2024-07-24 15:15:28 --> Loader Class Initialized
INFO - 2024-07-24 15:15:28 --> Helper loaded: url_helper
INFO - 2024-07-24 15:15:28 --> Helper loaded: file_helper
INFO - 2024-07-24 15:15:28 --> Helper loaded: form_helper
INFO - 2024-07-24 15:15:28 --> Helper loaded: my_helper
INFO - 2024-07-24 15:15:28 --> Database Driver Class Initialized
INFO - 2024-07-24 15:15:28 --> Session: Class initialized using 'files' driver.
INFO - 2024-07-24 15:15:28 --> Controller Class Initialized
ERROR - 2024-07-24 15:15:28 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1156
ERROR - 2024-07-24 15:15:28 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1688
ERROR - 2024-07-24 15:15:28 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1725
ERROR - 2024-07-24 15:15:28 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1763
ERROR - 2024-07-24 15:15:28 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1802
ERROR - 2024-07-24 15:15:28 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1879
ERROR - 2024-07-24 15:15:28 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1958
ERROR - 2024-07-24 15:15:28 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 2038
ERROR - 2024-07-24 15:15:28 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 2118
ERROR - 2024-07-24 15:15:28 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 2198
ERROR - 2024-07-24 15:15:28 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 2273
ERROR - 2024-07-24 15:15:28 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php 28
ERROR - 2024-07-24 15:15:28 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php 32
ERROR - 2024-07-24 15:15:28 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php 32
ERROR - 2024-07-24 15:15:28 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php 36
ERROR - 2024-07-24 15:15:28 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php 110
ERROR - 2024-07-24 15:15:28 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php 119
ERROR - 2024-07-24 15:15:28 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php 126
DEBUG - 2024-07-24 15:15:28 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php
INFO - 2024-07-24 15:15:31 --> Final output sent to browser
DEBUG - 2024-07-24 15:15:31 --> Total execution time: 3.2492
INFO - 2024-07-24 15:15:31 --> Config Class Initialized
INFO - 2024-07-24 15:15:31 --> Hooks Class Initialized
DEBUG - 2024-07-24 15:15:31 --> UTF-8 Support Enabled
INFO - 2024-07-24 15:15:31 --> Utf8 Class Initialized
INFO - 2024-07-24 15:15:31 --> URI Class Initialized
INFO - 2024-07-24 15:15:31 --> Router Class Initialized
INFO - 2024-07-24 15:15:31 --> Output Class Initialized
INFO - 2024-07-24 15:15:31 --> Security Class Initialized
DEBUG - 2024-07-24 15:15:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-07-24 15:15:31 --> Input Class Initialized
INFO - 2024-07-24 15:15:31 --> Language Class Initialized
INFO - 2024-07-24 15:15:31 --> Language Class Initialized
INFO - 2024-07-24 15:15:31 --> Config Class Initialized
INFO - 2024-07-24 15:15:31 --> Loader Class Initialized
INFO - 2024-07-24 15:15:31 --> Helper loaded: url_helper
INFO - 2024-07-24 15:15:31 --> Helper loaded: file_helper
INFO - 2024-07-24 15:15:31 --> Helper loaded: form_helper
INFO - 2024-07-24 15:15:31 --> Helper loaded: my_helper
INFO - 2024-07-24 15:15:31 --> Database Driver Class Initialized
INFO - 2024-07-24 15:15:31 --> Session: Class initialized using 'files' driver.
INFO - 2024-07-24 15:15:31 --> Controller Class Initialized
ERROR - 2024-07-24 15:15:31 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1156
ERROR - 2024-07-24 15:15:31 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1688
ERROR - 2024-07-24 15:15:31 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1725
ERROR - 2024-07-24 15:15:31 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1763
ERROR - 2024-07-24 15:15:31 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1802
ERROR - 2024-07-24 15:15:31 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1879
ERROR - 2024-07-24 15:15:31 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1958
ERROR - 2024-07-24 15:15:31 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 2038
ERROR - 2024-07-24 15:15:31 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 2118
ERROR - 2024-07-24 15:15:31 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 2198
ERROR - 2024-07-24 15:15:31 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 2273
ERROR - 2024-07-24 15:15:31 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php 28
ERROR - 2024-07-24 15:15:31 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php 32
ERROR - 2024-07-24 15:15:31 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php 32
ERROR - 2024-07-24 15:15:31 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php 36
ERROR - 2024-07-24 15:15:31 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php 110
ERROR - 2024-07-24 15:15:31 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php 119
ERROR - 2024-07-24 15:15:31 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php 126
DEBUG - 2024-07-24 15:15:31 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php
INFO - 2024-07-24 15:15:34 --> Final output sent to browser
DEBUG - 2024-07-24 15:15:34 --> Total execution time: 3.1622
INFO - 2024-07-24 15:15:34 --> Config Class Initialized
INFO - 2024-07-24 15:15:34 --> Hooks Class Initialized
DEBUG - 2024-07-24 15:15:34 --> UTF-8 Support Enabled
INFO - 2024-07-24 15:15:34 --> Utf8 Class Initialized
INFO - 2024-07-24 15:15:34 --> URI Class Initialized
INFO - 2024-07-24 15:15:34 --> Router Class Initialized
INFO - 2024-07-24 15:15:34 --> Output Class Initialized
INFO - 2024-07-24 15:15:34 --> Security Class Initialized
DEBUG - 2024-07-24 15:15:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-07-24 15:15:34 --> Input Class Initialized
INFO - 2024-07-24 15:15:34 --> Language Class Initialized
INFO - 2024-07-24 15:15:34 --> Language Class Initialized
INFO - 2024-07-24 15:15:34 --> Config Class Initialized
INFO - 2024-07-24 15:15:34 --> Loader Class Initialized
INFO - 2024-07-24 15:15:34 --> Helper loaded: url_helper
INFO - 2024-07-24 15:15:34 --> Helper loaded: file_helper
INFO - 2024-07-24 15:15:34 --> Helper loaded: form_helper
INFO - 2024-07-24 15:15:34 --> Helper loaded: my_helper
INFO - 2024-07-24 15:15:34 --> Database Driver Class Initialized
INFO - 2024-07-24 15:15:34 --> Session: Class initialized using 'files' driver.
INFO - 2024-07-24 15:15:34 --> Controller Class Initialized
ERROR - 2024-07-24 15:15:34 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1156
ERROR - 2024-07-24 15:15:34 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1688
ERROR - 2024-07-24 15:15:34 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1725
ERROR - 2024-07-24 15:15:34 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1763
ERROR - 2024-07-24 15:15:34 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1802
ERROR - 2024-07-24 15:15:34 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1879
ERROR - 2024-07-24 15:15:34 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1958
ERROR - 2024-07-24 15:15:34 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 2038
ERROR - 2024-07-24 15:15:34 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 2118
ERROR - 2024-07-24 15:15:34 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 2198
ERROR - 2024-07-24 15:15:34 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 2273
ERROR - 2024-07-24 15:15:34 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php 28
ERROR - 2024-07-24 15:15:34 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php 32
ERROR - 2024-07-24 15:15:34 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php 32
ERROR - 2024-07-24 15:15:34 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php 36
ERROR - 2024-07-24 15:15:34 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php 110
ERROR - 2024-07-24 15:15:34 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php 119
ERROR - 2024-07-24 15:15:34 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php 126
DEBUG - 2024-07-24 15:15:34 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php
INFO - 2024-07-24 15:15:38 --> Final output sent to browser
DEBUG - 2024-07-24 15:15:38 --> Total execution time: 3.2347
INFO - 2024-07-24 15:15:38 --> Config Class Initialized
INFO - 2024-07-24 15:15:38 --> Hooks Class Initialized
DEBUG - 2024-07-24 15:15:38 --> UTF-8 Support Enabled
INFO - 2024-07-24 15:15:38 --> Utf8 Class Initialized
INFO - 2024-07-24 15:15:38 --> URI Class Initialized
INFO - 2024-07-24 15:15:38 --> Router Class Initialized
INFO - 2024-07-24 15:15:38 --> Output Class Initialized
INFO - 2024-07-24 15:15:38 --> Security Class Initialized
DEBUG - 2024-07-24 15:15:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-07-24 15:15:38 --> Input Class Initialized
INFO - 2024-07-24 15:15:38 --> Language Class Initialized
INFO - 2024-07-24 15:15:38 --> Language Class Initialized
INFO - 2024-07-24 15:15:38 --> Config Class Initialized
INFO - 2024-07-24 15:15:38 --> Loader Class Initialized
INFO - 2024-07-24 15:15:38 --> Helper loaded: url_helper
INFO - 2024-07-24 15:15:38 --> Helper loaded: file_helper
INFO - 2024-07-24 15:15:38 --> Helper loaded: form_helper
INFO - 2024-07-24 15:15:38 --> Helper loaded: my_helper
INFO - 2024-07-24 15:15:38 --> Database Driver Class Initialized
INFO - 2024-07-24 15:15:38 --> Session: Class initialized using 'files' driver.
INFO - 2024-07-24 15:15:38 --> Controller Class Initialized
ERROR - 2024-07-24 15:15:38 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1156
ERROR - 2024-07-24 15:15:38 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1688
ERROR - 2024-07-24 15:15:38 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1725
ERROR - 2024-07-24 15:15:38 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1763
ERROR - 2024-07-24 15:15:38 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1802
ERROR - 2024-07-24 15:15:38 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1879
ERROR - 2024-07-24 15:15:38 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1958
ERROR - 2024-07-24 15:15:38 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 2038
ERROR - 2024-07-24 15:15:38 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 2118
ERROR - 2024-07-24 15:15:38 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 2198
ERROR - 2024-07-24 15:15:38 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 2273
ERROR - 2024-07-24 15:15:38 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php 28
ERROR - 2024-07-24 15:15:38 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php 32
ERROR - 2024-07-24 15:15:38 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php 32
ERROR - 2024-07-24 15:15:38 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php 36
ERROR - 2024-07-24 15:15:38 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php 110
ERROR - 2024-07-24 15:15:38 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php 119
ERROR - 2024-07-24 15:15:38 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php 126
DEBUG - 2024-07-24 15:15:38 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php
INFO - 2024-07-24 15:15:41 --> Final output sent to browser
DEBUG - 2024-07-24 15:15:41 --> Total execution time: 3.1456
INFO - 2024-07-24 15:15:41 --> Config Class Initialized
INFO - 2024-07-24 15:15:41 --> Hooks Class Initialized
DEBUG - 2024-07-24 15:15:41 --> UTF-8 Support Enabled
INFO - 2024-07-24 15:15:41 --> Utf8 Class Initialized
INFO - 2024-07-24 15:15:41 --> URI Class Initialized
INFO - 2024-07-24 15:15:41 --> Router Class Initialized
INFO - 2024-07-24 15:15:41 --> Output Class Initialized
INFO - 2024-07-24 15:15:41 --> Security Class Initialized
DEBUG - 2024-07-24 15:15:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-07-24 15:15:41 --> Input Class Initialized
INFO - 2024-07-24 15:15:41 --> Language Class Initialized
INFO - 2024-07-24 15:15:41 --> Language Class Initialized
INFO - 2024-07-24 15:15:41 --> Config Class Initialized
INFO - 2024-07-24 15:15:41 --> Loader Class Initialized
INFO - 2024-07-24 15:15:41 --> Helper loaded: url_helper
INFO - 2024-07-24 15:15:41 --> Helper loaded: file_helper
INFO - 2024-07-24 15:15:41 --> Helper loaded: form_helper
INFO - 2024-07-24 15:15:41 --> Helper loaded: my_helper
INFO - 2024-07-24 15:15:41 --> Database Driver Class Initialized
INFO - 2024-07-24 15:15:41 --> Session: Class initialized using 'files' driver.
INFO - 2024-07-24 15:15:41 --> Controller Class Initialized
ERROR - 2024-07-24 15:15:41 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1156
ERROR - 2024-07-24 15:15:41 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1688
ERROR - 2024-07-24 15:15:41 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1725
ERROR - 2024-07-24 15:15:41 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1763
ERROR - 2024-07-24 15:15:41 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1802
ERROR - 2024-07-24 15:15:41 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1879
ERROR - 2024-07-24 15:15:41 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1958
ERROR - 2024-07-24 15:15:41 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 2038
ERROR - 2024-07-24 15:15:41 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 2118
ERROR - 2024-07-24 15:15:41 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 2198
ERROR - 2024-07-24 15:15:41 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 2273
ERROR - 2024-07-24 15:15:41 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php 28
ERROR - 2024-07-24 15:15:41 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php 32
ERROR - 2024-07-24 15:15:41 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php 32
ERROR - 2024-07-24 15:15:41 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php 36
ERROR - 2024-07-24 15:15:41 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php 110
ERROR - 2024-07-24 15:15:41 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php 119
ERROR - 2024-07-24 15:15:41 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php 126
DEBUG - 2024-07-24 15:15:41 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php
INFO - 2024-07-24 15:15:44 --> Final output sent to browser
DEBUG - 2024-07-24 15:15:44 --> Total execution time: 2.7852
INFO - 2024-07-24 15:15:44 --> Config Class Initialized
INFO - 2024-07-24 15:15:44 --> Hooks Class Initialized
DEBUG - 2024-07-24 15:15:44 --> UTF-8 Support Enabled
INFO - 2024-07-24 15:15:44 --> Utf8 Class Initialized
INFO - 2024-07-24 15:15:44 --> URI Class Initialized
INFO - 2024-07-24 15:15:44 --> Router Class Initialized
INFO - 2024-07-24 15:15:44 --> Output Class Initialized
INFO - 2024-07-24 15:15:44 --> Security Class Initialized
DEBUG - 2024-07-24 15:15:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-07-24 15:15:44 --> Input Class Initialized
INFO - 2024-07-24 15:15:44 --> Language Class Initialized
INFO - 2024-07-24 15:15:44 --> Language Class Initialized
INFO - 2024-07-24 15:15:44 --> Config Class Initialized
INFO - 2024-07-24 15:15:44 --> Loader Class Initialized
INFO - 2024-07-24 15:15:44 --> Helper loaded: url_helper
INFO - 2024-07-24 15:15:44 --> Helper loaded: file_helper
INFO - 2024-07-24 15:15:44 --> Helper loaded: form_helper
INFO - 2024-07-24 15:15:44 --> Helper loaded: my_helper
INFO - 2024-07-24 15:15:44 --> Database Driver Class Initialized
INFO - 2024-07-24 15:15:44 --> Session: Class initialized using 'files' driver.
INFO - 2024-07-24 15:15:44 --> Controller Class Initialized
ERROR - 2024-07-24 15:15:44 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1156
ERROR - 2024-07-24 15:15:44 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1688
ERROR - 2024-07-24 15:15:44 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1725
ERROR - 2024-07-24 15:15:44 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1763
ERROR - 2024-07-24 15:15:44 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1802
ERROR - 2024-07-24 15:15:44 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1879
ERROR - 2024-07-24 15:15:44 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1958
ERROR - 2024-07-24 15:15:44 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 2038
ERROR - 2024-07-24 15:15:44 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 2118
ERROR - 2024-07-24 15:15:44 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 2198
ERROR - 2024-07-24 15:15:44 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 2273
ERROR - 2024-07-24 15:15:44 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php 28
ERROR - 2024-07-24 15:15:44 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php 32
ERROR - 2024-07-24 15:15:44 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php 32
ERROR - 2024-07-24 15:15:44 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php 36
ERROR - 2024-07-24 15:15:44 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php 110
ERROR - 2024-07-24 15:15:44 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php 119
ERROR - 2024-07-24 15:15:44 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php 126
DEBUG - 2024-07-24 15:15:44 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php
INFO - 2024-07-24 15:15:47 --> Final output sent to browser
DEBUG - 2024-07-24 15:15:47 --> Total execution time: 3.0153
