<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2024-11-01 16:14:38 --> Config Class Initialized
INFO - 2024-11-01 16:14:38 --> Hooks Class Initialized
DEBUG - 2024-11-01 16:14:38 --> UTF-8 Support Enabled
INFO - 2024-11-01 16:14:38 --> Utf8 Class Initialized
INFO - 2024-11-01 16:14:38 --> URI Class Initialized
INFO - 2024-11-01 16:14:38 --> Router Class Initialized
INFO - 2024-11-01 16:14:38 --> Output Class Initialized
INFO - 2024-11-01 16:14:38 --> Security Class Initialized
DEBUG - 2024-11-01 16:14:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-11-01 16:14:38 --> Input Class Initialized
INFO - 2024-11-01 16:14:38 --> Language Class Initialized
INFO - 2024-11-01 16:14:38 --> Language Class Initialized
INFO - 2024-11-01 16:14:38 --> Config Class Initialized
INFO - 2024-11-01 16:14:38 --> Loader Class Initialized
INFO - 2024-11-01 16:14:38 --> Helper loaded: url_helper
INFO - 2024-11-01 16:14:38 --> Helper loaded: file_helper
INFO - 2024-11-01 16:14:38 --> Helper loaded: form_helper
INFO - 2024-11-01 16:14:38 --> Helper loaded: my_helper
INFO - 2024-11-01 16:14:38 --> Database Driver Class Initialized
INFO - 2024-11-01 16:14:38 --> Session: Class initialized using 'files' driver.
INFO - 2024-11-01 16:14:38 --> Controller Class Initialized
INFO - 2024-11-01 16:14:38 --> Helper loaded: cookie_helper
INFO - 2024-11-01 16:14:38 --> Final output sent to browser
DEBUG - 2024-11-01 16:14:38 --> Total execution time: 0.0746
INFO - 2024-11-01 16:14:39 --> Config Class Initialized
INFO - 2024-11-01 16:14:39 --> Hooks Class Initialized
DEBUG - 2024-11-01 16:14:39 --> UTF-8 Support Enabled
INFO - 2024-11-01 16:14:39 --> Utf8 Class Initialized
INFO - 2024-11-01 16:14:39 --> URI Class Initialized
INFO - 2024-11-01 16:14:39 --> Router Class Initialized
INFO - 2024-11-01 16:14:39 --> Output Class Initialized
INFO - 2024-11-01 16:14:39 --> Security Class Initialized
DEBUG - 2024-11-01 16:14:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-11-01 16:14:39 --> Input Class Initialized
INFO - 2024-11-01 16:14:39 --> Language Class Initialized
INFO - 2024-11-01 16:14:39 --> Language Class Initialized
INFO - 2024-11-01 16:14:39 --> Config Class Initialized
INFO - 2024-11-01 16:14:39 --> Loader Class Initialized
INFO - 2024-11-01 16:14:39 --> Helper loaded: url_helper
INFO - 2024-11-01 16:14:39 --> Helper loaded: file_helper
INFO - 2024-11-01 16:14:39 --> Helper loaded: form_helper
INFO - 2024-11-01 16:14:39 --> Helper loaded: my_helper
INFO - 2024-11-01 16:14:39 --> Database Driver Class Initialized
INFO - 2024-11-01 16:14:39 --> Session: Class initialized using 'files' driver.
INFO - 2024-11-01 16:14:39 --> Controller Class Initialized
INFO - 2024-11-01 16:14:39 --> Helper loaded: cookie_helper
INFO - 2024-11-01 16:14:39 --> Config Class Initialized
INFO - 2024-11-01 16:14:39 --> Hooks Class Initialized
DEBUG - 2024-11-01 16:14:39 --> UTF-8 Support Enabled
INFO - 2024-11-01 16:14:39 --> Utf8 Class Initialized
INFO - 2024-11-01 16:14:39 --> URI Class Initialized
INFO - 2024-11-01 16:14:39 --> Router Class Initialized
INFO - 2024-11-01 16:14:39 --> Output Class Initialized
INFO - 2024-11-01 16:14:39 --> Security Class Initialized
DEBUG - 2024-11-01 16:14:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-11-01 16:14:39 --> Input Class Initialized
INFO - 2024-11-01 16:14:39 --> Language Class Initialized
INFO - 2024-11-01 16:14:39 --> Language Class Initialized
INFO - 2024-11-01 16:14:39 --> Config Class Initialized
INFO - 2024-11-01 16:14:39 --> Loader Class Initialized
INFO - 2024-11-01 16:14:39 --> Helper loaded: url_helper
INFO - 2024-11-01 16:14:39 --> Helper loaded: file_helper
INFO - 2024-11-01 16:14:39 --> Helper loaded: form_helper
INFO - 2024-11-01 16:14:39 --> Helper loaded: my_helper
INFO - 2024-11-01 16:14:39 --> Database Driver Class Initialized
INFO - 2024-11-01 16:14:39 --> Session: Class initialized using 'files' driver.
INFO - 2024-11-01 16:14:39 --> Controller Class Initialized
DEBUG - 2024-11-01 16:14:39 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/lihat_raport/views/list.php
DEBUG - 2024-11-01 16:14:39 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-11-01 16:14:39 --> Final output sent to browser
DEBUG - 2024-11-01 16:14:39 --> Total execution time: 0.2281
INFO - 2024-11-01 18:02:54 --> Config Class Initialized
INFO - 2024-11-01 18:02:54 --> Hooks Class Initialized
DEBUG - 2024-11-01 18:02:54 --> UTF-8 Support Enabled
INFO - 2024-11-01 18:02:54 --> Utf8 Class Initialized
INFO - 2024-11-01 18:02:54 --> URI Class Initialized
INFO - 2024-11-01 18:02:54 --> Router Class Initialized
INFO - 2024-11-01 18:02:54 --> Output Class Initialized
INFO - 2024-11-01 18:02:54 --> Security Class Initialized
DEBUG - 2024-11-01 18:02:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-11-01 18:02:54 --> Input Class Initialized
INFO - 2024-11-01 18:02:54 --> Language Class Initialized
INFO - 2024-11-01 18:02:54 --> Language Class Initialized
INFO - 2024-11-01 18:02:54 --> Config Class Initialized
INFO - 2024-11-01 18:02:54 --> Loader Class Initialized
INFO - 2024-11-01 18:02:54 --> Helper loaded: url_helper
INFO - 2024-11-01 18:02:54 --> Helper loaded: file_helper
INFO - 2024-11-01 18:02:54 --> Helper loaded: form_helper
INFO - 2024-11-01 18:02:54 --> Helper loaded: my_helper
INFO - 2024-11-01 18:02:54 --> Database Driver Class Initialized
INFO - 2024-11-01 18:02:54 --> Session: Class initialized using 'files' driver.
INFO - 2024-11-01 18:02:54 --> Controller Class Initialized
INFO - 2024-11-01 18:02:54 --> Helper loaded: cookie_helper
INFO - 2024-11-01 18:02:54 --> Final output sent to browser
DEBUG - 2024-11-01 18:02:54 --> Total execution time: 0.0750
INFO - 2024-11-01 18:02:55 --> Config Class Initialized
INFO - 2024-11-01 18:02:55 --> Hooks Class Initialized
DEBUG - 2024-11-01 18:02:55 --> UTF-8 Support Enabled
INFO - 2024-11-01 18:02:55 --> Utf8 Class Initialized
INFO - 2024-11-01 18:02:55 --> URI Class Initialized
INFO - 2024-11-01 18:02:55 --> Router Class Initialized
INFO - 2024-11-01 18:02:55 --> Output Class Initialized
INFO - 2024-11-01 18:02:55 --> Security Class Initialized
DEBUG - 2024-11-01 18:02:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-11-01 18:02:55 --> Input Class Initialized
INFO - 2024-11-01 18:02:55 --> Language Class Initialized
INFO - 2024-11-01 18:02:55 --> Language Class Initialized
INFO - 2024-11-01 18:02:55 --> Config Class Initialized
INFO - 2024-11-01 18:02:55 --> Loader Class Initialized
INFO - 2024-11-01 18:02:55 --> Helper loaded: url_helper
INFO - 2024-11-01 18:02:55 --> Helper loaded: file_helper
INFO - 2024-11-01 18:02:55 --> Helper loaded: form_helper
INFO - 2024-11-01 18:02:55 --> Helper loaded: my_helper
INFO - 2024-11-01 18:02:55 --> Database Driver Class Initialized
INFO - 2024-11-01 18:02:55 --> Session: Class initialized using 'files' driver.
INFO - 2024-11-01 18:02:55 --> Controller Class Initialized
INFO - 2024-11-01 18:02:55 --> Helper loaded: cookie_helper
INFO - 2024-11-01 18:02:55 --> Config Class Initialized
INFO - 2024-11-01 18:02:55 --> Hooks Class Initialized
DEBUG - 2024-11-01 18:02:55 --> UTF-8 Support Enabled
INFO - 2024-11-01 18:02:55 --> Utf8 Class Initialized
INFO - 2024-11-01 18:02:55 --> URI Class Initialized
INFO - 2024-11-01 18:02:55 --> Router Class Initialized
INFO - 2024-11-01 18:02:55 --> Output Class Initialized
INFO - 2024-11-01 18:02:55 --> Security Class Initialized
DEBUG - 2024-11-01 18:02:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-11-01 18:02:55 --> Input Class Initialized
INFO - 2024-11-01 18:02:55 --> Language Class Initialized
INFO - 2024-11-01 18:02:55 --> Language Class Initialized
INFO - 2024-11-01 18:02:55 --> Config Class Initialized
INFO - 2024-11-01 18:02:55 --> Loader Class Initialized
INFO - 2024-11-01 18:02:55 --> Helper loaded: url_helper
INFO - 2024-11-01 18:02:55 --> Helper loaded: file_helper
INFO - 2024-11-01 18:02:55 --> Helper loaded: form_helper
INFO - 2024-11-01 18:02:55 --> Helper loaded: my_helper
INFO - 2024-11-01 18:02:55 --> Database Driver Class Initialized
INFO - 2024-11-01 18:02:55 --> Session: Class initialized using 'files' driver.
INFO - 2024-11-01 18:02:55 --> Controller Class Initialized
DEBUG - 2024-11-01 18:02:55 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/lihat_raport/views/list.php
DEBUG - 2024-11-01 18:02:55 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-11-01 18:02:55 --> Final output sent to browser
DEBUG - 2024-11-01 18:02:55 --> Total execution time: 0.0391
INFO - 2024-11-01 18:02:57 --> Config Class Initialized
INFO - 2024-11-01 18:02:57 --> Hooks Class Initialized
DEBUG - 2024-11-01 18:02:57 --> UTF-8 Support Enabled
INFO - 2024-11-01 18:02:57 --> Utf8 Class Initialized
INFO - 2024-11-01 18:02:57 --> URI Class Initialized
INFO - 2024-11-01 18:02:57 --> Router Class Initialized
INFO - 2024-11-01 18:02:57 --> Output Class Initialized
INFO - 2024-11-01 18:02:57 --> Security Class Initialized
DEBUG - 2024-11-01 18:02:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-11-01 18:02:57 --> Input Class Initialized
INFO - 2024-11-01 18:02:57 --> Language Class Initialized
INFO - 2024-11-01 18:02:57 --> Language Class Initialized
INFO - 2024-11-01 18:02:57 --> Config Class Initialized
INFO - 2024-11-01 18:02:57 --> Loader Class Initialized
INFO - 2024-11-01 18:02:57 --> Helper loaded: url_helper
INFO - 2024-11-01 18:02:57 --> Helper loaded: file_helper
INFO - 2024-11-01 18:02:57 --> Helper loaded: form_helper
INFO - 2024-11-01 18:02:57 --> Helper loaded: my_helper
INFO - 2024-11-01 18:02:57 --> Database Driver Class Initialized
INFO - 2024-11-01 18:02:57 --> Session: Class initialized using 'files' driver.
INFO - 2024-11-01 18:02:57 --> Controller Class Initialized
DEBUG - 2024-11-01 18:02:57 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php
INFO - 2024-11-01 18:03:00 --> Final output sent to browser
DEBUG - 2024-11-01 18:03:00 --> Total execution time: 2.9879
INFO - 2024-11-01 20:10:05 --> Config Class Initialized
INFO - 2024-11-01 20:10:05 --> Hooks Class Initialized
DEBUG - 2024-11-01 20:10:05 --> UTF-8 Support Enabled
INFO - 2024-11-01 20:10:05 --> Utf8 Class Initialized
INFO - 2024-11-01 20:10:05 --> URI Class Initialized
INFO - 2024-11-01 20:10:05 --> Router Class Initialized
INFO - 2024-11-01 20:10:05 --> Output Class Initialized
INFO - 2024-11-01 20:10:05 --> Security Class Initialized
DEBUG - 2024-11-01 20:10:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-11-01 20:10:05 --> Input Class Initialized
INFO - 2024-11-01 20:10:05 --> Language Class Initialized
INFO - 2024-11-01 20:10:05 --> Language Class Initialized
INFO - 2024-11-01 20:10:05 --> Config Class Initialized
INFO - 2024-11-01 20:10:05 --> Loader Class Initialized
INFO - 2024-11-01 20:10:05 --> Helper loaded: url_helper
INFO - 2024-11-01 20:10:05 --> Helper loaded: file_helper
INFO - 2024-11-01 20:10:05 --> Helper loaded: form_helper
INFO - 2024-11-01 20:10:05 --> Helper loaded: my_helper
INFO - 2024-11-01 20:10:05 --> Database Driver Class Initialized
INFO - 2024-11-01 20:10:05 --> Session: Class initialized using 'files' driver.
INFO - 2024-11-01 20:10:05 --> Controller Class Initialized
INFO - 2024-11-01 20:10:05 --> Final output sent to browser
DEBUG - 2024-11-01 20:10:05 --> Total execution time: 0.0578
