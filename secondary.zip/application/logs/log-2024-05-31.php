<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2024-05-31 10:46:45 --> Config Class Initialized
INFO - 2024-05-31 10:46:45 --> Hooks Class Initialized
DEBUG - 2024-05-31 10:46:45 --> UTF-8 Support Enabled
INFO - 2024-05-31 10:46:45 --> Utf8 Class Initialized
INFO - 2024-05-31 10:46:45 --> URI Class Initialized
INFO - 2024-05-31 10:46:45 --> Router Class Initialized
INFO - 2024-05-31 10:46:45 --> Output Class Initialized
INFO - 2024-05-31 10:46:45 --> Security Class Initialized
DEBUG - 2024-05-31 10:46:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-05-31 10:46:45 --> Input Class Initialized
INFO - 2024-05-31 10:46:45 --> Language Class Initialized
INFO - 2024-05-31 10:46:45 --> Language Class Initialized
INFO - 2024-05-31 10:46:45 --> Config Class Initialized
INFO - 2024-05-31 10:46:45 --> Loader Class Initialized
INFO - 2024-05-31 10:46:45 --> Helper loaded: url_helper
INFO - 2024-05-31 10:46:45 --> Helper loaded: file_helper
INFO - 2024-05-31 10:46:45 --> Helper loaded: form_helper
INFO - 2024-05-31 10:46:45 --> Helper loaded: my_helper
INFO - 2024-05-31 10:46:45 --> Database Driver Class Initialized
INFO - 2024-05-31 10:46:45 --> Session: Class initialized using 'files' driver.
INFO - 2024-05-31 10:46:45 --> Controller Class Initialized
DEBUG - 2024-05-31 10:46:45 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/login/views/login.php
DEBUG - 2024-05-31 10:46:45 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-05-31 10:46:45 --> Final output sent to browser
DEBUG - 2024-05-31 10:46:45 --> Total execution time: 0.0505
INFO - 2024-05-31 10:47:50 --> Config Class Initialized
INFO - 2024-05-31 10:47:50 --> Hooks Class Initialized
DEBUG - 2024-05-31 10:47:50 --> UTF-8 Support Enabled
INFO - 2024-05-31 10:47:50 --> Utf8 Class Initialized
INFO - 2024-05-31 10:47:50 --> URI Class Initialized
INFO - 2024-05-31 10:47:50 --> Router Class Initialized
INFO - 2024-05-31 10:47:50 --> Output Class Initialized
INFO - 2024-05-31 10:47:50 --> Security Class Initialized
DEBUG - 2024-05-31 10:47:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-05-31 10:47:50 --> Input Class Initialized
INFO - 2024-05-31 10:47:50 --> Language Class Initialized
INFO - 2024-05-31 10:47:50 --> Language Class Initialized
INFO - 2024-05-31 10:47:50 --> Config Class Initialized
INFO - 2024-05-31 10:47:50 --> Loader Class Initialized
INFO - 2024-05-31 10:47:50 --> Helper loaded: url_helper
INFO - 2024-05-31 10:47:50 --> Helper loaded: file_helper
INFO - 2024-05-31 10:47:50 --> Helper loaded: form_helper
INFO - 2024-05-31 10:47:50 --> Helper loaded: my_helper
INFO - 2024-05-31 10:47:50 --> Database Driver Class Initialized
INFO - 2024-05-31 10:47:50 --> Session: Class initialized using 'files' driver.
INFO - 2024-05-31 10:47:50 --> Controller Class Initialized
INFO - 2024-05-31 10:47:50 --> Helper loaded: cookie_helper
INFO - 2024-05-31 10:47:50 --> Final output sent to browser
DEBUG - 2024-05-31 10:47:50 --> Total execution time: 0.0381
INFO - 2024-05-31 10:47:51 --> Config Class Initialized
INFO - 2024-05-31 10:47:51 --> Hooks Class Initialized
DEBUG - 2024-05-31 10:47:51 --> UTF-8 Support Enabled
INFO - 2024-05-31 10:47:51 --> Utf8 Class Initialized
INFO - 2024-05-31 10:47:51 --> URI Class Initialized
INFO - 2024-05-31 10:47:51 --> Router Class Initialized
INFO - 2024-05-31 10:47:51 --> Output Class Initialized
INFO - 2024-05-31 10:47:51 --> Security Class Initialized
DEBUG - 2024-05-31 10:47:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-05-31 10:47:51 --> Input Class Initialized
INFO - 2024-05-31 10:47:51 --> Language Class Initialized
INFO - 2024-05-31 10:47:51 --> Language Class Initialized
INFO - 2024-05-31 10:47:51 --> Config Class Initialized
INFO - 2024-05-31 10:47:51 --> Loader Class Initialized
INFO - 2024-05-31 10:47:51 --> Helper loaded: url_helper
INFO - 2024-05-31 10:47:51 --> Helper loaded: file_helper
INFO - 2024-05-31 10:47:51 --> Helper loaded: form_helper
INFO - 2024-05-31 10:47:51 --> Helper loaded: my_helper
INFO - 2024-05-31 10:47:51 --> Database Driver Class Initialized
INFO - 2024-05-31 10:47:51 --> Session: Class initialized using 'files' driver.
INFO - 2024-05-31 10:47:51 --> Controller Class Initialized
DEBUG - 2024-05-31 10:47:51 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/home/views/v_home_guru.php
DEBUG - 2024-05-31 10:47:51 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-05-31 10:47:51 --> Final output sent to browser
DEBUG - 2024-05-31 10:47:51 --> Total execution time: 0.0323
INFO - 2024-05-31 10:47:54 --> Config Class Initialized
INFO - 2024-05-31 10:47:54 --> Hooks Class Initialized
DEBUG - 2024-05-31 10:47:54 --> UTF-8 Support Enabled
INFO - 2024-05-31 10:47:54 --> Utf8 Class Initialized
INFO - 2024-05-31 10:47:54 --> URI Class Initialized
INFO - 2024-05-31 10:47:54 --> Router Class Initialized
INFO - 2024-05-31 10:47:54 --> Output Class Initialized
INFO - 2024-05-31 10:47:54 --> Security Class Initialized
DEBUG - 2024-05-31 10:47:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-05-31 10:47:54 --> Input Class Initialized
INFO - 2024-05-31 10:47:54 --> Language Class Initialized
INFO - 2024-05-31 10:47:54 --> Language Class Initialized
INFO - 2024-05-31 10:47:54 --> Config Class Initialized
INFO - 2024-05-31 10:47:54 --> Loader Class Initialized
INFO - 2024-05-31 10:47:54 --> Helper loaded: url_helper
INFO - 2024-05-31 10:47:54 --> Helper loaded: file_helper
INFO - 2024-05-31 10:47:54 --> Helper loaded: form_helper
INFO - 2024-05-31 10:47:54 --> Helper loaded: my_helper
INFO - 2024-05-31 10:47:54 --> Database Driver Class Initialized
INFO - 2024-05-31 10:47:54 --> Session: Class initialized using 'files' driver.
INFO - 2024-05-31 10:47:54 --> Controller Class Initialized
DEBUG - 2024-05-31 10:47:54 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/view_mapel/views/v_view_mapel.php
DEBUG - 2024-05-31 10:47:54 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-05-31 10:47:54 --> Final output sent to browser
DEBUG - 2024-05-31 10:47:54 --> Total execution time: 0.0368
INFO - 2024-05-31 10:47:56 --> Config Class Initialized
INFO - 2024-05-31 10:47:56 --> Hooks Class Initialized
DEBUG - 2024-05-31 10:47:56 --> UTF-8 Support Enabled
INFO - 2024-05-31 10:47:56 --> Utf8 Class Initialized
INFO - 2024-05-31 10:47:56 --> URI Class Initialized
INFO - 2024-05-31 10:47:56 --> Router Class Initialized
INFO - 2024-05-31 10:47:56 --> Output Class Initialized
INFO - 2024-05-31 10:47:56 --> Security Class Initialized
DEBUG - 2024-05-31 10:47:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-05-31 10:47:56 --> Input Class Initialized
INFO - 2024-05-31 10:47:56 --> Language Class Initialized
INFO - 2024-05-31 10:47:56 --> Language Class Initialized
INFO - 2024-05-31 10:47:56 --> Config Class Initialized
INFO - 2024-05-31 10:47:56 --> Loader Class Initialized
INFO - 2024-05-31 10:47:56 --> Helper loaded: url_helper
INFO - 2024-05-31 10:47:56 --> Helper loaded: file_helper
INFO - 2024-05-31 10:47:56 --> Helper loaded: form_helper
INFO - 2024-05-31 10:47:56 --> Helper loaded: my_helper
INFO - 2024-05-31 10:47:56 --> Database Driver Class Initialized
INFO - 2024-05-31 10:47:56 --> Session: Class initialized using 'files' driver.
INFO - 2024-05-31 10:47:56 --> Controller Class Initialized
DEBUG - 2024-05-31 10:47:56 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/views/list.php
DEBUG - 2024-05-31 10:47:56 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-05-31 10:47:56 --> Final output sent to browser
DEBUG - 2024-05-31 10:47:56 --> Total execution time: 0.0362
INFO - 2024-05-31 10:47:56 --> Config Class Initialized
INFO - 2024-05-31 10:47:56 --> Hooks Class Initialized
DEBUG - 2024-05-31 10:47:56 --> UTF-8 Support Enabled
INFO - 2024-05-31 10:47:56 --> Utf8 Class Initialized
INFO - 2024-05-31 10:47:56 --> URI Class Initialized
INFO - 2024-05-31 10:47:56 --> Router Class Initialized
INFO - 2024-05-31 10:47:56 --> Output Class Initialized
INFO - 2024-05-31 10:47:56 --> Security Class Initialized
DEBUG - 2024-05-31 10:47:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-05-31 10:47:56 --> Input Class Initialized
INFO - 2024-05-31 10:47:56 --> Language Class Initialized
INFO - 2024-05-31 10:47:56 --> Language Class Initialized
INFO - 2024-05-31 10:47:56 --> Config Class Initialized
INFO - 2024-05-31 10:47:56 --> Loader Class Initialized
INFO - 2024-05-31 10:47:56 --> Helper loaded: url_helper
INFO - 2024-05-31 10:47:56 --> Helper loaded: file_helper
INFO - 2024-05-31 10:47:56 --> Helper loaded: form_helper
INFO - 2024-05-31 10:47:56 --> Helper loaded: my_helper
INFO - 2024-05-31 10:47:56 --> Database Driver Class Initialized
INFO - 2024-05-31 10:47:56 --> Session: Class initialized using 'files' driver.
INFO - 2024-05-31 10:47:56 --> Controller Class Initialized
INFO - 2024-05-31 10:48:38 --> Config Class Initialized
INFO - 2024-05-31 10:48:38 --> Hooks Class Initialized
DEBUG - 2024-05-31 10:48:38 --> UTF-8 Support Enabled
INFO - 2024-05-31 10:48:38 --> Utf8 Class Initialized
INFO - 2024-05-31 10:48:38 --> URI Class Initialized
INFO - 2024-05-31 10:48:38 --> Router Class Initialized
INFO - 2024-05-31 10:48:38 --> Output Class Initialized
INFO - 2024-05-31 10:48:38 --> Security Class Initialized
DEBUG - 2024-05-31 10:48:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-05-31 10:48:38 --> Input Class Initialized
INFO - 2024-05-31 10:48:38 --> Language Class Initialized
INFO - 2024-05-31 10:48:38 --> Language Class Initialized
INFO - 2024-05-31 10:48:38 --> Config Class Initialized
INFO - 2024-05-31 10:48:38 --> Loader Class Initialized
INFO - 2024-05-31 10:48:38 --> Helper loaded: url_helper
INFO - 2024-05-31 10:48:38 --> Helper loaded: file_helper
INFO - 2024-05-31 10:48:38 --> Helper loaded: form_helper
INFO - 2024-05-31 10:48:38 --> Helper loaded: my_helper
INFO - 2024-05-31 10:48:38 --> Database Driver Class Initialized
INFO - 2024-05-31 10:48:38 --> Session: Class initialized using 'files' driver.
INFO - 2024-05-31 10:48:38 --> Controller Class Initialized
INFO - 2024-05-31 10:48:38 --> Final output sent to browser
DEBUG - 2024-05-31 10:48:38 --> Total execution time: 0.0316
INFO - 2024-05-31 10:49:18 --> Config Class Initialized
INFO - 2024-05-31 10:49:18 --> Hooks Class Initialized
DEBUG - 2024-05-31 10:49:18 --> UTF-8 Support Enabled
INFO - 2024-05-31 10:49:18 --> Utf8 Class Initialized
INFO - 2024-05-31 10:49:18 --> URI Class Initialized
INFO - 2024-05-31 10:49:18 --> Router Class Initialized
INFO - 2024-05-31 10:49:18 --> Output Class Initialized
INFO - 2024-05-31 10:49:18 --> Security Class Initialized
DEBUG - 2024-05-31 10:49:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-05-31 10:49:18 --> Input Class Initialized
INFO - 2024-05-31 10:49:18 --> Language Class Initialized
INFO - 2024-05-31 10:49:18 --> Language Class Initialized
INFO - 2024-05-31 10:49:18 --> Config Class Initialized
INFO - 2024-05-31 10:49:18 --> Loader Class Initialized
INFO - 2024-05-31 10:49:18 --> Helper loaded: url_helper
INFO - 2024-05-31 10:49:18 --> Helper loaded: file_helper
INFO - 2024-05-31 10:49:18 --> Helper loaded: form_helper
INFO - 2024-05-31 10:49:18 --> Helper loaded: my_helper
INFO - 2024-05-31 10:49:18 --> Database Driver Class Initialized
INFO - 2024-05-31 10:49:18 --> Session: Class initialized using 'files' driver.
INFO - 2024-05-31 10:49:18 --> Controller Class Initialized
INFO - 2024-05-31 10:49:18 --> Final output sent to browser
DEBUG - 2024-05-31 10:49:18 --> Total execution time: 0.0348
INFO - 2024-05-31 10:50:13 --> Config Class Initialized
INFO - 2024-05-31 10:50:13 --> Hooks Class Initialized
DEBUG - 2024-05-31 10:50:13 --> UTF-8 Support Enabled
INFO - 2024-05-31 10:50:13 --> Utf8 Class Initialized
INFO - 2024-05-31 10:50:13 --> URI Class Initialized
INFO - 2024-05-31 10:50:13 --> Router Class Initialized
INFO - 2024-05-31 10:50:13 --> Output Class Initialized
INFO - 2024-05-31 10:50:13 --> Security Class Initialized
DEBUG - 2024-05-31 10:50:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-05-31 10:50:13 --> Input Class Initialized
INFO - 2024-05-31 10:50:13 --> Language Class Initialized
INFO - 2024-05-31 10:50:13 --> Language Class Initialized
INFO - 2024-05-31 10:50:13 --> Config Class Initialized
INFO - 2024-05-31 10:50:13 --> Loader Class Initialized
INFO - 2024-05-31 10:50:13 --> Helper loaded: url_helper
INFO - 2024-05-31 10:50:13 --> Helper loaded: file_helper
INFO - 2024-05-31 10:50:13 --> Helper loaded: form_helper
INFO - 2024-05-31 10:50:13 --> Helper loaded: my_helper
INFO - 2024-05-31 10:50:13 --> Database Driver Class Initialized
INFO - 2024-05-31 10:50:13 --> Session: Class initialized using 'files' driver.
INFO - 2024-05-31 10:50:13 --> Controller Class Initialized
INFO - 2024-05-31 10:50:13 --> Final output sent to browser
DEBUG - 2024-05-31 10:50:13 --> Total execution time: 0.0241
INFO - 2024-05-31 10:50:29 --> Config Class Initialized
INFO - 2024-05-31 10:50:29 --> Hooks Class Initialized
DEBUG - 2024-05-31 10:50:29 --> UTF-8 Support Enabled
INFO - 2024-05-31 10:50:29 --> Utf8 Class Initialized
INFO - 2024-05-31 10:50:29 --> URI Class Initialized
INFO - 2024-05-31 10:50:29 --> Router Class Initialized
INFO - 2024-05-31 10:50:29 --> Output Class Initialized
INFO - 2024-05-31 10:50:29 --> Security Class Initialized
DEBUG - 2024-05-31 10:50:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-05-31 10:50:29 --> Input Class Initialized
INFO - 2024-05-31 10:50:29 --> Language Class Initialized
INFO - 2024-05-31 10:50:29 --> Language Class Initialized
INFO - 2024-05-31 10:50:29 --> Config Class Initialized
INFO - 2024-05-31 10:50:29 --> Loader Class Initialized
INFO - 2024-05-31 10:50:29 --> Helper loaded: url_helper
INFO - 2024-05-31 10:50:29 --> Helper loaded: file_helper
INFO - 2024-05-31 10:50:29 --> Helper loaded: form_helper
INFO - 2024-05-31 10:50:29 --> Helper loaded: my_helper
INFO - 2024-05-31 10:50:29 --> Database Driver Class Initialized
INFO - 2024-05-31 10:50:29 --> Session: Class initialized using 'files' driver.
INFO - 2024-05-31 10:50:29 --> Controller Class Initialized
INFO - 2024-05-31 10:50:29 --> Final output sent to browser
DEBUG - 2024-05-31 10:50:29 --> Total execution time: 0.0344
INFO - 2024-05-31 10:51:11 --> Config Class Initialized
INFO - 2024-05-31 10:51:11 --> Hooks Class Initialized
DEBUG - 2024-05-31 10:51:11 --> UTF-8 Support Enabled
INFO - 2024-05-31 10:51:11 --> Utf8 Class Initialized
INFO - 2024-05-31 10:51:11 --> URI Class Initialized
INFO - 2024-05-31 10:51:11 --> Router Class Initialized
INFO - 2024-05-31 10:51:11 --> Output Class Initialized
INFO - 2024-05-31 10:51:11 --> Security Class Initialized
DEBUG - 2024-05-31 10:51:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-05-31 10:51:11 --> Input Class Initialized
INFO - 2024-05-31 10:51:11 --> Language Class Initialized
INFO - 2024-05-31 10:51:11 --> Language Class Initialized
INFO - 2024-05-31 10:51:11 --> Config Class Initialized
INFO - 2024-05-31 10:51:11 --> Loader Class Initialized
INFO - 2024-05-31 10:51:11 --> Helper loaded: url_helper
INFO - 2024-05-31 10:51:11 --> Helper loaded: file_helper
INFO - 2024-05-31 10:51:11 --> Helper loaded: form_helper
INFO - 2024-05-31 10:51:11 --> Helper loaded: my_helper
INFO - 2024-05-31 10:51:11 --> Database Driver Class Initialized
INFO - 2024-05-31 10:51:11 --> Session: Class initialized using 'files' driver.
INFO - 2024-05-31 10:51:11 --> Controller Class Initialized
INFO - 2024-05-31 10:51:11 --> Final output sent to browser
DEBUG - 2024-05-31 10:51:11 --> Total execution time: 0.0359
INFO - 2024-05-31 10:51:11 --> Config Class Initialized
INFO - 2024-05-31 10:51:11 --> Hooks Class Initialized
DEBUG - 2024-05-31 10:51:11 --> UTF-8 Support Enabled
INFO - 2024-05-31 10:51:11 --> Utf8 Class Initialized
INFO - 2024-05-31 10:51:11 --> URI Class Initialized
INFO - 2024-05-31 10:51:11 --> Router Class Initialized
INFO - 2024-05-31 10:51:11 --> Output Class Initialized
INFO - 2024-05-31 10:51:11 --> Security Class Initialized
DEBUG - 2024-05-31 10:51:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-05-31 10:51:11 --> Input Class Initialized
INFO - 2024-05-31 10:51:11 --> Language Class Initialized
INFO - 2024-05-31 10:51:11 --> Language Class Initialized
INFO - 2024-05-31 10:51:11 --> Config Class Initialized
INFO - 2024-05-31 10:51:11 --> Loader Class Initialized
INFO - 2024-05-31 10:51:11 --> Helper loaded: url_helper
INFO - 2024-05-31 10:51:11 --> Helper loaded: file_helper
INFO - 2024-05-31 10:51:11 --> Helper loaded: form_helper
INFO - 2024-05-31 10:51:11 --> Helper loaded: my_helper
INFO - 2024-05-31 10:51:12 --> Database Driver Class Initialized
INFO - 2024-05-31 10:51:12 --> Session: Class initialized using 'files' driver.
INFO - 2024-05-31 10:51:12 --> Controller Class Initialized
INFO - 2024-05-31 10:51:17 --> Config Class Initialized
INFO - 2024-05-31 10:51:17 --> Hooks Class Initialized
DEBUG - 2024-05-31 10:51:17 --> UTF-8 Support Enabled
INFO - 2024-05-31 10:51:17 --> Utf8 Class Initialized
INFO - 2024-05-31 10:51:17 --> URI Class Initialized
INFO - 2024-05-31 10:51:17 --> Router Class Initialized
INFO - 2024-05-31 10:51:17 --> Output Class Initialized
INFO - 2024-05-31 10:51:17 --> Security Class Initialized
DEBUG - 2024-05-31 10:51:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-05-31 10:51:17 --> Input Class Initialized
INFO - 2024-05-31 10:51:17 --> Language Class Initialized
INFO - 2024-05-31 10:51:17 --> Language Class Initialized
INFO - 2024-05-31 10:51:17 --> Config Class Initialized
INFO - 2024-05-31 10:51:17 --> Loader Class Initialized
INFO - 2024-05-31 10:51:17 --> Helper loaded: url_helper
INFO - 2024-05-31 10:51:17 --> Helper loaded: file_helper
INFO - 2024-05-31 10:51:17 --> Helper loaded: form_helper
INFO - 2024-05-31 10:51:17 --> Helper loaded: my_helper
INFO - 2024-05-31 10:51:17 --> Database Driver Class Initialized
INFO - 2024-05-31 10:51:17 --> Session: Class initialized using 'files' driver.
INFO - 2024-05-31 10:51:17 --> Controller Class Initialized
INFO - 2024-05-31 10:51:17 --> Final output sent to browser
DEBUG - 2024-05-31 10:51:17 --> Total execution time: 0.0252
INFO - 2024-05-31 10:51:23 --> Config Class Initialized
INFO - 2024-05-31 10:51:23 --> Hooks Class Initialized
DEBUG - 2024-05-31 10:51:23 --> UTF-8 Support Enabled
INFO - 2024-05-31 10:51:23 --> Utf8 Class Initialized
INFO - 2024-05-31 10:51:23 --> URI Class Initialized
INFO - 2024-05-31 10:51:23 --> Router Class Initialized
INFO - 2024-05-31 10:51:23 --> Output Class Initialized
INFO - 2024-05-31 10:51:23 --> Security Class Initialized
DEBUG - 2024-05-31 10:51:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-05-31 10:51:23 --> Input Class Initialized
INFO - 2024-05-31 10:51:23 --> Language Class Initialized
INFO - 2024-05-31 10:51:23 --> Language Class Initialized
INFO - 2024-05-31 10:51:23 --> Config Class Initialized
INFO - 2024-05-31 10:51:23 --> Loader Class Initialized
INFO - 2024-05-31 10:51:23 --> Helper loaded: url_helper
INFO - 2024-05-31 10:51:23 --> Helper loaded: file_helper
INFO - 2024-05-31 10:51:23 --> Helper loaded: form_helper
INFO - 2024-05-31 10:51:23 --> Helper loaded: my_helper
INFO - 2024-05-31 10:51:23 --> Database Driver Class Initialized
INFO - 2024-05-31 10:51:23 --> Session: Class initialized using 'files' driver.
INFO - 2024-05-31 10:51:23 --> Controller Class Initialized
INFO - 2024-05-31 10:51:23 --> Final output sent to browser
DEBUG - 2024-05-31 10:51:23 --> Total execution time: 0.0512
INFO - 2024-05-31 10:51:23 --> Config Class Initialized
INFO - 2024-05-31 10:51:23 --> Hooks Class Initialized
DEBUG - 2024-05-31 10:51:23 --> UTF-8 Support Enabled
INFO - 2024-05-31 10:51:23 --> Utf8 Class Initialized
INFO - 2024-05-31 10:51:23 --> URI Class Initialized
INFO - 2024-05-31 10:51:23 --> Router Class Initialized
INFO - 2024-05-31 10:51:23 --> Output Class Initialized
INFO - 2024-05-31 10:51:23 --> Security Class Initialized
DEBUG - 2024-05-31 10:51:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-05-31 10:51:23 --> Input Class Initialized
INFO - 2024-05-31 10:51:23 --> Language Class Initialized
INFO - 2024-05-31 10:51:23 --> Language Class Initialized
INFO - 2024-05-31 10:51:23 --> Config Class Initialized
INFO - 2024-05-31 10:51:23 --> Loader Class Initialized
INFO - 2024-05-31 10:51:23 --> Helper loaded: url_helper
INFO - 2024-05-31 10:51:23 --> Helper loaded: file_helper
INFO - 2024-05-31 10:51:23 --> Helper loaded: form_helper
INFO - 2024-05-31 10:51:23 --> Helper loaded: my_helper
INFO - 2024-05-31 10:51:23 --> Database Driver Class Initialized
INFO - 2024-05-31 10:51:23 --> Session: Class initialized using 'files' driver.
INFO - 2024-05-31 10:51:23 --> Controller Class Initialized
INFO - 2024-05-31 10:51:25 --> Config Class Initialized
INFO - 2024-05-31 10:51:25 --> Hooks Class Initialized
DEBUG - 2024-05-31 10:51:25 --> UTF-8 Support Enabled
INFO - 2024-05-31 10:51:25 --> Utf8 Class Initialized
INFO - 2024-05-31 10:51:25 --> URI Class Initialized
INFO - 2024-05-31 10:51:25 --> Router Class Initialized
INFO - 2024-05-31 10:51:25 --> Output Class Initialized
INFO - 2024-05-31 10:51:25 --> Security Class Initialized
DEBUG - 2024-05-31 10:51:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-05-31 10:51:25 --> Input Class Initialized
INFO - 2024-05-31 10:51:25 --> Language Class Initialized
INFO - 2024-05-31 10:51:25 --> Language Class Initialized
INFO - 2024-05-31 10:51:25 --> Config Class Initialized
INFO - 2024-05-31 10:51:25 --> Loader Class Initialized
INFO - 2024-05-31 10:51:25 --> Helper loaded: url_helper
INFO - 2024-05-31 10:51:25 --> Helper loaded: file_helper
INFO - 2024-05-31 10:51:25 --> Helper loaded: form_helper
INFO - 2024-05-31 10:51:25 --> Helper loaded: my_helper
INFO - 2024-05-31 10:51:25 --> Database Driver Class Initialized
INFO - 2024-05-31 10:51:25 --> Session: Class initialized using 'files' driver.
INFO - 2024-05-31 10:51:25 --> Controller Class Initialized
INFO - 2024-05-31 10:51:25 --> Final output sent to browser
DEBUG - 2024-05-31 10:51:25 --> Total execution time: 0.0247
INFO - 2024-05-31 10:51:29 --> Config Class Initialized
INFO - 2024-05-31 10:51:29 --> Hooks Class Initialized
DEBUG - 2024-05-31 10:51:29 --> UTF-8 Support Enabled
INFO - 2024-05-31 10:51:29 --> Utf8 Class Initialized
INFO - 2024-05-31 10:51:29 --> URI Class Initialized
INFO - 2024-05-31 10:51:29 --> Router Class Initialized
INFO - 2024-05-31 10:51:29 --> Output Class Initialized
INFO - 2024-05-31 10:51:29 --> Security Class Initialized
DEBUG - 2024-05-31 10:51:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-05-31 10:51:29 --> Input Class Initialized
INFO - 2024-05-31 10:51:29 --> Language Class Initialized
INFO - 2024-05-31 10:51:29 --> Language Class Initialized
INFO - 2024-05-31 10:51:29 --> Config Class Initialized
INFO - 2024-05-31 10:51:29 --> Loader Class Initialized
INFO - 2024-05-31 10:51:29 --> Helper loaded: url_helper
INFO - 2024-05-31 10:51:29 --> Helper loaded: file_helper
INFO - 2024-05-31 10:51:29 --> Helper loaded: form_helper
INFO - 2024-05-31 10:51:29 --> Helper loaded: my_helper
INFO - 2024-05-31 10:51:29 --> Database Driver Class Initialized
INFO - 2024-05-31 10:51:29 --> Session: Class initialized using 'files' driver.
INFO - 2024-05-31 10:51:29 --> Controller Class Initialized
INFO - 2024-05-31 10:51:29 --> Final output sent to browser
DEBUG - 2024-05-31 10:51:29 --> Total execution time: 0.0268
INFO - 2024-05-31 10:51:29 --> Config Class Initialized
INFO - 2024-05-31 10:51:29 --> Hooks Class Initialized
DEBUG - 2024-05-31 10:51:29 --> UTF-8 Support Enabled
INFO - 2024-05-31 10:51:29 --> Utf8 Class Initialized
INFO - 2024-05-31 10:51:29 --> URI Class Initialized
INFO - 2024-05-31 10:51:29 --> Router Class Initialized
INFO - 2024-05-31 10:51:29 --> Output Class Initialized
INFO - 2024-05-31 10:51:29 --> Security Class Initialized
DEBUG - 2024-05-31 10:51:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-05-31 10:51:29 --> Input Class Initialized
INFO - 2024-05-31 10:51:29 --> Language Class Initialized
INFO - 2024-05-31 10:51:29 --> Language Class Initialized
INFO - 2024-05-31 10:51:29 --> Config Class Initialized
INFO - 2024-05-31 10:51:29 --> Loader Class Initialized
INFO - 2024-05-31 10:51:29 --> Helper loaded: url_helper
INFO - 2024-05-31 10:51:29 --> Helper loaded: file_helper
INFO - 2024-05-31 10:51:29 --> Helper loaded: form_helper
INFO - 2024-05-31 10:51:29 --> Helper loaded: my_helper
INFO - 2024-05-31 10:51:29 --> Database Driver Class Initialized
INFO - 2024-05-31 10:51:29 --> Session: Class initialized using 'files' driver.
INFO - 2024-05-31 10:51:29 --> Controller Class Initialized
INFO - 2024-05-31 10:51:31 --> Config Class Initialized
INFO - 2024-05-31 10:51:31 --> Hooks Class Initialized
DEBUG - 2024-05-31 10:51:31 --> UTF-8 Support Enabled
INFO - 2024-05-31 10:51:31 --> Utf8 Class Initialized
INFO - 2024-05-31 10:51:31 --> URI Class Initialized
INFO - 2024-05-31 10:51:31 --> Router Class Initialized
INFO - 2024-05-31 10:51:31 --> Output Class Initialized
INFO - 2024-05-31 10:51:31 --> Security Class Initialized
DEBUG - 2024-05-31 10:51:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-05-31 10:51:31 --> Input Class Initialized
INFO - 2024-05-31 10:51:31 --> Language Class Initialized
INFO - 2024-05-31 10:51:31 --> Language Class Initialized
INFO - 2024-05-31 10:51:31 --> Config Class Initialized
INFO - 2024-05-31 10:51:31 --> Loader Class Initialized
INFO - 2024-05-31 10:51:31 --> Helper loaded: url_helper
INFO - 2024-05-31 10:51:31 --> Helper loaded: file_helper
INFO - 2024-05-31 10:51:31 --> Helper loaded: form_helper
INFO - 2024-05-31 10:51:31 --> Helper loaded: my_helper
INFO - 2024-05-31 10:51:31 --> Database Driver Class Initialized
INFO - 2024-05-31 10:51:31 --> Session: Class initialized using 'files' driver.
INFO - 2024-05-31 10:51:31 --> Controller Class Initialized
INFO - 2024-05-31 10:51:31 --> Final output sent to browser
DEBUG - 2024-05-31 10:51:31 --> Total execution time: 0.0262
INFO - 2024-05-31 10:51:49 --> Config Class Initialized
INFO - 2024-05-31 10:51:49 --> Hooks Class Initialized
DEBUG - 2024-05-31 10:51:49 --> UTF-8 Support Enabled
INFO - 2024-05-31 10:51:49 --> Utf8 Class Initialized
INFO - 2024-05-31 10:51:49 --> URI Class Initialized
INFO - 2024-05-31 10:51:49 --> Router Class Initialized
INFO - 2024-05-31 10:51:49 --> Output Class Initialized
INFO - 2024-05-31 10:51:49 --> Security Class Initialized
DEBUG - 2024-05-31 10:51:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-05-31 10:51:49 --> Input Class Initialized
INFO - 2024-05-31 10:51:49 --> Language Class Initialized
INFO - 2024-05-31 10:51:49 --> Language Class Initialized
INFO - 2024-05-31 10:51:49 --> Config Class Initialized
INFO - 2024-05-31 10:51:49 --> Loader Class Initialized
INFO - 2024-05-31 10:51:49 --> Helper loaded: url_helper
INFO - 2024-05-31 10:51:49 --> Helper loaded: file_helper
INFO - 2024-05-31 10:51:49 --> Helper loaded: form_helper
INFO - 2024-05-31 10:51:49 --> Helper loaded: my_helper
INFO - 2024-05-31 10:51:49 --> Database Driver Class Initialized
INFO - 2024-05-31 10:51:49 --> Session: Class initialized using 'files' driver.
INFO - 2024-05-31 10:51:49 --> Controller Class Initialized
INFO - 2024-05-31 10:51:49 --> Final output sent to browser
DEBUG - 2024-05-31 10:51:49 --> Total execution time: 0.0298
INFO - 2024-05-31 10:51:49 --> Config Class Initialized
INFO - 2024-05-31 10:51:49 --> Hooks Class Initialized
DEBUG - 2024-05-31 10:51:49 --> UTF-8 Support Enabled
INFO - 2024-05-31 10:51:49 --> Utf8 Class Initialized
INFO - 2024-05-31 10:51:49 --> URI Class Initialized
INFO - 2024-05-31 10:51:49 --> Router Class Initialized
INFO - 2024-05-31 10:51:49 --> Output Class Initialized
INFO - 2024-05-31 10:51:49 --> Security Class Initialized
DEBUG - 2024-05-31 10:51:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-05-31 10:51:49 --> Input Class Initialized
INFO - 2024-05-31 10:51:49 --> Language Class Initialized
INFO - 2024-05-31 10:51:49 --> Language Class Initialized
INFO - 2024-05-31 10:51:49 --> Config Class Initialized
INFO - 2024-05-31 10:51:49 --> Loader Class Initialized
INFO - 2024-05-31 10:51:49 --> Helper loaded: url_helper
INFO - 2024-05-31 10:51:49 --> Helper loaded: file_helper
INFO - 2024-05-31 10:51:49 --> Helper loaded: form_helper
INFO - 2024-05-31 10:51:49 --> Helper loaded: my_helper
INFO - 2024-05-31 10:51:49 --> Database Driver Class Initialized
INFO - 2024-05-31 10:51:49 --> Session: Class initialized using 'files' driver.
INFO - 2024-05-31 10:51:49 --> Controller Class Initialized
INFO - 2024-05-31 10:51:53 --> Config Class Initialized
INFO - 2024-05-31 10:51:53 --> Hooks Class Initialized
DEBUG - 2024-05-31 10:51:53 --> UTF-8 Support Enabled
INFO - 2024-05-31 10:51:53 --> Utf8 Class Initialized
INFO - 2024-05-31 10:51:53 --> URI Class Initialized
INFO - 2024-05-31 10:51:53 --> Router Class Initialized
INFO - 2024-05-31 10:51:53 --> Output Class Initialized
INFO - 2024-05-31 10:51:53 --> Security Class Initialized
DEBUG - 2024-05-31 10:51:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-05-31 10:51:53 --> Input Class Initialized
INFO - 2024-05-31 10:51:53 --> Language Class Initialized
INFO - 2024-05-31 10:51:53 --> Language Class Initialized
INFO - 2024-05-31 10:51:53 --> Config Class Initialized
INFO - 2024-05-31 10:51:53 --> Loader Class Initialized
INFO - 2024-05-31 10:51:53 --> Helper loaded: url_helper
INFO - 2024-05-31 10:51:53 --> Helper loaded: file_helper
INFO - 2024-05-31 10:51:53 --> Helper loaded: form_helper
INFO - 2024-05-31 10:51:53 --> Helper loaded: my_helper
INFO - 2024-05-31 10:51:53 --> Database Driver Class Initialized
INFO - 2024-05-31 10:51:53 --> Session: Class initialized using 'files' driver.
INFO - 2024-05-31 10:51:53 --> Controller Class Initialized
INFO - 2024-05-31 10:51:53 --> Final output sent to browser
DEBUG - 2024-05-31 10:51:53 --> Total execution time: 0.0293
INFO - 2024-05-31 10:52:26 --> Config Class Initialized
INFO - 2024-05-31 10:52:26 --> Hooks Class Initialized
DEBUG - 2024-05-31 10:52:26 --> UTF-8 Support Enabled
INFO - 2024-05-31 10:52:26 --> Utf8 Class Initialized
INFO - 2024-05-31 10:52:26 --> URI Class Initialized
INFO - 2024-05-31 10:52:26 --> Router Class Initialized
INFO - 2024-05-31 10:52:26 --> Output Class Initialized
INFO - 2024-05-31 10:52:26 --> Security Class Initialized
DEBUG - 2024-05-31 10:52:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-05-31 10:52:26 --> Input Class Initialized
INFO - 2024-05-31 10:52:26 --> Language Class Initialized
INFO - 2024-05-31 10:52:26 --> Language Class Initialized
INFO - 2024-05-31 10:52:26 --> Config Class Initialized
INFO - 2024-05-31 10:52:26 --> Loader Class Initialized
INFO - 2024-05-31 10:52:26 --> Helper loaded: url_helper
INFO - 2024-05-31 10:52:26 --> Helper loaded: file_helper
INFO - 2024-05-31 10:52:26 --> Helper loaded: form_helper
INFO - 2024-05-31 10:52:26 --> Helper loaded: my_helper
INFO - 2024-05-31 10:52:26 --> Database Driver Class Initialized
INFO - 2024-05-31 10:52:26 --> Session: Class initialized using 'files' driver.
INFO - 2024-05-31 10:52:26 --> Controller Class Initialized
INFO - 2024-05-31 10:52:26 --> Final output sent to browser
DEBUG - 2024-05-31 10:52:26 --> Total execution time: 0.0284
INFO - 2024-05-31 10:52:26 --> Config Class Initialized
INFO - 2024-05-31 10:52:26 --> Hooks Class Initialized
DEBUG - 2024-05-31 10:52:27 --> UTF-8 Support Enabled
INFO - 2024-05-31 10:52:27 --> Utf8 Class Initialized
INFO - 2024-05-31 10:52:27 --> URI Class Initialized
INFO - 2024-05-31 10:52:27 --> Router Class Initialized
INFO - 2024-05-31 10:52:27 --> Output Class Initialized
INFO - 2024-05-31 10:52:27 --> Security Class Initialized
DEBUG - 2024-05-31 10:52:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-05-31 10:52:27 --> Input Class Initialized
INFO - 2024-05-31 10:52:27 --> Language Class Initialized
INFO - 2024-05-31 10:52:27 --> Language Class Initialized
INFO - 2024-05-31 10:52:27 --> Config Class Initialized
INFO - 2024-05-31 10:52:27 --> Loader Class Initialized
INFO - 2024-05-31 10:52:27 --> Helper loaded: url_helper
INFO - 2024-05-31 10:52:27 --> Helper loaded: file_helper
INFO - 2024-05-31 10:52:27 --> Helper loaded: form_helper
INFO - 2024-05-31 10:52:27 --> Helper loaded: my_helper
INFO - 2024-05-31 10:52:27 --> Database Driver Class Initialized
INFO - 2024-05-31 10:52:27 --> Session: Class initialized using 'files' driver.
INFO - 2024-05-31 10:52:27 --> Controller Class Initialized
INFO - 2024-05-31 10:52:28 --> Config Class Initialized
INFO - 2024-05-31 10:52:28 --> Hooks Class Initialized
DEBUG - 2024-05-31 10:52:28 --> UTF-8 Support Enabled
INFO - 2024-05-31 10:52:28 --> Utf8 Class Initialized
INFO - 2024-05-31 10:52:28 --> URI Class Initialized
INFO - 2024-05-31 10:52:28 --> Router Class Initialized
INFO - 2024-05-31 10:52:28 --> Output Class Initialized
INFO - 2024-05-31 10:52:28 --> Security Class Initialized
DEBUG - 2024-05-31 10:52:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-05-31 10:52:28 --> Input Class Initialized
INFO - 2024-05-31 10:52:28 --> Language Class Initialized
INFO - 2024-05-31 10:52:28 --> Language Class Initialized
INFO - 2024-05-31 10:52:28 --> Config Class Initialized
INFO - 2024-05-31 10:52:28 --> Loader Class Initialized
INFO - 2024-05-31 10:52:28 --> Helper loaded: url_helper
INFO - 2024-05-31 10:52:28 --> Helper loaded: file_helper
INFO - 2024-05-31 10:52:28 --> Helper loaded: form_helper
INFO - 2024-05-31 10:52:28 --> Helper loaded: my_helper
INFO - 2024-05-31 10:52:28 --> Database Driver Class Initialized
INFO - 2024-05-31 10:52:28 --> Session: Class initialized using 'files' driver.
INFO - 2024-05-31 10:52:28 --> Controller Class Initialized
INFO - 2024-05-31 10:52:28 --> Final output sent to browser
DEBUG - 2024-05-31 10:52:28 --> Total execution time: 0.0292
INFO - 2024-05-31 10:52:47 --> Config Class Initialized
INFO - 2024-05-31 10:52:47 --> Hooks Class Initialized
DEBUG - 2024-05-31 10:52:47 --> UTF-8 Support Enabled
INFO - 2024-05-31 10:52:47 --> Utf8 Class Initialized
INFO - 2024-05-31 10:52:47 --> URI Class Initialized
INFO - 2024-05-31 10:52:47 --> Router Class Initialized
INFO - 2024-05-31 10:52:47 --> Output Class Initialized
INFO - 2024-05-31 10:52:47 --> Security Class Initialized
DEBUG - 2024-05-31 10:52:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-05-31 10:52:47 --> Input Class Initialized
INFO - 2024-05-31 10:52:47 --> Language Class Initialized
INFO - 2024-05-31 10:52:47 --> Language Class Initialized
INFO - 2024-05-31 10:52:47 --> Config Class Initialized
INFO - 2024-05-31 10:52:47 --> Loader Class Initialized
INFO - 2024-05-31 10:52:47 --> Helper loaded: url_helper
INFO - 2024-05-31 10:52:47 --> Helper loaded: file_helper
INFO - 2024-05-31 10:52:47 --> Helper loaded: form_helper
INFO - 2024-05-31 10:52:47 --> Helper loaded: my_helper
INFO - 2024-05-31 10:52:47 --> Database Driver Class Initialized
INFO - 2024-05-31 10:52:47 --> Session: Class initialized using 'files' driver.
INFO - 2024-05-31 10:52:47 --> Controller Class Initialized
INFO - 2024-05-31 10:52:47 --> Final output sent to browser
DEBUG - 2024-05-31 10:52:47 --> Total execution time: 0.0368
INFO - 2024-05-31 10:52:47 --> Config Class Initialized
INFO - 2024-05-31 10:52:47 --> Hooks Class Initialized
DEBUG - 2024-05-31 10:52:47 --> UTF-8 Support Enabled
INFO - 2024-05-31 10:52:47 --> Utf8 Class Initialized
INFO - 2024-05-31 10:52:47 --> URI Class Initialized
INFO - 2024-05-31 10:52:47 --> Router Class Initialized
INFO - 2024-05-31 10:52:47 --> Output Class Initialized
INFO - 2024-05-31 10:52:47 --> Security Class Initialized
DEBUG - 2024-05-31 10:52:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-05-31 10:52:47 --> Input Class Initialized
INFO - 2024-05-31 10:52:47 --> Language Class Initialized
INFO - 2024-05-31 10:52:47 --> Language Class Initialized
INFO - 2024-05-31 10:52:47 --> Config Class Initialized
INFO - 2024-05-31 10:52:47 --> Loader Class Initialized
INFO - 2024-05-31 10:52:47 --> Helper loaded: url_helper
INFO - 2024-05-31 10:52:47 --> Helper loaded: file_helper
INFO - 2024-05-31 10:52:47 --> Helper loaded: form_helper
INFO - 2024-05-31 10:52:47 --> Helper loaded: my_helper
INFO - 2024-05-31 10:52:47 --> Database Driver Class Initialized
INFO - 2024-05-31 10:52:47 --> Session: Class initialized using 'files' driver.
INFO - 2024-05-31 10:52:47 --> Controller Class Initialized
INFO - 2024-05-31 10:52:55 --> Config Class Initialized
INFO - 2024-05-31 10:52:55 --> Hooks Class Initialized
DEBUG - 2024-05-31 10:52:55 --> UTF-8 Support Enabled
INFO - 2024-05-31 10:52:55 --> Utf8 Class Initialized
INFO - 2024-05-31 10:52:55 --> URI Class Initialized
INFO - 2024-05-31 10:52:55 --> Router Class Initialized
INFO - 2024-05-31 10:52:55 --> Output Class Initialized
INFO - 2024-05-31 10:52:55 --> Security Class Initialized
DEBUG - 2024-05-31 10:52:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-05-31 10:52:55 --> Input Class Initialized
INFO - 2024-05-31 10:52:55 --> Language Class Initialized
INFO - 2024-05-31 10:52:55 --> Language Class Initialized
INFO - 2024-05-31 10:52:55 --> Config Class Initialized
INFO - 2024-05-31 10:52:55 --> Loader Class Initialized
INFO - 2024-05-31 10:52:55 --> Helper loaded: url_helper
INFO - 2024-05-31 10:52:55 --> Helper loaded: file_helper
INFO - 2024-05-31 10:52:55 --> Helper loaded: form_helper
INFO - 2024-05-31 10:52:55 --> Helper loaded: my_helper
INFO - 2024-05-31 10:52:55 --> Database Driver Class Initialized
INFO - 2024-05-31 10:52:55 --> Session: Class initialized using 'files' driver.
INFO - 2024-05-31 10:52:55 --> Controller Class Initialized
INFO - 2024-05-31 10:52:55 --> Final output sent to browser
DEBUG - 2024-05-31 10:52:55 --> Total execution time: 0.0327
INFO - 2024-05-31 10:52:55 --> Config Class Initialized
INFO - 2024-05-31 10:52:55 --> Hooks Class Initialized
DEBUG - 2024-05-31 10:52:55 --> UTF-8 Support Enabled
INFO - 2024-05-31 10:52:55 --> Utf8 Class Initialized
INFO - 2024-05-31 10:52:55 --> URI Class Initialized
INFO - 2024-05-31 10:52:55 --> Router Class Initialized
INFO - 2024-05-31 10:52:55 --> Output Class Initialized
INFO - 2024-05-31 10:52:55 --> Security Class Initialized
DEBUG - 2024-05-31 10:52:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-05-31 10:52:55 --> Input Class Initialized
INFO - 2024-05-31 10:52:55 --> Language Class Initialized
INFO - 2024-05-31 10:52:55 --> Language Class Initialized
INFO - 2024-05-31 10:52:55 --> Config Class Initialized
INFO - 2024-05-31 10:52:55 --> Loader Class Initialized
INFO - 2024-05-31 10:52:55 --> Helper loaded: url_helper
INFO - 2024-05-31 10:52:55 --> Helper loaded: file_helper
INFO - 2024-05-31 10:52:55 --> Helper loaded: form_helper
INFO - 2024-05-31 10:52:55 --> Helper loaded: my_helper
INFO - 2024-05-31 10:52:55 --> Database Driver Class Initialized
INFO - 2024-05-31 10:52:55 --> Session: Class initialized using 'files' driver.
INFO - 2024-05-31 10:52:55 --> Controller Class Initialized
INFO - 2024-05-31 10:53:05 --> Config Class Initialized
INFO - 2024-05-31 10:53:05 --> Hooks Class Initialized
DEBUG - 2024-05-31 10:53:05 --> UTF-8 Support Enabled
INFO - 2024-05-31 10:53:05 --> Utf8 Class Initialized
INFO - 2024-05-31 10:53:05 --> URI Class Initialized
INFO - 2024-05-31 10:53:05 --> Router Class Initialized
INFO - 2024-05-31 10:53:05 --> Output Class Initialized
INFO - 2024-05-31 10:53:05 --> Security Class Initialized
DEBUG - 2024-05-31 10:53:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-05-31 10:53:05 --> Input Class Initialized
INFO - 2024-05-31 10:53:05 --> Language Class Initialized
INFO - 2024-05-31 10:53:05 --> Language Class Initialized
INFO - 2024-05-31 10:53:05 --> Config Class Initialized
INFO - 2024-05-31 10:53:05 --> Loader Class Initialized
INFO - 2024-05-31 10:53:05 --> Helper loaded: url_helper
INFO - 2024-05-31 10:53:05 --> Helper loaded: file_helper
INFO - 2024-05-31 10:53:05 --> Helper loaded: form_helper
INFO - 2024-05-31 10:53:05 --> Helper loaded: my_helper
INFO - 2024-05-31 10:53:05 --> Database Driver Class Initialized
INFO - 2024-05-31 10:53:05 --> Session: Class initialized using 'files' driver.
INFO - 2024-05-31 10:53:05 --> Controller Class Initialized
INFO - 2024-05-31 10:53:05 --> Final output sent to browser
DEBUG - 2024-05-31 10:53:05 --> Total execution time: 0.0335
INFO - 2024-05-31 10:53:08 --> Config Class Initialized
INFO - 2024-05-31 10:53:08 --> Hooks Class Initialized
DEBUG - 2024-05-31 10:53:08 --> UTF-8 Support Enabled
INFO - 2024-05-31 10:53:08 --> Utf8 Class Initialized
INFO - 2024-05-31 10:53:08 --> URI Class Initialized
INFO - 2024-05-31 10:53:08 --> Router Class Initialized
INFO - 2024-05-31 10:53:08 --> Output Class Initialized
INFO - 2024-05-31 10:53:08 --> Security Class Initialized
DEBUG - 2024-05-31 10:53:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-05-31 10:53:08 --> Input Class Initialized
INFO - 2024-05-31 10:53:08 --> Language Class Initialized
INFO - 2024-05-31 10:53:08 --> Language Class Initialized
INFO - 2024-05-31 10:53:08 --> Config Class Initialized
INFO - 2024-05-31 10:53:08 --> Loader Class Initialized
INFO - 2024-05-31 10:53:08 --> Helper loaded: url_helper
INFO - 2024-05-31 10:53:08 --> Helper loaded: file_helper
INFO - 2024-05-31 10:53:08 --> Helper loaded: form_helper
INFO - 2024-05-31 10:53:08 --> Helper loaded: my_helper
INFO - 2024-05-31 10:53:08 --> Database Driver Class Initialized
INFO - 2024-05-31 10:53:08 --> Session: Class initialized using 'files' driver.
INFO - 2024-05-31 10:53:08 --> Controller Class Initialized
INFO - 2024-05-31 10:53:08 --> Final output sent to browser
DEBUG - 2024-05-31 10:53:08 --> Total execution time: 0.1817
INFO - 2024-05-31 10:53:27 --> Config Class Initialized
INFO - 2024-05-31 10:53:27 --> Hooks Class Initialized
DEBUG - 2024-05-31 10:53:27 --> UTF-8 Support Enabled
INFO - 2024-05-31 10:53:27 --> Utf8 Class Initialized
INFO - 2024-05-31 10:53:27 --> URI Class Initialized
INFO - 2024-05-31 10:53:27 --> Router Class Initialized
INFO - 2024-05-31 10:53:27 --> Output Class Initialized
INFO - 2024-05-31 10:53:27 --> Security Class Initialized
DEBUG - 2024-05-31 10:53:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-05-31 10:53:27 --> Input Class Initialized
INFO - 2024-05-31 10:53:27 --> Language Class Initialized
INFO - 2024-05-31 10:53:27 --> Language Class Initialized
INFO - 2024-05-31 10:53:27 --> Config Class Initialized
INFO - 2024-05-31 10:53:27 --> Loader Class Initialized
INFO - 2024-05-31 10:53:27 --> Helper loaded: url_helper
INFO - 2024-05-31 10:53:27 --> Helper loaded: file_helper
INFO - 2024-05-31 10:53:27 --> Helper loaded: form_helper
INFO - 2024-05-31 10:53:27 --> Helper loaded: my_helper
INFO - 2024-05-31 10:53:27 --> Database Driver Class Initialized
INFO - 2024-05-31 10:53:27 --> Session: Class initialized using 'files' driver.
INFO - 2024-05-31 10:53:27 --> Controller Class Initialized
INFO - 2024-05-31 10:53:27 --> Final output sent to browser
DEBUG - 2024-05-31 10:53:27 --> Total execution time: 0.1099
INFO - 2024-05-31 10:53:29 --> Config Class Initialized
INFO - 2024-05-31 10:53:29 --> Hooks Class Initialized
DEBUG - 2024-05-31 10:53:29 --> UTF-8 Support Enabled
INFO - 2024-05-31 10:53:29 --> Utf8 Class Initialized
INFO - 2024-05-31 10:53:29 --> URI Class Initialized
INFO - 2024-05-31 10:53:29 --> Router Class Initialized
INFO - 2024-05-31 10:53:29 --> Output Class Initialized
INFO - 2024-05-31 10:53:29 --> Security Class Initialized
DEBUG - 2024-05-31 10:53:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-05-31 10:53:29 --> Input Class Initialized
INFO - 2024-05-31 10:53:29 --> Language Class Initialized
INFO - 2024-05-31 10:53:29 --> Language Class Initialized
INFO - 2024-05-31 10:53:29 --> Config Class Initialized
INFO - 2024-05-31 10:53:29 --> Loader Class Initialized
INFO - 2024-05-31 10:53:29 --> Helper loaded: url_helper
INFO - 2024-05-31 10:53:29 --> Helper loaded: file_helper
INFO - 2024-05-31 10:53:29 --> Helper loaded: form_helper
INFO - 2024-05-31 10:53:29 --> Helper loaded: my_helper
INFO - 2024-05-31 10:53:29 --> Database Driver Class Initialized
INFO - 2024-05-31 10:53:29 --> Session: Class initialized using 'files' driver.
INFO - 2024-05-31 10:53:29 --> Controller Class Initialized
INFO - 2024-05-31 10:53:29 --> Final output sent to browser
DEBUG - 2024-05-31 10:53:29 --> Total execution time: 0.0296
INFO - 2024-05-31 10:53:37 --> Config Class Initialized
INFO - 2024-05-31 10:53:37 --> Hooks Class Initialized
DEBUG - 2024-05-31 10:53:37 --> UTF-8 Support Enabled
INFO - 2024-05-31 10:53:37 --> Utf8 Class Initialized
INFO - 2024-05-31 10:53:37 --> URI Class Initialized
INFO - 2024-05-31 10:53:37 --> Router Class Initialized
INFO - 2024-05-31 10:53:37 --> Output Class Initialized
INFO - 2024-05-31 10:53:37 --> Security Class Initialized
DEBUG - 2024-05-31 10:53:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-05-31 10:53:37 --> Input Class Initialized
INFO - 2024-05-31 10:53:37 --> Language Class Initialized
INFO - 2024-05-31 10:53:37 --> Language Class Initialized
INFO - 2024-05-31 10:53:37 --> Config Class Initialized
INFO - 2024-05-31 10:53:37 --> Loader Class Initialized
INFO - 2024-05-31 10:53:37 --> Helper loaded: url_helper
INFO - 2024-05-31 10:53:37 --> Helper loaded: file_helper
INFO - 2024-05-31 10:53:37 --> Helper loaded: form_helper
INFO - 2024-05-31 10:53:37 --> Helper loaded: my_helper
INFO - 2024-05-31 10:53:37 --> Database Driver Class Initialized
INFO - 2024-05-31 10:53:37 --> Session: Class initialized using 'files' driver.
INFO - 2024-05-31 10:53:37 --> Controller Class Initialized
INFO - 2024-05-31 10:53:38 --> Final output sent to browser
DEBUG - 2024-05-31 10:53:38 --> Total execution time: 0.0945
INFO - 2024-05-31 10:53:43 --> Config Class Initialized
INFO - 2024-05-31 10:53:43 --> Hooks Class Initialized
DEBUG - 2024-05-31 10:53:43 --> UTF-8 Support Enabled
INFO - 2024-05-31 10:53:43 --> Utf8 Class Initialized
INFO - 2024-05-31 10:53:43 --> URI Class Initialized
INFO - 2024-05-31 10:53:43 --> Router Class Initialized
INFO - 2024-05-31 10:53:43 --> Output Class Initialized
INFO - 2024-05-31 10:53:43 --> Security Class Initialized
DEBUG - 2024-05-31 10:53:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-05-31 10:53:43 --> Input Class Initialized
INFO - 2024-05-31 10:53:43 --> Language Class Initialized
INFO - 2024-05-31 10:53:43 --> Language Class Initialized
INFO - 2024-05-31 10:53:43 --> Config Class Initialized
INFO - 2024-05-31 10:53:43 --> Loader Class Initialized
INFO - 2024-05-31 10:53:43 --> Helper loaded: url_helper
INFO - 2024-05-31 10:53:43 --> Helper loaded: file_helper
INFO - 2024-05-31 10:53:43 --> Helper loaded: form_helper
INFO - 2024-05-31 10:53:43 --> Helper loaded: my_helper
INFO - 2024-05-31 10:53:43 --> Database Driver Class Initialized
INFO - 2024-05-31 10:53:43 --> Session: Class initialized using 'files' driver.
INFO - 2024-05-31 10:53:43 --> Controller Class Initialized
INFO - 2024-05-31 10:53:43 --> Final output sent to browser
DEBUG - 2024-05-31 10:53:43 --> Total execution time: 0.0385
INFO - 2024-05-31 11:05:30 --> Config Class Initialized
INFO - 2024-05-31 11:05:30 --> Hooks Class Initialized
DEBUG - 2024-05-31 11:05:30 --> UTF-8 Support Enabled
INFO - 2024-05-31 11:05:30 --> Utf8 Class Initialized
INFO - 2024-05-31 11:05:30 --> URI Class Initialized
INFO - 2024-05-31 11:05:30 --> Router Class Initialized
INFO - 2024-05-31 11:05:30 --> Output Class Initialized
INFO - 2024-05-31 11:05:30 --> Security Class Initialized
DEBUG - 2024-05-31 11:05:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-05-31 11:05:30 --> Input Class Initialized
INFO - 2024-05-31 11:05:30 --> Language Class Initialized
INFO - 2024-05-31 11:05:30 --> Language Class Initialized
INFO - 2024-05-31 11:05:30 --> Config Class Initialized
INFO - 2024-05-31 11:05:30 --> Loader Class Initialized
INFO - 2024-05-31 11:05:30 --> Helper loaded: url_helper
INFO - 2024-05-31 11:05:30 --> Helper loaded: file_helper
INFO - 2024-05-31 11:05:30 --> Helper loaded: form_helper
INFO - 2024-05-31 11:05:30 --> Helper loaded: my_helper
INFO - 2024-05-31 11:05:30 --> Database Driver Class Initialized
INFO - 2024-05-31 11:05:30 --> Session: Class initialized using 'files' driver.
INFO - 2024-05-31 11:05:30 --> Controller Class Initialized
INFO - 2024-05-31 11:05:30 --> Final output sent to browser
DEBUG - 2024-05-31 11:05:30 --> Total execution time: 0.1304
INFO - 2024-05-31 11:05:39 --> Config Class Initialized
INFO - 2024-05-31 11:05:39 --> Hooks Class Initialized
DEBUG - 2024-05-31 11:05:39 --> UTF-8 Support Enabled
INFO - 2024-05-31 11:05:39 --> Utf8 Class Initialized
INFO - 2024-05-31 11:05:39 --> URI Class Initialized
INFO - 2024-05-31 11:05:39 --> Router Class Initialized
INFO - 2024-05-31 11:05:39 --> Output Class Initialized
INFO - 2024-05-31 11:05:39 --> Security Class Initialized
DEBUG - 2024-05-31 11:05:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-05-31 11:05:39 --> Input Class Initialized
INFO - 2024-05-31 11:05:39 --> Language Class Initialized
INFO - 2024-05-31 11:05:39 --> Language Class Initialized
INFO - 2024-05-31 11:05:39 --> Config Class Initialized
INFO - 2024-05-31 11:05:39 --> Loader Class Initialized
INFO - 2024-05-31 11:05:39 --> Helper loaded: url_helper
INFO - 2024-05-31 11:05:39 --> Helper loaded: file_helper
INFO - 2024-05-31 11:05:39 --> Helper loaded: form_helper
INFO - 2024-05-31 11:05:39 --> Helper loaded: my_helper
INFO - 2024-05-31 11:05:39 --> Database Driver Class Initialized
INFO - 2024-05-31 11:05:39 --> Session: Class initialized using 'files' driver.
INFO - 2024-05-31 11:05:39 --> Controller Class Initialized
INFO - 2024-05-31 11:05:39 --> Final output sent to browser
DEBUG - 2024-05-31 11:05:39 --> Total execution time: 0.0338
INFO - 2024-05-31 11:05:41 --> Config Class Initialized
INFO - 2024-05-31 11:05:41 --> Hooks Class Initialized
DEBUG - 2024-05-31 11:05:41 --> UTF-8 Support Enabled
INFO - 2024-05-31 11:05:41 --> Utf8 Class Initialized
INFO - 2024-05-31 11:05:41 --> URI Class Initialized
INFO - 2024-05-31 11:05:41 --> Router Class Initialized
INFO - 2024-05-31 11:05:41 --> Output Class Initialized
INFO - 2024-05-31 11:05:41 --> Security Class Initialized
DEBUG - 2024-05-31 11:05:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-05-31 11:05:41 --> Input Class Initialized
INFO - 2024-05-31 11:05:41 --> Language Class Initialized
INFO - 2024-05-31 11:05:41 --> Language Class Initialized
INFO - 2024-05-31 11:05:41 --> Config Class Initialized
INFO - 2024-05-31 11:05:41 --> Loader Class Initialized
INFO - 2024-05-31 11:05:41 --> Helper loaded: url_helper
INFO - 2024-05-31 11:05:41 --> Helper loaded: file_helper
INFO - 2024-05-31 11:05:41 --> Helper loaded: form_helper
INFO - 2024-05-31 11:05:41 --> Helper loaded: my_helper
INFO - 2024-05-31 11:05:41 --> Database Driver Class Initialized
INFO - 2024-05-31 11:05:41 --> Session: Class initialized using 'files' driver.
INFO - 2024-05-31 11:05:41 --> Controller Class Initialized
INFO - 2024-05-31 11:05:41 --> Final output sent to browser
DEBUG - 2024-05-31 11:05:41 --> Total execution time: 0.0300
INFO - 2024-05-31 11:05:42 --> Config Class Initialized
INFO - 2024-05-31 11:05:42 --> Hooks Class Initialized
DEBUG - 2024-05-31 11:05:42 --> UTF-8 Support Enabled
INFO - 2024-05-31 11:05:42 --> Utf8 Class Initialized
INFO - 2024-05-31 11:05:42 --> URI Class Initialized
INFO - 2024-05-31 11:05:42 --> Router Class Initialized
INFO - 2024-05-31 11:05:42 --> Output Class Initialized
INFO - 2024-05-31 11:05:42 --> Security Class Initialized
DEBUG - 2024-05-31 11:05:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-05-31 11:05:42 --> Input Class Initialized
INFO - 2024-05-31 11:05:42 --> Language Class Initialized
INFO - 2024-05-31 11:05:42 --> Language Class Initialized
INFO - 2024-05-31 11:05:42 --> Config Class Initialized
INFO - 2024-05-31 11:05:42 --> Loader Class Initialized
INFO - 2024-05-31 11:05:42 --> Helper loaded: url_helper
INFO - 2024-05-31 11:05:42 --> Helper loaded: file_helper
INFO - 2024-05-31 11:05:42 --> Helper loaded: form_helper
INFO - 2024-05-31 11:05:42 --> Helper loaded: my_helper
INFO - 2024-05-31 11:05:42 --> Database Driver Class Initialized
INFO - 2024-05-31 11:05:42 --> Session: Class initialized using 'files' driver.
INFO - 2024-05-31 11:05:42 --> Controller Class Initialized
INFO - 2024-05-31 11:05:42 --> Final output sent to browser
DEBUG - 2024-05-31 11:05:42 --> Total execution time: 0.0285
INFO - 2024-05-31 11:10:20 --> Config Class Initialized
INFO - 2024-05-31 11:10:20 --> Hooks Class Initialized
DEBUG - 2024-05-31 11:10:20 --> UTF-8 Support Enabled
INFO - 2024-05-31 11:10:20 --> Utf8 Class Initialized
INFO - 2024-05-31 11:10:20 --> URI Class Initialized
INFO - 2024-05-31 11:10:20 --> Router Class Initialized
INFO - 2024-05-31 11:10:20 --> Output Class Initialized
INFO - 2024-05-31 11:10:20 --> Security Class Initialized
DEBUG - 2024-05-31 11:10:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-05-31 11:10:20 --> Input Class Initialized
INFO - 2024-05-31 11:10:20 --> Language Class Initialized
INFO - 2024-05-31 11:10:20 --> Language Class Initialized
INFO - 2024-05-31 11:10:20 --> Config Class Initialized
INFO - 2024-05-31 11:10:20 --> Loader Class Initialized
INFO - 2024-05-31 11:10:20 --> Helper loaded: url_helper
INFO - 2024-05-31 11:10:20 --> Helper loaded: file_helper
INFO - 2024-05-31 11:10:20 --> Helper loaded: form_helper
INFO - 2024-05-31 11:10:20 --> Helper loaded: my_helper
INFO - 2024-05-31 11:10:20 --> Database Driver Class Initialized
INFO - 2024-05-31 11:10:20 --> Session: Class initialized using 'files' driver.
INFO - 2024-05-31 11:10:20 --> Controller Class Initialized
INFO - 2024-05-31 11:10:20 --> Final output sent to browser
DEBUG - 2024-05-31 11:10:20 --> Total execution time: 0.0798
INFO - 2024-05-31 11:10:25 --> Config Class Initialized
INFO - 2024-05-31 11:10:25 --> Hooks Class Initialized
DEBUG - 2024-05-31 11:10:25 --> UTF-8 Support Enabled
INFO - 2024-05-31 11:10:25 --> Utf8 Class Initialized
INFO - 2024-05-31 11:10:25 --> URI Class Initialized
INFO - 2024-05-31 11:10:25 --> Router Class Initialized
INFO - 2024-05-31 11:10:25 --> Output Class Initialized
INFO - 2024-05-31 11:10:25 --> Security Class Initialized
DEBUG - 2024-05-31 11:10:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-05-31 11:10:25 --> Input Class Initialized
INFO - 2024-05-31 11:10:25 --> Language Class Initialized
INFO - 2024-05-31 11:10:25 --> Language Class Initialized
INFO - 2024-05-31 11:10:25 --> Config Class Initialized
INFO - 2024-05-31 11:10:25 --> Loader Class Initialized
INFO - 2024-05-31 11:10:25 --> Helper loaded: url_helper
INFO - 2024-05-31 11:10:25 --> Helper loaded: file_helper
INFO - 2024-05-31 11:10:25 --> Helper loaded: form_helper
INFO - 2024-05-31 11:10:25 --> Helper loaded: my_helper
INFO - 2024-05-31 11:10:25 --> Database Driver Class Initialized
INFO - 2024-05-31 11:10:25 --> Session: Class initialized using 'files' driver.
INFO - 2024-05-31 11:10:25 --> Controller Class Initialized
INFO - 2024-05-31 11:10:25 --> Final output sent to browser
DEBUG - 2024-05-31 11:10:25 --> Total execution time: 0.0280
INFO - 2024-05-31 11:12:51 --> Config Class Initialized
INFO - 2024-05-31 11:12:51 --> Hooks Class Initialized
DEBUG - 2024-05-31 11:12:51 --> UTF-8 Support Enabled
INFO - 2024-05-31 11:12:51 --> Utf8 Class Initialized
INFO - 2024-05-31 11:12:51 --> URI Class Initialized
INFO - 2024-05-31 11:12:51 --> Router Class Initialized
INFO - 2024-05-31 11:12:51 --> Output Class Initialized
INFO - 2024-05-31 11:12:51 --> Security Class Initialized
DEBUG - 2024-05-31 11:12:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-05-31 11:12:51 --> Input Class Initialized
INFO - 2024-05-31 11:12:51 --> Language Class Initialized
INFO - 2024-05-31 11:12:51 --> Language Class Initialized
INFO - 2024-05-31 11:12:51 --> Config Class Initialized
INFO - 2024-05-31 11:12:51 --> Loader Class Initialized
INFO - 2024-05-31 11:12:51 --> Helper loaded: url_helper
INFO - 2024-05-31 11:12:51 --> Helper loaded: file_helper
INFO - 2024-05-31 11:12:51 --> Helper loaded: form_helper
INFO - 2024-05-31 11:12:51 --> Helper loaded: my_helper
INFO - 2024-05-31 11:12:51 --> Database Driver Class Initialized
INFO - 2024-05-31 11:12:51 --> Session: Class initialized using 'files' driver.
INFO - 2024-05-31 11:12:51 --> Controller Class Initialized
INFO - 2024-05-31 11:12:51 --> Final output sent to browser
DEBUG - 2024-05-31 11:12:51 --> Total execution time: 0.0547
INFO - 2024-05-31 11:12:56 --> Config Class Initialized
INFO - 2024-05-31 11:12:56 --> Hooks Class Initialized
DEBUG - 2024-05-31 11:12:56 --> UTF-8 Support Enabled
INFO - 2024-05-31 11:12:56 --> Utf8 Class Initialized
INFO - 2024-05-31 11:12:56 --> URI Class Initialized
INFO - 2024-05-31 11:12:56 --> Router Class Initialized
INFO - 2024-05-31 11:12:56 --> Output Class Initialized
INFO - 2024-05-31 11:12:56 --> Security Class Initialized
DEBUG - 2024-05-31 11:12:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-05-31 11:12:56 --> Input Class Initialized
INFO - 2024-05-31 11:12:56 --> Language Class Initialized
INFO - 2024-05-31 11:12:56 --> Language Class Initialized
INFO - 2024-05-31 11:12:56 --> Config Class Initialized
INFO - 2024-05-31 11:12:56 --> Loader Class Initialized
INFO - 2024-05-31 11:12:56 --> Helper loaded: url_helper
INFO - 2024-05-31 11:12:56 --> Helper loaded: file_helper
INFO - 2024-05-31 11:12:56 --> Helper loaded: form_helper
INFO - 2024-05-31 11:12:56 --> Helper loaded: my_helper
INFO - 2024-05-31 11:12:56 --> Database Driver Class Initialized
INFO - 2024-05-31 11:12:56 --> Session: Class initialized using 'files' driver.
INFO - 2024-05-31 11:12:56 --> Controller Class Initialized
INFO - 2024-05-31 11:12:56 --> Final output sent to browser
DEBUG - 2024-05-31 11:12:56 --> Total execution time: 0.0378
INFO - 2024-05-31 11:12:58 --> Config Class Initialized
INFO - 2024-05-31 11:12:58 --> Hooks Class Initialized
DEBUG - 2024-05-31 11:12:58 --> UTF-8 Support Enabled
INFO - 2024-05-31 11:12:58 --> Utf8 Class Initialized
INFO - 2024-05-31 11:12:58 --> URI Class Initialized
INFO - 2024-05-31 11:12:58 --> Router Class Initialized
INFO - 2024-05-31 11:12:58 --> Output Class Initialized
INFO - 2024-05-31 11:12:58 --> Security Class Initialized
DEBUG - 2024-05-31 11:12:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-05-31 11:12:58 --> Input Class Initialized
INFO - 2024-05-31 11:12:58 --> Language Class Initialized
INFO - 2024-05-31 11:12:58 --> Language Class Initialized
INFO - 2024-05-31 11:12:58 --> Config Class Initialized
INFO - 2024-05-31 11:12:58 --> Loader Class Initialized
INFO - 2024-05-31 11:12:58 --> Helper loaded: url_helper
INFO - 2024-05-31 11:12:58 --> Helper loaded: file_helper
INFO - 2024-05-31 11:12:58 --> Helper loaded: form_helper
INFO - 2024-05-31 11:12:58 --> Helper loaded: my_helper
INFO - 2024-05-31 11:12:58 --> Database Driver Class Initialized
INFO - 2024-05-31 11:12:58 --> Session: Class initialized using 'files' driver.
INFO - 2024-05-31 11:12:58 --> Controller Class Initialized
INFO - 2024-05-31 11:12:58 --> Final output sent to browser
DEBUG - 2024-05-31 11:12:58 --> Total execution time: 0.0809
INFO - 2024-05-31 11:13:01 --> Config Class Initialized
INFO - 2024-05-31 11:13:01 --> Hooks Class Initialized
DEBUG - 2024-05-31 11:13:01 --> UTF-8 Support Enabled
INFO - 2024-05-31 11:13:01 --> Utf8 Class Initialized
INFO - 2024-05-31 11:13:01 --> URI Class Initialized
INFO - 2024-05-31 11:13:01 --> Router Class Initialized
INFO - 2024-05-31 11:13:01 --> Output Class Initialized
INFO - 2024-05-31 11:13:01 --> Security Class Initialized
DEBUG - 2024-05-31 11:13:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-05-31 11:13:01 --> Input Class Initialized
INFO - 2024-05-31 11:13:01 --> Language Class Initialized
INFO - 2024-05-31 11:13:01 --> Language Class Initialized
INFO - 2024-05-31 11:13:01 --> Config Class Initialized
INFO - 2024-05-31 11:13:01 --> Loader Class Initialized
INFO - 2024-05-31 11:13:01 --> Helper loaded: url_helper
INFO - 2024-05-31 11:13:01 --> Helper loaded: file_helper
INFO - 2024-05-31 11:13:01 --> Helper loaded: form_helper
INFO - 2024-05-31 11:13:01 --> Helper loaded: my_helper
INFO - 2024-05-31 11:13:01 --> Database Driver Class Initialized
INFO - 2024-05-31 11:13:01 --> Session: Class initialized using 'files' driver.
INFO - 2024-05-31 11:13:01 --> Controller Class Initialized
INFO - 2024-05-31 11:13:01 --> Final output sent to browser
DEBUG - 2024-05-31 11:13:01 --> Total execution time: 0.0614
INFO - 2024-05-31 11:13:12 --> Config Class Initialized
INFO - 2024-05-31 11:13:12 --> Hooks Class Initialized
DEBUG - 2024-05-31 11:13:12 --> UTF-8 Support Enabled
INFO - 2024-05-31 11:13:12 --> Utf8 Class Initialized
INFO - 2024-05-31 11:13:12 --> URI Class Initialized
INFO - 2024-05-31 11:13:12 --> Router Class Initialized
INFO - 2024-05-31 11:13:12 --> Output Class Initialized
INFO - 2024-05-31 11:13:12 --> Security Class Initialized
DEBUG - 2024-05-31 11:13:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-05-31 11:13:12 --> Input Class Initialized
INFO - 2024-05-31 11:13:12 --> Language Class Initialized
INFO - 2024-05-31 11:13:12 --> Language Class Initialized
INFO - 2024-05-31 11:13:12 --> Config Class Initialized
INFO - 2024-05-31 11:13:12 --> Loader Class Initialized
INFO - 2024-05-31 11:13:12 --> Helper loaded: url_helper
INFO - 2024-05-31 11:13:12 --> Helper loaded: file_helper
INFO - 2024-05-31 11:13:12 --> Helper loaded: form_helper
INFO - 2024-05-31 11:13:12 --> Helper loaded: my_helper
INFO - 2024-05-31 11:13:12 --> Database Driver Class Initialized
INFO - 2024-05-31 11:13:12 --> Session: Class initialized using 'files' driver.
INFO - 2024-05-31 11:13:12 --> Controller Class Initialized
INFO - 2024-05-31 11:13:12 --> Final output sent to browser
DEBUG - 2024-05-31 11:13:12 --> Total execution time: 0.0310
INFO - 2024-05-31 11:13:23 --> Config Class Initialized
INFO - 2024-05-31 11:13:23 --> Hooks Class Initialized
DEBUG - 2024-05-31 11:13:23 --> UTF-8 Support Enabled
INFO - 2024-05-31 11:13:23 --> Utf8 Class Initialized
INFO - 2024-05-31 11:13:23 --> URI Class Initialized
INFO - 2024-05-31 11:13:23 --> Router Class Initialized
INFO - 2024-05-31 11:13:23 --> Output Class Initialized
INFO - 2024-05-31 11:13:23 --> Security Class Initialized
DEBUG - 2024-05-31 11:13:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-05-31 11:13:23 --> Input Class Initialized
INFO - 2024-05-31 11:13:23 --> Language Class Initialized
INFO - 2024-05-31 11:13:23 --> Language Class Initialized
INFO - 2024-05-31 11:13:23 --> Config Class Initialized
INFO - 2024-05-31 11:13:23 --> Loader Class Initialized
INFO - 2024-05-31 11:13:23 --> Helper loaded: url_helper
INFO - 2024-05-31 11:13:23 --> Helper loaded: file_helper
INFO - 2024-05-31 11:13:23 --> Helper loaded: form_helper
INFO - 2024-05-31 11:13:23 --> Helper loaded: my_helper
INFO - 2024-05-31 11:13:23 --> Database Driver Class Initialized
INFO - 2024-05-31 11:13:23 --> Session: Class initialized using 'files' driver.
INFO - 2024-05-31 11:13:23 --> Controller Class Initialized
INFO - 2024-05-31 11:13:23 --> Final output sent to browser
DEBUG - 2024-05-31 11:13:23 --> Total execution time: 0.0310
INFO - 2024-05-31 11:14:38 --> Config Class Initialized
INFO - 2024-05-31 11:14:38 --> Hooks Class Initialized
DEBUG - 2024-05-31 11:14:38 --> UTF-8 Support Enabled
INFO - 2024-05-31 11:14:38 --> Utf8 Class Initialized
INFO - 2024-05-31 11:14:38 --> URI Class Initialized
INFO - 2024-05-31 11:14:38 --> Router Class Initialized
INFO - 2024-05-31 11:14:38 --> Output Class Initialized
INFO - 2024-05-31 11:14:38 --> Security Class Initialized
DEBUG - 2024-05-31 11:14:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-05-31 11:14:38 --> Input Class Initialized
INFO - 2024-05-31 11:14:38 --> Language Class Initialized
INFO - 2024-05-31 11:14:38 --> Language Class Initialized
INFO - 2024-05-31 11:14:38 --> Config Class Initialized
INFO - 2024-05-31 11:14:38 --> Loader Class Initialized
INFO - 2024-05-31 11:14:38 --> Helper loaded: url_helper
INFO - 2024-05-31 11:14:38 --> Helper loaded: file_helper
INFO - 2024-05-31 11:14:38 --> Helper loaded: form_helper
INFO - 2024-05-31 11:14:38 --> Helper loaded: my_helper
INFO - 2024-05-31 11:14:38 --> Database Driver Class Initialized
INFO - 2024-05-31 11:14:38 --> Session: Class initialized using 'files' driver.
INFO - 2024-05-31 11:14:38 --> Controller Class Initialized
DEBUG - 2024-05-31 11:14:38 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/view_mapel/views/v_view_mapel.php
DEBUG - 2024-05-31 11:14:38 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-05-31 11:14:38 --> Final output sent to browser
DEBUG - 2024-05-31 11:14:38 --> Total execution time: 0.0344
INFO - 2024-05-31 11:14:41 --> Config Class Initialized
INFO - 2024-05-31 11:14:41 --> Hooks Class Initialized
DEBUG - 2024-05-31 11:14:41 --> UTF-8 Support Enabled
INFO - 2024-05-31 11:14:41 --> Utf8 Class Initialized
INFO - 2024-05-31 11:14:41 --> URI Class Initialized
INFO - 2024-05-31 11:14:41 --> Router Class Initialized
INFO - 2024-05-31 11:14:41 --> Output Class Initialized
INFO - 2024-05-31 11:14:41 --> Security Class Initialized
DEBUG - 2024-05-31 11:14:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-05-31 11:14:41 --> Input Class Initialized
INFO - 2024-05-31 11:14:41 --> Language Class Initialized
INFO - 2024-05-31 11:14:41 --> Language Class Initialized
INFO - 2024-05-31 11:14:41 --> Config Class Initialized
INFO - 2024-05-31 11:14:41 --> Loader Class Initialized
INFO - 2024-05-31 11:14:41 --> Helper loaded: url_helper
INFO - 2024-05-31 11:14:41 --> Helper loaded: file_helper
INFO - 2024-05-31 11:14:41 --> Helper loaded: form_helper
INFO - 2024-05-31 11:14:41 --> Helper loaded: my_helper
INFO - 2024-05-31 11:14:41 --> Database Driver Class Initialized
INFO - 2024-05-31 11:14:41 --> Session: Class initialized using 'files' driver.
INFO - 2024-05-31 11:14:41 --> Controller Class Initialized
DEBUG - 2024-05-31 11:14:41 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_catatan_guru/views/list.php
DEBUG - 2024-05-31 11:14:41 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-05-31 11:14:41 --> Final output sent to browser
DEBUG - 2024-05-31 11:14:41 --> Total execution time: 0.0364
INFO - 2024-05-31 11:14:43 --> Config Class Initialized
INFO - 2024-05-31 11:14:43 --> Hooks Class Initialized
DEBUG - 2024-05-31 11:14:43 --> UTF-8 Support Enabled
INFO - 2024-05-31 11:14:43 --> Utf8 Class Initialized
INFO - 2024-05-31 11:14:43 --> URI Class Initialized
INFO - 2024-05-31 11:14:43 --> Router Class Initialized
INFO - 2024-05-31 11:14:43 --> Output Class Initialized
INFO - 2024-05-31 11:14:43 --> Security Class Initialized
DEBUG - 2024-05-31 11:14:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-05-31 11:14:43 --> Input Class Initialized
INFO - 2024-05-31 11:14:43 --> Language Class Initialized
INFO - 2024-05-31 11:14:43 --> Language Class Initialized
INFO - 2024-05-31 11:14:43 --> Config Class Initialized
INFO - 2024-05-31 11:14:43 --> Loader Class Initialized
INFO - 2024-05-31 11:14:43 --> Helper loaded: url_helper
INFO - 2024-05-31 11:14:43 --> Helper loaded: file_helper
INFO - 2024-05-31 11:14:43 --> Helper loaded: form_helper
INFO - 2024-05-31 11:14:43 --> Helper loaded: my_helper
INFO - 2024-05-31 11:14:43 --> Database Driver Class Initialized
INFO - 2024-05-31 11:14:43 --> Session: Class initialized using 'files' driver.
INFO - 2024-05-31 11:14:43 --> Controller Class Initialized
DEBUG - 2024-05-31 11:14:43 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/view_mapel/views/v_view_mapel.php
DEBUG - 2024-05-31 11:14:43 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-05-31 11:14:43 --> Final output sent to browser
DEBUG - 2024-05-31 11:14:43 --> Total execution time: 0.0307
INFO - 2024-05-31 11:14:48 --> Config Class Initialized
INFO - 2024-05-31 11:14:48 --> Hooks Class Initialized
DEBUG - 2024-05-31 11:14:48 --> UTF-8 Support Enabled
INFO - 2024-05-31 11:14:48 --> Utf8 Class Initialized
INFO - 2024-05-31 11:14:48 --> URI Class Initialized
INFO - 2024-05-31 11:14:48 --> Router Class Initialized
INFO - 2024-05-31 11:14:48 --> Output Class Initialized
INFO - 2024-05-31 11:14:48 --> Security Class Initialized
DEBUG - 2024-05-31 11:14:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-05-31 11:14:48 --> Input Class Initialized
INFO - 2024-05-31 11:14:48 --> Language Class Initialized
INFO - 2024-05-31 11:14:48 --> Language Class Initialized
INFO - 2024-05-31 11:14:48 --> Config Class Initialized
INFO - 2024-05-31 11:14:48 --> Loader Class Initialized
INFO - 2024-05-31 11:14:48 --> Helper loaded: url_helper
INFO - 2024-05-31 11:14:48 --> Helper loaded: file_helper
INFO - 2024-05-31 11:14:48 --> Helper loaded: form_helper
INFO - 2024-05-31 11:14:48 --> Helper loaded: my_helper
INFO - 2024-05-31 11:14:48 --> Database Driver Class Initialized
INFO - 2024-05-31 11:14:48 --> Session: Class initialized using 'files' driver.
INFO - 2024-05-31 11:14:48 --> Controller Class Initialized
DEBUG - 2024-05-31 11:14:48 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/views/list.php
DEBUG - 2024-05-31 11:14:48 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-05-31 11:14:48 --> Final output sent to browser
DEBUG - 2024-05-31 11:14:48 --> Total execution time: 0.0343
INFO - 2024-05-31 11:14:48 --> Config Class Initialized
INFO - 2024-05-31 11:14:48 --> Hooks Class Initialized
DEBUG - 2024-05-31 11:14:48 --> UTF-8 Support Enabled
INFO - 2024-05-31 11:14:48 --> Utf8 Class Initialized
INFO - 2024-05-31 11:14:48 --> URI Class Initialized
INFO - 2024-05-31 11:14:48 --> Router Class Initialized
INFO - 2024-05-31 11:14:48 --> Output Class Initialized
INFO - 2024-05-31 11:14:48 --> Security Class Initialized
DEBUG - 2024-05-31 11:14:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-05-31 11:14:48 --> Input Class Initialized
INFO - 2024-05-31 11:14:48 --> Language Class Initialized
INFO - 2024-05-31 11:14:48 --> Language Class Initialized
INFO - 2024-05-31 11:14:48 --> Config Class Initialized
INFO - 2024-05-31 11:14:48 --> Loader Class Initialized
INFO - 2024-05-31 11:14:48 --> Helper loaded: url_helper
INFO - 2024-05-31 11:14:48 --> Helper loaded: file_helper
INFO - 2024-05-31 11:14:48 --> Helper loaded: form_helper
INFO - 2024-05-31 11:14:48 --> Helper loaded: my_helper
INFO - 2024-05-31 11:14:48 --> Database Driver Class Initialized
INFO - 2024-05-31 11:14:48 --> Session: Class initialized using 'files' driver.
INFO - 2024-05-31 11:14:48 --> Controller Class Initialized
INFO - 2024-05-31 11:19:55 --> Config Class Initialized
INFO - 2024-05-31 11:19:55 --> Hooks Class Initialized
DEBUG - 2024-05-31 11:19:55 --> UTF-8 Support Enabled
INFO - 2024-05-31 11:19:55 --> Utf8 Class Initialized
INFO - 2024-05-31 11:19:55 --> URI Class Initialized
INFO - 2024-05-31 11:19:55 --> Router Class Initialized
INFO - 2024-05-31 11:19:55 --> Output Class Initialized
INFO - 2024-05-31 11:19:55 --> Security Class Initialized
DEBUG - 2024-05-31 11:19:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-05-31 11:19:55 --> Input Class Initialized
INFO - 2024-05-31 11:19:55 --> Language Class Initialized
INFO - 2024-05-31 11:19:55 --> Language Class Initialized
INFO - 2024-05-31 11:19:55 --> Config Class Initialized
INFO - 2024-05-31 11:19:55 --> Loader Class Initialized
INFO - 2024-05-31 11:19:55 --> Helper loaded: url_helper
INFO - 2024-05-31 11:19:55 --> Helper loaded: file_helper
INFO - 2024-05-31 11:19:55 --> Helper loaded: form_helper
INFO - 2024-05-31 11:19:55 --> Helper loaded: my_helper
INFO - 2024-05-31 11:19:55 --> Database Driver Class Initialized
INFO - 2024-05-31 11:19:55 --> Session: Class initialized using 'files' driver.
INFO - 2024-05-31 11:19:55 --> Controller Class Initialized
DEBUG - 2024-05-31 11:19:55 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/view_mapel/views/v_view_mapel.php
DEBUG - 2024-05-31 11:19:55 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-05-31 11:19:55 --> Final output sent to browser
DEBUG - 2024-05-31 11:19:55 --> Total execution time: 0.0371
INFO - 2024-05-31 11:19:58 --> Config Class Initialized
INFO - 2024-05-31 11:19:58 --> Hooks Class Initialized
DEBUG - 2024-05-31 11:19:58 --> UTF-8 Support Enabled
INFO - 2024-05-31 11:19:58 --> Utf8 Class Initialized
INFO - 2024-05-31 11:19:58 --> URI Class Initialized
INFO - 2024-05-31 11:19:58 --> Router Class Initialized
INFO - 2024-05-31 11:19:58 --> Output Class Initialized
INFO - 2024-05-31 11:19:58 --> Security Class Initialized
DEBUG - 2024-05-31 11:19:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-05-31 11:19:58 --> Input Class Initialized
INFO - 2024-05-31 11:19:58 --> Language Class Initialized
INFO - 2024-05-31 11:19:58 --> Language Class Initialized
INFO - 2024-05-31 11:19:58 --> Config Class Initialized
INFO - 2024-05-31 11:19:58 --> Loader Class Initialized
INFO - 2024-05-31 11:19:58 --> Helper loaded: url_helper
INFO - 2024-05-31 11:19:58 --> Helper loaded: file_helper
INFO - 2024-05-31 11:19:58 --> Helper loaded: form_helper
INFO - 2024-05-31 11:19:58 --> Helper loaded: my_helper
INFO - 2024-05-31 11:19:58 --> Database Driver Class Initialized
INFO - 2024-05-31 11:19:58 --> Session: Class initialized using 'files' driver.
INFO - 2024-05-31 11:19:58 --> Controller Class Initialized
DEBUG - 2024-05-31 11:19:58 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pss/views/list.php
DEBUG - 2024-05-31 11:19:58 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-05-31 11:19:58 --> Final output sent to browser
DEBUG - 2024-05-31 11:19:58 --> Total execution time: 0.0296
INFO - 2024-05-31 11:19:58 --> Config Class Initialized
INFO - 2024-05-31 11:19:58 --> Hooks Class Initialized
DEBUG - 2024-05-31 11:19:58 --> UTF-8 Support Enabled
INFO - 2024-05-31 11:19:58 --> Utf8 Class Initialized
INFO - 2024-05-31 11:19:58 --> URI Class Initialized
INFO - 2024-05-31 11:19:58 --> Router Class Initialized
INFO - 2024-05-31 11:19:58 --> Output Class Initialized
INFO - 2024-05-31 11:19:58 --> Security Class Initialized
DEBUG - 2024-05-31 11:19:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-05-31 11:19:58 --> Input Class Initialized
INFO - 2024-05-31 11:19:58 --> Language Class Initialized
INFO - 2024-05-31 11:19:58 --> Language Class Initialized
INFO - 2024-05-31 11:19:58 --> Config Class Initialized
INFO - 2024-05-31 11:19:58 --> Loader Class Initialized
INFO - 2024-05-31 11:19:58 --> Helper loaded: url_helper
INFO - 2024-05-31 11:19:58 --> Helper loaded: file_helper
INFO - 2024-05-31 11:19:58 --> Helper loaded: form_helper
INFO - 2024-05-31 11:19:58 --> Helper loaded: my_helper
INFO - 2024-05-31 11:19:58 --> Database Driver Class Initialized
INFO - 2024-05-31 11:19:58 --> Session: Class initialized using 'files' driver.
INFO - 2024-05-31 11:19:58 --> Controller Class Initialized
INFO - 2024-05-31 11:20:04 --> Config Class Initialized
INFO - 2024-05-31 11:20:04 --> Hooks Class Initialized
DEBUG - 2024-05-31 11:20:04 --> UTF-8 Support Enabled
INFO - 2024-05-31 11:20:04 --> Utf8 Class Initialized
INFO - 2024-05-31 11:20:04 --> URI Class Initialized
INFO - 2024-05-31 11:20:04 --> Router Class Initialized
INFO - 2024-05-31 11:20:04 --> Output Class Initialized
INFO - 2024-05-31 11:20:04 --> Security Class Initialized
DEBUG - 2024-05-31 11:20:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-05-31 11:20:04 --> Input Class Initialized
INFO - 2024-05-31 11:20:04 --> Language Class Initialized
INFO - 2024-05-31 11:20:04 --> Language Class Initialized
INFO - 2024-05-31 11:20:04 --> Config Class Initialized
INFO - 2024-05-31 11:20:04 --> Loader Class Initialized
INFO - 2024-05-31 11:20:04 --> Helper loaded: url_helper
INFO - 2024-05-31 11:20:04 --> Helper loaded: file_helper
INFO - 2024-05-31 11:20:04 --> Helper loaded: form_helper
INFO - 2024-05-31 11:20:04 --> Helper loaded: my_helper
INFO - 2024-05-31 11:20:04 --> Database Driver Class Initialized
INFO - 2024-05-31 11:20:04 --> Session: Class initialized using 'files' driver.
INFO - 2024-05-31 11:20:04 --> Controller Class Initialized
DEBUG - 2024-05-31 11:20:04 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/view_mapel/views/v_view_mapel.php
DEBUG - 2024-05-31 11:20:04 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-05-31 11:20:04 --> Final output sent to browser
DEBUG - 2024-05-31 11:20:04 --> Total execution time: 0.0310
INFO - 2024-05-31 11:20:14 --> Config Class Initialized
INFO - 2024-05-31 11:20:14 --> Hooks Class Initialized
DEBUG - 2024-05-31 11:20:14 --> UTF-8 Support Enabled
INFO - 2024-05-31 11:20:14 --> Utf8 Class Initialized
INFO - 2024-05-31 11:20:14 --> URI Class Initialized
INFO - 2024-05-31 11:20:14 --> Router Class Initialized
INFO - 2024-05-31 11:20:14 --> Output Class Initialized
INFO - 2024-05-31 11:20:14 --> Security Class Initialized
DEBUG - 2024-05-31 11:20:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-05-31 11:20:14 --> Input Class Initialized
INFO - 2024-05-31 11:20:14 --> Language Class Initialized
INFO - 2024-05-31 11:20:14 --> Language Class Initialized
INFO - 2024-05-31 11:20:14 --> Config Class Initialized
INFO - 2024-05-31 11:20:14 --> Loader Class Initialized
INFO - 2024-05-31 11:20:14 --> Helper loaded: url_helper
INFO - 2024-05-31 11:20:14 --> Helper loaded: file_helper
INFO - 2024-05-31 11:20:14 --> Helper loaded: form_helper
INFO - 2024-05-31 11:20:14 --> Helper loaded: my_helper
INFO - 2024-05-31 11:20:14 --> Database Driver Class Initialized
INFO - 2024-05-31 11:20:14 --> Session: Class initialized using 'files' driver.
INFO - 2024-05-31 11:20:14 --> Controller Class Initialized
DEBUG - 2024-05-31 11:20:14 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/view_mapel/views/v_view_mapel.php
DEBUG - 2024-05-31 11:20:14 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-05-31 11:20:14 --> Final output sent to browser
DEBUG - 2024-05-31 11:20:14 --> Total execution time: 0.0256
INFO - 2024-05-31 11:20:17 --> Config Class Initialized
INFO - 2024-05-31 11:20:17 --> Hooks Class Initialized
DEBUG - 2024-05-31 11:20:17 --> UTF-8 Support Enabled
INFO - 2024-05-31 11:20:17 --> Utf8 Class Initialized
INFO - 2024-05-31 11:20:17 --> URI Class Initialized
INFO - 2024-05-31 11:20:17 --> Router Class Initialized
INFO - 2024-05-31 11:20:17 --> Output Class Initialized
INFO - 2024-05-31 11:20:17 --> Security Class Initialized
DEBUG - 2024-05-31 11:20:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-05-31 11:20:17 --> Input Class Initialized
INFO - 2024-05-31 11:20:17 --> Language Class Initialized
INFO - 2024-05-31 11:20:17 --> Language Class Initialized
INFO - 2024-05-31 11:20:17 --> Config Class Initialized
INFO - 2024-05-31 11:20:17 --> Loader Class Initialized
INFO - 2024-05-31 11:20:17 --> Helper loaded: url_helper
INFO - 2024-05-31 11:20:17 --> Helper loaded: file_helper
INFO - 2024-05-31 11:20:17 --> Helper loaded: form_helper
INFO - 2024-05-31 11:20:17 --> Helper loaded: my_helper
INFO - 2024-05-31 11:20:17 --> Database Driver Class Initialized
INFO - 2024-05-31 11:20:17 --> Session: Class initialized using 'files' driver.
INFO - 2024-05-31 11:20:17 --> Controller Class Initialized
DEBUG - 2024-05-31 11:20:17 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/views/list.php
DEBUG - 2024-05-31 11:20:17 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-05-31 11:20:17 --> Final output sent to browser
DEBUG - 2024-05-31 11:20:17 --> Total execution time: 0.0297
INFO - 2024-05-31 11:20:17 --> Config Class Initialized
INFO - 2024-05-31 11:20:17 --> Hooks Class Initialized
DEBUG - 2024-05-31 11:20:17 --> UTF-8 Support Enabled
INFO - 2024-05-31 11:20:17 --> Utf8 Class Initialized
INFO - 2024-05-31 11:20:17 --> URI Class Initialized
INFO - 2024-05-31 11:20:17 --> Router Class Initialized
INFO - 2024-05-31 11:20:17 --> Output Class Initialized
INFO - 2024-05-31 11:20:17 --> Security Class Initialized
DEBUG - 2024-05-31 11:20:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-05-31 11:20:17 --> Input Class Initialized
INFO - 2024-05-31 11:20:17 --> Language Class Initialized
INFO - 2024-05-31 11:20:17 --> Language Class Initialized
INFO - 2024-05-31 11:20:17 --> Config Class Initialized
INFO - 2024-05-31 11:20:17 --> Loader Class Initialized
INFO - 2024-05-31 11:20:17 --> Helper loaded: url_helper
INFO - 2024-05-31 11:20:17 --> Helper loaded: file_helper
INFO - 2024-05-31 11:20:17 --> Helper loaded: form_helper
INFO - 2024-05-31 11:20:17 --> Helper loaded: my_helper
INFO - 2024-05-31 11:20:17 --> Database Driver Class Initialized
INFO - 2024-05-31 11:20:17 --> Session: Class initialized using 'files' driver.
INFO - 2024-05-31 11:20:17 --> Controller Class Initialized
INFO - 2024-05-31 14:16:48 --> Config Class Initialized
INFO - 2024-05-31 14:16:48 --> Hooks Class Initialized
DEBUG - 2024-05-31 14:16:48 --> UTF-8 Support Enabled
INFO - 2024-05-31 14:16:48 --> Utf8 Class Initialized
INFO - 2024-05-31 14:16:48 --> URI Class Initialized
INFO - 2024-05-31 14:16:48 --> Router Class Initialized
INFO - 2024-05-31 14:16:48 --> Output Class Initialized
INFO - 2024-05-31 14:16:48 --> Security Class Initialized
DEBUG - 2024-05-31 14:16:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-05-31 14:16:48 --> Input Class Initialized
INFO - 2024-05-31 14:16:48 --> Language Class Initialized
INFO - 2024-05-31 14:16:48 --> Language Class Initialized
INFO - 2024-05-31 14:16:48 --> Config Class Initialized
INFO - 2024-05-31 14:16:48 --> Loader Class Initialized
INFO - 2024-05-31 14:16:48 --> Helper loaded: url_helper
INFO - 2024-05-31 14:16:48 --> Helper loaded: file_helper
INFO - 2024-05-31 14:16:48 --> Helper loaded: form_helper
INFO - 2024-05-31 14:16:48 --> Helper loaded: my_helper
INFO - 2024-05-31 14:16:48 --> Database Driver Class Initialized
INFO - 2024-05-31 14:16:48 --> Session: Class initialized using 'files' driver.
INFO - 2024-05-31 14:16:48 --> Controller Class Initialized
INFO - 2024-05-31 14:16:48 --> Final output sent to browser
DEBUG - 2024-05-31 14:16:48 --> Total execution time: 0.0768
