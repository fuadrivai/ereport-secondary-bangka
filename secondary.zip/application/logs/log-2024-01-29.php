<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2024-01-29 10:06:41 --> Config Class Initialized
INFO - 2024-01-29 10:06:41 --> Hooks Class Initialized
DEBUG - 2024-01-29 10:06:41 --> UTF-8 Support Enabled
INFO - 2024-01-29 10:06:41 --> Utf8 Class Initialized
INFO - 2024-01-29 10:06:41 --> URI Class Initialized
INFO - 2024-01-29 10:06:41 --> Router Class Initialized
INFO - 2024-01-29 10:06:41 --> Output Class Initialized
INFO - 2024-01-29 10:06:41 --> Security Class Initialized
DEBUG - 2024-01-29 10:06:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-01-29 10:06:41 --> Input Class Initialized
INFO - 2024-01-29 10:06:41 --> Language Class Initialized
INFO - 2024-01-29 10:06:41 --> Language Class Initialized
INFO - 2024-01-29 10:06:41 --> Config Class Initialized
INFO - 2024-01-29 10:06:41 --> Loader Class Initialized
INFO - 2024-01-29 10:06:41 --> Helper loaded: url_helper
INFO - 2024-01-29 10:06:41 --> Helper loaded: file_helper
INFO - 2024-01-29 10:06:41 --> Helper loaded: form_helper
INFO - 2024-01-29 10:06:41 --> Helper loaded: my_helper
INFO - 2024-01-29 10:06:41 --> Database Driver Class Initialized
INFO - 2024-01-29 10:06:41 --> Session: Class initialized using 'files' driver.
INFO - 2024-01-29 10:06:41 --> Controller Class Initialized
INFO - 2024-01-29 10:06:41 --> Helper loaded: cookie_helper
INFO - 2024-01-29 10:06:41 --> Final output sent to browser
DEBUG - 2024-01-29 10:06:41 --> Total execution time: 0.1506
INFO - 2024-01-29 10:06:42 --> Config Class Initialized
INFO - 2024-01-29 10:06:42 --> Hooks Class Initialized
DEBUG - 2024-01-29 10:06:42 --> UTF-8 Support Enabled
INFO - 2024-01-29 10:06:42 --> Utf8 Class Initialized
INFO - 2024-01-29 10:06:42 --> URI Class Initialized
INFO - 2024-01-29 10:06:42 --> Router Class Initialized
INFO - 2024-01-29 10:06:42 --> Output Class Initialized
INFO - 2024-01-29 10:06:42 --> Security Class Initialized
DEBUG - 2024-01-29 10:06:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-01-29 10:06:42 --> Input Class Initialized
INFO - 2024-01-29 10:06:42 --> Language Class Initialized
INFO - 2024-01-29 10:06:42 --> Language Class Initialized
INFO - 2024-01-29 10:06:42 --> Config Class Initialized
INFO - 2024-01-29 10:06:42 --> Loader Class Initialized
INFO - 2024-01-29 10:06:42 --> Helper loaded: url_helper
INFO - 2024-01-29 10:06:42 --> Helper loaded: file_helper
INFO - 2024-01-29 10:06:42 --> Helper loaded: form_helper
INFO - 2024-01-29 10:06:42 --> Helper loaded: my_helper
INFO - 2024-01-29 10:06:42 --> Database Driver Class Initialized
INFO - 2024-01-29 10:06:42 --> Session: Class initialized using 'files' driver.
INFO - 2024-01-29 10:06:42 --> Controller Class Initialized
INFO - 2024-01-29 10:06:42 --> Helper loaded: cookie_helper
INFO - 2024-01-29 10:06:42 --> Final output sent to browser
DEBUG - 2024-01-29 10:06:42 --> Total execution time: 0.1481
INFO - 2024-01-29 10:06:42 --> Config Class Initialized
INFO - 2024-01-29 10:06:42 --> Hooks Class Initialized
DEBUG - 2024-01-29 10:06:42 --> UTF-8 Support Enabled
INFO - 2024-01-29 10:06:42 --> Utf8 Class Initialized
INFO - 2024-01-29 10:06:42 --> URI Class Initialized
INFO - 2024-01-29 10:06:42 --> Router Class Initialized
INFO - 2024-01-29 10:06:42 --> Output Class Initialized
INFO - 2024-01-29 10:06:42 --> Security Class Initialized
DEBUG - 2024-01-29 10:06:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-01-29 10:06:42 --> Input Class Initialized
INFO - 2024-01-29 10:06:42 --> Language Class Initialized
INFO - 2024-01-29 10:06:42 --> Language Class Initialized
INFO - 2024-01-29 10:06:42 --> Config Class Initialized
INFO - 2024-01-29 10:06:42 --> Loader Class Initialized
INFO - 2024-01-29 10:06:42 --> Helper loaded: url_helper
INFO - 2024-01-29 10:06:42 --> Helper loaded: file_helper
INFO - 2024-01-29 10:06:42 --> Helper loaded: form_helper
INFO - 2024-01-29 10:06:42 --> Helper loaded: my_helper
INFO - 2024-01-29 10:06:42 --> Database Driver Class Initialized
INFO - 2024-01-29 10:06:42 --> Session: Class initialized using 'files' driver.
INFO - 2024-01-29 10:06:42 --> Controller Class Initialized
INFO - 2024-01-29 10:06:42 --> Helper loaded: cookie_helper
INFO - 2024-01-29 10:06:43 --> Config Class Initialized
INFO - 2024-01-29 10:06:43 --> Hooks Class Initialized
DEBUG - 2024-01-29 10:06:43 --> UTF-8 Support Enabled
INFO - 2024-01-29 10:06:43 --> Utf8 Class Initialized
INFO - 2024-01-29 10:06:43 --> URI Class Initialized
INFO - 2024-01-29 10:06:43 --> Router Class Initialized
INFO - 2024-01-29 10:06:43 --> Output Class Initialized
INFO - 2024-01-29 10:06:43 --> Config Class Initialized
INFO - 2024-01-29 10:06:43 --> Hooks Class Initialized
INFO - 2024-01-29 10:06:43 --> Security Class Initialized
DEBUG - 2024-01-29 10:06:43 --> UTF-8 Support Enabled
INFO - 2024-01-29 10:06:43 --> Utf8 Class Initialized
INFO - 2024-01-29 10:06:43 --> URI Class Initialized
DEBUG - 2024-01-29 10:06:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-01-29 10:06:43 --> Input Class Initialized
INFO - 2024-01-29 10:06:43 --> Language Class Initialized
INFO - 2024-01-29 10:06:43 --> Router Class Initialized
INFO - 2024-01-29 10:06:43 --> Output Class Initialized
INFO - 2024-01-29 10:06:43 --> Language Class Initialized
INFO - 2024-01-29 10:06:43 --> Config Class Initialized
INFO - 2024-01-29 10:06:43 --> Loader Class Initialized
INFO - 2024-01-29 10:06:43 --> Helper loaded: url_helper
INFO - 2024-01-29 10:06:43 --> Helper loaded: file_helper
INFO - 2024-01-29 10:06:43 --> Security Class Initialized
INFO - 2024-01-29 10:06:43 --> Helper loaded: form_helper
DEBUG - 2024-01-29 10:06:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-01-29 10:06:43 --> Input Class Initialized
INFO - 2024-01-29 10:06:43 --> Language Class Initialized
INFO - 2024-01-29 10:06:43 --> Helper loaded: my_helper
INFO - 2024-01-29 10:06:43 --> Language Class Initialized
INFO - 2024-01-29 10:06:43 --> Config Class Initialized
INFO - 2024-01-29 10:06:43 --> Loader Class Initialized
INFO - 2024-01-29 10:06:43 --> Database Driver Class Initialized
INFO - 2024-01-29 10:06:43 --> Helper loaded: url_helper
INFO - 2024-01-29 10:06:43 --> Helper loaded: file_helper
INFO - 2024-01-29 10:06:43 --> Session: Class initialized using 'files' driver.
INFO - 2024-01-29 10:06:43 --> Controller Class Initialized
INFO - 2024-01-29 10:06:43 --> Helper loaded: form_helper
INFO - 2024-01-29 10:06:43 --> Helper loaded: cookie_helper
INFO - 2024-01-29 10:06:43 --> Helper loaded: my_helper
INFO - 2024-01-29 10:06:43 --> Database Driver Class Initialized
INFO - 2024-01-29 10:06:43 --> Session: Class initialized using 'files' driver.
INFO - 2024-01-29 10:06:43 --> Controller Class Initialized
DEBUG - 2024-01-29 10:06:43 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/lihat_raport/views/list.php
DEBUG - 2024-01-29 10:06:43 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-01-29 10:06:43 --> Final output sent to browser
DEBUG - 2024-01-29 10:06:43 --> Total execution time: 0.1394
INFO - 2024-01-29 10:06:43 --> Config Class Initialized
INFO - 2024-01-29 10:06:43 --> Hooks Class Initialized
DEBUG - 2024-01-29 10:06:43 --> UTF-8 Support Enabled
INFO - 2024-01-29 10:06:43 --> Utf8 Class Initialized
INFO - 2024-01-29 10:06:43 --> URI Class Initialized
INFO - 2024-01-29 10:06:43 --> Router Class Initialized
INFO - 2024-01-29 10:06:43 --> Output Class Initialized
INFO - 2024-01-29 10:06:43 --> Security Class Initialized
DEBUG - 2024-01-29 10:06:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-01-29 10:06:43 --> Input Class Initialized
INFO - 2024-01-29 10:06:43 --> Language Class Initialized
INFO - 2024-01-29 10:06:43 --> Language Class Initialized
INFO - 2024-01-29 10:06:43 --> Config Class Initialized
INFO - 2024-01-29 10:06:43 --> Loader Class Initialized
INFO - 2024-01-29 10:06:43 --> Helper loaded: url_helper
INFO - 2024-01-29 10:06:43 --> Helper loaded: file_helper
INFO - 2024-01-29 10:06:43 --> Helper loaded: form_helper
INFO - 2024-01-29 10:06:43 --> Helper loaded: my_helper
INFO - 2024-01-29 10:06:43 --> Database Driver Class Initialized
INFO - 2024-01-29 10:06:43 --> Session: Class initialized using 'files' driver.
INFO - 2024-01-29 10:06:43 --> Controller Class Initialized
DEBUG - 2024-01-29 10:06:43 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/lihat_raport/views/list.php
DEBUG - 2024-01-29 10:06:43 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-01-29 10:06:43 --> Final output sent to browser
DEBUG - 2024-01-29 10:06:43 --> Total execution time: 0.0812
INFO - 2024-01-29 10:06:56 --> Config Class Initialized
INFO - 2024-01-29 10:06:56 --> Hooks Class Initialized
DEBUG - 2024-01-29 10:06:56 --> UTF-8 Support Enabled
INFO - 2024-01-29 10:06:56 --> Utf8 Class Initialized
INFO - 2024-01-29 10:06:56 --> URI Class Initialized
INFO - 2024-01-29 10:06:56 --> Router Class Initialized
INFO - 2024-01-29 10:06:56 --> Output Class Initialized
INFO - 2024-01-29 10:06:56 --> Security Class Initialized
DEBUG - 2024-01-29 10:06:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-01-29 10:06:56 --> Input Class Initialized
INFO - 2024-01-29 10:06:56 --> Language Class Initialized
INFO - 2024-01-29 10:06:56 --> Language Class Initialized
INFO - 2024-01-29 10:06:56 --> Config Class Initialized
INFO - 2024-01-29 10:06:56 --> Loader Class Initialized
INFO - 2024-01-29 10:06:56 --> Helper loaded: url_helper
INFO - 2024-01-29 10:06:56 --> Helper loaded: file_helper
INFO - 2024-01-29 10:06:56 --> Helper loaded: form_helper
INFO - 2024-01-29 10:06:56 --> Helper loaded: my_helper
INFO - 2024-01-29 10:06:56 --> Database Driver Class Initialized
INFO - 2024-01-29 10:06:56 --> Session: Class initialized using 'files' driver.
INFO - 2024-01-29 10:06:56 --> Controller Class Initialized
INFO - 2024-01-29 10:06:56 --> Helper loaded: cookie_helper
INFO - 2024-01-29 10:06:56 --> Final output sent to browser
DEBUG - 2024-01-29 10:06:56 --> Total execution time: 0.0694
INFO - 2024-01-29 10:06:57 --> Config Class Initialized
INFO - 2024-01-29 10:06:57 --> Hooks Class Initialized
DEBUG - 2024-01-29 10:06:57 --> UTF-8 Support Enabled
INFO - 2024-01-29 10:06:57 --> Utf8 Class Initialized
INFO - 2024-01-29 10:06:57 --> URI Class Initialized
INFO - 2024-01-29 10:06:57 --> Router Class Initialized
INFO - 2024-01-29 10:06:57 --> Output Class Initialized
INFO - 2024-01-29 10:06:57 --> Security Class Initialized
DEBUG - 2024-01-29 10:06:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-01-29 10:06:57 --> Input Class Initialized
INFO - 2024-01-29 10:06:57 --> Language Class Initialized
INFO - 2024-01-29 10:06:57 --> Language Class Initialized
INFO - 2024-01-29 10:06:57 --> Config Class Initialized
INFO - 2024-01-29 10:06:57 --> Loader Class Initialized
INFO - 2024-01-29 10:06:57 --> Helper loaded: url_helper
INFO - 2024-01-29 10:06:57 --> Helper loaded: file_helper
INFO - 2024-01-29 10:06:57 --> Helper loaded: form_helper
INFO - 2024-01-29 10:06:57 --> Helper loaded: my_helper
INFO - 2024-01-29 10:06:57 --> Database Driver Class Initialized
INFO - 2024-01-29 10:06:57 --> Config Class Initialized
INFO - 2024-01-29 10:06:57 --> Hooks Class Initialized
DEBUG - 2024-01-29 10:06:57 --> UTF-8 Support Enabled
INFO - 2024-01-29 10:06:57 --> Utf8 Class Initialized
INFO - 2024-01-29 10:06:57 --> URI Class Initialized
INFO - 2024-01-29 10:06:57 --> Router Class Initialized
INFO - 2024-01-29 10:06:57 --> Output Class Initialized
INFO - 2024-01-29 10:06:57 --> Security Class Initialized
DEBUG - 2024-01-29 10:06:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-01-29 10:06:57 --> Input Class Initialized
INFO - 2024-01-29 10:06:57 --> Language Class Initialized
INFO - 2024-01-29 10:06:57 --> Language Class Initialized
INFO - 2024-01-29 10:06:57 --> Config Class Initialized
INFO - 2024-01-29 10:06:57 --> Loader Class Initialized
INFO - 2024-01-29 10:06:57 --> Helper loaded: url_helper
INFO - 2024-01-29 10:06:57 --> Helper loaded: file_helper
INFO - 2024-01-29 10:06:57 --> Helper loaded: form_helper
INFO - 2024-01-29 10:06:57 --> Helper loaded: my_helper
INFO - 2024-01-29 10:06:57 --> Database Driver Class Initialized
INFO - 2024-01-29 10:06:57 --> Session: Class initialized using 'files' driver.
INFO - 2024-01-29 10:06:57 --> Controller Class Initialized
INFO - 2024-01-29 10:06:57 --> Helper loaded: cookie_helper
INFO - 2024-01-29 10:06:57 --> Session: Class initialized using 'files' driver.
INFO - 2024-01-29 10:06:57 --> Controller Class Initialized
INFO - 2024-01-29 10:06:57 --> Helper loaded: cookie_helper
INFO - 2024-01-29 10:06:57 --> Config Class Initialized
INFO - 2024-01-29 10:06:57 --> Hooks Class Initialized
DEBUG - 2024-01-29 10:06:57 --> UTF-8 Support Enabled
INFO - 2024-01-29 10:06:57 --> Utf8 Class Initialized
INFO - 2024-01-29 10:06:57 --> URI Class Initialized
INFO - 2024-01-29 10:06:57 --> Router Class Initialized
INFO - 2024-01-29 10:06:57 --> Output Class Initialized
INFO - 2024-01-29 10:06:57 --> Security Class Initialized
DEBUG - 2024-01-29 10:06:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-01-29 10:06:57 --> Input Class Initialized
INFO - 2024-01-29 10:06:57 --> Language Class Initialized
INFO - 2024-01-29 10:06:57 --> Language Class Initialized
INFO - 2024-01-29 10:06:57 --> Config Class Initialized
INFO - 2024-01-29 10:06:57 --> Loader Class Initialized
INFO - 2024-01-29 10:06:57 --> Helper loaded: url_helper
INFO - 2024-01-29 10:06:57 --> Helper loaded: file_helper
INFO - 2024-01-29 10:06:57 --> Helper loaded: form_helper
INFO - 2024-01-29 10:06:57 --> Helper loaded: my_helper
INFO - 2024-01-29 10:06:57 --> Database Driver Class Initialized
INFO - 2024-01-29 10:06:57 --> Session: Class initialized using 'files' driver.
INFO - 2024-01-29 10:06:57 --> Controller Class Initialized
DEBUG - 2024-01-29 10:06:57 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/lihat_raport/views/list.php
DEBUG - 2024-01-29 10:06:57 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-01-29 10:06:57 --> Final output sent to browser
DEBUG - 2024-01-29 10:06:57 --> Total execution time: 0.0900
INFO - 2024-01-29 16:49:13 --> Config Class Initialized
INFO - 2024-01-29 16:49:13 --> Hooks Class Initialized
DEBUG - 2024-01-29 16:49:13 --> UTF-8 Support Enabled
INFO - 2024-01-29 16:49:13 --> Utf8 Class Initialized
INFO - 2024-01-29 16:49:13 --> URI Class Initialized
INFO - 2024-01-29 16:49:13 --> Router Class Initialized
INFO - 2024-01-29 16:49:13 --> Output Class Initialized
INFO - 2024-01-29 16:49:13 --> Security Class Initialized
DEBUG - 2024-01-29 16:49:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-01-29 16:49:13 --> Input Class Initialized
INFO - 2024-01-29 16:49:13 --> Language Class Initialized
INFO - 2024-01-29 16:49:13 --> Language Class Initialized
INFO - 2024-01-29 16:49:13 --> Config Class Initialized
INFO - 2024-01-29 16:49:13 --> Loader Class Initialized
INFO - 2024-01-29 16:49:13 --> Helper loaded: url_helper
INFO - 2024-01-29 16:49:13 --> Helper loaded: file_helper
INFO - 2024-01-29 16:49:13 --> Helper loaded: form_helper
INFO - 2024-01-29 16:49:13 --> Helper loaded: my_helper
INFO - 2024-01-29 16:49:13 --> Database Driver Class Initialized
INFO - 2024-01-29 16:49:13 --> Session: Class initialized using 'files' driver.
INFO - 2024-01-29 16:49:13 --> Controller Class Initialized
INFO - 2024-01-29 16:49:13 --> Config Class Initialized
INFO - 2024-01-29 16:49:13 --> Hooks Class Initialized
DEBUG - 2024-01-29 16:49:13 --> UTF-8 Support Enabled
INFO - 2024-01-29 16:49:13 --> Utf8 Class Initialized
INFO - 2024-01-29 16:49:13 --> URI Class Initialized
INFO - 2024-01-29 16:49:13 --> Router Class Initialized
INFO - 2024-01-29 16:49:13 --> Output Class Initialized
INFO - 2024-01-29 16:49:13 --> Security Class Initialized
DEBUG - 2024-01-29 16:49:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-01-29 16:49:13 --> Input Class Initialized
INFO - 2024-01-29 16:49:13 --> Language Class Initialized
INFO - 2024-01-29 16:49:13 --> Language Class Initialized
INFO - 2024-01-29 16:49:13 --> Config Class Initialized
INFO - 2024-01-29 16:49:13 --> Loader Class Initialized
INFO - 2024-01-29 16:49:13 --> Config Class Initialized
INFO - 2024-01-29 16:49:13 --> Hooks Class Initialized
DEBUG - 2024-01-29 16:49:13 --> UTF-8 Support Enabled
INFO - 2024-01-29 16:49:13 --> Utf8 Class Initialized
INFO - 2024-01-29 16:49:13 --> URI Class Initialized
INFO - 2024-01-29 16:49:13 --> Router Class Initialized
INFO - 2024-01-29 16:49:13 --> Output Class Initialized
INFO - 2024-01-29 16:49:13 --> Security Class Initialized
DEBUG - 2024-01-29 16:49:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-01-29 16:49:13 --> Input Class Initialized
INFO - 2024-01-29 16:49:13 --> Language Class Initialized
INFO - 2024-01-29 16:49:13 --> Helper loaded: url_helper
INFO - 2024-01-29 16:49:13 --> Helper loaded: file_helper
INFO - 2024-01-29 16:49:13 --> Helper loaded: form_helper
INFO - 2024-01-29 16:49:13 --> Helper loaded: my_helper
INFO - 2024-01-29 16:49:13 --> Language Class Initialized
INFO - 2024-01-29 16:49:13 --> Config Class Initialized
INFO - 2024-01-29 16:49:13 --> Loader Class Initialized
INFO - 2024-01-29 16:49:13 --> Helper loaded: url_helper
INFO - 2024-01-29 16:49:13 --> Helper loaded: file_helper
INFO - 2024-01-29 16:49:13 --> Helper loaded: form_helper
INFO - 2024-01-29 16:49:13 --> Helper loaded: my_helper
INFO - 2024-01-29 16:49:13 --> Database Driver Class Initialized
INFO - 2024-01-29 16:49:13 --> Database Driver Class Initialized
INFO - 2024-01-29 16:49:13 --> Session: Class initialized using 'files' driver.
INFO - 2024-01-29 16:49:13 --> Controller Class Initialized
INFO - 2024-01-29 16:49:13 --> Helper loaded: cookie_helper
INFO - 2024-01-29 16:49:13 --> Final output sent to browser
DEBUG - 2024-01-29 16:49:13 --> Total execution time: 0.1608
INFO - 2024-01-29 16:49:13 --> Helper loaded: cookie_helper
INFO - 2024-01-29 16:49:13 --> Final output sent to browser
DEBUG - 2024-01-29 16:49:13 --> Total execution time: 0.0791
INFO - 2024-01-29 16:49:13 --> Session: Class initialized using 'files' driver.
INFO - 2024-01-29 16:49:13 --> Controller Class Initialized
INFO - 2024-01-29 16:49:13 --> Helper loaded: cookie_helper
INFO - 2024-01-29 16:49:13 --> Final output sent to browser
DEBUG - 2024-01-29 16:49:13 --> Total execution time: 0.0720
INFO - 2024-01-29 16:49:13 --> Config Class Initialized
INFO - 2024-01-29 16:49:13 --> Hooks Class Initialized
DEBUG - 2024-01-29 16:49:13 --> UTF-8 Support Enabled
INFO - 2024-01-29 16:49:13 --> Utf8 Class Initialized
INFO - 2024-01-29 16:49:13 --> URI Class Initialized
INFO - 2024-01-29 16:49:13 --> Router Class Initialized
INFO - 2024-01-29 16:49:13 --> Output Class Initialized
INFO - 2024-01-29 16:49:13 --> Security Class Initialized
DEBUG - 2024-01-29 16:49:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-01-29 16:49:13 --> Input Class Initialized
INFO - 2024-01-29 16:49:13 --> Language Class Initialized
INFO - 2024-01-29 16:49:13 --> Language Class Initialized
INFO - 2024-01-29 16:49:13 --> Config Class Initialized
INFO - 2024-01-29 16:49:13 --> Loader Class Initialized
INFO - 2024-01-29 16:49:13 --> Helper loaded: url_helper
INFO - 2024-01-29 16:49:13 --> Helper loaded: file_helper
INFO - 2024-01-29 16:49:13 --> Helper loaded: form_helper
INFO - 2024-01-29 16:49:13 --> Helper loaded: my_helper
INFO - 2024-01-29 16:49:13 --> Database Driver Class Initialized
INFO - 2024-01-29 16:49:13 --> Session: Class initialized using 'files' driver.
INFO - 2024-01-29 16:49:13 --> Controller Class Initialized
INFO - 2024-01-29 16:49:13 --> Helper loaded: cookie_helper
INFO - 2024-01-29 16:49:13 --> Final output sent to browser
DEBUG - 2024-01-29 16:49:13 --> Total execution time: 0.1005
INFO - 2024-01-29 16:49:14 --> Config Class Initialized
INFO - 2024-01-29 16:49:14 --> Hooks Class Initialized
DEBUG - 2024-01-29 16:49:14 --> UTF-8 Support Enabled
INFO - 2024-01-29 16:49:14 --> Utf8 Class Initialized
INFO - 2024-01-29 16:49:14 --> URI Class Initialized
INFO - 2024-01-29 16:49:14 --> Router Class Initialized
INFO - 2024-01-29 16:49:14 --> Output Class Initialized
INFO - 2024-01-29 16:49:14 --> Security Class Initialized
DEBUG - 2024-01-29 16:49:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-01-29 16:49:14 --> Input Class Initialized
INFO - 2024-01-29 16:49:14 --> Language Class Initialized
INFO - 2024-01-29 16:49:14 --> Language Class Initialized
INFO - 2024-01-29 16:49:14 --> Config Class Initialized
INFO - 2024-01-29 16:49:14 --> Loader Class Initialized
INFO - 2024-01-29 16:49:14 --> Helper loaded: url_helper
INFO - 2024-01-29 16:49:14 --> Helper loaded: file_helper
INFO - 2024-01-29 16:49:14 --> Helper loaded: form_helper
INFO - 2024-01-29 16:49:14 --> Helper loaded: my_helper
INFO - 2024-01-29 16:49:14 --> Database Driver Class Initialized
INFO - 2024-01-29 16:49:14 --> Session: Class initialized using 'files' driver.
INFO - 2024-01-29 16:49:14 --> Controller Class Initialized
INFO - 2024-01-29 16:49:14 --> Helper loaded: cookie_helper
INFO - 2024-01-29 16:49:14 --> Final output sent to browser
DEBUG - 2024-01-29 16:49:14 --> Total execution time: 0.0384
INFO - 2024-01-29 16:49:14 --> Config Class Initialized
INFO - 2024-01-29 16:49:14 --> Hooks Class Initialized
DEBUG - 2024-01-29 16:49:14 --> UTF-8 Support Enabled
INFO - 2024-01-29 16:49:14 --> Utf8 Class Initialized
INFO - 2024-01-29 16:49:14 --> URI Class Initialized
INFO - 2024-01-29 16:49:14 --> Router Class Initialized
INFO - 2024-01-29 16:49:14 --> Output Class Initialized
INFO - 2024-01-29 16:49:14 --> Security Class Initialized
DEBUG - 2024-01-29 16:49:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-01-29 16:49:14 --> Input Class Initialized
INFO - 2024-01-29 16:49:14 --> Language Class Initialized
INFO - 2024-01-29 16:49:14 --> Language Class Initialized
INFO - 2024-01-29 16:49:14 --> Config Class Initialized
INFO - 2024-01-29 16:49:14 --> Loader Class Initialized
INFO - 2024-01-29 16:49:14 --> Helper loaded: url_helper
INFO - 2024-01-29 16:49:14 --> Helper loaded: file_helper
INFO - 2024-01-29 16:49:14 --> Helper loaded: form_helper
INFO - 2024-01-29 16:49:14 --> Helper loaded: my_helper
INFO - 2024-01-29 16:49:14 --> Database Driver Class Initialized
INFO - 2024-01-29 16:49:14 --> Session: Class initialized using 'files' driver.
INFO - 2024-01-29 16:49:14 --> Controller Class Initialized
INFO - 2024-01-29 16:49:14 --> Helper loaded: cookie_helper
INFO - 2024-01-29 16:49:14 --> Config Class Initialized
INFO - 2024-01-29 16:49:14 --> Hooks Class Initialized
DEBUG - 2024-01-29 16:49:14 --> UTF-8 Support Enabled
INFO - 2024-01-29 16:49:14 --> Utf8 Class Initialized
INFO - 2024-01-29 16:49:14 --> URI Class Initialized
INFO - 2024-01-29 16:49:14 --> Router Class Initialized
INFO - 2024-01-29 16:49:14 --> Output Class Initialized
INFO - 2024-01-29 16:49:14 --> Security Class Initialized
DEBUG - 2024-01-29 16:49:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-01-29 16:49:14 --> Input Class Initialized
INFO - 2024-01-29 16:49:14 --> Language Class Initialized
INFO - 2024-01-29 16:49:14 --> Language Class Initialized
INFO - 2024-01-29 16:49:14 --> Config Class Initialized
INFO - 2024-01-29 16:49:14 --> Loader Class Initialized
INFO - 2024-01-29 16:49:14 --> Helper loaded: url_helper
INFO - 2024-01-29 16:49:14 --> Helper loaded: file_helper
INFO - 2024-01-29 16:49:14 --> Helper loaded: form_helper
INFO - 2024-01-29 16:49:14 --> Helper loaded: my_helper
INFO - 2024-01-29 16:49:14 --> Database Driver Class Initialized
INFO - 2024-01-29 16:49:14 --> Config Class Initialized
INFO - 2024-01-29 16:49:14 --> Hooks Class Initialized
DEBUG - 2024-01-29 16:49:14 --> UTF-8 Support Enabled
INFO - 2024-01-29 16:49:14 --> Utf8 Class Initialized
INFO - 2024-01-29 16:49:14 --> URI Class Initialized
INFO - 2024-01-29 16:49:14 --> Router Class Initialized
INFO - 2024-01-29 16:49:14 --> Output Class Initialized
INFO - 2024-01-29 16:49:14 --> Security Class Initialized
DEBUG - 2024-01-29 16:49:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-01-29 16:49:14 --> Input Class Initialized
INFO - 2024-01-29 16:49:14 --> Language Class Initialized
INFO - 2024-01-29 16:49:14 --> Session: Class initialized using 'files' driver.
INFO - 2024-01-29 16:49:14 --> Controller Class Initialized
INFO - 2024-01-29 16:49:14 --> Language Class Initialized
INFO - 2024-01-29 16:49:14 --> Config Class Initialized
INFO - 2024-01-29 16:49:14 --> Loader Class Initialized
INFO - 2024-01-29 16:49:14 --> Helper loaded: url_helper
INFO - 2024-01-29 16:49:14 --> Helper loaded: file_helper
INFO - 2024-01-29 16:49:14 --> Helper loaded: form_helper
INFO - 2024-01-29 16:49:14 --> Helper loaded: my_helper
INFO - 2024-01-29 16:49:14 --> Database Driver Class Initialized
INFO - 2024-01-29 16:49:14 --> Session: Class initialized using 'files' driver.
INFO - 2024-01-29 16:49:14 --> Controller Class Initialized
INFO - 2024-01-29 16:49:14 --> Helper loaded: cookie_helper
DEBUG - 2024-01-29 16:49:14 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/lihat_raport/views/list.php
DEBUG - 2024-01-29 16:49:14 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-01-29 16:49:14 --> Final output sent to browser
DEBUG - 2024-01-29 16:49:14 --> Total execution time: 0.0555
INFO - 2024-01-29 16:49:14 --> Config Class Initialized
INFO - 2024-01-29 16:49:14 --> Hooks Class Initialized
DEBUG - 2024-01-29 16:49:14 --> UTF-8 Support Enabled
INFO - 2024-01-29 16:49:14 --> Utf8 Class Initialized
INFO - 2024-01-29 16:49:14 --> URI Class Initialized
INFO - 2024-01-29 16:49:14 --> Router Class Initialized
INFO - 2024-01-29 16:49:14 --> Output Class Initialized
INFO - 2024-01-29 16:49:14 --> Security Class Initialized
INFO - 2024-01-29 16:49:14 --> Config Class Initialized
INFO - 2024-01-29 16:49:14 --> Hooks Class Initialized
DEBUG - 2024-01-29 16:49:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-01-29 16:49:14 --> Input Class Initialized
INFO - 2024-01-29 16:49:14 --> Language Class Initialized
INFO - 2024-01-29 16:49:14 --> Language Class Initialized
INFO - 2024-01-29 16:49:14 --> Config Class Initialized
INFO - 2024-01-29 16:49:14 --> Loader Class Initialized
INFO - 2024-01-29 16:49:14 --> Helper loaded: url_helper
INFO - 2024-01-29 16:49:14 --> Helper loaded: file_helper
INFO - 2024-01-29 16:49:14 --> Helper loaded: form_helper
INFO - 2024-01-29 16:49:14 --> Helper loaded: my_helper
DEBUG - 2024-01-29 16:49:14 --> UTF-8 Support Enabled
INFO - 2024-01-29 16:49:14 --> Utf8 Class Initialized
INFO - 2024-01-29 16:49:14 --> Database Driver Class Initialized
INFO - 2024-01-29 16:49:14 --> URI Class Initialized
INFO - 2024-01-29 16:49:14 --> Router Class Initialized
INFO - 2024-01-29 16:49:14 --> Output Class Initialized
INFO - 2024-01-29 16:49:14 --> Security Class Initialized
DEBUG - 2024-01-29 16:49:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-01-29 16:49:14 --> Input Class Initialized
INFO - 2024-01-29 16:49:14 --> Language Class Initialized
INFO - 2024-01-29 16:49:15 --> Session: Class initialized using 'files' driver.
INFO - 2024-01-29 16:49:15 --> Controller Class Initialized
INFO - 2024-01-29 16:49:15 --> Language Class Initialized
INFO - 2024-01-29 16:49:15 --> Config Class Initialized
INFO - 2024-01-29 16:49:15 --> Loader Class Initialized
INFO - 2024-01-29 16:49:15 --> Helper loaded: url_helper
INFO - 2024-01-29 16:49:15 --> Helper loaded: file_helper
INFO - 2024-01-29 16:49:15 --> Helper loaded: form_helper
INFO - 2024-01-29 16:49:15 --> Helper loaded: my_helper
INFO - 2024-01-29 16:49:15 --> Database Driver Class Initialized
INFO - 2024-01-29 16:49:15 --> Session: Class initialized using 'files' driver.
INFO - 2024-01-29 16:49:15 --> Controller Class Initialized
DEBUG - 2024-01-29 16:49:15 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/lihat_raport/views/list.php
DEBUG - 2024-01-29 16:49:15 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-01-29 16:49:15 --> Final output sent to browser
DEBUG - 2024-01-29 16:49:15 --> Total execution time: 0.0904
INFO - 2024-01-29 16:49:15 --> Helper loaded: cookie_helper
INFO - 2024-01-29 16:49:15 --> Config Class Initialized
INFO - 2024-01-29 16:49:15 --> Hooks Class Initialized
DEBUG - 2024-01-29 16:49:15 --> UTF-8 Support Enabled
INFO - 2024-01-29 16:49:15 --> Utf8 Class Initialized
INFO - 2024-01-29 16:49:15 --> URI Class Initialized
INFO - 2024-01-29 16:49:15 --> Router Class Initialized
INFO - 2024-01-29 16:49:15 --> Output Class Initialized
INFO - 2024-01-29 16:49:15 --> Security Class Initialized
DEBUG - 2024-01-29 16:49:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-01-29 16:49:15 --> Input Class Initialized
INFO - 2024-01-29 16:49:15 --> Language Class Initialized
INFO - 2024-01-29 16:49:15 --> Language Class Initialized
INFO - 2024-01-29 16:49:15 --> Config Class Initialized
INFO - 2024-01-29 16:49:15 --> Loader Class Initialized
INFO - 2024-01-29 16:49:15 --> Helper loaded: url_helper
INFO - 2024-01-29 16:49:15 --> Helper loaded: file_helper
INFO - 2024-01-29 16:49:15 --> Helper loaded: form_helper
INFO - 2024-01-29 16:49:15 --> Helper loaded: my_helper
INFO - 2024-01-29 16:49:15 --> Database Driver Class Initialized
INFO - 2024-01-29 16:49:15 --> Session: Class initialized using 'files' driver.
INFO - 2024-01-29 16:49:15 --> Controller Class Initialized
INFO - 2024-01-29 16:49:15 --> Helper loaded: cookie_helper
INFO - 2024-01-29 16:49:15 --> Config Class Initialized
INFO - 2024-01-29 16:49:15 --> Hooks Class Initialized
DEBUG - 2024-01-29 16:49:15 --> UTF-8 Support Enabled
INFO - 2024-01-29 16:49:15 --> Utf8 Class Initialized
INFO - 2024-01-29 16:49:15 --> URI Class Initialized
INFO - 2024-01-29 16:49:15 --> Router Class Initialized
INFO - 2024-01-29 16:49:15 --> Output Class Initialized
INFO - 2024-01-29 16:49:15 --> Security Class Initialized
DEBUG - 2024-01-29 16:49:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-01-29 16:49:15 --> Input Class Initialized
INFO - 2024-01-29 16:49:15 --> Language Class Initialized
INFO - 2024-01-29 16:49:15 --> Language Class Initialized
INFO - 2024-01-29 16:49:15 --> Config Class Initialized
INFO - 2024-01-29 16:49:15 --> Loader Class Initialized
INFO - 2024-01-29 16:49:15 --> Helper loaded: url_helper
INFO - 2024-01-29 16:49:15 --> Helper loaded: file_helper
INFO - 2024-01-29 16:49:15 --> Helper loaded: form_helper
INFO - 2024-01-29 16:49:15 --> Helper loaded: my_helper
INFO - 2024-01-29 16:49:15 --> Database Driver Class Initialized
INFO - 2024-01-29 16:49:15 --> Session: Class initialized using 'files' driver.
INFO - 2024-01-29 16:49:15 --> Controller Class Initialized
DEBUG - 2024-01-29 16:49:15 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/lihat_raport/views/list.php
DEBUG - 2024-01-29 16:49:15 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-01-29 16:49:15 --> Final output sent to browser
DEBUG - 2024-01-29 16:49:15 --> Total execution time: 0.0342
INFO - 2024-01-29 16:49:15 --> Config Class Initialized
INFO - 2024-01-29 16:49:15 --> Hooks Class Initialized
DEBUG - 2024-01-29 16:49:15 --> UTF-8 Support Enabled
INFO - 2024-01-29 16:49:15 --> Utf8 Class Initialized
INFO - 2024-01-29 16:49:15 --> URI Class Initialized
INFO - 2024-01-29 16:49:15 --> Router Class Initialized
INFO - 2024-01-29 16:49:15 --> Output Class Initialized
INFO - 2024-01-29 16:49:15 --> Security Class Initialized
DEBUG - 2024-01-29 16:49:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-01-29 16:49:15 --> Input Class Initialized
INFO - 2024-01-29 16:49:15 --> Language Class Initialized
INFO - 2024-01-29 16:49:15 --> Language Class Initialized
INFO - 2024-01-29 16:49:15 --> Config Class Initialized
INFO - 2024-01-29 16:49:15 --> Loader Class Initialized
INFO - 2024-01-29 16:49:15 --> Helper loaded: url_helper
INFO - 2024-01-29 16:49:15 --> Helper loaded: file_helper
INFO - 2024-01-29 16:49:15 --> Helper loaded: form_helper
INFO - 2024-01-29 16:49:15 --> Helper loaded: my_helper
INFO - 2024-01-29 16:49:15 --> Database Driver Class Initialized
INFO - 2024-01-29 16:49:15 --> Session: Class initialized using 'files' driver.
INFO - 2024-01-29 16:49:15 --> Controller Class Initialized
INFO - 2024-01-29 16:49:15 --> Helper loaded: cookie_helper
INFO - 2024-01-29 16:49:15 --> Config Class Initialized
INFO - 2024-01-29 16:49:15 --> Hooks Class Initialized
DEBUG - 2024-01-29 16:49:15 --> UTF-8 Support Enabled
INFO - 2024-01-29 16:49:15 --> Utf8 Class Initialized
INFO - 2024-01-29 16:49:15 --> URI Class Initialized
INFO - 2024-01-29 16:49:15 --> Router Class Initialized
INFO - 2024-01-29 16:49:15 --> Output Class Initialized
INFO - 2024-01-29 16:49:15 --> Security Class Initialized
DEBUG - 2024-01-29 16:49:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-01-29 16:49:15 --> Input Class Initialized
INFO - 2024-01-29 16:49:15 --> Language Class Initialized
INFO - 2024-01-29 16:49:15 --> Language Class Initialized
INFO - 2024-01-29 16:49:15 --> Config Class Initialized
INFO - 2024-01-29 16:49:15 --> Loader Class Initialized
INFO - 2024-01-29 16:49:15 --> Helper loaded: url_helper
INFO - 2024-01-29 16:49:15 --> Helper loaded: file_helper
INFO - 2024-01-29 16:49:15 --> Helper loaded: form_helper
INFO - 2024-01-29 16:49:15 --> Helper loaded: my_helper
INFO - 2024-01-29 16:49:15 --> Database Driver Class Initialized
INFO - 2024-01-29 16:49:15 --> Session: Class initialized using 'files' driver.
INFO - 2024-01-29 16:49:15 --> Controller Class Initialized
DEBUG - 2024-01-29 16:49:15 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/lihat_raport/views/list.php
DEBUG - 2024-01-29 16:49:15 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-01-29 16:49:15 --> Final output sent to browser
DEBUG - 2024-01-29 16:49:15 --> Total execution time: 0.0383
INFO - 2024-01-29 16:49:15 --> Config Class Initialized
INFO - 2024-01-29 16:49:15 --> Hooks Class Initialized
DEBUG - 2024-01-29 16:49:15 --> UTF-8 Support Enabled
INFO - 2024-01-29 16:49:15 --> Utf8 Class Initialized
INFO - 2024-01-29 16:49:15 --> URI Class Initialized
INFO - 2024-01-29 16:49:15 --> Router Class Initialized
INFO - 2024-01-29 16:49:15 --> Output Class Initialized
INFO - 2024-01-29 16:49:15 --> Security Class Initialized
DEBUG - 2024-01-29 16:49:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-01-29 16:49:15 --> Input Class Initialized
INFO - 2024-01-29 16:49:15 --> Language Class Initialized
INFO - 2024-01-29 16:49:15 --> Language Class Initialized
INFO - 2024-01-29 16:49:15 --> Config Class Initialized
INFO - 2024-01-29 16:49:15 --> Loader Class Initialized
INFO - 2024-01-29 16:49:15 --> Helper loaded: url_helper
INFO - 2024-01-29 16:49:15 --> Helper loaded: file_helper
INFO - 2024-01-29 16:49:15 --> Helper loaded: form_helper
INFO - 2024-01-29 16:49:15 --> Helper loaded: my_helper
INFO - 2024-01-29 16:49:15 --> Database Driver Class Initialized
INFO - 2024-01-29 16:49:15 --> Session: Class initialized using 'files' driver.
INFO - 2024-01-29 16:49:15 --> Controller Class Initialized
DEBUG - 2024-01-29 16:49:15 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/lihat_raport/views/list.php
DEBUG - 2024-01-29 16:49:15 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-01-29 16:49:15 --> Final output sent to browser
DEBUG - 2024-01-29 16:49:15 --> Total execution time: 0.0346
