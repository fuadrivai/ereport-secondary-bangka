<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2024-08-22 12:58:22 --> Config Class Initialized
INFO - 2024-08-22 12:58:22 --> Hooks Class Initialized
DEBUG - 2024-08-22 12:58:22 --> UTF-8 Support Enabled
INFO - 2024-08-22 12:58:22 --> Utf8 Class Initialized
INFO - 2024-08-22 12:58:22 --> URI Class Initialized
INFO - 2024-08-22 12:58:22 --> Router Class Initialized
INFO - 2024-08-22 12:58:22 --> Output Class Initialized
INFO - 2024-08-22 12:58:22 --> Security Class Initialized
DEBUG - 2024-08-22 12:58:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-08-22 12:58:22 --> Input Class Initialized
INFO - 2024-08-22 12:58:22 --> Language Class Initialized
INFO - 2024-08-22 12:58:22 --> Language Class Initialized
INFO - 2024-08-22 12:58:22 --> Config Class Initialized
INFO - 2024-08-22 12:58:22 --> Loader Class Initialized
INFO - 2024-08-22 12:58:22 --> Helper loaded: url_helper
INFO - 2024-08-22 12:58:22 --> Helper loaded: file_helper
INFO - 2024-08-22 12:58:22 --> Helper loaded: form_helper
INFO - 2024-08-22 12:58:22 --> Helper loaded: my_helper
INFO - 2024-08-22 12:58:22 --> Database Driver Class Initialized
INFO - 2024-08-22 12:58:22 --> Session: Class initialized using 'files' driver.
INFO - 2024-08-22 12:58:22 --> Controller Class Initialized
INFO - 2024-08-22 12:58:22 --> Helper loaded: cookie_helper
INFO - 2024-08-22 12:58:22 --> Final output sent to browser
DEBUG - 2024-08-22 12:58:22 --> Total execution time: 0.0546
INFO - 2024-08-22 12:58:23 --> Config Class Initialized
INFO - 2024-08-22 12:58:23 --> Hooks Class Initialized
DEBUG - 2024-08-22 12:58:23 --> UTF-8 Support Enabled
INFO - 2024-08-22 12:58:23 --> Utf8 Class Initialized
INFO - 2024-08-22 12:58:23 --> URI Class Initialized
INFO - 2024-08-22 12:58:23 --> Router Class Initialized
INFO - 2024-08-22 12:58:23 --> Output Class Initialized
INFO - 2024-08-22 12:58:23 --> Security Class Initialized
DEBUG - 2024-08-22 12:58:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-08-22 12:58:23 --> Input Class Initialized
INFO - 2024-08-22 12:58:23 --> Language Class Initialized
INFO - 2024-08-22 12:58:23 --> Language Class Initialized
INFO - 2024-08-22 12:58:23 --> Config Class Initialized
INFO - 2024-08-22 12:58:23 --> Loader Class Initialized
INFO - 2024-08-22 12:58:23 --> Helper loaded: url_helper
INFO - 2024-08-22 12:58:23 --> Helper loaded: file_helper
INFO - 2024-08-22 12:58:23 --> Helper loaded: form_helper
INFO - 2024-08-22 12:58:23 --> Helper loaded: my_helper
INFO - 2024-08-22 12:58:23 --> Database Driver Class Initialized
INFO - 2024-08-22 12:58:23 --> Session: Class initialized using 'files' driver.
INFO - 2024-08-22 12:58:23 --> Controller Class Initialized
INFO - 2024-08-22 12:58:23 --> Helper loaded: cookie_helper
INFO - 2024-08-22 12:58:23 --> Config Class Initialized
INFO - 2024-08-22 12:58:23 --> Hooks Class Initialized
DEBUG - 2024-08-22 12:58:23 --> UTF-8 Support Enabled
INFO - 2024-08-22 12:58:23 --> Utf8 Class Initialized
INFO - 2024-08-22 12:58:23 --> URI Class Initialized
INFO - 2024-08-22 12:58:23 --> Router Class Initialized
INFO - 2024-08-22 12:58:23 --> Output Class Initialized
INFO - 2024-08-22 12:58:23 --> Security Class Initialized
DEBUG - 2024-08-22 12:58:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-08-22 12:58:23 --> Input Class Initialized
INFO - 2024-08-22 12:58:23 --> Language Class Initialized
INFO - 2024-08-22 12:58:23 --> Language Class Initialized
INFO - 2024-08-22 12:58:23 --> Config Class Initialized
INFO - 2024-08-22 12:58:23 --> Loader Class Initialized
INFO - 2024-08-22 12:58:23 --> Helper loaded: url_helper
INFO - 2024-08-22 12:58:23 --> Helper loaded: file_helper
INFO - 2024-08-22 12:58:23 --> Helper loaded: form_helper
INFO - 2024-08-22 12:58:23 --> Helper loaded: my_helper
INFO - 2024-08-22 12:58:23 --> Database Driver Class Initialized
INFO - 2024-08-22 12:58:23 --> Session: Class initialized using 'files' driver.
INFO - 2024-08-22 12:58:23 --> Controller Class Initialized
DEBUG - 2024-08-22 12:58:23 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/lihat_raport/views/list.php
DEBUG - 2024-08-22 12:58:23 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-08-22 12:58:23 --> Final output sent to browser
DEBUG - 2024-08-22 12:58:23 --> Total execution time: 0.0463
INFO - 2024-08-22 12:58:24 --> Config Class Initialized
INFO - 2024-08-22 12:58:24 --> Hooks Class Initialized
DEBUG - 2024-08-22 12:58:24 --> UTF-8 Support Enabled
INFO - 2024-08-22 12:58:24 --> Utf8 Class Initialized
INFO - 2024-08-22 12:58:24 --> URI Class Initialized
INFO - 2024-08-22 12:58:25 --> Router Class Initialized
INFO - 2024-08-22 12:58:25 --> Output Class Initialized
INFO - 2024-08-22 12:58:25 --> Security Class Initialized
DEBUG - 2024-08-22 12:58:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-08-22 12:58:25 --> Input Class Initialized
INFO - 2024-08-22 12:58:25 --> Language Class Initialized
INFO - 2024-08-22 12:58:25 --> Language Class Initialized
INFO - 2024-08-22 12:58:25 --> Config Class Initialized
INFO - 2024-08-22 12:58:25 --> Loader Class Initialized
INFO - 2024-08-22 12:58:25 --> Helper loaded: url_helper
INFO - 2024-08-22 12:58:25 --> Helper loaded: file_helper
INFO - 2024-08-22 12:58:25 --> Helper loaded: form_helper
INFO - 2024-08-22 12:58:25 --> Helper loaded: my_helper
INFO - 2024-08-22 12:58:25 --> Database Driver Class Initialized
INFO - 2024-08-22 12:58:25 --> Session: Class initialized using 'files' driver.
INFO - 2024-08-22 12:58:25 --> Controller Class Initialized
ERROR - 2024-08-22 12:58:25 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 2591
ERROR - 2024-08-22 12:58:25 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 3156
ERROR - 2024-08-22 12:58:25 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 3194
ERROR - 2024-08-22 12:58:25 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 3232
ERROR - 2024-08-22 12:58:25 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 3271
ERROR - 2024-08-22 12:58:25 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 3388
ERROR - 2024-08-22 12:58:25 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 3507
ERROR - 2024-08-22 12:58:25 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 3626
ERROR - 2024-08-22 12:58:25 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 3745
ERROR - 2024-08-22 12:58:25 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/views/cetak_mh.php 6
ERROR - 2024-08-22 12:58:25 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/views/cetak_mh.php 6
ERROR - 2024-08-22 12:58:25 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/views/cetak_mh.php 40
ERROR - 2024-08-22 12:58:25 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/views/cetak_mh.php 44
ERROR - 2024-08-22 12:58:25 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/views/cetak_mh.php 44
ERROR - 2024-08-22 12:58:25 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/views/cetak_mh.php 65
ERROR - 2024-08-22 12:58:25 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/views/cetak_mh.php 65
DEBUG - 2024-08-22 12:58:25 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/views/cetak_mh.php
INFO - 2024-08-22 15:31:37 --> Config Class Initialized
INFO - 2024-08-22 15:31:37 --> Hooks Class Initialized
DEBUG - 2024-08-22 15:31:37 --> UTF-8 Support Enabled
INFO - 2024-08-22 15:31:37 --> Utf8 Class Initialized
INFO - 2024-08-22 15:31:37 --> URI Class Initialized
INFO - 2024-08-22 15:31:37 --> Router Class Initialized
INFO - 2024-08-22 15:31:37 --> Output Class Initialized
INFO - 2024-08-22 15:31:37 --> Security Class Initialized
DEBUG - 2024-08-22 15:31:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-08-22 15:31:37 --> Input Class Initialized
INFO - 2024-08-22 15:31:37 --> Language Class Initialized
INFO - 2024-08-22 15:31:37 --> Language Class Initialized
INFO - 2024-08-22 15:31:37 --> Config Class Initialized
INFO - 2024-08-22 15:31:37 --> Loader Class Initialized
INFO - 2024-08-22 15:31:37 --> Helper loaded: url_helper
INFO - 2024-08-22 15:31:37 --> Helper loaded: file_helper
INFO - 2024-08-22 15:31:37 --> Helper loaded: form_helper
INFO - 2024-08-22 15:31:37 --> Helper loaded: my_helper
INFO - 2024-08-22 15:31:37 --> Database Driver Class Initialized
INFO - 2024-08-22 15:31:37 --> Session: Class initialized using 'files' driver.
INFO - 2024-08-22 15:31:37 --> Controller Class Initialized
INFO - 2024-08-22 15:31:37 --> Helper loaded: cookie_helper
INFO - 2024-08-22 15:31:37 --> Final output sent to browser
DEBUG - 2024-08-22 15:31:37 --> Total execution time: 0.0946
INFO - 2024-08-22 15:31:37 --> Config Class Initialized
INFO - 2024-08-22 15:31:37 --> Hooks Class Initialized
DEBUG - 2024-08-22 15:31:37 --> UTF-8 Support Enabled
INFO - 2024-08-22 15:31:37 --> Utf8 Class Initialized
INFO - 2024-08-22 15:31:37 --> URI Class Initialized
INFO - 2024-08-22 15:31:37 --> Router Class Initialized
INFO - 2024-08-22 15:31:37 --> Output Class Initialized
INFO - 2024-08-22 15:31:37 --> Security Class Initialized
DEBUG - 2024-08-22 15:31:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-08-22 15:31:37 --> Input Class Initialized
INFO - 2024-08-22 15:31:37 --> Language Class Initialized
INFO - 2024-08-22 15:31:37 --> Language Class Initialized
INFO - 2024-08-22 15:31:37 --> Config Class Initialized
INFO - 2024-08-22 15:31:37 --> Loader Class Initialized
INFO - 2024-08-22 15:31:37 --> Helper loaded: url_helper
INFO - 2024-08-22 15:31:37 --> Helper loaded: file_helper
INFO - 2024-08-22 15:31:37 --> Helper loaded: form_helper
INFO - 2024-08-22 15:31:37 --> Helper loaded: my_helper
INFO - 2024-08-22 15:31:37 --> Database Driver Class Initialized
INFO - 2024-08-22 15:31:38 --> Session: Class initialized using 'files' driver.
INFO - 2024-08-22 15:31:38 --> Controller Class Initialized
INFO - 2024-08-22 15:31:38 --> Helper loaded: cookie_helper
INFO - 2024-08-22 15:31:38 --> Config Class Initialized
INFO - 2024-08-22 15:31:38 --> Hooks Class Initialized
DEBUG - 2024-08-22 15:31:38 --> UTF-8 Support Enabled
INFO - 2024-08-22 15:31:38 --> Utf8 Class Initialized
INFO - 2024-08-22 15:31:38 --> URI Class Initialized
INFO - 2024-08-22 15:31:38 --> Router Class Initialized
INFO - 2024-08-22 15:31:38 --> Output Class Initialized
INFO - 2024-08-22 15:31:38 --> Security Class Initialized
DEBUG - 2024-08-22 15:31:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-08-22 15:31:38 --> Input Class Initialized
INFO - 2024-08-22 15:31:38 --> Language Class Initialized
INFO - 2024-08-22 15:31:38 --> Language Class Initialized
INFO - 2024-08-22 15:31:38 --> Config Class Initialized
INFO - 2024-08-22 15:31:38 --> Loader Class Initialized
INFO - 2024-08-22 15:31:38 --> Helper loaded: url_helper
INFO - 2024-08-22 15:31:38 --> Helper loaded: file_helper
INFO - 2024-08-22 15:31:38 --> Helper loaded: form_helper
INFO - 2024-08-22 15:31:38 --> Helper loaded: my_helper
INFO - 2024-08-22 15:31:38 --> Database Driver Class Initialized
INFO - 2024-08-22 15:31:38 --> Session: Class initialized using 'files' driver.
INFO - 2024-08-22 15:31:38 --> Controller Class Initialized
DEBUG - 2024-08-22 15:31:38 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/lihat_raport/views/list.php
DEBUG - 2024-08-22 15:31:38 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-08-22 15:31:38 --> Final output sent to browser
DEBUG - 2024-08-22 15:31:38 --> Total execution time: 0.0532
INFO - 2024-08-22 18:01:16 --> Config Class Initialized
INFO - 2024-08-22 18:01:16 --> Hooks Class Initialized
DEBUG - 2024-08-22 18:01:16 --> UTF-8 Support Enabled
INFO - 2024-08-22 18:01:16 --> Utf8 Class Initialized
INFO - 2024-08-22 18:01:16 --> URI Class Initialized
INFO - 2024-08-22 18:01:17 --> Router Class Initialized
INFO - 2024-08-22 18:01:17 --> Output Class Initialized
INFO - 2024-08-22 18:01:17 --> Security Class Initialized
DEBUG - 2024-08-22 18:01:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-08-22 18:01:17 --> Input Class Initialized
INFO - 2024-08-22 18:01:17 --> Language Class Initialized
INFO - 2024-08-22 18:01:17 --> Language Class Initialized
INFO - 2024-08-22 18:01:17 --> Config Class Initialized
INFO - 2024-08-22 18:01:17 --> Loader Class Initialized
INFO - 2024-08-22 18:01:17 --> Helper loaded: url_helper
INFO - 2024-08-22 18:01:17 --> Helper loaded: file_helper
INFO - 2024-08-22 18:01:17 --> Helper loaded: form_helper
INFO - 2024-08-22 18:01:17 --> Helper loaded: my_helper
INFO - 2024-08-22 18:01:17 --> Database Driver Class Initialized
INFO - 2024-08-22 18:01:17 --> Session: Class initialized using 'files' driver.
INFO - 2024-08-22 18:01:17 --> Controller Class Initialized
INFO - 2024-08-22 18:01:17 --> Final output sent to browser
DEBUG - 2024-08-22 18:01:17 --> Total execution time: 0.1007
INFO - 2024-08-22 20:33:49 --> Config Class Initialized
INFO - 2024-08-22 20:33:49 --> Hooks Class Initialized
DEBUG - 2024-08-22 20:33:49 --> UTF-8 Support Enabled
INFO - 2024-08-22 20:33:49 --> Utf8 Class Initialized
INFO - 2024-08-22 20:33:49 --> URI Class Initialized
INFO - 2024-08-22 20:33:49 --> Router Class Initialized
INFO - 2024-08-22 20:33:49 --> Output Class Initialized
INFO - 2024-08-22 20:33:49 --> Security Class Initialized
DEBUG - 2024-08-22 20:33:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-08-22 20:33:49 --> Input Class Initialized
INFO - 2024-08-22 20:33:49 --> Language Class Initialized
INFO - 2024-08-22 20:33:49 --> Language Class Initialized
INFO - 2024-08-22 20:33:49 --> Config Class Initialized
INFO - 2024-08-22 20:33:49 --> Loader Class Initialized
INFO - 2024-08-22 20:33:49 --> Helper loaded: url_helper
INFO - 2024-08-22 20:33:49 --> Helper loaded: file_helper
INFO - 2024-08-22 20:33:50 --> Helper loaded: form_helper
INFO - 2024-08-22 20:33:50 --> Helper loaded: my_helper
INFO - 2024-08-22 20:33:50 --> Database Driver Class Initialized
INFO - 2024-08-22 20:33:50 --> Session: Class initialized using 'files' driver.
INFO - 2024-08-22 20:33:50 --> Controller Class Initialized
INFO - 2024-08-22 20:33:50 --> Helper loaded: cookie_helper
INFO - 2024-08-22 20:33:50 --> Final output sent to browser
DEBUG - 2024-08-22 20:33:50 --> Total execution time: 0.0753
INFO - 2024-08-22 20:33:50 --> Config Class Initialized
INFO - 2024-08-22 20:33:50 --> Hooks Class Initialized
DEBUG - 2024-08-22 20:33:50 --> UTF-8 Support Enabled
INFO - 2024-08-22 20:33:50 --> Utf8 Class Initialized
INFO - 2024-08-22 20:33:50 --> URI Class Initialized
INFO - 2024-08-22 20:33:50 --> Router Class Initialized
INFO - 2024-08-22 20:33:50 --> Output Class Initialized
INFO - 2024-08-22 20:33:50 --> Security Class Initialized
DEBUG - 2024-08-22 20:33:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-08-22 20:33:50 --> Input Class Initialized
INFO - 2024-08-22 20:33:50 --> Language Class Initialized
INFO - 2024-08-22 20:33:50 --> Language Class Initialized
INFO - 2024-08-22 20:33:50 --> Config Class Initialized
INFO - 2024-08-22 20:33:50 --> Loader Class Initialized
INFO - 2024-08-22 20:33:50 --> Helper loaded: url_helper
INFO - 2024-08-22 20:33:50 --> Helper loaded: file_helper
INFO - 2024-08-22 20:33:50 --> Helper loaded: form_helper
INFO - 2024-08-22 20:33:50 --> Helper loaded: my_helper
INFO - 2024-08-22 20:33:50 --> Database Driver Class Initialized
INFO - 2024-08-22 20:33:50 --> Session: Class initialized using 'files' driver.
INFO - 2024-08-22 20:33:50 --> Controller Class Initialized
INFO - 2024-08-22 20:33:50 --> Helper loaded: cookie_helper
INFO - 2024-08-22 20:33:50 --> Config Class Initialized
INFO - 2024-08-22 20:33:50 --> Hooks Class Initialized
DEBUG - 2024-08-22 20:33:50 --> UTF-8 Support Enabled
INFO - 2024-08-22 20:33:50 --> Utf8 Class Initialized
INFO - 2024-08-22 20:33:50 --> URI Class Initialized
INFO - 2024-08-22 20:33:50 --> Router Class Initialized
INFO - 2024-08-22 20:33:50 --> Output Class Initialized
INFO - 2024-08-22 20:33:50 --> Security Class Initialized
DEBUG - 2024-08-22 20:33:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-08-22 20:33:50 --> Input Class Initialized
INFO - 2024-08-22 20:33:50 --> Language Class Initialized
INFO - 2024-08-22 20:33:50 --> Language Class Initialized
INFO - 2024-08-22 20:33:50 --> Config Class Initialized
INFO - 2024-08-22 20:33:50 --> Loader Class Initialized
INFO - 2024-08-22 20:33:50 --> Helper loaded: url_helper
INFO - 2024-08-22 20:33:50 --> Helper loaded: file_helper
INFO - 2024-08-22 20:33:50 --> Helper loaded: form_helper
INFO - 2024-08-22 20:33:50 --> Helper loaded: my_helper
INFO - 2024-08-22 20:33:50 --> Database Driver Class Initialized
INFO - 2024-08-22 20:33:50 --> Session: Class initialized using 'files' driver.
INFO - 2024-08-22 20:33:50 --> Controller Class Initialized
DEBUG - 2024-08-22 20:33:50 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/lihat_raport/views/list.php
DEBUG - 2024-08-22 20:33:50 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-08-22 20:33:50 --> Final output sent to browser
DEBUG - 2024-08-22 20:33:50 --> Total execution time: 0.0537
