<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2024-03-20 08:43:43 --> Config Class Initialized
INFO - 2024-03-20 08:43:43 --> Hooks Class Initialized
DEBUG - 2024-03-20 08:43:43 --> UTF-8 Support Enabled
INFO - 2024-03-20 08:43:43 --> Utf8 Class Initialized
INFO - 2024-03-20 08:43:43 --> URI Class Initialized
INFO - 2024-03-20 08:43:43 --> Router Class Initialized
INFO - 2024-03-20 08:43:43 --> Output Class Initialized
INFO - 2024-03-20 08:43:43 --> Security Class Initialized
DEBUG - 2024-03-20 08:43:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-20 08:43:43 --> Input Class Initialized
INFO - 2024-03-20 08:43:43 --> Language Class Initialized
INFO - 2024-03-20 08:43:43 --> Language Class Initialized
INFO - 2024-03-20 08:43:43 --> Config Class Initialized
INFO - 2024-03-20 08:43:43 --> Loader Class Initialized
INFO - 2024-03-20 08:43:43 --> Helper loaded: url_helper
INFO - 2024-03-20 08:43:43 --> Helper loaded: file_helper
INFO - 2024-03-20 08:43:43 --> Helper loaded: form_helper
INFO - 2024-03-20 08:43:43 --> Helper loaded: my_helper
INFO - 2024-03-20 08:43:43 --> Database Driver Class Initialized
INFO - 2024-03-20 08:43:43 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-20 08:43:43 --> Controller Class Initialized
DEBUG - 2024-03-20 08:43:43 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/login/views/login.php
DEBUG - 2024-03-20 08:43:43 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-03-20 08:43:43 --> Final output sent to browser
DEBUG - 2024-03-20 08:43:43 --> Total execution time: 0.1122
INFO - 2024-03-20 08:54:35 --> Config Class Initialized
INFO - 2024-03-20 08:54:35 --> Hooks Class Initialized
DEBUG - 2024-03-20 08:54:35 --> UTF-8 Support Enabled
INFO - 2024-03-20 08:54:35 --> Utf8 Class Initialized
INFO - 2024-03-20 08:54:35 --> URI Class Initialized
INFO - 2024-03-20 08:54:35 --> Router Class Initialized
INFO - 2024-03-20 08:54:35 --> Output Class Initialized
INFO - 2024-03-20 08:54:35 --> Security Class Initialized
DEBUG - 2024-03-20 08:54:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-20 08:54:35 --> Input Class Initialized
INFO - 2024-03-20 08:54:35 --> Language Class Initialized
INFO - 2024-03-20 08:54:35 --> Language Class Initialized
INFO - 2024-03-20 08:54:35 --> Config Class Initialized
INFO - 2024-03-20 08:54:35 --> Loader Class Initialized
INFO - 2024-03-20 08:54:35 --> Helper loaded: url_helper
INFO - 2024-03-20 08:54:35 --> Helper loaded: file_helper
INFO - 2024-03-20 08:54:35 --> Helper loaded: form_helper
INFO - 2024-03-20 08:54:35 --> Helper loaded: my_helper
INFO - 2024-03-20 08:54:35 --> Database Driver Class Initialized
INFO - 2024-03-20 08:54:35 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-20 08:54:35 --> Controller Class Initialized
INFO - 2024-03-20 08:54:35 --> Helper loaded: cookie_helper
INFO - 2024-03-20 08:54:35 --> Final output sent to browser
DEBUG - 2024-03-20 08:54:35 --> Total execution time: 0.0606
INFO - 2024-03-20 08:54:35 --> Config Class Initialized
INFO - 2024-03-20 08:54:35 --> Hooks Class Initialized
DEBUG - 2024-03-20 08:54:35 --> UTF-8 Support Enabled
INFO - 2024-03-20 08:54:35 --> Utf8 Class Initialized
INFO - 2024-03-20 08:54:35 --> URI Class Initialized
INFO - 2024-03-20 08:54:35 --> Router Class Initialized
INFO - 2024-03-20 08:54:35 --> Output Class Initialized
INFO - 2024-03-20 08:54:36 --> Security Class Initialized
DEBUG - 2024-03-20 08:54:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-20 08:54:36 --> Input Class Initialized
INFO - 2024-03-20 08:54:36 --> Language Class Initialized
INFO - 2024-03-20 08:54:36 --> Language Class Initialized
INFO - 2024-03-20 08:54:36 --> Config Class Initialized
INFO - 2024-03-20 08:54:36 --> Loader Class Initialized
INFO - 2024-03-20 08:54:36 --> Helper loaded: url_helper
INFO - 2024-03-20 08:54:36 --> Helper loaded: file_helper
INFO - 2024-03-20 08:54:36 --> Helper loaded: form_helper
INFO - 2024-03-20 08:54:36 --> Helper loaded: my_helper
INFO - 2024-03-20 08:54:36 --> Database Driver Class Initialized
INFO - 2024-03-20 08:54:36 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-20 08:54:36 --> Controller Class Initialized
DEBUG - 2024-03-20 08:54:36 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/home/views/v_home_guru.php
DEBUG - 2024-03-20 08:54:36 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-03-20 08:54:36 --> Final output sent to browser
DEBUG - 2024-03-20 08:54:36 --> Total execution time: 0.0960
INFO - 2024-03-20 08:54:41 --> Config Class Initialized
INFO - 2024-03-20 08:54:41 --> Hooks Class Initialized
DEBUG - 2024-03-20 08:54:41 --> UTF-8 Support Enabled
INFO - 2024-03-20 08:54:41 --> Utf8 Class Initialized
INFO - 2024-03-20 08:54:41 --> URI Class Initialized
INFO - 2024-03-20 08:54:41 --> Router Class Initialized
INFO - 2024-03-20 08:54:41 --> Output Class Initialized
INFO - 2024-03-20 08:54:41 --> Security Class Initialized
DEBUG - 2024-03-20 08:54:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-20 08:54:41 --> Input Class Initialized
INFO - 2024-03-20 08:54:41 --> Language Class Initialized
INFO - 2024-03-20 08:54:41 --> Language Class Initialized
INFO - 2024-03-20 08:54:41 --> Config Class Initialized
INFO - 2024-03-20 08:54:41 --> Loader Class Initialized
INFO - 2024-03-20 08:54:41 --> Helper loaded: url_helper
INFO - 2024-03-20 08:54:41 --> Helper loaded: file_helper
INFO - 2024-03-20 08:54:41 --> Helper loaded: form_helper
INFO - 2024-03-20 08:54:41 --> Helper loaded: my_helper
INFO - 2024-03-20 08:54:41 --> Database Driver Class Initialized
INFO - 2024-03-20 08:54:41 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-20 08:54:41 --> Controller Class Initialized
DEBUG - 2024-03-20 08:54:41 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/list.php
DEBUG - 2024-03-20 08:54:41 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-03-20 08:54:41 --> Final output sent to browser
DEBUG - 2024-03-20 08:54:41 --> Total execution time: 0.2461
INFO - 2024-03-20 08:54:44 --> Config Class Initialized
INFO - 2024-03-20 08:54:44 --> Hooks Class Initialized
DEBUG - 2024-03-20 08:54:44 --> UTF-8 Support Enabled
INFO - 2024-03-20 08:54:44 --> Utf8 Class Initialized
INFO - 2024-03-20 08:54:44 --> URI Class Initialized
INFO - 2024-03-20 08:54:44 --> Router Class Initialized
INFO - 2024-03-20 08:54:44 --> Output Class Initialized
INFO - 2024-03-20 08:54:44 --> Security Class Initialized
DEBUG - 2024-03-20 08:54:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-20 08:54:44 --> Input Class Initialized
INFO - 2024-03-20 08:54:44 --> Language Class Initialized
INFO - 2024-03-20 08:54:44 --> Language Class Initialized
INFO - 2024-03-20 08:54:44 --> Config Class Initialized
INFO - 2024-03-20 08:54:44 --> Loader Class Initialized
INFO - 2024-03-20 08:54:44 --> Helper loaded: url_helper
INFO - 2024-03-20 08:54:44 --> Helper loaded: file_helper
INFO - 2024-03-20 08:54:44 --> Helper loaded: form_helper
INFO - 2024-03-20 08:54:44 --> Helper loaded: my_helper
INFO - 2024-03-20 08:54:44 --> Database Driver Class Initialized
INFO - 2024-03-20 08:54:44 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-20 08:54:44 --> Controller Class Initialized
DEBUG - 2024-03-20 08:54:44 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php
INFO - 2024-03-20 08:54:47 --> Final output sent to browser
DEBUG - 2024-03-20 08:54:47 --> Total execution time: 3.1066
INFO - 2024-03-20 08:56:28 --> Config Class Initialized
INFO - 2024-03-20 08:56:28 --> Hooks Class Initialized
DEBUG - 2024-03-20 08:56:28 --> UTF-8 Support Enabled
INFO - 2024-03-20 08:56:28 --> Utf8 Class Initialized
INFO - 2024-03-20 08:56:28 --> URI Class Initialized
INFO - 2024-03-20 08:56:28 --> Router Class Initialized
INFO - 2024-03-20 08:56:28 --> Output Class Initialized
INFO - 2024-03-20 08:56:28 --> Security Class Initialized
DEBUG - 2024-03-20 08:56:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-20 08:56:28 --> Input Class Initialized
INFO - 2024-03-20 08:56:28 --> Language Class Initialized
INFO - 2024-03-20 08:56:28 --> Language Class Initialized
INFO - 2024-03-20 08:56:28 --> Config Class Initialized
INFO - 2024-03-20 08:56:28 --> Loader Class Initialized
INFO - 2024-03-20 08:56:28 --> Helper loaded: url_helper
INFO - 2024-03-20 08:56:28 --> Helper loaded: file_helper
INFO - 2024-03-20 08:56:28 --> Helper loaded: form_helper
INFO - 2024-03-20 08:56:28 --> Helper loaded: my_helper
INFO - 2024-03-20 08:56:28 --> Database Driver Class Initialized
INFO - 2024-03-20 08:56:28 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-20 08:56:28 --> Controller Class Initialized
DEBUG - 2024-03-20 08:56:29 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php
INFO - 2024-03-20 08:56:31 --> Config Class Initialized
INFO - 2024-03-20 08:56:31 --> Hooks Class Initialized
DEBUG - 2024-03-20 08:56:31 --> UTF-8 Support Enabled
INFO - 2024-03-20 08:56:31 --> Utf8 Class Initialized
INFO - 2024-03-20 08:56:31 --> URI Class Initialized
INFO - 2024-03-20 08:56:31 --> Router Class Initialized
INFO - 2024-03-20 08:56:31 --> Output Class Initialized
INFO - 2024-03-20 08:56:31 --> Security Class Initialized
DEBUG - 2024-03-20 08:56:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-20 08:56:31 --> Input Class Initialized
INFO - 2024-03-20 08:56:31 --> Language Class Initialized
INFO - 2024-03-20 08:56:31 --> Language Class Initialized
INFO - 2024-03-20 08:56:31 --> Config Class Initialized
INFO - 2024-03-20 08:56:31 --> Loader Class Initialized
INFO - 2024-03-20 08:56:31 --> Helper loaded: url_helper
INFO - 2024-03-20 08:56:31 --> Helper loaded: file_helper
INFO - 2024-03-20 08:56:31 --> Helper loaded: form_helper
INFO - 2024-03-20 08:56:31 --> Helper loaded: my_helper
INFO - 2024-03-20 08:56:31 --> Database Driver Class Initialized
INFO - 2024-03-20 08:56:33 --> Final output sent to browser
DEBUG - 2024-03-20 08:56:33 --> Total execution time: 5.1908
INFO - 2024-03-20 08:56:33 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-20 08:56:33 --> Controller Class Initialized
DEBUG - 2024-03-20 08:56:34 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php
INFO - 2024-03-20 08:56:37 --> Final output sent to browser
DEBUG - 2024-03-20 08:56:37 --> Total execution time: 6.2981
INFO - 2024-03-20 08:56:51 --> Config Class Initialized
INFO - 2024-03-20 08:56:51 --> Hooks Class Initialized
DEBUG - 2024-03-20 08:56:51 --> UTF-8 Support Enabled
INFO - 2024-03-20 08:56:51 --> Utf8 Class Initialized
INFO - 2024-03-20 08:56:51 --> URI Class Initialized
INFO - 2024-03-20 08:56:51 --> Router Class Initialized
INFO - 2024-03-20 08:56:51 --> Output Class Initialized
INFO - 2024-03-20 08:56:51 --> Security Class Initialized
DEBUG - 2024-03-20 08:56:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-20 08:56:51 --> Input Class Initialized
INFO - 2024-03-20 08:56:51 --> Language Class Initialized
INFO - 2024-03-20 08:56:51 --> Language Class Initialized
INFO - 2024-03-20 08:56:51 --> Config Class Initialized
INFO - 2024-03-20 08:56:51 --> Loader Class Initialized
INFO - 2024-03-20 08:56:51 --> Helper loaded: url_helper
INFO - 2024-03-20 08:56:51 --> Helper loaded: file_helper
INFO - 2024-03-20 08:56:51 --> Helper loaded: form_helper
INFO - 2024-03-20 08:56:51 --> Helper loaded: my_helper
INFO - 2024-03-20 08:56:51 --> Database Driver Class Initialized
INFO - 2024-03-20 08:56:51 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-20 08:56:51 --> Controller Class Initialized
DEBUG - 2024-03-20 08:56:51 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php
INFO - 2024-03-20 08:56:55 --> Final output sent to browser
DEBUG - 2024-03-20 08:56:55 --> Total execution time: 3.8501
INFO - 2024-03-20 08:57:08 --> Config Class Initialized
INFO - 2024-03-20 08:57:08 --> Hooks Class Initialized
DEBUG - 2024-03-20 08:57:08 --> UTF-8 Support Enabled
INFO - 2024-03-20 08:57:08 --> Utf8 Class Initialized
INFO - 2024-03-20 08:57:08 --> URI Class Initialized
INFO - 2024-03-20 08:57:08 --> Router Class Initialized
INFO - 2024-03-20 08:57:08 --> Output Class Initialized
INFO - 2024-03-20 08:57:08 --> Security Class Initialized
DEBUG - 2024-03-20 08:57:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-20 08:57:08 --> Input Class Initialized
INFO - 2024-03-20 08:57:08 --> Language Class Initialized
INFO - 2024-03-20 08:57:08 --> Language Class Initialized
INFO - 2024-03-20 08:57:08 --> Config Class Initialized
INFO - 2024-03-20 08:57:08 --> Loader Class Initialized
INFO - 2024-03-20 08:57:08 --> Helper loaded: url_helper
INFO - 2024-03-20 08:57:08 --> Helper loaded: file_helper
INFO - 2024-03-20 08:57:08 --> Helper loaded: form_helper
INFO - 2024-03-20 08:57:08 --> Helper loaded: my_helper
INFO - 2024-03-20 08:57:08 --> Database Driver Class Initialized
INFO - 2024-03-20 08:57:08 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-20 08:57:08 --> Controller Class Initialized
DEBUG - 2024-03-20 08:57:08 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php
INFO - 2024-03-20 08:57:11 --> Final output sent to browser
DEBUG - 2024-03-20 08:57:11 --> Total execution time: 3.5401
INFO - 2024-03-20 08:57:13 --> Config Class Initialized
INFO - 2024-03-20 08:57:13 --> Hooks Class Initialized
DEBUG - 2024-03-20 08:57:13 --> UTF-8 Support Enabled
INFO - 2024-03-20 08:57:13 --> Utf8 Class Initialized
INFO - 2024-03-20 08:57:13 --> URI Class Initialized
INFO - 2024-03-20 08:57:13 --> Router Class Initialized
INFO - 2024-03-20 08:57:13 --> Output Class Initialized
INFO - 2024-03-20 08:57:13 --> Security Class Initialized
DEBUG - 2024-03-20 08:57:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-20 08:57:13 --> Input Class Initialized
INFO - 2024-03-20 08:57:13 --> Language Class Initialized
INFO - 2024-03-20 08:57:13 --> Language Class Initialized
INFO - 2024-03-20 08:57:13 --> Config Class Initialized
INFO - 2024-03-20 08:57:13 --> Loader Class Initialized
INFO - 2024-03-20 08:57:13 --> Helper loaded: url_helper
INFO - 2024-03-20 08:57:13 --> Helper loaded: file_helper
INFO - 2024-03-20 08:57:13 --> Helper loaded: form_helper
INFO - 2024-03-20 08:57:13 --> Helper loaded: my_helper
INFO - 2024-03-20 08:57:13 --> Database Driver Class Initialized
INFO - 2024-03-20 08:57:13 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-20 08:57:13 --> Controller Class Initialized
DEBUG - 2024-03-20 08:57:13 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php
INFO - 2024-03-20 08:57:18 --> Final output sent to browser
DEBUG - 2024-03-20 08:57:18 --> Total execution time: 4.6581
INFO - 2024-03-20 08:57:42 --> Config Class Initialized
INFO - 2024-03-20 08:57:42 --> Hooks Class Initialized
DEBUG - 2024-03-20 08:57:42 --> UTF-8 Support Enabled
INFO - 2024-03-20 08:57:42 --> Utf8 Class Initialized
INFO - 2024-03-20 08:57:42 --> URI Class Initialized
INFO - 2024-03-20 08:57:42 --> Router Class Initialized
INFO - 2024-03-20 08:57:42 --> Output Class Initialized
INFO - 2024-03-20 08:57:42 --> Security Class Initialized
DEBUG - 2024-03-20 08:57:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-20 08:57:42 --> Input Class Initialized
INFO - 2024-03-20 08:57:42 --> Language Class Initialized
INFO - 2024-03-20 08:57:42 --> Language Class Initialized
INFO - 2024-03-20 08:57:42 --> Config Class Initialized
INFO - 2024-03-20 08:57:42 --> Loader Class Initialized
INFO - 2024-03-20 08:57:42 --> Helper loaded: url_helper
INFO - 2024-03-20 08:57:42 --> Helper loaded: file_helper
INFO - 2024-03-20 08:57:42 --> Helper loaded: form_helper
INFO - 2024-03-20 08:57:42 --> Helper loaded: my_helper
INFO - 2024-03-20 08:57:42 --> Database Driver Class Initialized
INFO - 2024-03-20 08:57:42 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-20 08:57:42 --> Controller Class Initialized
DEBUG - 2024-03-20 08:57:42 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php
INFO - 2024-03-20 08:57:45 --> Config Class Initialized
INFO - 2024-03-20 08:57:45 --> Hooks Class Initialized
DEBUG - 2024-03-20 08:57:45 --> UTF-8 Support Enabled
INFO - 2024-03-20 08:57:45 --> Utf8 Class Initialized
INFO - 2024-03-20 08:57:45 --> URI Class Initialized
INFO - 2024-03-20 08:57:45 --> Router Class Initialized
INFO - 2024-03-20 08:57:45 --> Output Class Initialized
INFO - 2024-03-20 08:57:45 --> Security Class Initialized
DEBUG - 2024-03-20 08:57:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-20 08:57:45 --> Input Class Initialized
INFO - 2024-03-20 08:57:45 --> Language Class Initialized
INFO - 2024-03-20 08:57:46 --> Final output sent to browser
DEBUG - 2024-03-20 08:57:46 --> Total execution time: 4.0016
INFO - 2024-03-20 08:57:46 --> Language Class Initialized
INFO - 2024-03-20 08:57:46 --> Config Class Initialized
INFO - 2024-03-20 08:57:46 --> Loader Class Initialized
INFO - 2024-03-20 08:57:46 --> Helper loaded: url_helper
INFO - 2024-03-20 08:57:46 --> Helper loaded: file_helper
INFO - 2024-03-20 08:57:46 --> Helper loaded: form_helper
INFO - 2024-03-20 08:57:46 --> Helper loaded: my_helper
INFO - 2024-03-20 08:57:46 --> Database Driver Class Initialized
INFO - 2024-03-20 08:57:46 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-20 08:57:46 --> Controller Class Initialized
DEBUG - 2024-03-20 08:57:46 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php
INFO - 2024-03-20 08:57:50 --> Final output sent to browser
DEBUG - 2024-03-20 08:57:50 --> Total execution time: 5.2439
INFO - 2024-03-20 08:58:18 --> Config Class Initialized
INFO - 2024-03-20 08:58:18 --> Hooks Class Initialized
DEBUG - 2024-03-20 08:58:18 --> UTF-8 Support Enabled
INFO - 2024-03-20 08:58:18 --> Utf8 Class Initialized
INFO - 2024-03-20 08:58:18 --> URI Class Initialized
INFO - 2024-03-20 08:58:18 --> Router Class Initialized
INFO - 2024-03-20 08:58:18 --> Output Class Initialized
INFO - 2024-03-20 08:58:18 --> Security Class Initialized
DEBUG - 2024-03-20 08:58:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-20 08:58:18 --> Input Class Initialized
INFO - 2024-03-20 08:58:18 --> Language Class Initialized
INFO - 2024-03-20 08:58:18 --> Language Class Initialized
INFO - 2024-03-20 08:58:18 --> Config Class Initialized
INFO - 2024-03-20 08:58:18 --> Loader Class Initialized
INFO - 2024-03-20 08:58:18 --> Helper loaded: url_helper
INFO - 2024-03-20 08:58:18 --> Helper loaded: file_helper
INFO - 2024-03-20 08:58:18 --> Helper loaded: form_helper
INFO - 2024-03-20 08:58:18 --> Helper loaded: my_helper
INFO - 2024-03-20 08:58:18 --> Database Driver Class Initialized
INFO - 2024-03-20 08:58:18 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-20 08:58:18 --> Controller Class Initialized
DEBUG - 2024-03-20 08:58:19 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php
INFO - 2024-03-20 08:58:21 --> Config Class Initialized
INFO - 2024-03-20 08:58:21 --> Hooks Class Initialized
DEBUG - 2024-03-20 08:58:21 --> UTF-8 Support Enabled
INFO - 2024-03-20 08:58:21 --> Utf8 Class Initialized
INFO - 2024-03-20 08:58:21 --> URI Class Initialized
INFO - 2024-03-20 08:58:21 --> Router Class Initialized
INFO - 2024-03-20 08:58:21 --> Output Class Initialized
INFO - 2024-03-20 08:58:21 --> Security Class Initialized
DEBUG - 2024-03-20 08:58:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-20 08:58:21 --> Input Class Initialized
INFO - 2024-03-20 08:58:21 --> Language Class Initialized
INFO - 2024-03-20 08:58:21 --> Language Class Initialized
INFO - 2024-03-20 08:58:21 --> Config Class Initialized
INFO - 2024-03-20 08:58:21 --> Loader Class Initialized
INFO - 2024-03-20 08:58:21 --> Helper loaded: url_helper
INFO - 2024-03-20 08:58:21 --> Helper loaded: file_helper
INFO - 2024-03-20 08:58:21 --> Helper loaded: form_helper
INFO - 2024-03-20 08:58:21 --> Helper loaded: my_helper
INFO - 2024-03-20 08:58:21 --> Database Driver Class Initialized
INFO - 2024-03-20 08:58:22 --> Final output sent to browser
DEBUG - 2024-03-20 08:58:22 --> Total execution time: 3.6527
INFO - 2024-03-20 08:58:22 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-20 08:58:22 --> Controller Class Initialized
DEBUG - 2024-03-20 08:58:22 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php
INFO - 2024-03-20 08:58:25 --> Config Class Initialized
INFO - 2024-03-20 08:58:25 --> Hooks Class Initialized
DEBUG - 2024-03-20 08:58:25 --> UTF-8 Support Enabled
INFO - 2024-03-20 08:58:25 --> Utf8 Class Initialized
INFO - 2024-03-20 08:58:25 --> URI Class Initialized
INFO - 2024-03-20 08:58:25 --> Router Class Initialized
INFO - 2024-03-20 08:58:25 --> Output Class Initialized
INFO - 2024-03-20 08:58:25 --> Security Class Initialized
DEBUG - 2024-03-20 08:58:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-20 08:58:25 --> Input Class Initialized
INFO - 2024-03-20 08:58:25 --> Language Class Initialized
INFO - 2024-03-20 08:58:25 --> Language Class Initialized
INFO - 2024-03-20 08:58:25 --> Config Class Initialized
INFO - 2024-03-20 08:58:25 --> Loader Class Initialized
INFO - 2024-03-20 08:58:25 --> Helper loaded: url_helper
INFO - 2024-03-20 08:58:25 --> Helper loaded: file_helper
INFO - 2024-03-20 08:58:25 --> Helper loaded: form_helper
INFO - 2024-03-20 08:58:25 --> Helper loaded: my_helper
INFO - 2024-03-20 08:58:25 --> Database Driver Class Initialized
INFO - 2024-03-20 08:58:26 --> Final output sent to browser
DEBUG - 2024-03-20 08:58:26 --> Total execution time: 5.2946
INFO - 2024-03-20 08:58:26 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-20 08:58:26 --> Controller Class Initialized
DEBUG - 2024-03-20 08:58:27 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php
INFO - 2024-03-20 08:58:30 --> Final output sent to browser
DEBUG - 2024-03-20 08:58:30 --> Total execution time: 5.6307
INFO - 2024-03-20 08:59:09 --> Config Class Initialized
INFO - 2024-03-20 08:59:09 --> Hooks Class Initialized
DEBUG - 2024-03-20 08:59:09 --> UTF-8 Support Enabled
INFO - 2024-03-20 08:59:09 --> Utf8 Class Initialized
INFO - 2024-03-20 08:59:09 --> URI Class Initialized
INFO - 2024-03-20 08:59:09 --> Router Class Initialized
INFO - 2024-03-20 08:59:09 --> Output Class Initialized
INFO - 2024-03-20 08:59:09 --> Security Class Initialized
DEBUG - 2024-03-20 08:59:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-20 08:59:09 --> Input Class Initialized
INFO - 2024-03-20 08:59:09 --> Language Class Initialized
INFO - 2024-03-20 08:59:09 --> Language Class Initialized
INFO - 2024-03-20 08:59:09 --> Config Class Initialized
INFO - 2024-03-20 08:59:09 --> Loader Class Initialized
INFO - 2024-03-20 08:59:09 --> Helper loaded: url_helper
INFO - 2024-03-20 08:59:09 --> Helper loaded: file_helper
INFO - 2024-03-20 08:59:09 --> Helper loaded: form_helper
INFO - 2024-03-20 08:59:09 --> Helper loaded: my_helper
INFO - 2024-03-20 08:59:09 --> Database Driver Class Initialized
INFO - 2024-03-20 08:59:09 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-20 08:59:09 --> Controller Class Initialized
DEBUG - 2024-03-20 08:59:09 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php
INFO - 2024-03-20 08:59:11 --> Config Class Initialized
INFO - 2024-03-20 08:59:11 --> Hooks Class Initialized
DEBUG - 2024-03-20 08:59:11 --> UTF-8 Support Enabled
INFO - 2024-03-20 08:59:11 --> Utf8 Class Initialized
INFO - 2024-03-20 08:59:11 --> URI Class Initialized
INFO - 2024-03-20 08:59:11 --> Router Class Initialized
INFO - 2024-03-20 08:59:11 --> Output Class Initialized
INFO - 2024-03-20 08:59:11 --> Security Class Initialized
DEBUG - 2024-03-20 08:59:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-20 08:59:11 --> Input Class Initialized
INFO - 2024-03-20 08:59:11 --> Language Class Initialized
INFO - 2024-03-20 08:59:11 --> Language Class Initialized
INFO - 2024-03-20 08:59:11 --> Config Class Initialized
INFO - 2024-03-20 08:59:11 --> Loader Class Initialized
INFO - 2024-03-20 08:59:11 --> Helper loaded: url_helper
INFO - 2024-03-20 08:59:11 --> Helper loaded: file_helper
INFO - 2024-03-20 08:59:11 --> Helper loaded: form_helper
INFO - 2024-03-20 08:59:11 --> Helper loaded: my_helper
INFO - 2024-03-20 08:59:11 --> Database Driver Class Initialized
INFO - 2024-03-20 08:59:13 --> Final output sent to browser
DEBUG - 2024-03-20 08:59:13 --> Total execution time: 4.4883
INFO - 2024-03-20 08:59:13 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-20 08:59:13 --> Controller Class Initialized
DEBUG - 2024-03-20 08:59:13 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php
INFO - 2024-03-20 08:59:14 --> Config Class Initialized
INFO - 2024-03-20 08:59:14 --> Hooks Class Initialized
DEBUG - 2024-03-20 08:59:14 --> UTF-8 Support Enabled
INFO - 2024-03-20 08:59:14 --> Utf8 Class Initialized
INFO - 2024-03-20 08:59:14 --> URI Class Initialized
INFO - 2024-03-20 08:59:14 --> Router Class Initialized
INFO - 2024-03-20 08:59:14 --> Output Class Initialized
INFO - 2024-03-20 08:59:14 --> Security Class Initialized
DEBUG - 2024-03-20 08:59:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-20 08:59:14 --> Input Class Initialized
INFO - 2024-03-20 08:59:14 --> Language Class Initialized
INFO - 2024-03-20 08:59:14 --> Language Class Initialized
INFO - 2024-03-20 08:59:14 --> Config Class Initialized
INFO - 2024-03-20 08:59:14 --> Loader Class Initialized
INFO - 2024-03-20 08:59:14 --> Helper loaded: url_helper
INFO - 2024-03-20 08:59:14 --> Helper loaded: file_helper
INFO - 2024-03-20 08:59:14 --> Helper loaded: form_helper
INFO - 2024-03-20 08:59:14 --> Helper loaded: my_helper
INFO - 2024-03-20 08:59:14 --> Database Driver Class Initialized
INFO - 2024-03-20 08:59:16 --> Config Class Initialized
INFO - 2024-03-20 08:59:16 --> Hooks Class Initialized
DEBUG - 2024-03-20 08:59:16 --> UTF-8 Support Enabled
INFO - 2024-03-20 08:59:16 --> Utf8 Class Initialized
INFO - 2024-03-20 08:59:16 --> URI Class Initialized
INFO - 2024-03-20 08:59:16 --> Router Class Initialized
INFO - 2024-03-20 08:59:16 --> Output Class Initialized
INFO - 2024-03-20 08:59:16 --> Security Class Initialized
DEBUG - 2024-03-20 08:59:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-20 08:59:16 --> Input Class Initialized
INFO - 2024-03-20 08:59:16 --> Language Class Initialized
INFO - 2024-03-20 08:59:16 --> Language Class Initialized
INFO - 2024-03-20 08:59:16 --> Config Class Initialized
INFO - 2024-03-20 08:59:16 --> Loader Class Initialized
INFO - 2024-03-20 08:59:16 --> Helper loaded: url_helper
INFO - 2024-03-20 08:59:16 --> Helper loaded: file_helper
INFO - 2024-03-20 08:59:16 --> Helper loaded: form_helper
INFO - 2024-03-20 08:59:16 --> Helper loaded: my_helper
INFO - 2024-03-20 08:59:16 --> Database Driver Class Initialized
INFO - 2024-03-20 08:59:18 --> Final output sent to browser
DEBUG - 2024-03-20 08:59:18 --> Total execution time: 6.8400
INFO - 2024-03-20 08:59:18 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-20 08:59:18 --> Controller Class Initialized
DEBUG - 2024-03-20 08:59:18 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php
INFO - 2024-03-20 08:59:20 --> Config Class Initialized
INFO - 2024-03-20 08:59:20 --> Hooks Class Initialized
DEBUG - 2024-03-20 08:59:20 --> UTF-8 Support Enabled
INFO - 2024-03-20 08:59:20 --> Utf8 Class Initialized
INFO - 2024-03-20 08:59:20 --> URI Class Initialized
INFO - 2024-03-20 08:59:20 --> Router Class Initialized
INFO - 2024-03-20 08:59:20 --> Output Class Initialized
INFO - 2024-03-20 08:59:20 --> Security Class Initialized
DEBUG - 2024-03-20 08:59:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-20 08:59:20 --> Input Class Initialized
INFO - 2024-03-20 08:59:20 --> Language Class Initialized
INFO - 2024-03-20 08:59:20 --> Language Class Initialized
INFO - 2024-03-20 08:59:20 --> Config Class Initialized
INFO - 2024-03-20 08:59:20 --> Loader Class Initialized
INFO - 2024-03-20 08:59:20 --> Helper loaded: url_helper
INFO - 2024-03-20 08:59:20 --> Helper loaded: file_helper
INFO - 2024-03-20 08:59:20 --> Helper loaded: form_helper
INFO - 2024-03-20 08:59:20 --> Helper loaded: my_helper
INFO - 2024-03-20 08:59:20 --> Database Driver Class Initialized
INFO - 2024-03-20 08:59:21 --> Final output sent to browser
DEBUG - 2024-03-20 08:59:21 --> Total execution time: 7.5309
INFO - 2024-03-20 08:59:21 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-20 08:59:21 --> Controller Class Initialized
DEBUG - 2024-03-20 08:59:21 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php
INFO - 2024-03-20 08:59:25 --> Final output sent to browser
DEBUG - 2024-03-20 08:59:25 --> Total execution time: 8.5626
INFO - 2024-03-20 08:59:25 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-20 08:59:25 --> Controller Class Initialized
DEBUG - 2024-03-20 08:59:25 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php
INFO - 2024-03-20 08:59:30 --> Final output sent to browser
DEBUG - 2024-03-20 08:59:30 --> Total execution time: 9.7793
INFO - 2024-03-20 11:35:14 --> Config Class Initialized
INFO - 2024-03-20 11:35:14 --> Hooks Class Initialized
DEBUG - 2024-03-20 11:35:14 --> UTF-8 Support Enabled
INFO - 2024-03-20 11:35:14 --> Utf8 Class Initialized
INFO - 2024-03-20 11:35:14 --> URI Class Initialized
INFO - 2024-03-20 11:35:14 --> Router Class Initialized
INFO - 2024-03-20 11:35:14 --> Output Class Initialized
INFO - 2024-03-20 11:35:14 --> Security Class Initialized
DEBUG - 2024-03-20 11:35:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-20 11:35:14 --> Input Class Initialized
INFO - 2024-03-20 11:35:14 --> Language Class Initialized
INFO - 2024-03-20 11:35:14 --> Language Class Initialized
INFO - 2024-03-20 11:35:14 --> Config Class Initialized
INFO - 2024-03-20 11:35:14 --> Loader Class Initialized
INFO - 2024-03-20 11:35:14 --> Helper loaded: url_helper
INFO - 2024-03-20 11:35:14 --> Helper loaded: file_helper
INFO - 2024-03-20 11:35:14 --> Helper loaded: form_helper
INFO - 2024-03-20 11:35:14 --> Helper loaded: my_helper
INFO - 2024-03-20 11:35:14 --> Database Driver Class Initialized
INFO - 2024-03-20 11:35:14 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-20 11:35:14 --> Controller Class Initialized
INFO - 2024-03-20 11:35:14 --> Helper loaded: cookie_helper
INFO - 2024-03-20 11:35:14 --> Final output sent to browser
DEBUG - 2024-03-20 11:35:14 --> Total execution time: 0.0900
INFO - 2024-03-20 11:35:14 --> Config Class Initialized
INFO - 2024-03-20 11:35:14 --> Hooks Class Initialized
DEBUG - 2024-03-20 11:35:14 --> UTF-8 Support Enabled
INFO - 2024-03-20 11:35:14 --> Utf8 Class Initialized
INFO - 2024-03-20 11:35:14 --> URI Class Initialized
INFO - 2024-03-20 11:35:14 --> Router Class Initialized
INFO - 2024-03-20 11:35:14 --> Output Class Initialized
INFO - 2024-03-20 11:35:14 --> Security Class Initialized
DEBUG - 2024-03-20 11:35:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-20 11:35:14 --> Input Class Initialized
INFO - 2024-03-20 11:35:14 --> Language Class Initialized
INFO - 2024-03-20 11:35:14 --> Language Class Initialized
INFO - 2024-03-20 11:35:14 --> Config Class Initialized
INFO - 2024-03-20 11:35:14 --> Loader Class Initialized
INFO - 2024-03-20 11:35:14 --> Helper loaded: url_helper
INFO - 2024-03-20 11:35:14 --> Helper loaded: file_helper
INFO - 2024-03-20 11:35:14 --> Helper loaded: form_helper
INFO - 2024-03-20 11:35:14 --> Helper loaded: my_helper
INFO - 2024-03-20 11:35:14 --> Database Driver Class Initialized
INFO - 2024-03-20 11:35:14 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-20 11:35:14 --> Controller Class Initialized
INFO - 2024-03-20 11:35:14 --> Helper loaded: cookie_helper
INFO - 2024-03-20 11:35:14 --> Final output sent to browser
DEBUG - 2024-03-20 11:35:14 --> Total execution time: 0.0336
INFO - 2024-03-20 14:39:39 --> Config Class Initialized
INFO - 2024-03-20 14:39:39 --> Hooks Class Initialized
DEBUG - 2024-03-20 14:39:39 --> UTF-8 Support Enabled
INFO - 2024-03-20 14:39:39 --> Utf8 Class Initialized
INFO - 2024-03-20 14:39:39 --> URI Class Initialized
INFO - 2024-03-20 14:39:39 --> Router Class Initialized
INFO - 2024-03-20 14:39:39 --> Output Class Initialized
INFO - 2024-03-20 14:39:39 --> Security Class Initialized
DEBUG - 2024-03-20 14:39:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-20 14:39:39 --> Input Class Initialized
INFO - 2024-03-20 14:39:39 --> Language Class Initialized
INFO - 2024-03-20 14:39:39 --> Language Class Initialized
INFO - 2024-03-20 14:39:39 --> Config Class Initialized
INFO - 2024-03-20 14:39:39 --> Loader Class Initialized
INFO - 2024-03-20 14:39:39 --> Helper loaded: url_helper
INFO - 2024-03-20 14:39:39 --> Helper loaded: file_helper
INFO - 2024-03-20 14:39:39 --> Helper loaded: form_helper
INFO - 2024-03-20 14:39:39 --> Helper loaded: my_helper
INFO - 2024-03-20 14:39:39 --> Database Driver Class Initialized
INFO - 2024-03-20 14:39:39 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-20 14:39:39 --> Controller Class Initialized
DEBUG - 2024-03-20 14:39:39 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/login/views/login.php
DEBUG - 2024-03-20 14:39:39 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-03-20 14:39:39 --> Final output sent to browser
DEBUG - 2024-03-20 14:39:39 --> Total execution time: 0.0569
INFO - 2024-03-20 19:00:32 --> Config Class Initialized
INFO - 2024-03-20 19:00:32 --> Hooks Class Initialized
DEBUG - 2024-03-20 19:00:32 --> UTF-8 Support Enabled
INFO - 2024-03-20 19:00:32 --> Utf8 Class Initialized
INFO - 2024-03-20 19:00:32 --> URI Class Initialized
INFO - 2024-03-20 19:00:32 --> Router Class Initialized
INFO - 2024-03-20 19:00:32 --> Output Class Initialized
INFO - 2024-03-20 19:00:32 --> Security Class Initialized
DEBUG - 2024-03-20 19:00:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-20 19:00:32 --> Input Class Initialized
INFO - 2024-03-20 19:00:32 --> Language Class Initialized
INFO - 2024-03-20 19:00:32 --> Language Class Initialized
INFO - 2024-03-20 19:00:32 --> Config Class Initialized
INFO - 2024-03-20 19:00:32 --> Loader Class Initialized
INFO - 2024-03-20 19:00:32 --> Helper loaded: url_helper
INFO - 2024-03-20 19:00:32 --> Helper loaded: file_helper
INFO - 2024-03-20 19:00:32 --> Helper loaded: form_helper
INFO - 2024-03-20 19:00:32 --> Helper loaded: my_helper
INFO - 2024-03-20 19:00:32 --> Database Driver Class Initialized
INFO - 2024-03-20 19:00:32 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-20 19:00:32 --> Controller Class Initialized
INFO - 2024-03-20 19:00:32 --> Helper loaded: cookie_helper
INFO - 2024-03-20 19:00:32 --> Final output sent to browser
DEBUG - 2024-03-20 19:00:32 --> Total execution time: 0.0455
INFO - 2024-03-20 19:00:33 --> Config Class Initialized
INFO - 2024-03-20 19:00:33 --> Hooks Class Initialized
DEBUG - 2024-03-20 19:00:33 --> UTF-8 Support Enabled
INFO - 2024-03-20 19:00:33 --> Utf8 Class Initialized
INFO - 2024-03-20 19:00:33 --> URI Class Initialized
INFO - 2024-03-20 19:00:33 --> Router Class Initialized
INFO - 2024-03-20 19:00:33 --> Output Class Initialized
INFO - 2024-03-20 19:00:33 --> Security Class Initialized
DEBUG - 2024-03-20 19:00:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-20 19:00:33 --> Input Class Initialized
INFO - 2024-03-20 19:00:33 --> Language Class Initialized
INFO - 2024-03-20 19:00:33 --> Language Class Initialized
INFO - 2024-03-20 19:00:33 --> Config Class Initialized
INFO - 2024-03-20 19:00:33 --> Loader Class Initialized
INFO - 2024-03-20 19:00:33 --> Helper loaded: url_helper
INFO - 2024-03-20 19:00:33 --> Helper loaded: file_helper
INFO - 2024-03-20 19:00:33 --> Helper loaded: form_helper
INFO - 2024-03-20 19:00:33 --> Helper loaded: my_helper
INFO - 2024-03-20 19:00:33 --> Database Driver Class Initialized
INFO - 2024-03-20 19:00:33 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-20 19:00:33 --> Controller Class Initialized
INFO - 2024-03-20 19:00:33 --> Helper loaded: cookie_helper
INFO - 2024-03-20 19:00:33 --> Final output sent to browser
DEBUG - 2024-03-20 19:00:33 --> Total execution time: 0.0531
INFO - 2024-03-20 19:00:50 --> Config Class Initialized
INFO - 2024-03-20 19:00:50 --> Hooks Class Initialized
DEBUG - 2024-03-20 19:00:50 --> UTF-8 Support Enabled
INFO - 2024-03-20 19:00:50 --> Utf8 Class Initialized
INFO - 2024-03-20 19:00:50 --> URI Class Initialized
INFO - 2024-03-20 19:00:50 --> Router Class Initialized
INFO - 2024-03-20 19:00:50 --> Output Class Initialized
INFO - 2024-03-20 19:00:50 --> Security Class Initialized
DEBUG - 2024-03-20 19:00:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-20 19:00:50 --> Input Class Initialized
INFO - 2024-03-20 19:00:50 --> Language Class Initialized
INFO - 2024-03-20 19:00:50 --> Language Class Initialized
INFO - 2024-03-20 19:00:50 --> Config Class Initialized
INFO - 2024-03-20 19:00:50 --> Loader Class Initialized
INFO - 2024-03-20 19:00:50 --> Helper loaded: url_helper
INFO - 2024-03-20 19:00:50 --> Helper loaded: file_helper
INFO - 2024-03-20 19:00:50 --> Helper loaded: form_helper
INFO - 2024-03-20 19:00:50 --> Helper loaded: my_helper
INFO - 2024-03-20 19:00:50 --> Database Driver Class Initialized
INFO - 2024-03-20 19:00:50 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-20 19:00:50 --> Controller Class Initialized
INFO - 2024-03-20 19:00:50 --> Helper loaded: cookie_helper
INFO - 2024-03-20 19:00:50 --> Final output sent to browser
DEBUG - 2024-03-20 19:00:50 --> Total execution time: 0.0339
INFO - 2024-03-20 19:00:50 --> Config Class Initialized
INFO - 2024-03-20 19:00:50 --> Hooks Class Initialized
DEBUG - 2024-03-20 19:00:50 --> UTF-8 Support Enabled
INFO - 2024-03-20 19:00:50 --> Utf8 Class Initialized
INFO - 2024-03-20 19:00:50 --> URI Class Initialized
INFO - 2024-03-20 19:00:50 --> Router Class Initialized
INFO - 2024-03-20 19:00:50 --> Output Class Initialized
INFO - 2024-03-20 19:00:50 --> Security Class Initialized
DEBUG - 2024-03-20 19:00:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-20 19:00:50 --> Input Class Initialized
INFO - 2024-03-20 19:00:50 --> Language Class Initialized
INFO - 2024-03-20 19:00:50 --> Language Class Initialized
INFO - 2024-03-20 19:00:50 --> Config Class Initialized
INFO - 2024-03-20 19:00:50 --> Loader Class Initialized
INFO - 2024-03-20 19:00:50 --> Helper loaded: url_helper
INFO - 2024-03-20 19:00:50 --> Helper loaded: file_helper
INFO - 2024-03-20 19:00:50 --> Helper loaded: form_helper
INFO - 2024-03-20 19:00:50 --> Helper loaded: my_helper
INFO - 2024-03-20 19:00:50 --> Database Driver Class Initialized
INFO - 2024-03-20 19:00:50 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-20 19:00:50 --> Controller Class Initialized
INFO - 2024-03-20 19:00:50 --> Helper loaded: cookie_helper
INFO - 2024-03-20 19:00:50 --> Config Class Initialized
INFO - 2024-03-20 19:00:50 --> Hooks Class Initialized
DEBUG - 2024-03-20 19:00:50 --> UTF-8 Support Enabled
INFO - 2024-03-20 19:00:50 --> Utf8 Class Initialized
INFO - 2024-03-20 19:00:50 --> URI Class Initialized
INFO - 2024-03-20 19:00:50 --> Router Class Initialized
INFO - 2024-03-20 19:00:50 --> Output Class Initialized
INFO - 2024-03-20 19:00:50 --> Security Class Initialized
DEBUG - 2024-03-20 19:00:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-20 19:00:50 --> Input Class Initialized
INFO - 2024-03-20 19:00:50 --> Language Class Initialized
INFO - 2024-03-20 19:00:50 --> Language Class Initialized
INFO - 2024-03-20 19:00:50 --> Config Class Initialized
INFO - 2024-03-20 19:00:50 --> Loader Class Initialized
INFO - 2024-03-20 19:00:50 --> Helper loaded: url_helper
INFO - 2024-03-20 19:00:50 --> Helper loaded: file_helper
INFO - 2024-03-20 19:00:50 --> Helper loaded: form_helper
INFO - 2024-03-20 19:00:50 --> Helper loaded: my_helper
INFO - 2024-03-20 19:00:50 --> Database Driver Class Initialized
INFO - 2024-03-20 19:00:50 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-20 19:00:50 --> Controller Class Initialized
DEBUG - 2024-03-20 19:00:50 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/lihat_raport/views/list.php
DEBUG - 2024-03-20 19:00:50 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-03-20 19:00:50 --> Final output sent to browser
DEBUG - 2024-03-20 19:00:50 --> Total execution time: 0.0359
INFO - 2024-03-20 19:00:51 --> Config Class Initialized
INFO - 2024-03-20 19:00:51 --> Hooks Class Initialized
DEBUG - 2024-03-20 19:00:51 --> UTF-8 Support Enabled
INFO - 2024-03-20 19:00:51 --> Utf8 Class Initialized
INFO - 2024-03-20 19:00:51 --> URI Class Initialized
INFO - 2024-03-20 19:00:51 --> Router Class Initialized
INFO - 2024-03-20 19:00:51 --> Output Class Initialized
INFO - 2024-03-20 19:00:51 --> Security Class Initialized
DEBUG - 2024-03-20 19:00:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-20 19:00:51 --> Input Class Initialized
INFO - 2024-03-20 19:00:51 --> Language Class Initialized
INFO - 2024-03-20 19:00:51 --> Language Class Initialized
INFO - 2024-03-20 19:00:51 --> Config Class Initialized
INFO - 2024-03-20 19:00:51 --> Loader Class Initialized
INFO - 2024-03-20 19:00:51 --> Helper loaded: url_helper
INFO - 2024-03-20 19:00:51 --> Helper loaded: file_helper
INFO - 2024-03-20 19:00:51 --> Helper loaded: form_helper
INFO - 2024-03-20 19:00:51 --> Helper loaded: my_helper
INFO - 2024-03-20 19:00:51 --> Database Driver Class Initialized
INFO - 2024-03-20 19:00:51 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-20 19:00:51 --> Controller Class Initialized
INFO - 2024-03-20 19:00:51 --> Helper loaded: cookie_helper
INFO - 2024-03-20 19:00:51 --> Final output sent to browser
DEBUG - 2024-03-20 19:00:51 --> Total execution time: 0.0318
INFO - 2024-03-20 19:00:51 --> Config Class Initialized
INFO - 2024-03-20 19:00:51 --> Hooks Class Initialized
DEBUG - 2024-03-20 19:00:51 --> UTF-8 Support Enabled
INFO - 2024-03-20 19:00:51 --> Utf8 Class Initialized
INFO - 2024-03-20 19:00:51 --> URI Class Initialized
INFO - 2024-03-20 19:00:51 --> Router Class Initialized
INFO - 2024-03-20 19:00:51 --> Output Class Initialized
INFO - 2024-03-20 19:00:51 --> Security Class Initialized
DEBUG - 2024-03-20 19:00:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-20 19:00:51 --> Input Class Initialized
INFO - 2024-03-20 19:00:51 --> Language Class Initialized
INFO - 2024-03-20 19:00:51 --> Language Class Initialized
INFO - 2024-03-20 19:00:51 --> Config Class Initialized
INFO - 2024-03-20 19:00:51 --> Loader Class Initialized
INFO - 2024-03-20 19:00:51 --> Helper loaded: url_helper
INFO - 2024-03-20 19:00:51 --> Helper loaded: file_helper
INFO - 2024-03-20 19:00:51 --> Helper loaded: form_helper
INFO - 2024-03-20 19:00:51 --> Helper loaded: my_helper
INFO - 2024-03-20 19:00:51 --> Database Driver Class Initialized
INFO - 2024-03-20 19:00:51 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-20 19:00:51 --> Controller Class Initialized
INFO - 2024-03-20 19:00:51 --> Helper loaded: cookie_helper
INFO - 2024-03-20 19:00:51 --> Config Class Initialized
INFO - 2024-03-20 19:00:51 --> Hooks Class Initialized
DEBUG - 2024-03-20 19:00:51 --> UTF-8 Support Enabled
INFO - 2024-03-20 19:00:51 --> Utf8 Class Initialized
INFO - 2024-03-20 19:00:51 --> URI Class Initialized
INFO - 2024-03-20 19:00:51 --> Router Class Initialized
INFO - 2024-03-20 19:00:51 --> Output Class Initialized
INFO - 2024-03-20 19:00:51 --> Security Class Initialized
DEBUG - 2024-03-20 19:00:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-20 19:00:51 --> Input Class Initialized
INFO - 2024-03-20 19:00:51 --> Language Class Initialized
INFO - 2024-03-20 19:00:51 --> Language Class Initialized
INFO - 2024-03-20 19:00:51 --> Config Class Initialized
INFO - 2024-03-20 19:00:51 --> Loader Class Initialized
INFO - 2024-03-20 19:00:51 --> Helper loaded: url_helper
INFO - 2024-03-20 19:00:51 --> Helper loaded: file_helper
INFO - 2024-03-20 19:00:51 --> Helper loaded: form_helper
INFO - 2024-03-20 19:00:51 --> Helper loaded: my_helper
INFO - 2024-03-20 19:00:51 --> Database Driver Class Initialized
INFO - 2024-03-20 19:00:51 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-20 19:00:51 --> Controller Class Initialized
DEBUG - 2024-03-20 19:00:51 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/lihat_raport/views/list.php
DEBUG - 2024-03-20 19:00:51 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-03-20 19:00:51 --> Final output sent to browser
DEBUG - 2024-03-20 19:00:51 --> Total execution time: 0.0291
INFO - 2024-03-20 19:00:53 --> Config Class Initialized
INFO - 2024-03-20 19:00:53 --> Hooks Class Initialized
DEBUG - 2024-03-20 19:00:53 --> UTF-8 Support Enabled
INFO - 2024-03-20 19:00:53 --> Utf8 Class Initialized
INFO - 2024-03-20 19:00:53 --> URI Class Initialized
INFO - 2024-03-20 19:00:53 --> Router Class Initialized
INFO - 2024-03-20 19:00:53 --> Output Class Initialized
INFO - 2024-03-20 19:00:53 --> Security Class Initialized
DEBUG - 2024-03-20 19:00:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-20 19:00:53 --> Input Class Initialized
INFO - 2024-03-20 19:00:53 --> Language Class Initialized
INFO - 2024-03-20 19:00:53 --> Language Class Initialized
INFO - 2024-03-20 19:00:53 --> Config Class Initialized
INFO - 2024-03-20 19:00:53 --> Loader Class Initialized
INFO - 2024-03-20 19:00:53 --> Helper loaded: url_helper
INFO - 2024-03-20 19:00:53 --> Helper loaded: file_helper
INFO - 2024-03-20 19:00:53 --> Helper loaded: form_helper
INFO - 2024-03-20 19:00:53 --> Helper loaded: my_helper
INFO - 2024-03-20 19:00:53 --> Database Driver Class Initialized
INFO - 2024-03-20 19:00:53 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-20 19:00:53 --> Controller Class Initialized
INFO - 2024-03-20 19:00:53 --> Helper loaded: cookie_helper
INFO - 2024-03-20 19:00:53 --> Final output sent to browser
DEBUG - 2024-03-20 19:00:53 --> Total execution time: 0.0276
INFO - 2024-03-20 19:00:53 --> Config Class Initialized
INFO - 2024-03-20 19:00:53 --> Hooks Class Initialized
DEBUG - 2024-03-20 19:00:53 --> UTF-8 Support Enabled
INFO - 2024-03-20 19:00:53 --> Utf8 Class Initialized
INFO - 2024-03-20 19:00:53 --> URI Class Initialized
INFO - 2024-03-20 19:00:53 --> Router Class Initialized
INFO - 2024-03-20 19:00:53 --> Output Class Initialized
INFO - 2024-03-20 19:00:53 --> Security Class Initialized
DEBUG - 2024-03-20 19:00:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-20 19:00:53 --> Input Class Initialized
INFO - 2024-03-20 19:00:53 --> Language Class Initialized
INFO - 2024-03-20 19:00:53 --> Language Class Initialized
INFO - 2024-03-20 19:00:53 --> Config Class Initialized
INFO - 2024-03-20 19:00:53 --> Loader Class Initialized
INFO - 2024-03-20 19:00:53 --> Helper loaded: url_helper
INFO - 2024-03-20 19:00:53 --> Helper loaded: file_helper
INFO - 2024-03-20 19:00:53 --> Helper loaded: form_helper
INFO - 2024-03-20 19:00:53 --> Helper loaded: my_helper
INFO - 2024-03-20 19:00:53 --> Database Driver Class Initialized
INFO - 2024-03-20 19:00:53 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-20 19:00:53 --> Controller Class Initialized
INFO - 2024-03-20 19:00:53 --> Helper loaded: cookie_helper
INFO - 2024-03-20 19:00:53 --> Config Class Initialized
INFO - 2024-03-20 19:00:53 --> Hooks Class Initialized
DEBUG - 2024-03-20 19:00:53 --> UTF-8 Support Enabled
INFO - 2024-03-20 19:00:53 --> Utf8 Class Initialized
INFO - 2024-03-20 19:00:53 --> URI Class Initialized
INFO - 2024-03-20 19:00:53 --> Router Class Initialized
INFO - 2024-03-20 19:00:53 --> Output Class Initialized
INFO - 2024-03-20 19:00:53 --> Security Class Initialized
DEBUG - 2024-03-20 19:00:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-20 19:00:53 --> Input Class Initialized
INFO - 2024-03-20 19:00:53 --> Language Class Initialized
INFO - 2024-03-20 19:00:53 --> Language Class Initialized
INFO - 2024-03-20 19:00:53 --> Config Class Initialized
INFO - 2024-03-20 19:00:53 --> Loader Class Initialized
INFO - 2024-03-20 19:00:53 --> Helper loaded: url_helper
INFO - 2024-03-20 19:00:53 --> Helper loaded: file_helper
INFO - 2024-03-20 19:00:53 --> Helper loaded: form_helper
INFO - 2024-03-20 19:00:53 --> Helper loaded: my_helper
INFO - 2024-03-20 19:00:53 --> Database Driver Class Initialized
INFO - 2024-03-20 19:00:53 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-20 19:00:53 --> Controller Class Initialized
DEBUG - 2024-03-20 19:00:53 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/lihat_raport/views/list.php
DEBUG - 2024-03-20 19:00:53 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-03-20 19:00:53 --> Final output sent to browser
DEBUG - 2024-03-20 19:00:53 --> Total execution time: 0.0304
INFO - 2024-03-20 19:00:58 --> Config Class Initialized
INFO - 2024-03-20 19:00:58 --> Hooks Class Initialized
DEBUG - 2024-03-20 19:00:58 --> UTF-8 Support Enabled
INFO - 2024-03-20 19:00:58 --> Utf8 Class Initialized
INFO - 2024-03-20 19:00:58 --> URI Class Initialized
INFO - 2024-03-20 19:00:58 --> Router Class Initialized
INFO - 2024-03-20 19:00:58 --> Output Class Initialized
INFO - 2024-03-20 19:00:58 --> Security Class Initialized
DEBUG - 2024-03-20 19:00:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-20 19:00:58 --> Input Class Initialized
INFO - 2024-03-20 19:00:58 --> Language Class Initialized
INFO - 2024-03-20 19:00:58 --> Language Class Initialized
INFO - 2024-03-20 19:00:58 --> Config Class Initialized
INFO - 2024-03-20 19:00:58 --> Loader Class Initialized
INFO - 2024-03-20 19:00:58 --> Helper loaded: url_helper
INFO - 2024-03-20 19:00:58 --> Helper loaded: file_helper
INFO - 2024-03-20 19:00:58 --> Helper loaded: form_helper
INFO - 2024-03-20 19:00:58 --> Helper loaded: my_helper
INFO - 2024-03-20 19:00:58 --> Database Driver Class Initialized
INFO - 2024-03-20 19:00:58 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-20 19:00:58 --> Controller Class Initialized
DEBUG - 2024-03-20 19:00:58 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php
INFO - 2024-03-20 19:01:01 --> Final output sent to browser
DEBUG - 2024-03-20 19:01:01 --> Total execution time: 3.6866
