<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2024-01-07 07:45:00 --> Config Class Initialized
INFO - 2024-01-07 07:45:00 --> Hooks Class Initialized
<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2024-01-07 07:45:00 --> Config Class Initialized
INFO - 2024-01-07 07:45:00 --> Hooks Class Initialized
DEBUG - 2024-01-07 07:45:00 --> UTF-8 Support Enabled
INFO - 2024-01-07 07:45:00 --> Utf8 Class Initialized
DEBUG - 2024-01-07 07:45:00 --> UTF-8 Support Enabled
INFO - 2024-01-07 07:45:00 --> Utf8 Class Initialized
INFO - 2024-01-07 07:45:00 --> URI Class Initialized
INFO - 2024-01-07 07:45:00 --> URI Class Initialized
INFO - 2024-01-07 07:45:00 --> Router Class Initialized
INFO - 2024-01-07 07:45:00 --> Output Class Initialized
INFO - 2024-01-07 07:45:00 --> Security Class Initialized
DEBUG - 2024-01-07 07:45:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-01-07 07:45:00 --> Input Class Initialized
INFO - 2024-01-07 07:45:00 --> Language Class Initialized
INFO - 2024-01-07 07:45:00 --> Router Class Initialized
INFO - 2024-01-07 07:45:00 --> Language Class Initialized
INFO - 2024-01-07 07:45:00 --> Config Class Initialized
INFO - 2024-01-07 07:45:00 --> Loader Class Initialized
INFO - 2024-01-07 07:45:00 --> Helper loaded: url_helper
INFO - 2024-01-07 07:45:00 --> Helper loaded: file_helper
INFO - 2024-01-07 07:45:00 --> Helper loaded: form_helper
INFO - 2024-01-07 07:45:00 --> Helper loaded: my_helper
INFO - 2024-01-07 07:45:00 --> Database Driver Class Initialized
INFO - 2024-01-07 07:45:00 --> Output Class Initialized
INFO - 2024-01-07 07:45:00 --> Security Class Initialized
DEBUG - 2024-01-07 07:45:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-01-07 07:45:00 --> Input Class Initialized
INFO - 2024-01-07 07:45:00 --> Session: Class initialized using 'files' driver.
INFO - 2024-01-07 07:45:00 --> Controller Class Initialized
INFO - 2024-01-07 07:45:00 --> Language Class Initialized
INFO - 2024-01-07 07:45:00 --> Language Class Initialized
INFO - 2024-01-07 07:45:00 --> Config Class Initialized
INFO - 2024-01-07 07:45:00 --> Loader Class Initialized
INFO - 2024-01-07 07:45:00 --> Helper loaded: url_helper
INFO - 2024-01-07 07:45:00 --> Helper loaded: file_helper
INFO - 2024-01-07 07:45:00 --> Helper loaded: form_helper
INFO - 2024-01-07 07:45:00 --> Helper loaded: cookie_helper
INFO - 2024-01-07 07:45:00 --> Final output sent to browser
DEBUG - 2024-01-07 07:45:00 --> Total execution time: 0.2294
INFO - 2024-01-07 07:45:00 --> Helper loaded: my_helper
INFO - 2024-01-07 07:45:00 --> Database Driver Class Initialized
INFO - 2024-01-07 07:45:00 --> Session: Class initialized using 'files' driver.
INFO - 2024-01-07 07:45:00 --> Controller Class Initialized
INFO - 2024-01-07 07:45:00 --> Helper loaded: cookie_helper
INFO - 2024-01-07 07:45:00 --> Final output sent to browser
DEBUG - 2024-01-07 07:45:00 --> Total execution time: 0.2858
INFO - 2024-01-07 07:45:00 --> Config Class Initialized
INFO - 2024-01-07 07:45:00 --> Hooks Class Initialized
INFO - 2024-01-07 07:45:00 --> Config Class Initialized
INFO - 2024-01-07 07:45:00 --> Hooks Class Initialized
DEBUG - 2024-01-07 07:45:00 --> UTF-8 Support Enabled
INFO - 2024-01-07 07:45:00 --> Utf8 Class Initialized
INFO - 2024-01-07 07:45:00 --> URI Class Initialized
INFO - 2024-01-07 07:45:00 --> Router Class Initialized
INFO - 2024-01-07 07:45:00 --> Output Class Initialized
INFO - 2024-01-07 07:45:00 --> Security Class Initialized
DEBUG - 2024-01-07 07:45:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-01-07 07:45:00 --> Input Class Initialized
INFO - 2024-01-07 07:45:00 --> Language Class Initialized
INFO - 2024-01-07 07:45:00 --> Language Class Initialized
INFO - 2024-01-07 07:45:00 --> Config Class Initialized
INFO - 2024-01-07 07:45:00 --> Loader Class Initialized
DEBUG - 2024-01-07 07:45:00 --> UTF-8 Support Enabled
INFO - 2024-01-07 07:45:00 --> Utf8 Class Initialized
INFO - 2024-01-07 07:45:00 --> Helper loaded: url_helper
INFO - 2024-01-07 07:45:00 --> Helper loaded: file_helper
INFO - 2024-01-07 07:45:00 --> Helper loaded: form_helper
INFO - 2024-01-07 07:45:00 --> Helper loaded: my_helper
INFO - 2024-01-07 07:45:00 --> Database Driver Class Initialized
INFO - 2024-01-07 07:45:00 --> URI Class Initialized
INFO - 2024-01-07 07:45:00 --> Router Class Initialized
INFO - 2024-01-07 07:45:00 --> Output Class Initialized
INFO - 2024-01-07 07:45:00 --> Security Class Initialized
INFO - 2024-01-07 07:45:00 --> Session: Class initialized using 'files' driver.
INFO - 2024-01-07 07:45:00 --> Controller Class Initialized
DEBUG - 2024-01-07 07:45:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-01-07 07:45:00 --> Input Class Initialized
INFO - 2024-01-07 07:45:00 --> Helper loaded: cookie_helper
INFO - 2024-01-07 07:45:00 --> Language Class Initialized
INFO - 2024-01-07 07:45:00 --> Language Class Initialized
INFO - 2024-01-07 07:45:00 --> Config Class Initialized
INFO - 2024-01-07 07:45:00 --> Loader Class Initialized
INFO - 2024-01-07 07:45:00 --> Helper loaded: url_helper
INFO - 2024-01-07 07:45:00 --> Helper loaded: file_helper
INFO - 2024-01-07 07:45:00 --> Helper loaded: form_helper
INFO - 2024-01-07 07:45:00 --> Helper loaded: my_helper
INFO - 2024-01-07 07:45:00 --> Database Driver Class Initialized
INFO - 2024-01-07 07:45:01 --> Session: Class initialized using 'files' driver.
INFO - 2024-01-07 07:45:01 --> Controller Class Initialized
INFO - 2024-01-07 07:45:01 --> Helper loaded: cookie_helper
INFO - 2024-01-07 07:45:01 --> Config Class Initialized
INFO - 2024-01-07 07:45:01 --> Hooks Class Initialized
INFO - 2024-01-07 07:45:01 --> Config Class Initialized
INFO - 2024-01-07 07:45:01 --> Hooks Class Initialized
DEBUG - 2024-01-07 07:45:01 --> UTF-8 Support Enabled
INFO - 2024-01-07 07:45:01 --> Utf8 Class Initialized
DEBUG - 2024-01-07 07:45:01 --> UTF-8 Support Enabled
INFO - 2024-01-07 07:45:01 --> Utf8 Class Initialized
INFO - 2024-01-07 07:45:01 --> URI Class Initialized
INFO - 2024-01-07 07:45:01 --> Router Class Initialized
INFO - 2024-01-07 07:45:01 --> Output Class Initialized
INFO - 2024-01-07 07:45:01 --> Security Class Initialized
INFO - 2024-01-07 07:45:01 --> URI Class Initialized
DEBUG - 2024-01-07 07:45:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-01-07 07:45:01 --> Input Class Initialized
INFO - 2024-01-07 07:45:01 --> Language Class Initialized
INFO - 2024-01-07 07:45:01 --> Language Class Initialized
INFO - 2024-01-07 07:45:01 --> Config Class Initialized
INFO - 2024-01-07 07:45:01 --> Loader Class Initialized
INFO - 2024-01-07 07:45:01 --> Helper loaded: url_helper
INFO - 2024-01-07 07:45:01 --> Helper loaded: file_helper
INFO - 2024-01-07 07:45:01 --> Helper loaded: form_helper
INFO - 2024-01-07 07:45:01 --> Helper loaded: my_helper
INFO - 2024-01-07 07:45:01 --> Router Class Initialized
INFO - 2024-01-07 07:45:01 --> Database Driver Class Initialized
INFO - 2024-01-07 07:45:01 --> Output Class Initialized
INFO - 2024-01-07 07:45:01 --> Session: Class initialized using 'files' driver.
INFO - 2024-01-07 07:45:01 --> Controller Class Initialized
INFO - 2024-01-07 07:45:01 --> Security Class Initialized
DEBUG - 2024-01-07 07:45:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-01-07 07:45:01 --> Input Class Initialized
INFO - 2024-01-07 07:45:01 --> Language Class Initialized
INFO - 2024-01-07 07:45:01 --> Language Class Initialized
INFO - 2024-01-07 07:45:01 --> Config Class Initialized
INFO - 2024-01-07 07:45:01 --> Loader Class Initialized
DEBUG - 2024-01-07 07:45:01 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/lihat_raport/views/list.php
DEBUG - 2024-01-07 07:45:01 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-01-07 07:45:01 --> Final output sent to browser
DEBUG - 2024-01-07 07:45:01 --> Total execution time: 0.3340
INFO - 2024-01-07 07:45:01 --> Helper loaded: url_helper
INFO - 2024-01-07 07:45:01 --> Helper loaded: file_helper
INFO - 2024-01-07 07:45:01 --> Helper loaded: form_helper
INFO - 2024-01-07 07:45:01 --> Helper loaded: my_helper
INFO - 2024-01-07 07:45:02 --> Database Driver Class Initialized
INFO - 2024-01-07 07:45:02 --> Session: Class initialized using 'files' driver.
INFO - 2024-01-07 07:45:02 --> Controller Class Initialized
DEBUG - 2024-01-07 07:45:02 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/lihat_raport/views/list.php
DEBUG - 2024-01-07 07:45:02 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-01-07 07:45:02 --> Final output sent to browser
DEBUG - 2024-01-07 07:45:02 --> Total execution time: 1.0094
INFO - 2024-01-07 12:05:12 --> Config Class Initialized
INFO - 2024-01-07 12:05:12 --> Hooks Class Initialized
DEBUG - 2024-01-07 12:05:12 --> UTF-8 Support Enabled
INFO - 2024-01-07 12:05:12 --> Utf8 Class Initialized
INFO - 2024-01-07 12:05:12 --> URI Class Initialized
INFO - 2024-01-07 12:05:12 --> Router Class Initialized
INFO - 2024-01-07 12:05:12 --> Output Class Initialized
INFO - 2024-01-07 12:05:12 --> Security Class Initialized
DEBUG - 2024-01-07 12:05:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-01-07 12:05:12 --> Input Class Initialized
INFO - 2024-01-07 12:05:12 --> Language Class Initialized
INFO - 2024-01-07 12:05:12 --> Language Class Initialized
INFO - 2024-01-07 12:05:12 --> Config Class Initialized
INFO - 2024-01-07 12:05:12 --> Loader Class Initialized
INFO - 2024-01-07 12:05:12 --> Helper loaded: url_helper
INFO - 2024-01-07 12:05:12 --> Helper loaded: file_helper
INFO - 2024-01-07 12:05:12 --> Helper loaded: form_helper
INFO - 2024-01-07 12:05:12 --> Helper loaded: my_helper
INFO - 2024-01-07 12:05:12 --> Database Driver Class Initialized
INFO - 2024-01-07 12:05:12 --> Session: Class initialized using 'files' driver.
INFO - 2024-01-07 12:05:12 --> Controller Class Initialized
DEBUG - 2024-01-07 12:05:12 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/login/views/login.php
DEBUG - 2024-01-07 12:05:12 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-01-07 12:05:12 --> Final output sent to browser
DEBUG - 2024-01-07 12:05:12 --> Total execution time: 0.0616
INFO - 2024-01-07 16:55:29 --> Config Class Initialized
INFO - 2024-01-07 16:55:29 --> Hooks Class Initialized
DEBUG - 2024-01-07 16:55:29 --> UTF-8 Support Enabled
INFO - 2024-01-07 16:55:29 --> Utf8 Class Initialized
INFO - 2024-01-07 16:55:29 --> URI Class Initialized
INFO - 2024-01-07 16:55:29 --> Router Class Initialized
INFO - 2024-01-07 16:55:29 --> Output Class Initialized
INFO - 2024-01-07 16:55:29 --> Security Class Initialized
DEBUG - 2024-01-07 16:55:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-01-07 16:55:29 --> Input Class Initialized
INFO - 2024-01-07 16:55:29 --> Language Class Initialized
INFO - 2024-01-07 16:55:29 --> Language Class Initialized
INFO - 2024-01-07 16:55:29 --> Config Class Initialized
INFO - 2024-01-07 16:55:29 --> Loader Class Initialized
INFO - 2024-01-07 16:55:29 --> Helper loaded: url_helper
INFO - 2024-01-07 16:55:29 --> Helper loaded: file_helper
INFO - 2024-01-07 16:55:29 --> Helper loaded: form_helper
INFO - 2024-01-07 16:55:29 --> Helper loaded: my_helper
INFO - 2024-01-07 16:55:29 --> Database Driver Class Initialized
INFO - 2024-01-07 16:55:29 --> Session: Class initialized using 'files' driver.
INFO - 2024-01-07 16:55:29 --> Controller Class Initialized
INFO - 2024-01-07 16:55:29 --> Helper loaded: cookie_helper
INFO - 2024-01-07 16:55:29 --> Final output sent to browser
DEBUG - 2024-01-07 16:55:29 --> Total execution time: 0.0879
INFO - 2024-01-07 16:55:29 --> Config Class Initialized
INFO - 2024-01-07 16:55:29 --> Hooks Class Initialized
DEBUG - 2024-01-07 16:55:29 --> UTF-8 Support Enabled
INFO - 2024-01-07 16:55:29 --> Utf8 Class Initialized
INFO - 2024-01-07 16:55:29 --> URI Class Initialized
INFO - 2024-01-07 16:55:29 --> Router Class Initialized
INFO - 2024-01-07 16:55:29 --> Output Class Initialized
INFO - 2024-01-07 16:55:29 --> Security Class Initialized
DEBUG - 2024-01-07 16:55:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-01-07 16:55:29 --> Input Class Initialized
INFO - 2024-01-07 16:55:29 --> Language Class Initialized
INFO - 2024-01-07 16:55:29 --> Language Class Initialized
INFO - 2024-01-07 16:55:29 --> Config Class Initialized
INFO - 2024-01-07 16:55:29 --> Loader Class Initialized
INFO - 2024-01-07 16:55:29 --> Helper loaded: url_helper
INFO - 2024-01-07 16:55:29 --> Helper loaded: file_helper
INFO - 2024-01-07 16:55:29 --> Helper loaded: form_helper
INFO - 2024-01-07 16:55:29 --> Helper loaded: my_helper
INFO - 2024-01-07 16:55:29 --> Database Driver Class Initialized
INFO - 2024-01-07 16:55:29 --> Session: Class initialized using 'files' driver.
INFO - 2024-01-07 16:55:29 --> Controller Class Initialized
INFO - 2024-01-07 16:55:30 --> Helper loaded: cookie_helper
INFO - 2024-01-07 16:55:30 --> Config Class Initialized
INFO - 2024-01-07 16:55:30 --> Hooks Class Initialized
DEBUG - 2024-01-07 16:55:30 --> UTF-8 Support Enabled
INFO - 2024-01-07 16:55:30 --> Utf8 Class Initialized
INFO - 2024-01-07 16:55:30 --> URI Class Initialized
INFO - 2024-01-07 16:55:30 --> Router Class Initialized
INFO - 2024-01-07 16:55:30 --> Output Class Initialized
INFO - 2024-01-07 16:55:30 --> Security Class Initialized
DEBUG - 2024-01-07 16:55:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-01-07 16:55:30 --> Input Class Initialized
INFO - 2024-01-07 16:55:30 --> Language Class Initialized
INFO - 2024-01-07 16:55:30 --> Language Class Initialized
INFO - 2024-01-07 16:55:30 --> Config Class Initialized
INFO - 2024-01-07 16:55:30 --> Loader Class Initialized
INFO - 2024-01-07 16:55:30 --> Helper loaded: url_helper
INFO - 2024-01-07 16:55:30 --> Helper loaded: file_helper
INFO - 2024-01-07 16:55:30 --> Helper loaded: form_helper
INFO - 2024-01-07 16:55:30 --> Helper loaded: my_helper
INFO - 2024-01-07 16:55:30 --> Database Driver Class Initialized
INFO - 2024-01-07 16:55:30 --> Session: Class initialized using 'files' driver.
INFO - 2024-01-07 16:55:30 --> Controller Class Initialized
DEBUG - 2024-01-07 16:55:30 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/lihat_raport/views/list.php
DEBUG - 2024-01-07 16:55:30 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-01-07 16:55:30 --> Final output sent to browser
DEBUG - 2024-01-07 16:55:30 --> Total execution time: 0.0443
INFO - 2024-01-07 16:55:37 --> Config Class Initialized
INFO - 2024-01-07 16:55:37 --> Hooks Class Initialized
DEBUG - 2024-01-07 16:55:37 --> UTF-8 Support Enabled
INFO - 2024-01-07 16:55:37 --> Utf8 Class Initialized
INFO - 2024-01-07 16:55:37 --> URI Class Initialized
INFO - 2024-01-07 16:55:37 --> Router Class Initialized
INFO - 2024-01-07 16:55:37 --> Output Class Initialized
INFO - 2024-01-07 16:55:37 --> Security Class Initialized
DEBUG - 2024-01-07 16:55:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-01-07 16:55:37 --> Input Class Initialized
INFO - 2024-01-07 16:55:37 --> Language Class Initialized
INFO - 2024-01-07 16:55:37 --> Language Class Initialized
INFO - 2024-01-07 16:55:37 --> Config Class Initialized
INFO - 2024-01-07 16:55:37 --> Loader Class Initialized
INFO - 2024-01-07 16:55:37 --> Helper loaded: url_helper
INFO - 2024-01-07 16:55:37 --> Helper loaded: file_helper
INFO - 2024-01-07 16:55:37 --> Helper loaded: form_helper
INFO - 2024-01-07 16:55:37 --> Helper loaded: my_helper
INFO - 2024-01-07 16:55:37 --> Database Driver Class Initialized
INFO - 2024-01-07 16:55:37 --> Session: Class initialized using 'files' driver.
INFO - 2024-01-07 16:55:37 --> Controller Class Initialized
ERROR - 2024-01-07 16:55:37 --> Severity: Notice --> Undefined index: projek /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1837
ERROR - 2024-01-07 16:55:37 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2024-01-07 16:55:37 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2024-01-07 16:55:37 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2024-01-07 16:55:37 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2024-01-07 16:55:37 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2024-01-07 16:55:37 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2024-01-07 16:55:37 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2024-01-07 16:55:37 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2024-01-07 16:55:37 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2024-01-07 16:55:37 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2024-01-07 16:55:37 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2024-01-07 16:55:37 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2024-01-07 16:55:37 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2024-01-07 16:55:37 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2024-01-07 16:55:37 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2024-01-07 16:55:37 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2024-01-07 16:55:37 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2024-01-07 16:55:37 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2024-01-07 16:55:37 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2024-01-07 16:55:37 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2024-01-07 16:55:37 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2024-01-07 16:55:37 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2024-01-07 16:55:37 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
DEBUG - 2024-01-07 16:55:37 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/views/cetak_projek.php
