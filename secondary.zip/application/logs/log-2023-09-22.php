<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2023-09-22 12:11:54 --> Config Class Initialized
INFO - 2023-09-22 12:11:54 --> Hooks Class Initialized
DEBUG - 2023-09-22 12:11:54 --> UTF-8 Support Enabled
INFO - 2023-09-22 12:11:54 --> Utf8 Class Initialized
INFO - 2023-09-22 12:11:54 --> URI Class Initialized
INFO - 2023-09-22 12:11:54 --> Router Class Initialized
INFO - 2023-09-22 12:11:54 --> Output Class Initialized
INFO - 2023-09-22 12:11:54 --> Security Class Initialized
DEBUG - 2023-09-22 12:11:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-22 12:11:54 --> Input Class Initialized
INFO - 2023-09-22 12:11:54 --> Language Class Initialized
INFO - 2023-09-22 12:11:54 --> Language Class Initialized
INFO - 2023-09-22 12:11:54 --> Config Class Initialized
INFO - 2023-09-22 12:11:54 --> Loader Class Initialized
INFO - 2023-09-22 12:11:54 --> Helper loaded: url_helper
INFO - 2023-09-22 12:11:54 --> Helper loaded: file_helper
INFO - 2023-09-22 12:11:54 --> Helper loaded: form_helper
INFO - 2023-09-22 12:11:54 --> Helper loaded: my_helper
INFO - 2023-09-22 12:11:54 --> Database Driver Class Initialized
INFO - 2023-09-22 12:11:54 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-22 12:11:54 --> Controller Class Initialized
DEBUG - 2023-09-22 12:11:54 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/login/views/login.php
DEBUG - 2023-09-22 12:11:54 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-09-22 12:11:54 --> Final output sent to browser
DEBUG - 2023-09-22 12:11:54 --> Total execution time: 0.0563
INFO - 2023-09-22 12:11:57 --> Config Class Initialized
INFO - 2023-09-22 12:11:57 --> Hooks Class Initialized
DEBUG - 2023-09-22 12:11:57 --> UTF-8 Support Enabled
INFO - 2023-09-22 12:11:57 --> Utf8 Class Initialized
INFO - 2023-09-22 12:11:57 --> URI Class Initialized
INFO - 2023-09-22 12:11:57 --> Router Class Initialized
INFO - 2023-09-22 12:11:57 --> Output Class Initialized
INFO - 2023-09-22 12:11:57 --> Security Class Initialized
DEBUG - 2023-09-22 12:11:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-22 12:11:57 --> Input Class Initialized
INFO - 2023-09-22 12:11:57 --> Language Class Initialized
INFO - 2023-09-22 12:11:57 --> Language Class Initialized
INFO - 2023-09-22 12:11:57 --> Config Class Initialized
INFO - 2023-09-22 12:11:57 --> Loader Class Initialized
INFO - 2023-09-22 12:11:57 --> Helper loaded: url_helper
INFO - 2023-09-22 12:11:57 --> Helper loaded: file_helper
INFO - 2023-09-22 12:11:57 --> Helper loaded: form_helper
INFO - 2023-09-22 12:11:57 --> Helper loaded: my_helper
INFO - 2023-09-22 12:11:57 --> Database Driver Class Initialized
INFO - 2023-09-22 12:11:57 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-22 12:11:57 --> Controller Class Initialized
INFO - 2023-09-22 12:11:57 --> Helper loaded: cookie_helper
INFO - 2023-09-22 12:11:57 --> Final output sent to browser
DEBUG - 2023-09-22 12:11:57 --> Total execution time: 0.0684
INFO - 2023-09-22 12:11:57 --> Config Class Initialized
INFO - 2023-09-22 12:11:57 --> Hooks Class Initialized
DEBUG - 2023-09-22 12:11:57 --> UTF-8 Support Enabled
INFO - 2023-09-22 12:11:57 --> Utf8 Class Initialized
INFO - 2023-09-22 12:11:57 --> URI Class Initialized
INFO - 2023-09-22 12:11:57 --> Router Class Initialized
INFO - 2023-09-22 12:11:57 --> Output Class Initialized
INFO - 2023-09-22 12:11:57 --> Security Class Initialized
DEBUG - 2023-09-22 12:11:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-22 12:11:57 --> Input Class Initialized
INFO - 2023-09-22 12:11:57 --> Language Class Initialized
INFO - 2023-09-22 12:11:57 --> Language Class Initialized
INFO - 2023-09-22 12:11:57 --> Config Class Initialized
INFO - 2023-09-22 12:11:57 --> Loader Class Initialized
INFO - 2023-09-22 12:11:57 --> Helper loaded: url_helper
INFO - 2023-09-22 12:11:57 --> Helper loaded: file_helper
INFO - 2023-09-22 12:11:57 --> Helper loaded: form_helper
INFO - 2023-09-22 12:11:57 --> Helper loaded: my_helper
INFO - 2023-09-22 12:11:57 --> Database Driver Class Initialized
INFO - 2023-09-22 12:11:57 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-22 12:11:57 --> Controller Class Initialized
DEBUG - 2023-09-22 12:11:57 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/home/views/v_home_guru.php
DEBUG - 2023-09-22 12:11:57 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-09-22 12:11:57 --> Final output sent to browser
DEBUG - 2023-09-22 12:11:57 --> Total execution time: 0.0553
INFO - 2023-09-22 12:12:02 --> Config Class Initialized
INFO - 2023-09-22 12:12:02 --> Hooks Class Initialized
DEBUG - 2023-09-22 12:12:02 --> UTF-8 Support Enabled
INFO - 2023-09-22 12:12:02 --> Utf8 Class Initialized
INFO - 2023-09-22 12:12:02 --> URI Class Initialized
INFO - 2023-09-22 12:12:02 --> Router Class Initialized
INFO - 2023-09-22 12:12:02 --> Output Class Initialized
INFO - 2023-09-22 12:12:02 --> Security Class Initialized
DEBUG - 2023-09-22 12:12:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-22 12:12:02 --> Input Class Initialized
INFO - 2023-09-22 12:12:02 --> Language Class Initialized
INFO - 2023-09-22 12:12:02 --> Language Class Initialized
INFO - 2023-09-22 12:12:02 --> Config Class Initialized
INFO - 2023-09-22 12:12:02 --> Loader Class Initialized
INFO - 2023-09-22 12:12:02 --> Helper loaded: url_helper
INFO - 2023-09-22 12:12:02 --> Helper loaded: file_helper
INFO - 2023-09-22 12:12:02 --> Helper loaded: form_helper
INFO - 2023-09-22 12:12:02 --> Helper loaded: my_helper
INFO - 2023-09-22 12:12:02 --> Database Driver Class Initialized
INFO - 2023-09-22 12:12:02 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-22 12:12:02 --> Controller Class Initialized
DEBUG - 2023-09-22 12:12:02 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/view_mapel/views/v_view_mapel.php
DEBUG - 2023-09-22 12:12:02 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-09-22 12:12:02 --> Final output sent to browser
DEBUG - 2023-09-22 12:12:02 --> Total execution time: 0.0493
INFO - 2023-09-22 12:12:05 --> Config Class Initialized
INFO - 2023-09-22 12:12:05 --> Hooks Class Initialized
DEBUG - 2023-09-22 12:12:05 --> UTF-8 Support Enabled
INFO - 2023-09-22 12:12:05 --> Utf8 Class Initialized
INFO - 2023-09-22 12:12:05 --> URI Class Initialized
INFO - 2023-09-22 12:12:05 --> Router Class Initialized
INFO - 2023-09-22 12:12:05 --> Output Class Initialized
INFO - 2023-09-22 12:12:05 --> Security Class Initialized
DEBUG - 2023-09-22 12:12:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-22 12:12:05 --> Input Class Initialized
INFO - 2023-09-22 12:12:05 --> Language Class Initialized
INFO - 2023-09-22 12:12:05 --> Language Class Initialized
INFO - 2023-09-22 12:12:05 --> Config Class Initialized
INFO - 2023-09-22 12:12:05 --> Loader Class Initialized
INFO - 2023-09-22 12:12:05 --> Helper loaded: url_helper
INFO - 2023-09-22 12:12:05 --> Helper loaded: file_helper
INFO - 2023-09-22 12:12:05 --> Helper loaded: form_helper
INFO - 2023-09-22 12:12:05 --> Helper loaded: my_helper
INFO - 2023-09-22 12:12:05 --> Database Driver Class Initialized
INFO - 2023-09-22 12:12:05 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-22 12:12:05 --> Controller Class Initialized
DEBUG - 2023-09-22 12:12:05 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/views/list.php
DEBUG - 2023-09-22 12:12:05 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-09-22 12:12:05 --> Final output sent to browser
DEBUG - 2023-09-22 12:12:05 --> Total execution time: 0.1876
INFO - 2023-09-22 12:12:05 --> Config Class Initialized
INFO - 2023-09-22 12:12:05 --> Hooks Class Initialized
DEBUG - 2023-09-22 12:12:05 --> UTF-8 Support Enabled
INFO - 2023-09-22 12:12:05 --> Utf8 Class Initialized
INFO - 2023-09-22 12:12:05 --> URI Class Initialized
INFO - 2023-09-22 12:12:05 --> Router Class Initialized
INFO - 2023-09-22 12:12:05 --> Output Class Initialized
INFO - 2023-09-22 12:12:05 --> Security Class Initialized
DEBUG - 2023-09-22 12:12:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-22 12:12:06 --> Input Class Initialized
INFO - 2023-09-22 12:12:06 --> Language Class Initialized
INFO - 2023-09-22 12:12:06 --> Language Class Initialized
INFO - 2023-09-22 12:12:06 --> Config Class Initialized
INFO - 2023-09-22 12:12:06 --> Loader Class Initialized
INFO - 2023-09-22 12:12:06 --> Helper loaded: url_helper
INFO - 2023-09-22 12:12:06 --> Helper loaded: file_helper
INFO - 2023-09-22 12:12:06 --> Helper loaded: form_helper
INFO - 2023-09-22 12:12:06 --> Helper loaded: my_helper
INFO - 2023-09-22 12:12:06 --> Database Driver Class Initialized
INFO - 2023-09-22 12:12:06 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-22 12:12:06 --> Controller Class Initialized
INFO - 2023-09-22 12:12:17 --> Config Class Initialized
INFO - 2023-09-22 12:12:17 --> Hooks Class Initialized
DEBUG - 2023-09-22 12:12:17 --> UTF-8 Support Enabled
INFO - 2023-09-22 12:12:17 --> Utf8 Class Initialized
INFO - 2023-09-22 12:12:17 --> URI Class Initialized
INFO - 2023-09-22 12:12:17 --> Router Class Initialized
INFO - 2023-09-22 12:12:17 --> Output Class Initialized
INFO - 2023-09-22 12:12:17 --> Security Class Initialized
DEBUG - 2023-09-22 12:12:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-22 12:12:17 --> Input Class Initialized
INFO - 2023-09-22 12:12:17 --> Language Class Initialized
INFO - 2023-09-22 12:12:17 --> Language Class Initialized
INFO - 2023-09-22 12:12:17 --> Config Class Initialized
INFO - 2023-09-22 12:12:17 --> Loader Class Initialized
INFO - 2023-09-22 12:12:17 --> Helper loaded: url_helper
INFO - 2023-09-22 12:12:17 --> Helper loaded: file_helper
INFO - 2023-09-22 12:12:17 --> Helper loaded: form_helper
INFO - 2023-09-22 12:12:17 --> Helper loaded: my_helper
INFO - 2023-09-22 12:12:17 --> Database Driver Class Initialized
INFO - 2023-09-22 12:12:17 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-22 12:12:17 --> Controller Class Initialized
INFO - 2023-09-22 12:12:20 --> Config Class Initialized
INFO - 2023-09-22 12:12:20 --> Hooks Class Initialized
DEBUG - 2023-09-22 12:12:20 --> UTF-8 Support Enabled
INFO - 2023-09-22 12:12:20 --> Utf8 Class Initialized
INFO - 2023-09-22 12:12:20 --> URI Class Initialized
INFO - 2023-09-22 12:12:20 --> Router Class Initialized
INFO - 2023-09-22 12:12:20 --> Output Class Initialized
INFO - 2023-09-22 12:12:20 --> Security Class Initialized
DEBUG - 2023-09-22 12:12:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-22 12:12:20 --> Input Class Initialized
INFO - 2023-09-22 12:12:20 --> Language Class Initialized
INFO - 2023-09-22 12:12:20 --> Language Class Initialized
INFO - 2023-09-22 12:12:20 --> Config Class Initialized
INFO - 2023-09-22 12:12:20 --> Loader Class Initialized
INFO - 2023-09-22 12:12:20 --> Helper loaded: url_helper
INFO - 2023-09-22 12:12:20 --> Helper loaded: file_helper
INFO - 2023-09-22 12:12:20 --> Helper loaded: form_helper
INFO - 2023-09-22 12:12:20 --> Helper loaded: my_helper
INFO - 2023-09-22 12:12:20 --> Database Driver Class Initialized
INFO - 2023-09-22 12:12:20 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-22 12:12:20 --> Controller Class Initialized
DEBUG - 2023-09-22 12:12:20 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/views/list.php
DEBUG - 2023-09-22 12:12:20 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-09-22 12:12:20 --> Final output sent to browser
DEBUG - 2023-09-22 12:12:20 --> Total execution time: 0.0364
INFO - 2023-09-22 12:12:20 --> Config Class Initialized
INFO - 2023-09-22 12:12:20 --> Hooks Class Initialized
DEBUG - 2023-09-22 12:12:20 --> UTF-8 Support Enabled
INFO - 2023-09-22 12:12:20 --> Utf8 Class Initialized
INFO - 2023-09-22 12:12:20 --> URI Class Initialized
INFO - 2023-09-22 12:12:20 --> Router Class Initialized
INFO - 2023-09-22 12:12:20 --> Output Class Initialized
INFO - 2023-09-22 12:12:20 --> Security Class Initialized
DEBUG - 2023-09-22 12:12:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-22 12:12:20 --> Input Class Initialized
INFO - 2023-09-22 12:12:20 --> Language Class Initialized
INFO - 2023-09-22 12:12:20 --> Language Class Initialized
INFO - 2023-09-22 12:12:20 --> Config Class Initialized
INFO - 2023-09-22 12:12:20 --> Loader Class Initialized
INFO - 2023-09-22 12:12:20 --> Helper loaded: url_helper
INFO - 2023-09-22 12:12:20 --> Helper loaded: file_helper
INFO - 2023-09-22 12:12:20 --> Helper loaded: form_helper
INFO - 2023-09-22 12:12:20 --> Helper loaded: my_helper
INFO - 2023-09-22 12:12:20 --> Database Driver Class Initialized
INFO - 2023-09-22 12:12:20 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-22 12:12:20 --> Controller Class Initialized
INFO - 2023-09-22 12:12:23 --> Config Class Initialized
INFO - 2023-09-22 12:12:23 --> Hooks Class Initialized
DEBUG - 2023-09-22 12:12:23 --> UTF-8 Support Enabled
INFO - 2023-09-22 12:12:23 --> Utf8 Class Initialized
INFO - 2023-09-22 12:12:23 --> URI Class Initialized
INFO - 2023-09-22 12:12:23 --> Router Class Initialized
INFO - 2023-09-22 12:12:23 --> Output Class Initialized
INFO - 2023-09-22 12:12:23 --> Security Class Initialized
DEBUG - 2023-09-22 12:12:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-22 12:12:23 --> Input Class Initialized
INFO - 2023-09-22 12:12:23 --> Language Class Initialized
INFO - 2023-09-22 12:12:23 --> Language Class Initialized
INFO - 2023-09-22 12:12:23 --> Config Class Initialized
INFO - 2023-09-22 12:12:23 --> Loader Class Initialized
INFO - 2023-09-22 12:12:23 --> Helper loaded: url_helper
INFO - 2023-09-22 12:12:23 --> Helper loaded: file_helper
INFO - 2023-09-22 12:12:23 --> Helper loaded: form_helper
INFO - 2023-09-22 12:12:23 --> Helper loaded: my_helper
INFO - 2023-09-22 12:12:23 --> Database Driver Class Initialized
INFO - 2023-09-22 12:12:23 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-22 12:12:23 --> Controller Class Initialized
INFO - 2023-09-22 12:12:23 --> Final output sent to browser
DEBUG - 2023-09-22 12:12:23 --> Total execution time: 0.0343
INFO - 2023-09-22 12:12:32 --> Config Class Initialized
INFO - 2023-09-22 12:12:32 --> Hooks Class Initialized
DEBUG - 2023-09-22 12:12:32 --> UTF-8 Support Enabled
INFO - 2023-09-22 12:12:32 --> Utf8 Class Initialized
INFO - 2023-09-22 12:12:32 --> URI Class Initialized
INFO - 2023-09-22 12:12:32 --> Router Class Initialized
INFO - 2023-09-22 12:12:32 --> Output Class Initialized
INFO - 2023-09-22 12:12:32 --> Security Class Initialized
DEBUG - 2023-09-22 12:12:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-22 12:12:32 --> Input Class Initialized
INFO - 2023-09-22 12:12:32 --> Language Class Initialized
INFO - 2023-09-22 12:12:32 --> Language Class Initialized
INFO - 2023-09-22 12:12:32 --> Config Class Initialized
INFO - 2023-09-22 12:12:32 --> Loader Class Initialized
INFO - 2023-09-22 12:12:32 --> Helper loaded: url_helper
INFO - 2023-09-22 12:12:32 --> Helper loaded: file_helper
INFO - 2023-09-22 12:12:32 --> Helper loaded: form_helper
INFO - 2023-09-22 12:12:32 --> Helper loaded: my_helper
INFO - 2023-09-22 12:12:32 --> Database Driver Class Initialized
INFO - 2023-09-22 12:12:32 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-22 12:12:32 --> Controller Class Initialized
INFO - 2023-09-22 12:12:32 --> Final output sent to browser
DEBUG - 2023-09-22 12:12:32 --> Total execution time: 0.0952
INFO - 2023-09-22 12:16:17 --> Config Class Initialized
INFO - 2023-09-22 12:16:17 --> Hooks Class Initialized
DEBUG - 2023-09-22 12:16:17 --> UTF-8 Support Enabled
INFO - 2023-09-22 12:16:17 --> Utf8 Class Initialized
INFO - 2023-09-22 12:16:17 --> URI Class Initialized
INFO - 2023-09-22 12:16:17 --> Router Class Initialized
INFO - 2023-09-22 12:16:17 --> Output Class Initialized
INFO - 2023-09-22 12:16:17 --> Security Class Initialized
DEBUG - 2023-09-22 12:16:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-22 12:16:17 --> Input Class Initialized
INFO - 2023-09-22 12:16:17 --> Language Class Initialized
INFO - 2023-09-22 12:16:17 --> Language Class Initialized
INFO - 2023-09-22 12:16:17 --> Config Class Initialized
INFO - 2023-09-22 12:16:17 --> Loader Class Initialized
INFO - 2023-09-22 12:16:17 --> Helper loaded: url_helper
INFO - 2023-09-22 12:16:17 --> Helper loaded: file_helper
INFO - 2023-09-22 12:16:17 --> Helper loaded: form_helper
INFO - 2023-09-22 12:16:17 --> Helper loaded: my_helper
INFO - 2023-09-22 12:16:17 --> Database Driver Class Initialized
INFO - 2023-09-22 12:16:17 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-22 12:16:17 --> Controller Class Initialized
INFO - 2023-09-22 12:16:17 --> Final output sent to browser
DEBUG - 2023-09-22 12:16:17 --> Total execution time: 0.0393
INFO - 2023-09-22 12:16:52 --> Config Class Initialized
INFO - 2023-09-22 12:16:52 --> Hooks Class Initialized
DEBUG - 2023-09-22 12:16:52 --> UTF-8 Support Enabled
INFO - 2023-09-22 12:16:52 --> Utf8 Class Initialized
INFO - 2023-09-22 12:16:52 --> URI Class Initialized
INFO - 2023-09-22 12:16:52 --> Router Class Initialized
INFO - 2023-09-22 12:16:52 --> Output Class Initialized
INFO - 2023-09-22 12:16:52 --> Security Class Initialized
DEBUG - 2023-09-22 12:16:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-22 12:16:52 --> Input Class Initialized
INFO - 2023-09-22 12:16:52 --> Language Class Initialized
INFO - 2023-09-22 12:16:52 --> Language Class Initialized
INFO - 2023-09-22 12:16:52 --> Config Class Initialized
INFO - 2023-09-22 12:16:52 --> Loader Class Initialized
INFO - 2023-09-22 12:16:52 --> Helper loaded: url_helper
INFO - 2023-09-22 12:16:52 --> Helper loaded: file_helper
INFO - 2023-09-22 12:16:52 --> Helper loaded: form_helper
INFO - 2023-09-22 12:16:52 --> Helper loaded: my_helper
INFO - 2023-09-22 12:16:52 --> Database Driver Class Initialized
INFO - 2023-09-22 12:16:53 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-22 12:16:53 --> Controller Class Initialized
INFO - 2023-09-22 12:16:53 --> Final output sent to browser
DEBUG - 2023-09-22 12:16:53 --> Total execution time: 0.0337
INFO - 2023-09-22 12:16:53 --> Config Class Initialized
INFO - 2023-09-22 12:16:53 --> Hooks Class Initialized
DEBUG - 2023-09-22 12:16:53 --> UTF-8 Support Enabled
INFO - 2023-09-22 12:16:53 --> Utf8 Class Initialized
INFO - 2023-09-22 12:16:53 --> URI Class Initialized
INFO - 2023-09-22 12:16:53 --> Router Class Initialized
INFO - 2023-09-22 12:16:53 --> Output Class Initialized
INFO - 2023-09-22 12:16:53 --> Security Class Initialized
DEBUG - 2023-09-22 12:16:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-22 12:16:53 --> Input Class Initialized
INFO - 2023-09-22 12:16:53 --> Language Class Initialized
INFO - 2023-09-22 12:16:53 --> Language Class Initialized
INFO - 2023-09-22 12:16:53 --> Config Class Initialized
INFO - 2023-09-22 12:16:53 --> Loader Class Initialized
INFO - 2023-09-22 12:16:53 --> Helper loaded: url_helper
INFO - 2023-09-22 12:16:53 --> Helper loaded: file_helper
INFO - 2023-09-22 12:16:53 --> Helper loaded: form_helper
INFO - 2023-09-22 12:16:53 --> Helper loaded: my_helper
INFO - 2023-09-22 12:16:53 --> Database Driver Class Initialized
INFO - 2023-09-22 12:16:53 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-22 12:16:53 --> Controller Class Initialized
INFO - 2023-09-22 12:17:00 --> Config Class Initialized
INFO - 2023-09-22 12:17:00 --> Hooks Class Initialized
DEBUG - 2023-09-22 12:17:00 --> UTF-8 Support Enabled
INFO - 2023-09-22 12:17:00 --> Utf8 Class Initialized
INFO - 2023-09-22 12:17:00 --> URI Class Initialized
INFO - 2023-09-22 12:17:00 --> Router Class Initialized
INFO - 2023-09-22 12:17:00 --> Output Class Initialized
INFO - 2023-09-22 12:17:00 --> Security Class Initialized
DEBUG - 2023-09-22 12:17:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-22 12:17:00 --> Input Class Initialized
INFO - 2023-09-22 12:17:00 --> Language Class Initialized
INFO - 2023-09-22 12:17:00 --> Language Class Initialized
INFO - 2023-09-22 12:17:00 --> Config Class Initialized
INFO - 2023-09-22 12:17:00 --> Loader Class Initialized
INFO - 2023-09-22 12:17:00 --> Helper loaded: url_helper
INFO - 2023-09-22 12:17:00 --> Helper loaded: file_helper
INFO - 2023-09-22 12:17:00 --> Helper loaded: form_helper
INFO - 2023-09-22 12:17:00 --> Helper loaded: my_helper
INFO - 2023-09-22 12:17:00 --> Database Driver Class Initialized
INFO - 2023-09-22 12:17:00 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-22 12:17:00 --> Controller Class Initialized
INFO - 2023-09-22 12:17:00 --> Final output sent to browser
DEBUG - 2023-09-22 12:17:00 --> Total execution time: 0.0440
INFO - 2023-09-22 12:17:02 --> Config Class Initialized
INFO - 2023-09-22 12:17:02 --> Hooks Class Initialized
DEBUG - 2023-09-22 12:17:02 --> UTF-8 Support Enabled
INFO - 2023-09-22 12:17:02 --> Utf8 Class Initialized
INFO - 2023-09-22 12:17:02 --> URI Class Initialized
INFO - 2023-09-22 12:17:02 --> Router Class Initialized
INFO - 2023-09-22 12:17:02 --> Output Class Initialized
INFO - 2023-09-22 12:17:02 --> Security Class Initialized
DEBUG - 2023-09-22 12:17:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-22 12:17:02 --> Input Class Initialized
INFO - 2023-09-22 12:17:02 --> Language Class Initialized
INFO - 2023-09-22 12:17:02 --> Language Class Initialized
INFO - 2023-09-22 12:17:02 --> Config Class Initialized
INFO - 2023-09-22 12:17:02 --> Loader Class Initialized
INFO - 2023-09-22 12:17:02 --> Helper loaded: url_helper
INFO - 2023-09-22 12:17:02 --> Helper loaded: file_helper
INFO - 2023-09-22 12:17:02 --> Helper loaded: form_helper
INFO - 2023-09-22 12:17:02 --> Helper loaded: my_helper
INFO - 2023-09-22 12:17:02 --> Database Driver Class Initialized
INFO - 2023-09-22 12:17:02 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-22 12:17:02 --> Controller Class Initialized
INFO - 2023-09-22 12:17:02 --> Final output sent to browser
DEBUG - 2023-09-22 12:17:02 --> Total execution time: 0.0555
INFO - 2023-09-22 12:28:12 --> Config Class Initialized
INFO - 2023-09-22 12:28:12 --> Hooks Class Initialized
DEBUG - 2023-09-22 12:28:12 --> UTF-8 Support Enabled
INFO - 2023-09-22 12:28:12 --> Utf8 Class Initialized
INFO - 2023-09-22 12:28:12 --> URI Class Initialized
INFO - 2023-09-22 12:28:12 --> Router Class Initialized
INFO - 2023-09-22 12:28:12 --> Output Class Initialized
INFO - 2023-09-22 12:28:12 --> Security Class Initialized
DEBUG - 2023-09-22 12:28:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-22 12:28:12 --> Input Class Initialized
INFO - 2023-09-22 12:28:12 --> Language Class Initialized
INFO - 2023-09-22 12:28:12 --> Language Class Initialized
INFO - 2023-09-22 12:28:12 --> Config Class Initialized
INFO - 2023-09-22 12:28:12 --> Loader Class Initialized
INFO - 2023-09-22 12:28:12 --> Helper loaded: url_helper
INFO - 2023-09-22 12:28:12 --> Helper loaded: file_helper
INFO - 2023-09-22 12:28:12 --> Helper loaded: form_helper
INFO - 2023-09-22 12:28:12 --> Helper loaded: my_helper
INFO - 2023-09-22 12:28:12 --> Database Driver Class Initialized
INFO - 2023-09-22 12:28:12 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-22 12:28:12 --> Controller Class Initialized
DEBUG - 2023-09-22 12:28:12 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/login/views/login.php
DEBUG - 2023-09-22 12:28:12 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-09-22 12:28:12 --> Final output sent to browser
DEBUG - 2023-09-22 12:28:12 --> Total execution time: 0.0333
INFO - 2023-09-22 13:39:09 --> Config Class Initialized
INFO - 2023-09-22 13:39:09 --> Hooks Class Initialized
DEBUG - 2023-09-22 13:39:09 --> UTF-8 Support Enabled
INFO - 2023-09-22 13:39:09 --> Utf8 Class Initialized
INFO - 2023-09-22 13:39:09 --> URI Class Initialized
INFO - 2023-09-22 13:39:09 --> Router Class Initialized
INFO - 2023-09-22 13:39:09 --> Output Class Initialized
INFO - 2023-09-22 13:39:09 --> Security Class Initialized
DEBUG - 2023-09-22 13:39:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-22 13:39:09 --> Input Class Initialized
INFO - 2023-09-22 13:39:09 --> Language Class Initialized
INFO - 2023-09-22 13:39:09 --> Language Class Initialized
INFO - 2023-09-22 13:39:09 --> Config Class Initialized
INFO - 2023-09-22 13:39:09 --> Loader Class Initialized
INFO - 2023-09-22 13:39:09 --> Helper loaded: url_helper
INFO - 2023-09-22 13:39:09 --> Helper loaded: file_helper
INFO - 2023-09-22 13:39:09 --> Helper loaded: form_helper
INFO - 2023-09-22 13:39:09 --> Helper loaded: my_helper
INFO - 2023-09-22 13:39:09 --> Database Driver Class Initialized
INFO - 2023-09-22 13:39:09 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-22 13:39:09 --> Controller Class Initialized
INFO - 2023-09-22 13:39:09 --> Final output sent to browser
DEBUG - 2023-09-22 13:39:09 --> Total execution time: 0.0797
INFO - 2023-09-22 13:39:32 --> Config Class Initialized
INFO - 2023-09-22 13:39:32 --> Hooks Class Initialized
DEBUG - 2023-09-22 13:39:32 --> UTF-8 Support Enabled
INFO - 2023-09-22 13:39:32 --> Utf8 Class Initialized
INFO - 2023-09-22 13:39:32 --> URI Class Initialized
INFO - 2023-09-22 13:39:32 --> Router Class Initialized
INFO - 2023-09-22 13:39:32 --> Output Class Initialized
INFO - 2023-09-22 13:39:32 --> Security Class Initialized
DEBUG - 2023-09-22 13:39:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-22 13:39:32 --> Input Class Initialized
INFO - 2023-09-22 13:39:32 --> Language Class Initialized
INFO - 2023-09-22 13:39:32 --> Language Class Initialized
INFO - 2023-09-22 13:39:32 --> Config Class Initialized
INFO - 2023-09-22 13:39:32 --> Loader Class Initialized
INFO - 2023-09-22 13:39:32 --> Helper loaded: url_helper
INFO - 2023-09-22 13:39:32 --> Helper loaded: file_helper
INFO - 2023-09-22 13:39:32 --> Helper loaded: form_helper
INFO - 2023-09-22 13:39:32 --> Helper loaded: my_helper
INFO - 2023-09-22 13:39:32 --> Database Driver Class Initialized
INFO - 2023-09-22 13:39:32 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-22 13:39:32 --> Controller Class Initialized
INFO - 2023-09-22 13:39:32 --> Final output sent to browser
DEBUG - 2023-09-22 13:39:32 --> Total execution time: 0.0374
INFO - 2023-09-22 13:39:32 --> Config Class Initialized
INFO - 2023-09-22 13:39:32 --> Hooks Class Initialized
DEBUG - 2023-09-22 13:39:32 --> UTF-8 Support Enabled
INFO - 2023-09-22 13:39:32 --> Utf8 Class Initialized
INFO - 2023-09-22 13:39:32 --> URI Class Initialized
INFO - 2023-09-22 13:39:32 --> Router Class Initialized
INFO - 2023-09-22 13:39:32 --> Output Class Initialized
INFO - 2023-09-22 13:39:32 --> Security Class Initialized
DEBUG - 2023-09-22 13:39:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-22 13:39:32 --> Input Class Initialized
INFO - 2023-09-22 13:39:32 --> Language Class Initialized
INFO - 2023-09-22 13:39:32 --> Language Class Initialized
INFO - 2023-09-22 13:39:32 --> Config Class Initialized
INFO - 2023-09-22 13:39:32 --> Loader Class Initialized
INFO - 2023-09-22 13:39:32 --> Helper loaded: url_helper
INFO - 2023-09-22 13:39:32 --> Helper loaded: file_helper
INFO - 2023-09-22 13:39:32 --> Helper loaded: form_helper
INFO - 2023-09-22 13:39:32 --> Helper loaded: my_helper
INFO - 2023-09-22 13:39:32 --> Database Driver Class Initialized
INFO - 2023-09-22 13:39:32 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-22 13:39:32 --> Controller Class Initialized
INFO - 2023-09-22 13:39:34 --> Config Class Initialized
INFO - 2023-09-22 13:39:34 --> Hooks Class Initialized
DEBUG - 2023-09-22 13:39:34 --> UTF-8 Support Enabled
INFO - 2023-09-22 13:39:34 --> Utf8 Class Initialized
INFO - 2023-09-22 13:39:34 --> URI Class Initialized
INFO - 2023-09-22 13:39:34 --> Router Class Initialized
INFO - 2023-09-22 13:39:34 --> Output Class Initialized
INFO - 2023-09-22 13:39:34 --> Security Class Initialized
DEBUG - 2023-09-22 13:39:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-22 13:39:34 --> Input Class Initialized
INFO - 2023-09-22 13:39:34 --> Language Class Initialized
INFO - 2023-09-22 13:39:34 --> Language Class Initialized
INFO - 2023-09-22 13:39:34 --> Config Class Initialized
INFO - 2023-09-22 13:39:34 --> Loader Class Initialized
INFO - 2023-09-22 13:39:34 --> Helper loaded: url_helper
INFO - 2023-09-22 13:39:34 --> Helper loaded: file_helper
INFO - 2023-09-22 13:39:34 --> Helper loaded: form_helper
INFO - 2023-09-22 13:39:34 --> Helper loaded: my_helper
INFO - 2023-09-22 13:39:34 --> Database Driver Class Initialized
INFO - 2023-09-22 13:39:34 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-22 13:39:34 --> Controller Class Initialized
INFO - 2023-09-22 13:39:34 --> Final output sent to browser
DEBUG - 2023-09-22 13:39:34 --> Total execution time: 0.0326
INFO - 2023-09-22 13:39:51 --> Config Class Initialized
INFO - 2023-09-22 13:39:51 --> Hooks Class Initialized
DEBUG - 2023-09-22 13:39:51 --> UTF-8 Support Enabled
INFO - 2023-09-22 13:39:51 --> Utf8 Class Initialized
INFO - 2023-09-22 13:39:51 --> URI Class Initialized
INFO - 2023-09-22 13:39:51 --> Router Class Initialized
INFO - 2023-09-22 13:39:51 --> Output Class Initialized
INFO - 2023-09-22 13:39:51 --> Security Class Initialized
DEBUG - 2023-09-22 13:39:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-22 13:39:51 --> Input Class Initialized
INFO - 2023-09-22 13:39:51 --> Language Class Initialized
INFO - 2023-09-22 13:39:51 --> Language Class Initialized
INFO - 2023-09-22 13:39:51 --> Config Class Initialized
INFO - 2023-09-22 13:39:51 --> Loader Class Initialized
INFO - 2023-09-22 13:39:51 --> Helper loaded: url_helper
INFO - 2023-09-22 13:39:51 --> Helper loaded: file_helper
INFO - 2023-09-22 13:39:51 --> Helper loaded: form_helper
INFO - 2023-09-22 13:39:51 --> Helper loaded: my_helper
INFO - 2023-09-22 13:39:51 --> Database Driver Class Initialized
INFO - 2023-09-22 13:39:51 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-22 13:39:51 --> Controller Class Initialized
INFO - 2023-09-22 13:39:51 --> Final output sent to browser
DEBUG - 2023-09-22 13:39:51 --> Total execution time: 0.0395
INFO - 2023-09-22 13:39:51 --> Config Class Initialized
INFO - 2023-09-22 13:39:51 --> Hooks Class Initialized
DEBUG - 2023-09-22 13:39:51 --> UTF-8 Support Enabled
INFO - 2023-09-22 13:39:51 --> Utf8 Class Initialized
INFO - 2023-09-22 13:39:51 --> URI Class Initialized
INFO - 2023-09-22 13:39:51 --> Router Class Initialized
INFO - 2023-09-22 13:39:51 --> Output Class Initialized
INFO - 2023-09-22 13:39:51 --> Security Class Initialized
DEBUG - 2023-09-22 13:39:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-22 13:39:51 --> Input Class Initialized
INFO - 2023-09-22 13:39:51 --> Language Class Initialized
INFO - 2023-09-22 13:39:51 --> Language Class Initialized
INFO - 2023-09-22 13:39:51 --> Config Class Initialized
INFO - 2023-09-22 13:39:51 --> Loader Class Initialized
INFO - 2023-09-22 13:39:51 --> Helper loaded: url_helper
INFO - 2023-09-22 13:39:51 --> Helper loaded: file_helper
INFO - 2023-09-22 13:39:51 --> Helper loaded: form_helper
INFO - 2023-09-22 13:39:51 --> Helper loaded: my_helper
INFO - 2023-09-22 13:39:51 --> Database Driver Class Initialized
INFO - 2023-09-22 13:39:51 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-22 13:39:51 --> Controller Class Initialized
INFO - 2023-09-22 13:39:53 --> Config Class Initialized
INFO - 2023-09-22 13:39:53 --> Hooks Class Initialized
DEBUG - 2023-09-22 13:39:53 --> UTF-8 Support Enabled
INFO - 2023-09-22 13:39:53 --> Utf8 Class Initialized
INFO - 2023-09-22 13:39:53 --> URI Class Initialized
INFO - 2023-09-22 13:39:53 --> Router Class Initialized
INFO - 2023-09-22 13:39:53 --> Output Class Initialized
INFO - 2023-09-22 13:39:53 --> Security Class Initialized
DEBUG - 2023-09-22 13:39:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-22 13:39:53 --> Input Class Initialized
INFO - 2023-09-22 13:39:53 --> Language Class Initialized
INFO - 2023-09-22 13:39:53 --> Language Class Initialized
INFO - 2023-09-22 13:39:53 --> Config Class Initialized
INFO - 2023-09-22 13:39:53 --> Loader Class Initialized
INFO - 2023-09-22 13:39:53 --> Helper loaded: url_helper
INFO - 2023-09-22 13:39:53 --> Helper loaded: file_helper
INFO - 2023-09-22 13:39:53 --> Helper loaded: form_helper
INFO - 2023-09-22 13:39:53 --> Helper loaded: my_helper
INFO - 2023-09-22 13:39:53 --> Database Driver Class Initialized
INFO - 2023-09-22 13:39:53 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-22 13:39:53 --> Controller Class Initialized
INFO - 2023-09-22 13:39:53 --> Final output sent to browser
DEBUG - 2023-09-22 13:39:53 --> Total execution time: 0.0361
INFO - 2023-09-22 13:40:05 --> Config Class Initialized
INFO - 2023-09-22 13:40:05 --> Hooks Class Initialized
DEBUG - 2023-09-22 13:40:05 --> UTF-8 Support Enabled
INFO - 2023-09-22 13:40:05 --> Utf8 Class Initialized
INFO - 2023-09-22 13:40:05 --> URI Class Initialized
INFO - 2023-09-22 13:40:05 --> Router Class Initialized
INFO - 2023-09-22 13:40:05 --> Output Class Initialized
INFO - 2023-09-22 13:40:05 --> Security Class Initialized
DEBUG - 2023-09-22 13:40:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-22 13:40:05 --> Input Class Initialized
INFO - 2023-09-22 13:40:05 --> Language Class Initialized
INFO - 2023-09-22 13:40:05 --> Language Class Initialized
INFO - 2023-09-22 13:40:05 --> Config Class Initialized
INFO - 2023-09-22 13:40:05 --> Loader Class Initialized
INFO - 2023-09-22 13:40:05 --> Helper loaded: url_helper
INFO - 2023-09-22 13:40:05 --> Helper loaded: file_helper
INFO - 2023-09-22 13:40:05 --> Helper loaded: form_helper
INFO - 2023-09-22 13:40:05 --> Helper loaded: my_helper
INFO - 2023-09-22 13:40:05 --> Database Driver Class Initialized
INFO - 2023-09-22 13:40:05 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-22 13:40:05 --> Controller Class Initialized
INFO - 2023-09-22 13:40:05 --> Final output sent to browser
DEBUG - 2023-09-22 13:40:05 --> Total execution time: 0.0755
INFO - 2023-09-22 13:40:06 --> Config Class Initialized
INFO - 2023-09-22 13:40:06 --> Hooks Class Initialized
DEBUG - 2023-09-22 13:40:06 --> UTF-8 Support Enabled
INFO - 2023-09-22 13:40:06 --> Utf8 Class Initialized
INFO - 2023-09-22 13:40:06 --> URI Class Initialized
INFO - 2023-09-22 13:40:06 --> Router Class Initialized
INFO - 2023-09-22 13:40:06 --> Output Class Initialized
INFO - 2023-09-22 13:40:06 --> Security Class Initialized
DEBUG - 2023-09-22 13:40:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-22 13:40:06 --> Input Class Initialized
INFO - 2023-09-22 13:40:06 --> Language Class Initialized
INFO - 2023-09-22 13:40:06 --> Language Class Initialized
INFO - 2023-09-22 13:40:06 --> Config Class Initialized
INFO - 2023-09-22 13:40:06 --> Loader Class Initialized
INFO - 2023-09-22 13:40:06 --> Helper loaded: url_helper
INFO - 2023-09-22 13:40:06 --> Helper loaded: file_helper
INFO - 2023-09-22 13:40:06 --> Helper loaded: form_helper
INFO - 2023-09-22 13:40:06 --> Helper loaded: my_helper
INFO - 2023-09-22 13:40:06 --> Database Driver Class Initialized
INFO - 2023-09-22 13:40:06 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-22 13:40:06 --> Controller Class Initialized
INFO - 2023-09-22 13:40:12 --> Config Class Initialized
INFO - 2023-09-22 13:40:12 --> Hooks Class Initialized
DEBUG - 2023-09-22 13:40:12 --> UTF-8 Support Enabled
INFO - 2023-09-22 13:40:12 --> Utf8 Class Initialized
INFO - 2023-09-22 13:40:12 --> URI Class Initialized
INFO - 2023-09-22 13:40:12 --> Router Class Initialized
INFO - 2023-09-22 13:40:12 --> Output Class Initialized
INFO - 2023-09-22 13:40:12 --> Security Class Initialized
DEBUG - 2023-09-22 13:40:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-22 13:40:12 --> Input Class Initialized
INFO - 2023-09-22 13:40:12 --> Language Class Initialized
INFO - 2023-09-22 13:40:12 --> Language Class Initialized
INFO - 2023-09-22 13:40:12 --> Config Class Initialized
INFO - 2023-09-22 13:40:12 --> Loader Class Initialized
INFO - 2023-09-22 13:40:12 --> Helper loaded: url_helper
INFO - 2023-09-22 13:40:12 --> Helper loaded: file_helper
INFO - 2023-09-22 13:40:12 --> Helper loaded: form_helper
INFO - 2023-09-22 13:40:12 --> Helper loaded: my_helper
INFO - 2023-09-22 13:40:12 --> Database Driver Class Initialized
INFO - 2023-09-22 13:40:12 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-22 13:40:12 --> Controller Class Initialized
INFO - 2023-09-22 13:40:12 --> Final output sent to browser
DEBUG - 2023-09-22 13:40:12 --> Total execution time: 0.0417
INFO - 2023-09-22 13:40:39 --> Config Class Initialized
INFO - 2023-09-22 13:40:39 --> Hooks Class Initialized
DEBUG - 2023-09-22 13:40:39 --> UTF-8 Support Enabled
INFO - 2023-09-22 13:40:39 --> Utf8 Class Initialized
INFO - 2023-09-22 13:40:39 --> URI Class Initialized
INFO - 2023-09-22 13:40:39 --> Router Class Initialized
INFO - 2023-09-22 13:40:39 --> Output Class Initialized
INFO - 2023-09-22 13:40:39 --> Security Class Initialized
DEBUG - 2023-09-22 13:40:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-22 13:40:39 --> Input Class Initialized
INFO - 2023-09-22 13:40:39 --> Language Class Initialized
INFO - 2023-09-22 13:40:39 --> Language Class Initialized
INFO - 2023-09-22 13:40:39 --> Config Class Initialized
INFO - 2023-09-22 13:40:39 --> Loader Class Initialized
INFO - 2023-09-22 13:40:39 --> Helper loaded: url_helper
INFO - 2023-09-22 13:40:39 --> Helper loaded: file_helper
INFO - 2023-09-22 13:40:39 --> Helper loaded: form_helper
INFO - 2023-09-22 13:40:39 --> Helper loaded: my_helper
INFO - 2023-09-22 13:40:39 --> Database Driver Class Initialized
INFO - 2023-09-22 13:40:39 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-22 13:40:39 --> Controller Class Initialized
INFO - 2023-09-22 13:40:39 --> Final output sent to browser
DEBUG - 2023-09-22 13:40:39 --> Total execution time: 0.0411
INFO - 2023-09-22 13:40:39 --> Config Class Initialized
INFO - 2023-09-22 13:40:39 --> Hooks Class Initialized
DEBUG - 2023-09-22 13:40:39 --> UTF-8 Support Enabled
INFO - 2023-09-22 13:40:39 --> Utf8 Class Initialized
INFO - 2023-09-22 13:40:39 --> URI Class Initialized
INFO - 2023-09-22 13:40:39 --> Router Class Initialized
INFO - 2023-09-22 13:40:39 --> Output Class Initialized
INFO - 2023-09-22 13:40:39 --> Security Class Initialized
DEBUG - 2023-09-22 13:40:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-22 13:40:39 --> Input Class Initialized
INFO - 2023-09-22 13:40:39 --> Language Class Initialized
INFO - 2023-09-22 13:40:39 --> Language Class Initialized
INFO - 2023-09-22 13:40:39 --> Config Class Initialized
INFO - 2023-09-22 13:40:39 --> Loader Class Initialized
INFO - 2023-09-22 13:40:39 --> Helper loaded: url_helper
INFO - 2023-09-22 13:40:39 --> Helper loaded: file_helper
INFO - 2023-09-22 13:40:39 --> Helper loaded: form_helper
INFO - 2023-09-22 13:40:39 --> Helper loaded: my_helper
INFO - 2023-09-22 13:40:39 --> Database Driver Class Initialized
INFO - 2023-09-22 13:40:39 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-22 13:40:39 --> Controller Class Initialized
INFO - 2023-09-22 13:40:40 --> Config Class Initialized
INFO - 2023-09-22 13:40:40 --> Hooks Class Initialized
DEBUG - 2023-09-22 13:40:40 --> UTF-8 Support Enabled
INFO - 2023-09-22 13:40:40 --> Utf8 Class Initialized
INFO - 2023-09-22 13:40:40 --> URI Class Initialized
INFO - 2023-09-22 13:40:40 --> Router Class Initialized
INFO - 2023-09-22 13:40:40 --> Output Class Initialized
INFO - 2023-09-22 13:40:40 --> Security Class Initialized
DEBUG - 2023-09-22 13:40:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-22 13:40:40 --> Input Class Initialized
INFO - 2023-09-22 13:40:40 --> Language Class Initialized
INFO - 2023-09-22 13:40:40 --> Language Class Initialized
INFO - 2023-09-22 13:40:40 --> Config Class Initialized
INFO - 2023-09-22 13:40:40 --> Loader Class Initialized
INFO - 2023-09-22 13:40:40 --> Helper loaded: url_helper
INFO - 2023-09-22 13:40:40 --> Helper loaded: file_helper
INFO - 2023-09-22 13:40:40 --> Helper loaded: form_helper
INFO - 2023-09-22 13:40:40 --> Helper loaded: my_helper
INFO - 2023-09-22 13:40:40 --> Database Driver Class Initialized
INFO - 2023-09-22 13:40:40 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-22 13:40:40 --> Controller Class Initialized
INFO - 2023-09-22 13:40:40 --> Final output sent to browser
DEBUG - 2023-09-22 13:40:40 --> Total execution time: 0.0335
INFO - 2023-09-22 13:40:54 --> Config Class Initialized
INFO - 2023-09-22 13:40:54 --> Hooks Class Initialized
DEBUG - 2023-09-22 13:40:54 --> UTF-8 Support Enabled
INFO - 2023-09-22 13:40:54 --> Utf8 Class Initialized
INFO - 2023-09-22 13:40:54 --> URI Class Initialized
INFO - 2023-09-22 13:40:54 --> Router Class Initialized
INFO - 2023-09-22 13:40:54 --> Output Class Initialized
INFO - 2023-09-22 13:40:54 --> Security Class Initialized
DEBUG - 2023-09-22 13:40:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-22 13:40:54 --> Input Class Initialized
INFO - 2023-09-22 13:40:54 --> Language Class Initialized
INFO - 2023-09-22 13:40:54 --> Language Class Initialized
INFO - 2023-09-22 13:40:54 --> Config Class Initialized
INFO - 2023-09-22 13:40:54 --> Loader Class Initialized
INFO - 2023-09-22 13:40:54 --> Helper loaded: url_helper
INFO - 2023-09-22 13:40:54 --> Helper loaded: file_helper
INFO - 2023-09-22 13:40:54 --> Helper loaded: form_helper
INFO - 2023-09-22 13:40:54 --> Helper loaded: my_helper
INFO - 2023-09-22 13:40:54 --> Database Driver Class Initialized
INFO - 2023-09-22 13:40:54 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-22 13:40:54 --> Controller Class Initialized
INFO - 2023-09-22 13:40:54 --> Final output sent to browser
DEBUG - 2023-09-22 13:40:54 --> Total execution time: 0.0461
INFO - 2023-09-22 13:40:54 --> Config Class Initialized
INFO - 2023-09-22 13:40:54 --> Hooks Class Initialized
DEBUG - 2023-09-22 13:40:54 --> UTF-8 Support Enabled
INFO - 2023-09-22 13:40:54 --> Utf8 Class Initialized
INFO - 2023-09-22 13:40:54 --> URI Class Initialized
INFO - 2023-09-22 13:40:54 --> Router Class Initialized
INFO - 2023-09-22 13:40:54 --> Output Class Initialized
INFO - 2023-09-22 13:40:54 --> Security Class Initialized
DEBUG - 2023-09-22 13:40:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-22 13:40:54 --> Input Class Initialized
INFO - 2023-09-22 13:40:54 --> Language Class Initialized
INFO - 2023-09-22 13:40:54 --> Language Class Initialized
INFO - 2023-09-22 13:40:54 --> Config Class Initialized
INFO - 2023-09-22 13:40:54 --> Loader Class Initialized
INFO - 2023-09-22 13:40:54 --> Helper loaded: url_helper
INFO - 2023-09-22 13:40:54 --> Helper loaded: file_helper
INFO - 2023-09-22 13:40:54 --> Helper loaded: form_helper
INFO - 2023-09-22 13:40:54 --> Helper loaded: my_helper
INFO - 2023-09-22 13:40:54 --> Database Driver Class Initialized
INFO - 2023-09-22 13:40:54 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-22 13:40:54 --> Controller Class Initialized
INFO - 2023-09-22 13:40:56 --> Config Class Initialized
INFO - 2023-09-22 13:40:56 --> Hooks Class Initialized
DEBUG - 2023-09-22 13:40:56 --> UTF-8 Support Enabled
INFO - 2023-09-22 13:40:56 --> Utf8 Class Initialized
INFO - 2023-09-22 13:40:56 --> URI Class Initialized
INFO - 2023-09-22 13:40:56 --> Router Class Initialized
INFO - 2023-09-22 13:40:56 --> Output Class Initialized
INFO - 2023-09-22 13:40:56 --> Security Class Initialized
DEBUG - 2023-09-22 13:40:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-22 13:40:56 --> Input Class Initialized
INFO - 2023-09-22 13:40:56 --> Language Class Initialized
INFO - 2023-09-22 13:40:56 --> Language Class Initialized
INFO - 2023-09-22 13:40:56 --> Config Class Initialized
INFO - 2023-09-22 13:40:56 --> Loader Class Initialized
INFO - 2023-09-22 13:40:56 --> Helper loaded: url_helper
INFO - 2023-09-22 13:40:56 --> Helper loaded: file_helper
INFO - 2023-09-22 13:40:56 --> Helper loaded: form_helper
INFO - 2023-09-22 13:40:56 --> Helper loaded: my_helper
INFO - 2023-09-22 13:40:56 --> Database Driver Class Initialized
INFO - 2023-09-22 13:40:56 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-22 13:40:56 --> Controller Class Initialized
INFO - 2023-09-22 13:40:56 --> Final output sent to browser
DEBUG - 2023-09-22 13:40:56 --> Total execution time: 0.1293
INFO - 2023-09-22 13:41:08 --> Config Class Initialized
INFO - 2023-09-22 13:41:08 --> Hooks Class Initialized
DEBUG - 2023-09-22 13:41:08 --> UTF-8 Support Enabled
INFO - 2023-09-22 13:41:08 --> Utf8 Class Initialized
INFO - 2023-09-22 13:41:08 --> URI Class Initialized
INFO - 2023-09-22 13:41:08 --> Router Class Initialized
INFO - 2023-09-22 13:41:08 --> Output Class Initialized
INFO - 2023-09-22 13:41:08 --> Security Class Initialized
DEBUG - 2023-09-22 13:41:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-22 13:41:08 --> Input Class Initialized
INFO - 2023-09-22 13:41:08 --> Language Class Initialized
INFO - 2023-09-22 13:41:08 --> Language Class Initialized
INFO - 2023-09-22 13:41:08 --> Config Class Initialized
INFO - 2023-09-22 13:41:08 --> Loader Class Initialized
INFO - 2023-09-22 13:41:08 --> Helper loaded: url_helper
INFO - 2023-09-22 13:41:08 --> Helper loaded: file_helper
INFO - 2023-09-22 13:41:08 --> Helper loaded: form_helper
INFO - 2023-09-22 13:41:08 --> Helper loaded: my_helper
INFO - 2023-09-22 13:41:08 --> Database Driver Class Initialized
INFO - 2023-09-22 13:41:08 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-22 13:41:08 --> Controller Class Initialized
INFO - 2023-09-22 13:41:08 --> Final output sent to browser
DEBUG - 2023-09-22 13:41:08 --> Total execution time: 0.0408
INFO - 2023-09-22 13:41:09 --> Config Class Initialized
INFO - 2023-09-22 13:41:09 --> Hooks Class Initialized
DEBUG - 2023-09-22 13:41:09 --> UTF-8 Support Enabled
INFO - 2023-09-22 13:41:09 --> Utf8 Class Initialized
INFO - 2023-09-22 13:41:09 --> URI Class Initialized
INFO - 2023-09-22 13:41:09 --> Router Class Initialized
INFO - 2023-09-22 13:41:09 --> Output Class Initialized
INFO - 2023-09-22 13:41:09 --> Security Class Initialized
DEBUG - 2023-09-22 13:41:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-22 13:41:09 --> Input Class Initialized
INFO - 2023-09-22 13:41:09 --> Language Class Initialized
INFO - 2023-09-22 13:41:09 --> Language Class Initialized
INFO - 2023-09-22 13:41:09 --> Config Class Initialized
INFO - 2023-09-22 13:41:09 --> Loader Class Initialized
INFO - 2023-09-22 13:41:09 --> Helper loaded: url_helper
INFO - 2023-09-22 13:41:09 --> Helper loaded: file_helper
INFO - 2023-09-22 13:41:09 --> Helper loaded: form_helper
INFO - 2023-09-22 13:41:09 --> Helper loaded: my_helper
INFO - 2023-09-22 13:41:09 --> Database Driver Class Initialized
INFO - 2023-09-22 13:41:09 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-22 13:41:09 --> Controller Class Initialized
INFO - 2023-09-22 13:41:12 --> Config Class Initialized
INFO - 2023-09-22 13:41:12 --> Hooks Class Initialized
DEBUG - 2023-09-22 13:41:12 --> UTF-8 Support Enabled
INFO - 2023-09-22 13:41:12 --> Utf8 Class Initialized
INFO - 2023-09-22 13:41:12 --> URI Class Initialized
INFO - 2023-09-22 13:41:12 --> Router Class Initialized
INFO - 2023-09-22 13:41:12 --> Output Class Initialized
INFO - 2023-09-22 13:41:12 --> Security Class Initialized
DEBUG - 2023-09-22 13:41:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-22 13:41:12 --> Input Class Initialized
INFO - 2023-09-22 13:41:12 --> Language Class Initialized
INFO - 2023-09-22 13:41:12 --> Language Class Initialized
INFO - 2023-09-22 13:41:12 --> Config Class Initialized
INFO - 2023-09-22 13:41:12 --> Loader Class Initialized
INFO - 2023-09-22 13:41:12 --> Helper loaded: url_helper
INFO - 2023-09-22 13:41:12 --> Helper loaded: file_helper
INFO - 2023-09-22 13:41:12 --> Helper loaded: form_helper
INFO - 2023-09-22 13:41:12 --> Helper loaded: my_helper
INFO - 2023-09-22 13:41:12 --> Database Driver Class Initialized
INFO - 2023-09-22 13:41:12 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-22 13:41:12 --> Controller Class Initialized
INFO - 2023-09-22 13:41:12 --> Final output sent to browser
DEBUG - 2023-09-22 13:41:12 --> Total execution time: 0.0697
INFO - 2023-09-22 13:41:28 --> Config Class Initialized
INFO - 2023-09-22 13:41:28 --> Hooks Class Initialized
DEBUG - 2023-09-22 13:41:28 --> UTF-8 Support Enabled
INFO - 2023-09-22 13:41:28 --> Utf8 Class Initialized
INFO - 2023-09-22 13:41:28 --> URI Class Initialized
INFO - 2023-09-22 13:41:28 --> Router Class Initialized
INFO - 2023-09-22 13:41:28 --> Output Class Initialized
INFO - 2023-09-22 13:41:28 --> Security Class Initialized
DEBUG - 2023-09-22 13:41:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-22 13:41:28 --> Input Class Initialized
INFO - 2023-09-22 13:41:28 --> Language Class Initialized
INFO - 2023-09-22 13:41:28 --> Language Class Initialized
INFO - 2023-09-22 13:41:28 --> Config Class Initialized
INFO - 2023-09-22 13:41:28 --> Loader Class Initialized
INFO - 2023-09-22 13:41:28 --> Helper loaded: url_helper
INFO - 2023-09-22 13:41:28 --> Helper loaded: file_helper
INFO - 2023-09-22 13:41:28 --> Helper loaded: form_helper
INFO - 2023-09-22 13:41:28 --> Helper loaded: my_helper
INFO - 2023-09-22 13:41:28 --> Database Driver Class Initialized
INFO - 2023-09-22 13:41:28 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-22 13:41:28 --> Controller Class Initialized
INFO - 2023-09-22 13:41:28 --> Final output sent to browser
DEBUG - 2023-09-22 13:41:28 --> Total execution time: 0.0321
INFO - 2023-09-22 13:41:28 --> Config Class Initialized
INFO - 2023-09-22 13:41:28 --> Hooks Class Initialized
DEBUG - 2023-09-22 13:41:28 --> UTF-8 Support Enabled
INFO - 2023-09-22 13:41:28 --> Utf8 Class Initialized
INFO - 2023-09-22 13:41:28 --> URI Class Initialized
INFO - 2023-09-22 13:41:28 --> Router Class Initialized
INFO - 2023-09-22 13:41:28 --> Output Class Initialized
INFO - 2023-09-22 13:41:28 --> Security Class Initialized
DEBUG - 2023-09-22 13:41:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-22 13:41:28 --> Input Class Initialized
INFO - 2023-09-22 13:41:28 --> Language Class Initialized
INFO - 2023-09-22 13:41:28 --> Language Class Initialized
INFO - 2023-09-22 13:41:28 --> Config Class Initialized
INFO - 2023-09-22 13:41:28 --> Loader Class Initialized
INFO - 2023-09-22 13:41:28 --> Helper loaded: url_helper
INFO - 2023-09-22 13:41:29 --> Helper loaded: file_helper
INFO - 2023-09-22 13:41:29 --> Helper loaded: form_helper
INFO - 2023-09-22 13:41:29 --> Helper loaded: my_helper
INFO - 2023-09-22 13:41:29 --> Database Driver Class Initialized
INFO - 2023-09-22 13:41:29 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-22 13:41:29 --> Controller Class Initialized
INFO - 2023-09-22 13:41:30 --> Config Class Initialized
INFO - 2023-09-22 13:41:30 --> Hooks Class Initialized
DEBUG - 2023-09-22 13:41:30 --> UTF-8 Support Enabled
INFO - 2023-09-22 13:41:30 --> Utf8 Class Initialized
INFO - 2023-09-22 13:41:30 --> URI Class Initialized
INFO - 2023-09-22 13:41:30 --> Router Class Initialized
INFO - 2023-09-22 13:41:30 --> Output Class Initialized
INFO - 2023-09-22 13:41:30 --> Security Class Initialized
DEBUG - 2023-09-22 13:41:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-22 13:41:30 --> Input Class Initialized
INFO - 2023-09-22 13:41:30 --> Language Class Initialized
INFO - 2023-09-22 13:41:30 --> Language Class Initialized
INFO - 2023-09-22 13:41:30 --> Config Class Initialized
INFO - 2023-09-22 13:41:30 --> Loader Class Initialized
INFO - 2023-09-22 13:41:30 --> Helper loaded: url_helper
INFO - 2023-09-22 13:41:30 --> Helper loaded: file_helper
INFO - 2023-09-22 13:41:30 --> Helper loaded: form_helper
INFO - 2023-09-22 13:41:30 --> Helper loaded: my_helper
INFO - 2023-09-22 13:41:30 --> Database Driver Class Initialized
INFO - 2023-09-22 13:41:30 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-22 13:41:30 --> Controller Class Initialized
INFO - 2023-09-22 13:41:30 --> Final output sent to browser
DEBUG - 2023-09-22 13:41:30 --> Total execution time: 0.0378
INFO - 2023-09-22 13:41:46 --> Config Class Initialized
INFO - 2023-09-22 13:41:46 --> Hooks Class Initialized
DEBUG - 2023-09-22 13:41:46 --> UTF-8 Support Enabled
INFO - 2023-09-22 13:41:46 --> Utf8 Class Initialized
INFO - 2023-09-22 13:41:46 --> URI Class Initialized
INFO - 2023-09-22 13:41:46 --> Router Class Initialized
INFO - 2023-09-22 13:41:46 --> Output Class Initialized
INFO - 2023-09-22 13:41:46 --> Security Class Initialized
DEBUG - 2023-09-22 13:41:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-22 13:41:46 --> Input Class Initialized
INFO - 2023-09-22 13:41:46 --> Language Class Initialized
INFO - 2023-09-22 13:41:46 --> Language Class Initialized
INFO - 2023-09-22 13:41:46 --> Config Class Initialized
INFO - 2023-09-22 13:41:46 --> Loader Class Initialized
INFO - 2023-09-22 13:41:46 --> Helper loaded: url_helper
INFO - 2023-09-22 13:41:46 --> Helper loaded: file_helper
INFO - 2023-09-22 13:41:46 --> Helper loaded: form_helper
INFO - 2023-09-22 13:41:46 --> Helper loaded: my_helper
INFO - 2023-09-22 13:41:46 --> Database Driver Class Initialized
INFO - 2023-09-22 13:41:46 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-22 13:41:46 --> Controller Class Initialized
INFO - 2023-09-22 13:41:46 --> Final output sent to browser
DEBUG - 2023-09-22 13:41:46 --> Total execution time: 0.0360
INFO - 2023-09-22 13:41:46 --> Config Class Initialized
INFO - 2023-09-22 13:41:46 --> Hooks Class Initialized
DEBUG - 2023-09-22 13:41:46 --> UTF-8 Support Enabled
INFO - 2023-09-22 13:41:46 --> Utf8 Class Initialized
INFO - 2023-09-22 13:41:46 --> URI Class Initialized
INFO - 2023-09-22 13:41:46 --> Router Class Initialized
INFO - 2023-09-22 13:41:46 --> Output Class Initialized
INFO - 2023-09-22 13:41:46 --> Security Class Initialized
DEBUG - 2023-09-22 13:41:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-22 13:41:46 --> Input Class Initialized
INFO - 2023-09-22 13:41:46 --> Language Class Initialized
INFO - 2023-09-22 13:41:46 --> Language Class Initialized
INFO - 2023-09-22 13:41:46 --> Config Class Initialized
INFO - 2023-09-22 13:41:46 --> Loader Class Initialized
INFO - 2023-09-22 13:41:46 --> Helper loaded: url_helper
INFO - 2023-09-22 13:41:46 --> Helper loaded: file_helper
INFO - 2023-09-22 13:41:46 --> Helper loaded: form_helper
INFO - 2023-09-22 13:41:46 --> Helper loaded: my_helper
INFO - 2023-09-22 13:41:46 --> Database Driver Class Initialized
INFO - 2023-09-22 13:41:46 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-22 13:41:46 --> Controller Class Initialized
INFO - 2023-09-22 13:41:49 --> Config Class Initialized
INFO - 2023-09-22 13:41:49 --> Hooks Class Initialized
DEBUG - 2023-09-22 13:41:49 --> UTF-8 Support Enabled
INFO - 2023-09-22 13:41:49 --> Utf8 Class Initialized
INFO - 2023-09-22 13:41:49 --> URI Class Initialized
INFO - 2023-09-22 13:41:49 --> Router Class Initialized
INFO - 2023-09-22 13:41:49 --> Output Class Initialized
INFO - 2023-09-22 13:41:49 --> Security Class Initialized
DEBUG - 2023-09-22 13:41:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-22 13:41:49 --> Input Class Initialized
INFO - 2023-09-22 13:41:49 --> Language Class Initialized
INFO - 2023-09-22 13:41:49 --> Language Class Initialized
INFO - 2023-09-22 13:41:49 --> Config Class Initialized
INFO - 2023-09-22 13:41:49 --> Loader Class Initialized
INFO - 2023-09-22 13:41:49 --> Helper loaded: url_helper
INFO - 2023-09-22 13:41:49 --> Helper loaded: file_helper
INFO - 2023-09-22 13:41:49 --> Helper loaded: form_helper
INFO - 2023-09-22 13:41:49 --> Helper loaded: my_helper
INFO - 2023-09-22 13:41:49 --> Database Driver Class Initialized
INFO - 2023-09-22 13:41:49 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-22 13:41:49 --> Controller Class Initialized
INFO - 2023-09-22 13:41:49 --> Final output sent to browser
DEBUG - 2023-09-22 13:41:49 --> Total execution time: 0.0720
INFO - 2023-09-22 13:42:00 --> Config Class Initialized
INFO - 2023-09-22 13:42:00 --> Hooks Class Initialized
DEBUG - 2023-09-22 13:42:00 --> UTF-8 Support Enabled
INFO - 2023-09-22 13:42:00 --> Utf8 Class Initialized
INFO - 2023-09-22 13:42:00 --> URI Class Initialized
INFO - 2023-09-22 13:42:00 --> Router Class Initialized
INFO - 2023-09-22 13:42:00 --> Output Class Initialized
INFO - 2023-09-22 13:42:00 --> Security Class Initialized
DEBUG - 2023-09-22 13:42:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-22 13:42:00 --> Input Class Initialized
INFO - 2023-09-22 13:42:00 --> Language Class Initialized
INFO - 2023-09-22 13:42:00 --> Language Class Initialized
INFO - 2023-09-22 13:42:00 --> Config Class Initialized
INFO - 2023-09-22 13:42:00 --> Loader Class Initialized
INFO - 2023-09-22 13:42:00 --> Helper loaded: url_helper
INFO - 2023-09-22 13:42:00 --> Helper loaded: file_helper
INFO - 2023-09-22 13:42:00 --> Helper loaded: form_helper
INFO - 2023-09-22 13:42:00 --> Helper loaded: my_helper
INFO - 2023-09-22 13:42:00 --> Database Driver Class Initialized
INFO - 2023-09-22 13:42:00 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-22 13:42:00 --> Controller Class Initialized
INFO - 2023-09-22 13:42:00 --> Final output sent to browser
DEBUG - 2023-09-22 13:42:00 --> Total execution time: 0.0439
INFO - 2023-09-22 13:42:00 --> Config Class Initialized
INFO - 2023-09-22 13:42:00 --> Hooks Class Initialized
DEBUG - 2023-09-22 13:42:00 --> UTF-8 Support Enabled
INFO - 2023-09-22 13:42:00 --> Utf8 Class Initialized
INFO - 2023-09-22 13:42:00 --> URI Class Initialized
INFO - 2023-09-22 13:42:00 --> Router Class Initialized
INFO - 2023-09-22 13:42:00 --> Output Class Initialized
INFO - 2023-09-22 13:42:00 --> Security Class Initialized
DEBUG - 2023-09-22 13:42:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-22 13:42:00 --> Input Class Initialized
INFO - 2023-09-22 13:42:00 --> Language Class Initialized
INFO - 2023-09-22 13:42:00 --> Language Class Initialized
INFO - 2023-09-22 13:42:00 --> Config Class Initialized
INFO - 2023-09-22 13:42:00 --> Loader Class Initialized
INFO - 2023-09-22 13:42:00 --> Helper loaded: url_helper
INFO - 2023-09-22 13:42:00 --> Helper loaded: file_helper
INFO - 2023-09-22 13:42:00 --> Helper loaded: form_helper
INFO - 2023-09-22 13:42:00 --> Helper loaded: my_helper
INFO - 2023-09-22 13:42:00 --> Database Driver Class Initialized
INFO - 2023-09-22 13:42:00 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-22 13:42:00 --> Controller Class Initialized
INFO - 2023-09-22 13:42:38 --> Config Class Initialized
INFO - 2023-09-22 13:42:38 --> Hooks Class Initialized
DEBUG - 2023-09-22 13:42:38 --> UTF-8 Support Enabled
INFO - 2023-09-22 13:42:38 --> Utf8 Class Initialized
INFO - 2023-09-22 13:42:38 --> URI Class Initialized
INFO - 2023-09-22 13:42:38 --> Router Class Initialized
INFO - 2023-09-22 13:42:38 --> Output Class Initialized
INFO - 2023-09-22 13:42:38 --> Security Class Initialized
DEBUG - 2023-09-22 13:42:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-22 13:42:38 --> Input Class Initialized
INFO - 2023-09-22 13:42:38 --> Language Class Initialized
INFO - 2023-09-22 13:42:38 --> Language Class Initialized
INFO - 2023-09-22 13:42:38 --> Config Class Initialized
INFO - 2023-09-22 13:42:38 --> Loader Class Initialized
INFO - 2023-09-22 13:42:38 --> Helper loaded: url_helper
INFO - 2023-09-22 13:42:38 --> Helper loaded: file_helper
INFO - 2023-09-22 13:42:38 --> Helper loaded: form_helper
INFO - 2023-09-22 13:42:38 --> Helper loaded: my_helper
INFO - 2023-09-22 13:42:38 --> Database Driver Class Initialized
INFO - 2023-09-22 13:42:38 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-22 13:42:38 --> Controller Class Initialized
INFO - 2023-09-22 13:42:38 --> Final output sent to browser
DEBUG - 2023-09-22 13:42:38 --> Total execution time: 0.0801
INFO - 2023-09-22 13:42:53 --> Config Class Initialized
INFO - 2023-09-22 13:42:53 --> Hooks Class Initialized
DEBUG - 2023-09-22 13:42:53 --> UTF-8 Support Enabled
INFO - 2023-09-22 13:42:53 --> Utf8 Class Initialized
INFO - 2023-09-22 13:42:53 --> URI Class Initialized
INFO - 2023-09-22 13:42:53 --> Router Class Initialized
INFO - 2023-09-22 13:42:53 --> Output Class Initialized
INFO - 2023-09-22 13:42:53 --> Security Class Initialized
DEBUG - 2023-09-22 13:42:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-22 13:42:53 --> Input Class Initialized
INFO - 2023-09-22 13:42:53 --> Language Class Initialized
INFO - 2023-09-22 13:42:53 --> Language Class Initialized
INFO - 2023-09-22 13:42:53 --> Config Class Initialized
INFO - 2023-09-22 13:42:53 --> Loader Class Initialized
INFO - 2023-09-22 13:42:53 --> Helper loaded: url_helper
INFO - 2023-09-22 13:42:53 --> Helper loaded: file_helper
INFO - 2023-09-22 13:42:53 --> Helper loaded: form_helper
INFO - 2023-09-22 13:42:53 --> Helper loaded: my_helper
INFO - 2023-09-22 13:42:53 --> Database Driver Class Initialized
INFO - 2023-09-22 13:42:53 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-22 13:42:53 --> Controller Class Initialized
INFO - 2023-09-22 13:42:53 --> Final output sent to browser
DEBUG - 2023-09-22 13:42:53 --> Total execution time: 0.0375
INFO - 2023-09-22 13:42:53 --> Config Class Initialized
INFO - 2023-09-22 13:42:53 --> Hooks Class Initialized
DEBUG - 2023-09-22 13:42:53 --> UTF-8 Support Enabled
INFO - 2023-09-22 13:42:53 --> Utf8 Class Initialized
INFO - 2023-09-22 13:42:53 --> URI Class Initialized
INFO - 2023-09-22 13:42:53 --> Router Class Initialized
INFO - 2023-09-22 13:42:53 --> Output Class Initialized
INFO - 2023-09-22 13:42:53 --> Security Class Initialized
DEBUG - 2023-09-22 13:42:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-22 13:42:53 --> Input Class Initialized
INFO - 2023-09-22 13:42:53 --> Language Class Initialized
INFO - 2023-09-22 13:42:53 --> Language Class Initialized
INFO - 2023-09-22 13:42:53 --> Config Class Initialized
INFO - 2023-09-22 13:42:53 --> Loader Class Initialized
INFO - 2023-09-22 13:42:53 --> Helper loaded: url_helper
INFO - 2023-09-22 13:42:53 --> Helper loaded: file_helper
INFO - 2023-09-22 13:42:53 --> Helper loaded: form_helper
INFO - 2023-09-22 13:42:53 --> Helper loaded: my_helper
INFO - 2023-09-22 13:42:53 --> Database Driver Class Initialized
INFO - 2023-09-22 13:42:53 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-22 13:42:53 --> Controller Class Initialized
INFO - 2023-09-22 13:42:54 --> Config Class Initialized
INFO - 2023-09-22 13:42:54 --> Hooks Class Initialized
DEBUG - 2023-09-22 13:42:54 --> UTF-8 Support Enabled
INFO - 2023-09-22 13:42:54 --> Utf8 Class Initialized
INFO - 2023-09-22 13:42:54 --> URI Class Initialized
INFO - 2023-09-22 13:42:54 --> Router Class Initialized
INFO - 2023-09-22 13:42:54 --> Output Class Initialized
INFO - 2023-09-22 13:42:54 --> Security Class Initialized
DEBUG - 2023-09-22 13:42:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-22 13:42:54 --> Input Class Initialized
INFO - 2023-09-22 13:42:54 --> Language Class Initialized
INFO - 2023-09-22 13:42:54 --> Language Class Initialized
INFO - 2023-09-22 13:42:54 --> Config Class Initialized
INFO - 2023-09-22 13:42:54 --> Loader Class Initialized
INFO - 2023-09-22 13:42:54 --> Helper loaded: url_helper
INFO - 2023-09-22 13:42:54 --> Helper loaded: file_helper
INFO - 2023-09-22 13:42:54 --> Helper loaded: form_helper
INFO - 2023-09-22 13:42:54 --> Helper loaded: my_helper
INFO - 2023-09-22 13:42:54 --> Database Driver Class Initialized
INFO - 2023-09-22 13:42:54 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-22 13:42:54 --> Controller Class Initialized
INFO - 2023-09-22 13:42:54 --> Final output sent to browser
DEBUG - 2023-09-22 13:42:54 --> Total execution time: 0.0310
INFO - 2023-09-22 13:43:04 --> Config Class Initialized
INFO - 2023-09-22 13:43:04 --> Hooks Class Initialized
DEBUG - 2023-09-22 13:43:04 --> UTF-8 Support Enabled
INFO - 2023-09-22 13:43:04 --> Utf8 Class Initialized
INFO - 2023-09-22 13:43:04 --> URI Class Initialized
INFO - 2023-09-22 13:43:04 --> Router Class Initialized
INFO - 2023-09-22 13:43:04 --> Output Class Initialized
INFO - 2023-09-22 13:43:04 --> Security Class Initialized
DEBUG - 2023-09-22 13:43:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-22 13:43:04 --> Input Class Initialized
INFO - 2023-09-22 13:43:04 --> Language Class Initialized
INFO - 2023-09-22 13:43:04 --> Language Class Initialized
INFO - 2023-09-22 13:43:04 --> Config Class Initialized
INFO - 2023-09-22 13:43:04 --> Loader Class Initialized
INFO - 2023-09-22 13:43:04 --> Helper loaded: url_helper
INFO - 2023-09-22 13:43:04 --> Helper loaded: file_helper
INFO - 2023-09-22 13:43:04 --> Helper loaded: form_helper
INFO - 2023-09-22 13:43:04 --> Helper loaded: my_helper
INFO - 2023-09-22 13:43:04 --> Database Driver Class Initialized
INFO - 2023-09-22 13:43:04 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-22 13:43:04 --> Controller Class Initialized
INFO - 2023-09-22 13:43:04 --> Final output sent to browser
DEBUG - 2023-09-22 13:43:04 --> Total execution time: 0.0983
INFO - 2023-09-22 13:43:04 --> Config Class Initialized
INFO - 2023-09-22 13:43:04 --> Hooks Class Initialized
DEBUG - 2023-09-22 13:43:04 --> UTF-8 Support Enabled
INFO - 2023-09-22 13:43:04 --> Utf8 Class Initialized
INFO - 2023-09-22 13:43:04 --> URI Class Initialized
INFO - 2023-09-22 13:43:04 --> Router Class Initialized
INFO - 2023-09-22 13:43:04 --> Output Class Initialized
INFO - 2023-09-22 13:43:04 --> Security Class Initialized
DEBUG - 2023-09-22 13:43:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-22 13:43:04 --> Input Class Initialized
INFO - 2023-09-22 13:43:04 --> Language Class Initialized
INFO - 2023-09-22 13:43:04 --> Language Class Initialized
INFO - 2023-09-22 13:43:04 --> Config Class Initialized
INFO - 2023-09-22 13:43:04 --> Loader Class Initialized
INFO - 2023-09-22 13:43:04 --> Helper loaded: url_helper
INFO - 2023-09-22 13:43:04 --> Helper loaded: file_helper
INFO - 2023-09-22 13:43:04 --> Helper loaded: form_helper
INFO - 2023-09-22 13:43:04 --> Helper loaded: my_helper
INFO - 2023-09-22 13:43:04 --> Database Driver Class Initialized
INFO - 2023-09-22 13:43:04 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-22 13:43:04 --> Controller Class Initialized
INFO - 2023-09-22 13:43:07 --> Config Class Initialized
INFO - 2023-09-22 13:43:07 --> Hooks Class Initialized
DEBUG - 2023-09-22 13:43:07 --> UTF-8 Support Enabled
INFO - 2023-09-22 13:43:07 --> Utf8 Class Initialized
INFO - 2023-09-22 13:43:07 --> URI Class Initialized
INFO - 2023-09-22 13:43:07 --> Router Class Initialized
INFO - 2023-09-22 13:43:07 --> Output Class Initialized
INFO - 2023-09-22 13:43:07 --> Security Class Initialized
DEBUG - 2023-09-22 13:43:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-22 13:43:07 --> Input Class Initialized
INFO - 2023-09-22 13:43:07 --> Language Class Initialized
INFO - 2023-09-22 13:43:07 --> Language Class Initialized
INFO - 2023-09-22 13:43:07 --> Config Class Initialized
INFO - 2023-09-22 13:43:07 --> Loader Class Initialized
INFO - 2023-09-22 13:43:07 --> Helper loaded: url_helper
INFO - 2023-09-22 13:43:07 --> Helper loaded: file_helper
INFO - 2023-09-22 13:43:07 --> Helper loaded: form_helper
INFO - 2023-09-22 13:43:07 --> Helper loaded: my_helper
INFO - 2023-09-22 13:43:07 --> Database Driver Class Initialized
INFO - 2023-09-22 13:43:07 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-22 13:43:07 --> Controller Class Initialized
INFO - 2023-09-22 13:43:07 --> Final output sent to browser
DEBUG - 2023-09-22 13:43:07 --> Total execution time: 0.0362
INFO - 2023-09-22 13:43:19 --> Config Class Initialized
INFO - 2023-09-22 13:43:19 --> Hooks Class Initialized
DEBUG - 2023-09-22 13:43:19 --> UTF-8 Support Enabled
INFO - 2023-09-22 13:43:19 --> Utf8 Class Initialized
INFO - 2023-09-22 13:43:19 --> URI Class Initialized
INFO - 2023-09-22 13:43:19 --> Router Class Initialized
INFO - 2023-09-22 13:43:19 --> Output Class Initialized
INFO - 2023-09-22 13:43:19 --> Security Class Initialized
DEBUG - 2023-09-22 13:43:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-22 13:43:19 --> Input Class Initialized
INFO - 2023-09-22 13:43:19 --> Language Class Initialized
INFO - 2023-09-22 13:43:19 --> Language Class Initialized
INFO - 2023-09-22 13:43:19 --> Config Class Initialized
INFO - 2023-09-22 13:43:19 --> Loader Class Initialized
INFO - 2023-09-22 13:43:19 --> Helper loaded: url_helper
INFO - 2023-09-22 13:43:19 --> Helper loaded: file_helper
INFO - 2023-09-22 13:43:19 --> Helper loaded: form_helper
INFO - 2023-09-22 13:43:19 --> Helper loaded: my_helper
INFO - 2023-09-22 13:43:19 --> Database Driver Class Initialized
INFO - 2023-09-22 13:43:19 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-22 13:43:19 --> Controller Class Initialized
INFO - 2023-09-22 13:43:19 --> Final output sent to browser
DEBUG - 2023-09-22 13:43:19 --> Total execution time: 0.0377
INFO - 2023-09-22 13:43:19 --> Config Class Initialized
INFO - 2023-09-22 13:43:19 --> Hooks Class Initialized
DEBUG - 2023-09-22 13:43:19 --> UTF-8 Support Enabled
INFO - 2023-09-22 13:43:19 --> Utf8 Class Initialized
INFO - 2023-09-22 13:43:19 --> URI Class Initialized
INFO - 2023-09-22 13:43:19 --> Router Class Initialized
INFO - 2023-09-22 13:43:19 --> Output Class Initialized
INFO - 2023-09-22 13:43:19 --> Security Class Initialized
DEBUG - 2023-09-22 13:43:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-22 13:43:19 --> Input Class Initialized
INFO - 2023-09-22 13:43:19 --> Language Class Initialized
INFO - 2023-09-22 13:43:19 --> Language Class Initialized
INFO - 2023-09-22 13:43:19 --> Config Class Initialized
INFO - 2023-09-22 13:43:19 --> Loader Class Initialized
INFO - 2023-09-22 13:43:19 --> Helper loaded: url_helper
INFO - 2023-09-22 13:43:19 --> Helper loaded: file_helper
INFO - 2023-09-22 13:43:19 --> Helper loaded: form_helper
INFO - 2023-09-22 13:43:19 --> Helper loaded: my_helper
INFO - 2023-09-22 13:43:19 --> Database Driver Class Initialized
INFO - 2023-09-22 13:43:19 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-22 13:43:19 --> Controller Class Initialized
INFO - 2023-09-22 13:44:25 --> Config Class Initialized
INFO - 2023-09-22 13:44:25 --> Hooks Class Initialized
DEBUG - 2023-09-22 13:44:25 --> UTF-8 Support Enabled
INFO - 2023-09-22 13:44:25 --> Utf8 Class Initialized
INFO - 2023-09-22 13:44:25 --> URI Class Initialized
INFO - 2023-09-22 13:44:25 --> Router Class Initialized
INFO - 2023-09-22 13:44:25 --> Output Class Initialized
INFO - 2023-09-22 13:44:25 --> Security Class Initialized
DEBUG - 2023-09-22 13:44:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-22 13:44:25 --> Input Class Initialized
INFO - 2023-09-22 13:44:25 --> Language Class Initialized
INFO - 2023-09-22 13:44:25 --> Language Class Initialized
INFO - 2023-09-22 13:44:25 --> Config Class Initialized
INFO - 2023-09-22 13:44:25 --> Loader Class Initialized
INFO - 2023-09-22 13:44:25 --> Helper loaded: url_helper
INFO - 2023-09-22 13:44:25 --> Helper loaded: file_helper
INFO - 2023-09-22 13:44:25 --> Helper loaded: form_helper
INFO - 2023-09-22 13:44:25 --> Helper loaded: my_helper
INFO - 2023-09-22 13:44:25 --> Database Driver Class Initialized
INFO - 2023-09-22 13:44:25 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-22 13:44:25 --> Controller Class Initialized
INFO - 2023-09-22 13:44:25 --> Final output sent to browser
DEBUG - 2023-09-22 13:44:25 --> Total execution time: 0.0374
INFO - 2023-09-22 13:44:37 --> Config Class Initialized
INFO - 2023-09-22 13:44:37 --> Hooks Class Initialized
DEBUG - 2023-09-22 13:44:37 --> UTF-8 Support Enabled
INFO - 2023-09-22 13:44:37 --> Utf8 Class Initialized
INFO - 2023-09-22 13:44:37 --> URI Class Initialized
INFO - 2023-09-22 13:44:37 --> Router Class Initialized
INFO - 2023-09-22 13:44:37 --> Output Class Initialized
INFO - 2023-09-22 13:44:37 --> Security Class Initialized
DEBUG - 2023-09-22 13:44:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-22 13:44:37 --> Input Class Initialized
INFO - 2023-09-22 13:44:37 --> Language Class Initialized
INFO - 2023-09-22 13:44:37 --> Language Class Initialized
INFO - 2023-09-22 13:44:37 --> Config Class Initialized
INFO - 2023-09-22 13:44:37 --> Loader Class Initialized
INFO - 2023-09-22 13:44:37 --> Helper loaded: url_helper
INFO - 2023-09-22 13:44:37 --> Helper loaded: file_helper
INFO - 2023-09-22 13:44:37 --> Helper loaded: form_helper
INFO - 2023-09-22 13:44:37 --> Helper loaded: my_helper
INFO - 2023-09-22 13:44:37 --> Database Driver Class Initialized
INFO - 2023-09-22 13:44:37 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-22 13:44:37 --> Controller Class Initialized
INFO - 2023-09-22 13:44:37 --> Final output sent to browser
DEBUG - 2023-09-22 13:44:37 --> Total execution time: 0.0352
INFO - 2023-09-22 13:44:37 --> Config Class Initialized
INFO - 2023-09-22 13:44:37 --> Hooks Class Initialized
DEBUG - 2023-09-22 13:44:37 --> UTF-8 Support Enabled
INFO - 2023-09-22 13:44:37 --> Utf8 Class Initialized
INFO - 2023-09-22 13:44:37 --> URI Class Initialized
INFO - 2023-09-22 13:44:37 --> Router Class Initialized
INFO - 2023-09-22 13:44:37 --> Output Class Initialized
INFO - 2023-09-22 13:44:37 --> Security Class Initialized
DEBUG - 2023-09-22 13:44:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-22 13:44:37 --> Input Class Initialized
INFO - 2023-09-22 13:44:37 --> Language Class Initialized
INFO - 2023-09-22 13:44:37 --> Language Class Initialized
INFO - 2023-09-22 13:44:37 --> Config Class Initialized
INFO - 2023-09-22 13:44:37 --> Loader Class Initialized
INFO - 2023-09-22 13:44:37 --> Helper loaded: url_helper
INFO - 2023-09-22 13:44:37 --> Helper loaded: file_helper
INFO - 2023-09-22 13:44:37 --> Helper loaded: form_helper
INFO - 2023-09-22 13:44:37 --> Helper loaded: my_helper
INFO - 2023-09-22 13:44:37 --> Database Driver Class Initialized
INFO - 2023-09-22 13:44:37 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-22 13:44:37 --> Controller Class Initialized
INFO - 2023-09-22 13:44:39 --> Config Class Initialized
INFO - 2023-09-22 13:44:39 --> Hooks Class Initialized
DEBUG - 2023-09-22 13:44:39 --> UTF-8 Support Enabled
INFO - 2023-09-22 13:44:39 --> Utf8 Class Initialized
INFO - 2023-09-22 13:44:39 --> URI Class Initialized
INFO - 2023-09-22 13:44:39 --> Router Class Initialized
INFO - 2023-09-22 13:44:39 --> Output Class Initialized
INFO - 2023-09-22 13:44:39 --> Security Class Initialized
DEBUG - 2023-09-22 13:44:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-22 13:44:39 --> Input Class Initialized
INFO - 2023-09-22 13:44:39 --> Language Class Initialized
INFO - 2023-09-22 13:44:39 --> Language Class Initialized
INFO - 2023-09-22 13:44:39 --> Config Class Initialized
INFO - 2023-09-22 13:44:39 --> Loader Class Initialized
INFO - 2023-09-22 13:44:39 --> Helper loaded: url_helper
INFO - 2023-09-22 13:44:39 --> Helper loaded: file_helper
INFO - 2023-09-22 13:44:39 --> Helper loaded: form_helper
INFO - 2023-09-22 13:44:39 --> Helper loaded: my_helper
INFO - 2023-09-22 13:44:39 --> Database Driver Class Initialized
INFO - 2023-09-22 13:44:39 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-22 13:44:39 --> Controller Class Initialized
INFO - 2023-09-22 13:44:39 --> Final output sent to browser
DEBUG - 2023-09-22 13:44:39 --> Total execution time: 0.0406
INFO - 2023-09-22 13:44:48 --> Config Class Initialized
INFO - 2023-09-22 13:44:48 --> Hooks Class Initialized
DEBUG - 2023-09-22 13:44:48 --> UTF-8 Support Enabled
INFO - 2023-09-22 13:44:48 --> Utf8 Class Initialized
INFO - 2023-09-22 13:44:48 --> URI Class Initialized
INFO - 2023-09-22 13:44:48 --> Router Class Initialized
INFO - 2023-09-22 13:44:48 --> Output Class Initialized
INFO - 2023-09-22 13:44:48 --> Security Class Initialized
DEBUG - 2023-09-22 13:44:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-22 13:44:48 --> Input Class Initialized
INFO - 2023-09-22 13:44:48 --> Language Class Initialized
INFO - 2023-09-22 13:44:48 --> Language Class Initialized
INFO - 2023-09-22 13:44:48 --> Config Class Initialized
INFO - 2023-09-22 13:44:48 --> Loader Class Initialized
INFO - 2023-09-22 13:44:48 --> Helper loaded: url_helper
INFO - 2023-09-22 13:44:48 --> Helper loaded: file_helper
INFO - 2023-09-22 13:44:48 --> Helper loaded: form_helper
INFO - 2023-09-22 13:44:48 --> Helper loaded: my_helper
INFO - 2023-09-22 13:44:48 --> Database Driver Class Initialized
INFO - 2023-09-22 13:44:48 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-22 13:44:48 --> Controller Class Initialized
INFO - 2023-09-22 13:44:48 --> Final output sent to browser
DEBUG - 2023-09-22 13:44:48 --> Total execution time: 0.0307
INFO - 2023-09-22 13:44:48 --> Config Class Initialized
INFO - 2023-09-22 13:44:48 --> Hooks Class Initialized
DEBUG - 2023-09-22 13:44:48 --> UTF-8 Support Enabled
INFO - 2023-09-22 13:44:48 --> Utf8 Class Initialized
INFO - 2023-09-22 13:44:48 --> URI Class Initialized
INFO - 2023-09-22 13:44:48 --> Router Class Initialized
INFO - 2023-09-22 13:44:48 --> Output Class Initialized
INFO - 2023-09-22 13:44:48 --> Security Class Initialized
DEBUG - 2023-09-22 13:44:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-22 13:44:48 --> Input Class Initialized
INFO - 2023-09-22 13:44:48 --> Language Class Initialized
INFO - 2023-09-22 13:44:48 --> Language Class Initialized
INFO - 2023-09-22 13:44:48 --> Config Class Initialized
INFO - 2023-09-22 13:44:48 --> Loader Class Initialized
INFO - 2023-09-22 13:44:48 --> Helper loaded: url_helper
INFO - 2023-09-22 13:44:48 --> Helper loaded: file_helper
INFO - 2023-09-22 13:44:48 --> Helper loaded: form_helper
INFO - 2023-09-22 13:44:48 --> Helper loaded: my_helper
INFO - 2023-09-22 13:44:48 --> Database Driver Class Initialized
INFO - 2023-09-22 13:44:48 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-22 13:44:48 --> Controller Class Initialized
INFO - 2023-09-22 13:44:50 --> Config Class Initialized
INFO - 2023-09-22 13:44:50 --> Hooks Class Initialized
DEBUG - 2023-09-22 13:44:50 --> UTF-8 Support Enabled
INFO - 2023-09-22 13:44:50 --> Utf8 Class Initialized
INFO - 2023-09-22 13:44:50 --> URI Class Initialized
INFO - 2023-09-22 13:44:50 --> Router Class Initialized
INFO - 2023-09-22 13:44:50 --> Output Class Initialized
INFO - 2023-09-22 13:44:50 --> Security Class Initialized
DEBUG - 2023-09-22 13:44:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-22 13:44:50 --> Input Class Initialized
INFO - 2023-09-22 13:44:50 --> Language Class Initialized
INFO - 2023-09-22 13:44:50 --> Language Class Initialized
INFO - 2023-09-22 13:44:50 --> Config Class Initialized
INFO - 2023-09-22 13:44:50 --> Loader Class Initialized
INFO - 2023-09-22 13:44:50 --> Helper loaded: url_helper
INFO - 2023-09-22 13:44:50 --> Helper loaded: file_helper
INFO - 2023-09-22 13:44:50 --> Helper loaded: form_helper
INFO - 2023-09-22 13:44:50 --> Helper loaded: my_helper
INFO - 2023-09-22 13:44:50 --> Database Driver Class Initialized
INFO - 2023-09-22 13:44:50 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-22 13:44:50 --> Controller Class Initialized
INFO - 2023-09-22 13:44:50 --> Final output sent to browser
DEBUG - 2023-09-22 13:44:50 --> Total execution time: 0.0758
INFO - 2023-09-22 13:45:08 --> Config Class Initialized
INFO - 2023-09-22 13:45:08 --> Hooks Class Initialized
DEBUG - 2023-09-22 13:45:08 --> UTF-8 Support Enabled
INFO - 2023-09-22 13:45:08 --> Utf8 Class Initialized
INFO - 2023-09-22 13:45:08 --> URI Class Initialized
INFO - 2023-09-22 13:45:08 --> Router Class Initialized
INFO - 2023-09-22 13:45:08 --> Output Class Initialized
INFO - 2023-09-22 13:45:08 --> Security Class Initialized
DEBUG - 2023-09-22 13:45:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-22 13:45:08 --> Input Class Initialized
INFO - 2023-09-22 13:45:08 --> Language Class Initialized
INFO - 2023-09-22 13:45:08 --> Language Class Initialized
INFO - 2023-09-22 13:45:08 --> Config Class Initialized
INFO - 2023-09-22 13:45:08 --> Loader Class Initialized
INFO - 2023-09-22 13:45:08 --> Helper loaded: url_helper
INFO - 2023-09-22 13:45:08 --> Helper loaded: file_helper
INFO - 2023-09-22 13:45:08 --> Helper loaded: form_helper
INFO - 2023-09-22 13:45:08 --> Helper loaded: my_helper
INFO - 2023-09-22 13:45:08 --> Database Driver Class Initialized
INFO - 2023-09-22 13:45:08 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-22 13:45:08 --> Controller Class Initialized
INFO - 2023-09-22 13:45:08 --> Final output sent to browser
DEBUG - 2023-09-22 13:45:08 --> Total execution time: 0.0375
INFO - 2023-09-22 13:45:08 --> Config Class Initialized
INFO - 2023-09-22 13:45:08 --> Hooks Class Initialized
DEBUG - 2023-09-22 13:45:08 --> UTF-8 Support Enabled
INFO - 2023-09-22 13:45:08 --> Utf8 Class Initialized
INFO - 2023-09-22 13:45:08 --> URI Class Initialized
INFO - 2023-09-22 13:45:08 --> Router Class Initialized
INFO - 2023-09-22 13:45:08 --> Output Class Initialized
INFO - 2023-09-22 13:45:08 --> Security Class Initialized
DEBUG - 2023-09-22 13:45:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-22 13:45:08 --> Input Class Initialized
INFO - 2023-09-22 13:45:08 --> Language Class Initialized
INFO - 2023-09-22 13:45:08 --> Language Class Initialized
INFO - 2023-09-22 13:45:08 --> Config Class Initialized
INFO - 2023-09-22 13:45:08 --> Loader Class Initialized
INFO - 2023-09-22 13:45:08 --> Helper loaded: url_helper
INFO - 2023-09-22 13:45:08 --> Helper loaded: file_helper
INFO - 2023-09-22 13:45:08 --> Helper loaded: form_helper
INFO - 2023-09-22 13:45:08 --> Helper loaded: my_helper
INFO - 2023-09-22 13:45:08 --> Database Driver Class Initialized
INFO - 2023-09-22 13:45:08 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-22 13:45:08 --> Controller Class Initialized
INFO - 2023-09-22 13:45:09 --> Config Class Initialized
INFO - 2023-09-22 13:45:09 --> Hooks Class Initialized
DEBUG - 2023-09-22 13:45:09 --> UTF-8 Support Enabled
INFO - 2023-09-22 13:45:09 --> Utf8 Class Initialized
INFO - 2023-09-22 13:45:09 --> URI Class Initialized
INFO - 2023-09-22 13:45:09 --> Router Class Initialized
INFO - 2023-09-22 13:45:09 --> Output Class Initialized
INFO - 2023-09-22 13:45:09 --> Security Class Initialized
DEBUG - 2023-09-22 13:45:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-22 13:45:09 --> Input Class Initialized
INFO - 2023-09-22 13:45:09 --> Language Class Initialized
INFO - 2023-09-22 13:45:09 --> Language Class Initialized
INFO - 2023-09-22 13:45:09 --> Config Class Initialized
INFO - 2023-09-22 13:45:09 --> Loader Class Initialized
INFO - 2023-09-22 13:45:09 --> Helper loaded: url_helper
INFO - 2023-09-22 13:45:09 --> Helper loaded: file_helper
INFO - 2023-09-22 13:45:09 --> Helper loaded: form_helper
INFO - 2023-09-22 13:45:09 --> Helper loaded: my_helper
INFO - 2023-09-22 13:45:09 --> Database Driver Class Initialized
INFO - 2023-09-22 13:45:09 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-22 13:45:09 --> Controller Class Initialized
INFO - 2023-09-22 13:45:09 --> Final output sent to browser
DEBUG - 2023-09-22 13:45:09 --> Total execution time: 0.0535
INFO - 2023-09-22 13:45:23 --> Config Class Initialized
INFO - 2023-09-22 13:45:23 --> Hooks Class Initialized
DEBUG - 2023-09-22 13:45:23 --> UTF-8 Support Enabled
INFO - 2023-09-22 13:45:23 --> Utf8 Class Initialized
INFO - 2023-09-22 13:45:23 --> URI Class Initialized
INFO - 2023-09-22 13:45:23 --> Router Class Initialized
INFO - 2023-09-22 13:45:23 --> Output Class Initialized
INFO - 2023-09-22 13:45:23 --> Security Class Initialized
DEBUG - 2023-09-22 13:45:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-22 13:45:23 --> Input Class Initialized
INFO - 2023-09-22 13:45:23 --> Language Class Initialized
INFO - 2023-09-22 13:45:23 --> Language Class Initialized
INFO - 2023-09-22 13:45:23 --> Config Class Initialized
INFO - 2023-09-22 13:45:23 --> Loader Class Initialized
INFO - 2023-09-22 13:45:23 --> Helper loaded: url_helper
INFO - 2023-09-22 13:45:23 --> Helper loaded: file_helper
INFO - 2023-09-22 13:45:23 --> Helper loaded: form_helper
INFO - 2023-09-22 13:45:23 --> Helper loaded: my_helper
INFO - 2023-09-22 13:45:23 --> Database Driver Class Initialized
INFO - 2023-09-22 13:45:23 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-22 13:45:23 --> Controller Class Initialized
INFO - 2023-09-22 13:45:23 --> Final output sent to browser
DEBUG - 2023-09-22 13:45:23 --> Total execution time: 0.0816
INFO - 2023-09-22 13:45:23 --> Config Class Initialized
INFO - 2023-09-22 13:45:23 --> Hooks Class Initialized
DEBUG - 2023-09-22 13:45:23 --> UTF-8 Support Enabled
INFO - 2023-09-22 13:45:23 --> Utf8 Class Initialized
INFO - 2023-09-22 13:45:23 --> URI Class Initialized
INFO - 2023-09-22 13:45:23 --> Router Class Initialized
INFO - 2023-09-22 13:45:23 --> Output Class Initialized
INFO - 2023-09-22 13:45:23 --> Security Class Initialized
DEBUG - 2023-09-22 13:45:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-22 13:45:23 --> Input Class Initialized
INFO - 2023-09-22 13:45:23 --> Language Class Initialized
INFO - 2023-09-22 13:45:23 --> Language Class Initialized
INFO - 2023-09-22 13:45:23 --> Config Class Initialized
INFO - 2023-09-22 13:45:23 --> Loader Class Initialized
INFO - 2023-09-22 13:45:23 --> Helper loaded: url_helper
INFO - 2023-09-22 13:45:23 --> Helper loaded: file_helper
INFO - 2023-09-22 13:45:23 --> Helper loaded: form_helper
INFO - 2023-09-22 13:45:23 --> Helper loaded: my_helper
INFO - 2023-09-22 13:45:23 --> Database Driver Class Initialized
INFO - 2023-09-22 13:45:23 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-22 13:45:23 --> Controller Class Initialized
INFO - 2023-09-22 13:45:26 --> Config Class Initialized
INFO - 2023-09-22 13:45:26 --> Hooks Class Initialized
DEBUG - 2023-09-22 13:45:26 --> UTF-8 Support Enabled
INFO - 2023-09-22 13:45:26 --> Utf8 Class Initialized
INFO - 2023-09-22 13:45:26 --> URI Class Initialized
INFO - 2023-09-22 13:45:26 --> Router Class Initialized
INFO - 2023-09-22 13:45:26 --> Output Class Initialized
INFO - 2023-09-22 13:45:26 --> Security Class Initialized
DEBUG - 2023-09-22 13:45:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-22 13:45:26 --> Input Class Initialized
INFO - 2023-09-22 13:45:26 --> Language Class Initialized
INFO - 2023-09-22 13:45:26 --> Language Class Initialized
INFO - 2023-09-22 13:45:26 --> Config Class Initialized
INFO - 2023-09-22 13:45:26 --> Loader Class Initialized
INFO - 2023-09-22 13:45:26 --> Helper loaded: url_helper
INFO - 2023-09-22 13:45:26 --> Helper loaded: file_helper
INFO - 2023-09-22 13:45:26 --> Helper loaded: form_helper
INFO - 2023-09-22 13:45:26 --> Helper loaded: my_helper
INFO - 2023-09-22 13:45:26 --> Database Driver Class Initialized
INFO - 2023-09-22 13:45:26 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-22 13:45:26 --> Controller Class Initialized
INFO - 2023-09-22 13:45:26 --> Final output sent to browser
DEBUG - 2023-09-22 13:45:26 --> Total execution time: 0.0424
INFO - 2023-09-22 13:45:40 --> Config Class Initialized
INFO - 2023-09-22 13:45:40 --> Hooks Class Initialized
DEBUG - 2023-09-22 13:45:40 --> UTF-8 Support Enabled
INFO - 2023-09-22 13:45:40 --> Utf8 Class Initialized
INFO - 2023-09-22 13:45:40 --> URI Class Initialized
INFO - 2023-09-22 13:45:40 --> Router Class Initialized
INFO - 2023-09-22 13:45:40 --> Output Class Initialized
INFO - 2023-09-22 13:45:40 --> Security Class Initialized
DEBUG - 2023-09-22 13:45:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-22 13:45:40 --> Input Class Initialized
INFO - 2023-09-22 13:45:40 --> Language Class Initialized
INFO - 2023-09-22 13:45:40 --> Language Class Initialized
INFO - 2023-09-22 13:45:40 --> Config Class Initialized
INFO - 2023-09-22 13:45:40 --> Loader Class Initialized
INFO - 2023-09-22 13:45:40 --> Helper loaded: url_helper
INFO - 2023-09-22 13:45:40 --> Helper loaded: file_helper
INFO - 2023-09-22 13:45:40 --> Helper loaded: form_helper
INFO - 2023-09-22 13:45:40 --> Helper loaded: my_helper
INFO - 2023-09-22 13:45:40 --> Database Driver Class Initialized
INFO - 2023-09-22 13:45:40 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-22 13:45:40 --> Controller Class Initialized
INFO - 2023-09-22 13:45:40 --> Final output sent to browser
DEBUG - 2023-09-22 13:45:40 --> Total execution time: 0.0348
INFO - 2023-09-22 13:45:40 --> Config Class Initialized
INFO - 2023-09-22 13:45:40 --> Hooks Class Initialized
DEBUG - 2023-09-22 13:45:40 --> UTF-8 Support Enabled
INFO - 2023-09-22 13:45:40 --> Utf8 Class Initialized
INFO - 2023-09-22 13:45:40 --> URI Class Initialized
INFO - 2023-09-22 13:45:40 --> Router Class Initialized
INFO - 2023-09-22 13:45:40 --> Output Class Initialized
INFO - 2023-09-22 13:45:40 --> Security Class Initialized
DEBUG - 2023-09-22 13:45:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-22 13:45:40 --> Input Class Initialized
INFO - 2023-09-22 13:45:40 --> Language Class Initialized
INFO - 2023-09-22 13:45:40 --> Language Class Initialized
INFO - 2023-09-22 13:45:40 --> Config Class Initialized
INFO - 2023-09-22 13:45:40 --> Loader Class Initialized
INFO - 2023-09-22 13:45:40 --> Helper loaded: url_helper
INFO - 2023-09-22 13:45:40 --> Helper loaded: file_helper
INFO - 2023-09-22 13:45:40 --> Helper loaded: form_helper
INFO - 2023-09-22 13:45:40 --> Helper loaded: my_helper
INFO - 2023-09-22 13:45:40 --> Database Driver Class Initialized
INFO - 2023-09-22 13:45:40 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-22 13:45:40 --> Controller Class Initialized
INFO - 2023-09-22 13:45:41 --> Config Class Initialized
INFO - 2023-09-22 13:45:41 --> Hooks Class Initialized
DEBUG - 2023-09-22 13:45:41 --> UTF-8 Support Enabled
INFO - 2023-09-22 13:45:41 --> Utf8 Class Initialized
INFO - 2023-09-22 13:45:41 --> URI Class Initialized
INFO - 2023-09-22 13:45:41 --> Router Class Initialized
INFO - 2023-09-22 13:45:41 --> Output Class Initialized
INFO - 2023-09-22 13:45:41 --> Security Class Initialized
DEBUG - 2023-09-22 13:45:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-22 13:45:41 --> Input Class Initialized
INFO - 2023-09-22 13:45:41 --> Language Class Initialized
INFO - 2023-09-22 13:45:41 --> Language Class Initialized
INFO - 2023-09-22 13:45:41 --> Config Class Initialized
INFO - 2023-09-22 13:45:41 --> Loader Class Initialized
INFO - 2023-09-22 13:45:41 --> Helper loaded: url_helper
INFO - 2023-09-22 13:45:41 --> Helper loaded: file_helper
INFO - 2023-09-22 13:45:41 --> Helper loaded: form_helper
INFO - 2023-09-22 13:45:41 --> Helper loaded: my_helper
INFO - 2023-09-22 13:45:41 --> Database Driver Class Initialized
INFO - 2023-09-22 13:45:41 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-22 13:45:41 --> Controller Class Initialized
INFO - 2023-09-22 13:45:41 --> Final output sent to browser
DEBUG - 2023-09-22 13:45:41 --> Total execution time: 0.0742
INFO - 2023-09-22 13:45:54 --> Config Class Initialized
INFO - 2023-09-22 13:45:54 --> Hooks Class Initialized
DEBUG - 2023-09-22 13:45:54 --> UTF-8 Support Enabled
INFO - 2023-09-22 13:45:54 --> Utf8 Class Initialized
INFO - 2023-09-22 13:45:54 --> URI Class Initialized
INFO - 2023-09-22 13:45:54 --> Router Class Initialized
INFO - 2023-09-22 13:45:54 --> Output Class Initialized
INFO - 2023-09-22 13:45:54 --> Security Class Initialized
DEBUG - 2023-09-22 13:45:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-22 13:45:54 --> Input Class Initialized
INFO - 2023-09-22 13:45:54 --> Language Class Initialized
INFO - 2023-09-22 13:45:54 --> Language Class Initialized
INFO - 2023-09-22 13:45:54 --> Config Class Initialized
INFO - 2023-09-22 13:45:54 --> Loader Class Initialized
INFO - 2023-09-22 13:45:54 --> Helper loaded: url_helper
INFO - 2023-09-22 13:45:54 --> Helper loaded: file_helper
INFO - 2023-09-22 13:45:54 --> Helper loaded: form_helper
INFO - 2023-09-22 13:45:54 --> Helper loaded: my_helper
INFO - 2023-09-22 13:45:54 --> Database Driver Class Initialized
INFO - 2023-09-22 13:45:54 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-22 13:45:54 --> Controller Class Initialized
INFO - 2023-09-22 13:45:54 --> Final output sent to browser
DEBUG - 2023-09-22 13:45:54 --> Total execution time: 0.0357
INFO - 2023-09-22 13:45:54 --> Config Class Initialized
INFO - 2023-09-22 13:45:54 --> Hooks Class Initialized
DEBUG - 2023-09-22 13:45:54 --> UTF-8 Support Enabled
INFO - 2023-09-22 13:45:54 --> Utf8 Class Initialized
INFO - 2023-09-22 13:45:54 --> URI Class Initialized
INFO - 2023-09-22 13:45:54 --> Router Class Initialized
INFO - 2023-09-22 13:45:54 --> Output Class Initialized
INFO - 2023-09-22 13:45:54 --> Security Class Initialized
DEBUG - 2023-09-22 13:45:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-22 13:45:54 --> Input Class Initialized
INFO - 2023-09-22 13:45:54 --> Language Class Initialized
INFO - 2023-09-22 13:45:54 --> Language Class Initialized
INFO - 2023-09-22 13:45:54 --> Config Class Initialized
INFO - 2023-09-22 13:45:54 --> Loader Class Initialized
INFO - 2023-09-22 13:45:54 --> Helper loaded: url_helper
INFO - 2023-09-22 13:45:54 --> Helper loaded: file_helper
INFO - 2023-09-22 13:45:54 --> Helper loaded: form_helper
INFO - 2023-09-22 13:45:54 --> Helper loaded: my_helper
INFO - 2023-09-22 13:45:54 --> Database Driver Class Initialized
INFO - 2023-09-22 13:45:54 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-22 13:45:54 --> Controller Class Initialized
INFO - 2023-09-22 13:46:03 --> Config Class Initialized
INFO - 2023-09-22 13:46:03 --> Hooks Class Initialized
DEBUG - 2023-09-22 13:46:03 --> UTF-8 Support Enabled
INFO - 2023-09-22 13:46:03 --> Utf8 Class Initialized
INFO - 2023-09-22 13:46:03 --> URI Class Initialized
INFO - 2023-09-22 13:46:03 --> Router Class Initialized
INFO - 2023-09-22 13:46:03 --> Output Class Initialized
INFO - 2023-09-22 13:46:03 --> Security Class Initialized
DEBUG - 2023-09-22 13:46:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-22 13:46:03 --> Input Class Initialized
INFO - 2023-09-22 13:46:03 --> Language Class Initialized
INFO - 2023-09-22 13:46:03 --> Language Class Initialized
INFO - 2023-09-22 13:46:03 --> Config Class Initialized
INFO - 2023-09-22 13:46:03 --> Loader Class Initialized
INFO - 2023-09-22 13:46:03 --> Helper loaded: url_helper
INFO - 2023-09-22 13:46:03 --> Helper loaded: file_helper
INFO - 2023-09-22 13:46:03 --> Helper loaded: form_helper
INFO - 2023-09-22 13:46:03 --> Helper loaded: my_helper
INFO - 2023-09-22 13:46:03 --> Database Driver Class Initialized
INFO - 2023-09-22 13:46:03 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-22 13:46:03 --> Controller Class Initialized
INFO - 2023-09-22 13:46:03 --> Final output sent to browser
DEBUG - 2023-09-22 13:46:03 --> Total execution time: 0.0328
INFO - 2023-09-22 13:46:16 --> Config Class Initialized
INFO - 2023-09-22 13:46:16 --> Hooks Class Initialized
DEBUG - 2023-09-22 13:46:16 --> UTF-8 Support Enabled
INFO - 2023-09-22 13:46:16 --> Utf8 Class Initialized
INFO - 2023-09-22 13:46:16 --> URI Class Initialized
INFO - 2023-09-22 13:46:16 --> Router Class Initialized
INFO - 2023-09-22 13:46:16 --> Output Class Initialized
INFO - 2023-09-22 13:46:16 --> Security Class Initialized
DEBUG - 2023-09-22 13:46:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-22 13:46:16 --> Input Class Initialized
INFO - 2023-09-22 13:46:16 --> Language Class Initialized
INFO - 2023-09-22 13:46:16 --> Language Class Initialized
INFO - 2023-09-22 13:46:16 --> Config Class Initialized
INFO - 2023-09-22 13:46:16 --> Loader Class Initialized
INFO - 2023-09-22 13:46:16 --> Helper loaded: url_helper
INFO - 2023-09-22 13:46:16 --> Helper loaded: file_helper
INFO - 2023-09-22 13:46:16 --> Helper loaded: form_helper
INFO - 2023-09-22 13:46:16 --> Helper loaded: my_helper
INFO - 2023-09-22 13:46:16 --> Database Driver Class Initialized
INFO - 2023-09-22 13:46:16 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-22 13:46:16 --> Controller Class Initialized
INFO - 2023-09-22 13:46:17 --> Final output sent to browser
DEBUG - 2023-09-22 13:46:17 --> Total execution time: 0.0986
INFO - 2023-09-22 13:46:17 --> Config Class Initialized
INFO - 2023-09-22 13:46:17 --> Hooks Class Initialized
DEBUG - 2023-09-22 13:46:17 --> UTF-8 Support Enabled
INFO - 2023-09-22 13:46:17 --> Utf8 Class Initialized
INFO - 2023-09-22 13:46:17 --> URI Class Initialized
INFO - 2023-09-22 13:46:17 --> Router Class Initialized
INFO - 2023-09-22 13:46:17 --> Output Class Initialized
INFO - 2023-09-22 13:46:17 --> Security Class Initialized
DEBUG - 2023-09-22 13:46:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-22 13:46:17 --> Input Class Initialized
INFO - 2023-09-22 13:46:17 --> Language Class Initialized
INFO - 2023-09-22 13:46:17 --> Language Class Initialized
INFO - 2023-09-22 13:46:17 --> Config Class Initialized
INFO - 2023-09-22 13:46:17 --> Loader Class Initialized
INFO - 2023-09-22 13:46:17 --> Helper loaded: url_helper
INFO - 2023-09-22 13:46:17 --> Helper loaded: file_helper
INFO - 2023-09-22 13:46:17 --> Helper loaded: form_helper
INFO - 2023-09-22 13:46:17 --> Helper loaded: my_helper
INFO - 2023-09-22 13:46:17 --> Database Driver Class Initialized
INFO - 2023-09-22 13:46:17 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-22 13:46:17 --> Controller Class Initialized
INFO - 2023-09-22 13:46:21 --> Config Class Initialized
INFO - 2023-09-22 13:46:21 --> Hooks Class Initialized
DEBUG - 2023-09-22 13:46:21 --> UTF-8 Support Enabled
INFO - 2023-09-22 13:46:21 --> Utf8 Class Initialized
INFO - 2023-09-22 13:46:21 --> URI Class Initialized
INFO - 2023-09-22 13:46:21 --> Router Class Initialized
INFO - 2023-09-22 13:46:21 --> Output Class Initialized
INFO - 2023-09-22 13:46:21 --> Security Class Initialized
DEBUG - 2023-09-22 13:46:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-22 13:46:21 --> Input Class Initialized
INFO - 2023-09-22 13:46:21 --> Language Class Initialized
INFO - 2023-09-22 13:46:21 --> Language Class Initialized
INFO - 2023-09-22 13:46:21 --> Config Class Initialized
INFO - 2023-09-22 13:46:21 --> Loader Class Initialized
INFO - 2023-09-22 13:46:21 --> Helper loaded: url_helper
INFO - 2023-09-22 13:46:21 --> Helper loaded: file_helper
INFO - 2023-09-22 13:46:21 --> Helper loaded: form_helper
INFO - 2023-09-22 13:46:21 --> Helper loaded: my_helper
INFO - 2023-09-22 13:46:21 --> Database Driver Class Initialized
INFO - 2023-09-22 13:46:21 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-22 13:46:21 --> Controller Class Initialized
INFO - 2023-09-22 13:46:21 --> Final output sent to browser
DEBUG - 2023-09-22 13:46:21 --> Total execution time: 0.0405
INFO - 2023-09-22 13:46:38 --> Config Class Initialized
INFO - 2023-09-22 13:46:38 --> Hooks Class Initialized
DEBUG - 2023-09-22 13:46:38 --> UTF-8 Support Enabled
INFO - 2023-09-22 13:46:38 --> Utf8 Class Initialized
INFO - 2023-09-22 13:46:38 --> URI Class Initialized
INFO - 2023-09-22 13:46:38 --> Router Class Initialized
INFO - 2023-09-22 13:46:38 --> Output Class Initialized
INFO - 2023-09-22 13:46:38 --> Security Class Initialized
DEBUG - 2023-09-22 13:46:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-22 13:46:38 --> Input Class Initialized
INFO - 2023-09-22 13:46:38 --> Language Class Initialized
INFO - 2023-09-22 13:46:38 --> Language Class Initialized
INFO - 2023-09-22 13:46:38 --> Config Class Initialized
INFO - 2023-09-22 13:46:38 --> Loader Class Initialized
INFO - 2023-09-22 13:46:38 --> Helper loaded: url_helper
INFO - 2023-09-22 13:46:38 --> Helper loaded: file_helper
INFO - 2023-09-22 13:46:38 --> Helper loaded: form_helper
INFO - 2023-09-22 13:46:38 --> Helper loaded: my_helper
INFO - 2023-09-22 13:46:38 --> Database Driver Class Initialized
INFO - 2023-09-22 13:46:38 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-22 13:46:38 --> Controller Class Initialized
INFO - 2023-09-22 13:46:38 --> Final output sent to browser
DEBUG - 2023-09-22 13:46:38 --> Total execution time: 0.0761
INFO - 2023-09-22 13:46:38 --> Config Class Initialized
INFO - 2023-09-22 13:46:38 --> Hooks Class Initialized
DEBUG - 2023-09-22 13:46:38 --> UTF-8 Support Enabled
INFO - 2023-09-22 13:46:38 --> Utf8 Class Initialized
INFO - 2023-09-22 13:46:38 --> URI Class Initialized
INFO - 2023-09-22 13:46:38 --> Router Class Initialized
INFO - 2023-09-22 13:46:38 --> Output Class Initialized
INFO - 2023-09-22 13:46:38 --> Security Class Initialized
DEBUG - 2023-09-22 13:46:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-22 13:46:38 --> Input Class Initialized
INFO - 2023-09-22 13:46:38 --> Language Class Initialized
INFO - 2023-09-22 13:46:38 --> Language Class Initialized
INFO - 2023-09-22 13:46:38 --> Config Class Initialized
INFO - 2023-09-22 13:46:38 --> Loader Class Initialized
INFO - 2023-09-22 13:46:38 --> Helper loaded: url_helper
INFO - 2023-09-22 13:46:38 --> Helper loaded: file_helper
INFO - 2023-09-22 13:46:38 --> Helper loaded: form_helper
INFO - 2023-09-22 13:46:38 --> Helper loaded: my_helper
INFO - 2023-09-22 13:46:38 --> Database Driver Class Initialized
INFO - 2023-09-22 13:46:38 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-22 13:46:38 --> Controller Class Initialized
INFO - 2023-09-22 13:46:39 --> Config Class Initialized
INFO - 2023-09-22 13:46:39 --> Hooks Class Initialized
DEBUG - 2023-09-22 13:46:39 --> UTF-8 Support Enabled
INFO - 2023-09-22 13:46:39 --> Utf8 Class Initialized
INFO - 2023-09-22 13:46:39 --> URI Class Initialized
INFO - 2023-09-22 13:46:39 --> Router Class Initialized
INFO - 2023-09-22 13:46:39 --> Output Class Initialized
INFO - 2023-09-22 13:46:39 --> Security Class Initialized
DEBUG - 2023-09-22 13:46:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-22 13:46:39 --> Input Class Initialized
INFO - 2023-09-22 13:46:39 --> Language Class Initialized
INFO - 2023-09-22 13:46:39 --> Language Class Initialized
INFO - 2023-09-22 13:46:39 --> Config Class Initialized
INFO - 2023-09-22 13:46:39 --> Loader Class Initialized
INFO - 2023-09-22 13:46:39 --> Helper loaded: url_helper
INFO - 2023-09-22 13:46:39 --> Helper loaded: file_helper
INFO - 2023-09-22 13:46:39 --> Helper loaded: form_helper
INFO - 2023-09-22 13:46:39 --> Helper loaded: my_helper
INFO - 2023-09-22 13:46:39 --> Database Driver Class Initialized
INFO - 2023-09-22 13:46:39 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-22 13:46:39 --> Controller Class Initialized
INFO - 2023-09-22 13:46:39 --> Final output sent to browser
DEBUG - 2023-09-22 13:46:39 --> Total execution time: 0.0419
INFO - 2023-09-22 13:46:58 --> Config Class Initialized
INFO - 2023-09-22 13:46:58 --> Hooks Class Initialized
DEBUG - 2023-09-22 13:46:58 --> UTF-8 Support Enabled
INFO - 2023-09-22 13:46:58 --> Utf8 Class Initialized
INFO - 2023-09-22 13:46:58 --> URI Class Initialized
INFO - 2023-09-22 13:46:58 --> Router Class Initialized
INFO - 2023-09-22 13:46:58 --> Output Class Initialized
INFO - 2023-09-22 13:46:58 --> Security Class Initialized
DEBUG - 2023-09-22 13:46:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-22 13:46:58 --> Input Class Initialized
INFO - 2023-09-22 13:46:58 --> Language Class Initialized
INFO - 2023-09-22 13:46:58 --> Language Class Initialized
INFO - 2023-09-22 13:46:58 --> Config Class Initialized
INFO - 2023-09-22 13:46:58 --> Loader Class Initialized
INFO - 2023-09-22 13:46:58 --> Helper loaded: url_helper
INFO - 2023-09-22 13:46:58 --> Helper loaded: file_helper
INFO - 2023-09-22 13:46:58 --> Helper loaded: form_helper
INFO - 2023-09-22 13:46:58 --> Helper loaded: my_helper
INFO - 2023-09-22 13:46:58 --> Database Driver Class Initialized
INFO - 2023-09-22 13:46:58 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-22 13:46:58 --> Controller Class Initialized
INFO - 2023-09-22 13:46:58 --> Final output sent to browser
DEBUG - 2023-09-22 13:46:58 --> Total execution time: 0.1185
INFO - 2023-09-22 13:46:58 --> Config Class Initialized
INFO - 2023-09-22 13:46:58 --> Hooks Class Initialized
DEBUG - 2023-09-22 13:46:58 --> UTF-8 Support Enabled
INFO - 2023-09-22 13:46:58 --> Utf8 Class Initialized
INFO - 2023-09-22 13:46:58 --> URI Class Initialized
INFO - 2023-09-22 13:46:58 --> Router Class Initialized
INFO - 2023-09-22 13:46:58 --> Output Class Initialized
INFO - 2023-09-22 13:46:58 --> Security Class Initialized
DEBUG - 2023-09-22 13:46:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-22 13:46:58 --> Input Class Initialized
INFO - 2023-09-22 13:46:58 --> Language Class Initialized
INFO - 2023-09-22 13:46:58 --> Language Class Initialized
INFO - 2023-09-22 13:46:58 --> Config Class Initialized
INFO - 2023-09-22 13:46:58 --> Loader Class Initialized
INFO - 2023-09-22 13:46:58 --> Helper loaded: url_helper
INFO - 2023-09-22 13:46:58 --> Helper loaded: file_helper
INFO - 2023-09-22 13:46:58 --> Helper loaded: form_helper
INFO - 2023-09-22 13:46:58 --> Helper loaded: my_helper
INFO - 2023-09-22 13:46:58 --> Database Driver Class Initialized
INFO - 2023-09-22 13:46:58 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-22 13:46:58 --> Controller Class Initialized
INFO - 2023-09-22 13:48:08 --> Config Class Initialized
INFO - 2023-09-22 13:48:08 --> Hooks Class Initialized
DEBUG - 2023-09-22 13:48:08 --> UTF-8 Support Enabled
INFO - 2023-09-22 13:48:08 --> Utf8 Class Initialized
INFO - 2023-09-22 13:48:08 --> URI Class Initialized
INFO - 2023-09-22 13:48:08 --> Router Class Initialized
INFO - 2023-09-22 13:48:08 --> Output Class Initialized
INFO - 2023-09-22 13:48:08 --> Security Class Initialized
DEBUG - 2023-09-22 13:48:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-22 13:48:08 --> Input Class Initialized
INFO - 2023-09-22 13:48:08 --> Language Class Initialized
INFO - 2023-09-22 13:48:08 --> Language Class Initialized
INFO - 2023-09-22 13:48:08 --> Config Class Initialized
INFO - 2023-09-22 13:48:08 --> Loader Class Initialized
INFO - 2023-09-22 13:48:08 --> Helper loaded: url_helper
INFO - 2023-09-22 13:48:08 --> Helper loaded: file_helper
INFO - 2023-09-22 13:48:08 --> Helper loaded: form_helper
INFO - 2023-09-22 13:48:08 --> Helper loaded: my_helper
INFO - 2023-09-22 13:48:08 --> Database Driver Class Initialized
INFO - 2023-09-22 13:48:08 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-22 13:48:08 --> Controller Class Initialized
INFO - 2023-09-22 13:48:08 --> Final output sent to browser
DEBUG - 2023-09-22 13:48:08 --> Total execution time: 0.0392
INFO - 2023-09-22 13:50:33 --> Config Class Initialized
INFO - 2023-09-22 13:50:33 --> Hooks Class Initialized
DEBUG - 2023-09-22 13:50:33 --> UTF-8 Support Enabled
INFO - 2023-09-22 13:50:33 --> Utf8 Class Initialized
INFO - 2023-09-22 13:50:33 --> URI Class Initialized
INFO - 2023-09-22 13:50:33 --> Router Class Initialized
INFO - 2023-09-22 13:50:33 --> Output Class Initialized
INFO - 2023-09-22 13:50:33 --> Security Class Initialized
DEBUG - 2023-09-22 13:50:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-22 13:50:33 --> Input Class Initialized
INFO - 2023-09-22 13:50:33 --> Language Class Initialized
INFO - 2023-09-22 13:50:33 --> Language Class Initialized
INFO - 2023-09-22 13:50:33 --> Config Class Initialized
INFO - 2023-09-22 13:50:33 --> Loader Class Initialized
INFO - 2023-09-22 13:50:33 --> Helper loaded: url_helper
INFO - 2023-09-22 13:50:33 --> Helper loaded: file_helper
INFO - 2023-09-22 13:50:33 --> Helper loaded: form_helper
INFO - 2023-09-22 13:50:33 --> Helper loaded: my_helper
INFO - 2023-09-22 13:50:33 --> Database Driver Class Initialized
INFO - 2023-09-22 13:50:33 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-22 13:50:33 --> Controller Class Initialized
INFO - 2023-09-22 13:50:33 --> Final output sent to browser
DEBUG - 2023-09-22 13:50:33 --> Total execution time: 0.0333
INFO - 2023-09-22 13:50:44 --> Config Class Initialized
INFO - 2023-09-22 13:50:44 --> Hooks Class Initialized
DEBUG - 2023-09-22 13:50:44 --> UTF-8 Support Enabled
INFO - 2023-09-22 13:50:44 --> Utf8 Class Initialized
INFO - 2023-09-22 13:50:44 --> URI Class Initialized
INFO - 2023-09-22 13:50:44 --> Router Class Initialized
INFO - 2023-09-22 13:50:44 --> Output Class Initialized
INFO - 2023-09-22 13:50:44 --> Security Class Initialized
DEBUG - 2023-09-22 13:50:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-22 13:50:44 --> Input Class Initialized
INFO - 2023-09-22 13:50:44 --> Language Class Initialized
INFO - 2023-09-22 13:50:44 --> Language Class Initialized
INFO - 2023-09-22 13:50:44 --> Config Class Initialized
INFO - 2023-09-22 13:50:44 --> Loader Class Initialized
INFO - 2023-09-22 13:50:44 --> Helper loaded: url_helper
INFO - 2023-09-22 13:50:44 --> Helper loaded: file_helper
INFO - 2023-09-22 13:50:44 --> Helper loaded: form_helper
INFO - 2023-09-22 13:50:44 --> Helper loaded: my_helper
INFO - 2023-09-22 13:50:44 --> Database Driver Class Initialized
INFO - 2023-09-22 13:50:44 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-22 13:50:44 --> Controller Class Initialized
INFO - 2023-09-22 13:50:44 --> Final output sent to browser
DEBUG - 2023-09-22 13:50:44 --> Total execution time: 0.0468
INFO - 2023-09-22 13:50:44 --> Config Class Initialized
INFO - 2023-09-22 13:50:44 --> Hooks Class Initialized
DEBUG - 2023-09-22 13:50:44 --> UTF-8 Support Enabled
INFO - 2023-09-22 13:50:44 --> Utf8 Class Initialized
INFO - 2023-09-22 13:50:44 --> URI Class Initialized
INFO - 2023-09-22 13:50:44 --> Router Class Initialized
INFO - 2023-09-22 13:50:44 --> Output Class Initialized
INFO - 2023-09-22 13:50:44 --> Security Class Initialized
DEBUG - 2023-09-22 13:50:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-22 13:50:44 --> Input Class Initialized
INFO - 2023-09-22 13:50:44 --> Language Class Initialized
INFO - 2023-09-22 13:50:44 --> Language Class Initialized
INFO - 2023-09-22 13:50:44 --> Config Class Initialized
INFO - 2023-09-22 13:50:44 --> Loader Class Initialized
INFO - 2023-09-22 13:50:44 --> Helper loaded: url_helper
INFO - 2023-09-22 13:50:44 --> Helper loaded: file_helper
INFO - 2023-09-22 13:50:44 --> Helper loaded: form_helper
INFO - 2023-09-22 13:50:44 --> Helper loaded: my_helper
INFO - 2023-09-22 13:50:44 --> Database Driver Class Initialized
INFO - 2023-09-22 13:50:44 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-22 13:50:44 --> Controller Class Initialized
INFO - 2023-09-22 13:51:09 --> Config Class Initialized
INFO - 2023-09-22 13:51:09 --> Hooks Class Initialized
DEBUG - 2023-09-22 13:51:09 --> UTF-8 Support Enabled
INFO - 2023-09-22 13:51:09 --> Utf8 Class Initialized
INFO - 2023-09-22 13:51:09 --> URI Class Initialized
INFO - 2023-09-22 13:51:09 --> Router Class Initialized
INFO - 2023-09-22 13:51:09 --> Output Class Initialized
INFO - 2023-09-22 13:51:09 --> Security Class Initialized
DEBUG - 2023-09-22 13:51:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-22 13:51:09 --> Input Class Initialized
INFO - 2023-09-22 13:51:09 --> Language Class Initialized
INFO - 2023-09-22 13:51:09 --> Language Class Initialized
INFO - 2023-09-22 13:51:09 --> Config Class Initialized
INFO - 2023-09-22 13:51:09 --> Loader Class Initialized
INFO - 2023-09-22 13:51:09 --> Helper loaded: url_helper
INFO - 2023-09-22 13:51:09 --> Helper loaded: file_helper
INFO - 2023-09-22 13:51:09 --> Helper loaded: form_helper
INFO - 2023-09-22 13:51:09 --> Helper loaded: my_helper
INFO - 2023-09-22 13:51:09 --> Database Driver Class Initialized
INFO - 2023-09-22 13:51:09 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-22 13:51:09 --> Controller Class Initialized
INFO - 2023-09-22 13:51:09 --> Final output sent to browser
DEBUG - 2023-09-22 13:51:09 --> Total execution time: 0.0479
INFO - 2023-09-22 13:51:20 --> Config Class Initialized
INFO - 2023-09-22 13:51:20 --> Hooks Class Initialized
DEBUG - 2023-09-22 13:51:20 --> UTF-8 Support Enabled
INFO - 2023-09-22 13:51:20 --> Utf8 Class Initialized
INFO - 2023-09-22 13:51:20 --> URI Class Initialized
INFO - 2023-09-22 13:51:20 --> Router Class Initialized
INFO - 2023-09-22 13:51:20 --> Output Class Initialized
INFO - 2023-09-22 13:51:20 --> Security Class Initialized
DEBUG - 2023-09-22 13:51:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-22 13:51:20 --> Input Class Initialized
INFO - 2023-09-22 13:51:20 --> Language Class Initialized
INFO - 2023-09-22 13:51:20 --> Language Class Initialized
INFO - 2023-09-22 13:51:20 --> Config Class Initialized
INFO - 2023-09-22 13:51:20 --> Loader Class Initialized
INFO - 2023-09-22 13:51:20 --> Helper loaded: url_helper
INFO - 2023-09-22 13:51:20 --> Helper loaded: file_helper
INFO - 2023-09-22 13:51:20 --> Helper loaded: form_helper
INFO - 2023-09-22 13:51:20 --> Helper loaded: my_helper
INFO - 2023-09-22 13:51:20 --> Database Driver Class Initialized
INFO - 2023-09-22 13:51:20 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-22 13:51:20 --> Controller Class Initialized
INFO - 2023-09-22 13:51:20 --> Final output sent to browser
DEBUG - 2023-09-22 13:51:20 --> Total execution time: 0.0385
INFO - 2023-09-22 13:51:20 --> Config Class Initialized
INFO - 2023-09-22 13:51:20 --> Hooks Class Initialized
DEBUG - 2023-09-22 13:51:20 --> UTF-8 Support Enabled
INFO - 2023-09-22 13:51:20 --> Utf8 Class Initialized
INFO - 2023-09-22 13:51:20 --> URI Class Initialized
INFO - 2023-09-22 13:51:20 --> Router Class Initialized
INFO - 2023-09-22 13:51:20 --> Output Class Initialized
INFO - 2023-09-22 13:51:20 --> Security Class Initialized
DEBUG - 2023-09-22 13:51:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-22 13:51:20 --> Input Class Initialized
INFO - 2023-09-22 13:51:20 --> Language Class Initialized
INFO - 2023-09-22 13:51:20 --> Language Class Initialized
INFO - 2023-09-22 13:51:20 --> Config Class Initialized
INFO - 2023-09-22 13:51:20 --> Loader Class Initialized
INFO - 2023-09-22 13:51:20 --> Helper loaded: url_helper
INFO - 2023-09-22 13:51:20 --> Helper loaded: file_helper
INFO - 2023-09-22 13:51:20 --> Helper loaded: form_helper
INFO - 2023-09-22 13:51:20 --> Helper loaded: my_helper
INFO - 2023-09-22 13:51:20 --> Database Driver Class Initialized
INFO - 2023-09-22 13:51:20 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-22 13:51:20 --> Controller Class Initialized
INFO - 2023-09-22 13:51:21 --> Config Class Initialized
INFO - 2023-09-22 13:51:21 --> Hooks Class Initialized
DEBUG - 2023-09-22 13:51:21 --> UTF-8 Support Enabled
INFO - 2023-09-22 13:51:21 --> Utf8 Class Initialized
INFO - 2023-09-22 13:51:21 --> URI Class Initialized
INFO - 2023-09-22 13:51:21 --> Router Class Initialized
INFO - 2023-09-22 13:51:21 --> Output Class Initialized
INFO - 2023-09-22 13:51:21 --> Security Class Initialized
DEBUG - 2023-09-22 13:51:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-22 13:51:21 --> Input Class Initialized
INFO - 2023-09-22 13:51:21 --> Language Class Initialized
INFO - 2023-09-22 13:51:21 --> Language Class Initialized
INFO - 2023-09-22 13:51:21 --> Config Class Initialized
INFO - 2023-09-22 13:51:21 --> Loader Class Initialized
INFO - 2023-09-22 13:51:21 --> Helper loaded: url_helper
INFO - 2023-09-22 13:51:21 --> Helper loaded: file_helper
INFO - 2023-09-22 13:51:21 --> Helper loaded: form_helper
INFO - 2023-09-22 13:51:21 --> Helper loaded: my_helper
INFO - 2023-09-22 13:51:21 --> Database Driver Class Initialized
INFO - 2023-09-22 13:51:21 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-22 13:51:21 --> Controller Class Initialized
INFO - 2023-09-22 13:51:21 --> Final output sent to browser
DEBUG - 2023-09-22 13:51:21 --> Total execution time: 0.0359
INFO - 2023-09-22 13:51:32 --> Config Class Initialized
INFO - 2023-09-22 13:51:32 --> Hooks Class Initialized
DEBUG - 2023-09-22 13:51:32 --> UTF-8 Support Enabled
INFO - 2023-09-22 13:51:32 --> Utf8 Class Initialized
INFO - 2023-09-22 13:51:32 --> URI Class Initialized
INFO - 2023-09-22 13:51:32 --> Router Class Initialized
INFO - 2023-09-22 13:51:32 --> Output Class Initialized
INFO - 2023-09-22 13:51:32 --> Security Class Initialized
DEBUG - 2023-09-22 13:51:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-22 13:51:32 --> Input Class Initialized
INFO - 2023-09-22 13:51:32 --> Language Class Initialized
INFO - 2023-09-22 13:51:32 --> Language Class Initialized
INFO - 2023-09-22 13:51:32 --> Config Class Initialized
INFO - 2023-09-22 13:51:32 --> Loader Class Initialized
INFO - 2023-09-22 13:51:32 --> Helper loaded: url_helper
INFO - 2023-09-22 13:51:32 --> Helper loaded: file_helper
INFO - 2023-09-22 13:51:32 --> Helper loaded: form_helper
INFO - 2023-09-22 13:51:32 --> Helper loaded: my_helper
INFO - 2023-09-22 13:51:32 --> Database Driver Class Initialized
INFO - 2023-09-22 13:51:32 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-22 13:51:32 --> Controller Class Initialized
INFO - 2023-09-22 13:51:32 --> Final output sent to browser
DEBUG - 2023-09-22 13:51:32 --> Total execution time: 0.0425
INFO - 2023-09-22 13:51:32 --> Config Class Initialized
INFO - 2023-09-22 13:51:32 --> Hooks Class Initialized
DEBUG - 2023-09-22 13:51:32 --> UTF-8 Support Enabled
INFO - 2023-09-22 13:51:32 --> Utf8 Class Initialized
INFO - 2023-09-22 13:51:32 --> URI Class Initialized
INFO - 2023-09-22 13:51:32 --> Router Class Initialized
INFO - 2023-09-22 13:51:32 --> Output Class Initialized
INFO - 2023-09-22 13:51:32 --> Security Class Initialized
DEBUG - 2023-09-22 13:51:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-22 13:51:32 --> Input Class Initialized
INFO - 2023-09-22 13:51:32 --> Language Class Initialized
INFO - 2023-09-22 13:51:32 --> Language Class Initialized
INFO - 2023-09-22 13:51:32 --> Config Class Initialized
INFO - 2023-09-22 13:51:32 --> Loader Class Initialized
INFO - 2023-09-22 13:51:32 --> Helper loaded: url_helper
INFO - 2023-09-22 13:51:32 --> Helper loaded: file_helper
INFO - 2023-09-22 13:51:32 --> Helper loaded: form_helper
INFO - 2023-09-22 13:51:32 --> Helper loaded: my_helper
INFO - 2023-09-22 13:51:32 --> Database Driver Class Initialized
INFO - 2023-09-22 13:51:32 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-22 13:51:32 --> Controller Class Initialized
INFO - 2023-09-22 13:51:33 --> Config Class Initialized
INFO - 2023-09-22 13:51:33 --> Hooks Class Initialized
DEBUG - 2023-09-22 13:51:33 --> UTF-8 Support Enabled
INFO - 2023-09-22 13:51:33 --> Utf8 Class Initialized
INFO - 2023-09-22 13:51:33 --> URI Class Initialized
INFO - 2023-09-22 13:51:33 --> Router Class Initialized
INFO - 2023-09-22 13:51:33 --> Output Class Initialized
INFO - 2023-09-22 13:51:33 --> Security Class Initialized
DEBUG - 2023-09-22 13:51:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-22 13:51:33 --> Input Class Initialized
INFO - 2023-09-22 13:51:33 --> Language Class Initialized
INFO - 2023-09-22 13:51:33 --> Language Class Initialized
INFO - 2023-09-22 13:51:33 --> Config Class Initialized
INFO - 2023-09-22 13:51:33 --> Loader Class Initialized
INFO - 2023-09-22 13:51:33 --> Helper loaded: url_helper
INFO - 2023-09-22 13:51:33 --> Helper loaded: file_helper
INFO - 2023-09-22 13:51:33 --> Helper loaded: form_helper
INFO - 2023-09-22 13:51:33 --> Helper loaded: my_helper
INFO - 2023-09-22 13:51:33 --> Database Driver Class Initialized
INFO - 2023-09-22 13:51:33 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-22 13:51:33 --> Controller Class Initialized
INFO - 2023-09-22 13:51:33 --> Final output sent to browser
DEBUG - 2023-09-22 13:51:33 --> Total execution time: 0.0694
INFO - 2023-09-22 13:51:44 --> Config Class Initialized
INFO - 2023-09-22 13:51:44 --> Hooks Class Initialized
DEBUG - 2023-09-22 13:51:44 --> UTF-8 Support Enabled
INFO - 2023-09-22 13:51:44 --> Utf8 Class Initialized
INFO - 2023-09-22 13:51:44 --> URI Class Initialized
INFO - 2023-09-22 13:51:44 --> Router Class Initialized
INFO - 2023-09-22 13:51:44 --> Output Class Initialized
INFO - 2023-09-22 13:51:44 --> Security Class Initialized
DEBUG - 2023-09-22 13:51:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-22 13:51:44 --> Input Class Initialized
INFO - 2023-09-22 13:51:44 --> Language Class Initialized
INFO - 2023-09-22 13:51:44 --> Language Class Initialized
INFO - 2023-09-22 13:51:44 --> Config Class Initialized
INFO - 2023-09-22 13:51:44 --> Loader Class Initialized
INFO - 2023-09-22 13:51:44 --> Helper loaded: url_helper
INFO - 2023-09-22 13:51:44 --> Helper loaded: file_helper
INFO - 2023-09-22 13:51:44 --> Helper loaded: form_helper
INFO - 2023-09-22 13:51:44 --> Helper loaded: my_helper
INFO - 2023-09-22 13:51:44 --> Database Driver Class Initialized
INFO - 2023-09-22 13:51:44 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-22 13:51:44 --> Controller Class Initialized
INFO - 2023-09-22 13:51:44 --> Final output sent to browser
DEBUG - 2023-09-22 13:51:44 --> Total execution time: 0.0457
INFO - 2023-09-22 13:51:44 --> Config Class Initialized
INFO - 2023-09-22 13:51:44 --> Hooks Class Initialized
DEBUG - 2023-09-22 13:51:44 --> UTF-8 Support Enabled
INFO - 2023-09-22 13:51:44 --> Utf8 Class Initialized
INFO - 2023-09-22 13:51:44 --> URI Class Initialized
INFO - 2023-09-22 13:51:44 --> Router Class Initialized
INFO - 2023-09-22 13:51:44 --> Output Class Initialized
INFO - 2023-09-22 13:51:44 --> Security Class Initialized
DEBUG - 2023-09-22 13:51:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-22 13:51:44 --> Input Class Initialized
INFO - 2023-09-22 13:51:44 --> Language Class Initialized
INFO - 2023-09-22 13:51:44 --> Language Class Initialized
INFO - 2023-09-22 13:51:44 --> Config Class Initialized
INFO - 2023-09-22 13:51:44 --> Loader Class Initialized
INFO - 2023-09-22 13:51:44 --> Helper loaded: url_helper
INFO - 2023-09-22 13:51:44 --> Helper loaded: file_helper
INFO - 2023-09-22 13:51:44 --> Helper loaded: form_helper
INFO - 2023-09-22 13:51:44 --> Helper loaded: my_helper
INFO - 2023-09-22 13:51:44 --> Database Driver Class Initialized
INFO - 2023-09-22 13:51:44 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-22 13:51:44 --> Controller Class Initialized
INFO - 2023-09-22 13:51:45 --> Config Class Initialized
INFO - 2023-09-22 13:51:45 --> Hooks Class Initialized
DEBUG - 2023-09-22 13:51:45 --> UTF-8 Support Enabled
INFO - 2023-09-22 13:51:45 --> Utf8 Class Initialized
INFO - 2023-09-22 13:51:45 --> URI Class Initialized
INFO - 2023-09-22 13:51:45 --> Router Class Initialized
INFO - 2023-09-22 13:51:45 --> Output Class Initialized
INFO - 2023-09-22 13:51:45 --> Security Class Initialized
DEBUG - 2023-09-22 13:51:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-22 13:51:45 --> Input Class Initialized
INFO - 2023-09-22 13:51:45 --> Language Class Initialized
INFO - 2023-09-22 13:51:45 --> Language Class Initialized
INFO - 2023-09-22 13:51:45 --> Config Class Initialized
INFO - 2023-09-22 13:51:45 --> Loader Class Initialized
INFO - 2023-09-22 13:51:45 --> Helper loaded: url_helper
INFO - 2023-09-22 13:51:45 --> Helper loaded: file_helper
INFO - 2023-09-22 13:51:45 --> Helper loaded: form_helper
INFO - 2023-09-22 13:51:45 --> Helper loaded: my_helper
INFO - 2023-09-22 13:51:45 --> Database Driver Class Initialized
INFO - 2023-09-22 13:51:45 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-22 13:51:45 --> Controller Class Initialized
INFO - 2023-09-22 13:51:45 --> Final output sent to browser
DEBUG - 2023-09-22 13:51:45 --> Total execution time: 0.1497
INFO - 2023-09-22 13:51:57 --> Config Class Initialized
INFO - 2023-09-22 13:51:57 --> Hooks Class Initialized
DEBUG - 2023-09-22 13:51:57 --> UTF-8 Support Enabled
INFO - 2023-09-22 13:51:57 --> Utf8 Class Initialized
INFO - 2023-09-22 13:51:57 --> URI Class Initialized
INFO - 2023-09-22 13:51:57 --> Router Class Initialized
INFO - 2023-09-22 13:51:57 --> Output Class Initialized
INFO - 2023-09-22 13:51:57 --> Security Class Initialized
DEBUG - 2023-09-22 13:51:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-22 13:51:57 --> Input Class Initialized
INFO - 2023-09-22 13:51:57 --> Language Class Initialized
INFO - 2023-09-22 13:51:57 --> Language Class Initialized
INFO - 2023-09-22 13:51:57 --> Config Class Initialized
INFO - 2023-09-22 13:51:57 --> Loader Class Initialized
INFO - 2023-09-22 13:51:57 --> Helper loaded: url_helper
INFO - 2023-09-22 13:51:57 --> Helper loaded: file_helper
INFO - 2023-09-22 13:51:57 --> Helper loaded: form_helper
INFO - 2023-09-22 13:51:57 --> Helper loaded: my_helper
INFO - 2023-09-22 13:51:57 --> Database Driver Class Initialized
INFO - 2023-09-22 13:51:57 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-22 13:51:57 --> Controller Class Initialized
DEBUG - 2023-09-22 13:51:57 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/login/views/login.php
DEBUG - 2023-09-22 13:51:57 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-09-22 13:51:57 --> Final output sent to browser
DEBUG - 2023-09-22 13:51:57 --> Total execution time: 0.0702
INFO - 2023-09-22 13:51:59 --> Config Class Initialized
INFO - 2023-09-22 13:51:59 --> Hooks Class Initialized
DEBUG - 2023-09-22 13:51:59 --> UTF-8 Support Enabled
INFO - 2023-09-22 13:51:59 --> Utf8 Class Initialized
INFO - 2023-09-22 13:51:59 --> URI Class Initialized
INFO - 2023-09-22 13:51:59 --> Router Class Initialized
INFO - 2023-09-22 13:51:59 --> Output Class Initialized
INFO - 2023-09-22 13:51:59 --> Security Class Initialized
DEBUG - 2023-09-22 13:51:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-22 13:51:59 --> Input Class Initialized
INFO - 2023-09-22 13:51:59 --> Language Class Initialized
INFO - 2023-09-22 13:51:59 --> Language Class Initialized
INFO - 2023-09-22 13:51:59 --> Config Class Initialized
INFO - 2023-09-22 13:51:59 --> Loader Class Initialized
INFO - 2023-09-22 13:51:59 --> Helper loaded: url_helper
INFO - 2023-09-22 13:51:59 --> Helper loaded: file_helper
INFO - 2023-09-22 13:51:59 --> Helper loaded: form_helper
INFO - 2023-09-22 13:51:59 --> Helper loaded: my_helper
INFO - 2023-09-22 13:51:59 --> Database Driver Class Initialized
INFO - 2023-09-22 13:51:59 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-22 13:51:59 --> Controller Class Initialized
INFO - 2023-09-22 13:51:59 --> Final output sent to browser
DEBUG - 2023-09-22 13:51:59 --> Total execution time: 0.1014
INFO - 2023-09-22 13:52:00 --> Config Class Initialized
INFO - 2023-09-22 13:52:00 --> Hooks Class Initialized
DEBUG - 2023-09-22 13:52:00 --> UTF-8 Support Enabled
INFO - 2023-09-22 13:52:00 --> Utf8 Class Initialized
INFO - 2023-09-22 13:52:00 --> URI Class Initialized
INFO - 2023-09-22 13:52:00 --> Router Class Initialized
INFO - 2023-09-22 13:52:00 --> Output Class Initialized
INFO - 2023-09-22 13:52:00 --> Security Class Initialized
DEBUG - 2023-09-22 13:52:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-22 13:52:00 --> Input Class Initialized
INFO - 2023-09-22 13:52:00 --> Language Class Initialized
INFO - 2023-09-22 13:52:00 --> Language Class Initialized
INFO - 2023-09-22 13:52:00 --> Config Class Initialized
INFO - 2023-09-22 13:52:00 --> Loader Class Initialized
INFO - 2023-09-22 13:52:00 --> Helper loaded: url_helper
INFO - 2023-09-22 13:52:00 --> Helper loaded: file_helper
INFO - 2023-09-22 13:52:00 --> Helper loaded: form_helper
INFO - 2023-09-22 13:52:00 --> Helper loaded: my_helper
INFO - 2023-09-22 13:52:00 --> Database Driver Class Initialized
INFO - 2023-09-22 13:52:00 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-22 13:52:00 --> Controller Class Initialized
INFO - 2023-09-22 13:52:01 --> Config Class Initialized
INFO - 2023-09-22 13:52:01 --> Hooks Class Initialized
DEBUG - 2023-09-22 13:52:01 --> UTF-8 Support Enabled
INFO - 2023-09-22 13:52:01 --> Utf8 Class Initialized
INFO - 2023-09-22 13:52:01 --> URI Class Initialized
INFO - 2023-09-22 13:52:01 --> Router Class Initialized
INFO - 2023-09-22 13:52:01 --> Output Class Initialized
INFO - 2023-09-22 13:52:01 --> Security Class Initialized
DEBUG - 2023-09-22 13:52:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-22 13:52:01 --> Input Class Initialized
INFO - 2023-09-22 13:52:01 --> Language Class Initialized
INFO - 2023-09-22 13:52:01 --> Language Class Initialized
INFO - 2023-09-22 13:52:01 --> Config Class Initialized
INFO - 2023-09-22 13:52:01 --> Loader Class Initialized
INFO - 2023-09-22 13:52:01 --> Helper loaded: url_helper
INFO - 2023-09-22 13:52:01 --> Helper loaded: file_helper
INFO - 2023-09-22 13:52:01 --> Helper loaded: form_helper
INFO - 2023-09-22 13:52:01 --> Helper loaded: my_helper
INFO - 2023-09-22 13:52:01 --> Database Driver Class Initialized
INFO - 2023-09-22 13:52:01 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-22 13:52:01 --> Controller Class Initialized
INFO - 2023-09-22 13:52:01 --> Final output sent to browser
DEBUG - 2023-09-22 13:52:01 --> Total execution time: 0.0500
INFO - 2023-09-22 13:52:10 --> Config Class Initialized
INFO - 2023-09-22 13:52:10 --> Hooks Class Initialized
DEBUG - 2023-09-22 13:52:10 --> UTF-8 Support Enabled
INFO - 2023-09-22 13:52:10 --> Utf8 Class Initialized
INFO - 2023-09-22 13:52:10 --> URI Class Initialized
INFO - 2023-09-22 13:52:10 --> Router Class Initialized
INFO - 2023-09-22 13:52:10 --> Output Class Initialized
INFO - 2023-09-22 13:52:10 --> Security Class Initialized
DEBUG - 2023-09-22 13:52:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-22 13:52:10 --> Input Class Initialized
INFO - 2023-09-22 13:52:10 --> Language Class Initialized
INFO - 2023-09-22 13:52:10 --> Language Class Initialized
INFO - 2023-09-22 13:52:10 --> Config Class Initialized
INFO - 2023-09-22 13:52:10 --> Loader Class Initialized
INFO - 2023-09-22 13:52:10 --> Helper loaded: url_helper
INFO - 2023-09-22 13:52:10 --> Helper loaded: file_helper
INFO - 2023-09-22 13:52:10 --> Helper loaded: form_helper
INFO - 2023-09-22 13:52:10 --> Helper loaded: my_helper
INFO - 2023-09-22 13:52:10 --> Database Driver Class Initialized
INFO - 2023-09-22 13:52:10 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-22 13:52:10 --> Controller Class Initialized
INFO - 2023-09-22 13:52:10 --> Helper loaded: cookie_helper
INFO - 2023-09-22 13:52:10 --> Final output sent to browser
DEBUG - 2023-09-22 13:52:10 --> Total execution time: 0.0355
INFO - 2023-09-22 13:52:11 --> Config Class Initialized
INFO - 2023-09-22 13:52:11 --> Hooks Class Initialized
DEBUG - 2023-09-22 13:52:11 --> UTF-8 Support Enabled
INFO - 2023-09-22 13:52:11 --> Utf8 Class Initialized
INFO - 2023-09-22 13:52:11 --> URI Class Initialized
INFO - 2023-09-22 13:52:11 --> Router Class Initialized
INFO - 2023-09-22 13:52:11 --> Output Class Initialized
INFO - 2023-09-22 13:52:11 --> Security Class Initialized
DEBUG - 2023-09-22 13:52:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-22 13:52:11 --> Input Class Initialized
INFO - 2023-09-22 13:52:11 --> Language Class Initialized
INFO - 2023-09-22 13:52:11 --> Language Class Initialized
INFO - 2023-09-22 13:52:11 --> Config Class Initialized
INFO - 2023-09-22 13:52:11 --> Loader Class Initialized
INFO - 2023-09-22 13:52:11 --> Helper loaded: url_helper
INFO - 2023-09-22 13:52:11 --> Helper loaded: file_helper
INFO - 2023-09-22 13:52:11 --> Helper loaded: form_helper
INFO - 2023-09-22 13:52:11 --> Helper loaded: my_helper
INFO - 2023-09-22 13:52:11 --> Database Driver Class Initialized
INFO - 2023-09-22 13:52:11 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-22 13:52:11 --> Controller Class Initialized
DEBUG - 2023-09-22 13:52:11 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/home/views/v_home_guru.php
DEBUG - 2023-09-22 13:52:11 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-09-22 13:52:11 --> Final output sent to browser
DEBUG - 2023-09-22 13:52:11 --> Total execution time: 0.0462
INFO - 2023-09-22 13:52:26 --> Config Class Initialized
INFO - 2023-09-22 13:52:26 --> Hooks Class Initialized
DEBUG - 2023-09-22 13:52:26 --> UTF-8 Support Enabled
INFO - 2023-09-22 13:52:26 --> Utf8 Class Initialized
INFO - 2023-09-22 13:52:26 --> URI Class Initialized
INFO - 2023-09-22 13:52:26 --> Router Class Initialized
INFO - 2023-09-22 13:52:26 --> Output Class Initialized
INFO - 2023-09-22 13:52:26 --> Security Class Initialized
DEBUG - 2023-09-22 13:52:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-22 13:52:26 --> Input Class Initialized
INFO - 2023-09-22 13:52:26 --> Language Class Initialized
INFO - 2023-09-22 13:52:26 --> Language Class Initialized
INFO - 2023-09-22 13:52:26 --> Config Class Initialized
INFO - 2023-09-22 13:52:26 --> Loader Class Initialized
INFO - 2023-09-22 13:52:26 --> Helper loaded: url_helper
INFO - 2023-09-22 13:52:26 --> Helper loaded: file_helper
INFO - 2023-09-22 13:52:26 --> Helper loaded: form_helper
INFO - 2023-09-22 13:52:26 --> Helper loaded: my_helper
INFO - 2023-09-22 13:52:26 --> Database Driver Class Initialized
INFO - 2023-09-22 13:52:26 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-22 13:52:26 --> Controller Class Initialized
INFO - 2023-09-22 13:52:26 --> Final output sent to browser
DEBUG - 2023-09-22 13:52:26 --> Total execution time: 0.0411
INFO - 2023-09-22 13:52:26 --> Config Class Initialized
INFO - 2023-09-22 13:52:26 --> Hooks Class Initialized
DEBUG - 2023-09-22 13:52:26 --> UTF-8 Support Enabled
INFO - 2023-09-22 13:52:26 --> Utf8 Class Initialized
INFO - 2023-09-22 13:52:26 --> URI Class Initialized
INFO - 2023-09-22 13:52:26 --> Router Class Initialized
INFO - 2023-09-22 13:52:26 --> Output Class Initialized
INFO - 2023-09-22 13:52:26 --> Security Class Initialized
DEBUG - 2023-09-22 13:52:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-22 13:52:26 --> Input Class Initialized
INFO - 2023-09-22 13:52:26 --> Language Class Initialized
INFO - 2023-09-22 13:52:26 --> Language Class Initialized
INFO - 2023-09-22 13:52:26 --> Config Class Initialized
INFO - 2023-09-22 13:52:26 --> Loader Class Initialized
INFO - 2023-09-22 13:52:26 --> Helper loaded: url_helper
INFO - 2023-09-22 13:52:26 --> Helper loaded: file_helper
INFO - 2023-09-22 13:52:26 --> Helper loaded: form_helper
INFO - 2023-09-22 13:52:26 --> Helper loaded: my_helper
INFO - 2023-09-22 13:52:26 --> Database Driver Class Initialized
INFO - 2023-09-22 13:52:26 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-22 13:52:26 --> Controller Class Initialized
INFO - 2023-09-22 13:52:34 --> Config Class Initialized
INFO - 2023-09-22 13:52:34 --> Hooks Class Initialized
DEBUG - 2023-09-22 13:52:34 --> UTF-8 Support Enabled
INFO - 2023-09-22 13:52:34 --> Utf8 Class Initialized
INFO - 2023-09-22 13:52:34 --> URI Class Initialized
INFO - 2023-09-22 13:52:34 --> Router Class Initialized
INFO - 2023-09-22 13:52:34 --> Output Class Initialized
INFO - 2023-09-22 13:52:34 --> Security Class Initialized
DEBUG - 2023-09-22 13:52:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-22 13:52:34 --> Input Class Initialized
INFO - 2023-09-22 13:52:34 --> Language Class Initialized
INFO - 2023-09-22 13:52:34 --> Language Class Initialized
INFO - 2023-09-22 13:52:34 --> Config Class Initialized
INFO - 2023-09-22 13:52:34 --> Loader Class Initialized
INFO - 2023-09-22 13:52:34 --> Helper loaded: url_helper
INFO - 2023-09-22 13:52:34 --> Helper loaded: file_helper
INFO - 2023-09-22 13:52:34 --> Helper loaded: form_helper
INFO - 2023-09-22 13:52:34 --> Helper loaded: my_helper
INFO - 2023-09-22 13:52:34 --> Database Driver Class Initialized
INFO - 2023-09-22 13:52:34 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-22 13:52:34 --> Controller Class Initialized
DEBUG - 2023-09-22 13:52:34 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/view_mapel/views/v_view_mapel.php
DEBUG - 2023-09-22 13:52:34 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-09-22 13:52:34 --> Final output sent to browser
DEBUG - 2023-09-22 13:52:34 --> Total execution time: 0.0453
INFO - 2023-09-22 13:52:45 --> Config Class Initialized
INFO - 2023-09-22 13:52:45 --> Hooks Class Initialized
DEBUG - 2023-09-22 13:52:45 --> UTF-8 Support Enabled
INFO - 2023-09-22 13:52:45 --> Utf8 Class Initialized
INFO - 2023-09-22 13:52:45 --> URI Class Initialized
INFO - 2023-09-22 13:52:45 --> Router Class Initialized
INFO - 2023-09-22 13:52:45 --> Output Class Initialized
INFO - 2023-09-22 13:52:45 --> Security Class Initialized
DEBUG - 2023-09-22 13:52:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-22 13:52:45 --> Input Class Initialized
INFO - 2023-09-22 13:52:45 --> Language Class Initialized
INFO - 2023-09-22 13:52:45 --> Language Class Initialized
INFO - 2023-09-22 13:52:45 --> Config Class Initialized
INFO - 2023-09-22 13:52:45 --> Loader Class Initialized
INFO - 2023-09-22 13:52:45 --> Helper loaded: url_helper
INFO - 2023-09-22 13:52:45 --> Helper loaded: file_helper
INFO - 2023-09-22 13:52:45 --> Helper loaded: form_helper
INFO - 2023-09-22 13:52:45 --> Helper loaded: my_helper
INFO - 2023-09-22 13:52:45 --> Database Driver Class Initialized
INFO - 2023-09-22 13:52:45 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-22 13:52:45 --> Controller Class Initialized
DEBUG - 2023-09-22 13:52:45 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_catatan_guru/views/list.php
DEBUG - 2023-09-22 13:52:45 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-09-22 13:52:45 --> Final output sent to browser
DEBUG - 2023-09-22 13:52:45 --> Total execution time: 0.0411
INFO - 2023-09-22 13:52:49 --> Config Class Initialized
INFO - 2023-09-22 13:52:49 --> Hooks Class Initialized
DEBUG - 2023-09-22 13:52:49 --> UTF-8 Support Enabled
INFO - 2023-09-22 13:52:49 --> Utf8 Class Initialized
INFO - 2023-09-22 13:52:49 --> URI Class Initialized
INFO - 2023-09-22 13:52:49 --> Router Class Initialized
INFO - 2023-09-22 13:52:49 --> Output Class Initialized
INFO - 2023-09-22 13:52:49 --> Security Class Initialized
DEBUG - 2023-09-22 13:52:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-22 13:52:49 --> Input Class Initialized
INFO - 2023-09-22 13:52:49 --> Language Class Initialized
INFO - 2023-09-22 13:52:49 --> Language Class Initialized
INFO - 2023-09-22 13:52:49 --> Config Class Initialized
INFO - 2023-09-22 13:52:49 --> Loader Class Initialized
INFO - 2023-09-22 13:52:49 --> Helper loaded: url_helper
INFO - 2023-09-22 13:52:49 --> Helper loaded: file_helper
INFO - 2023-09-22 13:52:49 --> Helper loaded: form_helper
INFO - 2023-09-22 13:52:49 --> Helper loaded: my_helper
INFO - 2023-09-22 13:52:49 --> Database Driver Class Initialized
INFO - 2023-09-22 13:52:49 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-22 13:52:49 --> Controller Class Initialized
DEBUG - 2023-09-22 13:52:49 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/view_mapel/views/v_view_mapel.php
DEBUG - 2023-09-22 13:52:49 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-09-22 13:52:49 --> Final output sent to browser
DEBUG - 2023-09-22 13:52:49 --> Total execution time: 0.1042
INFO - 2023-09-22 13:52:51 --> Config Class Initialized
INFO - 2023-09-22 13:52:51 --> Hooks Class Initialized
DEBUG - 2023-09-22 13:52:51 --> UTF-8 Support Enabled
INFO - 2023-09-22 13:52:51 --> Utf8 Class Initialized
INFO - 2023-09-22 13:52:51 --> URI Class Initialized
INFO - 2023-09-22 13:52:51 --> Router Class Initialized
INFO - 2023-09-22 13:52:51 --> Output Class Initialized
INFO - 2023-09-22 13:52:51 --> Security Class Initialized
DEBUG - 2023-09-22 13:52:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-22 13:52:51 --> Input Class Initialized
INFO - 2023-09-22 13:52:51 --> Language Class Initialized
INFO - 2023-09-22 13:52:51 --> Language Class Initialized
INFO - 2023-09-22 13:52:51 --> Config Class Initialized
INFO - 2023-09-22 13:52:51 --> Loader Class Initialized
INFO - 2023-09-22 13:52:51 --> Helper loaded: url_helper
INFO - 2023-09-22 13:52:51 --> Helper loaded: file_helper
INFO - 2023-09-22 13:52:51 --> Helper loaded: form_helper
INFO - 2023-09-22 13:52:51 --> Helper loaded: my_helper
INFO - 2023-09-22 13:52:51 --> Database Driver Class Initialized
INFO - 2023-09-22 13:52:51 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-22 13:52:51 --> Controller Class Initialized
DEBUG - 2023-09-22 13:52:51 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/views/list.php
DEBUG - 2023-09-22 13:52:51 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-09-22 13:52:51 --> Final output sent to browser
DEBUG - 2023-09-22 13:52:51 --> Total execution time: 0.0401
INFO - 2023-09-22 13:52:51 --> Config Class Initialized
INFO - 2023-09-22 13:52:51 --> Hooks Class Initialized
DEBUG - 2023-09-22 13:52:51 --> UTF-8 Support Enabled
INFO - 2023-09-22 13:52:51 --> Utf8 Class Initialized
INFO - 2023-09-22 13:52:51 --> URI Class Initialized
INFO - 2023-09-22 13:52:51 --> Router Class Initialized
INFO - 2023-09-22 13:52:51 --> Output Class Initialized
INFO - 2023-09-22 13:52:51 --> Security Class Initialized
DEBUG - 2023-09-22 13:52:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-22 13:52:51 --> Input Class Initialized
INFO - 2023-09-22 13:52:51 --> Language Class Initialized
INFO - 2023-09-22 13:52:51 --> Language Class Initialized
INFO - 2023-09-22 13:52:51 --> Config Class Initialized
INFO - 2023-09-22 13:52:51 --> Loader Class Initialized
INFO - 2023-09-22 13:52:51 --> Helper loaded: url_helper
INFO - 2023-09-22 13:52:51 --> Helper loaded: file_helper
INFO - 2023-09-22 13:52:51 --> Helper loaded: form_helper
INFO - 2023-09-22 13:52:51 --> Helper loaded: my_helper
INFO - 2023-09-22 13:52:51 --> Database Driver Class Initialized
INFO - 2023-09-22 13:52:51 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-22 13:52:51 --> Controller Class Initialized
INFO - 2023-09-22 13:52:55 --> Config Class Initialized
INFO - 2023-09-22 13:52:55 --> Hooks Class Initialized
DEBUG - 2023-09-22 13:52:55 --> UTF-8 Support Enabled
INFO - 2023-09-22 13:52:55 --> Utf8 Class Initialized
INFO - 2023-09-22 13:52:55 --> URI Class Initialized
INFO - 2023-09-22 13:52:55 --> Router Class Initialized
INFO - 2023-09-22 13:52:55 --> Output Class Initialized
INFO - 2023-09-22 13:52:55 --> Security Class Initialized
DEBUG - 2023-09-22 13:52:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-22 13:52:55 --> Input Class Initialized
INFO - 2023-09-22 13:52:55 --> Language Class Initialized
INFO - 2023-09-22 13:52:55 --> Language Class Initialized
INFO - 2023-09-22 13:52:55 --> Config Class Initialized
INFO - 2023-09-22 13:52:55 --> Loader Class Initialized
INFO - 2023-09-22 13:52:55 --> Helper loaded: url_helper
INFO - 2023-09-22 13:52:55 --> Helper loaded: file_helper
INFO - 2023-09-22 13:52:55 --> Helper loaded: form_helper
INFO - 2023-09-22 13:52:55 --> Helper loaded: my_helper
INFO - 2023-09-22 13:52:55 --> Database Driver Class Initialized
INFO - 2023-09-22 13:52:55 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-22 13:52:55 --> Controller Class Initialized
INFO - 2023-09-22 13:52:55 --> Final output sent to browser
DEBUG - 2023-09-22 13:52:55 --> Total execution time: 0.0366
INFO - 2023-09-22 13:52:56 --> Config Class Initialized
INFO - 2023-09-22 13:52:56 --> Hooks Class Initialized
DEBUG - 2023-09-22 13:52:56 --> UTF-8 Support Enabled
INFO - 2023-09-22 13:52:56 --> Utf8 Class Initialized
INFO - 2023-09-22 13:52:56 --> URI Class Initialized
INFO - 2023-09-22 13:52:56 --> Router Class Initialized
INFO - 2023-09-22 13:52:56 --> Output Class Initialized
INFO - 2023-09-22 13:52:56 --> Security Class Initialized
DEBUG - 2023-09-22 13:52:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-22 13:52:56 --> Input Class Initialized
INFO - 2023-09-22 13:52:56 --> Language Class Initialized
INFO - 2023-09-22 13:52:56 --> Language Class Initialized
INFO - 2023-09-22 13:52:56 --> Config Class Initialized
INFO - 2023-09-22 13:52:56 --> Loader Class Initialized
INFO - 2023-09-22 13:52:56 --> Helper loaded: url_helper
INFO - 2023-09-22 13:52:56 --> Helper loaded: file_helper
INFO - 2023-09-22 13:52:56 --> Helper loaded: form_helper
INFO - 2023-09-22 13:52:56 --> Helper loaded: my_helper
INFO - 2023-09-22 13:52:56 --> Database Driver Class Initialized
INFO - 2023-09-22 13:52:56 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-22 13:52:56 --> Controller Class Initialized
INFO - 2023-09-22 13:52:56 --> Final output sent to browser
DEBUG - 2023-09-22 13:52:56 --> Total execution time: 0.0528
INFO - 2023-09-22 13:53:20 --> Config Class Initialized
INFO - 2023-09-22 13:53:20 --> Hooks Class Initialized
DEBUG - 2023-09-22 13:53:20 --> UTF-8 Support Enabled
INFO - 2023-09-22 13:53:20 --> Utf8 Class Initialized
INFO - 2023-09-22 13:53:20 --> URI Class Initialized
INFO - 2023-09-22 13:53:20 --> Router Class Initialized
INFO - 2023-09-22 13:53:20 --> Output Class Initialized
INFO - 2023-09-22 13:53:20 --> Security Class Initialized
DEBUG - 2023-09-22 13:53:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-22 13:53:20 --> Input Class Initialized
INFO - 2023-09-22 13:53:20 --> Language Class Initialized
INFO - 2023-09-22 13:53:20 --> Language Class Initialized
INFO - 2023-09-22 13:53:20 --> Config Class Initialized
INFO - 2023-09-22 13:53:20 --> Loader Class Initialized
INFO - 2023-09-22 13:53:20 --> Helper loaded: url_helper
INFO - 2023-09-22 13:53:20 --> Helper loaded: file_helper
INFO - 2023-09-22 13:53:20 --> Helper loaded: form_helper
INFO - 2023-09-22 13:53:20 --> Helper loaded: my_helper
INFO - 2023-09-22 13:53:20 --> Database Driver Class Initialized
INFO - 2023-09-22 13:53:20 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-22 13:53:20 --> Controller Class Initialized
INFO - 2023-09-22 13:53:20 --> Final output sent to browser
DEBUG - 2023-09-22 13:53:20 --> Total execution time: 0.0431
INFO - 2023-09-22 13:53:23 --> Config Class Initialized
INFO - 2023-09-22 13:53:23 --> Hooks Class Initialized
DEBUG - 2023-09-22 13:53:23 --> UTF-8 Support Enabled
INFO - 2023-09-22 13:53:23 --> Utf8 Class Initialized
INFO - 2023-09-22 13:53:23 --> URI Class Initialized
INFO - 2023-09-22 13:53:23 --> Router Class Initialized
INFO - 2023-09-22 13:53:23 --> Output Class Initialized
INFO - 2023-09-22 13:53:23 --> Security Class Initialized
DEBUG - 2023-09-22 13:53:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-22 13:53:23 --> Input Class Initialized
INFO - 2023-09-22 13:53:23 --> Language Class Initialized
INFO - 2023-09-22 13:53:23 --> Language Class Initialized
INFO - 2023-09-22 13:53:23 --> Config Class Initialized
INFO - 2023-09-22 13:53:23 --> Loader Class Initialized
INFO - 2023-09-22 13:53:23 --> Helper loaded: url_helper
INFO - 2023-09-22 13:53:23 --> Helper loaded: file_helper
INFO - 2023-09-22 13:53:23 --> Helper loaded: form_helper
INFO - 2023-09-22 13:53:23 --> Helper loaded: my_helper
INFO - 2023-09-22 13:53:23 --> Database Driver Class Initialized
INFO - 2023-09-22 13:53:23 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-22 13:53:23 --> Controller Class Initialized
INFO - 2023-09-22 13:53:23 --> Final output sent to browser
DEBUG - 2023-09-22 13:53:23 --> Total execution time: 0.0364
INFO - 2023-09-22 13:53:23 --> Config Class Initialized
INFO - 2023-09-22 13:53:23 --> Hooks Class Initialized
DEBUG - 2023-09-22 13:53:23 --> UTF-8 Support Enabled
INFO - 2023-09-22 13:53:23 --> Utf8 Class Initialized
INFO - 2023-09-22 13:53:23 --> URI Class Initialized
INFO - 2023-09-22 13:53:23 --> Router Class Initialized
INFO - 2023-09-22 13:53:23 --> Output Class Initialized
INFO - 2023-09-22 13:53:23 --> Security Class Initialized
DEBUG - 2023-09-22 13:53:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-22 13:53:23 --> Input Class Initialized
INFO - 2023-09-22 13:53:23 --> Language Class Initialized
INFO - 2023-09-22 13:53:23 --> Language Class Initialized
INFO - 2023-09-22 13:53:23 --> Config Class Initialized
INFO - 2023-09-22 13:53:23 --> Loader Class Initialized
INFO - 2023-09-22 13:53:23 --> Helper loaded: url_helper
INFO - 2023-09-22 13:53:23 --> Helper loaded: file_helper
INFO - 2023-09-22 13:53:23 --> Helper loaded: form_helper
INFO - 2023-09-22 13:53:23 --> Helper loaded: my_helper
INFO - 2023-09-22 13:53:23 --> Database Driver Class Initialized
INFO - 2023-09-22 13:53:23 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-22 13:53:23 --> Controller Class Initialized
INFO - 2023-09-22 13:53:23 --> Final output sent to browser
DEBUG - 2023-09-22 13:53:23 --> Total execution time: 0.0356
INFO - 2023-09-22 13:53:41 --> Config Class Initialized
INFO - 2023-09-22 13:53:41 --> Hooks Class Initialized
DEBUG - 2023-09-22 13:53:41 --> UTF-8 Support Enabled
INFO - 2023-09-22 13:53:41 --> Utf8 Class Initialized
INFO - 2023-09-22 13:53:41 --> URI Class Initialized
INFO - 2023-09-22 13:53:41 --> Router Class Initialized
INFO - 2023-09-22 13:53:41 --> Output Class Initialized
INFO - 2023-09-22 13:53:41 --> Security Class Initialized
DEBUG - 2023-09-22 13:53:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-22 13:53:41 --> Input Class Initialized
INFO - 2023-09-22 13:53:41 --> Language Class Initialized
INFO - 2023-09-22 13:53:41 --> Language Class Initialized
INFO - 2023-09-22 13:53:41 --> Config Class Initialized
INFO - 2023-09-22 13:53:41 --> Loader Class Initialized
INFO - 2023-09-22 13:53:41 --> Helper loaded: url_helper
INFO - 2023-09-22 13:53:41 --> Helper loaded: file_helper
INFO - 2023-09-22 13:53:41 --> Helper loaded: form_helper
INFO - 2023-09-22 13:53:41 --> Helper loaded: my_helper
INFO - 2023-09-22 13:53:41 --> Database Driver Class Initialized
INFO - 2023-09-22 13:53:41 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-22 13:53:41 --> Controller Class Initialized
INFO - 2023-09-22 13:53:41 --> Final output sent to browser
DEBUG - 2023-09-22 13:53:41 --> Total execution time: 0.0398
INFO - 2023-09-22 13:53:58 --> Config Class Initialized
INFO - 2023-09-22 13:53:58 --> Hooks Class Initialized
DEBUG - 2023-09-22 13:53:58 --> UTF-8 Support Enabled
INFO - 2023-09-22 13:53:58 --> Utf8 Class Initialized
INFO - 2023-09-22 13:53:58 --> URI Class Initialized
INFO - 2023-09-22 13:53:58 --> Router Class Initialized
INFO - 2023-09-22 13:53:58 --> Output Class Initialized
INFO - 2023-09-22 13:53:58 --> Security Class Initialized
DEBUG - 2023-09-22 13:53:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-22 13:53:58 --> Input Class Initialized
INFO - 2023-09-22 13:53:58 --> Language Class Initialized
INFO - 2023-09-22 13:53:58 --> Language Class Initialized
INFO - 2023-09-22 13:53:58 --> Config Class Initialized
INFO - 2023-09-22 13:53:58 --> Loader Class Initialized
INFO - 2023-09-22 13:53:58 --> Helper loaded: url_helper
INFO - 2023-09-22 13:53:58 --> Helper loaded: file_helper
INFO - 2023-09-22 13:53:58 --> Helper loaded: form_helper
INFO - 2023-09-22 13:53:58 --> Helper loaded: my_helper
INFO - 2023-09-22 13:53:58 --> Database Driver Class Initialized
INFO - 2023-09-22 13:53:58 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-22 13:53:58 --> Controller Class Initialized
INFO - 2023-09-22 13:53:58 --> Final output sent to browser
DEBUG - 2023-09-22 13:53:58 --> Total execution time: 0.0762
INFO - 2023-09-22 13:54:02 --> Config Class Initialized
INFO - 2023-09-22 13:54:02 --> Hooks Class Initialized
DEBUG - 2023-09-22 13:54:02 --> UTF-8 Support Enabled
INFO - 2023-09-22 13:54:02 --> Utf8 Class Initialized
INFO - 2023-09-22 13:54:02 --> URI Class Initialized
INFO - 2023-09-22 13:54:02 --> Router Class Initialized
INFO - 2023-09-22 13:54:02 --> Output Class Initialized
INFO - 2023-09-22 13:54:02 --> Security Class Initialized
DEBUG - 2023-09-22 13:54:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-22 13:54:02 --> Input Class Initialized
INFO - 2023-09-22 13:54:02 --> Language Class Initialized
INFO - 2023-09-22 13:54:02 --> Language Class Initialized
INFO - 2023-09-22 13:54:02 --> Config Class Initialized
INFO - 2023-09-22 13:54:02 --> Loader Class Initialized
INFO - 2023-09-22 13:54:02 --> Helper loaded: url_helper
INFO - 2023-09-22 13:54:02 --> Helper loaded: file_helper
INFO - 2023-09-22 13:54:02 --> Helper loaded: form_helper
INFO - 2023-09-22 13:54:02 --> Helper loaded: my_helper
INFO - 2023-09-22 13:54:02 --> Database Driver Class Initialized
INFO - 2023-09-22 13:54:02 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-22 13:54:02 --> Controller Class Initialized
INFO - 2023-09-22 13:54:02 --> Final output sent to browser
DEBUG - 2023-09-22 13:54:02 --> Total execution time: 0.2666
INFO - 2023-09-22 13:54:04 --> Config Class Initialized
INFO - 2023-09-22 13:54:04 --> Hooks Class Initialized
DEBUG - 2023-09-22 13:54:04 --> UTF-8 Support Enabled
INFO - 2023-09-22 13:54:04 --> Utf8 Class Initialized
INFO - 2023-09-22 13:54:04 --> URI Class Initialized
INFO - 2023-09-22 13:54:04 --> Router Class Initialized
INFO - 2023-09-22 13:54:04 --> Output Class Initialized
INFO - 2023-09-22 13:54:04 --> Security Class Initialized
DEBUG - 2023-09-22 13:54:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-22 13:54:04 --> Input Class Initialized
INFO - 2023-09-22 13:54:04 --> Language Class Initialized
INFO - 2023-09-22 13:54:04 --> Language Class Initialized
INFO - 2023-09-22 13:54:04 --> Config Class Initialized
INFO - 2023-09-22 13:54:04 --> Loader Class Initialized
INFO - 2023-09-22 13:54:04 --> Helper loaded: url_helper
INFO - 2023-09-22 13:54:04 --> Helper loaded: file_helper
INFO - 2023-09-22 13:54:04 --> Helper loaded: form_helper
INFO - 2023-09-22 13:54:04 --> Helper loaded: my_helper
INFO - 2023-09-22 13:54:04 --> Database Driver Class Initialized
INFO - 2023-09-22 13:54:04 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-22 13:54:04 --> Controller Class Initialized
INFO - 2023-09-22 13:54:04 --> Final output sent to browser
DEBUG - 2023-09-22 13:54:04 --> Total execution time: 0.0404
INFO - 2023-09-22 13:54:05 --> Config Class Initialized
INFO - 2023-09-22 13:54:05 --> Hooks Class Initialized
DEBUG - 2023-09-22 13:54:05 --> UTF-8 Support Enabled
INFO - 2023-09-22 13:54:05 --> Utf8 Class Initialized
INFO - 2023-09-22 13:54:05 --> URI Class Initialized
INFO - 2023-09-22 13:54:05 --> Router Class Initialized
INFO - 2023-09-22 13:54:05 --> Output Class Initialized
INFO - 2023-09-22 13:54:05 --> Security Class Initialized
DEBUG - 2023-09-22 13:54:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-22 13:54:05 --> Input Class Initialized
INFO - 2023-09-22 13:54:05 --> Language Class Initialized
INFO - 2023-09-22 13:54:05 --> Language Class Initialized
INFO - 2023-09-22 13:54:05 --> Config Class Initialized
INFO - 2023-09-22 13:54:05 --> Loader Class Initialized
INFO - 2023-09-22 13:54:05 --> Helper loaded: url_helper
INFO - 2023-09-22 13:54:05 --> Helper loaded: file_helper
INFO - 2023-09-22 13:54:05 --> Helper loaded: form_helper
INFO - 2023-09-22 13:54:05 --> Helper loaded: my_helper
INFO - 2023-09-22 13:54:05 --> Database Driver Class Initialized
INFO - 2023-09-22 13:54:05 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-22 13:54:05 --> Controller Class Initialized
INFO - 2023-09-22 13:54:05 --> Final output sent to browser
DEBUG - 2023-09-22 13:54:05 --> Total execution time: 0.0695
INFO - 2023-09-22 13:54:13 --> Config Class Initialized
INFO - 2023-09-22 13:54:13 --> Hooks Class Initialized
DEBUG - 2023-09-22 13:54:13 --> UTF-8 Support Enabled
INFO - 2023-09-22 13:54:13 --> Utf8 Class Initialized
INFO - 2023-09-22 13:54:13 --> URI Class Initialized
INFO - 2023-09-22 13:54:13 --> Router Class Initialized
INFO - 2023-09-22 13:54:13 --> Output Class Initialized
INFO - 2023-09-22 13:54:13 --> Security Class Initialized
DEBUG - 2023-09-22 13:54:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-22 13:54:13 --> Input Class Initialized
INFO - 2023-09-22 13:54:13 --> Language Class Initialized
INFO - 2023-09-22 13:54:13 --> Language Class Initialized
INFO - 2023-09-22 13:54:13 --> Config Class Initialized
INFO - 2023-09-22 13:54:13 --> Loader Class Initialized
INFO - 2023-09-22 13:54:13 --> Helper loaded: url_helper
INFO - 2023-09-22 13:54:13 --> Helper loaded: file_helper
INFO - 2023-09-22 13:54:13 --> Helper loaded: form_helper
INFO - 2023-09-22 13:54:13 --> Helper loaded: my_helper
INFO - 2023-09-22 13:54:13 --> Database Driver Class Initialized
INFO - 2023-09-22 13:54:13 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-22 13:54:13 --> Controller Class Initialized
INFO - 2023-09-22 13:54:13 --> Final output sent to browser
DEBUG - 2023-09-22 13:54:13 --> Total execution time: 0.0417
INFO - 2023-09-22 13:54:13 --> Config Class Initialized
INFO - 2023-09-22 13:54:13 --> Hooks Class Initialized
DEBUG - 2023-09-22 13:54:13 --> UTF-8 Support Enabled
INFO - 2023-09-22 13:54:13 --> Utf8 Class Initialized
INFO - 2023-09-22 13:54:13 --> URI Class Initialized
INFO - 2023-09-22 13:54:13 --> Router Class Initialized
INFO - 2023-09-22 13:54:13 --> Output Class Initialized
INFO - 2023-09-22 13:54:13 --> Security Class Initialized
DEBUG - 2023-09-22 13:54:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-22 13:54:13 --> Input Class Initialized
INFO - 2023-09-22 13:54:13 --> Language Class Initialized
INFO - 2023-09-22 13:54:13 --> Language Class Initialized
INFO - 2023-09-22 13:54:13 --> Config Class Initialized
INFO - 2023-09-22 13:54:13 --> Loader Class Initialized
INFO - 2023-09-22 13:54:13 --> Helper loaded: url_helper
INFO - 2023-09-22 13:54:13 --> Helper loaded: file_helper
INFO - 2023-09-22 13:54:13 --> Helper loaded: form_helper
INFO - 2023-09-22 13:54:13 --> Helper loaded: my_helper
INFO - 2023-09-22 13:54:13 --> Database Driver Class Initialized
INFO - 2023-09-22 13:54:13 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-22 13:54:13 --> Controller Class Initialized
INFO - 2023-09-22 13:54:15 --> Config Class Initialized
INFO - 2023-09-22 13:54:15 --> Hooks Class Initialized
DEBUG - 2023-09-22 13:54:15 --> UTF-8 Support Enabled
INFO - 2023-09-22 13:54:15 --> Utf8 Class Initialized
INFO - 2023-09-22 13:54:15 --> URI Class Initialized
INFO - 2023-09-22 13:54:15 --> Router Class Initialized
INFO - 2023-09-22 13:54:15 --> Output Class Initialized
INFO - 2023-09-22 13:54:15 --> Security Class Initialized
DEBUG - 2023-09-22 13:54:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-22 13:54:15 --> Input Class Initialized
INFO - 2023-09-22 13:54:15 --> Language Class Initialized
INFO - 2023-09-22 13:54:15 --> Language Class Initialized
INFO - 2023-09-22 13:54:15 --> Config Class Initialized
INFO - 2023-09-22 13:54:15 --> Loader Class Initialized
INFO - 2023-09-22 13:54:15 --> Helper loaded: url_helper
INFO - 2023-09-22 13:54:15 --> Helper loaded: file_helper
INFO - 2023-09-22 13:54:15 --> Helper loaded: form_helper
INFO - 2023-09-22 13:54:15 --> Helper loaded: my_helper
INFO - 2023-09-22 13:54:15 --> Database Driver Class Initialized
INFO - 2023-09-22 13:54:15 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-22 13:54:15 --> Controller Class Initialized
INFO - 2023-09-22 13:54:15 --> Config Class Initialized
INFO - 2023-09-22 13:54:15 --> Hooks Class Initialized
DEBUG - 2023-09-22 13:54:15 --> UTF-8 Support Enabled
INFO - 2023-09-22 13:54:15 --> Utf8 Class Initialized
INFO - 2023-09-22 13:54:15 --> URI Class Initialized
INFO - 2023-09-22 13:54:15 --> Router Class Initialized
INFO - 2023-09-22 13:54:15 --> Output Class Initialized
INFO - 2023-09-22 13:54:15 --> Security Class Initialized
DEBUG - 2023-09-22 13:54:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-22 13:54:15 --> Input Class Initialized
INFO - 2023-09-22 13:54:15 --> Language Class Initialized
INFO - 2023-09-22 13:54:15 --> Language Class Initialized
INFO - 2023-09-22 13:54:15 --> Config Class Initialized
INFO - 2023-09-22 13:54:15 --> Loader Class Initialized
INFO - 2023-09-22 13:54:15 --> Helper loaded: url_helper
INFO - 2023-09-22 13:54:15 --> Helper loaded: file_helper
INFO - 2023-09-22 13:54:15 --> Helper loaded: form_helper
INFO - 2023-09-22 13:54:15 --> Helper loaded: my_helper
INFO - 2023-09-22 13:54:15 --> Database Driver Class Initialized
INFO - 2023-09-22 13:54:15 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-22 13:54:15 --> Controller Class Initialized
INFO - 2023-09-22 13:54:16 --> Final output sent to browser
DEBUG - 2023-09-22 13:54:16 --> Total execution time: 0.1029
INFO - 2023-09-22 13:54:17 --> Config Class Initialized
INFO - 2023-09-22 13:54:17 --> Hooks Class Initialized
DEBUG - 2023-09-22 13:54:17 --> UTF-8 Support Enabled
INFO - 2023-09-22 13:54:17 --> Utf8 Class Initialized
INFO - 2023-09-22 13:54:17 --> URI Class Initialized
INFO - 2023-09-22 13:54:17 --> Router Class Initialized
INFO - 2023-09-22 13:54:17 --> Output Class Initialized
INFO - 2023-09-22 13:54:17 --> Security Class Initialized
DEBUG - 2023-09-22 13:54:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-22 13:54:17 --> Input Class Initialized
INFO - 2023-09-22 13:54:17 --> Language Class Initialized
INFO - 2023-09-22 13:54:17 --> Language Class Initialized
INFO - 2023-09-22 13:54:17 --> Config Class Initialized
INFO - 2023-09-22 13:54:17 --> Loader Class Initialized
INFO - 2023-09-22 13:54:17 --> Helper loaded: url_helper
INFO - 2023-09-22 13:54:17 --> Helper loaded: file_helper
INFO - 2023-09-22 13:54:17 --> Helper loaded: form_helper
INFO - 2023-09-22 13:54:17 --> Helper loaded: my_helper
INFO - 2023-09-22 13:54:17 --> Database Driver Class Initialized
INFO - 2023-09-22 13:54:17 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-22 13:54:17 --> Controller Class Initialized
DEBUG - 2023-09-22 13:54:17 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/views/list.php
DEBUG - 2023-09-22 13:54:17 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-09-22 13:54:17 --> Final output sent to browser
DEBUG - 2023-09-22 13:54:17 --> Total execution time: 0.0401
INFO - 2023-09-22 13:54:18 --> Config Class Initialized
INFO - 2023-09-22 13:54:18 --> Hooks Class Initialized
DEBUG - 2023-09-22 13:54:18 --> UTF-8 Support Enabled
INFO - 2023-09-22 13:54:18 --> Utf8 Class Initialized
INFO - 2023-09-22 13:54:18 --> URI Class Initialized
INFO - 2023-09-22 13:54:18 --> Router Class Initialized
INFO - 2023-09-22 13:54:18 --> Output Class Initialized
INFO - 2023-09-22 13:54:18 --> Security Class Initialized
DEBUG - 2023-09-22 13:54:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-22 13:54:18 --> Input Class Initialized
INFO - 2023-09-22 13:54:18 --> Language Class Initialized
INFO - 2023-09-22 13:54:18 --> Language Class Initialized
INFO - 2023-09-22 13:54:18 --> Config Class Initialized
INFO - 2023-09-22 13:54:18 --> Loader Class Initialized
INFO - 2023-09-22 13:54:18 --> Helper loaded: url_helper
INFO - 2023-09-22 13:54:18 --> Helper loaded: file_helper
INFO - 2023-09-22 13:54:18 --> Helper loaded: form_helper
INFO - 2023-09-22 13:54:18 --> Helper loaded: my_helper
INFO - 2023-09-22 13:54:18 --> Database Driver Class Initialized
INFO - 2023-09-22 13:54:18 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-22 13:54:18 --> Controller Class Initialized
INFO - 2023-09-22 13:54:23 --> Config Class Initialized
INFO - 2023-09-22 13:54:23 --> Hooks Class Initialized
DEBUG - 2023-09-22 13:54:23 --> UTF-8 Support Enabled
INFO - 2023-09-22 13:54:23 --> Utf8 Class Initialized
INFO - 2023-09-22 13:54:23 --> URI Class Initialized
INFO - 2023-09-22 13:54:23 --> Router Class Initialized
INFO - 2023-09-22 13:54:23 --> Output Class Initialized
INFO - 2023-09-22 13:54:23 --> Security Class Initialized
DEBUG - 2023-09-22 13:54:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-22 13:54:23 --> Input Class Initialized
INFO - 2023-09-22 13:54:23 --> Language Class Initialized
INFO - 2023-09-22 13:54:23 --> Language Class Initialized
INFO - 2023-09-22 13:54:23 --> Config Class Initialized
INFO - 2023-09-22 13:54:23 --> Loader Class Initialized
INFO - 2023-09-22 13:54:23 --> Helper loaded: url_helper
INFO - 2023-09-22 13:54:23 --> Helper loaded: file_helper
INFO - 2023-09-22 13:54:23 --> Helper loaded: form_helper
INFO - 2023-09-22 13:54:23 --> Helper loaded: my_helper
INFO - 2023-09-22 13:54:23 --> Database Driver Class Initialized
INFO - 2023-09-22 13:54:23 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-22 13:54:23 --> Controller Class Initialized
INFO - 2023-09-22 13:54:23 --> Final output sent to browser
DEBUG - 2023-09-22 13:54:23 --> Total execution time: 0.0625
INFO - 2023-09-22 13:54:28 --> Config Class Initialized
INFO - 2023-09-22 13:54:28 --> Hooks Class Initialized
DEBUG - 2023-09-22 13:54:28 --> UTF-8 Support Enabled
INFO - 2023-09-22 13:54:28 --> Utf8 Class Initialized
INFO - 2023-09-22 13:54:28 --> URI Class Initialized
INFO - 2023-09-22 13:54:28 --> Router Class Initialized
INFO - 2023-09-22 13:54:28 --> Output Class Initialized
INFO - 2023-09-22 13:54:28 --> Security Class Initialized
DEBUG - 2023-09-22 13:54:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-22 13:54:28 --> Input Class Initialized
INFO - 2023-09-22 13:54:28 --> Language Class Initialized
INFO - 2023-09-22 13:54:28 --> Language Class Initialized
INFO - 2023-09-22 13:54:28 --> Config Class Initialized
INFO - 2023-09-22 13:54:28 --> Loader Class Initialized
INFO - 2023-09-22 13:54:28 --> Helper loaded: url_helper
INFO - 2023-09-22 13:54:28 --> Helper loaded: file_helper
INFO - 2023-09-22 13:54:28 --> Helper loaded: form_helper
INFO - 2023-09-22 13:54:28 --> Helper loaded: my_helper
INFO - 2023-09-22 13:54:28 --> Database Driver Class Initialized
INFO - 2023-09-22 13:54:28 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-22 13:54:28 --> Controller Class Initialized
INFO - 2023-09-22 13:54:28 --> Final output sent to browser
DEBUG - 2023-09-22 13:54:28 --> Total execution time: 0.0316
INFO - 2023-09-22 13:54:28 --> Config Class Initialized
INFO - 2023-09-22 13:54:28 --> Hooks Class Initialized
DEBUG - 2023-09-22 13:54:28 --> UTF-8 Support Enabled
INFO - 2023-09-22 13:54:28 --> Utf8 Class Initialized
INFO - 2023-09-22 13:54:28 --> URI Class Initialized
INFO - 2023-09-22 13:54:28 --> Router Class Initialized
INFO - 2023-09-22 13:54:28 --> Output Class Initialized
INFO - 2023-09-22 13:54:28 --> Security Class Initialized
DEBUG - 2023-09-22 13:54:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-22 13:54:28 --> Input Class Initialized
INFO - 2023-09-22 13:54:28 --> Language Class Initialized
INFO - 2023-09-22 13:54:28 --> Language Class Initialized
INFO - 2023-09-22 13:54:28 --> Config Class Initialized
INFO - 2023-09-22 13:54:28 --> Loader Class Initialized
INFO - 2023-09-22 13:54:28 --> Helper loaded: url_helper
INFO - 2023-09-22 13:54:28 --> Helper loaded: file_helper
INFO - 2023-09-22 13:54:28 --> Helper loaded: form_helper
INFO - 2023-09-22 13:54:28 --> Helper loaded: my_helper
INFO - 2023-09-22 13:54:28 --> Database Driver Class Initialized
INFO - 2023-09-22 13:54:28 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-22 13:54:28 --> Controller Class Initialized
INFO - 2023-09-22 13:54:29 --> Config Class Initialized
INFO - 2023-09-22 13:54:29 --> Hooks Class Initialized
DEBUG - 2023-09-22 13:54:29 --> UTF-8 Support Enabled
INFO - 2023-09-22 13:54:29 --> Utf8 Class Initialized
INFO - 2023-09-22 13:54:29 --> URI Class Initialized
INFO - 2023-09-22 13:54:29 --> Router Class Initialized
INFO - 2023-09-22 13:54:29 --> Output Class Initialized
INFO - 2023-09-22 13:54:29 --> Security Class Initialized
DEBUG - 2023-09-22 13:54:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-22 13:54:29 --> Input Class Initialized
INFO - 2023-09-22 13:54:29 --> Language Class Initialized
INFO - 2023-09-22 13:54:29 --> Language Class Initialized
INFO - 2023-09-22 13:54:29 --> Config Class Initialized
INFO - 2023-09-22 13:54:29 --> Loader Class Initialized
INFO - 2023-09-22 13:54:29 --> Helper loaded: url_helper
INFO - 2023-09-22 13:54:29 --> Helper loaded: file_helper
INFO - 2023-09-22 13:54:29 --> Helper loaded: form_helper
INFO - 2023-09-22 13:54:29 --> Helper loaded: my_helper
INFO - 2023-09-22 13:54:29 --> Database Driver Class Initialized
INFO - 2023-09-22 13:54:29 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-22 13:54:29 --> Controller Class Initialized
INFO - 2023-09-22 13:54:29 --> Final output sent to browser
DEBUG - 2023-09-22 13:54:29 --> Total execution time: 0.0318
INFO - 2023-09-22 13:54:39 --> Config Class Initialized
INFO - 2023-09-22 13:54:39 --> Hooks Class Initialized
DEBUG - 2023-09-22 13:54:39 --> UTF-8 Support Enabled
INFO - 2023-09-22 13:54:39 --> Utf8 Class Initialized
INFO - 2023-09-22 13:54:39 --> URI Class Initialized
INFO - 2023-09-22 13:54:39 --> Router Class Initialized
INFO - 2023-09-22 13:54:39 --> Output Class Initialized
INFO - 2023-09-22 13:54:39 --> Security Class Initialized
DEBUG - 2023-09-22 13:54:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-22 13:54:39 --> Input Class Initialized
INFO - 2023-09-22 13:54:39 --> Language Class Initialized
INFO - 2023-09-22 13:54:39 --> Language Class Initialized
INFO - 2023-09-22 13:54:39 --> Config Class Initialized
INFO - 2023-09-22 13:54:39 --> Loader Class Initialized
INFO - 2023-09-22 13:54:39 --> Helper loaded: url_helper
INFO - 2023-09-22 13:54:39 --> Helper loaded: file_helper
INFO - 2023-09-22 13:54:39 --> Helper loaded: form_helper
INFO - 2023-09-22 13:54:39 --> Helper loaded: my_helper
INFO - 2023-09-22 13:54:39 --> Database Driver Class Initialized
INFO - 2023-09-22 13:54:39 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-22 13:54:39 --> Controller Class Initialized
DEBUG - 2023-09-22 13:54:39 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_catatan_homeroom/views/list.php
DEBUG - 2023-09-22 13:54:39 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-09-22 13:54:39 --> Final output sent to browser
DEBUG - 2023-09-22 13:54:39 --> Total execution time: 0.0443
INFO - 2023-09-22 13:55:01 --> Config Class Initialized
INFO - 2023-09-22 13:55:01 --> Hooks Class Initialized
DEBUG - 2023-09-22 13:55:01 --> UTF-8 Support Enabled
INFO - 2023-09-22 13:55:01 --> Utf8 Class Initialized
INFO - 2023-09-22 13:55:01 --> URI Class Initialized
INFO - 2023-09-22 13:55:01 --> Router Class Initialized
INFO - 2023-09-22 13:55:01 --> Output Class Initialized
INFO - 2023-09-22 13:55:01 --> Security Class Initialized
DEBUG - 2023-09-22 13:55:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-22 13:55:01 --> Input Class Initialized
INFO - 2023-09-22 13:55:01 --> Language Class Initialized
INFO - 2023-09-22 13:55:01 --> Language Class Initialized
INFO - 2023-09-22 13:55:01 --> Config Class Initialized
INFO - 2023-09-22 13:55:01 --> Loader Class Initialized
INFO - 2023-09-22 13:55:01 --> Helper loaded: url_helper
INFO - 2023-09-22 13:55:01 --> Helper loaded: file_helper
INFO - 2023-09-22 13:55:01 --> Helper loaded: form_helper
INFO - 2023-09-22 13:55:01 --> Helper loaded: my_helper
INFO - 2023-09-22 13:55:01 --> Database Driver Class Initialized
INFO - 2023-09-22 13:55:01 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-22 13:55:01 --> Controller Class Initialized
INFO - 2023-09-22 13:55:01 --> Final output sent to browser
DEBUG - 2023-09-22 13:55:01 --> Total execution time: 0.1326
INFO - 2023-09-22 13:55:01 --> Config Class Initialized
INFO - 2023-09-22 13:55:01 --> Hooks Class Initialized
DEBUG - 2023-09-22 13:55:01 --> UTF-8 Support Enabled
INFO - 2023-09-22 13:55:01 --> Utf8 Class Initialized
INFO - 2023-09-22 13:55:01 --> URI Class Initialized
INFO - 2023-09-22 13:55:01 --> Router Class Initialized
INFO - 2023-09-22 13:55:01 --> Output Class Initialized
INFO - 2023-09-22 13:55:01 --> Security Class Initialized
DEBUG - 2023-09-22 13:55:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-22 13:55:01 --> Input Class Initialized
INFO - 2023-09-22 13:55:01 --> Language Class Initialized
INFO - 2023-09-22 13:55:01 --> Language Class Initialized
INFO - 2023-09-22 13:55:01 --> Config Class Initialized
INFO - 2023-09-22 13:55:01 --> Loader Class Initialized
INFO - 2023-09-22 13:55:01 --> Helper loaded: url_helper
INFO - 2023-09-22 13:55:01 --> Helper loaded: file_helper
INFO - 2023-09-22 13:55:01 --> Helper loaded: form_helper
INFO - 2023-09-22 13:55:01 --> Helper loaded: my_helper
INFO - 2023-09-22 13:55:01 --> Database Driver Class Initialized
INFO - 2023-09-22 13:55:01 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-22 13:55:01 --> Controller Class Initialized
INFO - 2023-09-22 13:55:02 --> Config Class Initialized
INFO - 2023-09-22 13:55:02 --> Hooks Class Initialized
DEBUG - 2023-09-22 13:55:02 --> UTF-8 Support Enabled
INFO - 2023-09-22 13:55:02 --> Utf8 Class Initialized
INFO - 2023-09-22 13:55:02 --> URI Class Initialized
INFO - 2023-09-22 13:55:02 --> Router Class Initialized
INFO - 2023-09-22 13:55:02 --> Output Class Initialized
INFO - 2023-09-22 13:55:02 --> Security Class Initialized
DEBUG - 2023-09-22 13:55:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-22 13:55:02 --> Input Class Initialized
INFO - 2023-09-22 13:55:02 --> Language Class Initialized
INFO - 2023-09-22 13:55:03 --> Language Class Initialized
INFO - 2023-09-22 13:55:03 --> Config Class Initialized
INFO - 2023-09-22 13:55:03 --> Loader Class Initialized
INFO - 2023-09-22 13:55:03 --> Helper loaded: url_helper
INFO - 2023-09-22 13:55:03 --> Helper loaded: file_helper
INFO - 2023-09-22 13:55:03 --> Helper loaded: form_helper
INFO - 2023-09-22 13:55:03 --> Helper loaded: my_helper
INFO - 2023-09-22 13:55:03 --> Database Driver Class Initialized
INFO - 2023-09-22 13:55:03 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-22 13:55:03 --> Controller Class Initialized
INFO - 2023-09-22 13:55:03 --> Final output sent to browser
DEBUG - 2023-09-22 13:55:03 --> Total execution time: 0.0469
INFO - 2023-09-22 13:55:21 --> Config Class Initialized
INFO - 2023-09-22 13:55:21 --> Hooks Class Initialized
DEBUG - 2023-09-22 13:55:21 --> UTF-8 Support Enabled
INFO - 2023-09-22 13:55:21 --> Utf8 Class Initialized
INFO - 2023-09-22 13:55:21 --> URI Class Initialized
INFO - 2023-09-22 13:55:21 --> Router Class Initialized
INFO - 2023-09-22 13:55:21 --> Output Class Initialized
INFO - 2023-09-22 13:55:21 --> Security Class Initialized
DEBUG - 2023-09-22 13:55:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-22 13:55:21 --> Input Class Initialized
INFO - 2023-09-22 13:55:21 --> Language Class Initialized
INFO - 2023-09-22 13:55:21 --> Language Class Initialized
INFO - 2023-09-22 13:55:21 --> Config Class Initialized
INFO - 2023-09-22 13:55:21 --> Loader Class Initialized
INFO - 2023-09-22 13:55:21 --> Helper loaded: url_helper
INFO - 2023-09-22 13:55:21 --> Helper loaded: file_helper
INFO - 2023-09-22 13:55:21 --> Helper loaded: form_helper
INFO - 2023-09-22 13:55:21 --> Helper loaded: my_helper
INFO - 2023-09-22 13:55:21 --> Database Driver Class Initialized
INFO - 2023-09-22 13:55:21 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-22 13:55:21 --> Controller Class Initialized
INFO - 2023-09-22 13:55:21 --> Final output sent to browser
DEBUG - 2023-09-22 13:55:21 --> Total execution time: 0.0951
INFO - 2023-09-22 13:55:21 --> Config Class Initialized
INFO - 2023-09-22 13:55:21 --> Hooks Class Initialized
DEBUG - 2023-09-22 13:55:21 --> UTF-8 Support Enabled
INFO - 2023-09-22 13:55:21 --> Utf8 Class Initialized
INFO - 2023-09-22 13:55:21 --> URI Class Initialized
INFO - 2023-09-22 13:55:21 --> Router Class Initialized
INFO - 2023-09-22 13:55:21 --> Output Class Initialized
INFO - 2023-09-22 13:55:21 --> Security Class Initialized
DEBUG - 2023-09-22 13:55:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-22 13:55:21 --> Input Class Initialized
INFO - 2023-09-22 13:55:21 --> Language Class Initialized
INFO - 2023-09-22 13:55:21 --> Language Class Initialized
INFO - 2023-09-22 13:55:21 --> Config Class Initialized
INFO - 2023-09-22 13:55:21 --> Loader Class Initialized
INFO - 2023-09-22 13:55:21 --> Helper loaded: url_helper
INFO - 2023-09-22 13:55:21 --> Helper loaded: file_helper
INFO - 2023-09-22 13:55:21 --> Helper loaded: form_helper
INFO - 2023-09-22 13:55:21 --> Helper loaded: my_helper
INFO - 2023-09-22 13:55:21 --> Database Driver Class Initialized
INFO - 2023-09-22 13:55:21 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-22 13:55:21 --> Controller Class Initialized
INFO - 2023-09-22 13:55:46 --> Config Class Initialized
INFO - 2023-09-22 13:55:46 --> Hooks Class Initialized
DEBUG - 2023-09-22 13:55:46 --> UTF-8 Support Enabled
INFO - 2023-09-22 13:55:46 --> Utf8 Class Initialized
INFO - 2023-09-22 13:55:46 --> URI Class Initialized
INFO - 2023-09-22 13:55:46 --> Router Class Initialized
INFO - 2023-09-22 13:55:46 --> Output Class Initialized
INFO - 2023-09-22 13:55:46 --> Security Class Initialized
DEBUG - 2023-09-22 13:55:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-22 13:55:46 --> Input Class Initialized
INFO - 2023-09-22 13:55:46 --> Language Class Initialized
INFO - 2023-09-22 13:55:46 --> Language Class Initialized
INFO - 2023-09-22 13:55:46 --> Config Class Initialized
INFO - 2023-09-22 13:55:46 --> Loader Class Initialized
INFO - 2023-09-22 13:55:46 --> Helper loaded: url_helper
INFO - 2023-09-22 13:55:46 --> Helper loaded: file_helper
INFO - 2023-09-22 13:55:46 --> Helper loaded: form_helper
INFO - 2023-09-22 13:55:46 --> Helper loaded: my_helper
INFO - 2023-09-22 13:55:46 --> Database Driver Class Initialized
INFO - 2023-09-22 13:55:46 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-22 13:55:46 --> Controller Class Initialized
INFO - 2023-09-22 13:55:46 --> Final output sent to browser
DEBUG - 2023-09-22 13:55:46 --> Total execution time: 0.0329
INFO - 2023-09-22 13:56:43 --> Config Class Initialized
INFO - 2023-09-22 13:56:43 --> Hooks Class Initialized
DEBUG - 2023-09-22 13:56:43 --> UTF-8 Support Enabled
INFO - 2023-09-22 13:56:43 --> Utf8 Class Initialized
INFO - 2023-09-22 13:56:43 --> URI Class Initialized
INFO - 2023-09-22 13:56:43 --> Router Class Initialized
INFO - 2023-09-22 13:56:43 --> Output Class Initialized
INFO - 2023-09-22 13:56:43 --> Security Class Initialized
DEBUG - 2023-09-22 13:56:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-22 13:56:43 --> Input Class Initialized
INFO - 2023-09-22 13:56:43 --> Language Class Initialized
INFO - 2023-09-22 13:56:43 --> Language Class Initialized
INFO - 2023-09-22 13:56:43 --> Config Class Initialized
INFO - 2023-09-22 13:56:43 --> Loader Class Initialized
INFO - 2023-09-22 13:56:43 --> Helper loaded: url_helper
INFO - 2023-09-22 13:56:43 --> Helper loaded: file_helper
INFO - 2023-09-22 13:56:43 --> Helper loaded: form_helper
INFO - 2023-09-22 13:56:43 --> Helper loaded: my_helper
INFO - 2023-09-22 13:56:43 --> Database Driver Class Initialized
INFO - 2023-09-22 13:56:43 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-22 13:56:43 --> Controller Class Initialized
DEBUG - 2023-09-22 13:56:43 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/view_mapel/views/v_view_mapel.php
DEBUG - 2023-09-22 13:56:43 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-09-22 13:56:43 --> Final output sent to browser
DEBUG - 2023-09-22 13:56:43 --> Total execution time: 0.0347
INFO - 2023-09-22 13:56:48 --> Config Class Initialized
INFO - 2023-09-22 13:56:48 --> Hooks Class Initialized
DEBUG - 2023-09-22 13:56:48 --> UTF-8 Support Enabled
INFO - 2023-09-22 13:56:48 --> Utf8 Class Initialized
INFO - 2023-09-22 13:56:48 --> URI Class Initialized
INFO - 2023-09-22 13:56:48 --> Router Class Initialized
INFO - 2023-09-22 13:56:48 --> Output Class Initialized
INFO - 2023-09-22 13:56:48 --> Security Class Initialized
DEBUG - 2023-09-22 13:56:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-22 13:56:48 --> Input Class Initialized
INFO - 2023-09-22 13:56:48 --> Language Class Initialized
INFO - 2023-09-22 13:56:48 --> Language Class Initialized
INFO - 2023-09-22 13:56:48 --> Config Class Initialized
INFO - 2023-09-22 13:56:48 --> Loader Class Initialized
INFO - 2023-09-22 13:56:48 --> Helper loaded: url_helper
INFO - 2023-09-22 13:56:48 --> Helper loaded: file_helper
INFO - 2023-09-22 13:56:48 --> Helper loaded: form_helper
INFO - 2023-09-22 13:56:48 --> Helper loaded: my_helper
INFO - 2023-09-22 13:56:48 --> Database Driver Class Initialized
INFO - 2023-09-22 13:56:48 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-22 13:56:48 --> Controller Class Initialized
DEBUG - 2023-09-22 13:56:48 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/views/list.php
DEBUG - 2023-09-22 13:56:48 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-09-22 13:56:48 --> Final output sent to browser
DEBUG - 2023-09-22 13:56:48 --> Total execution time: 0.0674
INFO - 2023-09-22 13:56:48 --> Config Class Initialized
INFO - 2023-09-22 13:56:48 --> Hooks Class Initialized
DEBUG - 2023-09-22 13:56:48 --> UTF-8 Support Enabled
INFO - 2023-09-22 13:56:48 --> Utf8 Class Initialized
INFO - 2023-09-22 13:56:48 --> URI Class Initialized
INFO - 2023-09-22 13:56:48 --> Router Class Initialized
INFO - 2023-09-22 13:56:48 --> Output Class Initialized
INFO - 2023-09-22 13:56:48 --> Security Class Initialized
DEBUG - 2023-09-22 13:56:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-22 13:56:48 --> Input Class Initialized
INFO - 2023-09-22 13:56:48 --> Language Class Initialized
INFO - 2023-09-22 13:56:48 --> Language Class Initialized
INFO - 2023-09-22 13:56:48 --> Config Class Initialized
INFO - 2023-09-22 13:56:48 --> Loader Class Initialized
INFO - 2023-09-22 13:56:48 --> Helper loaded: url_helper
INFO - 2023-09-22 13:56:48 --> Helper loaded: file_helper
INFO - 2023-09-22 13:56:48 --> Helper loaded: form_helper
INFO - 2023-09-22 13:56:48 --> Helper loaded: my_helper
INFO - 2023-09-22 13:56:48 --> Database Driver Class Initialized
INFO - 2023-09-22 13:56:48 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-22 13:56:48 --> Controller Class Initialized
INFO - 2023-09-22 13:56:51 --> Config Class Initialized
INFO - 2023-09-22 13:56:51 --> Hooks Class Initialized
DEBUG - 2023-09-22 13:56:51 --> UTF-8 Support Enabled
INFO - 2023-09-22 13:56:51 --> Utf8 Class Initialized
INFO - 2023-09-22 13:56:51 --> URI Class Initialized
INFO - 2023-09-22 13:56:51 --> Router Class Initialized
INFO - 2023-09-22 13:56:51 --> Output Class Initialized
INFO - 2023-09-22 13:56:51 --> Security Class Initialized
DEBUG - 2023-09-22 13:56:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-22 13:56:51 --> Input Class Initialized
INFO - 2023-09-22 13:56:51 --> Language Class Initialized
INFO - 2023-09-22 13:56:51 --> Language Class Initialized
INFO - 2023-09-22 13:56:51 --> Config Class Initialized
INFO - 2023-09-22 13:56:51 --> Loader Class Initialized
INFO - 2023-09-22 13:56:51 --> Helper loaded: url_helper
INFO - 2023-09-22 13:56:51 --> Helper loaded: file_helper
INFO - 2023-09-22 13:56:51 --> Helper loaded: form_helper
INFO - 2023-09-22 13:56:51 --> Helper loaded: my_helper
INFO - 2023-09-22 13:56:51 --> Database Driver Class Initialized
INFO - 2023-09-22 13:56:51 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-22 13:56:51 --> Controller Class Initialized
INFO - 2023-09-22 13:56:51 --> Final output sent to browser
DEBUG - 2023-09-22 13:56:51 --> Total execution time: 0.0314
INFO - 2023-09-22 13:57:19 --> Config Class Initialized
INFO - 2023-09-22 13:57:19 --> Hooks Class Initialized
DEBUG - 2023-09-22 13:57:19 --> UTF-8 Support Enabled
INFO - 2023-09-22 13:57:19 --> Utf8 Class Initialized
INFO - 2023-09-22 13:57:19 --> URI Class Initialized
INFO - 2023-09-22 13:57:19 --> Router Class Initialized
INFO - 2023-09-22 13:57:19 --> Output Class Initialized
INFO - 2023-09-22 13:57:19 --> Security Class Initialized
DEBUG - 2023-09-22 13:57:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-22 13:57:19 --> Input Class Initialized
INFO - 2023-09-22 13:57:19 --> Language Class Initialized
INFO - 2023-09-22 13:57:19 --> Language Class Initialized
INFO - 2023-09-22 13:57:19 --> Config Class Initialized
INFO - 2023-09-22 13:57:19 --> Loader Class Initialized
INFO - 2023-09-22 13:57:19 --> Helper loaded: url_helper
INFO - 2023-09-22 13:57:19 --> Helper loaded: file_helper
INFO - 2023-09-22 13:57:19 --> Helper loaded: form_helper
INFO - 2023-09-22 13:57:19 --> Helper loaded: my_helper
INFO - 2023-09-22 13:57:19 --> Database Driver Class Initialized
INFO - 2023-09-22 13:57:19 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-22 13:57:19 --> Controller Class Initialized
INFO - 2023-09-22 13:57:19 --> Final output sent to browser
DEBUG - 2023-09-22 13:57:19 --> Total execution time: 0.0767
INFO - 2023-09-22 13:57:19 --> Config Class Initialized
INFO - 2023-09-22 13:57:19 --> Hooks Class Initialized
DEBUG - 2023-09-22 13:57:19 --> UTF-8 Support Enabled
INFO - 2023-09-22 13:57:19 --> Utf8 Class Initialized
INFO - 2023-09-22 13:57:19 --> URI Class Initialized
INFO - 2023-09-22 13:57:19 --> Router Class Initialized
INFO - 2023-09-22 13:57:19 --> Output Class Initialized
INFO - 2023-09-22 13:57:19 --> Security Class Initialized
DEBUG - 2023-09-22 13:57:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-22 13:57:19 --> Input Class Initialized
INFO - 2023-09-22 13:57:19 --> Language Class Initialized
INFO - 2023-09-22 13:57:19 --> Language Class Initialized
INFO - 2023-09-22 13:57:19 --> Config Class Initialized
INFO - 2023-09-22 13:57:19 --> Loader Class Initialized
INFO - 2023-09-22 13:57:19 --> Helper loaded: url_helper
INFO - 2023-09-22 13:57:19 --> Helper loaded: file_helper
INFO - 2023-09-22 13:57:19 --> Helper loaded: form_helper
INFO - 2023-09-22 13:57:19 --> Helper loaded: my_helper
INFO - 2023-09-22 13:57:19 --> Database Driver Class Initialized
INFO - 2023-09-22 13:57:19 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-22 13:57:19 --> Controller Class Initialized
INFO - 2023-09-22 13:57:20 --> Config Class Initialized
INFO - 2023-09-22 13:57:20 --> Hooks Class Initialized
DEBUG - 2023-09-22 13:57:20 --> UTF-8 Support Enabled
INFO - 2023-09-22 13:57:20 --> Utf8 Class Initialized
INFO - 2023-09-22 13:57:20 --> URI Class Initialized
INFO - 2023-09-22 13:57:20 --> Router Class Initialized
INFO - 2023-09-22 13:57:20 --> Output Class Initialized
INFO - 2023-09-22 13:57:20 --> Security Class Initialized
DEBUG - 2023-09-22 13:57:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-22 13:57:20 --> Input Class Initialized
INFO - 2023-09-22 13:57:20 --> Language Class Initialized
INFO - 2023-09-22 13:57:20 --> Language Class Initialized
INFO - 2023-09-22 13:57:20 --> Config Class Initialized
INFO - 2023-09-22 13:57:20 --> Loader Class Initialized
INFO - 2023-09-22 13:57:20 --> Helper loaded: url_helper
INFO - 2023-09-22 13:57:20 --> Helper loaded: file_helper
INFO - 2023-09-22 13:57:20 --> Helper loaded: form_helper
INFO - 2023-09-22 13:57:20 --> Helper loaded: my_helper
INFO - 2023-09-22 13:57:20 --> Database Driver Class Initialized
INFO - 2023-09-22 13:57:20 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-22 13:57:20 --> Controller Class Initialized
INFO - 2023-09-22 13:57:20 --> Final output sent to browser
DEBUG - 2023-09-22 13:57:20 --> Total execution time: 0.0355
INFO - 2023-09-22 13:57:39 --> Config Class Initialized
INFO - 2023-09-22 13:57:39 --> Hooks Class Initialized
DEBUG - 2023-09-22 13:57:39 --> UTF-8 Support Enabled
INFO - 2023-09-22 13:57:39 --> Utf8 Class Initialized
INFO - 2023-09-22 13:57:39 --> URI Class Initialized
INFO - 2023-09-22 13:57:39 --> Router Class Initialized
INFO - 2023-09-22 13:57:39 --> Output Class Initialized
INFO - 2023-09-22 13:57:39 --> Security Class Initialized
DEBUG - 2023-09-22 13:57:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-22 13:57:39 --> Input Class Initialized
INFO - 2023-09-22 13:57:39 --> Language Class Initialized
INFO - 2023-09-22 13:57:39 --> Language Class Initialized
INFO - 2023-09-22 13:57:39 --> Config Class Initialized
INFO - 2023-09-22 13:57:39 --> Loader Class Initialized
INFO - 2023-09-22 13:57:39 --> Helper loaded: url_helper
INFO - 2023-09-22 13:57:39 --> Helper loaded: file_helper
INFO - 2023-09-22 13:57:39 --> Helper loaded: form_helper
INFO - 2023-09-22 13:57:39 --> Helper loaded: my_helper
INFO - 2023-09-22 13:57:39 --> Database Driver Class Initialized
INFO - 2023-09-22 13:57:39 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-22 13:57:39 --> Controller Class Initialized
INFO - 2023-09-22 13:57:39 --> Final output sent to browser
DEBUG - 2023-09-22 13:57:39 --> Total execution time: 0.0346
INFO - 2023-09-22 13:57:39 --> Config Class Initialized
INFO - 2023-09-22 13:57:39 --> Hooks Class Initialized
DEBUG - 2023-09-22 13:57:39 --> UTF-8 Support Enabled
INFO - 2023-09-22 13:57:39 --> Utf8 Class Initialized
INFO - 2023-09-22 13:57:39 --> URI Class Initialized
INFO - 2023-09-22 13:57:39 --> Router Class Initialized
INFO - 2023-09-22 13:57:39 --> Output Class Initialized
INFO - 2023-09-22 13:57:39 --> Security Class Initialized
DEBUG - 2023-09-22 13:57:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-22 13:57:39 --> Input Class Initialized
INFO - 2023-09-22 13:57:39 --> Language Class Initialized
INFO - 2023-09-22 13:57:39 --> Language Class Initialized
INFO - 2023-09-22 13:57:39 --> Config Class Initialized
INFO - 2023-09-22 13:57:39 --> Loader Class Initialized
INFO - 2023-09-22 13:57:39 --> Helper loaded: url_helper
INFO - 2023-09-22 13:57:39 --> Helper loaded: file_helper
INFO - 2023-09-22 13:57:39 --> Helper loaded: form_helper
INFO - 2023-09-22 13:57:39 --> Helper loaded: my_helper
INFO - 2023-09-22 13:57:39 --> Database Driver Class Initialized
INFO - 2023-09-22 13:57:39 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-22 13:57:39 --> Controller Class Initialized
INFO - 2023-09-22 13:58:02 --> Config Class Initialized
INFO - 2023-09-22 13:58:02 --> Hooks Class Initialized
DEBUG - 2023-09-22 13:58:02 --> UTF-8 Support Enabled
INFO - 2023-09-22 13:58:02 --> Utf8 Class Initialized
INFO - 2023-09-22 13:58:02 --> URI Class Initialized
INFO - 2023-09-22 13:58:02 --> Router Class Initialized
INFO - 2023-09-22 13:58:02 --> Output Class Initialized
INFO - 2023-09-22 13:58:02 --> Security Class Initialized
DEBUG - 2023-09-22 13:58:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-22 13:58:02 --> Input Class Initialized
INFO - 2023-09-22 13:58:02 --> Language Class Initialized
INFO - 2023-09-22 13:58:02 --> Language Class Initialized
INFO - 2023-09-22 13:58:02 --> Config Class Initialized
INFO - 2023-09-22 13:58:02 --> Loader Class Initialized
INFO - 2023-09-22 13:58:02 --> Helper loaded: url_helper
INFO - 2023-09-22 13:58:02 --> Helper loaded: file_helper
INFO - 2023-09-22 13:58:02 --> Helper loaded: form_helper
INFO - 2023-09-22 13:58:02 --> Helper loaded: my_helper
INFO - 2023-09-22 13:58:02 --> Database Driver Class Initialized
INFO - 2023-09-22 13:58:02 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-22 13:58:02 --> Controller Class Initialized
INFO - 2023-09-22 13:58:02 --> Final output sent to browser
DEBUG - 2023-09-22 13:58:02 --> Total execution time: 0.1434
INFO - 2023-09-22 13:58:04 --> Config Class Initialized
INFO - 2023-09-22 13:58:04 --> Hooks Class Initialized
DEBUG - 2023-09-22 13:58:04 --> UTF-8 Support Enabled
INFO - 2023-09-22 13:58:04 --> Utf8 Class Initialized
INFO - 2023-09-22 13:58:04 --> URI Class Initialized
INFO - 2023-09-22 13:58:04 --> Router Class Initialized
INFO - 2023-09-22 13:58:04 --> Output Class Initialized
INFO - 2023-09-22 13:58:04 --> Security Class Initialized
DEBUG - 2023-09-22 13:58:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-22 13:58:04 --> Input Class Initialized
INFO - 2023-09-22 13:58:04 --> Language Class Initialized
INFO - 2023-09-22 13:58:04 --> Language Class Initialized
INFO - 2023-09-22 13:58:04 --> Config Class Initialized
INFO - 2023-09-22 13:58:04 --> Loader Class Initialized
INFO - 2023-09-22 13:58:04 --> Helper loaded: url_helper
INFO - 2023-09-22 13:58:04 --> Helper loaded: file_helper
INFO - 2023-09-22 13:58:04 --> Helper loaded: form_helper
INFO - 2023-09-22 13:58:04 --> Helper loaded: my_helper
INFO - 2023-09-22 13:58:04 --> Database Driver Class Initialized
INFO - 2023-09-22 13:58:04 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-22 13:58:04 --> Controller Class Initialized
INFO - 2023-09-22 13:58:04 --> Final output sent to browser
DEBUG - 2023-09-22 13:58:04 --> Total execution time: 0.0469
INFO - 2023-09-22 13:58:14 --> Config Class Initialized
INFO - 2023-09-22 13:58:14 --> Hooks Class Initialized
DEBUG - 2023-09-22 13:58:14 --> UTF-8 Support Enabled
INFO - 2023-09-22 13:58:14 --> Utf8 Class Initialized
INFO - 2023-09-22 13:58:14 --> URI Class Initialized
INFO - 2023-09-22 13:58:14 --> Router Class Initialized
INFO - 2023-09-22 13:58:14 --> Output Class Initialized
INFO - 2023-09-22 13:58:14 --> Security Class Initialized
DEBUG - 2023-09-22 13:58:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-22 13:58:14 --> Input Class Initialized
INFO - 2023-09-22 13:58:14 --> Language Class Initialized
INFO - 2023-09-22 13:58:14 --> Language Class Initialized
INFO - 2023-09-22 13:58:14 --> Config Class Initialized
INFO - 2023-09-22 13:58:14 --> Loader Class Initialized
INFO - 2023-09-22 13:58:14 --> Helper loaded: url_helper
INFO - 2023-09-22 13:58:14 --> Helper loaded: file_helper
INFO - 2023-09-22 13:58:14 --> Helper loaded: form_helper
INFO - 2023-09-22 13:58:14 --> Helper loaded: my_helper
INFO - 2023-09-22 13:58:14 --> Database Driver Class Initialized
INFO - 2023-09-22 13:58:14 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-22 13:58:14 --> Controller Class Initialized
INFO - 2023-09-22 13:58:14 --> Final output sent to browser
DEBUG - 2023-09-22 13:58:14 --> Total execution time: 0.0958
INFO - 2023-09-22 13:58:20 --> Config Class Initialized
INFO - 2023-09-22 13:58:20 --> Hooks Class Initialized
DEBUG - 2023-09-22 13:58:20 --> UTF-8 Support Enabled
INFO - 2023-09-22 13:58:20 --> Utf8 Class Initialized
INFO - 2023-09-22 13:58:20 --> URI Class Initialized
INFO - 2023-09-22 13:58:20 --> Router Class Initialized
INFO - 2023-09-22 13:58:20 --> Output Class Initialized
INFO - 2023-09-22 13:58:20 --> Security Class Initialized
DEBUG - 2023-09-22 13:58:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-22 13:58:20 --> Input Class Initialized
INFO - 2023-09-22 13:58:20 --> Language Class Initialized
INFO - 2023-09-22 13:58:20 --> Language Class Initialized
INFO - 2023-09-22 13:58:20 --> Config Class Initialized
INFO - 2023-09-22 13:58:20 --> Loader Class Initialized
INFO - 2023-09-22 13:58:20 --> Helper loaded: url_helper
INFO - 2023-09-22 13:58:20 --> Helper loaded: file_helper
INFO - 2023-09-22 13:58:20 --> Helper loaded: form_helper
INFO - 2023-09-22 13:58:20 --> Helper loaded: my_helper
INFO - 2023-09-22 13:58:20 --> Database Driver Class Initialized
INFO - 2023-09-22 13:58:20 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-22 13:58:20 --> Controller Class Initialized
INFO - 2023-09-22 13:58:20 --> Final output sent to browser
DEBUG - 2023-09-22 13:58:20 --> Total execution time: 0.0702
INFO - 2023-09-22 13:59:02 --> Config Class Initialized
INFO - 2023-09-22 13:59:02 --> Hooks Class Initialized
DEBUG - 2023-09-22 13:59:02 --> UTF-8 Support Enabled
INFO - 2023-09-22 13:59:02 --> Utf8 Class Initialized
INFO - 2023-09-22 13:59:02 --> URI Class Initialized
INFO - 2023-09-22 13:59:02 --> Router Class Initialized
INFO - 2023-09-22 13:59:02 --> Output Class Initialized
INFO - 2023-09-22 13:59:02 --> Security Class Initialized
DEBUG - 2023-09-22 13:59:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-22 13:59:02 --> Input Class Initialized
INFO - 2023-09-22 13:59:02 --> Language Class Initialized
INFO - 2023-09-22 13:59:02 --> Language Class Initialized
INFO - 2023-09-22 13:59:02 --> Config Class Initialized
INFO - 2023-09-22 13:59:02 --> Loader Class Initialized
INFO - 2023-09-22 13:59:02 --> Helper loaded: url_helper
INFO - 2023-09-22 13:59:02 --> Helper loaded: file_helper
INFO - 2023-09-22 13:59:02 --> Helper loaded: form_helper
INFO - 2023-09-22 13:59:02 --> Helper loaded: my_helper
INFO - 2023-09-22 13:59:02 --> Database Driver Class Initialized
INFO - 2023-09-22 13:59:02 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-22 13:59:02 --> Controller Class Initialized
INFO - 2023-09-22 13:59:02 --> Final output sent to browser
DEBUG - 2023-09-22 13:59:02 --> Total execution time: 0.0956
INFO - 2023-09-22 13:59:13 --> Config Class Initialized
INFO - 2023-09-22 13:59:13 --> Hooks Class Initialized
DEBUG - 2023-09-22 13:59:13 --> UTF-8 Support Enabled
INFO - 2023-09-22 13:59:13 --> Utf8 Class Initialized
INFO - 2023-09-22 13:59:13 --> URI Class Initialized
INFO - 2023-09-22 13:59:13 --> Router Class Initialized
INFO - 2023-09-22 13:59:13 --> Output Class Initialized
INFO - 2023-09-22 13:59:13 --> Security Class Initialized
DEBUG - 2023-09-22 13:59:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-22 13:59:13 --> Input Class Initialized
INFO - 2023-09-22 13:59:13 --> Language Class Initialized
INFO - 2023-09-22 13:59:13 --> Language Class Initialized
INFO - 2023-09-22 13:59:13 --> Config Class Initialized
INFO - 2023-09-22 13:59:13 --> Loader Class Initialized
INFO - 2023-09-22 13:59:13 --> Helper loaded: url_helper
INFO - 2023-09-22 13:59:13 --> Helper loaded: file_helper
INFO - 2023-09-22 13:59:13 --> Helper loaded: form_helper
INFO - 2023-09-22 13:59:13 --> Helper loaded: my_helper
INFO - 2023-09-22 13:59:13 --> Database Driver Class Initialized
INFO - 2023-09-22 13:59:13 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-22 13:59:13 --> Controller Class Initialized
DEBUG - 2023-09-22 13:59:13 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/riwayat_mengajar/views/list.php
DEBUG - 2023-09-22 13:59:13 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-09-22 13:59:13 --> Final output sent to browser
DEBUG - 2023-09-22 13:59:13 --> Total execution time: 0.0825
INFO - 2023-09-22 13:59:27 --> Config Class Initialized
INFO - 2023-09-22 13:59:27 --> Hooks Class Initialized
DEBUG - 2023-09-22 13:59:27 --> UTF-8 Support Enabled
INFO - 2023-09-22 13:59:27 --> Utf8 Class Initialized
INFO - 2023-09-22 13:59:27 --> URI Class Initialized
INFO - 2023-09-22 13:59:27 --> Router Class Initialized
INFO - 2023-09-22 13:59:27 --> Output Class Initialized
INFO - 2023-09-22 13:59:27 --> Security Class Initialized
DEBUG - 2023-09-22 13:59:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-22 13:59:27 --> Input Class Initialized
INFO - 2023-09-22 13:59:27 --> Language Class Initialized
INFO - 2023-09-22 13:59:27 --> Language Class Initialized
INFO - 2023-09-22 13:59:27 --> Config Class Initialized
INFO - 2023-09-22 13:59:27 --> Loader Class Initialized
INFO - 2023-09-22 13:59:27 --> Helper loaded: url_helper
INFO - 2023-09-22 13:59:27 --> Helper loaded: file_helper
INFO - 2023-09-22 13:59:27 --> Helper loaded: form_helper
INFO - 2023-09-22 13:59:27 --> Helper loaded: my_helper
INFO - 2023-09-22 13:59:27 --> Database Driver Class Initialized
INFO - 2023-09-22 13:59:27 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-22 13:59:27 --> Controller Class Initialized
DEBUG - 2023-09-22 13:59:27 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/view_mapel/views/v_view_mapel.php
DEBUG - 2023-09-22 13:59:27 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-09-22 13:59:27 --> Final output sent to browser
DEBUG - 2023-09-22 13:59:27 --> Total execution time: 0.0338
INFO - 2023-09-22 13:59:36 --> Config Class Initialized
INFO - 2023-09-22 13:59:36 --> Hooks Class Initialized
DEBUG - 2023-09-22 13:59:36 --> UTF-8 Support Enabled
INFO - 2023-09-22 13:59:36 --> Utf8 Class Initialized
INFO - 2023-09-22 13:59:36 --> URI Class Initialized
INFO - 2023-09-22 13:59:36 --> Router Class Initialized
INFO - 2023-09-22 13:59:36 --> Output Class Initialized
INFO - 2023-09-22 13:59:36 --> Security Class Initialized
DEBUG - 2023-09-22 13:59:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-22 13:59:36 --> Input Class Initialized
INFO - 2023-09-22 13:59:36 --> Language Class Initialized
INFO - 2023-09-22 13:59:36 --> Language Class Initialized
INFO - 2023-09-22 13:59:36 --> Config Class Initialized
INFO - 2023-09-22 13:59:36 --> Loader Class Initialized
INFO - 2023-09-22 13:59:36 --> Helper loaded: url_helper
INFO - 2023-09-22 13:59:36 --> Helper loaded: file_helper
INFO - 2023-09-22 13:59:36 --> Helper loaded: form_helper
INFO - 2023-09-22 13:59:36 --> Helper loaded: my_helper
INFO - 2023-09-22 13:59:36 --> Database Driver Class Initialized
INFO - 2023-09-22 13:59:36 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-22 13:59:36 --> Controller Class Initialized
DEBUG - 2023-09-22 13:59:36 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/riwayat_mengajar/views/list.php
DEBUG - 2023-09-22 13:59:36 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-09-22 13:59:36 --> Final output sent to browser
DEBUG - 2023-09-22 13:59:36 --> Total execution time: 0.0402
INFO - 2023-09-22 13:59:39 --> Config Class Initialized
INFO - 2023-09-22 13:59:39 --> Hooks Class Initialized
DEBUG - 2023-09-22 13:59:39 --> UTF-8 Support Enabled
INFO - 2023-09-22 13:59:39 --> Utf8 Class Initialized
INFO - 2023-09-22 13:59:39 --> URI Class Initialized
INFO - 2023-09-22 13:59:39 --> Router Class Initialized
INFO - 2023-09-22 13:59:39 --> Output Class Initialized
INFO - 2023-09-22 13:59:39 --> Security Class Initialized
DEBUG - 2023-09-22 13:59:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-22 13:59:39 --> Input Class Initialized
INFO - 2023-09-22 13:59:39 --> Language Class Initialized
INFO - 2023-09-22 13:59:39 --> Language Class Initialized
INFO - 2023-09-22 13:59:39 --> Config Class Initialized
INFO - 2023-09-22 13:59:39 --> Loader Class Initialized
INFO - 2023-09-22 13:59:39 --> Helper loaded: url_helper
INFO - 2023-09-22 13:59:39 --> Helper loaded: file_helper
INFO - 2023-09-22 13:59:39 --> Helper loaded: form_helper
INFO - 2023-09-22 13:59:39 --> Helper loaded: my_helper
INFO - 2023-09-22 13:59:39 --> Database Driver Class Initialized
INFO - 2023-09-22 13:59:39 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-22 13:59:39 --> Controller Class Initialized
ERROR - 2023-09-22 13:59:39 --> Severity: Notice --> Undefined variable: q_siswa_kelas /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/controllers/N_pengetahuan.php 115
ERROR - 2023-09-22 13:59:39 --> Severity: Warning --> Invalid argument supplied for foreach() /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/controllers/N_pengetahuan.php 115
ERROR - 2023-09-22 13:59:39 --> Severity: Notice --> Undefined offset: 1 /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/controllers/N_pengetahuan.php 202
ERROR - 2023-09-22 13:59:39 --> Severity: Notice --> Undefined offset: 1 /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/controllers/N_pengetahuan.php 203
ERROR - 2023-09-22 13:59:39 --> Severity: Notice --> Undefined offset: 1 /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/controllers/N_pengetahuan.php 202
ERROR - 2023-09-22 13:59:39 --> Severity: Notice --> Undefined offset: 1 /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/controllers/N_pengetahuan.php 203
ERROR - 2023-09-22 13:59:39 --> Severity: Notice --> Undefined offset: 1 /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/controllers/N_pengetahuan.php 202
ERROR - 2023-09-22 13:59:39 --> Severity: Notice --> Undefined offset: 1 /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/controllers/N_pengetahuan.php 203
ERROR - 2023-09-22 13:59:39 --> Severity: Notice --> Undefined offset: 1 /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/controllers/N_pengetahuan.php 202
ERROR - 2023-09-22 13:59:39 --> Severity: Notice --> Undefined offset: 1 /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/controllers/N_pengetahuan.php 203
ERROR - 2023-09-22 13:59:39 --> Severity: Notice --> Undefined offset: 1 /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/controllers/N_pengetahuan.php 202
ERROR - 2023-09-22 13:59:39 --> Severity: Notice --> Undefined offset: 1 /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/controllers/N_pengetahuan.php 203
ERROR - 2023-09-22 13:59:39 --> Severity: Notice --> Undefined offset: 1 /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/controllers/N_pengetahuan.php 202
ERROR - 2023-09-22 13:59:39 --> Severity: Notice --> Undefined offset: 1 /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/controllers/N_pengetahuan.php 203
ERROR - 2023-09-22 13:59:39 --> Severity: Notice --> Undefined offset: 1 /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/controllers/N_pengetahuan.php 202
ERROR - 2023-09-22 13:59:39 --> Severity: Notice --> Undefined offset: 1 /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/controllers/N_pengetahuan.php 203
ERROR - 2023-09-22 13:59:39 --> Severity: Notice --> Undefined offset: 1 /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/controllers/N_pengetahuan.php 202
ERROR - 2023-09-22 13:59:39 --> Severity: Notice --> Undefined offset: 1 /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/controllers/N_pengetahuan.php 203
ERROR - 2023-09-22 13:59:39 --> Severity: Notice --> Undefined offset: 1 /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/controllers/N_pengetahuan.php 202
ERROR - 2023-09-22 13:59:39 --> Severity: Notice --> Undefined offset: 1 /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/controllers/N_pengetahuan.php 203
ERROR - 2023-09-22 13:59:39 --> Severity: Notice --> Undefined offset: 1 /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/controllers/N_pengetahuan.php 202
ERROR - 2023-09-22 13:59:39 --> Severity: Notice --> Undefined offset: 1 /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/controllers/N_pengetahuan.php 203
ERROR - 2023-09-22 13:59:39 --> Severity: Notice --> Undefined offset: 1 /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/controllers/N_pengetahuan.php 202
ERROR - 2023-09-22 13:59:39 --> Severity: Notice --> Undefined offset: 1 /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/controllers/N_pengetahuan.php 203
ERROR - 2023-09-22 13:59:39 --> Severity: Notice --> Undefined offset: 1 /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/controllers/N_pengetahuan.php 202
ERROR - 2023-09-22 13:59:39 --> Severity: Notice --> Undefined offset: 1 /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/controllers/N_pengetahuan.php 203
ERROR - 2023-09-22 13:59:39 --> Severity: Notice --> Undefined offset: 1 /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/controllers/N_pengetahuan.php 202
ERROR - 2023-09-22 13:59:39 --> Severity: Notice --> Undefined offset: 1 /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/controllers/N_pengetahuan.php 203
ERROR - 2023-09-22 13:59:39 --> Severity: Notice --> Undefined offset: 1 /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/controllers/N_pengetahuan.php 202
ERROR - 2023-09-22 13:59:39 --> Severity: Notice --> Undefined offset: 1 /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/controllers/N_pengetahuan.php 203
ERROR - 2023-09-22 13:59:39 --> Severity: Notice --> Undefined offset: 1 /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/controllers/N_pengetahuan.php 202
ERROR - 2023-09-22 13:59:39 --> Severity: Notice --> Undefined offset: 1 /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/controllers/N_pengetahuan.php 203
ERROR - 2023-09-22 13:59:39 --> Severity: Notice --> Undefined offset: 1 /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/controllers/N_pengetahuan.php 202
ERROR - 2023-09-22 13:59:39 --> Severity: Notice --> Undefined offset: 1 /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/controllers/N_pengetahuan.php 203
DEBUG - 2023-09-22 13:59:39 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/views/cetak.php
INFO - 2023-09-22 13:59:39 --> Final output sent to browser
DEBUG - 2023-09-22 13:59:39 --> Total execution time: 0.0643
INFO - 2023-09-22 13:59:51 --> Config Class Initialized
INFO - 2023-09-22 13:59:51 --> Hooks Class Initialized
DEBUG - 2023-09-22 13:59:51 --> UTF-8 Support Enabled
INFO - 2023-09-22 13:59:51 --> Utf8 Class Initialized
INFO - 2023-09-22 13:59:51 --> URI Class Initialized
INFO - 2023-09-22 13:59:51 --> Router Class Initialized
INFO - 2023-09-22 13:59:51 --> Output Class Initialized
INFO - 2023-09-22 13:59:51 --> Security Class Initialized
DEBUG - 2023-09-22 13:59:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-22 13:59:51 --> Input Class Initialized
INFO - 2023-09-22 13:59:51 --> Language Class Initialized
INFO - 2023-09-22 13:59:51 --> Language Class Initialized
INFO - 2023-09-22 13:59:51 --> Config Class Initialized
INFO - 2023-09-22 13:59:51 --> Loader Class Initialized
INFO - 2023-09-22 13:59:51 --> Helper loaded: url_helper
INFO - 2023-09-22 13:59:51 --> Helper loaded: file_helper
INFO - 2023-09-22 13:59:51 --> Helper loaded: form_helper
INFO - 2023-09-22 13:59:51 --> Helper loaded: my_helper
INFO - 2023-09-22 13:59:51 --> Database Driver Class Initialized
INFO - 2023-09-22 13:59:51 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-22 13:59:51 --> Controller Class Initialized
DEBUG - 2023-09-22 13:59:51 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/view_mapel/views/v_view_mapel.php
DEBUG - 2023-09-22 13:59:51 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-09-22 13:59:51 --> Final output sent to browser
DEBUG - 2023-09-22 13:59:51 --> Total execution time: 0.0371
INFO - 2023-09-22 13:59:54 --> Config Class Initialized
INFO - 2023-09-22 13:59:54 --> Hooks Class Initialized
DEBUG - 2023-09-22 13:59:54 --> UTF-8 Support Enabled
INFO - 2023-09-22 13:59:54 --> Utf8 Class Initialized
INFO - 2023-09-22 13:59:54 --> URI Class Initialized
DEBUG - 2023-09-22 13:59:54 --> No URI present. Default controller set.
INFO - 2023-09-22 13:59:54 --> Router Class Initialized
INFO - 2023-09-22 13:59:54 --> Output Class Initialized
INFO - 2023-09-22 13:59:54 --> Security Class Initialized
DEBUG - 2023-09-22 13:59:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-22 13:59:54 --> Input Class Initialized
INFO - 2023-09-22 13:59:54 --> Language Class Initialized
INFO - 2023-09-22 13:59:54 --> Language Class Initialized
INFO - 2023-09-22 13:59:54 --> Config Class Initialized
INFO - 2023-09-22 13:59:54 --> Loader Class Initialized
INFO - 2023-09-22 13:59:54 --> Helper loaded: url_helper
INFO - 2023-09-22 13:59:54 --> Helper loaded: file_helper
INFO - 2023-09-22 13:59:54 --> Helper loaded: form_helper
INFO - 2023-09-22 13:59:54 --> Helper loaded: my_helper
INFO - 2023-09-22 13:59:54 --> Database Driver Class Initialized
INFO - 2023-09-22 13:59:54 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-22 13:59:54 --> Controller Class Initialized
DEBUG - 2023-09-22 13:59:54 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/home/views/v_home_guru.php
DEBUG - 2023-09-22 13:59:54 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-09-22 13:59:54 --> Final output sent to browser
DEBUG - 2023-09-22 13:59:54 --> Total execution time: 0.0429
INFO - 2023-09-22 14:00:05 --> Config Class Initialized
INFO - 2023-09-22 14:00:05 --> Hooks Class Initialized
DEBUG - 2023-09-22 14:00:05 --> UTF-8 Support Enabled
INFO - 2023-09-22 14:00:05 --> Utf8 Class Initialized
INFO - 2023-09-22 14:00:05 --> URI Class Initialized
INFO - 2023-09-22 14:00:05 --> Router Class Initialized
INFO - 2023-09-22 14:00:05 --> Output Class Initialized
INFO - 2023-09-22 14:00:05 --> Security Class Initialized
DEBUG - 2023-09-22 14:00:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-22 14:00:05 --> Input Class Initialized
INFO - 2023-09-22 14:00:05 --> Language Class Initialized
INFO - 2023-09-22 14:00:05 --> Language Class Initialized
INFO - 2023-09-22 14:00:05 --> Config Class Initialized
INFO - 2023-09-22 14:00:05 --> Loader Class Initialized
INFO - 2023-09-22 14:00:05 --> Helper loaded: url_helper
INFO - 2023-09-22 14:00:05 --> Helper loaded: file_helper
INFO - 2023-09-22 14:00:05 --> Helper loaded: form_helper
INFO - 2023-09-22 14:00:05 --> Helper loaded: my_helper
INFO - 2023-09-22 14:00:05 --> Database Driver Class Initialized
INFO - 2023-09-22 14:00:05 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-22 14:00:05 --> Controller Class Initialized
DEBUG - 2023-09-22 14:00:05 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/view_mapel/views/v_view_mapel.php
DEBUG - 2023-09-22 14:00:05 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-09-22 14:00:05 --> Final output sent to browser
DEBUG - 2023-09-22 14:00:05 --> Total execution time: 0.0487
INFO - 2023-09-22 14:00:11 --> Config Class Initialized
INFO - 2023-09-22 14:00:11 --> Hooks Class Initialized
DEBUG - 2023-09-22 14:00:11 --> UTF-8 Support Enabled
INFO - 2023-09-22 14:00:11 --> Utf8 Class Initialized
INFO - 2023-09-22 14:00:11 --> URI Class Initialized
INFO - 2023-09-22 14:00:11 --> Router Class Initialized
INFO - 2023-09-22 14:00:11 --> Output Class Initialized
INFO - 2023-09-22 14:00:11 --> Security Class Initialized
DEBUG - 2023-09-22 14:00:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-22 14:00:11 --> Input Class Initialized
INFO - 2023-09-22 14:00:11 --> Language Class Initialized
INFO - 2023-09-22 14:00:11 --> Language Class Initialized
INFO - 2023-09-22 14:00:11 --> Config Class Initialized
INFO - 2023-09-22 14:00:11 --> Loader Class Initialized
INFO - 2023-09-22 14:00:11 --> Helper loaded: url_helper
INFO - 2023-09-22 14:00:11 --> Helper loaded: file_helper
INFO - 2023-09-22 14:00:11 --> Helper loaded: form_helper
INFO - 2023-09-22 14:00:11 --> Helper loaded: my_helper
INFO - 2023-09-22 14:00:11 --> Database Driver Class Initialized
INFO - 2023-09-22 14:00:11 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-22 14:00:11 --> Controller Class Initialized
DEBUG - 2023-09-22 14:00:11 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/views/list.php
DEBUG - 2023-09-22 14:00:11 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-09-22 14:00:11 --> Final output sent to browser
DEBUG - 2023-09-22 14:00:11 --> Total execution time: 0.0509
INFO - 2023-09-22 14:00:11 --> Config Class Initialized
INFO - 2023-09-22 14:00:11 --> Hooks Class Initialized
DEBUG - 2023-09-22 14:00:11 --> UTF-8 Support Enabled
INFO - 2023-09-22 14:00:11 --> Utf8 Class Initialized
INFO - 2023-09-22 14:00:11 --> URI Class Initialized
INFO - 2023-09-22 14:00:11 --> Router Class Initialized
INFO - 2023-09-22 14:00:11 --> Output Class Initialized
INFO - 2023-09-22 14:00:11 --> Security Class Initialized
DEBUG - 2023-09-22 14:00:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-22 14:00:11 --> Input Class Initialized
INFO - 2023-09-22 14:00:11 --> Language Class Initialized
INFO - 2023-09-22 14:00:11 --> Language Class Initialized
INFO - 2023-09-22 14:00:11 --> Config Class Initialized
INFO - 2023-09-22 14:00:11 --> Loader Class Initialized
INFO - 2023-09-22 14:00:11 --> Helper loaded: url_helper
INFO - 2023-09-22 14:00:11 --> Helper loaded: file_helper
INFO - 2023-09-22 14:00:11 --> Helper loaded: form_helper
INFO - 2023-09-22 14:00:11 --> Helper loaded: my_helper
INFO - 2023-09-22 14:00:11 --> Database Driver Class Initialized
INFO - 2023-09-22 14:00:11 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-22 14:00:11 --> Controller Class Initialized
INFO - 2023-09-22 14:00:19 --> Config Class Initialized
INFO - 2023-09-22 14:00:19 --> Hooks Class Initialized
DEBUG - 2023-09-22 14:00:19 --> UTF-8 Support Enabled
INFO - 2023-09-22 14:00:19 --> Utf8 Class Initialized
INFO - 2023-09-22 14:00:19 --> URI Class Initialized
INFO - 2023-09-22 14:00:19 --> Router Class Initialized
INFO - 2023-09-22 14:00:19 --> Output Class Initialized
INFO - 2023-09-22 14:00:19 --> Security Class Initialized
DEBUG - 2023-09-22 14:00:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-22 14:00:19 --> Input Class Initialized
INFO - 2023-09-22 14:00:19 --> Language Class Initialized
INFO - 2023-09-22 14:00:19 --> Language Class Initialized
INFO - 2023-09-22 14:00:19 --> Config Class Initialized
INFO - 2023-09-22 14:00:19 --> Loader Class Initialized
INFO - 2023-09-22 14:00:19 --> Helper loaded: url_helper
INFO - 2023-09-22 14:00:19 --> Helper loaded: file_helper
INFO - 2023-09-22 14:00:19 --> Helper loaded: form_helper
INFO - 2023-09-22 14:00:19 --> Helper loaded: my_helper
INFO - 2023-09-22 14:00:19 --> Database Driver Class Initialized
INFO - 2023-09-22 14:00:19 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-22 14:00:19 --> Controller Class Initialized
INFO - 2023-09-22 14:00:19 --> Final output sent to browser
DEBUG - 2023-09-22 14:00:19 --> Total execution time: 0.0492
INFO - 2023-09-22 14:00:27 --> Config Class Initialized
INFO - 2023-09-22 14:00:27 --> Hooks Class Initialized
DEBUG - 2023-09-22 14:00:27 --> UTF-8 Support Enabled
INFO - 2023-09-22 14:00:27 --> Utf8 Class Initialized
INFO - 2023-09-22 14:00:27 --> URI Class Initialized
INFO - 2023-09-22 14:00:27 --> Router Class Initialized
INFO - 2023-09-22 14:00:27 --> Output Class Initialized
INFO - 2023-09-22 14:00:27 --> Security Class Initialized
DEBUG - 2023-09-22 14:00:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-22 14:00:27 --> Input Class Initialized
INFO - 2023-09-22 14:00:27 --> Language Class Initialized
INFO - 2023-09-22 14:00:27 --> Language Class Initialized
INFO - 2023-09-22 14:00:27 --> Config Class Initialized
INFO - 2023-09-22 14:00:27 --> Loader Class Initialized
INFO - 2023-09-22 14:00:27 --> Helper loaded: url_helper
INFO - 2023-09-22 14:00:27 --> Helper loaded: file_helper
INFO - 2023-09-22 14:00:27 --> Helper loaded: form_helper
INFO - 2023-09-22 14:00:27 --> Helper loaded: my_helper
INFO - 2023-09-22 14:00:27 --> Database Driver Class Initialized
INFO - 2023-09-22 14:00:27 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-22 14:00:27 --> Controller Class Initialized
INFO - 2023-09-22 14:00:27 --> Final output sent to browser
DEBUG - 2023-09-22 14:00:27 --> Total execution time: 0.0352
INFO - 2023-09-22 14:00:41 --> Config Class Initialized
INFO - 2023-09-22 14:00:41 --> Hooks Class Initialized
DEBUG - 2023-09-22 14:00:42 --> UTF-8 Support Enabled
INFO - 2023-09-22 14:00:42 --> Utf8 Class Initialized
INFO - 2023-09-22 14:00:42 --> URI Class Initialized
INFO - 2023-09-22 14:00:42 --> Router Class Initialized
INFO - 2023-09-22 14:00:42 --> Output Class Initialized
INFO - 2023-09-22 14:00:42 --> Security Class Initialized
DEBUG - 2023-09-22 14:00:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-22 14:00:42 --> Input Class Initialized
INFO - 2023-09-22 14:00:42 --> Language Class Initialized
INFO - 2023-09-22 14:00:42 --> Language Class Initialized
INFO - 2023-09-22 14:00:42 --> Config Class Initialized
INFO - 2023-09-22 14:00:42 --> Loader Class Initialized
INFO - 2023-09-22 14:00:42 --> Helper loaded: url_helper
INFO - 2023-09-22 14:00:42 --> Helper loaded: file_helper
INFO - 2023-09-22 14:00:42 --> Helper loaded: form_helper
INFO - 2023-09-22 14:00:42 --> Helper loaded: my_helper
INFO - 2023-09-22 14:00:42 --> Database Driver Class Initialized
INFO - 2023-09-22 14:00:42 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-22 14:00:42 --> Controller Class Initialized
INFO - 2023-09-22 14:00:42 --> Final output sent to browser
DEBUG - 2023-09-22 14:00:42 --> Total execution time: 0.0388
INFO - 2023-09-22 14:00:55 --> Config Class Initialized
INFO - 2023-09-22 14:00:55 --> Hooks Class Initialized
DEBUG - 2023-09-22 14:00:55 --> UTF-8 Support Enabled
INFO - 2023-09-22 14:00:55 --> Utf8 Class Initialized
INFO - 2023-09-22 14:00:55 --> URI Class Initialized
INFO - 2023-09-22 14:00:55 --> Router Class Initialized
INFO - 2023-09-22 14:00:55 --> Output Class Initialized
INFO - 2023-09-22 14:00:55 --> Security Class Initialized
DEBUG - 2023-09-22 14:00:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-22 14:00:55 --> Input Class Initialized
INFO - 2023-09-22 14:00:55 --> Language Class Initialized
INFO - 2023-09-22 14:00:55 --> Language Class Initialized
INFO - 2023-09-22 14:00:55 --> Config Class Initialized
INFO - 2023-09-22 14:00:55 --> Loader Class Initialized
INFO - 2023-09-22 14:00:55 --> Helper loaded: url_helper
INFO - 2023-09-22 14:00:55 --> Helper loaded: file_helper
INFO - 2023-09-22 14:00:55 --> Helper loaded: form_helper
INFO - 2023-09-22 14:00:55 --> Helper loaded: my_helper
INFO - 2023-09-22 14:00:55 --> Database Driver Class Initialized
INFO - 2023-09-22 14:00:55 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-22 14:00:55 --> Controller Class Initialized
INFO - 2023-09-22 14:00:55 --> Final output sent to browser
DEBUG - 2023-09-22 14:00:55 --> Total execution time: 0.0403
INFO - 2023-09-22 14:01:02 --> Config Class Initialized
INFO - 2023-09-22 14:01:02 --> Hooks Class Initialized
DEBUG - 2023-09-22 14:01:02 --> UTF-8 Support Enabled
INFO - 2023-09-22 14:01:02 --> Utf8 Class Initialized
INFO - 2023-09-22 14:01:02 --> URI Class Initialized
INFO - 2023-09-22 14:01:02 --> Router Class Initialized
INFO - 2023-09-22 14:01:02 --> Output Class Initialized
INFO - 2023-09-22 14:01:02 --> Security Class Initialized
DEBUG - 2023-09-22 14:01:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-22 14:01:02 --> Input Class Initialized
INFO - 2023-09-22 14:01:02 --> Language Class Initialized
INFO - 2023-09-22 14:01:02 --> Language Class Initialized
INFO - 2023-09-22 14:01:02 --> Config Class Initialized
INFO - 2023-09-22 14:01:02 --> Loader Class Initialized
INFO - 2023-09-22 14:01:02 --> Helper loaded: url_helper
INFO - 2023-09-22 14:01:02 --> Helper loaded: file_helper
INFO - 2023-09-22 14:01:02 --> Helper loaded: form_helper
INFO - 2023-09-22 14:01:02 --> Helper loaded: my_helper
INFO - 2023-09-22 14:01:02 --> Database Driver Class Initialized
INFO - 2023-09-22 14:01:02 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-22 14:01:02 --> Controller Class Initialized
INFO - 2023-09-22 14:01:02 --> Final output sent to browser
DEBUG - 2023-09-22 14:01:02 --> Total execution time: 0.0407
INFO - 2023-09-22 14:01:08 --> Config Class Initialized
INFO - 2023-09-22 14:01:08 --> Hooks Class Initialized
DEBUG - 2023-09-22 14:01:08 --> UTF-8 Support Enabled
INFO - 2023-09-22 14:01:08 --> Utf8 Class Initialized
INFO - 2023-09-22 14:01:08 --> URI Class Initialized
INFO - 2023-09-22 14:01:08 --> Router Class Initialized
INFO - 2023-09-22 14:01:08 --> Output Class Initialized
INFO - 2023-09-22 14:01:08 --> Security Class Initialized
DEBUG - 2023-09-22 14:01:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-22 14:01:08 --> Input Class Initialized
INFO - 2023-09-22 14:01:08 --> Language Class Initialized
INFO - 2023-09-22 14:01:08 --> Language Class Initialized
INFO - 2023-09-22 14:01:08 --> Config Class Initialized
INFO - 2023-09-22 14:01:08 --> Loader Class Initialized
INFO - 2023-09-22 14:01:08 --> Helper loaded: url_helper
INFO - 2023-09-22 14:01:08 --> Helper loaded: file_helper
INFO - 2023-09-22 14:01:08 --> Helper loaded: form_helper
INFO - 2023-09-22 14:01:08 --> Helper loaded: my_helper
INFO - 2023-09-22 14:01:08 --> Database Driver Class Initialized
INFO - 2023-09-22 14:01:08 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-22 14:01:08 --> Controller Class Initialized
INFO - 2023-09-22 14:01:08 --> Final output sent to browser
DEBUG - 2023-09-22 14:01:08 --> Total execution time: 0.1026
INFO - 2023-09-22 14:01:10 --> Config Class Initialized
INFO - 2023-09-22 14:01:10 --> Hooks Class Initialized
DEBUG - 2023-09-22 14:01:10 --> UTF-8 Support Enabled
INFO - 2023-09-22 14:01:10 --> Utf8 Class Initialized
INFO - 2023-09-22 14:01:10 --> URI Class Initialized
INFO - 2023-09-22 14:01:10 --> Router Class Initialized
INFO - 2023-09-22 14:01:10 --> Output Class Initialized
INFO - 2023-09-22 14:01:10 --> Security Class Initialized
DEBUG - 2023-09-22 14:01:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-22 14:01:10 --> Input Class Initialized
INFO - 2023-09-22 14:01:10 --> Language Class Initialized
INFO - 2023-09-22 14:01:10 --> Language Class Initialized
INFO - 2023-09-22 14:01:10 --> Config Class Initialized
INFO - 2023-09-22 14:01:10 --> Loader Class Initialized
INFO - 2023-09-22 14:01:10 --> Helper loaded: url_helper
INFO - 2023-09-22 14:01:10 --> Helper loaded: file_helper
INFO - 2023-09-22 14:01:10 --> Helper loaded: form_helper
INFO - 2023-09-22 14:01:10 --> Helper loaded: my_helper
INFO - 2023-09-22 14:01:10 --> Database Driver Class Initialized
INFO - 2023-09-22 14:01:10 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-22 14:01:10 --> Controller Class Initialized
INFO - 2023-09-22 14:01:10 --> Final output sent to browser
DEBUG - 2023-09-22 14:01:10 --> Total execution time: 0.0388
INFO - 2023-09-22 14:01:12 --> Config Class Initialized
INFO - 2023-09-22 14:01:12 --> Hooks Class Initialized
DEBUG - 2023-09-22 14:01:12 --> UTF-8 Support Enabled
INFO - 2023-09-22 14:01:12 --> Utf8 Class Initialized
INFO - 2023-09-22 14:01:12 --> URI Class Initialized
INFO - 2023-09-22 14:01:12 --> Router Class Initialized
INFO - 2023-09-22 14:01:12 --> Output Class Initialized
INFO - 2023-09-22 14:01:12 --> Security Class Initialized
DEBUG - 2023-09-22 14:01:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-22 14:01:12 --> Input Class Initialized
INFO - 2023-09-22 14:01:12 --> Language Class Initialized
INFO - 2023-09-22 14:01:12 --> Language Class Initialized
INFO - 2023-09-22 14:01:12 --> Config Class Initialized
INFO - 2023-09-22 14:01:12 --> Loader Class Initialized
INFO - 2023-09-22 14:01:12 --> Helper loaded: url_helper
INFO - 2023-09-22 14:01:12 --> Helper loaded: file_helper
INFO - 2023-09-22 14:01:12 --> Helper loaded: form_helper
INFO - 2023-09-22 14:01:12 --> Helper loaded: my_helper
INFO - 2023-09-22 14:01:12 --> Database Driver Class Initialized
INFO - 2023-09-22 14:01:12 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-22 14:01:12 --> Controller Class Initialized
INFO - 2023-09-22 14:01:12 --> Final output sent to browser
DEBUG - 2023-09-22 14:01:12 --> Total execution time: 0.0428
INFO - 2023-09-22 14:04:49 --> Config Class Initialized
INFO - 2023-09-22 14:04:49 --> Hooks Class Initialized
DEBUG - 2023-09-22 14:04:49 --> UTF-8 Support Enabled
INFO - 2023-09-22 14:04:49 --> Utf8 Class Initialized
INFO - 2023-09-22 14:04:49 --> URI Class Initialized
INFO - 2023-09-22 14:04:49 --> Router Class Initialized
INFO - 2023-09-22 14:04:49 --> Output Class Initialized
INFO - 2023-09-22 14:04:49 --> Security Class Initialized
DEBUG - 2023-09-22 14:04:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-22 14:04:49 --> Input Class Initialized
INFO - 2023-09-22 14:04:49 --> Language Class Initialized
INFO - 2023-09-22 14:04:49 --> Language Class Initialized
INFO - 2023-09-22 14:04:49 --> Config Class Initialized
INFO - 2023-09-22 14:04:49 --> Loader Class Initialized
INFO - 2023-09-22 14:04:49 --> Helper loaded: url_helper
INFO - 2023-09-22 14:04:49 --> Helper loaded: file_helper
INFO - 2023-09-22 14:04:49 --> Helper loaded: form_helper
INFO - 2023-09-22 14:04:49 --> Helper loaded: my_helper
INFO - 2023-09-22 14:04:49 --> Database Driver Class Initialized
INFO - 2023-09-22 14:04:49 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-22 14:04:49 --> Controller Class Initialized
INFO - 2023-09-22 14:04:49 --> Final output sent to browser
DEBUG - 2023-09-22 14:04:49 --> Total execution time: 0.0376
INFO - 2023-09-22 14:05:17 --> Config Class Initialized
INFO - 2023-09-22 14:05:17 --> Hooks Class Initialized
DEBUG - 2023-09-22 14:05:17 --> UTF-8 Support Enabled
INFO - 2023-09-22 14:05:17 --> Utf8 Class Initialized
INFO - 2023-09-22 14:05:17 --> URI Class Initialized
INFO - 2023-09-22 14:05:17 --> Router Class Initialized
INFO - 2023-09-22 14:05:17 --> Output Class Initialized
INFO - 2023-09-22 14:05:17 --> Security Class Initialized
DEBUG - 2023-09-22 14:05:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-22 14:05:17 --> Input Class Initialized
INFO - 2023-09-22 14:05:17 --> Language Class Initialized
INFO - 2023-09-22 14:05:17 --> Language Class Initialized
INFO - 2023-09-22 14:05:17 --> Config Class Initialized
INFO - 2023-09-22 14:05:17 --> Loader Class Initialized
INFO - 2023-09-22 14:05:17 --> Helper loaded: url_helper
INFO - 2023-09-22 14:05:17 --> Helper loaded: file_helper
INFO - 2023-09-22 14:05:17 --> Helper loaded: form_helper
INFO - 2023-09-22 14:05:17 --> Helper loaded: my_helper
INFO - 2023-09-22 14:05:17 --> Database Driver Class Initialized
INFO - 2023-09-22 14:05:17 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-22 14:05:17 --> Controller Class Initialized
INFO - 2023-09-22 14:05:17 --> Final output sent to browser
DEBUG - 2023-09-22 14:05:17 --> Total execution time: 0.0920
INFO - 2023-09-22 14:05:17 --> Config Class Initialized
INFO - 2023-09-22 14:05:17 --> Hooks Class Initialized
DEBUG - 2023-09-22 14:05:17 --> UTF-8 Support Enabled
INFO - 2023-09-22 14:05:17 --> Utf8 Class Initialized
INFO - 2023-09-22 14:05:17 --> URI Class Initialized
INFO - 2023-09-22 14:05:17 --> Router Class Initialized
INFO - 2023-09-22 14:05:17 --> Output Class Initialized
INFO - 2023-09-22 14:05:17 --> Security Class Initialized
DEBUG - 2023-09-22 14:05:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-22 14:05:17 --> Input Class Initialized
INFO - 2023-09-22 14:05:17 --> Language Class Initialized
INFO - 2023-09-22 14:05:17 --> Language Class Initialized
INFO - 2023-09-22 14:05:17 --> Config Class Initialized
INFO - 2023-09-22 14:05:17 --> Loader Class Initialized
INFO - 2023-09-22 14:05:17 --> Helper loaded: url_helper
INFO - 2023-09-22 14:05:17 --> Helper loaded: file_helper
INFO - 2023-09-22 14:05:17 --> Helper loaded: form_helper
INFO - 2023-09-22 14:05:17 --> Helper loaded: my_helper
INFO - 2023-09-22 14:05:17 --> Database Driver Class Initialized
INFO - 2023-09-22 14:05:17 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-22 14:05:17 --> Controller Class Initialized
INFO - 2023-09-22 14:05:18 --> Config Class Initialized
INFO - 2023-09-22 14:05:18 --> Hooks Class Initialized
DEBUG - 2023-09-22 14:05:18 --> UTF-8 Support Enabled
INFO - 2023-09-22 14:05:18 --> Utf8 Class Initialized
INFO - 2023-09-22 14:05:18 --> URI Class Initialized
INFO - 2023-09-22 14:05:18 --> Router Class Initialized
INFO - 2023-09-22 14:05:18 --> Output Class Initialized
INFO - 2023-09-22 14:05:18 --> Security Class Initialized
DEBUG - 2023-09-22 14:05:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-22 14:05:18 --> Input Class Initialized
INFO - 2023-09-22 14:05:18 --> Language Class Initialized
INFO - 2023-09-22 14:05:18 --> Language Class Initialized
INFO - 2023-09-22 14:05:18 --> Config Class Initialized
INFO - 2023-09-22 14:05:18 --> Loader Class Initialized
INFO - 2023-09-22 14:05:18 --> Helper loaded: url_helper
INFO - 2023-09-22 14:05:18 --> Helper loaded: file_helper
INFO - 2023-09-22 14:05:18 --> Helper loaded: form_helper
INFO - 2023-09-22 14:05:18 --> Helper loaded: my_helper
INFO - 2023-09-22 14:05:18 --> Database Driver Class Initialized
INFO - 2023-09-22 14:05:18 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-22 14:05:18 --> Controller Class Initialized
INFO - 2023-09-22 14:05:18 --> Final output sent to browser
DEBUG - 2023-09-22 14:05:18 --> Total execution time: 0.0369
INFO - 2023-09-22 14:05:31 --> Config Class Initialized
INFO - 2023-09-22 14:05:31 --> Hooks Class Initialized
DEBUG - 2023-09-22 14:05:31 --> UTF-8 Support Enabled
INFO - 2023-09-22 14:05:31 --> Utf8 Class Initialized
INFO - 2023-09-22 14:05:31 --> URI Class Initialized
INFO - 2023-09-22 14:05:31 --> Router Class Initialized
INFO - 2023-09-22 14:05:31 --> Output Class Initialized
INFO - 2023-09-22 14:05:31 --> Security Class Initialized
DEBUG - 2023-09-22 14:05:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-22 14:05:31 --> Input Class Initialized
INFO - 2023-09-22 14:05:31 --> Language Class Initialized
INFO - 2023-09-22 14:05:31 --> Language Class Initialized
INFO - 2023-09-22 14:05:31 --> Config Class Initialized
INFO - 2023-09-22 14:05:31 --> Loader Class Initialized
INFO - 2023-09-22 14:05:31 --> Helper loaded: url_helper
INFO - 2023-09-22 14:05:31 --> Helper loaded: file_helper
INFO - 2023-09-22 14:05:31 --> Helper loaded: form_helper
INFO - 2023-09-22 14:05:31 --> Helper loaded: my_helper
INFO - 2023-09-22 14:05:31 --> Database Driver Class Initialized
INFO - 2023-09-22 14:05:31 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-22 14:05:31 --> Controller Class Initialized
INFO - 2023-09-22 14:05:31 --> Final output sent to browser
DEBUG - 2023-09-22 14:05:31 --> Total execution time: 0.0462
INFO - 2023-09-22 14:05:31 --> Config Class Initialized
INFO - 2023-09-22 14:05:31 --> Hooks Class Initialized
DEBUG - 2023-09-22 14:05:31 --> UTF-8 Support Enabled
INFO - 2023-09-22 14:05:31 --> Utf8 Class Initialized
INFO - 2023-09-22 14:05:31 --> URI Class Initialized
INFO - 2023-09-22 14:05:31 --> Router Class Initialized
INFO - 2023-09-22 14:05:31 --> Output Class Initialized
INFO - 2023-09-22 14:05:31 --> Security Class Initialized
DEBUG - 2023-09-22 14:05:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-22 14:05:31 --> Input Class Initialized
INFO - 2023-09-22 14:05:31 --> Language Class Initialized
INFO - 2023-09-22 14:05:31 --> Language Class Initialized
INFO - 2023-09-22 14:05:31 --> Config Class Initialized
INFO - 2023-09-22 14:05:31 --> Loader Class Initialized
INFO - 2023-09-22 14:05:31 --> Helper loaded: url_helper
INFO - 2023-09-22 14:05:31 --> Helper loaded: file_helper
INFO - 2023-09-22 14:05:31 --> Helper loaded: form_helper
INFO - 2023-09-22 14:05:31 --> Helper loaded: my_helper
INFO - 2023-09-22 14:05:31 --> Database Driver Class Initialized
INFO - 2023-09-22 14:05:31 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-22 14:05:31 --> Controller Class Initialized
INFO - 2023-09-22 14:05:31 --> Config Class Initialized
INFO - 2023-09-22 14:05:31 --> Hooks Class Initialized
DEBUG - 2023-09-22 14:05:31 --> UTF-8 Support Enabled
INFO - 2023-09-22 14:05:31 --> Utf8 Class Initialized
INFO - 2023-09-22 14:05:31 --> URI Class Initialized
INFO - 2023-09-22 14:05:31 --> Router Class Initialized
INFO - 2023-09-22 14:05:31 --> Output Class Initialized
INFO - 2023-09-22 14:05:31 --> Security Class Initialized
DEBUG - 2023-09-22 14:05:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-22 14:05:31 --> Input Class Initialized
INFO - 2023-09-22 14:05:31 --> Language Class Initialized
INFO - 2023-09-22 14:05:31 --> Language Class Initialized
INFO - 2023-09-22 14:05:31 --> Config Class Initialized
INFO - 2023-09-22 14:05:31 --> Loader Class Initialized
INFO - 2023-09-22 14:05:31 --> Helper loaded: url_helper
INFO - 2023-09-22 14:05:31 --> Helper loaded: file_helper
INFO - 2023-09-22 14:05:31 --> Helper loaded: form_helper
INFO - 2023-09-22 14:05:31 --> Helper loaded: my_helper
INFO - 2023-09-22 14:05:31 --> Database Driver Class Initialized
INFO - 2023-09-22 14:05:31 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-22 14:05:31 --> Controller Class Initialized
INFO - 2023-09-22 14:05:31 --> Final output sent to browser
DEBUG - 2023-09-22 14:05:31 --> Total execution time: 0.0383
INFO - 2023-09-22 14:05:45 --> Config Class Initialized
INFO - 2023-09-22 14:05:45 --> Hooks Class Initialized
DEBUG - 2023-09-22 14:05:45 --> UTF-8 Support Enabled
INFO - 2023-09-22 14:05:45 --> Utf8 Class Initialized
INFO - 2023-09-22 14:05:45 --> URI Class Initialized
INFO - 2023-09-22 14:05:45 --> Router Class Initialized
INFO - 2023-09-22 14:05:45 --> Output Class Initialized
INFO - 2023-09-22 14:05:45 --> Security Class Initialized
DEBUG - 2023-09-22 14:05:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-22 14:05:45 --> Input Class Initialized
INFO - 2023-09-22 14:05:45 --> Language Class Initialized
INFO - 2023-09-22 14:05:45 --> Language Class Initialized
INFO - 2023-09-22 14:05:45 --> Config Class Initialized
INFO - 2023-09-22 14:05:45 --> Loader Class Initialized
INFO - 2023-09-22 14:05:45 --> Helper loaded: url_helper
INFO - 2023-09-22 14:05:45 --> Helper loaded: file_helper
INFO - 2023-09-22 14:05:45 --> Helper loaded: form_helper
INFO - 2023-09-22 14:05:45 --> Helper loaded: my_helper
INFO - 2023-09-22 14:05:45 --> Database Driver Class Initialized
INFO - 2023-09-22 14:05:45 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-22 14:05:45 --> Controller Class Initialized
INFO - 2023-09-22 14:05:45 --> Final output sent to browser
DEBUG - 2023-09-22 14:05:45 --> Total execution time: 0.0540
INFO - 2023-09-22 14:05:45 --> Config Class Initialized
INFO - 2023-09-22 14:05:45 --> Hooks Class Initialized
DEBUG - 2023-09-22 14:05:45 --> UTF-8 Support Enabled
INFO - 2023-09-22 14:05:45 --> Utf8 Class Initialized
INFO - 2023-09-22 14:05:45 --> URI Class Initialized
INFO - 2023-09-22 14:05:45 --> Router Class Initialized
INFO - 2023-09-22 14:05:45 --> Output Class Initialized
INFO - 2023-09-22 14:05:45 --> Security Class Initialized
DEBUG - 2023-09-22 14:05:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-22 14:05:45 --> Input Class Initialized
INFO - 2023-09-22 14:05:45 --> Language Class Initialized
INFO - 2023-09-22 14:05:45 --> Language Class Initialized
INFO - 2023-09-22 14:05:45 --> Config Class Initialized
INFO - 2023-09-22 14:05:45 --> Loader Class Initialized
INFO - 2023-09-22 14:05:45 --> Helper loaded: url_helper
INFO - 2023-09-22 14:05:45 --> Helper loaded: file_helper
INFO - 2023-09-22 14:05:45 --> Helper loaded: form_helper
INFO - 2023-09-22 14:05:45 --> Helper loaded: my_helper
INFO - 2023-09-22 14:05:45 --> Database Driver Class Initialized
INFO - 2023-09-22 14:05:45 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-22 14:05:45 --> Controller Class Initialized
INFO - 2023-09-22 14:05:46 --> Config Class Initialized
INFO - 2023-09-22 14:05:46 --> Hooks Class Initialized
DEBUG - 2023-09-22 14:05:46 --> UTF-8 Support Enabled
INFO - 2023-09-22 14:05:46 --> Utf8 Class Initialized
INFO - 2023-09-22 14:05:46 --> URI Class Initialized
INFO - 2023-09-22 14:05:46 --> Router Class Initialized
INFO - 2023-09-22 14:05:46 --> Output Class Initialized
INFO - 2023-09-22 14:05:46 --> Security Class Initialized
DEBUG - 2023-09-22 14:05:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-22 14:05:46 --> Input Class Initialized
INFO - 2023-09-22 14:05:46 --> Language Class Initialized
INFO - 2023-09-22 14:05:46 --> Language Class Initialized
INFO - 2023-09-22 14:05:46 --> Config Class Initialized
INFO - 2023-09-22 14:05:46 --> Loader Class Initialized
INFO - 2023-09-22 14:05:46 --> Helper loaded: url_helper
INFO - 2023-09-22 14:05:46 --> Helper loaded: file_helper
INFO - 2023-09-22 14:05:46 --> Helper loaded: form_helper
INFO - 2023-09-22 14:05:46 --> Helper loaded: my_helper
INFO - 2023-09-22 14:05:46 --> Database Driver Class Initialized
INFO - 2023-09-22 14:05:46 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-22 14:05:46 --> Controller Class Initialized
INFO - 2023-09-22 14:05:46 --> Final output sent to browser
DEBUG - 2023-09-22 14:05:46 --> Total execution time: 0.0411
INFO - 2023-09-22 14:05:59 --> Config Class Initialized
INFO - 2023-09-22 14:05:59 --> Hooks Class Initialized
DEBUG - 2023-09-22 14:05:59 --> UTF-8 Support Enabled
INFO - 2023-09-22 14:05:59 --> Utf8 Class Initialized
INFO - 2023-09-22 14:05:59 --> URI Class Initialized
INFO - 2023-09-22 14:05:59 --> Router Class Initialized
INFO - 2023-09-22 14:05:59 --> Output Class Initialized
INFO - 2023-09-22 14:05:59 --> Security Class Initialized
DEBUG - 2023-09-22 14:05:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-22 14:05:59 --> Input Class Initialized
INFO - 2023-09-22 14:05:59 --> Language Class Initialized
INFO - 2023-09-22 14:05:59 --> Language Class Initialized
INFO - 2023-09-22 14:05:59 --> Config Class Initialized
INFO - 2023-09-22 14:05:59 --> Loader Class Initialized
INFO - 2023-09-22 14:05:59 --> Helper loaded: url_helper
INFO - 2023-09-22 14:05:59 --> Helper loaded: file_helper
INFO - 2023-09-22 14:05:59 --> Helper loaded: form_helper
INFO - 2023-09-22 14:05:59 --> Helper loaded: my_helper
INFO - 2023-09-22 14:05:59 --> Database Driver Class Initialized
INFO - 2023-09-22 14:05:59 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-22 14:05:59 --> Controller Class Initialized
INFO - 2023-09-22 14:05:59 --> Final output sent to browser
DEBUG - 2023-09-22 14:05:59 --> Total execution time: 0.0348
INFO - 2023-09-22 14:05:59 --> Config Class Initialized
INFO - 2023-09-22 14:05:59 --> Hooks Class Initialized
DEBUG - 2023-09-22 14:05:59 --> UTF-8 Support Enabled
INFO - 2023-09-22 14:05:59 --> Utf8 Class Initialized
INFO - 2023-09-22 14:05:59 --> URI Class Initialized
INFO - 2023-09-22 14:05:59 --> Router Class Initialized
INFO - 2023-09-22 14:05:59 --> Output Class Initialized
INFO - 2023-09-22 14:05:59 --> Security Class Initialized
DEBUG - 2023-09-22 14:05:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-22 14:05:59 --> Input Class Initialized
INFO - 2023-09-22 14:05:59 --> Language Class Initialized
INFO - 2023-09-22 14:05:59 --> Language Class Initialized
INFO - 2023-09-22 14:05:59 --> Config Class Initialized
INFO - 2023-09-22 14:05:59 --> Loader Class Initialized
INFO - 2023-09-22 14:05:59 --> Helper loaded: url_helper
INFO - 2023-09-22 14:05:59 --> Helper loaded: file_helper
INFO - 2023-09-22 14:05:59 --> Helper loaded: form_helper
INFO - 2023-09-22 14:05:59 --> Helper loaded: my_helper
INFO - 2023-09-22 14:05:59 --> Database Driver Class Initialized
INFO - 2023-09-22 14:05:59 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-22 14:05:59 --> Controller Class Initialized
INFO - 2023-09-22 14:06:02 --> Config Class Initialized
INFO - 2023-09-22 14:06:02 --> Hooks Class Initialized
DEBUG - 2023-09-22 14:06:02 --> UTF-8 Support Enabled
INFO - 2023-09-22 14:06:02 --> Utf8 Class Initialized
INFO - 2023-09-22 14:06:02 --> URI Class Initialized
INFO - 2023-09-22 14:06:02 --> Router Class Initialized
INFO - 2023-09-22 14:06:02 --> Output Class Initialized
INFO - 2023-09-22 14:06:02 --> Security Class Initialized
DEBUG - 2023-09-22 14:06:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-22 14:06:02 --> Input Class Initialized
INFO - 2023-09-22 14:06:02 --> Language Class Initialized
INFO - 2023-09-22 14:06:02 --> Language Class Initialized
INFO - 2023-09-22 14:06:02 --> Config Class Initialized
INFO - 2023-09-22 14:06:02 --> Loader Class Initialized
INFO - 2023-09-22 14:06:02 --> Helper loaded: url_helper
INFO - 2023-09-22 14:06:02 --> Helper loaded: file_helper
INFO - 2023-09-22 14:06:02 --> Helper loaded: form_helper
INFO - 2023-09-22 14:06:02 --> Helper loaded: my_helper
INFO - 2023-09-22 14:06:02 --> Database Driver Class Initialized
INFO - 2023-09-22 14:06:02 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-22 14:06:02 --> Controller Class Initialized
INFO - 2023-09-22 14:06:02 --> Final output sent to browser
DEBUG - 2023-09-22 14:06:02 --> Total execution time: 0.2464
INFO - 2023-09-22 14:06:17 --> Config Class Initialized
INFO - 2023-09-22 14:06:17 --> Hooks Class Initialized
DEBUG - 2023-09-22 14:06:17 --> UTF-8 Support Enabled
INFO - 2023-09-22 14:06:17 --> Utf8 Class Initialized
INFO - 2023-09-22 14:06:17 --> URI Class Initialized
INFO - 2023-09-22 14:06:17 --> Router Class Initialized
INFO - 2023-09-22 14:06:17 --> Output Class Initialized
INFO - 2023-09-22 14:06:17 --> Security Class Initialized
DEBUG - 2023-09-22 14:06:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-22 14:06:17 --> Input Class Initialized
INFO - 2023-09-22 14:06:17 --> Language Class Initialized
INFO - 2023-09-22 14:06:17 --> Language Class Initialized
INFO - 2023-09-22 14:06:17 --> Config Class Initialized
INFO - 2023-09-22 14:06:17 --> Loader Class Initialized
INFO - 2023-09-22 14:06:17 --> Helper loaded: url_helper
INFO - 2023-09-22 14:06:17 --> Helper loaded: file_helper
INFO - 2023-09-22 14:06:17 --> Helper loaded: form_helper
INFO - 2023-09-22 14:06:17 --> Helper loaded: my_helper
INFO - 2023-09-22 14:06:17 --> Database Driver Class Initialized
INFO - 2023-09-22 14:06:17 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-22 14:06:17 --> Controller Class Initialized
INFO - 2023-09-22 14:06:17 --> Final output sent to browser
DEBUG - 2023-09-22 14:06:17 --> Total execution time: 0.0369
INFO - 2023-09-22 14:06:17 --> Config Class Initialized
INFO - 2023-09-22 14:06:17 --> Hooks Class Initialized
DEBUG - 2023-09-22 14:06:17 --> UTF-8 Support Enabled
INFO - 2023-09-22 14:06:17 --> Utf8 Class Initialized
INFO - 2023-09-22 14:06:17 --> URI Class Initialized
INFO - 2023-09-22 14:06:17 --> Router Class Initialized
INFO - 2023-09-22 14:06:17 --> Output Class Initialized
INFO - 2023-09-22 14:06:17 --> Security Class Initialized
DEBUG - 2023-09-22 14:06:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-22 14:06:17 --> Input Class Initialized
INFO - 2023-09-22 14:06:17 --> Language Class Initialized
INFO - 2023-09-22 14:06:17 --> Language Class Initialized
INFO - 2023-09-22 14:06:17 --> Config Class Initialized
INFO - 2023-09-22 14:06:17 --> Loader Class Initialized
INFO - 2023-09-22 14:06:17 --> Helper loaded: url_helper
INFO - 2023-09-22 14:06:17 --> Helper loaded: file_helper
INFO - 2023-09-22 14:06:17 --> Helper loaded: form_helper
INFO - 2023-09-22 14:06:17 --> Helper loaded: my_helper
INFO - 2023-09-22 14:06:17 --> Database Driver Class Initialized
INFO - 2023-09-22 14:06:17 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-22 14:06:17 --> Controller Class Initialized
INFO - 2023-09-22 14:06:19 --> Config Class Initialized
INFO - 2023-09-22 14:06:19 --> Hooks Class Initialized
DEBUG - 2023-09-22 14:06:19 --> UTF-8 Support Enabled
INFO - 2023-09-22 14:06:19 --> Utf8 Class Initialized
INFO - 2023-09-22 14:06:19 --> URI Class Initialized
INFO - 2023-09-22 14:06:19 --> Router Class Initialized
INFO - 2023-09-22 14:06:19 --> Output Class Initialized
INFO - 2023-09-22 14:06:19 --> Security Class Initialized
DEBUG - 2023-09-22 14:06:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-22 14:06:19 --> Input Class Initialized
INFO - 2023-09-22 14:06:19 --> Language Class Initialized
INFO - 2023-09-22 14:06:19 --> Language Class Initialized
INFO - 2023-09-22 14:06:19 --> Config Class Initialized
INFO - 2023-09-22 14:06:19 --> Loader Class Initialized
INFO - 2023-09-22 14:06:19 --> Helper loaded: url_helper
INFO - 2023-09-22 14:06:19 --> Helper loaded: file_helper
INFO - 2023-09-22 14:06:19 --> Helper loaded: form_helper
INFO - 2023-09-22 14:06:19 --> Helper loaded: my_helper
INFO - 2023-09-22 14:06:19 --> Database Driver Class Initialized
INFO - 2023-09-22 14:06:19 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-22 14:06:19 --> Controller Class Initialized
INFO - 2023-09-22 14:06:19 --> Final output sent to browser
DEBUG - 2023-09-22 14:06:19 --> Total execution time: 0.0699
INFO - 2023-09-22 14:06:39 --> Config Class Initialized
INFO - 2023-09-22 14:06:39 --> Hooks Class Initialized
DEBUG - 2023-09-22 14:06:39 --> UTF-8 Support Enabled
INFO - 2023-09-22 14:06:39 --> Utf8 Class Initialized
INFO - 2023-09-22 14:06:39 --> URI Class Initialized
INFO - 2023-09-22 14:06:39 --> Router Class Initialized
INFO - 2023-09-22 14:06:39 --> Output Class Initialized
INFO - 2023-09-22 14:06:39 --> Security Class Initialized
DEBUG - 2023-09-22 14:06:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-22 14:06:39 --> Input Class Initialized
INFO - 2023-09-22 14:06:39 --> Language Class Initialized
INFO - 2023-09-22 14:06:39 --> Language Class Initialized
INFO - 2023-09-22 14:06:39 --> Config Class Initialized
INFO - 2023-09-22 14:06:39 --> Loader Class Initialized
INFO - 2023-09-22 14:06:39 --> Helper loaded: url_helper
INFO - 2023-09-22 14:06:39 --> Helper loaded: file_helper
INFO - 2023-09-22 14:06:39 --> Helper loaded: form_helper
INFO - 2023-09-22 14:06:39 --> Helper loaded: my_helper
INFO - 2023-09-22 14:06:39 --> Database Driver Class Initialized
INFO - 2023-09-22 14:06:39 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-22 14:06:39 --> Controller Class Initialized
INFO - 2023-09-22 14:06:39 --> Final output sent to browser
DEBUG - 2023-09-22 14:06:39 --> Total execution time: 0.0990
INFO - 2023-09-22 14:06:39 --> Config Class Initialized
INFO - 2023-09-22 14:06:39 --> Hooks Class Initialized
DEBUG - 2023-09-22 14:06:39 --> UTF-8 Support Enabled
INFO - 2023-09-22 14:06:39 --> Utf8 Class Initialized
INFO - 2023-09-22 14:06:39 --> URI Class Initialized
INFO - 2023-09-22 14:06:39 --> Router Class Initialized
INFO - 2023-09-22 14:06:39 --> Output Class Initialized
INFO - 2023-09-22 14:06:39 --> Security Class Initialized
DEBUG - 2023-09-22 14:06:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-22 14:06:39 --> Input Class Initialized
INFO - 2023-09-22 14:06:39 --> Language Class Initialized
INFO - 2023-09-22 14:06:39 --> Language Class Initialized
INFO - 2023-09-22 14:06:39 --> Config Class Initialized
INFO - 2023-09-22 14:06:39 --> Loader Class Initialized
INFO - 2023-09-22 14:06:39 --> Helper loaded: url_helper
INFO - 2023-09-22 14:06:39 --> Helper loaded: file_helper
INFO - 2023-09-22 14:06:39 --> Helper loaded: form_helper
INFO - 2023-09-22 14:06:39 --> Helper loaded: my_helper
INFO - 2023-09-22 14:06:39 --> Database Driver Class Initialized
INFO - 2023-09-22 14:06:39 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-22 14:06:39 --> Controller Class Initialized
INFO - 2023-09-22 14:06:40 --> Config Class Initialized
INFO - 2023-09-22 14:06:40 --> Hooks Class Initialized
DEBUG - 2023-09-22 14:06:40 --> UTF-8 Support Enabled
INFO - 2023-09-22 14:06:40 --> Utf8 Class Initialized
INFO - 2023-09-22 14:06:40 --> URI Class Initialized
INFO - 2023-09-22 14:06:40 --> Router Class Initialized
INFO - 2023-09-22 14:06:40 --> Output Class Initialized
INFO - 2023-09-22 14:06:40 --> Security Class Initialized
DEBUG - 2023-09-22 14:06:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-22 14:06:40 --> Input Class Initialized
INFO - 2023-09-22 14:06:40 --> Language Class Initialized
INFO - 2023-09-22 14:06:40 --> Language Class Initialized
INFO - 2023-09-22 14:06:40 --> Config Class Initialized
INFO - 2023-09-22 14:06:40 --> Loader Class Initialized
INFO - 2023-09-22 14:06:40 --> Helper loaded: url_helper
INFO - 2023-09-22 14:06:40 --> Helper loaded: file_helper
INFO - 2023-09-22 14:06:40 --> Helper loaded: form_helper
INFO - 2023-09-22 14:06:40 --> Helper loaded: my_helper
INFO - 2023-09-22 14:06:40 --> Database Driver Class Initialized
INFO - 2023-09-22 14:06:40 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-22 14:06:40 --> Controller Class Initialized
INFO - 2023-09-22 14:06:40 --> Final output sent to browser
DEBUG - 2023-09-22 14:06:40 --> Total execution time: 0.0518
INFO - 2023-09-22 14:06:52 --> Config Class Initialized
INFO - 2023-09-22 14:06:52 --> Hooks Class Initialized
DEBUG - 2023-09-22 14:06:52 --> UTF-8 Support Enabled
INFO - 2023-09-22 14:06:52 --> Utf8 Class Initialized
INFO - 2023-09-22 14:06:52 --> URI Class Initialized
INFO - 2023-09-22 14:06:52 --> Router Class Initialized
INFO - 2023-09-22 14:06:52 --> Output Class Initialized
INFO - 2023-09-22 14:06:52 --> Security Class Initialized
DEBUG - 2023-09-22 14:06:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-22 14:06:52 --> Input Class Initialized
INFO - 2023-09-22 14:06:52 --> Language Class Initialized
INFO - 2023-09-22 14:06:52 --> Language Class Initialized
INFO - 2023-09-22 14:06:52 --> Config Class Initialized
INFO - 2023-09-22 14:06:52 --> Loader Class Initialized
INFO - 2023-09-22 14:06:52 --> Helper loaded: url_helper
INFO - 2023-09-22 14:06:52 --> Helper loaded: file_helper
INFO - 2023-09-22 14:06:52 --> Helper loaded: form_helper
INFO - 2023-09-22 14:06:52 --> Helper loaded: my_helper
INFO - 2023-09-22 14:06:52 --> Database Driver Class Initialized
INFO - 2023-09-22 14:06:52 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-22 14:06:52 --> Controller Class Initialized
INFO - 2023-09-22 14:06:52 --> Final output sent to browser
DEBUG - 2023-09-22 14:06:52 --> Total execution time: 0.0329
INFO - 2023-09-22 14:06:52 --> Config Class Initialized
INFO - 2023-09-22 14:06:52 --> Hooks Class Initialized
DEBUG - 2023-09-22 14:06:52 --> UTF-8 Support Enabled
INFO - 2023-09-22 14:06:52 --> Utf8 Class Initialized
INFO - 2023-09-22 14:06:52 --> URI Class Initialized
INFO - 2023-09-22 14:06:52 --> Router Class Initialized
INFO - 2023-09-22 14:06:52 --> Output Class Initialized
INFO - 2023-09-22 14:06:52 --> Security Class Initialized
DEBUG - 2023-09-22 14:06:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-22 14:06:52 --> Input Class Initialized
INFO - 2023-09-22 14:06:52 --> Language Class Initialized
INFO - 2023-09-22 14:06:52 --> Language Class Initialized
INFO - 2023-09-22 14:06:52 --> Config Class Initialized
INFO - 2023-09-22 14:06:52 --> Loader Class Initialized
INFO - 2023-09-22 14:06:52 --> Helper loaded: url_helper
INFO - 2023-09-22 14:06:52 --> Helper loaded: file_helper
INFO - 2023-09-22 14:06:52 --> Helper loaded: form_helper
INFO - 2023-09-22 14:06:52 --> Helper loaded: my_helper
INFO - 2023-09-22 14:06:52 --> Database Driver Class Initialized
INFO - 2023-09-22 14:06:52 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-22 14:06:52 --> Controller Class Initialized
INFO - 2023-09-22 14:06:53 --> Config Class Initialized
INFO - 2023-09-22 14:06:53 --> Hooks Class Initialized
DEBUG - 2023-09-22 14:06:53 --> UTF-8 Support Enabled
INFO - 2023-09-22 14:06:53 --> Utf8 Class Initialized
INFO - 2023-09-22 14:06:53 --> URI Class Initialized
INFO - 2023-09-22 14:06:53 --> Router Class Initialized
INFO - 2023-09-22 14:06:53 --> Output Class Initialized
INFO - 2023-09-22 14:06:53 --> Security Class Initialized
DEBUG - 2023-09-22 14:06:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-22 14:06:53 --> Input Class Initialized
INFO - 2023-09-22 14:06:53 --> Language Class Initialized
INFO - 2023-09-22 14:06:53 --> Language Class Initialized
INFO - 2023-09-22 14:06:53 --> Config Class Initialized
INFO - 2023-09-22 14:06:53 --> Loader Class Initialized
INFO - 2023-09-22 14:06:53 --> Helper loaded: url_helper
INFO - 2023-09-22 14:06:53 --> Helper loaded: file_helper
INFO - 2023-09-22 14:06:53 --> Helper loaded: form_helper
INFO - 2023-09-22 14:06:53 --> Helper loaded: my_helper
INFO - 2023-09-22 14:06:53 --> Database Driver Class Initialized
INFO - 2023-09-22 14:06:53 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-22 14:06:53 --> Controller Class Initialized
INFO - 2023-09-22 14:06:53 --> Final output sent to browser
DEBUG - 2023-09-22 14:06:53 --> Total execution time: 0.0344
INFO - 2023-09-22 14:07:05 --> Config Class Initialized
INFO - 2023-09-22 14:07:05 --> Hooks Class Initialized
DEBUG - 2023-09-22 14:07:05 --> UTF-8 Support Enabled
INFO - 2023-09-22 14:07:05 --> Utf8 Class Initialized
INFO - 2023-09-22 14:07:05 --> URI Class Initialized
INFO - 2023-09-22 14:07:05 --> Router Class Initialized
INFO - 2023-09-22 14:07:05 --> Output Class Initialized
INFO - 2023-09-22 14:07:05 --> Security Class Initialized
DEBUG - 2023-09-22 14:07:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-22 14:07:05 --> Input Class Initialized
INFO - 2023-09-22 14:07:05 --> Language Class Initialized
INFO - 2023-09-22 14:07:05 --> Language Class Initialized
INFO - 2023-09-22 14:07:05 --> Config Class Initialized
INFO - 2023-09-22 14:07:05 --> Loader Class Initialized
INFO - 2023-09-22 14:07:05 --> Helper loaded: url_helper
INFO - 2023-09-22 14:07:05 --> Helper loaded: file_helper
INFO - 2023-09-22 14:07:05 --> Helper loaded: form_helper
INFO - 2023-09-22 14:07:05 --> Helper loaded: my_helper
INFO - 2023-09-22 14:07:05 --> Database Driver Class Initialized
INFO - 2023-09-22 14:07:05 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-22 14:07:05 --> Controller Class Initialized
INFO - 2023-09-22 14:07:05 --> Final output sent to browser
DEBUG - 2023-09-22 14:07:05 --> Total execution time: 0.1362
INFO - 2023-09-22 14:07:05 --> Config Class Initialized
INFO - 2023-09-22 14:07:05 --> Hooks Class Initialized
DEBUG - 2023-09-22 14:07:05 --> UTF-8 Support Enabled
INFO - 2023-09-22 14:07:05 --> Utf8 Class Initialized
INFO - 2023-09-22 14:07:05 --> URI Class Initialized
INFO - 2023-09-22 14:07:05 --> Router Class Initialized
INFO - 2023-09-22 14:07:05 --> Output Class Initialized
INFO - 2023-09-22 14:07:05 --> Security Class Initialized
DEBUG - 2023-09-22 14:07:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-22 14:07:05 --> Input Class Initialized
INFO - 2023-09-22 14:07:05 --> Language Class Initialized
INFO - 2023-09-22 14:07:05 --> Language Class Initialized
INFO - 2023-09-22 14:07:05 --> Config Class Initialized
INFO - 2023-09-22 14:07:05 --> Loader Class Initialized
INFO - 2023-09-22 14:07:05 --> Helper loaded: url_helper
INFO - 2023-09-22 14:07:05 --> Helper loaded: file_helper
INFO - 2023-09-22 14:07:05 --> Helper loaded: form_helper
INFO - 2023-09-22 14:07:05 --> Helper loaded: my_helper
INFO - 2023-09-22 14:07:05 --> Database Driver Class Initialized
INFO - 2023-09-22 14:07:05 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-22 14:07:05 --> Controller Class Initialized
INFO - 2023-09-22 14:07:06 --> Config Class Initialized
INFO - 2023-09-22 14:07:06 --> Hooks Class Initialized
DEBUG - 2023-09-22 14:07:06 --> UTF-8 Support Enabled
INFO - 2023-09-22 14:07:06 --> Utf8 Class Initialized
INFO - 2023-09-22 14:07:06 --> URI Class Initialized
INFO - 2023-09-22 14:07:06 --> Router Class Initialized
INFO - 2023-09-22 14:07:06 --> Output Class Initialized
INFO - 2023-09-22 14:07:06 --> Security Class Initialized
DEBUG - 2023-09-22 14:07:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-22 14:07:06 --> Input Class Initialized
INFO - 2023-09-22 14:07:06 --> Language Class Initialized
INFO - 2023-09-22 14:07:06 --> Language Class Initialized
INFO - 2023-09-22 14:07:06 --> Config Class Initialized
INFO - 2023-09-22 14:07:06 --> Loader Class Initialized
INFO - 2023-09-22 14:07:06 --> Helper loaded: url_helper
INFO - 2023-09-22 14:07:06 --> Helper loaded: file_helper
INFO - 2023-09-22 14:07:06 --> Helper loaded: form_helper
INFO - 2023-09-22 14:07:06 --> Helper loaded: my_helper
INFO - 2023-09-22 14:07:06 --> Database Driver Class Initialized
INFO - 2023-09-22 14:07:06 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-22 14:07:06 --> Controller Class Initialized
INFO - 2023-09-22 14:07:06 --> Final output sent to browser
DEBUG - 2023-09-22 14:07:06 --> Total execution time: 0.0485
INFO - 2023-09-22 14:07:17 --> Config Class Initialized
INFO - 2023-09-22 14:07:17 --> Hooks Class Initialized
DEBUG - 2023-09-22 14:07:17 --> UTF-8 Support Enabled
INFO - 2023-09-22 14:07:17 --> Utf8 Class Initialized
INFO - 2023-09-22 14:07:17 --> URI Class Initialized
INFO - 2023-09-22 14:07:17 --> Router Class Initialized
INFO - 2023-09-22 14:07:17 --> Output Class Initialized
INFO - 2023-09-22 14:07:17 --> Security Class Initialized
DEBUG - 2023-09-22 14:07:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-22 14:07:17 --> Input Class Initialized
INFO - 2023-09-22 14:07:17 --> Language Class Initialized
INFO - 2023-09-22 14:07:17 --> Language Class Initialized
INFO - 2023-09-22 14:07:17 --> Config Class Initialized
INFO - 2023-09-22 14:07:17 --> Loader Class Initialized
INFO - 2023-09-22 14:07:17 --> Helper loaded: url_helper
INFO - 2023-09-22 14:07:17 --> Helper loaded: file_helper
INFO - 2023-09-22 14:07:17 --> Helper loaded: form_helper
INFO - 2023-09-22 14:07:17 --> Helper loaded: my_helper
INFO - 2023-09-22 14:07:17 --> Database Driver Class Initialized
INFO - 2023-09-22 14:07:17 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-22 14:07:17 --> Controller Class Initialized
INFO - 2023-09-22 14:07:17 --> Final output sent to browser
DEBUG - 2023-09-22 14:07:17 --> Total execution time: 0.0425
INFO - 2023-09-22 14:07:17 --> Config Class Initialized
INFO - 2023-09-22 14:07:17 --> Hooks Class Initialized
DEBUG - 2023-09-22 14:07:17 --> UTF-8 Support Enabled
INFO - 2023-09-22 14:07:17 --> Utf8 Class Initialized
INFO - 2023-09-22 14:07:17 --> URI Class Initialized
INFO - 2023-09-22 14:07:17 --> Router Class Initialized
INFO - 2023-09-22 14:07:17 --> Output Class Initialized
INFO - 2023-09-22 14:07:17 --> Security Class Initialized
DEBUG - 2023-09-22 14:07:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-22 14:07:17 --> Input Class Initialized
INFO - 2023-09-22 14:07:17 --> Language Class Initialized
INFO - 2023-09-22 14:07:17 --> Language Class Initialized
INFO - 2023-09-22 14:07:17 --> Config Class Initialized
INFO - 2023-09-22 14:07:17 --> Loader Class Initialized
INFO - 2023-09-22 14:07:17 --> Helper loaded: url_helper
INFO - 2023-09-22 14:07:17 --> Helper loaded: file_helper
INFO - 2023-09-22 14:07:17 --> Helper loaded: form_helper
INFO - 2023-09-22 14:07:17 --> Helper loaded: my_helper
INFO - 2023-09-22 14:07:17 --> Database Driver Class Initialized
INFO - 2023-09-22 14:07:17 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-22 14:07:17 --> Controller Class Initialized
INFO - 2023-09-22 14:07:18 --> Config Class Initialized
INFO - 2023-09-22 14:07:18 --> Hooks Class Initialized
DEBUG - 2023-09-22 14:07:18 --> UTF-8 Support Enabled
INFO - 2023-09-22 14:07:18 --> Utf8 Class Initialized
INFO - 2023-09-22 14:07:18 --> URI Class Initialized
INFO - 2023-09-22 14:07:18 --> Router Class Initialized
INFO - 2023-09-22 14:07:18 --> Output Class Initialized
INFO - 2023-09-22 14:07:18 --> Security Class Initialized
DEBUG - 2023-09-22 14:07:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-22 14:07:18 --> Input Class Initialized
INFO - 2023-09-22 14:07:18 --> Language Class Initialized
INFO - 2023-09-22 14:07:18 --> Language Class Initialized
INFO - 2023-09-22 14:07:18 --> Config Class Initialized
INFO - 2023-09-22 14:07:18 --> Loader Class Initialized
INFO - 2023-09-22 14:07:18 --> Helper loaded: url_helper
INFO - 2023-09-22 14:07:18 --> Helper loaded: file_helper
INFO - 2023-09-22 14:07:18 --> Helper loaded: form_helper
INFO - 2023-09-22 14:07:18 --> Helper loaded: my_helper
INFO - 2023-09-22 14:07:18 --> Database Driver Class Initialized
INFO - 2023-09-22 14:07:18 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-22 14:07:18 --> Controller Class Initialized
INFO - 2023-09-22 14:07:18 --> Final output sent to browser
DEBUG - 2023-09-22 14:07:18 --> Total execution time: 0.0490
INFO - 2023-09-22 14:07:33 --> Config Class Initialized
INFO - 2023-09-22 14:07:33 --> Hooks Class Initialized
DEBUG - 2023-09-22 14:07:33 --> UTF-8 Support Enabled
INFO - 2023-09-22 14:07:33 --> Utf8 Class Initialized
INFO - 2023-09-22 14:07:33 --> URI Class Initialized
INFO - 2023-09-22 14:07:33 --> Router Class Initialized
INFO - 2023-09-22 14:07:33 --> Output Class Initialized
INFO - 2023-09-22 14:07:33 --> Security Class Initialized
DEBUG - 2023-09-22 14:07:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-22 14:07:33 --> Input Class Initialized
INFO - 2023-09-22 14:07:33 --> Language Class Initialized
INFO - 2023-09-22 14:07:33 --> Language Class Initialized
INFO - 2023-09-22 14:07:33 --> Config Class Initialized
INFO - 2023-09-22 14:07:33 --> Loader Class Initialized
INFO - 2023-09-22 14:07:33 --> Helper loaded: url_helper
INFO - 2023-09-22 14:07:33 --> Helper loaded: file_helper
INFO - 2023-09-22 14:07:33 --> Helper loaded: form_helper
INFO - 2023-09-22 14:07:33 --> Helper loaded: my_helper
INFO - 2023-09-22 14:07:33 --> Database Driver Class Initialized
INFO - 2023-09-22 14:07:33 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-22 14:07:33 --> Controller Class Initialized
INFO - 2023-09-22 14:07:33 --> Final output sent to browser
DEBUG - 2023-09-22 14:07:33 --> Total execution time: 0.0364
INFO - 2023-09-22 14:07:33 --> Config Class Initialized
INFO - 2023-09-22 14:07:33 --> Hooks Class Initialized
DEBUG - 2023-09-22 14:07:33 --> UTF-8 Support Enabled
INFO - 2023-09-22 14:07:33 --> Utf8 Class Initialized
INFO - 2023-09-22 14:07:33 --> URI Class Initialized
INFO - 2023-09-22 14:07:33 --> Router Class Initialized
INFO - 2023-09-22 14:07:33 --> Output Class Initialized
INFO - 2023-09-22 14:07:33 --> Security Class Initialized
DEBUG - 2023-09-22 14:07:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-22 14:07:33 --> Input Class Initialized
INFO - 2023-09-22 14:07:33 --> Language Class Initialized
INFO - 2023-09-22 14:07:33 --> Language Class Initialized
INFO - 2023-09-22 14:07:33 --> Config Class Initialized
INFO - 2023-09-22 14:07:33 --> Loader Class Initialized
INFO - 2023-09-22 14:07:33 --> Helper loaded: url_helper
INFO - 2023-09-22 14:07:33 --> Helper loaded: file_helper
INFO - 2023-09-22 14:07:33 --> Helper loaded: form_helper
INFO - 2023-09-22 14:07:33 --> Helper loaded: my_helper
INFO - 2023-09-22 14:07:33 --> Database Driver Class Initialized
INFO - 2023-09-22 14:07:33 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-22 14:07:33 --> Controller Class Initialized
INFO - 2023-09-22 14:07:38 --> Config Class Initialized
INFO - 2023-09-22 14:07:38 --> Hooks Class Initialized
DEBUG - 2023-09-22 14:07:38 --> UTF-8 Support Enabled
INFO - 2023-09-22 14:07:38 --> Utf8 Class Initialized
INFO - 2023-09-22 14:07:38 --> URI Class Initialized
INFO - 2023-09-22 14:07:38 --> Router Class Initialized
INFO - 2023-09-22 14:07:38 --> Output Class Initialized
INFO - 2023-09-22 14:07:38 --> Security Class Initialized
DEBUG - 2023-09-22 14:07:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-22 14:07:38 --> Input Class Initialized
INFO - 2023-09-22 14:07:38 --> Language Class Initialized
INFO - 2023-09-22 14:07:38 --> Language Class Initialized
INFO - 2023-09-22 14:07:38 --> Config Class Initialized
INFO - 2023-09-22 14:07:38 --> Loader Class Initialized
INFO - 2023-09-22 14:07:38 --> Helper loaded: url_helper
INFO - 2023-09-22 14:07:38 --> Helper loaded: file_helper
INFO - 2023-09-22 14:07:38 --> Helper loaded: form_helper
INFO - 2023-09-22 14:07:38 --> Helper loaded: my_helper
INFO - 2023-09-22 14:07:38 --> Database Driver Class Initialized
INFO - 2023-09-22 14:07:38 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-22 14:07:38 --> Controller Class Initialized
INFO - 2023-09-22 14:07:38 --> Final output sent to browser
DEBUG - 2023-09-22 14:07:38 --> Total execution time: 0.0774
INFO - 2023-09-22 14:07:49 --> Config Class Initialized
INFO - 2023-09-22 14:07:49 --> Hooks Class Initialized
DEBUG - 2023-09-22 14:07:49 --> UTF-8 Support Enabled
INFO - 2023-09-22 14:07:49 --> Utf8 Class Initialized
INFO - 2023-09-22 14:07:49 --> URI Class Initialized
INFO - 2023-09-22 14:07:49 --> Router Class Initialized
INFO - 2023-09-22 14:07:49 --> Output Class Initialized
INFO - 2023-09-22 14:07:49 --> Security Class Initialized
DEBUG - 2023-09-22 14:07:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-22 14:07:49 --> Input Class Initialized
INFO - 2023-09-22 14:07:49 --> Language Class Initialized
INFO - 2023-09-22 14:07:49 --> Language Class Initialized
INFO - 2023-09-22 14:07:49 --> Config Class Initialized
INFO - 2023-09-22 14:07:49 --> Loader Class Initialized
INFO - 2023-09-22 14:07:49 --> Helper loaded: url_helper
INFO - 2023-09-22 14:07:49 --> Helper loaded: file_helper
INFO - 2023-09-22 14:07:49 --> Helper loaded: form_helper
INFO - 2023-09-22 14:07:49 --> Helper loaded: my_helper
INFO - 2023-09-22 14:07:49 --> Database Driver Class Initialized
INFO - 2023-09-22 14:07:49 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-22 14:07:49 --> Controller Class Initialized
INFO - 2023-09-22 14:07:49 --> Final output sent to browser
DEBUG - 2023-09-22 14:07:49 --> Total execution time: 0.0439
INFO - 2023-09-22 14:07:49 --> Config Class Initialized
INFO - 2023-09-22 14:07:49 --> Hooks Class Initialized
DEBUG - 2023-09-22 14:07:49 --> UTF-8 Support Enabled
INFO - 2023-09-22 14:07:49 --> Utf8 Class Initialized
INFO - 2023-09-22 14:07:49 --> URI Class Initialized
INFO - 2023-09-22 14:07:49 --> Router Class Initialized
INFO - 2023-09-22 14:07:49 --> Output Class Initialized
INFO - 2023-09-22 14:07:49 --> Security Class Initialized
DEBUG - 2023-09-22 14:07:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-22 14:07:49 --> Input Class Initialized
INFO - 2023-09-22 14:07:49 --> Language Class Initialized
INFO - 2023-09-22 14:07:49 --> Language Class Initialized
INFO - 2023-09-22 14:07:49 --> Config Class Initialized
INFO - 2023-09-22 14:07:49 --> Loader Class Initialized
INFO - 2023-09-22 14:07:49 --> Helper loaded: url_helper
INFO - 2023-09-22 14:07:49 --> Helper loaded: file_helper
INFO - 2023-09-22 14:07:49 --> Helper loaded: form_helper
INFO - 2023-09-22 14:07:49 --> Helper loaded: my_helper
INFO - 2023-09-22 14:07:49 --> Database Driver Class Initialized
INFO - 2023-09-22 14:07:49 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-22 14:07:49 --> Controller Class Initialized
INFO - 2023-09-22 14:07:52 --> Config Class Initialized
INFO - 2023-09-22 14:07:52 --> Hooks Class Initialized
DEBUG - 2023-09-22 14:07:52 --> UTF-8 Support Enabled
INFO - 2023-09-22 14:07:52 --> Utf8 Class Initialized
INFO - 2023-09-22 14:07:52 --> URI Class Initialized
INFO - 2023-09-22 14:07:52 --> Router Class Initialized
INFO - 2023-09-22 14:07:52 --> Output Class Initialized
INFO - 2023-09-22 14:07:52 --> Security Class Initialized
DEBUG - 2023-09-22 14:07:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-22 14:07:52 --> Input Class Initialized
INFO - 2023-09-22 14:07:52 --> Language Class Initialized
INFO - 2023-09-22 14:07:52 --> Language Class Initialized
INFO - 2023-09-22 14:07:52 --> Config Class Initialized
INFO - 2023-09-22 14:07:52 --> Loader Class Initialized
INFO - 2023-09-22 14:07:52 --> Helper loaded: url_helper
INFO - 2023-09-22 14:07:52 --> Helper loaded: file_helper
INFO - 2023-09-22 14:07:52 --> Helper loaded: form_helper
INFO - 2023-09-22 14:07:52 --> Helper loaded: my_helper
INFO - 2023-09-22 14:07:52 --> Database Driver Class Initialized
INFO - 2023-09-22 14:07:52 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-22 14:07:52 --> Controller Class Initialized
INFO - 2023-09-22 14:07:52 --> Final output sent to browser
DEBUG - 2023-09-22 14:07:52 --> Total execution time: 0.0304
INFO - 2023-09-22 14:08:01 --> Config Class Initialized
INFO - 2023-09-22 14:08:01 --> Hooks Class Initialized
DEBUG - 2023-09-22 14:08:01 --> UTF-8 Support Enabled
INFO - 2023-09-22 14:08:01 --> Utf8 Class Initialized
INFO - 2023-09-22 14:08:01 --> URI Class Initialized
INFO - 2023-09-22 14:08:01 --> Router Class Initialized
INFO - 2023-09-22 14:08:01 --> Output Class Initialized
INFO - 2023-09-22 14:08:01 --> Security Class Initialized
DEBUG - 2023-09-22 14:08:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-22 14:08:01 --> Input Class Initialized
INFO - 2023-09-22 14:08:01 --> Language Class Initialized
INFO - 2023-09-22 14:08:01 --> Language Class Initialized
INFO - 2023-09-22 14:08:01 --> Config Class Initialized
INFO - 2023-09-22 14:08:01 --> Loader Class Initialized
INFO - 2023-09-22 14:08:01 --> Helper loaded: url_helper
INFO - 2023-09-22 14:08:01 --> Helper loaded: file_helper
INFO - 2023-09-22 14:08:01 --> Helper loaded: form_helper
INFO - 2023-09-22 14:08:01 --> Helper loaded: my_helper
INFO - 2023-09-22 14:08:01 --> Database Driver Class Initialized
INFO - 2023-09-22 14:08:01 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-22 14:08:01 --> Controller Class Initialized
INFO - 2023-09-22 14:08:01 --> Final output sent to browser
DEBUG - 2023-09-22 14:08:01 --> Total execution time: 0.0429
INFO - 2023-09-22 14:08:01 --> Config Class Initialized
INFO - 2023-09-22 14:08:01 --> Hooks Class Initialized
DEBUG - 2023-09-22 14:08:01 --> UTF-8 Support Enabled
INFO - 2023-09-22 14:08:01 --> Utf8 Class Initialized
INFO - 2023-09-22 14:08:01 --> URI Class Initialized
INFO - 2023-09-22 14:08:01 --> Router Class Initialized
INFO - 2023-09-22 14:08:01 --> Output Class Initialized
INFO - 2023-09-22 14:08:01 --> Security Class Initialized
DEBUG - 2023-09-22 14:08:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-22 14:08:01 --> Input Class Initialized
INFO - 2023-09-22 14:08:01 --> Language Class Initialized
INFO - 2023-09-22 14:08:01 --> Language Class Initialized
INFO - 2023-09-22 14:08:01 --> Config Class Initialized
INFO - 2023-09-22 14:08:01 --> Loader Class Initialized
INFO - 2023-09-22 14:08:01 --> Helper loaded: url_helper
INFO - 2023-09-22 14:08:01 --> Helper loaded: file_helper
INFO - 2023-09-22 14:08:01 --> Helper loaded: form_helper
INFO - 2023-09-22 14:08:01 --> Helper loaded: my_helper
INFO - 2023-09-22 14:08:01 --> Database Driver Class Initialized
INFO - 2023-09-22 14:08:01 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-22 14:08:01 --> Controller Class Initialized
INFO - 2023-09-22 14:08:02 --> Config Class Initialized
INFO - 2023-09-22 14:08:02 --> Hooks Class Initialized
DEBUG - 2023-09-22 14:08:02 --> UTF-8 Support Enabled
INFO - 2023-09-22 14:08:02 --> Utf8 Class Initialized
INFO - 2023-09-22 14:08:02 --> URI Class Initialized
INFO - 2023-09-22 14:08:02 --> Router Class Initialized
INFO - 2023-09-22 14:08:02 --> Output Class Initialized
INFO - 2023-09-22 14:08:02 --> Security Class Initialized
DEBUG - 2023-09-22 14:08:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-22 14:08:02 --> Input Class Initialized
INFO - 2023-09-22 14:08:02 --> Language Class Initialized
INFO - 2023-09-22 14:08:02 --> Language Class Initialized
INFO - 2023-09-22 14:08:02 --> Config Class Initialized
INFO - 2023-09-22 14:08:02 --> Loader Class Initialized
INFO - 2023-09-22 14:08:02 --> Helper loaded: url_helper
INFO - 2023-09-22 14:08:02 --> Helper loaded: file_helper
INFO - 2023-09-22 14:08:02 --> Helper loaded: form_helper
INFO - 2023-09-22 14:08:02 --> Helper loaded: my_helper
INFO - 2023-09-22 14:08:02 --> Database Driver Class Initialized
INFO - 2023-09-22 14:08:02 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-22 14:08:02 --> Controller Class Initialized
INFO - 2023-09-22 14:08:02 --> Final output sent to browser
DEBUG - 2023-09-22 14:08:02 --> Total execution time: 0.1269
INFO - 2023-09-22 14:11:39 --> Config Class Initialized
INFO - 2023-09-22 14:11:39 --> Hooks Class Initialized
DEBUG - 2023-09-22 14:11:39 --> UTF-8 Support Enabled
INFO - 2023-09-22 14:11:39 --> Utf8 Class Initialized
INFO - 2023-09-22 14:11:39 --> URI Class Initialized
INFO - 2023-09-22 14:11:39 --> Router Class Initialized
INFO - 2023-09-22 14:11:39 --> Config Class Initialized
INFO - 2023-09-22 14:11:39 --> Hooks Class Initialized
DEBUG - 2023-09-22 14:11:39 --> UTF-8 Support Enabled
INFO - 2023-09-22 14:11:39 --> Utf8 Class Initialized
INFO - 2023-09-22 14:11:39 --> URI Class Initialized
INFO - 2023-09-22 14:11:39 --> Router Class Initialized
INFO - 2023-09-22 14:11:39 --> Output Class Initialized
INFO - 2023-09-22 14:11:39 --> Security Class Initialized
DEBUG - 2023-09-22 14:11:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-22 14:11:39 --> Input Class Initialized
INFO - 2023-09-22 14:11:39 --> Language Class Initialized
INFO - 2023-09-22 14:11:39 --> Output Class Initialized
INFO - 2023-09-22 14:11:39 --> Security Class Initialized
DEBUG - 2023-09-22 14:11:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-22 14:11:39 --> Input Class Initialized
INFO - 2023-09-22 14:11:39 --> Language Class Initialized
INFO - 2023-09-22 14:11:39 --> Language Class Initialized
INFO - 2023-09-22 14:11:39 --> Config Class Initialized
INFO - 2023-09-22 14:11:39 --> Loader Class Initialized
INFO - 2023-09-22 14:11:39 --> Language Class Initialized
INFO - 2023-09-22 14:11:39 --> Config Class Initialized
INFO - 2023-09-22 14:11:39 --> Loader Class Initialized
INFO - 2023-09-22 14:11:39 --> Helper loaded: url_helper
INFO - 2023-09-22 14:11:39 --> Helper loaded: file_helper
INFO - 2023-09-22 14:11:40 --> Helper loaded: form_helper
INFO - 2023-09-22 14:11:40 --> Helper loaded: my_helper
INFO - 2023-09-22 14:11:40 --> Helper loaded: url_helper
INFO - 2023-09-22 14:11:40 --> Helper loaded: file_helper
INFO - 2023-09-22 14:11:40 --> Helper loaded: form_helper
INFO - 2023-09-22 14:11:40 --> Helper loaded: my_helper
INFO - 2023-09-22 14:11:40 --> Database Driver Class Initialized
INFO - 2023-09-22 14:11:40 --> Database Driver Class Initialized
INFO - 2023-09-22 14:11:40 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-22 14:11:40 --> Controller Class Initialized
INFO - 2023-09-22 14:11:40 --> Final output sent to browser
DEBUG - 2023-09-22 14:11:40 --> Total execution time: 0.2345
INFO - 2023-09-22 14:11:40 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-22 14:11:40 --> Controller Class Initialized
INFO - 2023-09-22 14:11:40 --> Final output sent to browser
DEBUG - 2023-09-22 14:11:40 --> Total execution time: 0.2406
INFO - 2023-09-22 14:11:40 --> Config Class Initialized
INFO - 2023-09-22 14:11:40 --> Hooks Class Initialized
DEBUG - 2023-09-22 14:11:40 --> UTF-8 Support Enabled
INFO - 2023-09-22 14:11:40 --> Utf8 Class Initialized
INFO - 2023-09-22 14:11:40 --> URI Class Initialized
INFO - 2023-09-22 14:11:40 --> Router Class Initialized
INFO - 2023-09-22 14:11:40 --> Output Class Initialized
INFO - 2023-09-22 14:11:40 --> Security Class Initialized
DEBUG - 2023-09-22 14:11:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-22 14:11:40 --> Input Class Initialized
INFO - 2023-09-22 14:11:40 --> Language Class Initialized
INFO - 2023-09-22 14:11:40 --> Language Class Initialized
INFO - 2023-09-22 14:11:40 --> Config Class Initialized
INFO - 2023-09-22 14:11:40 --> Loader Class Initialized
INFO - 2023-09-22 14:11:40 --> Helper loaded: url_helper
INFO - 2023-09-22 14:11:40 --> Helper loaded: file_helper
INFO - 2023-09-22 14:11:40 --> Helper loaded: form_helper
INFO - 2023-09-22 14:11:40 --> Helper loaded: my_helper
INFO - 2023-09-22 14:11:40 --> Database Driver Class Initialized
INFO - 2023-09-22 14:11:40 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-22 14:11:40 --> Controller Class Initialized
INFO - 2023-09-22 14:15:34 --> Config Class Initialized
INFO - 2023-09-22 14:15:34 --> Hooks Class Initialized
DEBUG - 2023-09-22 14:15:34 --> UTF-8 Support Enabled
INFO - 2023-09-22 14:15:34 --> Utf8 Class Initialized
INFO - 2023-09-22 14:15:34 --> URI Class Initialized
INFO - 2023-09-22 14:15:34 --> Router Class Initialized
INFO - 2023-09-22 14:15:34 --> Output Class Initialized
INFO - 2023-09-22 14:15:34 --> Security Class Initialized
DEBUG - 2023-09-22 14:15:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-22 14:15:34 --> Input Class Initialized
INFO - 2023-09-22 14:15:34 --> Language Class Initialized
INFO - 2023-09-22 14:15:34 --> Language Class Initialized
INFO - 2023-09-22 14:15:34 --> Config Class Initialized
INFO - 2023-09-22 14:15:34 --> Loader Class Initialized
INFO - 2023-09-22 14:15:34 --> Helper loaded: url_helper
INFO - 2023-09-22 14:15:34 --> Helper loaded: file_helper
INFO - 2023-09-22 14:15:34 --> Helper loaded: form_helper
INFO - 2023-09-22 14:15:34 --> Helper loaded: my_helper
INFO - 2023-09-22 14:15:34 --> Database Driver Class Initialized
INFO - 2023-09-22 14:15:34 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-22 14:15:34 --> Controller Class Initialized
INFO - 2023-09-22 14:15:34 --> Final output sent to browser
DEBUG - 2023-09-22 14:15:34 --> Total execution time: 0.0386
INFO - 2023-09-22 14:18:57 --> Config Class Initialized
INFO - 2023-09-22 14:18:57 --> Hooks Class Initialized
DEBUG - 2023-09-22 14:18:57 --> UTF-8 Support Enabled
INFO - 2023-09-22 14:18:57 --> Utf8 Class Initialized
INFO - 2023-09-22 14:18:57 --> URI Class Initialized
INFO - 2023-09-22 14:18:57 --> Router Class Initialized
INFO - 2023-09-22 14:18:57 --> Output Class Initialized
INFO - 2023-09-22 14:18:57 --> Security Class Initialized
DEBUG - 2023-09-22 14:18:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-22 14:18:57 --> Input Class Initialized
INFO - 2023-09-22 14:18:57 --> Language Class Initialized
INFO - 2023-09-22 14:18:57 --> Language Class Initialized
INFO - 2023-09-22 14:18:57 --> Config Class Initialized
INFO - 2023-09-22 14:18:57 --> Loader Class Initialized
INFO - 2023-09-22 14:18:57 --> Helper loaded: url_helper
INFO - 2023-09-22 14:18:57 --> Helper loaded: file_helper
INFO - 2023-09-22 14:18:57 --> Helper loaded: form_helper
INFO - 2023-09-22 14:18:57 --> Helper loaded: my_helper
INFO - 2023-09-22 14:18:57 --> Database Driver Class Initialized
INFO - 2023-09-22 14:18:57 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-22 14:18:57 --> Controller Class Initialized
INFO - 2023-09-22 14:18:57 --> Final output sent to browser
DEBUG - 2023-09-22 14:18:57 --> Total execution time: 0.0356
INFO - 2023-09-22 14:18:57 --> Config Class Initialized
INFO - 2023-09-22 14:18:57 --> Hooks Class Initialized
DEBUG - 2023-09-22 14:18:57 --> UTF-8 Support Enabled
INFO - 2023-09-22 14:18:57 --> Utf8 Class Initialized
INFO - 2023-09-22 14:18:57 --> URI Class Initialized
INFO - 2023-09-22 14:18:57 --> Router Class Initialized
INFO - 2023-09-22 14:18:57 --> Output Class Initialized
INFO - 2023-09-22 14:18:57 --> Security Class Initialized
DEBUG - 2023-09-22 14:18:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-22 14:18:57 --> Input Class Initialized
INFO - 2023-09-22 14:18:57 --> Language Class Initialized
INFO - 2023-09-22 14:18:57 --> Language Class Initialized
INFO - 2023-09-22 14:18:57 --> Config Class Initialized
INFO - 2023-09-22 14:18:57 --> Loader Class Initialized
INFO - 2023-09-22 14:18:57 --> Helper loaded: url_helper
INFO - 2023-09-22 14:18:57 --> Helper loaded: file_helper
INFO - 2023-09-22 14:18:57 --> Helper loaded: form_helper
INFO - 2023-09-22 14:18:57 --> Helper loaded: my_helper
INFO - 2023-09-22 14:18:57 --> Database Driver Class Initialized
INFO - 2023-09-22 14:18:57 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-22 14:18:57 --> Controller Class Initialized
INFO - 2023-09-22 14:19:02 --> Config Class Initialized
INFO - 2023-09-22 14:19:02 --> Hooks Class Initialized
DEBUG - 2023-09-22 14:19:02 --> UTF-8 Support Enabled
INFO - 2023-09-22 14:19:02 --> Utf8 Class Initialized
INFO - 2023-09-22 14:19:02 --> URI Class Initialized
INFO - 2023-09-22 14:19:02 --> Router Class Initialized
INFO - 2023-09-22 14:19:02 --> Output Class Initialized
INFO - 2023-09-22 14:19:02 --> Security Class Initialized
DEBUG - 2023-09-22 14:19:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-22 14:19:02 --> Input Class Initialized
INFO - 2023-09-22 14:19:02 --> Language Class Initialized
INFO - 2023-09-22 14:19:02 --> Language Class Initialized
INFO - 2023-09-22 14:19:02 --> Config Class Initialized
INFO - 2023-09-22 14:19:02 --> Loader Class Initialized
INFO - 2023-09-22 14:19:02 --> Helper loaded: url_helper
INFO - 2023-09-22 14:19:02 --> Helper loaded: file_helper
INFO - 2023-09-22 14:19:02 --> Helper loaded: form_helper
INFO - 2023-09-22 14:19:02 --> Helper loaded: my_helper
INFO - 2023-09-22 14:19:02 --> Database Driver Class Initialized
INFO - 2023-09-22 14:19:02 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-22 14:19:02 --> Controller Class Initialized
DEBUG - 2023-09-22 14:19:02 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/login/views/login.php
DEBUG - 2023-09-22 14:19:02 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-09-22 14:19:02 --> Final output sent to browser
DEBUG - 2023-09-22 14:19:02 --> Total execution time: 0.0364
INFO - 2023-09-22 14:19:06 --> Config Class Initialized
INFO - 2023-09-22 14:19:06 --> Hooks Class Initialized
DEBUG - 2023-09-22 14:19:06 --> UTF-8 Support Enabled
INFO - 2023-09-22 14:19:06 --> Utf8 Class Initialized
INFO - 2023-09-22 14:19:06 --> URI Class Initialized
INFO - 2023-09-22 14:19:06 --> Router Class Initialized
INFO - 2023-09-22 14:19:06 --> Output Class Initialized
INFO - 2023-09-22 14:19:06 --> Security Class Initialized
DEBUG - 2023-09-22 14:19:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-22 14:19:06 --> Input Class Initialized
INFO - 2023-09-22 14:19:06 --> Language Class Initialized
INFO - 2023-09-22 14:19:06 --> Language Class Initialized
INFO - 2023-09-22 14:19:06 --> Config Class Initialized
INFO - 2023-09-22 14:19:06 --> Loader Class Initialized
INFO - 2023-09-22 14:19:06 --> Helper loaded: url_helper
INFO - 2023-09-22 14:19:06 --> Helper loaded: file_helper
INFO - 2023-09-22 14:19:06 --> Helper loaded: form_helper
INFO - 2023-09-22 14:19:06 --> Helper loaded: my_helper
INFO - 2023-09-22 14:19:06 --> Database Driver Class Initialized
INFO - 2023-09-22 14:19:06 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-22 14:19:06 --> Controller Class Initialized
INFO - 2023-09-22 14:19:06 --> Helper loaded: cookie_helper
INFO - 2023-09-22 14:19:06 --> Final output sent to browser
DEBUG - 2023-09-22 14:19:06 --> Total execution time: 0.0552
INFO - 2023-09-22 14:19:06 --> Config Class Initialized
INFO - 2023-09-22 14:19:06 --> Hooks Class Initialized
DEBUG - 2023-09-22 14:19:06 --> UTF-8 Support Enabled
INFO - 2023-09-22 14:19:06 --> Utf8 Class Initialized
INFO - 2023-09-22 14:19:06 --> URI Class Initialized
INFO - 2023-09-22 14:19:06 --> Router Class Initialized
INFO - 2023-09-22 14:19:06 --> Output Class Initialized
INFO - 2023-09-22 14:19:06 --> Security Class Initialized
DEBUG - 2023-09-22 14:19:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-22 14:19:06 --> Input Class Initialized
INFO - 2023-09-22 14:19:06 --> Language Class Initialized
INFO - 2023-09-22 14:19:06 --> Language Class Initialized
INFO - 2023-09-22 14:19:06 --> Config Class Initialized
INFO - 2023-09-22 14:19:06 --> Loader Class Initialized
INFO - 2023-09-22 14:19:06 --> Helper loaded: url_helper
INFO - 2023-09-22 14:19:06 --> Helper loaded: file_helper
INFO - 2023-09-22 14:19:06 --> Helper loaded: form_helper
INFO - 2023-09-22 14:19:06 --> Helper loaded: my_helper
INFO - 2023-09-22 14:19:06 --> Database Driver Class Initialized
INFO - 2023-09-22 14:19:06 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-22 14:19:06 --> Controller Class Initialized
DEBUG - 2023-09-22 14:19:06 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/home/views/v_home_guru.php
DEBUG - 2023-09-22 14:19:06 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-09-22 14:19:06 --> Final output sent to browser
DEBUG - 2023-09-22 14:19:06 --> Total execution time: 0.1395
INFO - 2023-09-22 14:19:11 --> Config Class Initialized
INFO - 2023-09-22 14:19:11 --> Hooks Class Initialized
DEBUG - 2023-09-22 14:19:11 --> UTF-8 Support Enabled
INFO - 2023-09-22 14:19:11 --> Utf8 Class Initialized
INFO - 2023-09-22 14:19:11 --> URI Class Initialized
INFO - 2023-09-22 14:19:11 --> Router Class Initialized
INFO - 2023-09-22 14:19:11 --> Output Class Initialized
INFO - 2023-09-22 14:19:11 --> Security Class Initialized
DEBUG - 2023-09-22 14:19:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-22 14:19:11 --> Input Class Initialized
INFO - 2023-09-22 14:19:11 --> Language Class Initialized
INFO - 2023-09-22 14:19:11 --> Language Class Initialized
INFO - 2023-09-22 14:19:11 --> Config Class Initialized
INFO - 2023-09-22 14:19:11 --> Loader Class Initialized
INFO - 2023-09-22 14:19:11 --> Helper loaded: url_helper
INFO - 2023-09-22 14:19:11 --> Helper loaded: file_helper
INFO - 2023-09-22 14:19:11 --> Helper loaded: form_helper
INFO - 2023-09-22 14:19:11 --> Helper loaded: my_helper
INFO - 2023-09-22 14:19:12 --> Database Driver Class Initialized
INFO - 2023-09-22 14:19:12 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-22 14:19:12 --> Controller Class Initialized
DEBUG - 2023-09-22 14:19:12 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/view_mapel/views/v_view_mapel.php
DEBUG - 2023-09-22 14:19:12 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-09-22 14:19:12 --> Final output sent to browser
DEBUG - 2023-09-22 14:19:12 --> Total execution time: 0.0848
INFO - 2023-09-22 14:19:19 --> Config Class Initialized
INFO - 2023-09-22 14:19:19 --> Hooks Class Initialized
DEBUG - 2023-09-22 14:19:19 --> UTF-8 Support Enabled
INFO - 2023-09-22 14:19:19 --> Utf8 Class Initialized
INFO - 2023-09-22 14:19:19 --> URI Class Initialized
INFO - 2023-09-22 14:19:19 --> Router Class Initialized
INFO - 2023-09-22 14:19:19 --> Output Class Initialized
INFO - 2023-09-22 14:19:19 --> Security Class Initialized
DEBUG - 2023-09-22 14:19:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-22 14:19:19 --> Input Class Initialized
INFO - 2023-09-22 14:19:19 --> Language Class Initialized
INFO - 2023-09-22 14:19:19 --> Language Class Initialized
INFO - 2023-09-22 14:19:19 --> Config Class Initialized
INFO - 2023-09-22 14:19:19 --> Loader Class Initialized
INFO - 2023-09-22 14:19:19 --> Helper loaded: url_helper
INFO - 2023-09-22 14:19:19 --> Helper loaded: file_helper
INFO - 2023-09-22 14:19:19 --> Helper loaded: form_helper
INFO - 2023-09-22 14:19:19 --> Helper loaded: my_helper
INFO - 2023-09-22 14:19:19 --> Database Driver Class Initialized
INFO - 2023-09-22 14:19:19 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-22 14:19:19 --> Controller Class Initialized
DEBUG - 2023-09-22 14:19:19 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/views/list.php
DEBUG - 2023-09-22 14:19:19 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-09-22 14:19:19 --> Final output sent to browser
DEBUG - 2023-09-22 14:19:19 --> Total execution time: 0.0458
INFO - 2023-09-22 14:19:19 --> Config Class Initialized
INFO - 2023-09-22 14:19:19 --> Hooks Class Initialized
DEBUG - 2023-09-22 14:19:19 --> UTF-8 Support Enabled
INFO - 2023-09-22 14:19:19 --> Utf8 Class Initialized
INFO - 2023-09-22 14:19:19 --> URI Class Initialized
INFO - 2023-09-22 14:19:19 --> Router Class Initialized
INFO - 2023-09-22 14:19:19 --> Output Class Initialized
INFO - 2023-09-22 14:19:19 --> Security Class Initialized
DEBUG - 2023-09-22 14:19:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-22 14:19:19 --> Input Class Initialized
INFO - 2023-09-22 14:19:19 --> Language Class Initialized
INFO - 2023-09-22 14:19:19 --> Language Class Initialized
INFO - 2023-09-22 14:19:19 --> Config Class Initialized
INFO - 2023-09-22 14:19:19 --> Loader Class Initialized
INFO - 2023-09-22 14:19:19 --> Helper loaded: url_helper
INFO - 2023-09-22 14:19:19 --> Helper loaded: file_helper
INFO - 2023-09-22 14:19:19 --> Helper loaded: form_helper
INFO - 2023-09-22 14:19:19 --> Helper loaded: my_helper
INFO - 2023-09-22 14:19:19 --> Database Driver Class Initialized
INFO - 2023-09-22 14:19:19 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-22 14:19:19 --> Controller Class Initialized
INFO - 2023-09-22 14:19:34 --> Config Class Initialized
INFO - 2023-09-22 14:19:34 --> Hooks Class Initialized
DEBUG - 2023-09-22 14:19:34 --> UTF-8 Support Enabled
INFO - 2023-09-22 14:19:34 --> Utf8 Class Initialized
INFO - 2023-09-22 14:19:34 --> URI Class Initialized
INFO - 2023-09-22 14:19:34 --> Router Class Initialized
INFO - 2023-09-22 14:19:34 --> Output Class Initialized
INFO - 2023-09-22 14:19:34 --> Security Class Initialized
DEBUG - 2023-09-22 14:19:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-22 14:19:34 --> Input Class Initialized
INFO - 2023-09-22 14:19:34 --> Language Class Initialized
INFO - 2023-09-22 14:19:34 --> Language Class Initialized
INFO - 2023-09-22 14:19:34 --> Config Class Initialized
INFO - 2023-09-22 14:19:34 --> Loader Class Initialized
INFO - 2023-09-22 14:19:34 --> Helper loaded: url_helper
INFO - 2023-09-22 14:19:34 --> Helper loaded: file_helper
INFO - 2023-09-22 14:19:34 --> Helper loaded: form_helper
INFO - 2023-09-22 14:19:34 --> Helper loaded: my_helper
INFO - 2023-09-22 14:19:34 --> Database Driver Class Initialized
INFO - 2023-09-22 14:19:34 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-22 14:19:34 --> Controller Class Initialized
INFO - 2023-09-22 14:19:34 --> Final output sent to browser
DEBUG - 2023-09-22 14:19:34 --> Total execution time: 0.0464
INFO - 2023-09-22 14:19:43 --> Config Class Initialized
INFO - 2023-09-22 14:19:43 --> Hooks Class Initialized
DEBUG - 2023-09-22 14:19:43 --> UTF-8 Support Enabled
INFO - 2023-09-22 14:19:43 --> Utf8 Class Initialized
INFO - 2023-09-22 14:19:43 --> URI Class Initialized
INFO - 2023-09-22 14:19:43 --> Router Class Initialized
INFO - 2023-09-22 14:19:43 --> Output Class Initialized
INFO - 2023-09-22 14:19:43 --> Security Class Initialized
DEBUG - 2023-09-22 14:19:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-22 14:19:43 --> Input Class Initialized
INFO - 2023-09-22 14:19:43 --> Language Class Initialized
INFO - 2023-09-22 14:19:43 --> Language Class Initialized
INFO - 2023-09-22 14:19:43 --> Config Class Initialized
INFO - 2023-09-22 14:19:43 --> Loader Class Initialized
INFO - 2023-09-22 14:19:43 --> Helper loaded: url_helper
INFO - 2023-09-22 14:19:43 --> Helper loaded: file_helper
INFO - 2023-09-22 14:19:43 --> Helper loaded: form_helper
INFO - 2023-09-22 14:19:43 --> Helper loaded: my_helper
INFO - 2023-09-22 14:19:43 --> Database Driver Class Initialized
INFO - 2023-09-22 14:19:43 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-22 14:19:43 --> Controller Class Initialized
INFO - 2023-09-22 14:20:22 --> Config Class Initialized
INFO - 2023-09-22 14:20:22 --> Hooks Class Initialized
DEBUG - 2023-09-22 14:20:22 --> UTF-8 Support Enabled
INFO - 2023-09-22 14:20:22 --> Utf8 Class Initialized
INFO - 2023-09-22 14:20:22 --> URI Class Initialized
INFO - 2023-09-22 14:20:22 --> Router Class Initialized
INFO - 2023-09-22 14:20:22 --> Output Class Initialized
INFO - 2023-09-22 14:20:22 --> Security Class Initialized
DEBUG - 2023-09-22 14:20:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-22 14:20:22 --> Input Class Initialized
INFO - 2023-09-22 14:20:22 --> Language Class Initialized
INFO - 2023-09-22 14:20:22 --> Language Class Initialized
INFO - 2023-09-22 14:20:22 --> Config Class Initialized
INFO - 2023-09-22 14:20:22 --> Loader Class Initialized
INFO - 2023-09-22 14:20:22 --> Helper loaded: url_helper
INFO - 2023-09-22 14:20:22 --> Helper loaded: file_helper
INFO - 2023-09-22 14:20:22 --> Helper loaded: form_helper
INFO - 2023-09-22 14:20:22 --> Helper loaded: my_helper
INFO - 2023-09-22 14:20:22 --> Database Driver Class Initialized
INFO - 2023-09-22 14:20:22 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-22 14:20:22 --> Controller Class Initialized
INFO - 2023-09-22 14:20:22 --> Final output sent to browser
DEBUG - 2023-09-22 14:20:22 --> Total execution time: 0.0414
INFO - 2023-09-22 14:20:22 --> Config Class Initialized
INFO - 2023-09-22 14:20:22 --> Hooks Class Initialized
DEBUG - 2023-09-22 14:20:22 --> UTF-8 Support Enabled
INFO - 2023-09-22 14:20:22 --> Utf8 Class Initialized
INFO - 2023-09-22 14:20:22 --> URI Class Initialized
INFO - 2023-09-22 14:20:22 --> Router Class Initialized
INFO - 2023-09-22 14:20:22 --> Output Class Initialized
INFO - 2023-09-22 14:20:22 --> Security Class Initialized
DEBUG - 2023-09-22 14:20:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-22 14:20:22 --> Input Class Initialized
INFO - 2023-09-22 14:20:22 --> Language Class Initialized
INFO - 2023-09-22 14:20:22 --> Language Class Initialized
INFO - 2023-09-22 14:20:22 --> Config Class Initialized
INFO - 2023-09-22 14:20:22 --> Loader Class Initialized
INFO - 2023-09-22 14:20:22 --> Helper loaded: url_helper
INFO - 2023-09-22 14:20:22 --> Helper loaded: file_helper
INFO - 2023-09-22 14:20:22 --> Helper loaded: form_helper
INFO - 2023-09-22 14:20:22 --> Helper loaded: my_helper
INFO - 2023-09-22 14:20:22 --> Database Driver Class Initialized
INFO - 2023-09-22 14:20:22 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-22 14:20:22 --> Controller Class Initialized
INFO - 2023-09-22 14:21:13 --> Config Class Initialized
INFO - 2023-09-22 14:21:13 --> Hooks Class Initialized
DEBUG - 2023-09-22 14:21:13 --> UTF-8 Support Enabled
INFO - 2023-09-22 14:21:13 --> Utf8 Class Initialized
INFO - 2023-09-22 14:21:13 --> URI Class Initialized
INFO - 2023-09-22 14:21:13 --> Router Class Initialized
INFO - 2023-09-22 14:21:13 --> Output Class Initialized
INFO - 2023-09-22 14:21:13 --> Security Class Initialized
DEBUG - 2023-09-22 14:21:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-22 14:21:13 --> Input Class Initialized
INFO - 2023-09-22 14:21:13 --> Language Class Initialized
INFO - 2023-09-22 14:21:13 --> Language Class Initialized
INFO - 2023-09-22 14:21:13 --> Config Class Initialized
INFO - 2023-09-22 14:21:13 --> Loader Class Initialized
INFO - 2023-09-22 14:21:13 --> Helper loaded: url_helper
INFO - 2023-09-22 14:21:13 --> Helper loaded: file_helper
INFO - 2023-09-22 14:21:13 --> Helper loaded: form_helper
INFO - 2023-09-22 14:21:13 --> Helper loaded: my_helper
INFO - 2023-09-22 14:21:13 --> Database Driver Class Initialized
INFO - 2023-09-22 14:21:13 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-22 14:21:13 --> Controller Class Initialized
INFO - 2023-09-22 14:21:13 --> Final output sent to browser
DEBUG - 2023-09-22 14:21:13 --> Total execution time: 0.0891
INFO - 2023-09-22 14:21:13 --> Config Class Initialized
INFO - 2023-09-22 14:21:13 --> Hooks Class Initialized
DEBUG - 2023-09-22 14:21:14 --> UTF-8 Support Enabled
INFO - 2023-09-22 14:21:14 --> Utf8 Class Initialized
INFO - 2023-09-22 14:21:14 --> URI Class Initialized
INFO - 2023-09-22 14:21:14 --> Router Class Initialized
INFO - 2023-09-22 14:21:14 --> Output Class Initialized
INFO - 2023-09-22 14:21:14 --> Security Class Initialized
DEBUG - 2023-09-22 14:21:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-22 14:21:14 --> Input Class Initialized
INFO - 2023-09-22 14:21:14 --> Language Class Initialized
INFO - 2023-09-22 14:21:14 --> Language Class Initialized
INFO - 2023-09-22 14:21:14 --> Config Class Initialized
INFO - 2023-09-22 14:21:14 --> Loader Class Initialized
INFO - 2023-09-22 14:21:14 --> Helper loaded: url_helper
INFO - 2023-09-22 14:21:14 --> Helper loaded: file_helper
INFO - 2023-09-22 14:21:14 --> Helper loaded: form_helper
INFO - 2023-09-22 14:21:14 --> Helper loaded: my_helper
INFO - 2023-09-22 14:21:14 --> Database Driver Class Initialized
INFO - 2023-09-22 14:21:14 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-22 14:21:14 --> Controller Class Initialized
INFO - 2023-09-22 14:21:15 --> Config Class Initialized
INFO - 2023-09-22 14:21:15 --> Hooks Class Initialized
DEBUG - 2023-09-22 14:21:15 --> UTF-8 Support Enabled
INFO - 2023-09-22 14:21:15 --> Utf8 Class Initialized
INFO - 2023-09-22 14:21:15 --> URI Class Initialized
DEBUG - 2023-09-22 14:21:15 --> No URI present. Default controller set.
INFO - 2023-09-22 14:21:15 --> Router Class Initialized
INFO - 2023-09-22 14:21:15 --> Output Class Initialized
INFO - 2023-09-22 14:21:15 --> Security Class Initialized
DEBUG - 2023-09-22 14:21:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-22 14:21:15 --> Input Class Initialized
INFO - 2023-09-22 14:21:15 --> Language Class Initialized
INFO - 2023-09-22 14:21:15 --> Language Class Initialized
INFO - 2023-09-22 14:21:15 --> Config Class Initialized
INFO - 2023-09-22 14:21:15 --> Loader Class Initialized
INFO - 2023-09-22 14:21:15 --> Helper loaded: url_helper
INFO - 2023-09-22 14:21:15 --> Helper loaded: file_helper
INFO - 2023-09-22 14:21:15 --> Helper loaded: form_helper
INFO - 2023-09-22 14:21:15 --> Helper loaded: my_helper
INFO - 2023-09-22 14:21:15 --> Database Driver Class Initialized
INFO - 2023-09-22 14:21:15 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-22 14:21:15 --> Controller Class Initialized
DEBUG - 2023-09-22 14:21:15 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/home/views/v_home_guru.php
DEBUG - 2023-09-22 14:21:15 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-09-22 14:21:15 --> Final output sent to browser
DEBUG - 2023-09-22 14:21:15 --> Total execution time: 0.0600
INFO - 2023-09-22 14:21:21 --> Config Class Initialized
INFO - 2023-09-22 14:21:21 --> Hooks Class Initialized
DEBUG - 2023-09-22 14:21:21 --> UTF-8 Support Enabled
INFO - 2023-09-22 14:21:21 --> Utf8 Class Initialized
INFO - 2023-09-22 14:21:21 --> URI Class Initialized
INFO - 2023-09-22 14:21:21 --> Router Class Initialized
INFO - 2023-09-22 14:21:21 --> Output Class Initialized
INFO - 2023-09-22 14:21:21 --> Security Class Initialized
DEBUG - 2023-09-22 14:21:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-22 14:21:21 --> Input Class Initialized
INFO - 2023-09-22 14:21:21 --> Language Class Initialized
INFO - 2023-09-22 14:21:21 --> Language Class Initialized
INFO - 2023-09-22 14:21:21 --> Config Class Initialized
INFO - 2023-09-22 14:21:21 --> Loader Class Initialized
INFO - 2023-09-22 14:21:21 --> Helper loaded: url_helper
INFO - 2023-09-22 14:21:21 --> Helper loaded: file_helper
INFO - 2023-09-22 14:21:21 --> Helper loaded: form_helper
INFO - 2023-09-22 14:21:21 --> Helper loaded: my_helper
INFO - 2023-09-22 14:21:21 --> Database Driver Class Initialized
INFO - 2023-09-22 14:21:21 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-22 14:21:21 --> Controller Class Initialized
DEBUG - 2023-09-22 14:21:21 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/riwayat_mengajar/views/list.php
DEBUG - 2023-09-22 14:21:21 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-09-22 14:21:21 --> Final output sent to browser
DEBUG - 2023-09-22 14:21:21 --> Total execution time: 0.0753
INFO - 2023-09-22 14:21:23 --> Config Class Initialized
INFO - 2023-09-22 14:21:23 --> Hooks Class Initialized
DEBUG - 2023-09-22 14:21:23 --> UTF-8 Support Enabled
INFO - 2023-09-22 14:21:23 --> Utf8 Class Initialized
INFO - 2023-09-22 14:21:23 --> URI Class Initialized
INFO - 2023-09-22 14:21:23 --> Router Class Initialized
INFO - 2023-09-22 14:21:23 --> Output Class Initialized
INFO - 2023-09-22 14:21:23 --> Security Class Initialized
DEBUG - 2023-09-22 14:21:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-22 14:21:23 --> Input Class Initialized
INFO - 2023-09-22 14:21:23 --> Language Class Initialized
INFO - 2023-09-22 14:21:23 --> Language Class Initialized
INFO - 2023-09-22 14:21:23 --> Config Class Initialized
INFO - 2023-09-22 14:21:23 --> Loader Class Initialized
INFO - 2023-09-22 14:21:23 --> Helper loaded: url_helper
INFO - 2023-09-22 14:21:23 --> Helper loaded: file_helper
INFO - 2023-09-22 14:21:23 --> Helper loaded: form_helper
INFO - 2023-09-22 14:21:23 --> Helper loaded: my_helper
INFO - 2023-09-22 14:21:23 --> Database Driver Class Initialized
INFO - 2023-09-22 14:21:23 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-22 14:21:23 --> Controller Class Initialized
DEBUG - 2023-09-22 14:21:23 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/view_mapel/views/v_view_mapel.php
DEBUG - 2023-09-22 14:21:23 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-09-22 14:21:23 --> Final output sent to browser
DEBUG - 2023-09-22 14:21:23 --> Total execution time: 0.1067
INFO - 2023-09-22 14:21:24 --> Config Class Initialized
INFO - 2023-09-22 14:21:24 --> Hooks Class Initialized
DEBUG - 2023-09-22 14:21:24 --> UTF-8 Support Enabled
INFO - 2023-09-22 14:21:24 --> Utf8 Class Initialized
INFO - 2023-09-22 14:21:24 --> URI Class Initialized
DEBUG - 2023-09-22 14:21:24 --> No URI present. Default controller set.
INFO - 2023-09-22 14:21:24 --> Router Class Initialized
INFO - 2023-09-22 14:21:24 --> Output Class Initialized
INFO - 2023-09-22 14:21:24 --> Security Class Initialized
DEBUG - 2023-09-22 14:21:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-22 14:21:24 --> Input Class Initialized
INFO - 2023-09-22 14:21:24 --> Language Class Initialized
INFO - 2023-09-22 14:21:24 --> Language Class Initialized
INFO - 2023-09-22 14:21:24 --> Config Class Initialized
INFO - 2023-09-22 14:21:24 --> Loader Class Initialized
INFO - 2023-09-22 14:21:24 --> Helper loaded: url_helper
INFO - 2023-09-22 14:21:24 --> Helper loaded: file_helper
INFO - 2023-09-22 14:21:24 --> Helper loaded: form_helper
INFO - 2023-09-22 14:21:24 --> Helper loaded: my_helper
INFO - 2023-09-22 14:21:24 --> Database Driver Class Initialized
INFO - 2023-09-22 14:21:24 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-22 14:21:24 --> Controller Class Initialized
DEBUG - 2023-09-22 14:21:24 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/home/views/v_home_guru.php
DEBUG - 2023-09-22 14:21:24 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-09-22 14:21:24 --> Final output sent to browser
DEBUG - 2023-09-22 14:21:24 --> Total execution time: 0.1109
INFO - 2023-09-22 14:21:34 --> Config Class Initialized
INFO - 2023-09-22 14:21:34 --> Hooks Class Initialized
DEBUG - 2023-09-22 14:21:34 --> UTF-8 Support Enabled
INFO - 2023-09-22 14:21:34 --> Utf8 Class Initialized
INFO - 2023-09-22 14:21:34 --> URI Class Initialized
INFO - 2023-09-22 14:21:34 --> Router Class Initialized
INFO - 2023-09-22 14:21:34 --> Output Class Initialized
INFO - 2023-09-22 14:21:34 --> Security Class Initialized
DEBUG - 2023-09-22 14:21:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-22 14:21:34 --> Input Class Initialized
INFO - 2023-09-22 14:21:34 --> Language Class Initialized
INFO - 2023-09-22 14:21:34 --> Language Class Initialized
INFO - 2023-09-22 14:21:34 --> Config Class Initialized
INFO - 2023-09-22 14:21:34 --> Loader Class Initialized
INFO - 2023-09-22 14:21:34 --> Helper loaded: url_helper
INFO - 2023-09-22 14:21:34 --> Helper loaded: file_helper
INFO - 2023-09-22 14:21:34 --> Helper loaded: form_helper
INFO - 2023-09-22 14:21:34 --> Helper loaded: my_helper
INFO - 2023-09-22 14:21:34 --> Database Driver Class Initialized
INFO - 2023-09-22 14:21:34 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-22 14:21:34 --> Controller Class Initialized
DEBUG - 2023-09-22 14:21:34 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/view_mapel/views/v_view_mapel.php
DEBUG - 2023-09-22 14:21:34 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-09-22 14:21:34 --> Final output sent to browser
DEBUG - 2023-09-22 14:21:34 --> Total execution time: 0.0409
INFO - 2023-09-22 14:22:11 --> Config Class Initialized
INFO - 2023-09-22 14:22:11 --> Hooks Class Initialized
DEBUG - 2023-09-22 14:22:11 --> UTF-8 Support Enabled
INFO - 2023-09-22 14:22:11 --> Utf8 Class Initialized
INFO - 2023-09-22 14:22:11 --> URI Class Initialized
INFO - 2023-09-22 14:22:11 --> Router Class Initialized
INFO - 2023-09-22 14:22:11 --> Output Class Initialized
INFO - 2023-09-22 14:22:11 --> Security Class Initialized
DEBUG - 2023-09-22 14:22:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-22 14:22:11 --> Input Class Initialized
INFO - 2023-09-22 14:22:11 --> Language Class Initialized
INFO - 2023-09-22 14:22:11 --> Language Class Initialized
INFO - 2023-09-22 14:22:11 --> Config Class Initialized
INFO - 2023-09-22 14:22:11 --> Loader Class Initialized
INFO - 2023-09-22 14:22:11 --> Helper loaded: url_helper
INFO - 2023-09-22 14:22:11 --> Helper loaded: file_helper
INFO - 2023-09-22 14:22:11 --> Helper loaded: form_helper
INFO - 2023-09-22 14:22:11 --> Helper loaded: my_helper
INFO - 2023-09-22 14:22:11 --> Database Driver Class Initialized
INFO - 2023-09-22 14:22:11 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-22 14:22:11 --> Controller Class Initialized
INFO - 2023-09-22 14:22:11 --> Final output sent to browser
DEBUG - 2023-09-22 14:22:11 --> Total execution time: 0.0531
INFO - 2023-09-22 14:22:11 --> Config Class Initialized
INFO - 2023-09-22 14:22:11 --> Hooks Class Initialized
DEBUG - 2023-09-22 14:22:11 --> UTF-8 Support Enabled
INFO - 2023-09-22 14:22:11 --> Utf8 Class Initialized
INFO - 2023-09-22 14:22:11 --> URI Class Initialized
INFO - 2023-09-22 14:22:11 --> Router Class Initialized
INFO - 2023-09-22 14:22:11 --> Output Class Initialized
INFO - 2023-09-22 14:22:11 --> Security Class Initialized
DEBUG - 2023-09-22 14:22:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-22 14:22:11 --> Input Class Initialized
INFO - 2023-09-22 14:22:11 --> Language Class Initialized
INFO - 2023-09-22 14:22:11 --> Language Class Initialized
INFO - 2023-09-22 14:22:11 --> Config Class Initialized
INFO - 2023-09-22 14:22:11 --> Loader Class Initialized
INFO - 2023-09-22 14:22:11 --> Helper loaded: url_helper
INFO - 2023-09-22 14:22:11 --> Helper loaded: file_helper
INFO - 2023-09-22 14:22:11 --> Helper loaded: form_helper
INFO - 2023-09-22 14:22:11 --> Helper loaded: my_helper
INFO - 2023-09-22 14:22:11 --> Database Driver Class Initialized
INFO - 2023-09-22 14:22:11 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-22 14:22:11 --> Controller Class Initialized
INFO - 2023-09-22 14:22:15 --> Config Class Initialized
INFO - 2023-09-22 14:22:15 --> Hooks Class Initialized
DEBUG - 2023-09-22 14:22:15 --> UTF-8 Support Enabled
INFO - 2023-09-22 14:22:15 --> Utf8 Class Initialized
INFO - 2023-09-22 14:22:15 --> URI Class Initialized
INFO - 2023-09-22 14:22:15 --> Router Class Initialized
INFO - 2023-09-22 14:22:15 --> Output Class Initialized
INFO - 2023-09-22 14:22:15 --> Security Class Initialized
DEBUG - 2023-09-22 14:22:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-22 14:22:15 --> Input Class Initialized
INFO - 2023-09-22 14:22:15 --> Language Class Initialized
INFO - 2023-09-22 14:22:15 --> Language Class Initialized
INFO - 2023-09-22 14:22:15 --> Config Class Initialized
INFO - 2023-09-22 14:22:15 --> Loader Class Initialized
INFO - 2023-09-22 14:22:15 --> Helper loaded: url_helper
INFO - 2023-09-22 14:22:15 --> Helper loaded: file_helper
INFO - 2023-09-22 14:22:15 --> Helper loaded: form_helper
INFO - 2023-09-22 14:22:15 --> Helper loaded: my_helper
INFO - 2023-09-22 14:22:15 --> Database Driver Class Initialized
INFO - 2023-09-22 14:22:15 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-22 14:22:15 --> Controller Class Initialized
INFO - 2023-09-22 14:22:15 --> Final output sent to browser
DEBUG - 2023-09-22 14:22:15 --> Total execution time: 0.1129
INFO - 2023-09-22 14:22:15 --> Config Class Initialized
INFO - 2023-09-22 14:22:15 --> Hooks Class Initialized
DEBUG - 2023-09-22 14:22:15 --> UTF-8 Support Enabled
INFO - 2023-09-22 14:22:15 --> Utf8 Class Initialized
INFO - 2023-09-22 14:22:15 --> URI Class Initialized
INFO - 2023-09-22 14:22:15 --> Router Class Initialized
INFO - 2023-09-22 14:22:15 --> Output Class Initialized
INFO - 2023-09-22 14:22:15 --> Security Class Initialized
DEBUG - 2023-09-22 14:22:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-22 14:22:15 --> Input Class Initialized
INFO - 2023-09-22 14:22:15 --> Language Class Initialized
INFO - 2023-09-22 14:22:15 --> Language Class Initialized
INFO - 2023-09-22 14:22:15 --> Config Class Initialized
INFO - 2023-09-22 14:22:15 --> Loader Class Initialized
INFO - 2023-09-22 14:22:15 --> Helper loaded: url_helper
INFO - 2023-09-22 14:22:15 --> Helper loaded: file_helper
INFO - 2023-09-22 14:22:15 --> Helper loaded: form_helper
INFO - 2023-09-22 14:22:15 --> Helper loaded: my_helper
INFO - 2023-09-22 14:22:15 --> Database Driver Class Initialized
INFO - 2023-09-22 14:22:15 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-22 14:22:15 --> Controller Class Initialized
INFO - 2023-09-22 14:22:25 --> Config Class Initialized
INFO - 2023-09-22 14:22:25 --> Hooks Class Initialized
DEBUG - 2023-09-22 14:22:25 --> UTF-8 Support Enabled
INFO - 2023-09-22 14:22:25 --> Utf8 Class Initialized
INFO - 2023-09-22 14:22:25 --> URI Class Initialized
INFO - 2023-09-22 14:22:25 --> Router Class Initialized
INFO - 2023-09-22 14:22:25 --> Output Class Initialized
INFO - 2023-09-22 14:22:25 --> Security Class Initialized
DEBUG - 2023-09-22 14:22:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-22 14:22:25 --> Input Class Initialized
INFO - 2023-09-22 14:22:25 --> Language Class Initialized
INFO - 2023-09-22 14:22:25 --> Language Class Initialized
INFO - 2023-09-22 14:22:25 --> Config Class Initialized
INFO - 2023-09-22 14:22:25 --> Loader Class Initialized
INFO - 2023-09-22 14:22:25 --> Helper loaded: url_helper
INFO - 2023-09-22 14:22:25 --> Helper loaded: file_helper
INFO - 2023-09-22 14:22:25 --> Helper loaded: form_helper
INFO - 2023-09-22 14:22:25 --> Helper loaded: my_helper
INFO - 2023-09-22 14:22:25 --> Database Driver Class Initialized
INFO - 2023-09-22 14:22:25 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-22 14:22:25 --> Controller Class Initialized
INFO - 2023-09-22 14:22:25 --> Final output sent to browser
DEBUG - 2023-09-22 14:22:25 --> Total execution time: 0.0370
INFO - 2023-09-22 14:22:25 --> Config Class Initialized
INFO - 2023-09-22 14:22:25 --> Hooks Class Initialized
DEBUG - 2023-09-22 14:22:25 --> UTF-8 Support Enabled
INFO - 2023-09-22 14:22:25 --> Utf8 Class Initialized
INFO - 2023-09-22 14:22:25 --> URI Class Initialized
INFO - 2023-09-22 14:22:25 --> Router Class Initialized
INFO - 2023-09-22 14:22:25 --> Output Class Initialized
INFO - 2023-09-22 14:22:25 --> Security Class Initialized
DEBUG - 2023-09-22 14:22:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-22 14:22:25 --> Input Class Initialized
INFO - 2023-09-22 14:22:25 --> Language Class Initialized
INFO - 2023-09-22 14:22:25 --> Language Class Initialized
INFO - 2023-09-22 14:22:25 --> Config Class Initialized
INFO - 2023-09-22 14:22:25 --> Loader Class Initialized
INFO - 2023-09-22 14:22:25 --> Helper loaded: url_helper
INFO - 2023-09-22 14:22:25 --> Helper loaded: file_helper
INFO - 2023-09-22 14:22:25 --> Helper loaded: form_helper
INFO - 2023-09-22 14:22:25 --> Helper loaded: my_helper
INFO - 2023-09-22 14:22:25 --> Database Driver Class Initialized
INFO - 2023-09-22 14:22:25 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-22 14:22:25 --> Controller Class Initialized
INFO - 2023-09-22 14:22:33 --> Config Class Initialized
INFO - 2023-09-22 14:22:33 --> Hooks Class Initialized
DEBUG - 2023-09-22 14:22:33 --> UTF-8 Support Enabled
INFO - 2023-09-22 14:22:33 --> Utf8 Class Initialized
INFO - 2023-09-22 14:22:33 --> URI Class Initialized
INFO - 2023-09-22 14:22:33 --> Router Class Initialized
INFO - 2023-09-22 14:22:33 --> Output Class Initialized
INFO - 2023-09-22 14:22:33 --> Security Class Initialized
DEBUG - 2023-09-22 14:22:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-22 14:22:33 --> Input Class Initialized
INFO - 2023-09-22 14:22:33 --> Language Class Initialized
INFO - 2023-09-22 14:22:33 --> Language Class Initialized
INFO - 2023-09-22 14:22:33 --> Config Class Initialized
INFO - 2023-09-22 14:22:33 --> Loader Class Initialized
INFO - 2023-09-22 14:22:33 --> Helper loaded: url_helper
INFO - 2023-09-22 14:22:33 --> Helper loaded: file_helper
INFO - 2023-09-22 14:22:33 --> Helper loaded: form_helper
INFO - 2023-09-22 14:22:33 --> Helper loaded: my_helper
INFO - 2023-09-22 14:22:34 --> Database Driver Class Initialized
INFO - 2023-09-22 14:22:34 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-22 14:22:34 --> Controller Class Initialized
DEBUG - 2023-09-22 14:22:34 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/view_mapel/views/v_view_mapel.php
DEBUG - 2023-09-22 14:22:34 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-09-22 14:22:34 --> Final output sent to browser
DEBUG - 2023-09-22 14:22:34 --> Total execution time: 0.1488
INFO - 2023-09-22 14:22:37 --> Config Class Initialized
INFO - 2023-09-22 14:22:37 --> Hooks Class Initialized
DEBUG - 2023-09-22 14:22:37 --> UTF-8 Support Enabled
INFO - 2023-09-22 14:22:37 --> Utf8 Class Initialized
INFO - 2023-09-22 14:22:37 --> URI Class Initialized
INFO - 2023-09-22 14:22:37 --> Router Class Initialized
INFO - 2023-09-22 14:22:37 --> Output Class Initialized
INFO - 2023-09-22 14:22:37 --> Security Class Initialized
DEBUG - 2023-09-22 14:22:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-22 14:22:37 --> Input Class Initialized
INFO - 2023-09-22 14:22:37 --> Language Class Initialized
INFO - 2023-09-22 14:22:37 --> Language Class Initialized
INFO - 2023-09-22 14:22:37 --> Config Class Initialized
INFO - 2023-09-22 14:22:37 --> Loader Class Initialized
INFO - 2023-09-22 14:22:37 --> Helper loaded: url_helper
INFO - 2023-09-22 14:22:37 --> Helper loaded: file_helper
INFO - 2023-09-22 14:22:37 --> Helper loaded: form_helper
INFO - 2023-09-22 14:22:37 --> Helper loaded: my_helper
INFO - 2023-09-22 14:22:37 --> Database Driver Class Initialized
INFO - 2023-09-22 14:22:37 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-22 14:22:37 --> Controller Class Initialized
DEBUG - 2023-09-22 14:22:37 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/views/list.php
DEBUG - 2023-09-22 14:22:37 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-09-22 14:22:37 --> Final output sent to browser
DEBUG - 2023-09-22 14:22:37 --> Total execution time: 0.0410
INFO - 2023-09-22 14:22:37 --> Config Class Initialized
INFO - 2023-09-22 14:22:37 --> Hooks Class Initialized
DEBUG - 2023-09-22 14:22:37 --> UTF-8 Support Enabled
INFO - 2023-09-22 14:22:37 --> Utf8 Class Initialized
INFO - 2023-09-22 14:22:37 --> URI Class Initialized
INFO - 2023-09-22 14:22:37 --> Router Class Initialized
INFO - 2023-09-22 14:22:37 --> Output Class Initialized
INFO - 2023-09-22 14:22:37 --> Security Class Initialized
DEBUG - 2023-09-22 14:22:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-22 14:22:37 --> Input Class Initialized
INFO - 2023-09-22 14:22:37 --> Language Class Initialized
INFO - 2023-09-22 14:22:37 --> Language Class Initialized
INFO - 2023-09-22 14:22:37 --> Config Class Initialized
INFO - 2023-09-22 14:22:37 --> Loader Class Initialized
INFO - 2023-09-22 14:22:37 --> Helper loaded: url_helper
INFO - 2023-09-22 14:22:37 --> Helper loaded: file_helper
INFO - 2023-09-22 14:22:37 --> Helper loaded: form_helper
INFO - 2023-09-22 14:22:37 --> Helper loaded: my_helper
INFO - 2023-09-22 14:22:37 --> Database Driver Class Initialized
INFO - 2023-09-22 14:22:37 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-22 14:22:37 --> Controller Class Initialized
INFO - 2023-09-22 14:23:28 --> Config Class Initialized
INFO - 2023-09-22 14:23:28 --> Hooks Class Initialized
DEBUG - 2023-09-22 14:23:28 --> UTF-8 Support Enabled
INFO - 2023-09-22 14:23:28 --> Utf8 Class Initialized
INFO - 2023-09-22 14:23:28 --> URI Class Initialized
INFO - 2023-09-22 14:23:28 --> Router Class Initialized
INFO - 2023-09-22 14:23:28 --> Config Class Initialized
INFO - 2023-09-22 14:23:28 --> Hooks Class Initialized
DEBUG - 2023-09-22 14:23:28 --> UTF-8 Support Enabled
INFO - 2023-09-22 14:23:28 --> Utf8 Class Initialized
INFO - 2023-09-22 14:23:28 --> URI Class Initialized
INFO - 2023-09-22 14:23:28 --> Router Class Initialized
INFO - 2023-09-22 14:23:28 --> Output Class Initialized
INFO - 2023-09-22 14:23:28 --> Security Class Initialized
DEBUG - 2023-09-22 14:23:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-22 14:23:28 --> Input Class Initialized
INFO - 2023-09-22 14:23:28 --> Language Class Initialized
INFO - 2023-09-22 14:23:28 --> Language Class Initialized
INFO - 2023-09-22 14:23:28 --> Config Class Initialized
INFO - 2023-09-22 14:23:28 --> Loader Class Initialized
INFO - 2023-09-22 14:23:28 --> Output Class Initialized
INFO - 2023-09-22 14:23:28 --> Security Class Initialized
DEBUG - 2023-09-22 14:23:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-22 14:23:28 --> Input Class Initialized
INFO - 2023-09-22 14:23:28 --> Language Class Initialized
INFO - 2023-09-22 14:23:28 --> Language Class Initialized
INFO - 2023-09-22 14:23:28 --> Config Class Initialized
INFO - 2023-09-22 14:23:28 --> Loader Class Initialized
INFO - 2023-09-22 14:23:28 --> Helper loaded: url_helper
INFO - 2023-09-22 14:23:28 --> Helper loaded: file_helper
INFO - 2023-09-22 14:23:28 --> Helper loaded: form_helper
INFO - 2023-09-22 14:23:28 --> Helper loaded: my_helper
INFO - 2023-09-22 14:23:28 --> Database Driver Class Initialized
INFO - 2023-09-22 14:23:28 --> Helper loaded: url_helper
INFO - 2023-09-22 14:23:28 --> Helper loaded: file_helper
INFO - 2023-09-22 14:23:28 --> Helper loaded: form_helper
INFO - 2023-09-22 14:23:28 --> Helper loaded: my_helper
INFO - 2023-09-22 14:23:28 --> Database Driver Class Initialized
INFO - 2023-09-22 14:23:28 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-22 14:23:28 --> Controller Class Initialized
INFO - 2023-09-22 14:23:28 --> Final output sent to browser
DEBUG - 2023-09-22 14:23:28 --> Total execution time: 0.0798
INFO - 2023-09-22 14:23:28 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-22 14:23:28 --> Controller Class Initialized
INFO - 2023-09-22 14:23:28 --> Final output sent to browser
DEBUG - 2023-09-22 14:23:28 --> Total execution time: 0.0727
INFO - 2023-09-22 14:23:28 --> Config Class Initialized
INFO - 2023-09-22 14:23:28 --> Hooks Class Initialized
DEBUG - 2023-09-22 14:23:28 --> UTF-8 Support Enabled
INFO - 2023-09-22 14:23:28 --> Utf8 Class Initialized
INFO - 2023-09-22 14:23:28 --> URI Class Initialized
INFO - 2023-09-22 14:23:28 --> Router Class Initialized
INFO - 2023-09-22 14:23:28 --> Output Class Initialized
INFO - 2023-09-22 14:23:28 --> Security Class Initialized
DEBUG - 2023-09-22 14:23:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-22 14:23:28 --> Input Class Initialized
INFO - 2023-09-22 14:23:28 --> Language Class Initialized
INFO - 2023-09-22 14:23:28 --> Language Class Initialized
INFO - 2023-09-22 14:23:28 --> Config Class Initialized
INFO - 2023-09-22 14:23:28 --> Loader Class Initialized
INFO - 2023-09-22 14:23:28 --> Helper loaded: url_helper
INFO - 2023-09-22 14:23:28 --> Helper loaded: file_helper
INFO - 2023-09-22 14:23:28 --> Helper loaded: form_helper
INFO - 2023-09-22 14:23:28 --> Helper loaded: my_helper
INFO - 2023-09-22 14:23:28 --> Database Driver Class Initialized
INFO - 2023-09-22 14:23:28 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-22 14:23:28 --> Controller Class Initialized
INFO - 2023-09-22 14:23:28 --> Final output sent to browser
DEBUG - 2023-09-22 14:23:28 --> Total execution time: 0.0363
INFO - 2023-09-22 14:23:29 --> Config Class Initialized
INFO - 2023-09-22 14:23:29 --> Hooks Class Initialized
DEBUG - 2023-09-22 14:23:29 --> UTF-8 Support Enabled
INFO - 2023-09-22 14:23:29 --> Utf8 Class Initialized
INFO - 2023-09-22 14:23:29 --> URI Class Initialized
INFO - 2023-09-22 14:23:29 --> Router Class Initialized
INFO - 2023-09-22 14:23:29 --> Output Class Initialized
INFO - 2023-09-22 14:23:29 --> Security Class Initialized
DEBUG - 2023-09-22 14:23:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-22 14:23:29 --> Input Class Initialized
INFO - 2023-09-22 14:23:29 --> Language Class Initialized
INFO - 2023-09-22 14:23:29 --> Language Class Initialized
INFO - 2023-09-22 14:23:29 --> Config Class Initialized
INFO - 2023-09-22 14:23:29 --> Loader Class Initialized
INFO - 2023-09-22 14:23:29 --> Helper loaded: url_helper
INFO - 2023-09-22 14:23:29 --> Helper loaded: file_helper
INFO - 2023-09-22 14:23:29 --> Helper loaded: form_helper
INFO - 2023-09-22 14:23:29 --> Helper loaded: my_helper
INFO - 2023-09-22 14:23:29 --> Database Driver Class Initialized
INFO - 2023-09-22 14:23:29 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-22 14:23:29 --> Controller Class Initialized
INFO - 2023-09-22 14:23:29 --> Final output sent to browser
DEBUG - 2023-09-22 14:23:29 --> Total execution time: 0.0345
INFO - 2023-09-22 14:23:34 --> Config Class Initialized
INFO - 2023-09-22 14:23:34 --> Hooks Class Initialized
DEBUG - 2023-09-22 14:23:34 --> UTF-8 Support Enabled
INFO - 2023-09-22 14:23:34 --> Utf8 Class Initialized
INFO - 2023-09-22 14:23:34 --> URI Class Initialized
INFO - 2023-09-22 14:23:34 --> Router Class Initialized
INFO - 2023-09-22 14:23:34 --> Output Class Initialized
INFO - 2023-09-22 14:23:34 --> Security Class Initialized
DEBUG - 2023-09-22 14:23:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-22 14:23:34 --> Input Class Initialized
INFO - 2023-09-22 14:23:34 --> Language Class Initialized
INFO - 2023-09-22 14:23:34 --> Language Class Initialized
INFO - 2023-09-22 14:23:34 --> Config Class Initialized
INFO - 2023-09-22 14:23:34 --> Loader Class Initialized
INFO - 2023-09-22 14:23:34 --> Helper loaded: url_helper
INFO - 2023-09-22 14:23:34 --> Helper loaded: file_helper
INFO - 2023-09-22 14:23:34 --> Helper loaded: form_helper
INFO - 2023-09-22 14:23:34 --> Helper loaded: my_helper
INFO - 2023-09-22 14:23:34 --> Database Driver Class Initialized
INFO - 2023-09-22 14:23:34 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-22 14:23:34 --> Controller Class Initialized
INFO - 2023-09-22 14:23:34 --> Final output sent to browser
DEBUG - 2023-09-22 14:23:34 --> Total execution time: 0.0345
INFO - 2023-09-22 14:24:15 --> Config Class Initialized
INFO - 2023-09-22 14:24:15 --> Hooks Class Initialized
DEBUG - 2023-09-22 14:24:15 --> UTF-8 Support Enabled
INFO - 2023-09-22 14:24:15 --> Utf8 Class Initialized
INFO - 2023-09-22 14:24:15 --> URI Class Initialized
INFO - 2023-09-22 14:24:16 --> Router Class Initialized
INFO - 2023-09-22 14:24:16 --> Output Class Initialized
INFO - 2023-09-22 14:24:16 --> Security Class Initialized
DEBUG - 2023-09-22 14:24:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-22 14:24:16 --> Input Class Initialized
INFO - 2023-09-22 14:24:16 --> Language Class Initialized
INFO - 2023-09-22 14:24:16 --> Language Class Initialized
INFO - 2023-09-22 14:24:16 --> Config Class Initialized
INFO - 2023-09-22 14:24:16 --> Loader Class Initialized
INFO - 2023-09-22 14:24:16 --> Helper loaded: url_helper
INFO - 2023-09-22 14:24:16 --> Helper loaded: file_helper
INFO - 2023-09-22 14:24:16 --> Helper loaded: form_helper
INFO - 2023-09-22 14:24:16 --> Helper loaded: my_helper
INFO - 2023-09-22 14:24:16 --> Database Driver Class Initialized
INFO - 2023-09-22 14:24:16 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-22 14:24:16 --> Controller Class Initialized
ERROR - 2023-09-22 14:24:16 --> Severity: Notice --> Undefined offset: 26 /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/controllers/N_pengetahuan.php 393
ERROR - 2023-09-22 14:24:16 --> Severity: error --> Exception: Invalid cell coordinate 7 /www/wwwroot/report.mhis.link/bangka/secondary/application/third_party/PHP_Excel/PHPExcel/Cell.php 558
INFO - 2023-09-22 14:24:19 --> Config Class Initialized
INFO - 2023-09-22 14:24:19 --> Hooks Class Initialized
DEBUG - 2023-09-22 14:24:19 --> UTF-8 Support Enabled
INFO - 2023-09-22 14:24:19 --> Utf8 Class Initialized
INFO - 2023-09-22 14:24:19 --> URI Class Initialized
INFO - 2023-09-22 14:24:19 --> Router Class Initialized
INFO - 2023-09-22 14:24:19 --> Output Class Initialized
INFO - 2023-09-22 14:24:19 --> Security Class Initialized
DEBUG - 2023-09-22 14:24:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-22 14:24:19 --> Input Class Initialized
INFO - 2023-09-22 14:24:19 --> Language Class Initialized
INFO - 2023-09-22 14:24:19 --> Language Class Initialized
INFO - 2023-09-22 14:24:19 --> Config Class Initialized
INFO - 2023-09-22 14:24:19 --> Loader Class Initialized
INFO - 2023-09-22 14:24:19 --> Helper loaded: url_helper
INFO - 2023-09-22 14:24:19 --> Helper loaded: file_helper
INFO - 2023-09-22 14:24:19 --> Helper loaded: form_helper
INFO - 2023-09-22 14:24:19 --> Helper loaded: my_helper
INFO - 2023-09-22 14:24:19 --> Database Driver Class Initialized
INFO - 2023-09-22 14:24:19 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-22 14:24:19 --> Controller Class Initialized
DEBUG - 2023-09-22 14:24:19 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/views/list.php
DEBUG - 2023-09-22 14:24:19 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-09-22 14:24:19 --> Final output sent to browser
DEBUG - 2023-09-22 14:24:19 --> Total execution time: 0.0385
INFO - 2023-09-22 14:24:19 --> Config Class Initialized
INFO - 2023-09-22 14:24:19 --> Hooks Class Initialized
DEBUG - 2023-09-22 14:24:19 --> UTF-8 Support Enabled
INFO - 2023-09-22 14:24:19 --> Utf8 Class Initialized
INFO - 2023-09-22 14:24:19 --> URI Class Initialized
INFO - 2023-09-22 14:24:19 --> Router Class Initialized
INFO - 2023-09-22 14:24:19 --> Output Class Initialized
INFO - 2023-09-22 14:24:19 --> Security Class Initialized
DEBUG - 2023-09-22 14:24:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-22 14:24:19 --> Input Class Initialized
INFO - 2023-09-22 14:24:19 --> Language Class Initialized
INFO - 2023-09-22 14:24:19 --> Language Class Initialized
INFO - 2023-09-22 14:24:19 --> Config Class Initialized
INFO - 2023-09-22 14:24:19 --> Loader Class Initialized
INFO - 2023-09-22 14:24:19 --> Helper loaded: url_helper
INFO - 2023-09-22 14:24:19 --> Helper loaded: file_helper
INFO - 2023-09-22 14:24:19 --> Helper loaded: form_helper
INFO - 2023-09-22 14:24:19 --> Helper loaded: my_helper
INFO - 2023-09-22 14:24:19 --> Database Driver Class Initialized
INFO - 2023-09-22 14:24:19 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-22 14:24:19 --> Controller Class Initialized
INFO - 2023-09-22 14:24:31 --> Config Class Initialized
INFO - 2023-09-22 14:24:31 --> Hooks Class Initialized
DEBUG - 2023-09-22 14:24:31 --> UTF-8 Support Enabled
INFO - 2023-09-22 14:24:31 --> Utf8 Class Initialized
INFO - 2023-09-22 14:24:31 --> URI Class Initialized
INFO - 2023-09-22 14:24:31 --> Router Class Initialized
INFO - 2023-09-22 14:24:31 --> Output Class Initialized
INFO - 2023-09-22 14:24:31 --> Security Class Initialized
DEBUG - 2023-09-22 14:24:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-22 14:24:31 --> Input Class Initialized
INFO - 2023-09-22 14:24:31 --> Language Class Initialized
INFO - 2023-09-22 14:24:31 --> Language Class Initialized
INFO - 2023-09-22 14:24:31 --> Config Class Initialized
INFO - 2023-09-22 14:24:31 --> Loader Class Initialized
INFO - 2023-09-22 14:24:31 --> Helper loaded: url_helper
INFO - 2023-09-22 14:24:31 --> Helper loaded: file_helper
INFO - 2023-09-22 14:24:31 --> Helper loaded: form_helper
INFO - 2023-09-22 14:24:31 --> Helper loaded: my_helper
INFO - 2023-09-22 14:24:31 --> Database Driver Class Initialized
INFO - 2023-09-22 14:24:31 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-22 14:24:31 --> Controller Class Initialized
ERROR - 2023-09-22 14:24:31 --> Severity: Notice --> Undefined offset: 26 /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/controllers/N_pengetahuan.php 393
ERROR - 2023-09-22 14:24:31 --> Severity: error --> Exception: Invalid cell coordinate 7 /www/wwwroot/report.mhis.link/bangka/secondary/application/third_party/PHP_Excel/PHPExcel/Cell.php 558
INFO - 2023-09-22 14:24:35 --> Config Class Initialized
INFO - 2023-09-22 14:24:35 --> Hooks Class Initialized
DEBUG - 2023-09-22 14:24:35 --> UTF-8 Support Enabled
INFO - 2023-09-22 14:24:35 --> Utf8 Class Initialized
INFO - 2023-09-22 14:24:35 --> URI Class Initialized
INFO - 2023-09-22 14:24:35 --> Router Class Initialized
INFO - 2023-09-22 14:24:35 --> Output Class Initialized
INFO - 2023-09-22 14:24:35 --> Security Class Initialized
DEBUG - 2023-09-22 14:24:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-22 14:24:35 --> Input Class Initialized
INFO - 2023-09-22 14:24:35 --> Language Class Initialized
INFO - 2023-09-22 14:24:35 --> Language Class Initialized
INFO - 2023-09-22 14:24:35 --> Config Class Initialized
INFO - 2023-09-22 14:24:35 --> Loader Class Initialized
INFO - 2023-09-22 14:24:35 --> Helper loaded: url_helper
INFO - 2023-09-22 14:24:35 --> Helper loaded: file_helper
INFO - 2023-09-22 14:24:35 --> Helper loaded: form_helper
INFO - 2023-09-22 14:24:35 --> Helper loaded: my_helper
INFO - 2023-09-22 14:24:35 --> Database Driver Class Initialized
INFO - 2023-09-22 14:24:35 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-22 14:24:35 --> Controller Class Initialized
INFO - 2023-09-22 14:24:40 --> Config Class Initialized
INFO - 2023-09-22 14:24:40 --> Hooks Class Initialized
DEBUG - 2023-09-22 14:24:40 --> UTF-8 Support Enabled
INFO - 2023-09-22 14:24:40 --> Utf8 Class Initialized
INFO - 2023-09-22 14:24:40 --> URI Class Initialized
INFO - 2023-09-22 14:24:40 --> Router Class Initialized
INFO - 2023-09-22 14:24:40 --> Output Class Initialized
INFO - 2023-09-22 14:24:40 --> Security Class Initialized
DEBUG - 2023-09-22 14:24:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-22 14:24:40 --> Input Class Initialized
INFO - 2023-09-22 14:24:40 --> Language Class Initialized
INFO - 2023-09-22 14:24:41 --> Language Class Initialized
INFO - 2023-09-22 14:24:41 --> Config Class Initialized
INFO - 2023-09-22 14:24:41 --> Loader Class Initialized
INFO - 2023-09-22 14:24:41 --> Helper loaded: url_helper
INFO - 2023-09-22 14:24:41 --> Helper loaded: file_helper
INFO - 2023-09-22 14:24:41 --> Helper loaded: form_helper
INFO - 2023-09-22 14:24:41 --> Helper loaded: my_helper
INFO - 2023-09-22 14:24:41 --> Database Driver Class Initialized
INFO - 2023-09-22 14:24:41 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-22 14:24:41 --> Controller Class Initialized
DEBUG - 2023-09-22 14:24:41 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/views/list.php
DEBUG - 2023-09-22 14:24:41 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-09-22 14:24:41 --> Final output sent to browser
DEBUG - 2023-09-22 14:24:41 --> Total execution time: 0.1475
INFO - 2023-09-22 14:24:41 --> Config Class Initialized
INFO - 2023-09-22 14:24:41 --> Hooks Class Initialized
DEBUG - 2023-09-22 14:24:41 --> UTF-8 Support Enabled
INFO - 2023-09-22 14:24:41 --> Utf8 Class Initialized
INFO - 2023-09-22 14:24:41 --> URI Class Initialized
INFO - 2023-09-22 14:24:41 --> Router Class Initialized
INFO - 2023-09-22 14:24:41 --> Output Class Initialized
INFO - 2023-09-22 14:24:41 --> Security Class Initialized
DEBUG - 2023-09-22 14:24:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-22 14:24:41 --> Input Class Initialized
INFO - 2023-09-22 14:24:41 --> Language Class Initialized
INFO - 2023-09-22 14:24:41 --> Language Class Initialized
INFO - 2023-09-22 14:24:41 --> Config Class Initialized
INFO - 2023-09-22 14:24:41 --> Loader Class Initialized
INFO - 2023-09-22 14:24:41 --> Helper loaded: url_helper
INFO - 2023-09-22 14:24:41 --> Helper loaded: file_helper
INFO - 2023-09-22 14:24:41 --> Helper loaded: form_helper
INFO - 2023-09-22 14:24:41 --> Helper loaded: my_helper
INFO - 2023-09-22 14:24:41 --> Database Driver Class Initialized
INFO - 2023-09-22 14:24:41 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-22 14:24:41 --> Controller Class Initialized
INFO - 2023-09-22 14:24:55 --> Config Class Initialized
INFO - 2023-09-22 14:24:55 --> Hooks Class Initialized
DEBUG - 2023-09-22 14:24:55 --> UTF-8 Support Enabled
INFO - 2023-09-22 14:24:55 --> Utf8 Class Initialized
INFO - 2023-09-22 14:24:55 --> URI Class Initialized
INFO - 2023-09-22 14:24:55 --> Router Class Initialized
INFO - 2023-09-22 14:24:55 --> Output Class Initialized
INFO - 2023-09-22 14:24:55 --> Security Class Initialized
DEBUG - 2023-09-22 14:24:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-22 14:24:55 --> Input Class Initialized
INFO - 2023-09-22 14:24:55 --> Language Class Initialized
INFO - 2023-09-22 14:24:55 --> Language Class Initialized
INFO - 2023-09-22 14:24:55 --> Config Class Initialized
INFO - 2023-09-22 14:24:55 --> Loader Class Initialized
INFO - 2023-09-22 14:24:55 --> Helper loaded: url_helper
INFO - 2023-09-22 14:24:55 --> Helper loaded: file_helper
INFO - 2023-09-22 14:24:55 --> Helper loaded: form_helper
INFO - 2023-09-22 14:24:55 --> Helper loaded: my_helper
INFO - 2023-09-22 14:24:55 --> Database Driver Class Initialized
INFO - 2023-09-22 14:24:55 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-22 14:24:55 --> Controller Class Initialized
DEBUG - 2023-09-22 14:24:55 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/views/form.php
DEBUG - 2023-09-22 14:24:55 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-09-22 14:24:55 --> Final output sent to browser
DEBUG - 2023-09-22 14:24:55 --> Total execution time: 0.0353
INFO - 2023-09-22 14:24:59 --> Config Class Initialized
INFO - 2023-09-22 14:24:59 --> Hooks Class Initialized
DEBUG - 2023-09-22 14:24:59 --> UTF-8 Support Enabled
INFO - 2023-09-22 14:24:59 --> Utf8 Class Initialized
INFO - 2023-09-22 14:24:59 --> URI Class Initialized
INFO - 2023-09-22 14:24:59 --> Router Class Initialized
INFO - 2023-09-22 14:24:59 --> Output Class Initialized
INFO - 2023-09-22 14:24:59 --> Security Class Initialized
DEBUG - 2023-09-22 14:24:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-22 14:24:59 --> Input Class Initialized
INFO - 2023-09-22 14:24:59 --> Language Class Initialized
INFO - 2023-09-22 14:24:59 --> Language Class Initialized
INFO - 2023-09-22 14:24:59 --> Config Class Initialized
INFO - 2023-09-22 14:24:59 --> Loader Class Initialized
INFO - 2023-09-22 14:24:59 --> Helper loaded: url_helper
INFO - 2023-09-22 14:24:59 --> Helper loaded: file_helper
INFO - 2023-09-22 14:24:59 --> Helper loaded: form_helper
INFO - 2023-09-22 14:24:59 --> Helper loaded: my_helper
INFO - 2023-09-22 14:24:59 --> Database Driver Class Initialized
INFO - 2023-09-22 14:24:59 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-22 14:24:59 --> Controller Class Initialized
DEBUG - 2023-09-22 14:24:59 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/views/list.php
DEBUG - 2023-09-22 14:24:59 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-09-22 14:24:59 --> Final output sent to browser
DEBUG - 2023-09-22 14:24:59 --> Total execution time: 0.0453
INFO - 2023-09-22 14:24:59 --> Config Class Initialized
INFO - 2023-09-22 14:24:59 --> Hooks Class Initialized
DEBUG - 2023-09-22 14:24:59 --> UTF-8 Support Enabled
INFO - 2023-09-22 14:24:59 --> Utf8 Class Initialized
INFO - 2023-09-22 14:24:59 --> URI Class Initialized
INFO - 2023-09-22 14:24:59 --> Router Class Initialized
INFO - 2023-09-22 14:24:59 --> Output Class Initialized
INFO - 2023-09-22 14:24:59 --> Security Class Initialized
DEBUG - 2023-09-22 14:24:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-22 14:24:59 --> Input Class Initialized
INFO - 2023-09-22 14:24:59 --> Language Class Initialized
INFO - 2023-09-22 14:24:59 --> Language Class Initialized
INFO - 2023-09-22 14:24:59 --> Config Class Initialized
INFO - 2023-09-22 14:24:59 --> Loader Class Initialized
INFO - 2023-09-22 14:24:59 --> Helper loaded: url_helper
INFO - 2023-09-22 14:24:59 --> Helper loaded: file_helper
INFO - 2023-09-22 14:24:59 --> Helper loaded: form_helper
INFO - 2023-09-22 14:24:59 --> Helper loaded: my_helper
INFO - 2023-09-22 14:24:59 --> Database Driver Class Initialized
INFO - 2023-09-22 14:24:59 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-22 14:24:59 --> Controller Class Initialized
INFO - 2023-09-22 14:25:06 --> Config Class Initialized
INFO - 2023-09-22 14:25:06 --> Hooks Class Initialized
DEBUG - 2023-09-22 14:25:06 --> UTF-8 Support Enabled
INFO - 2023-09-22 14:25:06 --> Utf8 Class Initialized
INFO - 2023-09-22 14:25:06 --> URI Class Initialized
INFO - 2023-09-22 14:25:06 --> Router Class Initialized
INFO - 2023-09-22 14:25:06 --> Output Class Initialized
INFO - 2023-09-22 14:25:06 --> Security Class Initialized
DEBUG - 2023-09-22 14:25:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-22 14:25:06 --> Input Class Initialized
INFO - 2023-09-22 14:25:06 --> Language Class Initialized
INFO - 2023-09-22 14:25:06 --> Language Class Initialized
INFO - 2023-09-22 14:25:06 --> Config Class Initialized
INFO - 2023-09-22 14:25:06 --> Loader Class Initialized
INFO - 2023-09-22 14:25:06 --> Helper loaded: url_helper
INFO - 2023-09-22 14:25:06 --> Helper loaded: file_helper
INFO - 2023-09-22 14:25:06 --> Helper loaded: form_helper
INFO - 2023-09-22 14:25:06 --> Helper loaded: my_helper
INFO - 2023-09-22 14:25:06 --> Database Driver Class Initialized
INFO - 2023-09-22 14:25:06 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-22 14:25:06 --> Controller Class Initialized
ERROR - 2023-09-22 14:25:06 --> Severity: Notice --> Undefined offset: 26 /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/controllers/N_pengetahuan.php 393
ERROR - 2023-09-22 14:25:06 --> Severity: error --> Exception: Invalid cell coordinate 7 /www/wwwroot/report.mhis.link/bangka/secondary/application/third_party/PHP_Excel/PHPExcel/Cell.php 558
INFO - 2023-09-22 14:25:20 --> Config Class Initialized
INFO - 2023-09-22 14:25:20 --> Hooks Class Initialized
DEBUG - 2023-09-22 14:25:20 --> UTF-8 Support Enabled
INFO - 2023-09-22 14:25:20 --> Utf8 Class Initialized
INFO - 2023-09-22 14:25:20 --> URI Class Initialized
INFO - 2023-09-22 14:25:20 --> Router Class Initialized
INFO - 2023-09-22 14:25:20 --> Output Class Initialized
INFO - 2023-09-22 14:25:20 --> Security Class Initialized
DEBUG - 2023-09-22 14:25:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-22 14:25:20 --> Input Class Initialized
INFO - 2023-09-22 14:25:20 --> Language Class Initialized
INFO - 2023-09-22 14:25:20 --> Language Class Initialized
INFO - 2023-09-22 14:25:20 --> Config Class Initialized
INFO - 2023-09-22 14:25:20 --> Loader Class Initialized
INFO - 2023-09-22 14:25:20 --> Helper loaded: url_helper
INFO - 2023-09-22 14:25:20 --> Helper loaded: file_helper
INFO - 2023-09-22 14:25:20 --> Helper loaded: form_helper
INFO - 2023-09-22 14:25:20 --> Helper loaded: my_helper
INFO - 2023-09-22 14:25:20 --> Database Driver Class Initialized
INFO - 2023-09-22 14:25:20 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-22 14:25:20 --> Controller Class Initialized
DEBUG - 2023-09-22 14:25:20 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/views/list.php
DEBUG - 2023-09-22 14:25:20 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-09-22 14:25:20 --> Final output sent to browser
DEBUG - 2023-09-22 14:25:20 --> Total execution time: 0.0356
INFO - 2023-09-22 14:25:20 --> Config Class Initialized
INFO - 2023-09-22 14:25:20 --> Hooks Class Initialized
DEBUG - 2023-09-22 14:25:20 --> UTF-8 Support Enabled
INFO - 2023-09-22 14:25:20 --> Utf8 Class Initialized
INFO - 2023-09-22 14:25:20 --> URI Class Initialized
INFO - 2023-09-22 14:25:20 --> Router Class Initialized
INFO - 2023-09-22 14:25:20 --> Output Class Initialized
INFO - 2023-09-22 14:25:20 --> Security Class Initialized
DEBUG - 2023-09-22 14:25:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-22 14:25:20 --> Input Class Initialized
INFO - 2023-09-22 14:25:20 --> Language Class Initialized
INFO - 2023-09-22 14:25:20 --> Language Class Initialized
INFO - 2023-09-22 14:25:20 --> Config Class Initialized
INFO - 2023-09-22 14:25:20 --> Loader Class Initialized
INFO - 2023-09-22 14:25:20 --> Helper loaded: url_helper
INFO - 2023-09-22 14:25:20 --> Helper loaded: file_helper
INFO - 2023-09-22 14:25:20 --> Helper loaded: form_helper
INFO - 2023-09-22 14:25:20 --> Helper loaded: my_helper
INFO - 2023-09-22 14:25:20 --> Database Driver Class Initialized
INFO - 2023-09-22 14:25:20 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-22 14:25:20 --> Controller Class Initialized
INFO - 2023-09-22 14:25:46 --> Config Class Initialized
INFO - 2023-09-22 14:25:46 --> Hooks Class Initialized
DEBUG - 2023-09-22 14:25:46 --> UTF-8 Support Enabled
INFO - 2023-09-22 14:25:46 --> Utf8 Class Initialized
INFO - 2023-09-22 14:25:46 --> URI Class Initialized
INFO - 2023-09-22 14:25:46 --> Router Class Initialized
INFO - 2023-09-22 14:25:46 --> Output Class Initialized
INFO - 2023-09-22 14:25:46 --> Security Class Initialized
DEBUG - 2023-09-22 14:25:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-22 14:25:46 --> Input Class Initialized
INFO - 2023-09-22 14:25:46 --> Language Class Initialized
INFO - 2023-09-22 14:25:46 --> Language Class Initialized
INFO - 2023-09-22 14:25:46 --> Config Class Initialized
INFO - 2023-09-22 14:25:46 --> Loader Class Initialized
INFO - 2023-09-22 14:25:46 --> Helper loaded: url_helper
INFO - 2023-09-22 14:25:46 --> Helper loaded: file_helper
INFO - 2023-09-22 14:25:46 --> Helper loaded: form_helper
INFO - 2023-09-22 14:25:46 --> Helper loaded: my_helper
INFO - 2023-09-22 14:25:46 --> Database Driver Class Initialized
INFO - 2023-09-22 14:25:46 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-22 14:25:46 --> Controller Class Initialized
DEBUG - 2023-09-22 14:25:46 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/views/form.php
DEBUG - 2023-09-22 14:25:46 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-09-22 14:25:46 --> Final output sent to browser
DEBUG - 2023-09-22 14:25:46 --> Total execution time: 0.0474
INFO - 2023-09-22 14:26:01 --> Config Class Initialized
INFO - 2023-09-22 14:26:01 --> Hooks Class Initialized
DEBUG - 2023-09-22 14:26:01 --> UTF-8 Support Enabled
INFO - 2023-09-22 14:26:01 --> Utf8 Class Initialized
INFO - 2023-09-22 14:26:01 --> URI Class Initialized
INFO - 2023-09-22 14:26:01 --> Router Class Initialized
INFO - 2023-09-22 14:26:01 --> Output Class Initialized
INFO - 2023-09-22 14:26:01 --> Security Class Initialized
DEBUG - 2023-09-22 14:26:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-22 14:26:01 --> Input Class Initialized
INFO - 2023-09-22 14:26:01 --> Language Class Initialized
INFO - 2023-09-22 14:26:01 --> Language Class Initialized
INFO - 2023-09-22 14:26:01 --> Config Class Initialized
INFO - 2023-09-22 14:26:01 --> Loader Class Initialized
INFO - 2023-09-22 14:26:01 --> Helper loaded: url_helper
INFO - 2023-09-22 14:26:01 --> Helper loaded: file_helper
INFO - 2023-09-22 14:26:01 --> Helper loaded: form_helper
INFO - 2023-09-22 14:26:01 --> Helper loaded: my_helper
INFO - 2023-09-22 14:26:01 --> Database Driver Class Initialized
INFO - 2023-09-22 14:26:01 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-22 14:26:01 --> Controller Class Initialized
DEBUG - 2023-09-22 14:26:01 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/views/list.php
DEBUG - 2023-09-22 14:26:01 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-09-22 14:26:01 --> Final output sent to browser
DEBUG - 2023-09-22 14:26:01 --> Total execution time: 0.0573
INFO - 2023-09-22 14:26:01 --> Config Class Initialized
INFO - 2023-09-22 14:26:01 --> Hooks Class Initialized
DEBUG - 2023-09-22 14:26:01 --> UTF-8 Support Enabled
INFO - 2023-09-22 14:26:01 --> Utf8 Class Initialized
INFO - 2023-09-22 14:26:01 --> URI Class Initialized
INFO - 2023-09-22 14:26:01 --> Router Class Initialized
INFO - 2023-09-22 14:26:01 --> Output Class Initialized
INFO - 2023-09-22 14:26:01 --> Security Class Initialized
DEBUG - 2023-09-22 14:26:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-22 14:26:01 --> Input Class Initialized
INFO - 2023-09-22 14:26:01 --> Language Class Initialized
INFO - 2023-09-22 14:26:01 --> Language Class Initialized
INFO - 2023-09-22 14:26:01 --> Config Class Initialized
INFO - 2023-09-22 14:26:01 --> Loader Class Initialized
INFO - 2023-09-22 14:26:01 --> Helper loaded: url_helper
INFO - 2023-09-22 14:26:01 --> Helper loaded: file_helper
INFO - 2023-09-22 14:26:01 --> Helper loaded: form_helper
INFO - 2023-09-22 14:26:01 --> Helper loaded: my_helper
INFO - 2023-09-22 14:26:01 --> Database Driver Class Initialized
INFO - 2023-09-22 14:26:01 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-22 14:26:01 --> Controller Class Initialized
INFO - 2023-09-22 14:26:30 --> Config Class Initialized
INFO - 2023-09-22 14:26:30 --> Hooks Class Initialized
DEBUG - 2023-09-22 14:26:30 --> UTF-8 Support Enabled
INFO - 2023-09-22 14:26:30 --> Utf8 Class Initialized
INFO - 2023-09-22 14:26:30 --> URI Class Initialized
INFO - 2023-09-22 14:26:30 --> Router Class Initialized
INFO - 2023-09-22 14:26:30 --> Output Class Initialized
INFO - 2023-09-22 14:26:30 --> Security Class Initialized
DEBUG - 2023-09-22 14:26:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-22 14:26:30 --> Input Class Initialized
INFO - 2023-09-22 14:26:30 --> Language Class Initialized
INFO - 2023-09-22 14:26:30 --> Language Class Initialized
INFO - 2023-09-22 14:26:30 --> Config Class Initialized
INFO - 2023-09-22 14:26:30 --> Loader Class Initialized
INFO - 2023-09-22 14:26:30 --> Helper loaded: url_helper
INFO - 2023-09-22 14:26:30 --> Helper loaded: file_helper
INFO - 2023-09-22 14:26:30 --> Helper loaded: form_helper
INFO - 2023-09-22 14:26:30 --> Helper loaded: my_helper
INFO - 2023-09-22 14:26:30 --> Database Driver Class Initialized
INFO - 2023-09-22 14:26:30 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-22 14:26:30 --> Controller Class Initialized
INFO - 2023-09-22 14:26:30 --> Final output sent to browser
DEBUG - 2023-09-22 14:26:30 --> Total execution time: 0.0403
INFO - 2023-09-22 14:29:07 --> Config Class Initialized
INFO - 2023-09-22 14:29:07 --> Hooks Class Initialized
DEBUG - 2023-09-22 14:29:07 --> UTF-8 Support Enabled
INFO - 2023-09-22 14:29:07 --> Utf8 Class Initialized
INFO - 2023-09-22 14:29:07 --> URI Class Initialized
INFO - 2023-09-22 14:29:07 --> Router Class Initialized
INFO - 2023-09-22 14:29:07 --> Output Class Initialized
INFO - 2023-09-22 14:29:07 --> Security Class Initialized
DEBUG - 2023-09-22 14:29:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-22 14:29:07 --> Input Class Initialized
INFO - 2023-09-22 14:29:07 --> Language Class Initialized
INFO - 2023-09-22 14:29:07 --> Language Class Initialized
INFO - 2023-09-22 14:29:07 --> Config Class Initialized
INFO - 2023-09-22 14:29:07 --> Loader Class Initialized
INFO - 2023-09-22 14:29:07 --> Helper loaded: url_helper
INFO - 2023-09-22 14:29:07 --> Helper loaded: file_helper
INFO - 2023-09-22 14:29:07 --> Helper loaded: form_helper
INFO - 2023-09-22 14:29:07 --> Helper loaded: my_helper
INFO - 2023-09-22 14:29:07 --> Database Driver Class Initialized
INFO - 2023-09-22 14:29:07 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-22 14:29:07 --> Controller Class Initialized
INFO - 2023-09-22 14:29:07 --> Final output sent to browser
DEBUG - 2023-09-22 14:29:07 --> Total execution time: 0.0467
INFO - 2023-09-22 14:29:08 --> Config Class Initialized
INFO - 2023-09-22 14:29:08 --> Hooks Class Initialized
DEBUG - 2023-09-22 14:29:08 --> UTF-8 Support Enabled
INFO - 2023-09-22 14:29:08 --> Utf8 Class Initialized
INFO - 2023-09-22 14:29:08 --> URI Class Initialized
INFO - 2023-09-22 14:29:08 --> Router Class Initialized
INFO - 2023-09-22 14:29:08 --> Output Class Initialized
INFO - 2023-09-22 14:29:08 --> Security Class Initialized
DEBUG - 2023-09-22 14:29:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-22 14:29:08 --> Input Class Initialized
INFO - 2023-09-22 14:29:08 --> Language Class Initialized
INFO - 2023-09-22 14:29:08 --> Language Class Initialized
INFO - 2023-09-22 14:29:08 --> Config Class Initialized
INFO - 2023-09-22 14:29:08 --> Loader Class Initialized
INFO - 2023-09-22 14:29:08 --> Helper loaded: url_helper
INFO - 2023-09-22 14:29:08 --> Helper loaded: file_helper
INFO - 2023-09-22 14:29:08 --> Helper loaded: form_helper
INFO - 2023-09-22 14:29:08 --> Helper loaded: my_helper
INFO - 2023-09-22 14:29:08 --> Database Driver Class Initialized
INFO - 2023-09-22 14:29:08 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-22 14:29:08 --> Controller Class Initialized
INFO - 2023-09-22 14:29:08 --> Final output sent to browser
DEBUG - 2023-09-22 14:29:08 --> Total execution time: 0.0399
INFO - 2023-09-22 14:29:09 --> Config Class Initialized
INFO - 2023-09-22 14:29:09 --> Hooks Class Initialized
DEBUG - 2023-09-22 14:29:09 --> UTF-8 Support Enabled
INFO - 2023-09-22 14:29:09 --> Utf8 Class Initialized
INFO - 2023-09-22 14:29:09 --> URI Class Initialized
INFO - 2023-09-22 14:29:10 --> Config Class Initialized
INFO - 2023-09-22 14:29:10 --> Hooks Class Initialized
DEBUG - 2023-09-22 14:29:10 --> UTF-8 Support Enabled
INFO - 2023-09-22 14:29:10 --> Utf8 Class Initialized
INFO - 2023-09-22 14:29:10 --> URI Class Initialized
INFO - 2023-09-22 14:29:10 --> Router Class Initialized
INFO - 2023-09-22 14:29:10 --> Output Class Initialized
INFO - 2023-09-22 14:29:10 --> Security Class Initialized
DEBUG - 2023-09-22 14:29:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-22 14:29:10 --> Input Class Initialized
INFO - 2023-09-22 14:29:10 --> Language Class Initialized
INFO - 2023-09-22 14:29:10 --> Router Class Initialized
INFO - 2023-09-22 14:29:10 --> Output Class Initialized
INFO - 2023-09-22 14:29:10 --> Security Class Initialized
DEBUG - 2023-09-22 14:29:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-22 14:29:10 --> Input Class Initialized
INFO - 2023-09-22 14:29:10 --> Language Class Initialized
INFO - 2023-09-22 14:29:10 --> Language Class Initialized
INFO - 2023-09-22 14:29:10 --> Config Class Initialized
INFO - 2023-09-22 14:29:10 --> Loader Class Initialized
INFO - 2023-09-22 14:29:10 --> Helper loaded: url_helper
INFO - 2023-09-22 14:29:10 --> Helper loaded: file_helper
INFO - 2023-09-22 14:29:10 --> Helper loaded: form_helper
INFO - 2023-09-22 14:29:10 --> Helper loaded: my_helper
INFO - 2023-09-22 14:29:10 --> Language Class Initialized
INFO - 2023-09-22 14:29:10 --> Config Class Initialized
INFO - 2023-09-22 14:29:10 --> Loader Class Initialized
INFO - 2023-09-22 14:29:10 --> Helper loaded: url_helper
INFO - 2023-09-22 14:29:10 --> Helper loaded: file_helper
INFO - 2023-09-22 14:29:10 --> Helper loaded: form_helper
INFO - 2023-09-22 14:29:10 --> Helper loaded: my_helper
INFO - 2023-09-22 14:29:10 --> Database Driver Class Initialized
INFO - 2023-09-22 14:29:10 --> Database Driver Class Initialized
INFO - 2023-09-22 14:29:10 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-22 14:29:10 --> Controller Class Initialized
INFO - 2023-09-22 14:29:10 --> Final output sent to browser
DEBUG - 2023-09-22 14:29:10 --> Total execution time: 0.0993
INFO - 2023-09-22 14:29:10 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-22 14:29:10 --> Controller Class Initialized
INFO - 2023-09-22 14:29:11 --> Config Class Initialized
INFO - 2023-09-22 14:29:11 --> Hooks Class Initialized
DEBUG - 2023-09-22 14:29:11 --> UTF-8 Support Enabled
INFO - 2023-09-22 14:29:11 --> Utf8 Class Initialized
INFO - 2023-09-22 14:29:11 --> URI Class Initialized
INFO - 2023-09-22 14:29:11 --> Router Class Initialized
INFO - 2023-09-22 14:29:11 --> Output Class Initialized
INFO - 2023-09-22 14:29:11 --> Security Class Initialized
DEBUG - 2023-09-22 14:29:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-22 14:29:11 --> Input Class Initialized
INFO - 2023-09-22 14:29:11 --> Language Class Initialized
INFO - 2023-09-22 14:29:11 --> Language Class Initialized
INFO - 2023-09-22 14:29:11 --> Config Class Initialized
INFO - 2023-09-22 14:29:11 --> Loader Class Initialized
INFO - 2023-09-22 14:29:11 --> Helper loaded: url_helper
INFO - 2023-09-22 14:29:11 --> Helper loaded: file_helper
INFO - 2023-09-22 14:29:11 --> Helper loaded: form_helper
INFO - 2023-09-22 14:29:11 --> Helper loaded: my_helper
INFO - 2023-09-22 14:29:11 --> Database Driver Class Initialized
INFO - 2023-09-22 14:29:11 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-22 14:29:11 --> Controller Class Initialized
INFO - 2023-09-22 14:29:14 --> Config Class Initialized
INFO - 2023-09-22 14:29:14 --> Hooks Class Initialized
DEBUG - 2023-09-22 14:29:14 --> UTF-8 Support Enabled
INFO - 2023-09-22 14:29:14 --> Utf8 Class Initialized
INFO - 2023-09-22 14:29:14 --> URI Class Initialized
INFO - 2023-09-22 14:29:14 --> Router Class Initialized
INFO - 2023-09-22 14:29:14 --> Output Class Initialized
INFO - 2023-09-22 14:29:14 --> Security Class Initialized
DEBUG - 2023-09-22 14:29:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-22 14:29:14 --> Input Class Initialized
INFO - 2023-09-22 14:29:14 --> Language Class Initialized
INFO - 2023-09-22 14:29:14 --> Language Class Initialized
INFO - 2023-09-22 14:29:14 --> Config Class Initialized
INFO - 2023-09-22 14:29:14 --> Loader Class Initialized
INFO - 2023-09-22 14:29:14 --> Helper loaded: url_helper
INFO - 2023-09-22 14:29:14 --> Helper loaded: file_helper
INFO - 2023-09-22 14:29:14 --> Helper loaded: form_helper
INFO - 2023-09-22 14:29:14 --> Helper loaded: my_helper
INFO - 2023-09-22 14:29:14 --> Database Driver Class Initialized
INFO - 2023-09-22 14:29:14 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-22 14:29:14 --> Controller Class Initialized
INFO - 2023-09-22 14:29:14 --> Final output sent to browser
DEBUG - 2023-09-22 14:29:14 --> Total execution time: 0.0432
INFO - 2023-09-22 14:29:16 --> Config Class Initialized
INFO - 2023-09-22 14:29:16 --> Hooks Class Initialized
DEBUG - 2023-09-22 14:29:16 --> UTF-8 Support Enabled
INFO - 2023-09-22 14:29:16 --> Utf8 Class Initialized
INFO - 2023-09-22 14:29:16 --> URI Class Initialized
INFO - 2023-09-22 14:29:16 --> Router Class Initialized
INFO - 2023-09-22 14:29:16 --> Output Class Initialized
INFO - 2023-09-22 14:29:16 --> Security Class Initialized
DEBUG - 2023-09-22 14:29:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-22 14:29:16 --> Input Class Initialized
INFO - 2023-09-22 14:29:16 --> Language Class Initialized
INFO - 2023-09-22 14:29:16 --> Language Class Initialized
INFO - 2023-09-22 14:29:16 --> Config Class Initialized
INFO - 2023-09-22 14:29:16 --> Loader Class Initialized
INFO - 2023-09-22 14:29:16 --> Helper loaded: url_helper
INFO - 2023-09-22 14:29:16 --> Helper loaded: file_helper
INFO - 2023-09-22 14:29:16 --> Helper loaded: form_helper
INFO - 2023-09-22 14:29:16 --> Helper loaded: my_helper
INFO - 2023-09-22 14:29:16 --> Database Driver Class Initialized
INFO - 2023-09-22 14:29:16 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-22 14:29:16 --> Controller Class Initialized
INFO - 2023-09-22 14:29:16 --> Final output sent to browser
DEBUG - 2023-09-22 14:29:16 --> Total execution time: 0.0381
INFO - 2023-09-22 14:29:16 --> Config Class Initialized
INFO - 2023-09-22 14:29:16 --> Hooks Class Initialized
DEBUG - 2023-09-22 14:29:16 --> UTF-8 Support Enabled
INFO - 2023-09-22 14:29:16 --> Utf8 Class Initialized
INFO - 2023-09-22 14:29:16 --> URI Class Initialized
INFO - 2023-09-22 14:29:16 --> Router Class Initialized
INFO - 2023-09-22 14:29:16 --> Output Class Initialized
INFO - 2023-09-22 14:29:16 --> Security Class Initialized
DEBUG - 2023-09-22 14:29:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-22 14:29:16 --> Input Class Initialized
INFO - 2023-09-22 14:29:16 --> Language Class Initialized
INFO - 2023-09-22 14:29:16 --> Language Class Initialized
INFO - 2023-09-22 14:29:16 --> Config Class Initialized
INFO - 2023-09-22 14:29:16 --> Loader Class Initialized
INFO - 2023-09-22 14:29:16 --> Helper loaded: url_helper
INFO - 2023-09-22 14:29:16 --> Helper loaded: file_helper
INFO - 2023-09-22 14:29:16 --> Helper loaded: form_helper
INFO - 2023-09-22 14:29:16 --> Helper loaded: my_helper
INFO - 2023-09-22 14:29:16 --> Database Driver Class Initialized
INFO - 2023-09-22 14:29:16 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-22 14:29:16 --> Controller Class Initialized
INFO - 2023-09-22 14:29:18 --> Config Class Initialized
INFO - 2023-09-22 14:29:18 --> Hooks Class Initialized
DEBUG - 2023-09-22 14:29:18 --> UTF-8 Support Enabled
INFO - 2023-09-22 14:29:18 --> Utf8 Class Initialized
INFO - 2023-09-22 14:29:18 --> URI Class Initialized
INFO - 2023-09-22 14:29:18 --> Config Class Initialized
INFO - 2023-09-22 14:29:18 --> Hooks Class Initialized
DEBUG - 2023-09-22 14:29:18 --> UTF-8 Support Enabled
INFO - 2023-09-22 14:29:18 --> Utf8 Class Initialized
INFO - 2023-09-22 14:29:18 --> URI Class Initialized
INFO - 2023-09-22 14:29:18 --> Router Class Initialized
INFO - 2023-09-22 14:29:18 --> Output Class Initialized
INFO - 2023-09-22 14:29:18 --> Security Class Initialized
DEBUG - 2023-09-22 14:29:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-22 14:29:18 --> Input Class Initialized
INFO - 2023-09-22 14:29:18 --> Language Class Initialized
INFO - 2023-09-22 14:29:18 --> Router Class Initialized
INFO - 2023-09-22 14:29:18 --> Output Class Initialized
INFO - 2023-09-22 14:29:18 --> Security Class Initialized
DEBUG - 2023-09-22 14:29:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-22 14:29:18 --> Input Class Initialized
INFO - 2023-09-22 14:29:18 --> Language Class Initialized
INFO - 2023-09-22 14:29:18 --> Language Class Initialized
INFO - 2023-09-22 14:29:18 --> Config Class Initialized
INFO - 2023-09-22 14:29:18 --> Loader Class Initialized
INFO - 2023-09-22 14:29:18 --> Helper loaded: url_helper
INFO - 2023-09-22 14:29:18 --> Helper loaded: file_helper
INFO - 2023-09-22 14:29:18 --> Helper loaded: form_helper
INFO - 2023-09-22 14:29:18 --> Language Class Initialized
INFO - 2023-09-22 14:29:18 --> Config Class Initialized
INFO - 2023-09-22 14:29:18 --> Loader Class Initialized
INFO - 2023-09-22 14:29:18 --> Helper loaded: url_helper
INFO - 2023-09-22 14:29:18 --> Helper loaded: file_helper
INFO - 2023-09-22 14:29:18 --> Helper loaded: form_helper
INFO - 2023-09-22 14:29:18 --> Helper loaded: my_helper
INFO - 2023-09-22 14:29:18 --> Helper loaded: my_helper
INFO - 2023-09-22 14:29:18 --> Database Driver Class Initialized
INFO - 2023-09-22 14:29:18 --> Database Driver Class Initialized
INFO - 2023-09-22 14:29:18 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-22 14:29:18 --> Controller Class Initialized
INFO - 2023-09-22 14:29:18 --> Final output sent to browser
DEBUG - 2023-09-22 14:29:18 --> Total execution time: 0.1193
INFO - 2023-09-22 14:29:18 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-22 14:29:18 --> Controller Class Initialized
INFO - 2023-09-22 14:29:18 --> Config Class Initialized
INFO - 2023-09-22 14:29:18 --> Hooks Class Initialized
DEBUG - 2023-09-22 14:29:18 --> UTF-8 Support Enabled
INFO - 2023-09-22 14:29:18 --> Utf8 Class Initialized
INFO - 2023-09-22 14:29:18 --> URI Class Initialized
INFO - 2023-09-22 14:29:18 --> Router Class Initialized
INFO - 2023-09-22 14:29:18 --> Output Class Initialized
INFO - 2023-09-22 14:29:18 --> Security Class Initialized
DEBUG - 2023-09-22 14:29:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-22 14:29:18 --> Input Class Initialized
INFO - 2023-09-22 14:29:18 --> Language Class Initialized
INFO - 2023-09-22 14:29:18 --> Language Class Initialized
INFO - 2023-09-22 14:29:18 --> Config Class Initialized
INFO - 2023-09-22 14:29:18 --> Loader Class Initialized
INFO - 2023-09-22 14:29:18 --> Helper loaded: url_helper
INFO - 2023-09-22 14:29:18 --> Helper loaded: file_helper
INFO - 2023-09-22 14:29:18 --> Helper loaded: form_helper
INFO - 2023-09-22 14:29:18 --> Helper loaded: my_helper
INFO - 2023-09-22 14:29:18 --> Database Driver Class Initialized
INFO - 2023-09-22 14:29:18 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-22 14:29:18 --> Controller Class Initialized
INFO - 2023-09-22 14:29:18 --> Config Class Initialized
INFO - 2023-09-22 14:29:18 --> Hooks Class Initialized
DEBUG - 2023-09-22 14:29:18 --> UTF-8 Support Enabled
INFO - 2023-09-22 14:29:18 --> Utf8 Class Initialized
INFO - 2023-09-22 14:29:18 --> URI Class Initialized
INFO - 2023-09-22 14:29:18 --> Router Class Initialized
INFO - 2023-09-22 14:29:18 --> Output Class Initialized
INFO - 2023-09-22 14:29:18 --> Security Class Initialized
DEBUG - 2023-09-22 14:29:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-22 14:29:18 --> Input Class Initialized
INFO - 2023-09-22 14:29:18 --> Language Class Initialized
INFO - 2023-09-22 14:29:18 --> Language Class Initialized
INFO - 2023-09-22 14:29:18 --> Config Class Initialized
INFO - 2023-09-22 14:29:18 --> Loader Class Initialized
INFO - 2023-09-22 14:29:18 --> Helper loaded: url_helper
INFO - 2023-09-22 14:29:18 --> Helper loaded: file_helper
INFO - 2023-09-22 14:29:18 --> Helper loaded: form_helper
INFO - 2023-09-22 14:29:18 --> Helper loaded: my_helper
INFO - 2023-09-22 14:29:18 --> Database Driver Class Initialized
INFO - 2023-09-22 14:29:18 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-22 14:29:18 --> Controller Class Initialized
INFO - 2023-09-22 14:29:19 --> Config Class Initialized
INFO - 2023-09-22 14:29:19 --> Hooks Class Initialized
DEBUG - 2023-09-22 14:29:19 --> UTF-8 Support Enabled
INFO - 2023-09-22 14:29:19 --> Utf8 Class Initialized
INFO - 2023-09-22 14:29:19 --> URI Class Initialized
INFO - 2023-09-22 14:29:19 --> Router Class Initialized
INFO - 2023-09-22 14:29:19 --> Output Class Initialized
INFO - 2023-09-22 14:29:19 --> Security Class Initialized
DEBUG - 2023-09-22 14:29:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-22 14:29:19 --> Input Class Initialized
INFO - 2023-09-22 14:29:19 --> Language Class Initialized
INFO - 2023-09-22 14:29:19 --> Language Class Initialized
INFO - 2023-09-22 14:29:19 --> Config Class Initialized
INFO - 2023-09-22 14:29:19 --> Loader Class Initialized
INFO - 2023-09-22 14:29:19 --> Helper loaded: url_helper
INFO - 2023-09-22 14:29:19 --> Helper loaded: file_helper
INFO - 2023-09-22 14:29:19 --> Helper loaded: form_helper
INFO - 2023-09-22 14:29:19 --> Helper loaded: my_helper
INFO - 2023-09-22 14:29:19 --> Database Driver Class Initialized
INFO - 2023-09-22 14:29:19 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-22 14:29:19 --> Controller Class Initialized
INFO - 2023-09-22 14:29:19 --> Final output sent to browser
DEBUG - 2023-09-22 14:29:19 --> Total execution time: 0.0424
INFO - 2023-09-22 14:29:19 --> Config Class Initialized
INFO - 2023-09-22 14:29:19 --> Hooks Class Initialized
DEBUG - 2023-09-22 14:29:20 --> UTF-8 Support Enabled
INFO - 2023-09-22 14:29:20 --> Utf8 Class Initialized
INFO - 2023-09-22 14:29:20 --> URI Class Initialized
INFO - 2023-09-22 14:29:20 --> Router Class Initialized
INFO - 2023-09-22 14:29:20 --> Output Class Initialized
INFO - 2023-09-22 14:29:20 --> Security Class Initialized
DEBUG - 2023-09-22 14:29:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-22 14:29:20 --> Input Class Initialized
INFO - 2023-09-22 14:29:20 --> Language Class Initialized
INFO - 2023-09-22 14:29:20 --> Language Class Initialized
INFO - 2023-09-22 14:29:20 --> Config Class Initialized
INFO - 2023-09-22 14:29:20 --> Loader Class Initialized
INFO - 2023-09-22 14:29:20 --> Helper loaded: url_helper
INFO - 2023-09-22 14:29:20 --> Helper loaded: file_helper
INFO - 2023-09-22 14:29:20 --> Helper loaded: form_helper
INFO - 2023-09-22 14:29:20 --> Helper loaded: my_helper
INFO - 2023-09-22 14:29:20 --> Database Driver Class Initialized
INFO - 2023-09-22 14:29:20 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-22 14:29:20 --> Controller Class Initialized
INFO - 2023-09-22 14:29:25 --> Config Class Initialized
INFO - 2023-09-22 14:29:25 --> Hooks Class Initialized
DEBUG - 2023-09-22 14:29:25 --> UTF-8 Support Enabled
INFO - 2023-09-22 14:29:25 --> Utf8 Class Initialized
INFO - 2023-09-22 14:29:25 --> URI Class Initialized
INFO - 2023-09-22 14:29:25 --> Router Class Initialized
INFO - 2023-09-22 14:29:25 --> Output Class Initialized
INFO - 2023-09-22 14:29:25 --> Security Class Initialized
DEBUG - 2023-09-22 14:29:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-22 14:29:25 --> Input Class Initialized
INFO - 2023-09-22 14:29:25 --> Language Class Initialized
INFO - 2023-09-22 14:29:25 --> Language Class Initialized
INFO - 2023-09-22 14:29:25 --> Config Class Initialized
INFO - 2023-09-22 14:29:25 --> Loader Class Initialized
INFO - 2023-09-22 14:29:25 --> Helper loaded: url_helper
INFO - 2023-09-22 14:29:25 --> Helper loaded: file_helper
INFO - 2023-09-22 14:29:25 --> Helper loaded: form_helper
INFO - 2023-09-22 14:29:25 --> Helper loaded: my_helper
INFO - 2023-09-22 14:29:25 --> Database Driver Class Initialized
INFO - 2023-09-22 14:29:25 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-22 14:29:25 --> Controller Class Initialized
INFO - 2023-09-22 14:29:25 --> Final output sent to browser
DEBUG - 2023-09-22 14:29:25 --> Total execution time: 0.0367
INFO - 2023-09-22 14:29:25 --> Config Class Initialized
INFO - 2023-09-22 14:29:25 --> Hooks Class Initialized
DEBUG - 2023-09-22 14:29:25 --> UTF-8 Support Enabled
INFO - 2023-09-22 14:29:25 --> Utf8 Class Initialized
INFO - 2023-09-22 14:29:25 --> URI Class Initialized
INFO - 2023-09-22 14:29:25 --> Router Class Initialized
INFO - 2023-09-22 14:29:25 --> Output Class Initialized
INFO - 2023-09-22 14:29:25 --> Security Class Initialized
DEBUG - 2023-09-22 14:29:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-22 14:29:25 --> Input Class Initialized
INFO - 2023-09-22 14:29:25 --> Language Class Initialized
INFO - 2023-09-22 14:29:25 --> Language Class Initialized
INFO - 2023-09-22 14:29:25 --> Config Class Initialized
INFO - 2023-09-22 14:29:25 --> Loader Class Initialized
INFO - 2023-09-22 14:29:25 --> Helper loaded: url_helper
INFO - 2023-09-22 14:29:25 --> Helper loaded: file_helper
INFO - 2023-09-22 14:29:25 --> Helper loaded: form_helper
INFO - 2023-09-22 14:29:25 --> Helper loaded: my_helper
INFO - 2023-09-22 14:29:25 --> Database Driver Class Initialized
INFO - 2023-09-22 14:29:25 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-22 14:29:25 --> Controller Class Initialized
INFO - 2023-09-22 14:29:26 --> Config Class Initialized
INFO - 2023-09-22 14:29:26 --> Hooks Class Initialized
DEBUG - 2023-09-22 14:29:26 --> UTF-8 Support Enabled
INFO - 2023-09-22 14:29:26 --> Utf8 Class Initialized
INFO - 2023-09-22 14:29:26 --> URI Class Initialized
INFO - 2023-09-22 14:29:26 --> Router Class Initialized
INFO - 2023-09-22 14:29:26 --> Output Class Initialized
INFO - 2023-09-22 14:29:26 --> Security Class Initialized
DEBUG - 2023-09-22 14:29:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-22 14:29:26 --> Input Class Initialized
INFO - 2023-09-22 14:29:26 --> Language Class Initialized
INFO - 2023-09-22 14:29:26 --> Language Class Initialized
INFO - 2023-09-22 14:29:26 --> Config Class Initialized
INFO - 2023-09-22 14:29:26 --> Loader Class Initialized
INFO - 2023-09-22 14:29:26 --> Helper loaded: url_helper
INFO - 2023-09-22 14:29:26 --> Helper loaded: file_helper
INFO - 2023-09-22 14:29:26 --> Helper loaded: form_helper
INFO - 2023-09-22 14:29:26 --> Helper loaded: my_helper
INFO - 2023-09-22 14:29:26 --> Database Driver Class Initialized
INFO - 2023-09-22 14:29:26 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-22 14:29:26 --> Controller Class Initialized
INFO - 2023-09-22 14:29:26 --> Final output sent to browser
DEBUG - 2023-09-22 14:29:26 --> Total execution time: 0.0977
INFO - 2023-09-22 14:29:27 --> Config Class Initialized
INFO - 2023-09-22 14:29:27 --> Hooks Class Initialized
DEBUG - 2023-09-22 14:29:27 --> UTF-8 Support Enabled
INFO - 2023-09-22 14:29:27 --> Utf8 Class Initialized
INFO - 2023-09-22 14:29:27 --> URI Class Initialized
INFO - 2023-09-22 14:29:27 --> Router Class Initialized
INFO - 2023-09-22 14:29:27 --> Output Class Initialized
INFO - 2023-09-22 14:29:27 --> Security Class Initialized
DEBUG - 2023-09-22 14:29:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-22 14:29:27 --> Input Class Initialized
INFO - 2023-09-22 14:29:27 --> Language Class Initialized
INFO - 2023-09-22 14:29:27 --> Language Class Initialized
INFO - 2023-09-22 14:29:27 --> Config Class Initialized
INFO - 2023-09-22 14:29:27 --> Loader Class Initialized
INFO - 2023-09-22 14:29:27 --> Helper loaded: url_helper
INFO - 2023-09-22 14:29:27 --> Helper loaded: file_helper
INFO - 2023-09-22 14:29:27 --> Helper loaded: form_helper
INFO - 2023-09-22 14:29:27 --> Helper loaded: my_helper
INFO - 2023-09-22 14:29:27 --> Database Driver Class Initialized
INFO - 2023-09-22 14:29:27 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-22 14:29:27 --> Controller Class Initialized
INFO - 2023-09-22 14:29:33 --> Config Class Initialized
INFO - 2023-09-22 14:29:33 --> Hooks Class Initialized
DEBUG - 2023-09-22 14:29:33 --> UTF-8 Support Enabled
INFO - 2023-09-22 14:29:33 --> Utf8 Class Initialized
INFO - 2023-09-22 14:29:33 --> URI Class Initialized
INFO - 2023-09-22 14:29:33 --> Router Class Initialized
INFO - 2023-09-22 14:29:33 --> Output Class Initialized
INFO - 2023-09-22 14:29:33 --> Security Class Initialized
DEBUG - 2023-09-22 14:29:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-22 14:29:33 --> Input Class Initialized
INFO - 2023-09-22 14:29:33 --> Language Class Initialized
INFO - 2023-09-22 14:29:33 --> Language Class Initialized
INFO - 2023-09-22 14:29:33 --> Config Class Initialized
INFO - 2023-09-22 14:29:33 --> Loader Class Initialized
INFO - 2023-09-22 14:29:33 --> Helper loaded: url_helper
INFO - 2023-09-22 14:29:33 --> Helper loaded: file_helper
INFO - 2023-09-22 14:29:33 --> Helper loaded: form_helper
INFO - 2023-09-22 14:29:33 --> Helper loaded: my_helper
INFO - 2023-09-22 14:29:33 --> Database Driver Class Initialized
INFO - 2023-09-22 14:29:33 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-22 14:29:33 --> Controller Class Initialized
INFO - 2023-09-22 14:29:33 --> Final output sent to browser
DEBUG - 2023-09-22 14:29:33 --> Total execution time: 0.0430
INFO - 2023-09-22 14:29:34 --> Config Class Initialized
INFO - 2023-09-22 14:29:34 --> Hooks Class Initialized
DEBUG - 2023-09-22 14:29:34 --> UTF-8 Support Enabled
INFO - 2023-09-22 14:29:34 --> Utf8 Class Initialized
INFO - 2023-09-22 14:29:34 --> URI Class Initialized
INFO - 2023-09-22 14:29:34 --> Router Class Initialized
INFO - 2023-09-22 14:29:34 --> Output Class Initialized
INFO - 2023-09-22 14:29:34 --> Security Class Initialized
DEBUG - 2023-09-22 14:29:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-22 14:29:34 --> Input Class Initialized
INFO - 2023-09-22 14:29:34 --> Language Class Initialized
INFO - 2023-09-22 14:29:34 --> Language Class Initialized
INFO - 2023-09-22 14:29:34 --> Config Class Initialized
INFO - 2023-09-22 14:29:34 --> Loader Class Initialized
INFO - 2023-09-22 14:29:34 --> Helper loaded: url_helper
INFO - 2023-09-22 14:29:34 --> Helper loaded: file_helper
INFO - 2023-09-22 14:29:34 --> Helper loaded: form_helper
INFO - 2023-09-22 14:29:34 --> Helper loaded: my_helper
INFO - 2023-09-22 14:29:34 --> Database Driver Class Initialized
INFO - 2023-09-22 14:29:34 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-22 14:29:34 --> Controller Class Initialized
INFO - 2023-09-22 14:29:35 --> Config Class Initialized
INFO - 2023-09-22 14:29:35 --> Hooks Class Initialized
DEBUG - 2023-09-22 14:29:35 --> UTF-8 Support Enabled
INFO - 2023-09-22 14:29:35 --> Utf8 Class Initialized
INFO - 2023-09-22 14:29:35 --> URI Class Initialized
INFO - 2023-09-22 14:29:35 --> Router Class Initialized
INFO - 2023-09-22 14:29:35 --> Output Class Initialized
INFO - 2023-09-22 14:29:35 --> Security Class Initialized
DEBUG - 2023-09-22 14:29:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-22 14:29:35 --> Input Class Initialized
INFO - 2023-09-22 14:29:35 --> Language Class Initialized
INFO - 2023-09-22 14:29:35 --> Language Class Initialized
INFO - 2023-09-22 14:29:35 --> Config Class Initialized
INFO - 2023-09-22 14:29:35 --> Loader Class Initialized
INFO - 2023-09-22 14:29:35 --> Helper loaded: url_helper
INFO - 2023-09-22 14:29:35 --> Helper loaded: file_helper
INFO - 2023-09-22 14:29:35 --> Helper loaded: form_helper
INFO - 2023-09-22 14:29:35 --> Helper loaded: my_helper
INFO - 2023-09-22 14:29:35 --> Database Driver Class Initialized
INFO - 2023-09-22 14:29:35 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-22 14:29:35 --> Controller Class Initialized
INFO - 2023-09-22 14:29:35 --> Final output sent to browser
DEBUG - 2023-09-22 14:29:35 --> Total execution time: 0.0327
INFO - 2023-09-22 14:29:35 --> Config Class Initialized
INFO - 2023-09-22 14:29:35 --> Hooks Class Initialized
DEBUG - 2023-09-22 14:29:35 --> UTF-8 Support Enabled
INFO - 2023-09-22 14:29:35 --> Utf8 Class Initialized
INFO - 2023-09-22 14:29:35 --> URI Class Initialized
INFO - 2023-09-22 14:29:35 --> Router Class Initialized
INFO - 2023-09-22 14:29:35 --> Output Class Initialized
INFO - 2023-09-22 14:29:35 --> Security Class Initialized
DEBUG - 2023-09-22 14:29:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-22 14:29:35 --> Input Class Initialized
INFO - 2023-09-22 14:29:35 --> Language Class Initialized
INFO - 2023-09-22 14:29:35 --> Language Class Initialized
INFO - 2023-09-22 14:29:35 --> Config Class Initialized
INFO - 2023-09-22 14:29:35 --> Loader Class Initialized
INFO - 2023-09-22 14:29:35 --> Helper loaded: url_helper
INFO - 2023-09-22 14:29:35 --> Helper loaded: file_helper
INFO - 2023-09-22 14:29:35 --> Helper loaded: form_helper
INFO - 2023-09-22 14:29:35 --> Helper loaded: my_helper
INFO - 2023-09-22 14:29:35 --> Database Driver Class Initialized
INFO - 2023-09-22 14:29:35 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-22 14:29:35 --> Controller Class Initialized
INFO - 2023-09-22 14:29:37 --> Config Class Initialized
INFO - 2023-09-22 14:29:37 --> Hooks Class Initialized
DEBUG - 2023-09-22 14:29:37 --> UTF-8 Support Enabled
INFO - 2023-09-22 14:29:37 --> Utf8 Class Initialized
INFO - 2023-09-22 14:29:37 --> URI Class Initialized
INFO - 2023-09-22 14:29:37 --> Router Class Initialized
INFO - 2023-09-22 14:29:37 --> Output Class Initialized
INFO - 2023-09-22 14:29:37 --> Security Class Initialized
DEBUG - 2023-09-22 14:29:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-22 14:29:37 --> Input Class Initialized
INFO - 2023-09-22 14:29:37 --> Language Class Initialized
INFO - 2023-09-22 14:29:37 --> Language Class Initialized
INFO - 2023-09-22 14:29:37 --> Config Class Initialized
INFO - 2023-09-22 14:29:37 --> Loader Class Initialized
INFO - 2023-09-22 14:29:37 --> Helper loaded: url_helper
INFO - 2023-09-22 14:29:37 --> Helper loaded: file_helper
INFO - 2023-09-22 14:29:37 --> Helper loaded: form_helper
INFO - 2023-09-22 14:29:37 --> Helper loaded: my_helper
INFO - 2023-09-22 14:29:37 --> Database Driver Class Initialized
INFO - 2023-09-22 14:29:37 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-22 14:29:37 --> Controller Class Initialized
INFO - 2023-09-22 14:29:37 --> Final output sent to browser
DEBUG - 2023-09-22 14:29:37 --> Total execution time: 0.0929
INFO - 2023-09-22 14:29:37 --> Config Class Initialized
INFO - 2023-09-22 14:29:37 --> Hooks Class Initialized
DEBUG - 2023-09-22 14:29:37 --> UTF-8 Support Enabled
INFO - 2023-09-22 14:29:37 --> Utf8 Class Initialized
INFO - 2023-09-22 14:29:37 --> URI Class Initialized
INFO - 2023-09-22 14:29:37 --> Router Class Initialized
INFO - 2023-09-22 14:29:37 --> Output Class Initialized
INFO - 2023-09-22 14:29:37 --> Security Class Initialized
DEBUG - 2023-09-22 14:29:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-22 14:29:37 --> Input Class Initialized
INFO - 2023-09-22 14:29:37 --> Language Class Initialized
INFO - 2023-09-22 14:29:37 --> Language Class Initialized
INFO - 2023-09-22 14:29:37 --> Config Class Initialized
INFO - 2023-09-22 14:29:37 --> Loader Class Initialized
INFO - 2023-09-22 14:29:37 --> Helper loaded: url_helper
INFO - 2023-09-22 14:29:37 --> Helper loaded: file_helper
INFO - 2023-09-22 14:29:37 --> Helper loaded: form_helper
INFO - 2023-09-22 14:29:37 --> Helper loaded: my_helper
INFO - 2023-09-22 14:29:37 --> Database Driver Class Initialized
INFO - 2023-09-22 14:29:37 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-22 14:29:37 --> Controller Class Initialized
INFO - 2023-09-22 14:29:45 --> Config Class Initialized
INFO - 2023-09-22 14:29:45 --> Hooks Class Initialized
DEBUG - 2023-09-22 14:29:45 --> UTF-8 Support Enabled
INFO - 2023-09-22 14:29:45 --> Utf8 Class Initialized
INFO - 2023-09-22 14:29:45 --> URI Class Initialized
INFO - 2023-09-22 14:29:45 --> Router Class Initialized
INFO - 2023-09-22 14:29:45 --> Output Class Initialized
INFO - 2023-09-22 14:29:45 --> Security Class Initialized
DEBUG - 2023-09-22 14:29:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-22 14:29:45 --> Input Class Initialized
INFO - 2023-09-22 14:29:45 --> Language Class Initialized
INFO - 2023-09-22 14:29:45 --> Language Class Initialized
INFO - 2023-09-22 14:29:45 --> Config Class Initialized
INFO - 2023-09-22 14:29:45 --> Loader Class Initialized
INFO - 2023-09-22 14:29:45 --> Helper loaded: url_helper
INFO - 2023-09-22 14:29:45 --> Helper loaded: file_helper
INFO - 2023-09-22 14:29:45 --> Helper loaded: form_helper
INFO - 2023-09-22 14:29:45 --> Helper loaded: my_helper
INFO - 2023-09-22 14:29:45 --> Database Driver Class Initialized
INFO - 2023-09-22 14:29:45 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-22 14:29:45 --> Controller Class Initialized
INFO - 2023-09-22 14:29:45 --> Final output sent to browser
DEBUG - 2023-09-22 14:29:45 --> Total execution time: 0.0415
INFO - 2023-09-22 14:29:45 --> Config Class Initialized
INFO - 2023-09-22 14:29:45 --> Hooks Class Initialized
DEBUG - 2023-09-22 14:29:45 --> UTF-8 Support Enabled
INFO - 2023-09-22 14:29:45 --> Utf8 Class Initialized
INFO - 2023-09-22 14:29:45 --> URI Class Initialized
INFO - 2023-09-22 14:29:45 --> Router Class Initialized
INFO - 2023-09-22 14:29:45 --> Output Class Initialized
INFO - 2023-09-22 14:29:45 --> Security Class Initialized
DEBUG - 2023-09-22 14:29:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-22 14:29:45 --> Input Class Initialized
INFO - 2023-09-22 14:29:45 --> Language Class Initialized
INFO - 2023-09-22 14:29:45 --> Language Class Initialized
INFO - 2023-09-22 14:29:45 --> Config Class Initialized
INFO - 2023-09-22 14:29:45 --> Loader Class Initialized
INFO - 2023-09-22 14:29:45 --> Helper loaded: url_helper
INFO - 2023-09-22 14:29:45 --> Helper loaded: file_helper
INFO - 2023-09-22 14:29:45 --> Helper loaded: form_helper
INFO - 2023-09-22 14:29:45 --> Helper loaded: my_helper
INFO - 2023-09-22 14:29:45 --> Database Driver Class Initialized
INFO - 2023-09-22 14:29:45 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-22 14:29:45 --> Controller Class Initialized
INFO - 2023-09-22 14:30:03 --> Config Class Initialized
INFO - 2023-09-22 14:30:03 --> Hooks Class Initialized
DEBUG - 2023-09-22 14:30:03 --> UTF-8 Support Enabled
INFO - 2023-09-22 14:30:03 --> Utf8 Class Initialized
INFO - 2023-09-22 14:30:03 --> URI Class Initialized
INFO - 2023-09-22 14:30:03 --> Router Class Initialized
INFO - 2023-09-22 14:30:03 --> Output Class Initialized
INFO - 2023-09-22 14:30:03 --> Security Class Initialized
DEBUG - 2023-09-22 14:30:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-22 14:30:03 --> Input Class Initialized
INFO - 2023-09-22 14:30:03 --> Language Class Initialized
INFO - 2023-09-22 14:30:03 --> Language Class Initialized
INFO - 2023-09-22 14:30:03 --> Config Class Initialized
INFO - 2023-09-22 14:30:03 --> Loader Class Initialized
INFO - 2023-09-22 14:30:03 --> Helper loaded: url_helper
INFO - 2023-09-22 14:30:03 --> Helper loaded: file_helper
INFO - 2023-09-22 14:30:03 --> Helper loaded: form_helper
INFO - 2023-09-22 14:30:03 --> Helper loaded: my_helper
INFO - 2023-09-22 14:30:03 --> Database Driver Class Initialized
INFO - 2023-09-22 14:30:03 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-22 14:30:03 --> Controller Class Initialized
INFO - 2023-09-22 14:30:03 --> Final output sent to browser
DEBUG - 2023-09-22 14:30:03 --> Total execution time: 0.0417
INFO - 2023-09-22 14:30:03 --> Config Class Initialized
INFO - 2023-09-22 14:30:03 --> Hooks Class Initialized
DEBUG - 2023-09-22 14:30:03 --> UTF-8 Support Enabled
INFO - 2023-09-22 14:30:03 --> Utf8 Class Initialized
INFO - 2023-09-22 14:30:03 --> URI Class Initialized
INFO - 2023-09-22 14:30:03 --> Router Class Initialized
INFO - 2023-09-22 14:30:03 --> Output Class Initialized
INFO - 2023-09-22 14:30:03 --> Security Class Initialized
DEBUG - 2023-09-22 14:30:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-22 14:30:03 --> Input Class Initialized
INFO - 2023-09-22 14:30:03 --> Language Class Initialized
INFO - 2023-09-22 14:30:03 --> Language Class Initialized
INFO - 2023-09-22 14:30:03 --> Config Class Initialized
INFO - 2023-09-22 14:30:03 --> Loader Class Initialized
INFO - 2023-09-22 14:30:03 --> Helper loaded: url_helper
INFO - 2023-09-22 14:30:03 --> Helper loaded: file_helper
INFO - 2023-09-22 14:30:03 --> Helper loaded: form_helper
INFO - 2023-09-22 14:30:03 --> Helper loaded: my_helper
INFO - 2023-09-22 14:30:03 --> Database Driver Class Initialized
INFO - 2023-09-22 14:30:03 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-22 14:30:03 --> Controller Class Initialized
INFO - 2023-09-22 14:30:08 --> Config Class Initialized
INFO - 2023-09-22 14:30:08 --> Hooks Class Initialized
DEBUG - 2023-09-22 14:30:08 --> UTF-8 Support Enabled
INFO - 2023-09-22 14:30:08 --> Utf8 Class Initialized
INFO - 2023-09-22 14:30:08 --> URI Class Initialized
INFO - 2023-09-22 14:30:08 --> Router Class Initialized
INFO - 2023-09-22 14:30:08 --> Output Class Initialized
INFO - 2023-09-22 14:30:08 --> Security Class Initialized
DEBUG - 2023-09-22 14:30:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-22 14:30:08 --> Input Class Initialized
INFO - 2023-09-22 14:30:08 --> Language Class Initialized
INFO - 2023-09-22 14:30:08 --> Language Class Initialized
INFO - 2023-09-22 14:30:08 --> Config Class Initialized
INFO - 2023-09-22 14:30:08 --> Loader Class Initialized
INFO - 2023-09-22 14:30:08 --> Helper loaded: url_helper
INFO - 2023-09-22 14:30:08 --> Helper loaded: file_helper
INFO - 2023-09-22 14:30:08 --> Helper loaded: form_helper
INFO - 2023-09-22 14:30:08 --> Helper loaded: my_helper
INFO - 2023-09-22 14:30:08 --> Database Driver Class Initialized
INFO - 2023-09-22 14:30:08 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-22 14:30:08 --> Controller Class Initialized
INFO - 2023-09-22 14:30:08 --> Final output sent to browser
DEBUG - 2023-09-22 14:30:08 --> Total execution time: 0.0554
INFO - 2023-09-22 14:30:08 --> Config Class Initialized
INFO - 2023-09-22 14:30:08 --> Hooks Class Initialized
DEBUG - 2023-09-22 14:30:08 --> UTF-8 Support Enabled
INFO - 2023-09-22 14:30:08 --> Utf8 Class Initialized
INFO - 2023-09-22 14:30:08 --> URI Class Initialized
INFO - 2023-09-22 14:30:08 --> Router Class Initialized
INFO - 2023-09-22 14:30:08 --> Output Class Initialized
INFO - 2023-09-22 14:30:08 --> Security Class Initialized
DEBUG - 2023-09-22 14:30:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-22 14:30:08 --> Input Class Initialized
INFO - 2023-09-22 14:30:08 --> Language Class Initialized
INFO - 2023-09-22 14:30:08 --> Language Class Initialized
INFO - 2023-09-22 14:30:08 --> Config Class Initialized
INFO - 2023-09-22 14:30:08 --> Loader Class Initialized
INFO - 2023-09-22 14:30:08 --> Helper loaded: url_helper
INFO - 2023-09-22 14:30:08 --> Helper loaded: file_helper
INFO - 2023-09-22 14:30:08 --> Helper loaded: form_helper
INFO - 2023-09-22 14:30:08 --> Helper loaded: my_helper
INFO - 2023-09-22 14:30:08 --> Database Driver Class Initialized
INFO - 2023-09-22 14:30:08 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-22 14:30:08 --> Controller Class Initialized
INFO - 2023-09-22 14:30:11 --> Config Class Initialized
INFO - 2023-09-22 14:30:11 --> Hooks Class Initialized
DEBUG - 2023-09-22 14:30:11 --> UTF-8 Support Enabled
INFO - 2023-09-22 14:30:11 --> Utf8 Class Initialized
INFO - 2023-09-22 14:30:11 --> URI Class Initialized
INFO - 2023-09-22 14:30:11 --> Router Class Initialized
INFO - 2023-09-22 14:30:11 --> Output Class Initialized
INFO - 2023-09-22 14:30:11 --> Security Class Initialized
DEBUG - 2023-09-22 14:30:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-22 14:30:11 --> Input Class Initialized
INFO - 2023-09-22 14:30:11 --> Language Class Initialized
INFO - 2023-09-22 14:30:11 --> Language Class Initialized
INFO - 2023-09-22 14:30:11 --> Config Class Initialized
INFO - 2023-09-22 14:30:11 --> Loader Class Initialized
INFO - 2023-09-22 14:30:11 --> Helper loaded: url_helper
INFO - 2023-09-22 14:30:11 --> Helper loaded: file_helper
INFO - 2023-09-22 14:30:11 --> Helper loaded: form_helper
INFO - 2023-09-22 14:30:11 --> Helper loaded: my_helper
INFO - 2023-09-22 14:30:11 --> Database Driver Class Initialized
INFO - 2023-09-22 14:30:11 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-22 14:30:11 --> Controller Class Initialized
INFO - 2023-09-22 14:30:11 --> Final output sent to browser
DEBUG - 2023-09-22 14:30:11 --> Total execution time: 0.0581
INFO - 2023-09-22 14:30:12 --> Config Class Initialized
INFO - 2023-09-22 14:30:12 --> Hooks Class Initialized
DEBUG - 2023-09-22 14:30:12 --> UTF-8 Support Enabled
INFO - 2023-09-22 14:30:12 --> Utf8 Class Initialized
INFO - 2023-09-22 14:30:12 --> URI Class Initialized
INFO - 2023-09-22 14:30:12 --> Router Class Initialized
INFO - 2023-09-22 14:30:12 --> Output Class Initialized
INFO - 2023-09-22 14:30:12 --> Security Class Initialized
DEBUG - 2023-09-22 14:30:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-22 14:30:12 --> Input Class Initialized
INFO - 2023-09-22 14:30:12 --> Language Class Initialized
INFO - 2023-09-22 14:30:12 --> Language Class Initialized
INFO - 2023-09-22 14:30:12 --> Config Class Initialized
INFO - 2023-09-22 14:30:12 --> Loader Class Initialized
INFO - 2023-09-22 14:30:12 --> Helper loaded: url_helper
INFO - 2023-09-22 14:30:12 --> Helper loaded: file_helper
INFO - 2023-09-22 14:30:12 --> Helper loaded: form_helper
INFO - 2023-09-22 14:30:12 --> Helper loaded: my_helper
INFO - 2023-09-22 14:30:12 --> Database Driver Class Initialized
INFO - 2023-09-22 14:30:12 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-22 14:30:12 --> Controller Class Initialized
INFO - 2023-09-22 14:30:14 --> Config Class Initialized
INFO - 2023-09-22 14:30:14 --> Hooks Class Initialized
DEBUG - 2023-09-22 14:30:14 --> UTF-8 Support Enabled
INFO - 2023-09-22 14:30:14 --> Utf8 Class Initialized
INFO - 2023-09-22 14:30:14 --> URI Class Initialized
INFO - 2023-09-22 14:30:14 --> Router Class Initialized
INFO - 2023-09-22 14:30:14 --> Output Class Initialized
INFO - 2023-09-22 14:30:14 --> Security Class Initialized
DEBUG - 2023-09-22 14:30:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-22 14:30:14 --> Input Class Initialized
INFO - 2023-09-22 14:30:14 --> Language Class Initialized
INFO - 2023-09-22 14:30:14 --> Language Class Initialized
INFO - 2023-09-22 14:30:14 --> Config Class Initialized
INFO - 2023-09-22 14:30:14 --> Loader Class Initialized
INFO - 2023-09-22 14:30:14 --> Helper loaded: url_helper
INFO - 2023-09-22 14:30:14 --> Helper loaded: file_helper
INFO - 2023-09-22 14:30:14 --> Helper loaded: form_helper
INFO - 2023-09-22 14:30:14 --> Helper loaded: my_helper
INFO - 2023-09-22 14:30:14 --> Database Driver Class Initialized
INFO - 2023-09-22 14:30:14 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-22 14:30:14 --> Controller Class Initialized
INFO - 2023-09-22 14:30:14 --> Final output sent to browser
DEBUG - 2023-09-22 14:30:14 --> Total execution time: 0.1783
INFO - 2023-09-22 14:30:14 --> Config Class Initialized
INFO - 2023-09-22 14:30:14 --> Hooks Class Initialized
DEBUG - 2023-09-22 14:30:14 --> UTF-8 Support Enabled
INFO - 2023-09-22 14:30:14 --> Utf8 Class Initialized
INFO - 2023-09-22 14:30:14 --> URI Class Initialized
INFO - 2023-09-22 14:30:14 --> Router Class Initialized
INFO - 2023-09-22 14:30:14 --> Output Class Initialized
INFO - 2023-09-22 14:30:14 --> Security Class Initialized
DEBUG - 2023-09-22 14:30:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-22 14:30:14 --> Input Class Initialized
INFO - 2023-09-22 14:30:14 --> Language Class Initialized
INFO - 2023-09-22 14:30:14 --> Language Class Initialized
INFO - 2023-09-22 14:30:14 --> Config Class Initialized
INFO - 2023-09-22 14:30:14 --> Loader Class Initialized
INFO - 2023-09-22 14:30:14 --> Helper loaded: url_helper
INFO - 2023-09-22 14:30:14 --> Helper loaded: file_helper
INFO - 2023-09-22 14:30:14 --> Helper loaded: form_helper
INFO - 2023-09-22 14:30:14 --> Helper loaded: my_helper
INFO - 2023-09-22 14:30:14 --> Database Driver Class Initialized
INFO - 2023-09-22 14:30:14 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-22 14:30:14 --> Controller Class Initialized
INFO - 2023-09-22 14:30:16 --> Config Class Initialized
INFO - 2023-09-22 14:30:16 --> Hooks Class Initialized
DEBUG - 2023-09-22 14:30:16 --> UTF-8 Support Enabled
INFO - 2023-09-22 14:30:16 --> Utf8 Class Initialized
INFO - 2023-09-22 14:30:16 --> URI Class Initialized
INFO - 2023-09-22 14:30:16 --> Router Class Initialized
INFO - 2023-09-22 14:30:16 --> Output Class Initialized
INFO - 2023-09-22 14:30:16 --> Security Class Initialized
DEBUG - 2023-09-22 14:30:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-22 14:30:16 --> Input Class Initialized
INFO - 2023-09-22 14:30:16 --> Language Class Initialized
INFO - 2023-09-22 14:30:16 --> Language Class Initialized
INFO - 2023-09-22 14:30:16 --> Config Class Initialized
INFO - 2023-09-22 14:30:16 --> Loader Class Initialized
INFO - 2023-09-22 14:30:16 --> Helper loaded: url_helper
INFO - 2023-09-22 14:30:16 --> Helper loaded: file_helper
INFO - 2023-09-22 14:30:16 --> Helper loaded: form_helper
INFO - 2023-09-22 14:30:16 --> Helper loaded: my_helper
INFO - 2023-09-22 14:30:16 --> Database Driver Class Initialized
INFO - 2023-09-22 14:30:16 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-22 14:30:16 --> Controller Class Initialized
INFO - 2023-09-22 14:30:16 --> Final output sent to browser
DEBUG - 2023-09-22 14:30:16 --> Total execution time: 0.0345
INFO - 2023-09-22 14:30:16 --> Config Class Initialized
INFO - 2023-09-22 14:30:16 --> Hooks Class Initialized
DEBUG - 2023-09-22 14:30:16 --> UTF-8 Support Enabled
INFO - 2023-09-22 14:30:16 --> Utf8 Class Initialized
INFO - 2023-09-22 14:30:16 --> URI Class Initialized
INFO - 2023-09-22 14:30:16 --> Router Class Initialized
INFO - 2023-09-22 14:30:16 --> Output Class Initialized
INFO - 2023-09-22 14:30:16 --> Security Class Initialized
DEBUG - 2023-09-22 14:30:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-22 14:30:16 --> Input Class Initialized
INFO - 2023-09-22 14:30:16 --> Language Class Initialized
INFO - 2023-09-22 14:30:16 --> Language Class Initialized
INFO - 2023-09-22 14:30:16 --> Config Class Initialized
INFO - 2023-09-22 14:30:16 --> Loader Class Initialized
INFO - 2023-09-22 14:30:16 --> Helper loaded: url_helper
INFO - 2023-09-22 14:30:16 --> Helper loaded: file_helper
INFO - 2023-09-22 14:30:16 --> Helper loaded: form_helper
INFO - 2023-09-22 14:30:16 --> Helper loaded: my_helper
INFO - 2023-09-22 14:30:16 --> Database Driver Class Initialized
INFO - 2023-09-22 14:30:16 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-22 14:30:16 --> Controller Class Initialized
INFO - 2023-09-22 14:30:20 --> Config Class Initialized
INFO - 2023-09-22 14:30:20 --> Hooks Class Initialized
DEBUG - 2023-09-22 14:30:20 --> UTF-8 Support Enabled
INFO - 2023-09-22 14:30:20 --> Utf8 Class Initialized
INFO - 2023-09-22 14:30:20 --> URI Class Initialized
INFO - 2023-09-22 14:30:20 --> Router Class Initialized
INFO - 2023-09-22 14:30:20 --> Output Class Initialized
INFO - 2023-09-22 14:30:20 --> Security Class Initialized
DEBUG - 2023-09-22 14:30:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-22 14:30:20 --> Input Class Initialized
INFO - 2023-09-22 14:30:20 --> Language Class Initialized
INFO - 2023-09-22 14:30:20 --> Language Class Initialized
INFO - 2023-09-22 14:30:20 --> Config Class Initialized
INFO - 2023-09-22 14:30:20 --> Loader Class Initialized
INFO - 2023-09-22 14:30:20 --> Helper loaded: url_helper
INFO - 2023-09-22 14:30:20 --> Helper loaded: file_helper
INFO - 2023-09-22 14:30:20 --> Helper loaded: form_helper
INFO - 2023-09-22 14:30:20 --> Helper loaded: my_helper
INFO - 2023-09-22 14:30:20 --> Database Driver Class Initialized
INFO - 2023-09-22 14:30:20 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-22 14:30:20 --> Controller Class Initialized
INFO - 2023-09-22 14:30:20 --> Final output sent to browser
DEBUG - 2023-09-22 14:30:20 --> Total execution time: 0.0370
INFO - 2023-09-22 14:30:21 --> Config Class Initialized
INFO - 2023-09-22 14:30:21 --> Hooks Class Initialized
DEBUG - 2023-09-22 14:30:21 --> UTF-8 Support Enabled
INFO - 2023-09-22 14:30:21 --> Utf8 Class Initialized
INFO - 2023-09-22 14:30:21 --> URI Class Initialized
INFO - 2023-09-22 14:30:21 --> Router Class Initialized
INFO - 2023-09-22 14:30:21 --> Output Class Initialized
INFO - 2023-09-22 14:30:21 --> Security Class Initialized
DEBUG - 2023-09-22 14:30:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-22 14:30:21 --> Input Class Initialized
INFO - 2023-09-22 14:30:21 --> Language Class Initialized
INFO - 2023-09-22 14:30:21 --> Language Class Initialized
INFO - 2023-09-22 14:30:21 --> Config Class Initialized
INFO - 2023-09-22 14:30:21 --> Loader Class Initialized
INFO - 2023-09-22 14:30:21 --> Helper loaded: url_helper
INFO - 2023-09-22 14:30:21 --> Helper loaded: file_helper
INFO - 2023-09-22 14:30:21 --> Helper loaded: form_helper
INFO - 2023-09-22 14:30:21 --> Helper loaded: my_helper
INFO - 2023-09-22 14:30:21 --> Database Driver Class Initialized
INFO - 2023-09-22 14:30:21 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-22 14:30:21 --> Controller Class Initialized
INFO - 2023-09-22 14:30:21 --> Config Class Initialized
INFO - 2023-09-22 14:30:21 --> Hooks Class Initialized
DEBUG - 2023-09-22 14:30:21 --> UTF-8 Support Enabled
INFO - 2023-09-22 14:30:21 --> Utf8 Class Initialized
INFO - 2023-09-22 14:30:21 --> URI Class Initialized
INFO - 2023-09-22 14:30:21 --> Router Class Initialized
INFO - 2023-09-22 14:30:21 --> Output Class Initialized
INFO - 2023-09-22 14:30:21 --> Security Class Initialized
DEBUG - 2023-09-22 14:30:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-22 14:30:21 --> Input Class Initialized
INFO - 2023-09-22 14:30:21 --> Language Class Initialized
INFO - 2023-09-22 14:30:21 --> Language Class Initialized
INFO - 2023-09-22 14:30:21 --> Config Class Initialized
INFO - 2023-09-22 14:30:21 --> Loader Class Initialized
INFO - 2023-09-22 14:30:21 --> Helper loaded: url_helper
INFO - 2023-09-22 14:30:21 --> Helper loaded: file_helper
INFO - 2023-09-22 14:30:21 --> Helper loaded: form_helper
INFO - 2023-09-22 14:30:21 --> Helper loaded: my_helper
INFO - 2023-09-22 14:30:21 --> Database Driver Class Initialized
INFO - 2023-09-22 14:30:21 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-22 14:30:21 --> Controller Class Initialized
INFO - 2023-09-22 14:30:21 --> Final output sent to browser
DEBUG - 2023-09-22 14:30:21 --> Total execution time: 0.0451
INFO - 2023-09-22 14:30:22 --> Config Class Initialized
INFO - 2023-09-22 14:30:22 --> Hooks Class Initialized
DEBUG - 2023-09-22 14:30:22 --> UTF-8 Support Enabled
INFO - 2023-09-22 14:30:22 --> Utf8 Class Initialized
INFO - 2023-09-22 14:30:22 --> URI Class Initialized
INFO - 2023-09-22 14:30:22 --> Router Class Initialized
INFO - 2023-09-22 14:30:22 --> Output Class Initialized
INFO - 2023-09-22 14:30:22 --> Security Class Initialized
DEBUG - 2023-09-22 14:30:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-22 14:30:22 --> Input Class Initialized
INFO - 2023-09-22 14:30:22 --> Language Class Initialized
INFO - 2023-09-22 14:30:22 --> Language Class Initialized
INFO - 2023-09-22 14:30:22 --> Config Class Initialized
INFO - 2023-09-22 14:30:22 --> Loader Class Initialized
INFO - 2023-09-22 14:30:22 --> Helper loaded: url_helper
INFO - 2023-09-22 14:30:22 --> Helper loaded: file_helper
INFO - 2023-09-22 14:30:22 --> Helper loaded: form_helper
INFO - 2023-09-22 14:30:22 --> Helper loaded: my_helper
INFO - 2023-09-22 14:30:22 --> Database Driver Class Initialized
INFO - 2023-09-22 14:30:22 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-22 14:30:22 --> Controller Class Initialized
INFO - 2023-09-22 14:30:22 --> Config Class Initialized
INFO - 2023-09-22 14:30:22 --> Hooks Class Initialized
DEBUG - 2023-09-22 14:30:22 --> UTF-8 Support Enabled
INFO - 2023-09-22 14:30:22 --> Utf8 Class Initialized
INFO - 2023-09-22 14:30:22 --> URI Class Initialized
INFO - 2023-09-22 14:30:22 --> Router Class Initialized
INFO - 2023-09-22 14:30:22 --> Output Class Initialized
INFO - 2023-09-22 14:30:22 --> Security Class Initialized
DEBUG - 2023-09-22 14:30:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-22 14:30:22 --> Input Class Initialized
INFO - 2023-09-22 14:30:22 --> Language Class Initialized
INFO - 2023-09-22 14:30:22 --> Language Class Initialized
INFO - 2023-09-22 14:30:22 --> Config Class Initialized
INFO - 2023-09-22 14:30:22 --> Loader Class Initialized
INFO - 2023-09-22 14:30:22 --> Helper loaded: url_helper
INFO - 2023-09-22 14:30:22 --> Helper loaded: file_helper
INFO - 2023-09-22 14:30:22 --> Helper loaded: form_helper
INFO - 2023-09-22 14:30:22 --> Helper loaded: my_helper
INFO - 2023-09-22 14:30:22 --> Database Driver Class Initialized
INFO - 2023-09-22 14:30:22 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-22 14:30:22 --> Controller Class Initialized
INFO - 2023-09-22 14:30:22 --> Final output sent to browser
DEBUG - 2023-09-22 14:30:22 --> Total execution time: 0.0421
INFO - 2023-09-22 14:30:23 --> Config Class Initialized
INFO - 2023-09-22 14:30:23 --> Hooks Class Initialized
DEBUG - 2023-09-22 14:30:23 --> UTF-8 Support Enabled
INFO - 2023-09-22 14:30:23 --> Utf8 Class Initialized
INFO - 2023-09-22 14:30:23 --> URI Class Initialized
INFO - 2023-09-22 14:30:23 --> Router Class Initialized
INFO - 2023-09-22 14:30:23 --> Output Class Initialized
INFO - 2023-09-22 14:30:23 --> Security Class Initialized
DEBUG - 2023-09-22 14:30:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-22 14:30:23 --> Input Class Initialized
INFO - 2023-09-22 14:30:23 --> Language Class Initialized
INFO - 2023-09-22 14:30:23 --> Language Class Initialized
INFO - 2023-09-22 14:30:23 --> Config Class Initialized
INFO - 2023-09-22 14:30:23 --> Loader Class Initialized
INFO - 2023-09-22 14:30:23 --> Helper loaded: url_helper
INFO - 2023-09-22 14:30:23 --> Helper loaded: file_helper
INFO - 2023-09-22 14:30:23 --> Helper loaded: form_helper
INFO - 2023-09-22 14:30:23 --> Helper loaded: my_helper
INFO - 2023-09-22 14:30:23 --> Database Driver Class Initialized
INFO - 2023-09-22 14:30:23 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-22 14:30:23 --> Controller Class Initialized
INFO - 2023-09-22 14:30:24 --> Config Class Initialized
INFO - 2023-09-22 14:30:24 --> Hooks Class Initialized
DEBUG - 2023-09-22 14:30:24 --> UTF-8 Support Enabled
INFO - 2023-09-22 14:30:24 --> Utf8 Class Initialized
INFO - 2023-09-22 14:30:24 --> URI Class Initialized
INFO - 2023-09-22 14:30:24 --> Router Class Initialized
INFO - 2023-09-22 14:30:24 --> Output Class Initialized
INFO - 2023-09-22 14:30:24 --> Security Class Initialized
DEBUG - 2023-09-22 14:30:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-22 14:30:24 --> Input Class Initialized
INFO - 2023-09-22 14:30:24 --> Language Class Initialized
INFO - 2023-09-22 14:30:24 --> Language Class Initialized
INFO - 2023-09-22 14:30:24 --> Config Class Initialized
INFO - 2023-09-22 14:30:24 --> Loader Class Initialized
INFO - 2023-09-22 14:30:24 --> Helper loaded: url_helper
INFO - 2023-09-22 14:30:24 --> Helper loaded: file_helper
INFO - 2023-09-22 14:30:24 --> Helper loaded: form_helper
INFO - 2023-09-22 14:30:24 --> Helper loaded: my_helper
INFO - 2023-09-22 14:30:24 --> Database Driver Class Initialized
INFO - 2023-09-22 14:30:24 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-22 14:30:24 --> Controller Class Initialized
INFO - 2023-09-22 14:30:24 --> Final output sent to browser
DEBUG - 2023-09-22 14:30:24 --> Total execution time: 0.0319
INFO - 2023-09-22 14:30:25 --> Config Class Initialized
INFO - 2023-09-22 14:30:25 --> Hooks Class Initialized
DEBUG - 2023-09-22 14:30:25 --> UTF-8 Support Enabled
INFO - 2023-09-22 14:30:25 --> Utf8 Class Initialized
INFO - 2023-09-22 14:30:25 --> URI Class Initialized
INFO - 2023-09-22 14:30:25 --> Router Class Initialized
INFO - 2023-09-22 14:30:25 --> Output Class Initialized
INFO - 2023-09-22 14:30:25 --> Security Class Initialized
DEBUG - 2023-09-22 14:30:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-22 14:30:25 --> Input Class Initialized
INFO - 2023-09-22 14:30:25 --> Language Class Initialized
INFO - 2023-09-22 14:30:25 --> Language Class Initialized
INFO - 2023-09-22 14:30:25 --> Config Class Initialized
INFO - 2023-09-22 14:30:25 --> Loader Class Initialized
INFO - 2023-09-22 14:30:25 --> Helper loaded: url_helper
INFO - 2023-09-22 14:30:25 --> Helper loaded: file_helper
INFO - 2023-09-22 14:30:25 --> Helper loaded: form_helper
INFO - 2023-09-22 14:30:25 --> Helper loaded: my_helper
INFO - 2023-09-22 14:30:25 --> Database Driver Class Initialized
INFO - 2023-09-22 14:30:25 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-22 14:30:25 --> Controller Class Initialized
INFO - 2023-09-22 14:30:26 --> Config Class Initialized
INFO - 2023-09-22 14:30:26 --> Hooks Class Initialized
DEBUG - 2023-09-22 14:30:26 --> UTF-8 Support Enabled
INFO - 2023-09-22 14:30:26 --> Utf8 Class Initialized
INFO - 2023-09-22 14:30:26 --> URI Class Initialized
INFO - 2023-09-22 14:30:26 --> Router Class Initialized
INFO - 2023-09-22 14:30:26 --> Output Class Initialized
INFO - 2023-09-22 14:30:26 --> Security Class Initialized
DEBUG - 2023-09-22 14:30:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-22 14:30:26 --> Input Class Initialized
INFO - 2023-09-22 14:30:26 --> Language Class Initialized
INFO - 2023-09-22 14:30:26 --> Language Class Initialized
INFO - 2023-09-22 14:30:26 --> Config Class Initialized
INFO - 2023-09-22 14:30:26 --> Loader Class Initialized
INFO - 2023-09-22 14:30:26 --> Helper loaded: url_helper
INFO - 2023-09-22 14:30:26 --> Helper loaded: file_helper
INFO - 2023-09-22 14:30:26 --> Helper loaded: form_helper
INFO - 2023-09-22 14:30:26 --> Helper loaded: my_helper
INFO - 2023-09-22 14:30:26 --> Database Driver Class Initialized
INFO - 2023-09-22 14:30:26 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-22 14:30:26 --> Controller Class Initialized
INFO - 2023-09-22 14:30:26 --> Final output sent to browser
DEBUG - 2023-09-22 14:30:26 --> Total execution time: 0.0394
INFO - 2023-09-22 14:30:26 --> Config Class Initialized
INFO - 2023-09-22 14:30:26 --> Hooks Class Initialized
DEBUG - 2023-09-22 14:30:26 --> UTF-8 Support Enabled
INFO - 2023-09-22 14:30:26 --> Utf8 Class Initialized
INFO - 2023-09-22 14:30:26 --> URI Class Initialized
INFO - 2023-09-22 14:30:26 --> Router Class Initialized
INFO - 2023-09-22 14:30:26 --> Output Class Initialized
INFO - 2023-09-22 14:30:26 --> Security Class Initialized
DEBUG - 2023-09-22 14:30:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-22 14:30:26 --> Input Class Initialized
INFO - 2023-09-22 14:30:26 --> Language Class Initialized
INFO - 2023-09-22 14:30:26 --> Language Class Initialized
INFO - 2023-09-22 14:30:26 --> Config Class Initialized
INFO - 2023-09-22 14:30:26 --> Loader Class Initialized
INFO - 2023-09-22 14:30:26 --> Helper loaded: url_helper
INFO - 2023-09-22 14:30:26 --> Helper loaded: file_helper
INFO - 2023-09-22 14:30:26 --> Helper loaded: form_helper
INFO - 2023-09-22 14:30:26 --> Helper loaded: my_helper
INFO - 2023-09-22 14:30:26 --> Database Driver Class Initialized
INFO - 2023-09-22 14:30:26 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-22 14:30:26 --> Controller Class Initialized
INFO - 2023-09-22 14:30:28 --> Config Class Initialized
INFO - 2023-09-22 14:30:28 --> Hooks Class Initialized
DEBUG - 2023-09-22 14:30:28 --> UTF-8 Support Enabled
INFO - 2023-09-22 14:30:28 --> Utf8 Class Initialized
INFO - 2023-09-22 14:30:28 --> URI Class Initialized
INFO - 2023-09-22 14:30:28 --> Router Class Initialized
INFO - 2023-09-22 14:30:28 --> Output Class Initialized
INFO - 2023-09-22 14:30:28 --> Security Class Initialized
DEBUG - 2023-09-22 14:30:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-22 14:30:28 --> Input Class Initialized
INFO - 2023-09-22 14:30:28 --> Language Class Initialized
INFO - 2023-09-22 14:30:28 --> Language Class Initialized
INFO - 2023-09-22 14:30:28 --> Config Class Initialized
INFO - 2023-09-22 14:30:28 --> Loader Class Initialized
INFO - 2023-09-22 14:30:28 --> Helper loaded: url_helper
INFO - 2023-09-22 14:30:28 --> Helper loaded: file_helper
INFO - 2023-09-22 14:30:28 --> Helper loaded: form_helper
INFO - 2023-09-22 14:30:28 --> Helper loaded: my_helper
INFO - 2023-09-22 14:30:28 --> Database Driver Class Initialized
INFO - 2023-09-22 14:30:28 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-22 14:30:28 --> Controller Class Initialized
INFO - 2023-09-22 14:30:28 --> Final output sent to browser
DEBUG - 2023-09-22 14:30:28 --> Total execution time: 0.0416
INFO - 2023-09-22 14:30:28 --> Config Class Initialized
INFO - 2023-09-22 14:30:28 --> Hooks Class Initialized
DEBUG - 2023-09-22 14:30:28 --> UTF-8 Support Enabled
INFO - 2023-09-22 14:30:28 --> Utf8 Class Initialized
INFO - 2023-09-22 14:30:28 --> URI Class Initialized
INFO - 2023-09-22 14:30:28 --> Router Class Initialized
INFO - 2023-09-22 14:30:28 --> Output Class Initialized
INFO - 2023-09-22 14:30:28 --> Security Class Initialized
DEBUG - 2023-09-22 14:30:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-22 14:30:28 --> Input Class Initialized
INFO - 2023-09-22 14:30:28 --> Language Class Initialized
INFO - 2023-09-22 14:30:28 --> Language Class Initialized
INFO - 2023-09-22 14:30:28 --> Config Class Initialized
INFO - 2023-09-22 14:30:28 --> Loader Class Initialized
INFO - 2023-09-22 14:30:28 --> Helper loaded: url_helper
INFO - 2023-09-22 14:30:28 --> Helper loaded: file_helper
INFO - 2023-09-22 14:30:28 --> Helper loaded: form_helper
INFO - 2023-09-22 14:30:28 --> Helper loaded: my_helper
INFO - 2023-09-22 14:30:28 --> Database Driver Class Initialized
INFO - 2023-09-22 14:30:28 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-22 14:30:28 --> Controller Class Initialized
INFO - 2023-09-22 14:30:30 --> Config Class Initialized
INFO - 2023-09-22 14:30:30 --> Hooks Class Initialized
DEBUG - 2023-09-22 14:30:30 --> UTF-8 Support Enabled
INFO - 2023-09-22 14:30:30 --> Utf8 Class Initialized
INFO - 2023-09-22 14:30:30 --> URI Class Initialized
INFO - 2023-09-22 14:30:30 --> Router Class Initialized
INFO - 2023-09-22 14:30:30 --> Output Class Initialized
INFO - 2023-09-22 14:30:30 --> Security Class Initialized
DEBUG - 2023-09-22 14:30:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-22 14:30:30 --> Input Class Initialized
INFO - 2023-09-22 14:30:30 --> Language Class Initialized
INFO - 2023-09-22 14:30:30 --> Language Class Initialized
INFO - 2023-09-22 14:30:30 --> Config Class Initialized
INFO - 2023-09-22 14:30:30 --> Loader Class Initialized
INFO - 2023-09-22 14:30:30 --> Helper loaded: url_helper
INFO - 2023-09-22 14:30:30 --> Helper loaded: file_helper
INFO - 2023-09-22 14:30:30 --> Helper loaded: form_helper
INFO - 2023-09-22 14:30:30 --> Helper loaded: my_helper
INFO - 2023-09-22 14:30:30 --> Database Driver Class Initialized
INFO - 2023-09-22 14:30:30 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-22 14:30:30 --> Controller Class Initialized
INFO - 2023-09-22 14:30:30 --> Final output sent to browser
DEBUG - 2023-09-22 14:30:30 --> Total execution time: 0.0436
INFO - 2023-09-22 14:30:30 --> Config Class Initialized
INFO - 2023-09-22 14:30:30 --> Hooks Class Initialized
DEBUG - 2023-09-22 14:30:30 --> UTF-8 Support Enabled
INFO - 2023-09-22 14:30:30 --> Utf8 Class Initialized
INFO - 2023-09-22 14:30:30 --> URI Class Initialized
INFO - 2023-09-22 14:30:30 --> Router Class Initialized
INFO - 2023-09-22 14:30:30 --> Output Class Initialized
INFO - 2023-09-22 14:30:30 --> Security Class Initialized
DEBUG - 2023-09-22 14:30:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-22 14:30:30 --> Input Class Initialized
INFO - 2023-09-22 14:30:30 --> Language Class Initialized
INFO - 2023-09-22 14:30:30 --> Language Class Initialized
INFO - 2023-09-22 14:30:30 --> Config Class Initialized
INFO - 2023-09-22 14:30:30 --> Loader Class Initialized
INFO - 2023-09-22 14:30:30 --> Helper loaded: url_helper
INFO - 2023-09-22 14:30:30 --> Helper loaded: file_helper
INFO - 2023-09-22 14:30:30 --> Helper loaded: form_helper
INFO - 2023-09-22 14:30:30 --> Helper loaded: my_helper
INFO - 2023-09-22 14:30:30 --> Database Driver Class Initialized
INFO - 2023-09-22 14:30:30 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-22 14:30:30 --> Controller Class Initialized
INFO - 2023-09-22 14:30:32 --> Config Class Initialized
INFO - 2023-09-22 14:30:32 --> Hooks Class Initialized
DEBUG - 2023-09-22 14:30:32 --> UTF-8 Support Enabled
INFO - 2023-09-22 14:30:32 --> Utf8 Class Initialized
INFO - 2023-09-22 14:30:32 --> URI Class Initialized
INFO - 2023-09-22 14:30:32 --> Router Class Initialized
INFO - 2023-09-22 14:30:32 --> Output Class Initialized
INFO - 2023-09-22 14:30:32 --> Security Class Initialized
DEBUG - 2023-09-22 14:30:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-22 14:30:32 --> Input Class Initialized
INFO - 2023-09-22 14:30:32 --> Language Class Initialized
INFO - 2023-09-22 14:30:32 --> Language Class Initialized
INFO - 2023-09-22 14:30:32 --> Config Class Initialized
INFO - 2023-09-22 14:30:32 --> Loader Class Initialized
INFO - 2023-09-22 14:30:32 --> Helper loaded: url_helper
INFO - 2023-09-22 14:30:32 --> Helper loaded: file_helper
INFO - 2023-09-22 14:30:32 --> Helper loaded: form_helper
INFO - 2023-09-22 14:30:32 --> Helper loaded: my_helper
INFO - 2023-09-22 14:30:32 --> Database Driver Class Initialized
INFO - 2023-09-22 14:30:32 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-22 14:30:32 --> Controller Class Initialized
INFO - 2023-09-22 14:30:32 --> Final output sent to browser
DEBUG - 2023-09-22 14:30:32 --> Total execution time: 0.0450
INFO - 2023-09-22 14:30:32 --> Config Class Initialized
INFO - 2023-09-22 14:30:32 --> Hooks Class Initialized
DEBUG - 2023-09-22 14:30:32 --> UTF-8 Support Enabled
INFO - 2023-09-22 14:30:32 --> Utf8 Class Initialized
INFO - 2023-09-22 14:30:32 --> URI Class Initialized
INFO - 2023-09-22 14:30:32 --> Router Class Initialized
INFO - 2023-09-22 14:30:32 --> Output Class Initialized
INFO - 2023-09-22 14:30:32 --> Security Class Initialized
DEBUG - 2023-09-22 14:30:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-22 14:30:32 --> Input Class Initialized
INFO - 2023-09-22 14:30:32 --> Language Class Initialized
INFO - 2023-09-22 14:30:32 --> Language Class Initialized
INFO - 2023-09-22 14:30:32 --> Config Class Initialized
INFO - 2023-09-22 14:30:32 --> Loader Class Initialized
INFO - 2023-09-22 14:30:32 --> Helper loaded: url_helper
INFO - 2023-09-22 14:30:32 --> Helper loaded: file_helper
INFO - 2023-09-22 14:30:32 --> Helper loaded: form_helper
INFO - 2023-09-22 14:30:32 --> Helper loaded: my_helper
INFO - 2023-09-22 14:30:32 --> Database Driver Class Initialized
INFO - 2023-09-22 14:30:32 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-22 14:30:32 --> Controller Class Initialized
INFO - 2023-09-22 14:30:34 --> Config Class Initialized
INFO - 2023-09-22 14:30:34 --> Hooks Class Initialized
DEBUG - 2023-09-22 14:30:34 --> UTF-8 Support Enabled
INFO - 2023-09-22 14:30:34 --> Utf8 Class Initialized
INFO - 2023-09-22 14:30:34 --> URI Class Initialized
INFO - 2023-09-22 14:30:34 --> Router Class Initialized
INFO - 2023-09-22 14:30:34 --> Output Class Initialized
INFO - 2023-09-22 14:30:34 --> Security Class Initialized
DEBUG - 2023-09-22 14:30:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-22 14:30:34 --> Input Class Initialized
INFO - 2023-09-22 14:30:34 --> Language Class Initialized
INFO - 2023-09-22 14:30:34 --> Language Class Initialized
INFO - 2023-09-22 14:30:34 --> Config Class Initialized
INFO - 2023-09-22 14:30:34 --> Loader Class Initialized
INFO - 2023-09-22 14:30:34 --> Helper loaded: url_helper
INFO - 2023-09-22 14:30:34 --> Helper loaded: file_helper
INFO - 2023-09-22 14:30:34 --> Helper loaded: form_helper
INFO - 2023-09-22 14:30:34 --> Helper loaded: my_helper
INFO - 2023-09-22 14:30:34 --> Database Driver Class Initialized
INFO - 2023-09-22 14:30:34 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-22 14:30:34 --> Controller Class Initialized
INFO - 2023-09-22 14:30:34 --> Final output sent to browser
DEBUG - 2023-09-22 14:30:34 --> Total execution time: 0.0366
INFO - 2023-09-22 14:30:34 --> Config Class Initialized
INFO - 2023-09-22 14:30:34 --> Hooks Class Initialized
DEBUG - 2023-09-22 14:30:34 --> UTF-8 Support Enabled
INFO - 2023-09-22 14:30:34 --> Utf8 Class Initialized
INFO - 2023-09-22 14:30:34 --> URI Class Initialized
INFO - 2023-09-22 14:30:34 --> Router Class Initialized
INFO - 2023-09-22 14:30:34 --> Output Class Initialized
INFO - 2023-09-22 14:30:34 --> Security Class Initialized
DEBUG - 2023-09-22 14:30:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-22 14:30:34 --> Input Class Initialized
INFO - 2023-09-22 14:30:34 --> Language Class Initialized
INFO - 2023-09-22 14:30:34 --> Language Class Initialized
INFO - 2023-09-22 14:30:34 --> Config Class Initialized
INFO - 2023-09-22 14:30:34 --> Loader Class Initialized
INFO - 2023-09-22 14:30:34 --> Helper loaded: url_helper
INFO - 2023-09-22 14:30:34 --> Helper loaded: file_helper
INFO - 2023-09-22 14:30:34 --> Helper loaded: form_helper
INFO - 2023-09-22 14:30:34 --> Helper loaded: my_helper
INFO - 2023-09-22 14:30:34 --> Database Driver Class Initialized
INFO - 2023-09-22 14:30:34 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-22 14:30:34 --> Controller Class Initialized
INFO - 2023-09-22 14:30:36 --> Config Class Initialized
INFO - 2023-09-22 14:30:36 --> Hooks Class Initialized
DEBUG - 2023-09-22 14:30:36 --> UTF-8 Support Enabled
INFO - 2023-09-22 14:30:36 --> Utf8 Class Initialized
INFO - 2023-09-22 14:30:36 --> URI Class Initialized
INFO - 2023-09-22 14:30:36 --> Router Class Initialized
INFO - 2023-09-22 14:30:36 --> Output Class Initialized
INFO - 2023-09-22 14:30:36 --> Security Class Initialized
DEBUG - 2023-09-22 14:30:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-22 14:30:36 --> Input Class Initialized
INFO - 2023-09-22 14:30:36 --> Language Class Initialized
INFO - 2023-09-22 14:30:36 --> Language Class Initialized
INFO - 2023-09-22 14:30:36 --> Config Class Initialized
INFO - 2023-09-22 14:30:36 --> Loader Class Initialized
INFO - 2023-09-22 14:30:36 --> Helper loaded: url_helper
INFO - 2023-09-22 14:30:36 --> Helper loaded: file_helper
INFO - 2023-09-22 14:30:36 --> Helper loaded: form_helper
INFO - 2023-09-22 14:30:36 --> Helper loaded: my_helper
INFO - 2023-09-22 14:30:36 --> Database Driver Class Initialized
INFO - 2023-09-22 14:30:36 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-22 14:30:36 --> Controller Class Initialized
INFO - 2023-09-22 14:30:36 --> Final output sent to browser
DEBUG - 2023-09-22 14:30:36 --> Total execution time: 0.0723
INFO - 2023-09-22 14:30:36 --> Config Class Initialized
INFO - 2023-09-22 14:30:36 --> Hooks Class Initialized
DEBUG - 2023-09-22 14:30:36 --> UTF-8 Support Enabled
INFO - 2023-09-22 14:30:36 --> Utf8 Class Initialized
INFO - 2023-09-22 14:30:36 --> URI Class Initialized
INFO - 2023-09-22 14:30:36 --> Router Class Initialized
INFO - 2023-09-22 14:30:36 --> Output Class Initialized
INFO - 2023-09-22 14:30:36 --> Security Class Initialized
DEBUG - 2023-09-22 14:30:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-22 14:30:36 --> Input Class Initialized
INFO - 2023-09-22 14:30:36 --> Language Class Initialized
INFO - 2023-09-22 14:30:36 --> Language Class Initialized
INFO - 2023-09-22 14:30:36 --> Config Class Initialized
INFO - 2023-09-22 14:30:36 --> Loader Class Initialized
INFO - 2023-09-22 14:30:36 --> Helper loaded: url_helper
INFO - 2023-09-22 14:30:36 --> Helper loaded: file_helper
INFO - 2023-09-22 14:30:36 --> Helper loaded: form_helper
INFO - 2023-09-22 14:30:36 --> Helper loaded: my_helper
INFO - 2023-09-22 14:30:36 --> Database Driver Class Initialized
INFO - 2023-09-22 14:30:36 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-22 14:30:36 --> Controller Class Initialized
INFO - 2023-09-22 14:30:38 --> Config Class Initialized
INFO - 2023-09-22 14:30:38 --> Hooks Class Initialized
DEBUG - 2023-09-22 14:30:38 --> UTF-8 Support Enabled
INFO - 2023-09-22 14:30:38 --> Utf8 Class Initialized
INFO - 2023-09-22 14:30:38 --> URI Class Initialized
INFO - 2023-09-22 14:30:38 --> Router Class Initialized
INFO - 2023-09-22 14:30:38 --> Output Class Initialized
INFO - 2023-09-22 14:30:38 --> Security Class Initialized
DEBUG - 2023-09-22 14:30:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-22 14:30:38 --> Input Class Initialized
INFO - 2023-09-22 14:30:38 --> Language Class Initialized
INFO - 2023-09-22 14:30:38 --> Language Class Initialized
INFO - 2023-09-22 14:30:38 --> Config Class Initialized
INFO - 2023-09-22 14:30:38 --> Loader Class Initialized
INFO - 2023-09-22 14:30:38 --> Helper loaded: url_helper
INFO - 2023-09-22 14:30:38 --> Helper loaded: file_helper
INFO - 2023-09-22 14:30:38 --> Helper loaded: form_helper
INFO - 2023-09-22 14:30:38 --> Helper loaded: my_helper
INFO - 2023-09-22 14:30:38 --> Database Driver Class Initialized
INFO - 2023-09-22 14:30:38 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-22 14:30:38 --> Controller Class Initialized
INFO - 2023-09-22 14:30:38 --> Final output sent to browser
DEBUG - 2023-09-22 14:30:38 --> Total execution time: 0.0431
INFO - 2023-09-22 14:30:38 --> Config Class Initialized
INFO - 2023-09-22 14:30:38 --> Hooks Class Initialized
DEBUG - 2023-09-22 14:30:38 --> UTF-8 Support Enabled
INFO - 2023-09-22 14:30:38 --> Utf8 Class Initialized
INFO - 2023-09-22 14:30:38 --> URI Class Initialized
INFO - 2023-09-22 14:30:39 --> Router Class Initialized
INFO - 2023-09-22 14:30:39 --> Output Class Initialized
INFO - 2023-09-22 14:30:39 --> Security Class Initialized
DEBUG - 2023-09-22 14:30:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-22 14:30:39 --> Input Class Initialized
INFO - 2023-09-22 14:30:39 --> Language Class Initialized
INFO - 2023-09-22 14:30:39 --> Language Class Initialized
INFO - 2023-09-22 14:30:39 --> Config Class Initialized
INFO - 2023-09-22 14:30:39 --> Loader Class Initialized
INFO - 2023-09-22 14:30:39 --> Helper loaded: url_helper
INFO - 2023-09-22 14:30:39 --> Helper loaded: file_helper
INFO - 2023-09-22 14:30:39 --> Helper loaded: form_helper
INFO - 2023-09-22 14:30:39 --> Helper loaded: my_helper
INFO - 2023-09-22 14:30:39 --> Database Driver Class Initialized
INFO - 2023-09-22 14:30:39 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-22 14:30:39 --> Controller Class Initialized
INFO - 2023-09-22 14:30:41 --> Config Class Initialized
INFO - 2023-09-22 14:30:41 --> Hooks Class Initialized
DEBUG - 2023-09-22 14:30:41 --> UTF-8 Support Enabled
INFO - 2023-09-22 14:30:41 --> Utf8 Class Initialized
INFO - 2023-09-22 14:30:41 --> URI Class Initialized
INFO - 2023-09-22 14:30:41 --> Router Class Initialized
INFO - 2023-09-22 14:30:41 --> Output Class Initialized
INFO - 2023-09-22 14:30:41 --> Security Class Initialized
DEBUG - 2023-09-22 14:30:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-22 14:30:41 --> Input Class Initialized
INFO - 2023-09-22 14:30:41 --> Language Class Initialized
INFO - 2023-09-22 14:30:41 --> Language Class Initialized
INFO - 2023-09-22 14:30:41 --> Config Class Initialized
INFO - 2023-09-22 14:30:41 --> Loader Class Initialized
INFO - 2023-09-22 14:30:41 --> Helper loaded: url_helper
INFO - 2023-09-22 14:30:41 --> Helper loaded: file_helper
INFO - 2023-09-22 14:30:41 --> Helper loaded: form_helper
INFO - 2023-09-22 14:30:41 --> Helper loaded: my_helper
INFO - 2023-09-22 14:30:41 --> Database Driver Class Initialized
INFO - 2023-09-22 14:30:41 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-22 14:30:41 --> Controller Class Initialized
INFO - 2023-09-22 14:30:41 --> Final output sent to browser
DEBUG - 2023-09-22 14:30:41 --> Total execution time: 0.0780
INFO - 2023-09-22 14:30:41 --> Config Class Initialized
INFO - 2023-09-22 14:30:41 --> Hooks Class Initialized
DEBUG - 2023-09-22 14:30:41 --> UTF-8 Support Enabled
INFO - 2023-09-22 14:30:41 --> Utf8 Class Initialized
INFO - 2023-09-22 14:30:41 --> URI Class Initialized
INFO - 2023-09-22 14:30:41 --> Router Class Initialized
INFO - 2023-09-22 14:30:41 --> Output Class Initialized
INFO - 2023-09-22 14:30:41 --> Security Class Initialized
DEBUG - 2023-09-22 14:30:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-22 14:30:41 --> Input Class Initialized
INFO - 2023-09-22 14:30:41 --> Language Class Initialized
INFO - 2023-09-22 14:30:41 --> Language Class Initialized
INFO - 2023-09-22 14:30:41 --> Config Class Initialized
INFO - 2023-09-22 14:30:41 --> Loader Class Initialized
INFO - 2023-09-22 14:30:41 --> Helper loaded: url_helper
INFO - 2023-09-22 14:30:41 --> Helper loaded: file_helper
INFO - 2023-09-22 14:30:41 --> Helper loaded: form_helper
INFO - 2023-09-22 14:30:41 --> Helper loaded: my_helper
INFO - 2023-09-22 14:30:41 --> Database Driver Class Initialized
INFO - 2023-09-22 14:30:41 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-22 14:30:41 --> Controller Class Initialized
INFO - 2023-09-22 14:30:43 --> Config Class Initialized
INFO - 2023-09-22 14:30:43 --> Hooks Class Initialized
DEBUG - 2023-09-22 14:30:43 --> UTF-8 Support Enabled
INFO - 2023-09-22 14:30:43 --> Utf8 Class Initialized
INFO - 2023-09-22 14:30:43 --> URI Class Initialized
INFO - 2023-09-22 14:30:43 --> Router Class Initialized
INFO - 2023-09-22 14:30:43 --> Output Class Initialized
INFO - 2023-09-22 14:30:43 --> Security Class Initialized
DEBUG - 2023-09-22 14:30:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-22 14:30:43 --> Input Class Initialized
INFO - 2023-09-22 14:30:43 --> Language Class Initialized
INFO - 2023-09-22 14:30:43 --> Language Class Initialized
INFO - 2023-09-22 14:30:43 --> Config Class Initialized
INFO - 2023-09-22 14:30:43 --> Loader Class Initialized
INFO - 2023-09-22 14:30:43 --> Helper loaded: url_helper
INFO - 2023-09-22 14:30:43 --> Helper loaded: file_helper
INFO - 2023-09-22 14:30:43 --> Helper loaded: form_helper
INFO - 2023-09-22 14:30:43 --> Helper loaded: my_helper
INFO - 2023-09-22 14:30:43 --> Database Driver Class Initialized
INFO - 2023-09-22 14:30:43 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-22 14:30:43 --> Controller Class Initialized
INFO - 2023-09-22 14:30:43 --> Final output sent to browser
DEBUG - 2023-09-22 14:30:43 --> Total execution time: 0.0440
INFO - 2023-09-22 14:30:43 --> Config Class Initialized
INFO - 2023-09-22 14:30:43 --> Hooks Class Initialized
DEBUG - 2023-09-22 14:30:43 --> UTF-8 Support Enabled
INFO - 2023-09-22 14:30:43 --> Utf8 Class Initialized
INFO - 2023-09-22 14:30:43 --> URI Class Initialized
INFO - 2023-09-22 14:30:43 --> Router Class Initialized
INFO - 2023-09-22 14:30:43 --> Output Class Initialized
INFO - 2023-09-22 14:30:43 --> Security Class Initialized
DEBUG - 2023-09-22 14:30:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-22 14:30:43 --> Input Class Initialized
INFO - 2023-09-22 14:30:43 --> Language Class Initialized
INFO - 2023-09-22 14:30:43 --> Language Class Initialized
INFO - 2023-09-22 14:30:43 --> Config Class Initialized
INFO - 2023-09-22 14:30:43 --> Loader Class Initialized
INFO - 2023-09-22 14:30:43 --> Helper loaded: url_helper
INFO - 2023-09-22 14:30:43 --> Helper loaded: file_helper
INFO - 2023-09-22 14:30:43 --> Helper loaded: form_helper
INFO - 2023-09-22 14:30:43 --> Helper loaded: my_helper
INFO - 2023-09-22 14:30:43 --> Database Driver Class Initialized
INFO - 2023-09-22 14:30:43 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-22 14:30:43 --> Controller Class Initialized
INFO - 2023-09-22 14:30:44 --> Config Class Initialized
INFO - 2023-09-22 14:30:44 --> Hooks Class Initialized
DEBUG - 2023-09-22 14:30:44 --> UTF-8 Support Enabled
INFO - 2023-09-22 14:30:44 --> Utf8 Class Initialized
INFO - 2023-09-22 14:30:44 --> URI Class Initialized
INFO - 2023-09-22 14:30:44 --> Router Class Initialized
INFO - 2023-09-22 14:30:44 --> Output Class Initialized
INFO - 2023-09-22 14:30:44 --> Security Class Initialized
DEBUG - 2023-09-22 14:30:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-22 14:30:44 --> Input Class Initialized
INFO - 2023-09-22 14:30:44 --> Language Class Initialized
INFO - 2023-09-22 14:30:44 --> Language Class Initialized
INFO - 2023-09-22 14:30:44 --> Config Class Initialized
INFO - 2023-09-22 14:30:44 --> Loader Class Initialized
INFO - 2023-09-22 14:30:44 --> Helper loaded: url_helper
INFO - 2023-09-22 14:30:44 --> Helper loaded: file_helper
INFO - 2023-09-22 14:30:44 --> Helper loaded: form_helper
INFO - 2023-09-22 14:30:44 --> Helper loaded: my_helper
INFO - 2023-09-22 14:30:44 --> Database Driver Class Initialized
INFO - 2023-09-22 14:30:44 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-22 14:30:44 --> Controller Class Initialized
INFO - 2023-09-22 14:30:44 --> Final output sent to browser
DEBUG - 2023-09-22 14:30:44 --> Total execution time: 0.0379
INFO - 2023-09-22 14:30:44 --> Config Class Initialized
INFO - 2023-09-22 14:30:44 --> Hooks Class Initialized
DEBUG - 2023-09-22 14:30:44 --> UTF-8 Support Enabled
INFO - 2023-09-22 14:30:44 --> Utf8 Class Initialized
INFO - 2023-09-22 14:30:44 --> URI Class Initialized
INFO - 2023-09-22 14:30:44 --> Router Class Initialized
INFO - 2023-09-22 14:30:44 --> Output Class Initialized
INFO - 2023-09-22 14:30:44 --> Security Class Initialized
DEBUG - 2023-09-22 14:30:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-22 14:30:44 --> Input Class Initialized
INFO - 2023-09-22 14:30:44 --> Language Class Initialized
INFO - 2023-09-22 14:30:44 --> Language Class Initialized
INFO - 2023-09-22 14:30:44 --> Config Class Initialized
INFO - 2023-09-22 14:30:44 --> Loader Class Initialized
INFO - 2023-09-22 14:30:44 --> Helper loaded: url_helper
INFO - 2023-09-22 14:30:44 --> Helper loaded: file_helper
INFO - 2023-09-22 14:30:44 --> Helper loaded: form_helper
INFO - 2023-09-22 14:30:44 --> Helper loaded: my_helper
INFO - 2023-09-22 14:30:44 --> Database Driver Class Initialized
INFO - 2023-09-22 14:30:44 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-22 14:30:44 --> Controller Class Initialized
INFO - 2023-09-22 14:30:48 --> Config Class Initialized
INFO - 2023-09-22 14:30:48 --> Hooks Class Initialized
DEBUG - 2023-09-22 14:30:48 --> UTF-8 Support Enabled
INFO - 2023-09-22 14:30:48 --> Utf8 Class Initialized
INFO - 2023-09-22 14:30:48 --> URI Class Initialized
INFO - 2023-09-22 14:30:49 --> Router Class Initialized
INFO - 2023-09-22 14:30:49 --> Output Class Initialized
INFO - 2023-09-22 14:30:49 --> Security Class Initialized
DEBUG - 2023-09-22 14:30:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-22 14:30:49 --> Input Class Initialized
INFO - 2023-09-22 14:30:49 --> Language Class Initialized
INFO - 2023-09-22 14:30:49 --> Language Class Initialized
INFO - 2023-09-22 14:30:49 --> Config Class Initialized
INFO - 2023-09-22 14:30:49 --> Loader Class Initialized
INFO - 2023-09-22 14:30:49 --> Helper loaded: url_helper
INFO - 2023-09-22 14:30:49 --> Helper loaded: file_helper
INFO - 2023-09-22 14:30:49 --> Helper loaded: form_helper
INFO - 2023-09-22 14:30:49 --> Helper loaded: my_helper
INFO - 2023-09-22 14:30:49 --> Database Driver Class Initialized
INFO - 2023-09-22 14:30:49 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-22 14:30:49 --> Controller Class Initialized
INFO - 2023-09-22 14:30:49 --> Final output sent to browser
DEBUG - 2023-09-22 14:30:49 --> Total execution time: 0.0897
INFO - 2023-09-22 14:30:49 --> Config Class Initialized
INFO - 2023-09-22 14:30:49 --> Hooks Class Initialized
DEBUG - 2023-09-22 14:30:49 --> UTF-8 Support Enabled
INFO - 2023-09-22 14:30:49 --> Utf8 Class Initialized
INFO - 2023-09-22 14:30:49 --> URI Class Initialized
INFO - 2023-09-22 14:30:49 --> Router Class Initialized
INFO - 2023-09-22 14:30:49 --> Output Class Initialized
INFO - 2023-09-22 14:30:49 --> Security Class Initialized
DEBUG - 2023-09-22 14:30:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-22 14:30:49 --> Input Class Initialized
INFO - 2023-09-22 14:30:49 --> Language Class Initialized
INFO - 2023-09-22 14:30:49 --> Language Class Initialized
INFO - 2023-09-22 14:30:49 --> Config Class Initialized
INFO - 2023-09-22 14:30:49 --> Loader Class Initialized
INFO - 2023-09-22 14:30:49 --> Helper loaded: url_helper
INFO - 2023-09-22 14:30:49 --> Helper loaded: file_helper
INFO - 2023-09-22 14:30:49 --> Helper loaded: form_helper
INFO - 2023-09-22 14:30:49 --> Helper loaded: my_helper
INFO - 2023-09-22 14:30:49 --> Database Driver Class Initialized
INFO - 2023-09-22 14:30:49 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-22 14:30:49 --> Controller Class Initialized
INFO - 2023-09-22 14:30:50 --> Config Class Initialized
INFO - 2023-09-22 14:30:50 --> Hooks Class Initialized
DEBUG - 2023-09-22 14:30:50 --> UTF-8 Support Enabled
INFO - 2023-09-22 14:30:50 --> Utf8 Class Initialized
INFO - 2023-09-22 14:30:50 --> URI Class Initialized
INFO - 2023-09-22 14:30:50 --> Router Class Initialized
INFO - 2023-09-22 14:30:50 --> Output Class Initialized
INFO - 2023-09-22 14:30:50 --> Security Class Initialized
DEBUG - 2023-09-22 14:30:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-22 14:30:50 --> Input Class Initialized
INFO - 2023-09-22 14:30:50 --> Language Class Initialized
INFO - 2023-09-22 14:30:50 --> Language Class Initialized
INFO - 2023-09-22 14:30:50 --> Config Class Initialized
INFO - 2023-09-22 14:30:50 --> Loader Class Initialized
INFO - 2023-09-22 14:30:50 --> Helper loaded: url_helper
INFO - 2023-09-22 14:30:50 --> Helper loaded: file_helper
INFO - 2023-09-22 14:30:50 --> Helper loaded: form_helper
INFO - 2023-09-22 14:30:50 --> Helper loaded: my_helper
INFO - 2023-09-22 14:30:50 --> Database Driver Class Initialized
INFO - 2023-09-22 14:30:50 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-22 14:30:50 --> Controller Class Initialized
INFO - 2023-09-22 14:30:50 --> Final output sent to browser
DEBUG - 2023-09-22 14:30:50 --> Total execution time: 0.1392
INFO - 2023-09-22 14:30:50 --> Config Class Initialized
INFO - 2023-09-22 14:30:50 --> Hooks Class Initialized
DEBUG - 2023-09-22 14:30:50 --> UTF-8 Support Enabled
INFO - 2023-09-22 14:30:50 --> Utf8 Class Initialized
INFO - 2023-09-22 14:30:50 --> URI Class Initialized
INFO - 2023-09-22 14:30:50 --> Router Class Initialized
INFO - 2023-09-22 14:30:50 --> Output Class Initialized
INFO - 2023-09-22 14:30:50 --> Security Class Initialized
DEBUG - 2023-09-22 14:30:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-22 14:30:50 --> Input Class Initialized
INFO - 2023-09-22 14:30:50 --> Language Class Initialized
INFO - 2023-09-22 14:30:50 --> Language Class Initialized
INFO - 2023-09-22 14:30:50 --> Config Class Initialized
INFO - 2023-09-22 14:30:50 --> Loader Class Initialized
INFO - 2023-09-22 14:30:50 --> Helper loaded: url_helper
INFO - 2023-09-22 14:30:50 --> Helper loaded: file_helper
INFO - 2023-09-22 14:30:50 --> Helper loaded: form_helper
INFO - 2023-09-22 14:30:50 --> Helper loaded: my_helper
INFO - 2023-09-22 14:30:50 --> Database Driver Class Initialized
INFO - 2023-09-22 14:30:50 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-22 14:30:50 --> Controller Class Initialized
INFO - 2023-09-22 14:30:52 --> Config Class Initialized
INFO - 2023-09-22 14:30:52 --> Hooks Class Initialized
DEBUG - 2023-09-22 14:30:52 --> UTF-8 Support Enabled
INFO - 2023-09-22 14:30:52 --> Utf8 Class Initialized
INFO - 2023-09-22 14:30:52 --> URI Class Initialized
INFO - 2023-09-22 14:30:52 --> Router Class Initialized
INFO - 2023-09-22 14:30:52 --> Output Class Initialized
INFO - 2023-09-22 14:30:52 --> Security Class Initialized
DEBUG - 2023-09-22 14:30:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-22 14:30:52 --> Input Class Initialized
INFO - 2023-09-22 14:30:52 --> Language Class Initialized
INFO - 2023-09-22 14:30:52 --> Language Class Initialized
INFO - 2023-09-22 14:30:52 --> Config Class Initialized
INFO - 2023-09-22 14:30:52 --> Loader Class Initialized
INFO - 2023-09-22 14:30:52 --> Helper loaded: url_helper
INFO - 2023-09-22 14:30:52 --> Helper loaded: file_helper
INFO - 2023-09-22 14:30:52 --> Helper loaded: form_helper
INFO - 2023-09-22 14:30:52 --> Helper loaded: my_helper
INFO - 2023-09-22 14:30:52 --> Database Driver Class Initialized
INFO - 2023-09-22 14:30:52 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-22 14:30:52 --> Controller Class Initialized
INFO - 2023-09-22 14:30:52 --> Final output sent to browser
DEBUG - 2023-09-22 14:30:52 --> Total execution time: 0.0453
INFO - 2023-09-22 14:30:52 --> Config Class Initialized
INFO - 2023-09-22 14:30:52 --> Hooks Class Initialized
DEBUG - 2023-09-22 14:30:52 --> UTF-8 Support Enabled
INFO - 2023-09-22 14:30:52 --> Utf8 Class Initialized
INFO - 2023-09-22 14:30:52 --> URI Class Initialized
INFO - 2023-09-22 14:30:52 --> Router Class Initialized
INFO - 2023-09-22 14:30:52 --> Output Class Initialized
INFO - 2023-09-22 14:30:52 --> Security Class Initialized
DEBUG - 2023-09-22 14:30:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-22 14:30:52 --> Input Class Initialized
INFO - 2023-09-22 14:30:52 --> Language Class Initialized
INFO - 2023-09-22 14:30:52 --> Language Class Initialized
INFO - 2023-09-22 14:30:52 --> Config Class Initialized
INFO - 2023-09-22 14:30:52 --> Loader Class Initialized
INFO - 2023-09-22 14:30:52 --> Helper loaded: url_helper
INFO - 2023-09-22 14:30:52 --> Helper loaded: file_helper
INFO - 2023-09-22 14:30:52 --> Helper loaded: form_helper
INFO - 2023-09-22 14:30:52 --> Helper loaded: my_helper
INFO - 2023-09-22 14:30:52 --> Database Driver Class Initialized
INFO - 2023-09-22 14:30:52 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-22 14:30:52 --> Controller Class Initialized
INFO - 2023-09-22 14:30:54 --> Config Class Initialized
INFO - 2023-09-22 14:30:54 --> Hooks Class Initialized
DEBUG - 2023-09-22 14:30:54 --> UTF-8 Support Enabled
INFO - 2023-09-22 14:30:54 --> Utf8 Class Initialized
INFO - 2023-09-22 14:30:54 --> URI Class Initialized
INFO - 2023-09-22 14:30:54 --> Router Class Initialized
INFO - 2023-09-22 14:30:54 --> Output Class Initialized
INFO - 2023-09-22 14:30:54 --> Security Class Initialized
DEBUG - 2023-09-22 14:30:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-22 14:30:54 --> Input Class Initialized
INFO - 2023-09-22 14:30:54 --> Language Class Initialized
INFO - 2023-09-22 14:30:54 --> Language Class Initialized
INFO - 2023-09-22 14:30:54 --> Config Class Initialized
INFO - 2023-09-22 14:30:54 --> Loader Class Initialized
INFO - 2023-09-22 14:30:54 --> Helper loaded: url_helper
INFO - 2023-09-22 14:30:54 --> Helper loaded: file_helper
INFO - 2023-09-22 14:30:54 --> Helper loaded: form_helper
INFO - 2023-09-22 14:30:54 --> Helper loaded: my_helper
INFO - 2023-09-22 14:30:54 --> Database Driver Class Initialized
INFO - 2023-09-22 14:30:54 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-22 14:30:54 --> Controller Class Initialized
INFO - 2023-09-22 14:30:54 --> Final output sent to browser
DEBUG - 2023-09-22 14:30:54 --> Total execution time: 0.0483
INFO - 2023-09-22 14:30:54 --> Config Class Initialized
INFO - 2023-09-22 14:30:54 --> Hooks Class Initialized
DEBUG - 2023-09-22 14:30:54 --> UTF-8 Support Enabled
INFO - 2023-09-22 14:30:54 --> Utf8 Class Initialized
INFO - 2023-09-22 14:30:54 --> URI Class Initialized
INFO - 2023-09-22 14:30:54 --> Router Class Initialized
INFO - 2023-09-22 14:30:54 --> Output Class Initialized
INFO - 2023-09-22 14:30:54 --> Security Class Initialized
DEBUG - 2023-09-22 14:30:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-22 14:30:54 --> Input Class Initialized
INFO - 2023-09-22 14:30:54 --> Language Class Initialized
INFO - 2023-09-22 14:30:54 --> Language Class Initialized
INFO - 2023-09-22 14:30:54 --> Config Class Initialized
INFO - 2023-09-22 14:30:54 --> Loader Class Initialized
INFO - 2023-09-22 14:30:54 --> Helper loaded: url_helper
INFO - 2023-09-22 14:30:54 --> Helper loaded: file_helper
INFO - 2023-09-22 14:30:54 --> Helper loaded: form_helper
INFO - 2023-09-22 14:30:54 --> Helper loaded: my_helper
INFO - 2023-09-22 14:30:54 --> Database Driver Class Initialized
INFO - 2023-09-22 14:30:54 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-22 14:30:54 --> Controller Class Initialized
INFO - 2023-09-22 14:31:03 --> Config Class Initialized
INFO - 2023-09-22 14:31:03 --> Hooks Class Initialized
DEBUG - 2023-09-22 14:31:03 --> UTF-8 Support Enabled
INFO - 2023-09-22 14:31:03 --> Utf8 Class Initialized
INFO - 2023-09-22 14:31:03 --> URI Class Initialized
INFO - 2023-09-22 14:31:03 --> Router Class Initialized
INFO - 2023-09-22 14:31:03 --> Output Class Initialized
INFO - 2023-09-22 14:31:03 --> Security Class Initialized
DEBUG - 2023-09-22 14:31:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-22 14:31:03 --> Input Class Initialized
INFO - 2023-09-22 14:31:03 --> Language Class Initialized
INFO - 2023-09-22 14:31:03 --> Language Class Initialized
INFO - 2023-09-22 14:31:03 --> Config Class Initialized
INFO - 2023-09-22 14:31:03 --> Loader Class Initialized
INFO - 2023-09-22 14:31:03 --> Helper loaded: url_helper
INFO - 2023-09-22 14:31:03 --> Helper loaded: file_helper
INFO - 2023-09-22 14:31:03 --> Helper loaded: form_helper
INFO - 2023-09-22 14:31:03 --> Helper loaded: my_helper
INFO - 2023-09-22 14:31:03 --> Database Driver Class Initialized
INFO - 2023-09-22 14:31:03 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-22 14:31:03 --> Controller Class Initialized
INFO - 2023-09-22 14:31:03 --> Final output sent to browser
DEBUG - 2023-09-22 14:31:03 --> Total execution time: 0.0458
INFO - 2023-09-22 14:31:03 --> Config Class Initialized
INFO - 2023-09-22 14:31:03 --> Hooks Class Initialized
DEBUG - 2023-09-22 14:31:03 --> UTF-8 Support Enabled
INFO - 2023-09-22 14:31:03 --> Utf8 Class Initialized
INFO - 2023-09-22 14:31:03 --> URI Class Initialized
INFO - 2023-09-22 14:31:03 --> Router Class Initialized
INFO - 2023-09-22 14:31:03 --> Output Class Initialized
INFO - 2023-09-22 14:31:03 --> Security Class Initialized
DEBUG - 2023-09-22 14:31:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-22 14:31:03 --> Input Class Initialized
INFO - 2023-09-22 14:31:03 --> Language Class Initialized
INFO - 2023-09-22 14:31:03 --> Language Class Initialized
INFO - 2023-09-22 14:31:03 --> Config Class Initialized
INFO - 2023-09-22 14:31:03 --> Loader Class Initialized
INFO - 2023-09-22 14:31:03 --> Helper loaded: url_helper
INFO - 2023-09-22 14:31:03 --> Helper loaded: file_helper
INFO - 2023-09-22 14:31:03 --> Helper loaded: form_helper
INFO - 2023-09-22 14:31:03 --> Helper loaded: my_helper
INFO - 2023-09-22 14:31:03 --> Database Driver Class Initialized
INFO - 2023-09-22 14:31:03 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-22 14:31:03 --> Controller Class Initialized
INFO - 2023-09-22 14:31:05 --> Config Class Initialized
INFO - 2023-09-22 14:31:05 --> Hooks Class Initialized
DEBUG - 2023-09-22 14:31:05 --> UTF-8 Support Enabled
INFO - 2023-09-22 14:31:05 --> Utf8 Class Initialized
INFO - 2023-09-22 14:31:05 --> URI Class Initialized
INFO - 2023-09-22 14:31:05 --> Router Class Initialized
INFO - 2023-09-22 14:31:05 --> Output Class Initialized
INFO - 2023-09-22 14:31:05 --> Security Class Initialized
DEBUG - 2023-09-22 14:31:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-22 14:31:05 --> Input Class Initialized
INFO - 2023-09-22 14:31:05 --> Language Class Initialized
INFO - 2023-09-22 14:31:05 --> Language Class Initialized
INFO - 2023-09-22 14:31:05 --> Config Class Initialized
INFO - 2023-09-22 14:31:05 --> Loader Class Initialized
INFO - 2023-09-22 14:31:05 --> Helper loaded: url_helper
INFO - 2023-09-22 14:31:05 --> Helper loaded: file_helper
INFO - 2023-09-22 14:31:05 --> Helper loaded: form_helper
INFO - 2023-09-22 14:31:05 --> Helper loaded: my_helper
INFO - 2023-09-22 14:31:05 --> Database Driver Class Initialized
INFO - 2023-09-22 14:31:05 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-22 14:31:05 --> Controller Class Initialized
INFO - 2023-09-22 14:31:05 --> Final output sent to browser
DEBUG - 2023-09-22 14:31:05 --> Total execution time: 0.1280
INFO - 2023-09-22 14:31:05 --> Config Class Initialized
INFO - 2023-09-22 14:31:05 --> Hooks Class Initialized
DEBUG - 2023-09-22 14:31:05 --> UTF-8 Support Enabled
INFO - 2023-09-22 14:31:05 --> Utf8 Class Initialized
INFO - 2023-09-22 14:31:05 --> URI Class Initialized
INFO - 2023-09-22 14:31:05 --> Router Class Initialized
INFO - 2023-09-22 14:31:05 --> Output Class Initialized
INFO - 2023-09-22 14:31:05 --> Security Class Initialized
DEBUG - 2023-09-22 14:31:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-22 14:31:05 --> Input Class Initialized
INFO - 2023-09-22 14:31:05 --> Language Class Initialized
INFO - 2023-09-22 14:31:05 --> Language Class Initialized
INFO - 2023-09-22 14:31:05 --> Config Class Initialized
INFO - 2023-09-22 14:31:05 --> Loader Class Initialized
INFO - 2023-09-22 14:31:05 --> Helper loaded: url_helper
INFO - 2023-09-22 14:31:05 --> Helper loaded: file_helper
INFO - 2023-09-22 14:31:05 --> Helper loaded: form_helper
INFO - 2023-09-22 14:31:05 --> Helper loaded: my_helper
INFO - 2023-09-22 14:31:05 --> Database Driver Class Initialized
INFO - 2023-09-22 14:31:05 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-22 14:31:05 --> Controller Class Initialized
INFO - 2023-09-22 14:31:06 --> Config Class Initialized
INFO - 2023-09-22 14:31:06 --> Hooks Class Initialized
DEBUG - 2023-09-22 14:31:06 --> UTF-8 Support Enabled
INFO - 2023-09-22 14:31:06 --> Utf8 Class Initialized
INFO - 2023-09-22 14:31:06 --> URI Class Initialized
INFO - 2023-09-22 14:31:06 --> Router Class Initialized
INFO - 2023-09-22 14:31:06 --> Output Class Initialized
INFO - 2023-09-22 14:31:06 --> Security Class Initialized
DEBUG - 2023-09-22 14:31:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-22 14:31:06 --> Input Class Initialized
INFO - 2023-09-22 14:31:06 --> Language Class Initialized
INFO - 2023-09-22 14:31:06 --> Language Class Initialized
INFO - 2023-09-22 14:31:06 --> Config Class Initialized
INFO - 2023-09-22 14:31:06 --> Loader Class Initialized
INFO - 2023-09-22 14:31:06 --> Helper loaded: url_helper
INFO - 2023-09-22 14:31:06 --> Helper loaded: file_helper
INFO - 2023-09-22 14:31:06 --> Helper loaded: form_helper
INFO - 2023-09-22 14:31:06 --> Helper loaded: my_helper
INFO - 2023-09-22 14:31:06 --> Database Driver Class Initialized
INFO - 2023-09-22 14:31:06 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-22 14:31:06 --> Controller Class Initialized
INFO - 2023-09-22 14:31:06 --> Final output sent to browser
DEBUG - 2023-09-22 14:31:06 --> Total execution time: 0.1056
INFO - 2023-09-22 14:31:07 --> Config Class Initialized
INFO - 2023-09-22 14:31:07 --> Hooks Class Initialized
DEBUG - 2023-09-22 14:31:07 --> UTF-8 Support Enabled
INFO - 2023-09-22 14:31:07 --> Utf8 Class Initialized
INFO - 2023-09-22 14:31:07 --> URI Class Initialized
INFO - 2023-09-22 14:31:07 --> Router Class Initialized
INFO - 2023-09-22 14:31:07 --> Output Class Initialized
INFO - 2023-09-22 14:31:07 --> Security Class Initialized
DEBUG - 2023-09-22 14:31:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-22 14:31:07 --> Input Class Initialized
INFO - 2023-09-22 14:31:07 --> Language Class Initialized
INFO - 2023-09-22 14:31:07 --> Language Class Initialized
INFO - 2023-09-22 14:31:07 --> Config Class Initialized
INFO - 2023-09-22 14:31:07 --> Loader Class Initialized
INFO - 2023-09-22 14:31:07 --> Helper loaded: url_helper
INFO - 2023-09-22 14:31:07 --> Helper loaded: file_helper
INFO - 2023-09-22 14:31:07 --> Helper loaded: form_helper
INFO - 2023-09-22 14:31:07 --> Helper loaded: my_helper
INFO - 2023-09-22 14:31:07 --> Database Driver Class Initialized
INFO - 2023-09-22 14:31:07 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-22 14:31:07 --> Controller Class Initialized
INFO - 2023-09-22 14:31:08 --> Config Class Initialized
INFO - 2023-09-22 14:31:08 --> Hooks Class Initialized
DEBUG - 2023-09-22 14:31:08 --> UTF-8 Support Enabled
INFO - 2023-09-22 14:31:08 --> Utf8 Class Initialized
INFO - 2023-09-22 14:31:08 --> URI Class Initialized
INFO - 2023-09-22 14:31:08 --> Router Class Initialized
INFO - 2023-09-22 14:31:08 --> Output Class Initialized
INFO - 2023-09-22 14:31:08 --> Security Class Initialized
DEBUG - 2023-09-22 14:31:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-22 14:31:08 --> Input Class Initialized
INFO - 2023-09-22 14:31:08 --> Language Class Initialized
INFO - 2023-09-22 14:31:08 --> Language Class Initialized
INFO - 2023-09-22 14:31:08 --> Config Class Initialized
INFO - 2023-09-22 14:31:08 --> Loader Class Initialized
INFO - 2023-09-22 14:31:08 --> Helper loaded: url_helper
INFO - 2023-09-22 14:31:08 --> Helper loaded: file_helper
INFO - 2023-09-22 14:31:08 --> Helper loaded: form_helper
INFO - 2023-09-22 14:31:08 --> Helper loaded: my_helper
INFO - 2023-09-22 14:31:08 --> Database Driver Class Initialized
INFO - 2023-09-22 14:31:08 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-22 14:31:08 --> Controller Class Initialized
INFO - 2023-09-22 14:31:36 --> Config Class Initialized
INFO - 2023-09-22 14:31:36 --> Hooks Class Initialized
DEBUG - 2023-09-22 14:31:36 --> UTF-8 Support Enabled
INFO - 2023-09-22 14:31:36 --> Utf8 Class Initialized
INFO - 2023-09-22 14:31:36 --> URI Class Initialized
INFO - 2023-09-22 14:31:36 --> Router Class Initialized
INFO - 2023-09-22 14:31:36 --> Output Class Initialized
INFO - 2023-09-22 14:31:36 --> Security Class Initialized
DEBUG - 2023-09-22 14:31:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-22 14:31:36 --> Input Class Initialized
INFO - 2023-09-22 14:31:36 --> Language Class Initialized
INFO - 2023-09-22 14:31:36 --> Language Class Initialized
INFO - 2023-09-22 14:31:36 --> Config Class Initialized
INFO - 2023-09-22 14:31:36 --> Loader Class Initialized
INFO - 2023-09-22 14:31:36 --> Helper loaded: url_helper
INFO - 2023-09-22 14:31:36 --> Helper loaded: file_helper
INFO - 2023-09-22 14:31:36 --> Helper loaded: form_helper
INFO - 2023-09-22 14:31:36 --> Helper loaded: my_helper
INFO - 2023-09-22 14:31:36 --> Database Driver Class Initialized
INFO - 2023-09-22 14:31:36 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-22 14:31:36 --> Controller Class Initialized
INFO - 2023-09-22 14:31:36 --> Final output sent to browser
DEBUG - 2023-09-22 14:31:36 --> Total execution time: 0.0424
INFO - 2023-09-22 14:31:36 --> Config Class Initialized
INFO - 2023-09-22 14:31:36 --> Hooks Class Initialized
DEBUG - 2023-09-22 14:31:36 --> UTF-8 Support Enabled
INFO - 2023-09-22 14:31:36 --> Utf8 Class Initialized
INFO - 2023-09-22 14:31:36 --> URI Class Initialized
INFO - 2023-09-22 14:31:36 --> Router Class Initialized
INFO - 2023-09-22 14:31:36 --> Output Class Initialized
INFO - 2023-09-22 14:31:36 --> Security Class Initialized
DEBUG - 2023-09-22 14:31:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-22 14:31:36 --> Input Class Initialized
INFO - 2023-09-22 14:31:36 --> Language Class Initialized
INFO - 2023-09-22 14:31:36 --> Language Class Initialized
INFO - 2023-09-22 14:31:36 --> Config Class Initialized
INFO - 2023-09-22 14:31:36 --> Loader Class Initialized
INFO - 2023-09-22 14:31:36 --> Helper loaded: url_helper
INFO - 2023-09-22 14:31:36 --> Helper loaded: file_helper
INFO - 2023-09-22 14:31:36 --> Helper loaded: form_helper
INFO - 2023-09-22 14:31:36 --> Helper loaded: my_helper
INFO - 2023-09-22 14:31:36 --> Database Driver Class Initialized
INFO - 2023-09-22 14:31:36 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-22 14:31:36 --> Controller Class Initialized
INFO - 2023-09-22 14:31:38 --> Config Class Initialized
INFO - 2023-09-22 14:31:38 --> Hooks Class Initialized
DEBUG - 2023-09-22 14:31:38 --> UTF-8 Support Enabled
INFO - 2023-09-22 14:31:38 --> Utf8 Class Initialized
INFO - 2023-09-22 14:31:38 --> URI Class Initialized
INFO - 2023-09-22 14:31:38 --> Router Class Initialized
INFO - 2023-09-22 14:31:38 --> Output Class Initialized
INFO - 2023-09-22 14:31:38 --> Security Class Initialized
DEBUG - 2023-09-22 14:31:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-22 14:31:38 --> Input Class Initialized
INFO - 2023-09-22 14:31:38 --> Language Class Initialized
INFO - 2023-09-22 14:31:38 --> Language Class Initialized
INFO - 2023-09-22 14:31:38 --> Config Class Initialized
INFO - 2023-09-22 14:31:38 --> Loader Class Initialized
INFO - 2023-09-22 14:31:38 --> Helper loaded: url_helper
INFO - 2023-09-22 14:31:38 --> Helper loaded: file_helper
INFO - 2023-09-22 14:31:38 --> Helper loaded: form_helper
INFO - 2023-09-22 14:31:38 --> Helper loaded: my_helper
INFO - 2023-09-22 14:31:38 --> Database Driver Class Initialized
INFO - 2023-09-22 14:31:38 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-22 14:31:38 --> Controller Class Initialized
INFO - 2023-09-22 14:31:38 --> Final output sent to browser
DEBUG - 2023-09-22 14:31:38 --> Total execution time: 0.0476
INFO - 2023-09-22 14:31:38 --> Config Class Initialized
INFO - 2023-09-22 14:31:38 --> Hooks Class Initialized
DEBUG - 2023-09-22 14:31:38 --> UTF-8 Support Enabled
INFO - 2023-09-22 14:31:38 --> Utf8 Class Initialized
INFO - 2023-09-22 14:31:38 --> URI Class Initialized
INFO - 2023-09-22 14:31:38 --> Router Class Initialized
INFO - 2023-09-22 14:31:38 --> Output Class Initialized
INFO - 2023-09-22 14:31:38 --> Security Class Initialized
DEBUG - 2023-09-22 14:31:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-22 14:31:38 --> Input Class Initialized
INFO - 2023-09-22 14:31:38 --> Language Class Initialized
INFO - 2023-09-22 14:31:39 --> Language Class Initialized
INFO - 2023-09-22 14:31:39 --> Config Class Initialized
INFO - 2023-09-22 14:31:39 --> Loader Class Initialized
INFO - 2023-09-22 14:31:39 --> Helper loaded: url_helper
INFO - 2023-09-22 14:31:39 --> Helper loaded: file_helper
INFO - 2023-09-22 14:31:39 --> Helper loaded: form_helper
INFO - 2023-09-22 14:31:39 --> Helper loaded: my_helper
INFO - 2023-09-22 14:31:39 --> Database Driver Class Initialized
INFO - 2023-09-22 14:31:39 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-22 14:31:39 --> Controller Class Initialized
INFO - 2023-09-22 14:31:47 --> Config Class Initialized
INFO - 2023-09-22 14:31:47 --> Hooks Class Initialized
DEBUG - 2023-09-22 14:31:47 --> UTF-8 Support Enabled
INFO - 2023-09-22 14:31:47 --> Utf8 Class Initialized
INFO - 2023-09-22 14:31:47 --> URI Class Initialized
INFO - 2023-09-22 14:31:47 --> Router Class Initialized
INFO - 2023-09-22 14:31:47 --> Output Class Initialized
INFO - 2023-09-22 14:31:47 --> Security Class Initialized
DEBUG - 2023-09-22 14:31:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-22 14:31:47 --> Input Class Initialized
INFO - 2023-09-22 14:31:47 --> Language Class Initialized
INFO - 2023-09-22 14:31:47 --> Language Class Initialized
INFO - 2023-09-22 14:31:47 --> Config Class Initialized
INFO - 2023-09-22 14:31:47 --> Loader Class Initialized
INFO - 2023-09-22 14:31:47 --> Helper loaded: url_helper
INFO - 2023-09-22 14:31:47 --> Helper loaded: file_helper
INFO - 2023-09-22 14:31:47 --> Helper loaded: form_helper
INFO - 2023-09-22 14:31:47 --> Helper loaded: my_helper
INFO - 2023-09-22 14:31:47 --> Database Driver Class Initialized
INFO - 2023-09-22 14:31:47 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-22 14:31:47 --> Controller Class Initialized
INFO - 2023-09-22 14:31:47 --> Final output sent to browser
DEBUG - 2023-09-22 14:31:47 --> Total execution time: 0.0439
INFO - 2023-09-22 14:32:09 --> Config Class Initialized
INFO - 2023-09-22 14:32:09 --> Hooks Class Initialized
DEBUG - 2023-09-22 14:32:09 --> UTF-8 Support Enabled
INFO - 2023-09-22 14:32:09 --> Utf8 Class Initialized
INFO - 2023-09-22 14:32:09 --> URI Class Initialized
INFO - 2023-09-22 14:32:09 --> Router Class Initialized
INFO - 2023-09-22 14:32:09 --> Output Class Initialized
INFO - 2023-09-22 14:32:09 --> Security Class Initialized
DEBUG - 2023-09-22 14:32:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-22 14:32:09 --> Input Class Initialized
INFO - 2023-09-22 14:32:09 --> Language Class Initialized
INFO - 2023-09-22 14:32:09 --> Language Class Initialized
INFO - 2023-09-22 14:32:09 --> Config Class Initialized
INFO - 2023-09-22 14:32:09 --> Loader Class Initialized
INFO - 2023-09-22 14:32:09 --> Helper loaded: url_helper
INFO - 2023-09-22 14:32:09 --> Helper loaded: file_helper
INFO - 2023-09-22 14:32:09 --> Helper loaded: form_helper
INFO - 2023-09-22 14:32:09 --> Helper loaded: my_helper
INFO - 2023-09-22 14:32:09 --> Database Driver Class Initialized
INFO - 2023-09-22 14:32:09 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-22 14:32:09 --> Controller Class Initialized
INFO - 2023-09-22 14:32:09 --> Final output sent to browser
DEBUG - 2023-09-22 14:32:09 --> Total execution time: 0.2574
INFO - 2023-09-22 14:32:11 --> Config Class Initialized
INFO - 2023-09-22 14:32:11 --> Hooks Class Initialized
DEBUG - 2023-09-22 14:32:11 --> UTF-8 Support Enabled
INFO - 2023-09-22 14:32:11 --> Utf8 Class Initialized
INFO - 2023-09-22 14:32:11 --> URI Class Initialized
INFO - 2023-09-22 14:32:11 --> Router Class Initialized
INFO - 2023-09-22 14:32:11 --> Output Class Initialized
INFO - 2023-09-22 14:32:11 --> Security Class Initialized
DEBUG - 2023-09-22 14:32:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-22 14:32:11 --> Input Class Initialized
INFO - 2023-09-22 14:32:11 --> Language Class Initialized
INFO - 2023-09-22 14:32:11 --> Language Class Initialized
INFO - 2023-09-22 14:32:11 --> Config Class Initialized
INFO - 2023-09-22 14:32:11 --> Loader Class Initialized
INFO - 2023-09-22 14:32:11 --> Helper loaded: url_helper
INFO - 2023-09-22 14:32:11 --> Helper loaded: file_helper
INFO - 2023-09-22 14:32:11 --> Helper loaded: form_helper
INFO - 2023-09-22 14:32:11 --> Helper loaded: my_helper
INFO - 2023-09-22 14:32:11 --> Database Driver Class Initialized
INFO - 2023-09-22 14:32:11 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-22 14:32:11 --> Controller Class Initialized
INFO - 2023-09-22 14:32:23 --> Config Class Initialized
INFO - 2023-09-22 14:32:23 --> Hooks Class Initialized
DEBUG - 2023-09-22 14:32:23 --> UTF-8 Support Enabled
INFO - 2023-09-22 14:32:23 --> Utf8 Class Initialized
INFO - 2023-09-22 14:32:23 --> URI Class Initialized
INFO - 2023-09-22 14:32:23 --> Router Class Initialized
INFO - 2023-09-22 14:32:23 --> Output Class Initialized
INFO - 2023-09-22 14:32:23 --> Security Class Initialized
DEBUG - 2023-09-22 14:32:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-22 14:32:23 --> Input Class Initialized
INFO - 2023-09-22 14:32:23 --> Language Class Initialized
INFO - 2023-09-22 14:32:23 --> Language Class Initialized
INFO - 2023-09-22 14:32:23 --> Config Class Initialized
INFO - 2023-09-22 14:32:23 --> Loader Class Initialized
INFO - 2023-09-22 14:32:23 --> Helper loaded: url_helper
INFO - 2023-09-22 14:32:23 --> Helper loaded: file_helper
INFO - 2023-09-22 14:32:23 --> Helper loaded: form_helper
INFO - 2023-09-22 14:32:23 --> Helper loaded: my_helper
INFO - 2023-09-22 14:32:23 --> Database Driver Class Initialized
INFO - 2023-09-22 14:32:23 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-22 14:32:23 --> Controller Class Initialized
INFO - 2023-09-22 14:32:39 --> Config Class Initialized
INFO - 2023-09-22 14:32:39 --> Hooks Class Initialized
DEBUG - 2023-09-22 14:32:39 --> UTF-8 Support Enabled
INFO - 2023-09-22 14:32:39 --> Utf8 Class Initialized
INFO - 2023-09-22 14:32:39 --> URI Class Initialized
INFO - 2023-09-22 14:32:39 --> Router Class Initialized
INFO - 2023-09-22 14:32:39 --> Output Class Initialized
INFO - 2023-09-22 14:32:39 --> Security Class Initialized
DEBUG - 2023-09-22 14:32:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-22 14:32:39 --> Input Class Initialized
INFO - 2023-09-22 14:32:39 --> Language Class Initialized
INFO - 2023-09-22 14:32:39 --> Language Class Initialized
INFO - 2023-09-22 14:32:39 --> Config Class Initialized
INFO - 2023-09-22 14:32:39 --> Loader Class Initialized
INFO - 2023-09-22 14:32:39 --> Helper loaded: url_helper
INFO - 2023-09-22 14:32:39 --> Helper loaded: file_helper
INFO - 2023-09-22 14:32:39 --> Helper loaded: form_helper
INFO - 2023-09-22 14:32:39 --> Helper loaded: my_helper
INFO - 2023-09-22 14:32:39 --> Database Driver Class Initialized
INFO - 2023-09-22 14:32:39 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-22 14:32:39 --> Controller Class Initialized
DEBUG - 2023-09-22 14:32:39 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/views/list.php
DEBUG - 2023-09-22 14:32:39 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-09-22 14:32:39 --> Final output sent to browser
DEBUG - 2023-09-22 14:32:39 --> Total execution time: 0.0359
INFO - 2023-09-22 14:32:40 --> Config Class Initialized
INFO - 2023-09-22 14:32:40 --> Hooks Class Initialized
DEBUG - 2023-09-22 14:32:40 --> UTF-8 Support Enabled
INFO - 2023-09-22 14:32:40 --> Utf8 Class Initialized
INFO - 2023-09-22 14:32:40 --> URI Class Initialized
INFO - 2023-09-22 14:32:40 --> Router Class Initialized
INFO - 2023-09-22 14:32:40 --> Output Class Initialized
INFO - 2023-09-22 14:32:40 --> Security Class Initialized
DEBUG - 2023-09-22 14:32:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-22 14:32:40 --> Input Class Initialized
INFO - 2023-09-22 14:32:40 --> Language Class Initialized
INFO - 2023-09-22 14:32:40 --> Language Class Initialized
INFO - 2023-09-22 14:32:40 --> Config Class Initialized
INFO - 2023-09-22 14:32:40 --> Loader Class Initialized
INFO - 2023-09-22 14:32:40 --> Helper loaded: url_helper
INFO - 2023-09-22 14:32:40 --> Helper loaded: file_helper
INFO - 2023-09-22 14:32:40 --> Helper loaded: form_helper
INFO - 2023-09-22 14:32:40 --> Helper loaded: my_helper
INFO - 2023-09-22 14:32:40 --> Database Driver Class Initialized
INFO - 2023-09-22 14:32:40 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-22 14:32:40 --> Controller Class Initialized
INFO - 2023-09-22 14:32:49 --> Config Class Initialized
INFO - 2023-09-22 14:32:49 --> Hooks Class Initialized
DEBUG - 2023-09-22 14:32:49 --> UTF-8 Support Enabled
INFO - 2023-09-22 14:32:49 --> Utf8 Class Initialized
INFO - 2023-09-22 14:32:49 --> URI Class Initialized
INFO - 2023-09-22 14:32:49 --> Router Class Initialized
INFO - 2023-09-22 14:32:49 --> Output Class Initialized
INFO - 2023-09-22 14:32:49 --> Security Class Initialized
DEBUG - 2023-09-22 14:32:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-22 14:32:49 --> Input Class Initialized
INFO - 2023-09-22 14:32:49 --> Language Class Initialized
INFO - 2023-09-22 14:32:49 --> Language Class Initialized
INFO - 2023-09-22 14:32:49 --> Config Class Initialized
INFO - 2023-09-22 14:32:49 --> Loader Class Initialized
INFO - 2023-09-22 14:32:49 --> Helper loaded: url_helper
INFO - 2023-09-22 14:32:49 --> Helper loaded: file_helper
INFO - 2023-09-22 14:32:49 --> Helper loaded: form_helper
INFO - 2023-09-22 14:32:49 --> Helper loaded: my_helper
INFO - 2023-09-22 14:32:49 --> Database Driver Class Initialized
INFO - 2023-09-22 14:32:49 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-22 14:32:49 --> Controller Class Initialized
INFO - 2023-09-22 14:32:49 --> Final output sent to browser
DEBUG - 2023-09-22 14:32:49 --> Total execution time: 0.0333
INFO - 2023-09-22 14:32:54 --> Config Class Initialized
INFO - 2023-09-22 14:32:54 --> Hooks Class Initialized
DEBUG - 2023-09-22 14:32:54 --> UTF-8 Support Enabled
INFO - 2023-09-22 14:32:54 --> Utf8 Class Initialized
INFO - 2023-09-22 14:32:54 --> URI Class Initialized
INFO - 2023-09-22 14:32:54 --> Router Class Initialized
INFO - 2023-09-22 14:32:54 --> Output Class Initialized
INFO - 2023-09-22 14:32:54 --> Security Class Initialized
DEBUG - 2023-09-22 14:32:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-22 14:32:54 --> Input Class Initialized
INFO - 2023-09-22 14:32:54 --> Language Class Initialized
INFO - 2023-09-22 14:32:54 --> Language Class Initialized
INFO - 2023-09-22 14:32:54 --> Config Class Initialized
INFO - 2023-09-22 14:32:54 --> Loader Class Initialized
INFO - 2023-09-22 14:32:54 --> Helper loaded: url_helper
INFO - 2023-09-22 14:32:54 --> Helper loaded: file_helper
INFO - 2023-09-22 14:32:54 --> Helper loaded: form_helper
INFO - 2023-09-22 14:32:54 --> Helper loaded: my_helper
INFO - 2023-09-22 14:32:54 --> Database Driver Class Initialized
INFO - 2023-09-22 14:32:54 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-22 14:32:54 --> Controller Class Initialized
INFO - 2023-09-22 14:32:54 --> Final output sent to browser
DEBUG - 2023-09-22 14:32:54 --> Total execution time: 0.0451
INFO - 2023-09-22 14:32:55 --> Config Class Initialized
INFO - 2023-09-22 14:32:55 --> Hooks Class Initialized
DEBUG - 2023-09-22 14:32:55 --> UTF-8 Support Enabled
INFO - 2023-09-22 14:32:55 --> Utf8 Class Initialized
INFO - 2023-09-22 14:32:55 --> URI Class Initialized
INFO - 2023-09-22 14:32:55 --> Router Class Initialized
INFO - 2023-09-22 14:32:55 --> Output Class Initialized
INFO - 2023-09-22 14:32:55 --> Security Class Initialized
DEBUG - 2023-09-22 14:32:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-22 14:32:55 --> Input Class Initialized
INFO - 2023-09-22 14:32:55 --> Language Class Initialized
INFO - 2023-09-22 14:32:55 --> Language Class Initialized
INFO - 2023-09-22 14:32:55 --> Config Class Initialized
INFO - 2023-09-22 14:32:55 --> Loader Class Initialized
INFO - 2023-09-22 14:32:55 --> Helper loaded: url_helper
INFO - 2023-09-22 14:32:55 --> Helper loaded: file_helper
INFO - 2023-09-22 14:32:55 --> Helper loaded: form_helper
INFO - 2023-09-22 14:32:55 --> Helper loaded: my_helper
INFO - 2023-09-22 14:32:55 --> Database Driver Class Initialized
INFO - 2023-09-22 14:32:55 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-22 14:32:55 --> Controller Class Initialized
INFO - 2023-09-22 14:32:55 --> Final output sent to browser
DEBUG - 2023-09-22 14:32:55 --> Total execution time: 0.0803
INFO - 2023-09-22 14:32:55 --> Config Class Initialized
INFO - 2023-09-22 14:32:55 --> Hooks Class Initialized
DEBUG - 2023-09-22 14:32:55 --> UTF-8 Support Enabled
INFO - 2023-09-22 14:32:55 --> Utf8 Class Initialized
INFO - 2023-09-22 14:32:55 --> URI Class Initialized
INFO - 2023-09-22 14:32:55 --> Router Class Initialized
INFO - 2023-09-22 14:32:55 --> Output Class Initialized
INFO - 2023-09-22 14:32:55 --> Security Class Initialized
DEBUG - 2023-09-22 14:32:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-22 14:32:55 --> Input Class Initialized
INFO - 2023-09-22 14:32:55 --> Language Class Initialized
INFO - 2023-09-22 14:32:55 --> Language Class Initialized
INFO - 2023-09-22 14:32:55 --> Config Class Initialized
INFO - 2023-09-22 14:32:55 --> Loader Class Initialized
INFO - 2023-09-22 14:32:55 --> Helper loaded: url_helper
INFO - 2023-09-22 14:32:55 --> Helper loaded: file_helper
INFO - 2023-09-22 14:32:55 --> Helper loaded: form_helper
INFO - 2023-09-22 14:32:55 --> Helper loaded: my_helper
INFO - 2023-09-22 14:32:55 --> Database Driver Class Initialized
INFO - 2023-09-22 14:32:55 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-22 14:32:55 --> Controller Class Initialized
INFO - 2023-09-22 14:32:56 --> Config Class Initialized
INFO - 2023-09-22 14:32:56 --> Hooks Class Initialized
DEBUG - 2023-09-22 14:32:56 --> UTF-8 Support Enabled
INFO - 2023-09-22 14:32:56 --> Utf8 Class Initialized
INFO - 2023-09-22 14:32:56 --> URI Class Initialized
INFO - 2023-09-22 14:32:56 --> Router Class Initialized
INFO - 2023-09-22 14:32:56 --> Output Class Initialized
INFO - 2023-09-22 14:32:56 --> Security Class Initialized
DEBUG - 2023-09-22 14:32:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-22 14:32:56 --> Input Class Initialized
INFO - 2023-09-22 14:32:56 --> Language Class Initialized
INFO - 2023-09-22 14:32:56 --> Language Class Initialized
INFO - 2023-09-22 14:32:56 --> Config Class Initialized
INFO - 2023-09-22 14:32:56 --> Loader Class Initialized
INFO - 2023-09-22 14:32:56 --> Helper loaded: url_helper
INFO - 2023-09-22 14:32:56 --> Helper loaded: file_helper
INFO - 2023-09-22 14:32:56 --> Helper loaded: form_helper
INFO - 2023-09-22 14:32:56 --> Helper loaded: my_helper
INFO - 2023-09-22 14:32:56 --> Database Driver Class Initialized
INFO - 2023-09-22 14:32:56 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-22 14:32:56 --> Controller Class Initialized
INFO - 2023-09-22 14:32:56 --> Config Class Initialized
INFO - 2023-09-22 14:32:56 --> Hooks Class Initialized
DEBUG - 2023-09-22 14:32:56 --> UTF-8 Support Enabled
INFO - 2023-09-22 14:32:56 --> Utf8 Class Initialized
INFO - 2023-09-22 14:32:56 --> URI Class Initialized
INFO - 2023-09-22 14:32:56 --> Router Class Initialized
INFO - 2023-09-22 14:32:56 --> Output Class Initialized
INFO - 2023-09-22 14:32:56 --> Security Class Initialized
DEBUG - 2023-09-22 14:32:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-22 14:32:56 --> Input Class Initialized
INFO - 2023-09-22 14:32:56 --> Language Class Initialized
INFO - 2023-09-22 14:32:56 --> Language Class Initialized
INFO - 2023-09-22 14:32:56 --> Config Class Initialized
INFO - 2023-09-22 14:32:56 --> Loader Class Initialized
INFO - 2023-09-22 14:32:56 --> Helper loaded: url_helper
INFO - 2023-09-22 14:32:56 --> Helper loaded: file_helper
INFO - 2023-09-22 14:32:56 --> Helper loaded: form_helper
INFO - 2023-09-22 14:32:56 --> Helper loaded: my_helper
INFO - 2023-09-22 14:32:56 --> Database Driver Class Initialized
INFO - 2023-09-22 14:32:56 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-22 14:32:56 --> Controller Class Initialized
INFO - 2023-09-22 14:32:56 --> Final output sent to browser
DEBUG - 2023-09-22 14:32:56 --> Total execution time: 0.0389
INFO - 2023-09-22 14:33:00 --> Config Class Initialized
INFO - 2023-09-22 14:33:00 --> Hooks Class Initialized
DEBUG - 2023-09-22 14:33:00 --> UTF-8 Support Enabled
INFO - 2023-09-22 14:33:00 --> Utf8 Class Initialized
INFO - 2023-09-22 14:33:00 --> URI Class Initialized
INFO - 2023-09-22 14:33:00 --> Router Class Initialized
INFO - 2023-09-22 14:33:00 --> Output Class Initialized
INFO - 2023-09-22 14:33:00 --> Security Class Initialized
DEBUG - 2023-09-22 14:33:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-22 14:33:00 --> Input Class Initialized
INFO - 2023-09-22 14:33:00 --> Language Class Initialized
INFO - 2023-09-22 14:33:00 --> Language Class Initialized
INFO - 2023-09-22 14:33:00 --> Config Class Initialized
INFO - 2023-09-22 14:33:00 --> Loader Class Initialized
INFO - 2023-09-22 14:33:00 --> Helper loaded: url_helper
INFO - 2023-09-22 14:33:00 --> Helper loaded: file_helper
INFO - 2023-09-22 14:33:00 --> Helper loaded: form_helper
INFO - 2023-09-22 14:33:00 --> Helper loaded: my_helper
INFO - 2023-09-22 14:33:00 --> Database Driver Class Initialized
INFO - 2023-09-22 14:33:00 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-22 14:33:00 --> Controller Class Initialized
INFO - 2023-09-22 14:33:00 --> Final output sent to browser
DEBUG - 2023-09-22 14:33:00 --> Total execution time: 0.0374
INFO - 2023-09-22 14:33:00 --> Config Class Initialized
INFO - 2023-09-22 14:33:00 --> Hooks Class Initialized
DEBUG - 2023-09-22 14:33:00 --> UTF-8 Support Enabled
INFO - 2023-09-22 14:33:00 --> Utf8 Class Initialized
INFO - 2023-09-22 14:33:00 --> URI Class Initialized
INFO - 2023-09-22 14:33:00 --> Router Class Initialized
INFO - 2023-09-22 14:33:00 --> Output Class Initialized
INFO - 2023-09-22 14:33:00 --> Security Class Initialized
DEBUG - 2023-09-22 14:33:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-22 14:33:00 --> Input Class Initialized
INFO - 2023-09-22 14:33:00 --> Language Class Initialized
INFO - 2023-09-22 14:33:00 --> Language Class Initialized
INFO - 2023-09-22 14:33:00 --> Config Class Initialized
INFO - 2023-09-22 14:33:00 --> Loader Class Initialized
INFO - 2023-09-22 14:33:00 --> Helper loaded: url_helper
INFO - 2023-09-22 14:33:00 --> Helper loaded: file_helper
INFO - 2023-09-22 14:33:00 --> Helper loaded: form_helper
INFO - 2023-09-22 14:33:00 --> Helper loaded: my_helper
INFO - 2023-09-22 14:33:00 --> Database Driver Class Initialized
INFO - 2023-09-22 14:33:00 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-22 14:33:00 --> Controller Class Initialized
INFO - 2023-09-22 14:33:01 --> Config Class Initialized
INFO - 2023-09-22 14:33:01 --> Hooks Class Initialized
DEBUG - 2023-09-22 14:33:01 --> UTF-8 Support Enabled
INFO - 2023-09-22 14:33:01 --> Utf8 Class Initialized
INFO - 2023-09-22 14:33:01 --> URI Class Initialized
INFO - 2023-09-22 14:33:01 --> Router Class Initialized
INFO - 2023-09-22 14:33:01 --> Output Class Initialized
INFO - 2023-09-22 14:33:01 --> Security Class Initialized
DEBUG - 2023-09-22 14:33:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-22 14:33:01 --> Input Class Initialized
INFO - 2023-09-22 14:33:01 --> Language Class Initialized
INFO - 2023-09-22 14:33:01 --> Language Class Initialized
INFO - 2023-09-22 14:33:01 --> Config Class Initialized
INFO - 2023-09-22 14:33:01 --> Loader Class Initialized
INFO - 2023-09-22 14:33:01 --> Helper loaded: url_helper
INFO - 2023-09-22 14:33:01 --> Helper loaded: file_helper
INFO - 2023-09-22 14:33:01 --> Helper loaded: form_helper
INFO - 2023-09-22 14:33:01 --> Helper loaded: my_helper
INFO - 2023-09-22 14:33:01 --> Database Driver Class Initialized
INFO - 2023-09-22 14:33:01 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-22 14:33:01 --> Controller Class Initialized
INFO - 2023-09-22 14:33:01 --> Final output sent to browser
DEBUG - 2023-09-22 14:33:01 --> Total execution time: 0.1363
INFO - 2023-09-22 14:33:05 --> Config Class Initialized
INFO - 2023-09-22 14:33:05 --> Hooks Class Initialized
DEBUG - 2023-09-22 14:33:05 --> UTF-8 Support Enabled
INFO - 2023-09-22 14:33:05 --> Utf8 Class Initialized
INFO - 2023-09-22 14:33:05 --> URI Class Initialized
INFO - 2023-09-22 14:33:05 --> Router Class Initialized
INFO - 2023-09-22 14:33:05 --> Output Class Initialized
INFO - 2023-09-22 14:33:05 --> Security Class Initialized
DEBUG - 2023-09-22 14:33:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-22 14:33:05 --> Input Class Initialized
INFO - 2023-09-22 14:33:05 --> Language Class Initialized
INFO - 2023-09-22 14:33:05 --> Language Class Initialized
INFO - 2023-09-22 14:33:05 --> Config Class Initialized
INFO - 2023-09-22 14:33:05 --> Loader Class Initialized
INFO - 2023-09-22 14:33:05 --> Helper loaded: url_helper
INFO - 2023-09-22 14:33:05 --> Helper loaded: file_helper
INFO - 2023-09-22 14:33:05 --> Helper loaded: form_helper
INFO - 2023-09-22 14:33:05 --> Helper loaded: my_helper
INFO - 2023-09-22 14:33:05 --> Database Driver Class Initialized
INFO - 2023-09-22 14:33:05 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-22 14:33:05 --> Controller Class Initialized
INFO - 2023-09-22 14:33:05 --> Final output sent to browser
DEBUG - 2023-09-22 14:33:05 --> Total execution time: 0.0350
INFO - 2023-09-22 14:33:05 --> Config Class Initialized
INFO - 2023-09-22 14:33:05 --> Hooks Class Initialized
DEBUG - 2023-09-22 14:33:05 --> UTF-8 Support Enabled
INFO - 2023-09-22 14:33:05 --> Utf8 Class Initialized
INFO - 2023-09-22 14:33:05 --> URI Class Initialized
INFO - 2023-09-22 14:33:05 --> Router Class Initialized
INFO - 2023-09-22 14:33:05 --> Output Class Initialized
INFO - 2023-09-22 14:33:05 --> Security Class Initialized
DEBUG - 2023-09-22 14:33:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-22 14:33:05 --> Input Class Initialized
INFO - 2023-09-22 14:33:05 --> Language Class Initialized
INFO - 2023-09-22 14:33:05 --> Language Class Initialized
INFO - 2023-09-22 14:33:05 --> Config Class Initialized
INFO - 2023-09-22 14:33:05 --> Loader Class Initialized
INFO - 2023-09-22 14:33:05 --> Helper loaded: url_helper
INFO - 2023-09-22 14:33:05 --> Helper loaded: file_helper
INFO - 2023-09-22 14:33:05 --> Helper loaded: form_helper
INFO - 2023-09-22 14:33:05 --> Helper loaded: my_helper
INFO - 2023-09-22 14:33:05 --> Database Driver Class Initialized
INFO - 2023-09-22 14:33:05 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-22 14:33:05 --> Controller Class Initialized
INFO - 2023-09-22 14:33:07 --> Config Class Initialized
INFO - 2023-09-22 14:33:07 --> Hooks Class Initialized
DEBUG - 2023-09-22 14:33:07 --> UTF-8 Support Enabled
INFO - 2023-09-22 14:33:07 --> Utf8 Class Initialized
INFO - 2023-09-22 14:33:07 --> URI Class Initialized
INFO - 2023-09-22 14:33:07 --> Router Class Initialized
INFO - 2023-09-22 14:33:07 --> Output Class Initialized
INFO - 2023-09-22 14:33:07 --> Security Class Initialized
DEBUG - 2023-09-22 14:33:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-22 14:33:07 --> Input Class Initialized
INFO - 2023-09-22 14:33:07 --> Language Class Initialized
INFO - 2023-09-22 14:33:07 --> Language Class Initialized
INFO - 2023-09-22 14:33:07 --> Config Class Initialized
INFO - 2023-09-22 14:33:07 --> Loader Class Initialized
INFO - 2023-09-22 14:33:07 --> Helper loaded: url_helper
INFO - 2023-09-22 14:33:07 --> Helper loaded: file_helper
INFO - 2023-09-22 14:33:07 --> Helper loaded: form_helper
INFO - 2023-09-22 14:33:07 --> Helper loaded: my_helper
INFO - 2023-09-22 14:33:07 --> Database Driver Class Initialized
INFO - 2023-09-22 14:33:07 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-22 14:33:07 --> Controller Class Initialized
INFO - 2023-09-22 14:33:07 --> Final output sent to browser
DEBUG - 2023-09-22 14:33:07 --> Total execution time: 0.0981
INFO - 2023-09-22 14:33:15 --> Config Class Initialized
INFO - 2023-09-22 14:33:15 --> Hooks Class Initialized
DEBUG - 2023-09-22 14:33:15 --> UTF-8 Support Enabled
INFO - 2023-09-22 14:33:15 --> Utf8 Class Initialized
INFO - 2023-09-22 14:33:15 --> URI Class Initialized
INFO - 2023-09-22 14:33:15 --> Router Class Initialized
INFO - 2023-09-22 14:33:15 --> Output Class Initialized
INFO - 2023-09-22 14:33:15 --> Security Class Initialized
DEBUG - 2023-09-22 14:33:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-22 14:33:15 --> Input Class Initialized
INFO - 2023-09-22 14:33:15 --> Language Class Initialized
INFO - 2023-09-22 14:33:15 --> Language Class Initialized
INFO - 2023-09-22 14:33:15 --> Config Class Initialized
INFO - 2023-09-22 14:33:15 --> Loader Class Initialized
INFO - 2023-09-22 14:33:15 --> Helper loaded: url_helper
INFO - 2023-09-22 14:33:15 --> Helper loaded: file_helper
INFO - 2023-09-22 14:33:15 --> Helper loaded: form_helper
INFO - 2023-09-22 14:33:15 --> Helper loaded: my_helper
INFO - 2023-09-22 14:33:15 --> Database Driver Class Initialized
INFO - 2023-09-22 14:33:15 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-22 14:33:15 --> Controller Class Initialized
INFO - 2023-09-22 14:33:15 --> Config Class Initialized
INFO - 2023-09-22 14:33:15 --> Hooks Class Initialized
DEBUG - 2023-09-22 14:33:15 --> UTF-8 Support Enabled
INFO - 2023-09-22 14:33:15 --> Utf8 Class Initialized
INFO - 2023-09-22 14:33:15 --> URI Class Initialized
INFO - 2023-09-22 14:33:15 --> Router Class Initialized
INFO - 2023-09-22 14:33:15 --> Output Class Initialized
INFO - 2023-09-22 14:33:15 --> Security Class Initialized
DEBUG - 2023-09-22 14:33:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-22 14:33:15 --> Input Class Initialized
INFO - 2023-09-22 14:33:15 --> Language Class Initialized
INFO - 2023-09-22 14:33:15 --> Language Class Initialized
INFO - 2023-09-22 14:33:15 --> Config Class Initialized
INFO - 2023-09-22 14:33:15 --> Loader Class Initialized
INFO - 2023-09-22 14:33:15 --> Helper loaded: url_helper
INFO - 2023-09-22 14:33:15 --> Helper loaded: file_helper
INFO - 2023-09-22 14:33:15 --> Helper loaded: form_helper
INFO - 2023-09-22 14:33:15 --> Helper loaded: my_helper
INFO - 2023-09-22 14:33:15 --> Database Driver Class Initialized
INFO - 2023-09-22 14:33:15 --> Final output sent to browser
DEBUG - 2023-09-22 14:33:15 --> Total execution time: 0.1078
INFO - 2023-09-22 14:33:15 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-22 14:33:15 --> Controller Class Initialized
INFO - 2023-09-22 14:33:39 --> Config Class Initialized
INFO - 2023-09-22 14:33:39 --> Hooks Class Initialized
DEBUG - 2023-09-22 14:33:39 --> UTF-8 Support Enabled
INFO - 2023-09-22 14:33:39 --> Utf8 Class Initialized
INFO - 2023-09-22 14:33:39 --> URI Class Initialized
INFO - 2023-09-22 14:33:39 --> Router Class Initialized
INFO - 2023-09-22 14:33:39 --> Output Class Initialized
INFO - 2023-09-22 14:33:39 --> Security Class Initialized
DEBUG - 2023-09-22 14:33:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-22 14:33:39 --> Input Class Initialized
INFO - 2023-09-22 14:33:39 --> Language Class Initialized
INFO - 2023-09-22 14:33:39 --> Language Class Initialized
INFO - 2023-09-22 14:33:39 --> Config Class Initialized
INFO - 2023-09-22 14:33:39 --> Loader Class Initialized
INFO - 2023-09-22 14:33:39 --> Helper loaded: url_helper
INFO - 2023-09-22 14:33:39 --> Helper loaded: file_helper
INFO - 2023-09-22 14:33:39 --> Helper loaded: form_helper
INFO - 2023-09-22 14:33:39 --> Helper loaded: my_helper
INFO - 2023-09-22 14:33:39 --> Database Driver Class Initialized
INFO - 2023-09-22 14:33:39 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-22 14:33:39 --> Controller Class Initialized
INFO - 2023-09-22 14:33:39 --> Final output sent to browser
DEBUG - 2023-09-22 14:33:39 --> Total execution time: 0.0908
INFO - 2023-09-22 14:34:01 --> Config Class Initialized
INFO - 2023-09-22 14:34:01 --> Hooks Class Initialized
DEBUG - 2023-09-22 14:34:01 --> UTF-8 Support Enabled
INFO - 2023-09-22 14:34:01 --> Utf8 Class Initialized
INFO - 2023-09-22 14:34:01 --> URI Class Initialized
INFO - 2023-09-22 14:34:01 --> Router Class Initialized
INFO - 2023-09-22 14:34:01 --> Output Class Initialized
INFO - 2023-09-22 14:34:01 --> Security Class Initialized
DEBUG - 2023-09-22 14:34:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-22 14:34:01 --> Input Class Initialized
INFO - 2023-09-22 14:34:01 --> Language Class Initialized
INFO - 2023-09-22 14:34:01 --> Language Class Initialized
INFO - 2023-09-22 14:34:01 --> Config Class Initialized
INFO - 2023-09-22 14:34:01 --> Loader Class Initialized
INFO - 2023-09-22 14:34:01 --> Helper loaded: url_helper
INFO - 2023-09-22 14:34:01 --> Helper loaded: file_helper
INFO - 2023-09-22 14:34:01 --> Helper loaded: form_helper
INFO - 2023-09-22 14:34:01 --> Helper loaded: my_helper
INFO - 2023-09-22 14:34:01 --> Database Driver Class Initialized
INFO - 2023-09-22 14:34:01 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-22 14:34:01 --> Controller Class Initialized
INFO - 2023-09-22 14:34:02 --> Final output sent to browser
DEBUG - 2023-09-22 14:34:02 --> Total execution time: 0.4591
INFO - 2023-09-22 14:34:06 --> Config Class Initialized
INFO - 2023-09-22 14:34:06 --> Hooks Class Initialized
DEBUG - 2023-09-22 14:34:06 --> UTF-8 Support Enabled
INFO - 2023-09-22 14:34:06 --> Utf8 Class Initialized
INFO - 2023-09-22 14:34:06 --> URI Class Initialized
INFO - 2023-09-22 14:34:06 --> Router Class Initialized
INFO - 2023-09-22 14:34:06 --> Output Class Initialized
INFO - 2023-09-22 14:34:06 --> Security Class Initialized
DEBUG - 2023-09-22 14:34:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-22 14:34:06 --> Input Class Initialized
INFO - 2023-09-22 14:34:06 --> Language Class Initialized
INFO - 2023-09-22 14:34:06 --> Language Class Initialized
INFO - 2023-09-22 14:34:06 --> Config Class Initialized
INFO - 2023-09-22 14:34:06 --> Loader Class Initialized
INFO - 2023-09-22 14:34:06 --> Helper loaded: url_helper
INFO - 2023-09-22 14:34:06 --> Helper loaded: file_helper
INFO - 2023-09-22 14:34:06 --> Helper loaded: form_helper
INFO - 2023-09-22 14:34:06 --> Helper loaded: my_helper
INFO - 2023-09-22 14:34:06 --> Database Driver Class Initialized
INFO - 2023-09-22 14:34:06 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-22 14:34:06 --> Controller Class Initialized
INFO - 2023-09-22 14:34:06 --> Final output sent to browser
DEBUG - 2023-09-22 14:34:06 --> Total execution time: 0.0915
INFO - 2023-09-22 14:34:20 --> Config Class Initialized
INFO - 2023-09-22 14:34:20 --> Hooks Class Initialized
DEBUG - 2023-09-22 14:34:20 --> UTF-8 Support Enabled
INFO - 2023-09-22 14:34:20 --> Utf8 Class Initialized
INFO - 2023-09-22 14:34:20 --> URI Class Initialized
INFO - 2023-09-22 14:34:20 --> Router Class Initialized
INFO - 2023-09-22 14:34:20 --> Output Class Initialized
INFO - 2023-09-22 14:34:20 --> Security Class Initialized
DEBUG - 2023-09-22 14:34:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-22 14:34:20 --> Input Class Initialized
INFO - 2023-09-22 14:34:20 --> Language Class Initialized
INFO - 2023-09-22 14:34:20 --> Language Class Initialized
INFO - 2023-09-22 14:34:20 --> Config Class Initialized
INFO - 2023-09-22 14:34:20 --> Loader Class Initialized
INFO - 2023-09-22 14:34:20 --> Helper loaded: url_helper
INFO - 2023-09-22 14:34:20 --> Helper loaded: file_helper
INFO - 2023-09-22 14:34:20 --> Helper loaded: form_helper
INFO - 2023-09-22 14:34:20 --> Helper loaded: my_helper
INFO - 2023-09-22 14:34:20 --> Database Driver Class Initialized
INFO - 2023-09-22 14:34:20 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-22 14:34:20 --> Controller Class Initialized
INFO - 2023-09-22 14:34:20 --> Final output sent to browser
DEBUG - 2023-09-22 14:34:20 --> Total execution time: 0.3387
INFO - 2023-09-22 14:34:23 --> Config Class Initialized
INFO - 2023-09-22 14:34:23 --> Hooks Class Initialized
DEBUG - 2023-09-22 14:34:23 --> UTF-8 Support Enabled
INFO - 2023-09-22 14:34:23 --> Utf8 Class Initialized
INFO - 2023-09-22 14:34:23 --> URI Class Initialized
INFO - 2023-09-22 14:34:23 --> Router Class Initialized
INFO - 2023-09-22 14:34:23 --> Output Class Initialized
INFO - 2023-09-22 14:34:23 --> Security Class Initialized
DEBUG - 2023-09-22 14:34:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-22 14:34:23 --> Input Class Initialized
INFO - 2023-09-22 14:34:23 --> Language Class Initialized
INFO - 2023-09-22 14:34:23 --> Language Class Initialized
INFO - 2023-09-22 14:34:23 --> Config Class Initialized
INFO - 2023-09-22 14:34:23 --> Loader Class Initialized
INFO - 2023-09-22 14:34:23 --> Helper loaded: url_helper
INFO - 2023-09-22 14:34:23 --> Helper loaded: file_helper
INFO - 2023-09-22 14:34:23 --> Helper loaded: form_helper
INFO - 2023-09-22 14:34:23 --> Helper loaded: my_helper
INFO - 2023-09-22 14:34:23 --> Database Driver Class Initialized
INFO - 2023-09-22 14:34:23 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-22 14:34:23 --> Controller Class Initialized
INFO - 2023-09-22 14:34:23 --> Final output sent to browser
DEBUG - 2023-09-22 14:34:23 --> Total execution time: 0.0438
INFO - 2023-09-22 14:34:42 --> Config Class Initialized
INFO - 2023-09-22 14:34:42 --> Hooks Class Initialized
DEBUG - 2023-09-22 14:34:42 --> UTF-8 Support Enabled
INFO - 2023-09-22 14:34:42 --> Utf8 Class Initialized
INFO - 2023-09-22 14:34:42 --> URI Class Initialized
INFO - 2023-09-22 14:34:42 --> Router Class Initialized
INFO - 2023-09-22 14:34:42 --> Output Class Initialized
INFO - 2023-09-22 14:34:42 --> Security Class Initialized
DEBUG - 2023-09-22 14:34:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-22 14:34:42 --> Input Class Initialized
INFO - 2023-09-22 14:34:42 --> Language Class Initialized
INFO - 2023-09-22 14:34:42 --> Language Class Initialized
INFO - 2023-09-22 14:34:42 --> Config Class Initialized
INFO - 2023-09-22 14:34:42 --> Loader Class Initialized
INFO - 2023-09-22 14:34:42 --> Helper loaded: url_helper
INFO - 2023-09-22 14:34:42 --> Helper loaded: file_helper
INFO - 2023-09-22 14:34:42 --> Helper loaded: form_helper
INFO - 2023-09-22 14:34:42 --> Helper loaded: my_helper
INFO - 2023-09-22 14:34:42 --> Database Driver Class Initialized
INFO - 2023-09-22 14:34:42 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-22 14:34:42 --> Controller Class Initialized
INFO - 2023-09-22 14:34:42 --> Final output sent to browser
DEBUG - 2023-09-22 14:34:42 --> Total execution time: 0.0689
INFO - 2023-09-22 14:34:44 --> Config Class Initialized
INFO - 2023-09-22 14:34:44 --> Hooks Class Initialized
DEBUG - 2023-09-22 14:34:44 --> UTF-8 Support Enabled
INFO - 2023-09-22 14:34:44 --> Utf8 Class Initialized
INFO - 2023-09-22 14:34:44 --> URI Class Initialized
INFO - 2023-09-22 14:34:44 --> Router Class Initialized
INFO - 2023-09-22 14:34:44 --> Output Class Initialized
INFO - 2023-09-22 14:34:44 --> Security Class Initialized
DEBUG - 2023-09-22 14:34:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-22 14:34:44 --> Input Class Initialized
INFO - 2023-09-22 14:34:44 --> Language Class Initialized
INFO - 2023-09-22 14:34:44 --> Language Class Initialized
INFO - 2023-09-22 14:34:44 --> Config Class Initialized
INFO - 2023-09-22 14:34:44 --> Loader Class Initialized
INFO - 2023-09-22 14:34:44 --> Helper loaded: url_helper
INFO - 2023-09-22 14:34:44 --> Helper loaded: file_helper
INFO - 2023-09-22 14:34:44 --> Helper loaded: form_helper
INFO - 2023-09-22 14:34:44 --> Helper loaded: my_helper
INFO - 2023-09-22 14:34:44 --> Database Driver Class Initialized
INFO - 2023-09-22 14:34:44 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-22 14:34:44 --> Controller Class Initialized
INFO - 2023-09-22 14:35:34 --> Config Class Initialized
INFO - 2023-09-22 14:35:34 --> Hooks Class Initialized
DEBUG - 2023-09-22 14:35:34 --> UTF-8 Support Enabled
INFO - 2023-09-22 14:35:34 --> Utf8 Class Initialized
INFO - 2023-09-22 14:35:34 --> URI Class Initialized
INFO - 2023-09-22 14:35:34 --> Router Class Initialized
INFO - 2023-09-22 14:35:34 --> Output Class Initialized
INFO - 2023-09-22 14:35:34 --> Security Class Initialized
DEBUG - 2023-09-22 14:35:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-22 14:35:34 --> Input Class Initialized
INFO - 2023-09-22 14:35:34 --> Language Class Initialized
INFO - 2023-09-22 14:35:34 --> Language Class Initialized
INFO - 2023-09-22 14:35:34 --> Config Class Initialized
INFO - 2023-09-22 14:35:34 --> Loader Class Initialized
INFO - 2023-09-22 14:35:34 --> Helper loaded: url_helper
INFO - 2023-09-22 14:35:34 --> Helper loaded: file_helper
INFO - 2023-09-22 14:35:34 --> Helper loaded: form_helper
INFO - 2023-09-22 14:35:34 --> Helper loaded: my_helper
INFO - 2023-09-22 14:35:34 --> Database Driver Class Initialized
INFO - 2023-09-22 14:35:34 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-22 14:35:34 --> Controller Class Initialized
INFO - 2023-09-22 14:35:34 --> Final output sent to browser
DEBUG - 2023-09-22 14:35:34 --> Total execution time: 0.1552
INFO - 2023-09-22 14:35:36 --> Config Class Initialized
INFO - 2023-09-22 14:35:36 --> Hooks Class Initialized
DEBUG - 2023-09-22 14:35:36 --> UTF-8 Support Enabled
INFO - 2023-09-22 14:35:36 --> Utf8 Class Initialized
INFO - 2023-09-22 14:35:36 --> URI Class Initialized
INFO - 2023-09-22 14:35:36 --> Router Class Initialized
INFO - 2023-09-22 14:35:36 --> Output Class Initialized
INFO - 2023-09-22 14:35:36 --> Security Class Initialized
DEBUG - 2023-09-22 14:35:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-22 14:35:36 --> Input Class Initialized
INFO - 2023-09-22 14:35:36 --> Language Class Initialized
INFO - 2023-09-22 14:35:36 --> Language Class Initialized
INFO - 2023-09-22 14:35:36 --> Config Class Initialized
INFO - 2023-09-22 14:35:36 --> Loader Class Initialized
INFO - 2023-09-22 14:35:36 --> Helper loaded: url_helper
INFO - 2023-09-22 14:35:36 --> Helper loaded: file_helper
INFO - 2023-09-22 14:35:36 --> Helper loaded: form_helper
INFO - 2023-09-22 14:35:36 --> Helper loaded: my_helper
INFO - 2023-09-22 14:35:36 --> Database Driver Class Initialized
INFO - 2023-09-22 14:35:36 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-22 14:35:36 --> Controller Class Initialized
INFO - 2023-09-22 14:35:36 --> Final output sent to browser
DEBUG - 2023-09-22 14:35:36 --> Total execution time: 0.1268
INFO - 2023-09-22 14:35:44 --> Config Class Initialized
INFO - 2023-09-22 14:35:44 --> Hooks Class Initialized
DEBUG - 2023-09-22 14:35:44 --> UTF-8 Support Enabled
INFO - 2023-09-22 14:35:44 --> Utf8 Class Initialized
INFO - 2023-09-22 14:35:44 --> URI Class Initialized
INFO - 2023-09-22 14:35:44 --> Router Class Initialized
INFO - 2023-09-22 14:35:44 --> Output Class Initialized
INFO - 2023-09-22 14:35:44 --> Security Class Initialized
DEBUG - 2023-09-22 14:35:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-22 14:35:44 --> Input Class Initialized
INFO - 2023-09-22 14:35:44 --> Language Class Initialized
INFO - 2023-09-22 14:35:44 --> Language Class Initialized
INFO - 2023-09-22 14:35:44 --> Config Class Initialized
INFO - 2023-09-22 14:35:44 --> Loader Class Initialized
INFO - 2023-09-22 14:35:44 --> Helper loaded: url_helper
INFO - 2023-09-22 14:35:44 --> Helper loaded: file_helper
INFO - 2023-09-22 14:35:44 --> Helper loaded: form_helper
INFO - 2023-09-22 14:35:44 --> Helper loaded: my_helper
INFO - 2023-09-22 14:35:44 --> Database Driver Class Initialized
INFO - 2023-09-22 14:35:44 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-22 14:35:44 --> Controller Class Initialized
INFO - 2023-09-22 14:35:44 --> Final output sent to browser
DEBUG - 2023-09-22 14:35:44 --> Total execution time: 0.0386
INFO - 2023-09-22 14:40:33 --> Config Class Initialized
INFO - 2023-09-22 14:40:33 --> Hooks Class Initialized
DEBUG - 2023-09-22 14:40:33 --> UTF-8 Support Enabled
INFO - 2023-09-22 14:40:33 --> Utf8 Class Initialized
INFO - 2023-09-22 14:40:33 --> URI Class Initialized
INFO - 2023-09-22 14:40:33 --> Router Class Initialized
INFO - 2023-09-22 14:40:33 --> Output Class Initialized
INFO - 2023-09-22 14:40:33 --> Security Class Initialized
DEBUG - 2023-09-22 14:40:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-22 14:40:33 --> Input Class Initialized
INFO - 2023-09-22 14:40:33 --> Language Class Initialized
INFO - 2023-09-22 14:40:33 --> Language Class Initialized
INFO - 2023-09-22 14:40:33 --> Config Class Initialized
INFO - 2023-09-22 14:40:33 --> Loader Class Initialized
INFO - 2023-09-22 14:40:33 --> Helper loaded: url_helper
INFO - 2023-09-22 14:40:33 --> Helper loaded: file_helper
INFO - 2023-09-22 14:40:33 --> Helper loaded: form_helper
INFO - 2023-09-22 14:40:33 --> Helper loaded: my_helper
INFO - 2023-09-22 14:40:33 --> Database Driver Class Initialized
INFO - 2023-09-22 14:40:33 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-22 14:40:33 --> Controller Class Initialized
INFO - 2023-09-22 14:40:33 --> Final output sent to browser
DEBUG - 2023-09-22 14:40:33 --> Total execution time: 0.1787
INFO - 2023-09-22 14:43:41 --> Config Class Initialized
INFO - 2023-09-22 14:43:41 --> Hooks Class Initialized
DEBUG - 2023-09-22 14:43:41 --> UTF-8 Support Enabled
INFO - 2023-09-22 14:43:41 --> Utf8 Class Initialized
INFO - 2023-09-22 14:43:41 --> URI Class Initialized
INFO - 2023-09-22 14:43:41 --> Router Class Initialized
INFO - 2023-09-22 14:43:41 --> Output Class Initialized
INFO - 2023-09-22 14:43:41 --> Security Class Initialized
DEBUG - 2023-09-22 14:43:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-22 14:43:41 --> Input Class Initialized
INFO - 2023-09-22 14:43:41 --> Language Class Initialized
INFO - 2023-09-22 14:43:41 --> Language Class Initialized
INFO - 2023-09-22 14:43:41 --> Config Class Initialized
INFO - 2023-09-22 14:43:41 --> Loader Class Initialized
INFO - 2023-09-22 14:43:41 --> Helper loaded: url_helper
INFO - 2023-09-22 14:43:41 --> Helper loaded: file_helper
INFO - 2023-09-22 14:43:41 --> Helper loaded: form_helper
INFO - 2023-09-22 14:43:41 --> Helper loaded: my_helper
INFO - 2023-09-22 14:43:41 --> Database Driver Class Initialized
INFO - 2023-09-22 14:43:41 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-22 14:43:41 --> Controller Class Initialized
DEBUG - 2023-09-22 14:43:41 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_absensi/views/list.php
DEBUG - 2023-09-22 14:43:41 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-09-22 14:43:41 --> Final output sent to browser
DEBUG - 2023-09-22 14:43:41 --> Total execution time: 0.0871
INFO - 2023-09-22 14:46:06 --> Config Class Initialized
INFO - 2023-09-22 14:46:06 --> Hooks Class Initialized
DEBUG - 2023-09-22 14:46:06 --> UTF-8 Support Enabled
INFO - 2023-09-22 14:46:06 --> Utf8 Class Initialized
INFO - 2023-09-22 14:46:06 --> URI Class Initialized
DEBUG - 2023-09-22 14:46:06 --> No URI present. Default controller set.
INFO - 2023-09-22 14:46:06 --> Router Class Initialized
INFO - 2023-09-22 14:46:06 --> Output Class Initialized
INFO - 2023-09-22 14:46:06 --> Security Class Initialized
DEBUG - 2023-09-22 14:46:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-22 14:46:06 --> Input Class Initialized
INFO - 2023-09-22 14:46:06 --> Language Class Initialized
INFO - 2023-09-22 14:46:06 --> Language Class Initialized
INFO - 2023-09-22 14:46:06 --> Config Class Initialized
INFO - 2023-09-22 14:46:06 --> Loader Class Initialized
INFO - 2023-09-22 14:46:06 --> Helper loaded: url_helper
INFO - 2023-09-22 14:46:06 --> Helper loaded: file_helper
INFO - 2023-09-22 14:46:06 --> Helper loaded: form_helper
INFO - 2023-09-22 14:46:06 --> Helper loaded: my_helper
INFO - 2023-09-22 14:46:06 --> Database Driver Class Initialized
INFO - 2023-09-22 14:46:06 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-22 14:46:06 --> Controller Class Initialized
INFO - 2023-09-22 14:46:07 --> Config Class Initialized
INFO - 2023-09-22 14:46:07 --> Hooks Class Initialized
DEBUG - 2023-09-22 14:46:07 --> UTF-8 Support Enabled
INFO - 2023-09-22 14:46:07 --> Utf8 Class Initialized
INFO - 2023-09-22 14:46:07 --> URI Class Initialized
INFO - 2023-09-22 14:46:07 --> Router Class Initialized
INFO - 2023-09-22 14:46:07 --> Output Class Initialized
INFO - 2023-09-22 14:46:07 --> Security Class Initialized
DEBUG - 2023-09-22 14:46:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-22 14:46:07 --> Input Class Initialized
INFO - 2023-09-22 14:46:07 --> Language Class Initialized
INFO - 2023-09-22 14:46:07 --> Language Class Initialized
INFO - 2023-09-22 14:46:07 --> Config Class Initialized
INFO - 2023-09-22 14:46:07 --> Loader Class Initialized
INFO - 2023-09-22 14:46:07 --> Helper loaded: url_helper
INFO - 2023-09-22 14:46:07 --> Helper loaded: file_helper
INFO - 2023-09-22 14:46:07 --> Helper loaded: form_helper
INFO - 2023-09-22 14:46:07 --> Helper loaded: my_helper
INFO - 2023-09-22 14:46:07 --> Database Driver Class Initialized
INFO - 2023-09-22 14:46:07 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-22 14:46:07 --> Controller Class Initialized
DEBUG - 2023-09-22 14:46:07 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/login/views/login.php
DEBUG - 2023-09-22 14:46:07 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-09-22 14:46:07 --> Final output sent to browser
DEBUG - 2023-09-22 14:46:07 --> Total execution time: 0.0479
INFO - 2023-09-22 14:46:11 --> Config Class Initialized
INFO - 2023-09-22 14:46:11 --> Hooks Class Initialized
DEBUG - 2023-09-22 14:46:11 --> UTF-8 Support Enabled
INFO - 2023-09-22 14:46:11 --> Utf8 Class Initialized
INFO - 2023-09-22 14:46:11 --> URI Class Initialized
INFO - 2023-09-22 14:46:11 --> Router Class Initialized
INFO - 2023-09-22 14:46:11 --> Output Class Initialized
INFO - 2023-09-22 14:46:11 --> Security Class Initialized
DEBUG - 2023-09-22 14:46:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-22 14:46:11 --> Input Class Initialized
INFO - 2023-09-22 14:46:11 --> Language Class Initialized
INFO - 2023-09-22 14:46:11 --> Language Class Initialized
INFO - 2023-09-22 14:46:11 --> Config Class Initialized
INFO - 2023-09-22 14:46:11 --> Loader Class Initialized
INFO - 2023-09-22 14:46:11 --> Helper loaded: url_helper
INFO - 2023-09-22 14:46:11 --> Helper loaded: file_helper
INFO - 2023-09-22 14:46:11 --> Helper loaded: form_helper
INFO - 2023-09-22 14:46:11 --> Helper loaded: my_helper
INFO - 2023-09-22 14:46:11 --> Database Driver Class Initialized
INFO - 2023-09-22 14:46:11 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-22 14:46:11 --> Controller Class Initialized
INFO - 2023-09-22 14:46:11 --> Helper loaded: cookie_helper
INFO - 2023-09-22 14:46:11 --> Final output sent to browser
DEBUG - 2023-09-22 14:46:11 --> Total execution time: 0.0444
INFO - 2023-09-22 14:46:11 --> Config Class Initialized
INFO - 2023-09-22 14:46:11 --> Hooks Class Initialized
DEBUG - 2023-09-22 14:46:11 --> UTF-8 Support Enabled
INFO - 2023-09-22 14:46:11 --> Utf8 Class Initialized
INFO - 2023-09-22 14:46:11 --> URI Class Initialized
INFO - 2023-09-22 14:46:11 --> Router Class Initialized
INFO - 2023-09-22 14:46:11 --> Output Class Initialized
INFO - 2023-09-22 14:46:11 --> Security Class Initialized
DEBUG - 2023-09-22 14:46:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-22 14:46:11 --> Input Class Initialized
INFO - 2023-09-22 14:46:11 --> Language Class Initialized
INFO - 2023-09-22 14:46:11 --> Language Class Initialized
INFO - 2023-09-22 14:46:11 --> Config Class Initialized
INFO - 2023-09-22 14:46:11 --> Loader Class Initialized
INFO - 2023-09-22 14:46:11 --> Helper loaded: url_helper
INFO - 2023-09-22 14:46:11 --> Helper loaded: file_helper
INFO - 2023-09-22 14:46:11 --> Helper loaded: form_helper
INFO - 2023-09-22 14:46:11 --> Helper loaded: my_helper
INFO - 2023-09-22 14:46:11 --> Database Driver Class Initialized
INFO - 2023-09-22 14:46:11 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-22 14:46:11 --> Controller Class Initialized
DEBUG - 2023-09-22 14:46:11 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/home/views/v_home.php
DEBUG - 2023-09-22 14:46:11 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-09-22 14:46:11 --> Final output sent to browser
DEBUG - 2023-09-22 14:46:11 --> Total execution time: 0.0453
INFO - 2023-09-22 14:46:14 --> Config Class Initialized
INFO - 2023-09-22 14:46:14 --> Hooks Class Initialized
DEBUG - 2023-09-22 14:46:14 --> UTF-8 Support Enabled
INFO - 2023-09-22 14:46:14 --> Utf8 Class Initialized
INFO - 2023-09-22 14:46:14 --> URI Class Initialized
INFO - 2023-09-22 14:46:14 --> Router Class Initialized
INFO - 2023-09-22 14:46:14 --> Output Class Initialized
INFO - 2023-09-22 14:46:14 --> Security Class Initialized
DEBUG - 2023-09-22 14:46:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-22 14:46:14 --> Input Class Initialized
INFO - 2023-09-22 14:46:14 --> Language Class Initialized
INFO - 2023-09-22 14:46:14 --> Language Class Initialized
INFO - 2023-09-22 14:46:14 --> Config Class Initialized
INFO - 2023-09-22 14:46:14 --> Loader Class Initialized
INFO - 2023-09-22 14:46:14 --> Helper loaded: url_helper
INFO - 2023-09-22 14:46:14 --> Helper loaded: file_helper
INFO - 2023-09-22 14:46:14 --> Helper loaded: form_helper
INFO - 2023-09-22 14:46:14 --> Helper loaded: my_helper
INFO - 2023-09-22 14:46:14 --> Database Driver Class Initialized
INFO - 2023-09-22 14:46:14 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-22 14:46:14 --> Controller Class Initialized
DEBUG - 2023-09-22 14:46:14 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/data_guru/views/list.php
DEBUG - 2023-09-22 14:46:14 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-09-22 14:46:14 --> Final output sent to browser
DEBUG - 2023-09-22 14:46:14 --> Total execution time: 0.0328
INFO - 2023-09-22 14:46:14 --> Config Class Initialized
INFO - 2023-09-22 14:46:14 --> Hooks Class Initialized
DEBUG - 2023-09-22 14:46:14 --> UTF-8 Support Enabled
INFO - 2023-09-22 14:46:14 --> Utf8 Class Initialized
INFO - 2023-09-22 14:46:14 --> URI Class Initialized
INFO - 2023-09-22 14:46:14 --> Router Class Initialized
INFO - 2023-09-22 14:46:14 --> Output Class Initialized
INFO - 2023-09-22 14:46:14 --> Security Class Initialized
DEBUG - 2023-09-22 14:46:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-22 14:46:14 --> Input Class Initialized
INFO - 2023-09-22 14:46:14 --> Language Class Initialized
ERROR - 2023-09-22 14:46:14 --> 404 Page Not Found: /index
INFO - 2023-09-22 14:46:14 --> Config Class Initialized
INFO - 2023-09-22 14:46:14 --> Hooks Class Initialized
DEBUG - 2023-09-22 14:46:14 --> UTF-8 Support Enabled
INFO - 2023-09-22 14:46:14 --> Utf8 Class Initialized
INFO - 2023-09-22 14:46:14 --> URI Class Initialized
INFO - 2023-09-22 14:46:14 --> Router Class Initialized
INFO - 2023-09-22 14:46:14 --> Output Class Initialized
INFO - 2023-09-22 14:46:14 --> Security Class Initialized
DEBUG - 2023-09-22 14:46:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-22 14:46:14 --> Input Class Initialized
INFO - 2023-09-22 14:46:14 --> Language Class Initialized
INFO - 2023-09-22 14:46:14 --> Language Class Initialized
INFO - 2023-09-22 14:46:14 --> Config Class Initialized
INFO - 2023-09-22 14:46:14 --> Loader Class Initialized
INFO - 2023-09-22 14:46:14 --> Helper loaded: url_helper
INFO - 2023-09-22 14:46:14 --> Helper loaded: file_helper
INFO - 2023-09-22 14:46:14 --> Helper loaded: form_helper
INFO - 2023-09-22 14:46:14 --> Helper loaded: my_helper
INFO - 2023-09-22 14:46:14 --> Database Driver Class Initialized
INFO - 2023-09-22 14:46:14 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-22 14:46:14 --> Controller Class Initialized
INFO - 2023-09-22 14:46:15 --> Config Class Initialized
INFO - 2023-09-22 14:46:15 --> Hooks Class Initialized
DEBUG - 2023-09-22 14:46:15 --> UTF-8 Support Enabled
INFO - 2023-09-22 14:46:15 --> Utf8 Class Initialized
INFO - 2023-09-22 14:46:15 --> URI Class Initialized
INFO - 2023-09-22 14:46:15 --> Router Class Initialized
INFO - 2023-09-22 14:46:15 --> Output Class Initialized
INFO - 2023-09-22 14:46:15 --> Security Class Initialized
DEBUG - 2023-09-22 14:46:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-22 14:46:15 --> Input Class Initialized
INFO - 2023-09-22 14:46:15 --> Language Class Initialized
INFO - 2023-09-22 14:46:15 --> Language Class Initialized
INFO - 2023-09-22 14:46:15 --> Config Class Initialized
INFO - 2023-09-22 14:46:15 --> Loader Class Initialized
INFO - 2023-09-22 14:46:15 --> Helper loaded: url_helper
INFO - 2023-09-22 14:46:15 --> Helper loaded: file_helper
INFO - 2023-09-22 14:46:15 --> Helper loaded: form_helper
INFO - 2023-09-22 14:46:15 --> Helper loaded: my_helper
INFO - 2023-09-22 14:46:15 --> Database Driver Class Initialized
INFO - 2023-09-22 14:46:15 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-22 14:46:15 --> Controller Class Initialized
DEBUG - 2023-09-22 14:46:15 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/set_walikelas/views/list.php
DEBUG - 2023-09-22 14:46:15 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-09-22 14:46:15 --> Final output sent to browser
DEBUG - 2023-09-22 14:46:15 --> Total execution time: 0.0573
INFO - 2023-09-22 14:46:16 --> Config Class Initialized
INFO - 2023-09-22 14:46:16 --> Hooks Class Initialized
DEBUG - 2023-09-22 14:46:16 --> UTF-8 Support Enabled
INFO - 2023-09-22 14:46:16 --> Utf8 Class Initialized
INFO - 2023-09-22 14:46:16 --> URI Class Initialized
INFO - 2023-09-22 14:46:16 --> Router Class Initialized
INFO - 2023-09-22 14:46:16 --> Output Class Initialized
INFO - 2023-09-22 14:46:16 --> Security Class Initialized
DEBUG - 2023-09-22 14:46:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-22 14:46:16 --> Input Class Initialized
INFO - 2023-09-22 14:46:16 --> Language Class Initialized
ERROR - 2023-09-22 14:46:16 --> 404 Page Not Found: /index
INFO - 2023-09-22 14:46:16 --> Config Class Initialized
INFO - 2023-09-22 14:46:16 --> Hooks Class Initialized
DEBUG - 2023-09-22 14:46:16 --> UTF-8 Support Enabled
INFO - 2023-09-22 14:46:16 --> Utf8 Class Initialized
INFO - 2023-09-22 14:46:16 --> URI Class Initialized
INFO - 2023-09-22 14:46:16 --> Router Class Initialized
INFO - 2023-09-22 14:46:16 --> Output Class Initialized
INFO - 2023-09-22 14:46:16 --> Security Class Initialized
DEBUG - 2023-09-22 14:46:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-22 14:46:16 --> Input Class Initialized
INFO - 2023-09-22 14:46:16 --> Language Class Initialized
INFO - 2023-09-22 14:46:16 --> Language Class Initialized
INFO - 2023-09-22 14:46:16 --> Config Class Initialized
INFO - 2023-09-22 14:46:16 --> Loader Class Initialized
INFO - 2023-09-22 14:46:16 --> Helper loaded: url_helper
INFO - 2023-09-22 14:46:16 --> Helper loaded: file_helper
INFO - 2023-09-22 14:46:16 --> Helper loaded: form_helper
INFO - 2023-09-22 14:46:16 --> Helper loaded: my_helper
INFO - 2023-09-22 14:46:16 --> Database Driver Class Initialized
INFO - 2023-09-22 14:46:16 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-22 14:46:16 --> Controller Class Initialized
INFO - 2023-09-22 14:46:18 --> Config Class Initialized
INFO - 2023-09-22 14:46:18 --> Hooks Class Initialized
DEBUG - 2023-09-22 14:46:18 --> UTF-8 Support Enabled
INFO - 2023-09-22 14:46:18 --> Utf8 Class Initialized
INFO - 2023-09-22 14:46:18 --> URI Class Initialized
INFO - 2023-09-22 14:46:18 --> Router Class Initialized
INFO - 2023-09-22 14:46:18 --> Output Class Initialized
INFO - 2023-09-22 14:46:18 --> Security Class Initialized
DEBUG - 2023-09-22 14:46:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-22 14:46:18 --> Input Class Initialized
INFO - 2023-09-22 14:46:18 --> Language Class Initialized
INFO - 2023-09-22 14:46:18 --> Language Class Initialized
INFO - 2023-09-22 14:46:18 --> Config Class Initialized
INFO - 2023-09-22 14:46:18 --> Loader Class Initialized
INFO - 2023-09-22 14:46:18 --> Helper loaded: url_helper
INFO - 2023-09-22 14:46:18 --> Helper loaded: file_helper
INFO - 2023-09-22 14:46:18 --> Helper loaded: form_helper
INFO - 2023-09-22 14:46:18 --> Helper loaded: my_helper
INFO - 2023-09-22 14:46:18 --> Database Driver Class Initialized
INFO - 2023-09-22 14:46:18 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-22 14:46:18 --> Controller Class Initialized
DEBUG - 2023-09-22 14:46:18 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/data_guru/views/list.php
DEBUG - 2023-09-22 14:46:18 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-09-22 14:46:18 --> Final output sent to browser
DEBUG - 2023-09-22 14:46:18 --> Total execution time: 0.0349
INFO - 2023-09-22 14:46:18 --> Config Class Initialized
INFO - 2023-09-22 14:46:18 --> Hooks Class Initialized
DEBUG - 2023-09-22 14:46:18 --> UTF-8 Support Enabled
INFO - 2023-09-22 14:46:18 --> Utf8 Class Initialized
INFO - 2023-09-22 14:46:18 --> URI Class Initialized
INFO - 2023-09-22 14:46:18 --> Router Class Initialized
INFO - 2023-09-22 14:46:18 --> Output Class Initialized
INFO - 2023-09-22 14:46:18 --> Security Class Initialized
DEBUG - 2023-09-22 14:46:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-22 14:46:18 --> Input Class Initialized
INFO - 2023-09-22 14:46:18 --> Language Class Initialized
ERROR - 2023-09-22 14:46:18 --> 404 Page Not Found: /index
INFO - 2023-09-22 14:46:18 --> Config Class Initialized
INFO - 2023-09-22 14:46:18 --> Hooks Class Initialized
DEBUG - 2023-09-22 14:46:18 --> UTF-8 Support Enabled
INFO - 2023-09-22 14:46:18 --> Utf8 Class Initialized
INFO - 2023-09-22 14:46:18 --> URI Class Initialized
INFO - 2023-09-22 14:46:18 --> Router Class Initialized
INFO - 2023-09-22 14:46:18 --> Output Class Initialized
INFO - 2023-09-22 14:46:18 --> Security Class Initialized
DEBUG - 2023-09-22 14:46:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-22 14:46:18 --> Input Class Initialized
INFO - 2023-09-22 14:46:18 --> Language Class Initialized
INFO - 2023-09-22 14:46:18 --> Language Class Initialized
INFO - 2023-09-22 14:46:18 --> Config Class Initialized
INFO - 2023-09-22 14:46:18 --> Loader Class Initialized
INFO - 2023-09-22 14:46:18 --> Helper loaded: url_helper
INFO - 2023-09-22 14:46:18 --> Helper loaded: file_helper
INFO - 2023-09-22 14:46:18 --> Helper loaded: form_helper
INFO - 2023-09-22 14:46:18 --> Helper loaded: my_helper
INFO - 2023-09-22 14:46:18 --> Database Driver Class Initialized
INFO - 2023-09-22 14:46:18 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-22 14:46:18 --> Controller Class Initialized
INFO - 2023-09-22 14:46:20 --> Config Class Initialized
INFO - 2023-09-22 14:46:20 --> Hooks Class Initialized
DEBUG - 2023-09-22 14:46:20 --> UTF-8 Support Enabled
INFO - 2023-09-22 14:46:20 --> Utf8 Class Initialized
INFO - 2023-09-22 14:46:20 --> URI Class Initialized
INFO - 2023-09-22 14:46:20 --> Router Class Initialized
INFO - 2023-09-22 14:46:20 --> Output Class Initialized
INFO - 2023-09-22 14:46:20 --> Security Class Initialized
DEBUG - 2023-09-22 14:46:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-22 14:46:20 --> Input Class Initialized
INFO - 2023-09-22 14:46:20 --> Language Class Initialized
INFO - 2023-09-22 14:46:20 --> Language Class Initialized
INFO - 2023-09-22 14:46:20 --> Config Class Initialized
INFO - 2023-09-22 14:46:20 --> Loader Class Initialized
INFO - 2023-09-22 14:46:20 --> Helper loaded: url_helper
INFO - 2023-09-22 14:46:20 --> Helper loaded: file_helper
INFO - 2023-09-22 14:46:20 --> Helper loaded: form_helper
INFO - 2023-09-22 14:46:20 --> Helper loaded: my_helper
INFO - 2023-09-22 14:46:20 --> Database Driver Class Initialized
INFO - 2023-09-22 14:46:20 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-22 14:46:20 --> Controller Class Initialized
INFO - 2023-09-22 14:46:22 --> Config Class Initialized
INFO - 2023-09-22 14:46:22 --> Hooks Class Initialized
DEBUG - 2023-09-22 14:46:22 --> UTF-8 Support Enabled
INFO - 2023-09-22 14:46:22 --> Utf8 Class Initialized
INFO - 2023-09-22 14:46:22 --> URI Class Initialized
INFO - 2023-09-22 14:46:22 --> Router Class Initialized
INFO - 2023-09-22 14:46:22 --> Output Class Initialized
INFO - 2023-09-22 14:46:22 --> Security Class Initialized
DEBUG - 2023-09-22 14:46:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-22 14:46:22 --> Input Class Initialized
INFO - 2023-09-22 14:46:22 --> Language Class Initialized
INFO - 2023-09-22 14:46:22 --> Language Class Initialized
INFO - 2023-09-22 14:46:22 --> Config Class Initialized
INFO - 2023-09-22 14:46:22 --> Loader Class Initialized
INFO - 2023-09-22 14:46:22 --> Helper loaded: url_helper
INFO - 2023-09-22 14:46:22 --> Helper loaded: file_helper
INFO - 2023-09-22 14:46:22 --> Helper loaded: form_helper
INFO - 2023-09-22 14:46:22 --> Helper loaded: my_helper
INFO - 2023-09-22 14:46:22 --> Database Driver Class Initialized
INFO - 2023-09-22 14:46:22 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-22 14:46:22 --> Controller Class Initialized
INFO - 2023-09-22 14:46:22 --> Helper loaded: cookie_helper
INFO - 2023-09-22 14:46:22 --> Config Class Initialized
INFO - 2023-09-22 14:46:22 --> Hooks Class Initialized
DEBUG - 2023-09-22 14:46:22 --> UTF-8 Support Enabled
INFO - 2023-09-22 14:46:22 --> Utf8 Class Initialized
INFO - 2023-09-22 14:46:22 --> URI Class Initialized
INFO - 2023-09-22 14:46:22 --> Router Class Initialized
INFO - 2023-09-22 14:46:22 --> Output Class Initialized
INFO - 2023-09-22 14:46:22 --> Security Class Initialized
DEBUG - 2023-09-22 14:46:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-22 14:46:22 --> Input Class Initialized
INFO - 2023-09-22 14:46:22 --> Language Class Initialized
INFO - 2023-09-22 14:46:22 --> Language Class Initialized
INFO - 2023-09-22 14:46:22 --> Config Class Initialized
INFO - 2023-09-22 14:46:22 --> Loader Class Initialized
INFO - 2023-09-22 14:46:22 --> Helper loaded: url_helper
INFO - 2023-09-22 14:46:22 --> Helper loaded: file_helper
INFO - 2023-09-22 14:46:22 --> Helper loaded: form_helper
INFO - 2023-09-22 14:46:22 --> Helper loaded: my_helper
INFO - 2023-09-22 14:46:22 --> Database Driver Class Initialized
INFO - 2023-09-22 14:46:22 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-22 14:46:22 --> Controller Class Initialized
INFO - 2023-09-22 14:46:22 --> Config Class Initialized
INFO - 2023-09-22 14:46:22 --> Hooks Class Initialized
DEBUG - 2023-09-22 14:46:22 --> UTF-8 Support Enabled
INFO - 2023-09-22 14:46:22 --> Utf8 Class Initialized
INFO - 2023-09-22 14:46:22 --> URI Class Initialized
INFO - 2023-09-22 14:46:22 --> Router Class Initialized
INFO - 2023-09-22 14:46:22 --> Output Class Initialized
INFO - 2023-09-22 14:46:22 --> Security Class Initialized
DEBUG - 2023-09-22 14:46:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-22 14:46:22 --> Input Class Initialized
INFO - 2023-09-22 14:46:22 --> Language Class Initialized
INFO - 2023-09-22 14:46:22 --> Language Class Initialized
INFO - 2023-09-22 14:46:22 --> Config Class Initialized
INFO - 2023-09-22 14:46:22 --> Loader Class Initialized
INFO - 2023-09-22 14:46:22 --> Helper loaded: url_helper
INFO - 2023-09-22 14:46:22 --> Helper loaded: file_helper
INFO - 2023-09-22 14:46:22 --> Helper loaded: form_helper
INFO - 2023-09-22 14:46:22 --> Helper loaded: my_helper
INFO - 2023-09-22 14:46:22 --> Database Driver Class Initialized
INFO - 2023-09-22 14:46:22 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-22 14:46:22 --> Controller Class Initialized
DEBUG - 2023-09-22 14:46:22 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/login/views/login.php
DEBUG - 2023-09-22 14:46:22 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-09-22 14:46:22 --> Final output sent to browser
DEBUG - 2023-09-22 14:46:22 --> Total execution time: 0.0551
INFO - 2023-09-22 14:46:25 --> Config Class Initialized
INFO - 2023-09-22 14:46:25 --> Hooks Class Initialized
DEBUG - 2023-09-22 14:46:25 --> UTF-8 Support Enabled
INFO - 2023-09-22 14:46:25 --> Utf8 Class Initialized
INFO - 2023-09-22 14:46:25 --> URI Class Initialized
INFO - 2023-09-22 14:46:25 --> Router Class Initialized
INFO - 2023-09-22 14:46:25 --> Output Class Initialized
INFO - 2023-09-22 14:46:25 --> Security Class Initialized
DEBUG - 2023-09-22 14:46:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-22 14:46:25 --> Input Class Initialized
INFO - 2023-09-22 14:46:25 --> Language Class Initialized
INFO - 2023-09-22 14:46:25 --> Language Class Initialized
INFO - 2023-09-22 14:46:25 --> Config Class Initialized
INFO - 2023-09-22 14:46:25 --> Loader Class Initialized
INFO - 2023-09-22 14:46:25 --> Helper loaded: url_helper
INFO - 2023-09-22 14:46:25 --> Helper loaded: file_helper
INFO - 2023-09-22 14:46:25 --> Helper loaded: form_helper
INFO - 2023-09-22 14:46:25 --> Helper loaded: my_helper
INFO - 2023-09-22 14:46:25 --> Database Driver Class Initialized
INFO - 2023-09-22 14:46:25 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-22 14:46:25 --> Controller Class Initialized
INFO - 2023-09-22 14:46:25 --> Helper loaded: cookie_helper
INFO - 2023-09-22 14:46:25 --> Final output sent to browser
DEBUG - 2023-09-22 14:46:25 --> Total execution time: 0.0362
INFO - 2023-09-22 14:46:25 --> Config Class Initialized
INFO - 2023-09-22 14:46:25 --> Hooks Class Initialized
DEBUG - 2023-09-22 14:46:25 --> UTF-8 Support Enabled
INFO - 2023-09-22 14:46:25 --> Utf8 Class Initialized
INFO - 2023-09-22 14:46:25 --> URI Class Initialized
INFO - 2023-09-22 14:46:25 --> Router Class Initialized
INFO - 2023-09-22 14:46:25 --> Output Class Initialized
INFO - 2023-09-22 14:46:25 --> Security Class Initialized
DEBUG - 2023-09-22 14:46:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-22 14:46:25 --> Input Class Initialized
INFO - 2023-09-22 14:46:25 --> Language Class Initialized
INFO - 2023-09-22 14:46:25 --> Language Class Initialized
INFO - 2023-09-22 14:46:25 --> Config Class Initialized
INFO - 2023-09-22 14:46:25 --> Loader Class Initialized
INFO - 2023-09-22 14:46:25 --> Helper loaded: url_helper
INFO - 2023-09-22 14:46:25 --> Helper loaded: file_helper
INFO - 2023-09-22 14:46:25 --> Helper loaded: form_helper
INFO - 2023-09-22 14:46:25 --> Helper loaded: my_helper
INFO - 2023-09-22 14:46:25 --> Database Driver Class Initialized
INFO - 2023-09-22 14:46:25 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-22 14:46:25 --> Controller Class Initialized
DEBUG - 2023-09-22 14:46:25 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/home/views/v_home_guru.php
DEBUG - 2023-09-22 14:46:25 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-09-22 14:46:25 --> Final output sent to browser
DEBUG - 2023-09-22 14:46:25 --> Total execution time: 0.0513
INFO - 2023-09-22 14:46:27 --> Config Class Initialized
INFO - 2023-09-22 14:46:27 --> Hooks Class Initialized
DEBUG - 2023-09-22 14:46:27 --> UTF-8 Support Enabled
INFO - 2023-09-22 14:46:27 --> Utf8 Class Initialized
INFO - 2023-09-22 14:46:27 --> URI Class Initialized
INFO - 2023-09-22 14:46:27 --> Router Class Initialized
INFO - 2023-09-22 14:46:27 --> Output Class Initialized
INFO - 2023-09-22 14:46:27 --> Security Class Initialized
DEBUG - 2023-09-22 14:46:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-22 14:46:27 --> Input Class Initialized
INFO - 2023-09-22 14:46:27 --> Language Class Initialized
INFO - 2023-09-22 14:46:27 --> Language Class Initialized
INFO - 2023-09-22 14:46:27 --> Config Class Initialized
INFO - 2023-09-22 14:46:27 --> Loader Class Initialized
INFO - 2023-09-22 14:46:27 --> Helper loaded: url_helper
INFO - 2023-09-22 14:46:27 --> Helper loaded: file_helper
INFO - 2023-09-22 14:46:27 --> Helper loaded: form_helper
INFO - 2023-09-22 14:46:27 --> Helper loaded: my_helper
INFO - 2023-09-22 14:46:27 --> Database Driver Class Initialized
INFO - 2023-09-22 14:46:27 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-22 14:46:27 --> Controller Class Initialized
DEBUG - 2023-09-22 14:46:27 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/view_mapel/views/v_view_mapel.php
DEBUG - 2023-09-22 14:46:27 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-09-22 14:46:27 --> Final output sent to browser
DEBUG - 2023-09-22 14:46:27 --> Total execution time: 0.0313
INFO - 2023-09-22 14:47:05 --> Config Class Initialized
INFO - 2023-09-22 14:47:05 --> Hooks Class Initialized
DEBUG - 2023-09-22 14:47:05 --> UTF-8 Support Enabled
INFO - 2023-09-22 14:47:05 --> Utf8 Class Initialized
INFO - 2023-09-22 14:47:05 --> URI Class Initialized
INFO - 2023-09-22 14:47:05 --> Router Class Initialized
INFO - 2023-09-22 14:47:05 --> Output Class Initialized
INFO - 2023-09-22 14:47:05 --> Security Class Initialized
DEBUG - 2023-09-22 14:47:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-22 14:47:05 --> Input Class Initialized
INFO - 2023-09-22 14:47:05 --> Language Class Initialized
INFO - 2023-09-22 14:47:05 --> Language Class Initialized
INFO - 2023-09-22 14:47:05 --> Config Class Initialized
INFO - 2023-09-22 14:47:05 --> Loader Class Initialized
INFO - 2023-09-22 14:47:05 --> Helper loaded: url_helper
INFO - 2023-09-22 14:47:05 --> Helper loaded: file_helper
INFO - 2023-09-22 14:47:05 --> Helper loaded: form_helper
INFO - 2023-09-22 14:47:05 --> Helper loaded: my_helper
INFO - 2023-09-22 14:47:05 --> Database Driver Class Initialized
INFO - 2023-09-22 14:47:05 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-22 14:47:05 --> Controller Class Initialized
DEBUG - 2023-09-22 14:47:05 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/views/list.php
DEBUG - 2023-09-22 14:47:05 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-09-22 14:47:05 --> Final output sent to browser
DEBUG - 2023-09-22 14:47:05 --> Total execution time: 0.0896
INFO - 2023-09-22 14:47:06 --> Config Class Initialized
INFO - 2023-09-22 14:47:06 --> Hooks Class Initialized
DEBUG - 2023-09-22 14:47:06 --> UTF-8 Support Enabled
INFO - 2023-09-22 14:47:06 --> Utf8 Class Initialized
INFO - 2023-09-22 14:47:06 --> URI Class Initialized
INFO - 2023-09-22 14:47:06 --> Router Class Initialized
INFO - 2023-09-22 14:47:06 --> Output Class Initialized
INFO - 2023-09-22 14:47:06 --> Security Class Initialized
DEBUG - 2023-09-22 14:47:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-22 14:47:06 --> Input Class Initialized
INFO - 2023-09-22 14:47:06 --> Language Class Initialized
INFO - 2023-09-22 14:47:06 --> Language Class Initialized
INFO - 2023-09-22 14:47:06 --> Config Class Initialized
INFO - 2023-09-22 14:47:06 --> Loader Class Initialized
INFO - 2023-09-22 14:47:06 --> Helper loaded: url_helper
INFO - 2023-09-22 14:47:06 --> Helper loaded: file_helper
INFO - 2023-09-22 14:47:06 --> Helper loaded: form_helper
INFO - 2023-09-22 14:47:06 --> Helper loaded: my_helper
INFO - 2023-09-22 14:47:06 --> Database Driver Class Initialized
INFO - 2023-09-22 14:47:06 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-22 14:47:06 --> Controller Class Initialized
INFO - 2023-09-22 14:47:48 --> Config Class Initialized
INFO - 2023-09-22 14:47:48 --> Hooks Class Initialized
DEBUG - 2023-09-22 14:47:48 --> UTF-8 Support Enabled
INFO - 2023-09-22 14:47:48 --> Utf8 Class Initialized
INFO - 2023-09-22 14:47:48 --> URI Class Initialized
INFO - 2023-09-22 14:47:48 --> Router Class Initialized
INFO - 2023-09-22 14:47:48 --> Output Class Initialized
INFO - 2023-09-22 14:47:48 --> Security Class Initialized
DEBUG - 2023-09-22 14:47:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-22 14:47:48 --> Input Class Initialized
INFO - 2023-09-22 14:47:48 --> Language Class Initialized
INFO - 2023-09-22 14:47:48 --> Language Class Initialized
INFO - 2023-09-22 14:47:48 --> Config Class Initialized
INFO - 2023-09-22 14:47:48 --> Loader Class Initialized
INFO - 2023-09-22 14:47:48 --> Helper loaded: url_helper
INFO - 2023-09-22 14:47:48 --> Helper loaded: file_helper
INFO - 2023-09-22 14:47:48 --> Helper loaded: form_helper
INFO - 2023-09-22 14:47:48 --> Helper loaded: my_helper
INFO - 2023-09-22 14:47:48 --> Database Driver Class Initialized
INFO - 2023-09-22 14:47:48 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-22 14:47:48 --> Controller Class Initialized
DEBUG - 2023-09-22 14:47:48 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/view_mapel/views/v_view_mapel.php
DEBUG - 2023-09-22 14:47:48 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-09-22 14:47:48 --> Final output sent to browser
DEBUG - 2023-09-22 14:47:48 --> Total execution time: 0.0416
INFO - 2023-09-22 14:47:52 --> Config Class Initialized
INFO - 2023-09-22 14:47:52 --> Hooks Class Initialized
DEBUG - 2023-09-22 14:47:52 --> UTF-8 Support Enabled
INFO - 2023-09-22 14:47:52 --> Utf8 Class Initialized
INFO - 2023-09-22 14:47:52 --> URI Class Initialized
INFO - 2023-09-22 14:47:52 --> Router Class Initialized
INFO - 2023-09-22 14:47:52 --> Output Class Initialized
INFO - 2023-09-22 14:47:52 --> Security Class Initialized
DEBUG - 2023-09-22 14:47:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-22 14:47:52 --> Input Class Initialized
INFO - 2023-09-22 14:47:52 --> Language Class Initialized
INFO - 2023-09-22 14:47:52 --> Language Class Initialized
INFO - 2023-09-22 14:47:52 --> Config Class Initialized
INFO - 2023-09-22 14:47:52 --> Loader Class Initialized
INFO - 2023-09-22 14:47:52 --> Helper loaded: url_helper
INFO - 2023-09-22 14:47:52 --> Helper loaded: file_helper
INFO - 2023-09-22 14:47:52 --> Helper loaded: form_helper
INFO - 2023-09-22 14:47:52 --> Helper loaded: my_helper
INFO - 2023-09-22 14:47:52 --> Database Driver Class Initialized
INFO - 2023-09-22 14:47:52 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-22 14:47:52 --> Controller Class Initialized
DEBUG - 2023-09-22 14:47:52 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_la/views/list.php
DEBUG - 2023-09-22 14:47:52 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-09-22 14:47:52 --> Final output sent to browser
DEBUG - 2023-09-22 14:47:52 --> Total execution time: 0.0418
INFO - 2023-09-22 14:47:52 --> Config Class Initialized
INFO - 2023-09-22 14:47:52 --> Hooks Class Initialized
DEBUG - 2023-09-22 14:47:52 --> UTF-8 Support Enabled
INFO - 2023-09-22 14:47:52 --> Utf8 Class Initialized
INFO - 2023-09-22 14:47:52 --> URI Class Initialized
INFO - 2023-09-22 14:47:52 --> Router Class Initialized
INFO - 2023-09-22 14:47:52 --> Output Class Initialized
INFO - 2023-09-22 14:47:52 --> Security Class Initialized
DEBUG - 2023-09-22 14:47:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-22 14:47:52 --> Input Class Initialized
INFO - 2023-09-22 14:47:52 --> Language Class Initialized
INFO - 2023-09-22 14:47:52 --> Language Class Initialized
INFO - 2023-09-22 14:47:52 --> Config Class Initialized
INFO - 2023-09-22 14:47:52 --> Loader Class Initialized
INFO - 2023-09-22 14:47:52 --> Helper loaded: url_helper
INFO - 2023-09-22 14:47:52 --> Helper loaded: file_helper
INFO - 2023-09-22 14:47:52 --> Helper loaded: form_helper
INFO - 2023-09-22 14:47:52 --> Helper loaded: my_helper
INFO - 2023-09-22 14:47:52 --> Database Driver Class Initialized
INFO - 2023-09-22 14:47:52 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-22 14:47:52 --> Controller Class Initialized
INFO - 2023-09-22 14:47:53 --> Config Class Initialized
INFO - 2023-09-22 14:47:53 --> Hooks Class Initialized
DEBUG - 2023-09-22 14:47:53 --> UTF-8 Support Enabled
INFO - 2023-09-22 14:47:53 --> Utf8 Class Initialized
INFO - 2023-09-22 14:47:53 --> URI Class Initialized
INFO - 2023-09-22 14:47:53 --> Router Class Initialized
INFO - 2023-09-22 14:47:53 --> Output Class Initialized
INFO - 2023-09-22 14:47:53 --> Security Class Initialized
DEBUG - 2023-09-22 14:47:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-22 14:47:53 --> Input Class Initialized
INFO - 2023-09-22 14:47:53 --> Language Class Initialized
INFO - 2023-09-22 14:47:53 --> Language Class Initialized
INFO - 2023-09-22 14:47:53 --> Config Class Initialized
INFO - 2023-09-22 14:47:53 --> Loader Class Initialized
INFO - 2023-09-22 14:47:53 --> Helper loaded: url_helper
INFO - 2023-09-22 14:47:53 --> Helper loaded: file_helper
INFO - 2023-09-22 14:47:53 --> Helper loaded: form_helper
INFO - 2023-09-22 14:47:53 --> Helper loaded: my_helper
INFO - 2023-09-22 14:47:53 --> Database Driver Class Initialized
INFO - 2023-09-22 14:47:53 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-22 14:47:53 --> Controller Class Initialized
DEBUG - 2023-09-22 14:47:53 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/view_mapel/views/v_view_mapel.php
DEBUG - 2023-09-22 14:47:53 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-09-22 14:47:53 --> Final output sent to browser
DEBUG - 2023-09-22 14:47:53 --> Total execution time: 0.0392
INFO - 2023-09-22 14:49:17 --> Config Class Initialized
INFO - 2023-09-22 14:49:17 --> Hooks Class Initialized
DEBUG - 2023-09-22 14:49:17 --> UTF-8 Support Enabled
INFO - 2023-09-22 14:49:17 --> Utf8 Class Initialized
INFO - 2023-09-22 14:49:17 --> URI Class Initialized
INFO - 2023-09-22 14:49:17 --> Router Class Initialized
INFO - 2023-09-22 14:49:17 --> Output Class Initialized
INFO - 2023-09-22 14:49:17 --> Security Class Initialized
DEBUG - 2023-09-22 14:49:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-22 14:49:17 --> Input Class Initialized
INFO - 2023-09-22 14:49:17 --> Language Class Initialized
INFO - 2023-09-22 14:49:17 --> Language Class Initialized
INFO - 2023-09-22 14:49:17 --> Config Class Initialized
INFO - 2023-09-22 14:49:17 --> Loader Class Initialized
INFO - 2023-09-22 14:49:17 --> Helper loaded: url_helper
INFO - 2023-09-22 14:49:17 --> Helper loaded: file_helper
INFO - 2023-09-22 14:49:17 --> Helper loaded: form_helper
INFO - 2023-09-22 14:49:17 --> Helper loaded: my_helper
INFO - 2023-09-22 14:49:17 --> Database Driver Class Initialized
INFO - 2023-09-22 14:49:17 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-22 14:49:17 --> Controller Class Initialized
INFO - 2023-09-22 14:49:17 --> Helper loaded: cookie_helper
INFO - 2023-09-22 14:49:17 --> Config Class Initialized
INFO - 2023-09-22 14:49:17 --> Hooks Class Initialized
DEBUG - 2023-09-22 14:49:17 --> UTF-8 Support Enabled
INFO - 2023-09-22 14:49:17 --> Utf8 Class Initialized
INFO - 2023-09-22 14:49:17 --> URI Class Initialized
INFO - 2023-09-22 14:49:17 --> Router Class Initialized
INFO - 2023-09-22 14:49:17 --> Output Class Initialized
INFO - 2023-09-22 14:49:17 --> Security Class Initialized
DEBUG - 2023-09-22 14:49:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-22 14:49:17 --> Input Class Initialized
INFO - 2023-09-22 14:49:17 --> Language Class Initialized
INFO - 2023-09-22 14:49:17 --> Language Class Initialized
INFO - 2023-09-22 14:49:17 --> Config Class Initialized
INFO - 2023-09-22 14:49:17 --> Loader Class Initialized
INFO - 2023-09-22 14:49:17 --> Helper loaded: url_helper
INFO - 2023-09-22 14:49:17 --> Helper loaded: file_helper
INFO - 2023-09-22 14:49:17 --> Helper loaded: form_helper
INFO - 2023-09-22 14:49:17 --> Helper loaded: my_helper
INFO - 2023-09-22 14:49:17 --> Database Driver Class Initialized
INFO - 2023-09-22 14:49:17 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-22 14:49:17 --> Controller Class Initialized
INFO - 2023-09-22 14:49:17 --> Config Class Initialized
INFO - 2023-09-22 14:49:17 --> Hooks Class Initialized
DEBUG - 2023-09-22 14:49:17 --> UTF-8 Support Enabled
INFO - 2023-09-22 14:49:17 --> Utf8 Class Initialized
INFO - 2023-09-22 14:49:17 --> URI Class Initialized
INFO - 2023-09-22 14:49:17 --> Router Class Initialized
INFO - 2023-09-22 14:49:17 --> Output Class Initialized
INFO - 2023-09-22 14:49:17 --> Security Class Initialized
DEBUG - 2023-09-22 14:49:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-22 14:49:17 --> Input Class Initialized
INFO - 2023-09-22 14:49:17 --> Language Class Initialized
INFO - 2023-09-22 14:49:17 --> Language Class Initialized
INFO - 2023-09-22 14:49:17 --> Config Class Initialized
INFO - 2023-09-22 14:49:17 --> Loader Class Initialized
INFO - 2023-09-22 14:49:17 --> Helper loaded: url_helper
INFO - 2023-09-22 14:49:17 --> Helper loaded: file_helper
INFO - 2023-09-22 14:49:17 --> Helper loaded: form_helper
INFO - 2023-09-22 14:49:17 --> Helper loaded: my_helper
INFO - 2023-09-22 14:49:17 --> Database Driver Class Initialized
INFO - 2023-09-22 14:49:17 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-22 14:49:17 --> Controller Class Initialized
DEBUG - 2023-09-22 14:49:17 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/login/views/login.php
DEBUG - 2023-09-22 14:49:17 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-09-22 14:49:17 --> Final output sent to browser
DEBUG - 2023-09-22 14:49:17 --> Total execution time: 0.0392
INFO - 2023-09-22 14:50:04 --> Config Class Initialized
INFO - 2023-09-22 14:50:04 --> Hooks Class Initialized
DEBUG - 2023-09-22 14:50:04 --> UTF-8 Support Enabled
INFO - 2023-09-22 14:50:04 --> Utf8 Class Initialized
INFO - 2023-09-22 14:50:04 --> URI Class Initialized
DEBUG - 2023-09-22 14:50:04 --> No URI present. Default controller set.
INFO - 2023-09-22 14:50:04 --> Router Class Initialized
INFO - 2023-09-22 14:50:04 --> Output Class Initialized
INFO - 2023-09-22 14:50:04 --> Security Class Initialized
DEBUG - 2023-09-22 14:50:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-22 14:50:04 --> Input Class Initialized
INFO - 2023-09-22 14:50:04 --> Language Class Initialized
INFO - 2023-09-22 14:50:04 --> Language Class Initialized
INFO - 2023-09-22 14:50:04 --> Config Class Initialized
INFO - 2023-09-22 14:50:04 --> Loader Class Initialized
INFO - 2023-09-22 14:50:04 --> Helper loaded: url_helper
INFO - 2023-09-22 14:50:04 --> Helper loaded: file_helper
INFO - 2023-09-22 14:50:04 --> Helper loaded: form_helper
INFO - 2023-09-22 14:50:04 --> Helper loaded: my_helper
INFO - 2023-09-22 14:50:04 --> Database Driver Class Initialized
INFO - 2023-09-22 14:50:04 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-22 14:50:04 --> Controller Class Initialized
DEBUG - 2023-09-22 14:50:04 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/home/views/v_home_guru.php
DEBUG - 2023-09-22 14:50:04 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-09-22 14:50:04 --> Final output sent to browser
DEBUG - 2023-09-22 14:50:04 --> Total execution time: 0.0539
INFO - 2023-09-22 14:50:10 --> Config Class Initialized
INFO - 2023-09-22 14:50:10 --> Hooks Class Initialized
DEBUG - 2023-09-22 14:50:10 --> UTF-8 Support Enabled
INFO - 2023-09-22 14:50:10 --> Utf8 Class Initialized
INFO - 2023-09-22 14:50:10 --> URI Class Initialized
INFO - 2023-09-22 14:50:10 --> Router Class Initialized
INFO - 2023-09-22 14:50:10 --> Output Class Initialized
INFO - 2023-09-22 14:50:10 --> Security Class Initialized
DEBUG - 2023-09-22 14:50:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-22 14:50:10 --> Input Class Initialized
INFO - 2023-09-22 14:50:10 --> Language Class Initialized
INFO - 2023-09-22 14:50:10 --> Language Class Initialized
INFO - 2023-09-22 14:50:10 --> Config Class Initialized
INFO - 2023-09-22 14:50:10 --> Loader Class Initialized
INFO - 2023-09-22 14:50:10 --> Helper loaded: url_helper
INFO - 2023-09-22 14:50:10 --> Helper loaded: file_helper
INFO - 2023-09-22 14:50:10 --> Helper loaded: form_helper
INFO - 2023-09-22 14:50:10 --> Helper loaded: my_helper
INFO - 2023-09-22 14:50:10 --> Database Driver Class Initialized
INFO - 2023-09-22 14:50:10 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-22 14:50:10 --> Controller Class Initialized
DEBUG - 2023-09-22 14:50:10 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/view_mapel/views/v_view_mapel.php
DEBUG - 2023-09-22 14:50:10 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-09-22 14:50:10 --> Final output sent to browser
DEBUG - 2023-09-22 14:50:10 --> Total execution time: 0.0359
INFO - 2023-09-22 14:56:11 --> Config Class Initialized
INFO - 2023-09-22 14:56:11 --> Hooks Class Initialized
DEBUG - 2023-09-22 14:56:11 --> UTF-8 Support Enabled
INFO - 2023-09-22 14:56:11 --> Utf8 Class Initialized
INFO - 2023-09-22 14:56:11 --> URI Class Initialized
DEBUG - 2023-09-22 14:56:11 --> No URI present. Default controller set.
INFO - 2023-09-22 14:56:11 --> Router Class Initialized
INFO - 2023-09-22 14:56:11 --> Output Class Initialized
INFO - 2023-09-22 14:56:11 --> Security Class Initialized
DEBUG - 2023-09-22 14:56:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-22 14:56:11 --> Input Class Initialized
INFO - 2023-09-22 14:56:11 --> Language Class Initialized
INFO - 2023-09-22 14:56:12 --> Language Class Initialized
INFO - 2023-09-22 14:56:12 --> Config Class Initialized
INFO - 2023-09-22 14:56:12 --> Loader Class Initialized
INFO - 2023-09-22 14:56:12 --> Helper loaded: url_helper
INFO - 2023-09-22 14:56:12 --> Helper loaded: file_helper
INFO - 2023-09-22 14:56:12 --> Helper loaded: form_helper
INFO - 2023-09-22 14:56:12 --> Helper loaded: my_helper
INFO - 2023-09-22 14:56:12 --> Database Driver Class Initialized
INFO - 2023-09-22 14:56:12 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-22 14:56:12 --> Controller Class Initialized
INFO - 2023-09-22 14:56:12 --> Config Class Initialized
INFO - 2023-09-22 14:56:12 --> Hooks Class Initialized
DEBUG - 2023-09-22 14:56:12 --> UTF-8 Support Enabled
INFO - 2023-09-22 14:56:12 --> Utf8 Class Initialized
INFO - 2023-09-22 14:56:12 --> URI Class Initialized
INFO - 2023-09-22 14:56:12 --> Router Class Initialized
INFO - 2023-09-22 14:56:12 --> Output Class Initialized
INFO - 2023-09-22 14:56:12 --> Security Class Initialized
DEBUG - 2023-09-22 14:56:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-22 14:56:12 --> Input Class Initialized
INFO - 2023-09-22 14:56:12 --> Language Class Initialized
INFO - 2023-09-22 14:56:12 --> Language Class Initialized
INFO - 2023-09-22 14:56:12 --> Config Class Initialized
INFO - 2023-09-22 14:56:12 --> Loader Class Initialized
INFO - 2023-09-22 14:56:12 --> Helper loaded: url_helper
INFO - 2023-09-22 14:56:12 --> Helper loaded: file_helper
INFO - 2023-09-22 14:56:12 --> Helper loaded: form_helper
INFO - 2023-09-22 14:56:12 --> Helper loaded: my_helper
INFO - 2023-09-22 14:56:12 --> Database Driver Class Initialized
INFO - 2023-09-22 14:56:12 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-22 14:56:12 --> Controller Class Initialized
DEBUG - 2023-09-22 14:56:12 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/login/views/login.php
DEBUG - 2023-09-22 14:56:12 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-09-22 14:56:12 --> Final output sent to browser
DEBUG - 2023-09-22 14:56:12 --> Total execution time: 0.0920
INFO - 2023-09-22 14:56:16 --> Config Class Initialized
INFO - 2023-09-22 14:56:16 --> Hooks Class Initialized
DEBUG - 2023-09-22 14:56:16 --> UTF-8 Support Enabled
INFO - 2023-09-22 14:56:16 --> Utf8 Class Initialized
INFO - 2023-09-22 14:56:16 --> URI Class Initialized
INFO - 2023-09-22 14:56:16 --> Router Class Initialized
INFO - 2023-09-22 14:56:16 --> Output Class Initialized
INFO - 2023-09-22 14:56:16 --> Security Class Initialized
DEBUG - 2023-09-22 14:56:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-22 14:56:16 --> Input Class Initialized
INFO - 2023-09-22 14:56:16 --> Language Class Initialized
INFO - 2023-09-22 14:56:16 --> Language Class Initialized
INFO - 2023-09-22 14:56:16 --> Config Class Initialized
INFO - 2023-09-22 14:56:16 --> Loader Class Initialized
INFO - 2023-09-22 14:56:16 --> Helper loaded: url_helper
INFO - 2023-09-22 14:56:16 --> Helper loaded: file_helper
INFO - 2023-09-22 14:56:16 --> Helper loaded: form_helper
INFO - 2023-09-22 14:56:16 --> Helper loaded: my_helper
INFO - 2023-09-22 14:56:16 --> Database Driver Class Initialized
INFO - 2023-09-22 14:56:16 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-22 14:56:16 --> Controller Class Initialized
INFO - 2023-09-22 14:56:16 --> Helper loaded: cookie_helper
INFO - 2023-09-22 14:56:16 --> Final output sent to browser
DEBUG - 2023-09-22 14:56:16 --> Total execution time: 0.0529
INFO - 2023-09-22 14:56:16 --> Config Class Initialized
INFO - 2023-09-22 14:56:16 --> Hooks Class Initialized
DEBUG - 2023-09-22 14:56:16 --> UTF-8 Support Enabled
INFO - 2023-09-22 14:56:16 --> Utf8 Class Initialized
INFO - 2023-09-22 14:56:16 --> URI Class Initialized
INFO - 2023-09-22 14:56:16 --> Router Class Initialized
INFO - 2023-09-22 14:56:16 --> Output Class Initialized
INFO - 2023-09-22 14:56:16 --> Security Class Initialized
DEBUG - 2023-09-22 14:56:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-22 14:56:16 --> Input Class Initialized
INFO - 2023-09-22 14:56:16 --> Language Class Initialized
INFO - 2023-09-22 14:56:16 --> Language Class Initialized
INFO - 2023-09-22 14:56:16 --> Config Class Initialized
INFO - 2023-09-22 14:56:16 --> Loader Class Initialized
INFO - 2023-09-22 14:56:16 --> Helper loaded: url_helper
INFO - 2023-09-22 14:56:16 --> Helper loaded: file_helper
INFO - 2023-09-22 14:56:16 --> Helper loaded: form_helper
INFO - 2023-09-22 14:56:16 --> Helper loaded: my_helper
INFO - 2023-09-22 14:56:16 --> Database Driver Class Initialized
INFO - 2023-09-22 14:56:16 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-22 14:56:16 --> Controller Class Initialized
DEBUG - 2023-09-22 14:56:16 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/home/views/v_home.php
DEBUG - 2023-09-22 14:56:16 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-09-22 14:56:16 --> Final output sent to browser
DEBUG - 2023-09-22 14:56:16 --> Total execution time: 0.0325
INFO - 2023-09-22 14:56:18 --> Config Class Initialized
INFO - 2023-09-22 14:56:18 --> Hooks Class Initialized
DEBUG - 2023-09-22 14:56:18 --> UTF-8 Support Enabled
INFO - 2023-09-22 14:56:18 --> Utf8 Class Initialized
INFO - 2023-09-22 14:56:18 --> URI Class Initialized
INFO - 2023-09-22 14:56:18 --> Router Class Initialized
INFO - 2023-09-22 14:56:18 --> Output Class Initialized
INFO - 2023-09-22 14:56:18 --> Security Class Initialized
DEBUG - 2023-09-22 14:56:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-22 14:56:18 --> Input Class Initialized
INFO - 2023-09-22 14:56:18 --> Language Class Initialized
INFO - 2023-09-22 14:56:18 --> Language Class Initialized
INFO - 2023-09-22 14:56:18 --> Config Class Initialized
INFO - 2023-09-22 14:56:18 --> Loader Class Initialized
INFO - 2023-09-22 14:56:18 --> Helper loaded: url_helper
INFO - 2023-09-22 14:56:18 --> Helper loaded: file_helper
INFO - 2023-09-22 14:56:18 --> Helper loaded: form_helper
INFO - 2023-09-22 14:56:18 --> Helper loaded: my_helper
INFO - 2023-09-22 14:56:18 --> Database Driver Class Initialized
INFO - 2023-09-22 14:56:18 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-22 14:56:18 --> Controller Class Initialized
DEBUG - 2023-09-22 14:56:18 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/data_guru/views/list.php
DEBUG - 2023-09-22 14:56:18 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-09-22 14:56:18 --> Final output sent to browser
DEBUG - 2023-09-22 14:56:18 --> Total execution time: 0.0359
INFO - 2023-09-22 14:56:19 --> Config Class Initialized
INFO - 2023-09-22 14:56:19 --> Hooks Class Initialized
DEBUG - 2023-09-22 14:56:19 --> UTF-8 Support Enabled
INFO - 2023-09-22 14:56:19 --> Utf8 Class Initialized
INFO - 2023-09-22 14:56:19 --> URI Class Initialized
INFO - 2023-09-22 14:56:19 --> Router Class Initialized
INFO - 2023-09-22 14:56:19 --> Output Class Initialized
INFO - 2023-09-22 14:56:19 --> Security Class Initialized
DEBUG - 2023-09-22 14:56:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-22 14:56:19 --> Input Class Initialized
INFO - 2023-09-22 14:56:19 --> Language Class Initialized
ERROR - 2023-09-22 14:56:19 --> 404 Page Not Found: /index
INFO - 2023-09-22 14:56:19 --> Config Class Initialized
INFO - 2023-09-22 14:56:19 --> Hooks Class Initialized
DEBUG - 2023-09-22 14:56:19 --> UTF-8 Support Enabled
INFO - 2023-09-22 14:56:19 --> Utf8 Class Initialized
INFO - 2023-09-22 14:56:19 --> URI Class Initialized
INFO - 2023-09-22 14:56:19 --> Router Class Initialized
INFO - 2023-09-22 14:56:19 --> Output Class Initialized
INFO - 2023-09-22 14:56:19 --> Security Class Initialized
DEBUG - 2023-09-22 14:56:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-22 14:56:19 --> Input Class Initialized
INFO - 2023-09-22 14:56:19 --> Language Class Initialized
INFO - 2023-09-22 14:56:19 --> Language Class Initialized
INFO - 2023-09-22 14:56:19 --> Config Class Initialized
INFO - 2023-09-22 14:56:19 --> Loader Class Initialized
INFO - 2023-09-22 14:56:19 --> Helper loaded: url_helper
INFO - 2023-09-22 14:56:19 --> Helper loaded: file_helper
INFO - 2023-09-22 14:56:19 --> Helper loaded: form_helper
INFO - 2023-09-22 14:56:19 --> Helper loaded: my_helper
INFO - 2023-09-22 14:56:19 --> Database Driver Class Initialized
INFO - 2023-09-22 14:56:19 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-22 14:56:19 --> Controller Class Initialized
INFO - 2023-09-22 14:56:22 --> Config Class Initialized
INFO - 2023-09-22 14:56:22 --> Hooks Class Initialized
DEBUG - 2023-09-22 14:56:22 --> UTF-8 Support Enabled
INFO - 2023-09-22 14:56:22 --> Utf8 Class Initialized
INFO - 2023-09-22 14:56:22 --> URI Class Initialized
INFO - 2023-09-22 14:56:22 --> Router Class Initialized
INFO - 2023-09-22 14:56:22 --> Output Class Initialized
INFO - 2023-09-22 14:56:23 --> Security Class Initialized
DEBUG - 2023-09-22 14:56:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-22 14:56:23 --> Input Class Initialized
INFO - 2023-09-22 14:56:23 --> Language Class Initialized
INFO - 2023-09-22 14:56:23 --> Language Class Initialized
INFO - 2023-09-22 14:56:23 --> Config Class Initialized
INFO - 2023-09-22 14:56:23 --> Loader Class Initialized
INFO - 2023-09-22 14:56:23 --> Helper loaded: url_helper
INFO - 2023-09-22 14:56:23 --> Helper loaded: file_helper
INFO - 2023-09-22 14:56:23 --> Helper loaded: form_helper
INFO - 2023-09-22 14:56:23 --> Helper loaded: my_helper
INFO - 2023-09-22 14:56:23 --> Database Driver Class Initialized
INFO - 2023-09-22 14:56:23 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-22 14:56:23 --> Controller Class Initialized
INFO - 2023-09-22 14:56:23 --> Helper loaded: cookie_helper
INFO - 2023-09-22 14:56:23 --> Config Class Initialized
INFO - 2023-09-22 14:56:23 --> Hooks Class Initialized
DEBUG - 2023-09-22 14:56:23 --> UTF-8 Support Enabled
INFO - 2023-09-22 14:56:23 --> Utf8 Class Initialized
INFO - 2023-09-22 14:56:23 --> URI Class Initialized
INFO - 2023-09-22 14:56:23 --> Router Class Initialized
INFO - 2023-09-22 14:56:23 --> Output Class Initialized
INFO - 2023-09-22 14:56:23 --> Security Class Initialized
DEBUG - 2023-09-22 14:56:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-22 14:56:23 --> Input Class Initialized
INFO - 2023-09-22 14:56:23 --> Language Class Initialized
INFO - 2023-09-22 14:56:23 --> Language Class Initialized
INFO - 2023-09-22 14:56:23 --> Config Class Initialized
INFO - 2023-09-22 14:56:23 --> Loader Class Initialized
INFO - 2023-09-22 14:56:23 --> Helper loaded: url_helper
INFO - 2023-09-22 14:56:23 --> Helper loaded: file_helper
INFO - 2023-09-22 14:56:23 --> Helper loaded: form_helper
INFO - 2023-09-22 14:56:23 --> Helper loaded: my_helper
INFO - 2023-09-22 14:56:23 --> Database Driver Class Initialized
INFO - 2023-09-22 14:56:23 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-22 14:56:23 --> Controller Class Initialized
INFO - 2023-09-22 14:56:23 --> Config Class Initialized
INFO - 2023-09-22 14:56:23 --> Hooks Class Initialized
DEBUG - 2023-09-22 14:56:23 --> UTF-8 Support Enabled
INFO - 2023-09-22 14:56:23 --> Utf8 Class Initialized
INFO - 2023-09-22 14:56:23 --> URI Class Initialized
INFO - 2023-09-22 14:56:23 --> Router Class Initialized
INFO - 2023-09-22 14:56:23 --> Output Class Initialized
INFO - 2023-09-22 14:56:23 --> Security Class Initialized
DEBUG - 2023-09-22 14:56:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-22 14:56:23 --> Input Class Initialized
INFO - 2023-09-22 14:56:23 --> Language Class Initialized
INFO - 2023-09-22 14:56:23 --> Language Class Initialized
INFO - 2023-09-22 14:56:23 --> Config Class Initialized
INFO - 2023-09-22 14:56:23 --> Loader Class Initialized
INFO - 2023-09-22 14:56:23 --> Helper loaded: url_helper
INFO - 2023-09-22 14:56:23 --> Helper loaded: file_helper
INFO - 2023-09-22 14:56:23 --> Helper loaded: form_helper
INFO - 2023-09-22 14:56:23 --> Helper loaded: my_helper
INFO - 2023-09-22 14:56:23 --> Database Driver Class Initialized
INFO - 2023-09-22 14:56:23 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-22 14:56:23 --> Controller Class Initialized
DEBUG - 2023-09-22 14:56:23 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/login/views/login.php
DEBUG - 2023-09-22 14:56:23 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-09-22 14:56:23 --> Final output sent to browser
DEBUG - 2023-09-22 14:56:23 --> Total execution time: 0.0824
INFO - 2023-09-22 14:56:26 --> Config Class Initialized
INFO - 2023-09-22 14:56:26 --> Hooks Class Initialized
DEBUG - 2023-09-22 14:56:26 --> UTF-8 Support Enabled
INFO - 2023-09-22 14:56:26 --> Utf8 Class Initialized
INFO - 2023-09-22 14:56:26 --> URI Class Initialized
INFO - 2023-09-22 14:56:26 --> Router Class Initialized
INFO - 2023-09-22 14:56:26 --> Output Class Initialized
INFO - 2023-09-22 14:56:26 --> Security Class Initialized
DEBUG - 2023-09-22 14:56:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-22 14:56:26 --> Input Class Initialized
INFO - 2023-09-22 14:56:26 --> Language Class Initialized
INFO - 2023-09-22 14:56:26 --> Language Class Initialized
INFO - 2023-09-22 14:56:26 --> Config Class Initialized
INFO - 2023-09-22 14:56:26 --> Loader Class Initialized
INFO - 2023-09-22 14:56:26 --> Helper loaded: url_helper
INFO - 2023-09-22 14:56:26 --> Helper loaded: file_helper
INFO - 2023-09-22 14:56:26 --> Helper loaded: form_helper
INFO - 2023-09-22 14:56:26 --> Helper loaded: my_helper
INFO - 2023-09-22 14:56:26 --> Database Driver Class Initialized
INFO - 2023-09-22 14:56:26 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-22 14:56:26 --> Controller Class Initialized
INFO - 2023-09-22 14:56:26 --> Helper loaded: cookie_helper
INFO - 2023-09-22 14:56:26 --> Final output sent to browser
DEBUG - 2023-09-22 14:56:26 --> Total execution time: 0.1427
INFO - 2023-09-22 14:56:26 --> Config Class Initialized
INFO - 2023-09-22 14:56:26 --> Hooks Class Initialized
DEBUG - 2023-09-22 14:56:26 --> UTF-8 Support Enabled
INFO - 2023-09-22 14:56:26 --> Utf8 Class Initialized
INFO - 2023-09-22 14:56:26 --> URI Class Initialized
INFO - 2023-09-22 14:56:26 --> Router Class Initialized
INFO - 2023-09-22 14:56:26 --> Output Class Initialized
INFO - 2023-09-22 14:56:26 --> Security Class Initialized
DEBUG - 2023-09-22 14:56:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-22 14:56:26 --> Input Class Initialized
INFO - 2023-09-22 14:56:26 --> Language Class Initialized
INFO - 2023-09-22 14:56:26 --> Language Class Initialized
INFO - 2023-09-22 14:56:26 --> Config Class Initialized
INFO - 2023-09-22 14:56:26 --> Loader Class Initialized
INFO - 2023-09-22 14:56:26 --> Helper loaded: url_helper
INFO - 2023-09-22 14:56:26 --> Helper loaded: file_helper
INFO - 2023-09-22 14:56:26 --> Helper loaded: form_helper
INFO - 2023-09-22 14:56:26 --> Helper loaded: my_helper
INFO - 2023-09-22 14:56:26 --> Database Driver Class Initialized
INFO - 2023-09-22 14:56:26 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-22 14:56:26 --> Controller Class Initialized
DEBUG - 2023-09-22 14:56:26 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/home/views/v_home_guru.php
DEBUG - 2023-09-22 14:56:26 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-09-22 14:56:26 --> Final output sent to browser
DEBUG - 2023-09-22 14:56:26 --> Total execution time: 0.1228
INFO - 2023-09-22 14:56:28 --> Config Class Initialized
INFO - 2023-09-22 14:56:28 --> Hooks Class Initialized
DEBUG - 2023-09-22 14:56:28 --> UTF-8 Support Enabled
INFO - 2023-09-22 14:56:28 --> Utf8 Class Initialized
INFO - 2023-09-22 14:56:28 --> URI Class Initialized
INFO - 2023-09-22 14:56:28 --> Router Class Initialized
INFO - 2023-09-22 14:56:28 --> Output Class Initialized
INFO - 2023-09-22 14:56:28 --> Security Class Initialized
DEBUG - 2023-09-22 14:56:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-22 14:56:28 --> Input Class Initialized
INFO - 2023-09-22 14:56:28 --> Language Class Initialized
INFO - 2023-09-22 14:56:28 --> Language Class Initialized
INFO - 2023-09-22 14:56:28 --> Config Class Initialized
INFO - 2023-09-22 14:56:28 --> Loader Class Initialized
INFO - 2023-09-22 14:56:28 --> Helper loaded: url_helper
INFO - 2023-09-22 14:56:28 --> Helper loaded: file_helper
INFO - 2023-09-22 14:56:28 --> Helper loaded: form_helper
INFO - 2023-09-22 14:56:28 --> Helper loaded: my_helper
INFO - 2023-09-22 14:56:28 --> Database Driver Class Initialized
INFO - 2023-09-22 14:56:28 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-22 14:56:28 --> Controller Class Initialized
DEBUG - 2023-09-22 14:56:28 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/view_mapel/views/v_view_mapel.php
DEBUG - 2023-09-22 14:56:28 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-09-22 14:56:28 --> Final output sent to browser
DEBUG - 2023-09-22 14:56:28 --> Total execution time: 0.0433
INFO - 2023-09-22 14:56:29 --> Config Class Initialized
INFO - 2023-09-22 14:56:29 --> Hooks Class Initialized
DEBUG - 2023-09-22 14:56:29 --> UTF-8 Support Enabled
INFO - 2023-09-22 14:56:29 --> Utf8 Class Initialized
INFO - 2023-09-22 14:56:29 --> URI Class Initialized
INFO - 2023-09-22 14:56:29 --> Router Class Initialized
INFO - 2023-09-22 14:56:29 --> Output Class Initialized
INFO - 2023-09-22 14:56:29 --> Security Class Initialized
DEBUG - 2023-09-22 14:56:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-22 14:56:29 --> Input Class Initialized
INFO - 2023-09-22 14:56:29 --> Language Class Initialized
INFO - 2023-09-22 14:56:29 --> Language Class Initialized
INFO - 2023-09-22 14:56:29 --> Config Class Initialized
INFO - 2023-09-22 14:56:29 --> Loader Class Initialized
INFO - 2023-09-22 14:56:29 --> Helper loaded: url_helper
INFO - 2023-09-22 14:56:29 --> Helper loaded: file_helper
INFO - 2023-09-22 14:56:29 --> Helper loaded: form_helper
INFO - 2023-09-22 14:56:29 --> Helper loaded: my_helper
INFO - 2023-09-22 14:56:29 --> Database Driver Class Initialized
INFO - 2023-09-22 14:56:29 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-22 14:56:29 --> Controller Class Initialized
DEBUG - 2023-09-22 14:56:29 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/views/list.php
DEBUG - 2023-09-22 14:56:29 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-09-22 14:56:29 --> Final output sent to browser
DEBUG - 2023-09-22 14:56:29 --> Total execution time: 0.0988
INFO - 2023-09-22 14:56:29 --> Config Class Initialized
INFO - 2023-09-22 14:56:29 --> Hooks Class Initialized
DEBUG - 2023-09-22 14:56:29 --> UTF-8 Support Enabled
INFO - 2023-09-22 14:56:29 --> Utf8 Class Initialized
INFO - 2023-09-22 14:56:29 --> URI Class Initialized
INFO - 2023-09-22 14:56:29 --> Router Class Initialized
INFO - 2023-09-22 14:56:29 --> Output Class Initialized
INFO - 2023-09-22 14:56:29 --> Security Class Initialized
DEBUG - 2023-09-22 14:56:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-22 14:56:29 --> Input Class Initialized
INFO - 2023-09-22 14:56:29 --> Language Class Initialized
INFO - 2023-09-22 14:56:29 --> Language Class Initialized
INFO - 2023-09-22 14:56:29 --> Config Class Initialized
INFO - 2023-09-22 14:56:29 --> Loader Class Initialized
INFO - 2023-09-22 14:56:29 --> Helper loaded: url_helper
INFO - 2023-09-22 14:56:29 --> Helper loaded: file_helper
INFO - 2023-09-22 14:56:29 --> Helper loaded: form_helper
INFO - 2023-09-22 14:56:29 --> Helper loaded: my_helper
INFO - 2023-09-22 14:56:29 --> Database Driver Class Initialized
INFO - 2023-09-22 14:56:29 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-22 14:56:29 --> Controller Class Initialized
INFO - 2023-09-22 14:56:30 --> Config Class Initialized
INFO - 2023-09-22 14:56:30 --> Hooks Class Initialized
DEBUG - 2023-09-22 14:56:30 --> UTF-8 Support Enabled
INFO - 2023-09-22 14:56:30 --> Utf8 Class Initialized
INFO - 2023-09-22 14:56:30 --> URI Class Initialized
INFO - 2023-09-22 14:56:30 --> Router Class Initialized
INFO - 2023-09-22 14:56:30 --> Output Class Initialized
INFO - 2023-09-22 14:56:30 --> Security Class Initialized
DEBUG - 2023-09-22 14:56:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-22 14:56:30 --> Input Class Initialized
INFO - 2023-09-22 14:56:30 --> Language Class Initialized
INFO - 2023-09-22 14:56:30 --> Language Class Initialized
INFO - 2023-09-22 14:56:30 --> Config Class Initialized
INFO - 2023-09-22 14:56:30 --> Loader Class Initialized
INFO - 2023-09-22 14:56:30 --> Helper loaded: url_helper
INFO - 2023-09-22 14:56:30 --> Helper loaded: file_helper
INFO - 2023-09-22 14:56:30 --> Helper loaded: form_helper
INFO - 2023-09-22 14:56:30 --> Helper loaded: my_helper
INFO - 2023-09-22 14:56:30 --> Database Driver Class Initialized
INFO - 2023-09-22 14:56:30 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-22 14:56:30 --> Controller Class Initialized
DEBUG - 2023-09-22 14:56:30 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/view_mapel/views/v_view_mapel.php
DEBUG - 2023-09-22 14:56:30 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-09-22 14:56:30 --> Final output sent to browser
DEBUG - 2023-09-22 14:56:30 --> Total execution time: 0.0325
INFO - 2023-09-22 14:56:31 --> Config Class Initialized
INFO - 2023-09-22 14:56:31 --> Hooks Class Initialized
DEBUG - 2023-09-22 14:56:31 --> UTF-8 Support Enabled
INFO - 2023-09-22 14:56:31 --> Utf8 Class Initialized
INFO - 2023-09-22 14:56:31 --> URI Class Initialized
INFO - 2023-09-22 14:56:31 --> Router Class Initialized
INFO - 2023-09-22 14:56:31 --> Output Class Initialized
INFO - 2023-09-22 14:56:31 --> Security Class Initialized
DEBUG - 2023-09-22 14:56:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-22 14:56:31 --> Input Class Initialized
INFO - 2023-09-22 14:56:31 --> Language Class Initialized
INFO - 2023-09-22 14:56:31 --> Language Class Initialized
INFO - 2023-09-22 14:56:31 --> Config Class Initialized
INFO - 2023-09-22 14:56:31 --> Loader Class Initialized
INFO - 2023-09-22 14:56:31 --> Helper loaded: url_helper
INFO - 2023-09-22 14:56:31 --> Helper loaded: file_helper
INFO - 2023-09-22 14:56:31 --> Helper loaded: form_helper
INFO - 2023-09-22 14:56:31 --> Helper loaded: my_helper
INFO - 2023-09-22 14:56:31 --> Database Driver Class Initialized
INFO - 2023-09-22 14:56:31 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-22 14:56:31 --> Controller Class Initialized
DEBUG - 2023-09-22 14:56:31 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_catatan_guru/views/list.php
DEBUG - 2023-09-22 14:56:31 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-09-22 14:56:31 --> Final output sent to browser
DEBUG - 2023-09-22 14:56:31 --> Total execution time: 0.1241
INFO - 2023-09-22 14:56:32 --> Config Class Initialized
INFO - 2023-09-22 14:56:32 --> Hooks Class Initialized
DEBUG - 2023-09-22 14:56:32 --> UTF-8 Support Enabled
INFO - 2023-09-22 14:56:32 --> Utf8 Class Initialized
INFO - 2023-09-22 14:56:32 --> URI Class Initialized
INFO - 2023-09-22 14:56:32 --> Router Class Initialized
INFO - 2023-09-22 14:56:32 --> Output Class Initialized
INFO - 2023-09-22 14:56:32 --> Security Class Initialized
DEBUG - 2023-09-22 14:56:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-22 14:56:32 --> Input Class Initialized
INFO - 2023-09-22 14:56:32 --> Language Class Initialized
INFO - 2023-09-22 14:56:32 --> Language Class Initialized
INFO - 2023-09-22 14:56:32 --> Config Class Initialized
INFO - 2023-09-22 14:56:32 --> Loader Class Initialized
INFO - 2023-09-22 14:56:32 --> Helper loaded: url_helper
INFO - 2023-09-22 14:56:32 --> Helper loaded: file_helper
INFO - 2023-09-22 14:56:32 --> Helper loaded: form_helper
INFO - 2023-09-22 14:56:32 --> Helper loaded: my_helper
INFO - 2023-09-22 14:56:32 --> Database Driver Class Initialized
INFO - 2023-09-22 14:56:32 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-22 14:56:32 --> Controller Class Initialized
DEBUG - 2023-09-22 14:56:32 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/view_mapel/views/v_view_mapel.php
DEBUG - 2023-09-22 14:56:32 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-09-22 14:56:32 --> Final output sent to browser
DEBUG - 2023-09-22 14:56:32 --> Total execution time: 0.0376
INFO - 2023-09-22 14:56:34 --> Config Class Initialized
INFO - 2023-09-22 14:56:34 --> Hooks Class Initialized
DEBUG - 2023-09-22 14:56:34 --> UTF-8 Support Enabled
INFO - 2023-09-22 14:56:34 --> Utf8 Class Initialized
INFO - 2023-09-22 14:56:34 --> URI Class Initialized
DEBUG - 2023-09-22 14:56:34 --> No URI present. Default controller set.
INFO - 2023-09-22 14:56:34 --> Router Class Initialized
INFO - 2023-09-22 14:56:34 --> Output Class Initialized
INFO - 2023-09-22 14:56:34 --> Security Class Initialized
DEBUG - 2023-09-22 14:56:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-22 14:56:34 --> Input Class Initialized
INFO - 2023-09-22 14:56:34 --> Language Class Initialized
INFO - 2023-09-22 14:56:34 --> Language Class Initialized
INFO - 2023-09-22 14:56:34 --> Config Class Initialized
INFO - 2023-09-22 14:56:34 --> Loader Class Initialized
INFO - 2023-09-22 14:56:34 --> Helper loaded: url_helper
INFO - 2023-09-22 14:56:34 --> Helper loaded: file_helper
INFO - 2023-09-22 14:56:34 --> Helper loaded: form_helper
INFO - 2023-09-22 14:56:34 --> Helper loaded: my_helper
INFO - 2023-09-22 14:56:34 --> Database Driver Class Initialized
INFO - 2023-09-22 14:56:34 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-22 14:56:34 --> Controller Class Initialized
DEBUG - 2023-09-22 14:56:34 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/home/views/v_home_guru.php
DEBUG - 2023-09-22 14:56:34 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-09-22 14:56:34 --> Final output sent to browser
DEBUG - 2023-09-22 14:56:34 --> Total execution time: 0.0435
INFO - 2023-09-22 14:56:36 --> Config Class Initialized
INFO - 2023-09-22 14:56:36 --> Hooks Class Initialized
DEBUG - 2023-09-22 14:56:36 --> UTF-8 Support Enabled
INFO - 2023-09-22 14:56:36 --> Utf8 Class Initialized
INFO - 2023-09-22 14:56:36 --> URI Class Initialized
INFO - 2023-09-22 14:56:36 --> Router Class Initialized
INFO - 2023-09-22 14:56:36 --> Output Class Initialized
INFO - 2023-09-22 14:56:36 --> Security Class Initialized
DEBUG - 2023-09-22 14:56:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-22 14:56:36 --> Input Class Initialized
INFO - 2023-09-22 14:56:36 --> Language Class Initialized
INFO - 2023-09-22 14:56:36 --> Language Class Initialized
INFO - 2023-09-22 14:56:36 --> Config Class Initialized
INFO - 2023-09-22 14:56:36 --> Loader Class Initialized
INFO - 2023-09-22 14:56:36 --> Helper loaded: url_helper
INFO - 2023-09-22 14:56:36 --> Helper loaded: file_helper
INFO - 2023-09-22 14:56:36 --> Helper loaded: form_helper
INFO - 2023-09-22 14:56:36 --> Helper loaded: my_helper
INFO - 2023-09-22 14:56:36 --> Database Driver Class Initialized
INFO - 2023-09-22 14:56:36 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-22 14:56:36 --> Controller Class Initialized
DEBUG - 2023-09-22 14:56:36 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/view_mapel/views/v_view_mapel.php
DEBUG - 2023-09-22 14:56:36 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-09-22 14:56:36 --> Final output sent to browser
DEBUG - 2023-09-22 14:56:36 --> Total execution time: 0.1383
INFO - 2023-09-22 14:56:37 --> Config Class Initialized
INFO - 2023-09-22 14:56:37 --> Hooks Class Initialized
DEBUG - 2023-09-22 14:56:37 --> UTF-8 Support Enabled
INFO - 2023-09-22 14:56:37 --> Utf8 Class Initialized
INFO - 2023-09-22 14:56:37 --> URI Class Initialized
INFO - 2023-09-22 14:56:37 --> Router Class Initialized
INFO - 2023-09-22 14:56:37 --> Output Class Initialized
INFO - 2023-09-22 14:56:37 --> Security Class Initialized
DEBUG - 2023-09-22 14:56:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-22 14:56:37 --> Input Class Initialized
INFO - 2023-09-22 14:56:37 --> Language Class Initialized
INFO - 2023-09-22 14:56:37 --> Language Class Initialized
INFO - 2023-09-22 14:56:37 --> Config Class Initialized
INFO - 2023-09-22 14:56:37 --> Loader Class Initialized
INFO - 2023-09-22 14:56:37 --> Helper loaded: url_helper
INFO - 2023-09-22 14:56:37 --> Helper loaded: file_helper
INFO - 2023-09-22 14:56:37 --> Helper loaded: form_helper
INFO - 2023-09-22 14:56:37 --> Helper loaded: my_helper
INFO - 2023-09-22 14:56:37 --> Database Driver Class Initialized
INFO - 2023-09-22 14:56:37 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-22 14:56:37 --> Controller Class Initialized
DEBUG - 2023-09-22 14:56:37 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_catatan_guru/views/list.php
DEBUG - 2023-09-22 14:56:37 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-09-22 14:56:37 --> Final output sent to browser
DEBUG - 2023-09-22 14:56:37 --> Total execution time: 0.0477
INFO - 2023-09-22 14:56:39 --> Config Class Initialized
INFO - 2023-09-22 14:56:39 --> Hooks Class Initialized
DEBUG - 2023-09-22 14:56:39 --> UTF-8 Support Enabled
INFO - 2023-09-22 14:56:39 --> Utf8 Class Initialized
INFO - 2023-09-22 14:56:39 --> URI Class Initialized
INFO - 2023-09-22 14:56:39 --> Router Class Initialized
INFO - 2023-09-22 14:56:39 --> Output Class Initialized
INFO - 2023-09-22 14:56:39 --> Security Class Initialized
DEBUG - 2023-09-22 14:56:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-22 14:56:39 --> Input Class Initialized
INFO - 2023-09-22 14:56:39 --> Language Class Initialized
INFO - 2023-09-22 14:56:39 --> Language Class Initialized
INFO - 2023-09-22 14:56:39 --> Config Class Initialized
INFO - 2023-09-22 14:56:39 --> Loader Class Initialized
INFO - 2023-09-22 14:56:39 --> Helper loaded: url_helper
INFO - 2023-09-22 14:56:39 --> Helper loaded: file_helper
INFO - 2023-09-22 14:56:39 --> Helper loaded: form_helper
INFO - 2023-09-22 14:56:39 --> Helper loaded: my_helper
INFO - 2023-09-22 14:56:39 --> Database Driver Class Initialized
INFO - 2023-09-22 14:56:39 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-22 14:56:39 --> Controller Class Initialized
INFO - 2023-09-22 14:56:39 --> Final output sent to browser
DEBUG - 2023-09-22 14:56:39 --> Total execution time: 0.0392
INFO - 2023-09-22 14:56:41 --> Config Class Initialized
INFO - 2023-09-22 14:56:41 --> Hooks Class Initialized
DEBUG - 2023-09-22 14:56:41 --> UTF-8 Support Enabled
INFO - 2023-09-22 14:56:41 --> Utf8 Class Initialized
INFO - 2023-09-22 14:56:41 --> URI Class Initialized
INFO - 2023-09-22 14:56:41 --> Router Class Initialized
INFO - 2023-09-22 14:56:41 --> Output Class Initialized
INFO - 2023-09-22 14:56:41 --> Security Class Initialized
DEBUG - 2023-09-22 14:56:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-22 14:56:41 --> Input Class Initialized
INFO - 2023-09-22 14:56:41 --> Language Class Initialized
INFO - 2023-09-22 14:56:41 --> Language Class Initialized
INFO - 2023-09-22 14:56:41 --> Config Class Initialized
INFO - 2023-09-22 14:56:41 --> Loader Class Initialized
INFO - 2023-09-22 14:56:41 --> Helper loaded: url_helper
INFO - 2023-09-22 14:56:41 --> Helper loaded: file_helper
INFO - 2023-09-22 14:56:41 --> Helper loaded: form_helper
INFO - 2023-09-22 14:56:41 --> Helper loaded: my_helper
INFO - 2023-09-22 14:56:41 --> Database Driver Class Initialized
INFO - 2023-09-22 14:56:41 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-22 14:56:41 --> Controller Class Initialized
DEBUG - 2023-09-22 14:56:41 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/view_mapel/views/v_view_mapel.php
DEBUG - 2023-09-22 14:56:41 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-09-22 14:56:41 --> Final output sent to browser
DEBUG - 2023-09-22 14:56:41 --> Total execution time: 0.0377
INFO - 2023-09-22 14:56:42 --> Config Class Initialized
INFO - 2023-09-22 14:56:42 --> Hooks Class Initialized
DEBUG - 2023-09-22 14:56:42 --> UTF-8 Support Enabled
INFO - 2023-09-22 14:56:42 --> Utf8 Class Initialized
INFO - 2023-09-22 14:56:42 --> URI Class Initialized
INFO - 2023-09-22 14:56:42 --> Router Class Initialized
INFO - 2023-09-22 14:56:42 --> Output Class Initialized
INFO - 2023-09-22 14:56:42 --> Security Class Initialized
DEBUG - 2023-09-22 14:56:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-22 14:56:42 --> Input Class Initialized
INFO - 2023-09-22 14:56:42 --> Language Class Initialized
INFO - 2023-09-22 14:56:42 --> Language Class Initialized
INFO - 2023-09-22 14:56:42 --> Config Class Initialized
INFO - 2023-09-22 14:56:42 --> Loader Class Initialized
INFO - 2023-09-22 14:56:42 --> Helper loaded: url_helper
INFO - 2023-09-22 14:56:42 --> Helper loaded: file_helper
INFO - 2023-09-22 14:56:42 --> Helper loaded: form_helper
INFO - 2023-09-22 14:56:42 --> Helper loaded: my_helper
INFO - 2023-09-22 14:56:42 --> Database Driver Class Initialized
INFO - 2023-09-22 14:56:42 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-22 14:56:42 --> Controller Class Initialized
DEBUG - 2023-09-22 14:56:42 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/views/list.php
DEBUG - 2023-09-22 14:56:42 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-09-22 14:56:42 --> Final output sent to browser
DEBUG - 2023-09-22 14:56:42 --> Total execution time: 0.0395
INFO - 2023-09-22 14:56:42 --> Config Class Initialized
INFO - 2023-09-22 14:56:42 --> Hooks Class Initialized
DEBUG - 2023-09-22 14:56:42 --> UTF-8 Support Enabled
INFO - 2023-09-22 14:56:42 --> Utf8 Class Initialized
INFO - 2023-09-22 14:56:42 --> URI Class Initialized
INFO - 2023-09-22 14:56:42 --> Router Class Initialized
INFO - 2023-09-22 14:56:42 --> Output Class Initialized
INFO - 2023-09-22 14:56:42 --> Security Class Initialized
DEBUG - 2023-09-22 14:56:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-22 14:56:42 --> Input Class Initialized
INFO - 2023-09-22 14:56:42 --> Language Class Initialized
INFO - 2023-09-22 14:56:42 --> Language Class Initialized
INFO - 2023-09-22 14:56:42 --> Config Class Initialized
INFO - 2023-09-22 14:56:42 --> Loader Class Initialized
INFO - 2023-09-22 14:56:42 --> Helper loaded: url_helper
INFO - 2023-09-22 14:56:42 --> Helper loaded: file_helper
INFO - 2023-09-22 14:56:42 --> Helper loaded: form_helper
INFO - 2023-09-22 14:56:42 --> Helper loaded: my_helper
INFO - 2023-09-22 14:56:42 --> Database Driver Class Initialized
INFO - 2023-09-22 14:56:42 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-22 14:56:42 --> Controller Class Initialized
INFO - 2023-09-22 14:56:43 --> Config Class Initialized
INFO - 2023-09-22 14:56:43 --> Hooks Class Initialized
DEBUG - 2023-09-22 14:56:43 --> UTF-8 Support Enabled
INFO - 2023-09-22 14:56:43 --> Utf8 Class Initialized
INFO - 2023-09-22 14:56:43 --> URI Class Initialized
INFO - 2023-09-22 14:56:43 --> Router Class Initialized
INFO - 2023-09-22 14:56:43 --> Output Class Initialized
INFO - 2023-09-22 14:56:43 --> Security Class Initialized
DEBUG - 2023-09-22 14:56:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-22 14:56:43 --> Input Class Initialized
INFO - 2023-09-22 14:56:43 --> Language Class Initialized
INFO - 2023-09-22 14:56:43 --> Language Class Initialized
INFO - 2023-09-22 14:56:43 --> Config Class Initialized
INFO - 2023-09-22 14:56:43 --> Loader Class Initialized
INFO - 2023-09-22 14:56:43 --> Helper loaded: url_helper
INFO - 2023-09-22 14:56:43 --> Helper loaded: file_helper
INFO - 2023-09-22 14:56:43 --> Helper loaded: form_helper
INFO - 2023-09-22 14:56:43 --> Helper loaded: my_helper
INFO - 2023-09-22 14:56:43 --> Database Driver Class Initialized
INFO - 2023-09-22 14:56:43 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-22 14:56:43 --> Controller Class Initialized
DEBUG - 2023-09-22 14:56:43 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/view_mapel/views/v_view_mapel.php
DEBUG - 2023-09-22 14:56:43 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-09-22 14:56:43 --> Final output sent to browser
DEBUG - 2023-09-22 14:56:43 --> Total execution time: 0.0861
INFO - 2023-09-22 14:59:01 --> Config Class Initialized
INFO - 2023-09-22 14:59:01 --> Hooks Class Initialized
DEBUG - 2023-09-22 14:59:01 --> UTF-8 Support Enabled
INFO - 2023-09-22 14:59:01 --> Utf8 Class Initialized
INFO - 2023-09-22 14:59:01 --> URI Class Initialized
DEBUG - 2023-09-22 14:59:01 --> No URI present. Default controller set.
INFO - 2023-09-22 14:59:01 --> Router Class Initialized
INFO - 2023-09-22 14:59:01 --> Output Class Initialized
INFO - 2023-09-22 14:59:01 --> Security Class Initialized
DEBUG - 2023-09-22 14:59:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-22 14:59:01 --> Input Class Initialized
INFO - 2023-09-22 14:59:01 --> Language Class Initialized
INFO - 2023-09-22 14:59:01 --> Language Class Initialized
INFO - 2023-09-22 14:59:01 --> Config Class Initialized
INFO - 2023-09-22 14:59:01 --> Loader Class Initialized
INFO - 2023-09-22 14:59:01 --> Helper loaded: url_helper
INFO - 2023-09-22 14:59:01 --> Helper loaded: file_helper
INFO - 2023-09-22 14:59:01 --> Helper loaded: form_helper
INFO - 2023-09-22 14:59:01 --> Helper loaded: my_helper
INFO - 2023-09-22 14:59:01 --> Database Driver Class Initialized
INFO - 2023-09-22 14:59:01 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-22 14:59:01 --> Controller Class Initialized
DEBUG - 2023-09-22 14:59:01 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/home/views/v_home_guru.php
DEBUG - 2023-09-22 14:59:01 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-09-22 14:59:01 --> Final output sent to browser
DEBUG - 2023-09-22 14:59:01 --> Total execution time: 0.0956
INFO - 2023-09-22 14:59:04 --> Config Class Initialized
INFO - 2023-09-22 14:59:04 --> Hooks Class Initialized
DEBUG - 2023-09-22 14:59:04 --> UTF-8 Support Enabled
INFO - 2023-09-22 14:59:04 --> Utf8 Class Initialized
INFO - 2023-09-22 14:59:04 --> URI Class Initialized
INFO - 2023-09-22 14:59:04 --> Router Class Initialized
INFO - 2023-09-22 14:59:04 --> Output Class Initialized
INFO - 2023-09-22 14:59:04 --> Security Class Initialized
DEBUG - 2023-09-22 14:59:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-22 14:59:04 --> Input Class Initialized
INFO - 2023-09-22 14:59:04 --> Language Class Initialized
INFO - 2023-09-22 14:59:04 --> Language Class Initialized
INFO - 2023-09-22 14:59:04 --> Config Class Initialized
INFO - 2023-09-22 14:59:04 --> Loader Class Initialized
INFO - 2023-09-22 14:59:04 --> Helper loaded: url_helper
INFO - 2023-09-22 14:59:04 --> Helper loaded: file_helper
INFO - 2023-09-22 14:59:04 --> Helper loaded: form_helper
INFO - 2023-09-22 14:59:04 --> Helper loaded: my_helper
INFO - 2023-09-22 14:59:04 --> Database Driver Class Initialized
INFO - 2023-09-22 14:59:04 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-22 14:59:04 --> Controller Class Initialized
DEBUG - 2023-09-22 14:59:04 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/view_mapel/views/v_view_mapel.php
DEBUG - 2023-09-22 14:59:04 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-09-22 14:59:04 --> Final output sent to browser
DEBUG - 2023-09-22 14:59:04 --> Total execution time: 0.0496
INFO - 2023-09-22 14:59:06 --> Config Class Initialized
INFO - 2023-09-22 14:59:06 --> Hooks Class Initialized
DEBUG - 2023-09-22 14:59:06 --> UTF-8 Support Enabled
INFO - 2023-09-22 14:59:06 --> Utf8 Class Initialized
INFO - 2023-09-22 14:59:06 --> URI Class Initialized
INFO - 2023-09-22 14:59:06 --> Router Class Initialized
INFO - 2023-09-22 14:59:06 --> Output Class Initialized
INFO - 2023-09-22 14:59:06 --> Security Class Initialized
DEBUG - 2023-09-22 14:59:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-22 14:59:06 --> Input Class Initialized
INFO - 2023-09-22 14:59:06 --> Language Class Initialized
INFO - 2023-09-22 14:59:06 --> Language Class Initialized
INFO - 2023-09-22 14:59:06 --> Config Class Initialized
INFO - 2023-09-22 14:59:06 --> Loader Class Initialized
INFO - 2023-09-22 14:59:06 --> Helper loaded: url_helper
INFO - 2023-09-22 14:59:06 --> Helper loaded: file_helper
INFO - 2023-09-22 14:59:06 --> Helper loaded: form_helper
INFO - 2023-09-22 14:59:06 --> Helper loaded: my_helper
INFO - 2023-09-22 14:59:06 --> Database Driver Class Initialized
INFO - 2023-09-22 14:59:06 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-22 14:59:06 --> Controller Class Initialized
INFO - 2023-09-22 14:59:07 --> Final output sent to browser
DEBUG - 2023-09-22 14:59:07 --> Total execution time: 0.4991
INFO - 2023-09-22 14:59:12 --> Config Class Initialized
INFO - 2023-09-22 14:59:12 --> Hooks Class Initialized
DEBUG - 2023-09-22 14:59:12 --> UTF-8 Support Enabled
INFO - 2023-09-22 14:59:12 --> Utf8 Class Initialized
INFO - 2023-09-22 14:59:12 --> URI Class Initialized
INFO - 2023-09-22 14:59:12 --> Router Class Initialized
INFO - 2023-09-22 14:59:12 --> Output Class Initialized
INFO - 2023-09-22 14:59:12 --> Security Class Initialized
DEBUG - 2023-09-22 14:59:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-22 14:59:12 --> Input Class Initialized
INFO - 2023-09-22 14:59:12 --> Language Class Initialized
INFO - 2023-09-22 14:59:12 --> Language Class Initialized
INFO - 2023-09-22 14:59:12 --> Config Class Initialized
INFO - 2023-09-22 14:59:12 --> Loader Class Initialized
INFO - 2023-09-22 14:59:12 --> Helper loaded: url_helper
INFO - 2023-09-22 14:59:12 --> Helper loaded: file_helper
INFO - 2023-09-22 14:59:12 --> Helper loaded: form_helper
INFO - 2023-09-22 14:59:12 --> Helper loaded: my_helper
INFO - 2023-09-22 14:59:12 --> Database Driver Class Initialized
INFO - 2023-09-22 14:59:12 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-22 14:59:12 --> Controller Class Initialized
DEBUG - 2023-09-22 14:59:12 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/login/views/login.php
DEBUG - 2023-09-22 14:59:12 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-09-22 14:59:12 --> Final output sent to browser
DEBUG - 2023-09-22 14:59:12 --> Total execution time: 0.0466
INFO - 2023-09-22 14:59:13 --> Config Class Initialized
INFO - 2023-09-22 14:59:13 --> Hooks Class Initialized
DEBUG - 2023-09-22 14:59:13 --> UTF-8 Support Enabled
INFO - 2023-09-22 14:59:13 --> Utf8 Class Initialized
INFO - 2023-09-22 14:59:13 --> URI Class Initialized
DEBUG - 2023-09-22 14:59:13 --> No URI present. Default controller set.
INFO - 2023-09-22 14:59:13 --> Router Class Initialized
INFO - 2023-09-22 14:59:13 --> Output Class Initialized
INFO - 2023-09-22 14:59:13 --> Security Class Initialized
DEBUG - 2023-09-22 14:59:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-22 14:59:13 --> Input Class Initialized
INFO - 2023-09-22 14:59:13 --> Language Class Initialized
INFO - 2023-09-22 14:59:13 --> Language Class Initialized
INFO - 2023-09-22 14:59:13 --> Config Class Initialized
INFO - 2023-09-22 14:59:13 --> Loader Class Initialized
INFO - 2023-09-22 14:59:13 --> Helper loaded: url_helper
INFO - 2023-09-22 14:59:13 --> Helper loaded: file_helper
INFO - 2023-09-22 14:59:13 --> Helper loaded: form_helper
INFO - 2023-09-22 14:59:13 --> Helper loaded: my_helper
INFO - 2023-09-22 14:59:13 --> Database Driver Class Initialized
INFO - 2023-09-22 14:59:13 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-22 14:59:13 --> Controller Class Initialized
DEBUG - 2023-09-22 14:59:13 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/home/views/v_home_guru.php
DEBUG - 2023-09-22 14:59:13 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-09-22 14:59:13 --> Final output sent to browser
DEBUG - 2023-09-22 14:59:13 --> Total execution time: 0.0748
INFO - 2023-09-22 14:59:17 --> Config Class Initialized
INFO - 2023-09-22 14:59:17 --> Hooks Class Initialized
DEBUG - 2023-09-22 14:59:17 --> UTF-8 Support Enabled
INFO - 2023-09-22 14:59:17 --> Utf8 Class Initialized
INFO - 2023-09-22 14:59:17 --> URI Class Initialized
INFO - 2023-09-22 14:59:17 --> Router Class Initialized
INFO - 2023-09-22 14:59:17 --> Output Class Initialized
INFO - 2023-09-22 14:59:17 --> Security Class Initialized
DEBUG - 2023-09-22 14:59:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-22 14:59:17 --> Input Class Initialized
INFO - 2023-09-22 14:59:17 --> Language Class Initialized
INFO - 2023-09-22 14:59:17 --> Language Class Initialized
INFO - 2023-09-22 14:59:17 --> Config Class Initialized
INFO - 2023-09-22 14:59:17 --> Loader Class Initialized
INFO - 2023-09-22 14:59:17 --> Helper loaded: url_helper
INFO - 2023-09-22 14:59:17 --> Helper loaded: file_helper
INFO - 2023-09-22 14:59:17 --> Helper loaded: form_helper
INFO - 2023-09-22 14:59:17 --> Helper loaded: my_helper
INFO - 2023-09-22 14:59:17 --> Database Driver Class Initialized
INFO - 2023-09-22 14:59:17 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-22 14:59:17 --> Controller Class Initialized
DEBUG - 2023-09-22 14:59:17 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/view_mapel/views/v_view_mapel.php
DEBUG - 2023-09-22 14:59:17 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-09-22 14:59:17 --> Final output sent to browser
DEBUG - 2023-09-22 14:59:17 --> Total execution time: 0.0676
INFO - 2023-09-22 14:59:20 --> Config Class Initialized
INFO - 2023-09-22 14:59:20 --> Hooks Class Initialized
DEBUG - 2023-09-22 14:59:20 --> UTF-8 Support Enabled
INFO - 2023-09-22 14:59:20 --> Utf8 Class Initialized
INFO - 2023-09-22 14:59:20 --> URI Class Initialized
INFO - 2023-09-22 14:59:20 --> Router Class Initialized
INFO - 2023-09-22 14:59:20 --> Output Class Initialized
INFO - 2023-09-22 14:59:20 --> Security Class Initialized
DEBUG - 2023-09-22 14:59:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-22 14:59:20 --> Input Class Initialized
INFO - 2023-09-22 14:59:20 --> Language Class Initialized
INFO - 2023-09-22 14:59:20 --> Language Class Initialized
INFO - 2023-09-22 14:59:20 --> Config Class Initialized
INFO - 2023-09-22 14:59:20 --> Loader Class Initialized
INFO - 2023-09-22 14:59:20 --> Helper loaded: url_helper
INFO - 2023-09-22 14:59:20 --> Helper loaded: file_helper
INFO - 2023-09-22 14:59:20 --> Helper loaded: form_helper
INFO - 2023-09-22 14:59:20 --> Helper loaded: my_helper
INFO - 2023-09-22 14:59:20 --> Database Driver Class Initialized
INFO - 2023-09-22 14:59:20 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-22 14:59:20 --> Controller Class Initialized
DEBUG - 2023-09-22 14:59:20 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/views/list.php
DEBUG - 2023-09-22 14:59:20 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-09-22 14:59:20 --> Final output sent to browser
DEBUG - 2023-09-22 14:59:20 --> Total execution time: 0.0476
INFO - 2023-09-22 14:59:20 --> Config Class Initialized
INFO - 2023-09-22 14:59:20 --> Hooks Class Initialized
DEBUG - 2023-09-22 14:59:20 --> UTF-8 Support Enabled
INFO - 2023-09-22 14:59:20 --> Utf8 Class Initialized
INFO - 2023-09-22 14:59:20 --> URI Class Initialized
INFO - 2023-09-22 14:59:20 --> Router Class Initialized
INFO - 2023-09-22 14:59:20 --> Output Class Initialized
INFO - 2023-09-22 14:59:20 --> Security Class Initialized
DEBUG - 2023-09-22 14:59:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-22 14:59:20 --> Input Class Initialized
INFO - 2023-09-22 14:59:20 --> Language Class Initialized
INFO - 2023-09-22 14:59:20 --> Language Class Initialized
INFO - 2023-09-22 14:59:20 --> Config Class Initialized
INFO - 2023-09-22 14:59:20 --> Loader Class Initialized
INFO - 2023-09-22 14:59:20 --> Helper loaded: url_helper
INFO - 2023-09-22 14:59:20 --> Helper loaded: file_helper
INFO - 2023-09-22 14:59:20 --> Helper loaded: form_helper
INFO - 2023-09-22 14:59:20 --> Helper loaded: my_helper
INFO - 2023-09-22 14:59:20 --> Config Class Initialized
INFO - 2023-09-22 14:59:20 --> Hooks Class Initialized
DEBUG - 2023-09-22 14:59:20 --> UTF-8 Support Enabled
INFO - 2023-09-22 14:59:20 --> Utf8 Class Initialized
INFO - 2023-09-22 14:59:20 --> URI Class Initialized
INFO - 2023-09-22 14:59:20 --> Router Class Initialized
INFO - 2023-09-22 14:59:20 --> Output Class Initialized
INFO - 2023-09-22 14:59:20 --> Security Class Initialized
DEBUG - 2023-09-22 14:59:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-22 14:59:20 --> Input Class Initialized
INFO - 2023-09-22 14:59:20 --> Language Class Initialized
INFO - 2023-09-22 14:59:20 --> Language Class Initialized
INFO - 2023-09-22 14:59:20 --> Config Class Initialized
INFO - 2023-09-22 14:59:20 --> Loader Class Initialized
INFO - 2023-09-22 14:59:20 --> Database Driver Class Initialized
INFO - 2023-09-22 14:59:20 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-22 14:59:20 --> Controller Class Initialized
INFO - 2023-09-22 14:59:20 --> Helper loaded: url_helper
INFO - 2023-09-22 14:59:20 --> Helper loaded: file_helper
INFO - 2023-09-22 14:59:20 --> Helper loaded: form_helper
INFO - 2023-09-22 14:59:20 --> Helper loaded: my_helper
INFO - 2023-09-22 14:59:20 --> Database Driver Class Initialized
INFO - 2023-09-22 14:59:20 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-22 14:59:20 --> Controller Class Initialized
INFO - 2023-09-22 14:59:20 --> Final output sent to browser
DEBUG - 2023-09-22 14:59:20 --> Total execution time: 0.0479
INFO - 2023-09-22 14:59:25 --> Config Class Initialized
INFO - 2023-09-22 14:59:25 --> Hooks Class Initialized
DEBUG - 2023-09-22 14:59:25 --> UTF-8 Support Enabled
INFO - 2023-09-22 14:59:25 --> Utf8 Class Initialized
INFO - 2023-09-22 14:59:25 --> URI Class Initialized
INFO - 2023-09-22 14:59:25 --> Router Class Initialized
INFO - 2023-09-22 14:59:25 --> Output Class Initialized
INFO - 2023-09-22 14:59:25 --> Security Class Initialized
DEBUG - 2023-09-22 14:59:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-22 14:59:25 --> Input Class Initialized
INFO - 2023-09-22 14:59:25 --> Language Class Initialized
INFO - 2023-09-22 14:59:25 --> Language Class Initialized
INFO - 2023-09-22 14:59:25 --> Config Class Initialized
INFO - 2023-09-22 14:59:25 --> Loader Class Initialized
INFO - 2023-09-22 14:59:25 --> Helper loaded: url_helper
INFO - 2023-09-22 14:59:25 --> Helper loaded: file_helper
INFO - 2023-09-22 14:59:25 --> Helper loaded: form_helper
INFO - 2023-09-22 14:59:25 --> Helper loaded: my_helper
INFO - 2023-09-22 14:59:25 --> Database Driver Class Initialized
INFO - 2023-09-22 14:59:25 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-22 14:59:25 --> Controller Class Initialized
DEBUG - 2023-09-22 14:59:25 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/view_mapel/views/v_view_mapel.php
DEBUG - 2023-09-22 14:59:25 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-09-22 14:59:25 --> Final output sent to browser
DEBUG - 2023-09-22 14:59:25 --> Total execution time: 0.1211
INFO - 2023-09-22 14:59:27 --> Config Class Initialized
INFO - 2023-09-22 14:59:27 --> Hooks Class Initialized
DEBUG - 2023-09-22 14:59:27 --> UTF-8 Support Enabled
INFO - 2023-09-22 14:59:27 --> Utf8 Class Initialized
INFO - 2023-09-22 14:59:27 --> URI Class Initialized
INFO - 2023-09-22 14:59:27 --> Router Class Initialized
INFO - 2023-09-22 14:59:27 --> Output Class Initialized
INFO - 2023-09-22 14:59:27 --> Security Class Initialized
DEBUG - 2023-09-22 14:59:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-22 14:59:27 --> Input Class Initialized
INFO - 2023-09-22 14:59:27 --> Language Class Initialized
INFO - 2023-09-22 14:59:27 --> Language Class Initialized
INFO - 2023-09-22 14:59:27 --> Config Class Initialized
INFO - 2023-09-22 14:59:27 --> Loader Class Initialized
INFO - 2023-09-22 14:59:27 --> Helper loaded: url_helper
INFO - 2023-09-22 14:59:27 --> Helper loaded: file_helper
INFO - 2023-09-22 14:59:27 --> Helper loaded: form_helper
INFO - 2023-09-22 14:59:27 --> Helper loaded: my_helper
INFO - 2023-09-22 14:59:27 --> Database Driver Class Initialized
INFO - 2023-09-22 14:59:27 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-22 14:59:27 --> Controller Class Initialized
DEBUG - 2023-09-22 14:59:27 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/views/list.php
DEBUG - 2023-09-22 14:59:27 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-09-22 14:59:27 --> Final output sent to browser
DEBUG - 2023-09-22 14:59:27 --> Total execution time: 0.0369
INFO - 2023-09-22 14:59:28 --> Config Class Initialized
INFO - 2023-09-22 14:59:28 --> Hooks Class Initialized
DEBUG - 2023-09-22 14:59:28 --> UTF-8 Support Enabled
INFO - 2023-09-22 14:59:28 --> Utf8 Class Initialized
INFO - 2023-09-22 14:59:28 --> URI Class Initialized
INFO - 2023-09-22 14:59:28 --> Router Class Initialized
INFO - 2023-09-22 14:59:28 --> Output Class Initialized
INFO - 2023-09-22 14:59:28 --> Security Class Initialized
DEBUG - 2023-09-22 14:59:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-22 14:59:28 --> Input Class Initialized
INFO - 2023-09-22 14:59:28 --> Language Class Initialized
INFO - 2023-09-22 14:59:28 --> Language Class Initialized
INFO - 2023-09-22 14:59:28 --> Config Class Initialized
INFO - 2023-09-22 14:59:28 --> Loader Class Initialized
INFO - 2023-09-22 14:59:28 --> Helper loaded: url_helper
INFO - 2023-09-22 14:59:28 --> Helper loaded: file_helper
INFO - 2023-09-22 14:59:28 --> Helper loaded: form_helper
INFO - 2023-09-22 14:59:28 --> Helper loaded: my_helper
INFO - 2023-09-22 14:59:28 --> Database Driver Class Initialized
INFO - 2023-09-22 14:59:28 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-22 14:59:28 --> Controller Class Initialized
INFO - 2023-09-22 14:59:28 --> Config Class Initialized
INFO - 2023-09-22 14:59:28 --> Hooks Class Initialized
DEBUG - 2023-09-22 14:59:28 --> UTF-8 Support Enabled
INFO - 2023-09-22 14:59:28 --> Utf8 Class Initialized
INFO - 2023-09-22 14:59:28 --> URI Class Initialized
INFO - 2023-09-22 14:59:28 --> Router Class Initialized
INFO - 2023-09-22 14:59:28 --> Output Class Initialized
INFO - 2023-09-22 14:59:28 --> Security Class Initialized
DEBUG - 2023-09-22 14:59:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-22 14:59:28 --> Input Class Initialized
INFO - 2023-09-22 14:59:28 --> Language Class Initialized
INFO - 2023-09-22 14:59:28 --> Language Class Initialized
INFO - 2023-09-22 14:59:28 --> Config Class Initialized
INFO - 2023-09-22 14:59:28 --> Loader Class Initialized
INFO - 2023-09-22 14:59:28 --> Helper loaded: url_helper
INFO - 2023-09-22 14:59:28 --> Helper loaded: file_helper
INFO - 2023-09-22 14:59:28 --> Helper loaded: form_helper
INFO - 2023-09-22 14:59:28 --> Helper loaded: my_helper
INFO - 2023-09-22 14:59:28 --> Database Driver Class Initialized
INFO - 2023-09-22 14:59:28 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-22 14:59:28 --> Controller Class Initialized
INFO - 2023-09-22 14:59:28 --> Config Class Initialized
INFO - 2023-09-22 14:59:28 --> Hooks Class Initialized
DEBUG - 2023-09-22 14:59:28 --> UTF-8 Support Enabled
INFO - 2023-09-22 14:59:28 --> Utf8 Class Initialized
INFO - 2023-09-22 14:59:28 --> URI Class Initialized
DEBUG - 2023-09-22 14:59:28 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/views/list.php
DEBUG - 2023-09-22 14:59:28 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-09-22 14:59:28 --> Final output sent to browser
DEBUG - 2023-09-22 14:59:28 --> Total execution time: 0.0463
INFO - 2023-09-22 14:59:28 --> Router Class Initialized
INFO - 2023-09-22 14:59:28 --> Output Class Initialized
INFO - 2023-09-22 14:59:28 --> Security Class Initialized
DEBUG - 2023-09-22 14:59:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-22 14:59:28 --> Input Class Initialized
INFO - 2023-09-22 14:59:28 --> Language Class Initialized
INFO - 2023-09-22 14:59:28 --> Language Class Initialized
INFO - 2023-09-22 14:59:28 --> Config Class Initialized
INFO - 2023-09-22 14:59:28 --> Loader Class Initialized
INFO - 2023-09-22 14:59:28 --> Helper loaded: url_helper
INFO - 2023-09-22 14:59:28 --> Helper loaded: file_helper
INFO - 2023-09-22 14:59:28 --> Helper loaded: form_helper
INFO - 2023-09-22 14:59:28 --> Helper loaded: my_helper
INFO - 2023-09-22 14:59:28 --> Database Driver Class Initialized
INFO - 2023-09-22 14:59:28 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-22 14:59:28 --> Controller Class Initialized
INFO - 2023-09-22 14:59:28 --> Helper loaded: cookie_helper
INFO - 2023-09-22 14:59:28 --> Final output sent to browser
DEBUG - 2023-09-22 14:59:28 --> Total execution time: 0.0631
INFO - 2023-09-22 14:59:28 --> Config Class Initialized
INFO - 2023-09-22 14:59:28 --> Hooks Class Initialized
DEBUG - 2023-09-22 14:59:28 --> UTF-8 Support Enabled
INFO - 2023-09-22 14:59:28 --> Utf8 Class Initialized
INFO - 2023-09-22 14:59:28 --> URI Class Initialized
INFO - 2023-09-22 14:59:28 --> Router Class Initialized
INFO - 2023-09-22 14:59:28 --> Output Class Initialized
INFO - 2023-09-22 14:59:28 --> Security Class Initialized
DEBUG - 2023-09-22 14:59:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-22 14:59:28 --> Input Class Initialized
INFO - 2023-09-22 14:59:28 --> Language Class Initialized
INFO - 2023-09-22 14:59:28 --> Language Class Initialized
INFO - 2023-09-22 14:59:28 --> Config Class Initialized
INFO - 2023-09-22 14:59:28 --> Loader Class Initialized
INFO - 2023-09-22 14:59:28 --> Helper loaded: url_helper
INFO - 2023-09-22 14:59:28 --> Helper loaded: file_helper
INFO - 2023-09-22 14:59:28 --> Helper loaded: form_helper
INFO - 2023-09-22 14:59:28 --> Helper loaded: my_helper
INFO - 2023-09-22 14:59:28 --> Database Driver Class Initialized
INFO - 2023-09-22 14:59:28 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-22 14:59:28 --> Controller Class Initialized
INFO - 2023-09-22 14:59:28 --> Config Class Initialized
INFO - 2023-09-22 14:59:28 --> Hooks Class Initialized
DEBUG - 2023-09-22 14:59:28 --> UTF-8 Support Enabled
INFO - 2023-09-22 14:59:28 --> Utf8 Class Initialized
INFO - 2023-09-22 14:59:28 --> URI Class Initialized
INFO - 2023-09-22 14:59:28 --> Router Class Initialized
INFO - 2023-09-22 14:59:28 --> Output Class Initialized
INFO - 2023-09-22 14:59:28 --> Security Class Initialized
DEBUG - 2023-09-22 14:59:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-22 14:59:28 --> Input Class Initialized
INFO - 2023-09-22 14:59:28 --> Language Class Initialized
INFO - 2023-09-22 14:59:28 --> Language Class Initialized
INFO - 2023-09-22 14:59:28 --> Config Class Initialized
INFO - 2023-09-22 14:59:28 --> Loader Class Initialized
INFO - 2023-09-22 14:59:28 --> Helper loaded: url_helper
INFO - 2023-09-22 14:59:28 --> Helper loaded: file_helper
INFO - 2023-09-22 14:59:28 --> Helper loaded: form_helper
INFO - 2023-09-22 14:59:28 --> Helper loaded: my_helper
INFO - 2023-09-22 14:59:28 --> Database Driver Class Initialized
INFO - 2023-09-22 14:59:28 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-22 14:59:28 --> Controller Class Initialized
DEBUG - 2023-09-22 14:59:28 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/home/views/v_home_guru.php
DEBUG - 2023-09-22 14:59:28 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-09-22 14:59:28 --> Final output sent to browser
DEBUG - 2023-09-22 14:59:28 --> Total execution time: 0.0332
INFO - 2023-09-22 14:59:34 --> Config Class Initialized
INFO - 2023-09-22 14:59:34 --> Hooks Class Initialized
DEBUG - 2023-09-22 14:59:34 --> UTF-8 Support Enabled
INFO - 2023-09-22 14:59:34 --> Utf8 Class Initialized
INFO - 2023-09-22 14:59:34 --> URI Class Initialized
INFO - 2023-09-22 14:59:34 --> Router Class Initialized
INFO - 2023-09-22 14:59:34 --> Output Class Initialized
INFO - 2023-09-22 14:59:34 --> Security Class Initialized
DEBUG - 2023-09-22 14:59:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-22 14:59:34 --> Input Class Initialized
INFO - 2023-09-22 14:59:34 --> Language Class Initialized
INFO - 2023-09-22 14:59:34 --> Language Class Initialized
INFO - 2023-09-22 14:59:34 --> Config Class Initialized
INFO - 2023-09-22 14:59:34 --> Loader Class Initialized
INFO - 2023-09-22 14:59:34 --> Helper loaded: url_helper
INFO - 2023-09-22 14:59:34 --> Helper loaded: file_helper
INFO - 2023-09-22 14:59:34 --> Helper loaded: form_helper
INFO - 2023-09-22 14:59:34 --> Helper loaded: my_helper
INFO - 2023-09-22 14:59:34 --> Database Driver Class Initialized
INFO - 2023-09-22 14:59:34 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-22 14:59:34 --> Controller Class Initialized
DEBUG - 2023-09-22 14:59:34 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/view_mapel/views/v_view_mapel.php
DEBUG - 2023-09-22 14:59:34 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-09-22 14:59:34 --> Final output sent to browser
DEBUG - 2023-09-22 14:59:34 --> Total execution time: 0.0841
INFO - 2023-09-22 14:59:40 --> Config Class Initialized
INFO - 2023-09-22 14:59:40 --> Hooks Class Initialized
DEBUG - 2023-09-22 14:59:41 --> UTF-8 Support Enabled
INFO - 2023-09-22 14:59:41 --> Utf8 Class Initialized
INFO - 2023-09-22 14:59:41 --> URI Class Initialized
INFO - 2023-09-22 14:59:41 --> Router Class Initialized
INFO - 2023-09-22 14:59:41 --> Output Class Initialized
INFO - 2023-09-22 14:59:41 --> Security Class Initialized
DEBUG - 2023-09-22 14:59:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-22 14:59:41 --> Input Class Initialized
INFO - 2023-09-22 14:59:41 --> Language Class Initialized
INFO - 2023-09-22 14:59:41 --> Language Class Initialized
INFO - 2023-09-22 14:59:41 --> Config Class Initialized
INFO - 2023-09-22 14:59:41 --> Loader Class Initialized
INFO - 2023-09-22 14:59:41 --> Helper loaded: url_helper
INFO - 2023-09-22 14:59:41 --> Helper loaded: file_helper
INFO - 2023-09-22 14:59:41 --> Helper loaded: form_helper
INFO - 2023-09-22 14:59:41 --> Helper loaded: my_helper
INFO - 2023-09-22 14:59:41 --> Database Driver Class Initialized
INFO - 2023-09-22 14:59:41 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-22 14:59:41 --> Controller Class Initialized
DEBUG - 2023-09-22 14:59:41 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/views/list.php
DEBUG - 2023-09-22 14:59:41 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-09-22 14:59:41 --> Final output sent to browser
DEBUG - 2023-09-22 14:59:41 --> Total execution time: 0.0920
INFO - 2023-09-22 14:59:41 --> Config Class Initialized
INFO - 2023-09-22 14:59:41 --> Hooks Class Initialized
DEBUG - 2023-09-22 14:59:41 --> UTF-8 Support Enabled
INFO - 2023-09-22 14:59:41 --> Utf8 Class Initialized
INFO - 2023-09-22 14:59:41 --> URI Class Initialized
INFO - 2023-09-22 14:59:41 --> Router Class Initialized
INFO - 2023-09-22 14:59:41 --> Output Class Initialized
INFO - 2023-09-22 14:59:41 --> Security Class Initialized
DEBUG - 2023-09-22 14:59:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-22 14:59:41 --> Input Class Initialized
INFO - 2023-09-22 14:59:41 --> Language Class Initialized
INFO - 2023-09-22 14:59:41 --> Language Class Initialized
INFO - 2023-09-22 14:59:41 --> Config Class Initialized
INFO - 2023-09-22 14:59:41 --> Loader Class Initialized
INFO - 2023-09-22 14:59:41 --> Helper loaded: url_helper
INFO - 2023-09-22 14:59:41 --> Helper loaded: file_helper
INFO - 2023-09-22 14:59:41 --> Helper loaded: form_helper
INFO - 2023-09-22 14:59:41 --> Helper loaded: my_helper
INFO - 2023-09-22 14:59:41 --> Database Driver Class Initialized
INFO - 2023-09-22 14:59:41 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-22 14:59:41 --> Controller Class Initialized
INFO - 2023-09-22 14:59:56 --> Config Class Initialized
INFO - 2023-09-22 14:59:56 --> Hooks Class Initialized
DEBUG - 2023-09-22 14:59:56 --> UTF-8 Support Enabled
INFO - 2023-09-22 14:59:56 --> Utf8 Class Initialized
INFO - 2023-09-22 14:59:56 --> URI Class Initialized
INFO - 2023-09-22 14:59:56 --> Router Class Initialized
INFO - 2023-09-22 14:59:56 --> Output Class Initialized
INFO - 2023-09-22 14:59:56 --> Security Class Initialized
DEBUG - 2023-09-22 14:59:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-22 14:59:56 --> Input Class Initialized
INFO - 2023-09-22 14:59:56 --> Language Class Initialized
INFO - 2023-09-22 14:59:56 --> Language Class Initialized
INFO - 2023-09-22 14:59:56 --> Config Class Initialized
INFO - 2023-09-22 14:59:56 --> Loader Class Initialized
INFO - 2023-09-22 14:59:56 --> Helper loaded: url_helper
INFO - 2023-09-22 14:59:56 --> Helper loaded: file_helper
INFO - 2023-09-22 14:59:56 --> Helper loaded: form_helper
INFO - 2023-09-22 14:59:56 --> Helper loaded: my_helper
INFO - 2023-09-22 14:59:56 --> Database Driver Class Initialized
INFO - 2023-09-22 14:59:56 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-22 14:59:56 --> Controller Class Initialized
DEBUG - 2023-09-22 14:59:56 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/login/views/login.php
DEBUG - 2023-09-22 14:59:56 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-09-22 14:59:56 --> Final output sent to browser
DEBUG - 2023-09-22 14:59:56 --> Total execution time: 0.0364
INFO - 2023-09-22 15:00:03 --> Config Class Initialized
INFO - 2023-09-22 15:00:03 --> Hooks Class Initialized
DEBUG - 2023-09-22 15:00:03 --> UTF-8 Support Enabled
INFO - 2023-09-22 15:00:03 --> Utf8 Class Initialized
INFO - 2023-09-22 15:00:03 --> URI Class Initialized
INFO - 2023-09-22 15:00:03 --> Router Class Initialized
INFO - 2023-09-22 15:00:03 --> Output Class Initialized
INFO - 2023-09-22 15:00:03 --> Security Class Initialized
DEBUG - 2023-09-22 15:00:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-22 15:00:03 --> Input Class Initialized
INFO - 2023-09-22 15:00:03 --> Language Class Initialized
INFO - 2023-09-22 15:00:03 --> Language Class Initialized
INFO - 2023-09-22 15:00:03 --> Config Class Initialized
INFO - 2023-09-22 15:00:03 --> Loader Class Initialized
INFO - 2023-09-22 15:00:03 --> Helper loaded: url_helper
INFO - 2023-09-22 15:00:03 --> Helper loaded: file_helper
INFO - 2023-09-22 15:00:03 --> Helper loaded: form_helper
INFO - 2023-09-22 15:00:03 --> Helper loaded: my_helper
INFO - 2023-09-22 15:00:03 --> Database Driver Class Initialized
INFO - 2023-09-22 15:00:03 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-22 15:00:03 --> Controller Class Initialized
INFO - 2023-09-22 15:00:03 --> Helper loaded: cookie_helper
INFO - 2023-09-22 15:00:03 --> Final output sent to browser
DEBUG - 2023-09-22 15:00:03 --> Total execution time: 0.0507
INFO - 2023-09-22 15:00:03 --> Config Class Initialized
INFO - 2023-09-22 15:00:03 --> Hooks Class Initialized
DEBUG - 2023-09-22 15:00:03 --> UTF-8 Support Enabled
INFO - 2023-09-22 15:00:03 --> Utf8 Class Initialized
INFO - 2023-09-22 15:00:03 --> URI Class Initialized
INFO - 2023-09-22 15:00:03 --> Router Class Initialized
INFO - 2023-09-22 15:00:03 --> Output Class Initialized
INFO - 2023-09-22 15:00:03 --> Security Class Initialized
DEBUG - 2023-09-22 15:00:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-22 15:00:03 --> Input Class Initialized
INFO - 2023-09-22 15:00:03 --> Language Class Initialized
INFO - 2023-09-22 15:00:03 --> Language Class Initialized
INFO - 2023-09-22 15:00:03 --> Config Class Initialized
INFO - 2023-09-22 15:00:03 --> Loader Class Initialized
INFO - 2023-09-22 15:00:03 --> Helper loaded: url_helper
INFO - 2023-09-22 15:00:03 --> Helper loaded: file_helper
INFO - 2023-09-22 15:00:03 --> Helper loaded: form_helper
INFO - 2023-09-22 15:00:03 --> Helper loaded: my_helper
INFO - 2023-09-22 15:00:03 --> Database Driver Class Initialized
INFO - 2023-09-22 15:00:03 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-22 15:00:03 --> Controller Class Initialized
DEBUG - 2023-09-22 15:00:03 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/home/views/v_home_guru.php
DEBUG - 2023-09-22 15:00:03 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-09-22 15:00:03 --> Final output sent to browser
DEBUG - 2023-09-22 15:00:03 --> Total execution time: 0.0447
INFO - 2023-09-22 15:00:14 --> Config Class Initialized
INFO - 2023-09-22 15:00:14 --> Hooks Class Initialized
DEBUG - 2023-09-22 15:00:14 --> UTF-8 Support Enabled
INFO - 2023-09-22 15:00:14 --> Utf8 Class Initialized
INFO - 2023-09-22 15:00:14 --> URI Class Initialized
DEBUG - 2023-09-22 15:00:14 --> No URI present. Default controller set.
INFO - 2023-09-22 15:00:14 --> Router Class Initialized
INFO - 2023-09-22 15:00:14 --> Output Class Initialized
INFO - 2023-09-22 15:00:14 --> Security Class Initialized
DEBUG - 2023-09-22 15:00:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-22 15:00:14 --> Input Class Initialized
INFO - 2023-09-22 15:00:14 --> Language Class Initialized
INFO - 2023-09-22 15:00:14 --> Language Class Initialized
INFO - 2023-09-22 15:00:14 --> Config Class Initialized
INFO - 2023-09-22 15:00:14 --> Loader Class Initialized
INFO - 2023-09-22 15:00:14 --> Helper loaded: url_helper
INFO - 2023-09-22 15:00:14 --> Helper loaded: file_helper
INFO - 2023-09-22 15:00:14 --> Helper loaded: form_helper
INFO - 2023-09-22 15:00:14 --> Helper loaded: my_helper
INFO - 2023-09-22 15:00:14 --> Database Driver Class Initialized
INFO - 2023-09-22 15:00:14 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-22 15:00:14 --> Controller Class Initialized
DEBUG - 2023-09-22 15:00:14 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/home/views/v_home_guru.php
DEBUG - 2023-09-22 15:00:14 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-09-22 15:00:14 --> Final output sent to browser
DEBUG - 2023-09-22 15:00:14 --> Total execution time: 0.0399
INFO - 2023-09-22 15:00:15 --> Config Class Initialized
INFO - 2023-09-22 15:00:15 --> Hooks Class Initialized
DEBUG - 2023-09-22 15:00:15 --> UTF-8 Support Enabled
INFO - 2023-09-22 15:00:15 --> Utf8 Class Initialized
INFO - 2023-09-22 15:00:15 --> URI Class Initialized
INFO - 2023-09-22 15:00:15 --> Router Class Initialized
INFO - 2023-09-22 15:00:15 --> Output Class Initialized
INFO - 2023-09-22 15:00:15 --> Security Class Initialized
DEBUG - 2023-09-22 15:00:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-22 15:00:15 --> Input Class Initialized
INFO - 2023-09-22 15:00:15 --> Language Class Initialized
INFO - 2023-09-22 15:00:15 --> Language Class Initialized
INFO - 2023-09-22 15:00:15 --> Config Class Initialized
INFO - 2023-09-22 15:00:15 --> Loader Class Initialized
INFO - 2023-09-22 15:00:15 --> Helper loaded: url_helper
INFO - 2023-09-22 15:00:15 --> Helper loaded: file_helper
INFO - 2023-09-22 15:00:15 --> Helper loaded: form_helper
INFO - 2023-09-22 15:00:15 --> Helper loaded: my_helper
INFO - 2023-09-22 15:00:15 --> Database Driver Class Initialized
INFO - 2023-09-22 15:00:15 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-22 15:00:15 --> Controller Class Initialized
DEBUG - 2023-09-22 15:00:15 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/view_mapel/views/v_view_mapel.php
DEBUG - 2023-09-22 15:00:15 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-09-22 15:00:15 --> Final output sent to browser
DEBUG - 2023-09-22 15:00:15 --> Total execution time: 0.0454
INFO - 2023-09-22 15:00:19 --> Config Class Initialized
INFO - 2023-09-22 15:00:19 --> Hooks Class Initialized
DEBUG - 2023-09-22 15:00:19 --> UTF-8 Support Enabled
INFO - 2023-09-22 15:00:19 --> Utf8 Class Initialized
INFO - 2023-09-22 15:00:19 --> URI Class Initialized
INFO - 2023-09-22 15:00:19 --> Router Class Initialized
INFO - 2023-09-22 15:00:19 --> Output Class Initialized
INFO - 2023-09-22 15:00:19 --> Security Class Initialized
DEBUG - 2023-09-22 15:00:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-22 15:00:19 --> Input Class Initialized
INFO - 2023-09-22 15:00:19 --> Language Class Initialized
INFO - 2023-09-22 15:00:19 --> Language Class Initialized
INFO - 2023-09-22 15:00:19 --> Config Class Initialized
INFO - 2023-09-22 15:00:19 --> Loader Class Initialized
INFO - 2023-09-22 15:00:19 --> Helper loaded: url_helper
INFO - 2023-09-22 15:00:19 --> Helper loaded: file_helper
INFO - 2023-09-22 15:00:19 --> Helper loaded: form_helper
INFO - 2023-09-22 15:00:19 --> Helper loaded: my_helper
INFO - 2023-09-22 15:00:19 --> Database Driver Class Initialized
INFO - 2023-09-22 15:00:19 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-22 15:00:19 --> Controller Class Initialized
DEBUG - 2023-09-22 15:00:19 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_catatan_guru/views/list.php
DEBUG - 2023-09-22 15:00:19 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-09-22 15:00:19 --> Final output sent to browser
DEBUG - 2023-09-22 15:00:19 --> Total execution time: 0.0605
INFO - 2023-09-22 15:00:22 --> Config Class Initialized
INFO - 2023-09-22 15:00:22 --> Hooks Class Initialized
DEBUG - 2023-09-22 15:00:22 --> UTF-8 Support Enabled
INFO - 2023-09-22 15:00:22 --> Utf8 Class Initialized
INFO - 2023-09-22 15:00:22 --> URI Class Initialized
INFO - 2023-09-22 15:00:22 --> Router Class Initialized
INFO - 2023-09-22 15:00:22 --> Output Class Initialized
INFO - 2023-09-22 15:00:22 --> Security Class Initialized
DEBUG - 2023-09-22 15:00:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-22 15:00:22 --> Input Class Initialized
INFO - 2023-09-22 15:00:22 --> Language Class Initialized
INFO - 2023-09-22 15:00:22 --> Language Class Initialized
INFO - 2023-09-22 15:00:22 --> Config Class Initialized
INFO - 2023-09-22 15:00:22 --> Loader Class Initialized
INFO - 2023-09-22 15:00:22 --> Helper loaded: url_helper
INFO - 2023-09-22 15:00:22 --> Helper loaded: file_helper
INFO - 2023-09-22 15:00:22 --> Helper loaded: form_helper
INFO - 2023-09-22 15:00:22 --> Helper loaded: my_helper
INFO - 2023-09-22 15:00:22 --> Database Driver Class Initialized
INFO - 2023-09-22 15:00:22 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-22 15:00:22 --> Controller Class Initialized
DEBUG - 2023-09-22 15:00:22 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/view_mapel/views/v_view_mapel.php
DEBUG - 2023-09-22 15:00:22 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-09-22 15:00:22 --> Final output sent to browser
DEBUG - 2023-09-22 15:00:22 --> Total execution time: 0.0350
INFO - 2023-09-22 15:00:24 --> Config Class Initialized
INFO - 2023-09-22 15:00:24 --> Hooks Class Initialized
DEBUG - 2023-09-22 15:00:24 --> UTF-8 Support Enabled
INFO - 2023-09-22 15:00:24 --> Utf8 Class Initialized
INFO - 2023-09-22 15:00:24 --> URI Class Initialized
INFO - 2023-09-22 15:00:24 --> Router Class Initialized
INFO - 2023-09-22 15:00:24 --> Output Class Initialized
INFO - 2023-09-22 15:00:24 --> Security Class Initialized
DEBUG - 2023-09-22 15:00:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-22 15:00:24 --> Input Class Initialized
INFO - 2023-09-22 15:00:24 --> Language Class Initialized
INFO - 2023-09-22 15:00:24 --> Language Class Initialized
INFO - 2023-09-22 15:00:24 --> Config Class Initialized
INFO - 2023-09-22 15:00:24 --> Loader Class Initialized
INFO - 2023-09-22 15:00:24 --> Helper loaded: url_helper
INFO - 2023-09-22 15:00:24 --> Helper loaded: file_helper
INFO - 2023-09-22 15:00:24 --> Helper loaded: form_helper
INFO - 2023-09-22 15:00:24 --> Helper loaded: my_helper
INFO - 2023-09-22 15:00:24 --> Database Driver Class Initialized
INFO - 2023-09-22 15:00:24 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-22 15:00:24 --> Controller Class Initialized
DEBUG - 2023-09-22 15:00:24 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/views/list.php
DEBUG - 2023-09-22 15:00:24 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-09-22 15:00:24 --> Final output sent to browser
DEBUG - 2023-09-22 15:00:24 --> Total execution time: 0.0454
INFO - 2023-09-22 15:00:24 --> Config Class Initialized
INFO - 2023-09-22 15:00:24 --> Hooks Class Initialized
DEBUG - 2023-09-22 15:00:24 --> UTF-8 Support Enabled
INFO - 2023-09-22 15:00:24 --> Utf8 Class Initialized
INFO - 2023-09-22 15:00:24 --> URI Class Initialized
INFO - 2023-09-22 15:00:24 --> Router Class Initialized
INFO - 2023-09-22 15:00:24 --> Output Class Initialized
INFO - 2023-09-22 15:00:24 --> Security Class Initialized
DEBUG - 2023-09-22 15:00:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-22 15:00:24 --> Input Class Initialized
INFO - 2023-09-22 15:00:24 --> Language Class Initialized
INFO - 2023-09-22 15:00:24 --> Language Class Initialized
INFO - 2023-09-22 15:00:24 --> Config Class Initialized
INFO - 2023-09-22 15:00:24 --> Loader Class Initialized
INFO - 2023-09-22 15:00:24 --> Helper loaded: url_helper
INFO - 2023-09-22 15:00:24 --> Helper loaded: file_helper
INFO - 2023-09-22 15:00:24 --> Helper loaded: form_helper
INFO - 2023-09-22 15:00:24 --> Helper loaded: my_helper
INFO - 2023-09-22 15:00:24 --> Database Driver Class Initialized
INFO - 2023-09-22 15:00:24 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-22 15:00:24 --> Controller Class Initialized
INFO - 2023-09-22 15:01:05 --> Config Class Initialized
INFO - 2023-09-22 15:01:05 --> Hooks Class Initialized
DEBUG - 2023-09-22 15:01:05 --> UTF-8 Support Enabled
INFO - 2023-09-22 15:01:05 --> Utf8 Class Initialized
INFO - 2023-09-22 15:01:05 --> URI Class Initialized
INFO - 2023-09-22 15:01:05 --> Router Class Initialized
INFO - 2023-09-22 15:01:05 --> Output Class Initialized
INFO - 2023-09-22 15:01:05 --> Security Class Initialized
DEBUG - 2023-09-22 15:01:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-22 15:01:05 --> Input Class Initialized
INFO - 2023-09-22 15:01:05 --> Language Class Initialized
INFO - 2023-09-22 15:01:05 --> Language Class Initialized
INFO - 2023-09-22 15:01:05 --> Config Class Initialized
INFO - 2023-09-22 15:01:05 --> Loader Class Initialized
INFO - 2023-09-22 15:01:05 --> Helper loaded: url_helper
INFO - 2023-09-22 15:01:05 --> Helper loaded: file_helper
INFO - 2023-09-22 15:01:05 --> Helper loaded: form_helper
INFO - 2023-09-22 15:01:05 --> Helper loaded: my_helper
INFO - 2023-09-22 15:01:05 --> Database Driver Class Initialized
INFO - 2023-09-22 15:01:05 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-22 15:01:05 --> Controller Class Initialized
INFO - 2023-09-22 15:01:05 --> Final output sent to browser
DEBUG - 2023-09-22 15:01:05 --> Total execution time: 0.1674
INFO - 2023-09-22 15:02:35 --> Config Class Initialized
INFO - 2023-09-22 15:02:35 --> Hooks Class Initialized
DEBUG - 2023-09-22 15:02:35 --> UTF-8 Support Enabled
INFO - 2023-09-22 15:02:35 --> Utf8 Class Initialized
INFO - 2023-09-22 15:02:35 --> URI Class Initialized
INFO - 2023-09-22 15:02:35 --> Router Class Initialized
INFO - 2023-09-22 15:02:35 --> Output Class Initialized
INFO - 2023-09-22 15:02:35 --> Security Class Initialized
DEBUG - 2023-09-22 15:02:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-22 15:02:35 --> Input Class Initialized
INFO - 2023-09-22 15:02:35 --> Language Class Initialized
INFO - 2023-09-22 15:02:35 --> Language Class Initialized
INFO - 2023-09-22 15:02:35 --> Config Class Initialized
INFO - 2023-09-22 15:02:35 --> Loader Class Initialized
INFO - 2023-09-22 15:02:35 --> Helper loaded: url_helper
INFO - 2023-09-22 15:02:35 --> Helper loaded: file_helper
INFO - 2023-09-22 15:02:35 --> Helper loaded: form_helper
INFO - 2023-09-22 15:02:35 --> Helper loaded: my_helper
INFO - 2023-09-22 15:02:35 --> Database Driver Class Initialized
INFO - 2023-09-22 15:02:35 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-22 15:02:35 --> Controller Class Initialized
INFO - 2023-09-22 15:02:35 --> Final output sent to browser
DEBUG - 2023-09-22 15:02:35 --> Total execution time: 0.0483
INFO - 2023-09-22 15:06:37 --> Config Class Initialized
INFO - 2023-09-22 15:06:37 --> Hooks Class Initialized
DEBUG - 2023-09-22 15:06:37 --> UTF-8 Support Enabled
INFO - 2023-09-22 15:06:37 --> Utf8 Class Initialized
INFO - 2023-09-22 15:06:37 --> URI Class Initialized
INFO - 2023-09-22 15:06:37 --> Router Class Initialized
INFO - 2023-09-22 15:06:37 --> Output Class Initialized
INFO - 2023-09-22 15:06:37 --> Security Class Initialized
DEBUG - 2023-09-22 15:06:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-22 15:06:37 --> Input Class Initialized
INFO - 2023-09-22 15:06:37 --> Language Class Initialized
INFO - 2023-09-22 15:06:37 --> Language Class Initialized
INFO - 2023-09-22 15:06:37 --> Config Class Initialized
INFO - 2023-09-22 15:06:37 --> Loader Class Initialized
INFO - 2023-09-22 15:06:37 --> Helper loaded: url_helper
INFO - 2023-09-22 15:06:37 --> Helper loaded: file_helper
INFO - 2023-09-22 15:06:37 --> Helper loaded: form_helper
INFO - 2023-09-22 15:06:37 --> Helper loaded: my_helper
INFO - 2023-09-22 15:06:37 --> Database Driver Class Initialized
INFO - 2023-09-22 15:06:37 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-22 15:06:37 --> Controller Class Initialized
INFO - 2023-09-22 15:06:37 --> Final output sent to browser
DEBUG - 2023-09-22 15:06:37 --> Total execution time: 0.0700
INFO - 2023-09-22 15:07:03 --> Config Class Initialized
INFO - 2023-09-22 15:07:03 --> Hooks Class Initialized
DEBUG - 2023-09-22 15:07:03 --> UTF-8 Support Enabled
INFO - 2023-09-22 15:07:03 --> Utf8 Class Initialized
INFO - 2023-09-22 15:07:03 --> URI Class Initialized
INFO - 2023-09-22 15:07:03 --> Router Class Initialized
INFO - 2023-09-22 15:07:03 --> Output Class Initialized
INFO - 2023-09-22 15:07:03 --> Security Class Initialized
DEBUG - 2023-09-22 15:07:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-22 15:07:03 --> Input Class Initialized
INFO - 2023-09-22 15:07:03 --> Language Class Initialized
INFO - 2023-09-22 15:07:03 --> Language Class Initialized
INFO - 2023-09-22 15:07:03 --> Config Class Initialized
INFO - 2023-09-22 15:07:03 --> Loader Class Initialized
INFO - 2023-09-22 15:07:03 --> Helper loaded: url_helper
INFO - 2023-09-22 15:07:03 --> Helper loaded: file_helper
INFO - 2023-09-22 15:07:03 --> Helper loaded: form_helper
INFO - 2023-09-22 15:07:03 --> Helper loaded: my_helper
INFO - 2023-09-22 15:07:03 --> Database Driver Class Initialized
INFO - 2023-09-22 15:07:03 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-22 15:07:03 --> Controller Class Initialized
INFO - 2023-09-22 15:07:03 --> Final output sent to browser
DEBUG - 2023-09-22 15:07:03 --> Total execution time: 0.0676
INFO - 2023-09-22 15:07:07 --> Config Class Initialized
INFO - 2023-09-22 15:07:07 --> Hooks Class Initialized
DEBUG - 2023-09-22 15:07:07 --> UTF-8 Support Enabled
INFO - 2023-09-22 15:07:07 --> Utf8 Class Initialized
INFO - 2023-09-22 15:07:07 --> URI Class Initialized
INFO - 2023-09-22 15:07:07 --> Router Class Initialized
INFO - 2023-09-22 15:07:07 --> Output Class Initialized
INFO - 2023-09-22 15:07:07 --> Security Class Initialized
DEBUG - 2023-09-22 15:07:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-22 15:07:07 --> Input Class Initialized
INFO - 2023-09-22 15:07:07 --> Language Class Initialized
INFO - 2023-09-22 15:07:07 --> Language Class Initialized
INFO - 2023-09-22 15:07:07 --> Config Class Initialized
INFO - 2023-09-22 15:07:07 --> Loader Class Initialized
INFO - 2023-09-22 15:07:07 --> Helper loaded: url_helper
INFO - 2023-09-22 15:07:07 --> Helper loaded: file_helper
INFO - 2023-09-22 15:07:07 --> Helper loaded: form_helper
INFO - 2023-09-22 15:07:07 --> Helper loaded: my_helper
INFO - 2023-09-22 15:07:07 --> Database Driver Class Initialized
INFO - 2023-09-22 15:07:07 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-22 15:07:07 --> Controller Class Initialized
INFO - 2023-09-22 15:07:07 --> Final output sent to browser
DEBUG - 2023-09-22 15:07:07 --> Total execution time: 0.0801
INFO - 2023-09-22 15:07:09 --> Config Class Initialized
INFO - 2023-09-22 15:07:09 --> Hooks Class Initialized
DEBUG - 2023-09-22 15:07:09 --> UTF-8 Support Enabled
INFO - 2023-09-22 15:07:09 --> Utf8 Class Initialized
INFO - 2023-09-22 15:07:09 --> URI Class Initialized
INFO - 2023-09-22 15:07:09 --> Router Class Initialized
INFO - 2023-09-22 15:07:09 --> Output Class Initialized
INFO - 2023-09-22 15:07:09 --> Security Class Initialized
DEBUG - 2023-09-22 15:07:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-22 15:07:09 --> Input Class Initialized
INFO - 2023-09-22 15:07:09 --> Language Class Initialized
INFO - 2023-09-22 15:07:09 --> Language Class Initialized
INFO - 2023-09-22 15:07:09 --> Config Class Initialized
INFO - 2023-09-22 15:07:09 --> Loader Class Initialized
INFO - 2023-09-22 15:07:09 --> Helper loaded: url_helper
INFO - 2023-09-22 15:07:09 --> Helper loaded: file_helper
INFO - 2023-09-22 15:07:09 --> Helper loaded: form_helper
INFO - 2023-09-22 15:07:09 --> Helper loaded: my_helper
INFO - 2023-09-22 15:07:09 --> Database Driver Class Initialized
INFO - 2023-09-22 15:07:09 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-22 15:07:09 --> Controller Class Initialized
INFO - 2023-09-22 15:07:09 --> Final output sent to browser
DEBUG - 2023-09-22 15:07:09 --> Total execution time: 0.0610
INFO - 2023-09-22 15:07:10 --> Config Class Initialized
INFO - 2023-09-22 15:07:10 --> Hooks Class Initialized
DEBUG - 2023-09-22 15:07:10 --> UTF-8 Support Enabled
INFO - 2023-09-22 15:07:10 --> Utf8 Class Initialized
INFO - 2023-09-22 15:07:10 --> URI Class Initialized
INFO - 2023-09-22 15:07:10 --> Router Class Initialized
INFO - 2023-09-22 15:07:10 --> Output Class Initialized
INFO - 2023-09-22 15:07:10 --> Security Class Initialized
DEBUG - 2023-09-22 15:07:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-22 15:07:10 --> Input Class Initialized
INFO - 2023-09-22 15:07:10 --> Language Class Initialized
INFO - 2023-09-22 15:07:11 --> Language Class Initialized
INFO - 2023-09-22 15:07:11 --> Config Class Initialized
INFO - 2023-09-22 15:07:11 --> Loader Class Initialized
INFO - 2023-09-22 15:07:11 --> Helper loaded: url_helper
INFO - 2023-09-22 15:07:11 --> Helper loaded: file_helper
INFO - 2023-09-22 15:07:11 --> Helper loaded: form_helper
INFO - 2023-09-22 15:07:11 --> Helper loaded: my_helper
INFO - 2023-09-22 15:07:11 --> Database Driver Class Initialized
INFO - 2023-09-22 15:07:11 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-22 15:07:11 --> Controller Class Initialized
INFO - 2023-09-22 15:07:11 --> Final output sent to browser
DEBUG - 2023-09-22 15:07:11 --> Total execution time: 0.0643
INFO - 2023-09-22 15:07:11 --> Config Class Initialized
INFO - 2023-09-22 15:07:11 --> Hooks Class Initialized
DEBUG - 2023-09-22 15:07:11 --> UTF-8 Support Enabled
INFO - 2023-09-22 15:07:11 --> Utf8 Class Initialized
INFO - 2023-09-22 15:07:11 --> URI Class Initialized
INFO - 2023-09-22 15:07:11 --> Router Class Initialized
INFO - 2023-09-22 15:07:11 --> Output Class Initialized
INFO - 2023-09-22 15:07:11 --> Security Class Initialized
DEBUG - 2023-09-22 15:07:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-22 15:07:11 --> Input Class Initialized
INFO - 2023-09-22 15:07:11 --> Language Class Initialized
INFO - 2023-09-22 15:07:11 --> Language Class Initialized
INFO - 2023-09-22 15:07:11 --> Config Class Initialized
INFO - 2023-09-22 15:07:11 --> Loader Class Initialized
INFO - 2023-09-22 15:07:11 --> Helper loaded: url_helper
INFO - 2023-09-22 15:07:11 --> Helper loaded: file_helper
INFO - 2023-09-22 15:07:11 --> Helper loaded: form_helper
INFO - 2023-09-22 15:07:11 --> Helper loaded: my_helper
INFO - 2023-09-22 15:07:11 --> Database Driver Class Initialized
INFO - 2023-09-22 15:07:11 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-22 15:07:11 --> Controller Class Initialized
INFO - 2023-09-22 15:07:11 --> Final output sent to browser
DEBUG - 2023-09-22 15:07:11 --> Total execution time: 0.0817
INFO - 2023-09-22 15:07:27 --> Config Class Initialized
INFO - 2023-09-22 15:07:27 --> Hooks Class Initialized
DEBUG - 2023-09-22 15:07:27 --> UTF-8 Support Enabled
INFO - 2023-09-22 15:07:27 --> Utf8 Class Initialized
INFO - 2023-09-22 15:07:27 --> URI Class Initialized
INFO - 2023-09-22 15:07:27 --> Router Class Initialized
INFO - 2023-09-22 15:07:27 --> Output Class Initialized
INFO - 2023-09-22 15:07:27 --> Security Class Initialized
DEBUG - 2023-09-22 15:07:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-22 15:07:27 --> Input Class Initialized
INFO - 2023-09-22 15:07:27 --> Language Class Initialized
INFO - 2023-09-22 15:07:27 --> Language Class Initialized
INFO - 2023-09-22 15:07:27 --> Config Class Initialized
INFO - 2023-09-22 15:07:27 --> Loader Class Initialized
INFO - 2023-09-22 15:07:27 --> Helper loaded: url_helper
INFO - 2023-09-22 15:07:27 --> Helper loaded: file_helper
INFO - 2023-09-22 15:07:27 --> Helper loaded: form_helper
INFO - 2023-09-22 15:07:27 --> Helper loaded: my_helper
INFO - 2023-09-22 15:07:27 --> Database Driver Class Initialized
INFO - 2023-09-22 15:07:27 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-22 15:07:27 --> Controller Class Initialized
INFO - 2023-09-22 15:07:27 --> Final output sent to browser
DEBUG - 2023-09-22 15:07:27 --> Total execution time: 0.0767
INFO - 2023-09-22 15:07:54 --> Config Class Initialized
INFO - 2023-09-22 15:07:54 --> Hooks Class Initialized
DEBUG - 2023-09-22 15:07:54 --> UTF-8 Support Enabled
INFO - 2023-09-22 15:07:54 --> Utf8 Class Initialized
INFO - 2023-09-22 15:07:54 --> URI Class Initialized
INFO - 2023-09-22 15:07:54 --> Router Class Initialized
INFO - 2023-09-22 15:07:54 --> Output Class Initialized
INFO - 2023-09-22 15:07:54 --> Security Class Initialized
DEBUG - 2023-09-22 15:07:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-22 15:07:54 --> Input Class Initialized
INFO - 2023-09-22 15:07:54 --> Language Class Initialized
INFO - 2023-09-22 15:07:54 --> Language Class Initialized
INFO - 2023-09-22 15:07:54 --> Config Class Initialized
INFO - 2023-09-22 15:07:54 --> Loader Class Initialized
INFO - 2023-09-22 15:07:54 --> Helper loaded: url_helper
INFO - 2023-09-22 15:07:54 --> Helper loaded: file_helper
INFO - 2023-09-22 15:07:54 --> Helper loaded: form_helper
INFO - 2023-09-22 15:07:54 --> Helper loaded: my_helper
INFO - 2023-09-22 15:07:54 --> Database Driver Class Initialized
INFO - 2023-09-22 15:07:54 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-22 15:07:54 --> Controller Class Initialized
INFO - 2023-09-22 15:07:54 --> Final output sent to browser
DEBUG - 2023-09-22 15:07:54 --> Total execution time: 0.0456
INFO - 2023-09-22 15:07:56 --> Config Class Initialized
INFO - 2023-09-22 15:07:56 --> Hooks Class Initialized
DEBUG - 2023-09-22 15:07:56 --> UTF-8 Support Enabled
INFO - 2023-09-22 15:07:56 --> Utf8 Class Initialized
INFO - 2023-09-22 15:07:56 --> URI Class Initialized
INFO - 2023-09-22 15:07:56 --> Router Class Initialized
INFO - 2023-09-22 15:07:56 --> Output Class Initialized
INFO - 2023-09-22 15:07:56 --> Security Class Initialized
DEBUG - 2023-09-22 15:07:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-22 15:07:56 --> Input Class Initialized
INFO - 2023-09-22 15:07:56 --> Language Class Initialized
INFO - 2023-09-22 15:07:56 --> Language Class Initialized
INFO - 2023-09-22 15:07:56 --> Config Class Initialized
INFO - 2023-09-22 15:07:56 --> Loader Class Initialized
INFO - 2023-09-22 15:07:56 --> Helper loaded: url_helper
INFO - 2023-09-22 15:07:56 --> Helper loaded: file_helper
INFO - 2023-09-22 15:07:56 --> Helper loaded: form_helper
INFO - 2023-09-22 15:07:56 --> Helper loaded: my_helper
INFO - 2023-09-22 15:07:56 --> Database Driver Class Initialized
INFO - 2023-09-22 15:07:56 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-22 15:07:56 --> Controller Class Initialized
INFO - 2023-09-22 15:07:56 --> Final output sent to browser
DEBUG - 2023-09-22 15:07:56 --> Total execution time: 0.0380
INFO - 2023-09-22 15:07:59 --> Config Class Initialized
INFO - 2023-09-22 15:07:59 --> Hooks Class Initialized
DEBUG - 2023-09-22 15:07:59 --> UTF-8 Support Enabled
INFO - 2023-09-22 15:07:59 --> Utf8 Class Initialized
INFO - 2023-09-22 15:07:59 --> URI Class Initialized
INFO - 2023-09-22 15:07:59 --> Router Class Initialized
INFO - 2023-09-22 15:07:59 --> Output Class Initialized
INFO - 2023-09-22 15:07:59 --> Security Class Initialized
DEBUG - 2023-09-22 15:07:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-22 15:07:59 --> Input Class Initialized
INFO - 2023-09-22 15:07:59 --> Language Class Initialized
INFO - 2023-09-22 15:07:59 --> Language Class Initialized
INFO - 2023-09-22 15:07:59 --> Config Class Initialized
INFO - 2023-09-22 15:07:59 --> Loader Class Initialized
INFO - 2023-09-22 15:07:59 --> Helper loaded: url_helper
INFO - 2023-09-22 15:07:59 --> Helper loaded: file_helper
INFO - 2023-09-22 15:07:59 --> Helper loaded: form_helper
INFO - 2023-09-22 15:07:59 --> Helper loaded: my_helper
INFO - 2023-09-22 15:07:59 --> Database Driver Class Initialized
INFO - 2023-09-22 15:07:59 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-22 15:07:59 --> Controller Class Initialized
INFO - 2023-09-22 15:07:59 --> Final output sent to browser
DEBUG - 2023-09-22 15:07:59 --> Total execution time: 0.0663
INFO - 2023-09-22 15:08:16 --> Config Class Initialized
INFO - 2023-09-22 15:08:16 --> Hooks Class Initialized
DEBUG - 2023-09-22 15:08:16 --> UTF-8 Support Enabled
INFO - 2023-09-22 15:08:16 --> Utf8 Class Initialized
INFO - 2023-09-22 15:08:16 --> URI Class Initialized
INFO - 2023-09-22 15:08:16 --> Router Class Initialized
INFO - 2023-09-22 15:08:16 --> Output Class Initialized
INFO - 2023-09-22 15:08:16 --> Security Class Initialized
DEBUG - 2023-09-22 15:08:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-22 15:08:16 --> Input Class Initialized
INFO - 2023-09-22 15:08:16 --> Language Class Initialized
INFO - 2023-09-22 15:08:16 --> Language Class Initialized
INFO - 2023-09-22 15:08:16 --> Config Class Initialized
INFO - 2023-09-22 15:08:16 --> Loader Class Initialized
INFO - 2023-09-22 15:08:16 --> Helper loaded: url_helper
INFO - 2023-09-22 15:08:16 --> Helper loaded: file_helper
INFO - 2023-09-22 15:08:16 --> Helper loaded: form_helper
INFO - 2023-09-22 15:08:16 --> Helper loaded: my_helper
INFO - 2023-09-22 15:08:16 --> Database Driver Class Initialized
INFO - 2023-09-22 15:08:16 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-22 15:08:16 --> Controller Class Initialized
DEBUG - 2023-09-22 15:08:16 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/views/list.php
DEBUG - 2023-09-22 15:08:16 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-09-22 15:08:16 --> Final output sent to browser
DEBUG - 2023-09-22 15:08:16 --> Total execution time: 0.0396
INFO - 2023-09-22 15:08:16 --> Config Class Initialized
INFO - 2023-09-22 15:08:16 --> Hooks Class Initialized
DEBUG - 2023-09-22 15:08:16 --> UTF-8 Support Enabled
INFO - 2023-09-22 15:08:16 --> Utf8 Class Initialized
INFO - 2023-09-22 15:08:16 --> URI Class Initialized
INFO - 2023-09-22 15:08:16 --> Router Class Initialized
INFO - 2023-09-22 15:08:16 --> Output Class Initialized
INFO - 2023-09-22 15:08:16 --> Security Class Initialized
DEBUG - 2023-09-22 15:08:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-22 15:08:16 --> Input Class Initialized
INFO - 2023-09-22 15:08:16 --> Language Class Initialized
INFO - 2023-09-22 15:08:16 --> Language Class Initialized
INFO - 2023-09-22 15:08:16 --> Config Class Initialized
INFO - 2023-09-22 15:08:16 --> Loader Class Initialized
INFO - 2023-09-22 15:08:16 --> Helper loaded: url_helper
INFO - 2023-09-22 15:08:16 --> Helper loaded: file_helper
INFO - 2023-09-22 15:08:16 --> Helper loaded: form_helper
INFO - 2023-09-22 15:08:16 --> Helper loaded: my_helper
INFO - 2023-09-22 15:08:16 --> Database Driver Class Initialized
INFO - 2023-09-22 15:08:16 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-22 15:08:16 --> Controller Class Initialized
INFO - 2023-09-22 15:08:24 --> Config Class Initialized
INFO - 2023-09-22 15:08:24 --> Hooks Class Initialized
DEBUG - 2023-09-22 15:08:24 --> UTF-8 Support Enabled
INFO - 2023-09-22 15:08:24 --> Utf8 Class Initialized
INFO - 2023-09-22 15:08:24 --> URI Class Initialized
INFO - 2023-09-22 15:08:24 --> Router Class Initialized
INFO - 2023-09-22 15:08:24 --> Output Class Initialized
INFO - 2023-09-22 15:08:24 --> Security Class Initialized
DEBUG - 2023-09-22 15:08:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-22 15:08:24 --> Input Class Initialized
INFO - 2023-09-22 15:08:24 --> Language Class Initialized
INFO - 2023-09-22 15:08:24 --> Language Class Initialized
INFO - 2023-09-22 15:08:24 --> Config Class Initialized
INFO - 2023-09-22 15:08:24 --> Loader Class Initialized
INFO - 2023-09-22 15:08:24 --> Helper loaded: url_helper
INFO - 2023-09-22 15:08:24 --> Helper loaded: file_helper
INFO - 2023-09-22 15:08:24 --> Helper loaded: form_helper
INFO - 2023-09-22 15:08:24 --> Helper loaded: my_helper
INFO - 2023-09-22 15:08:24 --> Database Driver Class Initialized
INFO - 2023-09-22 15:08:24 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-22 15:08:24 --> Controller Class Initialized
INFO - 2023-09-22 15:08:24 --> Final output sent to browser
DEBUG - 2023-09-22 15:08:24 --> Total execution time: 0.0365
INFO - 2023-09-22 15:08:33 --> Config Class Initialized
INFO - 2023-09-22 15:08:33 --> Hooks Class Initialized
DEBUG - 2023-09-22 15:08:33 --> UTF-8 Support Enabled
INFO - 2023-09-22 15:08:33 --> Utf8 Class Initialized
INFO - 2023-09-22 15:08:33 --> URI Class Initialized
INFO - 2023-09-22 15:08:33 --> Router Class Initialized
INFO - 2023-09-22 15:08:33 --> Output Class Initialized
INFO - 2023-09-22 15:08:33 --> Security Class Initialized
DEBUG - 2023-09-22 15:08:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-22 15:08:33 --> Input Class Initialized
INFO - 2023-09-22 15:08:33 --> Language Class Initialized
INFO - 2023-09-22 15:08:33 --> Language Class Initialized
INFO - 2023-09-22 15:08:33 --> Config Class Initialized
INFO - 2023-09-22 15:08:33 --> Loader Class Initialized
INFO - 2023-09-22 15:08:33 --> Helper loaded: url_helper
INFO - 2023-09-22 15:08:33 --> Helper loaded: file_helper
INFO - 2023-09-22 15:08:33 --> Helper loaded: form_helper
INFO - 2023-09-22 15:08:33 --> Helper loaded: my_helper
INFO - 2023-09-22 15:08:33 --> Database Driver Class Initialized
INFO - 2023-09-22 15:08:33 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-22 15:08:33 --> Controller Class Initialized
INFO - 2023-09-22 15:08:33 --> Final output sent to browser
DEBUG - 2023-09-22 15:08:33 --> Total execution time: 0.0361
INFO - 2023-09-22 15:08:49 --> Config Class Initialized
INFO - 2023-09-22 15:08:49 --> Hooks Class Initialized
DEBUG - 2023-09-22 15:08:49 --> UTF-8 Support Enabled
INFO - 2023-09-22 15:08:49 --> Utf8 Class Initialized
INFO - 2023-09-22 15:08:49 --> URI Class Initialized
INFO - 2023-09-22 15:08:49 --> Router Class Initialized
INFO - 2023-09-22 15:08:49 --> Output Class Initialized
INFO - 2023-09-22 15:08:49 --> Security Class Initialized
DEBUG - 2023-09-22 15:08:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-22 15:08:49 --> Input Class Initialized
INFO - 2023-09-22 15:08:49 --> Language Class Initialized
INFO - 2023-09-22 15:08:49 --> Language Class Initialized
INFO - 2023-09-22 15:08:49 --> Config Class Initialized
INFO - 2023-09-22 15:08:49 --> Loader Class Initialized
INFO - 2023-09-22 15:08:49 --> Helper loaded: url_helper
INFO - 2023-09-22 15:08:49 --> Helper loaded: file_helper
INFO - 2023-09-22 15:08:49 --> Helper loaded: form_helper
INFO - 2023-09-22 15:08:49 --> Helper loaded: my_helper
INFO - 2023-09-22 15:08:49 --> Database Driver Class Initialized
INFO - 2023-09-22 15:08:49 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-22 15:08:49 --> Controller Class Initialized
DEBUG - 2023-09-22 15:08:49 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/riwayat_mengajar/views/list.php
DEBUG - 2023-09-22 15:08:49 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-09-22 15:08:49 --> Final output sent to browser
DEBUG - 2023-09-22 15:08:49 --> Total execution time: 0.0350
INFO - 2023-09-22 15:10:43 --> Config Class Initialized
INFO - 2023-09-22 15:10:43 --> Hooks Class Initialized
DEBUG - 2023-09-22 15:10:43 --> UTF-8 Support Enabled
INFO - 2023-09-22 15:10:43 --> Utf8 Class Initialized
INFO - 2023-09-22 15:10:43 --> URI Class Initialized
INFO - 2023-09-22 15:10:43 --> Router Class Initialized
INFO - 2023-09-22 15:10:43 --> Output Class Initialized
INFO - 2023-09-22 15:10:43 --> Security Class Initialized
DEBUG - 2023-09-22 15:10:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-22 15:10:43 --> Input Class Initialized
INFO - 2023-09-22 15:10:43 --> Language Class Initialized
INFO - 2023-09-22 15:10:43 --> Language Class Initialized
INFO - 2023-09-22 15:10:43 --> Config Class Initialized
INFO - 2023-09-22 15:10:43 --> Loader Class Initialized
INFO - 2023-09-22 15:10:43 --> Helper loaded: url_helper
INFO - 2023-09-22 15:10:43 --> Helper loaded: file_helper
INFO - 2023-09-22 15:10:43 --> Helper loaded: form_helper
INFO - 2023-09-22 15:10:43 --> Helper loaded: my_helper
INFO - 2023-09-22 15:10:43 --> Database Driver Class Initialized
INFO - 2023-09-22 15:10:43 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-22 15:10:43 --> Controller Class Initialized
DEBUG - 2023-09-22 15:10:43 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/view_mapel/views/v_view_mapel.php
DEBUG - 2023-09-22 15:10:43 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-09-22 15:10:43 --> Final output sent to browser
DEBUG - 2023-09-22 15:10:43 --> Total execution time: 0.0387
INFO - 2023-09-22 15:10:46 --> Config Class Initialized
INFO - 2023-09-22 15:10:46 --> Hooks Class Initialized
DEBUG - 2023-09-22 15:10:46 --> UTF-8 Support Enabled
INFO - 2023-09-22 15:10:46 --> Utf8 Class Initialized
INFO - 2023-09-22 15:10:46 --> URI Class Initialized
INFO - 2023-09-22 15:10:46 --> Router Class Initialized
INFO - 2023-09-22 15:10:46 --> Output Class Initialized
INFO - 2023-09-22 15:10:46 --> Security Class Initialized
DEBUG - 2023-09-22 15:10:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-22 15:10:46 --> Input Class Initialized
INFO - 2023-09-22 15:10:46 --> Language Class Initialized
INFO - 2023-09-22 15:10:46 --> Language Class Initialized
INFO - 2023-09-22 15:10:46 --> Config Class Initialized
INFO - 2023-09-22 15:10:46 --> Loader Class Initialized
INFO - 2023-09-22 15:10:46 --> Helper loaded: url_helper
INFO - 2023-09-22 15:10:46 --> Helper loaded: file_helper
INFO - 2023-09-22 15:10:46 --> Helper loaded: form_helper
INFO - 2023-09-22 15:10:46 --> Helper loaded: my_helper
INFO - 2023-09-22 15:10:46 --> Database Driver Class Initialized
INFO - 2023-09-22 15:10:46 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-22 15:10:46 --> Controller Class Initialized
DEBUG - 2023-09-22 15:10:46 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_catatan_guru/views/list.php
DEBUG - 2023-09-22 15:10:46 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-09-22 15:10:46 --> Final output sent to browser
DEBUG - 2023-09-22 15:10:46 --> Total execution time: 0.0386
INFO - 2023-09-22 15:11:24 --> Config Class Initialized
INFO - 2023-09-22 15:11:24 --> Hooks Class Initialized
DEBUG - 2023-09-22 15:11:24 --> UTF-8 Support Enabled
INFO - 2023-09-22 15:11:24 --> Utf8 Class Initialized
INFO - 2023-09-22 15:11:24 --> URI Class Initialized
INFO - 2023-09-22 15:11:24 --> Router Class Initialized
INFO - 2023-09-22 15:11:24 --> Output Class Initialized
INFO - 2023-09-22 15:11:24 --> Security Class Initialized
DEBUG - 2023-09-22 15:11:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-22 15:11:24 --> Input Class Initialized
INFO - 2023-09-22 15:11:24 --> Language Class Initialized
INFO - 2023-09-22 15:11:24 --> Language Class Initialized
INFO - 2023-09-22 15:11:24 --> Config Class Initialized
INFO - 2023-09-22 15:11:24 --> Loader Class Initialized
INFO - 2023-09-22 15:11:24 --> Helper loaded: url_helper
INFO - 2023-09-22 15:11:24 --> Helper loaded: file_helper
INFO - 2023-09-22 15:11:24 --> Helper loaded: form_helper
INFO - 2023-09-22 15:11:24 --> Helper loaded: my_helper
INFO - 2023-09-22 15:11:24 --> Database Driver Class Initialized
INFO - 2023-09-22 15:11:24 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-22 15:11:24 --> Controller Class Initialized
INFO - 2023-09-22 15:11:24 --> Final output sent to browser
DEBUG - 2023-09-22 15:11:24 --> Total execution time: 0.1119
INFO - 2023-09-22 15:11:26 --> Config Class Initialized
INFO - 2023-09-22 15:11:26 --> Hooks Class Initialized
DEBUG - 2023-09-22 15:11:26 --> UTF-8 Support Enabled
INFO - 2023-09-22 15:11:26 --> Utf8 Class Initialized
INFO - 2023-09-22 15:11:26 --> URI Class Initialized
INFO - 2023-09-22 15:11:26 --> Router Class Initialized
INFO - 2023-09-22 15:11:26 --> Output Class Initialized
INFO - 2023-09-22 15:11:26 --> Security Class Initialized
DEBUG - 2023-09-22 15:11:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-22 15:11:26 --> Input Class Initialized
INFO - 2023-09-22 15:11:26 --> Language Class Initialized
INFO - 2023-09-22 15:11:26 --> Language Class Initialized
INFO - 2023-09-22 15:11:26 --> Config Class Initialized
INFO - 2023-09-22 15:11:26 --> Loader Class Initialized
INFO - 2023-09-22 15:11:26 --> Helper loaded: url_helper
INFO - 2023-09-22 15:11:26 --> Helper loaded: file_helper
INFO - 2023-09-22 15:11:26 --> Helper loaded: form_helper
INFO - 2023-09-22 15:11:26 --> Helper loaded: my_helper
INFO - 2023-09-22 15:11:26 --> Database Driver Class Initialized
INFO - 2023-09-22 15:11:26 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-22 15:11:26 --> Controller Class Initialized
INFO - 2023-09-22 15:11:26 --> Final output sent to browser
DEBUG - 2023-09-22 15:11:26 --> Total execution time: 0.0383
INFO - 2023-09-22 15:11:27 --> Config Class Initialized
INFO - 2023-09-22 15:11:27 --> Hooks Class Initialized
DEBUG - 2023-09-22 15:11:27 --> UTF-8 Support Enabled
INFO - 2023-09-22 15:11:27 --> Utf8 Class Initialized
INFO - 2023-09-22 15:11:27 --> URI Class Initialized
INFO - 2023-09-22 15:11:27 --> Router Class Initialized
INFO - 2023-09-22 15:11:27 --> Output Class Initialized
INFO - 2023-09-22 15:11:27 --> Security Class Initialized
DEBUG - 2023-09-22 15:11:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-22 15:11:27 --> Input Class Initialized
INFO - 2023-09-22 15:11:27 --> Language Class Initialized
INFO - 2023-09-22 15:11:27 --> Language Class Initialized
INFO - 2023-09-22 15:11:27 --> Config Class Initialized
INFO - 2023-09-22 15:11:27 --> Loader Class Initialized
INFO - 2023-09-22 15:11:27 --> Helper loaded: url_helper
INFO - 2023-09-22 15:11:27 --> Helper loaded: file_helper
INFO - 2023-09-22 15:11:27 --> Helper loaded: form_helper
INFO - 2023-09-22 15:11:27 --> Helper loaded: my_helper
INFO - 2023-09-22 15:11:27 --> Database Driver Class Initialized
INFO - 2023-09-22 15:11:27 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-22 15:11:27 --> Controller Class Initialized
DEBUG - 2023-09-22 15:11:27 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/view_mapel/views/v_view_mapel.php
DEBUG - 2023-09-22 15:11:27 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-09-22 15:11:27 --> Final output sent to browser
DEBUG - 2023-09-22 15:11:27 --> Total execution time: 0.0322
INFO - 2023-09-22 15:11:29 --> Config Class Initialized
INFO - 2023-09-22 15:11:29 --> Hooks Class Initialized
DEBUG - 2023-09-22 15:11:29 --> UTF-8 Support Enabled
INFO - 2023-09-22 15:11:29 --> Utf8 Class Initialized
INFO - 2023-09-22 15:11:29 --> URI Class Initialized
INFO - 2023-09-22 15:11:29 --> Router Class Initialized
INFO - 2023-09-22 15:11:29 --> Output Class Initialized
INFO - 2023-09-22 15:11:29 --> Security Class Initialized
DEBUG - 2023-09-22 15:11:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-22 15:11:29 --> Input Class Initialized
INFO - 2023-09-22 15:11:29 --> Language Class Initialized
INFO - 2023-09-22 15:11:29 --> Language Class Initialized
INFO - 2023-09-22 15:11:29 --> Config Class Initialized
INFO - 2023-09-22 15:11:29 --> Loader Class Initialized
INFO - 2023-09-22 15:11:29 --> Helper loaded: url_helper
INFO - 2023-09-22 15:11:29 --> Helper loaded: file_helper
INFO - 2023-09-22 15:11:29 --> Helper loaded: form_helper
INFO - 2023-09-22 15:11:29 --> Helper loaded: my_helper
INFO - 2023-09-22 15:11:29 --> Database Driver Class Initialized
INFO - 2023-09-22 15:11:29 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-22 15:11:29 --> Controller Class Initialized
DEBUG - 2023-09-22 15:11:29 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/view_mapel/views/v_view_mapel.php
DEBUG - 2023-09-22 15:11:29 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-09-22 15:11:29 --> Final output sent to browser
DEBUG - 2023-09-22 15:11:29 --> Total execution time: 0.0694
INFO - 2023-09-22 15:11:31 --> Config Class Initialized
INFO - 2023-09-22 15:11:31 --> Hooks Class Initialized
DEBUG - 2023-09-22 15:11:31 --> UTF-8 Support Enabled
INFO - 2023-09-22 15:11:31 --> Utf8 Class Initialized
INFO - 2023-09-22 15:11:31 --> URI Class Initialized
INFO - 2023-09-22 15:11:31 --> Router Class Initialized
INFO - 2023-09-22 15:11:31 --> Output Class Initialized
INFO - 2023-09-22 15:11:31 --> Security Class Initialized
DEBUG - 2023-09-22 15:11:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-22 15:11:31 --> Input Class Initialized
INFO - 2023-09-22 15:11:31 --> Language Class Initialized
INFO - 2023-09-22 15:11:31 --> Language Class Initialized
INFO - 2023-09-22 15:11:31 --> Config Class Initialized
INFO - 2023-09-22 15:11:31 --> Loader Class Initialized
INFO - 2023-09-22 15:11:31 --> Helper loaded: url_helper
INFO - 2023-09-22 15:11:31 --> Helper loaded: file_helper
INFO - 2023-09-22 15:11:31 --> Helper loaded: form_helper
INFO - 2023-09-22 15:11:31 --> Helper loaded: my_helper
INFO - 2023-09-22 15:11:31 --> Database Driver Class Initialized
INFO - 2023-09-22 15:11:31 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-22 15:11:31 --> Controller Class Initialized
DEBUG - 2023-09-22 15:11:31 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/view_mapel/views/v_view_mapel.php
DEBUG - 2023-09-22 15:11:31 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-09-22 15:11:31 --> Final output sent to browser
DEBUG - 2023-09-22 15:11:31 --> Total execution time: 0.0362
INFO - 2023-09-22 15:11:33 --> Config Class Initialized
INFO - 2023-09-22 15:11:33 --> Hooks Class Initialized
DEBUG - 2023-09-22 15:11:33 --> UTF-8 Support Enabled
INFO - 2023-09-22 15:11:33 --> Utf8 Class Initialized
INFO - 2023-09-22 15:11:33 --> URI Class Initialized
INFO - 2023-09-22 15:11:33 --> Router Class Initialized
INFO - 2023-09-22 15:11:33 --> Output Class Initialized
INFO - 2023-09-22 15:11:33 --> Security Class Initialized
DEBUG - 2023-09-22 15:11:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-22 15:11:33 --> Input Class Initialized
INFO - 2023-09-22 15:11:33 --> Language Class Initialized
INFO - 2023-09-22 15:11:33 --> Language Class Initialized
INFO - 2023-09-22 15:11:33 --> Config Class Initialized
INFO - 2023-09-22 15:11:33 --> Loader Class Initialized
INFO - 2023-09-22 15:11:33 --> Helper loaded: url_helper
INFO - 2023-09-22 15:11:33 --> Helper loaded: file_helper
INFO - 2023-09-22 15:11:33 --> Helper loaded: form_helper
INFO - 2023-09-22 15:11:33 --> Helper loaded: my_helper
INFO - 2023-09-22 15:11:33 --> Database Driver Class Initialized
INFO - 2023-09-22 15:11:33 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-22 15:11:33 --> Controller Class Initialized
DEBUG - 2023-09-22 15:11:33 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/views/list.php
DEBUG - 2023-09-22 15:11:33 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-09-22 15:11:33 --> Final output sent to browser
DEBUG - 2023-09-22 15:11:33 --> Total execution time: 0.0491
INFO - 2023-09-22 15:11:33 --> Config Class Initialized
INFO - 2023-09-22 15:11:33 --> Hooks Class Initialized
DEBUG - 2023-09-22 15:11:33 --> UTF-8 Support Enabled
INFO - 2023-09-22 15:11:33 --> Utf8 Class Initialized
INFO - 2023-09-22 15:11:33 --> URI Class Initialized
INFO - 2023-09-22 15:11:33 --> Router Class Initialized
INFO - 2023-09-22 15:11:33 --> Output Class Initialized
INFO - 2023-09-22 15:11:33 --> Security Class Initialized
DEBUG - 2023-09-22 15:11:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-22 15:11:33 --> Input Class Initialized
INFO - 2023-09-22 15:11:33 --> Language Class Initialized
INFO - 2023-09-22 15:11:33 --> Language Class Initialized
INFO - 2023-09-22 15:11:33 --> Config Class Initialized
INFO - 2023-09-22 15:11:33 --> Loader Class Initialized
INFO - 2023-09-22 15:11:33 --> Helper loaded: url_helper
INFO - 2023-09-22 15:11:33 --> Helper loaded: file_helper
INFO - 2023-09-22 15:11:33 --> Helper loaded: form_helper
INFO - 2023-09-22 15:11:33 --> Helper loaded: my_helper
INFO - 2023-09-22 15:11:33 --> Database Driver Class Initialized
INFO - 2023-09-22 15:11:33 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-22 15:11:33 --> Controller Class Initialized
INFO - 2023-09-22 15:11:40 --> Config Class Initialized
INFO - 2023-09-22 15:11:40 --> Hooks Class Initialized
DEBUG - 2023-09-22 15:11:40 --> UTF-8 Support Enabled
INFO - 2023-09-22 15:11:40 --> Utf8 Class Initialized
INFO - 2023-09-22 15:11:40 --> URI Class Initialized
INFO - 2023-09-22 15:11:40 --> Router Class Initialized
INFO - 2023-09-22 15:11:40 --> Output Class Initialized
INFO - 2023-09-22 15:11:40 --> Security Class Initialized
DEBUG - 2023-09-22 15:11:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-22 15:11:40 --> Input Class Initialized
INFO - 2023-09-22 15:11:40 --> Language Class Initialized
INFO - 2023-09-22 15:11:40 --> Language Class Initialized
INFO - 2023-09-22 15:11:40 --> Config Class Initialized
INFO - 2023-09-22 15:11:40 --> Loader Class Initialized
INFO - 2023-09-22 15:11:40 --> Helper loaded: url_helper
INFO - 2023-09-22 15:11:40 --> Helper loaded: file_helper
INFO - 2023-09-22 15:11:40 --> Helper loaded: form_helper
INFO - 2023-09-22 15:11:40 --> Helper loaded: my_helper
INFO - 2023-09-22 15:11:40 --> Database Driver Class Initialized
INFO - 2023-09-22 15:11:40 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-22 15:11:40 --> Controller Class Initialized
INFO - 2023-09-22 15:11:40 --> Final output sent to browser
DEBUG - 2023-09-22 15:11:40 --> Total execution time: 0.0371
INFO - 2023-09-22 15:12:39 --> Config Class Initialized
INFO - 2023-09-22 15:12:39 --> Hooks Class Initialized
DEBUG - 2023-09-22 15:12:39 --> UTF-8 Support Enabled
INFO - 2023-09-22 15:12:39 --> Utf8 Class Initialized
INFO - 2023-09-22 15:12:39 --> URI Class Initialized
INFO - 2023-09-22 15:12:39 --> Router Class Initialized
INFO - 2023-09-22 15:12:39 --> Output Class Initialized
INFO - 2023-09-22 15:12:39 --> Security Class Initialized
DEBUG - 2023-09-22 15:12:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-22 15:12:39 --> Input Class Initialized
INFO - 2023-09-22 15:12:39 --> Language Class Initialized
INFO - 2023-09-22 15:12:39 --> Language Class Initialized
INFO - 2023-09-22 15:12:39 --> Config Class Initialized
INFO - 2023-09-22 15:12:39 --> Loader Class Initialized
INFO - 2023-09-22 15:12:39 --> Helper loaded: url_helper
INFO - 2023-09-22 15:12:39 --> Helper loaded: file_helper
INFO - 2023-09-22 15:12:39 --> Helper loaded: form_helper
INFO - 2023-09-22 15:12:39 --> Helper loaded: my_helper
INFO - 2023-09-22 15:12:39 --> Database Driver Class Initialized
INFO - 2023-09-22 15:12:39 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-22 15:12:39 --> Controller Class Initialized
INFO - 2023-09-22 15:12:39 --> Config Class Initialized
INFO - 2023-09-22 15:12:39 --> Hooks Class Initialized
DEBUG - 2023-09-22 15:12:39 --> UTF-8 Support Enabled
INFO - 2023-09-22 15:12:39 --> Utf8 Class Initialized
INFO - 2023-09-22 15:12:39 --> URI Class Initialized
DEBUG - 2023-09-22 15:12:39 --> No URI present. Default controller set.
INFO - 2023-09-22 15:12:39 --> Router Class Initialized
INFO - 2023-09-22 15:12:39 --> Output Class Initialized
INFO - 2023-09-22 15:12:39 --> Security Class Initialized
DEBUG - 2023-09-22 15:12:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-22 15:12:39 --> Input Class Initialized
INFO - 2023-09-22 15:12:39 --> Language Class Initialized
INFO - 2023-09-22 15:12:39 --> Language Class Initialized
INFO - 2023-09-22 15:12:39 --> Config Class Initialized
INFO - 2023-09-22 15:12:39 --> Loader Class Initialized
INFO - 2023-09-22 15:12:39 --> Helper loaded: url_helper
INFO - 2023-09-22 15:12:39 --> Helper loaded: file_helper
INFO - 2023-09-22 15:12:39 --> Helper loaded: form_helper
INFO - 2023-09-22 15:12:39 --> Helper loaded: my_helper
INFO - 2023-09-22 15:12:39 --> Database Driver Class Initialized
INFO - 2023-09-22 15:12:39 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-22 15:12:39 --> Controller Class Initialized
DEBUG - 2023-09-22 15:12:39 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/home/views/v_home_guru.php
DEBUG - 2023-09-22 15:12:39 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-09-22 15:12:39 --> Final output sent to browser
DEBUG - 2023-09-22 15:12:39 --> Total execution time: 0.0621
INFO - 2023-09-22 15:12:40 --> Final output sent to browser
DEBUG - 2023-09-22 15:12:40 --> Total execution time: 0.4390
INFO - 2023-09-22 15:12:48 --> Config Class Initialized
INFO - 2023-09-22 15:12:48 --> Hooks Class Initialized
DEBUG - 2023-09-22 15:12:48 --> UTF-8 Support Enabled
INFO - 2023-09-22 15:12:48 --> Utf8 Class Initialized
INFO - 2023-09-22 15:12:48 --> URI Class Initialized
INFO - 2023-09-22 15:12:48 --> Router Class Initialized
INFO - 2023-09-22 15:12:48 --> Output Class Initialized
INFO - 2023-09-22 15:12:48 --> Security Class Initialized
DEBUG - 2023-09-22 15:12:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-22 15:12:48 --> Input Class Initialized
INFO - 2023-09-22 15:12:48 --> Language Class Initialized
INFO - 2023-09-22 15:12:48 --> Language Class Initialized
INFO - 2023-09-22 15:12:48 --> Config Class Initialized
INFO - 2023-09-22 15:12:48 --> Loader Class Initialized
INFO - 2023-09-22 15:12:48 --> Helper loaded: url_helper
INFO - 2023-09-22 15:12:48 --> Helper loaded: file_helper
INFO - 2023-09-22 15:12:48 --> Helper loaded: form_helper
INFO - 2023-09-22 15:12:48 --> Helper loaded: my_helper
INFO - 2023-09-22 15:12:48 --> Database Driver Class Initialized
INFO - 2023-09-22 15:12:48 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-22 15:12:48 --> Controller Class Initialized
DEBUG - 2023-09-22 15:12:48 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/view_mapel/views/v_view_mapel.php
DEBUG - 2023-09-22 15:12:48 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-09-22 15:12:48 --> Final output sent to browser
DEBUG - 2023-09-22 15:12:48 --> Total execution time: 0.0368
INFO - 2023-09-22 15:12:48 --> Config Class Initialized
INFO - 2023-09-22 15:12:48 --> Hooks Class Initialized
DEBUG - 2023-09-22 15:12:48 --> UTF-8 Support Enabled
INFO - 2023-09-22 15:12:48 --> Utf8 Class Initialized
INFO - 2023-09-22 15:12:48 --> URI Class Initialized
INFO - 2023-09-22 15:12:48 --> Router Class Initialized
INFO - 2023-09-22 15:12:48 --> Output Class Initialized
INFO - 2023-09-22 15:12:48 --> Security Class Initialized
DEBUG - 2023-09-22 15:12:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-22 15:12:48 --> Input Class Initialized
INFO - 2023-09-22 15:12:48 --> Language Class Initialized
INFO - 2023-09-22 15:12:48 --> Language Class Initialized
INFO - 2023-09-22 15:12:48 --> Config Class Initialized
INFO - 2023-09-22 15:12:48 --> Loader Class Initialized
INFO - 2023-09-22 15:12:48 --> Helper loaded: url_helper
INFO - 2023-09-22 15:12:48 --> Helper loaded: file_helper
INFO - 2023-09-22 15:12:48 --> Helper loaded: form_helper
INFO - 2023-09-22 15:12:48 --> Helper loaded: my_helper
INFO - 2023-09-22 15:12:48 --> Database Driver Class Initialized
INFO - 2023-09-22 15:12:48 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-22 15:12:48 --> Controller Class Initialized
DEBUG - 2023-09-22 15:12:48 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_catatan_homeroom/views/list.php
DEBUG - 2023-09-22 15:12:48 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-09-22 15:12:48 --> Final output sent to browser
DEBUG - 2023-09-22 15:12:48 --> Total execution time: 0.0360
INFO - 2023-09-22 15:12:50 --> Config Class Initialized
INFO - 2023-09-22 15:12:50 --> Hooks Class Initialized
DEBUG - 2023-09-22 15:12:50 --> UTF-8 Support Enabled
INFO - 2023-09-22 15:12:50 --> Utf8 Class Initialized
INFO - 2023-09-22 15:12:50 --> URI Class Initialized
INFO - 2023-09-22 15:12:50 --> Router Class Initialized
INFO - 2023-09-22 15:12:50 --> Output Class Initialized
INFO - 2023-09-22 15:12:50 --> Security Class Initialized
DEBUG - 2023-09-22 15:12:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-22 15:12:50 --> Input Class Initialized
INFO - 2023-09-22 15:12:50 --> Language Class Initialized
INFO - 2023-09-22 15:12:51 --> Language Class Initialized
INFO - 2023-09-22 15:12:51 --> Config Class Initialized
INFO - 2023-09-22 15:12:51 --> Loader Class Initialized
INFO - 2023-09-22 15:12:51 --> Helper loaded: url_helper
INFO - 2023-09-22 15:12:51 --> Helper loaded: file_helper
INFO - 2023-09-22 15:12:51 --> Helper loaded: form_helper
INFO - 2023-09-22 15:12:51 --> Helper loaded: my_helper
INFO - 2023-09-22 15:12:51 --> Database Driver Class Initialized
INFO - 2023-09-22 15:12:51 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-22 15:12:51 --> Controller Class Initialized
DEBUG - 2023-09-22 15:12:51 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/views/list.php
DEBUG - 2023-09-22 15:12:51 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-09-22 15:12:51 --> Final output sent to browser
DEBUG - 2023-09-22 15:12:51 --> Total execution time: 0.0609
INFO - 2023-09-22 15:12:51 --> Config Class Initialized
INFO - 2023-09-22 15:12:51 --> Hooks Class Initialized
DEBUG - 2023-09-22 15:12:51 --> UTF-8 Support Enabled
INFO - 2023-09-22 15:12:51 --> Utf8 Class Initialized
INFO - 2023-09-22 15:12:51 --> URI Class Initialized
INFO - 2023-09-22 15:12:51 --> Router Class Initialized
INFO - 2023-09-22 15:12:51 --> Output Class Initialized
INFO - 2023-09-22 15:12:51 --> Security Class Initialized
DEBUG - 2023-09-22 15:12:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-22 15:12:51 --> Input Class Initialized
INFO - 2023-09-22 15:12:51 --> Language Class Initialized
INFO - 2023-09-22 15:12:51 --> Language Class Initialized
INFO - 2023-09-22 15:12:51 --> Config Class Initialized
INFO - 2023-09-22 15:12:51 --> Loader Class Initialized
INFO - 2023-09-22 15:12:51 --> Helper loaded: url_helper
INFO - 2023-09-22 15:12:51 --> Helper loaded: file_helper
INFO - 2023-09-22 15:12:51 --> Helper loaded: form_helper
INFO - 2023-09-22 15:12:51 --> Helper loaded: my_helper
INFO - 2023-09-22 15:12:51 --> Database Driver Class Initialized
INFO - 2023-09-22 15:12:51 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-22 15:12:51 --> Controller Class Initialized
INFO - 2023-09-22 15:12:54 --> Config Class Initialized
INFO - 2023-09-22 15:12:54 --> Hooks Class Initialized
DEBUG - 2023-09-22 15:12:54 --> UTF-8 Support Enabled
INFO - 2023-09-22 15:12:54 --> Utf8 Class Initialized
INFO - 2023-09-22 15:12:54 --> URI Class Initialized
INFO - 2023-09-22 15:12:54 --> Router Class Initialized
INFO - 2023-09-22 15:12:54 --> Output Class Initialized
INFO - 2023-09-22 15:12:54 --> Security Class Initialized
DEBUG - 2023-09-22 15:12:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-22 15:12:54 --> Input Class Initialized
INFO - 2023-09-22 15:12:54 --> Language Class Initialized
INFO - 2023-09-22 15:12:54 --> Language Class Initialized
INFO - 2023-09-22 15:12:54 --> Config Class Initialized
INFO - 2023-09-22 15:12:54 --> Loader Class Initialized
INFO - 2023-09-22 15:12:54 --> Helper loaded: url_helper
INFO - 2023-09-22 15:12:54 --> Helper loaded: file_helper
INFO - 2023-09-22 15:12:54 --> Helper loaded: form_helper
INFO - 2023-09-22 15:12:54 --> Helper loaded: my_helper
INFO - 2023-09-22 15:12:54 --> Database Driver Class Initialized
INFO - 2023-09-22 15:12:54 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-22 15:12:54 --> Controller Class Initialized
INFO - 2023-09-22 15:12:54 --> Final output sent to browser
DEBUG - 2023-09-22 15:12:54 --> Total execution time: 0.0558
INFO - 2023-09-22 15:13:20 --> Config Class Initialized
INFO - 2023-09-22 15:13:20 --> Hooks Class Initialized
DEBUG - 2023-09-22 15:13:20 --> UTF-8 Support Enabled
INFO - 2023-09-22 15:13:20 --> Utf8 Class Initialized
INFO - 2023-09-22 15:13:20 --> URI Class Initialized
INFO - 2023-09-22 15:13:20 --> Router Class Initialized
INFO - 2023-09-22 15:13:20 --> Output Class Initialized
INFO - 2023-09-22 15:13:20 --> Security Class Initialized
DEBUG - 2023-09-22 15:13:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-22 15:13:20 --> Input Class Initialized
INFO - 2023-09-22 15:13:20 --> Language Class Initialized
INFO - 2023-09-22 15:13:20 --> Language Class Initialized
INFO - 2023-09-22 15:13:20 --> Config Class Initialized
INFO - 2023-09-22 15:13:20 --> Loader Class Initialized
INFO - 2023-09-22 15:13:20 --> Helper loaded: url_helper
INFO - 2023-09-22 15:13:20 --> Helper loaded: file_helper
INFO - 2023-09-22 15:13:20 --> Helper loaded: form_helper
INFO - 2023-09-22 15:13:20 --> Helper loaded: my_helper
INFO - 2023-09-22 15:13:20 --> Database Driver Class Initialized
INFO - 2023-09-22 15:13:20 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-22 15:13:20 --> Controller Class Initialized
INFO - 2023-09-22 15:13:20 --> Final output sent to browser
DEBUG - 2023-09-22 15:13:20 --> Total execution time: 0.0611
INFO - 2023-09-22 15:16:58 --> Config Class Initialized
INFO - 2023-09-22 15:16:58 --> Hooks Class Initialized
DEBUG - 2023-09-22 15:16:58 --> UTF-8 Support Enabled
INFO - 2023-09-22 15:16:58 --> Utf8 Class Initialized
INFO - 2023-09-22 15:16:58 --> URI Class Initialized
INFO - 2023-09-22 15:16:58 --> Router Class Initialized
INFO - 2023-09-22 15:16:58 --> Output Class Initialized
INFO - 2023-09-22 15:16:58 --> Security Class Initialized
DEBUG - 2023-09-22 15:16:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-22 15:16:58 --> Input Class Initialized
INFO - 2023-09-22 15:16:58 --> Language Class Initialized
INFO - 2023-09-22 15:16:58 --> Language Class Initialized
INFO - 2023-09-22 15:16:58 --> Config Class Initialized
INFO - 2023-09-22 15:16:58 --> Loader Class Initialized
INFO - 2023-09-22 15:16:58 --> Helper loaded: url_helper
INFO - 2023-09-22 15:16:58 --> Helper loaded: file_helper
INFO - 2023-09-22 15:16:58 --> Helper loaded: form_helper
INFO - 2023-09-22 15:16:58 --> Helper loaded: my_helper
INFO - 2023-09-22 15:16:58 --> Database Driver Class Initialized
INFO - 2023-09-22 15:16:58 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-22 15:16:58 --> Controller Class Initialized
DEBUG - 2023-09-22 15:16:58 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/view_mapel/views/v_view_mapel.php
DEBUG - 2023-09-22 15:16:58 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-09-22 15:16:58 --> Final output sent to browser
DEBUG - 2023-09-22 15:16:58 --> Total execution time: 0.0308
INFO - 2023-09-22 15:17:02 --> Config Class Initialized
INFO - 2023-09-22 15:17:02 --> Hooks Class Initialized
DEBUG - 2023-09-22 15:17:02 --> UTF-8 Support Enabled
INFO - 2023-09-22 15:17:02 --> Utf8 Class Initialized
INFO - 2023-09-22 15:17:02 --> URI Class Initialized
INFO - 2023-09-22 15:17:02 --> Router Class Initialized
INFO - 2023-09-22 15:17:02 --> Output Class Initialized
INFO - 2023-09-22 15:17:02 --> Security Class Initialized
DEBUG - 2023-09-22 15:17:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-22 15:17:02 --> Input Class Initialized
INFO - 2023-09-22 15:17:02 --> Language Class Initialized
INFO - 2023-09-22 15:17:02 --> Language Class Initialized
INFO - 2023-09-22 15:17:02 --> Config Class Initialized
INFO - 2023-09-22 15:17:02 --> Loader Class Initialized
INFO - 2023-09-22 15:17:02 --> Helper loaded: url_helper
INFO - 2023-09-22 15:17:02 --> Helper loaded: file_helper
INFO - 2023-09-22 15:17:02 --> Helper loaded: form_helper
INFO - 2023-09-22 15:17:02 --> Helper loaded: my_helper
INFO - 2023-09-22 15:17:02 --> Database Driver Class Initialized
INFO - 2023-09-22 15:17:02 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-22 15:17:02 --> Controller Class Initialized
DEBUG - 2023-09-22 15:17:02 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/views/list.php
DEBUG - 2023-09-22 15:17:02 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-09-22 15:17:02 --> Final output sent to browser
DEBUG - 2023-09-22 15:17:02 --> Total execution time: 0.0476
INFO - 2023-09-22 15:17:02 --> Config Class Initialized
INFO - 2023-09-22 15:17:02 --> Hooks Class Initialized
DEBUG - 2023-09-22 15:17:02 --> UTF-8 Support Enabled
INFO - 2023-09-22 15:17:02 --> Utf8 Class Initialized
INFO - 2023-09-22 15:17:02 --> URI Class Initialized
INFO - 2023-09-22 15:17:02 --> Router Class Initialized
INFO - 2023-09-22 15:17:03 --> Output Class Initialized
INFO - 2023-09-22 15:17:03 --> Security Class Initialized
DEBUG - 2023-09-22 15:17:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-22 15:17:03 --> Input Class Initialized
INFO - 2023-09-22 15:17:03 --> Language Class Initialized
INFO - 2023-09-22 15:17:03 --> Language Class Initialized
INFO - 2023-09-22 15:17:03 --> Config Class Initialized
INFO - 2023-09-22 15:17:03 --> Loader Class Initialized
INFO - 2023-09-22 15:17:03 --> Helper loaded: url_helper
INFO - 2023-09-22 15:17:03 --> Helper loaded: file_helper
INFO - 2023-09-22 15:17:03 --> Helper loaded: form_helper
INFO - 2023-09-22 15:17:03 --> Helper loaded: my_helper
INFO - 2023-09-22 15:17:03 --> Database Driver Class Initialized
INFO - 2023-09-22 15:17:03 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-22 15:17:03 --> Controller Class Initialized
INFO - 2023-09-22 15:17:09 --> Config Class Initialized
INFO - 2023-09-22 15:17:09 --> Hooks Class Initialized
DEBUG - 2023-09-22 15:17:09 --> UTF-8 Support Enabled
INFO - 2023-09-22 15:17:09 --> Utf8 Class Initialized
INFO - 2023-09-22 15:17:09 --> URI Class Initialized
DEBUG - 2023-09-22 15:17:09 --> No URI present. Default controller set.
INFO - 2023-09-22 15:17:09 --> Router Class Initialized
INFO - 2023-09-22 15:17:09 --> Output Class Initialized
INFO - 2023-09-22 15:17:09 --> Security Class Initialized
DEBUG - 2023-09-22 15:17:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-22 15:17:09 --> Input Class Initialized
INFO - 2023-09-22 15:17:09 --> Language Class Initialized
INFO - 2023-09-22 15:17:09 --> Language Class Initialized
INFO - 2023-09-22 15:17:09 --> Config Class Initialized
INFO - 2023-09-22 15:17:09 --> Loader Class Initialized
INFO - 2023-09-22 15:17:09 --> Helper loaded: url_helper
INFO - 2023-09-22 15:17:09 --> Helper loaded: file_helper
INFO - 2023-09-22 15:17:09 --> Helper loaded: form_helper
INFO - 2023-09-22 15:17:09 --> Helper loaded: my_helper
INFO - 2023-09-22 15:17:09 --> Database Driver Class Initialized
INFO - 2023-09-22 15:17:09 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-22 15:17:09 --> Controller Class Initialized
DEBUG - 2023-09-22 15:17:09 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/home/views/v_home_guru.php
DEBUG - 2023-09-22 15:17:09 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-09-22 15:17:09 --> Final output sent to browser
DEBUG - 2023-09-22 15:17:09 --> Total execution time: 0.0358
INFO - 2023-09-22 15:17:14 --> Config Class Initialized
INFO - 2023-09-22 15:17:14 --> Hooks Class Initialized
DEBUG - 2023-09-22 15:17:14 --> UTF-8 Support Enabled
INFO - 2023-09-22 15:17:14 --> Utf8 Class Initialized
INFO - 2023-09-22 15:17:14 --> URI Class Initialized
INFO - 2023-09-22 15:17:14 --> Router Class Initialized
INFO - 2023-09-22 15:17:14 --> Output Class Initialized
INFO - 2023-09-22 15:17:14 --> Security Class Initialized
DEBUG - 2023-09-22 15:17:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-22 15:17:14 --> Input Class Initialized
INFO - 2023-09-22 15:17:14 --> Language Class Initialized
INFO - 2023-09-22 15:17:14 --> Language Class Initialized
INFO - 2023-09-22 15:17:14 --> Config Class Initialized
INFO - 2023-09-22 15:17:14 --> Loader Class Initialized
INFO - 2023-09-22 15:17:14 --> Helper loaded: url_helper
INFO - 2023-09-22 15:17:14 --> Helper loaded: file_helper
INFO - 2023-09-22 15:17:14 --> Helper loaded: form_helper
INFO - 2023-09-22 15:17:14 --> Helper loaded: my_helper
INFO - 2023-09-22 15:17:14 --> Database Driver Class Initialized
INFO - 2023-09-22 15:17:14 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-22 15:17:14 --> Controller Class Initialized
DEBUG - 2023-09-22 15:17:14 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/view_mapel/views/v_view_mapel.php
DEBUG - 2023-09-22 15:17:14 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-09-22 15:17:14 --> Final output sent to browser
DEBUG - 2023-09-22 15:17:14 --> Total execution time: 0.0351
INFO - 2023-09-22 15:17:18 --> Config Class Initialized
INFO - 2023-09-22 15:17:18 --> Hooks Class Initialized
DEBUG - 2023-09-22 15:17:18 --> UTF-8 Support Enabled
INFO - 2023-09-22 15:17:18 --> Utf8 Class Initialized
INFO - 2023-09-22 15:17:18 --> URI Class Initialized
INFO - 2023-09-22 15:17:18 --> Router Class Initialized
INFO - 2023-09-22 15:17:18 --> Output Class Initialized
INFO - 2023-09-22 15:17:18 --> Security Class Initialized
DEBUG - 2023-09-22 15:17:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-22 15:17:18 --> Input Class Initialized
INFO - 2023-09-22 15:17:18 --> Language Class Initialized
INFO - 2023-09-22 15:17:18 --> Language Class Initialized
INFO - 2023-09-22 15:17:18 --> Config Class Initialized
INFO - 2023-09-22 15:17:18 --> Loader Class Initialized
INFO - 2023-09-22 15:17:18 --> Helper loaded: url_helper
INFO - 2023-09-22 15:17:18 --> Helper loaded: file_helper
INFO - 2023-09-22 15:17:18 --> Helper loaded: form_helper
INFO - 2023-09-22 15:17:18 --> Helper loaded: my_helper
INFO - 2023-09-22 15:17:18 --> Database Driver Class Initialized
INFO - 2023-09-22 15:17:18 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-22 15:17:18 --> Controller Class Initialized
DEBUG - 2023-09-22 15:17:18 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/views/list.php
DEBUG - 2023-09-22 15:17:18 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-09-22 15:17:18 --> Final output sent to browser
DEBUG - 2023-09-22 15:17:18 --> Total execution time: 0.0430
INFO - 2023-09-22 15:17:19 --> Config Class Initialized
INFO - 2023-09-22 15:17:19 --> Hooks Class Initialized
DEBUG - 2023-09-22 15:17:19 --> UTF-8 Support Enabled
INFO - 2023-09-22 15:17:19 --> Utf8 Class Initialized
INFO - 2023-09-22 15:17:19 --> URI Class Initialized
INFO - 2023-09-22 15:17:19 --> Router Class Initialized
INFO - 2023-09-22 15:17:19 --> Output Class Initialized
INFO - 2023-09-22 15:17:19 --> Security Class Initialized
DEBUG - 2023-09-22 15:17:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-22 15:17:19 --> Input Class Initialized
INFO - 2023-09-22 15:17:19 --> Language Class Initialized
INFO - 2023-09-22 15:17:19 --> Language Class Initialized
INFO - 2023-09-22 15:17:19 --> Config Class Initialized
INFO - 2023-09-22 15:17:19 --> Loader Class Initialized
INFO - 2023-09-22 15:17:19 --> Helper loaded: url_helper
INFO - 2023-09-22 15:17:19 --> Helper loaded: file_helper
INFO - 2023-09-22 15:17:19 --> Helper loaded: form_helper
INFO - 2023-09-22 15:17:19 --> Helper loaded: my_helper
INFO - 2023-09-22 15:17:19 --> Database Driver Class Initialized
INFO - 2023-09-22 15:17:19 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-22 15:17:19 --> Controller Class Initialized
INFO - 2023-09-22 15:17:28 --> Config Class Initialized
INFO - 2023-09-22 15:17:28 --> Hooks Class Initialized
DEBUG - 2023-09-22 15:17:28 --> UTF-8 Support Enabled
INFO - 2023-09-22 15:17:28 --> Utf8 Class Initialized
INFO - 2023-09-22 15:17:28 --> URI Class Initialized
INFO - 2023-09-22 15:17:28 --> Router Class Initialized
INFO - 2023-09-22 15:17:28 --> Output Class Initialized
INFO - 2023-09-22 15:17:28 --> Security Class Initialized
DEBUG - 2023-09-22 15:17:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-22 15:17:28 --> Input Class Initialized
INFO - 2023-09-22 15:17:28 --> Language Class Initialized
INFO - 2023-09-22 15:17:28 --> Language Class Initialized
INFO - 2023-09-22 15:17:28 --> Config Class Initialized
INFO - 2023-09-22 15:17:28 --> Loader Class Initialized
INFO - 2023-09-22 15:17:28 --> Helper loaded: url_helper
INFO - 2023-09-22 15:17:28 --> Helper loaded: file_helper
INFO - 2023-09-22 15:17:28 --> Helper loaded: form_helper
INFO - 2023-09-22 15:17:28 --> Helper loaded: my_helper
INFO - 2023-09-22 15:17:28 --> Database Driver Class Initialized
INFO - 2023-09-22 15:17:28 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-22 15:17:28 --> Controller Class Initialized
INFO - 2023-09-22 15:17:28 --> Final output sent to browser
DEBUG - 2023-09-22 15:17:28 --> Total execution time: 0.0312
INFO - 2023-09-22 15:18:43 --> Config Class Initialized
INFO - 2023-09-22 15:18:43 --> Hooks Class Initialized
DEBUG - 2023-09-22 15:18:43 --> UTF-8 Support Enabled
INFO - 2023-09-22 15:18:43 --> Utf8 Class Initialized
INFO - 2023-09-22 15:18:43 --> URI Class Initialized
INFO - 2023-09-22 15:18:43 --> Router Class Initialized
INFO - 2023-09-22 15:18:43 --> Output Class Initialized
INFO - 2023-09-22 15:18:43 --> Security Class Initialized
DEBUG - 2023-09-22 15:18:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-22 15:18:43 --> Input Class Initialized
INFO - 2023-09-22 15:18:43 --> Language Class Initialized
INFO - 2023-09-22 15:18:43 --> Language Class Initialized
INFO - 2023-09-22 15:18:43 --> Config Class Initialized
INFO - 2023-09-22 15:18:43 --> Loader Class Initialized
INFO - 2023-09-22 15:18:43 --> Helper loaded: url_helper
INFO - 2023-09-22 15:18:43 --> Helper loaded: file_helper
INFO - 2023-09-22 15:18:43 --> Helper loaded: form_helper
INFO - 2023-09-22 15:18:43 --> Helper loaded: my_helper
INFO - 2023-09-22 15:18:43 --> Database Driver Class Initialized
INFO - 2023-09-22 15:18:43 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-22 15:18:43 --> Controller Class Initialized
DEBUG - 2023-09-22 15:18:43 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/view_mapel/views/v_view_mapel.php
DEBUG - 2023-09-22 15:18:43 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-09-22 15:18:43 --> Final output sent to browser
DEBUG - 2023-09-22 15:18:43 --> Total execution time: 0.0367
INFO - 2023-09-22 15:18:46 --> Config Class Initialized
INFO - 2023-09-22 15:18:46 --> Hooks Class Initialized
DEBUG - 2023-09-22 15:18:46 --> UTF-8 Support Enabled
INFO - 2023-09-22 15:18:46 --> Utf8 Class Initialized
INFO - 2023-09-22 15:18:46 --> URI Class Initialized
INFO - 2023-09-22 15:18:46 --> Router Class Initialized
INFO - 2023-09-22 15:18:46 --> Output Class Initialized
INFO - 2023-09-22 15:18:46 --> Security Class Initialized
DEBUG - 2023-09-22 15:18:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-22 15:18:46 --> Input Class Initialized
INFO - 2023-09-22 15:18:46 --> Language Class Initialized
INFO - 2023-09-22 15:18:46 --> Language Class Initialized
INFO - 2023-09-22 15:18:46 --> Config Class Initialized
INFO - 2023-09-22 15:18:46 --> Loader Class Initialized
INFO - 2023-09-22 15:18:46 --> Helper loaded: url_helper
INFO - 2023-09-22 15:18:46 --> Helper loaded: file_helper
INFO - 2023-09-22 15:18:46 --> Helper loaded: form_helper
INFO - 2023-09-22 15:18:46 --> Helper loaded: my_helper
INFO - 2023-09-22 15:18:46 --> Database Driver Class Initialized
INFO - 2023-09-22 15:18:46 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-22 15:18:46 --> Controller Class Initialized
DEBUG - 2023-09-22 15:18:46 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/view_mapel/views/v_view_mapel.php
DEBUG - 2023-09-22 15:18:46 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-09-22 15:18:46 --> Final output sent to browser
DEBUG - 2023-09-22 15:18:46 --> Total execution time: 0.0359
INFO - 2023-09-22 15:18:46 --> Config Class Initialized
INFO - 2023-09-22 15:18:46 --> Hooks Class Initialized
DEBUG - 2023-09-22 15:18:46 --> UTF-8 Support Enabled
INFO - 2023-09-22 15:18:46 --> Utf8 Class Initialized
INFO - 2023-09-22 15:18:46 --> URI Class Initialized
INFO - 2023-09-22 15:18:46 --> Router Class Initialized
INFO - 2023-09-22 15:18:46 --> Output Class Initialized
INFO - 2023-09-22 15:18:46 --> Security Class Initialized
DEBUG - 2023-09-22 15:18:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-22 15:18:46 --> Input Class Initialized
INFO - 2023-09-22 15:18:46 --> Language Class Initialized
INFO - 2023-09-22 15:18:46 --> Language Class Initialized
INFO - 2023-09-22 15:18:46 --> Config Class Initialized
INFO - 2023-09-22 15:18:46 --> Loader Class Initialized
INFO - 2023-09-22 15:18:46 --> Helper loaded: url_helper
INFO - 2023-09-22 15:18:46 --> Helper loaded: file_helper
INFO - 2023-09-22 15:18:46 --> Helper loaded: form_helper
INFO - 2023-09-22 15:18:46 --> Helper loaded: my_helper
INFO - 2023-09-22 15:18:46 --> Database Driver Class Initialized
INFO - 2023-09-22 15:18:46 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-22 15:18:46 --> Controller Class Initialized
DEBUG - 2023-09-22 15:18:46 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/views/list.php
DEBUG - 2023-09-22 15:18:46 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-09-22 15:18:46 --> Final output sent to browser
DEBUG - 2023-09-22 15:18:46 --> Total execution time: 0.0397
INFO - 2023-09-22 15:18:47 --> Config Class Initialized
INFO - 2023-09-22 15:18:47 --> Hooks Class Initialized
DEBUG - 2023-09-22 15:18:47 --> UTF-8 Support Enabled
INFO - 2023-09-22 15:18:47 --> Utf8 Class Initialized
INFO - 2023-09-22 15:18:47 --> URI Class Initialized
INFO - 2023-09-22 15:18:47 --> Router Class Initialized
INFO - 2023-09-22 15:18:47 --> Output Class Initialized
INFO - 2023-09-22 15:18:47 --> Security Class Initialized
DEBUG - 2023-09-22 15:18:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-22 15:18:47 --> Input Class Initialized
INFO - 2023-09-22 15:18:47 --> Language Class Initialized
INFO - 2023-09-22 15:18:47 --> Language Class Initialized
INFO - 2023-09-22 15:18:47 --> Config Class Initialized
INFO - 2023-09-22 15:18:47 --> Loader Class Initialized
INFO - 2023-09-22 15:18:47 --> Helper loaded: url_helper
INFO - 2023-09-22 15:18:47 --> Helper loaded: file_helper
INFO - 2023-09-22 15:18:47 --> Helper loaded: form_helper
INFO - 2023-09-22 15:18:47 --> Helper loaded: my_helper
INFO - 2023-09-22 15:18:47 --> Database Driver Class Initialized
INFO - 2023-09-22 15:18:47 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-22 15:18:47 --> Controller Class Initialized
INFO - 2023-09-22 15:18:49 --> Config Class Initialized
INFO - 2023-09-22 15:18:49 --> Hooks Class Initialized
DEBUG - 2023-09-22 15:18:49 --> UTF-8 Support Enabled
INFO - 2023-09-22 15:18:49 --> Utf8 Class Initialized
INFO - 2023-09-22 15:18:49 --> URI Class Initialized
INFO - 2023-09-22 15:18:49 --> Router Class Initialized
INFO - 2023-09-22 15:18:49 --> Output Class Initialized
INFO - 2023-09-22 15:18:49 --> Security Class Initialized
DEBUG - 2023-09-22 15:18:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-22 15:18:49 --> Input Class Initialized
INFO - 2023-09-22 15:18:49 --> Language Class Initialized
INFO - 2023-09-22 15:18:49 --> Language Class Initialized
INFO - 2023-09-22 15:18:49 --> Config Class Initialized
INFO - 2023-09-22 15:18:49 --> Loader Class Initialized
INFO - 2023-09-22 15:18:49 --> Helper loaded: url_helper
INFO - 2023-09-22 15:18:49 --> Helper loaded: file_helper
INFO - 2023-09-22 15:18:49 --> Helper loaded: form_helper
INFO - 2023-09-22 15:18:49 --> Helper loaded: my_helper
INFO - 2023-09-22 15:18:49 --> Database Driver Class Initialized
INFO - 2023-09-22 15:18:49 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-22 15:18:49 --> Controller Class Initialized
DEBUG - 2023-09-22 15:18:49 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_catatan_guru/views/list.php
DEBUG - 2023-09-22 15:18:49 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-09-22 15:18:49 --> Final output sent to browser
DEBUG - 2023-09-22 15:18:49 --> Total execution time: 0.0493
INFO - 2023-09-22 15:18:53 --> Config Class Initialized
INFO - 2023-09-22 15:18:53 --> Hooks Class Initialized
DEBUG - 2023-09-22 15:18:53 --> UTF-8 Support Enabled
INFO - 2023-09-22 15:18:53 --> Utf8 Class Initialized
INFO - 2023-09-22 15:18:53 --> URI Class Initialized
INFO - 2023-09-22 15:18:53 --> Router Class Initialized
INFO - 2023-09-22 15:18:53 --> Output Class Initialized
INFO - 2023-09-22 15:18:53 --> Security Class Initialized
DEBUG - 2023-09-22 15:18:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-22 15:18:53 --> Input Class Initialized
INFO - 2023-09-22 15:18:53 --> Language Class Initialized
INFO - 2023-09-22 15:18:53 --> Language Class Initialized
INFO - 2023-09-22 15:18:53 --> Config Class Initialized
INFO - 2023-09-22 15:18:53 --> Loader Class Initialized
INFO - 2023-09-22 15:18:53 --> Helper loaded: url_helper
INFO - 2023-09-22 15:18:53 --> Helper loaded: file_helper
INFO - 2023-09-22 15:18:53 --> Helper loaded: form_helper
INFO - 2023-09-22 15:18:53 --> Helper loaded: my_helper
INFO - 2023-09-22 15:18:53 --> Database Driver Class Initialized
INFO - 2023-09-22 15:18:53 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-22 15:18:53 --> Controller Class Initialized
INFO - 2023-09-22 15:18:53 --> Final output sent to browser
DEBUG - 2023-09-22 15:18:53 --> Total execution time: 0.0401
INFO - 2023-09-22 15:19:33 --> Config Class Initialized
INFO - 2023-09-22 15:19:33 --> Hooks Class Initialized
DEBUG - 2023-09-22 15:19:33 --> UTF-8 Support Enabled
INFO - 2023-09-22 15:19:33 --> Utf8 Class Initialized
INFO - 2023-09-22 15:19:33 --> URI Class Initialized
DEBUG - 2023-09-22 15:19:33 --> No URI present. Default controller set.
INFO - 2023-09-22 15:19:33 --> Router Class Initialized
INFO - 2023-09-22 15:19:33 --> Output Class Initialized
INFO - 2023-09-22 15:19:33 --> Security Class Initialized
DEBUG - 2023-09-22 15:19:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-22 15:19:33 --> Input Class Initialized
INFO - 2023-09-22 15:19:33 --> Language Class Initialized
INFO - 2023-09-22 15:19:33 --> Language Class Initialized
INFO - 2023-09-22 15:19:33 --> Config Class Initialized
INFO - 2023-09-22 15:19:33 --> Loader Class Initialized
INFO - 2023-09-22 15:19:33 --> Helper loaded: url_helper
INFO - 2023-09-22 15:19:33 --> Helper loaded: file_helper
INFO - 2023-09-22 15:19:33 --> Helper loaded: form_helper
INFO - 2023-09-22 15:19:33 --> Helper loaded: my_helper
INFO - 2023-09-22 15:19:33 --> Database Driver Class Initialized
INFO - 2023-09-22 15:19:33 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-22 15:19:33 --> Controller Class Initialized
DEBUG - 2023-09-22 15:19:33 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/home/views/v_home_guru.php
DEBUG - 2023-09-22 15:19:33 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-09-22 15:19:33 --> Final output sent to browser
DEBUG - 2023-09-22 15:19:33 --> Total execution time: 0.0977
INFO - 2023-09-22 15:19:42 --> Config Class Initialized
INFO - 2023-09-22 15:19:42 --> Hooks Class Initialized
DEBUG - 2023-09-22 15:19:42 --> UTF-8 Support Enabled
INFO - 2023-09-22 15:19:42 --> Utf8 Class Initialized
INFO - 2023-09-22 15:19:42 --> URI Class Initialized
INFO - 2023-09-22 15:19:42 --> Router Class Initialized
INFO - 2023-09-22 15:19:42 --> Output Class Initialized
INFO - 2023-09-22 15:19:42 --> Security Class Initialized
DEBUG - 2023-09-22 15:19:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-22 15:19:42 --> Input Class Initialized
INFO - 2023-09-22 15:19:42 --> Language Class Initialized
INFO - 2023-09-22 15:19:42 --> Language Class Initialized
INFO - 2023-09-22 15:19:42 --> Config Class Initialized
INFO - 2023-09-22 15:19:42 --> Loader Class Initialized
INFO - 2023-09-22 15:19:42 --> Helper loaded: url_helper
INFO - 2023-09-22 15:19:42 --> Helper loaded: file_helper
INFO - 2023-09-22 15:19:42 --> Helper loaded: form_helper
INFO - 2023-09-22 15:19:42 --> Helper loaded: my_helper
INFO - 2023-09-22 15:19:42 --> Database Driver Class Initialized
INFO - 2023-09-22 15:19:42 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-22 15:19:42 --> Controller Class Initialized
DEBUG - 2023-09-22 15:19:42 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/view_mapel/views/v_view_mapel.php
DEBUG - 2023-09-22 15:19:42 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-09-22 15:19:42 --> Final output sent to browser
DEBUG - 2023-09-22 15:19:42 --> Total execution time: 0.0312
INFO - 2023-09-22 15:19:46 --> Config Class Initialized
INFO - 2023-09-22 15:19:46 --> Hooks Class Initialized
DEBUG - 2023-09-22 15:19:46 --> UTF-8 Support Enabled
INFO - 2023-09-22 15:19:46 --> Utf8 Class Initialized
INFO - 2023-09-22 15:19:46 --> URI Class Initialized
INFO - 2023-09-22 15:19:46 --> Router Class Initialized
INFO - 2023-09-22 15:19:46 --> Output Class Initialized
INFO - 2023-09-22 15:19:46 --> Security Class Initialized
DEBUG - 2023-09-22 15:19:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-22 15:19:46 --> Input Class Initialized
INFO - 2023-09-22 15:19:46 --> Language Class Initialized
INFO - 2023-09-22 15:19:46 --> Language Class Initialized
INFO - 2023-09-22 15:19:46 --> Config Class Initialized
INFO - 2023-09-22 15:19:46 --> Loader Class Initialized
INFO - 2023-09-22 15:19:46 --> Helper loaded: url_helper
INFO - 2023-09-22 15:19:46 --> Helper loaded: file_helper
INFO - 2023-09-22 15:19:46 --> Helper loaded: form_helper
INFO - 2023-09-22 15:19:46 --> Helper loaded: my_helper
INFO - 2023-09-22 15:19:46 --> Database Driver Class Initialized
INFO - 2023-09-22 15:19:46 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-22 15:19:46 --> Controller Class Initialized
DEBUG - 2023-09-22 15:19:46 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/home/views/v_ubah_password.php
DEBUG - 2023-09-22 15:19:46 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-09-22 15:19:46 --> Final output sent to browser
DEBUG - 2023-09-22 15:19:46 --> Total execution time: 0.0347
INFO - 2023-09-22 15:19:56 --> Config Class Initialized
INFO - 2023-09-22 15:19:56 --> Hooks Class Initialized
DEBUG - 2023-09-22 15:19:56 --> UTF-8 Support Enabled
INFO - 2023-09-22 15:19:56 --> Utf8 Class Initialized
INFO - 2023-09-22 15:19:56 --> URI Class Initialized
INFO - 2023-09-22 15:19:56 --> Router Class Initialized
INFO - 2023-09-22 15:19:56 --> Output Class Initialized
INFO - 2023-09-22 15:19:56 --> Security Class Initialized
DEBUG - 2023-09-22 15:19:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-22 15:19:56 --> Input Class Initialized
INFO - 2023-09-22 15:19:56 --> Language Class Initialized
INFO - 2023-09-22 15:19:56 --> Language Class Initialized
INFO - 2023-09-22 15:19:56 --> Config Class Initialized
INFO - 2023-09-22 15:19:56 --> Loader Class Initialized
INFO - 2023-09-22 15:19:56 --> Helper loaded: url_helper
INFO - 2023-09-22 15:19:56 --> Helper loaded: file_helper
INFO - 2023-09-22 15:19:56 --> Helper loaded: form_helper
INFO - 2023-09-22 15:19:56 --> Helper loaded: my_helper
INFO - 2023-09-22 15:19:56 --> Database Driver Class Initialized
INFO - 2023-09-22 15:19:56 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-22 15:19:56 --> Controller Class Initialized
DEBUG - 2023-09-22 15:19:56 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_catatan_guru/views/list.php
DEBUG - 2023-09-22 15:19:56 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-09-22 15:19:56 --> Final output sent to browser
DEBUG - 2023-09-22 15:19:56 --> Total execution time: 0.0394
INFO - 2023-09-22 15:20:00 --> Config Class Initialized
INFO - 2023-09-22 15:20:00 --> Hooks Class Initialized
DEBUG - 2023-09-22 15:20:00 --> UTF-8 Support Enabled
INFO - 2023-09-22 15:20:00 --> Utf8 Class Initialized
INFO - 2023-09-22 15:20:00 --> URI Class Initialized
INFO - 2023-09-22 15:20:00 --> Router Class Initialized
INFO - 2023-09-22 15:20:00 --> Output Class Initialized
INFO - 2023-09-22 15:20:00 --> Security Class Initialized
DEBUG - 2023-09-22 15:20:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-22 15:20:00 --> Input Class Initialized
INFO - 2023-09-22 15:20:00 --> Language Class Initialized
INFO - 2023-09-22 15:20:00 --> Language Class Initialized
INFO - 2023-09-22 15:20:00 --> Config Class Initialized
INFO - 2023-09-22 15:20:00 --> Loader Class Initialized
INFO - 2023-09-22 15:20:00 --> Helper loaded: url_helper
INFO - 2023-09-22 15:20:00 --> Helper loaded: file_helper
INFO - 2023-09-22 15:20:00 --> Helper loaded: form_helper
INFO - 2023-09-22 15:20:00 --> Helper loaded: my_helper
INFO - 2023-09-22 15:20:00 --> Database Driver Class Initialized
INFO - 2023-09-22 15:20:00 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-22 15:20:00 --> Controller Class Initialized
INFO - 2023-09-22 15:20:00 --> Final output sent to browser
DEBUG - 2023-09-22 15:20:00 --> Total execution time: 0.0378
INFO - 2023-09-22 15:20:03 --> Config Class Initialized
INFO - 2023-09-22 15:20:03 --> Hooks Class Initialized
DEBUG - 2023-09-22 15:20:03 --> UTF-8 Support Enabled
INFO - 2023-09-22 15:20:03 --> Utf8 Class Initialized
INFO - 2023-09-22 15:20:03 --> URI Class Initialized
INFO - 2023-09-22 15:20:03 --> Router Class Initialized
INFO - 2023-09-22 15:20:03 --> Output Class Initialized
INFO - 2023-09-22 15:20:03 --> Security Class Initialized
DEBUG - 2023-09-22 15:20:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-22 15:20:03 --> Input Class Initialized
INFO - 2023-09-22 15:20:03 --> Language Class Initialized
INFO - 2023-09-22 15:20:03 --> Language Class Initialized
INFO - 2023-09-22 15:20:03 --> Config Class Initialized
INFO - 2023-09-22 15:20:03 --> Loader Class Initialized
INFO - 2023-09-22 15:20:03 --> Helper loaded: url_helper
INFO - 2023-09-22 15:20:03 --> Helper loaded: file_helper
INFO - 2023-09-22 15:20:03 --> Helper loaded: form_helper
INFO - 2023-09-22 15:20:03 --> Helper loaded: my_helper
INFO - 2023-09-22 15:20:04 --> Database Driver Class Initialized
INFO - 2023-09-22 15:20:04 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-22 15:20:04 --> Controller Class Initialized
DEBUG - 2023-09-22 15:20:04 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_catatan_kl1/views/list.php
DEBUG - 2023-09-22 15:20:04 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-09-22 15:20:04 --> Final output sent to browser
DEBUG - 2023-09-22 15:20:04 --> Total execution time: 0.0488
INFO - 2023-09-22 15:20:09 --> Config Class Initialized
INFO - 2023-09-22 15:20:09 --> Hooks Class Initialized
DEBUG - 2023-09-22 15:20:09 --> UTF-8 Support Enabled
INFO - 2023-09-22 15:20:09 --> Utf8 Class Initialized
INFO - 2023-09-22 15:20:09 --> URI Class Initialized
INFO - 2023-09-22 15:20:09 --> Router Class Initialized
INFO - 2023-09-22 15:20:09 --> Output Class Initialized
INFO - 2023-09-22 15:20:09 --> Security Class Initialized
DEBUG - 2023-09-22 15:20:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-22 15:20:09 --> Input Class Initialized
INFO - 2023-09-22 15:20:09 --> Language Class Initialized
INFO - 2023-09-22 15:20:09 --> Language Class Initialized
INFO - 2023-09-22 15:20:09 --> Config Class Initialized
INFO - 2023-09-22 15:20:09 --> Loader Class Initialized
INFO - 2023-09-22 15:20:09 --> Helper loaded: url_helper
INFO - 2023-09-22 15:20:09 --> Helper loaded: file_helper
INFO - 2023-09-22 15:20:09 --> Helper loaded: form_helper
INFO - 2023-09-22 15:20:09 --> Helper loaded: my_helper
INFO - 2023-09-22 15:20:09 --> Database Driver Class Initialized
INFO - 2023-09-22 15:20:09 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-22 15:20:09 --> Controller Class Initialized
DEBUG - 2023-09-22 15:20:09 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/view_mapel/views/v_view_mapel.php
DEBUG - 2023-09-22 15:20:09 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-09-22 15:20:09 --> Final output sent to browser
DEBUG - 2023-09-22 15:20:09 --> Total execution time: 0.0744
INFO - 2023-09-22 15:20:33 --> Config Class Initialized
INFO - 2023-09-22 15:20:33 --> Hooks Class Initialized
DEBUG - 2023-09-22 15:20:33 --> UTF-8 Support Enabled
INFO - 2023-09-22 15:20:33 --> Utf8 Class Initialized
INFO - 2023-09-22 15:20:33 --> URI Class Initialized
INFO - 2023-09-22 15:20:33 --> Router Class Initialized
INFO - 2023-09-22 15:20:33 --> Output Class Initialized
INFO - 2023-09-22 15:20:33 --> Security Class Initialized
DEBUG - 2023-09-22 15:20:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-22 15:20:33 --> Input Class Initialized
INFO - 2023-09-22 15:20:33 --> Language Class Initialized
INFO - 2023-09-22 15:20:33 --> Language Class Initialized
INFO - 2023-09-22 15:20:33 --> Config Class Initialized
INFO - 2023-09-22 15:20:33 --> Loader Class Initialized
INFO - 2023-09-22 15:20:33 --> Helper loaded: url_helper
INFO - 2023-09-22 15:20:33 --> Helper loaded: file_helper
INFO - 2023-09-22 15:20:33 --> Helper loaded: form_helper
INFO - 2023-09-22 15:20:33 --> Helper loaded: my_helper
INFO - 2023-09-22 15:20:33 --> Database Driver Class Initialized
INFO - 2023-09-22 15:20:33 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-22 15:20:33 --> Controller Class Initialized
DEBUG - 2023-09-22 15:20:33 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/list.php
DEBUG - 2023-09-22 15:20:33 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-09-22 15:20:33 --> Final output sent to browser
DEBUG - 2023-09-22 15:20:33 --> Total execution time: 0.0994
INFO - 2023-09-22 15:20:44 --> Config Class Initialized
INFO - 2023-09-22 15:20:44 --> Hooks Class Initialized
DEBUG - 2023-09-22 15:20:44 --> UTF-8 Support Enabled
INFO - 2023-09-22 15:20:44 --> Utf8 Class Initialized
INFO - 2023-09-22 15:20:44 --> URI Class Initialized
INFO - 2023-09-22 15:20:44 --> Router Class Initialized
INFO - 2023-09-22 15:20:44 --> Output Class Initialized
INFO - 2023-09-22 15:20:44 --> Security Class Initialized
DEBUG - 2023-09-22 15:20:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-22 15:20:44 --> Input Class Initialized
INFO - 2023-09-22 15:20:44 --> Language Class Initialized
INFO - 2023-09-22 15:20:44 --> Language Class Initialized
INFO - 2023-09-22 15:20:44 --> Config Class Initialized
INFO - 2023-09-22 15:20:44 --> Loader Class Initialized
INFO - 2023-09-22 15:20:44 --> Helper loaded: url_helper
INFO - 2023-09-22 15:20:44 --> Helper loaded: file_helper
INFO - 2023-09-22 15:20:44 --> Helper loaded: form_helper
INFO - 2023-09-22 15:20:44 --> Helper loaded: my_helper
INFO - 2023-09-22 15:20:45 --> Database Driver Class Initialized
INFO - 2023-09-22 15:20:45 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-22 15:20:45 --> Controller Class Initialized
ERROR - 2023-09-22 15:20:45 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php 110
DEBUG - 2023-09-22 15:20:45 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php
ERROR - 2023-09-22 15:20:45 --> Severity: error --> Exception: Unable to get the size of the image [C:\Users\sallu\Downloads\Logo MH Transparan-01.png] /www/wwwroot/report.mhis.link/bangka/secondary/aset/html2pdf/spipu/html2pdf/src/Html2Pdf.php 1513
INFO - 2023-09-22 15:23:52 --> Config Class Initialized
INFO - 2023-09-22 15:23:52 --> Hooks Class Initialized
DEBUG - 2023-09-22 15:23:52 --> UTF-8 Support Enabled
INFO - 2023-09-22 15:23:52 --> Utf8 Class Initialized
INFO - 2023-09-22 15:23:52 --> URI Class Initialized
DEBUG - 2023-09-22 15:23:52 --> No URI present. Default controller set.
INFO - 2023-09-22 15:23:52 --> Router Class Initialized
INFO - 2023-09-22 15:23:52 --> Output Class Initialized
INFO - 2023-09-22 15:23:52 --> Security Class Initialized
DEBUG - 2023-09-22 15:23:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-22 15:23:52 --> Input Class Initialized
INFO - 2023-09-22 15:23:52 --> Language Class Initialized
INFO - 2023-09-22 15:23:52 --> Language Class Initialized
INFO - 2023-09-22 15:23:52 --> Config Class Initialized
INFO - 2023-09-22 15:23:52 --> Loader Class Initialized
INFO - 2023-09-22 15:23:52 --> Helper loaded: url_helper
INFO - 2023-09-22 15:23:52 --> Helper loaded: file_helper
INFO - 2023-09-22 15:23:52 --> Helper loaded: form_helper
INFO - 2023-09-22 15:23:52 --> Helper loaded: my_helper
INFO - 2023-09-22 15:23:53 --> Database Driver Class Initialized
INFO - 2023-09-22 15:23:53 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-22 15:23:53 --> Controller Class Initialized
DEBUG - 2023-09-22 15:23:53 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/home/views/v_home_guru.php
DEBUG - 2023-09-22 15:23:53 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-09-22 15:23:53 --> Final output sent to browser
DEBUG - 2023-09-22 15:23:53 --> Total execution time: 0.0710
INFO - 2023-09-22 15:24:01 --> Config Class Initialized
INFO - 2023-09-22 15:24:01 --> Hooks Class Initialized
DEBUG - 2023-09-22 15:24:01 --> UTF-8 Support Enabled
INFO - 2023-09-22 15:24:01 --> Utf8 Class Initialized
INFO - 2023-09-22 15:24:01 --> URI Class Initialized
INFO - 2023-09-22 15:24:01 --> Router Class Initialized
INFO - 2023-09-22 15:24:01 --> Output Class Initialized
INFO - 2023-09-22 15:24:01 --> Security Class Initialized
DEBUG - 2023-09-22 15:24:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-22 15:24:01 --> Input Class Initialized
INFO - 2023-09-22 15:24:01 --> Language Class Initialized
INFO - 2023-09-22 15:24:01 --> Language Class Initialized
INFO - 2023-09-22 15:24:01 --> Config Class Initialized
INFO - 2023-09-22 15:24:01 --> Loader Class Initialized
INFO - 2023-09-22 15:24:01 --> Helper loaded: url_helper
INFO - 2023-09-22 15:24:01 --> Helper loaded: file_helper
INFO - 2023-09-22 15:24:01 --> Helper loaded: form_helper
INFO - 2023-09-22 15:24:01 --> Helper loaded: my_helper
INFO - 2023-09-22 15:24:01 --> Database Driver Class Initialized
INFO - 2023-09-22 15:24:01 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-22 15:24:01 --> Controller Class Initialized
DEBUG - 2023-09-22 15:24:01 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/riwayat_mengajar/views/list.php
DEBUG - 2023-09-22 15:24:01 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-09-22 15:24:01 --> Final output sent to browser
DEBUG - 2023-09-22 15:24:01 --> Total execution time: 0.1513
INFO - 2023-09-22 15:24:08 --> Config Class Initialized
INFO - 2023-09-22 15:24:08 --> Hooks Class Initialized
DEBUG - 2023-09-22 15:24:08 --> UTF-8 Support Enabled
INFO - 2023-09-22 15:24:08 --> Utf8 Class Initialized
INFO - 2023-09-22 15:24:08 --> URI Class Initialized
INFO - 2023-09-22 15:24:08 --> Router Class Initialized
INFO - 2023-09-22 15:24:08 --> Output Class Initialized
INFO - 2023-09-22 15:24:08 --> Security Class Initialized
DEBUG - 2023-09-22 15:24:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-22 15:24:08 --> Input Class Initialized
INFO - 2023-09-22 15:24:08 --> Language Class Initialized
INFO - 2023-09-22 15:24:08 --> Language Class Initialized
INFO - 2023-09-22 15:24:08 --> Config Class Initialized
INFO - 2023-09-22 15:24:08 --> Loader Class Initialized
INFO - 2023-09-22 15:24:08 --> Helper loaded: url_helper
INFO - 2023-09-22 15:24:08 --> Helper loaded: file_helper
INFO - 2023-09-22 15:24:08 --> Helper loaded: form_helper
INFO - 2023-09-22 15:24:08 --> Helper loaded: my_helper
INFO - 2023-09-22 15:24:08 --> Database Driver Class Initialized
INFO - 2023-09-22 15:24:08 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-22 15:24:08 --> Controller Class Initialized
DEBUG - 2023-09-22 15:24:08 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_prestasi/views/list.php
DEBUG - 2023-09-22 15:24:08 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-09-22 15:24:08 --> Final output sent to browser
DEBUG - 2023-09-22 15:24:08 --> Total execution time: 0.0374
INFO - 2023-09-22 15:24:09 --> Config Class Initialized
INFO - 2023-09-22 15:24:09 --> Hooks Class Initialized
DEBUG - 2023-09-22 15:24:09 --> UTF-8 Support Enabled
INFO - 2023-09-22 15:24:09 --> Utf8 Class Initialized
INFO - 2023-09-22 15:24:09 --> URI Class Initialized
INFO - 2023-09-22 15:24:09 --> Router Class Initialized
INFO - 2023-09-22 15:24:09 --> Output Class Initialized
INFO - 2023-09-22 15:24:09 --> Security Class Initialized
DEBUG - 2023-09-22 15:24:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-22 15:24:09 --> Input Class Initialized
INFO - 2023-09-22 15:24:09 --> Language Class Initialized
ERROR - 2023-09-22 15:24:09 --> 404 Page Not Found: /index
INFO - 2023-09-22 15:24:09 --> Config Class Initialized
INFO - 2023-09-22 15:24:09 --> Hooks Class Initialized
DEBUG - 2023-09-22 15:24:09 --> UTF-8 Support Enabled
INFO - 2023-09-22 15:24:09 --> Utf8 Class Initialized
INFO - 2023-09-22 15:24:09 --> URI Class Initialized
INFO - 2023-09-22 15:24:09 --> Router Class Initialized
INFO - 2023-09-22 15:24:09 --> Output Class Initialized
INFO - 2023-09-22 15:24:09 --> Security Class Initialized
DEBUG - 2023-09-22 15:24:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-22 15:24:09 --> Input Class Initialized
INFO - 2023-09-22 15:24:09 --> Language Class Initialized
INFO - 2023-09-22 15:24:09 --> Language Class Initialized
INFO - 2023-09-22 15:24:09 --> Config Class Initialized
INFO - 2023-09-22 15:24:09 --> Loader Class Initialized
INFO - 2023-09-22 15:24:09 --> Helper loaded: url_helper
INFO - 2023-09-22 15:24:09 --> Helper loaded: file_helper
INFO - 2023-09-22 15:24:09 --> Helper loaded: form_helper
INFO - 2023-09-22 15:24:09 --> Helper loaded: my_helper
INFO - 2023-09-22 15:24:09 --> Database Driver Class Initialized
INFO - 2023-09-22 15:24:09 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-22 15:24:09 --> Controller Class Initialized
INFO - 2023-09-22 15:24:11 --> Config Class Initialized
INFO - 2023-09-22 15:24:11 --> Hooks Class Initialized
DEBUG - 2023-09-22 15:24:11 --> UTF-8 Support Enabled
INFO - 2023-09-22 15:24:11 --> Utf8 Class Initialized
INFO - 2023-09-22 15:24:11 --> URI Class Initialized
DEBUG - 2023-09-22 15:24:11 --> No URI present. Default controller set.
INFO - 2023-09-22 15:24:11 --> Router Class Initialized
INFO - 2023-09-22 15:24:11 --> Output Class Initialized
INFO - 2023-09-22 15:24:11 --> Security Class Initialized
DEBUG - 2023-09-22 15:24:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-22 15:24:11 --> Input Class Initialized
INFO - 2023-09-22 15:24:11 --> Language Class Initialized
INFO - 2023-09-22 15:24:11 --> Language Class Initialized
INFO - 2023-09-22 15:24:11 --> Config Class Initialized
INFO - 2023-09-22 15:24:11 --> Loader Class Initialized
INFO - 2023-09-22 15:24:11 --> Helper loaded: url_helper
INFO - 2023-09-22 15:24:11 --> Helper loaded: file_helper
INFO - 2023-09-22 15:24:11 --> Helper loaded: form_helper
INFO - 2023-09-22 15:24:11 --> Helper loaded: my_helper
INFO - 2023-09-22 15:24:11 --> Database Driver Class Initialized
INFO - 2023-09-22 15:24:11 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-22 15:24:11 --> Controller Class Initialized
INFO - 2023-09-22 15:24:11 --> Config Class Initialized
INFO - 2023-09-22 15:24:11 --> Hooks Class Initialized
DEBUG - 2023-09-22 15:24:11 --> UTF-8 Support Enabled
INFO - 2023-09-22 15:24:11 --> Utf8 Class Initialized
INFO - 2023-09-22 15:24:11 --> URI Class Initialized
INFO - 2023-09-22 15:24:11 --> Router Class Initialized
INFO - 2023-09-22 15:24:11 --> Output Class Initialized
INFO - 2023-09-22 15:24:11 --> Security Class Initialized
DEBUG - 2023-09-22 15:24:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-22 15:24:11 --> Input Class Initialized
INFO - 2023-09-22 15:24:11 --> Language Class Initialized
INFO - 2023-09-22 15:24:11 --> Language Class Initialized
INFO - 2023-09-22 15:24:11 --> Config Class Initialized
INFO - 2023-09-22 15:24:11 --> Loader Class Initialized
INFO - 2023-09-22 15:24:11 --> Helper loaded: url_helper
INFO - 2023-09-22 15:24:11 --> Helper loaded: file_helper
INFO - 2023-09-22 15:24:11 --> Helper loaded: form_helper
INFO - 2023-09-22 15:24:11 --> Helper loaded: my_helper
INFO - 2023-09-22 15:24:11 --> Database Driver Class Initialized
INFO - 2023-09-22 15:24:11 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-22 15:24:11 --> Controller Class Initialized
DEBUG - 2023-09-22 15:24:11 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/login/views/login.php
DEBUG - 2023-09-22 15:24:11 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-09-22 15:24:11 --> Final output sent to browser
DEBUG - 2023-09-22 15:24:11 --> Total execution time: 0.0453
INFO - 2023-09-22 15:24:14 --> Config Class Initialized
INFO - 2023-09-22 15:24:14 --> Hooks Class Initialized
DEBUG - 2023-09-22 15:24:14 --> UTF-8 Support Enabled
INFO - 2023-09-22 15:24:14 --> Utf8 Class Initialized
INFO - 2023-09-22 15:24:14 --> URI Class Initialized
INFO - 2023-09-22 15:24:14 --> Router Class Initialized
INFO - 2023-09-22 15:24:14 --> Output Class Initialized
INFO - 2023-09-22 15:24:14 --> Security Class Initialized
DEBUG - 2023-09-22 15:24:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-22 15:24:14 --> Input Class Initialized
INFO - 2023-09-22 15:24:14 --> Language Class Initialized
INFO - 2023-09-22 15:24:14 --> Language Class Initialized
INFO - 2023-09-22 15:24:14 --> Config Class Initialized
INFO - 2023-09-22 15:24:14 --> Loader Class Initialized
INFO - 2023-09-22 15:24:14 --> Helper loaded: url_helper
INFO - 2023-09-22 15:24:14 --> Helper loaded: file_helper
INFO - 2023-09-22 15:24:14 --> Helper loaded: form_helper
INFO - 2023-09-22 15:24:14 --> Helper loaded: my_helper
INFO - 2023-09-22 15:24:14 --> Database Driver Class Initialized
INFO - 2023-09-22 15:24:14 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-22 15:24:14 --> Controller Class Initialized
DEBUG - 2023-09-22 15:24:14 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/home/views/v_ubah_password.php
DEBUG - 2023-09-22 15:24:14 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-09-22 15:24:14 --> Final output sent to browser
DEBUG - 2023-09-22 15:24:14 --> Total execution time: 0.0382
INFO - 2023-09-22 15:24:16 --> Config Class Initialized
INFO - 2023-09-22 15:24:16 --> Hooks Class Initialized
DEBUG - 2023-09-22 15:24:16 --> UTF-8 Support Enabled
INFO - 2023-09-22 15:24:16 --> Utf8 Class Initialized
INFO - 2023-09-22 15:24:16 --> URI Class Initialized
INFO - 2023-09-22 15:24:16 --> Router Class Initialized
INFO - 2023-09-22 15:24:16 --> Output Class Initialized
INFO - 2023-09-22 15:24:16 --> Security Class Initialized
DEBUG - 2023-09-22 15:24:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-22 15:24:16 --> Input Class Initialized
INFO - 2023-09-22 15:24:16 --> Language Class Initialized
INFO - 2023-09-22 15:24:16 --> Language Class Initialized
INFO - 2023-09-22 15:24:16 --> Config Class Initialized
INFO - 2023-09-22 15:24:16 --> Loader Class Initialized
INFO - 2023-09-22 15:24:16 --> Helper loaded: url_helper
INFO - 2023-09-22 15:24:16 --> Helper loaded: file_helper
INFO - 2023-09-22 15:24:16 --> Helper loaded: form_helper
INFO - 2023-09-22 15:24:16 --> Helper loaded: my_helper
INFO - 2023-09-22 15:24:16 --> Database Driver Class Initialized
INFO - 2023-09-22 15:24:16 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-22 15:24:16 --> Controller Class Initialized
DEBUG - 2023-09-22 15:24:16 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/riwayat_mengajar/views/list.php
DEBUG - 2023-09-22 15:24:16 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-09-22 15:24:16 --> Final output sent to browser
DEBUG - 2023-09-22 15:24:16 --> Total execution time: 0.0495
INFO - 2023-09-22 15:24:17 --> Config Class Initialized
INFO - 2023-09-22 15:24:17 --> Hooks Class Initialized
DEBUG - 2023-09-22 15:24:17 --> UTF-8 Support Enabled
INFO - 2023-09-22 15:24:17 --> Utf8 Class Initialized
INFO - 2023-09-22 15:24:17 --> URI Class Initialized
INFO - 2023-09-22 15:24:17 --> Router Class Initialized
INFO - 2023-09-22 15:24:17 --> Output Class Initialized
INFO - 2023-09-22 15:24:17 --> Security Class Initialized
DEBUG - 2023-09-22 15:24:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-22 15:24:17 --> Input Class Initialized
INFO - 2023-09-22 15:24:17 --> Language Class Initialized
INFO - 2023-09-22 15:24:17 --> Language Class Initialized
INFO - 2023-09-22 15:24:17 --> Config Class Initialized
INFO - 2023-09-22 15:24:17 --> Loader Class Initialized
INFO - 2023-09-22 15:24:17 --> Helper loaded: url_helper
INFO - 2023-09-22 15:24:17 --> Helper loaded: file_helper
INFO - 2023-09-22 15:24:17 --> Helper loaded: form_helper
INFO - 2023-09-22 15:24:17 --> Helper loaded: my_helper
INFO - 2023-09-22 15:24:17 --> Database Driver Class Initialized
INFO - 2023-09-22 15:24:17 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-22 15:24:17 --> Controller Class Initialized
DEBUG - 2023-09-22 15:24:17 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_catatan_kl2/views/list.php
DEBUG - 2023-09-22 15:24:17 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-09-22 15:24:17 --> Final output sent to browser
DEBUG - 2023-09-22 15:24:17 --> Total execution time: 0.0415
INFO - 2023-09-22 15:24:22 --> Config Class Initialized
INFO - 2023-09-22 15:24:22 --> Hooks Class Initialized
DEBUG - 2023-09-22 15:24:22 --> UTF-8 Support Enabled
INFO - 2023-09-22 15:24:22 --> Utf8 Class Initialized
INFO - 2023-09-22 15:24:22 --> URI Class Initialized
INFO - 2023-09-22 15:24:22 --> Router Class Initialized
INFO - 2023-09-22 15:24:22 --> Output Class Initialized
INFO - 2023-09-22 15:24:22 --> Security Class Initialized
DEBUG - 2023-09-22 15:24:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-22 15:24:22 --> Input Class Initialized
INFO - 2023-09-22 15:24:22 --> Language Class Initialized
INFO - 2023-09-22 15:24:22 --> Language Class Initialized
INFO - 2023-09-22 15:24:22 --> Config Class Initialized
INFO - 2023-09-22 15:24:22 --> Loader Class Initialized
INFO - 2023-09-22 15:24:22 --> Helper loaded: url_helper
INFO - 2023-09-22 15:24:22 --> Helper loaded: file_helper
INFO - 2023-09-22 15:24:22 --> Helper loaded: form_helper
INFO - 2023-09-22 15:24:22 --> Helper loaded: my_helper
INFO - 2023-09-22 15:24:22 --> Database Driver Class Initialized
INFO - 2023-09-22 15:24:22 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-22 15:24:22 --> Controller Class Initialized
DEBUG - 2023-09-22 15:24:22 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_catatan_kl1/views/list.php
DEBUG - 2023-09-22 15:24:22 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-09-22 15:24:22 --> Final output sent to browser
DEBUG - 2023-09-22 15:24:22 --> Total execution time: 0.0356
INFO - 2023-09-22 15:24:23 --> Config Class Initialized
INFO - 2023-09-22 15:24:23 --> Hooks Class Initialized
DEBUG - 2023-09-22 15:24:23 --> UTF-8 Support Enabled
INFO - 2023-09-22 15:24:23 --> Utf8 Class Initialized
INFO - 2023-09-22 15:24:23 --> URI Class Initialized
INFO - 2023-09-22 15:24:23 --> Router Class Initialized
INFO - 2023-09-22 15:24:23 --> Output Class Initialized
INFO - 2023-09-22 15:24:23 --> Security Class Initialized
DEBUG - 2023-09-22 15:24:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-22 15:24:23 --> Input Class Initialized
INFO - 2023-09-22 15:24:23 --> Language Class Initialized
INFO - 2023-09-22 15:24:23 --> Language Class Initialized
INFO - 2023-09-22 15:24:23 --> Config Class Initialized
INFO - 2023-09-22 15:24:23 --> Loader Class Initialized
INFO - 2023-09-22 15:24:23 --> Helper loaded: url_helper
INFO - 2023-09-22 15:24:23 --> Helper loaded: file_helper
INFO - 2023-09-22 15:24:23 --> Helper loaded: form_helper
INFO - 2023-09-22 15:24:23 --> Helper loaded: my_helper
INFO - 2023-09-22 15:24:23 --> Database Driver Class Initialized
INFO - 2023-09-22 15:24:23 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-22 15:24:23 --> Controller Class Initialized
DEBUG - 2023-09-22 15:24:23 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/view_mapel/views/v_view_mapel.php
DEBUG - 2023-09-22 15:24:23 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-09-22 15:24:23 --> Final output sent to browser
DEBUG - 2023-09-22 15:24:23 --> Total execution time: 0.0336
INFO - 2023-09-22 15:24:28 --> Config Class Initialized
INFO - 2023-09-22 15:24:28 --> Hooks Class Initialized
DEBUG - 2023-09-22 15:24:28 --> UTF-8 Support Enabled
INFO - 2023-09-22 15:24:28 --> Utf8 Class Initialized
INFO - 2023-09-22 15:24:28 --> URI Class Initialized
DEBUG - 2023-09-22 15:24:28 --> No URI present. Default controller set.
INFO - 2023-09-22 15:24:28 --> Router Class Initialized
INFO - 2023-09-22 15:24:28 --> Output Class Initialized
INFO - 2023-09-22 15:24:28 --> Security Class Initialized
DEBUG - 2023-09-22 15:24:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-22 15:24:28 --> Input Class Initialized
INFO - 2023-09-22 15:24:28 --> Language Class Initialized
INFO - 2023-09-22 15:24:28 --> Language Class Initialized
INFO - 2023-09-22 15:24:28 --> Config Class Initialized
INFO - 2023-09-22 15:24:28 --> Loader Class Initialized
INFO - 2023-09-22 15:24:28 --> Helper loaded: url_helper
INFO - 2023-09-22 15:24:28 --> Helper loaded: file_helper
INFO - 2023-09-22 15:24:28 --> Helper loaded: form_helper
INFO - 2023-09-22 15:24:28 --> Helper loaded: my_helper
INFO - 2023-09-22 15:24:28 --> Database Driver Class Initialized
INFO - 2023-09-22 15:24:28 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-22 15:24:28 --> Controller Class Initialized
DEBUG - 2023-09-22 15:24:28 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/home/views/v_home_guru.php
DEBUG - 2023-09-22 15:24:28 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-09-22 15:24:28 --> Final output sent to browser
DEBUG - 2023-09-22 15:24:28 --> Total execution time: 0.0460
INFO - 2023-09-22 15:24:29 --> Config Class Initialized
INFO - 2023-09-22 15:24:29 --> Hooks Class Initialized
DEBUG - 2023-09-22 15:24:29 --> UTF-8 Support Enabled
INFO - 2023-09-22 15:24:29 --> Utf8 Class Initialized
INFO - 2023-09-22 15:24:29 --> URI Class Initialized
INFO - 2023-09-22 15:24:29 --> Router Class Initialized
INFO - 2023-09-22 15:24:29 --> Output Class Initialized
INFO - 2023-09-22 15:24:29 --> Security Class Initialized
DEBUG - 2023-09-22 15:24:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-22 15:24:29 --> Input Class Initialized
INFO - 2023-09-22 15:24:29 --> Language Class Initialized
INFO - 2023-09-22 15:24:29 --> Language Class Initialized
INFO - 2023-09-22 15:24:29 --> Config Class Initialized
INFO - 2023-09-22 15:24:29 --> Loader Class Initialized
INFO - 2023-09-22 15:24:29 --> Helper loaded: url_helper
INFO - 2023-09-22 15:24:29 --> Helper loaded: file_helper
INFO - 2023-09-22 15:24:29 --> Helper loaded: form_helper
INFO - 2023-09-22 15:24:29 --> Helper loaded: my_helper
INFO - 2023-09-22 15:24:29 --> Database Driver Class Initialized
INFO - 2023-09-22 15:24:29 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-22 15:24:29 --> Controller Class Initialized
DEBUG - 2023-09-22 15:24:29 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/view_mapel/views/v_view_mapel.php
DEBUG - 2023-09-22 15:24:29 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-09-22 15:24:29 --> Final output sent to browser
DEBUG - 2023-09-22 15:24:29 --> Total execution time: 0.0824
INFO - 2023-09-22 15:24:34 --> Config Class Initialized
INFO - 2023-09-22 15:24:34 --> Hooks Class Initialized
DEBUG - 2023-09-22 15:24:34 --> UTF-8 Support Enabled
INFO - 2023-09-22 15:24:34 --> Utf8 Class Initialized
INFO - 2023-09-22 15:24:34 --> URI Class Initialized
INFO - 2023-09-22 15:24:34 --> Router Class Initialized
INFO - 2023-09-22 15:24:34 --> Output Class Initialized
INFO - 2023-09-22 15:24:34 --> Security Class Initialized
DEBUG - 2023-09-22 15:24:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-22 15:24:34 --> Input Class Initialized
INFO - 2023-09-22 15:24:34 --> Language Class Initialized
INFO - 2023-09-22 15:24:34 --> Language Class Initialized
INFO - 2023-09-22 15:24:34 --> Config Class Initialized
INFO - 2023-09-22 15:24:34 --> Loader Class Initialized
INFO - 2023-09-22 15:24:34 --> Helper loaded: url_helper
INFO - 2023-09-22 15:24:34 --> Helper loaded: file_helper
INFO - 2023-09-22 15:24:34 --> Helper loaded: form_helper
INFO - 2023-09-22 15:24:34 --> Helper loaded: my_helper
INFO - 2023-09-22 15:24:34 --> Database Driver Class Initialized
INFO - 2023-09-22 15:24:34 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-22 15:24:34 --> Controller Class Initialized
DEBUG - 2023-09-22 15:24:34 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/views/list.php
DEBUG - 2023-09-22 15:24:34 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-09-22 15:24:34 --> Final output sent to browser
DEBUG - 2023-09-22 15:24:34 --> Total execution time: 0.0432
INFO - 2023-09-22 15:24:34 --> Config Class Initialized
INFO - 2023-09-22 15:24:34 --> Hooks Class Initialized
DEBUG - 2023-09-22 15:24:34 --> UTF-8 Support Enabled
INFO - 2023-09-22 15:24:34 --> Utf8 Class Initialized
INFO - 2023-09-22 15:24:34 --> URI Class Initialized
INFO - 2023-09-22 15:24:34 --> Router Class Initialized
INFO - 2023-09-22 15:24:34 --> Output Class Initialized
INFO - 2023-09-22 15:24:34 --> Security Class Initialized
DEBUG - 2023-09-22 15:24:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-22 15:24:34 --> Input Class Initialized
INFO - 2023-09-22 15:24:34 --> Language Class Initialized
INFO - 2023-09-22 15:24:34 --> Language Class Initialized
INFO - 2023-09-22 15:24:34 --> Config Class Initialized
INFO - 2023-09-22 15:24:34 --> Loader Class Initialized
INFO - 2023-09-22 15:24:34 --> Helper loaded: url_helper
INFO - 2023-09-22 15:24:34 --> Helper loaded: file_helper
INFO - 2023-09-22 15:24:34 --> Helper loaded: form_helper
INFO - 2023-09-22 15:24:34 --> Helper loaded: my_helper
INFO - 2023-09-22 15:24:34 --> Database Driver Class Initialized
INFO - 2023-09-22 15:24:34 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-22 15:24:34 --> Controller Class Initialized
INFO - 2023-09-22 15:24:40 --> Config Class Initialized
INFO - 2023-09-22 15:24:40 --> Hooks Class Initialized
DEBUG - 2023-09-22 15:24:40 --> UTF-8 Support Enabled
INFO - 2023-09-22 15:24:40 --> Utf8 Class Initialized
INFO - 2023-09-22 15:24:40 --> URI Class Initialized
INFO - 2023-09-22 15:24:40 --> Router Class Initialized
INFO - 2023-09-22 15:24:40 --> Output Class Initialized
INFO - 2023-09-22 15:24:40 --> Security Class Initialized
DEBUG - 2023-09-22 15:24:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-22 15:24:40 --> Input Class Initialized
INFO - 2023-09-22 15:24:40 --> Language Class Initialized
INFO - 2023-09-22 15:24:40 --> Language Class Initialized
INFO - 2023-09-22 15:24:40 --> Config Class Initialized
INFO - 2023-09-22 15:24:40 --> Loader Class Initialized
INFO - 2023-09-22 15:24:40 --> Helper loaded: url_helper
INFO - 2023-09-22 15:24:40 --> Helper loaded: file_helper
INFO - 2023-09-22 15:24:40 --> Helper loaded: form_helper
INFO - 2023-09-22 15:24:40 --> Helper loaded: my_helper
INFO - 2023-09-22 15:24:40 --> Database Driver Class Initialized
INFO - 2023-09-22 15:24:40 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-22 15:24:40 --> Controller Class Initialized
INFO - 2023-09-22 15:24:40 --> Final output sent to browser
DEBUG - 2023-09-22 15:24:40 --> Total execution time: 0.1178
INFO - 2023-09-22 15:24:41 --> Config Class Initialized
INFO - 2023-09-22 15:24:41 --> Hooks Class Initialized
DEBUG - 2023-09-22 15:24:41 --> UTF-8 Support Enabled
INFO - 2023-09-22 15:24:41 --> Utf8 Class Initialized
INFO - 2023-09-22 15:24:41 --> URI Class Initialized
INFO - 2023-09-22 15:24:41 --> Router Class Initialized
INFO - 2023-09-22 15:24:41 --> Output Class Initialized
INFO - 2023-09-22 15:24:41 --> Security Class Initialized
DEBUG - 2023-09-22 15:24:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-22 15:24:41 --> Input Class Initialized
INFO - 2023-09-22 15:24:41 --> Language Class Initialized
INFO - 2023-09-22 15:24:41 --> Language Class Initialized
INFO - 2023-09-22 15:24:41 --> Config Class Initialized
INFO - 2023-09-22 15:24:41 --> Loader Class Initialized
INFO - 2023-09-22 15:24:41 --> Helper loaded: url_helper
INFO - 2023-09-22 15:24:41 --> Helper loaded: file_helper
INFO - 2023-09-22 15:24:41 --> Helper loaded: form_helper
INFO - 2023-09-22 15:24:41 --> Helper loaded: my_helper
INFO - 2023-09-22 15:24:41 --> Database Driver Class Initialized
INFO - 2023-09-22 15:24:41 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-22 15:24:41 --> Controller Class Initialized
INFO - 2023-09-22 15:24:41 --> Final output sent to browser
DEBUG - 2023-09-22 15:24:41 --> Total execution time: 0.0781
INFO - 2023-09-22 15:24:41 --> Config Class Initialized
INFO - 2023-09-22 15:24:41 --> Hooks Class Initialized
DEBUG - 2023-09-22 15:24:41 --> UTF-8 Support Enabled
INFO - 2023-09-22 15:24:41 --> Utf8 Class Initialized
INFO - 2023-09-22 15:24:41 --> URI Class Initialized
INFO - 2023-09-22 15:24:41 --> Router Class Initialized
INFO - 2023-09-22 15:24:41 --> Output Class Initialized
INFO - 2023-09-22 15:24:41 --> Security Class Initialized
DEBUG - 2023-09-22 15:24:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-22 15:24:41 --> Input Class Initialized
INFO - 2023-09-22 15:24:41 --> Language Class Initialized
INFO - 2023-09-22 15:24:41 --> Language Class Initialized
INFO - 2023-09-22 15:24:41 --> Config Class Initialized
INFO - 2023-09-22 15:24:41 --> Loader Class Initialized
INFO - 2023-09-22 15:24:41 --> Helper loaded: url_helper
INFO - 2023-09-22 15:24:41 --> Helper loaded: file_helper
INFO - 2023-09-22 15:24:41 --> Helper loaded: form_helper
INFO - 2023-09-22 15:24:41 --> Helper loaded: my_helper
INFO - 2023-09-22 15:24:41 --> Database Driver Class Initialized
INFO - 2023-09-22 15:24:41 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-22 15:24:41 --> Controller Class Initialized
INFO - 2023-09-22 15:24:41 --> Final output sent to browser
DEBUG - 2023-09-22 15:24:41 --> Total execution time: 0.1141
INFO - 2023-09-22 15:24:43 --> Config Class Initialized
INFO - 2023-09-22 15:24:43 --> Hooks Class Initialized
DEBUG - 2023-09-22 15:24:43 --> UTF-8 Support Enabled
INFO - 2023-09-22 15:24:43 --> Utf8 Class Initialized
INFO - 2023-09-22 15:24:43 --> URI Class Initialized
INFO - 2023-09-22 15:24:43 --> Router Class Initialized
INFO - 2023-09-22 15:24:43 --> Output Class Initialized
INFO - 2023-09-22 15:24:43 --> Security Class Initialized
DEBUG - 2023-09-22 15:24:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-22 15:24:43 --> Input Class Initialized
INFO - 2023-09-22 15:24:43 --> Language Class Initialized
INFO - 2023-09-22 15:24:43 --> Language Class Initialized
INFO - 2023-09-22 15:24:43 --> Config Class Initialized
INFO - 2023-09-22 15:24:43 --> Loader Class Initialized
INFO - 2023-09-22 15:24:43 --> Helper loaded: url_helper
INFO - 2023-09-22 15:24:43 --> Helper loaded: file_helper
INFO - 2023-09-22 15:24:43 --> Helper loaded: form_helper
INFO - 2023-09-22 15:24:43 --> Helper loaded: my_helper
INFO - 2023-09-22 15:24:43 --> Database Driver Class Initialized
INFO - 2023-09-22 15:24:43 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-22 15:24:43 --> Controller Class Initialized
INFO - 2023-09-22 15:24:43 --> Final output sent to browser
DEBUG - 2023-09-22 15:24:43 --> Total execution time: 0.0374
INFO - 2023-09-22 15:25:08 --> Config Class Initialized
INFO - 2023-09-22 15:25:08 --> Hooks Class Initialized
DEBUG - 2023-09-22 15:25:08 --> UTF-8 Support Enabled
INFO - 2023-09-22 15:25:08 --> Utf8 Class Initialized
INFO - 2023-09-22 15:25:08 --> URI Class Initialized
INFO - 2023-09-22 15:25:08 --> Router Class Initialized
INFO - 2023-09-22 15:25:08 --> Output Class Initialized
INFO - 2023-09-22 15:25:08 --> Security Class Initialized
DEBUG - 2023-09-22 15:25:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-22 15:25:08 --> Input Class Initialized
INFO - 2023-09-22 15:25:08 --> Language Class Initialized
INFO - 2023-09-22 15:25:08 --> Language Class Initialized
INFO - 2023-09-22 15:25:08 --> Config Class Initialized
INFO - 2023-09-22 15:25:08 --> Loader Class Initialized
INFO - 2023-09-22 15:25:08 --> Helper loaded: url_helper
INFO - 2023-09-22 15:25:08 --> Helper loaded: file_helper
INFO - 2023-09-22 15:25:08 --> Helper loaded: form_helper
INFO - 2023-09-22 15:25:08 --> Helper loaded: my_helper
INFO - 2023-09-22 15:25:08 --> Database Driver Class Initialized
INFO - 2023-09-22 15:25:08 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-22 15:25:08 --> Controller Class Initialized
INFO - 2023-09-22 15:25:08 --> Helper loaded: cookie_helper
INFO - 2023-09-22 15:25:08 --> Final output sent to browser
DEBUG - 2023-09-22 15:25:08 --> Total execution time: 0.0402
INFO - 2023-09-22 15:25:08 --> Config Class Initialized
INFO - 2023-09-22 15:25:08 --> Hooks Class Initialized
DEBUG - 2023-09-22 15:25:08 --> UTF-8 Support Enabled
INFO - 2023-09-22 15:25:08 --> Utf8 Class Initialized
INFO - 2023-09-22 15:25:08 --> URI Class Initialized
INFO - 2023-09-22 15:25:08 --> Router Class Initialized
INFO - 2023-09-22 15:25:08 --> Output Class Initialized
INFO - 2023-09-22 15:25:08 --> Security Class Initialized
DEBUG - 2023-09-22 15:25:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-22 15:25:08 --> Input Class Initialized
INFO - 2023-09-22 15:25:08 --> Language Class Initialized
INFO - 2023-09-22 15:25:08 --> Language Class Initialized
INFO - 2023-09-22 15:25:08 --> Config Class Initialized
INFO - 2023-09-22 15:25:08 --> Loader Class Initialized
INFO - 2023-09-22 15:25:08 --> Helper loaded: url_helper
INFO - 2023-09-22 15:25:08 --> Helper loaded: file_helper
INFO - 2023-09-22 15:25:08 --> Helper loaded: form_helper
INFO - 2023-09-22 15:25:08 --> Helper loaded: my_helper
INFO - 2023-09-22 15:25:08 --> Database Driver Class Initialized
INFO - 2023-09-22 15:25:08 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-22 15:25:08 --> Controller Class Initialized
DEBUG - 2023-09-22 15:25:08 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/home/views/v_home_guru.php
DEBUG - 2023-09-22 15:25:08 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-09-22 15:25:08 --> Final output sent to browser
DEBUG - 2023-09-22 15:25:08 --> Total execution time: 0.0457
INFO - 2023-09-22 15:25:11 --> Config Class Initialized
INFO - 2023-09-22 15:25:11 --> Hooks Class Initialized
DEBUG - 2023-09-22 15:25:11 --> UTF-8 Support Enabled
INFO - 2023-09-22 15:25:11 --> Utf8 Class Initialized
INFO - 2023-09-22 15:25:11 --> URI Class Initialized
INFO - 2023-09-22 15:25:11 --> Router Class Initialized
INFO - 2023-09-22 15:25:11 --> Output Class Initialized
INFO - 2023-09-22 15:25:11 --> Security Class Initialized
DEBUG - 2023-09-22 15:25:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-22 15:25:11 --> Input Class Initialized
INFO - 2023-09-22 15:25:11 --> Language Class Initialized
INFO - 2023-09-22 15:25:11 --> Language Class Initialized
INFO - 2023-09-22 15:25:11 --> Config Class Initialized
INFO - 2023-09-22 15:25:11 --> Loader Class Initialized
INFO - 2023-09-22 15:25:11 --> Helper loaded: url_helper
INFO - 2023-09-22 15:25:11 --> Helper loaded: file_helper
INFO - 2023-09-22 15:25:11 --> Helper loaded: form_helper
INFO - 2023-09-22 15:25:11 --> Helper loaded: my_helper
INFO - 2023-09-22 15:25:11 --> Database Driver Class Initialized
INFO - 2023-09-22 15:25:11 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-22 15:25:11 --> Controller Class Initialized
DEBUG - 2023-09-22 15:25:11 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/view_mapel/views/v_view_mapel.php
DEBUG - 2023-09-22 15:25:11 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-09-22 15:25:11 --> Final output sent to browser
DEBUG - 2023-09-22 15:25:11 --> Total execution time: 0.0367
INFO - 2023-09-22 15:25:18 --> Config Class Initialized
INFO - 2023-09-22 15:25:18 --> Hooks Class Initialized
DEBUG - 2023-09-22 15:25:18 --> UTF-8 Support Enabled
INFO - 2023-09-22 15:25:18 --> Utf8 Class Initialized
INFO - 2023-09-22 15:25:18 --> URI Class Initialized
INFO - 2023-09-22 15:25:18 --> Router Class Initialized
INFO - 2023-09-22 15:25:18 --> Output Class Initialized
INFO - 2023-09-22 15:25:18 --> Security Class Initialized
DEBUG - 2023-09-22 15:25:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-22 15:25:18 --> Input Class Initialized
INFO - 2023-09-22 15:25:18 --> Language Class Initialized
INFO - 2023-09-22 15:25:18 --> Language Class Initialized
INFO - 2023-09-22 15:25:18 --> Config Class Initialized
INFO - 2023-09-22 15:25:18 --> Loader Class Initialized
INFO - 2023-09-22 15:25:18 --> Helper loaded: url_helper
INFO - 2023-09-22 15:25:18 --> Helper loaded: file_helper
INFO - 2023-09-22 15:25:18 --> Helper loaded: form_helper
INFO - 2023-09-22 15:25:18 --> Helper loaded: my_helper
INFO - 2023-09-22 15:25:18 --> Database Driver Class Initialized
INFO - 2023-09-22 15:25:18 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-22 15:25:18 --> Controller Class Initialized
DEBUG - 2023-09-22 15:25:18 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_icb/views/list.php
DEBUG - 2023-09-22 15:25:18 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-09-22 15:25:18 --> Final output sent to browser
DEBUG - 2023-09-22 15:25:18 --> Total execution time: 0.0391
INFO - 2023-09-22 15:25:18 --> Config Class Initialized
INFO - 2023-09-22 15:25:18 --> Hooks Class Initialized
DEBUG - 2023-09-22 15:25:18 --> UTF-8 Support Enabled
INFO - 2023-09-22 15:25:18 --> Utf8 Class Initialized
INFO - 2023-09-22 15:25:18 --> URI Class Initialized
INFO - 2023-09-22 15:25:18 --> Router Class Initialized
INFO - 2023-09-22 15:25:18 --> Output Class Initialized
INFO - 2023-09-22 15:25:18 --> Security Class Initialized
DEBUG - 2023-09-22 15:25:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-22 15:25:18 --> Input Class Initialized
INFO - 2023-09-22 15:25:18 --> Language Class Initialized
INFO - 2023-09-22 15:25:18 --> Language Class Initialized
INFO - 2023-09-22 15:25:18 --> Config Class Initialized
INFO - 2023-09-22 15:25:18 --> Loader Class Initialized
INFO - 2023-09-22 15:25:18 --> Helper loaded: url_helper
INFO - 2023-09-22 15:25:18 --> Helper loaded: file_helper
INFO - 2023-09-22 15:25:18 --> Helper loaded: form_helper
INFO - 2023-09-22 15:25:18 --> Helper loaded: my_helper
INFO - 2023-09-22 15:25:18 --> Database Driver Class Initialized
INFO - 2023-09-22 15:25:18 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-22 15:25:18 --> Controller Class Initialized
INFO - 2023-09-22 15:25:20 --> Config Class Initialized
INFO - 2023-09-22 15:25:20 --> Hooks Class Initialized
DEBUG - 2023-09-22 15:25:20 --> UTF-8 Support Enabled
INFO - 2023-09-22 15:25:20 --> Utf8 Class Initialized
INFO - 2023-09-22 15:25:20 --> URI Class Initialized
INFO - 2023-09-22 15:25:20 --> Router Class Initialized
INFO - 2023-09-22 15:25:20 --> Output Class Initialized
INFO - 2023-09-22 15:25:20 --> Security Class Initialized
DEBUG - 2023-09-22 15:25:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-22 15:25:20 --> Input Class Initialized
INFO - 2023-09-22 15:25:20 --> Language Class Initialized
INFO - 2023-09-22 15:25:20 --> Language Class Initialized
INFO - 2023-09-22 15:25:20 --> Config Class Initialized
INFO - 2023-09-22 15:25:20 --> Loader Class Initialized
INFO - 2023-09-22 15:25:20 --> Helper loaded: url_helper
INFO - 2023-09-22 15:25:20 --> Helper loaded: file_helper
INFO - 2023-09-22 15:25:20 --> Helper loaded: form_helper
INFO - 2023-09-22 15:25:20 --> Helper loaded: my_helper
INFO - 2023-09-22 15:25:20 --> Database Driver Class Initialized
INFO - 2023-09-22 15:25:20 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-22 15:25:20 --> Controller Class Initialized
INFO - 2023-09-22 15:25:20 --> Final output sent to browser
DEBUG - 2023-09-22 15:25:20 --> Total execution time: 0.0506
INFO - 2023-09-22 15:25:23 --> Config Class Initialized
INFO - 2023-09-22 15:25:23 --> Hooks Class Initialized
DEBUG - 2023-09-22 15:25:23 --> UTF-8 Support Enabled
INFO - 2023-09-22 15:25:23 --> Utf8 Class Initialized
INFO - 2023-09-22 15:25:23 --> URI Class Initialized
INFO - 2023-09-22 15:25:23 --> Router Class Initialized
INFO - 2023-09-22 15:25:23 --> Output Class Initialized
INFO - 2023-09-22 15:25:23 --> Security Class Initialized
DEBUG - 2023-09-22 15:25:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-22 15:25:23 --> Input Class Initialized
INFO - 2023-09-22 15:25:23 --> Language Class Initialized
INFO - 2023-09-22 15:25:23 --> Language Class Initialized
INFO - 2023-09-22 15:25:23 --> Config Class Initialized
INFO - 2023-09-22 15:25:23 --> Loader Class Initialized
INFO - 2023-09-22 15:25:23 --> Helper loaded: url_helper
INFO - 2023-09-22 15:25:23 --> Helper loaded: file_helper
INFO - 2023-09-22 15:25:23 --> Helper loaded: form_helper
INFO - 2023-09-22 15:25:23 --> Helper loaded: my_helper
INFO - 2023-09-22 15:25:23 --> Database Driver Class Initialized
INFO - 2023-09-22 15:25:23 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-22 15:25:23 --> Controller Class Initialized
DEBUG - 2023-09-22 15:25:23 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/view_mapel/views/v_view_mapel.php
DEBUG - 2023-09-22 15:25:23 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-09-22 15:25:23 --> Final output sent to browser
DEBUG - 2023-09-22 15:25:23 --> Total execution time: 0.0360
INFO - 2023-09-22 15:25:28 --> Config Class Initialized
INFO - 2023-09-22 15:25:28 --> Hooks Class Initialized
DEBUG - 2023-09-22 15:25:28 --> UTF-8 Support Enabled
INFO - 2023-09-22 15:25:28 --> Utf8 Class Initialized
INFO - 2023-09-22 15:25:28 --> URI Class Initialized
INFO - 2023-09-22 15:25:28 --> Router Class Initialized
INFO - 2023-09-22 15:25:28 --> Output Class Initialized
INFO - 2023-09-22 15:25:28 --> Security Class Initialized
DEBUG - 2023-09-22 15:25:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-22 15:25:28 --> Input Class Initialized
INFO - 2023-09-22 15:25:28 --> Language Class Initialized
INFO - 2023-09-22 15:25:28 --> Language Class Initialized
INFO - 2023-09-22 15:25:28 --> Config Class Initialized
INFO - 2023-09-22 15:25:28 --> Loader Class Initialized
INFO - 2023-09-22 15:25:28 --> Helper loaded: url_helper
INFO - 2023-09-22 15:25:28 --> Helper loaded: file_helper
INFO - 2023-09-22 15:25:28 --> Helper loaded: form_helper
INFO - 2023-09-22 15:25:28 --> Helper loaded: my_helper
INFO - 2023-09-22 15:25:28 --> Database Driver Class Initialized
INFO - 2023-09-22 15:25:28 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-22 15:25:28 --> Controller Class Initialized
DEBUG - 2023-09-22 15:25:28 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/view_mapel/views/v_view_mapel.php
DEBUG - 2023-09-22 15:25:28 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-09-22 15:25:28 --> Final output sent to browser
DEBUG - 2023-09-22 15:25:28 --> Total execution time: 0.0435
INFO - 2023-09-22 15:25:28 --> Config Class Initialized
INFO - 2023-09-22 15:25:28 --> Hooks Class Initialized
DEBUG - 2023-09-22 15:25:28 --> UTF-8 Support Enabled
INFO - 2023-09-22 15:25:28 --> Utf8 Class Initialized
INFO - 2023-09-22 15:25:28 --> URI Class Initialized
DEBUG - 2023-09-22 15:25:28 --> No URI present. Default controller set.
INFO - 2023-09-22 15:25:28 --> Router Class Initialized
INFO - 2023-09-22 15:25:28 --> Output Class Initialized
INFO - 2023-09-22 15:25:28 --> Security Class Initialized
DEBUG - 2023-09-22 15:25:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-22 15:25:28 --> Input Class Initialized
INFO - 2023-09-22 15:25:28 --> Language Class Initialized
INFO - 2023-09-22 15:25:28 --> Language Class Initialized
INFO - 2023-09-22 15:25:28 --> Config Class Initialized
INFO - 2023-09-22 15:25:28 --> Loader Class Initialized
INFO - 2023-09-22 15:25:28 --> Helper loaded: url_helper
INFO - 2023-09-22 15:25:28 --> Helper loaded: file_helper
INFO - 2023-09-22 15:25:28 --> Helper loaded: form_helper
INFO - 2023-09-22 15:25:28 --> Helper loaded: my_helper
INFO - 2023-09-22 15:25:28 --> Database Driver Class Initialized
INFO - 2023-09-22 15:25:28 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-22 15:25:28 --> Controller Class Initialized
DEBUG - 2023-09-22 15:25:28 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/home/views/v_home_guru.php
DEBUG - 2023-09-22 15:25:28 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-09-22 15:25:28 --> Final output sent to browser
DEBUG - 2023-09-22 15:25:28 --> Total execution time: 0.0428
INFO - 2023-09-22 15:25:29 --> Config Class Initialized
INFO - 2023-09-22 15:25:29 --> Hooks Class Initialized
DEBUG - 2023-09-22 15:25:29 --> UTF-8 Support Enabled
INFO - 2023-09-22 15:25:29 --> Utf8 Class Initialized
INFO - 2023-09-22 15:25:29 --> URI Class Initialized
DEBUG - 2023-09-22 15:25:29 --> No URI present. Default controller set.
INFO - 2023-09-22 15:25:29 --> Router Class Initialized
INFO - 2023-09-22 15:25:29 --> Output Class Initialized
INFO - 2023-09-22 15:25:29 --> Security Class Initialized
DEBUG - 2023-09-22 15:25:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-22 15:25:29 --> Input Class Initialized
INFO - 2023-09-22 15:25:29 --> Language Class Initialized
INFO - 2023-09-22 15:25:29 --> Language Class Initialized
INFO - 2023-09-22 15:25:29 --> Config Class Initialized
INFO - 2023-09-22 15:25:29 --> Loader Class Initialized
INFO - 2023-09-22 15:25:29 --> Helper loaded: url_helper
INFO - 2023-09-22 15:25:29 --> Helper loaded: file_helper
INFO - 2023-09-22 15:25:29 --> Helper loaded: form_helper
INFO - 2023-09-22 15:25:29 --> Helper loaded: my_helper
INFO - 2023-09-22 15:25:29 --> Database Driver Class Initialized
INFO - 2023-09-22 15:25:29 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-22 15:25:29 --> Controller Class Initialized
DEBUG - 2023-09-22 15:25:29 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/home/views/v_home_guru.php
DEBUG - 2023-09-22 15:25:29 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-09-22 15:25:29 --> Final output sent to browser
DEBUG - 2023-09-22 15:25:29 --> Total execution time: 0.0404
INFO - 2023-09-22 15:25:30 --> Config Class Initialized
INFO - 2023-09-22 15:25:30 --> Hooks Class Initialized
DEBUG - 2023-09-22 15:25:30 --> UTF-8 Support Enabled
INFO - 2023-09-22 15:25:30 --> Utf8 Class Initialized
INFO - 2023-09-22 15:25:30 --> URI Class Initialized
INFO - 2023-09-22 15:25:30 --> Router Class Initialized
INFO - 2023-09-22 15:25:30 --> Output Class Initialized
INFO - 2023-09-22 15:25:30 --> Security Class Initialized
DEBUG - 2023-09-22 15:25:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-22 15:25:30 --> Input Class Initialized
INFO - 2023-09-22 15:25:30 --> Language Class Initialized
INFO - 2023-09-22 15:25:30 --> Language Class Initialized
INFO - 2023-09-22 15:25:30 --> Config Class Initialized
INFO - 2023-09-22 15:25:30 --> Loader Class Initialized
INFO - 2023-09-22 15:25:30 --> Helper loaded: url_helper
INFO - 2023-09-22 15:25:30 --> Helper loaded: file_helper
INFO - 2023-09-22 15:25:30 --> Helper loaded: form_helper
INFO - 2023-09-22 15:25:30 --> Helper loaded: my_helper
INFO - 2023-09-22 15:25:30 --> Database Driver Class Initialized
INFO - 2023-09-22 15:25:30 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-22 15:25:30 --> Controller Class Initialized
DEBUG - 2023-09-22 15:25:30 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/view_mapel/views/v_view_mapel.php
DEBUG - 2023-09-22 15:25:30 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-09-22 15:25:30 --> Final output sent to browser
DEBUG - 2023-09-22 15:25:30 --> Total execution time: 0.0588
INFO - 2023-09-22 15:25:30 --> Config Class Initialized
INFO - 2023-09-22 15:25:30 --> Hooks Class Initialized
DEBUG - 2023-09-22 15:25:30 --> UTF-8 Support Enabled
INFO - 2023-09-22 15:25:30 --> Utf8 Class Initialized
INFO - 2023-09-22 15:25:30 --> URI Class Initialized
INFO - 2023-09-22 15:25:30 --> Router Class Initialized
INFO - 2023-09-22 15:25:30 --> Output Class Initialized
INFO - 2023-09-22 15:25:30 --> Security Class Initialized
DEBUG - 2023-09-22 15:25:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-22 15:25:30 --> Input Class Initialized
INFO - 2023-09-22 15:25:30 --> Language Class Initialized
INFO - 2023-09-22 15:25:30 --> Language Class Initialized
INFO - 2023-09-22 15:25:30 --> Config Class Initialized
INFO - 2023-09-22 15:25:30 --> Loader Class Initialized
INFO - 2023-09-22 15:25:30 --> Helper loaded: url_helper
INFO - 2023-09-22 15:25:30 --> Helper loaded: file_helper
INFO - 2023-09-22 15:25:30 --> Helper loaded: form_helper
INFO - 2023-09-22 15:25:30 --> Helper loaded: my_helper
INFO - 2023-09-22 15:25:30 --> Database Driver Class Initialized
INFO - 2023-09-22 15:25:30 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-22 15:25:30 --> Controller Class Initialized
DEBUG - 2023-09-22 15:25:30 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/view_mapel/views/v_view_mapel.php
DEBUG - 2023-09-22 15:25:30 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-09-22 15:25:30 --> Final output sent to browser
DEBUG - 2023-09-22 15:25:30 --> Total execution time: 0.0640
INFO - 2023-09-22 15:25:35 --> Config Class Initialized
INFO - 2023-09-22 15:25:35 --> Hooks Class Initialized
DEBUG - 2023-09-22 15:25:35 --> UTF-8 Support Enabled
INFO - 2023-09-22 15:25:35 --> Utf8 Class Initialized
INFO - 2023-09-22 15:25:35 --> URI Class Initialized
INFO - 2023-09-22 15:25:35 --> Router Class Initialized
INFO - 2023-09-22 15:25:35 --> Output Class Initialized
INFO - 2023-09-22 15:25:35 --> Security Class Initialized
DEBUG - 2023-09-22 15:25:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-22 15:25:35 --> Input Class Initialized
INFO - 2023-09-22 15:25:35 --> Language Class Initialized
INFO - 2023-09-22 15:25:35 --> Language Class Initialized
INFO - 2023-09-22 15:25:35 --> Config Class Initialized
INFO - 2023-09-22 15:25:35 --> Loader Class Initialized
INFO - 2023-09-22 15:25:35 --> Helper loaded: url_helper
INFO - 2023-09-22 15:25:35 --> Helper loaded: file_helper
INFO - 2023-09-22 15:25:35 --> Helper loaded: form_helper
INFO - 2023-09-22 15:25:35 --> Helper loaded: my_helper
INFO - 2023-09-22 15:25:35 --> Database Driver Class Initialized
INFO - 2023-09-22 15:25:35 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-22 15:25:35 --> Controller Class Initialized
DEBUG - 2023-09-22 15:25:35 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_icb/views/list.php
DEBUG - 2023-09-22 15:25:35 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-09-22 15:25:35 --> Final output sent to browser
DEBUG - 2023-09-22 15:25:35 --> Total execution time: 0.0596
INFO - 2023-09-22 15:25:35 --> Config Class Initialized
INFO - 2023-09-22 15:25:35 --> Hooks Class Initialized
DEBUG - 2023-09-22 15:25:35 --> UTF-8 Support Enabled
INFO - 2023-09-22 15:25:35 --> Utf8 Class Initialized
INFO - 2023-09-22 15:25:35 --> URI Class Initialized
INFO - 2023-09-22 15:25:35 --> Router Class Initialized
INFO - 2023-09-22 15:25:35 --> Output Class Initialized
INFO - 2023-09-22 15:25:35 --> Security Class Initialized
DEBUG - 2023-09-22 15:25:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-22 15:25:35 --> Input Class Initialized
INFO - 2023-09-22 15:25:35 --> Language Class Initialized
INFO - 2023-09-22 15:25:35 --> Language Class Initialized
INFO - 2023-09-22 15:25:35 --> Config Class Initialized
INFO - 2023-09-22 15:25:35 --> Loader Class Initialized
INFO - 2023-09-22 15:25:35 --> Helper loaded: url_helper
INFO - 2023-09-22 15:25:35 --> Helper loaded: file_helper
INFO - 2023-09-22 15:25:35 --> Helper loaded: form_helper
INFO - 2023-09-22 15:25:35 --> Helper loaded: my_helper
INFO - 2023-09-22 15:25:35 --> Database Driver Class Initialized
INFO - 2023-09-22 15:25:35 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-22 15:25:35 --> Controller Class Initialized
INFO - 2023-09-22 15:25:39 --> Config Class Initialized
INFO - 2023-09-22 15:25:39 --> Hooks Class Initialized
DEBUG - 2023-09-22 15:25:39 --> UTF-8 Support Enabled
INFO - 2023-09-22 15:25:39 --> Utf8 Class Initialized
INFO - 2023-09-22 15:25:39 --> URI Class Initialized
INFO - 2023-09-22 15:25:39 --> Router Class Initialized
INFO - 2023-09-22 15:25:39 --> Output Class Initialized
INFO - 2023-09-22 15:25:39 --> Security Class Initialized
DEBUG - 2023-09-22 15:25:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-22 15:25:39 --> Input Class Initialized
INFO - 2023-09-22 15:25:39 --> Language Class Initialized
INFO - 2023-09-22 15:25:39 --> Language Class Initialized
INFO - 2023-09-22 15:25:39 --> Config Class Initialized
INFO - 2023-09-22 15:25:39 --> Loader Class Initialized
INFO - 2023-09-22 15:25:39 --> Helper loaded: url_helper
INFO - 2023-09-22 15:25:39 --> Helper loaded: file_helper
INFO - 2023-09-22 15:25:39 --> Helper loaded: form_helper
INFO - 2023-09-22 15:25:39 --> Helper loaded: my_helper
INFO - 2023-09-22 15:25:39 --> Database Driver Class Initialized
INFO - 2023-09-22 15:25:39 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-22 15:25:39 --> Controller Class Initialized
DEBUG - 2023-09-22 15:25:39 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_icb/views/list.php
DEBUG - 2023-09-22 15:25:39 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-09-22 15:25:39 --> Final output sent to browser
DEBUG - 2023-09-22 15:25:39 --> Total execution time: 0.0478
INFO - 2023-09-22 15:25:39 --> Config Class Initialized
INFO - 2023-09-22 15:25:39 --> Hooks Class Initialized
DEBUG - 2023-09-22 15:25:39 --> UTF-8 Support Enabled
INFO - 2023-09-22 15:25:39 --> Utf8 Class Initialized
INFO - 2023-09-22 15:25:39 --> URI Class Initialized
INFO - 2023-09-22 15:25:39 --> Router Class Initialized
INFO - 2023-09-22 15:25:39 --> Output Class Initialized
INFO - 2023-09-22 15:25:39 --> Security Class Initialized
DEBUG - 2023-09-22 15:25:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-22 15:25:39 --> Input Class Initialized
INFO - 2023-09-22 15:25:39 --> Language Class Initialized
INFO - 2023-09-22 15:25:39 --> Language Class Initialized
INFO - 2023-09-22 15:25:39 --> Config Class Initialized
INFO - 2023-09-22 15:25:39 --> Loader Class Initialized
INFO - 2023-09-22 15:25:39 --> Helper loaded: url_helper
INFO - 2023-09-22 15:25:39 --> Helper loaded: file_helper
INFO - 2023-09-22 15:25:39 --> Helper loaded: form_helper
INFO - 2023-09-22 15:25:39 --> Helper loaded: my_helper
INFO - 2023-09-22 15:25:39 --> Database Driver Class Initialized
INFO - 2023-09-22 15:25:39 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-22 15:25:39 --> Controller Class Initialized
INFO - 2023-09-22 15:25:42 --> Config Class Initialized
INFO - 2023-09-22 15:25:42 --> Hooks Class Initialized
DEBUG - 2023-09-22 15:25:42 --> UTF-8 Support Enabled
INFO - 2023-09-22 15:25:42 --> Utf8 Class Initialized
INFO - 2023-09-22 15:25:42 --> URI Class Initialized
INFO - 2023-09-22 15:25:42 --> Router Class Initialized
INFO - 2023-09-22 15:25:42 --> Output Class Initialized
INFO - 2023-09-22 15:25:42 --> Security Class Initialized
DEBUG - 2023-09-22 15:25:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-22 15:25:42 --> Input Class Initialized
INFO - 2023-09-22 15:25:42 --> Language Class Initialized
INFO - 2023-09-22 15:25:42 --> Language Class Initialized
INFO - 2023-09-22 15:25:42 --> Config Class Initialized
INFO - 2023-09-22 15:25:42 --> Loader Class Initialized
INFO - 2023-09-22 15:25:42 --> Helper loaded: url_helper
INFO - 2023-09-22 15:25:42 --> Helper loaded: file_helper
INFO - 2023-09-22 15:25:42 --> Helper loaded: form_helper
INFO - 2023-09-22 15:25:42 --> Helper loaded: my_helper
INFO - 2023-09-22 15:25:42 --> Database Driver Class Initialized
INFO - 2023-09-22 15:25:42 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-22 15:25:42 --> Controller Class Initialized
INFO - 2023-09-22 15:25:42 --> Final output sent to browser
DEBUG - 2023-09-22 15:25:42 --> Total execution time: 0.0365
INFO - 2023-09-22 15:26:19 --> Config Class Initialized
INFO - 2023-09-22 15:26:19 --> Hooks Class Initialized
DEBUG - 2023-09-22 15:26:19 --> UTF-8 Support Enabled
INFO - 2023-09-22 15:26:19 --> Utf8 Class Initialized
INFO - 2023-09-22 15:26:19 --> URI Class Initialized
INFO - 2023-09-22 15:26:19 --> Router Class Initialized
INFO - 2023-09-22 15:26:19 --> Output Class Initialized
INFO - 2023-09-22 15:26:19 --> Security Class Initialized
DEBUG - 2023-09-22 15:26:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-22 15:26:19 --> Input Class Initialized
INFO - 2023-09-22 15:26:19 --> Language Class Initialized
INFO - 2023-09-22 15:26:19 --> Language Class Initialized
INFO - 2023-09-22 15:26:19 --> Config Class Initialized
INFO - 2023-09-22 15:26:19 --> Loader Class Initialized
INFO - 2023-09-22 15:26:19 --> Helper loaded: url_helper
INFO - 2023-09-22 15:26:19 --> Helper loaded: file_helper
INFO - 2023-09-22 15:26:19 --> Helper loaded: form_helper
INFO - 2023-09-22 15:26:19 --> Helper loaded: my_helper
INFO - 2023-09-22 15:26:19 --> Database Driver Class Initialized
INFO - 2023-09-22 15:26:19 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-22 15:26:19 --> Controller Class Initialized
INFO - 2023-09-22 15:26:19 --> Final output sent to browser
DEBUG - 2023-09-22 15:26:19 --> Total execution time: 0.0683
INFO - 2023-09-22 15:26:22 --> Config Class Initialized
INFO - 2023-09-22 15:26:22 --> Hooks Class Initialized
DEBUG - 2023-09-22 15:26:22 --> UTF-8 Support Enabled
INFO - 2023-09-22 15:26:22 --> Utf8 Class Initialized
INFO - 2023-09-22 15:26:22 --> URI Class Initialized
INFO - 2023-09-22 15:26:22 --> Router Class Initialized
INFO - 2023-09-22 15:26:22 --> Output Class Initialized
INFO - 2023-09-22 15:26:22 --> Security Class Initialized
DEBUG - 2023-09-22 15:26:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-22 15:26:22 --> Input Class Initialized
INFO - 2023-09-22 15:26:22 --> Language Class Initialized
INFO - 2023-09-22 15:26:22 --> Language Class Initialized
INFO - 2023-09-22 15:26:22 --> Config Class Initialized
INFO - 2023-09-22 15:26:22 --> Loader Class Initialized
INFO - 2023-09-22 15:26:22 --> Helper loaded: url_helper
INFO - 2023-09-22 15:26:22 --> Helper loaded: file_helper
INFO - 2023-09-22 15:26:22 --> Helper loaded: form_helper
INFO - 2023-09-22 15:26:22 --> Helper loaded: my_helper
INFO - 2023-09-22 15:26:22 --> Database Driver Class Initialized
INFO - 2023-09-22 15:26:22 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-22 15:26:22 --> Controller Class Initialized
DEBUG - 2023-09-22 15:26:22 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/list.php
DEBUG - 2023-09-22 15:26:22 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-09-22 15:26:22 --> Final output sent to browser
DEBUG - 2023-09-22 15:26:22 --> Total execution time: 0.0537
INFO - 2023-09-22 15:26:24 --> Config Class Initialized
INFO - 2023-09-22 15:26:24 --> Hooks Class Initialized
DEBUG - 2023-09-22 15:26:24 --> UTF-8 Support Enabled
INFO - 2023-09-22 15:26:24 --> Utf8 Class Initialized
INFO - 2023-09-22 15:26:24 --> URI Class Initialized
INFO - 2023-09-22 15:26:24 --> Router Class Initialized
INFO - 2023-09-22 15:26:24 --> Output Class Initialized
INFO - 2023-09-22 15:26:24 --> Security Class Initialized
DEBUG - 2023-09-22 15:26:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-22 15:26:24 --> Input Class Initialized
INFO - 2023-09-22 15:26:24 --> Language Class Initialized
INFO - 2023-09-22 15:26:24 --> Language Class Initialized
INFO - 2023-09-22 15:26:24 --> Config Class Initialized
INFO - 2023-09-22 15:26:24 --> Loader Class Initialized
INFO - 2023-09-22 15:26:24 --> Helper loaded: url_helper
INFO - 2023-09-22 15:26:24 --> Helper loaded: file_helper
INFO - 2023-09-22 15:26:24 --> Helper loaded: form_helper
INFO - 2023-09-22 15:26:24 --> Helper loaded: my_helper
INFO - 2023-09-22 15:26:24 --> Database Driver Class Initialized
INFO - 2023-09-22 15:26:24 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-22 15:26:24 --> Controller Class Initialized
ERROR - 2023-09-22 15:26:24 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php 110
DEBUG - 2023-09-22 15:26:24 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php
ERROR - 2023-09-22 15:26:24 --> Severity: error --> Exception: Unable to get the size of the image [C:\Users\sallu\Downloads\Logo MH Transparan-01.png] /www/wwwroot/report.mhis.link/bangka/secondary/aset/html2pdf/spipu/html2pdf/src/Html2Pdf.php 1513
INFO - 2023-09-22 15:26:33 --> Config Class Initialized
INFO - 2023-09-22 15:26:33 --> Hooks Class Initialized
DEBUG - 2023-09-22 15:26:33 --> UTF-8 Support Enabled
INFO - 2023-09-22 15:26:33 --> Utf8 Class Initialized
INFO - 2023-09-22 15:26:33 --> URI Class Initialized
INFO - 2023-09-22 15:26:33 --> Router Class Initialized
INFO - 2023-09-22 15:26:33 --> Output Class Initialized
INFO - 2023-09-22 15:26:33 --> Security Class Initialized
DEBUG - 2023-09-22 15:26:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-22 15:26:33 --> Input Class Initialized
INFO - 2023-09-22 15:26:33 --> Language Class Initialized
INFO - 2023-09-22 15:26:33 --> Language Class Initialized
INFO - 2023-09-22 15:26:33 --> Config Class Initialized
INFO - 2023-09-22 15:26:33 --> Loader Class Initialized
INFO - 2023-09-22 15:26:33 --> Helper loaded: url_helper
INFO - 2023-09-22 15:26:33 --> Helper loaded: file_helper
INFO - 2023-09-22 15:26:33 --> Helper loaded: form_helper
INFO - 2023-09-22 15:26:33 --> Helper loaded: my_helper
INFO - 2023-09-22 15:26:33 --> Database Driver Class Initialized
INFO - 2023-09-22 15:26:33 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-22 15:26:33 --> Controller Class Initialized
DEBUG - 2023-09-22 15:26:33 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/view_mapel/views/v_view_mapel.php
DEBUG - 2023-09-22 15:26:33 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-09-22 15:26:33 --> Final output sent to browser
DEBUG - 2023-09-22 15:26:33 --> Total execution time: 0.0380
INFO - 2023-09-22 15:26:36 --> Config Class Initialized
INFO - 2023-09-22 15:26:36 --> Hooks Class Initialized
DEBUG - 2023-09-22 15:26:36 --> UTF-8 Support Enabled
INFO - 2023-09-22 15:26:36 --> Utf8 Class Initialized
INFO - 2023-09-22 15:26:36 --> URI Class Initialized
INFO - 2023-09-22 15:26:36 --> Router Class Initialized
INFO - 2023-09-22 15:26:36 --> Output Class Initialized
INFO - 2023-09-22 15:26:36 --> Security Class Initialized
DEBUG - 2023-09-22 15:26:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-22 15:26:36 --> Input Class Initialized
INFO - 2023-09-22 15:26:36 --> Language Class Initialized
INFO - 2023-09-22 15:26:36 --> Language Class Initialized
INFO - 2023-09-22 15:26:36 --> Config Class Initialized
INFO - 2023-09-22 15:26:36 --> Loader Class Initialized
INFO - 2023-09-22 15:26:36 --> Helper loaded: url_helper
INFO - 2023-09-22 15:26:36 --> Helper loaded: file_helper
INFO - 2023-09-22 15:26:36 --> Helper loaded: form_helper
INFO - 2023-09-22 15:26:36 --> Helper loaded: my_helper
INFO - 2023-09-22 15:26:36 --> Database Driver Class Initialized
INFO - 2023-09-22 15:26:36 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-22 15:26:36 --> Controller Class Initialized
DEBUG - 2023-09-22 15:26:36 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_icb/views/list.php
DEBUG - 2023-09-22 15:26:36 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-09-22 15:26:36 --> Final output sent to browser
DEBUG - 2023-09-22 15:26:36 --> Total execution time: 0.0364
INFO - 2023-09-22 15:26:36 --> Config Class Initialized
INFO - 2023-09-22 15:26:36 --> Hooks Class Initialized
DEBUG - 2023-09-22 15:26:36 --> UTF-8 Support Enabled
INFO - 2023-09-22 15:26:36 --> Utf8 Class Initialized
INFO - 2023-09-22 15:26:36 --> URI Class Initialized
INFO - 2023-09-22 15:26:36 --> Router Class Initialized
INFO - 2023-09-22 15:26:36 --> Output Class Initialized
INFO - 2023-09-22 15:26:36 --> Security Class Initialized
DEBUG - 2023-09-22 15:26:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-22 15:26:36 --> Input Class Initialized
INFO - 2023-09-22 15:26:36 --> Language Class Initialized
INFO - 2023-09-22 15:26:36 --> Language Class Initialized
INFO - 2023-09-22 15:26:36 --> Config Class Initialized
INFO - 2023-09-22 15:26:36 --> Loader Class Initialized
INFO - 2023-09-22 15:26:36 --> Helper loaded: url_helper
INFO - 2023-09-22 15:26:36 --> Helper loaded: file_helper
INFO - 2023-09-22 15:26:36 --> Helper loaded: form_helper
INFO - 2023-09-22 15:26:36 --> Helper loaded: my_helper
INFO - 2023-09-22 15:26:36 --> Database Driver Class Initialized
INFO - 2023-09-22 15:26:36 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-22 15:26:36 --> Controller Class Initialized
INFO - 2023-09-22 15:26:38 --> Config Class Initialized
INFO - 2023-09-22 15:26:38 --> Hooks Class Initialized
DEBUG - 2023-09-22 15:26:39 --> UTF-8 Support Enabled
INFO - 2023-09-22 15:26:39 --> Utf8 Class Initialized
INFO - 2023-09-22 15:26:39 --> URI Class Initialized
INFO - 2023-09-22 15:26:39 --> Router Class Initialized
INFO - 2023-09-22 15:26:39 --> Output Class Initialized
INFO - 2023-09-22 15:26:39 --> Security Class Initialized
DEBUG - 2023-09-22 15:26:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-22 15:26:39 --> Input Class Initialized
INFO - 2023-09-22 15:26:39 --> Language Class Initialized
INFO - 2023-09-22 15:26:39 --> Language Class Initialized
INFO - 2023-09-22 15:26:39 --> Config Class Initialized
INFO - 2023-09-22 15:26:39 --> Loader Class Initialized
INFO - 2023-09-22 15:26:39 --> Helper loaded: url_helper
INFO - 2023-09-22 15:26:39 --> Helper loaded: file_helper
INFO - 2023-09-22 15:26:39 --> Helper loaded: form_helper
INFO - 2023-09-22 15:26:39 --> Helper loaded: my_helper
INFO - 2023-09-22 15:26:39 --> Database Driver Class Initialized
INFO - 2023-09-22 15:26:39 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-22 15:26:39 --> Controller Class Initialized
DEBUG - 2023-09-22 15:26:39 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/view_mapel/views/v_view_mapel.php
DEBUG - 2023-09-22 15:26:39 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-09-22 15:26:39 --> Final output sent to browser
DEBUG - 2023-09-22 15:26:39 --> Total execution time: 0.0404
INFO - 2023-09-22 15:26:40 --> Config Class Initialized
INFO - 2023-09-22 15:26:40 --> Hooks Class Initialized
DEBUG - 2023-09-22 15:26:40 --> UTF-8 Support Enabled
INFO - 2023-09-22 15:26:40 --> Utf8 Class Initialized
INFO - 2023-09-22 15:26:40 --> URI Class Initialized
INFO - 2023-09-22 15:26:40 --> Router Class Initialized
INFO - 2023-09-22 15:26:40 --> Output Class Initialized
INFO - 2023-09-22 15:26:40 --> Security Class Initialized
DEBUG - 2023-09-22 15:26:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-22 15:26:40 --> Input Class Initialized
INFO - 2023-09-22 15:26:40 --> Language Class Initialized
INFO - 2023-09-22 15:26:40 --> Language Class Initialized
INFO - 2023-09-22 15:26:40 --> Config Class Initialized
INFO - 2023-09-22 15:26:40 --> Loader Class Initialized
INFO - 2023-09-22 15:26:40 --> Helper loaded: url_helper
INFO - 2023-09-22 15:26:40 --> Helper loaded: file_helper
INFO - 2023-09-22 15:26:40 --> Helper loaded: form_helper
INFO - 2023-09-22 15:26:40 --> Helper loaded: my_helper
INFO - 2023-09-22 15:26:40 --> Database Driver Class Initialized
INFO - 2023-09-22 15:26:40 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-22 15:26:40 --> Controller Class Initialized
DEBUG - 2023-09-22 15:26:40 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_la/views/list.php
DEBUG - 2023-09-22 15:26:40 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-09-22 15:26:40 --> Final output sent to browser
DEBUG - 2023-09-22 15:26:40 --> Total execution time: 0.0368
INFO - 2023-09-22 15:26:40 --> Config Class Initialized
INFO - 2023-09-22 15:26:40 --> Hooks Class Initialized
DEBUG - 2023-09-22 15:26:40 --> UTF-8 Support Enabled
INFO - 2023-09-22 15:26:40 --> Utf8 Class Initialized
INFO - 2023-09-22 15:26:40 --> URI Class Initialized
INFO - 2023-09-22 15:26:40 --> Router Class Initialized
INFO - 2023-09-22 15:26:40 --> Output Class Initialized
INFO - 2023-09-22 15:26:40 --> Security Class Initialized
DEBUG - 2023-09-22 15:26:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-22 15:26:40 --> Input Class Initialized
INFO - 2023-09-22 15:26:40 --> Language Class Initialized
INFO - 2023-09-22 15:26:40 --> Language Class Initialized
INFO - 2023-09-22 15:26:40 --> Config Class Initialized
INFO - 2023-09-22 15:26:40 --> Loader Class Initialized
INFO - 2023-09-22 15:26:40 --> Helper loaded: url_helper
INFO - 2023-09-22 15:26:40 --> Helper loaded: file_helper
INFO - 2023-09-22 15:26:40 --> Helper loaded: form_helper
INFO - 2023-09-22 15:26:40 --> Helper loaded: my_helper
INFO - 2023-09-22 15:26:40 --> Database Driver Class Initialized
INFO - 2023-09-22 15:26:40 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-22 15:26:40 --> Controller Class Initialized
INFO - 2023-09-22 15:26:44 --> Config Class Initialized
INFO - 2023-09-22 15:26:44 --> Hooks Class Initialized
DEBUG - 2023-09-22 15:26:44 --> UTF-8 Support Enabled
INFO - 2023-09-22 15:26:44 --> Utf8 Class Initialized
INFO - 2023-09-22 15:26:44 --> URI Class Initialized
INFO - 2023-09-22 15:26:45 --> Router Class Initialized
INFO - 2023-09-22 15:26:45 --> Output Class Initialized
INFO - 2023-09-22 15:26:45 --> Security Class Initialized
DEBUG - 2023-09-22 15:26:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-22 15:26:45 --> Input Class Initialized
INFO - 2023-09-22 15:26:45 --> Language Class Initialized
INFO - 2023-09-22 15:26:45 --> Language Class Initialized
INFO - 2023-09-22 15:26:45 --> Config Class Initialized
INFO - 2023-09-22 15:26:45 --> Loader Class Initialized
INFO - 2023-09-22 15:26:45 --> Helper loaded: url_helper
INFO - 2023-09-22 15:26:45 --> Helper loaded: file_helper
INFO - 2023-09-22 15:26:45 --> Helper loaded: form_helper
INFO - 2023-09-22 15:26:45 --> Helper loaded: my_helper
INFO - 2023-09-22 15:26:45 --> Database Driver Class Initialized
INFO - 2023-09-22 15:26:45 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-22 15:26:45 --> Controller Class Initialized
DEBUG - 2023-09-22 15:26:45 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/view_mapel/views/v_view_mapel.php
DEBUG - 2023-09-22 15:26:45 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-09-22 15:26:45 --> Final output sent to browser
DEBUG - 2023-09-22 15:26:45 --> Total execution time: 0.1018
INFO - 2023-09-22 15:26:46 --> Config Class Initialized
INFO - 2023-09-22 15:26:46 --> Hooks Class Initialized
DEBUG - 2023-09-22 15:26:46 --> UTF-8 Support Enabled
INFO - 2023-09-22 15:26:46 --> Utf8 Class Initialized
INFO - 2023-09-22 15:26:46 --> URI Class Initialized
INFO - 2023-09-22 15:26:46 --> Router Class Initialized
INFO - 2023-09-22 15:26:46 --> Output Class Initialized
INFO - 2023-09-22 15:26:46 --> Security Class Initialized
DEBUG - 2023-09-22 15:26:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-22 15:26:46 --> Input Class Initialized
INFO - 2023-09-22 15:26:46 --> Language Class Initialized
INFO - 2023-09-22 15:26:46 --> Language Class Initialized
INFO - 2023-09-22 15:26:46 --> Config Class Initialized
INFO - 2023-09-22 15:26:46 --> Loader Class Initialized
INFO - 2023-09-22 15:26:46 --> Helper loaded: url_helper
INFO - 2023-09-22 15:26:46 --> Helper loaded: file_helper
INFO - 2023-09-22 15:26:46 --> Helper loaded: form_helper
INFO - 2023-09-22 15:26:46 --> Helper loaded: my_helper
INFO - 2023-09-22 15:26:46 --> Database Driver Class Initialized
INFO - 2023-09-22 15:26:46 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-22 15:26:46 --> Controller Class Initialized
DEBUG - 2023-09-22 15:26:46 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pss/views/list.php
DEBUG - 2023-09-22 15:26:46 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-09-22 15:26:46 --> Final output sent to browser
DEBUG - 2023-09-22 15:26:46 --> Total execution time: 0.0887
INFO - 2023-09-22 15:26:46 --> Config Class Initialized
INFO - 2023-09-22 15:26:46 --> Hooks Class Initialized
DEBUG - 2023-09-22 15:26:46 --> UTF-8 Support Enabled
INFO - 2023-09-22 15:26:46 --> Utf8 Class Initialized
INFO - 2023-09-22 15:26:46 --> URI Class Initialized
INFO - 2023-09-22 15:26:46 --> Router Class Initialized
INFO - 2023-09-22 15:26:46 --> Output Class Initialized
INFO - 2023-09-22 15:26:46 --> Security Class Initialized
DEBUG - 2023-09-22 15:26:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-22 15:26:46 --> Input Class Initialized
INFO - 2023-09-22 15:26:46 --> Language Class Initialized
INFO - 2023-09-22 15:26:46 --> Language Class Initialized
INFO - 2023-09-22 15:26:46 --> Config Class Initialized
INFO - 2023-09-22 15:26:46 --> Loader Class Initialized
INFO - 2023-09-22 15:26:46 --> Helper loaded: url_helper
INFO - 2023-09-22 15:26:46 --> Helper loaded: file_helper
INFO - 2023-09-22 15:26:46 --> Helper loaded: form_helper
INFO - 2023-09-22 15:26:46 --> Helper loaded: my_helper
INFO - 2023-09-22 15:26:46 --> Database Driver Class Initialized
INFO - 2023-09-22 15:26:46 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-22 15:26:46 --> Controller Class Initialized
INFO - 2023-09-22 15:26:47 --> Config Class Initialized
INFO - 2023-09-22 15:26:47 --> Hooks Class Initialized
DEBUG - 2023-09-22 15:26:47 --> UTF-8 Support Enabled
INFO - 2023-09-22 15:26:47 --> Utf8 Class Initialized
INFO - 2023-09-22 15:26:47 --> URI Class Initialized
INFO - 2023-09-22 15:26:47 --> Router Class Initialized
INFO - 2023-09-22 15:26:47 --> Output Class Initialized
INFO - 2023-09-22 15:26:47 --> Security Class Initialized
DEBUG - 2023-09-22 15:26:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-22 15:26:47 --> Input Class Initialized
INFO - 2023-09-22 15:26:47 --> Language Class Initialized
INFO - 2023-09-22 15:26:47 --> Language Class Initialized
INFO - 2023-09-22 15:26:47 --> Config Class Initialized
INFO - 2023-09-22 15:26:47 --> Loader Class Initialized
INFO - 2023-09-22 15:26:47 --> Helper loaded: url_helper
INFO - 2023-09-22 15:26:47 --> Helper loaded: file_helper
INFO - 2023-09-22 15:26:47 --> Helper loaded: form_helper
INFO - 2023-09-22 15:26:47 --> Helper loaded: my_helper
INFO - 2023-09-22 15:26:47 --> Database Driver Class Initialized
INFO - 2023-09-22 15:26:47 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-22 15:26:47 --> Controller Class Initialized
DEBUG - 2023-09-22 15:26:47 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/view_mapel/views/v_view_mapel.php
DEBUG - 2023-09-22 15:26:47 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-09-22 15:26:47 --> Final output sent to browser
DEBUG - 2023-09-22 15:26:47 --> Total execution time: 0.0380
INFO - 2023-09-22 15:26:52 --> Config Class Initialized
INFO - 2023-09-22 15:26:52 --> Hooks Class Initialized
DEBUG - 2023-09-22 15:26:52 --> UTF-8 Support Enabled
INFO - 2023-09-22 15:26:52 --> Utf8 Class Initialized
INFO - 2023-09-22 15:26:52 --> URI Class Initialized
INFO - 2023-09-22 15:26:52 --> Router Class Initialized
INFO - 2023-09-22 15:26:52 --> Output Class Initialized
INFO - 2023-09-22 15:26:52 --> Security Class Initialized
DEBUG - 2023-09-22 15:26:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-22 15:26:52 --> Input Class Initialized
INFO - 2023-09-22 15:26:52 --> Language Class Initialized
INFO - 2023-09-22 15:26:52 --> Language Class Initialized
INFO - 2023-09-22 15:26:52 --> Config Class Initialized
INFO - 2023-09-22 15:26:52 --> Loader Class Initialized
INFO - 2023-09-22 15:26:52 --> Helper loaded: url_helper
INFO - 2023-09-22 15:26:52 --> Helper loaded: file_helper
INFO - 2023-09-22 15:26:52 --> Helper loaded: form_helper
INFO - 2023-09-22 15:26:52 --> Helper loaded: my_helper
INFO - 2023-09-22 15:26:52 --> Database Driver Class Initialized
INFO - 2023-09-22 15:26:52 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-22 15:26:52 --> Controller Class Initialized
DEBUG - 2023-09-22 15:26:52 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_icb/views/list.php
DEBUG - 2023-09-22 15:26:52 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-09-22 15:26:52 --> Final output sent to browser
DEBUG - 2023-09-22 15:26:52 --> Total execution time: 0.0494
INFO - 2023-09-22 15:26:52 --> Config Class Initialized
INFO - 2023-09-22 15:26:52 --> Hooks Class Initialized
DEBUG - 2023-09-22 15:26:52 --> UTF-8 Support Enabled
INFO - 2023-09-22 15:26:52 --> Utf8 Class Initialized
INFO - 2023-09-22 15:26:52 --> URI Class Initialized
INFO - 2023-09-22 15:26:52 --> Router Class Initialized
INFO - 2023-09-22 15:26:52 --> Output Class Initialized
INFO - 2023-09-22 15:26:52 --> Security Class Initialized
DEBUG - 2023-09-22 15:26:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-22 15:26:52 --> Input Class Initialized
INFO - 2023-09-22 15:26:52 --> Language Class Initialized
INFO - 2023-09-22 15:26:52 --> Language Class Initialized
INFO - 2023-09-22 15:26:52 --> Config Class Initialized
INFO - 2023-09-22 15:26:52 --> Loader Class Initialized
INFO - 2023-09-22 15:26:52 --> Helper loaded: url_helper
INFO - 2023-09-22 15:26:52 --> Helper loaded: file_helper
INFO - 2023-09-22 15:26:52 --> Helper loaded: form_helper
INFO - 2023-09-22 15:26:52 --> Helper loaded: my_helper
INFO - 2023-09-22 15:26:52 --> Database Driver Class Initialized
INFO - 2023-09-22 15:26:52 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-22 15:26:52 --> Controller Class Initialized
INFO - 2023-09-22 15:26:54 --> Config Class Initialized
INFO - 2023-09-22 15:26:54 --> Hooks Class Initialized
DEBUG - 2023-09-22 15:26:54 --> UTF-8 Support Enabled
INFO - 2023-09-22 15:26:54 --> Utf8 Class Initialized
INFO - 2023-09-22 15:26:54 --> URI Class Initialized
INFO - 2023-09-22 15:26:54 --> Router Class Initialized
INFO - 2023-09-22 15:26:54 --> Output Class Initialized
INFO - 2023-09-22 15:26:54 --> Security Class Initialized
DEBUG - 2023-09-22 15:26:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-22 15:26:54 --> Input Class Initialized
INFO - 2023-09-22 15:26:54 --> Language Class Initialized
INFO - 2023-09-22 15:26:54 --> Language Class Initialized
INFO - 2023-09-22 15:26:54 --> Config Class Initialized
INFO - 2023-09-22 15:26:54 --> Loader Class Initialized
INFO - 2023-09-22 15:26:54 --> Helper loaded: url_helper
INFO - 2023-09-22 15:26:54 --> Helper loaded: file_helper
INFO - 2023-09-22 15:26:54 --> Helper loaded: form_helper
INFO - 2023-09-22 15:26:54 --> Helper loaded: my_helper
INFO - 2023-09-22 15:26:54 --> Database Driver Class Initialized
INFO - 2023-09-22 15:26:54 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-22 15:26:54 --> Controller Class Initialized
INFO - 2023-09-22 15:26:54 --> Final output sent to browser
DEBUG - 2023-09-22 15:26:54 --> Total execution time: 0.0367
INFO - 2023-09-22 15:26:57 --> Config Class Initialized
INFO - 2023-09-22 15:26:57 --> Hooks Class Initialized
DEBUG - 2023-09-22 15:26:57 --> UTF-8 Support Enabled
INFO - 2023-09-22 15:26:57 --> Utf8 Class Initialized
INFO - 2023-09-22 15:26:57 --> URI Class Initialized
INFO - 2023-09-22 15:26:57 --> Router Class Initialized
INFO - 2023-09-22 15:26:57 --> Output Class Initialized
INFO - 2023-09-22 15:26:57 --> Security Class Initialized
DEBUG - 2023-09-22 15:26:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-22 15:26:57 --> Input Class Initialized
INFO - 2023-09-22 15:26:57 --> Language Class Initialized
INFO - 2023-09-22 15:26:57 --> Language Class Initialized
INFO - 2023-09-22 15:26:57 --> Config Class Initialized
INFO - 2023-09-22 15:26:57 --> Loader Class Initialized
INFO - 2023-09-22 15:26:57 --> Helper loaded: url_helper
INFO - 2023-09-22 15:26:57 --> Helper loaded: file_helper
INFO - 2023-09-22 15:26:57 --> Helper loaded: form_helper
INFO - 2023-09-22 15:26:57 --> Helper loaded: my_helper
INFO - 2023-09-22 15:26:57 --> Database Driver Class Initialized
INFO - 2023-09-22 15:26:57 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-22 15:26:57 --> Controller Class Initialized
DEBUG - 2023-09-22 15:26:57 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/view_mapel/views/v_view_mapel.php
DEBUG - 2023-09-22 15:26:57 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-09-22 15:26:57 --> Final output sent to browser
DEBUG - 2023-09-22 15:26:57 --> Total execution time: 0.0728
INFO - 2023-09-22 15:27:00 --> Config Class Initialized
INFO - 2023-09-22 15:27:00 --> Hooks Class Initialized
DEBUG - 2023-09-22 15:27:00 --> UTF-8 Support Enabled
INFO - 2023-09-22 15:27:00 --> Utf8 Class Initialized
INFO - 2023-09-22 15:27:00 --> URI Class Initialized
INFO - 2023-09-22 15:27:00 --> Router Class Initialized
INFO - 2023-09-22 15:27:00 --> Output Class Initialized
INFO - 2023-09-22 15:27:00 --> Security Class Initialized
DEBUG - 2023-09-22 15:27:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-22 15:27:00 --> Input Class Initialized
INFO - 2023-09-22 15:27:00 --> Language Class Initialized
INFO - 2023-09-22 15:27:00 --> Language Class Initialized
INFO - 2023-09-22 15:27:00 --> Config Class Initialized
INFO - 2023-09-22 15:27:00 --> Loader Class Initialized
INFO - 2023-09-22 15:27:00 --> Helper loaded: url_helper
INFO - 2023-09-22 15:27:00 --> Helper loaded: file_helper
INFO - 2023-09-22 15:27:00 --> Helper loaded: form_helper
INFO - 2023-09-22 15:27:00 --> Helper loaded: my_helper
INFO - 2023-09-22 15:27:00 --> Database Driver Class Initialized
INFO - 2023-09-22 15:27:00 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-22 15:27:00 --> Controller Class Initialized
DEBUG - 2023-09-22 15:27:00 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_catatan_kl1/views/list.php
DEBUG - 2023-09-22 15:27:00 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-09-22 15:27:00 --> Final output sent to browser
DEBUG - 2023-09-22 15:27:00 --> Total execution time: 0.0388
INFO - 2023-09-22 15:27:03 --> Config Class Initialized
INFO - 2023-09-22 15:27:03 --> Hooks Class Initialized
DEBUG - 2023-09-22 15:27:03 --> UTF-8 Support Enabled
INFO - 2023-09-22 15:27:03 --> Utf8 Class Initialized
INFO - 2023-09-22 15:27:03 --> URI Class Initialized
INFO - 2023-09-22 15:27:03 --> Router Class Initialized
INFO - 2023-09-22 15:27:03 --> Output Class Initialized
INFO - 2023-09-22 15:27:03 --> Security Class Initialized
DEBUG - 2023-09-22 15:27:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-22 15:27:03 --> Input Class Initialized
INFO - 2023-09-22 15:27:03 --> Language Class Initialized
INFO - 2023-09-22 15:27:03 --> Language Class Initialized
INFO - 2023-09-22 15:27:03 --> Config Class Initialized
INFO - 2023-09-22 15:27:03 --> Loader Class Initialized
INFO - 2023-09-22 15:27:03 --> Helper loaded: url_helper
INFO - 2023-09-22 15:27:03 --> Helper loaded: file_helper
INFO - 2023-09-22 15:27:03 --> Helper loaded: form_helper
INFO - 2023-09-22 15:27:03 --> Helper loaded: my_helper
INFO - 2023-09-22 15:27:03 --> Database Driver Class Initialized
INFO - 2023-09-22 15:27:03 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-22 15:27:03 --> Controller Class Initialized
DEBUG - 2023-09-22 15:27:03 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_catatan_kl2/views/list.php
DEBUG - 2023-09-22 15:27:03 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-09-22 15:27:03 --> Final output sent to browser
DEBUG - 2023-09-22 15:27:03 --> Total execution time: 0.0412
INFO - 2023-09-22 15:27:38 --> Config Class Initialized
INFO - 2023-09-22 15:27:38 --> Hooks Class Initialized
DEBUG - 2023-09-22 15:27:38 --> UTF-8 Support Enabled
INFO - 2023-09-22 15:27:38 --> Utf8 Class Initialized
INFO - 2023-09-22 15:27:38 --> URI Class Initialized
INFO - 2023-09-22 15:27:38 --> Router Class Initialized
INFO - 2023-09-22 15:27:38 --> Output Class Initialized
INFO - 2023-09-22 15:27:38 --> Security Class Initialized
DEBUG - 2023-09-22 15:27:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-22 15:27:38 --> Input Class Initialized
INFO - 2023-09-22 15:27:38 --> Language Class Initialized
INFO - 2023-09-22 15:27:38 --> Language Class Initialized
INFO - 2023-09-22 15:27:38 --> Config Class Initialized
INFO - 2023-09-22 15:27:38 --> Loader Class Initialized
INFO - 2023-09-22 15:27:38 --> Helper loaded: url_helper
INFO - 2023-09-22 15:27:38 --> Helper loaded: file_helper
INFO - 2023-09-22 15:27:38 --> Helper loaded: form_helper
INFO - 2023-09-22 15:27:38 --> Helper loaded: my_helper
INFO - 2023-09-22 15:27:38 --> Database Driver Class Initialized
INFO - 2023-09-22 15:27:38 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-22 15:27:38 --> Controller Class Initialized
DEBUG - 2023-09-22 15:27:38 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_catatan_homeroom/views/list.php
DEBUG - 2023-09-22 15:27:38 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-09-22 15:27:38 --> Final output sent to browser
DEBUG - 2023-09-22 15:27:38 --> Total execution time: 0.0471
INFO - 2023-09-22 15:27:55 --> Config Class Initialized
INFO - 2023-09-22 15:27:55 --> Hooks Class Initialized
DEBUG - 2023-09-22 15:27:55 --> UTF-8 Support Enabled
INFO - 2023-09-22 15:27:55 --> Utf8 Class Initialized
INFO - 2023-09-22 15:27:55 --> URI Class Initialized
INFO - 2023-09-22 15:27:55 --> Router Class Initialized
INFO - 2023-09-22 15:27:55 --> Output Class Initialized
INFO - 2023-09-22 15:27:55 --> Security Class Initialized
DEBUG - 2023-09-22 15:27:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-22 15:27:55 --> Input Class Initialized
INFO - 2023-09-22 15:27:55 --> Language Class Initialized
INFO - 2023-09-22 15:27:55 --> Language Class Initialized
INFO - 2023-09-22 15:27:55 --> Config Class Initialized
INFO - 2023-09-22 15:27:55 --> Loader Class Initialized
INFO - 2023-09-22 15:27:55 --> Helper loaded: url_helper
INFO - 2023-09-22 15:27:55 --> Helper loaded: file_helper
INFO - 2023-09-22 15:27:55 --> Helper loaded: form_helper
INFO - 2023-09-22 15:27:55 --> Helper loaded: my_helper
INFO - 2023-09-22 15:27:55 --> Database Driver Class Initialized
INFO - 2023-09-22 15:27:55 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-22 15:27:55 --> Controller Class Initialized
DEBUG - 2023-09-22 15:27:55 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/view_mapel/views/v_view_mapel.php
DEBUG - 2023-09-22 15:27:55 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-09-22 15:27:55 --> Final output sent to browser
DEBUG - 2023-09-22 15:27:55 --> Total execution time: 0.0591
INFO - 2023-09-22 15:27:56 --> Config Class Initialized
INFO - 2023-09-22 15:27:56 --> Hooks Class Initialized
DEBUG - 2023-09-22 15:27:56 --> UTF-8 Support Enabled
INFO - 2023-09-22 15:27:56 --> Utf8 Class Initialized
INFO - 2023-09-22 15:27:56 --> URI Class Initialized
INFO - 2023-09-22 15:27:56 --> Router Class Initialized
INFO - 2023-09-22 15:27:56 --> Output Class Initialized
INFO - 2023-09-22 15:27:56 --> Security Class Initialized
DEBUG - 2023-09-22 15:27:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-22 15:27:56 --> Input Class Initialized
INFO - 2023-09-22 15:27:56 --> Language Class Initialized
INFO - 2023-09-22 15:27:56 --> Language Class Initialized
INFO - 2023-09-22 15:27:56 --> Config Class Initialized
INFO - 2023-09-22 15:27:56 --> Loader Class Initialized
INFO - 2023-09-22 15:27:56 --> Helper loaded: url_helper
INFO - 2023-09-22 15:27:56 --> Helper loaded: file_helper
INFO - 2023-09-22 15:27:56 --> Helper loaded: form_helper
INFO - 2023-09-22 15:27:56 --> Helper loaded: my_helper
INFO - 2023-09-22 15:27:56 --> Database Driver Class Initialized
INFO - 2023-09-22 15:27:56 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-22 15:27:56 --> Controller Class Initialized
DEBUG - 2023-09-22 15:27:56 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/login/views/login.php
DEBUG - 2023-09-22 15:27:56 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-09-22 15:27:56 --> Final output sent to browser
DEBUG - 2023-09-22 15:27:56 --> Total execution time: 0.0374
INFO - 2023-09-22 15:29:10 --> Config Class Initialized
INFO - 2023-09-22 15:29:10 --> Hooks Class Initialized
DEBUG - 2023-09-22 15:29:10 --> UTF-8 Support Enabled
INFO - 2023-09-22 15:29:10 --> Utf8 Class Initialized
INFO - 2023-09-22 15:29:10 --> URI Class Initialized
INFO - 2023-09-22 15:29:10 --> Router Class Initialized
INFO - 2023-09-22 15:29:10 --> Output Class Initialized
INFO - 2023-09-22 15:29:10 --> Security Class Initialized
DEBUG - 2023-09-22 15:29:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-22 15:29:10 --> Input Class Initialized
INFO - 2023-09-22 15:29:10 --> Language Class Initialized
INFO - 2023-09-22 15:29:10 --> Language Class Initialized
INFO - 2023-09-22 15:29:10 --> Config Class Initialized
INFO - 2023-09-22 15:29:10 --> Loader Class Initialized
INFO - 2023-09-22 15:29:10 --> Helper loaded: url_helper
INFO - 2023-09-22 15:29:10 --> Helper loaded: file_helper
INFO - 2023-09-22 15:29:10 --> Helper loaded: form_helper
INFO - 2023-09-22 15:29:10 --> Helper loaded: my_helper
INFO - 2023-09-22 15:29:10 --> Database Driver Class Initialized
INFO - 2023-09-22 15:29:10 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-22 15:29:10 --> Controller Class Initialized
DEBUG - 2023-09-22 15:29:10 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/home/views/v_ubah_password.php
DEBUG - 2023-09-22 15:29:10 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-09-22 15:29:10 --> Final output sent to browser
DEBUG - 2023-09-22 15:29:10 --> Total execution time: 0.0442
INFO - 2023-09-22 15:29:53 --> Config Class Initialized
INFO - 2023-09-22 15:29:53 --> Hooks Class Initialized
DEBUG - 2023-09-22 15:29:53 --> UTF-8 Support Enabled
INFO - 2023-09-22 15:29:53 --> Utf8 Class Initialized
INFO - 2023-09-22 15:29:53 --> URI Class Initialized
INFO - 2023-09-22 15:29:53 --> Router Class Initialized
INFO - 2023-09-22 15:29:53 --> Output Class Initialized
INFO - 2023-09-22 15:29:53 --> Security Class Initialized
DEBUG - 2023-09-22 15:29:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-22 15:29:53 --> Input Class Initialized
INFO - 2023-09-22 15:29:53 --> Language Class Initialized
INFO - 2023-09-22 15:29:53 --> Language Class Initialized
INFO - 2023-09-22 15:29:53 --> Config Class Initialized
INFO - 2023-09-22 15:29:53 --> Loader Class Initialized
INFO - 2023-09-22 15:29:53 --> Helper loaded: url_helper
INFO - 2023-09-22 15:29:53 --> Helper loaded: file_helper
INFO - 2023-09-22 15:29:53 --> Helper loaded: form_helper
INFO - 2023-09-22 15:29:53 --> Helper loaded: my_helper
INFO - 2023-09-22 15:29:53 --> Database Driver Class Initialized
INFO - 2023-09-22 15:29:53 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-22 15:29:53 --> Controller Class Initialized
INFO - 2023-09-22 15:30:11 --> Config Class Initialized
INFO - 2023-09-22 15:30:11 --> Hooks Class Initialized
DEBUG - 2023-09-22 15:30:11 --> UTF-8 Support Enabled
INFO - 2023-09-22 15:30:11 --> Utf8 Class Initialized
INFO - 2023-09-22 15:30:11 --> URI Class Initialized
INFO - 2023-09-22 15:30:11 --> Router Class Initialized
INFO - 2023-09-22 15:30:11 --> Output Class Initialized
INFO - 2023-09-22 15:30:11 --> Security Class Initialized
DEBUG - 2023-09-22 15:30:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-22 15:30:11 --> Input Class Initialized
INFO - 2023-09-22 15:30:11 --> Language Class Initialized
INFO - 2023-09-22 15:30:11 --> Language Class Initialized
INFO - 2023-09-22 15:30:11 --> Config Class Initialized
INFO - 2023-09-22 15:30:11 --> Loader Class Initialized
INFO - 2023-09-22 15:30:11 --> Helper loaded: url_helper
INFO - 2023-09-22 15:30:11 --> Helper loaded: file_helper
INFO - 2023-09-22 15:30:11 --> Helper loaded: form_helper
INFO - 2023-09-22 15:30:11 --> Helper loaded: my_helper
INFO - 2023-09-22 15:30:11 --> Database Driver Class Initialized
INFO - 2023-09-22 15:30:11 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-22 15:30:11 --> Controller Class Initialized
DEBUG - 2023-09-22 15:30:11 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/riwayat_mengajar/views/list.php
DEBUG - 2023-09-22 15:30:11 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-09-22 15:30:11 --> Final output sent to browser
DEBUG - 2023-09-22 15:30:11 --> Total execution time: 0.0761
INFO - 2023-09-22 15:30:20 --> Config Class Initialized
INFO - 2023-09-22 15:30:20 --> Hooks Class Initialized
DEBUG - 2023-09-22 15:30:20 --> UTF-8 Support Enabled
INFO - 2023-09-22 15:30:20 --> Utf8 Class Initialized
INFO - 2023-09-22 15:30:20 --> URI Class Initialized
DEBUG - 2023-09-22 15:30:20 --> No URI present. Default controller set.
INFO - 2023-09-22 15:30:20 --> Router Class Initialized
INFO - 2023-09-22 15:30:20 --> Output Class Initialized
INFO - 2023-09-22 15:30:20 --> Security Class Initialized
DEBUG - 2023-09-22 15:30:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-22 15:30:20 --> Input Class Initialized
INFO - 2023-09-22 15:30:20 --> Language Class Initialized
INFO - 2023-09-22 15:30:20 --> Language Class Initialized
INFO - 2023-09-22 15:30:20 --> Config Class Initialized
INFO - 2023-09-22 15:30:20 --> Loader Class Initialized
INFO - 2023-09-22 15:30:20 --> Helper loaded: url_helper
INFO - 2023-09-22 15:30:20 --> Helper loaded: file_helper
INFO - 2023-09-22 15:30:20 --> Helper loaded: form_helper
INFO - 2023-09-22 15:30:20 --> Helper loaded: my_helper
INFO - 2023-09-22 15:30:20 --> Database Driver Class Initialized
INFO - 2023-09-22 15:30:20 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-22 15:30:20 --> Controller Class Initialized
DEBUG - 2023-09-22 15:30:20 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/home/views/v_home_guru.php
DEBUG - 2023-09-22 15:30:20 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-09-22 15:30:20 --> Final output sent to browser
DEBUG - 2023-09-22 15:30:20 --> Total execution time: 0.0373
INFO - 2023-09-22 15:30:23 --> Config Class Initialized
INFO - 2023-09-22 15:30:23 --> Hooks Class Initialized
DEBUG - 2023-09-22 15:30:23 --> UTF-8 Support Enabled
INFO - 2023-09-22 15:30:23 --> Utf8 Class Initialized
INFO - 2023-09-22 15:30:23 --> URI Class Initialized
INFO - 2023-09-22 15:30:23 --> Router Class Initialized
INFO - 2023-09-22 15:30:23 --> Output Class Initialized
INFO - 2023-09-22 15:30:23 --> Security Class Initialized
DEBUG - 2023-09-22 15:30:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-22 15:30:23 --> Input Class Initialized
INFO - 2023-09-22 15:30:23 --> Language Class Initialized
INFO - 2023-09-22 15:30:23 --> Language Class Initialized
INFO - 2023-09-22 15:30:23 --> Config Class Initialized
INFO - 2023-09-22 15:30:23 --> Loader Class Initialized
INFO - 2023-09-22 15:30:23 --> Helper loaded: url_helper
INFO - 2023-09-22 15:30:23 --> Helper loaded: file_helper
INFO - 2023-09-22 15:30:23 --> Helper loaded: form_helper
INFO - 2023-09-22 15:30:23 --> Helper loaded: my_helper
INFO - 2023-09-22 15:30:23 --> Database Driver Class Initialized
INFO - 2023-09-22 15:30:23 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-22 15:30:23 --> Controller Class Initialized
DEBUG - 2023-09-22 15:30:23 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/riwayat_mengajar/views/list.php
DEBUG - 2023-09-22 15:30:23 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-09-22 15:30:23 --> Final output sent to browser
DEBUG - 2023-09-22 15:30:23 --> Total execution time: 0.0333
INFO - 2023-09-22 15:32:55 --> Config Class Initialized
INFO - 2023-09-22 15:32:55 --> Hooks Class Initialized
DEBUG - 2023-09-22 15:32:55 --> UTF-8 Support Enabled
INFO - 2023-09-22 15:32:55 --> Utf8 Class Initialized
INFO - 2023-09-22 15:32:55 --> URI Class Initialized
INFO - 2023-09-22 15:32:55 --> Router Class Initialized
INFO - 2023-09-22 15:32:55 --> Output Class Initialized
INFO - 2023-09-22 15:32:55 --> Security Class Initialized
DEBUG - 2023-09-22 15:32:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-22 15:32:55 --> Input Class Initialized
INFO - 2023-09-22 15:32:55 --> Language Class Initialized
INFO - 2023-09-22 15:32:55 --> Language Class Initialized
INFO - 2023-09-22 15:32:55 --> Config Class Initialized
INFO - 2023-09-22 15:32:55 --> Loader Class Initialized
INFO - 2023-09-22 15:32:55 --> Helper loaded: url_helper
INFO - 2023-09-22 15:32:55 --> Helper loaded: file_helper
INFO - 2023-09-22 15:32:55 --> Helper loaded: form_helper
INFO - 2023-09-22 15:32:55 --> Helper loaded: my_helper
INFO - 2023-09-22 15:32:55 --> Database Driver Class Initialized
INFO - 2023-09-22 15:32:55 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-22 15:32:55 --> Controller Class Initialized
DEBUG - 2023-09-22 15:32:55 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/view_mapel/views/v_view_mapel.php
DEBUG - 2023-09-22 15:32:55 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-09-22 15:32:55 --> Final output sent to browser
DEBUG - 2023-09-22 15:32:55 --> Total execution time: 0.0549
INFO - 2023-09-22 15:32:56 --> Config Class Initialized
INFO - 2023-09-22 15:32:56 --> Hooks Class Initialized
DEBUG - 2023-09-22 15:32:56 --> UTF-8 Support Enabled
INFO - 2023-09-22 15:32:56 --> Utf8 Class Initialized
INFO - 2023-09-22 15:32:56 --> URI Class Initialized
INFO - 2023-09-22 15:32:56 --> Router Class Initialized
INFO - 2023-09-22 15:32:56 --> Output Class Initialized
INFO - 2023-09-22 15:32:56 --> Security Class Initialized
DEBUG - 2023-09-22 15:32:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-22 15:32:56 --> Input Class Initialized
INFO - 2023-09-22 15:32:56 --> Language Class Initialized
INFO - 2023-09-22 15:32:56 --> Language Class Initialized
INFO - 2023-09-22 15:32:56 --> Config Class Initialized
INFO - 2023-09-22 15:32:56 --> Loader Class Initialized
INFO - 2023-09-22 15:32:56 --> Helper loaded: url_helper
INFO - 2023-09-22 15:32:56 --> Helper loaded: file_helper
INFO - 2023-09-22 15:32:56 --> Helper loaded: form_helper
INFO - 2023-09-22 15:32:56 --> Helper loaded: my_helper
INFO - 2023-09-22 15:32:56 --> Database Driver Class Initialized
INFO - 2023-09-22 15:32:56 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-22 15:32:56 --> Controller Class Initialized
DEBUG - 2023-09-22 15:32:56 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_catatan_guru/views/list.php
DEBUG - 2023-09-22 15:32:56 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-09-22 15:32:56 --> Final output sent to browser
DEBUG - 2023-09-22 15:32:56 --> Total execution time: 0.0398
INFO - 2023-09-22 15:32:58 --> Config Class Initialized
INFO - 2023-09-22 15:32:58 --> Hooks Class Initialized
DEBUG - 2023-09-22 15:32:58 --> UTF-8 Support Enabled
INFO - 2023-09-22 15:32:58 --> Utf8 Class Initialized
INFO - 2023-09-22 15:32:58 --> URI Class Initialized
INFO - 2023-09-22 15:32:58 --> Router Class Initialized
INFO - 2023-09-22 15:32:58 --> Output Class Initialized
INFO - 2023-09-22 15:32:58 --> Security Class Initialized
DEBUG - 2023-09-22 15:32:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-22 15:32:58 --> Input Class Initialized
INFO - 2023-09-22 15:32:58 --> Language Class Initialized
INFO - 2023-09-22 15:32:58 --> Language Class Initialized
INFO - 2023-09-22 15:32:58 --> Config Class Initialized
INFO - 2023-09-22 15:32:58 --> Loader Class Initialized
INFO - 2023-09-22 15:32:58 --> Helper loaded: url_helper
INFO - 2023-09-22 15:32:58 --> Helper loaded: file_helper
INFO - 2023-09-22 15:32:58 --> Helper loaded: form_helper
INFO - 2023-09-22 15:32:58 --> Helper loaded: my_helper
INFO - 2023-09-22 15:32:58 --> Database Driver Class Initialized
INFO - 2023-09-22 15:32:58 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-22 15:32:58 --> Controller Class Initialized
INFO - 2023-09-22 15:32:58 --> Final output sent to browser
DEBUG - 2023-09-22 15:32:58 --> Total execution time: 0.0417
INFO - 2023-09-22 15:33:01 --> Config Class Initialized
INFO - 2023-09-22 15:33:01 --> Hooks Class Initialized
DEBUG - 2023-09-22 15:33:01 --> UTF-8 Support Enabled
INFO - 2023-09-22 15:33:01 --> Utf8 Class Initialized
INFO - 2023-09-22 15:33:01 --> URI Class Initialized
INFO - 2023-09-22 15:33:01 --> Router Class Initialized
INFO - 2023-09-22 15:33:01 --> Output Class Initialized
INFO - 2023-09-22 15:33:01 --> Security Class Initialized
DEBUG - 2023-09-22 15:33:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-22 15:33:01 --> Input Class Initialized
INFO - 2023-09-22 15:33:01 --> Language Class Initialized
INFO - 2023-09-22 15:33:01 --> Language Class Initialized
INFO - 2023-09-22 15:33:01 --> Config Class Initialized
INFO - 2023-09-22 15:33:01 --> Loader Class Initialized
INFO - 2023-09-22 15:33:01 --> Helper loaded: url_helper
INFO - 2023-09-22 15:33:01 --> Helper loaded: file_helper
INFO - 2023-09-22 15:33:01 --> Helper loaded: form_helper
INFO - 2023-09-22 15:33:01 --> Helper loaded: my_helper
INFO - 2023-09-22 15:33:01 --> Database Driver Class Initialized
INFO - 2023-09-22 15:33:01 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-22 15:33:01 --> Controller Class Initialized
INFO - 2023-09-22 15:33:24 --> Config Class Initialized
INFO - 2023-09-22 15:33:24 --> Hooks Class Initialized
DEBUG - 2023-09-22 15:33:24 --> UTF-8 Support Enabled
INFO - 2023-09-22 15:33:24 --> Utf8 Class Initialized
INFO - 2023-09-22 15:33:24 --> URI Class Initialized
INFO - 2023-09-22 15:33:24 --> Router Class Initialized
INFO - 2023-09-22 15:33:24 --> Output Class Initialized
INFO - 2023-09-22 15:33:24 --> Security Class Initialized
DEBUG - 2023-09-22 15:33:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-22 15:33:24 --> Input Class Initialized
INFO - 2023-09-22 15:33:24 --> Language Class Initialized
INFO - 2023-09-22 15:33:24 --> Language Class Initialized
INFO - 2023-09-22 15:33:24 --> Config Class Initialized
INFO - 2023-09-22 15:33:24 --> Loader Class Initialized
INFO - 2023-09-22 15:33:24 --> Helper loaded: url_helper
INFO - 2023-09-22 15:33:24 --> Helper loaded: file_helper
INFO - 2023-09-22 15:33:24 --> Helper loaded: form_helper
INFO - 2023-09-22 15:33:24 --> Helper loaded: my_helper
INFO - 2023-09-22 15:33:24 --> Database Driver Class Initialized
INFO - 2023-09-22 15:33:24 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-22 15:33:24 --> Controller Class Initialized
INFO - 2023-09-22 15:33:24 --> Helper loaded: cookie_helper
INFO - 2023-09-22 15:33:24 --> Final output sent to browser
DEBUG - 2023-09-22 15:33:24 --> Total execution time: 0.0355
INFO - 2023-09-22 15:33:24 --> Config Class Initialized
INFO - 2023-09-22 15:33:24 --> Hooks Class Initialized
DEBUG - 2023-09-22 15:33:24 --> UTF-8 Support Enabled
INFO - 2023-09-22 15:33:24 --> Utf8 Class Initialized
INFO - 2023-09-22 15:33:24 --> URI Class Initialized
INFO - 2023-09-22 15:33:24 --> Router Class Initialized
INFO - 2023-09-22 15:33:24 --> Output Class Initialized
INFO - 2023-09-22 15:33:24 --> Security Class Initialized
DEBUG - 2023-09-22 15:33:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-22 15:33:24 --> Input Class Initialized
INFO - 2023-09-22 15:33:24 --> Language Class Initialized
INFO - 2023-09-22 15:33:24 --> Language Class Initialized
INFO - 2023-09-22 15:33:24 --> Config Class Initialized
INFO - 2023-09-22 15:33:24 --> Loader Class Initialized
INFO - 2023-09-22 15:33:24 --> Helper loaded: url_helper
INFO - 2023-09-22 15:33:24 --> Helper loaded: file_helper
INFO - 2023-09-22 15:33:24 --> Helper loaded: form_helper
INFO - 2023-09-22 15:33:24 --> Helper loaded: my_helper
INFO - 2023-09-22 15:33:24 --> Database Driver Class Initialized
INFO - 2023-09-22 15:33:24 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-22 15:33:24 --> Controller Class Initialized
DEBUG - 2023-09-22 15:33:24 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/home/views/v_home_guru.php
DEBUG - 2023-09-22 15:33:24 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-09-22 15:33:24 --> Final output sent to browser
DEBUG - 2023-09-22 15:33:24 --> Total execution time: 0.0438
INFO - 2023-09-22 15:33:41 --> Config Class Initialized
INFO - 2023-09-22 15:33:41 --> Hooks Class Initialized
DEBUG - 2023-09-22 15:33:41 --> UTF-8 Support Enabled
INFO - 2023-09-22 15:33:41 --> Utf8 Class Initialized
INFO - 2023-09-22 15:33:41 --> URI Class Initialized
INFO - 2023-09-22 15:33:41 --> Router Class Initialized
INFO - 2023-09-22 15:33:41 --> Output Class Initialized
INFO - 2023-09-22 15:33:41 --> Security Class Initialized
DEBUG - 2023-09-22 15:33:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-22 15:33:41 --> Input Class Initialized
INFO - 2023-09-22 15:33:41 --> Language Class Initialized
INFO - 2023-09-22 15:33:41 --> Language Class Initialized
INFO - 2023-09-22 15:33:41 --> Config Class Initialized
INFO - 2023-09-22 15:33:41 --> Loader Class Initialized
INFO - 2023-09-22 15:33:41 --> Helper loaded: url_helper
INFO - 2023-09-22 15:33:41 --> Helper loaded: file_helper
INFO - 2023-09-22 15:33:41 --> Helper loaded: form_helper
INFO - 2023-09-22 15:33:41 --> Helper loaded: my_helper
INFO - 2023-09-22 15:33:41 --> Database Driver Class Initialized
INFO - 2023-09-22 15:33:41 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-22 15:33:41 --> Controller Class Initialized
DEBUG - 2023-09-22 15:33:41 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/riwayat_mengajar/views/list.php
DEBUG - 2023-09-22 15:33:41 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-09-22 15:33:41 --> Final output sent to browser
DEBUG - 2023-09-22 15:33:41 --> Total execution time: 0.0361
INFO - 2023-09-22 15:33:45 --> Config Class Initialized
INFO - 2023-09-22 15:33:45 --> Hooks Class Initialized
DEBUG - 2023-09-22 15:33:45 --> UTF-8 Support Enabled
INFO - 2023-09-22 15:33:45 --> Utf8 Class Initialized
INFO - 2023-09-22 15:33:45 --> URI Class Initialized
INFO - 2023-09-22 15:33:45 --> Router Class Initialized
INFO - 2023-09-22 15:33:45 --> Output Class Initialized
INFO - 2023-09-22 15:33:45 --> Security Class Initialized
DEBUG - 2023-09-22 15:33:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-22 15:33:45 --> Input Class Initialized
INFO - 2023-09-22 15:33:45 --> Language Class Initialized
INFO - 2023-09-22 15:33:45 --> Language Class Initialized
INFO - 2023-09-22 15:33:45 --> Config Class Initialized
INFO - 2023-09-22 15:33:45 --> Loader Class Initialized
INFO - 2023-09-22 15:33:45 --> Helper loaded: url_helper
INFO - 2023-09-22 15:33:45 --> Helper loaded: file_helper
INFO - 2023-09-22 15:33:45 --> Helper loaded: form_helper
INFO - 2023-09-22 15:33:45 --> Helper loaded: my_helper
INFO - 2023-09-22 15:33:45 --> Database Driver Class Initialized
INFO - 2023-09-22 15:33:45 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-22 15:33:45 --> Controller Class Initialized
ERROR - 2023-09-22 15:33:45 --> Severity: Notice --> Undefined index: nama /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/controllers/N_pengetahuan.php 158
ERROR - 2023-09-22 15:33:45 --> Severity: Notice --> Undefined offset: 1 /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/controllers/N_pengetahuan.php 202
ERROR - 2023-09-22 15:33:45 --> Severity: Notice --> Undefined offset: 1 /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/controllers/N_pengetahuan.php 203
ERROR - 2023-09-22 15:33:45 --> Severity: Notice --> Undefined index: nama /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/controllers/N_pengetahuan.php 241
ERROR - 2023-09-22 15:33:45 --> Severity: Notice --> Undefined index: nama /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/controllers/N_pengetahuan.php 158
ERROR - 2023-09-22 15:33:45 --> Severity: Notice --> Undefined offset: 1 /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/controllers/N_pengetahuan.php 202
ERROR - 2023-09-22 15:33:45 --> Severity: Notice --> Undefined offset: 1 /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/controllers/N_pengetahuan.php 203
ERROR - 2023-09-22 15:33:45 --> Severity: Notice --> Undefined index: nama /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/controllers/N_pengetahuan.php 241
ERROR - 2023-09-22 15:33:45 --> Severity: Notice --> Undefined index: nama /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/controllers/N_pengetahuan.php 158
ERROR - 2023-09-22 15:33:45 --> Severity: Notice --> Undefined offset: 1 /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/controllers/N_pengetahuan.php 202
ERROR - 2023-09-22 15:33:45 --> Severity: Notice --> Undefined offset: 1 /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/controllers/N_pengetahuan.php 203
ERROR - 2023-09-22 15:33:45 --> Severity: Notice --> Undefined index: nama /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/controllers/N_pengetahuan.php 241
ERROR - 2023-09-22 15:33:45 --> Severity: Notice --> Undefined index: nama /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/controllers/N_pengetahuan.php 158
ERROR - 2023-09-22 15:33:45 --> Severity: Notice --> Undefined offset: 1 /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/controllers/N_pengetahuan.php 202
ERROR - 2023-09-22 15:33:45 --> Severity: Notice --> Undefined offset: 1 /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/controllers/N_pengetahuan.php 203
ERROR - 2023-09-22 15:33:45 --> Severity: Notice --> Undefined index: nama /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/controllers/N_pengetahuan.php 241
ERROR - 2023-09-22 15:33:45 --> Severity: Notice --> Undefined index: nama /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/controllers/N_pengetahuan.php 158
ERROR - 2023-09-22 15:33:45 --> Severity: Notice --> Undefined offset: 1 /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/controllers/N_pengetahuan.php 202
ERROR - 2023-09-22 15:33:45 --> Severity: Notice --> Undefined offset: 1 /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/controllers/N_pengetahuan.php 203
ERROR - 2023-09-22 15:33:45 --> Severity: Notice --> Undefined index: nama /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/controllers/N_pengetahuan.php 241
ERROR - 2023-09-22 15:33:45 --> Severity: Notice --> Undefined index: nama /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/controllers/N_pengetahuan.php 158
ERROR - 2023-09-22 15:33:45 --> Severity: Notice --> Undefined offset: 1 /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/controllers/N_pengetahuan.php 202
ERROR - 2023-09-22 15:33:45 --> Severity: Notice --> Undefined offset: 1 /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/controllers/N_pengetahuan.php 203
ERROR - 2023-09-22 15:33:45 --> Severity: Notice --> Undefined index: nama /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/controllers/N_pengetahuan.php 241
ERROR - 2023-09-22 15:33:45 --> Severity: Notice --> Undefined index: nama /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/controllers/N_pengetahuan.php 158
ERROR - 2023-09-22 15:33:45 --> Severity: Notice --> Undefined offset: 1 /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/controllers/N_pengetahuan.php 202
ERROR - 2023-09-22 15:33:45 --> Severity: Notice --> Undefined offset: 1 /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/controllers/N_pengetahuan.php 203
ERROR - 2023-09-22 15:33:45 --> Severity: Notice --> Undefined index: nama /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/controllers/N_pengetahuan.php 241
ERROR - 2023-09-22 15:33:45 --> Severity: Notice --> Undefined index: nama /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/controllers/N_pengetahuan.php 158
ERROR - 2023-09-22 15:33:45 --> Severity: Notice --> Undefined offset: 1 /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/controllers/N_pengetahuan.php 202
ERROR - 2023-09-22 15:33:45 --> Severity: Notice --> Undefined offset: 1 /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/controllers/N_pengetahuan.php 203
ERROR - 2023-09-22 15:33:45 --> Severity: Notice --> Undefined index: nama /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/controllers/N_pengetahuan.php 241
ERROR - 2023-09-22 15:33:45 --> Severity: Notice --> Undefined index: nama /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/controllers/N_pengetahuan.php 158
ERROR - 2023-09-22 15:33:45 --> Severity: Notice --> Undefined offset: 1 /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/controllers/N_pengetahuan.php 202
ERROR - 2023-09-22 15:33:45 --> Severity: Notice --> Undefined offset: 1 /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/controllers/N_pengetahuan.php 203
ERROR - 2023-09-22 15:33:45 --> Severity: Notice --> Undefined index: nama /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/controllers/N_pengetahuan.php 241
ERROR - 2023-09-22 15:33:45 --> Severity: Notice --> Undefined index: nama /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/controllers/N_pengetahuan.php 158
ERROR - 2023-09-22 15:33:45 --> Severity: Notice --> Undefined offset: 1 /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/controllers/N_pengetahuan.php 202
ERROR - 2023-09-22 15:33:45 --> Severity: Notice --> Undefined offset: 1 /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/controllers/N_pengetahuan.php 203
ERROR - 2023-09-22 15:33:45 --> Severity: Notice --> Undefined index: nama /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/controllers/N_pengetahuan.php 241
ERROR - 2023-09-22 15:33:45 --> Severity: Notice --> Undefined index: nama /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/controllers/N_pengetahuan.php 158
ERROR - 2023-09-22 15:33:45 --> Severity: Notice --> Undefined offset: 1 /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/controllers/N_pengetahuan.php 202
ERROR - 2023-09-22 15:33:45 --> Severity: Notice --> Undefined offset: 1 /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/controllers/N_pengetahuan.php 203
ERROR - 2023-09-22 15:33:45 --> Severity: Notice --> Undefined index: nama /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/controllers/N_pengetahuan.php 241
ERROR - 2023-09-22 15:33:45 --> Severity: Notice --> Undefined index: nama /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/controllers/N_pengetahuan.php 158
ERROR - 2023-09-22 15:33:45 --> Severity: Notice --> Undefined offset: 1 /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/controllers/N_pengetahuan.php 202
ERROR - 2023-09-22 15:33:45 --> Severity: Notice --> Undefined offset: 1 /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/controllers/N_pengetahuan.php 203
ERROR - 2023-09-22 15:33:45 --> Severity: Notice --> Undefined index: nama /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/controllers/N_pengetahuan.php 241
ERROR - 2023-09-22 15:33:45 --> Severity: Notice --> Undefined index: nama /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/controllers/N_pengetahuan.php 158
ERROR - 2023-09-22 15:33:45 --> Severity: Notice --> Undefined offset: 1 /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/controllers/N_pengetahuan.php 202
ERROR - 2023-09-22 15:33:45 --> Severity: Notice --> Undefined offset: 1 /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/controllers/N_pengetahuan.php 203
ERROR - 2023-09-22 15:33:45 --> Severity: Notice --> Undefined index: nama /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/controllers/N_pengetahuan.php 241
ERROR - 2023-09-22 15:33:45 --> Severity: Notice --> Undefined index: nama /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/controllers/N_pengetahuan.php 158
ERROR - 2023-09-22 15:33:45 --> Severity: Notice --> Undefined offset: 1 /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/controllers/N_pengetahuan.php 202
ERROR - 2023-09-22 15:33:45 --> Severity: Notice --> Undefined offset: 1 /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/controllers/N_pengetahuan.php 203
ERROR - 2023-09-22 15:33:45 --> Severity: Notice --> Undefined index: nama /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/controllers/N_pengetahuan.php 241
ERROR - 2023-09-22 15:33:45 --> Severity: Notice --> Undefined index: nama /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/controllers/N_pengetahuan.php 158
ERROR - 2023-09-22 15:33:45 --> Severity: Notice --> Undefined offset: 1 /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/controllers/N_pengetahuan.php 202
ERROR - 2023-09-22 15:33:45 --> Severity: Notice --> Undefined offset: 1 /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/controllers/N_pengetahuan.php 203
ERROR - 2023-09-22 15:33:45 --> Severity: Notice --> Undefined index: nama /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/controllers/N_pengetahuan.php 241
ERROR - 2023-09-22 15:33:45 --> Severity: Notice --> Undefined index: nama /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/controllers/N_pengetahuan.php 158
ERROR - 2023-09-22 15:33:45 --> Severity: Notice --> Undefined offset: 1 /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/controllers/N_pengetahuan.php 202
ERROR - 2023-09-22 15:33:45 --> Severity: Notice --> Undefined offset: 1 /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/controllers/N_pengetahuan.php 203
ERROR - 2023-09-22 15:33:45 --> Severity: Notice --> Undefined index: nama /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/controllers/N_pengetahuan.php 241
DEBUG - 2023-09-22 15:33:45 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/views/cetak.php
INFO - 2023-09-22 15:33:45 --> Final output sent to browser
DEBUG - 2023-09-22 15:33:45 --> Total execution time: 0.0617
INFO - 2023-09-22 15:33:57 --> Config Class Initialized
INFO - 2023-09-22 15:33:57 --> Hooks Class Initialized
DEBUG - 2023-09-22 15:33:57 --> UTF-8 Support Enabled
INFO - 2023-09-22 15:33:57 --> Utf8 Class Initialized
INFO - 2023-09-22 15:33:57 --> URI Class Initialized
INFO - 2023-09-22 15:33:57 --> Router Class Initialized
INFO - 2023-09-22 15:33:57 --> Output Class Initialized
INFO - 2023-09-22 15:33:57 --> Security Class Initialized
DEBUG - 2023-09-22 15:33:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-22 15:33:57 --> Input Class Initialized
INFO - 2023-09-22 15:33:57 --> Language Class Initialized
INFO - 2023-09-22 15:33:57 --> Language Class Initialized
INFO - 2023-09-22 15:33:57 --> Config Class Initialized
INFO - 2023-09-22 15:33:57 --> Loader Class Initialized
INFO - 2023-09-22 15:33:57 --> Helper loaded: url_helper
INFO - 2023-09-22 15:33:57 --> Helper loaded: file_helper
INFO - 2023-09-22 15:33:57 --> Helper loaded: form_helper
INFO - 2023-09-22 15:33:57 --> Helper loaded: my_helper
INFO - 2023-09-22 15:33:57 --> Database Driver Class Initialized
INFO - 2023-09-22 15:33:57 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-22 15:33:57 --> Controller Class Initialized
DEBUG - 2023-09-22 15:33:57 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_keterampilan/views/cetak.php
INFO - 2023-09-22 15:33:57 --> Final output sent to browser
DEBUG - 2023-09-22 15:33:57 --> Total execution time: 0.0407
INFO - 2023-09-22 15:34:14 --> Config Class Initialized
INFO - 2023-09-22 15:34:14 --> Hooks Class Initialized
DEBUG - 2023-09-22 15:34:14 --> UTF-8 Support Enabled
INFO - 2023-09-22 15:34:14 --> Utf8 Class Initialized
INFO - 2023-09-22 15:34:14 --> URI Class Initialized
INFO - 2023-09-22 15:34:14 --> Router Class Initialized
INFO - 2023-09-22 15:34:14 --> Output Class Initialized
INFO - 2023-09-22 15:34:14 --> Security Class Initialized
DEBUG - 2023-09-22 15:34:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-22 15:34:14 --> Input Class Initialized
INFO - 2023-09-22 15:34:14 --> Language Class Initialized
INFO - 2023-09-22 15:34:14 --> Language Class Initialized
INFO - 2023-09-22 15:34:14 --> Config Class Initialized
INFO - 2023-09-22 15:34:14 --> Loader Class Initialized
INFO - 2023-09-22 15:34:14 --> Helper loaded: url_helper
INFO - 2023-09-22 15:34:14 --> Helper loaded: file_helper
INFO - 2023-09-22 15:34:14 --> Helper loaded: form_helper
INFO - 2023-09-22 15:34:14 --> Helper loaded: my_helper
INFO - 2023-09-22 15:34:14 --> Database Driver Class Initialized
INFO - 2023-09-22 15:34:14 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-22 15:34:14 --> Controller Class Initialized
DEBUG - 2023-09-22 15:34:14 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/view_mapel/views/v_view_mapel.php
DEBUG - 2023-09-22 15:34:14 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-09-22 15:34:14 --> Final output sent to browser
DEBUG - 2023-09-22 15:34:14 --> Total execution time: 0.0350
INFO - 2023-09-22 15:34:16 --> Config Class Initialized
INFO - 2023-09-22 15:34:16 --> Hooks Class Initialized
DEBUG - 2023-09-22 15:34:16 --> UTF-8 Support Enabled
INFO - 2023-09-22 15:34:16 --> Utf8 Class Initialized
INFO - 2023-09-22 15:34:16 --> URI Class Initialized
INFO - 2023-09-22 15:34:16 --> Router Class Initialized
INFO - 2023-09-22 15:34:16 --> Output Class Initialized
INFO - 2023-09-22 15:34:16 --> Security Class Initialized
DEBUG - 2023-09-22 15:34:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-22 15:34:16 --> Input Class Initialized
INFO - 2023-09-22 15:34:16 --> Language Class Initialized
INFO - 2023-09-22 15:34:16 --> Language Class Initialized
INFO - 2023-09-22 15:34:16 --> Config Class Initialized
INFO - 2023-09-22 15:34:16 --> Loader Class Initialized
INFO - 2023-09-22 15:34:16 --> Helper loaded: url_helper
INFO - 2023-09-22 15:34:16 --> Helper loaded: file_helper
INFO - 2023-09-22 15:34:16 --> Helper loaded: form_helper
INFO - 2023-09-22 15:34:16 --> Helper loaded: my_helper
INFO - 2023-09-22 15:34:16 --> Database Driver Class Initialized
INFO - 2023-09-22 15:34:16 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-22 15:34:16 --> Controller Class Initialized
DEBUG - 2023-09-22 15:34:16 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/views/list.php
DEBUG - 2023-09-22 15:34:16 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-09-22 15:34:16 --> Final output sent to browser
DEBUG - 2023-09-22 15:34:16 --> Total execution time: 0.0412
INFO - 2023-09-22 15:34:16 --> Config Class Initialized
INFO - 2023-09-22 15:34:16 --> Hooks Class Initialized
DEBUG - 2023-09-22 15:34:16 --> UTF-8 Support Enabled
INFO - 2023-09-22 15:34:16 --> Utf8 Class Initialized
INFO - 2023-09-22 15:34:16 --> URI Class Initialized
INFO - 2023-09-22 15:34:16 --> Router Class Initialized
INFO - 2023-09-22 15:34:16 --> Output Class Initialized
INFO - 2023-09-22 15:34:16 --> Security Class Initialized
DEBUG - 2023-09-22 15:34:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-22 15:34:16 --> Input Class Initialized
INFO - 2023-09-22 15:34:16 --> Language Class Initialized
INFO - 2023-09-22 15:34:16 --> Language Class Initialized
INFO - 2023-09-22 15:34:16 --> Config Class Initialized
INFO - 2023-09-22 15:34:16 --> Loader Class Initialized
INFO - 2023-09-22 15:34:16 --> Helper loaded: url_helper
INFO - 2023-09-22 15:34:16 --> Helper loaded: file_helper
INFO - 2023-09-22 15:34:16 --> Helper loaded: form_helper
INFO - 2023-09-22 15:34:16 --> Helper loaded: my_helper
INFO - 2023-09-22 15:34:16 --> Database Driver Class Initialized
INFO - 2023-09-22 15:34:16 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-22 15:34:16 --> Controller Class Initialized
INFO - 2023-09-22 15:34:21 --> Config Class Initialized
INFO - 2023-09-22 15:34:21 --> Hooks Class Initialized
DEBUG - 2023-09-22 15:34:21 --> UTF-8 Support Enabled
INFO - 2023-09-22 15:34:21 --> Utf8 Class Initialized
INFO - 2023-09-22 15:34:21 --> URI Class Initialized
INFO - 2023-09-22 15:34:21 --> Router Class Initialized
INFO - 2023-09-22 15:34:21 --> Output Class Initialized
INFO - 2023-09-22 15:34:21 --> Security Class Initialized
DEBUG - 2023-09-22 15:34:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-22 15:34:21 --> Input Class Initialized
INFO - 2023-09-22 15:34:21 --> Language Class Initialized
INFO - 2023-09-22 15:34:21 --> Language Class Initialized
INFO - 2023-09-22 15:34:21 --> Config Class Initialized
INFO - 2023-09-22 15:34:21 --> Loader Class Initialized
INFO - 2023-09-22 15:34:21 --> Helper loaded: url_helper
INFO - 2023-09-22 15:34:21 --> Helper loaded: file_helper
INFO - 2023-09-22 15:34:21 --> Helper loaded: form_helper
INFO - 2023-09-22 15:34:21 --> Helper loaded: my_helper
INFO - 2023-09-22 15:34:21 --> Database Driver Class Initialized
INFO - 2023-09-22 15:34:21 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-22 15:34:21 --> Controller Class Initialized
INFO - 2023-09-22 15:34:21 --> Final output sent to browser
DEBUG - 2023-09-22 15:34:21 --> Total execution time: 0.0342
INFO - 2023-09-22 15:34:24 --> Config Class Initialized
INFO - 2023-09-22 15:34:24 --> Hooks Class Initialized
DEBUG - 2023-09-22 15:34:24 --> UTF-8 Support Enabled
INFO - 2023-09-22 15:34:24 --> Utf8 Class Initialized
INFO - 2023-09-22 15:34:24 --> URI Class Initialized
INFO - 2023-09-22 15:34:24 --> Router Class Initialized
INFO - 2023-09-22 15:34:24 --> Output Class Initialized
INFO - 2023-09-22 15:34:24 --> Security Class Initialized
DEBUG - 2023-09-22 15:34:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-22 15:34:24 --> Input Class Initialized
INFO - 2023-09-22 15:34:24 --> Language Class Initialized
INFO - 2023-09-22 15:34:24 --> Language Class Initialized
INFO - 2023-09-22 15:34:24 --> Config Class Initialized
INFO - 2023-09-22 15:34:24 --> Loader Class Initialized
INFO - 2023-09-22 15:34:24 --> Helper loaded: url_helper
INFO - 2023-09-22 15:34:24 --> Helper loaded: file_helper
INFO - 2023-09-22 15:34:24 --> Helper loaded: form_helper
INFO - 2023-09-22 15:34:24 --> Helper loaded: my_helper
INFO - 2023-09-22 15:34:24 --> Database Driver Class Initialized
INFO - 2023-09-22 15:34:24 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-22 15:34:24 --> Controller Class Initialized
INFO - 2023-09-22 15:34:24 --> Final output sent to browser
DEBUG - 2023-09-22 15:34:24 --> Total execution time: 0.0385
INFO - 2023-09-22 15:34:24 --> Config Class Initialized
INFO - 2023-09-22 15:34:24 --> Hooks Class Initialized
DEBUG - 2023-09-22 15:34:24 --> UTF-8 Support Enabled
INFO - 2023-09-22 15:34:24 --> Utf8 Class Initialized
INFO - 2023-09-22 15:34:24 --> URI Class Initialized
INFO - 2023-09-22 15:34:24 --> Router Class Initialized
INFO - 2023-09-22 15:34:24 --> Output Class Initialized
INFO - 2023-09-22 15:34:24 --> Security Class Initialized
DEBUG - 2023-09-22 15:34:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-22 15:34:24 --> Input Class Initialized
INFO - 2023-09-22 15:34:24 --> Language Class Initialized
INFO - 2023-09-22 15:34:24 --> Language Class Initialized
INFO - 2023-09-22 15:34:24 --> Config Class Initialized
INFO - 2023-09-22 15:34:24 --> Loader Class Initialized
INFO - 2023-09-22 15:34:24 --> Helper loaded: url_helper
INFO - 2023-09-22 15:34:24 --> Helper loaded: file_helper
INFO - 2023-09-22 15:34:24 --> Helper loaded: form_helper
INFO - 2023-09-22 15:34:24 --> Helper loaded: my_helper
INFO - 2023-09-22 15:34:24 --> Database Driver Class Initialized
INFO - 2023-09-22 15:34:24 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-22 15:34:24 --> Controller Class Initialized
INFO - 2023-09-22 15:34:24 --> Final output sent to browser
DEBUG - 2023-09-22 15:34:24 --> Total execution time: 0.0421
INFO - 2023-09-22 15:34:25 --> Config Class Initialized
INFO - 2023-09-22 15:34:25 --> Hooks Class Initialized
DEBUG - 2023-09-22 15:34:25 --> UTF-8 Support Enabled
INFO - 2023-09-22 15:34:25 --> Utf8 Class Initialized
INFO - 2023-09-22 15:34:25 --> URI Class Initialized
INFO - 2023-09-22 15:34:25 --> Router Class Initialized
INFO - 2023-09-22 15:34:25 --> Output Class Initialized
INFO - 2023-09-22 15:34:25 --> Security Class Initialized
DEBUG - 2023-09-22 15:34:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-22 15:34:25 --> Input Class Initialized
INFO - 2023-09-22 15:34:25 --> Language Class Initialized
INFO - 2023-09-22 15:34:25 --> Language Class Initialized
INFO - 2023-09-22 15:34:25 --> Config Class Initialized
INFO - 2023-09-22 15:34:25 --> Loader Class Initialized
INFO - 2023-09-22 15:34:25 --> Helper loaded: url_helper
INFO - 2023-09-22 15:34:25 --> Helper loaded: file_helper
INFO - 2023-09-22 15:34:25 --> Helper loaded: form_helper
INFO - 2023-09-22 15:34:25 --> Helper loaded: my_helper
INFO - 2023-09-22 15:34:25 --> Database Driver Class Initialized
INFO - 2023-09-22 15:34:25 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-22 15:34:25 --> Controller Class Initialized
INFO - 2023-09-22 15:34:25 --> Final output sent to browser
DEBUG - 2023-09-22 15:34:25 --> Total execution time: 0.0637
INFO - 2023-09-22 15:55:19 --> Config Class Initialized
INFO - 2023-09-22 15:55:19 --> Hooks Class Initialized
DEBUG - 2023-09-22 15:55:19 --> UTF-8 Support Enabled
INFO - 2023-09-22 15:55:19 --> Utf8 Class Initialized
INFO - 2023-09-22 15:55:19 --> URI Class Initialized
INFO - 2023-09-22 15:55:19 --> Router Class Initialized
INFO - 2023-09-22 15:55:19 --> Output Class Initialized
INFO - 2023-09-22 15:55:19 --> Security Class Initialized
DEBUG - 2023-09-22 15:55:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-22 15:55:19 --> Input Class Initialized
INFO - 2023-09-22 15:55:19 --> Language Class Initialized
INFO - 2023-09-22 15:55:19 --> Language Class Initialized
INFO - 2023-09-22 15:55:19 --> Config Class Initialized
INFO - 2023-09-22 15:55:19 --> Loader Class Initialized
INFO - 2023-09-22 15:55:19 --> Helper loaded: url_helper
INFO - 2023-09-22 15:55:19 --> Helper loaded: file_helper
INFO - 2023-09-22 15:55:19 --> Helper loaded: form_helper
INFO - 2023-09-22 15:55:19 --> Helper loaded: my_helper
INFO - 2023-09-22 15:55:19 --> Database Driver Class Initialized
INFO - 2023-09-22 15:55:19 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-22 15:55:19 --> Controller Class Initialized
DEBUG - 2023-09-22 15:55:19 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/views/list.php
DEBUG - 2023-09-22 15:55:19 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-09-22 15:55:19 --> Final output sent to browser
DEBUG - 2023-09-22 15:55:19 --> Total execution time: 0.0487
INFO - 2023-09-22 15:55:21 --> Config Class Initialized
INFO - 2023-09-22 15:55:21 --> Hooks Class Initialized
DEBUG - 2023-09-22 15:55:21 --> UTF-8 Support Enabled
INFO - 2023-09-22 15:55:21 --> Utf8 Class Initialized
INFO - 2023-09-22 15:55:21 --> URI Class Initialized
INFO - 2023-09-22 15:55:21 --> Router Class Initialized
INFO - 2023-09-22 15:55:21 --> Output Class Initialized
INFO - 2023-09-22 15:55:21 --> Security Class Initialized
DEBUG - 2023-09-22 15:55:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-22 15:55:21 --> Input Class Initialized
INFO - 2023-09-22 15:55:21 --> Language Class Initialized
INFO - 2023-09-22 15:55:21 --> Language Class Initialized
INFO - 2023-09-22 15:55:21 --> Config Class Initialized
INFO - 2023-09-22 15:55:21 --> Loader Class Initialized
INFO - 2023-09-22 15:55:21 --> Helper loaded: url_helper
INFO - 2023-09-22 15:55:21 --> Helper loaded: file_helper
INFO - 2023-09-22 15:55:21 --> Helper loaded: form_helper
INFO - 2023-09-22 15:55:21 --> Helper loaded: my_helper
INFO - 2023-09-22 15:55:21 --> Database Driver Class Initialized
INFO - 2023-09-22 15:55:21 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-22 15:55:21 --> Controller Class Initialized
INFO - 2023-09-22 16:11:29 --> Config Class Initialized
INFO - 2023-09-22 16:11:29 --> Hooks Class Initialized
DEBUG - 2023-09-22 16:11:29 --> UTF-8 Support Enabled
INFO - 2023-09-22 16:11:29 --> Utf8 Class Initialized
INFO - 2023-09-22 16:11:29 --> URI Class Initialized
DEBUG - 2023-09-22 16:11:29 --> No URI present. Default controller set.
INFO - 2023-09-22 16:11:29 --> Router Class Initialized
INFO - 2023-09-22 16:11:29 --> Output Class Initialized
INFO - 2023-09-22 16:11:29 --> Security Class Initialized
DEBUG - 2023-09-22 16:11:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-22 16:11:29 --> Input Class Initialized
INFO - 2023-09-22 16:11:29 --> Language Class Initialized
INFO - 2023-09-22 16:11:29 --> Language Class Initialized
INFO - 2023-09-22 16:11:29 --> Config Class Initialized
INFO - 2023-09-22 16:11:29 --> Loader Class Initialized
INFO - 2023-09-22 16:11:29 --> Helper loaded: url_helper
INFO - 2023-09-22 16:11:29 --> Helper loaded: file_helper
INFO - 2023-09-22 16:11:29 --> Helper loaded: form_helper
INFO - 2023-09-22 16:11:29 --> Helper loaded: my_helper
INFO - 2023-09-22 16:11:29 --> Database Driver Class Initialized
INFO - 2023-09-22 16:11:29 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-22 16:11:29 --> Controller Class Initialized
DEBUG - 2023-09-22 16:11:29 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/home/views/v_home_guru.php
DEBUG - 2023-09-22 16:11:29 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-09-22 16:11:29 --> Final output sent to browser
DEBUG - 2023-09-22 16:11:29 --> Total execution time: 0.0556
INFO - 2023-09-22 16:11:36 --> Config Class Initialized
INFO - 2023-09-22 16:11:36 --> Hooks Class Initialized
DEBUG - 2023-09-22 16:11:36 --> UTF-8 Support Enabled
INFO - 2023-09-22 16:11:36 --> Utf8 Class Initialized
INFO - 2023-09-22 16:11:36 --> URI Class Initialized
INFO - 2023-09-22 16:11:36 --> Router Class Initialized
INFO - 2023-09-22 16:11:36 --> Output Class Initialized
INFO - 2023-09-22 16:11:36 --> Security Class Initialized
DEBUG - 2023-09-22 16:11:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-22 16:11:36 --> Input Class Initialized
INFO - 2023-09-22 16:11:36 --> Language Class Initialized
INFO - 2023-09-22 16:11:36 --> Language Class Initialized
INFO - 2023-09-22 16:11:36 --> Config Class Initialized
INFO - 2023-09-22 16:11:36 --> Loader Class Initialized
INFO - 2023-09-22 16:11:36 --> Helper loaded: url_helper
INFO - 2023-09-22 16:11:36 --> Helper loaded: file_helper
INFO - 2023-09-22 16:11:36 --> Helper loaded: form_helper
INFO - 2023-09-22 16:11:36 --> Helper loaded: my_helper
INFO - 2023-09-22 16:11:36 --> Database Driver Class Initialized
INFO - 2023-09-22 16:11:36 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-22 16:11:36 --> Controller Class Initialized
DEBUG - 2023-09-22 16:11:36 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/view_mapel/views/v_view_mapel.php
DEBUG - 2023-09-22 16:11:36 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-09-22 16:11:36 --> Final output sent to browser
DEBUG - 2023-09-22 16:11:36 --> Total execution time: 0.0375
INFO - 2023-09-22 16:11:37 --> Config Class Initialized
INFO - 2023-09-22 16:11:37 --> Hooks Class Initialized
DEBUG - 2023-09-22 16:11:37 --> UTF-8 Support Enabled
INFO - 2023-09-22 16:11:37 --> Utf8 Class Initialized
INFO - 2023-09-22 16:11:37 --> URI Class Initialized
DEBUG - 2023-09-22 16:11:37 --> No URI present. Default controller set.
INFO - 2023-09-22 16:11:37 --> Router Class Initialized
INFO - 2023-09-22 16:11:37 --> Output Class Initialized
INFO - 2023-09-22 16:11:37 --> Security Class Initialized
DEBUG - 2023-09-22 16:11:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-22 16:11:37 --> Input Class Initialized
INFO - 2023-09-22 16:11:37 --> Language Class Initialized
INFO - 2023-09-22 16:11:37 --> Language Class Initialized
INFO - 2023-09-22 16:11:37 --> Config Class Initialized
INFO - 2023-09-22 16:11:37 --> Loader Class Initialized
INFO - 2023-09-22 16:11:37 --> Helper loaded: url_helper
INFO - 2023-09-22 16:11:37 --> Helper loaded: file_helper
INFO - 2023-09-22 16:11:37 --> Helper loaded: form_helper
INFO - 2023-09-22 16:11:37 --> Helper loaded: my_helper
INFO - 2023-09-22 16:11:37 --> Database Driver Class Initialized
INFO - 2023-09-22 16:11:37 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-22 16:11:37 --> Controller Class Initialized
DEBUG - 2023-09-22 16:11:37 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/home/views/v_home_guru.php
DEBUG - 2023-09-22 16:11:37 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-09-22 16:11:37 --> Final output sent to browser
DEBUG - 2023-09-22 16:11:37 --> Total execution time: 0.0394
INFO - 2023-09-22 16:43:38 --> Config Class Initialized
INFO - 2023-09-22 16:43:38 --> Hooks Class Initialized
DEBUG - 2023-09-22 16:43:38 --> UTF-8 Support Enabled
INFO - 2023-09-22 16:43:38 --> Utf8 Class Initialized
INFO - 2023-09-22 16:43:38 --> URI Class Initialized
DEBUG - 2023-09-22 16:43:38 --> No URI present. Default controller set.
INFO - 2023-09-22 16:43:38 --> Router Class Initialized
INFO - 2023-09-22 16:43:38 --> Output Class Initialized
INFO - 2023-09-22 16:43:38 --> Security Class Initialized
DEBUG - 2023-09-22 16:43:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-22 16:43:38 --> Input Class Initialized
INFO - 2023-09-22 16:43:38 --> Language Class Initialized
INFO - 2023-09-22 16:43:38 --> Language Class Initialized
INFO - 2023-09-22 16:43:38 --> Config Class Initialized
INFO - 2023-09-22 16:43:38 --> Loader Class Initialized
INFO - 2023-09-22 16:43:38 --> Helper loaded: url_helper
INFO - 2023-09-22 16:43:38 --> Helper loaded: file_helper
INFO - 2023-09-22 16:43:38 --> Helper loaded: form_helper
INFO - 2023-09-22 16:43:38 --> Helper loaded: my_helper
INFO - 2023-09-22 16:43:38 --> Database Driver Class Initialized
INFO - 2023-09-22 16:43:39 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-22 16:43:39 --> Controller Class Initialized
DEBUG - 2023-09-22 16:43:39 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/home/views/v_home_guru.php
DEBUG - 2023-09-22 16:43:39 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-09-22 16:43:39 --> Final output sent to browser
DEBUG - 2023-09-22 16:43:39 --> Total execution time: 0.0539
INFO - 2023-09-22 16:58:28 --> Config Class Initialized
INFO - 2023-09-22 16:58:28 --> Hooks Class Initialized
DEBUG - 2023-09-22 16:58:28 --> UTF-8 Support Enabled
INFO - 2023-09-22 16:58:28 --> Utf8 Class Initialized
INFO - 2023-09-22 16:58:28 --> URI Class Initialized
INFO - 2023-09-22 16:58:28 --> Router Class Initialized
INFO - 2023-09-22 16:58:28 --> Output Class Initialized
INFO - 2023-09-22 16:58:28 --> Security Class Initialized
DEBUG - 2023-09-22 16:58:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-22 16:58:28 --> Input Class Initialized
INFO - 2023-09-22 16:58:28 --> Language Class Initialized
INFO - 2023-09-22 16:58:28 --> Language Class Initialized
INFO - 2023-09-22 16:58:28 --> Config Class Initialized
INFO - 2023-09-22 16:58:28 --> Loader Class Initialized
INFO - 2023-09-22 16:58:28 --> Helper loaded: url_helper
INFO - 2023-09-22 16:58:28 --> Helper loaded: file_helper
INFO - 2023-09-22 16:58:28 --> Helper loaded: form_helper
INFO - 2023-09-22 16:58:28 --> Helper loaded: my_helper
INFO - 2023-09-22 16:58:28 --> Database Driver Class Initialized
INFO - 2023-09-22 16:58:28 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-22 16:58:28 --> Controller Class Initialized
DEBUG - 2023-09-22 16:58:28 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_catatan_guru/views/list.php
DEBUG - 2023-09-22 16:58:28 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-09-22 16:58:28 --> Final output sent to browser
DEBUG - 2023-09-22 16:58:28 --> Total execution time: 0.1990
INFO - 2023-09-22 17:08:31 --> Config Class Initialized
INFO - 2023-09-22 17:08:31 --> Hooks Class Initialized
DEBUG - 2023-09-22 17:08:31 --> UTF-8 Support Enabled
INFO - 2023-09-22 17:08:31 --> Utf8 Class Initialized
INFO - 2023-09-22 17:08:31 --> URI Class Initialized
INFO - 2023-09-22 17:08:31 --> Router Class Initialized
INFO - 2023-09-22 17:08:31 --> Output Class Initialized
INFO - 2023-09-22 17:08:31 --> Security Class Initialized
DEBUG - 2023-09-22 17:08:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-22 17:08:31 --> Input Class Initialized
INFO - 2023-09-22 17:08:31 --> Language Class Initialized
INFO - 2023-09-22 17:08:31 --> Language Class Initialized
INFO - 2023-09-22 17:08:31 --> Config Class Initialized
INFO - 2023-09-22 17:08:31 --> Loader Class Initialized
INFO - 2023-09-22 17:08:31 --> Helper loaded: url_helper
INFO - 2023-09-22 17:08:31 --> Helper loaded: file_helper
INFO - 2023-09-22 17:08:31 --> Helper loaded: form_helper
INFO - 2023-09-22 17:08:31 --> Helper loaded: my_helper
INFO - 2023-09-22 17:08:31 --> Database Driver Class Initialized
INFO - 2023-09-22 17:08:31 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-22 17:08:31 --> Controller Class Initialized
ERROR - 2023-09-22 17:08:31 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php 110
DEBUG - 2023-09-22 17:08:31 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php
ERROR - 2023-09-22 17:08:32 --> Severity: error --> Exception: Unable to get the size of the image [C:\Users\sallu\Downloads\Logo MH Transparan-01.png] /www/wwwroot/report.mhis.link/bangka/secondary/aset/html2pdf/spipu/html2pdf/src/Html2Pdf.php 1513
INFO - 2023-09-22 17:08:37 --> Config Class Initialized
INFO - 2023-09-22 17:08:37 --> Hooks Class Initialized
DEBUG - 2023-09-22 17:08:37 --> UTF-8 Support Enabled
INFO - 2023-09-22 17:08:37 --> Utf8 Class Initialized
INFO - 2023-09-22 17:08:37 --> URI Class Initialized
DEBUG - 2023-09-22 17:08:37 --> No URI present. Default controller set.
INFO - 2023-09-22 17:08:37 --> Router Class Initialized
INFO - 2023-09-22 17:08:37 --> Output Class Initialized
INFO - 2023-09-22 17:08:37 --> Security Class Initialized
DEBUG - 2023-09-22 17:08:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-22 17:08:37 --> Input Class Initialized
INFO - 2023-09-22 17:08:37 --> Language Class Initialized
INFO - 2023-09-22 17:08:37 --> Language Class Initialized
INFO - 2023-09-22 17:08:37 --> Config Class Initialized
INFO - 2023-09-22 17:08:37 --> Loader Class Initialized
INFO - 2023-09-22 17:08:37 --> Helper loaded: url_helper
INFO - 2023-09-22 17:08:37 --> Helper loaded: file_helper
INFO - 2023-09-22 17:08:37 --> Helper loaded: form_helper
INFO - 2023-09-22 17:08:37 --> Helper loaded: my_helper
INFO - 2023-09-22 17:08:37 --> Database Driver Class Initialized
INFO - 2023-09-22 17:08:37 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-22 17:08:37 --> Controller Class Initialized
DEBUG - 2023-09-22 17:08:37 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/home/views/v_home_guru.php
DEBUG - 2023-09-22 17:08:37 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-09-22 17:08:37 --> Final output sent to browser
DEBUG - 2023-09-22 17:08:37 --> Total execution time: 0.0760
