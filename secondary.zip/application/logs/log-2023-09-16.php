<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2023-09-16 09:34:30 --> Config Class Initialized
INFO - 2023-09-16 09:34:30 --> Hooks Class Initialized
DEBUG - 2023-09-16 09:34:30 --> UTF-8 Support Enabled
INFO - 2023-09-16 09:34:30 --> Utf8 Class Initialized
INFO - 2023-09-16 09:34:30 --> URI Class Initialized
DEBUG - 2023-09-16 09:34:30 --> No URI present. Default controller set.
INFO - 2023-09-16 09:34:30 --> Router Class Initialized
INFO - 2023-09-16 09:34:30 --> Output Class Initialized
INFO - 2023-09-16 09:34:30 --> Security Class Initialized
DEBUG - 2023-09-16 09:34:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-16 09:34:30 --> Input Class Initialized
INFO - 2023-09-16 09:34:30 --> Language Class Initialized
INFO - 2023-09-16 09:34:30 --> Language Class Initialized
INFO - 2023-09-16 09:34:30 --> Config Class Initialized
INFO - 2023-09-16 09:34:30 --> Loader Class Initialized
INFO - 2023-09-16 09:34:30 --> Helper loaded: url_helper
INFO - 2023-09-16 09:34:30 --> Helper loaded: file_helper
INFO - 2023-09-16 09:34:30 --> Helper loaded: form_helper
INFO - 2023-09-16 09:34:30 --> Helper loaded: my_helper
INFO - 2023-09-16 09:34:30 --> Database Driver Class Initialized
INFO - 2023-09-16 09:34:30 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-16 09:34:30 --> Controller Class Initialized
DEBUG - 2023-09-16 09:34:30 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/home/views/v_home_guru.php
DEBUG - 2023-09-16 09:34:30 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-09-16 09:34:30 --> Final output sent to browser
DEBUG - 2023-09-16 09:34:30 --> Total execution time: 0.1068
INFO - 2023-09-16 09:34:40 --> Config Class Initialized
INFO - 2023-09-16 09:34:40 --> Hooks Class Initialized
DEBUG - 2023-09-16 09:34:40 --> UTF-8 Support Enabled
INFO - 2023-09-16 09:34:40 --> Utf8 Class Initialized
INFO - 2023-09-16 09:34:40 --> URI Class Initialized
INFO - 2023-09-16 09:34:40 --> Router Class Initialized
INFO - 2023-09-16 09:34:40 --> Output Class Initialized
INFO - 2023-09-16 09:34:40 --> Security Class Initialized
DEBUG - 2023-09-16 09:34:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-16 09:34:40 --> Input Class Initialized
INFO - 2023-09-16 09:34:40 --> Language Class Initialized
INFO - 2023-09-16 09:34:40 --> Language Class Initialized
INFO - 2023-09-16 09:34:40 --> Config Class Initialized
INFO - 2023-09-16 09:34:40 --> Loader Class Initialized
INFO - 2023-09-16 09:34:40 --> Helper loaded: url_helper
INFO - 2023-09-16 09:34:40 --> Helper loaded: file_helper
INFO - 2023-09-16 09:34:40 --> Helper loaded: form_helper
INFO - 2023-09-16 09:34:40 --> Helper loaded: my_helper
INFO - 2023-09-16 09:34:40 --> Database Driver Class Initialized
INFO - 2023-09-16 09:34:40 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-16 09:34:40 --> Controller Class Initialized
DEBUG - 2023-09-16 09:34:40 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/view_mapel/views/v_view_mapel.php
DEBUG - 2023-09-16 09:34:40 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-09-16 09:34:40 --> Final output sent to browser
DEBUG - 2023-09-16 09:34:40 --> Total execution time: 0.0605
INFO - 2023-09-16 09:34:51 --> Config Class Initialized
INFO - 2023-09-16 09:34:51 --> Hooks Class Initialized
DEBUG - 2023-09-16 09:34:51 --> UTF-8 Support Enabled
INFO - 2023-09-16 09:34:51 --> Utf8 Class Initialized
INFO - 2023-09-16 09:34:51 --> URI Class Initialized
INFO - 2023-09-16 09:34:51 --> Router Class Initialized
INFO - 2023-09-16 09:34:51 --> Output Class Initialized
INFO - 2023-09-16 09:34:51 --> Security Class Initialized
DEBUG - 2023-09-16 09:34:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-16 09:34:51 --> Input Class Initialized
INFO - 2023-09-16 09:34:51 --> Language Class Initialized
INFO - 2023-09-16 09:34:51 --> Language Class Initialized
INFO - 2023-09-16 09:34:51 --> Config Class Initialized
INFO - 2023-09-16 09:34:51 --> Loader Class Initialized
INFO - 2023-09-16 09:34:51 --> Helper loaded: url_helper
INFO - 2023-09-16 09:34:51 --> Helper loaded: file_helper
INFO - 2023-09-16 09:34:51 --> Helper loaded: form_helper
INFO - 2023-09-16 09:34:51 --> Helper loaded: my_helper
INFO - 2023-09-16 09:34:51 --> Database Driver Class Initialized
INFO - 2023-09-16 09:34:51 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-16 09:34:51 --> Controller Class Initialized
DEBUG - 2023-09-16 09:34:51 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/view_mapel/views/v_view_mapel.php
DEBUG - 2023-09-16 09:34:51 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-09-16 09:34:51 --> Final output sent to browser
DEBUG - 2023-09-16 09:34:51 --> Total execution time: 0.0417
INFO - 2023-09-16 09:34:52 --> Config Class Initialized
INFO - 2023-09-16 09:34:52 --> Hooks Class Initialized
DEBUG - 2023-09-16 09:34:52 --> UTF-8 Support Enabled
INFO - 2023-09-16 09:34:52 --> Utf8 Class Initialized
INFO - 2023-09-16 09:34:52 --> URI Class Initialized
DEBUG - 2023-09-16 09:34:52 --> No URI present. Default controller set.
INFO - 2023-09-16 09:34:52 --> Router Class Initialized
INFO - 2023-09-16 09:34:52 --> Output Class Initialized
INFO - 2023-09-16 09:34:52 --> Security Class Initialized
DEBUG - 2023-09-16 09:34:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-16 09:34:52 --> Input Class Initialized
INFO - 2023-09-16 09:34:52 --> Language Class Initialized
INFO - 2023-09-16 09:34:53 --> Language Class Initialized
INFO - 2023-09-16 09:34:53 --> Config Class Initialized
INFO - 2023-09-16 09:34:53 --> Loader Class Initialized
INFO - 2023-09-16 09:34:53 --> Helper loaded: url_helper
INFO - 2023-09-16 09:34:53 --> Helper loaded: file_helper
INFO - 2023-09-16 09:34:53 --> Helper loaded: form_helper
INFO - 2023-09-16 09:34:53 --> Helper loaded: my_helper
INFO - 2023-09-16 09:34:53 --> Database Driver Class Initialized
INFO - 2023-09-16 09:34:53 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-16 09:34:53 --> Controller Class Initialized
DEBUG - 2023-09-16 09:34:53 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/home/views/v_home_guru.php
DEBUG - 2023-09-16 09:34:53 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-09-16 09:34:53 --> Final output sent to browser
DEBUG - 2023-09-16 09:34:53 --> Total execution time: 0.0998
INFO - 2023-09-16 09:34:56 --> Config Class Initialized
INFO - 2023-09-16 09:34:56 --> Hooks Class Initialized
DEBUG - 2023-09-16 09:34:56 --> UTF-8 Support Enabled
INFO - 2023-09-16 09:34:56 --> Utf8 Class Initialized
INFO - 2023-09-16 09:34:56 --> URI Class Initialized
DEBUG - 2023-09-16 09:34:56 --> No URI present. Default controller set.
INFO - 2023-09-16 09:34:56 --> Router Class Initialized
INFO - 2023-09-16 09:34:56 --> Output Class Initialized
INFO - 2023-09-16 09:34:56 --> Security Class Initialized
DEBUG - 2023-09-16 09:34:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-16 09:34:56 --> Input Class Initialized
INFO - 2023-09-16 09:34:56 --> Language Class Initialized
INFO - 2023-09-16 09:34:56 --> Language Class Initialized
INFO - 2023-09-16 09:34:56 --> Config Class Initialized
INFO - 2023-09-16 09:34:56 --> Loader Class Initialized
INFO - 2023-09-16 09:34:56 --> Helper loaded: url_helper
INFO - 2023-09-16 09:34:56 --> Helper loaded: file_helper
INFO - 2023-09-16 09:34:56 --> Helper loaded: form_helper
INFO - 2023-09-16 09:34:56 --> Helper loaded: my_helper
INFO - 2023-09-16 09:34:56 --> Database Driver Class Initialized
INFO - 2023-09-16 09:34:56 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-16 09:34:56 --> Controller Class Initialized
DEBUG - 2023-09-16 09:34:56 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/home/views/v_home_guru.php
DEBUG - 2023-09-16 09:34:56 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-09-16 09:34:56 --> Final output sent to browser
DEBUG - 2023-09-16 09:34:56 --> Total execution time: 0.1050
INFO - 2023-09-16 09:34:58 --> Config Class Initialized
INFO - 2023-09-16 09:34:58 --> Hooks Class Initialized
DEBUG - 2023-09-16 09:34:58 --> UTF-8 Support Enabled
INFO - 2023-09-16 09:34:58 --> Utf8 Class Initialized
INFO - 2023-09-16 09:34:58 --> URI Class Initialized
INFO - 2023-09-16 09:34:58 --> Router Class Initialized
INFO - 2023-09-16 09:34:58 --> Output Class Initialized
INFO - 2023-09-16 09:34:58 --> Security Class Initialized
DEBUG - 2023-09-16 09:34:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-16 09:34:58 --> Input Class Initialized
INFO - 2023-09-16 09:34:58 --> Language Class Initialized
INFO - 2023-09-16 09:34:58 --> Language Class Initialized
INFO - 2023-09-16 09:34:58 --> Config Class Initialized
INFO - 2023-09-16 09:34:58 --> Loader Class Initialized
INFO - 2023-09-16 09:34:58 --> Helper loaded: url_helper
INFO - 2023-09-16 09:34:58 --> Helper loaded: file_helper
INFO - 2023-09-16 09:34:58 --> Helper loaded: form_helper
INFO - 2023-09-16 09:34:58 --> Helper loaded: my_helper
INFO - 2023-09-16 09:34:58 --> Database Driver Class Initialized
INFO - 2023-09-16 09:34:58 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-16 09:34:58 --> Controller Class Initialized
DEBUG - 2023-09-16 09:34:58 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/view_mapel/views/v_view_mapel.php
DEBUG - 2023-09-16 09:34:58 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-09-16 09:34:58 --> Final output sent to browser
DEBUG - 2023-09-16 09:34:58 --> Total execution time: 0.0310
INFO - 2023-09-16 09:35:11 --> Config Class Initialized
INFO - 2023-09-16 09:35:11 --> Hooks Class Initialized
DEBUG - 2023-09-16 09:35:11 --> UTF-8 Support Enabled
INFO - 2023-09-16 09:35:11 --> Utf8 Class Initialized
INFO - 2023-09-16 09:35:11 --> URI Class Initialized
INFO - 2023-09-16 09:35:11 --> Router Class Initialized
INFO - 2023-09-16 09:35:11 --> Output Class Initialized
INFO - 2023-09-16 09:35:11 --> Security Class Initialized
DEBUG - 2023-09-16 09:35:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-16 09:35:11 --> Input Class Initialized
INFO - 2023-09-16 09:35:11 --> Language Class Initialized
INFO - 2023-09-16 09:35:11 --> Language Class Initialized
INFO - 2023-09-16 09:35:11 --> Config Class Initialized
INFO - 2023-09-16 09:35:11 --> Loader Class Initialized
INFO - 2023-09-16 09:35:11 --> Helper loaded: url_helper
INFO - 2023-09-16 09:35:11 --> Helper loaded: file_helper
INFO - 2023-09-16 09:35:11 --> Helper loaded: form_helper
INFO - 2023-09-16 09:35:11 --> Helper loaded: my_helper
INFO - 2023-09-16 09:35:11 --> Database Driver Class Initialized
INFO - 2023-09-16 09:35:11 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-16 09:35:11 --> Controller Class Initialized
DEBUG - 2023-09-16 09:35:11 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/view_mapel/views/v_view_mapel.php
DEBUG - 2023-09-16 09:35:11 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-09-16 09:35:11 --> Final output sent to browser
DEBUG - 2023-09-16 09:35:11 --> Total execution time: 0.2544
INFO - 2023-09-16 09:35:14 --> Config Class Initialized
INFO - 2023-09-16 09:35:14 --> Hooks Class Initialized
DEBUG - 2023-09-16 09:35:14 --> UTF-8 Support Enabled
INFO - 2023-09-16 09:35:14 --> Utf8 Class Initialized
INFO - 2023-09-16 09:35:14 --> URI Class Initialized
DEBUG - 2023-09-16 09:35:14 --> No URI present. Default controller set.
INFO - 2023-09-16 09:35:14 --> Router Class Initialized
INFO - 2023-09-16 09:35:14 --> Output Class Initialized
INFO - 2023-09-16 09:35:14 --> Security Class Initialized
DEBUG - 2023-09-16 09:35:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-16 09:35:14 --> Input Class Initialized
INFO - 2023-09-16 09:35:14 --> Language Class Initialized
INFO - 2023-09-16 09:35:14 --> Language Class Initialized
INFO - 2023-09-16 09:35:14 --> Config Class Initialized
INFO - 2023-09-16 09:35:14 --> Loader Class Initialized
INFO - 2023-09-16 09:35:14 --> Helper loaded: url_helper
INFO - 2023-09-16 09:35:14 --> Helper loaded: file_helper
INFO - 2023-09-16 09:35:14 --> Helper loaded: form_helper
INFO - 2023-09-16 09:35:14 --> Helper loaded: my_helper
INFO - 2023-09-16 09:35:14 --> Database Driver Class Initialized
INFO - 2023-09-16 09:35:14 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-16 09:35:14 --> Controller Class Initialized
DEBUG - 2023-09-16 09:35:14 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/home/views/v_home_guru.php
DEBUG - 2023-09-16 09:35:14 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-09-16 09:35:14 --> Final output sent to browser
DEBUG - 2023-09-16 09:35:14 --> Total execution time: 0.0360
INFO - 2023-09-16 09:35:18 --> Config Class Initialized
INFO - 2023-09-16 09:35:18 --> Hooks Class Initialized
DEBUG - 2023-09-16 09:35:18 --> UTF-8 Support Enabled
INFO - 2023-09-16 09:35:18 --> Utf8 Class Initialized
INFO - 2023-09-16 09:35:18 --> URI Class Initialized
DEBUG - 2023-09-16 09:35:18 --> No URI present. Default controller set.
INFO - 2023-09-16 09:35:18 --> Router Class Initialized
INFO - 2023-09-16 09:35:18 --> Output Class Initialized
INFO - 2023-09-16 09:35:18 --> Security Class Initialized
DEBUG - 2023-09-16 09:35:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-16 09:35:18 --> Input Class Initialized
INFO - 2023-09-16 09:35:18 --> Language Class Initialized
INFO - 2023-09-16 09:35:18 --> Language Class Initialized
INFO - 2023-09-16 09:35:18 --> Config Class Initialized
INFO - 2023-09-16 09:35:18 --> Loader Class Initialized
INFO - 2023-09-16 09:35:18 --> Helper loaded: url_helper
INFO - 2023-09-16 09:35:18 --> Helper loaded: file_helper
INFO - 2023-09-16 09:35:18 --> Helper loaded: form_helper
INFO - 2023-09-16 09:35:18 --> Helper loaded: my_helper
INFO - 2023-09-16 09:35:18 --> Database Driver Class Initialized
INFO - 2023-09-16 09:35:18 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-16 09:35:18 --> Controller Class Initialized
DEBUG - 2023-09-16 09:35:18 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/home/views/v_home_guru.php
DEBUG - 2023-09-16 09:35:18 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-09-16 09:35:18 --> Final output sent to browser
DEBUG - 2023-09-16 09:35:18 --> Total execution time: 0.0408
INFO - 2023-09-16 09:35:44 --> Config Class Initialized
INFO - 2023-09-16 09:35:44 --> Hooks Class Initialized
DEBUG - 2023-09-16 09:35:44 --> UTF-8 Support Enabled
INFO - 2023-09-16 09:35:44 --> Utf8 Class Initialized
INFO - 2023-09-16 09:35:44 --> URI Class Initialized
DEBUG - 2023-09-16 09:35:44 --> No URI present. Default controller set.
INFO - 2023-09-16 09:35:44 --> Router Class Initialized
INFO - 2023-09-16 09:35:44 --> Output Class Initialized
INFO - 2023-09-16 09:35:44 --> Security Class Initialized
DEBUG - 2023-09-16 09:35:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-16 09:35:44 --> Input Class Initialized
INFO - 2023-09-16 09:35:44 --> Language Class Initialized
INFO - 2023-09-16 09:35:44 --> Language Class Initialized
INFO - 2023-09-16 09:35:44 --> Config Class Initialized
INFO - 2023-09-16 09:35:44 --> Loader Class Initialized
INFO - 2023-09-16 09:35:44 --> Helper loaded: url_helper
INFO - 2023-09-16 09:35:44 --> Helper loaded: file_helper
INFO - 2023-09-16 09:35:44 --> Helper loaded: form_helper
INFO - 2023-09-16 09:35:44 --> Helper loaded: my_helper
INFO - 2023-09-16 09:35:44 --> Database Driver Class Initialized
INFO - 2023-09-16 09:35:44 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-16 09:35:44 --> Controller Class Initialized
DEBUG - 2023-09-16 09:35:44 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/home/views/v_home_guru.php
DEBUG - 2023-09-16 09:35:44 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-09-16 09:35:44 --> Final output sent to browser
DEBUG - 2023-09-16 09:35:44 --> Total execution time: 0.1282
INFO - 2023-09-16 09:55:58 --> Config Class Initialized
INFO - 2023-09-16 09:55:58 --> Hooks Class Initialized
DEBUG - 2023-09-16 09:55:58 --> UTF-8 Support Enabled
INFO - 2023-09-16 09:55:58 --> Utf8 Class Initialized
INFO - 2023-09-16 09:55:58 --> URI Class Initialized
INFO - 2023-09-16 09:55:58 --> Router Class Initialized
INFO - 2023-09-16 09:55:58 --> Output Class Initialized
INFO - 2023-09-16 09:55:58 --> Security Class Initialized
DEBUG - 2023-09-16 09:55:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-16 09:55:58 --> Input Class Initialized
INFO - 2023-09-16 09:55:58 --> Language Class Initialized
INFO - 2023-09-16 09:55:58 --> Language Class Initialized
INFO - 2023-09-16 09:55:58 --> Config Class Initialized
INFO - 2023-09-16 09:55:58 --> Loader Class Initialized
INFO - 2023-09-16 09:55:58 --> Helper loaded: url_helper
INFO - 2023-09-16 09:55:58 --> Helper loaded: file_helper
INFO - 2023-09-16 09:55:58 --> Helper loaded: form_helper
INFO - 2023-09-16 09:55:58 --> Helper loaded: my_helper
INFO - 2023-09-16 09:55:58 --> Database Driver Class Initialized
INFO - 2023-09-16 09:55:58 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-16 09:55:58 --> Controller Class Initialized
DEBUG - 2023-09-16 09:55:58 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/login/views/login.php
DEBUG - 2023-09-16 09:55:58 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-09-16 09:55:58 --> Final output sent to browser
DEBUG - 2023-09-16 09:55:58 --> Total execution time: 0.1470
