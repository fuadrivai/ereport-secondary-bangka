<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2024-06-08 08:03:54 --> Config Class Initialized
INFO - 2024-06-08 08:03:54 --> Hooks Class Initialized
DEBUG - 2024-06-08 08:03:54 --> UTF-8 Support Enabled
INFO - 2024-06-08 08:03:54 --> Utf8 Class Initialized
INFO - 2024-06-08 08:03:54 --> URI Class Initialized
INFO - 2024-06-08 08:03:54 --> Router Class Initialized
INFO - 2024-06-08 08:03:54 --> Output Class Initialized
INFO - 2024-06-08 08:03:54 --> Security Class Initialized
DEBUG - 2024-06-08 08:03:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-08 08:03:54 --> Input Class Initialized
INFO - 2024-06-08 08:03:54 --> Language Class Initialized
INFO - 2024-06-08 08:03:54 --> Language Class Initialized
INFO - 2024-06-08 08:03:54 --> Config Class Initialized
INFO - 2024-06-08 08:03:54 --> Loader Class Initialized
INFO - 2024-06-08 08:03:54 --> Helper loaded: url_helper
INFO - 2024-06-08 08:03:54 --> Helper loaded: file_helper
INFO - 2024-06-08 08:03:54 --> Helper loaded: form_helper
INFO - 2024-06-08 08:03:54 --> Helper loaded: my_helper
INFO - 2024-06-08 08:03:54 --> Database Driver Class Initialized
INFO - 2024-06-08 08:03:54 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-08 08:03:54 --> Controller Class Initialized
DEBUG - 2024-06-08 08:03:54 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/views/list.php
DEBUG - 2024-06-08 08:03:54 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-06-08 08:03:54 --> Final output sent to browser
DEBUG - 2024-06-08 08:03:54 --> Total execution time: 0.0577
INFO - 2024-06-08 08:03:55 --> Config Class Initialized
INFO - 2024-06-08 08:03:55 --> Hooks Class Initialized
DEBUG - 2024-06-08 08:03:55 --> UTF-8 Support Enabled
INFO - 2024-06-08 08:03:55 --> Utf8 Class Initialized
INFO - 2024-06-08 08:03:55 --> URI Class Initialized
INFO - 2024-06-08 08:03:55 --> Router Class Initialized
INFO - 2024-06-08 08:03:55 --> Output Class Initialized
INFO - 2024-06-08 08:03:55 --> Security Class Initialized
DEBUG - 2024-06-08 08:03:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-08 08:03:55 --> Input Class Initialized
INFO - 2024-06-08 08:03:55 --> Language Class Initialized
INFO - 2024-06-08 08:03:55 --> Language Class Initialized
INFO - 2024-06-08 08:03:55 --> Config Class Initialized
INFO - 2024-06-08 08:03:55 --> Loader Class Initialized
INFO - 2024-06-08 08:03:55 --> Helper loaded: url_helper
INFO - 2024-06-08 08:03:55 --> Helper loaded: file_helper
INFO - 2024-06-08 08:03:55 --> Helper loaded: form_helper
INFO - 2024-06-08 08:03:55 --> Helper loaded: my_helper
INFO - 2024-06-08 08:03:55 --> Database Driver Class Initialized
INFO - 2024-06-08 08:03:55 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-08 08:03:55 --> Controller Class Initialized
INFO - 2024-06-08 08:07:09 --> Config Class Initialized
INFO - 2024-06-08 08:07:09 --> Hooks Class Initialized
DEBUG - 2024-06-08 08:07:09 --> UTF-8 Support Enabled
INFO - 2024-06-08 08:07:09 --> Utf8 Class Initialized
INFO - 2024-06-08 08:07:09 --> URI Class Initialized
DEBUG - 2024-06-08 08:07:09 --> No URI present. Default controller set.
INFO - 2024-06-08 08:07:09 --> Router Class Initialized
INFO - 2024-06-08 08:07:09 --> Output Class Initialized
INFO - 2024-06-08 08:07:09 --> Security Class Initialized
DEBUG - 2024-06-08 08:07:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-08 08:07:09 --> Input Class Initialized
INFO - 2024-06-08 08:07:09 --> Language Class Initialized
INFO - 2024-06-08 08:07:09 --> Language Class Initialized
INFO - 2024-06-08 08:07:09 --> Config Class Initialized
INFO - 2024-06-08 08:07:09 --> Loader Class Initialized
INFO - 2024-06-08 08:07:09 --> Helper loaded: url_helper
INFO - 2024-06-08 08:07:09 --> Helper loaded: file_helper
INFO - 2024-06-08 08:07:09 --> Helper loaded: form_helper
INFO - 2024-06-08 08:07:09 --> Helper loaded: my_helper
INFO - 2024-06-08 08:07:09 --> Database Driver Class Initialized
INFO - 2024-06-08 08:07:09 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-08 08:07:09 --> Controller Class Initialized
INFO - 2024-06-08 08:07:10 --> Config Class Initialized
INFO - 2024-06-08 08:07:10 --> Hooks Class Initialized
DEBUG - 2024-06-08 08:07:10 --> UTF-8 Support Enabled
INFO - 2024-06-08 08:07:10 --> Utf8 Class Initialized
INFO - 2024-06-08 08:07:10 --> URI Class Initialized
INFO - 2024-06-08 08:07:10 --> Router Class Initialized
INFO - 2024-06-08 08:07:10 --> Output Class Initialized
INFO - 2024-06-08 08:07:10 --> Security Class Initialized
DEBUG - 2024-06-08 08:07:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-08 08:07:10 --> Input Class Initialized
INFO - 2024-06-08 08:07:10 --> Language Class Initialized
INFO - 2024-06-08 08:07:10 --> Language Class Initialized
INFO - 2024-06-08 08:07:10 --> Config Class Initialized
INFO - 2024-06-08 08:07:10 --> Loader Class Initialized
INFO - 2024-06-08 08:07:10 --> Helper loaded: url_helper
INFO - 2024-06-08 08:07:10 --> Helper loaded: file_helper
INFO - 2024-06-08 08:07:10 --> Helper loaded: form_helper
INFO - 2024-06-08 08:07:10 --> Helper loaded: my_helper
INFO - 2024-06-08 08:07:10 --> Database Driver Class Initialized
INFO - 2024-06-08 08:07:10 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-08 08:07:10 --> Controller Class Initialized
DEBUG - 2024-06-08 08:07:10 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/login/views/login.php
DEBUG - 2024-06-08 08:07:10 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-06-08 08:07:10 --> Final output sent to browser
DEBUG - 2024-06-08 08:07:10 --> Total execution time: 0.0325
INFO - 2024-06-08 08:07:12 --> Config Class Initialized
INFO - 2024-06-08 08:07:12 --> Hooks Class Initialized
DEBUG - 2024-06-08 08:07:12 --> UTF-8 Support Enabled
INFO - 2024-06-08 08:07:12 --> Utf8 Class Initialized
INFO - 2024-06-08 08:07:12 --> URI Class Initialized
INFO - 2024-06-08 08:07:12 --> Router Class Initialized
INFO - 2024-06-08 08:07:12 --> Output Class Initialized
INFO - 2024-06-08 08:07:12 --> Security Class Initialized
DEBUG - 2024-06-08 08:07:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-08 08:07:12 --> Input Class Initialized
INFO - 2024-06-08 08:07:12 --> Language Class Initialized
INFO - 2024-06-08 08:07:12 --> Language Class Initialized
INFO - 2024-06-08 08:07:12 --> Config Class Initialized
INFO - 2024-06-08 08:07:12 --> Loader Class Initialized
INFO - 2024-06-08 08:07:12 --> Helper loaded: url_helper
INFO - 2024-06-08 08:07:12 --> Helper loaded: file_helper
INFO - 2024-06-08 08:07:12 --> Helper loaded: form_helper
INFO - 2024-06-08 08:07:12 --> Helper loaded: my_helper
INFO - 2024-06-08 08:07:12 --> Database Driver Class Initialized
INFO - 2024-06-08 08:07:12 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-08 08:07:12 --> Controller Class Initialized
INFO - 2024-06-08 08:07:12 --> Helper loaded: cookie_helper
INFO - 2024-06-08 08:07:12 --> Final output sent to browser
DEBUG - 2024-06-08 08:07:12 --> Total execution time: 0.0456
INFO - 2024-06-08 08:07:12 --> Config Class Initialized
INFO - 2024-06-08 08:07:12 --> Hooks Class Initialized
DEBUG - 2024-06-08 08:07:12 --> UTF-8 Support Enabled
INFO - 2024-06-08 08:07:12 --> Utf8 Class Initialized
INFO - 2024-06-08 08:07:12 --> URI Class Initialized
INFO - 2024-06-08 08:07:12 --> Router Class Initialized
INFO - 2024-06-08 08:07:12 --> Output Class Initialized
INFO - 2024-06-08 08:07:12 --> Security Class Initialized
DEBUG - 2024-06-08 08:07:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-08 08:07:12 --> Input Class Initialized
INFO - 2024-06-08 08:07:12 --> Language Class Initialized
INFO - 2024-06-08 08:07:12 --> Language Class Initialized
INFO - 2024-06-08 08:07:12 --> Config Class Initialized
INFO - 2024-06-08 08:07:12 --> Loader Class Initialized
INFO - 2024-06-08 08:07:12 --> Helper loaded: url_helper
INFO - 2024-06-08 08:07:12 --> Helper loaded: file_helper
INFO - 2024-06-08 08:07:12 --> Helper loaded: form_helper
INFO - 2024-06-08 08:07:12 --> Helper loaded: my_helper
INFO - 2024-06-08 08:07:12 --> Database Driver Class Initialized
INFO - 2024-06-08 08:07:12 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-08 08:07:12 --> Controller Class Initialized
DEBUG - 2024-06-08 08:07:12 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/home/views/v_home_guru.php
DEBUG - 2024-06-08 08:07:12 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-06-08 08:07:12 --> Final output sent to browser
DEBUG - 2024-06-08 08:07:12 --> Total execution time: 0.0394
INFO - 2024-06-08 08:07:46 --> Config Class Initialized
INFO - 2024-06-08 08:07:46 --> Hooks Class Initialized
DEBUG - 2024-06-08 08:07:46 --> UTF-8 Support Enabled
INFO - 2024-06-08 08:07:46 --> Utf8 Class Initialized
INFO - 2024-06-08 08:07:46 --> URI Class Initialized
INFO - 2024-06-08 08:07:46 --> Router Class Initialized
INFO - 2024-06-08 08:07:46 --> Output Class Initialized
INFO - 2024-06-08 08:07:46 --> Security Class Initialized
DEBUG - 2024-06-08 08:07:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-08 08:07:46 --> Input Class Initialized
INFO - 2024-06-08 08:07:46 --> Language Class Initialized
INFO - 2024-06-08 08:07:46 --> Language Class Initialized
INFO - 2024-06-08 08:07:46 --> Config Class Initialized
INFO - 2024-06-08 08:07:46 --> Loader Class Initialized
INFO - 2024-06-08 08:07:46 --> Helper loaded: url_helper
INFO - 2024-06-08 08:07:46 --> Helper loaded: file_helper
INFO - 2024-06-08 08:07:46 --> Helper loaded: form_helper
INFO - 2024-06-08 08:07:46 --> Helper loaded: my_helper
INFO - 2024-06-08 08:07:46 --> Database Driver Class Initialized
INFO - 2024-06-08 08:07:46 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-08 08:07:46 --> Controller Class Initialized
DEBUG - 2024-06-08 08:07:46 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/view_mapel/views/v_view_mapel.php
DEBUG - 2024-06-08 08:07:46 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-06-08 08:07:46 --> Final output sent to browser
DEBUG - 2024-06-08 08:07:46 --> Total execution time: 0.0261
INFO - 2024-06-08 08:07:48 --> Config Class Initialized
INFO - 2024-06-08 08:07:48 --> Hooks Class Initialized
DEBUG - 2024-06-08 08:07:48 --> UTF-8 Support Enabled
INFO - 2024-06-08 08:07:48 --> Utf8 Class Initialized
INFO - 2024-06-08 08:07:48 --> URI Class Initialized
INFO - 2024-06-08 08:07:48 --> Router Class Initialized
INFO - 2024-06-08 08:07:48 --> Output Class Initialized
INFO - 2024-06-08 08:07:48 --> Security Class Initialized
DEBUG - 2024-06-08 08:07:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-08 08:07:48 --> Input Class Initialized
INFO - 2024-06-08 08:07:48 --> Language Class Initialized
INFO - 2024-06-08 08:07:48 --> Language Class Initialized
INFO - 2024-06-08 08:07:48 --> Config Class Initialized
INFO - 2024-06-08 08:07:48 --> Loader Class Initialized
INFO - 2024-06-08 08:07:48 --> Helper loaded: url_helper
INFO - 2024-06-08 08:07:48 --> Helper loaded: file_helper
INFO - 2024-06-08 08:07:48 --> Helper loaded: form_helper
INFO - 2024-06-08 08:07:48 --> Helper loaded: my_helper
INFO - 2024-06-08 08:07:48 --> Database Driver Class Initialized
INFO - 2024-06-08 08:07:48 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-08 08:07:48 --> Controller Class Initialized
DEBUG - 2024-06-08 08:07:49 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/views/list.php
DEBUG - 2024-06-08 08:07:49 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-06-08 08:07:49 --> Final output sent to browser
DEBUG - 2024-06-08 08:07:49 --> Total execution time: 0.0424
INFO - 2024-06-08 08:07:49 --> Config Class Initialized
INFO - 2024-06-08 08:07:49 --> Hooks Class Initialized
DEBUG - 2024-06-08 08:07:49 --> UTF-8 Support Enabled
INFO - 2024-06-08 08:07:49 --> Utf8 Class Initialized
INFO - 2024-06-08 08:07:49 --> URI Class Initialized
INFO - 2024-06-08 08:07:49 --> Router Class Initialized
INFO - 2024-06-08 08:07:49 --> Output Class Initialized
INFO - 2024-06-08 08:07:49 --> Security Class Initialized
DEBUG - 2024-06-08 08:07:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-08 08:07:49 --> Input Class Initialized
INFO - 2024-06-08 08:07:49 --> Language Class Initialized
INFO - 2024-06-08 08:07:49 --> Language Class Initialized
INFO - 2024-06-08 08:07:49 --> Config Class Initialized
INFO - 2024-06-08 08:07:49 --> Loader Class Initialized
INFO - 2024-06-08 08:07:49 --> Helper loaded: url_helper
INFO - 2024-06-08 08:07:49 --> Helper loaded: file_helper
INFO - 2024-06-08 08:07:49 --> Helper loaded: form_helper
INFO - 2024-06-08 08:07:49 --> Helper loaded: my_helper
INFO - 2024-06-08 08:07:49 --> Database Driver Class Initialized
INFO - 2024-06-08 08:07:49 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-08 08:07:49 --> Controller Class Initialized
INFO - 2024-06-08 08:08:07 --> Config Class Initialized
INFO - 2024-06-08 08:08:07 --> Hooks Class Initialized
DEBUG - 2024-06-08 08:08:07 --> UTF-8 Support Enabled
INFO - 2024-06-08 08:08:07 --> Utf8 Class Initialized
INFO - 2024-06-08 08:08:07 --> URI Class Initialized
INFO - 2024-06-08 08:08:07 --> Router Class Initialized
INFO - 2024-06-08 08:08:07 --> Output Class Initialized
INFO - 2024-06-08 08:08:07 --> Security Class Initialized
DEBUG - 2024-06-08 08:08:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-08 08:08:07 --> Input Class Initialized
INFO - 2024-06-08 08:08:07 --> Language Class Initialized
INFO - 2024-06-08 08:08:07 --> Language Class Initialized
INFO - 2024-06-08 08:08:07 --> Config Class Initialized
INFO - 2024-06-08 08:08:07 --> Loader Class Initialized
INFO - 2024-06-08 08:08:07 --> Helper loaded: url_helper
INFO - 2024-06-08 08:08:07 --> Helper loaded: file_helper
INFO - 2024-06-08 08:08:07 --> Helper loaded: form_helper
INFO - 2024-06-08 08:08:07 --> Helper loaded: my_helper
INFO - 2024-06-08 08:08:07 --> Database Driver Class Initialized
INFO - 2024-06-08 08:08:07 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-08 08:08:07 --> Controller Class Initialized
INFO - 2024-06-08 08:08:07 --> Final output sent to browser
DEBUG - 2024-06-08 08:08:07 --> Total execution time: 0.0445
INFO - 2024-06-08 08:08:10 --> Config Class Initialized
INFO - 2024-06-08 08:08:10 --> Hooks Class Initialized
DEBUG - 2024-06-08 08:08:10 --> UTF-8 Support Enabled
INFO - 2024-06-08 08:08:10 --> Utf8 Class Initialized
INFO - 2024-06-08 08:08:10 --> URI Class Initialized
INFO - 2024-06-08 08:08:10 --> Router Class Initialized
INFO - 2024-06-08 08:08:10 --> Output Class Initialized
INFO - 2024-06-08 08:08:10 --> Security Class Initialized
DEBUG - 2024-06-08 08:08:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-08 08:08:10 --> Input Class Initialized
INFO - 2024-06-08 08:08:10 --> Language Class Initialized
INFO - 2024-06-08 08:08:10 --> Language Class Initialized
INFO - 2024-06-08 08:08:10 --> Config Class Initialized
INFO - 2024-06-08 08:08:10 --> Loader Class Initialized
INFO - 2024-06-08 08:08:10 --> Helper loaded: url_helper
INFO - 2024-06-08 08:08:10 --> Helper loaded: file_helper
INFO - 2024-06-08 08:08:10 --> Helper loaded: form_helper
INFO - 2024-06-08 08:08:10 --> Helper loaded: my_helper
INFO - 2024-06-08 08:08:10 --> Database Driver Class Initialized
INFO - 2024-06-08 08:08:10 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-08 08:08:10 --> Controller Class Initialized
INFO - 2024-06-08 08:08:39 --> Config Class Initialized
INFO - 2024-06-08 08:08:39 --> Hooks Class Initialized
DEBUG - 2024-06-08 08:08:39 --> UTF-8 Support Enabled
INFO - 2024-06-08 08:08:39 --> Utf8 Class Initialized
INFO - 2024-06-08 08:08:39 --> URI Class Initialized
INFO - 2024-06-08 08:08:39 --> Router Class Initialized
INFO - 2024-06-08 08:08:39 --> Output Class Initialized
INFO - 2024-06-08 08:08:39 --> Security Class Initialized
DEBUG - 2024-06-08 08:08:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-08 08:08:39 --> Input Class Initialized
INFO - 2024-06-08 08:08:39 --> Language Class Initialized
INFO - 2024-06-08 08:08:39 --> Language Class Initialized
INFO - 2024-06-08 08:08:39 --> Config Class Initialized
INFO - 2024-06-08 08:08:39 --> Loader Class Initialized
INFO - 2024-06-08 08:08:39 --> Helper loaded: url_helper
INFO - 2024-06-08 08:08:39 --> Helper loaded: file_helper
INFO - 2024-06-08 08:08:39 --> Helper loaded: form_helper
INFO - 2024-06-08 08:08:39 --> Helper loaded: my_helper
INFO - 2024-06-08 08:08:39 --> Database Driver Class Initialized
INFO - 2024-06-08 08:08:39 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-08 08:08:39 --> Controller Class Initialized
INFO - 2024-06-08 08:08:39 --> Final output sent to browser
DEBUG - 2024-06-08 08:08:39 --> Total execution time: 0.0276
INFO - 2024-06-08 08:08:48 --> Config Class Initialized
INFO - 2024-06-08 08:08:48 --> Hooks Class Initialized
DEBUG - 2024-06-08 08:08:48 --> UTF-8 Support Enabled
INFO - 2024-06-08 08:08:48 --> Utf8 Class Initialized
INFO - 2024-06-08 08:08:48 --> URI Class Initialized
INFO - 2024-06-08 08:08:48 --> Router Class Initialized
INFO - 2024-06-08 08:08:48 --> Output Class Initialized
INFO - 2024-06-08 08:08:48 --> Security Class Initialized
DEBUG - 2024-06-08 08:08:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-08 08:08:48 --> Input Class Initialized
INFO - 2024-06-08 08:08:48 --> Language Class Initialized
INFO - 2024-06-08 08:08:48 --> Language Class Initialized
INFO - 2024-06-08 08:08:48 --> Config Class Initialized
INFO - 2024-06-08 08:08:48 --> Loader Class Initialized
INFO - 2024-06-08 08:08:48 --> Helper loaded: url_helper
INFO - 2024-06-08 08:08:48 --> Helper loaded: file_helper
INFO - 2024-06-08 08:08:48 --> Helper loaded: form_helper
INFO - 2024-06-08 08:08:48 --> Helper loaded: my_helper
INFO - 2024-06-08 08:08:48 --> Database Driver Class Initialized
INFO - 2024-06-08 08:08:48 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-08 08:08:48 --> Controller Class Initialized
INFO - 2024-06-08 08:08:48 --> Final output sent to browser
DEBUG - 2024-06-08 08:08:48 --> Total execution time: 0.0764
INFO - 2024-06-08 08:08:48 --> Config Class Initialized
INFO - 2024-06-08 08:08:48 --> Hooks Class Initialized
DEBUG - 2024-06-08 08:08:48 --> UTF-8 Support Enabled
INFO - 2024-06-08 08:08:48 --> Utf8 Class Initialized
INFO - 2024-06-08 08:08:48 --> URI Class Initialized
INFO - 2024-06-08 08:08:48 --> Router Class Initialized
INFO - 2024-06-08 08:08:48 --> Output Class Initialized
INFO - 2024-06-08 08:08:48 --> Security Class Initialized
DEBUG - 2024-06-08 08:08:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-08 08:08:48 --> Input Class Initialized
INFO - 2024-06-08 08:08:48 --> Language Class Initialized
INFO - 2024-06-08 08:08:48 --> Language Class Initialized
INFO - 2024-06-08 08:08:48 --> Config Class Initialized
INFO - 2024-06-08 08:08:48 --> Loader Class Initialized
INFO - 2024-06-08 08:08:48 --> Helper loaded: url_helper
INFO - 2024-06-08 08:08:48 --> Helper loaded: file_helper
INFO - 2024-06-08 08:08:48 --> Helper loaded: form_helper
INFO - 2024-06-08 08:08:48 --> Helper loaded: my_helper
INFO - 2024-06-08 08:08:48 --> Database Driver Class Initialized
INFO - 2024-06-08 08:08:48 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-08 08:08:48 --> Controller Class Initialized
INFO - 2024-06-08 08:08:49 --> Config Class Initialized
INFO - 2024-06-08 08:08:49 --> Hooks Class Initialized
DEBUG - 2024-06-08 08:08:49 --> UTF-8 Support Enabled
INFO - 2024-06-08 08:08:49 --> Utf8 Class Initialized
INFO - 2024-06-08 08:08:49 --> URI Class Initialized
INFO - 2024-06-08 08:08:49 --> Router Class Initialized
INFO - 2024-06-08 08:08:49 --> Output Class Initialized
INFO - 2024-06-08 08:08:49 --> Security Class Initialized
DEBUG - 2024-06-08 08:08:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-08 08:08:49 --> Input Class Initialized
INFO - 2024-06-08 08:08:49 --> Language Class Initialized
INFO - 2024-06-08 08:08:49 --> Language Class Initialized
INFO - 2024-06-08 08:08:49 --> Config Class Initialized
INFO - 2024-06-08 08:08:49 --> Loader Class Initialized
INFO - 2024-06-08 08:08:49 --> Helper loaded: url_helper
INFO - 2024-06-08 08:08:49 --> Helper loaded: file_helper
INFO - 2024-06-08 08:08:49 --> Helper loaded: form_helper
INFO - 2024-06-08 08:08:49 --> Helper loaded: my_helper
INFO - 2024-06-08 08:08:49 --> Database Driver Class Initialized
INFO - 2024-06-08 08:08:49 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-08 08:08:49 --> Controller Class Initialized
INFO - 2024-06-08 08:08:49 --> Final output sent to browser
DEBUG - 2024-06-08 08:08:49 --> Total execution time: 0.0278
INFO - 2024-06-08 08:09:00 --> Config Class Initialized
INFO - 2024-06-08 08:09:00 --> Hooks Class Initialized
DEBUG - 2024-06-08 08:09:00 --> UTF-8 Support Enabled
INFO - 2024-06-08 08:09:00 --> Utf8 Class Initialized
INFO - 2024-06-08 08:09:00 --> URI Class Initialized
INFO - 2024-06-08 08:09:00 --> Router Class Initialized
INFO - 2024-06-08 08:09:00 --> Output Class Initialized
INFO - 2024-06-08 08:09:00 --> Security Class Initialized
DEBUG - 2024-06-08 08:09:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-08 08:09:00 --> Input Class Initialized
INFO - 2024-06-08 08:09:00 --> Language Class Initialized
INFO - 2024-06-08 08:09:00 --> Language Class Initialized
INFO - 2024-06-08 08:09:00 --> Config Class Initialized
INFO - 2024-06-08 08:09:00 --> Loader Class Initialized
INFO - 2024-06-08 08:09:00 --> Helper loaded: url_helper
INFO - 2024-06-08 08:09:00 --> Helper loaded: file_helper
INFO - 2024-06-08 08:09:00 --> Helper loaded: form_helper
INFO - 2024-06-08 08:09:00 --> Helper loaded: my_helper
INFO - 2024-06-08 08:09:00 --> Database Driver Class Initialized
INFO - 2024-06-08 08:09:00 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-08 08:09:00 --> Controller Class Initialized
INFO - 2024-06-08 08:09:00 --> Final output sent to browser
DEBUG - 2024-06-08 08:09:00 --> Total execution time: 0.0367
INFO - 2024-06-08 08:09:00 --> Config Class Initialized
INFO - 2024-06-08 08:09:00 --> Hooks Class Initialized
DEBUG - 2024-06-08 08:09:00 --> UTF-8 Support Enabled
INFO - 2024-06-08 08:09:00 --> Utf8 Class Initialized
INFO - 2024-06-08 08:09:00 --> URI Class Initialized
INFO - 2024-06-08 08:09:00 --> Router Class Initialized
INFO - 2024-06-08 08:09:00 --> Output Class Initialized
INFO - 2024-06-08 08:09:00 --> Security Class Initialized
DEBUG - 2024-06-08 08:09:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-08 08:09:00 --> Input Class Initialized
INFO - 2024-06-08 08:09:00 --> Language Class Initialized
INFO - 2024-06-08 08:09:00 --> Language Class Initialized
INFO - 2024-06-08 08:09:00 --> Config Class Initialized
INFO - 2024-06-08 08:09:00 --> Loader Class Initialized
INFO - 2024-06-08 08:09:00 --> Helper loaded: url_helper
INFO - 2024-06-08 08:09:00 --> Helper loaded: file_helper
INFO - 2024-06-08 08:09:00 --> Helper loaded: form_helper
INFO - 2024-06-08 08:09:00 --> Helper loaded: my_helper
INFO - 2024-06-08 08:09:00 --> Database Driver Class Initialized
INFO - 2024-06-08 08:09:00 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-08 08:09:00 --> Controller Class Initialized
INFO - 2024-06-08 08:09:55 --> Config Class Initialized
INFO - 2024-06-08 08:09:55 --> Hooks Class Initialized
DEBUG - 2024-06-08 08:09:55 --> UTF-8 Support Enabled
INFO - 2024-06-08 08:09:55 --> Utf8 Class Initialized
INFO - 2024-06-08 08:09:55 --> URI Class Initialized
INFO - 2024-06-08 08:09:55 --> Router Class Initialized
INFO - 2024-06-08 08:09:55 --> Output Class Initialized
INFO - 2024-06-08 08:09:55 --> Security Class Initialized
DEBUG - 2024-06-08 08:09:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-08 08:09:55 --> Input Class Initialized
INFO - 2024-06-08 08:09:55 --> Language Class Initialized
INFO - 2024-06-08 08:09:55 --> Language Class Initialized
INFO - 2024-06-08 08:09:55 --> Config Class Initialized
INFO - 2024-06-08 08:09:55 --> Loader Class Initialized
INFO - 2024-06-08 08:09:55 --> Helper loaded: url_helper
INFO - 2024-06-08 08:09:55 --> Helper loaded: file_helper
INFO - 2024-06-08 08:09:55 --> Helper loaded: form_helper
INFO - 2024-06-08 08:09:55 --> Helper loaded: my_helper
INFO - 2024-06-08 08:09:55 --> Database Driver Class Initialized
INFO - 2024-06-08 08:09:55 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-08 08:09:55 --> Controller Class Initialized
INFO - 2024-06-08 08:41:51 --> Config Class Initialized
INFO - 2024-06-08 08:41:51 --> Hooks Class Initialized
DEBUG - 2024-06-08 08:41:51 --> UTF-8 Support Enabled
INFO - 2024-06-08 08:41:51 --> Utf8 Class Initialized
INFO - 2024-06-08 08:41:51 --> URI Class Initialized
INFO - 2024-06-08 08:41:51 --> Router Class Initialized
INFO - 2024-06-08 08:41:51 --> Output Class Initialized
INFO - 2024-06-08 08:41:51 --> Security Class Initialized
DEBUG - 2024-06-08 08:41:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-08 08:41:51 --> Input Class Initialized
INFO - 2024-06-08 08:41:51 --> Language Class Initialized
INFO - 2024-06-08 08:41:51 --> Language Class Initialized
INFO - 2024-06-08 08:41:51 --> Config Class Initialized
INFO - 2024-06-08 08:41:51 --> Loader Class Initialized
INFO - 2024-06-08 08:41:51 --> Helper loaded: url_helper
INFO - 2024-06-08 08:41:51 --> Helper loaded: file_helper
INFO - 2024-06-08 08:41:51 --> Helper loaded: form_helper
INFO - 2024-06-08 08:41:51 --> Helper loaded: my_helper
INFO - 2024-06-08 08:41:51 --> Database Driver Class Initialized
INFO - 2024-06-08 08:41:51 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-08 08:41:51 --> Controller Class Initialized
DEBUG - 2024-06-08 08:41:51 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/views/form.php
DEBUG - 2024-06-08 08:41:51 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-06-08 08:41:51 --> Final output sent to browser
DEBUG - 2024-06-08 08:41:51 --> Total execution time: 0.0464
INFO - 2024-06-08 08:41:58 --> Config Class Initialized
INFO - 2024-06-08 08:41:58 --> Hooks Class Initialized
DEBUG - 2024-06-08 08:41:58 --> UTF-8 Support Enabled
INFO - 2024-06-08 08:41:58 --> Utf8 Class Initialized
INFO - 2024-06-08 08:41:58 --> URI Class Initialized
INFO - 2024-06-08 08:41:58 --> Router Class Initialized
INFO - 2024-06-08 08:41:58 --> Output Class Initialized
INFO - 2024-06-08 08:41:58 --> Security Class Initialized
DEBUG - 2024-06-08 08:41:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-08 08:41:58 --> Input Class Initialized
INFO - 2024-06-08 08:41:58 --> Language Class Initialized
INFO - 2024-06-08 08:41:58 --> Language Class Initialized
INFO - 2024-06-08 08:41:58 --> Config Class Initialized
INFO - 2024-06-08 08:41:58 --> Loader Class Initialized
INFO - 2024-06-08 08:41:58 --> Helper loaded: url_helper
INFO - 2024-06-08 08:41:58 --> Helper loaded: file_helper
INFO - 2024-06-08 08:41:58 --> Helper loaded: form_helper
INFO - 2024-06-08 08:41:58 --> Helper loaded: my_helper
INFO - 2024-06-08 08:41:58 --> Database Driver Class Initialized
INFO - 2024-06-08 08:41:58 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-08 08:41:58 --> Controller Class Initialized
INFO - 2024-06-08 08:41:58 --> Config Class Initialized
INFO - 2024-06-08 08:41:58 --> Hooks Class Initialized
DEBUG - 2024-06-08 08:41:58 --> UTF-8 Support Enabled
INFO - 2024-06-08 08:41:58 --> Utf8 Class Initialized
INFO - 2024-06-08 08:41:58 --> URI Class Initialized
INFO - 2024-06-08 08:41:58 --> Router Class Initialized
INFO - 2024-06-08 08:41:58 --> Output Class Initialized
INFO - 2024-06-08 08:41:58 --> Security Class Initialized
DEBUG - 2024-06-08 08:41:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-08 08:41:58 --> Input Class Initialized
INFO - 2024-06-08 08:41:58 --> Language Class Initialized
INFO - 2024-06-08 08:41:58 --> Language Class Initialized
INFO - 2024-06-08 08:41:58 --> Config Class Initialized
INFO - 2024-06-08 08:41:58 --> Loader Class Initialized
INFO - 2024-06-08 08:41:58 --> Helper loaded: url_helper
INFO - 2024-06-08 08:41:58 --> Helper loaded: file_helper
INFO - 2024-06-08 08:41:58 --> Helper loaded: form_helper
INFO - 2024-06-08 08:41:58 --> Helper loaded: my_helper
INFO - 2024-06-08 08:41:58 --> Database Driver Class Initialized
INFO - 2024-06-08 08:41:58 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-08 08:41:58 --> Controller Class Initialized
DEBUG - 2024-06-08 08:41:58 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/views/list.php
DEBUG - 2024-06-08 08:41:58 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-06-08 08:41:58 --> Final output sent to browser
DEBUG - 2024-06-08 08:41:58 --> Total execution time: 0.0368
INFO - 2024-06-08 08:41:58 --> Config Class Initialized
INFO - 2024-06-08 08:41:58 --> Hooks Class Initialized
DEBUG - 2024-06-08 08:41:58 --> UTF-8 Support Enabled
INFO - 2024-06-08 08:41:58 --> Utf8 Class Initialized
INFO - 2024-06-08 08:41:58 --> URI Class Initialized
INFO - 2024-06-08 08:41:58 --> Router Class Initialized
INFO - 2024-06-08 08:41:58 --> Output Class Initialized
INFO - 2024-06-08 08:41:58 --> Security Class Initialized
DEBUG - 2024-06-08 08:41:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-08 08:41:58 --> Input Class Initialized
INFO - 2024-06-08 08:41:58 --> Language Class Initialized
INFO - 2024-06-08 08:41:58 --> Language Class Initialized
INFO - 2024-06-08 08:41:58 --> Config Class Initialized
INFO - 2024-06-08 08:41:58 --> Loader Class Initialized
INFO - 2024-06-08 08:41:58 --> Helper loaded: url_helper
INFO - 2024-06-08 08:41:58 --> Helper loaded: file_helper
INFO - 2024-06-08 08:41:58 --> Helper loaded: form_helper
INFO - 2024-06-08 08:41:58 --> Helper loaded: my_helper
INFO - 2024-06-08 08:41:58 --> Database Driver Class Initialized
INFO - 2024-06-08 08:41:58 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-08 08:41:58 --> Controller Class Initialized
INFO - 2024-06-08 08:42:00 --> Config Class Initialized
INFO - 2024-06-08 08:42:00 --> Hooks Class Initialized
DEBUG - 2024-06-08 08:42:00 --> UTF-8 Support Enabled
INFO - 2024-06-08 08:42:00 --> Utf8 Class Initialized
INFO - 2024-06-08 08:42:00 --> URI Class Initialized
INFO - 2024-06-08 08:42:00 --> Router Class Initialized
INFO - 2024-06-08 08:42:00 --> Output Class Initialized
INFO - 2024-06-08 08:42:00 --> Security Class Initialized
DEBUG - 2024-06-08 08:42:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-08 08:42:00 --> Input Class Initialized
INFO - 2024-06-08 08:42:00 --> Language Class Initialized
INFO - 2024-06-08 08:42:00 --> Language Class Initialized
INFO - 2024-06-08 08:42:00 --> Config Class Initialized
INFO - 2024-06-08 08:42:00 --> Loader Class Initialized
INFO - 2024-06-08 08:42:00 --> Helper loaded: url_helper
INFO - 2024-06-08 08:42:00 --> Helper loaded: file_helper
INFO - 2024-06-08 08:42:00 --> Helper loaded: form_helper
INFO - 2024-06-08 08:42:00 --> Helper loaded: my_helper
INFO - 2024-06-08 08:42:00 --> Database Driver Class Initialized
INFO - 2024-06-08 08:42:00 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-08 08:42:00 --> Controller Class Initialized
INFO - 2024-06-08 08:42:00 --> Final output sent to browser
DEBUG - 2024-06-08 08:42:00 --> Total execution time: 0.0352
INFO - 2024-06-08 08:42:04 --> Config Class Initialized
INFO - 2024-06-08 08:42:04 --> Hooks Class Initialized
DEBUG - 2024-06-08 08:42:04 --> UTF-8 Support Enabled
INFO - 2024-06-08 08:42:04 --> Utf8 Class Initialized
INFO - 2024-06-08 08:42:04 --> URI Class Initialized
INFO - 2024-06-08 08:42:04 --> Router Class Initialized
INFO - 2024-06-08 08:42:04 --> Output Class Initialized
INFO - 2024-06-08 08:42:04 --> Security Class Initialized
DEBUG - 2024-06-08 08:42:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-08 08:42:04 --> Input Class Initialized
INFO - 2024-06-08 08:42:04 --> Language Class Initialized
INFO - 2024-06-08 08:42:04 --> Language Class Initialized
INFO - 2024-06-08 08:42:04 --> Config Class Initialized
INFO - 2024-06-08 08:42:04 --> Loader Class Initialized
INFO - 2024-06-08 08:42:04 --> Helper loaded: url_helper
INFO - 2024-06-08 08:42:04 --> Helper loaded: file_helper
INFO - 2024-06-08 08:42:04 --> Helper loaded: form_helper
INFO - 2024-06-08 08:42:04 --> Helper loaded: my_helper
INFO - 2024-06-08 08:42:04 --> Database Driver Class Initialized
INFO - 2024-06-08 08:42:04 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-08 08:42:04 --> Controller Class Initialized
INFO - 2024-06-08 08:42:04 --> Final output sent to browser
DEBUG - 2024-06-08 08:42:04 --> Total execution time: 0.0404
INFO - 2024-06-08 08:42:12 --> Config Class Initialized
INFO - 2024-06-08 08:42:12 --> Hooks Class Initialized
DEBUG - 2024-06-08 08:42:12 --> UTF-8 Support Enabled
INFO - 2024-06-08 08:42:12 --> Utf8 Class Initialized
INFO - 2024-06-08 08:42:12 --> URI Class Initialized
INFO - 2024-06-08 08:42:12 --> Router Class Initialized
INFO - 2024-06-08 08:42:12 --> Output Class Initialized
INFO - 2024-06-08 08:42:12 --> Security Class Initialized
DEBUG - 2024-06-08 08:42:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-08 08:42:12 --> Input Class Initialized
INFO - 2024-06-08 08:42:12 --> Language Class Initialized
INFO - 2024-06-08 08:42:12 --> Language Class Initialized
INFO - 2024-06-08 08:42:12 --> Config Class Initialized
INFO - 2024-06-08 08:42:12 --> Loader Class Initialized
INFO - 2024-06-08 08:42:12 --> Helper loaded: url_helper
INFO - 2024-06-08 08:42:12 --> Helper loaded: file_helper
INFO - 2024-06-08 08:42:12 --> Helper loaded: form_helper
INFO - 2024-06-08 08:42:12 --> Helper loaded: my_helper
INFO - 2024-06-08 08:42:12 --> Database Driver Class Initialized
INFO - 2024-06-08 08:42:12 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-08 08:42:12 --> Controller Class Initialized
INFO - 2024-06-08 14:05:14 --> Config Class Initialized
INFO - 2024-06-08 14:05:14 --> Hooks Class Initialized
DEBUG - 2024-06-08 14:05:14 --> UTF-8 Support Enabled
INFO - 2024-06-08 14:05:14 --> Utf8 Class Initialized
INFO - 2024-06-08 14:05:14 --> URI Class Initialized
INFO - 2024-06-08 14:05:14 --> Router Class Initialized
INFO - 2024-06-08 14:05:14 --> Output Class Initialized
INFO - 2024-06-08 14:05:14 --> Security Class Initialized
DEBUG - 2024-06-08 14:05:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-08 14:05:14 --> Input Class Initialized
INFO - 2024-06-08 14:05:14 --> Language Class Initialized
INFO - 2024-06-08 14:05:14 --> Language Class Initialized
INFO - 2024-06-08 14:05:14 --> Config Class Initialized
INFO - 2024-06-08 14:05:14 --> Loader Class Initialized
INFO - 2024-06-08 14:05:14 --> Helper loaded: url_helper
INFO - 2024-06-08 14:05:14 --> Helper loaded: file_helper
INFO - 2024-06-08 14:05:14 --> Helper loaded: form_helper
INFO - 2024-06-08 14:05:14 --> Helper loaded: my_helper
INFO - 2024-06-08 14:05:14 --> Database Driver Class Initialized
INFO - 2024-06-08 14:05:14 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-08 14:05:14 --> Controller Class Initialized
DEBUG - 2024-06-08 14:05:14 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/views/list.php
DEBUG - 2024-06-08 14:05:14 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-06-08 14:05:14 --> Final output sent to browser
DEBUG - 2024-06-08 14:05:14 --> Total execution time: 0.1292
INFO - 2024-06-08 14:05:14 --> Config Class Initialized
INFO - 2024-06-08 14:05:14 --> Hooks Class Initialized
DEBUG - 2024-06-08 14:05:14 --> UTF-8 Support Enabled
INFO - 2024-06-08 14:05:14 --> Utf8 Class Initialized
INFO - 2024-06-08 14:05:14 --> URI Class Initialized
INFO - 2024-06-08 14:05:14 --> Router Class Initialized
INFO - 2024-06-08 14:05:14 --> Output Class Initialized
INFO - 2024-06-08 14:05:14 --> Security Class Initialized
DEBUG - 2024-06-08 14:05:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-08 14:05:14 --> Input Class Initialized
INFO - 2024-06-08 14:05:14 --> Language Class Initialized
INFO - 2024-06-08 14:05:14 --> Language Class Initialized
INFO - 2024-06-08 14:05:14 --> Config Class Initialized
INFO - 2024-06-08 14:05:14 --> Loader Class Initialized
INFO - 2024-06-08 14:05:14 --> Helper loaded: url_helper
INFO - 2024-06-08 14:05:14 --> Helper loaded: file_helper
INFO - 2024-06-08 14:05:14 --> Helper loaded: form_helper
INFO - 2024-06-08 14:05:14 --> Helper loaded: my_helper
INFO - 2024-06-08 14:05:14 --> Database Driver Class Initialized
INFO - 2024-06-08 14:05:14 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-08 14:05:14 --> Controller Class Initialized
INFO - 2024-06-08 14:09:15 --> Config Class Initialized
INFO - 2024-06-08 14:09:15 --> Hooks Class Initialized
DEBUG - 2024-06-08 14:09:15 --> UTF-8 Support Enabled
INFO - 2024-06-08 14:09:15 --> Utf8 Class Initialized
INFO - 2024-06-08 14:09:15 --> URI Class Initialized
INFO - 2024-06-08 14:09:15 --> Router Class Initialized
INFO - 2024-06-08 14:09:15 --> Output Class Initialized
INFO - 2024-06-08 14:09:15 --> Security Class Initialized
DEBUG - 2024-06-08 14:09:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-08 14:09:15 --> Input Class Initialized
INFO - 2024-06-08 14:09:15 --> Language Class Initialized
INFO - 2024-06-08 14:09:15 --> Language Class Initialized
INFO - 2024-06-08 14:09:15 --> Config Class Initialized
INFO - 2024-06-08 14:09:15 --> Loader Class Initialized
INFO - 2024-06-08 14:09:15 --> Helper loaded: url_helper
INFO - 2024-06-08 14:09:15 --> Helper loaded: file_helper
INFO - 2024-06-08 14:09:15 --> Helper loaded: form_helper
INFO - 2024-06-08 14:09:15 --> Helper loaded: my_helper
INFO - 2024-06-08 14:09:15 --> Database Driver Class Initialized
INFO - 2024-06-08 14:09:15 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-08 14:09:15 --> Controller Class Initialized
DEBUG - 2024-06-08 14:09:15 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/views/list.php
DEBUG - 2024-06-08 14:09:15 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-06-08 14:09:15 --> Final output sent to browser
DEBUG - 2024-06-08 14:09:15 --> Total execution time: 0.0620
INFO - 2024-06-08 14:09:15 --> Config Class Initialized
INFO - 2024-06-08 14:09:15 --> Hooks Class Initialized
DEBUG - 2024-06-08 14:09:15 --> UTF-8 Support Enabled
INFO - 2024-06-08 14:09:15 --> Utf8 Class Initialized
INFO - 2024-06-08 14:09:15 --> URI Class Initialized
INFO - 2024-06-08 14:09:15 --> Router Class Initialized
INFO - 2024-06-08 14:09:15 --> Output Class Initialized
INFO - 2024-06-08 14:09:15 --> Security Class Initialized
DEBUG - 2024-06-08 14:09:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-08 14:09:15 --> Input Class Initialized
INFO - 2024-06-08 14:09:15 --> Language Class Initialized
INFO - 2024-06-08 14:09:15 --> Language Class Initialized
INFO - 2024-06-08 14:09:15 --> Config Class Initialized
INFO - 2024-06-08 14:09:15 --> Loader Class Initialized
INFO - 2024-06-08 14:09:15 --> Helper loaded: url_helper
INFO - 2024-06-08 14:09:15 --> Helper loaded: file_helper
INFO - 2024-06-08 14:09:15 --> Helper loaded: form_helper
INFO - 2024-06-08 14:09:15 --> Helper loaded: my_helper
INFO - 2024-06-08 14:09:15 --> Database Driver Class Initialized
INFO - 2024-06-08 14:09:15 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-08 14:09:15 --> Controller Class Initialized
INFO - 2024-06-08 14:09:50 --> Config Class Initialized
INFO - 2024-06-08 14:09:50 --> Hooks Class Initialized
DEBUG - 2024-06-08 14:09:50 --> UTF-8 Support Enabled
INFO - 2024-06-08 14:09:50 --> Utf8 Class Initialized
INFO - 2024-06-08 14:09:50 --> URI Class Initialized
INFO - 2024-06-08 14:09:50 --> Router Class Initialized
INFO - 2024-06-08 14:09:51 --> Output Class Initialized
INFO - 2024-06-08 14:09:51 --> Security Class Initialized
DEBUG - 2024-06-08 14:09:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-08 14:09:51 --> Input Class Initialized
INFO - 2024-06-08 14:09:51 --> Language Class Initialized
INFO - 2024-06-08 14:09:51 --> Language Class Initialized
INFO - 2024-06-08 14:09:51 --> Config Class Initialized
INFO - 2024-06-08 14:09:51 --> Loader Class Initialized
INFO - 2024-06-08 14:09:51 --> Helper loaded: url_helper
INFO - 2024-06-08 14:09:51 --> Helper loaded: file_helper
INFO - 2024-06-08 14:09:51 --> Helper loaded: form_helper
INFO - 2024-06-08 14:09:51 --> Helper loaded: my_helper
INFO - 2024-06-08 14:09:51 --> Database Driver Class Initialized
INFO - 2024-06-08 14:09:51 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-08 14:09:51 --> Controller Class Initialized
DEBUG - 2024-06-08 14:09:51 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/login/views/login.php
DEBUG - 2024-06-08 14:09:51 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-06-08 14:09:51 --> Final output sent to browser
DEBUG - 2024-06-08 14:09:51 --> Total execution time: 0.9163
INFO - 2024-06-08 14:10:05 --> Config Class Initialized
INFO - 2024-06-08 14:10:05 --> Hooks Class Initialized
DEBUG - 2024-06-08 14:10:05 --> UTF-8 Support Enabled
INFO - 2024-06-08 14:10:05 --> Utf8 Class Initialized
INFO - 2024-06-08 14:10:05 --> URI Class Initialized
INFO - 2024-06-08 14:10:05 --> Router Class Initialized
INFO - 2024-06-08 14:10:05 --> Output Class Initialized
INFO - 2024-06-08 14:10:05 --> Security Class Initialized
DEBUG - 2024-06-08 14:10:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-08 14:10:05 --> Input Class Initialized
INFO - 2024-06-08 14:10:05 --> Language Class Initialized
INFO - 2024-06-08 14:10:05 --> Language Class Initialized
INFO - 2024-06-08 14:10:05 --> Config Class Initialized
INFO - 2024-06-08 14:10:05 --> Loader Class Initialized
INFO - 2024-06-08 14:10:05 --> Helper loaded: url_helper
INFO - 2024-06-08 14:10:05 --> Helper loaded: file_helper
INFO - 2024-06-08 14:10:05 --> Helper loaded: form_helper
INFO - 2024-06-08 14:10:05 --> Helper loaded: my_helper
INFO - 2024-06-08 14:10:05 --> Database Driver Class Initialized
INFO - 2024-06-08 14:10:05 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-08 14:10:05 --> Controller Class Initialized
INFO - 2024-06-08 14:10:05 --> Helper loaded: cookie_helper
INFO - 2024-06-08 14:10:05 --> Final output sent to browser
DEBUG - 2024-06-08 14:10:05 --> Total execution time: 0.1916
INFO - 2024-06-08 14:10:06 --> Config Class Initialized
INFO - 2024-06-08 14:10:06 --> Hooks Class Initialized
DEBUG - 2024-06-08 14:10:06 --> UTF-8 Support Enabled
INFO - 2024-06-08 14:10:06 --> Utf8 Class Initialized
INFO - 2024-06-08 14:10:06 --> URI Class Initialized
INFO - 2024-06-08 14:10:06 --> Router Class Initialized
INFO - 2024-06-08 14:10:06 --> Output Class Initialized
INFO - 2024-06-08 14:10:06 --> Security Class Initialized
DEBUG - 2024-06-08 14:10:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-08 14:10:06 --> Input Class Initialized
INFO - 2024-06-08 14:10:06 --> Language Class Initialized
INFO - 2024-06-08 14:10:06 --> Language Class Initialized
INFO - 2024-06-08 14:10:06 --> Config Class Initialized
INFO - 2024-06-08 14:10:06 --> Loader Class Initialized
INFO - 2024-06-08 14:10:06 --> Helper loaded: url_helper
INFO - 2024-06-08 14:10:06 --> Helper loaded: file_helper
INFO - 2024-06-08 14:10:06 --> Helper loaded: form_helper
INFO - 2024-06-08 14:10:06 --> Helper loaded: my_helper
INFO - 2024-06-08 14:10:06 --> Database Driver Class Initialized
INFO - 2024-06-08 14:10:06 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-08 14:10:06 --> Controller Class Initialized
DEBUG - 2024-06-08 14:10:06 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/home/views/v_home.php
DEBUG - 2024-06-08 14:10:06 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-06-08 14:10:06 --> Final output sent to browser
DEBUG - 2024-06-08 14:10:06 --> Total execution time: 0.1739
INFO - 2024-06-08 14:10:18 --> Config Class Initialized
INFO - 2024-06-08 14:10:18 --> Hooks Class Initialized
DEBUG - 2024-06-08 14:10:18 --> UTF-8 Support Enabled
INFO - 2024-06-08 14:10:18 --> Utf8 Class Initialized
INFO - 2024-06-08 14:10:18 --> URI Class Initialized
INFO - 2024-06-08 14:10:18 --> Router Class Initialized
INFO - 2024-06-08 14:10:18 --> Output Class Initialized
INFO - 2024-06-08 14:10:18 --> Security Class Initialized
DEBUG - 2024-06-08 14:10:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-08 14:10:18 --> Input Class Initialized
INFO - 2024-06-08 14:10:18 --> Language Class Initialized
INFO - 2024-06-08 14:10:18 --> Language Class Initialized
INFO - 2024-06-08 14:10:18 --> Config Class Initialized
INFO - 2024-06-08 14:10:18 --> Loader Class Initialized
INFO - 2024-06-08 14:10:18 --> Helper loaded: url_helper
INFO - 2024-06-08 14:10:18 --> Helper loaded: file_helper
INFO - 2024-06-08 14:10:18 --> Helper loaded: form_helper
INFO - 2024-06-08 14:10:18 --> Helper loaded: my_helper
INFO - 2024-06-08 14:10:18 --> Database Driver Class Initialized
INFO - 2024-06-08 14:10:18 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-08 14:10:18 --> Controller Class Initialized
INFO - 2024-06-08 14:10:18 --> Helper loaded: cookie_helper
INFO - 2024-06-08 14:10:18 --> Config Class Initialized
INFO - 2024-06-08 14:10:18 --> Hooks Class Initialized
DEBUG - 2024-06-08 14:10:18 --> UTF-8 Support Enabled
INFO - 2024-06-08 14:10:18 --> Utf8 Class Initialized
INFO - 2024-06-08 14:10:18 --> URI Class Initialized
INFO - 2024-06-08 14:10:18 --> Router Class Initialized
INFO - 2024-06-08 14:10:18 --> Output Class Initialized
INFO - 2024-06-08 14:10:18 --> Security Class Initialized
DEBUG - 2024-06-08 14:10:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-08 14:10:18 --> Input Class Initialized
INFO - 2024-06-08 14:10:18 --> Language Class Initialized
INFO - 2024-06-08 14:10:18 --> Language Class Initialized
INFO - 2024-06-08 14:10:18 --> Config Class Initialized
INFO - 2024-06-08 14:10:18 --> Loader Class Initialized
INFO - 2024-06-08 14:10:18 --> Helper loaded: url_helper
INFO - 2024-06-08 14:10:18 --> Helper loaded: file_helper
INFO - 2024-06-08 14:10:18 --> Helper loaded: form_helper
INFO - 2024-06-08 14:10:18 --> Helper loaded: my_helper
INFO - 2024-06-08 14:10:18 --> Database Driver Class Initialized
INFO - 2024-06-08 14:10:18 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-08 14:10:18 --> Controller Class Initialized
INFO - 2024-06-08 14:10:18 --> Config Class Initialized
INFO - 2024-06-08 14:10:18 --> Hooks Class Initialized
DEBUG - 2024-06-08 14:10:18 --> UTF-8 Support Enabled
INFO - 2024-06-08 14:10:18 --> Utf8 Class Initialized
INFO - 2024-06-08 14:10:18 --> URI Class Initialized
INFO - 2024-06-08 14:10:18 --> Router Class Initialized
INFO - 2024-06-08 14:10:18 --> Output Class Initialized
INFO - 2024-06-08 14:10:18 --> Security Class Initialized
DEBUG - 2024-06-08 14:10:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-08 14:10:18 --> Input Class Initialized
INFO - 2024-06-08 14:10:18 --> Language Class Initialized
INFO - 2024-06-08 14:10:18 --> Language Class Initialized
INFO - 2024-06-08 14:10:18 --> Config Class Initialized
INFO - 2024-06-08 14:10:18 --> Loader Class Initialized
INFO - 2024-06-08 14:10:18 --> Helper loaded: url_helper
INFO - 2024-06-08 14:10:18 --> Helper loaded: file_helper
INFO - 2024-06-08 14:10:18 --> Helper loaded: form_helper
INFO - 2024-06-08 14:10:18 --> Helper loaded: my_helper
INFO - 2024-06-08 14:10:18 --> Database Driver Class Initialized
INFO - 2024-06-08 14:10:18 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-08 14:10:18 --> Controller Class Initialized
DEBUG - 2024-06-08 14:10:18 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/login/views/login.php
DEBUG - 2024-06-08 14:10:18 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-06-08 14:10:18 --> Final output sent to browser
DEBUG - 2024-06-08 14:10:18 --> Total execution time: 0.0272
INFO - 2024-06-08 14:10:23 --> Config Class Initialized
INFO - 2024-06-08 14:10:23 --> Hooks Class Initialized
DEBUG - 2024-06-08 14:10:23 --> UTF-8 Support Enabled
INFO - 2024-06-08 14:10:23 --> Utf8 Class Initialized
INFO - 2024-06-08 14:10:23 --> URI Class Initialized
INFO - 2024-06-08 14:10:23 --> Router Class Initialized
INFO - 2024-06-08 14:10:23 --> Output Class Initialized
INFO - 2024-06-08 14:10:23 --> Security Class Initialized
DEBUG - 2024-06-08 14:10:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-08 14:10:23 --> Input Class Initialized
INFO - 2024-06-08 14:10:23 --> Language Class Initialized
INFO - 2024-06-08 14:10:23 --> Language Class Initialized
INFO - 2024-06-08 14:10:23 --> Config Class Initialized
INFO - 2024-06-08 14:10:23 --> Loader Class Initialized
INFO - 2024-06-08 14:10:23 --> Helper loaded: url_helper
INFO - 2024-06-08 14:10:23 --> Helper loaded: file_helper
INFO - 2024-06-08 14:10:23 --> Helper loaded: form_helper
INFO - 2024-06-08 14:10:23 --> Helper loaded: my_helper
INFO - 2024-06-08 14:10:23 --> Database Driver Class Initialized
INFO - 2024-06-08 14:10:23 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-08 14:10:23 --> Controller Class Initialized
INFO - 2024-06-08 14:10:23 --> Helper loaded: cookie_helper
INFO - 2024-06-08 14:10:23 --> Final output sent to browser
DEBUG - 2024-06-08 14:10:23 --> Total execution time: 0.0623
INFO - 2024-06-08 14:10:23 --> Config Class Initialized
INFO - 2024-06-08 14:10:23 --> Hooks Class Initialized
DEBUG - 2024-06-08 14:10:23 --> UTF-8 Support Enabled
INFO - 2024-06-08 14:10:23 --> Utf8 Class Initialized
INFO - 2024-06-08 14:10:23 --> URI Class Initialized
INFO - 2024-06-08 14:10:23 --> Router Class Initialized
INFO - 2024-06-08 14:10:23 --> Output Class Initialized
INFO - 2024-06-08 14:10:23 --> Security Class Initialized
DEBUG - 2024-06-08 14:10:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-08 14:10:23 --> Input Class Initialized
INFO - 2024-06-08 14:10:23 --> Language Class Initialized
INFO - 2024-06-08 14:10:23 --> Language Class Initialized
INFO - 2024-06-08 14:10:23 --> Config Class Initialized
INFO - 2024-06-08 14:10:23 --> Loader Class Initialized
INFO - 2024-06-08 14:10:23 --> Helper loaded: url_helper
INFO - 2024-06-08 14:10:23 --> Helper loaded: file_helper
INFO - 2024-06-08 14:10:23 --> Helper loaded: form_helper
INFO - 2024-06-08 14:10:23 --> Helper loaded: my_helper
INFO - 2024-06-08 14:10:23 --> Database Driver Class Initialized
INFO - 2024-06-08 14:10:23 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-08 14:10:23 --> Controller Class Initialized
DEBUG - 2024-06-08 14:10:23 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/home/views/v_home_guru.php
DEBUG - 2024-06-08 14:10:23 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-06-08 14:10:23 --> Final output sent to browser
DEBUG - 2024-06-08 14:10:23 --> Total execution time: 0.0690
INFO - 2024-06-08 14:10:26 --> Config Class Initialized
INFO - 2024-06-08 14:10:26 --> Hooks Class Initialized
DEBUG - 2024-06-08 14:10:26 --> UTF-8 Support Enabled
INFO - 2024-06-08 14:10:26 --> Utf8 Class Initialized
INFO - 2024-06-08 14:10:26 --> URI Class Initialized
INFO - 2024-06-08 14:10:26 --> Router Class Initialized
INFO - 2024-06-08 14:10:26 --> Output Class Initialized
INFO - 2024-06-08 14:10:26 --> Security Class Initialized
DEBUG - 2024-06-08 14:10:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-08 14:10:26 --> Input Class Initialized
INFO - 2024-06-08 14:10:26 --> Language Class Initialized
INFO - 2024-06-08 14:10:26 --> Language Class Initialized
INFO - 2024-06-08 14:10:26 --> Config Class Initialized
INFO - 2024-06-08 14:10:26 --> Loader Class Initialized
INFO - 2024-06-08 14:10:26 --> Helper loaded: url_helper
INFO - 2024-06-08 14:10:26 --> Helper loaded: file_helper
INFO - 2024-06-08 14:10:26 --> Helper loaded: form_helper
INFO - 2024-06-08 14:10:26 --> Helper loaded: my_helper
INFO - 2024-06-08 14:10:26 --> Database Driver Class Initialized
INFO - 2024-06-08 14:10:26 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-08 14:10:26 --> Controller Class Initialized
INFO - 2024-06-08 14:10:26 --> Helper loaded: cookie_helper
INFO - 2024-06-08 14:10:26 --> Config Class Initialized
INFO - 2024-06-08 14:10:26 --> Hooks Class Initialized
DEBUG - 2024-06-08 14:10:26 --> UTF-8 Support Enabled
INFO - 2024-06-08 14:10:26 --> Utf8 Class Initialized
INFO - 2024-06-08 14:10:26 --> URI Class Initialized
INFO - 2024-06-08 14:10:26 --> Router Class Initialized
INFO - 2024-06-08 14:10:26 --> Output Class Initialized
INFO - 2024-06-08 14:10:26 --> Security Class Initialized
DEBUG - 2024-06-08 14:10:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-08 14:10:26 --> Input Class Initialized
INFO - 2024-06-08 14:10:26 --> Language Class Initialized
INFO - 2024-06-08 14:10:26 --> Language Class Initialized
INFO - 2024-06-08 14:10:26 --> Config Class Initialized
INFO - 2024-06-08 14:10:26 --> Loader Class Initialized
INFO - 2024-06-08 14:10:26 --> Helper loaded: url_helper
INFO - 2024-06-08 14:10:26 --> Helper loaded: file_helper
INFO - 2024-06-08 14:10:26 --> Helper loaded: form_helper
INFO - 2024-06-08 14:10:26 --> Helper loaded: my_helper
INFO - 2024-06-08 14:10:26 --> Database Driver Class Initialized
INFO - 2024-06-08 14:10:26 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-08 14:10:26 --> Controller Class Initialized
INFO - 2024-06-08 14:10:27 --> Config Class Initialized
INFO - 2024-06-08 14:10:27 --> Hooks Class Initialized
DEBUG - 2024-06-08 14:10:27 --> UTF-8 Support Enabled
INFO - 2024-06-08 14:10:27 --> Utf8 Class Initialized
INFO - 2024-06-08 14:10:27 --> URI Class Initialized
INFO - 2024-06-08 14:10:27 --> Router Class Initialized
INFO - 2024-06-08 14:10:27 --> Output Class Initialized
INFO - 2024-06-08 14:10:27 --> Security Class Initialized
DEBUG - 2024-06-08 14:10:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-08 14:10:27 --> Input Class Initialized
INFO - 2024-06-08 14:10:27 --> Language Class Initialized
INFO - 2024-06-08 14:10:27 --> Language Class Initialized
INFO - 2024-06-08 14:10:27 --> Config Class Initialized
INFO - 2024-06-08 14:10:27 --> Loader Class Initialized
INFO - 2024-06-08 14:10:27 --> Helper loaded: url_helper
INFO - 2024-06-08 14:10:27 --> Helper loaded: file_helper
INFO - 2024-06-08 14:10:27 --> Helper loaded: form_helper
INFO - 2024-06-08 14:10:27 --> Helper loaded: my_helper
INFO - 2024-06-08 14:10:27 --> Database Driver Class Initialized
INFO - 2024-06-08 14:10:27 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-08 14:10:27 --> Controller Class Initialized
DEBUG - 2024-06-08 14:10:27 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/login/views/login.php
DEBUG - 2024-06-08 14:10:27 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-06-08 14:10:27 --> Final output sent to browser
DEBUG - 2024-06-08 14:10:27 --> Total execution time: 0.0698
INFO - 2024-06-08 14:11:02 --> Config Class Initialized
INFO - 2024-06-08 14:11:02 --> Hooks Class Initialized
DEBUG - 2024-06-08 14:11:02 --> UTF-8 Support Enabled
INFO - 2024-06-08 14:11:02 --> Utf8 Class Initialized
INFO - 2024-06-08 14:11:02 --> URI Class Initialized
INFO - 2024-06-08 14:11:02 --> Router Class Initialized
INFO - 2024-06-08 14:11:02 --> Output Class Initialized
INFO - 2024-06-08 14:11:02 --> Security Class Initialized
DEBUG - 2024-06-08 14:11:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-08 14:11:02 --> Input Class Initialized
INFO - 2024-06-08 14:11:02 --> Language Class Initialized
INFO - 2024-06-08 14:11:02 --> Language Class Initialized
INFO - 2024-06-08 14:11:02 --> Config Class Initialized
INFO - 2024-06-08 14:11:02 --> Loader Class Initialized
INFO - 2024-06-08 14:11:02 --> Helper loaded: url_helper
INFO - 2024-06-08 14:11:02 --> Helper loaded: file_helper
INFO - 2024-06-08 14:11:02 --> Helper loaded: form_helper
INFO - 2024-06-08 14:11:02 --> Helper loaded: my_helper
INFO - 2024-06-08 14:11:02 --> Database Driver Class Initialized
INFO - 2024-06-08 14:11:02 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-08 14:11:02 --> Controller Class Initialized
DEBUG - 2024-06-08 14:11:02 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/home/views/v_home_guru.php
DEBUG - 2024-06-08 14:11:02 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-06-08 14:11:02 --> Final output sent to browser
DEBUG - 2024-06-08 14:11:02 --> Total execution time: 0.4481
INFO - 2024-06-08 14:11:05 --> Config Class Initialized
INFO - 2024-06-08 14:11:05 --> Hooks Class Initialized
DEBUG - 2024-06-08 14:11:05 --> UTF-8 Support Enabled
INFO - 2024-06-08 14:11:05 --> Utf8 Class Initialized
INFO - 2024-06-08 14:11:05 --> URI Class Initialized
INFO - 2024-06-08 14:11:05 --> Router Class Initialized
INFO - 2024-06-08 14:11:05 --> Output Class Initialized
INFO - 2024-06-08 14:11:05 --> Security Class Initialized
DEBUG - 2024-06-08 14:11:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-08 14:11:05 --> Input Class Initialized
INFO - 2024-06-08 14:11:05 --> Language Class Initialized
INFO - 2024-06-08 14:11:05 --> Language Class Initialized
INFO - 2024-06-08 14:11:05 --> Config Class Initialized
INFO - 2024-06-08 14:11:05 --> Loader Class Initialized
INFO - 2024-06-08 14:11:05 --> Helper loaded: url_helper
INFO - 2024-06-08 14:11:05 --> Helper loaded: file_helper
INFO - 2024-06-08 14:11:05 --> Helper loaded: form_helper
INFO - 2024-06-08 14:11:05 --> Helper loaded: my_helper
INFO - 2024-06-08 14:11:05 --> Database Driver Class Initialized
INFO - 2024-06-08 14:11:05 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-08 14:11:05 --> Controller Class Initialized
INFO - 2024-06-08 14:11:05 --> Helper loaded: cookie_helper
INFO - 2024-06-08 14:11:05 --> Config Class Initialized
INFO - 2024-06-08 14:11:05 --> Hooks Class Initialized
DEBUG - 2024-06-08 14:11:05 --> UTF-8 Support Enabled
INFO - 2024-06-08 14:11:05 --> Utf8 Class Initialized
INFO - 2024-06-08 14:11:05 --> URI Class Initialized
INFO - 2024-06-08 14:11:06 --> Router Class Initialized
INFO - 2024-06-08 14:11:06 --> Output Class Initialized
INFO - 2024-06-08 14:11:06 --> Security Class Initialized
DEBUG - 2024-06-08 14:11:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-08 14:11:06 --> Input Class Initialized
INFO - 2024-06-08 14:11:06 --> Language Class Initialized
INFO - 2024-06-08 14:11:06 --> Language Class Initialized
INFO - 2024-06-08 14:11:06 --> Config Class Initialized
INFO - 2024-06-08 14:11:06 --> Loader Class Initialized
INFO - 2024-06-08 14:11:06 --> Helper loaded: url_helper
INFO - 2024-06-08 14:11:06 --> Helper loaded: file_helper
INFO - 2024-06-08 14:11:06 --> Helper loaded: form_helper
INFO - 2024-06-08 14:11:06 --> Helper loaded: my_helper
INFO - 2024-06-08 14:11:06 --> Database Driver Class Initialized
INFO - 2024-06-08 14:11:06 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-08 14:11:06 --> Controller Class Initialized
INFO - 2024-06-08 14:11:06 --> Config Class Initialized
INFO - 2024-06-08 14:11:06 --> Hooks Class Initialized
DEBUG - 2024-06-08 14:11:06 --> UTF-8 Support Enabled
INFO - 2024-06-08 14:11:06 --> Utf8 Class Initialized
INFO - 2024-06-08 14:11:06 --> URI Class Initialized
INFO - 2024-06-08 14:11:06 --> Router Class Initialized
INFO - 2024-06-08 14:11:06 --> Output Class Initialized
INFO - 2024-06-08 14:11:06 --> Security Class Initialized
DEBUG - 2024-06-08 14:11:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-08 14:11:06 --> Input Class Initialized
INFO - 2024-06-08 14:11:06 --> Language Class Initialized
INFO - 2024-06-08 14:11:06 --> Language Class Initialized
INFO - 2024-06-08 14:11:06 --> Config Class Initialized
INFO - 2024-06-08 14:11:06 --> Loader Class Initialized
INFO - 2024-06-08 14:11:06 --> Helper loaded: url_helper
INFO - 2024-06-08 14:11:06 --> Helper loaded: file_helper
INFO - 2024-06-08 14:11:06 --> Helper loaded: form_helper
INFO - 2024-06-08 14:11:06 --> Helper loaded: my_helper
INFO - 2024-06-08 14:11:06 --> Database Driver Class Initialized
INFO - 2024-06-08 14:11:06 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-08 14:11:06 --> Controller Class Initialized
DEBUG - 2024-06-08 14:11:06 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/login/views/login.php
DEBUG - 2024-06-08 14:11:06 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-06-08 14:11:06 --> Final output sent to browser
DEBUG - 2024-06-08 14:11:06 --> Total execution time: 0.0815
INFO - 2024-06-08 14:11:08 --> Config Class Initialized
INFO - 2024-06-08 14:11:08 --> Hooks Class Initialized
DEBUG - 2024-06-08 14:11:08 --> UTF-8 Support Enabled
INFO - 2024-06-08 14:11:08 --> Utf8 Class Initialized
INFO - 2024-06-08 14:11:08 --> URI Class Initialized
INFO - 2024-06-08 14:11:08 --> Router Class Initialized
INFO - 2024-06-08 14:11:08 --> Output Class Initialized
INFO - 2024-06-08 14:11:08 --> Security Class Initialized
DEBUG - 2024-06-08 14:11:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-08 14:11:08 --> Input Class Initialized
INFO - 2024-06-08 14:11:08 --> Language Class Initialized
INFO - 2024-06-08 14:11:09 --> Language Class Initialized
INFO - 2024-06-08 14:11:09 --> Config Class Initialized
INFO - 2024-06-08 14:11:09 --> Loader Class Initialized
INFO - 2024-06-08 14:11:09 --> Helper loaded: url_helper
INFO - 2024-06-08 14:11:09 --> Helper loaded: file_helper
INFO - 2024-06-08 14:11:09 --> Helper loaded: form_helper
INFO - 2024-06-08 14:11:09 --> Helper loaded: my_helper
INFO - 2024-06-08 14:11:09 --> Database Driver Class Initialized
INFO - 2024-06-08 14:11:09 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-08 14:11:09 --> Controller Class Initialized
INFO - 2024-06-08 14:11:09 --> Helper loaded: cookie_helper
INFO - 2024-06-08 14:11:09 --> Final output sent to browser
DEBUG - 2024-06-08 14:11:09 --> Total execution time: 0.7483
INFO - 2024-06-08 14:11:09 --> Config Class Initialized
INFO - 2024-06-08 14:11:09 --> Hooks Class Initialized
DEBUG - 2024-06-08 14:11:09 --> UTF-8 Support Enabled
INFO - 2024-06-08 14:11:09 --> Utf8 Class Initialized
INFO - 2024-06-08 14:11:09 --> URI Class Initialized
INFO - 2024-06-08 14:11:09 --> Router Class Initialized
INFO - 2024-06-08 14:11:09 --> Output Class Initialized
INFO - 2024-06-08 14:11:09 --> Security Class Initialized
DEBUG - 2024-06-08 14:11:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-08 14:11:09 --> Input Class Initialized
INFO - 2024-06-08 14:11:09 --> Language Class Initialized
INFO - 2024-06-08 14:11:09 --> Language Class Initialized
INFO - 2024-06-08 14:11:09 --> Config Class Initialized
INFO - 2024-06-08 14:11:09 --> Loader Class Initialized
INFO - 2024-06-08 14:11:09 --> Helper loaded: url_helper
INFO - 2024-06-08 14:11:09 --> Helper loaded: file_helper
INFO - 2024-06-08 14:11:09 --> Helper loaded: form_helper
INFO - 2024-06-08 14:11:09 --> Helper loaded: my_helper
INFO - 2024-06-08 14:11:09 --> Database Driver Class Initialized
INFO - 2024-06-08 14:11:09 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-08 14:11:09 --> Controller Class Initialized
DEBUG - 2024-06-08 14:11:09 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/home/views/v_home_guru.php
DEBUG - 2024-06-08 14:11:09 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-06-08 14:11:09 --> Final output sent to browser
DEBUG - 2024-06-08 14:11:09 --> Total execution time: 0.1159
INFO - 2024-06-08 14:11:11 --> Config Class Initialized
INFO - 2024-06-08 14:11:11 --> Hooks Class Initialized
DEBUG - 2024-06-08 14:11:11 --> UTF-8 Support Enabled
INFO - 2024-06-08 14:11:11 --> Utf8 Class Initialized
INFO - 2024-06-08 14:11:11 --> URI Class Initialized
INFO - 2024-06-08 14:11:11 --> Router Class Initialized
INFO - 2024-06-08 14:11:11 --> Output Class Initialized
INFO - 2024-06-08 14:11:11 --> Security Class Initialized
DEBUG - 2024-06-08 14:11:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-08 14:11:11 --> Input Class Initialized
INFO - 2024-06-08 14:11:11 --> Language Class Initialized
INFO - 2024-06-08 14:11:11 --> Language Class Initialized
INFO - 2024-06-08 14:11:11 --> Config Class Initialized
INFO - 2024-06-08 14:11:11 --> Loader Class Initialized
INFO - 2024-06-08 14:11:11 --> Helper loaded: url_helper
INFO - 2024-06-08 14:11:11 --> Helper loaded: file_helper
INFO - 2024-06-08 14:11:11 --> Helper loaded: form_helper
INFO - 2024-06-08 14:11:11 --> Helper loaded: my_helper
INFO - 2024-06-08 14:11:11 --> Database Driver Class Initialized
INFO - 2024-06-08 14:11:11 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-08 14:11:11 --> Controller Class Initialized
DEBUG - 2024-06-08 14:11:12 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/view_mapel/views/v_view_mapel.php
DEBUG - 2024-06-08 14:11:12 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-06-08 14:11:12 --> Final output sent to browser
DEBUG - 2024-06-08 14:11:12 --> Total execution time: 0.2739
INFO - 2024-06-08 14:11:15 --> Config Class Initialized
INFO - 2024-06-08 14:11:15 --> Hooks Class Initialized
DEBUG - 2024-06-08 14:11:15 --> UTF-8 Support Enabled
INFO - 2024-06-08 14:11:15 --> Utf8 Class Initialized
INFO - 2024-06-08 14:11:15 --> URI Class Initialized
INFO - 2024-06-08 14:11:15 --> Router Class Initialized
INFO - 2024-06-08 14:11:15 --> Output Class Initialized
INFO - 2024-06-08 14:11:15 --> Security Class Initialized
DEBUG - 2024-06-08 14:11:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-08 14:11:15 --> Input Class Initialized
INFO - 2024-06-08 14:11:15 --> Language Class Initialized
INFO - 2024-06-08 14:11:15 --> Language Class Initialized
INFO - 2024-06-08 14:11:15 --> Config Class Initialized
INFO - 2024-06-08 14:11:15 --> Loader Class Initialized
INFO - 2024-06-08 14:11:15 --> Helper loaded: url_helper
INFO - 2024-06-08 14:11:15 --> Helper loaded: file_helper
INFO - 2024-06-08 14:11:15 --> Helper loaded: form_helper
INFO - 2024-06-08 14:11:15 --> Helper loaded: my_helper
INFO - 2024-06-08 14:11:15 --> Database Driver Class Initialized
INFO - 2024-06-08 14:11:15 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-08 14:11:15 --> Controller Class Initialized
DEBUG - 2024-06-08 14:11:15 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_catatan_guru/views/list.php
DEBUG - 2024-06-08 14:11:15 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-06-08 14:11:15 --> Final output sent to browser
DEBUG - 2024-06-08 14:11:15 --> Total execution time: 0.0659
INFO - 2024-06-08 14:11:17 --> Config Class Initialized
INFO - 2024-06-08 14:11:17 --> Hooks Class Initialized
DEBUG - 2024-06-08 14:11:17 --> UTF-8 Support Enabled
INFO - 2024-06-08 14:11:17 --> Utf8 Class Initialized
INFO - 2024-06-08 14:11:17 --> URI Class Initialized
INFO - 2024-06-08 14:11:17 --> Router Class Initialized
INFO - 2024-06-08 14:11:17 --> Output Class Initialized
INFO - 2024-06-08 14:11:17 --> Security Class Initialized
DEBUG - 2024-06-08 14:11:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-08 14:11:17 --> Input Class Initialized
INFO - 2024-06-08 14:11:17 --> Language Class Initialized
INFO - 2024-06-08 14:11:17 --> Language Class Initialized
INFO - 2024-06-08 14:11:17 --> Config Class Initialized
INFO - 2024-06-08 14:11:17 --> Loader Class Initialized
INFO - 2024-06-08 14:11:17 --> Helper loaded: url_helper
INFO - 2024-06-08 14:11:17 --> Helper loaded: file_helper
INFO - 2024-06-08 14:11:17 --> Helper loaded: form_helper
INFO - 2024-06-08 14:11:17 --> Helper loaded: my_helper
INFO - 2024-06-08 14:11:17 --> Database Driver Class Initialized
INFO - 2024-06-08 14:11:17 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-08 14:11:17 --> Controller Class Initialized
INFO - 2024-06-08 14:11:26 --> Config Class Initialized
INFO - 2024-06-08 14:11:26 --> Hooks Class Initialized
DEBUG - 2024-06-08 14:11:26 --> UTF-8 Support Enabled
INFO - 2024-06-08 14:11:26 --> Utf8 Class Initialized
INFO - 2024-06-08 14:11:26 --> URI Class Initialized
INFO - 2024-06-08 14:11:26 --> Router Class Initialized
INFO - 2024-06-08 14:11:26 --> Output Class Initialized
INFO - 2024-06-08 14:11:26 --> Security Class Initialized
DEBUG - 2024-06-08 14:11:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-08 14:11:26 --> Input Class Initialized
INFO - 2024-06-08 14:11:26 --> Language Class Initialized
INFO - 2024-06-08 14:11:26 --> Language Class Initialized
INFO - 2024-06-08 14:11:26 --> Config Class Initialized
INFO - 2024-06-08 14:11:26 --> Loader Class Initialized
INFO - 2024-06-08 14:11:26 --> Helper loaded: url_helper
INFO - 2024-06-08 14:11:26 --> Helper loaded: file_helper
INFO - 2024-06-08 14:11:26 --> Helper loaded: form_helper
INFO - 2024-06-08 14:11:26 --> Helper loaded: my_helper
INFO - 2024-06-08 14:11:26 --> Database Driver Class Initialized
INFO - 2024-06-08 14:11:26 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-08 14:11:26 --> Controller Class Initialized
DEBUG - 2024-06-08 14:11:26 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/view_mapel/views/v_view_mapel.php
DEBUG - 2024-06-08 14:11:26 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-06-08 14:11:26 --> Final output sent to browser
DEBUG - 2024-06-08 14:11:26 --> Total execution time: 0.0518
INFO - 2024-06-08 14:25:52 --> Config Class Initialized
INFO - 2024-06-08 14:25:52 --> Hooks Class Initialized
DEBUG - 2024-06-08 14:25:52 --> UTF-8 Support Enabled
INFO - 2024-06-08 14:25:52 --> Utf8 Class Initialized
INFO - 2024-06-08 14:25:52 --> URI Class Initialized
INFO - 2024-06-08 14:25:52 --> Router Class Initialized
INFO - 2024-06-08 14:25:52 --> Output Class Initialized
INFO - 2024-06-08 14:25:52 --> Security Class Initialized
DEBUG - 2024-06-08 14:25:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-08 14:25:52 --> Input Class Initialized
INFO - 2024-06-08 14:25:52 --> Language Class Initialized
INFO - 2024-06-08 14:25:52 --> Language Class Initialized
INFO - 2024-06-08 14:25:52 --> Config Class Initialized
INFO - 2024-06-08 14:25:52 --> Loader Class Initialized
INFO - 2024-06-08 14:25:52 --> Helper loaded: url_helper
INFO - 2024-06-08 14:25:52 --> Helper loaded: file_helper
INFO - 2024-06-08 14:25:52 --> Helper loaded: form_helper
INFO - 2024-06-08 14:25:52 --> Helper loaded: my_helper
INFO - 2024-06-08 14:25:52 --> Database Driver Class Initialized
INFO - 2024-06-08 14:25:52 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-08 14:25:52 --> Controller Class Initialized
INFO - 2024-06-08 14:29:37 --> Config Class Initialized
INFO - 2024-06-08 14:29:37 --> Hooks Class Initialized
DEBUG - 2024-06-08 14:29:37 --> UTF-8 Support Enabled
INFO - 2024-06-08 14:29:37 --> Utf8 Class Initialized
INFO - 2024-06-08 14:29:37 --> URI Class Initialized
DEBUG - 2024-06-08 14:29:37 --> No URI present. Default controller set.
INFO - 2024-06-08 14:29:37 --> Router Class Initialized
INFO - 2024-06-08 14:29:37 --> Output Class Initialized
INFO - 2024-06-08 14:29:37 --> Security Class Initialized
DEBUG - 2024-06-08 14:29:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-08 14:29:37 --> Input Class Initialized
INFO - 2024-06-08 14:29:37 --> Language Class Initialized
INFO - 2024-06-08 14:29:37 --> Language Class Initialized
INFO - 2024-06-08 14:29:37 --> Config Class Initialized
INFO - 2024-06-08 14:29:37 --> Loader Class Initialized
INFO - 2024-06-08 14:29:37 --> Helper loaded: url_helper
INFO - 2024-06-08 14:29:37 --> Helper loaded: file_helper
INFO - 2024-06-08 14:29:37 --> Helper loaded: form_helper
INFO - 2024-06-08 14:29:37 --> Helper loaded: my_helper
INFO - 2024-06-08 14:29:37 --> Database Driver Class Initialized
INFO - 2024-06-08 14:29:37 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-08 14:29:37 --> Controller Class Initialized
INFO - 2024-06-08 14:29:37 --> Config Class Initialized
INFO - 2024-06-08 14:29:37 --> Hooks Class Initialized
DEBUG - 2024-06-08 14:29:37 --> UTF-8 Support Enabled
INFO - 2024-06-08 14:29:37 --> Utf8 Class Initialized
INFO - 2024-06-08 14:29:37 --> URI Class Initialized
INFO - 2024-06-08 14:29:37 --> Router Class Initialized
INFO - 2024-06-08 14:29:37 --> Output Class Initialized
INFO - 2024-06-08 14:29:37 --> Security Class Initialized
DEBUG - 2024-06-08 14:29:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-08 14:29:37 --> Input Class Initialized
INFO - 2024-06-08 14:29:37 --> Language Class Initialized
INFO - 2024-06-08 14:29:37 --> Language Class Initialized
INFO - 2024-06-08 14:29:37 --> Config Class Initialized
INFO - 2024-06-08 14:29:37 --> Loader Class Initialized
INFO - 2024-06-08 14:29:37 --> Helper loaded: url_helper
INFO - 2024-06-08 14:29:37 --> Helper loaded: file_helper
INFO - 2024-06-08 14:29:37 --> Helper loaded: form_helper
INFO - 2024-06-08 14:29:37 --> Helper loaded: my_helper
INFO - 2024-06-08 14:29:37 --> Database Driver Class Initialized
INFO - 2024-06-08 14:29:38 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-08 14:29:38 --> Controller Class Initialized
DEBUG - 2024-06-08 14:29:38 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/login/views/login.php
DEBUG - 2024-06-08 14:29:38 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-06-08 14:29:38 --> Final output sent to browser
DEBUG - 2024-06-08 14:29:38 --> Total execution time: 0.0989
INFO - 2024-06-08 14:29:43 --> Config Class Initialized
INFO - 2024-06-08 14:29:43 --> Hooks Class Initialized
DEBUG - 2024-06-08 14:29:43 --> UTF-8 Support Enabled
INFO - 2024-06-08 14:29:43 --> Utf8 Class Initialized
INFO - 2024-06-08 14:29:43 --> URI Class Initialized
INFO - 2024-06-08 14:29:43 --> Router Class Initialized
INFO - 2024-06-08 14:29:43 --> Output Class Initialized
INFO - 2024-06-08 14:29:43 --> Security Class Initialized
DEBUG - 2024-06-08 14:29:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-08 14:29:43 --> Input Class Initialized
INFO - 2024-06-08 14:29:43 --> Language Class Initialized
INFO - 2024-06-08 14:29:43 --> Language Class Initialized
INFO - 2024-06-08 14:29:43 --> Config Class Initialized
INFO - 2024-06-08 14:29:43 --> Loader Class Initialized
INFO - 2024-06-08 14:29:43 --> Helper loaded: url_helper
INFO - 2024-06-08 14:29:43 --> Helper loaded: file_helper
INFO - 2024-06-08 14:29:43 --> Helper loaded: form_helper
INFO - 2024-06-08 14:29:43 --> Helper loaded: my_helper
INFO - 2024-06-08 14:29:43 --> Database Driver Class Initialized
INFO - 2024-06-08 14:29:43 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-08 14:29:43 --> Controller Class Initialized
INFO - 2024-06-08 14:29:43 --> Helper loaded: cookie_helper
INFO - 2024-06-08 14:29:43 --> Final output sent to browser
DEBUG - 2024-06-08 14:29:43 --> Total execution time: 0.1565
INFO - 2024-06-08 14:29:43 --> Config Class Initialized
INFO - 2024-06-08 14:29:43 --> Hooks Class Initialized
DEBUG - 2024-06-08 14:29:43 --> UTF-8 Support Enabled
INFO - 2024-06-08 14:29:43 --> Utf8 Class Initialized
INFO - 2024-06-08 14:29:43 --> URI Class Initialized
INFO - 2024-06-08 14:29:43 --> Router Class Initialized
INFO - 2024-06-08 14:29:43 --> Output Class Initialized
INFO - 2024-06-08 14:29:43 --> Security Class Initialized
DEBUG - 2024-06-08 14:29:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-08 14:29:43 --> Input Class Initialized
INFO - 2024-06-08 14:29:43 --> Language Class Initialized
INFO - 2024-06-08 14:29:43 --> Language Class Initialized
INFO - 2024-06-08 14:29:43 --> Config Class Initialized
INFO - 2024-06-08 14:29:43 --> Loader Class Initialized
INFO - 2024-06-08 14:29:43 --> Helper loaded: url_helper
INFO - 2024-06-08 14:29:43 --> Helper loaded: file_helper
INFO - 2024-06-08 14:29:43 --> Helper loaded: form_helper
INFO - 2024-06-08 14:29:43 --> Helper loaded: my_helper
INFO - 2024-06-08 14:29:43 --> Database Driver Class Initialized
INFO - 2024-06-08 14:29:43 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-08 14:29:43 --> Controller Class Initialized
DEBUG - 2024-06-08 14:29:43 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/home/views/v_home_guru.php
DEBUG - 2024-06-08 14:29:43 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-06-08 14:29:43 --> Final output sent to browser
DEBUG - 2024-06-08 14:29:43 --> Total execution time: 0.1206
INFO - 2024-06-08 14:29:52 --> Config Class Initialized
INFO - 2024-06-08 14:29:52 --> Hooks Class Initialized
DEBUG - 2024-06-08 14:29:52 --> UTF-8 Support Enabled
INFO - 2024-06-08 14:29:52 --> Utf8 Class Initialized
INFO - 2024-06-08 14:29:52 --> URI Class Initialized
INFO - 2024-06-08 14:29:52 --> Router Class Initialized
INFO - 2024-06-08 14:29:52 --> Output Class Initialized
INFO - 2024-06-08 14:29:52 --> Security Class Initialized
DEBUG - 2024-06-08 14:29:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-08 14:29:52 --> Input Class Initialized
INFO - 2024-06-08 14:29:52 --> Language Class Initialized
INFO - 2024-06-08 14:29:52 --> Language Class Initialized
INFO - 2024-06-08 14:29:52 --> Config Class Initialized
INFO - 2024-06-08 14:29:52 --> Loader Class Initialized
INFO - 2024-06-08 14:29:52 --> Helper loaded: url_helper
INFO - 2024-06-08 14:29:52 --> Helper loaded: file_helper
INFO - 2024-06-08 14:29:52 --> Helper loaded: form_helper
INFO - 2024-06-08 14:29:52 --> Helper loaded: my_helper
INFO - 2024-06-08 14:29:52 --> Database Driver Class Initialized
INFO - 2024-06-08 14:29:52 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-08 14:29:52 --> Controller Class Initialized
DEBUG - 2024-06-08 14:29:52 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/view_mapel/views/v_view_mapel.php
DEBUG - 2024-06-08 14:29:52 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-06-08 14:29:52 --> Final output sent to browser
DEBUG - 2024-06-08 14:29:52 --> Total execution time: 0.1183
INFO - 2024-06-08 14:29:54 --> Config Class Initialized
INFO - 2024-06-08 14:29:54 --> Hooks Class Initialized
DEBUG - 2024-06-08 14:29:54 --> UTF-8 Support Enabled
INFO - 2024-06-08 14:29:54 --> Utf8 Class Initialized
INFO - 2024-06-08 14:29:54 --> URI Class Initialized
INFO - 2024-06-08 14:29:54 --> Router Class Initialized
INFO - 2024-06-08 14:29:54 --> Output Class Initialized
INFO - 2024-06-08 14:29:54 --> Security Class Initialized
DEBUG - 2024-06-08 14:29:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-08 14:29:54 --> Input Class Initialized
INFO - 2024-06-08 14:29:54 --> Language Class Initialized
INFO - 2024-06-08 14:29:54 --> Language Class Initialized
INFO - 2024-06-08 14:29:54 --> Config Class Initialized
INFO - 2024-06-08 14:29:54 --> Loader Class Initialized
INFO - 2024-06-08 14:29:54 --> Helper loaded: url_helper
INFO - 2024-06-08 14:29:54 --> Helper loaded: file_helper
INFO - 2024-06-08 14:29:54 --> Helper loaded: form_helper
INFO - 2024-06-08 14:29:54 --> Helper loaded: my_helper
INFO - 2024-06-08 14:29:54 --> Database Driver Class Initialized
INFO - 2024-06-08 14:29:54 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-08 14:29:54 --> Controller Class Initialized
DEBUG - 2024-06-08 14:29:54 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/views/list.php
DEBUG - 2024-06-08 14:29:54 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-06-08 14:29:54 --> Final output sent to browser
DEBUG - 2024-06-08 14:29:54 --> Total execution time: 0.2659
INFO - 2024-06-08 14:29:54 --> Config Class Initialized
INFO - 2024-06-08 14:29:54 --> Hooks Class Initialized
DEBUG - 2024-06-08 14:29:54 --> UTF-8 Support Enabled
INFO - 2024-06-08 14:29:54 --> Utf8 Class Initialized
INFO - 2024-06-08 14:29:54 --> URI Class Initialized
INFO - 2024-06-08 14:29:54 --> Router Class Initialized
INFO - 2024-06-08 14:29:54 --> Output Class Initialized
INFO - 2024-06-08 14:29:54 --> Security Class Initialized
DEBUG - 2024-06-08 14:29:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-08 14:29:54 --> Input Class Initialized
INFO - 2024-06-08 14:29:55 --> Language Class Initialized
INFO - 2024-06-08 14:29:55 --> Language Class Initialized
INFO - 2024-06-08 14:29:55 --> Config Class Initialized
INFO - 2024-06-08 14:29:55 --> Loader Class Initialized
INFO - 2024-06-08 14:29:55 --> Helper loaded: url_helper
INFO - 2024-06-08 14:29:55 --> Helper loaded: file_helper
INFO - 2024-06-08 14:29:55 --> Helper loaded: form_helper
INFO - 2024-06-08 14:29:55 --> Helper loaded: my_helper
INFO - 2024-06-08 14:29:55 --> Database Driver Class Initialized
INFO - 2024-06-08 14:29:55 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-08 14:29:55 --> Controller Class Initialized
INFO - 2024-06-08 14:29:56 --> Config Class Initialized
INFO - 2024-06-08 14:29:56 --> Hooks Class Initialized
DEBUG - 2024-06-08 14:29:56 --> UTF-8 Support Enabled
INFO - 2024-06-08 14:29:56 --> Utf8 Class Initialized
INFO - 2024-06-08 14:29:56 --> URI Class Initialized
INFO - 2024-06-08 14:29:56 --> Router Class Initialized
INFO - 2024-06-08 14:29:56 --> Output Class Initialized
INFO - 2024-06-08 14:29:56 --> Security Class Initialized
DEBUG - 2024-06-08 14:29:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-08 14:29:56 --> Input Class Initialized
INFO - 2024-06-08 14:29:56 --> Language Class Initialized
INFO - 2024-06-08 14:29:56 --> Language Class Initialized
INFO - 2024-06-08 14:29:56 --> Config Class Initialized
INFO - 2024-06-08 14:29:56 --> Loader Class Initialized
INFO - 2024-06-08 14:29:56 --> Helper loaded: url_helper
INFO - 2024-06-08 14:29:56 --> Helper loaded: file_helper
INFO - 2024-06-08 14:29:56 --> Helper loaded: form_helper
INFO - 2024-06-08 14:29:56 --> Helper loaded: my_helper
INFO - 2024-06-08 14:29:57 --> Database Driver Class Initialized
INFO - 2024-06-08 14:29:57 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-08 14:29:57 --> Controller Class Initialized
INFO - 2024-06-08 14:29:57 --> Final output sent to browser
DEBUG - 2024-06-08 14:29:57 --> Total execution time: 0.4939
INFO - 2024-06-08 14:30:06 --> Config Class Initialized
INFO - 2024-06-08 14:30:06 --> Hooks Class Initialized
DEBUG - 2024-06-08 14:30:06 --> UTF-8 Support Enabled
INFO - 2024-06-08 14:30:06 --> Utf8 Class Initialized
INFO - 2024-06-08 14:30:06 --> URI Class Initialized
INFO - 2024-06-08 14:30:06 --> Router Class Initialized
INFO - 2024-06-08 14:30:06 --> Output Class Initialized
INFO - 2024-06-08 14:30:06 --> Security Class Initialized
DEBUG - 2024-06-08 14:30:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-08 14:30:06 --> Input Class Initialized
INFO - 2024-06-08 14:30:06 --> Language Class Initialized
INFO - 2024-06-08 14:30:06 --> Language Class Initialized
INFO - 2024-06-08 14:30:06 --> Config Class Initialized
INFO - 2024-06-08 14:30:06 --> Loader Class Initialized
INFO - 2024-06-08 14:30:06 --> Helper loaded: url_helper
INFO - 2024-06-08 14:30:06 --> Helper loaded: file_helper
INFO - 2024-06-08 14:30:06 --> Helper loaded: form_helper
INFO - 2024-06-08 14:30:06 --> Helper loaded: my_helper
INFO - 2024-06-08 14:30:06 --> Database Driver Class Initialized
INFO - 2024-06-08 14:30:06 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-08 14:30:06 --> Controller Class Initialized
INFO - 2024-06-08 14:30:06 --> Final output sent to browser
DEBUG - 2024-06-08 14:30:06 --> Total execution time: 0.0662
INFO - 2024-06-08 14:30:06 --> Config Class Initialized
INFO - 2024-06-08 14:30:06 --> Hooks Class Initialized
DEBUG - 2024-06-08 14:30:06 --> UTF-8 Support Enabled
INFO - 2024-06-08 14:30:06 --> Utf8 Class Initialized
INFO - 2024-06-08 14:30:06 --> URI Class Initialized
INFO - 2024-06-08 14:30:06 --> Router Class Initialized
INFO - 2024-06-08 14:30:06 --> Output Class Initialized
INFO - 2024-06-08 14:30:06 --> Security Class Initialized
DEBUG - 2024-06-08 14:30:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-08 14:30:06 --> Input Class Initialized
INFO - 2024-06-08 14:30:06 --> Language Class Initialized
INFO - 2024-06-08 14:30:06 --> Language Class Initialized
INFO - 2024-06-08 14:30:06 --> Config Class Initialized
INFO - 2024-06-08 14:30:06 --> Loader Class Initialized
INFO - 2024-06-08 14:30:06 --> Helper loaded: url_helper
INFO - 2024-06-08 14:30:06 --> Helper loaded: file_helper
INFO - 2024-06-08 14:30:06 --> Helper loaded: form_helper
INFO - 2024-06-08 14:30:06 --> Helper loaded: my_helper
INFO - 2024-06-08 14:30:06 --> Database Driver Class Initialized
INFO - 2024-06-08 14:30:06 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-08 14:30:06 --> Controller Class Initialized
INFO - 2024-06-08 14:30:11 --> Config Class Initialized
INFO - 2024-06-08 14:30:11 --> Hooks Class Initialized
DEBUG - 2024-06-08 14:30:11 --> UTF-8 Support Enabled
INFO - 2024-06-08 14:30:11 --> Utf8 Class Initialized
INFO - 2024-06-08 14:30:11 --> URI Class Initialized
INFO - 2024-06-08 14:30:11 --> Router Class Initialized
INFO - 2024-06-08 14:30:11 --> Output Class Initialized
INFO - 2024-06-08 14:30:11 --> Security Class Initialized
DEBUG - 2024-06-08 14:30:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-08 14:30:11 --> Input Class Initialized
INFO - 2024-06-08 14:30:11 --> Language Class Initialized
INFO - 2024-06-08 14:30:11 --> Language Class Initialized
INFO - 2024-06-08 14:30:11 --> Config Class Initialized
INFO - 2024-06-08 14:30:11 --> Loader Class Initialized
INFO - 2024-06-08 14:30:11 --> Helper loaded: url_helper
INFO - 2024-06-08 14:30:11 --> Helper loaded: file_helper
INFO - 2024-06-08 14:30:11 --> Helper loaded: form_helper
INFO - 2024-06-08 14:30:11 --> Helper loaded: my_helper
INFO - 2024-06-08 14:30:11 --> Database Driver Class Initialized
INFO - 2024-06-08 14:30:11 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-08 14:30:11 --> Controller Class Initialized
INFO - 2024-06-08 14:30:11 --> Final output sent to browser
DEBUG - 2024-06-08 14:30:11 --> Total execution time: 0.4174
INFO - 2024-06-08 14:33:46 --> Config Class Initialized
INFO - 2024-06-08 14:33:46 --> Hooks Class Initialized
DEBUG - 2024-06-08 14:33:46 --> UTF-8 Support Enabled
INFO - 2024-06-08 14:33:46 --> Utf8 Class Initialized
INFO - 2024-06-08 14:33:46 --> URI Class Initialized
INFO - 2024-06-08 14:33:46 --> Router Class Initialized
INFO - 2024-06-08 14:33:46 --> Output Class Initialized
INFO - 2024-06-08 14:33:46 --> Security Class Initialized
DEBUG - 2024-06-08 14:33:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-08 14:33:46 --> Input Class Initialized
INFO - 2024-06-08 14:33:46 --> Language Class Initialized
INFO - 2024-06-08 14:33:46 --> Language Class Initialized
INFO - 2024-06-08 14:33:46 --> Config Class Initialized
INFO - 2024-06-08 14:33:46 --> Loader Class Initialized
INFO - 2024-06-08 14:33:46 --> Helper loaded: url_helper
INFO - 2024-06-08 14:33:46 --> Helper loaded: file_helper
INFO - 2024-06-08 14:33:46 --> Helper loaded: form_helper
INFO - 2024-06-08 14:33:46 --> Helper loaded: my_helper
INFO - 2024-06-08 14:33:46 --> Database Driver Class Initialized
INFO - 2024-06-08 14:33:46 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-08 14:33:46 --> Controller Class Initialized
INFO - 2024-06-08 14:33:46 --> Final output sent to browser
DEBUG - 2024-06-08 14:33:46 --> Total execution time: 0.1241
INFO - 2024-06-08 14:35:52 --> Config Class Initialized
INFO - 2024-06-08 14:35:52 --> Hooks Class Initialized
DEBUG - 2024-06-08 14:35:52 --> UTF-8 Support Enabled
INFO - 2024-06-08 14:35:52 --> Utf8 Class Initialized
INFO - 2024-06-08 14:35:52 --> URI Class Initialized
INFO - 2024-06-08 14:35:52 --> Router Class Initialized
INFO - 2024-06-08 14:35:52 --> Output Class Initialized
INFO - 2024-06-08 14:35:52 --> Security Class Initialized
DEBUG - 2024-06-08 14:35:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-08 14:35:52 --> Input Class Initialized
INFO - 2024-06-08 14:35:52 --> Language Class Initialized
INFO - 2024-06-08 14:35:52 --> Language Class Initialized
INFO - 2024-06-08 14:35:52 --> Config Class Initialized
INFO - 2024-06-08 14:35:52 --> Loader Class Initialized
INFO - 2024-06-08 14:35:52 --> Helper loaded: url_helper
INFO - 2024-06-08 14:35:52 --> Helper loaded: file_helper
INFO - 2024-06-08 14:35:52 --> Helper loaded: form_helper
INFO - 2024-06-08 14:35:52 --> Helper loaded: my_helper
INFO - 2024-06-08 14:35:52 --> Database Driver Class Initialized
INFO - 2024-06-08 14:35:52 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-08 14:35:52 --> Controller Class Initialized
INFO - 2024-06-08 14:35:52 --> Final output sent to browser
DEBUG - 2024-06-08 14:35:52 --> Total execution time: 0.2621
INFO - 2024-06-08 14:37:27 --> Config Class Initialized
INFO - 2024-06-08 14:37:27 --> Hooks Class Initialized
DEBUG - 2024-06-08 14:37:27 --> UTF-8 Support Enabled
INFO - 2024-06-08 14:37:27 --> Utf8 Class Initialized
INFO - 2024-06-08 14:37:28 --> URI Class Initialized
INFO - 2024-06-08 14:37:28 --> Router Class Initialized
INFO - 2024-06-08 14:37:28 --> Output Class Initialized
INFO - 2024-06-08 14:37:28 --> Security Class Initialized
DEBUG - 2024-06-08 14:37:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-08 14:37:28 --> Input Class Initialized
INFO - 2024-06-08 14:37:28 --> Language Class Initialized
INFO - 2024-06-08 14:37:28 --> Language Class Initialized
INFO - 2024-06-08 14:37:28 --> Config Class Initialized
INFO - 2024-06-08 14:37:28 --> Loader Class Initialized
INFO - 2024-06-08 14:37:28 --> Helper loaded: url_helper
INFO - 2024-06-08 14:37:28 --> Helper loaded: file_helper
INFO - 2024-06-08 14:37:28 --> Helper loaded: form_helper
INFO - 2024-06-08 14:37:28 --> Helper loaded: my_helper
INFO - 2024-06-08 14:37:28 --> Database Driver Class Initialized
INFO - 2024-06-08 14:37:28 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-08 14:37:28 --> Controller Class Initialized
INFO - 2024-06-08 14:37:28 --> Final output sent to browser
DEBUG - 2024-06-08 14:37:28 --> Total execution time: 0.2270
INFO - 2024-06-08 14:37:50 --> Config Class Initialized
INFO - 2024-06-08 14:37:50 --> Hooks Class Initialized
DEBUG - 2024-06-08 14:37:50 --> UTF-8 Support Enabled
INFO - 2024-06-08 14:37:50 --> Utf8 Class Initialized
INFO - 2024-06-08 14:37:50 --> URI Class Initialized
DEBUG - 2024-06-08 14:37:50 --> No URI present. Default controller set.
INFO - 2024-06-08 14:37:50 --> Router Class Initialized
INFO - 2024-06-08 14:37:50 --> Output Class Initialized
INFO - 2024-06-08 14:37:50 --> Security Class Initialized
DEBUG - 2024-06-08 14:37:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-08 14:37:50 --> Input Class Initialized
INFO - 2024-06-08 14:37:50 --> Language Class Initialized
INFO - 2024-06-08 14:37:50 --> Language Class Initialized
INFO - 2024-06-08 14:37:50 --> Config Class Initialized
INFO - 2024-06-08 14:37:50 --> Loader Class Initialized
INFO - 2024-06-08 14:37:50 --> Helper loaded: url_helper
INFO - 2024-06-08 14:37:50 --> Helper loaded: file_helper
INFO - 2024-06-08 14:37:50 --> Helper loaded: form_helper
INFO - 2024-06-08 14:37:50 --> Helper loaded: my_helper
INFO - 2024-06-08 14:37:50 --> Database Driver Class Initialized
INFO - 2024-06-08 14:37:50 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-08 14:37:50 --> Controller Class Initialized
DEBUG - 2024-06-08 14:37:50 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/home/views/v_home_guru.php
DEBUG - 2024-06-08 14:37:50 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-06-08 14:37:50 --> Final output sent to browser
DEBUG - 2024-06-08 14:37:50 --> Total execution time: 0.0314
INFO - 2024-06-08 14:37:52 --> Config Class Initialized
INFO - 2024-06-08 14:37:52 --> Hooks Class Initialized
DEBUG - 2024-06-08 14:37:52 --> UTF-8 Support Enabled
INFO - 2024-06-08 14:37:52 --> Utf8 Class Initialized
INFO - 2024-06-08 14:37:52 --> URI Class Initialized
INFO - 2024-06-08 14:37:52 --> Router Class Initialized
INFO - 2024-06-08 14:37:52 --> Output Class Initialized
INFO - 2024-06-08 14:37:52 --> Security Class Initialized
DEBUG - 2024-06-08 14:37:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-08 14:37:52 --> Input Class Initialized
INFO - 2024-06-08 14:37:52 --> Language Class Initialized
INFO - 2024-06-08 14:37:52 --> Language Class Initialized
INFO - 2024-06-08 14:37:52 --> Config Class Initialized
INFO - 2024-06-08 14:37:52 --> Loader Class Initialized
INFO - 2024-06-08 14:37:52 --> Helper loaded: url_helper
INFO - 2024-06-08 14:37:52 --> Helper loaded: file_helper
INFO - 2024-06-08 14:37:52 --> Helper loaded: form_helper
INFO - 2024-06-08 14:37:52 --> Helper loaded: my_helper
INFO - 2024-06-08 14:37:52 --> Database Driver Class Initialized
INFO - 2024-06-08 14:37:52 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-08 14:37:52 --> Controller Class Initialized
DEBUG - 2024-06-08 14:37:52 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/view_mapel/views/v_view_mapel.php
DEBUG - 2024-06-08 14:37:52 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-06-08 14:37:52 --> Final output sent to browser
DEBUG - 2024-06-08 14:37:52 --> Total execution time: 0.0315
INFO - 2024-06-08 14:37:54 --> Config Class Initialized
INFO - 2024-06-08 14:37:54 --> Hooks Class Initialized
DEBUG - 2024-06-08 14:37:54 --> UTF-8 Support Enabled
INFO - 2024-06-08 14:37:54 --> Utf8 Class Initialized
INFO - 2024-06-08 14:37:54 --> URI Class Initialized
INFO - 2024-06-08 14:37:54 --> Router Class Initialized
INFO - 2024-06-08 14:37:54 --> Output Class Initialized
INFO - 2024-06-08 14:37:54 --> Security Class Initialized
DEBUG - 2024-06-08 14:37:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-08 14:37:54 --> Input Class Initialized
INFO - 2024-06-08 14:37:54 --> Language Class Initialized
INFO - 2024-06-08 14:37:54 --> Language Class Initialized
INFO - 2024-06-08 14:37:54 --> Config Class Initialized
INFO - 2024-06-08 14:37:54 --> Loader Class Initialized
INFO - 2024-06-08 14:37:54 --> Helper loaded: url_helper
INFO - 2024-06-08 14:37:54 --> Helper loaded: file_helper
INFO - 2024-06-08 14:37:54 --> Helper loaded: form_helper
INFO - 2024-06-08 14:37:54 --> Helper loaded: my_helper
INFO - 2024-06-08 14:37:54 --> Database Driver Class Initialized
INFO - 2024-06-08 14:37:54 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-08 14:37:54 --> Controller Class Initialized
DEBUG - 2024-06-08 14:37:54 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/views/list.php
DEBUG - 2024-06-08 14:37:54 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-06-08 14:37:54 --> Final output sent to browser
DEBUG - 2024-06-08 14:37:54 --> Total execution time: 0.0388
INFO - 2024-06-08 14:37:54 --> Config Class Initialized
INFO - 2024-06-08 14:37:54 --> Hooks Class Initialized
DEBUG - 2024-06-08 14:37:54 --> UTF-8 Support Enabled
INFO - 2024-06-08 14:37:54 --> Utf8 Class Initialized
INFO - 2024-06-08 14:37:54 --> URI Class Initialized
INFO - 2024-06-08 14:37:54 --> Router Class Initialized
INFO - 2024-06-08 14:37:54 --> Output Class Initialized
INFO - 2024-06-08 14:37:54 --> Security Class Initialized
DEBUG - 2024-06-08 14:37:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-08 14:37:54 --> Input Class Initialized
INFO - 2024-06-08 14:37:54 --> Language Class Initialized
INFO - 2024-06-08 14:37:54 --> Language Class Initialized
INFO - 2024-06-08 14:37:54 --> Config Class Initialized
INFO - 2024-06-08 14:37:54 --> Loader Class Initialized
INFO - 2024-06-08 14:37:54 --> Helper loaded: url_helper
INFO - 2024-06-08 14:37:54 --> Helper loaded: file_helper
INFO - 2024-06-08 14:37:54 --> Helper loaded: form_helper
INFO - 2024-06-08 14:37:54 --> Helper loaded: my_helper
INFO - 2024-06-08 14:37:54 --> Database Driver Class Initialized
INFO - 2024-06-08 14:37:54 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-08 14:37:54 --> Controller Class Initialized
INFO - 2024-06-08 14:37:56 --> Config Class Initialized
INFO - 2024-06-08 14:37:56 --> Hooks Class Initialized
DEBUG - 2024-06-08 14:37:56 --> UTF-8 Support Enabled
INFO - 2024-06-08 14:37:56 --> Utf8 Class Initialized
INFO - 2024-06-08 14:37:56 --> URI Class Initialized
INFO - 2024-06-08 14:37:56 --> Router Class Initialized
INFO - 2024-06-08 14:37:56 --> Output Class Initialized
INFO - 2024-06-08 14:37:56 --> Security Class Initialized
DEBUG - 2024-06-08 14:37:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-08 14:37:56 --> Input Class Initialized
INFO - 2024-06-08 14:37:56 --> Language Class Initialized
INFO - 2024-06-08 14:37:56 --> Language Class Initialized
INFO - 2024-06-08 14:37:56 --> Config Class Initialized
INFO - 2024-06-08 14:37:56 --> Loader Class Initialized
INFO - 2024-06-08 14:37:56 --> Helper loaded: url_helper
INFO - 2024-06-08 14:37:56 --> Helper loaded: file_helper
INFO - 2024-06-08 14:37:56 --> Helper loaded: form_helper
INFO - 2024-06-08 14:37:56 --> Helper loaded: my_helper
INFO - 2024-06-08 14:37:56 --> Database Driver Class Initialized
INFO - 2024-06-08 14:37:56 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-08 14:37:56 --> Controller Class Initialized
INFO - 2024-06-08 14:37:56 --> Final output sent to browser
DEBUG - 2024-06-08 14:37:56 --> Total execution time: 0.0538
INFO - 2024-06-08 14:38:01 --> Config Class Initialized
INFO - 2024-06-08 14:38:01 --> Hooks Class Initialized
DEBUG - 2024-06-08 14:38:01 --> UTF-8 Support Enabled
INFO - 2024-06-08 14:38:01 --> Utf8 Class Initialized
INFO - 2024-06-08 14:38:01 --> URI Class Initialized
INFO - 2024-06-08 14:38:01 --> Router Class Initialized
INFO - 2024-06-08 14:38:01 --> Output Class Initialized
INFO - 2024-06-08 14:38:01 --> Security Class Initialized
DEBUG - 2024-06-08 14:38:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-08 14:38:01 --> Input Class Initialized
INFO - 2024-06-08 14:38:01 --> Language Class Initialized
INFO - 2024-06-08 14:38:01 --> Language Class Initialized
INFO - 2024-06-08 14:38:01 --> Config Class Initialized
INFO - 2024-06-08 14:38:01 --> Loader Class Initialized
INFO - 2024-06-08 14:38:01 --> Helper loaded: url_helper
INFO - 2024-06-08 14:38:01 --> Helper loaded: file_helper
INFO - 2024-06-08 14:38:01 --> Helper loaded: form_helper
INFO - 2024-06-08 14:38:01 --> Helper loaded: my_helper
INFO - 2024-06-08 14:38:01 --> Database Driver Class Initialized
INFO - 2024-06-08 14:38:01 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-08 14:38:01 --> Controller Class Initialized
INFO - 2024-06-08 14:38:01 --> Final output sent to browser
DEBUG - 2024-06-08 14:38:01 --> Total execution time: 0.1649
