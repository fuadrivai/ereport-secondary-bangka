<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2024-11-06 13:56:56 --> Config Class Initialized
INFO - 2024-11-06 13:56:56 --> Hooks Class Initialized
DEBUG - 2024-11-06 13:56:56 --> UTF-8 Support Enabled
INFO - 2024-11-06 13:56:56 --> Utf8 Class Initialized
INFO - 2024-11-06 13:56:56 --> URI Class Initialized
INFO - 2024-11-06 13:56:56 --> Router Class Initialized
INFO - 2024-11-06 13:56:56 --> Output Class Initialized
INFO - 2024-11-06 13:56:56 --> Security Class Initialized
DEBUG - 2024-11-06 13:56:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-11-06 13:56:56 --> Input Class Initialized
INFO - 2024-11-06 13:56:56 --> Language Class Initialized
INFO - 2024-11-06 13:56:56 --> Language Class Initialized
INFO - 2024-11-06 13:56:56 --> Config Class Initialized
INFO - 2024-11-06 13:56:56 --> Loader Class Initialized
INFO - 2024-11-06 13:56:56 --> Helper loaded: url_helper
INFO - 2024-11-06 13:56:56 --> Helper loaded: file_helper
INFO - 2024-11-06 13:56:56 --> Helper loaded: form_helper
INFO - 2024-11-06 13:56:56 --> Helper loaded: my_helper
INFO - 2024-11-06 13:56:56 --> Database Driver Class Initialized
INFO - 2024-11-06 13:56:56 --> Session: Class initialized using 'files' driver.
INFO - 2024-11-06 13:56:56 --> Controller Class Initialized
DEBUG - 2024-11-06 13:56:56 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/login/views/login.php
DEBUG - 2024-11-06 13:56:56 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-11-06 13:56:56 --> Final output sent to browser
DEBUG - 2024-11-06 13:56:56 --> Total execution time: 0.0552
INFO - 2024-11-06 13:57:05 --> Config Class Initialized
INFO - 2024-11-06 13:57:05 --> Hooks Class Initialized
DEBUG - 2024-11-06 13:57:05 --> UTF-8 Support Enabled
INFO - 2024-11-06 13:57:05 --> Utf8 Class Initialized
INFO - 2024-11-06 13:57:05 --> URI Class Initialized
INFO - 2024-11-06 13:57:05 --> Router Class Initialized
INFO - 2024-11-06 13:57:05 --> Output Class Initialized
INFO - 2024-11-06 13:57:05 --> Security Class Initialized
DEBUG - 2024-11-06 13:57:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-11-06 13:57:05 --> Input Class Initialized
INFO - 2024-11-06 13:57:05 --> Language Class Initialized
INFO - 2024-11-06 13:57:05 --> Language Class Initialized
INFO - 2024-11-06 13:57:05 --> Config Class Initialized
INFO - 2024-11-06 13:57:05 --> Loader Class Initialized
INFO - 2024-11-06 13:57:05 --> Helper loaded: url_helper
INFO - 2024-11-06 13:57:05 --> Helper loaded: file_helper
INFO - 2024-11-06 13:57:05 --> Helper loaded: form_helper
INFO - 2024-11-06 13:57:05 --> Helper loaded: my_helper
INFO - 2024-11-06 13:57:05 --> Database Driver Class Initialized
INFO - 2024-11-06 13:57:05 --> Session: Class initialized using 'files' driver.
INFO - 2024-11-06 13:57:05 --> Controller Class Initialized
INFO - 2024-11-06 13:57:05 --> Helper loaded: cookie_helper
INFO - 2024-11-06 13:57:05 --> Final output sent to browser
DEBUG - 2024-11-06 13:57:05 --> Total execution time: 0.3097
INFO - 2024-11-06 13:57:05 --> Config Class Initialized
INFO - 2024-11-06 13:57:05 --> Hooks Class Initialized
DEBUG - 2024-11-06 13:57:05 --> UTF-8 Support Enabled
INFO - 2024-11-06 13:57:05 --> Utf8 Class Initialized
INFO - 2024-11-06 13:57:05 --> URI Class Initialized
INFO - 2024-11-06 13:57:05 --> Router Class Initialized
INFO - 2024-11-06 13:57:05 --> Output Class Initialized
INFO - 2024-11-06 13:57:05 --> Security Class Initialized
DEBUG - 2024-11-06 13:57:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-11-06 13:57:05 --> Input Class Initialized
INFO - 2024-11-06 13:57:05 --> Language Class Initialized
INFO - 2024-11-06 13:57:05 --> Language Class Initialized
INFO - 2024-11-06 13:57:05 --> Config Class Initialized
INFO - 2024-11-06 13:57:05 --> Loader Class Initialized
INFO - 2024-11-06 13:57:05 --> Helper loaded: url_helper
INFO - 2024-11-06 13:57:05 --> Helper loaded: file_helper
INFO - 2024-11-06 13:57:05 --> Helper loaded: form_helper
INFO - 2024-11-06 13:57:05 --> Helper loaded: my_helper
INFO - 2024-11-06 13:57:05 --> Database Driver Class Initialized
INFO - 2024-11-06 13:57:05 --> Session: Class initialized using 'files' driver.
INFO - 2024-11-06 13:57:05 --> Controller Class Initialized
DEBUG - 2024-11-06 13:57:05 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/home/views/v_home.php
DEBUG - 2024-11-06 13:57:05 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-11-06 13:57:05 --> Final output sent to browser
DEBUG - 2024-11-06 13:57:05 --> Total execution time: 0.0502
INFO - 2024-11-06 13:57:33 --> Config Class Initialized
INFO - 2024-11-06 13:57:33 --> Hooks Class Initialized
DEBUG - 2024-11-06 13:57:33 --> UTF-8 Support Enabled
INFO - 2024-11-06 13:57:33 --> Utf8 Class Initialized
INFO - 2024-11-06 13:57:33 --> URI Class Initialized
INFO - 2024-11-06 13:57:33 --> Router Class Initialized
INFO - 2024-11-06 13:57:33 --> Output Class Initialized
INFO - 2024-11-06 13:57:33 --> Security Class Initialized
DEBUG - 2024-11-06 13:57:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-11-06 13:57:33 --> Input Class Initialized
INFO - 2024-11-06 13:57:33 --> Language Class Initialized
INFO - 2024-11-06 13:57:33 --> Language Class Initialized
INFO - 2024-11-06 13:57:33 --> Config Class Initialized
INFO - 2024-11-06 13:57:33 --> Loader Class Initialized
INFO - 2024-11-06 13:57:33 --> Helper loaded: url_helper
INFO - 2024-11-06 13:57:33 --> Helper loaded: file_helper
INFO - 2024-11-06 13:57:33 --> Helper loaded: form_helper
INFO - 2024-11-06 13:57:33 --> Helper loaded: my_helper
INFO - 2024-11-06 13:57:33 --> Database Driver Class Initialized
INFO - 2024-11-06 13:57:33 --> Session: Class initialized using 'files' driver.
INFO - 2024-11-06 13:57:33 --> Controller Class Initialized
DEBUG - 2024-11-06 13:57:33 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/set_kelas/views/list.php
DEBUG - 2024-11-06 13:57:33 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-11-06 13:57:33 --> Final output sent to browser
DEBUG - 2024-11-06 13:57:33 --> Total execution time: 0.0398
INFO - 2024-11-06 13:57:41 --> Config Class Initialized
INFO - 2024-11-06 13:57:41 --> Hooks Class Initialized
DEBUG - 2024-11-06 13:57:41 --> UTF-8 Support Enabled
INFO - 2024-11-06 13:57:41 --> Utf8 Class Initialized
INFO - 2024-11-06 13:57:41 --> URI Class Initialized
DEBUG - 2024-11-06 13:57:41 --> No URI present. Default controller set.
INFO - 2024-11-06 13:57:41 --> Router Class Initialized
INFO - 2024-11-06 13:57:41 --> Output Class Initialized
INFO - 2024-11-06 13:57:41 --> Security Class Initialized
DEBUG - 2024-11-06 13:57:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-11-06 13:57:41 --> Input Class Initialized
INFO - 2024-11-06 13:57:41 --> Language Class Initialized
INFO - 2024-11-06 13:57:41 --> Language Class Initialized
INFO - 2024-11-06 13:57:41 --> Config Class Initialized
INFO - 2024-11-06 13:57:41 --> Loader Class Initialized
INFO - 2024-11-06 13:57:41 --> Helper loaded: url_helper
INFO - 2024-11-06 13:57:41 --> Helper loaded: file_helper
INFO - 2024-11-06 13:57:41 --> Helper loaded: form_helper
INFO - 2024-11-06 13:57:41 --> Helper loaded: my_helper
INFO - 2024-11-06 13:57:41 --> Database Driver Class Initialized
INFO - 2024-11-06 13:57:41 --> Session: Class initialized using 'files' driver.
INFO - 2024-11-06 13:57:41 --> Controller Class Initialized
DEBUG - 2024-11-06 13:57:41 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/home/views/v_home.php
DEBUG - 2024-11-06 13:57:41 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-11-06 13:57:41 --> Final output sent to browser
DEBUG - 2024-11-06 13:57:41 --> Total execution time: 0.0326
INFO - 2024-11-06 13:58:55 --> Config Class Initialized
INFO - 2024-11-06 13:58:55 --> Hooks Class Initialized
DEBUG - 2024-11-06 13:58:55 --> UTF-8 Support Enabled
INFO - 2024-11-06 13:58:55 --> Utf8 Class Initialized
INFO - 2024-11-06 13:58:55 --> URI Class Initialized
INFO - 2024-11-06 13:58:55 --> Router Class Initialized
INFO - 2024-11-06 13:58:55 --> Output Class Initialized
INFO - 2024-11-06 13:58:55 --> Security Class Initialized
DEBUG - 2024-11-06 13:58:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-11-06 13:58:55 --> Input Class Initialized
INFO - 2024-11-06 13:58:55 --> Language Class Initialized
INFO - 2024-11-06 13:58:55 --> Language Class Initialized
INFO - 2024-11-06 13:58:55 --> Config Class Initialized
INFO - 2024-11-06 13:58:55 --> Loader Class Initialized
INFO - 2024-11-06 13:58:55 --> Helper loaded: url_helper
INFO - 2024-11-06 13:58:55 --> Helper loaded: file_helper
INFO - 2024-11-06 13:58:55 --> Helper loaded: form_helper
INFO - 2024-11-06 13:58:55 --> Helper loaded: my_helper
INFO - 2024-11-06 13:58:55 --> Database Driver Class Initialized
INFO - 2024-11-06 13:58:55 --> Session: Class initialized using 'files' driver.
INFO - 2024-11-06 13:58:55 --> Controller Class Initialized
DEBUG - 2024-11-06 13:58:55 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/tahun/views/list.php
DEBUG - 2024-11-06 13:58:55 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-11-06 13:58:55 --> Final output sent to browser
DEBUG - 2024-11-06 13:58:55 --> Total execution time: 0.0324
INFO - 2024-11-06 13:58:55 --> Config Class Initialized
INFO - 2024-11-06 13:58:55 --> Hooks Class Initialized
DEBUG - 2024-11-06 13:58:55 --> UTF-8 Support Enabled
INFO - 2024-11-06 13:58:55 --> Utf8 Class Initialized
INFO - 2024-11-06 13:58:55 --> URI Class Initialized
INFO - 2024-11-06 13:58:55 --> Router Class Initialized
INFO - 2024-11-06 13:58:55 --> Output Class Initialized
INFO - 2024-11-06 13:58:55 --> Security Class Initialized
DEBUG - 2024-11-06 13:58:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-11-06 13:58:55 --> Input Class Initialized
INFO - 2024-11-06 13:58:55 --> Language Class Initialized
ERROR - 2024-11-06 13:58:55 --> 404 Page Not Found: /index
INFO - 2024-11-06 13:58:55 --> Config Class Initialized
INFO - 2024-11-06 13:58:55 --> Hooks Class Initialized
DEBUG - 2024-11-06 13:58:55 --> UTF-8 Support Enabled
INFO - 2024-11-06 13:58:55 --> Utf8 Class Initialized
INFO - 2024-11-06 13:58:55 --> URI Class Initialized
INFO - 2024-11-06 13:58:55 --> Router Class Initialized
INFO - 2024-11-06 13:58:55 --> Output Class Initialized
INFO - 2024-11-06 13:58:55 --> Security Class Initialized
DEBUG - 2024-11-06 13:58:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-11-06 13:58:55 --> Input Class Initialized
INFO - 2024-11-06 13:58:55 --> Language Class Initialized
INFO - 2024-11-06 13:58:55 --> Language Class Initialized
INFO - 2024-11-06 13:58:55 --> Config Class Initialized
INFO - 2024-11-06 13:58:55 --> Loader Class Initialized
INFO - 2024-11-06 13:58:55 --> Helper loaded: url_helper
INFO - 2024-11-06 13:58:55 --> Helper loaded: file_helper
INFO - 2024-11-06 13:58:55 --> Helper loaded: form_helper
INFO - 2024-11-06 13:58:55 --> Helper loaded: my_helper
INFO - 2024-11-06 13:58:55 --> Database Driver Class Initialized
INFO - 2024-11-06 13:58:55 --> Session: Class initialized using 'files' driver.
INFO - 2024-11-06 13:58:55 --> Controller Class Initialized
INFO - 2024-11-06 13:59:14 --> Config Class Initialized
INFO - 2024-11-06 13:59:14 --> Hooks Class Initialized
DEBUG - 2024-11-06 13:59:14 --> UTF-8 Support Enabled
INFO - 2024-11-06 13:59:14 --> Utf8 Class Initialized
INFO - 2024-11-06 13:59:14 --> URI Class Initialized
DEBUG - 2024-11-06 13:59:14 --> No URI present. Default controller set.
INFO - 2024-11-06 13:59:14 --> Router Class Initialized
INFO - 2024-11-06 13:59:14 --> Output Class Initialized
INFO - 2024-11-06 13:59:14 --> Security Class Initialized
DEBUG - 2024-11-06 13:59:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-11-06 13:59:14 --> Input Class Initialized
INFO - 2024-11-06 13:59:14 --> Language Class Initialized
INFO - 2024-11-06 13:59:15 --> Language Class Initialized
INFO - 2024-11-06 13:59:15 --> Config Class Initialized
INFO - 2024-11-06 13:59:15 --> Loader Class Initialized
INFO - 2024-11-06 13:59:15 --> Helper loaded: url_helper
INFO - 2024-11-06 13:59:15 --> Helper loaded: file_helper
INFO - 2024-11-06 13:59:15 --> Helper loaded: form_helper
INFO - 2024-11-06 13:59:15 --> Helper loaded: my_helper
INFO - 2024-11-06 13:59:15 --> Database Driver Class Initialized
INFO - 2024-11-06 13:59:15 --> Session: Class initialized using 'files' driver.
INFO - 2024-11-06 13:59:15 --> Controller Class Initialized
DEBUG - 2024-11-06 13:59:15 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/home/views/v_home.php
DEBUG - 2024-11-06 13:59:15 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-11-06 13:59:15 --> Final output sent to browser
DEBUG - 2024-11-06 13:59:15 --> Total execution time: 0.0307
INFO - 2024-11-06 13:59:23 --> Config Class Initialized
INFO - 2024-11-06 13:59:23 --> Hooks Class Initialized
DEBUG - 2024-11-06 13:59:23 --> UTF-8 Support Enabled
INFO - 2024-11-06 13:59:23 --> Utf8 Class Initialized
INFO - 2024-11-06 13:59:23 --> URI Class Initialized
DEBUG - 2024-11-06 13:59:23 --> No URI present. Default controller set.
INFO - 2024-11-06 13:59:23 --> Router Class Initialized
INFO - 2024-11-06 13:59:23 --> Output Class Initialized
INFO - 2024-11-06 13:59:23 --> Security Class Initialized
DEBUG - 2024-11-06 13:59:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-11-06 13:59:23 --> Input Class Initialized
INFO - 2024-11-06 13:59:23 --> Language Class Initialized
INFO - 2024-11-06 13:59:23 --> Language Class Initialized
INFO - 2024-11-06 13:59:23 --> Config Class Initialized
INFO - 2024-11-06 13:59:23 --> Loader Class Initialized
INFO - 2024-11-06 13:59:23 --> Helper loaded: url_helper
INFO - 2024-11-06 13:59:23 --> Helper loaded: file_helper
INFO - 2024-11-06 13:59:23 --> Helper loaded: form_helper
INFO - 2024-11-06 13:59:23 --> Helper loaded: my_helper
INFO - 2024-11-06 13:59:23 --> Database Driver Class Initialized
INFO - 2024-11-06 13:59:23 --> Session: Class initialized using 'files' driver.
INFO - 2024-11-06 13:59:23 --> Controller Class Initialized
DEBUG - 2024-11-06 13:59:23 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/home/views/v_home.php
DEBUG - 2024-11-06 13:59:23 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-11-06 13:59:23 --> Final output sent to browser
DEBUG - 2024-11-06 13:59:23 --> Total execution time: 0.0282
INFO - 2024-11-06 14:00:06 --> Config Class Initialized
INFO - 2024-11-06 14:00:06 --> Hooks Class Initialized
DEBUG - 2024-11-06 14:00:06 --> UTF-8 Support Enabled
INFO - 2024-11-06 14:00:06 --> Utf8 Class Initialized
INFO - 2024-11-06 14:00:06 --> URI Class Initialized
DEBUG - 2024-11-06 14:00:06 --> No URI present. Default controller set.
INFO - 2024-11-06 14:00:06 --> Router Class Initialized
INFO - 2024-11-06 14:00:06 --> Output Class Initialized
INFO - 2024-11-06 14:00:06 --> Security Class Initialized
DEBUG - 2024-11-06 14:00:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-11-06 14:00:06 --> Input Class Initialized
INFO - 2024-11-06 14:00:06 --> Language Class Initialized
INFO - 2024-11-06 14:00:06 --> Language Class Initialized
INFO - 2024-11-06 14:00:06 --> Config Class Initialized
INFO - 2024-11-06 14:00:06 --> Loader Class Initialized
INFO - 2024-11-06 14:00:06 --> Helper loaded: url_helper
INFO - 2024-11-06 14:00:06 --> Helper loaded: file_helper
INFO - 2024-11-06 14:00:06 --> Helper loaded: form_helper
INFO - 2024-11-06 14:00:06 --> Helper loaded: my_helper
INFO - 2024-11-06 14:00:06 --> Database Driver Class Initialized
INFO - 2024-11-06 14:00:06 --> Session: Class initialized using 'files' driver.
INFO - 2024-11-06 14:00:06 --> Controller Class Initialized
DEBUG - 2024-11-06 14:00:06 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/home/views/v_home.php
DEBUG - 2024-11-06 14:00:06 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-11-06 14:00:06 --> Final output sent to browser
DEBUG - 2024-11-06 14:00:06 --> Total execution time: 0.0402
INFO - 2024-11-06 14:00:23 --> Config Class Initialized
INFO - 2024-11-06 14:00:23 --> Hooks Class Initialized
DEBUG - 2024-11-06 14:00:23 --> UTF-8 Support Enabled
INFO - 2024-11-06 14:00:23 --> Utf8 Class Initialized
INFO - 2024-11-06 14:00:23 --> URI Class Initialized
DEBUG - 2024-11-06 14:00:23 --> No URI present. Default controller set.
INFO - 2024-11-06 14:00:23 --> Router Class Initialized
INFO - 2024-11-06 14:00:23 --> Output Class Initialized
INFO - 2024-11-06 14:00:23 --> Security Class Initialized
DEBUG - 2024-11-06 14:00:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-11-06 14:00:23 --> Input Class Initialized
INFO - 2024-11-06 14:00:23 --> Language Class Initialized
INFO - 2024-11-06 14:00:23 --> Language Class Initialized
INFO - 2024-11-06 14:00:23 --> Config Class Initialized
INFO - 2024-11-06 14:00:23 --> Loader Class Initialized
INFO - 2024-11-06 14:00:23 --> Helper loaded: url_helper
INFO - 2024-11-06 14:00:23 --> Helper loaded: file_helper
INFO - 2024-11-06 14:00:23 --> Helper loaded: form_helper
INFO - 2024-11-06 14:00:23 --> Helper loaded: my_helper
INFO - 2024-11-06 14:00:23 --> Database Driver Class Initialized
INFO - 2024-11-06 14:00:23 --> Session: Class initialized using 'files' driver.
INFO - 2024-11-06 14:00:23 --> Controller Class Initialized
DEBUG - 2024-11-06 14:00:23 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/home/views/v_home.php
DEBUG - 2024-11-06 14:00:23 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-11-06 14:00:23 --> Final output sent to browser
DEBUG - 2024-11-06 14:00:23 --> Total execution time: 0.0324
INFO - 2024-11-06 14:00:32 --> Config Class Initialized
INFO - 2024-11-06 14:00:32 --> Hooks Class Initialized
DEBUG - 2024-11-06 14:00:32 --> UTF-8 Support Enabled
INFO - 2024-11-06 14:00:32 --> Utf8 Class Initialized
INFO - 2024-11-06 14:00:32 --> URI Class Initialized
DEBUG - 2024-11-06 14:00:32 --> No URI present. Default controller set.
INFO - 2024-11-06 14:00:32 --> Router Class Initialized
INFO - 2024-11-06 14:00:32 --> Output Class Initialized
INFO - 2024-11-06 14:00:32 --> Security Class Initialized
DEBUG - 2024-11-06 14:00:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-11-06 14:00:32 --> Input Class Initialized
INFO - 2024-11-06 14:00:32 --> Language Class Initialized
INFO - 2024-11-06 14:00:32 --> Language Class Initialized
INFO - 2024-11-06 14:00:32 --> Config Class Initialized
INFO - 2024-11-06 14:00:32 --> Loader Class Initialized
INFO - 2024-11-06 14:00:32 --> Helper loaded: url_helper
INFO - 2024-11-06 14:00:32 --> Helper loaded: file_helper
INFO - 2024-11-06 14:00:32 --> Helper loaded: form_helper
INFO - 2024-11-06 14:00:32 --> Helper loaded: my_helper
INFO - 2024-11-06 14:00:32 --> Database Driver Class Initialized
INFO - 2024-11-06 14:00:32 --> Session: Class initialized using 'files' driver.
INFO - 2024-11-06 14:00:32 --> Controller Class Initialized
DEBUG - 2024-11-06 14:00:32 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/home/views/v_home.php
DEBUG - 2024-11-06 14:00:32 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-11-06 14:00:32 --> Final output sent to browser
DEBUG - 2024-11-06 14:00:32 --> Total execution time: 0.0316
INFO - 2024-11-06 14:00:37 --> Config Class Initialized
INFO - 2024-11-06 14:00:37 --> Hooks Class Initialized
DEBUG - 2024-11-06 14:00:37 --> UTF-8 Support Enabled
INFO - 2024-11-06 14:00:37 --> Utf8 Class Initialized
INFO - 2024-11-06 14:00:37 --> URI Class Initialized
INFO - 2024-11-06 14:00:37 --> Router Class Initialized
INFO - 2024-11-06 14:00:37 --> Output Class Initialized
INFO - 2024-11-06 14:00:37 --> Security Class Initialized
DEBUG - 2024-11-06 14:00:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-11-06 14:00:37 --> Input Class Initialized
INFO - 2024-11-06 14:00:37 --> Language Class Initialized
INFO - 2024-11-06 14:00:37 --> Language Class Initialized
INFO - 2024-11-06 14:00:37 --> Config Class Initialized
INFO - 2024-11-06 14:00:37 --> Loader Class Initialized
INFO - 2024-11-06 14:00:37 --> Helper loaded: url_helper
INFO - 2024-11-06 14:00:37 --> Helper loaded: file_helper
INFO - 2024-11-06 14:00:37 --> Helper loaded: form_helper
INFO - 2024-11-06 14:00:37 --> Helper loaded: my_helper
INFO - 2024-11-06 14:00:37 --> Database Driver Class Initialized
INFO - 2024-11-06 14:00:37 --> Session: Class initialized using 'files' driver.
INFO - 2024-11-06 14:00:37 --> Controller Class Initialized
DEBUG - 2024-11-06 14:00:37 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/data_guru/views/list.php
DEBUG - 2024-11-06 14:00:37 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-11-06 14:00:37 --> Final output sent to browser
DEBUG - 2024-11-06 14:00:37 --> Total execution time: 0.0280
INFO - 2024-11-06 14:00:38 --> Config Class Initialized
INFO - 2024-11-06 14:00:38 --> Hooks Class Initialized
DEBUG - 2024-11-06 14:00:38 --> UTF-8 Support Enabled
INFO - 2024-11-06 14:00:38 --> Utf8 Class Initialized
INFO - 2024-11-06 14:00:38 --> URI Class Initialized
INFO - 2024-11-06 14:00:38 --> Router Class Initialized
INFO - 2024-11-06 14:00:38 --> Output Class Initialized
INFO - 2024-11-06 14:00:38 --> Security Class Initialized
DEBUG - 2024-11-06 14:00:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-11-06 14:00:38 --> Input Class Initialized
INFO - 2024-11-06 14:00:38 --> Language Class Initialized
ERROR - 2024-11-06 14:00:38 --> 404 Page Not Found: /index
INFO - 2024-11-06 14:00:38 --> Config Class Initialized
INFO - 2024-11-06 14:00:38 --> Hooks Class Initialized
DEBUG - 2024-11-06 14:00:38 --> UTF-8 Support Enabled
INFO - 2024-11-06 14:00:38 --> Utf8 Class Initialized
INFO - 2024-11-06 14:00:38 --> URI Class Initialized
INFO - 2024-11-06 14:00:38 --> Router Class Initialized
INFO - 2024-11-06 14:00:38 --> Output Class Initialized
INFO - 2024-11-06 14:00:38 --> Security Class Initialized
DEBUG - 2024-11-06 14:00:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-11-06 14:00:38 --> Input Class Initialized
INFO - 2024-11-06 14:00:38 --> Language Class Initialized
INFO - 2024-11-06 14:00:38 --> Language Class Initialized
INFO - 2024-11-06 14:00:38 --> Config Class Initialized
INFO - 2024-11-06 14:00:38 --> Loader Class Initialized
INFO - 2024-11-06 14:00:38 --> Helper loaded: url_helper
INFO - 2024-11-06 14:00:38 --> Helper loaded: file_helper
INFO - 2024-11-06 14:00:38 --> Helper loaded: form_helper
INFO - 2024-11-06 14:00:38 --> Helper loaded: my_helper
INFO - 2024-11-06 14:00:38 --> Database Driver Class Initialized
INFO - 2024-11-06 14:00:38 --> Session: Class initialized using 'files' driver.
INFO - 2024-11-06 14:00:38 --> Controller Class Initialized
INFO - 2024-11-06 14:00:40 --> Config Class Initialized
INFO - 2024-11-06 14:00:40 --> Hooks Class Initialized
DEBUG - 2024-11-06 14:00:40 --> UTF-8 Support Enabled
INFO - 2024-11-06 14:00:40 --> Utf8 Class Initialized
INFO - 2024-11-06 14:00:40 --> URI Class Initialized
DEBUG - 2024-11-06 14:00:40 --> No URI present. Default controller set.
INFO - 2024-11-06 14:00:40 --> Router Class Initialized
INFO - 2024-11-06 14:00:40 --> Output Class Initialized
INFO - 2024-11-06 14:00:40 --> Security Class Initialized
DEBUG - 2024-11-06 14:00:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-11-06 14:00:40 --> Input Class Initialized
INFO - 2024-11-06 14:00:40 --> Language Class Initialized
INFO - 2024-11-06 14:00:40 --> Language Class Initialized
INFO - 2024-11-06 14:00:40 --> Config Class Initialized
INFO - 2024-11-06 14:00:40 --> Loader Class Initialized
INFO - 2024-11-06 14:00:40 --> Helper loaded: url_helper
INFO - 2024-11-06 14:00:40 --> Helper loaded: file_helper
INFO - 2024-11-06 14:00:40 --> Helper loaded: form_helper
INFO - 2024-11-06 14:00:40 --> Helper loaded: my_helper
INFO - 2024-11-06 14:00:40 --> Database Driver Class Initialized
INFO - 2024-11-06 14:00:40 --> Session: Class initialized using 'files' driver.
INFO - 2024-11-06 14:00:40 --> Controller Class Initialized
DEBUG - 2024-11-06 14:00:40 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/home/views/v_home.php
DEBUG - 2024-11-06 14:00:40 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-11-06 14:00:40 --> Final output sent to browser
DEBUG - 2024-11-06 14:00:40 --> Total execution time: 0.0299
INFO - 2024-11-06 14:01:29 --> Config Class Initialized
INFO - 2024-11-06 14:01:29 --> Hooks Class Initialized
DEBUG - 2024-11-06 14:01:29 --> UTF-8 Support Enabled
INFO - 2024-11-06 14:01:29 --> Utf8 Class Initialized
INFO - 2024-11-06 14:01:29 --> URI Class Initialized
INFO - 2024-11-06 14:01:29 --> Router Class Initialized
INFO - 2024-11-06 14:01:29 --> Output Class Initialized
INFO - 2024-11-06 14:01:29 --> Security Class Initialized
DEBUG - 2024-11-06 14:01:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-11-06 14:01:29 --> Input Class Initialized
INFO - 2024-11-06 14:01:29 --> Language Class Initialized
INFO - 2024-11-06 14:01:29 --> Language Class Initialized
INFO - 2024-11-06 14:01:29 --> Config Class Initialized
INFO - 2024-11-06 14:01:29 --> Loader Class Initialized
INFO - 2024-11-06 14:01:29 --> Helper loaded: url_helper
INFO - 2024-11-06 14:01:29 --> Helper loaded: file_helper
INFO - 2024-11-06 14:01:29 --> Helper loaded: form_helper
INFO - 2024-11-06 14:01:29 --> Helper loaded: my_helper
INFO - 2024-11-06 14:01:29 --> Database Driver Class Initialized
INFO - 2024-11-06 14:01:29 --> Session: Class initialized using 'files' driver.
INFO - 2024-11-06 14:01:29 --> Controller Class Initialized
INFO - 2024-11-06 14:01:29 --> Helper loaded: cookie_helper
INFO - 2024-11-06 14:01:29 --> Final output sent to browser
DEBUG - 2024-11-06 14:01:29 --> Total execution time: 0.1674
INFO - 2024-11-06 14:01:30 --> Config Class Initialized
INFO - 2024-11-06 14:01:30 --> Hooks Class Initialized
DEBUG - 2024-11-06 14:01:30 --> UTF-8 Support Enabled
INFO - 2024-11-06 14:01:30 --> Utf8 Class Initialized
INFO - 2024-11-06 14:01:30 --> URI Class Initialized
INFO - 2024-11-06 14:01:30 --> Router Class Initialized
INFO - 2024-11-06 14:01:30 --> Output Class Initialized
INFO - 2024-11-06 14:01:30 --> Security Class Initialized
DEBUG - 2024-11-06 14:01:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-11-06 14:01:30 --> Input Class Initialized
INFO - 2024-11-06 14:01:30 --> Language Class Initialized
INFO - 2024-11-06 14:01:30 --> Language Class Initialized
INFO - 2024-11-06 14:01:30 --> Config Class Initialized
INFO - 2024-11-06 14:01:30 --> Loader Class Initialized
INFO - 2024-11-06 14:01:30 --> Helper loaded: url_helper
INFO - 2024-11-06 14:01:30 --> Helper loaded: file_helper
INFO - 2024-11-06 14:01:30 --> Helper loaded: form_helper
INFO - 2024-11-06 14:01:30 --> Helper loaded: my_helper
INFO - 2024-11-06 14:01:30 --> Database Driver Class Initialized
INFO - 2024-11-06 14:01:30 --> Session: Class initialized using 'files' driver.
INFO - 2024-11-06 14:01:30 --> Controller Class Initialized
INFO - 2024-11-06 14:01:30 --> Helper loaded: cookie_helper
INFO - 2024-11-06 14:01:30 --> Config Class Initialized
INFO - 2024-11-06 14:01:30 --> Hooks Class Initialized
DEBUG - 2024-11-06 14:01:30 --> UTF-8 Support Enabled
INFO - 2024-11-06 14:01:30 --> Utf8 Class Initialized
INFO - 2024-11-06 14:01:30 --> URI Class Initialized
INFO - 2024-11-06 14:01:30 --> Router Class Initialized
INFO - 2024-11-06 14:01:30 --> Output Class Initialized
INFO - 2024-11-06 14:01:30 --> Security Class Initialized
DEBUG - 2024-11-06 14:01:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-11-06 14:01:30 --> Input Class Initialized
INFO - 2024-11-06 14:01:30 --> Language Class Initialized
INFO - 2024-11-06 14:01:30 --> Language Class Initialized
INFO - 2024-11-06 14:01:30 --> Config Class Initialized
INFO - 2024-11-06 14:01:30 --> Loader Class Initialized
INFO - 2024-11-06 14:01:30 --> Helper loaded: url_helper
INFO - 2024-11-06 14:01:30 --> Helper loaded: file_helper
INFO - 2024-11-06 14:01:30 --> Helper loaded: form_helper
INFO - 2024-11-06 14:01:30 --> Helper loaded: my_helper
INFO - 2024-11-06 14:01:30 --> Database Driver Class Initialized
INFO - 2024-11-06 14:01:30 --> Session: Class initialized using 'files' driver.
INFO - 2024-11-06 14:01:30 --> Controller Class Initialized
DEBUG - 2024-11-06 14:01:30 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/lihat_raport/views/list.php
DEBUG - 2024-11-06 14:01:30 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-11-06 14:01:30 --> Final output sent to browser
DEBUG - 2024-11-06 14:01:30 --> Total execution time: 0.0378
INFO - 2024-11-06 14:01:36 --> Config Class Initialized
INFO - 2024-11-06 14:01:36 --> Hooks Class Initialized
DEBUG - 2024-11-06 14:01:36 --> UTF-8 Support Enabled
INFO - 2024-11-06 14:01:36 --> Utf8 Class Initialized
INFO - 2024-11-06 14:01:36 --> URI Class Initialized
INFO - 2024-11-06 14:01:36 --> Router Class Initialized
INFO - 2024-11-06 14:01:36 --> Output Class Initialized
INFO - 2024-11-06 14:01:36 --> Security Class Initialized
DEBUG - 2024-11-06 14:01:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-11-06 14:01:36 --> Input Class Initialized
INFO - 2024-11-06 14:01:36 --> Language Class Initialized
INFO - 2024-11-06 14:01:36 --> Language Class Initialized
INFO - 2024-11-06 14:01:36 --> Config Class Initialized
INFO - 2024-11-06 14:01:36 --> Loader Class Initialized
INFO - 2024-11-06 14:01:36 --> Helper loaded: url_helper
INFO - 2024-11-06 14:01:36 --> Helper loaded: file_helper
INFO - 2024-11-06 14:01:36 --> Helper loaded: form_helper
INFO - 2024-11-06 14:01:36 --> Helper loaded: my_helper
INFO - 2024-11-06 14:01:36 --> Database Driver Class Initialized
INFO - 2024-11-06 14:01:36 --> Session: Class initialized using 'files' driver.
INFO - 2024-11-06 14:01:36 --> Controller Class Initialized
DEBUG - 2024-11-06 14:01:36 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php
INFO - 2024-11-06 14:01:40 --> Final output sent to browser
DEBUG - 2024-11-06 14:01:40 --> Total execution time: 3.9000
