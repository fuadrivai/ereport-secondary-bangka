<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2024-08-05 03:21:28 --> Config Class Initialized
INFO - 2024-08-05 03:21:28 --> Hooks Class Initialized
DEBUG - 2024-08-05 03:21:28 --> UTF-8 Support Enabled
INFO - 2024-08-05 03:21:28 --> Utf8 Class Initialized
INFO - 2024-08-05 03:21:28 --> URI Class Initialized
INFO - 2024-08-05 03:21:28 --> Router Class Initialized
INFO - 2024-08-05 03:21:28 --> Output Class Initialized
INFO - 2024-08-05 03:21:28 --> Security Class Initialized
DEBUG - 2024-08-05 03:21:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-08-05 03:21:28 --> Input Class Initialized
INFO - 2024-08-05 03:21:28 --> Language Class Initialized
INFO - 2024-08-05 03:21:28 --> Language Class Initialized
INFO - 2024-08-05 03:21:28 --> Config Class Initialized
INFO - 2024-08-05 03:21:28 --> Loader Class Initialized
INFO - 2024-08-05 03:21:28 --> Helper loaded: url_helper
INFO - 2024-08-05 03:21:28 --> Helper loaded: file_helper
INFO - 2024-08-05 03:21:28 --> Helper loaded: form_helper
INFO - 2024-08-05 03:21:28 --> Helper loaded: my_helper
INFO - 2024-08-05 03:21:28 --> Database Driver Class Initialized
INFO - 2024-08-05 03:21:28 --> Session: Class initialized using 'files' driver.
INFO - 2024-08-05 03:21:28 --> Controller Class Initialized
INFO - 2024-08-05 03:21:28 --> Helper loaded: cookie_helper
INFO - 2024-08-05 03:21:28 --> Final output sent to browser
DEBUG - 2024-08-05 03:21:28 --> Total execution time: 0.0903
INFO - 2024-08-05 03:21:29 --> Config Class Initialized
INFO - 2024-08-05 03:21:29 --> Hooks Class Initialized
DEBUG - 2024-08-05 03:21:29 --> UTF-8 Support Enabled
INFO - 2024-08-05 03:21:29 --> Utf8 Class Initialized
INFO - 2024-08-05 03:21:29 --> URI Class Initialized
INFO - 2024-08-05 03:21:29 --> Router Class Initialized
INFO - 2024-08-05 03:21:29 --> Output Class Initialized
INFO - 2024-08-05 03:21:29 --> Security Class Initialized
DEBUG - 2024-08-05 03:21:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-08-05 03:21:29 --> Input Class Initialized
INFO - 2024-08-05 03:21:29 --> Language Class Initialized
INFO - 2024-08-05 03:21:29 --> Language Class Initialized
INFO - 2024-08-05 03:21:29 --> Config Class Initialized
INFO - 2024-08-05 03:21:29 --> Loader Class Initialized
INFO - 2024-08-05 03:21:29 --> Helper loaded: url_helper
INFO - 2024-08-05 03:21:29 --> Helper loaded: file_helper
INFO - 2024-08-05 03:21:29 --> Helper loaded: form_helper
INFO - 2024-08-05 03:21:29 --> Helper loaded: my_helper
INFO - 2024-08-05 03:21:29 --> Database Driver Class Initialized
INFO - 2024-08-05 03:21:29 --> Session: Class initialized using 'files' driver.
INFO - 2024-08-05 03:21:29 --> Controller Class Initialized
INFO - 2024-08-05 03:21:29 --> Helper loaded: cookie_helper
INFO - 2024-08-05 03:21:29 --> Config Class Initialized
INFO - 2024-08-05 03:21:29 --> Hooks Class Initialized
DEBUG - 2024-08-05 03:21:29 --> UTF-8 Support Enabled
INFO - 2024-08-05 03:21:29 --> Utf8 Class Initialized
INFO - 2024-08-05 03:21:29 --> URI Class Initialized
INFO - 2024-08-05 03:21:29 --> Router Class Initialized
INFO - 2024-08-05 03:21:29 --> Output Class Initialized
INFO - 2024-08-05 03:21:29 --> Security Class Initialized
DEBUG - 2024-08-05 03:21:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-08-05 03:21:29 --> Input Class Initialized
INFO - 2024-08-05 03:21:29 --> Language Class Initialized
INFO - 2024-08-05 03:21:29 --> Language Class Initialized
INFO - 2024-08-05 03:21:29 --> Config Class Initialized
INFO - 2024-08-05 03:21:29 --> Loader Class Initialized
INFO - 2024-08-05 03:21:29 --> Helper loaded: url_helper
INFO - 2024-08-05 03:21:29 --> Helper loaded: file_helper
INFO - 2024-08-05 03:21:29 --> Helper loaded: form_helper
INFO - 2024-08-05 03:21:29 --> Helper loaded: my_helper
INFO - 2024-08-05 03:21:29 --> Database Driver Class Initialized
INFO - 2024-08-05 03:21:29 --> Session: Class initialized using 'files' driver.
INFO - 2024-08-05 03:21:29 --> Controller Class Initialized
DEBUG - 2024-08-05 03:21:29 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/lihat_raport/views/list.php
DEBUG - 2024-08-05 03:21:29 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-08-05 03:21:29 --> Final output sent to browser
DEBUG - 2024-08-05 03:21:29 --> Total execution time: 0.0510
INFO - 2024-08-05 03:21:36 --> Config Class Initialized
INFO - 2024-08-05 03:21:36 --> Hooks Class Initialized
DEBUG - 2024-08-05 03:21:36 --> UTF-8 Support Enabled
INFO - 2024-08-05 03:21:36 --> Utf8 Class Initialized
INFO - 2024-08-05 03:21:36 --> URI Class Initialized
INFO - 2024-08-05 03:21:36 --> Router Class Initialized
INFO - 2024-08-05 03:21:36 --> Output Class Initialized
INFO - 2024-08-05 03:21:36 --> Security Class Initialized
DEBUG - 2024-08-05 03:21:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-08-05 03:21:36 --> Input Class Initialized
INFO - 2024-08-05 03:21:36 --> Language Class Initialized
INFO - 2024-08-05 03:21:36 --> Language Class Initialized
INFO - 2024-08-05 03:21:36 --> Config Class Initialized
INFO - 2024-08-05 03:21:36 --> Loader Class Initialized
INFO - 2024-08-05 03:21:36 --> Helper loaded: url_helper
INFO - 2024-08-05 03:21:36 --> Helper loaded: file_helper
INFO - 2024-08-05 03:21:36 --> Helper loaded: form_helper
INFO - 2024-08-05 03:21:36 --> Helper loaded: my_helper
INFO - 2024-08-05 03:21:36 --> Database Driver Class Initialized
INFO - 2024-08-05 03:21:36 --> Session: Class initialized using 'files' driver.
INFO - 2024-08-05 03:21:36 --> Controller Class Initialized
ERROR - 2024-08-05 03:21:36 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 2591
ERROR - 2024-08-05 03:21:36 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 3156
ERROR - 2024-08-05 03:21:36 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 3194
ERROR - 2024-08-05 03:21:36 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 3232
ERROR - 2024-08-05 03:21:36 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 3271
ERROR - 2024-08-05 03:21:36 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 3388
ERROR - 2024-08-05 03:21:36 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 3507
ERROR - 2024-08-05 03:21:36 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 3626
ERROR - 2024-08-05 03:21:36 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 3745
ERROR - 2024-08-05 03:21:36 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/views/cetak_mh.php 6
ERROR - 2024-08-05 03:21:36 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/views/cetak_mh.php 6
ERROR - 2024-08-05 03:21:36 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/views/cetak_mh.php 40
ERROR - 2024-08-05 03:21:36 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/views/cetak_mh.php 44
ERROR - 2024-08-05 03:21:36 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/views/cetak_mh.php 44
ERROR - 2024-08-05 03:21:36 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/views/cetak_mh.php 65
ERROR - 2024-08-05 03:21:36 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/views/cetak_mh.php 65
DEBUG - 2024-08-05 03:21:36 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/views/cetak_mh.php
INFO - 2024-08-05 11:33:05 --> Config Class Initialized
INFO - 2024-08-05 11:33:05 --> Hooks Class Initialized
DEBUG - 2024-08-05 11:33:05 --> UTF-8 Support Enabled
INFO - 2024-08-05 11:33:05 --> Utf8 Class Initialized
INFO - 2024-08-05 11:33:05 --> URI Class Initialized
DEBUG - 2024-08-05 11:33:05 --> No URI present. Default controller set.
INFO - 2024-08-05 11:33:05 --> Router Class Initialized
INFO - 2024-08-05 11:33:05 --> Output Class Initialized
INFO - 2024-08-05 11:33:05 --> Security Class Initialized
DEBUG - 2024-08-05 11:33:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-08-05 11:33:05 --> Input Class Initialized
INFO - 2024-08-05 11:33:05 --> Language Class Initialized
INFO - 2024-08-05 11:33:05 --> Language Class Initialized
INFO - 2024-08-05 11:33:05 --> Config Class Initialized
INFO - 2024-08-05 11:33:05 --> Loader Class Initialized
INFO - 2024-08-05 11:33:05 --> Helper loaded: url_helper
INFO - 2024-08-05 11:33:05 --> Helper loaded: file_helper
INFO - 2024-08-05 11:33:05 --> Helper loaded: form_helper
INFO - 2024-08-05 11:33:05 --> Helper loaded: my_helper
INFO - 2024-08-05 11:33:05 --> Database Driver Class Initialized
INFO - 2024-08-05 11:33:05 --> Session: Class initialized using 'files' driver.
INFO - 2024-08-05 11:33:05 --> Controller Class Initialized
INFO - 2024-08-05 11:33:05 --> Config Class Initialized
INFO - 2024-08-05 11:33:05 --> Hooks Class Initialized
DEBUG - 2024-08-05 11:33:05 --> UTF-8 Support Enabled
INFO - 2024-08-05 11:33:05 --> Utf8 Class Initialized
INFO - 2024-08-05 11:33:05 --> URI Class Initialized
INFO - 2024-08-05 11:33:05 --> Router Class Initialized
INFO - 2024-08-05 11:33:05 --> Output Class Initialized
INFO - 2024-08-05 11:33:05 --> Security Class Initialized
DEBUG - 2024-08-05 11:33:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-08-05 11:33:05 --> Input Class Initialized
INFO - 2024-08-05 11:33:05 --> Language Class Initialized
INFO - 2024-08-05 11:33:05 --> Language Class Initialized
INFO - 2024-08-05 11:33:05 --> Config Class Initialized
INFO - 2024-08-05 11:33:05 --> Loader Class Initialized
INFO - 2024-08-05 11:33:05 --> Helper loaded: url_helper
INFO - 2024-08-05 11:33:05 --> Helper loaded: file_helper
INFO - 2024-08-05 11:33:05 --> Helper loaded: form_helper
INFO - 2024-08-05 11:33:05 --> Helper loaded: my_helper
INFO - 2024-08-05 11:33:05 --> Database Driver Class Initialized
INFO - 2024-08-05 11:33:05 --> Session: Class initialized using 'files' driver.
INFO - 2024-08-05 11:33:05 --> Controller Class Initialized
DEBUG - 2024-08-05 11:33:05 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/login/views/login.php
DEBUG - 2024-08-05 11:33:05 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-08-05 11:33:05 --> Final output sent to browser
DEBUG - 2024-08-05 11:33:05 --> Total execution time: 0.0301
INFO - 2024-08-05 11:33:11 --> Config Class Initialized
INFO - 2024-08-05 11:33:11 --> Hooks Class Initialized
DEBUG - 2024-08-05 11:33:11 --> UTF-8 Support Enabled
INFO - 2024-08-05 11:33:11 --> Utf8 Class Initialized
INFO - 2024-08-05 11:33:11 --> URI Class Initialized
INFO - 2024-08-05 11:33:11 --> Router Class Initialized
INFO - 2024-08-05 11:33:11 --> Output Class Initialized
INFO - 2024-08-05 11:33:11 --> Security Class Initialized
DEBUG - 2024-08-05 11:33:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-08-05 11:33:11 --> Input Class Initialized
INFO - 2024-08-05 11:33:11 --> Language Class Initialized
INFO - 2024-08-05 11:33:11 --> Language Class Initialized
INFO - 2024-08-05 11:33:11 --> Config Class Initialized
INFO - 2024-08-05 11:33:11 --> Loader Class Initialized
INFO - 2024-08-05 11:33:11 --> Helper loaded: url_helper
INFO - 2024-08-05 11:33:11 --> Helper loaded: file_helper
INFO - 2024-08-05 11:33:11 --> Helper loaded: form_helper
INFO - 2024-08-05 11:33:11 --> Helper loaded: my_helper
INFO - 2024-08-05 11:33:12 --> Database Driver Class Initialized
INFO - 2024-08-05 11:33:12 --> Session: Class initialized using 'files' driver.
INFO - 2024-08-05 11:33:12 --> Controller Class Initialized
INFO - 2024-08-05 11:33:12 --> Final output sent to browser
DEBUG - 2024-08-05 11:33:12 --> Total execution time: 0.0932
INFO - 2024-08-05 11:33:16 --> Config Class Initialized
INFO - 2024-08-05 11:33:16 --> Hooks Class Initialized
DEBUG - 2024-08-05 11:33:16 --> UTF-8 Support Enabled
INFO - 2024-08-05 11:33:16 --> Utf8 Class Initialized
INFO - 2024-08-05 11:33:16 --> URI Class Initialized
INFO - 2024-08-05 11:33:16 --> Router Class Initialized
INFO - 2024-08-05 11:33:16 --> Output Class Initialized
INFO - 2024-08-05 11:33:16 --> Security Class Initialized
DEBUG - 2024-08-05 11:33:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-08-05 11:33:16 --> Input Class Initialized
INFO - 2024-08-05 11:33:16 --> Language Class Initialized
INFO - 2024-08-05 11:33:16 --> Language Class Initialized
INFO - 2024-08-05 11:33:16 --> Config Class Initialized
INFO - 2024-08-05 11:33:16 --> Loader Class Initialized
INFO - 2024-08-05 11:33:16 --> Helper loaded: url_helper
INFO - 2024-08-05 11:33:16 --> Helper loaded: file_helper
INFO - 2024-08-05 11:33:16 --> Helper loaded: form_helper
INFO - 2024-08-05 11:33:16 --> Helper loaded: my_helper
INFO - 2024-08-05 11:33:16 --> Database Driver Class Initialized
INFO - 2024-08-05 11:33:16 --> Session: Class initialized using 'files' driver.
INFO - 2024-08-05 11:33:16 --> Controller Class Initialized
INFO - 2024-08-05 11:33:16 --> Helper loaded: cookie_helper
INFO - 2024-08-05 11:33:16 --> Final output sent to browser
DEBUG - 2024-08-05 11:33:16 --> Total execution time: 0.0293
INFO - 2024-08-05 11:33:16 --> Config Class Initialized
INFO - 2024-08-05 11:33:16 --> Hooks Class Initialized
DEBUG - 2024-08-05 11:33:16 --> UTF-8 Support Enabled
INFO - 2024-08-05 11:33:16 --> Utf8 Class Initialized
INFO - 2024-08-05 11:33:16 --> URI Class Initialized
INFO - 2024-08-05 11:33:16 --> Router Class Initialized
INFO - 2024-08-05 11:33:16 --> Output Class Initialized
INFO - 2024-08-05 11:33:16 --> Security Class Initialized
DEBUG - 2024-08-05 11:33:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-08-05 11:33:16 --> Input Class Initialized
INFO - 2024-08-05 11:33:16 --> Language Class Initialized
INFO - 2024-08-05 11:33:16 --> Language Class Initialized
INFO - 2024-08-05 11:33:16 --> Config Class Initialized
INFO - 2024-08-05 11:33:16 --> Loader Class Initialized
INFO - 2024-08-05 11:33:16 --> Helper loaded: url_helper
INFO - 2024-08-05 11:33:16 --> Helper loaded: file_helper
INFO - 2024-08-05 11:33:16 --> Helper loaded: form_helper
INFO - 2024-08-05 11:33:16 --> Helper loaded: my_helper
INFO - 2024-08-05 11:33:16 --> Database Driver Class Initialized
INFO - 2024-08-05 11:33:16 --> Session: Class initialized using 'files' driver.
INFO - 2024-08-05 11:33:16 --> Controller Class Initialized
DEBUG - 2024-08-05 11:33:16 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/home/views/v_home.php
DEBUG - 2024-08-05 11:33:16 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-08-05 11:33:16 --> Final output sent to browser
DEBUG - 2024-08-05 11:33:16 --> Total execution time: 0.0407
INFO - 2024-08-05 11:33:18 --> Config Class Initialized
INFO - 2024-08-05 11:33:18 --> Hooks Class Initialized
DEBUG - 2024-08-05 11:33:18 --> UTF-8 Support Enabled
INFO - 2024-08-05 11:33:18 --> Utf8 Class Initialized
INFO - 2024-08-05 11:33:18 --> URI Class Initialized
INFO - 2024-08-05 11:33:18 --> Router Class Initialized
INFO - 2024-08-05 11:33:18 --> Output Class Initialized
INFO - 2024-08-05 11:33:18 --> Security Class Initialized
DEBUG - 2024-08-05 11:33:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-08-05 11:33:18 --> Input Class Initialized
INFO - 2024-08-05 11:33:18 --> Language Class Initialized
INFO - 2024-08-05 11:33:18 --> Language Class Initialized
INFO - 2024-08-05 11:33:18 --> Config Class Initialized
INFO - 2024-08-05 11:33:18 --> Loader Class Initialized
INFO - 2024-08-05 11:33:18 --> Helper loaded: url_helper
INFO - 2024-08-05 11:33:18 --> Helper loaded: file_helper
INFO - 2024-08-05 11:33:18 --> Helper loaded: form_helper
INFO - 2024-08-05 11:33:18 --> Helper loaded: my_helper
INFO - 2024-08-05 11:33:18 --> Database Driver Class Initialized
INFO - 2024-08-05 11:33:18 --> Session: Class initialized using 'files' driver.
INFO - 2024-08-05 11:33:18 --> Controller Class Initialized
DEBUG - 2024-08-05 11:33:18 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/data_siswa/views/list.php
DEBUG - 2024-08-05 11:33:18 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-08-05 11:33:18 --> Final output sent to browser
DEBUG - 2024-08-05 11:33:18 --> Total execution time: 0.0387
INFO - 2024-08-05 11:33:18 --> Config Class Initialized
INFO - 2024-08-05 11:33:18 --> Hooks Class Initialized
DEBUG - 2024-08-05 11:33:18 --> UTF-8 Support Enabled
INFO - 2024-08-05 11:33:18 --> Utf8 Class Initialized
INFO - 2024-08-05 11:33:18 --> URI Class Initialized
INFO - 2024-08-05 11:33:18 --> Router Class Initialized
INFO - 2024-08-05 11:33:18 --> Output Class Initialized
INFO - 2024-08-05 11:33:18 --> Security Class Initialized
DEBUG - 2024-08-05 11:33:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-08-05 11:33:18 --> Input Class Initialized
INFO - 2024-08-05 11:33:18 --> Language Class Initialized
ERROR - 2024-08-05 11:33:18 --> 404 Page Not Found: /index
INFO - 2024-08-05 11:33:18 --> Config Class Initialized
INFO - 2024-08-05 11:33:18 --> Hooks Class Initialized
DEBUG - 2024-08-05 11:33:18 --> UTF-8 Support Enabled
INFO - 2024-08-05 11:33:18 --> Utf8 Class Initialized
INFO - 2024-08-05 11:33:18 --> URI Class Initialized
INFO - 2024-08-05 11:33:18 --> Router Class Initialized
INFO - 2024-08-05 11:33:18 --> Output Class Initialized
INFO - 2024-08-05 11:33:18 --> Security Class Initialized
DEBUG - 2024-08-05 11:33:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-08-05 11:33:18 --> Input Class Initialized
INFO - 2024-08-05 11:33:18 --> Language Class Initialized
INFO - 2024-08-05 11:33:18 --> Language Class Initialized
INFO - 2024-08-05 11:33:18 --> Config Class Initialized
INFO - 2024-08-05 11:33:18 --> Loader Class Initialized
INFO - 2024-08-05 11:33:18 --> Helper loaded: url_helper
INFO - 2024-08-05 11:33:18 --> Helper loaded: file_helper
INFO - 2024-08-05 11:33:18 --> Helper loaded: form_helper
INFO - 2024-08-05 11:33:18 --> Helper loaded: my_helper
INFO - 2024-08-05 11:33:18 --> Database Driver Class Initialized
INFO - 2024-08-05 11:33:18 --> Session: Class initialized using 'files' driver.
INFO - 2024-08-05 11:33:18 --> Controller Class Initialized
INFO - 2024-08-05 11:33:25 --> Config Class Initialized
INFO - 2024-08-05 11:33:25 --> Hooks Class Initialized
DEBUG - 2024-08-05 11:33:25 --> UTF-8 Support Enabled
INFO - 2024-08-05 11:33:25 --> Utf8 Class Initialized
INFO - 2024-08-05 11:33:25 --> URI Class Initialized
INFO - 2024-08-05 11:33:25 --> Router Class Initialized
INFO - 2024-08-05 11:33:25 --> Output Class Initialized
INFO - 2024-08-05 11:33:25 --> Security Class Initialized
DEBUG - 2024-08-05 11:33:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-08-05 11:33:25 --> Input Class Initialized
INFO - 2024-08-05 11:33:25 --> Language Class Initialized
INFO - 2024-08-05 11:33:25 --> Language Class Initialized
INFO - 2024-08-05 11:33:25 --> Config Class Initialized
INFO - 2024-08-05 11:33:25 --> Loader Class Initialized
INFO - 2024-08-05 11:33:25 --> Helper loaded: url_helper
INFO - 2024-08-05 11:33:25 --> Helper loaded: file_helper
INFO - 2024-08-05 11:33:25 --> Helper loaded: form_helper
INFO - 2024-08-05 11:33:25 --> Helper loaded: my_helper
INFO - 2024-08-05 11:33:25 --> Database Driver Class Initialized
INFO - 2024-08-05 11:33:25 --> Session: Class initialized using 'files' driver.
INFO - 2024-08-05 11:33:25 --> Controller Class Initialized
INFO - 2024-08-05 11:33:25 --> Helper loaded: cookie_helper
INFO - 2024-08-05 11:33:25 --> Config Class Initialized
INFO - 2024-08-05 11:33:25 --> Hooks Class Initialized
DEBUG - 2024-08-05 11:33:25 --> UTF-8 Support Enabled
INFO - 2024-08-05 11:33:25 --> Utf8 Class Initialized
INFO - 2024-08-05 11:33:25 --> URI Class Initialized
INFO - 2024-08-05 11:33:25 --> Router Class Initialized
INFO - 2024-08-05 11:33:25 --> Output Class Initialized
INFO - 2024-08-05 11:33:25 --> Security Class Initialized
DEBUG - 2024-08-05 11:33:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-08-05 11:33:25 --> Input Class Initialized
INFO - 2024-08-05 11:33:25 --> Language Class Initialized
INFO - 2024-08-05 11:33:25 --> Language Class Initialized
INFO - 2024-08-05 11:33:25 --> Config Class Initialized
INFO - 2024-08-05 11:33:25 --> Loader Class Initialized
INFO - 2024-08-05 11:33:25 --> Helper loaded: url_helper
INFO - 2024-08-05 11:33:25 --> Helper loaded: file_helper
INFO - 2024-08-05 11:33:25 --> Helper loaded: form_helper
INFO - 2024-08-05 11:33:25 --> Helper loaded: my_helper
INFO - 2024-08-05 11:33:25 --> Database Driver Class Initialized
INFO - 2024-08-05 11:33:25 --> Session: Class initialized using 'files' driver.
INFO - 2024-08-05 11:33:25 --> Controller Class Initialized
INFO - 2024-08-05 11:33:25 --> Config Class Initialized
INFO - 2024-08-05 11:33:25 --> Hooks Class Initialized
DEBUG - 2024-08-05 11:33:25 --> UTF-8 Support Enabled
INFO - 2024-08-05 11:33:25 --> Utf8 Class Initialized
INFO - 2024-08-05 11:33:25 --> URI Class Initialized
INFO - 2024-08-05 11:33:25 --> Router Class Initialized
INFO - 2024-08-05 11:33:25 --> Output Class Initialized
INFO - 2024-08-05 11:33:25 --> Security Class Initialized
DEBUG - 2024-08-05 11:33:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-08-05 11:33:25 --> Input Class Initialized
INFO - 2024-08-05 11:33:25 --> Language Class Initialized
INFO - 2024-08-05 11:33:25 --> Language Class Initialized
INFO - 2024-08-05 11:33:25 --> Config Class Initialized
INFO - 2024-08-05 11:33:25 --> Loader Class Initialized
INFO - 2024-08-05 11:33:25 --> Helper loaded: url_helper
INFO - 2024-08-05 11:33:25 --> Helper loaded: file_helper
INFO - 2024-08-05 11:33:25 --> Helper loaded: form_helper
INFO - 2024-08-05 11:33:25 --> Helper loaded: my_helper
INFO - 2024-08-05 11:33:25 --> Database Driver Class Initialized
INFO - 2024-08-05 11:33:25 --> Session: Class initialized using 'files' driver.
INFO - 2024-08-05 11:33:25 --> Controller Class Initialized
DEBUG - 2024-08-05 11:33:25 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/login/views/login.php
DEBUG - 2024-08-05 11:33:25 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-08-05 11:33:25 --> Final output sent to browser
DEBUG - 2024-08-05 11:33:25 --> Total execution time: 0.0260
INFO - 2024-08-05 11:33:33 --> Config Class Initialized
INFO - 2024-08-05 11:33:33 --> Hooks Class Initialized
DEBUG - 2024-08-05 11:33:33 --> UTF-8 Support Enabled
INFO - 2024-08-05 11:33:33 --> Utf8 Class Initialized
INFO - 2024-08-05 11:33:33 --> URI Class Initialized
INFO - 2024-08-05 11:33:33 --> Router Class Initialized
INFO - 2024-08-05 11:33:33 --> Output Class Initialized
INFO - 2024-08-05 11:33:33 --> Security Class Initialized
DEBUG - 2024-08-05 11:33:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-08-05 11:33:33 --> Input Class Initialized
INFO - 2024-08-05 11:33:33 --> Language Class Initialized
INFO - 2024-08-05 11:33:33 --> Language Class Initialized
INFO - 2024-08-05 11:33:33 --> Config Class Initialized
INFO - 2024-08-05 11:33:33 --> Loader Class Initialized
INFO - 2024-08-05 11:33:33 --> Helper loaded: url_helper
INFO - 2024-08-05 11:33:33 --> Helper loaded: file_helper
INFO - 2024-08-05 11:33:33 --> Helper loaded: form_helper
INFO - 2024-08-05 11:33:33 --> Helper loaded: my_helper
INFO - 2024-08-05 11:33:33 --> Database Driver Class Initialized
INFO - 2024-08-05 11:33:33 --> Session: Class initialized using 'files' driver.
INFO - 2024-08-05 11:33:33 --> Controller Class Initialized
INFO - 2024-08-05 11:33:33 --> Helper loaded: cookie_helper
INFO - 2024-08-05 11:33:33 --> Final output sent to browser
DEBUG - 2024-08-05 11:33:33 --> Total execution time: 0.0370
INFO - 2024-08-05 11:33:33 --> Config Class Initialized
INFO - 2024-08-05 11:33:33 --> Hooks Class Initialized
DEBUG - 2024-08-05 11:33:33 --> UTF-8 Support Enabled
INFO - 2024-08-05 11:33:33 --> Utf8 Class Initialized
INFO - 2024-08-05 11:33:33 --> URI Class Initialized
INFO - 2024-08-05 11:33:33 --> Router Class Initialized
INFO - 2024-08-05 11:33:33 --> Output Class Initialized
INFO - 2024-08-05 11:33:33 --> Security Class Initialized
DEBUG - 2024-08-05 11:33:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-08-05 11:33:33 --> Input Class Initialized
INFO - 2024-08-05 11:33:33 --> Language Class Initialized
INFO - 2024-08-05 11:33:33 --> Language Class Initialized
INFO - 2024-08-05 11:33:33 --> Config Class Initialized
INFO - 2024-08-05 11:33:33 --> Loader Class Initialized
INFO - 2024-08-05 11:33:33 --> Helper loaded: url_helper
INFO - 2024-08-05 11:33:33 --> Helper loaded: file_helper
INFO - 2024-08-05 11:33:33 --> Helper loaded: form_helper
INFO - 2024-08-05 11:33:33 --> Helper loaded: my_helper
INFO - 2024-08-05 11:33:33 --> Database Driver Class Initialized
INFO - 2024-08-05 11:33:33 --> Session: Class initialized using 'files' driver.
INFO - 2024-08-05 11:33:33 --> Controller Class Initialized
DEBUG - 2024-08-05 11:33:33 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/home/views/v_home_siswa.php
DEBUG - 2024-08-05 11:33:33 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-08-05 11:33:33 --> Final output sent to browser
DEBUG - 2024-08-05 11:33:33 --> Total execution time: 0.0284
INFO - 2024-08-05 11:33:34 --> Config Class Initialized
INFO - 2024-08-05 11:33:34 --> Hooks Class Initialized
DEBUG - 2024-08-05 11:33:34 --> UTF-8 Support Enabled
INFO - 2024-08-05 11:33:34 --> Utf8 Class Initialized
INFO - 2024-08-05 11:33:34 --> URI Class Initialized
INFO - 2024-08-05 11:33:34 --> Router Class Initialized
INFO - 2024-08-05 11:33:34 --> Output Class Initialized
INFO - 2024-08-05 11:33:34 --> Security Class Initialized
DEBUG - 2024-08-05 11:33:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-08-05 11:33:34 --> Input Class Initialized
INFO - 2024-08-05 11:33:34 --> Language Class Initialized
INFO - 2024-08-05 11:33:34 --> Language Class Initialized
INFO - 2024-08-05 11:33:34 --> Config Class Initialized
INFO - 2024-08-05 11:33:34 --> Loader Class Initialized
INFO - 2024-08-05 11:33:34 --> Helper loaded: url_helper
INFO - 2024-08-05 11:33:34 --> Helper loaded: file_helper
INFO - 2024-08-05 11:33:34 --> Helper loaded: form_helper
INFO - 2024-08-05 11:33:34 --> Helper loaded: my_helper
INFO - 2024-08-05 11:33:34 --> Database Driver Class Initialized
INFO - 2024-08-05 11:33:34 --> Session: Class initialized using 'files' driver.
INFO - 2024-08-05 11:33:34 --> Controller Class Initialized
DEBUG - 2024-08-05 11:33:34 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/lihat_raport/views/list.php
DEBUG - 2024-08-05 11:33:34 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-08-05 11:33:34 --> Final output sent to browser
DEBUG - 2024-08-05 11:33:34 --> Total execution time: 0.1710
INFO - 2024-08-05 11:47:14 --> Config Class Initialized
INFO - 2024-08-05 11:47:14 --> Hooks Class Initialized
DEBUG - 2024-08-05 11:47:14 --> UTF-8 Support Enabled
INFO - 2024-08-05 11:47:14 --> Utf8 Class Initialized
INFO - 2024-08-05 11:47:14 --> URI Class Initialized
INFO - 2024-08-05 11:47:14 --> Router Class Initialized
INFO - 2024-08-05 11:47:14 --> Output Class Initialized
INFO - 2024-08-05 11:47:14 --> Security Class Initialized
DEBUG - 2024-08-05 11:47:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-08-05 11:47:14 --> Input Class Initialized
INFO - 2024-08-05 11:47:14 --> Language Class Initialized
INFO - 2024-08-05 11:47:14 --> Language Class Initialized
INFO - 2024-08-05 11:47:14 --> Config Class Initialized
INFO - 2024-08-05 11:47:14 --> Loader Class Initialized
INFO - 2024-08-05 11:47:14 --> Helper loaded: url_helper
INFO - 2024-08-05 11:47:14 --> Helper loaded: file_helper
INFO - 2024-08-05 11:47:14 --> Helper loaded: form_helper
INFO - 2024-08-05 11:47:14 --> Helper loaded: my_helper
INFO - 2024-08-05 11:47:14 --> Database Driver Class Initialized
INFO - 2024-08-05 11:47:14 --> Session: Class initialized using 'files' driver.
INFO - 2024-08-05 11:47:14 --> Controller Class Initialized
INFO - 2024-08-05 11:47:14 --> Helper loaded: cookie_helper
INFO - 2024-08-05 11:47:14 --> Config Class Initialized
INFO - 2024-08-05 11:47:14 --> Hooks Class Initialized
DEBUG - 2024-08-05 11:47:14 --> UTF-8 Support Enabled
INFO - 2024-08-05 11:47:14 --> Utf8 Class Initialized
INFO - 2024-08-05 11:47:14 --> URI Class Initialized
INFO - 2024-08-05 11:47:14 --> Router Class Initialized
INFO - 2024-08-05 11:47:14 --> Output Class Initialized
INFO - 2024-08-05 11:47:14 --> Security Class Initialized
DEBUG - 2024-08-05 11:47:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-08-05 11:47:14 --> Input Class Initialized
INFO - 2024-08-05 11:47:14 --> Language Class Initialized
INFO - 2024-08-05 11:47:14 --> Language Class Initialized
INFO - 2024-08-05 11:47:14 --> Config Class Initialized
INFO - 2024-08-05 11:47:14 --> Loader Class Initialized
INFO - 2024-08-05 11:47:14 --> Helper loaded: url_helper
INFO - 2024-08-05 11:47:14 --> Helper loaded: file_helper
INFO - 2024-08-05 11:47:14 --> Helper loaded: form_helper
INFO - 2024-08-05 11:47:14 --> Helper loaded: my_helper
INFO - 2024-08-05 11:47:14 --> Database Driver Class Initialized
INFO - 2024-08-05 11:47:14 --> Session: Class initialized using 'files' driver.
INFO - 2024-08-05 11:47:14 --> Controller Class Initialized
INFO - 2024-08-05 11:47:14 --> Config Class Initialized
INFO - 2024-08-05 11:47:14 --> Hooks Class Initialized
DEBUG - 2024-08-05 11:47:14 --> UTF-8 Support Enabled
INFO - 2024-08-05 11:47:14 --> Utf8 Class Initialized
INFO - 2024-08-05 11:47:14 --> URI Class Initialized
INFO - 2024-08-05 11:47:14 --> Router Class Initialized
INFO - 2024-08-05 11:47:14 --> Output Class Initialized
INFO - 2024-08-05 11:47:14 --> Security Class Initialized
DEBUG - 2024-08-05 11:47:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-08-05 11:47:14 --> Input Class Initialized
INFO - 2024-08-05 11:47:14 --> Language Class Initialized
INFO - 2024-08-05 11:47:14 --> Language Class Initialized
INFO - 2024-08-05 11:47:14 --> Config Class Initialized
INFO - 2024-08-05 11:47:14 --> Loader Class Initialized
INFO - 2024-08-05 11:47:14 --> Helper loaded: url_helper
INFO - 2024-08-05 11:47:14 --> Helper loaded: file_helper
INFO - 2024-08-05 11:47:14 --> Helper loaded: form_helper
INFO - 2024-08-05 11:47:14 --> Helper loaded: my_helper
INFO - 2024-08-05 11:47:14 --> Database Driver Class Initialized
INFO - 2024-08-05 11:47:14 --> Session: Class initialized using 'files' driver.
INFO - 2024-08-05 11:47:14 --> Controller Class Initialized
DEBUG - 2024-08-05 11:47:14 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/login/views/login.php
DEBUG - 2024-08-05 11:47:14 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-08-05 11:47:14 --> Final output sent to browser
DEBUG - 2024-08-05 11:47:14 --> Total execution time: 0.0307
INFO - 2024-08-05 12:40:30 --> Config Class Initialized
INFO - 2024-08-05 12:40:30 --> Hooks Class Initialized
DEBUG - 2024-08-05 12:40:30 --> UTF-8 Support Enabled
INFO - 2024-08-05 12:40:30 --> Utf8 Class Initialized
INFO - 2024-08-05 12:40:30 --> URI Class Initialized
INFO - 2024-08-05 12:40:30 --> Router Class Initialized
INFO - 2024-08-05 12:40:30 --> Output Class Initialized
INFO - 2024-08-05 12:40:30 --> Security Class Initialized
DEBUG - 2024-08-05 12:40:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-08-05 12:40:30 --> Input Class Initialized
INFO - 2024-08-05 12:40:30 --> Language Class Initialized
INFO - 2024-08-05 12:40:30 --> Language Class Initialized
INFO - 2024-08-05 12:40:30 --> Config Class Initialized
INFO - 2024-08-05 12:40:30 --> Loader Class Initialized
INFO - 2024-08-05 12:40:30 --> Helper loaded: url_helper
INFO - 2024-08-05 12:40:30 --> Helper loaded: file_helper
INFO - 2024-08-05 12:40:30 --> Helper loaded: form_helper
INFO - 2024-08-05 12:40:30 --> Helper loaded: my_helper
INFO - 2024-08-05 12:40:30 --> Database Driver Class Initialized
INFO - 2024-08-05 12:40:30 --> Session: Class initialized using 'files' driver.
INFO - 2024-08-05 12:40:30 --> Controller Class Initialized
DEBUG - 2024-08-05 12:40:30 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/login/views/login.php
DEBUG - 2024-08-05 12:40:30 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-08-05 12:40:30 --> Final output sent to browser
DEBUG - 2024-08-05 12:40:30 --> Total execution time: 0.0461
INFO - 2024-08-05 13:59:23 --> Config Class Initialized
INFO - 2024-08-05 13:59:23 --> Hooks Class Initialized
DEBUG - 2024-08-05 13:59:23 --> UTF-8 Support Enabled
INFO - 2024-08-05 13:59:23 --> Utf8 Class Initialized
INFO - 2024-08-05 13:59:23 --> URI Class Initialized
INFO - 2024-08-05 13:59:23 --> Router Class Initialized
INFO - 2024-08-05 13:59:23 --> Output Class Initialized
INFO - 2024-08-05 13:59:23 --> Security Class Initialized
DEBUG - 2024-08-05 13:59:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-08-05 13:59:23 --> Input Class Initialized
INFO - 2024-08-05 13:59:23 --> Language Class Initialized
INFO - 2024-08-05 13:59:23 --> Language Class Initialized
INFO - 2024-08-05 13:59:23 --> Config Class Initialized
INFO - 2024-08-05 13:59:23 --> Loader Class Initialized
INFO - 2024-08-05 13:59:23 --> Helper loaded: url_helper
INFO - 2024-08-05 13:59:23 --> Helper loaded: file_helper
INFO - 2024-08-05 13:59:23 --> Helper loaded: form_helper
INFO - 2024-08-05 13:59:23 --> Helper loaded: my_helper
INFO - 2024-08-05 13:59:23 --> Database Driver Class Initialized
INFO - 2024-08-05 13:59:23 --> Session: Class initialized using 'files' driver.
INFO - 2024-08-05 13:59:23 --> Controller Class Initialized
INFO - 2024-08-05 13:59:23 --> Helper loaded: cookie_helper
INFO - 2024-08-05 13:59:23 --> Final output sent to browser
DEBUG - 2024-08-05 13:59:23 --> Total execution time: 0.0558
INFO - 2024-08-05 13:59:24 --> Config Class Initialized
INFO - 2024-08-05 13:59:24 --> Hooks Class Initialized
DEBUG - 2024-08-05 13:59:24 --> UTF-8 Support Enabled
INFO - 2024-08-05 13:59:24 --> Utf8 Class Initialized
INFO - 2024-08-05 13:59:24 --> URI Class Initialized
INFO - 2024-08-05 13:59:24 --> Router Class Initialized
INFO - 2024-08-05 13:59:24 --> Output Class Initialized
INFO - 2024-08-05 13:59:24 --> Security Class Initialized
DEBUG - 2024-08-05 13:59:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-08-05 13:59:24 --> Input Class Initialized
INFO - 2024-08-05 13:59:24 --> Language Class Initialized
INFO - 2024-08-05 13:59:24 --> Language Class Initialized
INFO - 2024-08-05 13:59:24 --> Config Class Initialized
INFO - 2024-08-05 13:59:24 --> Loader Class Initialized
INFO - 2024-08-05 13:59:24 --> Helper loaded: url_helper
INFO - 2024-08-05 13:59:24 --> Helper loaded: file_helper
INFO - 2024-08-05 13:59:24 --> Helper loaded: form_helper
INFO - 2024-08-05 13:59:24 --> Helper loaded: my_helper
INFO - 2024-08-05 13:59:24 --> Database Driver Class Initialized
INFO - 2024-08-05 13:59:24 --> Session: Class initialized using 'files' driver.
INFO - 2024-08-05 13:59:24 --> Controller Class Initialized
INFO - 2024-08-05 13:59:24 --> Helper loaded: cookie_helper
INFO - 2024-08-05 13:59:24 --> Config Class Initialized
INFO - 2024-08-05 13:59:24 --> Hooks Class Initialized
DEBUG - 2024-08-05 13:59:24 --> UTF-8 Support Enabled
INFO - 2024-08-05 13:59:24 --> Utf8 Class Initialized
INFO - 2024-08-05 13:59:24 --> URI Class Initialized
INFO - 2024-08-05 13:59:24 --> Router Class Initialized
INFO - 2024-08-05 13:59:24 --> Output Class Initialized
INFO - 2024-08-05 13:59:24 --> Security Class Initialized
DEBUG - 2024-08-05 13:59:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-08-05 13:59:24 --> Input Class Initialized
INFO - 2024-08-05 13:59:24 --> Language Class Initialized
INFO - 2024-08-05 13:59:24 --> Language Class Initialized
INFO - 2024-08-05 13:59:24 --> Config Class Initialized
INFO - 2024-08-05 13:59:24 --> Loader Class Initialized
INFO - 2024-08-05 13:59:24 --> Helper loaded: url_helper
INFO - 2024-08-05 13:59:24 --> Helper loaded: file_helper
INFO - 2024-08-05 13:59:24 --> Helper loaded: form_helper
INFO - 2024-08-05 13:59:24 --> Helper loaded: my_helper
INFO - 2024-08-05 13:59:24 --> Database Driver Class Initialized
INFO - 2024-08-05 13:59:24 --> Session: Class initialized using 'files' driver.
INFO - 2024-08-05 13:59:24 --> Controller Class Initialized
DEBUG - 2024-08-05 13:59:24 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/lihat_raport/views/list.php
DEBUG - 2024-08-05 13:59:24 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-08-05 13:59:24 --> Final output sent to browser
DEBUG - 2024-08-05 13:59:24 --> Total execution time: 0.0343
INFO - 2024-08-05 13:59:34 --> Config Class Initialized
INFO - 2024-08-05 13:59:34 --> Hooks Class Initialized
DEBUG - 2024-08-05 13:59:34 --> UTF-8 Support Enabled
INFO - 2024-08-05 13:59:34 --> Utf8 Class Initialized
INFO - 2024-08-05 13:59:34 --> URI Class Initialized
INFO - 2024-08-05 13:59:34 --> Router Class Initialized
INFO - 2024-08-05 13:59:34 --> Output Class Initialized
INFO - 2024-08-05 13:59:34 --> Security Class Initialized
DEBUG - 2024-08-05 13:59:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-08-05 13:59:34 --> Input Class Initialized
INFO - 2024-08-05 13:59:34 --> Language Class Initialized
INFO - 2024-08-05 13:59:34 --> Language Class Initialized
INFO - 2024-08-05 13:59:34 --> Config Class Initialized
INFO - 2024-08-05 13:59:34 --> Loader Class Initialized
INFO - 2024-08-05 13:59:34 --> Helper loaded: url_helper
INFO - 2024-08-05 13:59:34 --> Helper loaded: file_helper
INFO - 2024-08-05 13:59:34 --> Helper loaded: form_helper
INFO - 2024-08-05 13:59:34 --> Helper loaded: my_helper
INFO - 2024-08-05 13:59:34 --> Database Driver Class Initialized
INFO - 2024-08-05 13:59:34 --> Session: Class initialized using 'files' driver.
INFO - 2024-08-05 13:59:34 --> Controller Class Initialized
ERROR - 2024-08-05 13:59:34 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1160
ERROR - 2024-08-05 13:59:34 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1692
ERROR - 2024-08-05 13:59:34 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1729
ERROR - 2024-08-05 13:59:34 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1767
ERROR - 2024-08-05 13:59:34 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1806
ERROR - 2024-08-05 13:59:34 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1883
ERROR - 2024-08-05 13:59:34 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1962
ERROR - 2024-08-05 13:59:34 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 2042
ERROR - 2024-08-05 13:59:34 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 2122
ERROR - 2024-08-05 13:59:34 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 2202
ERROR - 2024-08-05 13:59:34 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 2277
ERROR - 2024-08-05 13:59:34 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php 32
ERROR - 2024-08-05 13:59:34 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php 32
DEBUG - 2024-08-05 13:59:34 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php
INFO - 2024-08-05 13:59:37 --> Final output sent to browser
DEBUG - 2024-08-05 13:59:37 --> Total execution time: 3.0961
INFO - 2024-08-05 13:59:37 --> Config Class Initialized
INFO - 2024-08-05 13:59:37 --> Hooks Class Initialized
DEBUG - 2024-08-05 13:59:37 --> UTF-8 Support Enabled
INFO - 2024-08-05 13:59:37 --> Utf8 Class Initialized
INFO - 2024-08-05 13:59:37 --> URI Class Initialized
INFO - 2024-08-05 13:59:37 --> Router Class Initialized
INFO - 2024-08-05 13:59:37 --> Output Class Initialized
INFO - 2024-08-05 13:59:37 --> Security Class Initialized
DEBUG - 2024-08-05 13:59:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-08-05 13:59:37 --> Input Class Initialized
INFO - 2024-08-05 13:59:37 --> Language Class Initialized
INFO - 2024-08-05 13:59:37 --> Language Class Initialized
INFO - 2024-08-05 13:59:37 --> Config Class Initialized
INFO - 2024-08-05 13:59:37 --> Loader Class Initialized
INFO - 2024-08-05 13:59:37 --> Helper loaded: url_helper
INFO - 2024-08-05 13:59:37 --> Helper loaded: file_helper
INFO - 2024-08-05 13:59:37 --> Helper loaded: form_helper
INFO - 2024-08-05 13:59:37 --> Helper loaded: my_helper
INFO - 2024-08-05 13:59:37 --> Database Driver Class Initialized
INFO - 2024-08-05 13:59:37 --> Session: Class initialized using 'files' driver.
INFO - 2024-08-05 13:59:37 --> Controller Class Initialized
ERROR - 2024-08-05 13:59:37 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1160
ERROR - 2024-08-05 13:59:37 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1692
ERROR - 2024-08-05 13:59:37 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1729
ERROR - 2024-08-05 13:59:37 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1767
ERROR - 2024-08-05 13:59:37 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1806
ERROR - 2024-08-05 13:59:37 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1883
ERROR - 2024-08-05 13:59:37 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1962
ERROR - 2024-08-05 13:59:37 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 2042
ERROR - 2024-08-05 13:59:37 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 2122
ERROR - 2024-08-05 13:59:37 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 2202
ERROR - 2024-08-05 13:59:37 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 2277
ERROR - 2024-08-05 13:59:37 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php 32
ERROR - 2024-08-05 13:59:37 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php 32
DEBUG - 2024-08-05 13:59:37 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php
INFO - 2024-08-05 13:59:40 --> Final output sent to browser
DEBUG - 2024-08-05 13:59:40 --> Total execution time: 2.5146
INFO - 2024-08-05 13:59:40 --> Config Class Initialized
INFO - 2024-08-05 13:59:40 --> Hooks Class Initialized
DEBUG - 2024-08-05 13:59:40 --> UTF-8 Support Enabled
INFO - 2024-08-05 13:59:40 --> Utf8 Class Initialized
INFO - 2024-08-05 13:59:40 --> URI Class Initialized
INFO - 2024-08-05 13:59:40 --> Router Class Initialized
INFO - 2024-08-05 13:59:40 --> Output Class Initialized
INFO - 2024-08-05 13:59:40 --> Security Class Initialized
DEBUG - 2024-08-05 13:59:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-08-05 13:59:40 --> Input Class Initialized
INFO - 2024-08-05 13:59:40 --> Language Class Initialized
INFO - 2024-08-05 13:59:40 --> Language Class Initialized
INFO - 2024-08-05 13:59:40 --> Config Class Initialized
INFO - 2024-08-05 13:59:40 --> Loader Class Initialized
INFO - 2024-08-05 13:59:40 --> Helper loaded: url_helper
INFO - 2024-08-05 13:59:40 --> Helper loaded: file_helper
INFO - 2024-08-05 13:59:40 --> Helper loaded: form_helper
INFO - 2024-08-05 13:59:40 --> Helper loaded: my_helper
INFO - 2024-08-05 13:59:40 --> Database Driver Class Initialized
INFO - 2024-08-05 13:59:40 --> Session: Class initialized using 'files' driver.
INFO - 2024-08-05 13:59:40 --> Controller Class Initialized
ERROR - 2024-08-05 13:59:40 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1160
ERROR - 2024-08-05 13:59:40 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1692
ERROR - 2024-08-05 13:59:40 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1729
ERROR - 2024-08-05 13:59:40 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1767
ERROR - 2024-08-05 13:59:40 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1806
ERROR - 2024-08-05 13:59:40 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1883
ERROR - 2024-08-05 13:59:40 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1962
ERROR - 2024-08-05 13:59:40 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 2042
ERROR - 2024-08-05 13:59:40 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 2122
ERROR - 2024-08-05 13:59:40 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 2202
ERROR - 2024-08-05 13:59:40 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 2277
ERROR - 2024-08-05 13:59:40 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php 32
ERROR - 2024-08-05 13:59:40 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php 32
DEBUG - 2024-08-05 13:59:40 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php
INFO - 2024-08-05 13:59:40 --> Config Class Initialized
INFO - 2024-08-05 13:59:40 --> Hooks Class Initialized
DEBUG - 2024-08-05 13:59:40 --> UTF-8 Support Enabled
INFO - 2024-08-05 13:59:40 --> Utf8 Class Initialized
INFO - 2024-08-05 13:59:40 --> URI Class Initialized
INFO - 2024-08-05 13:59:40 --> Router Class Initialized
INFO - 2024-08-05 13:59:40 --> Output Class Initialized
INFO - 2024-08-05 13:59:40 --> Security Class Initialized
DEBUG - 2024-08-05 13:59:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-08-05 13:59:40 --> Input Class Initialized
INFO - 2024-08-05 13:59:40 --> Language Class Initialized
INFO - 2024-08-05 13:59:40 --> Language Class Initialized
INFO - 2024-08-05 13:59:40 --> Config Class Initialized
INFO - 2024-08-05 13:59:40 --> Loader Class Initialized
INFO - 2024-08-05 13:59:40 --> Helper loaded: url_helper
INFO - 2024-08-05 13:59:40 --> Helper loaded: file_helper
INFO - 2024-08-05 13:59:40 --> Helper loaded: form_helper
INFO - 2024-08-05 13:59:40 --> Helper loaded: my_helper
INFO - 2024-08-05 13:59:40 --> Database Driver Class Initialized
INFO - 2024-08-05 13:59:42 --> Final output sent to browser
DEBUG - 2024-08-05 13:59:42 --> Total execution time: 2.6421
INFO - 2024-08-05 13:59:42 --> Session: Class initialized using 'files' driver.
INFO - 2024-08-05 13:59:42 --> Controller Class Initialized
ERROR - 2024-08-05 13:59:42 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 2591
ERROR - 2024-08-05 13:59:42 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 3156
ERROR - 2024-08-05 13:59:42 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 3194
ERROR - 2024-08-05 13:59:42 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 3232
ERROR - 2024-08-05 13:59:42 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 3271
ERROR - 2024-08-05 13:59:42 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 3388
ERROR - 2024-08-05 13:59:42 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 3507
ERROR - 2024-08-05 13:59:42 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 3626
ERROR - 2024-08-05 13:59:42 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 3745
ERROR - 2024-08-05 13:59:42 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/views/cetak_mh.php 6
ERROR - 2024-08-05 13:59:42 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/views/cetak_mh.php 6
ERROR - 2024-08-05 13:59:42 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/views/cetak_mh.php 40
ERROR - 2024-08-05 13:59:42 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/views/cetak_mh.php 44
ERROR - 2024-08-05 13:59:42 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/views/cetak_mh.php 44
ERROR - 2024-08-05 13:59:42 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/views/cetak_mh.php 65
ERROR - 2024-08-05 13:59:42 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/views/cetak_mh.php 65
DEBUG - 2024-08-05 13:59:42 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/views/cetak_mh.php
INFO - 2024-08-05 21:10:13 --> Config Class Initialized
INFO - 2024-08-05 21:10:14 --> Hooks Class Initialized
DEBUG - 2024-08-05 21:10:14 --> UTF-8 Support Enabled
INFO - 2024-08-05 21:10:14 --> Utf8 Class Initialized
INFO - 2024-08-05 21:10:14 --> URI Class Initialized
INFO - 2024-08-05 21:10:14 --> Router Class Initialized
INFO - 2024-08-05 21:10:14 --> Output Class Initialized
INFO - 2024-08-05 21:10:14 --> Security Class Initialized
DEBUG - 2024-08-05 21:10:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-08-05 21:10:14 --> Input Class Initialized
INFO - 2024-08-05 21:10:14 --> Language Class Initialized
INFO - 2024-08-05 21:10:14 --> Language Class Initialized
INFO - 2024-08-05 21:10:14 --> Config Class Initialized
INFO - 2024-08-05 21:10:14 --> Loader Class Initialized
INFO - 2024-08-05 21:10:14 --> Helper loaded: url_helper
INFO - 2024-08-05 21:10:14 --> Helper loaded: file_helper
INFO - 2024-08-05 21:10:14 --> Helper loaded: form_helper
INFO - 2024-08-05 21:10:14 --> Helper loaded: my_helper
INFO - 2024-08-05 21:10:14 --> Database Driver Class Initialized
INFO - 2024-08-05 21:10:14 --> Session: Class initialized using 'files' driver.
INFO - 2024-08-05 21:10:14 --> Controller Class Initialized
INFO - 2024-08-05 21:10:14 --> Final output sent to browser
DEBUG - 2024-08-05 21:10:14 --> Total execution time: 0.3890
