<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2024-10-04 09:42:15 --> Config Class Initialized
INFO - 2024-10-04 09:42:15 --> Hooks Class Initialized
DEBUG - 2024-10-04 09:42:15 --> UTF-8 Support Enabled
INFO - 2024-10-04 09:42:15 --> Utf8 Class Initialized
INFO - 2024-10-04 09:42:15 --> URI Class Initialized
INFO - 2024-10-04 09:42:15 --> Router Class Initialized
INFO - 2024-10-04 09:42:15 --> Output Class Initialized
INFO - 2024-10-04 09:42:15 --> Security Class Initialized
DEBUG - 2024-10-04 09:42:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-04 09:42:15 --> Input Class Initialized
INFO - 2024-10-04 09:42:15 --> Language Class Initialized
INFO - 2024-10-04 09:42:15 --> Language Class Initialized
INFO - 2024-10-04 09:42:15 --> Config Class Initialized
INFO - 2024-10-04 09:42:15 --> Loader Class Initialized
INFO - 2024-10-04 09:42:15 --> Helper loaded: url_helper
INFO - 2024-10-04 09:42:15 --> Helper loaded: file_helper
INFO - 2024-10-04 09:42:15 --> Helper loaded: form_helper
INFO - 2024-10-04 09:42:15 --> Helper loaded: my_helper
INFO - 2024-10-04 09:42:15 --> Database Driver Class Initialized
INFO - 2024-10-04 09:42:15 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-04 09:42:15 --> Controller Class Initialized
DEBUG - 2024-10-04 09:42:15 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/login/views/login.php
DEBUG - 2024-10-04 09:42:15 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-10-04 09:42:15 --> Final output sent to browser
DEBUG - 2024-10-04 09:42:15 --> Total execution time: 0.1357
INFO - 2024-10-04 09:44:41 --> Config Class Initialized
INFO - 2024-10-04 09:44:41 --> Hooks Class Initialized
DEBUG - 2024-10-04 09:44:41 --> UTF-8 Support Enabled
INFO - 2024-10-04 09:44:41 --> Utf8 Class Initialized
INFO - 2024-10-04 09:44:41 --> URI Class Initialized
INFO - 2024-10-04 09:44:41 --> Router Class Initialized
INFO - 2024-10-04 09:44:41 --> Output Class Initialized
INFO - 2024-10-04 09:44:41 --> Security Class Initialized
DEBUG - 2024-10-04 09:44:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-04 09:44:41 --> Input Class Initialized
INFO - 2024-10-04 09:44:41 --> Language Class Initialized
INFO - 2024-10-04 09:44:41 --> Language Class Initialized
INFO - 2024-10-04 09:44:41 --> Config Class Initialized
INFO - 2024-10-04 09:44:41 --> Loader Class Initialized
INFO - 2024-10-04 09:44:41 --> Helper loaded: url_helper
INFO - 2024-10-04 09:44:41 --> Helper loaded: file_helper
INFO - 2024-10-04 09:44:41 --> Helper loaded: form_helper
INFO - 2024-10-04 09:44:41 --> Helper loaded: my_helper
INFO - 2024-10-04 09:44:41 --> Database Driver Class Initialized
INFO - 2024-10-04 09:44:41 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-04 09:44:41 --> Controller Class Initialized
INFO - 2024-10-04 09:44:41 --> Helper loaded: cookie_helper
INFO - 2024-10-04 09:44:41 --> Final output sent to browser
DEBUG - 2024-10-04 09:44:41 --> Total execution time: 0.0509
INFO - 2024-10-04 09:44:41 --> Config Class Initialized
INFO - 2024-10-04 09:44:41 --> Hooks Class Initialized
DEBUG - 2024-10-04 09:44:41 --> UTF-8 Support Enabled
INFO - 2024-10-04 09:44:41 --> Utf8 Class Initialized
INFO - 2024-10-04 09:44:41 --> URI Class Initialized
INFO - 2024-10-04 09:44:41 --> Router Class Initialized
INFO - 2024-10-04 09:44:41 --> Output Class Initialized
INFO - 2024-10-04 09:44:41 --> Security Class Initialized
DEBUG - 2024-10-04 09:44:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-04 09:44:41 --> Input Class Initialized
INFO - 2024-10-04 09:44:41 --> Language Class Initialized
INFO - 2024-10-04 09:44:41 --> Language Class Initialized
INFO - 2024-10-04 09:44:41 --> Config Class Initialized
INFO - 2024-10-04 09:44:41 --> Loader Class Initialized
INFO - 2024-10-04 09:44:41 --> Helper loaded: url_helper
INFO - 2024-10-04 09:44:41 --> Helper loaded: file_helper
INFO - 2024-10-04 09:44:41 --> Helper loaded: form_helper
INFO - 2024-10-04 09:44:41 --> Helper loaded: my_helper
INFO - 2024-10-04 09:44:41 --> Database Driver Class Initialized
INFO - 2024-10-04 09:44:41 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-04 09:44:41 --> Controller Class Initialized
DEBUG - 2024-10-04 09:44:41 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/home/views/v_home_guru.php
DEBUG - 2024-10-04 09:44:41 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-10-04 09:44:41 --> Final output sent to browser
DEBUG - 2024-10-04 09:44:41 --> Total execution time: 0.0371
INFO - 2024-10-04 10:21:02 --> Config Class Initialized
INFO - 2024-10-04 10:21:02 --> Hooks Class Initialized
DEBUG - 2024-10-04 10:21:02 --> UTF-8 Support Enabled
INFO - 2024-10-04 10:21:02 --> Utf8 Class Initialized
INFO - 2024-10-04 10:21:02 --> URI Class Initialized
INFO - 2024-10-04 10:21:02 --> Router Class Initialized
INFO - 2024-10-04 10:21:02 --> Output Class Initialized
INFO - 2024-10-04 10:21:02 --> Security Class Initialized
DEBUG - 2024-10-04 10:21:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-04 10:21:02 --> Input Class Initialized
INFO - 2024-10-04 10:21:02 --> Language Class Initialized
INFO - 2024-10-04 10:21:02 --> Language Class Initialized
INFO - 2024-10-04 10:21:02 --> Config Class Initialized
INFO - 2024-10-04 10:21:02 --> Loader Class Initialized
INFO - 2024-10-04 10:21:02 --> Helper loaded: url_helper
INFO - 2024-10-04 10:21:02 --> Helper loaded: file_helper
INFO - 2024-10-04 10:21:02 --> Helper loaded: form_helper
INFO - 2024-10-04 10:21:02 --> Helper loaded: my_helper
INFO - 2024-10-04 10:21:02 --> Database Driver Class Initialized
INFO - 2024-10-04 10:21:02 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-04 10:21:02 --> Controller Class Initialized
DEBUG - 2024-10-04 10:21:02 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/home/views/v_home_guru.php
DEBUG - 2024-10-04 10:21:02 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-10-04 10:21:02 --> Final output sent to browser
DEBUG - 2024-10-04 10:21:02 --> Total execution time: 0.5417
INFO - 2024-10-04 13:54:07 --> Config Class Initialized
INFO - 2024-10-04 13:54:07 --> Hooks Class Initialized
DEBUG - 2024-10-04 13:54:07 --> UTF-8 Support Enabled
INFO - 2024-10-04 13:54:07 --> Utf8 Class Initialized
INFO - 2024-10-04 13:54:07 --> URI Class Initialized
INFO - 2024-10-04 13:54:07 --> Router Class Initialized
INFO - 2024-10-04 13:54:07 --> Output Class Initialized
INFO - 2024-10-04 13:54:07 --> Security Class Initialized
DEBUG - 2024-10-04 13:54:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-04 13:54:07 --> Input Class Initialized
INFO - 2024-10-04 13:54:07 --> Language Class Initialized
INFO - 2024-10-04 13:54:07 --> Language Class Initialized
INFO - 2024-10-04 13:54:07 --> Config Class Initialized
INFO - 2024-10-04 13:54:07 --> Loader Class Initialized
INFO - 2024-10-04 13:54:07 --> Helper loaded: url_helper
INFO - 2024-10-04 13:54:07 --> Helper loaded: file_helper
INFO - 2024-10-04 13:54:07 --> Helper loaded: form_helper
INFO - 2024-10-04 13:54:07 --> Helper loaded: my_helper
INFO - 2024-10-04 13:54:07 --> Database Driver Class Initialized
INFO - 2024-10-04 13:54:07 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-04 13:54:07 --> Controller Class Initialized
INFO - 2024-10-04 13:54:07 --> Helper loaded: cookie_helper
INFO - 2024-10-04 13:54:07 --> Final output sent to browser
DEBUG - 2024-10-04 13:54:07 --> Total execution time: 0.0593
INFO - 2024-10-04 13:54:08 --> Config Class Initialized
INFO - 2024-10-04 13:54:08 --> Hooks Class Initialized
DEBUG - 2024-10-04 13:54:08 --> UTF-8 Support Enabled
INFO - 2024-10-04 13:54:08 --> Utf8 Class Initialized
INFO - 2024-10-04 13:54:08 --> URI Class Initialized
INFO - 2024-10-04 13:54:08 --> Router Class Initialized
INFO - 2024-10-04 13:54:08 --> Output Class Initialized
INFO - 2024-10-04 13:54:08 --> Security Class Initialized
DEBUG - 2024-10-04 13:54:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-04 13:54:08 --> Input Class Initialized
INFO - 2024-10-04 13:54:08 --> Language Class Initialized
INFO - 2024-10-04 13:54:08 --> Language Class Initialized
INFO - 2024-10-04 13:54:08 --> Config Class Initialized
INFO - 2024-10-04 13:54:08 --> Loader Class Initialized
INFO - 2024-10-04 13:54:08 --> Helper loaded: url_helper
INFO - 2024-10-04 13:54:08 --> Helper loaded: file_helper
INFO - 2024-10-04 13:54:08 --> Helper loaded: form_helper
INFO - 2024-10-04 13:54:08 --> Helper loaded: my_helper
INFO - 2024-10-04 13:54:08 --> Database Driver Class Initialized
INFO - 2024-10-04 13:54:08 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-04 13:54:08 --> Controller Class Initialized
INFO - 2024-10-04 13:54:08 --> Helper loaded: cookie_helper
INFO - 2024-10-04 13:54:08 --> Config Class Initialized
INFO - 2024-10-04 13:54:08 --> Hooks Class Initialized
DEBUG - 2024-10-04 13:54:08 --> UTF-8 Support Enabled
INFO - 2024-10-04 13:54:08 --> Utf8 Class Initialized
INFO - 2024-10-04 13:54:08 --> URI Class Initialized
INFO - 2024-10-04 13:54:08 --> Router Class Initialized
INFO - 2024-10-04 13:54:08 --> Output Class Initialized
INFO - 2024-10-04 13:54:08 --> Security Class Initialized
DEBUG - 2024-10-04 13:54:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-04 13:54:08 --> Input Class Initialized
INFO - 2024-10-04 13:54:08 --> Language Class Initialized
INFO - 2024-10-04 13:54:08 --> Language Class Initialized
INFO - 2024-10-04 13:54:08 --> Config Class Initialized
INFO - 2024-10-04 13:54:08 --> Loader Class Initialized
INFO - 2024-10-04 13:54:08 --> Helper loaded: url_helper
INFO - 2024-10-04 13:54:08 --> Helper loaded: file_helper
INFO - 2024-10-04 13:54:08 --> Helper loaded: form_helper
INFO - 2024-10-04 13:54:08 --> Helper loaded: my_helper
INFO - 2024-10-04 13:54:08 --> Database Driver Class Initialized
INFO - 2024-10-04 13:54:08 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-04 13:54:08 --> Controller Class Initialized
DEBUG - 2024-10-04 13:54:08 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/lihat_raport/views/list.php
DEBUG - 2024-10-04 13:54:08 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-10-04 13:54:08 --> Final output sent to browser
DEBUG - 2024-10-04 13:54:08 --> Total execution time: 0.0371
INFO - 2024-10-04 13:54:24 --> Config Class Initialized
INFO - 2024-10-04 13:54:24 --> Hooks Class Initialized
DEBUG - 2024-10-04 13:54:24 --> UTF-8 Support Enabled
INFO - 2024-10-04 13:54:24 --> Utf8 Class Initialized
INFO - 2024-10-04 13:54:24 --> URI Class Initialized
INFO - 2024-10-04 13:54:24 --> Router Class Initialized
INFO - 2024-10-04 13:54:24 --> Output Class Initialized
INFO - 2024-10-04 13:54:24 --> Security Class Initialized
DEBUG - 2024-10-04 13:54:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-04 13:54:24 --> Input Class Initialized
INFO - 2024-10-04 13:54:24 --> Language Class Initialized
INFO - 2024-10-04 13:54:24 --> Language Class Initialized
INFO - 2024-10-04 13:54:24 --> Config Class Initialized
INFO - 2024-10-04 13:54:24 --> Loader Class Initialized
INFO - 2024-10-04 13:54:24 --> Helper loaded: url_helper
INFO - 2024-10-04 13:54:24 --> Helper loaded: file_helper
INFO - 2024-10-04 13:54:24 --> Helper loaded: form_helper
INFO - 2024-10-04 13:54:24 --> Helper loaded: my_helper
INFO - 2024-10-04 13:54:24 --> Database Driver Class Initialized
INFO - 2024-10-04 13:54:24 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-04 13:54:24 --> Controller Class Initialized
DEBUG - 2024-10-04 13:54:24 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php
INFO - 2024-10-04 13:54:31 --> Final output sent to browser
DEBUG - 2024-10-04 13:54:31 --> Total execution time: 6.8560
INFO - 2024-10-04 13:57:29 --> Config Class Initialized
INFO - 2024-10-04 13:57:29 --> Hooks Class Initialized
DEBUG - 2024-10-04 13:57:29 --> UTF-8 Support Enabled
INFO - 2024-10-04 13:57:29 --> Utf8 Class Initialized
INFO - 2024-10-04 13:57:29 --> URI Class Initialized
INFO - 2024-10-04 13:57:29 --> Router Class Initialized
INFO - 2024-10-04 13:57:29 --> Output Class Initialized
INFO - 2024-10-04 13:57:29 --> Security Class Initialized
DEBUG - 2024-10-04 13:57:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-04 13:57:29 --> Input Class Initialized
INFO - 2024-10-04 13:57:29 --> Language Class Initialized
INFO - 2024-10-04 13:57:29 --> Language Class Initialized
INFO - 2024-10-04 13:57:29 --> Config Class Initialized
INFO - 2024-10-04 13:57:29 --> Loader Class Initialized
INFO - 2024-10-04 13:57:29 --> Helper loaded: url_helper
INFO - 2024-10-04 13:57:29 --> Helper loaded: file_helper
INFO - 2024-10-04 13:57:29 --> Helper loaded: form_helper
INFO - 2024-10-04 13:57:29 --> Helper loaded: my_helper
INFO - 2024-10-04 13:57:29 --> Database Driver Class Initialized
INFO - 2024-10-04 13:57:29 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-04 13:57:29 --> Controller Class Initialized
DEBUG - 2024-10-04 13:57:29 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php
INFO - 2024-10-04 13:57:37 --> Final output sent to browser
DEBUG - 2024-10-04 13:57:37 --> Total execution time: 7.8549
INFO - 2024-10-04 14:44:27 --> Config Class Initialized
INFO - 2024-10-04 14:44:27 --> Hooks Class Initialized
DEBUG - 2024-10-04 14:44:27 --> UTF-8 Support Enabled
INFO - 2024-10-04 14:44:27 --> Utf8 Class Initialized
INFO - 2024-10-04 14:44:27 --> URI Class Initialized
INFO - 2024-10-04 14:44:27 --> Router Class Initialized
INFO - 2024-10-04 14:44:27 --> Output Class Initialized
INFO - 2024-10-04 14:44:27 --> Security Class Initialized
DEBUG - 2024-10-04 14:44:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-04 14:44:27 --> Input Class Initialized
INFO - 2024-10-04 14:44:27 --> Language Class Initialized
INFO - 2024-10-04 14:44:27 --> Language Class Initialized
INFO - 2024-10-04 14:44:27 --> Config Class Initialized
INFO - 2024-10-04 14:44:27 --> Loader Class Initialized
INFO - 2024-10-04 14:44:27 --> Helper loaded: url_helper
INFO - 2024-10-04 14:44:27 --> Helper loaded: file_helper
INFO - 2024-10-04 14:44:27 --> Helper loaded: form_helper
INFO - 2024-10-04 14:44:27 --> Helper loaded: my_helper
INFO - 2024-10-04 14:44:27 --> Database Driver Class Initialized
INFO - 2024-10-04 14:44:27 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-04 14:44:27 --> Controller Class Initialized
DEBUG - 2024-10-04 14:44:27 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/login/views/login.php
DEBUG - 2024-10-04 14:44:27 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-10-04 14:44:27 --> Final output sent to browser
DEBUG - 2024-10-04 14:44:27 --> Total execution time: 0.0470
INFO - 2024-10-04 14:44:36 --> Config Class Initialized
INFO - 2024-10-04 14:44:36 --> Hooks Class Initialized
DEBUG - 2024-10-04 14:44:36 --> UTF-8 Support Enabled
INFO - 2024-10-04 14:44:36 --> Utf8 Class Initialized
INFO - 2024-10-04 14:44:36 --> URI Class Initialized
INFO - 2024-10-04 14:44:36 --> Router Class Initialized
INFO - 2024-10-04 14:44:36 --> Output Class Initialized
INFO - 2024-10-04 14:44:36 --> Security Class Initialized
DEBUG - 2024-10-04 14:44:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-04 14:44:36 --> Input Class Initialized
INFO - 2024-10-04 14:44:36 --> Language Class Initialized
INFO - 2024-10-04 14:44:36 --> Language Class Initialized
INFO - 2024-10-04 14:44:36 --> Config Class Initialized
INFO - 2024-10-04 14:44:36 --> Loader Class Initialized
INFO - 2024-10-04 14:44:36 --> Helper loaded: url_helper
INFO - 2024-10-04 14:44:36 --> Helper loaded: file_helper
INFO - 2024-10-04 14:44:36 --> Helper loaded: form_helper
INFO - 2024-10-04 14:44:36 --> Helper loaded: my_helper
INFO - 2024-10-04 14:44:36 --> Database Driver Class Initialized
INFO - 2024-10-04 14:44:36 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-04 14:44:36 --> Controller Class Initialized
DEBUG - 2024-10-04 14:44:36 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/login/views/login.php
DEBUG - 2024-10-04 14:44:36 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-10-04 14:44:36 --> Final output sent to browser
DEBUG - 2024-10-04 14:44:36 --> Total execution time: 0.0264
INFO - 2024-10-04 15:05:07 --> Config Class Initialized
INFO - 2024-10-04 15:05:07 --> Hooks Class Initialized
DEBUG - 2024-10-04 15:05:07 --> UTF-8 Support Enabled
INFO - 2024-10-04 15:05:07 --> Utf8 Class Initialized
INFO - 2024-10-04 15:05:07 --> URI Class Initialized
INFO - 2024-10-04 15:05:07 --> Router Class Initialized
INFO - 2024-10-04 15:05:07 --> Output Class Initialized
INFO - 2024-10-04 15:05:07 --> Security Class Initialized
DEBUG - 2024-10-04 15:05:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-04 15:05:07 --> Input Class Initialized
INFO - 2024-10-04 15:05:07 --> Language Class Initialized
INFO - 2024-10-04 15:05:07 --> Language Class Initialized
INFO - 2024-10-04 15:05:07 --> Config Class Initialized
INFO - 2024-10-04 15:05:07 --> Loader Class Initialized
INFO - 2024-10-04 15:05:07 --> Helper loaded: url_helper
INFO - 2024-10-04 15:05:07 --> Helper loaded: file_helper
INFO - 2024-10-04 15:05:07 --> Helper loaded: form_helper
INFO - 2024-10-04 15:05:07 --> Helper loaded: my_helper
INFO - 2024-10-04 15:05:07 --> Database Driver Class Initialized
INFO - 2024-10-04 15:05:07 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-04 15:05:07 --> Controller Class Initialized
INFO - 2024-10-04 15:05:07 --> Config Class Initialized
INFO - 2024-10-04 15:05:07 --> Hooks Class Initialized
DEBUG - 2024-10-04 15:05:07 --> UTF-8 Support Enabled
INFO - 2024-10-04 15:05:07 --> Utf8 Class Initialized
INFO - 2024-10-04 15:05:07 --> URI Class Initialized
INFO - 2024-10-04 15:05:07 --> Router Class Initialized
INFO - 2024-10-04 15:05:07 --> Output Class Initialized
INFO - 2024-10-04 15:05:07 --> Security Class Initialized
DEBUG - 2024-10-04 15:05:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-04 15:05:07 --> Input Class Initialized
INFO - 2024-10-04 15:05:07 --> Language Class Initialized
INFO - 2024-10-04 15:05:07 --> Language Class Initialized
INFO - 2024-10-04 15:05:07 --> Config Class Initialized
INFO - 2024-10-04 15:05:07 --> Loader Class Initialized
INFO - 2024-10-04 15:05:07 --> Helper loaded: url_helper
INFO - 2024-10-04 15:05:07 --> Helper loaded: file_helper
INFO - 2024-10-04 15:05:07 --> Helper loaded: form_helper
INFO - 2024-10-04 15:05:07 --> Helper loaded: my_helper
INFO - 2024-10-04 15:05:07 --> Database Driver Class Initialized
INFO - 2024-10-04 15:05:07 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-04 15:05:07 --> Controller Class Initialized
DEBUG - 2024-10-04 15:05:07 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/login/views/login.php
DEBUG - 2024-10-04 15:05:07 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-10-04 15:05:07 --> Final output sent to browser
DEBUG - 2024-10-04 15:05:07 --> Total execution time: 0.0612
INFO - 2024-10-04 15:05:10 --> Config Class Initialized
INFO - 2024-10-04 15:05:10 --> Hooks Class Initialized
DEBUG - 2024-10-04 15:05:10 --> UTF-8 Support Enabled
INFO - 2024-10-04 15:05:10 --> Utf8 Class Initialized
INFO - 2024-10-04 15:05:10 --> URI Class Initialized
INFO - 2024-10-04 15:05:10 --> Router Class Initialized
INFO - 2024-10-04 15:05:10 --> Output Class Initialized
INFO - 2024-10-04 15:05:10 --> Security Class Initialized
DEBUG - 2024-10-04 15:05:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-04 15:05:10 --> Input Class Initialized
INFO - 2024-10-04 15:05:10 --> Language Class Initialized
INFO - 2024-10-04 15:05:10 --> Language Class Initialized
INFO - 2024-10-04 15:05:10 --> Config Class Initialized
INFO - 2024-10-04 15:05:10 --> Loader Class Initialized
INFO - 2024-10-04 15:05:10 --> Helper loaded: url_helper
INFO - 2024-10-04 15:05:10 --> Helper loaded: file_helper
INFO - 2024-10-04 15:05:10 --> Helper loaded: form_helper
INFO - 2024-10-04 15:05:10 --> Helper loaded: my_helper
INFO - 2024-10-04 15:05:10 --> Database Driver Class Initialized
INFO - 2024-10-04 15:05:10 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-04 15:05:10 --> Controller Class Initialized
INFO - 2024-10-04 15:05:10 --> Helper loaded: cookie_helper
INFO - 2024-10-04 15:05:10 --> Final output sent to browser
DEBUG - 2024-10-04 15:05:10 --> Total execution time: 0.0826
INFO - 2024-10-04 15:05:10 --> Config Class Initialized
INFO - 2024-10-04 15:05:10 --> Hooks Class Initialized
DEBUG - 2024-10-04 15:05:10 --> UTF-8 Support Enabled
INFO - 2024-10-04 15:05:10 --> Utf8 Class Initialized
INFO - 2024-10-04 15:05:10 --> URI Class Initialized
INFO - 2024-10-04 15:05:10 --> Router Class Initialized
INFO - 2024-10-04 15:05:10 --> Output Class Initialized
INFO - 2024-10-04 15:05:10 --> Security Class Initialized
DEBUG - 2024-10-04 15:05:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-04 15:05:10 --> Input Class Initialized
INFO - 2024-10-04 15:05:10 --> Language Class Initialized
INFO - 2024-10-04 15:05:10 --> Language Class Initialized
INFO - 2024-10-04 15:05:10 --> Config Class Initialized
INFO - 2024-10-04 15:05:10 --> Loader Class Initialized
INFO - 2024-10-04 15:05:10 --> Helper loaded: url_helper
INFO - 2024-10-04 15:05:10 --> Helper loaded: file_helper
INFO - 2024-10-04 15:05:10 --> Helper loaded: form_helper
INFO - 2024-10-04 15:05:10 --> Helper loaded: my_helper
INFO - 2024-10-04 15:05:10 --> Database Driver Class Initialized
INFO - 2024-10-04 15:05:10 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-04 15:05:10 --> Controller Class Initialized
DEBUG - 2024-10-04 15:05:10 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/home/views/v_home_guru.php
DEBUG - 2024-10-04 15:05:10 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-10-04 15:05:10 --> Final output sent to browser
DEBUG - 2024-10-04 15:05:10 --> Total execution time: 0.0443
INFO - 2024-10-04 15:05:13 --> Config Class Initialized
INFO - 2024-10-04 15:05:13 --> Hooks Class Initialized
DEBUG - 2024-10-04 15:05:13 --> UTF-8 Support Enabled
INFO - 2024-10-04 15:05:13 --> Utf8 Class Initialized
INFO - 2024-10-04 15:05:13 --> URI Class Initialized
INFO - 2024-10-04 15:05:13 --> Router Class Initialized
INFO - 2024-10-04 15:05:13 --> Output Class Initialized
INFO - 2024-10-04 15:05:13 --> Security Class Initialized
DEBUG - 2024-10-04 15:05:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-04 15:05:13 --> Input Class Initialized
INFO - 2024-10-04 15:05:13 --> Language Class Initialized
INFO - 2024-10-04 15:05:13 --> Language Class Initialized
INFO - 2024-10-04 15:05:13 --> Config Class Initialized
INFO - 2024-10-04 15:05:13 --> Loader Class Initialized
INFO - 2024-10-04 15:05:13 --> Helper loaded: url_helper
INFO - 2024-10-04 15:05:13 --> Helper loaded: file_helper
INFO - 2024-10-04 15:05:13 --> Helper loaded: form_helper
INFO - 2024-10-04 15:05:13 --> Helper loaded: my_helper
INFO - 2024-10-04 15:05:13 --> Database Driver Class Initialized
INFO - 2024-10-04 15:05:13 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-04 15:05:13 --> Controller Class Initialized
DEBUG - 2024-10-04 15:05:13 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/view_mapel/views/v_view_mapel.php
DEBUG - 2024-10-04 15:05:13 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-10-04 15:05:13 --> Final output sent to browser
DEBUG - 2024-10-04 15:05:13 --> Total execution time: 0.0405
INFO - 2024-10-04 15:05:24 --> Config Class Initialized
INFO - 2024-10-04 15:05:24 --> Hooks Class Initialized
DEBUG - 2024-10-04 15:05:24 --> UTF-8 Support Enabled
INFO - 2024-10-04 15:05:24 --> Utf8 Class Initialized
INFO - 2024-10-04 15:05:24 --> URI Class Initialized
INFO - 2024-10-04 15:05:24 --> Router Class Initialized
INFO - 2024-10-04 15:05:24 --> Output Class Initialized
INFO - 2024-10-04 15:05:24 --> Security Class Initialized
DEBUG - 2024-10-04 15:05:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-04 15:05:24 --> Input Class Initialized
INFO - 2024-10-04 15:05:24 --> Language Class Initialized
INFO - 2024-10-04 15:05:24 --> Language Class Initialized
INFO - 2024-10-04 15:05:24 --> Config Class Initialized
INFO - 2024-10-04 15:05:24 --> Loader Class Initialized
INFO - 2024-10-04 15:05:24 --> Helper loaded: url_helper
INFO - 2024-10-04 15:05:24 --> Helper loaded: file_helper
INFO - 2024-10-04 15:05:24 --> Helper loaded: form_helper
INFO - 2024-10-04 15:05:24 --> Helper loaded: my_helper
INFO - 2024-10-04 15:05:24 --> Database Driver Class Initialized
INFO - 2024-10-04 15:05:24 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-04 15:05:24 --> Controller Class Initialized
DEBUG - 2024-10-04 15:05:24 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/views/list.php
DEBUG - 2024-10-04 15:05:24 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-10-04 15:05:24 --> Final output sent to browser
DEBUG - 2024-10-04 15:05:24 --> Total execution time: 0.0374
INFO - 2024-10-04 15:05:24 --> Config Class Initialized
INFO - 2024-10-04 15:05:24 --> Hooks Class Initialized
DEBUG - 2024-10-04 15:05:24 --> UTF-8 Support Enabled
INFO - 2024-10-04 15:05:24 --> Utf8 Class Initialized
INFO - 2024-10-04 15:05:24 --> URI Class Initialized
INFO - 2024-10-04 15:05:24 --> Router Class Initialized
INFO - 2024-10-04 15:05:24 --> Output Class Initialized
INFO - 2024-10-04 15:05:24 --> Security Class Initialized
DEBUG - 2024-10-04 15:05:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-04 15:05:24 --> Input Class Initialized
INFO - 2024-10-04 15:05:24 --> Language Class Initialized
INFO - 2024-10-04 15:05:24 --> Language Class Initialized
INFO - 2024-10-04 15:05:24 --> Config Class Initialized
INFO - 2024-10-04 15:05:24 --> Loader Class Initialized
INFO - 2024-10-04 15:05:24 --> Helper loaded: url_helper
INFO - 2024-10-04 15:05:24 --> Helper loaded: file_helper
INFO - 2024-10-04 15:05:24 --> Helper loaded: form_helper
INFO - 2024-10-04 15:05:24 --> Helper loaded: my_helper
INFO - 2024-10-04 15:05:24 --> Database Driver Class Initialized
INFO - 2024-10-04 15:05:24 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-04 15:05:24 --> Controller Class Initialized
INFO - 2024-10-04 15:05:30 --> Config Class Initialized
INFO - 2024-10-04 15:05:30 --> Hooks Class Initialized
DEBUG - 2024-10-04 15:05:30 --> UTF-8 Support Enabled
INFO - 2024-10-04 15:05:30 --> Utf8 Class Initialized
INFO - 2024-10-04 15:05:30 --> URI Class Initialized
INFO - 2024-10-04 15:05:30 --> Router Class Initialized
INFO - 2024-10-04 15:05:30 --> Output Class Initialized
INFO - 2024-10-04 15:05:30 --> Security Class Initialized
DEBUG - 2024-10-04 15:05:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-04 15:05:30 --> Input Class Initialized
INFO - 2024-10-04 15:05:30 --> Language Class Initialized
INFO - 2024-10-04 15:05:30 --> Language Class Initialized
INFO - 2024-10-04 15:05:30 --> Config Class Initialized
INFO - 2024-10-04 15:05:30 --> Loader Class Initialized
INFO - 2024-10-04 15:05:30 --> Helper loaded: url_helper
INFO - 2024-10-04 15:05:30 --> Helper loaded: file_helper
INFO - 2024-10-04 15:05:30 --> Helper loaded: form_helper
INFO - 2024-10-04 15:05:30 --> Helper loaded: my_helper
INFO - 2024-10-04 15:05:30 --> Database Driver Class Initialized
INFO - 2024-10-04 15:05:30 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-04 15:05:30 --> Controller Class Initialized
DEBUG - 2024-10-04 15:05:30 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/view_mapel/views/v_view_mapel.php
DEBUG - 2024-10-04 15:05:30 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-10-04 15:05:30 --> Final output sent to browser
DEBUG - 2024-10-04 15:05:30 --> Total execution time: 0.0303
INFO - 2024-10-04 15:05:44 --> Config Class Initialized
INFO - 2024-10-04 15:05:44 --> Hooks Class Initialized
DEBUG - 2024-10-04 15:05:44 --> UTF-8 Support Enabled
INFO - 2024-10-04 15:05:44 --> Utf8 Class Initialized
INFO - 2024-10-04 15:05:44 --> URI Class Initialized
INFO - 2024-10-04 15:05:44 --> Router Class Initialized
INFO - 2024-10-04 15:05:44 --> Output Class Initialized
INFO - 2024-10-04 15:05:44 --> Security Class Initialized
DEBUG - 2024-10-04 15:05:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-04 15:05:44 --> Input Class Initialized
INFO - 2024-10-04 15:05:44 --> Language Class Initialized
INFO - 2024-10-04 15:05:44 --> Language Class Initialized
INFO - 2024-10-04 15:05:44 --> Config Class Initialized
INFO - 2024-10-04 15:05:44 --> Loader Class Initialized
INFO - 2024-10-04 15:05:44 --> Helper loaded: url_helper
INFO - 2024-10-04 15:05:44 --> Helper loaded: file_helper
INFO - 2024-10-04 15:05:44 --> Helper loaded: form_helper
INFO - 2024-10-04 15:05:44 --> Helper loaded: my_helper
INFO - 2024-10-04 15:05:44 --> Database Driver Class Initialized
INFO - 2024-10-04 15:05:44 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-04 15:05:44 --> Controller Class Initialized
DEBUG - 2024-10-04 15:05:44 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/views/list.php
DEBUG - 2024-10-04 15:05:44 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-10-04 15:05:44 --> Final output sent to browser
DEBUG - 2024-10-04 15:05:44 --> Total execution time: 0.0473
INFO - 2024-10-04 15:05:44 --> Config Class Initialized
INFO - 2024-10-04 15:05:44 --> Hooks Class Initialized
DEBUG - 2024-10-04 15:05:44 --> UTF-8 Support Enabled
INFO - 2024-10-04 15:05:44 --> Utf8 Class Initialized
INFO - 2024-10-04 15:05:44 --> URI Class Initialized
INFO - 2024-10-04 15:05:44 --> Router Class Initialized
INFO - 2024-10-04 15:05:44 --> Output Class Initialized
INFO - 2024-10-04 15:05:44 --> Security Class Initialized
DEBUG - 2024-10-04 15:05:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-04 15:05:44 --> Input Class Initialized
INFO - 2024-10-04 15:05:44 --> Language Class Initialized
INFO - 2024-10-04 15:05:44 --> Language Class Initialized
INFO - 2024-10-04 15:05:44 --> Config Class Initialized
INFO - 2024-10-04 15:05:44 --> Loader Class Initialized
INFO - 2024-10-04 15:05:44 --> Helper loaded: url_helper
INFO - 2024-10-04 15:05:44 --> Helper loaded: file_helper
INFO - 2024-10-04 15:05:44 --> Helper loaded: form_helper
INFO - 2024-10-04 15:05:44 --> Helper loaded: my_helper
INFO - 2024-10-04 15:05:44 --> Database Driver Class Initialized
INFO - 2024-10-04 15:05:44 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-04 15:05:44 --> Controller Class Initialized
INFO - 2024-10-04 15:06:16 --> Config Class Initialized
INFO - 2024-10-04 15:06:16 --> Hooks Class Initialized
DEBUG - 2024-10-04 15:06:16 --> UTF-8 Support Enabled
INFO - 2024-10-04 15:06:16 --> Utf8 Class Initialized
INFO - 2024-10-04 15:06:16 --> URI Class Initialized
INFO - 2024-10-04 15:06:16 --> Router Class Initialized
INFO - 2024-10-04 15:06:16 --> Output Class Initialized
INFO - 2024-10-04 15:06:16 --> Security Class Initialized
DEBUG - 2024-10-04 15:06:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-04 15:06:16 --> Input Class Initialized
INFO - 2024-10-04 15:06:16 --> Language Class Initialized
INFO - 2024-10-04 15:06:16 --> Language Class Initialized
INFO - 2024-10-04 15:06:16 --> Config Class Initialized
INFO - 2024-10-04 15:06:16 --> Loader Class Initialized
INFO - 2024-10-04 15:06:16 --> Helper loaded: url_helper
INFO - 2024-10-04 15:06:16 --> Helper loaded: file_helper
INFO - 2024-10-04 15:06:16 --> Helper loaded: form_helper
INFO - 2024-10-04 15:06:16 --> Helper loaded: my_helper
INFO - 2024-10-04 15:06:16 --> Database Driver Class Initialized
INFO - 2024-10-04 15:06:16 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-04 15:06:16 --> Controller Class Initialized
INFO - 2024-10-04 15:06:16 --> Final output sent to browser
DEBUG - 2024-10-04 15:06:16 --> Total execution time: 0.0423
INFO - 2024-10-04 15:06:19 --> Config Class Initialized
INFO - 2024-10-04 15:06:19 --> Hooks Class Initialized
DEBUG - 2024-10-04 15:06:19 --> UTF-8 Support Enabled
INFO - 2024-10-04 15:06:19 --> Utf8 Class Initialized
INFO - 2024-10-04 15:06:19 --> URI Class Initialized
INFO - 2024-10-04 15:06:19 --> Router Class Initialized
INFO - 2024-10-04 15:06:19 --> Output Class Initialized
INFO - 2024-10-04 15:06:19 --> Security Class Initialized
DEBUG - 2024-10-04 15:06:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-04 15:06:19 --> Input Class Initialized
INFO - 2024-10-04 15:06:19 --> Language Class Initialized
INFO - 2024-10-04 15:06:19 --> Language Class Initialized
INFO - 2024-10-04 15:06:19 --> Config Class Initialized
INFO - 2024-10-04 15:06:19 --> Loader Class Initialized
INFO - 2024-10-04 15:06:19 --> Helper loaded: url_helper
INFO - 2024-10-04 15:06:19 --> Helper loaded: file_helper
INFO - 2024-10-04 15:06:19 --> Helper loaded: form_helper
INFO - 2024-10-04 15:06:19 --> Helper loaded: my_helper
INFO - 2024-10-04 15:06:19 --> Database Driver Class Initialized
INFO - 2024-10-04 15:06:19 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-04 15:06:19 --> Controller Class Initialized
INFO - 2024-10-04 15:06:19 --> Final output sent to browser
DEBUG - 2024-10-04 15:06:19 --> Total execution time: 0.0425
INFO - 2024-10-04 15:06:23 --> Config Class Initialized
INFO - 2024-10-04 15:06:23 --> Hooks Class Initialized
DEBUG - 2024-10-04 15:06:23 --> UTF-8 Support Enabled
INFO - 2024-10-04 15:06:23 --> Utf8 Class Initialized
INFO - 2024-10-04 15:06:23 --> URI Class Initialized
INFO - 2024-10-04 15:06:23 --> Router Class Initialized
INFO - 2024-10-04 15:06:23 --> Output Class Initialized
INFO - 2024-10-04 15:06:23 --> Security Class Initialized
DEBUG - 2024-10-04 15:06:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-04 15:06:23 --> Input Class Initialized
INFO - 2024-10-04 15:06:23 --> Language Class Initialized
INFO - 2024-10-04 15:06:23 --> Language Class Initialized
INFO - 2024-10-04 15:06:23 --> Config Class Initialized
INFO - 2024-10-04 15:06:23 --> Loader Class Initialized
INFO - 2024-10-04 15:06:23 --> Helper loaded: url_helper
INFO - 2024-10-04 15:06:23 --> Helper loaded: file_helper
INFO - 2024-10-04 15:06:23 --> Helper loaded: form_helper
INFO - 2024-10-04 15:06:23 --> Helper loaded: my_helper
INFO - 2024-10-04 15:06:23 --> Database Driver Class Initialized
INFO - 2024-10-04 15:06:23 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-04 15:06:23 --> Controller Class Initialized
DEBUG - 2024-10-04 15:06:23 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/views/form.php
DEBUG - 2024-10-04 15:06:23 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-10-04 15:06:23 --> Final output sent to browser
DEBUG - 2024-10-04 15:06:23 --> Total execution time: 0.0333
INFO - 2024-10-04 15:06:24 --> Config Class Initialized
INFO - 2024-10-04 15:06:24 --> Hooks Class Initialized
DEBUG - 2024-10-04 15:06:24 --> UTF-8 Support Enabled
INFO - 2024-10-04 15:06:24 --> Utf8 Class Initialized
INFO - 2024-10-04 15:06:24 --> URI Class Initialized
INFO - 2024-10-04 15:06:24 --> Router Class Initialized
INFO - 2024-10-04 15:06:24 --> Output Class Initialized
INFO - 2024-10-04 15:06:24 --> Security Class Initialized
DEBUG - 2024-10-04 15:06:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-04 15:06:24 --> Input Class Initialized
INFO - 2024-10-04 15:06:24 --> Language Class Initialized
INFO - 2024-10-04 15:06:24 --> Language Class Initialized
INFO - 2024-10-04 15:06:24 --> Config Class Initialized
INFO - 2024-10-04 15:06:24 --> Loader Class Initialized
INFO - 2024-10-04 15:06:24 --> Helper loaded: url_helper
INFO - 2024-10-04 15:06:24 --> Helper loaded: file_helper
INFO - 2024-10-04 15:06:24 --> Helper loaded: form_helper
INFO - 2024-10-04 15:06:24 --> Helper loaded: my_helper
INFO - 2024-10-04 15:06:24 --> Database Driver Class Initialized
INFO - 2024-10-04 15:06:24 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-04 15:06:24 --> Controller Class Initialized
DEBUG - 2024-10-04 15:06:24 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/views/list.php
DEBUG - 2024-10-04 15:06:24 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-10-04 15:06:24 --> Final output sent to browser
DEBUG - 2024-10-04 15:06:24 --> Total execution time: 0.0329
INFO - 2024-10-04 15:06:24 --> Config Class Initialized
INFO - 2024-10-04 15:06:24 --> Hooks Class Initialized
DEBUG - 2024-10-04 15:06:24 --> UTF-8 Support Enabled
INFO - 2024-10-04 15:06:24 --> Utf8 Class Initialized
INFO - 2024-10-04 15:06:24 --> URI Class Initialized
INFO - 2024-10-04 15:06:24 --> Router Class Initialized
INFO - 2024-10-04 15:06:24 --> Output Class Initialized
INFO - 2024-10-04 15:06:24 --> Security Class Initialized
DEBUG - 2024-10-04 15:06:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-04 15:06:24 --> Input Class Initialized
INFO - 2024-10-04 15:06:24 --> Language Class Initialized
INFO - 2024-10-04 15:06:24 --> Language Class Initialized
INFO - 2024-10-04 15:06:24 --> Config Class Initialized
INFO - 2024-10-04 15:06:24 --> Loader Class Initialized
INFO - 2024-10-04 15:06:24 --> Helper loaded: url_helper
INFO - 2024-10-04 15:06:24 --> Helper loaded: file_helper
INFO - 2024-10-04 15:06:24 --> Helper loaded: form_helper
INFO - 2024-10-04 15:06:24 --> Helper loaded: my_helper
INFO - 2024-10-04 15:06:24 --> Database Driver Class Initialized
INFO - 2024-10-04 15:06:24 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-04 15:06:24 --> Controller Class Initialized
INFO - 2024-10-04 15:06:25 --> Config Class Initialized
INFO - 2024-10-04 15:06:25 --> Hooks Class Initialized
DEBUG - 2024-10-04 15:06:25 --> UTF-8 Support Enabled
INFO - 2024-10-04 15:06:25 --> Utf8 Class Initialized
INFO - 2024-10-04 15:06:25 --> URI Class Initialized
INFO - 2024-10-04 15:06:25 --> Router Class Initialized
INFO - 2024-10-04 15:06:25 --> Output Class Initialized
INFO - 2024-10-04 15:06:25 --> Security Class Initialized
DEBUG - 2024-10-04 15:06:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-04 15:06:25 --> Input Class Initialized
INFO - 2024-10-04 15:06:25 --> Language Class Initialized
INFO - 2024-10-04 15:06:25 --> Language Class Initialized
INFO - 2024-10-04 15:06:25 --> Config Class Initialized
INFO - 2024-10-04 15:06:25 --> Loader Class Initialized
INFO - 2024-10-04 15:06:25 --> Helper loaded: url_helper
INFO - 2024-10-04 15:06:25 --> Helper loaded: file_helper
INFO - 2024-10-04 15:06:25 --> Helper loaded: form_helper
INFO - 2024-10-04 15:06:25 --> Helper loaded: my_helper
INFO - 2024-10-04 15:06:25 --> Database Driver Class Initialized
INFO - 2024-10-04 15:06:25 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-04 15:06:25 --> Controller Class Initialized
INFO - 2024-10-04 15:06:27 --> Config Class Initialized
INFO - 2024-10-04 15:06:27 --> Hooks Class Initialized
DEBUG - 2024-10-04 15:06:27 --> UTF-8 Support Enabled
INFO - 2024-10-04 15:06:27 --> Utf8 Class Initialized
INFO - 2024-10-04 15:06:27 --> URI Class Initialized
INFO - 2024-10-04 15:06:27 --> Router Class Initialized
INFO - 2024-10-04 15:06:27 --> Output Class Initialized
INFO - 2024-10-04 15:06:27 --> Security Class Initialized
DEBUG - 2024-10-04 15:06:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-04 15:06:27 --> Input Class Initialized
INFO - 2024-10-04 15:06:27 --> Language Class Initialized
INFO - 2024-10-04 15:06:27 --> Language Class Initialized
INFO - 2024-10-04 15:06:27 --> Config Class Initialized
INFO - 2024-10-04 15:06:27 --> Loader Class Initialized
INFO - 2024-10-04 15:06:27 --> Helper loaded: url_helper
INFO - 2024-10-04 15:06:27 --> Helper loaded: file_helper
INFO - 2024-10-04 15:06:27 --> Helper loaded: form_helper
INFO - 2024-10-04 15:06:27 --> Helper loaded: my_helper
INFO - 2024-10-04 15:06:27 --> Database Driver Class Initialized
INFO - 2024-10-04 15:06:27 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-04 15:06:27 --> Controller Class Initialized
DEBUG - 2024-10-04 15:06:27 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/views/list.php
DEBUG - 2024-10-04 15:06:27 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-10-04 15:06:27 --> Final output sent to browser
DEBUG - 2024-10-04 15:06:27 --> Total execution time: 0.0543
INFO - 2024-10-04 15:06:27 --> Config Class Initialized
INFO - 2024-10-04 15:06:27 --> Hooks Class Initialized
DEBUG - 2024-10-04 15:06:27 --> UTF-8 Support Enabled
INFO - 2024-10-04 15:06:27 --> Utf8 Class Initialized
INFO - 2024-10-04 15:06:27 --> URI Class Initialized
INFO - 2024-10-04 15:06:27 --> Router Class Initialized
INFO - 2024-10-04 15:06:27 --> Output Class Initialized
INFO - 2024-10-04 15:06:27 --> Security Class Initialized
DEBUG - 2024-10-04 15:06:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-04 15:06:27 --> Input Class Initialized
INFO - 2024-10-04 15:06:27 --> Language Class Initialized
INFO - 2024-10-04 15:06:27 --> Language Class Initialized
INFO - 2024-10-04 15:06:27 --> Config Class Initialized
INFO - 2024-10-04 15:06:27 --> Loader Class Initialized
INFO - 2024-10-04 15:06:27 --> Helper loaded: url_helper
INFO - 2024-10-04 15:06:27 --> Helper loaded: file_helper
INFO - 2024-10-04 15:06:27 --> Helper loaded: form_helper
INFO - 2024-10-04 15:06:27 --> Helper loaded: my_helper
INFO - 2024-10-04 15:06:27 --> Database Driver Class Initialized
INFO - 2024-10-04 15:06:27 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-04 15:06:27 --> Controller Class Initialized
INFO - 2024-10-04 15:06:33 --> Config Class Initialized
INFO - 2024-10-04 15:06:33 --> Hooks Class Initialized
DEBUG - 2024-10-04 15:06:33 --> UTF-8 Support Enabled
INFO - 2024-10-04 15:06:33 --> Utf8 Class Initialized
INFO - 2024-10-04 15:06:33 --> URI Class Initialized
INFO - 2024-10-04 15:06:33 --> Router Class Initialized
INFO - 2024-10-04 15:06:33 --> Output Class Initialized
INFO - 2024-10-04 15:06:33 --> Security Class Initialized
DEBUG - 2024-10-04 15:06:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-04 15:06:33 --> Input Class Initialized
INFO - 2024-10-04 15:06:33 --> Language Class Initialized
INFO - 2024-10-04 15:06:33 --> Language Class Initialized
INFO - 2024-10-04 15:06:33 --> Config Class Initialized
INFO - 2024-10-04 15:06:33 --> Loader Class Initialized
INFO - 2024-10-04 15:06:33 --> Helper loaded: url_helper
INFO - 2024-10-04 15:06:33 --> Helper loaded: file_helper
INFO - 2024-10-04 15:06:33 --> Helper loaded: form_helper
INFO - 2024-10-04 15:06:33 --> Helper loaded: my_helper
INFO - 2024-10-04 15:06:33 --> Database Driver Class Initialized
INFO - 2024-10-04 15:06:33 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-04 15:06:33 --> Controller Class Initialized
INFO - 2024-10-04 15:06:33 --> Final output sent to browser
DEBUG - 2024-10-04 15:06:33 --> Total execution time: 0.0337
INFO - 2024-10-04 15:06:46 --> Config Class Initialized
INFO - 2024-10-04 15:06:46 --> Hooks Class Initialized
DEBUG - 2024-10-04 15:06:46 --> UTF-8 Support Enabled
INFO - 2024-10-04 15:06:46 --> Utf8 Class Initialized
INFO - 2024-10-04 15:06:46 --> URI Class Initialized
INFO - 2024-10-04 15:06:46 --> Router Class Initialized
INFO - 2024-10-04 15:06:46 --> Output Class Initialized
INFO - 2024-10-04 15:06:46 --> Security Class Initialized
DEBUG - 2024-10-04 15:06:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-04 15:06:46 --> Input Class Initialized
INFO - 2024-10-04 15:06:46 --> Language Class Initialized
INFO - 2024-10-04 15:06:46 --> Language Class Initialized
INFO - 2024-10-04 15:06:46 --> Config Class Initialized
INFO - 2024-10-04 15:06:46 --> Loader Class Initialized
INFO - 2024-10-04 15:06:46 --> Helper loaded: url_helper
INFO - 2024-10-04 15:06:46 --> Helper loaded: file_helper
INFO - 2024-10-04 15:06:46 --> Helper loaded: form_helper
INFO - 2024-10-04 15:06:46 --> Helper loaded: my_helper
INFO - 2024-10-04 15:06:46 --> Database Driver Class Initialized
INFO - 2024-10-04 15:06:46 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-04 15:06:46 --> Controller Class Initialized
DEBUG - 2024-10-04 15:06:46 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/view_mapel/views/v_view_mapel.php
DEBUG - 2024-10-04 15:06:46 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-10-04 15:06:46 --> Final output sent to browser
DEBUG - 2024-10-04 15:06:46 --> Total execution time: 0.0532
INFO - 2024-10-04 15:07:34 --> Config Class Initialized
INFO - 2024-10-04 15:07:34 --> Hooks Class Initialized
DEBUG - 2024-10-04 15:07:34 --> UTF-8 Support Enabled
INFO - 2024-10-04 15:07:34 --> Utf8 Class Initialized
INFO - 2024-10-04 15:07:34 --> URI Class Initialized
INFO - 2024-10-04 15:07:34 --> Router Class Initialized
INFO - 2024-10-04 15:07:34 --> Output Class Initialized
INFO - 2024-10-04 15:07:34 --> Security Class Initialized
DEBUG - 2024-10-04 15:07:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-04 15:07:34 --> Input Class Initialized
INFO - 2024-10-04 15:07:34 --> Language Class Initialized
INFO - 2024-10-04 15:07:34 --> Language Class Initialized
INFO - 2024-10-04 15:07:34 --> Config Class Initialized
INFO - 2024-10-04 15:07:34 --> Loader Class Initialized
INFO - 2024-10-04 15:07:34 --> Helper loaded: url_helper
INFO - 2024-10-04 15:07:34 --> Helper loaded: file_helper
INFO - 2024-10-04 15:07:34 --> Helper loaded: form_helper
INFO - 2024-10-04 15:07:34 --> Helper loaded: my_helper
INFO - 2024-10-04 15:07:34 --> Database Driver Class Initialized
INFO - 2024-10-04 15:07:34 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-04 15:07:34 --> Controller Class Initialized
DEBUG - 2024-10-04 15:07:34 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_catatan_guru/views/list.php
DEBUG - 2024-10-04 15:07:34 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-10-04 15:07:34 --> Final output sent to browser
DEBUG - 2024-10-04 15:07:34 --> Total execution time: 0.0473
INFO - 2024-10-04 15:07:38 --> Config Class Initialized
INFO - 2024-10-04 15:07:38 --> Hooks Class Initialized
DEBUG - 2024-10-04 15:07:38 --> UTF-8 Support Enabled
INFO - 2024-10-04 15:07:38 --> Utf8 Class Initialized
INFO - 2024-10-04 15:07:38 --> URI Class Initialized
INFO - 2024-10-04 15:07:38 --> Router Class Initialized
INFO - 2024-10-04 15:07:38 --> Output Class Initialized
INFO - 2024-10-04 15:07:38 --> Security Class Initialized
DEBUG - 2024-10-04 15:07:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-04 15:07:38 --> Input Class Initialized
INFO - 2024-10-04 15:07:38 --> Language Class Initialized
INFO - 2024-10-04 15:07:38 --> Language Class Initialized
INFO - 2024-10-04 15:07:38 --> Config Class Initialized
INFO - 2024-10-04 15:07:38 --> Loader Class Initialized
INFO - 2024-10-04 15:07:38 --> Helper loaded: url_helper
INFO - 2024-10-04 15:07:38 --> Helper loaded: file_helper
INFO - 2024-10-04 15:07:38 --> Helper loaded: form_helper
INFO - 2024-10-04 15:07:38 --> Helper loaded: my_helper
INFO - 2024-10-04 15:07:38 --> Database Driver Class Initialized
INFO - 2024-10-04 15:07:38 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-04 15:07:38 --> Controller Class Initialized
DEBUG - 2024-10-04 15:07:38 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/view_mapel/views/v_view_mapel.php
DEBUG - 2024-10-04 15:07:38 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-10-04 15:07:38 --> Final output sent to browser
DEBUG - 2024-10-04 15:07:38 --> Total execution time: 0.0294
INFO - 2024-10-04 15:07:40 --> Config Class Initialized
INFO - 2024-10-04 15:07:40 --> Hooks Class Initialized
DEBUG - 2024-10-04 15:07:40 --> UTF-8 Support Enabled
INFO - 2024-10-04 15:07:40 --> Utf8 Class Initialized
INFO - 2024-10-04 15:07:40 --> URI Class Initialized
INFO - 2024-10-04 15:07:40 --> Router Class Initialized
INFO - 2024-10-04 15:07:40 --> Output Class Initialized
INFO - 2024-10-04 15:07:40 --> Security Class Initialized
DEBUG - 2024-10-04 15:07:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-04 15:07:40 --> Input Class Initialized
INFO - 2024-10-04 15:07:40 --> Language Class Initialized
INFO - 2024-10-04 15:07:40 --> Language Class Initialized
INFO - 2024-10-04 15:07:40 --> Config Class Initialized
INFO - 2024-10-04 15:07:40 --> Loader Class Initialized
INFO - 2024-10-04 15:07:40 --> Helper loaded: url_helper
INFO - 2024-10-04 15:07:40 --> Helper loaded: file_helper
INFO - 2024-10-04 15:07:40 --> Helper loaded: form_helper
INFO - 2024-10-04 15:07:40 --> Helper loaded: my_helper
INFO - 2024-10-04 15:07:40 --> Database Driver Class Initialized
INFO - 2024-10-04 15:07:40 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-04 15:07:40 --> Controller Class Initialized
DEBUG - 2024-10-04 15:07:40 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/view_mapel/views/v_view_mapel.php
DEBUG - 2024-10-04 15:07:40 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-10-04 15:07:40 --> Final output sent to browser
DEBUG - 2024-10-04 15:07:40 --> Total execution time: 0.0502
INFO - 2024-10-04 15:08:39 --> Config Class Initialized
INFO - 2024-10-04 15:08:39 --> Hooks Class Initialized
DEBUG - 2024-10-04 15:08:39 --> UTF-8 Support Enabled
INFO - 2024-10-04 15:08:39 --> Utf8 Class Initialized
INFO - 2024-10-04 15:08:39 --> URI Class Initialized
INFO - 2024-10-04 15:08:39 --> Router Class Initialized
INFO - 2024-10-04 15:08:39 --> Output Class Initialized
INFO - 2024-10-04 15:08:39 --> Security Class Initialized
DEBUG - 2024-10-04 15:08:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-04 15:08:39 --> Input Class Initialized
INFO - 2024-10-04 15:08:39 --> Language Class Initialized
INFO - 2024-10-04 15:08:39 --> Language Class Initialized
INFO - 2024-10-04 15:08:39 --> Config Class Initialized
INFO - 2024-10-04 15:08:39 --> Loader Class Initialized
INFO - 2024-10-04 15:08:39 --> Helper loaded: url_helper
INFO - 2024-10-04 15:08:39 --> Helper loaded: file_helper
INFO - 2024-10-04 15:08:39 --> Helper loaded: form_helper
INFO - 2024-10-04 15:08:39 --> Helper loaded: my_helper
INFO - 2024-10-04 15:08:39 --> Database Driver Class Initialized
INFO - 2024-10-04 15:08:39 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-04 15:08:39 --> Controller Class Initialized
DEBUG - 2024-10-04 15:08:39 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/views/list.php
DEBUG - 2024-10-04 15:08:39 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-10-04 15:08:39 --> Final output sent to browser
DEBUG - 2024-10-04 15:08:39 --> Total execution time: 0.0320
INFO - 2024-10-04 15:08:39 --> Config Class Initialized
INFO - 2024-10-04 15:08:39 --> Hooks Class Initialized
DEBUG - 2024-10-04 15:08:39 --> UTF-8 Support Enabled
INFO - 2024-10-04 15:08:39 --> Utf8 Class Initialized
INFO - 2024-10-04 15:08:39 --> URI Class Initialized
INFO - 2024-10-04 15:08:39 --> Router Class Initialized
INFO - 2024-10-04 15:08:39 --> Output Class Initialized
INFO - 2024-10-04 15:08:39 --> Security Class Initialized
DEBUG - 2024-10-04 15:08:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-04 15:08:39 --> Input Class Initialized
INFO - 2024-10-04 15:08:39 --> Language Class Initialized
INFO - 2024-10-04 15:08:39 --> Language Class Initialized
INFO - 2024-10-04 15:08:39 --> Config Class Initialized
INFO - 2024-10-04 15:08:39 --> Loader Class Initialized
INFO - 2024-10-04 15:08:39 --> Helper loaded: url_helper
INFO - 2024-10-04 15:08:39 --> Helper loaded: file_helper
INFO - 2024-10-04 15:08:39 --> Helper loaded: form_helper
INFO - 2024-10-04 15:08:39 --> Helper loaded: my_helper
INFO - 2024-10-04 15:08:39 --> Database Driver Class Initialized
INFO - 2024-10-04 15:08:39 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-04 15:08:39 --> Controller Class Initialized
INFO - 2024-10-04 15:08:45 --> Config Class Initialized
INFO - 2024-10-04 15:08:45 --> Hooks Class Initialized
DEBUG - 2024-10-04 15:08:45 --> UTF-8 Support Enabled
INFO - 2024-10-04 15:08:45 --> Utf8 Class Initialized
INFO - 2024-10-04 15:08:45 --> URI Class Initialized
INFO - 2024-10-04 15:08:45 --> Router Class Initialized
INFO - 2024-10-04 15:08:45 --> Output Class Initialized
INFO - 2024-10-04 15:08:45 --> Security Class Initialized
DEBUG - 2024-10-04 15:08:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-04 15:08:45 --> Input Class Initialized
INFO - 2024-10-04 15:08:45 --> Language Class Initialized
INFO - 2024-10-04 15:08:45 --> Language Class Initialized
INFO - 2024-10-04 15:08:45 --> Config Class Initialized
INFO - 2024-10-04 15:08:45 --> Loader Class Initialized
INFO - 2024-10-04 15:08:45 --> Helper loaded: url_helper
INFO - 2024-10-04 15:08:45 --> Helper loaded: file_helper
INFO - 2024-10-04 15:08:45 --> Helper loaded: form_helper
INFO - 2024-10-04 15:08:45 --> Helper loaded: my_helper
INFO - 2024-10-04 15:08:45 --> Database Driver Class Initialized
INFO - 2024-10-04 15:08:45 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-04 15:08:45 --> Controller Class Initialized
INFO - 2024-10-04 15:08:45 --> Final output sent to browser
DEBUG - 2024-10-04 15:08:45 --> Total execution time: 0.0567
INFO - 2024-10-04 15:11:31 --> Config Class Initialized
INFO - 2024-10-04 15:11:31 --> Hooks Class Initialized
DEBUG - 2024-10-04 15:11:31 --> UTF-8 Support Enabled
INFO - 2024-10-04 15:11:31 --> Utf8 Class Initialized
INFO - 2024-10-04 15:11:31 --> URI Class Initialized
INFO - 2024-10-04 15:11:31 --> Router Class Initialized
INFO - 2024-10-04 15:11:31 --> Output Class Initialized
INFO - 2024-10-04 15:11:31 --> Security Class Initialized
DEBUG - 2024-10-04 15:11:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-04 15:11:31 --> Input Class Initialized
INFO - 2024-10-04 15:11:31 --> Language Class Initialized
INFO - 2024-10-04 15:11:31 --> Language Class Initialized
INFO - 2024-10-04 15:11:31 --> Config Class Initialized
INFO - 2024-10-04 15:11:31 --> Loader Class Initialized
INFO - 2024-10-04 15:11:31 --> Helper loaded: url_helper
INFO - 2024-10-04 15:11:31 --> Helper loaded: file_helper
INFO - 2024-10-04 15:11:31 --> Helper loaded: form_helper
INFO - 2024-10-04 15:11:31 --> Helper loaded: my_helper
INFO - 2024-10-04 15:11:31 --> Database Driver Class Initialized
INFO - 2024-10-04 15:11:31 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-04 15:11:31 --> Controller Class Initialized
INFO - 2024-10-04 15:11:31 --> Final output sent to browser
DEBUG - 2024-10-04 15:11:31 --> Total execution time: 0.0623
INFO - 2024-10-04 15:11:39 --> Config Class Initialized
INFO - 2024-10-04 15:11:39 --> Hooks Class Initialized
DEBUG - 2024-10-04 15:11:39 --> UTF-8 Support Enabled
INFO - 2024-10-04 15:11:39 --> Utf8 Class Initialized
INFO - 2024-10-04 15:11:39 --> URI Class Initialized
INFO - 2024-10-04 15:11:39 --> Router Class Initialized
INFO - 2024-10-04 15:11:39 --> Output Class Initialized
INFO - 2024-10-04 15:11:39 --> Security Class Initialized
DEBUG - 2024-10-04 15:11:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-04 15:11:39 --> Input Class Initialized
INFO - 2024-10-04 15:11:39 --> Language Class Initialized
INFO - 2024-10-04 15:11:39 --> Language Class Initialized
INFO - 2024-10-04 15:11:39 --> Config Class Initialized
INFO - 2024-10-04 15:11:39 --> Loader Class Initialized
INFO - 2024-10-04 15:11:39 --> Helper loaded: url_helper
INFO - 2024-10-04 15:11:39 --> Helper loaded: file_helper
INFO - 2024-10-04 15:11:39 --> Helper loaded: form_helper
INFO - 2024-10-04 15:11:39 --> Helper loaded: my_helper
INFO - 2024-10-04 15:11:39 --> Database Driver Class Initialized
INFO - 2024-10-04 15:11:39 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-04 15:11:39 --> Controller Class Initialized
DEBUG - 2024-10-04 15:11:39 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/view_mapel/views/v_view_mapel.php
DEBUG - 2024-10-04 15:11:39 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-10-04 15:11:39 --> Final output sent to browser
DEBUG - 2024-10-04 15:11:39 --> Total execution time: 0.0296
INFO - 2024-10-04 15:11:46 --> Config Class Initialized
INFO - 2024-10-04 15:11:46 --> Hooks Class Initialized
DEBUG - 2024-10-04 15:11:46 --> UTF-8 Support Enabled
INFO - 2024-10-04 15:11:46 --> Utf8 Class Initialized
INFO - 2024-10-04 15:11:46 --> URI Class Initialized
INFO - 2024-10-04 15:11:46 --> Router Class Initialized
INFO - 2024-10-04 15:11:46 --> Output Class Initialized
INFO - 2024-10-04 15:11:46 --> Security Class Initialized
DEBUG - 2024-10-04 15:11:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-04 15:11:46 --> Input Class Initialized
INFO - 2024-10-04 15:11:46 --> Language Class Initialized
INFO - 2024-10-04 15:11:46 --> Language Class Initialized
INFO - 2024-10-04 15:11:46 --> Config Class Initialized
INFO - 2024-10-04 15:11:46 --> Loader Class Initialized
INFO - 2024-10-04 15:11:46 --> Helper loaded: url_helper
INFO - 2024-10-04 15:11:46 --> Helper loaded: file_helper
INFO - 2024-10-04 15:11:46 --> Helper loaded: form_helper
INFO - 2024-10-04 15:11:46 --> Helper loaded: my_helper
INFO - 2024-10-04 15:11:46 --> Database Driver Class Initialized
INFO - 2024-10-04 15:11:46 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-04 15:11:46 --> Controller Class Initialized
DEBUG - 2024-10-04 15:11:46 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_catatan_guru/views/list.php
DEBUG - 2024-10-04 15:11:46 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-10-04 15:11:46 --> Final output sent to browser
DEBUG - 2024-10-04 15:11:46 --> Total execution time: 0.0312
INFO - 2024-10-04 15:11:49 --> Config Class Initialized
INFO - 2024-10-04 15:11:49 --> Hooks Class Initialized
DEBUG - 2024-10-04 15:11:49 --> UTF-8 Support Enabled
INFO - 2024-10-04 15:11:49 --> Utf8 Class Initialized
INFO - 2024-10-04 15:11:49 --> URI Class Initialized
INFO - 2024-10-04 15:11:49 --> Router Class Initialized
INFO - 2024-10-04 15:11:49 --> Output Class Initialized
INFO - 2024-10-04 15:11:49 --> Security Class Initialized
DEBUG - 2024-10-04 15:11:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-04 15:11:49 --> Input Class Initialized
INFO - 2024-10-04 15:11:49 --> Language Class Initialized
INFO - 2024-10-04 15:11:49 --> Language Class Initialized
INFO - 2024-10-04 15:11:49 --> Config Class Initialized
INFO - 2024-10-04 15:11:49 --> Loader Class Initialized
INFO - 2024-10-04 15:11:49 --> Helper loaded: url_helper
INFO - 2024-10-04 15:11:49 --> Helper loaded: file_helper
INFO - 2024-10-04 15:11:49 --> Helper loaded: form_helper
INFO - 2024-10-04 15:11:49 --> Helper loaded: my_helper
INFO - 2024-10-04 15:11:49 --> Database Driver Class Initialized
INFO - 2024-10-04 15:11:49 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-04 15:11:49 --> Controller Class Initialized
INFO - 2024-10-04 15:11:49 --> Final output sent to browser
DEBUG - 2024-10-04 15:11:49 --> Total execution time: 0.0353
INFO - 2024-10-04 15:15:52 --> Config Class Initialized
INFO - 2024-10-04 15:15:52 --> Hooks Class Initialized
DEBUG - 2024-10-04 15:15:52 --> UTF-8 Support Enabled
INFO - 2024-10-04 15:15:52 --> Utf8 Class Initialized
INFO - 2024-10-04 15:15:52 --> URI Class Initialized
INFO - 2024-10-04 15:15:52 --> Router Class Initialized
INFO - 2024-10-04 15:15:52 --> Output Class Initialized
INFO - 2024-10-04 15:15:52 --> Security Class Initialized
DEBUG - 2024-10-04 15:15:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-04 15:15:52 --> Input Class Initialized
INFO - 2024-10-04 15:15:52 --> Language Class Initialized
INFO - 2024-10-04 15:15:52 --> Language Class Initialized
INFO - 2024-10-04 15:15:52 --> Config Class Initialized
INFO - 2024-10-04 15:15:52 --> Loader Class Initialized
INFO - 2024-10-04 15:15:52 --> Helper loaded: url_helper
INFO - 2024-10-04 15:15:52 --> Helper loaded: file_helper
INFO - 2024-10-04 15:15:52 --> Helper loaded: form_helper
INFO - 2024-10-04 15:15:52 --> Helper loaded: my_helper
INFO - 2024-10-04 15:15:52 --> Database Driver Class Initialized
INFO - 2024-10-04 15:15:52 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-04 15:15:52 --> Controller Class Initialized
INFO - 2024-10-04 15:15:52 --> Final output sent to browser
DEBUG - 2024-10-04 15:15:52 --> Total execution time: 0.0489
INFO - 2024-10-04 15:16:00 --> Config Class Initialized
INFO - 2024-10-04 15:16:00 --> Hooks Class Initialized
DEBUG - 2024-10-04 15:16:00 --> UTF-8 Support Enabled
INFO - 2024-10-04 15:16:00 --> Utf8 Class Initialized
INFO - 2024-10-04 15:16:00 --> URI Class Initialized
INFO - 2024-10-04 15:16:00 --> Router Class Initialized
INFO - 2024-10-04 15:16:00 --> Output Class Initialized
INFO - 2024-10-04 15:16:00 --> Security Class Initialized
DEBUG - 2024-10-04 15:16:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-04 15:16:00 --> Input Class Initialized
INFO - 2024-10-04 15:16:00 --> Language Class Initialized
INFO - 2024-10-04 15:16:00 --> Language Class Initialized
INFO - 2024-10-04 15:16:00 --> Config Class Initialized
INFO - 2024-10-04 15:16:00 --> Loader Class Initialized
INFO - 2024-10-04 15:16:00 --> Helper loaded: url_helper
INFO - 2024-10-04 15:16:00 --> Helper loaded: file_helper
INFO - 2024-10-04 15:16:00 --> Helper loaded: form_helper
INFO - 2024-10-04 15:16:00 --> Helper loaded: my_helper
INFO - 2024-10-04 15:16:00 --> Database Driver Class Initialized
INFO - 2024-10-04 15:16:00 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-04 15:16:00 --> Controller Class Initialized
DEBUG - 2024-10-04 15:16:00 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/view_mapel/views/v_view_mapel.php
DEBUG - 2024-10-04 15:16:00 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-10-04 15:16:00 --> Final output sent to browser
DEBUG - 2024-10-04 15:16:00 --> Total execution time: 0.0303
INFO - 2024-10-04 15:16:02 --> Config Class Initialized
INFO - 2024-10-04 15:16:02 --> Hooks Class Initialized
DEBUG - 2024-10-04 15:16:02 --> UTF-8 Support Enabled
INFO - 2024-10-04 15:16:02 --> Utf8 Class Initialized
INFO - 2024-10-04 15:16:02 --> URI Class Initialized
INFO - 2024-10-04 15:16:02 --> Router Class Initialized
INFO - 2024-10-04 15:16:02 --> Output Class Initialized
INFO - 2024-10-04 15:16:02 --> Security Class Initialized
DEBUG - 2024-10-04 15:16:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-04 15:16:02 --> Input Class Initialized
INFO - 2024-10-04 15:16:02 --> Language Class Initialized
INFO - 2024-10-04 15:16:02 --> Language Class Initialized
INFO - 2024-10-04 15:16:02 --> Config Class Initialized
INFO - 2024-10-04 15:16:02 --> Loader Class Initialized
INFO - 2024-10-04 15:16:02 --> Helper loaded: url_helper
INFO - 2024-10-04 15:16:02 --> Helper loaded: file_helper
INFO - 2024-10-04 15:16:02 --> Helper loaded: form_helper
INFO - 2024-10-04 15:16:02 --> Helper loaded: my_helper
INFO - 2024-10-04 15:16:02 --> Database Driver Class Initialized
INFO - 2024-10-04 15:16:02 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-04 15:16:02 --> Controller Class Initialized
DEBUG - 2024-10-04 15:16:02 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/views/list.php
DEBUG - 2024-10-04 15:16:02 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-10-04 15:16:02 --> Final output sent to browser
DEBUG - 2024-10-04 15:16:02 --> Total execution time: 0.0343
INFO - 2024-10-04 15:16:03 --> Config Class Initialized
INFO - 2024-10-04 15:16:03 --> Hooks Class Initialized
DEBUG - 2024-10-04 15:16:03 --> UTF-8 Support Enabled
INFO - 2024-10-04 15:16:03 --> Utf8 Class Initialized
INFO - 2024-10-04 15:16:03 --> URI Class Initialized
INFO - 2024-10-04 15:16:03 --> Router Class Initialized
INFO - 2024-10-04 15:16:03 --> Output Class Initialized
INFO - 2024-10-04 15:16:03 --> Security Class Initialized
DEBUG - 2024-10-04 15:16:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-04 15:16:03 --> Input Class Initialized
INFO - 2024-10-04 15:16:03 --> Language Class Initialized
INFO - 2024-10-04 15:16:03 --> Language Class Initialized
INFO - 2024-10-04 15:16:03 --> Config Class Initialized
INFO - 2024-10-04 15:16:03 --> Loader Class Initialized
INFO - 2024-10-04 15:16:03 --> Helper loaded: url_helper
INFO - 2024-10-04 15:16:03 --> Helper loaded: file_helper
INFO - 2024-10-04 15:16:03 --> Helper loaded: form_helper
INFO - 2024-10-04 15:16:03 --> Helper loaded: my_helper
INFO - 2024-10-04 15:16:03 --> Database Driver Class Initialized
INFO - 2024-10-04 15:16:03 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-04 15:16:03 --> Controller Class Initialized
INFO - 2024-10-04 15:16:05 --> Config Class Initialized
INFO - 2024-10-04 15:16:05 --> Hooks Class Initialized
DEBUG - 2024-10-04 15:16:05 --> UTF-8 Support Enabled
INFO - 2024-10-04 15:16:05 --> Utf8 Class Initialized
INFO - 2024-10-04 15:16:05 --> URI Class Initialized
INFO - 2024-10-04 15:16:05 --> Router Class Initialized
INFO - 2024-10-04 15:16:05 --> Output Class Initialized
INFO - 2024-10-04 15:16:05 --> Security Class Initialized
DEBUG - 2024-10-04 15:16:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-04 15:16:05 --> Input Class Initialized
INFO - 2024-10-04 15:16:05 --> Language Class Initialized
INFO - 2024-10-04 15:16:05 --> Language Class Initialized
INFO - 2024-10-04 15:16:05 --> Config Class Initialized
INFO - 2024-10-04 15:16:05 --> Loader Class Initialized
INFO - 2024-10-04 15:16:05 --> Helper loaded: url_helper
INFO - 2024-10-04 15:16:05 --> Helper loaded: file_helper
INFO - 2024-10-04 15:16:05 --> Helper loaded: form_helper
INFO - 2024-10-04 15:16:05 --> Helper loaded: my_helper
INFO - 2024-10-04 15:16:05 --> Database Driver Class Initialized
INFO - 2024-10-04 15:16:05 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-04 15:16:05 --> Controller Class Initialized
INFO - 2024-10-04 15:16:05 --> Final output sent to browser
DEBUG - 2024-10-04 15:16:05 --> Total execution time: 0.0314
INFO - 2024-10-04 15:16:09 --> Config Class Initialized
INFO - 2024-10-04 15:16:09 --> Hooks Class Initialized
DEBUG - 2024-10-04 15:16:09 --> UTF-8 Support Enabled
INFO - 2024-10-04 15:16:09 --> Utf8 Class Initialized
INFO - 2024-10-04 15:16:09 --> URI Class Initialized
INFO - 2024-10-04 15:16:09 --> Router Class Initialized
INFO - 2024-10-04 15:16:09 --> Output Class Initialized
INFO - 2024-10-04 15:16:09 --> Security Class Initialized
DEBUG - 2024-10-04 15:16:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-04 15:16:09 --> Input Class Initialized
INFO - 2024-10-04 15:16:09 --> Language Class Initialized
INFO - 2024-10-04 15:16:09 --> Language Class Initialized
INFO - 2024-10-04 15:16:09 --> Config Class Initialized
INFO - 2024-10-04 15:16:09 --> Loader Class Initialized
INFO - 2024-10-04 15:16:09 --> Helper loaded: url_helper
INFO - 2024-10-04 15:16:09 --> Helper loaded: file_helper
INFO - 2024-10-04 15:16:09 --> Helper loaded: form_helper
INFO - 2024-10-04 15:16:09 --> Helper loaded: my_helper
INFO - 2024-10-04 15:16:09 --> Database Driver Class Initialized
INFO - 2024-10-04 15:16:09 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-04 15:16:09 --> Controller Class Initialized
DEBUG - 2024-10-04 15:16:09 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/view_mapel/views/v_view_mapel.php
DEBUG - 2024-10-04 15:16:09 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-10-04 15:16:09 --> Final output sent to browser
DEBUG - 2024-10-04 15:16:09 --> Total execution time: 0.0518
INFO - 2024-10-04 15:16:10 --> Config Class Initialized
INFO - 2024-10-04 15:16:10 --> Hooks Class Initialized
DEBUG - 2024-10-04 15:16:10 --> UTF-8 Support Enabled
INFO - 2024-10-04 15:16:10 --> Utf8 Class Initialized
INFO - 2024-10-04 15:16:10 --> URI Class Initialized
INFO - 2024-10-04 15:16:10 --> Router Class Initialized
INFO - 2024-10-04 15:16:10 --> Output Class Initialized
INFO - 2024-10-04 15:16:10 --> Security Class Initialized
DEBUG - 2024-10-04 15:16:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-04 15:16:10 --> Input Class Initialized
INFO - 2024-10-04 15:16:10 --> Language Class Initialized
INFO - 2024-10-04 15:16:10 --> Language Class Initialized
INFO - 2024-10-04 15:16:10 --> Config Class Initialized
INFO - 2024-10-04 15:16:10 --> Loader Class Initialized
INFO - 2024-10-04 15:16:10 --> Helper loaded: url_helper
INFO - 2024-10-04 15:16:10 --> Helper loaded: file_helper
INFO - 2024-10-04 15:16:10 --> Helper loaded: form_helper
INFO - 2024-10-04 15:16:10 --> Helper loaded: my_helper
INFO - 2024-10-04 15:16:10 --> Database Driver Class Initialized
INFO - 2024-10-04 15:16:10 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-04 15:16:10 --> Controller Class Initialized
DEBUG - 2024-10-04 15:16:10 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/views/list.php
DEBUG - 2024-10-04 15:16:10 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-10-04 15:16:10 --> Final output sent to browser
DEBUG - 2024-10-04 15:16:10 --> Total execution time: 0.0268
INFO - 2024-10-04 15:16:10 --> Config Class Initialized
INFO - 2024-10-04 15:16:10 --> Hooks Class Initialized
DEBUG - 2024-10-04 15:16:10 --> UTF-8 Support Enabled
INFO - 2024-10-04 15:16:10 --> Utf8 Class Initialized
INFO - 2024-10-04 15:16:10 --> URI Class Initialized
INFO - 2024-10-04 15:16:10 --> Router Class Initialized
INFO - 2024-10-04 15:16:10 --> Output Class Initialized
INFO - 2024-10-04 15:16:10 --> Security Class Initialized
DEBUG - 2024-10-04 15:16:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-04 15:16:10 --> Input Class Initialized
INFO - 2024-10-04 15:16:10 --> Language Class Initialized
INFO - 2024-10-04 15:16:10 --> Language Class Initialized
INFO - 2024-10-04 15:16:10 --> Config Class Initialized
INFO - 2024-10-04 15:16:10 --> Loader Class Initialized
INFO - 2024-10-04 15:16:10 --> Helper loaded: url_helper
INFO - 2024-10-04 15:16:10 --> Helper loaded: file_helper
INFO - 2024-10-04 15:16:10 --> Helper loaded: form_helper
INFO - 2024-10-04 15:16:10 --> Helper loaded: my_helper
INFO - 2024-10-04 15:16:11 --> Database Driver Class Initialized
INFO - 2024-10-04 15:16:11 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-04 15:16:11 --> Controller Class Initialized
INFO - 2024-10-04 15:16:17 --> Config Class Initialized
INFO - 2024-10-04 15:16:17 --> Hooks Class Initialized
DEBUG - 2024-10-04 15:16:17 --> UTF-8 Support Enabled
INFO - 2024-10-04 15:16:17 --> Utf8 Class Initialized
INFO - 2024-10-04 15:16:17 --> URI Class Initialized
INFO - 2024-10-04 15:16:17 --> Router Class Initialized
INFO - 2024-10-04 15:16:17 --> Output Class Initialized
INFO - 2024-10-04 15:16:17 --> Security Class Initialized
DEBUG - 2024-10-04 15:16:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-04 15:16:17 --> Input Class Initialized
INFO - 2024-10-04 15:16:17 --> Language Class Initialized
INFO - 2024-10-04 15:16:17 --> Language Class Initialized
INFO - 2024-10-04 15:16:17 --> Config Class Initialized
INFO - 2024-10-04 15:16:17 --> Loader Class Initialized
INFO - 2024-10-04 15:16:17 --> Helper loaded: url_helper
INFO - 2024-10-04 15:16:17 --> Helper loaded: file_helper
INFO - 2024-10-04 15:16:17 --> Helper loaded: form_helper
INFO - 2024-10-04 15:16:17 --> Helper loaded: my_helper
INFO - 2024-10-04 15:16:17 --> Database Driver Class Initialized
INFO - 2024-10-04 15:16:17 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-04 15:16:17 --> Controller Class Initialized
DEBUG - 2024-10-04 15:16:17 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/view_mapel/views/v_view_mapel.php
DEBUG - 2024-10-04 15:16:17 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-10-04 15:16:17 --> Final output sent to browser
DEBUG - 2024-10-04 15:16:17 --> Total execution time: 0.0559
INFO - 2024-10-04 15:16:33 --> Config Class Initialized
INFO - 2024-10-04 15:16:33 --> Hooks Class Initialized
DEBUG - 2024-10-04 15:16:33 --> UTF-8 Support Enabled
INFO - 2024-10-04 15:16:33 --> Utf8 Class Initialized
INFO - 2024-10-04 15:16:33 --> URI Class Initialized
INFO - 2024-10-04 15:16:33 --> Router Class Initialized
INFO - 2024-10-04 15:16:33 --> Output Class Initialized
INFO - 2024-10-04 15:16:33 --> Security Class Initialized
DEBUG - 2024-10-04 15:16:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-04 15:16:33 --> Input Class Initialized
INFO - 2024-10-04 15:16:33 --> Language Class Initialized
INFO - 2024-10-04 15:16:33 --> Language Class Initialized
INFO - 2024-10-04 15:16:33 --> Config Class Initialized
INFO - 2024-10-04 15:16:33 --> Loader Class Initialized
INFO - 2024-10-04 15:16:33 --> Helper loaded: url_helper
INFO - 2024-10-04 15:16:33 --> Helper loaded: file_helper
INFO - 2024-10-04 15:16:33 --> Helper loaded: form_helper
INFO - 2024-10-04 15:16:33 --> Helper loaded: my_helper
INFO - 2024-10-04 15:16:33 --> Database Driver Class Initialized
INFO - 2024-10-04 15:16:33 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-04 15:16:33 --> Controller Class Initialized
DEBUG - 2024-10-04 15:16:33 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_catatan_guru/views/list.php
DEBUG - 2024-10-04 15:16:33 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-10-04 15:16:33 --> Final output sent to browser
DEBUG - 2024-10-04 15:16:33 --> Total execution time: 0.0330
INFO - 2024-10-04 15:16:35 --> Config Class Initialized
INFO - 2024-10-04 15:16:35 --> Hooks Class Initialized
DEBUG - 2024-10-04 15:16:35 --> UTF-8 Support Enabled
INFO - 2024-10-04 15:16:35 --> Utf8 Class Initialized
INFO - 2024-10-04 15:16:35 --> URI Class Initialized
INFO - 2024-10-04 15:16:35 --> Router Class Initialized
INFO - 2024-10-04 15:16:35 --> Output Class Initialized
INFO - 2024-10-04 15:16:35 --> Security Class Initialized
DEBUG - 2024-10-04 15:16:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-04 15:16:35 --> Input Class Initialized
INFO - 2024-10-04 15:16:35 --> Language Class Initialized
INFO - 2024-10-04 15:16:35 --> Language Class Initialized
INFO - 2024-10-04 15:16:35 --> Config Class Initialized
INFO - 2024-10-04 15:16:35 --> Loader Class Initialized
INFO - 2024-10-04 15:16:35 --> Helper loaded: url_helper
INFO - 2024-10-04 15:16:35 --> Helper loaded: file_helper
INFO - 2024-10-04 15:16:35 --> Helper loaded: form_helper
INFO - 2024-10-04 15:16:35 --> Helper loaded: my_helper
INFO - 2024-10-04 15:16:35 --> Database Driver Class Initialized
INFO - 2024-10-04 15:16:35 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-04 15:16:35 --> Controller Class Initialized
DEBUG - 2024-10-04 15:16:35 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/view_mapel/views/v_view_mapel.php
DEBUG - 2024-10-04 15:16:35 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-10-04 15:16:35 --> Final output sent to browser
DEBUG - 2024-10-04 15:16:35 --> Total execution time: 0.0266
INFO - 2024-10-04 15:16:37 --> Config Class Initialized
INFO - 2024-10-04 15:16:37 --> Hooks Class Initialized
DEBUG - 2024-10-04 15:16:37 --> UTF-8 Support Enabled
INFO - 2024-10-04 15:16:37 --> Utf8 Class Initialized
INFO - 2024-10-04 15:16:37 --> URI Class Initialized
INFO - 2024-10-04 15:16:37 --> Router Class Initialized
INFO - 2024-10-04 15:16:37 --> Output Class Initialized
INFO - 2024-10-04 15:16:37 --> Security Class Initialized
DEBUG - 2024-10-04 15:16:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-04 15:16:37 --> Input Class Initialized
INFO - 2024-10-04 15:16:37 --> Language Class Initialized
INFO - 2024-10-04 15:16:37 --> Language Class Initialized
INFO - 2024-10-04 15:16:37 --> Config Class Initialized
INFO - 2024-10-04 15:16:37 --> Loader Class Initialized
INFO - 2024-10-04 15:16:37 --> Helper loaded: url_helper
INFO - 2024-10-04 15:16:37 --> Helper loaded: file_helper
INFO - 2024-10-04 15:16:37 --> Helper loaded: form_helper
INFO - 2024-10-04 15:16:37 --> Helper loaded: my_helper
INFO - 2024-10-04 15:16:37 --> Database Driver Class Initialized
INFO - 2024-10-04 15:16:37 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-04 15:16:37 --> Controller Class Initialized
DEBUG - 2024-10-04 15:16:37 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/views/list.php
DEBUG - 2024-10-04 15:16:37 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-10-04 15:16:37 --> Final output sent to browser
DEBUG - 2024-10-04 15:16:37 --> Total execution time: 0.0503
INFO - 2024-10-04 15:16:37 --> Config Class Initialized
INFO - 2024-10-04 15:16:37 --> Hooks Class Initialized
DEBUG - 2024-10-04 15:16:37 --> UTF-8 Support Enabled
INFO - 2024-10-04 15:16:37 --> Utf8 Class Initialized
INFO - 2024-10-04 15:16:37 --> URI Class Initialized
INFO - 2024-10-04 15:16:37 --> Router Class Initialized
INFO - 2024-10-04 15:16:37 --> Output Class Initialized
INFO - 2024-10-04 15:16:37 --> Security Class Initialized
DEBUG - 2024-10-04 15:16:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-04 15:16:37 --> Input Class Initialized
INFO - 2024-10-04 15:16:37 --> Language Class Initialized
INFO - 2024-10-04 15:16:37 --> Language Class Initialized
INFO - 2024-10-04 15:16:37 --> Config Class Initialized
INFO - 2024-10-04 15:16:37 --> Loader Class Initialized
INFO - 2024-10-04 15:16:37 --> Helper loaded: url_helper
INFO - 2024-10-04 15:16:37 --> Helper loaded: file_helper
INFO - 2024-10-04 15:16:37 --> Helper loaded: form_helper
INFO - 2024-10-04 15:16:37 --> Helper loaded: my_helper
INFO - 2024-10-04 15:16:37 --> Database Driver Class Initialized
INFO - 2024-10-04 15:16:37 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-04 15:16:37 --> Controller Class Initialized
INFO - 2024-10-04 15:16:41 --> Config Class Initialized
INFO - 2024-10-04 15:16:41 --> Hooks Class Initialized
DEBUG - 2024-10-04 15:16:41 --> UTF-8 Support Enabled
INFO - 2024-10-04 15:16:41 --> Utf8 Class Initialized
INFO - 2024-10-04 15:16:41 --> URI Class Initialized
INFO - 2024-10-04 15:16:41 --> Router Class Initialized
INFO - 2024-10-04 15:16:41 --> Output Class Initialized
INFO - 2024-10-04 15:16:41 --> Security Class Initialized
DEBUG - 2024-10-04 15:16:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-04 15:16:41 --> Input Class Initialized
INFO - 2024-10-04 15:16:41 --> Language Class Initialized
INFO - 2024-10-04 15:16:41 --> Language Class Initialized
INFO - 2024-10-04 15:16:41 --> Config Class Initialized
INFO - 2024-10-04 15:16:41 --> Loader Class Initialized
INFO - 2024-10-04 15:16:41 --> Helper loaded: url_helper
INFO - 2024-10-04 15:16:41 --> Helper loaded: file_helper
INFO - 2024-10-04 15:16:41 --> Helper loaded: form_helper
INFO - 2024-10-04 15:16:41 --> Helper loaded: my_helper
INFO - 2024-10-04 15:16:41 --> Database Driver Class Initialized
INFO - 2024-10-04 15:16:41 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-04 15:16:41 --> Controller Class Initialized
INFO - 2024-10-04 15:16:41 --> Final output sent to browser
DEBUG - 2024-10-04 15:16:41 --> Total execution time: 0.0756
INFO - 2024-10-04 15:19:32 --> Config Class Initialized
INFO - 2024-10-04 15:19:32 --> Hooks Class Initialized
DEBUG - 2024-10-04 15:19:32 --> UTF-8 Support Enabled
INFO - 2024-10-04 15:19:32 --> Utf8 Class Initialized
INFO - 2024-10-04 15:19:32 --> URI Class Initialized
INFO - 2024-10-04 15:19:32 --> Router Class Initialized
INFO - 2024-10-04 15:19:32 --> Output Class Initialized
INFO - 2024-10-04 15:19:32 --> Security Class Initialized
DEBUG - 2024-10-04 15:19:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-04 15:19:32 --> Input Class Initialized
INFO - 2024-10-04 15:19:32 --> Language Class Initialized
INFO - 2024-10-04 15:19:32 --> Language Class Initialized
INFO - 2024-10-04 15:19:32 --> Config Class Initialized
INFO - 2024-10-04 15:19:32 --> Loader Class Initialized
INFO - 2024-10-04 15:19:32 --> Helper loaded: url_helper
INFO - 2024-10-04 15:19:32 --> Helper loaded: file_helper
INFO - 2024-10-04 15:19:32 --> Helper loaded: form_helper
INFO - 2024-10-04 15:19:32 --> Helper loaded: my_helper
INFO - 2024-10-04 15:19:32 --> Database Driver Class Initialized
INFO - 2024-10-04 15:19:32 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-04 15:19:32 --> Controller Class Initialized
DEBUG - 2024-10-04 15:19:32 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/view_mapel/views/v_view_mapel.php
DEBUG - 2024-10-04 15:19:32 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-10-04 15:19:32 --> Final output sent to browser
DEBUG - 2024-10-04 15:19:32 --> Total execution time: 0.0526
INFO - 2024-10-04 15:19:36 --> Config Class Initialized
INFO - 2024-10-04 15:19:36 --> Hooks Class Initialized
DEBUG - 2024-10-04 15:19:36 --> UTF-8 Support Enabled
INFO - 2024-10-04 15:19:36 --> Utf8 Class Initialized
INFO - 2024-10-04 15:19:36 --> URI Class Initialized
INFO - 2024-10-04 15:19:36 --> Router Class Initialized
INFO - 2024-10-04 15:19:36 --> Output Class Initialized
INFO - 2024-10-04 15:19:36 --> Security Class Initialized
DEBUG - 2024-10-04 15:19:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-04 15:19:36 --> Input Class Initialized
INFO - 2024-10-04 15:19:36 --> Language Class Initialized
INFO - 2024-10-04 15:19:36 --> Language Class Initialized
INFO - 2024-10-04 15:19:36 --> Config Class Initialized
INFO - 2024-10-04 15:19:36 --> Loader Class Initialized
INFO - 2024-10-04 15:19:36 --> Helper loaded: url_helper
INFO - 2024-10-04 15:19:36 --> Helper loaded: file_helper
INFO - 2024-10-04 15:19:36 --> Helper loaded: form_helper
INFO - 2024-10-04 15:19:36 --> Helper loaded: my_helper
INFO - 2024-10-04 15:19:36 --> Database Driver Class Initialized
INFO - 2024-10-04 15:19:36 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-04 15:19:36 --> Controller Class Initialized
DEBUG - 2024-10-04 15:19:36 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/views/list.php
DEBUG - 2024-10-04 15:19:36 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-10-04 15:19:36 --> Final output sent to browser
DEBUG - 2024-10-04 15:19:36 --> Total execution time: 0.0353
INFO - 2024-10-04 15:19:36 --> Config Class Initialized
INFO - 2024-10-04 15:19:36 --> Hooks Class Initialized
DEBUG - 2024-10-04 15:19:36 --> UTF-8 Support Enabled
INFO - 2024-10-04 15:19:36 --> Utf8 Class Initialized
INFO - 2024-10-04 15:19:36 --> URI Class Initialized
INFO - 2024-10-04 15:19:36 --> Router Class Initialized
INFO - 2024-10-04 15:19:36 --> Output Class Initialized
INFO - 2024-10-04 15:19:36 --> Security Class Initialized
DEBUG - 2024-10-04 15:19:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-04 15:19:36 --> Input Class Initialized
INFO - 2024-10-04 15:19:36 --> Language Class Initialized
INFO - 2024-10-04 15:19:36 --> Language Class Initialized
INFO - 2024-10-04 15:19:36 --> Config Class Initialized
INFO - 2024-10-04 15:19:36 --> Loader Class Initialized
INFO - 2024-10-04 15:19:36 --> Helper loaded: url_helper
INFO - 2024-10-04 15:19:36 --> Helper loaded: file_helper
INFO - 2024-10-04 15:19:36 --> Helper loaded: form_helper
INFO - 2024-10-04 15:19:36 --> Helper loaded: my_helper
INFO - 2024-10-04 15:19:36 --> Database Driver Class Initialized
INFO - 2024-10-04 15:19:36 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-04 15:19:36 --> Controller Class Initialized
INFO - 2024-10-04 15:19:41 --> Config Class Initialized
INFO - 2024-10-04 15:19:41 --> Hooks Class Initialized
DEBUG - 2024-10-04 15:19:41 --> UTF-8 Support Enabled
INFO - 2024-10-04 15:19:41 --> Utf8 Class Initialized
INFO - 2024-10-04 15:19:41 --> URI Class Initialized
INFO - 2024-10-04 15:19:41 --> Router Class Initialized
INFO - 2024-10-04 15:19:41 --> Output Class Initialized
INFO - 2024-10-04 15:19:41 --> Security Class Initialized
DEBUG - 2024-10-04 15:19:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-04 15:19:41 --> Input Class Initialized
INFO - 2024-10-04 15:19:41 --> Language Class Initialized
INFO - 2024-10-04 15:19:41 --> Language Class Initialized
INFO - 2024-10-04 15:19:41 --> Config Class Initialized
INFO - 2024-10-04 15:19:41 --> Loader Class Initialized
INFO - 2024-10-04 15:19:41 --> Helper loaded: url_helper
INFO - 2024-10-04 15:19:41 --> Helper loaded: file_helper
INFO - 2024-10-04 15:19:41 --> Helper loaded: form_helper
INFO - 2024-10-04 15:19:41 --> Helper loaded: my_helper
INFO - 2024-10-04 15:19:41 --> Database Driver Class Initialized
INFO - 2024-10-04 15:19:41 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-04 15:19:41 --> Controller Class Initialized
INFO - 2024-10-04 15:19:41 --> Final output sent to browser
DEBUG - 2024-10-04 15:19:41 --> Total execution time: 0.0344
INFO - 2024-10-04 15:22:35 --> Config Class Initialized
INFO - 2024-10-04 15:22:35 --> Hooks Class Initialized
DEBUG - 2024-10-04 15:22:35 --> UTF-8 Support Enabled
INFO - 2024-10-04 15:22:35 --> Utf8 Class Initialized
INFO - 2024-10-04 15:22:35 --> URI Class Initialized
INFO - 2024-10-04 15:22:35 --> Router Class Initialized
INFO - 2024-10-04 15:22:35 --> Output Class Initialized
INFO - 2024-10-04 15:22:35 --> Security Class Initialized
DEBUG - 2024-10-04 15:22:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-04 15:22:35 --> Input Class Initialized
INFO - 2024-10-04 15:22:35 --> Language Class Initialized
INFO - 2024-10-04 15:22:35 --> Language Class Initialized
INFO - 2024-10-04 15:22:35 --> Config Class Initialized
INFO - 2024-10-04 15:22:35 --> Loader Class Initialized
INFO - 2024-10-04 15:22:35 --> Helper loaded: url_helper
INFO - 2024-10-04 15:22:35 --> Helper loaded: file_helper
INFO - 2024-10-04 15:22:35 --> Helper loaded: form_helper
INFO - 2024-10-04 15:22:35 --> Helper loaded: my_helper
INFO - 2024-10-04 15:22:35 --> Database Driver Class Initialized
INFO - 2024-10-04 15:22:35 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-04 15:22:35 --> Controller Class Initialized
INFO - 2024-10-04 15:22:35 --> Final output sent to browser
DEBUG - 2024-10-04 15:22:35 --> Total execution time: 0.0698
INFO - 2024-10-04 15:24:39 --> Config Class Initialized
INFO - 2024-10-04 15:24:39 --> Hooks Class Initialized
DEBUG - 2024-10-04 15:24:39 --> UTF-8 Support Enabled
INFO - 2024-10-04 15:24:39 --> Utf8 Class Initialized
INFO - 2024-10-04 15:24:39 --> URI Class Initialized
INFO - 2024-10-04 15:24:39 --> Router Class Initialized
INFO - 2024-10-04 15:24:39 --> Output Class Initialized
INFO - 2024-10-04 15:24:39 --> Security Class Initialized
DEBUG - 2024-10-04 15:24:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-04 15:24:39 --> Input Class Initialized
INFO - 2024-10-04 15:24:39 --> Language Class Initialized
INFO - 2024-10-04 15:24:39 --> Language Class Initialized
INFO - 2024-10-04 15:24:39 --> Config Class Initialized
INFO - 2024-10-04 15:24:39 --> Loader Class Initialized
INFO - 2024-10-04 15:24:39 --> Helper loaded: url_helper
INFO - 2024-10-04 15:24:39 --> Helper loaded: file_helper
INFO - 2024-10-04 15:24:39 --> Helper loaded: form_helper
INFO - 2024-10-04 15:24:39 --> Helper loaded: my_helper
INFO - 2024-10-04 15:24:39 --> Database Driver Class Initialized
INFO - 2024-10-04 15:24:39 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-04 15:24:39 --> Controller Class Initialized
INFO - 2024-10-04 15:24:39 --> Final output sent to browser
DEBUG - 2024-10-04 15:24:39 --> Total execution time: 0.0310
INFO - 2024-10-04 15:25:58 --> Config Class Initialized
INFO - 2024-10-04 15:25:58 --> Hooks Class Initialized
DEBUG - 2024-10-04 15:25:58 --> UTF-8 Support Enabled
INFO - 2024-10-04 15:25:58 --> Utf8 Class Initialized
INFO - 2024-10-04 15:25:58 --> URI Class Initialized
INFO - 2024-10-04 15:25:58 --> Router Class Initialized
INFO - 2024-10-04 15:25:58 --> Output Class Initialized
INFO - 2024-10-04 15:25:58 --> Security Class Initialized
DEBUG - 2024-10-04 15:25:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-04 15:25:58 --> Input Class Initialized
INFO - 2024-10-04 15:25:58 --> Language Class Initialized
INFO - 2024-10-04 15:25:58 --> Language Class Initialized
INFO - 2024-10-04 15:25:58 --> Config Class Initialized
INFO - 2024-10-04 15:25:58 --> Loader Class Initialized
INFO - 2024-10-04 15:25:58 --> Helper loaded: url_helper
INFO - 2024-10-04 15:25:58 --> Helper loaded: file_helper
INFO - 2024-10-04 15:25:58 --> Helper loaded: form_helper
INFO - 2024-10-04 15:25:58 --> Helper loaded: my_helper
INFO - 2024-10-04 15:25:58 --> Database Driver Class Initialized
INFO - 2024-10-04 15:25:58 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-04 15:25:58 --> Controller Class Initialized
INFO - 2024-10-04 15:25:58 --> Final output sent to browser
DEBUG - 2024-10-04 15:25:58 --> Total execution time: 0.0347
INFO - 2024-10-04 15:25:58 --> Config Class Initialized
INFO - 2024-10-04 15:25:58 --> Hooks Class Initialized
DEBUG - 2024-10-04 15:25:58 --> UTF-8 Support Enabled
INFO - 2024-10-04 15:25:58 --> Utf8 Class Initialized
INFO - 2024-10-04 15:25:58 --> URI Class Initialized
INFO - 2024-10-04 15:25:58 --> Router Class Initialized
INFO - 2024-10-04 15:25:58 --> Output Class Initialized
INFO - 2024-10-04 15:25:58 --> Security Class Initialized
DEBUG - 2024-10-04 15:25:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-04 15:25:58 --> Input Class Initialized
INFO - 2024-10-04 15:25:58 --> Language Class Initialized
INFO - 2024-10-04 15:25:58 --> Language Class Initialized
INFO - 2024-10-04 15:25:58 --> Config Class Initialized
INFO - 2024-10-04 15:25:58 --> Loader Class Initialized
INFO - 2024-10-04 15:25:58 --> Helper loaded: url_helper
INFO - 2024-10-04 15:25:58 --> Helper loaded: file_helper
INFO - 2024-10-04 15:25:58 --> Helper loaded: form_helper
INFO - 2024-10-04 15:25:58 --> Helper loaded: my_helper
INFO - 2024-10-04 15:25:58 --> Database Driver Class Initialized
INFO - 2024-10-04 15:25:58 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-04 15:25:58 --> Controller Class Initialized
INFO - 2024-10-04 15:26:07 --> Config Class Initialized
INFO - 2024-10-04 15:26:07 --> Hooks Class Initialized
DEBUG - 2024-10-04 15:26:07 --> UTF-8 Support Enabled
INFO - 2024-10-04 15:26:07 --> Utf8 Class Initialized
INFO - 2024-10-04 15:26:07 --> URI Class Initialized
INFO - 2024-10-04 15:26:07 --> Router Class Initialized
INFO - 2024-10-04 15:26:07 --> Output Class Initialized
INFO - 2024-10-04 15:26:07 --> Security Class Initialized
DEBUG - 2024-10-04 15:26:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-04 15:26:07 --> Input Class Initialized
INFO - 2024-10-04 15:26:07 --> Language Class Initialized
INFO - 2024-10-04 15:26:07 --> Language Class Initialized
INFO - 2024-10-04 15:26:07 --> Config Class Initialized
INFO - 2024-10-04 15:26:07 --> Loader Class Initialized
INFO - 2024-10-04 15:26:07 --> Helper loaded: url_helper
INFO - 2024-10-04 15:26:07 --> Helper loaded: file_helper
INFO - 2024-10-04 15:26:07 --> Helper loaded: form_helper
INFO - 2024-10-04 15:26:07 --> Helper loaded: my_helper
INFO - 2024-10-04 15:26:07 --> Database Driver Class Initialized
INFO - 2024-10-04 15:26:07 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-04 15:26:07 --> Controller Class Initialized
INFO - 2024-10-04 15:26:07 --> Final output sent to browser
DEBUG - 2024-10-04 15:26:07 --> Total execution time: 0.0274
INFO - 2024-10-04 15:26:17 --> Config Class Initialized
INFO - 2024-10-04 15:26:17 --> Hooks Class Initialized
DEBUG - 2024-10-04 15:26:17 --> UTF-8 Support Enabled
INFO - 2024-10-04 15:26:17 --> Utf8 Class Initialized
INFO - 2024-10-04 15:26:17 --> URI Class Initialized
INFO - 2024-10-04 15:26:17 --> Router Class Initialized
INFO - 2024-10-04 15:26:17 --> Output Class Initialized
INFO - 2024-10-04 15:26:17 --> Security Class Initialized
DEBUG - 2024-10-04 15:26:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-04 15:26:17 --> Input Class Initialized
INFO - 2024-10-04 15:26:17 --> Language Class Initialized
INFO - 2024-10-04 15:26:17 --> Language Class Initialized
INFO - 2024-10-04 15:26:17 --> Config Class Initialized
INFO - 2024-10-04 15:26:17 --> Loader Class Initialized
INFO - 2024-10-04 15:26:17 --> Helper loaded: url_helper
INFO - 2024-10-04 15:26:17 --> Helper loaded: file_helper
INFO - 2024-10-04 15:26:17 --> Helper loaded: form_helper
INFO - 2024-10-04 15:26:17 --> Helper loaded: my_helper
INFO - 2024-10-04 15:26:17 --> Database Driver Class Initialized
INFO - 2024-10-04 15:26:17 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-04 15:26:17 --> Controller Class Initialized
INFO - 2024-10-04 15:26:17 --> Final output sent to browser
DEBUG - 2024-10-04 15:26:17 --> Total execution time: 0.0749
INFO - 2024-10-04 15:26:17 --> Config Class Initialized
INFO - 2024-10-04 15:26:17 --> Hooks Class Initialized
DEBUG - 2024-10-04 15:26:17 --> UTF-8 Support Enabled
INFO - 2024-10-04 15:26:17 --> Utf8 Class Initialized
INFO - 2024-10-04 15:26:17 --> URI Class Initialized
INFO - 2024-10-04 15:26:17 --> Router Class Initialized
INFO - 2024-10-04 15:26:17 --> Output Class Initialized
INFO - 2024-10-04 15:26:17 --> Security Class Initialized
DEBUG - 2024-10-04 15:26:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-04 15:26:17 --> Input Class Initialized
INFO - 2024-10-04 15:26:17 --> Language Class Initialized
INFO - 2024-10-04 15:26:17 --> Language Class Initialized
INFO - 2024-10-04 15:26:17 --> Config Class Initialized
INFO - 2024-10-04 15:26:17 --> Loader Class Initialized
INFO - 2024-10-04 15:26:17 --> Helper loaded: url_helper
INFO - 2024-10-04 15:26:17 --> Helper loaded: file_helper
INFO - 2024-10-04 15:26:17 --> Helper loaded: form_helper
INFO - 2024-10-04 15:26:17 --> Helper loaded: my_helper
INFO - 2024-10-04 15:26:17 --> Database Driver Class Initialized
INFO - 2024-10-04 15:26:17 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-04 15:26:17 --> Controller Class Initialized
INFO - 2024-10-04 15:26:28 --> Config Class Initialized
INFO - 2024-10-04 15:26:28 --> Hooks Class Initialized
DEBUG - 2024-10-04 15:26:28 --> UTF-8 Support Enabled
INFO - 2024-10-04 15:26:28 --> Utf8 Class Initialized
INFO - 2024-10-04 15:26:28 --> URI Class Initialized
INFO - 2024-10-04 15:26:28 --> Router Class Initialized
INFO - 2024-10-04 15:26:28 --> Output Class Initialized
INFO - 2024-10-04 15:26:28 --> Security Class Initialized
DEBUG - 2024-10-04 15:26:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-04 15:26:28 --> Input Class Initialized
INFO - 2024-10-04 15:26:28 --> Language Class Initialized
INFO - 2024-10-04 15:26:28 --> Language Class Initialized
INFO - 2024-10-04 15:26:28 --> Config Class Initialized
INFO - 2024-10-04 15:26:28 --> Loader Class Initialized
INFO - 2024-10-04 15:26:28 --> Helper loaded: url_helper
INFO - 2024-10-04 15:26:28 --> Helper loaded: file_helper
INFO - 2024-10-04 15:26:28 --> Helper loaded: form_helper
INFO - 2024-10-04 15:26:28 --> Helper loaded: my_helper
INFO - 2024-10-04 15:26:28 --> Database Driver Class Initialized
INFO - 2024-10-04 15:26:28 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-04 15:26:28 --> Controller Class Initialized
INFO - 2024-10-04 15:26:28 --> Final output sent to browser
DEBUG - 2024-10-04 15:26:28 --> Total execution time: 0.0616
INFO - 2024-10-04 15:26:36 --> Config Class Initialized
INFO - 2024-10-04 15:26:36 --> Hooks Class Initialized
DEBUG - 2024-10-04 15:26:36 --> UTF-8 Support Enabled
INFO - 2024-10-04 15:26:36 --> Utf8 Class Initialized
INFO - 2024-10-04 15:26:36 --> URI Class Initialized
INFO - 2024-10-04 15:26:36 --> Router Class Initialized
INFO - 2024-10-04 15:26:36 --> Output Class Initialized
INFO - 2024-10-04 15:26:36 --> Security Class Initialized
DEBUG - 2024-10-04 15:26:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-04 15:26:36 --> Input Class Initialized
INFO - 2024-10-04 15:26:36 --> Language Class Initialized
INFO - 2024-10-04 15:26:36 --> Language Class Initialized
INFO - 2024-10-04 15:26:36 --> Config Class Initialized
INFO - 2024-10-04 15:26:36 --> Loader Class Initialized
INFO - 2024-10-04 15:26:36 --> Helper loaded: url_helper
INFO - 2024-10-04 15:26:36 --> Helper loaded: file_helper
INFO - 2024-10-04 15:26:36 --> Helper loaded: form_helper
INFO - 2024-10-04 15:26:36 --> Helper loaded: my_helper
INFO - 2024-10-04 15:26:36 --> Database Driver Class Initialized
INFO - 2024-10-04 15:26:36 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-04 15:26:36 --> Controller Class Initialized
INFO - 2024-10-04 15:26:36 --> Final output sent to browser
DEBUG - 2024-10-04 15:26:36 --> Total execution time: 0.0313
INFO - 2024-10-04 15:26:36 --> Config Class Initialized
INFO - 2024-10-04 15:26:36 --> Hooks Class Initialized
DEBUG - 2024-10-04 15:26:36 --> UTF-8 Support Enabled
INFO - 2024-10-04 15:26:36 --> Utf8 Class Initialized
INFO - 2024-10-04 15:26:36 --> URI Class Initialized
INFO - 2024-10-04 15:26:36 --> Router Class Initialized
INFO - 2024-10-04 15:26:36 --> Output Class Initialized
INFO - 2024-10-04 15:26:36 --> Security Class Initialized
DEBUG - 2024-10-04 15:26:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-04 15:26:36 --> Input Class Initialized
INFO - 2024-10-04 15:26:36 --> Language Class Initialized
INFO - 2024-10-04 15:26:36 --> Language Class Initialized
INFO - 2024-10-04 15:26:36 --> Config Class Initialized
INFO - 2024-10-04 15:26:36 --> Loader Class Initialized
INFO - 2024-10-04 15:26:36 --> Helper loaded: url_helper
INFO - 2024-10-04 15:26:36 --> Helper loaded: file_helper
INFO - 2024-10-04 15:26:36 --> Helper loaded: form_helper
INFO - 2024-10-04 15:26:36 --> Helper loaded: my_helper
INFO - 2024-10-04 15:26:36 --> Database Driver Class Initialized
INFO - 2024-10-04 15:26:36 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-04 15:26:36 --> Controller Class Initialized
INFO - 2024-10-04 15:26:48 --> Config Class Initialized
INFO - 2024-10-04 15:26:48 --> Hooks Class Initialized
DEBUG - 2024-10-04 15:26:48 --> UTF-8 Support Enabled
INFO - 2024-10-04 15:26:48 --> Utf8 Class Initialized
INFO - 2024-10-04 15:26:48 --> URI Class Initialized
INFO - 2024-10-04 15:26:48 --> Router Class Initialized
INFO - 2024-10-04 15:26:48 --> Output Class Initialized
INFO - 2024-10-04 15:26:48 --> Security Class Initialized
DEBUG - 2024-10-04 15:26:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-04 15:26:48 --> Input Class Initialized
INFO - 2024-10-04 15:26:48 --> Language Class Initialized
INFO - 2024-10-04 15:26:48 --> Language Class Initialized
INFO - 2024-10-04 15:26:48 --> Config Class Initialized
INFO - 2024-10-04 15:26:48 --> Loader Class Initialized
INFO - 2024-10-04 15:26:48 --> Helper loaded: url_helper
INFO - 2024-10-04 15:26:48 --> Helper loaded: file_helper
INFO - 2024-10-04 15:26:48 --> Helper loaded: form_helper
INFO - 2024-10-04 15:26:48 --> Helper loaded: my_helper
INFO - 2024-10-04 15:26:49 --> Database Driver Class Initialized
INFO - 2024-10-04 15:26:49 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-04 15:26:49 --> Controller Class Initialized
INFO - 2024-10-04 15:26:49 --> Final output sent to browser
DEBUG - 2024-10-04 15:26:49 --> Total execution time: 0.0633
INFO - 2024-10-04 15:26:57 --> Config Class Initialized
INFO - 2024-10-04 15:26:57 --> Hooks Class Initialized
DEBUG - 2024-10-04 15:26:58 --> UTF-8 Support Enabled
INFO - 2024-10-04 15:26:58 --> Utf8 Class Initialized
INFO - 2024-10-04 15:26:58 --> URI Class Initialized
INFO - 2024-10-04 15:26:58 --> Router Class Initialized
INFO - 2024-10-04 15:26:58 --> Output Class Initialized
INFO - 2024-10-04 15:26:58 --> Security Class Initialized
DEBUG - 2024-10-04 15:26:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-04 15:26:58 --> Input Class Initialized
INFO - 2024-10-04 15:26:58 --> Language Class Initialized
INFO - 2024-10-04 15:26:58 --> Language Class Initialized
INFO - 2024-10-04 15:26:58 --> Config Class Initialized
INFO - 2024-10-04 15:26:58 --> Loader Class Initialized
INFO - 2024-10-04 15:26:58 --> Helper loaded: url_helper
INFO - 2024-10-04 15:26:58 --> Helper loaded: file_helper
INFO - 2024-10-04 15:26:58 --> Helper loaded: form_helper
INFO - 2024-10-04 15:26:58 --> Helper loaded: my_helper
INFO - 2024-10-04 15:26:58 --> Database Driver Class Initialized
INFO - 2024-10-04 15:26:58 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-04 15:26:58 --> Controller Class Initialized
INFO - 2024-10-04 15:26:58 --> Final output sent to browser
DEBUG - 2024-10-04 15:26:58 --> Total execution time: 0.0929
INFO - 2024-10-04 15:26:58 --> Config Class Initialized
INFO - 2024-10-04 15:26:58 --> Hooks Class Initialized
DEBUG - 2024-10-04 15:26:58 --> UTF-8 Support Enabled
INFO - 2024-10-04 15:26:58 --> Utf8 Class Initialized
INFO - 2024-10-04 15:26:58 --> URI Class Initialized
INFO - 2024-10-04 15:26:58 --> Router Class Initialized
INFO - 2024-10-04 15:26:58 --> Output Class Initialized
INFO - 2024-10-04 15:26:58 --> Security Class Initialized
DEBUG - 2024-10-04 15:26:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-04 15:26:58 --> Input Class Initialized
INFO - 2024-10-04 15:26:58 --> Language Class Initialized
INFO - 2024-10-04 15:26:58 --> Language Class Initialized
INFO - 2024-10-04 15:26:58 --> Config Class Initialized
INFO - 2024-10-04 15:26:58 --> Loader Class Initialized
INFO - 2024-10-04 15:26:58 --> Helper loaded: url_helper
INFO - 2024-10-04 15:26:58 --> Helper loaded: file_helper
INFO - 2024-10-04 15:26:58 --> Helper loaded: form_helper
INFO - 2024-10-04 15:26:58 --> Helper loaded: my_helper
INFO - 2024-10-04 15:26:58 --> Database Driver Class Initialized
INFO - 2024-10-04 15:26:58 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-04 15:26:58 --> Controller Class Initialized
INFO - 2024-10-04 15:28:11 --> Config Class Initialized
INFO - 2024-10-04 15:28:11 --> Hooks Class Initialized
DEBUG - 2024-10-04 15:28:11 --> UTF-8 Support Enabled
INFO - 2024-10-04 15:28:11 --> Utf8 Class Initialized
INFO - 2024-10-04 15:28:11 --> URI Class Initialized
INFO - 2024-10-04 15:28:11 --> Router Class Initialized
INFO - 2024-10-04 15:28:11 --> Output Class Initialized
INFO - 2024-10-04 15:28:11 --> Security Class Initialized
DEBUG - 2024-10-04 15:28:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-04 15:28:11 --> Input Class Initialized
INFO - 2024-10-04 15:28:11 --> Language Class Initialized
INFO - 2024-10-04 15:28:11 --> Language Class Initialized
INFO - 2024-10-04 15:28:11 --> Config Class Initialized
INFO - 2024-10-04 15:28:11 --> Loader Class Initialized
INFO - 2024-10-04 15:28:11 --> Helper loaded: url_helper
INFO - 2024-10-04 15:28:11 --> Helper loaded: file_helper
INFO - 2024-10-04 15:28:11 --> Helper loaded: form_helper
INFO - 2024-10-04 15:28:11 --> Helper loaded: my_helper
INFO - 2024-10-04 15:28:11 --> Database Driver Class Initialized
INFO - 2024-10-04 15:28:11 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-04 15:28:11 --> Controller Class Initialized
INFO - 2024-10-04 15:28:11 --> Final output sent to browser
DEBUG - 2024-10-04 15:28:11 --> Total execution time: 0.0297
INFO - 2024-10-04 15:28:19 --> Config Class Initialized
INFO - 2024-10-04 15:28:19 --> Hooks Class Initialized
DEBUG - 2024-10-04 15:28:19 --> UTF-8 Support Enabled
INFO - 2024-10-04 15:28:19 --> Utf8 Class Initialized
INFO - 2024-10-04 15:28:19 --> URI Class Initialized
INFO - 2024-10-04 15:28:19 --> Router Class Initialized
INFO - 2024-10-04 15:28:19 --> Output Class Initialized
INFO - 2024-10-04 15:28:19 --> Security Class Initialized
DEBUG - 2024-10-04 15:28:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-04 15:28:19 --> Input Class Initialized
INFO - 2024-10-04 15:28:19 --> Language Class Initialized
INFO - 2024-10-04 15:28:19 --> Language Class Initialized
INFO - 2024-10-04 15:28:19 --> Config Class Initialized
INFO - 2024-10-04 15:28:19 --> Loader Class Initialized
INFO - 2024-10-04 15:28:19 --> Helper loaded: url_helper
INFO - 2024-10-04 15:28:19 --> Helper loaded: file_helper
INFO - 2024-10-04 15:28:19 --> Helper loaded: form_helper
INFO - 2024-10-04 15:28:19 --> Helper loaded: my_helper
INFO - 2024-10-04 15:28:19 --> Database Driver Class Initialized
INFO - 2024-10-04 15:28:19 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-04 15:28:19 --> Controller Class Initialized
INFO - 2024-10-04 15:28:19 --> Final output sent to browser
DEBUG - 2024-10-04 15:28:19 --> Total execution time: 0.0305
INFO - 2024-10-04 15:28:19 --> Config Class Initialized
INFO - 2024-10-04 15:28:19 --> Hooks Class Initialized
DEBUG - 2024-10-04 15:28:19 --> UTF-8 Support Enabled
INFO - 2024-10-04 15:28:19 --> Utf8 Class Initialized
INFO - 2024-10-04 15:28:19 --> URI Class Initialized
INFO - 2024-10-04 15:28:19 --> Router Class Initialized
INFO - 2024-10-04 15:28:19 --> Output Class Initialized
INFO - 2024-10-04 15:28:19 --> Security Class Initialized
DEBUG - 2024-10-04 15:28:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-04 15:28:19 --> Input Class Initialized
INFO - 2024-10-04 15:28:19 --> Language Class Initialized
INFO - 2024-10-04 15:28:19 --> Language Class Initialized
INFO - 2024-10-04 15:28:19 --> Config Class Initialized
INFO - 2024-10-04 15:28:19 --> Loader Class Initialized
INFO - 2024-10-04 15:28:19 --> Helper loaded: url_helper
INFO - 2024-10-04 15:28:19 --> Helper loaded: file_helper
INFO - 2024-10-04 15:28:19 --> Helper loaded: form_helper
INFO - 2024-10-04 15:28:19 --> Helper loaded: my_helper
INFO - 2024-10-04 15:28:19 --> Database Driver Class Initialized
INFO - 2024-10-04 15:28:19 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-04 15:28:19 --> Controller Class Initialized
INFO - 2024-10-04 15:28:30 --> Config Class Initialized
INFO - 2024-10-04 15:28:30 --> Hooks Class Initialized
DEBUG - 2024-10-04 15:28:30 --> UTF-8 Support Enabled
INFO - 2024-10-04 15:28:30 --> Utf8 Class Initialized
INFO - 2024-10-04 15:28:30 --> URI Class Initialized
INFO - 2024-10-04 15:28:30 --> Router Class Initialized
INFO - 2024-10-04 15:28:30 --> Output Class Initialized
INFO - 2024-10-04 15:28:30 --> Security Class Initialized
DEBUG - 2024-10-04 15:28:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-04 15:28:30 --> Input Class Initialized
INFO - 2024-10-04 15:28:30 --> Language Class Initialized
INFO - 2024-10-04 15:28:30 --> Language Class Initialized
INFO - 2024-10-04 15:28:30 --> Config Class Initialized
INFO - 2024-10-04 15:28:30 --> Loader Class Initialized
INFO - 2024-10-04 15:28:30 --> Helper loaded: url_helper
INFO - 2024-10-04 15:28:30 --> Helper loaded: file_helper
INFO - 2024-10-04 15:28:30 --> Helper loaded: form_helper
INFO - 2024-10-04 15:28:30 --> Helper loaded: my_helper
INFO - 2024-10-04 15:28:30 --> Database Driver Class Initialized
INFO - 2024-10-04 15:28:30 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-04 15:28:30 --> Controller Class Initialized
INFO - 2024-10-04 15:28:30 --> Final output sent to browser
DEBUG - 2024-10-04 15:28:30 --> Total execution time: 0.0267
INFO - 2024-10-04 15:28:37 --> Config Class Initialized
INFO - 2024-10-04 15:28:37 --> Hooks Class Initialized
DEBUG - 2024-10-04 15:28:37 --> UTF-8 Support Enabled
INFO - 2024-10-04 15:28:37 --> Utf8 Class Initialized
INFO - 2024-10-04 15:28:37 --> URI Class Initialized
INFO - 2024-10-04 15:28:37 --> Router Class Initialized
INFO - 2024-10-04 15:28:37 --> Output Class Initialized
INFO - 2024-10-04 15:28:37 --> Security Class Initialized
DEBUG - 2024-10-04 15:28:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-04 15:28:37 --> Input Class Initialized
INFO - 2024-10-04 15:28:37 --> Language Class Initialized
INFO - 2024-10-04 15:28:37 --> Language Class Initialized
INFO - 2024-10-04 15:28:37 --> Config Class Initialized
INFO - 2024-10-04 15:28:37 --> Loader Class Initialized
INFO - 2024-10-04 15:28:37 --> Helper loaded: url_helper
INFO - 2024-10-04 15:28:37 --> Helper loaded: file_helper
INFO - 2024-10-04 15:28:37 --> Helper loaded: form_helper
INFO - 2024-10-04 15:28:37 --> Helper loaded: my_helper
INFO - 2024-10-04 15:28:37 --> Database Driver Class Initialized
INFO - 2024-10-04 15:28:37 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-04 15:28:37 --> Controller Class Initialized
INFO - 2024-10-04 15:28:37 --> Final output sent to browser
DEBUG - 2024-10-04 15:28:37 --> Total execution time: 0.0331
INFO - 2024-10-04 15:28:37 --> Config Class Initialized
INFO - 2024-10-04 15:28:37 --> Hooks Class Initialized
DEBUG - 2024-10-04 15:28:37 --> UTF-8 Support Enabled
INFO - 2024-10-04 15:28:37 --> Utf8 Class Initialized
INFO - 2024-10-04 15:28:37 --> URI Class Initialized
INFO - 2024-10-04 15:28:37 --> Router Class Initialized
INFO - 2024-10-04 15:28:37 --> Output Class Initialized
INFO - 2024-10-04 15:28:37 --> Security Class Initialized
DEBUG - 2024-10-04 15:28:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-04 15:28:37 --> Input Class Initialized
INFO - 2024-10-04 15:28:37 --> Language Class Initialized
INFO - 2024-10-04 15:28:37 --> Language Class Initialized
INFO - 2024-10-04 15:28:37 --> Config Class Initialized
INFO - 2024-10-04 15:28:37 --> Loader Class Initialized
INFO - 2024-10-04 15:28:37 --> Helper loaded: url_helper
INFO - 2024-10-04 15:28:37 --> Helper loaded: file_helper
INFO - 2024-10-04 15:28:37 --> Helper loaded: form_helper
INFO - 2024-10-04 15:28:37 --> Helper loaded: my_helper
INFO - 2024-10-04 15:28:37 --> Database Driver Class Initialized
INFO - 2024-10-04 15:28:37 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-04 15:28:37 --> Controller Class Initialized
INFO - 2024-10-04 15:28:45 --> Config Class Initialized
INFO - 2024-10-04 15:28:45 --> Hooks Class Initialized
DEBUG - 2024-10-04 15:28:45 --> UTF-8 Support Enabled
INFO - 2024-10-04 15:28:45 --> Utf8 Class Initialized
INFO - 2024-10-04 15:28:45 --> URI Class Initialized
INFO - 2024-10-04 15:28:45 --> Router Class Initialized
INFO - 2024-10-04 15:28:45 --> Output Class Initialized
INFO - 2024-10-04 15:28:45 --> Security Class Initialized
DEBUG - 2024-10-04 15:28:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-04 15:28:45 --> Input Class Initialized
INFO - 2024-10-04 15:28:45 --> Language Class Initialized
INFO - 2024-10-04 15:28:45 --> Language Class Initialized
INFO - 2024-10-04 15:28:45 --> Config Class Initialized
INFO - 2024-10-04 15:28:45 --> Loader Class Initialized
INFO - 2024-10-04 15:28:45 --> Helper loaded: url_helper
INFO - 2024-10-04 15:28:45 --> Helper loaded: file_helper
INFO - 2024-10-04 15:28:45 --> Helper loaded: form_helper
INFO - 2024-10-04 15:28:45 --> Helper loaded: my_helper
INFO - 2024-10-04 15:28:45 --> Database Driver Class Initialized
INFO - 2024-10-04 15:28:45 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-04 15:28:45 --> Controller Class Initialized
INFO - 2024-10-04 15:28:45 --> Final output sent to browser
DEBUG - 2024-10-04 15:28:45 --> Total execution time: 0.0563
INFO - 2024-10-04 15:28:51 --> Config Class Initialized
INFO - 2024-10-04 15:28:51 --> Hooks Class Initialized
DEBUG - 2024-10-04 15:28:51 --> UTF-8 Support Enabled
INFO - 2024-10-04 15:28:51 --> Utf8 Class Initialized
INFO - 2024-10-04 15:28:51 --> URI Class Initialized
INFO - 2024-10-04 15:28:51 --> Router Class Initialized
INFO - 2024-10-04 15:28:51 --> Output Class Initialized
INFO - 2024-10-04 15:28:51 --> Security Class Initialized
DEBUG - 2024-10-04 15:28:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-04 15:28:51 --> Input Class Initialized
INFO - 2024-10-04 15:28:51 --> Language Class Initialized
INFO - 2024-10-04 15:28:51 --> Language Class Initialized
INFO - 2024-10-04 15:28:51 --> Config Class Initialized
INFO - 2024-10-04 15:28:51 --> Loader Class Initialized
INFO - 2024-10-04 15:28:51 --> Helper loaded: url_helper
INFO - 2024-10-04 15:28:51 --> Helper loaded: file_helper
INFO - 2024-10-04 15:28:51 --> Helper loaded: form_helper
INFO - 2024-10-04 15:28:51 --> Helper loaded: my_helper
INFO - 2024-10-04 15:28:51 --> Database Driver Class Initialized
INFO - 2024-10-04 15:28:51 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-04 15:28:51 --> Controller Class Initialized
DEBUG - 2024-10-04 15:28:51 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/view_mapel/views/v_view_mapel.php
DEBUG - 2024-10-04 15:28:51 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-10-04 15:28:51 --> Final output sent to browser
DEBUG - 2024-10-04 15:28:51 --> Total execution time: 0.0468
INFO - 2024-10-04 15:28:54 --> Config Class Initialized
INFO - 2024-10-04 15:28:54 --> Hooks Class Initialized
DEBUG - 2024-10-04 15:28:54 --> UTF-8 Support Enabled
INFO - 2024-10-04 15:28:54 --> Utf8 Class Initialized
INFO - 2024-10-04 15:28:54 --> URI Class Initialized
INFO - 2024-10-04 15:28:54 --> Router Class Initialized
INFO - 2024-10-04 15:28:54 --> Output Class Initialized
INFO - 2024-10-04 15:28:54 --> Security Class Initialized
DEBUG - 2024-10-04 15:28:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-04 15:28:54 --> Input Class Initialized
INFO - 2024-10-04 15:28:54 --> Language Class Initialized
INFO - 2024-10-04 15:28:54 --> Language Class Initialized
INFO - 2024-10-04 15:28:54 --> Config Class Initialized
INFO - 2024-10-04 15:28:54 --> Loader Class Initialized
INFO - 2024-10-04 15:28:54 --> Helper loaded: url_helper
INFO - 2024-10-04 15:28:54 --> Helper loaded: file_helper
INFO - 2024-10-04 15:28:54 --> Helper loaded: form_helper
INFO - 2024-10-04 15:28:54 --> Helper loaded: my_helper
INFO - 2024-10-04 15:28:54 --> Database Driver Class Initialized
INFO - 2024-10-04 15:28:54 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-04 15:28:54 --> Controller Class Initialized
DEBUG - 2024-10-04 15:28:54 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_catatan_guru/views/list.php
DEBUG - 2024-10-04 15:28:54 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-10-04 15:28:54 --> Final output sent to browser
DEBUG - 2024-10-04 15:28:54 --> Total execution time: 0.0355
INFO - 2024-10-04 15:28:57 --> Config Class Initialized
INFO - 2024-10-04 15:28:57 --> Hooks Class Initialized
DEBUG - 2024-10-04 15:28:57 --> UTF-8 Support Enabled
INFO - 2024-10-04 15:28:57 --> Utf8 Class Initialized
INFO - 2024-10-04 15:28:57 --> URI Class Initialized
INFO - 2024-10-04 15:28:57 --> Router Class Initialized
INFO - 2024-10-04 15:28:57 --> Output Class Initialized
INFO - 2024-10-04 15:28:57 --> Security Class Initialized
DEBUG - 2024-10-04 15:28:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-04 15:28:57 --> Input Class Initialized
INFO - 2024-10-04 15:28:57 --> Language Class Initialized
INFO - 2024-10-04 15:28:57 --> Language Class Initialized
INFO - 2024-10-04 15:28:57 --> Config Class Initialized
INFO - 2024-10-04 15:28:57 --> Loader Class Initialized
INFO - 2024-10-04 15:28:57 --> Helper loaded: url_helper
INFO - 2024-10-04 15:28:57 --> Helper loaded: file_helper
INFO - 2024-10-04 15:28:57 --> Helper loaded: form_helper
INFO - 2024-10-04 15:28:57 --> Helper loaded: my_helper
INFO - 2024-10-04 15:28:57 --> Database Driver Class Initialized
INFO - 2024-10-04 15:28:57 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-04 15:28:57 --> Controller Class Initialized
INFO - 2024-10-04 15:28:57 --> Final output sent to browser
DEBUG - 2024-10-04 15:28:57 --> Total execution time: 0.0504
INFO - 2024-10-04 15:33:31 --> Config Class Initialized
INFO - 2024-10-04 15:33:31 --> Hooks Class Initialized
DEBUG - 2024-10-04 15:33:31 --> UTF-8 Support Enabled
INFO - 2024-10-04 15:33:31 --> Utf8 Class Initialized
INFO - 2024-10-04 15:33:31 --> URI Class Initialized
INFO - 2024-10-04 15:33:31 --> Router Class Initialized
INFO - 2024-10-04 15:33:31 --> Output Class Initialized
INFO - 2024-10-04 15:33:31 --> Security Class Initialized
DEBUG - 2024-10-04 15:33:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-04 15:33:31 --> Input Class Initialized
INFO - 2024-10-04 15:33:31 --> Language Class Initialized
INFO - 2024-10-04 15:33:31 --> Language Class Initialized
INFO - 2024-10-04 15:33:31 --> Config Class Initialized
INFO - 2024-10-04 15:33:31 --> Loader Class Initialized
INFO - 2024-10-04 15:33:31 --> Helper loaded: url_helper
INFO - 2024-10-04 15:33:31 --> Helper loaded: file_helper
INFO - 2024-10-04 15:33:31 --> Helper loaded: form_helper
INFO - 2024-10-04 15:33:31 --> Helper loaded: my_helper
INFO - 2024-10-04 15:33:31 --> Database Driver Class Initialized
INFO - 2024-10-04 15:33:31 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-04 15:33:31 --> Controller Class Initialized
INFO - 2024-10-04 15:33:31 --> Final output sent to browser
DEBUG - 2024-10-04 15:33:31 --> Total execution time: 0.0632
INFO - 2024-10-04 15:33:48 --> Config Class Initialized
INFO - 2024-10-04 15:33:48 --> Hooks Class Initialized
DEBUG - 2024-10-04 15:33:48 --> UTF-8 Support Enabled
INFO - 2024-10-04 15:33:48 --> Utf8 Class Initialized
INFO - 2024-10-04 15:33:48 --> URI Class Initialized
INFO - 2024-10-04 15:33:48 --> Router Class Initialized
INFO - 2024-10-04 15:33:48 --> Output Class Initialized
INFO - 2024-10-04 15:33:48 --> Security Class Initialized
DEBUG - 2024-10-04 15:33:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-04 15:33:48 --> Input Class Initialized
INFO - 2024-10-04 15:33:48 --> Language Class Initialized
INFO - 2024-10-04 15:33:48 --> Language Class Initialized
INFO - 2024-10-04 15:33:48 --> Config Class Initialized
INFO - 2024-10-04 15:33:48 --> Loader Class Initialized
INFO - 2024-10-04 15:33:48 --> Helper loaded: url_helper
INFO - 2024-10-04 15:33:48 --> Helper loaded: file_helper
INFO - 2024-10-04 15:33:48 --> Helper loaded: form_helper
INFO - 2024-10-04 15:33:48 --> Helper loaded: my_helper
INFO - 2024-10-04 15:33:48 --> Database Driver Class Initialized
INFO - 2024-10-04 15:33:48 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-04 15:33:48 --> Controller Class Initialized
INFO - 2024-10-04 15:33:49 --> Final output sent to browser
DEBUG - 2024-10-04 15:33:49 --> Total execution time: 0.0955
INFO - 2024-10-04 15:33:49 --> Config Class Initialized
INFO - 2024-10-04 15:33:49 --> Hooks Class Initialized
DEBUG - 2024-10-04 15:33:49 --> UTF-8 Support Enabled
INFO - 2024-10-04 15:33:49 --> Utf8 Class Initialized
INFO - 2024-10-04 15:33:49 --> URI Class Initialized
INFO - 2024-10-04 15:33:49 --> Router Class Initialized
INFO - 2024-10-04 15:33:49 --> Output Class Initialized
INFO - 2024-10-04 15:33:49 --> Security Class Initialized
DEBUG - 2024-10-04 15:33:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-04 15:33:49 --> Input Class Initialized
INFO - 2024-10-04 15:33:49 --> Language Class Initialized
INFO - 2024-10-04 15:33:49 --> Language Class Initialized
INFO - 2024-10-04 15:33:49 --> Config Class Initialized
INFO - 2024-10-04 15:33:49 --> Loader Class Initialized
INFO - 2024-10-04 15:33:49 --> Helper loaded: url_helper
INFO - 2024-10-04 15:33:49 --> Helper loaded: file_helper
INFO - 2024-10-04 15:33:49 --> Helper loaded: form_helper
INFO - 2024-10-04 15:33:49 --> Helper loaded: my_helper
INFO - 2024-10-04 15:33:49 --> Database Driver Class Initialized
INFO - 2024-10-04 15:33:49 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-04 15:33:49 --> Controller Class Initialized
INFO - 2024-10-04 15:33:49 --> Final output sent to browser
DEBUG - 2024-10-04 15:33:49 --> Total execution time: 0.0835
INFO - 2024-10-04 15:34:02 --> Config Class Initialized
INFO - 2024-10-04 15:34:02 --> Hooks Class Initialized
DEBUG - 2024-10-04 15:34:02 --> UTF-8 Support Enabled
INFO - 2024-10-04 15:34:02 --> Utf8 Class Initialized
INFO - 2024-10-04 15:34:02 --> URI Class Initialized
INFO - 2024-10-04 15:34:02 --> Router Class Initialized
INFO - 2024-10-04 15:34:02 --> Output Class Initialized
INFO - 2024-10-04 15:34:02 --> Security Class Initialized
DEBUG - 2024-10-04 15:34:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-04 15:34:02 --> Input Class Initialized
INFO - 2024-10-04 15:34:02 --> Language Class Initialized
INFO - 2024-10-04 15:34:02 --> Language Class Initialized
INFO - 2024-10-04 15:34:02 --> Config Class Initialized
INFO - 2024-10-04 15:34:02 --> Loader Class Initialized
INFO - 2024-10-04 15:34:02 --> Helper loaded: url_helper
INFO - 2024-10-04 15:34:02 --> Helper loaded: file_helper
INFO - 2024-10-04 15:34:02 --> Helper loaded: form_helper
INFO - 2024-10-04 15:34:02 --> Helper loaded: my_helper
INFO - 2024-10-04 15:34:02 --> Database Driver Class Initialized
INFO - 2024-10-04 15:34:02 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-04 15:34:02 --> Controller Class Initialized
INFO - 2024-10-04 15:34:02 --> Final output sent to browser
DEBUG - 2024-10-04 15:34:02 --> Total execution time: 0.1076
INFO - 2024-10-04 15:34:04 --> Config Class Initialized
INFO - 2024-10-04 15:34:04 --> Hooks Class Initialized
DEBUG - 2024-10-04 15:34:04 --> UTF-8 Support Enabled
INFO - 2024-10-04 15:34:04 --> Utf8 Class Initialized
INFO - 2024-10-04 15:34:04 --> URI Class Initialized
INFO - 2024-10-04 15:34:04 --> Router Class Initialized
INFO - 2024-10-04 15:34:04 --> Output Class Initialized
INFO - 2024-10-04 15:34:04 --> Security Class Initialized
DEBUG - 2024-10-04 15:34:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-04 15:34:04 --> Input Class Initialized
INFO - 2024-10-04 15:34:04 --> Language Class Initialized
INFO - 2024-10-04 15:34:04 --> Language Class Initialized
INFO - 2024-10-04 15:34:04 --> Config Class Initialized
INFO - 2024-10-04 15:34:04 --> Loader Class Initialized
INFO - 2024-10-04 15:34:04 --> Helper loaded: url_helper
INFO - 2024-10-04 15:34:04 --> Helper loaded: file_helper
INFO - 2024-10-04 15:34:04 --> Helper loaded: form_helper
INFO - 2024-10-04 15:34:04 --> Helper loaded: my_helper
INFO - 2024-10-04 15:34:04 --> Database Driver Class Initialized
INFO - 2024-10-04 15:34:04 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-04 15:34:04 --> Controller Class Initialized
DEBUG - 2024-10-04 15:34:04 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/view_mapel/views/v_view_mapel.php
DEBUG - 2024-10-04 15:34:04 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-10-04 15:34:04 --> Final output sent to browser
DEBUG - 2024-10-04 15:34:04 --> Total execution time: 0.0318
INFO - 2024-10-04 15:49:11 --> Config Class Initialized
INFO - 2024-10-04 15:49:11 --> Hooks Class Initialized
DEBUG - 2024-10-04 15:49:11 --> UTF-8 Support Enabled
INFO - 2024-10-04 15:49:11 --> Utf8 Class Initialized
INFO - 2024-10-04 15:49:11 --> URI Class Initialized
INFO - 2024-10-04 15:49:11 --> Router Class Initialized
INFO - 2024-10-04 15:49:11 --> Output Class Initialized
INFO - 2024-10-04 15:49:11 --> Security Class Initialized
DEBUG - 2024-10-04 15:49:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-04 15:49:11 --> Input Class Initialized
INFO - 2024-10-04 15:49:11 --> Language Class Initialized
INFO - 2024-10-04 15:49:11 --> Language Class Initialized
INFO - 2024-10-04 15:49:11 --> Config Class Initialized
INFO - 2024-10-04 15:49:11 --> Loader Class Initialized
INFO - 2024-10-04 15:49:11 --> Helper loaded: url_helper
INFO - 2024-10-04 15:49:11 --> Helper loaded: file_helper
INFO - 2024-10-04 15:49:11 --> Helper loaded: form_helper
INFO - 2024-10-04 15:49:11 --> Helper loaded: my_helper
INFO - 2024-10-04 15:49:11 --> Database Driver Class Initialized
INFO - 2024-10-04 15:49:11 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-04 15:49:11 --> Controller Class Initialized
DEBUG - 2024-10-04 15:49:11 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_catatan_guru/views/list.php
DEBUG - 2024-10-04 15:49:11 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-10-04 15:49:11 --> Final output sent to browser
DEBUG - 2024-10-04 15:49:11 --> Total execution time: 0.3739
INFO - 2024-10-04 15:49:14 --> Config Class Initialized
INFO - 2024-10-04 15:49:14 --> Hooks Class Initialized
DEBUG - 2024-10-04 15:49:14 --> UTF-8 Support Enabled
INFO - 2024-10-04 15:49:14 --> Utf8 Class Initialized
INFO - 2024-10-04 15:49:14 --> URI Class Initialized
INFO - 2024-10-04 15:49:14 --> Router Class Initialized
INFO - 2024-10-04 15:49:14 --> Output Class Initialized
INFO - 2024-10-04 15:49:14 --> Security Class Initialized
DEBUG - 2024-10-04 15:49:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-04 15:49:14 --> Input Class Initialized
INFO - 2024-10-04 15:49:14 --> Language Class Initialized
INFO - 2024-10-04 15:49:14 --> Language Class Initialized
INFO - 2024-10-04 15:49:14 --> Config Class Initialized
INFO - 2024-10-04 15:49:14 --> Loader Class Initialized
INFO - 2024-10-04 15:49:14 --> Helper loaded: url_helper
INFO - 2024-10-04 15:49:14 --> Helper loaded: file_helper
INFO - 2024-10-04 15:49:14 --> Helper loaded: form_helper
INFO - 2024-10-04 15:49:14 --> Helper loaded: my_helper
INFO - 2024-10-04 15:49:14 --> Database Driver Class Initialized
INFO - 2024-10-04 15:49:14 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-04 15:49:14 --> Controller Class Initialized
INFO - 2024-10-04 15:49:14 --> Final output sent to browser
DEBUG - 2024-10-04 15:49:14 --> Total execution time: 0.0474
INFO - 2024-10-04 15:49:17 --> Config Class Initialized
INFO - 2024-10-04 15:49:17 --> Hooks Class Initialized
DEBUG - 2024-10-04 15:49:17 --> UTF-8 Support Enabled
INFO - 2024-10-04 15:49:17 --> Utf8 Class Initialized
INFO - 2024-10-04 15:49:17 --> URI Class Initialized
INFO - 2024-10-04 15:49:17 --> Router Class Initialized
INFO - 2024-10-04 15:49:17 --> Output Class Initialized
INFO - 2024-10-04 15:49:17 --> Security Class Initialized
DEBUG - 2024-10-04 15:49:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-04 15:49:17 --> Input Class Initialized
INFO - 2024-10-04 15:49:17 --> Language Class Initialized
INFO - 2024-10-04 15:49:17 --> Language Class Initialized
INFO - 2024-10-04 15:49:17 --> Config Class Initialized
INFO - 2024-10-04 15:49:17 --> Loader Class Initialized
INFO - 2024-10-04 15:49:17 --> Helper loaded: url_helper
INFO - 2024-10-04 15:49:17 --> Helper loaded: file_helper
INFO - 2024-10-04 15:49:17 --> Helper loaded: form_helper
INFO - 2024-10-04 15:49:17 --> Helper loaded: my_helper
INFO - 2024-10-04 15:49:17 --> Database Driver Class Initialized
INFO - 2024-10-04 15:49:17 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-04 15:49:17 --> Controller Class Initialized
DEBUG - 2024-10-04 15:49:17 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/view_mapel/views/v_view_mapel.php
DEBUG - 2024-10-04 15:49:17 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-10-04 15:49:17 --> Final output sent to browser
DEBUG - 2024-10-04 15:49:17 --> Total execution time: 0.0434
INFO - 2024-10-04 15:50:35 --> Config Class Initialized
INFO - 2024-10-04 15:50:35 --> Hooks Class Initialized
DEBUG - 2024-10-04 15:50:35 --> UTF-8 Support Enabled
INFO - 2024-10-04 15:50:35 --> Utf8 Class Initialized
INFO - 2024-10-04 15:50:35 --> URI Class Initialized
INFO - 2024-10-04 15:50:35 --> Router Class Initialized
INFO - 2024-10-04 15:50:35 --> Output Class Initialized
INFO - 2024-10-04 15:50:35 --> Security Class Initialized
DEBUG - 2024-10-04 15:50:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-04 15:50:35 --> Input Class Initialized
INFO - 2024-10-04 15:50:35 --> Language Class Initialized
INFO - 2024-10-04 15:50:35 --> Language Class Initialized
INFO - 2024-10-04 15:50:35 --> Config Class Initialized
INFO - 2024-10-04 15:50:35 --> Loader Class Initialized
INFO - 2024-10-04 15:50:35 --> Helper loaded: url_helper
INFO - 2024-10-04 15:50:35 --> Helper loaded: file_helper
INFO - 2024-10-04 15:50:35 --> Helper loaded: form_helper
INFO - 2024-10-04 15:50:35 --> Helper loaded: my_helper
INFO - 2024-10-04 15:50:35 --> Database Driver Class Initialized
INFO - 2024-10-04 15:50:35 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-04 15:50:35 --> Controller Class Initialized
DEBUG - 2024-10-04 15:50:35 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/views/list.php
DEBUG - 2024-10-04 15:50:35 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-10-04 15:50:35 --> Final output sent to browser
DEBUG - 2024-10-04 15:50:35 --> Total execution time: 0.0550
INFO - 2024-10-04 15:50:35 --> Config Class Initialized
INFO - 2024-10-04 15:50:35 --> Hooks Class Initialized
DEBUG - 2024-10-04 15:50:35 --> UTF-8 Support Enabled
INFO - 2024-10-04 15:50:35 --> Utf8 Class Initialized
INFO - 2024-10-04 15:50:35 --> URI Class Initialized
INFO - 2024-10-04 15:50:35 --> Router Class Initialized
INFO - 2024-10-04 15:50:35 --> Output Class Initialized
INFO - 2024-10-04 15:50:35 --> Security Class Initialized
DEBUG - 2024-10-04 15:50:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-04 15:50:35 --> Input Class Initialized
INFO - 2024-10-04 15:50:35 --> Language Class Initialized
INFO - 2024-10-04 15:50:35 --> Language Class Initialized
INFO - 2024-10-04 15:50:35 --> Config Class Initialized
INFO - 2024-10-04 15:50:35 --> Loader Class Initialized
INFO - 2024-10-04 15:50:35 --> Helper loaded: url_helper
INFO - 2024-10-04 15:50:35 --> Helper loaded: file_helper
INFO - 2024-10-04 15:50:35 --> Helper loaded: form_helper
INFO - 2024-10-04 15:50:35 --> Helper loaded: my_helper
INFO - 2024-10-04 15:50:35 --> Database Driver Class Initialized
INFO - 2024-10-04 15:50:35 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-04 15:50:35 --> Controller Class Initialized
INFO - 2024-10-04 15:50:50 --> Config Class Initialized
INFO - 2024-10-04 15:50:50 --> Hooks Class Initialized
DEBUG - 2024-10-04 15:50:50 --> UTF-8 Support Enabled
INFO - 2024-10-04 15:50:50 --> Utf8 Class Initialized
INFO - 2024-10-04 15:50:50 --> URI Class Initialized
INFO - 2024-10-04 15:50:50 --> Router Class Initialized
INFO - 2024-10-04 15:50:50 --> Output Class Initialized
INFO - 2024-10-04 15:50:50 --> Security Class Initialized
DEBUG - 2024-10-04 15:50:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-04 15:50:50 --> Input Class Initialized
INFO - 2024-10-04 15:50:50 --> Language Class Initialized
INFO - 2024-10-04 15:50:50 --> Language Class Initialized
INFO - 2024-10-04 15:50:50 --> Config Class Initialized
INFO - 2024-10-04 15:50:50 --> Loader Class Initialized
INFO - 2024-10-04 15:50:50 --> Helper loaded: url_helper
INFO - 2024-10-04 15:50:50 --> Helper loaded: file_helper
INFO - 2024-10-04 15:50:50 --> Helper loaded: form_helper
INFO - 2024-10-04 15:50:50 --> Helper loaded: my_helper
INFO - 2024-10-04 15:50:50 --> Database Driver Class Initialized
INFO - 2024-10-04 15:50:50 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-04 15:50:50 --> Controller Class Initialized
INFO - 2024-10-04 15:50:50 --> Final output sent to browser
DEBUG - 2024-10-04 15:50:50 --> Total execution time: 0.0327
INFO - 2024-10-04 15:51:19 --> Config Class Initialized
INFO - 2024-10-04 15:51:19 --> Hooks Class Initialized
DEBUG - 2024-10-04 15:51:19 --> UTF-8 Support Enabled
INFO - 2024-10-04 15:51:19 --> Utf8 Class Initialized
INFO - 2024-10-04 15:51:19 --> URI Class Initialized
INFO - 2024-10-04 15:51:19 --> Router Class Initialized
INFO - 2024-10-04 15:51:19 --> Output Class Initialized
INFO - 2024-10-04 15:51:19 --> Security Class Initialized
DEBUG - 2024-10-04 15:51:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-04 15:51:19 --> Input Class Initialized
INFO - 2024-10-04 15:51:19 --> Language Class Initialized
INFO - 2024-10-04 15:51:19 --> Language Class Initialized
INFO - 2024-10-04 15:51:19 --> Config Class Initialized
INFO - 2024-10-04 15:51:19 --> Loader Class Initialized
INFO - 2024-10-04 15:51:19 --> Helper loaded: url_helper
INFO - 2024-10-04 15:51:19 --> Helper loaded: file_helper
INFO - 2024-10-04 15:51:19 --> Helper loaded: form_helper
INFO - 2024-10-04 15:51:19 --> Helper loaded: my_helper
INFO - 2024-10-04 15:51:19 --> Database Driver Class Initialized
INFO - 2024-10-04 15:51:19 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-04 15:51:19 --> Controller Class Initialized
DEBUG - 2024-10-04 15:51:19 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/login/views/login.php
DEBUG - 2024-10-04 15:51:19 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-10-04 15:51:19 --> Final output sent to browser
DEBUG - 2024-10-04 15:51:19 --> Total execution time: 0.0329
INFO - 2024-10-04 15:56:47 --> Config Class Initialized
INFO - 2024-10-04 15:56:47 --> Hooks Class Initialized
DEBUG - 2024-10-04 15:56:47 --> UTF-8 Support Enabled
INFO - 2024-10-04 15:56:47 --> Utf8 Class Initialized
INFO - 2024-10-04 15:56:47 --> URI Class Initialized
INFO - 2024-10-04 15:56:47 --> Router Class Initialized
INFO - 2024-10-04 15:56:47 --> Output Class Initialized
INFO - 2024-10-04 15:56:47 --> Security Class Initialized
DEBUG - 2024-10-04 15:56:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-04 15:56:47 --> Input Class Initialized
INFO - 2024-10-04 15:56:47 --> Language Class Initialized
INFO - 2024-10-04 15:56:47 --> Language Class Initialized
INFO - 2024-10-04 15:56:47 --> Config Class Initialized
INFO - 2024-10-04 15:56:47 --> Loader Class Initialized
INFO - 2024-10-04 15:56:47 --> Helper loaded: url_helper
INFO - 2024-10-04 15:56:47 --> Helper loaded: file_helper
INFO - 2024-10-04 15:56:47 --> Helper loaded: form_helper
INFO - 2024-10-04 15:56:47 --> Helper loaded: my_helper
INFO - 2024-10-04 15:56:47 --> Database Driver Class Initialized
INFO - 2024-10-04 15:56:47 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-04 15:56:47 --> Controller Class Initialized
INFO - 2024-10-04 15:56:47 --> Final output sent to browser
DEBUG - 2024-10-04 15:56:47 --> Total execution time: 0.0516
INFO - 2024-10-04 15:56:52 --> Config Class Initialized
INFO - 2024-10-04 15:56:52 --> Hooks Class Initialized
DEBUG - 2024-10-04 15:56:52 --> UTF-8 Support Enabled
INFO - 2024-10-04 15:56:52 --> Utf8 Class Initialized
INFO - 2024-10-04 15:56:52 --> URI Class Initialized
INFO - 2024-10-04 15:56:52 --> Router Class Initialized
INFO - 2024-10-04 15:56:52 --> Output Class Initialized
INFO - 2024-10-04 15:56:52 --> Security Class Initialized
DEBUG - 2024-10-04 15:56:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-04 15:56:52 --> Input Class Initialized
INFO - 2024-10-04 15:56:52 --> Language Class Initialized
INFO - 2024-10-04 15:56:52 --> Language Class Initialized
INFO - 2024-10-04 15:56:52 --> Config Class Initialized
INFO - 2024-10-04 15:56:52 --> Loader Class Initialized
INFO - 2024-10-04 15:56:52 --> Helper loaded: url_helper
INFO - 2024-10-04 15:56:52 --> Helper loaded: file_helper
INFO - 2024-10-04 15:56:52 --> Helper loaded: form_helper
INFO - 2024-10-04 15:56:52 --> Helper loaded: my_helper
INFO - 2024-10-04 15:56:52 --> Database Driver Class Initialized
INFO - 2024-10-04 15:56:52 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-04 15:56:52 --> Controller Class Initialized
DEBUG - 2024-10-04 15:56:52 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/view_mapel/views/v_view_mapel.php
DEBUG - 2024-10-04 15:56:52 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-10-04 15:56:52 --> Final output sent to browser
DEBUG - 2024-10-04 15:56:52 --> Total execution time: 0.0291
INFO - 2024-10-04 15:57:00 --> Config Class Initialized
INFO - 2024-10-04 15:57:00 --> Hooks Class Initialized
DEBUG - 2024-10-04 15:57:00 --> UTF-8 Support Enabled
INFO - 2024-10-04 15:57:00 --> Utf8 Class Initialized
INFO - 2024-10-04 15:57:00 --> URI Class Initialized
INFO - 2024-10-04 15:57:00 --> Router Class Initialized
INFO - 2024-10-04 15:57:00 --> Output Class Initialized
INFO - 2024-10-04 15:57:00 --> Security Class Initialized
DEBUG - 2024-10-04 15:57:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-04 15:57:00 --> Input Class Initialized
INFO - 2024-10-04 15:57:00 --> Language Class Initialized
INFO - 2024-10-04 15:57:00 --> Language Class Initialized
INFO - 2024-10-04 15:57:00 --> Config Class Initialized
INFO - 2024-10-04 15:57:00 --> Loader Class Initialized
INFO - 2024-10-04 15:57:00 --> Helper loaded: url_helper
INFO - 2024-10-04 15:57:00 --> Helper loaded: file_helper
INFO - 2024-10-04 15:57:00 --> Helper loaded: form_helper
INFO - 2024-10-04 15:57:00 --> Helper loaded: my_helper
INFO - 2024-10-04 15:57:00 --> Database Driver Class Initialized
INFO - 2024-10-04 15:57:00 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-04 15:57:00 --> Controller Class Initialized
DEBUG - 2024-10-04 15:57:00 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/views/list.php
DEBUG - 2024-10-04 15:57:00 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-10-04 15:57:00 --> Final output sent to browser
DEBUG - 2024-10-04 15:57:00 --> Total execution time: 0.0365
INFO - 2024-10-04 15:57:00 --> Config Class Initialized
INFO - 2024-10-04 15:57:00 --> Hooks Class Initialized
DEBUG - 2024-10-04 15:57:00 --> UTF-8 Support Enabled
INFO - 2024-10-04 15:57:00 --> Utf8 Class Initialized
INFO - 2024-10-04 15:57:00 --> URI Class Initialized
INFO - 2024-10-04 15:57:00 --> Router Class Initialized
INFO - 2024-10-04 15:57:00 --> Output Class Initialized
INFO - 2024-10-04 15:57:00 --> Security Class Initialized
DEBUG - 2024-10-04 15:57:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-04 15:57:00 --> Input Class Initialized
INFO - 2024-10-04 15:57:00 --> Language Class Initialized
INFO - 2024-10-04 15:57:00 --> Language Class Initialized
INFO - 2024-10-04 15:57:00 --> Config Class Initialized
INFO - 2024-10-04 15:57:00 --> Loader Class Initialized
INFO - 2024-10-04 15:57:00 --> Helper loaded: url_helper
INFO - 2024-10-04 15:57:00 --> Helper loaded: file_helper
INFO - 2024-10-04 15:57:00 --> Helper loaded: form_helper
INFO - 2024-10-04 15:57:00 --> Helper loaded: my_helper
INFO - 2024-10-04 15:57:00 --> Database Driver Class Initialized
INFO - 2024-10-04 15:57:00 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-04 15:57:00 --> Controller Class Initialized
INFO - 2024-10-04 15:57:11 --> Config Class Initialized
INFO - 2024-10-04 15:57:11 --> Hooks Class Initialized
DEBUG - 2024-10-04 15:57:11 --> UTF-8 Support Enabled
INFO - 2024-10-04 15:57:11 --> Utf8 Class Initialized
INFO - 2024-10-04 15:57:11 --> URI Class Initialized
INFO - 2024-10-04 15:57:11 --> Router Class Initialized
INFO - 2024-10-04 15:57:11 --> Output Class Initialized
INFO - 2024-10-04 15:57:11 --> Security Class Initialized
DEBUG - 2024-10-04 15:57:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-04 15:57:11 --> Input Class Initialized
INFO - 2024-10-04 15:57:11 --> Language Class Initialized
INFO - 2024-10-04 15:57:11 --> Language Class Initialized
INFO - 2024-10-04 15:57:11 --> Config Class Initialized
INFO - 2024-10-04 15:57:11 --> Loader Class Initialized
INFO - 2024-10-04 15:57:11 --> Helper loaded: url_helper
INFO - 2024-10-04 15:57:11 --> Helper loaded: file_helper
INFO - 2024-10-04 15:57:11 --> Helper loaded: form_helper
INFO - 2024-10-04 15:57:11 --> Helper loaded: my_helper
INFO - 2024-10-04 15:57:11 --> Database Driver Class Initialized
INFO - 2024-10-04 15:57:11 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-04 15:57:11 --> Controller Class Initialized
INFO - 2024-10-04 15:57:11 --> Final output sent to browser
DEBUG - 2024-10-04 15:57:11 --> Total execution time: 0.0321
INFO - 2024-10-04 16:15:38 --> Config Class Initialized
INFO - 2024-10-04 16:15:39 --> Hooks Class Initialized
DEBUG - 2024-10-04 16:15:39 --> UTF-8 Support Enabled
INFO - 2024-10-04 16:15:39 --> Utf8 Class Initialized
INFO - 2024-10-04 16:15:39 --> URI Class Initialized
INFO - 2024-10-04 16:15:39 --> Router Class Initialized
INFO - 2024-10-04 16:15:39 --> Output Class Initialized
INFO - 2024-10-04 16:15:39 --> Security Class Initialized
DEBUG - 2024-10-04 16:15:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-04 16:15:39 --> Input Class Initialized
INFO - 2024-10-04 16:15:39 --> Language Class Initialized
INFO - 2024-10-04 16:15:39 --> Language Class Initialized
INFO - 2024-10-04 16:15:39 --> Config Class Initialized
INFO - 2024-10-04 16:15:39 --> Loader Class Initialized
INFO - 2024-10-04 16:15:39 --> Helper loaded: url_helper
INFO - 2024-10-04 16:15:39 --> Helper loaded: file_helper
INFO - 2024-10-04 16:15:39 --> Helper loaded: form_helper
INFO - 2024-10-04 16:15:39 --> Helper loaded: my_helper
INFO - 2024-10-04 16:15:39 --> Database Driver Class Initialized
INFO - 2024-10-04 16:15:39 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-04 16:15:39 --> Controller Class Initialized
INFO - 2024-10-04 16:15:39 --> Final output sent to browser
DEBUG - 2024-10-04 16:15:39 --> Total execution time: 0.5685
INFO - 2024-10-04 16:17:54 --> Config Class Initialized
INFO - 2024-10-04 16:17:54 --> Hooks Class Initialized
DEBUG - 2024-10-04 16:17:54 --> UTF-8 Support Enabled
INFO - 2024-10-04 16:17:54 --> Utf8 Class Initialized
INFO - 2024-10-04 16:17:54 --> URI Class Initialized
INFO - 2024-10-04 16:17:54 --> Router Class Initialized
INFO - 2024-10-04 16:17:54 --> Output Class Initialized
INFO - 2024-10-04 16:17:54 --> Security Class Initialized
DEBUG - 2024-10-04 16:17:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-04 16:17:54 --> Input Class Initialized
INFO - 2024-10-04 16:17:54 --> Language Class Initialized
INFO - 2024-10-04 16:17:54 --> Language Class Initialized
INFO - 2024-10-04 16:17:54 --> Config Class Initialized
INFO - 2024-10-04 16:17:54 --> Loader Class Initialized
INFO - 2024-10-04 16:17:54 --> Helper loaded: url_helper
INFO - 2024-10-04 16:17:54 --> Helper loaded: file_helper
INFO - 2024-10-04 16:17:54 --> Helper loaded: form_helper
INFO - 2024-10-04 16:17:54 --> Helper loaded: my_helper
INFO - 2024-10-04 16:17:54 --> Database Driver Class Initialized
INFO - 2024-10-04 16:17:54 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-04 16:17:54 --> Controller Class Initialized
INFO - 2024-10-04 16:17:54 --> Final output sent to browser
DEBUG - 2024-10-04 16:17:54 --> Total execution time: 0.5008
INFO - 2024-10-04 16:17:57 --> Config Class Initialized
INFO - 2024-10-04 16:17:57 --> Hooks Class Initialized
DEBUG - 2024-10-04 16:17:57 --> UTF-8 Support Enabled
INFO - 2024-10-04 16:17:57 --> Utf8 Class Initialized
INFO - 2024-10-04 16:17:57 --> URI Class Initialized
INFO - 2024-10-04 16:17:57 --> Router Class Initialized
INFO - 2024-10-04 16:17:57 --> Output Class Initialized
INFO - 2024-10-04 16:17:57 --> Security Class Initialized
DEBUG - 2024-10-04 16:17:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-04 16:17:57 --> Input Class Initialized
INFO - 2024-10-04 16:17:57 --> Language Class Initialized
INFO - 2024-10-04 16:17:57 --> Language Class Initialized
INFO - 2024-10-04 16:17:57 --> Config Class Initialized
INFO - 2024-10-04 16:17:57 --> Loader Class Initialized
INFO - 2024-10-04 16:17:57 --> Helper loaded: url_helper
INFO - 2024-10-04 16:17:57 --> Helper loaded: file_helper
INFO - 2024-10-04 16:17:57 --> Helper loaded: form_helper
INFO - 2024-10-04 16:17:57 --> Helper loaded: my_helper
INFO - 2024-10-04 16:17:57 --> Database Driver Class Initialized
INFO - 2024-10-04 16:17:57 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-04 16:17:57 --> Controller Class Initialized
DEBUG - 2024-10-04 16:17:57 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/view_mapel/views/v_view_mapel.php
DEBUG - 2024-10-04 16:17:57 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-10-04 16:17:57 --> Final output sent to browser
DEBUG - 2024-10-04 16:17:57 --> Total execution time: 0.0566
INFO - 2024-10-04 16:18:02 --> Config Class Initialized
INFO - 2024-10-04 16:18:02 --> Hooks Class Initialized
DEBUG - 2024-10-04 16:18:02 --> UTF-8 Support Enabled
INFO - 2024-10-04 16:18:02 --> Utf8 Class Initialized
INFO - 2024-10-04 16:18:02 --> URI Class Initialized
INFO - 2024-10-04 16:18:02 --> Router Class Initialized
INFO - 2024-10-04 16:18:02 --> Output Class Initialized
INFO - 2024-10-04 16:18:02 --> Security Class Initialized
DEBUG - 2024-10-04 16:18:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-04 16:18:02 --> Input Class Initialized
INFO - 2024-10-04 16:18:02 --> Language Class Initialized
INFO - 2024-10-04 16:18:02 --> Language Class Initialized
INFO - 2024-10-04 16:18:02 --> Config Class Initialized
INFO - 2024-10-04 16:18:02 --> Loader Class Initialized
INFO - 2024-10-04 16:18:02 --> Helper loaded: url_helper
INFO - 2024-10-04 16:18:02 --> Helper loaded: file_helper
INFO - 2024-10-04 16:18:02 --> Helper loaded: form_helper
INFO - 2024-10-04 16:18:02 --> Helper loaded: my_helper
INFO - 2024-10-04 16:18:02 --> Database Driver Class Initialized
INFO - 2024-10-04 16:18:03 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-04 16:18:03 --> Controller Class Initialized
DEBUG - 2024-10-04 16:18:03 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/views/list.php
DEBUG - 2024-10-04 16:18:03 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-10-04 16:18:03 --> Final output sent to browser
DEBUG - 2024-10-04 16:18:03 --> Total execution time: 0.1448
INFO - 2024-10-04 16:18:03 --> Config Class Initialized
INFO - 2024-10-04 16:18:03 --> Hooks Class Initialized
DEBUG - 2024-10-04 16:18:03 --> UTF-8 Support Enabled
INFO - 2024-10-04 16:18:03 --> Utf8 Class Initialized
INFO - 2024-10-04 16:18:03 --> URI Class Initialized
INFO - 2024-10-04 16:18:03 --> Router Class Initialized
INFO - 2024-10-04 16:18:03 --> Output Class Initialized
INFO - 2024-10-04 16:18:03 --> Security Class Initialized
DEBUG - 2024-10-04 16:18:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-04 16:18:03 --> Input Class Initialized
INFO - 2024-10-04 16:18:03 --> Language Class Initialized
INFO - 2024-10-04 16:18:03 --> Language Class Initialized
INFO - 2024-10-04 16:18:03 --> Config Class Initialized
INFO - 2024-10-04 16:18:03 --> Loader Class Initialized
INFO - 2024-10-04 16:18:03 --> Helper loaded: url_helper
INFO - 2024-10-04 16:18:03 --> Helper loaded: file_helper
INFO - 2024-10-04 16:18:03 --> Helper loaded: form_helper
INFO - 2024-10-04 16:18:03 --> Helper loaded: my_helper
INFO - 2024-10-04 16:18:03 --> Database Driver Class Initialized
INFO - 2024-10-04 16:18:03 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-04 16:18:03 --> Controller Class Initialized
INFO - 2024-10-04 16:18:06 --> Config Class Initialized
INFO - 2024-10-04 16:18:06 --> Hooks Class Initialized
DEBUG - 2024-10-04 16:18:06 --> UTF-8 Support Enabled
INFO - 2024-10-04 16:18:06 --> Utf8 Class Initialized
INFO - 2024-10-04 16:18:06 --> URI Class Initialized
INFO - 2024-10-04 16:18:06 --> Router Class Initialized
INFO - 2024-10-04 16:18:06 --> Output Class Initialized
INFO - 2024-10-04 16:18:06 --> Security Class Initialized
DEBUG - 2024-10-04 16:18:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-04 16:18:06 --> Input Class Initialized
INFO - 2024-10-04 16:18:06 --> Language Class Initialized
INFO - 2024-10-04 16:18:06 --> Language Class Initialized
INFO - 2024-10-04 16:18:06 --> Config Class Initialized
INFO - 2024-10-04 16:18:06 --> Loader Class Initialized
INFO - 2024-10-04 16:18:06 --> Helper loaded: url_helper
INFO - 2024-10-04 16:18:06 --> Helper loaded: file_helper
INFO - 2024-10-04 16:18:06 --> Helper loaded: form_helper
INFO - 2024-10-04 16:18:06 --> Helper loaded: my_helper
INFO - 2024-10-04 16:18:06 --> Database Driver Class Initialized
INFO - 2024-10-04 16:18:06 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-04 16:18:06 --> Controller Class Initialized
INFO - 2024-10-04 16:18:06 --> Final output sent to browser
DEBUG - 2024-10-04 16:18:06 --> Total execution time: 0.0865
INFO - 2024-10-04 16:18:07 --> Config Class Initialized
INFO - 2024-10-04 16:18:07 --> Hooks Class Initialized
DEBUG - 2024-10-04 16:18:07 --> UTF-8 Support Enabled
INFO - 2024-10-04 16:18:07 --> Utf8 Class Initialized
INFO - 2024-10-04 16:18:07 --> URI Class Initialized
INFO - 2024-10-04 16:18:07 --> Router Class Initialized
INFO - 2024-10-04 16:18:07 --> Output Class Initialized
INFO - 2024-10-04 16:18:07 --> Security Class Initialized
DEBUG - 2024-10-04 16:18:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-04 16:18:07 --> Input Class Initialized
INFO - 2024-10-04 16:18:07 --> Language Class Initialized
INFO - 2024-10-04 16:18:07 --> Language Class Initialized
INFO - 2024-10-04 16:18:07 --> Config Class Initialized
INFO - 2024-10-04 16:18:07 --> Loader Class Initialized
INFO - 2024-10-04 16:18:07 --> Helper loaded: url_helper
INFO - 2024-10-04 16:18:07 --> Helper loaded: file_helper
INFO - 2024-10-04 16:18:07 --> Helper loaded: form_helper
INFO - 2024-10-04 16:18:07 --> Helper loaded: my_helper
INFO - 2024-10-04 16:18:07 --> Database Driver Class Initialized
INFO - 2024-10-04 16:18:07 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-04 16:18:07 --> Controller Class Initialized
INFO - 2024-10-04 16:18:07 --> Final output sent to browser
DEBUG - 2024-10-04 16:18:07 --> Total execution time: 0.1027
INFO - 2024-10-04 16:18:10 --> Config Class Initialized
INFO - 2024-10-04 16:18:10 --> Hooks Class Initialized
DEBUG - 2024-10-04 16:18:10 --> UTF-8 Support Enabled
INFO - 2024-10-04 16:18:10 --> Utf8 Class Initialized
INFO - 2024-10-04 16:18:10 --> URI Class Initialized
INFO - 2024-10-04 16:18:10 --> Router Class Initialized
INFO - 2024-10-04 16:18:10 --> Output Class Initialized
INFO - 2024-10-04 16:18:10 --> Security Class Initialized
DEBUG - 2024-10-04 16:18:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-04 16:18:10 --> Input Class Initialized
INFO - 2024-10-04 16:18:10 --> Language Class Initialized
INFO - 2024-10-04 16:18:10 --> Language Class Initialized
INFO - 2024-10-04 16:18:10 --> Config Class Initialized
INFO - 2024-10-04 16:18:10 --> Loader Class Initialized
INFO - 2024-10-04 16:18:10 --> Helper loaded: url_helper
INFO - 2024-10-04 16:18:10 --> Helper loaded: file_helper
INFO - 2024-10-04 16:18:10 --> Helper loaded: form_helper
INFO - 2024-10-04 16:18:10 --> Helper loaded: my_helper
INFO - 2024-10-04 16:18:10 --> Database Driver Class Initialized
INFO - 2024-10-04 16:18:10 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-04 16:18:10 --> Controller Class Initialized
DEBUG - 2024-10-04 16:18:10 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/view_mapel/views/v_view_mapel.php
DEBUG - 2024-10-04 16:18:10 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-10-04 16:18:10 --> Final output sent to browser
DEBUG - 2024-10-04 16:18:10 --> Total execution time: 0.0481
INFO - 2024-10-04 16:18:13 --> Config Class Initialized
INFO - 2024-10-04 16:18:13 --> Hooks Class Initialized
DEBUG - 2024-10-04 16:18:13 --> UTF-8 Support Enabled
INFO - 2024-10-04 16:18:13 --> Utf8 Class Initialized
INFO - 2024-10-04 16:18:13 --> URI Class Initialized
INFO - 2024-10-04 16:18:13 --> Router Class Initialized
INFO - 2024-10-04 16:18:13 --> Output Class Initialized
INFO - 2024-10-04 16:18:13 --> Security Class Initialized
DEBUG - 2024-10-04 16:18:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-04 16:18:13 --> Input Class Initialized
INFO - 2024-10-04 16:18:13 --> Language Class Initialized
INFO - 2024-10-04 16:18:13 --> Language Class Initialized
INFO - 2024-10-04 16:18:13 --> Config Class Initialized
INFO - 2024-10-04 16:18:13 --> Loader Class Initialized
INFO - 2024-10-04 16:18:13 --> Helper loaded: url_helper
INFO - 2024-10-04 16:18:13 --> Helper loaded: file_helper
INFO - 2024-10-04 16:18:13 --> Helper loaded: form_helper
INFO - 2024-10-04 16:18:13 --> Helper loaded: my_helper
INFO - 2024-10-04 16:18:13 --> Database Driver Class Initialized
INFO - 2024-10-04 16:18:13 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-04 16:18:13 --> Controller Class Initialized
DEBUG - 2024-10-04 16:18:13 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/views/list.php
DEBUG - 2024-10-04 16:18:13 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-10-04 16:18:13 --> Final output sent to browser
DEBUG - 2024-10-04 16:18:13 --> Total execution time: 0.2535
INFO - 2024-10-04 16:18:13 --> Config Class Initialized
INFO - 2024-10-04 16:18:13 --> Hooks Class Initialized
DEBUG - 2024-10-04 16:18:13 --> UTF-8 Support Enabled
INFO - 2024-10-04 16:18:13 --> Utf8 Class Initialized
INFO - 2024-10-04 16:18:13 --> URI Class Initialized
INFO - 2024-10-04 16:18:13 --> Router Class Initialized
INFO - 2024-10-04 16:18:13 --> Output Class Initialized
INFO - 2024-10-04 16:18:13 --> Security Class Initialized
DEBUG - 2024-10-04 16:18:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-04 16:18:14 --> Input Class Initialized
INFO - 2024-10-04 16:18:14 --> Language Class Initialized
INFO - 2024-10-04 16:18:14 --> Language Class Initialized
INFO - 2024-10-04 16:18:14 --> Config Class Initialized
INFO - 2024-10-04 16:18:14 --> Loader Class Initialized
INFO - 2024-10-04 16:18:14 --> Helper loaded: url_helper
INFO - 2024-10-04 16:18:14 --> Helper loaded: file_helper
INFO - 2024-10-04 16:18:14 --> Helper loaded: form_helper
INFO - 2024-10-04 16:18:14 --> Helper loaded: my_helper
INFO - 2024-10-04 16:18:14 --> Database Driver Class Initialized
INFO - 2024-10-04 16:18:14 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-04 16:18:14 --> Controller Class Initialized
INFO - 2024-10-04 16:18:17 --> Config Class Initialized
INFO - 2024-10-04 16:18:17 --> Hooks Class Initialized
DEBUG - 2024-10-04 16:18:17 --> UTF-8 Support Enabled
INFO - 2024-10-04 16:18:17 --> Utf8 Class Initialized
INFO - 2024-10-04 16:18:17 --> URI Class Initialized
INFO - 2024-10-04 16:18:17 --> Router Class Initialized
INFO - 2024-10-04 16:18:17 --> Output Class Initialized
INFO - 2024-10-04 16:18:17 --> Security Class Initialized
DEBUG - 2024-10-04 16:18:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-04 16:18:17 --> Input Class Initialized
INFO - 2024-10-04 16:18:17 --> Language Class Initialized
INFO - 2024-10-04 16:18:17 --> Language Class Initialized
INFO - 2024-10-04 16:18:17 --> Config Class Initialized
INFO - 2024-10-04 16:18:17 --> Loader Class Initialized
INFO - 2024-10-04 16:18:17 --> Helper loaded: url_helper
INFO - 2024-10-04 16:18:17 --> Helper loaded: file_helper
INFO - 2024-10-04 16:18:17 --> Helper loaded: form_helper
INFO - 2024-10-04 16:18:17 --> Helper loaded: my_helper
INFO - 2024-10-04 16:18:17 --> Database Driver Class Initialized
INFO - 2024-10-04 16:18:17 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-04 16:18:17 --> Controller Class Initialized
INFO - 2024-10-04 16:18:17 --> Final output sent to browser
DEBUG - 2024-10-04 16:18:17 --> Total execution time: 0.1025
INFO - 2024-10-04 16:18:19 --> Config Class Initialized
INFO - 2024-10-04 16:18:19 --> Hooks Class Initialized
DEBUG - 2024-10-04 16:18:19 --> UTF-8 Support Enabled
INFO - 2024-10-04 16:18:19 --> Utf8 Class Initialized
INFO - 2024-10-04 16:18:19 --> URI Class Initialized
INFO - 2024-10-04 16:18:19 --> Router Class Initialized
INFO - 2024-10-04 16:18:19 --> Output Class Initialized
INFO - 2024-10-04 16:18:19 --> Security Class Initialized
DEBUG - 2024-10-04 16:18:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-04 16:18:19 --> Input Class Initialized
INFO - 2024-10-04 16:18:19 --> Language Class Initialized
INFO - 2024-10-04 16:18:19 --> Language Class Initialized
INFO - 2024-10-04 16:18:19 --> Config Class Initialized
INFO - 2024-10-04 16:18:19 --> Loader Class Initialized
INFO - 2024-10-04 16:18:19 --> Helper loaded: url_helper
INFO - 2024-10-04 16:18:19 --> Helper loaded: file_helper
INFO - 2024-10-04 16:18:19 --> Helper loaded: form_helper
INFO - 2024-10-04 16:18:19 --> Helper loaded: my_helper
INFO - 2024-10-04 16:18:19 --> Database Driver Class Initialized
INFO - 2024-10-04 16:18:19 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-04 16:18:19 --> Controller Class Initialized
DEBUG - 2024-10-04 16:18:19 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/view_mapel/views/v_view_mapel.php
DEBUG - 2024-10-04 16:18:19 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-10-04 16:18:19 --> Final output sent to browser
DEBUG - 2024-10-04 16:18:19 --> Total execution time: 0.0887
INFO - 2024-10-04 16:18:22 --> Config Class Initialized
INFO - 2024-10-04 16:18:22 --> Hooks Class Initialized
DEBUG - 2024-10-04 16:18:22 --> UTF-8 Support Enabled
INFO - 2024-10-04 16:18:22 --> Utf8 Class Initialized
INFO - 2024-10-04 16:18:22 --> URI Class Initialized
INFO - 2024-10-04 16:18:22 --> Router Class Initialized
INFO - 2024-10-04 16:18:22 --> Output Class Initialized
INFO - 2024-10-04 16:18:22 --> Security Class Initialized
DEBUG - 2024-10-04 16:18:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-04 16:18:22 --> Input Class Initialized
INFO - 2024-10-04 16:18:22 --> Language Class Initialized
INFO - 2024-10-04 16:18:22 --> Language Class Initialized
INFO - 2024-10-04 16:18:22 --> Config Class Initialized
INFO - 2024-10-04 16:18:22 --> Loader Class Initialized
INFO - 2024-10-04 16:18:22 --> Helper loaded: url_helper
INFO - 2024-10-04 16:18:22 --> Helper loaded: file_helper
INFO - 2024-10-04 16:18:22 --> Helper loaded: form_helper
INFO - 2024-10-04 16:18:22 --> Helper loaded: my_helper
INFO - 2024-10-04 16:18:22 --> Database Driver Class Initialized
INFO - 2024-10-04 16:18:22 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-04 16:18:22 --> Controller Class Initialized
DEBUG - 2024-10-04 16:18:22 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_catatan_guru/views/list.php
DEBUG - 2024-10-04 16:18:22 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-10-04 16:18:22 --> Final output sent to browser
DEBUG - 2024-10-04 16:18:22 --> Total execution time: 0.0578
INFO - 2024-10-04 16:18:24 --> Config Class Initialized
INFO - 2024-10-04 16:18:24 --> Hooks Class Initialized
DEBUG - 2024-10-04 16:18:24 --> UTF-8 Support Enabled
INFO - 2024-10-04 16:18:24 --> Utf8 Class Initialized
INFO - 2024-10-04 16:18:24 --> URI Class Initialized
INFO - 2024-10-04 16:18:24 --> Router Class Initialized
INFO - 2024-10-04 16:18:24 --> Output Class Initialized
INFO - 2024-10-04 16:18:24 --> Security Class Initialized
DEBUG - 2024-10-04 16:18:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-04 16:18:24 --> Input Class Initialized
INFO - 2024-10-04 16:18:24 --> Language Class Initialized
INFO - 2024-10-04 16:18:24 --> Language Class Initialized
INFO - 2024-10-04 16:18:24 --> Config Class Initialized
INFO - 2024-10-04 16:18:24 --> Loader Class Initialized
INFO - 2024-10-04 16:18:24 --> Helper loaded: url_helper
INFO - 2024-10-04 16:18:24 --> Helper loaded: file_helper
INFO - 2024-10-04 16:18:24 --> Helper loaded: form_helper
INFO - 2024-10-04 16:18:24 --> Helper loaded: my_helper
INFO - 2024-10-04 16:18:24 --> Database Driver Class Initialized
INFO - 2024-10-04 16:18:24 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-04 16:18:24 --> Controller Class Initialized
INFO - 2024-10-04 16:18:24 --> Final output sent to browser
DEBUG - 2024-10-04 16:18:24 --> Total execution time: 0.0440
INFO - 2024-10-04 16:18:25 --> Config Class Initialized
INFO - 2024-10-04 16:18:25 --> Hooks Class Initialized
DEBUG - 2024-10-04 16:18:25 --> UTF-8 Support Enabled
INFO - 2024-10-04 16:18:25 --> Utf8 Class Initialized
INFO - 2024-10-04 16:18:25 --> URI Class Initialized
INFO - 2024-10-04 16:18:25 --> Router Class Initialized
INFO - 2024-10-04 16:18:25 --> Output Class Initialized
INFO - 2024-10-04 16:18:25 --> Security Class Initialized
DEBUG - 2024-10-04 16:18:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-04 16:18:25 --> Input Class Initialized
INFO - 2024-10-04 16:18:25 --> Language Class Initialized
INFO - 2024-10-04 16:18:25 --> Language Class Initialized
INFO - 2024-10-04 16:18:25 --> Config Class Initialized
INFO - 2024-10-04 16:18:25 --> Loader Class Initialized
INFO - 2024-10-04 16:18:25 --> Helper loaded: url_helper
INFO - 2024-10-04 16:18:25 --> Helper loaded: file_helper
INFO - 2024-10-04 16:18:25 --> Helper loaded: form_helper
INFO - 2024-10-04 16:18:25 --> Helper loaded: my_helper
INFO - 2024-10-04 16:18:25 --> Database Driver Class Initialized
INFO - 2024-10-04 16:18:25 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-04 16:18:25 --> Controller Class Initialized
DEBUG - 2024-10-04 16:18:25 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_catatan_guru/views/list.php
DEBUG - 2024-10-04 16:18:25 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-10-04 16:18:25 --> Final output sent to browser
DEBUG - 2024-10-04 16:18:25 --> Total execution time: 0.3417
INFO - 2024-10-04 16:18:26 --> Config Class Initialized
INFO - 2024-10-04 16:18:26 --> Hooks Class Initialized
DEBUG - 2024-10-04 16:18:26 --> UTF-8 Support Enabled
INFO - 2024-10-04 16:18:26 --> Utf8 Class Initialized
INFO - 2024-10-04 16:18:26 --> URI Class Initialized
INFO - 2024-10-04 16:18:26 --> Router Class Initialized
INFO - 2024-10-04 16:18:26 --> Output Class Initialized
INFO - 2024-10-04 16:18:26 --> Security Class Initialized
DEBUG - 2024-10-04 16:18:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-04 16:18:26 --> Input Class Initialized
INFO - 2024-10-04 16:18:26 --> Language Class Initialized
INFO - 2024-10-04 16:18:26 --> Language Class Initialized
INFO - 2024-10-04 16:18:26 --> Config Class Initialized
INFO - 2024-10-04 16:18:26 --> Loader Class Initialized
INFO - 2024-10-04 16:18:26 --> Helper loaded: url_helper
INFO - 2024-10-04 16:18:26 --> Helper loaded: file_helper
INFO - 2024-10-04 16:18:26 --> Config Class Initialized
INFO - 2024-10-04 16:18:26 --> Hooks Class Initialized
DEBUG - 2024-10-04 16:18:26 --> UTF-8 Support Enabled
INFO - 2024-10-04 16:18:26 --> Utf8 Class Initialized
INFO - 2024-10-04 16:18:26 --> URI Class Initialized
INFO - 2024-10-04 16:18:26 --> Router Class Initialized
INFO - 2024-10-04 16:18:26 --> Output Class Initialized
INFO - 2024-10-04 16:18:26 --> Security Class Initialized
DEBUG - 2024-10-04 16:18:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-04 16:18:26 --> Input Class Initialized
INFO - 2024-10-04 16:18:26 --> Language Class Initialized
INFO - 2024-10-04 16:18:26 --> Language Class Initialized
INFO - 2024-10-04 16:18:26 --> Config Class Initialized
INFO - 2024-10-04 16:18:26 --> Loader Class Initialized
INFO - 2024-10-04 16:18:26 --> Helper loaded: url_helper
INFO - 2024-10-04 16:18:26 --> Helper loaded: file_helper
INFO - 2024-10-04 16:18:26 --> Helper loaded: form_helper
INFO - 2024-10-04 16:18:26 --> Helper loaded: form_helper
INFO - 2024-10-04 16:18:26 --> Helper loaded: my_helper
INFO - 2024-10-04 16:18:26 --> Database Driver Class Initialized
INFO - 2024-10-04 16:18:26 --> Helper loaded: my_helper
INFO - 2024-10-04 16:18:26 --> Database Driver Class Initialized
INFO - 2024-10-04 16:18:26 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-04 16:18:26 --> Controller Class Initialized
INFO - 2024-10-04 16:18:26 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-04 16:18:26 --> Controller Class Initialized
DEBUG - 2024-10-04 16:18:26 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_catatan_guru/views/list.php
DEBUG - 2024-10-04 16:18:26 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-10-04 16:18:26 --> Final output sent to browser
DEBUG - 2024-10-04 16:18:26 --> Total execution time: 0.1325
DEBUG - 2024-10-04 16:18:26 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_catatan_guru/views/list.php
DEBUG - 2024-10-04 16:18:26 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-10-04 16:18:26 --> Final output sent to browser
DEBUG - 2024-10-04 16:18:26 --> Total execution time: 0.1130
INFO - 2024-10-04 16:18:27 --> Config Class Initialized
INFO - 2024-10-04 16:18:27 --> Hooks Class Initialized
DEBUG - 2024-10-04 16:18:27 --> UTF-8 Support Enabled
INFO - 2024-10-04 16:18:27 --> Utf8 Class Initialized
INFO - 2024-10-04 16:18:27 --> URI Class Initialized
INFO - 2024-10-04 16:18:27 --> Router Class Initialized
INFO - 2024-10-04 16:18:27 --> Output Class Initialized
INFO - 2024-10-04 16:18:27 --> Security Class Initialized
DEBUG - 2024-10-04 16:18:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-04 16:18:27 --> Input Class Initialized
INFO - 2024-10-04 16:18:27 --> Language Class Initialized
INFO - 2024-10-04 16:18:27 --> Language Class Initialized
INFO - 2024-10-04 16:18:27 --> Config Class Initialized
INFO - 2024-10-04 16:18:27 --> Loader Class Initialized
INFO - 2024-10-04 16:18:27 --> Helper loaded: url_helper
INFO - 2024-10-04 16:18:27 --> Helper loaded: file_helper
INFO - 2024-10-04 16:18:27 --> Helper loaded: form_helper
INFO - 2024-10-04 16:18:27 --> Helper loaded: my_helper
INFO - 2024-10-04 16:18:27 --> Database Driver Class Initialized
INFO - 2024-10-04 16:18:27 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-04 16:18:27 --> Controller Class Initialized
DEBUG - 2024-10-04 16:18:27 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/view_mapel/views/v_view_mapel.php
DEBUG - 2024-10-04 16:18:27 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-10-04 16:18:27 --> Final output sent to browser
DEBUG - 2024-10-04 16:18:27 --> Total execution time: 0.0339
INFO - 2024-10-04 16:18:29 --> Config Class Initialized
INFO - 2024-10-04 16:18:29 --> Hooks Class Initialized
DEBUG - 2024-10-04 16:18:29 --> UTF-8 Support Enabled
INFO - 2024-10-04 16:18:29 --> Utf8 Class Initialized
INFO - 2024-10-04 16:18:29 --> URI Class Initialized
INFO - 2024-10-04 16:18:29 --> Router Class Initialized
INFO - 2024-10-04 16:18:29 --> Output Class Initialized
INFO - 2024-10-04 16:18:29 --> Security Class Initialized
DEBUG - 2024-10-04 16:18:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-04 16:18:29 --> Input Class Initialized
INFO - 2024-10-04 16:18:29 --> Language Class Initialized
INFO - 2024-10-04 16:18:29 --> Language Class Initialized
INFO - 2024-10-04 16:18:29 --> Config Class Initialized
INFO - 2024-10-04 16:18:29 --> Loader Class Initialized
INFO - 2024-10-04 16:18:29 --> Helper loaded: url_helper
INFO - 2024-10-04 16:18:29 --> Helper loaded: file_helper
INFO - 2024-10-04 16:18:29 --> Helper loaded: form_helper
INFO - 2024-10-04 16:18:29 --> Helper loaded: my_helper
INFO - 2024-10-04 16:18:29 --> Database Driver Class Initialized
INFO - 2024-10-04 16:18:29 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-04 16:18:29 --> Controller Class Initialized
DEBUG - 2024-10-04 16:18:29 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_catatan_guru/views/list.php
DEBUG - 2024-10-04 16:18:29 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-10-04 16:18:29 --> Final output sent to browser
DEBUG - 2024-10-04 16:18:29 --> Total execution time: 0.1029
INFO - 2024-10-04 16:18:31 --> Config Class Initialized
INFO - 2024-10-04 16:18:31 --> Hooks Class Initialized
DEBUG - 2024-10-04 16:18:31 --> UTF-8 Support Enabled
INFO - 2024-10-04 16:18:31 --> Utf8 Class Initialized
INFO - 2024-10-04 16:18:31 --> URI Class Initialized
INFO - 2024-10-04 16:18:31 --> Router Class Initialized
INFO - 2024-10-04 16:18:31 --> Output Class Initialized
INFO - 2024-10-04 16:18:31 --> Security Class Initialized
DEBUG - 2024-10-04 16:18:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-04 16:18:31 --> Input Class Initialized
INFO - 2024-10-04 16:18:31 --> Language Class Initialized
INFO - 2024-10-04 16:18:31 --> Language Class Initialized
INFO - 2024-10-04 16:18:31 --> Config Class Initialized
INFO - 2024-10-04 16:18:31 --> Loader Class Initialized
INFO - 2024-10-04 16:18:31 --> Helper loaded: url_helper
INFO - 2024-10-04 16:18:31 --> Helper loaded: file_helper
INFO - 2024-10-04 16:18:31 --> Helper loaded: form_helper
INFO - 2024-10-04 16:18:31 --> Helper loaded: my_helper
INFO - 2024-10-04 16:18:31 --> Database Driver Class Initialized
INFO - 2024-10-04 16:18:31 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-04 16:18:31 --> Controller Class Initialized
INFO - 2024-10-04 16:18:31 --> Final output sent to browser
DEBUG - 2024-10-04 16:18:31 --> Total execution time: 0.0434
INFO - 2024-10-04 16:18:33 --> Config Class Initialized
INFO - 2024-10-04 16:18:33 --> Hooks Class Initialized
DEBUG - 2024-10-04 16:18:33 --> UTF-8 Support Enabled
INFO - 2024-10-04 16:18:33 --> Utf8 Class Initialized
INFO - 2024-10-04 16:18:33 --> URI Class Initialized
INFO - 2024-10-04 16:18:33 --> Router Class Initialized
INFO - 2024-10-04 16:18:33 --> Output Class Initialized
INFO - 2024-10-04 16:18:33 --> Security Class Initialized
DEBUG - 2024-10-04 16:18:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-04 16:18:33 --> Input Class Initialized
INFO - 2024-10-04 16:18:33 --> Language Class Initialized
INFO - 2024-10-04 16:18:33 --> Language Class Initialized
INFO - 2024-10-04 16:18:33 --> Config Class Initialized
INFO - 2024-10-04 16:18:33 --> Loader Class Initialized
INFO - 2024-10-04 16:18:33 --> Helper loaded: url_helper
INFO - 2024-10-04 16:18:33 --> Helper loaded: file_helper
INFO - 2024-10-04 16:18:33 --> Helper loaded: form_helper
INFO - 2024-10-04 16:18:33 --> Helper loaded: my_helper
INFO - 2024-10-04 16:18:33 --> Database Driver Class Initialized
INFO - 2024-10-04 16:18:33 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-04 16:18:33 --> Controller Class Initialized
DEBUG - 2024-10-04 16:18:33 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/view_mapel/views/v_view_mapel.php
DEBUG - 2024-10-04 16:18:33 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-10-04 16:18:33 --> Final output sent to browser
DEBUG - 2024-10-04 16:18:33 --> Total execution time: 0.1158
INFO - 2024-10-04 16:18:36 --> Config Class Initialized
INFO - 2024-10-04 16:18:36 --> Hooks Class Initialized
DEBUG - 2024-10-04 16:18:36 --> UTF-8 Support Enabled
INFO - 2024-10-04 16:18:36 --> Utf8 Class Initialized
INFO - 2024-10-04 16:18:36 --> URI Class Initialized
INFO - 2024-10-04 16:18:36 --> Router Class Initialized
INFO - 2024-10-04 16:18:36 --> Output Class Initialized
INFO - 2024-10-04 16:18:36 --> Security Class Initialized
DEBUG - 2024-10-04 16:18:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-04 16:18:36 --> Input Class Initialized
INFO - 2024-10-04 16:18:36 --> Language Class Initialized
INFO - 2024-10-04 16:18:36 --> Language Class Initialized
INFO - 2024-10-04 16:18:36 --> Config Class Initialized
INFO - 2024-10-04 16:18:36 --> Loader Class Initialized
INFO - 2024-10-04 16:18:36 --> Helper loaded: url_helper
INFO - 2024-10-04 16:18:36 --> Helper loaded: file_helper
INFO - 2024-10-04 16:18:36 --> Helper loaded: form_helper
INFO - 2024-10-04 16:18:36 --> Helper loaded: my_helper
INFO - 2024-10-04 16:18:36 --> Database Driver Class Initialized
INFO - 2024-10-04 16:18:36 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-04 16:18:36 --> Controller Class Initialized
DEBUG - 2024-10-04 16:18:36 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_catatan_guru/views/list.php
DEBUG - 2024-10-04 16:18:36 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-10-04 16:18:36 --> Final output sent to browser
DEBUG - 2024-10-04 16:18:36 --> Total execution time: 0.0518
INFO - 2024-10-04 16:18:38 --> Config Class Initialized
INFO - 2024-10-04 16:18:38 --> Hooks Class Initialized
DEBUG - 2024-10-04 16:18:38 --> UTF-8 Support Enabled
INFO - 2024-10-04 16:18:38 --> Utf8 Class Initialized
INFO - 2024-10-04 16:18:38 --> URI Class Initialized
INFO - 2024-10-04 16:18:38 --> Router Class Initialized
INFO - 2024-10-04 16:18:38 --> Output Class Initialized
INFO - 2024-10-04 16:18:38 --> Security Class Initialized
DEBUG - 2024-10-04 16:18:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-04 16:18:38 --> Input Class Initialized
INFO - 2024-10-04 16:18:38 --> Language Class Initialized
INFO - 2024-10-04 16:18:38 --> Language Class Initialized
INFO - 2024-10-04 16:18:38 --> Config Class Initialized
INFO - 2024-10-04 16:18:38 --> Loader Class Initialized
INFO - 2024-10-04 16:18:38 --> Helper loaded: url_helper
INFO - 2024-10-04 16:18:38 --> Helper loaded: file_helper
INFO - 2024-10-04 16:18:38 --> Helper loaded: form_helper
INFO - 2024-10-04 16:18:38 --> Helper loaded: my_helper
INFO - 2024-10-04 16:18:38 --> Database Driver Class Initialized
INFO - 2024-10-04 16:18:38 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-04 16:18:38 --> Controller Class Initialized
INFO - 2024-10-04 16:18:38 --> Final output sent to browser
DEBUG - 2024-10-04 16:18:38 --> Total execution time: 0.1593
INFO - 2024-10-04 16:18:40 --> Config Class Initialized
INFO - 2024-10-04 16:18:40 --> Hooks Class Initialized
DEBUG - 2024-10-04 16:18:40 --> UTF-8 Support Enabled
INFO - 2024-10-04 16:18:40 --> Utf8 Class Initialized
INFO - 2024-10-04 16:18:40 --> URI Class Initialized
INFO - 2024-10-04 16:18:40 --> Router Class Initialized
INFO - 2024-10-04 16:18:40 --> Output Class Initialized
INFO - 2024-10-04 16:18:40 --> Security Class Initialized
DEBUG - 2024-10-04 16:18:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-04 16:18:40 --> Input Class Initialized
INFO - 2024-10-04 16:18:40 --> Language Class Initialized
INFO - 2024-10-04 16:18:40 --> Language Class Initialized
INFO - 2024-10-04 16:18:40 --> Config Class Initialized
INFO - 2024-10-04 16:18:40 --> Loader Class Initialized
INFO - 2024-10-04 16:18:40 --> Helper loaded: url_helper
INFO - 2024-10-04 16:18:40 --> Helper loaded: file_helper
INFO - 2024-10-04 16:18:40 --> Helper loaded: form_helper
INFO - 2024-10-04 16:18:40 --> Helper loaded: my_helper
INFO - 2024-10-04 16:18:40 --> Database Driver Class Initialized
INFO - 2024-10-04 16:18:40 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-04 16:18:40 --> Controller Class Initialized
DEBUG - 2024-10-04 16:18:40 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/view_mapel/views/v_view_mapel.php
DEBUG - 2024-10-04 16:18:40 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-10-04 16:18:40 --> Final output sent to browser
DEBUG - 2024-10-04 16:18:40 --> Total execution time: 0.1563
INFO - 2024-10-04 16:18:42 --> Config Class Initialized
INFO - 2024-10-04 16:18:42 --> Hooks Class Initialized
DEBUG - 2024-10-04 16:18:42 --> UTF-8 Support Enabled
INFO - 2024-10-04 16:18:42 --> Utf8 Class Initialized
INFO - 2024-10-04 16:18:42 --> URI Class Initialized
INFO - 2024-10-04 16:18:42 --> Router Class Initialized
INFO - 2024-10-04 16:18:42 --> Output Class Initialized
INFO - 2024-10-04 16:18:42 --> Security Class Initialized
DEBUG - 2024-10-04 16:18:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-04 16:18:42 --> Input Class Initialized
INFO - 2024-10-04 16:18:42 --> Language Class Initialized
INFO - 2024-10-04 16:18:42 --> Language Class Initialized
INFO - 2024-10-04 16:18:42 --> Config Class Initialized
INFO - 2024-10-04 16:18:42 --> Loader Class Initialized
INFO - 2024-10-04 16:18:42 --> Helper loaded: url_helper
INFO - 2024-10-04 16:18:42 --> Helper loaded: file_helper
INFO - 2024-10-04 16:18:42 --> Helper loaded: form_helper
INFO - 2024-10-04 16:18:42 --> Helper loaded: my_helper
INFO - 2024-10-04 16:18:42 --> Database Driver Class Initialized
INFO - 2024-10-04 16:18:42 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-04 16:18:42 --> Controller Class Initialized
DEBUG - 2024-10-04 16:18:43 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/views/list.php
DEBUG - 2024-10-04 16:18:43 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-10-04 16:18:43 --> Final output sent to browser
DEBUG - 2024-10-04 16:18:43 --> Total execution time: 0.1027
INFO - 2024-10-04 16:18:43 --> Config Class Initialized
INFO - 2024-10-04 16:18:43 --> Hooks Class Initialized
DEBUG - 2024-10-04 16:18:43 --> UTF-8 Support Enabled
INFO - 2024-10-04 16:18:43 --> Utf8 Class Initialized
INFO - 2024-10-04 16:18:43 --> URI Class Initialized
INFO - 2024-10-04 16:18:43 --> Router Class Initialized
INFO - 2024-10-04 16:18:43 --> Output Class Initialized
INFO - 2024-10-04 16:18:43 --> Security Class Initialized
DEBUG - 2024-10-04 16:18:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-04 16:18:43 --> Input Class Initialized
INFO - 2024-10-04 16:18:43 --> Language Class Initialized
INFO - 2024-10-04 16:18:43 --> Language Class Initialized
INFO - 2024-10-04 16:18:43 --> Config Class Initialized
INFO - 2024-10-04 16:18:43 --> Loader Class Initialized
INFO - 2024-10-04 16:18:43 --> Helper loaded: url_helper
INFO - 2024-10-04 16:18:43 --> Helper loaded: file_helper
INFO - 2024-10-04 16:18:43 --> Helper loaded: form_helper
INFO - 2024-10-04 16:18:43 --> Helper loaded: my_helper
INFO - 2024-10-04 16:18:43 --> Database Driver Class Initialized
INFO - 2024-10-04 16:18:43 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-04 16:18:43 --> Controller Class Initialized
INFO - 2024-10-04 16:18:46 --> Config Class Initialized
INFO - 2024-10-04 16:18:46 --> Hooks Class Initialized
DEBUG - 2024-10-04 16:18:46 --> UTF-8 Support Enabled
INFO - 2024-10-04 16:18:46 --> Utf8 Class Initialized
INFO - 2024-10-04 16:18:46 --> URI Class Initialized
INFO - 2024-10-04 16:18:46 --> Router Class Initialized
INFO - 2024-10-04 16:18:46 --> Output Class Initialized
INFO - 2024-10-04 16:18:46 --> Security Class Initialized
DEBUG - 2024-10-04 16:18:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-04 16:18:46 --> Input Class Initialized
INFO - 2024-10-04 16:18:46 --> Language Class Initialized
INFO - 2024-10-04 16:18:46 --> Language Class Initialized
INFO - 2024-10-04 16:18:46 --> Config Class Initialized
INFO - 2024-10-04 16:18:46 --> Loader Class Initialized
INFO - 2024-10-04 16:18:46 --> Helper loaded: url_helper
INFO - 2024-10-04 16:18:46 --> Helper loaded: file_helper
INFO - 2024-10-04 16:18:46 --> Helper loaded: form_helper
INFO - 2024-10-04 16:18:46 --> Helper loaded: my_helper
INFO - 2024-10-04 16:18:46 --> Database Driver Class Initialized
INFO - 2024-10-04 16:18:46 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-04 16:18:46 --> Controller Class Initialized
INFO - 2024-10-04 16:18:46 --> Final output sent to browser
DEBUG - 2024-10-04 16:18:46 --> Total execution time: 0.0411
INFO - 2024-10-04 16:18:48 --> Config Class Initialized
INFO - 2024-10-04 16:18:48 --> Hooks Class Initialized
DEBUG - 2024-10-04 16:18:48 --> UTF-8 Support Enabled
INFO - 2024-10-04 16:18:48 --> Utf8 Class Initialized
INFO - 2024-10-04 16:18:48 --> URI Class Initialized
INFO - 2024-10-04 16:18:48 --> Router Class Initialized
INFO - 2024-10-04 16:18:48 --> Output Class Initialized
INFO - 2024-10-04 16:18:48 --> Security Class Initialized
DEBUG - 2024-10-04 16:18:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-04 16:18:48 --> Input Class Initialized
INFO - 2024-10-04 16:18:48 --> Language Class Initialized
INFO - 2024-10-04 16:18:48 --> Language Class Initialized
INFO - 2024-10-04 16:18:48 --> Config Class Initialized
INFO - 2024-10-04 16:18:48 --> Loader Class Initialized
INFO - 2024-10-04 16:18:48 --> Helper loaded: url_helper
INFO - 2024-10-04 16:18:48 --> Helper loaded: file_helper
INFO - 2024-10-04 16:18:48 --> Helper loaded: form_helper
INFO - 2024-10-04 16:18:48 --> Helper loaded: my_helper
INFO - 2024-10-04 16:18:48 --> Database Driver Class Initialized
INFO - 2024-10-04 16:18:48 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-04 16:18:48 --> Controller Class Initialized
DEBUG - 2024-10-04 16:18:48 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/view_mapel/views/v_view_mapel.php
DEBUG - 2024-10-04 16:18:48 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-10-04 16:18:48 --> Final output sent to browser
DEBUG - 2024-10-04 16:18:48 --> Total execution time: 0.1009
INFO - 2024-10-04 16:18:51 --> Config Class Initialized
INFO - 2024-10-04 16:18:51 --> Hooks Class Initialized
DEBUG - 2024-10-04 16:18:51 --> UTF-8 Support Enabled
INFO - 2024-10-04 16:18:51 --> Utf8 Class Initialized
INFO - 2024-10-04 16:18:51 --> URI Class Initialized
INFO - 2024-10-04 16:18:51 --> Router Class Initialized
INFO - 2024-10-04 16:18:51 --> Output Class Initialized
INFO - 2024-10-04 16:18:51 --> Security Class Initialized
DEBUG - 2024-10-04 16:18:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-04 16:18:51 --> Input Class Initialized
INFO - 2024-10-04 16:18:51 --> Language Class Initialized
INFO - 2024-10-04 16:18:51 --> Language Class Initialized
INFO - 2024-10-04 16:18:51 --> Config Class Initialized
INFO - 2024-10-04 16:18:51 --> Loader Class Initialized
INFO - 2024-10-04 16:18:51 --> Helper loaded: url_helper
INFO - 2024-10-04 16:18:51 --> Helper loaded: file_helper
INFO - 2024-10-04 16:18:51 --> Helper loaded: form_helper
INFO - 2024-10-04 16:18:51 --> Helper loaded: my_helper
INFO - 2024-10-04 16:18:51 --> Database Driver Class Initialized
INFO - 2024-10-04 16:18:51 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-04 16:18:51 --> Controller Class Initialized
DEBUG - 2024-10-04 16:18:51 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_catatan_guru/views/list.php
DEBUG - 2024-10-04 16:18:51 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-10-04 16:18:51 --> Final output sent to browser
DEBUG - 2024-10-04 16:18:51 --> Total execution time: 0.1508
INFO - 2024-10-04 16:18:52 --> Config Class Initialized
INFO - 2024-10-04 16:18:52 --> Hooks Class Initialized
DEBUG - 2024-10-04 16:18:52 --> UTF-8 Support Enabled
INFO - 2024-10-04 16:18:52 --> Utf8 Class Initialized
INFO - 2024-10-04 16:18:52 --> URI Class Initialized
INFO - 2024-10-04 16:18:52 --> Router Class Initialized
INFO - 2024-10-04 16:18:52 --> Output Class Initialized
INFO - 2024-10-04 16:18:52 --> Security Class Initialized
DEBUG - 2024-10-04 16:18:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-04 16:18:52 --> Input Class Initialized
INFO - 2024-10-04 16:18:52 --> Language Class Initialized
INFO - 2024-10-04 16:18:52 --> Language Class Initialized
INFO - 2024-10-04 16:18:52 --> Config Class Initialized
INFO - 2024-10-04 16:18:52 --> Loader Class Initialized
INFO - 2024-10-04 16:18:52 --> Helper loaded: url_helper
INFO - 2024-10-04 16:18:52 --> Helper loaded: file_helper
INFO - 2024-10-04 16:18:52 --> Helper loaded: form_helper
INFO - 2024-10-04 16:18:52 --> Helper loaded: my_helper
INFO - 2024-10-04 16:18:52 --> Database Driver Class Initialized
INFO - 2024-10-04 16:18:52 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-04 16:18:52 --> Controller Class Initialized
INFO - 2024-10-04 16:18:52 --> Final output sent to browser
DEBUG - 2024-10-04 16:18:52 --> Total execution time: 0.0357
INFO - 2024-10-04 16:26:15 --> Config Class Initialized
INFO - 2024-10-04 16:26:15 --> Hooks Class Initialized
DEBUG - 2024-10-04 16:26:15 --> UTF-8 Support Enabled
INFO - 2024-10-04 16:26:15 --> Utf8 Class Initialized
INFO - 2024-10-04 16:26:15 --> URI Class Initialized
INFO - 2024-10-04 16:26:15 --> Router Class Initialized
INFO - 2024-10-04 16:26:15 --> Output Class Initialized
INFO - 2024-10-04 16:26:15 --> Security Class Initialized
DEBUG - 2024-10-04 16:26:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-04 16:26:15 --> Input Class Initialized
INFO - 2024-10-04 16:26:15 --> Language Class Initialized
INFO - 2024-10-04 16:26:15 --> Language Class Initialized
INFO - 2024-10-04 16:26:15 --> Config Class Initialized
INFO - 2024-10-04 16:26:15 --> Loader Class Initialized
INFO - 2024-10-04 16:26:15 --> Helper loaded: url_helper
INFO - 2024-10-04 16:26:15 --> Helper loaded: file_helper
INFO - 2024-10-04 16:26:15 --> Helper loaded: form_helper
INFO - 2024-10-04 16:26:15 --> Helper loaded: my_helper
INFO - 2024-10-04 16:26:15 --> Database Driver Class Initialized
INFO - 2024-10-04 16:26:15 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-04 16:26:15 --> Controller Class Initialized
INFO - 2024-10-04 16:26:15 --> Final output sent to browser
DEBUG - 2024-10-04 16:26:15 --> Total execution time: 0.0874
INFO - 2024-10-04 16:26:22 --> Config Class Initialized
INFO - 2024-10-04 16:26:22 --> Hooks Class Initialized
DEBUG - 2024-10-04 16:26:22 --> UTF-8 Support Enabled
INFO - 2024-10-04 16:26:22 --> Utf8 Class Initialized
INFO - 2024-10-04 16:26:22 --> URI Class Initialized
INFO - 2024-10-04 16:26:22 --> Router Class Initialized
INFO - 2024-10-04 16:26:22 --> Output Class Initialized
INFO - 2024-10-04 16:26:22 --> Security Class Initialized
DEBUG - 2024-10-04 16:26:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-04 16:26:22 --> Input Class Initialized
INFO - 2024-10-04 16:26:22 --> Language Class Initialized
INFO - 2024-10-04 16:26:22 --> Language Class Initialized
INFO - 2024-10-04 16:26:22 --> Config Class Initialized
INFO - 2024-10-04 16:26:22 --> Loader Class Initialized
INFO - 2024-10-04 16:26:22 --> Helper loaded: url_helper
INFO - 2024-10-04 16:26:22 --> Helper loaded: file_helper
INFO - 2024-10-04 16:26:22 --> Helper loaded: form_helper
INFO - 2024-10-04 16:26:22 --> Helper loaded: my_helper
INFO - 2024-10-04 16:26:22 --> Database Driver Class Initialized
INFO - 2024-10-04 16:26:22 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-04 16:26:22 --> Controller Class Initialized
INFO - 2024-10-04 16:26:22 --> Final output sent to browser
DEBUG - 2024-10-04 16:26:22 --> Total execution time: 0.1149
INFO - 2024-10-04 16:26:24 --> Config Class Initialized
INFO - 2024-10-04 16:26:24 --> Hooks Class Initialized
DEBUG - 2024-10-04 16:26:24 --> UTF-8 Support Enabled
INFO - 2024-10-04 16:26:24 --> Utf8 Class Initialized
INFO - 2024-10-04 16:26:24 --> URI Class Initialized
INFO - 2024-10-04 16:26:24 --> Router Class Initialized
INFO - 2024-10-04 16:26:24 --> Output Class Initialized
INFO - 2024-10-04 16:26:24 --> Security Class Initialized
DEBUG - 2024-10-04 16:26:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-04 16:26:24 --> Input Class Initialized
INFO - 2024-10-04 16:26:24 --> Language Class Initialized
INFO - 2024-10-04 16:26:24 --> Language Class Initialized
INFO - 2024-10-04 16:26:24 --> Config Class Initialized
INFO - 2024-10-04 16:26:24 --> Loader Class Initialized
INFO - 2024-10-04 16:26:24 --> Helper loaded: url_helper
INFO - 2024-10-04 16:26:24 --> Helper loaded: file_helper
INFO - 2024-10-04 16:26:24 --> Helper loaded: form_helper
INFO - 2024-10-04 16:26:24 --> Helper loaded: my_helper
INFO - 2024-10-04 16:26:24 --> Database Driver Class Initialized
INFO - 2024-10-04 16:26:24 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-04 16:26:24 --> Controller Class Initialized
DEBUG - 2024-10-04 16:26:24 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/view_mapel/views/v_view_mapel.php
DEBUG - 2024-10-04 16:26:24 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-10-04 16:26:24 --> Final output sent to browser
DEBUG - 2024-10-04 16:26:24 --> Total execution time: 0.0453
INFO - 2024-10-04 16:26:28 --> Config Class Initialized
INFO - 2024-10-04 16:26:28 --> Hooks Class Initialized
DEBUG - 2024-10-04 16:26:28 --> UTF-8 Support Enabled
INFO - 2024-10-04 16:26:28 --> Utf8 Class Initialized
INFO - 2024-10-04 16:26:28 --> URI Class Initialized
INFO - 2024-10-04 16:26:28 --> Router Class Initialized
INFO - 2024-10-04 16:26:28 --> Output Class Initialized
INFO - 2024-10-04 16:26:28 --> Security Class Initialized
DEBUG - 2024-10-04 16:26:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-04 16:26:28 --> Input Class Initialized
INFO - 2024-10-04 16:26:28 --> Language Class Initialized
INFO - 2024-10-04 16:26:28 --> Language Class Initialized
INFO - 2024-10-04 16:26:28 --> Config Class Initialized
INFO - 2024-10-04 16:26:28 --> Loader Class Initialized
INFO - 2024-10-04 16:26:28 --> Helper loaded: url_helper
INFO - 2024-10-04 16:26:28 --> Helper loaded: file_helper
INFO - 2024-10-04 16:26:28 --> Helper loaded: form_helper
INFO - 2024-10-04 16:26:28 --> Helper loaded: my_helper
INFO - 2024-10-04 16:26:28 --> Database Driver Class Initialized
INFO - 2024-10-04 16:26:28 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-04 16:26:28 --> Controller Class Initialized
DEBUG - 2024-10-04 16:26:28 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/views/list.php
DEBUG - 2024-10-04 16:26:28 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-10-04 16:26:28 --> Final output sent to browser
DEBUG - 2024-10-04 16:26:28 --> Total execution time: 0.0459
INFO - 2024-10-04 16:26:28 --> Config Class Initialized
INFO - 2024-10-04 16:26:28 --> Hooks Class Initialized
DEBUG - 2024-10-04 16:26:28 --> UTF-8 Support Enabled
INFO - 2024-10-04 16:26:28 --> Utf8 Class Initialized
INFO - 2024-10-04 16:26:28 --> URI Class Initialized
INFO - 2024-10-04 16:26:28 --> Router Class Initialized
INFO - 2024-10-04 16:26:28 --> Output Class Initialized
INFO - 2024-10-04 16:26:28 --> Security Class Initialized
DEBUG - 2024-10-04 16:26:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-04 16:26:28 --> Input Class Initialized
INFO - 2024-10-04 16:26:28 --> Language Class Initialized
INFO - 2024-10-04 16:26:28 --> Language Class Initialized
INFO - 2024-10-04 16:26:28 --> Config Class Initialized
INFO - 2024-10-04 16:26:28 --> Loader Class Initialized
INFO - 2024-10-04 16:26:28 --> Helper loaded: url_helper
INFO - 2024-10-04 16:26:28 --> Helper loaded: file_helper
INFO - 2024-10-04 16:26:28 --> Helper loaded: form_helper
INFO - 2024-10-04 16:26:28 --> Helper loaded: my_helper
INFO - 2024-10-04 16:26:28 --> Database Driver Class Initialized
INFO - 2024-10-04 16:26:28 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-04 16:26:28 --> Controller Class Initialized
INFO - 2024-10-04 16:26:31 --> Config Class Initialized
INFO - 2024-10-04 16:26:31 --> Hooks Class Initialized
DEBUG - 2024-10-04 16:26:31 --> UTF-8 Support Enabled
INFO - 2024-10-04 16:26:31 --> Utf8 Class Initialized
INFO - 2024-10-04 16:26:31 --> URI Class Initialized
INFO - 2024-10-04 16:26:31 --> Router Class Initialized
INFO - 2024-10-04 16:26:31 --> Output Class Initialized
INFO - 2024-10-04 16:26:31 --> Security Class Initialized
DEBUG - 2024-10-04 16:26:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-04 16:26:31 --> Input Class Initialized
INFO - 2024-10-04 16:26:31 --> Language Class Initialized
INFO - 2024-10-04 16:26:31 --> Language Class Initialized
INFO - 2024-10-04 16:26:31 --> Config Class Initialized
INFO - 2024-10-04 16:26:31 --> Loader Class Initialized
INFO - 2024-10-04 16:26:31 --> Helper loaded: url_helper
INFO - 2024-10-04 16:26:31 --> Helper loaded: file_helper
INFO - 2024-10-04 16:26:31 --> Helper loaded: form_helper
INFO - 2024-10-04 16:26:31 --> Helper loaded: my_helper
INFO - 2024-10-04 16:26:31 --> Database Driver Class Initialized
INFO - 2024-10-04 16:26:31 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-04 16:26:31 --> Controller Class Initialized
INFO - 2024-10-04 16:26:31 --> Final output sent to browser
DEBUG - 2024-10-04 16:26:31 --> Total execution time: 0.0372
INFO - 2024-10-04 16:26:33 --> Config Class Initialized
INFO - 2024-10-04 16:26:33 --> Hooks Class Initialized
DEBUG - 2024-10-04 16:26:33 --> UTF-8 Support Enabled
INFO - 2024-10-04 16:26:33 --> Utf8 Class Initialized
INFO - 2024-10-04 16:26:33 --> URI Class Initialized
INFO - 2024-10-04 16:26:33 --> Router Class Initialized
INFO - 2024-10-04 16:26:33 --> Output Class Initialized
INFO - 2024-10-04 16:26:33 --> Security Class Initialized
DEBUG - 2024-10-04 16:26:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-04 16:26:33 --> Input Class Initialized
INFO - 2024-10-04 16:26:33 --> Language Class Initialized
INFO - 2024-10-04 16:26:33 --> Language Class Initialized
INFO - 2024-10-04 16:26:33 --> Config Class Initialized
INFO - 2024-10-04 16:26:33 --> Loader Class Initialized
INFO - 2024-10-04 16:26:33 --> Helper loaded: url_helper
INFO - 2024-10-04 16:26:33 --> Helper loaded: file_helper
INFO - 2024-10-04 16:26:33 --> Helper loaded: form_helper
INFO - 2024-10-04 16:26:33 --> Helper loaded: my_helper
INFO - 2024-10-04 16:26:33 --> Database Driver Class Initialized
INFO - 2024-10-04 16:26:33 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-04 16:26:33 --> Controller Class Initialized
DEBUG - 2024-10-04 16:26:33 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/view_mapel/views/v_view_mapel.php
DEBUG - 2024-10-04 16:26:33 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-10-04 16:26:33 --> Final output sent to browser
DEBUG - 2024-10-04 16:26:33 --> Total execution time: 0.0332
INFO - 2024-10-04 16:26:37 --> Config Class Initialized
INFO - 2024-10-04 16:26:37 --> Hooks Class Initialized
DEBUG - 2024-10-04 16:26:37 --> UTF-8 Support Enabled
INFO - 2024-10-04 16:26:37 --> Utf8 Class Initialized
INFO - 2024-10-04 16:26:37 --> URI Class Initialized
INFO - 2024-10-04 16:26:37 --> Router Class Initialized
INFO - 2024-10-04 16:26:37 --> Output Class Initialized
INFO - 2024-10-04 16:26:37 --> Security Class Initialized
DEBUG - 2024-10-04 16:26:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-04 16:26:37 --> Input Class Initialized
INFO - 2024-10-04 16:26:37 --> Language Class Initialized
INFO - 2024-10-04 16:26:37 --> Language Class Initialized
INFO - 2024-10-04 16:26:37 --> Config Class Initialized
INFO - 2024-10-04 16:26:37 --> Loader Class Initialized
INFO - 2024-10-04 16:26:37 --> Helper loaded: url_helper
INFO - 2024-10-04 16:26:37 --> Helper loaded: file_helper
INFO - 2024-10-04 16:26:37 --> Helper loaded: form_helper
INFO - 2024-10-04 16:26:37 --> Helper loaded: my_helper
INFO - 2024-10-04 16:26:37 --> Database Driver Class Initialized
INFO - 2024-10-04 16:26:37 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-04 16:26:37 --> Controller Class Initialized
DEBUG - 2024-10-04 16:26:37 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_catatan_guru/views/list.php
DEBUG - 2024-10-04 16:26:37 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-10-04 16:26:37 --> Final output sent to browser
DEBUG - 2024-10-04 16:26:37 --> Total execution time: 0.0436
INFO - 2024-10-04 16:26:39 --> Config Class Initialized
INFO - 2024-10-04 16:26:39 --> Hooks Class Initialized
DEBUG - 2024-10-04 16:26:39 --> UTF-8 Support Enabled
INFO - 2024-10-04 16:26:39 --> Utf8 Class Initialized
INFO - 2024-10-04 16:26:39 --> URI Class Initialized
INFO - 2024-10-04 16:26:39 --> Router Class Initialized
INFO - 2024-10-04 16:26:39 --> Output Class Initialized
INFO - 2024-10-04 16:26:39 --> Security Class Initialized
DEBUG - 2024-10-04 16:26:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-04 16:26:39 --> Input Class Initialized
INFO - 2024-10-04 16:26:39 --> Language Class Initialized
INFO - 2024-10-04 16:26:39 --> Language Class Initialized
INFO - 2024-10-04 16:26:39 --> Config Class Initialized
INFO - 2024-10-04 16:26:39 --> Loader Class Initialized
INFO - 2024-10-04 16:26:39 --> Helper loaded: url_helper
INFO - 2024-10-04 16:26:39 --> Helper loaded: file_helper
INFO - 2024-10-04 16:26:39 --> Helper loaded: form_helper
INFO - 2024-10-04 16:26:39 --> Helper loaded: my_helper
INFO - 2024-10-04 16:26:39 --> Database Driver Class Initialized
INFO - 2024-10-04 16:26:39 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-04 16:26:39 --> Controller Class Initialized
INFO - 2024-10-04 16:26:39 --> Final output sent to browser
DEBUG - 2024-10-04 16:26:39 --> Total execution time: 0.0407
INFO - 2024-10-04 16:31:36 --> Config Class Initialized
INFO - 2024-10-04 16:31:36 --> Hooks Class Initialized
DEBUG - 2024-10-04 16:31:36 --> UTF-8 Support Enabled
INFO - 2024-10-04 16:31:36 --> Utf8 Class Initialized
INFO - 2024-10-04 16:31:36 --> URI Class Initialized
INFO - 2024-10-04 16:31:36 --> Router Class Initialized
INFO - 2024-10-04 16:31:36 --> Output Class Initialized
INFO - 2024-10-04 16:31:36 --> Security Class Initialized
DEBUG - 2024-10-04 16:31:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-04 16:31:36 --> Input Class Initialized
INFO - 2024-10-04 16:31:36 --> Language Class Initialized
INFO - 2024-10-04 16:31:36 --> Language Class Initialized
INFO - 2024-10-04 16:31:36 --> Config Class Initialized
INFO - 2024-10-04 16:31:36 --> Loader Class Initialized
INFO - 2024-10-04 16:31:36 --> Helper loaded: url_helper
INFO - 2024-10-04 16:31:36 --> Helper loaded: file_helper
INFO - 2024-10-04 16:31:36 --> Helper loaded: form_helper
INFO - 2024-10-04 16:31:36 --> Helper loaded: my_helper
INFO - 2024-10-04 16:31:36 --> Database Driver Class Initialized
INFO - 2024-10-04 16:31:36 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-04 16:31:36 --> Controller Class Initialized
INFO - 2024-10-04 16:31:36 --> Final output sent to browser
DEBUG - 2024-10-04 16:31:36 --> Total execution time: 0.0572
INFO - 2024-10-04 16:31:42 --> Config Class Initialized
INFO - 2024-10-04 16:31:42 --> Hooks Class Initialized
DEBUG - 2024-10-04 16:31:42 --> UTF-8 Support Enabled
INFO - 2024-10-04 16:31:42 --> Utf8 Class Initialized
INFO - 2024-10-04 16:31:42 --> URI Class Initialized
INFO - 2024-10-04 16:31:42 --> Router Class Initialized
INFO - 2024-10-04 16:31:42 --> Output Class Initialized
INFO - 2024-10-04 16:31:42 --> Security Class Initialized
DEBUG - 2024-10-04 16:31:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-04 16:31:42 --> Input Class Initialized
INFO - 2024-10-04 16:31:42 --> Language Class Initialized
INFO - 2024-10-04 16:31:42 --> Language Class Initialized
INFO - 2024-10-04 16:31:42 --> Config Class Initialized
INFO - 2024-10-04 16:31:42 --> Loader Class Initialized
INFO - 2024-10-04 16:31:42 --> Helper loaded: url_helper
INFO - 2024-10-04 16:31:42 --> Helper loaded: file_helper
INFO - 2024-10-04 16:31:42 --> Helper loaded: form_helper
INFO - 2024-10-04 16:31:42 --> Helper loaded: my_helper
INFO - 2024-10-04 16:31:42 --> Database Driver Class Initialized
INFO - 2024-10-04 16:31:42 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-04 16:31:42 --> Controller Class Initialized
DEBUG - 2024-10-04 16:31:42 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/view_mapel/views/v_view_mapel.php
DEBUG - 2024-10-04 16:31:42 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-10-04 16:31:42 --> Final output sent to browser
DEBUG - 2024-10-04 16:31:42 --> Total execution time: 0.0385
INFO - 2024-10-04 16:31:47 --> Config Class Initialized
INFO - 2024-10-04 16:31:47 --> Hooks Class Initialized
DEBUG - 2024-10-04 16:31:47 --> UTF-8 Support Enabled
INFO - 2024-10-04 16:31:47 --> Utf8 Class Initialized
INFO - 2024-10-04 16:31:47 --> URI Class Initialized
INFO - 2024-10-04 16:31:47 --> Router Class Initialized
INFO - 2024-10-04 16:31:47 --> Output Class Initialized
INFO - 2024-10-04 16:31:47 --> Security Class Initialized
DEBUG - 2024-10-04 16:31:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-04 16:31:47 --> Input Class Initialized
INFO - 2024-10-04 16:31:47 --> Language Class Initialized
INFO - 2024-10-04 16:31:47 --> Language Class Initialized
INFO - 2024-10-04 16:31:47 --> Config Class Initialized
INFO - 2024-10-04 16:31:47 --> Loader Class Initialized
INFO - 2024-10-04 16:31:47 --> Helper loaded: url_helper
INFO - 2024-10-04 16:31:47 --> Helper loaded: file_helper
INFO - 2024-10-04 16:31:47 --> Helper loaded: form_helper
INFO - 2024-10-04 16:31:47 --> Helper loaded: my_helper
INFO - 2024-10-04 16:31:47 --> Database Driver Class Initialized
INFO - 2024-10-04 16:31:47 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-04 16:31:47 --> Controller Class Initialized
DEBUG - 2024-10-04 16:31:47 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_catatan_guru/views/list.php
DEBUG - 2024-10-04 16:31:47 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-10-04 16:31:47 --> Final output sent to browser
DEBUG - 2024-10-04 16:31:47 --> Total execution time: 0.0545
INFO - 2024-10-04 16:31:48 --> Config Class Initialized
INFO - 2024-10-04 16:31:48 --> Hooks Class Initialized
DEBUG - 2024-10-04 16:31:48 --> UTF-8 Support Enabled
INFO - 2024-10-04 16:31:48 --> Utf8 Class Initialized
INFO - 2024-10-04 16:31:48 --> URI Class Initialized
INFO - 2024-10-04 16:31:48 --> Router Class Initialized
INFO - 2024-10-04 16:31:48 --> Output Class Initialized
INFO - 2024-10-04 16:31:48 --> Security Class Initialized
DEBUG - 2024-10-04 16:31:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-04 16:31:48 --> Input Class Initialized
INFO - 2024-10-04 16:31:48 --> Language Class Initialized
INFO - 2024-10-04 16:31:48 --> Language Class Initialized
INFO - 2024-10-04 16:31:48 --> Config Class Initialized
INFO - 2024-10-04 16:31:48 --> Loader Class Initialized
INFO - 2024-10-04 16:31:48 --> Helper loaded: url_helper
INFO - 2024-10-04 16:31:48 --> Helper loaded: file_helper
INFO - 2024-10-04 16:31:48 --> Helper loaded: form_helper
INFO - 2024-10-04 16:31:48 --> Helper loaded: my_helper
INFO - 2024-10-04 16:31:48 --> Database Driver Class Initialized
INFO - 2024-10-04 16:31:48 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-04 16:31:48 --> Controller Class Initialized
INFO - 2024-10-04 16:31:48 --> Final output sent to browser
DEBUG - 2024-10-04 16:31:48 --> Total execution time: 0.0400
INFO - 2024-10-04 16:31:51 --> Config Class Initialized
INFO - 2024-10-04 16:31:51 --> Hooks Class Initialized
DEBUG - 2024-10-04 16:31:51 --> UTF-8 Support Enabled
INFO - 2024-10-04 16:31:51 --> Utf8 Class Initialized
INFO - 2024-10-04 16:31:51 --> URI Class Initialized
INFO - 2024-10-04 16:31:51 --> Router Class Initialized
INFO - 2024-10-04 16:31:51 --> Output Class Initialized
INFO - 2024-10-04 16:31:51 --> Security Class Initialized
DEBUG - 2024-10-04 16:31:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-04 16:31:51 --> Input Class Initialized
INFO - 2024-10-04 16:31:51 --> Language Class Initialized
INFO - 2024-10-04 16:31:51 --> Language Class Initialized
INFO - 2024-10-04 16:31:51 --> Config Class Initialized
INFO - 2024-10-04 16:31:51 --> Loader Class Initialized
INFO - 2024-10-04 16:31:51 --> Helper loaded: url_helper
INFO - 2024-10-04 16:31:51 --> Helper loaded: file_helper
INFO - 2024-10-04 16:31:51 --> Helper loaded: form_helper
INFO - 2024-10-04 16:31:51 --> Helper loaded: my_helper
INFO - 2024-10-04 16:31:51 --> Database Driver Class Initialized
INFO - 2024-10-04 16:31:51 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-04 16:31:51 --> Controller Class Initialized
DEBUG - 2024-10-04 16:31:51 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/view_mapel/views/v_view_mapel.php
DEBUG - 2024-10-04 16:31:51 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-10-04 16:31:51 --> Final output sent to browser
DEBUG - 2024-10-04 16:31:51 --> Total execution time: 0.0290
INFO - 2024-10-04 16:31:55 --> Config Class Initialized
INFO - 2024-10-04 16:31:55 --> Hooks Class Initialized
DEBUG - 2024-10-04 16:31:55 --> UTF-8 Support Enabled
INFO - 2024-10-04 16:31:55 --> Utf8 Class Initialized
INFO - 2024-10-04 16:31:55 --> URI Class Initialized
INFO - 2024-10-04 16:31:55 --> Router Class Initialized
INFO - 2024-10-04 16:31:55 --> Output Class Initialized
INFO - 2024-10-04 16:31:55 --> Security Class Initialized
DEBUG - 2024-10-04 16:31:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-04 16:31:55 --> Input Class Initialized
INFO - 2024-10-04 16:31:55 --> Language Class Initialized
INFO - 2024-10-04 16:31:55 --> Language Class Initialized
INFO - 2024-10-04 16:31:55 --> Config Class Initialized
INFO - 2024-10-04 16:31:55 --> Loader Class Initialized
INFO - 2024-10-04 16:31:55 --> Helper loaded: url_helper
INFO - 2024-10-04 16:31:55 --> Helper loaded: file_helper
INFO - 2024-10-04 16:31:55 --> Helper loaded: form_helper
INFO - 2024-10-04 16:31:55 --> Helper loaded: my_helper
INFO - 2024-10-04 16:31:55 --> Database Driver Class Initialized
INFO - 2024-10-04 16:31:55 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-04 16:31:55 --> Controller Class Initialized
DEBUG - 2024-10-04 16:31:55 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/views/list.php
DEBUG - 2024-10-04 16:31:55 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-10-04 16:31:55 --> Final output sent to browser
DEBUG - 2024-10-04 16:31:55 --> Total execution time: 0.0330
INFO - 2024-10-04 16:31:55 --> Config Class Initialized
INFO - 2024-10-04 16:31:55 --> Hooks Class Initialized
DEBUG - 2024-10-04 16:31:55 --> UTF-8 Support Enabled
INFO - 2024-10-04 16:31:55 --> Utf8 Class Initialized
INFO - 2024-10-04 16:31:55 --> URI Class Initialized
INFO - 2024-10-04 16:31:55 --> Router Class Initialized
INFO - 2024-10-04 16:31:55 --> Output Class Initialized
INFO - 2024-10-04 16:31:55 --> Security Class Initialized
DEBUG - 2024-10-04 16:31:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-04 16:31:55 --> Input Class Initialized
INFO - 2024-10-04 16:31:55 --> Language Class Initialized
INFO - 2024-10-04 16:31:55 --> Language Class Initialized
INFO - 2024-10-04 16:31:55 --> Config Class Initialized
INFO - 2024-10-04 16:31:55 --> Loader Class Initialized
INFO - 2024-10-04 16:31:55 --> Helper loaded: url_helper
INFO - 2024-10-04 16:31:55 --> Helper loaded: file_helper
INFO - 2024-10-04 16:31:55 --> Helper loaded: form_helper
INFO - 2024-10-04 16:31:55 --> Helper loaded: my_helper
INFO - 2024-10-04 16:31:55 --> Database Driver Class Initialized
INFO - 2024-10-04 16:31:55 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-04 16:31:55 --> Controller Class Initialized
INFO - 2024-10-04 16:31:58 --> Config Class Initialized
INFO - 2024-10-04 16:31:58 --> Hooks Class Initialized
DEBUG - 2024-10-04 16:31:58 --> UTF-8 Support Enabled
INFO - 2024-10-04 16:31:58 --> Utf8 Class Initialized
INFO - 2024-10-04 16:31:58 --> URI Class Initialized
INFO - 2024-10-04 16:31:58 --> Router Class Initialized
INFO - 2024-10-04 16:31:58 --> Output Class Initialized
INFO - 2024-10-04 16:31:58 --> Security Class Initialized
DEBUG - 2024-10-04 16:31:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-04 16:31:58 --> Input Class Initialized
INFO - 2024-10-04 16:31:58 --> Language Class Initialized
INFO - 2024-10-04 16:31:58 --> Language Class Initialized
INFO - 2024-10-04 16:31:58 --> Config Class Initialized
INFO - 2024-10-04 16:31:58 --> Loader Class Initialized
INFO - 2024-10-04 16:31:58 --> Helper loaded: url_helper
INFO - 2024-10-04 16:31:58 --> Helper loaded: file_helper
INFO - 2024-10-04 16:31:58 --> Helper loaded: form_helper
INFO - 2024-10-04 16:31:58 --> Helper loaded: my_helper
INFO - 2024-10-04 16:31:58 --> Database Driver Class Initialized
INFO - 2024-10-04 16:31:58 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-04 16:31:58 --> Controller Class Initialized
INFO - 2024-10-04 16:31:58 --> Final output sent to browser
DEBUG - 2024-10-04 16:31:58 --> Total execution time: 0.0322
INFO - 2024-10-04 16:32:00 --> Config Class Initialized
INFO - 2024-10-04 16:32:00 --> Hooks Class Initialized
DEBUG - 2024-10-04 16:32:00 --> UTF-8 Support Enabled
INFO - 2024-10-04 16:32:00 --> Utf8 Class Initialized
INFO - 2024-10-04 16:32:00 --> URI Class Initialized
INFO - 2024-10-04 16:32:00 --> Router Class Initialized
INFO - 2024-10-04 16:32:00 --> Output Class Initialized
INFO - 2024-10-04 16:32:00 --> Security Class Initialized
DEBUG - 2024-10-04 16:32:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-04 16:32:00 --> Input Class Initialized
INFO - 2024-10-04 16:32:00 --> Language Class Initialized
INFO - 2024-10-04 16:32:00 --> Language Class Initialized
INFO - 2024-10-04 16:32:00 --> Config Class Initialized
INFO - 2024-10-04 16:32:00 --> Loader Class Initialized
INFO - 2024-10-04 16:32:00 --> Helper loaded: url_helper
INFO - 2024-10-04 16:32:00 --> Helper loaded: file_helper
INFO - 2024-10-04 16:32:00 --> Helper loaded: form_helper
INFO - 2024-10-04 16:32:00 --> Helper loaded: my_helper
INFO - 2024-10-04 16:32:00 --> Database Driver Class Initialized
INFO - 2024-10-04 16:32:00 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-04 16:32:00 --> Controller Class Initialized
DEBUG - 2024-10-04 16:32:00 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/view_mapel/views/v_view_mapel.php
DEBUG - 2024-10-04 16:32:00 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-10-04 16:32:00 --> Final output sent to browser
DEBUG - 2024-10-04 16:32:00 --> Total execution time: 0.0872
INFO - 2024-10-04 16:32:03 --> Config Class Initialized
INFO - 2024-10-04 16:32:03 --> Hooks Class Initialized
DEBUG - 2024-10-04 16:32:03 --> UTF-8 Support Enabled
INFO - 2024-10-04 16:32:03 --> Utf8 Class Initialized
INFO - 2024-10-04 16:32:03 --> URI Class Initialized
INFO - 2024-10-04 16:32:03 --> Router Class Initialized
INFO - 2024-10-04 16:32:03 --> Output Class Initialized
INFO - 2024-10-04 16:32:03 --> Security Class Initialized
DEBUG - 2024-10-04 16:32:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-04 16:32:03 --> Input Class Initialized
INFO - 2024-10-04 16:32:03 --> Language Class Initialized
INFO - 2024-10-04 16:32:03 --> Language Class Initialized
INFO - 2024-10-04 16:32:03 --> Config Class Initialized
INFO - 2024-10-04 16:32:03 --> Loader Class Initialized
INFO - 2024-10-04 16:32:03 --> Helper loaded: url_helper
INFO - 2024-10-04 16:32:03 --> Helper loaded: file_helper
INFO - 2024-10-04 16:32:03 --> Helper loaded: form_helper
INFO - 2024-10-04 16:32:03 --> Helper loaded: my_helper
INFO - 2024-10-04 16:32:03 --> Database Driver Class Initialized
INFO - 2024-10-04 16:32:03 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-04 16:32:03 --> Controller Class Initialized
DEBUG - 2024-10-04 16:32:03 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/views/list.php
DEBUG - 2024-10-04 16:32:03 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-10-04 16:32:03 --> Final output sent to browser
DEBUG - 2024-10-04 16:32:03 --> Total execution time: 0.0424
INFO - 2024-10-04 16:32:03 --> Config Class Initialized
INFO - 2024-10-04 16:32:03 --> Hooks Class Initialized
DEBUG - 2024-10-04 16:32:03 --> UTF-8 Support Enabled
INFO - 2024-10-04 16:32:03 --> Utf8 Class Initialized
INFO - 2024-10-04 16:32:03 --> URI Class Initialized
INFO - 2024-10-04 16:32:03 --> Router Class Initialized
INFO - 2024-10-04 16:32:03 --> Output Class Initialized
INFO - 2024-10-04 16:32:03 --> Security Class Initialized
DEBUG - 2024-10-04 16:32:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-04 16:32:03 --> Input Class Initialized
INFO - 2024-10-04 16:32:03 --> Language Class Initialized
INFO - 2024-10-04 16:32:03 --> Language Class Initialized
INFO - 2024-10-04 16:32:03 --> Config Class Initialized
INFO - 2024-10-04 16:32:03 --> Loader Class Initialized
INFO - 2024-10-04 16:32:03 --> Helper loaded: url_helper
INFO - 2024-10-04 16:32:03 --> Helper loaded: file_helper
INFO - 2024-10-04 16:32:03 --> Helper loaded: form_helper
INFO - 2024-10-04 16:32:03 --> Helper loaded: my_helper
INFO - 2024-10-04 16:32:03 --> Database Driver Class Initialized
INFO - 2024-10-04 16:32:03 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-04 16:32:03 --> Controller Class Initialized
INFO - 2024-10-04 16:36:08 --> Config Class Initialized
INFO - 2024-10-04 16:36:08 --> Hooks Class Initialized
DEBUG - 2024-10-04 16:36:08 --> UTF-8 Support Enabled
INFO - 2024-10-04 16:36:08 --> Utf8 Class Initialized
INFO - 2024-10-04 16:36:08 --> URI Class Initialized
INFO - 2024-10-04 16:36:08 --> Router Class Initialized
INFO - 2024-10-04 16:36:08 --> Output Class Initialized
INFO - 2024-10-04 16:36:08 --> Security Class Initialized
DEBUG - 2024-10-04 16:36:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-04 16:36:08 --> Input Class Initialized
INFO - 2024-10-04 16:36:08 --> Language Class Initialized
INFO - 2024-10-04 16:36:08 --> Language Class Initialized
INFO - 2024-10-04 16:36:08 --> Config Class Initialized
INFO - 2024-10-04 16:36:08 --> Loader Class Initialized
INFO - 2024-10-04 16:36:08 --> Helper loaded: url_helper
INFO - 2024-10-04 16:36:08 --> Helper loaded: file_helper
INFO - 2024-10-04 16:36:08 --> Helper loaded: form_helper
INFO - 2024-10-04 16:36:08 --> Helper loaded: my_helper
INFO - 2024-10-04 16:36:08 --> Database Driver Class Initialized
INFO - 2024-10-04 16:36:09 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-04 16:36:09 --> Controller Class Initialized
DEBUG - 2024-10-04 16:36:09 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/views/list.php
DEBUG - 2024-10-04 16:36:09 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-10-04 16:36:09 --> Final output sent to browser
DEBUG - 2024-10-04 16:36:09 --> Total execution time: 0.0321
INFO - 2024-10-04 16:36:09 --> Config Class Initialized
INFO - 2024-10-04 16:36:09 --> Hooks Class Initialized
DEBUG - 2024-10-04 16:36:09 --> UTF-8 Support Enabled
INFO - 2024-10-04 16:36:09 --> Utf8 Class Initialized
INFO - 2024-10-04 16:36:09 --> URI Class Initialized
INFO - 2024-10-04 16:36:09 --> Router Class Initialized
INFO - 2024-10-04 16:36:09 --> Output Class Initialized
INFO - 2024-10-04 16:36:09 --> Security Class Initialized
DEBUG - 2024-10-04 16:36:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-04 16:36:09 --> Input Class Initialized
INFO - 2024-10-04 16:36:09 --> Language Class Initialized
INFO - 2024-10-04 16:36:09 --> Language Class Initialized
INFO - 2024-10-04 16:36:09 --> Config Class Initialized
INFO - 2024-10-04 16:36:09 --> Loader Class Initialized
INFO - 2024-10-04 16:36:09 --> Helper loaded: url_helper
INFO - 2024-10-04 16:36:09 --> Helper loaded: file_helper
INFO - 2024-10-04 16:36:09 --> Helper loaded: form_helper
INFO - 2024-10-04 16:36:09 --> Helper loaded: my_helper
INFO - 2024-10-04 16:36:09 --> Database Driver Class Initialized
INFO - 2024-10-04 16:36:09 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-04 16:36:09 --> Controller Class Initialized
INFO - 2024-10-04 16:36:15 --> Config Class Initialized
INFO - 2024-10-04 16:36:15 --> Hooks Class Initialized
DEBUG - 2024-10-04 16:36:15 --> UTF-8 Support Enabled
INFO - 2024-10-04 16:36:15 --> Utf8 Class Initialized
INFO - 2024-10-04 16:36:15 --> URI Class Initialized
DEBUG - 2024-10-04 16:36:15 --> No URI present. Default controller set.
INFO - 2024-10-04 16:36:15 --> Router Class Initialized
INFO - 2024-10-04 16:36:15 --> Output Class Initialized
INFO - 2024-10-04 16:36:15 --> Security Class Initialized
DEBUG - 2024-10-04 16:36:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-04 16:36:15 --> Input Class Initialized
INFO - 2024-10-04 16:36:15 --> Language Class Initialized
INFO - 2024-10-04 16:36:15 --> Language Class Initialized
INFO - 2024-10-04 16:36:15 --> Config Class Initialized
INFO - 2024-10-04 16:36:15 --> Loader Class Initialized
INFO - 2024-10-04 16:36:15 --> Helper loaded: url_helper
INFO - 2024-10-04 16:36:15 --> Helper loaded: file_helper
INFO - 2024-10-04 16:36:15 --> Helper loaded: form_helper
INFO - 2024-10-04 16:36:15 --> Helper loaded: my_helper
INFO - 2024-10-04 16:36:15 --> Database Driver Class Initialized
INFO - 2024-10-04 16:36:15 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-04 16:36:15 --> Controller Class Initialized
DEBUG - 2024-10-04 16:36:15 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/home/views/v_home_guru.php
DEBUG - 2024-10-04 16:36:15 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-10-04 16:36:15 --> Final output sent to browser
DEBUG - 2024-10-04 16:36:15 --> Total execution time: 0.0442
INFO - 2024-10-04 16:36:16 --> Config Class Initialized
INFO - 2024-10-04 16:36:16 --> Hooks Class Initialized
DEBUG - 2024-10-04 16:36:16 --> UTF-8 Support Enabled
INFO - 2024-10-04 16:36:16 --> Utf8 Class Initialized
INFO - 2024-10-04 16:36:16 --> URI Class Initialized
INFO - 2024-10-04 16:36:16 --> Router Class Initialized
INFO - 2024-10-04 16:36:16 --> Output Class Initialized
INFO - 2024-10-04 16:36:16 --> Security Class Initialized
DEBUG - 2024-10-04 16:36:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-04 16:36:16 --> Input Class Initialized
INFO - 2024-10-04 16:36:16 --> Language Class Initialized
INFO - 2024-10-04 16:36:16 --> Language Class Initialized
INFO - 2024-10-04 16:36:16 --> Config Class Initialized
INFO - 2024-10-04 16:36:16 --> Loader Class Initialized
INFO - 2024-10-04 16:36:16 --> Helper loaded: url_helper
INFO - 2024-10-04 16:36:16 --> Helper loaded: file_helper
INFO - 2024-10-04 16:36:16 --> Helper loaded: form_helper
INFO - 2024-10-04 16:36:16 --> Helper loaded: my_helper
INFO - 2024-10-04 16:36:16 --> Database Driver Class Initialized
INFO - 2024-10-04 16:36:16 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-04 16:36:16 --> Controller Class Initialized
DEBUG - 2024-10-04 16:36:16 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/view_mapel/views/v_view_mapel.php
DEBUG - 2024-10-04 16:36:16 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-10-04 16:36:16 --> Final output sent to browser
DEBUG - 2024-10-04 16:36:16 --> Total execution time: 0.0357
INFO - 2024-10-04 16:36:21 --> Config Class Initialized
INFO - 2024-10-04 16:36:21 --> Hooks Class Initialized
DEBUG - 2024-10-04 16:36:21 --> UTF-8 Support Enabled
INFO - 2024-10-04 16:36:21 --> Utf8 Class Initialized
INFO - 2024-10-04 16:36:21 --> URI Class Initialized
INFO - 2024-10-04 16:36:21 --> Router Class Initialized
INFO - 2024-10-04 16:36:21 --> Output Class Initialized
INFO - 2024-10-04 16:36:21 --> Security Class Initialized
DEBUG - 2024-10-04 16:36:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-04 16:36:21 --> Input Class Initialized
INFO - 2024-10-04 16:36:21 --> Language Class Initialized
INFO - 2024-10-04 16:36:21 --> Language Class Initialized
INFO - 2024-10-04 16:36:21 --> Config Class Initialized
INFO - 2024-10-04 16:36:21 --> Loader Class Initialized
INFO - 2024-10-04 16:36:21 --> Helper loaded: url_helper
INFO - 2024-10-04 16:36:21 --> Helper loaded: file_helper
INFO - 2024-10-04 16:36:21 --> Helper loaded: form_helper
INFO - 2024-10-04 16:36:21 --> Helper loaded: my_helper
INFO - 2024-10-04 16:36:21 --> Database Driver Class Initialized
INFO - 2024-10-04 16:36:21 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-04 16:36:21 --> Controller Class Initialized
DEBUG - 2024-10-04 16:36:21 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/views/list.php
DEBUG - 2024-10-04 16:36:21 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-10-04 16:36:21 --> Final output sent to browser
DEBUG - 2024-10-04 16:36:21 --> Total execution time: 0.0945
INFO - 2024-10-04 16:36:22 --> Config Class Initialized
INFO - 2024-10-04 16:36:22 --> Hooks Class Initialized
DEBUG - 2024-10-04 16:36:22 --> UTF-8 Support Enabled
INFO - 2024-10-04 16:36:22 --> Utf8 Class Initialized
INFO - 2024-10-04 16:36:22 --> URI Class Initialized
INFO - 2024-10-04 16:36:22 --> Router Class Initialized
INFO - 2024-10-04 16:36:22 --> Output Class Initialized
INFO - 2024-10-04 16:36:22 --> Security Class Initialized
DEBUG - 2024-10-04 16:36:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-04 16:36:22 --> Input Class Initialized
INFO - 2024-10-04 16:36:22 --> Language Class Initialized
INFO - 2024-10-04 16:36:22 --> Language Class Initialized
INFO - 2024-10-04 16:36:22 --> Config Class Initialized
INFO - 2024-10-04 16:36:22 --> Loader Class Initialized
INFO - 2024-10-04 16:36:22 --> Helper loaded: url_helper
INFO - 2024-10-04 16:36:22 --> Helper loaded: file_helper
INFO - 2024-10-04 16:36:22 --> Helper loaded: form_helper
INFO - 2024-10-04 16:36:22 --> Helper loaded: my_helper
INFO - 2024-10-04 16:36:22 --> Database Driver Class Initialized
INFO - 2024-10-04 16:36:22 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-04 16:36:22 --> Controller Class Initialized
INFO - 2024-10-04 16:36:26 --> Config Class Initialized
INFO - 2024-10-04 16:36:26 --> Hooks Class Initialized
DEBUG - 2024-10-04 16:36:26 --> UTF-8 Support Enabled
INFO - 2024-10-04 16:36:26 --> Utf8 Class Initialized
INFO - 2024-10-04 16:36:26 --> URI Class Initialized
INFO - 2024-10-04 16:36:26 --> Router Class Initialized
INFO - 2024-10-04 16:36:26 --> Output Class Initialized
INFO - 2024-10-04 16:36:26 --> Security Class Initialized
DEBUG - 2024-10-04 16:36:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-04 16:36:26 --> Input Class Initialized
INFO - 2024-10-04 16:36:26 --> Language Class Initialized
INFO - 2024-10-04 16:36:26 --> Language Class Initialized
INFO - 2024-10-04 16:36:26 --> Config Class Initialized
INFO - 2024-10-04 16:36:26 --> Loader Class Initialized
INFO - 2024-10-04 16:36:26 --> Helper loaded: url_helper
INFO - 2024-10-04 16:36:26 --> Helper loaded: file_helper
INFO - 2024-10-04 16:36:26 --> Helper loaded: form_helper
INFO - 2024-10-04 16:36:26 --> Helper loaded: my_helper
INFO - 2024-10-04 16:36:26 --> Database Driver Class Initialized
INFO - 2024-10-04 16:36:26 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-04 16:36:26 --> Controller Class Initialized
DEBUG - 2024-10-04 16:36:26 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/view_mapel/views/v_view_mapel.php
DEBUG - 2024-10-04 16:36:26 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-10-04 16:36:26 --> Final output sent to browser
DEBUG - 2024-10-04 16:36:26 --> Total execution time: 0.0532
INFO - 2024-10-04 16:36:27 --> Config Class Initialized
INFO - 2024-10-04 16:36:27 --> Hooks Class Initialized
DEBUG - 2024-10-04 16:36:27 --> UTF-8 Support Enabled
INFO - 2024-10-04 16:36:27 --> Utf8 Class Initialized
INFO - 2024-10-04 16:36:27 --> URI Class Initialized
DEBUG - 2024-10-04 16:36:27 --> No URI present. Default controller set.
INFO - 2024-10-04 16:36:27 --> Router Class Initialized
INFO - 2024-10-04 16:36:27 --> Output Class Initialized
INFO - 2024-10-04 16:36:27 --> Security Class Initialized
DEBUG - 2024-10-04 16:36:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-04 16:36:27 --> Input Class Initialized
INFO - 2024-10-04 16:36:27 --> Language Class Initialized
INFO - 2024-10-04 16:36:27 --> Language Class Initialized
INFO - 2024-10-04 16:36:27 --> Config Class Initialized
INFO - 2024-10-04 16:36:27 --> Loader Class Initialized
INFO - 2024-10-04 16:36:27 --> Helper loaded: url_helper
INFO - 2024-10-04 16:36:27 --> Helper loaded: file_helper
INFO - 2024-10-04 16:36:27 --> Helper loaded: form_helper
INFO - 2024-10-04 16:36:27 --> Helper loaded: my_helper
INFO - 2024-10-04 16:36:27 --> Database Driver Class Initialized
INFO - 2024-10-04 16:36:27 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-04 16:36:27 --> Controller Class Initialized
DEBUG - 2024-10-04 16:36:27 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/home/views/v_home_guru.php
DEBUG - 2024-10-04 16:36:27 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-10-04 16:36:27 --> Final output sent to browser
DEBUG - 2024-10-04 16:36:27 --> Total execution time: 0.0368
INFO - 2024-10-04 16:36:29 --> Config Class Initialized
INFO - 2024-10-04 16:36:29 --> Hooks Class Initialized
DEBUG - 2024-10-04 16:36:29 --> UTF-8 Support Enabled
INFO - 2024-10-04 16:36:29 --> Utf8 Class Initialized
INFO - 2024-10-04 16:36:29 --> URI Class Initialized
INFO - 2024-10-04 16:36:29 --> Router Class Initialized
INFO - 2024-10-04 16:36:29 --> Output Class Initialized
INFO - 2024-10-04 16:36:29 --> Security Class Initialized
DEBUG - 2024-10-04 16:36:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-04 16:36:29 --> Input Class Initialized
INFO - 2024-10-04 16:36:29 --> Language Class Initialized
INFO - 2024-10-04 16:36:29 --> Language Class Initialized
INFO - 2024-10-04 16:36:29 --> Config Class Initialized
INFO - 2024-10-04 16:36:29 --> Loader Class Initialized
INFO - 2024-10-04 16:36:29 --> Helper loaded: url_helper
INFO - 2024-10-04 16:36:29 --> Helper loaded: file_helper
INFO - 2024-10-04 16:36:29 --> Helper loaded: form_helper
INFO - 2024-10-04 16:36:29 --> Helper loaded: my_helper
INFO - 2024-10-04 16:36:29 --> Database Driver Class Initialized
INFO - 2024-10-04 16:36:29 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-04 16:36:29 --> Controller Class Initialized
DEBUG - 2024-10-04 16:36:29 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/view_mapel/views/v_view_mapel.php
DEBUG - 2024-10-04 16:36:29 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-10-04 16:36:29 --> Final output sent to browser
DEBUG - 2024-10-04 16:36:29 --> Total execution time: 0.0352
INFO - 2024-10-04 17:02:39 --> Config Class Initialized
INFO - 2024-10-04 17:02:39 --> Hooks Class Initialized
DEBUG - 2024-10-04 17:02:39 --> UTF-8 Support Enabled
INFO - 2024-10-04 17:02:39 --> Utf8 Class Initialized
INFO - 2024-10-04 17:02:39 --> URI Class Initialized
INFO - 2024-10-04 17:02:39 --> Router Class Initialized
INFO - 2024-10-04 17:02:39 --> Output Class Initialized
INFO - 2024-10-04 17:02:39 --> Security Class Initialized
DEBUG - 2024-10-04 17:02:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-04 17:02:39 --> Input Class Initialized
INFO - 2024-10-04 17:02:39 --> Language Class Initialized
INFO - 2024-10-04 17:02:39 --> Language Class Initialized
INFO - 2024-10-04 17:02:39 --> Config Class Initialized
INFO - 2024-10-04 17:02:39 --> Loader Class Initialized
INFO - 2024-10-04 17:02:39 --> Helper loaded: url_helper
INFO - 2024-10-04 17:02:39 --> Helper loaded: file_helper
INFO - 2024-10-04 17:02:39 --> Helper loaded: form_helper
INFO - 2024-10-04 17:02:39 --> Helper loaded: my_helper
INFO - 2024-10-04 17:02:39 --> Database Driver Class Initialized
INFO - 2024-10-04 17:02:39 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-04 17:02:39 --> Controller Class Initialized
DEBUG - 2024-10-04 17:02:39 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/view_mapel/views/v_view_mapel.php
DEBUG - 2024-10-04 17:02:39 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-10-04 17:02:39 --> Final output sent to browser
DEBUG - 2024-10-04 17:02:39 --> Total execution time: 0.0431
INFO - 2024-10-04 17:02:46 --> Config Class Initialized
INFO - 2024-10-04 17:02:46 --> Hooks Class Initialized
DEBUG - 2024-10-04 17:02:46 --> UTF-8 Support Enabled
INFO - 2024-10-04 17:02:46 --> Utf8 Class Initialized
INFO - 2024-10-04 17:02:46 --> URI Class Initialized
DEBUG - 2024-10-04 17:02:46 --> No URI present. Default controller set.
INFO - 2024-10-04 17:02:46 --> Router Class Initialized
INFO - 2024-10-04 17:02:46 --> Output Class Initialized
INFO - 2024-10-04 17:02:46 --> Security Class Initialized
DEBUG - 2024-10-04 17:02:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-04 17:02:46 --> Input Class Initialized
INFO - 2024-10-04 17:02:46 --> Language Class Initialized
INFO - 2024-10-04 17:02:46 --> Language Class Initialized
INFO - 2024-10-04 17:02:46 --> Config Class Initialized
INFO - 2024-10-04 17:02:46 --> Loader Class Initialized
INFO - 2024-10-04 17:02:46 --> Helper loaded: url_helper
INFO - 2024-10-04 17:02:46 --> Helper loaded: file_helper
INFO - 2024-10-04 17:02:46 --> Helper loaded: form_helper
INFO - 2024-10-04 17:02:46 --> Helper loaded: my_helper
INFO - 2024-10-04 17:02:46 --> Database Driver Class Initialized
INFO - 2024-10-04 17:02:46 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-04 17:02:46 --> Controller Class Initialized
DEBUG - 2024-10-04 17:02:46 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/home/views/v_home_guru.php
DEBUG - 2024-10-04 17:02:46 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-10-04 17:02:46 --> Final output sent to browser
DEBUG - 2024-10-04 17:02:46 --> Total execution time: 0.0351
INFO - 2024-10-04 17:03:06 --> Config Class Initialized
INFO - 2024-10-04 17:03:06 --> Hooks Class Initialized
DEBUG - 2024-10-04 17:03:06 --> UTF-8 Support Enabled
INFO - 2024-10-04 17:03:06 --> Utf8 Class Initialized
INFO - 2024-10-04 17:03:06 --> URI Class Initialized
DEBUG - 2024-10-04 17:03:06 --> No URI present. Default controller set.
INFO - 2024-10-04 17:03:06 --> Router Class Initialized
INFO - 2024-10-04 17:03:06 --> Output Class Initialized
INFO - 2024-10-04 17:03:06 --> Security Class Initialized
DEBUG - 2024-10-04 17:03:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-04 17:03:06 --> Input Class Initialized
INFO - 2024-10-04 17:03:06 --> Language Class Initialized
INFO - 2024-10-04 17:03:06 --> Language Class Initialized
INFO - 2024-10-04 17:03:06 --> Config Class Initialized
INFO - 2024-10-04 17:03:06 --> Loader Class Initialized
INFO - 2024-10-04 17:03:06 --> Helper loaded: url_helper
INFO - 2024-10-04 17:03:06 --> Helper loaded: file_helper
INFO - 2024-10-04 17:03:06 --> Helper loaded: form_helper
INFO - 2024-10-04 17:03:06 --> Helper loaded: my_helper
INFO - 2024-10-04 17:03:06 --> Database Driver Class Initialized
INFO - 2024-10-04 17:03:06 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-04 17:03:06 --> Controller Class Initialized
DEBUG - 2024-10-04 17:03:06 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/home/views/v_home_guru.php
DEBUG - 2024-10-04 17:03:06 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-10-04 17:03:06 --> Final output sent to browser
DEBUG - 2024-10-04 17:03:06 --> Total execution time: 0.0387
INFO - 2024-10-04 17:03:17 --> Config Class Initialized
INFO - 2024-10-04 17:03:17 --> Hooks Class Initialized
DEBUG - 2024-10-04 17:03:17 --> UTF-8 Support Enabled
INFO - 2024-10-04 17:03:17 --> Utf8 Class Initialized
INFO - 2024-10-04 17:03:17 --> URI Class Initialized
INFO - 2024-10-04 17:03:17 --> Router Class Initialized
INFO - 2024-10-04 17:03:17 --> Output Class Initialized
INFO - 2024-10-04 17:03:17 --> Security Class Initialized
DEBUG - 2024-10-04 17:03:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-04 17:03:17 --> Input Class Initialized
INFO - 2024-10-04 17:03:17 --> Language Class Initialized
INFO - 2024-10-04 17:03:17 --> Language Class Initialized
INFO - 2024-10-04 17:03:17 --> Config Class Initialized
INFO - 2024-10-04 17:03:17 --> Loader Class Initialized
INFO - 2024-10-04 17:03:17 --> Helper loaded: url_helper
INFO - 2024-10-04 17:03:17 --> Helper loaded: file_helper
INFO - 2024-10-04 17:03:17 --> Helper loaded: form_helper
INFO - 2024-10-04 17:03:17 --> Helper loaded: my_helper
INFO - 2024-10-04 17:03:17 --> Database Driver Class Initialized
INFO - 2024-10-04 17:03:17 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-04 17:03:17 --> Controller Class Initialized
DEBUG - 2024-10-04 17:03:17 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/view_mapel/views/v_view_mapel.php
DEBUG - 2024-10-04 17:03:17 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-10-04 17:03:17 --> Final output sent to browser
DEBUG - 2024-10-04 17:03:17 --> Total execution time: 0.0772
INFO - 2024-10-04 17:03:28 --> Config Class Initialized
INFO - 2024-10-04 17:03:28 --> Hooks Class Initialized
DEBUG - 2024-10-04 17:03:28 --> UTF-8 Support Enabled
INFO - 2024-10-04 17:03:28 --> Utf8 Class Initialized
INFO - 2024-10-04 17:03:28 --> URI Class Initialized
INFO - 2024-10-04 17:03:28 --> Router Class Initialized
INFO - 2024-10-04 17:03:28 --> Output Class Initialized
INFO - 2024-10-04 17:03:28 --> Security Class Initialized
DEBUG - 2024-10-04 17:03:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-04 17:03:28 --> Input Class Initialized
INFO - 2024-10-04 17:03:28 --> Language Class Initialized
INFO - 2024-10-04 17:03:28 --> Language Class Initialized
INFO - 2024-10-04 17:03:28 --> Config Class Initialized
INFO - 2024-10-04 17:03:28 --> Loader Class Initialized
INFO - 2024-10-04 17:03:28 --> Helper loaded: url_helper
INFO - 2024-10-04 17:03:28 --> Helper loaded: file_helper
INFO - 2024-10-04 17:03:28 --> Helper loaded: form_helper
INFO - 2024-10-04 17:03:28 --> Helper loaded: my_helper
INFO - 2024-10-04 17:03:28 --> Database Driver Class Initialized
INFO - 2024-10-04 17:03:28 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-04 17:03:28 --> Controller Class Initialized
DEBUG - 2024-10-04 17:03:28 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/views/list.php
DEBUG - 2024-10-04 17:03:28 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-10-04 17:03:28 --> Final output sent to browser
DEBUG - 2024-10-04 17:03:28 --> Total execution time: 0.0775
INFO - 2024-10-04 17:03:28 --> Config Class Initialized
INFO - 2024-10-04 17:03:28 --> Hooks Class Initialized
DEBUG - 2024-10-04 17:03:28 --> UTF-8 Support Enabled
INFO - 2024-10-04 17:03:28 --> Utf8 Class Initialized
INFO - 2024-10-04 17:03:28 --> URI Class Initialized
INFO - 2024-10-04 17:03:28 --> Router Class Initialized
INFO - 2024-10-04 17:03:28 --> Output Class Initialized
INFO - 2024-10-04 17:03:28 --> Security Class Initialized
DEBUG - 2024-10-04 17:03:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-04 17:03:28 --> Input Class Initialized
INFO - 2024-10-04 17:03:28 --> Language Class Initialized
INFO - 2024-10-04 17:03:28 --> Language Class Initialized
INFO - 2024-10-04 17:03:28 --> Config Class Initialized
INFO - 2024-10-04 17:03:28 --> Loader Class Initialized
INFO - 2024-10-04 17:03:28 --> Helper loaded: url_helper
INFO - 2024-10-04 17:03:28 --> Helper loaded: file_helper
INFO - 2024-10-04 17:03:28 --> Helper loaded: form_helper
INFO - 2024-10-04 17:03:28 --> Helper loaded: my_helper
INFO - 2024-10-04 17:03:28 --> Database Driver Class Initialized
INFO - 2024-10-04 17:03:28 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-04 17:03:28 --> Controller Class Initialized
INFO - 2024-10-04 17:03:44 --> Config Class Initialized
INFO - 2024-10-04 17:03:44 --> Hooks Class Initialized
DEBUG - 2024-10-04 17:03:44 --> UTF-8 Support Enabled
INFO - 2024-10-04 17:03:44 --> Utf8 Class Initialized
INFO - 2024-10-04 17:03:44 --> URI Class Initialized
INFO - 2024-10-04 17:03:44 --> Router Class Initialized
INFO - 2024-10-04 17:03:44 --> Output Class Initialized
INFO - 2024-10-04 17:03:44 --> Security Class Initialized
DEBUG - 2024-10-04 17:03:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-04 17:03:44 --> Input Class Initialized
INFO - 2024-10-04 17:03:44 --> Language Class Initialized
INFO - 2024-10-04 17:03:44 --> Language Class Initialized
INFO - 2024-10-04 17:03:44 --> Config Class Initialized
INFO - 2024-10-04 17:03:44 --> Loader Class Initialized
INFO - 2024-10-04 17:03:44 --> Helper loaded: url_helper
INFO - 2024-10-04 17:03:44 --> Helper loaded: file_helper
INFO - 2024-10-04 17:03:44 --> Helper loaded: form_helper
INFO - 2024-10-04 17:03:44 --> Helper loaded: my_helper
INFO - 2024-10-04 17:03:44 --> Database Driver Class Initialized
INFO - 2024-10-04 17:03:44 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-04 17:03:44 --> Controller Class Initialized
INFO - 2024-10-04 17:03:44 --> Final output sent to browser
DEBUG - 2024-10-04 17:03:44 --> Total execution time: 0.1254
INFO - 2024-10-04 17:07:45 --> Config Class Initialized
INFO - 2024-10-04 17:07:45 --> Hooks Class Initialized
DEBUG - 2024-10-04 17:07:45 --> UTF-8 Support Enabled
INFO - 2024-10-04 17:07:45 --> Utf8 Class Initialized
INFO - 2024-10-04 17:07:45 --> URI Class Initialized
INFO - 2024-10-04 17:07:45 --> Router Class Initialized
INFO - 2024-10-04 17:07:45 --> Output Class Initialized
INFO - 2024-10-04 17:07:45 --> Security Class Initialized
DEBUG - 2024-10-04 17:07:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-04 17:07:45 --> Input Class Initialized
INFO - 2024-10-04 17:07:45 --> Language Class Initialized
INFO - 2024-10-04 17:07:45 --> Language Class Initialized
INFO - 2024-10-04 17:07:45 --> Config Class Initialized
INFO - 2024-10-04 17:07:45 --> Loader Class Initialized
INFO - 2024-10-04 17:07:45 --> Helper loaded: url_helper
INFO - 2024-10-04 17:07:45 --> Helper loaded: file_helper
INFO - 2024-10-04 17:07:45 --> Helper loaded: form_helper
INFO - 2024-10-04 17:07:45 --> Helper loaded: my_helper
INFO - 2024-10-04 17:07:45 --> Database Driver Class Initialized
INFO - 2024-10-04 17:07:45 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-04 17:07:45 --> Controller Class Initialized
INFO - 2024-10-04 17:07:45 --> Final output sent to browser
DEBUG - 2024-10-04 17:07:45 --> Total execution time: 0.0709
INFO - 2024-10-04 17:07:47 --> Config Class Initialized
INFO - 2024-10-04 17:07:47 --> Hooks Class Initialized
DEBUG - 2024-10-04 17:07:47 --> UTF-8 Support Enabled
INFO - 2024-10-04 17:07:47 --> Utf8 Class Initialized
INFO - 2024-10-04 17:07:47 --> URI Class Initialized
INFO - 2024-10-04 17:07:47 --> Router Class Initialized
INFO - 2024-10-04 17:07:47 --> Output Class Initialized
INFO - 2024-10-04 17:07:47 --> Security Class Initialized
DEBUG - 2024-10-04 17:07:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-04 17:07:47 --> Input Class Initialized
INFO - 2024-10-04 17:07:47 --> Language Class Initialized
INFO - 2024-10-04 17:07:47 --> Language Class Initialized
INFO - 2024-10-04 17:07:47 --> Config Class Initialized
INFO - 2024-10-04 17:07:47 --> Loader Class Initialized
INFO - 2024-10-04 17:07:47 --> Helper loaded: url_helper
INFO - 2024-10-04 17:07:47 --> Helper loaded: file_helper
INFO - 2024-10-04 17:07:47 --> Helper loaded: form_helper
INFO - 2024-10-04 17:07:47 --> Helper loaded: my_helper
INFO - 2024-10-04 17:07:47 --> Database Driver Class Initialized
INFO - 2024-10-04 17:07:47 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-04 17:07:47 --> Controller Class Initialized
DEBUG - 2024-10-04 17:07:47 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/view_mapel/views/v_view_mapel.php
DEBUG - 2024-10-04 17:07:47 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-10-04 17:07:47 --> Final output sent to browser
DEBUG - 2024-10-04 17:07:47 --> Total execution time: 0.0360
INFO - 2024-10-04 17:07:52 --> Config Class Initialized
INFO - 2024-10-04 17:07:52 --> Hooks Class Initialized
DEBUG - 2024-10-04 17:07:52 --> UTF-8 Support Enabled
INFO - 2024-10-04 17:07:52 --> Utf8 Class Initialized
INFO - 2024-10-04 17:07:52 --> URI Class Initialized
INFO - 2024-10-04 17:07:52 --> Router Class Initialized
INFO - 2024-10-04 17:07:52 --> Output Class Initialized
INFO - 2024-10-04 17:07:52 --> Security Class Initialized
DEBUG - 2024-10-04 17:07:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-04 17:07:52 --> Input Class Initialized
INFO - 2024-10-04 17:07:52 --> Language Class Initialized
INFO - 2024-10-04 17:07:52 --> Language Class Initialized
INFO - 2024-10-04 17:07:52 --> Config Class Initialized
INFO - 2024-10-04 17:07:52 --> Loader Class Initialized
INFO - 2024-10-04 17:07:52 --> Helper loaded: url_helper
INFO - 2024-10-04 17:07:52 --> Helper loaded: file_helper
INFO - 2024-10-04 17:07:52 --> Helper loaded: form_helper
INFO - 2024-10-04 17:07:52 --> Helper loaded: my_helper
INFO - 2024-10-04 17:07:52 --> Database Driver Class Initialized
INFO - 2024-10-04 17:07:52 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-04 17:07:52 --> Controller Class Initialized
DEBUG - 2024-10-04 17:07:52 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/views/list.php
DEBUG - 2024-10-04 17:07:52 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-10-04 17:07:52 --> Final output sent to browser
DEBUG - 2024-10-04 17:07:52 --> Total execution time: 0.0345
INFO - 2024-10-04 17:07:52 --> Config Class Initialized
INFO - 2024-10-04 17:07:52 --> Hooks Class Initialized
DEBUG - 2024-10-04 17:07:52 --> UTF-8 Support Enabled
INFO - 2024-10-04 17:07:52 --> Utf8 Class Initialized
INFO - 2024-10-04 17:07:52 --> URI Class Initialized
INFO - 2024-10-04 17:07:52 --> Router Class Initialized
INFO - 2024-10-04 17:07:52 --> Output Class Initialized
INFO - 2024-10-04 17:07:52 --> Security Class Initialized
DEBUG - 2024-10-04 17:07:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-04 17:07:52 --> Input Class Initialized
INFO - 2024-10-04 17:07:52 --> Language Class Initialized
INFO - 2024-10-04 17:07:52 --> Language Class Initialized
INFO - 2024-10-04 17:07:52 --> Config Class Initialized
INFO - 2024-10-04 17:07:52 --> Loader Class Initialized
INFO - 2024-10-04 17:07:52 --> Helper loaded: url_helper
INFO - 2024-10-04 17:07:52 --> Helper loaded: file_helper
INFO - 2024-10-04 17:07:52 --> Helper loaded: form_helper
INFO - 2024-10-04 17:07:52 --> Helper loaded: my_helper
INFO - 2024-10-04 17:07:52 --> Database Driver Class Initialized
INFO - 2024-10-04 17:07:52 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-04 17:07:52 --> Controller Class Initialized
INFO - 2024-10-04 17:08:00 --> Config Class Initialized
INFO - 2024-10-04 17:08:00 --> Hooks Class Initialized
DEBUG - 2024-10-04 17:08:00 --> UTF-8 Support Enabled
INFO - 2024-10-04 17:08:00 --> Utf8 Class Initialized
INFO - 2024-10-04 17:08:00 --> URI Class Initialized
INFO - 2024-10-04 17:08:00 --> Router Class Initialized
INFO - 2024-10-04 17:08:00 --> Output Class Initialized
INFO - 2024-10-04 17:08:00 --> Security Class Initialized
DEBUG - 2024-10-04 17:08:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-04 17:08:00 --> Input Class Initialized
INFO - 2024-10-04 17:08:00 --> Language Class Initialized
INFO - 2024-10-04 17:08:00 --> Language Class Initialized
INFO - 2024-10-04 17:08:00 --> Config Class Initialized
INFO - 2024-10-04 17:08:00 --> Loader Class Initialized
INFO - 2024-10-04 17:08:00 --> Helper loaded: url_helper
INFO - 2024-10-04 17:08:00 --> Helper loaded: file_helper
INFO - 2024-10-04 17:08:00 --> Helper loaded: form_helper
INFO - 2024-10-04 17:08:00 --> Helper loaded: my_helper
INFO - 2024-10-04 17:08:00 --> Database Driver Class Initialized
INFO - 2024-10-04 17:08:00 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-04 17:08:00 --> Controller Class Initialized
DEBUG - 2024-10-04 17:08:00 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/view_mapel/views/v_view_mapel.php
DEBUG - 2024-10-04 17:08:00 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-10-04 17:08:00 --> Final output sent to browser
DEBUG - 2024-10-04 17:08:00 --> Total execution time: 0.0308
INFO - 2024-10-04 17:08:04 --> Config Class Initialized
INFO - 2024-10-04 17:08:04 --> Hooks Class Initialized
DEBUG - 2024-10-04 17:08:04 --> UTF-8 Support Enabled
INFO - 2024-10-04 17:08:04 --> Utf8 Class Initialized
INFO - 2024-10-04 17:08:04 --> URI Class Initialized
INFO - 2024-10-04 17:08:04 --> Router Class Initialized
INFO - 2024-10-04 17:08:04 --> Output Class Initialized
INFO - 2024-10-04 17:08:04 --> Security Class Initialized
DEBUG - 2024-10-04 17:08:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-04 17:08:04 --> Input Class Initialized
INFO - 2024-10-04 17:08:04 --> Language Class Initialized
INFO - 2024-10-04 17:08:04 --> Language Class Initialized
INFO - 2024-10-04 17:08:04 --> Config Class Initialized
INFO - 2024-10-04 17:08:04 --> Loader Class Initialized
INFO - 2024-10-04 17:08:04 --> Helper loaded: url_helper
INFO - 2024-10-04 17:08:04 --> Helper loaded: file_helper
INFO - 2024-10-04 17:08:04 --> Helper loaded: form_helper
INFO - 2024-10-04 17:08:04 --> Helper loaded: my_helper
INFO - 2024-10-04 17:08:04 --> Database Driver Class Initialized
INFO - 2024-10-04 17:08:04 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-04 17:08:04 --> Controller Class Initialized
DEBUG - 2024-10-04 17:08:04 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/views/list.php
DEBUG - 2024-10-04 17:08:04 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-10-04 17:08:04 --> Final output sent to browser
DEBUG - 2024-10-04 17:08:04 --> Total execution time: 0.0387
INFO - 2024-10-04 17:08:04 --> Config Class Initialized
INFO - 2024-10-04 17:08:04 --> Hooks Class Initialized
DEBUG - 2024-10-04 17:08:04 --> UTF-8 Support Enabled
INFO - 2024-10-04 17:08:04 --> Utf8 Class Initialized
INFO - 2024-10-04 17:08:04 --> URI Class Initialized
INFO - 2024-10-04 17:08:04 --> Router Class Initialized
INFO - 2024-10-04 17:08:04 --> Output Class Initialized
INFO - 2024-10-04 17:08:04 --> Security Class Initialized
DEBUG - 2024-10-04 17:08:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-04 17:08:04 --> Input Class Initialized
INFO - 2024-10-04 17:08:04 --> Language Class Initialized
INFO - 2024-10-04 17:08:04 --> Language Class Initialized
INFO - 2024-10-04 17:08:04 --> Config Class Initialized
INFO - 2024-10-04 17:08:04 --> Loader Class Initialized
INFO - 2024-10-04 17:08:04 --> Helper loaded: url_helper
INFO - 2024-10-04 17:08:04 --> Helper loaded: file_helper
INFO - 2024-10-04 17:08:04 --> Helper loaded: form_helper
INFO - 2024-10-04 17:08:04 --> Helper loaded: my_helper
INFO - 2024-10-04 17:08:04 --> Database Driver Class Initialized
INFO - 2024-10-04 17:08:04 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-04 17:08:04 --> Controller Class Initialized
INFO - 2024-10-04 17:08:08 --> Config Class Initialized
INFO - 2024-10-04 17:08:08 --> Hooks Class Initialized
DEBUG - 2024-10-04 17:08:08 --> UTF-8 Support Enabled
INFO - 2024-10-04 17:08:08 --> Utf8 Class Initialized
INFO - 2024-10-04 17:08:08 --> URI Class Initialized
INFO - 2024-10-04 17:08:08 --> Router Class Initialized
INFO - 2024-10-04 17:08:08 --> Output Class Initialized
INFO - 2024-10-04 17:08:08 --> Security Class Initialized
DEBUG - 2024-10-04 17:08:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-04 17:08:08 --> Input Class Initialized
INFO - 2024-10-04 17:08:08 --> Language Class Initialized
INFO - 2024-10-04 17:08:08 --> Language Class Initialized
INFO - 2024-10-04 17:08:08 --> Config Class Initialized
INFO - 2024-10-04 17:08:08 --> Loader Class Initialized
INFO - 2024-10-04 17:08:08 --> Helper loaded: url_helper
INFO - 2024-10-04 17:08:08 --> Helper loaded: file_helper
INFO - 2024-10-04 17:08:08 --> Helper loaded: form_helper
INFO - 2024-10-04 17:08:08 --> Helper loaded: my_helper
INFO - 2024-10-04 17:08:08 --> Database Driver Class Initialized
INFO - 2024-10-04 17:08:08 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-04 17:08:08 --> Controller Class Initialized
DEBUG - 2024-10-04 17:08:08 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/view_mapel/views/v_view_mapel.php
DEBUG - 2024-10-04 17:08:08 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-10-04 17:08:08 --> Final output sent to browser
DEBUG - 2024-10-04 17:08:08 --> Total execution time: 0.0341
INFO - 2024-10-04 17:08:10 --> Config Class Initialized
INFO - 2024-10-04 17:08:10 --> Hooks Class Initialized
DEBUG - 2024-10-04 17:08:10 --> UTF-8 Support Enabled
INFO - 2024-10-04 17:08:10 --> Utf8 Class Initialized
INFO - 2024-10-04 17:08:10 --> URI Class Initialized
INFO - 2024-10-04 17:08:10 --> Router Class Initialized
INFO - 2024-10-04 17:08:10 --> Output Class Initialized
INFO - 2024-10-04 17:08:10 --> Security Class Initialized
DEBUG - 2024-10-04 17:08:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-04 17:08:10 --> Input Class Initialized
INFO - 2024-10-04 17:08:10 --> Language Class Initialized
INFO - 2024-10-04 17:08:10 --> Language Class Initialized
INFO - 2024-10-04 17:08:10 --> Config Class Initialized
INFO - 2024-10-04 17:08:10 --> Loader Class Initialized
INFO - 2024-10-04 17:08:10 --> Helper loaded: url_helper
INFO - 2024-10-04 17:08:10 --> Helper loaded: file_helper
INFO - 2024-10-04 17:08:10 --> Helper loaded: form_helper
INFO - 2024-10-04 17:08:10 --> Helper loaded: my_helper
INFO - 2024-10-04 17:08:10 --> Database Driver Class Initialized
INFO - 2024-10-04 17:08:10 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-04 17:08:10 --> Controller Class Initialized
DEBUG - 2024-10-04 17:08:10 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/views/list.php
DEBUG - 2024-10-04 17:08:10 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-10-04 17:08:10 --> Final output sent to browser
DEBUG - 2024-10-04 17:08:10 --> Total execution time: 0.0338
INFO - 2024-10-04 17:08:10 --> Config Class Initialized
INFO - 2024-10-04 17:08:10 --> Hooks Class Initialized
DEBUG - 2024-10-04 17:08:10 --> UTF-8 Support Enabled
INFO - 2024-10-04 17:08:10 --> Utf8 Class Initialized
INFO - 2024-10-04 17:08:10 --> URI Class Initialized
INFO - 2024-10-04 17:08:10 --> Router Class Initialized
INFO - 2024-10-04 17:08:10 --> Output Class Initialized
INFO - 2024-10-04 17:08:10 --> Security Class Initialized
DEBUG - 2024-10-04 17:08:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-04 17:08:10 --> Input Class Initialized
INFO - 2024-10-04 17:08:10 --> Language Class Initialized
INFO - 2024-10-04 17:08:10 --> Language Class Initialized
INFO - 2024-10-04 17:08:10 --> Config Class Initialized
INFO - 2024-10-04 17:08:10 --> Loader Class Initialized
INFO - 2024-10-04 17:08:10 --> Helper loaded: url_helper
INFO - 2024-10-04 17:08:10 --> Helper loaded: file_helper
INFO - 2024-10-04 17:08:10 --> Helper loaded: form_helper
INFO - 2024-10-04 17:08:10 --> Helper loaded: my_helper
INFO - 2024-10-04 17:08:10 --> Database Driver Class Initialized
INFO - 2024-10-04 17:08:10 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-04 17:08:10 --> Controller Class Initialized
INFO - 2024-10-04 17:08:16 --> Config Class Initialized
INFO - 2024-10-04 17:08:16 --> Hooks Class Initialized
DEBUG - 2024-10-04 17:08:16 --> UTF-8 Support Enabled
INFO - 2024-10-04 17:08:16 --> Utf8 Class Initialized
INFO - 2024-10-04 17:08:16 --> URI Class Initialized
INFO - 2024-10-04 17:08:16 --> Router Class Initialized
INFO - 2024-10-04 17:08:16 --> Output Class Initialized
INFO - 2024-10-04 17:08:16 --> Security Class Initialized
DEBUG - 2024-10-04 17:08:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-04 17:08:16 --> Input Class Initialized
INFO - 2024-10-04 17:08:16 --> Language Class Initialized
INFO - 2024-10-04 17:08:16 --> Language Class Initialized
INFO - 2024-10-04 17:08:16 --> Config Class Initialized
INFO - 2024-10-04 17:08:16 --> Loader Class Initialized
INFO - 2024-10-04 17:08:16 --> Helper loaded: url_helper
INFO - 2024-10-04 17:08:16 --> Helper loaded: file_helper
INFO - 2024-10-04 17:08:16 --> Helper loaded: form_helper
INFO - 2024-10-04 17:08:16 --> Helper loaded: my_helper
INFO - 2024-10-04 17:08:16 --> Database Driver Class Initialized
INFO - 2024-10-04 17:08:16 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-04 17:08:16 --> Controller Class Initialized
DEBUG - 2024-10-04 17:08:16 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/view_mapel/views/v_view_mapel.php
DEBUG - 2024-10-04 17:08:16 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-10-04 17:08:16 --> Final output sent to browser
DEBUG - 2024-10-04 17:08:16 --> Total execution time: 0.0322
INFO - 2024-10-04 17:08:19 --> Config Class Initialized
INFO - 2024-10-04 17:08:19 --> Hooks Class Initialized
DEBUG - 2024-10-04 17:08:19 --> UTF-8 Support Enabled
INFO - 2024-10-04 17:08:19 --> Utf8 Class Initialized
INFO - 2024-10-04 17:08:19 --> URI Class Initialized
INFO - 2024-10-04 17:08:19 --> Router Class Initialized
INFO - 2024-10-04 17:08:19 --> Output Class Initialized
INFO - 2024-10-04 17:08:19 --> Security Class Initialized
DEBUG - 2024-10-04 17:08:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-04 17:08:19 --> Input Class Initialized
INFO - 2024-10-04 17:08:19 --> Language Class Initialized
INFO - 2024-10-04 17:08:19 --> Language Class Initialized
INFO - 2024-10-04 17:08:19 --> Config Class Initialized
INFO - 2024-10-04 17:08:19 --> Loader Class Initialized
INFO - 2024-10-04 17:08:19 --> Helper loaded: url_helper
INFO - 2024-10-04 17:08:19 --> Helper loaded: file_helper
INFO - 2024-10-04 17:08:19 --> Helper loaded: form_helper
INFO - 2024-10-04 17:08:19 --> Helper loaded: my_helper
INFO - 2024-10-04 17:08:19 --> Database Driver Class Initialized
INFO - 2024-10-04 17:08:19 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-04 17:08:19 --> Controller Class Initialized
DEBUG - 2024-10-04 17:08:19 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/views/list.php
DEBUG - 2024-10-04 17:08:19 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-10-04 17:08:19 --> Final output sent to browser
DEBUG - 2024-10-04 17:08:19 --> Total execution time: 0.0352
INFO - 2024-10-04 17:08:19 --> Config Class Initialized
INFO - 2024-10-04 17:08:19 --> Hooks Class Initialized
DEBUG - 2024-10-04 17:08:19 --> UTF-8 Support Enabled
INFO - 2024-10-04 17:08:19 --> Utf8 Class Initialized
INFO - 2024-10-04 17:08:19 --> URI Class Initialized
INFO - 2024-10-04 17:08:19 --> Router Class Initialized
INFO - 2024-10-04 17:08:19 --> Output Class Initialized
INFO - 2024-10-04 17:08:19 --> Security Class Initialized
DEBUG - 2024-10-04 17:08:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-04 17:08:19 --> Input Class Initialized
INFO - 2024-10-04 17:08:19 --> Language Class Initialized
INFO - 2024-10-04 17:08:19 --> Language Class Initialized
INFO - 2024-10-04 17:08:19 --> Config Class Initialized
INFO - 2024-10-04 17:08:19 --> Loader Class Initialized
INFO - 2024-10-04 17:08:19 --> Helper loaded: url_helper
INFO - 2024-10-04 17:08:19 --> Helper loaded: file_helper
INFO - 2024-10-04 17:08:19 --> Helper loaded: form_helper
INFO - 2024-10-04 17:08:19 --> Helper loaded: my_helper
INFO - 2024-10-04 17:08:19 --> Database Driver Class Initialized
INFO - 2024-10-04 17:08:19 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-04 17:08:19 --> Controller Class Initialized
INFO - 2024-10-04 17:08:26 --> Config Class Initialized
INFO - 2024-10-04 17:08:26 --> Hooks Class Initialized
DEBUG - 2024-10-04 17:08:26 --> UTF-8 Support Enabled
INFO - 2024-10-04 17:08:26 --> Utf8 Class Initialized
INFO - 2024-10-04 17:08:26 --> URI Class Initialized
INFO - 2024-10-04 17:08:26 --> Router Class Initialized
INFO - 2024-10-04 17:08:26 --> Output Class Initialized
INFO - 2024-10-04 17:08:26 --> Security Class Initialized
DEBUG - 2024-10-04 17:08:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-04 17:08:26 --> Input Class Initialized
INFO - 2024-10-04 17:08:26 --> Language Class Initialized
INFO - 2024-10-04 17:08:26 --> Language Class Initialized
INFO - 2024-10-04 17:08:26 --> Config Class Initialized
INFO - 2024-10-04 17:08:26 --> Loader Class Initialized
INFO - 2024-10-04 17:08:26 --> Helper loaded: url_helper
INFO - 2024-10-04 17:08:26 --> Helper loaded: file_helper
INFO - 2024-10-04 17:08:26 --> Helper loaded: form_helper
INFO - 2024-10-04 17:08:26 --> Helper loaded: my_helper
INFO - 2024-10-04 17:08:26 --> Database Driver Class Initialized
INFO - 2024-10-04 17:08:26 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-04 17:08:26 --> Controller Class Initialized
DEBUG - 2024-10-04 17:08:26 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/view_mapel/views/v_view_mapel.php
DEBUG - 2024-10-04 17:08:26 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-10-04 17:08:26 --> Final output sent to browser
DEBUG - 2024-10-04 17:08:26 --> Total execution time: 0.0340
INFO - 2024-10-04 17:08:29 --> Config Class Initialized
INFO - 2024-10-04 17:08:29 --> Hooks Class Initialized
DEBUG - 2024-10-04 17:08:29 --> UTF-8 Support Enabled
INFO - 2024-10-04 17:08:29 --> Utf8 Class Initialized
INFO - 2024-10-04 17:08:29 --> URI Class Initialized
INFO - 2024-10-04 17:08:29 --> Router Class Initialized
INFO - 2024-10-04 17:08:29 --> Output Class Initialized
INFO - 2024-10-04 17:08:29 --> Security Class Initialized
DEBUG - 2024-10-04 17:08:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-04 17:08:29 --> Input Class Initialized
INFO - 2024-10-04 17:08:29 --> Language Class Initialized
INFO - 2024-10-04 17:08:29 --> Language Class Initialized
INFO - 2024-10-04 17:08:29 --> Config Class Initialized
INFO - 2024-10-04 17:08:29 --> Loader Class Initialized
INFO - 2024-10-04 17:08:29 --> Helper loaded: url_helper
INFO - 2024-10-04 17:08:29 --> Helper loaded: file_helper
INFO - 2024-10-04 17:08:29 --> Helper loaded: form_helper
INFO - 2024-10-04 17:08:29 --> Helper loaded: my_helper
INFO - 2024-10-04 17:08:29 --> Database Driver Class Initialized
INFO - 2024-10-04 17:08:29 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-04 17:08:29 --> Controller Class Initialized
DEBUG - 2024-10-04 17:08:29 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/views/list.php
DEBUG - 2024-10-04 17:08:29 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-10-04 17:08:29 --> Final output sent to browser
DEBUG - 2024-10-04 17:08:29 --> Total execution time: 0.0438
INFO - 2024-10-04 17:08:30 --> Config Class Initialized
INFO - 2024-10-04 17:08:30 --> Hooks Class Initialized
DEBUG - 2024-10-04 17:08:30 --> UTF-8 Support Enabled
INFO - 2024-10-04 17:08:30 --> Utf8 Class Initialized
INFO - 2024-10-04 17:08:30 --> URI Class Initialized
INFO - 2024-10-04 17:08:30 --> Router Class Initialized
INFO - 2024-10-04 17:08:30 --> Output Class Initialized
INFO - 2024-10-04 17:08:30 --> Security Class Initialized
DEBUG - 2024-10-04 17:08:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-04 17:08:30 --> Input Class Initialized
INFO - 2024-10-04 17:08:30 --> Language Class Initialized
INFO - 2024-10-04 17:08:30 --> Language Class Initialized
INFO - 2024-10-04 17:08:30 --> Config Class Initialized
INFO - 2024-10-04 17:08:30 --> Loader Class Initialized
INFO - 2024-10-04 17:08:30 --> Helper loaded: url_helper
INFO - 2024-10-04 17:08:30 --> Helper loaded: file_helper
INFO - 2024-10-04 17:08:30 --> Helper loaded: form_helper
INFO - 2024-10-04 17:08:30 --> Helper loaded: my_helper
INFO - 2024-10-04 17:08:30 --> Database Driver Class Initialized
INFO - 2024-10-04 17:08:30 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-04 17:08:30 --> Controller Class Initialized
INFO - 2024-10-04 17:08:34 --> Config Class Initialized
INFO - 2024-10-04 17:08:34 --> Hooks Class Initialized
DEBUG - 2024-10-04 17:08:34 --> UTF-8 Support Enabled
INFO - 2024-10-04 17:08:34 --> Utf8 Class Initialized
INFO - 2024-10-04 17:08:34 --> URI Class Initialized
INFO - 2024-10-04 17:08:34 --> Router Class Initialized
INFO - 2024-10-04 17:08:34 --> Output Class Initialized
INFO - 2024-10-04 17:08:34 --> Security Class Initialized
DEBUG - 2024-10-04 17:08:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-04 17:08:34 --> Input Class Initialized
INFO - 2024-10-04 17:08:34 --> Language Class Initialized
INFO - 2024-10-04 17:08:34 --> Language Class Initialized
INFO - 2024-10-04 17:08:34 --> Config Class Initialized
INFO - 2024-10-04 17:08:34 --> Loader Class Initialized
INFO - 2024-10-04 17:08:34 --> Helper loaded: url_helper
INFO - 2024-10-04 17:08:34 --> Helper loaded: file_helper
INFO - 2024-10-04 17:08:34 --> Helper loaded: form_helper
INFO - 2024-10-04 17:08:34 --> Helper loaded: my_helper
INFO - 2024-10-04 17:08:34 --> Database Driver Class Initialized
INFO - 2024-10-04 17:08:34 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-04 17:08:34 --> Controller Class Initialized
DEBUG - 2024-10-04 17:08:34 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/view_mapel/views/v_view_mapel.php
DEBUG - 2024-10-04 17:08:34 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-10-04 17:08:34 --> Final output sent to browser
DEBUG - 2024-10-04 17:08:34 --> Total execution time: 0.0540
INFO - 2024-10-04 17:08:41 --> Config Class Initialized
INFO - 2024-10-04 17:08:41 --> Hooks Class Initialized
DEBUG - 2024-10-04 17:08:41 --> UTF-8 Support Enabled
INFO - 2024-10-04 17:08:41 --> Utf8 Class Initialized
INFO - 2024-10-04 17:08:41 --> URI Class Initialized
INFO - 2024-10-04 17:08:41 --> Router Class Initialized
INFO - 2024-10-04 17:08:41 --> Output Class Initialized
INFO - 2024-10-04 17:08:41 --> Security Class Initialized
DEBUG - 2024-10-04 17:08:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-04 17:08:41 --> Input Class Initialized
INFO - 2024-10-04 17:08:41 --> Language Class Initialized
INFO - 2024-10-04 17:08:41 --> Language Class Initialized
INFO - 2024-10-04 17:08:41 --> Config Class Initialized
INFO - 2024-10-04 17:08:41 --> Loader Class Initialized
INFO - 2024-10-04 17:08:41 --> Helper loaded: url_helper
INFO - 2024-10-04 17:08:41 --> Helper loaded: file_helper
INFO - 2024-10-04 17:08:41 --> Helper loaded: form_helper
INFO - 2024-10-04 17:08:41 --> Helper loaded: my_helper
INFO - 2024-10-04 17:08:41 --> Database Driver Class Initialized
INFO - 2024-10-04 17:08:41 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-04 17:08:41 --> Controller Class Initialized
DEBUG - 2024-10-04 17:08:41 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/views/list.php
DEBUG - 2024-10-04 17:08:41 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-10-04 17:08:41 --> Final output sent to browser
DEBUG - 2024-10-04 17:08:41 --> Total execution time: 0.1191
INFO - 2024-10-04 17:08:41 --> Config Class Initialized
INFO - 2024-10-04 17:08:41 --> Hooks Class Initialized
DEBUG - 2024-10-04 17:08:41 --> UTF-8 Support Enabled
INFO - 2024-10-04 17:08:41 --> Utf8 Class Initialized
INFO - 2024-10-04 17:08:41 --> URI Class Initialized
INFO - 2024-10-04 17:08:41 --> Router Class Initialized
INFO - 2024-10-04 17:08:41 --> Output Class Initialized
INFO - 2024-10-04 17:08:41 --> Security Class Initialized
DEBUG - 2024-10-04 17:08:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-04 17:08:41 --> Input Class Initialized
INFO - 2024-10-04 17:08:41 --> Language Class Initialized
INFO - 2024-10-04 17:08:41 --> Language Class Initialized
INFO - 2024-10-04 17:08:41 --> Config Class Initialized
INFO - 2024-10-04 17:08:41 --> Loader Class Initialized
INFO - 2024-10-04 17:08:41 --> Helper loaded: url_helper
INFO - 2024-10-04 17:08:41 --> Helper loaded: file_helper
INFO - 2024-10-04 17:08:41 --> Helper loaded: form_helper
INFO - 2024-10-04 17:08:41 --> Helper loaded: my_helper
INFO - 2024-10-04 17:08:41 --> Database Driver Class Initialized
INFO - 2024-10-04 17:08:41 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-04 17:08:41 --> Controller Class Initialized
INFO - 2024-10-04 17:08:46 --> Config Class Initialized
INFO - 2024-10-04 17:08:46 --> Hooks Class Initialized
DEBUG - 2024-10-04 17:08:46 --> UTF-8 Support Enabled
INFO - 2024-10-04 17:08:46 --> Utf8 Class Initialized
INFO - 2024-10-04 17:08:46 --> URI Class Initialized
INFO - 2024-10-04 17:08:46 --> Router Class Initialized
INFO - 2024-10-04 17:08:46 --> Output Class Initialized
INFO - 2024-10-04 17:08:46 --> Security Class Initialized
DEBUG - 2024-10-04 17:08:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-04 17:08:46 --> Input Class Initialized
INFO - 2024-10-04 17:08:46 --> Language Class Initialized
INFO - 2024-10-04 17:08:46 --> Language Class Initialized
INFO - 2024-10-04 17:08:46 --> Config Class Initialized
INFO - 2024-10-04 17:08:46 --> Loader Class Initialized
INFO - 2024-10-04 17:08:46 --> Helper loaded: url_helper
INFO - 2024-10-04 17:08:46 --> Helper loaded: file_helper
INFO - 2024-10-04 17:08:46 --> Helper loaded: form_helper
INFO - 2024-10-04 17:08:46 --> Helper loaded: my_helper
INFO - 2024-10-04 17:08:46 --> Database Driver Class Initialized
INFO - 2024-10-04 17:08:46 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-04 17:08:46 --> Controller Class Initialized
DEBUG - 2024-10-04 17:08:46 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/view_mapel/views/v_view_mapel.php
DEBUG - 2024-10-04 17:08:46 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-10-04 17:08:46 --> Final output sent to browser
DEBUG - 2024-10-04 17:08:46 --> Total execution time: 0.0332
INFO - 2024-10-04 17:08:50 --> Config Class Initialized
INFO - 2024-10-04 17:08:50 --> Hooks Class Initialized
DEBUG - 2024-10-04 17:08:50 --> UTF-8 Support Enabled
INFO - 2024-10-04 17:08:50 --> Utf8 Class Initialized
INFO - 2024-10-04 17:08:50 --> URI Class Initialized
INFO - 2024-10-04 17:08:50 --> Router Class Initialized
INFO - 2024-10-04 17:08:50 --> Output Class Initialized
INFO - 2024-10-04 17:08:50 --> Security Class Initialized
DEBUG - 2024-10-04 17:08:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-04 17:08:50 --> Input Class Initialized
INFO - 2024-10-04 17:08:50 --> Language Class Initialized
INFO - 2024-10-04 17:08:50 --> Language Class Initialized
INFO - 2024-10-04 17:08:50 --> Config Class Initialized
INFO - 2024-10-04 17:08:50 --> Loader Class Initialized
INFO - 2024-10-04 17:08:50 --> Helper loaded: url_helper
INFO - 2024-10-04 17:08:50 --> Helper loaded: file_helper
INFO - 2024-10-04 17:08:50 --> Helper loaded: form_helper
INFO - 2024-10-04 17:08:50 --> Helper loaded: my_helper
INFO - 2024-10-04 17:08:50 --> Database Driver Class Initialized
INFO - 2024-10-04 17:08:50 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-04 17:08:50 --> Controller Class Initialized
DEBUG - 2024-10-04 17:08:50 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/views/list.php
DEBUG - 2024-10-04 17:08:50 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-10-04 17:08:50 --> Final output sent to browser
DEBUG - 2024-10-04 17:08:50 --> Total execution time: 0.0310
INFO - 2024-10-04 17:08:50 --> Config Class Initialized
INFO - 2024-10-04 17:08:50 --> Hooks Class Initialized
DEBUG - 2024-10-04 17:08:50 --> UTF-8 Support Enabled
INFO - 2024-10-04 17:08:50 --> Utf8 Class Initialized
INFO - 2024-10-04 17:08:50 --> URI Class Initialized
INFO - 2024-10-04 17:08:50 --> Router Class Initialized
INFO - 2024-10-04 17:08:50 --> Output Class Initialized
INFO - 2024-10-04 17:08:50 --> Security Class Initialized
DEBUG - 2024-10-04 17:08:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-04 17:08:50 --> Input Class Initialized
INFO - 2024-10-04 17:08:50 --> Language Class Initialized
INFO - 2024-10-04 17:08:50 --> Language Class Initialized
INFO - 2024-10-04 17:08:50 --> Config Class Initialized
INFO - 2024-10-04 17:08:50 --> Loader Class Initialized
INFO - 2024-10-04 17:08:50 --> Helper loaded: url_helper
INFO - 2024-10-04 17:08:50 --> Helper loaded: file_helper
INFO - 2024-10-04 17:08:50 --> Helper loaded: form_helper
INFO - 2024-10-04 17:08:50 --> Helper loaded: my_helper
INFO - 2024-10-04 17:08:50 --> Database Driver Class Initialized
INFO - 2024-10-04 17:08:50 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-04 17:08:50 --> Controller Class Initialized
INFO - 2024-10-04 17:08:52 --> Config Class Initialized
INFO - 2024-10-04 17:08:52 --> Hooks Class Initialized
DEBUG - 2024-10-04 17:08:52 --> UTF-8 Support Enabled
INFO - 2024-10-04 17:08:52 --> Utf8 Class Initialized
INFO - 2024-10-04 17:08:52 --> URI Class Initialized
INFO - 2024-10-04 17:08:52 --> Router Class Initialized
INFO - 2024-10-04 17:08:52 --> Output Class Initialized
INFO - 2024-10-04 17:08:52 --> Security Class Initialized
DEBUG - 2024-10-04 17:08:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-04 17:08:52 --> Input Class Initialized
INFO - 2024-10-04 17:08:52 --> Language Class Initialized
INFO - 2024-10-04 17:08:52 --> Language Class Initialized
INFO - 2024-10-04 17:08:52 --> Config Class Initialized
INFO - 2024-10-04 17:08:52 --> Loader Class Initialized
INFO - 2024-10-04 17:08:52 --> Helper loaded: url_helper
INFO - 2024-10-04 17:08:52 --> Helper loaded: file_helper
INFO - 2024-10-04 17:08:52 --> Helper loaded: form_helper
INFO - 2024-10-04 17:08:52 --> Helper loaded: my_helper
INFO - 2024-10-04 17:08:52 --> Database Driver Class Initialized
INFO - 2024-10-04 17:08:52 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-04 17:08:52 --> Controller Class Initialized
INFO - 2024-10-04 17:08:52 --> Final output sent to browser
DEBUG - 2024-10-04 17:08:52 --> Total execution time: 0.0308
INFO - 2024-10-04 17:09:23 --> Config Class Initialized
INFO - 2024-10-04 17:09:23 --> Hooks Class Initialized
DEBUG - 2024-10-04 17:09:23 --> UTF-8 Support Enabled
INFO - 2024-10-04 17:09:23 --> Utf8 Class Initialized
INFO - 2024-10-04 17:09:23 --> URI Class Initialized
INFO - 2024-10-04 17:09:23 --> Router Class Initialized
INFO - 2024-10-04 17:09:23 --> Output Class Initialized
INFO - 2024-10-04 17:09:23 --> Security Class Initialized
DEBUG - 2024-10-04 17:09:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-04 17:09:23 --> Input Class Initialized
INFO - 2024-10-04 17:09:23 --> Language Class Initialized
INFO - 2024-10-04 17:09:23 --> Language Class Initialized
INFO - 2024-10-04 17:09:23 --> Config Class Initialized
INFO - 2024-10-04 17:09:23 --> Loader Class Initialized
INFO - 2024-10-04 17:09:23 --> Helper loaded: url_helper
INFO - 2024-10-04 17:09:23 --> Helper loaded: file_helper
INFO - 2024-10-04 17:09:23 --> Helper loaded: form_helper
INFO - 2024-10-04 17:09:23 --> Helper loaded: my_helper
INFO - 2024-10-04 17:09:23 --> Database Driver Class Initialized
INFO - 2024-10-04 17:09:23 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-04 17:09:23 --> Controller Class Initialized
INFO - 2024-10-04 17:09:23 --> Final output sent to browser
DEBUG - 2024-10-04 17:09:23 --> Total execution time: 0.0322
INFO - 2024-10-04 17:09:23 --> Config Class Initialized
INFO - 2024-10-04 17:09:23 --> Hooks Class Initialized
DEBUG - 2024-10-04 17:09:23 --> UTF-8 Support Enabled
INFO - 2024-10-04 17:09:23 --> Utf8 Class Initialized
INFO - 2024-10-04 17:09:23 --> URI Class Initialized
INFO - 2024-10-04 17:09:23 --> Router Class Initialized
INFO - 2024-10-04 17:09:23 --> Output Class Initialized
INFO - 2024-10-04 17:09:23 --> Security Class Initialized
DEBUG - 2024-10-04 17:09:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-04 17:09:23 --> Input Class Initialized
INFO - 2024-10-04 17:09:23 --> Language Class Initialized
INFO - 2024-10-04 17:09:23 --> Language Class Initialized
INFO - 2024-10-04 17:09:23 --> Config Class Initialized
INFO - 2024-10-04 17:09:23 --> Loader Class Initialized
INFO - 2024-10-04 17:09:23 --> Helper loaded: url_helper
INFO - 2024-10-04 17:09:23 --> Helper loaded: file_helper
INFO - 2024-10-04 17:09:23 --> Helper loaded: form_helper
INFO - 2024-10-04 17:09:23 --> Helper loaded: my_helper
INFO - 2024-10-04 17:09:23 --> Database Driver Class Initialized
INFO - 2024-10-04 17:09:23 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-04 17:09:23 --> Controller Class Initialized
INFO - 2024-10-04 17:09:32 --> Config Class Initialized
INFO - 2024-10-04 17:09:32 --> Hooks Class Initialized
DEBUG - 2024-10-04 17:09:32 --> UTF-8 Support Enabled
INFO - 2024-10-04 17:09:32 --> Utf8 Class Initialized
INFO - 2024-10-04 17:09:32 --> URI Class Initialized
INFO - 2024-10-04 17:09:32 --> Router Class Initialized
INFO - 2024-10-04 17:09:32 --> Output Class Initialized
INFO - 2024-10-04 17:09:32 --> Security Class Initialized
DEBUG - 2024-10-04 17:09:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-04 17:09:32 --> Input Class Initialized
INFO - 2024-10-04 17:09:32 --> Language Class Initialized
INFO - 2024-10-04 17:09:32 --> Language Class Initialized
INFO - 2024-10-04 17:09:32 --> Config Class Initialized
INFO - 2024-10-04 17:09:32 --> Loader Class Initialized
INFO - 2024-10-04 17:09:32 --> Helper loaded: url_helper
INFO - 2024-10-04 17:09:32 --> Helper loaded: file_helper
INFO - 2024-10-04 17:09:32 --> Helper loaded: form_helper
INFO - 2024-10-04 17:09:32 --> Helper loaded: my_helper
INFO - 2024-10-04 17:09:32 --> Database Driver Class Initialized
INFO - 2024-10-04 17:09:32 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-04 17:09:32 --> Controller Class Initialized
INFO - 2024-10-04 17:09:32 --> Final output sent to browser
DEBUG - 2024-10-04 17:09:32 --> Total execution time: 0.0318
INFO - 2024-10-04 17:09:43 --> Config Class Initialized
INFO - 2024-10-04 17:09:43 --> Hooks Class Initialized
DEBUG - 2024-10-04 17:09:43 --> UTF-8 Support Enabled
INFO - 2024-10-04 17:09:43 --> Utf8 Class Initialized
INFO - 2024-10-04 17:09:43 --> URI Class Initialized
INFO - 2024-10-04 17:09:43 --> Router Class Initialized
INFO - 2024-10-04 17:09:43 --> Output Class Initialized
INFO - 2024-10-04 17:09:43 --> Security Class Initialized
DEBUG - 2024-10-04 17:09:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-04 17:09:43 --> Input Class Initialized
INFO - 2024-10-04 17:09:43 --> Language Class Initialized
INFO - 2024-10-04 17:09:43 --> Language Class Initialized
INFO - 2024-10-04 17:09:43 --> Config Class Initialized
INFO - 2024-10-04 17:09:43 --> Loader Class Initialized
INFO - 2024-10-04 17:09:43 --> Helper loaded: url_helper
INFO - 2024-10-04 17:09:43 --> Helper loaded: file_helper
INFO - 2024-10-04 17:09:43 --> Helper loaded: form_helper
INFO - 2024-10-04 17:09:43 --> Helper loaded: my_helper
INFO - 2024-10-04 17:09:43 --> Database Driver Class Initialized
INFO - 2024-10-04 17:09:43 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-04 17:09:43 --> Controller Class Initialized
INFO - 2024-10-04 17:09:43 --> Final output sent to browser
DEBUG - 2024-10-04 17:09:43 --> Total execution time: 0.0946
INFO - 2024-10-04 17:09:43 --> Config Class Initialized
INFO - 2024-10-04 17:09:43 --> Hooks Class Initialized
DEBUG - 2024-10-04 17:09:43 --> UTF-8 Support Enabled
INFO - 2024-10-04 17:09:43 --> Utf8 Class Initialized
INFO - 2024-10-04 17:09:43 --> URI Class Initialized
INFO - 2024-10-04 17:09:43 --> Router Class Initialized
INFO - 2024-10-04 17:09:43 --> Output Class Initialized
INFO - 2024-10-04 17:09:43 --> Security Class Initialized
DEBUG - 2024-10-04 17:09:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-04 17:09:43 --> Input Class Initialized
INFO - 2024-10-04 17:09:43 --> Language Class Initialized
INFO - 2024-10-04 17:09:43 --> Language Class Initialized
INFO - 2024-10-04 17:09:43 --> Config Class Initialized
INFO - 2024-10-04 17:09:43 --> Loader Class Initialized
INFO - 2024-10-04 17:09:43 --> Helper loaded: url_helper
INFO - 2024-10-04 17:09:43 --> Helper loaded: file_helper
INFO - 2024-10-04 17:09:43 --> Helper loaded: form_helper
INFO - 2024-10-04 17:09:43 --> Helper loaded: my_helper
INFO - 2024-10-04 17:09:43 --> Database Driver Class Initialized
INFO - 2024-10-04 17:09:43 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-04 17:09:43 --> Controller Class Initialized
INFO - 2024-10-04 17:09:53 --> Config Class Initialized
INFO - 2024-10-04 17:09:53 --> Hooks Class Initialized
DEBUG - 2024-10-04 17:09:53 --> UTF-8 Support Enabled
INFO - 2024-10-04 17:09:53 --> Utf8 Class Initialized
INFO - 2024-10-04 17:09:53 --> URI Class Initialized
INFO - 2024-10-04 17:09:53 --> Router Class Initialized
INFO - 2024-10-04 17:09:53 --> Output Class Initialized
INFO - 2024-10-04 17:09:53 --> Security Class Initialized
DEBUG - 2024-10-04 17:09:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-04 17:09:53 --> Input Class Initialized
INFO - 2024-10-04 17:09:53 --> Language Class Initialized
INFO - 2024-10-04 17:09:53 --> Language Class Initialized
INFO - 2024-10-04 17:09:53 --> Config Class Initialized
INFO - 2024-10-04 17:09:53 --> Loader Class Initialized
INFO - 2024-10-04 17:09:53 --> Helper loaded: url_helper
INFO - 2024-10-04 17:09:53 --> Helper loaded: file_helper
INFO - 2024-10-04 17:09:53 --> Helper loaded: form_helper
INFO - 2024-10-04 17:09:53 --> Helper loaded: my_helper
INFO - 2024-10-04 17:09:53 --> Database Driver Class Initialized
INFO - 2024-10-04 17:09:53 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-04 17:09:53 --> Controller Class Initialized
INFO - 2024-10-04 17:09:53 --> Final output sent to browser
DEBUG - 2024-10-04 17:09:53 --> Total execution time: 0.0295
INFO - 2024-10-04 17:10:03 --> Config Class Initialized
INFO - 2024-10-04 17:10:03 --> Hooks Class Initialized
DEBUG - 2024-10-04 17:10:03 --> UTF-8 Support Enabled
INFO - 2024-10-04 17:10:03 --> Utf8 Class Initialized
INFO - 2024-10-04 17:10:03 --> URI Class Initialized
INFO - 2024-10-04 17:10:03 --> Router Class Initialized
INFO - 2024-10-04 17:10:03 --> Output Class Initialized
INFO - 2024-10-04 17:10:03 --> Security Class Initialized
DEBUG - 2024-10-04 17:10:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-04 17:10:03 --> Input Class Initialized
INFO - 2024-10-04 17:10:03 --> Language Class Initialized
INFO - 2024-10-04 17:10:03 --> Language Class Initialized
INFO - 2024-10-04 17:10:03 --> Config Class Initialized
INFO - 2024-10-04 17:10:03 --> Loader Class Initialized
INFO - 2024-10-04 17:10:03 --> Helper loaded: url_helper
INFO - 2024-10-04 17:10:03 --> Helper loaded: file_helper
INFO - 2024-10-04 17:10:03 --> Helper loaded: form_helper
INFO - 2024-10-04 17:10:03 --> Helper loaded: my_helper
INFO - 2024-10-04 17:10:03 --> Database Driver Class Initialized
INFO - 2024-10-04 17:10:03 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-04 17:10:03 --> Controller Class Initialized
INFO - 2024-10-04 17:10:03 --> Final output sent to browser
DEBUG - 2024-10-04 17:10:03 --> Total execution time: 0.0391
INFO - 2024-10-04 17:10:03 --> Config Class Initialized
INFO - 2024-10-04 17:10:03 --> Hooks Class Initialized
DEBUG - 2024-10-04 17:10:03 --> UTF-8 Support Enabled
INFO - 2024-10-04 17:10:03 --> Utf8 Class Initialized
INFO - 2024-10-04 17:10:03 --> URI Class Initialized
INFO - 2024-10-04 17:10:03 --> Router Class Initialized
INFO - 2024-10-04 17:10:03 --> Output Class Initialized
INFO - 2024-10-04 17:10:03 --> Security Class Initialized
DEBUG - 2024-10-04 17:10:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-04 17:10:03 --> Input Class Initialized
INFO - 2024-10-04 17:10:03 --> Language Class Initialized
INFO - 2024-10-04 17:10:03 --> Language Class Initialized
INFO - 2024-10-04 17:10:03 --> Config Class Initialized
INFO - 2024-10-04 17:10:03 --> Loader Class Initialized
INFO - 2024-10-04 17:10:03 --> Helper loaded: url_helper
INFO - 2024-10-04 17:10:03 --> Helper loaded: file_helper
INFO - 2024-10-04 17:10:03 --> Helper loaded: form_helper
INFO - 2024-10-04 17:10:03 --> Helper loaded: my_helper
INFO - 2024-10-04 17:10:03 --> Database Driver Class Initialized
INFO - 2024-10-04 17:10:03 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-04 17:10:03 --> Controller Class Initialized
INFO - 2024-10-04 17:10:05 --> Config Class Initialized
INFO - 2024-10-04 17:10:05 --> Hooks Class Initialized
DEBUG - 2024-10-04 17:10:05 --> UTF-8 Support Enabled
INFO - 2024-10-04 17:10:05 --> Utf8 Class Initialized
INFO - 2024-10-04 17:10:05 --> URI Class Initialized
INFO - 2024-10-04 17:10:05 --> Router Class Initialized
INFO - 2024-10-04 17:10:05 --> Output Class Initialized
INFO - 2024-10-04 17:10:05 --> Security Class Initialized
DEBUG - 2024-10-04 17:10:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-04 17:10:05 --> Input Class Initialized
INFO - 2024-10-04 17:10:05 --> Language Class Initialized
INFO - 2024-10-04 17:10:05 --> Language Class Initialized
INFO - 2024-10-04 17:10:05 --> Config Class Initialized
INFO - 2024-10-04 17:10:05 --> Loader Class Initialized
INFO - 2024-10-04 17:10:05 --> Helper loaded: url_helper
INFO - 2024-10-04 17:10:05 --> Helper loaded: file_helper
INFO - 2024-10-04 17:10:05 --> Helper loaded: form_helper
INFO - 2024-10-04 17:10:05 --> Helper loaded: my_helper
INFO - 2024-10-04 17:10:05 --> Database Driver Class Initialized
INFO - 2024-10-04 17:10:05 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-04 17:10:05 --> Controller Class Initialized
INFO - 2024-10-04 17:10:05 --> Final output sent to browser
DEBUG - 2024-10-04 17:10:05 --> Total execution time: 0.0326
INFO - 2024-10-04 17:10:50 --> Config Class Initialized
INFO - 2024-10-04 17:10:50 --> Hooks Class Initialized
DEBUG - 2024-10-04 17:10:50 --> UTF-8 Support Enabled
INFO - 2024-10-04 17:10:50 --> Utf8 Class Initialized
INFO - 2024-10-04 17:10:50 --> URI Class Initialized
INFO - 2024-10-04 17:10:50 --> Router Class Initialized
INFO - 2024-10-04 17:10:50 --> Output Class Initialized
INFO - 2024-10-04 17:10:50 --> Security Class Initialized
DEBUG - 2024-10-04 17:10:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-04 17:10:50 --> Input Class Initialized
INFO - 2024-10-04 17:10:50 --> Language Class Initialized
INFO - 2024-10-04 17:10:50 --> Language Class Initialized
INFO - 2024-10-04 17:10:50 --> Config Class Initialized
INFO - 2024-10-04 17:10:50 --> Loader Class Initialized
INFO - 2024-10-04 17:10:50 --> Helper loaded: url_helper
INFO - 2024-10-04 17:10:50 --> Helper loaded: file_helper
INFO - 2024-10-04 17:10:50 --> Helper loaded: form_helper
INFO - 2024-10-04 17:10:50 --> Helper loaded: my_helper
INFO - 2024-10-04 17:10:50 --> Database Driver Class Initialized
INFO - 2024-10-04 17:10:50 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-04 17:10:50 --> Controller Class Initialized
INFO - 2024-10-04 17:10:50 --> Final output sent to browser
DEBUG - 2024-10-04 17:10:50 --> Total execution time: 0.0303
INFO - 2024-10-04 17:10:50 --> Config Class Initialized
INFO - 2024-10-04 17:10:50 --> Hooks Class Initialized
DEBUG - 2024-10-04 17:10:50 --> UTF-8 Support Enabled
INFO - 2024-10-04 17:10:50 --> Utf8 Class Initialized
INFO - 2024-10-04 17:10:50 --> URI Class Initialized
INFO - 2024-10-04 17:10:50 --> Router Class Initialized
INFO - 2024-10-04 17:10:50 --> Output Class Initialized
INFO - 2024-10-04 17:10:50 --> Security Class Initialized
DEBUG - 2024-10-04 17:10:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-04 17:10:50 --> Input Class Initialized
INFO - 2024-10-04 17:10:50 --> Language Class Initialized
INFO - 2024-10-04 17:10:50 --> Language Class Initialized
INFO - 2024-10-04 17:10:50 --> Config Class Initialized
INFO - 2024-10-04 17:10:50 --> Loader Class Initialized
INFO - 2024-10-04 17:10:50 --> Helper loaded: url_helper
INFO - 2024-10-04 17:10:50 --> Helper loaded: file_helper
INFO - 2024-10-04 17:10:50 --> Helper loaded: form_helper
INFO - 2024-10-04 17:10:50 --> Helper loaded: my_helper
INFO - 2024-10-04 17:10:50 --> Database Driver Class Initialized
INFO - 2024-10-04 17:10:50 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-04 17:10:50 --> Controller Class Initialized
INFO - 2024-10-04 17:10:52 --> Config Class Initialized
INFO - 2024-10-04 17:10:52 --> Hooks Class Initialized
DEBUG - 2024-10-04 17:10:52 --> UTF-8 Support Enabled
INFO - 2024-10-04 17:10:52 --> Utf8 Class Initialized
INFO - 2024-10-04 17:10:52 --> URI Class Initialized
INFO - 2024-10-04 17:10:52 --> Router Class Initialized
INFO - 2024-10-04 17:10:52 --> Output Class Initialized
INFO - 2024-10-04 17:10:52 --> Security Class Initialized
DEBUG - 2024-10-04 17:10:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-04 17:10:52 --> Input Class Initialized
INFO - 2024-10-04 17:10:52 --> Language Class Initialized
INFO - 2024-10-04 17:10:52 --> Language Class Initialized
INFO - 2024-10-04 17:10:52 --> Config Class Initialized
INFO - 2024-10-04 17:10:52 --> Loader Class Initialized
INFO - 2024-10-04 17:10:52 --> Helper loaded: url_helper
INFO - 2024-10-04 17:10:52 --> Helper loaded: file_helper
INFO - 2024-10-04 17:10:52 --> Helper loaded: form_helper
INFO - 2024-10-04 17:10:52 --> Helper loaded: my_helper
INFO - 2024-10-04 17:10:52 --> Database Driver Class Initialized
INFO - 2024-10-04 17:10:52 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-04 17:10:52 --> Controller Class Initialized
INFO - 2024-10-04 17:10:52 --> Final output sent to browser
DEBUG - 2024-10-04 17:10:52 --> Total execution time: 0.0323
INFO - 2024-10-04 17:10:59 --> Config Class Initialized
INFO - 2024-10-04 17:10:59 --> Hooks Class Initialized
DEBUG - 2024-10-04 17:10:59 --> UTF-8 Support Enabled
INFO - 2024-10-04 17:10:59 --> Utf8 Class Initialized
INFO - 2024-10-04 17:10:59 --> URI Class Initialized
INFO - 2024-10-04 17:10:59 --> Router Class Initialized
INFO - 2024-10-04 17:10:59 --> Output Class Initialized
INFO - 2024-10-04 17:10:59 --> Security Class Initialized
DEBUG - 2024-10-04 17:10:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-04 17:10:59 --> Input Class Initialized
INFO - 2024-10-04 17:10:59 --> Language Class Initialized
INFO - 2024-10-04 17:10:59 --> Language Class Initialized
INFO - 2024-10-04 17:10:59 --> Config Class Initialized
INFO - 2024-10-04 17:10:59 --> Loader Class Initialized
INFO - 2024-10-04 17:10:59 --> Helper loaded: url_helper
INFO - 2024-10-04 17:10:59 --> Helper loaded: file_helper
INFO - 2024-10-04 17:10:59 --> Helper loaded: form_helper
INFO - 2024-10-04 17:10:59 --> Helper loaded: my_helper
INFO - 2024-10-04 17:10:59 --> Database Driver Class Initialized
INFO - 2024-10-04 17:10:59 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-04 17:10:59 --> Controller Class Initialized
INFO - 2024-10-04 17:10:59 --> Final output sent to browser
DEBUG - 2024-10-04 17:10:59 --> Total execution time: 0.0424
INFO - 2024-10-04 17:10:59 --> Config Class Initialized
INFO - 2024-10-04 17:10:59 --> Hooks Class Initialized
DEBUG - 2024-10-04 17:10:59 --> UTF-8 Support Enabled
INFO - 2024-10-04 17:10:59 --> Utf8 Class Initialized
INFO - 2024-10-04 17:10:59 --> URI Class Initialized
INFO - 2024-10-04 17:10:59 --> Router Class Initialized
INFO - 2024-10-04 17:10:59 --> Output Class Initialized
INFO - 2024-10-04 17:10:59 --> Security Class Initialized
DEBUG - 2024-10-04 17:10:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-04 17:10:59 --> Input Class Initialized
INFO - 2024-10-04 17:10:59 --> Language Class Initialized
INFO - 2024-10-04 17:10:59 --> Language Class Initialized
INFO - 2024-10-04 17:10:59 --> Config Class Initialized
INFO - 2024-10-04 17:10:59 --> Loader Class Initialized
INFO - 2024-10-04 17:10:59 --> Helper loaded: url_helper
INFO - 2024-10-04 17:10:59 --> Helper loaded: file_helper
INFO - 2024-10-04 17:10:59 --> Helper loaded: form_helper
INFO - 2024-10-04 17:10:59 --> Helper loaded: my_helper
INFO - 2024-10-04 17:10:59 --> Database Driver Class Initialized
INFO - 2024-10-04 17:10:59 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-04 17:10:59 --> Controller Class Initialized
INFO - 2024-10-04 17:11:14 --> Config Class Initialized
INFO - 2024-10-04 17:11:14 --> Hooks Class Initialized
DEBUG - 2024-10-04 17:11:14 --> UTF-8 Support Enabled
INFO - 2024-10-04 17:11:14 --> Utf8 Class Initialized
INFO - 2024-10-04 17:11:14 --> URI Class Initialized
INFO - 2024-10-04 17:11:14 --> Router Class Initialized
INFO - 2024-10-04 17:11:14 --> Output Class Initialized
INFO - 2024-10-04 17:11:14 --> Security Class Initialized
DEBUG - 2024-10-04 17:11:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-04 17:11:14 --> Input Class Initialized
INFO - 2024-10-04 17:11:14 --> Language Class Initialized
INFO - 2024-10-04 17:11:14 --> Language Class Initialized
INFO - 2024-10-04 17:11:14 --> Config Class Initialized
INFO - 2024-10-04 17:11:14 --> Loader Class Initialized
INFO - 2024-10-04 17:11:14 --> Helper loaded: url_helper
INFO - 2024-10-04 17:11:14 --> Helper loaded: file_helper
INFO - 2024-10-04 17:11:14 --> Helper loaded: form_helper
INFO - 2024-10-04 17:11:14 --> Helper loaded: my_helper
INFO - 2024-10-04 17:11:14 --> Database Driver Class Initialized
INFO - 2024-10-04 17:11:14 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-04 17:11:14 --> Controller Class Initialized
INFO - 2024-10-04 17:11:14 --> Final output sent to browser
DEBUG - 2024-10-04 17:11:14 --> Total execution time: 0.0319
INFO - 2024-10-04 17:11:22 --> Config Class Initialized
INFO - 2024-10-04 17:11:22 --> Hooks Class Initialized
DEBUG - 2024-10-04 17:11:22 --> UTF-8 Support Enabled
INFO - 2024-10-04 17:11:22 --> Utf8 Class Initialized
INFO - 2024-10-04 17:11:22 --> URI Class Initialized
INFO - 2024-10-04 17:11:22 --> Router Class Initialized
INFO - 2024-10-04 17:11:22 --> Output Class Initialized
INFO - 2024-10-04 17:11:22 --> Security Class Initialized
DEBUG - 2024-10-04 17:11:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-04 17:11:22 --> Input Class Initialized
INFO - 2024-10-04 17:11:22 --> Language Class Initialized
INFO - 2024-10-04 17:11:22 --> Language Class Initialized
INFO - 2024-10-04 17:11:22 --> Config Class Initialized
INFO - 2024-10-04 17:11:22 --> Loader Class Initialized
INFO - 2024-10-04 17:11:22 --> Helper loaded: url_helper
INFO - 2024-10-04 17:11:22 --> Helper loaded: file_helper
INFO - 2024-10-04 17:11:22 --> Helper loaded: form_helper
INFO - 2024-10-04 17:11:22 --> Helper loaded: my_helper
INFO - 2024-10-04 17:11:22 --> Database Driver Class Initialized
INFO - 2024-10-04 17:11:22 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-04 17:11:22 --> Controller Class Initialized
INFO - 2024-10-04 17:11:22 --> Final output sent to browser
DEBUG - 2024-10-04 17:11:22 --> Total execution time: 0.0332
INFO - 2024-10-04 17:11:22 --> Config Class Initialized
INFO - 2024-10-04 17:11:22 --> Hooks Class Initialized
DEBUG - 2024-10-04 17:11:22 --> UTF-8 Support Enabled
INFO - 2024-10-04 17:11:22 --> Utf8 Class Initialized
INFO - 2024-10-04 17:11:22 --> URI Class Initialized
INFO - 2024-10-04 17:11:22 --> Router Class Initialized
INFO - 2024-10-04 17:11:22 --> Output Class Initialized
INFO - 2024-10-04 17:11:22 --> Security Class Initialized
DEBUG - 2024-10-04 17:11:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-04 17:11:22 --> Input Class Initialized
INFO - 2024-10-04 17:11:22 --> Language Class Initialized
INFO - 2024-10-04 17:11:22 --> Language Class Initialized
INFO - 2024-10-04 17:11:22 --> Config Class Initialized
INFO - 2024-10-04 17:11:22 --> Loader Class Initialized
INFO - 2024-10-04 17:11:22 --> Helper loaded: url_helper
INFO - 2024-10-04 17:11:22 --> Helper loaded: file_helper
INFO - 2024-10-04 17:11:22 --> Helper loaded: form_helper
INFO - 2024-10-04 17:11:22 --> Helper loaded: my_helper
INFO - 2024-10-04 17:11:22 --> Database Driver Class Initialized
INFO - 2024-10-04 17:11:22 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-04 17:11:22 --> Controller Class Initialized
INFO - 2024-10-04 17:11:26 --> Config Class Initialized
INFO - 2024-10-04 17:11:26 --> Hooks Class Initialized
DEBUG - 2024-10-04 17:11:26 --> UTF-8 Support Enabled
INFO - 2024-10-04 17:11:26 --> Utf8 Class Initialized
INFO - 2024-10-04 17:11:26 --> URI Class Initialized
INFO - 2024-10-04 17:11:26 --> Router Class Initialized
INFO - 2024-10-04 17:11:26 --> Output Class Initialized
INFO - 2024-10-04 17:11:26 --> Security Class Initialized
DEBUG - 2024-10-04 17:11:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-04 17:11:26 --> Input Class Initialized
INFO - 2024-10-04 17:11:26 --> Language Class Initialized
INFO - 2024-10-04 17:11:26 --> Language Class Initialized
INFO - 2024-10-04 17:11:26 --> Config Class Initialized
INFO - 2024-10-04 17:11:26 --> Loader Class Initialized
INFO - 2024-10-04 17:11:26 --> Helper loaded: url_helper
INFO - 2024-10-04 17:11:26 --> Helper loaded: file_helper
INFO - 2024-10-04 17:11:26 --> Helper loaded: form_helper
INFO - 2024-10-04 17:11:26 --> Helper loaded: my_helper
INFO - 2024-10-04 17:11:26 --> Database Driver Class Initialized
INFO - 2024-10-04 17:11:26 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-04 17:11:26 --> Controller Class Initialized
INFO - 2024-10-04 17:11:26 --> Final output sent to browser
DEBUG - 2024-10-04 17:11:26 --> Total execution time: 0.0331
INFO - 2024-10-04 17:11:37 --> Config Class Initialized
INFO - 2024-10-04 17:11:37 --> Hooks Class Initialized
DEBUG - 2024-10-04 17:11:37 --> UTF-8 Support Enabled
INFO - 2024-10-04 17:11:37 --> Utf8 Class Initialized
INFO - 2024-10-04 17:11:37 --> URI Class Initialized
INFO - 2024-10-04 17:11:37 --> Router Class Initialized
INFO - 2024-10-04 17:11:37 --> Output Class Initialized
INFO - 2024-10-04 17:11:37 --> Security Class Initialized
DEBUG - 2024-10-04 17:11:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-04 17:11:37 --> Input Class Initialized
INFO - 2024-10-04 17:11:37 --> Language Class Initialized
INFO - 2024-10-04 17:11:37 --> Language Class Initialized
INFO - 2024-10-04 17:11:37 --> Config Class Initialized
INFO - 2024-10-04 17:11:37 --> Loader Class Initialized
INFO - 2024-10-04 17:11:37 --> Helper loaded: url_helper
INFO - 2024-10-04 17:11:37 --> Helper loaded: file_helper
INFO - 2024-10-04 17:11:37 --> Helper loaded: form_helper
INFO - 2024-10-04 17:11:37 --> Helper loaded: my_helper
INFO - 2024-10-04 17:11:37 --> Database Driver Class Initialized
INFO - 2024-10-04 17:11:37 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-04 17:11:37 --> Controller Class Initialized
DEBUG - 2024-10-04 17:11:37 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/view_mapel/views/v_view_mapel.php
DEBUG - 2024-10-04 17:11:37 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-10-04 17:11:37 --> Final output sent to browser
DEBUG - 2024-10-04 17:11:37 --> Total execution time: 0.0327
INFO - 2024-10-04 17:12:30 --> Config Class Initialized
INFO - 2024-10-04 17:12:30 --> Hooks Class Initialized
DEBUG - 2024-10-04 17:12:30 --> UTF-8 Support Enabled
INFO - 2024-10-04 17:12:30 --> Utf8 Class Initialized
INFO - 2024-10-04 17:12:30 --> URI Class Initialized
INFO - 2024-10-04 17:12:30 --> Router Class Initialized
INFO - 2024-10-04 17:12:30 --> Output Class Initialized
INFO - 2024-10-04 17:12:30 --> Security Class Initialized
DEBUG - 2024-10-04 17:12:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-04 17:12:30 --> Input Class Initialized
INFO - 2024-10-04 17:12:30 --> Language Class Initialized
INFO - 2024-10-04 17:12:30 --> Language Class Initialized
INFO - 2024-10-04 17:12:30 --> Config Class Initialized
INFO - 2024-10-04 17:12:30 --> Loader Class Initialized
INFO - 2024-10-04 17:12:30 --> Helper loaded: url_helper
INFO - 2024-10-04 17:12:30 --> Helper loaded: file_helper
INFO - 2024-10-04 17:12:30 --> Helper loaded: form_helper
INFO - 2024-10-04 17:12:30 --> Helper loaded: my_helper
INFO - 2024-10-04 17:12:30 --> Database Driver Class Initialized
INFO - 2024-10-04 17:12:30 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-04 17:12:30 --> Controller Class Initialized
DEBUG - 2024-10-04 17:12:30 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/views/list.php
DEBUG - 2024-10-04 17:12:30 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-10-04 17:12:30 --> Final output sent to browser
DEBUG - 2024-10-04 17:12:30 --> Total execution time: 0.0761
INFO - 2024-10-04 17:12:31 --> Config Class Initialized
INFO - 2024-10-04 17:12:31 --> Hooks Class Initialized
DEBUG - 2024-10-04 17:12:31 --> UTF-8 Support Enabled
INFO - 2024-10-04 17:12:31 --> Utf8 Class Initialized
INFO - 2024-10-04 17:12:31 --> URI Class Initialized
INFO - 2024-10-04 17:12:31 --> Router Class Initialized
INFO - 2024-10-04 17:12:31 --> Output Class Initialized
INFO - 2024-10-04 17:12:31 --> Security Class Initialized
DEBUG - 2024-10-04 17:12:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-04 17:12:31 --> Input Class Initialized
INFO - 2024-10-04 17:12:31 --> Language Class Initialized
INFO - 2024-10-04 17:12:31 --> Language Class Initialized
INFO - 2024-10-04 17:12:31 --> Config Class Initialized
INFO - 2024-10-04 17:12:31 --> Loader Class Initialized
INFO - 2024-10-04 17:12:31 --> Helper loaded: url_helper
INFO - 2024-10-04 17:12:31 --> Helper loaded: file_helper
INFO - 2024-10-04 17:12:31 --> Helper loaded: form_helper
INFO - 2024-10-04 17:12:31 --> Helper loaded: my_helper
INFO - 2024-10-04 17:12:31 --> Database Driver Class Initialized
INFO - 2024-10-04 17:12:31 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-04 17:12:31 --> Controller Class Initialized
INFO - 2024-10-04 17:12:33 --> Config Class Initialized
INFO - 2024-10-04 17:12:33 --> Hooks Class Initialized
DEBUG - 2024-10-04 17:12:33 --> UTF-8 Support Enabled
INFO - 2024-10-04 17:12:33 --> Utf8 Class Initialized
INFO - 2024-10-04 17:12:33 --> URI Class Initialized
INFO - 2024-10-04 17:12:33 --> Router Class Initialized
INFO - 2024-10-04 17:12:33 --> Output Class Initialized
INFO - 2024-10-04 17:12:33 --> Security Class Initialized
DEBUG - 2024-10-04 17:12:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-04 17:12:33 --> Input Class Initialized
INFO - 2024-10-04 17:12:33 --> Language Class Initialized
INFO - 2024-10-04 17:12:33 --> Language Class Initialized
INFO - 2024-10-04 17:12:33 --> Config Class Initialized
INFO - 2024-10-04 17:12:33 --> Loader Class Initialized
INFO - 2024-10-04 17:12:33 --> Helper loaded: url_helper
INFO - 2024-10-04 17:12:33 --> Helper loaded: file_helper
INFO - 2024-10-04 17:12:33 --> Helper loaded: form_helper
INFO - 2024-10-04 17:12:33 --> Helper loaded: my_helper
INFO - 2024-10-04 17:12:33 --> Database Driver Class Initialized
INFO - 2024-10-04 17:12:33 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-04 17:12:33 --> Controller Class Initialized
INFO - 2024-10-04 17:12:33 --> Final output sent to browser
DEBUG - 2024-10-04 17:12:33 --> Total execution time: 0.0705
INFO - 2024-10-04 17:12:36 --> Config Class Initialized
INFO - 2024-10-04 17:12:36 --> Hooks Class Initialized
DEBUG - 2024-10-04 17:12:36 --> UTF-8 Support Enabled
INFO - 2024-10-04 17:12:36 --> Utf8 Class Initialized
INFO - 2024-10-04 17:12:36 --> URI Class Initialized
INFO - 2024-10-04 17:12:36 --> Router Class Initialized
INFO - 2024-10-04 17:12:36 --> Output Class Initialized
INFO - 2024-10-04 17:12:36 --> Security Class Initialized
DEBUG - 2024-10-04 17:12:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-04 17:12:36 --> Input Class Initialized
INFO - 2024-10-04 17:12:36 --> Language Class Initialized
INFO - 2024-10-04 17:12:36 --> Language Class Initialized
INFO - 2024-10-04 17:12:36 --> Config Class Initialized
INFO - 2024-10-04 17:12:36 --> Loader Class Initialized
INFO - 2024-10-04 17:12:36 --> Helper loaded: url_helper
INFO - 2024-10-04 17:12:36 --> Helper loaded: file_helper
INFO - 2024-10-04 17:12:36 --> Helper loaded: form_helper
INFO - 2024-10-04 17:12:36 --> Helper loaded: my_helper
INFO - 2024-10-04 17:12:36 --> Database Driver Class Initialized
INFO - 2024-10-04 17:12:36 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-04 17:12:36 --> Controller Class Initialized
DEBUG - 2024-10-04 17:12:36 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/view_mapel/views/v_view_mapel.php
DEBUG - 2024-10-04 17:12:36 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-10-04 17:12:36 --> Final output sent to browser
DEBUG - 2024-10-04 17:12:36 --> Total execution time: 0.0320
INFO - 2024-10-04 17:12:40 --> Config Class Initialized
INFO - 2024-10-04 17:12:40 --> Hooks Class Initialized
DEBUG - 2024-10-04 17:12:40 --> UTF-8 Support Enabled
INFO - 2024-10-04 17:12:40 --> Utf8 Class Initialized
INFO - 2024-10-04 17:12:40 --> URI Class Initialized
INFO - 2024-10-04 17:12:40 --> Router Class Initialized
INFO - 2024-10-04 17:12:40 --> Output Class Initialized
INFO - 2024-10-04 17:12:40 --> Security Class Initialized
DEBUG - 2024-10-04 17:12:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-04 17:12:40 --> Input Class Initialized
INFO - 2024-10-04 17:12:40 --> Language Class Initialized
INFO - 2024-10-04 17:12:40 --> Language Class Initialized
INFO - 2024-10-04 17:12:40 --> Config Class Initialized
INFO - 2024-10-04 17:12:40 --> Loader Class Initialized
INFO - 2024-10-04 17:12:40 --> Helper loaded: url_helper
INFO - 2024-10-04 17:12:40 --> Helper loaded: file_helper
INFO - 2024-10-04 17:12:40 --> Helper loaded: form_helper
INFO - 2024-10-04 17:12:40 --> Helper loaded: my_helper
INFO - 2024-10-04 17:12:40 --> Database Driver Class Initialized
INFO - 2024-10-04 17:12:40 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-04 17:12:40 --> Controller Class Initialized
DEBUG - 2024-10-04 17:12:40 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/view_mapel/views/v_view_mapel.php
DEBUG - 2024-10-04 17:12:40 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-10-04 17:12:40 --> Final output sent to browser
DEBUG - 2024-10-04 17:12:40 --> Total execution time: 0.0432
INFO - 2024-10-04 17:12:44 --> Config Class Initialized
INFO - 2024-10-04 17:12:44 --> Hooks Class Initialized
DEBUG - 2024-10-04 17:12:44 --> UTF-8 Support Enabled
INFO - 2024-10-04 17:12:44 --> Utf8 Class Initialized
INFO - 2024-10-04 17:12:44 --> URI Class Initialized
INFO - 2024-10-04 17:12:44 --> Router Class Initialized
INFO - 2024-10-04 17:12:44 --> Output Class Initialized
INFO - 2024-10-04 17:12:44 --> Security Class Initialized
DEBUG - 2024-10-04 17:12:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-04 17:12:44 --> Input Class Initialized
INFO - 2024-10-04 17:12:44 --> Language Class Initialized
INFO - 2024-10-04 17:12:44 --> Language Class Initialized
INFO - 2024-10-04 17:12:44 --> Config Class Initialized
INFO - 2024-10-04 17:12:44 --> Loader Class Initialized
INFO - 2024-10-04 17:12:44 --> Helper loaded: url_helper
INFO - 2024-10-04 17:12:44 --> Helper loaded: file_helper
INFO - 2024-10-04 17:12:44 --> Helper loaded: form_helper
INFO - 2024-10-04 17:12:44 --> Helper loaded: my_helper
INFO - 2024-10-04 17:12:44 --> Database Driver Class Initialized
INFO - 2024-10-04 17:12:44 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-04 17:12:44 --> Controller Class Initialized
DEBUG - 2024-10-04 17:12:44 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/views/list.php
DEBUG - 2024-10-04 17:12:44 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-10-04 17:12:44 --> Final output sent to browser
DEBUG - 2024-10-04 17:12:44 --> Total execution time: 0.0332
INFO - 2024-10-04 17:12:44 --> Config Class Initialized
INFO - 2024-10-04 17:12:44 --> Hooks Class Initialized
DEBUG - 2024-10-04 17:12:44 --> UTF-8 Support Enabled
INFO - 2024-10-04 17:12:44 --> Utf8 Class Initialized
INFO - 2024-10-04 17:12:44 --> URI Class Initialized
INFO - 2024-10-04 17:12:44 --> Router Class Initialized
INFO - 2024-10-04 17:12:44 --> Output Class Initialized
INFO - 2024-10-04 17:12:44 --> Security Class Initialized
DEBUG - 2024-10-04 17:12:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-04 17:12:44 --> Input Class Initialized
INFO - 2024-10-04 17:12:44 --> Language Class Initialized
INFO - 2024-10-04 17:12:44 --> Language Class Initialized
INFO - 2024-10-04 17:12:44 --> Config Class Initialized
INFO - 2024-10-04 17:12:44 --> Loader Class Initialized
INFO - 2024-10-04 17:12:44 --> Helper loaded: url_helper
INFO - 2024-10-04 17:12:44 --> Helper loaded: file_helper
INFO - 2024-10-04 17:12:44 --> Helper loaded: form_helper
INFO - 2024-10-04 17:12:44 --> Helper loaded: my_helper
INFO - 2024-10-04 17:12:44 --> Database Driver Class Initialized
INFO - 2024-10-04 17:12:44 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-04 17:12:44 --> Controller Class Initialized
INFO - 2024-10-04 17:13:14 --> Config Class Initialized
INFO - 2024-10-04 17:13:14 --> Hooks Class Initialized
DEBUG - 2024-10-04 17:13:14 --> UTF-8 Support Enabled
INFO - 2024-10-04 17:13:14 --> Utf8 Class Initialized
INFO - 2024-10-04 17:13:14 --> URI Class Initialized
INFO - 2024-10-04 17:13:14 --> Router Class Initialized
INFO - 2024-10-04 17:13:14 --> Output Class Initialized
INFO - 2024-10-04 17:13:14 --> Security Class Initialized
DEBUG - 2024-10-04 17:13:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-04 17:13:14 --> Input Class Initialized
INFO - 2024-10-04 17:13:14 --> Language Class Initialized
INFO - 2024-10-04 17:13:14 --> Language Class Initialized
INFO - 2024-10-04 17:13:14 --> Config Class Initialized
INFO - 2024-10-04 17:13:14 --> Loader Class Initialized
INFO - 2024-10-04 17:13:14 --> Helper loaded: url_helper
INFO - 2024-10-04 17:13:14 --> Helper loaded: file_helper
INFO - 2024-10-04 17:13:14 --> Helper loaded: form_helper
INFO - 2024-10-04 17:13:14 --> Helper loaded: my_helper
INFO - 2024-10-04 17:13:14 --> Database Driver Class Initialized
INFO - 2024-10-04 17:13:14 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-04 17:13:14 --> Controller Class Initialized
DEBUG - 2024-10-04 17:13:14 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/view_mapel/views/v_view_mapel.php
DEBUG - 2024-10-04 17:13:14 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-10-04 17:13:14 --> Final output sent to browser
DEBUG - 2024-10-04 17:13:14 --> Total execution time: 0.0366
