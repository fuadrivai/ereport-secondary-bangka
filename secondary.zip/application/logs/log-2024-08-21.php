<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2024-08-21 05:57:39 --> Config Class Initialized
INFO - 2024-08-21 05:57:39 --> Hooks Class Initialized
DEBUG - 2024-08-21 05:57:39 --> UTF-8 Support Enabled
INFO - 2024-08-21 05:57:39 --> Utf8 Class Initialized
INFO - 2024-08-21 05:57:39 --> URI Class Initialized
INFO - 2024-08-21 05:57:39 --> Router Class Initialized
INFO - 2024-08-21 05:57:39 --> Output Class Initialized
INFO - 2024-08-21 05:57:39 --> Security Class Initialized
DEBUG - 2024-08-21 05:57:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-08-21 05:57:39 --> Input Class Initialized
INFO - 2024-08-21 05:57:39 --> Language Class Initialized
INFO - 2024-08-21 05:57:39 --> Language Class Initialized
INFO - 2024-08-21 05:57:39 --> Config Class Initialized
INFO - 2024-08-21 05:57:39 --> Loader Class Initialized
INFO - 2024-08-21 05:57:39 --> Helper loaded: url_helper
INFO - 2024-08-21 05:57:39 --> Helper loaded: file_helper
INFO - 2024-08-21 05:57:39 --> Helper loaded: form_helper
INFO - 2024-08-21 05:57:39 --> Helper loaded: my_helper
INFO - 2024-08-21 05:57:39 --> Database Driver Class Initialized
INFO - 2024-08-21 05:57:39 --> Session: Class initialized using 'files' driver.
INFO - 2024-08-21 05:57:39 --> Controller Class Initialized
INFO - 2024-08-21 05:57:39 --> Helper loaded: cookie_helper
INFO - 2024-08-21 05:57:39 --> Final output sent to browser
DEBUG - 2024-08-21 05:57:39 --> Total execution time: 0.1051
INFO - 2024-08-21 05:57:39 --> Config Class Initialized
INFO - 2024-08-21 05:57:39 --> Hooks Class Initialized
DEBUG - 2024-08-21 05:57:39 --> UTF-8 Support Enabled
INFO - 2024-08-21 05:57:39 --> Utf8 Class Initialized
INFO - 2024-08-21 05:57:39 --> URI Class Initialized
INFO - 2024-08-21 05:57:39 --> Router Class Initialized
INFO - 2024-08-21 05:57:39 --> Output Class Initialized
INFO - 2024-08-21 05:57:39 --> Security Class Initialized
DEBUG - 2024-08-21 05:57:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-08-21 05:57:39 --> Input Class Initialized
INFO - 2024-08-21 05:57:39 --> Language Class Initialized
INFO - 2024-08-21 05:57:39 --> Language Class Initialized
INFO - 2024-08-21 05:57:39 --> Config Class Initialized
INFO - 2024-08-21 05:57:39 --> Loader Class Initialized
INFO - 2024-08-21 05:57:39 --> Helper loaded: url_helper
INFO - 2024-08-21 05:57:39 --> Helper loaded: file_helper
INFO - 2024-08-21 05:57:39 --> Helper loaded: form_helper
INFO - 2024-08-21 05:57:39 --> Helper loaded: my_helper
INFO - 2024-08-21 05:57:39 --> Database Driver Class Initialized
INFO - 2024-08-21 05:57:39 --> Session: Class initialized using 'files' driver.
INFO - 2024-08-21 05:57:39 --> Controller Class Initialized
INFO - 2024-08-21 05:57:39 --> Helper loaded: cookie_helper
INFO - 2024-08-21 05:57:39 --> Config Class Initialized
INFO - 2024-08-21 05:57:39 --> Hooks Class Initialized
DEBUG - 2024-08-21 05:57:39 --> UTF-8 Support Enabled
INFO - 2024-08-21 05:57:39 --> Utf8 Class Initialized
INFO - 2024-08-21 05:57:39 --> URI Class Initialized
INFO - 2024-08-21 05:57:39 --> Router Class Initialized
INFO - 2024-08-21 05:57:39 --> Output Class Initialized
INFO - 2024-08-21 05:57:39 --> Security Class Initialized
DEBUG - 2024-08-21 05:57:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-08-21 05:57:39 --> Input Class Initialized
INFO - 2024-08-21 05:57:39 --> Language Class Initialized
INFO - 2024-08-21 05:57:39 --> Language Class Initialized
INFO - 2024-08-21 05:57:39 --> Config Class Initialized
INFO - 2024-08-21 05:57:39 --> Loader Class Initialized
INFO - 2024-08-21 05:57:39 --> Helper loaded: url_helper
INFO - 2024-08-21 05:57:39 --> Helper loaded: file_helper
INFO - 2024-08-21 05:57:39 --> Helper loaded: form_helper
INFO - 2024-08-21 05:57:39 --> Helper loaded: my_helper
INFO - 2024-08-21 05:57:39 --> Database Driver Class Initialized
INFO - 2024-08-21 05:57:39 --> Session: Class initialized using 'files' driver.
INFO - 2024-08-21 05:57:39 --> Controller Class Initialized
DEBUG - 2024-08-21 05:57:39 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/lihat_raport/views/list.php
DEBUG - 2024-08-21 05:57:39 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-08-21 05:57:39 --> Final output sent to browser
DEBUG - 2024-08-21 05:57:39 --> Total execution time: 0.0536
INFO - 2024-08-21 05:57:50 --> Config Class Initialized
INFO - 2024-08-21 05:57:50 --> Hooks Class Initialized
DEBUG - 2024-08-21 05:57:50 --> UTF-8 Support Enabled
INFO - 2024-08-21 05:57:50 --> Utf8 Class Initialized
INFO - 2024-08-21 05:57:50 --> URI Class Initialized
INFO - 2024-08-21 05:57:50 --> Router Class Initialized
INFO - 2024-08-21 05:57:50 --> Output Class Initialized
INFO - 2024-08-21 05:57:50 --> Security Class Initialized
DEBUG - 2024-08-21 05:57:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-08-21 05:57:50 --> Input Class Initialized
INFO - 2024-08-21 05:57:50 --> Language Class Initialized
INFO - 2024-08-21 05:57:50 --> Language Class Initialized
INFO - 2024-08-21 05:57:50 --> Config Class Initialized
INFO - 2024-08-21 05:57:50 --> Loader Class Initialized
INFO - 2024-08-21 05:57:50 --> Helper loaded: url_helper
INFO - 2024-08-21 05:57:50 --> Helper loaded: file_helper
INFO - 2024-08-21 05:57:50 --> Helper loaded: form_helper
INFO - 2024-08-21 05:57:50 --> Helper loaded: my_helper
INFO - 2024-08-21 05:57:50 --> Database Driver Class Initialized
INFO - 2024-08-21 05:57:50 --> Session: Class initialized using 'files' driver.
INFO - 2024-08-21 05:57:50 --> Controller Class Initialized
INFO - 2024-08-21 05:57:50 --> Helper loaded: cookie_helper
INFO - 2024-08-21 05:57:50 --> Final output sent to browser
DEBUG - 2024-08-21 05:57:50 --> Total execution time: 0.0700
INFO - 2024-08-21 05:57:50 --> Config Class Initialized
INFO - 2024-08-21 05:57:50 --> Hooks Class Initialized
DEBUG - 2024-08-21 05:57:50 --> UTF-8 Support Enabled
INFO - 2024-08-21 05:57:50 --> Utf8 Class Initialized
INFO - 2024-08-21 05:57:50 --> URI Class Initialized
INFO - 2024-08-21 05:57:50 --> Router Class Initialized
INFO - 2024-08-21 05:57:50 --> Output Class Initialized
INFO - 2024-08-21 05:57:50 --> Security Class Initialized
DEBUG - 2024-08-21 05:57:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-08-21 05:57:50 --> Input Class Initialized
INFO - 2024-08-21 05:57:50 --> Language Class Initialized
INFO - 2024-08-21 05:57:50 --> Language Class Initialized
INFO - 2024-08-21 05:57:50 --> Config Class Initialized
INFO - 2024-08-21 05:57:50 --> Loader Class Initialized
INFO - 2024-08-21 05:57:50 --> Helper loaded: url_helper
INFO - 2024-08-21 05:57:50 --> Helper loaded: file_helper
INFO - 2024-08-21 05:57:50 --> Helper loaded: form_helper
INFO - 2024-08-21 05:57:50 --> Helper loaded: my_helper
INFO - 2024-08-21 05:57:50 --> Database Driver Class Initialized
INFO - 2024-08-21 05:57:50 --> Session: Class initialized using 'files' driver.
INFO - 2024-08-21 05:57:50 --> Controller Class Initialized
INFO - 2024-08-21 05:57:50 --> Helper loaded: cookie_helper
INFO - 2024-08-21 05:57:51 --> Config Class Initialized
INFO - 2024-08-21 05:57:51 --> Hooks Class Initialized
DEBUG - 2024-08-21 05:57:51 --> UTF-8 Support Enabled
INFO - 2024-08-21 05:57:51 --> Utf8 Class Initialized
INFO - 2024-08-21 05:57:51 --> URI Class Initialized
INFO - 2024-08-21 05:57:51 --> Router Class Initialized
INFO - 2024-08-21 05:57:51 --> Output Class Initialized
INFO - 2024-08-21 05:57:51 --> Security Class Initialized
DEBUG - 2024-08-21 05:57:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-08-21 05:57:51 --> Input Class Initialized
INFO - 2024-08-21 05:57:51 --> Language Class Initialized
INFO - 2024-08-21 05:57:51 --> Language Class Initialized
INFO - 2024-08-21 05:57:51 --> Config Class Initialized
INFO - 2024-08-21 05:57:51 --> Loader Class Initialized
INFO - 2024-08-21 05:57:51 --> Helper loaded: url_helper
INFO - 2024-08-21 05:57:51 --> Helper loaded: file_helper
INFO - 2024-08-21 05:57:51 --> Helper loaded: form_helper
INFO - 2024-08-21 05:57:51 --> Helper loaded: my_helper
INFO - 2024-08-21 05:57:51 --> Database Driver Class Initialized
INFO - 2024-08-21 05:57:51 --> Session: Class initialized using 'files' driver.
INFO - 2024-08-21 05:57:51 --> Controller Class Initialized
DEBUG - 2024-08-21 05:57:51 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/lihat_raport/views/list.php
DEBUG - 2024-08-21 05:57:51 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-08-21 05:57:51 --> Final output sent to browser
DEBUG - 2024-08-21 05:57:51 --> Total execution time: 0.0302
INFO - 2024-08-21 08:04:51 --> Config Class Initialized
INFO - 2024-08-21 08:04:51 --> Hooks Class Initialized
DEBUG - 2024-08-21 08:04:51 --> UTF-8 Support Enabled
INFO - 2024-08-21 08:04:51 --> Utf8 Class Initialized
INFO - 2024-08-21 08:04:51 --> URI Class Initialized
INFO - 2024-08-21 08:04:51 --> Router Class Initialized
INFO - 2024-08-21 08:04:51 --> Output Class Initialized
INFO - 2024-08-21 08:04:51 --> Security Class Initialized
DEBUG - 2024-08-21 08:04:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-08-21 08:04:51 --> Input Class Initialized
INFO - 2024-08-21 08:04:51 --> Language Class Initialized
INFO - 2024-08-21 08:04:51 --> Language Class Initialized
INFO - 2024-08-21 08:04:51 --> Config Class Initialized
INFO - 2024-08-21 08:04:51 --> Loader Class Initialized
INFO - 2024-08-21 08:04:51 --> Helper loaded: url_helper
INFO - 2024-08-21 08:04:51 --> Helper loaded: file_helper
INFO - 2024-08-21 08:04:51 --> Helper loaded: form_helper
INFO - 2024-08-21 08:04:51 --> Helper loaded: my_helper
INFO - 2024-08-21 08:04:51 --> Database Driver Class Initialized
INFO - 2024-08-21 08:04:51 --> Session: Class initialized using 'files' driver.
INFO - 2024-08-21 08:04:51 --> Controller Class Initialized
INFO - 2024-08-21 08:04:51 --> Helper loaded: cookie_helper
INFO - 2024-08-21 08:04:51 --> Final output sent to browser
DEBUG - 2024-08-21 08:04:51 --> Total execution time: 0.0519
INFO - 2024-08-21 08:04:51 --> Config Class Initialized
INFO - 2024-08-21 08:04:51 --> Hooks Class Initialized
DEBUG - 2024-08-21 08:04:51 --> UTF-8 Support Enabled
INFO - 2024-08-21 08:04:51 --> Utf8 Class Initialized
INFO - 2024-08-21 08:04:51 --> URI Class Initialized
INFO - 2024-08-21 08:04:51 --> Router Class Initialized
INFO - 2024-08-21 08:04:51 --> Output Class Initialized
INFO - 2024-08-21 08:04:51 --> Security Class Initialized
DEBUG - 2024-08-21 08:04:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-08-21 08:04:51 --> Input Class Initialized
INFO - 2024-08-21 08:04:51 --> Language Class Initialized
INFO - 2024-08-21 08:04:51 --> Language Class Initialized
INFO - 2024-08-21 08:04:51 --> Config Class Initialized
INFO - 2024-08-21 08:04:51 --> Loader Class Initialized
INFO - 2024-08-21 08:04:51 --> Helper loaded: url_helper
INFO - 2024-08-21 08:04:51 --> Helper loaded: file_helper
INFO - 2024-08-21 08:04:51 --> Helper loaded: form_helper
INFO - 2024-08-21 08:04:51 --> Helper loaded: my_helper
INFO - 2024-08-21 08:04:51 --> Database Driver Class Initialized
INFO - 2024-08-21 08:04:51 --> Session: Class initialized using 'files' driver.
INFO - 2024-08-21 08:04:51 --> Controller Class Initialized
INFO - 2024-08-21 08:04:51 --> Helper loaded: cookie_helper
INFO - 2024-08-21 08:04:52 --> Config Class Initialized
INFO - 2024-08-21 08:04:52 --> Hooks Class Initialized
DEBUG - 2024-08-21 08:04:52 --> UTF-8 Support Enabled
INFO - 2024-08-21 08:04:52 --> Utf8 Class Initialized
INFO - 2024-08-21 08:04:52 --> URI Class Initialized
INFO - 2024-08-21 08:04:52 --> Router Class Initialized
INFO - 2024-08-21 08:04:52 --> Output Class Initialized
INFO - 2024-08-21 08:04:52 --> Security Class Initialized
DEBUG - 2024-08-21 08:04:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-08-21 08:04:52 --> Input Class Initialized
INFO - 2024-08-21 08:04:52 --> Language Class Initialized
INFO - 2024-08-21 08:04:52 --> Language Class Initialized
INFO - 2024-08-21 08:04:52 --> Config Class Initialized
INFO - 2024-08-21 08:04:52 --> Loader Class Initialized
INFO - 2024-08-21 08:04:52 --> Helper loaded: url_helper
INFO - 2024-08-21 08:04:52 --> Helper loaded: file_helper
INFO - 2024-08-21 08:04:52 --> Helper loaded: form_helper
INFO - 2024-08-21 08:04:52 --> Helper loaded: my_helper
INFO - 2024-08-21 08:04:52 --> Database Driver Class Initialized
INFO - 2024-08-21 08:04:52 --> Session: Class initialized using 'files' driver.
INFO - 2024-08-21 08:04:52 --> Controller Class Initialized
DEBUG - 2024-08-21 08:04:52 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/lihat_raport/views/list.php
DEBUG - 2024-08-21 08:04:52 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-08-21 08:04:52 --> Final output sent to browser
DEBUG - 2024-08-21 08:04:52 --> Total execution time: 0.0481
INFO - 2024-08-21 08:24:13 --> Config Class Initialized
INFO - 2024-08-21 08:24:13 --> Hooks Class Initialized
DEBUG - 2024-08-21 08:24:13 --> UTF-8 Support Enabled
INFO - 2024-08-21 08:24:13 --> Utf8 Class Initialized
INFO - 2024-08-21 08:24:13 --> URI Class Initialized
INFO - 2024-08-21 08:24:13 --> Router Class Initialized
INFO - 2024-08-21 08:24:13 --> Output Class Initialized
INFO - 2024-08-21 08:24:13 --> Security Class Initialized
DEBUG - 2024-08-21 08:24:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-08-21 08:24:13 --> Input Class Initialized
INFO - 2024-08-21 08:24:13 --> Language Class Initialized
INFO - 2024-08-21 08:24:13 --> Language Class Initialized
INFO - 2024-08-21 08:24:13 --> Config Class Initialized
INFO - 2024-08-21 08:24:13 --> Loader Class Initialized
INFO - 2024-08-21 08:24:13 --> Helper loaded: url_helper
INFO - 2024-08-21 08:24:13 --> Helper loaded: file_helper
INFO - 2024-08-21 08:24:13 --> Helper loaded: form_helper
INFO - 2024-08-21 08:24:13 --> Helper loaded: my_helper
INFO - 2024-08-21 08:24:13 --> Database Driver Class Initialized
INFO - 2024-08-21 08:24:13 --> Session: Class initialized using 'files' driver.
INFO - 2024-08-21 08:24:13 --> Controller Class Initialized
INFO - 2024-08-21 08:24:13 --> Helper loaded: cookie_helper
INFO - 2024-08-21 08:24:13 --> Final output sent to browser
DEBUG - 2024-08-21 08:24:13 --> Total execution time: 0.0640
INFO - 2024-08-21 08:24:14 --> Config Class Initialized
INFO - 2024-08-21 08:24:14 --> Hooks Class Initialized
DEBUG - 2024-08-21 08:24:14 --> UTF-8 Support Enabled
INFO - 2024-08-21 08:24:14 --> Utf8 Class Initialized
INFO - 2024-08-21 08:24:14 --> URI Class Initialized
INFO - 2024-08-21 08:24:14 --> Router Class Initialized
INFO - 2024-08-21 08:24:14 --> Output Class Initialized
INFO - 2024-08-21 08:24:14 --> Security Class Initialized
DEBUG - 2024-08-21 08:24:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-08-21 08:24:14 --> Input Class Initialized
INFO - 2024-08-21 08:24:14 --> Language Class Initialized
INFO - 2024-08-21 08:24:14 --> Language Class Initialized
INFO - 2024-08-21 08:24:14 --> Config Class Initialized
INFO - 2024-08-21 08:24:14 --> Loader Class Initialized
INFO - 2024-08-21 08:24:14 --> Helper loaded: url_helper
INFO - 2024-08-21 08:24:14 --> Helper loaded: file_helper
INFO - 2024-08-21 08:24:14 --> Helper loaded: form_helper
INFO - 2024-08-21 08:24:14 --> Helper loaded: my_helper
INFO - 2024-08-21 08:24:14 --> Database Driver Class Initialized
INFO - 2024-08-21 08:24:14 --> Session: Class initialized using 'files' driver.
INFO - 2024-08-21 08:24:14 --> Controller Class Initialized
INFO - 2024-08-21 08:24:14 --> Helper loaded: cookie_helper
INFO - 2024-08-21 08:24:15 --> Config Class Initialized
INFO - 2024-08-21 08:24:15 --> Hooks Class Initialized
DEBUG - 2024-08-21 08:24:15 --> UTF-8 Support Enabled
INFO - 2024-08-21 08:24:15 --> Utf8 Class Initialized
INFO - 2024-08-21 08:24:15 --> URI Class Initialized
INFO - 2024-08-21 08:24:15 --> Router Class Initialized
INFO - 2024-08-21 08:24:15 --> Output Class Initialized
INFO - 2024-08-21 08:24:15 --> Security Class Initialized
DEBUG - 2024-08-21 08:24:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-08-21 08:24:15 --> Input Class Initialized
INFO - 2024-08-21 08:24:15 --> Language Class Initialized
INFO - 2024-08-21 08:24:15 --> Language Class Initialized
INFO - 2024-08-21 08:24:15 --> Config Class Initialized
INFO - 2024-08-21 08:24:15 --> Loader Class Initialized
INFO - 2024-08-21 08:24:15 --> Helper loaded: url_helper
INFO - 2024-08-21 08:24:15 --> Helper loaded: file_helper
INFO - 2024-08-21 08:24:15 --> Helper loaded: form_helper
INFO - 2024-08-21 08:24:15 --> Helper loaded: my_helper
INFO - 2024-08-21 08:24:15 --> Database Driver Class Initialized
INFO - 2024-08-21 08:24:15 --> Session: Class initialized using 'files' driver.
INFO - 2024-08-21 08:24:15 --> Controller Class Initialized
DEBUG - 2024-08-21 08:24:15 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/lihat_raport/views/list.php
DEBUG - 2024-08-21 08:24:15 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-08-21 08:24:15 --> Final output sent to browser
DEBUG - 2024-08-21 08:24:15 --> Total execution time: 0.0331
INFO - 2024-08-21 08:24:20 --> Config Class Initialized
INFO - 2024-08-21 08:24:20 --> Hooks Class Initialized
DEBUG - 2024-08-21 08:24:20 --> UTF-8 Support Enabled
INFO - 2024-08-21 08:24:20 --> Utf8 Class Initialized
INFO - 2024-08-21 08:24:20 --> URI Class Initialized
INFO - 2024-08-21 08:24:20 --> Router Class Initialized
INFO - 2024-08-21 08:24:20 --> Output Class Initialized
INFO - 2024-08-21 08:24:20 --> Security Class Initialized
DEBUG - 2024-08-21 08:24:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-08-21 08:24:20 --> Input Class Initialized
INFO - 2024-08-21 08:24:20 --> Language Class Initialized
INFO - 2024-08-21 08:24:21 --> Language Class Initialized
INFO - 2024-08-21 08:24:21 --> Config Class Initialized
INFO - 2024-08-21 08:24:21 --> Loader Class Initialized
INFO - 2024-08-21 08:24:21 --> Helper loaded: url_helper
INFO - 2024-08-21 08:24:21 --> Helper loaded: file_helper
INFO - 2024-08-21 08:24:21 --> Helper loaded: form_helper
INFO - 2024-08-21 08:24:21 --> Helper loaded: my_helper
INFO - 2024-08-21 08:24:21 --> Database Driver Class Initialized
INFO - 2024-08-21 08:24:21 --> Session: Class initialized using 'files' driver.
INFO - 2024-08-21 08:24:21 --> Controller Class Initialized
DEBUG - 2024-08-21 08:24:21 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/views/cetak_tahfiz.php
INFO - 2024-08-21 08:24:25 --> Final output sent to browser
DEBUG - 2024-08-21 08:24:25 --> Total execution time: 4.2808
INFO - 2024-08-21 08:24:25 --> Config Class Initialized
INFO - 2024-08-21 08:24:25 --> Hooks Class Initialized
DEBUG - 2024-08-21 08:24:25 --> UTF-8 Support Enabled
INFO - 2024-08-21 08:24:25 --> Utf8 Class Initialized
INFO - 2024-08-21 08:24:25 --> URI Class Initialized
INFO - 2024-08-21 08:24:25 --> Router Class Initialized
INFO - 2024-08-21 08:24:25 --> Output Class Initialized
INFO - 2024-08-21 08:24:25 --> Security Class Initialized
DEBUG - 2024-08-21 08:24:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-08-21 08:24:25 --> Input Class Initialized
INFO - 2024-08-21 08:24:25 --> Language Class Initialized
INFO - 2024-08-21 08:24:25 --> Language Class Initialized
INFO - 2024-08-21 08:24:25 --> Config Class Initialized
INFO - 2024-08-21 08:24:25 --> Loader Class Initialized
INFO - 2024-08-21 08:24:25 --> Helper loaded: url_helper
INFO - 2024-08-21 08:24:25 --> Helper loaded: file_helper
INFO - 2024-08-21 08:24:25 --> Helper loaded: form_helper
INFO - 2024-08-21 08:24:25 --> Helper loaded: my_helper
INFO - 2024-08-21 08:24:25 --> Database Driver Class Initialized
INFO - 2024-08-21 08:24:25 --> Session: Class initialized using 'files' driver.
INFO - 2024-08-21 08:24:25 --> Controller Class Initialized
DEBUG - 2024-08-21 08:24:25 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/views/cetak_tahfiz.php
INFO - 2024-08-21 08:24:29 --> Final output sent to browser
DEBUG - 2024-08-21 08:24:29 --> Total execution time: 3.7620
INFO - 2024-08-21 08:24:29 --> Config Class Initialized
INFO - 2024-08-21 08:24:29 --> Hooks Class Initialized
DEBUG - 2024-08-21 08:24:29 --> UTF-8 Support Enabled
INFO - 2024-08-21 08:24:29 --> Utf8 Class Initialized
INFO - 2024-08-21 08:24:29 --> URI Class Initialized
INFO - 2024-08-21 08:24:29 --> Router Class Initialized
INFO - 2024-08-21 08:24:29 --> Output Class Initialized
INFO - 2024-08-21 08:24:29 --> Security Class Initialized
DEBUG - 2024-08-21 08:24:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-08-21 08:24:29 --> Input Class Initialized
INFO - 2024-08-21 08:24:29 --> Language Class Initialized
INFO - 2024-08-21 08:24:29 --> Language Class Initialized
INFO - 2024-08-21 08:24:29 --> Config Class Initialized
INFO - 2024-08-21 08:24:29 --> Loader Class Initialized
INFO - 2024-08-21 08:24:29 --> Helper loaded: url_helper
INFO - 2024-08-21 08:24:29 --> Helper loaded: file_helper
INFO - 2024-08-21 08:24:29 --> Helper loaded: form_helper
INFO - 2024-08-21 08:24:29 --> Helper loaded: my_helper
INFO - 2024-08-21 08:24:29 --> Database Driver Class Initialized
INFO - 2024-08-21 08:24:29 --> Session: Class initialized using 'files' driver.
INFO - 2024-08-21 08:24:29 --> Controller Class Initialized
DEBUG - 2024-08-21 08:24:29 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/views/cetak_tahfiz.php
INFO - 2024-08-21 08:24:29 --> Config Class Initialized
INFO - 2024-08-21 08:24:29 --> Hooks Class Initialized
DEBUG - 2024-08-21 08:24:29 --> UTF-8 Support Enabled
INFO - 2024-08-21 08:24:29 --> Utf8 Class Initialized
INFO - 2024-08-21 08:24:29 --> URI Class Initialized
INFO - 2024-08-21 08:24:29 --> Router Class Initialized
INFO - 2024-08-21 08:24:29 --> Output Class Initialized
INFO - 2024-08-21 08:24:29 --> Security Class Initialized
DEBUG - 2024-08-21 08:24:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-08-21 08:24:29 --> Input Class Initialized
INFO - 2024-08-21 08:24:29 --> Language Class Initialized
INFO - 2024-08-21 08:24:29 --> Language Class Initialized
INFO - 2024-08-21 08:24:29 --> Config Class Initialized
INFO - 2024-08-21 08:24:29 --> Loader Class Initialized
INFO - 2024-08-21 08:24:29 --> Helper loaded: url_helper
INFO - 2024-08-21 08:24:29 --> Helper loaded: file_helper
INFO - 2024-08-21 08:24:29 --> Helper loaded: form_helper
INFO - 2024-08-21 08:24:29 --> Helper loaded: my_helper
INFO - 2024-08-21 08:24:29 --> Database Driver Class Initialized
INFO - 2024-08-21 08:24:33 --> Session: Class initialized using 'files' driver.
INFO - 2024-08-21 08:24:33 --> Controller Class Initialized
DEBUG - 2024-08-21 08:24:33 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/views/cetak_tahfiz.php
INFO - 2024-08-21 08:24:35 --> Config Class Initialized
INFO - 2024-08-21 08:24:35 --> Hooks Class Initialized
DEBUG - 2024-08-21 08:24:35 --> UTF-8 Support Enabled
INFO - 2024-08-21 08:24:35 --> Utf8 Class Initialized
INFO - 2024-08-21 08:24:35 --> URI Class Initialized
INFO - 2024-08-21 08:24:35 --> Router Class Initialized
INFO - 2024-08-21 08:24:35 --> Output Class Initialized
INFO - 2024-08-21 08:24:35 --> Security Class Initialized
DEBUG - 2024-08-21 08:24:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-08-21 08:24:35 --> Input Class Initialized
INFO - 2024-08-21 08:24:35 --> Language Class Initialized
INFO - 2024-08-21 08:24:35 --> Language Class Initialized
INFO - 2024-08-21 08:24:35 --> Config Class Initialized
INFO - 2024-08-21 08:24:35 --> Loader Class Initialized
INFO - 2024-08-21 08:24:35 --> Helper loaded: url_helper
INFO - 2024-08-21 08:24:35 --> Helper loaded: file_helper
INFO - 2024-08-21 08:24:35 --> Helper loaded: form_helper
INFO - 2024-08-21 08:24:35 --> Helper loaded: my_helper
INFO - 2024-08-21 08:24:35 --> Database Driver Class Initialized
INFO - 2024-08-21 08:24:37 --> Session: Class initialized using 'files' driver.
INFO - 2024-08-21 08:24:37 --> Controller Class Initialized
ERROR - 2024-08-21 08:24:37 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1160
ERROR - 2024-08-21 08:24:37 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1692
ERROR - 2024-08-21 08:24:37 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1729
ERROR - 2024-08-21 08:24:37 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1767
ERROR - 2024-08-21 08:24:37 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1806
ERROR - 2024-08-21 08:24:37 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1883
ERROR - 2024-08-21 08:24:37 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1962
ERROR - 2024-08-21 08:24:37 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 2042
ERROR - 2024-08-21 08:24:37 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 2122
ERROR - 2024-08-21 08:24:37 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 2202
ERROR - 2024-08-21 08:24:37 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 2277
ERROR - 2024-08-21 08:24:37 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php 32
ERROR - 2024-08-21 08:24:37 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php 32
DEBUG - 2024-08-21 08:24:37 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php
INFO - 2024-08-21 08:24:40 --> Final output sent to browser
DEBUG - 2024-08-21 08:24:40 --> Total execution time: 4.6206
INFO - 2024-08-21 08:24:40 --> Config Class Initialized
INFO - 2024-08-21 08:24:40 --> Hooks Class Initialized
DEBUG - 2024-08-21 08:24:40 --> UTF-8 Support Enabled
INFO - 2024-08-21 08:24:40 --> Utf8 Class Initialized
INFO - 2024-08-21 08:24:40 --> URI Class Initialized
INFO - 2024-08-21 08:24:40 --> Router Class Initialized
INFO - 2024-08-21 08:24:40 --> Output Class Initialized
INFO - 2024-08-21 08:24:40 --> Security Class Initialized
DEBUG - 2024-08-21 08:24:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-08-21 08:24:40 --> Input Class Initialized
INFO - 2024-08-21 08:24:40 --> Language Class Initialized
INFO - 2024-08-21 08:24:40 --> Language Class Initialized
INFO - 2024-08-21 08:24:40 --> Config Class Initialized
INFO - 2024-08-21 08:24:40 --> Loader Class Initialized
INFO - 2024-08-21 08:24:40 --> Helper loaded: url_helper
INFO - 2024-08-21 08:24:40 --> Helper loaded: file_helper
INFO - 2024-08-21 08:24:40 --> Helper loaded: form_helper
INFO - 2024-08-21 08:24:40 --> Helper loaded: my_helper
INFO - 2024-08-21 08:24:40 --> Database Driver Class Initialized
INFO - 2024-08-21 08:24:40 --> Session: Class initialized using 'files' driver.
INFO - 2024-08-21 08:24:40 --> Controller Class Initialized
ERROR - 2024-08-21 08:24:40 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1160
ERROR - 2024-08-21 08:24:40 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1692
ERROR - 2024-08-21 08:24:40 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1729
ERROR - 2024-08-21 08:24:40 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1767
ERROR - 2024-08-21 08:24:40 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1806
ERROR - 2024-08-21 08:24:40 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1883
ERROR - 2024-08-21 08:24:40 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1962
ERROR - 2024-08-21 08:24:40 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 2042
ERROR - 2024-08-21 08:24:40 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 2122
ERROR - 2024-08-21 08:24:40 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 2202
ERROR - 2024-08-21 08:24:40 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 2277
ERROR - 2024-08-21 08:24:40 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php 32
ERROR - 2024-08-21 08:24:40 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php 32
DEBUG - 2024-08-21 08:24:40 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php
INFO - 2024-08-21 08:24:43 --> Final output sent to browser
DEBUG - 2024-08-21 08:24:43 --> Total execution time: 2.7860
INFO - 2024-08-21 10:30:23 --> Config Class Initialized
INFO - 2024-08-21 10:30:23 --> Hooks Class Initialized
DEBUG - 2024-08-21 10:30:23 --> UTF-8 Support Enabled
INFO - 2024-08-21 10:30:23 --> Utf8 Class Initialized
INFO - 2024-08-21 10:30:23 --> URI Class Initialized
INFO - 2024-08-21 10:30:23 --> Router Class Initialized
INFO - 2024-08-21 10:30:23 --> Output Class Initialized
INFO - 2024-08-21 10:30:23 --> Security Class Initialized
DEBUG - 2024-08-21 10:30:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-08-21 10:30:23 --> Input Class Initialized
INFO - 2024-08-21 10:30:23 --> Language Class Initialized
INFO - 2024-08-21 10:30:23 --> Language Class Initialized
INFO - 2024-08-21 10:30:23 --> Config Class Initialized
INFO - 2024-08-21 10:30:23 --> Loader Class Initialized
INFO - 2024-08-21 10:30:23 --> Helper loaded: url_helper
INFO - 2024-08-21 10:30:23 --> Helper loaded: file_helper
INFO - 2024-08-21 10:30:23 --> Helper loaded: form_helper
INFO - 2024-08-21 10:30:23 --> Helper loaded: my_helper
INFO - 2024-08-21 10:30:23 --> Database Driver Class Initialized
INFO - 2024-08-21 10:30:23 --> Session: Class initialized using 'files' driver.
INFO - 2024-08-21 10:30:23 --> Controller Class Initialized
DEBUG - 2024-08-21 10:30:23 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/set_walikelas/views/list.php
DEBUG - 2024-08-21 10:30:23 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-08-21 10:30:23 --> Final output sent to browser
DEBUG - 2024-08-21 10:30:23 --> Total execution time: 0.0549
INFO - 2024-08-21 10:30:23 --> Config Class Initialized
INFO - 2024-08-21 10:30:23 --> Hooks Class Initialized
DEBUG - 2024-08-21 10:30:23 --> UTF-8 Support Enabled
INFO - 2024-08-21 10:30:23 --> Utf8 Class Initialized
INFO - 2024-08-21 10:30:23 --> URI Class Initialized
INFO - 2024-08-21 10:30:23 --> Router Class Initialized
INFO - 2024-08-21 10:30:23 --> Output Class Initialized
INFO - 2024-08-21 10:30:23 --> Security Class Initialized
DEBUG - 2024-08-21 10:30:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-08-21 10:30:23 --> Input Class Initialized
INFO - 2024-08-21 10:30:23 --> Language Class Initialized
ERROR - 2024-08-21 10:30:23 --> 404 Page Not Found: /index
INFO - 2024-08-21 10:30:23 --> Config Class Initialized
INFO - 2024-08-21 10:30:23 --> Hooks Class Initialized
DEBUG - 2024-08-21 10:30:23 --> UTF-8 Support Enabled
INFO - 2024-08-21 10:30:23 --> Utf8 Class Initialized
INFO - 2024-08-21 10:30:23 --> URI Class Initialized
INFO - 2024-08-21 10:30:23 --> Router Class Initialized
INFO - 2024-08-21 10:30:23 --> Output Class Initialized
INFO - 2024-08-21 10:30:23 --> Security Class Initialized
DEBUG - 2024-08-21 10:30:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-08-21 10:30:23 --> Input Class Initialized
INFO - 2024-08-21 10:30:23 --> Language Class Initialized
INFO - 2024-08-21 10:30:23 --> Language Class Initialized
INFO - 2024-08-21 10:30:23 --> Config Class Initialized
INFO - 2024-08-21 10:30:23 --> Loader Class Initialized
INFO - 2024-08-21 10:30:23 --> Helper loaded: url_helper
INFO - 2024-08-21 10:30:23 --> Helper loaded: file_helper
INFO - 2024-08-21 10:30:23 --> Helper loaded: form_helper
INFO - 2024-08-21 10:30:23 --> Helper loaded: my_helper
INFO - 2024-08-21 10:30:23 --> Database Driver Class Initialized
INFO - 2024-08-21 10:30:23 --> Session: Class initialized using 'files' driver.
INFO - 2024-08-21 10:30:23 --> Controller Class Initialized
INFO - 2024-08-21 15:49:05 --> Config Class Initialized
INFO - 2024-08-21 15:49:05 --> Hooks Class Initialized
DEBUG - 2024-08-21 15:49:05 --> UTF-8 Support Enabled
INFO - 2024-08-21 15:49:05 --> Utf8 Class Initialized
INFO - 2024-08-21 15:49:05 --> URI Class Initialized
INFO - 2024-08-21 15:49:05 --> Router Class Initialized
INFO - 2024-08-21 15:49:05 --> Output Class Initialized
INFO - 2024-08-21 15:49:05 --> Security Class Initialized
DEBUG - 2024-08-21 15:49:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-08-21 15:49:05 --> Input Class Initialized
INFO - 2024-08-21 15:49:05 --> Language Class Initialized
INFO - 2024-08-21 15:49:05 --> Language Class Initialized
INFO - 2024-08-21 15:49:05 --> Config Class Initialized
INFO - 2024-08-21 15:49:05 --> Loader Class Initialized
INFO - 2024-08-21 15:49:05 --> Helper loaded: url_helper
INFO - 2024-08-21 15:49:05 --> Helper loaded: file_helper
INFO - 2024-08-21 15:49:05 --> Helper loaded: form_helper
INFO - 2024-08-21 15:49:05 --> Helper loaded: my_helper
INFO - 2024-08-21 15:49:05 --> Database Driver Class Initialized
INFO - 2024-08-21 15:49:05 --> Session: Class initialized using 'files' driver.
INFO - 2024-08-21 15:49:05 --> Controller Class Initialized
INFO - 2024-08-21 15:49:05 --> Helper loaded: cookie_helper
INFO - 2024-08-21 15:49:05 --> Final output sent to browser
DEBUG - 2024-08-21 15:49:05 --> Total execution time: 0.0703
INFO - 2024-08-21 15:49:06 --> Config Class Initialized
INFO - 2024-08-21 15:49:06 --> Hooks Class Initialized
DEBUG - 2024-08-21 15:49:06 --> UTF-8 Support Enabled
INFO - 2024-08-21 15:49:06 --> Utf8 Class Initialized
INFO - 2024-08-21 15:49:06 --> URI Class Initialized
INFO - 2024-08-21 15:49:06 --> Router Class Initialized
INFO - 2024-08-21 15:49:06 --> Output Class Initialized
INFO - 2024-08-21 15:49:06 --> Security Class Initialized
DEBUG - 2024-08-21 15:49:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-08-21 15:49:06 --> Input Class Initialized
INFO - 2024-08-21 15:49:06 --> Language Class Initialized
INFO - 2024-08-21 15:49:06 --> Language Class Initialized
INFO - 2024-08-21 15:49:06 --> Config Class Initialized
INFO - 2024-08-21 15:49:06 --> Loader Class Initialized
INFO - 2024-08-21 15:49:06 --> Helper loaded: url_helper
INFO - 2024-08-21 15:49:06 --> Helper loaded: file_helper
INFO - 2024-08-21 15:49:06 --> Helper loaded: form_helper
INFO - 2024-08-21 15:49:06 --> Helper loaded: my_helper
INFO - 2024-08-21 15:49:06 --> Database Driver Class Initialized
INFO - 2024-08-21 15:49:06 --> Session: Class initialized using 'files' driver.
INFO - 2024-08-21 15:49:06 --> Controller Class Initialized
INFO - 2024-08-21 15:49:06 --> Helper loaded: cookie_helper
INFO - 2024-08-21 15:49:06 --> Config Class Initialized
INFO - 2024-08-21 15:49:06 --> Hooks Class Initialized
DEBUG - 2024-08-21 15:49:06 --> UTF-8 Support Enabled
INFO - 2024-08-21 15:49:06 --> Utf8 Class Initialized
INFO - 2024-08-21 15:49:06 --> URI Class Initialized
INFO - 2024-08-21 15:49:06 --> Router Class Initialized
INFO - 2024-08-21 15:49:06 --> Output Class Initialized
INFO - 2024-08-21 15:49:06 --> Security Class Initialized
DEBUG - 2024-08-21 15:49:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-08-21 15:49:06 --> Input Class Initialized
INFO - 2024-08-21 15:49:06 --> Language Class Initialized
INFO - 2024-08-21 15:49:06 --> Language Class Initialized
INFO - 2024-08-21 15:49:06 --> Config Class Initialized
INFO - 2024-08-21 15:49:06 --> Loader Class Initialized
INFO - 2024-08-21 15:49:06 --> Helper loaded: url_helper
INFO - 2024-08-21 15:49:06 --> Helper loaded: file_helper
INFO - 2024-08-21 15:49:06 --> Helper loaded: form_helper
INFO - 2024-08-21 15:49:06 --> Helper loaded: my_helper
INFO - 2024-08-21 15:49:06 --> Database Driver Class Initialized
INFO - 2024-08-21 15:49:06 --> Session: Class initialized using 'files' driver.
INFO - 2024-08-21 15:49:06 --> Controller Class Initialized
DEBUG - 2024-08-21 15:49:06 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/lihat_raport/views/list.php
DEBUG - 2024-08-21 15:49:06 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-08-21 15:49:06 --> Final output sent to browser
DEBUG - 2024-08-21 15:49:06 --> Total execution time: 0.0426
INFO - 2024-08-21 15:49:14 --> Config Class Initialized
INFO - 2024-08-21 15:49:14 --> Hooks Class Initialized
DEBUG - 2024-08-21 15:49:14 --> UTF-8 Support Enabled
INFO - 2024-08-21 15:49:14 --> Utf8 Class Initialized
INFO - 2024-08-21 15:49:14 --> URI Class Initialized
INFO - 2024-08-21 15:49:14 --> Router Class Initialized
INFO - 2024-08-21 15:49:14 --> Output Class Initialized
INFO - 2024-08-21 15:49:14 --> Security Class Initialized
DEBUG - 2024-08-21 15:49:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-08-21 15:49:14 --> Input Class Initialized
INFO - 2024-08-21 15:49:14 --> Language Class Initialized
INFO - 2024-08-21 15:49:14 --> Language Class Initialized
INFO - 2024-08-21 15:49:14 --> Config Class Initialized
INFO - 2024-08-21 15:49:14 --> Loader Class Initialized
INFO - 2024-08-21 15:49:14 --> Helper loaded: url_helper
INFO - 2024-08-21 15:49:14 --> Helper loaded: file_helper
INFO - 2024-08-21 15:49:14 --> Helper loaded: form_helper
INFO - 2024-08-21 15:49:14 --> Helper loaded: my_helper
INFO - 2024-08-21 15:49:14 --> Database Driver Class Initialized
INFO - 2024-08-21 15:49:14 --> Session: Class initialized using 'files' driver.
INFO - 2024-08-21 15:49:14 --> Controller Class Initialized
ERROR - 2024-08-21 15:49:14 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 107
ERROR - 2024-08-21 15:49:14 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 554
ERROR - 2024-08-21 15:49:14 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 554
ERROR - 2024-08-21 15:49:14 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 616
ERROR - 2024-08-21 15:49:14 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 679
ERROR - 2024-08-21 15:49:14 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 679
ERROR - 2024-08-21 15:49:14 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 686
ERROR - 2024-08-21 15:49:14 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 757
ERROR - 2024-08-21 15:49:14 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 760
ERROR - 2024-08-21 15:49:14 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 760
ERROR - 2024-08-21 15:49:14 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 832
ERROR - 2024-08-21 15:49:14 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 906
ERROR - 2024-08-21 15:49:14 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 906
ERROR - 2024-08-21 15:49:14 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 913
ERROR - 2024-08-21 15:49:14 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 987
ERROR - 2024-08-21 15:49:14 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 987
ERROR - 2024-08-21 15:49:14 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/views/cetak_rapot.php 83
ERROR - 2024-08-21 15:49:14 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/views/cetak_rapot.php 95
ERROR - 2024-08-21 15:49:14 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/views/cetak_rapot.php 95
ERROR - 2024-08-21 15:49:14 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/views/cetak_rapot.php 436
ERROR - 2024-08-21 15:49:14 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/views/cetak_rapot.php 437
DEBUG - 2024-08-21 15:49:14 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/views/cetak_rapot.php
INFO - 2024-08-21 15:49:17 --> Final output sent to browser
DEBUG - 2024-08-21 15:49:17 --> Total execution time: 3.2850
INFO - 2024-08-21 15:49:38 --> Config Class Initialized
INFO - 2024-08-21 15:49:38 --> Hooks Class Initialized
DEBUG - 2024-08-21 15:49:38 --> UTF-8 Support Enabled
INFO - 2024-08-21 15:49:38 --> Utf8 Class Initialized
INFO - 2024-08-21 15:49:38 --> URI Class Initialized
INFO - 2024-08-21 15:49:38 --> Router Class Initialized
INFO - 2024-08-21 15:49:38 --> Output Class Initialized
INFO - 2024-08-21 15:49:38 --> Security Class Initialized
DEBUG - 2024-08-21 15:49:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-08-21 15:49:38 --> Input Class Initialized
INFO - 2024-08-21 15:49:38 --> Language Class Initialized
INFO - 2024-08-21 15:49:38 --> Language Class Initialized
INFO - 2024-08-21 15:49:38 --> Config Class Initialized
INFO - 2024-08-21 15:49:38 --> Loader Class Initialized
INFO - 2024-08-21 15:49:38 --> Helper loaded: url_helper
INFO - 2024-08-21 15:49:38 --> Helper loaded: file_helper
INFO - 2024-08-21 15:49:38 --> Helper loaded: form_helper
INFO - 2024-08-21 15:49:38 --> Helper loaded: my_helper
INFO - 2024-08-21 15:49:38 --> Database Driver Class Initialized
INFO - 2024-08-21 15:49:38 --> Session: Class initialized using 'files' driver.
INFO - 2024-08-21 15:49:38 --> Controller Class Initialized
INFO - 2024-08-21 15:49:38 --> Helper loaded: cookie_helper
INFO - 2024-08-21 15:49:38 --> Final output sent to browser
DEBUG - 2024-08-21 15:49:38 --> Total execution time: 0.0318
INFO - 2024-08-21 15:49:39 --> Config Class Initialized
INFO - 2024-08-21 15:49:39 --> Hooks Class Initialized
DEBUG - 2024-08-21 15:49:39 --> UTF-8 Support Enabled
INFO - 2024-08-21 15:49:39 --> Utf8 Class Initialized
INFO - 2024-08-21 15:49:39 --> URI Class Initialized
INFO - 2024-08-21 15:49:39 --> Router Class Initialized
INFO - 2024-08-21 15:49:39 --> Output Class Initialized
INFO - 2024-08-21 15:49:39 --> Security Class Initialized
DEBUG - 2024-08-21 15:49:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-08-21 15:49:39 --> Input Class Initialized
INFO - 2024-08-21 15:49:39 --> Language Class Initialized
INFO - 2024-08-21 15:49:39 --> Language Class Initialized
INFO - 2024-08-21 15:49:39 --> Config Class Initialized
INFO - 2024-08-21 15:49:39 --> Loader Class Initialized
INFO - 2024-08-21 15:49:39 --> Helper loaded: url_helper
INFO - 2024-08-21 15:49:39 --> Helper loaded: file_helper
INFO - 2024-08-21 15:49:39 --> Helper loaded: form_helper
INFO - 2024-08-21 15:49:39 --> Helper loaded: my_helper
INFO - 2024-08-21 15:49:39 --> Database Driver Class Initialized
INFO - 2024-08-21 15:49:39 --> Session: Class initialized using 'files' driver.
INFO - 2024-08-21 15:49:39 --> Controller Class Initialized
INFO - 2024-08-21 15:49:39 --> Helper loaded: cookie_helper
INFO - 2024-08-21 15:49:39 --> Config Class Initialized
INFO - 2024-08-21 15:49:39 --> Hooks Class Initialized
DEBUG - 2024-08-21 15:49:39 --> UTF-8 Support Enabled
INFO - 2024-08-21 15:49:39 --> Utf8 Class Initialized
INFO - 2024-08-21 15:49:39 --> URI Class Initialized
INFO - 2024-08-21 15:49:39 --> Router Class Initialized
INFO - 2024-08-21 15:49:39 --> Output Class Initialized
INFO - 2024-08-21 15:49:39 --> Security Class Initialized
DEBUG - 2024-08-21 15:49:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-08-21 15:49:39 --> Input Class Initialized
INFO - 2024-08-21 15:49:39 --> Language Class Initialized
INFO - 2024-08-21 15:49:39 --> Language Class Initialized
INFO - 2024-08-21 15:49:39 --> Config Class Initialized
INFO - 2024-08-21 15:49:39 --> Loader Class Initialized
INFO - 2024-08-21 15:49:39 --> Helper loaded: url_helper
INFO - 2024-08-21 15:49:39 --> Helper loaded: file_helper
INFO - 2024-08-21 15:49:39 --> Helper loaded: form_helper
INFO - 2024-08-21 15:49:39 --> Helper loaded: my_helper
INFO - 2024-08-21 15:49:39 --> Database Driver Class Initialized
INFO - 2024-08-21 15:49:39 --> Session: Class initialized using 'files' driver.
INFO - 2024-08-21 15:49:39 --> Controller Class Initialized
DEBUG - 2024-08-21 15:49:39 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/lihat_raport/views/list.php
DEBUG - 2024-08-21 15:49:39 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-08-21 15:49:39 --> Final output sent to browser
DEBUG - 2024-08-21 15:49:39 --> Total execution time: 0.0334
INFO - 2024-08-21 15:49:41 --> Config Class Initialized
INFO - 2024-08-21 15:49:41 --> Hooks Class Initialized
DEBUG - 2024-08-21 15:49:41 --> UTF-8 Support Enabled
INFO - 2024-08-21 15:49:41 --> Utf8 Class Initialized
INFO - 2024-08-21 15:49:41 --> URI Class Initialized
INFO - 2024-08-21 15:49:41 --> Router Class Initialized
INFO - 2024-08-21 15:49:41 --> Output Class Initialized
INFO - 2024-08-21 15:49:41 --> Security Class Initialized
DEBUG - 2024-08-21 15:49:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-08-21 15:49:41 --> Input Class Initialized
INFO - 2024-08-21 15:49:41 --> Language Class Initialized
INFO - 2024-08-21 15:49:41 --> Language Class Initialized
INFO - 2024-08-21 15:49:41 --> Config Class Initialized
INFO - 2024-08-21 15:49:41 --> Loader Class Initialized
INFO - 2024-08-21 15:49:41 --> Helper loaded: url_helper
INFO - 2024-08-21 15:49:41 --> Helper loaded: file_helper
INFO - 2024-08-21 15:49:41 --> Helper loaded: form_helper
INFO - 2024-08-21 15:49:41 --> Helper loaded: my_helper
INFO - 2024-08-21 15:49:41 --> Database Driver Class Initialized
INFO - 2024-08-21 15:49:41 --> Session: Class initialized using 'files' driver.
INFO - 2024-08-21 15:49:41 --> Controller Class Initialized
ERROR - 2024-08-21 15:49:41 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 107
ERROR - 2024-08-21 15:49:41 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 554
ERROR - 2024-08-21 15:49:41 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 554
ERROR - 2024-08-21 15:49:41 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 616
ERROR - 2024-08-21 15:49:41 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 679
ERROR - 2024-08-21 15:49:41 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 679
ERROR - 2024-08-21 15:49:41 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 686
ERROR - 2024-08-21 15:49:41 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 757
ERROR - 2024-08-21 15:49:41 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 760
ERROR - 2024-08-21 15:49:41 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 760
ERROR - 2024-08-21 15:49:41 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 832
ERROR - 2024-08-21 15:49:41 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 906
ERROR - 2024-08-21 15:49:41 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 906
ERROR - 2024-08-21 15:49:41 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 913
ERROR - 2024-08-21 15:49:41 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 987
ERROR - 2024-08-21 15:49:41 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 987
ERROR - 2024-08-21 15:49:41 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/views/cetak_rapot.php 83
ERROR - 2024-08-21 15:49:41 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/views/cetak_rapot.php 95
ERROR - 2024-08-21 15:49:41 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/views/cetak_rapot.php 95
DEBUG - 2024-08-21 15:49:41 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/views/cetak_rapot.php
INFO - 2024-08-21 15:49:44 --> Final output sent to browser
DEBUG - 2024-08-21 15:49:44 --> Total execution time: 2.8233
