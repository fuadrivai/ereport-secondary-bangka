<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2024-01-04 11:52:42 --> Config Class Initialized
INFO - 2024-01-04 11:52:42 --> Hooks Class Initialized
DEBUG - 2024-01-04 11:52:42 --> UTF-8 Support Enabled
INFO - 2024-01-04 11:52:42 --> Utf8 Class Initialized
INFO - 2024-01-04 11:52:42 --> URI Class Initialized
INFO - 2024-01-04 11:52:42 --> Router Class Initialized
INFO - 2024-01-04 11:52:42 --> Output Class Initialized
INFO - 2024-01-04 11:52:42 --> Security Class Initialized
DEBUG - 2024-01-04 11:52:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-01-04 11:52:42 --> Input Class Initialized
INFO - 2024-01-04 11:52:42 --> Language Class Initialized
INFO - 2024-01-04 11:52:42 --> Language Class Initialized
INFO - 2024-01-04 11:52:42 --> Config Class Initialized
INFO - 2024-01-04 11:52:42 --> Loader Class Initialized
INFO - 2024-01-04 11:52:42 --> Helper loaded: url_helper
INFO - 2024-01-04 11:52:42 --> Helper loaded: file_helper
INFO - 2024-01-04 11:52:42 --> Helper loaded: form_helper
INFO - 2024-01-04 11:52:42 --> Helper loaded: my_helper
INFO - 2024-01-04 11:52:42 --> Database Driver Class Initialized
INFO - 2024-01-04 11:52:42 --> Session: Class initialized using 'files' driver.
INFO - 2024-01-04 11:52:42 --> Controller Class Initialized
DEBUG - 2024-01-04 11:52:42 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/login/views/login.php
DEBUG - 2024-01-04 11:52:42 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-01-04 11:52:42 --> Final output sent to browser
DEBUG - 2024-01-04 11:52:42 --> Total execution time: 0.1012
INFO - 2024-01-04 12:43:25 --> Config Class Initialized
INFO - 2024-01-04 12:43:25 --> Hooks Class Initialized
DEBUG - 2024-01-04 12:43:25 --> UTF-8 Support Enabled
INFO - 2024-01-04 12:43:25 --> Utf8 Class Initialized
INFO - 2024-01-04 12:43:25 --> URI Class Initialized
INFO - 2024-01-04 12:43:25 --> Router Class Initialized
INFO - 2024-01-04 12:43:25 --> Output Class Initialized
INFO - 2024-01-04 12:43:25 --> Security Class Initialized
DEBUG - 2024-01-04 12:43:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-01-04 12:43:25 --> Input Class Initialized
INFO - 2024-01-04 12:43:25 --> Language Class Initialized
INFO - 2024-01-04 12:43:25 --> Language Class Initialized
INFO - 2024-01-04 12:43:25 --> Config Class Initialized
INFO - 2024-01-04 12:43:25 --> Loader Class Initialized
INFO - 2024-01-04 12:43:25 --> Helper loaded: url_helper
INFO - 2024-01-04 12:43:25 --> Helper loaded: file_helper
INFO - 2024-01-04 12:43:25 --> Helper loaded: form_helper
INFO - 2024-01-04 12:43:25 --> Helper loaded: my_helper
INFO - 2024-01-04 12:43:25 --> Database Driver Class Initialized
INFO - 2024-01-04 12:43:25 --> Session: Class initialized using 'files' driver.
INFO - 2024-01-04 12:43:25 --> Controller Class Initialized
INFO - 2024-01-04 12:43:25 --> Helper loaded: cookie_helper
INFO - 2024-01-04 12:43:25 --> Final output sent to browser
DEBUG - 2024-01-04 12:43:25 --> Total execution time: 0.0607
INFO - 2024-01-04 12:43:25 --> Config Class Initialized
INFO - 2024-01-04 12:43:25 --> Hooks Class Initialized
DEBUG - 2024-01-04 12:43:25 --> UTF-8 Support Enabled
INFO - 2024-01-04 12:43:25 --> Utf8 Class Initialized
INFO - 2024-01-04 12:43:25 --> URI Class Initialized
INFO - 2024-01-04 12:43:25 --> Router Class Initialized
INFO - 2024-01-04 12:43:25 --> Output Class Initialized
INFO - 2024-01-04 12:43:25 --> Security Class Initialized
DEBUG - 2024-01-04 12:43:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-01-04 12:43:25 --> Input Class Initialized
INFO - 2024-01-04 12:43:25 --> Language Class Initialized
INFO - 2024-01-04 12:43:25 --> Language Class Initialized
INFO - 2024-01-04 12:43:25 --> Config Class Initialized
INFO - 2024-01-04 12:43:25 --> Loader Class Initialized
INFO - 2024-01-04 12:43:25 --> Helper loaded: url_helper
INFO - 2024-01-04 12:43:25 --> Helper loaded: file_helper
INFO - 2024-01-04 12:43:25 --> Helper loaded: form_helper
INFO - 2024-01-04 12:43:25 --> Helper loaded: my_helper
INFO - 2024-01-04 12:43:25 --> Database Driver Class Initialized
INFO - 2024-01-04 12:43:25 --> Session: Class initialized using 'files' driver.
INFO - 2024-01-04 12:43:25 --> Controller Class Initialized
INFO - 2024-01-04 12:43:25 --> Helper loaded: cookie_helper
INFO - 2024-01-04 12:43:25 --> Config Class Initialized
INFO - 2024-01-04 12:43:25 --> Hooks Class Initialized
DEBUG - 2024-01-04 12:43:25 --> UTF-8 Support Enabled
INFO - 2024-01-04 12:43:25 --> Utf8 Class Initialized
INFO - 2024-01-04 12:43:25 --> URI Class Initialized
INFO - 2024-01-04 12:43:25 --> Router Class Initialized
INFO - 2024-01-04 12:43:25 --> Output Class Initialized
INFO - 2024-01-04 12:43:25 --> Security Class Initialized
DEBUG - 2024-01-04 12:43:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-01-04 12:43:25 --> Input Class Initialized
INFO - 2024-01-04 12:43:25 --> Language Class Initialized
INFO - 2024-01-04 12:43:25 --> Language Class Initialized
INFO - 2024-01-04 12:43:25 --> Config Class Initialized
INFO - 2024-01-04 12:43:25 --> Loader Class Initialized
INFO - 2024-01-04 12:43:25 --> Helper loaded: url_helper
INFO - 2024-01-04 12:43:25 --> Helper loaded: file_helper
INFO - 2024-01-04 12:43:25 --> Helper loaded: form_helper
INFO - 2024-01-04 12:43:25 --> Helper loaded: my_helper
INFO - 2024-01-04 12:43:25 --> Database Driver Class Initialized
INFO - 2024-01-04 12:43:25 --> Session: Class initialized using 'files' driver.
INFO - 2024-01-04 12:43:25 --> Controller Class Initialized
DEBUG - 2024-01-04 12:43:25 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/lihat_raport/views/list.php
DEBUG - 2024-01-04 12:43:25 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-01-04 12:43:25 --> Final output sent to browser
DEBUG - 2024-01-04 12:43:25 --> Total execution time: 0.0414
INFO - 2024-01-04 12:43:27 --> Config Class Initialized
INFO - 2024-01-04 12:43:27 --> Hooks Class Initialized
DEBUG - 2024-01-04 12:43:27 --> UTF-8 Support Enabled
INFO - 2024-01-04 12:43:27 --> Utf8 Class Initialized
INFO - 2024-01-04 12:43:27 --> URI Class Initialized
INFO - 2024-01-04 12:43:27 --> Router Class Initialized
INFO - 2024-01-04 12:43:27 --> Output Class Initialized
INFO - 2024-01-04 12:43:27 --> Security Class Initialized
DEBUG - 2024-01-04 12:43:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-01-04 12:43:27 --> Input Class Initialized
INFO - 2024-01-04 12:43:27 --> Language Class Initialized
INFO - 2024-01-04 12:43:27 --> Language Class Initialized
INFO - 2024-01-04 12:43:27 --> Config Class Initialized
INFO - 2024-01-04 12:43:27 --> Loader Class Initialized
INFO - 2024-01-04 12:43:27 --> Helper loaded: url_helper
INFO - 2024-01-04 12:43:27 --> Helper loaded: file_helper
INFO - 2024-01-04 12:43:27 --> Helper loaded: form_helper
INFO - 2024-01-04 12:43:27 --> Helper loaded: my_helper
INFO - 2024-01-04 12:43:27 --> Database Driver Class Initialized
INFO - 2024-01-04 12:43:27 --> Session: Class initialized using 'files' driver.
INFO - 2024-01-04 12:43:27 --> Controller Class Initialized
INFO - 2024-01-04 12:43:27 --> Helper loaded: cookie_helper
INFO - 2024-01-04 12:43:27 --> Final output sent to browser
DEBUG - 2024-01-04 12:43:27 --> Total execution time: 0.0400
INFO - 2024-01-04 12:43:28 --> Config Class Initialized
INFO - 2024-01-04 12:43:28 --> Hooks Class Initialized
DEBUG - 2024-01-04 12:43:28 --> UTF-8 Support Enabled
INFO - 2024-01-04 12:43:28 --> Utf8 Class Initialized
INFO - 2024-01-04 12:43:28 --> URI Class Initialized
INFO - 2024-01-04 12:43:28 --> Router Class Initialized
INFO - 2024-01-04 12:43:28 --> Output Class Initialized
INFO - 2024-01-04 12:43:28 --> Security Class Initialized
DEBUG - 2024-01-04 12:43:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-01-04 12:43:28 --> Input Class Initialized
INFO - 2024-01-04 12:43:28 --> Language Class Initialized
INFO - 2024-01-04 12:43:28 --> Language Class Initialized
INFO - 2024-01-04 12:43:28 --> Config Class Initialized
INFO - 2024-01-04 12:43:28 --> Loader Class Initialized
INFO - 2024-01-04 12:43:28 --> Helper loaded: url_helper
INFO - 2024-01-04 12:43:28 --> Helper loaded: file_helper
INFO - 2024-01-04 12:43:28 --> Helper loaded: form_helper
INFO - 2024-01-04 12:43:28 --> Helper loaded: my_helper
INFO - 2024-01-04 12:43:28 --> Database Driver Class Initialized
INFO - 2024-01-04 12:43:28 --> Session: Class initialized using 'files' driver.
INFO - 2024-01-04 12:43:28 --> Controller Class Initialized
INFO - 2024-01-04 12:43:28 --> Helper loaded: cookie_helper
INFO - 2024-01-04 12:43:28 --> Config Class Initialized
INFO - 2024-01-04 12:43:28 --> Hooks Class Initialized
DEBUG - 2024-01-04 12:43:28 --> UTF-8 Support Enabled
INFO - 2024-01-04 12:43:28 --> Utf8 Class Initialized
INFO - 2024-01-04 12:43:28 --> URI Class Initialized
INFO - 2024-01-04 12:43:28 --> Router Class Initialized
INFO - 2024-01-04 12:43:28 --> Output Class Initialized
INFO - 2024-01-04 12:43:28 --> Security Class Initialized
DEBUG - 2024-01-04 12:43:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-01-04 12:43:28 --> Input Class Initialized
INFO - 2024-01-04 12:43:28 --> Language Class Initialized
INFO - 2024-01-04 12:43:28 --> Language Class Initialized
INFO - 2024-01-04 12:43:28 --> Config Class Initialized
INFO - 2024-01-04 12:43:28 --> Loader Class Initialized
INFO - 2024-01-04 12:43:28 --> Helper loaded: url_helper
INFO - 2024-01-04 12:43:28 --> Helper loaded: file_helper
INFO - 2024-01-04 12:43:28 --> Helper loaded: form_helper
INFO - 2024-01-04 12:43:28 --> Helper loaded: my_helper
INFO - 2024-01-04 12:43:28 --> Database Driver Class Initialized
INFO - 2024-01-04 12:43:28 --> Session: Class initialized using 'files' driver.
INFO - 2024-01-04 12:43:28 --> Controller Class Initialized
INFO - 2024-01-04 12:43:28 --> Helper loaded: cookie_helper
INFO - 2024-01-04 12:43:29 --> Config Class Initialized
INFO - 2024-01-04 12:43:29 --> Hooks Class Initialized
DEBUG - 2024-01-04 12:43:29 --> UTF-8 Support Enabled
INFO - 2024-01-04 12:43:29 --> Utf8 Class Initialized
INFO - 2024-01-04 12:43:29 --> URI Class Initialized
INFO - 2024-01-04 12:43:29 --> Router Class Initialized
INFO - 2024-01-04 12:43:29 --> Output Class Initialized
INFO - 2024-01-04 12:43:29 --> Security Class Initialized
DEBUG - 2024-01-04 12:43:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-01-04 12:43:29 --> Input Class Initialized
INFO - 2024-01-04 12:43:29 --> Language Class Initialized
INFO - 2024-01-04 12:43:29 --> Language Class Initialized
INFO - 2024-01-04 12:43:29 --> Config Class Initialized
INFO - 2024-01-04 12:43:29 --> Loader Class Initialized
INFO - 2024-01-04 12:43:29 --> Helper loaded: url_helper
INFO - 2024-01-04 12:43:29 --> Helper loaded: file_helper
INFO - 2024-01-04 12:43:29 --> Helper loaded: form_helper
INFO - 2024-01-04 12:43:29 --> Helper loaded: my_helper
INFO - 2024-01-04 12:43:29 --> Database Driver Class Initialized
INFO - 2024-01-04 12:43:29 --> Session: Class initialized using 'files' driver.
INFO - 2024-01-04 12:43:29 --> Controller Class Initialized
DEBUG - 2024-01-04 12:43:29 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/lihat_raport/views/list.php
DEBUG - 2024-01-04 12:43:29 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-01-04 12:43:29 --> Final output sent to browser
DEBUG - 2024-01-04 12:43:29 --> Total execution time: 0.0334
INFO - 2024-01-04 12:43:36 --> Config Class Initialized
INFO - 2024-01-04 12:43:36 --> Hooks Class Initialized
DEBUG - 2024-01-04 12:43:36 --> UTF-8 Support Enabled
INFO - 2024-01-04 12:43:36 --> Utf8 Class Initialized
INFO - 2024-01-04 12:43:36 --> URI Class Initialized
INFO - 2024-01-04 12:43:36 --> Router Class Initialized
INFO - 2024-01-04 12:43:36 --> Output Class Initialized
INFO - 2024-01-04 12:43:36 --> Security Class Initialized
DEBUG - 2024-01-04 12:43:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-01-04 12:43:36 --> Input Class Initialized
INFO - 2024-01-04 12:43:36 --> Language Class Initialized
INFO - 2024-01-04 12:43:36 --> Language Class Initialized
INFO - 2024-01-04 12:43:36 --> Config Class Initialized
INFO - 2024-01-04 12:43:36 --> Loader Class Initialized
INFO - 2024-01-04 12:43:36 --> Helper loaded: url_helper
INFO - 2024-01-04 12:43:36 --> Helper loaded: file_helper
INFO - 2024-01-04 12:43:36 --> Helper loaded: form_helper
INFO - 2024-01-04 12:43:36 --> Helper loaded: my_helper
INFO - 2024-01-04 12:43:36 --> Database Driver Class Initialized
INFO - 2024-01-04 12:43:36 --> Session: Class initialized using 'files' driver.
INFO - 2024-01-04 12:43:36 --> Controller Class Initialized
DEBUG - 2024-01-04 12:43:36 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php
INFO - 2024-01-04 12:43:40 --> Final output sent to browser
DEBUG - 2024-01-04 12:43:40 --> Total execution time: 4.5434
INFO - 2024-01-04 14:02:02 --> Config Class Initialized
INFO - 2024-01-04 14:02:02 --> Hooks Class Initialized
DEBUG - 2024-01-04 14:02:02 --> UTF-8 Support Enabled
INFO - 2024-01-04 14:02:02 --> Utf8 Class Initialized
INFO - 2024-01-04 14:02:02 --> URI Class Initialized
INFO - 2024-01-04 14:02:02 --> Router Class Initialized
INFO - 2024-01-04 14:02:02 --> Output Class Initialized
INFO - 2024-01-04 14:02:02 --> Security Class Initialized
DEBUG - 2024-01-04 14:02:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-01-04 14:02:02 --> Input Class Initialized
INFO - 2024-01-04 14:02:02 --> Language Class Initialized
INFO - 2024-01-04 14:02:02 --> Language Class Initialized
INFO - 2024-01-04 14:02:02 --> Config Class Initialized
INFO - 2024-01-04 14:02:02 --> Loader Class Initialized
INFO - 2024-01-04 14:02:02 --> Helper loaded: url_helper
INFO - 2024-01-04 14:02:02 --> Helper loaded: file_helper
INFO - 2024-01-04 14:02:02 --> Helper loaded: form_helper
INFO - 2024-01-04 14:02:02 --> Helper loaded: my_helper
INFO - 2024-01-04 14:02:02 --> Database Driver Class Initialized
INFO - 2024-01-04 14:02:02 --> Session: Class initialized using 'files' driver.
INFO - 2024-01-04 14:02:02 --> Controller Class Initialized
INFO - 2024-01-04 14:02:02 --> Helper loaded: cookie_helper
INFO - 2024-01-04 14:02:02 --> Final output sent to browser
DEBUG - 2024-01-04 14:02:02 --> Total execution time: 0.1925
INFO - 2024-01-04 14:02:03 --> Config Class Initialized
INFO - 2024-01-04 14:02:03 --> Hooks Class Initialized
DEBUG - 2024-01-04 14:02:03 --> UTF-8 Support Enabled
INFO - 2024-01-04 14:02:03 --> Utf8 Class Initialized
INFO - 2024-01-04 14:02:03 --> URI Class Initialized
INFO - 2024-01-04 14:02:03 --> Router Class Initialized
INFO - 2024-01-04 14:02:03 --> Output Class Initialized
INFO - 2024-01-04 14:02:03 --> Security Class Initialized
DEBUG - 2024-01-04 14:02:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-01-04 14:02:03 --> Input Class Initialized
INFO - 2024-01-04 14:02:03 --> Language Class Initialized
INFO - 2024-01-04 14:02:03 --> Language Class Initialized
INFO - 2024-01-04 14:02:03 --> Config Class Initialized
INFO - 2024-01-04 14:02:03 --> Loader Class Initialized
INFO - 2024-01-04 14:02:03 --> Helper loaded: url_helper
INFO - 2024-01-04 14:02:03 --> Helper loaded: file_helper
INFO - 2024-01-04 14:02:03 --> Helper loaded: form_helper
INFO - 2024-01-04 14:02:03 --> Helper loaded: my_helper
INFO - 2024-01-04 14:02:03 --> Database Driver Class Initialized
INFO - 2024-01-04 14:02:03 --> Session: Class initialized using 'files' driver.
INFO - 2024-01-04 14:02:03 --> Controller Class Initialized
INFO - 2024-01-04 14:02:03 --> Helper loaded: cookie_helper
INFO - 2024-01-04 14:02:03 --> Final output sent to browser
DEBUG - 2024-01-04 14:02:03 --> Total execution time: 0.0487
INFO - 2024-01-04 14:02:03 --> Config Class Initialized
INFO - 2024-01-04 14:02:03 --> Hooks Class Initialized
DEBUG - 2024-01-04 14:02:03 --> UTF-8 Support Enabled
INFO - 2024-01-04 14:02:03 --> Utf8 Class Initialized
INFO - 2024-01-04 14:02:03 --> URI Class Initialized
INFO - 2024-01-04 14:02:03 --> Router Class Initialized
INFO - 2024-01-04 14:02:03 --> Output Class Initialized
INFO - 2024-01-04 14:02:03 --> Security Class Initialized
DEBUG - 2024-01-04 14:02:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-01-04 14:02:03 --> Input Class Initialized
INFO - 2024-01-04 14:02:03 --> Language Class Initialized
INFO - 2024-01-04 14:02:03 --> Language Class Initialized
INFO - 2024-01-04 14:02:03 --> Config Class Initialized
INFO - 2024-01-04 14:02:03 --> Loader Class Initialized
INFO - 2024-01-04 14:02:03 --> Helper loaded: url_helper
INFO - 2024-01-04 14:02:03 --> Helper loaded: file_helper
INFO - 2024-01-04 14:02:03 --> Helper loaded: form_helper
INFO - 2024-01-04 14:02:03 --> Helper loaded: my_helper
INFO - 2024-01-04 14:02:03 --> Database Driver Class Initialized
INFO - 2024-01-04 14:02:03 --> Session: Class initialized using 'files' driver.
INFO - 2024-01-04 14:02:03 --> Controller Class Initialized
INFO - 2024-01-04 14:02:03 --> Helper loaded: cookie_helper
INFO - 2024-01-04 14:02:04 --> Config Class Initialized
INFO - 2024-01-04 14:02:04 --> Hooks Class Initialized
DEBUG - 2024-01-04 14:02:04 --> UTF-8 Support Enabled
INFO - 2024-01-04 14:02:04 --> Utf8 Class Initialized
INFO - 2024-01-04 14:02:04 --> URI Class Initialized
INFO - 2024-01-04 14:02:04 --> Config Class Initialized
INFO - 2024-01-04 14:02:04 --> Hooks Class Initialized
DEBUG - 2024-01-04 14:02:04 --> UTF-8 Support Enabled
INFO - 2024-01-04 14:02:04 --> Utf8 Class Initialized
INFO - 2024-01-04 14:02:04 --> URI Class Initialized
INFO - 2024-01-04 14:02:04 --> Router Class Initialized
INFO - 2024-01-04 14:02:04 --> Output Class Initialized
INFO - 2024-01-04 14:02:04 --> Security Class Initialized
DEBUG - 2024-01-04 14:02:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-01-04 14:02:04 --> Input Class Initialized
INFO - 2024-01-04 14:02:04 --> Language Class Initialized
INFO - 2024-01-04 14:02:04 --> Router Class Initialized
INFO - 2024-01-04 14:02:04 --> Output Class Initialized
INFO - 2024-01-04 14:02:04 --> Security Class Initialized
DEBUG - 2024-01-04 14:02:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-01-04 14:02:04 --> Input Class Initialized
INFO - 2024-01-04 14:02:04 --> Language Class Initialized
INFO - 2024-01-04 14:02:04 --> Language Class Initialized
INFO - 2024-01-04 14:02:04 --> Config Class Initialized
INFO - 2024-01-04 14:02:04 --> Loader Class Initialized
INFO - 2024-01-04 14:02:04 --> Helper loaded: url_helper
INFO - 2024-01-04 14:02:04 --> Helper loaded: file_helper
INFO - 2024-01-04 14:02:04 --> Helper loaded: form_helper
INFO - 2024-01-04 14:02:04 --> Language Class Initialized
INFO - 2024-01-04 14:02:04 --> Config Class Initialized
INFO - 2024-01-04 14:02:04 --> Loader Class Initialized
INFO - 2024-01-04 14:02:04 --> Helper loaded: url_helper
INFO - 2024-01-04 14:02:04 --> Helper loaded: file_helper
INFO - 2024-01-04 14:02:04 --> Helper loaded: form_helper
INFO - 2024-01-04 14:02:04 --> Helper loaded: my_helper
INFO - 2024-01-04 14:02:04 --> Helper loaded: my_helper
INFO - 2024-01-04 14:02:04 --> Database Driver Class Initialized
INFO - 2024-01-04 14:02:04 --> Database Driver Class Initialized
INFO - 2024-01-04 14:02:04 --> Session: Class initialized using 'files' driver.
INFO - 2024-01-04 14:02:04 --> Controller Class Initialized
INFO - 2024-01-04 14:02:04 --> Session: Class initialized using 'files' driver.
INFO - 2024-01-04 14:02:04 --> Controller Class Initialized
INFO - 2024-01-04 14:02:04 --> Helper loaded: cookie_helper
DEBUG - 2024-01-04 14:02:04 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/lihat_raport/views/list.php
DEBUG - 2024-01-04 14:02:04 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-01-04 14:02:04 --> Final output sent to browser
DEBUG - 2024-01-04 14:02:04 --> Total execution time: 0.0863
INFO - 2024-01-04 14:02:04 --> Config Class Initialized
INFO - 2024-01-04 14:02:04 --> Hooks Class Initialized
DEBUG - 2024-01-04 14:02:04 --> UTF-8 Support Enabled
INFO - 2024-01-04 14:02:04 --> Utf8 Class Initialized
INFO - 2024-01-04 14:02:04 --> URI Class Initialized
INFO - 2024-01-04 14:02:04 --> Router Class Initialized
INFO - 2024-01-04 14:02:04 --> Output Class Initialized
INFO - 2024-01-04 14:02:04 --> Security Class Initialized
DEBUG - 2024-01-04 14:02:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-01-04 14:02:04 --> Input Class Initialized
INFO - 2024-01-04 14:02:04 --> Language Class Initialized
INFO - 2024-01-04 14:02:04 --> Language Class Initialized
INFO - 2024-01-04 14:02:04 --> Config Class Initialized
INFO - 2024-01-04 14:02:04 --> Loader Class Initialized
INFO - 2024-01-04 14:02:04 --> Helper loaded: url_helper
INFO - 2024-01-04 14:02:04 --> Helper loaded: file_helper
INFO - 2024-01-04 14:02:04 --> Helper loaded: form_helper
INFO - 2024-01-04 14:02:04 --> Helper loaded: my_helper
INFO - 2024-01-04 14:02:04 --> Database Driver Class Initialized
INFO - 2024-01-04 14:02:04 --> Session: Class initialized using 'files' driver.
INFO - 2024-01-04 14:02:04 --> Controller Class Initialized
INFO - 2024-01-04 14:02:04 --> Helper loaded: cookie_helper
INFO - 2024-01-04 14:02:04 --> Final output sent to browser
DEBUG - 2024-01-04 14:02:04 --> Total execution time: 0.0355
INFO - 2024-01-04 14:02:04 --> Config Class Initialized
INFO - 2024-01-04 14:02:04 --> Hooks Class Initialized
DEBUG - 2024-01-04 14:02:04 --> UTF-8 Support Enabled
INFO - 2024-01-04 14:02:04 --> Utf8 Class Initialized
INFO - 2024-01-04 14:02:04 --> URI Class Initialized
INFO - 2024-01-04 14:02:04 --> Router Class Initialized
INFO - 2024-01-04 14:02:04 --> Output Class Initialized
INFO - 2024-01-04 14:02:04 --> Security Class Initialized
DEBUG - 2024-01-04 14:02:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-01-04 14:02:04 --> Input Class Initialized
INFO - 2024-01-04 14:02:04 --> Language Class Initialized
INFO - 2024-01-04 14:02:04 --> Language Class Initialized
INFO - 2024-01-04 14:02:04 --> Config Class Initialized
INFO - 2024-01-04 14:02:04 --> Loader Class Initialized
INFO - 2024-01-04 14:02:04 --> Helper loaded: url_helper
INFO - 2024-01-04 14:02:04 --> Helper loaded: file_helper
INFO - 2024-01-04 14:02:04 --> Helper loaded: form_helper
INFO - 2024-01-04 14:02:04 --> Helper loaded: my_helper
INFO - 2024-01-04 14:02:04 --> Database Driver Class Initialized
INFO - 2024-01-04 14:02:04 --> Session: Class initialized using 'files' driver.
INFO - 2024-01-04 14:02:04 --> Controller Class Initialized
DEBUG - 2024-01-04 14:02:04 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/lihat_raport/views/list.php
DEBUG - 2024-01-04 14:02:04 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-01-04 14:02:04 --> Final output sent to browser
DEBUG - 2024-01-04 14:02:04 --> Total execution time: 0.0369
INFO - 2024-01-04 14:02:04 --> Config Class Initialized
INFO - 2024-01-04 14:02:04 --> Hooks Class Initialized
DEBUG - 2024-01-04 14:02:04 --> UTF-8 Support Enabled
INFO - 2024-01-04 14:02:04 --> Utf8 Class Initialized
INFO - 2024-01-04 14:02:04 --> URI Class Initialized
INFO - 2024-01-04 14:02:04 --> Router Class Initialized
INFO - 2024-01-04 14:02:04 --> Output Class Initialized
INFO - 2024-01-04 14:02:04 --> Security Class Initialized
DEBUG - 2024-01-04 14:02:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-01-04 14:02:04 --> Input Class Initialized
INFO - 2024-01-04 14:02:04 --> Language Class Initialized
INFO - 2024-01-04 14:02:04 --> Language Class Initialized
INFO - 2024-01-04 14:02:04 --> Config Class Initialized
INFO - 2024-01-04 14:02:04 --> Loader Class Initialized
INFO - 2024-01-04 14:02:04 --> Helper loaded: url_helper
INFO - 2024-01-04 14:02:04 --> Helper loaded: file_helper
INFO - 2024-01-04 14:02:04 --> Helper loaded: form_helper
INFO - 2024-01-04 14:02:04 --> Helper loaded: my_helper
INFO - 2024-01-04 14:02:04 --> Database Driver Class Initialized
INFO - 2024-01-04 14:02:04 --> Session: Class initialized using 'files' driver.
INFO - 2024-01-04 14:02:04 --> Controller Class Initialized
INFO - 2024-01-04 14:02:04 --> Helper loaded: cookie_helper
INFO - 2024-01-04 14:02:04 --> Config Class Initialized
INFO - 2024-01-04 14:02:04 --> Hooks Class Initialized
DEBUG - 2024-01-04 14:02:04 --> UTF-8 Support Enabled
INFO - 2024-01-04 14:02:04 --> Utf8 Class Initialized
INFO - 2024-01-04 14:02:05 --> URI Class Initialized
INFO - 2024-01-04 14:02:05 --> Router Class Initialized
INFO - 2024-01-04 14:02:05 --> Output Class Initialized
INFO - 2024-01-04 14:02:05 --> Security Class Initialized
DEBUG - 2024-01-04 14:02:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-01-04 14:02:05 --> Input Class Initialized
INFO - 2024-01-04 14:02:05 --> Language Class Initialized
INFO - 2024-01-04 14:02:05 --> Language Class Initialized
INFO - 2024-01-04 14:02:05 --> Config Class Initialized
INFO - 2024-01-04 14:02:05 --> Loader Class Initialized
INFO - 2024-01-04 14:02:05 --> Helper loaded: url_helper
INFO - 2024-01-04 14:02:05 --> Helper loaded: file_helper
INFO - 2024-01-04 14:02:05 --> Helper loaded: form_helper
INFO - 2024-01-04 14:02:05 --> Helper loaded: my_helper
INFO - 2024-01-04 14:02:05 --> Database Driver Class Initialized
INFO - 2024-01-04 14:02:05 --> Session: Class initialized using 'files' driver.
INFO - 2024-01-04 14:02:05 --> Controller Class Initialized
INFO - 2024-01-04 14:02:05 --> Helper loaded: cookie_helper
INFO - 2024-01-04 14:02:05 --> Final output sent to browser
DEBUG - 2024-01-04 14:02:05 --> Total execution time: 0.2857
INFO - 2024-01-04 14:02:05 --> Config Class Initialized
INFO - 2024-01-04 14:02:05 --> Hooks Class Initialized
DEBUG - 2024-01-04 14:02:05 --> UTF-8 Support Enabled
INFO - 2024-01-04 14:02:05 --> Utf8 Class Initialized
INFO - 2024-01-04 14:02:05 --> URI Class Initialized
INFO - 2024-01-04 14:02:05 --> Config Class Initialized
INFO - 2024-01-04 14:02:05 --> Hooks Class Initialized
DEBUG - 2024-01-04 14:02:05 --> UTF-8 Support Enabled
INFO - 2024-01-04 14:02:05 --> Utf8 Class Initialized
INFO - 2024-01-04 14:02:05 --> URI Class Initialized
INFO - 2024-01-04 14:02:05 --> Router Class Initialized
INFO - 2024-01-04 14:02:05 --> Output Class Initialized
INFO - 2024-01-04 14:02:05 --> Security Class Initialized
INFO - 2024-01-04 14:02:05 --> Router Class Initialized
INFO - 2024-01-04 14:02:05 --> Output Class Initialized
INFO - 2024-01-04 14:02:05 --> Security Class Initialized
DEBUG - 2024-01-04 14:02:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-01-04 14:02:05 --> Input Class Initialized
INFO - 2024-01-04 14:02:05 --> Language Class Initialized
INFO - 2024-01-04 14:02:05 --> Language Class Initialized
INFO - 2024-01-04 14:02:05 --> Config Class Initialized
INFO - 2024-01-04 14:02:05 --> Loader Class Initialized
INFO - 2024-01-04 14:02:05 --> Helper loaded: url_helper
INFO - 2024-01-04 14:02:05 --> Helper loaded: file_helper
INFO - 2024-01-04 14:02:05 --> Helper loaded: form_helper
DEBUG - 2024-01-04 14:02:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-01-04 14:02:05 --> Input Class Initialized
INFO - 2024-01-04 14:02:05 --> Language Class Initialized
INFO - 2024-01-04 14:02:05 --> Language Class Initialized
INFO - 2024-01-04 14:02:05 --> Config Class Initialized
INFO - 2024-01-04 14:02:05 --> Loader Class Initialized
INFO - 2024-01-04 14:02:05 --> Helper loaded: url_helper
INFO - 2024-01-04 14:02:05 --> Helper loaded: file_helper
INFO - 2024-01-04 14:02:05 --> Helper loaded: form_helper
INFO - 2024-01-04 14:02:05 --> Helper loaded: my_helper
INFO - 2024-01-04 14:02:05 --> Helper loaded: my_helper
INFO - 2024-01-04 14:02:05 --> Database Driver Class Initialized
INFO - 2024-01-04 14:02:05 --> Database Driver Class Initialized
INFO - 2024-01-04 14:02:05 --> Config Class Initialized
INFO - 2024-01-04 14:02:05 --> Hooks Class Initialized
DEBUG - 2024-01-04 14:02:05 --> UTF-8 Support Enabled
INFO - 2024-01-04 14:02:05 --> Utf8 Class Initialized
INFO - 2024-01-04 14:02:05 --> URI Class Initialized
INFO - 2024-01-04 14:02:05 --> Router Class Initialized
INFO - 2024-01-04 14:02:05 --> Session: Class initialized using 'files' driver.
INFO - 2024-01-04 14:02:05 --> Controller Class Initialized
INFO - 2024-01-04 14:02:05 --> Output Class Initialized
INFO - 2024-01-04 14:02:05 --> Security Class Initialized
DEBUG - 2024-01-04 14:02:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-01-04 14:02:05 --> Input Class Initialized
INFO - 2024-01-04 14:02:05 --> Language Class Initialized
INFO - 2024-01-04 14:02:05 --> Language Class Initialized
INFO - 2024-01-04 14:02:05 --> Config Class Initialized
INFO - 2024-01-04 14:02:05 --> Loader Class Initialized
INFO - 2024-01-04 14:02:05 --> Helper loaded: url_helper
DEBUG - 2024-01-04 14:02:05 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/lihat_raport/views/list.php
DEBUG - 2024-01-04 14:02:05 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-01-04 14:02:05 --> Final output sent to browser
DEBUG - 2024-01-04 14:02:05 --> Total execution time: 0.1846
INFO - 2024-01-04 14:02:05 --> Session: Class initialized using 'files' driver.
INFO - 2024-01-04 14:02:05 --> Controller Class Initialized
INFO - 2024-01-04 14:02:05 --> Helper loaded: file_helper
INFO - 2024-01-04 14:02:05 --> Helper loaded: form_helper
INFO - 2024-01-04 14:02:05 --> Helper loaded: my_helper
INFO - 2024-01-04 14:02:05 --> Database Driver Class Initialized
INFO - 2024-01-04 14:02:05 --> Session: Class initialized using 'files' driver.
INFO - 2024-01-04 14:02:05 --> Controller Class Initialized
INFO - 2024-01-04 14:02:05 --> Helper loaded: cookie_helper
INFO - 2024-01-04 14:02:05 --> Helper loaded: cookie_helper
INFO - 2024-01-04 14:02:05 --> Final output sent to browser
DEBUG - 2024-01-04 14:02:05 --> Total execution time: 0.1507
INFO - 2024-01-04 14:02:06 --> Config Class Initialized
INFO - 2024-01-04 14:02:06 --> Hooks Class Initialized
DEBUG - 2024-01-04 14:02:06 --> UTF-8 Support Enabled
INFO - 2024-01-04 14:02:06 --> Utf8 Class Initialized
INFO - 2024-01-04 14:02:06 --> URI Class Initialized
INFO - 2024-01-04 14:02:06 --> Router Class Initialized
INFO - 2024-01-04 14:02:06 --> Config Class Initialized
INFO - 2024-01-04 14:02:06 --> Hooks Class Initialized
DEBUG - 2024-01-04 14:02:06 --> UTF-8 Support Enabled
INFO - 2024-01-04 14:02:06 --> Utf8 Class Initialized
INFO - 2024-01-04 14:02:06 --> URI Class Initialized
INFO - 2024-01-04 14:02:06 --> Router Class Initialized
INFO - 2024-01-04 14:02:06 --> Output Class Initialized
INFO - 2024-01-04 14:02:06 --> Security Class Initialized
DEBUG - 2024-01-04 14:02:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-01-04 14:02:06 --> Input Class Initialized
INFO - 2024-01-04 14:02:06 --> Language Class Initialized
INFO - 2024-01-04 14:02:06 --> Language Class Initialized
INFO - 2024-01-04 14:02:06 --> Config Class Initialized
INFO - 2024-01-04 14:02:06 --> Loader Class Initialized
INFO - 2024-01-04 14:02:06 --> Output Class Initialized
INFO - 2024-01-04 14:02:06 --> Security Class Initialized
DEBUG - 2024-01-04 14:02:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-01-04 14:02:06 --> Input Class Initialized
INFO - 2024-01-04 14:02:06 --> Language Class Initialized
INFO - 2024-01-04 14:02:06 --> Language Class Initialized
INFO - 2024-01-04 14:02:06 --> Config Class Initialized
INFO - 2024-01-04 14:02:06 --> Loader Class Initialized
INFO - 2024-01-04 14:02:06 --> Helper loaded: url_helper
INFO - 2024-01-04 14:02:06 --> Helper loaded: file_helper
INFO - 2024-01-04 14:02:06 --> Helper loaded: form_helper
INFO - 2024-01-04 14:02:06 --> Helper loaded: my_helper
INFO - 2024-01-04 14:02:06 --> Helper loaded: url_helper
INFO - 2024-01-04 14:02:06 --> Helper loaded: file_helper
INFO - 2024-01-04 14:02:06 --> Helper loaded: form_helper
INFO - 2024-01-04 14:02:06 --> Helper loaded: my_helper
INFO - 2024-01-04 14:02:06 --> Database Driver Class Initialized
INFO - 2024-01-04 14:02:06 --> Database Driver Class Initialized
INFO - 2024-01-04 14:02:06 --> Session: Class initialized using 'files' driver.
INFO - 2024-01-04 14:02:06 --> Controller Class Initialized
INFO - 2024-01-04 14:02:06 --> Helper loaded: cookie_helper
INFO - 2024-01-04 14:02:06 --> Session: Class initialized using 'files' driver.
INFO - 2024-01-04 14:02:06 --> Controller Class Initialized
DEBUG - 2024-01-04 14:02:06 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/lihat_raport/views/list.php
DEBUG - 2024-01-04 14:02:06 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-01-04 14:02:06 --> Final output sent to browser
DEBUG - 2024-01-04 14:02:06 --> Total execution time: 0.1723
INFO - 2024-01-04 14:02:07 --> Config Class Initialized
INFO - 2024-01-04 14:02:07 --> Hooks Class Initialized
DEBUG - 2024-01-04 14:02:07 --> UTF-8 Support Enabled
INFO - 2024-01-04 14:02:07 --> Utf8 Class Initialized
INFO - 2024-01-04 14:02:07 --> URI Class Initialized
INFO - 2024-01-04 14:02:07 --> Router Class Initialized
INFO - 2024-01-04 14:02:07 --> Output Class Initialized
INFO - 2024-01-04 14:02:07 --> Security Class Initialized
DEBUG - 2024-01-04 14:02:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-01-04 14:02:07 --> Input Class Initialized
INFO - 2024-01-04 14:02:07 --> Language Class Initialized
INFO - 2024-01-04 14:02:07 --> Language Class Initialized
INFO - 2024-01-04 14:02:07 --> Config Class Initialized
INFO - 2024-01-04 14:02:07 --> Loader Class Initialized
INFO - 2024-01-04 14:02:07 --> Helper loaded: url_helper
INFO - 2024-01-04 14:02:07 --> Helper loaded: file_helper
INFO - 2024-01-04 14:02:07 --> Helper loaded: form_helper
INFO - 2024-01-04 14:02:07 --> Helper loaded: my_helper
INFO - 2024-01-04 14:02:07 --> Database Driver Class Initialized
INFO - 2024-01-04 14:02:07 --> Session: Class initialized using 'files' driver.
INFO - 2024-01-04 14:02:07 --> Controller Class Initialized
DEBUG - 2024-01-04 14:02:07 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/lihat_raport/views/list.php
DEBUG - 2024-01-04 14:02:07 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-01-04 14:02:07 --> Final output sent to browser
DEBUG - 2024-01-04 14:02:07 --> Total execution time: 0.0841
INFO - 2024-01-04 14:02:14 --> Config Class Initialized
INFO - 2024-01-04 14:02:14 --> Hooks Class Initialized
DEBUG - 2024-01-04 14:02:14 --> UTF-8 Support Enabled
INFO - 2024-01-04 14:02:14 --> Utf8 Class Initialized
INFO - 2024-01-04 14:02:14 --> URI Class Initialized
INFO - 2024-01-04 14:02:14 --> Router Class Initialized
INFO - 2024-01-04 14:02:14 --> Output Class Initialized
INFO - 2024-01-04 14:02:14 --> Security Class Initialized
DEBUG - 2024-01-04 14:02:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-01-04 14:02:14 --> Input Class Initialized
INFO - 2024-01-04 14:02:14 --> Language Class Initialized
INFO - 2024-01-04 14:02:14 --> Language Class Initialized
INFO - 2024-01-04 14:02:14 --> Config Class Initialized
INFO - 2024-01-04 14:02:14 --> Loader Class Initialized
INFO - 2024-01-04 14:02:14 --> Helper loaded: url_helper
INFO - 2024-01-04 14:02:14 --> Helper loaded: file_helper
INFO - 2024-01-04 14:02:14 --> Helper loaded: form_helper
INFO - 2024-01-04 14:02:14 --> Helper loaded: my_helper
INFO - 2024-01-04 14:02:14 --> Database Driver Class Initialized
INFO - 2024-01-04 14:02:14 --> Session: Class initialized using 'files' driver.
INFO - 2024-01-04 14:02:14 --> Controller Class Initialized
DEBUG - 2024-01-04 14:02:14 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php
INFO - 2024-01-04 14:02:19 --> Final output sent to browser
DEBUG - 2024-01-04 14:02:19 --> Total execution time: 4.4862
