<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2023-11-23 09:34:22 --> Config Class Initialized
INFO - 2023-11-23 09:34:22 --> Hooks Class Initialized
DEBUG - 2023-11-23 09:34:22 --> UTF-8 Support Enabled
INFO - 2023-11-23 09:34:22 --> Utf8 Class Initialized
INFO - 2023-11-23 09:34:22 --> URI Class Initialized
DEBUG - 2023-11-23 09:34:22 --> No URI present. Default controller set.
INFO - 2023-11-23 09:34:22 --> Router Class Initialized
INFO - 2023-11-23 09:34:22 --> Output Class Initialized
INFO - 2023-11-23 09:34:22 --> Security Class Initialized
DEBUG - 2023-11-23 09:34:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-23 09:34:22 --> Input Class Initialized
INFO - 2023-11-23 09:34:22 --> Language Class Initialized
INFO - 2023-11-23 09:34:22 --> Language Class Initialized
INFO - 2023-11-23 09:34:22 --> Config Class Initialized
INFO - 2023-11-23 09:34:22 --> Loader Class Initialized
INFO - 2023-11-23 09:34:22 --> Helper loaded: url_helper
INFO - 2023-11-23 09:34:22 --> Helper loaded: file_helper
INFO - 2023-11-23 09:34:22 --> Helper loaded: form_helper
INFO - 2023-11-23 09:34:22 --> Helper loaded: my_helper
INFO - 2023-11-23 09:34:22 --> Database Driver Class Initialized
INFO - 2023-11-23 09:34:22 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-23 09:34:22 --> Controller Class Initialized
INFO - 2023-11-23 09:34:22 --> Config Class Initialized
INFO - 2023-11-23 09:34:22 --> Hooks Class Initialized
DEBUG - 2023-11-23 09:34:22 --> UTF-8 Support Enabled
INFO - 2023-11-23 09:34:22 --> Utf8 Class Initialized
INFO - 2023-11-23 09:34:22 --> URI Class Initialized
INFO - 2023-11-23 09:34:22 --> Router Class Initialized
INFO - 2023-11-23 09:34:22 --> Output Class Initialized
INFO - 2023-11-23 09:34:22 --> Security Class Initialized
DEBUG - 2023-11-23 09:34:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-23 09:34:22 --> Input Class Initialized
INFO - 2023-11-23 09:34:22 --> Language Class Initialized
INFO - 2023-11-23 09:34:22 --> Language Class Initialized
INFO - 2023-11-23 09:34:22 --> Config Class Initialized
INFO - 2023-11-23 09:34:22 --> Loader Class Initialized
INFO - 2023-11-23 09:34:22 --> Helper loaded: url_helper
INFO - 2023-11-23 09:34:22 --> Helper loaded: file_helper
INFO - 2023-11-23 09:34:22 --> Helper loaded: form_helper
INFO - 2023-11-23 09:34:22 --> Helper loaded: my_helper
INFO - 2023-11-23 09:34:22 --> Database Driver Class Initialized
INFO - 2023-11-23 09:34:22 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-23 09:34:22 --> Controller Class Initialized
DEBUG - 2023-11-23 09:34:22 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/login/views/login.php
DEBUG - 2023-11-23 09:34:22 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-11-23 09:34:22 --> Final output sent to browser
DEBUG - 2023-11-23 09:34:22 --> Total execution time: 0.0650
INFO - 2023-11-23 09:34:26 --> Config Class Initialized
INFO - 2023-11-23 09:34:26 --> Hooks Class Initialized
DEBUG - 2023-11-23 09:34:26 --> UTF-8 Support Enabled
INFO - 2023-11-23 09:34:26 --> Utf8 Class Initialized
INFO - 2023-11-23 09:34:26 --> URI Class Initialized
INFO - 2023-11-23 09:34:26 --> Router Class Initialized
INFO - 2023-11-23 09:34:26 --> Output Class Initialized
INFO - 2023-11-23 09:34:26 --> Security Class Initialized
DEBUG - 2023-11-23 09:34:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-23 09:34:26 --> Input Class Initialized
INFO - 2023-11-23 09:34:26 --> Language Class Initialized
INFO - 2023-11-23 09:34:26 --> Language Class Initialized
INFO - 2023-11-23 09:34:26 --> Config Class Initialized
INFO - 2023-11-23 09:34:26 --> Loader Class Initialized
INFO - 2023-11-23 09:34:26 --> Helper loaded: url_helper
INFO - 2023-11-23 09:34:26 --> Helper loaded: file_helper
INFO - 2023-11-23 09:34:26 --> Helper loaded: form_helper
INFO - 2023-11-23 09:34:26 --> Helper loaded: my_helper
INFO - 2023-11-23 09:34:26 --> Database Driver Class Initialized
INFO - 2023-11-23 09:34:26 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-23 09:34:26 --> Controller Class Initialized
INFO - 2023-11-23 09:34:26 --> Helper loaded: cookie_helper
INFO - 2023-11-23 09:34:26 --> Final output sent to browser
DEBUG - 2023-11-23 09:34:26 --> Total execution time: 0.1868
INFO - 2023-11-23 09:34:26 --> Config Class Initialized
INFO - 2023-11-23 09:34:26 --> Hooks Class Initialized
DEBUG - 2023-11-23 09:34:26 --> UTF-8 Support Enabled
INFO - 2023-11-23 09:34:26 --> Utf8 Class Initialized
INFO - 2023-11-23 09:34:26 --> URI Class Initialized
INFO - 2023-11-23 09:34:26 --> Router Class Initialized
INFO - 2023-11-23 09:34:26 --> Output Class Initialized
INFO - 2023-11-23 09:34:26 --> Security Class Initialized
DEBUG - 2023-11-23 09:34:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-23 09:34:26 --> Input Class Initialized
INFO - 2023-11-23 09:34:26 --> Language Class Initialized
INFO - 2023-11-23 09:34:26 --> Language Class Initialized
INFO - 2023-11-23 09:34:26 --> Config Class Initialized
INFO - 2023-11-23 09:34:26 --> Loader Class Initialized
INFO - 2023-11-23 09:34:26 --> Helper loaded: url_helper
INFO - 2023-11-23 09:34:26 --> Helper loaded: file_helper
INFO - 2023-11-23 09:34:26 --> Helper loaded: form_helper
INFO - 2023-11-23 09:34:26 --> Helper loaded: my_helper
INFO - 2023-11-23 09:34:26 --> Database Driver Class Initialized
INFO - 2023-11-23 09:34:26 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-23 09:34:26 --> Controller Class Initialized
DEBUG - 2023-11-23 09:34:26 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/home/views/v_home_guru.php
DEBUG - 2023-11-23 09:34:26 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-11-23 09:34:26 --> Final output sent to browser
DEBUG - 2023-11-23 09:34:26 --> Total execution time: 0.0987
INFO - 2023-11-23 09:34:29 --> Config Class Initialized
INFO - 2023-11-23 09:34:29 --> Hooks Class Initialized
DEBUG - 2023-11-23 09:34:29 --> UTF-8 Support Enabled
INFO - 2023-11-23 09:34:29 --> Utf8 Class Initialized
INFO - 2023-11-23 09:34:29 --> URI Class Initialized
INFO - 2023-11-23 09:34:29 --> Router Class Initialized
INFO - 2023-11-23 09:34:29 --> Output Class Initialized
INFO - 2023-11-23 09:34:29 --> Security Class Initialized
DEBUG - 2023-11-23 09:34:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-23 09:34:29 --> Input Class Initialized
INFO - 2023-11-23 09:34:29 --> Language Class Initialized
INFO - 2023-11-23 09:34:29 --> Language Class Initialized
INFO - 2023-11-23 09:34:29 --> Config Class Initialized
INFO - 2023-11-23 09:34:29 --> Loader Class Initialized
INFO - 2023-11-23 09:34:29 --> Helper loaded: url_helper
INFO - 2023-11-23 09:34:29 --> Helper loaded: file_helper
INFO - 2023-11-23 09:34:29 --> Helper loaded: form_helper
INFO - 2023-11-23 09:34:29 --> Helper loaded: my_helper
INFO - 2023-11-23 09:34:29 --> Database Driver Class Initialized
INFO - 2023-11-23 09:34:29 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-23 09:34:29 --> Controller Class Initialized
DEBUG - 2023-11-23 09:34:29 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/view_mapel/views/v_view_mapel.php
DEBUG - 2023-11-23 09:34:29 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-11-23 09:34:29 --> Final output sent to browser
DEBUG - 2023-11-23 09:34:29 --> Total execution time: 0.0423
INFO - 2023-11-23 09:35:03 --> Config Class Initialized
INFO - 2023-11-23 09:35:03 --> Hooks Class Initialized
DEBUG - 2023-11-23 09:35:03 --> UTF-8 Support Enabled
INFO - 2023-11-23 09:35:03 --> Utf8 Class Initialized
INFO - 2023-11-23 09:35:03 --> URI Class Initialized
INFO - 2023-11-23 09:35:03 --> Router Class Initialized
INFO - 2023-11-23 09:35:03 --> Output Class Initialized
INFO - 2023-11-23 09:35:03 --> Security Class Initialized
DEBUG - 2023-11-23 09:35:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-23 09:35:03 --> Input Class Initialized
INFO - 2023-11-23 09:35:03 --> Language Class Initialized
INFO - 2023-11-23 09:35:03 --> Language Class Initialized
INFO - 2023-11-23 09:35:03 --> Config Class Initialized
INFO - 2023-11-23 09:35:03 --> Loader Class Initialized
INFO - 2023-11-23 09:35:03 --> Helper loaded: url_helper
INFO - 2023-11-23 09:35:03 --> Helper loaded: file_helper
INFO - 2023-11-23 09:35:03 --> Helper loaded: form_helper
INFO - 2023-11-23 09:35:03 --> Helper loaded: my_helper
INFO - 2023-11-23 09:35:03 --> Database Driver Class Initialized
INFO - 2023-11-23 09:35:03 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-23 09:35:03 --> Controller Class Initialized
DEBUG - 2023-11-23 09:35:03 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/views/list.php
DEBUG - 2023-11-23 09:35:03 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-11-23 09:35:03 --> Final output sent to browser
DEBUG - 2023-11-23 09:35:03 --> Total execution time: 0.0675
INFO - 2023-11-23 09:35:04 --> Config Class Initialized
INFO - 2023-11-23 09:35:04 --> Hooks Class Initialized
DEBUG - 2023-11-23 09:35:04 --> UTF-8 Support Enabled
INFO - 2023-11-23 09:35:04 --> Utf8 Class Initialized
INFO - 2023-11-23 09:35:04 --> URI Class Initialized
INFO - 2023-11-23 09:35:04 --> Router Class Initialized
INFO - 2023-11-23 09:35:04 --> Output Class Initialized
INFO - 2023-11-23 09:35:04 --> Security Class Initialized
DEBUG - 2023-11-23 09:35:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-23 09:35:04 --> Input Class Initialized
INFO - 2023-11-23 09:35:04 --> Language Class Initialized
INFO - 2023-11-23 09:35:04 --> Language Class Initialized
INFO - 2023-11-23 09:35:04 --> Config Class Initialized
INFO - 2023-11-23 09:35:04 --> Loader Class Initialized
INFO - 2023-11-23 09:35:04 --> Helper loaded: url_helper
INFO - 2023-11-23 09:35:04 --> Helper loaded: file_helper
INFO - 2023-11-23 09:35:04 --> Helper loaded: form_helper
INFO - 2023-11-23 09:35:04 --> Helper loaded: my_helper
INFO - 2023-11-23 09:35:04 --> Database Driver Class Initialized
INFO - 2023-11-23 09:35:04 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-23 09:35:04 --> Controller Class Initialized
INFO - 2023-11-23 09:35:14 --> Config Class Initialized
INFO - 2023-11-23 09:35:14 --> Hooks Class Initialized
DEBUG - 2023-11-23 09:35:14 --> UTF-8 Support Enabled
INFO - 2023-11-23 09:35:14 --> Utf8 Class Initialized
INFO - 2023-11-23 09:35:14 --> URI Class Initialized
INFO - 2023-11-23 09:35:14 --> Router Class Initialized
INFO - 2023-11-23 09:35:14 --> Output Class Initialized
INFO - 2023-11-23 09:35:14 --> Security Class Initialized
DEBUG - 2023-11-23 09:35:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-23 09:35:14 --> Input Class Initialized
INFO - 2023-11-23 09:35:14 --> Language Class Initialized
INFO - 2023-11-23 09:35:14 --> Language Class Initialized
INFO - 2023-11-23 09:35:14 --> Config Class Initialized
INFO - 2023-11-23 09:35:14 --> Loader Class Initialized
INFO - 2023-11-23 09:35:14 --> Helper loaded: url_helper
INFO - 2023-11-23 09:35:14 --> Helper loaded: file_helper
INFO - 2023-11-23 09:35:14 --> Helper loaded: form_helper
INFO - 2023-11-23 09:35:14 --> Helper loaded: my_helper
INFO - 2023-11-23 09:35:14 --> Database Driver Class Initialized
INFO - 2023-11-23 09:35:14 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-23 09:35:14 --> Controller Class Initialized
INFO - 2023-11-23 09:35:15 --> Final output sent to browser
DEBUG - 2023-11-23 09:35:15 --> Total execution time: 0.0508
INFO - 2023-11-23 09:35:48 --> Config Class Initialized
INFO - 2023-11-23 09:35:48 --> Hooks Class Initialized
DEBUG - 2023-11-23 09:35:48 --> UTF-8 Support Enabled
INFO - 2023-11-23 09:35:48 --> Utf8 Class Initialized
INFO - 2023-11-23 09:35:48 --> URI Class Initialized
INFO - 2023-11-23 09:35:48 --> Router Class Initialized
INFO - 2023-11-23 09:35:48 --> Output Class Initialized
INFO - 2023-11-23 09:35:48 --> Security Class Initialized
DEBUG - 2023-11-23 09:35:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-23 09:35:48 --> Input Class Initialized
INFO - 2023-11-23 09:35:48 --> Language Class Initialized
INFO - 2023-11-23 09:35:48 --> Language Class Initialized
INFO - 2023-11-23 09:35:48 --> Config Class Initialized
INFO - 2023-11-23 09:35:48 --> Loader Class Initialized
INFO - 2023-11-23 09:35:48 --> Helper loaded: url_helper
INFO - 2023-11-23 09:35:48 --> Helper loaded: file_helper
INFO - 2023-11-23 09:35:48 --> Helper loaded: form_helper
INFO - 2023-11-23 09:35:48 --> Helper loaded: my_helper
INFO - 2023-11-23 09:35:48 --> Database Driver Class Initialized
INFO - 2023-11-23 09:35:48 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-23 09:35:48 --> Controller Class Initialized
INFO - 2023-11-23 09:35:48 --> Final output sent to browser
DEBUG - 2023-11-23 09:35:48 --> Total execution time: 0.2909
INFO - 2023-11-23 09:35:51 --> Config Class Initialized
INFO - 2023-11-23 09:35:51 --> Hooks Class Initialized
DEBUG - 2023-11-23 09:35:51 --> UTF-8 Support Enabled
INFO - 2023-11-23 09:35:51 --> Utf8 Class Initialized
INFO - 2023-11-23 09:35:51 --> URI Class Initialized
INFO - 2023-11-23 09:35:51 --> Router Class Initialized
INFO - 2023-11-23 09:35:51 --> Output Class Initialized
INFO - 2023-11-23 09:35:51 --> Security Class Initialized
DEBUG - 2023-11-23 09:35:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-23 09:35:51 --> Input Class Initialized
INFO - 2023-11-23 09:35:51 --> Language Class Initialized
INFO - 2023-11-23 09:35:51 --> Language Class Initialized
INFO - 2023-11-23 09:35:51 --> Config Class Initialized
INFO - 2023-11-23 09:35:51 --> Loader Class Initialized
INFO - 2023-11-23 09:35:51 --> Helper loaded: url_helper
INFO - 2023-11-23 09:35:51 --> Helper loaded: file_helper
INFO - 2023-11-23 09:35:51 --> Helper loaded: form_helper
INFO - 2023-11-23 09:35:51 --> Helper loaded: my_helper
INFO - 2023-11-23 09:35:51 --> Database Driver Class Initialized
INFO - 2023-11-23 09:35:51 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-23 09:35:51 --> Controller Class Initialized
DEBUG - 2023-11-23 09:35:51 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/view_mapel/views/v_view_mapel.php
DEBUG - 2023-11-23 09:35:51 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-11-23 09:35:51 --> Final output sent to browser
DEBUG - 2023-11-23 09:35:51 --> Total execution time: 0.0342
INFO - 2023-11-23 09:35:55 --> Config Class Initialized
INFO - 2023-11-23 09:35:55 --> Hooks Class Initialized
DEBUG - 2023-11-23 09:35:55 --> UTF-8 Support Enabled
INFO - 2023-11-23 09:35:55 --> Utf8 Class Initialized
INFO - 2023-11-23 09:35:55 --> URI Class Initialized
INFO - 2023-11-23 09:35:55 --> Router Class Initialized
INFO - 2023-11-23 09:35:55 --> Output Class Initialized
INFO - 2023-11-23 09:35:55 --> Security Class Initialized
DEBUG - 2023-11-23 09:35:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-23 09:35:55 --> Input Class Initialized
INFO - 2023-11-23 09:35:55 --> Language Class Initialized
INFO - 2023-11-23 09:35:55 --> Language Class Initialized
INFO - 2023-11-23 09:35:55 --> Config Class Initialized
INFO - 2023-11-23 09:35:55 --> Loader Class Initialized
INFO - 2023-11-23 09:35:55 --> Helper loaded: url_helper
INFO - 2023-11-23 09:35:55 --> Helper loaded: file_helper
INFO - 2023-11-23 09:35:55 --> Helper loaded: form_helper
INFO - 2023-11-23 09:35:55 --> Helper loaded: my_helper
INFO - 2023-11-23 09:35:55 --> Database Driver Class Initialized
INFO - 2023-11-23 09:35:55 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-23 09:35:55 --> Controller Class Initialized
DEBUG - 2023-11-23 09:35:55 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/views/list.php
DEBUG - 2023-11-23 09:35:55 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-11-23 09:35:55 --> Final output sent to browser
DEBUG - 2023-11-23 09:35:55 --> Total execution time: 0.1122
INFO - 2023-11-23 09:35:55 --> Config Class Initialized
INFO - 2023-11-23 09:35:55 --> Hooks Class Initialized
DEBUG - 2023-11-23 09:35:55 --> UTF-8 Support Enabled
INFO - 2023-11-23 09:35:55 --> Utf8 Class Initialized
INFO - 2023-11-23 09:35:55 --> URI Class Initialized
INFO - 2023-11-23 09:35:55 --> Router Class Initialized
INFO - 2023-11-23 09:35:55 --> Output Class Initialized
INFO - 2023-11-23 09:35:55 --> Security Class Initialized
DEBUG - 2023-11-23 09:35:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-23 09:35:55 --> Input Class Initialized
INFO - 2023-11-23 09:35:55 --> Language Class Initialized
INFO - 2023-11-23 09:35:55 --> Language Class Initialized
INFO - 2023-11-23 09:35:55 --> Config Class Initialized
INFO - 2023-11-23 09:35:55 --> Loader Class Initialized
INFO - 2023-11-23 09:35:55 --> Helper loaded: url_helper
INFO - 2023-11-23 09:35:55 --> Helper loaded: file_helper
INFO - 2023-11-23 09:35:55 --> Helper loaded: form_helper
INFO - 2023-11-23 09:35:55 --> Helper loaded: my_helper
INFO - 2023-11-23 09:35:55 --> Database Driver Class Initialized
INFO - 2023-11-23 09:35:55 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-23 09:35:55 --> Controller Class Initialized
INFO - 2023-11-23 09:36:02 --> Config Class Initialized
INFO - 2023-11-23 09:36:02 --> Hooks Class Initialized
DEBUG - 2023-11-23 09:36:02 --> UTF-8 Support Enabled
INFO - 2023-11-23 09:36:02 --> Utf8 Class Initialized
INFO - 2023-11-23 09:36:02 --> URI Class Initialized
INFO - 2023-11-23 09:36:02 --> Router Class Initialized
INFO - 2023-11-23 09:36:02 --> Output Class Initialized
INFO - 2023-11-23 09:36:02 --> Security Class Initialized
DEBUG - 2023-11-23 09:36:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-23 09:36:02 --> Input Class Initialized
INFO - 2023-11-23 09:36:02 --> Language Class Initialized
INFO - 2023-11-23 09:36:02 --> Language Class Initialized
INFO - 2023-11-23 09:36:02 --> Config Class Initialized
INFO - 2023-11-23 09:36:02 --> Loader Class Initialized
INFO - 2023-11-23 09:36:02 --> Helper loaded: url_helper
INFO - 2023-11-23 09:36:02 --> Helper loaded: file_helper
INFO - 2023-11-23 09:36:02 --> Helper loaded: form_helper
INFO - 2023-11-23 09:36:02 --> Helper loaded: my_helper
INFO - 2023-11-23 09:36:02 --> Database Driver Class Initialized
INFO - 2023-11-23 09:36:02 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-23 09:36:02 --> Controller Class Initialized
INFO - 2023-11-23 09:36:02 --> Final output sent to browser
DEBUG - 2023-11-23 09:36:02 --> Total execution time: 0.0534
INFO - 2023-11-23 09:37:39 --> Config Class Initialized
INFO - 2023-11-23 09:37:39 --> Hooks Class Initialized
DEBUG - 2023-11-23 09:37:39 --> UTF-8 Support Enabled
INFO - 2023-11-23 09:37:39 --> Utf8 Class Initialized
INFO - 2023-11-23 09:37:39 --> URI Class Initialized
INFO - 2023-11-23 09:37:39 --> Router Class Initialized
INFO - 2023-11-23 09:37:39 --> Output Class Initialized
INFO - 2023-11-23 09:37:39 --> Security Class Initialized
DEBUG - 2023-11-23 09:37:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-23 09:37:39 --> Input Class Initialized
INFO - 2023-11-23 09:37:39 --> Language Class Initialized
INFO - 2023-11-23 09:37:39 --> Language Class Initialized
INFO - 2023-11-23 09:37:39 --> Config Class Initialized
INFO - 2023-11-23 09:37:39 --> Loader Class Initialized
INFO - 2023-11-23 09:37:39 --> Helper loaded: url_helper
INFO - 2023-11-23 09:37:39 --> Helper loaded: file_helper
INFO - 2023-11-23 09:37:39 --> Helper loaded: form_helper
INFO - 2023-11-23 09:37:39 --> Helper loaded: my_helper
INFO - 2023-11-23 09:37:39 --> Database Driver Class Initialized
INFO - 2023-11-23 09:37:39 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-23 09:37:39 --> Controller Class Initialized
INFO - 2023-11-23 09:37:39 --> Final output sent to browser
DEBUG - 2023-11-23 09:37:39 --> Total execution time: 0.1372
INFO - 2023-11-23 09:37:46 --> Config Class Initialized
INFO - 2023-11-23 09:37:46 --> Hooks Class Initialized
DEBUG - 2023-11-23 09:37:46 --> UTF-8 Support Enabled
INFO - 2023-11-23 09:37:46 --> Utf8 Class Initialized
INFO - 2023-11-23 09:37:46 --> URI Class Initialized
INFO - 2023-11-23 09:37:46 --> Router Class Initialized
INFO - 2023-11-23 09:37:46 --> Output Class Initialized
INFO - 2023-11-23 09:37:46 --> Security Class Initialized
DEBUG - 2023-11-23 09:37:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-23 09:37:46 --> Input Class Initialized
INFO - 2023-11-23 09:37:46 --> Language Class Initialized
INFO - 2023-11-23 09:37:46 --> Language Class Initialized
INFO - 2023-11-23 09:37:46 --> Config Class Initialized
INFO - 2023-11-23 09:37:46 --> Loader Class Initialized
INFO - 2023-11-23 09:37:46 --> Helper loaded: url_helper
INFO - 2023-11-23 09:37:46 --> Helper loaded: file_helper
INFO - 2023-11-23 09:37:46 --> Helper loaded: form_helper
INFO - 2023-11-23 09:37:46 --> Helper loaded: my_helper
INFO - 2023-11-23 09:37:46 --> Database Driver Class Initialized
INFO - 2023-11-23 09:37:46 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-23 09:37:46 --> Controller Class Initialized
INFO - 2023-11-23 09:37:46 --> Final output sent to browser
DEBUG - 2023-11-23 09:37:46 --> Total execution time: 0.3330
INFO - 2023-11-23 09:38:00 --> Config Class Initialized
INFO - 2023-11-23 09:38:00 --> Hooks Class Initialized
DEBUG - 2023-11-23 09:38:00 --> UTF-8 Support Enabled
INFO - 2023-11-23 09:38:00 --> Utf8 Class Initialized
INFO - 2023-11-23 09:38:00 --> URI Class Initialized
INFO - 2023-11-23 09:38:00 --> Router Class Initialized
INFO - 2023-11-23 09:38:00 --> Output Class Initialized
INFO - 2023-11-23 09:38:00 --> Security Class Initialized
DEBUG - 2023-11-23 09:38:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-23 09:38:00 --> Input Class Initialized
INFO - 2023-11-23 09:38:00 --> Language Class Initialized
INFO - 2023-11-23 09:38:00 --> Language Class Initialized
INFO - 2023-11-23 09:38:00 --> Config Class Initialized
INFO - 2023-11-23 09:38:00 --> Loader Class Initialized
INFO - 2023-11-23 09:38:00 --> Helper loaded: url_helper
INFO - 2023-11-23 09:38:00 --> Helper loaded: file_helper
INFO - 2023-11-23 09:38:00 --> Helper loaded: form_helper
INFO - 2023-11-23 09:38:00 --> Helper loaded: my_helper
INFO - 2023-11-23 09:38:00 --> Database Driver Class Initialized
INFO - 2023-11-23 09:38:00 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-23 09:38:00 --> Controller Class Initialized
INFO - 2023-11-23 09:38:00 --> Final output sent to browser
DEBUG - 2023-11-23 09:38:00 --> Total execution time: 0.0433
INFO - 2023-11-23 09:38:25 --> Config Class Initialized
INFO - 2023-11-23 09:38:25 --> Hooks Class Initialized
DEBUG - 2023-11-23 09:38:25 --> UTF-8 Support Enabled
INFO - 2023-11-23 09:38:25 --> Utf8 Class Initialized
INFO - 2023-11-23 09:38:25 --> URI Class Initialized
INFO - 2023-11-23 09:38:25 --> Router Class Initialized
INFO - 2023-11-23 09:38:25 --> Output Class Initialized
INFO - 2023-11-23 09:38:25 --> Security Class Initialized
DEBUG - 2023-11-23 09:38:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-23 09:38:25 --> Input Class Initialized
INFO - 2023-11-23 09:38:25 --> Language Class Initialized
INFO - 2023-11-23 09:38:25 --> Language Class Initialized
INFO - 2023-11-23 09:38:25 --> Config Class Initialized
INFO - 2023-11-23 09:38:25 --> Loader Class Initialized
INFO - 2023-11-23 09:38:25 --> Helper loaded: url_helper
INFO - 2023-11-23 09:38:25 --> Helper loaded: file_helper
INFO - 2023-11-23 09:38:25 --> Helper loaded: form_helper
INFO - 2023-11-23 09:38:25 --> Helper loaded: my_helper
INFO - 2023-11-23 09:38:25 --> Database Driver Class Initialized
INFO - 2023-11-23 09:38:25 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-23 09:38:25 --> Controller Class Initialized
INFO - 2023-11-23 09:38:25 --> Final output sent to browser
DEBUG - 2023-11-23 09:38:25 --> Total execution time: 0.0916
INFO - 2023-11-23 09:38:25 --> Config Class Initialized
INFO - 2023-11-23 09:38:25 --> Hooks Class Initialized
DEBUG - 2023-11-23 09:38:25 --> UTF-8 Support Enabled
INFO - 2023-11-23 09:38:25 --> Utf8 Class Initialized
INFO - 2023-11-23 09:38:25 --> URI Class Initialized
INFO - 2023-11-23 09:38:25 --> Router Class Initialized
INFO - 2023-11-23 09:38:25 --> Output Class Initialized
INFO - 2023-11-23 09:38:25 --> Security Class Initialized
DEBUG - 2023-11-23 09:38:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-23 09:38:25 --> Input Class Initialized
INFO - 2023-11-23 09:38:25 --> Language Class Initialized
INFO - 2023-11-23 09:38:25 --> Language Class Initialized
INFO - 2023-11-23 09:38:25 --> Config Class Initialized
INFO - 2023-11-23 09:38:25 --> Loader Class Initialized
INFO - 2023-11-23 09:38:25 --> Helper loaded: url_helper
INFO - 2023-11-23 09:38:25 --> Helper loaded: file_helper
INFO - 2023-11-23 09:38:25 --> Helper loaded: form_helper
INFO - 2023-11-23 09:38:25 --> Helper loaded: my_helper
INFO - 2023-11-23 09:38:25 --> Database Driver Class Initialized
INFO - 2023-11-23 09:38:25 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-23 09:38:25 --> Controller Class Initialized
INFO - 2023-11-23 09:38:53 --> Config Class Initialized
INFO - 2023-11-23 09:38:53 --> Hooks Class Initialized
DEBUG - 2023-11-23 09:38:53 --> UTF-8 Support Enabled
INFO - 2023-11-23 09:38:53 --> Utf8 Class Initialized
INFO - 2023-11-23 09:38:53 --> URI Class Initialized
INFO - 2023-11-23 09:38:53 --> Router Class Initialized
INFO - 2023-11-23 09:38:53 --> Output Class Initialized
INFO - 2023-11-23 09:38:53 --> Security Class Initialized
DEBUG - 2023-11-23 09:38:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-23 09:38:53 --> Input Class Initialized
INFO - 2023-11-23 09:38:53 --> Language Class Initialized
INFO - 2023-11-23 09:38:53 --> Language Class Initialized
INFO - 2023-11-23 09:38:53 --> Config Class Initialized
INFO - 2023-11-23 09:38:53 --> Loader Class Initialized
INFO - 2023-11-23 09:38:53 --> Helper loaded: url_helper
INFO - 2023-11-23 09:38:53 --> Helper loaded: file_helper
INFO - 2023-11-23 09:38:53 --> Helper loaded: form_helper
INFO - 2023-11-23 09:38:53 --> Helper loaded: my_helper
INFO - 2023-11-23 09:38:53 --> Database Driver Class Initialized
INFO - 2023-11-23 09:38:53 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-23 09:38:53 --> Controller Class Initialized
INFO - 2023-11-23 09:38:53 --> Final output sent to browser
DEBUG - 2023-11-23 09:38:53 --> Total execution time: 0.0355
INFO - 2023-11-23 09:40:08 --> Config Class Initialized
INFO - 2023-11-23 09:40:08 --> Hooks Class Initialized
DEBUG - 2023-11-23 09:40:08 --> UTF-8 Support Enabled
INFO - 2023-11-23 09:40:08 --> Utf8 Class Initialized
INFO - 2023-11-23 09:40:08 --> URI Class Initialized
INFO - 2023-11-23 09:40:08 --> Router Class Initialized
INFO - 2023-11-23 09:40:08 --> Output Class Initialized
INFO - 2023-11-23 09:40:08 --> Security Class Initialized
DEBUG - 2023-11-23 09:40:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-23 09:40:08 --> Input Class Initialized
INFO - 2023-11-23 09:40:08 --> Language Class Initialized
INFO - 2023-11-23 09:40:08 --> Language Class Initialized
INFO - 2023-11-23 09:40:08 --> Config Class Initialized
INFO - 2023-11-23 09:40:08 --> Loader Class Initialized
INFO - 2023-11-23 09:40:08 --> Helper loaded: url_helper
INFO - 2023-11-23 09:40:08 --> Helper loaded: file_helper
INFO - 2023-11-23 09:40:08 --> Helper loaded: form_helper
INFO - 2023-11-23 09:40:08 --> Helper loaded: my_helper
INFO - 2023-11-23 09:40:08 --> Database Driver Class Initialized
INFO - 2023-11-23 09:40:08 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-23 09:40:08 --> Controller Class Initialized
INFO - 2023-11-23 09:40:08 --> Final output sent to browser
DEBUG - 2023-11-23 09:40:08 --> Total execution time: 0.1236
INFO - 2023-11-23 09:40:08 --> Config Class Initialized
INFO - 2023-11-23 09:40:08 --> Hooks Class Initialized
DEBUG - 2023-11-23 09:40:08 --> UTF-8 Support Enabled
INFO - 2023-11-23 09:40:08 --> Utf8 Class Initialized
INFO - 2023-11-23 09:40:08 --> URI Class Initialized
INFO - 2023-11-23 09:40:08 --> Router Class Initialized
INFO - 2023-11-23 09:40:08 --> Output Class Initialized
INFO - 2023-11-23 09:40:08 --> Security Class Initialized
DEBUG - 2023-11-23 09:40:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-23 09:40:08 --> Input Class Initialized
INFO - 2023-11-23 09:40:08 --> Language Class Initialized
INFO - 2023-11-23 09:40:08 --> Language Class Initialized
INFO - 2023-11-23 09:40:08 --> Config Class Initialized
INFO - 2023-11-23 09:40:08 --> Loader Class Initialized
INFO - 2023-11-23 09:40:08 --> Helper loaded: url_helper
INFO - 2023-11-23 09:40:08 --> Helper loaded: file_helper
INFO - 2023-11-23 09:40:08 --> Helper loaded: form_helper
INFO - 2023-11-23 09:40:08 --> Helper loaded: my_helper
INFO - 2023-11-23 09:40:08 --> Database Driver Class Initialized
INFO - 2023-11-23 09:40:08 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-23 09:40:08 --> Controller Class Initialized
INFO - 2023-11-23 09:40:09 --> Config Class Initialized
INFO - 2023-11-23 09:40:09 --> Hooks Class Initialized
DEBUG - 2023-11-23 09:40:09 --> UTF-8 Support Enabled
INFO - 2023-11-23 09:40:09 --> Utf8 Class Initialized
INFO - 2023-11-23 09:40:09 --> URI Class Initialized
INFO - 2023-11-23 09:40:09 --> Router Class Initialized
INFO - 2023-11-23 09:40:09 --> Output Class Initialized
INFO - 2023-11-23 09:40:09 --> Security Class Initialized
DEBUG - 2023-11-23 09:40:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-23 09:40:09 --> Input Class Initialized
INFO - 2023-11-23 09:40:09 --> Language Class Initialized
INFO - 2023-11-23 09:40:09 --> Language Class Initialized
INFO - 2023-11-23 09:40:09 --> Config Class Initialized
INFO - 2023-11-23 09:40:09 --> Loader Class Initialized
INFO - 2023-11-23 09:40:09 --> Helper loaded: url_helper
INFO - 2023-11-23 09:40:09 --> Helper loaded: file_helper
INFO - 2023-11-23 09:40:09 --> Helper loaded: form_helper
INFO - 2023-11-23 09:40:09 --> Helper loaded: my_helper
INFO - 2023-11-23 09:40:09 --> Database Driver Class Initialized
INFO - 2023-11-23 09:40:09 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-23 09:40:09 --> Controller Class Initialized
INFO - 2023-11-23 09:40:09 --> Final output sent to browser
DEBUG - 2023-11-23 09:40:09 --> Total execution time: 0.0872
INFO - 2023-11-23 09:40:15 --> Config Class Initialized
INFO - 2023-11-23 09:40:15 --> Hooks Class Initialized
DEBUG - 2023-11-23 09:40:15 --> UTF-8 Support Enabled
INFO - 2023-11-23 09:40:15 --> Utf8 Class Initialized
INFO - 2023-11-23 09:40:15 --> URI Class Initialized
INFO - 2023-11-23 09:40:15 --> Router Class Initialized
INFO - 2023-11-23 09:40:15 --> Output Class Initialized
INFO - 2023-11-23 09:40:15 --> Security Class Initialized
DEBUG - 2023-11-23 09:40:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-23 09:40:15 --> Input Class Initialized
INFO - 2023-11-23 09:40:15 --> Language Class Initialized
INFO - 2023-11-23 09:40:15 --> Language Class Initialized
INFO - 2023-11-23 09:40:15 --> Config Class Initialized
INFO - 2023-11-23 09:40:15 --> Loader Class Initialized
INFO - 2023-11-23 09:40:15 --> Helper loaded: url_helper
INFO - 2023-11-23 09:40:15 --> Helper loaded: file_helper
INFO - 2023-11-23 09:40:15 --> Helper loaded: form_helper
INFO - 2023-11-23 09:40:15 --> Helper loaded: my_helper
INFO - 2023-11-23 09:40:15 --> Database Driver Class Initialized
INFO - 2023-11-23 09:40:15 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-23 09:40:15 --> Controller Class Initialized
INFO - 2023-11-23 09:40:15 --> Final output sent to browser
DEBUG - 2023-11-23 09:40:15 --> Total execution time: 0.0393
INFO - 2023-11-23 09:40:19 --> Config Class Initialized
INFO - 2023-11-23 09:40:19 --> Hooks Class Initialized
DEBUG - 2023-11-23 09:40:19 --> UTF-8 Support Enabled
INFO - 2023-11-23 09:40:19 --> Utf8 Class Initialized
INFO - 2023-11-23 09:40:19 --> URI Class Initialized
INFO - 2023-11-23 09:40:19 --> Router Class Initialized
INFO - 2023-11-23 09:40:19 --> Output Class Initialized
INFO - 2023-11-23 09:40:19 --> Security Class Initialized
DEBUG - 2023-11-23 09:40:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-23 09:40:19 --> Input Class Initialized
INFO - 2023-11-23 09:40:19 --> Language Class Initialized
INFO - 2023-11-23 09:40:20 --> Language Class Initialized
INFO - 2023-11-23 09:40:20 --> Config Class Initialized
INFO - 2023-11-23 09:40:20 --> Loader Class Initialized
INFO - 2023-11-23 09:40:20 --> Helper loaded: url_helper
INFO - 2023-11-23 09:40:20 --> Helper loaded: file_helper
INFO - 2023-11-23 09:40:20 --> Helper loaded: form_helper
INFO - 2023-11-23 09:40:20 --> Helper loaded: my_helper
INFO - 2023-11-23 09:40:20 --> Database Driver Class Initialized
INFO - 2023-11-23 09:40:20 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-23 09:40:20 --> Controller Class Initialized
INFO - 2023-11-23 09:41:04 --> Config Class Initialized
INFO - 2023-11-23 09:41:04 --> Hooks Class Initialized
DEBUG - 2023-11-23 09:41:04 --> UTF-8 Support Enabled
INFO - 2023-11-23 09:41:04 --> Utf8 Class Initialized
INFO - 2023-11-23 09:41:04 --> URI Class Initialized
INFO - 2023-11-23 09:41:04 --> Router Class Initialized
INFO - 2023-11-23 09:41:04 --> Output Class Initialized
INFO - 2023-11-23 09:41:04 --> Security Class Initialized
DEBUG - 2023-11-23 09:41:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-23 09:41:04 --> Input Class Initialized
INFO - 2023-11-23 09:41:04 --> Language Class Initialized
INFO - 2023-11-23 09:41:04 --> Language Class Initialized
INFO - 2023-11-23 09:41:04 --> Config Class Initialized
INFO - 2023-11-23 09:41:04 --> Loader Class Initialized
INFO - 2023-11-23 09:41:04 --> Helper loaded: url_helper
INFO - 2023-11-23 09:41:04 --> Helper loaded: file_helper
INFO - 2023-11-23 09:41:04 --> Helper loaded: form_helper
INFO - 2023-11-23 09:41:04 --> Helper loaded: my_helper
INFO - 2023-11-23 09:41:04 --> Database Driver Class Initialized
INFO - 2023-11-23 09:41:04 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-23 09:41:04 --> Controller Class Initialized
INFO - 2023-11-23 09:41:04 --> Final output sent to browser
DEBUG - 2023-11-23 09:41:04 --> Total execution time: 0.0485
INFO - 2023-11-23 09:41:06 --> Config Class Initialized
INFO - 2023-11-23 09:41:06 --> Hooks Class Initialized
DEBUG - 2023-11-23 09:41:06 --> UTF-8 Support Enabled
INFO - 2023-11-23 09:41:06 --> Utf8 Class Initialized
INFO - 2023-11-23 09:41:06 --> URI Class Initialized
INFO - 2023-11-23 09:41:06 --> Router Class Initialized
INFO - 2023-11-23 09:41:06 --> Output Class Initialized
INFO - 2023-11-23 09:41:06 --> Security Class Initialized
DEBUG - 2023-11-23 09:41:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-23 09:41:06 --> Input Class Initialized
INFO - 2023-11-23 09:41:06 --> Language Class Initialized
INFO - 2023-11-23 09:41:06 --> Language Class Initialized
INFO - 2023-11-23 09:41:06 --> Config Class Initialized
INFO - 2023-11-23 09:41:06 --> Loader Class Initialized
INFO - 2023-11-23 09:41:06 --> Helper loaded: url_helper
INFO - 2023-11-23 09:41:06 --> Helper loaded: file_helper
INFO - 2023-11-23 09:41:06 --> Helper loaded: form_helper
INFO - 2023-11-23 09:41:06 --> Helper loaded: my_helper
INFO - 2023-11-23 09:41:06 --> Database Driver Class Initialized
INFO - 2023-11-23 09:41:06 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-23 09:41:06 --> Controller Class Initialized
INFO - 2023-11-23 09:41:06 --> Final output sent to browser
DEBUG - 2023-11-23 09:41:06 --> Total execution time: 0.4172
INFO - 2023-11-23 09:41:09 --> Config Class Initialized
INFO - 2023-11-23 09:41:09 --> Hooks Class Initialized
DEBUG - 2023-11-23 09:41:09 --> UTF-8 Support Enabled
INFO - 2023-11-23 09:41:09 --> Utf8 Class Initialized
INFO - 2023-11-23 09:41:09 --> URI Class Initialized
INFO - 2023-11-23 09:41:09 --> Router Class Initialized
INFO - 2023-11-23 09:41:09 --> Output Class Initialized
INFO - 2023-11-23 09:41:09 --> Security Class Initialized
DEBUG - 2023-11-23 09:41:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-23 09:41:09 --> Input Class Initialized
INFO - 2023-11-23 09:41:09 --> Language Class Initialized
INFO - 2023-11-23 09:41:09 --> Language Class Initialized
INFO - 2023-11-23 09:41:09 --> Config Class Initialized
INFO - 2023-11-23 09:41:09 --> Loader Class Initialized
INFO - 2023-11-23 09:41:09 --> Helper loaded: url_helper
INFO - 2023-11-23 09:41:09 --> Helper loaded: file_helper
INFO - 2023-11-23 09:41:09 --> Helper loaded: form_helper
INFO - 2023-11-23 09:41:09 --> Helper loaded: my_helper
INFO - 2023-11-23 09:41:09 --> Database Driver Class Initialized
INFO - 2023-11-23 09:41:09 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-23 09:41:09 --> Controller Class Initialized
INFO - 2023-11-23 09:41:09 --> Final output sent to browser
DEBUG - 2023-11-23 09:41:09 --> Total execution time: 0.0514
INFO - 2023-11-23 09:41:09 --> Config Class Initialized
INFO - 2023-11-23 09:41:09 --> Hooks Class Initialized
DEBUG - 2023-11-23 09:41:09 --> UTF-8 Support Enabled
INFO - 2023-11-23 09:41:09 --> Utf8 Class Initialized
INFO - 2023-11-23 09:41:09 --> URI Class Initialized
INFO - 2023-11-23 09:41:09 --> Router Class Initialized
INFO - 2023-11-23 09:41:09 --> Output Class Initialized
INFO - 2023-11-23 09:41:09 --> Security Class Initialized
DEBUG - 2023-11-23 09:41:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-23 09:41:09 --> Input Class Initialized
INFO - 2023-11-23 09:41:09 --> Language Class Initialized
INFO - 2023-11-23 09:41:09 --> Language Class Initialized
INFO - 2023-11-23 09:41:09 --> Config Class Initialized
INFO - 2023-11-23 09:41:09 --> Loader Class Initialized
INFO - 2023-11-23 09:41:09 --> Helper loaded: url_helper
INFO - 2023-11-23 09:41:09 --> Helper loaded: file_helper
INFO - 2023-11-23 09:41:09 --> Helper loaded: form_helper
INFO - 2023-11-23 09:41:09 --> Helper loaded: my_helper
INFO - 2023-11-23 09:41:09 --> Database Driver Class Initialized
INFO - 2023-11-23 09:41:09 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-23 09:41:09 --> Controller Class Initialized
INFO - 2023-11-23 09:41:12 --> Config Class Initialized
INFO - 2023-11-23 09:41:12 --> Hooks Class Initialized
DEBUG - 2023-11-23 09:41:12 --> UTF-8 Support Enabled
INFO - 2023-11-23 09:41:12 --> Utf8 Class Initialized
INFO - 2023-11-23 09:41:12 --> URI Class Initialized
INFO - 2023-11-23 09:41:12 --> Router Class Initialized
INFO - 2023-11-23 09:41:12 --> Output Class Initialized
INFO - 2023-11-23 09:41:12 --> Security Class Initialized
DEBUG - 2023-11-23 09:41:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-23 09:41:12 --> Input Class Initialized
INFO - 2023-11-23 09:41:12 --> Language Class Initialized
INFO - 2023-11-23 09:41:12 --> Language Class Initialized
INFO - 2023-11-23 09:41:12 --> Config Class Initialized
INFO - 2023-11-23 09:41:12 --> Loader Class Initialized
INFO - 2023-11-23 09:41:12 --> Helper loaded: url_helper
INFO - 2023-11-23 09:41:12 --> Helper loaded: file_helper
INFO - 2023-11-23 09:41:12 --> Helper loaded: form_helper
INFO - 2023-11-23 09:41:12 --> Helper loaded: my_helper
INFO - 2023-11-23 09:41:12 --> Database Driver Class Initialized
INFO - 2023-11-23 09:41:12 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-23 09:41:12 --> Controller Class Initialized
INFO - 2023-11-23 09:41:12 --> Final output sent to browser
DEBUG - 2023-11-23 09:41:12 --> Total execution time: 0.0299
INFO - 2023-11-23 09:41:15 --> Config Class Initialized
INFO - 2023-11-23 09:41:15 --> Hooks Class Initialized
DEBUG - 2023-11-23 09:41:15 --> UTF-8 Support Enabled
INFO - 2023-11-23 09:41:15 --> Utf8 Class Initialized
INFO - 2023-11-23 09:41:15 --> URI Class Initialized
INFO - 2023-11-23 09:41:15 --> Router Class Initialized
INFO - 2023-11-23 09:41:15 --> Output Class Initialized
INFO - 2023-11-23 09:41:15 --> Security Class Initialized
DEBUG - 2023-11-23 09:41:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-23 09:41:15 --> Input Class Initialized
INFO - 2023-11-23 09:41:15 --> Language Class Initialized
INFO - 2023-11-23 09:41:15 --> Language Class Initialized
INFO - 2023-11-23 09:41:15 --> Config Class Initialized
INFO - 2023-11-23 09:41:15 --> Loader Class Initialized
INFO - 2023-11-23 09:41:15 --> Helper loaded: url_helper
INFO - 2023-11-23 09:41:15 --> Helper loaded: file_helper
INFO - 2023-11-23 09:41:15 --> Helper loaded: form_helper
INFO - 2023-11-23 09:41:15 --> Helper loaded: my_helper
INFO - 2023-11-23 09:41:15 --> Database Driver Class Initialized
INFO - 2023-11-23 09:41:15 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-23 09:41:15 --> Controller Class Initialized
INFO - 2023-11-23 09:41:15 --> Final output sent to browser
DEBUG - 2023-11-23 09:41:15 --> Total execution time: 0.0538
INFO - 2023-11-23 09:41:15 --> Config Class Initialized
INFO - 2023-11-23 09:41:15 --> Hooks Class Initialized
DEBUG - 2023-11-23 09:41:15 --> UTF-8 Support Enabled
INFO - 2023-11-23 09:41:15 --> Utf8 Class Initialized
INFO - 2023-11-23 09:41:15 --> URI Class Initialized
INFO - 2023-11-23 09:41:15 --> Router Class Initialized
INFO - 2023-11-23 09:41:15 --> Output Class Initialized
INFO - 2023-11-23 09:41:15 --> Security Class Initialized
DEBUG - 2023-11-23 09:41:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-23 09:41:15 --> Input Class Initialized
INFO - 2023-11-23 09:41:15 --> Language Class Initialized
INFO - 2023-11-23 09:41:15 --> Language Class Initialized
INFO - 2023-11-23 09:41:15 --> Config Class Initialized
INFO - 2023-11-23 09:41:15 --> Loader Class Initialized
INFO - 2023-11-23 09:41:15 --> Helper loaded: url_helper
INFO - 2023-11-23 09:41:15 --> Helper loaded: file_helper
INFO - 2023-11-23 09:41:15 --> Helper loaded: form_helper
INFO - 2023-11-23 09:41:15 --> Helper loaded: my_helper
INFO - 2023-11-23 09:41:15 --> Database Driver Class Initialized
INFO - 2023-11-23 09:41:15 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-23 09:41:15 --> Controller Class Initialized
INFO - 2023-11-23 09:41:18 --> Config Class Initialized
INFO - 2023-11-23 09:41:18 --> Hooks Class Initialized
DEBUG - 2023-11-23 09:41:18 --> UTF-8 Support Enabled
INFO - 2023-11-23 09:41:18 --> Utf8 Class Initialized
INFO - 2023-11-23 09:41:18 --> URI Class Initialized
INFO - 2023-11-23 09:41:18 --> Router Class Initialized
INFO - 2023-11-23 09:41:18 --> Output Class Initialized
INFO - 2023-11-23 09:41:18 --> Security Class Initialized
DEBUG - 2023-11-23 09:41:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-23 09:41:18 --> Input Class Initialized
INFO - 2023-11-23 09:41:18 --> Language Class Initialized
INFO - 2023-11-23 09:41:18 --> Language Class Initialized
INFO - 2023-11-23 09:41:18 --> Config Class Initialized
INFO - 2023-11-23 09:41:18 --> Loader Class Initialized
INFO - 2023-11-23 09:41:18 --> Helper loaded: url_helper
INFO - 2023-11-23 09:41:18 --> Helper loaded: file_helper
INFO - 2023-11-23 09:41:18 --> Helper loaded: form_helper
INFO - 2023-11-23 09:41:18 --> Helper loaded: my_helper
INFO - 2023-11-23 09:41:18 --> Database Driver Class Initialized
INFO - 2023-11-23 09:41:18 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-23 09:41:18 --> Controller Class Initialized
INFO - 2023-11-23 09:41:18 --> Final output sent to browser
DEBUG - 2023-11-23 09:41:18 --> Total execution time: 0.0334
INFO - 2023-11-23 09:41:21 --> Config Class Initialized
INFO - 2023-11-23 09:41:21 --> Hooks Class Initialized
DEBUG - 2023-11-23 09:41:21 --> UTF-8 Support Enabled
INFO - 2023-11-23 09:41:21 --> Utf8 Class Initialized
INFO - 2023-11-23 09:41:21 --> URI Class Initialized
INFO - 2023-11-23 09:41:21 --> Router Class Initialized
INFO - 2023-11-23 09:41:21 --> Output Class Initialized
INFO - 2023-11-23 09:41:21 --> Security Class Initialized
DEBUG - 2023-11-23 09:41:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-23 09:41:21 --> Input Class Initialized
INFO - 2023-11-23 09:41:21 --> Language Class Initialized
INFO - 2023-11-23 09:41:21 --> Language Class Initialized
INFO - 2023-11-23 09:41:21 --> Config Class Initialized
INFO - 2023-11-23 09:41:21 --> Loader Class Initialized
INFO - 2023-11-23 09:41:21 --> Helper loaded: url_helper
INFO - 2023-11-23 09:41:21 --> Helper loaded: file_helper
INFO - 2023-11-23 09:41:21 --> Helper loaded: form_helper
INFO - 2023-11-23 09:41:21 --> Helper loaded: my_helper
INFO - 2023-11-23 09:41:21 --> Database Driver Class Initialized
INFO - 2023-11-23 09:41:21 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-23 09:41:21 --> Controller Class Initialized
INFO - 2023-11-23 09:41:21 --> Final output sent to browser
DEBUG - 2023-11-23 09:41:21 --> Total execution time: 0.0374
INFO - 2023-11-23 09:41:21 --> Config Class Initialized
INFO - 2023-11-23 09:41:21 --> Hooks Class Initialized
DEBUG - 2023-11-23 09:41:21 --> UTF-8 Support Enabled
INFO - 2023-11-23 09:41:21 --> Utf8 Class Initialized
INFO - 2023-11-23 09:41:21 --> URI Class Initialized
INFO - 2023-11-23 09:41:21 --> Router Class Initialized
INFO - 2023-11-23 09:41:21 --> Output Class Initialized
INFO - 2023-11-23 09:41:21 --> Security Class Initialized
DEBUG - 2023-11-23 09:41:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-23 09:41:21 --> Input Class Initialized
INFO - 2023-11-23 09:41:21 --> Language Class Initialized
INFO - 2023-11-23 09:41:21 --> Language Class Initialized
INFO - 2023-11-23 09:41:21 --> Config Class Initialized
INFO - 2023-11-23 09:41:21 --> Loader Class Initialized
INFO - 2023-11-23 09:41:21 --> Helper loaded: url_helper
INFO - 2023-11-23 09:41:21 --> Helper loaded: file_helper
INFO - 2023-11-23 09:41:21 --> Helper loaded: form_helper
INFO - 2023-11-23 09:41:21 --> Helper loaded: my_helper
INFO - 2023-11-23 09:41:21 --> Database Driver Class Initialized
INFO - 2023-11-23 09:41:21 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-23 09:41:21 --> Controller Class Initialized
INFO - 2023-11-23 09:41:25 --> Config Class Initialized
INFO - 2023-11-23 09:41:25 --> Hooks Class Initialized
DEBUG - 2023-11-23 09:41:25 --> UTF-8 Support Enabled
INFO - 2023-11-23 09:41:25 --> Utf8 Class Initialized
INFO - 2023-11-23 09:41:25 --> URI Class Initialized
INFO - 2023-11-23 09:41:25 --> Router Class Initialized
INFO - 2023-11-23 09:41:25 --> Output Class Initialized
INFO - 2023-11-23 09:41:25 --> Security Class Initialized
DEBUG - 2023-11-23 09:41:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-23 09:41:25 --> Input Class Initialized
INFO - 2023-11-23 09:41:25 --> Language Class Initialized
INFO - 2023-11-23 09:41:25 --> Language Class Initialized
INFO - 2023-11-23 09:41:25 --> Config Class Initialized
INFO - 2023-11-23 09:41:25 --> Loader Class Initialized
INFO - 2023-11-23 09:41:25 --> Helper loaded: url_helper
INFO - 2023-11-23 09:41:25 --> Helper loaded: file_helper
INFO - 2023-11-23 09:41:25 --> Helper loaded: form_helper
INFO - 2023-11-23 09:41:25 --> Helper loaded: my_helper
INFO - 2023-11-23 09:41:25 --> Database Driver Class Initialized
INFO - 2023-11-23 09:41:25 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-23 09:41:25 --> Controller Class Initialized
INFO - 2023-11-23 09:41:25 --> Final output sent to browser
DEBUG - 2023-11-23 09:41:25 --> Total execution time: 0.0337
INFO - 2023-11-23 09:41:29 --> Config Class Initialized
INFO - 2023-11-23 09:41:29 --> Hooks Class Initialized
DEBUG - 2023-11-23 09:41:29 --> UTF-8 Support Enabled
INFO - 2023-11-23 09:41:29 --> Utf8 Class Initialized
INFO - 2023-11-23 09:41:29 --> URI Class Initialized
INFO - 2023-11-23 09:41:29 --> Router Class Initialized
INFO - 2023-11-23 09:41:29 --> Output Class Initialized
INFO - 2023-11-23 09:41:29 --> Security Class Initialized
DEBUG - 2023-11-23 09:41:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-23 09:41:29 --> Input Class Initialized
INFO - 2023-11-23 09:41:29 --> Language Class Initialized
INFO - 2023-11-23 09:41:29 --> Language Class Initialized
INFO - 2023-11-23 09:41:29 --> Config Class Initialized
INFO - 2023-11-23 09:41:29 --> Loader Class Initialized
INFO - 2023-11-23 09:41:29 --> Helper loaded: url_helper
INFO - 2023-11-23 09:41:29 --> Helper loaded: file_helper
INFO - 2023-11-23 09:41:29 --> Helper loaded: form_helper
INFO - 2023-11-23 09:41:29 --> Helper loaded: my_helper
INFO - 2023-11-23 09:41:29 --> Database Driver Class Initialized
INFO - 2023-11-23 09:41:29 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-23 09:41:29 --> Controller Class Initialized
INFO - 2023-11-23 09:41:29 --> Final output sent to browser
DEBUG - 2023-11-23 09:41:29 --> Total execution time: 0.1084
INFO - 2023-11-23 09:41:29 --> Config Class Initialized
INFO - 2023-11-23 09:41:29 --> Hooks Class Initialized
DEBUG - 2023-11-23 09:41:29 --> UTF-8 Support Enabled
INFO - 2023-11-23 09:41:29 --> Utf8 Class Initialized
INFO - 2023-11-23 09:41:29 --> URI Class Initialized
INFO - 2023-11-23 09:41:29 --> Router Class Initialized
INFO - 2023-11-23 09:41:29 --> Output Class Initialized
INFO - 2023-11-23 09:41:29 --> Security Class Initialized
DEBUG - 2023-11-23 09:41:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-23 09:41:29 --> Input Class Initialized
INFO - 2023-11-23 09:41:29 --> Language Class Initialized
INFO - 2023-11-23 09:41:29 --> Language Class Initialized
INFO - 2023-11-23 09:41:29 --> Config Class Initialized
INFO - 2023-11-23 09:41:29 --> Loader Class Initialized
INFO - 2023-11-23 09:41:30 --> Helper loaded: url_helper
INFO - 2023-11-23 09:41:30 --> Helper loaded: file_helper
INFO - 2023-11-23 09:41:30 --> Helper loaded: form_helper
INFO - 2023-11-23 09:41:30 --> Helper loaded: my_helper
INFO - 2023-11-23 09:41:30 --> Database Driver Class Initialized
INFO - 2023-11-23 09:41:30 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-23 09:41:30 --> Controller Class Initialized
INFO - 2023-11-23 09:41:33 --> Config Class Initialized
INFO - 2023-11-23 09:41:33 --> Hooks Class Initialized
DEBUG - 2023-11-23 09:41:33 --> UTF-8 Support Enabled
INFO - 2023-11-23 09:41:33 --> Utf8 Class Initialized
INFO - 2023-11-23 09:41:33 --> URI Class Initialized
INFO - 2023-11-23 09:41:33 --> Router Class Initialized
INFO - 2023-11-23 09:41:33 --> Output Class Initialized
INFO - 2023-11-23 09:41:33 --> Security Class Initialized
DEBUG - 2023-11-23 09:41:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-23 09:41:33 --> Input Class Initialized
INFO - 2023-11-23 09:41:33 --> Language Class Initialized
INFO - 2023-11-23 09:41:33 --> Language Class Initialized
INFO - 2023-11-23 09:41:33 --> Config Class Initialized
INFO - 2023-11-23 09:41:33 --> Loader Class Initialized
INFO - 2023-11-23 09:41:33 --> Helper loaded: url_helper
INFO - 2023-11-23 09:41:33 --> Helper loaded: file_helper
INFO - 2023-11-23 09:41:33 --> Helper loaded: form_helper
INFO - 2023-11-23 09:41:33 --> Helper loaded: my_helper
INFO - 2023-11-23 09:41:33 --> Database Driver Class Initialized
INFO - 2023-11-23 09:41:33 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-23 09:41:33 --> Controller Class Initialized
INFO - 2023-11-23 09:41:33 --> Final output sent to browser
DEBUG - 2023-11-23 09:41:33 --> Total execution time: 0.0406
INFO - 2023-11-23 09:46:42 --> Config Class Initialized
INFO - 2023-11-23 09:46:42 --> Hooks Class Initialized
DEBUG - 2023-11-23 09:46:42 --> UTF-8 Support Enabled
INFO - 2023-11-23 09:46:42 --> Utf8 Class Initialized
INFO - 2023-11-23 09:46:42 --> URI Class Initialized
INFO - 2023-11-23 09:46:42 --> Router Class Initialized
INFO - 2023-11-23 09:46:42 --> Output Class Initialized
INFO - 2023-11-23 09:46:42 --> Security Class Initialized
DEBUG - 2023-11-23 09:46:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-23 09:46:42 --> Input Class Initialized
INFO - 2023-11-23 09:46:42 --> Language Class Initialized
INFO - 2023-11-23 09:46:42 --> Language Class Initialized
INFO - 2023-11-23 09:46:42 --> Config Class Initialized
INFO - 2023-11-23 09:46:42 --> Loader Class Initialized
INFO - 2023-11-23 09:46:42 --> Helper loaded: url_helper
INFO - 2023-11-23 09:46:42 --> Helper loaded: file_helper
INFO - 2023-11-23 09:46:42 --> Helper loaded: form_helper
INFO - 2023-11-23 09:46:42 --> Helper loaded: my_helper
INFO - 2023-11-23 09:46:42 --> Database Driver Class Initialized
INFO - 2023-11-23 09:46:42 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-23 09:46:42 --> Controller Class Initialized
INFO - 2023-11-23 09:46:42 --> Final output sent to browser
DEBUG - 2023-11-23 09:46:42 --> Total execution time: 0.1791
INFO - 2023-11-23 09:46:43 --> Config Class Initialized
INFO - 2023-11-23 09:46:43 --> Hooks Class Initialized
DEBUG - 2023-11-23 09:46:43 --> UTF-8 Support Enabled
INFO - 2023-11-23 09:46:43 --> Utf8 Class Initialized
INFO - 2023-11-23 09:46:43 --> URI Class Initialized
INFO - 2023-11-23 09:46:43 --> Router Class Initialized
INFO - 2023-11-23 09:46:43 --> Output Class Initialized
INFO - 2023-11-23 09:46:43 --> Security Class Initialized
DEBUG - 2023-11-23 09:46:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-23 09:46:43 --> Input Class Initialized
INFO - 2023-11-23 09:46:43 --> Language Class Initialized
INFO - 2023-11-23 09:46:43 --> Language Class Initialized
INFO - 2023-11-23 09:46:43 --> Config Class Initialized
INFO - 2023-11-23 09:46:43 --> Loader Class Initialized
INFO - 2023-11-23 09:46:43 --> Helper loaded: url_helper
INFO - 2023-11-23 09:46:43 --> Helper loaded: file_helper
INFO - 2023-11-23 09:46:43 --> Helper loaded: form_helper
INFO - 2023-11-23 09:46:43 --> Helper loaded: my_helper
INFO - 2023-11-23 09:46:43 --> Database Driver Class Initialized
INFO - 2023-11-23 09:46:43 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-23 09:46:43 --> Controller Class Initialized
INFO - 2023-11-23 09:46:46 --> Config Class Initialized
INFO - 2023-11-23 09:46:46 --> Hooks Class Initialized
DEBUG - 2023-11-23 09:46:46 --> UTF-8 Support Enabled
INFO - 2023-11-23 09:46:46 --> Utf8 Class Initialized
INFO - 2023-11-23 09:46:46 --> URI Class Initialized
INFO - 2023-11-23 09:46:46 --> Router Class Initialized
INFO - 2023-11-23 09:46:46 --> Output Class Initialized
INFO - 2023-11-23 09:46:46 --> Security Class Initialized
DEBUG - 2023-11-23 09:46:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-23 09:46:46 --> Input Class Initialized
INFO - 2023-11-23 09:46:46 --> Language Class Initialized
INFO - 2023-11-23 09:46:46 --> Language Class Initialized
INFO - 2023-11-23 09:46:46 --> Config Class Initialized
INFO - 2023-11-23 09:46:46 --> Loader Class Initialized
INFO - 2023-11-23 09:46:46 --> Helper loaded: url_helper
INFO - 2023-11-23 09:46:46 --> Helper loaded: file_helper
INFO - 2023-11-23 09:46:46 --> Helper loaded: form_helper
INFO - 2023-11-23 09:46:46 --> Helper loaded: my_helper
INFO - 2023-11-23 09:46:46 --> Database Driver Class Initialized
INFO - 2023-11-23 09:46:46 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-23 09:46:46 --> Controller Class Initialized
INFO - 2023-11-23 09:46:46 --> Final output sent to browser
DEBUG - 2023-11-23 09:46:46 --> Total execution time: 0.0389
INFO - 2023-11-23 09:48:03 --> Config Class Initialized
INFO - 2023-11-23 09:48:03 --> Hooks Class Initialized
DEBUG - 2023-11-23 09:48:03 --> UTF-8 Support Enabled
INFO - 2023-11-23 09:48:03 --> Utf8 Class Initialized
INFO - 2023-11-23 09:48:03 --> URI Class Initialized
INFO - 2023-11-23 09:48:03 --> Router Class Initialized
INFO - 2023-11-23 09:48:03 --> Output Class Initialized
INFO - 2023-11-23 09:48:03 --> Security Class Initialized
DEBUG - 2023-11-23 09:48:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-23 09:48:03 --> Input Class Initialized
INFO - 2023-11-23 09:48:03 --> Language Class Initialized
INFO - 2023-11-23 09:48:03 --> Language Class Initialized
INFO - 2023-11-23 09:48:03 --> Config Class Initialized
INFO - 2023-11-23 09:48:03 --> Loader Class Initialized
INFO - 2023-11-23 09:48:03 --> Helper loaded: url_helper
INFO - 2023-11-23 09:48:03 --> Helper loaded: file_helper
INFO - 2023-11-23 09:48:03 --> Helper loaded: form_helper
INFO - 2023-11-23 09:48:03 --> Helper loaded: my_helper
INFO - 2023-11-23 09:48:03 --> Database Driver Class Initialized
INFO - 2023-11-23 09:48:03 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-23 09:48:03 --> Controller Class Initialized
INFO - 2023-11-23 09:48:03 --> Final output sent to browser
DEBUG - 2023-11-23 09:48:03 --> Total execution time: 0.1063
INFO - 2023-11-23 09:48:03 --> Config Class Initialized
INFO - 2023-11-23 09:48:03 --> Hooks Class Initialized
DEBUG - 2023-11-23 09:48:03 --> UTF-8 Support Enabled
INFO - 2023-11-23 09:48:03 --> Utf8 Class Initialized
INFO - 2023-11-23 09:48:03 --> URI Class Initialized
INFO - 2023-11-23 09:48:03 --> Router Class Initialized
INFO - 2023-11-23 09:48:03 --> Output Class Initialized
INFO - 2023-11-23 09:48:03 --> Security Class Initialized
DEBUG - 2023-11-23 09:48:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-23 09:48:03 --> Input Class Initialized
INFO - 2023-11-23 09:48:03 --> Language Class Initialized
INFO - 2023-11-23 09:48:03 --> Language Class Initialized
INFO - 2023-11-23 09:48:03 --> Config Class Initialized
INFO - 2023-11-23 09:48:03 --> Loader Class Initialized
INFO - 2023-11-23 09:48:03 --> Helper loaded: url_helper
INFO - 2023-11-23 09:48:03 --> Helper loaded: file_helper
INFO - 2023-11-23 09:48:03 --> Helper loaded: form_helper
INFO - 2023-11-23 09:48:03 --> Helper loaded: my_helper
INFO - 2023-11-23 09:48:03 --> Database Driver Class Initialized
INFO - 2023-11-23 09:48:03 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-23 09:48:03 --> Controller Class Initialized
INFO - 2023-11-23 09:48:06 --> Config Class Initialized
INFO - 2023-11-23 09:48:06 --> Hooks Class Initialized
DEBUG - 2023-11-23 09:48:06 --> UTF-8 Support Enabled
INFO - 2023-11-23 09:48:06 --> Utf8 Class Initialized
INFO - 2023-11-23 09:48:06 --> URI Class Initialized
INFO - 2023-11-23 09:48:06 --> Router Class Initialized
INFO - 2023-11-23 09:48:06 --> Output Class Initialized
INFO - 2023-11-23 09:48:06 --> Security Class Initialized
DEBUG - 2023-11-23 09:48:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-23 09:48:06 --> Input Class Initialized
INFO - 2023-11-23 09:48:06 --> Language Class Initialized
INFO - 2023-11-23 09:48:06 --> Language Class Initialized
INFO - 2023-11-23 09:48:06 --> Config Class Initialized
INFO - 2023-11-23 09:48:06 --> Loader Class Initialized
INFO - 2023-11-23 09:48:06 --> Helper loaded: url_helper
INFO - 2023-11-23 09:48:06 --> Helper loaded: file_helper
INFO - 2023-11-23 09:48:06 --> Helper loaded: form_helper
INFO - 2023-11-23 09:48:06 --> Helper loaded: my_helper
INFO - 2023-11-23 09:48:06 --> Database Driver Class Initialized
INFO - 2023-11-23 09:48:06 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-23 09:48:06 --> Controller Class Initialized
INFO - 2023-11-23 09:48:06 --> Final output sent to browser
DEBUG - 2023-11-23 09:48:06 --> Total execution time: 0.0609
INFO - 2023-11-23 09:49:51 --> Config Class Initialized
INFO - 2023-11-23 09:49:51 --> Hooks Class Initialized
DEBUG - 2023-11-23 09:49:51 --> UTF-8 Support Enabled
INFO - 2023-11-23 09:49:51 --> Utf8 Class Initialized
INFO - 2023-11-23 09:49:51 --> URI Class Initialized
INFO - 2023-11-23 09:49:51 --> Router Class Initialized
INFO - 2023-11-23 09:49:51 --> Output Class Initialized
INFO - 2023-11-23 09:49:51 --> Security Class Initialized
DEBUG - 2023-11-23 09:49:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-23 09:49:51 --> Input Class Initialized
INFO - 2023-11-23 09:49:51 --> Language Class Initialized
INFO - 2023-11-23 09:49:51 --> Language Class Initialized
INFO - 2023-11-23 09:49:51 --> Config Class Initialized
INFO - 2023-11-23 09:49:51 --> Loader Class Initialized
INFO - 2023-11-23 09:49:51 --> Helper loaded: url_helper
INFO - 2023-11-23 09:49:51 --> Helper loaded: file_helper
INFO - 2023-11-23 09:49:51 --> Helper loaded: form_helper
INFO - 2023-11-23 09:49:51 --> Helper loaded: my_helper
INFO - 2023-11-23 09:49:51 --> Database Driver Class Initialized
INFO - 2023-11-23 09:49:51 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-23 09:49:51 --> Controller Class Initialized
INFO - 2023-11-23 09:49:51 --> Final output sent to browser
DEBUG - 2023-11-23 09:49:51 --> Total execution time: 0.0652
INFO - 2023-11-23 09:50:27 --> Config Class Initialized
INFO - 2023-11-23 09:50:27 --> Hooks Class Initialized
DEBUG - 2023-11-23 09:50:27 --> UTF-8 Support Enabled
INFO - 2023-11-23 09:50:27 --> Utf8 Class Initialized
INFO - 2023-11-23 09:50:27 --> URI Class Initialized
INFO - 2023-11-23 09:50:27 --> Router Class Initialized
INFO - 2023-11-23 09:50:27 --> Output Class Initialized
INFO - 2023-11-23 09:50:27 --> Security Class Initialized
DEBUG - 2023-11-23 09:50:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-23 09:50:27 --> Input Class Initialized
INFO - 2023-11-23 09:50:27 --> Language Class Initialized
INFO - 2023-11-23 09:50:27 --> Language Class Initialized
INFO - 2023-11-23 09:50:27 --> Config Class Initialized
INFO - 2023-11-23 09:50:27 --> Loader Class Initialized
INFO - 2023-11-23 09:50:27 --> Helper loaded: url_helper
INFO - 2023-11-23 09:50:27 --> Helper loaded: file_helper
INFO - 2023-11-23 09:50:27 --> Helper loaded: form_helper
INFO - 2023-11-23 09:50:27 --> Helper loaded: my_helper
INFO - 2023-11-23 09:50:27 --> Database Driver Class Initialized
INFO - 2023-11-23 09:50:27 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-23 09:50:27 --> Controller Class Initialized
INFO - 2023-11-23 09:50:27 --> Final output sent to browser
DEBUG - 2023-11-23 09:50:27 --> Total execution time: 0.0731
INFO - 2023-11-23 09:51:11 --> Config Class Initialized
INFO - 2023-11-23 09:51:11 --> Hooks Class Initialized
DEBUG - 2023-11-23 09:51:11 --> UTF-8 Support Enabled
INFO - 2023-11-23 09:51:11 --> Utf8 Class Initialized
INFO - 2023-11-23 09:51:11 --> URI Class Initialized
INFO - 2023-11-23 09:51:11 --> Router Class Initialized
INFO - 2023-11-23 09:51:11 --> Output Class Initialized
INFO - 2023-11-23 09:51:11 --> Security Class Initialized
DEBUG - 2023-11-23 09:51:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-23 09:51:11 --> Input Class Initialized
INFO - 2023-11-23 09:51:11 --> Language Class Initialized
INFO - 2023-11-23 09:51:11 --> Language Class Initialized
INFO - 2023-11-23 09:51:11 --> Config Class Initialized
INFO - 2023-11-23 09:51:11 --> Loader Class Initialized
INFO - 2023-11-23 09:51:11 --> Helper loaded: url_helper
INFO - 2023-11-23 09:51:11 --> Helper loaded: file_helper
INFO - 2023-11-23 09:51:11 --> Helper loaded: form_helper
INFO - 2023-11-23 09:51:11 --> Helper loaded: my_helper
INFO - 2023-11-23 09:51:11 --> Database Driver Class Initialized
INFO - 2023-11-23 09:51:11 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-23 09:51:11 --> Controller Class Initialized
INFO - 2023-11-23 09:51:11 --> Final output sent to browser
DEBUG - 2023-11-23 09:51:11 --> Total execution time: 0.0340
INFO - 2023-11-23 09:51:11 --> Config Class Initialized
INFO - 2023-11-23 09:51:11 --> Hooks Class Initialized
DEBUG - 2023-11-23 09:51:11 --> UTF-8 Support Enabled
INFO - 2023-11-23 09:51:11 --> Utf8 Class Initialized
INFO - 2023-11-23 09:51:11 --> URI Class Initialized
INFO - 2023-11-23 09:51:11 --> Router Class Initialized
INFO - 2023-11-23 09:51:11 --> Output Class Initialized
INFO - 2023-11-23 09:51:11 --> Security Class Initialized
DEBUG - 2023-11-23 09:51:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-23 09:51:11 --> Input Class Initialized
INFO - 2023-11-23 09:51:11 --> Language Class Initialized
INFO - 2023-11-23 09:51:11 --> Language Class Initialized
INFO - 2023-11-23 09:51:11 --> Config Class Initialized
INFO - 2023-11-23 09:51:11 --> Loader Class Initialized
INFO - 2023-11-23 09:51:11 --> Helper loaded: url_helper
INFO - 2023-11-23 09:51:11 --> Helper loaded: file_helper
INFO - 2023-11-23 09:51:11 --> Helper loaded: form_helper
INFO - 2023-11-23 09:51:11 --> Helper loaded: my_helper
INFO - 2023-11-23 09:51:11 --> Database Driver Class Initialized
INFO - 2023-11-23 09:51:11 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-23 09:51:11 --> Controller Class Initialized
INFO - 2023-11-23 09:53:27 --> Config Class Initialized
INFO - 2023-11-23 09:53:27 --> Hooks Class Initialized
DEBUG - 2023-11-23 09:53:27 --> UTF-8 Support Enabled
INFO - 2023-11-23 09:53:27 --> Utf8 Class Initialized
INFO - 2023-11-23 09:53:27 --> URI Class Initialized
INFO - 2023-11-23 09:53:27 --> Router Class Initialized
INFO - 2023-11-23 09:53:27 --> Output Class Initialized
INFO - 2023-11-23 09:53:27 --> Security Class Initialized
DEBUG - 2023-11-23 09:53:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-23 09:53:27 --> Input Class Initialized
INFO - 2023-11-23 09:53:27 --> Language Class Initialized
INFO - 2023-11-23 09:53:27 --> Language Class Initialized
INFO - 2023-11-23 09:53:27 --> Config Class Initialized
INFO - 2023-11-23 09:53:27 --> Loader Class Initialized
INFO - 2023-11-23 09:53:27 --> Helper loaded: url_helper
INFO - 2023-11-23 09:53:27 --> Helper loaded: file_helper
INFO - 2023-11-23 09:53:27 --> Helper loaded: form_helper
INFO - 2023-11-23 09:53:27 --> Helper loaded: my_helper
INFO - 2023-11-23 09:53:27 --> Database Driver Class Initialized
INFO - 2023-11-23 09:53:27 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-23 09:53:27 --> Controller Class Initialized
INFO - 2023-11-23 09:53:27 --> Final output sent to browser
DEBUG - 2023-11-23 09:53:27 --> Total execution time: 0.0501
INFO - 2023-11-23 10:15:55 --> Config Class Initialized
INFO - 2023-11-23 10:15:55 --> Hooks Class Initialized
DEBUG - 2023-11-23 10:15:55 --> UTF-8 Support Enabled
INFO - 2023-11-23 10:15:55 --> Utf8 Class Initialized
INFO - 2023-11-23 10:15:55 --> URI Class Initialized
INFO - 2023-11-23 10:15:55 --> Router Class Initialized
INFO - 2023-11-23 10:15:55 --> Output Class Initialized
INFO - 2023-11-23 10:15:55 --> Security Class Initialized
DEBUG - 2023-11-23 10:15:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-23 10:15:55 --> Input Class Initialized
INFO - 2023-11-23 10:15:55 --> Language Class Initialized
INFO - 2023-11-23 10:15:55 --> Language Class Initialized
INFO - 2023-11-23 10:15:55 --> Config Class Initialized
INFO - 2023-11-23 10:15:55 --> Loader Class Initialized
INFO - 2023-11-23 10:15:55 --> Helper loaded: url_helper
INFO - 2023-11-23 10:15:55 --> Helper loaded: file_helper
INFO - 2023-11-23 10:15:55 --> Helper loaded: form_helper
INFO - 2023-11-23 10:15:55 --> Helper loaded: my_helper
INFO - 2023-11-23 10:15:55 --> Database Driver Class Initialized
INFO - 2023-11-23 10:15:55 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-23 10:15:55 --> Controller Class Initialized
INFO - 2023-11-23 10:15:55 --> Config Class Initialized
INFO - 2023-11-23 10:15:55 --> Hooks Class Initialized
DEBUG - 2023-11-23 10:15:55 --> UTF-8 Support Enabled
INFO - 2023-11-23 10:15:55 --> Utf8 Class Initialized
INFO - 2023-11-23 10:15:55 --> URI Class Initialized
INFO - 2023-11-23 10:15:55 --> Router Class Initialized
INFO - 2023-11-23 10:15:55 --> Output Class Initialized
INFO - 2023-11-23 10:15:55 --> Security Class Initialized
DEBUG - 2023-11-23 10:15:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-23 10:15:55 --> Input Class Initialized
INFO - 2023-11-23 10:15:55 --> Language Class Initialized
INFO - 2023-11-23 10:15:55 --> Language Class Initialized
INFO - 2023-11-23 10:15:55 --> Config Class Initialized
INFO - 2023-11-23 10:15:55 --> Loader Class Initialized
INFO - 2023-11-23 10:15:55 --> Helper loaded: url_helper
INFO - 2023-11-23 10:15:55 --> Helper loaded: file_helper
INFO - 2023-11-23 10:15:55 --> Helper loaded: form_helper
INFO - 2023-11-23 10:15:55 --> Helper loaded: my_helper
INFO - 2023-11-23 10:15:55 --> Database Driver Class Initialized
INFO - 2023-11-23 10:15:55 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-23 10:15:55 --> Controller Class Initialized
DEBUG - 2023-11-23 10:15:55 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/login/views/login.php
DEBUG - 2023-11-23 10:15:55 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-11-23 10:15:55 --> Final output sent to browser
DEBUG - 2023-11-23 10:15:55 --> Total execution time: 0.0350
INFO - 2023-11-23 10:16:05 --> Config Class Initialized
INFO - 2023-11-23 10:16:05 --> Hooks Class Initialized
DEBUG - 2023-11-23 10:16:05 --> UTF-8 Support Enabled
INFO - 2023-11-23 10:16:05 --> Utf8 Class Initialized
INFO - 2023-11-23 10:16:05 --> URI Class Initialized
INFO - 2023-11-23 10:16:05 --> Router Class Initialized
INFO - 2023-11-23 10:16:05 --> Output Class Initialized
INFO - 2023-11-23 10:16:05 --> Security Class Initialized
DEBUG - 2023-11-23 10:16:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-23 10:16:05 --> Input Class Initialized
INFO - 2023-11-23 10:16:05 --> Language Class Initialized
INFO - 2023-11-23 10:16:05 --> Language Class Initialized
INFO - 2023-11-23 10:16:05 --> Config Class Initialized
INFO - 2023-11-23 10:16:05 --> Loader Class Initialized
INFO - 2023-11-23 10:16:05 --> Helper loaded: url_helper
INFO - 2023-11-23 10:16:05 --> Helper loaded: file_helper
INFO - 2023-11-23 10:16:05 --> Helper loaded: form_helper
INFO - 2023-11-23 10:16:05 --> Helper loaded: my_helper
INFO - 2023-11-23 10:16:05 --> Database Driver Class Initialized
INFO - 2023-11-23 10:16:05 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-23 10:16:05 --> Controller Class Initialized
INFO - 2023-11-23 10:16:05 --> Helper loaded: cookie_helper
INFO - 2023-11-23 10:16:05 --> Final output sent to browser
DEBUG - 2023-11-23 10:16:05 --> Total execution time: 0.2811
INFO - 2023-11-23 10:16:06 --> Config Class Initialized
INFO - 2023-11-23 10:16:06 --> Hooks Class Initialized
DEBUG - 2023-11-23 10:16:06 --> UTF-8 Support Enabled
INFO - 2023-11-23 10:16:06 --> Utf8 Class Initialized
INFO - 2023-11-23 10:16:06 --> URI Class Initialized
INFO - 2023-11-23 10:16:06 --> Router Class Initialized
INFO - 2023-11-23 10:16:06 --> Output Class Initialized
INFO - 2023-11-23 10:16:06 --> Security Class Initialized
DEBUG - 2023-11-23 10:16:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-23 10:16:06 --> Input Class Initialized
INFO - 2023-11-23 10:16:06 --> Language Class Initialized
INFO - 2023-11-23 10:16:06 --> Language Class Initialized
INFO - 2023-11-23 10:16:06 --> Config Class Initialized
INFO - 2023-11-23 10:16:06 --> Loader Class Initialized
INFO - 2023-11-23 10:16:06 --> Helper loaded: url_helper
INFO - 2023-11-23 10:16:06 --> Helper loaded: file_helper
INFO - 2023-11-23 10:16:06 --> Helper loaded: form_helper
INFO - 2023-11-23 10:16:06 --> Helper loaded: my_helper
INFO - 2023-11-23 10:16:06 --> Database Driver Class Initialized
INFO - 2023-11-23 10:16:06 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-23 10:16:06 --> Controller Class Initialized
DEBUG - 2023-11-23 10:16:06 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/home/views/v_home_guru.php
DEBUG - 2023-11-23 10:16:06 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-11-23 10:16:06 --> Final output sent to browser
DEBUG - 2023-11-23 10:16:06 --> Total execution time: 0.0517
INFO - 2023-11-23 10:16:36 --> Config Class Initialized
INFO - 2023-11-23 10:16:36 --> Hooks Class Initialized
DEBUG - 2023-11-23 10:16:36 --> UTF-8 Support Enabled
INFO - 2023-11-23 10:16:36 --> Utf8 Class Initialized
INFO - 2023-11-23 10:16:36 --> URI Class Initialized
INFO - 2023-11-23 10:16:36 --> Router Class Initialized
INFO - 2023-11-23 10:16:36 --> Output Class Initialized
INFO - 2023-11-23 10:16:36 --> Security Class Initialized
DEBUG - 2023-11-23 10:16:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-23 10:16:36 --> Input Class Initialized
INFO - 2023-11-23 10:16:36 --> Language Class Initialized
INFO - 2023-11-23 10:16:36 --> Language Class Initialized
INFO - 2023-11-23 10:16:36 --> Config Class Initialized
INFO - 2023-11-23 10:16:36 --> Loader Class Initialized
INFO - 2023-11-23 10:16:36 --> Helper loaded: url_helper
INFO - 2023-11-23 10:16:36 --> Helper loaded: file_helper
INFO - 2023-11-23 10:16:36 --> Helper loaded: form_helper
INFO - 2023-11-23 10:16:36 --> Helper loaded: my_helper
INFO - 2023-11-23 10:16:36 --> Database Driver Class Initialized
INFO - 2023-11-23 10:16:36 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-23 10:16:36 --> Controller Class Initialized
DEBUG - 2023-11-23 10:16:36 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/view_mapel/views/v_view_mapel.php
DEBUG - 2023-11-23 10:16:36 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-11-23 10:16:36 --> Final output sent to browser
DEBUG - 2023-11-23 10:16:36 --> Total execution time: 0.0902
INFO - 2023-11-23 10:16:41 --> Config Class Initialized
INFO - 2023-11-23 10:16:41 --> Hooks Class Initialized
DEBUG - 2023-11-23 10:16:41 --> UTF-8 Support Enabled
INFO - 2023-11-23 10:16:41 --> Utf8 Class Initialized
INFO - 2023-11-23 10:16:41 --> URI Class Initialized
INFO - 2023-11-23 10:16:41 --> Router Class Initialized
INFO - 2023-11-23 10:16:41 --> Output Class Initialized
INFO - 2023-11-23 10:16:41 --> Security Class Initialized
DEBUG - 2023-11-23 10:16:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-23 10:16:41 --> Input Class Initialized
INFO - 2023-11-23 10:16:41 --> Language Class Initialized
INFO - 2023-11-23 10:16:41 --> Language Class Initialized
INFO - 2023-11-23 10:16:41 --> Config Class Initialized
INFO - 2023-11-23 10:16:41 --> Loader Class Initialized
INFO - 2023-11-23 10:16:41 --> Helper loaded: url_helper
INFO - 2023-11-23 10:16:41 --> Helper loaded: file_helper
INFO - 2023-11-23 10:16:41 --> Helper loaded: form_helper
INFO - 2023-11-23 10:16:41 --> Helper loaded: my_helper
INFO - 2023-11-23 10:16:41 --> Database Driver Class Initialized
INFO - 2023-11-23 10:16:41 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-23 10:16:41 --> Controller Class Initialized
DEBUG - 2023-11-23 10:16:41 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/views/list.php
DEBUG - 2023-11-23 10:16:41 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-11-23 10:16:41 --> Final output sent to browser
DEBUG - 2023-11-23 10:16:41 --> Total execution time: 0.0418
INFO - 2023-11-23 10:16:41 --> Config Class Initialized
INFO - 2023-11-23 10:16:41 --> Hooks Class Initialized
DEBUG - 2023-11-23 10:16:41 --> UTF-8 Support Enabled
INFO - 2023-11-23 10:16:41 --> Utf8 Class Initialized
INFO - 2023-11-23 10:16:41 --> URI Class Initialized
INFO - 2023-11-23 10:16:41 --> Router Class Initialized
INFO - 2023-11-23 10:16:41 --> Output Class Initialized
INFO - 2023-11-23 10:16:41 --> Security Class Initialized
DEBUG - 2023-11-23 10:16:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-23 10:16:41 --> Input Class Initialized
INFO - 2023-11-23 10:16:41 --> Language Class Initialized
INFO - 2023-11-23 10:16:41 --> Language Class Initialized
INFO - 2023-11-23 10:16:41 --> Config Class Initialized
INFO - 2023-11-23 10:16:41 --> Loader Class Initialized
INFO - 2023-11-23 10:16:41 --> Helper loaded: url_helper
INFO - 2023-11-23 10:16:41 --> Helper loaded: file_helper
INFO - 2023-11-23 10:16:41 --> Helper loaded: form_helper
INFO - 2023-11-23 10:16:41 --> Helper loaded: my_helper
INFO - 2023-11-23 10:16:41 --> Database Driver Class Initialized
INFO - 2023-11-23 10:16:41 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-23 10:16:41 --> Controller Class Initialized
INFO - 2023-11-23 10:16:46 --> Config Class Initialized
INFO - 2023-11-23 10:16:46 --> Hooks Class Initialized
DEBUG - 2023-11-23 10:16:46 --> UTF-8 Support Enabled
INFO - 2023-11-23 10:16:46 --> Utf8 Class Initialized
INFO - 2023-11-23 10:16:46 --> URI Class Initialized
INFO - 2023-11-23 10:16:46 --> Router Class Initialized
INFO - 2023-11-23 10:16:46 --> Output Class Initialized
INFO - 2023-11-23 10:16:46 --> Security Class Initialized
DEBUG - 2023-11-23 10:16:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-23 10:16:46 --> Input Class Initialized
INFO - 2023-11-23 10:16:46 --> Language Class Initialized
INFO - 2023-11-23 10:16:46 --> Language Class Initialized
INFO - 2023-11-23 10:16:46 --> Config Class Initialized
INFO - 2023-11-23 10:16:46 --> Loader Class Initialized
INFO - 2023-11-23 10:16:46 --> Helper loaded: url_helper
INFO - 2023-11-23 10:16:46 --> Helper loaded: file_helper
INFO - 2023-11-23 10:16:46 --> Helper loaded: form_helper
INFO - 2023-11-23 10:16:46 --> Helper loaded: my_helper
INFO - 2023-11-23 10:16:46 --> Database Driver Class Initialized
INFO - 2023-11-23 10:16:46 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-23 10:16:46 --> Controller Class Initialized
INFO - 2023-11-23 10:16:46 --> Final output sent to browser
DEBUG - 2023-11-23 10:16:46 --> Total execution time: 0.0595
INFO - 2023-11-23 10:17:26 --> Config Class Initialized
INFO - 2023-11-23 10:17:26 --> Hooks Class Initialized
DEBUG - 2023-11-23 10:17:26 --> UTF-8 Support Enabled
INFO - 2023-11-23 10:17:26 --> Utf8 Class Initialized
INFO - 2023-11-23 10:17:26 --> URI Class Initialized
INFO - 2023-11-23 10:17:26 --> Router Class Initialized
INFO - 2023-11-23 10:17:26 --> Output Class Initialized
INFO - 2023-11-23 10:17:26 --> Security Class Initialized
DEBUG - 2023-11-23 10:17:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-23 10:17:26 --> Input Class Initialized
INFO - 2023-11-23 10:17:26 --> Language Class Initialized
INFO - 2023-11-23 10:17:26 --> Language Class Initialized
INFO - 2023-11-23 10:17:26 --> Config Class Initialized
INFO - 2023-11-23 10:17:26 --> Loader Class Initialized
INFO - 2023-11-23 10:17:26 --> Helper loaded: url_helper
INFO - 2023-11-23 10:17:26 --> Helper loaded: file_helper
INFO - 2023-11-23 10:17:26 --> Helper loaded: form_helper
INFO - 2023-11-23 10:17:26 --> Helper loaded: my_helper
INFO - 2023-11-23 10:17:26 --> Database Driver Class Initialized
INFO - 2023-11-23 10:17:26 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-23 10:17:26 --> Controller Class Initialized
INFO - 2023-11-23 10:17:26 --> Final output sent to browser
DEBUG - 2023-11-23 10:17:26 --> Total execution time: 0.2702
INFO - 2023-11-23 10:17:38 --> Config Class Initialized
INFO - 2023-11-23 10:17:38 --> Hooks Class Initialized
DEBUG - 2023-11-23 10:17:38 --> UTF-8 Support Enabled
INFO - 2023-11-23 10:17:38 --> Utf8 Class Initialized
INFO - 2023-11-23 10:17:38 --> URI Class Initialized
INFO - 2023-11-23 10:17:38 --> Router Class Initialized
INFO - 2023-11-23 10:17:38 --> Output Class Initialized
INFO - 2023-11-23 10:17:38 --> Security Class Initialized
DEBUG - 2023-11-23 10:17:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-23 10:17:38 --> Input Class Initialized
INFO - 2023-11-23 10:17:38 --> Language Class Initialized
INFO - 2023-11-23 10:17:38 --> Language Class Initialized
INFO - 2023-11-23 10:17:38 --> Config Class Initialized
INFO - 2023-11-23 10:17:38 --> Loader Class Initialized
INFO - 2023-11-23 10:17:38 --> Helper loaded: url_helper
INFO - 2023-11-23 10:17:38 --> Helper loaded: file_helper
INFO - 2023-11-23 10:17:38 --> Helper loaded: form_helper
INFO - 2023-11-23 10:17:38 --> Helper loaded: my_helper
INFO - 2023-11-23 10:17:38 --> Database Driver Class Initialized
INFO - 2023-11-23 10:17:38 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-23 10:17:38 --> Controller Class Initialized
INFO - 2023-11-23 10:17:38 --> Final output sent to browser
DEBUG - 2023-11-23 10:17:38 --> Total execution time: 0.0501
INFO - 2023-11-23 10:17:44 --> Config Class Initialized
INFO - 2023-11-23 10:17:44 --> Hooks Class Initialized
DEBUG - 2023-11-23 10:17:44 --> UTF-8 Support Enabled
INFO - 2023-11-23 10:17:44 --> Utf8 Class Initialized
INFO - 2023-11-23 10:17:44 --> URI Class Initialized
INFO - 2023-11-23 10:17:44 --> Router Class Initialized
INFO - 2023-11-23 10:17:44 --> Output Class Initialized
INFO - 2023-11-23 10:17:44 --> Security Class Initialized
DEBUG - 2023-11-23 10:17:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-23 10:17:44 --> Input Class Initialized
INFO - 2023-11-23 10:17:44 --> Language Class Initialized
INFO - 2023-11-23 10:17:44 --> Language Class Initialized
INFO - 2023-11-23 10:17:44 --> Config Class Initialized
INFO - 2023-11-23 10:17:44 --> Loader Class Initialized
INFO - 2023-11-23 10:17:44 --> Helper loaded: url_helper
INFO - 2023-11-23 10:17:44 --> Helper loaded: file_helper
INFO - 2023-11-23 10:17:44 --> Helper loaded: form_helper
INFO - 2023-11-23 10:17:44 --> Helper loaded: my_helper
INFO - 2023-11-23 10:17:44 --> Database Driver Class Initialized
INFO - 2023-11-23 10:17:44 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-23 10:17:44 --> Controller Class Initialized
INFO - 2023-11-23 10:17:44 --> Final output sent to browser
DEBUG - 2023-11-23 10:17:44 --> Total execution time: 0.0398
INFO - 2023-11-23 10:17:53 --> Config Class Initialized
INFO - 2023-11-23 10:17:53 --> Hooks Class Initialized
DEBUG - 2023-11-23 10:17:53 --> UTF-8 Support Enabled
INFO - 2023-11-23 10:17:53 --> Utf8 Class Initialized
INFO - 2023-11-23 10:17:53 --> URI Class Initialized
INFO - 2023-11-23 10:17:53 --> Router Class Initialized
INFO - 2023-11-23 10:17:53 --> Output Class Initialized
INFO - 2023-11-23 10:17:53 --> Security Class Initialized
DEBUG - 2023-11-23 10:17:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-23 10:17:53 --> Input Class Initialized
INFO - 2023-11-23 10:17:53 --> Language Class Initialized
INFO - 2023-11-23 10:17:53 --> Language Class Initialized
INFO - 2023-11-23 10:17:53 --> Config Class Initialized
INFO - 2023-11-23 10:17:53 --> Loader Class Initialized
INFO - 2023-11-23 10:17:53 --> Helper loaded: url_helper
INFO - 2023-11-23 10:17:53 --> Helper loaded: file_helper
INFO - 2023-11-23 10:17:53 --> Helper loaded: form_helper
INFO - 2023-11-23 10:17:53 --> Helper loaded: my_helper
INFO - 2023-11-23 10:17:53 --> Database Driver Class Initialized
INFO - 2023-11-23 10:17:53 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-23 10:17:53 --> Controller Class Initialized
INFO - 2023-11-23 10:17:53 --> Final output sent to browser
DEBUG - 2023-11-23 10:17:53 --> Total execution time: 0.0372
INFO - 2023-11-23 10:25:58 --> Config Class Initialized
INFO - 2023-11-23 10:25:58 --> Hooks Class Initialized
DEBUG - 2023-11-23 10:25:58 --> UTF-8 Support Enabled
INFO - 2023-11-23 10:25:58 --> Utf8 Class Initialized
INFO - 2023-11-23 10:25:58 --> URI Class Initialized
INFO - 2023-11-23 10:25:58 --> Router Class Initialized
INFO - 2023-11-23 10:25:58 --> Output Class Initialized
INFO - 2023-11-23 10:25:58 --> Security Class Initialized
DEBUG - 2023-11-23 10:25:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-23 10:25:58 --> Input Class Initialized
INFO - 2023-11-23 10:25:58 --> Language Class Initialized
INFO - 2023-11-23 10:25:58 --> Language Class Initialized
INFO - 2023-11-23 10:25:58 --> Config Class Initialized
INFO - 2023-11-23 10:25:58 --> Loader Class Initialized
INFO - 2023-11-23 10:25:58 --> Helper loaded: url_helper
INFO - 2023-11-23 10:25:58 --> Helper loaded: file_helper
INFO - 2023-11-23 10:25:58 --> Helper loaded: form_helper
INFO - 2023-11-23 10:25:58 --> Helper loaded: my_helper
INFO - 2023-11-23 10:25:58 --> Database Driver Class Initialized
INFO - 2023-11-23 10:25:58 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-23 10:25:58 --> Controller Class Initialized
INFO - 2023-11-23 10:25:58 --> Final output sent to browser
DEBUG - 2023-11-23 10:25:58 --> Total execution time: 0.0584
INFO - 2023-11-23 10:25:58 --> Config Class Initialized
INFO - 2023-11-23 10:25:58 --> Hooks Class Initialized
DEBUG - 2023-11-23 10:25:58 --> UTF-8 Support Enabled
INFO - 2023-11-23 10:25:58 --> Utf8 Class Initialized
INFO - 2023-11-23 10:25:58 --> URI Class Initialized
INFO - 2023-11-23 10:25:58 --> Router Class Initialized
INFO - 2023-11-23 10:25:58 --> Output Class Initialized
INFO - 2023-11-23 10:25:58 --> Security Class Initialized
DEBUG - 2023-11-23 10:25:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-23 10:25:58 --> Input Class Initialized
INFO - 2023-11-23 10:25:58 --> Language Class Initialized
INFO - 2023-11-23 10:25:58 --> Language Class Initialized
INFO - 2023-11-23 10:25:58 --> Config Class Initialized
INFO - 2023-11-23 10:25:58 --> Loader Class Initialized
INFO - 2023-11-23 10:25:58 --> Helper loaded: url_helper
INFO - 2023-11-23 10:25:58 --> Helper loaded: file_helper
INFO - 2023-11-23 10:25:58 --> Helper loaded: form_helper
INFO - 2023-11-23 10:25:58 --> Helper loaded: my_helper
INFO - 2023-11-23 10:25:58 --> Database Driver Class Initialized
INFO - 2023-11-23 10:25:58 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-23 10:25:58 --> Controller Class Initialized
INFO - 2023-11-23 10:26:02 --> Config Class Initialized
INFO - 2023-11-23 10:26:02 --> Hooks Class Initialized
DEBUG - 2023-11-23 10:26:02 --> UTF-8 Support Enabled
INFO - 2023-11-23 10:26:02 --> Utf8 Class Initialized
INFO - 2023-11-23 10:26:02 --> URI Class Initialized
INFO - 2023-11-23 10:26:02 --> Router Class Initialized
INFO - 2023-11-23 10:26:02 --> Output Class Initialized
INFO - 2023-11-23 10:26:02 --> Security Class Initialized
DEBUG - 2023-11-23 10:26:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-23 10:26:02 --> Input Class Initialized
INFO - 2023-11-23 10:26:02 --> Language Class Initialized
INFO - 2023-11-23 10:26:02 --> Language Class Initialized
INFO - 2023-11-23 10:26:02 --> Config Class Initialized
INFO - 2023-11-23 10:26:02 --> Loader Class Initialized
INFO - 2023-11-23 10:26:02 --> Helper loaded: url_helper
INFO - 2023-11-23 10:26:02 --> Helper loaded: file_helper
INFO - 2023-11-23 10:26:02 --> Helper loaded: form_helper
INFO - 2023-11-23 10:26:02 --> Helper loaded: my_helper
INFO - 2023-11-23 10:26:02 --> Database Driver Class Initialized
INFO - 2023-11-23 10:26:02 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-23 10:26:02 --> Controller Class Initialized
INFO - 2023-11-23 10:26:02 --> Final output sent to browser
DEBUG - 2023-11-23 10:26:02 --> Total execution time: 0.0418
INFO - 2023-11-23 10:26:23 --> Config Class Initialized
INFO - 2023-11-23 10:26:23 --> Hooks Class Initialized
DEBUG - 2023-11-23 10:26:23 --> UTF-8 Support Enabled
INFO - 2023-11-23 10:26:23 --> Utf8 Class Initialized
INFO - 2023-11-23 10:26:23 --> URI Class Initialized
INFO - 2023-11-23 10:26:23 --> Router Class Initialized
INFO - 2023-11-23 10:26:23 --> Output Class Initialized
INFO - 2023-11-23 10:26:23 --> Security Class Initialized
DEBUG - 2023-11-23 10:26:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-23 10:26:23 --> Input Class Initialized
INFO - 2023-11-23 10:26:23 --> Language Class Initialized
INFO - 2023-11-23 10:26:23 --> Language Class Initialized
INFO - 2023-11-23 10:26:23 --> Config Class Initialized
INFO - 2023-11-23 10:26:23 --> Loader Class Initialized
INFO - 2023-11-23 10:26:23 --> Helper loaded: url_helper
INFO - 2023-11-23 10:26:23 --> Helper loaded: file_helper
INFO - 2023-11-23 10:26:23 --> Helper loaded: form_helper
INFO - 2023-11-23 10:26:23 --> Helper loaded: my_helper
INFO - 2023-11-23 10:26:23 --> Database Driver Class Initialized
INFO - 2023-11-23 10:26:23 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-23 10:26:23 --> Controller Class Initialized
INFO - 2023-11-23 10:26:23 --> Final output sent to browser
DEBUG - 2023-11-23 10:26:23 --> Total execution time: 0.0470
INFO - 2023-11-23 10:26:23 --> Config Class Initialized
INFO - 2023-11-23 10:26:23 --> Hooks Class Initialized
DEBUG - 2023-11-23 10:26:23 --> UTF-8 Support Enabled
INFO - 2023-11-23 10:26:23 --> Utf8 Class Initialized
INFO - 2023-11-23 10:26:23 --> URI Class Initialized
INFO - 2023-11-23 10:26:23 --> Router Class Initialized
INFO - 2023-11-23 10:26:23 --> Output Class Initialized
INFO - 2023-11-23 10:26:23 --> Security Class Initialized
DEBUG - 2023-11-23 10:26:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-23 10:26:23 --> Input Class Initialized
INFO - 2023-11-23 10:26:23 --> Language Class Initialized
INFO - 2023-11-23 10:26:23 --> Language Class Initialized
INFO - 2023-11-23 10:26:23 --> Config Class Initialized
INFO - 2023-11-23 10:26:23 --> Loader Class Initialized
INFO - 2023-11-23 10:26:23 --> Helper loaded: url_helper
INFO - 2023-11-23 10:26:23 --> Helper loaded: file_helper
INFO - 2023-11-23 10:26:23 --> Helper loaded: form_helper
INFO - 2023-11-23 10:26:23 --> Helper loaded: my_helper
INFO - 2023-11-23 10:26:23 --> Database Driver Class Initialized
INFO - 2023-11-23 10:26:23 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-23 10:26:23 --> Controller Class Initialized
INFO - 2023-11-23 10:26:39 --> Config Class Initialized
INFO - 2023-11-23 10:26:39 --> Hooks Class Initialized
DEBUG - 2023-11-23 10:26:39 --> UTF-8 Support Enabled
INFO - 2023-11-23 10:26:39 --> Utf8 Class Initialized
INFO - 2023-11-23 10:26:39 --> URI Class Initialized
INFO - 2023-11-23 10:26:39 --> Router Class Initialized
INFO - 2023-11-23 10:26:39 --> Output Class Initialized
INFO - 2023-11-23 10:26:39 --> Security Class Initialized
DEBUG - 2023-11-23 10:26:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-23 10:26:39 --> Input Class Initialized
INFO - 2023-11-23 10:26:39 --> Language Class Initialized
INFO - 2023-11-23 10:26:39 --> Language Class Initialized
INFO - 2023-11-23 10:26:39 --> Config Class Initialized
INFO - 2023-11-23 10:26:39 --> Loader Class Initialized
INFO - 2023-11-23 10:26:39 --> Helper loaded: url_helper
INFO - 2023-11-23 10:26:39 --> Helper loaded: file_helper
INFO - 2023-11-23 10:26:39 --> Helper loaded: form_helper
INFO - 2023-11-23 10:26:39 --> Helper loaded: my_helper
INFO - 2023-11-23 10:26:39 --> Database Driver Class Initialized
INFO - 2023-11-23 10:26:39 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-23 10:26:39 --> Controller Class Initialized
INFO - 2023-11-23 10:26:39 --> Final output sent to browser
DEBUG - 2023-11-23 10:26:39 --> Total execution time: 0.0672
INFO - 2023-11-23 10:27:11 --> Config Class Initialized
INFO - 2023-11-23 10:27:11 --> Hooks Class Initialized
DEBUG - 2023-11-23 10:27:11 --> UTF-8 Support Enabled
INFO - 2023-11-23 10:27:11 --> Utf8 Class Initialized
INFO - 2023-11-23 10:27:11 --> URI Class Initialized
INFO - 2023-11-23 10:27:11 --> Router Class Initialized
INFO - 2023-11-23 10:27:11 --> Output Class Initialized
INFO - 2023-11-23 10:27:11 --> Security Class Initialized
DEBUG - 2023-11-23 10:27:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-23 10:27:11 --> Input Class Initialized
INFO - 2023-11-23 10:27:11 --> Language Class Initialized
INFO - 2023-11-23 10:27:11 --> Language Class Initialized
INFO - 2023-11-23 10:27:11 --> Config Class Initialized
INFO - 2023-11-23 10:27:11 --> Loader Class Initialized
INFO - 2023-11-23 10:27:11 --> Helper loaded: url_helper
INFO - 2023-11-23 10:27:11 --> Helper loaded: file_helper
INFO - 2023-11-23 10:27:11 --> Helper loaded: form_helper
INFO - 2023-11-23 10:27:11 --> Helper loaded: my_helper
INFO - 2023-11-23 10:27:11 --> Database Driver Class Initialized
INFO - 2023-11-23 10:27:11 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-23 10:27:11 --> Controller Class Initialized
INFO - 2023-11-23 10:27:11 --> Final output sent to browser
DEBUG - 2023-11-23 10:27:11 --> Total execution time: 0.0427
INFO - 2023-11-23 10:27:11 --> Config Class Initialized
INFO - 2023-11-23 10:27:11 --> Hooks Class Initialized
DEBUG - 2023-11-23 10:27:11 --> UTF-8 Support Enabled
INFO - 2023-11-23 10:27:11 --> Utf8 Class Initialized
INFO - 2023-11-23 10:27:11 --> URI Class Initialized
INFO - 2023-11-23 10:27:11 --> Router Class Initialized
INFO - 2023-11-23 10:27:11 --> Output Class Initialized
INFO - 2023-11-23 10:27:11 --> Security Class Initialized
DEBUG - 2023-11-23 10:27:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-23 10:27:11 --> Input Class Initialized
INFO - 2023-11-23 10:27:11 --> Language Class Initialized
INFO - 2023-11-23 10:27:11 --> Language Class Initialized
INFO - 2023-11-23 10:27:11 --> Config Class Initialized
INFO - 2023-11-23 10:27:11 --> Loader Class Initialized
INFO - 2023-11-23 10:27:11 --> Helper loaded: url_helper
INFO - 2023-11-23 10:27:11 --> Helper loaded: file_helper
INFO - 2023-11-23 10:27:11 --> Helper loaded: form_helper
INFO - 2023-11-23 10:27:11 --> Helper loaded: my_helper
INFO - 2023-11-23 10:27:11 --> Database Driver Class Initialized
INFO - 2023-11-23 10:27:11 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-23 10:27:11 --> Controller Class Initialized
INFO - 2023-11-23 10:27:54 --> Config Class Initialized
INFO - 2023-11-23 10:27:54 --> Hooks Class Initialized
DEBUG - 2023-11-23 10:27:54 --> UTF-8 Support Enabled
INFO - 2023-11-23 10:27:54 --> Utf8 Class Initialized
INFO - 2023-11-23 10:27:54 --> URI Class Initialized
INFO - 2023-11-23 10:27:54 --> Router Class Initialized
INFO - 2023-11-23 10:27:54 --> Output Class Initialized
INFO - 2023-11-23 10:27:54 --> Security Class Initialized
DEBUG - 2023-11-23 10:27:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-23 10:27:54 --> Input Class Initialized
INFO - 2023-11-23 10:27:54 --> Language Class Initialized
INFO - 2023-11-23 10:27:54 --> Language Class Initialized
INFO - 2023-11-23 10:27:54 --> Config Class Initialized
INFO - 2023-11-23 10:27:54 --> Loader Class Initialized
INFO - 2023-11-23 10:27:54 --> Helper loaded: url_helper
INFO - 2023-11-23 10:27:54 --> Helper loaded: file_helper
INFO - 2023-11-23 10:27:54 --> Helper loaded: form_helper
INFO - 2023-11-23 10:27:54 --> Helper loaded: my_helper
INFO - 2023-11-23 10:27:54 --> Database Driver Class Initialized
INFO - 2023-11-23 10:27:54 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-23 10:27:54 --> Controller Class Initialized
INFO - 2023-11-23 10:27:54 --> Final output sent to browser
DEBUG - 2023-11-23 10:27:54 --> Total execution time: 0.0601
INFO - 2023-11-23 10:27:56 --> Config Class Initialized
INFO - 2023-11-23 10:27:56 --> Hooks Class Initialized
DEBUG - 2023-11-23 10:27:56 --> UTF-8 Support Enabled
INFO - 2023-11-23 10:27:56 --> Utf8 Class Initialized
INFO - 2023-11-23 10:27:56 --> URI Class Initialized
INFO - 2023-11-23 10:27:56 --> Router Class Initialized
INFO - 2023-11-23 10:27:56 --> Output Class Initialized
INFO - 2023-11-23 10:27:56 --> Security Class Initialized
DEBUG - 2023-11-23 10:27:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-23 10:27:56 --> Input Class Initialized
INFO - 2023-11-23 10:27:56 --> Language Class Initialized
INFO - 2023-11-23 10:27:56 --> Language Class Initialized
INFO - 2023-11-23 10:27:56 --> Config Class Initialized
INFO - 2023-11-23 10:27:56 --> Loader Class Initialized
INFO - 2023-11-23 10:27:56 --> Helper loaded: url_helper
INFO - 2023-11-23 10:27:56 --> Helper loaded: file_helper
INFO - 2023-11-23 10:27:56 --> Helper loaded: form_helper
INFO - 2023-11-23 10:27:56 --> Helper loaded: my_helper
INFO - 2023-11-23 10:27:56 --> Database Driver Class Initialized
INFO - 2023-11-23 10:27:56 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-23 10:27:56 --> Controller Class Initialized
INFO - 2023-11-23 10:27:56 --> Final output sent to browser
DEBUG - 2023-11-23 10:27:56 --> Total execution time: 0.0325
INFO - 2023-11-23 10:27:58 --> Config Class Initialized
INFO - 2023-11-23 10:27:58 --> Hooks Class Initialized
DEBUG - 2023-11-23 10:27:58 --> UTF-8 Support Enabled
INFO - 2023-11-23 10:27:58 --> Utf8 Class Initialized
INFO - 2023-11-23 10:27:58 --> URI Class Initialized
INFO - 2023-11-23 10:27:58 --> Router Class Initialized
INFO - 2023-11-23 10:27:58 --> Output Class Initialized
INFO - 2023-11-23 10:27:58 --> Security Class Initialized
DEBUG - 2023-11-23 10:27:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-23 10:27:58 --> Input Class Initialized
INFO - 2023-11-23 10:27:58 --> Language Class Initialized
INFO - 2023-11-23 10:27:58 --> Language Class Initialized
INFO - 2023-11-23 10:27:58 --> Config Class Initialized
INFO - 2023-11-23 10:27:58 --> Loader Class Initialized
INFO - 2023-11-23 10:27:58 --> Helper loaded: url_helper
INFO - 2023-11-23 10:27:58 --> Helper loaded: file_helper
INFO - 2023-11-23 10:27:58 --> Helper loaded: form_helper
INFO - 2023-11-23 10:27:58 --> Helper loaded: my_helper
INFO - 2023-11-23 10:27:58 --> Database Driver Class Initialized
INFO - 2023-11-23 10:27:58 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-23 10:27:58 --> Controller Class Initialized
INFO - 2023-11-23 10:27:58 --> Final output sent to browser
DEBUG - 2023-11-23 10:27:58 --> Total execution time: 0.0334
INFO - 2023-11-23 10:29:11 --> Config Class Initialized
INFO - 2023-11-23 10:29:11 --> Hooks Class Initialized
DEBUG - 2023-11-23 10:29:11 --> UTF-8 Support Enabled
INFO - 2023-11-23 10:29:11 --> Utf8 Class Initialized
INFO - 2023-11-23 10:29:11 --> URI Class Initialized
INFO - 2023-11-23 10:29:11 --> Router Class Initialized
INFO - 2023-11-23 10:29:11 --> Output Class Initialized
INFO - 2023-11-23 10:29:11 --> Security Class Initialized
DEBUG - 2023-11-23 10:29:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-23 10:29:11 --> Input Class Initialized
INFO - 2023-11-23 10:29:11 --> Language Class Initialized
INFO - 2023-11-23 10:29:11 --> Language Class Initialized
INFO - 2023-11-23 10:29:11 --> Config Class Initialized
INFO - 2023-11-23 10:29:11 --> Loader Class Initialized
INFO - 2023-11-23 10:29:11 --> Helper loaded: url_helper
INFO - 2023-11-23 10:29:11 --> Helper loaded: file_helper
INFO - 2023-11-23 10:29:11 --> Helper loaded: form_helper
INFO - 2023-11-23 10:29:11 --> Helper loaded: my_helper
INFO - 2023-11-23 10:29:11 --> Database Driver Class Initialized
INFO - 2023-11-23 10:29:11 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-23 10:29:11 --> Controller Class Initialized
INFO - 2023-11-23 10:29:11 --> Final output sent to browser
DEBUG - 2023-11-23 10:29:11 --> Total execution time: 0.0729
INFO - 2023-11-23 10:29:16 --> Config Class Initialized
INFO - 2023-11-23 10:29:16 --> Hooks Class Initialized
DEBUG - 2023-11-23 10:29:16 --> UTF-8 Support Enabled
INFO - 2023-11-23 10:29:16 --> Utf8 Class Initialized
INFO - 2023-11-23 10:29:16 --> URI Class Initialized
INFO - 2023-11-23 10:29:16 --> Router Class Initialized
INFO - 2023-11-23 10:29:16 --> Output Class Initialized
INFO - 2023-11-23 10:29:16 --> Security Class Initialized
DEBUG - 2023-11-23 10:29:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-23 10:29:16 --> Input Class Initialized
INFO - 2023-11-23 10:29:16 --> Language Class Initialized
INFO - 2023-11-23 10:29:16 --> Language Class Initialized
INFO - 2023-11-23 10:29:16 --> Config Class Initialized
INFO - 2023-11-23 10:29:16 --> Loader Class Initialized
INFO - 2023-11-23 10:29:16 --> Helper loaded: url_helper
INFO - 2023-11-23 10:29:16 --> Helper loaded: file_helper
INFO - 2023-11-23 10:29:16 --> Helper loaded: form_helper
INFO - 2023-11-23 10:29:16 --> Helper loaded: my_helper
INFO - 2023-11-23 10:29:16 --> Database Driver Class Initialized
INFO - 2023-11-23 10:29:16 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-23 10:29:16 --> Controller Class Initialized
INFO - 2023-11-23 10:29:16 --> Final output sent to browser
DEBUG - 2023-11-23 10:29:16 --> Total execution time: 0.0703
INFO - 2023-11-23 10:29:22 --> Config Class Initialized
INFO - 2023-11-23 10:29:22 --> Hooks Class Initialized
DEBUG - 2023-11-23 10:29:22 --> UTF-8 Support Enabled
INFO - 2023-11-23 10:29:22 --> Utf8 Class Initialized
INFO - 2023-11-23 10:29:22 --> URI Class Initialized
INFO - 2023-11-23 10:29:22 --> Router Class Initialized
INFO - 2023-11-23 10:29:22 --> Output Class Initialized
INFO - 2023-11-23 10:29:22 --> Security Class Initialized
DEBUG - 2023-11-23 10:29:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-23 10:29:22 --> Input Class Initialized
INFO - 2023-11-23 10:29:22 --> Language Class Initialized
INFO - 2023-11-23 10:29:22 --> Language Class Initialized
INFO - 2023-11-23 10:29:22 --> Config Class Initialized
INFO - 2023-11-23 10:29:22 --> Loader Class Initialized
INFO - 2023-11-23 10:29:22 --> Helper loaded: url_helper
INFO - 2023-11-23 10:29:22 --> Helper loaded: file_helper
INFO - 2023-11-23 10:29:22 --> Helper loaded: form_helper
INFO - 2023-11-23 10:29:22 --> Helper loaded: my_helper
INFO - 2023-11-23 10:29:22 --> Database Driver Class Initialized
INFO - 2023-11-23 10:29:22 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-23 10:29:22 --> Controller Class Initialized
INFO - 2023-11-23 10:29:22 --> Final output sent to browser
DEBUG - 2023-11-23 10:29:22 --> Total execution time: 0.0398
INFO - 2023-11-23 10:29:33 --> Config Class Initialized
INFO - 2023-11-23 10:29:33 --> Hooks Class Initialized
DEBUG - 2023-11-23 10:29:33 --> UTF-8 Support Enabled
INFO - 2023-11-23 10:29:33 --> Utf8 Class Initialized
INFO - 2023-11-23 10:29:33 --> URI Class Initialized
INFO - 2023-11-23 10:29:33 --> Router Class Initialized
INFO - 2023-11-23 10:29:33 --> Output Class Initialized
INFO - 2023-11-23 10:29:33 --> Security Class Initialized
DEBUG - 2023-11-23 10:29:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-23 10:29:33 --> Input Class Initialized
INFO - 2023-11-23 10:29:33 --> Language Class Initialized
INFO - 2023-11-23 10:29:33 --> Language Class Initialized
INFO - 2023-11-23 10:29:33 --> Config Class Initialized
INFO - 2023-11-23 10:29:33 --> Loader Class Initialized
INFO - 2023-11-23 10:29:33 --> Helper loaded: url_helper
INFO - 2023-11-23 10:29:33 --> Helper loaded: file_helper
INFO - 2023-11-23 10:29:33 --> Helper loaded: form_helper
INFO - 2023-11-23 10:29:33 --> Helper loaded: my_helper
INFO - 2023-11-23 10:29:33 --> Database Driver Class Initialized
INFO - 2023-11-23 10:29:33 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-23 10:29:33 --> Controller Class Initialized
INFO - 2023-11-23 10:29:33 --> Final output sent to browser
DEBUG - 2023-11-23 10:29:33 --> Total execution time: 0.0339
INFO - 2023-11-23 10:29:33 --> Config Class Initialized
INFO - 2023-11-23 10:29:33 --> Hooks Class Initialized
DEBUG - 2023-11-23 10:29:33 --> UTF-8 Support Enabled
INFO - 2023-11-23 10:29:33 --> Utf8 Class Initialized
INFO - 2023-11-23 10:29:33 --> URI Class Initialized
INFO - 2023-11-23 10:29:33 --> Router Class Initialized
INFO - 2023-11-23 10:29:33 --> Output Class Initialized
INFO - 2023-11-23 10:29:33 --> Security Class Initialized
DEBUG - 2023-11-23 10:29:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-23 10:29:33 --> Input Class Initialized
INFO - 2023-11-23 10:29:33 --> Language Class Initialized
INFO - 2023-11-23 10:29:33 --> Language Class Initialized
INFO - 2023-11-23 10:29:33 --> Config Class Initialized
INFO - 2023-11-23 10:29:33 --> Loader Class Initialized
INFO - 2023-11-23 10:29:33 --> Helper loaded: url_helper
INFO - 2023-11-23 10:29:33 --> Helper loaded: file_helper
INFO - 2023-11-23 10:29:33 --> Helper loaded: form_helper
INFO - 2023-11-23 10:29:33 --> Helper loaded: my_helper
INFO - 2023-11-23 10:29:33 --> Database Driver Class Initialized
INFO - 2023-11-23 10:29:33 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-23 10:29:33 --> Controller Class Initialized
INFO - 2023-11-23 10:29:38 --> Config Class Initialized
INFO - 2023-11-23 10:29:38 --> Hooks Class Initialized
DEBUG - 2023-11-23 10:29:38 --> UTF-8 Support Enabled
INFO - 2023-11-23 10:29:38 --> Utf8 Class Initialized
INFO - 2023-11-23 10:29:38 --> URI Class Initialized
INFO - 2023-11-23 10:29:38 --> Router Class Initialized
INFO - 2023-11-23 10:29:38 --> Output Class Initialized
INFO - 2023-11-23 10:29:38 --> Security Class Initialized
DEBUG - 2023-11-23 10:29:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-23 10:29:38 --> Input Class Initialized
INFO - 2023-11-23 10:29:38 --> Language Class Initialized
INFO - 2023-11-23 10:29:38 --> Language Class Initialized
INFO - 2023-11-23 10:29:38 --> Config Class Initialized
INFO - 2023-11-23 10:29:38 --> Loader Class Initialized
INFO - 2023-11-23 10:29:38 --> Helper loaded: url_helper
INFO - 2023-11-23 10:29:38 --> Helper loaded: file_helper
INFO - 2023-11-23 10:29:38 --> Helper loaded: form_helper
INFO - 2023-11-23 10:29:38 --> Helper loaded: my_helper
INFO - 2023-11-23 10:29:38 --> Database Driver Class Initialized
INFO - 2023-11-23 10:29:38 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-23 10:29:38 --> Controller Class Initialized
INFO - 2023-11-23 10:29:38 --> Final output sent to browser
DEBUG - 2023-11-23 10:29:38 --> Total execution time: 0.0465
INFO - 2023-11-23 10:29:40 --> Config Class Initialized
INFO - 2023-11-23 10:29:40 --> Hooks Class Initialized
DEBUG - 2023-11-23 10:29:40 --> UTF-8 Support Enabled
INFO - 2023-11-23 10:29:40 --> Utf8 Class Initialized
INFO - 2023-11-23 10:29:40 --> URI Class Initialized
INFO - 2023-11-23 10:29:40 --> Router Class Initialized
INFO - 2023-11-23 10:29:40 --> Output Class Initialized
INFO - 2023-11-23 10:29:40 --> Security Class Initialized
DEBUG - 2023-11-23 10:29:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-23 10:29:40 --> Input Class Initialized
INFO - 2023-11-23 10:29:40 --> Language Class Initialized
INFO - 2023-11-23 10:29:40 --> Language Class Initialized
INFO - 2023-11-23 10:29:40 --> Config Class Initialized
INFO - 2023-11-23 10:29:40 --> Loader Class Initialized
INFO - 2023-11-23 10:29:40 --> Helper loaded: url_helper
INFO - 2023-11-23 10:29:40 --> Helper loaded: file_helper
INFO - 2023-11-23 10:29:40 --> Helper loaded: form_helper
INFO - 2023-11-23 10:29:40 --> Helper loaded: my_helper
INFO - 2023-11-23 10:29:40 --> Database Driver Class Initialized
INFO - 2023-11-23 10:29:40 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-23 10:29:40 --> Controller Class Initialized
INFO - 2023-11-23 10:29:40 --> Final output sent to browser
DEBUG - 2023-11-23 10:29:40 --> Total execution time: 0.0340
INFO - 2023-11-23 10:29:41 --> Config Class Initialized
INFO - 2023-11-23 10:29:41 --> Hooks Class Initialized
DEBUG - 2023-11-23 10:29:41 --> UTF-8 Support Enabled
INFO - 2023-11-23 10:29:41 --> Utf8 Class Initialized
INFO - 2023-11-23 10:29:41 --> URI Class Initialized
INFO - 2023-11-23 10:29:41 --> Router Class Initialized
INFO - 2023-11-23 10:29:41 --> Output Class Initialized
INFO - 2023-11-23 10:29:41 --> Security Class Initialized
DEBUG - 2023-11-23 10:29:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-23 10:29:41 --> Input Class Initialized
INFO - 2023-11-23 10:29:41 --> Language Class Initialized
INFO - 2023-11-23 10:29:41 --> Language Class Initialized
INFO - 2023-11-23 10:29:41 --> Config Class Initialized
INFO - 2023-11-23 10:29:41 --> Loader Class Initialized
INFO - 2023-11-23 10:29:41 --> Helper loaded: url_helper
INFO - 2023-11-23 10:29:41 --> Helper loaded: file_helper
INFO - 2023-11-23 10:29:41 --> Helper loaded: form_helper
INFO - 2023-11-23 10:29:41 --> Helper loaded: my_helper
INFO - 2023-11-23 10:29:41 --> Database Driver Class Initialized
INFO - 2023-11-23 10:29:41 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-23 10:29:41 --> Controller Class Initialized
INFO - 2023-11-23 10:29:41 --> Final output sent to browser
DEBUG - 2023-11-23 10:29:41 --> Total execution time: 0.0442
INFO - 2023-11-23 10:29:41 --> Config Class Initialized
INFO - 2023-11-23 10:29:41 --> Hooks Class Initialized
DEBUG - 2023-11-23 10:29:41 --> UTF-8 Support Enabled
INFO - 2023-11-23 10:29:41 --> Utf8 Class Initialized
INFO - 2023-11-23 10:29:41 --> URI Class Initialized
INFO - 2023-11-23 10:29:41 --> Router Class Initialized
INFO - 2023-11-23 10:29:41 --> Output Class Initialized
INFO - 2023-11-23 10:29:41 --> Security Class Initialized
DEBUG - 2023-11-23 10:29:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-23 10:29:41 --> Input Class Initialized
INFO - 2023-11-23 10:29:41 --> Language Class Initialized
INFO - 2023-11-23 10:29:41 --> Language Class Initialized
INFO - 2023-11-23 10:29:41 --> Config Class Initialized
INFO - 2023-11-23 10:29:41 --> Loader Class Initialized
INFO - 2023-11-23 10:29:41 --> Helper loaded: url_helper
INFO - 2023-11-23 10:29:41 --> Helper loaded: file_helper
INFO - 2023-11-23 10:29:41 --> Helper loaded: form_helper
INFO - 2023-11-23 10:29:41 --> Helper loaded: my_helper
INFO - 2023-11-23 10:29:41 --> Database Driver Class Initialized
INFO - 2023-11-23 10:29:41 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-23 10:29:41 --> Controller Class Initialized
INFO - 2023-11-23 10:29:42 --> Config Class Initialized
INFO - 2023-11-23 10:29:42 --> Hooks Class Initialized
DEBUG - 2023-11-23 10:29:42 --> UTF-8 Support Enabled
INFO - 2023-11-23 10:29:42 --> Utf8 Class Initialized
INFO - 2023-11-23 10:29:42 --> URI Class Initialized
INFO - 2023-11-23 10:29:42 --> Router Class Initialized
INFO - 2023-11-23 10:29:42 --> Output Class Initialized
INFO - 2023-11-23 10:29:42 --> Security Class Initialized
DEBUG - 2023-11-23 10:29:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-23 10:29:42 --> Input Class Initialized
INFO - 2023-11-23 10:29:42 --> Language Class Initialized
INFO - 2023-11-23 10:29:42 --> Language Class Initialized
INFO - 2023-11-23 10:29:42 --> Config Class Initialized
INFO - 2023-11-23 10:29:42 --> Loader Class Initialized
INFO - 2023-11-23 10:29:42 --> Helper loaded: url_helper
INFO - 2023-11-23 10:29:42 --> Helper loaded: file_helper
INFO - 2023-11-23 10:29:42 --> Helper loaded: form_helper
INFO - 2023-11-23 10:29:42 --> Helper loaded: my_helper
INFO - 2023-11-23 10:29:42 --> Database Driver Class Initialized
INFO - 2023-11-23 10:29:42 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-23 10:29:42 --> Controller Class Initialized
INFO - 2023-11-23 10:29:42 --> Final output sent to browser
DEBUG - 2023-11-23 10:29:42 --> Total execution time: 0.0378
INFO - 2023-11-23 10:29:51 --> Config Class Initialized
INFO - 2023-11-23 10:29:51 --> Hooks Class Initialized
DEBUG - 2023-11-23 10:29:51 --> UTF-8 Support Enabled
INFO - 2023-11-23 10:29:51 --> Utf8 Class Initialized
INFO - 2023-11-23 10:29:51 --> URI Class Initialized
INFO - 2023-11-23 10:29:51 --> Router Class Initialized
INFO - 2023-11-23 10:29:51 --> Output Class Initialized
INFO - 2023-11-23 10:29:51 --> Security Class Initialized
DEBUG - 2023-11-23 10:29:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-23 10:29:51 --> Input Class Initialized
INFO - 2023-11-23 10:29:51 --> Language Class Initialized
INFO - 2023-11-23 10:29:51 --> Language Class Initialized
INFO - 2023-11-23 10:29:51 --> Config Class Initialized
INFO - 2023-11-23 10:29:51 --> Loader Class Initialized
INFO - 2023-11-23 10:29:51 --> Helper loaded: url_helper
INFO - 2023-11-23 10:29:51 --> Helper loaded: file_helper
INFO - 2023-11-23 10:29:51 --> Helper loaded: form_helper
INFO - 2023-11-23 10:29:51 --> Helper loaded: my_helper
INFO - 2023-11-23 10:29:51 --> Database Driver Class Initialized
INFO - 2023-11-23 10:29:52 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-23 10:29:52 --> Controller Class Initialized
INFO - 2023-11-23 10:29:52 --> Final output sent to browser
DEBUG - 2023-11-23 10:29:52 --> Total execution time: 0.0521
INFO - 2023-11-23 10:30:53 --> Config Class Initialized
INFO - 2023-11-23 10:30:53 --> Hooks Class Initialized
DEBUG - 2023-11-23 10:30:53 --> UTF-8 Support Enabled
INFO - 2023-11-23 10:30:53 --> Utf8 Class Initialized
INFO - 2023-11-23 10:30:53 --> URI Class Initialized
INFO - 2023-11-23 10:30:53 --> Router Class Initialized
INFO - 2023-11-23 10:30:53 --> Output Class Initialized
INFO - 2023-11-23 10:30:53 --> Security Class Initialized
DEBUG - 2023-11-23 10:30:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-23 10:30:53 --> Input Class Initialized
INFO - 2023-11-23 10:30:53 --> Language Class Initialized
INFO - 2023-11-23 10:30:53 --> Language Class Initialized
INFO - 2023-11-23 10:30:53 --> Config Class Initialized
INFO - 2023-11-23 10:30:53 --> Loader Class Initialized
INFO - 2023-11-23 10:30:53 --> Helper loaded: url_helper
INFO - 2023-11-23 10:30:53 --> Helper loaded: file_helper
INFO - 2023-11-23 10:30:53 --> Helper loaded: form_helper
INFO - 2023-11-23 10:30:53 --> Helper loaded: my_helper
INFO - 2023-11-23 10:30:53 --> Database Driver Class Initialized
INFO - 2023-11-23 10:30:53 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-23 10:30:53 --> Controller Class Initialized
INFO - 2023-11-23 10:30:53 --> Final output sent to browser
DEBUG - 2023-11-23 10:30:53 --> Total execution time: 0.0690
INFO - 2023-11-23 10:30:55 --> Config Class Initialized
INFO - 2023-11-23 10:30:55 --> Hooks Class Initialized
DEBUG - 2023-11-23 10:30:55 --> UTF-8 Support Enabled
INFO - 2023-11-23 10:30:55 --> Utf8 Class Initialized
INFO - 2023-11-23 10:30:55 --> URI Class Initialized
INFO - 2023-11-23 10:30:55 --> Router Class Initialized
INFO - 2023-11-23 10:30:55 --> Output Class Initialized
INFO - 2023-11-23 10:30:55 --> Security Class Initialized
DEBUG - 2023-11-23 10:30:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-23 10:30:55 --> Input Class Initialized
INFO - 2023-11-23 10:30:55 --> Language Class Initialized
INFO - 2023-11-23 10:30:55 --> Language Class Initialized
INFO - 2023-11-23 10:30:55 --> Config Class Initialized
INFO - 2023-11-23 10:30:55 --> Loader Class Initialized
INFO - 2023-11-23 10:30:55 --> Helper loaded: url_helper
INFO - 2023-11-23 10:30:55 --> Helper loaded: file_helper
INFO - 2023-11-23 10:30:55 --> Helper loaded: form_helper
INFO - 2023-11-23 10:30:55 --> Helper loaded: my_helper
INFO - 2023-11-23 10:30:55 --> Database Driver Class Initialized
INFO - 2023-11-23 10:30:55 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-23 10:30:55 --> Controller Class Initialized
INFO - 2023-11-23 10:30:55 --> Final output sent to browser
DEBUG - 2023-11-23 10:30:55 --> Total execution time: 0.0511
INFO - 2023-11-23 10:30:59 --> Config Class Initialized
INFO - 2023-11-23 10:30:59 --> Hooks Class Initialized
DEBUG - 2023-11-23 10:30:59 --> UTF-8 Support Enabled
INFO - 2023-11-23 10:30:59 --> Utf8 Class Initialized
INFO - 2023-11-23 10:30:59 --> URI Class Initialized
INFO - 2023-11-23 10:30:59 --> Router Class Initialized
INFO - 2023-11-23 10:30:59 --> Output Class Initialized
INFO - 2023-11-23 10:30:59 --> Security Class Initialized
DEBUG - 2023-11-23 10:30:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-23 10:30:59 --> Input Class Initialized
INFO - 2023-11-23 10:30:59 --> Language Class Initialized
INFO - 2023-11-23 10:30:59 --> Language Class Initialized
INFO - 2023-11-23 10:30:59 --> Config Class Initialized
INFO - 2023-11-23 10:30:59 --> Loader Class Initialized
INFO - 2023-11-23 10:30:59 --> Helper loaded: url_helper
INFO - 2023-11-23 10:30:59 --> Helper loaded: file_helper
INFO - 2023-11-23 10:30:59 --> Helper loaded: form_helper
INFO - 2023-11-23 10:30:59 --> Helper loaded: my_helper
INFO - 2023-11-23 10:30:59 --> Database Driver Class Initialized
INFO - 2023-11-23 10:30:59 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-23 10:30:59 --> Controller Class Initialized
INFO - 2023-11-23 10:30:59 --> Final output sent to browser
DEBUG - 2023-11-23 10:30:59 --> Total execution time: 0.0401
INFO - 2023-11-23 10:31:01 --> Config Class Initialized
INFO - 2023-11-23 10:31:01 --> Hooks Class Initialized
DEBUG - 2023-11-23 10:31:01 --> UTF-8 Support Enabled
INFO - 2023-11-23 10:31:01 --> Utf8 Class Initialized
INFO - 2023-11-23 10:31:01 --> URI Class Initialized
INFO - 2023-11-23 10:31:01 --> Router Class Initialized
INFO - 2023-11-23 10:31:01 --> Output Class Initialized
INFO - 2023-11-23 10:31:01 --> Security Class Initialized
DEBUG - 2023-11-23 10:31:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-23 10:31:01 --> Input Class Initialized
INFO - 2023-11-23 10:31:01 --> Language Class Initialized
INFO - 2023-11-23 10:31:01 --> Language Class Initialized
INFO - 2023-11-23 10:31:01 --> Config Class Initialized
INFO - 2023-11-23 10:31:01 --> Loader Class Initialized
INFO - 2023-11-23 10:31:01 --> Helper loaded: url_helper
INFO - 2023-11-23 10:31:01 --> Helper loaded: file_helper
INFO - 2023-11-23 10:31:01 --> Helper loaded: form_helper
INFO - 2023-11-23 10:31:01 --> Helper loaded: my_helper
INFO - 2023-11-23 10:31:01 --> Database Driver Class Initialized
INFO - 2023-11-23 10:31:01 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-23 10:31:01 --> Controller Class Initialized
INFO - 2023-11-23 10:31:01 --> Final output sent to browser
DEBUG - 2023-11-23 10:31:01 --> Total execution time: 0.0448
INFO - 2023-11-23 10:31:07 --> Config Class Initialized
INFO - 2023-11-23 10:31:07 --> Hooks Class Initialized
DEBUG - 2023-11-23 10:31:07 --> UTF-8 Support Enabled
INFO - 2023-11-23 10:31:07 --> Utf8 Class Initialized
INFO - 2023-11-23 10:31:07 --> URI Class Initialized
INFO - 2023-11-23 10:31:07 --> Router Class Initialized
INFO - 2023-11-23 10:31:07 --> Output Class Initialized
INFO - 2023-11-23 10:31:07 --> Security Class Initialized
DEBUG - 2023-11-23 10:31:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-23 10:31:07 --> Input Class Initialized
INFO - 2023-11-23 10:31:07 --> Language Class Initialized
INFO - 2023-11-23 10:31:07 --> Language Class Initialized
INFO - 2023-11-23 10:31:07 --> Config Class Initialized
INFO - 2023-11-23 10:31:07 --> Loader Class Initialized
INFO - 2023-11-23 10:31:07 --> Helper loaded: url_helper
INFO - 2023-11-23 10:31:07 --> Helper loaded: file_helper
INFO - 2023-11-23 10:31:07 --> Helper loaded: form_helper
INFO - 2023-11-23 10:31:07 --> Helper loaded: my_helper
INFO - 2023-11-23 10:31:07 --> Database Driver Class Initialized
INFO - 2023-11-23 10:31:07 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-23 10:31:07 --> Controller Class Initialized
INFO - 2023-11-23 10:31:07 --> Final output sent to browser
DEBUG - 2023-11-23 10:31:07 --> Total execution time: 0.0555
INFO - 2023-11-23 10:31:09 --> Config Class Initialized
INFO - 2023-11-23 10:31:09 --> Hooks Class Initialized
DEBUG - 2023-11-23 10:31:09 --> UTF-8 Support Enabled
INFO - 2023-11-23 10:31:09 --> Utf8 Class Initialized
INFO - 2023-11-23 10:31:09 --> URI Class Initialized
INFO - 2023-11-23 10:31:09 --> Router Class Initialized
INFO - 2023-11-23 10:31:09 --> Output Class Initialized
INFO - 2023-11-23 10:31:09 --> Security Class Initialized
DEBUG - 2023-11-23 10:31:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-23 10:31:09 --> Input Class Initialized
INFO - 2023-11-23 10:31:09 --> Language Class Initialized
INFO - 2023-11-23 10:31:09 --> Language Class Initialized
INFO - 2023-11-23 10:31:09 --> Config Class Initialized
INFO - 2023-11-23 10:31:09 --> Loader Class Initialized
INFO - 2023-11-23 10:31:09 --> Helper loaded: url_helper
INFO - 2023-11-23 10:31:09 --> Helper loaded: file_helper
INFO - 2023-11-23 10:31:09 --> Helper loaded: form_helper
INFO - 2023-11-23 10:31:09 --> Helper loaded: my_helper
INFO - 2023-11-23 10:31:09 --> Database Driver Class Initialized
INFO - 2023-11-23 10:31:09 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-23 10:31:09 --> Controller Class Initialized
INFO - 2023-11-23 10:31:19 --> Config Class Initialized
INFO - 2023-11-23 10:31:19 --> Hooks Class Initialized
DEBUG - 2023-11-23 10:31:19 --> UTF-8 Support Enabled
INFO - 2023-11-23 10:31:19 --> Utf8 Class Initialized
INFO - 2023-11-23 10:31:19 --> URI Class Initialized
INFO - 2023-11-23 10:31:19 --> Router Class Initialized
INFO - 2023-11-23 10:31:19 --> Output Class Initialized
INFO - 2023-11-23 10:31:19 --> Security Class Initialized
DEBUG - 2023-11-23 10:31:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-23 10:31:19 --> Input Class Initialized
INFO - 2023-11-23 10:31:19 --> Language Class Initialized
INFO - 2023-11-23 10:31:19 --> Language Class Initialized
INFO - 2023-11-23 10:31:19 --> Config Class Initialized
INFO - 2023-11-23 10:31:19 --> Loader Class Initialized
INFO - 2023-11-23 10:31:19 --> Helper loaded: url_helper
INFO - 2023-11-23 10:31:19 --> Helper loaded: file_helper
INFO - 2023-11-23 10:31:19 --> Helper loaded: form_helper
INFO - 2023-11-23 10:31:19 --> Helper loaded: my_helper
INFO - 2023-11-23 10:31:19 --> Database Driver Class Initialized
INFO - 2023-11-23 10:31:19 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-23 10:31:19 --> Controller Class Initialized
INFO - 2023-11-23 10:31:19 --> Final output sent to browser
DEBUG - 2023-11-23 10:31:19 --> Total execution time: 0.0445
INFO - 2023-11-23 10:31:30 --> Config Class Initialized
INFO - 2023-11-23 10:31:30 --> Hooks Class Initialized
DEBUG - 2023-11-23 10:31:30 --> UTF-8 Support Enabled
INFO - 2023-11-23 10:31:30 --> Utf8 Class Initialized
INFO - 2023-11-23 10:31:30 --> URI Class Initialized
INFO - 2023-11-23 10:31:30 --> Router Class Initialized
INFO - 2023-11-23 10:31:30 --> Output Class Initialized
INFO - 2023-11-23 10:31:30 --> Security Class Initialized
DEBUG - 2023-11-23 10:31:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-23 10:31:30 --> Input Class Initialized
INFO - 2023-11-23 10:31:30 --> Language Class Initialized
INFO - 2023-11-23 10:31:30 --> Language Class Initialized
INFO - 2023-11-23 10:31:30 --> Config Class Initialized
INFO - 2023-11-23 10:31:30 --> Loader Class Initialized
INFO - 2023-11-23 10:31:30 --> Helper loaded: url_helper
INFO - 2023-11-23 10:31:30 --> Helper loaded: file_helper
INFO - 2023-11-23 10:31:30 --> Helper loaded: form_helper
INFO - 2023-11-23 10:31:30 --> Helper loaded: my_helper
INFO - 2023-11-23 10:31:30 --> Database Driver Class Initialized
INFO - 2023-11-23 10:31:30 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-23 10:31:30 --> Controller Class Initialized
INFO - 2023-11-23 10:31:30 --> Final output sent to browser
DEBUG - 2023-11-23 10:31:30 --> Total execution time: 0.0358
INFO - 2023-11-23 10:33:09 --> Config Class Initialized
INFO - 2023-11-23 10:33:09 --> Hooks Class Initialized
DEBUG - 2023-11-23 10:33:09 --> UTF-8 Support Enabled
INFO - 2023-11-23 10:33:09 --> Utf8 Class Initialized
INFO - 2023-11-23 10:33:09 --> URI Class Initialized
INFO - 2023-11-23 10:33:09 --> Router Class Initialized
INFO - 2023-11-23 10:33:09 --> Output Class Initialized
INFO - 2023-11-23 10:33:09 --> Security Class Initialized
DEBUG - 2023-11-23 10:33:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-23 10:33:09 --> Input Class Initialized
INFO - 2023-11-23 10:33:09 --> Language Class Initialized
INFO - 2023-11-23 10:33:09 --> Language Class Initialized
INFO - 2023-11-23 10:33:09 --> Config Class Initialized
INFO - 2023-11-23 10:33:09 --> Loader Class Initialized
INFO - 2023-11-23 10:33:09 --> Helper loaded: url_helper
INFO - 2023-11-23 10:33:09 --> Helper loaded: file_helper
INFO - 2023-11-23 10:33:09 --> Helper loaded: form_helper
INFO - 2023-11-23 10:33:09 --> Helper loaded: my_helper
INFO - 2023-11-23 10:33:09 --> Database Driver Class Initialized
INFO - 2023-11-23 10:33:09 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-23 10:33:09 --> Controller Class Initialized
DEBUG - 2023-11-23 10:33:09 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/view_mapel/views/v_view_mapel.php
DEBUG - 2023-11-23 10:33:09 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-11-23 10:33:09 --> Final output sent to browser
DEBUG - 2023-11-23 10:33:09 --> Total execution time: 0.0334
INFO - 2023-11-23 10:33:11 --> Config Class Initialized
INFO - 2023-11-23 10:33:11 --> Hooks Class Initialized
DEBUG - 2023-11-23 10:33:11 --> UTF-8 Support Enabled
INFO - 2023-11-23 10:33:11 --> Utf8 Class Initialized
INFO - 2023-11-23 10:33:11 --> URI Class Initialized
INFO - 2023-11-23 10:33:11 --> Router Class Initialized
INFO - 2023-11-23 10:33:11 --> Output Class Initialized
INFO - 2023-11-23 10:33:11 --> Security Class Initialized
DEBUG - 2023-11-23 10:33:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-23 10:33:11 --> Input Class Initialized
INFO - 2023-11-23 10:33:11 --> Language Class Initialized
INFO - 2023-11-23 10:33:11 --> Language Class Initialized
INFO - 2023-11-23 10:33:11 --> Config Class Initialized
INFO - 2023-11-23 10:33:11 --> Loader Class Initialized
INFO - 2023-11-23 10:33:11 --> Helper loaded: url_helper
INFO - 2023-11-23 10:33:11 --> Helper loaded: file_helper
INFO - 2023-11-23 10:33:11 --> Helper loaded: form_helper
INFO - 2023-11-23 10:33:11 --> Helper loaded: my_helper
INFO - 2023-11-23 10:33:11 --> Database Driver Class Initialized
INFO - 2023-11-23 10:33:11 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-23 10:33:11 --> Controller Class Initialized
DEBUG - 2023-11-23 10:33:11 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/views/list.php
DEBUG - 2023-11-23 10:33:11 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-11-23 10:33:11 --> Final output sent to browser
DEBUG - 2023-11-23 10:33:11 --> Total execution time: 0.1198
INFO - 2023-11-23 10:33:11 --> Config Class Initialized
INFO - 2023-11-23 10:33:11 --> Hooks Class Initialized
DEBUG - 2023-11-23 10:33:11 --> UTF-8 Support Enabled
INFO - 2023-11-23 10:33:11 --> Utf8 Class Initialized
INFO - 2023-11-23 10:33:11 --> URI Class Initialized
INFO - 2023-11-23 10:33:11 --> Router Class Initialized
INFO - 2023-11-23 10:33:11 --> Output Class Initialized
INFO - 2023-11-23 10:33:11 --> Security Class Initialized
DEBUG - 2023-11-23 10:33:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-23 10:33:11 --> Input Class Initialized
INFO - 2023-11-23 10:33:11 --> Language Class Initialized
INFO - 2023-11-23 10:33:11 --> Language Class Initialized
INFO - 2023-11-23 10:33:11 --> Config Class Initialized
INFO - 2023-11-23 10:33:11 --> Loader Class Initialized
INFO - 2023-11-23 10:33:11 --> Helper loaded: url_helper
INFO - 2023-11-23 10:33:11 --> Helper loaded: file_helper
INFO - 2023-11-23 10:33:11 --> Helper loaded: form_helper
INFO - 2023-11-23 10:33:11 --> Helper loaded: my_helper
INFO - 2023-11-23 10:33:11 --> Database Driver Class Initialized
INFO - 2023-11-23 10:33:12 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-23 10:33:12 --> Controller Class Initialized
INFO - 2023-11-23 10:33:13 --> Config Class Initialized
INFO - 2023-11-23 10:33:13 --> Hooks Class Initialized
DEBUG - 2023-11-23 10:33:13 --> UTF-8 Support Enabled
INFO - 2023-11-23 10:33:13 --> Utf8 Class Initialized
INFO - 2023-11-23 10:33:13 --> URI Class Initialized
INFO - 2023-11-23 10:33:13 --> Router Class Initialized
INFO - 2023-11-23 10:33:14 --> Output Class Initialized
INFO - 2023-11-23 10:33:14 --> Security Class Initialized
DEBUG - 2023-11-23 10:33:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-23 10:33:14 --> Input Class Initialized
INFO - 2023-11-23 10:33:14 --> Language Class Initialized
INFO - 2023-11-23 10:33:14 --> Language Class Initialized
INFO - 2023-11-23 10:33:14 --> Config Class Initialized
INFO - 2023-11-23 10:33:14 --> Loader Class Initialized
INFO - 2023-11-23 10:33:14 --> Helper loaded: url_helper
INFO - 2023-11-23 10:33:14 --> Helper loaded: file_helper
INFO - 2023-11-23 10:33:14 --> Helper loaded: form_helper
INFO - 2023-11-23 10:33:14 --> Helper loaded: my_helper
INFO - 2023-11-23 10:33:14 --> Database Driver Class Initialized
INFO - 2023-11-23 10:33:14 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-23 10:33:14 --> Controller Class Initialized
INFO - 2023-11-23 10:33:14 --> Final output sent to browser
DEBUG - 2023-11-23 10:33:14 --> Total execution time: 0.0460
INFO - 2023-11-23 10:41:14 --> Config Class Initialized
INFO - 2023-11-23 10:41:14 --> Hooks Class Initialized
DEBUG - 2023-11-23 10:41:14 --> UTF-8 Support Enabled
INFO - 2023-11-23 10:41:14 --> Utf8 Class Initialized
INFO - 2023-11-23 10:41:14 --> URI Class Initialized
INFO - 2023-11-23 10:41:14 --> Router Class Initialized
INFO - 2023-11-23 10:41:14 --> Output Class Initialized
INFO - 2023-11-23 10:41:14 --> Security Class Initialized
DEBUG - 2023-11-23 10:41:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-23 10:41:14 --> Input Class Initialized
INFO - 2023-11-23 10:41:14 --> Language Class Initialized
INFO - 2023-11-23 10:41:14 --> Language Class Initialized
INFO - 2023-11-23 10:41:14 --> Config Class Initialized
INFO - 2023-11-23 10:41:14 --> Loader Class Initialized
INFO - 2023-11-23 10:41:14 --> Helper loaded: url_helper
INFO - 2023-11-23 10:41:14 --> Helper loaded: file_helper
INFO - 2023-11-23 10:41:14 --> Helper loaded: form_helper
INFO - 2023-11-23 10:41:14 --> Helper loaded: my_helper
INFO - 2023-11-23 10:41:14 --> Database Driver Class Initialized
INFO - 2023-11-23 10:41:14 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-23 10:41:14 --> Controller Class Initialized
DEBUG - 2023-11-23 10:41:14 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/view_mapel/views/v_view_mapel.php
DEBUG - 2023-11-23 10:41:14 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-11-23 10:41:14 --> Final output sent to browser
DEBUG - 2023-11-23 10:41:14 --> Total execution time: 0.0517
INFO - 2023-11-23 10:41:18 --> Config Class Initialized
INFO - 2023-11-23 10:41:18 --> Hooks Class Initialized
DEBUG - 2023-11-23 10:41:18 --> UTF-8 Support Enabled
INFO - 2023-11-23 10:41:18 --> Utf8 Class Initialized
INFO - 2023-11-23 10:41:18 --> URI Class Initialized
INFO - 2023-11-23 10:41:18 --> Router Class Initialized
INFO - 2023-11-23 10:41:18 --> Output Class Initialized
INFO - 2023-11-23 10:41:18 --> Security Class Initialized
DEBUG - 2023-11-23 10:41:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-23 10:41:18 --> Input Class Initialized
INFO - 2023-11-23 10:41:18 --> Language Class Initialized
INFO - 2023-11-23 10:41:18 --> Language Class Initialized
INFO - 2023-11-23 10:41:18 --> Config Class Initialized
INFO - 2023-11-23 10:41:18 --> Loader Class Initialized
INFO - 2023-11-23 10:41:18 --> Helper loaded: url_helper
INFO - 2023-11-23 10:41:18 --> Helper loaded: file_helper
INFO - 2023-11-23 10:41:18 --> Helper loaded: form_helper
INFO - 2023-11-23 10:41:18 --> Helper loaded: my_helper
INFO - 2023-11-23 10:41:18 --> Database Driver Class Initialized
INFO - 2023-11-23 10:41:18 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-23 10:41:18 --> Controller Class Initialized
DEBUG - 2023-11-23 10:41:18 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/views/list.php
DEBUG - 2023-11-23 10:41:18 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-11-23 10:41:18 --> Final output sent to browser
DEBUG - 2023-11-23 10:41:18 --> Total execution time: 0.0438
INFO - 2023-11-23 10:41:18 --> Config Class Initialized
INFO - 2023-11-23 10:41:18 --> Hooks Class Initialized
DEBUG - 2023-11-23 10:41:18 --> UTF-8 Support Enabled
INFO - 2023-11-23 10:41:18 --> Utf8 Class Initialized
INFO - 2023-11-23 10:41:18 --> URI Class Initialized
INFO - 2023-11-23 10:41:18 --> Router Class Initialized
INFO - 2023-11-23 10:41:18 --> Output Class Initialized
INFO - 2023-11-23 10:41:18 --> Security Class Initialized
DEBUG - 2023-11-23 10:41:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-23 10:41:18 --> Input Class Initialized
INFO - 2023-11-23 10:41:18 --> Language Class Initialized
INFO - 2023-11-23 10:41:18 --> Language Class Initialized
INFO - 2023-11-23 10:41:18 --> Config Class Initialized
INFO - 2023-11-23 10:41:18 --> Loader Class Initialized
INFO - 2023-11-23 10:41:18 --> Helper loaded: url_helper
INFO - 2023-11-23 10:41:18 --> Helper loaded: file_helper
INFO - 2023-11-23 10:41:18 --> Helper loaded: form_helper
INFO - 2023-11-23 10:41:18 --> Helper loaded: my_helper
INFO - 2023-11-23 10:41:18 --> Database Driver Class Initialized
INFO - 2023-11-23 10:41:18 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-23 10:41:18 --> Controller Class Initialized
INFO - 2023-11-23 10:41:53 --> Config Class Initialized
INFO - 2023-11-23 10:41:53 --> Hooks Class Initialized
DEBUG - 2023-11-23 10:41:53 --> UTF-8 Support Enabled
INFO - 2023-11-23 10:41:53 --> Utf8 Class Initialized
INFO - 2023-11-23 10:41:53 --> URI Class Initialized
INFO - 2023-11-23 10:41:53 --> Router Class Initialized
INFO - 2023-11-23 10:41:53 --> Output Class Initialized
INFO - 2023-11-23 10:41:53 --> Security Class Initialized
DEBUG - 2023-11-23 10:41:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-23 10:41:53 --> Input Class Initialized
INFO - 2023-11-23 10:41:53 --> Language Class Initialized
INFO - 2023-11-23 10:41:53 --> Language Class Initialized
INFO - 2023-11-23 10:41:53 --> Config Class Initialized
INFO - 2023-11-23 10:41:53 --> Loader Class Initialized
INFO - 2023-11-23 10:41:53 --> Helper loaded: url_helper
INFO - 2023-11-23 10:41:53 --> Helper loaded: file_helper
INFO - 2023-11-23 10:41:53 --> Helper loaded: form_helper
INFO - 2023-11-23 10:41:53 --> Helper loaded: my_helper
INFO - 2023-11-23 10:41:53 --> Database Driver Class Initialized
INFO - 2023-11-23 10:41:53 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-23 10:41:53 --> Controller Class Initialized
INFO - 2023-11-23 10:41:53 --> Final output sent to browser
DEBUG - 2023-11-23 10:41:53 --> Total execution time: 0.0326
INFO - 2023-11-23 10:42:08 --> Config Class Initialized
INFO - 2023-11-23 10:42:08 --> Hooks Class Initialized
DEBUG - 2023-11-23 10:42:08 --> UTF-8 Support Enabled
INFO - 2023-11-23 10:42:08 --> Utf8 Class Initialized
INFO - 2023-11-23 10:42:08 --> URI Class Initialized
INFO - 2023-11-23 10:42:08 --> Router Class Initialized
INFO - 2023-11-23 10:42:08 --> Output Class Initialized
INFO - 2023-11-23 10:42:08 --> Security Class Initialized
DEBUG - 2023-11-23 10:42:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-23 10:42:08 --> Input Class Initialized
INFO - 2023-11-23 10:42:08 --> Language Class Initialized
INFO - 2023-11-23 10:42:08 --> Language Class Initialized
INFO - 2023-11-23 10:42:08 --> Config Class Initialized
INFO - 2023-11-23 10:42:08 --> Loader Class Initialized
INFO - 2023-11-23 10:42:08 --> Helper loaded: url_helper
INFO - 2023-11-23 10:42:08 --> Helper loaded: file_helper
INFO - 2023-11-23 10:42:08 --> Helper loaded: form_helper
INFO - 2023-11-23 10:42:08 --> Helper loaded: my_helper
INFO - 2023-11-23 10:42:08 --> Database Driver Class Initialized
INFO - 2023-11-23 10:42:08 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-23 10:42:08 --> Controller Class Initialized
INFO - 2023-11-23 10:42:08 --> Final output sent to browser
DEBUG - 2023-11-23 10:42:08 --> Total execution time: 0.0387
INFO - 2023-11-23 10:42:08 --> Config Class Initialized
INFO - 2023-11-23 10:42:08 --> Hooks Class Initialized
DEBUG - 2023-11-23 10:42:08 --> UTF-8 Support Enabled
INFO - 2023-11-23 10:42:08 --> Utf8 Class Initialized
INFO - 2023-11-23 10:42:08 --> URI Class Initialized
INFO - 2023-11-23 10:42:08 --> Router Class Initialized
INFO - 2023-11-23 10:42:08 --> Output Class Initialized
INFO - 2023-11-23 10:42:08 --> Security Class Initialized
DEBUG - 2023-11-23 10:42:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-23 10:42:08 --> Input Class Initialized
INFO - 2023-11-23 10:42:08 --> Language Class Initialized
INFO - 2023-11-23 10:42:08 --> Language Class Initialized
INFO - 2023-11-23 10:42:08 --> Config Class Initialized
INFO - 2023-11-23 10:42:08 --> Loader Class Initialized
INFO - 2023-11-23 10:42:08 --> Helper loaded: url_helper
INFO - 2023-11-23 10:42:08 --> Helper loaded: file_helper
INFO - 2023-11-23 10:42:08 --> Helper loaded: form_helper
INFO - 2023-11-23 10:42:08 --> Helper loaded: my_helper
INFO - 2023-11-23 10:42:08 --> Database Driver Class Initialized
INFO - 2023-11-23 10:42:08 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-23 10:42:08 --> Controller Class Initialized
INFO - 2023-11-23 10:42:10 --> Config Class Initialized
INFO - 2023-11-23 10:42:10 --> Hooks Class Initialized
DEBUG - 2023-11-23 10:42:10 --> UTF-8 Support Enabled
INFO - 2023-11-23 10:42:10 --> Utf8 Class Initialized
INFO - 2023-11-23 10:42:10 --> URI Class Initialized
INFO - 2023-11-23 10:42:10 --> Router Class Initialized
INFO - 2023-11-23 10:42:10 --> Output Class Initialized
INFO - 2023-11-23 10:42:10 --> Security Class Initialized
DEBUG - 2023-11-23 10:42:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-23 10:42:10 --> Input Class Initialized
INFO - 2023-11-23 10:42:10 --> Language Class Initialized
INFO - 2023-11-23 10:42:10 --> Language Class Initialized
INFO - 2023-11-23 10:42:10 --> Config Class Initialized
INFO - 2023-11-23 10:42:10 --> Loader Class Initialized
INFO - 2023-11-23 10:42:10 --> Helper loaded: url_helper
INFO - 2023-11-23 10:42:10 --> Helper loaded: file_helper
INFO - 2023-11-23 10:42:10 --> Helper loaded: form_helper
INFO - 2023-11-23 10:42:10 --> Helper loaded: my_helper
INFO - 2023-11-23 10:42:10 --> Database Driver Class Initialized
INFO - 2023-11-23 10:42:10 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-23 10:42:10 --> Controller Class Initialized
INFO - 2023-11-23 10:42:10 --> Final output sent to browser
DEBUG - 2023-11-23 10:42:10 --> Total execution time: 0.0311
INFO - 2023-11-23 10:42:16 --> Config Class Initialized
INFO - 2023-11-23 10:42:16 --> Hooks Class Initialized
DEBUG - 2023-11-23 10:42:16 --> UTF-8 Support Enabled
INFO - 2023-11-23 10:42:16 --> Utf8 Class Initialized
INFO - 2023-11-23 10:42:16 --> URI Class Initialized
INFO - 2023-11-23 10:42:16 --> Router Class Initialized
INFO - 2023-11-23 10:42:16 --> Output Class Initialized
INFO - 2023-11-23 10:42:16 --> Security Class Initialized
DEBUG - 2023-11-23 10:42:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-23 10:42:16 --> Input Class Initialized
INFO - 2023-11-23 10:42:16 --> Language Class Initialized
INFO - 2023-11-23 10:42:16 --> Language Class Initialized
INFO - 2023-11-23 10:42:16 --> Config Class Initialized
INFO - 2023-11-23 10:42:16 --> Loader Class Initialized
INFO - 2023-11-23 10:42:16 --> Helper loaded: url_helper
INFO - 2023-11-23 10:42:16 --> Helper loaded: file_helper
INFO - 2023-11-23 10:42:16 --> Helper loaded: form_helper
INFO - 2023-11-23 10:42:16 --> Helper loaded: my_helper
INFO - 2023-11-23 10:42:16 --> Database Driver Class Initialized
INFO - 2023-11-23 10:42:16 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-23 10:42:16 --> Controller Class Initialized
INFO - 2023-11-23 10:42:16 --> Final output sent to browser
DEBUG - 2023-11-23 10:42:16 --> Total execution time: 0.0362
INFO - 2023-11-23 10:42:16 --> Config Class Initialized
INFO - 2023-11-23 10:42:16 --> Hooks Class Initialized
DEBUG - 2023-11-23 10:42:16 --> UTF-8 Support Enabled
INFO - 2023-11-23 10:42:16 --> Utf8 Class Initialized
INFO - 2023-11-23 10:42:16 --> URI Class Initialized
INFO - 2023-11-23 10:42:16 --> Router Class Initialized
INFO - 2023-11-23 10:42:16 --> Output Class Initialized
INFO - 2023-11-23 10:42:16 --> Security Class Initialized
DEBUG - 2023-11-23 10:42:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-23 10:42:16 --> Input Class Initialized
INFO - 2023-11-23 10:42:16 --> Language Class Initialized
INFO - 2023-11-23 10:42:16 --> Language Class Initialized
INFO - 2023-11-23 10:42:16 --> Config Class Initialized
INFO - 2023-11-23 10:42:16 --> Loader Class Initialized
INFO - 2023-11-23 10:42:16 --> Helper loaded: url_helper
INFO - 2023-11-23 10:42:16 --> Helper loaded: file_helper
INFO - 2023-11-23 10:42:16 --> Helper loaded: form_helper
INFO - 2023-11-23 10:42:16 --> Helper loaded: my_helper
INFO - 2023-11-23 10:42:16 --> Database Driver Class Initialized
INFO - 2023-11-23 10:42:16 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-23 10:42:16 --> Controller Class Initialized
INFO - 2023-11-23 10:42:18 --> Config Class Initialized
INFO - 2023-11-23 10:42:18 --> Hooks Class Initialized
DEBUG - 2023-11-23 10:42:18 --> UTF-8 Support Enabled
INFO - 2023-11-23 10:42:18 --> Utf8 Class Initialized
INFO - 2023-11-23 10:42:18 --> URI Class Initialized
INFO - 2023-11-23 10:42:18 --> Router Class Initialized
INFO - 2023-11-23 10:42:18 --> Output Class Initialized
INFO - 2023-11-23 10:42:18 --> Security Class Initialized
DEBUG - 2023-11-23 10:42:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-23 10:42:18 --> Input Class Initialized
INFO - 2023-11-23 10:42:18 --> Language Class Initialized
INFO - 2023-11-23 10:42:18 --> Language Class Initialized
INFO - 2023-11-23 10:42:18 --> Config Class Initialized
INFO - 2023-11-23 10:42:18 --> Loader Class Initialized
INFO - 2023-11-23 10:42:18 --> Helper loaded: url_helper
INFO - 2023-11-23 10:42:18 --> Helper loaded: file_helper
INFO - 2023-11-23 10:42:18 --> Helper loaded: form_helper
INFO - 2023-11-23 10:42:18 --> Helper loaded: my_helper
INFO - 2023-11-23 10:42:18 --> Database Driver Class Initialized
INFO - 2023-11-23 10:42:18 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-23 10:42:18 --> Controller Class Initialized
INFO - 2023-11-23 10:42:18 --> Final output sent to browser
DEBUG - 2023-11-23 10:42:18 --> Total execution time: 0.0666
INFO - 2023-11-23 10:43:02 --> Config Class Initialized
INFO - 2023-11-23 10:43:02 --> Hooks Class Initialized
DEBUG - 2023-11-23 10:43:02 --> UTF-8 Support Enabled
INFO - 2023-11-23 10:43:02 --> Utf8 Class Initialized
INFO - 2023-11-23 10:43:02 --> URI Class Initialized
INFO - 2023-11-23 10:43:02 --> Router Class Initialized
INFO - 2023-11-23 10:43:02 --> Output Class Initialized
INFO - 2023-11-23 10:43:02 --> Security Class Initialized
DEBUG - 2023-11-23 10:43:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-23 10:43:02 --> Input Class Initialized
INFO - 2023-11-23 10:43:02 --> Language Class Initialized
INFO - 2023-11-23 10:43:02 --> Language Class Initialized
INFO - 2023-11-23 10:43:02 --> Config Class Initialized
INFO - 2023-11-23 10:43:02 --> Loader Class Initialized
INFO - 2023-11-23 10:43:02 --> Helper loaded: url_helper
INFO - 2023-11-23 10:43:02 --> Helper loaded: file_helper
INFO - 2023-11-23 10:43:02 --> Helper loaded: form_helper
INFO - 2023-11-23 10:43:02 --> Helper loaded: my_helper
INFO - 2023-11-23 10:43:02 --> Database Driver Class Initialized
INFO - 2023-11-23 10:43:02 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-23 10:43:02 --> Controller Class Initialized
INFO - 2023-11-23 10:43:02 --> Final output sent to browser
DEBUG - 2023-11-23 10:43:02 --> Total execution time: 0.1124
INFO - 2023-11-23 10:43:02 --> Config Class Initialized
INFO - 2023-11-23 10:43:02 --> Hooks Class Initialized
DEBUG - 2023-11-23 10:43:02 --> UTF-8 Support Enabled
INFO - 2023-11-23 10:43:02 --> Utf8 Class Initialized
INFO - 2023-11-23 10:43:02 --> URI Class Initialized
INFO - 2023-11-23 10:43:02 --> Router Class Initialized
INFO - 2023-11-23 10:43:02 --> Output Class Initialized
INFO - 2023-11-23 10:43:02 --> Security Class Initialized
DEBUG - 2023-11-23 10:43:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-23 10:43:02 --> Input Class Initialized
INFO - 2023-11-23 10:43:02 --> Language Class Initialized
INFO - 2023-11-23 10:43:02 --> Language Class Initialized
INFO - 2023-11-23 10:43:02 --> Config Class Initialized
INFO - 2023-11-23 10:43:02 --> Loader Class Initialized
INFO - 2023-11-23 10:43:02 --> Helper loaded: url_helper
INFO - 2023-11-23 10:43:02 --> Helper loaded: file_helper
INFO - 2023-11-23 10:43:02 --> Helper loaded: form_helper
INFO - 2023-11-23 10:43:02 --> Helper loaded: my_helper
INFO - 2023-11-23 10:43:02 --> Database Driver Class Initialized
INFO - 2023-11-23 10:43:02 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-23 10:43:02 --> Controller Class Initialized
INFO - 2023-11-23 11:17:19 --> Config Class Initialized
INFO - 2023-11-23 11:17:19 --> Hooks Class Initialized
DEBUG - 2023-11-23 11:17:19 --> UTF-8 Support Enabled
INFO - 2023-11-23 11:17:19 --> Utf8 Class Initialized
INFO - 2023-11-23 11:17:19 --> URI Class Initialized
INFO - 2023-11-23 11:17:19 --> Router Class Initialized
INFO - 2023-11-23 11:17:19 --> Output Class Initialized
INFO - 2023-11-23 11:17:19 --> Security Class Initialized
DEBUG - 2023-11-23 11:17:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-23 11:17:19 --> Input Class Initialized
INFO - 2023-11-23 11:17:19 --> Language Class Initialized
INFO - 2023-11-23 11:17:19 --> Language Class Initialized
INFO - 2023-11-23 11:17:19 --> Config Class Initialized
INFO - 2023-11-23 11:17:19 --> Loader Class Initialized
INFO - 2023-11-23 11:17:19 --> Helper loaded: url_helper
INFO - 2023-11-23 11:17:19 --> Helper loaded: file_helper
INFO - 2023-11-23 11:17:19 --> Helper loaded: form_helper
INFO - 2023-11-23 11:17:19 --> Helper loaded: my_helper
INFO - 2023-11-23 11:17:19 --> Database Driver Class Initialized
INFO - 2023-11-23 11:17:19 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-23 11:17:19 --> Controller Class Initialized
INFO - 2023-11-23 11:17:19 --> Final output sent to browser
DEBUG - 2023-11-23 11:17:19 --> Total execution time: 0.0693
INFO - 2023-11-23 11:17:41 --> Config Class Initialized
INFO - 2023-11-23 11:17:41 --> Hooks Class Initialized
DEBUG - 2023-11-23 11:17:41 --> UTF-8 Support Enabled
INFO - 2023-11-23 11:17:41 --> Utf8 Class Initialized
INFO - 2023-11-23 11:17:41 --> URI Class Initialized
INFO - 2023-11-23 11:17:41 --> Router Class Initialized
INFO - 2023-11-23 11:17:41 --> Output Class Initialized
INFO - 2023-11-23 11:17:41 --> Security Class Initialized
DEBUG - 2023-11-23 11:17:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-23 11:17:41 --> Input Class Initialized
INFO - 2023-11-23 11:17:41 --> Language Class Initialized
INFO - 2023-11-23 11:17:41 --> Language Class Initialized
INFO - 2023-11-23 11:17:41 --> Config Class Initialized
INFO - 2023-11-23 11:17:41 --> Loader Class Initialized
INFO - 2023-11-23 11:17:41 --> Helper loaded: url_helper
INFO - 2023-11-23 11:17:41 --> Helper loaded: file_helper
INFO - 2023-11-23 11:17:41 --> Helper loaded: form_helper
INFO - 2023-11-23 11:17:41 --> Helper loaded: my_helper
INFO - 2023-11-23 11:17:41 --> Database Driver Class Initialized
INFO - 2023-11-23 11:17:41 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-23 11:17:41 --> Controller Class Initialized
INFO - 2023-11-23 11:17:41 --> Final output sent to browser
DEBUG - 2023-11-23 11:17:41 --> Total execution time: 0.0832
INFO - 2023-11-23 11:17:50 --> Config Class Initialized
INFO - 2023-11-23 11:17:50 --> Hooks Class Initialized
DEBUG - 2023-11-23 11:17:50 --> UTF-8 Support Enabled
INFO - 2023-11-23 11:17:50 --> Utf8 Class Initialized
INFO - 2023-11-23 11:17:50 --> URI Class Initialized
INFO - 2023-11-23 11:17:50 --> Router Class Initialized
INFO - 2023-11-23 11:17:50 --> Output Class Initialized
INFO - 2023-11-23 11:17:50 --> Security Class Initialized
DEBUG - 2023-11-23 11:17:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-23 11:17:50 --> Input Class Initialized
INFO - 2023-11-23 11:17:50 --> Language Class Initialized
INFO - 2023-11-23 11:17:50 --> Language Class Initialized
INFO - 2023-11-23 11:17:50 --> Config Class Initialized
INFO - 2023-11-23 11:17:50 --> Loader Class Initialized
INFO - 2023-11-23 11:17:50 --> Helper loaded: url_helper
INFO - 2023-11-23 11:17:50 --> Helper loaded: file_helper
INFO - 2023-11-23 11:17:50 --> Helper loaded: form_helper
INFO - 2023-11-23 11:17:50 --> Helper loaded: my_helper
INFO - 2023-11-23 11:17:50 --> Database Driver Class Initialized
INFO - 2023-11-23 11:17:50 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-23 11:17:50 --> Controller Class Initialized
INFO - 2023-11-23 11:17:50 --> Final output sent to browser
DEBUG - 2023-11-23 11:17:50 --> Total execution time: 0.0433
INFO - 2023-11-23 11:17:56 --> Config Class Initialized
INFO - 2023-11-23 11:17:56 --> Hooks Class Initialized
DEBUG - 2023-11-23 11:17:56 --> UTF-8 Support Enabled
INFO - 2023-11-23 11:17:56 --> Utf8 Class Initialized
INFO - 2023-11-23 11:17:56 --> URI Class Initialized
INFO - 2023-11-23 11:17:56 --> Router Class Initialized
INFO - 2023-11-23 11:17:56 --> Output Class Initialized
INFO - 2023-11-23 11:17:56 --> Security Class Initialized
DEBUG - 2023-11-23 11:17:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-23 11:17:56 --> Input Class Initialized
INFO - 2023-11-23 11:17:56 --> Language Class Initialized
INFO - 2023-11-23 11:17:56 --> Language Class Initialized
INFO - 2023-11-23 11:17:56 --> Config Class Initialized
INFO - 2023-11-23 11:17:56 --> Loader Class Initialized
INFO - 2023-11-23 11:17:56 --> Helper loaded: url_helper
INFO - 2023-11-23 11:17:56 --> Helper loaded: file_helper
INFO - 2023-11-23 11:17:56 --> Helper loaded: form_helper
INFO - 2023-11-23 11:17:56 --> Helper loaded: my_helper
INFO - 2023-11-23 11:17:56 --> Database Driver Class Initialized
INFO - 2023-11-23 11:17:56 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-23 11:17:56 --> Controller Class Initialized
INFO - 2023-11-23 11:17:56 --> Final output sent to browser
DEBUG - 2023-11-23 11:17:56 --> Total execution time: 0.0456
INFO - 2023-11-23 11:18:03 --> Config Class Initialized
INFO - 2023-11-23 11:18:03 --> Hooks Class Initialized
DEBUG - 2023-11-23 11:18:03 --> UTF-8 Support Enabled
INFO - 2023-11-23 11:18:03 --> Utf8 Class Initialized
INFO - 2023-11-23 11:18:03 --> URI Class Initialized
INFO - 2023-11-23 11:18:03 --> Router Class Initialized
INFO - 2023-11-23 11:18:03 --> Output Class Initialized
INFO - 2023-11-23 11:18:03 --> Security Class Initialized
DEBUG - 2023-11-23 11:18:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-23 11:18:03 --> Input Class Initialized
INFO - 2023-11-23 11:18:03 --> Language Class Initialized
INFO - 2023-11-23 11:18:03 --> Language Class Initialized
INFO - 2023-11-23 11:18:03 --> Config Class Initialized
INFO - 2023-11-23 11:18:03 --> Loader Class Initialized
INFO - 2023-11-23 11:18:03 --> Helper loaded: url_helper
INFO - 2023-11-23 11:18:03 --> Helper loaded: file_helper
INFO - 2023-11-23 11:18:03 --> Helper loaded: form_helper
INFO - 2023-11-23 11:18:03 --> Helper loaded: my_helper
INFO - 2023-11-23 11:18:03 --> Database Driver Class Initialized
INFO - 2023-11-23 11:18:03 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-23 11:18:03 --> Controller Class Initialized
INFO - 2023-11-23 11:18:03 --> Final output sent to browser
DEBUG - 2023-11-23 11:18:03 --> Total execution time: 0.0557
INFO - 2023-11-23 11:20:57 --> Config Class Initialized
INFO - 2023-11-23 11:20:57 --> Hooks Class Initialized
DEBUG - 2023-11-23 11:20:57 --> UTF-8 Support Enabled
INFO - 2023-11-23 11:20:57 --> Utf8 Class Initialized
INFO - 2023-11-23 11:20:57 --> URI Class Initialized
INFO - 2023-11-23 11:20:57 --> Router Class Initialized
INFO - 2023-11-23 11:20:57 --> Output Class Initialized
INFO - 2023-11-23 11:20:57 --> Security Class Initialized
DEBUG - 2023-11-23 11:20:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-23 11:20:57 --> Input Class Initialized
INFO - 2023-11-23 11:20:57 --> Language Class Initialized
INFO - 2023-11-23 11:20:57 --> Language Class Initialized
INFO - 2023-11-23 11:20:57 --> Config Class Initialized
INFO - 2023-11-23 11:20:57 --> Loader Class Initialized
INFO - 2023-11-23 11:20:57 --> Helper loaded: url_helper
INFO - 2023-11-23 11:20:57 --> Helper loaded: file_helper
INFO - 2023-11-23 11:20:57 --> Helper loaded: form_helper
INFO - 2023-11-23 11:20:57 --> Helper loaded: my_helper
INFO - 2023-11-23 11:20:57 --> Database Driver Class Initialized
INFO - 2023-11-23 11:20:57 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-23 11:20:57 --> Controller Class Initialized
INFO - 2023-11-23 11:20:57 --> Final output sent to browser
DEBUG - 2023-11-23 11:20:57 --> Total execution time: 0.0309
INFO - 2023-11-23 11:21:18 --> Config Class Initialized
INFO - 2023-11-23 11:21:18 --> Hooks Class Initialized
DEBUG - 2023-11-23 11:21:18 --> UTF-8 Support Enabled
INFO - 2023-11-23 11:21:18 --> Utf8 Class Initialized
INFO - 2023-11-23 11:21:18 --> URI Class Initialized
INFO - 2023-11-23 11:21:18 --> Router Class Initialized
INFO - 2023-11-23 11:21:18 --> Output Class Initialized
INFO - 2023-11-23 11:21:18 --> Security Class Initialized
DEBUG - 2023-11-23 11:21:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-23 11:21:18 --> Input Class Initialized
INFO - 2023-11-23 11:21:18 --> Language Class Initialized
INFO - 2023-11-23 11:21:18 --> Language Class Initialized
INFO - 2023-11-23 11:21:18 --> Config Class Initialized
INFO - 2023-11-23 11:21:18 --> Loader Class Initialized
INFO - 2023-11-23 11:21:18 --> Helper loaded: url_helper
INFO - 2023-11-23 11:21:18 --> Helper loaded: file_helper
INFO - 2023-11-23 11:21:18 --> Helper loaded: form_helper
INFO - 2023-11-23 11:21:18 --> Helper loaded: my_helper
INFO - 2023-11-23 11:21:18 --> Database Driver Class Initialized
INFO - 2023-11-23 11:21:18 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-23 11:21:18 --> Controller Class Initialized
INFO - 2023-11-23 11:21:18 --> Final output sent to browser
DEBUG - 2023-11-23 11:21:18 --> Total execution time: 0.0682
INFO - 2023-11-23 11:21:18 --> Config Class Initialized
INFO - 2023-11-23 11:21:18 --> Hooks Class Initialized
DEBUG - 2023-11-23 11:21:18 --> UTF-8 Support Enabled
INFO - 2023-11-23 11:21:18 --> Utf8 Class Initialized
INFO - 2023-11-23 11:21:18 --> URI Class Initialized
INFO - 2023-11-23 11:21:18 --> Router Class Initialized
INFO - 2023-11-23 11:21:18 --> Output Class Initialized
INFO - 2023-11-23 11:21:18 --> Security Class Initialized
DEBUG - 2023-11-23 11:21:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-23 11:21:18 --> Input Class Initialized
INFO - 2023-11-23 11:21:18 --> Language Class Initialized
INFO - 2023-11-23 11:21:18 --> Language Class Initialized
INFO - 2023-11-23 11:21:18 --> Config Class Initialized
INFO - 2023-11-23 11:21:18 --> Loader Class Initialized
INFO - 2023-11-23 11:21:18 --> Helper loaded: url_helper
INFO - 2023-11-23 11:21:18 --> Helper loaded: file_helper
INFO - 2023-11-23 11:21:18 --> Helper loaded: form_helper
INFO - 2023-11-23 11:21:18 --> Helper loaded: my_helper
INFO - 2023-11-23 11:21:18 --> Database Driver Class Initialized
INFO - 2023-11-23 11:21:18 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-23 11:21:18 --> Controller Class Initialized
INFO - 2023-11-23 11:21:21 --> Config Class Initialized
INFO - 2023-11-23 11:21:21 --> Hooks Class Initialized
DEBUG - 2023-11-23 11:21:21 --> UTF-8 Support Enabled
INFO - 2023-11-23 11:21:21 --> Utf8 Class Initialized
INFO - 2023-11-23 11:21:21 --> URI Class Initialized
INFO - 2023-11-23 11:21:21 --> Router Class Initialized
INFO - 2023-11-23 11:21:21 --> Output Class Initialized
INFO - 2023-11-23 11:21:21 --> Security Class Initialized
DEBUG - 2023-11-23 11:21:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-23 11:21:21 --> Input Class Initialized
INFO - 2023-11-23 11:21:21 --> Language Class Initialized
INFO - 2023-11-23 11:21:21 --> Language Class Initialized
INFO - 2023-11-23 11:21:21 --> Config Class Initialized
INFO - 2023-11-23 11:21:21 --> Loader Class Initialized
INFO - 2023-11-23 11:21:21 --> Helper loaded: url_helper
INFO - 2023-11-23 11:21:21 --> Helper loaded: file_helper
INFO - 2023-11-23 11:21:21 --> Helper loaded: form_helper
INFO - 2023-11-23 11:21:21 --> Helper loaded: my_helper
INFO - 2023-11-23 11:21:21 --> Database Driver Class Initialized
INFO - 2023-11-23 11:21:21 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-23 11:21:21 --> Controller Class Initialized
INFO - 2023-11-23 11:21:21 --> Final output sent to browser
DEBUG - 2023-11-23 11:21:21 --> Total execution time: 0.0339
INFO - 2023-11-23 11:21:41 --> Config Class Initialized
INFO - 2023-11-23 11:21:41 --> Hooks Class Initialized
DEBUG - 2023-11-23 11:21:41 --> UTF-8 Support Enabled
INFO - 2023-11-23 11:21:41 --> Utf8 Class Initialized
INFO - 2023-11-23 11:21:41 --> URI Class Initialized
INFO - 2023-11-23 11:21:41 --> Router Class Initialized
INFO - 2023-11-23 11:21:41 --> Output Class Initialized
INFO - 2023-11-23 11:21:41 --> Security Class Initialized
DEBUG - 2023-11-23 11:21:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-23 11:21:41 --> Input Class Initialized
INFO - 2023-11-23 11:21:41 --> Language Class Initialized
INFO - 2023-11-23 11:21:41 --> Language Class Initialized
INFO - 2023-11-23 11:21:41 --> Config Class Initialized
INFO - 2023-11-23 11:21:41 --> Loader Class Initialized
INFO - 2023-11-23 11:21:41 --> Helper loaded: url_helper
INFO - 2023-11-23 11:21:41 --> Helper loaded: file_helper
INFO - 2023-11-23 11:21:41 --> Helper loaded: form_helper
INFO - 2023-11-23 11:21:41 --> Helper loaded: my_helper
INFO - 2023-11-23 11:21:41 --> Database Driver Class Initialized
INFO - 2023-11-23 11:21:41 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-23 11:21:41 --> Controller Class Initialized
INFO - 2023-11-23 11:21:41 --> Final output sent to browser
DEBUG - 2023-11-23 11:21:41 --> Total execution time: 0.0389
INFO - 2023-11-23 11:21:41 --> Config Class Initialized
INFO - 2023-11-23 11:21:41 --> Hooks Class Initialized
DEBUG - 2023-11-23 11:21:41 --> UTF-8 Support Enabled
INFO - 2023-11-23 11:21:41 --> Utf8 Class Initialized
INFO - 2023-11-23 11:21:41 --> URI Class Initialized
INFO - 2023-11-23 11:21:41 --> Router Class Initialized
INFO - 2023-11-23 11:21:41 --> Output Class Initialized
INFO - 2023-11-23 11:21:41 --> Security Class Initialized
DEBUG - 2023-11-23 11:21:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-23 11:21:41 --> Input Class Initialized
INFO - 2023-11-23 11:21:41 --> Language Class Initialized
INFO - 2023-11-23 11:21:41 --> Language Class Initialized
INFO - 2023-11-23 11:21:41 --> Config Class Initialized
INFO - 2023-11-23 11:21:41 --> Loader Class Initialized
INFO - 2023-11-23 11:21:41 --> Helper loaded: url_helper
INFO - 2023-11-23 11:21:41 --> Helper loaded: file_helper
INFO - 2023-11-23 11:21:41 --> Helper loaded: form_helper
INFO - 2023-11-23 11:21:41 --> Helper loaded: my_helper
INFO - 2023-11-23 11:21:41 --> Database Driver Class Initialized
INFO - 2023-11-23 11:21:41 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-23 11:21:41 --> Controller Class Initialized
INFO - 2023-11-23 11:21:43 --> Config Class Initialized
INFO - 2023-11-23 11:21:43 --> Hooks Class Initialized
DEBUG - 2023-11-23 11:21:43 --> UTF-8 Support Enabled
INFO - 2023-11-23 11:21:43 --> Utf8 Class Initialized
INFO - 2023-11-23 11:21:43 --> URI Class Initialized
INFO - 2023-11-23 11:21:43 --> Router Class Initialized
INFO - 2023-11-23 11:21:43 --> Output Class Initialized
INFO - 2023-11-23 11:21:43 --> Security Class Initialized
DEBUG - 2023-11-23 11:21:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-23 11:21:43 --> Input Class Initialized
INFO - 2023-11-23 11:21:43 --> Language Class Initialized
INFO - 2023-11-23 11:21:43 --> Language Class Initialized
INFO - 2023-11-23 11:21:43 --> Config Class Initialized
INFO - 2023-11-23 11:21:43 --> Loader Class Initialized
INFO - 2023-11-23 11:21:43 --> Helper loaded: url_helper
INFO - 2023-11-23 11:21:43 --> Helper loaded: file_helper
INFO - 2023-11-23 11:21:43 --> Helper loaded: form_helper
INFO - 2023-11-23 11:21:43 --> Helper loaded: my_helper
INFO - 2023-11-23 11:21:43 --> Database Driver Class Initialized
INFO - 2023-11-23 11:21:43 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-23 11:21:43 --> Controller Class Initialized
INFO - 2023-11-23 11:21:43 --> Final output sent to browser
DEBUG - 2023-11-23 11:21:43 --> Total execution time: 0.0423
INFO - 2023-11-23 11:23:21 --> Config Class Initialized
INFO - 2023-11-23 11:23:21 --> Hooks Class Initialized
DEBUG - 2023-11-23 11:23:21 --> UTF-8 Support Enabled
INFO - 2023-11-23 11:23:21 --> Utf8 Class Initialized
INFO - 2023-11-23 11:23:21 --> URI Class Initialized
INFO - 2023-11-23 11:23:21 --> Router Class Initialized
INFO - 2023-11-23 11:23:21 --> Output Class Initialized
INFO - 2023-11-23 11:23:21 --> Security Class Initialized
DEBUG - 2023-11-23 11:23:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-23 11:23:21 --> Input Class Initialized
INFO - 2023-11-23 11:23:21 --> Language Class Initialized
INFO - 2023-11-23 11:23:21 --> Language Class Initialized
INFO - 2023-11-23 11:23:21 --> Config Class Initialized
INFO - 2023-11-23 11:23:21 --> Loader Class Initialized
INFO - 2023-11-23 11:23:21 --> Helper loaded: url_helper
INFO - 2023-11-23 11:23:21 --> Helper loaded: file_helper
INFO - 2023-11-23 11:23:21 --> Helper loaded: form_helper
INFO - 2023-11-23 11:23:21 --> Helper loaded: my_helper
INFO - 2023-11-23 11:23:21 --> Database Driver Class Initialized
INFO - 2023-11-23 11:23:21 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-23 11:23:21 --> Controller Class Initialized
INFO - 2023-11-23 11:23:21 --> Final output sent to browser
DEBUG - 2023-11-23 11:23:21 --> Total execution time: 0.0660
INFO - 2023-11-23 11:23:39 --> Config Class Initialized
INFO - 2023-11-23 11:23:39 --> Hooks Class Initialized
DEBUG - 2023-11-23 11:23:39 --> UTF-8 Support Enabled
INFO - 2023-11-23 11:23:39 --> Utf8 Class Initialized
INFO - 2023-11-23 11:23:39 --> URI Class Initialized
INFO - 2023-11-23 11:23:39 --> Router Class Initialized
INFO - 2023-11-23 11:23:39 --> Output Class Initialized
INFO - 2023-11-23 11:23:39 --> Security Class Initialized
DEBUG - 2023-11-23 11:23:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-23 11:23:39 --> Input Class Initialized
INFO - 2023-11-23 11:23:39 --> Language Class Initialized
INFO - 2023-11-23 11:23:39 --> Language Class Initialized
INFO - 2023-11-23 11:23:39 --> Config Class Initialized
INFO - 2023-11-23 11:23:39 --> Loader Class Initialized
INFO - 2023-11-23 11:23:39 --> Helper loaded: url_helper
INFO - 2023-11-23 11:23:39 --> Helper loaded: file_helper
INFO - 2023-11-23 11:23:39 --> Helper loaded: form_helper
INFO - 2023-11-23 11:23:39 --> Helper loaded: my_helper
INFO - 2023-11-23 11:23:39 --> Database Driver Class Initialized
INFO - 2023-11-23 11:23:39 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-23 11:23:39 --> Controller Class Initialized
INFO - 2023-11-23 11:23:39 --> Final output sent to browser
DEBUG - 2023-11-23 11:23:39 --> Total execution time: 0.0732
INFO - 2023-11-23 11:23:51 --> Config Class Initialized
INFO - 2023-11-23 11:23:51 --> Hooks Class Initialized
DEBUG - 2023-11-23 11:23:51 --> UTF-8 Support Enabled
INFO - 2023-11-23 11:23:51 --> Utf8 Class Initialized
INFO - 2023-11-23 11:23:51 --> URI Class Initialized
INFO - 2023-11-23 11:23:51 --> Router Class Initialized
INFO - 2023-11-23 11:23:51 --> Output Class Initialized
INFO - 2023-11-23 11:23:51 --> Security Class Initialized
DEBUG - 2023-11-23 11:23:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-23 11:23:51 --> Input Class Initialized
INFO - 2023-11-23 11:23:51 --> Language Class Initialized
INFO - 2023-11-23 11:23:51 --> Language Class Initialized
INFO - 2023-11-23 11:23:51 --> Config Class Initialized
INFO - 2023-11-23 11:23:51 --> Loader Class Initialized
INFO - 2023-11-23 11:23:51 --> Helper loaded: url_helper
INFO - 2023-11-23 11:23:51 --> Helper loaded: file_helper
INFO - 2023-11-23 11:23:51 --> Helper loaded: form_helper
INFO - 2023-11-23 11:23:51 --> Helper loaded: my_helper
INFO - 2023-11-23 11:23:51 --> Database Driver Class Initialized
INFO - 2023-11-23 11:23:51 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-23 11:23:51 --> Controller Class Initialized
INFO - 2023-11-23 11:23:51 --> Final output sent to browser
DEBUG - 2023-11-23 11:23:51 --> Total execution time: 0.0349
INFO - 2023-11-23 11:23:58 --> Config Class Initialized
INFO - 2023-11-23 11:23:58 --> Hooks Class Initialized
DEBUG - 2023-11-23 11:23:58 --> UTF-8 Support Enabled
INFO - 2023-11-23 11:23:58 --> Utf8 Class Initialized
INFO - 2023-11-23 11:23:58 --> URI Class Initialized
INFO - 2023-11-23 11:23:58 --> Router Class Initialized
INFO - 2023-11-23 11:23:58 --> Output Class Initialized
INFO - 2023-11-23 11:23:58 --> Security Class Initialized
DEBUG - 2023-11-23 11:23:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-23 11:23:58 --> Input Class Initialized
INFO - 2023-11-23 11:23:58 --> Language Class Initialized
INFO - 2023-11-23 11:23:58 --> Language Class Initialized
INFO - 2023-11-23 11:23:58 --> Config Class Initialized
INFO - 2023-11-23 11:23:58 --> Loader Class Initialized
INFO - 2023-11-23 11:23:58 --> Helper loaded: url_helper
INFO - 2023-11-23 11:23:58 --> Helper loaded: file_helper
INFO - 2023-11-23 11:23:58 --> Helper loaded: form_helper
INFO - 2023-11-23 11:23:58 --> Helper loaded: my_helper
INFO - 2023-11-23 11:23:58 --> Database Driver Class Initialized
INFO - 2023-11-23 11:23:58 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-23 11:23:58 --> Controller Class Initialized
INFO - 2023-11-23 11:23:58 --> Final output sent to browser
DEBUG - 2023-11-23 11:23:58 --> Total execution time: 0.0355
INFO - 2023-11-23 11:24:03 --> Config Class Initialized
INFO - 2023-11-23 11:24:03 --> Hooks Class Initialized
DEBUG - 2023-11-23 11:24:03 --> UTF-8 Support Enabled
INFO - 2023-11-23 11:24:03 --> Utf8 Class Initialized
INFO - 2023-11-23 11:24:03 --> URI Class Initialized
INFO - 2023-11-23 11:24:03 --> Router Class Initialized
INFO - 2023-11-23 11:24:03 --> Output Class Initialized
INFO - 2023-11-23 11:24:03 --> Security Class Initialized
DEBUG - 2023-11-23 11:24:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-23 11:24:03 --> Input Class Initialized
INFO - 2023-11-23 11:24:03 --> Language Class Initialized
INFO - 2023-11-23 11:24:03 --> Language Class Initialized
INFO - 2023-11-23 11:24:03 --> Config Class Initialized
INFO - 2023-11-23 11:24:03 --> Loader Class Initialized
INFO - 2023-11-23 11:24:03 --> Helper loaded: url_helper
INFO - 2023-11-23 11:24:03 --> Helper loaded: file_helper
INFO - 2023-11-23 11:24:03 --> Helper loaded: form_helper
INFO - 2023-11-23 11:24:03 --> Helper loaded: my_helper
INFO - 2023-11-23 11:24:03 --> Database Driver Class Initialized
INFO - 2023-11-23 11:24:03 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-23 11:24:03 --> Controller Class Initialized
INFO - 2023-11-23 11:24:03 --> Final output sent to browser
DEBUG - 2023-11-23 11:24:03 --> Total execution time: 0.0426
INFO - 2023-11-23 11:24:11 --> Config Class Initialized
INFO - 2023-11-23 11:24:11 --> Hooks Class Initialized
DEBUG - 2023-11-23 11:24:11 --> UTF-8 Support Enabled
INFO - 2023-11-23 11:24:11 --> Utf8 Class Initialized
INFO - 2023-11-23 11:24:11 --> URI Class Initialized
INFO - 2023-11-23 11:24:11 --> Router Class Initialized
INFO - 2023-11-23 11:24:11 --> Output Class Initialized
INFO - 2023-11-23 11:24:11 --> Security Class Initialized
DEBUG - 2023-11-23 11:24:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-23 11:24:11 --> Input Class Initialized
INFO - 2023-11-23 11:24:11 --> Language Class Initialized
INFO - 2023-11-23 11:24:11 --> Language Class Initialized
INFO - 2023-11-23 11:24:11 --> Config Class Initialized
INFO - 2023-11-23 11:24:11 --> Loader Class Initialized
INFO - 2023-11-23 11:24:11 --> Helper loaded: url_helper
INFO - 2023-11-23 11:24:11 --> Helper loaded: file_helper
INFO - 2023-11-23 11:24:11 --> Helper loaded: form_helper
INFO - 2023-11-23 11:24:11 --> Helper loaded: my_helper
INFO - 2023-11-23 11:24:11 --> Database Driver Class Initialized
INFO - 2023-11-23 11:24:11 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-23 11:24:11 --> Controller Class Initialized
INFO - 2023-11-23 11:24:11 --> Final output sent to browser
DEBUG - 2023-11-23 11:24:11 --> Total execution time: 0.1070
INFO - 2023-11-23 11:24:16 --> Config Class Initialized
INFO - 2023-11-23 11:24:16 --> Hooks Class Initialized
DEBUG - 2023-11-23 11:24:16 --> UTF-8 Support Enabled
INFO - 2023-11-23 11:24:16 --> Utf8 Class Initialized
INFO - 2023-11-23 11:24:16 --> URI Class Initialized
INFO - 2023-11-23 11:24:16 --> Router Class Initialized
INFO - 2023-11-23 11:24:16 --> Output Class Initialized
INFO - 2023-11-23 11:24:16 --> Security Class Initialized
DEBUG - 2023-11-23 11:24:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-23 11:24:16 --> Input Class Initialized
INFO - 2023-11-23 11:24:16 --> Language Class Initialized
INFO - 2023-11-23 11:24:16 --> Language Class Initialized
INFO - 2023-11-23 11:24:16 --> Config Class Initialized
INFO - 2023-11-23 11:24:16 --> Loader Class Initialized
INFO - 2023-11-23 11:24:16 --> Helper loaded: url_helper
INFO - 2023-11-23 11:24:16 --> Helper loaded: file_helper
INFO - 2023-11-23 11:24:16 --> Helper loaded: form_helper
INFO - 2023-11-23 11:24:16 --> Helper loaded: my_helper
INFO - 2023-11-23 11:24:16 --> Database Driver Class Initialized
INFO - 2023-11-23 11:24:16 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-23 11:24:16 --> Controller Class Initialized
INFO - 2023-11-23 11:24:16 --> Final output sent to browser
DEBUG - 2023-11-23 11:24:16 --> Total execution time: 0.2166
INFO - 2023-11-23 11:34:38 --> Config Class Initialized
INFO - 2023-11-23 11:34:38 --> Hooks Class Initialized
DEBUG - 2023-11-23 11:34:38 --> UTF-8 Support Enabled
INFO - 2023-11-23 11:34:38 --> Utf8 Class Initialized
INFO - 2023-11-23 11:34:38 --> URI Class Initialized
INFO - 2023-11-23 11:34:38 --> Router Class Initialized
INFO - 2023-11-23 11:34:38 --> Output Class Initialized
INFO - 2023-11-23 11:34:38 --> Security Class Initialized
DEBUG - 2023-11-23 11:34:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-23 11:34:38 --> Input Class Initialized
INFO - 2023-11-23 11:34:38 --> Language Class Initialized
INFO - 2023-11-23 11:34:38 --> Language Class Initialized
INFO - 2023-11-23 11:34:38 --> Config Class Initialized
INFO - 2023-11-23 11:34:38 --> Loader Class Initialized
INFO - 2023-11-23 11:34:38 --> Helper loaded: url_helper
INFO - 2023-11-23 11:34:38 --> Helper loaded: file_helper
INFO - 2023-11-23 11:34:38 --> Helper loaded: form_helper
INFO - 2023-11-23 11:34:38 --> Helper loaded: my_helper
INFO - 2023-11-23 11:34:38 --> Database Driver Class Initialized
INFO - 2023-11-23 11:34:38 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-23 11:34:38 --> Controller Class Initialized
DEBUG - 2023-11-23 11:34:38 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/views/list.php
DEBUG - 2023-11-23 11:34:38 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-11-23 11:34:38 --> Final output sent to browser
DEBUG - 2023-11-23 11:34:38 --> Total execution time: 0.0463
INFO - 2023-11-23 11:34:38 --> Config Class Initialized
INFO - 2023-11-23 11:34:38 --> Hooks Class Initialized
DEBUG - 2023-11-23 11:34:38 --> UTF-8 Support Enabled
INFO - 2023-11-23 11:34:38 --> Utf8 Class Initialized
INFO - 2023-11-23 11:34:38 --> URI Class Initialized
INFO - 2023-11-23 11:34:38 --> Router Class Initialized
INFO - 2023-11-23 11:34:38 --> Output Class Initialized
INFO - 2023-11-23 11:34:38 --> Security Class Initialized
DEBUG - 2023-11-23 11:34:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-23 11:34:38 --> Input Class Initialized
INFO - 2023-11-23 11:34:38 --> Language Class Initialized
INFO - 2023-11-23 11:34:38 --> Language Class Initialized
INFO - 2023-11-23 11:34:38 --> Config Class Initialized
INFO - 2023-11-23 11:34:38 --> Loader Class Initialized
INFO - 2023-11-23 11:34:38 --> Helper loaded: url_helper
INFO - 2023-11-23 11:34:38 --> Helper loaded: file_helper
INFO - 2023-11-23 11:34:38 --> Helper loaded: form_helper
INFO - 2023-11-23 11:34:38 --> Helper loaded: my_helper
INFO - 2023-11-23 11:34:38 --> Database Driver Class Initialized
INFO - 2023-11-23 11:34:38 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-23 11:34:38 --> Controller Class Initialized
INFO - 2023-11-23 11:35:02 --> Config Class Initialized
INFO - 2023-11-23 11:35:02 --> Hooks Class Initialized
DEBUG - 2023-11-23 11:35:02 --> UTF-8 Support Enabled
INFO - 2023-11-23 11:35:02 --> Utf8 Class Initialized
INFO - 2023-11-23 11:35:02 --> URI Class Initialized
INFO - 2023-11-23 11:35:02 --> Router Class Initialized
INFO - 2023-11-23 11:35:02 --> Output Class Initialized
INFO - 2023-11-23 11:35:02 --> Security Class Initialized
DEBUG - 2023-11-23 11:35:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-23 11:35:02 --> Input Class Initialized
INFO - 2023-11-23 11:35:02 --> Language Class Initialized
INFO - 2023-11-23 11:35:02 --> Language Class Initialized
INFO - 2023-11-23 11:35:02 --> Config Class Initialized
INFO - 2023-11-23 11:35:02 --> Loader Class Initialized
INFO - 2023-11-23 11:35:02 --> Helper loaded: url_helper
INFO - 2023-11-23 11:35:02 --> Helper loaded: file_helper
INFO - 2023-11-23 11:35:02 --> Helper loaded: form_helper
INFO - 2023-11-23 11:35:02 --> Helper loaded: my_helper
INFO - 2023-11-23 11:35:02 --> Database Driver Class Initialized
INFO - 2023-11-23 11:35:02 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-23 11:35:02 --> Controller Class Initialized
INFO - 2023-11-23 11:35:02 --> Final output sent to browser
DEBUG - 2023-11-23 11:35:02 --> Total execution time: 0.0656
INFO - 2023-11-23 11:35:04 --> Config Class Initialized
INFO - 2023-11-23 11:35:04 --> Hooks Class Initialized
DEBUG - 2023-11-23 11:35:04 --> UTF-8 Support Enabled
INFO - 2023-11-23 11:35:04 --> Utf8 Class Initialized
INFO - 2023-11-23 11:35:04 --> URI Class Initialized
INFO - 2023-11-23 11:35:04 --> Router Class Initialized
INFO - 2023-11-23 11:35:04 --> Output Class Initialized
INFO - 2023-11-23 11:35:04 --> Security Class Initialized
DEBUG - 2023-11-23 11:35:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-23 11:35:04 --> Input Class Initialized
INFO - 2023-11-23 11:35:04 --> Language Class Initialized
INFO - 2023-11-23 11:35:04 --> Language Class Initialized
INFO - 2023-11-23 11:35:04 --> Config Class Initialized
INFO - 2023-11-23 11:35:04 --> Loader Class Initialized
INFO - 2023-11-23 11:35:04 --> Helper loaded: url_helper
INFO - 2023-11-23 11:35:04 --> Helper loaded: file_helper
INFO - 2023-11-23 11:35:04 --> Helper loaded: form_helper
INFO - 2023-11-23 11:35:04 --> Helper loaded: my_helper
INFO - 2023-11-23 11:35:04 --> Database Driver Class Initialized
INFO - 2023-11-23 11:35:04 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-23 11:35:04 --> Controller Class Initialized
INFO - 2023-11-23 11:35:04 --> Final output sent to browser
DEBUG - 2023-11-23 11:35:04 --> Total execution time: 0.0384
INFO - 2023-11-23 11:35:23 --> Config Class Initialized
INFO - 2023-11-23 11:35:23 --> Hooks Class Initialized
DEBUG - 2023-11-23 11:35:23 --> UTF-8 Support Enabled
INFO - 2023-11-23 11:35:23 --> Utf8 Class Initialized
INFO - 2023-11-23 11:35:23 --> URI Class Initialized
INFO - 2023-11-23 11:35:23 --> Router Class Initialized
INFO - 2023-11-23 11:35:23 --> Output Class Initialized
INFO - 2023-11-23 11:35:23 --> Security Class Initialized
DEBUG - 2023-11-23 11:35:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-23 11:35:23 --> Input Class Initialized
INFO - 2023-11-23 11:35:23 --> Language Class Initialized
INFO - 2023-11-23 11:35:23 --> Language Class Initialized
INFO - 2023-11-23 11:35:23 --> Config Class Initialized
INFO - 2023-11-23 11:35:23 --> Loader Class Initialized
INFO - 2023-11-23 11:35:23 --> Helper loaded: url_helper
INFO - 2023-11-23 11:35:23 --> Helper loaded: file_helper
INFO - 2023-11-23 11:35:23 --> Helper loaded: form_helper
INFO - 2023-11-23 11:35:23 --> Helper loaded: my_helper
INFO - 2023-11-23 11:35:23 --> Database Driver Class Initialized
INFO - 2023-11-23 11:35:23 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-23 11:35:23 --> Controller Class Initialized
INFO - 2023-11-23 11:35:23 --> Final output sent to browser
DEBUG - 2023-11-23 11:35:23 --> Total execution time: 0.0366
INFO - 2023-11-23 11:35:23 --> Config Class Initialized
INFO - 2023-11-23 11:35:23 --> Hooks Class Initialized
DEBUG - 2023-11-23 11:35:23 --> UTF-8 Support Enabled
INFO - 2023-11-23 11:35:23 --> Utf8 Class Initialized
INFO - 2023-11-23 11:35:23 --> URI Class Initialized
INFO - 2023-11-23 11:35:23 --> Router Class Initialized
INFO - 2023-11-23 11:35:23 --> Output Class Initialized
INFO - 2023-11-23 11:35:23 --> Security Class Initialized
DEBUG - 2023-11-23 11:35:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-23 11:35:23 --> Input Class Initialized
INFO - 2023-11-23 11:35:23 --> Language Class Initialized
INFO - 2023-11-23 11:35:23 --> Language Class Initialized
INFO - 2023-11-23 11:35:23 --> Config Class Initialized
INFO - 2023-11-23 11:35:23 --> Loader Class Initialized
INFO - 2023-11-23 11:35:23 --> Helper loaded: url_helper
INFO - 2023-11-23 11:35:23 --> Helper loaded: file_helper
INFO - 2023-11-23 11:35:23 --> Helper loaded: form_helper
INFO - 2023-11-23 11:35:23 --> Helper loaded: my_helper
INFO - 2023-11-23 11:35:23 --> Database Driver Class Initialized
INFO - 2023-11-23 11:35:23 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-23 11:35:23 --> Controller Class Initialized
INFO - 2023-11-23 11:35:32 --> Config Class Initialized
INFO - 2023-11-23 11:35:32 --> Hooks Class Initialized
DEBUG - 2023-11-23 11:35:32 --> UTF-8 Support Enabled
INFO - 2023-11-23 11:35:32 --> Utf8 Class Initialized
INFO - 2023-11-23 11:35:32 --> URI Class Initialized
INFO - 2023-11-23 11:35:32 --> Router Class Initialized
INFO - 2023-11-23 11:35:32 --> Output Class Initialized
INFO - 2023-11-23 11:35:32 --> Security Class Initialized
DEBUG - 2023-11-23 11:35:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-23 11:35:32 --> Input Class Initialized
INFO - 2023-11-23 11:35:32 --> Language Class Initialized
INFO - 2023-11-23 11:35:32 --> Language Class Initialized
INFO - 2023-11-23 11:35:32 --> Config Class Initialized
INFO - 2023-11-23 11:35:32 --> Loader Class Initialized
INFO - 2023-11-23 11:35:32 --> Helper loaded: url_helper
INFO - 2023-11-23 11:35:32 --> Helper loaded: file_helper
INFO - 2023-11-23 11:35:32 --> Helper loaded: form_helper
INFO - 2023-11-23 11:35:32 --> Helper loaded: my_helper
INFO - 2023-11-23 11:35:32 --> Database Driver Class Initialized
INFO - 2023-11-23 11:35:32 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-23 11:35:32 --> Controller Class Initialized
INFO - 2023-11-23 11:35:32 --> Final output sent to browser
DEBUG - 2023-11-23 11:35:32 --> Total execution time: 0.0447
INFO - 2023-11-23 11:36:23 --> Config Class Initialized
INFO - 2023-11-23 11:36:23 --> Hooks Class Initialized
DEBUG - 2023-11-23 11:36:23 --> UTF-8 Support Enabled
INFO - 2023-11-23 11:36:23 --> Utf8 Class Initialized
INFO - 2023-11-23 11:36:23 --> URI Class Initialized
INFO - 2023-11-23 11:36:23 --> Router Class Initialized
INFO - 2023-11-23 11:36:23 --> Output Class Initialized
INFO - 2023-11-23 11:36:23 --> Security Class Initialized
DEBUG - 2023-11-23 11:36:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-23 11:36:23 --> Input Class Initialized
INFO - 2023-11-23 11:36:23 --> Language Class Initialized
INFO - 2023-11-23 11:36:23 --> Language Class Initialized
INFO - 2023-11-23 11:36:23 --> Config Class Initialized
INFO - 2023-11-23 11:36:23 --> Loader Class Initialized
INFO - 2023-11-23 11:36:23 --> Helper loaded: url_helper
INFO - 2023-11-23 11:36:23 --> Helper loaded: file_helper
INFO - 2023-11-23 11:36:23 --> Helper loaded: form_helper
INFO - 2023-11-23 11:36:23 --> Helper loaded: my_helper
INFO - 2023-11-23 11:36:23 --> Database Driver Class Initialized
INFO - 2023-11-23 11:36:23 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-23 11:36:23 --> Controller Class Initialized
INFO - 2023-11-23 11:36:23 --> Final output sent to browser
DEBUG - 2023-11-23 11:36:23 --> Total execution time: 0.0328
INFO - 2023-11-23 11:37:21 --> Config Class Initialized
INFO - 2023-11-23 11:37:21 --> Hooks Class Initialized
DEBUG - 2023-11-23 11:37:21 --> UTF-8 Support Enabled
INFO - 2023-11-23 11:37:21 --> Utf8 Class Initialized
INFO - 2023-11-23 11:37:21 --> URI Class Initialized
INFO - 2023-11-23 11:37:21 --> Router Class Initialized
INFO - 2023-11-23 11:37:21 --> Output Class Initialized
INFO - 2023-11-23 11:37:21 --> Security Class Initialized
DEBUG - 2023-11-23 11:37:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-23 11:37:21 --> Input Class Initialized
INFO - 2023-11-23 11:37:21 --> Language Class Initialized
INFO - 2023-11-23 11:37:21 --> Language Class Initialized
INFO - 2023-11-23 11:37:21 --> Config Class Initialized
INFO - 2023-11-23 11:37:21 --> Loader Class Initialized
INFO - 2023-11-23 11:37:21 --> Helper loaded: url_helper
INFO - 2023-11-23 11:37:21 --> Helper loaded: file_helper
INFO - 2023-11-23 11:37:21 --> Helper loaded: form_helper
INFO - 2023-11-23 11:37:21 --> Helper loaded: my_helper
INFO - 2023-11-23 11:37:21 --> Database Driver Class Initialized
INFO - 2023-11-23 11:37:21 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-23 11:37:21 --> Controller Class Initialized
INFO - 2023-11-23 11:37:21 --> Final output sent to browser
DEBUG - 2023-11-23 11:37:21 --> Total execution time: 0.0488
INFO - 2023-11-23 11:37:21 --> Config Class Initialized
INFO - 2023-11-23 11:37:21 --> Hooks Class Initialized
DEBUG - 2023-11-23 11:37:21 --> UTF-8 Support Enabled
INFO - 2023-11-23 11:37:21 --> Utf8 Class Initialized
INFO - 2023-11-23 11:37:21 --> URI Class Initialized
INFO - 2023-11-23 11:37:21 --> Router Class Initialized
INFO - 2023-11-23 11:37:21 --> Output Class Initialized
INFO - 2023-11-23 11:37:21 --> Security Class Initialized
DEBUG - 2023-11-23 11:37:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-23 11:37:21 --> Input Class Initialized
INFO - 2023-11-23 11:37:21 --> Language Class Initialized
INFO - 2023-11-23 11:37:21 --> Language Class Initialized
INFO - 2023-11-23 11:37:21 --> Config Class Initialized
INFO - 2023-11-23 11:37:21 --> Loader Class Initialized
INFO - 2023-11-23 11:37:21 --> Helper loaded: url_helper
INFO - 2023-11-23 11:37:21 --> Helper loaded: file_helper
INFO - 2023-11-23 11:37:21 --> Helper loaded: form_helper
INFO - 2023-11-23 11:37:21 --> Helper loaded: my_helper
INFO - 2023-11-23 11:37:21 --> Database Driver Class Initialized
INFO - 2023-11-23 11:37:21 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-23 11:37:21 --> Controller Class Initialized
INFO - 2023-11-23 11:37:25 --> Config Class Initialized
INFO - 2023-11-23 11:37:25 --> Hooks Class Initialized
DEBUG - 2023-11-23 11:37:25 --> UTF-8 Support Enabled
INFO - 2023-11-23 11:37:25 --> Utf8 Class Initialized
INFO - 2023-11-23 11:37:25 --> URI Class Initialized
INFO - 2023-11-23 11:37:25 --> Router Class Initialized
INFO - 2023-11-23 11:37:25 --> Output Class Initialized
INFO - 2023-11-23 11:37:25 --> Security Class Initialized
DEBUG - 2023-11-23 11:37:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-23 11:37:25 --> Input Class Initialized
INFO - 2023-11-23 11:37:25 --> Language Class Initialized
INFO - 2023-11-23 11:37:25 --> Language Class Initialized
INFO - 2023-11-23 11:37:25 --> Config Class Initialized
INFO - 2023-11-23 11:37:25 --> Loader Class Initialized
INFO - 2023-11-23 11:37:25 --> Helper loaded: url_helper
INFO - 2023-11-23 11:37:25 --> Helper loaded: file_helper
INFO - 2023-11-23 11:37:25 --> Helper loaded: form_helper
INFO - 2023-11-23 11:37:25 --> Helper loaded: my_helper
INFO - 2023-11-23 11:37:25 --> Database Driver Class Initialized
INFO - 2023-11-23 11:37:25 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-23 11:37:25 --> Controller Class Initialized
INFO - 2023-11-23 11:37:25 --> Final output sent to browser
DEBUG - 2023-11-23 11:37:25 --> Total execution time: 0.1294
INFO - 2023-11-23 11:39:10 --> Config Class Initialized
INFO - 2023-11-23 11:39:10 --> Hooks Class Initialized
DEBUG - 2023-11-23 11:39:10 --> UTF-8 Support Enabled
INFO - 2023-11-23 11:39:10 --> Utf8 Class Initialized
INFO - 2023-11-23 11:39:10 --> URI Class Initialized
INFO - 2023-11-23 11:39:10 --> Router Class Initialized
INFO - 2023-11-23 11:39:10 --> Output Class Initialized
INFO - 2023-11-23 11:39:10 --> Security Class Initialized
DEBUG - 2023-11-23 11:39:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-23 11:39:10 --> Input Class Initialized
INFO - 2023-11-23 11:39:10 --> Language Class Initialized
INFO - 2023-11-23 11:39:10 --> Language Class Initialized
INFO - 2023-11-23 11:39:10 --> Config Class Initialized
INFO - 2023-11-23 11:39:10 --> Loader Class Initialized
INFO - 2023-11-23 11:39:10 --> Helper loaded: url_helper
INFO - 2023-11-23 11:39:10 --> Helper loaded: file_helper
INFO - 2023-11-23 11:39:10 --> Helper loaded: form_helper
INFO - 2023-11-23 11:39:10 --> Helper loaded: my_helper
INFO - 2023-11-23 11:39:10 --> Database Driver Class Initialized
INFO - 2023-11-23 11:39:10 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-23 11:39:10 --> Controller Class Initialized
INFO - 2023-11-23 11:39:10 --> Final output sent to browser
DEBUG - 2023-11-23 11:39:10 --> Total execution time: 0.1083
INFO - 2023-11-23 11:39:15 --> Config Class Initialized
INFO - 2023-11-23 11:39:15 --> Hooks Class Initialized
DEBUG - 2023-11-23 11:39:15 --> UTF-8 Support Enabled
INFO - 2023-11-23 11:39:15 --> Utf8 Class Initialized
INFO - 2023-11-23 11:39:15 --> URI Class Initialized
INFO - 2023-11-23 11:39:15 --> Router Class Initialized
INFO - 2023-11-23 11:39:15 --> Output Class Initialized
INFO - 2023-11-23 11:39:15 --> Security Class Initialized
DEBUG - 2023-11-23 11:39:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-23 11:39:15 --> Input Class Initialized
INFO - 2023-11-23 11:39:15 --> Language Class Initialized
INFO - 2023-11-23 11:39:15 --> Language Class Initialized
INFO - 2023-11-23 11:39:15 --> Config Class Initialized
INFO - 2023-11-23 11:39:15 --> Loader Class Initialized
INFO - 2023-11-23 11:39:15 --> Helper loaded: url_helper
INFO - 2023-11-23 11:39:15 --> Helper loaded: file_helper
INFO - 2023-11-23 11:39:15 --> Helper loaded: form_helper
INFO - 2023-11-23 11:39:15 --> Helper loaded: my_helper
INFO - 2023-11-23 11:39:15 --> Database Driver Class Initialized
INFO - 2023-11-23 11:39:15 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-23 11:39:15 --> Controller Class Initialized
INFO - 2023-11-23 11:39:15 --> Final output sent to browser
DEBUG - 2023-11-23 11:39:15 --> Total execution time: 0.0391
INFO - 2023-11-23 11:39:26 --> Config Class Initialized
INFO - 2023-11-23 11:39:26 --> Hooks Class Initialized
DEBUG - 2023-11-23 11:39:26 --> UTF-8 Support Enabled
INFO - 2023-11-23 11:39:26 --> Utf8 Class Initialized
INFO - 2023-11-23 11:39:26 --> URI Class Initialized
INFO - 2023-11-23 11:39:26 --> Router Class Initialized
INFO - 2023-11-23 11:39:26 --> Output Class Initialized
INFO - 2023-11-23 11:39:26 --> Security Class Initialized
DEBUG - 2023-11-23 11:39:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-23 11:39:26 --> Input Class Initialized
INFO - 2023-11-23 11:39:26 --> Language Class Initialized
INFO - 2023-11-23 11:39:26 --> Language Class Initialized
INFO - 2023-11-23 11:39:26 --> Config Class Initialized
INFO - 2023-11-23 11:39:26 --> Loader Class Initialized
INFO - 2023-11-23 11:39:26 --> Helper loaded: url_helper
INFO - 2023-11-23 11:39:26 --> Helper loaded: file_helper
INFO - 2023-11-23 11:39:26 --> Helper loaded: form_helper
INFO - 2023-11-23 11:39:26 --> Helper loaded: my_helper
INFO - 2023-11-23 11:39:26 --> Database Driver Class Initialized
INFO - 2023-11-23 11:39:26 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-23 11:39:26 --> Controller Class Initialized
INFO - 2023-11-23 11:39:26 --> Final output sent to browser
DEBUG - 2023-11-23 11:39:26 --> Total execution time: 0.0491
INFO - 2023-11-23 11:39:26 --> Config Class Initialized
INFO - 2023-11-23 11:39:26 --> Hooks Class Initialized
DEBUG - 2023-11-23 11:39:26 --> UTF-8 Support Enabled
INFO - 2023-11-23 11:39:26 --> Utf8 Class Initialized
INFO - 2023-11-23 11:39:26 --> URI Class Initialized
INFO - 2023-11-23 11:39:26 --> Router Class Initialized
INFO - 2023-11-23 11:39:26 --> Output Class Initialized
INFO - 2023-11-23 11:39:26 --> Security Class Initialized
DEBUG - 2023-11-23 11:39:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-23 11:39:26 --> Input Class Initialized
INFO - 2023-11-23 11:39:26 --> Language Class Initialized
INFO - 2023-11-23 11:39:26 --> Language Class Initialized
INFO - 2023-11-23 11:39:26 --> Config Class Initialized
INFO - 2023-11-23 11:39:26 --> Loader Class Initialized
INFO - 2023-11-23 11:39:26 --> Helper loaded: url_helper
INFO - 2023-11-23 11:39:26 --> Helper loaded: file_helper
INFO - 2023-11-23 11:39:26 --> Helper loaded: form_helper
INFO - 2023-11-23 11:39:26 --> Helper loaded: my_helper
INFO - 2023-11-23 11:39:26 --> Database Driver Class Initialized
INFO - 2023-11-23 11:39:26 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-23 11:39:26 --> Controller Class Initialized
INFO - 2023-11-23 11:39:30 --> Config Class Initialized
INFO - 2023-11-23 11:39:30 --> Hooks Class Initialized
DEBUG - 2023-11-23 11:39:30 --> UTF-8 Support Enabled
INFO - 2023-11-23 11:39:30 --> Utf8 Class Initialized
INFO - 2023-11-23 11:39:30 --> URI Class Initialized
INFO - 2023-11-23 11:39:30 --> Router Class Initialized
INFO - 2023-11-23 11:39:30 --> Output Class Initialized
INFO - 2023-11-23 11:39:30 --> Security Class Initialized
DEBUG - 2023-11-23 11:39:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-23 11:39:30 --> Input Class Initialized
INFO - 2023-11-23 11:39:30 --> Language Class Initialized
INFO - 2023-11-23 11:39:30 --> Language Class Initialized
INFO - 2023-11-23 11:39:30 --> Config Class Initialized
INFO - 2023-11-23 11:39:30 --> Loader Class Initialized
INFO - 2023-11-23 11:39:30 --> Helper loaded: url_helper
INFO - 2023-11-23 11:39:30 --> Helper loaded: file_helper
INFO - 2023-11-23 11:39:30 --> Helper loaded: form_helper
INFO - 2023-11-23 11:39:30 --> Helper loaded: my_helper
INFO - 2023-11-23 11:39:30 --> Database Driver Class Initialized
INFO - 2023-11-23 11:39:30 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-23 11:39:30 --> Controller Class Initialized
INFO - 2023-11-23 11:39:30 --> Final output sent to browser
DEBUG - 2023-11-23 11:39:30 --> Total execution time: 0.0359
INFO - 2023-11-23 11:39:46 --> Config Class Initialized
INFO - 2023-11-23 11:39:46 --> Hooks Class Initialized
DEBUG - 2023-11-23 11:39:46 --> UTF-8 Support Enabled
INFO - 2023-11-23 11:39:46 --> Utf8 Class Initialized
INFO - 2023-11-23 11:39:46 --> URI Class Initialized
INFO - 2023-11-23 11:39:46 --> Router Class Initialized
INFO - 2023-11-23 11:39:46 --> Output Class Initialized
INFO - 2023-11-23 11:39:46 --> Security Class Initialized
DEBUG - 2023-11-23 11:39:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-23 11:39:46 --> Input Class Initialized
INFO - 2023-11-23 11:39:46 --> Language Class Initialized
INFO - 2023-11-23 11:39:46 --> Language Class Initialized
INFO - 2023-11-23 11:39:46 --> Config Class Initialized
INFO - 2023-11-23 11:39:46 --> Loader Class Initialized
INFO - 2023-11-23 11:39:46 --> Helper loaded: url_helper
INFO - 2023-11-23 11:39:46 --> Helper loaded: file_helper
INFO - 2023-11-23 11:39:46 --> Helper loaded: form_helper
INFO - 2023-11-23 11:39:46 --> Helper loaded: my_helper
INFO - 2023-11-23 11:39:46 --> Database Driver Class Initialized
INFO - 2023-11-23 11:39:46 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-23 11:39:46 --> Controller Class Initialized
INFO - 2023-11-23 11:39:46 --> Final output sent to browser
DEBUG - 2023-11-23 11:39:46 --> Total execution time: 0.0356
INFO - 2023-11-23 11:39:46 --> Config Class Initialized
INFO - 2023-11-23 11:39:46 --> Hooks Class Initialized
DEBUG - 2023-11-23 11:39:46 --> UTF-8 Support Enabled
INFO - 2023-11-23 11:39:46 --> Utf8 Class Initialized
INFO - 2023-11-23 11:39:46 --> URI Class Initialized
INFO - 2023-11-23 11:39:46 --> Router Class Initialized
INFO - 2023-11-23 11:39:46 --> Output Class Initialized
INFO - 2023-11-23 11:39:46 --> Security Class Initialized
DEBUG - 2023-11-23 11:39:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-23 11:39:46 --> Input Class Initialized
INFO - 2023-11-23 11:39:46 --> Language Class Initialized
INFO - 2023-11-23 11:39:46 --> Language Class Initialized
INFO - 2023-11-23 11:39:46 --> Config Class Initialized
INFO - 2023-11-23 11:39:46 --> Loader Class Initialized
INFO - 2023-11-23 11:39:46 --> Helper loaded: url_helper
INFO - 2023-11-23 11:39:46 --> Helper loaded: file_helper
INFO - 2023-11-23 11:39:46 --> Helper loaded: form_helper
INFO - 2023-11-23 11:39:46 --> Helper loaded: my_helper
INFO - 2023-11-23 11:39:46 --> Database Driver Class Initialized
INFO - 2023-11-23 11:39:46 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-23 11:39:46 --> Controller Class Initialized
INFO - 2023-11-23 11:43:15 --> Config Class Initialized
INFO - 2023-11-23 11:43:15 --> Hooks Class Initialized
DEBUG - 2023-11-23 11:43:15 --> UTF-8 Support Enabled
INFO - 2023-11-23 11:43:15 --> Utf8 Class Initialized
INFO - 2023-11-23 11:43:15 --> URI Class Initialized
INFO - 2023-11-23 11:43:15 --> Router Class Initialized
INFO - 2023-11-23 11:43:15 --> Output Class Initialized
INFO - 2023-11-23 11:43:15 --> Security Class Initialized
DEBUG - 2023-11-23 11:43:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-23 11:43:15 --> Input Class Initialized
INFO - 2023-11-23 11:43:15 --> Language Class Initialized
INFO - 2023-11-23 11:43:15 --> Language Class Initialized
INFO - 2023-11-23 11:43:15 --> Config Class Initialized
INFO - 2023-11-23 11:43:15 --> Loader Class Initialized
INFO - 2023-11-23 11:43:15 --> Helper loaded: url_helper
INFO - 2023-11-23 11:43:15 --> Helper loaded: file_helper
INFO - 2023-11-23 11:43:15 --> Helper loaded: form_helper
INFO - 2023-11-23 11:43:15 --> Helper loaded: my_helper
INFO - 2023-11-23 11:43:15 --> Database Driver Class Initialized
INFO - 2023-11-23 11:43:15 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-23 11:43:15 --> Controller Class Initialized
INFO - 2023-11-23 11:43:15 --> Final output sent to browser
DEBUG - 2023-11-23 11:43:15 --> Total execution time: 0.0737
INFO - 2023-11-23 11:44:45 --> Config Class Initialized
INFO - 2023-11-23 11:44:45 --> Hooks Class Initialized
DEBUG - 2023-11-23 11:44:45 --> UTF-8 Support Enabled
INFO - 2023-11-23 11:44:45 --> Utf8 Class Initialized
INFO - 2023-11-23 11:44:45 --> URI Class Initialized
INFO - 2023-11-23 11:44:45 --> Router Class Initialized
INFO - 2023-11-23 11:44:45 --> Output Class Initialized
INFO - 2023-11-23 11:44:45 --> Security Class Initialized
DEBUG - 2023-11-23 11:44:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-23 11:44:46 --> Input Class Initialized
INFO - 2023-11-23 11:44:46 --> Language Class Initialized
INFO - 2023-11-23 11:44:46 --> Language Class Initialized
INFO - 2023-11-23 11:44:46 --> Config Class Initialized
INFO - 2023-11-23 11:44:46 --> Loader Class Initialized
INFO - 2023-11-23 11:44:46 --> Helper loaded: url_helper
INFO - 2023-11-23 11:44:46 --> Helper loaded: file_helper
INFO - 2023-11-23 11:44:46 --> Helper loaded: form_helper
INFO - 2023-11-23 11:44:46 --> Helper loaded: my_helper
INFO - 2023-11-23 11:44:46 --> Database Driver Class Initialized
INFO - 2023-11-23 11:44:46 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-23 11:44:46 --> Controller Class Initialized
INFO - 2023-11-23 11:44:46 --> Final output sent to browser
DEBUG - 2023-11-23 11:44:46 --> Total execution time: 0.0625
INFO - 2023-11-23 11:44:51 --> Config Class Initialized
INFO - 2023-11-23 11:44:51 --> Hooks Class Initialized
DEBUG - 2023-11-23 11:44:51 --> UTF-8 Support Enabled
INFO - 2023-11-23 11:44:51 --> Utf8 Class Initialized
INFO - 2023-11-23 11:44:51 --> URI Class Initialized
INFO - 2023-11-23 11:44:51 --> Router Class Initialized
INFO - 2023-11-23 11:44:51 --> Output Class Initialized
INFO - 2023-11-23 11:44:51 --> Security Class Initialized
DEBUG - 2023-11-23 11:44:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-23 11:44:51 --> Input Class Initialized
INFO - 2023-11-23 11:44:51 --> Language Class Initialized
INFO - 2023-11-23 11:44:51 --> Language Class Initialized
INFO - 2023-11-23 11:44:51 --> Config Class Initialized
INFO - 2023-11-23 11:44:51 --> Loader Class Initialized
INFO - 2023-11-23 11:44:51 --> Helper loaded: url_helper
INFO - 2023-11-23 11:44:51 --> Helper loaded: file_helper
INFO - 2023-11-23 11:44:51 --> Helper loaded: form_helper
INFO - 2023-11-23 11:44:51 --> Helper loaded: my_helper
INFO - 2023-11-23 11:44:51 --> Database Driver Class Initialized
INFO - 2023-11-23 11:44:51 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-23 11:44:51 --> Controller Class Initialized
INFO - 2023-11-23 11:44:51 --> Final output sent to browser
DEBUG - 2023-11-23 11:44:51 --> Total execution time: 0.1904
INFO - 2023-11-23 11:44:53 --> Config Class Initialized
INFO - 2023-11-23 11:44:53 --> Hooks Class Initialized
DEBUG - 2023-11-23 11:44:53 --> UTF-8 Support Enabled
INFO - 2023-11-23 11:44:53 --> Utf8 Class Initialized
INFO - 2023-11-23 11:44:53 --> URI Class Initialized
INFO - 2023-11-23 11:44:53 --> Router Class Initialized
INFO - 2023-11-23 11:44:53 --> Output Class Initialized
INFO - 2023-11-23 11:44:53 --> Security Class Initialized
DEBUG - 2023-11-23 11:44:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-23 11:44:53 --> Input Class Initialized
INFO - 2023-11-23 11:44:53 --> Language Class Initialized
INFO - 2023-11-23 11:44:53 --> Language Class Initialized
INFO - 2023-11-23 11:44:53 --> Config Class Initialized
INFO - 2023-11-23 11:44:53 --> Loader Class Initialized
INFO - 2023-11-23 11:44:53 --> Helper loaded: url_helper
INFO - 2023-11-23 11:44:53 --> Helper loaded: file_helper
INFO - 2023-11-23 11:44:53 --> Helper loaded: form_helper
INFO - 2023-11-23 11:44:53 --> Helper loaded: my_helper
INFO - 2023-11-23 11:44:53 --> Database Driver Class Initialized
INFO - 2023-11-23 11:44:53 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-23 11:44:53 --> Controller Class Initialized
INFO - 2023-11-23 11:44:53 --> Final output sent to browser
DEBUG - 2023-11-23 11:44:53 --> Total execution time: 0.0385
