<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2024-10-28 07:53:55 --> Config Class Initialized
INFO - 2024-10-28 07:53:55 --> Hooks Class Initialized
DEBUG - 2024-10-28 07:53:55 --> UTF-8 Support Enabled
INFO - 2024-10-28 07:53:55 --> Utf8 Class Initialized
INFO - 2024-10-28 07:53:55 --> URI Class Initialized
INFO - 2024-10-28 07:53:55 --> Router Class Initialized
INFO - 2024-10-28 07:53:55 --> Output Class Initialized
INFO - 2024-10-28 07:53:55 --> Security Class Initialized
DEBUG - 2024-10-28 07:53:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-28 07:53:55 --> Input Class Initialized
INFO - 2024-10-28 07:53:55 --> Language Class Initialized
INFO - 2024-10-28 07:53:55 --> Language Class Initialized
INFO - 2024-10-28 07:53:55 --> Config Class Initialized
INFO - 2024-10-28 07:53:55 --> Loader Class Initialized
INFO - 2024-10-28 07:53:55 --> Helper loaded: url_helper
INFO - 2024-10-28 07:53:55 --> Helper loaded: file_helper
INFO - 2024-10-28 07:53:55 --> Helper loaded: form_helper
INFO - 2024-10-28 07:53:55 --> Helper loaded: my_helper
INFO - 2024-10-28 07:53:55 --> Database Driver Class Initialized
INFO - 2024-10-28 07:53:55 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-28 07:53:55 --> Controller Class Initialized
INFO - 2024-10-28 07:53:55 --> Config Class Initialized
INFO - 2024-10-28 07:53:55 --> Hooks Class Initialized
DEBUG - 2024-10-28 07:53:55 --> UTF-8 Support Enabled
INFO - 2024-10-28 07:53:55 --> Utf8 Class Initialized
INFO - 2024-10-28 07:53:55 --> URI Class Initialized
INFO - 2024-10-28 07:53:55 --> Router Class Initialized
INFO - 2024-10-28 07:53:55 --> Output Class Initialized
INFO - 2024-10-28 07:53:55 --> Security Class Initialized
DEBUG - 2024-10-28 07:53:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-28 07:53:55 --> Input Class Initialized
INFO - 2024-10-28 07:53:55 --> Language Class Initialized
INFO - 2024-10-28 07:53:55 --> Language Class Initialized
INFO - 2024-10-28 07:53:55 --> Config Class Initialized
INFO - 2024-10-28 07:53:55 --> Loader Class Initialized
INFO - 2024-10-28 07:53:55 --> Helper loaded: url_helper
INFO - 2024-10-28 07:53:55 --> Helper loaded: file_helper
INFO - 2024-10-28 07:53:55 --> Helper loaded: form_helper
INFO - 2024-10-28 07:53:55 --> Helper loaded: my_helper
INFO - 2024-10-28 07:53:55 --> Database Driver Class Initialized
INFO - 2024-10-28 07:53:55 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-28 07:53:55 --> Controller Class Initialized
INFO - 2024-10-28 07:53:56 --> Config Class Initialized
INFO - 2024-10-28 07:53:56 --> Hooks Class Initialized
DEBUG - 2024-10-28 07:53:56 --> UTF-8 Support Enabled
INFO - 2024-10-28 07:53:56 --> Utf8 Class Initialized
INFO - 2024-10-28 07:53:56 --> URI Class Initialized
INFO - 2024-10-28 07:53:56 --> Router Class Initialized
INFO - 2024-10-28 07:53:56 --> Output Class Initialized
INFO - 2024-10-28 07:53:56 --> Security Class Initialized
DEBUG - 2024-10-28 07:53:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-28 07:53:56 --> Input Class Initialized
INFO - 2024-10-28 07:53:56 --> Language Class Initialized
INFO - 2024-10-28 07:53:56 --> Language Class Initialized
INFO - 2024-10-28 07:53:56 --> Config Class Initialized
INFO - 2024-10-28 07:53:56 --> Loader Class Initialized
INFO - 2024-10-28 07:53:56 --> Helper loaded: url_helper
INFO - 2024-10-28 07:53:56 --> Helper loaded: file_helper
INFO - 2024-10-28 07:53:56 --> Helper loaded: form_helper
INFO - 2024-10-28 07:53:56 --> Helper loaded: my_helper
INFO - 2024-10-28 07:53:56 --> Database Driver Class Initialized
INFO - 2024-10-28 07:53:56 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-28 07:53:56 --> Controller Class Initialized
INFO - 2024-10-28 07:54:00 --> Config Class Initialized
INFO - 2024-10-28 07:54:00 --> Hooks Class Initialized
DEBUG - 2024-10-28 07:54:00 --> UTF-8 Support Enabled
INFO - 2024-10-28 07:54:00 --> Utf8 Class Initialized
INFO - 2024-10-28 07:54:00 --> URI Class Initialized
INFO - 2024-10-28 07:54:00 --> Router Class Initialized
INFO - 2024-10-28 07:54:00 --> Output Class Initialized
INFO - 2024-10-28 07:54:00 --> Security Class Initialized
DEBUG - 2024-10-28 07:54:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-28 07:54:00 --> Input Class Initialized
INFO - 2024-10-28 07:54:00 --> Language Class Initialized
INFO - 2024-10-28 07:54:00 --> Language Class Initialized
INFO - 2024-10-28 07:54:00 --> Config Class Initialized
INFO - 2024-10-28 07:54:00 --> Loader Class Initialized
INFO - 2024-10-28 07:54:00 --> Helper loaded: url_helper
INFO - 2024-10-28 07:54:00 --> Helper loaded: file_helper
INFO - 2024-10-28 07:54:00 --> Helper loaded: form_helper
INFO - 2024-10-28 07:54:00 --> Helper loaded: my_helper
INFO - 2024-10-28 07:54:00 --> Database Driver Class Initialized
INFO - 2024-10-28 07:54:00 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-28 07:54:00 --> Controller Class Initialized
ERROR - 2024-10-28 07:54:00 --> Severity: Notice --> Undefined variable: status_form /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/data_siswa/views/form.php 231
DEBUG - 2024-10-28 07:54:00 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/data_siswa/views/form.php
DEBUG - 2024-10-28 07:54:00 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-10-28 07:54:00 --> Final output sent to browser
DEBUG - 2024-10-28 07:54:00 --> Total execution time: 0.0383
INFO - 2024-10-28 07:54:08 --> Config Class Initialized
INFO - 2024-10-28 07:54:08 --> Hooks Class Initialized
DEBUG - 2024-10-28 07:54:08 --> UTF-8 Support Enabled
INFO - 2024-10-28 07:54:08 --> Utf8 Class Initialized
INFO - 2024-10-28 07:54:08 --> URI Class Initialized
INFO - 2024-10-28 07:54:08 --> Router Class Initialized
INFO - 2024-10-28 07:54:08 --> Output Class Initialized
INFO - 2024-10-28 07:54:08 --> Security Class Initialized
DEBUG - 2024-10-28 07:54:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-28 07:54:08 --> Input Class Initialized
INFO - 2024-10-28 07:54:08 --> Language Class Initialized
INFO - 2024-10-28 07:54:08 --> Language Class Initialized
INFO - 2024-10-28 07:54:08 --> Config Class Initialized
INFO - 2024-10-28 07:54:08 --> Loader Class Initialized
INFO - 2024-10-28 07:54:08 --> Helper loaded: url_helper
INFO - 2024-10-28 07:54:08 --> Helper loaded: file_helper
INFO - 2024-10-28 07:54:08 --> Helper loaded: form_helper
INFO - 2024-10-28 07:54:08 --> Helper loaded: my_helper
INFO - 2024-10-28 07:54:08 --> Database Driver Class Initialized
INFO - 2024-10-28 07:54:08 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-28 07:54:08 --> Controller Class Initialized
ERROR - 2024-10-28 07:54:08 --> Severity: Notice --> Undefined variable: status_form /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/data_siswa/views/form.php 231
DEBUG - 2024-10-28 07:54:08 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/data_siswa/views/form.php
DEBUG - 2024-10-28 07:54:08 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-10-28 07:54:08 --> Final output sent to browser
DEBUG - 2024-10-28 07:54:08 --> Total execution time: 0.0514
INFO - 2024-10-28 07:54:31 --> Config Class Initialized
INFO - 2024-10-28 07:54:31 --> Hooks Class Initialized
DEBUG - 2024-10-28 07:54:31 --> UTF-8 Support Enabled
INFO - 2024-10-28 07:54:31 --> Utf8 Class Initialized
INFO - 2024-10-28 07:54:31 --> URI Class Initialized
INFO - 2024-10-28 07:54:31 --> Router Class Initialized
INFO - 2024-10-28 07:54:31 --> Output Class Initialized
INFO - 2024-10-28 07:54:31 --> Security Class Initialized
DEBUG - 2024-10-28 07:54:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-28 07:54:31 --> Input Class Initialized
INFO - 2024-10-28 07:54:31 --> Language Class Initialized
INFO - 2024-10-28 07:54:31 --> Language Class Initialized
INFO - 2024-10-28 07:54:31 --> Config Class Initialized
INFO - 2024-10-28 07:54:31 --> Loader Class Initialized
INFO - 2024-10-28 07:54:31 --> Helper loaded: url_helper
INFO - 2024-10-28 07:54:31 --> Helper loaded: file_helper
INFO - 2024-10-28 07:54:31 --> Helper loaded: form_helper
INFO - 2024-10-28 07:54:31 --> Helper loaded: my_helper
INFO - 2024-10-28 07:54:31 --> Database Driver Class Initialized
INFO - 2024-10-28 07:54:31 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-28 07:54:31 --> Controller Class Initialized
INFO - 2024-10-28 07:54:31 --> Upload Class Initialized
INFO - 2024-10-28 07:54:31 --> Language file loaded: language/english/upload_lang.php
ERROR - 2024-10-28 07:54:31 --> The upload path does not appear to be valid.
INFO - 2024-10-28 07:54:32 --> Config Class Initialized
INFO - 2024-10-28 07:54:32 --> Hooks Class Initialized
DEBUG - 2024-10-28 07:54:32 --> UTF-8 Support Enabled
INFO - 2024-10-28 07:54:32 --> Utf8 Class Initialized
INFO - 2024-10-28 07:54:32 --> URI Class Initialized
INFO - 2024-10-28 07:54:32 --> Router Class Initialized
INFO - 2024-10-28 07:54:32 --> Output Class Initialized
INFO - 2024-10-28 07:54:32 --> Security Class Initialized
DEBUG - 2024-10-28 07:54:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-28 07:54:32 --> Input Class Initialized
INFO - 2024-10-28 07:54:32 --> Language Class Initialized
INFO - 2024-10-28 07:54:32 --> Language Class Initialized
INFO - 2024-10-28 07:54:32 --> Config Class Initialized
INFO - 2024-10-28 07:54:32 --> Loader Class Initialized
INFO - 2024-10-28 07:54:32 --> Helper loaded: url_helper
INFO - 2024-10-28 07:54:32 --> Helper loaded: file_helper
INFO - 2024-10-28 07:54:32 --> Helper loaded: form_helper
INFO - 2024-10-28 07:54:32 --> Helper loaded: my_helper
INFO - 2024-10-28 07:54:32 --> Database Driver Class Initialized
INFO - 2024-10-28 07:54:32 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-28 07:54:32 --> Controller Class Initialized
DEBUG - 2024-10-28 07:54:32 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/data_siswa/views/list.php
DEBUG - 2024-10-28 07:54:32 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-10-28 07:54:32 --> Final output sent to browser
DEBUG - 2024-10-28 07:54:32 --> Total execution time: 0.0292
INFO - 2024-10-28 07:54:32 --> Config Class Initialized
INFO - 2024-10-28 07:54:32 --> Hooks Class Initialized
DEBUG - 2024-10-28 07:54:32 --> UTF-8 Support Enabled
INFO - 2024-10-28 07:54:32 --> Utf8 Class Initialized
INFO - 2024-10-28 07:54:32 --> URI Class Initialized
INFO - 2024-10-28 07:54:32 --> Router Class Initialized
INFO - 2024-10-28 07:54:32 --> Output Class Initialized
INFO - 2024-10-28 07:54:32 --> Security Class Initialized
DEBUG - 2024-10-28 07:54:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-28 07:54:32 --> Input Class Initialized
INFO - 2024-10-28 07:54:32 --> Language Class Initialized
ERROR - 2024-10-28 07:54:32 --> 404 Page Not Found: /index
INFO - 2024-10-28 07:54:32 --> Config Class Initialized
INFO - 2024-10-28 07:54:32 --> Hooks Class Initialized
DEBUG - 2024-10-28 07:54:32 --> UTF-8 Support Enabled
INFO - 2024-10-28 07:54:32 --> Utf8 Class Initialized
INFO - 2024-10-28 07:54:32 --> URI Class Initialized
INFO - 2024-10-28 07:54:32 --> Router Class Initialized
INFO - 2024-10-28 07:54:32 --> Output Class Initialized
INFO - 2024-10-28 07:54:32 --> Security Class Initialized
DEBUG - 2024-10-28 07:54:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-28 07:54:32 --> Input Class Initialized
INFO - 2024-10-28 07:54:32 --> Language Class Initialized
INFO - 2024-10-28 07:54:32 --> Language Class Initialized
INFO - 2024-10-28 07:54:32 --> Config Class Initialized
INFO - 2024-10-28 07:54:32 --> Loader Class Initialized
INFO - 2024-10-28 07:54:32 --> Helper loaded: url_helper
INFO - 2024-10-28 07:54:32 --> Helper loaded: file_helper
INFO - 2024-10-28 07:54:32 --> Helper loaded: form_helper
INFO - 2024-10-28 07:54:32 --> Helper loaded: my_helper
INFO - 2024-10-28 07:54:32 --> Database Driver Class Initialized
INFO - 2024-10-28 07:54:32 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-28 07:54:32 --> Controller Class Initialized
INFO - 2024-10-28 07:54:37 --> Config Class Initialized
INFO - 2024-10-28 07:54:37 --> Hooks Class Initialized
DEBUG - 2024-10-28 07:54:37 --> UTF-8 Support Enabled
INFO - 2024-10-28 07:54:37 --> Utf8 Class Initialized
INFO - 2024-10-28 07:54:37 --> URI Class Initialized
INFO - 2024-10-28 07:54:37 --> Router Class Initialized
INFO - 2024-10-28 07:54:37 --> Output Class Initialized
INFO - 2024-10-28 07:54:37 --> Security Class Initialized
DEBUG - 2024-10-28 07:54:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-28 07:54:38 --> Input Class Initialized
INFO - 2024-10-28 07:54:38 --> Language Class Initialized
INFO - 2024-10-28 07:54:38 --> Language Class Initialized
INFO - 2024-10-28 07:54:38 --> Config Class Initialized
INFO - 2024-10-28 07:54:38 --> Loader Class Initialized
INFO - 2024-10-28 07:54:38 --> Helper loaded: url_helper
INFO - 2024-10-28 07:54:38 --> Helper loaded: file_helper
INFO - 2024-10-28 07:54:38 --> Helper loaded: form_helper
INFO - 2024-10-28 07:54:38 --> Helper loaded: my_helper
INFO - 2024-10-28 07:54:38 --> Database Driver Class Initialized
INFO - 2024-10-28 07:54:38 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-28 07:54:38 --> Controller Class Initialized
INFO - 2024-10-28 07:54:38 --> Config Class Initialized
INFO - 2024-10-28 07:54:38 --> Hooks Class Initialized
DEBUG - 2024-10-28 07:54:38 --> UTF-8 Support Enabled
INFO - 2024-10-28 07:54:38 --> Utf8 Class Initialized
INFO - 2024-10-28 07:54:38 --> URI Class Initialized
INFO - 2024-10-28 07:54:38 --> Router Class Initialized
INFO - 2024-10-28 07:54:38 --> Output Class Initialized
INFO - 2024-10-28 07:54:38 --> Security Class Initialized
DEBUG - 2024-10-28 07:54:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-28 07:54:38 --> Input Class Initialized
INFO - 2024-10-28 07:54:38 --> Language Class Initialized
INFO - 2024-10-28 07:54:38 --> Language Class Initialized
INFO - 2024-10-28 07:54:38 --> Config Class Initialized
INFO - 2024-10-28 07:54:38 --> Loader Class Initialized
INFO - 2024-10-28 07:54:38 --> Helper loaded: url_helper
INFO - 2024-10-28 07:54:38 --> Helper loaded: file_helper
INFO - 2024-10-28 07:54:38 --> Helper loaded: form_helper
INFO - 2024-10-28 07:54:38 --> Helper loaded: my_helper
INFO - 2024-10-28 07:54:38 --> Database Driver Class Initialized
INFO - 2024-10-28 07:54:38 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-28 07:54:38 --> Controller Class Initialized
INFO - 2024-10-28 07:54:39 --> Config Class Initialized
INFO - 2024-10-28 07:54:39 --> Hooks Class Initialized
DEBUG - 2024-10-28 07:54:39 --> UTF-8 Support Enabled
INFO - 2024-10-28 07:54:39 --> Utf8 Class Initialized
INFO - 2024-10-28 07:54:39 --> URI Class Initialized
INFO - 2024-10-28 07:54:39 --> Router Class Initialized
INFO - 2024-10-28 07:54:39 --> Output Class Initialized
INFO - 2024-10-28 07:54:39 --> Security Class Initialized
DEBUG - 2024-10-28 07:54:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-28 07:54:39 --> Input Class Initialized
INFO - 2024-10-28 07:54:39 --> Language Class Initialized
INFO - 2024-10-28 07:54:39 --> Language Class Initialized
INFO - 2024-10-28 07:54:39 --> Config Class Initialized
INFO - 2024-10-28 07:54:39 --> Loader Class Initialized
INFO - 2024-10-28 07:54:39 --> Helper loaded: url_helper
INFO - 2024-10-28 07:54:39 --> Helper loaded: file_helper
INFO - 2024-10-28 07:54:39 --> Helper loaded: form_helper
INFO - 2024-10-28 07:54:39 --> Helper loaded: my_helper
INFO - 2024-10-28 07:54:39 --> Database Driver Class Initialized
INFO - 2024-10-28 07:54:39 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-28 07:54:39 --> Controller Class Initialized
INFO - 2024-10-28 07:54:40 --> Config Class Initialized
INFO - 2024-10-28 07:54:40 --> Hooks Class Initialized
DEBUG - 2024-10-28 07:54:40 --> UTF-8 Support Enabled
INFO - 2024-10-28 07:54:40 --> Utf8 Class Initialized
INFO - 2024-10-28 07:54:40 --> URI Class Initialized
INFO - 2024-10-28 07:54:40 --> Router Class Initialized
INFO - 2024-10-28 07:54:40 --> Output Class Initialized
INFO - 2024-10-28 07:54:40 --> Security Class Initialized
DEBUG - 2024-10-28 07:54:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-28 07:54:40 --> Input Class Initialized
INFO - 2024-10-28 07:54:40 --> Language Class Initialized
INFO - 2024-10-28 07:54:40 --> Language Class Initialized
INFO - 2024-10-28 07:54:40 --> Config Class Initialized
INFO - 2024-10-28 07:54:40 --> Loader Class Initialized
INFO - 2024-10-28 07:54:40 --> Helper loaded: url_helper
INFO - 2024-10-28 07:54:40 --> Helper loaded: file_helper
INFO - 2024-10-28 07:54:40 --> Helper loaded: form_helper
INFO - 2024-10-28 07:54:40 --> Helper loaded: my_helper
INFO - 2024-10-28 07:54:40 --> Database Driver Class Initialized
INFO - 2024-10-28 07:54:40 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-28 07:54:40 --> Controller Class Initialized
ERROR - 2024-10-28 07:54:40 --> Severity: Notice --> Undefined variable: status_form /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/data_siswa/views/form.php 231
DEBUG - 2024-10-28 07:54:40 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/data_siswa/views/form.php
DEBUG - 2024-10-28 07:54:40 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-10-28 07:54:40 --> Final output sent to browser
DEBUG - 2024-10-28 07:54:40 --> Total execution time: 0.0674
INFO - 2024-10-28 07:55:04 --> Config Class Initialized
INFO - 2024-10-28 07:55:04 --> Hooks Class Initialized
DEBUG - 2024-10-28 07:55:04 --> UTF-8 Support Enabled
INFO - 2024-10-28 07:55:04 --> Utf8 Class Initialized
INFO - 2024-10-28 07:55:04 --> URI Class Initialized
INFO - 2024-10-28 07:55:04 --> Router Class Initialized
INFO - 2024-10-28 07:55:04 --> Output Class Initialized
INFO - 2024-10-28 07:55:04 --> Security Class Initialized
DEBUG - 2024-10-28 07:55:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-28 07:55:04 --> Input Class Initialized
INFO - 2024-10-28 07:55:04 --> Language Class Initialized
INFO - 2024-10-28 07:55:04 --> Language Class Initialized
INFO - 2024-10-28 07:55:04 --> Config Class Initialized
INFO - 2024-10-28 07:55:04 --> Loader Class Initialized
INFO - 2024-10-28 07:55:04 --> Helper loaded: url_helper
INFO - 2024-10-28 07:55:04 --> Helper loaded: file_helper
INFO - 2024-10-28 07:55:04 --> Helper loaded: form_helper
INFO - 2024-10-28 07:55:04 --> Helper loaded: my_helper
INFO - 2024-10-28 07:55:04 --> Database Driver Class Initialized
INFO - 2024-10-28 07:55:04 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-28 07:55:04 --> Controller Class Initialized
INFO - 2024-10-28 07:55:04 --> Upload Class Initialized
INFO - 2024-10-28 07:55:04 --> Language file loaded: language/english/upload_lang.php
ERROR - 2024-10-28 07:55:04 --> The upload path does not appear to be valid.
INFO - 2024-10-28 07:55:04 --> Config Class Initialized
INFO - 2024-10-28 07:55:04 --> Hooks Class Initialized
DEBUG - 2024-10-28 07:55:04 --> UTF-8 Support Enabled
INFO - 2024-10-28 07:55:04 --> Utf8 Class Initialized
INFO - 2024-10-28 07:55:04 --> URI Class Initialized
INFO - 2024-10-28 07:55:04 --> Router Class Initialized
INFO - 2024-10-28 07:55:04 --> Output Class Initialized
INFO - 2024-10-28 07:55:04 --> Security Class Initialized
DEBUG - 2024-10-28 07:55:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-28 07:55:04 --> Input Class Initialized
INFO - 2024-10-28 07:55:04 --> Language Class Initialized
INFO - 2024-10-28 07:55:04 --> Language Class Initialized
INFO - 2024-10-28 07:55:04 --> Config Class Initialized
INFO - 2024-10-28 07:55:04 --> Loader Class Initialized
INFO - 2024-10-28 07:55:04 --> Helper loaded: url_helper
INFO - 2024-10-28 07:55:04 --> Helper loaded: file_helper
INFO - 2024-10-28 07:55:04 --> Helper loaded: form_helper
INFO - 2024-10-28 07:55:04 --> Helper loaded: my_helper
INFO - 2024-10-28 07:55:04 --> Database Driver Class Initialized
INFO - 2024-10-28 07:55:04 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-28 07:55:04 --> Controller Class Initialized
DEBUG - 2024-10-28 07:55:04 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/data_siswa/views/list.php
DEBUG - 2024-10-28 07:55:04 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-10-28 07:55:04 --> Final output sent to browser
DEBUG - 2024-10-28 07:55:04 --> Total execution time: 0.0272
INFO - 2024-10-28 07:55:04 --> Config Class Initialized
INFO - 2024-10-28 07:55:04 --> Hooks Class Initialized
DEBUG - 2024-10-28 07:55:04 --> UTF-8 Support Enabled
INFO - 2024-10-28 07:55:04 --> Utf8 Class Initialized
INFO - 2024-10-28 07:55:04 --> URI Class Initialized
INFO - 2024-10-28 07:55:04 --> Router Class Initialized
INFO - 2024-10-28 07:55:04 --> Output Class Initialized
INFO - 2024-10-28 07:55:04 --> Security Class Initialized
DEBUG - 2024-10-28 07:55:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-28 07:55:04 --> Input Class Initialized
INFO - 2024-10-28 07:55:04 --> Language Class Initialized
ERROR - 2024-10-28 07:55:04 --> 404 Page Not Found: /index
INFO - 2024-10-28 07:55:04 --> Config Class Initialized
INFO - 2024-10-28 07:55:04 --> Hooks Class Initialized
DEBUG - 2024-10-28 07:55:04 --> UTF-8 Support Enabled
INFO - 2024-10-28 07:55:04 --> Utf8 Class Initialized
INFO - 2024-10-28 07:55:04 --> URI Class Initialized
INFO - 2024-10-28 07:55:04 --> Router Class Initialized
INFO - 2024-10-28 07:55:04 --> Output Class Initialized
INFO - 2024-10-28 07:55:04 --> Security Class Initialized
DEBUG - 2024-10-28 07:55:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-28 07:55:04 --> Input Class Initialized
INFO - 2024-10-28 07:55:04 --> Language Class Initialized
INFO - 2024-10-28 07:55:04 --> Language Class Initialized
INFO - 2024-10-28 07:55:04 --> Config Class Initialized
INFO - 2024-10-28 07:55:04 --> Loader Class Initialized
INFO - 2024-10-28 07:55:04 --> Helper loaded: url_helper
INFO - 2024-10-28 07:55:04 --> Helper loaded: file_helper
INFO - 2024-10-28 07:55:04 --> Helper loaded: form_helper
INFO - 2024-10-28 07:55:04 --> Helper loaded: my_helper
INFO - 2024-10-28 07:55:04 --> Database Driver Class Initialized
INFO - 2024-10-28 07:55:04 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-28 07:55:04 --> Controller Class Initialized
INFO - 2024-10-28 07:55:16 --> Config Class Initialized
INFO - 2024-10-28 07:55:16 --> Hooks Class Initialized
DEBUG - 2024-10-28 07:55:16 --> UTF-8 Support Enabled
INFO - 2024-10-28 07:55:16 --> Utf8 Class Initialized
INFO - 2024-10-28 07:55:16 --> URI Class Initialized
INFO - 2024-10-28 07:55:16 --> Router Class Initialized
INFO - 2024-10-28 07:55:16 --> Output Class Initialized
INFO - 2024-10-28 07:55:16 --> Security Class Initialized
DEBUG - 2024-10-28 07:55:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-28 07:55:16 --> Input Class Initialized
INFO - 2024-10-28 07:55:16 --> Language Class Initialized
INFO - 2024-10-28 07:55:16 --> Language Class Initialized
INFO - 2024-10-28 07:55:16 --> Config Class Initialized
INFO - 2024-10-28 07:55:16 --> Loader Class Initialized
INFO - 2024-10-28 07:55:16 --> Helper loaded: url_helper
INFO - 2024-10-28 07:55:16 --> Helper loaded: file_helper
INFO - 2024-10-28 07:55:16 --> Helper loaded: form_helper
INFO - 2024-10-28 07:55:16 --> Helper loaded: my_helper
INFO - 2024-10-28 07:55:16 --> Database Driver Class Initialized
INFO - 2024-10-28 07:55:16 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-28 07:55:16 --> Controller Class Initialized
INFO - 2024-10-28 07:55:16 --> Config Class Initialized
INFO - 2024-10-28 07:55:16 --> Hooks Class Initialized
DEBUG - 2024-10-28 07:55:16 --> UTF-8 Support Enabled
INFO - 2024-10-28 07:55:16 --> Utf8 Class Initialized
INFO - 2024-10-28 07:55:16 --> URI Class Initialized
INFO - 2024-10-28 07:55:16 --> Router Class Initialized
INFO - 2024-10-28 07:55:16 --> Output Class Initialized
INFO - 2024-10-28 07:55:16 --> Security Class Initialized
DEBUG - 2024-10-28 07:55:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-28 07:55:16 --> Input Class Initialized
INFO - 2024-10-28 07:55:16 --> Language Class Initialized
INFO - 2024-10-28 07:55:16 --> Language Class Initialized
INFO - 2024-10-28 07:55:16 --> Config Class Initialized
INFO - 2024-10-28 07:55:16 --> Loader Class Initialized
INFO - 2024-10-28 07:55:16 --> Helper loaded: url_helper
INFO - 2024-10-28 07:55:16 --> Helper loaded: file_helper
INFO - 2024-10-28 07:55:16 --> Helper loaded: form_helper
INFO - 2024-10-28 07:55:16 --> Helper loaded: my_helper
INFO - 2024-10-28 07:55:16 --> Database Driver Class Initialized
INFO - 2024-10-28 07:55:16 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-28 07:55:16 --> Controller Class Initialized
INFO - 2024-10-28 07:55:17 --> Config Class Initialized
INFO - 2024-10-28 07:55:17 --> Hooks Class Initialized
DEBUG - 2024-10-28 07:55:17 --> UTF-8 Support Enabled
INFO - 2024-10-28 07:55:17 --> Utf8 Class Initialized
INFO - 2024-10-28 07:55:17 --> URI Class Initialized
INFO - 2024-10-28 07:55:17 --> Router Class Initialized
INFO - 2024-10-28 07:55:17 --> Output Class Initialized
INFO - 2024-10-28 07:55:17 --> Security Class Initialized
DEBUG - 2024-10-28 07:55:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-28 07:55:17 --> Input Class Initialized
INFO - 2024-10-28 07:55:17 --> Language Class Initialized
INFO - 2024-10-28 07:55:17 --> Language Class Initialized
INFO - 2024-10-28 07:55:17 --> Config Class Initialized
INFO - 2024-10-28 07:55:17 --> Loader Class Initialized
INFO - 2024-10-28 07:55:17 --> Helper loaded: url_helper
INFO - 2024-10-28 07:55:17 --> Helper loaded: file_helper
INFO - 2024-10-28 07:55:17 --> Helper loaded: form_helper
INFO - 2024-10-28 07:55:17 --> Helper loaded: my_helper
INFO - 2024-10-28 07:55:17 --> Database Driver Class Initialized
INFO - 2024-10-28 07:55:17 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-28 07:55:17 --> Controller Class Initialized
INFO - 2024-10-28 07:55:18 --> Config Class Initialized
INFO - 2024-10-28 07:55:18 --> Hooks Class Initialized
DEBUG - 2024-10-28 07:55:18 --> UTF-8 Support Enabled
INFO - 2024-10-28 07:55:18 --> Utf8 Class Initialized
INFO - 2024-10-28 07:55:18 --> URI Class Initialized
INFO - 2024-10-28 07:55:18 --> Router Class Initialized
INFO - 2024-10-28 07:55:18 --> Output Class Initialized
INFO - 2024-10-28 07:55:18 --> Security Class Initialized
DEBUG - 2024-10-28 07:55:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-28 07:55:18 --> Input Class Initialized
INFO - 2024-10-28 07:55:18 --> Language Class Initialized
INFO - 2024-10-28 07:55:18 --> Language Class Initialized
INFO - 2024-10-28 07:55:18 --> Config Class Initialized
INFO - 2024-10-28 07:55:18 --> Loader Class Initialized
INFO - 2024-10-28 07:55:18 --> Helper loaded: url_helper
INFO - 2024-10-28 07:55:18 --> Helper loaded: file_helper
INFO - 2024-10-28 07:55:18 --> Helper loaded: form_helper
INFO - 2024-10-28 07:55:18 --> Helper loaded: my_helper
INFO - 2024-10-28 07:55:18 --> Database Driver Class Initialized
INFO - 2024-10-28 07:55:18 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-28 07:55:18 --> Controller Class Initialized
ERROR - 2024-10-28 07:55:18 --> Severity: Notice --> Undefined variable: status_form /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/data_siswa/views/form.php 231
DEBUG - 2024-10-28 07:55:18 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/data_siswa/views/form.php
DEBUG - 2024-10-28 07:55:18 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-10-28 07:55:18 --> Final output sent to browser
DEBUG - 2024-10-28 07:55:18 --> Total execution time: 0.0722
INFO - 2024-10-28 07:55:41 --> Config Class Initialized
INFO - 2024-10-28 07:55:41 --> Hooks Class Initialized
DEBUG - 2024-10-28 07:55:41 --> UTF-8 Support Enabled
INFO - 2024-10-28 07:55:41 --> Utf8 Class Initialized
INFO - 2024-10-28 07:55:41 --> URI Class Initialized
INFO - 2024-10-28 07:55:41 --> Router Class Initialized
INFO - 2024-10-28 07:55:41 --> Output Class Initialized
INFO - 2024-10-28 07:55:41 --> Security Class Initialized
DEBUG - 2024-10-28 07:55:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-28 07:55:41 --> Input Class Initialized
INFO - 2024-10-28 07:55:41 --> Language Class Initialized
INFO - 2024-10-28 07:55:41 --> Language Class Initialized
INFO - 2024-10-28 07:55:41 --> Config Class Initialized
INFO - 2024-10-28 07:55:41 --> Loader Class Initialized
INFO - 2024-10-28 07:55:41 --> Helper loaded: url_helper
INFO - 2024-10-28 07:55:41 --> Helper loaded: file_helper
INFO - 2024-10-28 07:55:41 --> Helper loaded: form_helper
INFO - 2024-10-28 07:55:41 --> Helper loaded: my_helper
INFO - 2024-10-28 07:55:41 --> Database Driver Class Initialized
INFO - 2024-10-28 07:55:41 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-28 07:55:41 --> Controller Class Initialized
INFO - 2024-10-28 07:55:41 --> Upload Class Initialized
INFO - 2024-10-28 07:55:41 --> Language file loaded: language/english/upload_lang.php
ERROR - 2024-10-28 07:55:41 --> The upload path does not appear to be valid.
INFO - 2024-10-28 07:55:41 --> Config Class Initialized
INFO - 2024-10-28 07:55:41 --> Hooks Class Initialized
DEBUG - 2024-10-28 07:55:41 --> UTF-8 Support Enabled
INFO - 2024-10-28 07:55:41 --> Utf8 Class Initialized
INFO - 2024-10-28 07:55:41 --> URI Class Initialized
INFO - 2024-10-28 07:55:41 --> Router Class Initialized
INFO - 2024-10-28 07:55:41 --> Output Class Initialized
INFO - 2024-10-28 07:55:41 --> Security Class Initialized
DEBUG - 2024-10-28 07:55:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-28 07:55:41 --> Input Class Initialized
INFO - 2024-10-28 07:55:41 --> Language Class Initialized
INFO - 2024-10-28 07:55:41 --> Language Class Initialized
INFO - 2024-10-28 07:55:41 --> Config Class Initialized
INFO - 2024-10-28 07:55:41 --> Loader Class Initialized
INFO - 2024-10-28 07:55:41 --> Helper loaded: url_helper
INFO - 2024-10-28 07:55:41 --> Helper loaded: file_helper
INFO - 2024-10-28 07:55:41 --> Helper loaded: form_helper
INFO - 2024-10-28 07:55:41 --> Helper loaded: my_helper
INFO - 2024-10-28 07:55:41 --> Database Driver Class Initialized
INFO - 2024-10-28 07:55:41 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-28 07:55:41 --> Controller Class Initialized
DEBUG - 2024-10-28 07:55:41 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/data_siswa/views/list.php
DEBUG - 2024-10-28 07:55:41 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-10-28 07:55:41 --> Final output sent to browser
DEBUG - 2024-10-28 07:55:41 --> Total execution time: 0.0275
INFO - 2024-10-28 07:55:41 --> Config Class Initialized
INFO - 2024-10-28 07:55:41 --> Hooks Class Initialized
DEBUG - 2024-10-28 07:55:41 --> UTF-8 Support Enabled
INFO - 2024-10-28 07:55:41 --> Utf8 Class Initialized
INFO - 2024-10-28 07:55:41 --> URI Class Initialized
INFO - 2024-10-28 07:55:41 --> Router Class Initialized
INFO - 2024-10-28 07:55:41 --> Output Class Initialized
INFO - 2024-10-28 07:55:41 --> Security Class Initialized
DEBUG - 2024-10-28 07:55:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-28 07:55:41 --> Input Class Initialized
INFO - 2024-10-28 07:55:41 --> Language Class Initialized
ERROR - 2024-10-28 07:55:41 --> 404 Page Not Found: /index
INFO - 2024-10-28 07:55:41 --> Config Class Initialized
INFO - 2024-10-28 07:55:41 --> Hooks Class Initialized
DEBUG - 2024-10-28 07:55:41 --> UTF-8 Support Enabled
INFO - 2024-10-28 07:55:41 --> Utf8 Class Initialized
INFO - 2024-10-28 07:55:41 --> URI Class Initialized
INFO - 2024-10-28 07:55:41 --> Router Class Initialized
INFO - 2024-10-28 07:55:41 --> Output Class Initialized
INFO - 2024-10-28 07:55:41 --> Security Class Initialized
DEBUG - 2024-10-28 07:55:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-28 07:55:41 --> Input Class Initialized
INFO - 2024-10-28 07:55:41 --> Language Class Initialized
INFO - 2024-10-28 07:55:41 --> Language Class Initialized
INFO - 2024-10-28 07:55:41 --> Config Class Initialized
INFO - 2024-10-28 07:55:41 --> Loader Class Initialized
INFO - 2024-10-28 07:55:41 --> Helper loaded: url_helper
INFO - 2024-10-28 07:55:41 --> Helper loaded: file_helper
INFO - 2024-10-28 07:55:41 --> Helper loaded: form_helper
INFO - 2024-10-28 07:55:41 --> Helper loaded: my_helper
INFO - 2024-10-28 07:55:41 --> Database Driver Class Initialized
INFO - 2024-10-28 07:55:41 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-28 07:55:41 --> Controller Class Initialized
INFO - 2024-10-28 07:56:45 --> Config Class Initialized
INFO - 2024-10-28 07:56:45 --> Hooks Class Initialized
DEBUG - 2024-10-28 07:56:45 --> UTF-8 Support Enabled
INFO - 2024-10-28 07:56:45 --> Utf8 Class Initialized
INFO - 2024-10-28 07:56:45 --> URI Class Initialized
INFO - 2024-10-28 07:56:45 --> Router Class Initialized
INFO - 2024-10-28 07:56:45 --> Output Class Initialized
INFO - 2024-10-28 07:56:45 --> Security Class Initialized
DEBUG - 2024-10-28 07:56:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-28 07:56:45 --> Input Class Initialized
INFO - 2024-10-28 07:56:45 --> Language Class Initialized
INFO - 2024-10-28 07:56:45 --> Language Class Initialized
INFO - 2024-10-28 07:56:45 --> Config Class Initialized
INFO - 2024-10-28 07:56:45 --> Loader Class Initialized
INFO - 2024-10-28 07:56:45 --> Helper loaded: url_helper
INFO - 2024-10-28 07:56:45 --> Helper loaded: file_helper
INFO - 2024-10-28 07:56:45 --> Helper loaded: form_helper
INFO - 2024-10-28 07:56:45 --> Helper loaded: my_helper
INFO - 2024-10-28 07:56:45 --> Database Driver Class Initialized
INFO - 2024-10-28 07:56:45 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-28 07:56:45 --> Controller Class Initialized
INFO - 2024-10-28 07:56:46 --> Config Class Initialized
INFO - 2024-10-28 07:56:46 --> Hooks Class Initialized
DEBUG - 2024-10-28 07:56:46 --> UTF-8 Support Enabled
INFO - 2024-10-28 07:56:46 --> Utf8 Class Initialized
INFO - 2024-10-28 07:56:46 --> URI Class Initialized
INFO - 2024-10-28 07:56:46 --> Router Class Initialized
INFO - 2024-10-28 07:56:46 --> Output Class Initialized
INFO - 2024-10-28 07:56:46 --> Security Class Initialized
DEBUG - 2024-10-28 07:56:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-28 07:56:46 --> Input Class Initialized
INFO - 2024-10-28 07:56:46 --> Language Class Initialized
INFO - 2024-10-28 07:56:46 --> Language Class Initialized
INFO - 2024-10-28 07:56:46 --> Config Class Initialized
INFO - 2024-10-28 07:56:46 --> Loader Class Initialized
INFO - 2024-10-28 07:56:46 --> Helper loaded: url_helper
INFO - 2024-10-28 07:56:46 --> Helper loaded: file_helper
INFO - 2024-10-28 07:56:46 --> Helper loaded: form_helper
INFO - 2024-10-28 07:56:46 --> Helper loaded: my_helper
INFO - 2024-10-28 07:56:46 --> Database Driver Class Initialized
INFO - 2024-10-28 07:56:46 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-28 07:56:46 --> Controller Class Initialized
INFO - 2024-10-28 07:56:48 --> Config Class Initialized
INFO - 2024-10-28 07:56:48 --> Hooks Class Initialized
DEBUG - 2024-10-28 07:56:48 --> UTF-8 Support Enabled
INFO - 2024-10-28 07:56:48 --> Utf8 Class Initialized
INFO - 2024-10-28 07:56:48 --> URI Class Initialized
INFO - 2024-10-28 07:56:48 --> Router Class Initialized
INFO - 2024-10-28 07:56:48 --> Output Class Initialized
INFO - 2024-10-28 07:56:48 --> Security Class Initialized
DEBUG - 2024-10-28 07:56:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-28 07:56:48 --> Input Class Initialized
INFO - 2024-10-28 07:56:48 --> Language Class Initialized
INFO - 2024-10-28 07:56:48 --> Language Class Initialized
INFO - 2024-10-28 07:56:48 --> Config Class Initialized
INFO - 2024-10-28 07:56:48 --> Loader Class Initialized
INFO - 2024-10-28 07:56:48 --> Helper loaded: url_helper
INFO - 2024-10-28 07:56:48 --> Helper loaded: file_helper
INFO - 2024-10-28 07:56:48 --> Helper loaded: form_helper
INFO - 2024-10-28 07:56:48 --> Helper loaded: my_helper
INFO - 2024-10-28 07:56:48 --> Database Driver Class Initialized
INFO - 2024-10-28 07:56:48 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-28 07:56:48 --> Controller Class Initialized
ERROR - 2024-10-28 07:56:48 --> Severity: Notice --> Undefined variable: status_form /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/data_siswa/views/form.php 231
DEBUG - 2024-10-28 07:56:48 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/data_siswa/views/form.php
DEBUG - 2024-10-28 07:56:48 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-10-28 07:56:48 --> Final output sent to browser
DEBUG - 2024-10-28 07:56:48 --> Total execution time: 0.0312
INFO - 2024-10-28 07:57:11 --> Config Class Initialized
INFO - 2024-10-28 07:57:11 --> Hooks Class Initialized
DEBUG - 2024-10-28 07:57:11 --> UTF-8 Support Enabled
INFO - 2024-10-28 07:57:11 --> Utf8 Class Initialized
INFO - 2024-10-28 07:57:11 --> URI Class Initialized
INFO - 2024-10-28 07:57:11 --> Router Class Initialized
INFO - 2024-10-28 07:57:11 --> Output Class Initialized
INFO - 2024-10-28 07:57:11 --> Security Class Initialized
DEBUG - 2024-10-28 07:57:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-28 07:57:11 --> Input Class Initialized
INFO - 2024-10-28 07:57:11 --> Language Class Initialized
INFO - 2024-10-28 07:57:11 --> Language Class Initialized
INFO - 2024-10-28 07:57:11 --> Config Class Initialized
INFO - 2024-10-28 07:57:11 --> Loader Class Initialized
INFO - 2024-10-28 07:57:11 --> Helper loaded: url_helper
INFO - 2024-10-28 07:57:11 --> Helper loaded: file_helper
INFO - 2024-10-28 07:57:11 --> Helper loaded: form_helper
INFO - 2024-10-28 07:57:11 --> Helper loaded: my_helper
INFO - 2024-10-28 07:57:11 --> Database Driver Class Initialized
INFO - 2024-10-28 07:57:11 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-28 07:57:11 --> Controller Class Initialized
INFO - 2024-10-28 07:57:11 --> Upload Class Initialized
INFO - 2024-10-28 07:57:11 --> Language file loaded: language/english/upload_lang.php
ERROR - 2024-10-28 07:57:11 --> The upload path does not appear to be valid.
INFO - 2024-10-28 07:57:11 --> Config Class Initialized
INFO - 2024-10-28 07:57:11 --> Hooks Class Initialized
DEBUG - 2024-10-28 07:57:11 --> UTF-8 Support Enabled
INFO - 2024-10-28 07:57:11 --> Utf8 Class Initialized
INFO - 2024-10-28 07:57:11 --> URI Class Initialized
INFO - 2024-10-28 07:57:11 --> Router Class Initialized
INFO - 2024-10-28 07:57:11 --> Output Class Initialized
INFO - 2024-10-28 07:57:11 --> Security Class Initialized
DEBUG - 2024-10-28 07:57:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-28 07:57:11 --> Input Class Initialized
INFO - 2024-10-28 07:57:11 --> Language Class Initialized
INFO - 2024-10-28 07:57:11 --> Language Class Initialized
INFO - 2024-10-28 07:57:11 --> Config Class Initialized
INFO - 2024-10-28 07:57:11 --> Loader Class Initialized
INFO - 2024-10-28 07:57:11 --> Helper loaded: url_helper
INFO - 2024-10-28 07:57:11 --> Helper loaded: file_helper
INFO - 2024-10-28 07:57:11 --> Helper loaded: form_helper
INFO - 2024-10-28 07:57:11 --> Helper loaded: my_helper
INFO - 2024-10-28 07:57:11 --> Database Driver Class Initialized
INFO - 2024-10-28 07:57:11 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-28 07:57:11 --> Controller Class Initialized
DEBUG - 2024-10-28 07:57:11 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/data_siswa/views/list.php
DEBUG - 2024-10-28 07:57:11 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-10-28 07:57:11 --> Final output sent to browser
DEBUG - 2024-10-28 07:57:11 --> Total execution time: 0.0355
INFO - 2024-10-28 07:57:11 --> Config Class Initialized
INFO - 2024-10-28 07:57:11 --> Hooks Class Initialized
DEBUG - 2024-10-28 07:57:12 --> UTF-8 Support Enabled
INFO - 2024-10-28 07:57:12 --> Utf8 Class Initialized
INFO - 2024-10-28 07:57:12 --> URI Class Initialized
INFO - 2024-10-28 07:57:12 --> Router Class Initialized
INFO - 2024-10-28 07:57:12 --> Output Class Initialized
INFO - 2024-10-28 07:57:12 --> Security Class Initialized
DEBUG - 2024-10-28 07:57:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-28 07:57:12 --> Input Class Initialized
INFO - 2024-10-28 07:57:12 --> Language Class Initialized
ERROR - 2024-10-28 07:57:12 --> 404 Page Not Found: /index
INFO - 2024-10-28 07:57:12 --> Config Class Initialized
INFO - 2024-10-28 07:57:12 --> Hooks Class Initialized
DEBUG - 2024-10-28 07:57:12 --> UTF-8 Support Enabled
INFO - 2024-10-28 07:57:12 --> Utf8 Class Initialized
INFO - 2024-10-28 07:57:12 --> URI Class Initialized
INFO - 2024-10-28 07:57:12 --> Router Class Initialized
INFO - 2024-10-28 07:57:12 --> Output Class Initialized
INFO - 2024-10-28 07:57:12 --> Security Class Initialized
DEBUG - 2024-10-28 07:57:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-28 07:57:12 --> Input Class Initialized
INFO - 2024-10-28 07:57:12 --> Language Class Initialized
INFO - 2024-10-28 07:57:12 --> Language Class Initialized
INFO - 2024-10-28 07:57:12 --> Config Class Initialized
INFO - 2024-10-28 07:57:12 --> Loader Class Initialized
INFO - 2024-10-28 07:57:12 --> Helper loaded: url_helper
INFO - 2024-10-28 07:57:12 --> Helper loaded: file_helper
INFO - 2024-10-28 07:57:12 --> Helper loaded: form_helper
INFO - 2024-10-28 07:57:12 --> Helper loaded: my_helper
INFO - 2024-10-28 07:57:12 --> Database Driver Class Initialized
INFO - 2024-10-28 07:57:12 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-28 07:57:12 --> Controller Class Initialized
INFO - 2024-10-28 07:57:15 --> Config Class Initialized
INFO - 2024-10-28 07:57:15 --> Hooks Class Initialized
DEBUG - 2024-10-28 07:57:15 --> UTF-8 Support Enabled
INFO - 2024-10-28 07:57:15 --> Utf8 Class Initialized
INFO - 2024-10-28 07:57:15 --> URI Class Initialized
INFO - 2024-10-28 07:57:15 --> Router Class Initialized
INFO - 2024-10-28 07:57:15 --> Output Class Initialized
INFO - 2024-10-28 07:57:15 --> Security Class Initialized
DEBUG - 2024-10-28 07:57:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-28 07:57:15 --> Input Class Initialized
INFO - 2024-10-28 07:57:15 --> Language Class Initialized
INFO - 2024-10-28 07:57:15 --> Language Class Initialized
INFO - 2024-10-28 07:57:15 --> Config Class Initialized
INFO - 2024-10-28 07:57:15 --> Loader Class Initialized
INFO - 2024-10-28 07:57:15 --> Helper loaded: url_helper
INFO - 2024-10-28 07:57:15 --> Helper loaded: file_helper
INFO - 2024-10-28 07:57:15 --> Helper loaded: form_helper
INFO - 2024-10-28 07:57:15 --> Helper loaded: my_helper
INFO - 2024-10-28 07:57:15 --> Database Driver Class Initialized
INFO - 2024-10-28 07:57:15 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-28 07:57:15 --> Controller Class Initialized
INFO - 2024-10-28 07:57:15 --> Config Class Initialized
INFO - 2024-10-28 07:57:15 --> Hooks Class Initialized
DEBUG - 2024-10-28 07:57:15 --> UTF-8 Support Enabled
INFO - 2024-10-28 07:57:15 --> Utf8 Class Initialized
INFO - 2024-10-28 07:57:15 --> URI Class Initialized
INFO - 2024-10-28 07:57:15 --> Router Class Initialized
INFO - 2024-10-28 07:57:15 --> Output Class Initialized
INFO - 2024-10-28 07:57:15 --> Security Class Initialized
DEBUG - 2024-10-28 07:57:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-28 07:57:15 --> Input Class Initialized
INFO - 2024-10-28 07:57:15 --> Language Class Initialized
INFO - 2024-10-28 07:57:15 --> Language Class Initialized
INFO - 2024-10-28 07:57:15 --> Config Class Initialized
INFO - 2024-10-28 07:57:15 --> Loader Class Initialized
INFO - 2024-10-28 07:57:15 --> Helper loaded: url_helper
INFO - 2024-10-28 07:57:15 --> Helper loaded: file_helper
INFO - 2024-10-28 07:57:15 --> Helper loaded: form_helper
INFO - 2024-10-28 07:57:15 --> Helper loaded: my_helper
INFO - 2024-10-28 07:57:15 --> Database Driver Class Initialized
INFO - 2024-10-28 07:57:15 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-28 07:57:15 --> Controller Class Initialized
INFO - 2024-10-28 07:57:16 --> Config Class Initialized
INFO - 2024-10-28 07:57:16 --> Hooks Class Initialized
DEBUG - 2024-10-28 07:57:16 --> UTF-8 Support Enabled
INFO - 2024-10-28 07:57:16 --> Utf8 Class Initialized
INFO - 2024-10-28 07:57:16 --> URI Class Initialized
INFO - 2024-10-28 07:57:16 --> Router Class Initialized
INFO - 2024-10-28 07:57:16 --> Output Class Initialized
INFO - 2024-10-28 07:57:16 --> Security Class Initialized
DEBUG - 2024-10-28 07:57:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-28 07:57:16 --> Input Class Initialized
INFO - 2024-10-28 07:57:16 --> Language Class Initialized
INFO - 2024-10-28 07:57:16 --> Language Class Initialized
INFO - 2024-10-28 07:57:16 --> Config Class Initialized
INFO - 2024-10-28 07:57:16 --> Loader Class Initialized
INFO - 2024-10-28 07:57:16 --> Helper loaded: url_helper
INFO - 2024-10-28 07:57:16 --> Helper loaded: file_helper
INFO - 2024-10-28 07:57:16 --> Helper loaded: form_helper
INFO - 2024-10-28 07:57:16 --> Helper loaded: my_helper
INFO - 2024-10-28 07:57:16 --> Database Driver Class Initialized
INFO - 2024-10-28 07:57:16 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-28 07:57:16 --> Controller Class Initialized
INFO - 2024-10-28 07:57:17 --> Config Class Initialized
INFO - 2024-10-28 07:57:17 --> Hooks Class Initialized
DEBUG - 2024-10-28 07:57:17 --> UTF-8 Support Enabled
INFO - 2024-10-28 07:57:17 --> Utf8 Class Initialized
INFO - 2024-10-28 07:57:17 --> URI Class Initialized
INFO - 2024-10-28 07:57:17 --> Router Class Initialized
INFO - 2024-10-28 07:57:17 --> Output Class Initialized
INFO - 2024-10-28 07:57:17 --> Security Class Initialized
DEBUG - 2024-10-28 07:57:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-28 07:57:17 --> Input Class Initialized
INFO - 2024-10-28 07:57:17 --> Language Class Initialized
INFO - 2024-10-28 07:57:17 --> Language Class Initialized
INFO - 2024-10-28 07:57:17 --> Config Class Initialized
INFO - 2024-10-28 07:57:17 --> Loader Class Initialized
INFO - 2024-10-28 07:57:17 --> Helper loaded: url_helper
INFO - 2024-10-28 07:57:17 --> Helper loaded: file_helper
INFO - 2024-10-28 07:57:17 --> Helper loaded: form_helper
INFO - 2024-10-28 07:57:17 --> Helper loaded: my_helper
INFO - 2024-10-28 07:57:17 --> Database Driver Class Initialized
INFO - 2024-10-28 07:57:17 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-28 07:57:17 --> Controller Class Initialized
ERROR - 2024-10-28 07:57:17 --> Severity: Notice --> Undefined variable: status_form /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/data_siswa/views/form.php 231
DEBUG - 2024-10-28 07:57:17 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/data_siswa/views/form.php
DEBUG - 2024-10-28 07:57:17 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-10-28 07:57:17 --> Final output sent to browser
DEBUG - 2024-10-28 07:57:17 --> Total execution time: 0.0354
INFO - 2024-10-28 07:57:26 --> Config Class Initialized
INFO - 2024-10-28 07:57:26 --> Hooks Class Initialized
DEBUG - 2024-10-28 07:57:26 --> UTF-8 Support Enabled
INFO - 2024-10-28 07:57:26 --> Utf8 Class Initialized
INFO - 2024-10-28 07:57:26 --> URI Class Initialized
INFO - 2024-10-28 07:57:26 --> Router Class Initialized
INFO - 2024-10-28 07:57:26 --> Output Class Initialized
INFO - 2024-10-28 07:57:26 --> Security Class Initialized
DEBUG - 2024-10-28 07:57:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-28 07:57:26 --> Input Class Initialized
INFO - 2024-10-28 07:57:26 --> Language Class Initialized
INFO - 2024-10-28 07:57:26 --> Language Class Initialized
INFO - 2024-10-28 07:57:26 --> Config Class Initialized
INFO - 2024-10-28 07:57:26 --> Loader Class Initialized
INFO - 2024-10-28 07:57:26 --> Helper loaded: url_helper
INFO - 2024-10-28 07:57:26 --> Helper loaded: file_helper
INFO - 2024-10-28 07:57:26 --> Helper loaded: form_helper
INFO - 2024-10-28 07:57:26 --> Helper loaded: my_helper
INFO - 2024-10-28 07:57:26 --> Database Driver Class Initialized
INFO - 2024-10-28 07:57:26 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-28 07:57:26 --> Controller Class Initialized
INFO - 2024-10-28 07:57:26 --> Upload Class Initialized
INFO - 2024-10-28 07:57:26 --> Language file loaded: language/english/upload_lang.php
ERROR - 2024-10-28 07:57:26 --> The upload path does not appear to be valid.
INFO - 2024-10-28 07:57:26 --> Config Class Initialized
INFO - 2024-10-28 07:57:26 --> Hooks Class Initialized
DEBUG - 2024-10-28 07:57:26 --> UTF-8 Support Enabled
INFO - 2024-10-28 07:57:26 --> Utf8 Class Initialized
INFO - 2024-10-28 07:57:26 --> URI Class Initialized
INFO - 2024-10-28 07:57:26 --> Router Class Initialized
INFO - 2024-10-28 07:57:26 --> Output Class Initialized
INFO - 2024-10-28 07:57:26 --> Security Class Initialized
DEBUG - 2024-10-28 07:57:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-28 07:57:26 --> Input Class Initialized
INFO - 2024-10-28 07:57:26 --> Language Class Initialized
INFO - 2024-10-28 07:57:26 --> Language Class Initialized
INFO - 2024-10-28 07:57:26 --> Config Class Initialized
INFO - 2024-10-28 07:57:26 --> Loader Class Initialized
INFO - 2024-10-28 07:57:26 --> Helper loaded: url_helper
INFO - 2024-10-28 07:57:26 --> Helper loaded: file_helper
INFO - 2024-10-28 07:57:26 --> Helper loaded: form_helper
INFO - 2024-10-28 07:57:26 --> Helper loaded: my_helper
INFO - 2024-10-28 07:57:26 --> Database Driver Class Initialized
INFO - 2024-10-28 07:57:26 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-28 07:57:26 --> Controller Class Initialized
DEBUG - 2024-10-28 07:57:26 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/data_siswa/views/list.php
DEBUG - 2024-10-28 07:57:26 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-10-28 07:57:26 --> Final output sent to browser
DEBUG - 2024-10-28 07:57:26 --> Total execution time: 0.0275
INFO - 2024-10-28 07:57:26 --> Config Class Initialized
INFO - 2024-10-28 07:57:26 --> Hooks Class Initialized
DEBUG - 2024-10-28 07:57:26 --> UTF-8 Support Enabled
INFO - 2024-10-28 07:57:26 --> Utf8 Class Initialized
INFO - 2024-10-28 07:57:26 --> URI Class Initialized
INFO - 2024-10-28 07:57:26 --> Router Class Initialized
INFO - 2024-10-28 07:57:26 --> Output Class Initialized
INFO - 2024-10-28 07:57:26 --> Security Class Initialized
DEBUG - 2024-10-28 07:57:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-28 07:57:26 --> Input Class Initialized
INFO - 2024-10-28 07:57:26 --> Language Class Initialized
ERROR - 2024-10-28 07:57:26 --> 404 Page Not Found: /index
INFO - 2024-10-28 07:57:26 --> Config Class Initialized
INFO - 2024-10-28 07:57:26 --> Hooks Class Initialized
DEBUG - 2024-10-28 07:57:26 --> UTF-8 Support Enabled
INFO - 2024-10-28 07:57:26 --> Utf8 Class Initialized
INFO - 2024-10-28 07:57:26 --> URI Class Initialized
INFO - 2024-10-28 07:57:26 --> Router Class Initialized
INFO - 2024-10-28 07:57:26 --> Output Class Initialized
INFO - 2024-10-28 07:57:26 --> Security Class Initialized
DEBUG - 2024-10-28 07:57:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-28 07:57:26 --> Input Class Initialized
INFO - 2024-10-28 07:57:26 --> Language Class Initialized
INFO - 2024-10-28 07:57:26 --> Language Class Initialized
INFO - 2024-10-28 07:57:26 --> Config Class Initialized
INFO - 2024-10-28 07:57:26 --> Loader Class Initialized
INFO - 2024-10-28 07:57:26 --> Helper loaded: url_helper
INFO - 2024-10-28 07:57:26 --> Helper loaded: file_helper
INFO - 2024-10-28 07:57:26 --> Helper loaded: form_helper
INFO - 2024-10-28 07:57:26 --> Helper loaded: my_helper
INFO - 2024-10-28 07:57:26 --> Database Driver Class Initialized
INFO - 2024-10-28 07:57:26 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-28 07:57:26 --> Controller Class Initialized
INFO - 2024-10-28 07:57:29 --> Config Class Initialized
INFO - 2024-10-28 07:57:29 --> Hooks Class Initialized
DEBUG - 2024-10-28 07:57:29 --> UTF-8 Support Enabled
INFO - 2024-10-28 07:57:29 --> Utf8 Class Initialized
INFO - 2024-10-28 07:57:29 --> URI Class Initialized
INFO - 2024-10-28 07:57:29 --> Router Class Initialized
INFO - 2024-10-28 07:57:29 --> Output Class Initialized
INFO - 2024-10-28 07:57:29 --> Security Class Initialized
DEBUG - 2024-10-28 07:57:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-28 07:57:29 --> Input Class Initialized
INFO - 2024-10-28 07:57:29 --> Language Class Initialized
INFO - 2024-10-28 07:57:29 --> Language Class Initialized
INFO - 2024-10-28 07:57:29 --> Config Class Initialized
INFO - 2024-10-28 07:57:29 --> Loader Class Initialized
INFO - 2024-10-28 07:57:29 --> Helper loaded: url_helper
INFO - 2024-10-28 07:57:29 --> Helper loaded: file_helper
INFO - 2024-10-28 07:57:29 --> Helper loaded: form_helper
INFO - 2024-10-28 07:57:29 --> Helper loaded: my_helper
INFO - 2024-10-28 07:57:29 --> Database Driver Class Initialized
INFO - 2024-10-28 07:57:29 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-28 07:57:29 --> Controller Class Initialized
INFO - 2024-10-28 07:57:30 --> Config Class Initialized
INFO - 2024-10-28 07:57:30 --> Hooks Class Initialized
DEBUG - 2024-10-28 07:57:30 --> UTF-8 Support Enabled
INFO - 2024-10-28 07:57:30 --> Utf8 Class Initialized
INFO - 2024-10-28 07:57:30 --> URI Class Initialized
INFO - 2024-10-28 07:57:30 --> Router Class Initialized
INFO - 2024-10-28 07:57:30 --> Output Class Initialized
INFO - 2024-10-28 07:57:30 --> Security Class Initialized
DEBUG - 2024-10-28 07:57:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-28 07:57:30 --> Input Class Initialized
INFO - 2024-10-28 07:57:30 --> Language Class Initialized
INFO - 2024-10-28 07:57:30 --> Language Class Initialized
INFO - 2024-10-28 07:57:30 --> Config Class Initialized
INFO - 2024-10-28 07:57:30 --> Loader Class Initialized
INFO - 2024-10-28 07:57:30 --> Helper loaded: url_helper
INFO - 2024-10-28 07:57:30 --> Helper loaded: file_helper
INFO - 2024-10-28 07:57:30 --> Helper loaded: form_helper
INFO - 2024-10-28 07:57:30 --> Helper loaded: my_helper
INFO - 2024-10-28 07:57:30 --> Database Driver Class Initialized
INFO - 2024-10-28 07:57:30 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-28 07:57:30 --> Controller Class Initialized
INFO - 2024-10-28 07:57:30 --> Config Class Initialized
INFO - 2024-10-28 07:57:30 --> Hooks Class Initialized
DEBUG - 2024-10-28 07:57:30 --> UTF-8 Support Enabled
INFO - 2024-10-28 07:57:30 --> Utf8 Class Initialized
INFO - 2024-10-28 07:57:30 --> URI Class Initialized
INFO - 2024-10-28 07:57:30 --> Router Class Initialized
INFO - 2024-10-28 07:57:30 --> Output Class Initialized
INFO - 2024-10-28 07:57:30 --> Security Class Initialized
DEBUG - 2024-10-28 07:57:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-28 07:57:30 --> Input Class Initialized
INFO - 2024-10-28 07:57:30 --> Language Class Initialized
INFO - 2024-10-28 07:57:30 --> Language Class Initialized
INFO - 2024-10-28 07:57:30 --> Config Class Initialized
INFO - 2024-10-28 07:57:30 --> Loader Class Initialized
INFO - 2024-10-28 07:57:30 --> Helper loaded: url_helper
INFO - 2024-10-28 07:57:30 --> Helper loaded: file_helper
INFO - 2024-10-28 07:57:30 --> Helper loaded: form_helper
INFO - 2024-10-28 07:57:30 --> Helper loaded: my_helper
INFO - 2024-10-28 07:57:30 --> Database Driver Class Initialized
INFO - 2024-10-28 07:57:30 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-28 07:57:30 --> Controller Class Initialized
INFO - 2024-10-28 07:57:32 --> Config Class Initialized
INFO - 2024-10-28 07:57:32 --> Hooks Class Initialized
DEBUG - 2024-10-28 07:57:32 --> UTF-8 Support Enabled
INFO - 2024-10-28 07:57:32 --> Utf8 Class Initialized
INFO - 2024-10-28 07:57:32 --> URI Class Initialized
INFO - 2024-10-28 07:57:32 --> Router Class Initialized
INFO - 2024-10-28 07:57:32 --> Output Class Initialized
INFO - 2024-10-28 07:57:32 --> Security Class Initialized
DEBUG - 2024-10-28 07:57:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-28 07:57:32 --> Input Class Initialized
INFO - 2024-10-28 07:57:32 --> Language Class Initialized
INFO - 2024-10-28 07:57:32 --> Language Class Initialized
INFO - 2024-10-28 07:57:32 --> Config Class Initialized
INFO - 2024-10-28 07:57:32 --> Loader Class Initialized
INFO - 2024-10-28 07:57:32 --> Helper loaded: url_helper
INFO - 2024-10-28 07:57:32 --> Helper loaded: file_helper
INFO - 2024-10-28 07:57:32 --> Helper loaded: form_helper
INFO - 2024-10-28 07:57:32 --> Helper loaded: my_helper
INFO - 2024-10-28 07:57:32 --> Database Driver Class Initialized
INFO - 2024-10-28 07:57:32 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-28 07:57:32 --> Controller Class Initialized
ERROR - 2024-10-28 07:57:32 --> Severity: Notice --> Undefined variable: status_form /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/data_siswa/views/form.php 231
DEBUG - 2024-10-28 07:57:32 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/data_siswa/views/form.php
DEBUG - 2024-10-28 07:57:32 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-10-28 07:57:32 --> Final output sent to browser
DEBUG - 2024-10-28 07:57:32 --> Total execution time: 0.0345
INFO - 2024-10-28 07:57:40 --> Config Class Initialized
INFO - 2024-10-28 07:57:40 --> Hooks Class Initialized
DEBUG - 2024-10-28 07:57:40 --> UTF-8 Support Enabled
INFO - 2024-10-28 07:57:40 --> Utf8 Class Initialized
INFO - 2024-10-28 07:57:40 --> URI Class Initialized
INFO - 2024-10-28 07:57:40 --> Router Class Initialized
INFO - 2024-10-28 07:57:40 --> Output Class Initialized
INFO - 2024-10-28 07:57:40 --> Security Class Initialized
DEBUG - 2024-10-28 07:57:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-28 07:57:40 --> Input Class Initialized
INFO - 2024-10-28 07:57:40 --> Language Class Initialized
INFO - 2024-10-28 07:57:40 --> Language Class Initialized
INFO - 2024-10-28 07:57:40 --> Config Class Initialized
INFO - 2024-10-28 07:57:40 --> Loader Class Initialized
INFO - 2024-10-28 07:57:40 --> Helper loaded: url_helper
INFO - 2024-10-28 07:57:40 --> Helper loaded: file_helper
INFO - 2024-10-28 07:57:40 --> Helper loaded: form_helper
INFO - 2024-10-28 07:57:40 --> Helper loaded: my_helper
INFO - 2024-10-28 07:57:40 --> Database Driver Class Initialized
INFO - 2024-10-28 07:57:40 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-28 07:57:40 --> Controller Class Initialized
INFO - 2024-10-28 07:57:40 --> Upload Class Initialized
INFO - 2024-10-28 07:57:40 --> Language file loaded: language/english/upload_lang.php
ERROR - 2024-10-28 07:57:40 --> The upload path does not appear to be valid.
INFO - 2024-10-28 07:57:40 --> Config Class Initialized
INFO - 2024-10-28 07:57:40 --> Hooks Class Initialized
DEBUG - 2024-10-28 07:57:40 --> UTF-8 Support Enabled
INFO - 2024-10-28 07:57:40 --> Utf8 Class Initialized
INFO - 2024-10-28 07:57:40 --> URI Class Initialized
INFO - 2024-10-28 07:57:40 --> Router Class Initialized
INFO - 2024-10-28 07:57:40 --> Output Class Initialized
INFO - 2024-10-28 07:57:40 --> Security Class Initialized
DEBUG - 2024-10-28 07:57:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-28 07:57:40 --> Input Class Initialized
INFO - 2024-10-28 07:57:40 --> Language Class Initialized
INFO - 2024-10-28 07:57:40 --> Language Class Initialized
INFO - 2024-10-28 07:57:40 --> Config Class Initialized
INFO - 2024-10-28 07:57:40 --> Loader Class Initialized
INFO - 2024-10-28 07:57:40 --> Helper loaded: url_helper
INFO - 2024-10-28 07:57:40 --> Helper loaded: file_helper
INFO - 2024-10-28 07:57:40 --> Helper loaded: form_helper
INFO - 2024-10-28 07:57:40 --> Helper loaded: my_helper
INFO - 2024-10-28 07:57:40 --> Database Driver Class Initialized
INFO - 2024-10-28 07:57:40 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-28 07:57:40 --> Controller Class Initialized
DEBUG - 2024-10-28 07:57:40 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/data_siswa/views/list.php
DEBUG - 2024-10-28 07:57:40 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-10-28 07:57:40 --> Final output sent to browser
DEBUG - 2024-10-28 07:57:40 --> Total execution time: 0.0484
INFO - 2024-10-28 07:57:40 --> Config Class Initialized
INFO - 2024-10-28 07:57:40 --> Hooks Class Initialized
DEBUG - 2024-10-28 07:57:40 --> UTF-8 Support Enabled
INFO - 2024-10-28 07:57:40 --> Utf8 Class Initialized
INFO - 2024-10-28 07:57:40 --> URI Class Initialized
INFO - 2024-10-28 07:57:40 --> Router Class Initialized
INFO - 2024-10-28 07:57:40 --> Output Class Initialized
INFO - 2024-10-28 07:57:40 --> Security Class Initialized
DEBUG - 2024-10-28 07:57:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-28 07:57:40 --> Input Class Initialized
INFO - 2024-10-28 07:57:40 --> Language Class Initialized
ERROR - 2024-10-28 07:57:40 --> 404 Page Not Found: /index
INFO - 2024-10-28 07:57:40 --> Config Class Initialized
INFO - 2024-10-28 07:57:40 --> Hooks Class Initialized
DEBUG - 2024-10-28 07:57:40 --> UTF-8 Support Enabled
INFO - 2024-10-28 07:57:40 --> Utf8 Class Initialized
INFO - 2024-10-28 07:57:40 --> URI Class Initialized
INFO - 2024-10-28 07:57:40 --> Router Class Initialized
INFO - 2024-10-28 07:57:40 --> Output Class Initialized
INFO - 2024-10-28 07:57:40 --> Security Class Initialized
DEBUG - 2024-10-28 07:57:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-28 07:57:40 --> Input Class Initialized
INFO - 2024-10-28 07:57:40 --> Language Class Initialized
INFO - 2024-10-28 07:57:40 --> Language Class Initialized
INFO - 2024-10-28 07:57:40 --> Config Class Initialized
INFO - 2024-10-28 07:57:40 --> Loader Class Initialized
INFO - 2024-10-28 07:57:40 --> Helper loaded: url_helper
INFO - 2024-10-28 07:57:40 --> Helper loaded: file_helper
INFO - 2024-10-28 07:57:40 --> Helper loaded: form_helper
INFO - 2024-10-28 07:57:40 --> Helper loaded: my_helper
INFO - 2024-10-28 07:57:40 --> Database Driver Class Initialized
INFO - 2024-10-28 07:57:40 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-28 07:57:40 --> Controller Class Initialized
INFO - 2024-10-28 07:58:01 --> Config Class Initialized
INFO - 2024-10-28 07:58:01 --> Hooks Class Initialized
DEBUG - 2024-10-28 07:58:01 --> UTF-8 Support Enabled
INFO - 2024-10-28 07:58:01 --> Utf8 Class Initialized
INFO - 2024-10-28 07:58:01 --> URI Class Initialized
INFO - 2024-10-28 07:58:01 --> Router Class Initialized
INFO - 2024-10-28 07:58:01 --> Output Class Initialized
INFO - 2024-10-28 07:58:01 --> Security Class Initialized
DEBUG - 2024-10-28 07:58:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-28 07:58:01 --> Input Class Initialized
INFO - 2024-10-28 07:58:01 --> Language Class Initialized
INFO - 2024-10-28 07:58:01 --> Language Class Initialized
INFO - 2024-10-28 07:58:01 --> Config Class Initialized
INFO - 2024-10-28 07:58:01 --> Loader Class Initialized
INFO - 2024-10-28 07:58:01 --> Helper loaded: url_helper
INFO - 2024-10-28 07:58:01 --> Helper loaded: file_helper
INFO - 2024-10-28 07:58:01 --> Helper loaded: form_helper
INFO - 2024-10-28 07:58:01 --> Helper loaded: my_helper
INFO - 2024-10-28 07:58:01 --> Database Driver Class Initialized
INFO - 2024-10-28 07:58:01 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-28 07:58:01 --> Controller Class Initialized
INFO - 2024-10-28 07:58:01 --> Config Class Initialized
INFO - 2024-10-28 07:58:01 --> Hooks Class Initialized
DEBUG - 2024-10-28 07:58:01 --> UTF-8 Support Enabled
INFO - 2024-10-28 07:58:01 --> Utf8 Class Initialized
INFO - 2024-10-28 07:58:01 --> URI Class Initialized
INFO - 2024-10-28 07:58:01 --> Router Class Initialized
INFO - 2024-10-28 07:58:01 --> Output Class Initialized
INFO - 2024-10-28 07:58:01 --> Security Class Initialized
DEBUG - 2024-10-28 07:58:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-28 07:58:01 --> Input Class Initialized
INFO - 2024-10-28 07:58:01 --> Language Class Initialized
INFO - 2024-10-28 07:58:01 --> Language Class Initialized
INFO - 2024-10-28 07:58:01 --> Config Class Initialized
INFO - 2024-10-28 07:58:01 --> Loader Class Initialized
INFO - 2024-10-28 07:58:01 --> Helper loaded: url_helper
INFO - 2024-10-28 07:58:01 --> Helper loaded: file_helper
INFO - 2024-10-28 07:58:01 --> Helper loaded: form_helper
INFO - 2024-10-28 07:58:01 --> Helper loaded: my_helper
INFO - 2024-10-28 07:58:01 --> Database Driver Class Initialized
INFO - 2024-10-28 07:58:01 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-28 07:58:01 --> Controller Class Initialized
INFO - 2024-10-28 07:58:02 --> Config Class Initialized
INFO - 2024-10-28 07:58:02 --> Hooks Class Initialized
DEBUG - 2024-10-28 07:58:02 --> UTF-8 Support Enabled
INFO - 2024-10-28 07:58:02 --> Utf8 Class Initialized
INFO - 2024-10-28 07:58:02 --> URI Class Initialized
INFO - 2024-10-28 07:58:02 --> Router Class Initialized
INFO - 2024-10-28 07:58:02 --> Output Class Initialized
INFO - 2024-10-28 07:58:02 --> Security Class Initialized
DEBUG - 2024-10-28 07:58:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-28 07:58:02 --> Input Class Initialized
INFO - 2024-10-28 07:58:02 --> Language Class Initialized
INFO - 2024-10-28 07:58:02 --> Language Class Initialized
INFO - 2024-10-28 07:58:02 --> Config Class Initialized
INFO - 2024-10-28 07:58:02 --> Loader Class Initialized
INFO - 2024-10-28 07:58:02 --> Helper loaded: url_helper
INFO - 2024-10-28 07:58:02 --> Helper loaded: file_helper
INFO - 2024-10-28 07:58:02 --> Helper loaded: form_helper
INFO - 2024-10-28 07:58:02 --> Helper loaded: my_helper
INFO - 2024-10-28 07:58:02 --> Database Driver Class Initialized
INFO - 2024-10-28 07:58:02 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-28 07:58:02 --> Controller Class Initialized
INFO - 2024-10-28 07:58:06 --> Config Class Initialized
INFO - 2024-10-28 07:58:06 --> Hooks Class Initialized
DEBUG - 2024-10-28 07:58:06 --> UTF-8 Support Enabled
INFO - 2024-10-28 07:58:06 --> Utf8 Class Initialized
INFO - 2024-10-28 07:58:06 --> URI Class Initialized
INFO - 2024-10-28 07:58:06 --> Router Class Initialized
INFO - 2024-10-28 07:58:06 --> Output Class Initialized
INFO - 2024-10-28 07:58:06 --> Security Class Initialized
DEBUG - 2024-10-28 07:58:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-28 07:58:06 --> Input Class Initialized
INFO - 2024-10-28 07:58:06 --> Language Class Initialized
INFO - 2024-10-28 07:58:06 --> Language Class Initialized
INFO - 2024-10-28 07:58:06 --> Config Class Initialized
INFO - 2024-10-28 07:58:06 --> Loader Class Initialized
INFO - 2024-10-28 07:58:06 --> Helper loaded: url_helper
INFO - 2024-10-28 07:58:06 --> Helper loaded: file_helper
INFO - 2024-10-28 07:58:06 --> Helper loaded: form_helper
INFO - 2024-10-28 07:58:06 --> Helper loaded: my_helper
INFO - 2024-10-28 07:58:06 --> Database Driver Class Initialized
INFO - 2024-10-28 07:58:06 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-28 07:58:06 --> Controller Class Initialized
ERROR - 2024-10-28 07:58:06 --> Severity: Notice --> Undefined variable: status_form /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/data_siswa/views/form.php 231
DEBUG - 2024-10-28 07:58:06 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/data_siswa/views/form.php
DEBUG - 2024-10-28 07:58:06 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-10-28 07:58:06 --> Final output sent to browser
DEBUG - 2024-10-28 07:58:06 --> Total execution time: 0.0314
INFO - 2024-10-28 07:58:30 --> Config Class Initialized
INFO - 2024-10-28 07:58:30 --> Hooks Class Initialized
DEBUG - 2024-10-28 07:58:30 --> UTF-8 Support Enabled
INFO - 2024-10-28 07:58:30 --> Utf8 Class Initialized
INFO - 2024-10-28 07:58:30 --> URI Class Initialized
INFO - 2024-10-28 07:58:30 --> Router Class Initialized
INFO - 2024-10-28 07:58:30 --> Output Class Initialized
INFO - 2024-10-28 07:58:30 --> Security Class Initialized
DEBUG - 2024-10-28 07:58:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-28 07:58:30 --> Input Class Initialized
INFO - 2024-10-28 07:58:30 --> Language Class Initialized
INFO - 2024-10-28 07:58:30 --> Language Class Initialized
INFO - 2024-10-28 07:58:30 --> Config Class Initialized
INFO - 2024-10-28 07:58:30 --> Loader Class Initialized
INFO - 2024-10-28 07:58:30 --> Helper loaded: url_helper
INFO - 2024-10-28 07:58:30 --> Helper loaded: file_helper
INFO - 2024-10-28 07:58:30 --> Helper loaded: form_helper
INFO - 2024-10-28 07:58:30 --> Helper loaded: my_helper
INFO - 2024-10-28 07:58:30 --> Database Driver Class Initialized
INFO - 2024-10-28 07:58:30 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-28 07:58:30 --> Controller Class Initialized
INFO - 2024-10-28 07:58:30 --> Upload Class Initialized
INFO - 2024-10-28 07:58:30 --> Language file loaded: language/english/upload_lang.php
ERROR - 2024-10-28 07:58:30 --> The upload path does not appear to be valid.
INFO - 2024-10-28 07:58:30 --> Config Class Initialized
INFO - 2024-10-28 07:58:30 --> Hooks Class Initialized
DEBUG - 2024-10-28 07:58:30 --> UTF-8 Support Enabled
INFO - 2024-10-28 07:58:30 --> Utf8 Class Initialized
INFO - 2024-10-28 07:58:30 --> URI Class Initialized
INFO - 2024-10-28 07:58:30 --> Router Class Initialized
INFO - 2024-10-28 07:58:30 --> Output Class Initialized
INFO - 2024-10-28 07:58:30 --> Security Class Initialized
DEBUG - 2024-10-28 07:58:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-28 07:58:30 --> Input Class Initialized
INFO - 2024-10-28 07:58:30 --> Language Class Initialized
INFO - 2024-10-28 07:58:30 --> Language Class Initialized
INFO - 2024-10-28 07:58:30 --> Config Class Initialized
INFO - 2024-10-28 07:58:30 --> Loader Class Initialized
INFO - 2024-10-28 07:58:30 --> Helper loaded: url_helper
INFO - 2024-10-28 07:58:30 --> Helper loaded: file_helper
INFO - 2024-10-28 07:58:30 --> Helper loaded: form_helper
INFO - 2024-10-28 07:58:30 --> Helper loaded: my_helper
INFO - 2024-10-28 07:58:30 --> Database Driver Class Initialized
INFO - 2024-10-28 07:58:30 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-28 07:58:30 --> Controller Class Initialized
DEBUG - 2024-10-28 07:58:30 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/data_siswa/views/list.php
DEBUG - 2024-10-28 07:58:30 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-10-28 07:58:30 --> Final output sent to browser
DEBUG - 2024-10-28 07:58:30 --> Total execution time: 0.0368
INFO - 2024-10-28 07:58:30 --> Config Class Initialized
INFO - 2024-10-28 07:58:30 --> Hooks Class Initialized
DEBUG - 2024-10-28 07:58:30 --> UTF-8 Support Enabled
INFO - 2024-10-28 07:58:30 --> Utf8 Class Initialized
INFO - 2024-10-28 07:58:30 --> URI Class Initialized
INFO - 2024-10-28 07:58:30 --> Router Class Initialized
INFO - 2024-10-28 07:58:30 --> Output Class Initialized
INFO - 2024-10-28 07:58:30 --> Security Class Initialized
DEBUG - 2024-10-28 07:58:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-28 07:58:30 --> Input Class Initialized
INFO - 2024-10-28 07:58:30 --> Language Class Initialized
ERROR - 2024-10-28 07:58:30 --> 404 Page Not Found: /index
INFO - 2024-10-28 07:58:30 --> Config Class Initialized
INFO - 2024-10-28 07:58:30 --> Hooks Class Initialized
DEBUG - 2024-10-28 07:58:30 --> UTF-8 Support Enabled
INFO - 2024-10-28 07:58:30 --> Utf8 Class Initialized
INFO - 2024-10-28 07:58:30 --> URI Class Initialized
INFO - 2024-10-28 07:58:30 --> Router Class Initialized
INFO - 2024-10-28 07:58:30 --> Output Class Initialized
INFO - 2024-10-28 07:58:30 --> Security Class Initialized
DEBUG - 2024-10-28 07:58:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-28 07:58:30 --> Input Class Initialized
INFO - 2024-10-28 07:58:30 --> Language Class Initialized
INFO - 2024-10-28 07:58:30 --> Language Class Initialized
INFO - 2024-10-28 07:58:30 --> Config Class Initialized
INFO - 2024-10-28 07:58:30 --> Loader Class Initialized
INFO - 2024-10-28 07:58:30 --> Helper loaded: url_helper
INFO - 2024-10-28 07:58:30 --> Helper loaded: file_helper
INFO - 2024-10-28 07:58:30 --> Helper loaded: form_helper
INFO - 2024-10-28 07:58:30 --> Helper loaded: my_helper
INFO - 2024-10-28 07:58:30 --> Database Driver Class Initialized
INFO - 2024-10-28 07:58:30 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-28 07:58:30 --> Controller Class Initialized
INFO - 2024-10-28 07:58:42 --> Config Class Initialized
INFO - 2024-10-28 07:58:42 --> Hooks Class Initialized
DEBUG - 2024-10-28 07:58:42 --> UTF-8 Support Enabled
INFO - 2024-10-28 07:58:42 --> Utf8 Class Initialized
INFO - 2024-10-28 07:58:42 --> URI Class Initialized
INFO - 2024-10-28 07:58:42 --> Router Class Initialized
INFO - 2024-10-28 07:58:42 --> Output Class Initialized
INFO - 2024-10-28 07:58:42 --> Security Class Initialized
DEBUG - 2024-10-28 07:58:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-28 07:58:42 --> Input Class Initialized
INFO - 2024-10-28 07:58:42 --> Language Class Initialized
INFO - 2024-10-28 07:58:42 --> Language Class Initialized
INFO - 2024-10-28 07:58:42 --> Config Class Initialized
INFO - 2024-10-28 07:58:42 --> Loader Class Initialized
INFO - 2024-10-28 07:58:42 --> Helper loaded: url_helper
INFO - 2024-10-28 07:58:42 --> Helper loaded: file_helper
INFO - 2024-10-28 07:58:42 --> Helper loaded: form_helper
INFO - 2024-10-28 07:58:42 --> Helper loaded: my_helper
INFO - 2024-10-28 07:58:42 --> Database Driver Class Initialized
INFO - 2024-10-28 07:58:42 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-28 07:58:42 --> Controller Class Initialized
INFO - 2024-10-28 07:58:43 --> Config Class Initialized
INFO - 2024-10-28 07:58:43 --> Hooks Class Initialized
DEBUG - 2024-10-28 07:58:43 --> UTF-8 Support Enabled
INFO - 2024-10-28 07:58:43 --> Utf8 Class Initialized
INFO - 2024-10-28 07:58:43 --> URI Class Initialized
INFO - 2024-10-28 07:58:43 --> Router Class Initialized
INFO - 2024-10-28 07:58:43 --> Output Class Initialized
INFO - 2024-10-28 07:58:43 --> Security Class Initialized
DEBUG - 2024-10-28 07:58:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-28 07:58:43 --> Input Class Initialized
INFO - 2024-10-28 07:58:43 --> Language Class Initialized
INFO - 2024-10-28 07:58:43 --> Language Class Initialized
INFO - 2024-10-28 07:58:43 --> Config Class Initialized
INFO - 2024-10-28 07:58:43 --> Loader Class Initialized
INFO - 2024-10-28 07:58:43 --> Helper loaded: url_helper
INFO - 2024-10-28 07:58:43 --> Helper loaded: file_helper
INFO - 2024-10-28 07:58:43 --> Helper loaded: form_helper
INFO - 2024-10-28 07:58:43 --> Helper loaded: my_helper
INFO - 2024-10-28 07:58:43 --> Database Driver Class Initialized
INFO - 2024-10-28 07:58:43 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-28 07:58:43 --> Controller Class Initialized
INFO - 2024-10-28 07:58:52 --> Config Class Initialized
INFO - 2024-10-28 07:58:52 --> Hooks Class Initialized
DEBUG - 2024-10-28 07:58:52 --> UTF-8 Support Enabled
INFO - 2024-10-28 07:58:52 --> Utf8 Class Initialized
INFO - 2024-10-28 07:58:52 --> URI Class Initialized
INFO - 2024-10-28 07:58:52 --> Router Class Initialized
INFO - 2024-10-28 07:58:52 --> Output Class Initialized
INFO - 2024-10-28 07:58:52 --> Security Class Initialized
DEBUG - 2024-10-28 07:58:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-28 07:58:52 --> Input Class Initialized
INFO - 2024-10-28 07:58:52 --> Language Class Initialized
INFO - 2024-10-28 07:58:52 --> Language Class Initialized
INFO - 2024-10-28 07:58:52 --> Config Class Initialized
INFO - 2024-10-28 07:58:52 --> Loader Class Initialized
INFO - 2024-10-28 07:58:52 --> Helper loaded: url_helper
INFO - 2024-10-28 07:58:52 --> Helper loaded: file_helper
INFO - 2024-10-28 07:58:52 --> Helper loaded: form_helper
INFO - 2024-10-28 07:58:52 --> Helper loaded: my_helper
INFO - 2024-10-28 07:58:52 --> Database Driver Class Initialized
INFO - 2024-10-28 07:58:52 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-28 07:58:52 --> Controller Class Initialized
ERROR - 2024-10-28 07:58:52 --> Severity: Notice --> Undefined variable: status_form /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/data_siswa/views/form.php 231
DEBUG - 2024-10-28 07:58:52 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/data_siswa/views/form.php
DEBUG - 2024-10-28 07:58:52 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-10-28 07:58:52 --> Final output sent to browser
DEBUG - 2024-10-28 07:58:52 --> Total execution time: 0.0601
INFO - 2024-10-28 07:59:13 --> Config Class Initialized
INFO - 2024-10-28 07:59:13 --> Hooks Class Initialized
DEBUG - 2024-10-28 07:59:13 --> UTF-8 Support Enabled
INFO - 2024-10-28 07:59:13 --> Utf8 Class Initialized
INFO - 2024-10-28 07:59:13 --> URI Class Initialized
INFO - 2024-10-28 07:59:13 --> Router Class Initialized
INFO - 2024-10-28 07:59:13 --> Output Class Initialized
INFO - 2024-10-28 07:59:13 --> Security Class Initialized
DEBUG - 2024-10-28 07:59:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-28 07:59:13 --> Input Class Initialized
INFO - 2024-10-28 07:59:13 --> Language Class Initialized
INFO - 2024-10-28 07:59:13 --> Language Class Initialized
INFO - 2024-10-28 07:59:13 --> Config Class Initialized
INFO - 2024-10-28 07:59:13 --> Loader Class Initialized
INFO - 2024-10-28 07:59:13 --> Helper loaded: url_helper
INFO - 2024-10-28 07:59:13 --> Helper loaded: file_helper
INFO - 2024-10-28 07:59:13 --> Helper loaded: form_helper
INFO - 2024-10-28 07:59:13 --> Helper loaded: my_helper
INFO - 2024-10-28 07:59:13 --> Database Driver Class Initialized
INFO - 2024-10-28 07:59:13 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-28 07:59:13 --> Controller Class Initialized
INFO - 2024-10-28 07:59:13 --> Upload Class Initialized
INFO - 2024-10-28 07:59:13 --> Language file loaded: language/english/upload_lang.php
ERROR - 2024-10-28 07:59:13 --> The upload path does not appear to be valid.
INFO - 2024-10-28 07:59:13 --> Config Class Initialized
INFO - 2024-10-28 07:59:13 --> Hooks Class Initialized
DEBUG - 2024-10-28 07:59:13 --> UTF-8 Support Enabled
INFO - 2024-10-28 07:59:13 --> Utf8 Class Initialized
INFO - 2024-10-28 07:59:13 --> URI Class Initialized
INFO - 2024-10-28 07:59:13 --> Router Class Initialized
INFO - 2024-10-28 07:59:13 --> Output Class Initialized
INFO - 2024-10-28 07:59:13 --> Security Class Initialized
DEBUG - 2024-10-28 07:59:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-28 07:59:13 --> Input Class Initialized
INFO - 2024-10-28 07:59:13 --> Language Class Initialized
INFO - 2024-10-28 07:59:13 --> Language Class Initialized
INFO - 2024-10-28 07:59:13 --> Config Class Initialized
INFO - 2024-10-28 07:59:13 --> Loader Class Initialized
INFO - 2024-10-28 07:59:13 --> Helper loaded: url_helper
INFO - 2024-10-28 07:59:13 --> Helper loaded: file_helper
INFO - 2024-10-28 07:59:13 --> Helper loaded: form_helper
INFO - 2024-10-28 07:59:13 --> Helper loaded: my_helper
INFO - 2024-10-28 07:59:13 --> Database Driver Class Initialized
INFO - 2024-10-28 07:59:13 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-28 07:59:13 --> Controller Class Initialized
DEBUG - 2024-10-28 07:59:13 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/data_siswa/views/list.php
DEBUG - 2024-10-28 07:59:13 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-10-28 07:59:13 --> Final output sent to browser
DEBUG - 2024-10-28 07:59:13 --> Total execution time: 0.0310
INFO - 2024-10-28 07:59:13 --> Config Class Initialized
INFO - 2024-10-28 07:59:13 --> Hooks Class Initialized
DEBUG - 2024-10-28 07:59:13 --> UTF-8 Support Enabled
INFO - 2024-10-28 07:59:13 --> Utf8 Class Initialized
INFO - 2024-10-28 07:59:13 --> URI Class Initialized
INFO - 2024-10-28 07:59:13 --> Router Class Initialized
INFO - 2024-10-28 07:59:13 --> Output Class Initialized
INFO - 2024-10-28 07:59:13 --> Security Class Initialized
DEBUG - 2024-10-28 07:59:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-28 07:59:13 --> Input Class Initialized
INFO - 2024-10-28 07:59:13 --> Language Class Initialized
ERROR - 2024-10-28 07:59:13 --> 404 Page Not Found: /index
INFO - 2024-10-28 07:59:13 --> Config Class Initialized
INFO - 2024-10-28 07:59:13 --> Hooks Class Initialized
DEBUG - 2024-10-28 07:59:13 --> UTF-8 Support Enabled
INFO - 2024-10-28 07:59:13 --> Utf8 Class Initialized
INFO - 2024-10-28 07:59:13 --> URI Class Initialized
INFO - 2024-10-28 07:59:13 --> Router Class Initialized
INFO - 2024-10-28 07:59:13 --> Output Class Initialized
INFO - 2024-10-28 07:59:13 --> Security Class Initialized
DEBUG - 2024-10-28 07:59:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-28 07:59:13 --> Input Class Initialized
INFO - 2024-10-28 07:59:13 --> Language Class Initialized
INFO - 2024-10-28 07:59:13 --> Language Class Initialized
INFO - 2024-10-28 07:59:13 --> Config Class Initialized
INFO - 2024-10-28 07:59:13 --> Loader Class Initialized
INFO - 2024-10-28 07:59:13 --> Helper loaded: url_helper
INFO - 2024-10-28 07:59:13 --> Helper loaded: file_helper
INFO - 2024-10-28 07:59:13 --> Helper loaded: form_helper
INFO - 2024-10-28 07:59:13 --> Helper loaded: my_helper
INFO - 2024-10-28 07:59:13 --> Database Driver Class Initialized
INFO - 2024-10-28 07:59:13 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-28 07:59:13 --> Controller Class Initialized
INFO - 2024-10-28 07:59:23 --> Config Class Initialized
INFO - 2024-10-28 07:59:23 --> Hooks Class Initialized
DEBUG - 2024-10-28 07:59:23 --> UTF-8 Support Enabled
INFO - 2024-10-28 07:59:23 --> Utf8 Class Initialized
INFO - 2024-10-28 07:59:23 --> URI Class Initialized
INFO - 2024-10-28 07:59:23 --> Router Class Initialized
INFO - 2024-10-28 07:59:23 --> Output Class Initialized
INFO - 2024-10-28 07:59:23 --> Security Class Initialized
DEBUG - 2024-10-28 07:59:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-28 07:59:23 --> Input Class Initialized
INFO - 2024-10-28 07:59:23 --> Language Class Initialized
INFO - 2024-10-28 07:59:23 --> Language Class Initialized
INFO - 2024-10-28 07:59:23 --> Config Class Initialized
INFO - 2024-10-28 07:59:23 --> Loader Class Initialized
INFO - 2024-10-28 07:59:23 --> Helper loaded: url_helper
INFO - 2024-10-28 07:59:23 --> Helper loaded: file_helper
INFO - 2024-10-28 07:59:23 --> Helper loaded: form_helper
INFO - 2024-10-28 07:59:23 --> Helper loaded: my_helper
INFO - 2024-10-28 07:59:23 --> Database Driver Class Initialized
INFO - 2024-10-28 07:59:23 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-28 07:59:23 --> Controller Class Initialized
INFO - 2024-10-28 07:59:23 --> Config Class Initialized
INFO - 2024-10-28 07:59:23 --> Hooks Class Initialized
DEBUG - 2024-10-28 07:59:23 --> UTF-8 Support Enabled
INFO - 2024-10-28 07:59:23 --> Utf8 Class Initialized
INFO - 2024-10-28 07:59:23 --> URI Class Initialized
INFO - 2024-10-28 07:59:23 --> Router Class Initialized
INFO - 2024-10-28 07:59:23 --> Output Class Initialized
INFO - 2024-10-28 07:59:23 --> Security Class Initialized
DEBUG - 2024-10-28 07:59:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-28 07:59:23 --> Input Class Initialized
INFO - 2024-10-28 07:59:23 --> Language Class Initialized
INFO - 2024-10-28 07:59:23 --> Language Class Initialized
INFO - 2024-10-28 07:59:23 --> Config Class Initialized
INFO - 2024-10-28 07:59:23 --> Loader Class Initialized
INFO - 2024-10-28 07:59:23 --> Helper loaded: url_helper
INFO - 2024-10-28 07:59:23 --> Helper loaded: file_helper
INFO - 2024-10-28 07:59:23 --> Helper loaded: form_helper
INFO - 2024-10-28 07:59:23 --> Helper loaded: my_helper
INFO - 2024-10-28 07:59:23 --> Database Driver Class Initialized
INFO - 2024-10-28 07:59:23 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-28 07:59:23 --> Controller Class Initialized
INFO - 2024-10-28 07:59:24 --> Config Class Initialized
INFO - 2024-10-28 07:59:24 --> Hooks Class Initialized
DEBUG - 2024-10-28 07:59:24 --> UTF-8 Support Enabled
INFO - 2024-10-28 07:59:24 --> Utf8 Class Initialized
INFO - 2024-10-28 07:59:24 --> URI Class Initialized
INFO - 2024-10-28 07:59:24 --> Router Class Initialized
INFO - 2024-10-28 07:59:24 --> Output Class Initialized
INFO - 2024-10-28 07:59:24 --> Security Class Initialized
DEBUG - 2024-10-28 07:59:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-28 07:59:24 --> Input Class Initialized
INFO - 2024-10-28 07:59:24 --> Language Class Initialized
INFO - 2024-10-28 07:59:24 --> Language Class Initialized
INFO - 2024-10-28 07:59:24 --> Config Class Initialized
INFO - 2024-10-28 07:59:24 --> Loader Class Initialized
INFO - 2024-10-28 07:59:24 --> Helper loaded: url_helper
INFO - 2024-10-28 07:59:24 --> Helper loaded: file_helper
INFO - 2024-10-28 07:59:24 --> Helper loaded: form_helper
INFO - 2024-10-28 07:59:24 --> Helper loaded: my_helper
INFO - 2024-10-28 07:59:24 --> Database Driver Class Initialized
INFO - 2024-10-28 07:59:24 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-28 07:59:24 --> Controller Class Initialized
INFO - 2024-10-28 07:59:25 --> Config Class Initialized
INFO - 2024-10-28 07:59:25 --> Hooks Class Initialized
DEBUG - 2024-10-28 07:59:25 --> UTF-8 Support Enabled
INFO - 2024-10-28 07:59:25 --> Utf8 Class Initialized
INFO - 2024-10-28 07:59:25 --> URI Class Initialized
INFO - 2024-10-28 07:59:25 --> Router Class Initialized
INFO - 2024-10-28 07:59:25 --> Output Class Initialized
INFO - 2024-10-28 07:59:25 --> Security Class Initialized
DEBUG - 2024-10-28 07:59:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-28 07:59:25 --> Input Class Initialized
INFO - 2024-10-28 07:59:25 --> Language Class Initialized
INFO - 2024-10-28 07:59:25 --> Language Class Initialized
INFO - 2024-10-28 07:59:25 --> Config Class Initialized
INFO - 2024-10-28 07:59:25 --> Loader Class Initialized
INFO - 2024-10-28 07:59:25 --> Helper loaded: url_helper
INFO - 2024-10-28 07:59:25 --> Helper loaded: file_helper
INFO - 2024-10-28 07:59:25 --> Helper loaded: form_helper
INFO - 2024-10-28 07:59:25 --> Helper loaded: my_helper
INFO - 2024-10-28 07:59:25 --> Database Driver Class Initialized
INFO - 2024-10-28 07:59:25 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-28 07:59:25 --> Controller Class Initialized
ERROR - 2024-10-28 07:59:25 --> Severity: Notice --> Undefined variable: status_form /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/data_siswa/views/form.php 231
DEBUG - 2024-10-28 07:59:25 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/data_siswa/views/form.php
DEBUG - 2024-10-28 07:59:25 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-10-28 07:59:25 --> Final output sent to browser
DEBUG - 2024-10-28 07:59:25 --> Total execution time: 0.0409
INFO - 2024-10-28 07:59:44 --> Config Class Initialized
INFO - 2024-10-28 07:59:44 --> Hooks Class Initialized
DEBUG - 2024-10-28 07:59:44 --> UTF-8 Support Enabled
INFO - 2024-10-28 07:59:44 --> Utf8 Class Initialized
INFO - 2024-10-28 07:59:44 --> URI Class Initialized
INFO - 2024-10-28 07:59:44 --> Router Class Initialized
INFO - 2024-10-28 07:59:44 --> Output Class Initialized
INFO - 2024-10-28 07:59:44 --> Security Class Initialized
DEBUG - 2024-10-28 07:59:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-28 07:59:44 --> Input Class Initialized
INFO - 2024-10-28 07:59:44 --> Language Class Initialized
INFO - 2024-10-28 07:59:44 --> Language Class Initialized
INFO - 2024-10-28 07:59:44 --> Config Class Initialized
INFO - 2024-10-28 07:59:44 --> Loader Class Initialized
INFO - 2024-10-28 07:59:44 --> Helper loaded: url_helper
INFO - 2024-10-28 07:59:44 --> Helper loaded: file_helper
INFO - 2024-10-28 07:59:44 --> Helper loaded: form_helper
INFO - 2024-10-28 07:59:44 --> Helper loaded: my_helper
INFO - 2024-10-28 07:59:44 --> Database Driver Class Initialized
INFO - 2024-10-28 07:59:44 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-28 07:59:44 --> Controller Class Initialized
INFO - 2024-10-28 07:59:44 --> Upload Class Initialized
INFO - 2024-10-28 07:59:44 --> Language file loaded: language/english/upload_lang.php
ERROR - 2024-10-28 07:59:44 --> The upload path does not appear to be valid.
INFO - 2024-10-28 07:59:44 --> Config Class Initialized
INFO - 2024-10-28 07:59:44 --> Hooks Class Initialized
DEBUG - 2024-10-28 07:59:44 --> UTF-8 Support Enabled
INFO - 2024-10-28 07:59:44 --> Utf8 Class Initialized
INFO - 2024-10-28 07:59:44 --> URI Class Initialized
INFO - 2024-10-28 07:59:44 --> Router Class Initialized
INFO - 2024-10-28 07:59:44 --> Output Class Initialized
INFO - 2024-10-28 07:59:44 --> Security Class Initialized
DEBUG - 2024-10-28 07:59:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-28 07:59:44 --> Input Class Initialized
INFO - 2024-10-28 07:59:44 --> Language Class Initialized
INFO - 2024-10-28 07:59:44 --> Language Class Initialized
INFO - 2024-10-28 07:59:44 --> Config Class Initialized
INFO - 2024-10-28 07:59:44 --> Loader Class Initialized
INFO - 2024-10-28 07:59:44 --> Helper loaded: url_helper
INFO - 2024-10-28 07:59:44 --> Helper loaded: file_helper
INFO - 2024-10-28 07:59:44 --> Helper loaded: form_helper
INFO - 2024-10-28 07:59:44 --> Helper loaded: my_helper
INFO - 2024-10-28 07:59:44 --> Database Driver Class Initialized
INFO - 2024-10-28 07:59:44 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-28 07:59:44 --> Controller Class Initialized
DEBUG - 2024-10-28 07:59:44 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/data_siswa/views/list.php
DEBUG - 2024-10-28 07:59:44 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-10-28 07:59:44 --> Final output sent to browser
DEBUG - 2024-10-28 07:59:44 --> Total execution time: 0.0285
INFO - 2024-10-28 07:59:44 --> Config Class Initialized
INFO - 2024-10-28 07:59:44 --> Hooks Class Initialized
DEBUG - 2024-10-28 07:59:44 --> UTF-8 Support Enabled
INFO - 2024-10-28 07:59:44 --> Utf8 Class Initialized
INFO - 2024-10-28 07:59:44 --> URI Class Initialized
INFO - 2024-10-28 07:59:44 --> Router Class Initialized
INFO - 2024-10-28 07:59:44 --> Output Class Initialized
INFO - 2024-10-28 07:59:44 --> Security Class Initialized
DEBUG - 2024-10-28 07:59:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-28 07:59:44 --> Input Class Initialized
INFO - 2024-10-28 07:59:44 --> Language Class Initialized
ERROR - 2024-10-28 07:59:44 --> 404 Page Not Found: /index
INFO - 2024-10-28 07:59:44 --> Config Class Initialized
INFO - 2024-10-28 07:59:44 --> Hooks Class Initialized
DEBUG - 2024-10-28 07:59:44 --> UTF-8 Support Enabled
INFO - 2024-10-28 07:59:44 --> Utf8 Class Initialized
INFO - 2024-10-28 07:59:44 --> URI Class Initialized
INFO - 2024-10-28 07:59:44 --> Router Class Initialized
INFO - 2024-10-28 07:59:44 --> Output Class Initialized
INFO - 2024-10-28 07:59:44 --> Security Class Initialized
DEBUG - 2024-10-28 07:59:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-28 07:59:44 --> Input Class Initialized
INFO - 2024-10-28 07:59:44 --> Language Class Initialized
INFO - 2024-10-28 07:59:44 --> Language Class Initialized
INFO - 2024-10-28 07:59:44 --> Config Class Initialized
INFO - 2024-10-28 07:59:44 --> Loader Class Initialized
INFO - 2024-10-28 07:59:44 --> Helper loaded: url_helper
INFO - 2024-10-28 07:59:44 --> Helper loaded: file_helper
INFO - 2024-10-28 07:59:44 --> Helper loaded: form_helper
INFO - 2024-10-28 07:59:44 --> Helper loaded: my_helper
INFO - 2024-10-28 07:59:44 --> Database Driver Class Initialized
INFO - 2024-10-28 07:59:44 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-28 07:59:44 --> Controller Class Initialized
INFO - 2024-10-28 07:59:54 --> Config Class Initialized
INFO - 2024-10-28 07:59:54 --> Hooks Class Initialized
DEBUG - 2024-10-28 07:59:54 --> UTF-8 Support Enabled
INFO - 2024-10-28 07:59:54 --> Utf8 Class Initialized
INFO - 2024-10-28 07:59:54 --> URI Class Initialized
INFO - 2024-10-28 07:59:54 --> Router Class Initialized
INFO - 2024-10-28 07:59:54 --> Output Class Initialized
INFO - 2024-10-28 07:59:54 --> Security Class Initialized
DEBUG - 2024-10-28 07:59:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-28 07:59:54 --> Input Class Initialized
INFO - 2024-10-28 07:59:54 --> Language Class Initialized
INFO - 2024-10-28 07:59:54 --> Language Class Initialized
INFO - 2024-10-28 07:59:54 --> Config Class Initialized
INFO - 2024-10-28 07:59:54 --> Loader Class Initialized
INFO - 2024-10-28 07:59:54 --> Helper loaded: url_helper
INFO - 2024-10-28 07:59:54 --> Helper loaded: file_helper
INFO - 2024-10-28 07:59:54 --> Helper loaded: form_helper
INFO - 2024-10-28 07:59:54 --> Helper loaded: my_helper
INFO - 2024-10-28 07:59:54 --> Database Driver Class Initialized
INFO - 2024-10-28 07:59:54 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-28 07:59:54 --> Controller Class Initialized
INFO - 2024-10-28 07:59:54 --> Config Class Initialized
INFO - 2024-10-28 07:59:54 --> Hooks Class Initialized
DEBUG - 2024-10-28 07:59:54 --> UTF-8 Support Enabled
INFO - 2024-10-28 07:59:54 --> Utf8 Class Initialized
INFO - 2024-10-28 07:59:54 --> URI Class Initialized
INFO - 2024-10-28 07:59:54 --> Router Class Initialized
INFO - 2024-10-28 07:59:54 --> Output Class Initialized
INFO - 2024-10-28 07:59:54 --> Security Class Initialized
DEBUG - 2024-10-28 07:59:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-28 07:59:54 --> Input Class Initialized
INFO - 2024-10-28 07:59:54 --> Language Class Initialized
INFO - 2024-10-28 07:59:54 --> Language Class Initialized
INFO - 2024-10-28 07:59:54 --> Config Class Initialized
INFO - 2024-10-28 07:59:54 --> Loader Class Initialized
INFO - 2024-10-28 07:59:54 --> Helper loaded: url_helper
INFO - 2024-10-28 07:59:54 --> Helper loaded: file_helper
INFO - 2024-10-28 07:59:54 --> Helper loaded: form_helper
INFO - 2024-10-28 07:59:54 --> Helper loaded: my_helper
INFO - 2024-10-28 07:59:54 --> Database Driver Class Initialized
INFO - 2024-10-28 07:59:54 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-28 07:59:54 --> Controller Class Initialized
INFO - 2024-10-28 07:59:55 --> Config Class Initialized
INFO - 2024-10-28 07:59:55 --> Hooks Class Initialized
DEBUG - 2024-10-28 07:59:55 --> UTF-8 Support Enabled
INFO - 2024-10-28 07:59:55 --> Utf8 Class Initialized
INFO - 2024-10-28 07:59:55 --> URI Class Initialized
INFO - 2024-10-28 07:59:55 --> Router Class Initialized
INFO - 2024-10-28 07:59:55 --> Output Class Initialized
INFO - 2024-10-28 07:59:55 --> Security Class Initialized
DEBUG - 2024-10-28 07:59:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-28 07:59:55 --> Input Class Initialized
INFO - 2024-10-28 07:59:55 --> Language Class Initialized
INFO - 2024-10-28 07:59:55 --> Language Class Initialized
INFO - 2024-10-28 07:59:55 --> Config Class Initialized
INFO - 2024-10-28 07:59:55 --> Loader Class Initialized
INFO - 2024-10-28 07:59:55 --> Helper loaded: url_helper
INFO - 2024-10-28 07:59:55 --> Helper loaded: file_helper
INFO - 2024-10-28 07:59:55 --> Helper loaded: form_helper
INFO - 2024-10-28 07:59:55 --> Helper loaded: my_helper
INFO - 2024-10-28 07:59:55 --> Database Driver Class Initialized
INFO - 2024-10-28 07:59:55 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-28 07:59:55 --> Controller Class Initialized
INFO - 2024-10-28 07:59:55 --> Config Class Initialized
INFO - 2024-10-28 07:59:55 --> Hooks Class Initialized
DEBUG - 2024-10-28 07:59:55 --> UTF-8 Support Enabled
INFO - 2024-10-28 07:59:55 --> Utf8 Class Initialized
INFO - 2024-10-28 07:59:55 --> URI Class Initialized
INFO - 2024-10-28 07:59:55 --> Router Class Initialized
INFO - 2024-10-28 07:59:55 --> Output Class Initialized
INFO - 2024-10-28 07:59:55 --> Security Class Initialized
DEBUG - 2024-10-28 07:59:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-28 07:59:55 --> Input Class Initialized
INFO - 2024-10-28 07:59:55 --> Language Class Initialized
INFO - 2024-10-28 07:59:55 --> Language Class Initialized
INFO - 2024-10-28 07:59:55 --> Config Class Initialized
INFO - 2024-10-28 07:59:55 --> Loader Class Initialized
INFO - 2024-10-28 07:59:55 --> Helper loaded: url_helper
INFO - 2024-10-28 07:59:55 --> Helper loaded: file_helper
INFO - 2024-10-28 07:59:55 --> Helper loaded: form_helper
INFO - 2024-10-28 07:59:55 --> Helper loaded: my_helper
INFO - 2024-10-28 07:59:55 --> Database Driver Class Initialized
INFO - 2024-10-28 07:59:55 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-28 07:59:55 --> Controller Class Initialized
INFO - 2024-10-28 07:59:58 --> Config Class Initialized
INFO - 2024-10-28 07:59:58 --> Hooks Class Initialized
DEBUG - 2024-10-28 07:59:58 --> UTF-8 Support Enabled
INFO - 2024-10-28 07:59:58 --> Utf8 Class Initialized
INFO - 2024-10-28 07:59:58 --> URI Class Initialized
INFO - 2024-10-28 07:59:58 --> Router Class Initialized
INFO - 2024-10-28 07:59:58 --> Output Class Initialized
INFO - 2024-10-28 07:59:58 --> Security Class Initialized
DEBUG - 2024-10-28 07:59:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-28 07:59:58 --> Input Class Initialized
INFO - 2024-10-28 07:59:58 --> Language Class Initialized
INFO - 2024-10-28 07:59:58 --> Language Class Initialized
INFO - 2024-10-28 07:59:58 --> Config Class Initialized
INFO - 2024-10-28 07:59:58 --> Loader Class Initialized
INFO - 2024-10-28 07:59:58 --> Helper loaded: url_helper
INFO - 2024-10-28 07:59:58 --> Helper loaded: file_helper
INFO - 2024-10-28 07:59:58 --> Helper loaded: form_helper
INFO - 2024-10-28 07:59:58 --> Helper loaded: my_helper
INFO - 2024-10-28 07:59:58 --> Database Driver Class Initialized
INFO - 2024-10-28 07:59:58 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-28 07:59:58 --> Controller Class Initialized
INFO - 2024-10-28 07:59:59 --> Config Class Initialized
INFO - 2024-10-28 07:59:59 --> Hooks Class Initialized
DEBUG - 2024-10-28 07:59:59 --> UTF-8 Support Enabled
INFO - 2024-10-28 07:59:59 --> Utf8 Class Initialized
INFO - 2024-10-28 07:59:59 --> URI Class Initialized
INFO - 2024-10-28 07:59:59 --> Router Class Initialized
INFO - 2024-10-28 07:59:59 --> Output Class Initialized
INFO - 2024-10-28 07:59:59 --> Security Class Initialized
DEBUG - 2024-10-28 07:59:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-28 07:59:59 --> Input Class Initialized
INFO - 2024-10-28 07:59:59 --> Language Class Initialized
INFO - 2024-10-28 07:59:59 --> Language Class Initialized
INFO - 2024-10-28 07:59:59 --> Config Class Initialized
INFO - 2024-10-28 07:59:59 --> Loader Class Initialized
INFO - 2024-10-28 07:59:59 --> Helper loaded: url_helper
INFO - 2024-10-28 07:59:59 --> Helper loaded: file_helper
INFO - 2024-10-28 07:59:59 --> Helper loaded: form_helper
INFO - 2024-10-28 07:59:59 --> Helper loaded: my_helper
INFO - 2024-10-28 07:59:59 --> Database Driver Class Initialized
INFO - 2024-10-28 07:59:59 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-28 07:59:59 --> Controller Class Initialized
INFO - 2024-10-28 08:00:04 --> Config Class Initialized
INFO - 2024-10-28 08:00:04 --> Hooks Class Initialized
DEBUG - 2024-10-28 08:00:04 --> UTF-8 Support Enabled
INFO - 2024-10-28 08:00:04 --> Utf8 Class Initialized
INFO - 2024-10-28 08:00:04 --> URI Class Initialized
INFO - 2024-10-28 08:00:04 --> Router Class Initialized
INFO - 2024-10-28 08:00:04 --> Output Class Initialized
INFO - 2024-10-28 08:00:04 --> Security Class Initialized
DEBUG - 2024-10-28 08:00:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-28 08:00:04 --> Input Class Initialized
INFO - 2024-10-28 08:00:04 --> Language Class Initialized
INFO - 2024-10-28 08:00:04 --> Language Class Initialized
INFO - 2024-10-28 08:00:04 --> Config Class Initialized
INFO - 2024-10-28 08:00:04 --> Loader Class Initialized
INFO - 2024-10-28 08:00:04 --> Helper loaded: url_helper
INFO - 2024-10-28 08:00:04 --> Helper loaded: file_helper
INFO - 2024-10-28 08:00:04 --> Helper loaded: form_helper
INFO - 2024-10-28 08:00:04 --> Helper loaded: my_helper
INFO - 2024-10-28 08:00:04 --> Database Driver Class Initialized
INFO - 2024-10-28 08:00:04 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-28 08:00:04 --> Controller Class Initialized
ERROR - 2024-10-28 08:00:04 --> Severity: Notice --> Undefined variable: status_form /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/data_siswa/views/form.php 231
DEBUG - 2024-10-28 08:00:04 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/data_siswa/views/form.php
DEBUG - 2024-10-28 08:00:04 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-10-28 08:00:04 --> Final output sent to browser
DEBUG - 2024-10-28 08:00:04 --> Total execution time: 0.0999
INFO - 2024-10-28 08:00:26 --> Config Class Initialized
INFO - 2024-10-28 08:00:26 --> Hooks Class Initialized
DEBUG - 2024-10-28 08:00:26 --> UTF-8 Support Enabled
INFO - 2024-10-28 08:00:26 --> Utf8 Class Initialized
INFO - 2024-10-28 08:00:26 --> URI Class Initialized
INFO - 2024-10-28 08:00:26 --> Router Class Initialized
INFO - 2024-10-28 08:00:26 --> Output Class Initialized
INFO - 2024-10-28 08:00:26 --> Security Class Initialized
DEBUG - 2024-10-28 08:00:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-28 08:00:26 --> Input Class Initialized
INFO - 2024-10-28 08:00:26 --> Language Class Initialized
INFO - 2024-10-28 08:00:26 --> Language Class Initialized
INFO - 2024-10-28 08:00:26 --> Config Class Initialized
INFO - 2024-10-28 08:00:26 --> Loader Class Initialized
INFO - 2024-10-28 08:00:26 --> Helper loaded: url_helper
INFO - 2024-10-28 08:00:26 --> Helper loaded: file_helper
INFO - 2024-10-28 08:00:26 --> Helper loaded: form_helper
INFO - 2024-10-28 08:00:26 --> Helper loaded: my_helper
INFO - 2024-10-28 08:00:26 --> Database Driver Class Initialized
INFO - 2024-10-28 08:00:26 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-28 08:00:26 --> Controller Class Initialized
INFO - 2024-10-28 08:00:26 --> Upload Class Initialized
INFO - 2024-10-28 08:00:26 --> Language file loaded: language/english/upload_lang.php
ERROR - 2024-10-28 08:00:26 --> The upload path does not appear to be valid.
INFO - 2024-10-28 08:00:26 --> Config Class Initialized
INFO - 2024-10-28 08:00:26 --> Hooks Class Initialized
DEBUG - 2024-10-28 08:00:26 --> UTF-8 Support Enabled
INFO - 2024-10-28 08:00:26 --> Utf8 Class Initialized
INFO - 2024-10-28 08:00:26 --> URI Class Initialized
INFO - 2024-10-28 08:00:26 --> Router Class Initialized
INFO - 2024-10-28 08:00:26 --> Output Class Initialized
INFO - 2024-10-28 08:00:26 --> Security Class Initialized
DEBUG - 2024-10-28 08:00:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-28 08:00:26 --> Input Class Initialized
INFO - 2024-10-28 08:00:26 --> Language Class Initialized
INFO - 2024-10-28 08:00:26 --> Language Class Initialized
INFO - 2024-10-28 08:00:26 --> Config Class Initialized
INFO - 2024-10-28 08:00:26 --> Loader Class Initialized
INFO - 2024-10-28 08:00:26 --> Helper loaded: url_helper
INFO - 2024-10-28 08:00:26 --> Helper loaded: file_helper
INFO - 2024-10-28 08:00:26 --> Helper loaded: form_helper
INFO - 2024-10-28 08:00:26 --> Helper loaded: my_helper
INFO - 2024-10-28 08:00:26 --> Database Driver Class Initialized
INFO - 2024-10-28 08:00:26 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-28 08:00:26 --> Controller Class Initialized
DEBUG - 2024-10-28 08:00:26 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/data_siswa/views/list.php
DEBUG - 2024-10-28 08:00:26 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-10-28 08:00:26 --> Final output sent to browser
DEBUG - 2024-10-28 08:00:26 --> Total execution time: 0.0329
INFO - 2024-10-28 08:00:26 --> Config Class Initialized
INFO - 2024-10-28 08:00:26 --> Hooks Class Initialized
DEBUG - 2024-10-28 08:00:26 --> UTF-8 Support Enabled
INFO - 2024-10-28 08:00:26 --> Utf8 Class Initialized
INFO - 2024-10-28 08:00:26 --> URI Class Initialized
INFO - 2024-10-28 08:00:26 --> Router Class Initialized
INFO - 2024-10-28 08:00:26 --> Output Class Initialized
INFO - 2024-10-28 08:00:26 --> Security Class Initialized
DEBUG - 2024-10-28 08:00:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-28 08:00:26 --> Input Class Initialized
INFO - 2024-10-28 08:00:26 --> Language Class Initialized
ERROR - 2024-10-28 08:00:26 --> 404 Page Not Found: /index
INFO - 2024-10-28 08:00:26 --> Config Class Initialized
INFO - 2024-10-28 08:00:26 --> Hooks Class Initialized
DEBUG - 2024-10-28 08:00:26 --> UTF-8 Support Enabled
INFO - 2024-10-28 08:00:26 --> Utf8 Class Initialized
INFO - 2024-10-28 08:00:26 --> URI Class Initialized
INFO - 2024-10-28 08:00:26 --> Router Class Initialized
INFO - 2024-10-28 08:00:26 --> Output Class Initialized
INFO - 2024-10-28 08:00:26 --> Security Class Initialized
DEBUG - 2024-10-28 08:00:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-28 08:00:26 --> Input Class Initialized
INFO - 2024-10-28 08:00:26 --> Language Class Initialized
INFO - 2024-10-28 08:00:26 --> Language Class Initialized
INFO - 2024-10-28 08:00:26 --> Config Class Initialized
INFO - 2024-10-28 08:00:26 --> Loader Class Initialized
INFO - 2024-10-28 08:00:26 --> Helper loaded: url_helper
INFO - 2024-10-28 08:00:26 --> Helper loaded: file_helper
INFO - 2024-10-28 08:00:26 --> Helper loaded: form_helper
INFO - 2024-10-28 08:00:26 --> Helper loaded: my_helper
INFO - 2024-10-28 08:00:26 --> Database Driver Class Initialized
INFO - 2024-10-28 08:00:26 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-28 08:00:26 --> Controller Class Initialized
INFO - 2024-10-28 08:00:35 --> Config Class Initialized
INFO - 2024-10-28 08:00:35 --> Hooks Class Initialized
DEBUG - 2024-10-28 08:00:35 --> UTF-8 Support Enabled
INFO - 2024-10-28 08:00:35 --> Utf8 Class Initialized
INFO - 2024-10-28 08:00:35 --> URI Class Initialized
INFO - 2024-10-28 08:00:35 --> Router Class Initialized
INFO - 2024-10-28 08:00:35 --> Output Class Initialized
INFO - 2024-10-28 08:00:35 --> Security Class Initialized
DEBUG - 2024-10-28 08:00:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-28 08:00:35 --> Input Class Initialized
INFO - 2024-10-28 08:00:35 --> Language Class Initialized
INFO - 2024-10-28 08:00:35 --> Language Class Initialized
INFO - 2024-10-28 08:00:35 --> Config Class Initialized
INFO - 2024-10-28 08:00:35 --> Loader Class Initialized
INFO - 2024-10-28 08:00:35 --> Helper loaded: url_helper
INFO - 2024-10-28 08:00:35 --> Helper loaded: file_helper
INFO - 2024-10-28 08:00:35 --> Helper loaded: form_helper
INFO - 2024-10-28 08:00:35 --> Helper loaded: my_helper
INFO - 2024-10-28 08:00:35 --> Database Driver Class Initialized
INFO - 2024-10-28 08:00:35 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-28 08:00:35 --> Controller Class Initialized
INFO - 2024-10-28 08:00:35 --> Config Class Initialized
INFO - 2024-10-28 08:00:35 --> Hooks Class Initialized
DEBUG - 2024-10-28 08:00:35 --> UTF-8 Support Enabled
INFO - 2024-10-28 08:00:35 --> Utf8 Class Initialized
INFO - 2024-10-28 08:00:35 --> URI Class Initialized
INFO - 2024-10-28 08:00:35 --> Router Class Initialized
INFO - 2024-10-28 08:00:35 --> Output Class Initialized
INFO - 2024-10-28 08:00:35 --> Security Class Initialized
DEBUG - 2024-10-28 08:00:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-28 08:00:35 --> Input Class Initialized
INFO - 2024-10-28 08:00:35 --> Language Class Initialized
INFO - 2024-10-28 08:00:35 --> Language Class Initialized
INFO - 2024-10-28 08:00:35 --> Config Class Initialized
INFO - 2024-10-28 08:00:35 --> Loader Class Initialized
INFO - 2024-10-28 08:00:35 --> Helper loaded: url_helper
INFO - 2024-10-28 08:00:35 --> Helper loaded: file_helper
INFO - 2024-10-28 08:00:35 --> Helper loaded: form_helper
INFO - 2024-10-28 08:00:35 --> Helper loaded: my_helper
INFO - 2024-10-28 08:00:35 --> Database Driver Class Initialized
INFO - 2024-10-28 08:00:35 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-28 08:00:35 --> Controller Class Initialized
INFO - 2024-10-28 08:00:35 --> Config Class Initialized
INFO - 2024-10-28 08:00:35 --> Hooks Class Initialized
DEBUG - 2024-10-28 08:00:35 --> UTF-8 Support Enabled
INFO - 2024-10-28 08:00:35 --> Utf8 Class Initialized
INFO - 2024-10-28 08:00:35 --> URI Class Initialized
INFO - 2024-10-28 08:00:35 --> Router Class Initialized
INFO - 2024-10-28 08:00:35 --> Output Class Initialized
INFO - 2024-10-28 08:00:35 --> Security Class Initialized
DEBUG - 2024-10-28 08:00:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-28 08:00:35 --> Input Class Initialized
INFO - 2024-10-28 08:00:35 --> Language Class Initialized
INFO - 2024-10-28 08:00:35 --> Language Class Initialized
INFO - 2024-10-28 08:00:35 --> Config Class Initialized
INFO - 2024-10-28 08:00:35 --> Loader Class Initialized
INFO - 2024-10-28 08:00:35 --> Helper loaded: url_helper
INFO - 2024-10-28 08:00:35 --> Helper loaded: file_helper
INFO - 2024-10-28 08:00:35 --> Helper loaded: form_helper
INFO - 2024-10-28 08:00:35 --> Helper loaded: my_helper
INFO - 2024-10-28 08:00:35 --> Database Driver Class Initialized
INFO - 2024-10-28 08:00:35 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-28 08:00:35 --> Controller Class Initialized
INFO - 2024-10-28 08:00:36 --> Config Class Initialized
INFO - 2024-10-28 08:00:36 --> Hooks Class Initialized
DEBUG - 2024-10-28 08:00:36 --> UTF-8 Support Enabled
INFO - 2024-10-28 08:00:36 --> Utf8 Class Initialized
INFO - 2024-10-28 08:00:36 --> URI Class Initialized
INFO - 2024-10-28 08:00:36 --> Router Class Initialized
INFO - 2024-10-28 08:00:36 --> Output Class Initialized
INFO - 2024-10-28 08:00:36 --> Security Class Initialized
DEBUG - 2024-10-28 08:00:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-28 08:00:36 --> Input Class Initialized
INFO - 2024-10-28 08:00:36 --> Language Class Initialized
INFO - 2024-10-28 08:00:36 --> Language Class Initialized
INFO - 2024-10-28 08:00:36 --> Config Class Initialized
INFO - 2024-10-28 08:00:36 --> Loader Class Initialized
INFO - 2024-10-28 08:00:36 --> Helper loaded: url_helper
INFO - 2024-10-28 08:00:36 --> Helper loaded: file_helper
INFO - 2024-10-28 08:00:36 --> Helper loaded: form_helper
INFO - 2024-10-28 08:00:36 --> Helper loaded: my_helper
INFO - 2024-10-28 08:00:36 --> Database Driver Class Initialized
INFO - 2024-10-28 08:00:36 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-28 08:00:36 --> Controller Class Initialized
INFO - 2024-10-28 08:00:37 --> Config Class Initialized
INFO - 2024-10-28 08:00:37 --> Hooks Class Initialized
DEBUG - 2024-10-28 08:00:37 --> UTF-8 Support Enabled
INFO - 2024-10-28 08:00:37 --> Utf8 Class Initialized
INFO - 2024-10-28 08:00:37 --> URI Class Initialized
INFO - 2024-10-28 08:00:37 --> Router Class Initialized
INFO - 2024-10-28 08:00:37 --> Output Class Initialized
INFO - 2024-10-28 08:00:37 --> Security Class Initialized
DEBUG - 2024-10-28 08:00:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-28 08:00:37 --> Input Class Initialized
INFO - 2024-10-28 08:00:37 --> Language Class Initialized
INFO - 2024-10-28 08:00:38 --> Language Class Initialized
INFO - 2024-10-28 08:00:38 --> Config Class Initialized
INFO - 2024-10-28 08:00:38 --> Loader Class Initialized
INFO - 2024-10-28 08:00:38 --> Helper loaded: url_helper
INFO - 2024-10-28 08:00:38 --> Helper loaded: file_helper
INFO - 2024-10-28 08:00:38 --> Helper loaded: form_helper
INFO - 2024-10-28 08:00:38 --> Helper loaded: my_helper
INFO - 2024-10-28 08:00:38 --> Database Driver Class Initialized
INFO - 2024-10-28 08:00:38 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-28 08:00:38 --> Controller Class Initialized
ERROR - 2024-10-28 08:00:38 --> Severity: Notice --> Undefined variable: status_form /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/data_siswa/views/form.php 231
DEBUG - 2024-10-28 08:00:38 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/data_siswa/views/form.php
DEBUG - 2024-10-28 08:00:38 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-10-28 08:00:38 --> Final output sent to browser
DEBUG - 2024-10-28 08:00:38 --> Total execution time: 0.0269
INFO - 2024-10-28 08:00:54 --> Config Class Initialized
INFO - 2024-10-28 08:00:54 --> Hooks Class Initialized
DEBUG - 2024-10-28 08:00:54 --> UTF-8 Support Enabled
INFO - 2024-10-28 08:00:54 --> Utf8 Class Initialized
INFO - 2024-10-28 08:00:54 --> URI Class Initialized
INFO - 2024-10-28 08:00:54 --> Router Class Initialized
INFO - 2024-10-28 08:00:54 --> Output Class Initialized
INFO - 2024-10-28 08:00:54 --> Security Class Initialized
DEBUG - 2024-10-28 08:00:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-28 08:00:54 --> Input Class Initialized
INFO - 2024-10-28 08:00:54 --> Language Class Initialized
INFO - 2024-10-28 08:00:54 --> Language Class Initialized
INFO - 2024-10-28 08:00:54 --> Config Class Initialized
INFO - 2024-10-28 08:00:54 --> Loader Class Initialized
INFO - 2024-10-28 08:00:54 --> Helper loaded: url_helper
INFO - 2024-10-28 08:00:54 --> Helper loaded: file_helper
INFO - 2024-10-28 08:00:54 --> Helper loaded: form_helper
INFO - 2024-10-28 08:00:54 --> Helper loaded: my_helper
INFO - 2024-10-28 08:00:54 --> Database Driver Class Initialized
INFO - 2024-10-28 08:00:54 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-28 08:00:54 --> Controller Class Initialized
INFO - 2024-10-28 08:00:54 --> Upload Class Initialized
INFO - 2024-10-28 08:00:54 --> Language file loaded: language/english/upload_lang.php
ERROR - 2024-10-28 08:00:54 --> The upload path does not appear to be valid.
INFO - 2024-10-28 08:00:54 --> Config Class Initialized
INFO - 2024-10-28 08:00:54 --> Hooks Class Initialized
DEBUG - 2024-10-28 08:00:54 --> UTF-8 Support Enabled
INFO - 2024-10-28 08:00:54 --> Utf8 Class Initialized
INFO - 2024-10-28 08:00:54 --> URI Class Initialized
INFO - 2024-10-28 08:00:54 --> Router Class Initialized
INFO - 2024-10-28 08:00:54 --> Output Class Initialized
INFO - 2024-10-28 08:00:54 --> Security Class Initialized
DEBUG - 2024-10-28 08:00:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-28 08:00:54 --> Input Class Initialized
INFO - 2024-10-28 08:00:54 --> Language Class Initialized
INFO - 2024-10-28 08:00:54 --> Language Class Initialized
INFO - 2024-10-28 08:00:54 --> Config Class Initialized
INFO - 2024-10-28 08:00:54 --> Loader Class Initialized
INFO - 2024-10-28 08:00:54 --> Helper loaded: url_helper
INFO - 2024-10-28 08:00:54 --> Helper loaded: file_helper
INFO - 2024-10-28 08:00:54 --> Helper loaded: form_helper
INFO - 2024-10-28 08:00:54 --> Helper loaded: my_helper
INFO - 2024-10-28 08:00:54 --> Database Driver Class Initialized
INFO - 2024-10-28 08:00:54 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-28 08:00:54 --> Controller Class Initialized
DEBUG - 2024-10-28 08:00:54 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/data_siswa/views/list.php
DEBUG - 2024-10-28 08:00:54 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-10-28 08:00:54 --> Final output sent to browser
DEBUG - 2024-10-28 08:00:54 --> Total execution time: 0.0293
INFO - 2024-10-28 08:00:54 --> Config Class Initialized
INFO - 2024-10-28 08:00:54 --> Hooks Class Initialized
DEBUG - 2024-10-28 08:00:54 --> UTF-8 Support Enabled
INFO - 2024-10-28 08:00:54 --> Utf8 Class Initialized
INFO - 2024-10-28 08:00:54 --> URI Class Initialized
INFO - 2024-10-28 08:00:54 --> Router Class Initialized
INFO - 2024-10-28 08:00:54 --> Output Class Initialized
INFO - 2024-10-28 08:00:54 --> Security Class Initialized
DEBUG - 2024-10-28 08:00:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-28 08:00:54 --> Input Class Initialized
INFO - 2024-10-28 08:00:54 --> Language Class Initialized
ERROR - 2024-10-28 08:00:54 --> 404 Page Not Found: /index
INFO - 2024-10-28 08:00:54 --> Config Class Initialized
INFO - 2024-10-28 08:00:54 --> Hooks Class Initialized
DEBUG - 2024-10-28 08:00:54 --> UTF-8 Support Enabled
INFO - 2024-10-28 08:00:54 --> Utf8 Class Initialized
INFO - 2024-10-28 08:00:54 --> URI Class Initialized
INFO - 2024-10-28 08:00:54 --> Router Class Initialized
INFO - 2024-10-28 08:00:54 --> Output Class Initialized
INFO - 2024-10-28 08:00:54 --> Security Class Initialized
DEBUG - 2024-10-28 08:00:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-28 08:00:54 --> Input Class Initialized
INFO - 2024-10-28 08:00:54 --> Language Class Initialized
INFO - 2024-10-28 08:00:54 --> Language Class Initialized
INFO - 2024-10-28 08:00:54 --> Config Class Initialized
INFO - 2024-10-28 08:00:54 --> Loader Class Initialized
INFO - 2024-10-28 08:00:54 --> Helper loaded: url_helper
INFO - 2024-10-28 08:00:54 --> Helper loaded: file_helper
INFO - 2024-10-28 08:00:54 --> Helper loaded: form_helper
INFO - 2024-10-28 08:00:54 --> Helper loaded: my_helper
INFO - 2024-10-28 08:00:54 --> Database Driver Class Initialized
INFO - 2024-10-28 08:00:54 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-28 08:00:54 --> Controller Class Initialized
INFO - 2024-10-28 08:01:04 --> Config Class Initialized
INFO - 2024-10-28 08:01:04 --> Hooks Class Initialized
DEBUG - 2024-10-28 08:01:04 --> UTF-8 Support Enabled
INFO - 2024-10-28 08:01:04 --> Utf8 Class Initialized
INFO - 2024-10-28 08:01:04 --> URI Class Initialized
INFO - 2024-10-28 08:01:04 --> Router Class Initialized
INFO - 2024-10-28 08:01:04 --> Output Class Initialized
INFO - 2024-10-28 08:01:04 --> Security Class Initialized
DEBUG - 2024-10-28 08:01:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-28 08:01:04 --> Input Class Initialized
INFO - 2024-10-28 08:01:04 --> Language Class Initialized
INFO - 2024-10-28 08:01:04 --> Language Class Initialized
INFO - 2024-10-28 08:01:04 --> Config Class Initialized
INFO - 2024-10-28 08:01:04 --> Loader Class Initialized
INFO - 2024-10-28 08:01:04 --> Helper loaded: url_helper
INFO - 2024-10-28 08:01:04 --> Helper loaded: file_helper
INFO - 2024-10-28 08:01:04 --> Helper loaded: form_helper
INFO - 2024-10-28 08:01:04 --> Helper loaded: my_helper
INFO - 2024-10-28 08:01:04 --> Database Driver Class Initialized
INFO - 2024-10-28 08:01:04 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-28 08:01:04 --> Controller Class Initialized
INFO - 2024-10-28 08:01:04 --> Config Class Initialized
INFO - 2024-10-28 08:01:04 --> Hooks Class Initialized
DEBUG - 2024-10-28 08:01:04 --> UTF-8 Support Enabled
INFO - 2024-10-28 08:01:04 --> Utf8 Class Initialized
INFO - 2024-10-28 08:01:04 --> URI Class Initialized
INFO - 2024-10-28 08:01:04 --> Router Class Initialized
INFO - 2024-10-28 08:01:04 --> Output Class Initialized
INFO - 2024-10-28 08:01:04 --> Security Class Initialized
DEBUG - 2024-10-28 08:01:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-28 08:01:04 --> Input Class Initialized
INFO - 2024-10-28 08:01:04 --> Language Class Initialized
INFO - 2024-10-28 08:01:04 --> Language Class Initialized
INFO - 2024-10-28 08:01:04 --> Config Class Initialized
INFO - 2024-10-28 08:01:04 --> Loader Class Initialized
INFO - 2024-10-28 08:01:04 --> Helper loaded: url_helper
INFO - 2024-10-28 08:01:04 --> Helper loaded: file_helper
INFO - 2024-10-28 08:01:04 --> Helper loaded: form_helper
INFO - 2024-10-28 08:01:04 --> Helper loaded: my_helper
INFO - 2024-10-28 08:01:04 --> Database Driver Class Initialized
INFO - 2024-10-28 08:01:04 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-28 08:01:04 --> Controller Class Initialized
INFO - 2024-10-28 08:01:06 --> Config Class Initialized
INFO - 2024-10-28 08:01:06 --> Hooks Class Initialized
DEBUG - 2024-10-28 08:01:06 --> UTF-8 Support Enabled
INFO - 2024-10-28 08:01:06 --> Utf8 Class Initialized
INFO - 2024-10-28 08:01:06 --> URI Class Initialized
INFO - 2024-10-28 08:01:06 --> Router Class Initialized
INFO - 2024-10-28 08:01:06 --> Output Class Initialized
INFO - 2024-10-28 08:01:06 --> Security Class Initialized
DEBUG - 2024-10-28 08:01:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-28 08:01:06 --> Input Class Initialized
INFO - 2024-10-28 08:01:06 --> Language Class Initialized
INFO - 2024-10-28 08:01:06 --> Language Class Initialized
INFO - 2024-10-28 08:01:06 --> Config Class Initialized
INFO - 2024-10-28 08:01:06 --> Loader Class Initialized
INFO - 2024-10-28 08:01:06 --> Helper loaded: url_helper
INFO - 2024-10-28 08:01:06 --> Helper loaded: file_helper
INFO - 2024-10-28 08:01:06 --> Helper loaded: form_helper
INFO - 2024-10-28 08:01:06 --> Helper loaded: my_helper
INFO - 2024-10-28 08:01:06 --> Database Driver Class Initialized
INFO - 2024-10-28 08:01:06 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-28 08:01:06 --> Controller Class Initialized
ERROR - 2024-10-28 08:01:06 --> Severity: Notice --> Undefined variable: status_form /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/data_siswa/views/form.php 231
DEBUG - 2024-10-28 08:01:06 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/data_siswa/views/form.php
DEBUG - 2024-10-28 08:01:06 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-10-28 08:01:06 --> Final output sent to browser
DEBUG - 2024-10-28 08:01:06 --> Total execution time: 0.0390
INFO - 2024-10-28 08:01:21 --> Config Class Initialized
INFO - 2024-10-28 08:01:21 --> Hooks Class Initialized
DEBUG - 2024-10-28 08:01:21 --> UTF-8 Support Enabled
INFO - 2024-10-28 08:01:21 --> Utf8 Class Initialized
INFO - 2024-10-28 08:01:21 --> URI Class Initialized
INFO - 2024-10-28 08:01:21 --> Router Class Initialized
INFO - 2024-10-28 08:01:21 --> Output Class Initialized
INFO - 2024-10-28 08:01:21 --> Security Class Initialized
DEBUG - 2024-10-28 08:01:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-28 08:01:21 --> Input Class Initialized
INFO - 2024-10-28 08:01:21 --> Language Class Initialized
INFO - 2024-10-28 08:01:21 --> Language Class Initialized
INFO - 2024-10-28 08:01:21 --> Config Class Initialized
INFO - 2024-10-28 08:01:21 --> Loader Class Initialized
INFO - 2024-10-28 08:01:21 --> Helper loaded: url_helper
INFO - 2024-10-28 08:01:21 --> Helper loaded: file_helper
INFO - 2024-10-28 08:01:21 --> Helper loaded: form_helper
INFO - 2024-10-28 08:01:21 --> Helper loaded: my_helper
INFO - 2024-10-28 08:01:21 --> Database Driver Class Initialized
INFO - 2024-10-28 08:01:21 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-28 08:01:21 --> Controller Class Initialized
INFO - 2024-10-28 08:01:21 --> Upload Class Initialized
INFO - 2024-10-28 08:01:21 --> Language file loaded: language/english/upload_lang.php
ERROR - 2024-10-28 08:01:21 --> The upload path does not appear to be valid.
INFO - 2024-10-28 08:01:21 --> Config Class Initialized
INFO - 2024-10-28 08:01:21 --> Hooks Class Initialized
DEBUG - 2024-10-28 08:01:21 --> UTF-8 Support Enabled
INFO - 2024-10-28 08:01:21 --> Utf8 Class Initialized
INFO - 2024-10-28 08:01:21 --> URI Class Initialized
INFO - 2024-10-28 08:01:21 --> Router Class Initialized
INFO - 2024-10-28 08:01:21 --> Output Class Initialized
INFO - 2024-10-28 08:01:21 --> Security Class Initialized
DEBUG - 2024-10-28 08:01:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-28 08:01:21 --> Input Class Initialized
INFO - 2024-10-28 08:01:21 --> Language Class Initialized
INFO - 2024-10-28 08:01:21 --> Language Class Initialized
INFO - 2024-10-28 08:01:21 --> Config Class Initialized
INFO - 2024-10-28 08:01:21 --> Loader Class Initialized
INFO - 2024-10-28 08:01:21 --> Helper loaded: url_helper
INFO - 2024-10-28 08:01:21 --> Helper loaded: file_helper
INFO - 2024-10-28 08:01:21 --> Helper loaded: form_helper
INFO - 2024-10-28 08:01:21 --> Helper loaded: my_helper
INFO - 2024-10-28 08:01:21 --> Database Driver Class Initialized
INFO - 2024-10-28 08:01:21 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-28 08:01:21 --> Controller Class Initialized
DEBUG - 2024-10-28 08:01:21 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/data_siswa/views/list.php
DEBUG - 2024-10-28 08:01:21 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-10-28 08:01:21 --> Final output sent to browser
DEBUG - 2024-10-28 08:01:21 --> Total execution time: 0.0270
INFO - 2024-10-28 08:01:21 --> Config Class Initialized
INFO - 2024-10-28 08:01:21 --> Hooks Class Initialized
DEBUG - 2024-10-28 08:01:21 --> UTF-8 Support Enabled
INFO - 2024-10-28 08:01:21 --> Utf8 Class Initialized
INFO - 2024-10-28 08:01:21 --> URI Class Initialized
INFO - 2024-10-28 08:01:21 --> Router Class Initialized
INFO - 2024-10-28 08:01:21 --> Output Class Initialized
INFO - 2024-10-28 08:01:21 --> Security Class Initialized
DEBUG - 2024-10-28 08:01:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-28 08:01:21 --> Input Class Initialized
INFO - 2024-10-28 08:01:21 --> Language Class Initialized
ERROR - 2024-10-28 08:01:21 --> 404 Page Not Found: /index
INFO - 2024-10-28 08:01:21 --> Config Class Initialized
INFO - 2024-10-28 08:01:21 --> Hooks Class Initialized
DEBUG - 2024-10-28 08:01:21 --> UTF-8 Support Enabled
INFO - 2024-10-28 08:01:21 --> Utf8 Class Initialized
INFO - 2024-10-28 08:01:21 --> URI Class Initialized
INFO - 2024-10-28 08:01:21 --> Router Class Initialized
INFO - 2024-10-28 08:01:21 --> Output Class Initialized
INFO - 2024-10-28 08:01:21 --> Security Class Initialized
DEBUG - 2024-10-28 08:01:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-28 08:01:21 --> Input Class Initialized
INFO - 2024-10-28 08:01:21 --> Language Class Initialized
INFO - 2024-10-28 08:01:21 --> Language Class Initialized
INFO - 2024-10-28 08:01:21 --> Config Class Initialized
INFO - 2024-10-28 08:01:21 --> Loader Class Initialized
INFO - 2024-10-28 08:01:21 --> Helper loaded: url_helper
INFO - 2024-10-28 08:01:21 --> Helper loaded: file_helper
INFO - 2024-10-28 08:01:21 --> Helper loaded: form_helper
INFO - 2024-10-28 08:01:21 --> Helper loaded: my_helper
INFO - 2024-10-28 08:01:21 --> Database Driver Class Initialized
INFO - 2024-10-28 08:01:21 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-28 08:01:21 --> Controller Class Initialized
INFO - 2024-10-28 08:01:27 --> Config Class Initialized
INFO - 2024-10-28 08:01:27 --> Hooks Class Initialized
DEBUG - 2024-10-28 08:01:27 --> UTF-8 Support Enabled
INFO - 2024-10-28 08:01:27 --> Utf8 Class Initialized
INFO - 2024-10-28 08:01:27 --> URI Class Initialized
INFO - 2024-10-28 08:01:27 --> Router Class Initialized
INFO - 2024-10-28 08:01:27 --> Output Class Initialized
INFO - 2024-10-28 08:01:27 --> Security Class Initialized
DEBUG - 2024-10-28 08:01:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-28 08:01:27 --> Input Class Initialized
INFO - 2024-10-28 08:01:27 --> Language Class Initialized
INFO - 2024-10-28 08:01:27 --> Language Class Initialized
INFO - 2024-10-28 08:01:27 --> Config Class Initialized
INFO - 2024-10-28 08:01:27 --> Loader Class Initialized
INFO - 2024-10-28 08:01:27 --> Helper loaded: url_helper
INFO - 2024-10-28 08:01:27 --> Helper loaded: file_helper
INFO - 2024-10-28 08:01:27 --> Helper loaded: form_helper
INFO - 2024-10-28 08:01:27 --> Helper loaded: my_helper
INFO - 2024-10-28 08:01:27 --> Database Driver Class Initialized
INFO - 2024-10-28 08:01:27 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-28 08:01:27 --> Controller Class Initialized
INFO - 2024-10-28 08:01:28 --> Config Class Initialized
INFO - 2024-10-28 08:01:28 --> Hooks Class Initialized
DEBUG - 2024-10-28 08:01:28 --> UTF-8 Support Enabled
INFO - 2024-10-28 08:01:28 --> Utf8 Class Initialized
INFO - 2024-10-28 08:01:28 --> URI Class Initialized
INFO - 2024-10-28 08:01:28 --> Router Class Initialized
INFO - 2024-10-28 08:01:28 --> Output Class Initialized
INFO - 2024-10-28 08:01:28 --> Security Class Initialized
DEBUG - 2024-10-28 08:01:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-28 08:01:28 --> Input Class Initialized
INFO - 2024-10-28 08:01:28 --> Language Class Initialized
INFO - 2024-10-28 08:01:28 --> Language Class Initialized
INFO - 2024-10-28 08:01:28 --> Config Class Initialized
INFO - 2024-10-28 08:01:28 --> Loader Class Initialized
INFO - 2024-10-28 08:01:28 --> Helper loaded: url_helper
INFO - 2024-10-28 08:01:28 --> Helper loaded: file_helper
INFO - 2024-10-28 08:01:28 --> Helper loaded: form_helper
INFO - 2024-10-28 08:01:28 --> Helper loaded: my_helper
INFO - 2024-10-28 08:01:28 --> Database Driver Class Initialized
INFO - 2024-10-28 08:01:28 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-28 08:01:28 --> Controller Class Initialized
INFO - 2024-10-28 08:01:28 --> Config Class Initialized
INFO - 2024-10-28 08:01:28 --> Hooks Class Initialized
DEBUG - 2024-10-28 08:01:28 --> UTF-8 Support Enabled
INFO - 2024-10-28 08:01:28 --> Utf8 Class Initialized
INFO - 2024-10-28 08:01:28 --> URI Class Initialized
INFO - 2024-10-28 08:01:28 --> Router Class Initialized
INFO - 2024-10-28 08:01:28 --> Output Class Initialized
INFO - 2024-10-28 08:01:28 --> Security Class Initialized
DEBUG - 2024-10-28 08:01:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-28 08:01:28 --> Input Class Initialized
INFO - 2024-10-28 08:01:28 --> Language Class Initialized
INFO - 2024-10-28 08:01:28 --> Language Class Initialized
INFO - 2024-10-28 08:01:28 --> Config Class Initialized
INFO - 2024-10-28 08:01:28 --> Loader Class Initialized
INFO - 2024-10-28 08:01:28 --> Helper loaded: url_helper
INFO - 2024-10-28 08:01:28 --> Helper loaded: file_helper
INFO - 2024-10-28 08:01:28 --> Helper loaded: form_helper
INFO - 2024-10-28 08:01:28 --> Helper loaded: my_helper
INFO - 2024-10-28 08:01:28 --> Database Driver Class Initialized
INFO - 2024-10-28 08:01:28 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-28 08:01:28 --> Controller Class Initialized
INFO - 2024-10-28 08:01:29 --> Config Class Initialized
INFO - 2024-10-28 08:01:29 --> Hooks Class Initialized
DEBUG - 2024-10-28 08:01:29 --> UTF-8 Support Enabled
INFO - 2024-10-28 08:01:29 --> Utf8 Class Initialized
INFO - 2024-10-28 08:01:29 --> URI Class Initialized
INFO - 2024-10-28 08:01:29 --> Router Class Initialized
INFO - 2024-10-28 08:01:29 --> Output Class Initialized
INFO - 2024-10-28 08:01:29 --> Security Class Initialized
DEBUG - 2024-10-28 08:01:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-28 08:01:29 --> Input Class Initialized
INFO - 2024-10-28 08:01:29 --> Language Class Initialized
INFO - 2024-10-28 08:01:29 --> Language Class Initialized
INFO - 2024-10-28 08:01:29 --> Config Class Initialized
INFO - 2024-10-28 08:01:29 --> Loader Class Initialized
INFO - 2024-10-28 08:01:29 --> Helper loaded: url_helper
INFO - 2024-10-28 08:01:29 --> Helper loaded: file_helper
INFO - 2024-10-28 08:01:29 --> Helper loaded: form_helper
INFO - 2024-10-28 08:01:29 --> Helper loaded: my_helper
INFO - 2024-10-28 08:01:29 --> Database Driver Class Initialized
INFO - 2024-10-28 08:01:29 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-28 08:01:29 --> Controller Class Initialized
INFO - 2024-10-28 08:01:30 --> Config Class Initialized
INFO - 2024-10-28 08:01:30 --> Hooks Class Initialized
DEBUG - 2024-10-28 08:01:30 --> UTF-8 Support Enabled
INFO - 2024-10-28 08:01:30 --> Utf8 Class Initialized
INFO - 2024-10-28 08:01:30 --> URI Class Initialized
INFO - 2024-10-28 08:01:30 --> Router Class Initialized
INFO - 2024-10-28 08:01:30 --> Output Class Initialized
INFO - 2024-10-28 08:01:30 --> Security Class Initialized
DEBUG - 2024-10-28 08:01:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-28 08:01:30 --> Input Class Initialized
INFO - 2024-10-28 08:01:30 --> Language Class Initialized
INFO - 2024-10-28 08:01:30 --> Language Class Initialized
INFO - 2024-10-28 08:01:30 --> Config Class Initialized
INFO - 2024-10-28 08:01:30 --> Loader Class Initialized
INFO - 2024-10-28 08:01:30 --> Helper loaded: url_helper
INFO - 2024-10-28 08:01:30 --> Helper loaded: file_helper
INFO - 2024-10-28 08:01:30 --> Helper loaded: form_helper
INFO - 2024-10-28 08:01:30 --> Helper loaded: my_helper
INFO - 2024-10-28 08:01:30 --> Database Driver Class Initialized
INFO - 2024-10-28 08:01:30 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-28 08:01:30 --> Controller Class Initialized
INFO - 2024-10-28 08:01:32 --> Config Class Initialized
INFO - 2024-10-28 08:01:32 --> Hooks Class Initialized
DEBUG - 2024-10-28 08:01:32 --> UTF-8 Support Enabled
INFO - 2024-10-28 08:01:32 --> Utf8 Class Initialized
INFO - 2024-10-28 08:01:32 --> URI Class Initialized
INFO - 2024-10-28 08:01:32 --> Router Class Initialized
INFO - 2024-10-28 08:01:32 --> Output Class Initialized
INFO - 2024-10-28 08:01:32 --> Security Class Initialized
DEBUG - 2024-10-28 08:01:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-28 08:01:32 --> Input Class Initialized
INFO - 2024-10-28 08:01:32 --> Language Class Initialized
INFO - 2024-10-28 08:01:32 --> Language Class Initialized
INFO - 2024-10-28 08:01:32 --> Config Class Initialized
INFO - 2024-10-28 08:01:32 --> Loader Class Initialized
INFO - 2024-10-28 08:01:32 --> Helper loaded: url_helper
INFO - 2024-10-28 08:01:32 --> Helper loaded: file_helper
INFO - 2024-10-28 08:01:32 --> Helper loaded: form_helper
INFO - 2024-10-28 08:01:32 --> Helper loaded: my_helper
INFO - 2024-10-28 08:01:32 --> Database Driver Class Initialized
INFO - 2024-10-28 08:01:32 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-28 08:01:32 --> Controller Class Initialized
ERROR - 2024-10-28 08:01:32 --> Severity: Notice --> Undefined variable: status_form /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/data_siswa/views/form.php 231
DEBUG - 2024-10-28 08:01:32 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/data_siswa/views/form.php
DEBUG - 2024-10-28 08:01:32 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-10-28 08:01:32 --> Final output sent to browser
DEBUG - 2024-10-28 08:01:32 --> Total execution time: 0.0313
INFO - 2024-10-28 08:01:54 --> Config Class Initialized
INFO - 2024-10-28 08:01:54 --> Hooks Class Initialized
DEBUG - 2024-10-28 08:01:54 --> UTF-8 Support Enabled
INFO - 2024-10-28 08:01:54 --> Utf8 Class Initialized
INFO - 2024-10-28 08:01:54 --> URI Class Initialized
INFO - 2024-10-28 08:01:54 --> Router Class Initialized
INFO - 2024-10-28 08:01:54 --> Output Class Initialized
INFO - 2024-10-28 08:01:54 --> Security Class Initialized
DEBUG - 2024-10-28 08:01:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-28 08:01:54 --> Input Class Initialized
INFO - 2024-10-28 08:01:54 --> Language Class Initialized
INFO - 2024-10-28 08:01:54 --> Language Class Initialized
INFO - 2024-10-28 08:01:54 --> Config Class Initialized
INFO - 2024-10-28 08:01:54 --> Loader Class Initialized
INFO - 2024-10-28 08:01:54 --> Helper loaded: url_helper
INFO - 2024-10-28 08:01:54 --> Helper loaded: file_helper
INFO - 2024-10-28 08:01:54 --> Helper loaded: form_helper
INFO - 2024-10-28 08:01:54 --> Helper loaded: my_helper
INFO - 2024-10-28 08:01:54 --> Database Driver Class Initialized
INFO - 2024-10-28 08:01:54 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-28 08:01:54 --> Controller Class Initialized
INFO - 2024-10-28 08:01:54 --> Upload Class Initialized
INFO - 2024-10-28 08:01:54 --> Language file loaded: language/english/upload_lang.php
ERROR - 2024-10-28 08:01:54 --> The upload path does not appear to be valid.
INFO - 2024-10-28 08:01:54 --> Config Class Initialized
INFO - 2024-10-28 08:01:54 --> Hooks Class Initialized
DEBUG - 2024-10-28 08:01:54 --> UTF-8 Support Enabled
INFO - 2024-10-28 08:01:54 --> Utf8 Class Initialized
INFO - 2024-10-28 08:01:54 --> URI Class Initialized
INFO - 2024-10-28 08:01:54 --> Router Class Initialized
INFO - 2024-10-28 08:01:54 --> Output Class Initialized
INFO - 2024-10-28 08:01:54 --> Security Class Initialized
DEBUG - 2024-10-28 08:01:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-28 08:01:54 --> Input Class Initialized
INFO - 2024-10-28 08:01:54 --> Language Class Initialized
INFO - 2024-10-28 08:01:54 --> Language Class Initialized
INFO - 2024-10-28 08:01:54 --> Config Class Initialized
INFO - 2024-10-28 08:01:54 --> Loader Class Initialized
INFO - 2024-10-28 08:01:54 --> Helper loaded: url_helper
INFO - 2024-10-28 08:01:54 --> Helper loaded: file_helper
INFO - 2024-10-28 08:01:54 --> Helper loaded: form_helper
INFO - 2024-10-28 08:01:54 --> Helper loaded: my_helper
INFO - 2024-10-28 08:01:54 --> Database Driver Class Initialized
INFO - 2024-10-28 08:01:54 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-28 08:01:54 --> Controller Class Initialized
DEBUG - 2024-10-28 08:01:54 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/data_siswa/views/list.php
DEBUG - 2024-10-28 08:01:54 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-10-28 08:01:54 --> Final output sent to browser
DEBUG - 2024-10-28 08:01:54 --> Total execution time: 0.0251
INFO - 2024-10-28 08:01:54 --> Config Class Initialized
INFO - 2024-10-28 08:01:54 --> Hooks Class Initialized
DEBUG - 2024-10-28 08:01:54 --> UTF-8 Support Enabled
INFO - 2024-10-28 08:01:54 --> Utf8 Class Initialized
INFO - 2024-10-28 08:01:54 --> URI Class Initialized
INFO - 2024-10-28 08:01:54 --> Router Class Initialized
INFO - 2024-10-28 08:01:54 --> Output Class Initialized
INFO - 2024-10-28 08:01:54 --> Security Class Initialized
DEBUG - 2024-10-28 08:01:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-28 08:01:54 --> Input Class Initialized
INFO - 2024-10-28 08:01:54 --> Language Class Initialized
ERROR - 2024-10-28 08:01:54 --> 404 Page Not Found: /index
INFO - 2024-10-28 08:01:54 --> Config Class Initialized
INFO - 2024-10-28 08:01:54 --> Hooks Class Initialized
DEBUG - 2024-10-28 08:01:54 --> UTF-8 Support Enabled
INFO - 2024-10-28 08:01:54 --> Utf8 Class Initialized
INFO - 2024-10-28 08:01:54 --> URI Class Initialized
INFO - 2024-10-28 08:01:54 --> Router Class Initialized
INFO - 2024-10-28 08:01:54 --> Output Class Initialized
INFO - 2024-10-28 08:01:54 --> Security Class Initialized
DEBUG - 2024-10-28 08:01:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-28 08:01:54 --> Input Class Initialized
INFO - 2024-10-28 08:01:54 --> Language Class Initialized
INFO - 2024-10-28 08:01:54 --> Language Class Initialized
INFO - 2024-10-28 08:01:54 --> Config Class Initialized
INFO - 2024-10-28 08:01:54 --> Loader Class Initialized
INFO - 2024-10-28 08:01:54 --> Helper loaded: url_helper
INFO - 2024-10-28 08:01:54 --> Helper loaded: file_helper
INFO - 2024-10-28 08:01:54 --> Helper loaded: form_helper
INFO - 2024-10-28 08:01:54 --> Helper loaded: my_helper
INFO - 2024-10-28 08:01:54 --> Database Driver Class Initialized
INFO - 2024-10-28 08:01:54 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-28 08:01:54 --> Controller Class Initialized
INFO - 2024-10-28 08:02:09 --> Config Class Initialized
INFO - 2024-10-28 08:02:09 --> Hooks Class Initialized
DEBUG - 2024-10-28 08:02:09 --> UTF-8 Support Enabled
INFO - 2024-10-28 08:02:09 --> Utf8 Class Initialized
INFO - 2024-10-28 08:02:09 --> URI Class Initialized
INFO - 2024-10-28 08:02:09 --> Router Class Initialized
INFO - 2024-10-28 08:02:09 --> Output Class Initialized
INFO - 2024-10-28 08:02:09 --> Security Class Initialized
DEBUG - 2024-10-28 08:02:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-28 08:02:09 --> Input Class Initialized
INFO - 2024-10-28 08:02:09 --> Language Class Initialized
INFO - 2024-10-28 08:02:09 --> Language Class Initialized
INFO - 2024-10-28 08:02:09 --> Config Class Initialized
INFO - 2024-10-28 08:02:09 --> Loader Class Initialized
INFO - 2024-10-28 08:02:09 --> Helper loaded: url_helper
INFO - 2024-10-28 08:02:09 --> Helper loaded: file_helper
INFO - 2024-10-28 08:02:09 --> Helper loaded: form_helper
INFO - 2024-10-28 08:02:09 --> Helper loaded: my_helper
INFO - 2024-10-28 08:02:09 --> Database Driver Class Initialized
INFO - 2024-10-28 08:02:09 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-28 08:02:09 --> Controller Class Initialized
INFO - 2024-10-28 08:02:09 --> Config Class Initialized
INFO - 2024-10-28 08:02:09 --> Hooks Class Initialized
DEBUG - 2024-10-28 08:02:09 --> UTF-8 Support Enabled
INFO - 2024-10-28 08:02:09 --> Utf8 Class Initialized
INFO - 2024-10-28 08:02:09 --> URI Class Initialized
INFO - 2024-10-28 08:02:09 --> Router Class Initialized
INFO - 2024-10-28 08:02:09 --> Output Class Initialized
INFO - 2024-10-28 08:02:09 --> Security Class Initialized
DEBUG - 2024-10-28 08:02:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-28 08:02:09 --> Input Class Initialized
INFO - 2024-10-28 08:02:09 --> Language Class Initialized
INFO - 2024-10-28 08:02:09 --> Language Class Initialized
INFO - 2024-10-28 08:02:09 --> Config Class Initialized
INFO - 2024-10-28 08:02:09 --> Loader Class Initialized
INFO - 2024-10-28 08:02:09 --> Helper loaded: url_helper
INFO - 2024-10-28 08:02:09 --> Helper loaded: file_helper
INFO - 2024-10-28 08:02:09 --> Helper loaded: form_helper
INFO - 2024-10-28 08:02:09 --> Helper loaded: my_helper
INFO - 2024-10-28 08:02:09 --> Database Driver Class Initialized
INFO - 2024-10-28 08:02:09 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-28 08:02:09 --> Controller Class Initialized
INFO - 2024-10-28 08:02:10 --> Config Class Initialized
INFO - 2024-10-28 08:02:10 --> Hooks Class Initialized
DEBUG - 2024-10-28 08:02:10 --> UTF-8 Support Enabled
INFO - 2024-10-28 08:02:10 --> Utf8 Class Initialized
INFO - 2024-10-28 08:02:10 --> URI Class Initialized
INFO - 2024-10-28 08:02:10 --> Router Class Initialized
INFO - 2024-10-28 08:02:10 --> Output Class Initialized
INFO - 2024-10-28 08:02:10 --> Security Class Initialized
DEBUG - 2024-10-28 08:02:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-28 08:02:10 --> Input Class Initialized
INFO - 2024-10-28 08:02:10 --> Language Class Initialized
INFO - 2024-10-28 08:02:10 --> Language Class Initialized
INFO - 2024-10-28 08:02:10 --> Config Class Initialized
INFO - 2024-10-28 08:02:10 --> Loader Class Initialized
INFO - 2024-10-28 08:02:10 --> Helper loaded: url_helper
INFO - 2024-10-28 08:02:10 --> Helper loaded: file_helper
INFO - 2024-10-28 08:02:10 --> Helper loaded: form_helper
INFO - 2024-10-28 08:02:10 --> Helper loaded: my_helper
INFO - 2024-10-28 08:02:10 --> Database Driver Class Initialized
INFO - 2024-10-28 08:02:10 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-28 08:02:10 --> Controller Class Initialized
INFO - 2024-10-28 08:02:10 --> Config Class Initialized
INFO - 2024-10-28 08:02:10 --> Hooks Class Initialized
DEBUG - 2024-10-28 08:02:10 --> UTF-8 Support Enabled
INFO - 2024-10-28 08:02:10 --> Utf8 Class Initialized
INFO - 2024-10-28 08:02:10 --> URI Class Initialized
INFO - 2024-10-28 08:02:10 --> Router Class Initialized
INFO - 2024-10-28 08:02:10 --> Output Class Initialized
INFO - 2024-10-28 08:02:10 --> Security Class Initialized
DEBUG - 2024-10-28 08:02:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-28 08:02:10 --> Input Class Initialized
INFO - 2024-10-28 08:02:10 --> Language Class Initialized
INFO - 2024-10-28 08:02:10 --> Language Class Initialized
INFO - 2024-10-28 08:02:10 --> Config Class Initialized
INFO - 2024-10-28 08:02:10 --> Loader Class Initialized
INFO - 2024-10-28 08:02:10 --> Helper loaded: url_helper
INFO - 2024-10-28 08:02:10 --> Helper loaded: file_helper
INFO - 2024-10-28 08:02:10 --> Helper loaded: form_helper
INFO - 2024-10-28 08:02:10 --> Helper loaded: my_helper
INFO - 2024-10-28 08:02:11 --> Database Driver Class Initialized
INFO - 2024-10-28 08:02:11 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-28 08:02:11 --> Controller Class Initialized
INFO - 2024-10-28 08:02:14 --> Config Class Initialized
INFO - 2024-10-28 08:02:14 --> Hooks Class Initialized
DEBUG - 2024-10-28 08:02:14 --> UTF-8 Support Enabled
INFO - 2024-10-28 08:02:14 --> Utf8 Class Initialized
INFO - 2024-10-28 08:02:14 --> URI Class Initialized
INFO - 2024-10-28 08:02:14 --> Router Class Initialized
INFO - 2024-10-28 08:02:14 --> Output Class Initialized
INFO - 2024-10-28 08:02:14 --> Security Class Initialized
DEBUG - 2024-10-28 08:02:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-28 08:02:14 --> Input Class Initialized
INFO - 2024-10-28 08:02:14 --> Language Class Initialized
INFO - 2024-10-28 08:02:14 --> Language Class Initialized
INFO - 2024-10-28 08:02:14 --> Config Class Initialized
INFO - 2024-10-28 08:02:14 --> Loader Class Initialized
INFO - 2024-10-28 08:02:14 --> Helper loaded: url_helper
INFO - 2024-10-28 08:02:14 --> Helper loaded: file_helper
INFO - 2024-10-28 08:02:14 --> Helper loaded: form_helper
INFO - 2024-10-28 08:02:14 --> Helper loaded: my_helper
INFO - 2024-10-28 08:02:14 --> Database Driver Class Initialized
INFO - 2024-10-28 08:02:14 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-28 08:02:14 --> Controller Class Initialized
ERROR - 2024-10-28 08:02:14 --> Severity: Notice --> Undefined variable: status_form /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/data_siswa/views/form.php 231
DEBUG - 2024-10-28 08:02:14 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/data_siswa/views/form.php
DEBUG - 2024-10-28 08:02:14 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-10-28 08:02:14 --> Final output sent to browser
DEBUG - 2024-10-28 08:02:14 --> Total execution time: 0.0375
INFO - 2024-10-28 08:02:39 --> Config Class Initialized
INFO - 2024-10-28 08:02:39 --> Hooks Class Initialized
DEBUG - 2024-10-28 08:02:39 --> UTF-8 Support Enabled
INFO - 2024-10-28 08:02:39 --> Utf8 Class Initialized
INFO - 2024-10-28 08:02:39 --> URI Class Initialized
INFO - 2024-10-28 08:02:39 --> Router Class Initialized
INFO - 2024-10-28 08:02:39 --> Output Class Initialized
INFO - 2024-10-28 08:02:39 --> Security Class Initialized
DEBUG - 2024-10-28 08:02:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-28 08:02:39 --> Input Class Initialized
INFO - 2024-10-28 08:02:39 --> Language Class Initialized
INFO - 2024-10-28 08:02:39 --> Language Class Initialized
INFO - 2024-10-28 08:02:39 --> Config Class Initialized
INFO - 2024-10-28 08:02:39 --> Loader Class Initialized
INFO - 2024-10-28 08:02:39 --> Helper loaded: url_helper
INFO - 2024-10-28 08:02:39 --> Helper loaded: file_helper
INFO - 2024-10-28 08:02:39 --> Helper loaded: form_helper
INFO - 2024-10-28 08:02:39 --> Helper loaded: my_helper
INFO - 2024-10-28 08:02:39 --> Database Driver Class Initialized
INFO - 2024-10-28 08:02:39 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-28 08:02:39 --> Controller Class Initialized
INFO - 2024-10-28 08:02:39 --> Upload Class Initialized
INFO - 2024-10-28 08:02:39 --> Language file loaded: language/english/upload_lang.php
ERROR - 2024-10-28 08:02:39 --> The upload path does not appear to be valid.
INFO - 2024-10-28 08:02:39 --> Config Class Initialized
INFO - 2024-10-28 08:02:39 --> Hooks Class Initialized
DEBUG - 2024-10-28 08:02:39 --> UTF-8 Support Enabled
INFO - 2024-10-28 08:02:39 --> Utf8 Class Initialized
INFO - 2024-10-28 08:02:39 --> URI Class Initialized
INFO - 2024-10-28 08:02:39 --> Router Class Initialized
INFO - 2024-10-28 08:02:39 --> Output Class Initialized
INFO - 2024-10-28 08:02:39 --> Security Class Initialized
DEBUG - 2024-10-28 08:02:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-28 08:02:39 --> Input Class Initialized
INFO - 2024-10-28 08:02:39 --> Language Class Initialized
INFO - 2024-10-28 08:02:39 --> Language Class Initialized
INFO - 2024-10-28 08:02:39 --> Config Class Initialized
INFO - 2024-10-28 08:02:39 --> Loader Class Initialized
INFO - 2024-10-28 08:02:39 --> Helper loaded: url_helper
INFO - 2024-10-28 08:02:39 --> Helper loaded: file_helper
INFO - 2024-10-28 08:02:39 --> Helper loaded: form_helper
INFO - 2024-10-28 08:02:39 --> Helper loaded: my_helper
INFO - 2024-10-28 08:02:39 --> Database Driver Class Initialized
INFO - 2024-10-28 08:02:39 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-28 08:02:39 --> Controller Class Initialized
DEBUG - 2024-10-28 08:02:39 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/data_siswa/views/list.php
DEBUG - 2024-10-28 08:02:39 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-10-28 08:02:39 --> Final output sent to browser
DEBUG - 2024-10-28 08:02:39 --> Total execution time: 0.0264
INFO - 2024-10-28 08:02:39 --> Config Class Initialized
INFO - 2024-10-28 08:02:39 --> Hooks Class Initialized
DEBUG - 2024-10-28 08:02:39 --> UTF-8 Support Enabled
INFO - 2024-10-28 08:02:39 --> Utf8 Class Initialized
INFO - 2024-10-28 08:02:39 --> URI Class Initialized
INFO - 2024-10-28 08:02:39 --> Router Class Initialized
INFO - 2024-10-28 08:02:39 --> Output Class Initialized
INFO - 2024-10-28 08:02:39 --> Security Class Initialized
DEBUG - 2024-10-28 08:02:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-28 08:02:39 --> Input Class Initialized
INFO - 2024-10-28 08:02:39 --> Language Class Initialized
ERROR - 2024-10-28 08:02:39 --> 404 Page Not Found: /index
INFO - 2024-10-28 08:02:39 --> Config Class Initialized
INFO - 2024-10-28 08:02:39 --> Hooks Class Initialized
DEBUG - 2024-10-28 08:02:39 --> UTF-8 Support Enabled
INFO - 2024-10-28 08:02:39 --> Utf8 Class Initialized
INFO - 2024-10-28 08:02:39 --> URI Class Initialized
INFO - 2024-10-28 08:02:39 --> Router Class Initialized
INFO - 2024-10-28 08:02:39 --> Output Class Initialized
INFO - 2024-10-28 08:02:39 --> Security Class Initialized
DEBUG - 2024-10-28 08:02:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-28 08:02:39 --> Input Class Initialized
INFO - 2024-10-28 08:02:39 --> Language Class Initialized
INFO - 2024-10-28 08:02:39 --> Language Class Initialized
INFO - 2024-10-28 08:02:39 --> Config Class Initialized
INFO - 2024-10-28 08:02:39 --> Loader Class Initialized
INFO - 2024-10-28 08:02:39 --> Helper loaded: url_helper
INFO - 2024-10-28 08:02:39 --> Helper loaded: file_helper
INFO - 2024-10-28 08:02:39 --> Helper loaded: form_helper
INFO - 2024-10-28 08:02:39 --> Helper loaded: my_helper
INFO - 2024-10-28 08:02:39 --> Database Driver Class Initialized
INFO - 2024-10-28 08:02:39 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-28 08:02:39 --> Controller Class Initialized
INFO - 2024-10-28 08:03:13 --> Config Class Initialized
INFO - 2024-10-28 08:03:13 --> Hooks Class Initialized
DEBUG - 2024-10-28 08:03:13 --> UTF-8 Support Enabled
INFO - 2024-10-28 08:03:13 --> Utf8 Class Initialized
INFO - 2024-10-28 08:03:13 --> URI Class Initialized
INFO - 2024-10-28 08:03:13 --> Router Class Initialized
INFO - 2024-10-28 08:03:13 --> Output Class Initialized
INFO - 2024-10-28 08:03:13 --> Security Class Initialized
DEBUG - 2024-10-28 08:03:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-28 08:03:13 --> Input Class Initialized
INFO - 2024-10-28 08:03:13 --> Language Class Initialized
INFO - 2024-10-28 08:03:13 --> Language Class Initialized
INFO - 2024-10-28 08:03:13 --> Config Class Initialized
INFO - 2024-10-28 08:03:13 --> Loader Class Initialized
INFO - 2024-10-28 08:03:13 --> Helper loaded: url_helper
INFO - 2024-10-28 08:03:13 --> Helper loaded: file_helper
INFO - 2024-10-28 08:03:13 --> Helper loaded: form_helper
INFO - 2024-10-28 08:03:13 --> Helper loaded: my_helper
INFO - 2024-10-28 08:03:13 --> Database Driver Class Initialized
INFO - 2024-10-28 08:03:13 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-28 08:03:13 --> Controller Class Initialized
INFO - 2024-10-28 08:03:13 --> Config Class Initialized
INFO - 2024-10-28 08:03:13 --> Hooks Class Initialized
DEBUG - 2024-10-28 08:03:13 --> UTF-8 Support Enabled
INFO - 2024-10-28 08:03:13 --> Utf8 Class Initialized
INFO - 2024-10-28 08:03:13 --> URI Class Initialized
INFO - 2024-10-28 08:03:13 --> Router Class Initialized
INFO - 2024-10-28 08:03:13 --> Output Class Initialized
INFO - 2024-10-28 08:03:13 --> Security Class Initialized
DEBUG - 2024-10-28 08:03:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-28 08:03:13 --> Input Class Initialized
INFO - 2024-10-28 08:03:13 --> Language Class Initialized
INFO - 2024-10-28 08:03:13 --> Language Class Initialized
INFO - 2024-10-28 08:03:13 --> Config Class Initialized
INFO - 2024-10-28 08:03:13 --> Loader Class Initialized
INFO - 2024-10-28 08:03:13 --> Helper loaded: url_helper
INFO - 2024-10-28 08:03:13 --> Helper loaded: file_helper
INFO - 2024-10-28 08:03:13 --> Helper loaded: form_helper
INFO - 2024-10-28 08:03:13 --> Helper loaded: my_helper
INFO - 2024-10-28 08:03:13 --> Database Driver Class Initialized
INFO - 2024-10-28 08:03:13 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-28 08:03:13 --> Controller Class Initialized
INFO - 2024-10-28 08:03:14 --> Config Class Initialized
INFO - 2024-10-28 08:03:14 --> Hooks Class Initialized
DEBUG - 2024-10-28 08:03:14 --> UTF-8 Support Enabled
INFO - 2024-10-28 08:03:14 --> Utf8 Class Initialized
INFO - 2024-10-28 08:03:14 --> URI Class Initialized
INFO - 2024-10-28 08:03:14 --> Router Class Initialized
INFO - 2024-10-28 08:03:14 --> Output Class Initialized
INFO - 2024-10-28 08:03:14 --> Security Class Initialized
DEBUG - 2024-10-28 08:03:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-28 08:03:14 --> Input Class Initialized
INFO - 2024-10-28 08:03:14 --> Language Class Initialized
INFO - 2024-10-28 08:03:14 --> Language Class Initialized
INFO - 2024-10-28 08:03:14 --> Config Class Initialized
INFO - 2024-10-28 08:03:14 --> Loader Class Initialized
INFO - 2024-10-28 08:03:14 --> Helper loaded: url_helper
INFO - 2024-10-28 08:03:14 --> Helper loaded: file_helper
INFO - 2024-10-28 08:03:14 --> Helper loaded: form_helper
INFO - 2024-10-28 08:03:14 --> Helper loaded: my_helper
INFO - 2024-10-28 08:03:14 --> Database Driver Class Initialized
INFO - 2024-10-28 08:03:14 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-28 08:03:14 --> Controller Class Initialized
INFO - 2024-10-28 08:03:16 --> Config Class Initialized
INFO - 2024-10-28 08:03:16 --> Hooks Class Initialized
DEBUG - 2024-10-28 08:03:16 --> UTF-8 Support Enabled
INFO - 2024-10-28 08:03:16 --> Utf8 Class Initialized
INFO - 2024-10-28 08:03:16 --> URI Class Initialized
INFO - 2024-10-28 08:03:16 --> Router Class Initialized
INFO - 2024-10-28 08:03:16 --> Output Class Initialized
INFO - 2024-10-28 08:03:16 --> Security Class Initialized
DEBUG - 2024-10-28 08:03:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-28 08:03:16 --> Input Class Initialized
INFO - 2024-10-28 08:03:16 --> Language Class Initialized
INFO - 2024-10-28 08:03:16 --> Language Class Initialized
INFO - 2024-10-28 08:03:16 --> Config Class Initialized
INFO - 2024-10-28 08:03:16 --> Loader Class Initialized
INFO - 2024-10-28 08:03:16 --> Helper loaded: url_helper
INFO - 2024-10-28 08:03:16 --> Helper loaded: file_helper
INFO - 2024-10-28 08:03:16 --> Helper loaded: form_helper
INFO - 2024-10-28 08:03:16 --> Helper loaded: my_helper
INFO - 2024-10-28 08:03:16 --> Database Driver Class Initialized
INFO - 2024-10-28 08:03:16 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-28 08:03:16 --> Controller Class Initialized
ERROR - 2024-10-28 08:03:16 --> Severity: Notice --> Undefined variable: status_form /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/data_siswa/views/form.php 231
DEBUG - 2024-10-28 08:03:16 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/data_siswa/views/form.php
DEBUG - 2024-10-28 08:03:16 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-10-28 08:03:16 --> Final output sent to browser
DEBUG - 2024-10-28 08:03:16 --> Total execution time: 0.0346
INFO - 2024-10-28 08:04:00 --> Config Class Initialized
INFO - 2024-10-28 08:04:00 --> Hooks Class Initialized
DEBUG - 2024-10-28 08:04:00 --> UTF-8 Support Enabled
INFO - 2024-10-28 08:04:00 --> Utf8 Class Initialized
INFO - 2024-10-28 08:04:00 --> URI Class Initialized
INFO - 2024-10-28 08:04:00 --> Router Class Initialized
INFO - 2024-10-28 08:04:00 --> Output Class Initialized
INFO - 2024-10-28 08:04:00 --> Security Class Initialized
DEBUG - 2024-10-28 08:04:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-28 08:04:00 --> Input Class Initialized
INFO - 2024-10-28 08:04:00 --> Language Class Initialized
INFO - 2024-10-28 08:04:00 --> Language Class Initialized
INFO - 2024-10-28 08:04:00 --> Config Class Initialized
INFO - 2024-10-28 08:04:00 --> Loader Class Initialized
INFO - 2024-10-28 08:04:00 --> Helper loaded: url_helper
INFO - 2024-10-28 08:04:00 --> Helper loaded: file_helper
INFO - 2024-10-28 08:04:00 --> Helper loaded: form_helper
INFO - 2024-10-28 08:04:00 --> Helper loaded: my_helper
INFO - 2024-10-28 08:04:00 --> Database Driver Class Initialized
INFO - 2024-10-28 08:04:00 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-28 08:04:00 --> Controller Class Initialized
INFO - 2024-10-28 08:04:00 --> Upload Class Initialized
INFO - 2024-10-28 08:04:00 --> Language file loaded: language/english/upload_lang.php
ERROR - 2024-10-28 08:04:00 --> The upload path does not appear to be valid.
INFO - 2024-10-28 08:04:00 --> Config Class Initialized
INFO - 2024-10-28 08:04:00 --> Hooks Class Initialized
DEBUG - 2024-10-28 08:04:00 --> UTF-8 Support Enabled
INFO - 2024-10-28 08:04:00 --> Utf8 Class Initialized
INFO - 2024-10-28 08:04:00 --> URI Class Initialized
INFO - 2024-10-28 08:04:00 --> Router Class Initialized
INFO - 2024-10-28 08:04:00 --> Output Class Initialized
INFO - 2024-10-28 08:04:00 --> Security Class Initialized
DEBUG - 2024-10-28 08:04:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-28 08:04:00 --> Input Class Initialized
INFO - 2024-10-28 08:04:00 --> Language Class Initialized
INFO - 2024-10-28 08:04:00 --> Language Class Initialized
INFO - 2024-10-28 08:04:00 --> Config Class Initialized
INFO - 2024-10-28 08:04:00 --> Loader Class Initialized
INFO - 2024-10-28 08:04:00 --> Helper loaded: url_helper
INFO - 2024-10-28 08:04:00 --> Helper loaded: file_helper
INFO - 2024-10-28 08:04:00 --> Helper loaded: form_helper
INFO - 2024-10-28 08:04:00 --> Helper loaded: my_helper
INFO - 2024-10-28 08:04:00 --> Database Driver Class Initialized
INFO - 2024-10-28 08:04:00 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-28 08:04:00 --> Controller Class Initialized
DEBUG - 2024-10-28 08:04:00 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/data_siswa/views/list.php
DEBUG - 2024-10-28 08:04:00 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-10-28 08:04:00 --> Final output sent to browser
DEBUG - 2024-10-28 08:04:00 --> Total execution time: 0.0270
INFO - 2024-10-28 08:04:00 --> Config Class Initialized
INFO - 2024-10-28 08:04:00 --> Hooks Class Initialized
DEBUG - 2024-10-28 08:04:00 --> UTF-8 Support Enabled
INFO - 2024-10-28 08:04:00 --> Utf8 Class Initialized
INFO - 2024-10-28 08:04:00 --> URI Class Initialized
INFO - 2024-10-28 08:04:00 --> Router Class Initialized
INFO - 2024-10-28 08:04:00 --> Output Class Initialized
INFO - 2024-10-28 08:04:00 --> Security Class Initialized
DEBUG - 2024-10-28 08:04:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-28 08:04:00 --> Input Class Initialized
INFO - 2024-10-28 08:04:00 --> Language Class Initialized
ERROR - 2024-10-28 08:04:00 --> 404 Page Not Found: /index
INFO - 2024-10-28 08:04:00 --> Config Class Initialized
INFO - 2024-10-28 08:04:00 --> Hooks Class Initialized
DEBUG - 2024-10-28 08:04:00 --> UTF-8 Support Enabled
INFO - 2024-10-28 08:04:00 --> Utf8 Class Initialized
INFO - 2024-10-28 08:04:00 --> URI Class Initialized
INFO - 2024-10-28 08:04:00 --> Router Class Initialized
INFO - 2024-10-28 08:04:00 --> Output Class Initialized
INFO - 2024-10-28 08:04:00 --> Security Class Initialized
DEBUG - 2024-10-28 08:04:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-28 08:04:00 --> Input Class Initialized
INFO - 2024-10-28 08:04:00 --> Language Class Initialized
INFO - 2024-10-28 08:04:00 --> Language Class Initialized
INFO - 2024-10-28 08:04:00 --> Config Class Initialized
INFO - 2024-10-28 08:04:00 --> Loader Class Initialized
INFO - 2024-10-28 08:04:00 --> Helper loaded: url_helper
INFO - 2024-10-28 08:04:00 --> Helper loaded: file_helper
INFO - 2024-10-28 08:04:00 --> Helper loaded: form_helper
INFO - 2024-10-28 08:04:00 --> Helper loaded: my_helper
INFO - 2024-10-28 08:04:00 --> Database Driver Class Initialized
INFO - 2024-10-28 08:04:00 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-28 08:04:00 --> Controller Class Initialized
INFO - 2024-10-28 08:04:08 --> Config Class Initialized
INFO - 2024-10-28 08:04:08 --> Hooks Class Initialized
DEBUG - 2024-10-28 08:04:08 --> UTF-8 Support Enabled
INFO - 2024-10-28 08:04:08 --> Utf8 Class Initialized
INFO - 2024-10-28 08:04:08 --> URI Class Initialized
INFO - 2024-10-28 08:04:08 --> Router Class Initialized
INFO - 2024-10-28 08:04:08 --> Output Class Initialized
INFO - 2024-10-28 08:04:08 --> Security Class Initialized
DEBUG - 2024-10-28 08:04:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-28 08:04:08 --> Input Class Initialized
INFO - 2024-10-28 08:04:08 --> Language Class Initialized
INFO - 2024-10-28 08:04:08 --> Language Class Initialized
INFO - 2024-10-28 08:04:08 --> Config Class Initialized
INFO - 2024-10-28 08:04:08 --> Loader Class Initialized
INFO - 2024-10-28 08:04:08 --> Helper loaded: url_helper
INFO - 2024-10-28 08:04:08 --> Helper loaded: file_helper
INFO - 2024-10-28 08:04:08 --> Helper loaded: form_helper
INFO - 2024-10-28 08:04:08 --> Helper loaded: my_helper
INFO - 2024-10-28 08:04:08 --> Database Driver Class Initialized
INFO - 2024-10-28 08:04:08 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-28 08:04:08 --> Controller Class Initialized
INFO - 2024-10-28 08:04:08 --> Config Class Initialized
INFO - 2024-10-28 08:04:08 --> Hooks Class Initialized
DEBUG - 2024-10-28 08:04:08 --> UTF-8 Support Enabled
INFO - 2024-10-28 08:04:08 --> Utf8 Class Initialized
INFO - 2024-10-28 08:04:08 --> URI Class Initialized
INFO - 2024-10-28 08:04:08 --> Router Class Initialized
INFO - 2024-10-28 08:04:08 --> Output Class Initialized
INFO - 2024-10-28 08:04:08 --> Security Class Initialized
DEBUG - 2024-10-28 08:04:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-28 08:04:08 --> Input Class Initialized
INFO - 2024-10-28 08:04:08 --> Language Class Initialized
INFO - 2024-10-28 08:04:08 --> Language Class Initialized
INFO - 2024-10-28 08:04:08 --> Config Class Initialized
INFO - 2024-10-28 08:04:08 --> Loader Class Initialized
INFO - 2024-10-28 08:04:08 --> Helper loaded: url_helper
INFO - 2024-10-28 08:04:08 --> Helper loaded: file_helper
INFO - 2024-10-28 08:04:08 --> Helper loaded: form_helper
INFO - 2024-10-28 08:04:08 --> Helper loaded: my_helper
INFO - 2024-10-28 08:04:08 --> Database Driver Class Initialized
INFO - 2024-10-28 08:04:08 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-28 08:04:08 --> Controller Class Initialized
INFO - 2024-10-28 08:04:09 --> Config Class Initialized
INFO - 2024-10-28 08:04:09 --> Hooks Class Initialized
DEBUG - 2024-10-28 08:04:09 --> UTF-8 Support Enabled
INFO - 2024-10-28 08:04:09 --> Utf8 Class Initialized
INFO - 2024-10-28 08:04:09 --> URI Class Initialized
INFO - 2024-10-28 08:04:09 --> Router Class Initialized
INFO - 2024-10-28 08:04:09 --> Output Class Initialized
INFO - 2024-10-28 08:04:09 --> Security Class Initialized
DEBUG - 2024-10-28 08:04:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-28 08:04:09 --> Input Class Initialized
INFO - 2024-10-28 08:04:09 --> Language Class Initialized
INFO - 2024-10-28 08:04:09 --> Language Class Initialized
INFO - 2024-10-28 08:04:09 --> Config Class Initialized
INFO - 2024-10-28 08:04:09 --> Loader Class Initialized
INFO - 2024-10-28 08:04:09 --> Helper loaded: url_helper
INFO - 2024-10-28 08:04:09 --> Helper loaded: file_helper
INFO - 2024-10-28 08:04:09 --> Helper loaded: form_helper
INFO - 2024-10-28 08:04:09 --> Helper loaded: my_helper
INFO - 2024-10-28 08:04:09 --> Database Driver Class Initialized
INFO - 2024-10-28 08:04:09 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-28 08:04:09 --> Controller Class Initialized
INFO - 2024-10-28 08:04:09 --> Config Class Initialized
INFO - 2024-10-28 08:04:09 --> Hooks Class Initialized
DEBUG - 2024-10-28 08:04:09 --> UTF-8 Support Enabled
INFO - 2024-10-28 08:04:09 --> Utf8 Class Initialized
INFO - 2024-10-28 08:04:09 --> URI Class Initialized
INFO - 2024-10-28 08:04:09 --> Router Class Initialized
INFO - 2024-10-28 08:04:09 --> Output Class Initialized
INFO - 2024-10-28 08:04:09 --> Security Class Initialized
DEBUG - 2024-10-28 08:04:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-28 08:04:09 --> Input Class Initialized
INFO - 2024-10-28 08:04:09 --> Language Class Initialized
INFO - 2024-10-28 08:04:09 --> Language Class Initialized
INFO - 2024-10-28 08:04:09 --> Config Class Initialized
INFO - 2024-10-28 08:04:09 --> Loader Class Initialized
INFO - 2024-10-28 08:04:09 --> Helper loaded: url_helper
INFO - 2024-10-28 08:04:09 --> Helper loaded: file_helper
INFO - 2024-10-28 08:04:09 --> Helper loaded: form_helper
INFO - 2024-10-28 08:04:09 --> Helper loaded: my_helper
INFO - 2024-10-28 08:04:09 --> Database Driver Class Initialized
INFO - 2024-10-28 08:04:09 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-28 08:04:09 --> Controller Class Initialized
INFO - 2024-10-28 08:04:09 --> Config Class Initialized
INFO - 2024-10-28 08:04:09 --> Hooks Class Initialized
DEBUG - 2024-10-28 08:04:09 --> UTF-8 Support Enabled
INFO - 2024-10-28 08:04:09 --> Utf8 Class Initialized
INFO - 2024-10-28 08:04:09 --> URI Class Initialized
INFO - 2024-10-28 08:04:09 --> Router Class Initialized
INFO - 2024-10-28 08:04:09 --> Output Class Initialized
INFO - 2024-10-28 08:04:09 --> Security Class Initialized
DEBUG - 2024-10-28 08:04:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-28 08:04:09 --> Input Class Initialized
INFO - 2024-10-28 08:04:09 --> Language Class Initialized
INFO - 2024-10-28 08:04:09 --> Language Class Initialized
INFO - 2024-10-28 08:04:09 --> Config Class Initialized
INFO - 2024-10-28 08:04:09 --> Loader Class Initialized
INFO - 2024-10-28 08:04:09 --> Helper loaded: url_helper
INFO - 2024-10-28 08:04:09 --> Helper loaded: file_helper
INFO - 2024-10-28 08:04:09 --> Helper loaded: form_helper
INFO - 2024-10-28 08:04:09 --> Helper loaded: my_helper
INFO - 2024-10-28 08:04:09 --> Database Driver Class Initialized
INFO - 2024-10-28 08:04:09 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-28 08:04:09 --> Controller Class Initialized
INFO - 2024-10-28 08:04:11 --> Config Class Initialized
INFO - 2024-10-28 08:04:11 --> Hooks Class Initialized
DEBUG - 2024-10-28 08:04:11 --> UTF-8 Support Enabled
INFO - 2024-10-28 08:04:11 --> Utf8 Class Initialized
INFO - 2024-10-28 08:04:11 --> URI Class Initialized
INFO - 2024-10-28 08:04:11 --> Router Class Initialized
INFO - 2024-10-28 08:04:11 --> Output Class Initialized
INFO - 2024-10-28 08:04:11 --> Security Class Initialized
DEBUG - 2024-10-28 08:04:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-28 08:04:11 --> Input Class Initialized
INFO - 2024-10-28 08:04:11 --> Language Class Initialized
INFO - 2024-10-28 08:04:11 --> Language Class Initialized
INFO - 2024-10-28 08:04:11 --> Config Class Initialized
INFO - 2024-10-28 08:04:11 --> Loader Class Initialized
INFO - 2024-10-28 08:04:11 --> Helper loaded: url_helper
INFO - 2024-10-28 08:04:11 --> Helper loaded: file_helper
INFO - 2024-10-28 08:04:11 --> Helper loaded: form_helper
INFO - 2024-10-28 08:04:11 --> Helper loaded: my_helper
INFO - 2024-10-28 08:04:11 --> Database Driver Class Initialized
INFO - 2024-10-28 08:04:11 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-28 08:04:11 --> Controller Class Initialized
ERROR - 2024-10-28 08:04:11 --> Severity: Notice --> Undefined variable: status_form /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/data_siswa/views/form.php 231
DEBUG - 2024-10-28 08:04:11 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/data_siswa/views/form.php
DEBUG - 2024-10-28 08:04:11 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-10-28 08:04:11 --> Final output sent to browser
DEBUG - 2024-10-28 08:04:11 --> Total execution time: 0.0384
INFO - 2024-10-28 08:04:34 --> Config Class Initialized
INFO - 2024-10-28 08:04:34 --> Hooks Class Initialized
DEBUG - 2024-10-28 08:04:34 --> UTF-8 Support Enabled
INFO - 2024-10-28 08:04:34 --> Utf8 Class Initialized
INFO - 2024-10-28 08:04:34 --> URI Class Initialized
INFO - 2024-10-28 08:04:34 --> Router Class Initialized
INFO - 2024-10-28 08:04:34 --> Output Class Initialized
INFO - 2024-10-28 08:04:34 --> Security Class Initialized
DEBUG - 2024-10-28 08:04:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-28 08:04:34 --> Input Class Initialized
INFO - 2024-10-28 08:04:34 --> Language Class Initialized
INFO - 2024-10-28 08:04:34 --> Language Class Initialized
INFO - 2024-10-28 08:04:34 --> Config Class Initialized
INFO - 2024-10-28 08:04:34 --> Loader Class Initialized
INFO - 2024-10-28 08:04:34 --> Helper loaded: url_helper
INFO - 2024-10-28 08:04:34 --> Helper loaded: file_helper
INFO - 2024-10-28 08:04:34 --> Helper loaded: form_helper
INFO - 2024-10-28 08:04:34 --> Helper loaded: my_helper
INFO - 2024-10-28 08:04:34 --> Database Driver Class Initialized
INFO - 2024-10-28 08:04:34 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-28 08:04:34 --> Controller Class Initialized
INFO - 2024-10-28 08:04:34 --> Upload Class Initialized
INFO - 2024-10-28 08:04:34 --> Language file loaded: language/english/upload_lang.php
ERROR - 2024-10-28 08:04:34 --> The upload path does not appear to be valid.
INFO - 2024-10-28 08:04:34 --> Config Class Initialized
INFO - 2024-10-28 08:04:34 --> Hooks Class Initialized
DEBUG - 2024-10-28 08:04:34 --> UTF-8 Support Enabled
INFO - 2024-10-28 08:04:34 --> Utf8 Class Initialized
INFO - 2024-10-28 08:04:34 --> URI Class Initialized
INFO - 2024-10-28 08:04:34 --> Router Class Initialized
INFO - 2024-10-28 08:04:34 --> Output Class Initialized
INFO - 2024-10-28 08:04:34 --> Security Class Initialized
DEBUG - 2024-10-28 08:04:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-28 08:04:34 --> Input Class Initialized
INFO - 2024-10-28 08:04:34 --> Language Class Initialized
INFO - 2024-10-28 08:04:34 --> Language Class Initialized
INFO - 2024-10-28 08:04:34 --> Config Class Initialized
INFO - 2024-10-28 08:04:34 --> Loader Class Initialized
INFO - 2024-10-28 08:04:34 --> Helper loaded: url_helper
INFO - 2024-10-28 08:04:34 --> Helper loaded: file_helper
INFO - 2024-10-28 08:04:34 --> Helper loaded: form_helper
INFO - 2024-10-28 08:04:34 --> Helper loaded: my_helper
INFO - 2024-10-28 08:04:34 --> Database Driver Class Initialized
INFO - 2024-10-28 08:04:34 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-28 08:04:34 --> Controller Class Initialized
DEBUG - 2024-10-28 08:04:34 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/data_siswa/views/list.php
DEBUG - 2024-10-28 08:04:34 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-10-28 08:04:34 --> Final output sent to browser
DEBUG - 2024-10-28 08:04:34 --> Total execution time: 0.0508
INFO - 2024-10-28 08:04:34 --> Config Class Initialized
INFO - 2024-10-28 08:04:34 --> Hooks Class Initialized
DEBUG - 2024-10-28 08:04:34 --> UTF-8 Support Enabled
INFO - 2024-10-28 08:04:34 --> Utf8 Class Initialized
INFO - 2024-10-28 08:04:34 --> URI Class Initialized
INFO - 2024-10-28 08:04:34 --> Router Class Initialized
INFO - 2024-10-28 08:04:34 --> Output Class Initialized
INFO - 2024-10-28 08:04:34 --> Security Class Initialized
DEBUG - 2024-10-28 08:04:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-28 08:04:34 --> Input Class Initialized
INFO - 2024-10-28 08:04:34 --> Language Class Initialized
ERROR - 2024-10-28 08:04:34 --> 404 Page Not Found: /index
INFO - 2024-10-28 08:04:34 --> Config Class Initialized
INFO - 2024-10-28 08:04:34 --> Hooks Class Initialized
DEBUG - 2024-10-28 08:04:34 --> UTF-8 Support Enabled
INFO - 2024-10-28 08:04:34 --> Utf8 Class Initialized
INFO - 2024-10-28 08:04:34 --> URI Class Initialized
INFO - 2024-10-28 08:04:34 --> Router Class Initialized
INFO - 2024-10-28 08:04:34 --> Output Class Initialized
INFO - 2024-10-28 08:04:34 --> Security Class Initialized
DEBUG - 2024-10-28 08:04:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-28 08:04:34 --> Input Class Initialized
INFO - 2024-10-28 08:04:34 --> Language Class Initialized
INFO - 2024-10-28 08:04:35 --> Language Class Initialized
INFO - 2024-10-28 08:04:35 --> Config Class Initialized
INFO - 2024-10-28 08:04:35 --> Loader Class Initialized
INFO - 2024-10-28 08:04:35 --> Helper loaded: url_helper
INFO - 2024-10-28 08:04:35 --> Helper loaded: file_helper
INFO - 2024-10-28 08:04:35 --> Helper loaded: form_helper
INFO - 2024-10-28 08:04:35 --> Helper loaded: my_helper
INFO - 2024-10-28 08:04:35 --> Database Driver Class Initialized
INFO - 2024-10-28 08:04:35 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-28 08:04:35 --> Controller Class Initialized
INFO - 2024-10-28 08:04:54 --> Config Class Initialized
INFO - 2024-10-28 08:04:54 --> Hooks Class Initialized
DEBUG - 2024-10-28 08:04:54 --> UTF-8 Support Enabled
INFO - 2024-10-28 08:04:54 --> Utf8 Class Initialized
INFO - 2024-10-28 08:04:54 --> URI Class Initialized
INFO - 2024-10-28 08:04:54 --> Router Class Initialized
INFO - 2024-10-28 08:04:54 --> Output Class Initialized
INFO - 2024-10-28 08:04:54 --> Security Class Initialized
DEBUG - 2024-10-28 08:04:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-28 08:04:54 --> Input Class Initialized
INFO - 2024-10-28 08:04:54 --> Language Class Initialized
INFO - 2024-10-28 08:04:54 --> Language Class Initialized
INFO - 2024-10-28 08:04:54 --> Config Class Initialized
INFO - 2024-10-28 08:04:54 --> Loader Class Initialized
INFO - 2024-10-28 08:04:54 --> Helper loaded: url_helper
INFO - 2024-10-28 08:04:54 --> Helper loaded: file_helper
INFO - 2024-10-28 08:04:54 --> Helper loaded: form_helper
INFO - 2024-10-28 08:04:54 --> Helper loaded: my_helper
INFO - 2024-10-28 08:04:54 --> Database Driver Class Initialized
INFO - 2024-10-28 08:04:54 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-28 08:04:54 --> Controller Class Initialized
INFO - 2024-10-28 08:04:54 --> Config Class Initialized
INFO - 2024-10-28 08:04:54 --> Hooks Class Initialized
DEBUG - 2024-10-28 08:04:54 --> UTF-8 Support Enabled
INFO - 2024-10-28 08:04:54 --> Utf8 Class Initialized
INFO - 2024-10-28 08:04:54 --> URI Class Initialized
INFO - 2024-10-28 08:04:54 --> Router Class Initialized
INFO - 2024-10-28 08:04:54 --> Output Class Initialized
INFO - 2024-10-28 08:04:54 --> Security Class Initialized
DEBUG - 2024-10-28 08:04:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-28 08:04:54 --> Input Class Initialized
INFO - 2024-10-28 08:04:54 --> Language Class Initialized
INFO - 2024-10-28 08:04:54 --> Language Class Initialized
INFO - 2024-10-28 08:04:54 --> Config Class Initialized
INFO - 2024-10-28 08:04:54 --> Loader Class Initialized
INFO - 2024-10-28 08:04:54 --> Helper loaded: url_helper
INFO - 2024-10-28 08:04:54 --> Helper loaded: file_helper
INFO - 2024-10-28 08:04:54 --> Helper loaded: form_helper
INFO - 2024-10-28 08:04:54 --> Helper loaded: my_helper
INFO - 2024-10-28 08:04:54 --> Database Driver Class Initialized
INFO - 2024-10-28 08:04:54 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-28 08:04:54 --> Controller Class Initialized
INFO - 2024-10-28 08:04:55 --> Config Class Initialized
INFO - 2024-10-28 08:04:55 --> Hooks Class Initialized
DEBUG - 2024-10-28 08:04:55 --> UTF-8 Support Enabled
INFO - 2024-10-28 08:04:55 --> Utf8 Class Initialized
INFO - 2024-10-28 08:04:55 --> URI Class Initialized
INFO - 2024-10-28 08:04:55 --> Router Class Initialized
INFO - 2024-10-28 08:04:55 --> Output Class Initialized
INFO - 2024-10-28 08:04:55 --> Security Class Initialized
DEBUG - 2024-10-28 08:04:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-28 08:04:55 --> Input Class Initialized
INFO - 2024-10-28 08:04:55 --> Language Class Initialized
INFO - 2024-10-28 08:04:55 --> Language Class Initialized
INFO - 2024-10-28 08:04:55 --> Config Class Initialized
INFO - 2024-10-28 08:04:55 --> Loader Class Initialized
INFO - 2024-10-28 08:04:55 --> Helper loaded: url_helper
INFO - 2024-10-28 08:04:55 --> Helper loaded: file_helper
INFO - 2024-10-28 08:04:55 --> Helper loaded: form_helper
INFO - 2024-10-28 08:04:55 --> Helper loaded: my_helper
INFO - 2024-10-28 08:04:55 --> Database Driver Class Initialized
INFO - 2024-10-28 08:04:55 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-28 08:04:55 --> Controller Class Initialized
INFO - 2024-10-28 08:04:55 --> Config Class Initialized
INFO - 2024-10-28 08:04:55 --> Hooks Class Initialized
DEBUG - 2024-10-28 08:04:55 --> UTF-8 Support Enabled
INFO - 2024-10-28 08:04:55 --> Utf8 Class Initialized
INFO - 2024-10-28 08:04:55 --> URI Class Initialized
INFO - 2024-10-28 08:04:55 --> Router Class Initialized
INFO - 2024-10-28 08:04:55 --> Output Class Initialized
INFO - 2024-10-28 08:04:55 --> Security Class Initialized
DEBUG - 2024-10-28 08:04:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-28 08:04:55 --> Input Class Initialized
INFO - 2024-10-28 08:04:55 --> Language Class Initialized
INFO - 2024-10-28 08:04:55 --> Language Class Initialized
INFO - 2024-10-28 08:04:55 --> Config Class Initialized
INFO - 2024-10-28 08:04:55 --> Loader Class Initialized
INFO - 2024-10-28 08:04:55 --> Helper loaded: url_helper
INFO - 2024-10-28 08:04:55 --> Helper loaded: file_helper
INFO - 2024-10-28 08:04:55 --> Helper loaded: form_helper
INFO - 2024-10-28 08:04:55 --> Helper loaded: my_helper
INFO - 2024-10-28 08:04:55 --> Database Driver Class Initialized
INFO - 2024-10-28 08:04:55 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-28 08:04:55 --> Controller Class Initialized
INFO - 2024-10-28 08:05:01 --> Config Class Initialized
INFO - 2024-10-28 08:05:01 --> Hooks Class Initialized
DEBUG - 2024-10-28 08:05:01 --> UTF-8 Support Enabled
INFO - 2024-10-28 08:05:01 --> Utf8 Class Initialized
INFO - 2024-10-28 08:05:01 --> URI Class Initialized
INFO - 2024-10-28 08:05:01 --> Router Class Initialized
INFO - 2024-10-28 08:05:01 --> Output Class Initialized
INFO - 2024-10-28 08:05:01 --> Security Class Initialized
DEBUG - 2024-10-28 08:05:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-28 08:05:01 --> Input Class Initialized
INFO - 2024-10-28 08:05:01 --> Language Class Initialized
INFO - 2024-10-28 08:05:01 --> Language Class Initialized
INFO - 2024-10-28 08:05:01 --> Config Class Initialized
INFO - 2024-10-28 08:05:01 --> Loader Class Initialized
INFO - 2024-10-28 08:05:01 --> Helper loaded: url_helper
INFO - 2024-10-28 08:05:01 --> Helper loaded: file_helper
INFO - 2024-10-28 08:05:01 --> Helper loaded: form_helper
INFO - 2024-10-28 08:05:01 --> Helper loaded: my_helper
INFO - 2024-10-28 08:05:01 --> Database Driver Class Initialized
INFO - 2024-10-28 08:05:01 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-28 08:05:01 --> Controller Class Initialized
ERROR - 2024-10-28 08:05:01 --> Severity: Notice --> Undefined variable: status_form /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/data_siswa/views/form.php 231
DEBUG - 2024-10-28 08:05:01 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/data_siswa/views/form.php
DEBUG - 2024-10-28 08:05:01 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-10-28 08:05:01 --> Final output sent to browser
DEBUG - 2024-10-28 08:05:01 --> Total execution time: 0.0372
INFO - 2024-10-28 08:05:21 --> Config Class Initialized
INFO - 2024-10-28 08:05:21 --> Hooks Class Initialized
DEBUG - 2024-10-28 08:05:21 --> UTF-8 Support Enabled
INFO - 2024-10-28 08:05:21 --> Utf8 Class Initialized
INFO - 2024-10-28 08:05:21 --> URI Class Initialized
INFO - 2024-10-28 08:05:21 --> Router Class Initialized
INFO - 2024-10-28 08:05:21 --> Output Class Initialized
INFO - 2024-10-28 08:05:21 --> Security Class Initialized
DEBUG - 2024-10-28 08:05:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-28 08:05:21 --> Input Class Initialized
INFO - 2024-10-28 08:05:21 --> Language Class Initialized
INFO - 2024-10-28 08:05:21 --> Language Class Initialized
INFO - 2024-10-28 08:05:21 --> Config Class Initialized
INFO - 2024-10-28 08:05:21 --> Loader Class Initialized
INFO - 2024-10-28 08:05:21 --> Helper loaded: url_helper
INFO - 2024-10-28 08:05:21 --> Helper loaded: file_helper
INFO - 2024-10-28 08:05:21 --> Helper loaded: form_helper
INFO - 2024-10-28 08:05:21 --> Helper loaded: my_helper
INFO - 2024-10-28 08:05:21 --> Database Driver Class Initialized
INFO - 2024-10-28 08:05:21 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-28 08:05:21 --> Controller Class Initialized
INFO - 2024-10-28 08:05:21 --> Upload Class Initialized
INFO - 2024-10-28 08:05:21 --> Language file loaded: language/english/upload_lang.php
ERROR - 2024-10-28 08:05:21 --> The upload path does not appear to be valid.
INFO - 2024-10-28 08:05:21 --> Config Class Initialized
INFO - 2024-10-28 08:05:21 --> Hooks Class Initialized
DEBUG - 2024-10-28 08:05:21 --> UTF-8 Support Enabled
INFO - 2024-10-28 08:05:21 --> Utf8 Class Initialized
INFO - 2024-10-28 08:05:21 --> URI Class Initialized
INFO - 2024-10-28 08:05:21 --> Router Class Initialized
INFO - 2024-10-28 08:05:21 --> Output Class Initialized
INFO - 2024-10-28 08:05:21 --> Security Class Initialized
DEBUG - 2024-10-28 08:05:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-28 08:05:21 --> Input Class Initialized
INFO - 2024-10-28 08:05:21 --> Language Class Initialized
INFO - 2024-10-28 08:05:21 --> Language Class Initialized
INFO - 2024-10-28 08:05:21 --> Config Class Initialized
INFO - 2024-10-28 08:05:21 --> Loader Class Initialized
INFO - 2024-10-28 08:05:21 --> Helper loaded: url_helper
INFO - 2024-10-28 08:05:21 --> Helper loaded: file_helper
INFO - 2024-10-28 08:05:21 --> Helper loaded: form_helper
INFO - 2024-10-28 08:05:21 --> Helper loaded: my_helper
INFO - 2024-10-28 08:05:21 --> Database Driver Class Initialized
INFO - 2024-10-28 08:05:21 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-28 08:05:21 --> Controller Class Initialized
DEBUG - 2024-10-28 08:05:21 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/data_siswa/views/list.php
DEBUG - 2024-10-28 08:05:21 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-10-28 08:05:21 --> Final output sent to browser
DEBUG - 2024-10-28 08:05:21 --> Total execution time: 0.0361
INFO - 2024-10-28 08:05:21 --> Config Class Initialized
INFO - 2024-10-28 08:05:21 --> Hooks Class Initialized
DEBUG - 2024-10-28 08:05:21 --> UTF-8 Support Enabled
INFO - 2024-10-28 08:05:21 --> Utf8 Class Initialized
INFO - 2024-10-28 08:05:21 --> URI Class Initialized
INFO - 2024-10-28 08:05:21 --> Router Class Initialized
INFO - 2024-10-28 08:05:21 --> Output Class Initialized
INFO - 2024-10-28 08:05:21 --> Security Class Initialized
DEBUG - 2024-10-28 08:05:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-28 08:05:21 --> Input Class Initialized
INFO - 2024-10-28 08:05:21 --> Language Class Initialized
ERROR - 2024-10-28 08:05:21 --> 404 Page Not Found: /index
INFO - 2024-10-28 08:05:21 --> Config Class Initialized
INFO - 2024-10-28 08:05:21 --> Hooks Class Initialized
DEBUG - 2024-10-28 08:05:21 --> UTF-8 Support Enabled
INFO - 2024-10-28 08:05:21 --> Utf8 Class Initialized
INFO - 2024-10-28 08:05:21 --> URI Class Initialized
INFO - 2024-10-28 08:05:21 --> Router Class Initialized
INFO - 2024-10-28 08:05:21 --> Output Class Initialized
INFO - 2024-10-28 08:05:21 --> Security Class Initialized
DEBUG - 2024-10-28 08:05:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-28 08:05:21 --> Input Class Initialized
INFO - 2024-10-28 08:05:21 --> Language Class Initialized
INFO - 2024-10-28 08:05:21 --> Language Class Initialized
INFO - 2024-10-28 08:05:21 --> Config Class Initialized
INFO - 2024-10-28 08:05:21 --> Loader Class Initialized
INFO - 2024-10-28 08:05:21 --> Helper loaded: url_helper
INFO - 2024-10-28 08:05:21 --> Helper loaded: file_helper
INFO - 2024-10-28 08:05:21 --> Helper loaded: form_helper
INFO - 2024-10-28 08:05:21 --> Helper loaded: my_helper
INFO - 2024-10-28 08:05:21 --> Database Driver Class Initialized
INFO - 2024-10-28 08:05:21 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-28 08:05:21 --> Controller Class Initialized
INFO - 2024-10-28 08:13:38 --> Config Class Initialized
INFO - 2024-10-28 08:13:38 --> Hooks Class Initialized
DEBUG - 2024-10-28 08:13:38 --> UTF-8 Support Enabled
INFO - 2024-10-28 08:13:38 --> Utf8 Class Initialized
INFO - 2024-10-28 08:13:38 --> URI Class Initialized
INFO - 2024-10-28 08:13:38 --> Router Class Initialized
INFO - 2024-10-28 08:13:38 --> Output Class Initialized
INFO - 2024-10-28 08:13:38 --> Security Class Initialized
DEBUG - 2024-10-28 08:13:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-28 08:13:38 --> Input Class Initialized
INFO - 2024-10-28 08:13:38 --> Language Class Initialized
INFO - 2024-10-28 08:13:38 --> Language Class Initialized
INFO - 2024-10-28 08:13:38 --> Config Class Initialized
INFO - 2024-10-28 08:13:38 --> Loader Class Initialized
INFO - 2024-10-28 08:13:38 --> Helper loaded: url_helper
INFO - 2024-10-28 08:13:38 --> Helper loaded: file_helper
INFO - 2024-10-28 08:13:38 --> Helper loaded: form_helper
INFO - 2024-10-28 08:13:38 --> Helper loaded: my_helper
INFO - 2024-10-28 08:13:38 --> Database Driver Class Initialized
INFO - 2024-10-28 08:13:38 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-28 08:13:38 --> Controller Class Initialized
INFO - 2024-10-28 08:13:38 --> Config Class Initialized
INFO - 2024-10-28 08:13:38 --> Hooks Class Initialized
DEBUG - 2024-10-28 08:13:38 --> UTF-8 Support Enabled
INFO - 2024-10-28 08:13:38 --> Utf8 Class Initialized
INFO - 2024-10-28 08:13:38 --> URI Class Initialized
INFO - 2024-10-28 08:13:38 --> Router Class Initialized
INFO - 2024-10-28 08:13:38 --> Output Class Initialized
INFO - 2024-10-28 08:13:38 --> Security Class Initialized
DEBUG - 2024-10-28 08:13:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-28 08:13:38 --> Input Class Initialized
INFO - 2024-10-28 08:13:38 --> Language Class Initialized
INFO - 2024-10-28 08:13:38 --> Language Class Initialized
INFO - 2024-10-28 08:13:38 --> Config Class Initialized
INFO - 2024-10-28 08:13:38 --> Loader Class Initialized
INFO - 2024-10-28 08:13:38 --> Helper loaded: url_helper
INFO - 2024-10-28 08:13:38 --> Helper loaded: file_helper
INFO - 2024-10-28 08:13:38 --> Helper loaded: form_helper
INFO - 2024-10-28 08:13:38 --> Helper loaded: my_helper
INFO - 2024-10-28 08:13:38 --> Database Driver Class Initialized
INFO - 2024-10-28 08:13:38 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-28 08:13:38 --> Controller Class Initialized
INFO - 2024-10-28 08:13:40 --> Config Class Initialized
INFO - 2024-10-28 08:13:40 --> Hooks Class Initialized
DEBUG - 2024-10-28 08:13:40 --> UTF-8 Support Enabled
INFO - 2024-10-28 08:13:40 --> Utf8 Class Initialized
INFO - 2024-10-28 08:13:40 --> URI Class Initialized
INFO - 2024-10-28 08:13:40 --> Router Class Initialized
INFO - 2024-10-28 08:13:40 --> Output Class Initialized
INFO - 2024-10-28 08:13:40 --> Security Class Initialized
DEBUG - 2024-10-28 08:13:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-28 08:13:40 --> Input Class Initialized
INFO - 2024-10-28 08:13:40 --> Language Class Initialized
INFO - 2024-10-28 08:13:40 --> Language Class Initialized
INFO - 2024-10-28 08:13:40 --> Config Class Initialized
INFO - 2024-10-28 08:13:40 --> Loader Class Initialized
INFO - 2024-10-28 08:13:40 --> Helper loaded: url_helper
INFO - 2024-10-28 08:13:40 --> Helper loaded: file_helper
INFO - 2024-10-28 08:13:40 --> Helper loaded: form_helper
INFO - 2024-10-28 08:13:40 --> Helper loaded: my_helper
INFO - 2024-10-28 08:13:40 --> Database Driver Class Initialized
INFO - 2024-10-28 08:13:40 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-28 08:13:40 --> Controller Class Initialized
INFO - 2024-10-28 08:13:40 --> Config Class Initialized
INFO - 2024-10-28 08:13:40 --> Hooks Class Initialized
DEBUG - 2024-10-28 08:13:40 --> UTF-8 Support Enabled
INFO - 2024-10-28 08:13:40 --> Utf8 Class Initialized
INFO - 2024-10-28 08:13:40 --> URI Class Initialized
INFO - 2024-10-28 08:13:40 --> Router Class Initialized
INFO - 2024-10-28 08:13:40 --> Output Class Initialized
INFO - 2024-10-28 08:13:40 --> Security Class Initialized
DEBUG - 2024-10-28 08:13:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-28 08:13:40 --> Input Class Initialized
INFO - 2024-10-28 08:13:40 --> Language Class Initialized
INFO - 2024-10-28 08:13:40 --> Language Class Initialized
INFO - 2024-10-28 08:13:40 --> Config Class Initialized
INFO - 2024-10-28 08:13:40 --> Loader Class Initialized
INFO - 2024-10-28 08:13:40 --> Helper loaded: url_helper
INFO - 2024-10-28 08:13:40 --> Helper loaded: file_helper
INFO - 2024-10-28 08:13:40 --> Helper loaded: form_helper
INFO - 2024-10-28 08:13:40 --> Helper loaded: my_helper
INFO - 2024-10-28 08:13:40 --> Database Driver Class Initialized
INFO - 2024-10-28 08:13:40 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-28 08:13:40 --> Controller Class Initialized
INFO - 2024-10-28 08:13:41 --> Config Class Initialized
INFO - 2024-10-28 08:13:41 --> Hooks Class Initialized
DEBUG - 2024-10-28 08:13:41 --> UTF-8 Support Enabled
INFO - 2024-10-28 08:13:41 --> Utf8 Class Initialized
INFO - 2024-10-28 08:13:41 --> URI Class Initialized
INFO - 2024-10-28 08:13:41 --> Router Class Initialized
INFO - 2024-10-28 08:13:41 --> Output Class Initialized
INFO - 2024-10-28 08:13:41 --> Security Class Initialized
DEBUG - 2024-10-28 08:13:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-28 08:13:41 --> Input Class Initialized
INFO - 2024-10-28 08:13:41 --> Language Class Initialized
INFO - 2024-10-28 08:13:41 --> Language Class Initialized
INFO - 2024-10-28 08:13:41 --> Config Class Initialized
INFO - 2024-10-28 08:13:41 --> Loader Class Initialized
INFO - 2024-10-28 08:13:41 --> Helper loaded: url_helper
INFO - 2024-10-28 08:13:41 --> Helper loaded: file_helper
INFO - 2024-10-28 08:13:41 --> Helper loaded: form_helper
INFO - 2024-10-28 08:13:41 --> Helper loaded: my_helper
INFO - 2024-10-28 08:13:41 --> Database Driver Class Initialized
INFO - 2024-10-28 08:13:41 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-28 08:13:41 --> Controller Class Initialized
INFO - 2024-10-28 08:13:41 --> Config Class Initialized
INFO - 2024-10-28 08:13:41 --> Hooks Class Initialized
DEBUG - 2024-10-28 08:13:41 --> UTF-8 Support Enabled
INFO - 2024-10-28 08:13:41 --> Utf8 Class Initialized
INFO - 2024-10-28 08:13:41 --> URI Class Initialized
INFO - 2024-10-28 08:13:41 --> Router Class Initialized
INFO - 2024-10-28 08:13:41 --> Output Class Initialized
INFO - 2024-10-28 08:13:41 --> Config Class Initialized
INFO - 2024-10-28 08:13:41 --> Hooks Class Initialized
DEBUG - 2024-10-28 08:13:41 --> UTF-8 Support Enabled
INFO - 2024-10-28 08:13:41 --> Utf8 Class Initialized
INFO - 2024-10-28 08:13:41 --> URI Class Initialized
INFO - 2024-10-28 08:13:41 --> Router Class Initialized
INFO - 2024-10-28 08:13:41 --> Output Class Initialized
INFO - 2024-10-28 08:13:41 --> Security Class Initialized
DEBUG - 2024-10-28 08:13:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-28 08:13:41 --> Input Class Initialized
INFO - 2024-10-28 08:13:41 --> Language Class Initialized
INFO - 2024-10-28 08:13:41 --> Language Class Initialized
INFO - 2024-10-28 08:13:41 --> Config Class Initialized
INFO - 2024-10-28 08:13:41 --> Loader Class Initialized
INFO - 2024-10-28 08:13:41 --> Helper loaded: url_helper
INFO - 2024-10-28 08:13:41 --> Helper loaded: file_helper
INFO - 2024-10-28 08:13:41 --> Helper loaded: form_helper
INFO - 2024-10-28 08:13:41 --> Helper loaded: my_helper
INFO - 2024-10-28 08:13:41 --> Security Class Initialized
DEBUG - 2024-10-28 08:13:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-28 08:13:41 --> Input Class Initialized
INFO - 2024-10-28 08:13:41 --> Language Class Initialized
INFO - 2024-10-28 08:13:41 --> Language Class Initialized
INFO - 2024-10-28 08:13:41 --> Config Class Initialized
INFO - 2024-10-28 08:13:41 --> Loader Class Initialized
INFO - 2024-10-28 08:13:41 --> Helper loaded: url_helper
INFO - 2024-10-28 08:13:41 --> Helper loaded: file_helper
INFO - 2024-10-28 08:13:41 --> Helper loaded: form_helper
INFO - 2024-10-28 08:13:41 --> Helper loaded: my_helper
INFO - 2024-10-28 08:13:41 --> Database Driver Class Initialized
INFO - 2024-10-28 08:13:41 --> Database Driver Class Initialized
INFO - 2024-10-28 08:13:41 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-28 08:13:41 --> Controller Class Initialized
INFO - 2024-10-28 08:13:41 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-28 08:13:41 --> Controller Class Initialized
INFO - 2024-10-28 08:13:43 --> Config Class Initialized
INFO - 2024-10-28 08:13:43 --> Hooks Class Initialized
DEBUG - 2024-10-28 08:13:43 --> UTF-8 Support Enabled
INFO - 2024-10-28 08:13:43 --> Utf8 Class Initialized
INFO - 2024-10-28 08:13:43 --> URI Class Initialized
INFO - 2024-10-28 08:13:43 --> Router Class Initialized
INFO - 2024-10-28 08:13:43 --> Output Class Initialized
INFO - 2024-10-28 08:13:43 --> Security Class Initialized
DEBUG - 2024-10-28 08:13:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-28 08:13:43 --> Input Class Initialized
INFO - 2024-10-28 08:13:43 --> Language Class Initialized
INFO - 2024-10-28 08:13:43 --> Language Class Initialized
INFO - 2024-10-28 08:13:43 --> Config Class Initialized
INFO - 2024-10-28 08:13:43 --> Loader Class Initialized
INFO - 2024-10-28 08:13:43 --> Helper loaded: url_helper
INFO - 2024-10-28 08:13:43 --> Helper loaded: file_helper
INFO - 2024-10-28 08:13:43 --> Helper loaded: form_helper
INFO - 2024-10-28 08:13:43 --> Helper loaded: my_helper
INFO - 2024-10-28 08:13:43 --> Database Driver Class Initialized
INFO - 2024-10-28 08:13:43 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-28 08:13:43 --> Controller Class Initialized
ERROR - 2024-10-28 08:13:43 --> Severity: Notice --> Undefined variable: status_form /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/data_siswa/views/form.php 231
DEBUG - 2024-10-28 08:13:43 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/data_siswa/views/form.php
DEBUG - 2024-10-28 08:13:43 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-10-28 08:13:43 --> Final output sent to browser
DEBUG - 2024-10-28 08:13:43 --> Total execution time: 0.0306
INFO - 2024-10-28 08:14:11 --> Config Class Initialized
INFO - 2024-10-28 08:14:11 --> Hooks Class Initialized
DEBUG - 2024-10-28 08:14:11 --> UTF-8 Support Enabled
INFO - 2024-10-28 08:14:11 --> Utf8 Class Initialized
INFO - 2024-10-28 08:14:11 --> URI Class Initialized
INFO - 2024-10-28 08:14:11 --> Router Class Initialized
INFO - 2024-10-28 08:14:11 --> Output Class Initialized
INFO - 2024-10-28 08:14:11 --> Security Class Initialized
DEBUG - 2024-10-28 08:14:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-28 08:14:11 --> Input Class Initialized
INFO - 2024-10-28 08:14:11 --> Language Class Initialized
INFO - 2024-10-28 08:14:11 --> Language Class Initialized
INFO - 2024-10-28 08:14:11 --> Config Class Initialized
INFO - 2024-10-28 08:14:11 --> Loader Class Initialized
INFO - 2024-10-28 08:14:11 --> Helper loaded: url_helper
INFO - 2024-10-28 08:14:11 --> Helper loaded: file_helper
INFO - 2024-10-28 08:14:11 --> Helper loaded: form_helper
INFO - 2024-10-28 08:14:11 --> Helper loaded: my_helper
INFO - 2024-10-28 08:14:11 --> Database Driver Class Initialized
INFO - 2024-10-28 08:14:11 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-28 08:14:11 --> Controller Class Initialized
INFO - 2024-10-28 08:14:11 --> Upload Class Initialized
INFO - 2024-10-28 08:14:11 --> Language file loaded: language/english/upload_lang.php
ERROR - 2024-10-28 08:14:11 --> The upload path does not appear to be valid.
INFO - 2024-10-28 08:14:11 --> Config Class Initialized
INFO - 2024-10-28 08:14:11 --> Hooks Class Initialized
DEBUG - 2024-10-28 08:14:11 --> UTF-8 Support Enabled
INFO - 2024-10-28 08:14:11 --> Utf8 Class Initialized
INFO - 2024-10-28 08:14:11 --> URI Class Initialized
INFO - 2024-10-28 08:14:11 --> Router Class Initialized
INFO - 2024-10-28 08:14:11 --> Output Class Initialized
INFO - 2024-10-28 08:14:11 --> Security Class Initialized
DEBUG - 2024-10-28 08:14:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-28 08:14:11 --> Input Class Initialized
INFO - 2024-10-28 08:14:11 --> Language Class Initialized
INFO - 2024-10-28 08:14:11 --> Language Class Initialized
INFO - 2024-10-28 08:14:11 --> Config Class Initialized
INFO - 2024-10-28 08:14:11 --> Loader Class Initialized
INFO - 2024-10-28 08:14:11 --> Helper loaded: url_helper
INFO - 2024-10-28 08:14:11 --> Helper loaded: file_helper
INFO - 2024-10-28 08:14:11 --> Helper loaded: form_helper
INFO - 2024-10-28 08:14:11 --> Helper loaded: my_helper
INFO - 2024-10-28 08:14:11 --> Database Driver Class Initialized
INFO - 2024-10-28 08:14:11 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-28 08:14:11 --> Controller Class Initialized
DEBUG - 2024-10-28 08:14:11 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/data_siswa/views/list.php
DEBUG - 2024-10-28 08:14:11 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-10-28 08:14:11 --> Final output sent to browser
DEBUG - 2024-10-28 08:14:11 --> Total execution time: 0.0301
INFO - 2024-10-28 08:14:11 --> Config Class Initialized
INFO - 2024-10-28 08:14:11 --> Hooks Class Initialized
DEBUG - 2024-10-28 08:14:11 --> UTF-8 Support Enabled
INFO - 2024-10-28 08:14:11 --> Utf8 Class Initialized
INFO - 2024-10-28 08:14:11 --> URI Class Initialized
INFO - 2024-10-28 08:14:11 --> Router Class Initialized
INFO - 2024-10-28 08:14:11 --> Output Class Initialized
INFO - 2024-10-28 08:14:11 --> Security Class Initialized
DEBUG - 2024-10-28 08:14:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-28 08:14:11 --> Input Class Initialized
INFO - 2024-10-28 08:14:11 --> Language Class Initialized
ERROR - 2024-10-28 08:14:11 --> 404 Page Not Found: /index
INFO - 2024-10-28 08:14:11 --> Config Class Initialized
INFO - 2024-10-28 08:14:11 --> Hooks Class Initialized
DEBUG - 2024-10-28 08:14:11 --> UTF-8 Support Enabled
INFO - 2024-10-28 08:14:11 --> Utf8 Class Initialized
INFO - 2024-10-28 08:14:11 --> URI Class Initialized
INFO - 2024-10-28 08:14:11 --> Router Class Initialized
INFO - 2024-10-28 08:14:11 --> Output Class Initialized
INFO - 2024-10-28 08:14:11 --> Security Class Initialized
DEBUG - 2024-10-28 08:14:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-28 08:14:11 --> Input Class Initialized
INFO - 2024-10-28 08:14:11 --> Language Class Initialized
INFO - 2024-10-28 08:14:11 --> Language Class Initialized
INFO - 2024-10-28 08:14:11 --> Config Class Initialized
INFO - 2024-10-28 08:14:11 --> Loader Class Initialized
INFO - 2024-10-28 08:14:11 --> Helper loaded: url_helper
INFO - 2024-10-28 08:14:11 --> Helper loaded: file_helper
INFO - 2024-10-28 08:14:11 --> Helper loaded: form_helper
INFO - 2024-10-28 08:14:11 --> Helper loaded: my_helper
INFO - 2024-10-28 08:14:11 --> Database Driver Class Initialized
INFO - 2024-10-28 08:14:11 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-28 08:14:11 --> Controller Class Initialized
INFO - 2024-10-28 08:14:24 --> Config Class Initialized
INFO - 2024-10-28 08:14:24 --> Hooks Class Initialized
DEBUG - 2024-10-28 08:14:24 --> UTF-8 Support Enabled
INFO - 2024-10-28 08:14:24 --> Utf8 Class Initialized
INFO - 2024-10-28 08:14:24 --> URI Class Initialized
INFO - 2024-10-28 08:14:24 --> Router Class Initialized
INFO - 2024-10-28 08:14:24 --> Output Class Initialized
INFO - 2024-10-28 08:14:24 --> Security Class Initialized
DEBUG - 2024-10-28 08:14:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-28 08:14:24 --> Input Class Initialized
INFO - 2024-10-28 08:14:24 --> Language Class Initialized
INFO - 2024-10-28 08:14:24 --> Language Class Initialized
INFO - 2024-10-28 08:14:24 --> Config Class Initialized
INFO - 2024-10-28 08:14:24 --> Loader Class Initialized
INFO - 2024-10-28 08:14:24 --> Helper loaded: url_helper
INFO - 2024-10-28 08:14:24 --> Helper loaded: file_helper
INFO - 2024-10-28 08:14:24 --> Helper loaded: form_helper
INFO - 2024-10-28 08:14:24 --> Helper loaded: my_helper
INFO - 2024-10-28 08:14:24 --> Database Driver Class Initialized
INFO - 2024-10-28 08:14:24 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-28 08:14:24 --> Controller Class Initialized
INFO - 2024-10-28 08:14:25 --> Config Class Initialized
INFO - 2024-10-28 08:14:25 --> Hooks Class Initialized
DEBUG - 2024-10-28 08:14:25 --> UTF-8 Support Enabled
INFO - 2024-10-28 08:14:25 --> Utf8 Class Initialized
INFO - 2024-10-28 08:14:25 --> URI Class Initialized
INFO - 2024-10-28 08:14:25 --> Router Class Initialized
INFO - 2024-10-28 08:14:25 --> Output Class Initialized
INFO - 2024-10-28 08:14:25 --> Security Class Initialized
DEBUG - 2024-10-28 08:14:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-28 08:14:25 --> Input Class Initialized
INFO - 2024-10-28 08:14:25 --> Language Class Initialized
INFO - 2024-10-28 08:14:25 --> Language Class Initialized
INFO - 2024-10-28 08:14:25 --> Config Class Initialized
INFO - 2024-10-28 08:14:25 --> Loader Class Initialized
INFO - 2024-10-28 08:14:25 --> Helper loaded: url_helper
INFO - 2024-10-28 08:14:25 --> Helper loaded: file_helper
INFO - 2024-10-28 08:14:25 --> Helper loaded: form_helper
INFO - 2024-10-28 08:14:25 --> Helper loaded: my_helper
INFO - 2024-10-28 08:14:25 --> Database Driver Class Initialized
INFO - 2024-10-28 08:14:25 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-28 08:14:25 --> Controller Class Initialized
INFO - 2024-10-28 08:14:25 --> Config Class Initialized
INFO - 2024-10-28 08:14:25 --> Hooks Class Initialized
DEBUG - 2024-10-28 08:14:25 --> UTF-8 Support Enabled
INFO - 2024-10-28 08:14:25 --> Utf8 Class Initialized
INFO - 2024-10-28 08:14:25 --> URI Class Initialized
INFO - 2024-10-28 08:14:25 --> Router Class Initialized
INFO - 2024-10-28 08:14:25 --> Output Class Initialized
INFO - 2024-10-28 08:14:25 --> Security Class Initialized
DEBUG - 2024-10-28 08:14:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-28 08:14:25 --> Input Class Initialized
INFO - 2024-10-28 08:14:25 --> Language Class Initialized
INFO - 2024-10-28 08:14:25 --> Language Class Initialized
INFO - 2024-10-28 08:14:25 --> Config Class Initialized
INFO - 2024-10-28 08:14:25 --> Loader Class Initialized
INFO - 2024-10-28 08:14:25 --> Helper loaded: url_helper
INFO - 2024-10-28 08:14:25 --> Helper loaded: file_helper
INFO - 2024-10-28 08:14:25 --> Helper loaded: form_helper
INFO - 2024-10-28 08:14:25 --> Helper loaded: my_helper
INFO - 2024-10-28 08:14:25 --> Database Driver Class Initialized
INFO - 2024-10-28 08:14:25 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-28 08:14:25 --> Controller Class Initialized
INFO - 2024-10-28 08:14:26 --> Config Class Initialized
INFO - 2024-10-28 08:14:26 --> Hooks Class Initialized
DEBUG - 2024-10-28 08:14:26 --> UTF-8 Support Enabled
INFO - 2024-10-28 08:14:26 --> Utf8 Class Initialized
INFO - 2024-10-28 08:14:26 --> URI Class Initialized
INFO - 2024-10-28 08:14:26 --> Router Class Initialized
INFO - 2024-10-28 08:14:26 --> Output Class Initialized
INFO - 2024-10-28 08:14:26 --> Security Class Initialized
DEBUG - 2024-10-28 08:14:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-28 08:14:26 --> Input Class Initialized
INFO - 2024-10-28 08:14:26 --> Language Class Initialized
INFO - 2024-10-28 08:14:26 --> Language Class Initialized
INFO - 2024-10-28 08:14:26 --> Config Class Initialized
INFO - 2024-10-28 08:14:26 --> Loader Class Initialized
INFO - 2024-10-28 08:14:26 --> Helper loaded: url_helper
INFO - 2024-10-28 08:14:26 --> Helper loaded: file_helper
INFO - 2024-10-28 08:14:26 --> Helper loaded: form_helper
INFO - 2024-10-28 08:14:26 --> Helper loaded: my_helper
INFO - 2024-10-28 08:14:27 --> Database Driver Class Initialized
INFO - 2024-10-28 08:14:27 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-28 08:14:27 --> Controller Class Initialized
ERROR - 2024-10-28 08:14:27 --> Severity: Notice --> Undefined variable: status_form /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/data_siswa/views/form.php 231
DEBUG - 2024-10-28 08:14:27 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/data_siswa/views/form.php
DEBUG - 2024-10-28 08:14:27 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-10-28 08:14:27 --> Final output sent to browser
DEBUG - 2024-10-28 08:14:27 --> Total execution time: 0.0352
INFO - 2024-10-28 08:15:35 --> Config Class Initialized
INFO - 2024-10-28 08:15:35 --> Hooks Class Initialized
DEBUG - 2024-10-28 08:15:35 --> UTF-8 Support Enabled
INFO - 2024-10-28 08:15:35 --> Utf8 Class Initialized
INFO - 2024-10-28 08:15:35 --> URI Class Initialized
INFO - 2024-10-28 08:15:35 --> Router Class Initialized
INFO - 2024-10-28 08:15:35 --> Output Class Initialized
INFO - 2024-10-28 08:15:35 --> Security Class Initialized
DEBUG - 2024-10-28 08:15:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-28 08:15:35 --> Input Class Initialized
INFO - 2024-10-28 08:15:35 --> Language Class Initialized
INFO - 2024-10-28 08:15:35 --> Language Class Initialized
INFO - 2024-10-28 08:15:35 --> Config Class Initialized
INFO - 2024-10-28 08:15:35 --> Loader Class Initialized
INFO - 2024-10-28 08:15:35 --> Helper loaded: url_helper
INFO - 2024-10-28 08:15:35 --> Helper loaded: file_helper
INFO - 2024-10-28 08:15:35 --> Helper loaded: form_helper
INFO - 2024-10-28 08:15:35 --> Helper loaded: my_helper
INFO - 2024-10-28 08:15:35 --> Database Driver Class Initialized
INFO - 2024-10-28 08:15:35 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-28 08:15:35 --> Controller Class Initialized
INFO - 2024-10-28 08:15:35 --> Upload Class Initialized
INFO - 2024-10-28 08:15:35 --> Language file loaded: language/english/upload_lang.php
ERROR - 2024-10-28 08:15:35 --> The upload path does not appear to be valid.
INFO - 2024-10-28 08:15:35 --> Config Class Initialized
INFO - 2024-10-28 08:15:35 --> Hooks Class Initialized
DEBUG - 2024-10-28 08:15:35 --> UTF-8 Support Enabled
INFO - 2024-10-28 08:15:35 --> Utf8 Class Initialized
INFO - 2024-10-28 08:15:35 --> URI Class Initialized
INFO - 2024-10-28 08:15:35 --> Router Class Initialized
INFO - 2024-10-28 08:15:35 --> Output Class Initialized
INFO - 2024-10-28 08:15:35 --> Security Class Initialized
DEBUG - 2024-10-28 08:15:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-28 08:15:35 --> Input Class Initialized
INFO - 2024-10-28 08:15:35 --> Language Class Initialized
INFO - 2024-10-28 08:15:35 --> Language Class Initialized
INFO - 2024-10-28 08:15:35 --> Config Class Initialized
INFO - 2024-10-28 08:15:35 --> Loader Class Initialized
INFO - 2024-10-28 08:15:35 --> Helper loaded: url_helper
INFO - 2024-10-28 08:15:35 --> Helper loaded: file_helper
INFO - 2024-10-28 08:15:35 --> Helper loaded: form_helper
INFO - 2024-10-28 08:15:35 --> Helper loaded: my_helper
INFO - 2024-10-28 08:15:35 --> Database Driver Class Initialized
INFO - 2024-10-28 08:15:35 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-28 08:15:35 --> Controller Class Initialized
DEBUG - 2024-10-28 08:15:35 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/data_siswa/views/list.php
DEBUG - 2024-10-28 08:15:35 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-10-28 08:15:35 --> Final output sent to browser
DEBUG - 2024-10-28 08:15:35 --> Total execution time: 0.0272
INFO - 2024-10-28 08:15:35 --> Config Class Initialized
INFO - 2024-10-28 08:15:35 --> Hooks Class Initialized
DEBUG - 2024-10-28 08:15:35 --> UTF-8 Support Enabled
INFO - 2024-10-28 08:15:35 --> Utf8 Class Initialized
INFO - 2024-10-28 08:15:35 --> URI Class Initialized
INFO - 2024-10-28 08:15:35 --> Router Class Initialized
INFO - 2024-10-28 08:15:35 --> Output Class Initialized
INFO - 2024-10-28 08:15:35 --> Security Class Initialized
DEBUG - 2024-10-28 08:15:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-28 08:15:35 --> Input Class Initialized
INFO - 2024-10-28 08:15:35 --> Language Class Initialized
ERROR - 2024-10-28 08:15:35 --> 404 Page Not Found: /index
INFO - 2024-10-28 08:15:35 --> Config Class Initialized
INFO - 2024-10-28 08:15:35 --> Hooks Class Initialized
DEBUG - 2024-10-28 08:15:35 --> UTF-8 Support Enabled
INFO - 2024-10-28 08:15:35 --> Utf8 Class Initialized
INFO - 2024-10-28 08:15:35 --> URI Class Initialized
INFO - 2024-10-28 08:15:35 --> Router Class Initialized
INFO - 2024-10-28 08:15:35 --> Output Class Initialized
INFO - 2024-10-28 08:15:35 --> Security Class Initialized
DEBUG - 2024-10-28 08:15:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-28 08:15:35 --> Input Class Initialized
INFO - 2024-10-28 08:15:35 --> Language Class Initialized
INFO - 2024-10-28 08:15:35 --> Language Class Initialized
INFO - 2024-10-28 08:15:35 --> Config Class Initialized
INFO - 2024-10-28 08:15:35 --> Loader Class Initialized
INFO - 2024-10-28 08:15:35 --> Helper loaded: url_helper
INFO - 2024-10-28 08:15:35 --> Helper loaded: file_helper
INFO - 2024-10-28 08:15:35 --> Helper loaded: form_helper
INFO - 2024-10-28 08:15:35 --> Helper loaded: my_helper
INFO - 2024-10-28 08:15:35 --> Database Driver Class Initialized
INFO - 2024-10-28 08:15:35 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-28 08:15:35 --> Controller Class Initialized
INFO - 2024-10-28 08:15:40 --> Config Class Initialized
INFO - 2024-10-28 08:15:40 --> Hooks Class Initialized
DEBUG - 2024-10-28 08:15:40 --> UTF-8 Support Enabled
INFO - 2024-10-28 08:15:40 --> Utf8 Class Initialized
INFO - 2024-10-28 08:15:40 --> URI Class Initialized
INFO - 2024-10-28 08:15:40 --> Router Class Initialized
INFO - 2024-10-28 08:15:40 --> Output Class Initialized
INFO - 2024-10-28 08:15:40 --> Security Class Initialized
DEBUG - 2024-10-28 08:15:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-28 08:15:40 --> Input Class Initialized
INFO - 2024-10-28 08:15:40 --> Language Class Initialized
INFO - 2024-10-28 08:15:40 --> Language Class Initialized
INFO - 2024-10-28 08:15:40 --> Config Class Initialized
INFO - 2024-10-28 08:15:40 --> Loader Class Initialized
INFO - 2024-10-28 08:15:40 --> Helper loaded: url_helper
INFO - 2024-10-28 08:15:40 --> Helper loaded: file_helper
INFO - 2024-10-28 08:15:40 --> Helper loaded: form_helper
INFO - 2024-10-28 08:15:40 --> Helper loaded: my_helper
INFO - 2024-10-28 08:15:40 --> Database Driver Class Initialized
INFO - 2024-10-28 08:15:40 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-28 08:15:40 --> Controller Class Initialized
INFO - 2024-10-28 08:15:40 --> Config Class Initialized
INFO - 2024-10-28 08:15:40 --> Hooks Class Initialized
DEBUG - 2024-10-28 08:15:40 --> UTF-8 Support Enabled
INFO - 2024-10-28 08:15:40 --> Utf8 Class Initialized
INFO - 2024-10-28 08:15:40 --> URI Class Initialized
INFO - 2024-10-28 08:15:40 --> Router Class Initialized
INFO - 2024-10-28 08:15:40 --> Output Class Initialized
INFO - 2024-10-28 08:15:40 --> Security Class Initialized
DEBUG - 2024-10-28 08:15:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-28 08:15:40 --> Input Class Initialized
INFO - 2024-10-28 08:15:40 --> Language Class Initialized
INFO - 2024-10-28 08:15:40 --> Language Class Initialized
INFO - 2024-10-28 08:15:40 --> Config Class Initialized
INFO - 2024-10-28 08:15:40 --> Loader Class Initialized
INFO - 2024-10-28 08:15:40 --> Helper loaded: url_helper
INFO - 2024-10-28 08:15:40 --> Helper loaded: file_helper
INFO - 2024-10-28 08:15:40 --> Helper loaded: form_helper
INFO - 2024-10-28 08:15:40 --> Helper loaded: my_helper
INFO - 2024-10-28 08:15:40 --> Database Driver Class Initialized
INFO - 2024-10-28 08:15:40 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-28 08:15:40 --> Controller Class Initialized
INFO - 2024-10-28 08:15:41 --> Config Class Initialized
INFO - 2024-10-28 08:15:41 --> Hooks Class Initialized
DEBUG - 2024-10-28 08:15:41 --> UTF-8 Support Enabled
INFO - 2024-10-28 08:15:41 --> Utf8 Class Initialized
INFO - 2024-10-28 08:15:41 --> URI Class Initialized
INFO - 2024-10-28 08:15:41 --> Router Class Initialized
INFO - 2024-10-28 08:15:41 --> Output Class Initialized
INFO - 2024-10-28 08:15:41 --> Security Class Initialized
DEBUG - 2024-10-28 08:15:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-28 08:15:41 --> Input Class Initialized
INFO - 2024-10-28 08:15:41 --> Language Class Initialized
INFO - 2024-10-28 08:15:41 --> Language Class Initialized
INFO - 2024-10-28 08:15:41 --> Config Class Initialized
INFO - 2024-10-28 08:15:41 --> Loader Class Initialized
INFO - 2024-10-28 08:15:41 --> Helper loaded: url_helper
INFO - 2024-10-28 08:15:41 --> Helper loaded: file_helper
INFO - 2024-10-28 08:15:41 --> Helper loaded: form_helper
INFO - 2024-10-28 08:15:41 --> Helper loaded: my_helper
INFO - 2024-10-28 08:15:41 --> Database Driver Class Initialized
INFO - 2024-10-28 08:15:41 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-28 08:15:41 --> Controller Class Initialized
INFO - 2024-10-28 08:15:47 --> Config Class Initialized
INFO - 2024-10-28 08:15:47 --> Hooks Class Initialized
DEBUG - 2024-10-28 08:15:47 --> UTF-8 Support Enabled
INFO - 2024-10-28 08:15:47 --> Utf8 Class Initialized
INFO - 2024-10-28 08:15:47 --> URI Class Initialized
INFO - 2024-10-28 08:15:47 --> Router Class Initialized
INFO - 2024-10-28 08:15:47 --> Output Class Initialized
INFO - 2024-10-28 08:15:47 --> Security Class Initialized
DEBUG - 2024-10-28 08:15:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-28 08:15:47 --> Input Class Initialized
INFO - 2024-10-28 08:15:47 --> Language Class Initialized
INFO - 2024-10-28 08:15:47 --> Language Class Initialized
INFO - 2024-10-28 08:15:47 --> Config Class Initialized
INFO - 2024-10-28 08:15:47 --> Loader Class Initialized
INFO - 2024-10-28 08:15:47 --> Helper loaded: url_helper
INFO - 2024-10-28 08:15:47 --> Helper loaded: file_helper
INFO - 2024-10-28 08:15:47 --> Helper loaded: form_helper
INFO - 2024-10-28 08:15:47 --> Helper loaded: my_helper
INFO - 2024-10-28 08:15:47 --> Database Driver Class Initialized
INFO - 2024-10-28 08:15:47 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-28 08:15:47 --> Controller Class Initialized
ERROR - 2024-10-28 08:15:47 --> Severity: Notice --> Undefined variable: status_form /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/data_siswa/views/form.php 231
DEBUG - 2024-10-28 08:15:47 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/data_siswa/views/form.php
DEBUG - 2024-10-28 08:15:47 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-10-28 08:15:47 --> Final output sent to browser
DEBUG - 2024-10-28 08:15:47 --> Total execution time: 0.0358
INFO - 2024-10-28 08:16:04 --> Config Class Initialized
INFO - 2024-10-28 08:16:04 --> Hooks Class Initialized
DEBUG - 2024-10-28 08:16:04 --> UTF-8 Support Enabled
INFO - 2024-10-28 08:16:04 --> Utf8 Class Initialized
INFO - 2024-10-28 08:16:04 --> URI Class Initialized
INFO - 2024-10-28 08:16:04 --> Router Class Initialized
INFO - 2024-10-28 08:16:04 --> Output Class Initialized
INFO - 2024-10-28 08:16:04 --> Security Class Initialized
DEBUG - 2024-10-28 08:16:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-28 08:16:04 --> Input Class Initialized
INFO - 2024-10-28 08:16:04 --> Language Class Initialized
INFO - 2024-10-28 08:16:04 --> Language Class Initialized
INFO - 2024-10-28 08:16:04 --> Config Class Initialized
INFO - 2024-10-28 08:16:04 --> Loader Class Initialized
INFO - 2024-10-28 08:16:04 --> Helper loaded: url_helper
INFO - 2024-10-28 08:16:04 --> Helper loaded: file_helper
INFO - 2024-10-28 08:16:04 --> Helper loaded: form_helper
INFO - 2024-10-28 08:16:04 --> Helper loaded: my_helper
INFO - 2024-10-28 08:16:04 --> Database Driver Class Initialized
INFO - 2024-10-28 08:16:04 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-28 08:16:04 --> Controller Class Initialized
INFO - 2024-10-28 08:16:04 --> Upload Class Initialized
INFO - 2024-10-28 08:16:04 --> Language file loaded: language/english/upload_lang.php
ERROR - 2024-10-28 08:16:04 --> The upload path does not appear to be valid.
INFO - 2024-10-28 08:16:04 --> Config Class Initialized
INFO - 2024-10-28 08:16:04 --> Hooks Class Initialized
DEBUG - 2024-10-28 08:16:04 --> UTF-8 Support Enabled
INFO - 2024-10-28 08:16:04 --> Utf8 Class Initialized
INFO - 2024-10-28 08:16:04 --> URI Class Initialized
INFO - 2024-10-28 08:16:04 --> Router Class Initialized
INFO - 2024-10-28 08:16:04 --> Output Class Initialized
INFO - 2024-10-28 08:16:04 --> Security Class Initialized
DEBUG - 2024-10-28 08:16:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-28 08:16:04 --> Input Class Initialized
INFO - 2024-10-28 08:16:04 --> Language Class Initialized
INFO - 2024-10-28 08:16:04 --> Language Class Initialized
INFO - 2024-10-28 08:16:04 --> Config Class Initialized
INFO - 2024-10-28 08:16:04 --> Loader Class Initialized
INFO - 2024-10-28 08:16:04 --> Helper loaded: url_helper
INFO - 2024-10-28 08:16:04 --> Helper loaded: file_helper
INFO - 2024-10-28 08:16:04 --> Helper loaded: form_helper
INFO - 2024-10-28 08:16:04 --> Helper loaded: my_helper
INFO - 2024-10-28 08:16:04 --> Database Driver Class Initialized
INFO - 2024-10-28 08:16:04 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-28 08:16:04 --> Controller Class Initialized
DEBUG - 2024-10-28 08:16:04 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/data_siswa/views/list.php
DEBUG - 2024-10-28 08:16:04 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-10-28 08:16:04 --> Final output sent to browser
DEBUG - 2024-10-28 08:16:04 --> Total execution time: 0.0318
INFO - 2024-10-28 08:16:05 --> Config Class Initialized
INFO - 2024-10-28 08:16:05 --> Hooks Class Initialized
DEBUG - 2024-10-28 08:16:05 --> UTF-8 Support Enabled
INFO - 2024-10-28 08:16:05 --> Utf8 Class Initialized
INFO - 2024-10-28 08:16:05 --> URI Class Initialized
INFO - 2024-10-28 08:16:05 --> Router Class Initialized
INFO - 2024-10-28 08:16:05 --> Output Class Initialized
INFO - 2024-10-28 08:16:05 --> Security Class Initialized
DEBUG - 2024-10-28 08:16:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-28 08:16:05 --> Input Class Initialized
INFO - 2024-10-28 08:16:05 --> Language Class Initialized
ERROR - 2024-10-28 08:16:05 --> 404 Page Not Found: /index
INFO - 2024-10-28 08:16:05 --> Config Class Initialized
INFO - 2024-10-28 08:16:05 --> Hooks Class Initialized
DEBUG - 2024-10-28 08:16:05 --> UTF-8 Support Enabled
INFO - 2024-10-28 08:16:05 --> Utf8 Class Initialized
INFO - 2024-10-28 08:16:05 --> URI Class Initialized
INFO - 2024-10-28 08:16:05 --> Router Class Initialized
INFO - 2024-10-28 08:16:05 --> Output Class Initialized
INFO - 2024-10-28 08:16:05 --> Security Class Initialized
DEBUG - 2024-10-28 08:16:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-28 08:16:05 --> Input Class Initialized
INFO - 2024-10-28 08:16:05 --> Language Class Initialized
INFO - 2024-10-28 08:16:05 --> Language Class Initialized
INFO - 2024-10-28 08:16:05 --> Config Class Initialized
INFO - 2024-10-28 08:16:05 --> Loader Class Initialized
INFO - 2024-10-28 08:16:05 --> Helper loaded: url_helper
INFO - 2024-10-28 08:16:05 --> Helper loaded: file_helper
INFO - 2024-10-28 08:16:05 --> Helper loaded: form_helper
INFO - 2024-10-28 08:16:05 --> Helper loaded: my_helper
INFO - 2024-10-28 08:16:05 --> Database Driver Class Initialized
INFO - 2024-10-28 08:16:05 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-28 08:16:05 --> Controller Class Initialized
INFO - 2024-10-28 08:16:12 --> Config Class Initialized
INFO - 2024-10-28 08:16:12 --> Hooks Class Initialized
DEBUG - 2024-10-28 08:16:12 --> UTF-8 Support Enabled
INFO - 2024-10-28 08:16:12 --> Utf8 Class Initialized
INFO - 2024-10-28 08:16:12 --> URI Class Initialized
INFO - 2024-10-28 08:16:12 --> Router Class Initialized
INFO - 2024-10-28 08:16:12 --> Output Class Initialized
INFO - 2024-10-28 08:16:12 --> Security Class Initialized
DEBUG - 2024-10-28 08:16:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-28 08:16:12 --> Input Class Initialized
INFO - 2024-10-28 08:16:12 --> Language Class Initialized
INFO - 2024-10-28 08:16:12 --> Language Class Initialized
INFO - 2024-10-28 08:16:12 --> Config Class Initialized
INFO - 2024-10-28 08:16:12 --> Loader Class Initialized
INFO - 2024-10-28 08:16:12 --> Helper loaded: url_helper
INFO - 2024-10-28 08:16:12 --> Helper loaded: file_helper
INFO - 2024-10-28 08:16:12 --> Helper loaded: form_helper
INFO - 2024-10-28 08:16:12 --> Helper loaded: my_helper
INFO - 2024-10-28 08:16:12 --> Database Driver Class Initialized
INFO - 2024-10-28 08:16:12 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-28 08:16:12 --> Controller Class Initialized
INFO - 2024-10-28 08:16:12 --> Config Class Initialized
INFO - 2024-10-28 08:16:12 --> Hooks Class Initialized
DEBUG - 2024-10-28 08:16:12 --> UTF-8 Support Enabled
INFO - 2024-10-28 08:16:12 --> Utf8 Class Initialized
INFO - 2024-10-28 08:16:12 --> URI Class Initialized
INFO - 2024-10-28 08:16:12 --> Router Class Initialized
INFO - 2024-10-28 08:16:12 --> Output Class Initialized
INFO - 2024-10-28 08:16:12 --> Security Class Initialized
DEBUG - 2024-10-28 08:16:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-28 08:16:12 --> Input Class Initialized
INFO - 2024-10-28 08:16:12 --> Language Class Initialized
INFO - 2024-10-28 08:16:12 --> Language Class Initialized
INFO - 2024-10-28 08:16:12 --> Config Class Initialized
INFO - 2024-10-28 08:16:12 --> Loader Class Initialized
INFO - 2024-10-28 08:16:12 --> Helper loaded: url_helper
INFO - 2024-10-28 08:16:12 --> Helper loaded: file_helper
INFO - 2024-10-28 08:16:12 --> Helper loaded: form_helper
INFO - 2024-10-28 08:16:12 --> Helper loaded: my_helper
INFO - 2024-10-28 08:16:12 --> Database Driver Class Initialized
INFO - 2024-10-28 08:16:12 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-28 08:16:12 --> Controller Class Initialized
INFO - 2024-10-28 08:16:13 --> Config Class Initialized
INFO - 2024-10-28 08:16:13 --> Hooks Class Initialized
DEBUG - 2024-10-28 08:16:13 --> UTF-8 Support Enabled
INFO - 2024-10-28 08:16:13 --> Utf8 Class Initialized
INFO - 2024-10-28 08:16:13 --> URI Class Initialized
INFO - 2024-10-28 08:16:13 --> Router Class Initialized
INFO - 2024-10-28 08:16:13 --> Output Class Initialized
INFO - 2024-10-28 08:16:13 --> Security Class Initialized
DEBUG - 2024-10-28 08:16:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-28 08:16:13 --> Input Class Initialized
INFO - 2024-10-28 08:16:13 --> Language Class Initialized
INFO - 2024-10-28 08:16:13 --> Language Class Initialized
INFO - 2024-10-28 08:16:13 --> Config Class Initialized
INFO - 2024-10-28 08:16:13 --> Loader Class Initialized
INFO - 2024-10-28 08:16:13 --> Helper loaded: url_helper
INFO - 2024-10-28 08:16:13 --> Helper loaded: file_helper
INFO - 2024-10-28 08:16:13 --> Helper loaded: form_helper
INFO - 2024-10-28 08:16:13 --> Helper loaded: my_helper
INFO - 2024-10-28 08:16:13 --> Database Driver Class Initialized
INFO - 2024-10-28 08:16:13 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-28 08:16:13 --> Controller Class Initialized
INFO - 2024-10-28 08:16:14 --> Config Class Initialized
INFO - 2024-10-28 08:16:14 --> Hooks Class Initialized
DEBUG - 2024-10-28 08:16:14 --> UTF-8 Support Enabled
INFO - 2024-10-28 08:16:14 --> Utf8 Class Initialized
INFO - 2024-10-28 08:16:14 --> URI Class Initialized
INFO - 2024-10-28 08:16:14 --> Router Class Initialized
INFO - 2024-10-28 08:16:14 --> Output Class Initialized
INFO - 2024-10-28 08:16:14 --> Security Class Initialized
DEBUG - 2024-10-28 08:16:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-28 08:16:14 --> Input Class Initialized
INFO - 2024-10-28 08:16:14 --> Language Class Initialized
INFO - 2024-10-28 08:16:14 --> Language Class Initialized
INFO - 2024-10-28 08:16:14 --> Config Class Initialized
INFO - 2024-10-28 08:16:14 --> Loader Class Initialized
INFO - 2024-10-28 08:16:14 --> Helper loaded: url_helper
INFO - 2024-10-28 08:16:14 --> Helper loaded: file_helper
INFO - 2024-10-28 08:16:14 --> Helper loaded: form_helper
INFO - 2024-10-28 08:16:14 --> Helper loaded: my_helper
INFO - 2024-10-28 08:16:14 --> Database Driver Class Initialized
INFO - 2024-10-28 08:16:14 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-28 08:16:14 --> Controller Class Initialized
ERROR - 2024-10-28 08:16:14 --> Severity: Notice --> Undefined variable: status_form /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/data_siswa/views/form.php 231
DEBUG - 2024-10-28 08:16:14 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/data_siswa/views/form.php
DEBUG - 2024-10-28 08:16:14 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-10-28 08:16:14 --> Final output sent to browser
DEBUG - 2024-10-28 08:16:14 --> Total execution time: 0.0306
INFO - 2024-10-28 08:17:05 --> Config Class Initialized
INFO - 2024-10-28 08:17:05 --> Hooks Class Initialized
DEBUG - 2024-10-28 08:17:05 --> UTF-8 Support Enabled
INFO - 2024-10-28 08:17:05 --> Utf8 Class Initialized
INFO - 2024-10-28 08:17:05 --> URI Class Initialized
INFO - 2024-10-28 08:17:05 --> Router Class Initialized
INFO - 2024-10-28 08:17:05 --> Output Class Initialized
INFO - 2024-10-28 08:17:05 --> Security Class Initialized
DEBUG - 2024-10-28 08:17:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-28 08:17:05 --> Input Class Initialized
INFO - 2024-10-28 08:17:05 --> Language Class Initialized
INFO - 2024-10-28 08:17:05 --> Language Class Initialized
INFO - 2024-10-28 08:17:05 --> Config Class Initialized
INFO - 2024-10-28 08:17:05 --> Loader Class Initialized
INFO - 2024-10-28 08:17:05 --> Helper loaded: url_helper
INFO - 2024-10-28 08:17:05 --> Helper loaded: file_helper
INFO - 2024-10-28 08:17:05 --> Helper loaded: form_helper
INFO - 2024-10-28 08:17:05 --> Helper loaded: my_helper
INFO - 2024-10-28 08:17:05 --> Database Driver Class Initialized
INFO - 2024-10-28 08:17:05 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-28 08:17:05 --> Controller Class Initialized
INFO - 2024-10-28 08:17:05 --> Upload Class Initialized
INFO - 2024-10-28 08:17:05 --> Language file loaded: language/english/upload_lang.php
ERROR - 2024-10-28 08:17:05 --> The upload path does not appear to be valid.
INFO - 2024-10-28 08:17:05 --> Config Class Initialized
INFO - 2024-10-28 08:17:05 --> Hooks Class Initialized
DEBUG - 2024-10-28 08:17:05 --> UTF-8 Support Enabled
INFO - 2024-10-28 08:17:05 --> Utf8 Class Initialized
INFO - 2024-10-28 08:17:05 --> URI Class Initialized
INFO - 2024-10-28 08:17:05 --> Router Class Initialized
INFO - 2024-10-28 08:17:05 --> Output Class Initialized
INFO - 2024-10-28 08:17:05 --> Security Class Initialized
DEBUG - 2024-10-28 08:17:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-28 08:17:05 --> Input Class Initialized
INFO - 2024-10-28 08:17:05 --> Language Class Initialized
INFO - 2024-10-28 08:17:05 --> Language Class Initialized
INFO - 2024-10-28 08:17:05 --> Config Class Initialized
INFO - 2024-10-28 08:17:05 --> Loader Class Initialized
INFO - 2024-10-28 08:17:05 --> Helper loaded: url_helper
INFO - 2024-10-28 08:17:05 --> Helper loaded: file_helper
INFO - 2024-10-28 08:17:05 --> Helper loaded: form_helper
INFO - 2024-10-28 08:17:05 --> Helper loaded: my_helper
INFO - 2024-10-28 08:17:05 --> Database Driver Class Initialized
INFO - 2024-10-28 08:17:05 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-28 08:17:05 --> Controller Class Initialized
DEBUG - 2024-10-28 08:17:05 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/data_siswa/views/list.php
DEBUG - 2024-10-28 08:17:05 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-10-28 08:17:05 --> Final output sent to browser
DEBUG - 2024-10-28 08:17:05 --> Total execution time: 0.0298
INFO - 2024-10-28 08:17:05 --> Config Class Initialized
INFO - 2024-10-28 08:17:05 --> Hooks Class Initialized
DEBUG - 2024-10-28 08:17:05 --> UTF-8 Support Enabled
INFO - 2024-10-28 08:17:05 --> Utf8 Class Initialized
INFO - 2024-10-28 08:17:05 --> URI Class Initialized
INFO - 2024-10-28 08:17:05 --> Router Class Initialized
INFO - 2024-10-28 08:17:05 --> Output Class Initialized
INFO - 2024-10-28 08:17:05 --> Security Class Initialized
DEBUG - 2024-10-28 08:17:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-28 08:17:05 --> Input Class Initialized
INFO - 2024-10-28 08:17:05 --> Language Class Initialized
ERROR - 2024-10-28 08:17:05 --> 404 Page Not Found: /index
INFO - 2024-10-28 08:17:05 --> Config Class Initialized
INFO - 2024-10-28 08:17:05 --> Hooks Class Initialized
DEBUG - 2024-10-28 08:17:05 --> UTF-8 Support Enabled
INFO - 2024-10-28 08:17:05 --> Utf8 Class Initialized
INFO - 2024-10-28 08:17:05 --> URI Class Initialized
INFO - 2024-10-28 08:17:05 --> Router Class Initialized
INFO - 2024-10-28 08:17:05 --> Output Class Initialized
INFO - 2024-10-28 08:17:05 --> Security Class Initialized
DEBUG - 2024-10-28 08:17:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-28 08:17:05 --> Input Class Initialized
INFO - 2024-10-28 08:17:05 --> Language Class Initialized
INFO - 2024-10-28 08:17:05 --> Language Class Initialized
INFO - 2024-10-28 08:17:05 --> Config Class Initialized
INFO - 2024-10-28 08:17:05 --> Loader Class Initialized
INFO - 2024-10-28 08:17:05 --> Helper loaded: url_helper
INFO - 2024-10-28 08:17:05 --> Helper loaded: file_helper
INFO - 2024-10-28 08:17:05 --> Helper loaded: form_helper
INFO - 2024-10-28 08:17:05 --> Helper loaded: my_helper
INFO - 2024-10-28 08:17:05 --> Database Driver Class Initialized
INFO - 2024-10-28 08:17:05 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-28 08:17:05 --> Controller Class Initialized
INFO - 2024-10-28 08:17:28 --> Config Class Initialized
INFO - 2024-10-28 08:17:28 --> Hooks Class Initialized
DEBUG - 2024-10-28 08:17:28 --> UTF-8 Support Enabled
INFO - 2024-10-28 08:17:28 --> Utf8 Class Initialized
INFO - 2024-10-28 08:17:28 --> URI Class Initialized
INFO - 2024-10-28 08:17:28 --> Router Class Initialized
INFO - 2024-10-28 08:17:28 --> Output Class Initialized
INFO - 2024-10-28 08:17:28 --> Security Class Initialized
DEBUG - 2024-10-28 08:17:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-28 08:17:28 --> Input Class Initialized
INFO - 2024-10-28 08:17:28 --> Language Class Initialized
INFO - 2024-10-28 08:17:28 --> Language Class Initialized
INFO - 2024-10-28 08:17:28 --> Config Class Initialized
INFO - 2024-10-28 08:17:28 --> Loader Class Initialized
INFO - 2024-10-28 08:17:28 --> Helper loaded: url_helper
INFO - 2024-10-28 08:17:28 --> Helper loaded: file_helper
INFO - 2024-10-28 08:17:28 --> Helper loaded: form_helper
INFO - 2024-10-28 08:17:28 --> Helper loaded: my_helper
INFO - 2024-10-28 08:17:28 --> Database Driver Class Initialized
INFO - 2024-10-28 08:17:28 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-28 08:17:28 --> Controller Class Initialized
INFO - 2024-10-28 08:17:28 --> Config Class Initialized
INFO - 2024-10-28 08:17:28 --> Hooks Class Initialized
DEBUG - 2024-10-28 08:17:28 --> UTF-8 Support Enabled
INFO - 2024-10-28 08:17:28 --> Utf8 Class Initialized
INFO - 2024-10-28 08:17:28 --> URI Class Initialized
INFO - 2024-10-28 08:17:28 --> Router Class Initialized
INFO - 2024-10-28 08:17:28 --> Output Class Initialized
INFO - 2024-10-28 08:17:28 --> Security Class Initialized
DEBUG - 2024-10-28 08:17:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-28 08:17:28 --> Input Class Initialized
INFO - 2024-10-28 08:17:28 --> Language Class Initialized
INFO - 2024-10-28 08:17:28 --> Language Class Initialized
INFO - 2024-10-28 08:17:28 --> Config Class Initialized
INFO - 2024-10-28 08:17:28 --> Loader Class Initialized
INFO - 2024-10-28 08:17:28 --> Helper loaded: url_helper
INFO - 2024-10-28 08:17:28 --> Helper loaded: file_helper
INFO - 2024-10-28 08:17:28 --> Helper loaded: form_helper
INFO - 2024-10-28 08:17:28 --> Helper loaded: my_helper
INFO - 2024-10-28 08:17:28 --> Database Driver Class Initialized
INFO - 2024-10-28 08:17:28 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-28 08:17:28 --> Controller Class Initialized
INFO - 2024-10-28 08:17:30 --> Config Class Initialized
INFO - 2024-10-28 08:17:30 --> Hooks Class Initialized
DEBUG - 2024-10-28 08:17:30 --> UTF-8 Support Enabled
INFO - 2024-10-28 08:17:30 --> Utf8 Class Initialized
INFO - 2024-10-28 08:17:30 --> URI Class Initialized
INFO - 2024-10-28 08:17:30 --> Router Class Initialized
INFO - 2024-10-28 08:17:30 --> Output Class Initialized
INFO - 2024-10-28 08:17:30 --> Security Class Initialized
DEBUG - 2024-10-28 08:17:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-28 08:17:30 --> Input Class Initialized
INFO - 2024-10-28 08:17:30 --> Language Class Initialized
INFO - 2024-10-28 08:17:30 --> Language Class Initialized
INFO - 2024-10-28 08:17:30 --> Config Class Initialized
INFO - 2024-10-28 08:17:30 --> Loader Class Initialized
INFO - 2024-10-28 08:17:30 --> Helper loaded: url_helper
INFO - 2024-10-28 08:17:30 --> Helper loaded: file_helper
INFO - 2024-10-28 08:17:30 --> Helper loaded: form_helper
INFO - 2024-10-28 08:17:30 --> Helper loaded: my_helper
INFO - 2024-10-28 08:17:30 --> Database Driver Class Initialized
INFO - 2024-10-28 08:17:30 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-28 08:17:30 --> Controller Class Initialized
ERROR - 2024-10-28 08:17:30 --> Severity: Notice --> Undefined variable: status_form /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/data_siswa/views/form.php 231
DEBUG - 2024-10-28 08:17:30 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/data_siswa/views/form.php
DEBUG - 2024-10-28 08:17:30 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-10-28 08:17:30 --> Final output sent to browser
DEBUG - 2024-10-28 08:17:30 --> Total execution time: 0.0278
INFO - 2024-10-28 08:17:55 --> Config Class Initialized
INFO - 2024-10-28 08:17:55 --> Hooks Class Initialized
DEBUG - 2024-10-28 08:17:55 --> UTF-8 Support Enabled
INFO - 2024-10-28 08:17:55 --> Utf8 Class Initialized
INFO - 2024-10-28 08:17:55 --> URI Class Initialized
INFO - 2024-10-28 08:17:55 --> Router Class Initialized
INFO - 2024-10-28 08:17:55 --> Output Class Initialized
INFO - 2024-10-28 08:17:55 --> Security Class Initialized
DEBUG - 2024-10-28 08:17:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-28 08:17:55 --> Input Class Initialized
INFO - 2024-10-28 08:17:55 --> Language Class Initialized
INFO - 2024-10-28 08:17:55 --> Language Class Initialized
INFO - 2024-10-28 08:17:55 --> Config Class Initialized
INFO - 2024-10-28 08:17:55 --> Loader Class Initialized
INFO - 2024-10-28 08:17:55 --> Helper loaded: url_helper
INFO - 2024-10-28 08:17:55 --> Helper loaded: file_helper
INFO - 2024-10-28 08:17:55 --> Helper loaded: form_helper
INFO - 2024-10-28 08:17:55 --> Helper loaded: my_helper
INFO - 2024-10-28 08:17:55 --> Database Driver Class Initialized
INFO - 2024-10-28 08:17:55 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-28 08:17:55 --> Controller Class Initialized
INFO - 2024-10-28 08:17:55 --> Upload Class Initialized
INFO - 2024-10-28 08:17:55 --> Language file loaded: language/english/upload_lang.php
ERROR - 2024-10-28 08:17:55 --> The upload path does not appear to be valid.
INFO - 2024-10-28 08:17:55 --> Config Class Initialized
INFO - 2024-10-28 08:17:55 --> Hooks Class Initialized
DEBUG - 2024-10-28 08:17:55 --> UTF-8 Support Enabled
INFO - 2024-10-28 08:17:55 --> Utf8 Class Initialized
INFO - 2024-10-28 08:17:55 --> URI Class Initialized
INFO - 2024-10-28 08:17:55 --> Router Class Initialized
INFO - 2024-10-28 08:17:55 --> Output Class Initialized
INFO - 2024-10-28 08:17:55 --> Security Class Initialized
DEBUG - 2024-10-28 08:17:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-28 08:17:55 --> Input Class Initialized
INFO - 2024-10-28 08:17:55 --> Language Class Initialized
INFO - 2024-10-28 08:17:55 --> Language Class Initialized
INFO - 2024-10-28 08:17:55 --> Config Class Initialized
INFO - 2024-10-28 08:17:55 --> Loader Class Initialized
INFO - 2024-10-28 08:17:55 --> Helper loaded: url_helper
INFO - 2024-10-28 08:17:55 --> Helper loaded: file_helper
INFO - 2024-10-28 08:17:55 --> Helper loaded: form_helper
INFO - 2024-10-28 08:17:55 --> Helper loaded: my_helper
INFO - 2024-10-28 08:17:55 --> Database Driver Class Initialized
INFO - 2024-10-28 08:17:55 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-28 08:17:55 --> Controller Class Initialized
DEBUG - 2024-10-28 08:17:55 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/data_siswa/views/list.php
DEBUG - 2024-10-28 08:17:55 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-10-28 08:17:55 --> Final output sent to browser
DEBUG - 2024-10-28 08:17:55 --> Total execution time: 0.0251
INFO - 2024-10-28 08:17:55 --> Config Class Initialized
INFO - 2024-10-28 08:17:55 --> Hooks Class Initialized
DEBUG - 2024-10-28 08:17:55 --> UTF-8 Support Enabled
INFO - 2024-10-28 08:17:55 --> Utf8 Class Initialized
INFO - 2024-10-28 08:17:55 --> URI Class Initialized
INFO - 2024-10-28 08:17:55 --> Router Class Initialized
INFO - 2024-10-28 08:17:55 --> Output Class Initialized
INFO - 2024-10-28 08:17:55 --> Security Class Initialized
DEBUG - 2024-10-28 08:17:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-28 08:17:55 --> Input Class Initialized
INFO - 2024-10-28 08:17:55 --> Language Class Initialized
ERROR - 2024-10-28 08:17:55 --> 404 Page Not Found: /index
INFO - 2024-10-28 08:17:55 --> Config Class Initialized
INFO - 2024-10-28 08:17:55 --> Hooks Class Initialized
DEBUG - 2024-10-28 08:17:55 --> UTF-8 Support Enabled
INFO - 2024-10-28 08:17:55 --> Utf8 Class Initialized
INFO - 2024-10-28 08:17:55 --> URI Class Initialized
INFO - 2024-10-28 08:17:55 --> Router Class Initialized
INFO - 2024-10-28 08:17:55 --> Output Class Initialized
INFO - 2024-10-28 08:17:55 --> Security Class Initialized
DEBUG - 2024-10-28 08:17:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-28 08:17:55 --> Input Class Initialized
INFO - 2024-10-28 08:17:55 --> Language Class Initialized
INFO - 2024-10-28 08:17:55 --> Language Class Initialized
INFO - 2024-10-28 08:17:55 --> Config Class Initialized
INFO - 2024-10-28 08:17:55 --> Loader Class Initialized
INFO - 2024-10-28 08:17:55 --> Helper loaded: url_helper
INFO - 2024-10-28 08:17:55 --> Helper loaded: file_helper
INFO - 2024-10-28 08:17:55 --> Helper loaded: form_helper
INFO - 2024-10-28 08:17:55 --> Helper loaded: my_helper
INFO - 2024-10-28 08:17:55 --> Database Driver Class Initialized
INFO - 2024-10-28 08:17:55 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-28 08:17:55 --> Controller Class Initialized
INFO - 2024-10-28 08:20:06 --> Config Class Initialized
INFO - 2024-10-28 08:20:06 --> Hooks Class Initialized
DEBUG - 2024-10-28 08:20:06 --> UTF-8 Support Enabled
INFO - 2024-10-28 08:20:06 --> Utf8 Class Initialized
INFO - 2024-10-28 08:20:06 --> URI Class Initialized
DEBUG - 2024-10-28 08:20:06 --> No URI present. Default controller set.
INFO - 2024-10-28 08:20:06 --> Router Class Initialized
INFO - 2024-10-28 08:20:06 --> Output Class Initialized
INFO - 2024-10-28 08:20:06 --> Security Class Initialized
DEBUG - 2024-10-28 08:20:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-28 08:20:06 --> Input Class Initialized
INFO - 2024-10-28 08:20:06 --> Language Class Initialized
INFO - 2024-10-28 08:20:06 --> Language Class Initialized
INFO - 2024-10-28 08:20:06 --> Config Class Initialized
INFO - 2024-10-28 08:20:06 --> Loader Class Initialized
INFO - 2024-10-28 08:20:06 --> Helper loaded: url_helper
INFO - 2024-10-28 08:20:06 --> Helper loaded: file_helper
INFO - 2024-10-28 08:20:06 --> Helper loaded: form_helper
INFO - 2024-10-28 08:20:06 --> Helper loaded: my_helper
INFO - 2024-10-28 08:20:06 --> Database Driver Class Initialized
INFO - 2024-10-28 08:20:06 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-28 08:20:06 --> Controller Class Initialized
INFO - 2024-10-28 08:20:06 --> Config Class Initialized
INFO - 2024-10-28 08:20:06 --> Hooks Class Initialized
DEBUG - 2024-10-28 08:20:06 --> UTF-8 Support Enabled
INFO - 2024-10-28 08:20:06 --> Utf8 Class Initialized
INFO - 2024-10-28 08:20:06 --> URI Class Initialized
INFO - 2024-10-28 08:20:06 --> Router Class Initialized
INFO - 2024-10-28 08:20:06 --> Output Class Initialized
INFO - 2024-10-28 08:20:06 --> Security Class Initialized
DEBUG - 2024-10-28 08:20:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-28 08:20:06 --> Input Class Initialized
INFO - 2024-10-28 08:20:06 --> Language Class Initialized
INFO - 2024-10-28 08:20:06 --> Language Class Initialized
INFO - 2024-10-28 08:20:06 --> Config Class Initialized
INFO - 2024-10-28 08:20:06 --> Loader Class Initialized
INFO - 2024-10-28 08:20:06 --> Helper loaded: url_helper
INFO - 2024-10-28 08:20:06 --> Helper loaded: file_helper
INFO - 2024-10-28 08:20:06 --> Helper loaded: form_helper
INFO - 2024-10-28 08:20:06 --> Helper loaded: my_helper
INFO - 2024-10-28 08:20:06 --> Database Driver Class Initialized
INFO - 2024-10-28 08:20:06 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-28 08:20:06 --> Controller Class Initialized
DEBUG - 2024-10-28 08:20:06 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/login/views/login.php
DEBUG - 2024-10-28 08:20:06 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-10-28 08:20:06 --> Final output sent to browser
DEBUG - 2024-10-28 08:20:06 --> Total execution time: 0.0315
INFO - 2024-10-28 08:20:22 --> Config Class Initialized
INFO - 2024-10-28 08:20:22 --> Hooks Class Initialized
DEBUG - 2024-10-28 08:20:22 --> UTF-8 Support Enabled
INFO - 2024-10-28 08:20:22 --> Utf8 Class Initialized
INFO - 2024-10-28 08:20:22 --> URI Class Initialized
INFO - 2024-10-28 08:20:22 --> Router Class Initialized
INFO - 2024-10-28 08:20:22 --> Output Class Initialized
INFO - 2024-10-28 08:20:22 --> Security Class Initialized
DEBUG - 2024-10-28 08:20:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-28 08:20:22 --> Input Class Initialized
INFO - 2024-10-28 08:20:22 --> Language Class Initialized
INFO - 2024-10-28 08:20:22 --> Language Class Initialized
INFO - 2024-10-28 08:20:22 --> Config Class Initialized
INFO - 2024-10-28 08:20:22 --> Loader Class Initialized
INFO - 2024-10-28 08:20:22 --> Helper loaded: url_helper
INFO - 2024-10-28 08:20:22 --> Helper loaded: file_helper
INFO - 2024-10-28 08:20:22 --> Helper loaded: form_helper
INFO - 2024-10-28 08:20:22 --> Helper loaded: my_helper
INFO - 2024-10-28 08:20:22 --> Database Driver Class Initialized
INFO - 2024-10-28 08:20:22 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-28 08:20:22 --> Controller Class Initialized
INFO - 2024-10-28 08:20:22 --> Helper loaded: cookie_helper
INFO - 2024-10-28 08:20:22 --> Final output sent to browser
DEBUG - 2024-10-28 08:20:22 --> Total execution time: 0.0409
INFO - 2024-10-28 08:20:22 --> Config Class Initialized
INFO - 2024-10-28 08:20:22 --> Hooks Class Initialized
DEBUG - 2024-10-28 08:20:22 --> UTF-8 Support Enabled
INFO - 2024-10-28 08:20:22 --> Utf8 Class Initialized
INFO - 2024-10-28 08:20:22 --> URI Class Initialized
INFO - 2024-10-28 08:20:22 --> Router Class Initialized
INFO - 2024-10-28 08:20:22 --> Output Class Initialized
INFO - 2024-10-28 08:20:22 --> Security Class Initialized
DEBUG - 2024-10-28 08:20:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-28 08:20:22 --> Input Class Initialized
INFO - 2024-10-28 08:20:22 --> Language Class Initialized
INFO - 2024-10-28 08:20:22 --> Language Class Initialized
INFO - 2024-10-28 08:20:22 --> Config Class Initialized
INFO - 2024-10-28 08:20:22 --> Loader Class Initialized
INFO - 2024-10-28 08:20:22 --> Helper loaded: url_helper
INFO - 2024-10-28 08:20:22 --> Helper loaded: file_helper
INFO - 2024-10-28 08:20:22 --> Helper loaded: form_helper
INFO - 2024-10-28 08:20:22 --> Helper loaded: my_helper
INFO - 2024-10-28 08:20:22 --> Database Driver Class Initialized
INFO - 2024-10-28 08:20:22 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-28 08:20:22 --> Controller Class Initialized
DEBUG - 2024-10-28 08:20:22 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/home/views/v_home_guru.php
DEBUG - 2024-10-28 08:20:22 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-10-28 08:20:22 --> Final output sent to browser
DEBUG - 2024-10-28 08:20:22 --> Total execution time: 0.0408
INFO - 2024-10-28 08:23:52 --> Config Class Initialized
INFO - 2024-10-28 08:23:52 --> Hooks Class Initialized
DEBUG - 2024-10-28 08:23:52 --> UTF-8 Support Enabled
INFO - 2024-10-28 08:23:52 --> Utf8 Class Initialized
INFO - 2024-10-28 08:23:52 --> URI Class Initialized
INFO - 2024-10-28 08:23:52 --> Router Class Initialized
INFO - 2024-10-28 08:23:52 --> Output Class Initialized
INFO - 2024-10-28 08:23:52 --> Security Class Initialized
DEBUG - 2024-10-28 08:23:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-28 08:23:52 --> Input Class Initialized
INFO - 2024-10-28 08:23:52 --> Language Class Initialized
INFO - 2024-10-28 08:23:52 --> Language Class Initialized
INFO - 2024-10-28 08:23:52 --> Config Class Initialized
INFO - 2024-10-28 08:23:52 --> Loader Class Initialized
INFO - 2024-10-28 08:23:52 --> Helper loaded: url_helper
INFO - 2024-10-28 08:23:52 --> Helper loaded: file_helper
INFO - 2024-10-28 08:23:52 --> Helper loaded: form_helper
INFO - 2024-10-28 08:23:52 --> Helper loaded: my_helper
INFO - 2024-10-28 08:23:52 --> Database Driver Class Initialized
INFO - 2024-10-28 08:23:52 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-28 08:23:52 --> Controller Class Initialized
INFO - 2024-10-28 08:23:52 --> Helper loaded: cookie_helper
INFO - 2024-10-28 08:23:52 --> Config Class Initialized
INFO - 2024-10-28 08:23:52 --> Hooks Class Initialized
DEBUG - 2024-10-28 08:23:52 --> UTF-8 Support Enabled
INFO - 2024-10-28 08:23:52 --> Utf8 Class Initialized
INFO - 2024-10-28 08:23:52 --> URI Class Initialized
INFO - 2024-10-28 08:23:52 --> Router Class Initialized
INFO - 2024-10-28 08:23:52 --> Output Class Initialized
INFO - 2024-10-28 08:23:52 --> Security Class Initialized
DEBUG - 2024-10-28 08:23:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-28 08:23:52 --> Input Class Initialized
INFO - 2024-10-28 08:23:52 --> Language Class Initialized
INFO - 2024-10-28 08:23:52 --> Language Class Initialized
INFO - 2024-10-28 08:23:52 --> Config Class Initialized
INFO - 2024-10-28 08:23:52 --> Loader Class Initialized
INFO - 2024-10-28 08:23:52 --> Helper loaded: url_helper
INFO - 2024-10-28 08:23:52 --> Helper loaded: file_helper
INFO - 2024-10-28 08:23:52 --> Helper loaded: form_helper
INFO - 2024-10-28 08:23:52 --> Helper loaded: my_helper
INFO - 2024-10-28 08:23:52 --> Database Driver Class Initialized
INFO - 2024-10-28 08:23:52 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-28 08:23:52 --> Controller Class Initialized
INFO - 2024-10-28 08:23:52 --> Config Class Initialized
INFO - 2024-10-28 08:23:52 --> Hooks Class Initialized
DEBUG - 2024-10-28 08:23:52 --> UTF-8 Support Enabled
INFO - 2024-10-28 08:23:52 --> Utf8 Class Initialized
INFO - 2024-10-28 08:23:52 --> URI Class Initialized
INFO - 2024-10-28 08:23:52 --> Router Class Initialized
INFO - 2024-10-28 08:23:52 --> Output Class Initialized
INFO - 2024-10-28 08:23:52 --> Security Class Initialized
DEBUG - 2024-10-28 08:23:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-28 08:23:52 --> Input Class Initialized
INFO - 2024-10-28 08:23:52 --> Language Class Initialized
INFO - 2024-10-28 08:23:52 --> Language Class Initialized
INFO - 2024-10-28 08:23:52 --> Config Class Initialized
INFO - 2024-10-28 08:23:52 --> Loader Class Initialized
INFO - 2024-10-28 08:23:52 --> Helper loaded: url_helper
INFO - 2024-10-28 08:23:52 --> Helper loaded: file_helper
INFO - 2024-10-28 08:23:52 --> Helper loaded: form_helper
INFO - 2024-10-28 08:23:52 --> Helper loaded: my_helper
INFO - 2024-10-28 08:23:52 --> Database Driver Class Initialized
INFO - 2024-10-28 08:23:52 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-28 08:23:52 --> Controller Class Initialized
DEBUG - 2024-10-28 08:23:52 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/login/views/login.php
DEBUG - 2024-10-28 08:23:52 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-10-28 08:23:52 --> Final output sent to browser
DEBUG - 2024-10-28 08:23:52 --> Total execution time: 0.0276
INFO - 2024-10-28 08:24:04 --> Config Class Initialized
INFO - 2024-10-28 08:24:04 --> Hooks Class Initialized
DEBUG - 2024-10-28 08:24:04 --> UTF-8 Support Enabled
INFO - 2024-10-28 08:24:04 --> Utf8 Class Initialized
INFO - 2024-10-28 08:24:04 --> URI Class Initialized
INFO - 2024-10-28 08:24:04 --> Router Class Initialized
INFO - 2024-10-28 08:24:04 --> Output Class Initialized
INFO - 2024-10-28 08:24:04 --> Security Class Initialized
DEBUG - 2024-10-28 08:24:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-28 08:24:04 --> Input Class Initialized
INFO - 2024-10-28 08:24:04 --> Language Class Initialized
INFO - 2024-10-28 08:24:04 --> Language Class Initialized
INFO - 2024-10-28 08:24:04 --> Config Class Initialized
INFO - 2024-10-28 08:24:04 --> Loader Class Initialized
INFO - 2024-10-28 08:24:04 --> Helper loaded: url_helper
INFO - 2024-10-28 08:24:04 --> Helper loaded: file_helper
INFO - 2024-10-28 08:24:04 --> Helper loaded: form_helper
INFO - 2024-10-28 08:24:04 --> Helper loaded: my_helper
INFO - 2024-10-28 08:24:04 --> Database Driver Class Initialized
INFO - 2024-10-28 08:24:04 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-28 08:24:04 --> Controller Class Initialized
INFO - 2024-10-28 08:24:04 --> Helper loaded: cookie_helper
INFO - 2024-10-28 08:24:04 --> Final output sent to browser
DEBUG - 2024-10-28 08:24:04 --> Total execution time: 0.0676
INFO - 2024-10-28 08:24:04 --> Config Class Initialized
INFO - 2024-10-28 08:24:04 --> Hooks Class Initialized
DEBUG - 2024-10-28 08:24:04 --> UTF-8 Support Enabled
INFO - 2024-10-28 08:24:04 --> Utf8 Class Initialized
INFO - 2024-10-28 08:24:04 --> URI Class Initialized
INFO - 2024-10-28 08:24:04 --> Router Class Initialized
INFO - 2024-10-28 08:24:04 --> Output Class Initialized
INFO - 2024-10-28 08:24:04 --> Security Class Initialized
DEBUG - 2024-10-28 08:24:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-28 08:24:04 --> Input Class Initialized
INFO - 2024-10-28 08:24:04 --> Language Class Initialized
INFO - 2024-10-28 08:24:04 --> Language Class Initialized
INFO - 2024-10-28 08:24:04 --> Config Class Initialized
INFO - 2024-10-28 08:24:04 --> Loader Class Initialized
INFO - 2024-10-28 08:24:04 --> Helper loaded: url_helper
INFO - 2024-10-28 08:24:04 --> Helper loaded: file_helper
INFO - 2024-10-28 08:24:04 --> Helper loaded: form_helper
INFO - 2024-10-28 08:24:04 --> Helper loaded: my_helper
INFO - 2024-10-28 08:24:04 --> Database Driver Class Initialized
INFO - 2024-10-28 08:24:04 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-28 08:24:04 --> Controller Class Initialized
DEBUG - 2024-10-28 08:24:04 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/home/views/v_home_guru.php
DEBUG - 2024-10-28 08:24:04 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-10-28 08:24:04 --> Final output sent to browser
DEBUG - 2024-10-28 08:24:04 --> Total execution time: 0.0633
INFO - 2024-10-28 08:24:16 --> Config Class Initialized
INFO - 2024-10-28 08:24:16 --> Hooks Class Initialized
DEBUG - 2024-10-28 08:24:16 --> UTF-8 Support Enabled
INFO - 2024-10-28 08:24:16 --> Utf8 Class Initialized
INFO - 2024-10-28 08:24:16 --> URI Class Initialized
INFO - 2024-10-28 08:24:16 --> Router Class Initialized
INFO - 2024-10-28 08:24:16 --> Output Class Initialized
INFO - 2024-10-28 08:24:16 --> Security Class Initialized
DEBUG - 2024-10-28 08:24:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-28 08:24:16 --> Input Class Initialized
INFO - 2024-10-28 08:24:16 --> Language Class Initialized
INFO - 2024-10-28 08:24:16 --> Language Class Initialized
INFO - 2024-10-28 08:24:16 --> Config Class Initialized
INFO - 2024-10-28 08:24:16 --> Loader Class Initialized
INFO - 2024-10-28 08:24:16 --> Helper loaded: url_helper
INFO - 2024-10-28 08:24:16 --> Helper loaded: file_helper
INFO - 2024-10-28 08:24:16 --> Helper loaded: form_helper
INFO - 2024-10-28 08:24:16 --> Helper loaded: my_helper
INFO - 2024-10-28 08:24:16 --> Database Driver Class Initialized
INFO - 2024-10-28 08:24:16 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-28 08:24:16 --> Controller Class Initialized
DEBUG - 2024-10-28 08:24:16 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/list.php
DEBUG - 2024-10-28 08:24:16 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-10-28 08:24:16 --> Final output sent to browser
DEBUG - 2024-10-28 08:24:16 --> Total execution time: 0.0482
INFO - 2024-10-28 08:24:33 --> Config Class Initialized
INFO - 2024-10-28 08:24:33 --> Hooks Class Initialized
DEBUG - 2024-10-28 08:24:33 --> UTF-8 Support Enabled
INFO - 2024-10-28 08:24:33 --> Utf8 Class Initialized
INFO - 2024-10-28 08:24:33 --> URI Class Initialized
INFO - 2024-10-28 08:24:33 --> Router Class Initialized
INFO - 2024-10-28 08:24:33 --> Output Class Initialized
INFO - 2024-10-28 08:24:33 --> Security Class Initialized
DEBUG - 2024-10-28 08:24:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-28 08:24:33 --> Input Class Initialized
INFO - 2024-10-28 08:24:33 --> Language Class Initialized
INFO - 2024-10-28 08:24:33 --> Language Class Initialized
INFO - 2024-10-28 08:24:33 --> Config Class Initialized
INFO - 2024-10-28 08:24:33 --> Loader Class Initialized
INFO - 2024-10-28 08:24:33 --> Helper loaded: url_helper
INFO - 2024-10-28 08:24:33 --> Helper loaded: file_helper
INFO - 2024-10-28 08:24:33 --> Helper loaded: form_helper
INFO - 2024-10-28 08:24:33 --> Helper loaded: my_helper
INFO - 2024-10-28 08:24:33 --> Database Driver Class Initialized
INFO - 2024-10-28 08:24:33 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-28 08:24:33 --> Controller Class Initialized
DEBUG - 2024-10-28 08:24:34 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php
INFO - 2024-10-28 08:24:37 --> Final output sent to browser
DEBUG - 2024-10-28 08:24:37 --> Total execution time: 3.3487
INFO - 2024-10-28 08:27:04 --> Config Class Initialized
INFO - 2024-10-28 08:27:04 --> Hooks Class Initialized
DEBUG - 2024-10-28 08:27:04 --> UTF-8 Support Enabled
INFO - 2024-10-28 08:27:04 --> Utf8 Class Initialized
INFO - 2024-10-28 08:27:04 --> URI Class Initialized
INFO - 2024-10-28 08:27:04 --> Router Class Initialized
INFO - 2024-10-28 08:27:04 --> Output Class Initialized
INFO - 2024-10-28 08:27:04 --> Security Class Initialized
DEBUG - 2024-10-28 08:27:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-28 08:27:04 --> Input Class Initialized
INFO - 2024-10-28 08:27:04 --> Language Class Initialized
INFO - 2024-10-28 08:27:04 --> Language Class Initialized
INFO - 2024-10-28 08:27:04 --> Config Class Initialized
INFO - 2024-10-28 08:27:04 --> Loader Class Initialized
INFO - 2024-10-28 08:27:04 --> Helper loaded: url_helper
INFO - 2024-10-28 08:27:04 --> Helper loaded: file_helper
INFO - 2024-10-28 08:27:04 --> Helper loaded: form_helper
INFO - 2024-10-28 08:27:04 --> Helper loaded: my_helper
INFO - 2024-10-28 08:27:04 --> Database Driver Class Initialized
INFO - 2024-10-28 08:27:04 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-28 08:27:04 --> Controller Class Initialized
DEBUG - 2024-10-28 08:27:04 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php
INFO - 2024-10-28 08:27:07 --> Final output sent to browser
DEBUG - 2024-10-28 08:27:07 --> Total execution time: 2.7231
INFO - 2024-10-28 08:27:53 --> Config Class Initialized
INFO - 2024-10-28 08:27:53 --> Hooks Class Initialized
DEBUG - 2024-10-28 08:27:53 --> UTF-8 Support Enabled
INFO - 2024-10-28 08:27:53 --> Utf8 Class Initialized
INFO - 2024-10-28 08:27:53 --> URI Class Initialized
INFO - 2024-10-28 08:27:53 --> Router Class Initialized
INFO - 2024-10-28 08:27:53 --> Output Class Initialized
INFO - 2024-10-28 08:27:53 --> Security Class Initialized
DEBUG - 2024-10-28 08:27:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-28 08:27:53 --> Input Class Initialized
INFO - 2024-10-28 08:27:53 --> Language Class Initialized
INFO - 2024-10-28 08:27:53 --> Language Class Initialized
INFO - 2024-10-28 08:27:53 --> Config Class Initialized
INFO - 2024-10-28 08:27:53 --> Loader Class Initialized
INFO - 2024-10-28 08:27:53 --> Helper loaded: url_helper
INFO - 2024-10-28 08:27:53 --> Helper loaded: file_helper
INFO - 2024-10-28 08:27:53 --> Helper loaded: form_helper
INFO - 2024-10-28 08:27:53 --> Helper loaded: my_helper
INFO - 2024-10-28 08:27:53 --> Database Driver Class Initialized
INFO - 2024-10-28 08:27:53 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-28 08:27:53 --> Controller Class Initialized
DEBUG - 2024-10-28 08:27:53 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php
INFO - 2024-10-28 08:27:55 --> Final output sent to browser
DEBUG - 2024-10-28 08:27:55 --> Total execution time: 2.5443
INFO - 2024-10-28 08:29:00 --> Config Class Initialized
INFO - 2024-10-28 08:29:00 --> Hooks Class Initialized
DEBUG - 2024-10-28 08:29:00 --> UTF-8 Support Enabled
INFO - 2024-10-28 08:29:00 --> Utf8 Class Initialized
INFO - 2024-10-28 08:29:00 --> URI Class Initialized
INFO - 2024-10-28 08:29:00 --> Router Class Initialized
INFO - 2024-10-28 08:29:00 --> Output Class Initialized
INFO - 2024-10-28 08:29:00 --> Security Class Initialized
DEBUG - 2024-10-28 08:29:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-28 08:29:00 --> Input Class Initialized
INFO - 2024-10-28 08:29:00 --> Language Class Initialized
INFO - 2024-10-28 08:29:00 --> Language Class Initialized
INFO - 2024-10-28 08:29:00 --> Config Class Initialized
INFO - 2024-10-28 08:29:00 --> Loader Class Initialized
INFO - 2024-10-28 08:29:00 --> Helper loaded: url_helper
INFO - 2024-10-28 08:29:00 --> Helper loaded: file_helper
INFO - 2024-10-28 08:29:00 --> Helper loaded: form_helper
INFO - 2024-10-28 08:29:00 --> Helper loaded: my_helper
INFO - 2024-10-28 08:29:00 --> Database Driver Class Initialized
INFO - 2024-10-28 08:29:00 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-28 08:29:00 --> Controller Class Initialized
DEBUG - 2024-10-28 08:29:00 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php
INFO - 2024-10-28 08:29:04 --> Final output sent to browser
DEBUG - 2024-10-28 08:29:04 --> Total execution time: 3.9541
INFO - 2024-10-28 08:30:02 --> Config Class Initialized
INFO - 2024-10-28 08:30:02 --> Hooks Class Initialized
DEBUG - 2024-10-28 08:30:02 --> UTF-8 Support Enabled
INFO - 2024-10-28 08:30:02 --> Utf8 Class Initialized
INFO - 2024-10-28 08:30:02 --> URI Class Initialized
INFO - 2024-10-28 08:30:02 --> Router Class Initialized
INFO - 2024-10-28 08:30:02 --> Output Class Initialized
INFO - 2024-10-28 08:30:02 --> Security Class Initialized
DEBUG - 2024-10-28 08:30:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-28 08:30:02 --> Input Class Initialized
INFO - 2024-10-28 08:30:02 --> Language Class Initialized
INFO - 2024-10-28 08:30:02 --> Language Class Initialized
INFO - 2024-10-28 08:30:02 --> Config Class Initialized
INFO - 2024-10-28 08:30:02 --> Loader Class Initialized
INFO - 2024-10-28 08:30:02 --> Helper loaded: url_helper
INFO - 2024-10-28 08:30:02 --> Helper loaded: file_helper
INFO - 2024-10-28 08:30:02 --> Helper loaded: form_helper
INFO - 2024-10-28 08:30:02 --> Helper loaded: my_helper
INFO - 2024-10-28 08:30:02 --> Database Driver Class Initialized
INFO - 2024-10-28 08:30:02 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-28 08:30:02 --> Controller Class Initialized
DEBUG - 2024-10-28 08:30:02 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php
INFO - 2024-10-28 08:30:06 --> Final output sent to browser
DEBUG - 2024-10-28 08:30:06 --> Total execution time: 3.4385
INFO - 2024-10-28 08:30:34 --> Config Class Initialized
INFO - 2024-10-28 08:30:34 --> Hooks Class Initialized
DEBUG - 2024-10-28 08:30:34 --> UTF-8 Support Enabled
INFO - 2024-10-28 08:30:34 --> Utf8 Class Initialized
INFO - 2024-10-28 08:30:34 --> URI Class Initialized
INFO - 2024-10-28 08:30:34 --> Router Class Initialized
INFO - 2024-10-28 08:30:34 --> Output Class Initialized
INFO - 2024-10-28 08:30:34 --> Security Class Initialized
DEBUG - 2024-10-28 08:30:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-28 08:30:34 --> Input Class Initialized
INFO - 2024-10-28 08:30:34 --> Language Class Initialized
INFO - 2024-10-28 08:30:34 --> Language Class Initialized
INFO - 2024-10-28 08:30:34 --> Config Class Initialized
INFO - 2024-10-28 08:30:34 --> Loader Class Initialized
INFO - 2024-10-28 08:30:34 --> Helper loaded: url_helper
INFO - 2024-10-28 08:30:34 --> Helper loaded: file_helper
INFO - 2024-10-28 08:30:34 --> Helper loaded: form_helper
INFO - 2024-10-28 08:30:34 --> Helper loaded: my_helper
INFO - 2024-10-28 08:30:34 --> Database Driver Class Initialized
INFO - 2024-10-28 08:30:34 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-28 08:30:34 --> Controller Class Initialized
DEBUG - 2024-10-28 08:30:34 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php
INFO - 2024-10-28 08:30:37 --> Final output sent to browser
DEBUG - 2024-10-28 08:30:37 --> Total execution time: 2.7715
INFO - 2024-10-28 08:31:01 --> Config Class Initialized
INFO - 2024-10-28 08:31:01 --> Hooks Class Initialized
DEBUG - 2024-10-28 08:31:01 --> UTF-8 Support Enabled
INFO - 2024-10-28 08:31:01 --> Utf8 Class Initialized
INFO - 2024-10-28 08:31:01 --> URI Class Initialized
INFO - 2024-10-28 08:31:01 --> Router Class Initialized
INFO - 2024-10-28 08:31:01 --> Output Class Initialized
INFO - 2024-10-28 08:31:01 --> Security Class Initialized
DEBUG - 2024-10-28 08:31:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-28 08:31:01 --> Input Class Initialized
INFO - 2024-10-28 08:31:01 --> Language Class Initialized
INFO - 2024-10-28 08:31:02 --> Language Class Initialized
INFO - 2024-10-28 08:31:02 --> Config Class Initialized
INFO - 2024-10-28 08:31:02 --> Loader Class Initialized
INFO - 2024-10-28 08:31:02 --> Helper loaded: url_helper
INFO - 2024-10-28 08:31:02 --> Helper loaded: file_helper
INFO - 2024-10-28 08:31:02 --> Helper loaded: form_helper
INFO - 2024-10-28 08:31:02 --> Helper loaded: my_helper
INFO - 2024-10-28 08:31:02 --> Database Driver Class Initialized
INFO - 2024-10-28 08:31:02 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-28 08:31:02 --> Controller Class Initialized
DEBUG - 2024-10-28 08:31:02 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php
INFO - 2024-10-28 08:31:05 --> Final output sent to browser
DEBUG - 2024-10-28 08:31:05 --> Total execution time: 3.0575
INFO - 2024-10-28 08:31:26 --> Config Class Initialized
INFO - 2024-10-28 08:31:26 --> Hooks Class Initialized
DEBUG - 2024-10-28 08:31:26 --> UTF-8 Support Enabled
INFO - 2024-10-28 08:31:26 --> Utf8 Class Initialized
INFO - 2024-10-28 08:31:26 --> URI Class Initialized
INFO - 2024-10-28 08:31:26 --> Router Class Initialized
INFO - 2024-10-28 08:31:26 --> Output Class Initialized
INFO - 2024-10-28 08:31:26 --> Security Class Initialized
DEBUG - 2024-10-28 08:31:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-28 08:31:26 --> Input Class Initialized
INFO - 2024-10-28 08:31:26 --> Language Class Initialized
INFO - 2024-10-28 08:31:26 --> Language Class Initialized
INFO - 2024-10-28 08:31:26 --> Config Class Initialized
INFO - 2024-10-28 08:31:26 --> Loader Class Initialized
INFO - 2024-10-28 08:31:26 --> Helper loaded: url_helper
INFO - 2024-10-28 08:31:26 --> Helper loaded: file_helper
INFO - 2024-10-28 08:31:26 --> Helper loaded: form_helper
INFO - 2024-10-28 08:31:26 --> Helper loaded: my_helper
INFO - 2024-10-28 08:31:26 --> Database Driver Class Initialized
INFO - 2024-10-28 08:31:26 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-28 08:31:26 --> Controller Class Initialized
DEBUG - 2024-10-28 08:31:26 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php
INFO - 2024-10-28 08:31:29 --> Final output sent to browser
DEBUG - 2024-10-28 08:31:29 --> Total execution time: 3.1714
INFO - 2024-10-28 08:31:59 --> Config Class Initialized
INFO - 2024-10-28 08:31:59 --> Hooks Class Initialized
DEBUG - 2024-10-28 08:31:59 --> UTF-8 Support Enabled
INFO - 2024-10-28 08:31:59 --> Utf8 Class Initialized
INFO - 2024-10-28 08:31:59 --> URI Class Initialized
INFO - 2024-10-28 08:31:59 --> Router Class Initialized
INFO - 2024-10-28 08:31:59 --> Output Class Initialized
INFO - 2024-10-28 08:31:59 --> Security Class Initialized
DEBUG - 2024-10-28 08:31:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-28 08:31:59 --> Input Class Initialized
INFO - 2024-10-28 08:31:59 --> Language Class Initialized
INFO - 2024-10-28 08:31:59 --> Language Class Initialized
INFO - 2024-10-28 08:31:59 --> Config Class Initialized
INFO - 2024-10-28 08:31:59 --> Loader Class Initialized
INFO - 2024-10-28 08:31:59 --> Helper loaded: url_helper
INFO - 2024-10-28 08:31:59 --> Helper loaded: file_helper
INFO - 2024-10-28 08:31:59 --> Helper loaded: form_helper
INFO - 2024-10-28 08:31:59 --> Helper loaded: my_helper
INFO - 2024-10-28 08:31:59 --> Database Driver Class Initialized
INFO - 2024-10-28 08:31:59 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-28 08:31:59 --> Controller Class Initialized
DEBUG - 2024-10-28 08:31:59 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php
INFO - 2024-10-28 08:32:02 --> Final output sent to browser
DEBUG - 2024-10-28 08:32:02 --> Total execution time: 3.4166
INFO - 2024-10-28 08:33:18 --> Config Class Initialized
INFO - 2024-10-28 08:33:18 --> Hooks Class Initialized
DEBUG - 2024-10-28 08:33:18 --> UTF-8 Support Enabled
INFO - 2024-10-28 08:33:18 --> Utf8 Class Initialized
INFO - 2024-10-28 08:33:18 --> URI Class Initialized
INFO - 2024-10-28 08:33:18 --> Router Class Initialized
INFO - 2024-10-28 08:33:18 --> Output Class Initialized
INFO - 2024-10-28 08:33:18 --> Security Class Initialized
DEBUG - 2024-10-28 08:33:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-28 08:33:18 --> Input Class Initialized
INFO - 2024-10-28 08:33:18 --> Language Class Initialized
INFO - 2024-10-28 08:33:18 --> Language Class Initialized
INFO - 2024-10-28 08:33:18 --> Config Class Initialized
INFO - 2024-10-28 08:33:18 --> Loader Class Initialized
INFO - 2024-10-28 08:33:18 --> Helper loaded: url_helper
INFO - 2024-10-28 08:33:18 --> Helper loaded: file_helper
INFO - 2024-10-28 08:33:18 --> Helper loaded: form_helper
INFO - 2024-10-28 08:33:18 --> Helper loaded: my_helper
INFO - 2024-10-28 08:33:18 --> Database Driver Class Initialized
INFO - 2024-10-28 08:33:18 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-28 08:33:18 --> Controller Class Initialized
DEBUG - 2024-10-28 08:33:18 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php
INFO - 2024-10-28 08:33:21 --> Final output sent to browser
DEBUG - 2024-10-28 08:33:21 --> Total execution time: 3.0167
INFO - 2024-10-28 08:34:30 --> Config Class Initialized
INFO - 2024-10-28 08:34:30 --> Hooks Class Initialized
DEBUG - 2024-10-28 08:34:30 --> UTF-8 Support Enabled
INFO - 2024-10-28 08:34:30 --> Utf8 Class Initialized
INFO - 2024-10-28 08:34:30 --> URI Class Initialized
INFO - 2024-10-28 08:34:30 --> Router Class Initialized
INFO - 2024-10-28 08:34:30 --> Output Class Initialized
INFO - 2024-10-28 08:34:30 --> Security Class Initialized
DEBUG - 2024-10-28 08:34:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-28 08:34:30 --> Input Class Initialized
INFO - 2024-10-28 08:34:30 --> Language Class Initialized
INFO - 2024-10-28 08:34:30 --> Language Class Initialized
INFO - 2024-10-28 08:34:30 --> Config Class Initialized
INFO - 2024-10-28 08:34:30 --> Loader Class Initialized
INFO - 2024-10-28 08:34:30 --> Helper loaded: url_helper
INFO - 2024-10-28 08:34:30 --> Helper loaded: file_helper
INFO - 2024-10-28 08:34:30 --> Helper loaded: form_helper
INFO - 2024-10-28 08:34:30 --> Helper loaded: my_helper
INFO - 2024-10-28 08:34:30 --> Database Driver Class Initialized
INFO - 2024-10-28 08:34:30 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-28 08:34:30 --> Controller Class Initialized
DEBUG - 2024-10-28 08:34:30 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php
INFO - 2024-10-28 08:34:33 --> Final output sent to browser
DEBUG - 2024-10-28 08:34:33 --> Total execution time: 3.0506
INFO - 2024-10-28 08:34:52 --> Config Class Initialized
INFO - 2024-10-28 08:34:52 --> Hooks Class Initialized
DEBUG - 2024-10-28 08:34:52 --> UTF-8 Support Enabled
INFO - 2024-10-28 08:34:52 --> Utf8 Class Initialized
INFO - 2024-10-28 08:34:52 --> URI Class Initialized
INFO - 2024-10-28 08:34:52 --> Router Class Initialized
INFO - 2024-10-28 08:34:52 --> Output Class Initialized
INFO - 2024-10-28 08:34:52 --> Security Class Initialized
DEBUG - 2024-10-28 08:34:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-28 08:34:52 --> Input Class Initialized
INFO - 2024-10-28 08:34:52 --> Language Class Initialized
INFO - 2024-10-28 08:34:52 --> Language Class Initialized
INFO - 2024-10-28 08:34:52 --> Config Class Initialized
INFO - 2024-10-28 08:34:52 --> Loader Class Initialized
INFO - 2024-10-28 08:34:52 --> Helper loaded: url_helper
INFO - 2024-10-28 08:34:52 --> Helper loaded: file_helper
INFO - 2024-10-28 08:34:52 --> Helper loaded: form_helper
INFO - 2024-10-28 08:34:52 --> Helper loaded: my_helper
INFO - 2024-10-28 08:34:52 --> Database Driver Class Initialized
INFO - 2024-10-28 08:34:52 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-28 08:34:52 --> Controller Class Initialized
DEBUG - 2024-10-28 08:34:52 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php
INFO - 2024-10-28 08:34:55 --> Final output sent to browser
DEBUG - 2024-10-28 08:34:55 --> Total execution time: 2.6624
INFO - 2024-10-28 08:35:48 --> Config Class Initialized
INFO - 2024-10-28 08:35:48 --> Hooks Class Initialized
DEBUG - 2024-10-28 08:35:48 --> UTF-8 Support Enabled
INFO - 2024-10-28 08:35:48 --> Utf8 Class Initialized
INFO - 2024-10-28 08:35:48 --> URI Class Initialized
INFO - 2024-10-28 08:35:48 --> Router Class Initialized
INFO - 2024-10-28 08:35:48 --> Output Class Initialized
INFO - 2024-10-28 08:35:48 --> Security Class Initialized
DEBUG - 2024-10-28 08:35:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-28 08:35:48 --> Input Class Initialized
INFO - 2024-10-28 08:35:48 --> Language Class Initialized
INFO - 2024-10-28 08:35:48 --> Language Class Initialized
INFO - 2024-10-28 08:35:48 --> Config Class Initialized
INFO - 2024-10-28 08:35:48 --> Loader Class Initialized
INFO - 2024-10-28 08:35:48 --> Helper loaded: url_helper
INFO - 2024-10-28 08:35:48 --> Helper loaded: file_helper
INFO - 2024-10-28 08:35:48 --> Helper loaded: form_helper
INFO - 2024-10-28 08:35:48 --> Helper loaded: my_helper
INFO - 2024-10-28 08:35:48 --> Database Driver Class Initialized
INFO - 2024-10-28 08:35:48 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-28 08:35:48 --> Controller Class Initialized
DEBUG - 2024-10-28 08:35:48 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php
INFO - 2024-10-28 08:35:51 --> Final output sent to browser
DEBUG - 2024-10-28 08:35:51 --> Total execution time: 2.8910
INFO - 2024-10-28 08:36:35 --> Config Class Initialized
INFO - 2024-10-28 08:36:35 --> Hooks Class Initialized
DEBUG - 2024-10-28 08:36:35 --> UTF-8 Support Enabled
INFO - 2024-10-28 08:36:35 --> Utf8 Class Initialized
INFO - 2024-10-28 08:36:35 --> URI Class Initialized
INFO - 2024-10-28 08:36:35 --> Router Class Initialized
INFO - 2024-10-28 08:36:35 --> Output Class Initialized
INFO - 2024-10-28 08:36:35 --> Security Class Initialized
DEBUG - 2024-10-28 08:36:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-28 08:36:35 --> Input Class Initialized
INFO - 2024-10-28 08:36:35 --> Language Class Initialized
INFO - 2024-10-28 08:36:35 --> Language Class Initialized
INFO - 2024-10-28 08:36:35 --> Config Class Initialized
INFO - 2024-10-28 08:36:35 --> Loader Class Initialized
INFO - 2024-10-28 08:36:35 --> Helper loaded: url_helper
INFO - 2024-10-28 08:36:35 --> Helper loaded: file_helper
INFO - 2024-10-28 08:36:35 --> Helper loaded: form_helper
INFO - 2024-10-28 08:36:35 --> Helper loaded: my_helper
INFO - 2024-10-28 08:36:35 --> Database Driver Class Initialized
INFO - 2024-10-28 08:36:35 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-28 08:36:35 --> Controller Class Initialized
DEBUG - 2024-10-28 08:36:35 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php
INFO - 2024-10-28 08:36:38 --> Final output sent to browser
DEBUG - 2024-10-28 08:36:38 --> Total execution time: 2.6928
INFO - 2024-10-28 08:36:58 --> Config Class Initialized
INFO - 2024-10-28 08:36:58 --> Hooks Class Initialized
DEBUG - 2024-10-28 08:36:58 --> UTF-8 Support Enabled
INFO - 2024-10-28 08:36:58 --> Utf8 Class Initialized
INFO - 2024-10-28 08:36:58 --> URI Class Initialized
INFO - 2024-10-28 08:36:58 --> Router Class Initialized
INFO - 2024-10-28 08:36:58 --> Output Class Initialized
INFO - 2024-10-28 08:36:58 --> Security Class Initialized
DEBUG - 2024-10-28 08:36:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-28 08:36:58 --> Input Class Initialized
INFO - 2024-10-28 08:36:58 --> Language Class Initialized
INFO - 2024-10-28 08:36:58 --> Language Class Initialized
INFO - 2024-10-28 08:36:58 --> Config Class Initialized
INFO - 2024-10-28 08:36:58 --> Loader Class Initialized
INFO - 2024-10-28 08:36:58 --> Helper loaded: url_helper
INFO - 2024-10-28 08:36:58 --> Helper loaded: file_helper
INFO - 2024-10-28 08:36:58 --> Helper loaded: form_helper
INFO - 2024-10-28 08:36:58 --> Helper loaded: my_helper
INFO - 2024-10-28 08:36:58 --> Database Driver Class Initialized
INFO - 2024-10-28 08:36:58 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-28 08:36:58 --> Controller Class Initialized
DEBUG - 2024-10-28 08:36:58 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php
INFO - 2024-10-28 08:37:01 --> Final output sent to browser
DEBUG - 2024-10-28 08:37:01 --> Total execution time: 3.4753
INFO - 2024-10-28 08:37:22 --> Config Class Initialized
INFO - 2024-10-28 08:37:22 --> Hooks Class Initialized
DEBUG - 2024-10-28 08:37:22 --> UTF-8 Support Enabled
INFO - 2024-10-28 08:37:22 --> Utf8 Class Initialized
INFO - 2024-10-28 08:37:22 --> URI Class Initialized
INFO - 2024-10-28 08:37:22 --> Router Class Initialized
INFO - 2024-10-28 08:37:22 --> Output Class Initialized
INFO - 2024-10-28 08:37:22 --> Security Class Initialized
DEBUG - 2024-10-28 08:37:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-28 08:37:22 --> Input Class Initialized
INFO - 2024-10-28 08:37:22 --> Language Class Initialized
INFO - 2024-10-28 08:37:22 --> Language Class Initialized
INFO - 2024-10-28 08:37:22 --> Config Class Initialized
INFO - 2024-10-28 08:37:22 --> Loader Class Initialized
INFO - 2024-10-28 08:37:22 --> Helper loaded: url_helper
INFO - 2024-10-28 08:37:22 --> Helper loaded: file_helper
INFO - 2024-10-28 08:37:22 --> Helper loaded: form_helper
INFO - 2024-10-28 08:37:22 --> Helper loaded: my_helper
INFO - 2024-10-28 08:37:22 --> Database Driver Class Initialized
INFO - 2024-10-28 08:37:22 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-28 08:37:22 --> Controller Class Initialized
DEBUG - 2024-10-28 08:37:22 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php
INFO - 2024-10-28 08:37:25 --> Final output sent to browser
DEBUG - 2024-10-28 08:37:25 --> Total execution time: 2.9997
INFO - 2024-10-28 08:37:45 --> Config Class Initialized
INFO - 2024-10-28 08:37:45 --> Hooks Class Initialized
DEBUG - 2024-10-28 08:37:45 --> UTF-8 Support Enabled
INFO - 2024-10-28 08:37:45 --> Utf8 Class Initialized
INFO - 2024-10-28 08:37:45 --> URI Class Initialized
INFO - 2024-10-28 08:37:45 --> Router Class Initialized
INFO - 2024-10-28 08:37:45 --> Output Class Initialized
INFO - 2024-10-28 08:37:45 --> Security Class Initialized
DEBUG - 2024-10-28 08:37:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-28 08:37:45 --> Input Class Initialized
INFO - 2024-10-28 08:37:45 --> Language Class Initialized
INFO - 2024-10-28 08:37:45 --> Language Class Initialized
INFO - 2024-10-28 08:37:45 --> Config Class Initialized
INFO - 2024-10-28 08:37:45 --> Loader Class Initialized
INFO - 2024-10-28 08:37:45 --> Helper loaded: url_helper
INFO - 2024-10-28 08:37:45 --> Helper loaded: file_helper
INFO - 2024-10-28 08:37:45 --> Helper loaded: form_helper
INFO - 2024-10-28 08:37:45 --> Helper loaded: my_helper
INFO - 2024-10-28 08:37:45 --> Database Driver Class Initialized
INFO - 2024-10-28 08:37:45 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-28 08:37:45 --> Controller Class Initialized
DEBUG - 2024-10-28 08:37:45 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php
INFO - 2024-10-28 08:37:47 --> Final output sent to browser
DEBUG - 2024-10-28 08:37:47 --> Total execution time: 2.6771
INFO - 2024-10-28 08:38:14 --> Config Class Initialized
INFO - 2024-10-28 08:38:14 --> Hooks Class Initialized
DEBUG - 2024-10-28 08:38:14 --> UTF-8 Support Enabled
INFO - 2024-10-28 08:38:14 --> Utf8 Class Initialized
INFO - 2024-10-28 08:38:14 --> URI Class Initialized
INFO - 2024-10-28 08:38:14 --> Router Class Initialized
INFO - 2024-10-28 08:38:14 --> Output Class Initialized
INFO - 2024-10-28 08:38:14 --> Security Class Initialized
DEBUG - 2024-10-28 08:38:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-28 08:38:14 --> Input Class Initialized
INFO - 2024-10-28 08:38:14 --> Language Class Initialized
INFO - 2024-10-28 08:38:14 --> Language Class Initialized
INFO - 2024-10-28 08:38:14 --> Config Class Initialized
INFO - 2024-10-28 08:38:14 --> Loader Class Initialized
INFO - 2024-10-28 08:38:14 --> Helper loaded: url_helper
INFO - 2024-10-28 08:38:14 --> Helper loaded: file_helper
INFO - 2024-10-28 08:38:14 --> Helper loaded: form_helper
INFO - 2024-10-28 08:38:14 --> Helper loaded: my_helper
INFO - 2024-10-28 08:38:14 --> Database Driver Class Initialized
INFO - 2024-10-28 08:38:14 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-28 08:38:14 --> Controller Class Initialized
DEBUG - 2024-10-28 08:38:14 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php
INFO - 2024-10-28 08:38:17 --> Final output sent to browser
DEBUG - 2024-10-28 08:38:17 --> Total execution time: 2.8437
INFO - 2024-10-28 08:38:37 --> Config Class Initialized
INFO - 2024-10-28 08:38:37 --> Hooks Class Initialized
DEBUG - 2024-10-28 08:38:37 --> UTF-8 Support Enabled
INFO - 2024-10-28 08:38:37 --> Utf8 Class Initialized
INFO - 2024-10-28 08:38:37 --> URI Class Initialized
INFO - 2024-10-28 08:38:37 --> Router Class Initialized
INFO - 2024-10-28 08:38:37 --> Output Class Initialized
INFO - 2024-10-28 08:38:37 --> Security Class Initialized
DEBUG - 2024-10-28 08:38:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-28 08:38:37 --> Input Class Initialized
INFO - 2024-10-28 08:38:37 --> Language Class Initialized
INFO - 2024-10-28 08:38:37 --> Language Class Initialized
INFO - 2024-10-28 08:38:37 --> Config Class Initialized
INFO - 2024-10-28 08:38:37 --> Loader Class Initialized
INFO - 2024-10-28 08:38:37 --> Helper loaded: url_helper
INFO - 2024-10-28 08:38:37 --> Helper loaded: file_helper
INFO - 2024-10-28 08:38:37 --> Helper loaded: form_helper
INFO - 2024-10-28 08:38:37 --> Helper loaded: my_helper
INFO - 2024-10-28 08:38:37 --> Database Driver Class Initialized
INFO - 2024-10-28 08:38:37 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-28 08:38:37 --> Controller Class Initialized
DEBUG - 2024-10-28 08:38:37 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php
INFO - 2024-10-28 08:38:40 --> Final output sent to browser
DEBUG - 2024-10-28 08:38:40 --> Total execution time: 2.7653
INFO - 2024-10-28 08:46:08 --> Config Class Initialized
INFO - 2024-10-28 08:46:08 --> Hooks Class Initialized
DEBUG - 2024-10-28 08:46:08 --> UTF-8 Support Enabled
INFO - 2024-10-28 08:46:08 --> Utf8 Class Initialized
INFO - 2024-10-28 08:46:08 --> URI Class Initialized
INFO - 2024-10-28 08:46:08 --> Router Class Initialized
INFO - 2024-10-28 08:46:08 --> Output Class Initialized
INFO - 2024-10-28 08:46:08 --> Security Class Initialized
DEBUG - 2024-10-28 08:46:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-28 08:46:08 --> Input Class Initialized
INFO - 2024-10-28 08:46:08 --> Language Class Initialized
INFO - 2024-10-28 08:46:08 --> Language Class Initialized
INFO - 2024-10-28 08:46:08 --> Config Class Initialized
INFO - 2024-10-28 08:46:08 --> Loader Class Initialized
INFO - 2024-10-28 08:46:08 --> Helper loaded: url_helper
INFO - 2024-10-28 08:46:08 --> Helper loaded: file_helper
INFO - 2024-10-28 08:46:08 --> Helper loaded: form_helper
INFO - 2024-10-28 08:46:08 --> Helper loaded: my_helper
INFO - 2024-10-28 08:46:08 --> Database Driver Class Initialized
INFO - 2024-10-28 08:46:08 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-28 08:46:08 --> Controller Class Initialized
INFO - 2024-10-28 08:46:08 --> Helper loaded: cookie_helper
INFO - 2024-10-28 08:46:08 --> Config Class Initialized
INFO - 2024-10-28 08:46:08 --> Hooks Class Initialized
DEBUG - 2024-10-28 08:46:08 --> UTF-8 Support Enabled
INFO - 2024-10-28 08:46:08 --> Utf8 Class Initialized
INFO - 2024-10-28 08:46:08 --> URI Class Initialized
INFO - 2024-10-28 08:46:08 --> Router Class Initialized
INFO - 2024-10-28 08:46:08 --> Output Class Initialized
INFO - 2024-10-28 08:46:08 --> Security Class Initialized
DEBUG - 2024-10-28 08:46:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-28 08:46:08 --> Input Class Initialized
INFO - 2024-10-28 08:46:08 --> Language Class Initialized
INFO - 2024-10-28 08:46:08 --> Language Class Initialized
INFO - 2024-10-28 08:46:08 --> Config Class Initialized
INFO - 2024-10-28 08:46:08 --> Loader Class Initialized
INFO - 2024-10-28 08:46:08 --> Helper loaded: url_helper
INFO - 2024-10-28 08:46:08 --> Helper loaded: file_helper
INFO - 2024-10-28 08:46:08 --> Helper loaded: form_helper
INFO - 2024-10-28 08:46:08 --> Helper loaded: my_helper
INFO - 2024-10-28 08:46:08 --> Database Driver Class Initialized
INFO - 2024-10-28 08:46:08 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-28 08:46:08 --> Controller Class Initialized
INFO - 2024-10-28 08:46:08 --> Config Class Initialized
INFO - 2024-10-28 08:46:08 --> Hooks Class Initialized
DEBUG - 2024-10-28 08:46:08 --> UTF-8 Support Enabled
INFO - 2024-10-28 08:46:08 --> Utf8 Class Initialized
INFO - 2024-10-28 08:46:08 --> URI Class Initialized
INFO - 2024-10-28 08:46:08 --> Router Class Initialized
INFO - 2024-10-28 08:46:08 --> Output Class Initialized
INFO - 2024-10-28 08:46:08 --> Security Class Initialized
DEBUG - 2024-10-28 08:46:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-28 08:46:08 --> Input Class Initialized
INFO - 2024-10-28 08:46:08 --> Language Class Initialized
INFO - 2024-10-28 08:46:08 --> Language Class Initialized
INFO - 2024-10-28 08:46:08 --> Config Class Initialized
INFO - 2024-10-28 08:46:08 --> Loader Class Initialized
INFO - 2024-10-28 08:46:08 --> Helper loaded: url_helper
INFO - 2024-10-28 08:46:08 --> Helper loaded: file_helper
INFO - 2024-10-28 08:46:09 --> Helper loaded: form_helper
INFO - 2024-10-28 08:46:09 --> Helper loaded: my_helper
INFO - 2024-10-28 08:46:09 --> Database Driver Class Initialized
INFO - 2024-10-28 08:46:09 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-28 08:46:09 --> Controller Class Initialized
DEBUG - 2024-10-28 08:46:09 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/login/views/login.php
DEBUG - 2024-10-28 08:46:09 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-10-28 08:46:09 --> Final output sent to browser
DEBUG - 2024-10-28 08:46:09 --> Total execution time: 0.0399
INFO - 2024-10-28 08:46:17 --> Config Class Initialized
INFO - 2024-10-28 08:46:17 --> Hooks Class Initialized
DEBUG - 2024-10-28 08:46:17 --> UTF-8 Support Enabled
INFO - 2024-10-28 08:46:17 --> Utf8 Class Initialized
INFO - 2024-10-28 08:46:17 --> URI Class Initialized
INFO - 2024-10-28 08:46:17 --> Router Class Initialized
INFO - 2024-10-28 08:46:17 --> Output Class Initialized
INFO - 2024-10-28 08:46:17 --> Security Class Initialized
DEBUG - 2024-10-28 08:46:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-28 08:46:17 --> Input Class Initialized
INFO - 2024-10-28 08:46:17 --> Language Class Initialized
INFO - 2024-10-28 08:46:17 --> Language Class Initialized
INFO - 2024-10-28 08:46:17 --> Config Class Initialized
INFO - 2024-10-28 08:46:17 --> Loader Class Initialized
INFO - 2024-10-28 08:46:17 --> Helper loaded: url_helper
INFO - 2024-10-28 08:46:17 --> Helper loaded: file_helper
INFO - 2024-10-28 08:46:17 --> Helper loaded: form_helper
INFO - 2024-10-28 08:46:17 --> Helper loaded: my_helper
INFO - 2024-10-28 08:46:17 --> Database Driver Class Initialized
INFO - 2024-10-28 08:46:17 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-28 08:46:17 --> Controller Class Initialized
INFO - 2024-10-28 08:46:17 --> Helper loaded: cookie_helper
INFO - 2024-10-28 08:46:17 --> Final output sent to browser
DEBUG - 2024-10-28 08:46:17 --> Total execution time: 0.0292
INFO - 2024-10-28 08:46:17 --> Config Class Initialized
INFO - 2024-10-28 08:46:17 --> Hooks Class Initialized
DEBUG - 2024-10-28 08:46:17 --> UTF-8 Support Enabled
INFO - 2024-10-28 08:46:17 --> Utf8 Class Initialized
INFO - 2024-10-28 08:46:17 --> URI Class Initialized
INFO - 2024-10-28 08:46:17 --> Router Class Initialized
INFO - 2024-10-28 08:46:17 --> Output Class Initialized
INFO - 2024-10-28 08:46:17 --> Security Class Initialized
DEBUG - 2024-10-28 08:46:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-28 08:46:17 --> Input Class Initialized
INFO - 2024-10-28 08:46:17 --> Language Class Initialized
INFO - 2024-10-28 08:46:17 --> Language Class Initialized
INFO - 2024-10-28 08:46:17 --> Config Class Initialized
INFO - 2024-10-28 08:46:17 --> Loader Class Initialized
INFO - 2024-10-28 08:46:17 --> Helper loaded: url_helper
INFO - 2024-10-28 08:46:17 --> Helper loaded: file_helper
INFO - 2024-10-28 08:46:17 --> Helper loaded: form_helper
INFO - 2024-10-28 08:46:17 --> Helper loaded: my_helper
INFO - 2024-10-28 08:46:17 --> Database Driver Class Initialized
INFO - 2024-10-28 08:46:18 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-28 08:46:18 --> Controller Class Initialized
DEBUG - 2024-10-28 08:46:18 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/home/views/v_home.php
DEBUG - 2024-10-28 08:46:18 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-10-28 08:46:18 --> Final output sent to browser
DEBUG - 2024-10-28 08:46:18 --> Total execution time: 0.0385
INFO - 2024-10-28 08:46:21 --> Config Class Initialized
INFO - 2024-10-28 08:46:21 --> Hooks Class Initialized
DEBUG - 2024-10-28 08:46:21 --> UTF-8 Support Enabled
INFO - 2024-10-28 08:46:21 --> Utf8 Class Initialized
INFO - 2024-10-28 08:46:21 --> URI Class Initialized
INFO - 2024-10-28 08:46:21 --> Router Class Initialized
INFO - 2024-10-28 08:46:21 --> Output Class Initialized
INFO - 2024-10-28 08:46:21 --> Security Class Initialized
DEBUG - 2024-10-28 08:46:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-28 08:46:21 --> Input Class Initialized
INFO - 2024-10-28 08:46:21 --> Language Class Initialized
INFO - 2024-10-28 08:46:21 --> Language Class Initialized
INFO - 2024-10-28 08:46:21 --> Config Class Initialized
INFO - 2024-10-28 08:46:21 --> Loader Class Initialized
INFO - 2024-10-28 08:46:21 --> Helper loaded: url_helper
INFO - 2024-10-28 08:46:21 --> Helper loaded: file_helper
INFO - 2024-10-28 08:46:21 --> Helper loaded: form_helper
INFO - 2024-10-28 08:46:21 --> Helper loaded: my_helper
INFO - 2024-10-28 08:46:21 --> Database Driver Class Initialized
INFO - 2024-10-28 08:46:21 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-28 08:46:21 --> Controller Class Initialized
DEBUG - 2024-10-28 08:46:21 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/data_siswa/views/list.php
DEBUG - 2024-10-28 08:46:21 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-10-28 08:46:21 --> Final output sent to browser
DEBUG - 2024-10-28 08:46:21 --> Total execution time: 0.0269
INFO - 2024-10-28 08:46:21 --> Config Class Initialized
INFO - 2024-10-28 08:46:21 --> Hooks Class Initialized
DEBUG - 2024-10-28 08:46:21 --> UTF-8 Support Enabled
INFO - 2024-10-28 08:46:21 --> Utf8 Class Initialized
INFO - 2024-10-28 08:46:21 --> URI Class Initialized
INFO - 2024-10-28 08:46:21 --> Router Class Initialized
INFO - 2024-10-28 08:46:21 --> Output Class Initialized
INFO - 2024-10-28 08:46:21 --> Security Class Initialized
DEBUG - 2024-10-28 08:46:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-28 08:46:21 --> Input Class Initialized
INFO - 2024-10-28 08:46:21 --> Language Class Initialized
ERROR - 2024-10-28 08:46:21 --> 404 Page Not Found: /index
INFO - 2024-10-28 08:46:21 --> Config Class Initialized
INFO - 2024-10-28 08:46:21 --> Hooks Class Initialized
DEBUG - 2024-10-28 08:46:21 --> UTF-8 Support Enabled
INFO - 2024-10-28 08:46:21 --> Utf8 Class Initialized
INFO - 2024-10-28 08:46:21 --> URI Class Initialized
INFO - 2024-10-28 08:46:21 --> Router Class Initialized
INFO - 2024-10-28 08:46:21 --> Output Class Initialized
INFO - 2024-10-28 08:46:21 --> Security Class Initialized
DEBUG - 2024-10-28 08:46:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-28 08:46:21 --> Input Class Initialized
INFO - 2024-10-28 08:46:21 --> Language Class Initialized
INFO - 2024-10-28 08:46:21 --> Language Class Initialized
INFO - 2024-10-28 08:46:21 --> Config Class Initialized
INFO - 2024-10-28 08:46:21 --> Loader Class Initialized
INFO - 2024-10-28 08:46:21 --> Helper loaded: url_helper
INFO - 2024-10-28 08:46:21 --> Helper loaded: file_helper
INFO - 2024-10-28 08:46:21 --> Helper loaded: form_helper
INFO - 2024-10-28 08:46:21 --> Helper loaded: my_helper
INFO - 2024-10-28 08:46:21 --> Database Driver Class Initialized
INFO - 2024-10-28 08:46:21 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-28 08:46:21 --> Controller Class Initialized
INFO - 2024-10-28 08:46:24 --> Config Class Initialized
INFO - 2024-10-28 08:46:24 --> Hooks Class Initialized
DEBUG - 2024-10-28 08:46:24 --> UTF-8 Support Enabled
INFO - 2024-10-28 08:46:24 --> Utf8 Class Initialized
INFO - 2024-10-28 08:46:24 --> URI Class Initialized
INFO - 2024-10-28 08:46:24 --> Router Class Initialized
INFO - 2024-10-28 08:46:24 --> Output Class Initialized
INFO - 2024-10-28 08:46:24 --> Security Class Initialized
DEBUG - 2024-10-28 08:46:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-28 08:46:24 --> Input Class Initialized
INFO - 2024-10-28 08:46:24 --> Language Class Initialized
INFO - 2024-10-28 08:46:24 --> Language Class Initialized
INFO - 2024-10-28 08:46:24 --> Config Class Initialized
INFO - 2024-10-28 08:46:24 --> Loader Class Initialized
INFO - 2024-10-28 08:46:24 --> Helper loaded: url_helper
INFO - 2024-10-28 08:46:24 --> Helper loaded: file_helper
INFO - 2024-10-28 08:46:24 --> Helper loaded: form_helper
INFO - 2024-10-28 08:46:24 --> Helper loaded: my_helper
INFO - 2024-10-28 08:46:24 --> Database Driver Class Initialized
INFO - 2024-10-28 08:46:24 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-28 08:46:24 --> Controller Class Initialized
INFO - 2024-10-28 08:46:24 --> Config Class Initialized
INFO - 2024-10-28 08:46:24 --> Hooks Class Initialized
DEBUG - 2024-10-28 08:46:24 --> UTF-8 Support Enabled
INFO - 2024-10-28 08:46:24 --> Utf8 Class Initialized
INFO - 2024-10-28 08:46:24 --> URI Class Initialized
INFO - 2024-10-28 08:46:24 --> Router Class Initialized
INFO - 2024-10-28 08:46:24 --> Output Class Initialized
INFO - 2024-10-28 08:46:24 --> Security Class Initialized
DEBUG - 2024-10-28 08:46:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-28 08:46:24 --> Input Class Initialized
INFO - 2024-10-28 08:46:24 --> Language Class Initialized
INFO - 2024-10-28 08:46:24 --> Language Class Initialized
INFO - 2024-10-28 08:46:24 --> Config Class Initialized
INFO - 2024-10-28 08:46:24 --> Loader Class Initialized
INFO - 2024-10-28 08:46:24 --> Helper loaded: url_helper
INFO - 2024-10-28 08:46:24 --> Helper loaded: file_helper
INFO - 2024-10-28 08:46:24 --> Helper loaded: form_helper
INFO - 2024-10-28 08:46:24 --> Helper loaded: my_helper
INFO - 2024-10-28 08:46:24 --> Database Driver Class Initialized
INFO - 2024-10-28 08:46:24 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-28 08:46:24 --> Controller Class Initialized
INFO - 2024-10-28 08:46:25 --> Config Class Initialized
INFO - 2024-10-28 08:46:25 --> Hooks Class Initialized
DEBUG - 2024-10-28 08:46:25 --> UTF-8 Support Enabled
INFO - 2024-10-28 08:46:25 --> Utf8 Class Initialized
INFO - 2024-10-28 08:46:25 --> URI Class Initialized
INFO - 2024-10-28 08:46:25 --> Router Class Initialized
INFO - 2024-10-28 08:46:25 --> Output Class Initialized
INFO - 2024-10-28 08:46:25 --> Security Class Initialized
DEBUG - 2024-10-28 08:46:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-28 08:46:25 --> Input Class Initialized
INFO - 2024-10-28 08:46:25 --> Language Class Initialized
INFO - 2024-10-28 08:46:25 --> Language Class Initialized
INFO - 2024-10-28 08:46:25 --> Config Class Initialized
INFO - 2024-10-28 08:46:25 --> Loader Class Initialized
INFO - 2024-10-28 08:46:25 --> Helper loaded: url_helper
INFO - 2024-10-28 08:46:25 --> Helper loaded: file_helper
INFO - 2024-10-28 08:46:25 --> Helper loaded: form_helper
INFO - 2024-10-28 08:46:25 --> Helper loaded: my_helper
INFO - 2024-10-28 08:46:25 --> Database Driver Class Initialized
INFO - 2024-10-28 08:46:25 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-28 08:46:25 --> Controller Class Initialized
INFO - 2024-10-28 08:46:27 --> Config Class Initialized
INFO - 2024-10-28 08:46:27 --> Hooks Class Initialized
DEBUG - 2024-10-28 08:46:27 --> UTF-8 Support Enabled
INFO - 2024-10-28 08:46:27 --> Utf8 Class Initialized
INFO - 2024-10-28 08:46:27 --> URI Class Initialized
INFO - 2024-10-28 08:46:27 --> Router Class Initialized
INFO - 2024-10-28 08:46:27 --> Output Class Initialized
INFO - 2024-10-28 08:46:27 --> Security Class Initialized
DEBUG - 2024-10-28 08:46:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-28 08:46:27 --> Input Class Initialized
INFO - 2024-10-28 08:46:27 --> Language Class Initialized
INFO - 2024-10-28 08:46:27 --> Language Class Initialized
INFO - 2024-10-28 08:46:27 --> Config Class Initialized
INFO - 2024-10-28 08:46:27 --> Loader Class Initialized
INFO - 2024-10-28 08:46:27 --> Helper loaded: url_helper
INFO - 2024-10-28 08:46:27 --> Helper loaded: file_helper
INFO - 2024-10-28 08:46:27 --> Helper loaded: form_helper
INFO - 2024-10-28 08:46:27 --> Helper loaded: my_helper
INFO - 2024-10-28 08:46:27 --> Database Driver Class Initialized
INFO - 2024-10-28 08:46:27 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-28 08:46:27 --> Controller Class Initialized
ERROR - 2024-10-28 08:46:27 --> Severity: Notice --> Undefined variable: status_form /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/data_siswa/views/form.php 231
DEBUG - 2024-10-28 08:46:27 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/data_siswa/views/form.php
DEBUG - 2024-10-28 08:46:27 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-10-28 08:46:27 --> Final output sent to browser
DEBUG - 2024-10-28 08:46:27 --> Total execution time: 0.0326
INFO - 2024-10-28 08:46:55 --> Config Class Initialized
INFO - 2024-10-28 08:46:55 --> Hooks Class Initialized
DEBUG - 2024-10-28 08:46:55 --> UTF-8 Support Enabled
INFO - 2024-10-28 08:46:55 --> Utf8 Class Initialized
INFO - 2024-10-28 08:46:55 --> URI Class Initialized
INFO - 2024-10-28 08:46:55 --> Router Class Initialized
INFO - 2024-10-28 08:46:55 --> Output Class Initialized
INFO - 2024-10-28 08:46:55 --> Security Class Initialized
DEBUG - 2024-10-28 08:46:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-28 08:46:55 --> Input Class Initialized
INFO - 2024-10-28 08:46:55 --> Language Class Initialized
INFO - 2024-10-28 08:46:55 --> Language Class Initialized
INFO - 2024-10-28 08:46:55 --> Config Class Initialized
INFO - 2024-10-28 08:46:55 --> Loader Class Initialized
INFO - 2024-10-28 08:46:55 --> Helper loaded: url_helper
INFO - 2024-10-28 08:46:55 --> Helper loaded: file_helper
INFO - 2024-10-28 08:46:55 --> Helper loaded: form_helper
INFO - 2024-10-28 08:46:55 --> Helper loaded: my_helper
INFO - 2024-10-28 08:46:55 --> Database Driver Class Initialized
INFO - 2024-10-28 08:46:55 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-28 08:46:55 --> Controller Class Initialized
INFO - 2024-10-28 08:46:55 --> Upload Class Initialized
INFO - 2024-10-28 08:46:55 --> Language file loaded: language/english/upload_lang.php
ERROR - 2024-10-28 08:46:55 --> The upload path does not appear to be valid.
INFO - 2024-10-28 08:46:55 --> Config Class Initialized
INFO - 2024-10-28 08:46:55 --> Hooks Class Initialized
DEBUG - 2024-10-28 08:46:55 --> UTF-8 Support Enabled
INFO - 2024-10-28 08:46:55 --> Utf8 Class Initialized
INFO - 2024-10-28 08:46:55 --> URI Class Initialized
INFO - 2024-10-28 08:46:55 --> Router Class Initialized
INFO - 2024-10-28 08:46:55 --> Output Class Initialized
INFO - 2024-10-28 08:46:55 --> Security Class Initialized
DEBUG - 2024-10-28 08:46:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-28 08:46:55 --> Input Class Initialized
INFO - 2024-10-28 08:46:55 --> Language Class Initialized
INFO - 2024-10-28 08:46:55 --> Language Class Initialized
INFO - 2024-10-28 08:46:55 --> Config Class Initialized
INFO - 2024-10-28 08:46:55 --> Loader Class Initialized
INFO - 2024-10-28 08:46:55 --> Helper loaded: url_helper
INFO - 2024-10-28 08:46:55 --> Helper loaded: file_helper
INFO - 2024-10-28 08:46:55 --> Helper loaded: form_helper
INFO - 2024-10-28 08:46:55 --> Helper loaded: my_helper
INFO - 2024-10-28 08:46:55 --> Database Driver Class Initialized
INFO - 2024-10-28 08:46:55 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-28 08:46:55 --> Controller Class Initialized
DEBUG - 2024-10-28 08:46:55 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/data_siswa/views/list.php
DEBUG - 2024-10-28 08:46:55 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-10-28 08:46:55 --> Final output sent to browser
DEBUG - 2024-10-28 08:46:55 --> Total execution time: 0.0270
INFO - 2024-10-28 08:46:55 --> Config Class Initialized
INFO - 2024-10-28 08:46:55 --> Hooks Class Initialized
DEBUG - 2024-10-28 08:46:55 --> UTF-8 Support Enabled
INFO - 2024-10-28 08:46:55 --> Utf8 Class Initialized
INFO - 2024-10-28 08:46:55 --> URI Class Initialized
INFO - 2024-10-28 08:46:55 --> Router Class Initialized
INFO - 2024-10-28 08:46:55 --> Output Class Initialized
INFO - 2024-10-28 08:46:55 --> Security Class Initialized
DEBUG - 2024-10-28 08:46:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-28 08:46:55 --> Input Class Initialized
INFO - 2024-10-28 08:46:55 --> Language Class Initialized
ERROR - 2024-10-28 08:46:55 --> 404 Page Not Found: /index
INFO - 2024-10-28 08:46:55 --> Config Class Initialized
INFO - 2024-10-28 08:46:55 --> Hooks Class Initialized
DEBUG - 2024-10-28 08:46:55 --> UTF-8 Support Enabled
INFO - 2024-10-28 08:46:55 --> Utf8 Class Initialized
INFO - 2024-10-28 08:46:55 --> URI Class Initialized
INFO - 2024-10-28 08:46:55 --> Router Class Initialized
INFO - 2024-10-28 08:46:55 --> Output Class Initialized
INFO - 2024-10-28 08:46:55 --> Security Class Initialized
DEBUG - 2024-10-28 08:46:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-28 08:46:55 --> Input Class Initialized
INFO - 2024-10-28 08:46:55 --> Language Class Initialized
INFO - 2024-10-28 08:46:55 --> Language Class Initialized
INFO - 2024-10-28 08:46:55 --> Config Class Initialized
INFO - 2024-10-28 08:46:55 --> Loader Class Initialized
INFO - 2024-10-28 08:46:55 --> Helper loaded: url_helper
INFO - 2024-10-28 08:46:55 --> Helper loaded: file_helper
INFO - 2024-10-28 08:46:55 --> Helper loaded: form_helper
INFO - 2024-10-28 08:46:55 --> Helper loaded: my_helper
INFO - 2024-10-28 08:46:55 --> Database Driver Class Initialized
INFO - 2024-10-28 08:46:55 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-28 08:46:55 --> Controller Class Initialized
INFO - 2024-10-28 08:46:58 --> Config Class Initialized
INFO - 2024-10-28 08:46:58 --> Hooks Class Initialized
DEBUG - 2024-10-28 08:46:58 --> UTF-8 Support Enabled
INFO - 2024-10-28 08:46:58 --> Utf8 Class Initialized
INFO - 2024-10-28 08:46:58 --> URI Class Initialized
INFO - 2024-10-28 08:46:58 --> Router Class Initialized
INFO - 2024-10-28 08:46:58 --> Output Class Initialized
INFO - 2024-10-28 08:46:58 --> Security Class Initialized
DEBUG - 2024-10-28 08:46:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-28 08:46:58 --> Input Class Initialized
INFO - 2024-10-28 08:46:58 --> Language Class Initialized
INFO - 2024-10-28 08:46:58 --> Language Class Initialized
INFO - 2024-10-28 08:46:58 --> Config Class Initialized
INFO - 2024-10-28 08:46:58 --> Loader Class Initialized
INFO - 2024-10-28 08:46:58 --> Helper loaded: url_helper
INFO - 2024-10-28 08:46:58 --> Helper loaded: file_helper
INFO - 2024-10-28 08:46:58 --> Helper loaded: form_helper
INFO - 2024-10-28 08:46:58 --> Helper loaded: my_helper
INFO - 2024-10-28 08:46:58 --> Database Driver Class Initialized
INFO - 2024-10-28 08:46:58 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-28 08:46:58 --> Controller Class Initialized
INFO - 2024-10-28 08:46:59 --> Config Class Initialized
INFO - 2024-10-28 08:46:59 --> Hooks Class Initialized
DEBUG - 2024-10-28 08:46:59 --> UTF-8 Support Enabled
INFO - 2024-10-28 08:46:59 --> Utf8 Class Initialized
INFO - 2024-10-28 08:46:59 --> URI Class Initialized
INFO - 2024-10-28 08:46:59 --> Router Class Initialized
INFO - 2024-10-28 08:46:59 --> Output Class Initialized
INFO - 2024-10-28 08:46:59 --> Security Class Initialized
DEBUG - 2024-10-28 08:46:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-28 08:46:59 --> Input Class Initialized
INFO - 2024-10-28 08:46:59 --> Language Class Initialized
INFO - 2024-10-28 08:46:59 --> Language Class Initialized
INFO - 2024-10-28 08:46:59 --> Config Class Initialized
INFO - 2024-10-28 08:46:59 --> Loader Class Initialized
INFO - 2024-10-28 08:46:59 --> Helper loaded: url_helper
INFO - 2024-10-28 08:46:59 --> Helper loaded: file_helper
INFO - 2024-10-28 08:46:59 --> Helper loaded: form_helper
INFO - 2024-10-28 08:46:59 --> Helper loaded: my_helper
INFO - 2024-10-28 08:46:59 --> Database Driver Class Initialized
INFO - 2024-10-28 08:46:59 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-28 08:46:59 --> Controller Class Initialized
INFO - 2024-10-28 08:47:00 --> Config Class Initialized
INFO - 2024-10-28 08:47:00 --> Hooks Class Initialized
DEBUG - 2024-10-28 08:47:00 --> UTF-8 Support Enabled
INFO - 2024-10-28 08:47:00 --> Utf8 Class Initialized
INFO - 2024-10-28 08:47:00 --> URI Class Initialized
INFO - 2024-10-28 08:47:00 --> Router Class Initialized
INFO - 2024-10-28 08:47:00 --> Output Class Initialized
INFO - 2024-10-28 08:47:00 --> Security Class Initialized
DEBUG - 2024-10-28 08:47:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-28 08:47:00 --> Input Class Initialized
INFO - 2024-10-28 08:47:00 --> Language Class Initialized
INFO - 2024-10-28 08:47:00 --> Language Class Initialized
INFO - 2024-10-28 08:47:00 --> Config Class Initialized
INFO - 2024-10-28 08:47:00 --> Loader Class Initialized
INFO - 2024-10-28 08:47:00 --> Helper loaded: url_helper
INFO - 2024-10-28 08:47:00 --> Helper loaded: file_helper
INFO - 2024-10-28 08:47:00 --> Helper loaded: form_helper
INFO - 2024-10-28 08:47:00 --> Helper loaded: my_helper
INFO - 2024-10-28 08:47:00 --> Database Driver Class Initialized
INFO - 2024-10-28 08:47:00 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-28 08:47:00 --> Controller Class Initialized
INFO - 2024-10-28 08:47:02 --> Config Class Initialized
INFO - 2024-10-28 08:47:02 --> Hooks Class Initialized
DEBUG - 2024-10-28 08:47:02 --> UTF-8 Support Enabled
INFO - 2024-10-28 08:47:02 --> Utf8 Class Initialized
INFO - 2024-10-28 08:47:02 --> URI Class Initialized
INFO - 2024-10-28 08:47:02 --> Router Class Initialized
INFO - 2024-10-28 08:47:02 --> Output Class Initialized
INFO - 2024-10-28 08:47:02 --> Security Class Initialized
DEBUG - 2024-10-28 08:47:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-28 08:47:02 --> Input Class Initialized
INFO - 2024-10-28 08:47:02 --> Language Class Initialized
INFO - 2024-10-28 08:47:02 --> Language Class Initialized
INFO - 2024-10-28 08:47:02 --> Config Class Initialized
INFO - 2024-10-28 08:47:02 --> Loader Class Initialized
INFO - 2024-10-28 08:47:02 --> Helper loaded: url_helper
INFO - 2024-10-28 08:47:02 --> Helper loaded: file_helper
INFO - 2024-10-28 08:47:02 --> Helper loaded: form_helper
INFO - 2024-10-28 08:47:02 --> Helper loaded: my_helper
INFO - 2024-10-28 08:47:02 --> Database Driver Class Initialized
INFO - 2024-10-28 08:47:02 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-28 08:47:02 --> Controller Class Initialized
ERROR - 2024-10-28 08:47:02 --> Severity: Notice --> Undefined variable: status_form /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/data_siswa/views/form.php 231
DEBUG - 2024-10-28 08:47:02 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/data_siswa/views/form.php
DEBUG - 2024-10-28 08:47:02 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-10-28 08:47:02 --> Final output sent to browser
DEBUG - 2024-10-28 08:47:02 --> Total execution time: 0.0290
INFO - 2024-10-28 08:47:32 --> Config Class Initialized
INFO - 2024-10-28 08:47:32 --> Hooks Class Initialized
DEBUG - 2024-10-28 08:47:32 --> UTF-8 Support Enabled
INFO - 2024-10-28 08:47:32 --> Utf8 Class Initialized
INFO - 2024-10-28 08:47:32 --> URI Class Initialized
INFO - 2024-10-28 08:47:32 --> Router Class Initialized
INFO - 2024-10-28 08:47:32 --> Output Class Initialized
INFO - 2024-10-28 08:47:32 --> Security Class Initialized
DEBUG - 2024-10-28 08:47:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-28 08:47:32 --> Input Class Initialized
INFO - 2024-10-28 08:47:32 --> Language Class Initialized
INFO - 2024-10-28 08:47:32 --> Language Class Initialized
INFO - 2024-10-28 08:47:32 --> Config Class Initialized
INFO - 2024-10-28 08:47:32 --> Loader Class Initialized
INFO - 2024-10-28 08:47:32 --> Helper loaded: url_helper
INFO - 2024-10-28 08:47:32 --> Helper loaded: file_helper
INFO - 2024-10-28 08:47:32 --> Helper loaded: form_helper
INFO - 2024-10-28 08:47:32 --> Helper loaded: my_helper
INFO - 2024-10-28 08:47:32 --> Database Driver Class Initialized
INFO - 2024-10-28 08:47:32 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-28 08:47:32 --> Controller Class Initialized
INFO - 2024-10-28 08:47:32 --> Upload Class Initialized
INFO - 2024-10-28 08:47:32 --> Language file loaded: language/english/upload_lang.php
ERROR - 2024-10-28 08:47:32 --> The upload path does not appear to be valid.
INFO - 2024-10-28 08:47:33 --> Config Class Initialized
INFO - 2024-10-28 08:47:33 --> Hooks Class Initialized
DEBUG - 2024-10-28 08:47:33 --> UTF-8 Support Enabled
INFO - 2024-10-28 08:47:33 --> Utf8 Class Initialized
INFO - 2024-10-28 08:47:33 --> URI Class Initialized
INFO - 2024-10-28 08:47:33 --> Router Class Initialized
INFO - 2024-10-28 08:47:33 --> Output Class Initialized
INFO - 2024-10-28 08:47:33 --> Security Class Initialized
DEBUG - 2024-10-28 08:47:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-28 08:47:33 --> Input Class Initialized
INFO - 2024-10-28 08:47:33 --> Language Class Initialized
INFO - 2024-10-28 08:47:33 --> Language Class Initialized
INFO - 2024-10-28 08:47:33 --> Config Class Initialized
INFO - 2024-10-28 08:47:33 --> Loader Class Initialized
INFO - 2024-10-28 08:47:33 --> Helper loaded: url_helper
INFO - 2024-10-28 08:47:33 --> Helper loaded: file_helper
INFO - 2024-10-28 08:47:33 --> Helper loaded: form_helper
INFO - 2024-10-28 08:47:33 --> Helper loaded: my_helper
INFO - 2024-10-28 08:47:33 --> Database Driver Class Initialized
INFO - 2024-10-28 08:47:33 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-28 08:47:33 --> Controller Class Initialized
DEBUG - 2024-10-28 08:47:33 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/data_siswa/views/list.php
DEBUG - 2024-10-28 08:47:33 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-10-28 08:47:33 --> Final output sent to browser
DEBUG - 2024-10-28 08:47:33 --> Total execution time: 0.0478
INFO - 2024-10-28 08:47:33 --> Config Class Initialized
INFO - 2024-10-28 08:47:33 --> Hooks Class Initialized
DEBUG - 2024-10-28 08:47:33 --> UTF-8 Support Enabled
INFO - 2024-10-28 08:47:33 --> Utf8 Class Initialized
INFO - 2024-10-28 08:47:33 --> URI Class Initialized
INFO - 2024-10-28 08:47:33 --> Router Class Initialized
INFO - 2024-10-28 08:47:33 --> Output Class Initialized
INFO - 2024-10-28 08:47:33 --> Security Class Initialized
DEBUG - 2024-10-28 08:47:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-28 08:47:33 --> Input Class Initialized
INFO - 2024-10-28 08:47:33 --> Language Class Initialized
ERROR - 2024-10-28 08:47:33 --> 404 Page Not Found: /index
INFO - 2024-10-28 08:47:33 --> Config Class Initialized
INFO - 2024-10-28 08:47:33 --> Hooks Class Initialized
DEBUG - 2024-10-28 08:47:33 --> UTF-8 Support Enabled
INFO - 2024-10-28 08:47:33 --> Utf8 Class Initialized
INFO - 2024-10-28 08:47:33 --> URI Class Initialized
INFO - 2024-10-28 08:47:33 --> Router Class Initialized
INFO - 2024-10-28 08:47:33 --> Output Class Initialized
INFO - 2024-10-28 08:47:33 --> Security Class Initialized
DEBUG - 2024-10-28 08:47:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-28 08:47:33 --> Input Class Initialized
INFO - 2024-10-28 08:47:33 --> Language Class Initialized
INFO - 2024-10-28 08:47:33 --> Language Class Initialized
INFO - 2024-10-28 08:47:33 --> Config Class Initialized
INFO - 2024-10-28 08:47:33 --> Loader Class Initialized
INFO - 2024-10-28 08:47:33 --> Helper loaded: url_helper
INFO - 2024-10-28 08:47:33 --> Helper loaded: file_helper
INFO - 2024-10-28 08:47:33 --> Helper loaded: form_helper
INFO - 2024-10-28 08:47:33 --> Helper loaded: my_helper
INFO - 2024-10-28 08:47:33 --> Database Driver Class Initialized
INFO - 2024-10-28 08:47:33 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-28 08:47:33 --> Controller Class Initialized
INFO - 2024-10-28 08:47:35 --> Config Class Initialized
INFO - 2024-10-28 08:47:35 --> Hooks Class Initialized
DEBUG - 2024-10-28 08:47:35 --> UTF-8 Support Enabled
INFO - 2024-10-28 08:47:35 --> Utf8 Class Initialized
INFO - 2024-10-28 08:47:35 --> URI Class Initialized
INFO - 2024-10-28 08:47:35 --> Router Class Initialized
INFO - 2024-10-28 08:47:35 --> Output Class Initialized
INFO - 2024-10-28 08:47:35 --> Security Class Initialized
DEBUG - 2024-10-28 08:47:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-28 08:47:35 --> Input Class Initialized
INFO - 2024-10-28 08:47:35 --> Language Class Initialized
INFO - 2024-10-28 08:47:35 --> Language Class Initialized
INFO - 2024-10-28 08:47:35 --> Config Class Initialized
INFO - 2024-10-28 08:47:35 --> Loader Class Initialized
INFO - 2024-10-28 08:47:35 --> Helper loaded: url_helper
INFO - 2024-10-28 08:47:35 --> Helper loaded: file_helper
INFO - 2024-10-28 08:47:35 --> Helper loaded: form_helper
INFO - 2024-10-28 08:47:35 --> Helper loaded: my_helper
INFO - 2024-10-28 08:47:35 --> Database Driver Class Initialized
INFO - 2024-10-28 08:47:35 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-28 08:47:35 --> Controller Class Initialized
INFO - 2024-10-28 08:47:35 --> Helper loaded: cookie_helper
INFO - 2024-10-28 08:47:35 --> Config Class Initialized
INFO - 2024-10-28 08:47:35 --> Hooks Class Initialized
DEBUG - 2024-10-28 08:47:35 --> UTF-8 Support Enabled
INFO - 2024-10-28 08:47:35 --> Utf8 Class Initialized
INFO - 2024-10-28 08:47:35 --> URI Class Initialized
INFO - 2024-10-28 08:47:35 --> Router Class Initialized
INFO - 2024-10-28 08:47:35 --> Output Class Initialized
INFO - 2024-10-28 08:47:35 --> Security Class Initialized
DEBUG - 2024-10-28 08:47:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-28 08:47:35 --> Input Class Initialized
INFO - 2024-10-28 08:47:35 --> Language Class Initialized
INFO - 2024-10-28 08:47:35 --> Language Class Initialized
INFO - 2024-10-28 08:47:35 --> Config Class Initialized
INFO - 2024-10-28 08:47:35 --> Loader Class Initialized
INFO - 2024-10-28 08:47:35 --> Helper loaded: url_helper
INFO - 2024-10-28 08:47:35 --> Helper loaded: file_helper
INFO - 2024-10-28 08:47:35 --> Helper loaded: form_helper
INFO - 2024-10-28 08:47:35 --> Helper loaded: my_helper
INFO - 2024-10-28 08:47:35 --> Database Driver Class Initialized
INFO - 2024-10-28 08:47:35 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-28 08:47:35 --> Controller Class Initialized
INFO - 2024-10-28 08:47:35 --> Config Class Initialized
INFO - 2024-10-28 08:47:35 --> Hooks Class Initialized
DEBUG - 2024-10-28 08:47:35 --> UTF-8 Support Enabled
INFO - 2024-10-28 08:47:35 --> Utf8 Class Initialized
INFO - 2024-10-28 08:47:35 --> URI Class Initialized
INFO - 2024-10-28 08:47:35 --> Router Class Initialized
INFO - 2024-10-28 08:47:35 --> Output Class Initialized
INFO - 2024-10-28 08:47:35 --> Security Class Initialized
DEBUG - 2024-10-28 08:47:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-28 08:47:35 --> Input Class Initialized
INFO - 2024-10-28 08:47:35 --> Language Class Initialized
INFO - 2024-10-28 08:47:35 --> Language Class Initialized
INFO - 2024-10-28 08:47:35 --> Config Class Initialized
INFO - 2024-10-28 08:47:35 --> Loader Class Initialized
INFO - 2024-10-28 08:47:35 --> Helper loaded: url_helper
INFO - 2024-10-28 08:47:35 --> Helper loaded: file_helper
INFO - 2024-10-28 08:47:35 --> Helper loaded: form_helper
INFO - 2024-10-28 08:47:35 --> Helper loaded: my_helper
INFO - 2024-10-28 08:47:35 --> Database Driver Class Initialized
INFO - 2024-10-28 08:47:35 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-28 08:47:35 --> Controller Class Initialized
DEBUG - 2024-10-28 08:47:35 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/login/views/login.php
DEBUG - 2024-10-28 08:47:35 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-10-28 08:47:35 --> Final output sent to browser
DEBUG - 2024-10-28 08:47:35 --> Total execution time: 0.0393
INFO - 2024-10-28 08:47:43 --> Config Class Initialized
INFO - 2024-10-28 08:47:43 --> Hooks Class Initialized
DEBUG - 2024-10-28 08:47:43 --> UTF-8 Support Enabled
INFO - 2024-10-28 08:47:43 --> Utf8 Class Initialized
INFO - 2024-10-28 08:47:43 --> URI Class Initialized
INFO - 2024-10-28 08:47:43 --> Router Class Initialized
INFO - 2024-10-28 08:47:43 --> Output Class Initialized
INFO - 2024-10-28 08:47:43 --> Security Class Initialized
DEBUG - 2024-10-28 08:47:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-28 08:47:43 --> Input Class Initialized
INFO - 2024-10-28 08:47:43 --> Language Class Initialized
INFO - 2024-10-28 08:47:43 --> Language Class Initialized
INFO - 2024-10-28 08:47:43 --> Config Class Initialized
INFO - 2024-10-28 08:47:43 --> Loader Class Initialized
INFO - 2024-10-28 08:47:43 --> Helper loaded: url_helper
INFO - 2024-10-28 08:47:43 --> Helper loaded: file_helper
INFO - 2024-10-28 08:47:43 --> Helper loaded: form_helper
INFO - 2024-10-28 08:47:43 --> Helper loaded: my_helper
INFO - 2024-10-28 08:47:43 --> Database Driver Class Initialized
INFO - 2024-10-28 08:47:43 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-28 08:47:43 --> Controller Class Initialized
INFO - 2024-10-28 08:47:43 --> Helper loaded: cookie_helper
INFO - 2024-10-28 08:47:43 --> Final output sent to browser
DEBUG - 2024-10-28 08:47:43 --> Total execution time: 0.0287
INFO - 2024-10-28 08:47:43 --> Config Class Initialized
INFO - 2024-10-28 08:47:43 --> Hooks Class Initialized
DEBUG - 2024-10-28 08:47:43 --> UTF-8 Support Enabled
INFO - 2024-10-28 08:47:43 --> Utf8 Class Initialized
INFO - 2024-10-28 08:47:43 --> URI Class Initialized
INFO - 2024-10-28 08:47:43 --> Router Class Initialized
INFO - 2024-10-28 08:47:43 --> Output Class Initialized
INFO - 2024-10-28 08:47:43 --> Security Class Initialized
DEBUG - 2024-10-28 08:47:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-28 08:47:43 --> Input Class Initialized
INFO - 2024-10-28 08:47:43 --> Language Class Initialized
INFO - 2024-10-28 08:47:43 --> Language Class Initialized
INFO - 2024-10-28 08:47:43 --> Config Class Initialized
INFO - 2024-10-28 08:47:43 --> Loader Class Initialized
INFO - 2024-10-28 08:47:43 --> Helper loaded: url_helper
INFO - 2024-10-28 08:47:43 --> Helper loaded: file_helper
INFO - 2024-10-28 08:47:43 --> Helper loaded: form_helper
INFO - 2024-10-28 08:47:43 --> Helper loaded: my_helper
INFO - 2024-10-28 08:47:43 --> Database Driver Class Initialized
INFO - 2024-10-28 08:47:43 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-28 08:47:43 --> Controller Class Initialized
DEBUG - 2024-10-28 08:47:43 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/home/views/v_home_guru.php
DEBUG - 2024-10-28 08:47:43 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-10-28 08:47:43 --> Final output sent to browser
DEBUG - 2024-10-28 08:47:43 --> Total execution time: 0.0334
INFO - 2024-10-28 08:47:49 --> Config Class Initialized
INFO - 2024-10-28 08:47:49 --> Hooks Class Initialized
DEBUG - 2024-10-28 08:47:49 --> UTF-8 Support Enabled
INFO - 2024-10-28 08:47:49 --> Utf8 Class Initialized
INFO - 2024-10-28 08:47:49 --> URI Class Initialized
INFO - 2024-10-28 08:47:49 --> Router Class Initialized
INFO - 2024-10-28 08:47:49 --> Output Class Initialized
INFO - 2024-10-28 08:47:49 --> Security Class Initialized
DEBUG - 2024-10-28 08:47:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-28 08:47:49 --> Input Class Initialized
INFO - 2024-10-28 08:47:49 --> Language Class Initialized
INFO - 2024-10-28 08:47:49 --> Language Class Initialized
INFO - 2024-10-28 08:47:49 --> Config Class Initialized
INFO - 2024-10-28 08:47:49 --> Loader Class Initialized
INFO - 2024-10-28 08:47:49 --> Helper loaded: url_helper
INFO - 2024-10-28 08:47:49 --> Helper loaded: file_helper
INFO - 2024-10-28 08:47:49 --> Helper loaded: form_helper
INFO - 2024-10-28 08:47:49 --> Helper loaded: my_helper
INFO - 2024-10-28 08:47:49 --> Database Driver Class Initialized
INFO - 2024-10-28 08:47:49 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-28 08:47:49 --> Controller Class Initialized
DEBUG - 2024-10-28 08:47:49 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/list.php
DEBUG - 2024-10-28 08:47:49 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-10-28 08:47:49 --> Final output sent to browser
DEBUG - 2024-10-28 08:47:49 --> Total execution time: 0.0296
INFO - 2024-10-28 08:47:59 --> Config Class Initialized
INFO - 2024-10-28 08:47:59 --> Hooks Class Initialized
DEBUG - 2024-10-28 08:47:59 --> UTF-8 Support Enabled
INFO - 2024-10-28 08:47:59 --> Utf8 Class Initialized
INFO - 2024-10-28 08:47:59 --> URI Class Initialized
INFO - 2024-10-28 08:47:59 --> Router Class Initialized
INFO - 2024-10-28 08:47:59 --> Output Class Initialized
INFO - 2024-10-28 08:47:59 --> Security Class Initialized
DEBUG - 2024-10-28 08:47:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-28 08:47:59 --> Input Class Initialized
INFO - 2024-10-28 08:47:59 --> Language Class Initialized
INFO - 2024-10-28 08:47:59 --> Language Class Initialized
INFO - 2024-10-28 08:47:59 --> Config Class Initialized
INFO - 2024-10-28 08:47:59 --> Loader Class Initialized
INFO - 2024-10-28 08:47:59 --> Helper loaded: url_helper
INFO - 2024-10-28 08:47:59 --> Helper loaded: file_helper
INFO - 2024-10-28 08:47:59 --> Helper loaded: form_helper
INFO - 2024-10-28 08:47:59 --> Helper loaded: my_helper
INFO - 2024-10-28 08:47:59 --> Database Driver Class Initialized
INFO - 2024-10-28 08:47:59 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-28 08:47:59 --> Controller Class Initialized
DEBUG - 2024-10-28 08:47:59 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php
INFO - 2024-10-28 08:48:02 --> Final output sent to browser
DEBUG - 2024-10-28 08:48:02 --> Total execution time: 3.5002
INFO - 2024-10-28 09:08:48 --> Config Class Initialized
INFO - 2024-10-28 09:08:48 --> Hooks Class Initialized
DEBUG - 2024-10-28 09:08:48 --> UTF-8 Support Enabled
INFO - 2024-10-28 09:08:48 --> Utf8 Class Initialized
INFO - 2024-10-28 09:08:48 --> URI Class Initialized
INFO - 2024-10-28 09:08:48 --> Router Class Initialized
INFO - 2024-10-28 09:08:48 --> Output Class Initialized
INFO - 2024-10-28 09:08:48 --> Security Class Initialized
DEBUG - 2024-10-28 09:08:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-28 09:08:48 --> Input Class Initialized
INFO - 2024-10-28 09:08:48 --> Language Class Initialized
INFO - 2024-10-28 09:08:48 --> Language Class Initialized
INFO - 2024-10-28 09:08:48 --> Config Class Initialized
INFO - 2024-10-28 09:08:48 --> Loader Class Initialized
INFO - 2024-10-28 09:08:48 --> Helper loaded: url_helper
INFO - 2024-10-28 09:08:48 --> Helper loaded: file_helper
INFO - 2024-10-28 09:08:48 --> Helper loaded: form_helper
INFO - 2024-10-28 09:08:48 --> Helper loaded: my_helper
INFO - 2024-10-28 09:08:48 --> Database Driver Class Initialized
INFO - 2024-10-28 09:08:48 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-28 09:08:48 --> Controller Class Initialized
DEBUG - 2024-10-28 09:08:48 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/list.php
DEBUG - 2024-10-28 09:08:48 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-10-28 09:08:48 --> Final output sent to browser
DEBUG - 2024-10-28 09:08:48 --> Total execution time: 0.0492
INFO - 2024-10-28 09:08:51 --> Config Class Initialized
INFO - 2024-10-28 09:08:51 --> Hooks Class Initialized
DEBUG - 2024-10-28 09:08:51 --> UTF-8 Support Enabled
INFO - 2024-10-28 09:08:51 --> Utf8 Class Initialized
INFO - 2024-10-28 09:08:51 --> URI Class Initialized
INFO - 2024-10-28 09:08:51 --> Router Class Initialized
INFO - 2024-10-28 09:08:51 --> Output Class Initialized
INFO - 2024-10-28 09:08:51 --> Security Class Initialized
DEBUG - 2024-10-28 09:08:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-28 09:08:51 --> Input Class Initialized
INFO - 2024-10-28 09:08:51 --> Language Class Initialized
INFO - 2024-10-28 09:08:51 --> Language Class Initialized
INFO - 2024-10-28 09:08:51 --> Config Class Initialized
INFO - 2024-10-28 09:08:51 --> Loader Class Initialized
INFO - 2024-10-28 09:08:51 --> Helper loaded: url_helper
INFO - 2024-10-28 09:08:51 --> Helper loaded: file_helper
INFO - 2024-10-28 09:08:51 --> Helper loaded: form_helper
INFO - 2024-10-28 09:08:51 --> Helper loaded: my_helper
INFO - 2024-10-28 09:08:51 --> Database Driver Class Initialized
INFO - 2024-10-28 09:08:51 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-28 09:08:51 --> Controller Class Initialized
INFO - 2024-10-28 09:08:51 --> Helper loaded: cookie_helper
INFO - 2024-10-28 09:08:51 --> Config Class Initialized
INFO - 2024-10-28 09:08:51 --> Hooks Class Initialized
DEBUG - 2024-10-28 09:08:51 --> UTF-8 Support Enabled
INFO - 2024-10-28 09:08:51 --> Utf8 Class Initialized
INFO - 2024-10-28 09:08:51 --> URI Class Initialized
INFO - 2024-10-28 09:08:51 --> Router Class Initialized
INFO - 2024-10-28 09:08:51 --> Output Class Initialized
INFO - 2024-10-28 09:08:51 --> Security Class Initialized
DEBUG - 2024-10-28 09:08:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-28 09:08:51 --> Input Class Initialized
INFO - 2024-10-28 09:08:51 --> Language Class Initialized
INFO - 2024-10-28 09:08:51 --> Language Class Initialized
INFO - 2024-10-28 09:08:51 --> Config Class Initialized
INFO - 2024-10-28 09:08:51 --> Loader Class Initialized
INFO - 2024-10-28 09:08:51 --> Helper loaded: url_helper
INFO - 2024-10-28 09:08:51 --> Helper loaded: file_helper
INFO - 2024-10-28 09:08:51 --> Helper loaded: form_helper
INFO - 2024-10-28 09:08:51 --> Helper loaded: my_helper
INFO - 2024-10-28 09:08:51 --> Database Driver Class Initialized
INFO - 2024-10-28 09:08:51 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-28 09:08:51 --> Controller Class Initialized
INFO - 2024-10-28 09:08:52 --> Config Class Initialized
INFO - 2024-10-28 09:08:52 --> Hooks Class Initialized
DEBUG - 2024-10-28 09:08:52 --> UTF-8 Support Enabled
INFO - 2024-10-28 09:08:52 --> Utf8 Class Initialized
INFO - 2024-10-28 09:08:52 --> URI Class Initialized
INFO - 2024-10-28 09:08:52 --> Router Class Initialized
INFO - 2024-10-28 09:08:52 --> Output Class Initialized
INFO - 2024-10-28 09:08:52 --> Security Class Initialized
DEBUG - 2024-10-28 09:08:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-28 09:08:52 --> Input Class Initialized
INFO - 2024-10-28 09:08:52 --> Language Class Initialized
INFO - 2024-10-28 09:08:52 --> Language Class Initialized
INFO - 2024-10-28 09:08:52 --> Config Class Initialized
INFO - 2024-10-28 09:08:52 --> Loader Class Initialized
INFO - 2024-10-28 09:08:52 --> Helper loaded: url_helper
INFO - 2024-10-28 09:08:52 --> Helper loaded: file_helper
INFO - 2024-10-28 09:08:52 --> Helper loaded: form_helper
INFO - 2024-10-28 09:08:52 --> Helper loaded: my_helper
INFO - 2024-10-28 09:08:52 --> Database Driver Class Initialized
INFO - 2024-10-28 09:08:52 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-28 09:08:52 --> Controller Class Initialized
DEBUG - 2024-10-28 09:08:52 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/login/views/login.php
DEBUG - 2024-10-28 09:08:52 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-10-28 09:08:52 --> Final output sent to browser
DEBUG - 2024-10-28 09:08:52 --> Total execution time: 0.0362
INFO - 2024-10-28 09:09:01 --> Config Class Initialized
INFO - 2024-10-28 09:09:01 --> Hooks Class Initialized
DEBUG - 2024-10-28 09:09:01 --> UTF-8 Support Enabled
INFO - 2024-10-28 09:09:01 --> Utf8 Class Initialized
INFO - 2024-10-28 09:09:01 --> URI Class Initialized
INFO - 2024-10-28 09:09:01 --> Router Class Initialized
INFO - 2024-10-28 09:09:01 --> Output Class Initialized
INFO - 2024-10-28 09:09:01 --> Security Class Initialized
DEBUG - 2024-10-28 09:09:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-28 09:09:01 --> Input Class Initialized
INFO - 2024-10-28 09:09:01 --> Language Class Initialized
INFO - 2024-10-28 09:09:01 --> Language Class Initialized
INFO - 2024-10-28 09:09:01 --> Config Class Initialized
INFO - 2024-10-28 09:09:01 --> Loader Class Initialized
INFO - 2024-10-28 09:09:01 --> Helper loaded: url_helper
INFO - 2024-10-28 09:09:01 --> Helper loaded: file_helper
INFO - 2024-10-28 09:09:01 --> Helper loaded: form_helper
INFO - 2024-10-28 09:09:01 --> Helper loaded: my_helper
INFO - 2024-10-28 09:09:01 --> Database Driver Class Initialized
INFO - 2024-10-28 09:09:01 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-28 09:09:01 --> Controller Class Initialized
INFO - 2024-10-28 09:09:01 --> Helper loaded: cookie_helper
INFO - 2024-10-28 09:09:01 --> Final output sent to browser
DEBUG - 2024-10-28 09:09:01 --> Total execution time: 0.0358
INFO - 2024-10-28 09:09:01 --> Config Class Initialized
INFO - 2024-10-28 09:09:01 --> Hooks Class Initialized
DEBUG - 2024-10-28 09:09:01 --> UTF-8 Support Enabled
INFO - 2024-10-28 09:09:01 --> Utf8 Class Initialized
INFO - 2024-10-28 09:09:01 --> URI Class Initialized
INFO - 2024-10-28 09:09:01 --> Router Class Initialized
INFO - 2024-10-28 09:09:01 --> Output Class Initialized
INFO - 2024-10-28 09:09:01 --> Security Class Initialized
DEBUG - 2024-10-28 09:09:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-28 09:09:01 --> Input Class Initialized
INFO - 2024-10-28 09:09:01 --> Language Class Initialized
INFO - 2024-10-28 09:09:01 --> Language Class Initialized
INFO - 2024-10-28 09:09:01 --> Config Class Initialized
INFO - 2024-10-28 09:09:01 --> Loader Class Initialized
INFO - 2024-10-28 09:09:01 --> Helper loaded: url_helper
INFO - 2024-10-28 09:09:01 --> Helper loaded: file_helper
INFO - 2024-10-28 09:09:01 --> Helper loaded: form_helper
INFO - 2024-10-28 09:09:01 --> Helper loaded: my_helper
INFO - 2024-10-28 09:09:01 --> Database Driver Class Initialized
INFO - 2024-10-28 09:09:01 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-28 09:09:01 --> Controller Class Initialized
DEBUG - 2024-10-28 09:09:01 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/home/views/v_home_guru.php
DEBUG - 2024-10-28 09:09:01 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-10-28 09:09:01 --> Final output sent to browser
DEBUG - 2024-10-28 09:09:01 --> Total execution time: 0.0340
INFO - 2024-10-28 09:09:06 --> Config Class Initialized
INFO - 2024-10-28 09:09:06 --> Hooks Class Initialized
DEBUG - 2024-10-28 09:09:06 --> UTF-8 Support Enabled
INFO - 2024-10-28 09:09:06 --> Utf8 Class Initialized
INFO - 2024-10-28 09:09:06 --> URI Class Initialized
INFO - 2024-10-28 09:09:06 --> Router Class Initialized
INFO - 2024-10-28 09:09:06 --> Output Class Initialized
INFO - 2024-10-28 09:09:06 --> Security Class Initialized
DEBUG - 2024-10-28 09:09:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-28 09:09:06 --> Input Class Initialized
INFO - 2024-10-28 09:09:06 --> Language Class Initialized
INFO - 2024-10-28 09:09:06 --> Language Class Initialized
INFO - 2024-10-28 09:09:06 --> Config Class Initialized
INFO - 2024-10-28 09:09:06 --> Loader Class Initialized
INFO - 2024-10-28 09:09:06 --> Helper loaded: url_helper
INFO - 2024-10-28 09:09:06 --> Helper loaded: file_helper
INFO - 2024-10-28 09:09:06 --> Helper loaded: form_helper
INFO - 2024-10-28 09:09:06 --> Helper loaded: my_helper
INFO - 2024-10-28 09:09:06 --> Database Driver Class Initialized
INFO - 2024-10-28 09:09:06 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-28 09:09:06 --> Controller Class Initialized
DEBUG - 2024-10-28 09:09:06 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/list.php
DEBUG - 2024-10-28 09:09:06 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-10-28 09:09:06 --> Final output sent to browser
DEBUG - 2024-10-28 09:09:06 --> Total execution time: 0.0560
INFO - 2024-10-28 09:09:10 --> Config Class Initialized
INFO - 2024-10-28 09:09:10 --> Hooks Class Initialized
DEBUG - 2024-10-28 09:09:10 --> UTF-8 Support Enabled
INFO - 2024-10-28 09:09:10 --> Utf8 Class Initialized
INFO - 2024-10-28 09:09:10 --> URI Class Initialized
INFO - 2024-10-28 09:09:10 --> Router Class Initialized
INFO - 2024-10-28 09:09:10 --> Output Class Initialized
INFO - 2024-10-28 09:09:10 --> Security Class Initialized
DEBUG - 2024-10-28 09:09:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-28 09:09:10 --> Input Class Initialized
INFO - 2024-10-28 09:09:10 --> Language Class Initialized
INFO - 2024-10-28 09:09:10 --> Language Class Initialized
INFO - 2024-10-28 09:09:10 --> Config Class Initialized
INFO - 2024-10-28 09:09:10 --> Loader Class Initialized
INFO - 2024-10-28 09:09:10 --> Helper loaded: url_helper
INFO - 2024-10-28 09:09:10 --> Helper loaded: file_helper
INFO - 2024-10-28 09:09:10 --> Helper loaded: form_helper
INFO - 2024-10-28 09:09:10 --> Helper loaded: my_helper
INFO - 2024-10-28 09:09:10 --> Database Driver Class Initialized
INFO - 2024-10-28 09:09:10 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-28 09:09:10 --> Controller Class Initialized
DEBUG - 2024-10-28 09:09:10 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php
INFO - 2024-10-28 09:09:13 --> Final output sent to browser
DEBUG - 2024-10-28 09:09:13 --> Total execution time: 2.8341
INFO - 2024-10-28 09:10:10 --> Config Class Initialized
INFO - 2024-10-28 09:10:10 --> Hooks Class Initialized
DEBUG - 2024-10-28 09:10:10 --> UTF-8 Support Enabled
INFO - 2024-10-28 09:10:10 --> Utf8 Class Initialized
INFO - 2024-10-28 09:10:10 --> URI Class Initialized
INFO - 2024-10-28 09:10:10 --> Router Class Initialized
INFO - 2024-10-28 09:10:10 --> Output Class Initialized
INFO - 2024-10-28 09:10:10 --> Security Class Initialized
DEBUG - 2024-10-28 09:10:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-28 09:10:10 --> Input Class Initialized
INFO - 2024-10-28 09:10:10 --> Language Class Initialized
INFO - 2024-10-28 09:10:10 --> Language Class Initialized
INFO - 2024-10-28 09:10:10 --> Config Class Initialized
INFO - 2024-10-28 09:10:10 --> Loader Class Initialized
INFO - 2024-10-28 09:10:10 --> Helper loaded: url_helper
INFO - 2024-10-28 09:10:10 --> Helper loaded: file_helper
INFO - 2024-10-28 09:10:10 --> Helper loaded: form_helper
INFO - 2024-10-28 09:10:10 --> Helper loaded: my_helper
INFO - 2024-10-28 09:10:10 --> Database Driver Class Initialized
INFO - 2024-10-28 09:10:10 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-28 09:10:10 --> Controller Class Initialized
DEBUG - 2024-10-28 09:10:10 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php
INFO - 2024-10-28 09:10:13 --> Final output sent to browser
DEBUG - 2024-10-28 09:10:13 --> Total execution time: 2.9596
INFO - 2024-10-28 09:15:27 --> Config Class Initialized
INFO - 2024-10-28 09:15:27 --> Hooks Class Initialized
DEBUG - 2024-10-28 09:15:27 --> UTF-8 Support Enabled
INFO - 2024-10-28 09:15:27 --> Utf8 Class Initialized
INFO - 2024-10-28 09:15:27 --> URI Class Initialized
INFO - 2024-10-28 09:15:27 --> Router Class Initialized
INFO - 2024-10-28 09:15:27 --> Output Class Initialized
INFO - 2024-10-28 09:15:27 --> Security Class Initialized
DEBUG - 2024-10-28 09:15:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-28 09:15:27 --> Input Class Initialized
INFO - 2024-10-28 09:15:27 --> Language Class Initialized
INFO - 2024-10-28 09:15:27 --> Language Class Initialized
INFO - 2024-10-28 09:15:27 --> Config Class Initialized
INFO - 2024-10-28 09:15:27 --> Loader Class Initialized
INFO - 2024-10-28 09:15:27 --> Helper loaded: url_helper
INFO - 2024-10-28 09:15:27 --> Helper loaded: file_helper
INFO - 2024-10-28 09:15:27 --> Helper loaded: form_helper
INFO - 2024-10-28 09:15:27 --> Helper loaded: my_helper
INFO - 2024-10-28 09:15:27 --> Database Driver Class Initialized
INFO - 2024-10-28 09:15:27 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-28 09:15:27 --> Controller Class Initialized
DEBUG - 2024-10-28 09:15:27 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php
INFO - 2024-10-28 09:15:30 --> Final output sent to browser
DEBUG - 2024-10-28 09:15:30 --> Total execution time: 3.0165
INFO - 2024-10-28 09:16:47 --> Config Class Initialized
INFO - 2024-10-28 09:16:47 --> Hooks Class Initialized
DEBUG - 2024-10-28 09:16:47 --> UTF-8 Support Enabled
INFO - 2024-10-28 09:16:47 --> Utf8 Class Initialized
INFO - 2024-10-28 09:16:47 --> URI Class Initialized
INFO - 2024-10-28 09:16:47 --> Router Class Initialized
INFO - 2024-10-28 09:16:47 --> Output Class Initialized
INFO - 2024-10-28 09:16:47 --> Security Class Initialized
DEBUG - 2024-10-28 09:16:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-28 09:16:47 --> Input Class Initialized
INFO - 2024-10-28 09:16:47 --> Language Class Initialized
INFO - 2024-10-28 09:16:47 --> Language Class Initialized
INFO - 2024-10-28 09:16:47 --> Config Class Initialized
INFO - 2024-10-28 09:16:47 --> Loader Class Initialized
INFO - 2024-10-28 09:16:47 --> Helper loaded: url_helper
INFO - 2024-10-28 09:16:47 --> Helper loaded: file_helper
INFO - 2024-10-28 09:16:47 --> Helper loaded: form_helper
INFO - 2024-10-28 09:16:47 --> Helper loaded: my_helper
INFO - 2024-10-28 09:16:47 --> Database Driver Class Initialized
INFO - 2024-10-28 09:16:47 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-28 09:16:47 --> Controller Class Initialized
DEBUG - 2024-10-28 09:16:47 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php
INFO - 2024-10-28 09:16:50 --> Final output sent to browser
DEBUG - 2024-10-28 09:16:50 --> Total execution time: 3.4657
INFO - 2024-10-28 09:17:32 --> Config Class Initialized
INFO - 2024-10-28 09:17:32 --> Hooks Class Initialized
DEBUG - 2024-10-28 09:17:32 --> UTF-8 Support Enabled
INFO - 2024-10-28 09:17:32 --> Utf8 Class Initialized
INFO - 2024-10-28 09:17:32 --> URI Class Initialized
INFO - 2024-10-28 09:17:32 --> Router Class Initialized
INFO - 2024-10-28 09:17:32 --> Output Class Initialized
INFO - 2024-10-28 09:17:32 --> Security Class Initialized
DEBUG - 2024-10-28 09:17:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-28 09:17:32 --> Input Class Initialized
INFO - 2024-10-28 09:17:32 --> Language Class Initialized
INFO - 2024-10-28 09:17:32 --> Language Class Initialized
INFO - 2024-10-28 09:17:32 --> Config Class Initialized
INFO - 2024-10-28 09:17:32 --> Loader Class Initialized
INFO - 2024-10-28 09:17:32 --> Helper loaded: url_helper
INFO - 2024-10-28 09:17:32 --> Helper loaded: file_helper
INFO - 2024-10-28 09:17:32 --> Helper loaded: form_helper
INFO - 2024-10-28 09:17:32 --> Helper loaded: my_helper
INFO - 2024-10-28 09:17:32 --> Database Driver Class Initialized
INFO - 2024-10-28 09:17:32 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-28 09:17:32 --> Controller Class Initialized
DEBUG - 2024-10-28 09:17:32 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php
INFO - 2024-10-28 09:17:35 --> Final output sent to browser
DEBUG - 2024-10-28 09:17:35 --> Total execution time: 2.8713
INFO - 2024-10-28 09:17:57 --> Config Class Initialized
INFO - 2024-10-28 09:17:57 --> Hooks Class Initialized
DEBUG - 2024-10-28 09:17:57 --> UTF-8 Support Enabled
INFO - 2024-10-28 09:17:57 --> Utf8 Class Initialized
INFO - 2024-10-28 09:17:57 --> URI Class Initialized
INFO - 2024-10-28 09:17:57 --> Router Class Initialized
INFO - 2024-10-28 09:17:57 --> Output Class Initialized
INFO - 2024-10-28 09:17:57 --> Security Class Initialized
DEBUG - 2024-10-28 09:17:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-28 09:17:57 --> Input Class Initialized
INFO - 2024-10-28 09:17:57 --> Language Class Initialized
INFO - 2024-10-28 09:17:57 --> Language Class Initialized
INFO - 2024-10-28 09:17:57 --> Config Class Initialized
INFO - 2024-10-28 09:17:57 --> Loader Class Initialized
INFO - 2024-10-28 09:17:57 --> Helper loaded: url_helper
INFO - 2024-10-28 09:17:57 --> Helper loaded: file_helper
INFO - 2024-10-28 09:17:57 --> Helper loaded: form_helper
INFO - 2024-10-28 09:17:57 --> Helper loaded: my_helper
INFO - 2024-10-28 09:17:57 --> Database Driver Class Initialized
INFO - 2024-10-28 09:17:57 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-28 09:17:57 --> Controller Class Initialized
DEBUG - 2024-10-28 09:17:57 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php
INFO - 2024-10-28 09:18:00 --> Final output sent to browser
DEBUG - 2024-10-28 09:18:00 --> Total execution time: 2.7648
INFO - 2024-10-28 09:18:26 --> Config Class Initialized
INFO - 2024-10-28 09:18:26 --> Hooks Class Initialized
DEBUG - 2024-10-28 09:18:26 --> UTF-8 Support Enabled
INFO - 2024-10-28 09:18:26 --> Utf8 Class Initialized
INFO - 2024-10-28 09:18:26 --> URI Class Initialized
INFO - 2024-10-28 09:18:26 --> Router Class Initialized
INFO - 2024-10-28 09:18:26 --> Output Class Initialized
INFO - 2024-10-28 09:18:26 --> Security Class Initialized
DEBUG - 2024-10-28 09:18:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-28 09:18:26 --> Input Class Initialized
INFO - 2024-10-28 09:18:26 --> Language Class Initialized
INFO - 2024-10-28 09:18:26 --> Language Class Initialized
INFO - 2024-10-28 09:18:26 --> Config Class Initialized
INFO - 2024-10-28 09:18:26 --> Loader Class Initialized
INFO - 2024-10-28 09:18:26 --> Helper loaded: url_helper
INFO - 2024-10-28 09:18:26 --> Helper loaded: file_helper
INFO - 2024-10-28 09:18:26 --> Helper loaded: form_helper
INFO - 2024-10-28 09:18:26 --> Helper loaded: my_helper
INFO - 2024-10-28 09:18:26 --> Database Driver Class Initialized
INFO - 2024-10-28 09:18:26 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-28 09:18:26 --> Controller Class Initialized
DEBUG - 2024-10-28 09:18:26 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php
INFO - 2024-10-28 09:18:29 --> Final output sent to browser
DEBUG - 2024-10-28 09:18:29 --> Total execution time: 3.3127
INFO - 2024-10-28 09:19:35 --> Config Class Initialized
INFO - 2024-10-28 09:19:35 --> Hooks Class Initialized
DEBUG - 2024-10-28 09:19:35 --> UTF-8 Support Enabled
INFO - 2024-10-28 09:19:35 --> Utf8 Class Initialized
INFO - 2024-10-28 09:19:35 --> URI Class Initialized
INFO - 2024-10-28 09:19:35 --> Router Class Initialized
INFO - 2024-10-28 09:19:35 --> Output Class Initialized
INFO - 2024-10-28 09:19:35 --> Security Class Initialized
DEBUG - 2024-10-28 09:19:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-28 09:19:35 --> Input Class Initialized
INFO - 2024-10-28 09:19:35 --> Language Class Initialized
INFO - 2024-10-28 09:19:35 --> Language Class Initialized
INFO - 2024-10-28 09:19:35 --> Config Class Initialized
INFO - 2024-10-28 09:19:35 --> Loader Class Initialized
INFO - 2024-10-28 09:19:35 --> Helper loaded: url_helper
INFO - 2024-10-28 09:19:35 --> Helper loaded: file_helper
INFO - 2024-10-28 09:19:35 --> Helper loaded: form_helper
INFO - 2024-10-28 09:19:35 --> Helper loaded: my_helper
INFO - 2024-10-28 09:19:35 --> Database Driver Class Initialized
INFO - 2024-10-28 09:19:35 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-28 09:19:35 --> Controller Class Initialized
DEBUG - 2024-10-28 09:19:35 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php
INFO - 2024-10-28 09:19:38 --> Final output sent to browser
DEBUG - 2024-10-28 09:19:38 --> Total execution time: 3.1688
INFO - 2024-10-28 09:20:03 --> Config Class Initialized
INFO - 2024-10-28 09:20:03 --> Hooks Class Initialized
DEBUG - 2024-10-28 09:20:03 --> UTF-8 Support Enabled
INFO - 2024-10-28 09:20:03 --> Utf8 Class Initialized
INFO - 2024-10-28 09:20:03 --> URI Class Initialized
INFO - 2024-10-28 09:20:03 --> Router Class Initialized
INFO - 2024-10-28 09:20:03 --> Output Class Initialized
INFO - 2024-10-28 09:20:03 --> Security Class Initialized
DEBUG - 2024-10-28 09:20:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-28 09:20:03 --> Input Class Initialized
INFO - 2024-10-28 09:20:03 --> Language Class Initialized
INFO - 2024-10-28 09:20:03 --> Language Class Initialized
INFO - 2024-10-28 09:20:03 --> Config Class Initialized
INFO - 2024-10-28 09:20:03 --> Loader Class Initialized
INFO - 2024-10-28 09:20:03 --> Helper loaded: url_helper
INFO - 2024-10-28 09:20:03 --> Helper loaded: file_helper
INFO - 2024-10-28 09:20:03 --> Helper loaded: form_helper
INFO - 2024-10-28 09:20:03 --> Helper loaded: my_helper
INFO - 2024-10-28 09:20:03 --> Database Driver Class Initialized
INFO - 2024-10-28 09:20:03 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-28 09:20:03 --> Controller Class Initialized
DEBUG - 2024-10-28 09:20:03 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php
INFO - 2024-10-28 09:20:06 --> Final output sent to browser
DEBUG - 2024-10-28 09:20:06 --> Total execution time: 3.5830
INFO - 2024-10-28 09:21:44 --> Config Class Initialized
INFO - 2024-10-28 09:21:44 --> Hooks Class Initialized
DEBUG - 2024-10-28 09:21:44 --> UTF-8 Support Enabled
INFO - 2024-10-28 09:21:44 --> Utf8 Class Initialized
INFO - 2024-10-28 09:21:44 --> URI Class Initialized
INFO - 2024-10-28 09:21:44 --> Router Class Initialized
INFO - 2024-10-28 09:21:44 --> Output Class Initialized
INFO - 2024-10-28 09:21:44 --> Security Class Initialized
DEBUG - 2024-10-28 09:21:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-28 09:21:44 --> Input Class Initialized
INFO - 2024-10-28 09:21:44 --> Language Class Initialized
INFO - 2024-10-28 09:21:44 --> Language Class Initialized
INFO - 2024-10-28 09:21:44 --> Config Class Initialized
INFO - 2024-10-28 09:21:44 --> Loader Class Initialized
INFO - 2024-10-28 09:21:44 --> Helper loaded: url_helper
INFO - 2024-10-28 09:21:44 --> Helper loaded: file_helper
INFO - 2024-10-28 09:21:44 --> Helper loaded: form_helper
INFO - 2024-10-28 09:21:44 --> Helper loaded: my_helper
INFO - 2024-10-28 09:21:44 --> Database Driver Class Initialized
INFO - 2024-10-28 09:21:44 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-28 09:21:44 --> Controller Class Initialized
DEBUG - 2024-10-28 09:21:44 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php
INFO - 2024-10-28 09:21:47 --> Final output sent to browser
DEBUG - 2024-10-28 09:21:47 --> Total execution time: 3.0575
INFO - 2024-10-28 09:22:21 --> Config Class Initialized
INFO - 2024-10-28 09:22:21 --> Hooks Class Initialized
DEBUG - 2024-10-28 09:22:21 --> UTF-8 Support Enabled
INFO - 2024-10-28 09:22:21 --> Utf8 Class Initialized
INFO - 2024-10-28 09:22:21 --> URI Class Initialized
INFO - 2024-10-28 09:22:21 --> Router Class Initialized
INFO - 2024-10-28 09:22:21 --> Output Class Initialized
INFO - 2024-10-28 09:22:21 --> Security Class Initialized
DEBUG - 2024-10-28 09:22:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-28 09:22:21 --> Input Class Initialized
INFO - 2024-10-28 09:22:21 --> Language Class Initialized
INFO - 2024-10-28 09:22:21 --> Language Class Initialized
INFO - 2024-10-28 09:22:21 --> Config Class Initialized
INFO - 2024-10-28 09:22:21 --> Loader Class Initialized
INFO - 2024-10-28 09:22:21 --> Helper loaded: url_helper
INFO - 2024-10-28 09:22:21 --> Helper loaded: file_helper
INFO - 2024-10-28 09:22:21 --> Helper loaded: form_helper
INFO - 2024-10-28 09:22:21 --> Helper loaded: my_helper
INFO - 2024-10-28 09:22:21 --> Database Driver Class Initialized
INFO - 2024-10-28 09:22:21 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-28 09:22:21 --> Controller Class Initialized
DEBUG - 2024-10-28 09:22:21 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php
INFO - 2024-10-28 09:22:25 --> Final output sent to browser
DEBUG - 2024-10-28 09:22:25 --> Total execution time: 3.6250
INFO - 2024-10-28 09:22:45 --> Config Class Initialized
INFO - 2024-10-28 09:22:45 --> Hooks Class Initialized
DEBUG - 2024-10-28 09:22:45 --> UTF-8 Support Enabled
INFO - 2024-10-28 09:22:45 --> Utf8 Class Initialized
INFO - 2024-10-28 09:22:45 --> URI Class Initialized
INFO - 2024-10-28 09:22:45 --> Router Class Initialized
INFO - 2024-10-28 09:22:45 --> Output Class Initialized
INFO - 2024-10-28 09:22:45 --> Security Class Initialized
DEBUG - 2024-10-28 09:22:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-28 09:22:45 --> Input Class Initialized
INFO - 2024-10-28 09:22:45 --> Language Class Initialized
INFO - 2024-10-28 09:22:45 --> Language Class Initialized
INFO - 2024-10-28 09:22:45 --> Config Class Initialized
INFO - 2024-10-28 09:22:45 --> Loader Class Initialized
INFO - 2024-10-28 09:22:45 --> Helper loaded: url_helper
INFO - 2024-10-28 09:22:45 --> Helper loaded: file_helper
INFO - 2024-10-28 09:22:45 --> Helper loaded: form_helper
INFO - 2024-10-28 09:22:45 --> Helper loaded: my_helper
INFO - 2024-10-28 09:22:45 --> Database Driver Class Initialized
INFO - 2024-10-28 09:22:45 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-28 09:22:45 --> Controller Class Initialized
DEBUG - 2024-10-28 09:22:45 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php
INFO - 2024-10-28 09:22:48 --> Final output sent to browser
DEBUG - 2024-10-28 09:22:48 --> Total execution time: 3.0439
INFO - 2024-10-28 09:23:16 --> Config Class Initialized
INFO - 2024-10-28 09:23:16 --> Hooks Class Initialized
DEBUG - 2024-10-28 09:23:16 --> UTF-8 Support Enabled
INFO - 2024-10-28 09:23:16 --> Utf8 Class Initialized
INFO - 2024-10-28 09:23:16 --> URI Class Initialized
INFO - 2024-10-28 09:23:16 --> Router Class Initialized
INFO - 2024-10-28 09:23:16 --> Output Class Initialized
INFO - 2024-10-28 09:23:16 --> Security Class Initialized
DEBUG - 2024-10-28 09:23:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-28 09:23:16 --> Input Class Initialized
INFO - 2024-10-28 09:23:16 --> Language Class Initialized
INFO - 2024-10-28 09:23:16 --> Language Class Initialized
INFO - 2024-10-28 09:23:16 --> Config Class Initialized
INFO - 2024-10-28 09:23:16 --> Loader Class Initialized
INFO - 2024-10-28 09:23:16 --> Helper loaded: url_helper
INFO - 2024-10-28 09:23:16 --> Helper loaded: file_helper
INFO - 2024-10-28 09:23:16 --> Helper loaded: form_helper
INFO - 2024-10-28 09:23:16 --> Helper loaded: my_helper
INFO - 2024-10-28 09:23:16 --> Database Driver Class Initialized
INFO - 2024-10-28 09:23:16 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-28 09:23:16 --> Controller Class Initialized
DEBUG - 2024-10-28 09:23:16 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php
INFO - 2024-10-28 09:23:20 --> Final output sent to browser
DEBUG - 2024-10-28 09:23:20 --> Total execution time: 4.2132
INFO - 2024-10-28 09:23:48 --> Config Class Initialized
INFO - 2024-10-28 09:23:48 --> Hooks Class Initialized
DEBUG - 2024-10-28 09:23:48 --> UTF-8 Support Enabled
INFO - 2024-10-28 09:23:48 --> Utf8 Class Initialized
INFO - 2024-10-28 09:23:48 --> URI Class Initialized
INFO - 2024-10-28 09:23:48 --> Router Class Initialized
INFO - 2024-10-28 09:23:48 --> Output Class Initialized
INFO - 2024-10-28 09:23:48 --> Security Class Initialized
DEBUG - 2024-10-28 09:23:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-28 09:23:48 --> Input Class Initialized
INFO - 2024-10-28 09:23:48 --> Language Class Initialized
INFO - 2024-10-28 09:23:48 --> Language Class Initialized
INFO - 2024-10-28 09:23:48 --> Config Class Initialized
INFO - 2024-10-28 09:23:48 --> Loader Class Initialized
INFO - 2024-10-28 09:23:48 --> Helper loaded: url_helper
INFO - 2024-10-28 09:23:48 --> Helper loaded: file_helper
INFO - 2024-10-28 09:23:48 --> Helper loaded: form_helper
INFO - 2024-10-28 09:23:48 --> Helper loaded: my_helper
INFO - 2024-10-28 09:23:48 --> Database Driver Class Initialized
INFO - 2024-10-28 09:23:48 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-28 09:23:48 --> Controller Class Initialized
DEBUG - 2024-10-28 09:23:48 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php
INFO - 2024-10-28 09:23:51 --> Final output sent to browser
DEBUG - 2024-10-28 09:23:51 --> Total execution time: 3.2294
INFO - 2024-10-28 09:24:07 --> Config Class Initialized
INFO - 2024-10-28 09:24:07 --> Hooks Class Initialized
DEBUG - 2024-10-28 09:24:07 --> UTF-8 Support Enabled
INFO - 2024-10-28 09:24:07 --> Utf8 Class Initialized
INFO - 2024-10-28 09:24:07 --> URI Class Initialized
INFO - 2024-10-28 09:24:07 --> Router Class Initialized
INFO - 2024-10-28 09:24:07 --> Output Class Initialized
INFO - 2024-10-28 09:24:07 --> Security Class Initialized
DEBUG - 2024-10-28 09:24:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-28 09:24:07 --> Input Class Initialized
INFO - 2024-10-28 09:24:07 --> Language Class Initialized
INFO - 2024-10-28 09:24:07 --> Language Class Initialized
INFO - 2024-10-28 09:24:07 --> Config Class Initialized
INFO - 2024-10-28 09:24:07 --> Loader Class Initialized
INFO - 2024-10-28 09:24:07 --> Helper loaded: url_helper
INFO - 2024-10-28 09:24:07 --> Helper loaded: file_helper
INFO - 2024-10-28 09:24:07 --> Helper loaded: form_helper
INFO - 2024-10-28 09:24:07 --> Helper loaded: my_helper
INFO - 2024-10-28 09:24:07 --> Database Driver Class Initialized
INFO - 2024-10-28 09:24:07 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-28 09:24:07 --> Controller Class Initialized
DEBUG - 2024-10-28 09:24:07 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php
INFO - 2024-10-28 09:24:11 --> Final output sent to browser
DEBUG - 2024-10-28 09:24:11 --> Total execution time: 3.2116
INFO - 2024-10-28 09:25:06 --> Config Class Initialized
INFO - 2024-10-28 09:25:06 --> Hooks Class Initialized
DEBUG - 2024-10-28 09:25:06 --> UTF-8 Support Enabled
INFO - 2024-10-28 09:25:06 --> Utf8 Class Initialized
INFO - 2024-10-28 09:25:06 --> URI Class Initialized
INFO - 2024-10-28 09:25:06 --> Router Class Initialized
INFO - 2024-10-28 09:25:06 --> Output Class Initialized
INFO - 2024-10-28 09:25:06 --> Security Class Initialized
DEBUG - 2024-10-28 09:25:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-28 09:25:06 --> Input Class Initialized
INFO - 2024-10-28 09:25:06 --> Language Class Initialized
INFO - 2024-10-28 09:25:06 --> Language Class Initialized
INFO - 2024-10-28 09:25:06 --> Config Class Initialized
INFO - 2024-10-28 09:25:06 --> Loader Class Initialized
INFO - 2024-10-28 09:25:06 --> Helper loaded: url_helper
INFO - 2024-10-28 09:25:06 --> Helper loaded: file_helper
INFO - 2024-10-28 09:25:06 --> Helper loaded: form_helper
INFO - 2024-10-28 09:25:06 --> Helper loaded: my_helper
INFO - 2024-10-28 09:25:06 --> Database Driver Class Initialized
INFO - 2024-10-28 09:25:06 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-28 09:25:06 --> Controller Class Initialized
DEBUG - 2024-10-28 09:25:06 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php
INFO - 2024-10-28 09:25:10 --> Final output sent to browser
DEBUG - 2024-10-28 09:25:10 --> Total execution time: 4.4610
INFO - 2024-10-28 09:25:28 --> Config Class Initialized
INFO - 2024-10-28 09:25:28 --> Hooks Class Initialized
DEBUG - 2024-10-28 09:25:28 --> UTF-8 Support Enabled
INFO - 2024-10-28 09:25:28 --> Utf8 Class Initialized
INFO - 2024-10-28 09:25:28 --> URI Class Initialized
INFO - 2024-10-28 09:25:28 --> Router Class Initialized
INFO - 2024-10-28 09:25:28 --> Output Class Initialized
INFO - 2024-10-28 09:25:28 --> Security Class Initialized
DEBUG - 2024-10-28 09:25:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-28 09:25:28 --> Input Class Initialized
INFO - 2024-10-28 09:25:28 --> Language Class Initialized
INFO - 2024-10-28 09:25:28 --> Language Class Initialized
INFO - 2024-10-28 09:25:28 --> Config Class Initialized
INFO - 2024-10-28 09:25:28 --> Loader Class Initialized
INFO - 2024-10-28 09:25:28 --> Helper loaded: url_helper
INFO - 2024-10-28 09:25:28 --> Helper loaded: file_helper
INFO - 2024-10-28 09:25:28 --> Helper loaded: form_helper
INFO - 2024-10-28 09:25:28 --> Helper loaded: my_helper
INFO - 2024-10-28 09:25:28 --> Database Driver Class Initialized
INFO - 2024-10-28 09:25:28 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-28 09:25:28 --> Controller Class Initialized
DEBUG - 2024-10-28 09:25:28 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php
INFO - 2024-10-28 09:25:31 --> Final output sent to browser
DEBUG - 2024-10-28 09:25:31 --> Total execution time: 3.5342
INFO - 2024-10-28 09:25:54 --> Config Class Initialized
INFO - 2024-10-28 09:25:54 --> Hooks Class Initialized
DEBUG - 2024-10-28 09:25:54 --> UTF-8 Support Enabled
INFO - 2024-10-28 09:25:54 --> Utf8 Class Initialized
INFO - 2024-10-28 09:25:54 --> URI Class Initialized
INFO - 2024-10-28 09:25:54 --> Router Class Initialized
INFO - 2024-10-28 09:25:54 --> Output Class Initialized
INFO - 2024-10-28 09:25:54 --> Security Class Initialized
DEBUG - 2024-10-28 09:25:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-28 09:25:54 --> Input Class Initialized
INFO - 2024-10-28 09:25:54 --> Language Class Initialized
INFO - 2024-10-28 09:25:54 --> Language Class Initialized
INFO - 2024-10-28 09:25:54 --> Config Class Initialized
INFO - 2024-10-28 09:25:54 --> Loader Class Initialized
INFO - 2024-10-28 09:25:54 --> Helper loaded: url_helper
INFO - 2024-10-28 09:25:54 --> Helper loaded: file_helper
INFO - 2024-10-28 09:25:54 --> Helper loaded: form_helper
INFO - 2024-10-28 09:25:54 --> Helper loaded: my_helper
INFO - 2024-10-28 09:25:54 --> Database Driver Class Initialized
INFO - 2024-10-28 09:25:54 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-28 09:25:54 --> Controller Class Initialized
DEBUG - 2024-10-28 09:25:54 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php
INFO - 2024-10-28 09:25:58 --> Final output sent to browser
DEBUG - 2024-10-28 09:25:58 --> Total execution time: 3.2543
INFO - 2024-10-28 09:26:58 --> Config Class Initialized
INFO - 2024-10-28 09:26:58 --> Hooks Class Initialized
DEBUG - 2024-10-28 09:26:58 --> UTF-8 Support Enabled
INFO - 2024-10-28 09:26:58 --> Utf8 Class Initialized
INFO - 2024-10-28 09:26:58 --> URI Class Initialized
INFO - 2024-10-28 09:26:58 --> Router Class Initialized
INFO - 2024-10-28 09:26:58 --> Output Class Initialized
INFO - 2024-10-28 09:26:58 --> Security Class Initialized
DEBUG - 2024-10-28 09:26:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-28 09:26:58 --> Input Class Initialized
INFO - 2024-10-28 09:26:58 --> Language Class Initialized
INFO - 2024-10-28 09:26:58 --> Language Class Initialized
INFO - 2024-10-28 09:26:58 --> Config Class Initialized
INFO - 2024-10-28 09:26:58 --> Loader Class Initialized
INFO - 2024-10-28 09:26:58 --> Helper loaded: url_helper
INFO - 2024-10-28 09:26:58 --> Helper loaded: file_helper
INFO - 2024-10-28 09:26:58 --> Helper loaded: form_helper
INFO - 2024-10-28 09:26:58 --> Helper loaded: my_helper
INFO - 2024-10-28 09:26:58 --> Database Driver Class Initialized
INFO - 2024-10-28 09:26:58 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-28 09:26:58 --> Controller Class Initialized
DEBUG - 2024-10-28 09:26:58 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php
INFO - 2024-10-28 09:27:02 --> Final output sent to browser
DEBUG - 2024-10-28 09:27:02 --> Total execution time: 3.7696
INFO - 2024-10-28 09:35:38 --> Config Class Initialized
INFO - 2024-10-28 09:35:38 --> Hooks Class Initialized
DEBUG - 2024-10-28 09:35:38 --> UTF-8 Support Enabled
INFO - 2024-10-28 09:35:38 --> Utf8 Class Initialized
INFO - 2024-10-28 09:35:38 --> URI Class Initialized
INFO - 2024-10-28 09:35:38 --> Router Class Initialized
INFO - 2024-10-28 09:35:38 --> Output Class Initialized
INFO - 2024-10-28 09:35:38 --> Security Class Initialized
DEBUG - 2024-10-28 09:35:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-28 09:35:38 --> Input Class Initialized
INFO - 2024-10-28 09:35:38 --> Language Class Initialized
INFO - 2024-10-28 09:35:38 --> Language Class Initialized
INFO - 2024-10-28 09:35:38 --> Config Class Initialized
INFO - 2024-10-28 09:35:38 --> Loader Class Initialized
INFO - 2024-10-28 09:35:38 --> Helper loaded: url_helper
INFO - 2024-10-28 09:35:38 --> Helper loaded: file_helper
INFO - 2024-10-28 09:35:38 --> Helper loaded: form_helper
INFO - 2024-10-28 09:35:38 --> Helper loaded: my_helper
INFO - 2024-10-28 09:35:38 --> Database Driver Class Initialized
INFO - 2024-10-28 09:35:38 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-28 09:35:38 --> Controller Class Initialized
INFO - 2024-10-28 09:35:38 --> Helper loaded: cookie_helper
INFO - 2024-10-28 09:35:39 --> Config Class Initialized
INFO - 2024-10-28 09:35:39 --> Hooks Class Initialized
DEBUG - 2024-10-28 09:35:39 --> UTF-8 Support Enabled
INFO - 2024-10-28 09:35:39 --> Utf8 Class Initialized
INFO - 2024-10-28 09:35:39 --> URI Class Initialized
INFO - 2024-10-28 09:35:39 --> Router Class Initialized
INFO - 2024-10-28 09:35:39 --> Output Class Initialized
INFO - 2024-10-28 09:35:39 --> Security Class Initialized
DEBUG - 2024-10-28 09:35:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-28 09:35:39 --> Input Class Initialized
INFO - 2024-10-28 09:35:39 --> Language Class Initialized
INFO - 2024-10-28 09:35:39 --> Language Class Initialized
INFO - 2024-10-28 09:35:39 --> Config Class Initialized
INFO - 2024-10-28 09:35:39 --> Loader Class Initialized
INFO - 2024-10-28 09:35:39 --> Helper loaded: url_helper
INFO - 2024-10-28 09:35:39 --> Helper loaded: file_helper
INFO - 2024-10-28 09:35:39 --> Helper loaded: form_helper
INFO - 2024-10-28 09:35:39 --> Helper loaded: my_helper
INFO - 2024-10-28 09:35:39 --> Database Driver Class Initialized
INFO - 2024-10-28 09:35:39 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-28 09:35:39 --> Controller Class Initialized
INFO - 2024-10-28 09:35:39 --> Config Class Initialized
INFO - 2024-10-28 09:35:39 --> Hooks Class Initialized
DEBUG - 2024-10-28 09:35:39 --> UTF-8 Support Enabled
INFO - 2024-10-28 09:35:39 --> Utf8 Class Initialized
INFO - 2024-10-28 09:35:39 --> URI Class Initialized
INFO - 2024-10-28 09:35:39 --> Router Class Initialized
INFO - 2024-10-28 09:35:39 --> Output Class Initialized
INFO - 2024-10-28 09:35:39 --> Security Class Initialized
DEBUG - 2024-10-28 09:35:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-28 09:35:39 --> Input Class Initialized
INFO - 2024-10-28 09:35:39 --> Language Class Initialized
INFO - 2024-10-28 09:35:39 --> Language Class Initialized
INFO - 2024-10-28 09:35:39 --> Config Class Initialized
INFO - 2024-10-28 09:35:39 --> Loader Class Initialized
INFO - 2024-10-28 09:35:39 --> Helper loaded: url_helper
INFO - 2024-10-28 09:35:39 --> Helper loaded: file_helper
INFO - 2024-10-28 09:35:39 --> Helper loaded: form_helper
INFO - 2024-10-28 09:35:39 --> Helper loaded: my_helper
INFO - 2024-10-28 09:35:39 --> Database Driver Class Initialized
INFO - 2024-10-28 09:35:39 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-28 09:35:39 --> Controller Class Initialized
DEBUG - 2024-10-28 09:35:39 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/login/views/login.php
DEBUG - 2024-10-28 09:35:39 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-10-28 09:35:39 --> Final output sent to browser
DEBUG - 2024-10-28 09:35:39 --> Total execution time: 0.0301
INFO - 2024-10-28 09:35:45 --> Config Class Initialized
INFO - 2024-10-28 09:35:45 --> Hooks Class Initialized
DEBUG - 2024-10-28 09:35:45 --> UTF-8 Support Enabled
INFO - 2024-10-28 09:35:45 --> Utf8 Class Initialized
INFO - 2024-10-28 09:35:45 --> URI Class Initialized
INFO - 2024-10-28 09:35:45 --> Router Class Initialized
INFO - 2024-10-28 09:35:45 --> Output Class Initialized
INFO - 2024-10-28 09:35:45 --> Security Class Initialized
DEBUG - 2024-10-28 09:35:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-28 09:35:45 --> Input Class Initialized
INFO - 2024-10-28 09:35:45 --> Language Class Initialized
INFO - 2024-10-28 09:35:45 --> Language Class Initialized
INFO - 2024-10-28 09:35:45 --> Config Class Initialized
INFO - 2024-10-28 09:35:45 --> Loader Class Initialized
INFO - 2024-10-28 09:35:45 --> Helper loaded: url_helper
INFO - 2024-10-28 09:35:45 --> Helper loaded: file_helper
INFO - 2024-10-28 09:35:45 --> Helper loaded: form_helper
INFO - 2024-10-28 09:35:45 --> Helper loaded: my_helper
INFO - 2024-10-28 09:35:45 --> Database Driver Class Initialized
INFO - 2024-10-28 09:35:45 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-28 09:35:45 --> Controller Class Initialized
INFO - 2024-10-28 09:35:45 --> Helper loaded: cookie_helper
INFO - 2024-10-28 09:35:45 --> Final output sent to browser
DEBUG - 2024-10-28 09:35:45 --> Total execution time: 0.0381
INFO - 2024-10-28 09:35:45 --> Config Class Initialized
INFO - 2024-10-28 09:35:45 --> Hooks Class Initialized
DEBUG - 2024-10-28 09:35:45 --> UTF-8 Support Enabled
INFO - 2024-10-28 09:35:45 --> Utf8 Class Initialized
INFO - 2024-10-28 09:35:45 --> URI Class Initialized
INFO - 2024-10-28 09:35:45 --> Router Class Initialized
INFO - 2024-10-28 09:35:45 --> Output Class Initialized
INFO - 2024-10-28 09:35:45 --> Security Class Initialized
DEBUG - 2024-10-28 09:35:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-28 09:35:45 --> Input Class Initialized
INFO - 2024-10-28 09:35:45 --> Language Class Initialized
INFO - 2024-10-28 09:35:45 --> Language Class Initialized
INFO - 2024-10-28 09:35:45 --> Config Class Initialized
INFO - 2024-10-28 09:35:45 --> Loader Class Initialized
INFO - 2024-10-28 09:35:45 --> Helper loaded: url_helper
INFO - 2024-10-28 09:35:45 --> Helper loaded: file_helper
INFO - 2024-10-28 09:35:45 --> Helper loaded: form_helper
INFO - 2024-10-28 09:35:45 --> Helper loaded: my_helper
INFO - 2024-10-28 09:35:45 --> Database Driver Class Initialized
INFO - 2024-10-28 09:35:45 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-28 09:35:45 --> Controller Class Initialized
DEBUG - 2024-10-28 09:35:45 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/home/views/v_home.php
DEBUG - 2024-10-28 09:35:45 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-10-28 09:35:45 --> Final output sent to browser
DEBUG - 2024-10-28 09:35:45 --> Total execution time: 0.0474
INFO - 2024-10-28 09:35:48 --> Config Class Initialized
INFO - 2024-10-28 09:35:48 --> Hooks Class Initialized
DEBUG - 2024-10-28 09:35:48 --> UTF-8 Support Enabled
INFO - 2024-10-28 09:35:48 --> Utf8 Class Initialized
INFO - 2024-10-28 09:35:48 --> URI Class Initialized
INFO - 2024-10-28 09:35:48 --> Router Class Initialized
INFO - 2024-10-28 09:35:48 --> Output Class Initialized
INFO - 2024-10-28 09:35:48 --> Security Class Initialized
DEBUG - 2024-10-28 09:35:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-28 09:35:48 --> Input Class Initialized
INFO - 2024-10-28 09:35:48 --> Language Class Initialized
INFO - 2024-10-28 09:35:48 --> Language Class Initialized
INFO - 2024-10-28 09:35:48 --> Config Class Initialized
INFO - 2024-10-28 09:35:48 --> Loader Class Initialized
INFO - 2024-10-28 09:35:48 --> Helper loaded: url_helper
INFO - 2024-10-28 09:35:48 --> Helper loaded: file_helper
INFO - 2024-10-28 09:35:48 --> Helper loaded: form_helper
INFO - 2024-10-28 09:35:48 --> Helper loaded: my_helper
INFO - 2024-10-28 09:35:48 --> Database Driver Class Initialized
INFO - 2024-10-28 09:35:48 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-28 09:35:48 --> Controller Class Initialized
DEBUG - 2024-10-28 09:35:48 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/data_siswa/views/list.php
DEBUG - 2024-10-28 09:35:48 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-10-28 09:35:48 --> Final output sent to browser
DEBUG - 2024-10-28 09:35:48 --> Total execution time: 0.0289
INFO - 2024-10-28 09:35:48 --> Config Class Initialized
INFO - 2024-10-28 09:35:48 --> Hooks Class Initialized
DEBUG - 2024-10-28 09:35:48 --> UTF-8 Support Enabled
INFO - 2024-10-28 09:35:48 --> Utf8 Class Initialized
INFO - 2024-10-28 09:35:48 --> URI Class Initialized
INFO - 2024-10-28 09:35:48 --> Router Class Initialized
INFO - 2024-10-28 09:35:48 --> Output Class Initialized
INFO - 2024-10-28 09:35:48 --> Security Class Initialized
DEBUG - 2024-10-28 09:35:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-28 09:35:48 --> Input Class Initialized
INFO - 2024-10-28 09:35:48 --> Language Class Initialized
ERROR - 2024-10-28 09:35:48 --> 404 Page Not Found: /index
INFO - 2024-10-28 09:35:48 --> Config Class Initialized
INFO - 2024-10-28 09:35:48 --> Hooks Class Initialized
DEBUG - 2024-10-28 09:35:48 --> UTF-8 Support Enabled
INFO - 2024-10-28 09:35:48 --> Utf8 Class Initialized
INFO - 2024-10-28 09:35:48 --> URI Class Initialized
INFO - 2024-10-28 09:35:48 --> Router Class Initialized
INFO - 2024-10-28 09:35:48 --> Output Class Initialized
INFO - 2024-10-28 09:35:48 --> Security Class Initialized
DEBUG - 2024-10-28 09:35:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-28 09:35:48 --> Input Class Initialized
INFO - 2024-10-28 09:35:48 --> Language Class Initialized
INFO - 2024-10-28 09:35:48 --> Language Class Initialized
INFO - 2024-10-28 09:35:48 --> Config Class Initialized
INFO - 2024-10-28 09:35:48 --> Loader Class Initialized
INFO - 2024-10-28 09:35:48 --> Helper loaded: url_helper
INFO - 2024-10-28 09:35:48 --> Helper loaded: file_helper
INFO - 2024-10-28 09:35:48 --> Helper loaded: form_helper
INFO - 2024-10-28 09:35:48 --> Helper loaded: my_helper
INFO - 2024-10-28 09:35:48 --> Database Driver Class Initialized
INFO - 2024-10-28 09:35:48 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-28 09:35:48 --> Controller Class Initialized
INFO - 2024-10-28 09:35:52 --> Config Class Initialized
INFO - 2024-10-28 09:35:52 --> Hooks Class Initialized
DEBUG - 2024-10-28 09:35:52 --> UTF-8 Support Enabled
INFO - 2024-10-28 09:35:52 --> Utf8 Class Initialized
INFO - 2024-10-28 09:35:52 --> URI Class Initialized
INFO - 2024-10-28 09:35:52 --> Router Class Initialized
INFO - 2024-10-28 09:35:52 --> Output Class Initialized
INFO - 2024-10-28 09:35:52 --> Security Class Initialized
DEBUG - 2024-10-28 09:35:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-28 09:35:52 --> Input Class Initialized
INFO - 2024-10-28 09:35:52 --> Language Class Initialized
INFO - 2024-10-28 09:35:52 --> Language Class Initialized
INFO - 2024-10-28 09:35:52 --> Config Class Initialized
INFO - 2024-10-28 09:35:52 --> Loader Class Initialized
INFO - 2024-10-28 09:35:52 --> Helper loaded: url_helper
INFO - 2024-10-28 09:35:52 --> Helper loaded: file_helper
INFO - 2024-10-28 09:35:52 --> Helper loaded: form_helper
INFO - 2024-10-28 09:35:52 --> Helper loaded: my_helper
INFO - 2024-10-28 09:35:52 --> Database Driver Class Initialized
INFO - 2024-10-28 09:35:52 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-28 09:35:52 --> Controller Class Initialized
INFO - 2024-10-28 09:35:52 --> Config Class Initialized
INFO - 2024-10-28 09:35:52 --> Hooks Class Initialized
DEBUG - 2024-10-28 09:35:52 --> UTF-8 Support Enabled
INFO - 2024-10-28 09:35:52 --> Utf8 Class Initialized
INFO - 2024-10-28 09:35:52 --> URI Class Initialized
INFO - 2024-10-28 09:35:52 --> Router Class Initialized
INFO - 2024-10-28 09:35:52 --> Output Class Initialized
INFO - 2024-10-28 09:35:52 --> Security Class Initialized
DEBUG - 2024-10-28 09:35:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-28 09:35:52 --> Input Class Initialized
INFO - 2024-10-28 09:35:52 --> Language Class Initialized
INFO - 2024-10-28 09:35:52 --> Language Class Initialized
INFO - 2024-10-28 09:35:52 --> Config Class Initialized
INFO - 2024-10-28 09:35:52 --> Loader Class Initialized
INFO - 2024-10-28 09:35:52 --> Helper loaded: url_helper
INFO - 2024-10-28 09:35:52 --> Helper loaded: file_helper
INFO - 2024-10-28 09:35:52 --> Helper loaded: form_helper
INFO - 2024-10-28 09:35:52 --> Helper loaded: my_helper
INFO - 2024-10-28 09:35:52 --> Database Driver Class Initialized
INFO - 2024-10-28 09:35:52 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-28 09:35:52 --> Controller Class Initialized
INFO - 2024-10-28 09:35:54 --> Config Class Initialized
INFO - 2024-10-28 09:35:54 --> Hooks Class Initialized
DEBUG - 2024-10-28 09:35:54 --> UTF-8 Support Enabled
INFO - 2024-10-28 09:35:54 --> Utf8 Class Initialized
INFO - 2024-10-28 09:35:54 --> URI Class Initialized
INFO - 2024-10-28 09:35:54 --> Router Class Initialized
INFO - 2024-10-28 09:35:54 --> Output Class Initialized
INFO - 2024-10-28 09:35:54 --> Security Class Initialized
DEBUG - 2024-10-28 09:35:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-28 09:35:54 --> Input Class Initialized
INFO - 2024-10-28 09:35:54 --> Language Class Initialized
INFO - 2024-10-28 09:35:54 --> Language Class Initialized
INFO - 2024-10-28 09:35:54 --> Config Class Initialized
INFO - 2024-10-28 09:35:54 --> Loader Class Initialized
INFO - 2024-10-28 09:35:54 --> Helper loaded: url_helper
INFO - 2024-10-28 09:35:54 --> Helper loaded: file_helper
INFO - 2024-10-28 09:35:54 --> Helper loaded: form_helper
INFO - 2024-10-28 09:35:54 --> Helper loaded: my_helper
INFO - 2024-10-28 09:35:54 --> Database Driver Class Initialized
INFO - 2024-10-28 09:35:54 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-28 09:35:54 --> Controller Class Initialized
INFO - 2024-10-28 09:35:54 --> Config Class Initialized
INFO - 2024-10-28 09:35:54 --> Hooks Class Initialized
DEBUG - 2024-10-28 09:35:54 --> UTF-8 Support Enabled
INFO - 2024-10-28 09:35:54 --> Utf8 Class Initialized
INFO - 2024-10-28 09:35:54 --> URI Class Initialized
INFO - 2024-10-28 09:35:54 --> Router Class Initialized
INFO - 2024-10-28 09:35:54 --> Output Class Initialized
INFO - 2024-10-28 09:35:54 --> Security Class Initialized
DEBUG - 2024-10-28 09:35:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-28 09:35:54 --> Input Class Initialized
INFO - 2024-10-28 09:35:54 --> Language Class Initialized
INFO - 2024-10-28 09:35:54 --> Language Class Initialized
INFO - 2024-10-28 09:35:54 --> Config Class Initialized
INFO - 2024-10-28 09:35:54 --> Loader Class Initialized
INFO - 2024-10-28 09:35:54 --> Helper loaded: url_helper
INFO - 2024-10-28 09:35:54 --> Helper loaded: file_helper
INFO - 2024-10-28 09:35:54 --> Helper loaded: form_helper
INFO - 2024-10-28 09:35:54 --> Helper loaded: my_helper
INFO - 2024-10-28 09:35:54 --> Database Driver Class Initialized
INFO - 2024-10-28 09:35:54 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-28 09:35:54 --> Controller Class Initialized
INFO - 2024-10-28 09:35:55 --> Config Class Initialized
INFO - 2024-10-28 09:35:55 --> Hooks Class Initialized
DEBUG - 2024-10-28 09:35:55 --> UTF-8 Support Enabled
INFO - 2024-10-28 09:35:55 --> Utf8 Class Initialized
INFO - 2024-10-28 09:35:55 --> URI Class Initialized
INFO - 2024-10-28 09:35:55 --> Router Class Initialized
INFO - 2024-10-28 09:35:55 --> Output Class Initialized
INFO - 2024-10-28 09:35:55 --> Security Class Initialized
DEBUG - 2024-10-28 09:35:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-28 09:35:55 --> Input Class Initialized
INFO - 2024-10-28 09:35:55 --> Language Class Initialized
INFO - 2024-10-28 09:35:55 --> Language Class Initialized
INFO - 2024-10-28 09:35:55 --> Config Class Initialized
INFO - 2024-10-28 09:35:55 --> Loader Class Initialized
INFO - 2024-10-28 09:35:55 --> Helper loaded: url_helper
INFO - 2024-10-28 09:35:55 --> Helper loaded: file_helper
INFO - 2024-10-28 09:35:55 --> Helper loaded: form_helper
INFO - 2024-10-28 09:35:55 --> Helper loaded: my_helper
INFO - 2024-10-28 09:35:55 --> Database Driver Class Initialized
INFO - 2024-10-28 09:35:55 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-28 09:35:55 --> Controller Class Initialized
INFO - 2024-10-28 09:35:57 --> Config Class Initialized
INFO - 2024-10-28 09:35:57 --> Hooks Class Initialized
DEBUG - 2024-10-28 09:35:57 --> UTF-8 Support Enabled
INFO - 2024-10-28 09:35:57 --> Utf8 Class Initialized
INFO - 2024-10-28 09:35:57 --> URI Class Initialized
INFO - 2024-10-28 09:35:57 --> Router Class Initialized
INFO - 2024-10-28 09:35:57 --> Output Class Initialized
INFO - 2024-10-28 09:35:57 --> Security Class Initialized
DEBUG - 2024-10-28 09:35:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-28 09:35:57 --> Input Class Initialized
INFO - 2024-10-28 09:35:57 --> Language Class Initialized
INFO - 2024-10-28 09:35:57 --> Language Class Initialized
INFO - 2024-10-28 09:35:57 --> Config Class Initialized
INFO - 2024-10-28 09:35:57 --> Loader Class Initialized
INFO - 2024-10-28 09:35:57 --> Helper loaded: url_helper
INFO - 2024-10-28 09:35:57 --> Helper loaded: file_helper
INFO - 2024-10-28 09:35:57 --> Helper loaded: form_helper
INFO - 2024-10-28 09:35:57 --> Helper loaded: my_helper
INFO - 2024-10-28 09:35:57 --> Database Driver Class Initialized
INFO - 2024-10-28 09:35:57 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-28 09:35:57 --> Controller Class Initialized
ERROR - 2024-10-28 09:35:57 --> Severity: Notice --> Undefined variable: status_form /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/data_siswa/views/form.php 231
DEBUG - 2024-10-28 09:35:57 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/data_siswa/views/form.php
DEBUG - 2024-10-28 09:35:57 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-10-28 09:35:57 --> Final output sent to browser
DEBUG - 2024-10-28 09:35:57 --> Total execution time: 0.0349
INFO - 2024-10-28 09:36:04 --> Config Class Initialized
INFO - 2024-10-28 09:36:04 --> Hooks Class Initialized
DEBUG - 2024-10-28 09:36:04 --> UTF-8 Support Enabled
INFO - 2024-10-28 09:36:04 --> Utf8 Class Initialized
INFO - 2024-10-28 09:36:04 --> URI Class Initialized
INFO - 2024-10-28 09:36:04 --> Router Class Initialized
INFO - 2024-10-28 09:36:04 --> Output Class Initialized
INFO - 2024-10-28 09:36:04 --> Security Class Initialized
DEBUG - 2024-10-28 09:36:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-28 09:36:04 --> Input Class Initialized
INFO - 2024-10-28 09:36:04 --> Language Class Initialized
INFO - 2024-10-28 09:36:04 --> Language Class Initialized
INFO - 2024-10-28 09:36:04 --> Config Class Initialized
INFO - 2024-10-28 09:36:04 --> Loader Class Initialized
INFO - 2024-10-28 09:36:04 --> Helper loaded: url_helper
INFO - 2024-10-28 09:36:04 --> Helper loaded: file_helper
INFO - 2024-10-28 09:36:04 --> Helper loaded: form_helper
INFO - 2024-10-28 09:36:04 --> Helper loaded: my_helper
INFO - 2024-10-28 09:36:04 --> Database Driver Class Initialized
INFO - 2024-10-28 09:36:04 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-28 09:36:04 --> Controller Class Initialized
INFO - 2024-10-28 09:36:04 --> Upload Class Initialized
INFO - 2024-10-28 09:36:04 --> Language file loaded: language/english/upload_lang.php
ERROR - 2024-10-28 09:36:04 --> The upload path does not appear to be valid.
INFO - 2024-10-28 09:36:04 --> Config Class Initialized
INFO - 2024-10-28 09:36:04 --> Hooks Class Initialized
DEBUG - 2024-10-28 09:36:04 --> UTF-8 Support Enabled
INFO - 2024-10-28 09:36:04 --> Utf8 Class Initialized
INFO - 2024-10-28 09:36:04 --> URI Class Initialized
INFO - 2024-10-28 09:36:04 --> Router Class Initialized
INFO - 2024-10-28 09:36:04 --> Output Class Initialized
INFO - 2024-10-28 09:36:04 --> Security Class Initialized
DEBUG - 2024-10-28 09:36:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-28 09:36:04 --> Input Class Initialized
INFO - 2024-10-28 09:36:04 --> Language Class Initialized
INFO - 2024-10-28 09:36:04 --> Language Class Initialized
INFO - 2024-10-28 09:36:04 --> Config Class Initialized
INFO - 2024-10-28 09:36:04 --> Loader Class Initialized
INFO - 2024-10-28 09:36:04 --> Helper loaded: url_helper
INFO - 2024-10-28 09:36:04 --> Helper loaded: file_helper
INFO - 2024-10-28 09:36:04 --> Helper loaded: form_helper
INFO - 2024-10-28 09:36:04 --> Helper loaded: my_helper
INFO - 2024-10-28 09:36:04 --> Database Driver Class Initialized
INFO - 2024-10-28 09:36:04 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-28 09:36:04 --> Controller Class Initialized
DEBUG - 2024-10-28 09:36:04 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/data_siswa/views/list.php
DEBUG - 2024-10-28 09:36:04 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-10-28 09:36:04 --> Final output sent to browser
DEBUG - 2024-10-28 09:36:04 --> Total execution time: 0.0373
INFO - 2024-10-28 09:36:04 --> Config Class Initialized
INFO - 2024-10-28 09:36:04 --> Hooks Class Initialized
DEBUG - 2024-10-28 09:36:04 --> UTF-8 Support Enabled
INFO - 2024-10-28 09:36:04 --> Utf8 Class Initialized
INFO - 2024-10-28 09:36:04 --> URI Class Initialized
INFO - 2024-10-28 09:36:04 --> Router Class Initialized
INFO - 2024-10-28 09:36:04 --> Output Class Initialized
INFO - 2024-10-28 09:36:04 --> Security Class Initialized
DEBUG - 2024-10-28 09:36:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-28 09:36:04 --> Input Class Initialized
INFO - 2024-10-28 09:36:04 --> Language Class Initialized
ERROR - 2024-10-28 09:36:04 --> 404 Page Not Found: /index
INFO - 2024-10-28 09:36:04 --> Config Class Initialized
INFO - 2024-10-28 09:36:04 --> Hooks Class Initialized
DEBUG - 2024-10-28 09:36:04 --> UTF-8 Support Enabled
INFO - 2024-10-28 09:36:04 --> Utf8 Class Initialized
INFO - 2024-10-28 09:36:04 --> URI Class Initialized
INFO - 2024-10-28 09:36:04 --> Router Class Initialized
INFO - 2024-10-28 09:36:04 --> Output Class Initialized
INFO - 2024-10-28 09:36:04 --> Security Class Initialized
DEBUG - 2024-10-28 09:36:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-28 09:36:04 --> Input Class Initialized
INFO - 2024-10-28 09:36:04 --> Language Class Initialized
INFO - 2024-10-28 09:36:04 --> Language Class Initialized
INFO - 2024-10-28 09:36:04 --> Config Class Initialized
INFO - 2024-10-28 09:36:04 --> Loader Class Initialized
INFO - 2024-10-28 09:36:04 --> Helper loaded: url_helper
INFO - 2024-10-28 09:36:04 --> Helper loaded: file_helper
INFO - 2024-10-28 09:36:04 --> Helper loaded: form_helper
INFO - 2024-10-28 09:36:04 --> Helper loaded: my_helper
INFO - 2024-10-28 09:36:04 --> Database Driver Class Initialized
INFO - 2024-10-28 09:36:04 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-28 09:36:04 --> Controller Class Initialized
INFO - 2024-10-28 09:36:07 --> Config Class Initialized
INFO - 2024-10-28 09:36:07 --> Hooks Class Initialized
DEBUG - 2024-10-28 09:36:07 --> UTF-8 Support Enabled
INFO - 2024-10-28 09:36:07 --> Utf8 Class Initialized
INFO - 2024-10-28 09:36:07 --> URI Class Initialized
INFO - 2024-10-28 09:36:07 --> Router Class Initialized
INFO - 2024-10-28 09:36:07 --> Output Class Initialized
INFO - 2024-10-28 09:36:07 --> Security Class Initialized
DEBUG - 2024-10-28 09:36:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-28 09:36:07 --> Input Class Initialized
INFO - 2024-10-28 09:36:07 --> Language Class Initialized
INFO - 2024-10-28 09:36:07 --> Language Class Initialized
INFO - 2024-10-28 09:36:07 --> Config Class Initialized
INFO - 2024-10-28 09:36:07 --> Loader Class Initialized
INFO - 2024-10-28 09:36:07 --> Helper loaded: url_helper
INFO - 2024-10-28 09:36:07 --> Helper loaded: file_helper
INFO - 2024-10-28 09:36:07 --> Helper loaded: form_helper
INFO - 2024-10-28 09:36:07 --> Helper loaded: my_helper
INFO - 2024-10-28 09:36:07 --> Database Driver Class Initialized
INFO - 2024-10-28 09:36:07 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-28 09:36:07 --> Controller Class Initialized
INFO - 2024-10-28 09:36:08 --> Config Class Initialized
INFO - 2024-10-28 09:36:08 --> Hooks Class Initialized
DEBUG - 2024-10-28 09:36:08 --> UTF-8 Support Enabled
INFO - 2024-10-28 09:36:08 --> Utf8 Class Initialized
INFO - 2024-10-28 09:36:08 --> URI Class Initialized
INFO - 2024-10-28 09:36:08 --> Router Class Initialized
INFO - 2024-10-28 09:36:08 --> Output Class Initialized
INFO - 2024-10-28 09:36:08 --> Security Class Initialized
DEBUG - 2024-10-28 09:36:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-28 09:36:08 --> Input Class Initialized
INFO - 2024-10-28 09:36:08 --> Language Class Initialized
INFO - 2024-10-28 09:36:08 --> Language Class Initialized
INFO - 2024-10-28 09:36:08 --> Config Class Initialized
INFO - 2024-10-28 09:36:08 --> Loader Class Initialized
INFO - 2024-10-28 09:36:08 --> Helper loaded: url_helper
INFO - 2024-10-28 09:36:08 --> Helper loaded: file_helper
INFO - 2024-10-28 09:36:08 --> Helper loaded: form_helper
INFO - 2024-10-28 09:36:08 --> Helper loaded: my_helper
INFO - 2024-10-28 09:36:08 --> Database Driver Class Initialized
INFO - 2024-10-28 09:36:08 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-28 09:36:08 --> Controller Class Initialized
INFO - 2024-10-28 09:36:10 --> Config Class Initialized
INFO - 2024-10-28 09:36:10 --> Hooks Class Initialized
DEBUG - 2024-10-28 09:36:10 --> UTF-8 Support Enabled
INFO - 2024-10-28 09:36:10 --> Utf8 Class Initialized
INFO - 2024-10-28 09:36:10 --> URI Class Initialized
INFO - 2024-10-28 09:36:10 --> Router Class Initialized
INFO - 2024-10-28 09:36:10 --> Output Class Initialized
INFO - 2024-10-28 09:36:10 --> Security Class Initialized
DEBUG - 2024-10-28 09:36:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-28 09:36:10 --> Input Class Initialized
INFO - 2024-10-28 09:36:10 --> Language Class Initialized
INFO - 2024-10-28 09:36:10 --> Language Class Initialized
INFO - 2024-10-28 09:36:10 --> Config Class Initialized
INFO - 2024-10-28 09:36:10 --> Loader Class Initialized
INFO - 2024-10-28 09:36:10 --> Helper loaded: url_helper
INFO - 2024-10-28 09:36:10 --> Helper loaded: file_helper
INFO - 2024-10-28 09:36:10 --> Helper loaded: form_helper
INFO - 2024-10-28 09:36:10 --> Helper loaded: my_helper
INFO - 2024-10-28 09:36:10 --> Database Driver Class Initialized
INFO - 2024-10-28 09:36:10 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-28 09:36:10 --> Controller Class Initialized
ERROR - 2024-10-28 09:36:10 --> Severity: Notice --> Undefined variable: status_form /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/data_siswa/views/form.php 231
DEBUG - 2024-10-28 09:36:10 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/data_siswa/views/form.php
DEBUG - 2024-10-28 09:36:10 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-10-28 09:36:10 --> Final output sent to browser
DEBUG - 2024-10-28 09:36:10 --> Total execution time: 0.0425
INFO - 2024-10-28 09:36:16 --> Config Class Initialized
INFO - 2024-10-28 09:36:16 --> Hooks Class Initialized
DEBUG - 2024-10-28 09:36:16 --> UTF-8 Support Enabled
INFO - 2024-10-28 09:36:16 --> Utf8 Class Initialized
INFO - 2024-10-28 09:36:16 --> URI Class Initialized
INFO - 2024-10-28 09:36:16 --> Router Class Initialized
INFO - 2024-10-28 09:36:16 --> Output Class Initialized
INFO - 2024-10-28 09:36:16 --> Security Class Initialized
DEBUG - 2024-10-28 09:36:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-28 09:36:16 --> Input Class Initialized
INFO - 2024-10-28 09:36:16 --> Language Class Initialized
INFO - 2024-10-28 09:36:16 --> Language Class Initialized
INFO - 2024-10-28 09:36:16 --> Config Class Initialized
INFO - 2024-10-28 09:36:16 --> Loader Class Initialized
INFO - 2024-10-28 09:36:16 --> Helper loaded: url_helper
INFO - 2024-10-28 09:36:16 --> Helper loaded: file_helper
INFO - 2024-10-28 09:36:16 --> Helper loaded: form_helper
INFO - 2024-10-28 09:36:16 --> Helper loaded: my_helper
INFO - 2024-10-28 09:36:16 --> Database Driver Class Initialized
INFO - 2024-10-28 09:36:16 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-28 09:36:16 --> Controller Class Initialized
INFO - 2024-10-28 09:36:16 --> Upload Class Initialized
INFO - 2024-10-28 09:36:16 --> Language file loaded: language/english/upload_lang.php
ERROR - 2024-10-28 09:36:16 --> The upload path does not appear to be valid.
INFO - 2024-10-28 09:36:17 --> Config Class Initialized
INFO - 2024-10-28 09:36:17 --> Hooks Class Initialized
DEBUG - 2024-10-28 09:36:17 --> UTF-8 Support Enabled
INFO - 2024-10-28 09:36:17 --> Utf8 Class Initialized
INFO - 2024-10-28 09:36:17 --> URI Class Initialized
INFO - 2024-10-28 09:36:17 --> Router Class Initialized
INFO - 2024-10-28 09:36:17 --> Output Class Initialized
INFO - 2024-10-28 09:36:17 --> Security Class Initialized
DEBUG - 2024-10-28 09:36:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-28 09:36:17 --> Input Class Initialized
INFO - 2024-10-28 09:36:17 --> Language Class Initialized
INFO - 2024-10-28 09:36:17 --> Language Class Initialized
INFO - 2024-10-28 09:36:17 --> Config Class Initialized
INFO - 2024-10-28 09:36:17 --> Loader Class Initialized
INFO - 2024-10-28 09:36:17 --> Helper loaded: url_helper
INFO - 2024-10-28 09:36:17 --> Helper loaded: file_helper
INFO - 2024-10-28 09:36:17 --> Helper loaded: form_helper
INFO - 2024-10-28 09:36:17 --> Helper loaded: my_helper
INFO - 2024-10-28 09:36:17 --> Database Driver Class Initialized
INFO - 2024-10-28 09:36:17 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-28 09:36:17 --> Controller Class Initialized
DEBUG - 2024-10-28 09:36:17 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/data_siswa/views/list.php
DEBUG - 2024-10-28 09:36:17 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-10-28 09:36:17 --> Final output sent to browser
DEBUG - 2024-10-28 09:36:17 --> Total execution time: 0.0501
INFO - 2024-10-28 09:36:17 --> Config Class Initialized
INFO - 2024-10-28 09:36:17 --> Hooks Class Initialized
DEBUG - 2024-10-28 09:36:17 --> UTF-8 Support Enabled
INFO - 2024-10-28 09:36:17 --> Utf8 Class Initialized
INFO - 2024-10-28 09:36:17 --> URI Class Initialized
INFO - 2024-10-28 09:36:17 --> Router Class Initialized
INFO - 2024-10-28 09:36:17 --> Output Class Initialized
INFO - 2024-10-28 09:36:17 --> Security Class Initialized
DEBUG - 2024-10-28 09:36:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-28 09:36:17 --> Input Class Initialized
INFO - 2024-10-28 09:36:17 --> Language Class Initialized
ERROR - 2024-10-28 09:36:17 --> 404 Page Not Found: /index
INFO - 2024-10-28 09:36:17 --> Config Class Initialized
INFO - 2024-10-28 09:36:17 --> Hooks Class Initialized
DEBUG - 2024-10-28 09:36:17 --> UTF-8 Support Enabled
INFO - 2024-10-28 09:36:17 --> Utf8 Class Initialized
INFO - 2024-10-28 09:36:17 --> URI Class Initialized
INFO - 2024-10-28 09:36:17 --> Router Class Initialized
INFO - 2024-10-28 09:36:17 --> Output Class Initialized
INFO - 2024-10-28 09:36:17 --> Security Class Initialized
DEBUG - 2024-10-28 09:36:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-28 09:36:17 --> Input Class Initialized
INFO - 2024-10-28 09:36:17 --> Language Class Initialized
INFO - 2024-10-28 09:36:17 --> Language Class Initialized
INFO - 2024-10-28 09:36:17 --> Config Class Initialized
INFO - 2024-10-28 09:36:17 --> Loader Class Initialized
INFO - 2024-10-28 09:36:17 --> Helper loaded: url_helper
INFO - 2024-10-28 09:36:17 --> Helper loaded: file_helper
INFO - 2024-10-28 09:36:17 --> Helper loaded: form_helper
INFO - 2024-10-28 09:36:17 --> Helper loaded: my_helper
INFO - 2024-10-28 09:36:17 --> Database Driver Class Initialized
INFO - 2024-10-28 09:36:17 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-28 09:36:17 --> Controller Class Initialized
INFO - 2024-10-28 11:48:18 --> Config Class Initialized
INFO - 2024-10-28 11:48:18 --> Hooks Class Initialized
DEBUG - 2024-10-28 11:48:18 --> UTF-8 Support Enabled
INFO - 2024-10-28 11:48:18 --> Utf8 Class Initialized
INFO - 2024-10-28 11:48:18 --> URI Class Initialized
INFO - 2024-10-28 11:48:18 --> Router Class Initialized
INFO - 2024-10-28 11:48:18 --> Output Class Initialized
INFO - 2024-10-28 11:48:18 --> Security Class Initialized
DEBUG - 2024-10-28 11:48:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-28 11:48:18 --> Input Class Initialized
INFO - 2024-10-28 11:48:18 --> Language Class Initialized
INFO - 2024-10-28 11:48:18 --> Language Class Initialized
INFO - 2024-10-28 11:48:18 --> Config Class Initialized
INFO - 2024-10-28 11:48:18 --> Loader Class Initialized
INFO - 2024-10-28 11:48:18 --> Helper loaded: url_helper
INFO - 2024-10-28 11:48:18 --> Helper loaded: file_helper
INFO - 2024-10-28 11:48:18 --> Helper loaded: form_helper
INFO - 2024-10-28 11:48:18 --> Helper loaded: my_helper
INFO - 2024-10-28 11:48:18 --> Database Driver Class Initialized
INFO - 2024-10-28 11:48:18 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-28 11:48:18 --> Controller Class Initialized
DEBUG - 2024-10-28 11:48:18 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/login/views/login.php
DEBUG - 2024-10-28 11:48:18 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-10-28 11:48:18 --> Final output sent to browser
DEBUG - 2024-10-28 11:48:18 --> Total execution time: 0.0465
INFO - 2024-10-28 11:48:22 --> Config Class Initialized
INFO - 2024-10-28 11:48:22 --> Hooks Class Initialized
DEBUG - 2024-10-28 11:48:22 --> UTF-8 Support Enabled
INFO - 2024-10-28 11:48:22 --> Utf8 Class Initialized
INFO - 2024-10-28 11:48:22 --> URI Class Initialized
INFO - 2024-10-28 11:48:22 --> Router Class Initialized
INFO - 2024-10-28 11:48:22 --> Output Class Initialized
INFO - 2024-10-28 11:48:22 --> Security Class Initialized
DEBUG - 2024-10-28 11:48:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-28 11:48:22 --> Input Class Initialized
INFO - 2024-10-28 11:48:22 --> Language Class Initialized
INFO - 2024-10-28 11:48:22 --> Language Class Initialized
INFO - 2024-10-28 11:48:22 --> Config Class Initialized
INFO - 2024-10-28 11:48:22 --> Loader Class Initialized
INFO - 2024-10-28 11:48:22 --> Helper loaded: url_helper
INFO - 2024-10-28 11:48:22 --> Helper loaded: file_helper
INFO - 2024-10-28 11:48:22 --> Helper loaded: form_helper
INFO - 2024-10-28 11:48:22 --> Helper loaded: my_helper
INFO - 2024-10-28 11:48:22 --> Database Driver Class Initialized
INFO - 2024-10-28 11:48:22 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-28 11:48:22 --> Controller Class Initialized
INFO - 2024-10-28 11:48:22 --> Helper loaded: cookie_helper
INFO - 2024-10-28 11:48:22 --> Final output sent to browser
DEBUG - 2024-10-28 11:48:22 --> Total execution time: 0.0276
INFO - 2024-10-28 11:48:22 --> Config Class Initialized
INFO - 2024-10-28 11:48:22 --> Hooks Class Initialized
DEBUG - 2024-10-28 11:48:22 --> UTF-8 Support Enabled
INFO - 2024-10-28 11:48:22 --> Utf8 Class Initialized
INFO - 2024-10-28 11:48:22 --> URI Class Initialized
INFO - 2024-10-28 11:48:22 --> Router Class Initialized
INFO - 2024-10-28 11:48:22 --> Output Class Initialized
INFO - 2024-10-28 11:48:22 --> Security Class Initialized
DEBUG - 2024-10-28 11:48:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-28 11:48:22 --> Input Class Initialized
INFO - 2024-10-28 11:48:22 --> Language Class Initialized
INFO - 2024-10-28 11:48:22 --> Language Class Initialized
INFO - 2024-10-28 11:48:22 --> Config Class Initialized
INFO - 2024-10-28 11:48:22 --> Loader Class Initialized
INFO - 2024-10-28 11:48:22 --> Helper loaded: url_helper
INFO - 2024-10-28 11:48:22 --> Helper loaded: file_helper
INFO - 2024-10-28 11:48:22 --> Helper loaded: form_helper
INFO - 2024-10-28 11:48:22 --> Helper loaded: my_helper
INFO - 2024-10-28 11:48:22 --> Database Driver Class Initialized
INFO - 2024-10-28 11:48:22 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-28 11:48:22 --> Controller Class Initialized
DEBUG - 2024-10-28 11:48:22 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/home/views/v_home.php
DEBUG - 2024-10-28 11:48:22 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-10-28 11:48:22 --> Final output sent to browser
DEBUG - 2024-10-28 11:48:22 --> Total execution time: 0.0310
INFO - 2024-10-28 11:48:26 --> Config Class Initialized
INFO - 2024-10-28 11:48:26 --> Hooks Class Initialized
DEBUG - 2024-10-28 11:48:26 --> UTF-8 Support Enabled
INFO - 2024-10-28 11:48:26 --> Utf8 Class Initialized
INFO - 2024-10-28 11:48:26 --> URI Class Initialized
INFO - 2024-10-28 11:48:26 --> Router Class Initialized
INFO - 2024-10-28 11:48:26 --> Output Class Initialized
INFO - 2024-10-28 11:48:26 --> Security Class Initialized
DEBUG - 2024-10-28 11:48:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-28 11:48:26 --> Input Class Initialized
INFO - 2024-10-28 11:48:26 --> Language Class Initialized
INFO - 2024-10-28 11:48:26 --> Language Class Initialized
INFO - 2024-10-28 11:48:26 --> Config Class Initialized
INFO - 2024-10-28 11:48:26 --> Loader Class Initialized
INFO - 2024-10-28 11:48:26 --> Helper loaded: url_helper
INFO - 2024-10-28 11:48:26 --> Helper loaded: file_helper
INFO - 2024-10-28 11:48:26 --> Helper loaded: form_helper
INFO - 2024-10-28 11:48:26 --> Helper loaded: my_helper
INFO - 2024-10-28 11:48:26 --> Database Driver Class Initialized
INFO - 2024-10-28 11:48:26 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-28 11:48:26 --> Controller Class Initialized
DEBUG - 2024-10-28 11:48:26 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/data_siswa/views/list.php
DEBUG - 2024-10-28 11:48:26 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-10-28 11:48:26 --> Final output sent to browser
DEBUG - 2024-10-28 11:48:26 --> Total execution time: 0.0299
INFO - 2024-10-28 11:48:26 --> Config Class Initialized
INFO - 2024-10-28 11:48:26 --> Hooks Class Initialized
DEBUG - 2024-10-28 11:48:26 --> UTF-8 Support Enabled
INFO - 2024-10-28 11:48:26 --> Utf8 Class Initialized
INFO - 2024-10-28 11:48:26 --> URI Class Initialized
INFO - 2024-10-28 11:48:26 --> Router Class Initialized
INFO - 2024-10-28 11:48:26 --> Output Class Initialized
INFO - 2024-10-28 11:48:26 --> Security Class Initialized
DEBUG - 2024-10-28 11:48:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-28 11:48:26 --> Input Class Initialized
INFO - 2024-10-28 11:48:26 --> Language Class Initialized
ERROR - 2024-10-28 11:48:26 --> 404 Page Not Found: /index
INFO - 2024-10-28 11:48:26 --> Config Class Initialized
INFO - 2024-10-28 11:48:26 --> Hooks Class Initialized
DEBUG - 2024-10-28 11:48:26 --> UTF-8 Support Enabled
INFO - 2024-10-28 11:48:26 --> Utf8 Class Initialized
INFO - 2024-10-28 11:48:26 --> URI Class Initialized
INFO - 2024-10-28 11:48:26 --> Router Class Initialized
INFO - 2024-10-28 11:48:26 --> Output Class Initialized
INFO - 2024-10-28 11:48:26 --> Security Class Initialized
DEBUG - 2024-10-28 11:48:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-28 11:48:26 --> Input Class Initialized
INFO - 2024-10-28 11:48:26 --> Language Class Initialized
INFO - 2024-10-28 11:48:26 --> Language Class Initialized
INFO - 2024-10-28 11:48:26 --> Config Class Initialized
INFO - 2024-10-28 11:48:26 --> Loader Class Initialized
INFO - 2024-10-28 11:48:26 --> Helper loaded: url_helper
INFO - 2024-10-28 11:48:26 --> Helper loaded: file_helper
INFO - 2024-10-28 11:48:26 --> Helper loaded: form_helper
INFO - 2024-10-28 11:48:26 --> Helper loaded: my_helper
INFO - 2024-10-28 11:48:26 --> Database Driver Class Initialized
INFO - 2024-10-28 11:48:26 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-28 11:48:26 --> Controller Class Initialized
INFO - 2024-10-28 11:48:30 --> Config Class Initialized
INFO - 2024-10-28 11:48:30 --> Hooks Class Initialized
DEBUG - 2024-10-28 11:48:30 --> UTF-8 Support Enabled
INFO - 2024-10-28 11:48:30 --> Utf8 Class Initialized
INFO - 2024-10-28 11:48:30 --> URI Class Initialized
INFO - 2024-10-28 11:48:30 --> Router Class Initialized
INFO - 2024-10-28 11:48:30 --> Output Class Initialized
INFO - 2024-10-28 11:48:30 --> Security Class Initialized
DEBUG - 2024-10-28 11:48:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-28 11:48:30 --> Input Class Initialized
INFO - 2024-10-28 11:48:30 --> Language Class Initialized
INFO - 2024-10-28 11:48:30 --> Language Class Initialized
INFO - 2024-10-28 11:48:30 --> Config Class Initialized
INFO - 2024-10-28 11:48:30 --> Loader Class Initialized
INFO - 2024-10-28 11:48:30 --> Helper loaded: url_helper
INFO - 2024-10-28 11:48:30 --> Helper loaded: file_helper
INFO - 2024-10-28 11:48:30 --> Helper loaded: form_helper
INFO - 2024-10-28 11:48:30 --> Helper loaded: my_helper
INFO - 2024-10-28 11:48:30 --> Database Driver Class Initialized
INFO - 2024-10-28 11:48:30 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-28 11:48:30 --> Controller Class Initialized
INFO - 2024-10-28 11:48:30 --> Config Class Initialized
INFO - 2024-10-28 11:48:30 --> Hooks Class Initialized
DEBUG - 2024-10-28 11:48:30 --> UTF-8 Support Enabled
INFO - 2024-10-28 11:48:30 --> Utf8 Class Initialized
INFO - 2024-10-28 11:48:30 --> URI Class Initialized
INFO - 2024-10-28 11:48:30 --> Router Class Initialized
INFO - 2024-10-28 11:48:30 --> Output Class Initialized
INFO - 2024-10-28 11:48:30 --> Security Class Initialized
DEBUG - 2024-10-28 11:48:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-28 11:48:30 --> Input Class Initialized
INFO - 2024-10-28 11:48:30 --> Language Class Initialized
INFO - 2024-10-28 11:48:30 --> Language Class Initialized
INFO - 2024-10-28 11:48:30 --> Config Class Initialized
INFO - 2024-10-28 11:48:30 --> Loader Class Initialized
INFO - 2024-10-28 11:48:30 --> Helper loaded: url_helper
INFO - 2024-10-28 11:48:30 --> Helper loaded: file_helper
INFO - 2024-10-28 11:48:30 --> Helper loaded: form_helper
INFO - 2024-10-28 11:48:30 --> Helper loaded: my_helper
INFO - 2024-10-28 11:48:30 --> Database Driver Class Initialized
INFO - 2024-10-28 11:48:30 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-28 11:48:30 --> Controller Class Initialized
INFO - 2024-10-28 11:48:31 --> Config Class Initialized
INFO - 2024-10-28 11:48:31 --> Hooks Class Initialized
DEBUG - 2024-10-28 11:48:31 --> UTF-8 Support Enabled
INFO - 2024-10-28 11:48:31 --> Utf8 Class Initialized
INFO - 2024-10-28 11:48:31 --> URI Class Initialized
INFO - 2024-10-28 11:48:31 --> Router Class Initialized
INFO - 2024-10-28 11:48:31 --> Output Class Initialized
INFO - 2024-10-28 11:48:31 --> Security Class Initialized
DEBUG - 2024-10-28 11:48:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-28 11:48:31 --> Input Class Initialized
INFO - 2024-10-28 11:48:31 --> Language Class Initialized
INFO - 2024-10-28 11:48:31 --> Language Class Initialized
INFO - 2024-10-28 11:48:31 --> Config Class Initialized
INFO - 2024-10-28 11:48:31 --> Loader Class Initialized
INFO - 2024-10-28 11:48:31 --> Helper loaded: url_helper
INFO - 2024-10-28 11:48:31 --> Helper loaded: file_helper
INFO - 2024-10-28 11:48:31 --> Helper loaded: form_helper
INFO - 2024-10-28 11:48:31 --> Helper loaded: my_helper
INFO - 2024-10-28 11:48:31 --> Database Driver Class Initialized
INFO - 2024-10-28 11:48:31 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-28 11:48:31 --> Controller Class Initialized
INFO - 2024-10-28 11:48:32 --> Config Class Initialized
INFO - 2024-10-28 11:48:32 --> Hooks Class Initialized
DEBUG - 2024-10-28 11:48:32 --> UTF-8 Support Enabled
INFO - 2024-10-28 11:48:32 --> Utf8 Class Initialized
INFO - 2024-10-28 11:48:32 --> URI Class Initialized
INFO - 2024-10-28 11:48:32 --> Router Class Initialized
INFO - 2024-10-28 11:48:32 --> Output Class Initialized
INFO - 2024-10-28 11:48:32 --> Security Class Initialized
DEBUG - 2024-10-28 11:48:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-28 11:48:32 --> Input Class Initialized
INFO - 2024-10-28 11:48:32 --> Language Class Initialized
INFO - 2024-10-28 11:48:32 --> Language Class Initialized
INFO - 2024-10-28 11:48:32 --> Config Class Initialized
INFO - 2024-10-28 11:48:32 --> Loader Class Initialized
INFO - 2024-10-28 11:48:32 --> Helper loaded: url_helper
INFO - 2024-10-28 11:48:32 --> Helper loaded: file_helper
INFO - 2024-10-28 11:48:32 --> Helper loaded: form_helper
INFO - 2024-10-28 11:48:32 --> Helper loaded: my_helper
INFO - 2024-10-28 11:48:32 --> Database Driver Class Initialized
INFO - 2024-10-28 11:48:32 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-28 11:48:32 --> Controller Class Initialized
ERROR - 2024-10-28 11:48:32 --> Severity: Notice --> Undefined variable: status_form /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/data_siswa/views/form.php 231
DEBUG - 2024-10-28 11:48:32 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/data_siswa/views/form.php
DEBUG - 2024-10-28 11:48:32 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-10-28 11:48:32 --> Final output sent to browser
DEBUG - 2024-10-28 11:48:32 --> Total execution time: 0.0288
INFO - 2024-10-28 11:48:46 --> Config Class Initialized
INFO - 2024-10-28 11:48:46 --> Hooks Class Initialized
DEBUG - 2024-10-28 11:48:46 --> UTF-8 Support Enabled
INFO - 2024-10-28 11:48:46 --> Utf8 Class Initialized
INFO - 2024-10-28 11:48:46 --> URI Class Initialized
INFO - 2024-10-28 11:48:46 --> Router Class Initialized
INFO - 2024-10-28 11:48:46 --> Output Class Initialized
INFO - 2024-10-28 11:48:46 --> Security Class Initialized
DEBUG - 2024-10-28 11:48:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-28 11:48:46 --> Input Class Initialized
INFO - 2024-10-28 11:48:46 --> Language Class Initialized
INFO - 2024-10-28 11:48:46 --> Language Class Initialized
INFO - 2024-10-28 11:48:46 --> Config Class Initialized
INFO - 2024-10-28 11:48:46 --> Loader Class Initialized
INFO - 2024-10-28 11:48:46 --> Helper loaded: url_helper
INFO - 2024-10-28 11:48:46 --> Helper loaded: file_helper
INFO - 2024-10-28 11:48:46 --> Helper loaded: form_helper
INFO - 2024-10-28 11:48:46 --> Helper loaded: my_helper
INFO - 2024-10-28 11:48:46 --> Database Driver Class Initialized
INFO - 2024-10-28 11:48:46 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-28 11:48:46 --> Controller Class Initialized
INFO - 2024-10-28 11:48:46 --> Upload Class Initialized
INFO - 2024-10-28 11:48:46 --> Language file loaded: language/english/upload_lang.php
ERROR - 2024-10-28 11:48:46 --> The upload path does not appear to be valid.
INFO - 2024-10-28 11:48:47 --> Config Class Initialized
INFO - 2024-10-28 11:48:47 --> Hooks Class Initialized
DEBUG - 2024-10-28 11:48:47 --> UTF-8 Support Enabled
INFO - 2024-10-28 11:48:47 --> Utf8 Class Initialized
INFO - 2024-10-28 11:48:47 --> URI Class Initialized
INFO - 2024-10-28 11:48:47 --> Router Class Initialized
INFO - 2024-10-28 11:48:47 --> Output Class Initialized
INFO - 2024-10-28 11:48:47 --> Security Class Initialized
DEBUG - 2024-10-28 11:48:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-28 11:48:47 --> Input Class Initialized
INFO - 2024-10-28 11:48:47 --> Language Class Initialized
INFO - 2024-10-28 11:48:47 --> Language Class Initialized
INFO - 2024-10-28 11:48:47 --> Config Class Initialized
INFO - 2024-10-28 11:48:47 --> Loader Class Initialized
INFO - 2024-10-28 11:48:47 --> Helper loaded: url_helper
INFO - 2024-10-28 11:48:47 --> Helper loaded: file_helper
INFO - 2024-10-28 11:48:47 --> Helper loaded: form_helper
INFO - 2024-10-28 11:48:47 --> Helper loaded: my_helper
INFO - 2024-10-28 11:48:47 --> Database Driver Class Initialized
INFO - 2024-10-28 11:48:47 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-28 11:48:47 --> Controller Class Initialized
DEBUG - 2024-10-28 11:48:47 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/data_siswa/views/list.php
DEBUG - 2024-10-28 11:48:47 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-10-28 11:48:47 --> Final output sent to browser
DEBUG - 2024-10-28 11:48:47 --> Total execution time: 0.0262
INFO - 2024-10-28 11:48:47 --> Config Class Initialized
INFO - 2024-10-28 11:48:47 --> Hooks Class Initialized
DEBUG - 2024-10-28 11:48:47 --> UTF-8 Support Enabled
INFO - 2024-10-28 11:48:47 --> Utf8 Class Initialized
INFO - 2024-10-28 11:48:47 --> URI Class Initialized
INFO - 2024-10-28 11:48:47 --> Router Class Initialized
INFO - 2024-10-28 11:48:47 --> Output Class Initialized
INFO - 2024-10-28 11:48:47 --> Security Class Initialized
DEBUG - 2024-10-28 11:48:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-28 11:48:47 --> Input Class Initialized
INFO - 2024-10-28 11:48:47 --> Language Class Initialized
ERROR - 2024-10-28 11:48:47 --> 404 Page Not Found: /index
INFO - 2024-10-28 11:48:47 --> Config Class Initialized
INFO - 2024-10-28 11:48:47 --> Hooks Class Initialized
DEBUG - 2024-10-28 11:48:47 --> UTF-8 Support Enabled
INFO - 2024-10-28 11:48:47 --> Utf8 Class Initialized
INFO - 2024-10-28 11:48:47 --> URI Class Initialized
INFO - 2024-10-28 11:48:47 --> Router Class Initialized
INFO - 2024-10-28 11:48:47 --> Output Class Initialized
INFO - 2024-10-28 11:48:47 --> Security Class Initialized
DEBUG - 2024-10-28 11:48:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-28 11:48:47 --> Input Class Initialized
INFO - 2024-10-28 11:48:47 --> Language Class Initialized
INFO - 2024-10-28 11:48:47 --> Language Class Initialized
INFO - 2024-10-28 11:48:47 --> Config Class Initialized
INFO - 2024-10-28 11:48:47 --> Loader Class Initialized
INFO - 2024-10-28 11:48:47 --> Helper loaded: url_helper
INFO - 2024-10-28 11:48:47 --> Helper loaded: file_helper
INFO - 2024-10-28 11:48:47 --> Helper loaded: form_helper
INFO - 2024-10-28 11:48:47 --> Helper loaded: my_helper
INFO - 2024-10-28 11:48:47 --> Database Driver Class Initialized
INFO - 2024-10-28 11:48:47 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-28 11:48:47 --> Controller Class Initialized
INFO - 2024-10-28 14:00:44 --> Config Class Initialized
INFO - 2024-10-28 14:00:44 --> Hooks Class Initialized
DEBUG - 2024-10-28 14:00:44 --> UTF-8 Support Enabled
INFO - 2024-10-28 14:00:44 --> Utf8 Class Initialized
INFO - 2024-10-28 14:00:44 --> URI Class Initialized
INFO - 2024-10-28 14:00:44 --> Router Class Initialized
INFO - 2024-10-28 14:00:44 --> Output Class Initialized
INFO - 2024-10-28 14:00:44 --> Security Class Initialized
DEBUG - 2024-10-28 14:00:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-28 14:00:44 --> Input Class Initialized
INFO - 2024-10-28 14:00:44 --> Language Class Initialized
INFO - 2024-10-28 14:00:44 --> Language Class Initialized
INFO - 2024-10-28 14:00:44 --> Config Class Initialized
INFO - 2024-10-28 14:00:44 --> Loader Class Initialized
INFO - 2024-10-28 14:00:44 --> Helper loaded: url_helper
INFO - 2024-10-28 14:00:44 --> Helper loaded: file_helper
INFO - 2024-10-28 14:00:44 --> Helper loaded: form_helper
INFO - 2024-10-28 14:00:44 --> Helper loaded: my_helper
INFO - 2024-10-28 14:00:44 --> Database Driver Class Initialized
INFO - 2024-10-28 14:00:44 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-28 14:00:44 --> Controller Class Initialized
INFO - 2024-10-28 14:00:44 --> Final output sent to browser
DEBUG - 2024-10-28 14:00:44 --> Total execution time: 0.0494
INFO - 2024-10-28 21:25:25 --> Config Class Initialized
INFO - 2024-10-28 21:25:25 --> Hooks Class Initialized
DEBUG - 2024-10-28 21:25:25 --> UTF-8 Support Enabled
INFO - 2024-10-28 21:25:25 --> Utf8 Class Initialized
INFO - 2024-10-28 21:25:25 --> URI Class Initialized
INFO - 2024-10-28 21:25:25 --> Router Class Initialized
INFO - 2024-10-28 21:25:25 --> Output Class Initialized
INFO - 2024-10-28 21:25:25 --> Security Class Initialized
DEBUG - 2024-10-28 21:25:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-28 21:25:25 --> Input Class Initialized
INFO - 2024-10-28 21:25:25 --> Language Class Initialized
INFO - 2024-10-28 21:25:25 --> Language Class Initialized
INFO - 2024-10-28 21:25:25 --> Config Class Initialized
INFO - 2024-10-28 21:25:25 --> Loader Class Initialized
INFO - 2024-10-28 21:25:25 --> Helper loaded: url_helper
INFO - 2024-10-28 21:25:25 --> Helper loaded: file_helper
INFO - 2024-10-28 21:25:25 --> Helper loaded: form_helper
INFO - 2024-10-28 21:25:25 --> Helper loaded: my_helper
INFO - 2024-10-28 21:25:25 --> Database Driver Class Initialized
INFO - 2024-10-28 21:25:25 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-28 21:25:25 --> Controller Class Initialized
DEBUG - 2024-10-28 21:25:25 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/login/views/login.php
DEBUG - 2024-10-28 21:25:25 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-10-28 21:25:25 --> Final output sent to browser
DEBUG - 2024-10-28 21:25:25 --> Total execution time: 0.0570
INFO - 2024-10-28 21:25:36 --> Config Class Initialized
INFO - 2024-10-28 21:25:36 --> Hooks Class Initialized
DEBUG - 2024-10-28 21:25:36 --> UTF-8 Support Enabled
INFO - 2024-10-28 21:25:36 --> Utf8 Class Initialized
INFO - 2024-10-28 21:25:36 --> URI Class Initialized
INFO - 2024-10-28 21:25:36 --> Router Class Initialized
INFO - 2024-10-28 21:25:36 --> Output Class Initialized
INFO - 2024-10-28 21:25:36 --> Security Class Initialized
DEBUG - 2024-10-28 21:25:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-28 21:25:36 --> Input Class Initialized
INFO - 2024-10-28 21:25:36 --> Language Class Initialized
INFO - 2024-10-28 21:25:36 --> Language Class Initialized
INFO - 2024-10-28 21:25:36 --> Config Class Initialized
INFO - 2024-10-28 21:25:36 --> Loader Class Initialized
INFO - 2024-10-28 21:25:36 --> Helper loaded: url_helper
INFO - 2024-10-28 21:25:36 --> Helper loaded: file_helper
INFO - 2024-10-28 21:25:36 --> Helper loaded: form_helper
INFO - 2024-10-28 21:25:36 --> Helper loaded: my_helper
INFO - 2024-10-28 21:25:36 --> Database Driver Class Initialized
INFO - 2024-10-28 21:25:36 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-28 21:25:36 --> Controller Class Initialized
INFO - 2024-10-28 21:25:36 --> Helper loaded: cookie_helper
INFO - 2024-10-28 21:25:36 --> Final output sent to browser
DEBUG - 2024-10-28 21:25:36 --> Total execution time: 0.0394
INFO - 2024-10-28 21:25:36 --> Config Class Initialized
INFO - 2024-10-28 21:25:36 --> Hooks Class Initialized
DEBUG - 2024-10-28 21:25:36 --> UTF-8 Support Enabled
INFO - 2024-10-28 21:25:36 --> Utf8 Class Initialized
INFO - 2024-10-28 21:25:36 --> URI Class Initialized
INFO - 2024-10-28 21:25:36 --> Router Class Initialized
INFO - 2024-10-28 21:25:36 --> Output Class Initialized
INFO - 2024-10-28 21:25:36 --> Security Class Initialized
DEBUG - 2024-10-28 21:25:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-28 21:25:36 --> Input Class Initialized
INFO - 2024-10-28 21:25:36 --> Language Class Initialized
INFO - 2024-10-28 21:25:36 --> Language Class Initialized
INFO - 2024-10-28 21:25:36 --> Config Class Initialized
INFO - 2024-10-28 21:25:36 --> Loader Class Initialized
INFO - 2024-10-28 21:25:36 --> Helper loaded: url_helper
INFO - 2024-10-28 21:25:36 --> Helper loaded: file_helper
INFO - 2024-10-28 21:25:36 --> Helper loaded: form_helper
INFO - 2024-10-28 21:25:36 --> Helper loaded: my_helper
INFO - 2024-10-28 21:25:36 --> Database Driver Class Initialized
INFO - 2024-10-28 21:25:36 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-28 21:25:36 --> Controller Class Initialized
DEBUG - 2024-10-28 21:25:36 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/home/views/v_home_guru.php
DEBUG - 2024-10-28 21:25:36 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-10-28 21:25:36 --> Final output sent to browser
DEBUG - 2024-10-28 21:25:36 --> Total execution time: 0.0395
INFO - 2024-10-28 21:25:50 --> Config Class Initialized
INFO - 2024-10-28 21:25:50 --> Hooks Class Initialized
DEBUG - 2024-10-28 21:25:50 --> UTF-8 Support Enabled
INFO - 2024-10-28 21:25:50 --> Utf8 Class Initialized
INFO - 2024-10-28 21:25:50 --> URI Class Initialized
INFO - 2024-10-28 21:25:50 --> Router Class Initialized
INFO - 2024-10-28 21:25:50 --> Output Class Initialized
INFO - 2024-10-28 21:25:50 --> Security Class Initialized
DEBUG - 2024-10-28 21:25:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-28 21:25:50 --> Input Class Initialized
INFO - 2024-10-28 21:25:50 --> Language Class Initialized
INFO - 2024-10-28 21:25:51 --> Language Class Initialized
INFO - 2024-10-28 21:25:51 --> Config Class Initialized
INFO - 2024-10-28 21:25:51 --> Loader Class Initialized
INFO - 2024-10-28 21:25:51 --> Helper loaded: url_helper
INFO - 2024-10-28 21:25:51 --> Helper loaded: file_helper
INFO - 2024-10-28 21:25:51 --> Helper loaded: form_helper
INFO - 2024-10-28 21:25:51 --> Helper loaded: my_helper
INFO - 2024-10-28 21:25:51 --> Database Driver Class Initialized
INFO - 2024-10-28 21:25:51 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-28 21:25:51 --> Controller Class Initialized
DEBUG - 2024-10-28 21:25:51 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/view_mapel/views/v_view_mapel.php
DEBUG - 2024-10-28 21:25:51 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-10-28 21:25:51 --> Final output sent to browser
DEBUG - 2024-10-28 21:25:51 --> Total execution time: 0.2375
INFO - 2024-10-28 21:25:53 --> Config Class Initialized
INFO - 2024-10-28 21:25:53 --> Hooks Class Initialized
DEBUG - 2024-10-28 21:25:53 --> UTF-8 Support Enabled
INFO - 2024-10-28 21:25:53 --> Utf8 Class Initialized
INFO - 2024-10-28 21:25:53 --> URI Class Initialized
INFO - 2024-10-28 21:25:53 --> Router Class Initialized
INFO - 2024-10-28 21:25:53 --> Output Class Initialized
INFO - 2024-10-28 21:25:53 --> Security Class Initialized
DEBUG - 2024-10-28 21:25:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-28 21:25:53 --> Input Class Initialized
INFO - 2024-10-28 21:25:53 --> Language Class Initialized
INFO - 2024-10-28 21:25:53 --> Language Class Initialized
INFO - 2024-10-28 21:25:53 --> Config Class Initialized
INFO - 2024-10-28 21:25:53 --> Loader Class Initialized
INFO - 2024-10-28 21:25:53 --> Helper loaded: url_helper
INFO - 2024-10-28 21:25:53 --> Helper loaded: file_helper
INFO - 2024-10-28 21:25:53 --> Helper loaded: form_helper
INFO - 2024-10-28 21:25:53 --> Helper loaded: my_helper
INFO - 2024-10-28 21:25:53 --> Database Driver Class Initialized
INFO - 2024-10-28 21:25:53 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-28 21:25:53 --> Controller Class Initialized
DEBUG - 2024-10-28 21:25:53 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/views/list.php
DEBUG - 2024-10-28 21:25:53 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-10-28 21:25:53 --> Final output sent to browser
DEBUG - 2024-10-28 21:25:53 --> Total execution time: 0.0404
INFO - 2024-10-28 21:25:54 --> Config Class Initialized
INFO - 2024-10-28 21:25:54 --> Hooks Class Initialized
DEBUG - 2024-10-28 21:25:54 --> UTF-8 Support Enabled
INFO - 2024-10-28 21:25:54 --> Utf8 Class Initialized
INFO - 2024-10-28 21:25:54 --> URI Class Initialized
INFO - 2024-10-28 21:25:54 --> Router Class Initialized
INFO - 2024-10-28 21:25:54 --> Output Class Initialized
INFO - 2024-10-28 21:25:54 --> Security Class Initialized
DEBUG - 2024-10-28 21:25:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-28 21:25:54 --> Input Class Initialized
INFO - 2024-10-28 21:25:54 --> Language Class Initialized
INFO - 2024-10-28 21:25:54 --> Language Class Initialized
INFO - 2024-10-28 21:25:54 --> Config Class Initialized
INFO - 2024-10-28 21:25:54 --> Loader Class Initialized
INFO - 2024-10-28 21:25:54 --> Helper loaded: url_helper
INFO - 2024-10-28 21:25:54 --> Helper loaded: file_helper
INFO - 2024-10-28 21:25:54 --> Helper loaded: form_helper
INFO - 2024-10-28 21:25:54 --> Helper loaded: my_helper
INFO - 2024-10-28 21:25:54 --> Database Driver Class Initialized
INFO - 2024-10-28 21:25:54 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-28 21:25:54 --> Controller Class Initialized
INFO - 2024-10-28 21:25:58 --> Config Class Initialized
INFO - 2024-10-28 21:25:58 --> Hooks Class Initialized
DEBUG - 2024-10-28 21:25:58 --> UTF-8 Support Enabled
INFO - 2024-10-28 21:25:58 --> Utf8 Class Initialized
INFO - 2024-10-28 21:25:58 --> URI Class Initialized
INFO - 2024-10-28 21:25:58 --> Router Class Initialized
INFO - 2024-10-28 21:25:58 --> Output Class Initialized
INFO - 2024-10-28 21:25:58 --> Security Class Initialized
DEBUG - 2024-10-28 21:25:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-28 21:25:58 --> Input Class Initialized
INFO - 2024-10-28 21:25:58 --> Language Class Initialized
INFO - 2024-10-28 21:25:58 --> Language Class Initialized
INFO - 2024-10-28 21:25:58 --> Config Class Initialized
INFO - 2024-10-28 21:25:58 --> Loader Class Initialized
INFO - 2024-10-28 21:25:58 --> Helper loaded: url_helper
INFO - 2024-10-28 21:25:58 --> Helper loaded: file_helper
INFO - 2024-10-28 21:25:58 --> Helper loaded: form_helper
INFO - 2024-10-28 21:25:58 --> Helper loaded: my_helper
INFO - 2024-10-28 21:25:58 --> Database Driver Class Initialized
INFO - 2024-10-28 21:25:58 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-28 21:25:58 --> Controller Class Initialized
INFO - 2024-10-28 21:25:58 --> Final output sent to browser
DEBUG - 2024-10-28 21:25:58 --> Total execution time: 0.0412
INFO - 2024-10-28 21:26:00 --> Config Class Initialized
INFO - 2024-10-28 21:26:00 --> Hooks Class Initialized
DEBUG - 2024-10-28 21:26:00 --> UTF-8 Support Enabled
INFO - 2024-10-28 21:26:00 --> Utf8 Class Initialized
INFO - 2024-10-28 21:26:00 --> URI Class Initialized
INFO - 2024-10-28 21:26:00 --> Router Class Initialized
INFO - 2024-10-28 21:26:00 --> Output Class Initialized
INFO - 2024-10-28 21:26:00 --> Security Class Initialized
DEBUG - 2024-10-28 21:26:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-28 21:26:00 --> Input Class Initialized
INFO - 2024-10-28 21:26:00 --> Language Class Initialized
INFO - 2024-10-28 21:26:00 --> Language Class Initialized
INFO - 2024-10-28 21:26:00 --> Config Class Initialized
INFO - 2024-10-28 21:26:00 --> Loader Class Initialized
INFO - 2024-10-28 21:26:00 --> Helper loaded: url_helper
INFO - 2024-10-28 21:26:00 --> Helper loaded: file_helper
INFO - 2024-10-28 21:26:00 --> Helper loaded: form_helper
INFO - 2024-10-28 21:26:00 --> Helper loaded: my_helper
INFO - 2024-10-28 21:26:00 --> Database Driver Class Initialized
INFO - 2024-10-28 21:26:00 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-28 21:26:00 --> Controller Class Initialized
INFO - 2024-10-28 21:26:00 --> Final output sent to browser
DEBUG - 2024-10-28 21:26:00 --> Total execution time: 0.0323
INFO - 2024-10-28 21:26:05 --> Config Class Initialized
INFO - 2024-10-28 21:26:05 --> Hooks Class Initialized
DEBUG - 2024-10-28 21:26:05 --> UTF-8 Support Enabled
INFO - 2024-10-28 21:26:05 --> Utf8 Class Initialized
INFO - 2024-10-28 21:26:05 --> URI Class Initialized
INFO - 2024-10-28 21:26:05 --> Router Class Initialized
INFO - 2024-10-28 21:26:05 --> Output Class Initialized
INFO - 2024-10-28 21:26:05 --> Security Class Initialized
DEBUG - 2024-10-28 21:26:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-28 21:26:05 --> Input Class Initialized
INFO - 2024-10-28 21:26:05 --> Language Class Initialized
INFO - 2024-10-28 21:26:05 --> Language Class Initialized
INFO - 2024-10-28 21:26:05 --> Config Class Initialized
INFO - 2024-10-28 21:26:05 --> Loader Class Initialized
INFO - 2024-10-28 21:26:05 --> Helper loaded: url_helper
INFO - 2024-10-28 21:26:05 --> Helper loaded: file_helper
INFO - 2024-10-28 21:26:05 --> Helper loaded: form_helper
INFO - 2024-10-28 21:26:05 --> Helper loaded: my_helper
INFO - 2024-10-28 21:26:05 --> Database Driver Class Initialized
INFO - 2024-10-28 21:26:05 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-28 21:26:05 --> Controller Class Initialized
INFO - 2024-10-28 21:26:05 --> Final output sent to browser
DEBUG - 2024-10-28 21:26:05 --> Total execution time: 0.0400
INFO - 2024-10-28 21:26:08 --> Config Class Initialized
INFO - 2024-10-28 21:26:08 --> Hooks Class Initialized
DEBUG - 2024-10-28 21:26:08 --> UTF-8 Support Enabled
INFO - 2024-10-28 21:26:08 --> Utf8 Class Initialized
INFO - 2024-10-28 21:26:08 --> URI Class Initialized
INFO - 2024-10-28 21:26:08 --> Router Class Initialized
INFO - 2024-10-28 21:26:08 --> Output Class Initialized
INFO - 2024-10-28 21:26:08 --> Security Class Initialized
DEBUG - 2024-10-28 21:26:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-28 21:26:08 --> Input Class Initialized
INFO - 2024-10-28 21:26:08 --> Language Class Initialized
INFO - 2024-10-28 21:26:08 --> Language Class Initialized
INFO - 2024-10-28 21:26:08 --> Config Class Initialized
INFO - 2024-10-28 21:26:08 --> Loader Class Initialized
INFO - 2024-10-28 21:26:08 --> Helper loaded: url_helper
INFO - 2024-10-28 21:26:08 --> Helper loaded: file_helper
INFO - 2024-10-28 21:26:08 --> Helper loaded: form_helper
INFO - 2024-10-28 21:26:08 --> Helper loaded: my_helper
INFO - 2024-10-28 21:26:08 --> Database Driver Class Initialized
INFO - 2024-10-28 21:26:08 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-28 21:26:08 --> Controller Class Initialized
INFO - 2024-10-28 21:26:08 --> Final output sent to browser
DEBUG - 2024-10-28 21:26:08 --> Total execution time: 0.0352
INFO - 2024-10-28 21:26:10 --> Config Class Initialized
INFO - 2024-10-28 21:26:10 --> Hooks Class Initialized
DEBUG - 2024-10-28 21:26:10 --> UTF-8 Support Enabled
INFO - 2024-10-28 21:26:10 --> Utf8 Class Initialized
INFO - 2024-10-28 21:26:10 --> URI Class Initialized
INFO - 2024-10-28 21:26:10 --> Router Class Initialized
INFO - 2024-10-28 21:26:10 --> Output Class Initialized
INFO - 2024-10-28 21:26:10 --> Security Class Initialized
DEBUG - 2024-10-28 21:26:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-28 21:26:10 --> Input Class Initialized
INFO - 2024-10-28 21:26:10 --> Language Class Initialized
INFO - 2024-10-28 21:26:10 --> Language Class Initialized
INFO - 2024-10-28 21:26:10 --> Config Class Initialized
INFO - 2024-10-28 21:26:10 --> Loader Class Initialized
INFO - 2024-10-28 21:26:10 --> Helper loaded: url_helper
INFO - 2024-10-28 21:26:10 --> Helper loaded: file_helper
INFO - 2024-10-28 21:26:10 --> Helper loaded: form_helper
INFO - 2024-10-28 21:26:10 --> Helper loaded: my_helper
INFO - 2024-10-28 21:26:10 --> Database Driver Class Initialized
INFO - 2024-10-28 21:26:10 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-28 21:26:10 --> Controller Class Initialized
INFO - 2024-10-28 21:26:10 --> Final output sent to browser
DEBUG - 2024-10-28 21:26:10 --> Total execution time: 0.0296
INFO - 2024-10-28 21:26:17 --> Config Class Initialized
INFO - 2024-10-28 21:26:17 --> Hooks Class Initialized
DEBUG - 2024-10-28 21:26:17 --> UTF-8 Support Enabled
INFO - 2024-10-28 21:26:17 --> Utf8 Class Initialized
INFO - 2024-10-28 21:26:17 --> URI Class Initialized
INFO - 2024-10-28 21:26:17 --> Router Class Initialized
INFO - 2024-10-28 21:26:17 --> Output Class Initialized
INFO - 2024-10-28 21:26:17 --> Security Class Initialized
DEBUG - 2024-10-28 21:26:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-28 21:26:17 --> Input Class Initialized
INFO - 2024-10-28 21:26:17 --> Language Class Initialized
INFO - 2024-10-28 21:26:17 --> Language Class Initialized
INFO - 2024-10-28 21:26:17 --> Config Class Initialized
INFO - 2024-10-28 21:26:17 --> Loader Class Initialized
INFO - 2024-10-28 21:26:17 --> Helper loaded: url_helper
INFO - 2024-10-28 21:26:17 --> Helper loaded: file_helper
INFO - 2024-10-28 21:26:17 --> Helper loaded: form_helper
INFO - 2024-10-28 21:26:17 --> Helper loaded: my_helper
INFO - 2024-10-28 21:26:17 --> Database Driver Class Initialized
INFO - 2024-10-28 21:26:17 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-28 21:26:17 --> Controller Class Initialized
INFO - 2024-10-28 21:26:17 --> Final output sent to browser
DEBUG - 2024-10-28 21:26:17 --> Total execution time: 0.0482
INFO - 2024-10-28 21:26:20 --> Config Class Initialized
INFO - 2024-10-28 21:26:20 --> Hooks Class Initialized
DEBUG - 2024-10-28 21:26:20 --> UTF-8 Support Enabled
INFO - 2024-10-28 21:26:20 --> Utf8 Class Initialized
INFO - 2024-10-28 21:26:20 --> URI Class Initialized
INFO - 2024-10-28 21:26:20 --> Router Class Initialized
INFO - 2024-10-28 21:26:20 --> Output Class Initialized
INFO - 2024-10-28 21:26:20 --> Security Class Initialized
DEBUG - 2024-10-28 21:26:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-28 21:26:20 --> Input Class Initialized
INFO - 2024-10-28 21:26:20 --> Language Class Initialized
INFO - 2024-10-28 21:26:20 --> Language Class Initialized
INFO - 2024-10-28 21:26:20 --> Config Class Initialized
INFO - 2024-10-28 21:26:20 --> Loader Class Initialized
INFO - 2024-10-28 21:26:20 --> Helper loaded: url_helper
INFO - 2024-10-28 21:26:20 --> Helper loaded: file_helper
INFO - 2024-10-28 21:26:20 --> Helper loaded: form_helper
INFO - 2024-10-28 21:26:20 --> Helper loaded: my_helper
INFO - 2024-10-28 21:26:20 --> Database Driver Class Initialized
INFO - 2024-10-28 21:26:20 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-28 21:26:20 --> Controller Class Initialized
INFO - 2024-10-28 21:26:20 --> Final output sent to browser
DEBUG - 2024-10-28 21:26:20 --> Total execution time: 0.0534
INFO - 2024-10-28 21:26:21 --> Config Class Initialized
INFO - 2024-10-28 21:26:21 --> Hooks Class Initialized
DEBUG - 2024-10-28 21:26:21 --> UTF-8 Support Enabled
INFO - 2024-10-28 21:26:21 --> Utf8 Class Initialized
INFO - 2024-10-28 21:26:21 --> URI Class Initialized
INFO - 2024-10-28 21:26:21 --> Router Class Initialized
INFO - 2024-10-28 21:26:21 --> Output Class Initialized
INFO - 2024-10-28 21:26:21 --> Security Class Initialized
DEBUG - 2024-10-28 21:26:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-28 21:26:21 --> Input Class Initialized
INFO - 2024-10-28 21:26:21 --> Language Class Initialized
INFO - 2024-10-28 21:26:21 --> Language Class Initialized
INFO - 2024-10-28 21:26:21 --> Config Class Initialized
INFO - 2024-10-28 21:26:21 --> Loader Class Initialized
INFO - 2024-10-28 21:26:21 --> Helper loaded: url_helper
INFO - 2024-10-28 21:26:21 --> Helper loaded: file_helper
INFO - 2024-10-28 21:26:21 --> Helper loaded: form_helper
INFO - 2024-10-28 21:26:21 --> Helper loaded: my_helper
INFO - 2024-10-28 21:26:21 --> Database Driver Class Initialized
INFO - 2024-10-28 21:26:21 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-28 21:26:21 --> Controller Class Initialized
INFO - 2024-10-28 21:26:21 --> Final output sent to browser
DEBUG - 2024-10-28 21:26:21 --> Total execution time: 0.0402
INFO - 2024-10-28 21:26:29 --> Config Class Initialized
INFO - 2024-10-28 21:26:29 --> Hooks Class Initialized
DEBUG - 2024-10-28 21:26:29 --> UTF-8 Support Enabled
INFO - 2024-10-28 21:26:29 --> Utf8 Class Initialized
INFO - 2024-10-28 21:26:29 --> URI Class Initialized
INFO - 2024-10-28 21:26:29 --> Router Class Initialized
INFO - 2024-10-28 21:26:29 --> Output Class Initialized
INFO - 2024-10-28 21:26:29 --> Security Class Initialized
DEBUG - 2024-10-28 21:26:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-28 21:26:29 --> Input Class Initialized
INFO - 2024-10-28 21:26:29 --> Language Class Initialized
INFO - 2024-10-28 21:26:29 --> Language Class Initialized
INFO - 2024-10-28 21:26:29 --> Config Class Initialized
INFO - 2024-10-28 21:26:29 --> Loader Class Initialized
INFO - 2024-10-28 21:26:29 --> Helper loaded: url_helper
INFO - 2024-10-28 21:26:29 --> Helper loaded: file_helper
INFO - 2024-10-28 21:26:29 --> Helper loaded: form_helper
INFO - 2024-10-28 21:26:29 --> Helper loaded: my_helper
INFO - 2024-10-28 21:26:29 --> Database Driver Class Initialized
INFO - 2024-10-28 21:26:29 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-28 21:26:29 --> Controller Class Initialized
INFO - 2024-10-28 21:26:29 --> Final output sent to browser
DEBUG - 2024-10-28 21:26:29 --> Total execution time: 0.0380
INFO - 2024-10-28 21:28:06 --> Config Class Initialized
INFO - 2024-10-28 21:28:06 --> Hooks Class Initialized
DEBUG - 2024-10-28 21:28:06 --> UTF-8 Support Enabled
INFO - 2024-10-28 21:28:06 --> Utf8 Class Initialized
INFO - 2024-10-28 21:28:06 --> URI Class Initialized
INFO - 2024-10-28 21:28:06 --> Router Class Initialized
INFO - 2024-10-28 21:28:06 --> Output Class Initialized
INFO - 2024-10-28 21:28:06 --> Security Class Initialized
DEBUG - 2024-10-28 21:28:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-28 21:28:06 --> Input Class Initialized
INFO - 2024-10-28 21:28:06 --> Language Class Initialized
INFO - 2024-10-28 21:28:06 --> Language Class Initialized
INFO - 2024-10-28 21:28:06 --> Config Class Initialized
INFO - 2024-10-28 21:28:06 --> Loader Class Initialized
INFO - 2024-10-28 21:28:06 --> Helper loaded: url_helper
INFO - 2024-10-28 21:28:06 --> Helper loaded: file_helper
INFO - 2024-10-28 21:28:06 --> Helper loaded: form_helper
INFO - 2024-10-28 21:28:06 --> Helper loaded: my_helper
INFO - 2024-10-28 21:28:06 --> Database Driver Class Initialized
INFO - 2024-10-28 21:28:06 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-28 21:28:06 --> Controller Class Initialized
INFO - 2024-10-28 21:28:06 --> Final output sent to browser
DEBUG - 2024-10-28 21:28:06 --> Total execution time: 0.0515
INFO - 2024-10-28 21:46:06 --> Config Class Initialized
INFO - 2024-10-28 21:46:06 --> Hooks Class Initialized
DEBUG - 2024-10-28 21:46:06 --> UTF-8 Support Enabled
INFO - 2024-10-28 21:46:06 --> Utf8 Class Initialized
INFO - 2024-10-28 21:46:06 --> URI Class Initialized
INFO - 2024-10-28 21:46:06 --> Router Class Initialized
INFO - 2024-10-28 21:46:06 --> Output Class Initialized
INFO - 2024-10-28 21:46:06 --> Security Class Initialized
DEBUG - 2024-10-28 21:46:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-28 21:46:06 --> Input Class Initialized
INFO - 2024-10-28 21:46:06 --> Language Class Initialized
INFO - 2024-10-28 21:46:06 --> Language Class Initialized
INFO - 2024-10-28 21:46:06 --> Config Class Initialized
INFO - 2024-10-28 21:46:06 --> Loader Class Initialized
INFO - 2024-10-28 21:46:06 --> Helper loaded: url_helper
INFO - 2024-10-28 21:46:06 --> Helper loaded: file_helper
INFO - 2024-10-28 21:46:06 --> Helper loaded: form_helper
INFO - 2024-10-28 21:46:06 --> Helper loaded: my_helper
INFO - 2024-10-28 21:46:06 --> Database Driver Class Initialized
INFO - 2024-10-28 21:46:06 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-28 21:46:06 --> Controller Class Initialized
INFO - 2024-10-28 21:46:06 --> Final output sent to browser
DEBUG - 2024-10-28 21:46:06 --> Total execution time: 0.2738
