<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2024-06-05 08:20:59 --> Config Class Initialized
INFO - 2024-06-05 08:20:59 --> Hooks Class Initialized
DEBUG - 2024-06-05 08:20:59 --> UTF-8 Support Enabled
INFO - 2024-06-05 08:20:59 --> Utf8 Class Initialized
INFO - 2024-06-05 08:20:59 --> URI Class Initialized
INFO - 2024-06-05 08:20:59 --> Router Class Initialized
INFO - 2024-06-05 08:20:59 --> Output Class Initialized
INFO - 2024-06-05 08:20:59 --> Security Class Initialized
DEBUG - 2024-06-05 08:20:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-05 08:20:59 --> Input Class Initialized
INFO - 2024-06-05 08:20:59 --> Language Class Initialized
INFO - 2024-06-05 08:20:59 --> Language Class Initialized
INFO - 2024-06-05 08:20:59 --> Config Class Initialized
INFO - 2024-06-05 08:20:59 --> Loader Class Initialized
INFO - 2024-06-05 08:20:59 --> Helper loaded: url_helper
INFO - 2024-06-05 08:20:59 --> Helper loaded: file_helper
INFO - 2024-06-05 08:20:59 --> Helper loaded: form_helper
INFO - 2024-06-05 08:20:59 --> Helper loaded: my_helper
INFO - 2024-06-05 08:20:59 --> Database Driver Class Initialized
INFO - 2024-06-05 08:20:59 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-05 08:20:59 --> Controller Class Initialized
DEBUG - 2024-06-05 08:20:59 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/views/list.php
DEBUG - 2024-06-05 08:20:59 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-06-05 08:20:59 --> Final output sent to browser
DEBUG - 2024-06-05 08:20:59 --> Total execution time: 0.0555
INFO - 2024-06-05 08:21:26 --> Config Class Initialized
INFO - 2024-06-05 08:21:26 --> Hooks Class Initialized
DEBUG - 2024-06-05 08:21:26 --> UTF-8 Support Enabled
INFO - 2024-06-05 08:21:26 --> Utf8 Class Initialized
INFO - 2024-06-05 08:21:26 --> URI Class Initialized
INFO - 2024-06-05 08:21:26 --> Router Class Initialized
INFO - 2024-06-05 08:21:26 --> Output Class Initialized
INFO - 2024-06-05 08:21:26 --> Security Class Initialized
DEBUG - 2024-06-05 08:21:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-05 08:21:26 --> Input Class Initialized
INFO - 2024-06-05 08:21:26 --> Language Class Initialized
INFO - 2024-06-05 08:21:26 --> Language Class Initialized
INFO - 2024-06-05 08:21:26 --> Config Class Initialized
INFO - 2024-06-05 08:21:26 --> Loader Class Initialized
INFO - 2024-06-05 08:21:26 --> Helper loaded: url_helper
INFO - 2024-06-05 08:21:26 --> Helper loaded: file_helper
INFO - 2024-06-05 08:21:26 --> Helper loaded: form_helper
INFO - 2024-06-05 08:21:26 --> Helper loaded: my_helper
INFO - 2024-06-05 08:21:26 --> Database Driver Class Initialized
INFO - 2024-06-05 08:21:26 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-05 08:21:26 --> Controller Class Initialized
INFO - 2024-06-05 09:05:38 --> Config Class Initialized
INFO - 2024-06-05 09:05:38 --> Hooks Class Initialized
DEBUG - 2024-06-05 09:05:38 --> UTF-8 Support Enabled
INFO - 2024-06-05 09:05:38 --> Utf8 Class Initialized
INFO - 2024-06-05 09:05:38 --> URI Class Initialized
INFO - 2024-06-05 09:05:38 --> Router Class Initialized
INFO - 2024-06-05 09:05:38 --> Output Class Initialized
INFO - 2024-06-05 09:05:38 --> Security Class Initialized
DEBUG - 2024-06-05 09:05:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-05 09:05:38 --> Input Class Initialized
INFO - 2024-06-05 09:05:38 --> Language Class Initialized
INFO - 2024-06-05 09:05:38 --> Language Class Initialized
INFO - 2024-06-05 09:05:38 --> Config Class Initialized
INFO - 2024-06-05 09:05:38 --> Loader Class Initialized
INFO - 2024-06-05 09:05:38 --> Helper loaded: url_helper
INFO - 2024-06-05 09:05:38 --> Helper loaded: file_helper
INFO - 2024-06-05 09:05:38 --> Helper loaded: form_helper
INFO - 2024-06-05 09:05:38 --> Helper loaded: my_helper
INFO - 2024-06-05 09:05:38 --> Database Driver Class Initialized
INFO - 2024-06-05 09:05:38 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-05 09:05:38 --> Controller Class Initialized
DEBUG - 2024-06-05 09:05:38 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/views/list.php
DEBUG - 2024-06-05 09:05:38 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-06-05 09:05:38 --> Final output sent to browser
DEBUG - 2024-06-05 09:05:38 --> Total execution time: 0.0462
INFO - 2024-06-05 09:05:39 --> Config Class Initialized
INFO - 2024-06-05 09:05:39 --> Hooks Class Initialized
DEBUG - 2024-06-05 09:05:39 --> UTF-8 Support Enabled
INFO - 2024-06-05 09:05:39 --> Utf8 Class Initialized
INFO - 2024-06-05 09:05:39 --> URI Class Initialized
INFO - 2024-06-05 09:05:39 --> Router Class Initialized
INFO - 2024-06-05 09:05:39 --> Output Class Initialized
INFO - 2024-06-05 09:05:39 --> Security Class Initialized
DEBUG - 2024-06-05 09:05:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-05 09:05:39 --> Input Class Initialized
INFO - 2024-06-05 09:05:39 --> Language Class Initialized
INFO - 2024-06-05 09:05:39 --> Language Class Initialized
INFO - 2024-06-05 09:05:39 --> Config Class Initialized
INFO - 2024-06-05 09:05:39 --> Loader Class Initialized
INFO - 2024-06-05 09:05:39 --> Helper loaded: url_helper
INFO - 2024-06-05 09:05:39 --> Helper loaded: file_helper
INFO - 2024-06-05 09:05:39 --> Helper loaded: form_helper
INFO - 2024-06-05 09:05:39 --> Helper loaded: my_helper
INFO - 2024-06-05 09:05:39 --> Database Driver Class Initialized
INFO - 2024-06-05 09:05:39 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-05 09:05:39 --> Controller Class Initialized
INFO - 2024-06-05 11:06:41 --> Config Class Initialized
INFO - 2024-06-05 11:06:41 --> Hooks Class Initialized
DEBUG - 2024-06-05 11:06:41 --> UTF-8 Support Enabled
INFO - 2024-06-05 11:06:41 --> Utf8 Class Initialized
INFO - 2024-06-05 11:06:41 --> URI Class Initialized
INFO - 2024-06-05 11:06:41 --> Router Class Initialized
INFO - 2024-06-05 11:06:41 --> Output Class Initialized
INFO - 2024-06-05 11:06:41 --> Security Class Initialized
DEBUG - 2024-06-05 11:06:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-05 11:06:41 --> Input Class Initialized
INFO - 2024-06-05 11:06:41 --> Language Class Initialized
INFO - 2024-06-05 11:06:41 --> Language Class Initialized
INFO - 2024-06-05 11:06:41 --> Config Class Initialized
INFO - 2024-06-05 11:06:41 --> Loader Class Initialized
INFO - 2024-06-05 11:06:41 --> Helper loaded: url_helper
INFO - 2024-06-05 11:06:41 --> Helper loaded: file_helper
INFO - 2024-06-05 11:06:41 --> Helper loaded: form_helper
INFO - 2024-06-05 11:06:41 --> Helper loaded: my_helper
INFO - 2024-06-05 11:06:41 --> Database Driver Class Initialized
INFO - 2024-06-05 11:06:41 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-05 11:06:41 --> Controller Class Initialized
DEBUG - 2024-06-05 11:06:41 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/login/views/login.php
DEBUG - 2024-06-05 11:06:41 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-06-05 11:06:41 --> Final output sent to browser
DEBUG - 2024-06-05 11:06:41 --> Total execution time: 0.0473
INFO - 2024-06-05 14:42:21 --> Config Class Initialized
INFO - 2024-06-05 14:42:21 --> Hooks Class Initialized
DEBUG - 2024-06-05 14:42:21 --> UTF-8 Support Enabled
INFO - 2024-06-05 14:42:21 --> Utf8 Class Initialized
INFO - 2024-06-05 14:42:21 --> URI Class Initialized
INFO - 2024-06-05 14:42:21 --> Router Class Initialized
INFO - 2024-06-05 14:42:21 --> Output Class Initialized
INFO - 2024-06-05 14:42:21 --> Security Class Initialized
DEBUG - 2024-06-05 14:42:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-05 14:42:21 --> Input Class Initialized
INFO - 2024-06-05 14:42:21 --> Language Class Initialized
INFO - 2024-06-05 14:42:21 --> Language Class Initialized
INFO - 2024-06-05 14:42:21 --> Config Class Initialized
INFO - 2024-06-05 14:42:21 --> Loader Class Initialized
INFO - 2024-06-05 14:42:21 --> Helper loaded: url_helper
INFO - 2024-06-05 14:42:21 --> Helper loaded: file_helper
INFO - 2024-06-05 14:42:21 --> Helper loaded: form_helper
INFO - 2024-06-05 14:42:21 --> Helper loaded: my_helper
INFO - 2024-06-05 14:42:21 --> Database Driver Class Initialized
INFO - 2024-06-05 14:42:21 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-05 14:42:21 --> Controller Class Initialized
INFO - 2024-06-05 14:42:21 --> Final output sent to browser
DEBUG - 2024-06-05 14:42:21 --> Total execution time: 0.0859
INFO - 2024-06-05 14:52:47 --> Config Class Initialized
INFO - 2024-06-05 14:52:47 --> Hooks Class Initialized
DEBUG - 2024-06-05 14:52:47 --> UTF-8 Support Enabled
INFO - 2024-06-05 14:52:47 --> Utf8 Class Initialized
INFO - 2024-06-05 14:52:47 --> URI Class Initialized
INFO - 2024-06-05 14:52:47 --> Router Class Initialized
INFO - 2024-06-05 14:52:47 --> Output Class Initialized
INFO - 2024-06-05 14:52:47 --> Security Class Initialized
DEBUG - 2024-06-05 14:52:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-05 14:52:47 --> Input Class Initialized
INFO - 2024-06-05 14:52:47 --> Language Class Initialized
INFO - 2024-06-05 14:52:47 --> Language Class Initialized
INFO - 2024-06-05 14:52:47 --> Config Class Initialized
INFO - 2024-06-05 14:52:47 --> Loader Class Initialized
INFO - 2024-06-05 14:52:47 --> Helper loaded: url_helper
INFO - 2024-06-05 14:52:47 --> Helper loaded: file_helper
INFO - 2024-06-05 14:52:47 --> Helper loaded: form_helper
INFO - 2024-06-05 14:52:47 --> Helper loaded: my_helper
INFO - 2024-06-05 14:52:47 --> Database Driver Class Initialized
INFO - 2024-06-05 14:52:47 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-05 14:52:47 --> Controller Class Initialized
INFO - 2024-06-05 14:52:47 --> Final output sent to browser
DEBUG - 2024-06-05 14:52:47 --> Total execution time: 0.0407
INFO - 2024-06-05 14:55:47 --> Config Class Initialized
INFO - 2024-06-05 14:55:47 --> Hooks Class Initialized
DEBUG - 2024-06-05 14:55:47 --> UTF-8 Support Enabled
INFO - 2024-06-05 14:55:47 --> Utf8 Class Initialized
INFO - 2024-06-05 14:55:47 --> URI Class Initialized
INFO - 2024-06-05 14:55:47 --> Router Class Initialized
INFO - 2024-06-05 14:55:47 --> Output Class Initialized
INFO - 2024-06-05 14:55:47 --> Security Class Initialized
DEBUG - 2024-06-05 14:55:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-05 14:55:47 --> Input Class Initialized
INFO - 2024-06-05 14:55:47 --> Language Class Initialized
INFO - 2024-06-05 14:55:47 --> Language Class Initialized
INFO - 2024-06-05 14:55:47 --> Config Class Initialized
INFO - 2024-06-05 14:55:47 --> Loader Class Initialized
INFO - 2024-06-05 14:55:47 --> Helper loaded: url_helper
INFO - 2024-06-05 14:55:47 --> Helper loaded: file_helper
INFO - 2024-06-05 14:55:47 --> Helper loaded: form_helper
INFO - 2024-06-05 14:55:47 --> Helper loaded: my_helper
INFO - 2024-06-05 14:55:47 --> Database Driver Class Initialized
INFO - 2024-06-05 14:55:47 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-05 14:55:47 --> Controller Class Initialized
INFO - 2024-06-05 14:55:48 --> Final output sent to browser
DEBUG - 2024-06-05 14:55:48 --> Total execution time: 0.1438
INFO - 2024-06-05 14:56:18 --> Config Class Initialized
INFO - 2024-06-05 14:56:18 --> Hooks Class Initialized
DEBUG - 2024-06-05 14:56:18 --> UTF-8 Support Enabled
INFO - 2024-06-05 14:56:18 --> Utf8 Class Initialized
INFO - 2024-06-05 14:56:18 --> URI Class Initialized
INFO - 2024-06-05 14:56:18 --> Router Class Initialized
INFO - 2024-06-05 14:56:18 --> Output Class Initialized
INFO - 2024-06-05 14:56:18 --> Security Class Initialized
DEBUG - 2024-06-05 14:56:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-05 14:56:18 --> Input Class Initialized
INFO - 2024-06-05 14:56:18 --> Language Class Initialized
INFO - 2024-06-05 14:56:18 --> Language Class Initialized
INFO - 2024-06-05 14:56:18 --> Config Class Initialized
INFO - 2024-06-05 14:56:18 --> Loader Class Initialized
INFO - 2024-06-05 14:56:18 --> Helper loaded: url_helper
INFO - 2024-06-05 14:56:18 --> Helper loaded: file_helper
INFO - 2024-06-05 14:56:18 --> Helper loaded: form_helper
INFO - 2024-06-05 14:56:18 --> Helper loaded: my_helper
INFO - 2024-06-05 14:56:18 --> Database Driver Class Initialized
INFO - 2024-06-05 14:56:18 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-05 14:56:18 --> Controller Class Initialized
INFO - 2024-06-05 14:56:19 --> Final output sent to browser
DEBUG - 2024-06-05 14:56:19 --> Total execution time: 0.3195
INFO - 2024-06-05 14:56:22 --> Config Class Initialized
INFO - 2024-06-05 14:56:22 --> Hooks Class Initialized
DEBUG - 2024-06-05 14:56:22 --> UTF-8 Support Enabled
INFO - 2024-06-05 14:56:22 --> Utf8 Class Initialized
INFO - 2024-06-05 14:56:22 --> URI Class Initialized
INFO - 2024-06-05 14:56:22 --> Router Class Initialized
INFO - 2024-06-05 14:56:22 --> Output Class Initialized
INFO - 2024-06-05 14:56:22 --> Security Class Initialized
DEBUG - 2024-06-05 14:56:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-05 14:56:22 --> Input Class Initialized
INFO - 2024-06-05 14:56:22 --> Language Class Initialized
INFO - 2024-06-05 14:56:22 --> Language Class Initialized
INFO - 2024-06-05 14:56:22 --> Config Class Initialized
INFO - 2024-06-05 14:56:22 --> Loader Class Initialized
INFO - 2024-06-05 14:56:22 --> Helper loaded: url_helper
INFO - 2024-06-05 14:56:22 --> Helper loaded: file_helper
INFO - 2024-06-05 14:56:22 --> Helper loaded: form_helper
INFO - 2024-06-05 14:56:22 --> Helper loaded: my_helper
INFO - 2024-06-05 14:56:22 --> Database Driver Class Initialized
INFO - 2024-06-05 14:56:22 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-05 14:56:22 --> Controller Class Initialized
INFO - 2024-06-05 14:56:22 --> Final output sent to browser
DEBUG - 2024-06-05 14:56:22 --> Total execution time: 0.0891
INFO - 2024-06-05 14:57:19 --> Config Class Initialized
INFO - 2024-06-05 14:57:19 --> Hooks Class Initialized
DEBUG - 2024-06-05 14:57:19 --> UTF-8 Support Enabled
INFO - 2024-06-05 14:57:19 --> Utf8 Class Initialized
INFO - 2024-06-05 14:57:19 --> URI Class Initialized
INFO - 2024-06-05 14:57:19 --> Router Class Initialized
INFO - 2024-06-05 14:57:19 --> Output Class Initialized
INFO - 2024-06-05 14:57:19 --> Security Class Initialized
DEBUG - 2024-06-05 14:57:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-05 14:57:19 --> Input Class Initialized
INFO - 2024-06-05 14:57:19 --> Language Class Initialized
INFO - 2024-06-05 14:57:19 --> Language Class Initialized
INFO - 2024-06-05 14:57:19 --> Config Class Initialized
INFO - 2024-06-05 14:57:19 --> Loader Class Initialized
INFO - 2024-06-05 14:57:19 --> Helper loaded: url_helper
INFO - 2024-06-05 14:57:19 --> Helper loaded: file_helper
INFO - 2024-06-05 14:57:19 --> Helper loaded: form_helper
INFO - 2024-06-05 14:57:19 --> Helper loaded: my_helper
INFO - 2024-06-05 14:57:19 --> Database Driver Class Initialized
INFO - 2024-06-05 14:57:19 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-05 14:57:19 --> Controller Class Initialized
INFO - 2024-06-05 14:57:19 --> Final output sent to browser
DEBUG - 2024-06-05 14:57:19 --> Total execution time: 0.0331
INFO - 2024-06-05 14:58:55 --> Config Class Initialized
INFO - 2024-06-05 14:58:55 --> Hooks Class Initialized
DEBUG - 2024-06-05 14:58:55 --> UTF-8 Support Enabled
INFO - 2024-06-05 14:58:55 --> Utf8 Class Initialized
INFO - 2024-06-05 14:58:55 --> URI Class Initialized
INFO - 2024-06-05 14:58:55 --> Router Class Initialized
INFO - 2024-06-05 14:58:55 --> Output Class Initialized
INFO - 2024-06-05 14:58:55 --> Security Class Initialized
DEBUG - 2024-06-05 14:58:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-05 14:58:55 --> Input Class Initialized
INFO - 2024-06-05 14:58:55 --> Language Class Initialized
INFO - 2024-06-05 14:58:55 --> Language Class Initialized
INFO - 2024-06-05 14:58:55 --> Config Class Initialized
INFO - 2024-06-05 14:58:55 --> Loader Class Initialized
INFO - 2024-06-05 14:58:55 --> Helper loaded: url_helper
INFO - 2024-06-05 14:58:55 --> Helper loaded: file_helper
INFO - 2024-06-05 14:58:55 --> Helper loaded: form_helper
INFO - 2024-06-05 14:58:55 --> Helper loaded: my_helper
INFO - 2024-06-05 14:58:55 --> Database Driver Class Initialized
INFO - 2024-06-05 14:58:55 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-05 14:58:55 --> Controller Class Initialized
INFO - 2024-06-05 14:58:55 --> Final output sent to browser
DEBUG - 2024-06-05 14:58:55 --> Total execution time: 0.3923
INFO - 2024-06-05 14:58:58 --> Config Class Initialized
INFO - 2024-06-05 14:58:58 --> Hooks Class Initialized
DEBUG - 2024-06-05 14:58:58 --> UTF-8 Support Enabled
INFO - 2024-06-05 14:58:58 --> Utf8 Class Initialized
INFO - 2024-06-05 14:58:58 --> URI Class Initialized
INFO - 2024-06-05 14:58:58 --> Router Class Initialized
INFO - 2024-06-05 14:58:58 --> Output Class Initialized
INFO - 2024-06-05 14:58:58 --> Security Class Initialized
DEBUG - 2024-06-05 14:58:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-05 14:58:58 --> Input Class Initialized
INFO - 2024-06-05 14:58:58 --> Language Class Initialized
INFO - 2024-06-05 14:58:58 --> Language Class Initialized
INFO - 2024-06-05 14:58:58 --> Config Class Initialized
INFO - 2024-06-05 14:58:58 --> Loader Class Initialized
INFO - 2024-06-05 14:58:58 --> Helper loaded: url_helper
INFO - 2024-06-05 14:58:58 --> Helper loaded: file_helper
INFO - 2024-06-05 14:58:58 --> Helper loaded: form_helper
INFO - 2024-06-05 14:58:58 --> Helper loaded: my_helper
INFO - 2024-06-05 14:58:58 --> Database Driver Class Initialized
INFO - 2024-06-05 14:58:58 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-05 14:58:58 --> Controller Class Initialized
INFO - 2024-06-05 14:58:58 --> Final output sent to browser
DEBUG - 2024-06-05 14:58:58 --> Total execution time: 0.0427
INFO - 2024-06-05 15:00:14 --> Config Class Initialized
INFO - 2024-06-05 15:00:14 --> Hooks Class Initialized
DEBUG - 2024-06-05 15:00:14 --> UTF-8 Support Enabled
INFO - 2024-06-05 15:00:14 --> Utf8 Class Initialized
INFO - 2024-06-05 15:00:14 --> URI Class Initialized
INFO - 2024-06-05 15:00:14 --> Router Class Initialized
INFO - 2024-06-05 15:00:14 --> Output Class Initialized
INFO - 2024-06-05 15:00:14 --> Security Class Initialized
DEBUG - 2024-06-05 15:00:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-05 15:00:14 --> Input Class Initialized
INFO - 2024-06-05 15:00:14 --> Language Class Initialized
INFO - 2024-06-05 15:00:14 --> Language Class Initialized
INFO - 2024-06-05 15:00:14 --> Config Class Initialized
INFO - 2024-06-05 15:00:14 --> Loader Class Initialized
INFO - 2024-06-05 15:00:14 --> Helper loaded: url_helper
INFO - 2024-06-05 15:00:14 --> Helper loaded: file_helper
INFO - 2024-06-05 15:00:14 --> Helper loaded: form_helper
INFO - 2024-06-05 15:00:14 --> Helper loaded: my_helper
INFO - 2024-06-05 15:00:14 --> Database Driver Class Initialized
INFO - 2024-06-05 15:00:14 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-05 15:00:14 --> Controller Class Initialized
INFO - 2024-06-05 15:00:14 --> Final output sent to browser
DEBUG - 2024-06-05 15:00:14 --> Total execution time: 0.1977
INFO - 2024-06-05 15:00:19 --> Config Class Initialized
INFO - 2024-06-05 15:00:19 --> Hooks Class Initialized
DEBUG - 2024-06-05 15:00:19 --> UTF-8 Support Enabled
INFO - 2024-06-05 15:00:19 --> Utf8 Class Initialized
INFO - 2024-06-05 15:00:19 --> URI Class Initialized
INFO - 2024-06-05 15:00:19 --> Router Class Initialized
INFO - 2024-06-05 15:00:19 --> Output Class Initialized
INFO - 2024-06-05 15:00:19 --> Security Class Initialized
DEBUG - 2024-06-05 15:00:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-05 15:00:19 --> Input Class Initialized
INFO - 2024-06-05 15:00:19 --> Language Class Initialized
INFO - 2024-06-05 15:00:19 --> Language Class Initialized
INFO - 2024-06-05 15:00:19 --> Config Class Initialized
INFO - 2024-06-05 15:00:19 --> Loader Class Initialized
INFO - 2024-06-05 15:00:19 --> Helper loaded: url_helper
INFO - 2024-06-05 15:00:19 --> Helper loaded: file_helper
INFO - 2024-06-05 15:00:19 --> Helper loaded: form_helper
INFO - 2024-06-05 15:00:19 --> Helper loaded: my_helper
INFO - 2024-06-05 15:00:19 --> Database Driver Class Initialized
INFO - 2024-06-05 15:00:19 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-05 15:00:19 --> Controller Class Initialized
INFO - 2024-06-05 15:00:19 --> Final output sent to browser
DEBUG - 2024-06-05 15:00:19 --> Total execution time: 0.0702
INFO - 2024-06-05 15:00:23 --> Config Class Initialized
INFO - 2024-06-05 15:00:23 --> Hooks Class Initialized
DEBUG - 2024-06-05 15:00:23 --> UTF-8 Support Enabled
INFO - 2024-06-05 15:00:23 --> Utf8 Class Initialized
INFO - 2024-06-05 15:00:23 --> URI Class Initialized
INFO - 2024-06-05 15:00:23 --> Router Class Initialized
INFO - 2024-06-05 15:00:23 --> Output Class Initialized
INFO - 2024-06-05 15:00:23 --> Security Class Initialized
DEBUG - 2024-06-05 15:00:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-05 15:00:23 --> Input Class Initialized
INFO - 2024-06-05 15:00:23 --> Language Class Initialized
INFO - 2024-06-05 15:00:23 --> Language Class Initialized
INFO - 2024-06-05 15:00:23 --> Config Class Initialized
INFO - 2024-06-05 15:00:23 --> Loader Class Initialized
INFO - 2024-06-05 15:00:23 --> Helper loaded: url_helper
INFO - 2024-06-05 15:00:23 --> Helper loaded: file_helper
INFO - 2024-06-05 15:00:23 --> Helper loaded: form_helper
INFO - 2024-06-05 15:00:23 --> Helper loaded: my_helper
INFO - 2024-06-05 15:00:23 --> Database Driver Class Initialized
INFO - 2024-06-05 15:00:23 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-05 15:00:23 --> Controller Class Initialized
INFO - 2024-06-05 15:00:23 --> Final output sent to browser
DEBUG - 2024-06-05 15:00:23 --> Total execution time: 0.0308
INFO - 2024-06-05 15:00:26 --> Config Class Initialized
INFO - 2024-06-05 15:00:26 --> Hooks Class Initialized
DEBUG - 2024-06-05 15:00:26 --> UTF-8 Support Enabled
INFO - 2024-06-05 15:00:26 --> Utf8 Class Initialized
INFO - 2024-06-05 15:00:26 --> URI Class Initialized
INFO - 2024-06-05 15:00:26 --> Router Class Initialized
INFO - 2024-06-05 15:00:26 --> Output Class Initialized
INFO - 2024-06-05 15:00:26 --> Security Class Initialized
DEBUG - 2024-06-05 15:00:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-05 15:00:26 --> Input Class Initialized
INFO - 2024-06-05 15:00:26 --> Language Class Initialized
INFO - 2024-06-05 15:00:26 --> Language Class Initialized
INFO - 2024-06-05 15:00:26 --> Config Class Initialized
INFO - 2024-06-05 15:00:26 --> Loader Class Initialized
INFO - 2024-06-05 15:00:26 --> Helper loaded: url_helper
INFO - 2024-06-05 15:00:26 --> Helper loaded: file_helper
INFO - 2024-06-05 15:00:26 --> Helper loaded: form_helper
INFO - 2024-06-05 15:00:26 --> Helper loaded: my_helper
INFO - 2024-06-05 15:00:26 --> Database Driver Class Initialized
INFO - 2024-06-05 15:00:26 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-05 15:00:26 --> Controller Class Initialized
INFO - 2024-06-05 15:00:26 --> Final output sent to browser
DEBUG - 2024-06-05 15:00:26 --> Total execution time: 0.0704
INFO - 2024-06-05 15:00:27 --> Config Class Initialized
INFO - 2024-06-05 15:00:27 --> Hooks Class Initialized
DEBUG - 2024-06-05 15:00:27 --> UTF-8 Support Enabled
INFO - 2024-06-05 15:00:27 --> Utf8 Class Initialized
INFO - 2024-06-05 15:00:27 --> URI Class Initialized
INFO - 2024-06-05 15:00:27 --> Router Class Initialized
INFO - 2024-06-05 15:00:27 --> Output Class Initialized
INFO - 2024-06-05 15:00:27 --> Security Class Initialized
DEBUG - 2024-06-05 15:00:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-05 15:00:27 --> Input Class Initialized
INFO - 2024-06-05 15:00:27 --> Language Class Initialized
INFO - 2024-06-05 15:00:27 --> Language Class Initialized
INFO - 2024-06-05 15:00:27 --> Config Class Initialized
INFO - 2024-06-05 15:00:27 --> Loader Class Initialized
INFO - 2024-06-05 15:00:27 --> Helper loaded: url_helper
INFO - 2024-06-05 15:00:27 --> Helper loaded: file_helper
INFO - 2024-06-05 15:00:27 --> Helper loaded: form_helper
INFO - 2024-06-05 15:00:27 --> Helper loaded: my_helper
INFO - 2024-06-05 15:00:27 --> Database Driver Class Initialized
INFO - 2024-06-05 15:00:27 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-05 15:00:27 --> Controller Class Initialized
INFO - 2024-06-05 15:00:27 --> Final output sent to browser
DEBUG - 2024-06-05 15:00:27 --> Total execution time: 0.0597
INFO - 2024-06-05 15:00:28 --> Config Class Initialized
INFO - 2024-06-05 15:00:28 --> Hooks Class Initialized
DEBUG - 2024-06-05 15:00:28 --> UTF-8 Support Enabled
INFO - 2024-06-05 15:00:28 --> Utf8 Class Initialized
INFO - 2024-06-05 15:00:28 --> URI Class Initialized
INFO - 2024-06-05 15:00:28 --> Router Class Initialized
INFO - 2024-06-05 15:00:28 --> Output Class Initialized
INFO - 2024-06-05 15:00:28 --> Security Class Initialized
DEBUG - 2024-06-05 15:00:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-05 15:00:28 --> Input Class Initialized
INFO - 2024-06-05 15:00:28 --> Language Class Initialized
INFO - 2024-06-05 15:00:28 --> Language Class Initialized
INFO - 2024-06-05 15:00:28 --> Config Class Initialized
INFO - 2024-06-05 15:00:28 --> Loader Class Initialized
INFO - 2024-06-05 15:00:28 --> Helper loaded: url_helper
INFO - 2024-06-05 15:00:28 --> Helper loaded: file_helper
INFO - 2024-06-05 15:00:28 --> Helper loaded: form_helper
INFO - 2024-06-05 15:00:28 --> Helper loaded: my_helper
INFO - 2024-06-05 15:00:28 --> Database Driver Class Initialized
INFO - 2024-06-05 15:00:28 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-05 15:00:28 --> Controller Class Initialized
INFO - 2024-06-05 15:00:28 --> Final output sent to browser
DEBUG - 2024-06-05 15:00:28 --> Total execution time: 0.0322
INFO - 2024-06-05 15:00:35 --> Config Class Initialized
INFO - 2024-06-05 15:00:35 --> Hooks Class Initialized
DEBUG - 2024-06-05 15:00:35 --> UTF-8 Support Enabled
INFO - 2024-06-05 15:00:35 --> Utf8 Class Initialized
INFO - 2024-06-05 15:00:35 --> URI Class Initialized
INFO - 2024-06-05 15:00:35 --> Router Class Initialized
INFO - 2024-06-05 15:00:35 --> Output Class Initialized
INFO - 2024-06-05 15:00:35 --> Security Class Initialized
DEBUG - 2024-06-05 15:00:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-05 15:00:35 --> Input Class Initialized
INFO - 2024-06-05 15:00:35 --> Language Class Initialized
INFO - 2024-06-05 15:00:35 --> Language Class Initialized
INFO - 2024-06-05 15:00:35 --> Config Class Initialized
INFO - 2024-06-05 15:00:35 --> Loader Class Initialized
INFO - 2024-06-05 15:00:35 --> Helper loaded: url_helper
INFO - 2024-06-05 15:00:35 --> Helper loaded: file_helper
INFO - 2024-06-05 15:00:35 --> Helper loaded: form_helper
INFO - 2024-06-05 15:00:35 --> Helper loaded: my_helper
INFO - 2024-06-05 15:00:35 --> Database Driver Class Initialized
INFO - 2024-06-05 15:00:35 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-05 15:00:35 --> Controller Class Initialized
INFO - 2024-06-05 15:00:35 --> Final output sent to browser
DEBUG - 2024-06-05 15:00:35 --> Total execution time: 0.0377
INFO - 2024-06-05 15:00:40 --> Config Class Initialized
INFO - 2024-06-05 15:00:40 --> Hooks Class Initialized
DEBUG - 2024-06-05 15:00:40 --> UTF-8 Support Enabled
INFO - 2024-06-05 15:00:40 --> Utf8 Class Initialized
INFO - 2024-06-05 15:00:40 --> URI Class Initialized
INFO - 2024-06-05 15:00:40 --> Router Class Initialized
INFO - 2024-06-05 15:00:40 --> Output Class Initialized
INFO - 2024-06-05 15:00:40 --> Security Class Initialized
DEBUG - 2024-06-05 15:00:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-05 15:00:40 --> Input Class Initialized
INFO - 2024-06-05 15:00:40 --> Language Class Initialized
INFO - 2024-06-05 15:00:40 --> Language Class Initialized
INFO - 2024-06-05 15:00:40 --> Config Class Initialized
INFO - 2024-06-05 15:00:40 --> Loader Class Initialized
INFO - 2024-06-05 15:00:40 --> Helper loaded: url_helper
INFO - 2024-06-05 15:00:40 --> Helper loaded: file_helper
INFO - 2024-06-05 15:00:40 --> Helper loaded: form_helper
INFO - 2024-06-05 15:00:40 --> Helper loaded: my_helper
INFO - 2024-06-05 15:00:40 --> Database Driver Class Initialized
INFO - 2024-06-05 15:00:40 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-05 15:00:40 --> Controller Class Initialized
INFO - 2024-06-05 15:00:40 --> Config Class Initialized
INFO - 2024-06-05 15:00:40 --> Hooks Class Initialized
DEBUG - 2024-06-05 15:00:40 --> UTF-8 Support Enabled
INFO - 2024-06-05 15:00:40 --> Utf8 Class Initialized
INFO - 2024-06-05 15:00:40 --> URI Class Initialized
INFO - 2024-06-05 15:00:40 --> Router Class Initialized
INFO - 2024-06-05 15:00:40 --> Output Class Initialized
INFO - 2024-06-05 15:00:40 --> Security Class Initialized
DEBUG - 2024-06-05 15:00:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-05 15:00:40 --> Input Class Initialized
INFO - 2024-06-05 15:00:40 --> Language Class Initialized
INFO - 2024-06-05 15:00:40 --> Language Class Initialized
INFO - 2024-06-05 15:00:40 --> Config Class Initialized
INFO - 2024-06-05 15:00:40 --> Loader Class Initialized
INFO - 2024-06-05 15:00:40 --> Helper loaded: url_helper
INFO - 2024-06-05 15:00:40 --> Helper loaded: file_helper
INFO - 2024-06-05 15:00:40 --> Helper loaded: form_helper
INFO - 2024-06-05 15:00:40 --> Helper loaded: my_helper
INFO - 2024-06-05 15:00:40 --> Database Driver Class Initialized
INFO - 2024-06-05 15:00:40 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-05 15:00:40 --> Controller Class Initialized
DEBUG - 2024-06-05 15:00:40 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/login/views/login.php
DEBUG - 2024-06-05 15:00:40 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-06-05 15:00:40 --> Final output sent to browser
DEBUG - 2024-06-05 15:00:40 --> Total execution time: 0.0305
INFO - 2024-06-05 15:00:45 --> Config Class Initialized
INFO - 2024-06-05 15:00:45 --> Hooks Class Initialized
DEBUG - 2024-06-05 15:00:45 --> UTF-8 Support Enabled
INFO - 2024-06-05 15:00:45 --> Utf8 Class Initialized
INFO - 2024-06-05 15:00:45 --> URI Class Initialized
INFO - 2024-06-05 15:00:45 --> Router Class Initialized
INFO - 2024-06-05 15:00:45 --> Output Class Initialized
INFO - 2024-06-05 15:00:45 --> Security Class Initialized
DEBUG - 2024-06-05 15:00:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-05 15:00:45 --> Input Class Initialized
INFO - 2024-06-05 15:00:45 --> Language Class Initialized
INFO - 2024-06-05 15:00:45 --> Language Class Initialized
INFO - 2024-06-05 15:00:45 --> Config Class Initialized
INFO - 2024-06-05 15:00:45 --> Loader Class Initialized
INFO - 2024-06-05 15:00:45 --> Helper loaded: url_helper
INFO - 2024-06-05 15:00:45 --> Helper loaded: file_helper
INFO - 2024-06-05 15:00:45 --> Helper loaded: form_helper
INFO - 2024-06-05 15:00:45 --> Helper loaded: my_helper
INFO - 2024-06-05 15:00:45 --> Database Driver Class Initialized
INFO - 2024-06-05 15:00:45 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-05 15:00:45 --> Controller Class Initialized
INFO - 2024-06-05 15:00:45 --> Helper loaded: cookie_helper
INFO - 2024-06-05 15:00:45 --> Final output sent to browser
DEBUG - 2024-06-05 15:00:45 --> Total execution time: 0.0308
INFO - 2024-06-05 15:00:45 --> Config Class Initialized
INFO - 2024-06-05 15:00:45 --> Hooks Class Initialized
DEBUG - 2024-06-05 15:00:45 --> UTF-8 Support Enabled
INFO - 2024-06-05 15:00:45 --> Utf8 Class Initialized
INFO - 2024-06-05 15:00:45 --> URI Class Initialized
INFO - 2024-06-05 15:00:45 --> Router Class Initialized
INFO - 2024-06-05 15:00:45 --> Output Class Initialized
INFO - 2024-06-05 15:00:45 --> Security Class Initialized
DEBUG - 2024-06-05 15:00:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-05 15:00:45 --> Input Class Initialized
INFO - 2024-06-05 15:00:45 --> Language Class Initialized
INFO - 2024-06-05 15:00:45 --> Language Class Initialized
INFO - 2024-06-05 15:00:45 --> Config Class Initialized
INFO - 2024-06-05 15:00:45 --> Loader Class Initialized
INFO - 2024-06-05 15:00:45 --> Helper loaded: url_helper
INFO - 2024-06-05 15:00:45 --> Helper loaded: file_helper
INFO - 2024-06-05 15:00:45 --> Helper loaded: form_helper
INFO - 2024-06-05 15:00:45 --> Helper loaded: my_helper
INFO - 2024-06-05 15:00:45 --> Database Driver Class Initialized
INFO - 2024-06-05 15:00:45 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-05 15:00:45 --> Controller Class Initialized
DEBUG - 2024-06-05 15:00:45 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/home/views/v_home_guru.php
DEBUG - 2024-06-05 15:00:45 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-06-05 15:00:45 --> Final output sent to browser
DEBUG - 2024-06-05 15:00:45 --> Total execution time: 0.0388
INFO - 2024-06-05 15:00:48 --> Config Class Initialized
INFO - 2024-06-05 15:00:48 --> Hooks Class Initialized
DEBUG - 2024-06-05 15:00:48 --> UTF-8 Support Enabled
INFO - 2024-06-05 15:00:48 --> Utf8 Class Initialized
INFO - 2024-06-05 15:00:48 --> URI Class Initialized
INFO - 2024-06-05 15:00:48 --> Router Class Initialized
INFO - 2024-06-05 15:00:48 --> Output Class Initialized
INFO - 2024-06-05 15:00:48 --> Security Class Initialized
DEBUG - 2024-06-05 15:00:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-05 15:00:48 --> Input Class Initialized
INFO - 2024-06-05 15:00:48 --> Language Class Initialized
INFO - 2024-06-05 15:00:48 --> Language Class Initialized
INFO - 2024-06-05 15:00:48 --> Config Class Initialized
INFO - 2024-06-05 15:00:48 --> Loader Class Initialized
INFO - 2024-06-05 15:00:48 --> Helper loaded: url_helper
INFO - 2024-06-05 15:00:48 --> Helper loaded: file_helper
INFO - 2024-06-05 15:00:48 --> Helper loaded: form_helper
INFO - 2024-06-05 15:00:48 --> Helper loaded: my_helper
INFO - 2024-06-05 15:00:48 --> Database Driver Class Initialized
INFO - 2024-06-05 15:00:48 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-05 15:00:48 --> Controller Class Initialized
DEBUG - 2024-06-05 15:00:48 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/view_mapel/views/v_view_mapel.php
DEBUG - 2024-06-05 15:00:48 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-06-05 15:00:48 --> Final output sent to browser
DEBUG - 2024-06-05 15:00:48 --> Total execution time: 0.0328
INFO - 2024-06-05 15:00:50 --> Config Class Initialized
INFO - 2024-06-05 15:00:50 --> Hooks Class Initialized
DEBUG - 2024-06-05 15:00:50 --> UTF-8 Support Enabled
INFO - 2024-06-05 15:00:50 --> Utf8 Class Initialized
INFO - 2024-06-05 15:00:50 --> URI Class Initialized
INFO - 2024-06-05 15:00:50 --> Router Class Initialized
INFO - 2024-06-05 15:00:50 --> Output Class Initialized
INFO - 2024-06-05 15:00:50 --> Security Class Initialized
DEBUG - 2024-06-05 15:00:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-05 15:00:50 --> Input Class Initialized
INFO - 2024-06-05 15:00:50 --> Language Class Initialized
INFO - 2024-06-05 15:00:50 --> Language Class Initialized
INFO - 2024-06-05 15:00:50 --> Config Class Initialized
INFO - 2024-06-05 15:00:50 --> Loader Class Initialized
INFO - 2024-06-05 15:00:50 --> Helper loaded: url_helper
INFO - 2024-06-05 15:00:50 --> Helper loaded: file_helper
INFO - 2024-06-05 15:00:50 --> Helper loaded: form_helper
INFO - 2024-06-05 15:00:50 --> Helper loaded: my_helper
INFO - 2024-06-05 15:00:50 --> Database Driver Class Initialized
INFO - 2024-06-05 15:00:50 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-05 15:00:50 --> Controller Class Initialized
DEBUG - 2024-06-05 15:00:50 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/views/list.php
DEBUG - 2024-06-05 15:00:50 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-06-05 15:00:50 --> Final output sent to browser
DEBUG - 2024-06-05 15:00:50 --> Total execution time: 0.0349
INFO - 2024-06-05 15:00:51 --> Config Class Initialized
INFO - 2024-06-05 15:00:51 --> Hooks Class Initialized
DEBUG - 2024-06-05 15:00:51 --> UTF-8 Support Enabled
INFO - 2024-06-05 15:00:51 --> Utf8 Class Initialized
INFO - 2024-06-05 15:00:51 --> URI Class Initialized
INFO - 2024-06-05 15:00:51 --> Router Class Initialized
INFO - 2024-06-05 15:00:51 --> Output Class Initialized
INFO - 2024-06-05 15:00:51 --> Security Class Initialized
DEBUG - 2024-06-05 15:00:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-05 15:00:51 --> Input Class Initialized
INFO - 2024-06-05 15:00:51 --> Language Class Initialized
INFO - 2024-06-05 15:00:51 --> Language Class Initialized
INFO - 2024-06-05 15:00:51 --> Config Class Initialized
INFO - 2024-06-05 15:00:51 --> Loader Class Initialized
INFO - 2024-06-05 15:00:51 --> Helper loaded: url_helper
INFO - 2024-06-05 15:00:51 --> Helper loaded: file_helper
INFO - 2024-06-05 15:00:51 --> Helper loaded: form_helper
INFO - 2024-06-05 15:00:51 --> Helper loaded: my_helper
INFO - 2024-06-05 15:00:51 --> Database Driver Class Initialized
INFO - 2024-06-05 15:00:51 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-05 15:00:51 --> Controller Class Initialized
INFO - 2024-06-05 15:00:54 --> Config Class Initialized
INFO - 2024-06-05 15:00:54 --> Hooks Class Initialized
DEBUG - 2024-06-05 15:00:54 --> UTF-8 Support Enabled
INFO - 2024-06-05 15:00:54 --> Utf8 Class Initialized
INFO - 2024-06-05 15:00:54 --> URI Class Initialized
INFO - 2024-06-05 15:00:54 --> Router Class Initialized
INFO - 2024-06-05 15:00:54 --> Output Class Initialized
INFO - 2024-06-05 15:00:54 --> Security Class Initialized
DEBUG - 2024-06-05 15:00:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-05 15:00:54 --> Input Class Initialized
INFO - 2024-06-05 15:00:54 --> Language Class Initialized
INFO - 2024-06-05 15:00:54 --> Language Class Initialized
INFO - 2024-06-05 15:00:54 --> Config Class Initialized
INFO - 2024-06-05 15:00:54 --> Loader Class Initialized
INFO - 2024-06-05 15:00:54 --> Helper loaded: url_helper
INFO - 2024-06-05 15:00:54 --> Helper loaded: file_helper
INFO - 2024-06-05 15:00:54 --> Helper loaded: form_helper
INFO - 2024-06-05 15:00:54 --> Helper loaded: my_helper
INFO - 2024-06-05 15:00:54 --> Database Driver Class Initialized
INFO - 2024-06-05 15:00:54 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-05 15:00:54 --> Controller Class Initialized
INFO - 2024-06-05 15:00:54 --> Final output sent to browser
DEBUG - 2024-06-05 15:00:54 --> Total execution time: 0.0330
INFO - 2024-06-05 15:00:58 --> Config Class Initialized
INFO - 2024-06-05 15:00:58 --> Hooks Class Initialized
DEBUG - 2024-06-05 15:00:58 --> UTF-8 Support Enabled
INFO - 2024-06-05 15:00:58 --> Utf8 Class Initialized
INFO - 2024-06-05 15:00:58 --> URI Class Initialized
INFO - 2024-06-05 15:00:58 --> Router Class Initialized
INFO - 2024-06-05 15:00:58 --> Output Class Initialized
INFO - 2024-06-05 15:00:58 --> Security Class Initialized
DEBUG - 2024-06-05 15:00:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-05 15:00:58 --> Input Class Initialized
INFO - 2024-06-05 15:00:58 --> Language Class Initialized
INFO - 2024-06-05 15:00:58 --> Language Class Initialized
INFO - 2024-06-05 15:00:58 --> Config Class Initialized
INFO - 2024-06-05 15:00:58 --> Loader Class Initialized
INFO - 2024-06-05 15:00:58 --> Helper loaded: url_helper
INFO - 2024-06-05 15:00:58 --> Helper loaded: file_helper
INFO - 2024-06-05 15:00:58 --> Helper loaded: form_helper
INFO - 2024-06-05 15:00:58 --> Helper loaded: my_helper
INFO - 2024-06-05 15:00:58 --> Database Driver Class Initialized
INFO - 2024-06-05 15:00:58 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-05 15:00:58 --> Controller Class Initialized
INFO - 2024-06-05 15:00:58 --> Final output sent to browser
DEBUG - 2024-06-05 15:00:58 --> Total execution time: 0.0276
INFO - 2024-06-05 15:01:02 --> Config Class Initialized
INFO - 2024-06-05 15:01:02 --> Hooks Class Initialized
DEBUG - 2024-06-05 15:01:02 --> UTF-8 Support Enabled
INFO - 2024-06-05 15:01:02 --> Utf8 Class Initialized
INFO - 2024-06-05 15:01:02 --> URI Class Initialized
INFO - 2024-06-05 15:01:02 --> Router Class Initialized
INFO - 2024-06-05 15:01:02 --> Output Class Initialized
INFO - 2024-06-05 15:01:02 --> Security Class Initialized
DEBUG - 2024-06-05 15:01:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-05 15:01:02 --> Input Class Initialized
INFO - 2024-06-05 15:01:02 --> Language Class Initialized
INFO - 2024-06-05 15:01:02 --> Language Class Initialized
INFO - 2024-06-05 15:01:02 --> Config Class Initialized
INFO - 2024-06-05 15:01:02 --> Loader Class Initialized
INFO - 2024-06-05 15:01:02 --> Helper loaded: url_helper
INFO - 2024-06-05 15:01:02 --> Helper loaded: file_helper
INFO - 2024-06-05 15:01:02 --> Helper loaded: form_helper
INFO - 2024-06-05 15:01:02 --> Helper loaded: my_helper
INFO - 2024-06-05 15:01:02 --> Database Driver Class Initialized
INFO - 2024-06-05 15:01:02 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-05 15:01:02 --> Controller Class Initialized
INFO - 2024-06-05 15:01:02 --> Final output sent to browser
DEBUG - 2024-06-05 15:01:02 --> Total execution time: 0.0348
INFO - 2024-06-05 15:01:06 --> Config Class Initialized
INFO - 2024-06-05 15:01:06 --> Hooks Class Initialized
DEBUG - 2024-06-05 15:01:06 --> UTF-8 Support Enabled
INFO - 2024-06-05 15:01:06 --> Utf8 Class Initialized
INFO - 2024-06-05 15:01:06 --> URI Class Initialized
INFO - 2024-06-05 15:01:06 --> Router Class Initialized
INFO - 2024-06-05 15:01:06 --> Output Class Initialized
INFO - 2024-06-05 15:01:06 --> Security Class Initialized
DEBUG - 2024-06-05 15:01:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-05 15:01:06 --> Input Class Initialized
INFO - 2024-06-05 15:01:06 --> Language Class Initialized
INFO - 2024-06-05 15:01:06 --> Language Class Initialized
INFO - 2024-06-05 15:01:06 --> Config Class Initialized
INFO - 2024-06-05 15:01:06 --> Loader Class Initialized
INFO - 2024-06-05 15:01:06 --> Helper loaded: url_helper
INFO - 2024-06-05 15:01:06 --> Helper loaded: file_helper
INFO - 2024-06-05 15:01:06 --> Helper loaded: form_helper
INFO - 2024-06-05 15:01:06 --> Helper loaded: my_helper
INFO - 2024-06-05 15:01:06 --> Database Driver Class Initialized
INFO - 2024-06-05 15:01:06 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-05 15:01:06 --> Controller Class Initialized
INFO - 2024-06-05 15:01:06 --> Final output sent to browser
DEBUG - 2024-06-05 15:01:06 --> Total execution time: 0.0333
INFO - 2024-06-05 15:01:10 --> Config Class Initialized
INFO - 2024-06-05 15:01:10 --> Hooks Class Initialized
DEBUG - 2024-06-05 15:01:10 --> UTF-8 Support Enabled
INFO - 2024-06-05 15:01:10 --> Utf8 Class Initialized
INFO - 2024-06-05 15:01:10 --> URI Class Initialized
INFO - 2024-06-05 15:01:10 --> Router Class Initialized
INFO - 2024-06-05 15:01:10 --> Output Class Initialized
INFO - 2024-06-05 15:01:10 --> Security Class Initialized
DEBUG - 2024-06-05 15:01:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-05 15:01:10 --> Input Class Initialized
INFO - 2024-06-05 15:01:10 --> Language Class Initialized
INFO - 2024-06-05 15:01:10 --> Language Class Initialized
INFO - 2024-06-05 15:01:10 --> Config Class Initialized
INFO - 2024-06-05 15:01:10 --> Loader Class Initialized
INFO - 2024-06-05 15:01:10 --> Helper loaded: url_helper
INFO - 2024-06-05 15:01:10 --> Helper loaded: file_helper
INFO - 2024-06-05 15:01:10 --> Helper loaded: form_helper
INFO - 2024-06-05 15:01:10 --> Helper loaded: my_helper
INFO - 2024-06-05 15:01:10 --> Database Driver Class Initialized
INFO - 2024-06-05 15:01:10 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-05 15:01:10 --> Controller Class Initialized
INFO - 2024-06-05 15:01:10 --> Final output sent to browser
DEBUG - 2024-06-05 15:01:10 --> Total execution time: 0.0293
INFO - 2024-06-05 15:01:13 --> Config Class Initialized
INFO - 2024-06-05 15:01:13 --> Hooks Class Initialized
DEBUG - 2024-06-05 15:01:13 --> UTF-8 Support Enabled
INFO - 2024-06-05 15:01:13 --> Utf8 Class Initialized
INFO - 2024-06-05 15:01:13 --> URI Class Initialized
INFO - 2024-06-05 15:01:13 --> Router Class Initialized
INFO - 2024-06-05 15:01:13 --> Output Class Initialized
INFO - 2024-06-05 15:01:13 --> Security Class Initialized
DEBUG - 2024-06-05 15:01:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-05 15:01:13 --> Input Class Initialized
INFO - 2024-06-05 15:01:13 --> Language Class Initialized
INFO - 2024-06-05 15:01:13 --> Language Class Initialized
INFO - 2024-06-05 15:01:13 --> Config Class Initialized
INFO - 2024-06-05 15:01:13 --> Loader Class Initialized
INFO - 2024-06-05 15:01:13 --> Helper loaded: url_helper
INFO - 2024-06-05 15:01:13 --> Helper loaded: file_helper
INFO - 2024-06-05 15:01:13 --> Helper loaded: form_helper
INFO - 2024-06-05 15:01:13 --> Helper loaded: my_helper
INFO - 2024-06-05 15:01:13 --> Database Driver Class Initialized
INFO - 2024-06-05 15:01:13 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-05 15:01:13 --> Controller Class Initialized
INFO - 2024-06-05 15:01:13 --> Final output sent to browser
DEBUG - 2024-06-05 15:01:13 --> Total execution time: 0.0308
INFO - 2024-06-05 15:01:16 --> Config Class Initialized
INFO - 2024-06-05 15:01:16 --> Hooks Class Initialized
DEBUG - 2024-06-05 15:01:16 --> UTF-8 Support Enabled
INFO - 2024-06-05 15:01:16 --> Utf8 Class Initialized
INFO - 2024-06-05 15:01:16 --> URI Class Initialized
INFO - 2024-06-05 15:01:16 --> Router Class Initialized
INFO - 2024-06-05 15:01:16 --> Output Class Initialized
INFO - 2024-06-05 15:01:16 --> Security Class Initialized
DEBUG - 2024-06-05 15:01:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-05 15:01:16 --> Input Class Initialized
INFO - 2024-06-05 15:01:16 --> Language Class Initialized
INFO - 2024-06-05 15:01:16 --> Language Class Initialized
INFO - 2024-06-05 15:01:16 --> Config Class Initialized
INFO - 2024-06-05 15:01:16 --> Loader Class Initialized
INFO - 2024-06-05 15:01:16 --> Helper loaded: url_helper
INFO - 2024-06-05 15:01:16 --> Helper loaded: file_helper
INFO - 2024-06-05 15:01:16 --> Helper loaded: form_helper
INFO - 2024-06-05 15:01:16 --> Helper loaded: my_helper
INFO - 2024-06-05 15:01:16 --> Database Driver Class Initialized
INFO - 2024-06-05 15:01:16 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-05 15:01:16 --> Controller Class Initialized
INFO - 2024-06-05 15:01:16 --> Final output sent to browser
DEBUG - 2024-06-05 15:01:16 --> Total execution time: 0.0316
INFO - 2024-06-05 15:01:20 --> Config Class Initialized
INFO - 2024-06-05 15:01:20 --> Hooks Class Initialized
DEBUG - 2024-06-05 15:01:20 --> UTF-8 Support Enabled
INFO - 2024-06-05 15:01:20 --> Utf8 Class Initialized
INFO - 2024-06-05 15:01:20 --> URI Class Initialized
INFO - 2024-06-05 15:01:20 --> Router Class Initialized
INFO - 2024-06-05 15:01:20 --> Output Class Initialized
INFO - 2024-06-05 15:01:20 --> Security Class Initialized
DEBUG - 2024-06-05 15:01:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-05 15:01:20 --> Input Class Initialized
INFO - 2024-06-05 15:01:20 --> Language Class Initialized
INFO - 2024-06-05 15:01:20 --> Language Class Initialized
INFO - 2024-06-05 15:01:20 --> Config Class Initialized
INFO - 2024-06-05 15:01:20 --> Loader Class Initialized
INFO - 2024-06-05 15:01:20 --> Helper loaded: url_helper
INFO - 2024-06-05 15:01:20 --> Helper loaded: file_helper
INFO - 2024-06-05 15:01:20 --> Helper loaded: form_helper
INFO - 2024-06-05 15:01:20 --> Helper loaded: my_helper
INFO - 2024-06-05 15:01:20 --> Database Driver Class Initialized
INFO - 2024-06-05 15:01:20 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-05 15:01:20 --> Controller Class Initialized
INFO - 2024-06-05 15:01:20 --> Final output sent to browser
DEBUG - 2024-06-05 15:01:20 --> Total execution time: 0.0322
INFO - 2024-06-05 15:03:46 --> Config Class Initialized
INFO - 2024-06-05 15:03:46 --> Hooks Class Initialized
DEBUG - 2024-06-05 15:03:46 --> UTF-8 Support Enabled
INFO - 2024-06-05 15:03:46 --> Utf8 Class Initialized
INFO - 2024-06-05 15:03:46 --> URI Class Initialized
INFO - 2024-06-05 15:03:46 --> Router Class Initialized
INFO - 2024-06-05 15:03:46 --> Output Class Initialized
INFO - 2024-06-05 15:03:46 --> Security Class Initialized
DEBUG - 2024-06-05 15:03:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-05 15:03:46 --> Input Class Initialized
INFO - 2024-06-05 15:03:46 --> Language Class Initialized
INFO - 2024-06-05 15:03:46 --> Language Class Initialized
INFO - 2024-06-05 15:03:46 --> Config Class Initialized
INFO - 2024-06-05 15:03:46 --> Loader Class Initialized
INFO - 2024-06-05 15:03:46 --> Helper loaded: url_helper
INFO - 2024-06-05 15:03:46 --> Helper loaded: file_helper
INFO - 2024-06-05 15:03:46 --> Helper loaded: form_helper
INFO - 2024-06-05 15:03:46 --> Helper loaded: my_helper
INFO - 2024-06-05 15:03:46 --> Database Driver Class Initialized
INFO - 2024-06-05 15:03:46 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-05 15:03:46 --> Controller Class Initialized
INFO - 2024-06-05 15:03:46 --> Final output sent to browser
DEBUG - 2024-06-05 15:03:46 --> Total execution time: 0.0642
INFO - 2024-06-05 15:03:49 --> Config Class Initialized
INFO - 2024-06-05 15:03:49 --> Hooks Class Initialized
DEBUG - 2024-06-05 15:03:49 --> UTF-8 Support Enabled
INFO - 2024-06-05 15:03:49 --> Utf8 Class Initialized
INFO - 2024-06-05 15:03:49 --> URI Class Initialized
INFO - 2024-06-05 15:03:49 --> Router Class Initialized
INFO - 2024-06-05 15:03:49 --> Output Class Initialized
INFO - 2024-06-05 15:03:49 --> Security Class Initialized
DEBUG - 2024-06-05 15:03:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-05 15:03:49 --> Input Class Initialized
INFO - 2024-06-05 15:03:50 --> Language Class Initialized
INFO - 2024-06-05 15:03:50 --> Language Class Initialized
INFO - 2024-06-05 15:03:50 --> Config Class Initialized
INFO - 2024-06-05 15:03:50 --> Loader Class Initialized
INFO - 2024-06-05 15:03:50 --> Helper loaded: url_helper
INFO - 2024-06-05 15:03:50 --> Helper loaded: file_helper
INFO - 2024-06-05 15:03:50 --> Helper loaded: form_helper
INFO - 2024-06-05 15:03:50 --> Helper loaded: my_helper
INFO - 2024-06-05 15:03:50 --> Database Driver Class Initialized
INFO - 2024-06-05 15:03:50 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-05 15:03:50 --> Controller Class Initialized
INFO - 2024-06-05 15:03:50 --> Final output sent to browser
DEBUG - 2024-06-05 15:03:50 --> Total execution time: 0.0374
INFO - 2024-06-05 16:35:58 --> Config Class Initialized
INFO - 2024-06-05 16:35:58 --> Hooks Class Initialized
DEBUG - 2024-06-05 16:35:58 --> UTF-8 Support Enabled
INFO - 2024-06-05 16:35:58 --> Utf8 Class Initialized
INFO - 2024-06-05 16:35:58 --> URI Class Initialized
INFO - 2024-06-05 16:35:58 --> Router Class Initialized
INFO - 2024-06-05 16:35:58 --> Output Class Initialized
INFO - 2024-06-05 16:35:58 --> Security Class Initialized
DEBUG - 2024-06-05 16:35:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-05 16:35:58 --> Input Class Initialized
INFO - 2024-06-05 16:35:58 --> Language Class Initialized
INFO - 2024-06-05 16:35:58 --> Language Class Initialized
INFO - 2024-06-05 16:35:58 --> Config Class Initialized
INFO - 2024-06-05 16:35:58 --> Loader Class Initialized
INFO - 2024-06-05 16:35:58 --> Helper loaded: url_helper
INFO - 2024-06-05 16:35:58 --> Helper loaded: file_helper
INFO - 2024-06-05 16:35:58 --> Helper loaded: form_helper
INFO - 2024-06-05 16:35:58 --> Helper loaded: my_helper
INFO - 2024-06-05 16:35:58 --> Database Driver Class Initialized
INFO - 2024-06-05 16:35:58 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-05 16:35:58 --> Controller Class Initialized
INFO - 2024-06-05 16:35:58 --> Final output sent to browser
DEBUG - 2024-06-05 16:35:58 --> Total execution time: 0.0537
INFO - 2024-06-05 16:37:16 --> Config Class Initialized
INFO - 2024-06-05 16:37:16 --> Hooks Class Initialized
DEBUG - 2024-06-05 16:37:16 --> UTF-8 Support Enabled
INFO - 2024-06-05 16:37:16 --> Utf8 Class Initialized
INFO - 2024-06-05 16:37:16 --> URI Class Initialized
INFO - 2024-06-05 16:37:16 --> Router Class Initialized
INFO - 2024-06-05 16:37:16 --> Output Class Initialized
INFO - 2024-06-05 16:37:16 --> Security Class Initialized
DEBUG - 2024-06-05 16:37:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-05 16:37:16 --> Input Class Initialized
INFO - 2024-06-05 16:37:16 --> Language Class Initialized
INFO - 2024-06-05 16:37:16 --> Language Class Initialized
INFO - 2024-06-05 16:37:16 --> Config Class Initialized
INFO - 2024-06-05 16:37:16 --> Loader Class Initialized
INFO - 2024-06-05 16:37:16 --> Helper loaded: url_helper
INFO - 2024-06-05 16:37:16 --> Helper loaded: file_helper
INFO - 2024-06-05 16:37:16 --> Helper loaded: form_helper
INFO - 2024-06-05 16:37:16 --> Helper loaded: my_helper
INFO - 2024-06-05 16:37:16 --> Database Driver Class Initialized
INFO - 2024-06-05 16:37:16 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-05 16:37:16 --> Controller Class Initialized
INFO - 2024-06-05 16:37:16 --> Final output sent to browser
DEBUG - 2024-06-05 16:37:16 --> Total execution time: 0.1275
INFO - 2024-06-05 16:37:28 --> Config Class Initialized
INFO - 2024-06-05 16:37:28 --> Hooks Class Initialized
DEBUG - 2024-06-05 16:37:28 --> UTF-8 Support Enabled
INFO - 2024-06-05 16:37:28 --> Utf8 Class Initialized
INFO - 2024-06-05 16:37:28 --> URI Class Initialized
INFO - 2024-06-05 16:37:28 --> Router Class Initialized
INFO - 2024-06-05 16:37:28 --> Output Class Initialized
INFO - 2024-06-05 16:37:28 --> Security Class Initialized
DEBUG - 2024-06-05 16:37:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-05 16:37:28 --> Input Class Initialized
INFO - 2024-06-05 16:37:28 --> Language Class Initialized
INFO - 2024-06-05 16:37:28 --> Language Class Initialized
INFO - 2024-06-05 16:37:28 --> Config Class Initialized
INFO - 2024-06-05 16:37:28 --> Loader Class Initialized
INFO - 2024-06-05 16:37:28 --> Helper loaded: url_helper
INFO - 2024-06-05 16:37:28 --> Helper loaded: file_helper
INFO - 2024-06-05 16:37:28 --> Helper loaded: form_helper
INFO - 2024-06-05 16:37:28 --> Helper loaded: my_helper
INFO - 2024-06-05 16:37:28 --> Database Driver Class Initialized
INFO - 2024-06-05 16:37:28 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-05 16:37:28 --> Controller Class Initialized
INFO - 2024-06-05 16:37:29 --> Final output sent to browser
DEBUG - 2024-06-05 16:37:29 --> Total execution time: 0.1768
INFO - 2024-06-05 16:37:32 --> Config Class Initialized
INFO - 2024-06-05 16:37:32 --> Hooks Class Initialized
DEBUG - 2024-06-05 16:37:32 --> UTF-8 Support Enabled
INFO - 2024-06-05 16:37:32 --> Utf8 Class Initialized
INFO - 2024-06-05 16:37:32 --> URI Class Initialized
INFO - 2024-06-05 16:37:32 --> Router Class Initialized
INFO - 2024-06-05 16:37:32 --> Output Class Initialized
INFO - 2024-06-05 16:37:32 --> Security Class Initialized
DEBUG - 2024-06-05 16:37:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-05 16:37:32 --> Input Class Initialized
INFO - 2024-06-05 16:37:32 --> Language Class Initialized
INFO - 2024-06-05 16:37:32 --> Language Class Initialized
INFO - 2024-06-05 16:37:32 --> Config Class Initialized
INFO - 2024-06-05 16:37:32 --> Loader Class Initialized
INFO - 2024-06-05 16:37:32 --> Helper loaded: url_helper
INFO - 2024-06-05 16:37:32 --> Helper loaded: file_helper
INFO - 2024-06-05 16:37:32 --> Helper loaded: form_helper
INFO - 2024-06-05 16:37:32 --> Helper loaded: my_helper
INFO - 2024-06-05 16:37:32 --> Database Driver Class Initialized
INFO - 2024-06-05 16:37:32 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-05 16:37:32 --> Controller Class Initialized
INFO - 2024-06-05 16:37:32 --> Final output sent to browser
DEBUG - 2024-06-05 16:37:32 --> Total execution time: 0.0359
INFO - 2024-06-05 16:37:35 --> Config Class Initialized
INFO - 2024-06-05 16:37:35 --> Hooks Class Initialized
DEBUG - 2024-06-05 16:37:35 --> UTF-8 Support Enabled
INFO - 2024-06-05 16:37:35 --> Utf8 Class Initialized
INFO - 2024-06-05 16:37:35 --> URI Class Initialized
INFO - 2024-06-05 16:37:35 --> Router Class Initialized
INFO - 2024-06-05 16:37:35 --> Output Class Initialized
INFO - 2024-06-05 16:37:35 --> Security Class Initialized
DEBUG - 2024-06-05 16:37:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-05 16:37:35 --> Input Class Initialized
INFO - 2024-06-05 16:37:35 --> Language Class Initialized
INFO - 2024-06-05 16:37:35 --> Language Class Initialized
INFO - 2024-06-05 16:37:35 --> Config Class Initialized
INFO - 2024-06-05 16:37:35 --> Loader Class Initialized
INFO - 2024-06-05 16:37:35 --> Helper loaded: url_helper
INFO - 2024-06-05 16:37:35 --> Helper loaded: file_helper
INFO - 2024-06-05 16:37:35 --> Helper loaded: form_helper
INFO - 2024-06-05 16:37:35 --> Helper loaded: my_helper
INFO - 2024-06-05 16:37:35 --> Database Driver Class Initialized
INFO - 2024-06-05 16:37:35 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-05 16:37:35 --> Controller Class Initialized
INFO - 2024-06-05 16:37:35 --> Final output sent to browser
DEBUG - 2024-06-05 16:37:35 --> Total execution time: 0.0659
INFO - 2024-06-05 16:37:40 --> Config Class Initialized
INFO - 2024-06-05 16:37:40 --> Hooks Class Initialized
DEBUG - 2024-06-05 16:37:40 --> UTF-8 Support Enabled
INFO - 2024-06-05 16:37:40 --> Utf8 Class Initialized
INFO - 2024-06-05 16:37:40 --> URI Class Initialized
INFO - 2024-06-05 16:37:40 --> Router Class Initialized
INFO - 2024-06-05 16:37:40 --> Output Class Initialized
INFO - 2024-06-05 16:37:40 --> Security Class Initialized
DEBUG - 2024-06-05 16:37:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-05 16:37:40 --> Input Class Initialized
INFO - 2024-06-05 16:37:40 --> Language Class Initialized
INFO - 2024-06-05 16:37:40 --> Language Class Initialized
INFO - 2024-06-05 16:37:40 --> Config Class Initialized
INFO - 2024-06-05 16:37:40 --> Loader Class Initialized
INFO - 2024-06-05 16:37:40 --> Helper loaded: url_helper
INFO - 2024-06-05 16:37:40 --> Helper loaded: file_helper
INFO - 2024-06-05 16:37:40 --> Helper loaded: form_helper
INFO - 2024-06-05 16:37:40 --> Helper loaded: my_helper
INFO - 2024-06-05 16:37:40 --> Database Driver Class Initialized
INFO - 2024-06-05 16:37:40 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-05 16:37:40 --> Controller Class Initialized
INFO - 2024-06-05 16:37:40 --> Final output sent to browser
DEBUG - 2024-06-05 16:37:40 --> Total execution time: 0.0412
INFO - 2024-06-05 16:37:45 --> Config Class Initialized
INFO - 2024-06-05 16:37:45 --> Hooks Class Initialized
DEBUG - 2024-06-05 16:37:45 --> UTF-8 Support Enabled
INFO - 2024-06-05 16:37:45 --> Utf8 Class Initialized
INFO - 2024-06-05 16:37:45 --> URI Class Initialized
INFO - 2024-06-05 16:37:45 --> Router Class Initialized
INFO - 2024-06-05 16:37:45 --> Output Class Initialized
INFO - 2024-06-05 16:37:45 --> Security Class Initialized
DEBUG - 2024-06-05 16:37:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-05 16:37:45 --> Input Class Initialized
INFO - 2024-06-05 16:37:45 --> Language Class Initialized
INFO - 2024-06-05 16:37:45 --> Language Class Initialized
INFO - 2024-06-05 16:37:45 --> Config Class Initialized
INFO - 2024-06-05 16:37:45 --> Loader Class Initialized
INFO - 2024-06-05 16:37:45 --> Helper loaded: url_helper
INFO - 2024-06-05 16:37:45 --> Helper loaded: file_helper
INFO - 2024-06-05 16:37:45 --> Helper loaded: form_helper
INFO - 2024-06-05 16:37:45 --> Helper loaded: my_helper
INFO - 2024-06-05 16:37:45 --> Database Driver Class Initialized
INFO - 2024-06-05 16:37:45 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-05 16:37:45 --> Controller Class Initialized
INFO - 2024-06-05 16:37:45 --> Final output sent to browser
DEBUG - 2024-06-05 16:37:45 --> Total execution time: 0.0333
INFO - 2024-06-05 16:37:53 --> Config Class Initialized
INFO - 2024-06-05 16:37:53 --> Hooks Class Initialized
DEBUG - 2024-06-05 16:37:53 --> UTF-8 Support Enabled
INFO - 2024-06-05 16:37:53 --> Utf8 Class Initialized
INFO - 2024-06-05 16:37:53 --> URI Class Initialized
INFO - 2024-06-05 16:37:53 --> Router Class Initialized
INFO - 2024-06-05 16:37:53 --> Output Class Initialized
INFO - 2024-06-05 16:37:53 --> Security Class Initialized
DEBUG - 2024-06-05 16:37:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-05 16:37:53 --> Input Class Initialized
INFO - 2024-06-05 16:37:53 --> Language Class Initialized
INFO - 2024-06-05 16:37:53 --> Language Class Initialized
INFO - 2024-06-05 16:37:53 --> Config Class Initialized
INFO - 2024-06-05 16:37:53 --> Loader Class Initialized
INFO - 2024-06-05 16:37:53 --> Helper loaded: url_helper
INFO - 2024-06-05 16:37:53 --> Helper loaded: file_helper
INFO - 2024-06-05 16:37:53 --> Helper loaded: form_helper
INFO - 2024-06-05 16:37:53 --> Helper loaded: my_helper
INFO - 2024-06-05 16:37:53 --> Database Driver Class Initialized
INFO - 2024-06-05 16:37:53 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-05 16:37:53 --> Controller Class Initialized
INFO - 2024-06-05 16:37:53 --> Final output sent to browser
DEBUG - 2024-06-05 16:37:53 --> Total execution time: 0.0491
INFO - 2024-06-05 16:37:57 --> Config Class Initialized
INFO - 2024-06-05 16:37:57 --> Hooks Class Initialized
DEBUG - 2024-06-05 16:37:57 --> UTF-8 Support Enabled
INFO - 2024-06-05 16:37:57 --> Utf8 Class Initialized
INFO - 2024-06-05 16:37:57 --> URI Class Initialized
INFO - 2024-06-05 16:37:57 --> Router Class Initialized
INFO - 2024-06-05 16:37:57 --> Output Class Initialized
INFO - 2024-06-05 16:37:57 --> Security Class Initialized
DEBUG - 2024-06-05 16:37:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-05 16:37:57 --> Input Class Initialized
INFO - 2024-06-05 16:37:57 --> Language Class Initialized
INFO - 2024-06-05 16:37:57 --> Language Class Initialized
INFO - 2024-06-05 16:37:57 --> Config Class Initialized
INFO - 2024-06-05 16:37:57 --> Loader Class Initialized
INFO - 2024-06-05 16:37:57 --> Helper loaded: url_helper
INFO - 2024-06-05 16:37:57 --> Helper loaded: file_helper
INFO - 2024-06-05 16:37:57 --> Helper loaded: form_helper
INFO - 2024-06-05 16:37:57 --> Helper loaded: my_helper
INFO - 2024-06-05 16:37:57 --> Database Driver Class Initialized
INFO - 2024-06-05 16:37:57 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-05 16:37:57 --> Controller Class Initialized
INFO - 2024-06-05 16:37:57 --> Final output sent to browser
DEBUG - 2024-06-05 16:37:57 --> Total execution time: 0.0360
INFO - 2024-06-05 16:38:01 --> Config Class Initialized
INFO - 2024-06-05 16:38:01 --> Hooks Class Initialized
DEBUG - 2024-06-05 16:38:01 --> UTF-8 Support Enabled
INFO - 2024-06-05 16:38:01 --> Utf8 Class Initialized
INFO - 2024-06-05 16:38:01 --> URI Class Initialized
INFO - 2024-06-05 16:38:01 --> Router Class Initialized
INFO - 2024-06-05 16:38:01 --> Output Class Initialized
INFO - 2024-06-05 16:38:01 --> Security Class Initialized
DEBUG - 2024-06-05 16:38:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-05 16:38:01 --> Input Class Initialized
INFO - 2024-06-05 16:38:01 --> Language Class Initialized
INFO - 2024-06-05 16:38:01 --> Language Class Initialized
INFO - 2024-06-05 16:38:01 --> Config Class Initialized
INFO - 2024-06-05 16:38:01 --> Loader Class Initialized
INFO - 2024-06-05 16:38:02 --> Helper loaded: url_helper
INFO - 2024-06-05 16:38:02 --> Helper loaded: file_helper
INFO - 2024-06-05 16:38:02 --> Helper loaded: form_helper
INFO - 2024-06-05 16:38:02 --> Helper loaded: my_helper
INFO - 2024-06-05 16:38:02 --> Database Driver Class Initialized
INFO - 2024-06-05 16:38:02 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-05 16:38:02 --> Controller Class Initialized
INFO - 2024-06-05 16:38:02 --> Final output sent to browser
DEBUG - 2024-06-05 16:38:02 --> Total execution time: 0.0843
