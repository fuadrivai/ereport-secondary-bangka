<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2023-12-04 09:01:42 --> Config Class Initialized
INFO - 2023-12-04 09:01:42 --> Hooks Class Initialized
DEBUG - 2023-12-04 09:01:42 --> UTF-8 Support Enabled
INFO - 2023-12-04 09:01:42 --> Utf8 Class Initialized
INFO - 2023-12-04 09:01:42 --> URI Class Initialized
INFO - 2023-12-04 09:01:42 --> Router Class Initialized
INFO - 2023-12-04 09:01:42 --> Output Class Initialized
INFO - 2023-12-04 09:01:42 --> Security Class Initialized
DEBUG - 2023-12-04 09:01:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-04 09:01:42 --> Input Class Initialized
INFO - 2023-12-04 09:01:42 --> Language Class Initialized
INFO - 2023-12-04 09:01:42 --> Language Class Initialized
INFO - 2023-12-04 09:01:42 --> Config Class Initialized
INFO - 2023-12-04 09:01:42 --> Loader Class Initialized
INFO - 2023-12-04 09:01:42 --> Helper loaded: url_helper
INFO - 2023-12-04 09:01:42 --> Helper loaded: file_helper
INFO - 2023-12-04 09:01:42 --> Helper loaded: form_helper
INFO - 2023-12-04 09:01:42 --> Helper loaded: my_helper
INFO - 2023-12-04 09:01:42 --> Database Driver Class Initialized
INFO - 2023-12-04 09:01:42 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-04 09:01:42 --> Controller Class Initialized
DEBUG - 2023-12-04 09:01:42 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/login/views/login.php
DEBUG - 2023-12-04 09:01:42 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-12-04 09:01:42 --> Final output sent to browser
DEBUG - 2023-12-04 09:01:42 --> Total execution time: 0.0623
INFO - 2023-12-04 09:01:48 --> Config Class Initialized
INFO - 2023-12-04 09:01:48 --> Hooks Class Initialized
DEBUG - 2023-12-04 09:01:48 --> UTF-8 Support Enabled
INFO - 2023-12-04 09:01:48 --> Utf8 Class Initialized
INFO - 2023-12-04 09:01:48 --> URI Class Initialized
INFO - 2023-12-04 09:01:48 --> Router Class Initialized
INFO - 2023-12-04 09:01:48 --> Output Class Initialized
INFO - 2023-12-04 09:01:48 --> Security Class Initialized
DEBUG - 2023-12-04 09:01:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-04 09:01:48 --> Input Class Initialized
INFO - 2023-12-04 09:01:48 --> Language Class Initialized
INFO - 2023-12-04 09:01:48 --> Language Class Initialized
INFO - 2023-12-04 09:01:48 --> Config Class Initialized
INFO - 2023-12-04 09:01:48 --> Loader Class Initialized
INFO - 2023-12-04 09:01:48 --> Helper loaded: url_helper
INFO - 2023-12-04 09:01:48 --> Helper loaded: file_helper
INFO - 2023-12-04 09:01:48 --> Helper loaded: form_helper
INFO - 2023-12-04 09:01:48 --> Helper loaded: my_helper
INFO - 2023-12-04 09:01:48 --> Database Driver Class Initialized
INFO - 2023-12-04 09:01:48 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-04 09:01:48 --> Controller Class Initialized
INFO - 2023-12-04 09:01:48 --> Helper loaded: cookie_helper
INFO - 2023-12-04 09:01:48 --> Final output sent to browser
DEBUG - 2023-12-04 09:01:48 --> Total execution time: 0.0681
INFO - 2023-12-04 09:01:48 --> Config Class Initialized
INFO - 2023-12-04 09:01:48 --> Hooks Class Initialized
DEBUG - 2023-12-04 09:01:48 --> UTF-8 Support Enabled
INFO - 2023-12-04 09:01:48 --> Utf8 Class Initialized
INFO - 2023-12-04 09:01:48 --> URI Class Initialized
INFO - 2023-12-04 09:01:48 --> Router Class Initialized
INFO - 2023-12-04 09:01:48 --> Output Class Initialized
INFO - 2023-12-04 09:01:48 --> Security Class Initialized
DEBUG - 2023-12-04 09:01:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-04 09:01:48 --> Input Class Initialized
INFO - 2023-12-04 09:01:48 --> Language Class Initialized
INFO - 2023-12-04 09:01:48 --> Language Class Initialized
INFO - 2023-12-04 09:01:48 --> Config Class Initialized
INFO - 2023-12-04 09:01:48 --> Loader Class Initialized
INFO - 2023-12-04 09:01:48 --> Helper loaded: url_helper
INFO - 2023-12-04 09:01:48 --> Helper loaded: file_helper
INFO - 2023-12-04 09:01:48 --> Helper loaded: form_helper
INFO - 2023-12-04 09:01:48 --> Helper loaded: my_helper
INFO - 2023-12-04 09:01:48 --> Database Driver Class Initialized
INFO - 2023-12-04 09:01:48 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-04 09:01:48 --> Controller Class Initialized
DEBUG - 2023-12-04 09:01:48 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/home/views/v_home_guru.php
DEBUG - 2023-12-04 09:01:48 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-12-04 09:01:48 --> Final output sent to browser
DEBUG - 2023-12-04 09:01:48 --> Total execution time: 0.0562
INFO - 2023-12-04 09:01:54 --> Config Class Initialized
INFO - 2023-12-04 09:01:54 --> Hooks Class Initialized
DEBUG - 2023-12-04 09:01:54 --> UTF-8 Support Enabled
INFO - 2023-12-04 09:01:54 --> Utf8 Class Initialized
INFO - 2023-12-04 09:01:54 --> URI Class Initialized
INFO - 2023-12-04 09:01:54 --> Router Class Initialized
INFO - 2023-12-04 09:01:54 --> Output Class Initialized
INFO - 2023-12-04 09:01:54 --> Security Class Initialized
DEBUG - 2023-12-04 09:01:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-04 09:01:54 --> Input Class Initialized
INFO - 2023-12-04 09:01:54 --> Language Class Initialized
INFO - 2023-12-04 09:01:54 --> Language Class Initialized
INFO - 2023-12-04 09:01:54 --> Config Class Initialized
INFO - 2023-12-04 09:01:54 --> Loader Class Initialized
INFO - 2023-12-04 09:01:54 --> Helper loaded: url_helper
INFO - 2023-12-04 09:01:54 --> Helper loaded: file_helper
INFO - 2023-12-04 09:01:54 --> Helper loaded: form_helper
INFO - 2023-12-04 09:01:54 --> Helper loaded: my_helper
INFO - 2023-12-04 09:01:54 --> Database Driver Class Initialized
INFO - 2023-12-04 09:01:54 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-04 09:01:54 --> Controller Class Initialized
DEBUG - 2023-12-04 09:01:54 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/view_mapel/views/v_view_mapel.php
DEBUG - 2023-12-04 09:01:54 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-12-04 09:01:54 --> Final output sent to browser
DEBUG - 2023-12-04 09:01:54 --> Total execution time: 0.0383
INFO - 2023-12-04 09:01:57 --> Config Class Initialized
INFO - 2023-12-04 09:01:57 --> Hooks Class Initialized
DEBUG - 2023-12-04 09:01:57 --> UTF-8 Support Enabled
INFO - 2023-12-04 09:01:57 --> Utf8 Class Initialized
INFO - 2023-12-04 09:01:57 --> URI Class Initialized
INFO - 2023-12-04 09:01:57 --> Router Class Initialized
INFO - 2023-12-04 09:01:57 --> Output Class Initialized
INFO - 2023-12-04 09:01:57 --> Security Class Initialized
DEBUG - 2023-12-04 09:01:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-04 09:01:57 --> Input Class Initialized
INFO - 2023-12-04 09:01:57 --> Language Class Initialized
INFO - 2023-12-04 09:01:57 --> Language Class Initialized
INFO - 2023-12-04 09:01:57 --> Config Class Initialized
INFO - 2023-12-04 09:01:57 --> Loader Class Initialized
INFO - 2023-12-04 09:01:57 --> Helper loaded: url_helper
INFO - 2023-12-04 09:01:57 --> Helper loaded: file_helper
INFO - 2023-12-04 09:01:57 --> Helper loaded: form_helper
INFO - 2023-12-04 09:01:57 --> Helper loaded: my_helper
INFO - 2023-12-04 09:01:57 --> Database Driver Class Initialized
INFO - 2023-12-04 09:01:57 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-04 09:01:57 --> Controller Class Initialized
DEBUG - 2023-12-04 09:01:57 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/views/list.php
DEBUG - 2023-12-04 09:01:57 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-12-04 09:01:57 --> Final output sent to browser
DEBUG - 2023-12-04 09:01:57 --> Total execution time: 0.0562
INFO - 2023-12-04 09:01:58 --> Config Class Initialized
INFO - 2023-12-04 09:01:58 --> Hooks Class Initialized
DEBUG - 2023-12-04 09:01:58 --> UTF-8 Support Enabled
INFO - 2023-12-04 09:01:58 --> Utf8 Class Initialized
INFO - 2023-12-04 09:01:58 --> URI Class Initialized
INFO - 2023-12-04 09:01:58 --> Router Class Initialized
INFO - 2023-12-04 09:01:58 --> Output Class Initialized
INFO - 2023-12-04 09:01:58 --> Security Class Initialized
DEBUG - 2023-12-04 09:01:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-04 09:01:58 --> Input Class Initialized
INFO - 2023-12-04 09:01:58 --> Language Class Initialized
INFO - 2023-12-04 09:01:58 --> Language Class Initialized
INFO - 2023-12-04 09:01:58 --> Config Class Initialized
INFO - 2023-12-04 09:01:58 --> Loader Class Initialized
INFO - 2023-12-04 09:01:58 --> Helper loaded: url_helper
INFO - 2023-12-04 09:01:58 --> Helper loaded: file_helper
INFO - 2023-12-04 09:01:58 --> Helper loaded: form_helper
INFO - 2023-12-04 09:01:58 --> Helper loaded: my_helper
INFO - 2023-12-04 09:01:58 --> Database Driver Class Initialized
INFO - 2023-12-04 09:01:58 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-04 09:01:58 --> Controller Class Initialized
INFO - 2023-12-04 13:30:55 --> Config Class Initialized
INFO - 2023-12-04 13:30:55 --> Hooks Class Initialized
DEBUG - 2023-12-04 13:30:55 --> UTF-8 Support Enabled
INFO - 2023-12-04 13:30:55 --> Utf8 Class Initialized
INFO - 2023-12-04 13:30:55 --> URI Class Initialized
INFO - 2023-12-04 13:30:55 --> Router Class Initialized
INFO - 2023-12-04 13:30:55 --> Output Class Initialized
INFO - 2023-12-04 13:30:55 --> Security Class Initialized
DEBUG - 2023-12-04 13:30:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-04 13:30:55 --> Input Class Initialized
INFO - 2023-12-04 13:30:55 --> Language Class Initialized
INFO - 2023-12-04 13:30:55 --> Language Class Initialized
INFO - 2023-12-04 13:30:55 --> Config Class Initialized
INFO - 2023-12-04 13:30:55 --> Loader Class Initialized
INFO - 2023-12-04 13:30:55 --> Helper loaded: url_helper
INFO - 2023-12-04 13:30:55 --> Helper loaded: file_helper
INFO - 2023-12-04 13:30:55 --> Helper loaded: form_helper
INFO - 2023-12-04 13:30:55 --> Helper loaded: my_helper
INFO - 2023-12-04 13:30:55 --> Database Driver Class Initialized
INFO - 2023-12-04 13:30:55 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-04 13:30:55 --> Controller Class Initialized
DEBUG - 2023-12-04 13:30:55 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/login/views/login.php
DEBUG - 2023-12-04 13:30:55 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-12-04 13:30:55 --> Final output sent to browser
DEBUG - 2023-12-04 13:30:55 --> Total execution time: 0.0593
INFO - 2023-12-04 13:30:59 --> Config Class Initialized
INFO - 2023-12-04 13:30:59 --> Hooks Class Initialized
DEBUG - 2023-12-04 13:30:59 --> UTF-8 Support Enabled
INFO - 2023-12-04 13:30:59 --> Utf8 Class Initialized
INFO - 2023-12-04 13:30:59 --> URI Class Initialized
INFO - 2023-12-04 13:30:59 --> Router Class Initialized
INFO - 2023-12-04 13:30:59 --> Output Class Initialized
INFO - 2023-12-04 13:30:59 --> Security Class Initialized
DEBUG - 2023-12-04 13:30:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-04 13:30:59 --> Input Class Initialized
INFO - 2023-12-04 13:30:59 --> Language Class Initialized
INFO - 2023-12-04 13:30:59 --> Language Class Initialized
INFO - 2023-12-04 13:30:59 --> Config Class Initialized
INFO - 2023-12-04 13:30:59 --> Loader Class Initialized
INFO - 2023-12-04 13:30:59 --> Helper loaded: url_helper
INFO - 2023-12-04 13:30:59 --> Helper loaded: file_helper
INFO - 2023-12-04 13:30:59 --> Helper loaded: form_helper
INFO - 2023-12-04 13:30:59 --> Helper loaded: my_helper
INFO - 2023-12-04 13:30:59 --> Database Driver Class Initialized
INFO - 2023-12-04 13:30:59 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-04 13:30:59 --> Controller Class Initialized
INFO - 2023-12-04 13:30:59 --> Helper loaded: cookie_helper
INFO - 2023-12-04 13:30:59 --> Final output sent to browser
DEBUG - 2023-12-04 13:30:59 --> Total execution time: 0.0480
INFO - 2023-12-04 13:30:59 --> Config Class Initialized
INFO - 2023-12-04 13:30:59 --> Hooks Class Initialized
DEBUG - 2023-12-04 13:30:59 --> UTF-8 Support Enabled
INFO - 2023-12-04 13:30:59 --> Utf8 Class Initialized
INFO - 2023-12-04 13:30:59 --> URI Class Initialized
INFO - 2023-12-04 13:30:59 --> Router Class Initialized
INFO - 2023-12-04 13:30:59 --> Output Class Initialized
INFO - 2023-12-04 13:30:59 --> Security Class Initialized
DEBUG - 2023-12-04 13:30:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-04 13:30:59 --> Input Class Initialized
INFO - 2023-12-04 13:30:59 --> Language Class Initialized
INFO - 2023-12-04 13:30:59 --> Language Class Initialized
INFO - 2023-12-04 13:30:59 --> Config Class Initialized
INFO - 2023-12-04 13:30:59 --> Loader Class Initialized
INFO - 2023-12-04 13:30:59 --> Helper loaded: url_helper
INFO - 2023-12-04 13:30:59 --> Helper loaded: file_helper
INFO - 2023-12-04 13:30:59 --> Helper loaded: form_helper
INFO - 2023-12-04 13:30:59 --> Helper loaded: my_helper
INFO - 2023-12-04 13:30:59 --> Database Driver Class Initialized
INFO - 2023-12-04 13:30:59 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-04 13:30:59 --> Controller Class Initialized
DEBUG - 2023-12-04 13:30:59 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/home/views/v_home.php
DEBUG - 2023-12-04 13:30:59 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-12-04 13:30:59 --> Final output sent to browser
DEBUG - 2023-12-04 13:30:59 --> Total execution time: 0.0745
INFO - 2023-12-04 13:31:01 --> Config Class Initialized
INFO - 2023-12-04 13:31:01 --> Hooks Class Initialized
DEBUG - 2023-12-04 13:31:01 --> UTF-8 Support Enabled
INFO - 2023-12-04 13:31:01 --> Utf8 Class Initialized
INFO - 2023-12-04 13:31:01 --> URI Class Initialized
INFO - 2023-12-04 13:31:01 --> Router Class Initialized
INFO - 2023-12-04 13:31:01 --> Output Class Initialized
INFO - 2023-12-04 13:31:01 --> Security Class Initialized
DEBUG - 2023-12-04 13:31:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-04 13:31:01 --> Input Class Initialized
INFO - 2023-12-04 13:31:01 --> Language Class Initialized
INFO - 2023-12-04 13:31:01 --> Language Class Initialized
INFO - 2023-12-04 13:31:01 --> Config Class Initialized
INFO - 2023-12-04 13:31:01 --> Loader Class Initialized
INFO - 2023-12-04 13:31:01 --> Helper loaded: url_helper
INFO - 2023-12-04 13:31:01 --> Helper loaded: file_helper
INFO - 2023-12-04 13:31:01 --> Helper loaded: form_helper
INFO - 2023-12-04 13:31:01 --> Helper loaded: my_helper
INFO - 2023-12-04 13:31:01 --> Database Driver Class Initialized
INFO - 2023-12-04 13:31:01 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-04 13:31:01 --> Controller Class Initialized
DEBUG - 2023-12-04 13:31:01 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/set_walikelas/views/list.php
DEBUG - 2023-12-04 13:31:01 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-12-04 13:31:01 --> Final output sent to browser
DEBUG - 2023-12-04 13:31:01 --> Total execution time: 0.0446
INFO - 2023-12-04 13:31:01 --> Config Class Initialized
INFO - 2023-12-04 13:31:01 --> Hooks Class Initialized
DEBUG - 2023-12-04 13:31:01 --> UTF-8 Support Enabled
INFO - 2023-12-04 13:31:01 --> Utf8 Class Initialized
INFO - 2023-12-04 13:31:01 --> URI Class Initialized
INFO - 2023-12-04 13:31:01 --> Router Class Initialized
INFO - 2023-12-04 13:31:01 --> Output Class Initialized
INFO - 2023-12-04 13:31:01 --> Security Class Initialized
DEBUG - 2023-12-04 13:31:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-04 13:31:01 --> Input Class Initialized
INFO - 2023-12-04 13:31:01 --> Language Class Initialized
ERROR - 2023-12-04 13:31:01 --> 404 Page Not Found: /index
INFO - 2023-12-04 13:31:01 --> Config Class Initialized
INFO - 2023-12-04 13:31:01 --> Hooks Class Initialized
DEBUG - 2023-12-04 13:31:01 --> UTF-8 Support Enabled
INFO - 2023-12-04 13:31:01 --> Utf8 Class Initialized
INFO - 2023-12-04 13:31:01 --> URI Class Initialized
INFO - 2023-12-04 13:31:01 --> Router Class Initialized
INFO - 2023-12-04 13:31:01 --> Output Class Initialized
INFO - 2023-12-04 13:31:01 --> Security Class Initialized
DEBUG - 2023-12-04 13:31:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-04 13:31:01 --> Input Class Initialized
INFO - 2023-12-04 13:31:01 --> Language Class Initialized
INFO - 2023-12-04 13:31:01 --> Language Class Initialized
INFO - 2023-12-04 13:31:01 --> Config Class Initialized
INFO - 2023-12-04 13:31:01 --> Loader Class Initialized
INFO - 2023-12-04 13:31:01 --> Helper loaded: url_helper
INFO - 2023-12-04 13:31:01 --> Helper loaded: file_helper
INFO - 2023-12-04 13:31:01 --> Helper loaded: form_helper
INFO - 2023-12-04 13:31:01 --> Helper loaded: my_helper
INFO - 2023-12-04 13:31:01 --> Database Driver Class Initialized
INFO - 2023-12-04 13:31:01 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-04 13:31:01 --> Controller Class Initialized
INFO - 2023-12-04 13:31:04 --> Config Class Initialized
INFO - 2023-12-04 13:31:04 --> Hooks Class Initialized
DEBUG - 2023-12-04 13:31:04 --> UTF-8 Support Enabled
INFO - 2023-12-04 13:31:04 --> Utf8 Class Initialized
INFO - 2023-12-04 13:31:04 --> URI Class Initialized
INFO - 2023-12-04 13:31:04 --> Router Class Initialized
INFO - 2023-12-04 13:31:04 --> Output Class Initialized
INFO - 2023-12-04 13:31:04 --> Security Class Initialized
DEBUG - 2023-12-04 13:31:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-04 13:31:04 --> Input Class Initialized
INFO - 2023-12-04 13:31:04 --> Language Class Initialized
INFO - 2023-12-04 13:31:04 --> Language Class Initialized
INFO - 2023-12-04 13:31:04 --> Config Class Initialized
INFO - 2023-12-04 13:31:04 --> Loader Class Initialized
INFO - 2023-12-04 13:31:04 --> Helper loaded: url_helper
INFO - 2023-12-04 13:31:04 --> Helper loaded: file_helper
INFO - 2023-12-04 13:31:04 --> Helper loaded: form_helper
INFO - 2023-12-04 13:31:04 --> Helper loaded: my_helper
INFO - 2023-12-04 13:31:04 --> Database Driver Class Initialized
INFO - 2023-12-04 13:31:04 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-04 13:31:04 --> Controller Class Initialized
INFO - 2023-12-04 13:31:04 --> Helper loaded: cookie_helper
INFO - 2023-12-04 13:31:04 --> Config Class Initialized
INFO - 2023-12-04 13:31:04 --> Hooks Class Initialized
DEBUG - 2023-12-04 13:31:04 --> UTF-8 Support Enabled
INFO - 2023-12-04 13:31:04 --> Utf8 Class Initialized
INFO - 2023-12-04 13:31:04 --> URI Class Initialized
INFO - 2023-12-04 13:31:04 --> Router Class Initialized
INFO - 2023-12-04 13:31:04 --> Output Class Initialized
INFO - 2023-12-04 13:31:04 --> Security Class Initialized
DEBUG - 2023-12-04 13:31:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-04 13:31:04 --> Input Class Initialized
INFO - 2023-12-04 13:31:04 --> Language Class Initialized
INFO - 2023-12-04 13:31:04 --> Language Class Initialized
INFO - 2023-12-04 13:31:04 --> Config Class Initialized
INFO - 2023-12-04 13:31:04 --> Loader Class Initialized
INFO - 2023-12-04 13:31:04 --> Helper loaded: url_helper
INFO - 2023-12-04 13:31:04 --> Helper loaded: file_helper
INFO - 2023-12-04 13:31:04 --> Helper loaded: form_helper
INFO - 2023-12-04 13:31:04 --> Helper loaded: my_helper
INFO - 2023-12-04 13:31:04 --> Database Driver Class Initialized
INFO - 2023-12-04 13:31:04 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-04 13:31:04 --> Controller Class Initialized
INFO - 2023-12-04 13:31:04 --> Config Class Initialized
INFO - 2023-12-04 13:31:04 --> Hooks Class Initialized
DEBUG - 2023-12-04 13:31:04 --> UTF-8 Support Enabled
INFO - 2023-12-04 13:31:04 --> Utf8 Class Initialized
INFO - 2023-12-04 13:31:04 --> URI Class Initialized
INFO - 2023-12-04 13:31:04 --> Router Class Initialized
INFO - 2023-12-04 13:31:04 --> Output Class Initialized
INFO - 2023-12-04 13:31:04 --> Security Class Initialized
DEBUG - 2023-12-04 13:31:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-04 13:31:04 --> Input Class Initialized
INFO - 2023-12-04 13:31:04 --> Language Class Initialized
INFO - 2023-12-04 13:31:04 --> Language Class Initialized
INFO - 2023-12-04 13:31:04 --> Config Class Initialized
INFO - 2023-12-04 13:31:04 --> Loader Class Initialized
INFO - 2023-12-04 13:31:04 --> Helper loaded: url_helper
INFO - 2023-12-04 13:31:04 --> Helper loaded: file_helper
INFO - 2023-12-04 13:31:04 --> Helper loaded: form_helper
INFO - 2023-12-04 13:31:04 --> Helper loaded: my_helper
INFO - 2023-12-04 13:31:04 --> Database Driver Class Initialized
INFO - 2023-12-04 13:31:04 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-04 13:31:04 --> Controller Class Initialized
DEBUG - 2023-12-04 13:31:04 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/login/views/login.php
DEBUG - 2023-12-04 13:31:04 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-12-04 13:31:04 --> Final output sent to browser
DEBUG - 2023-12-04 13:31:04 --> Total execution time: 0.0359
INFO - 2023-12-04 13:31:08 --> Config Class Initialized
INFO - 2023-12-04 13:31:08 --> Hooks Class Initialized
DEBUG - 2023-12-04 13:31:08 --> UTF-8 Support Enabled
INFO - 2023-12-04 13:31:08 --> Utf8 Class Initialized
INFO - 2023-12-04 13:31:08 --> URI Class Initialized
INFO - 2023-12-04 13:31:08 --> Router Class Initialized
INFO - 2023-12-04 13:31:08 --> Output Class Initialized
INFO - 2023-12-04 13:31:08 --> Security Class Initialized
DEBUG - 2023-12-04 13:31:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-04 13:31:08 --> Input Class Initialized
INFO - 2023-12-04 13:31:08 --> Language Class Initialized
INFO - 2023-12-04 13:31:08 --> Language Class Initialized
INFO - 2023-12-04 13:31:08 --> Config Class Initialized
INFO - 2023-12-04 13:31:08 --> Loader Class Initialized
INFO - 2023-12-04 13:31:08 --> Helper loaded: url_helper
INFO - 2023-12-04 13:31:08 --> Helper loaded: file_helper
INFO - 2023-12-04 13:31:08 --> Helper loaded: form_helper
INFO - 2023-12-04 13:31:08 --> Helper loaded: my_helper
INFO - 2023-12-04 13:31:08 --> Database Driver Class Initialized
INFO - 2023-12-04 13:31:08 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-04 13:31:08 --> Controller Class Initialized
INFO - 2023-12-04 13:31:08 --> Helper loaded: cookie_helper
INFO - 2023-12-04 13:31:08 --> Final output sent to browser
DEBUG - 2023-12-04 13:31:08 --> Total execution time: 0.0875
INFO - 2023-12-04 13:31:08 --> Config Class Initialized
INFO - 2023-12-04 13:31:08 --> Hooks Class Initialized
DEBUG - 2023-12-04 13:31:08 --> UTF-8 Support Enabled
INFO - 2023-12-04 13:31:08 --> Utf8 Class Initialized
INFO - 2023-12-04 13:31:08 --> URI Class Initialized
INFO - 2023-12-04 13:31:08 --> Router Class Initialized
INFO - 2023-12-04 13:31:08 --> Output Class Initialized
INFO - 2023-12-04 13:31:08 --> Security Class Initialized
DEBUG - 2023-12-04 13:31:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-04 13:31:08 --> Input Class Initialized
INFO - 2023-12-04 13:31:08 --> Language Class Initialized
INFO - 2023-12-04 13:31:08 --> Language Class Initialized
INFO - 2023-12-04 13:31:08 --> Config Class Initialized
INFO - 2023-12-04 13:31:08 --> Loader Class Initialized
INFO - 2023-12-04 13:31:08 --> Helper loaded: url_helper
INFO - 2023-12-04 13:31:08 --> Helper loaded: file_helper
INFO - 2023-12-04 13:31:08 --> Helper loaded: form_helper
INFO - 2023-12-04 13:31:08 --> Helper loaded: my_helper
INFO - 2023-12-04 13:31:08 --> Database Driver Class Initialized
INFO - 2023-12-04 13:31:08 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-04 13:31:08 --> Controller Class Initialized
DEBUG - 2023-12-04 13:31:08 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/home/views/v_home_guru.php
DEBUG - 2023-12-04 13:31:08 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-12-04 13:31:08 --> Final output sent to browser
DEBUG - 2023-12-04 13:31:08 --> Total execution time: 0.0617
INFO - 2023-12-04 13:31:11 --> Config Class Initialized
INFO - 2023-12-04 13:31:11 --> Hooks Class Initialized
DEBUG - 2023-12-04 13:31:11 --> UTF-8 Support Enabled
INFO - 2023-12-04 13:31:11 --> Utf8 Class Initialized
INFO - 2023-12-04 13:31:11 --> URI Class Initialized
INFO - 2023-12-04 13:31:11 --> Router Class Initialized
INFO - 2023-12-04 13:31:11 --> Output Class Initialized
INFO - 2023-12-04 13:31:11 --> Security Class Initialized
DEBUG - 2023-12-04 13:31:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-04 13:31:11 --> Input Class Initialized
INFO - 2023-12-04 13:31:11 --> Language Class Initialized
INFO - 2023-12-04 13:31:11 --> Language Class Initialized
INFO - 2023-12-04 13:31:11 --> Config Class Initialized
INFO - 2023-12-04 13:31:11 --> Loader Class Initialized
INFO - 2023-12-04 13:31:11 --> Helper loaded: url_helper
INFO - 2023-12-04 13:31:11 --> Helper loaded: file_helper
INFO - 2023-12-04 13:31:11 --> Helper loaded: form_helper
INFO - 2023-12-04 13:31:11 --> Helper loaded: my_helper
INFO - 2023-12-04 13:31:11 --> Database Driver Class Initialized
INFO - 2023-12-04 13:31:11 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-04 13:31:11 --> Controller Class Initialized
DEBUG - 2023-12-04 13:31:11 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/views/list.php
DEBUG - 2023-12-04 13:31:11 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-12-04 13:31:11 --> Final output sent to browser
DEBUG - 2023-12-04 13:31:11 --> Total execution time: 0.0609
INFO - 2023-12-04 13:31:13 --> Config Class Initialized
INFO - 2023-12-04 13:31:13 --> Hooks Class Initialized
DEBUG - 2023-12-04 13:31:13 --> UTF-8 Support Enabled
INFO - 2023-12-04 13:31:13 --> Utf8 Class Initialized
INFO - 2023-12-04 13:31:13 --> URI Class Initialized
INFO - 2023-12-04 13:31:13 --> Router Class Initialized
INFO - 2023-12-04 13:31:13 --> Output Class Initialized
INFO - 2023-12-04 13:31:13 --> Security Class Initialized
DEBUG - 2023-12-04 13:31:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-04 13:31:13 --> Input Class Initialized
INFO - 2023-12-04 13:31:13 --> Language Class Initialized
INFO - 2023-12-04 13:31:13 --> Language Class Initialized
INFO - 2023-12-04 13:31:13 --> Config Class Initialized
INFO - 2023-12-04 13:31:13 --> Loader Class Initialized
INFO - 2023-12-04 13:31:13 --> Helper loaded: url_helper
INFO - 2023-12-04 13:31:13 --> Helper loaded: file_helper
INFO - 2023-12-04 13:31:13 --> Helper loaded: form_helper
INFO - 2023-12-04 13:31:13 --> Helper loaded: my_helper
INFO - 2023-12-04 13:31:13 --> Database Driver Class Initialized
INFO - 2023-12-04 13:31:13 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-04 13:31:13 --> Controller Class Initialized
DEBUG - 2023-12-04 13:31:13 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/views/cetak_ikm.php
INFO - 2023-12-04 13:31:16 --> Final output sent to browser
DEBUG - 2023-12-04 13:31:16 --> Total execution time: 2.4754
INFO - 2023-12-04 13:45:34 --> Config Class Initialized
INFO - 2023-12-04 13:45:34 --> Hooks Class Initialized
DEBUG - 2023-12-04 13:45:34 --> UTF-8 Support Enabled
INFO - 2023-12-04 13:45:34 --> Utf8 Class Initialized
INFO - 2023-12-04 13:45:34 --> URI Class Initialized
DEBUG - 2023-12-04 13:45:34 --> No URI present. Default controller set.
INFO - 2023-12-04 13:45:34 --> Router Class Initialized
INFO - 2023-12-04 13:45:34 --> Output Class Initialized
INFO - 2023-12-04 13:45:34 --> Security Class Initialized
DEBUG - 2023-12-04 13:45:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-04 13:45:34 --> Input Class Initialized
INFO - 2023-12-04 13:45:34 --> Language Class Initialized
INFO - 2023-12-04 13:45:34 --> Language Class Initialized
INFO - 2023-12-04 13:45:34 --> Config Class Initialized
INFO - 2023-12-04 13:45:34 --> Loader Class Initialized
INFO - 2023-12-04 13:45:34 --> Helper loaded: url_helper
INFO - 2023-12-04 13:45:34 --> Helper loaded: file_helper
INFO - 2023-12-04 13:45:34 --> Helper loaded: form_helper
INFO - 2023-12-04 13:45:34 --> Helper loaded: my_helper
INFO - 2023-12-04 13:45:34 --> Database Driver Class Initialized
INFO - 2023-12-04 13:45:34 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-04 13:45:34 --> Controller Class Initialized
INFO - 2023-12-04 13:45:34 --> Config Class Initialized
INFO - 2023-12-04 13:45:34 --> Hooks Class Initialized
DEBUG - 2023-12-04 13:45:34 --> UTF-8 Support Enabled
INFO - 2023-12-04 13:45:34 --> Utf8 Class Initialized
INFO - 2023-12-04 13:45:34 --> URI Class Initialized
INFO - 2023-12-04 13:45:34 --> Router Class Initialized
INFO - 2023-12-04 13:45:34 --> Output Class Initialized
INFO - 2023-12-04 13:45:34 --> Security Class Initialized
DEBUG - 2023-12-04 13:45:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-04 13:45:34 --> Input Class Initialized
INFO - 2023-12-04 13:45:34 --> Language Class Initialized
INFO - 2023-12-04 13:45:34 --> Language Class Initialized
INFO - 2023-12-04 13:45:34 --> Config Class Initialized
INFO - 2023-12-04 13:45:34 --> Loader Class Initialized
INFO - 2023-12-04 13:45:34 --> Helper loaded: url_helper
INFO - 2023-12-04 13:45:34 --> Helper loaded: file_helper
INFO - 2023-12-04 13:45:34 --> Helper loaded: form_helper
INFO - 2023-12-04 13:45:34 --> Helper loaded: my_helper
INFO - 2023-12-04 13:45:34 --> Database Driver Class Initialized
INFO - 2023-12-04 13:45:34 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-04 13:45:34 --> Controller Class Initialized
DEBUG - 2023-12-04 13:45:34 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/login/views/login.php
DEBUG - 2023-12-04 13:45:34 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-12-04 13:45:34 --> Final output sent to browser
DEBUG - 2023-12-04 13:45:34 --> Total execution time: 0.0408
INFO - 2023-12-04 13:45:38 --> Config Class Initialized
INFO - 2023-12-04 13:45:38 --> Hooks Class Initialized
DEBUG - 2023-12-04 13:45:38 --> UTF-8 Support Enabled
INFO - 2023-12-04 13:45:38 --> Utf8 Class Initialized
INFO - 2023-12-04 13:45:38 --> URI Class Initialized
INFO - 2023-12-04 13:45:38 --> Router Class Initialized
INFO - 2023-12-04 13:45:38 --> Output Class Initialized
INFO - 2023-12-04 13:45:38 --> Security Class Initialized
DEBUG - 2023-12-04 13:45:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-04 13:45:38 --> Input Class Initialized
INFO - 2023-12-04 13:45:38 --> Language Class Initialized
INFO - 2023-12-04 13:45:38 --> Language Class Initialized
INFO - 2023-12-04 13:45:38 --> Config Class Initialized
INFO - 2023-12-04 13:45:38 --> Loader Class Initialized
INFO - 2023-12-04 13:45:38 --> Helper loaded: url_helper
INFO - 2023-12-04 13:45:38 --> Helper loaded: file_helper
INFO - 2023-12-04 13:45:38 --> Helper loaded: form_helper
INFO - 2023-12-04 13:45:38 --> Helper loaded: my_helper
INFO - 2023-12-04 13:45:38 --> Database Driver Class Initialized
INFO - 2023-12-04 13:45:38 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-04 13:45:38 --> Controller Class Initialized
INFO - 2023-12-04 13:45:38 --> Helper loaded: cookie_helper
INFO - 2023-12-04 13:45:38 --> Final output sent to browser
DEBUG - 2023-12-04 13:45:38 --> Total execution time: 0.0442
INFO - 2023-12-04 13:45:38 --> Config Class Initialized
INFO - 2023-12-04 13:45:38 --> Hooks Class Initialized
DEBUG - 2023-12-04 13:45:38 --> UTF-8 Support Enabled
INFO - 2023-12-04 13:45:38 --> Utf8 Class Initialized
INFO - 2023-12-04 13:45:38 --> URI Class Initialized
INFO - 2023-12-04 13:45:38 --> Router Class Initialized
INFO - 2023-12-04 13:45:38 --> Output Class Initialized
INFO - 2023-12-04 13:45:38 --> Security Class Initialized
DEBUG - 2023-12-04 13:45:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-04 13:45:38 --> Input Class Initialized
INFO - 2023-12-04 13:45:38 --> Language Class Initialized
INFO - 2023-12-04 13:45:38 --> Language Class Initialized
INFO - 2023-12-04 13:45:38 --> Config Class Initialized
INFO - 2023-12-04 13:45:38 --> Loader Class Initialized
INFO - 2023-12-04 13:45:38 --> Helper loaded: url_helper
INFO - 2023-12-04 13:45:38 --> Helper loaded: file_helper
INFO - 2023-12-04 13:45:38 --> Helper loaded: form_helper
INFO - 2023-12-04 13:45:38 --> Helper loaded: my_helper
INFO - 2023-12-04 13:45:38 --> Database Driver Class Initialized
INFO - 2023-12-04 13:45:38 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-04 13:45:38 --> Controller Class Initialized
DEBUG - 2023-12-04 13:45:38 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/home/views/v_home.php
DEBUG - 2023-12-04 13:45:38 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-12-04 13:45:38 --> Final output sent to browser
DEBUG - 2023-12-04 13:45:38 --> Total execution time: 0.0707
INFO - 2023-12-04 13:50:43 --> Config Class Initialized
INFO - 2023-12-04 13:50:43 --> Hooks Class Initialized
DEBUG - 2023-12-04 13:50:43 --> UTF-8 Support Enabled
INFO - 2023-12-04 13:50:43 --> Utf8 Class Initialized
INFO - 2023-12-04 13:50:43 --> URI Class Initialized
INFO - 2023-12-04 13:50:43 --> Router Class Initialized
INFO - 2023-12-04 13:50:43 --> Output Class Initialized
INFO - 2023-12-04 13:50:43 --> Security Class Initialized
DEBUG - 2023-12-04 13:50:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-04 13:50:43 --> Input Class Initialized
INFO - 2023-12-04 13:50:43 --> Language Class Initialized
INFO - 2023-12-04 13:50:43 --> Language Class Initialized
INFO - 2023-12-04 13:50:43 --> Config Class Initialized
INFO - 2023-12-04 13:50:43 --> Loader Class Initialized
INFO - 2023-12-04 13:50:43 --> Helper loaded: url_helper
INFO - 2023-12-04 13:50:43 --> Helper loaded: file_helper
INFO - 2023-12-04 13:50:43 --> Helper loaded: form_helper
INFO - 2023-12-04 13:50:43 --> Helper loaded: my_helper
INFO - 2023-12-04 13:50:43 --> Database Driver Class Initialized
INFO - 2023-12-04 13:50:43 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-04 13:50:43 --> Controller Class Initialized
DEBUG - 2023-12-04 13:50:43 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/home/views/v_home.php
DEBUG - 2023-12-04 13:50:43 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-12-04 13:50:43 --> Final output sent to browser
DEBUG - 2023-12-04 13:50:43 --> Total execution time: 0.1580
INFO - 2023-12-04 13:50:45 --> Config Class Initialized
INFO - 2023-12-04 13:50:45 --> Hooks Class Initialized
DEBUG - 2023-12-04 13:50:45 --> UTF-8 Support Enabled
INFO - 2023-12-04 13:50:45 --> Utf8 Class Initialized
INFO - 2023-12-04 13:50:45 --> URI Class Initialized
INFO - 2023-12-04 13:50:45 --> Router Class Initialized
INFO - 2023-12-04 13:50:45 --> Output Class Initialized
INFO - 2023-12-04 13:50:45 --> Security Class Initialized
DEBUG - 2023-12-04 13:50:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-04 13:50:45 --> Input Class Initialized
INFO - 2023-12-04 13:50:45 --> Language Class Initialized
INFO - 2023-12-04 13:50:45 --> Language Class Initialized
INFO - 2023-12-04 13:50:45 --> Config Class Initialized
INFO - 2023-12-04 13:50:45 --> Loader Class Initialized
INFO - 2023-12-04 13:50:45 --> Helper loaded: url_helper
INFO - 2023-12-04 13:50:45 --> Helper loaded: file_helper
INFO - 2023-12-04 13:50:45 --> Helper loaded: form_helper
INFO - 2023-12-04 13:50:45 --> Helper loaded: my_helper
INFO - 2023-12-04 13:50:45 --> Database Driver Class Initialized
INFO - 2023-12-04 13:50:45 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-04 13:50:45 --> Controller Class Initialized
DEBUG - 2023-12-04 13:50:45 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/data_projek/views/list.php
DEBUG - 2023-12-04 13:50:45 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-12-04 13:50:45 --> Final output sent to browser
DEBUG - 2023-12-04 13:50:45 --> Total execution time: 0.0440
INFO - 2023-12-04 13:50:45 --> Config Class Initialized
INFO - 2023-12-04 13:50:45 --> Hooks Class Initialized
DEBUG - 2023-12-04 13:50:45 --> UTF-8 Support Enabled
INFO - 2023-12-04 13:50:45 --> Utf8 Class Initialized
INFO - 2023-12-04 13:50:46 --> URI Class Initialized
INFO - 2023-12-04 13:50:46 --> Router Class Initialized
INFO - 2023-12-04 13:50:46 --> Output Class Initialized
INFO - 2023-12-04 13:50:46 --> Security Class Initialized
DEBUG - 2023-12-04 13:50:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-04 13:50:46 --> Input Class Initialized
INFO - 2023-12-04 13:50:46 --> Language Class Initialized
ERROR - 2023-12-04 13:50:46 --> 404 Page Not Found: /index
INFO - 2023-12-04 13:50:46 --> Config Class Initialized
INFO - 2023-12-04 13:50:46 --> Hooks Class Initialized
DEBUG - 2023-12-04 13:50:46 --> UTF-8 Support Enabled
INFO - 2023-12-04 13:50:46 --> Utf8 Class Initialized
INFO - 2023-12-04 13:50:46 --> URI Class Initialized
INFO - 2023-12-04 13:50:46 --> Router Class Initialized
INFO - 2023-12-04 13:50:46 --> Output Class Initialized
INFO - 2023-12-04 13:50:46 --> Security Class Initialized
DEBUG - 2023-12-04 13:50:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-04 13:50:46 --> Input Class Initialized
INFO - 2023-12-04 13:50:46 --> Language Class Initialized
INFO - 2023-12-04 13:50:46 --> Language Class Initialized
INFO - 2023-12-04 13:50:46 --> Config Class Initialized
INFO - 2023-12-04 13:50:46 --> Loader Class Initialized
INFO - 2023-12-04 13:50:46 --> Helper loaded: url_helper
INFO - 2023-12-04 13:50:46 --> Helper loaded: file_helper
INFO - 2023-12-04 13:50:46 --> Helper loaded: form_helper
INFO - 2023-12-04 13:50:46 --> Helper loaded: my_helper
INFO - 2023-12-04 13:50:46 --> Database Driver Class Initialized
INFO - 2023-12-04 13:50:46 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-04 13:50:46 --> Controller Class Initialized
INFO - 2023-12-04 13:50:47 --> Config Class Initialized
INFO - 2023-12-04 13:50:47 --> Hooks Class Initialized
DEBUG - 2023-12-04 13:50:47 --> UTF-8 Support Enabled
INFO - 2023-12-04 13:50:47 --> Utf8 Class Initialized
INFO - 2023-12-04 13:50:47 --> URI Class Initialized
INFO - 2023-12-04 13:50:47 --> Router Class Initialized
INFO - 2023-12-04 13:50:47 --> Output Class Initialized
INFO - 2023-12-04 13:50:47 --> Security Class Initialized
DEBUG - 2023-12-04 13:50:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-04 13:50:47 --> Input Class Initialized
INFO - 2023-12-04 13:50:47 --> Language Class Initialized
INFO - 2023-12-04 13:50:47 --> Language Class Initialized
INFO - 2023-12-04 13:50:47 --> Config Class Initialized
INFO - 2023-12-04 13:50:47 --> Loader Class Initialized
INFO - 2023-12-04 13:50:47 --> Helper loaded: url_helper
INFO - 2023-12-04 13:50:47 --> Helper loaded: file_helper
INFO - 2023-12-04 13:50:47 --> Helper loaded: form_helper
INFO - 2023-12-04 13:50:47 --> Helper loaded: my_helper
INFO - 2023-12-04 13:50:47 --> Database Driver Class Initialized
INFO - 2023-12-04 13:50:47 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-04 13:50:47 --> Controller Class Initialized
DEBUG - 2023-12-04 13:50:47 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/data_kelompok/views/list.php
DEBUG - 2023-12-04 13:50:47 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-12-04 13:50:47 --> Final output sent to browser
DEBUG - 2023-12-04 13:50:47 --> Total execution time: 0.0835
INFO - 2023-12-04 13:50:47 --> Config Class Initialized
INFO - 2023-12-04 13:50:47 --> Hooks Class Initialized
DEBUG - 2023-12-04 13:50:47 --> UTF-8 Support Enabled
INFO - 2023-12-04 13:50:47 --> Utf8 Class Initialized
INFO - 2023-12-04 13:50:47 --> URI Class Initialized
INFO - 2023-12-04 13:50:47 --> Router Class Initialized
INFO - 2023-12-04 13:50:47 --> Output Class Initialized
INFO - 2023-12-04 13:50:47 --> Security Class Initialized
DEBUG - 2023-12-04 13:50:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-04 13:50:47 --> Input Class Initialized
INFO - 2023-12-04 13:50:47 --> Language Class Initialized
ERROR - 2023-12-04 13:50:47 --> 404 Page Not Found: /index
INFO - 2023-12-04 13:50:47 --> Config Class Initialized
INFO - 2023-12-04 13:50:47 --> Hooks Class Initialized
DEBUG - 2023-12-04 13:50:47 --> UTF-8 Support Enabled
INFO - 2023-12-04 13:50:47 --> Utf8 Class Initialized
INFO - 2023-12-04 13:50:47 --> URI Class Initialized
INFO - 2023-12-04 13:50:47 --> Router Class Initialized
INFO - 2023-12-04 13:50:47 --> Output Class Initialized
INFO - 2023-12-04 13:50:47 --> Security Class Initialized
DEBUG - 2023-12-04 13:50:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-04 13:50:47 --> Input Class Initialized
INFO - 2023-12-04 13:50:47 --> Language Class Initialized
INFO - 2023-12-04 13:50:47 --> Language Class Initialized
INFO - 2023-12-04 13:50:47 --> Config Class Initialized
INFO - 2023-12-04 13:50:47 --> Loader Class Initialized
INFO - 2023-12-04 13:50:47 --> Helper loaded: url_helper
INFO - 2023-12-04 13:50:47 --> Helper loaded: file_helper
INFO - 2023-12-04 13:50:47 --> Helper loaded: form_helper
INFO - 2023-12-04 13:50:47 --> Helper loaded: my_helper
INFO - 2023-12-04 13:50:47 --> Database Driver Class Initialized
INFO - 2023-12-04 13:50:47 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-04 13:50:47 --> Controller Class Initialized
INFO - 2023-12-04 13:50:49 --> Config Class Initialized
INFO - 2023-12-04 13:50:49 --> Hooks Class Initialized
DEBUG - 2023-12-04 13:50:49 --> UTF-8 Support Enabled
INFO - 2023-12-04 13:50:49 --> Utf8 Class Initialized
INFO - 2023-12-04 13:50:49 --> URI Class Initialized
INFO - 2023-12-04 13:50:49 --> Router Class Initialized
INFO - 2023-12-04 13:50:49 --> Output Class Initialized
INFO - 2023-12-04 13:50:49 --> Security Class Initialized
DEBUG - 2023-12-04 13:50:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-04 13:50:49 --> Input Class Initialized
INFO - 2023-12-04 13:50:49 --> Language Class Initialized
INFO - 2023-12-04 13:50:49 --> Language Class Initialized
INFO - 2023-12-04 13:50:49 --> Config Class Initialized
INFO - 2023-12-04 13:50:49 --> Loader Class Initialized
INFO - 2023-12-04 13:50:49 --> Helper loaded: url_helper
INFO - 2023-12-04 13:50:49 --> Helper loaded: file_helper
INFO - 2023-12-04 13:50:49 --> Helper loaded: form_helper
INFO - 2023-12-04 13:50:49 --> Helper loaded: my_helper
INFO - 2023-12-04 13:50:49 --> Database Driver Class Initialized
INFO - 2023-12-04 13:50:49 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-04 13:50:49 --> Controller Class Initialized
DEBUG - 2023-12-04 13:50:49 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/set_kelompok/views/list.php
DEBUG - 2023-12-04 13:50:49 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-12-04 13:50:49 --> Final output sent to browser
DEBUG - 2023-12-04 13:50:49 --> Total execution time: 0.0694
INFO - 2023-12-04 13:50:49 --> Config Class Initialized
INFO - 2023-12-04 13:50:49 --> Hooks Class Initialized
DEBUG - 2023-12-04 13:50:49 --> UTF-8 Support Enabled
INFO - 2023-12-04 13:50:49 --> Utf8 Class Initialized
INFO - 2023-12-04 13:50:49 --> URI Class Initialized
INFO - 2023-12-04 13:50:49 --> Router Class Initialized
INFO - 2023-12-04 13:50:49 --> Output Class Initialized
INFO - 2023-12-04 13:50:49 --> Security Class Initialized
DEBUG - 2023-12-04 13:50:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-04 13:50:49 --> Input Class Initialized
INFO - 2023-12-04 13:50:49 --> Language Class Initialized
ERROR - 2023-12-04 13:50:49 --> 404 Page Not Found: /index
INFO - 2023-12-04 13:50:49 --> Config Class Initialized
INFO - 2023-12-04 13:50:49 --> Hooks Class Initialized
DEBUG - 2023-12-04 13:50:49 --> UTF-8 Support Enabled
INFO - 2023-12-04 13:50:49 --> Utf8 Class Initialized
INFO - 2023-12-04 13:50:49 --> URI Class Initialized
INFO - 2023-12-04 13:50:49 --> Router Class Initialized
INFO - 2023-12-04 13:50:49 --> Output Class Initialized
INFO - 2023-12-04 13:50:49 --> Security Class Initialized
DEBUG - 2023-12-04 13:50:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-04 13:50:49 --> Input Class Initialized
INFO - 2023-12-04 13:50:49 --> Language Class Initialized
INFO - 2023-12-04 13:50:49 --> Language Class Initialized
INFO - 2023-12-04 13:50:49 --> Config Class Initialized
INFO - 2023-12-04 13:50:49 --> Loader Class Initialized
INFO - 2023-12-04 13:50:49 --> Helper loaded: url_helper
INFO - 2023-12-04 13:50:49 --> Helper loaded: file_helper
INFO - 2023-12-04 13:50:49 --> Helper loaded: form_helper
INFO - 2023-12-04 13:50:49 --> Helper loaded: my_helper
INFO - 2023-12-04 13:50:49 --> Database Driver Class Initialized
INFO - 2023-12-04 13:50:49 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-04 13:50:49 --> Controller Class Initialized
INFO - 2023-12-04 13:50:50 --> Config Class Initialized
INFO - 2023-12-04 13:50:50 --> Hooks Class Initialized
DEBUG - 2023-12-04 13:50:50 --> UTF-8 Support Enabled
INFO - 2023-12-04 13:50:50 --> Utf8 Class Initialized
INFO - 2023-12-04 13:50:50 --> URI Class Initialized
INFO - 2023-12-04 13:50:50 --> Router Class Initialized
INFO - 2023-12-04 13:50:50 --> Output Class Initialized
INFO - 2023-12-04 13:50:50 --> Security Class Initialized
DEBUG - 2023-12-04 13:50:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-04 13:50:50 --> Input Class Initialized
INFO - 2023-12-04 13:50:50 --> Language Class Initialized
INFO - 2023-12-04 13:50:50 --> Language Class Initialized
INFO - 2023-12-04 13:50:50 --> Config Class Initialized
INFO - 2023-12-04 13:50:50 --> Loader Class Initialized
INFO - 2023-12-04 13:50:50 --> Helper loaded: url_helper
INFO - 2023-12-04 13:50:50 --> Helper loaded: file_helper
INFO - 2023-12-04 13:50:50 --> Helper loaded: form_helper
INFO - 2023-12-04 13:50:50 --> Helper loaded: my_helper
INFO - 2023-12-04 13:50:50 --> Database Driver Class Initialized
INFO - 2023-12-04 13:50:50 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-04 13:50:50 --> Controller Class Initialized
DEBUG - 2023-12-04 13:50:50 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/data_projek/views/list.php
DEBUG - 2023-12-04 13:50:50 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-12-04 13:50:50 --> Final output sent to browser
DEBUG - 2023-12-04 13:50:50 --> Total execution time: 0.0427
INFO - 2023-12-04 13:50:50 --> Config Class Initialized
INFO - 2023-12-04 13:50:50 --> Hooks Class Initialized
DEBUG - 2023-12-04 13:50:50 --> UTF-8 Support Enabled
INFO - 2023-12-04 13:50:50 --> Utf8 Class Initialized
INFO - 2023-12-04 13:50:50 --> URI Class Initialized
INFO - 2023-12-04 13:50:50 --> Router Class Initialized
INFO - 2023-12-04 13:50:50 --> Output Class Initialized
INFO - 2023-12-04 13:50:50 --> Security Class Initialized
DEBUG - 2023-12-04 13:50:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-04 13:50:50 --> Input Class Initialized
INFO - 2023-12-04 13:50:50 --> Language Class Initialized
ERROR - 2023-12-04 13:50:50 --> 404 Page Not Found: /index
INFO - 2023-12-04 13:50:50 --> Config Class Initialized
INFO - 2023-12-04 13:50:50 --> Hooks Class Initialized
DEBUG - 2023-12-04 13:50:50 --> UTF-8 Support Enabled
INFO - 2023-12-04 13:50:50 --> Utf8 Class Initialized
INFO - 2023-12-04 13:50:50 --> URI Class Initialized
INFO - 2023-12-04 13:50:50 --> Router Class Initialized
INFO - 2023-12-04 13:50:50 --> Output Class Initialized
INFO - 2023-12-04 13:50:50 --> Security Class Initialized
DEBUG - 2023-12-04 13:50:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-04 13:50:50 --> Input Class Initialized
INFO - 2023-12-04 13:50:50 --> Language Class Initialized
INFO - 2023-12-04 13:50:50 --> Language Class Initialized
INFO - 2023-12-04 13:50:50 --> Config Class Initialized
INFO - 2023-12-04 13:50:50 --> Loader Class Initialized
INFO - 2023-12-04 13:50:50 --> Helper loaded: url_helper
INFO - 2023-12-04 13:50:50 --> Helper loaded: file_helper
INFO - 2023-12-04 13:50:50 --> Helper loaded: form_helper
INFO - 2023-12-04 13:50:50 --> Helper loaded: my_helper
INFO - 2023-12-04 13:50:50 --> Database Driver Class Initialized
INFO - 2023-12-04 13:50:50 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-04 13:50:50 --> Controller Class Initialized
INFO - 2023-12-04 13:50:51 --> Config Class Initialized
INFO - 2023-12-04 13:50:51 --> Hooks Class Initialized
DEBUG - 2023-12-04 13:50:51 --> UTF-8 Support Enabled
INFO - 2023-12-04 13:50:51 --> Utf8 Class Initialized
INFO - 2023-12-04 13:50:51 --> URI Class Initialized
INFO - 2023-12-04 13:50:51 --> Router Class Initialized
INFO - 2023-12-04 13:50:51 --> Output Class Initialized
INFO - 2023-12-04 13:50:51 --> Security Class Initialized
DEBUG - 2023-12-04 13:50:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-04 13:50:51 --> Input Class Initialized
INFO - 2023-12-04 13:50:51 --> Language Class Initialized
INFO - 2023-12-04 13:50:51 --> Language Class Initialized
INFO - 2023-12-04 13:50:51 --> Config Class Initialized
INFO - 2023-12-04 13:50:51 --> Loader Class Initialized
INFO - 2023-12-04 13:50:51 --> Helper loaded: url_helper
INFO - 2023-12-04 13:50:51 --> Helper loaded: file_helper
INFO - 2023-12-04 13:50:51 --> Helper loaded: form_helper
INFO - 2023-12-04 13:50:51 --> Helper loaded: my_helper
INFO - 2023-12-04 13:50:51 --> Database Driver Class Initialized
INFO - 2023-12-04 13:50:51 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-04 13:50:51 --> Controller Class Initialized
INFO - 2023-12-04 13:50:51 --> Final output sent to browser
DEBUG - 2023-12-04 13:50:51 --> Total execution time: 0.1087
INFO - 2023-12-04 13:53:16 --> Config Class Initialized
INFO - 2023-12-04 13:53:16 --> Hooks Class Initialized
DEBUG - 2023-12-04 13:53:16 --> UTF-8 Support Enabled
INFO - 2023-12-04 13:53:16 --> Utf8 Class Initialized
INFO - 2023-12-04 13:53:16 --> URI Class Initialized
INFO - 2023-12-04 13:53:16 --> Router Class Initialized
INFO - 2023-12-04 13:53:16 --> Output Class Initialized
INFO - 2023-12-04 13:53:16 --> Security Class Initialized
DEBUG - 2023-12-04 13:53:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-04 13:53:16 --> Input Class Initialized
INFO - 2023-12-04 13:53:16 --> Language Class Initialized
INFO - 2023-12-04 13:53:16 --> Language Class Initialized
INFO - 2023-12-04 13:53:16 --> Config Class Initialized
INFO - 2023-12-04 13:53:16 --> Loader Class Initialized
INFO - 2023-12-04 13:53:16 --> Helper loaded: url_helper
INFO - 2023-12-04 13:53:16 --> Helper loaded: file_helper
INFO - 2023-12-04 13:53:16 --> Helper loaded: form_helper
INFO - 2023-12-04 13:53:16 --> Helper loaded: my_helper
INFO - 2023-12-04 13:53:16 --> Database Driver Class Initialized
INFO - 2023-12-04 13:53:16 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-04 13:53:16 --> Controller Class Initialized
DEBUG - 2023-12-04 13:53:16 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/data_projek/views/list.php
DEBUG - 2023-12-04 13:53:16 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-12-04 13:53:16 --> Final output sent to browser
DEBUG - 2023-12-04 13:53:16 --> Total execution time: 0.0594
INFO - 2023-12-04 13:53:16 --> Config Class Initialized
INFO - 2023-12-04 13:53:16 --> Hooks Class Initialized
DEBUG - 2023-12-04 13:53:16 --> UTF-8 Support Enabled
INFO - 2023-12-04 13:53:16 --> Utf8 Class Initialized
INFO - 2023-12-04 13:53:16 --> URI Class Initialized
INFO - 2023-12-04 13:53:16 --> Router Class Initialized
INFO - 2023-12-04 13:53:16 --> Output Class Initialized
INFO - 2023-12-04 13:53:16 --> Security Class Initialized
DEBUG - 2023-12-04 13:53:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-04 13:53:16 --> Input Class Initialized
INFO - 2023-12-04 13:53:16 --> Language Class Initialized
ERROR - 2023-12-04 13:53:16 --> 404 Page Not Found: /index
INFO - 2023-12-04 13:53:16 --> Config Class Initialized
INFO - 2023-12-04 13:53:16 --> Hooks Class Initialized
DEBUG - 2023-12-04 13:53:16 --> UTF-8 Support Enabled
INFO - 2023-12-04 13:53:16 --> Utf8 Class Initialized
INFO - 2023-12-04 13:53:16 --> URI Class Initialized
INFO - 2023-12-04 13:53:16 --> Router Class Initialized
INFO - 2023-12-04 13:53:16 --> Output Class Initialized
INFO - 2023-12-04 13:53:16 --> Security Class Initialized
DEBUG - 2023-12-04 13:53:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-04 13:53:16 --> Input Class Initialized
INFO - 2023-12-04 13:53:16 --> Language Class Initialized
INFO - 2023-12-04 13:53:16 --> Language Class Initialized
INFO - 2023-12-04 13:53:16 --> Config Class Initialized
INFO - 2023-12-04 13:53:16 --> Loader Class Initialized
INFO - 2023-12-04 13:53:16 --> Helper loaded: url_helper
INFO - 2023-12-04 13:53:16 --> Helper loaded: file_helper
INFO - 2023-12-04 13:53:16 --> Helper loaded: form_helper
INFO - 2023-12-04 13:53:16 --> Helper loaded: my_helper
INFO - 2023-12-04 13:53:16 --> Database Driver Class Initialized
INFO - 2023-12-04 13:53:16 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-04 13:53:16 --> Controller Class Initialized
INFO - 2023-12-04 13:53:17 --> Config Class Initialized
INFO - 2023-12-04 13:53:17 --> Hooks Class Initialized
DEBUG - 2023-12-04 13:53:17 --> UTF-8 Support Enabled
INFO - 2023-12-04 13:53:17 --> Utf8 Class Initialized
INFO - 2023-12-04 13:53:17 --> URI Class Initialized
INFO - 2023-12-04 13:53:17 --> Router Class Initialized
INFO - 2023-12-04 13:53:17 --> Output Class Initialized
INFO - 2023-12-04 13:53:17 --> Security Class Initialized
DEBUG - 2023-12-04 13:53:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-04 13:53:17 --> Input Class Initialized
INFO - 2023-12-04 13:53:17 --> Language Class Initialized
INFO - 2023-12-04 13:53:17 --> Language Class Initialized
INFO - 2023-12-04 13:53:17 --> Config Class Initialized
INFO - 2023-12-04 13:53:17 --> Loader Class Initialized
INFO - 2023-12-04 13:53:17 --> Helper loaded: url_helper
INFO - 2023-12-04 13:53:17 --> Helper loaded: file_helper
INFO - 2023-12-04 13:53:17 --> Helper loaded: form_helper
INFO - 2023-12-04 13:53:17 --> Helper loaded: my_helper
INFO - 2023-12-04 13:53:17 --> Database Driver Class Initialized
INFO - 2023-12-04 13:53:17 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-04 13:53:17 --> Controller Class Initialized
INFO - 2023-12-04 13:53:17 --> Final output sent to browser
DEBUG - 2023-12-04 13:53:17 --> Total execution time: 0.0691
INFO - 2023-12-04 13:56:02 --> Config Class Initialized
INFO - 2023-12-04 13:56:02 --> Hooks Class Initialized
DEBUG - 2023-12-04 13:56:02 --> UTF-8 Support Enabled
INFO - 2023-12-04 13:56:02 --> Utf8 Class Initialized
INFO - 2023-12-04 13:56:02 --> URI Class Initialized
INFO - 2023-12-04 13:56:02 --> Router Class Initialized
INFO - 2023-12-04 13:56:02 --> Output Class Initialized
INFO - 2023-12-04 13:56:02 --> Security Class Initialized
DEBUG - 2023-12-04 13:56:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-04 13:56:02 --> Input Class Initialized
INFO - 2023-12-04 13:56:02 --> Language Class Initialized
INFO - 2023-12-04 13:56:02 --> Language Class Initialized
INFO - 2023-12-04 13:56:02 --> Config Class Initialized
INFO - 2023-12-04 13:56:02 --> Loader Class Initialized
INFO - 2023-12-04 13:56:02 --> Helper loaded: url_helper
INFO - 2023-12-04 13:56:02 --> Helper loaded: file_helper
INFO - 2023-12-04 13:56:02 --> Helper loaded: form_helper
INFO - 2023-12-04 13:56:02 --> Helper loaded: my_helper
INFO - 2023-12-04 13:56:02 --> Database Driver Class Initialized
INFO - 2023-12-04 13:56:02 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-04 13:56:02 --> Controller Class Initialized
DEBUG - 2023-12-04 13:56:02 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/set_walikelas/views/list.php
DEBUG - 2023-12-04 13:56:02 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-12-04 13:56:02 --> Final output sent to browser
DEBUG - 2023-12-04 13:56:02 --> Total execution time: 0.1734
INFO - 2023-12-04 13:56:02 --> Config Class Initialized
INFO - 2023-12-04 13:56:02 --> Hooks Class Initialized
DEBUG - 2023-12-04 13:56:02 --> UTF-8 Support Enabled
INFO - 2023-12-04 13:56:02 --> Utf8 Class Initialized
INFO - 2023-12-04 13:56:02 --> URI Class Initialized
INFO - 2023-12-04 13:56:02 --> Router Class Initialized
INFO - 2023-12-04 13:56:02 --> Output Class Initialized
INFO - 2023-12-04 13:56:02 --> Security Class Initialized
DEBUG - 2023-12-04 13:56:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-04 13:56:02 --> Input Class Initialized
INFO - 2023-12-04 13:56:02 --> Language Class Initialized
ERROR - 2023-12-04 13:56:02 --> 404 Page Not Found: /index
INFO - 2023-12-04 13:56:02 --> Config Class Initialized
INFO - 2023-12-04 13:56:02 --> Hooks Class Initialized
DEBUG - 2023-12-04 13:56:02 --> UTF-8 Support Enabled
INFO - 2023-12-04 13:56:02 --> Utf8 Class Initialized
INFO - 2023-12-04 13:56:02 --> URI Class Initialized
INFO - 2023-12-04 13:56:02 --> Router Class Initialized
INFO - 2023-12-04 13:56:02 --> Output Class Initialized
INFO - 2023-12-04 13:56:02 --> Security Class Initialized
DEBUG - 2023-12-04 13:56:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-04 13:56:02 --> Input Class Initialized
INFO - 2023-12-04 13:56:02 --> Language Class Initialized
INFO - 2023-12-04 13:56:02 --> Language Class Initialized
INFO - 2023-12-04 13:56:02 --> Config Class Initialized
INFO - 2023-12-04 13:56:02 --> Loader Class Initialized
INFO - 2023-12-04 13:56:02 --> Helper loaded: url_helper
INFO - 2023-12-04 13:56:02 --> Helper loaded: file_helper
INFO - 2023-12-04 13:56:02 --> Helper loaded: form_helper
INFO - 2023-12-04 13:56:02 --> Helper loaded: my_helper
INFO - 2023-12-04 13:56:02 --> Database Driver Class Initialized
INFO - 2023-12-04 13:56:02 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-04 13:56:02 --> Controller Class Initialized
INFO - 2023-12-04 13:56:06 --> Config Class Initialized
INFO - 2023-12-04 13:56:06 --> Hooks Class Initialized
DEBUG - 2023-12-04 13:56:06 --> UTF-8 Support Enabled
INFO - 2023-12-04 13:56:06 --> Utf8 Class Initialized
INFO - 2023-12-04 13:56:06 --> URI Class Initialized
INFO - 2023-12-04 13:56:06 --> Router Class Initialized
INFO - 2023-12-04 13:56:06 --> Output Class Initialized
INFO - 2023-12-04 13:56:06 --> Security Class Initialized
DEBUG - 2023-12-04 13:56:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-04 13:56:06 --> Input Class Initialized
INFO - 2023-12-04 13:56:06 --> Language Class Initialized
INFO - 2023-12-04 13:56:06 --> Language Class Initialized
INFO - 2023-12-04 13:56:06 --> Config Class Initialized
INFO - 2023-12-04 13:56:06 --> Loader Class Initialized
INFO - 2023-12-04 13:56:06 --> Helper loaded: url_helper
INFO - 2023-12-04 13:56:06 --> Helper loaded: file_helper
INFO - 2023-12-04 13:56:06 --> Helper loaded: form_helper
INFO - 2023-12-04 13:56:06 --> Helper loaded: my_helper
INFO - 2023-12-04 13:56:06 --> Database Driver Class Initialized
INFO - 2023-12-04 13:56:06 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-04 13:56:06 --> Controller Class Initialized
INFO - 2023-12-04 13:56:06 --> Helper loaded: cookie_helper
INFO - 2023-12-04 13:56:06 --> Config Class Initialized
INFO - 2023-12-04 13:56:06 --> Hooks Class Initialized
DEBUG - 2023-12-04 13:56:06 --> UTF-8 Support Enabled
INFO - 2023-12-04 13:56:06 --> Utf8 Class Initialized
INFO - 2023-12-04 13:56:06 --> URI Class Initialized
INFO - 2023-12-04 13:56:06 --> Router Class Initialized
INFO - 2023-12-04 13:56:06 --> Output Class Initialized
INFO - 2023-12-04 13:56:06 --> Security Class Initialized
DEBUG - 2023-12-04 13:56:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-04 13:56:06 --> Input Class Initialized
INFO - 2023-12-04 13:56:06 --> Language Class Initialized
INFO - 2023-12-04 13:56:06 --> Language Class Initialized
INFO - 2023-12-04 13:56:06 --> Config Class Initialized
INFO - 2023-12-04 13:56:06 --> Loader Class Initialized
INFO - 2023-12-04 13:56:06 --> Helper loaded: url_helper
INFO - 2023-12-04 13:56:06 --> Helper loaded: file_helper
INFO - 2023-12-04 13:56:06 --> Helper loaded: form_helper
INFO - 2023-12-04 13:56:06 --> Helper loaded: my_helper
INFO - 2023-12-04 13:56:06 --> Database Driver Class Initialized
INFO - 2023-12-04 13:56:06 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-04 13:56:06 --> Controller Class Initialized
INFO - 2023-12-04 13:56:06 --> Config Class Initialized
INFO - 2023-12-04 13:56:06 --> Hooks Class Initialized
DEBUG - 2023-12-04 13:56:06 --> UTF-8 Support Enabled
INFO - 2023-12-04 13:56:06 --> Utf8 Class Initialized
INFO - 2023-12-04 13:56:06 --> URI Class Initialized
INFO - 2023-12-04 13:56:06 --> Router Class Initialized
INFO - 2023-12-04 13:56:06 --> Output Class Initialized
INFO - 2023-12-04 13:56:06 --> Security Class Initialized
DEBUG - 2023-12-04 13:56:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-04 13:56:06 --> Input Class Initialized
INFO - 2023-12-04 13:56:06 --> Language Class Initialized
INFO - 2023-12-04 13:56:06 --> Language Class Initialized
INFO - 2023-12-04 13:56:06 --> Config Class Initialized
INFO - 2023-12-04 13:56:06 --> Loader Class Initialized
INFO - 2023-12-04 13:56:06 --> Helper loaded: url_helper
INFO - 2023-12-04 13:56:06 --> Helper loaded: file_helper
INFO - 2023-12-04 13:56:06 --> Helper loaded: form_helper
INFO - 2023-12-04 13:56:06 --> Helper loaded: my_helper
INFO - 2023-12-04 13:56:06 --> Database Driver Class Initialized
INFO - 2023-12-04 13:56:06 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-04 13:56:06 --> Controller Class Initialized
DEBUG - 2023-12-04 13:56:06 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/login/views/login.php
DEBUG - 2023-12-04 13:56:06 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-12-04 13:56:06 --> Final output sent to browser
DEBUG - 2023-12-04 13:56:06 --> Total execution time: 0.0478
INFO - 2023-12-04 13:56:10 --> Config Class Initialized
INFO - 2023-12-04 13:56:10 --> Hooks Class Initialized
DEBUG - 2023-12-04 13:56:10 --> UTF-8 Support Enabled
INFO - 2023-12-04 13:56:10 --> Utf8 Class Initialized
INFO - 2023-12-04 13:56:10 --> URI Class Initialized
INFO - 2023-12-04 13:56:10 --> Router Class Initialized
INFO - 2023-12-04 13:56:10 --> Output Class Initialized
INFO - 2023-12-04 13:56:10 --> Security Class Initialized
DEBUG - 2023-12-04 13:56:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-04 13:56:10 --> Input Class Initialized
INFO - 2023-12-04 13:56:10 --> Language Class Initialized
INFO - 2023-12-04 13:56:10 --> Language Class Initialized
INFO - 2023-12-04 13:56:10 --> Config Class Initialized
INFO - 2023-12-04 13:56:10 --> Loader Class Initialized
INFO - 2023-12-04 13:56:10 --> Helper loaded: url_helper
INFO - 2023-12-04 13:56:10 --> Helper loaded: file_helper
INFO - 2023-12-04 13:56:10 --> Helper loaded: form_helper
INFO - 2023-12-04 13:56:10 --> Helper loaded: my_helper
INFO - 2023-12-04 13:56:10 --> Database Driver Class Initialized
INFO - 2023-12-04 13:56:10 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-04 13:56:10 --> Controller Class Initialized
INFO - 2023-12-04 13:56:10 --> Helper loaded: cookie_helper
INFO - 2023-12-04 13:56:10 --> Final output sent to browser
DEBUG - 2023-12-04 13:56:10 --> Total execution time: 0.0481
INFO - 2023-12-04 13:56:10 --> Config Class Initialized
INFO - 2023-12-04 13:56:10 --> Hooks Class Initialized
DEBUG - 2023-12-04 13:56:10 --> UTF-8 Support Enabled
INFO - 2023-12-04 13:56:10 --> Utf8 Class Initialized
INFO - 2023-12-04 13:56:10 --> URI Class Initialized
INFO - 2023-12-04 13:56:10 --> Router Class Initialized
INFO - 2023-12-04 13:56:10 --> Output Class Initialized
INFO - 2023-12-04 13:56:10 --> Security Class Initialized
DEBUG - 2023-12-04 13:56:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-04 13:56:10 --> Input Class Initialized
INFO - 2023-12-04 13:56:10 --> Language Class Initialized
INFO - 2023-12-04 13:56:10 --> Language Class Initialized
INFO - 2023-12-04 13:56:10 --> Config Class Initialized
INFO - 2023-12-04 13:56:10 --> Loader Class Initialized
INFO - 2023-12-04 13:56:10 --> Helper loaded: url_helper
INFO - 2023-12-04 13:56:10 --> Helper loaded: file_helper
INFO - 2023-12-04 13:56:10 --> Helper loaded: form_helper
INFO - 2023-12-04 13:56:10 --> Helper loaded: my_helper
INFO - 2023-12-04 13:56:10 --> Database Driver Class Initialized
INFO - 2023-12-04 13:56:10 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-04 13:56:10 --> Controller Class Initialized
DEBUG - 2023-12-04 13:56:10 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/home/views/v_home_guru.php
DEBUG - 2023-12-04 13:56:10 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-12-04 13:56:10 --> Final output sent to browser
DEBUG - 2023-12-04 13:56:10 --> Total execution time: 0.0464
INFO - 2023-12-04 13:56:13 --> Config Class Initialized
INFO - 2023-12-04 13:56:13 --> Hooks Class Initialized
DEBUG - 2023-12-04 13:56:13 --> UTF-8 Support Enabled
INFO - 2023-12-04 13:56:13 --> Utf8 Class Initialized
INFO - 2023-12-04 13:56:13 --> URI Class Initialized
INFO - 2023-12-04 13:56:13 --> Router Class Initialized
INFO - 2023-12-04 13:56:13 --> Output Class Initialized
INFO - 2023-12-04 13:56:13 --> Security Class Initialized
DEBUG - 2023-12-04 13:56:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-04 13:56:13 --> Input Class Initialized
INFO - 2023-12-04 13:56:13 --> Language Class Initialized
INFO - 2023-12-04 13:56:13 --> Language Class Initialized
INFO - 2023-12-04 13:56:13 --> Config Class Initialized
INFO - 2023-12-04 13:56:13 --> Loader Class Initialized
INFO - 2023-12-04 13:56:13 --> Helper loaded: url_helper
INFO - 2023-12-04 13:56:13 --> Helper loaded: file_helper
INFO - 2023-12-04 13:56:13 --> Helper loaded: form_helper
INFO - 2023-12-04 13:56:13 --> Helper loaded: my_helper
INFO - 2023-12-04 13:56:13 --> Database Driver Class Initialized
INFO - 2023-12-04 13:56:13 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-04 13:56:13 --> Controller Class Initialized
DEBUG - 2023-12-04 13:56:13 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/views/list.php
DEBUG - 2023-12-04 13:56:13 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-12-04 13:56:13 --> Final output sent to browser
DEBUG - 2023-12-04 13:56:13 --> Total execution time: 0.1021
INFO - 2023-12-04 13:56:14 --> Config Class Initialized
INFO - 2023-12-04 13:56:14 --> Hooks Class Initialized
DEBUG - 2023-12-04 13:56:14 --> UTF-8 Support Enabled
INFO - 2023-12-04 13:56:14 --> Utf8 Class Initialized
INFO - 2023-12-04 13:56:14 --> URI Class Initialized
INFO - 2023-12-04 13:56:14 --> Router Class Initialized
INFO - 2023-12-04 13:56:14 --> Output Class Initialized
INFO - 2023-12-04 13:56:14 --> Security Class Initialized
DEBUG - 2023-12-04 13:56:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-04 13:56:14 --> Input Class Initialized
INFO - 2023-12-04 13:56:14 --> Language Class Initialized
INFO - 2023-12-04 13:56:14 --> Language Class Initialized
INFO - 2023-12-04 13:56:14 --> Config Class Initialized
INFO - 2023-12-04 13:56:14 --> Loader Class Initialized
INFO - 2023-12-04 13:56:14 --> Helper loaded: url_helper
INFO - 2023-12-04 13:56:14 --> Helper loaded: file_helper
INFO - 2023-12-04 13:56:14 --> Helper loaded: form_helper
INFO - 2023-12-04 13:56:14 --> Helper loaded: my_helper
INFO - 2023-12-04 13:56:14 --> Database Driver Class Initialized
INFO - 2023-12-04 13:56:14 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-04 13:56:14 --> Controller Class Initialized
DEBUG - 2023-12-04 13:56:14 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/views/cetak_ikm.php
INFO - 2023-12-04 13:56:17 --> Final output sent to browser
DEBUG - 2023-12-04 13:56:17 --> Total execution time: 2.4881
INFO - 2023-12-04 13:56:23 --> Config Class Initialized
INFO - 2023-12-04 13:56:23 --> Hooks Class Initialized
DEBUG - 2023-12-04 13:56:23 --> UTF-8 Support Enabled
INFO - 2023-12-04 13:56:23 --> Utf8 Class Initialized
INFO - 2023-12-04 13:56:23 --> URI Class Initialized
INFO - 2023-12-04 13:56:23 --> Router Class Initialized
INFO - 2023-12-04 13:56:23 --> Output Class Initialized
INFO - 2023-12-04 13:56:23 --> Security Class Initialized
DEBUG - 2023-12-04 13:56:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-04 13:56:23 --> Input Class Initialized
INFO - 2023-12-04 13:56:23 --> Language Class Initialized
INFO - 2023-12-04 13:56:23 --> Language Class Initialized
INFO - 2023-12-04 13:56:23 --> Config Class Initialized
INFO - 2023-12-04 13:56:23 --> Loader Class Initialized
INFO - 2023-12-04 13:56:23 --> Helper loaded: url_helper
INFO - 2023-12-04 13:56:23 --> Helper loaded: file_helper
INFO - 2023-12-04 13:56:23 --> Helper loaded: form_helper
INFO - 2023-12-04 13:56:23 --> Helper loaded: my_helper
INFO - 2023-12-04 13:56:23 --> Database Driver Class Initialized
INFO - 2023-12-04 13:56:23 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-04 13:56:23 --> Controller Class Initialized
ERROR - 2023-12-04 13:56:23 --> Severity: Notice --> Undefined variable: projek /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/views/cetak_projek.php 107
DEBUG - 2023-12-04 13:56:23 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/views/cetak_projek.php
INFO - 2023-12-04 13:56:27 --> Final output sent to browser
DEBUG - 2023-12-04 13:56:27 --> Total execution time: 4.4108
INFO - 2023-12-04 14:33:28 --> Config Class Initialized
INFO - 2023-12-04 14:33:28 --> Hooks Class Initialized
DEBUG - 2023-12-04 14:33:28 --> UTF-8 Support Enabled
INFO - 2023-12-04 14:33:28 --> Utf8 Class Initialized
INFO - 2023-12-04 14:33:28 --> URI Class Initialized
INFO - 2023-12-04 14:33:28 --> Router Class Initialized
INFO - 2023-12-04 14:33:28 --> Output Class Initialized
INFO - 2023-12-04 14:33:28 --> Security Class Initialized
DEBUG - 2023-12-04 14:33:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-04 14:33:28 --> Input Class Initialized
INFO - 2023-12-04 14:33:28 --> Language Class Initialized
INFO - 2023-12-04 14:33:28 --> Language Class Initialized
INFO - 2023-12-04 14:33:28 --> Config Class Initialized
INFO - 2023-12-04 14:33:28 --> Loader Class Initialized
INFO - 2023-12-04 14:33:28 --> Helper loaded: url_helper
INFO - 2023-12-04 14:33:28 --> Helper loaded: file_helper
INFO - 2023-12-04 14:33:28 --> Helper loaded: form_helper
INFO - 2023-12-04 14:33:28 --> Helper loaded: my_helper
INFO - 2023-12-04 14:33:28 --> Database Driver Class Initialized
INFO - 2023-12-04 14:33:28 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-04 14:33:28 --> Controller Class Initialized
INFO - 2023-12-04 14:33:28 --> Helper loaded: cookie_helper
INFO - 2023-12-04 14:33:28 --> Config Class Initialized
INFO - 2023-12-04 14:33:28 --> Hooks Class Initialized
DEBUG - 2023-12-04 14:33:28 --> UTF-8 Support Enabled
INFO - 2023-12-04 14:33:28 --> Utf8 Class Initialized
INFO - 2023-12-04 14:33:28 --> URI Class Initialized
INFO - 2023-12-04 14:33:28 --> Router Class Initialized
INFO - 2023-12-04 14:33:28 --> Output Class Initialized
INFO - 2023-12-04 14:33:28 --> Security Class Initialized
DEBUG - 2023-12-04 14:33:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-04 14:33:28 --> Input Class Initialized
INFO - 2023-12-04 14:33:28 --> Language Class Initialized
INFO - 2023-12-04 14:33:28 --> Language Class Initialized
INFO - 2023-12-04 14:33:28 --> Config Class Initialized
INFO - 2023-12-04 14:33:28 --> Loader Class Initialized
INFO - 2023-12-04 14:33:28 --> Helper loaded: url_helper
INFO - 2023-12-04 14:33:28 --> Helper loaded: file_helper
INFO - 2023-12-04 14:33:28 --> Helper loaded: form_helper
INFO - 2023-12-04 14:33:28 --> Helper loaded: my_helper
INFO - 2023-12-04 14:33:28 --> Database Driver Class Initialized
INFO - 2023-12-04 14:33:28 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-04 14:33:28 --> Controller Class Initialized
INFO - 2023-12-04 14:33:28 --> Config Class Initialized
INFO - 2023-12-04 14:33:28 --> Hooks Class Initialized
DEBUG - 2023-12-04 14:33:28 --> UTF-8 Support Enabled
INFO - 2023-12-04 14:33:28 --> Utf8 Class Initialized
INFO - 2023-12-04 14:33:28 --> URI Class Initialized
INFO - 2023-12-04 14:33:28 --> Router Class Initialized
INFO - 2023-12-04 14:33:28 --> Output Class Initialized
INFO - 2023-12-04 14:33:28 --> Security Class Initialized
DEBUG - 2023-12-04 14:33:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-04 14:33:28 --> Input Class Initialized
INFO - 2023-12-04 14:33:28 --> Language Class Initialized
INFO - 2023-12-04 14:33:28 --> Language Class Initialized
INFO - 2023-12-04 14:33:28 --> Config Class Initialized
INFO - 2023-12-04 14:33:28 --> Loader Class Initialized
INFO - 2023-12-04 14:33:28 --> Helper loaded: url_helper
INFO - 2023-12-04 14:33:28 --> Helper loaded: file_helper
INFO - 2023-12-04 14:33:28 --> Helper loaded: form_helper
INFO - 2023-12-04 14:33:28 --> Helper loaded: my_helper
INFO - 2023-12-04 14:33:28 --> Database Driver Class Initialized
INFO - 2023-12-04 14:33:28 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-04 14:33:28 --> Controller Class Initialized
DEBUG - 2023-12-04 14:33:28 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/login/views/login.php
DEBUG - 2023-12-04 14:33:28 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-12-04 14:33:28 --> Final output sent to browser
DEBUG - 2023-12-04 14:33:28 --> Total execution time: 0.0469
INFO - 2023-12-04 14:33:33 --> Config Class Initialized
INFO - 2023-12-04 14:33:33 --> Hooks Class Initialized
DEBUG - 2023-12-04 14:33:33 --> UTF-8 Support Enabled
INFO - 2023-12-04 14:33:33 --> Utf8 Class Initialized
INFO - 2023-12-04 14:33:33 --> URI Class Initialized
INFO - 2023-12-04 14:33:33 --> Router Class Initialized
INFO - 2023-12-04 14:33:33 --> Output Class Initialized
INFO - 2023-12-04 14:33:33 --> Security Class Initialized
DEBUG - 2023-12-04 14:33:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-04 14:33:33 --> Input Class Initialized
INFO - 2023-12-04 14:33:33 --> Language Class Initialized
INFO - 2023-12-04 14:33:33 --> Language Class Initialized
INFO - 2023-12-04 14:33:33 --> Config Class Initialized
INFO - 2023-12-04 14:33:33 --> Loader Class Initialized
INFO - 2023-12-04 14:33:33 --> Helper loaded: url_helper
INFO - 2023-12-04 14:33:33 --> Helper loaded: file_helper
INFO - 2023-12-04 14:33:33 --> Helper loaded: form_helper
INFO - 2023-12-04 14:33:33 --> Helper loaded: my_helper
INFO - 2023-12-04 14:33:33 --> Database Driver Class Initialized
INFO - 2023-12-04 14:33:33 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-04 14:33:33 --> Controller Class Initialized
INFO - 2023-12-04 14:33:33 --> Helper loaded: cookie_helper
INFO - 2023-12-04 14:33:33 --> Final output sent to browser
DEBUG - 2023-12-04 14:33:33 --> Total execution time: 0.0475
INFO - 2023-12-04 14:33:33 --> Config Class Initialized
INFO - 2023-12-04 14:33:33 --> Hooks Class Initialized
DEBUG - 2023-12-04 14:33:33 --> UTF-8 Support Enabled
INFO - 2023-12-04 14:33:33 --> Utf8 Class Initialized
INFO - 2023-12-04 14:33:33 --> URI Class Initialized
INFO - 2023-12-04 14:33:33 --> Router Class Initialized
INFO - 2023-12-04 14:33:33 --> Output Class Initialized
INFO - 2023-12-04 14:33:33 --> Security Class Initialized
DEBUG - 2023-12-04 14:33:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-04 14:33:33 --> Input Class Initialized
INFO - 2023-12-04 14:33:33 --> Language Class Initialized
INFO - 2023-12-04 14:33:33 --> Language Class Initialized
INFO - 2023-12-04 14:33:33 --> Config Class Initialized
INFO - 2023-12-04 14:33:33 --> Loader Class Initialized
INFO - 2023-12-04 14:33:33 --> Helper loaded: url_helper
INFO - 2023-12-04 14:33:33 --> Helper loaded: file_helper
INFO - 2023-12-04 14:33:33 --> Helper loaded: form_helper
INFO - 2023-12-04 14:33:33 --> Helper loaded: my_helper
INFO - 2023-12-04 14:33:33 --> Database Driver Class Initialized
INFO - 2023-12-04 14:33:33 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-04 14:33:33 --> Controller Class Initialized
DEBUG - 2023-12-04 14:33:33 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/home/views/v_home.php
DEBUG - 2023-12-04 14:33:33 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-12-04 14:33:33 --> Final output sent to browser
DEBUG - 2023-12-04 14:33:33 --> Total execution time: 0.0968
INFO - 2023-12-04 14:33:35 --> Config Class Initialized
INFO - 2023-12-04 14:33:35 --> Hooks Class Initialized
DEBUG - 2023-12-04 14:33:35 --> UTF-8 Support Enabled
INFO - 2023-12-04 14:33:35 --> Utf8 Class Initialized
INFO - 2023-12-04 14:33:35 --> URI Class Initialized
INFO - 2023-12-04 14:33:35 --> Router Class Initialized
INFO - 2023-12-04 14:33:35 --> Output Class Initialized
INFO - 2023-12-04 14:33:35 --> Security Class Initialized
DEBUG - 2023-12-04 14:33:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-04 14:33:35 --> Input Class Initialized
INFO - 2023-12-04 14:33:35 --> Language Class Initialized
INFO - 2023-12-04 14:33:35 --> Language Class Initialized
INFO - 2023-12-04 14:33:35 --> Config Class Initialized
INFO - 2023-12-04 14:33:35 --> Loader Class Initialized
INFO - 2023-12-04 14:33:35 --> Helper loaded: url_helper
INFO - 2023-12-04 14:33:35 --> Helper loaded: file_helper
INFO - 2023-12-04 14:33:35 --> Helper loaded: form_helper
INFO - 2023-12-04 14:33:35 --> Helper loaded: my_helper
INFO - 2023-12-04 14:33:35 --> Database Driver Class Initialized
INFO - 2023-12-04 14:33:35 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-04 14:33:35 --> Controller Class Initialized
DEBUG - 2023-12-04 14:33:35 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/data_kelas/views/list.php
DEBUG - 2023-12-04 14:33:35 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-12-04 14:33:35 --> Final output sent to browser
DEBUG - 2023-12-04 14:33:35 --> Total execution time: 0.0943
INFO - 2023-12-04 14:33:35 --> Config Class Initialized
INFO - 2023-12-04 14:33:35 --> Hooks Class Initialized
DEBUG - 2023-12-04 14:33:35 --> UTF-8 Support Enabled
INFO - 2023-12-04 14:33:35 --> Utf8 Class Initialized
INFO - 2023-12-04 14:33:35 --> URI Class Initialized
INFO - 2023-12-04 14:33:35 --> Router Class Initialized
INFO - 2023-12-04 14:33:35 --> Output Class Initialized
INFO - 2023-12-04 14:33:35 --> Security Class Initialized
DEBUG - 2023-12-04 14:33:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-04 14:33:35 --> Input Class Initialized
INFO - 2023-12-04 14:33:35 --> Language Class Initialized
ERROR - 2023-12-04 14:33:35 --> 404 Page Not Found: /index
INFO - 2023-12-04 14:33:35 --> Config Class Initialized
INFO - 2023-12-04 14:33:35 --> Hooks Class Initialized
DEBUG - 2023-12-04 14:33:35 --> UTF-8 Support Enabled
INFO - 2023-12-04 14:33:35 --> Utf8 Class Initialized
INFO - 2023-12-04 14:33:35 --> URI Class Initialized
INFO - 2023-12-04 14:33:35 --> Router Class Initialized
INFO - 2023-12-04 14:33:35 --> Output Class Initialized
INFO - 2023-12-04 14:33:35 --> Security Class Initialized
DEBUG - 2023-12-04 14:33:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-04 14:33:35 --> Input Class Initialized
INFO - 2023-12-04 14:33:35 --> Language Class Initialized
INFO - 2023-12-04 14:33:35 --> Language Class Initialized
INFO - 2023-12-04 14:33:35 --> Config Class Initialized
INFO - 2023-12-04 14:33:35 --> Loader Class Initialized
INFO - 2023-12-04 14:33:35 --> Helper loaded: url_helper
INFO - 2023-12-04 14:33:35 --> Helper loaded: file_helper
INFO - 2023-12-04 14:33:35 --> Helper loaded: form_helper
INFO - 2023-12-04 14:33:35 --> Helper loaded: my_helper
INFO - 2023-12-04 14:33:35 --> Database Driver Class Initialized
INFO - 2023-12-04 14:33:35 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-04 14:33:35 --> Controller Class Initialized
INFO - 2023-12-04 14:33:41 --> Config Class Initialized
INFO - 2023-12-04 14:33:41 --> Hooks Class Initialized
DEBUG - 2023-12-04 14:33:41 --> UTF-8 Support Enabled
INFO - 2023-12-04 14:33:41 --> Utf8 Class Initialized
INFO - 2023-12-04 14:33:41 --> URI Class Initialized
INFO - 2023-12-04 14:33:41 --> Router Class Initialized
INFO - 2023-12-04 14:33:41 --> Output Class Initialized
INFO - 2023-12-04 14:33:41 --> Security Class Initialized
DEBUG - 2023-12-04 14:33:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-04 14:33:41 --> Input Class Initialized
INFO - 2023-12-04 14:33:41 --> Language Class Initialized
INFO - 2023-12-04 14:33:41 --> Language Class Initialized
INFO - 2023-12-04 14:33:41 --> Config Class Initialized
INFO - 2023-12-04 14:33:41 --> Loader Class Initialized
INFO - 2023-12-04 14:33:41 --> Helper loaded: url_helper
INFO - 2023-12-04 14:33:41 --> Helper loaded: file_helper
INFO - 2023-12-04 14:33:41 --> Helper loaded: form_helper
INFO - 2023-12-04 14:33:41 --> Helper loaded: my_helper
INFO - 2023-12-04 14:33:41 --> Database Driver Class Initialized
INFO - 2023-12-04 14:33:42 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-04 14:33:42 --> Controller Class Initialized
DEBUG - 2023-12-04 14:33:42 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/data_mapel/views/list.php
DEBUG - 2023-12-04 14:33:42 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-12-04 14:33:42 --> Final output sent to browser
DEBUG - 2023-12-04 14:33:42 --> Total execution time: 0.0495
INFO - 2023-12-04 14:33:42 --> Config Class Initialized
INFO - 2023-12-04 14:33:42 --> Hooks Class Initialized
DEBUG - 2023-12-04 14:33:42 --> UTF-8 Support Enabled
INFO - 2023-12-04 14:33:42 --> Utf8 Class Initialized
INFO - 2023-12-04 14:33:42 --> URI Class Initialized
INFO - 2023-12-04 14:33:42 --> Router Class Initialized
INFO - 2023-12-04 14:33:42 --> Output Class Initialized
INFO - 2023-12-04 14:33:42 --> Security Class Initialized
DEBUG - 2023-12-04 14:33:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-04 14:33:42 --> Input Class Initialized
INFO - 2023-12-04 14:33:42 --> Language Class Initialized
ERROR - 2023-12-04 14:33:42 --> 404 Page Not Found: /index
INFO - 2023-12-04 14:33:42 --> Config Class Initialized
INFO - 2023-12-04 14:33:42 --> Hooks Class Initialized
DEBUG - 2023-12-04 14:33:42 --> UTF-8 Support Enabled
INFO - 2023-12-04 14:33:42 --> Utf8 Class Initialized
INFO - 2023-12-04 14:33:42 --> URI Class Initialized
INFO - 2023-12-04 14:33:42 --> Router Class Initialized
INFO - 2023-12-04 14:33:42 --> Output Class Initialized
INFO - 2023-12-04 14:33:42 --> Security Class Initialized
DEBUG - 2023-12-04 14:33:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-04 14:33:42 --> Input Class Initialized
INFO - 2023-12-04 14:33:42 --> Language Class Initialized
INFO - 2023-12-04 14:33:42 --> Language Class Initialized
INFO - 2023-12-04 14:33:42 --> Config Class Initialized
INFO - 2023-12-04 14:33:42 --> Loader Class Initialized
INFO - 2023-12-04 14:33:42 --> Helper loaded: url_helper
INFO - 2023-12-04 14:33:42 --> Helper loaded: file_helper
INFO - 2023-12-04 14:33:42 --> Helper loaded: form_helper
INFO - 2023-12-04 14:33:42 --> Helper loaded: my_helper
INFO - 2023-12-04 14:33:42 --> Database Driver Class Initialized
INFO - 2023-12-04 14:33:42 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-04 14:33:42 --> Controller Class Initialized
INFO - 2023-12-04 14:33:43 --> Config Class Initialized
INFO - 2023-12-04 14:33:43 --> Hooks Class Initialized
DEBUG - 2023-12-04 14:33:43 --> UTF-8 Support Enabled
INFO - 2023-12-04 14:33:43 --> Utf8 Class Initialized
INFO - 2023-12-04 14:33:43 --> URI Class Initialized
INFO - 2023-12-04 14:33:43 --> Router Class Initialized
INFO - 2023-12-04 14:33:43 --> Output Class Initialized
INFO - 2023-12-04 14:33:43 --> Security Class Initialized
DEBUG - 2023-12-04 14:33:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-04 14:33:43 --> Input Class Initialized
INFO - 2023-12-04 14:33:43 --> Language Class Initialized
INFO - 2023-12-04 14:33:43 --> Language Class Initialized
INFO - 2023-12-04 14:33:43 --> Config Class Initialized
INFO - 2023-12-04 14:33:43 --> Loader Class Initialized
INFO - 2023-12-04 14:33:43 --> Helper loaded: url_helper
INFO - 2023-12-04 14:33:43 --> Helper loaded: file_helper
INFO - 2023-12-04 14:33:43 --> Helper loaded: form_helper
INFO - 2023-12-04 14:33:43 --> Helper loaded: my_helper
INFO - 2023-12-04 14:33:43 --> Database Driver Class Initialized
INFO - 2023-12-04 14:33:43 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-04 14:33:43 --> Controller Class Initialized
INFO - 2023-12-04 14:33:43 --> Final output sent to browser
DEBUG - 2023-12-04 14:33:43 --> Total execution time: 0.0409
INFO - 2023-12-04 14:33:48 --> Config Class Initialized
INFO - 2023-12-04 14:33:48 --> Hooks Class Initialized
DEBUG - 2023-12-04 14:33:48 --> UTF-8 Support Enabled
INFO - 2023-12-04 14:33:48 --> Utf8 Class Initialized
INFO - 2023-12-04 14:33:48 --> URI Class Initialized
INFO - 2023-12-04 14:33:48 --> Router Class Initialized
INFO - 2023-12-04 14:33:48 --> Output Class Initialized
INFO - 2023-12-04 14:33:48 --> Security Class Initialized
DEBUG - 2023-12-04 14:33:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-04 14:33:48 --> Input Class Initialized
INFO - 2023-12-04 14:33:48 --> Language Class Initialized
INFO - 2023-12-04 14:33:48 --> Language Class Initialized
INFO - 2023-12-04 14:33:48 --> Config Class Initialized
INFO - 2023-12-04 14:33:48 --> Loader Class Initialized
INFO - 2023-12-04 14:33:48 --> Helper loaded: url_helper
INFO - 2023-12-04 14:33:48 --> Helper loaded: file_helper
INFO - 2023-12-04 14:33:48 --> Helper loaded: form_helper
INFO - 2023-12-04 14:33:48 --> Helper loaded: my_helper
INFO - 2023-12-04 14:33:48 --> Database Driver Class Initialized
INFO - 2023-12-04 14:33:48 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-04 14:33:48 --> Controller Class Initialized
INFO - 2023-12-04 14:33:48 --> Final output sent to browser
DEBUG - 2023-12-04 14:33:48 --> Total execution time: 0.0373
INFO - 2023-12-04 14:33:54 --> Config Class Initialized
INFO - 2023-12-04 14:33:54 --> Hooks Class Initialized
DEBUG - 2023-12-04 14:33:54 --> UTF-8 Support Enabled
INFO - 2023-12-04 14:33:54 --> Utf8 Class Initialized
INFO - 2023-12-04 14:33:54 --> URI Class Initialized
INFO - 2023-12-04 14:33:54 --> Router Class Initialized
INFO - 2023-12-04 14:33:54 --> Output Class Initialized
INFO - 2023-12-04 14:33:54 --> Security Class Initialized
DEBUG - 2023-12-04 14:33:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-04 14:33:54 --> Input Class Initialized
INFO - 2023-12-04 14:33:54 --> Language Class Initialized
INFO - 2023-12-04 14:33:54 --> Language Class Initialized
INFO - 2023-12-04 14:33:54 --> Config Class Initialized
INFO - 2023-12-04 14:33:54 --> Loader Class Initialized
INFO - 2023-12-04 14:33:54 --> Helper loaded: url_helper
INFO - 2023-12-04 14:33:54 --> Helper loaded: file_helper
INFO - 2023-12-04 14:33:54 --> Helper loaded: form_helper
INFO - 2023-12-04 14:33:54 --> Helper loaded: my_helper
INFO - 2023-12-04 14:33:54 --> Database Driver Class Initialized
INFO - 2023-12-04 14:33:54 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-04 14:33:54 --> Controller Class Initialized
INFO - 2023-12-04 14:33:54 --> Final output sent to browser
DEBUG - 2023-12-04 14:33:54 --> Total execution time: 0.0356
INFO - 2023-12-04 14:37:15 --> Config Class Initialized
INFO - 2023-12-04 14:37:15 --> Hooks Class Initialized
DEBUG - 2023-12-04 14:37:15 --> UTF-8 Support Enabled
INFO - 2023-12-04 14:37:15 --> Utf8 Class Initialized
INFO - 2023-12-04 14:37:15 --> URI Class Initialized
INFO - 2023-12-04 14:37:15 --> Router Class Initialized
INFO - 2023-12-04 14:37:15 --> Output Class Initialized
INFO - 2023-12-04 14:37:15 --> Security Class Initialized
DEBUG - 2023-12-04 14:37:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-04 14:37:15 --> Input Class Initialized
INFO - 2023-12-04 14:37:15 --> Language Class Initialized
INFO - 2023-12-04 14:37:15 --> Language Class Initialized
INFO - 2023-12-04 14:37:15 --> Config Class Initialized
INFO - 2023-12-04 14:37:15 --> Loader Class Initialized
INFO - 2023-12-04 14:37:15 --> Helper loaded: url_helper
INFO - 2023-12-04 14:37:15 --> Helper loaded: file_helper
INFO - 2023-12-04 14:37:15 --> Helper loaded: form_helper
INFO - 2023-12-04 14:37:15 --> Helper loaded: my_helper
INFO - 2023-12-04 14:37:15 --> Database Driver Class Initialized
INFO - 2023-12-04 14:37:15 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-04 14:37:15 --> Controller Class Initialized
DEBUG - 2023-12-04 14:37:15 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/data_mapel/views/list.php
DEBUG - 2023-12-04 14:37:15 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-12-04 14:37:15 --> Final output sent to browser
DEBUG - 2023-12-04 14:37:15 --> Total execution time: 0.0938
INFO - 2023-12-04 14:37:15 --> Config Class Initialized
INFO - 2023-12-04 14:37:15 --> Hooks Class Initialized
DEBUG - 2023-12-04 14:37:15 --> UTF-8 Support Enabled
INFO - 2023-12-04 14:37:15 --> Utf8 Class Initialized
INFO - 2023-12-04 14:37:15 --> URI Class Initialized
INFO - 2023-12-04 14:37:15 --> Router Class Initialized
INFO - 2023-12-04 14:37:15 --> Output Class Initialized
INFO - 2023-12-04 14:37:15 --> Security Class Initialized
DEBUG - 2023-12-04 14:37:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-04 14:37:15 --> Input Class Initialized
INFO - 2023-12-04 14:37:15 --> Language Class Initialized
ERROR - 2023-12-04 14:37:15 --> 404 Page Not Found: /index
INFO - 2023-12-04 14:37:15 --> Config Class Initialized
INFO - 2023-12-04 14:37:15 --> Hooks Class Initialized
DEBUG - 2023-12-04 14:37:15 --> UTF-8 Support Enabled
INFO - 2023-12-04 14:37:15 --> Utf8 Class Initialized
INFO - 2023-12-04 14:37:15 --> URI Class Initialized
INFO - 2023-12-04 14:37:15 --> Router Class Initialized
INFO - 2023-12-04 14:37:15 --> Output Class Initialized
INFO - 2023-12-04 14:37:15 --> Security Class Initialized
DEBUG - 2023-12-04 14:37:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-04 14:37:15 --> Input Class Initialized
INFO - 2023-12-04 14:37:15 --> Language Class Initialized
INFO - 2023-12-04 14:37:15 --> Language Class Initialized
INFO - 2023-12-04 14:37:15 --> Config Class Initialized
INFO - 2023-12-04 14:37:15 --> Loader Class Initialized
INFO - 2023-12-04 14:37:15 --> Helper loaded: url_helper
INFO - 2023-12-04 14:37:15 --> Helper loaded: file_helper
INFO - 2023-12-04 14:37:15 --> Helper loaded: form_helper
INFO - 2023-12-04 14:37:15 --> Helper loaded: my_helper
INFO - 2023-12-04 14:37:15 --> Database Driver Class Initialized
INFO - 2023-12-04 14:37:15 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-04 14:37:15 --> Controller Class Initialized
INFO - 2023-12-04 14:37:16 --> Config Class Initialized
INFO - 2023-12-04 14:37:16 --> Hooks Class Initialized
DEBUG - 2023-12-04 14:37:16 --> UTF-8 Support Enabled
INFO - 2023-12-04 14:37:16 --> Utf8 Class Initialized
INFO - 2023-12-04 14:37:16 --> URI Class Initialized
INFO - 2023-12-04 14:37:16 --> Router Class Initialized
INFO - 2023-12-04 14:37:16 --> Output Class Initialized
INFO - 2023-12-04 14:37:16 --> Security Class Initialized
DEBUG - 2023-12-04 14:37:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-04 14:37:16 --> Input Class Initialized
INFO - 2023-12-04 14:37:16 --> Language Class Initialized
INFO - 2023-12-04 14:37:16 --> Language Class Initialized
INFO - 2023-12-04 14:37:16 --> Config Class Initialized
INFO - 2023-12-04 14:37:16 --> Loader Class Initialized
INFO - 2023-12-04 14:37:16 --> Helper loaded: url_helper
INFO - 2023-12-04 14:37:16 --> Helper loaded: file_helper
INFO - 2023-12-04 14:37:16 --> Helper loaded: form_helper
INFO - 2023-12-04 14:37:16 --> Helper loaded: my_helper
INFO - 2023-12-04 14:37:16 --> Database Driver Class Initialized
INFO - 2023-12-04 14:37:16 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-04 14:37:16 --> Controller Class Initialized
INFO - 2023-12-04 14:37:16 --> Final output sent to browser
DEBUG - 2023-12-04 14:37:16 --> Total execution time: 0.0457
INFO - 2023-12-04 14:37:22 --> Config Class Initialized
INFO - 2023-12-04 14:37:22 --> Hooks Class Initialized
DEBUG - 2023-12-04 14:37:22 --> UTF-8 Support Enabled
INFO - 2023-12-04 14:37:22 --> Utf8 Class Initialized
INFO - 2023-12-04 14:37:22 --> URI Class Initialized
INFO - 2023-12-04 14:37:22 --> Router Class Initialized
INFO - 2023-12-04 14:37:22 --> Output Class Initialized
INFO - 2023-12-04 14:37:22 --> Security Class Initialized
DEBUG - 2023-12-04 14:37:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-04 14:37:22 --> Input Class Initialized
INFO - 2023-12-04 14:37:22 --> Language Class Initialized
INFO - 2023-12-04 14:37:22 --> Language Class Initialized
INFO - 2023-12-04 14:37:22 --> Config Class Initialized
INFO - 2023-12-04 14:37:22 --> Loader Class Initialized
INFO - 2023-12-04 14:37:22 --> Helper loaded: url_helper
INFO - 2023-12-04 14:37:22 --> Helper loaded: file_helper
INFO - 2023-12-04 14:37:22 --> Helper loaded: form_helper
INFO - 2023-12-04 14:37:22 --> Helper loaded: my_helper
INFO - 2023-12-04 14:37:22 --> Database Driver Class Initialized
INFO - 2023-12-04 14:37:22 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-04 14:37:22 --> Controller Class Initialized
INFO - 2023-12-04 14:37:22 --> Helper loaded: cookie_helper
INFO - 2023-12-04 14:37:22 --> Config Class Initialized
INFO - 2023-12-04 14:37:22 --> Hooks Class Initialized
DEBUG - 2023-12-04 14:37:22 --> UTF-8 Support Enabled
INFO - 2023-12-04 14:37:22 --> Utf8 Class Initialized
INFO - 2023-12-04 14:37:22 --> URI Class Initialized
INFO - 2023-12-04 14:37:22 --> Router Class Initialized
INFO - 2023-12-04 14:37:22 --> Output Class Initialized
INFO - 2023-12-04 14:37:22 --> Security Class Initialized
DEBUG - 2023-12-04 14:37:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-04 14:37:22 --> Input Class Initialized
INFO - 2023-12-04 14:37:22 --> Language Class Initialized
INFO - 2023-12-04 14:37:22 --> Language Class Initialized
INFO - 2023-12-04 14:37:22 --> Config Class Initialized
INFO - 2023-12-04 14:37:22 --> Loader Class Initialized
INFO - 2023-12-04 14:37:22 --> Helper loaded: url_helper
INFO - 2023-12-04 14:37:22 --> Helper loaded: file_helper
INFO - 2023-12-04 14:37:22 --> Helper loaded: form_helper
INFO - 2023-12-04 14:37:22 --> Helper loaded: my_helper
INFO - 2023-12-04 14:37:22 --> Database Driver Class Initialized
INFO - 2023-12-04 14:37:22 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-04 14:37:22 --> Controller Class Initialized
INFO - 2023-12-04 14:37:22 --> Config Class Initialized
INFO - 2023-12-04 14:37:22 --> Hooks Class Initialized
DEBUG - 2023-12-04 14:37:22 --> UTF-8 Support Enabled
INFO - 2023-12-04 14:37:22 --> Utf8 Class Initialized
INFO - 2023-12-04 14:37:22 --> URI Class Initialized
INFO - 2023-12-04 14:37:22 --> Router Class Initialized
INFO - 2023-12-04 14:37:22 --> Output Class Initialized
INFO - 2023-12-04 14:37:22 --> Security Class Initialized
DEBUG - 2023-12-04 14:37:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-04 14:37:22 --> Input Class Initialized
INFO - 2023-12-04 14:37:22 --> Language Class Initialized
INFO - 2023-12-04 14:37:22 --> Language Class Initialized
INFO - 2023-12-04 14:37:22 --> Config Class Initialized
INFO - 2023-12-04 14:37:22 --> Loader Class Initialized
INFO - 2023-12-04 14:37:22 --> Helper loaded: url_helper
INFO - 2023-12-04 14:37:22 --> Helper loaded: file_helper
INFO - 2023-12-04 14:37:22 --> Helper loaded: form_helper
INFO - 2023-12-04 14:37:22 --> Helper loaded: my_helper
INFO - 2023-12-04 14:37:22 --> Database Driver Class Initialized
INFO - 2023-12-04 14:37:22 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-04 14:37:22 --> Controller Class Initialized
DEBUG - 2023-12-04 14:37:22 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/login/views/login.php
DEBUG - 2023-12-04 14:37:22 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-12-04 14:37:22 --> Final output sent to browser
DEBUG - 2023-12-04 14:37:22 --> Total execution time: 0.1240
INFO - 2023-12-04 14:37:49 --> Config Class Initialized
INFO - 2023-12-04 14:37:49 --> Hooks Class Initialized
DEBUG - 2023-12-04 14:37:49 --> UTF-8 Support Enabled
INFO - 2023-12-04 14:37:49 --> Utf8 Class Initialized
INFO - 2023-12-04 14:37:49 --> URI Class Initialized
INFO - 2023-12-04 14:37:49 --> Router Class Initialized
INFO - 2023-12-04 14:37:49 --> Output Class Initialized
INFO - 2023-12-04 14:37:49 --> Security Class Initialized
DEBUG - 2023-12-04 14:37:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-04 14:37:49 --> Input Class Initialized
INFO - 2023-12-04 14:37:49 --> Language Class Initialized
INFO - 2023-12-04 14:37:49 --> Language Class Initialized
INFO - 2023-12-04 14:37:49 --> Config Class Initialized
INFO - 2023-12-04 14:37:49 --> Loader Class Initialized
INFO - 2023-12-04 14:37:49 --> Helper loaded: url_helper
INFO - 2023-12-04 14:37:49 --> Helper loaded: file_helper
INFO - 2023-12-04 14:37:49 --> Helper loaded: form_helper
INFO - 2023-12-04 14:37:49 --> Helper loaded: my_helper
INFO - 2023-12-04 14:37:49 --> Database Driver Class Initialized
INFO - 2023-12-04 14:37:49 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-04 14:37:49 --> Controller Class Initialized
DEBUG - 2023-12-04 14:37:49 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/views/list.php
DEBUG - 2023-12-04 14:37:49 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-12-04 14:37:49 --> Final output sent to browser
DEBUG - 2023-12-04 14:37:49 --> Total execution time: 0.0525
INFO - 2023-12-04 14:37:50 --> Config Class Initialized
INFO - 2023-12-04 14:37:50 --> Hooks Class Initialized
DEBUG - 2023-12-04 14:37:50 --> UTF-8 Support Enabled
INFO - 2023-12-04 14:37:50 --> Utf8 Class Initialized
INFO - 2023-12-04 14:37:50 --> URI Class Initialized
INFO - 2023-12-04 14:37:50 --> Router Class Initialized
INFO - 2023-12-04 14:37:50 --> Output Class Initialized
INFO - 2023-12-04 14:37:50 --> Security Class Initialized
DEBUG - 2023-12-04 14:37:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-04 14:37:50 --> Input Class Initialized
INFO - 2023-12-04 14:37:50 --> Language Class Initialized
INFO - 2023-12-04 14:37:50 --> Language Class Initialized
INFO - 2023-12-04 14:37:50 --> Config Class Initialized
INFO - 2023-12-04 14:37:50 --> Loader Class Initialized
INFO - 2023-12-04 14:37:50 --> Helper loaded: url_helper
INFO - 2023-12-04 14:37:50 --> Helper loaded: file_helper
INFO - 2023-12-04 14:37:50 --> Helper loaded: form_helper
INFO - 2023-12-04 14:37:50 --> Helper loaded: my_helper
INFO - 2023-12-04 14:37:50 --> Database Driver Class Initialized
INFO - 2023-12-04 14:37:50 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-04 14:37:50 --> Controller Class Initialized
INFO - 2023-12-04 15:17:37 --> Config Class Initialized
INFO - 2023-12-04 15:17:37 --> Hooks Class Initialized
DEBUG - 2023-12-04 15:17:37 --> UTF-8 Support Enabled
INFO - 2023-12-04 15:17:37 --> Utf8 Class Initialized
INFO - 2023-12-04 15:17:37 --> URI Class Initialized
INFO - 2023-12-04 15:17:37 --> Router Class Initialized
INFO - 2023-12-04 15:17:37 --> Output Class Initialized
INFO - 2023-12-04 15:17:37 --> Security Class Initialized
DEBUG - 2023-12-04 15:17:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-04 15:17:37 --> Input Class Initialized
INFO - 2023-12-04 15:17:37 --> Language Class Initialized
INFO - 2023-12-04 15:17:37 --> Language Class Initialized
INFO - 2023-12-04 15:17:37 --> Config Class Initialized
INFO - 2023-12-04 15:17:37 --> Loader Class Initialized
INFO - 2023-12-04 15:17:37 --> Helper loaded: url_helper
INFO - 2023-12-04 15:17:37 --> Helper loaded: file_helper
INFO - 2023-12-04 15:17:37 --> Helper loaded: form_helper
INFO - 2023-12-04 15:17:37 --> Helper loaded: my_helper
INFO - 2023-12-04 15:17:37 --> Database Driver Class Initialized
INFO - 2023-12-04 15:17:37 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-04 15:17:37 --> Controller Class Initialized
DEBUG - 2023-12-04 15:17:37 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/login/views/login.php
DEBUG - 2023-12-04 15:17:37 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-12-04 15:17:37 --> Final output sent to browser
DEBUG - 2023-12-04 15:17:37 --> Total execution time: 0.0846
INFO - 2023-12-04 15:19:23 --> Config Class Initialized
INFO - 2023-12-04 15:19:23 --> Hooks Class Initialized
DEBUG - 2023-12-04 15:19:23 --> UTF-8 Support Enabled
INFO - 2023-12-04 15:19:23 --> Utf8 Class Initialized
INFO - 2023-12-04 15:19:23 --> URI Class Initialized
INFO - 2023-12-04 15:19:23 --> Router Class Initialized
INFO - 2023-12-04 15:19:23 --> Output Class Initialized
INFO - 2023-12-04 15:19:23 --> Security Class Initialized
DEBUG - 2023-12-04 15:19:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-04 15:19:23 --> Input Class Initialized
INFO - 2023-12-04 15:19:23 --> Language Class Initialized
INFO - 2023-12-04 15:19:23 --> Language Class Initialized
INFO - 2023-12-04 15:19:23 --> Config Class Initialized
INFO - 2023-12-04 15:19:23 --> Loader Class Initialized
INFO - 2023-12-04 15:19:23 --> Helper loaded: url_helper
INFO - 2023-12-04 15:19:23 --> Helper loaded: file_helper
INFO - 2023-12-04 15:19:23 --> Helper loaded: form_helper
INFO - 2023-12-04 15:19:23 --> Helper loaded: my_helper
INFO - 2023-12-04 15:19:23 --> Database Driver Class Initialized
INFO - 2023-12-04 15:19:23 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-04 15:19:23 --> Controller Class Initialized
INFO - 2023-12-04 15:19:24 --> Helper loaded: cookie_helper
INFO - 2023-12-04 15:19:24 --> Final output sent to browser
DEBUG - 2023-12-04 15:19:24 --> Total execution time: 0.0797
INFO - 2023-12-04 15:19:24 --> Config Class Initialized
INFO - 2023-12-04 15:19:24 --> Hooks Class Initialized
DEBUG - 2023-12-04 15:19:24 --> UTF-8 Support Enabled
INFO - 2023-12-04 15:19:24 --> Utf8 Class Initialized
INFO - 2023-12-04 15:19:24 --> URI Class Initialized
INFO - 2023-12-04 15:19:24 --> Router Class Initialized
INFO - 2023-12-04 15:19:24 --> Output Class Initialized
INFO - 2023-12-04 15:19:24 --> Security Class Initialized
DEBUG - 2023-12-04 15:19:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-04 15:19:24 --> Input Class Initialized
INFO - 2023-12-04 15:19:24 --> Language Class Initialized
INFO - 2023-12-04 15:19:24 --> Language Class Initialized
INFO - 2023-12-04 15:19:24 --> Config Class Initialized
INFO - 2023-12-04 15:19:24 --> Loader Class Initialized
INFO - 2023-12-04 15:19:24 --> Helper loaded: url_helper
INFO - 2023-12-04 15:19:24 --> Helper loaded: file_helper
INFO - 2023-12-04 15:19:24 --> Helper loaded: form_helper
INFO - 2023-12-04 15:19:24 --> Helper loaded: my_helper
INFO - 2023-12-04 15:19:24 --> Database Driver Class Initialized
INFO - 2023-12-04 15:19:24 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-04 15:19:24 --> Controller Class Initialized
DEBUG - 2023-12-04 15:19:24 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/home/views/v_home_guru.php
DEBUG - 2023-12-04 15:19:24 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-12-04 15:19:24 --> Final output sent to browser
DEBUG - 2023-12-04 15:19:24 --> Total execution time: 0.0638
INFO - 2023-12-04 15:19:56 --> Config Class Initialized
INFO - 2023-12-04 15:19:56 --> Hooks Class Initialized
DEBUG - 2023-12-04 15:19:56 --> UTF-8 Support Enabled
INFO - 2023-12-04 15:19:56 --> Utf8 Class Initialized
INFO - 2023-12-04 15:19:56 --> URI Class Initialized
INFO - 2023-12-04 15:19:56 --> Router Class Initialized
INFO - 2023-12-04 15:19:56 --> Output Class Initialized
INFO - 2023-12-04 15:19:56 --> Security Class Initialized
DEBUG - 2023-12-04 15:19:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-04 15:19:56 --> Input Class Initialized
INFO - 2023-12-04 15:19:56 --> Language Class Initialized
INFO - 2023-12-04 15:19:56 --> Language Class Initialized
INFO - 2023-12-04 15:19:56 --> Config Class Initialized
INFO - 2023-12-04 15:19:56 --> Loader Class Initialized
INFO - 2023-12-04 15:19:56 --> Helper loaded: url_helper
INFO - 2023-12-04 15:19:56 --> Helper loaded: file_helper
INFO - 2023-12-04 15:19:56 --> Helper loaded: form_helper
INFO - 2023-12-04 15:19:56 --> Helper loaded: my_helper
INFO - 2023-12-04 15:19:56 --> Database Driver Class Initialized
INFO - 2023-12-04 15:19:56 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-04 15:19:56 --> Controller Class Initialized
DEBUG - 2023-12-04 15:19:56 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/view_mapel/views/v_view_mapel.php
DEBUG - 2023-12-04 15:19:56 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-12-04 15:19:56 --> Final output sent to browser
DEBUG - 2023-12-04 15:19:56 --> Total execution time: 0.3340
INFO - 2023-12-04 15:19:59 --> Config Class Initialized
INFO - 2023-12-04 15:19:59 --> Hooks Class Initialized
DEBUG - 2023-12-04 15:19:59 --> UTF-8 Support Enabled
INFO - 2023-12-04 15:19:59 --> Utf8 Class Initialized
INFO - 2023-12-04 15:19:59 --> URI Class Initialized
INFO - 2023-12-04 15:19:59 --> Router Class Initialized
INFO - 2023-12-04 15:19:59 --> Output Class Initialized
INFO - 2023-12-04 15:19:59 --> Security Class Initialized
DEBUG - 2023-12-04 15:19:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-04 15:19:59 --> Input Class Initialized
INFO - 2023-12-04 15:19:59 --> Language Class Initialized
INFO - 2023-12-04 15:19:59 --> Language Class Initialized
INFO - 2023-12-04 15:19:59 --> Config Class Initialized
INFO - 2023-12-04 15:19:59 --> Loader Class Initialized
INFO - 2023-12-04 15:19:59 --> Helper loaded: url_helper
INFO - 2023-12-04 15:19:59 --> Helper loaded: file_helper
INFO - 2023-12-04 15:19:59 --> Helper loaded: form_helper
INFO - 2023-12-04 15:19:59 --> Helper loaded: my_helper
INFO - 2023-12-04 15:19:59 --> Database Driver Class Initialized
INFO - 2023-12-04 15:19:59 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-04 15:19:59 --> Controller Class Initialized
DEBUG - 2023-12-04 15:19:59 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/views/list.php
DEBUG - 2023-12-04 15:19:59 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-12-04 15:19:59 --> Final output sent to browser
DEBUG - 2023-12-04 15:19:59 --> Total execution time: 0.0589
INFO - 2023-12-04 15:19:59 --> Config Class Initialized
INFO - 2023-12-04 15:19:59 --> Hooks Class Initialized
DEBUG - 2023-12-04 15:19:59 --> UTF-8 Support Enabled
INFO - 2023-12-04 15:19:59 --> Utf8 Class Initialized
INFO - 2023-12-04 15:19:59 --> URI Class Initialized
INFO - 2023-12-04 15:19:59 --> Router Class Initialized
INFO - 2023-12-04 15:19:59 --> Output Class Initialized
INFO - 2023-12-04 15:19:59 --> Security Class Initialized
DEBUG - 2023-12-04 15:19:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-04 15:19:59 --> Input Class Initialized
INFO - 2023-12-04 15:19:59 --> Language Class Initialized
INFO - 2023-12-04 15:19:59 --> Language Class Initialized
INFO - 2023-12-04 15:19:59 --> Config Class Initialized
INFO - 2023-12-04 15:19:59 --> Loader Class Initialized
INFO - 2023-12-04 15:19:59 --> Helper loaded: url_helper
INFO - 2023-12-04 15:19:59 --> Helper loaded: file_helper
INFO - 2023-12-04 15:19:59 --> Helper loaded: form_helper
INFO - 2023-12-04 15:19:59 --> Helper loaded: my_helper
INFO - 2023-12-04 15:19:59 --> Database Driver Class Initialized
INFO - 2023-12-04 15:19:59 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-04 15:19:59 --> Controller Class Initialized
INFO - 2023-12-04 15:20:09 --> Config Class Initialized
INFO - 2023-12-04 15:20:09 --> Hooks Class Initialized
DEBUG - 2023-12-04 15:20:09 --> UTF-8 Support Enabled
INFO - 2023-12-04 15:20:09 --> Utf8 Class Initialized
INFO - 2023-12-04 15:20:09 --> URI Class Initialized
INFO - 2023-12-04 15:20:09 --> Router Class Initialized
INFO - 2023-12-04 15:20:09 --> Output Class Initialized
INFO - 2023-12-04 15:20:09 --> Security Class Initialized
DEBUG - 2023-12-04 15:20:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-04 15:20:09 --> Input Class Initialized
INFO - 2023-12-04 15:20:09 --> Language Class Initialized
INFO - 2023-12-04 15:20:09 --> Language Class Initialized
INFO - 2023-12-04 15:20:09 --> Config Class Initialized
INFO - 2023-12-04 15:20:09 --> Loader Class Initialized
INFO - 2023-12-04 15:20:09 --> Helper loaded: url_helper
INFO - 2023-12-04 15:20:09 --> Helper loaded: file_helper
INFO - 2023-12-04 15:20:09 --> Helper loaded: form_helper
INFO - 2023-12-04 15:20:09 --> Helper loaded: my_helper
INFO - 2023-12-04 15:20:09 --> Database Driver Class Initialized
INFO - 2023-12-04 15:20:09 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-04 15:20:09 --> Controller Class Initialized
INFO - 2023-12-04 15:20:09 --> Final output sent to browser
DEBUG - 2023-12-04 15:20:09 --> Total execution time: 0.0735
INFO - 2023-12-04 15:20:13 --> Config Class Initialized
INFO - 2023-12-04 15:20:13 --> Hooks Class Initialized
DEBUG - 2023-12-04 15:20:13 --> UTF-8 Support Enabled
INFO - 2023-12-04 15:20:13 --> Utf8 Class Initialized
INFO - 2023-12-04 15:20:13 --> URI Class Initialized
INFO - 2023-12-04 15:20:13 --> Router Class Initialized
INFO - 2023-12-04 15:20:13 --> Output Class Initialized
INFO - 2023-12-04 15:20:13 --> Security Class Initialized
DEBUG - 2023-12-04 15:20:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-04 15:20:13 --> Input Class Initialized
INFO - 2023-12-04 15:20:13 --> Language Class Initialized
INFO - 2023-12-04 15:20:13 --> Language Class Initialized
INFO - 2023-12-04 15:20:13 --> Config Class Initialized
INFO - 2023-12-04 15:20:13 --> Loader Class Initialized
INFO - 2023-12-04 15:20:13 --> Helper loaded: url_helper
INFO - 2023-12-04 15:20:13 --> Helper loaded: file_helper
INFO - 2023-12-04 15:20:13 --> Helper loaded: form_helper
INFO - 2023-12-04 15:20:13 --> Helper loaded: my_helper
INFO - 2023-12-04 15:20:13 --> Database Driver Class Initialized
INFO - 2023-12-04 15:20:13 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-04 15:20:13 --> Controller Class Initialized
INFO - 2023-12-04 15:20:13 --> Final output sent to browser
DEBUG - 2023-12-04 15:20:13 --> Total execution time: 0.0414
INFO - 2023-12-04 15:20:14 --> Config Class Initialized
INFO - 2023-12-04 15:20:14 --> Hooks Class Initialized
DEBUG - 2023-12-04 15:20:14 --> UTF-8 Support Enabled
INFO - 2023-12-04 15:20:14 --> Utf8 Class Initialized
INFO - 2023-12-04 15:20:14 --> URI Class Initialized
INFO - 2023-12-04 15:20:14 --> Router Class Initialized
INFO - 2023-12-04 15:20:14 --> Output Class Initialized
INFO - 2023-12-04 15:20:14 --> Security Class Initialized
DEBUG - 2023-12-04 15:20:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-04 15:20:14 --> Input Class Initialized
INFO - 2023-12-04 15:20:14 --> Language Class Initialized
INFO - 2023-12-04 15:20:14 --> Language Class Initialized
INFO - 2023-12-04 15:20:14 --> Config Class Initialized
INFO - 2023-12-04 15:20:14 --> Loader Class Initialized
INFO - 2023-12-04 15:20:14 --> Helper loaded: url_helper
INFO - 2023-12-04 15:20:14 --> Helper loaded: file_helper
INFO - 2023-12-04 15:20:14 --> Helper loaded: form_helper
INFO - 2023-12-04 15:20:14 --> Helper loaded: my_helper
INFO - 2023-12-04 15:20:14 --> Database Driver Class Initialized
INFO - 2023-12-04 15:20:14 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-04 15:20:14 --> Controller Class Initialized
INFO - 2023-12-04 15:20:14 --> Final output sent to browser
DEBUG - 2023-12-04 15:20:14 --> Total execution time: 0.0805
INFO - 2023-12-04 15:20:17 --> Config Class Initialized
INFO - 2023-12-04 15:20:17 --> Hooks Class Initialized
DEBUG - 2023-12-04 15:20:17 --> UTF-8 Support Enabled
INFO - 2023-12-04 15:20:17 --> Utf8 Class Initialized
INFO - 2023-12-04 15:20:17 --> URI Class Initialized
INFO - 2023-12-04 15:20:17 --> Router Class Initialized
INFO - 2023-12-04 15:20:17 --> Output Class Initialized
INFO - 2023-12-04 15:20:17 --> Security Class Initialized
DEBUG - 2023-12-04 15:20:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-04 15:20:17 --> Input Class Initialized
INFO - 2023-12-04 15:20:17 --> Language Class Initialized
INFO - 2023-12-04 15:20:17 --> Language Class Initialized
INFO - 2023-12-04 15:20:17 --> Config Class Initialized
INFO - 2023-12-04 15:20:17 --> Loader Class Initialized
INFO - 2023-12-04 15:20:17 --> Helper loaded: url_helper
INFO - 2023-12-04 15:20:17 --> Helper loaded: file_helper
INFO - 2023-12-04 15:20:17 --> Helper loaded: form_helper
INFO - 2023-12-04 15:20:17 --> Helper loaded: my_helper
INFO - 2023-12-04 15:20:17 --> Database Driver Class Initialized
INFO - 2023-12-04 15:20:17 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-04 15:20:17 --> Controller Class Initialized
INFO - 2023-12-04 15:20:17 --> Final output sent to browser
DEBUG - 2023-12-04 15:20:17 --> Total execution time: 0.0427
INFO - 2023-12-04 15:20:18 --> Config Class Initialized
INFO - 2023-12-04 15:20:19 --> Hooks Class Initialized
DEBUG - 2023-12-04 15:20:19 --> UTF-8 Support Enabled
INFO - 2023-12-04 15:20:19 --> Utf8 Class Initialized
INFO - 2023-12-04 15:20:19 --> URI Class Initialized
INFO - 2023-12-04 15:20:19 --> Router Class Initialized
INFO - 2023-12-04 15:20:19 --> Output Class Initialized
INFO - 2023-12-04 15:20:19 --> Security Class Initialized
DEBUG - 2023-12-04 15:20:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-04 15:20:19 --> Input Class Initialized
INFO - 2023-12-04 15:20:19 --> Language Class Initialized
INFO - 2023-12-04 15:20:19 --> Language Class Initialized
INFO - 2023-12-04 15:20:19 --> Config Class Initialized
INFO - 2023-12-04 15:20:19 --> Loader Class Initialized
INFO - 2023-12-04 15:20:19 --> Helper loaded: url_helper
INFO - 2023-12-04 15:20:19 --> Helper loaded: file_helper
INFO - 2023-12-04 15:20:19 --> Helper loaded: form_helper
INFO - 2023-12-04 15:20:19 --> Helper loaded: my_helper
INFO - 2023-12-04 15:20:19 --> Database Driver Class Initialized
INFO - 2023-12-04 15:20:19 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-04 15:20:19 --> Controller Class Initialized
INFO - 2023-12-04 15:20:19 --> Final output sent to browser
DEBUG - 2023-12-04 15:20:19 --> Total execution time: 0.0820
INFO - 2023-12-04 15:20:21 --> Config Class Initialized
INFO - 2023-12-04 15:20:21 --> Hooks Class Initialized
DEBUG - 2023-12-04 15:20:21 --> UTF-8 Support Enabled
INFO - 2023-12-04 15:20:21 --> Utf8 Class Initialized
INFO - 2023-12-04 15:20:21 --> URI Class Initialized
INFO - 2023-12-04 15:20:21 --> Router Class Initialized
INFO - 2023-12-04 15:20:21 --> Output Class Initialized
INFO - 2023-12-04 15:20:21 --> Security Class Initialized
DEBUG - 2023-12-04 15:20:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-04 15:20:21 --> Input Class Initialized
INFO - 2023-12-04 15:20:21 --> Language Class Initialized
INFO - 2023-12-04 15:20:21 --> Language Class Initialized
INFO - 2023-12-04 15:20:21 --> Config Class Initialized
INFO - 2023-12-04 15:20:21 --> Loader Class Initialized
INFO - 2023-12-04 15:20:21 --> Helper loaded: url_helper
INFO - 2023-12-04 15:20:21 --> Helper loaded: file_helper
INFO - 2023-12-04 15:20:21 --> Helper loaded: form_helper
INFO - 2023-12-04 15:20:21 --> Helper loaded: my_helper
INFO - 2023-12-04 15:20:21 --> Database Driver Class Initialized
INFO - 2023-12-04 15:20:21 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-04 15:20:21 --> Controller Class Initialized
INFO - 2023-12-04 15:20:21 --> Final output sent to browser
DEBUG - 2023-12-04 15:20:21 --> Total execution time: 0.0585
INFO - 2023-12-04 15:20:40 --> Config Class Initialized
INFO - 2023-12-04 15:20:40 --> Hooks Class Initialized
DEBUG - 2023-12-04 15:20:40 --> UTF-8 Support Enabled
INFO - 2023-12-04 15:20:40 --> Utf8 Class Initialized
INFO - 2023-12-04 15:20:40 --> URI Class Initialized
INFO - 2023-12-04 15:20:40 --> Router Class Initialized
INFO - 2023-12-04 15:20:40 --> Output Class Initialized
INFO - 2023-12-04 15:20:40 --> Security Class Initialized
DEBUG - 2023-12-04 15:20:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-04 15:20:40 --> Input Class Initialized
INFO - 2023-12-04 15:20:40 --> Language Class Initialized
INFO - 2023-12-04 15:20:40 --> Language Class Initialized
INFO - 2023-12-04 15:20:40 --> Config Class Initialized
INFO - 2023-12-04 15:20:40 --> Loader Class Initialized
INFO - 2023-12-04 15:20:40 --> Helper loaded: url_helper
INFO - 2023-12-04 15:20:40 --> Helper loaded: file_helper
INFO - 2023-12-04 15:20:40 --> Helper loaded: form_helper
INFO - 2023-12-04 15:20:40 --> Helper loaded: my_helper
INFO - 2023-12-04 15:20:40 --> Database Driver Class Initialized
INFO - 2023-12-04 15:20:40 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-04 15:20:40 --> Controller Class Initialized
DEBUG - 2023-12-04 15:20:40 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/riwayat_mengajar/views/list.php
DEBUG - 2023-12-04 15:20:40 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-12-04 15:20:40 --> Final output sent to browser
DEBUG - 2023-12-04 15:20:40 --> Total execution time: 0.0420
INFO - 2023-12-04 15:20:45 --> Config Class Initialized
INFO - 2023-12-04 15:20:45 --> Hooks Class Initialized
DEBUG - 2023-12-04 15:20:45 --> UTF-8 Support Enabled
INFO - 2023-12-04 15:20:45 --> Utf8 Class Initialized
INFO - 2023-12-04 15:20:45 --> URI Class Initialized
INFO - 2023-12-04 15:20:45 --> Router Class Initialized
INFO - 2023-12-04 15:20:45 --> Output Class Initialized
INFO - 2023-12-04 15:20:45 --> Security Class Initialized
DEBUG - 2023-12-04 15:20:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-04 15:20:45 --> Input Class Initialized
INFO - 2023-12-04 15:20:45 --> Language Class Initialized
INFO - 2023-12-04 15:20:45 --> Language Class Initialized
INFO - 2023-12-04 15:20:45 --> Config Class Initialized
INFO - 2023-12-04 15:20:45 --> Loader Class Initialized
INFO - 2023-12-04 15:20:45 --> Helper loaded: url_helper
INFO - 2023-12-04 15:20:45 --> Helper loaded: file_helper
INFO - 2023-12-04 15:20:45 --> Helper loaded: form_helper
INFO - 2023-12-04 15:20:45 --> Helper loaded: my_helper
INFO - 2023-12-04 15:20:45 --> Database Driver Class Initialized
INFO - 2023-12-04 15:20:45 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-04 15:20:45 --> Controller Class Initialized
DEBUG - 2023-12-04 15:20:45 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_keterampilan/views/cetak.php
INFO - 2023-12-04 15:20:45 --> Final output sent to browser
DEBUG - 2023-12-04 15:20:45 --> Total execution time: 0.0508
INFO - 2023-12-04 15:20:51 --> Config Class Initialized
INFO - 2023-12-04 15:20:51 --> Hooks Class Initialized
DEBUG - 2023-12-04 15:20:51 --> UTF-8 Support Enabled
INFO - 2023-12-04 15:20:51 --> Utf8 Class Initialized
INFO - 2023-12-04 15:20:51 --> URI Class Initialized
INFO - 2023-12-04 15:20:51 --> Router Class Initialized
INFO - 2023-12-04 15:20:51 --> Output Class Initialized
INFO - 2023-12-04 15:20:51 --> Security Class Initialized
DEBUG - 2023-12-04 15:20:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-04 15:20:51 --> Input Class Initialized
INFO - 2023-12-04 15:20:51 --> Language Class Initialized
INFO - 2023-12-04 15:20:51 --> Language Class Initialized
INFO - 2023-12-04 15:20:51 --> Config Class Initialized
INFO - 2023-12-04 15:20:51 --> Loader Class Initialized
INFO - 2023-12-04 15:20:51 --> Helper loaded: url_helper
INFO - 2023-12-04 15:20:51 --> Helper loaded: file_helper
INFO - 2023-12-04 15:20:51 --> Helper loaded: form_helper
INFO - 2023-12-04 15:20:51 --> Helper loaded: my_helper
INFO - 2023-12-04 15:20:51 --> Database Driver Class Initialized
INFO - 2023-12-04 15:20:51 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-04 15:20:51 --> Controller Class Initialized
ERROR - 2023-12-04 15:20:51 --> Severity: Notice --> Undefined offset: 1 /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/controllers/N_pengetahuan.php 203
ERROR - 2023-12-04 15:20:51 --> Severity: Notice --> Undefined offset: 1 /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/controllers/N_pengetahuan.php 203
ERROR - 2023-12-04 15:20:51 --> Severity: Notice --> Undefined offset: 1 /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/controllers/N_pengetahuan.php 203
ERROR - 2023-12-04 15:20:51 --> Severity: Notice --> Undefined offset: 1 /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/controllers/N_pengetahuan.php 202
ERROR - 2023-12-04 15:20:51 --> Severity: Notice --> Undefined offset: 1 /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/controllers/N_pengetahuan.php 203
ERROR - 2023-12-04 15:20:51 --> Severity: Notice --> Undefined offset: 1 /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/controllers/N_pengetahuan.php 203
ERROR - 2023-12-04 15:20:51 --> Severity: Notice --> Undefined offset: 1 /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/controllers/N_pengetahuan.php 202
ERROR - 2023-12-04 15:20:51 --> Severity: Notice --> Undefined offset: 1 /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/controllers/N_pengetahuan.php 203
ERROR - 2023-12-04 15:20:51 --> Severity: Notice --> Undefined offset: 1 /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/controllers/N_pengetahuan.php 202
ERROR - 2023-12-04 15:20:51 --> Severity: Notice --> Undefined offset: 1 /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/controllers/N_pengetahuan.php 202
ERROR - 2023-12-04 15:20:51 --> Severity: Notice --> Undefined offset: 1 /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/controllers/N_pengetahuan.php 203
ERROR - 2023-12-04 15:20:51 --> Severity: Notice --> Undefined offset: 1 /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/controllers/N_pengetahuan.php 202
ERROR - 2023-12-04 15:20:51 --> Severity: Notice --> Undefined offset: 1 /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/controllers/N_pengetahuan.php 202
ERROR - 2023-12-04 15:20:51 --> Severity: Notice --> Undefined offset: 1 /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/controllers/N_pengetahuan.php 202
ERROR - 2023-12-04 15:20:51 --> Severity: Notice --> Undefined offset: 1 /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/controllers/N_pengetahuan.php 203
ERROR - 2023-12-04 15:20:51 --> Severity: Notice --> Undefined offset: 1 /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/controllers/N_pengetahuan.php 202
DEBUG - 2023-12-04 15:20:51 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/views/cetak.php
INFO - 2023-12-04 15:20:51 --> Final output sent to browser
DEBUG - 2023-12-04 15:20:51 --> Total execution time: 0.1020
INFO - 2023-12-04 15:21:00 --> Config Class Initialized
INFO - 2023-12-04 15:21:00 --> Hooks Class Initialized
DEBUG - 2023-12-04 15:21:00 --> UTF-8 Support Enabled
INFO - 2023-12-04 15:21:00 --> Utf8 Class Initialized
INFO - 2023-12-04 15:21:00 --> URI Class Initialized
INFO - 2023-12-04 15:21:00 --> Router Class Initialized
INFO - 2023-12-04 15:21:00 --> Output Class Initialized
INFO - 2023-12-04 15:21:00 --> Security Class Initialized
DEBUG - 2023-12-04 15:21:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-04 15:21:00 --> Input Class Initialized
INFO - 2023-12-04 15:21:00 --> Language Class Initialized
INFO - 2023-12-04 15:21:00 --> Language Class Initialized
INFO - 2023-12-04 15:21:00 --> Config Class Initialized
INFO - 2023-12-04 15:21:00 --> Loader Class Initialized
INFO - 2023-12-04 15:21:00 --> Helper loaded: url_helper
INFO - 2023-12-04 15:21:00 --> Helper loaded: file_helper
INFO - 2023-12-04 15:21:00 --> Helper loaded: form_helper
INFO - 2023-12-04 15:21:00 --> Helper loaded: my_helper
INFO - 2023-12-04 15:21:00 --> Database Driver Class Initialized
INFO - 2023-12-04 15:21:00 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-04 15:21:00 --> Controller Class Initialized
DEBUG - 2023-12-04 15:21:00 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/view_mapel/views/v_view_mapel.php
DEBUG - 2023-12-04 15:21:00 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-12-04 15:21:00 --> Final output sent to browser
DEBUG - 2023-12-04 15:21:00 --> Total execution time: 0.0391
INFO - 2023-12-04 15:21:02 --> Config Class Initialized
INFO - 2023-12-04 15:21:02 --> Hooks Class Initialized
DEBUG - 2023-12-04 15:21:02 --> UTF-8 Support Enabled
INFO - 2023-12-04 15:21:02 --> Utf8 Class Initialized
INFO - 2023-12-04 15:21:02 --> URI Class Initialized
INFO - 2023-12-04 15:21:02 --> Router Class Initialized
INFO - 2023-12-04 15:21:02 --> Output Class Initialized
INFO - 2023-12-04 15:21:02 --> Security Class Initialized
DEBUG - 2023-12-04 15:21:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-04 15:21:02 --> Input Class Initialized
INFO - 2023-12-04 15:21:02 --> Language Class Initialized
INFO - 2023-12-04 15:21:02 --> Language Class Initialized
INFO - 2023-12-04 15:21:02 --> Config Class Initialized
INFO - 2023-12-04 15:21:02 --> Loader Class Initialized
INFO - 2023-12-04 15:21:02 --> Helper loaded: url_helper
INFO - 2023-12-04 15:21:02 --> Helper loaded: file_helper
INFO - 2023-12-04 15:21:02 --> Helper loaded: form_helper
INFO - 2023-12-04 15:21:02 --> Helper loaded: my_helper
INFO - 2023-12-04 15:21:02 --> Database Driver Class Initialized
INFO - 2023-12-04 15:21:02 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-04 15:21:02 --> Controller Class Initialized
DEBUG - 2023-12-04 15:21:02 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_catatan_guru/views/list.php
DEBUG - 2023-12-04 15:21:02 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-12-04 15:21:02 --> Final output sent to browser
DEBUG - 2023-12-04 15:21:02 --> Total execution time: 0.0425
INFO - 2023-12-04 15:21:05 --> Config Class Initialized
INFO - 2023-12-04 15:21:05 --> Hooks Class Initialized
DEBUG - 2023-12-04 15:21:05 --> UTF-8 Support Enabled
INFO - 2023-12-04 15:21:05 --> Utf8 Class Initialized
INFO - 2023-12-04 15:21:05 --> URI Class Initialized
INFO - 2023-12-04 15:21:05 --> Router Class Initialized
INFO - 2023-12-04 15:21:05 --> Output Class Initialized
INFO - 2023-12-04 15:21:05 --> Security Class Initialized
DEBUG - 2023-12-04 15:21:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-04 15:21:05 --> Input Class Initialized
INFO - 2023-12-04 15:21:05 --> Language Class Initialized
INFO - 2023-12-04 15:21:05 --> Language Class Initialized
INFO - 2023-12-04 15:21:05 --> Config Class Initialized
INFO - 2023-12-04 15:21:05 --> Loader Class Initialized
INFO - 2023-12-04 15:21:05 --> Helper loaded: url_helper
INFO - 2023-12-04 15:21:05 --> Helper loaded: file_helper
INFO - 2023-12-04 15:21:05 --> Helper loaded: form_helper
INFO - 2023-12-04 15:21:05 --> Helper loaded: my_helper
INFO - 2023-12-04 15:21:05 --> Database Driver Class Initialized
INFO - 2023-12-04 15:21:05 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-04 15:21:05 --> Controller Class Initialized
INFO - 2023-12-04 15:21:05 --> Final output sent to browser
DEBUG - 2023-12-04 15:21:05 --> Total execution time: 0.0502
INFO - 2023-12-04 15:33:52 --> Config Class Initialized
INFO - 2023-12-04 15:33:52 --> Hooks Class Initialized
DEBUG - 2023-12-04 15:33:52 --> UTF-8 Support Enabled
INFO - 2023-12-04 15:33:52 --> Utf8 Class Initialized
INFO - 2023-12-04 15:33:52 --> URI Class Initialized
INFO - 2023-12-04 15:33:52 --> Router Class Initialized
INFO - 2023-12-04 15:33:52 --> Output Class Initialized
INFO - 2023-12-04 15:33:52 --> Security Class Initialized
DEBUG - 2023-12-04 15:33:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-04 15:33:52 --> Input Class Initialized
INFO - 2023-12-04 15:33:52 --> Language Class Initialized
INFO - 2023-12-04 15:33:52 --> Language Class Initialized
INFO - 2023-12-04 15:33:52 --> Config Class Initialized
INFO - 2023-12-04 15:33:52 --> Loader Class Initialized
INFO - 2023-12-04 15:33:52 --> Helper loaded: url_helper
INFO - 2023-12-04 15:33:52 --> Helper loaded: file_helper
INFO - 2023-12-04 15:33:52 --> Helper loaded: form_helper
INFO - 2023-12-04 15:33:52 --> Helper loaded: my_helper
INFO - 2023-12-04 15:33:52 --> Database Driver Class Initialized
INFO - 2023-12-04 15:33:52 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-04 15:33:52 --> Controller Class Initialized
INFO - 2023-12-04 15:33:52 --> Config Class Initialized
INFO - 2023-12-04 15:33:52 --> Hooks Class Initialized
DEBUG - 2023-12-04 15:33:52 --> UTF-8 Support Enabled
INFO - 2023-12-04 15:33:52 --> Utf8 Class Initialized
INFO - 2023-12-04 15:33:52 --> URI Class Initialized
INFO - 2023-12-04 15:33:52 --> Router Class Initialized
INFO - 2023-12-04 15:33:52 --> Output Class Initialized
INFO - 2023-12-04 15:33:52 --> Security Class Initialized
DEBUG - 2023-12-04 15:33:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-04 15:33:52 --> Input Class Initialized
INFO - 2023-12-04 15:33:52 --> Language Class Initialized
INFO - 2023-12-04 15:33:52 --> Language Class Initialized
INFO - 2023-12-04 15:33:52 --> Config Class Initialized
INFO - 2023-12-04 15:33:52 --> Loader Class Initialized
INFO - 2023-12-04 15:33:52 --> Helper loaded: url_helper
INFO - 2023-12-04 15:33:52 --> Helper loaded: file_helper
INFO - 2023-12-04 15:33:52 --> Helper loaded: form_helper
INFO - 2023-12-04 15:33:52 --> Helper loaded: my_helper
INFO - 2023-12-04 15:33:52 --> Database Driver Class Initialized
INFO - 2023-12-04 15:33:52 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-04 15:33:52 --> Controller Class Initialized
DEBUG - 2023-12-04 15:33:52 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/login/views/login.php
DEBUG - 2023-12-04 15:33:52 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-12-04 15:33:52 --> Final output sent to browser
DEBUG - 2023-12-04 15:33:52 --> Total execution time: 0.0377
INFO - 2023-12-04 15:33:57 --> Config Class Initialized
INFO - 2023-12-04 15:33:57 --> Hooks Class Initialized
DEBUG - 2023-12-04 15:33:57 --> UTF-8 Support Enabled
INFO - 2023-12-04 15:33:57 --> Utf8 Class Initialized
INFO - 2023-12-04 15:33:57 --> URI Class Initialized
INFO - 2023-12-04 15:33:57 --> Router Class Initialized
INFO - 2023-12-04 15:33:57 --> Output Class Initialized
INFO - 2023-12-04 15:33:57 --> Security Class Initialized
DEBUG - 2023-12-04 15:33:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-04 15:33:57 --> Input Class Initialized
INFO - 2023-12-04 15:33:57 --> Language Class Initialized
INFO - 2023-12-04 15:33:57 --> Language Class Initialized
INFO - 2023-12-04 15:33:57 --> Config Class Initialized
INFO - 2023-12-04 15:33:57 --> Loader Class Initialized
INFO - 2023-12-04 15:33:57 --> Helper loaded: url_helper
INFO - 2023-12-04 15:33:57 --> Helper loaded: file_helper
INFO - 2023-12-04 15:33:57 --> Helper loaded: form_helper
INFO - 2023-12-04 15:33:57 --> Helper loaded: my_helper
INFO - 2023-12-04 15:33:57 --> Database Driver Class Initialized
INFO - 2023-12-04 15:33:57 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-04 15:33:57 --> Controller Class Initialized
INFO - 2023-12-04 15:33:57 --> Helper loaded: cookie_helper
INFO - 2023-12-04 15:33:57 --> Final output sent to browser
DEBUG - 2023-12-04 15:33:57 --> Total execution time: 0.0533
INFO - 2023-12-04 15:33:57 --> Config Class Initialized
INFO - 2023-12-04 15:33:57 --> Hooks Class Initialized
DEBUG - 2023-12-04 15:33:57 --> UTF-8 Support Enabled
INFO - 2023-12-04 15:33:57 --> Utf8 Class Initialized
INFO - 2023-12-04 15:33:57 --> URI Class Initialized
INFO - 2023-12-04 15:33:57 --> Router Class Initialized
INFO - 2023-12-04 15:33:57 --> Output Class Initialized
INFO - 2023-12-04 15:33:57 --> Security Class Initialized
DEBUG - 2023-12-04 15:33:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-04 15:33:57 --> Input Class Initialized
INFO - 2023-12-04 15:33:57 --> Language Class Initialized
INFO - 2023-12-04 15:33:57 --> Language Class Initialized
INFO - 2023-12-04 15:33:57 --> Config Class Initialized
INFO - 2023-12-04 15:33:57 --> Loader Class Initialized
INFO - 2023-12-04 15:33:57 --> Helper loaded: url_helper
INFO - 2023-12-04 15:33:57 --> Helper loaded: file_helper
INFO - 2023-12-04 15:33:57 --> Helper loaded: form_helper
INFO - 2023-12-04 15:33:57 --> Helper loaded: my_helper
INFO - 2023-12-04 15:33:57 --> Database Driver Class Initialized
INFO - 2023-12-04 15:33:57 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-04 15:33:57 --> Controller Class Initialized
DEBUG - 2023-12-04 15:33:57 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/home/views/v_home_guru.php
DEBUG - 2023-12-04 15:33:57 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-12-04 15:33:57 --> Final output sent to browser
DEBUG - 2023-12-04 15:33:57 --> Total execution time: 0.0454
INFO - 2023-12-04 15:34:00 --> Config Class Initialized
INFO - 2023-12-04 15:34:00 --> Hooks Class Initialized
DEBUG - 2023-12-04 15:34:00 --> UTF-8 Support Enabled
INFO - 2023-12-04 15:34:00 --> Utf8 Class Initialized
INFO - 2023-12-04 15:34:00 --> URI Class Initialized
INFO - 2023-12-04 15:34:00 --> Router Class Initialized
INFO - 2023-12-04 15:34:00 --> Output Class Initialized
INFO - 2023-12-04 15:34:00 --> Security Class Initialized
DEBUG - 2023-12-04 15:34:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-04 15:34:00 --> Input Class Initialized
INFO - 2023-12-04 15:34:00 --> Language Class Initialized
INFO - 2023-12-04 15:34:00 --> Language Class Initialized
INFO - 2023-12-04 15:34:00 --> Config Class Initialized
INFO - 2023-12-04 15:34:00 --> Loader Class Initialized
INFO - 2023-12-04 15:34:00 --> Helper loaded: url_helper
INFO - 2023-12-04 15:34:00 --> Helper loaded: file_helper
INFO - 2023-12-04 15:34:00 --> Helper loaded: form_helper
INFO - 2023-12-04 15:34:00 --> Helper loaded: my_helper
INFO - 2023-12-04 15:34:00 --> Database Driver Class Initialized
INFO - 2023-12-04 15:34:00 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-04 15:34:00 --> Controller Class Initialized
DEBUG - 2023-12-04 15:34:00 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/view_mapel/views/v_view_mapel.php
DEBUG - 2023-12-04 15:34:00 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-12-04 15:34:00 --> Final output sent to browser
DEBUG - 2023-12-04 15:34:00 --> Total execution time: 0.0448
INFO - 2023-12-04 15:34:02 --> Config Class Initialized
INFO - 2023-12-04 15:34:02 --> Hooks Class Initialized
DEBUG - 2023-12-04 15:34:02 --> UTF-8 Support Enabled
INFO - 2023-12-04 15:34:02 --> Utf8 Class Initialized
INFO - 2023-12-04 15:34:02 --> URI Class Initialized
INFO - 2023-12-04 15:34:02 --> Router Class Initialized
INFO - 2023-12-04 15:34:02 --> Output Class Initialized
INFO - 2023-12-04 15:34:02 --> Security Class Initialized
DEBUG - 2023-12-04 15:34:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-04 15:34:02 --> Input Class Initialized
INFO - 2023-12-04 15:34:02 --> Language Class Initialized
INFO - 2023-12-04 15:34:02 --> Language Class Initialized
INFO - 2023-12-04 15:34:02 --> Config Class Initialized
INFO - 2023-12-04 15:34:02 --> Loader Class Initialized
INFO - 2023-12-04 15:34:02 --> Helper loaded: url_helper
INFO - 2023-12-04 15:34:02 --> Helper loaded: file_helper
INFO - 2023-12-04 15:34:02 --> Helper loaded: form_helper
INFO - 2023-12-04 15:34:02 --> Helper loaded: my_helper
INFO - 2023-12-04 15:34:02 --> Database Driver Class Initialized
INFO - 2023-12-04 15:34:02 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-04 15:34:02 --> Controller Class Initialized
DEBUG - 2023-12-04 15:34:02 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/views/list.php
DEBUG - 2023-12-04 15:34:02 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-12-04 15:34:02 --> Final output sent to browser
DEBUG - 2023-12-04 15:34:02 --> Total execution time: 0.0705
INFO - 2023-12-04 15:34:02 --> Config Class Initialized
INFO - 2023-12-04 15:34:02 --> Hooks Class Initialized
DEBUG - 2023-12-04 15:34:02 --> UTF-8 Support Enabled
INFO - 2023-12-04 15:34:02 --> Utf8 Class Initialized
INFO - 2023-12-04 15:34:02 --> URI Class Initialized
INFO - 2023-12-04 15:34:02 --> Router Class Initialized
INFO - 2023-12-04 15:34:02 --> Output Class Initialized
INFO - 2023-12-04 15:34:02 --> Security Class Initialized
DEBUG - 2023-12-04 15:34:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-04 15:34:02 --> Input Class Initialized
INFO - 2023-12-04 15:34:02 --> Language Class Initialized
INFO - 2023-12-04 15:34:02 --> Language Class Initialized
INFO - 2023-12-04 15:34:02 --> Config Class Initialized
INFO - 2023-12-04 15:34:02 --> Loader Class Initialized
INFO - 2023-12-04 15:34:02 --> Helper loaded: url_helper
INFO - 2023-12-04 15:34:02 --> Helper loaded: file_helper
INFO - 2023-12-04 15:34:02 --> Helper loaded: form_helper
INFO - 2023-12-04 15:34:02 --> Helper loaded: my_helper
INFO - 2023-12-04 15:34:02 --> Database Driver Class Initialized
INFO - 2023-12-04 15:34:02 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-04 15:34:02 --> Controller Class Initialized
INFO - 2023-12-04 15:34:04 --> Config Class Initialized
INFO - 2023-12-04 15:34:04 --> Hooks Class Initialized
DEBUG - 2023-12-04 15:34:04 --> UTF-8 Support Enabled
INFO - 2023-12-04 15:34:04 --> Utf8 Class Initialized
INFO - 2023-12-04 15:34:04 --> URI Class Initialized
INFO - 2023-12-04 15:34:04 --> Router Class Initialized
INFO - 2023-12-04 15:34:04 --> Output Class Initialized
INFO - 2023-12-04 15:34:04 --> Security Class Initialized
DEBUG - 2023-12-04 15:34:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-04 15:34:04 --> Input Class Initialized
INFO - 2023-12-04 15:34:04 --> Language Class Initialized
INFO - 2023-12-04 15:34:04 --> Language Class Initialized
INFO - 2023-12-04 15:34:04 --> Config Class Initialized
INFO - 2023-12-04 15:34:04 --> Loader Class Initialized
INFO - 2023-12-04 15:34:04 --> Helper loaded: url_helper
INFO - 2023-12-04 15:34:04 --> Helper loaded: file_helper
INFO - 2023-12-04 15:34:04 --> Helper loaded: form_helper
INFO - 2023-12-04 15:34:04 --> Helper loaded: my_helper
INFO - 2023-12-04 15:34:04 --> Database Driver Class Initialized
INFO - 2023-12-04 15:34:04 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-04 15:34:04 --> Controller Class Initialized
INFO - 2023-12-04 16:01:16 --> Config Class Initialized
INFO - 2023-12-04 16:01:16 --> Hooks Class Initialized
DEBUG - 2023-12-04 16:01:16 --> UTF-8 Support Enabled
INFO - 2023-12-04 16:01:16 --> Utf8 Class Initialized
INFO - 2023-12-04 16:01:16 --> URI Class Initialized
INFO - 2023-12-04 16:01:16 --> Router Class Initialized
INFO - 2023-12-04 16:01:16 --> Output Class Initialized
INFO - 2023-12-04 16:01:16 --> Security Class Initialized
DEBUG - 2023-12-04 16:01:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-04 16:01:16 --> Input Class Initialized
INFO - 2023-12-04 16:01:16 --> Language Class Initialized
INFO - 2023-12-04 16:01:16 --> Language Class Initialized
INFO - 2023-12-04 16:01:16 --> Config Class Initialized
INFO - 2023-12-04 16:01:16 --> Loader Class Initialized
INFO - 2023-12-04 16:01:16 --> Helper loaded: url_helper
INFO - 2023-12-04 16:01:16 --> Helper loaded: file_helper
INFO - 2023-12-04 16:01:16 --> Helper loaded: form_helper
INFO - 2023-12-04 16:01:16 --> Helper loaded: my_helper
INFO - 2023-12-04 16:01:16 --> Database Driver Class Initialized
INFO - 2023-12-04 16:01:16 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-04 16:01:16 --> Controller Class Initialized
DEBUG - 2023-12-04 16:01:16 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/views/list.php
DEBUG - 2023-12-04 16:01:16 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-12-04 16:01:16 --> Final output sent to browser
DEBUG - 2023-12-04 16:01:16 --> Total execution time: 0.1350
INFO - 2023-12-04 16:01:16 --> Config Class Initialized
INFO - 2023-12-04 16:01:16 --> Hooks Class Initialized
DEBUG - 2023-12-04 16:01:16 --> UTF-8 Support Enabled
INFO - 2023-12-04 16:01:16 --> Utf8 Class Initialized
INFO - 2023-12-04 16:01:16 --> URI Class Initialized
INFO - 2023-12-04 16:01:16 --> Router Class Initialized
INFO - 2023-12-04 16:01:16 --> Output Class Initialized
INFO - 2023-12-04 16:01:16 --> Security Class Initialized
DEBUG - 2023-12-04 16:01:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-04 16:01:16 --> Input Class Initialized
INFO - 2023-12-04 16:01:16 --> Language Class Initialized
INFO - 2023-12-04 16:01:16 --> Language Class Initialized
INFO - 2023-12-04 16:01:16 --> Config Class Initialized
INFO - 2023-12-04 16:01:16 --> Loader Class Initialized
INFO - 2023-12-04 16:01:16 --> Helper loaded: url_helper
INFO - 2023-12-04 16:01:16 --> Helper loaded: file_helper
INFO - 2023-12-04 16:01:16 --> Helper loaded: form_helper
INFO - 2023-12-04 16:01:16 --> Helper loaded: my_helper
INFO - 2023-12-04 16:01:16 --> Database Driver Class Initialized
INFO - 2023-12-04 16:01:16 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-04 16:01:16 --> Controller Class Initialized
INFO - 2023-12-04 16:05:53 --> Config Class Initialized
INFO - 2023-12-04 16:05:53 --> Hooks Class Initialized
DEBUG - 2023-12-04 16:05:53 --> UTF-8 Support Enabled
INFO - 2023-12-04 16:05:53 --> Utf8 Class Initialized
INFO - 2023-12-04 16:05:53 --> URI Class Initialized
DEBUG - 2023-12-04 16:05:53 --> No URI present. Default controller set.
INFO - 2023-12-04 16:05:53 --> Router Class Initialized
INFO - 2023-12-04 16:05:53 --> Output Class Initialized
INFO - 2023-12-04 16:05:53 --> Security Class Initialized
DEBUG - 2023-12-04 16:05:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-04 16:05:53 --> Input Class Initialized
INFO - 2023-12-04 16:05:53 --> Language Class Initialized
INFO - 2023-12-04 16:05:53 --> Language Class Initialized
INFO - 2023-12-04 16:05:53 --> Config Class Initialized
INFO - 2023-12-04 16:05:53 --> Loader Class Initialized
INFO - 2023-12-04 16:05:53 --> Helper loaded: url_helper
INFO - 2023-12-04 16:05:53 --> Helper loaded: file_helper
INFO - 2023-12-04 16:05:53 --> Helper loaded: form_helper
INFO - 2023-12-04 16:05:53 --> Helper loaded: my_helper
INFO - 2023-12-04 16:05:53 --> Database Driver Class Initialized
INFO - 2023-12-04 16:05:53 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-04 16:05:53 --> Controller Class Initialized
INFO - 2023-12-04 16:05:53 --> Config Class Initialized
INFO - 2023-12-04 16:05:53 --> Hooks Class Initialized
DEBUG - 2023-12-04 16:05:53 --> UTF-8 Support Enabled
INFO - 2023-12-04 16:05:53 --> Utf8 Class Initialized
INFO - 2023-12-04 16:05:53 --> URI Class Initialized
INFO - 2023-12-04 16:05:53 --> Router Class Initialized
INFO - 2023-12-04 16:05:53 --> Output Class Initialized
INFO - 2023-12-04 16:05:53 --> Security Class Initialized
DEBUG - 2023-12-04 16:05:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-04 16:05:53 --> Input Class Initialized
INFO - 2023-12-04 16:05:53 --> Language Class Initialized
INFO - 2023-12-04 16:05:53 --> Language Class Initialized
INFO - 2023-12-04 16:05:53 --> Config Class Initialized
INFO - 2023-12-04 16:05:53 --> Loader Class Initialized
INFO - 2023-12-04 16:05:53 --> Helper loaded: url_helper
INFO - 2023-12-04 16:05:53 --> Helper loaded: file_helper
INFO - 2023-12-04 16:05:53 --> Helper loaded: form_helper
INFO - 2023-12-04 16:05:53 --> Helper loaded: my_helper
INFO - 2023-12-04 16:05:53 --> Database Driver Class Initialized
INFO - 2023-12-04 16:05:53 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-04 16:05:53 --> Controller Class Initialized
DEBUG - 2023-12-04 16:05:53 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/login/views/login.php
DEBUG - 2023-12-04 16:05:53 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-12-04 16:05:53 --> Final output sent to browser
DEBUG - 2023-12-04 16:05:53 --> Total execution time: 0.0380
INFO - 2023-12-04 16:05:56 --> Config Class Initialized
INFO - 2023-12-04 16:05:56 --> Hooks Class Initialized
DEBUG - 2023-12-04 16:05:56 --> UTF-8 Support Enabled
INFO - 2023-12-04 16:05:56 --> Utf8 Class Initialized
INFO - 2023-12-04 16:05:56 --> URI Class Initialized
INFO - 2023-12-04 16:05:56 --> Router Class Initialized
INFO - 2023-12-04 16:05:56 --> Output Class Initialized
INFO - 2023-12-04 16:05:56 --> Security Class Initialized
DEBUG - 2023-12-04 16:05:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-04 16:05:56 --> Input Class Initialized
INFO - 2023-12-04 16:05:56 --> Language Class Initialized
INFO - 2023-12-04 16:05:56 --> Language Class Initialized
INFO - 2023-12-04 16:05:56 --> Config Class Initialized
INFO - 2023-12-04 16:05:56 --> Loader Class Initialized
INFO - 2023-12-04 16:05:56 --> Helper loaded: url_helper
INFO - 2023-12-04 16:05:56 --> Helper loaded: file_helper
INFO - 2023-12-04 16:05:56 --> Helper loaded: form_helper
INFO - 2023-12-04 16:05:56 --> Helper loaded: my_helper
INFO - 2023-12-04 16:05:56 --> Database Driver Class Initialized
INFO - 2023-12-04 16:05:56 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-04 16:05:56 --> Controller Class Initialized
INFO - 2023-12-04 16:05:56 --> Final output sent to browser
DEBUG - 2023-12-04 16:05:56 --> Total execution time: 0.2471
INFO - 2023-12-04 16:06:08 --> Config Class Initialized
INFO - 2023-12-04 16:06:08 --> Hooks Class Initialized
DEBUG - 2023-12-04 16:06:08 --> UTF-8 Support Enabled
INFO - 2023-12-04 16:06:08 --> Utf8 Class Initialized
INFO - 2023-12-04 16:06:08 --> URI Class Initialized
INFO - 2023-12-04 16:06:08 --> Router Class Initialized
INFO - 2023-12-04 16:06:08 --> Output Class Initialized
INFO - 2023-12-04 16:06:08 --> Security Class Initialized
DEBUG - 2023-12-04 16:06:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-04 16:06:08 --> Input Class Initialized
INFO - 2023-12-04 16:06:08 --> Language Class Initialized
INFO - 2023-12-04 16:06:08 --> Language Class Initialized
INFO - 2023-12-04 16:06:08 --> Config Class Initialized
INFO - 2023-12-04 16:06:08 --> Loader Class Initialized
INFO - 2023-12-04 16:06:08 --> Helper loaded: url_helper
INFO - 2023-12-04 16:06:08 --> Helper loaded: file_helper
INFO - 2023-12-04 16:06:08 --> Helper loaded: form_helper
INFO - 2023-12-04 16:06:08 --> Helper loaded: my_helper
INFO - 2023-12-04 16:06:08 --> Database Driver Class Initialized
INFO - 2023-12-04 16:06:08 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-04 16:06:08 --> Controller Class Initialized
INFO - 2023-12-04 16:06:08 --> Helper loaded: cookie_helper
INFO - 2023-12-04 16:06:08 --> Final output sent to browser
DEBUG - 2023-12-04 16:06:08 --> Total execution time: 0.0564
INFO - 2023-12-04 16:06:09 --> Config Class Initialized
INFO - 2023-12-04 16:06:09 --> Hooks Class Initialized
DEBUG - 2023-12-04 16:06:09 --> UTF-8 Support Enabled
INFO - 2023-12-04 16:06:09 --> Utf8 Class Initialized
INFO - 2023-12-04 16:06:09 --> URI Class Initialized
INFO - 2023-12-04 16:06:09 --> Router Class Initialized
INFO - 2023-12-04 16:06:09 --> Output Class Initialized
INFO - 2023-12-04 16:06:09 --> Security Class Initialized
DEBUG - 2023-12-04 16:06:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-04 16:06:09 --> Input Class Initialized
INFO - 2023-12-04 16:06:09 --> Language Class Initialized
INFO - 2023-12-04 16:06:09 --> Language Class Initialized
INFO - 2023-12-04 16:06:09 --> Config Class Initialized
INFO - 2023-12-04 16:06:09 --> Loader Class Initialized
INFO - 2023-12-04 16:06:09 --> Helper loaded: url_helper
INFO - 2023-12-04 16:06:09 --> Helper loaded: file_helper
INFO - 2023-12-04 16:06:09 --> Helper loaded: form_helper
INFO - 2023-12-04 16:06:09 --> Helper loaded: my_helper
INFO - 2023-12-04 16:06:09 --> Database Driver Class Initialized
INFO - 2023-12-04 16:06:09 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-04 16:06:09 --> Controller Class Initialized
DEBUG - 2023-12-04 16:06:09 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/home/views/v_home_guru.php
DEBUG - 2023-12-04 16:06:09 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-12-04 16:06:09 --> Final output sent to browser
DEBUG - 2023-12-04 16:06:09 --> Total execution time: 0.0509
INFO - 2023-12-04 16:06:12 --> Config Class Initialized
INFO - 2023-12-04 16:06:12 --> Hooks Class Initialized
DEBUG - 2023-12-04 16:06:12 --> UTF-8 Support Enabled
INFO - 2023-12-04 16:06:12 --> Utf8 Class Initialized
INFO - 2023-12-04 16:06:12 --> URI Class Initialized
INFO - 2023-12-04 16:06:12 --> Router Class Initialized
INFO - 2023-12-04 16:06:12 --> Output Class Initialized
INFO - 2023-12-04 16:06:12 --> Security Class Initialized
DEBUG - 2023-12-04 16:06:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-04 16:06:12 --> Input Class Initialized
INFO - 2023-12-04 16:06:12 --> Language Class Initialized
INFO - 2023-12-04 16:06:12 --> Language Class Initialized
INFO - 2023-12-04 16:06:12 --> Config Class Initialized
INFO - 2023-12-04 16:06:12 --> Loader Class Initialized
INFO - 2023-12-04 16:06:12 --> Helper loaded: url_helper
INFO - 2023-12-04 16:06:12 --> Helper loaded: file_helper
INFO - 2023-12-04 16:06:12 --> Helper loaded: form_helper
INFO - 2023-12-04 16:06:12 --> Helper loaded: my_helper
INFO - 2023-12-04 16:06:12 --> Database Driver Class Initialized
INFO - 2023-12-04 16:06:12 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-04 16:06:12 --> Controller Class Initialized
DEBUG - 2023-12-04 16:06:12 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/view_mapel/views/v_view_mapel.php
DEBUG - 2023-12-04 16:06:12 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-12-04 16:06:12 --> Final output sent to browser
DEBUG - 2023-12-04 16:06:12 --> Total execution time: 0.0420
INFO - 2023-12-04 16:06:15 --> Config Class Initialized
INFO - 2023-12-04 16:06:15 --> Hooks Class Initialized
DEBUG - 2023-12-04 16:06:15 --> UTF-8 Support Enabled
INFO - 2023-12-04 16:06:15 --> Utf8 Class Initialized
INFO - 2023-12-04 16:06:15 --> URI Class Initialized
INFO - 2023-12-04 16:06:15 --> Router Class Initialized
INFO - 2023-12-04 16:06:15 --> Output Class Initialized
INFO - 2023-12-04 16:06:15 --> Security Class Initialized
DEBUG - 2023-12-04 16:06:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-04 16:06:15 --> Input Class Initialized
INFO - 2023-12-04 16:06:15 --> Language Class Initialized
INFO - 2023-12-04 16:06:15 --> Language Class Initialized
INFO - 2023-12-04 16:06:15 --> Config Class Initialized
INFO - 2023-12-04 16:06:15 --> Loader Class Initialized
INFO - 2023-12-04 16:06:15 --> Helper loaded: url_helper
INFO - 2023-12-04 16:06:15 --> Helper loaded: file_helper
INFO - 2023-12-04 16:06:15 --> Helper loaded: form_helper
INFO - 2023-12-04 16:06:15 --> Helper loaded: my_helper
INFO - 2023-12-04 16:06:15 --> Database Driver Class Initialized
INFO - 2023-12-04 16:06:15 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-04 16:06:15 --> Controller Class Initialized
DEBUG - 2023-12-04 16:06:15 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/views/list.php
DEBUG - 2023-12-04 16:06:15 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-12-04 16:06:15 --> Final output sent to browser
DEBUG - 2023-12-04 16:06:15 --> Total execution time: 0.0560
INFO - 2023-12-04 16:06:16 --> Config Class Initialized
INFO - 2023-12-04 16:06:16 --> Hooks Class Initialized
DEBUG - 2023-12-04 16:06:16 --> UTF-8 Support Enabled
INFO - 2023-12-04 16:06:16 --> Utf8 Class Initialized
INFO - 2023-12-04 16:06:16 --> URI Class Initialized
INFO - 2023-12-04 16:06:16 --> Router Class Initialized
INFO - 2023-12-04 16:06:16 --> Output Class Initialized
INFO - 2023-12-04 16:06:16 --> Security Class Initialized
DEBUG - 2023-12-04 16:06:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-04 16:06:16 --> Input Class Initialized
INFO - 2023-12-04 16:06:16 --> Language Class Initialized
INFO - 2023-12-04 16:06:16 --> Language Class Initialized
INFO - 2023-12-04 16:06:16 --> Config Class Initialized
INFO - 2023-12-04 16:06:16 --> Loader Class Initialized
INFO - 2023-12-04 16:06:16 --> Helper loaded: url_helper
INFO - 2023-12-04 16:06:16 --> Helper loaded: file_helper
INFO - 2023-12-04 16:06:16 --> Helper loaded: form_helper
INFO - 2023-12-04 16:06:16 --> Helper loaded: my_helper
INFO - 2023-12-04 16:06:16 --> Database Driver Class Initialized
INFO - 2023-12-04 16:06:16 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-04 16:06:16 --> Controller Class Initialized
INFO - 2023-12-04 16:06:19 --> Config Class Initialized
INFO - 2023-12-04 16:06:19 --> Hooks Class Initialized
DEBUG - 2023-12-04 16:06:19 --> UTF-8 Support Enabled
INFO - 2023-12-04 16:06:19 --> Utf8 Class Initialized
INFO - 2023-12-04 16:06:19 --> URI Class Initialized
INFO - 2023-12-04 16:06:19 --> Router Class Initialized
INFO - 2023-12-04 16:06:19 --> Output Class Initialized
INFO - 2023-12-04 16:06:19 --> Security Class Initialized
DEBUG - 2023-12-04 16:06:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-04 16:06:19 --> Input Class Initialized
INFO - 2023-12-04 16:06:19 --> Language Class Initialized
INFO - 2023-12-04 16:06:19 --> Language Class Initialized
INFO - 2023-12-04 16:06:19 --> Config Class Initialized
INFO - 2023-12-04 16:06:19 --> Loader Class Initialized
INFO - 2023-12-04 16:06:19 --> Helper loaded: url_helper
INFO - 2023-12-04 16:06:19 --> Helper loaded: file_helper
INFO - 2023-12-04 16:06:19 --> Helper loaded: form_helper
INFO - 2023-12-04 16:06:19 --> Helper loaded: my_helper
INFO - 2023-12-04 16:06:19 --> Database Driver Class Initialized
INFO - 2023-12-04 16:06:19 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-04 16:06:19 --> Controller Class Initialized
INFO - 2023-12-04 16:06:19 --> Final output sent to browser
DEBUG - 2023-12-04 16:06:19 --> Total execution time: 0.0399
INFO - 2023-12-04 16:07:06 --> Config Class Initialized
INFO - 2023-12-04 16:07:06 --> Hooks Class Initialized
DEBUG - 2023-12-04 16:07:06 --> UTF-8 Support Enabled
INFO - 2023-12-04 16:07:06 --> Utf8 Class Initialized
INFO - 2023-12-04 16:07:06 --> URI Class Initialized
INFO - 2023-12-04 16:07:06 --> Router Class Initialized
INFO - 2023-12-04 16:07:06 --> Output Class Initialized
INFO - 2023-12-04 16:07:06 --> Security Class Initialized
DEBUG - 2023-12-04 16:07:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-04 16:07:06 --> Input Class Initialized
INFO - 2023-12-04 16:07:06 --> Language Class Initialized
INFO - 2023-12-04 16:07:06 --> Language Class Initialized
INFO - 2023-12-04 16:07:06 --> Config Class Initialized
INFO - 2023-12-04 16:07:06 --> Loader Class Initialized
INFO - 2023-12-04 16:07:06 --> Helper loaded: url_helper
INFO - 2023-12-04 16:07:06 --> Helper loaded: file_helper
INFO - 2023-12-04 16:07:06 --> Helper loaded: form_helper
INFO - 2023-12-04 16:07:06 --> Helper loaded: my_helper
INFO - 2023-12-04 16:07:06 --> Database Driver Class Initialized
INFO - 2023-12-04 16:07:06 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-04 16:07:06 --> Controller Class Initialized
INFO - 2023-12-04 16:07:06 --> Final output sent to browser
DEBUG - 2023-12-04 16:07:06 --> Total execution time: 0.0865
INFO - 2023-12-04 16:07:06 --> Config Class Initialized
INFO - 2023-12-04 16:07:06 --> Hooks Class Initialized
DEBUG - 2023-12-04 16:07:06 --> UTF-8 Support Enabled
INFO - 2023-12-04 16:07:06 --> Utf8 Class Initialized
INFO - 2023-12-04 16:07:06 --> URI Class Initialized
INFO - 2023-12-04 16:07:06 --> Router Class Initialized
INFO - 2023-12-04 16:07:06 --> Output Class Initialized
INFO - 2023-12-04 16:07:06 --> Security Class Initialized
DEBUG - 2023-12-04 16:07:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-04 16:07:06 --> Input Class Initialized
INFO - 2023-12-04 16:07:06 --> Language Class Initialized
INFO - 2023-12-04 16:07:06 --> Language Class Initialized
INFO - 2023-12-04 16:07:06 --> Config Class Initialized
INFO - 2023-12-04 16:07:06 --> Loader Class Initialized
INFO - 2023-12-04 16:07:06 --> Helper loaded: url_helper
INFO - 2023-12-04 16:07:06 --> Helper loaded: file_helper
INFO - 2023-12-04 16:07:06 --> Helper loaded: form_helper
INFO - 2023-12-04 16:07:06 --> Helper loaded: my_helper
INFO - 2023-12-04 16:07:06 --> Database Driver Class Initialized
INFO - 2023-12-04 16:07:06 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-04 16:07:06 --> Controller Class Initialized
INFO - 2023-12-04 16:07:18 --> Config Class Initialized
INFO - 2023-12-04 16:07:18 --> Hooks Class Initialized
DEBUG - 2023-12-04 16:07:18 --> UTF-8 Support Enabled
INFO - 2023-12-04 16:07:18 --> Utf8 Class Initialized
INFO - 2023-12-04 16:07:18 --> URI Class Initialized
INFO - 2023-12-04 16:07:18 --> Router Class Initialized
INFO - 2023-12-04 16:07:18 --> Output Class Initialized
INFO - 2023-12-04 16:07:18 --> Security Class Initialized
DEBUG - 2023-12-04 16:07:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-04 16:07:18 --> Input Class Initialized
INFO - 2023-12-04 16:07:18 --> Language Class Initialized
INFO - 2023-12-04 16:07:18 --> Language Class Initialized
INFO - 2023-12-04 16:07:18 --> Config Class Initialized
INFO - 2023-12-04 16:07:18 --> Loader Class Initialized
INFO - 2023-12-04 16:07:18 --> Helper loaded: url_helper
INFO - 2023-12-04 16:07:18 --> Helper loaded: file_helper
INFO - 2023-12-04 16:07:18 --> Helper loaded: form_helper
INFO - 2023-12-04 16:07:18 --> Helper loaded: my_helper
INFO - 2023-12-04 16:07:18 --> Database Driver Class Initialized
INFO - 2023-12-04 16:07:18 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-04 16:07:18 --> Controller Class Initialized
INFO - 2023-12-04 16:07:18 --> Final output sent to browser
DEBUG - 2023-12-04 16:07:18 --> Total execution time: 0.0516
INFO - 2023-12-04 16:07:25 --> Config Class Initialized
INFO - 2023-12-04 16:07:25 --> Hooks Class Initialized
DEBUG - 2023-12-04 16:07:25 --> UTF-8 Support Enabled
INFO - 2023-12-04 16:07:25 --> Utf8 Class Initialized
INFO - 2023-12-04 16:07:25 --> URI Class Initialized
INFO - 2023-12-04 16:07:25 --> Router Class Initialized
INFO - 2023-12-04 16:07:25 --> Output Class Initialized
INFO - 2023-12-04 16:07:25 --> Security Class Initialized
DEBUG - 2023-12-04 16:07:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-04 16:07:25 --> Input Class Initialized
INFO - 2023-12-04 16:07:25 --> Language Class Initialized
INFO - 2023-12-04 16:07:25 --> Language Class Initialized
INFO - 2023-12-04 16:07:25 --> Config Class Initialized
INFO - 2023-12-04 16:07:25 --> Loader Class Initialized
INFO - 2023-12-04 16:07:25 --> Helper loaded: url_helper
INFO - 2023-12-04 16:07:25 --> Helper loaded: file_helper
INFO - 2023-12-04 16:07:25 --> Helper loaded: form_helper
INFO - 2023-12-04 16:07:25 --> Helper loaded: my_helper
INFO - 2023-12-04 16:07:25 --> Database Driver Class Initialized
INFO - 2023-12-04 16:07:25 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-04 16:07:25 --> Controller Class Initialized
INFO - 2023-12-04 16:07:25 --> Final output sent to browser
DEBUG - 2023-12-04 16:07:25 --> Total execution time: 0.0494
INFO - 2023-12-04 16:07:25 --> Config Class Initialized
INFO - 2023-12-04 16:07:25 --> Hooks Class Initialized
DEBUG - 2023-12-04 16:07:25 --> UTF-8 Support Enabled
INFO - 2023-12-04 16:07:25 --> Utf8 Class Initialized
INFO - 2023-12-04 16:07:25 --> URI Class Initialized
INFO - 2023-12-04 16:07:25 --> Router Class Initialized
INFO - 2023-12-04 16:07:25 --> Output Class Initialized
INFO - 2023-12-04 16:07:25 --> Security Class Initialized
DEBUG - 2023-12-04 16:07:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-04 16:07:25 --> Input Class Initialized
INFO - 2023-12-04 16:07:25 --> Language Class Initialized
INFO - 2023-12-04 16:07:25 --> Language Class Initialized
INFO - 2023-12-04 16:07:25 --> Config Class Initialized
INFO - 2023-12-04 16:07:25 --> Loader Class Initialized
INFO - 2023-12-04 16:07:25 --> Helper loaded: url_helper
INFO - 2023-12-04 16:07:25 --> Helper loaded: file_helper
INFO - 2023-12-04 16:07:25 --> Helper loaded: form_helper
INFO - 2023-12-04 16:07:25 --> Helper loaded: my_helper
INFO - 2023-12-04 16:07:25 --> Database Driver Class Initialized
INFO - 2023-12-04 16:07:25 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-04 16:07:25 --> Controller Class Initialized
INFO - 2023-12-04 16:07:31 --> Config Class Initialized
INFO - 2023-12-04 16:07:31 --> Hooks Class Initialized
DEBUG - 2023-12-04 16:07:31 --> UTF-8 Support Enabled
INFO - 2023-12-04 16:07:31 --> Utf8 Class Initialized
INFO - 2023-12-04 16:07:31 --> URI Class Initialized
INFO - 2023-12-04 16:07:31 --> Router Class Initialized
INFO - 2023-12-04 16:07:31 --> Output Class Initialized
INFO - 2023-12-04 16:07:31 --> Security Class Initialized
DEBUG - 2023-12-04 16:07:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-04 16:07:31 --> Input Class Initialized
INFO - 2023-12-04 16:07:31 --> Language Class Initialized
INFO - 2023-12-04 16:07:31 --> Language Class Initialized
INFO - 2023-12-04 16:07:31 --> Config Class Initialized
INFO - 2023-12-04 16:07:31 --> Loader Class Initialized
INFO - 2023-12-04 16:07:31 --> Helper loaded: url_helper
INFO - 2023-12-04 16:07:31 --> Helper loaded: file_helper
INFO - 2023-12-04 16:07:31 --> Helper loaded: form_helper
INFO - 2023-12-04 16:07:31 --> Helper loaded: my_helper
INFO - 2023-12-04 16:07:31 --> Database Driver Class Initialized
INFO - 2023-12-04 16:07:31 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-04 16:07:31 --> Controller Class Initialized
INFO - 2023-12-04 16:07:31 --> Final output sent to browser
DEBUG - 2023-12-04 16:07:31 --> Total execution time: 0.0585
INFO - 2023-12-04 16:07:36 --> Config Class Initialized
INFO - 2023-12-04 16:07:36 --> Hooks Class Initialized
DEBUG - 2023-12-04 16:07:36 --> UTF-8 Support Enabled
INFO - 2023-12-04 16:07:36 --> Utf8 Class Initialized
INFO - 2023-12-04 16:07:36 --> URI Class Initialized
INFO - 2023-12-04 16:07:36 --> Router Class Initialized
INFO - 2023-12-04 16:07:36 --> Output Class Initialized
INFO - 2023-12-04 16:07:36 --> Security Class Initialized
DEBUG - 2023-12-04 16:07:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-04 16:07:36 --> Input Class Initialized
INFO - 2023-12-04 16:07:36 --> Language Class Initialized
INFO - 2023-12-04 16:07:36 --> Language Class Initialized
INFO - 2023-12-04 16:07:36 --> Config Class Initialized
INFO - 2023-12-04 16:07:36 --> Loader Class Initialized
INFO - 2023-12-04 16:07:36 --> Helper loaded: url_helper
INFO - 2023-12-04 16:07:36 --> Helper loaded: file_helper
INFO - 2023-12-04 16:07:36 --> Helper loaded: form_helper
INFO - 2023-12-04 16:07:36 --> Helper loaded: my_helper
INFO - 2023-12-04 16:07:36 --> Database Driver Class Initialized
INFO - 2023-12-04 16:07:36 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-04 16:07:36 --> Controller Class Initialized
INFO - 2023-12-04 16:07:36 --> Final output sent to browser
DEBUG - 2023-12-04 16:07:36 --> Total execution time: 0.0403
INFO - 2023-12-04 16:07:42 --> Config Class Initialized
INFO - 2023-12-04 16:07:42 --> Hooks Class Initialized
DEBUG - 2023-12-04 16:07:42 --> UTF-8 Support Enabled
INFO - 2023-12-04 16:07:42 --> Utf8 Class Initialized
INFO - 2023-12-04 16:07:42 --> URI Class Initialized
INFO - 2023-12-04 16:07:42 --> Router Class Initialized
INFO - 2023-12-04 16:07:42 --> Output Class Initialized
INFO - 2023-12-04 16:07:42 --> Security Class Initialized
DEBUG - 2023-12-04 16:07:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-04 16:07:42 --> Input Class Initialized
INFO - 2023-12-04 16:07:42 --> Language Class Initialized
INFO - 2023-12-04 16:07:42 --> Language Class Initialized
INFO - 2023-12-04 16:07:42 --> Config Class Initialized
INFO - 2023-12-04 16:07:42 --> Loader Class Initialized
INFO - 2023-12-04 16:07:42 --> Helper loaded: url_helper
INFO - 2023-12-04 16:07:42 --> Helper loaded: file_helper
INFO - 2023-12-04 16:07:42 --> Helper loaded: form_helper
INFO - 2023-12-04 16:07:42 --> Helper loaded: my_helper
INFO - 2023-12-04 16:07:42 --> Database Driver Class Initialized
INFO - 2023-12-04 16:07:42 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-04 16:07:42 --> Controller Class Initialized
INFO - 2023-12-04 16:07:42 --> Final output sent to browser
DEBUG - 2023-12-04 16:07:42 --> Total execution time: 0.0449
INFO - 2023-12-04 16:07:45 --> Config Class Initialized
INFO - 2023-12-04 16:07:45 --> Hooks Class Initialized
DEBUG - 2023-12-04 16:07:45 --> UTF-8 Support Enabled
INFO - 2023-12-04 16:07:45 --> Utf8 Class Initialized
INFO - 2023-12-04 16:07:45 --> URI Class Initialized
INFO - 2023-12-04 16:07:45 --> Router Class Initialized
INFO - 2023-12-04 16:07:45 --> Output Class Initialized
INFO - 2023-12-04 16:07:45 --> Security Class Initialized
DEBUG - 2023-12-04 16:07:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-04 16:07:45 --> Input Class Initialized
INFO - 2023-12-04 16:07:45 --> Language Class Initialized
INFO - 2023-12-04 16:07:45 --> Language Class Initialized
INFO - 2023-12-04 16:07:45 --> Config Class Initialized
INFO - 2023-12-04 16:07:45 --> Loader Class Initialized
INFO - 2023-12-04 16:07:45 --> Helper loaded: url_helper
INFO - 2023-12-04 16:07:45 --> Helper loaded: file_helper
INFO - 2023-12-04 16:07:45 --> Helper loaded: form_helper
INFO - 2023-12-04 16:07:45 --> Helper loaded: my_helper
INFO - 2023-12-04 16:07:45 --> Database Driver Class Initialized
INFO - 2023-12-04 16:07:45 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-04 16:07:45 --> Controller Class Initialized
INFO - 2023-12-04 16:07:45 --> Final output sent to browser
DEBUG - 2023-12-04 16:07:45 --> Total execution time: 0.0495
INFO - 2023-12-04 16:07:46 --> Config Class Initialized
INFO - 2023-12-04 16:07:46 --> Hooks Class Initialized
DEBUG - 2023-12-04 16:07:46 --> UTF-8 Support Enabled
INFO - 2023-12-04 16:07:46 --> Utf8 Class Initialized
INFO - 2023-12-04 16:07:46 --> URI Class Initialized
INFO - 2023-12-04 16:07:46 --> Router Class Initialized
INFO - 2023-12-04 16:07:46 --> Output Class Initialized
INFO - 2023-12-04 16:07:46 --> Security Class Initialized
DEBUG - 2023-12-04 16:07:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-04 16:07:46 --> Input Class Initialized
INFO - 2023-12-04 16:07:46 --> Language Class Initialized
INFO - 2023-12-04 16:07:46 --> Language Class Initialized
INFO - 2023-12-04 16:07:46 --> Config Class Initialized
INFO - 2023-12-04 16:07:46 --> Loader Class Initialized
INFO - 2023-12-04 16:07:46 --> Helper loaded: url_helper
INFO - 2023-12-04 16:07:46 --> Helper loaded: file_helper
INFO - 2023-12-04 16:07:46 --> Helper loaded: form_helper
INFO - 2023-12-04 16:07:46 --> Helper loaded: my_helper
INFO - 2023-12-04 16:07:46 --> Database Driver Class Initialized
INFO - 2023-12-04 16:07:46 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-04 16:07:46 --> Controller Class Initialized
INFO - 2023-12-04 16:07:46 --> Final output sent to browser
DEBUG - 2023-12-04 16:07:46 --> Total execution time: 0.0428
INFO - 2023-12-04 16:08:39 --> Config Class Initialized
INFO - 2023-12-04 16:08:39 --> Hooks Class Initialized
DEBUG - 2023-12-04 16:08:39 --> UTF-8 Support Enabled
INFO - 2023-12-04 16:08:39 --> Utf8 Class Initialized
INFO - 2023-12-04 16:08:39 --> URI Class Initialized
DEBUG - 2023-12-04 16:08:39 --> No URI present. Default controller set.
INFO - 2023-12-04 16:08:39 --> Router Class Initialized
INFO - 2023-12-04 16:08:39 --> Output Class Initialized
INFO - 2023-12-04 16:08:39 --> Security Class Initialized
DEBUG - 2023-12-04 16:08:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-04 16:08:39 --> Input Class Initialized
INFO - 2023-12-04 16:08:39 --> Language Class Initialized
INFO - 2023-12-04 16:08:39 --> Language Class Initialized
INFO - 2023-12-04 16:08:39 --> Config Class Initialized
INFO - 2023-12-04 16:08:39 --> Loader Class Initialized
INFO - 2023-12-04 16:08:39 --> Helper loaded: url_helper
INFO - 2023-12-04 16:08:39 --> Helper loaded: file_helper
INFO - 2023-12-04 16:08:39 --> Helper loaded: form_helper
INFO - 2023-12-04 16:08:39 --> Helper loaded: my_helper
INFO - 2023-12-04 16:08:39 --> Database Driver Class Initialized
INFO - 2023-12-04 16:08:39 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-04 16:08:39 --> Controller Class Initialized
INFO - 2023-12-04 16:08:39 --> Config Class Initialized
INFO - 2023-12-04 16:08:39 --> Hooks Class Initialized
DEBUG - 2023-12-04 16:08:39 --> UTF-8 Support Enabled
INFO - 2023-12-04 16:08:39 --> Utf8 Class Initialized
INFO - 2023-12-04 16:08:39 --> URI Class Initialized
INFO - 2023-12-04 16:08:39 --> Router Class Initialized
INFO - 2023-12-04 16:08:39 --> Output Class Initialized
INFO - 2023-12-04 16:08:39 --> Security Class Initialized
DEBUG - 2023-12-04 16:08:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-04 16:08:39 --> Input Class Initialized
INFO - 2023-12-04 16:08:39 --> Language Class Initialized
INFO - 2023-12-04 16:08:39 --> Language Class Initialized
INFO - 2023-12-04 16:08:39 --> Config Class Initialized
INFO - 2023-12-04 16:08:39 --> Loader Class Initialized
INFO - 2023-12-04 16:08:39 --> Helper loaded: url_helper
INFO - 2023-12-04 16:08:39 --> Helper loaded: file_helper
INFO - 2023-12-04 16:08:39 --> Helper loaded: form_helper
INFO - 2023-12-04 16:08:39 --> Helper loaded: my_helper
INFO - 2023-12-04 16:08:39 --> Database Driver Class Initialized
INFO - 2023-12-04 16:08:39 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-04 16:08:39 --> Controller Class Initialized
DEBUG - 2023-12-04 16:08:39 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/login/views/login.php
DEBUG - 2023-12-04 16:08:39 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-12-04 16:08:39 --> Final output sent to browser
DEBUG - 2023-12-04 16:08:39 --> Total execution time: 0.0353
INFO - 2023-12-04 16:08:42 --> Config Class Initialized
INFO - 2023-12-04 16:08:42 --> Hooks Class Initialized
DEBUG - 2023-12-04 16:08:42 --> UTF-8 Support Enabled
INFO - 2023-12-04 16:08:42 --> Utf8 Class Initialized
INFO - 2023-12-04 16:08:42 --> URI Class Initialized
INFO - 2023-12-04 16:08:42 --> Router Class Initialized
INFO - 2023-12-04 16:08:42 --> Output Class Initialized
INFO - 2023-12-04 16:08:42 --> Security Class Initialized
DEBUG - 2023-12-04 16:08:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-04 16:08:42 --> Input Class Initialized
INFO - 2023-12-04 16:08:42 --> Language Class Initialized
INFO - 2023-12-04 16:08:42 --> Language Class Initialized
INFO - 2023-12-04 16:08:42 --> Config Class Initialized
INFO - 2023-12-04 16:08:42 --> Loader Class Initialized
INFO - 2023-12-04 16:08:42 --> Helper loaded: url_helper
INFO - 2023-12-04 16:08:42 --> Helper loaded: file_helper
INFO - 2023-12-04 16:08:42 --> Helper loaded: form_helper
INFO - 2023-12-04 16:08:42 --> Helper loaded: my_helper
INFO - 2023-12-04 16:08:42 --> Database Driver Class Initialized
INFO - 2023-12-04 16:08:42 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-04 16:08:42 --> Controller Class Initialized
INFO - 2023-12-04 16:08:42 --> Helper loaded: cookie_helper
INFO - 2023-12-04 16:08:42 --> Final output sent to browser
DEBUG - 2023-12-04 16:08:42 --> Total execution time: 0.0470
INFO - 2023-12-04 16:08:42 --> Config Class Initialized
INFO - 2023-12-04 16:08:42 --> Hooks Class Initialized
DEBUG - 2023-12-04 16:08:42 --> UTF-8 Support Enabled
INFO - 2023-12-04 16:08:42 --> Utf8 Class Initialized
INFO - 2023-12-04 16:08:42 --> URI Class Initialized
INFO - 2023-12-04 16:08:42 --> Router Class Initialized
INFO - 2023-12-04 16:08:42 --> Output Class Initialized
INFO - 2023-12-04 16:08:42 --> Security Class Initialized
DEBUG - 2023-12-04 16:08:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-04 16:08:42 --> Input Class Initialized
INFO - 2023-12-04 16:08:42 --> Language Class Initialized
INFO - 2023-12-04 16:08:42 --> Language Class Initialized
INFO - 2023-12-04 16:08:42 --> Config Class Initialized
INFO - 2023-12-04 16:08:42 --> Loader Class Initialized
INFO - 2023-12-04 16:08:42 --> Helper loaded: url_helper
INFO - 2023-12-04 16:08:42 --> Helper loaded: file_helper
INFO - 2023-12-04 16:08:42 --> Helper loaded: form_helper
INFO - 2023-12-04 16:08:42 --> Helper loaded: my_helper
INFO - 2023-12-04 16:08:42 --> Database Driver Class Initialized
INFO - 2023-12-04 16:08:42 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-04 16:08:42 --> Controller Class Initialized
DEBUG - 2023-12-04 16:08:42 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/home/views/v_home_guru.php
DEBUG - 2023-12-04 16:08:42 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-12-04 16:08:42 --> Final output sent to browser
DEBUG - 2023-12-04 16:08:42 --> Total execution time: 0.0433
INFO - 2023-12-04 16:09:43 --> Config Class Initialized
INFO - 2023-12-04 16:09:43 --> Hooks Class Initialized
DEBUG - 2023-12-04 16:09:43 --> UTF-8 Support Enabled
INFO - 2023-12-04 16:09:43 --> Utf8 Class Initialized
INFO - 2023-12-04 16:09:43 --> URI Class Initialized
DEBUG - 2023-12-04 16:09:43 --> No URI present. Default controller set.
INFO - 2023-12-04 16:09:43 --> Router Class Initialized
INFO - 2023-12-04 16:09:43 --> Output Class Initialized
INFO - 2023-12-04 16:09:43 --> Security Class Initialized
DEBUG - 2023-12-04 16:09:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-04 16:09:43 --> Input Class Initialized
INFO - 2023-12-04 16:09:43 --> Language Class Initialized
INFO - 2023-12-04 16:09:43 --> Language Class Initialized
INFO - 2023-12-04 16:09:43 --> Config Class Initialized
INFO - 2023-12-04 16:09:43 --> Loader Class Initialized
INFO - 2023-12-04 16:09:43 --> Helper loaded: url_helper
INFO - 2023-12-04 16:09:43 --> Helper loaded: file_helper
INFO - 2023-12-04 16:09:43 --> Helper loaded: form_helper
INFO - 2023-12-04 16:09:43 --> Helper loaded: my_helper
INFO - 2023-12-04 16:09:43 --> Database Driver Class Initialized
INFO - 2023-12-04 16:09:43 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-04 16:09:43 --> Controller Class Initialized
DEBUG - 2023-12-04 16:09:43 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/home/views/v_home_guru.php
DEBUG - 2023-12-04 16:09:43 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-12-04 16:09:43 --> Final output sent to browser
DEBUG - 2023-12-04 16:09:43 --> Total execution time: 0.1019
INFO - 2023-12-04 23:13:40 --> Config Class Initialized
INFO - 2023-12-04 23:13:40 --> Hooks Class Initialized
DEBUG - 2023-12-04 23:13:40 --> UTF-8 Support Enabled
INFO - 2023-12-04 23:13:40 --> Utf8 Class Initialized
INFO - 2023-12-04 23:13:40 --> URI Class Initialized
INFO - 2023-12-04 23:13:40 --> Router Class Initialized
INFO - 2023-12-04 23:13:40 --> Output Class Initialized
INFO - 2023-12-04 23:13:40 --> Security Class Initialized
DEBUG - 2023-12-04 23:13:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-04 23:13:40 --> Input Class Initialized
INFO - 2023-12-04 23:13:40 --> Language Class Initialized
ERROR - 2023-12-04 23:13:40 --> 404 Page Not Found: ../modules/login/controllers/Login/do_loginapii
INFO - 2023-12-04 23:13:41 --> Config Class Initialized
INFO - 2023-12-04 23:13:41 --> Hooks Class Initialized
DEBUG - 2023-12-04 23:13:41 --> UTF-8 Support Enabled
INFO - 2023-12-04 23:13:41 --> Utf8 Class Initialized
INFO - 2023-12-04 23:13:41 --> URI Class Initialized
INFO - 2023-12-04 23:13:41 --> Router Class Initialized
INFO - 2023-12-04 23:13:41 --> Output Class Initialized
INFO - 2023-12-04 23:13:41 --> Security Class Initialized
DEBUG - 2023-12-04 23:13:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-04 23:13:41 --> Input Class Initialized
INFO - 2023-12-04 23:13:41 --> Language Class Initialized
ERROR - 2023-12-04 23:13:41 --> 404 Page Not Found: ../modules/login/controllers/Login/do_loginapii
INFO - 2023-12-04 23:13:42 --> Config Class Initialized
INFO - 2023-12-04 23:13:42 --> Hooks Class Initialized
DEBUG - 2023-12-04 23:13:42 --> UTF-8 Support Enabled
INFO - 2023-12-04 23:13:42 --> Utf8 Class Initialized
INFO - 2023-12-04 23:13:42 --> URI Class Initialized
INFO - 2023-12-04 23:13:42 --> Router Class Initialized
INFO - 2023-12-04 23:13:42 --> Output Class Initialized
INFO - 2023-12-04 23:13:42 --> Security Class Initialized
DEBUG - 2023-12-04 23:13:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-04 23:13:42 --> Input Class Initialized
INFO - 2023-12-04 23:13:42 --> Language Class Initialized
ERROR - 2023-12-04 23:13:42 --> 404 Page Not Found: ../modules/login/controllers/Login/do_loginapii
INFO - 2023-12-04 23:13:42 --> Config Class Initialized
INFO - 2023-12-04 23:13:42 --> Hooks Class Initialized
DEBUG - 2023-12-04 23:13:42 --> UTF-8 Support Enabled
INFO - 2023-12-04 23:13:42 --> Utf8 Class Initialized
INFO - 2023-12-04 23:13:42 --> URI Class Initialized
INFO - 2023-12-04 23:13:42 --> Router Class Initialized
INFO - 2023-12-04 23:13:42 --> Output Class Initialized
INFO - 2023-12-04 23:13:42 --> Security Class Initialized
DEBUG - 2023-12-04 23:13:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-04 23:13:42 --> Input Class Initialized
INFO - 2023-12-04 23:13:42 --> Language Class Initialized
ERROR - 2023-12-04 23:13:42 --> 404 Page Not Found: ../modules/login/controllers/Login/do_loginapii
INFO - 2023-12-04 23:13:42 --> Config Class Initialized
INFO - 2023-12-04 23:13:42 --> Hooks Class Initialized
DEBUG - 2023-12-04 23:13:42 --> UTF-8 Support Enabled
INFO - 2023-12-04 23:13:42 --> Utf8 Class Initialized
INFO - 2023-12-04 23:13:42 --> URI Class Initialized
INFO - 2023-12-04 23:13:42 --> Router Class Initialized
INFO - 2023-12-04 23:13:42 --> Output Class Initialized
INFO - 2023-12-04 23:13:42 --> Security Class Initialized
DEBUG - 2023-12-04 23:13:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-04 23:13:42 --> Input Class Initialized
INFO - 2023-12-04 23:13:42 --> Language Class Initialized
ERROR - 2023-12-04 23:13:42 --> 404 Page Not Found: ../modules/login/controllers/Login/do_loginapii
INFO - 2023-12-04 23:13:42 --> Config Class Initialized
INFO - 2023-12-04 23:13:42 --> Hooks Class Initialized
DEBUG - 2023-12-04 23:13:42 --> UTF-8 Support Enabled
INFO - 2023-12-04 23:13:42 --> Utf8 Class Initialized
INFO - 2023-12-04 23:13:42 --> URI Class Initialized
INFO - 2023-12-04 23:13:43 --> Router Class Initialized
INFO - 2023-12-04 23:13:43 --> Output Class Initialized
INFO - 2023-12-04 23:13:43 --> Security Class Initialized
DEBUG - 2023-12-04 23:13:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-04 23:13:43 --> Input Class Initialized
INFO - 2023-12-04 23:13:43 --> Language Class Initialized
ERROR - 2023-12-04 23:13:43 --> 404 Page Not Found: ../modules/login/controllers/Login/do_loginapii
INFO - 2023-12-04 23:13:43 --> Config Class Initialized
INFO - 2023-12-04 23:13:43 --> Hooks Class Initialized
DEBUG - 2023-12-04 23:13:43 --> UTF-8 Support Enabled
INFO - 2023-12-04 23:13:43 --> Utf8 Class Initialized
INFO - 2023-12-04 23:13:43 --> URI Class Initialized
INFO - 2023-12-04 23:13:43 --> Router Class Initialized
INFO - 2023-12-04 23:13:43 --> Output Class Initialized
INFO - 2023-12-04 23:13:43 --> Security Class Initialized
DEBUG - 2023-12-04 23:13:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-04 23:13:43 --> Input Class Initialized
INFO - 2023-12-04 23:13:43 --> Language Class Initialized
ERROR - 2023-12-04 23:13:43 --> 404 Page Not Found: ../modules/login/controllers/Login/do_loginapii
INFO - 2023-12-04 23:13:44 --> Config Class Initialized
INFO - 2023-12-04 23:13:44 --> Hooks Class Initialized
DEBUG - 2023-12-04 23:13:44 --> UTF-8 Support Enabled
INFO - 2023-12-04 23:13:44 --> Utf8 Class Initialized
INFO - 2023-12-04 23:13:44 --> URI Class Initialized
INFO - 2023-12-04 23:13:45 --> Router Class Initialized
INFO - 2023-12-04 23:13:45 --> Output Class Initialized
INFO - 2023-12-04 23:13:45 --> Security Class Initialized
DEBUG - 2023-12-04 23:13:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-04 23:13:45 --> Input Class Initialized
INFO - 2023-12-04 23:13:45 --> Language Class Initialized
ERROR - 2023-12-04 23:13:45 --> 404 Page Not Found: ../modules/login/controllers/Login/do_loginapii
INFO - 2023-12-04 23:13:47 --> Config Class Initialized
INFO - 2023-12-04 23:13:47 --> Hooks Class Initialized
DEBUG - 2023-12-04 23:13:47 --> UTF-8 Support Enabled
INFO - 2023-12-04 23:13:47 --> Utf8 Class Initialized
INFO - 2023-12-04 23:13:47 --> URI Class Initialized
INFO - 2023-12-04 23:13:47 --> Router Class Initialized
INFO - 2023-12-04 23:13:47 --> Output Class Initialized
INFO - 2023-12-04 23:13:47 --> Security Class Initialized
DEBUG - 2023-12-04 23:13:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-04 23:13:47 --> Input Class Initialized
INFO - 2023-12-04 23:13:47 --> Language Class Initialized
ERROR - 2023-12-04 23:13:47 --> 404 Page Not Found: ../modules/login/controllers/Login/do_loginapii
INFO - 2023-12-04 23:13:47 --> Config Class Initialized
INFO - 2023-12-04 23:13:47 --> Hooks Class Initialized
DEBUG - 2023-12-04 23:13:47 --> UTF-8 Support Enabled
INFO - 2023-12-04 23:13:47 --> Utf8 Class Initialized
INFO - 2023-12-04 23:13:47 --> URI Class Initialized
INFO - 2023-12-04 23:13:47 --> Router Class Initialized
INFO - 2023-12-04 23:13:47 --> Output Class Initialized
INFO - 2023-12-04 23:13:47 --> Security Class Initialized
DEBUG - 2023-12-04 23:13:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-04 23:13:47 --> Input Class Initialized
INFO - 2023-12-04 23:13:47 --> Language Class Initialized
ERROR - 2023-12-04 23:13:47 --> 404 Page Not Found: ../modules/login/controllers/Login/do_loginapii
INFO - 2023-12-04 23:13:48 --> Config Class Initialized
INFO - 2023-12-04 23:13:48 --> Hooks Class Initialized
DEBUG - 2023-12-04 23:13:48 --> UTF-8 Support Enabled
INFO - 2023-12-04 23:13:48 --> Utf8 Class Initialized
INFO - 2023-12-04 23:13:48 --> URI Class Initialized
INFO - 2023-12-04 23:13:48 --> Router Class Initialized
INFO - 2023-12-04 23:13:48 --> Output Class Initialized
INFO - 2023-12-04 23:13:48 --> Security Class Initialized
DEBUG - 2023-12-04 23:13:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-04 23:13:48 --> Input Class Initialized
INFO - 2023-12-04 23:13:48 --> Language Class Initialized
ERROR - 2023-12-04 23:13:48 --> 404 Page Not Found: ../modules/login/controllers/Login/do_loginapii
INFO - 2023-12-04 23:13:51 --> Config Class Initialized
INFO - 2023-12-04 23:13:51 --> Hooks Class Initialized
DEBUG - 2023-12-04 23:13:51 --> UTF-8 Support Enabled
INFO - 2023-12-04 23:13:51 --> Utf8 Class Initialized
INFO - 2023-12-04 23:13:51 --> URI Class Initialized
INFO - 2023-12-04 23:13:51 --> Router Class Initialized
INFO - 2023-12-04 23:13:51 --> Output Class Initialized
INFO - 2023-12-04 23:13:51 --> Security Class Initialized
DEBUG - 2023-12-04 23:13:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-04 23:13:51 --> Input Class Initialized
INFO - 2023-12-04 23:13:51 --> Language Class Initialized
ERROR - 2023-12-04 23:13:51 --> 404 Page Not Found: ../modules/login/controllers/Login/do_loginapii
INFO - 2023-12-04 23:14:14 --> Config Class Initialized
INFO - 2023-12-04 23:14:14 --> Hooks Class Initialized
DEBUG - 2023-12-04 23:14:14 --> UTF-8 Support Enabled
INFO - 2023-12-04 23:14:14 --> Utf8 Class Initialized
INFO - 2023-12-04 23:14:14 --> URI Class Initialized
INFO - 2023-12-04 23:14:14 --> Router Class Initialized
INFO - 2023-12-04 23:14:14 --> Output Class Initialized
INFO - 2023-12-04 23:14:14 --> Security Class Initialized
DEBUG - 2023-12-04 23:14:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-04 23:14:14 --> Input Class Initialized
INFO - 2023-12-04 23:14:14 --> Language Class Initialized
ERROR - 2023-12-04 23:14:14 --> 404 Page Not Found: ../modules/login/controllers/Login/do_loginapii
