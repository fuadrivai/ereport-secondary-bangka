<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2023-09-24 11:29:42 --> Config Class Initialized
INFO - 2023-09-24 11:29:42 --> Hooks Class Initialized
DEBUG - 2023-09-24 11:29:42 --> UTF-8 Support Enabled
INFO - 2023-09-24 11:29:42 --> Utf8 Class Initialized
INFO - 2023-09-24 11:29:42 --> URI Class Initialized
INFO - 2023-09-24 11:29:42 --> Router Class Initialized
INFO - 2023-09-24 11:29:42 --> Output Class Initialized
INFO - 2023-09-24 11:29:42 --> Security Class Initialized
DEBUG - 2023-09-24 11:29:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-24 11:29:42 --> Input Class Initialized
INFO - 2023-09-24 11:29:42 --> Language Class Initialized
INFO - 2023-09-24 11:29:42 --> Language Class Initialized
INFO - 2023-09-24 11:29:42 --> Config Class Initialized
INFO - 2023-09-24 11:29:42 --> Loader Class Initialized
INFO - 2023-09-24 11:29:42 --> Helper loaded: url_helper
INFO - 2023-09-24 11:29:42 --> Helper loaded: file_helper
INFO - 2023-09-24 11:29:42 --> Helper loaded: form_helper
INFO - 2023-09-24 11:29:42 --> Helper loaded: my_helper
INFO - 2023-09-24 11:29:42 --> Database Driver Class Initialized
INFO - 2023-09-24 11:29:42 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-24 11:29:42 --> Controller Class Initialized
DEBUG - 2023-09-24 11:29:42 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/views/list.php
DEBUG - 2023-09-24 11:29:42 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-09-24 11:29:42 --> Final output sent to browser
DEBUG - 2023-09-24 11:29:42 --> Total execution time: 0.0982
INFO - 2023-09-24 11:29:43 --> Config Class Initialized
INFO - 2023-09-24 11:29:43 --> Hooks Class Initialized
DEBUG - 2023-09-24 11:29:43 --> UTF-8 Support Enabled
INFO - 2023-09-24 11:29:43 --> Utf8 Class Initialized
INFO - 2023-09-24 11:29:43 --> URI Class Initialized
INFO - 2023-09-24 11:29:43 --> Router Class Initialized
INFO - 2023-09-24 11:29:43 --> Output Class Initialized
INFO - 2023-09-24 11:29:43 --> Security Class Initialized
DEBUG - 2023-09-24 11:29:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-24 11:29:43 --> Input Class Initialized
INFO - 2023-09-24 11:29:43 --> Language Class Initialized
INFO - 2023-09-24 11:29:43 --> Language Class Initialized
INFO - 2023-09-24 11:29:43 --> Config Class Initialized
INFO - 2023-09-24 11:29:43 --> Loader Class Initialized
INFO - 2023-09-24 11:29:43 --> Helper loaded: url_helper
INFO - 2023-09-24 11:29:43 --> Helper loaded: file_helper
INFO - 2023-09-24 11:29:43 --> Helper loaded: form_helper
INFO - 2023-09-24 11:29:43 --> Helper loaded: my_helper
INFO - 2023-09-24 11:29:43 --> Database Driver Class Initialized
INFO - 2023-09-24 11:29:43 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-24 11:29:43 --> Controller Class Initialized
INFO - 2023-09-24 11:42:32 --> Config Class Initialized
INFO - 2023-09-24 11:42:32 --> Hooks Class Initialized
DEBUG - 2023-09-24 11:42:32 --> UTF-8 Support Enabled
INFO - 2023-09-24 11:42:32 --> Utf8 Class Initialized
INFO - 2023-09-24 11:42:32 --> URI Class Initialized
INFO - 2023-09-24 11:42:32 --> Router Class Initialized
INFO - 2023-09-24 11:42:32 --> Output Class Initialized
INFO - 2023-09-24 11:42:32 --> Security Class Initialized
DEBUG - 2023-09-24 11:42:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-24 11:42:32 --> Input Class Initialized
INFO - 2023-09-24 11:42:32 --> Language Class Initialized
INFO - 2023-09-24 11:42:32 --> Language Class Initialized
INFO - 2023-09-24 11:42:32 --> Config Class Initialized
INFO - 2023-09-24 11:42:32 --> Loader Class Initialized
INFO - 2023-09-24 11:42:32 --> Helper loaded: url_helper
INFO - 2023-09-24 11:42:32 --> Helper loaded: file_helper
INFO - 2023-09-24 11:42:32 --> Helper loaded: form_helper
INFO - 2023-09-24 11:42:32 --> Helper loaded: my_helper
INFO - 2023-09-24 11:42:32 --> Database Driver Class Initialized
INFO - 2023-09-24 11:42:32 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-24 11:42:32 --> Controller Class Initialized
INFO - 2023-09-24 11:42:32 --> Final output sent to browser
DEBUG - 2023-09-24 11:42:32 --> Total execution time: 0.0842
INFO - 2023-09-24 11:52:41 --> Config Class Initialized
INFO - 2023-09-24 11:52:41 --> Hooks Class Initialized
DEBUG - 2023-09-24 11:52:41 --> UTF-8 Support Enabled
INFO - 2023-09-24 11:52:41 --> Utf8 Class Initialized
INFO - 2023-09-24 11:52:41 --> URI Class Initialized
INFO - 2023-09-24 11:52:41 --> Router Class Initialized
INFO - 2023-09-24 11:52:41 --> Output Class Initialized
INFO - 2023-09-24 11:52:41 --> Security Class Initialized
DEBUG - 2023-09-24 11:52:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-24 11:52:41 --> Input Class Initialized
INFO - 2023-09-24 11:52:41 --> Language Class Initialized
INFO - 2023-09-24 11:52:41 --> Language Class Initialized
INFO - 2023-09-24 11:52:41 --> Config Class Initialized
INFO - 2023-09-24 11:52:41 --> Loader Class Initialized
INFO - 2023-09-24 11:52:41 --> Helper loaded: url_helper
INFO - 2023-09-24 11:52:41 --> Helper loaded: file_helper
INFO - 2023-09-24 11:52:41 --> Helper loaded: form_helper
INFO - 2023-09-24 11:52:41 --> Helper loaded: my_helper
INFO - 2023-09-24 11:52:41 --> Database Driver Class Initialized
INFO - 2023-09-24 11:52:41 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-24 11:52:41 --> Controller Class Initialized
INFO - 2023-09-24 11:52:41 --> Final output sent to browser
DEBUG - 2023-09-24 11:52:41 --> Total execution time: 0.4302
INFO - 2023-09-24 11:52:46 --> Config Class Initialized
INFO - 2023-09-24 11:52:46 --> Hooks Class Initialized
DEBUG - 2023-09-24 11:52:46 --> UTF-8 Support Enabled
INFO - 2023-09-24 11:52:46 --> Utf8 Class Initialized
INFO - 2023-09-24 11:52:46 --> URI Class Initialized
INFO - 2023-09-24 11:52:46 --> Router Class Initialized
INFO - 2023-09-24 11:52:46 --> Output Class Initialized
INFO - 2023-09-24 11:52:46 --> Security Class Initialized
DEBUG - 2023-09-24 11:52:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-24 11:52:46 --> Input Class Initialized
INFO - 2023-09-24 11:52:46 --> Language Class Initialized
INFO - 2023-09-24 11:52:46 --> Language Class Initialized
INFO - 2023-09-24 11:52:46 --> Config Class Initialized
INFO - 2023-09-24 11:52:46 --> Loader Class Initialized
INFO - 2023-09-24 11:52:46 --> Helper loaded: url_helper
INFO - 2023-09-24 11:52:46 --> Helper loaded: file_helper
INFO - 2023-09-24 11:52:46 --> Helper loaded: form_helper
INFO - 2023-09-24 11:52:46 --> Helper loaded: my_helper
INFO - 2023-09-24 11:52:46 --> Database Driver Class Initialized
INFO - 2023-09-24 11:52:46 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-24 11:52:46 --> Controller Class Initialized
INFO - 2023-09-24 11:52:47 --> Final output sent to browser
DEBUG - 2023-09-24 11:52:47 --> Total execution time: 0.6641
INFO - 2023-09-24 11:52:47 --> Config Class Initialized
INFO - 2023-09-24 11:52:47 --> Hooks Class Initialized
DEBUG - 2023-09-24 11:52:47 --> UTF-8 Support Enabled
INFO - 2023-09-24 11:52:47 --> Utf8 Class Initialized
INFO - 2023-09-24 11:52:47 --> URI Class Initialized
INFO - 2023-09-24 11:52:47 --> Router Class Initialized
INFO - 2023-09-24 11:52:47 --> Output Class Initialized
INFO - 2023-09-24 11:52:47 --> Security Class Initialized
DEBUG - 2023-09-24 11:52:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-24 11:52:47 --> Input Class Initialized
INFO - 2023-09-24 11:52:47 --> Language Class Initialized
INFO - 2023-09-24 11:52:47 --> Language Class Initialized
INFO - 2023-09-24 11:52:47 --> Config Class Initialized
INFO - 2023-09-24 11:52:47 --> Loader Class Initialized
INFO - 2023-09-24 11:52:47 --> Helper loaded: url_helper
INFO - 2023-09-24 11:52:47 --> Helper loaded: file_helper
INFO - 2023-09-24 11:52:47 --> Helper loaded: form_helper
INFO - 2023-09-24 11:52:47 --> Helper loaded: my_helper
INFO - 2023-09-24 11:52:47 --> Database Driver Class Initialized
INFO - 2023-09-24 11:52:47 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-24 11:52:47 --> Controller Class Initialized
INFO - 2023-09-24 11:52:49 --> Config Class Initialized
INFO - 2023-09-24 11:52:49 --> Hooks Class Initialized
DEBUG - 2023-09-24 11:52:49 --> UTF-8 Support Enabled
INFO - 2023-09-24 11:52:49 --> Utf8 Class Initialized
INFO - 2023-09-24 11:52:49 --> URI Class Initialized
INFO - 2023-09-24 11:52:49 --> Router Class Initialized
INFO - 2023-09-24 11:52:49 --> Output Class Initialized
INFO - 2023-09-24 11:52:49 --> Security Class Initialized
DEBUG - 2023-09-24 11:52:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-24 11:52:49 --> Input Class Initialized
INFO - 2023-09-24 11:52:49 --> Language Class Initialized
INFO - 2023-09-24 11:52:49 --> Language Class Initialized
INFO - 2023-09-24 11:52:49 --> Config Class Initialized
INFO - 2023-09-24 11:52:49 --> Loader Class Initialized
INFO - 2023-09-24 11:52:49 --> Helper loaded: url_helper
INFO - 2023-09-24 11:52:49 --> Helper loaded: file_helper
INFO - 2023-09-24 11:52:49 --> Helper loaded: form_helper
INFO - 2023-09-24 11:52:49 --> Helper loaded: my_helper
INFO - 2023-09-24 11:52:49 --> Database Driver Class Initialized
INFO - 2023-09-24 11:52:49 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-24 11:52:49 --> Controller Class Initialized
INFO - 2023-09-24 11:52:49 --> Final output sent to browser
DEBUG - 2023-09-24 11:52:49 --> Total execution time: 0.1288
INFO - 2023-09-24 11:52:50 --> Config Class Initialized
INFO - 2023-09-24 11:52:50 --> Hooks Class Initialized
DEBUG - 2023-09-24 11:52:50 --> UTF-8 Support Enabled
INFO - 2023-09-24 11:52:50 --> Utf8 Class Initialized
INFO - 2023-09-24 11:52:50 --> URI Class Initialized
INFO - 2023-09-24 11:52:50 --> Router Class Initialized
INFO - 2023-09-24 11:52:50 --> Output Class Initialized
INFO - 2023-09-24 11:52:50 --> Security Class Initialized
DEBUG - 2023-09-24 11:52:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-24 11:52:50 --> Input Class Initialized
INFO - 2023-09-24 11:52:50 --> Language Class Initialized
INFO - 2023-09-24 11:52:50 --> Language Class Initialized
INFO - 2023-09-24 11:52:50 --> Config Class Initialized
INFO - 2023-09-24 11:52:50 --> Loader Class Initialized
INFO - 2023-09-24 11:52:50 --> Helper loaded: url_helper
INFO - 2023-09-24 11:52:50 --> Helper loaded: file_helper
INFO - 2023-09-24 11:52:50 --> Helper loaded: form_helper
INFO - 2023-09-24 11:52:50 --> Helper loaded: my_helper
INFO - 2023-09-24 11:52:50 --> Database Driver Class Initialized
INFO - 2023-09-24 11:52:50 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-24 11:52:50 --> Controller Class Initialized
INFO - 2023-09-24 11:52:52 --> Config Class Initialized
INFO - 2023-09-24 11:52:52 --> Hooks Class Initialized
DEBUG - 2023-09-24 11:52:52 --> UTF-8 Support Enabled
INFO - 2023-09-24 11:52:52 --> Utf8 Class Initialized
INFO - 2023-09-24 11:52:52 --> URI Class Initialized
INFO - 2023-09-24 11:52:52 --> Router Class Initialized
INFO - 2023-09-24 11:52:52 --> Output Class Initialized
INFO - 2023-09-24 11:52:52 --> Security Class Initialized
DEBUG - 2023-09-24 11:52:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-24 11:52:52 --> Input Class Initialized
INFO - 2023-09-24 11:52:52 --> Language Class Initialized
INFO - 2023-09-24 11:52:52 --> Language Class Initialized
INFO - 2023-09-24 11:52:52 --> Config Class Initialized
INFO - 2023-09-24 11:52:52 --> Loader Class Initialized
INFO - 2023-09-24 11:52:52 --> Helper loaded: url_helper
INFO - 2023-09-24 11:52:52 --> Helper loaded: file_helper
INFO - 2023-09-24 11:52:52 --> Helper loaded: form_helper
INFO - 2023-09-24 11:52:52 --> Helper loaded: my_helper
INFO - 2023-09-24 11:52:52 --> Database Driver Class Initialized
INFO - 2023-09-24 11:52:52 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-24 11:52:52 --> Controller Class Initialized
INFO - 2023-09-24 11:52:52 --> Final output sent to browser
DEBUG - 2023-09-24 11:52:52 --> Total execution time: 0.0353
INFO - 2023-09-24 11:52:52 --> Config Class Initialized
INFO - 2023-09-24 11:52:52 --> Hooks Class Initialized
DEBUG - 2023-09-24 11:52:52 --> UTF-8 Support Enabled
INFO - 2023-09-24 11:52:52 --> Utf8 Class Initialized
INFO - 2023-09-24 11:52:52 --> URI Class Initialized
INFO - 2023-09-24 11:52:52 --> Router Class Initialized
INFO - 2023-09-24 11:52:52 --> Output Class Initialized
INFO - 2023-09-24 11:52:52 --> Security Class Initialized
DEBUG - 2023-09-24 11:52:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-24 11:52:52 --> Input Class Initialized
INFO - 2023-09-24 11:52:52 --> Language Class Initialized
INFO - 2023-09-24 11:52:52 --> Language Class Initialized
INFO - 2023-09-24 11:52:52 --> Config Class Initialized
INFO - 2023-09-24 11:52:52 --> Loader Class Initialized
INFO - 2023-09-24 11:52:52 --> Helper loaded: url_helper
INFO - 2023-09-24 11:52:52 --> Helper loaded: file_helper
INFO - 2023-09-24 11:52:52 --> Helper loaded: form_helper
INFO - 2023-09-24 11:52:52 --> Helper loaded: my_helper
INFO - 2023-09-24 11:52:52 --> Database Driver Class Initialized
INFO - 2023-09-24 11:52:52 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-24 11:52:52 --> Controller Class Initialized
INFO - 2023-09-24 11:52:55 --> Config Class Initialized
INFO - 2023-09-24 11:52:55 --> Hooks Class Initialized
DEBUG - 2023-09-24 11:52:55 --> UTF-8 Support Enabled
INFO - 2023-09-24 11:52:55 --> Utf8 Class Initialized
INFO - 2023-09-24 11:52:55 --> URI Class Initialized
INFO - 2023-09-24 11:52:55 --> Router Class Initialized
INFO - 2023-09-24 11:52:55 --> Output Class Initialized
INFO - 2023-09-24 11:52:55 --> Security Class Initialized
DEBUG - 2023-09-24 11:52:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-24 11:52:55 --> Input Class Initialized
INFO - 2023-09-24 11:52:55 --> Language Class Initialized
INFO - 2023-09-24 11:52:55 --> Language Class Initialized
INFO - 2023-09-24 11:52:55 --> Config Class Initialized
INFO - 2023-09-24 11:52:55 --> Loader Class Initialized
INFO - 2023-09-24 11:52:55 --> Helper loaded: url_helper
INFO - 2023-09-24 11:52:55 --> Helper loaded: file_helper
INFO - 2023-09-24 11:52:55 --> Helper loaded: form_helper
INFO - 2023-09-24 11:52:55 --> Helper loaded: my_helper
INFO - 2023-09-24 11:52:55 --> Database Driver Class Initialized
INFO - 2023-09-24 11:52:55 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-24 11:52:55 --> Controller Class Initialized
INFO - 2023-09-24 11:52:55 --> Final output sent to browser
DEBUG - 2023-09-24 11:52:55 --> Total execution time: 0.0317
INFO - 2023-09-24 11:53:15 --> Config Class Initialized
INFO - 2023-09-24 11:53:15 --> Hooks Class Initialized
DEBUG - 2023-09-24 11:53:15 --> UTF-8 Support Enabled
INFO - 2023-09-24 11:53:15 --> Utf8 Class Initialized
INFO - 2023-09-24 11:53:15 --> URI Class Initialized
INFO - 2023-09-24 11:53:15 --> Router Class Initialized
INFO - 2023-09-24 11:53:15 --> Output Class Initialized
INFO - 2023-09-24 11:53:15 --> Security Class Initialized
DEBUG - 2023-09-24 11:53:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-24 11:53:15 --> Input Class Initialized
INFO - 2023-09-24 11:53:15 --> Language Class Initialized
INFO - 2023-09-24 11:53:15 --> Language Class Initialized
INFO - 2023-09-24 11:53:15 --> Config Class Initialized
INFO - 2023-09-24 11:53:15 --> Loader Class Initialized
INFO - 2023-09-24 11:53:15 --> Helper loaded: url_helper
INFO - 2023-09-24 11:53:15 --> Helper loaded: file_helper
INFO - 2023-09-24 11:53:15 --> Helper loaded: form_helper
INFO - 2023-09-24 11:53:15 --> Helper loaded: my_helper
INFO - 2023-09-24 11:53:15 --> Database Driver Class Initialized
INFO - 2023-09-24 11:53:15 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-24 11:53:15 --> Controller Class Initialized
INFO - 2023-09-24 11:53:15 --> Final output sent to browser
DEBUG - 2023-09-24 11:53:15 --> Total execution time: 0.0414
INFO - 2023-09-24 11:53:16 --> Config Class Initialized
INFO - 2023-09-24 11:53:16 --> Hooks Class Initialized
DEBUG - 2023-09-24 11:53:16 --> UTF-8 Support Enabled
INFO - 2023-09-24 11:53:16 --> Utf8 Class Initialized
INFO - 2023-09-24 11:53:16 --> URI Class Initialized
INFO - 2023-09-24 11:53:16 --> Router Class Initialized
INFO - 2023-09-24 11:53:16 --> Output Class Initialized
INFO - 2023-09-24 11:53:16 --> Security Class Initialized
DEBUG - 2023-09-24 11:53:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-24 11:53:16 --> Input Class Initialized
INFO - 2023-09-24 11:53:16 --> Language Class Initialized
INFO - 2023-09-24 11:53:16 --> Language Class Initialized
INFO - 2023-09-24 11:53:16 --> Config Class Initialized
INFO - 2023-09-24 11:53:16 --> Loader Class Initialized
INFO - 2023-09-24 11:53:16 --> Helper loaded: url_helper
INFO - 2023-09-24 11:53:16 --> Helper loaded: file_helper
INFO - 2023-09-24 11:53:16 --> Helper loaded: form_helper
INFO - 2023-09-24 11:53:16 --> Helper loaded: my_helper
INFO - 2023-09-24 11:53:16 --> Database Driver Class Initialized
INFO - 2023-09-24 11:53:16 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-24 11:53:16 --> Controller Class Initialized
INFO - 2023-09-24 11:53:17 --> Config Class Initialized
INFO - 2023-09-24 11:53:17 --> Hooks Class Initialized
DEBUG - 2023-09-24 11:53:17 --> UTF-8 Support Enabled
INFO - 2023-09-24 11:53:17 --> Utf8 Class Initialized
INFO - 2023-09-24 11:53:17 --> URI Class Initialized
INFO - 2023-09-24 11:53:17 --> Router Class Initialized
INFO - 2023-09-24 11:53:17 --> Output Class Initialized
INFO - 2023-09-24 11:53:17 --> Security Class Initialized
DEBUG - 2023-09-24 11:53:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-24 11:53:17 --> Input Class Initialized
INFO - 2023-09-24 11:53:17 --> Language Class Initialized
INFO - 2023-09-24 11:53:17 --> Language Class Initialized
INFO - 2023-09-24 11:53:17 --> Config Class Initialized
INFO - 2023-09-24 11:53:17 --> Loader Class Initialized
INFO - 2023-09-24 11:53:17 --> Helper loaded: url_helper
INFO - 2023-09-24 11:53:17 --> Helper loaded: file_helper
INFO - 2023-09-24 11:53:17 --> Helper loaded: form_helper
INFO - 2023-09-24 11:53:17 --> Helper loaded: my_helper
INFO - 2023-09-24 11:53:17 --> Database Driver Class Initialized
INFO - 2023-09-24 11:53:17 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-24 11:53:17 --> Controller Class Initialized
INFO - 2023-09-24 11:53:17 --> Final output sent to browser
DEBUG - 2023-09-24 11:53:17 --> Total execution time: 0.0412
INFO - 2023-09-24 11:53:32 --> Config Class Initialized
INFO - 2023-09-24 11:53:32 --> Hooks Class Initialized
DEBUG - 2023-09-24 11:53:32 --> UTF-8 Support Enabled
INFO - 2023-09-24 11:53:32 --> Utf8 Class Initialized
INFO - 2023-09-24 11:53:32 --> URI Class Initialized
INFO - 2023-09-24 11:53:32 --> Router Class Initialized
INFO - 2023-09-24 11:53:32 --> Output Class Initialized
INFO - 2023-09-24 11:53:32 --> Security Class Initialized
DEBUG - 2023-09-24 11:53:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-24 11:53:32 --> Input Class Initialized
INFO - 2023-09-24 11:53:32 --> Language Class Initialized
INFO - 2023-09-24 11:53:32 --> Language Class Initialized
INFO - 2023-09-24 11:53:32 --> Config Class Initialized
INFO - 2023-09-24 11:53:32 --> Loader Class Initialized
INFO - 2023-09-24 11:53:32 --> Helper loaded: url_helper
INFO - 2023-09-24 11:53:32 --> Helper loaded: file_helper
INFO - 2023-09-24 11:53:32 --> Helper loaded: form_helper
INFO - 2023-09-24 11:53:32 --> Helper loaded: my_helper
INFO - 2023-09-24 11:53:32 --> Database Driver Class Initialized
INFO - 2023-09-24 11:53:32 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-24 11:53:32 --> Controller Class Initialized
INFO - 2023-09-24 11:53:32 --> Final output sent to browser
DEBUG - 2023-09-24 11:53:32 --> Total execution time: 0.0459
INFO - 2023-09-24 11:53:32 --> Config Class Initialized
INFO - 2023-09-24 11:53:32 --> Hooks Class Initialized
DEBUG - 2023-09-24 11:53:32 --> UTF-8 Support Enabled
INFO - 2023-09-24 11:53:32 --> Utf8 Class Initialized
INFO - 2023-09-24 11:53:32 --> URI Class Initialized
INFO - 2023-09-24 11:53:32 --> Router Class Initialized
INFO - 2023-09-24 11:53:32 --> Output Class Initialized
INFO - 2023-09-24 11:53:32 --> Security Class Initialized
DEBUG - 2023-09-24 11:53:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-24 11:53:32 --> Input Class Initialized
INFO - 2023-09-24 11:53:32 --> Language Class Initialized
INFO - 2023-09-24 11:53:32 --> Language Class Initialized
INFO - 2023-09-24 11:53:32 --> Config Class Initialized
INFO - 2023-09-24 11:53:32 --> Loader Class Initialized
INFO - 2023-09-24 11:53:32 --> Helper loaded: url_helper
INFO - 2023-09-24 11:53:32 --> Helper loaded: file_helper
INFO - 2023-09-24 11:53:32 --> Helper loaded: form_helper
INFO - 2023-09-24 11:53:32 --> Helper loaded: my_helper
INFO - 2023-09-24 11:53:32 --> Database Driver Class Initialized
INFO - 2023-09-24 11:53:32 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-24 11:53:32 --> Controller Class Initialized
INFO - 2023-09-24 11:53:33 --> Config Class Initialized
INFO - 2023-09-24 11:53:33 --> Hooks Class Initialized
DEBUG - 2023-09-24 11:53:33 --> UTF-8 Support Enabled
INFO - 2023-09-24 11:53:33 --> Utf8 Class Initialized
INFO - 2023-09-24 11:53:33 --> URI Class Initialized
INFO - 2023-09-24 11:53:33 --> Router Class Initialized
INFO - 2023-09-24 11:53:33 --> Output Class Initialized
INFO - 2023-09-24 11:53:33 --> Security Class Initialized
DEBUG - 2023-09-24 11:53:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-24 11:53:33 --> Input Class Initialized
INFO - 2023-09-24 11:53:33 --> Language Class Initialized
INFO - 2023-09-24 11:53:33 --> Language Class Initialized
INFO - 2023-09-24 11:53:33 --> Config Class Initialized
INFO - 2023-09-24 11:53:33 --> Loader Class Initialized
INFO - 2023-09-24 11:53:33 --> Helper loaded: url_helper
INFO - 2023-09-24 11:53:33 --> Helper loaded: file_helper
INFO - 2023-09-24 11:53:33 --> Helper loaded: form_helper
INFO - 2023-09-24 11:53:33 --> Helper loaded: my_helper
INFO - 2023-09-24 11:53:33 --> Database Driver Class Initialized
INFO - 2023-09-24 11:53:33 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-24 11:53:33 --> Controller Class Initialized
INFO - 2023-09-24 11:53:33 --> Final output sent to browser
DEBUG - 2023-09-24 11:53:33 --> Total execution time: 0.0372
INFO - 2023-09-24 11:53:46 --> Config Class Initialized
INFO - 2023-09-24 11:53:46 --> Hooks Class Initialized
DEBUG - 2023-09-24 11:53:46 --> UTF-8 Support Enabled
INFO - 2023-09-24 11:53:46 --> Utf8 Class Initialized
INFO - 2023-09-24 11:53:46 --> URI Class Initialized
INFO - 2023-09-24 11:53:46 --> Router Class Initialized
INFO - 2023-09-24 11:53:46 --> Output Class Initialized
INFO - 2023-09-24 11:53:46 --> Security Class Initialized
DEBUG - 2023-09-24 11:53:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-24 11:53:46 --> Input Class Initialized
INFO - 2023-09-24 11:53:46 --> Language Class Initialized
INFO - 2023-09-24 11:53:46 --> Language Class Initialized
INFO - 2023-09-24 11:53:46 --> Config Class Initialized
INFO - 2023-09-24 11:53:46 --> Loader Class Initialized
INFO - 2023-09-24 11:53:46 --> Helper loaded: url_helper
INFO - 2023-09-24 11:53:46 --> Helper loaded: file_helper
INFO - 2023-09-24 11:53:46 --> Helper loaded: form_helper
INFO - 2023-09-24 11:53:46 --> Helper loaded: my_helper
INFO - 2023-09-24 11:53:46 --> Database Driver Class Initialized
INFO - 2023-09-24 11:53:46 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-24 11:53:46 --> Controller Class Initialized
INFO - 2023-09-24 11:53:46 --> Final output sent to browser
DEBUG - 2023-09-24 11:53:46 --> Total execution time: 0.0736
INFO - 2023-09-24 11:53:46 --> Config Class Initialized
INFO - 2023-09-24 11:53:46 --> Hooks Class Initialized
DEBUG - 2023-09-24 11:53:46 --> UTF-8 Support Enabled
INFO - 2023-09-24 11:53:46 --> Utf8 Class Initialized
INFO - 2023-09-24 11:53:46 --> URI Class Initialized
INFO - 2023-09-24 11:53:46 --> Router Class Initialized
INFO - 2023-09-24 11:53:46 --> Output Class Initialized
INFO - 2023-09-24 11:53:46 --> Security Class Initialized
DEBUG - 2023-09-24 11:53:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-24 11:53:46 --> Input Class Initialized
INFO - 2023-09-24 11:53:46 --> Language Class Initialized
INFO - 2023-09-24 11:53:46 --> Language Class Initialized
INFO - 2023-09-24 11:53:46 --> Config Class Initialized
INFO - 2023-09-24 11:53:46 --> Loader Class Initialized
INFO - 2023-09-24 11:53:46 --> Helper loaded: url_helper
INFO - 2023-09-24 11:53:46 --> Helper loaded: file_helper
INFO - 2023-09-24 11:53:46 --> Helper loaded: form_helper
INFO - 2023-09-24 11:53:46 --> Helper loaded: my_helper
INFO - 2023-09-24 11:53:46 --> Database Driver Class Initialized
INFO - 2023-09-24 11:53:46 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-24 11:53:46 --> Controller Class Initialized
INFO - 2023-09-24 11:53:48 --> Config Class Initialized
INFO - 2023-09-24 11:53:48 --> Hooks Class Initialized
DEBUG - 2023-09-24 11:53:48 --> UTF-8 Support Enabled
INFO - 2023-09-24 11:53:48 --> Utf8 Class Initialized
INFO - 2023-09-24 11:53:48 --> URI Class Initialized
INFO - 2023-09-24 11:53:48 --> Router Class Initialized
INFO - 2023-09-24 11:53:48 --> Output Class Initialized
INFO - 2023-09-24 11:53:48 --> Security Class Initialized
DEBUG - 2023-09-24 11:53:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-24 11:53:48 --> Input Class Initialized
INFO - 2023-09-24 11:53:48 --> Language Class Initialized
INFO - 2023-09-24 11:53:48 --> Language Class Initialized
INFO - 2023-09-24 11:53:48 --> Config Class Initialized
INFO - 2023-09-24 11:53:48 --> Loader Class Initialized
INFO - 2023-09-24 11:53:48 --> Helper loaded: url_helper
INFO - 2023-09-24 11:53:48 --> Helper loaded: file_helper
INFO - 2023-09-24 11:53:48 --> Helper loaded: form_helper
INFO - 2023-09-24 11:53:48 --> Helper loaded: my_helper
INFO - 2023-09-24 11:53:48 --> Database Driver Class Initialized
INFO - 2023-09-24 11:53:48 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-24 11:53:48 --> Controller Class Initialized
INFO - 2023-09-24 11:53:48 --> Final output sent to browser
DEBUG - 2023-09-24 11:53:48 --> Total execution time: 0.0336
INFO - 2023-09-24 11:53:57 --> Config Class Initialized
INFO - 2023-09-24 11:53:57 --> Hooks Class Initialized
DEBUG - 2023-09-24 11:53:57 --> UTF-8 Support Enabled
INFO - 2023-09-24 11:53:57 --> Utf8 Class Initialized
INFO - 2023-09-24 11:53:57 --> URI Class Initialized
INFO - 2023-09-24 11:53:57 --> Router Class Initialized
INFO - 2023-09-24 11:53:57 --> Output Class Initialized
INFO - 2023-09-24 11:53:57 --> Security Class Initialized
DEBUG - 2023-09-24 11:53:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-24 11:53:57 --> Input Class Initialized
INFO - 2023-09-24 11:53:57 --> Language Class Initialized
INFO - 2023-09-24 11:53:57 --> Language Class Initialized
INFO - 2023-09-24 11:53:57 --> Config Class Initialized
INFO - 2023-09-24 11:53:57 --> Loader Class Initialized
INFO - 2023-09-24 11:53:57 --> Helper loaded: url_helper
INFO - 2023-09-24 11:53:57 --> Helper loaded: file_helper
INFO - 2023-09-24 11:53:57 --> Helper loaded: form_helper
INFO - 2023-09-24 11:53:57 --> Helper loaded: my_helper
INFO - 2023-09-24 11:53:57 --> Database Driver Class Initialized
INFO - 2023-09-24 11:53:57 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-24 11:53:57 --> Controller Class Initialized
INFO - 2023-09-24 11:53:57 --> Final output sent to browser
DEBUG - 2023-09-24 11:53:57 --> Total execution time: 0.0355
INFO - 2023-09-24 11:53:57 --> Config Class Initialized
INFO - 2023-09-24 11:53:57 --> Hooks Class Initialized
DEBUG - 2023-09-24 11:53:57 --> UTF-8 Support Enabled
INFO - 2023-09-24 11:53:57 --> Utf8 Class Initialized
INFO - 2023-09-24 11:53:57 --> URI Class Initialized
INFO - 2023-09-24 11:53:57 --> Router Class Initialized
INFO - 2023-09-24 11:53:57 --> Output Class Initialized
INFO - 2023-09-24 11:53:57 --> Security Class Initialized
DEBUG - 2023-09-24 11:53:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-24 11:53:57 --> Input Class Initialized
INFO - 2023-09-24 11:53:57 --> Language Class Initialized
INFO - 2023-09-24 11:53:57 --> Language Class Initialized
INFO - 2023-09-24 11:53:57 --> Config Class Initialized
INFO - 2023-09-24 11:53:57 --> Loader Class Initialized
INFO - 2023-09-24 11:53:57 --> Helper loaded: url_helper
INFO - 2023-09-24 11:53:57 --> Helper loaded: file_helper
INFO - 2023-09-24 11:53:57 --> Helper loaded: form_helper
INFO - 2023-09-24 11:53:57 --> Helper loaded: my_helper
INFO - 2023-09-24 11:53:57 --> Database Driver Class Initialized
INFO - 2023-09-24 11:53:57 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-24 11:53:57 --> Controller Class Initialized
INFO - 2023-09-24 11:54:09 --> Config Class Initialized
INFO - 2023-09-24 11:54:09 --> Hooks Class Initialized
DEBUG - 2023-09-24 11:54:09 --> UTF-8 Support Enabled
INFO - 2023-09-24 11:54:09 --> Utf8 Class Initialized
INFO - 2023-09-24 11:54:09 --> URI Class Initialized
INFO - 2023-09-24 11:54:09 --> Router Class Initialized
INFO - 2023-09-24 11:54:09 --> Output Class Initialized
INFO - 2023-09-24 11:54:09 --> Security Class Initialized
DEBUG - 2023-09-24 11:54:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-24 11:54:09 --> Input Class Initialized
INFO - 2023-09-24 11:54:09 --> Language Class Initialized
INFO - 2023-09-24 11:54:09 --> Language Class Initialized
INFO - 2023-09-24 11:54:09 --> Config Class Initialized
INFO - 2023-09-24 11:54:09 --> Loader Class Initialized
INFO - 2023-09-24 11:54:09 --> Helper loaded: url_helper
INFO - 2023-09-24 11:54:09 --> Helper loaded: file_helper
INFO - 2023-09-24 11:54:09 --> Helper loaded: form_helper
INFO - 2023-09-24 11:54:09 --> Helper loaded: my_helper
INFO - 2023-09-24 11:54:09 --> Database Driver Class Initialized
INFO - 2023-09-24 11:54:09 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-24 11:54:09 --> Controller Class Initialized
INFO - 2023-09-24 11:54:09 --> Final output sent to browser
DEBUG - 2023-09-24 11:54:09 --> Total execution time: 0.0344
INFO - 2023-09-24 11:54:18 --> Config Class Initialized
INFO - 2023-09-24 11:54:18 --> Hooks Class Initialized
DEBUG - 2023-09-24 11:54:18 --> UTF-8 Support Enabled
INFO - 2023-09-24 11:54:18 --> Utf8 Class Initialized
INFO - 2023-09-24 11:54:18 --> URI Class Initialized
INFO - 2023-09-24 11:54:18 --> Router Class Initialized
INFO - 2023-09-24 11:54:18 --> Output Class Initialized
INFO - 2023-09-24 11:54:18 --> Security Class Initialized
DEBUG - 2023-09-24 11:54:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-24 11:54:18 --> Input Class Initialized
INFO - 2023-09-24 11:54:18 --> Language Class Initialized
INFO - 2023-09-24 11:54:18 --> Language Class Initialized
INFO - 2023-09-24 11:54:18 --> Config Class Initialized
INFO - 2023-09-24 11:54:18 --> Loader Class Initialized
INFO - 2023-09-24 11:54:18 --> Helper loaded: url_helper
INFO - 2023-09-24 11:54:18 --> Helper loaded: file_helper
INFO - 2023-09-24 11:54:18 --> Helper loaded: form_helper
INFO - 2023-09-24 11:54:18 --> Helper loaded: my_helper
INFO - 2023-09-24 11:54:18 --> Database Driver Class Initialized
INFO - 2023-09-24 11:54:18 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-24 11:54:18 --> Controller Class Initialized
INFO - 2023-09-24 11:54:18 --> Final output sent to browser
DEBUG - 2023-09-24 11:54:18 --> Total execution time: 0.0441
INFO - 2023-09-24 11:54:18 --> Config Class Initialized
INFO - 2023-09-24 11:54:18 --> Hooks Class Initialized
DEBUG - 2023-09-24 11:54:18 --> UTF-8 Support Enabled
INFO - 2023-09-24 11:54:18 --> Utf8 Class Initialized
INFO - 2023-09-24 11:54:18 --> URI Class Initialized
INFO - 2023-09-24 11:54:18 --> Router Class Initialized
INFO - 2023-09-24 11:54:18 --> Output Class Initialized
INFO - 2023-09-24 11:54:18 --> Security Class Initialized
DEBUG - 2023-09-24 11:54:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-24 11:54:18 --> Input Class Initialized
INFO - 2023-09-24 11:54:18 --> Language Class Initialized
INFO - 2023-09-24 11:54:18 --> Language Class Initialized
INFO - 2023-09-24 11:54:18 --> Config Class Initialized
INFO - 2023-09-24 11:54:18 --> Loader Class Initialized
INFO - 2023-09-24 11:54:18 --> Helper loaded: url_helper
INFO - 2023-09-24 11:54:18 --> Helper loaded: file_helper
INFO - 2023-09-24 11:54:18 --> Helper loaded: form_helper
INFO - 2023-09-24 11:54:18 --> Helper loaded: my_helper
INFO - 2023-09-24 11:54:18 --> Database Driver Class Initialized
INFO - 2023-09-24 11:54:18 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-24 11:54:18 --> Controller Class Initialized
INFO - 2023-09-24 11:54:20 --> Config Class Initialized
INFO - 2023-09-24 11:54:20 --> Hooks Class Initialized
DEBUG - 2023-09-24 11:54:20 --> UTF-8 Support Enabled
INFO - 2023-09-24 11:54:20 --> Utf8 Class Initialized
INFO - 2023-09-24 11:54:20 --> URI Class Initialized
INFO - 2023-09-24 11:54:20 --> Router Class Initialized
INFO - 2023-09-24 11:54:20 --> Output Class Initialized
INFO - 2023-09-24 11:54:20 --> Security Class Initialized
DEBUG - 2023-09-24 11:54:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-24 11:54:20 --> Input Class Initialized
INFO - 2023-09-24 11:54:20 --> Language Class Initialized
INFO - 2023-09-24 11:54:20 --> Language Class Initialized
INFO - 2023-09-24 11:54:20 --> Config Class Initialized
INFO - 2023-09-24 11:54:20 --> Loader Class Initialized
INFO - 2023-09-24 11:54:20 --> Helper loaded: url_helper
INFO - 2023-09-24 11:54:20 --> Helper loaded: file_helper
INFO - 2023-09-24 11:54:20 --> Helper loaded: form_helper
INFO - 2023-09-24 11:54:20 --> Helper loaded: my_helper
INFO - 2023-09-24 11:54:20 --> Database Driver Class Initialized
INFO - 2023-09-24 11:54:20 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-24 11:54:20 --> Controller Class Initialized
INFO - 2023-09-24 11:54:20 --> Final output sent to browser
DEBUG - 2023-09-24 11:54:20 --> Total execution time: 0.0366
INFO - 2023-09-24 11:54:29 --> Config Class Initialized
INFO - 2023-09-24 11:54:29 --> Hooks Class Initialized
DEBUG - 2023-09-24 11:54:29 --> UTF-8 Support Enabled
INFO - 2023-09-24 11:54:29 --> Utf8 Class Initialized
INFO - 2023-09-24 11:54:29 --> URI Class Initialized
INFO - 2023-09-24 11:54:29 --> Router Class Initialized
INFO - 2023-09-24 11:54:29 --> Output Class Initialized
INFO - 2023-09-24 11:54:29 --> Security Class Initialized
DEBUG - 2023-09-24 11:54:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-24 11:54:29 --> Input Class Initialized
INFO - 2023-09-24 11:54:29 --> Language Class Initialized
INFO - 2023-09-24 11:54:29 --> Language Class Initialized
INFO - 2023-09-24 11:54:29 --> Config Class Initialized
INFO - 2023-09-24 11:54:29 --> Loader Class Initialized
INFO - 2023-09-24 11:54:29 --> Helper loaded: url_helper
INFO - 2023-09-24 11:54:29 --> Helper loaded: file_helper
INFO - 2023-09-24 11:54:29 --> Helper loaded: form_helper
INFO - 2023-09-24 11:54:29 --> Helper loaded: my_helper
INFO - 2023-09-24 11:54:29 --> Database Driver Class Initialized
INFO - 2023-09-24 11:54:29 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-24 11:54:29 --> Controller Class Initialized
INFO - 2023-09-24 11:54:29 --> Final output sent to browser
DEBUG - 2023-09-24 11:54:29 --> Total execution time: 0.0387
INFO - 2023-09-24 11:54:29 --> Config Class Initialized
INFO - 2023-09-24 11:54:29 --> Hooks Class Initialized
DEBUG - 2023-09-24 11:54:29 --> UTF-8 Support Enabled
INFO - 2023-09-24 11:54:29 --> Utf8 Class Initialized
INFO - 2023-09-24 11:54:29 --> URI Class Initialized
INFO - 2023-09-24 11:54:29 --> Router Class Initialized
INFO - 2023-09-24 11:54:29 --> Output Class Initialized
INFO - 2023-09-24 11:54:29 --> Security Class Initialized
DEBUG - 2023-09-24 11:54:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-24 11:54:29 --> Input Class Initialized
INFO - 2023-09-24 11:54:29 --> Language Class Initialized
INFO - 2023-09-24 11:54:29 --> Language Class Initialized
INFO - 2023-09-24 11:54:29 --> Config Class Initialized
INFO - 2023-09-24 11:54:29 --> Loader Class Initialized
INFO - 2023-09-24 11:54:29 --> Helper loaded: url_helper
INFO - 2023-09-24 11:54:29 --> Helper loaded: file_helper
INFO - 2023-09-24 11:54:29 --> Helper loaded: form_helper
INFO - 2023-09-24 11:54:29 --> Helper loaded: my_helper
INFO - 2023-09-24 11:54:29 --> Database Driver Class Initialized
INFO - 2023-09-24 11:54:29 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-24 11:54:29 --> Controller Class Initialized
INFO - 2023-09-24 11:54:30 --> Config Class Initialized
INFO - 2023-09-24 11:54:30 --> Hooks Class Initialized
DEBUG - 2023-09-24 11:54:30 --> UTF-8 Support Enabled
INFO - 2023-09-24 11:54:30 --> Utf8 Class Initialized
INFO - 2023-09-24 11:54:30 --> URI Class Initialized
INFO - 2023-09-24 11:54:30 --> Router Class Initialized
INFO - 2023-09-24 11:54:30 --> Output Class Initialized
INFO - 2023-09-24 11:54:30 --> Security Class Initialized
DEBUG - 2023-09-24 11:54:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-24 11:54:30 --> Input Class Initialized
INFO - 2023-09-24 11:54:30 --> Language Class Initialized
INFO - 2023-09-24 11:54:30 --> Language Class Initialized
INFO - 2023-09-24 11:54:30 --> Config Class Initialized
INFO - 2023-09-24 11:54:30 --> Loader Class Initialized
INFO - 2023-09-24 11:54:30 --> Helper loaded: url_helper
INFO - 2023-09-24 11:54:30 --> Helper loaded: file_helper
INFO - 2023-09-24 11:54:30 --> Helper loaded: form_helper
INFO - 2023-09-24 11:54:30 --> Helper loaded: my_helper
INFO - 2023-09-24 11:54:30 --> Database Driver Class Initialized
INFO - 2023-09-24 11:54:30 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-24 11:54:30 --> Controller Class Initialized
INFO - 2023-09-24 11:54:30 --> Final output sent to browser
DEBUG - 2023-09-24 11:54:30 --> Total execution time: 0.0471
INFO - 2023-09-24 11:54:41 --> Config Class Initialized
INFO - 2023-09-24 11:54:41 --> Hooks Class Initialized
DEBUG - 2023-09-24 11:54:41 --> UTF-8 Support Enabled
INFO - 2023-09-24 11:54:41 --> Utf8 Class Initialized
INFO - 2023-09-24 11:54:41 --> URI Class Initialized
INFO - 2023-09-24 11:54:41 --> Router Class Initialized
INFO - 2023-09-24 11:54:41 --> Output Class Initialized
INFO - 2023-09-24 11:54:41 --> Security Class Initialized
DEBUG - 2023-09-24 11:54:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-24 11:54:41 --> Input Class Initialized
INFO - 2023-09-24 11:54:41 --> Language Class Initialized
INFO - 2023-09-24 11:54:41 --> Language Class Initialized
INFO - 2023-09-24 11:54:41 --> Config Class Initialized
INFO - 2023-09-24 11:54:41 --> Loader Class Initialized
INFO - 2023-09-24 11:54:41 --> Helper loaded: url_helper
INFO - 2023-09-24 11:54:41 --> Helper loaded: file_helper
INFO - 2023-09-24 11:54:41 --> Helper loaded: form_helper
INFO - 2023-09-24 11:54:41 --> Helper loaded: my_helper
INFO - 2023-09-24 11:54:41 --> Database Driver Class Initialized
INFO - 2023-09-24 11:54:41 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-24 11:54:41 --> Controller Class Initialized
INFO - 2023-09-24 11:54:41 --> Final output sent to browser
DEBUG - 2023-09-24 11:54:41 --> Total execution time: 0.0322
INFO - 2023-09-24 11:54:41 --> Config Class Initialized
INFO - 2023-09-24 11:54:41 --> Hooks Class Initialized
DEBUG - 2023-09-24 11:54:41 --> UTF-8 Support Enabled
INFO - 2023-09-24 11:54:41 --> Utf8 Class Initialized
INFO - 2023-09-24 11:54:41 --> URI Class Initialized
INFO - 2023-09-24 11:54:41 --> Router Class Initialized
INFO - 2023-09-24 11:54:41 --> Output Class Initialized
INFO - 2023-09-24 11:54:41 --> Security Class Initialized
DEBUG - 2023-09-24 11:54:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-24 11:54:41 --> Input Class Initialized
INFO - 2023-09-24 11:54:41 --> Language Class Initialized
INFO - 2023-09-24 11:54:41 --> Language Class Initialized
INFO - 2023-09-24 11:54:41 --> Config Class Initialized
INFO - 2023-09-24 11:54:41 --> Loader Class Initialized
INFO - 2023-09-24 11:54:41 --> Helper loaded: url_helper
INFO - 2023-09-24 11:54:41 --> Helper loaded: file_helper
INFO - 2023-09-24 11:54:41 --> Helper loaded: form_helper
INFO - 2023-09-24 11:54:41 --> Helper loaded: my_helper
INFO - 2023-09-24 11:54:41 --> Database Driver Class Initialized
INFO - 2023-09-24 11:54:41 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-24 11:54:41 --> Controller Class Initialized
INFO - 2023-09-24 11:54:43 --> Config Class Initialized
INFO - 2023-09-24 11:54:43 --> Hooks Class Initialized
DEBUG - 2023-09-24 11:54:43 --> UTF-8 Support Enabled
INFO - 2023-09-24 11:54:43 --> Utf8 Class Initialized
INFO - 2023-09-24 11:54:43 --> URI Class Initialized
INFO - 2023-09-24 11:54:43 --> Router Class Initialized
INFO - 2023-09-24 11:54:43 --> Output Class Initialized
INFO - 2023-09-24 11:54:43 --> Security Class Initialized
DEBUG - 2023-09-24 11:54:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-24 11:54:43 --> Input Class Initialized
INFO - 2023-09-24 11:54:43 --> Language Class Initialized
INFO - 2023-09-24 11:54:43 --> Language Class Initialized
INFO - 2023-09-24 11:54:43 --> Config Class Initialized
INFO - 2023-09-24 11:54:43 --> Loader Class Initialized
INFO - 2023-09-24 11:54:43 --> Helper loaded: url_helper
INFO - 2023-09-24 11:54:43 --> Helper loaded: file_helper
INFO - 2023-09-24 11:54:43 --> Helper loaded: form_helper
INFO - 2023-09-24 11:54:43 --> Helper loaded: my_helper
INFO - 2023-09-24 11:54:43 --> Database Driver Class Initialized
INFO - 2023-09-24 11:54:43 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-24 11:54:43 --> Controller Class Initialized
INFO - 2023-09-24 11:54:43 --> Final output sent to browser
DEBUG - 2023-09-24 11:54:43 --> Total execution time: 0.0296
INFO - 2023-09-24 11:54:53 --> Config Class Initialized
INFO - 2023-09-24 11:54:53 --> Hooks Class Initialized
DEBUG - 2023-09-24 11:54:53 --> UTF-8 Support Enabled
INFO - 2023-09-24 11:54:53 --> Utf8 Class Initialized
INFO - 2023-09-24 11:54:53 --> URI Class Initialized
INFO - 2023-09-24 11:54:53 --> Router Class Initialized
INFO - 2023-09-24 11:54:53 --> Output Class Initialized
INFO - 2023-09-24 11:54:53 --> Security Class Initialized
DEBUG - 2023-09-24 11:54:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-24 11:54:53 --> Input Class Initialized
INFO - 2023-09-24 11:54:53 --> Language Class Initialized
INFO - 2023-09-24 11:54:53 --> Language Class Initialized
INFO - 2023-09-24 11:54:53 --> Config Class Initialized
INFO - 2023-09-24 11:54:53 --> Loader Class Initialized
INFO - 2023-09-24 11:54:53 --> Helper loaded: url_helper
INFO - 2023-09-24 11:54:53 --> Helper loaded: file_helper
INFO - 2023-09-24 11:54:53 --> Helper loaded: form_helper
INFO - 2023-09-24 11:54:53 --> Helper loaded: my_helper
INFO - 2023-09-24 11:54:53 --> Database Driver Class Initialized
INFO - 2023-09-24 11:54:53 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-24 11:54:53 --> Controller Class Initialized
INFO - 2023-09-24 11:54:53 --> Final output sent to browser
DEBUG - 2023-09-24 11:54:53 --> Total execution time: 0.0432
INFO - 2023-09-24 11:54:53 --> Config Class Initialized
INFO - 2023-09-24 11:54:53 --> Hooks Class Initialized
DEBUG - 2023-09-24 11:54:53 --> UTF-8 Support Enabled
INFO - 2023-09-24 11:54:53 --> Utf8 Class Initialized
INFO - 2023-09-24 11:54:53 --> URI Class Initialized
INFO - 2023-09-24 11:54:53 --> Router Class Initialized
INFO - 2023-09-24 11:54:53 --> Output Class Initialized
INFO - 2023-09-24 11:54:53 --> Security Class Initialized
DEBUG - 2023-09-24 11:54:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-24 11:54:53 --> Input Class Initialized
INFO - 2023-09-24 11:54:53 --> Language Class Initialized
INFO - 2023-09-24 11:54:53 --> Language Class Initialized
INFO - 2023-09-24 11:54:53 --> Config Class Initialized
INFO - 2023-09-24 11:54:53 --> Loader Class Initialized
INFO - 2023-09-24 11:54:53 --> Helper loaded: url_helper
INFO - 2023-09-24 11:54:53 --> Helper loaded: file_helper
INFO - 2023-09-24 11:54:53 --> Helper loaded: form_helper
INFO - 2023-09-24 11:54:53 --> Helper loaded: my_helper
INFO - 2023-09-24 11:54:53 --> Database Driver Class Initialized
INFO - 2023-09-24 11:54:53 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-24 11:54:53 --> Controller Class Initialized
INFO - 2023-09-24 11:54:54 --> Config Class Initialized
INFO - 2023-09-24 11:54:54 --> Hooks Class Initialized
DEBUG - 2023-09-24 11:54:54 --> UTF-8 Support Enabled
INFO - 2023-09-24 11:54:54 --> Utf8 Class Initialized
INFO - 2023-09-24 11:54:54 --> URI Class Initialized
INFO - 2023-09-24 11:54:54 --> Router Class Initialized
INFO - 2023-09-24 11:54:54 --> Output Class Initialized
INFO - 2023-09-24 11:54:54 --> Security Class Initialized
DEBUG - 2023-09-24 11:54:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-24 11:54:54 --> Input Class Initialized
INFO - 2023-09-24 11:54:54 --> Language Class Initialized
INFO - 2023-09-24 11:54:54 --> Language Class Initialized
INFO - 2023-09-24 11:54:54 --> Config Class Initialized
INFO - 2023-09-24 11:54:54 --> Loader Class Initialized
INFO - 2023-09-24 11:54:54 --> Helper loaded: url_helper
INFO - 2023-09-24 11:54:54 --> Helper loaded: file_helper
INFO - 2023-09-24 11:54:54 --> Helper loaded: form_helper
INFO - 2023-09-24 11:54:54 --> Helper loaded: my_helper
INFO - 2023-09-24 11:54:54 --> Database Driver Class Initialized
INFO - 2023-09-24 11:54:54 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-24 11:54:54 --> Controller Class Initialized
INFO - 2023-09-24 11:54:54 --> Final output sent to browser
DEBUG - 2023-09-24 11:54:54 --> Total execution time: 0.0686
INFO - 2023-09-24 11:55:04 --> Config Class Initialized
INFO - 2023-09-24 11:55:04 --> Hooks Class Initialized
DEBUG - 2023-09-24 11:55:04 --> UTF-8 Support Enabled
INFO - 2023-09-24 11:55:04 --> Utf8 Class Initialized
INFO - 2023-09-24 11:55:04 --> URI Class Initialized
INFO - 2023-09-24 11:55:04 --> Router Class Initialized
INFO - 2023-09-24 11:55:04 --> Output Class Initialized
INFO - 2023-09-24 11:55:04 --> Security Class Initialized
DEBUG - 2023-09-24 11:55:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-24 11:55:04 --> Input Class Initialized
INFO - 2023-09-24 11:55:04 --> Language Class Initialized
INFO - 2023-09-24 11:55:04 --> Language Class Initialized
INFO - 2023-09-24 11:55:04 --> Config Class Initialized
INFO - 2023-09-24 11:55:04 --> Loader Class Initialized
INFO - 2023-09-24 11:55:04 --> Helper loaded: url_helper
INFO - 2023-09-24 11:55:04 --> Helper loaded: file_helper
INFO - 2023-09-24 11:55:04 --> Helper loaded: form_helper
INFO - 2023-09-24 11:55:04 --> Helper loaded: my_helper
INFO - 2023-09-24 11:55:04 --> Database Driver Class Initialized
INFO - 2023-09-24 11:55:04 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-24 11:55:04 --> Controller Class Initialized
INFO - 2023-09-24 11:55:04 --> Final output sent to browser
DEBUG - 2023-09-24 11:55:04 --> Total execution time: 0.0386
INFO - 2023-09-24 11:55:04 --> Config Class Initialized
INFO - 2023-09-24 11:55:04 --> Hooks Class Initialized
DEBUG - 2023-09-24 11:55:04 --> UTF-8 Support Enabled
INFO - 2023-09-24 11:55:04 --> Utf8 Class Initialized
INFO - 2023-09-24 11:55:04 --> URI Class Initialized
INFO - 2023-09-24 11:55:04 --> Router Class Initialized
INFO - 2023-09-24 11:55:04 --> Output Class Initialized
INFO - 2023-09-24 11:55:04 --> Security Class Initialized
DEBUG - 2023-09-24 11:55:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-24 11:55:04 --> Input Class Initialized
INFO - 2023-09-24 11:55:04 --> Language Class Initialized
INFO - 2023-09-24 11:55:04 --> Language Class Initialized
INFO - 2023-09-24 11:55:04 --> Config Class Initialized
INFO - 2023-09-24 11:55:04 --> Loader Class Initialized
INFO - 2023-09-24 11:55:04 --> Helper loaded: url_helper
INFO - 2023-09-24 11:55:04 --> Helper loaded: file_helper
INFO - 2023-09-24 11:55:04 --> Helper loaded: form_helper
INFO - 2023-09-24 11:55:04 --> Helper loaded: my_helper
INFO - 2023-09-24 11:55:04 --> Database Driver Class Initialized
INFO - 2023-09-24 11:55:04 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-24 11:55:04 --> Controller Class Initialized
INFO - 2023-09-24 11:55:08 --> Config Class Initialized
INFO - 2023-09-24 11:55:08 --> Hooks Class Initialized
DEBUG - 2023-09-24 11:55:08 --> UTF-8 Support Enabled
INFO - 2023-09-24 11:55:08 --> Utf8 Class Initialized
INFO - 2023-09-24 11:55:08 --> URI Class Initialized
INFO - 2023-09-24 11:55:08 --> Router Class Initialized
INFO - 2023-09-24 11:55:08 --> Output Class Initialized
INFO - 2023-09-24 11:55:08 --> Security Class Initialized
DEBUG - 2023-09-24 11:55:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-24 11:55:08 --> Input Class Initialized
INFO - 2023-09-24 11:55:08 --> Language Class Initialized
INFO - 2023-09-24 11:55:08 --> Language Class Initialized
INFO - 2023-09-24 11:55:08 --> Config Class Initialized
INFO - 2023-09-24 11:55:08 --> Loader Class Initialized
INFO - 2023-09-24 11:55:08 --> Helper loaded: url_helper
INFO - 2023-09-24 11:55:08 --> Helper loaded: file_helper
INFO - 2023-09-24 11:55:08 --> Helper loaded: form_helper
INFO - 2023-09-24 11:55:08 --> Helper loaded: my_helper
INFO - 2023-09-24 11:55:08 --> Database Driver Class Initialized
INFO - 2023-09-24 11:55:08 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-24 11:55:08 --> Controller Class Initialized
INFO - 2023-09-24 11:55:08 --> Final output sent to browser
DEBUG - 2023-09-24 11:55:08 --> Total execution time: 0.0413
INFO - 2023-09-24 11:55:17 --> Config Class Initialized
INFO - 2023-09-24 11:55:17 --> Hooks Class Initialized
DEBUG - 2023-09-24 11:55:17 --> UTF-8 Support Enabled
INFO - 2023-09-24 11:55:17 --> Utf8 Class Initialized
INFO - 2023-09-24 11:55:17 --> URI Class Initialized
INFO - 2023-09-24 11:55:17 --> Router Class Initialized
INFO - 2023-09-24 11:55:17 --> Output Class Initialized
INFO - 2023-09-24 11:55:17 --> Security Class Initialized
DEBUG - 2023-09-24 11:55:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-24 11:55:17 --> Input Class Initialized
INFO - 2023-09-24 11:55:17 --> Language Class Initialized
INFO - 2023-09-24 11:55:17 --> Language Class Initialized
INFO - 2023-09-24 11:55:17 --> Config Class Initialized
INFO - 2023-09-24 11:55:17 --> Loader Class Initialized
INFO - 2023-09-24 11:55:17 --> Helper loaded: url_helper
INFO - 2023-09-24 11:55:17 --> Helper loaded: file_helper
INFO - 2023-09-24 11:55:17 --> Helper loaded: form_helper
INFO - 2023-09-24 11:55:17 --> Helper loaded: my_helper
INFO - 2023-09-24 11:55:17 --> Database Driver Class Initialized
INFO - 2023-09-24 11:55:17 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-24 11:55:17 --> Controller Class Initialized
INFO - 2023-09-24 11:55:17 --> Final output sent to browser
DEBUG - 2023-09-24 11:55:17 --> Total execution time: 0.0921
INFO - 2023-09-24 11:55:17 --> Config Class Initialized
INFO - 2023-09-24 11:55:17 --> Hooks Class Initialized
DEBUG - 2023-09-24 11:55:17 --> UTF-8 Support Enabled
INFO - 2023-09-24 11:55:17 --> Utf8 Class Initialized
INFO - 2023-09-24 11:55:17 --> URI Class Initialized
INFO - 2023-09-24 11:55:17 --> Router Class Initialized
INFO - 2023-09-24 11:55:17 --> Output Class Initialized
INFO - 2023-09-24 11:55:17 --> Security Class Initialized
DEBUG - 2023-09-24 11:55:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-24 11:55:17 --> Input Class Initialized
INFO - 2023-09-24 11:55:17 --> Language Class Initialized
INFO - 2023-09-24 11:55:17 --> Language Class Initialized
INFO - 2023-09-24 11:55:17 --> Config Class Initialized
INFO - 2023-09-24 11:55:17 --> Loader Class Initialized
INFO - 2023-09-24 11:55:17 --> Helper loaded: url_helper
INFO - 2023-09-24 11:55:17 --> Helper loaded: file_helper
INFO - 2023-09-24 11:55:17 --> Helper loaded: form_helper
INFO - 2023-09-24 11:55:17 --> Helper loaded: my_helper
INFO - 2023-09-24 11:55:17 --> Database Driver Class Initialized
INFO - 2023-09-24 11:55:17 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-24 11:55:17 --> Controller Class Initialized
INFO - 2023-09-24 11:55:18 --> Config Class Initialized
INFO - 2023-09-24 11:55:18 --> Hooks Class Initialized
DEBUG - 2023-09-24 11:55:18 --> UTF-8 Support Enabled
INFO - 2023-09-24 11:55:18 --> Utf8 Class Initialized
INFO - 2023-09-24 11:55:18 --> URI Class Initialized
INFO - 2023-09-24 11:55:18 --> Router Class Initialized
INFO - 2023-09-24 11:55:18 --> Output Class Initialized
INFO - 2023-09-24 11:55:18 --> Security Class Initialized
DEBUG - 2023-09-24 11:55:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-24 11:55:18 --> Input Class Initialized
INFO - 2023-09-24 11:55:18 --> Language Class Initialized
INFO - 2023-09-24 11:55:18 --> Language Class Initialized
INFO - 2023-09-24 11:55:18 --> Config Class Initialized
INFO - 2023-09-24 11:55:18 --> Loader Class Initialized
INFO - 2023-09-24 11:55:18 --> Helper loaded: url_helper
INFO - 2023-09-24 11:55:18 --> Helper loaded: file_helper
INFO - 2023-09-24 11:55:18 --> Helper loaded: form_helper
INFO - 2023-09-24 11:55:18 --> Helper loaded: my_helper
INFO - 2023-09-24 11:55:18 --> Database Driver Class Initialized
INFO - 2023-09-24 11:55:18 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-24 11:55:18 --> Controller Class Initialized
INFO - 2023-09-24 11:55:18 --> Final output sent to browser
DEBUG - 2023-09-24 11:55:18 --> Total execution time: 0.0371
INFO - 2023-09-24 11:55:26 --> Config Class Initialized
INFO - 2023-09-24 11:55:26 --> Hooks Class Initialized
DEBUG - 2023-09-24 11:55:26 --> UTF-8 Support Enabled
INFO - 2023-09-24 11:55:26 --> Utf8 Class Initialized
INFO - 2023-09-24 11:55:26 --> URI Class Initialized
INFO - 2023-09-24 11:55:26 --> Router Class Initialized
INFO - 2023-09-24 11:55:26 --> Output Class Initialized
INFO - 2023-09-24 11:55:26 --> Security Class Initialized
DEBUG - 2023-09-24 11:55:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-24 11:55:26 --> Input Class Initialized
INFO - 2023-09-24 11:55:26 --> Language Class Initialized
INFO - 2023-09-24 11:55:26 --> Language Class Initialized
INFO - 2023-09-24 11:55:26 --> Config Class Initialized
INFO - 2023-09-24 11:55:26 --> Loader Class Initialized
INFO - 2023-09-24 11:55:26 --> Helper loaded: url_helper
INFO - 2023-09-24 11:55:26 --> Helper loaded: file_helper
INFO - 2023-09-24 11:55:26 --> Helper loaded: form_helper
INFO - 2023-09-24 11:55:26 --> Helper loaded: my_helper
INFO - 2023-09-24 11:55:26 --> Database Driver Class Initialized
INFO - 2023-09-24 11:55:26 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-24 11:55:26 --> Controller Class Initialized
INFO - 2023-09-24 11:55:26 --> Final output sent to browser
DEBUG - 2023-09-24 11:55:26 --> Total execution time: 0.1140
INFO - 2023-09-24 11:55:27 --> Config Class Initialized
INFO - 2023-09-24 11:55:27 --> Hooks Class Initialized
DEBUG - 2023-09-24 11:55:27 --> UTF-8 Support Enabled
INFO - 2023-09-24 11:55:27 --> Utf8 Class Initialized
INFO - 2023-09-24 11:55:27 --> URI Class Initialized
INFO - 2023-09-24 11:55:27 --> Router Class Initialized
INFO - 2023-09-24 11:55:27 --> Output Class Initialized
INFO - 2023-09-24 11:55:27 --> Security Class Initialized
DEBUG - 2023-09-24 11:55:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-24 11:55:27 --> Input Class Initialized
INFO - 2023-09-24 11:55:27 --> Language Class Initialized
INFO - 2023-09-24 11:55:27 --> Language Class Initialized
INFO - 2023-09-24 11:55:27 --> Config Class Initialized
INFO - 2023-09-24 11:55:27 --> Loader Class Initialized
INFO - 2023-09-24 11:55:27 --> Helper loaded: url_helper
INFO - 2023-09-24 11:55:27 --> Helper loaded: file_helper
INFO - 2023-09-24 11:55:27 --> Helper loaded: form_helper
INFO - 2023-09-24 11:55:27 --> Helper loaded: my_helper
INFO - 2023-09-24 11:55:27 --> Database Driver Class Initialized
INFO - 2023-09-24 11:55:27 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-24 11:55:27 --> Controller Class Initialized
INFO - 2023-09-24 11:55:28 --> Config Class Initialized
INFO - 2023-09-24 11:55:28 --> Hooks Class Initialized
DEBUG - 2023-09-24 11:55:28 --> UTF-8 Support Enabled
INFO - 2023-09-24 11:55:28 --> Utf8 Class Initialized
INFO - 2023-09-24 11:55:28 --> URI Class Initialized
INFO - 2023-09-24 11:55:28 --> Router Class Initialized
INFO - 2023-09-24 11:55:28 --> Output Class Initialized
INFO - 2023-09-24 11:55:28 --> Security Class Initialized
DEBUG - 2023-09-24 11:55:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-24 11:55:28 --> Input Class Initialized
INFO - 2023-09-24 11:55:28 --> Language Class Initialized
INFO - 2023-09-24 11:55:28 --> Language Class Initialized
INFO - 2023-09-24 11:55:28 --> Config Class Initialized
INFO - 2023-09-24 11:55:28 --> Loader Class Initialized
INFO - 2023-09-24 11:55:28 --> Helper loaded: url_helper
INFO - 2023-09-24 11:55:28 --> Helper loaded: file_helper
INFO - 2023-09-24 11:55:28 --> Helper loaded: form_helper
INFO - 2023-09-24 11:55:28 --> Helper loaded: my_helper
INFO - 2023-09-24 11:55:28 --> Database Driver Class Initialized
INFO - 2023-09-24 11:55:28 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-24 11:55:28 --> Controller Class Initialized
INFO - 2023-09-24 11:55:28 --> Final output sent to browser
DEBUG - 2023-09-24 11:55:28 --> Total execution time: 0.0321
INFO - 2023-09-24 11:55:38 --> Config Class Initialized
INFO - 2023-09-24 11:55:38 --> Hooks Class Initialized
DEBUG - 2023-09-24 11:55:38 --> UTF-8 Support Enabled
INFO - 2023-09-24 11:55:38 --> Utf8 Class Initialized
INFO - 2023-09-24 11:55:38 --> URI Class Initialized
INFO - 2023-09-24 11:55:38 --> Router Class Initialized
INFO - 2023-09-24 11:55:38 --> Output Class Initialized
INFO - 2023-09-24 11:55:38 --> Security Class Initialized
DEBUG - 2023-09-24 11:55:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-24 11:55:38 --> Input Class Initialized
INFO - 2023-09-24 11:55:38 --> Language Class Initialized
INFO - 2023-09-24 11:55:38 --> Language Class Initialized
INFO - 2023-09-24 11:55:38 --> Config Class Initialized
INFO - 2023-09-24 11:55:38 --> Loader Class Initialized
INFO - 2023-09-24 11:55:38 --> Helper loaded: url_helper
INFO - 2023-09-24 11:55:38 --> Helper loaded: file_helper
INFO - 2023-09-24 11:55:38 --> Helper loaded: form_helper
INFO - 2023-09-24 11:55:38 --> Helper loaded: my_helper
INFO - 2023-09-24 11:55:38 --> Database Driver Class Initialized
INFO - 2023-09-24 11:55:38 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-24 11:55:38 --> Controller Class Initialized
INFO - 2023-09-24 11:55:38 --> Final output sent to browser
DEBUG - 2023-09-24 11:55:38 --> Total execution time: 0.0609
INFO - 2023-09-24 11:55:38 --> Config Class Initialized
INFO - 2023-09-24 11:55:38 --> Hooks Class Initialized
DEBUG - 2023-09-24 11:55:38 --> UTF-8 Support Enabled
INFO - 2023-09-24 11:55:38 --> Utf8 Class Initialized
INFO - 2023-09-24 11:55:38 --> URI Class Initialized
INFO - 2023-09-24 11:55:38 --> Router Class Initialized
INFO - 2023-09-24 11:55:38 --> Output Class Initialized
INFO - 2023-09-24 11:55:38 --> Security Class Initialized
DEBUG - 2023-09-24 11:55:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-24 11:55:38 --> Input Class Initialized
INFO - 2023-09-24 11:55:38 --> Language Class Initialized
INFO - 2023-09-24 11:55:38 --> Language Class Initialized
INFO - 2023-09-24 11:55:38 --> Config Class Initialized
INFO - 2023-09-24 11:55:38 --> Loader Class Initialized
INFO - 2023-09-24 11:55:38 --> Helper loaded: url_helper
INFO - 2023-09-24 11:55:38 --> Helper loaded: file_helper
INFO - 2023-09-24 11:55:38 --> Helper loaded: form_helper
INFO - 2023-09-24 11:55:38 --> Helper loaded: my_helper
INFO - 2023-09-24 11:55:38 --> Database Driver Class Initialized
INFO - 2023-09-24 11:55:38 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-24 11:55:38 --> Controller Class Initialized
INFO - 2023-09-24 11:55:39 --> Config Class Initialized
INFO - 2023-09-24 11:55:39 --> Hooks Class Initialized
DEBUG - 2023-09-24 11:55:39 --> UTF-8 Support Enabled
INFO - 2023-09-24 11:55:39 --> Utf8 Class Initialized
INFO - 2023-09-24 11:55:39 --> URI Class Initialized
INFO - 2023-09-24 11:55:39 --> Router Class Initialized
INFO - 2023-09-24 11:55:39 --> Output Class Initialized
INFO - 2023-09-24 11:55:39 --> Security Class Initialized
DEBUG - 2023-09-24 11:55:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-24 11:55:39 --> Input Class Initialized
INFO - 2023-09-24 11:55:39 --> Language Class Initialized
INFO - 2023-09-24 11:55:39 --> Language Class Initialized
INFO - 2023-09-24 11:55:39 --> Config Class Initialized
INFO - 2023-09-24 11:55:39 --> Loader Class Initialized
INFO - 2023-09-24 11:55:39 --> Helper loaded: url_helper
INFO - 2023-09-24 11:55:39 --> Helper loaded: file_helper
INFO - 2023-09-24 11:55:39 --> Helper loaded: form_helper
INFO - 2023-09-24 11:55:39 --> Helper loaded: my_helper
INFO - 2023-09-24 11:55:39 --> Database Driver Class Initialized
INFO - 2023-09-24 11:55:39 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-24 11:55:39 --> Controller Class Initialized
INFO - 2023-09-24 11:55:39 --> Final output sent to browser
DEBUG - 2023-09-24 11:55:39 --> Total execution time: 0.0347
INFO - 2023-09-24 11:55:49 --> Config Class Initialized
INFO - 2023-09-24 11:55:49 --> Hooks Class Initialized
DEBUG - 2023-09-24 11:55:49 --> UTF-8 Support Enabled
INFO - 2023-09-24 11:55:49 --> Utf8 Class Initialized
INFO - 2023-09-24 11:55:49 --> URI Class Initialized
INFO - 2023-09-24 11:55:49 --> Router Class Initialized
INFO - 2023-09-24 11:55:49 --> Output Class Initialized
INFO - 2023-09-24 11:55:49 --> Security Class Initialized
DEBUG - 2023-09-24 11:55:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-24 11:55:49 --> Input Class Initialized
INFO - 2023-09-24 11:55:49 --> Language Class Initialized
INFO - 2023-09-24 11:55:49 --> Language Class Initialized
INFO - 2023-09-24 11:55:49 --> Config Class Initialized
INFO - 2023-09-24 11:55:49 --> Loader Class Initialized
INFO - 2023-09-24 11:55:49 --> Helper loaded: url_helper
INFO - 2023-09-24 11:55:49 --> Helper loaded: file_helper
INFO - 2023-09-24 11:55:49 --> Helper loaded: form_helper
INFO - 2023-09-24 11:55:49 --> Helper loaded: my_helper
INFO - 2023-09-24 11:55:49 --> Database Driver Class Initialized
INFO - 2023-09-24 11:55:49 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-24 11:55:49 --> Controller Class Initialized
INFO - 2023-09-24 11:55:49 --> Final output sent to browser
DEBUG - 2023-09-24 11:55:49 --> Total execution time: 0.1119
INFO - 2023-09-24 11:55:49 --> Config Class Initialized
INFO - 2023-09-24 11:55:49 --> Hooks Class Initialized
DEBUG - 2023-09-24 11:55:49 --> UTF-8 Support Enabled
INFO - 2023-09-24 11:55:49 --> Utf8 Class Initialized
INFO - 2023-09-24 11:55:49 --> URI Class Initialized
INFO - 2023-09-24 11:55:49 --> Router Class Initialized
INFO - 2023-09-24 11:55:49 --> Output Class Initialized
INFO - 2023-09-24 11:55:49 --> Security Class Initialized
DEBUG - 2023-09-24 11:55:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-24 11:55:49 --> Input Class Initialized
INFO - 2023-09-24 11:55:49 --> Language Class Initialized
INFO - 2023-09-24 11:55:49 --> Language Class Initialized
INFO - 2023-09-24 11:55:49 --> Config Class Initialized
INFO - 2023-09-24 11:55:49 --> Loader Class Initialized
INFO - 2023-09-24 11:55:49 --> Helper loaded: url_helper
INFO - 2023-09-24 11:55:49 --> Helper loaded: file_helper
INFO - 2023-09-24 11:55:49 --> Helper loaded: form_helper
INFO - 2023-09-24 11:55:49 --> Helper loaded: my_helper
INFO - 2023-09-24 11:55:49 --> Database Driver Class Initialized
INFO - 2023-09-24 11:55:49 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-24 11:55:49 --> Controller Class Initialized
INFO - 2023-09-24 11:55:51 --> Config Class Initialized
INFO - 2023-09-24 11:55:51 --> Hooks Class Initialized
DEBUG - 2023-09-24 11:55:51 --> UTF-8 Support Enabled
INFO - 2023-09-24 11:55:51 --> Utf8 Class Initialized
INFO - 2023-09-24 11:55:51 --> URI Class Initialized
INFO - 2023-09-24 11:55:51 --> Router Class Initialized
INFO - 2023-09-24 11:55:51 --> Output Class Initialized
INFO - 2023-09-24 11:55:51 --> Security Class Initialized
DEBUG - 2023-09-24 11:55:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-24 11:55:51 --> Input Class Initialized
INFO - 2023-09-24 11:55:51 --> Language Class Initialized
INFO - 2023-09-24 11:55:51 --> Language Class Initialized
INFO - 2023-09-24 11:55:51 --> Config Class Initialized
INFO - 2023-09-24 11:55:51 --> Loader Class Initialized
INFO - 2023-09-24 11:55:51 --> Helper loaded: url_helper
INFO - 2023-09-24 11:55:51 --> Helper loaded: file_helper
INFO - 2023-09-24 11:55:51 --> Helper loaded: form_helper
INFO - 2023-09-24 11:55:51 --> Helper loaded: my_helper
INFO - 2023-09-24 11:55:51 --> Database Driver Class Initialized
INFO - 2023-09-24 11:55:51 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-24 11:55:51 --> Controller Class Initialized
INFO - 2023-09-24 11:55:51 --> Final output sent to browser
DEBUG - 2023-09-24 11:55:51 --> Total execution time: 0.0311
INFO - 2023-09-24 11:56:08 --> Config Class Initialized
INFO - 2023-09-24 11:56:08 --> Hooks Class Initialized
DEBUG - 2023-09-24 11:56:08 --> UTF-8 Support Enabled
INFO - 2023-09-24 11:56:08 --> Utf8 Class Initialized
INFO - 2023-09-24 11:56:08 --> URI Class Initialized
INFO - 2023-09-24 11:56:08 --> Router Class Initialized
INFO - 2023-09-24 11:56:08 --> Output Class Initialized
INFO - 2023-09-24 11:56:08 --> Security Class Initialized
DEBUG - 2023-09-24 11:56:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-24 11:56:08 --> Input Class Initialized
INFO - 2023-09-24 11:56:08 --> Language Class Initialized
INFO - 2023-09-24 11:56:08 --> Language Class Initialized
INFO - 2023-09-24 11:56:08 --> Config Class Initialized
INFO - 2023-09-24 11:56:08 --> Loader Class Initialized
INFO - 2023-09-24 11:56:08 --> Helper loaded: url_helper
INFO - 2023-09-24 11:56:08 --> Helper loaded: file_helper
INFO - 2023-09-24 11:56:08 --> Helper loaded: form_helper
INFO - 2023-09-24 11:56:08 --> Helper loaded: my_helper
INFO - 2023-09-24 11:56:08 --> Database Driver Class Initialized
INFO - 2023-09-24 11:56:08 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-24 11:56:08 --> Controller Class Initialized
INFO - 2023-09-24 11:56:08 --> Final output sent to browser
DEBUG - 2023-09-24 11:56:08 --> Total execution time: 0.0314
INFO - 2023-09-24 11:56:09 --> Config Class Initialized
INFO - 2023-09-24 11:56:09 --> Hooks Class Initialized
DEBUG - 2023-09-24 11:56:09 --> UTF-8 Support Enabled
INFO - 2023-09-24 11:56:09 --> Utf8 Class Initialized
INFO - 2023-09-24 11:56:09 --> URI Class Initialized
INFO - 2023-09-24 11:56:09 --> Router Class Initialized
INFO - 2023-09-24 11:56:09 --> Output Class Initialized
INFO - 2023-09-24 11:56:09 --> Security Class Initialized
DEBUG - 2023-09-24 11:56:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-24 11:56:09 --> Input Class Initialized
INFO - 2023-09-24 11:56:09 --> Language Class Initialized
INFO - 2023-09-24 11:56:09 --> Language Class Initialized
INFO - 2023-09-24 11:56:09 --> Config Class Initialized
INFO - 2023-09-24 11:56:09 --> Loader Class Initialized
INFO - 2023-09-24 11:56:09 --> Helper loaded: url_helper
INFO - 2023-09-24 11:56:09 --> Helper loaded: file_helper
INFO - 2023-09-24 11:56:09 --> Helper loaded: form_helper
INFO - 2023-09-24 11:56:09 --> Helper loaded: my_helper
INFO - 2023-09-24 11:56:09 --> Database Driver Class Initialized
INFO - 2023-09-24 11:56:09 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-24 11:56:09 --> Controller Class Initialized
INFO - 2023-09-24 11:56:15 --> Config Class Initialized
INFO - 2023-09-24 11:56:15 --> Hooks Class Initialized
DEBUG - 2023-09-24 11:56:15 --> UTF-8 Support Enabled
INFO - 2023-09-24 11:56:15 --> Utf8 Class Initialized
INFO - 2023-09-24 11:56:15 --> URI Class Initialized
INFO - 2023-09-24 11:56:15 --> Router Class Initialized
INFO - 2023-09-24 11:56:15 --> Output Class Initialized
INFO - 2023-09-24 11:56:15 --> Security Class Initialized
DEBUG - 2023-09-24 11:56:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-24 11:56:15 --> Input Class Initialized
INFO - 2023-09-24 11:56:15 --> Language Class Initialized
INFO - 2023-09-24 11:56:15 --> Language Class Initialized
INFO - 2023-09-24 11:56:15 --> Config Class Initialized
INFO - 2023-09-24 11:56:15 --> Loader Class Initialized
INFO - 2023-09-24 11:56:15 --> Helper loaded: url_helper
INFO - 2023-09-24 11:56:15 --> Helper loaded: file_helper
INFO - 2023-09-24 11:56:15 --> Helper loaded: form_helper
INFO - 2023-09-24 11:56:15 --> Helper loaded: my_helper
INFO - 2023-09-24 11:56:15 --> Database Driver Class Initialized
INFO - 2023-09-24 11:56:15 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-24 11:56:15 --> Controller Class Initialized
INFO - 2023-09-24 11:56:15 --> Final output sent to browser
DEBUG - 2023-09-24 11:56:15 --> Total execution time: 0.0364
INFO - 2023-09-24 11:56:23 --> Config Class Initialized
INFO - 2023-09-24 11:56:23 --> Hooks Class Initialized
DEBUG - 2023-09-24 11:56:23 --> UTF-8 Support Enabled
INFO - 2023-09-24 11:56:23 --> Utf8 Class Initialized
INFO - 2023-09-24 11:56:23 --> URI Class Initialized
INFO - 2023-09-24 11:56:23 --> Router Class Initialized
INFO - 2023-09-24 11:56:23 --> Output Class Initialized
INFO - 2023-09-24 11:56:23 --> Security Class Initialized
DEBUG - 2023-09-24 11:56:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-24 11:56:23 --> Input Class Initialized
INFO - 2023-09-24 11:56:23 --> Language Class Initialized
INFO - 2023-09-24 11:56:23 --> Language Class Initialized
INFO - 2023-09-24 11:56:23 --> Config Class Initialized
INFO - 2023-09-24 11:56:23 --> Loader Class Initialized
INFO - 2023-09-24 11:56:23 --> Helper loaded: url_helper
INFO - 2023-09-24 11:56:23 --> Helper loaded: file_helper
INFO - 2023-09-24 11:56:23 --> Helper loaded: form_helper
INFO - 2023-09-24 11:56:23 --> Helper loaded: my_helper
INFO - 2023-09-24 11:56:23 --> Database Driver Class Initialized
INFO - 2023-09-24 11:56:23 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-24 11:56:23 --> Controller Class Initialized
INFO - 2023-09-24 11:56:23 --> Final output sent to browser
DEBUG - 2023-09-24 11:56:23 --> Total execution time: 0.1066
INFO - 2023-09-24 11:56:23 --> Config Class Initialized
INFO - 2023-09-24 11:56:23 --> Hooks Class Initialized
DEBUG - 2023-09-24 11:56:23 --> UTF-8 Support Enabled
INFO - 2023-09-24 11:56:23 --> Utf8 Class Initialized
INFO - 2023-09-24 11:56:23 --> URI Class Initialized
INFO - 2023-09-24 11:56:23 --> Router Class Initialized
INFO - 2023-09-24 11:56:23 --> Output Class Initialized
INFO - 2023-09-24 11:56:23 --> Security Class Initialized
DEBUG - 2023-09-24 11:56:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-24 11:56:23 --> Input Class Initialized
INFO - 2023-09-24 11:56:23 --> Language Class Initialized
INFO - 2023-09-24 11:56:23 --> Language Class Initialized
INFO - 2023-09-24 11:56:23 --> Config Class Initialized
INFO - 2023-09-24 11:56:23 --> Loader Class Initialized
INFO - 2023-09-24 11:56:23 --> Helper loaded: url_helper
INFO - 2023-09-24 11:56:23 --> Helper loaded: file_helper
INFO - 2023-09-24 11:56:23 --> Helper loaded: form_helper
INFO - 2023-09-24 11:56:23 --> Helper loaded: my_helper
INFO - 2023-09-24 11:56:24 --> Database Driver Class Initialized
INFO - 2023-09-24 11:56:24 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-24 11:56:24 --> Controller Class Initialized
INFO - 2023-09-24 11:56:25 --> Config Class Initialized
INFO - 2023-09-24 11:56:25 --> Hooks Class Initialized
DEBUG - 2023-09-24 11:56:25 --> UTF-8 Support Enabled
INFO - 2023-09-24 11:56:25 --> Utf8 Class Initialized
INFO - 2023-09-24 11:56:25 --> URI Class Initialized
INFO - 2023-09-24 11:56:25 --> Router Class Initialized
INFO - 2023-09-24 11:56:25 --> Output Class Initialized
INFO - 2023-09-24 11:56:25 --> Security Class Initialized
DEBUG - 2023-09-24 11:56:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-24 11:56:25 --> Input Class Initialized
INFO - 2023-09-24 11:56:25 --> Language Class Initialized
INFO - 2023-09-24 11:56:25 --> Language Class Initialized
INFO - 2023-09-24 11:56:25 --> Config Class Initialized
INFO - 2023-09-24 11:56:25 --> Loader Class Initialized
INFO - 2023-09-24 11:56:25 --> Helper loaded: url_helper
INFO - 2023-09-24 11:56:25 --> Helper loaded: file_helper
INFO - 2023-09-24 11:56:25 --> Helper loaded: form_helper
INFO - 2023-09-24 11:56:25 --> Helper loaded: my_helper
INFO - 2023-09-24 11:56:25 --> Database Driver Class Initialized
INFO - 2023-09-24 11:56:25 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-24 11:56:25 --> Controller Class Initialized
INFO - 2023-09-24 11:56:25 --> Final output sent to browser
DEBUG - 2023-09-24 11:56:25 --> Total execution time: 0.0532
INFO - 2023-09-24 11:56:34 --> Config Class Initialized
INFO - 2023-09-24 11:56:34 --> Hooks Class Initialized
DEBUG - 2023-09-24 11:56:34 --> UTF-8 Support Enabled
INFO - 2023-09-24 11:56:34 --> Utf8 Class Initialized
INFO - 2023-09-24 11:56:34 --> URI Class Initialized
INFO - 2023-09-24 11:56:34 --> Router Class Initialized
INFO - 2023-09-24 11:56:34 --> Output Class Initialized
INFO - 2023-09-24 11:56:34 --> Security Class Initialized
DEBUG - 2023-09-24 11:56:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-24 11:56:34 --> Input Class Initialized
INFO - 2023-09-24 11:56:34 --> Language Class Initialized
INFO - 2023-09-24 11:56:34 --> Language Class Initialized
INFO - 2023-09-24 11:56:34 --> Config Class Initialized
INFO - 2023-09-24 11:56:34 --> Loader Class Initialized
INFO - 2023-09-24 11:56:34 --> Helper loaded: url_helper
INFO - 2023-09-24 11:56:34 --> Helper loaded: file_helper
INFO - 2023-09-24 11:56:34 --> Helper loaded: form_helper
INFO - 2023-09-24 11:56:34 --> Helper loaded: my_helper
INFO - 2023-09-24 11:56:34 --> Database Driver Class Initialized
INFO - 2023-09-24 11:56:34 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-24 11:56:34 --> Controller Class Initialized
INFO - 2023-09-24 11:56:34 --> Final output sent to browser
DEBUG - 2023-09-24 11:56:34 --> Total execution time: 0.0719
INFO - 2023-09-24 11:56:34 --> Config Class Initialized
INFO - 2023-09-24 11:56:34 --> Hooks Class Initialized
DEBUG - 2023-09-24 11:56:34 --> UTF-8 Support Enabled
INFO - 2023-09-24 11:56:34 --> Utf8 Class Initialized
INFO - 2023-09-24 11:56:34 --> URI Class Initialized
INFO - 2023-09-24 11:56:34 --> Router Class Initialized
INFO - 2023-09-24 11:56:34 --> Output Class Initialized
INFO - 2023-09-24 11:56:34 --> Security Class Initialized
DEBUG - 2023-09-24 11:56:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-24 11:56:34 --> Input Class Initialized
INFO - 2023-09-24 11:56:34 --> Language Class Initialized
INFO - 2023-09-24 11:56:34 --> Language Class Initialized
INFO - 2023-09-24 11:56:34 --> Config Class Initialized
INFO - 2023-09-24 11:56:34 --> Loader Class Initialized
INFO - 2023-09-24 11:56:34 --> Helper loaded: url_helper
INFO - 2023-09-24 11:56:34 --> Helper loaded: file_helper
INFO - 2023-09-24 11:56:34 --> Helper loaded: form_helper
INFO - 2023-09-24 11:56:34 --> Helper loaded: my_helper
INFO - 2023-09-24 11:56:34 --> Database Driver Class Initialized
INFO - 2023-09-24 11:56:34 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-24 11:56:34 --> Controller Class Initialized
INFO - 2023-09-24 11:56:35 --> Config Class Initialized
INFO - 2023-09-24 11:56:35 --> Hooks Class Initialized
DEBUG - 2023-09-24 11:56:35 --> UTF-8 Support Enabled
INFO - 2023-09-24 11:56:35 --> Utf8 Class Initialized
INFO - 2023-09-24 11:56:35 --> URI Class Initialized
INFO - 2023-09-24 11:56:35 --> Router Class Initialized
INFO - 2023-09-24 11:56:35 --> Output Class Initialized
INFO - 2023-09-24 11:56:35 --> Security Class Initialized
DEBUG - 2023-09-24 11:56:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-24 11:56:35 --> Input Class Initialized
INFO - 2023-09-24 11:56:35 --> Language Class Initialized
INFO - 2023-09-24 11:56:35 --> Language Class Initialized
INFO - 2023-09-24 11:56:35 --> Config Class Initialized
INFO - 2023-09-24 11:56:35 --> Loader Class Initialized
INFO - 2023-09-24 11:56:35 --> Helper loaded: url_helper
INFO - 2023-09-24 11:56:35 --> Helper loaded: file_helper
INFO - 2023-09-24 11:56:35 --> Helper loaded: form_helper
INFO - 2023-09-24 11:56:35 --> Helper loaded: my_helper
INFO - 2023-09-24 11:56:35 --> Database Driver Class Initialized
INFO - 2023-09-24 11:56:35 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-24 11:56:35 --> Controller Class Initialized
INFO - 2023-09-24 11:56:35 --> Final output sent to browser
DEBUG - 2023-09-24 11:56:35 --> Total execution time: 0.0300
INFO - 2023-09-24 11:56:46 --> Config Class Initialized
INFO - 2023-09-24 11:56:46 --> Hooks Class Initialized
DEBUG - 2023-09-24 11:56:46 --> UTF-8 Support Enabled
INFO - 2023-09-24 11:56:46 --> Utf8 Class Initialized
INFO - 2023-09-24 11:56:46 --> URI Class Initialized
INFO - 2023-09-24 11:56:46 --> Router Class Initialized
INFO - 2023-09-24 11:56:46 --> Output Class Initialized
INFO - 2023-09-24 11:56:46 --> Security Class Initialized
DEBUG - 2023-09-24 11:56:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-24 11:56:46 --> Input Class Initialized
INFO - 2023-09-24 11:56:46 --> Language Class Initialized
INFO - 2023-09-24 11:56:46 --> Language Class Initialized
INFO - 2023-09-24 11:56:46 --> Config Class Initialized
INFO - 2023-09-24 11:56:46 --> Loader Class Initialized
INFO - 2023-09-24 11:56:46 --> Helper loaded: url_helper
INFO - 2023-09-24 11:56:46 --> Helper loaded: file_helper
INFO - 2023-09-24 11:56:46 --> Helper loaded: form_helper
INFO - 2023-09-24 11:56:46 --> Helper loaded: my_helper
INFO - 2023-09-24 11:56:46 --> Database Driver Class Initialized
INFO - 2023-09-24 11:56:46 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-24 11:56:46 --> Controller Class Initialized
INFO - 2023-09-24 11:56:46 --> Final output sent to browser
DEBUG - 2023-09-24 11:56:46 --> Total execution time: 0.0346
INFO - 2023-09-24 11:56:46 --> Config Class Initialized
INFO - 2023-09-24 11:56:46 --> Hooks Class Initialized
DEBUG - 2023-09-24 11:56:46 --> UTF-8 Support Enabled
INFO - 2023-09-24 11:56:46 --> Utf8 Class Initialized
INFO - 2023-09-24 11:56:46 --> URI Class Initialized
INFO - 2023-09-24 11:56:46 --> Router Class Initialized
INFO - 2023-09-24 11:56:46 --> Output Class Initialized
INFO - 2023-09-24 11:56:46 --> Security Class Initialized
DEBUG - 2023-09-24 11:56:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-24 11:56:46 --> Input Class Initialized
INFO - 2023-09-24 11:56:46 --> Language Class Initialized
INFO - 2023-09-24 11:56:46 --> Language Class Initialized
INFO - 2023-09-24 11:56:46 --> Config Class Initialized
INFO - 2023-09-24 11:56:46 --> Loader Class Initialized
INFO - 2023-09-24 11:56:46 --> Helper loaded: url_helper
INFO - 2023-09-24 11:56:46 --> Helper loaded: file_helper
INFO - 2023-09-24 11:56:46 --> Helper loaded: form_helper
INFO - 2023-09-24 11:56:46 --> Helper loaded: my_helper
INFO - 2023-09-24 11:56:46 --> Database Driver Class Initialized
INFO - 2023-09-24 11:56:46 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-24 11:56:46 --> Controller Class Initialized
INFO - 2023-09-24 11:56:47 --> Config Class Initialized
INFO - 2023-09-24 11:56:47 --> Hooks Class Initialized
DEBUG - 2023-09-24 11:56:47 --> UTF-8 Support Enabled
INFO - 2023-09-24 11:56:47 --> Utf8 Class Initialized
INFO - 2023-09-24 11:56:47 --> URI Class Initialized
INFO - 2023-09-24 11:56:47 --> Router Class Initialized
INFO - 2023-09-24 11:56:47 --> Output Class Initialized
INFO - 2023-09-24 11:56:47 --> Security Class Initialized
DEBUG - 2023-09-24 11:56:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-24 11:56:47 --> Input Class Initialized
INFO - 2023-09-24 11:56:47 --> Language Class Initialized
INFO - 2023-09-24 11:56:47 --> Language Class Initialized
INFO - 2023-09-24 11:56:47 --> Config Class Initialized
INFO - 2023-09-24 11:56:47 --> Loader Class Initialized
INFO - 2023-09-24 11:56:47 --> Helper loaded: url_helper
INFO - 2023-09-24 11:56:47 --> Helper loaded: file_helper
INFO - 2023-09-24 11:56:47 --> Helper loaded: form_helper
INFO - 2023-09-24 11:56:47 --> Helper loaded: my_helper
INFO - 2023-09-24 11:56:47 --> Database Driver Class Initialized
INFO - 2023-09-24 11:56:47 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-24 11:56:47 --> Controller Class Initialized
INFO - 2023-09-24 11:56:47 --> Final output sent to browser
DEBUG - 2023-09-24 11:56:47 --> Total execution time: 0.0303
INFO - 2023-09-24 11:56:56 --> Config Class Initialized
INFO - 2023-09-24 11:56:56 --> Hooks Class Initialized
DEBUG - 2023-09-24 11:56:56 --> UTF-8 Support Enabled
INFO - 2023-09-24 11:56:56 --> Utf8 Class Initialized
INFO - 2023-09-24 11:56:56 --> URI Class Initialized
INFO - 2023-09-24 11:56:56 --> Router Class Initialized
INFO - 2023-09-24 11:56:56 --> Output Class Initialized
INFO - 2023-09-24 11:56:56 --> Security Class Initialized
DEBUG - 2023-09-24 11:56:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-24 11:56:56 --> Input Class Initialized
INFO - 2023-09-24 11:56:56 --> Language Class Initialized
INFO - 2023-09-24 11:56:56 --> Language Class Initialized
INFO - 2023-09-24 11:56:56 --> Config Class Initialized
INFO - 2023-09-24 11:56:56 --> Loader Class Initialized
INFO - 2023-09-24 11:56:56 --> Helper loaded: url_helper
INFO - 2023-09-24 11:56:56 --> Helper loaded: file_helper
INFO - 2023-09-24 11:56:56 --> Helper loaded: form_helper
INFO - 2023-09-24 11:56:56 --> Helper loaded: my_helper
INFO - 2023-09-24 11:56:56 --> Database Driver Class Initialized
INFO - 2023-09-24 11:56:56 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-24 11:56:56 --> Controller Class Initialized
INFO - 2023-09-24 11:56:56 --> Final output sent to browser
DEBUG - 2023-09-24 11:56:56 --> Total execution time: 0.0388
INFO - 2023-09-24 11:56:57 --> Config Class Initialized
INFO - 2023-09-24 11:56:57 --> Hooks Class Initialized
DEBUG - 2023-09-24 11:56:57 --> UTF-8 Support Enabled
INFO - 2023-09-24 11:56:57 --> Utf8 Class Initialized
INFO - 2023-09-24 11:56:57 --> URI Class Initialized
INFO - 2023-09-24 11:56:57 --> Router Class Initialized
INFO - 2023-09-24 11:56:57 --> Output Class Initialized
INFO - 2023-09-24 11:56:57 --> Security Class Initialized
DEBUG - 2023-09-24 11:56:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-24 11:56:57 --> Input Class Initialized
INFO - 2023-09-24 11:56:57 --> Language Class Initialized
INFO - 2023-09-24 11:56:57 --> Language Class Initialized
INFO - 2023-09-24 11:56:57 --> Config Class Initialized
INFO - 2023-09-24 11:56:57 --> Loader Class Initialized
INFO - 2023-09-24 11:56:57 --> Helper loaded: url_helper
INFO - 2023-09-24 11:56:57 --> Helper loaded: file_helper
INFO - 2023-09-24 11:56:57 --> Helper loaded: form_helper
INFO - 2023-09-24 11:56:57 --> Helper loaded: my_helper
INFO - 2023-09-24 11:56:57 --> Database Driver Class Initialized
INFO - 2023-09-24 11:56:57 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-24 11:56:57 --> Controller Class Initialized
INFO - 2023-09-24 11:56:58 --> Config Class Initialized
INFO - 2023-09-24 11:56:58 --> Hooks Class Initialized
DEBUG - 2023-09-24 11:56:58 --> UTF-8 Support Enabled
INFO - 2023-09-24 11:56:58 --> Utf8 Class Initialized
INFO - 2023-09-24 11:56:58 --> URI Class Initialized
INFO - 2023-09-24 11:56:58 --> Router Class Initialized
INFO - 2023-09-24 11:56:58 --> Output Class Initialized
INFO - 2023-09-24 11:56:58 --> Security Class Initialized
DEBUG - 2023-09-24 11:56:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-24 11:56:58 --> Input Class Initialized
INFO - 2023-09-24 11:56:58 --> Language Class Initialized
INFO - 2023-09-24 11:56:58 --> Language Class Initialized
INFO - 2023-09-24 11:56:58 --> Config Class Initialized
INFO - 2023-09-24 11:56:58 --> Loader Class Initialized
INFO - 2023-09-24 11:56:58 --> Helper loaded: url_helper
INFO - 2023-09-24 11:56:58 --> Helper loaded: file_helper
INFO - 2023-09-24 11:56:58 --> Helper loaded: form_helper
INFO - 2023-09-24 11:56:58 --> Helper loaded: my_helper
INFO - 2023-09-24 11:56:58 --> Database Driver Class Initialized
INFO - 2023-09-24 11:56:58 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-24 11:56:58 --> Controller Class Initialized
INFO - 2023-09-24 11:56:58 --> Final output sent to browser
DEBUG - 2023-09-24 11:56:58 --> Total execution time: 0.0285
INFO - 2023-09-24 11:57:09 --> Config Class Initialized
INFO - 2023-09-24 11:57:09 --> Hooks Class Initialized
DEBUG - 2023-09-24 11:57:09 --> UTF-8 Support Enabled
INFO - 2023-09-24 11:57:09 --> Utf8 Class Initialized
INFO - 2023-09-24 11:57:09 --> URI Class Initialized
INFO - 2023-09-24 11:57:09 --> Router Class Initialized
INFO - 2023-09-24 11:57:09 --> Output Class Initialized
INFO - 2023-09-24 11:57:09 --> Security Class Initialized
DEBUG - 2023-09-24 11:57:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-24 11:57:09 --> Input Class Initialized
INFO - 2023-09-24 11:57:09 --> Language Class Initialized
INFO - 2023-09-24 11:57:09 --> Language Class Initialized
INFO - 2023-09-24 11:57:09 --> Config Class Initialized
INFO - 2023-09-24 11:57:09 --> Loader Class Initialized
INFO - 2023-09-24 11:57:09 --> Helper loaded: url_helper
INFO - 2023-09-24 11:57:09 --> Helper loaded: file_helper
INFO - 2023-09-24 11:57:09 --> Helper loaded: form_helper
INFO - 2023-09-24 11:57:09 --> Helper loaded: my_helper
INFO - 2023-09-24 11:57:09 --> Database Driver Class Initialized
INFO - 2023-09-24 11:57:09 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-24 11:57:09 --> Controller Class Initialized
INFO - 2023-09-24 11:57:09 --> Final output sent to browser
DEBUG - 2023-09-24 11:57:09 --> Total execution time: 0.0387
INFO - 2023-09-24 11:57:09 --> Config Class Initialized
INFO - 2023-09-24 11:57:09 --> Hooks Class Initialized
DEBUG - 2023-09-24 11:57:09 --> UTF-8 Support Enabled
INFO - 2023-09-24 11:57:09 --> Utf8 Class Initialized
INFO - 2023-09-24 11:57:09 --> URI Class Initialized
INFO - 2023-09-24 11:57:09 --> Router Class Initialized
INFO - 2023-09-24 11:57:09 --> Output Class Initialized
INFO - 2023-09-24 11:57:09 --> Security Class Initialized
DEBUG - 2023-09-24 11:57:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-24 11:57:09 --> Input Class Initialized
INFO - 2023-09-24 11:57:09 --> Language Class Initialized
INFO - 2023-09-24 11:57:09 --> Language Class Initialized
INFO - 2023-09-24 11:57:09 --> Config Class Initialized
INFO - 2023-09-24 11:57:09 --> Loader Class Initialized
INFO - 2023-09-24 11:57:09 --> Helper loaded: url_helper
INFO - 2023-09-24 11:57:09 --> Helper loaded: file_helper
INFO - 2023-09-24 11:57:09 --> Helper loaded: form_helper
INFO - 2023-09-24 11:57:09 --> Helper loaded: my_helper
INFO - 2023-09-24 11:57:09 --> Database Driver Class Initialized
INFO - 2023-09-24 11:57:10 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-24 11:57:10 --> Controller Class Initialized
INFO - 2023-09-24 11:57:10 --> Config Class Initialized
INFO - 2023-09-24 11:57:10 --> Hooks Class Initialized
DEBUG - 2023-09-24 11:57:10 --> UTF-8 Support Enabled
INFO - 2023-09-24 11:57:10 --> Utf8 Class Initialized
INFO - 2023-09-24 11:57:10 --> URI Class Initialized
INFO - 2023-09-24 11:57:10 --> Router Class Initialized
INFO - 2023-09-24 11:57:10 --> Output Class Initialized
INFO - 2023-09-24 11:57:10 --> Security Class Initialized
DEBUG - 2023-09-24 11:57:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-24 11:57:10 --> Input Class Initialized
INFO - 2023-09-24 11:57:10 --> Language Class Initialized
INFO - 2023-09-24 11:57:10 --> Language Class Initialized
INFO - 2023-09-24 11:57:10 --> Config Class Initialized
INFO - 2023-09-24 11:57:10 --> Loader Class Initialized
INFO - 2023-09-24 11:57:10 --> Helper loaded: url_helper
INFO - 2023-09-24 11:57:10 --> Helper loaded: file_helper
INFO - 2023-09-24 11:57:10 --> Helper loaded: form_helper
INFO - 2023-09-24 11:57:10 --> Helper loaded: my_helper
INFO - 2023-09-24 11:57:10 --> Database Driver Class Initialized
INFO - 2023-09-24 11:57:10 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-24 11:57:10 --> Controller Class Initialized
INFO - 2023-09-24 11:57:10 --> Final output sent to browser
DEBUG - 2023-09-24 11:57:10 --> Total execution time: 0.0351
INFO - 2023-09-24 11:57:18 --> Config Class Initialized
INFO - 2023-09-24 11:57:18 --> Hooks Class Initialized
DEBUG - 2023-09-24 11:57:18 --> UTF-8 Support Enabled
INFO - 2023-09-24 11:57:18 --> Utf8 Class Initialized
INFO - 2023-09-24 11:57:18 --> URI Class Initialized
INFO - 2023-09-24 11:57:18 --> Router Class Initialized
INFO - 2023-09-24 11:57:18 --> Output Class Initialized
INFO - 2023-09-24 11:57:18 --> Security Class Initialized
DEBUG - 2023-09-24 11:57:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-24 11:57:18 --> Input Class Initialized
INFO - 2023-09-24 11:57:18 --> Language Class Initialized
INFO - 2023-09-24 11:57:18 --> Language Class Initialized
INFO - 2023-09-24 11:57:18 --> Config Class Initialized
INFO - 2023-09-24 11:57:18 --> Loader Class Initialized
INFO - 2023-09-24 11:57:18 --> Helper loaded: url_helper
INFO - 2023-09-24 11:57:18 --> Helper loaded: file_helper
INFO - 2023-09-24 11:57:18 --> Helper loaded: form_helper
INFO - 2023-09-24 11:57:18 --> Helper loaded: my_helper
INFO - 2023-09-24 11:57:18 --> Database Driver Class Initialized
INFO - 2023-09-24 11:57:18 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-24 11:57:18 --> Controller Class Initialized
INFO - 2023-09-24 11:57:18 --> Final output sent to browser
DEBUG - 2023-09-24 11:57:18 --> Total execution time: 0.0313
INFO - 2023-09-24 11:57:18 --> Config Class Initialized
INFO - 2023-09-24 11:57:18 --> Hooks Class Initialized
DEBUG - 2023-09-24 11:57:18 --> UTF-8 Support Enabled
INFO - 2023-09-24 11:57:18 --> Utf8 Class Initialized
INFO - 2023-09-24 11:57:18 --> URI Class Initialized
INFO - 2023-09-24 11:57:18 --> Router Class Initialized
INFO - 2023-09-24 11:57:18 --> Output Class Initialized
INFO - 2023-09-24 11:57:18 --> Security Class Initialized
DEBUG - 2023-09-24 11:57:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-24 11:57:18 --> Input Class Initialized
INFO - 2023-09-24 11:57:18 --> Language Class Initialized
INFO - 2023-09-24 11:57:19 --> Language Class Initialized
INFO - 2023-09-24 11:57:19 --> Config Class Initialized
INFO - 2023-09-24 11:57:19 --> Loader Class Initialized
INFO - 2023-09-24 11:57:19 --> Helper loaded: url_helper
INFO - 2023-09-24 11:57:19 --> Helper loaded: file_helper
INFO - 2023-09-24 11:57:19 --> Helper loaded: form_helper
INFO - 2023-09-24 11:57:19 --> Helper loaded: my_helper
INFO - 2023-09-24 11:57:19 --> Database Driver Class Initialized
INFO - 2023-09-24 11:57:19 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-24 11:57:19 --> Controller Class Initialized
INFO - 2023-09-24 11:57:20 --> Config Class Initialized
INFO - 2023-09-24 11:57:20 --> Hooks Class Initialized
DEBUG - 2023-09-24 11:57:20 --> UTF-8 Support Enabled
INFO - 2023-09-24 11:57:20 --> Utf8 Class Initialized
INFO - 2023-09-24 11:57:20 --> URI Class Initialized
INFO - 2023-09-24 11:57:20 --> Router Class Initialized
INFO - 2023-09-24 11:57:20 --> Output Class Initialized
INFO - 2023-09-24 11:57:20 --> Security Class Initialized
DEBUG - 2023-09-24 11:57:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-24 11:57:20 --> Input Class Initialized
INFO - 2023-09-24 11:57:20 --> Language Class Initialized
INFO - 2023-09-24 11:57:20 --> Language Class Initialized
INFO - 2023-09-24 11:57:20 --> Config Class Initialized
INFO - 2023-09-24 11:57:20 --> Loader Class Initialized
INFO - 2023-09-24 11:57:20 --> Helper loaded: url_helper
INFO - 2023-09-24 11:57:20 --> Helper loaded: file_helper
INFO - 2023-09-24 11:57:20 --> Helper loaded: form_helper
INFO - 2023-09-24 11:57:20 --> Helper loaded: my_helper
INFO - 2023-09-24 11:57:20 --> Database Driver Class Initialized
INFO - 2023-09-24 11:57:20 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-24 11:57:20 --> Controller Class Initialized
INFO - 2023-09-24 11:57:20 --> Final output sent to browser
DEBUG - 2023-09-24 11:57:20 --> Total execution time: 0.0312
INFO - 2023-09-24 11:57:29 --> Config Class Initialized
INFO - 2023-09-24 11:57:29 --> Hooks Class Initialized
DEBUG - 2023-09-24 11:57:29 --> UTF-8 Support Enabled
INFO - 2023-09-24 11:57:29 --> Utf8 Class Initialized
INFO - 2023-09-24 11:57:29 --> URI Class Initialized
INFO - 2023-09-24 11:57:29 --> Router Class Initialized
INFO - 2023-09-24 11:57:29 --> Output Class Initialized
INFO - 2023-09-24 11:57:29 --> Security Class Initialized
DEBUG - 2023-09-24 11:57:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-24 11:57:29 --> Input Class Initialized
INFO - 2023-09-24 11:57:29 --> Language Class Initialized
INFO - 2023-09-24 11:57:29 --> Language Class Initialized
INFO - 2023-09-24 11:57:29 --> Config Class Initialized
INFO - 2023-09-24 11:57:29 --> Loader Class Initialized
INFO - 2023-09-24 11:57:29 --> Helper loaded: url_helper
INFO - 2023-09-24 11:57:29 --> Helper loaded: file_helper
INFO - 2023-09-24 11:57:29 --> Helper loaded: form_helper
INFO - 2023-09-24 11:57:29 --> Helper loaded: my_helper
INFO - 2023-09-24 11:57:29 --> Database Driver Class Initialized
INFO - 2023-09-24 11:57:29 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-24 11:57:29 --> Controller Class Initialized
INFO - 2023-09-24 11:57:29 --> Final output sent to browser
DEBUG - 2023-09-24 11:57:29 --> Total execution time: 0.0405
INFO - 2023-09-24 11:57:29 --> Config Class Initialized
INFO - 2023-09-24 11:57:29 --> Hooks Class Initialized
DEBUG - 2023-09-24 11:57:29 --> UTF-8 Support Enabled
INFO - 2023-09-24 11:57:29 --> Utf8 Class Initialized
INFO - 2023-09-24 11:57:29 --> URI Class Initialized
INFO - 2023-09-24 11:57:29 --> Router Class Initialized
INFO - 2023-09-24 11:57:29 --> Output Class Initialized
INFO - 2023-09-24 11:57:29 --> Security Class Initialized
DEBUG - 2023-09-24 11:57:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-24 11:57:29 --> Input Class Initialized
INFO - 2023-09-24 11:57:29 --> Language Class Initialized
INFO - 2023-09-24 11:57:29 --> Language Class Initialized
INFO - 2023-09-24 11:57:29 --> Config Class Initialized
INFO - 2023-09-24 11:57:29 --> Loader Class Initialized
INFO - 2023-09-24 11:57:29 --> Helper loaded: url_helper
INFO - 2023-09-24 11:57:29 --> Helper loaded: file_helper
INFO - 2023-09-24 11:57:29 --> Helper loaded: form_helper
INFO - 2023-09-24 11:57:30 --> Helper loaded: my_helper
INFO - 2023-09-24 11:57:30 --> Database Driver Class Initialized
INFO - 2023-09-24 11:57:30 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-24 11:57:30 --> Controller Class Initialized
INFO - 2023-09-24 11:57:31 --> Config Class Initialized
INFO - 2023-09-24 11:57:31 --> Hooks Class Initialized
DEBUG - 2023-09-24 11:57:31 --> UTF-8 Support Enabled
INFO - 2023-09-24 11:57:31 --> Utf8 Class Initialized
INFO - 2023-09-24 11:57:31 --> URI Class Initialized
INFO - 2023-09-24 11:57:31 --> Router Class Initialized
INFO - 2023-09-24 11:57:31 --> Output Class Initialized
INFO - 2023-09-24 11:57:31 --> Security Class Initialized
DEBUG - 2023-09-24 11:57:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-24 11:57:31 --> Input Class Initialized
INFO - 2023-09-24 11:57:31 --> Language Class Initialized
INFO - 2023-09-24 11:57:31 --> Language Class Initialized
INFO - 2023-09-24 11:57:31 --> Config Class Initialized
INFO - 2023-09-24 11:57:31 --> Loader Class Initialized
INFO - 2023-09-24 11:57:31 --> Helper loaded: url_helper
INFO - 2023-09-24 11:57:31 --> Helper loaded: file_helper
INFO - 2023-09-24 11:57:31 --> Helper loaded: form_helper
INFO - 2023-09-24 11:57:31 --> Helper loaded: my_helper
INFO - 2023-09-24 11:57:31 --> Database Driver Class Initialized
INFO - 2023-09-24 11:57:31 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-24 11:57:31 --> Controller Class Initialized
INFO - 2023-09-24 11:57:31 --> Final output sent to browser
DEBUG - 2023-09-24 11:57:31 --> Total execution time: 0.0299
INFO - 2023-09-24 11:57:39 --> Config Class Initialized
INFO - 2023-09-24 11:57:39 --> Hooks Class Initialized
DEBUG - 2023-09-24 11:57:39 --> UTF-8 Support Enabled
INFO - 2023-09-24 11:57:39 --> Utf8 Class Initialized
INFO - 2023-09-24 11:57:39 --> URI Class Initialized
INFO - 2023-09-24 11:57:39 --> Router Class Initialized
INFO - 2023-09-24 11:57:39 --> Output Class Initialized
INFO - 2023-09-24 11:57:39 --> Security Class Initialized
DEBUG - 2023-09-24 11:57:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-24 11:57:39 --> Input Class Initialized
INFO - 2023-09-24 11:57:39 --> Language Class Initialized
INFO - 2023-09-24 11:57:39 --> Language Class Initialized
INFO - 2023-09-24 11:57:39 --> Config Class Initialized
INFO - 2023-09-24 11:57:39 --> Loader Class Initialized
INFO - 2023-09-24 11:57:39 --> Helper loaded: url_helper
INFO - 2023-09-24 11:57:39 --> Helper loaded: file_helper
INFO - 2023-09-24 11:57:39 --> Helper loaded: form_helper
INFO - 2023-09-24 11:57:39 --> Helper loaded: my_helper
INFO - 2023-09-24 11:57:39 --> Database Driver Class Initialized
INFO - 2023-09-24 11:57:39 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-24 11:57:39 --> Controller Class Initialized
INFO - 2023-09-24 11:57:39 --> Final output sent to browser
DEBUG - 2023-09-24 11:57:39 --> Total execution time: 0.0335
INFO - 2023-09-24 11:57:40 --> Config Class Initialized
INFO - 2023-09-24 11:57:40 --> Hooks Class Initialized
DEBUG - 2023-09-24 11:57:40 --> UTF-8 Support Enabled
INFO - 2023-09-24 11:57:40 --> Utf8 Class Initialized
INFO - 2023-09-24 11:57:40 --> URI Class Initialized
INFO - 2023-09-24 11:57:40 --> Router Class Initialized
INFO - 2023-09-24 11:57:40 --> Output Class Initialized
INFO - 2023-09-24 11:57:40 --> Security Class Initialized
DEBUG - 2023-09-24 11:57:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-24 11:57:40 --> Input Class Initialized
INFO - 2023-09-24 11:57:40 --> Language Class Initialized
INFO - 2023-09-24 11:57:40 --> Language Class Initialized
INFO - 2023-09-24 11:57:40 --> Config Class Initialized
INFO - 2023-09-24 11:57:40 --> Loader Class Initialized
INFO - 2023-09-24 11:57:40 --> Helper loaded: url_helper
INFO - 2023-09-24 11:57:40 --> Helper loaded: file_helper
INFO - 2023-09-24 11:57:40 --> Helper loaded: form_helper
INFO - 2023-09-24 11:57:40 --> Helper loaded: my_helper
INFO - 2023-09-24 11:57:40 --> Database Driver Class Initialized
INFO - 2023-09-24 11:57:40 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-24 11:57:40 --> Controller Class Initialized
INFO - 2023-09-24 11:57:41 --> Config Class Initialized
INFO - 2023-09-24 11:57:41 --> Hooks Class Initialized
DEBUG - 2023-09-24 11:57:41 --> UTF-8 Support Enabled
INFO - 2023-09-24 11:57:41 --> Utf8 Class Initialized
INFO - 2023-09-24 11:57:41 --> URI Class Initialized
INFO - 2023-09-24 11:57:41 --> Router Class Initialized
INFO - 2023-09-24 11:57:41 --> Output Class Initialized
INFO - 2023-09-24 11:57:41 --> Security Class Initialized
DEBUG - 2023-09-24 11:57:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-24 11:57:41 --> Input Class Initialized
INFO - 2023-09-24 11:57:41 --> Language Class Initialized
INFO - 2023-09-24 11:57:41 --> Language Class Initialized
INFO - 2023-09-24 11:57:41 --> Config Class Initialized
INFO - 2023-09-24 11:57:41 --> Loader Class Initialized
INFO - 2023-09-24 11:57:41 --> Helper loaded: url_helper
INFO - 2023-09-24 11:57:41 --> Helper loaded: file_helper
INFO - 2023-09-24 11:57:41 --> Helper loaded: form_helper
INFO - 2023-09-24 11:57:41 --> Helper loaded: my_helper
INFO - 2023-09-24 11:57:41 --> Database Driver Class Initialized
INFO - 2023-09-24 11:57:41 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-24 11:57:41 --> Controller Class Initialized
INFO - 2023-09-24 11:57:41 --> Final output sent to browser
DEBUG - 2023-09-24 11:57:41 --> Total execution time: 0.0325
INFO - 2023-09-24 11:57:53 --> Config Class Initialized
INFO - 2023-09-24 11:57:53 --> Hooks Class Initialized
DEBUG - 2023-09-24 11:57:53 --> UTF-8 Support Enabled
INFO - 2023-09-24 11:57:53 --> Utf8 Class Initialized
INFO - 2023-09-24 11:57:53 --> URI Class Initialized
INFO - 2023-09-24 11:57:53 --> Router Class Initialized
INFO - 2023-09-24 11:57:53 --> Output Class Initialized
INFO - 2023-09-24 11:57:53 --> Security Class Initialized
DEBUG - 2023-09-24 11:57:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-24 11:57:53 --> Input Class Initialized
INFO - 2023-09-24 11:57:53 --> Language Class Initialized
INFO - 2023-09-24 11:57:53 --> Language Class Initialized
INFO - 2023-09-24 11:57:53 --> Config Class Initialized
INFO - 2023-09-24 11:57:53 --> Loader Class Initialized
INFO - 2023-09-24 11:57:53 --> Helper loaded: url_helper
INFO - 2023-09-24 11:57:53 --> Helper loaded: file_helper
INFO - 2023-09-24 11:57:53 --> Helper loaded: form_helper
INFO - 2023-09-24 11:57:53 --> Helper loaded: my_helper
INFO - 2023-09-24 11:57:53 --> Database Driver Class Initialized
INFO - 2023-09-24 11:57:53 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-24 11:57:53 --> Controller Class Initialized
INFO - 2023-09-24 11:57:53 --> Final output sent to browser
DEBUG - 2023-09-24 11:57:53 --> Total execution time: 0.0351
INFO - 2023-09-24 11:57:53 --> Config Class Initialized
INFO - 2023-09-24 11:57:53 --> Hooks Class Initialized
DEBUG - 2023-09-24 11:57:53 --> UTF-8 Support Enabled
INFO - 2023-09-24 11:57:53 --> Utf8 Class Initialized
INFO - 2023-09-24 11:57:53 --> URI Class Initialized
INFO - 2023-09-24 11:57:53 --> Router Class Initialized
INFO - 2023-09-24 11:57:53 --> Output Class Initialized
INFO - 2023-09-24 11:57:53 --> Security Class Initialized
DEBUG - 2023-09-24 11:57:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-24 11:57:53 --> Input Class Initialized
INFO - 2023-09-24 11:57:53 --> Language Class Initialized
INFO - 2023-09-24 11:57:53 --> Language Class Initialized
INFO - 2023-09-24 11:57:53 --> Config Class Initialized
INFO - 2023-09-24 11:57:53 --> Loader Class Initialized
INFO - 2023-09-24 11:57:53 --> Helper loaded: url_helper
INFO - 2023-09-24 11:57:53 --> Helper loaded: file_helper
INFO - 2023-09-24 11:57:53 --> Helper loaded: form_helper
INFO - 2023-09-24 11:57:53 --> Helper loaded: my_helper
INFO - 2023-09-24 11:57:53 --> Database Driver Class Initialized
INFO - 2023-09-24 11:57:53 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-24 11:57:53 --> Controller Class Initialized
INFO - 2023-09-24 11:57:54 --> Config Class Initialized
INFO - 2023-09-24 11:57:54 --> Hooks Class Initialized
DEBUG - 2023-09-24 11:57:54 --> UTF-8 Support Enabled
INFO - 2023-09-24 11:57:54 --> Utf8 Class Initialized
INFO - 2023-09-24 11:57:54 --> URI Class Initialized
INFO - 2023-09-24 11:57:54 --> Router Class Initialized
INFO - 2023-09-24 11:57:54 --> Output Class Initialized
INFO - 2023-09-24 11:57:54 --> Security Class Initialized
DEBUG - 2023-09-24 11:57:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-24 11:57:54 --> Input Class Initialized
INFO - 2023-09-24 11:57:54 --> Language Class Initialized
INFO - 2023-09-24 11:57:54 --> Language Class Initialized
INFO - 2023-09-24 11:57:54 --> Config Class Initialized
INFO - 2023-09-24 11:57:54 --> Loader Class Initialized
INFO - 2023-09-24 11:57:54 --> Helper loaded: url_helper
INFO - 2023-09-24 11:57:54 --> Helper loaded: file_helper
INFO - 2023-09-24 11:57:54 --> Helper loaded: form_helper
INFO - 2023-09-24 11:57:54 --> Helper loaded: my_helper
INFO - 2023-09-24 11:57:54 --> Database Driver Class Initialized
INFO - 2023-09-24 11:57:54 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-24 11:57:54 --> Controller Class Initialized
INFO - 2023-09-24 11:57:54 --> Final output sent to browser
DEBUG - 2023-09-24 11:57:54 --> Total execution time: 0.0301
INFO - 2023-09-24 11:58:02 --> Config Class Initialized
INFO - 2023-09-24 11:58:02 --> Hooks Class Initialized
DEBUG - 2023-09-24 11:58:02 --> UTF-8 Support Enabled
INFO - 2023-09-24 11:58:02 --> Utf8 Class Initialized
INFO - 2023-09-24 11:58:02 --> URI Class Initialized
INFO - 2023-09-24 11:58:02 --> Router Class Initialized
INFO - 2023-09-24 11:58:02 --> Output Class Initialized
INFO - 2023-09-24 11:58:02 --> Security Class Initialized
DEBUG - 2023-09-24 11:58:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-24 11:58:02 --> Input Class Initialized
INFO - 2023-09-24 11:58:02 --> Language Class Initialized
INFO - 2023-09-24 11:58:02 --> Language Class Initialized
INFO - 2023-09-24 11:58:02 --> Config Class Initialized
INFO - 2023-09-24 11:58:02 --> Loader Class Initialized
INFO - 2023-09-24 11:58:02 --> Helper loaded: url_helper
INFO - 2023-09-24 11:58:02 --> Helper loaded: file_helper
INFO - 2023-09-24 11:58:02 --> Helper loaded: form_helper
INFO - 2023-09-24 11:58:02 --> Helper loaded: my_helper
INFO - 2023-09-24 11:58:02 --> Database Driver Class Initialized
INFO - 2023-09-24 11:58:02 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-24 11:58:02 --> Controller Class Initialized
INFO - 2023-09-24 11:58:02 --> Final output sent to browser
DEBUG - 2023-09-24 11:58:02 --> Total execution time: 0.0364
INFO - 2023-09-24 11:58:02 --> Config Class Initialized
INFO - 2023-09-24 11:58:02 --> Hooks Class Initialized
DEBUG - 2023-09-24 11:58:02 --> UTF-8 Support Enabled
INFO - 2023-09-24 11:58:02 --> Utf8 Class Initialized
INFO - 2023-09-24 11:58:02 --> URI Class Initialized
INFO - 2023-09-24 11:58:02 --> Router Class Initialized
INFO - 2023-09-24 11:58:02 --> Output Class Initialized
INFO - 2023-09-24 11:58:02 --> Security Class Initialized
DEBUG - 2023-09-24 11:58:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-24 11:58:02 --> Input Class Initialized
INFO - 2023-09-24 11:58:02 --> Language Class Initialized
INFO - 2023-09-24 11:58:02 --> Language Class Initialized
INFO - 2023-09-24 11:58:02 --> Config Class Initialized
INFO - 2023-09-24 11:58:02 --> Loader Class Initialized
INFO - 2023-09-24 11:58:02 --> Helper loaded: url_helper
INFO - 2023-09-24 11:58:02 --> Helper loaded: file_helper
INFO - 2023-09-24 11:58:02 --> Helper loaded: form_helper
INFO - 2023-09-24 11:58:02 --> Helper loaded: my_helper
INFO - 2023-09-24 11:58:02 --> Database Driver Class Initialized
INFO - 2023-09-24 11:58:02 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-24 11:58:02 --> Controller Class Initialized
INFO - 2023-09-24 11:58:03 --> Config Class Initialized
INFO - 2023-09-24 11:58:03 --> Hooks Class Initialized
DEBUG - 2023-09-24 11:58:03 --> UTF-8 Support Enabled
INFO - 2023-09-24 11:58:03 --> Utf8 Class Initialized
INFO - 2023-09-24 11:58:03 --> URI Class Initialized
INFO - 2023-09-24 11:58:03 --> Router Class Initialized
INFO - 2023-09-24 11:58:03 --> Output Class Initialized
INFO - 2023-09-24 11:58:03 --> Security Class Initialized
DEBUG - 2023-09-24 11:58:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-24 11:58:03 --> Input Class Initialized
INFO - 2023-09-24 11:58:03 --> Language Class Initialized
INFO - 2023-09-24 11:58:03 --> Language Class Initialized
INFO - 2023-09-24 11:58:03 --> Config Class Initialized
INFO - 2023-09-24 11:58:03 --> Loader Class Initialized
INFO - 2023-09-24 11:58:03 --> Helper loaded: url_helper
INFO - 2023-09-24 11:58:03 --> Helper loaded: file_helper
INFO - 2023-09-24 11:58:03 --> Helper loaded: form_helper
INFO - 2023-09-24 11:58:03 --> Helper loaded: my_helper
INFO - 2023-09-24 11:58:03 --> Database Driver Class Initialized
INFO - 2023-09-24 11:58:03 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-24 11:58:03 --> Controller Class Initialized
INFO - 2023-09-24 11:58:03 --> Final output sent to browser
DEBUG - 2023-09-24 11:58:03 --> Total execution time: 0.0332
INFO - 2023-09-24 11:58:12 --> Config Class Initialized
INFO - 2023-09-24 11:58:12 --> Hooks Class Initialized
DEBUG - 2023-09-24 11:58:12 --> UTF-8 Support Enabled
INFO - 2023-09-24 11:58:12 --> Utf8 Class Initialized
INFO - 2023-09-24 11:58:12 --> URI Class Initialized
INFO - 2023-09-24 11:58:12 --> Router Class Initialized
INFO - 2023-09-24 11:58:12 --> Output Class Initialized
INFO - 2023-09-24 11:58:12 --> Security Class Initialized
DEBUG - 2023-09-24 11:58:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-24 11:58:12 --> Input Class Initialized
INFO - 2023-09-24 11:58:12 --> Language Class Initialized
INFO - 2023-09-24 11:58:12 --> Language Class Initialized
INFO - 2023-09-24 11:58:12 --> Config Class Initialized
INFO - 2023-09-24 11:58:12 --> Loader Class Initialized
INFO - 2023-09-24 11:58:12 --> Helper loaded: url_helper
INFO - 2023-09-24 11:58:12 --> Helper loaded: file_helper
INFO - 2023-09-24 11:58:12 --> Helper loaded: form_helper
INFO - 2023-09-24 11:58:12 --> Helper loaded: my_helper
INFO - 2023-09-24 11:58:12 --> Database Driver Class Initialized
INFO - 2023-09-24 11:58:12 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-24 11:58:12 --> Controller Class Initialized
INFO - 2023-09-24 11:58:12 --> Final output sent to browser
DEBUG - 2023-09-24 11:58:12 --> Total execution time: 0.0302
INFO - 2023-09-24 11:58:12 --> Config Class Initialized
INFO - 2023-09-24 11:58:12 --> Hooks Class Initialized
DEBUG - 2023-09-24 11:58:12 --> UTF-8 Support Enabled
INFO - 2023-09-24 11:58:12 --> Utf8 Class Initialized
INFO - 2023-09-24 11:58:12 --> URI Class Initialized
INFO - 2023-09-24 11:58:12 --> Router Class Initialized
INFO - 2023-09-24 11:58:12 --> Output Class Initialized
INFO - 2023-09-24 11:58:12 --> Security Class Initialized
DEBUG - 2023-09-24 11:58:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-24 11:58:12 --> Input Class Initialized
INFO - 2023-09-24 11:58:12 --> Language Class Initialized
INFO - 2023-09-24 11:58:12 --> Language Class Initialized
INFO - 2023-09-24 11:58:12 --> Config Class Initialized
INFO - 2023-09-24 11:58:12 --> Loader Class Initialized
INFO - 2023-09-24 11:58:12 --> Helper loaded: url_helper
INFO - 2023-09-24 11:58:12 --> Helper loaded: file_helper
INFO - 2023-09-24 11:58:12 --> Helper loaded: form_helper
INFO - 2023-09-24 11:58:12 --> Helper loaded: my_helper
INFO - 2023-09-24 11:58:12 --> Database Driver Class Initialized
INFO - 2023-09-24 11:58:12 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-24 11:58:12 --> Controller Class Initialized
INFO - 2023-09-24 11:58:12 --> Config Class Initialized
INFO - 2023-09-24 11:58:12 --> Hooks Class Initialized
DEBUG - 2023-09-24 11:58:12 --> UTF-8 Support Enabled
INFO - 2023-09-24 11:58:12 --> Utf8 Class Initialized
INFO - 2023-09-24 11:58:12 --> URI Class Initialized
INFO - 2023-09-24 11:58:12 --> Router Class Initialized
INFO - 2023-09-24 11:58:12 --> Output Class Initialized
INFO - 2023-09-24 11:58:12 --> Security Class Initialized
DEBUG - 2023-09-24 11:58:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-24 11:58:12 --> Input Class Initialized
INFO - 2023-09-24 11:58:12 --> Language Class Initialized
INFO - 2023-09-24 11:58:12 --> Language Class Initialized
INFO - 2023-09-24 11:58:12 --> Config Class Initialized
INFO - 2023-09-24 11:58:12 --> Loader Class Initialized
INFO - 2023-09-24 11:58:12 --> Helper loaded: url_helper
INFO - 2023-09-24 11:58:12 --> Helper loaded: file_helper
INFO - 2023-09-24 11:58:12 --> Helper loaded: form_helper
INFO - 2023-09-24 11:58:12 --> Helper loaded: my_helper
INFO - 2023-09-24 11:58:12 --> Database Driver Class Initialized
INFO - 2023-09-24 11:58:12 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-24 11:58:12 --> Controller Class Initialized
INFO - 2023-09-24 11:58:12 --> Final output sent to browser
DEBUG - 2023-09-24 11:58:12 --> Total execution time: 0.0329
INFO - 2023-09-24 11:58:21 --> Config Class Initialized
INFO - 2023-09-24 11:58:21 --> Hooks Class Initialized
DEBUG - 2023-09-24 11:58:21 --> UTF-8 Support Enabled
INFO - 2023-09-24 11:58:21 --> Utf8 Class Initialized
INFO - 2023-09-24 11:58:21 --> URI Class Initialized
INFO - 2023-09-24 11:58:21 --> Router Class Initialized
INFO - 2023-09-24 11:58:21 --> Output Class Initialized
INFO - 2023-09-24 11:58:21 --> Security Class Initialized
DEBUG - 2023-09-24 11:58:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-24 11:58:21 --> Input Class Initialized
INFO - 2023-09-24 11:58:21 --> Language Class Initialized
INFO - 2023-09-24 11:58:21 --> Language Class Initialized
INFO - 2023-09-24 11:58:21 --> Config Class Initialized
INFO - 2023-09-24 11:58:21 --> Loader Class Initialized
INFO - 2023-09-24 11:58:21 --> Helper loaded: url_helper
INFO - 2023-09-24 11:58:21 --> Helper loaded: file_helper
INFO - 2023-09-24 11:58:21 --> Helper loaded: form_helper
INFO - 2023-09-24 11:58:21 --> Helper loaded: my_helper
INFO - 2023-09-24 11:58:21 --> Database Driver Class Initialized
INFO - 2023-09-24 11:58:21 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-24 11:58:21 --> Controller Class Initialized
INFO - 2023-09-24 11:58:21 --> Final output sent to browser
DEBUG - 2023-09-24 11:58:21 --> Total execution time: 0.0316
INFO - 2023-09-24 11:58:21 --> Config Class Initialized
INFO - 2023-09-24 11:58:21 --> Hooks Class Initialized
DEBUG - 2023-09-24 11:58:21 --> UTF-8 Support Enabled
INFO - 2023-09-24 11:58:21 --> Utf8 Class Initialized
INFO - 2023-09-24 11:58:21 --> URI Class Initialized
INFO - 2023-09-24 11:58:21 --> Router Class Initialized
INFO - 2023-09-24 11:58:21 --> Output Class Initialized
INFO - 2023-09-24 11:58:21 --> Security Class Initialized
DEBUG - 2023-09-24 11:58:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-24 11:58:21 --> Input Class Initialized
INFO - 2023-09-24 11:58:21 --> Language Class Initialized
INFO - 2023-09-24 11:58:21 --> Language Class Initialized
INFO - 2023-09-24 11:58:21 --> Config Class Initialized
INFO - 2023-09-24 11:58:21 --> Loader Class Initialized
INFO - 2023-09-24 11:58:21 --> Helper loaded: url_helper
INFO - 2023-09-24 11:58:21 --> Helper loaded: file_helper
INFO - 2023-09-24 11:58:21 --> Helper loaded: form_helper
INFO - 2023-09-24 11:58:21 --> Helper loaded: my_helper
INFO - 2023-09-24 11:58:21 --> Database Driver Class Initialized
INFO - 2023-09-24 11:58:21 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-24 11:58:21 --> Controller Class Initialized
INFO - 2023-09-24 11:58:22 --> Config Class Initialized
INFO - 2023-09-24 11:58:22 --> Hooks Class Initialized
DEBUG - 2023-09-24 11:58:22 --> UTF-8 Support Enabled
INFO - 2023-09-24 11:58:22 --> Utf8 Class Initialized
INFO - 2023-09-24 11:58:22 --> URI Class Initialized
INFO - 2023-09-24 11:58:22 --> Router Class Initialized
INFO - 2023-09-24 11:58:22 --> Output Class Initialized
INFO - 2023-09-24 11:58:22 --> Security Class Initialized
DEBUG - 2023-09-24 11:58:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-24 11:58:22 --> Input Class Initialized
INFO - 2023-09-24 11:58:22 --> Language Class Initialized
INFO - 2023-09-24 11:58:22 --> Language Class Initialized
INFO - 2023-09-24 11:58:22 --> Config Class Initialized
INFO - 2023-09-24 11:58:22 --> Loader Class Initialized
INFO - 2023-09-24 11:58:22 --> Helper loaded: url_helper
INFO - 2023-09-24 11:58:22 --> Helper loaded: file_helper
INFO - 2023-09-24 11:58:22 --> Helper loaded: form_helper
INFO - 2023-09-24 11:58:22 --> Helper loaded: my_helper
INFO - 2023-09-24 11:58:22 --> Database Driver Class Initialized
INFO - 2023-09-24 11:58:22 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-24 11:58:22 --> Controller Class Initialized
INFO - 2023-09-24 11:58:22 --> Final output sent to browser
DEBUG - 2023-09-24 11:58:22 --> Total execution time: 0.0358
INFO - 2023-09-24 11:58:37 --> Config Class Initialized
INFO - 2023-09-24 11:58:37 --> Hooks Class Initialized
DEBUG - 2023-09-24 11:58:37 --> UTF-8 Support Enabled
INFO - 2023-09-24 11:58:37 --> Utf8 Class Initialized
INFO - 2023-09-24 11:58:37 --> URI Class Initialized
INFO - 2023-09-24 11:58:37 --> Router Class Initialized
INFO - 2023-09-24 11:58:37 --> Output Class Initialized
INFO - 2023-09-24 11:58:37 --> Security Class Initialized
DEBUG - 2023-09-24 11:58:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-24 11:58:37 --> Input Class Initialized
INFO - 2023-09-24 11:58:37 --> Language Class Initialized
INFO - 2023-09-24 11:58:37 --> Language Class Initialized
INFO - 2023-09-24 11:58:37 --> Config Class Initialized
INFO - 2023-09-24 11:58:37 --> Loader Class Initialized
INFO - 2023-09-24 11:58:37 --> Helper loaded: url_helper
INFO - 2023-09-24 11:58:37 --> Helper loaded: file_helper
INFO - 2023-09-24 11:58:37 --> Helper loaded: form_helper
INFO - 2023-09-24 11:58:37 --> Helper loaded: my_helper
INFO - 2023-09-24 11:58:37 --> Database Driver Class Initialized
INFO - 2023-09-24 11:58:37 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-24 11:58:37 --> Controller Class Initialized
INFO - 2023-09-24 11:58:37 --> Final output sent to browser
DEBUG - 2023-09-24 11:58:37 --> Total execution time: 0.0332
INFO - 2023-09-24 11:58:37 --> Config Class Initialized
INFO - 2023-09-24 11:58:37 --> Hooks Class Initialized
DEBUG - 2023-09-24 11:58:37 --> UTF-8 Support Enabled
INFO - 2023-09-24 11:58:37 --> Utf8 Class Initialized
INFO - 2023-09-24 11:58:37 --> URI Class Initialized
INFO - 2023-09-24 11:58:37 --> Router Class Initialized
INFO - 2023-09-24 11:58:37 --> Output Class Initialized
INFO - 2023-09-24 11:58:37 --> Security Class Initialized
DEBUG - 2023-09-24 11:58:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-24 11:58:37 --> Input Class Initialized
INFO - 2023-09-24 11:58:37 --> Language Class Initialized
INFO - 2023-09-24 11:58:37 --> Language Class Initialized
INFO - 2023-09-24 11:58:37 --> Config Class Initialized
INFO - 2023-09-24 11:58:37 --> Loader Class Initialized
INFO - 2023-09-24 11:58:37 --> Helper loaded: url_helper
INFO - 2023-09-24 11:58:37 --> Helper loaded: file_helper
INFO - 2023-09-24 11:58:37 --> Helper loaded: form_helper
INFO - 2023-09-24 11:58:37 --> Helper loaded: my_helper
INFO - 2023-09-24 11:58:37 --> Database Driver Class Initialized
INFO - 2023-09-24 11:58:37 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-24 11:58:37 --> Controller Class Initialized
INFO - 2023-09-24 11:58:38 --> Config Class Initialized
INFO - 2023-09-24 11:58:38 --> Hooks Class Initialized
DEBUG - 2023-09-24 11:58:38 --> UTF-8 Support Enabled
INFO - 2023-09-24 11:58:38 --> Utf8 Class Initialized
INFO - 2023-09-24 11:58:38 --> URI Class Initialized
INFO - 2023-09-24 11:58:38 --> Router Class Initialized
INFO - 2023-09-24 11:58:38 --> Output Class Initialized
INFO - 2023-09-24 11:58:38 --> Security Class Initialized
DEBUG - 2023-09-24 11:58:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-24 11:58:38 --> Input Class Initialized
INFO - 2023-09-24 11:58:38 --> Language Class Initialized
INFO - 2023-09-24 11:58:38 --> Language Class Initialized
INFO - 2023-09-24 11:58:38 --> Config Class Initialized
INFO - 2023-09-24 11:58:38 --> Loader Class Initialized
INFO - 2023-09-24 11:58:38 --> Helper loaded: url_helper
INFO - 2023-09-24 11:58:38 --> Helper loaded: file_helper
INFO - 2023-09-24 11:58:38 --> Helper loaded: form_helper
INFO - 2023-09-24 11:58:38 --> Helper loaded: my_helper
INFO - 2023-09-24 11:58:38 --> Database Driver Class Initialized
INFO - 2023-09-24 11:58:38 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-24 11:58:38 --> Controller Class Initialized
INFO - 2023-09-24 11:58:38 --> Final output sent to browser
DEBUG - 2023-09-24 11:58:38 --> Total execution time: 0.0438
INFO - 2023-09-24 11:58:47 --> Config Class Initialized
INFO - 2023-09-24 11:58:47 --> Hooks Class Initialized
DEBUG - 2023-09-24 11:58:47 --> UTF-8 Support Enabled
INFO - 2023-09-24 11:58:47 --> Utf8 Class Initialized
INFO - 2023-09-24 11:58:47 --> URI Class Initialized
INFO - 2023-09-24 11:58:47 --> Router Class Initialized
INFO - 2023-09-24 11:58:47 --> Output Class Initialized
INFO - 2023-09-24 11:58:47 --> Security Class Initialized
DEBUG - 2023-09-24 11:58:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-24 11:58:47 --> Input Class Initialized
INFO - 2023-09-24 11:58:47 --> Language Class Initialized
INFO - 2023-09-24 11:58:47 --> Language Class Initialized
INFO - 2023-09-24 11:58:47 --> Config Class Initialized
INFO - 2023-09-24 11:58:47 --> Loader Class Initialized
INFO - 2023-09-24 11:58:47 --> Helper loaded: url_helper
INFO - 2023-09-24 11:58:47 --> Helper loaded: file_helper
INFO - 2023-09-24 11:58:47 --> Helper loaded: form_helper
INFO - 2023-09-24 11:58:47 --> Helper loaded: my_helper
INFO - 2023-09-24 11:58:47 --> Database Driver Class Initialized
INFO - 2023-09-24 11:58:47 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-24 11:58:47 --> Controller Class Initialized
INFO - 2023-09-24 11:58:47 --> Final output sent to browser
DEBUG - 2023-09-24 11:58:47 --> Total execution time: 0.0330
INFO - 2023-09-24 11:58:48 --> Config Class Initialized
INFO - 2023-09-24 11:58:48 --> Hooks Class Initialized
DEBUG - 2023-09-24 11:58:48 --> UTF-8 Support Enabled
INFO - 2023-09-24 11:58:48 --> Utf8 Class Initialized
INFO - 2023-09-24 11:58:48 --> URI Class Initialized
INFO - 2023-09-24 11:58:48 --> Router Class Initialized
INFO - 2023-09-24 11:58:48 --> Output Class Initialized
INFO - 2023-09-24 11:58:48 --> Security Class Initialized
DEBUG - 2023-09-24 11:58:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-24 11:58:48 --> Input Class Initialized
INFO - 2023-09-24 11:58:48 --> Language Class Initialized
INFO - 2023-09-24 11:58:48 --> Language Class Initialized
INFO - 2023-09-24 11:58:48 --> Config Class Initialized
INFO - 2023-09-24 11:58:48 --> Loader Class Initialized
INFO - 2023-09-24 11:58:48 --> Helper loaded: url_helper
INFO - 2023-09-24 11:58:48 --> Helper loaded: file_helper
INFO - 2023-09-24 11:58:48 --> Helper loaded: form_helper
INFO - 2023-09-24 11:58:48 --> Helper loaded: my_helper
INFO - 2023-09-24 11:58:48 --> Database Driver Class Initialized
INFO - 2023-09-24 11:58:48 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-24 11:58:48 --> Controller Class Initialized
INFO - 2023-09-24 11:58:49 --> Config Class Initialized
INFO - 2023-09-24 11:58:49 --> Hooks Class Initialized
DEBUG - 2023-09-24 11:58:49 --> UTF-8 Support Enabled
INFO - 2023-09-24 11:58:49 --> Utf8 Class Initialized
INFO - 2023-09-24 11:58:49 --> URI Class Initialized
INFO - 2023-09-24 11:58:49 --> Router Class Initialized
INFO - 2023-09-24 11:58:49 --> Output Class Initialized
INFO - 2023-09-24 11:58:49 --> Security Class Initialized
DEBUG - 2023-09-24 11:58:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-24 11:58:49 --> Input Class Initialized
INFO - 2023-09-24 11:58:49 --> Language Class Initialized
INFO - 2023-09-24 11:58:49 --> Language Class Initialized
INFO - 2023-09-24 11:58:49 --> Config Class Initialized
INFO - 2023-09-24 11:58:49 --> Loader Class Initialized
INFO - 2023-09-24 11:58:49 --> Helper loaded: url_helper
INFO - 2023-09-24 11:58:49 --> Helper loaded: file_helper
INFO - 2023-09-24 11:58:49 --> Helper loaded: form_helper
INFO - 2023-09-24 11:58:49 --> Helper loaded: my_helper
INFO - 2023-09-24 11:58:49 --> Database Driver Class Initialized
INFO - 2023-09-24 11:58:49 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-24 11:58:49 --> Controller Class Initialized
INFO - 2023-09-24 11:58:49 --> Final output sent to browser
DEBUG - 2023-09-24 11:58:49 --> Total execution time: 0.0655
INFO - 2023-09-24 11:59:19 --> Config Class Initialized
INFO - 2023-09-24 11:59:19 --> Hooks Class Initialized
DEBUG - 2023-09-24 11:59:19 --> UTF-8 Support Enabled
INFO - 2023-09-24 11:59:19 --> Utf8 Class Initialized
INFO - 2023-09-24 11:59:19 --> URI Class Initialized
INFO - 2023-09-24 11:59:19 --> Router Class Initialized
INFO - 2023-09-24 11:59:19 --> Output Class Initialized
INFO - 2023-09-24 11:59:19 --> Security Class Initialized
DEBUG - 2023-09-24 11:59:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-24 11:59:19 --> Input Class Initialized
INFO - 2023-09-24 11:59:19 --> Language Class Initialized
INFO - 2023-09-24 11:59:19 --> Language Class Initialized
INFO - 2023-09-24 11:59:19 --> Config Class Initialized
INFO - 2023-09-24 11:59:19 --> Loader Class Initialized
INFO - 2023-09-24 11:59:19 --> Helper loaded: url_helper
INFO - 2023-09-24 11:59:19 --> Helper loaded: file_helper
INFO - 2023-09-24 11:59:19 --> Helper loaded: form_helper
INFO - 2023-09-24 11:59:19 --> Helper loaded: my_helper
INFO - 2023-09-24 11:59:19 --> Database Driver Class Initialized
INFO - 2023-09-24 11:59:19 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-24 11:59:19 --> Controller Class Initialized
INFO - 2023-09-24 11:59:19 --> Final output sent to browser
DEBUG - 2023-09-24 11:59:19 --> Total execution time: 0.1194
INFO - 2023-09-24 11:59:19 --> Config Class Initialized
INFO - 2023-09-24 11:59:19 --> Hooks Class Initialized
DEBUG - 2023-09-24 11:59:19 --> UTF-8 Support Enabled
INFO - 2023-09-24 11:59:19 --> Utf8 Class Initialized
INFO - 2023-09-24 11:59:19 --> URI Class Initialized
INFO - 2023-09-24 11:59:19 --> Router Class Initialized
INFO - 2023-09-24 11:59:19 --> Output Class Initialized
INFO - 2023-09-24 11:59:19 --> Security Class Initialized
DEBUG - 2023-09-24 11:59:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-24 11:59:19 --> Input Class Initialized
INFO - 2023-09-24 11:59:19 --> Language Class Initialized
INFO - 2023-09-24 11:59:19 --> Language Class Initialized
INFO - 2023-09-24 11:59:19 --> Config Class Initialized
INFO - 2023-09-24 11:59:19 --> Loader Class Initialized
INFO - 2023-09-24 11:59:19 --> Helper loaded: url_helper
INFO - 2023-09-24 11:59:19 --> Helper loaded: file_helper
INFO - 2023-09-24 11:59:19 --> Helper loaded: form_helper
INFO - 2023-09-24 11:59:19 --> Helper loaded: my_helper
INFO - 2023-09-24 11:59:19 --> Database Driver Class Initialized
INFO - 2023-09-24 11:59:19 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-24 11:59:19 --> Controller Class Initialized
INFO - 2023-09-24 11:59:22 --> Config Class Initialized
INFO - 2023-09-24 11:59:22 --> Hooks Class Initialized
DEBUG - 2023-09-24 11:59:22 --> UTF-8 Support Enabled
INFO - 2023-09-24 11:59:22 --> Utf8 Class Initialized
INFO - 2023-09-24 11:59:22 --> URI Class Initialized
INFO - 2023-09-24 11:59:22 --> Router Class Initialized
INFO - 2023-09-24 11:59:22 --> Output Class Initialized
INFO - 2023-09-24 11:59:22 --> Security Class Initialized
DEBUG - 2023-09-24 11:59:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-24 11:59:22 --> Input Class Initialized
INFO - 2023-09-24 11:59:22 --> Language Class Initialized
INFO - 2023-09-24 11:59:22 --> Language Class Initialized
INFO - 2023-09-24 11:59:22 --> Config Class Initialized
INFO - 2023-09-24 11:59:22 --> Loader Class Initialized
INFO - 2023-09-24 11:59:22 --> Helper loaded: url_helper
INFO - 2023-09-24 11:59:22 --> Helper loaded: file_helper
INFO - 2023-09-24 11:59:22 --> Helper loaded: form_helper
INFO - 2023-09-24 11:59:22 --> Helper loaded: my_helper
INFO - 2023-09-24 11:59:22 --> Database Driver Class Initialized
INFO - 2023-09-24 11:59:22 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-24 11:59:22 --> Controller Class Initialized
INFO - 2023-09-24 11:59:22 --> Final output sent to browser
DEBUG - 2023-09-24 11:59:22 --> Total execution time: 0.0546
INFO - 2023-09-24 11:59:32 --> Config Class Initialized
INFO - 2023-09-24 11:59:32 --> Hooks Class Initialized
DEBUG - 2023-09-24 11:59:32 --> UTF-8 Support Enabled
INFO - 2023-09-24 11:59:32 --> Utf8 Class Initialized
INFO - 2023-09-24 11:59:32 --> URI Class Initialized
INFO - 2023-09-24 11:59:32 --> Router Class Initialized
INFO - 2023-09-24 11:59:32 --> Output Class Initialized
INFO - 2023-09-24 11:59:32 --> Security Class Initialized
DEBUG - 2023-09-24 11:59:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-24 11:59:32 --> Input Class Initialized
INFO - 2023-09-24 11:59:32 --> Language Class Initialized
INFO - 2023-09-24 11:59:32 --> Language Class Initialized
INFO - 2023-09-24 11:59:32 --> Config Class Initialized
INFO - 2023-09-24 11:59:32 --> Loader Class Initialized
INFO - 2023-09-24 11:59:32 --> Helper loaded: url_helper
INFO - 2023-09-24 11:59:32 --> Helper loaded: file_helper
INFO - 2023-09-24 11:59:32 --> Helper loaded: form_helper
INFO - 2023-09-24 11:59:32 --> Helper loaded: my_helper
INFO - 2023-09-24 11:59:32 --> Database Driver Class Initialized
INFO - 2023-09-24 11:59:32 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-24 11:59:32 --> Controller Class Initialized
INFO - 2023-09-24 11:59:32 --> Final output sent to browser
DEBUG - 2023-09-24 11:59:32 --> Total execution time: 0.0673
INFO - 2023-09-24 11:59:32 --> Config Class Initialized
INFO - 2023-09-24 11:59:32 --> Hooks Class Initialized
DEBUG - 2023-09-24 11:59:32 --> UTF-8 Support Enabled
INFO - 2023-09-24 11:59:32 --> Utf8 Class Initialized
INFO - 2023-09-24 11:59:32 --> URI Class Initialized
INFO - 2023-09-24 11:59:32 --> Router Class Initialized
INFO - 2023-09-24 11:59:32 --> Output Class Initialized
INFO - 2023-09-24 11:59:32 --> Security Class Initialized
DEBUG - 2023-09-24 11:59:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-24 11:59:32 --> Input Class Initialized
INFO - 2023-09-24 11:59:32 --> Language Class Initialized
INFO - 2023-09-24 11:59:32 --> Language Class Initialized
INFO - 2023-09-24 11:59:32 --> Config Class Initialized
INFO - 2023-09-24 11:59:32 --> Loader Class Initialized
INFO - 2023-09-24 11:59:32 --> Helper loaded: url_helper
INFO - 2023-09-24 11:59:32 --> Helper loaded: file_helper
INFO - 2023-09-24 11:59:32 --> Helper loaded: form_helper
INFO - 2023-09-24 11:59:32 --> Helper loaded: my_helper
INFO - 2023-09-24 11:59:32 --> Database Driver Class Initialized
INFO - 2023-09-24 11:59:32 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-24 11:59:32 --> Controller Class Initialized
INFO - 2023-09-24 12:02:19 --> Config Class Initialized
INFO - 2023-09-24 12:02:19 --> Hooks Class Initialized
DEBUG - 2023-09-24 12:02:19 --> UTF-8 Support Enabled
INFO - 2023-09-24 12:02:19 --> Utf8 Class Initialized
INFO - 2023-09-24 12:02:19 --> URI Class Initialized
INFO - 2023-09-24 12:02:19 --> Router Class Initialized
INFO - 2023-09-24 12:02:19 --> Output Class Initialized
INFO - 2023-09-24 12:02:19 --> Security Class Initialized
DEBUG - 2023-09-24 12:02:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-24 12:02:19 --> Input Class Initialized
INFO - 2023-09-24 12:02:19 --> Language Class Initialized
INFO - 2023-09-24 12:02:19 --> Language Class Initialized
INFO - 2023-09-24 12:02:19 --> Config Class Initialized
INFO - 2023-09-24 12:02:19 --> Loader Class Initialized
INFO - 2023-09-24 12:02:19 --> Helper loaded: url_helper
INFO - 2023-09-24 12:02:19 --> Helper loaded: file_helper
INFO - 2023-09-24 12:02:19 --> Helper loaded: form_helper
INFO - 2023-09-24 12:02:19 --> Helper loaded: my_helper
INFO - 2023-09-24 12:02:19 --> Database Driver Class Initialized
INFO - 2023-09-24 12:02:19 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-24 12:02:19 --> Controller Class Initialized
INFO - 2023-09-24 12:02:19 --> Final output sent to browser
DEBUG - 2023-09-24 12:02:19 --> Total execution time: 0.0680
INFO - 2023-09-24 12:02:31 --> Config Class Initialized
INFO - 2023-09-24 12:02:31 --> Hooks Class Initialized
DEBUG - 2023-09-24 12:02:31 --> UTF-8 Support Enabled
INFO - 2023-09-24 12:02:31 --> Utf8 Class Initialized
INFO - 2023-09-24 12:02:31 --> URI Class Initialized
INFO - 2023-09-24 12:02:31 --> Router Class Initialized
INFO - 2023-09-24 12:02:31 --> Output Class Initialized
INFO - 2023-09-24 12:02:31 --> Security Class Initialized
DEBUG - 2023-09-24 12:02:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-24 12:02:31 --> Input Class Initialized
INFO - 2023-09-24 12:02:31 --> Language Class Initialized
INFO - 2023-09-24 12:02:31 --> Language Class Initialized
INFO - 2023-09-24 12:02:31 --> Config Class Initialized
INFO - 2023-09-24 12:02:31 --> Loader Class Initialized
INFO - 2023-09-24 12:02:31 --> Helper loaded: url_helper
INFO - 2023-09-24 12:02:31 --> Helper loaded: file_helper
INFO - 2023-09-24 12:02:31 --> Helper loaded: form_helper
INFO - 2023-09-24 12:02:31 --> Helper loaded: my_helper
INFO - 2023-09-24 12:02:31 --> Database Driver Class Initialized
INFO - 2023-09-24 12:02:31 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-24 12:02:31 --> Controller Class Initialized
INFO - 2023-09-24 12:02:31 --> Final output sent to browser
DEBUG - 2023-09-24 12:02:31 --> Total execution time: 0.0915
INFO - 2023-09-24 12:02:31 --> Config Class Initialized
INFO - 2023-09-24 12:02:31 --> Hooks Class Initialized
DEBUG - 2023-09-24 12:02:31 --> UTF-8 Support Enabled
INFO - 2023-09-24 12:02:31 --> Utf8 Class Initialized
INFO - 2023-09-24 12:02:31 --> URI Class Initialized
INFO - 2023-09-24 12:02:31 --> Router Class Initialized
INFO - 2023-09-24 12:02:31 --> Output Class Initialized
INFO - 2023-09-24 12:02:31 --> Security Class Initialized
DEBUG - 2023-09-24 12:02:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-24 12:02:31 --> Input Class Initialized
INFO - 2023-09-24 12:02:31 --> Language Class Initialized
INFO - 2023-09-24 12:02:31 --> Language Class Initialized
INFO - 2023-09-24 12:02:31 --> Config Class Initialized
INFO - 2023-09-24 12:02:31 --> Loader Class Initialized
INFO - 2023-09-24 12:02:31 --> Helper loaded: url_helper
INFO - 2023-09-24 12:02:31 --> Helper loaded: file_helper
INFO - 2023-09-24 12:02:31 --> Helper loaded: form_helper
INFO - 2023-09-24 12:02:31 --> Helper loaded: my_helper
INFO - 2023-09-24 12:02:31 --> Database Driver Class Initialized
INFO - 2023-09-24 12:02:31 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-24 12:02:31 --> Controller Class Initialized
INFO - 2023-09-24 12:02:32 --> Config Class Initialized
INFO - 2023-09-24 12:02:32 --> Hooks Class Initialized
DEBUG - 2023-09-24 12:02:32 --> UTF-8 Support Enabled
INFO - 2023-09-24 12:02:32 --> Utf8 Class Initialized
INFO - 2023-09-24 12:02:32 --> URI Class Initialized
INFO - 2023-09-24 12:02:32 --> Router Class Initialized
INFO - 2023-09-24 12:02:32 --> Output Class Initialized
INFO - 2023-09-24 12:02:32 --> Security Class Initialized
DEBUG - 2023-09-24 12:02:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-24 12:02:32 --> Input Class Initialized
INFO - 2023-09-24 12:02:32 --> Language Class Initialized
INFO - 2023-09-24 12:02:32 --> Language Class Initialized
INFO - 2023-09-24 12:02:32 --> Config Class Initialized
INFO - 2023-09-24 12:02:32 --> Loader Class Initialized
INFO - 2023-09-24 12:02:32 --> Helper loaded: url_helper
INFO - 2023-09-24 12:02:32 --> Helper loaded: file_helper
INFO - 2023-09-24 12:02:32 --> Helper loaded: form_helper
INFO - 2023-09-24 12:02:32 --> Helper loaded: my_helper
INFO - 2023-09-24 12:02:32 --> Database Driver Class Initialized
INFO - 2023-09-24 12:02:32 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-24 12:02:32 --> Controller Class Initialized
INFO - 2023-09-24 12:02:32 --> Final output sent to browser
DEBUG - 2023-09-24 12:02:32 --> Total execution time: 0.0345
INFO - 2023-09-24 12:02:41 --> Config Class Initialized
INFO - 2023-09-24 12:02:41 --> Hooks Class Initialized
DEBUG - 2023-09-24 12:02:41 --> UTF-8 Support Enabled
INFO - 2023-09-24 12:02:41 --> Utf8 Class Initialized
INFO - 2023-09-24 12:02:41 --> URI Class Initialized
INFO - 2023-09-24 12:02:41 --> Router Class Initialized
INFO - 2023-09-24 12:02:41 --> Output Class Initialized
INFO - 2023-09-24 12:02:41 --> Security Class Initialized
DEBUG - 2023-09-24 12:02:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-24 12:02:41 --> Input Class Initialized
INFO - 2023-09-24 12:02:41 --> Language Class Initialized
INFO - 2023-09-24 12:02:41 --> Language Class Initialized
INFO - 2023-09-24 12:02:41 --> Config Class Initialized
INFO - 2023-09-24 12:02:41 --> Loader Class Initialized
INFO - 2023-09-24 12:02:41 --> Helper loaded: url_helper
INFO - 2023-09-24 12:02:41 --> Helper loaded: file_helper
INFO - 2023-09-24 12:02:41 --> Helper loaded: form_helper
INFO - 2023-09-24 12:02:41 --> Helper loaded: my_helper
INFO - 2023-09-24 12:02:41 --> Database Driver Class Initialized
INFO - 2023-09-24 12:02:41 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-24 12:02:41 --> Controller Class Initialized
INFO - 2023-09-24 12:02:41 --> Final output sent to browser
DEBUG - 2023-09-24 12:02:41 --> Total execution time: 0.0361
INFO - 2023-09-24 12:02:41 --> Config Class Initialized
INFO - 2023-09-24 12:02:41 --> Hooks Class Initialized
DEBUG - 2023-09-24 12:02:41 --> UTF-8 Support Enabled
INFO - 2023-09-24 12:02:41 --> Utf8 Class Initialized
INFO - 2023-09-24 12:02:41 --> URI Class Initialized
INFO - 2023-09-24 12:02:41 --> Router Class Initialized
INFO - 2023-09-24 12:02:41 --> Output Class Initialized
INFO - 2023-09-24 12:02:41 --> Security Class Initialized
DEBUG - 2023-09-24 12:02:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-24 12:02:41 --> Input Class Initialized
INFO - 2023-09-24 12:02:41 --> Language Class Initialized
INFO - 2023-09-24 12:02:41 --> Language Class Initialized
INFO - 2023-09-24 12:02:41 --> Config Class Initialized
INFO - 2023-09-24 12:02:41 --> Loader Class Initialized
INFO - 2023-09-24 12:02:41 --> Helper loaded: url_helper
INFO - 2023-09-24 12:02:41 --> Helper loaded: file_helper
INFO - 2023-09-24 12:02:41 --> Helper loaded: form_helper
INFO - 2023-09-24 12:02:41 --> Helper loaded: my_helper
INFO - 2023-09-24 12:02:41 --> Database Driver Class Initialized
INFO - 2023-09-24 12:02:41 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-24 12:02:41 --> Controller Class Initialized
INFO - 2023-09-24 12:02:56 --> Config Class Initialized
INFO - 2023-09-24 12:02:56 --> Hooks Class Initialized
DEBUG - 2023-09-24 12:02:56 --> UTF-8 Support Enabled
INFO - 2023-09-24 12:02:56 --> Utf8 Class Initialized
INFO - 2023-09-24 12:02:56 --> URI Class Initialized
INFO - 2023-09-24 12:02:56 --> Router Class Initialized
INFO - 2023-09-24 12:02:56 --> Output Class Initialized
INFO - 2023-09-24 12:02:56 --> Security Class Initialized
DEBUG - 2023-09-24 12:02:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-24 12:02:56 --> Input Class Initialized
INFO - 2023-09-24 12:02:56 --> Language Class Initialized
INFO - 2023-09-24 12:02:56 --> Language Class Initialized
INFO - 2023-09-24 12:02:56 --> Config Class Initialized
INFO - 2023-09-24 12:02:56 --> Loader Class Initialized
INFO - 2023-09-24 12:02:56 --> Helper loaded: url_helper
INFO - 2023-09-24 12:02:56 --> Helper loaded: file_helper
INFO - 2023-09-24 12:02:56 --> Helper loaded: form_helper
INFO - 2023-09-24 12:02:56 --> Helper loaded: my_helper
INFO - 2023-09-24 12:02:56 --> Database Driver Class Initialized
INFO - 2023-09-24 12:02:56 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-24 12:02:56 --> Controller Class Initialized
INFO - 2023-09-24 12:02:56 --> Final output sent to browser
DEBUG - 2023-09-24 12:02:56 --> Total execution time: 0.0331
INFO - 2023-09-24 12:03:05 --> Config Class Initialized
INFO - 2023-09-24 12:03:05 --> Hooks Class Initialized
DEBUG - 2023-09-24 12:03:05 --> UTF-8 Support Enabled
INFO - 2023-09-24 12:03:05 --> Utf8 Class Initialized
INFO - 2023-09-24 12:03:05 --> URI Class Initialized
INFO - 2023-09-24 12:03:05 --> Router Class Initialized
INFO - 2023-09-24 12:03:05 --> Output Class Initialized
INFO - 2023-09-24 12:03:05 --> Security Class Initialized
DEBUG - 2023-09-24 12:03:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-24 12:03:05 --> Input Class Initialized
INFO - 2023-09-24 12:03:05 --> Language Class Initialized
INFO - 2023-09-24 12:03:05 --> Language Class Initialized
INFO - 2023-09-24 12:03:05 --> Config Class Initialized
INFO - 2023-09-24 12:03:05 --> Loader Class Initialized
INFO - 2023-09-24 12:03:05 --> Helper loaded: url_helper
INFO - 2023-09-24 12:03:05 --> Helper loaded: file_helper
INFO - 2023-09-24 12:03:05 --> Helper loaded: form_helper
INFO - 2023-09-24 12:03:05 --> Helper loaded: my_helper
INFO - 2023-09-24 12:03:05 --> Database Driver Class Initialized
INFO - 2023-09-24 12:03:05 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-24 12:03:05 --> Controller Class Initialized
INFO - 2023-09-24 12:03:05 --> Final output sent to browser
DEBUG - 2023-09-24 12:03:05 --> Total execution time: 0.0364
INFO - 2023-09-24 12:03:05 --> Config Class Initialized
INFO - 2023-09-24 12:03:05 --> Hooks Class Initialized
DEBUG - 2023-09-24 12:03:05 --> UTF-8 Support Enabled
INFO - 2023-09-24 12:03:05 --> Utf8 Class Initialized
INFO - 2023-09-24 12:03:05 --> URI Class Initialized
INFO - 2023-09-24 12:03:05 --> Router Class Initialized
INFO - 2023-09-24 12:03:05 --> Output Class Initialized
INFO - 2023-09-24 12:03:05 --> Security Class Initialized
DEBUG - 2023-09-24 12:03:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-24 12:03:05 --> Input Class Initialized
INFO - 2023-09-24 12:03:05 --> Language Class Initialized
INFO - 2023-09-24 12:03:05 --> Language Class Initialized
INFO - 2023-09-24 12:03:05 --> Config Class Initialized
INFO - 2023-09-24 12:03:05 --> Loader Class Initialized
INFO - 2023-09-24 12:03:05 --> Helper loaded: url_helper
INFO - 2023-09-24 12:03:05 --> Helper loaded: file_helper
INFO - 2023-09-24 12:03:05 --> Helper loaded: form_helper
INFO - 2023-09-24 12:03:05 --> Helper loaded: my_helper
INFO - 2023-09-24 12:03:05 --> Database Driver Class Initialized
INFO - 2023-09-24 12:03:05 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-24 12:03:05 --> Controller Class Initialized
INFO - 2023-09-24 12:03:07 --> Config Class Initialized
INFO - 2023-09-24 12:03:07 --> Hooks Class Initialized
DEBUG - 2023-09-24 12:03:07 --> UTF-8 Support Enabled
INFO - 2023-09-24 12:03:07 --> Utf8 Class Initialized
INFO - 2023-09-24 12:03:07 --> URI Class Initialized
INFO - 2023-09-24 12:03:07 --> Router Class Initialized
INFO - 2023-09-24 12:03:07 --> Output Class Initialized
INFO - 2023-09-24 12:03:07 --> Security Class Initialized
DEBUG - 2023-09-24 12:03:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-24 12:03:07 --> Input Class Initialized
INFO - 2023-09-24 12:03:07 --> Language Class Initialized
INFO - 2023-09-24 12:03:07 --> Language Class Initialized
INFO - 2023-09-24 12:03:07 --> Config Class Initialized
INFO - 2023-09-24 12:03:07 --> Loader Class Initialized
INFO - 2023-09-24 12:03:07 --> Helper loaded: url_helper
INFO - 2023-09-24 12:03:07 --> Helper loaded: file_helper
INFO - 2023-09-24 12:03:07 --> Helper loaded: form_helper
INFO - 2023-09-24 12:03:07 --> Helper loaded: my_helper
INFO - 2023-09-24 12:03:07 --> Database Driver Class Initialized
INFO - 2023-09-24 12:03:07 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-24 12:03:07 --> Controller Class Initialized
INFO - 2023-09-24 12:03:07 --> Final output sent to browser
DEBUG - 2023-09-24 12:03:07 --> Total execution time: 0.0319
INFO - 2023-09-24 12:03:16 --> Config Class Initialized
INFO - 2023-09-24 12:03:16 --> Hooks Class Initialized
DEBUG - 2023-09-24 12:03:16 --> UTF-8 Support Enabled
INFO - 2023-09-24 12:03:16 --> Utf8 Class Initialized
INFO - 2023-09-24 12:03:16 --> URI Class Initialized
INFO - 2023-09-24 12:03:16 --> Router Class Initialized
INFO - 2023-09-24 12:03:16 --> Output Class Initialized
INFO - 2023-09-24 12:03:16 --> Security Class Initialized
DEBUG - 2023-09-24 12:03:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-24 12:03:16 --> Input Class Initialized
INFO - 2023-09-24 12:03:16 --> Language Class Initialized
INFO - 2023-09-24 12:03:16 --> Language Class Initialized
INFO - 2023-09-24 12:03:16 --> Config Class Initialized
INFO - 2023-09-24 12:03:16 --> Loader Class Initialized
INFO - 2023-09-24 12:03:16 --> Helper loaded: url_helper
INFO - 2023-09-24 12:03:16 --> Helper loaded: file_helper
INFO - 2023-09-24 12:03:16 --> Helper loaded: form_helper
INFO - 2023-09-24 12:03:16 --> Helper loaded: my_helper
INFO - 2023-09-24 12:03:16 --> Database Driver Class Initialized
INFO - 2023-09-24 12:03:16 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-24 12:03:16 --> Controller Class Initialized
INFO - 2023-09-24 12:03:16 --> Final output sent to browser
DEBUG - 2023-09-24 12:03:16 --> Total execution time: 0.0366
INFO - 2023-09-24 12:03:16 --> Config Class Initialized
INFO - 2023-09-24 12:03:16 --> Hooks Class Initialized
DEBUG - 2023-09-24 12:03:16 --> UTF-8 Support Enabled
INFO - 2023-09-24 12:03:16 --> Utf8 Class Initialized
INFO - 2023-09-24 12:03:16 --> URI Class Initialized
INFO - 2023-09-24 12:03:16 --> Router Class Initialized
INFO - 2023-09-24 12:03:16 --> Output Class Initialized
INFO - 2023-09-24 12:03:16 --> Security Class Initialized
DEBUG - 2023-09-24 12:03:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-24 12:03:16 --> Input Class Initialized
INFO - 2023-09-24 12:03:16 --> Language Class Initialized
INFO - 2023-09-24 12:03:16 --> Language Class Initialized
INFO - 2023-09-24 12:03:16 --> Config Class Initialized
INFO - 2023-09-24 12:03:16 --> Loader Class Initialized
INFO - 2023-09-24 12:03:16 --> Helper loaded: url_helper
INFO - 2023-09-24 12:03:16 --> Helper loaded: file_helper
INFO - 2023-09-24 12:03:16 --> Helper loaded: form_helper
INFO - 2023-09-24 12:03:16 --> Helper loaded: my_helper
INFO - 2023-09-24 12:03:16 --> Database Driver Class Initialized
INFO - 2023-09-24 12:03:16 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-24 12:03:16 --> Controller Class Initialized
INFO - 2023-09-24 12:03:18 --> Config Class Initialized
INFO - 2023-09-24 12:03:18 --> Hooks Class Initialized
DEBUG - 2023-09-24 12:03:18 --> UTF-8 Support Enabled
INFO - 2023-09-24 12:03:18 --> Utf8 Class Initialized
INFO - 2023-09-24 12:03:18 --> URI Class Initialized
INFO - 2023-09-24 12:03:18 --> Router Class Initialized
INFO - 2023-09-24 12:03:18 --> Output Class Initialized
INFO - 2023-09-24 12:03:18 --> Security Class Initialized
DEBUG - 2023-09-24 12:03:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-24 12:03:18 --> Input Class Initialized
INFO - 2023-09-24 12:03:18 --> Language Class Initialized
INFO - 2023-09-24 12:03:18 --> Language Class Initialized
INFO - 2023-09-24 12:03:18 --> Config Class Initialized
INFO - 2023-09-24 12:03:18 --> Loader Class Initialized
INFO - 2023-09-24 12:03:18 --> Helper loaded: url_helper
INFO - 2023-09-24 12:03:18 --> Helper loaded: file_helper
INFO - 2023-09-24 12:03:18 --> Helper loaded: form_helper
INFO - 2023-09-24 12:03:18 --> Helper loaded: my_helper
INFO - 2023-09-24 12:03:18 --> Database Driver Class Initialized
INFO - 2023-09-24 12:03:18 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-24 12:03:18 --> Controller Class Initialized
INFO - 2023-09-24 12:03:18 --> Final output sent to browser
DEBUG - 2023-09-24 12:03:18 --> Total execution time: 0.1106
INFO - 2023-09-24 12:03:27 --> Config Class Initialized
INFO - 2023-09-24 12:03:27 --> Hooks Class Initialized
DEBUG - 2023-09-24 12:03:27 --> UTF-8 Support Enabled
INFO - 2023-09-24 12:03:27 --> Utf8 Class Initialized
INFO - 2023-09-24 12:03:27 --> URI Class Initialized
INFO - 2023-09-24 12:03:27 --> Router Class Initialized
INFO - 2023-09-24 12:03:27 --> Output Class Initialized
INFO - 2023-09-24 12:03:27 --> Security Class Initialized
DEBUG - 2023-09-24 12:03:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-24 12:03:27 --> Input Class Initialized
INFO - 2023-09-24 12:03:27 --> Language Class Initialized
INFO - 2023-09-24 12:03:27 --> Language Class Initialized
INFO - 2023-09-24 12:03:27 --> Config Class Initialized
INFO - 2023-09-24 12:03:27 --> Loader Class Initialized
INFO - 2023-09-24 12:03:27 --> Helper loaded: url_helper
INFO - 2023-09-24 12:03:27 --> Helper loaded: file_helper
INFO - 2023-09-24 12:03:27 --> Helper loaded: form_helper
INFO - 2023-09-24 12:03:27 --> Helper loaded: my_helper
INFO - 2023-09-24 12:03:27 --> Database Driver Class Initialized
INFO - 2023-09-24 12:03:27 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-24 12:03:27 --> Controller Class Initialized
INFO - 2023-09-24 12:03:27 --> Final output sent to browser
DEBUG - 2023-09-24 12:03:27 --> Total execution time: 0.0333
INFO - 2023-09-24 12:03:27 --> Config Class Initialized
INFO - 2023-09-24 12:03:27 --> Hooks Class Initialized
DEBUG - 2023-09-24 12:03:27 --> UTF-8 Support Enabled
INFO - 2023-09-24 12:03:27 --> Utf8 Class Initialized
INFO - 2023-09-24 12:03:27 --> URI Class Initialized
INFO - 2023-09-24 12:03:27 --> Router Class Initialized
INFO - 2023-09-24 12:03:27 --> Output Class Initialized
INFO - 2023-09-24 12:03:27 --> Security Class Initialized
DEBUG - 2023-09-24 12:03:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-24 12:03:27 --> Input Class Initialized
INFO - 2023-09-24 12:03:27 --> Language Class Initialized
INFO - 2023-09-24 12:03:27 --> Language Class Initialized
INFO - 2023-09-24 12:03:27 --> Config Class Initialized
INFO - 2023-09-24 12:03:27 --> Loader Class Initialized
INFO - 2023-09-24 12:03:27 --> Helper loaded: url_helper
INFO - 2023-09-24 12:03:27 --> Helper loaded: file_helper
INFO - 2023-09-24 12:03:27 --> Helper loaded: form_helper
INFO - 2023-09-24 12:03:27 --> Helper loaded: my_helper
INFO - 2023-09-24 12:03:27 --> Database Driver Class Initialized
INFO - 2023-09-24 12:03:27 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-24 12:03:27 --> Controller Class Initialized
INFO - 2023-09-24 12:03:29 --> Config Class Initialized
INFO - 2023-09-24 12:03:29 --> Hooks Class Initialized
DEBUG - 2023-09-24 12:03:29 --> UTF-8 Support Enabled
INFO - 2023-09-24 12:03:29 --> Utf8 Class Initialized
INFO - 2023-09-24 12:03:29 --> URI Class Initialized
INFO - 2023-09-24 12:03:29 --> Router Class Initialized
INFO - 2023-09-24 12:03:29 --> Output Class Initialized
INFO - 2023-09-24 12:03:29 --> Security Class Initialized
DEBUG - 2023-09-24 12:03:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-24 12:03:29 --> Input Class Initialized
INFO - 2023-09-24 12:03:29 --> Language Class Initialized
INFO - 2023-09-24 12:03:29 --> Language Class Initialized
INFO - 2023-09-24 12:03:29 --> Config Class Initialized
INFO - 2023-09-24 12:03:29 --> Loader Class Initialized
INFO - 2023-09-24 12:03:29 --> Helper loaded: url_helper
INFO - 2023-09-24 12:03:29 --> Helper loaded: file_helper
INFO - 2023-09-24 12:03:29 --> Helper loaded: form_helper
INFO - 2023-09-24 12:03:29 --> Helper loaded: my_helper
INFO - 2023-09-24 12:03:29 --> Database Driver Class Initialized
INFO - 2023-09-24 12:03:29 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-24 12:03:29 --> Controller Class Initialized
INFO - 2023-09-24 12:03:29 --> Final output sent to browser
DEBUG - 2023-09-24 12:03:29 --> Total execution time: 0.0684
INFO - 2023-09-24 12:03:42 --> Config Class Initialized
INFO - 2023-09-24 12:03:42 --> Hooks Class Initialized
DEBUG - 2023-09-24 12:03:42 --> UTF-8 Support Enabled
INFO - 2023-09-24 12:03:42 --> Utf8 Class Initialized
INFO - 2023-09-24 12:03:42 --> URI Class Initialized
INFO - 2023-09-24 12:03:42 --> Router Class Initialized
INFO - 2023-09-24 12:03:42 --> Output Class Initialized
INFO - 2023-09-24 12:03:42 --> Security Class Initialized
DEBUG - 2023-09-24 12:03:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-24 12:03:42 --> Input Class Initialized
INFO - 2023-09-24 12:03:42 --> Language Class Initialized
INFO - 2023-09-24 12:03:42 --> Language Class Initialized
INFO - 2023-09-24 12:03:42 --> Config Class Initialized
INFO - 2023-09-24 12:03:42 --> Loader Class Initialized
INFO - 2023-09-24 12:03:42 --> Helper loaded: url_helper
INFO - 2023-09-24 12:03:42 --> Helper loaded: file_helper
INFO - 2023-09-24 12:03:42 --> Helper loaded: form_helper
INFO - 2023-09-24 12:03:42 --> Helper loaded: my_helper
INFO - 2023-09-24 12:03:42 --> Database Driver Class Initialized
INFO - 2023-09-24 12:03:42 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-24 12:03:42 --> Controller Class Initialized
INFO - 2023-09-24 12:03:42 --> Final output sent to browser
DEBUG - 2023-09-24 12:03:42 --> Total execution time: 0.0311
INFO - 2023-09-24 12:03:42 --> Config Class Initialized
INFO - 2023-09-24 12:03:42 --> Hooks Class Initialized
DEBUG - 2023-09-24 12:03:42 --> UTF-8 Support Enabled
INFO - 2023-09-24 12:03:42 --> Utf8 Class Initialized
INFO - 2023-09-24 12:03:42 --> URI Class Initialized
INFO - 2023-09-24 12:03:42 --> Router Class Initialized
INFO - 2023-09-24 12:03:42 --> Output Class Initialized
INFO - 2023-09-24 12:03:42 --> Security Class Initialized
DEBUG - 2023-09-24 12:03:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-24 12:03:42 --> Input Class Initialized
INFO - 2023-09-24 12:03:42 --> Language Class Initialized
INFO - 2023-09-24 12:03:42 --> Language Class Initialized
INFO - 2023-09-24 12:03:42 --> Config Class Initialized
INFO - 2023-09-24 12:03:42 --> Loader Class Initialized
INFO - 2023-09-24 12:03:42 --> Helper loaded: url_helper
INFO - 2023-09-24 12:03:42 --> Helper loaded: file_helper
INFO - 2023-09-24 12:03:42 --> Helper loaded: form_helper
INFO - 2023-09-24 12:03:42 --> Helper loaded: my_helper
INFO - 2023-09-24 12:03:42 --> Database Driver Class Initialized
INFO - 2023-09-24 12:03:42 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-24 12:03:42 --> Controller Class Initialized
INFO - 2023-09-24 12:03:43 --> Config Class Initialized
INFO - 2023-09-24 12:03:43 --> Hooks Class Initialized
DEBUG - 2023-09-24 12:03:43 --> UTF-8 Support Enabled
INFO - 2023-09-24 12:03:43 --> Utf8 Class Initialized
INFO - 2023-09-24 12:03:43 --> URI Class Initialized
INFO - 2023-09-24 12:03:43 --> Router Class Initialized
INFO - 2023-09-24 12:03:43 --> Output Class Initialized
INFO - 2023-09-24 12:03:43 --> Security Class Initialized
DEBUG - 2023-09-24 12:03:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-24 12:03:43 --> Input Class Initialized
INFO - 2023-09-24 12:03:43 --> Language Class Initialized
INFO - 2023-09-24 12:03:43 --> Language Class Initialized
INFO - 2023-09-24 12:03:43 --> Config Class Initialized
INFO - 2023-09-24 12:03:43 --> Loader Class Initialized
INFO - 2023-09-24 12:03:43 --> Helper loaded: url_helper
INFO - 2023-09-24 12:03:43 --> Helper loaded: file_helper
INFO - 2023-09-24 12:03:43 --> Helper loaded: form_helper
INFO - 2023-09-24 12:03:43 --> Helper loaded: my_helper
INFO - 2023-09-24 12:03:43 --> Database Driver Class Initialized
INFO - 2023-09-24 12:03:43 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-24 12:03:43 --> Controller Class Initialized
INFO - 2023-09-24 12:03:43 --> Final output sent to browser
DEBUG - 2023-09-24 12:03:43 --> Total execution time: 0.0636
INFO - 2023-09-24 12:03:52 --> Config Class Initialized
INFO - 2023-09-24 12:03:52 --> Hooks Class Initialized
DEBUG - 2023-09-24 12:03:52 --> UTF-8 Support Enabled
INFO - 2023-09-24 12:03:52 --> Utf8 Class Initialized
INFO - 2023-09-24 12:03:52 --> URI Class Initialized
INFO - 2023-09-24 12:03:52 --> Router Class Initialized
INFO - 2023-09-24 12:03:52 --> Output Class Initialized
INFO - 2023-09-24 12:03:52 --> Security Class Initialized
DEBUG - 2023-09-24 12:03:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-24 12:03:52 --> Input Class Initialized
INFO - 2023-09-24 12:03:52 --> Language Class Initialized
INFO - 2023-09-24 12:03:52 --> Language Class Initialized
INFO - 2023-09-24 12:03:52 --> Config Class Initialized
INFO - 2023-09-24 12:03:52 --> Loader Class Initialized
INFO - 2023-09-24 12:03:52 --> Helper loaded: url_helper
INFO - 2023-09-24 12:03:52 --> Helper loaded: file_helper
INFO - 2023-09-24 12:03:52 --> Helper loaded: form_helper
INFO - 2023-09-24 12:03:52 --> Helper loaded: my_helper
INFO - 2023-09-24 12:03:52 --> Database Driver Class Initialized
INFO - 2023-09-24 12:03:52 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-24 12:03:52 --> Controller Class Initialized
INFO - 2023-09-24 12:03:52 --> Final output sent to browser
DEBUG - 2023-09-24 12:03:52 --> Total execution time: 0.0875
INFO - 2023-09-24 12:03:52 --> Config Class Initialized
INFO - 2023-09-24 12:03:52 --> Hooks Class Initialized
DEBUG - 2023-09-24 12:03:52 --> UTF-8 Support Enabled
INFO - 2023-09-24 12:03:52 --> Utf8 Class Initialized
INFO - 2023-09-24 12:03:52 --> URI Class Initialized
INFO - 2023-09-24 12:03:52 --> Router Class Initialized
INFO - 2023-09-24 12:03:52 --> Output Class Initialized
INFO - 2023-09-24 12:03:52 --> Security Class Initialized
DEBUG - 2023-09-24 12:03:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-24 12:03:52 --> Input Class Initialized
INFO - 2023-09-24 12:03:52 --> Language Class Initialized
INFO - 2023-09-24 12:03:52 --> Language Class Initialized
INFO - 2023-09-24 12:03:52 --> Config Class Initialized
INFO - 2023-09-24 12:03:52 --> Loader Class Initialized
INFO - 2023-09-24 12:03:52 --> Helper loaded: url_helper
INFO - 2023-09-24 12:03:52 --> Helper loaded: file_helper
INFO - 2023-09-24 12:03:52 --> Helper loaded: form_helper
INFO - 2023-09-24 12:03:52 --> Helper loaded: my_helper
INFO - 2023-09-24 12:03:52 --> Database Driver Class Initialized
INFO - 2023-09-24 12:03:53 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-24 12:03:53 --> Controller Class Initialized
INFO - 2023-09-24 12:03:54 --> Config Class Initialized
INFO - 2023-09-24 12:03:54 --> Hooks Class Initialized
DEBUG - 2023-09-24 12:03:54 --> UTF-8 Support Enabled
INFO - 2023-09-24 12:03:54 --> Utf8 Class Initialized
INFO - 2023-09-24 12:03:54 --> URI Class Initialized
INFO - 2023-09-24 12:03:54 --> Router Class Initialized
INFO - 2023-09-24 12:03:54 --> Output Class Initialized
INFO - 2023-09-24 12:03:54 --> Security Class Initialized
DEBUG - 2023-09-24 12:03:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-24 12:03:54 --> Input Class Initialized
INFO - 2023-09-24 12:03:54 --> Language Class Initialized
INFO - 2023-09-24 12:03:54 --> Language Class Initialized
INFO - 2023-09-24 12:03:54 --> Config Class Initialized
INFO - 2023-09-24 12:03:54 --> Loader Class Initialized
INFO - 2023-09-24 12:03:54 --> Helper loaded: url_helper
INFO - 2023-09-24 12:03:54 --> Helper loaded: file_helper
INFO - 2023-09-24 12:03:54 --> Helper loaded: form_helper
INFO - 2023-09-24 12:03:54 --> Helper loaded: my_helper
INFO - 2023-09-24 12:03:54 --> Database Driver Class Initialized
INFO - 2023-09-24 12:03:54 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-24 12:03:54 --> Controller Class Initialized
INFO - 2023-09-24 12:03:54 --> Final output sent to browser
DEBUG - 2023-09-24 12:03:54 --> Total execution time: 0.0504
INFO - 2023-09-24 12:04:02 --> Config Class Initialized
INFO - 2023-09-24 12:04:02 --> Hooks Class Initialized
DEBUG - 2023-09-24 12:04:02 --> UTF-8 Support Enabled
INFO - 2023-09-24 12:04:02 --> Utf8 Class Initialized
INFO - 2023-09-24 12:04:02 --> URI Class Initialized
INFO - 2023-09-24 12:04:02 --> Router Class Initialized
INFO - 2023-09-24 12:04:02 --> Output Class Initialized
INFO - 2023-09-24 12:04:02 --> Security Class Initialized
DEBUG - 2023-09-24 12:04:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-24 12:04:02 --> Input Class Initialized
INFO - 2023-09-24 12:04:02 --> Language Class Initialized
INFO - 2023-09-24 12:04:02 --> Language Class Initialized
INFO - 2023-09-24 12:04:02 --> Config Class Initialized
INFO - 2023-09-24 12:04:02 --> Loader Class Initialized
INFO - 2023-09-24 12:04:02 --> Helper loaded: url_helper
INFO - 2023-09-24 12:04:02 --> Helper loaded: file_helper
INFO - 2023-09-24 12:04:02 --> Helper loaded: form_helper
INFO - 2023-09-24 12:04:02 --> Helper loaded: my_helper
INFO - 2023-09-24 12:04:02 --> Database Driver Class Initialized
INFO - 2023-09-24 12:04:02 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-24 12:04:02 --> Controller Class Initialized
INFO - 2023-09-24 12:04:02 --> Final output sent to browser
DEBUG - 2023-09-24 12:04:02 --> Total execution time: 0.2434
INFO - 2023-09-24 12:04:02 --> Config Class Initialized
INFO - 2023-09-24 12:04:02 --> Hooks Class Initialized
DEBUG - 2023-09-24 12:04:02 --> UTF-8 Support Enabled
INFO - 2023-09-24 12:04:02 --> Utf8 Class Initialized
INFO - 2023-09-24 12:04:02 --> URI Class Initialized
INFO - 2023-09-24 12:04:02 --> Router Class Initialized
INFO - 2023-09-24 12:04:02 --> Output Class Initialized
INFO - 2023-09-24 12:04:02 --> Security Class Initialized
DEBUG - 2023-09-24 12:04:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-24 12:04:02 --> Input Class Initialized
INFO - 2023-09-24 12:04:02 --> Language Class Initialized
INFO - 2023-09-24 12:04:02 --> Language Class Initialized
INFO - 2023-09-24 12:04:02 --> Config Class Initialized
INFO - 2023-09-24 12:04:02 --> Loader Class Initialized
INFO - 2023-09-24 12:04:02 --> Helper loaded: url_helper
INFO - 2023-09-24 12:04:02 --> Helper loaded: file_helper
INFO - 2023-09-24 12:04:02 --> Helper loaded: form_helper
INFO - 2023-09-24 12:04:02 --> Helper loaded: my_helper
INFO - 2023-09-24 12:04:02 --> Database Driver Class Initialized
INFO - 2023-09-24 12:04:02 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-24 12:04:02 --> Controller Class Initialized
INFO - 2023-09-24 12:04:03 --> Config Class Initialized
INFO - 2023-09-24 12:04:03 --> Hooks Class Initialized
DEBUG - 2023-09-24 12:04:03 --> UTF-8 Support Enabled
INFO - 2023-09-24 12:04:03 --> Utf8 Class Initialized
INFO - 2023-09-24 12:04:03 --> URI Class Initialized
INFO - 2023-09-24 12:04:03 --> Router Class Initialized
INFO - 2023-09-24 12:04:03 --> Output Class Initialized
INFO - 2023-09-24 12:04:03 --> Security Class Initialized
DEBUG - 2023-09-24 12:04:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-24 12:04:03 --> Input Class Initialized
INFO - 2023-09-24 12:04:03 --> Language Class Initialized
INFO - 2023-09-24 12:04:03 --> Language Class Initialized
INFO - 2023-09-24 12:04:03 --> Config Class Initialized
INFO - 2023-09-24 12:04:03 --> Loader Class Initialized
INFO - 2023-09-24 12:04:03 --> Helper loaded: url_helper
INFO - 2023-09-24 12:04:03 --> Helper loaded: file_helper
INFO - 2023-09-24 12:04:03 --> Helper loaded: form_helper
INFO - 2023-09-24 12:04:03 --> Helper loaded: my_helper
INFO - 2023-09-24 12:04:03 --> Database Driver Class Initialized
INFO - 2023-09-24 12:04:03 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-24 12:04:03 --> Controller Class Initialized
INFO - 2023-09-24 12:04:03 --> Final output sent to browser
DEBUG - 2023-09-24 12:04:03 --> Total execution time: 0.0433
INFO - 2023-09-24 12:04:12 --> Config Class Initialized
INFO - 2023-09-24 12:04:12 --> Hooks Class Initialized
DEBUG - 2023-09-24 12:04:12 --> UTF-8 Support Enabled
INFO - 2023-09-24 12:04:12 --> Utf8 Class Initialized
INFO - 2023-09-24 12:04:12 --> URI Class Initialized
INFO - 2023-09-24 12:04:12 --> Router Class Initialized
INFO - 2023-09-24 12:04:12 --> Output Class Initialized
INFO - 2023-09-24 12:04:12 --> Security Class Initialized
DEBUG - 2023-09-24 12:04:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-24 12:04:12 --> Input Class Initialized
INFO - 2023-09-24 12:04:12 --> Language Class Initialized
INFO - 2023-09-24 12:04:12 --> Language Class Initialized
INFO - 2023-09-24 12:04:12 --> Config Class Initialized
INFO - 2023-09-24 12:04:12 --> Loader Class Initialized
INFO - 2023-09-24 12:04:12 --> Helper loaded: url_helper
INFO - 2023-09-24 12:04:12 --> Helper loaded: file_helper
INFO - 2023-09-24 12:04:12 --> Helper loaded: form_helper
INFO - 2023-09-24 12:04:12 --> Helper loaded: my_helper
INFO - 2023-09-24 12:04:12 --> Database Driver Class Initialized
INFO - 2023-09-24 12:04:12 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-24 12:04:12 --> Controller Class Initialized
INFO - 2023-09-24 12:04:12 --> Final output sent to browser
DEBUG - 2023-09-24 12:04:12 --> Total execution time: 0.0344
INFO - 2023-09-24 12:04:12 --> Config Class Initialized
INFO - 2023-09-24 12:04:12 --> Hooks Class Initialized
DEBUG - 2023-09-24 12:04:12 --> UTF-8 Support Enabled
INFO - 2023-09-24 12:04:12 --> Utf8 Class Initialized
INFO - 2023-09-24 12:04:12 --> URI Class Initialized
INFO - 2023-09-24 12:04:12 --> Router Class Initialized
INFO - 2023-09-24 12:04:12 --> Output Class Initialized
INFO - 2023-09-24 12:04:12 --> Security Class Initialized
DEBUG - 2023-09-24 12:04:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-24 12:04:12 --> Input Class Initialized
INFO - 2023-09-24 12:04:12 --> Language Class Initialized
INFO - 2023-09-24 12:04:12 --> Language Class Initialized
INFO - 2023-09-24 12:04:12 --> Config Class Initialized
INFO - 2023-09-24 12:04:12 --> Loader Class Initialized
INFO - 2023-09-24 12:04:12 --> Helper loaded: url_helper
INFO - 2023-09-24 12:04:12 --> Helper loaded: file_helper
INFO - 2023-09-24 12:04:12 --> Helper loaded: form_helper
INFO - 2023-09-24 12:04:12 --> Helper loaded: my_helper
INFO - 2023-09-24 12:04:12 --> Database Driver Class Initialized
INFO - 2023-09-24 12:04:12 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-24 12:04:12 --> Controller Class Initialized
INFO - 2023-09-24 12:04:14 --> Config Class Initialized
INFO - 2023-09-24 12:04:14 --> Hooks Class Initialized
DEBUG - 2023-09-24 12:04:14 --> UTF-8 Support Enabled
INFO - 2023-09-24 12:04:14 --> Utf8 Class Initialized
INFO - 2023-09-24 12:04:14 --> URI Class Initialized
INFO - 2023-09-24 12:04:14 --> Router Class Initialized
INFO - 2023-09-24 12:04:14 --> Output Class Initialized
INFO - 2023-09-24 12:04:14 --> Security Class Initialized
DEBUG - 2023-09-24 12:04:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-24 12:04:14 --> Input Class Initialized
INFO - 2023-09-24 12:04:14 --> Language Class Initialized
INFO - 2023-09-24 12:04:14 --> Language Class Initialized
INFO - 2023-09-24 12:04:14 --> Config Class Initialized
INFO - 2023-09-24 12:04:14 --> Loader Class Initialized
INFO - 2023-09-24 12:04:14 --> Helper loaded: url_helper
INFO - 2023-09-24 12:04:14 --> Helper loaded: file_helper
INFO - 2023-09-24 12:04:14 --> Helper loaded: form_helper
INFO - 2023-09-24 12:04:14 --> Helper loaded: my_helper
INFO - 2023-09-24 12:04:14 --> Database Driver Class Initialized
INFO - 2023-09-24 12:04:14 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-24 12:04:14 --> Controller Class Initialized
INFO - 2023-09-24 12:04:14 --> Final output sent to browser
DEBUG - 2023-09-24 12:04:14 --> Total execution time: 0.0408
INFO - 2023-09-24 12:04:22 --> Config Class Initialized
INFO - 2023-09-24 12:04:22 --> Hooks Class Initialized
DEBUG - 2023-09-24 12:04:22 --> UTF-8 Support Enabled
INFO - 2023-09-24 12:04:22 --> Utf8 Class Initialized
INFO - 2023-09-24 12:04:22 --> URI Class Initialized
INFO - 2023-09-24 12:04:22 --> Router Class Initialized
INFO - 2023-09-24 12:04:22 --> Output Class Initialized
INFO - 2023-09-24 12:04:22 --> Security Class Initialized
DEBUG - 2023-09-24 12:04:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-24 12:04:22 --> Input Class Initialized
INFO - 2023-09-24 12:04:22 --> Language Class Initialized
INFO - 2023-09-24 12:04:22 --> Language Class Initialized
INFO - 2023-09-24 12:04:22 --> Config Class Initialized
INFO - 2023-09-24 12:04:22 --> Loader Class Initialized
INFO - 2023-09-24 12:04:22 --> Helper loaded: url_helper
INFO - 2023-09-24 12:04:22 --> Helper loaded: file_helper
INFO - 2023-09-24 12:04:22 --> Helper loaded: form_helper
INFO - 2023-09-24 12:04:22 --> Helper loaded: my_helper
INFO - 2023-09-24 12:04:22 --> Database Driver Class Initialized
INFO - 2023-09-24 12:04:22 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-24 12:04:22 --> Controller Class Initialized
INFO - 2023-09-24 12:04:22 --> Final output sent to browser
DEBUG - 2023-09-24 12:04:22 --> Total execution time: 0.0411
INFO - 2023-09-24 12:04:22 --> Config Class Initialized
INFO - 2023-09-24 12:04:22 --> Hooks Class Initialized
DEBUG - 2023-09-24 12:04:22 --> UTF-8 Support Enabled
INFO - 2023-09-24 12:04:22 --> Utf8 Class Initialized
INFO - 2023-09-24 12:04:22 --> URI Class Initialized
INFO - 2023-09-24 12:04:22 --> Router Class Initialized
INFO - 2023-09-24 12:04:22 --> Output Class Initialized
INFO - 2023-09-24 12:04:22 --> Security Class Initialized
DEBUG - 2023-09-24 12:04:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-24 12:04:22 --> Input Class Initialized
INFO - 2023-09-24 12:04:22 --> Language Class Initialized
INFO - 2023-09-24 12:04:22 --> Language Class Initialized
INFO - 2023-09-24 12:04:22 --> Config Class Initialized
INFO - 2023-09-24 12:04:22 --> Loader Class Initialized
INFO - 2023-09-24 12:04:22 --> Helper loaded: url_helper
INFO - 2023-09-24 12:04:22 --> Helper loaded: file_helper
INFO - 2023-09-24 12:04:22 --> Helper loaded: form_helper
INFO - 2023-09-24 12:04:22 --> Helper loaded: my_helper
INFO - 2023-09-24 12:04:22 --> Database Driver Class Initialized
INFO - 2023-09-24 12:04:22 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-24 12:04:22 --> Controller Class Initialized
INFO - 2023-09-24 12:04:34 --> Config Class Initialized
INFO - 2023-09-24 12:04:34 --> Hooks Class Initialized
DEBUG - 2023-09-24 12:04:34 --> UTF-8 Support Enabled
INFO - 2023-09-24 12:04:34 --> Utf8 Class Initialized
INFO - 2023-09-24 12:04:34 --> URI Class Initialized
INFO - 2023-09-24 12:04:34 --> Router Class Initialized
INFO - 2023-09-24 12:04:34 --> Output Class Initialized
INFO - 2023-09-24 12:04:34 --> Security Class Initialized
DEBUG - 2023-09-24 12:04:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-24 12:04:34 --> Input Class Initialized
INFO - 2023-09-24 12:04:34 --> Language Class Initialized
INFO - 2023-09-24 12:04:34 --> Language Class Initialized
INFO - 2023-09-24 12:04:34 --> Config Class Initialized
INFO - 2023-09-24 12:04:34 --> Loader Class Initialized
INFO - 2023-09-24 12:04:34 --> Helper loaded: url_helper
INFO - 2023-09-24 12:04:34 --> Helper loaded: file_helper
INFO - 2023-09-24 12:04:34 --> Helper loaded: form_helper
INFO - 2023-09-24 12:04:34 --> Helper loaded: my_helper
INFO - 2023-09-24 12:04:35 --> Database Driver Class Initialized
INFO - 2023-09-24 12:04:35 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-24 12:04:35 --> Controller Class Initialized
ERROR - 2023-09-24 12:04:35 --> Severity: Notice --> Undefined offset: 26 /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/controllers/N_pengetahuan.php 393
ERROR - 2023-09-24 12:04:35 --> Severity: error --> Exception: Invalid cell coordinate 7 /www/wwwroot/report.mhis.link/bangka/secondary/application/third_party/PHP_Excel/PHPExcel/Cell.php 558
INFO - 2023-09-24 12:04:41 --> Config Class Initialized
INFO - 2023-09-24 12:04:41 --> Hooks Class Initialized
DEBUG - 2023-09-24 12:04:41 --> UTF-8 Support Enabled
INFO - 2023-09-24 12:04:41 --> Utf8 Class Initialized
INFO - 2023-09-24 12:04:41 --> URI Class Initialized
INFO - 2023-09-24 12:04:41 --> Router Class Initialized
INFO - 2023-09-24 12:04:41 --> Output Class Initialized
INFO - 2023-09-24 12:04:41 --> Security Class Initialized
DEBUG - 2023-09-24 12:04:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-24 12:04:41 --> Input Class Initialized
INFO - 2023-09-24 12:04:41 --> Language Class Initialized
INFO - 2023-09-24 12:04:41 --> Language Class Initialized
INFO - 2023-09-24 12:04:41 --> Config Class Initialized
INFO - 2023-09-24 12:04:41 --> Loader Class Initialized
INFO - 2023-09-24 12:04:41 --> Helper loaded: url_helper
INFO - 2023-09-24 12:04:41 --> Helper loaded: file_helper
INFO - 2023-09-24 12:04:41 --> Helper loaded: form_helper
INFO - 2023-09-24 12:04:41 --> Helper loaded: my_helper
INFO - 2023-09-24 12:04:41 --> Database Driver Class Initialized
INFO - 2023-09-24 12:04:41 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-24 12:04:41 --> Controller Class Initialized
DEBUG - 2023-09-24 12:04:41 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/views/list.php
DEBUG - 2023-09-24 12:04:41 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-09-24 12:04:41 --> Final output sent to browser
DEBUG - 2023-09-24 12:04:41 --> Total execution time: 0.0366
INFO - 2023-09-24 12:04:41 --> Config Class Initialized
INFO - 2023-09-24 12:04:41 --> Hooks Class Initialized
DEBUG - 2023-09-24 12:04:41 --> UTF-8 Support Enabled
INFO - 2023-09-24 12:04:41 --> Utf8 Class Initialized
INFO - 2023-09-24 12:04:41 --> URI Class Initialized
INFO - 2023-09-24 12:04:41 --> Router Class Initialized
INFO - 2023-09-24 12:04:41 --> Output Class Initialized
INFO - 2023-09-24 12:04:41 --> Security Class Initialized
DEBUG - 2023-09-24 12:04:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-24 12:04:41 --> Input Class Initialized
INFO - 2023-09-24 12:04:42 --> Language Class Initialized
INFO - 2023-09-24 12:04:42 --> Language Class Initialized
INFO - 2023-09-24 12:04:42 --> Config Class Initialized
INFO - 2023-09-24 12:04:42 --> Loader Class Initialized
INFO - 2023-09-24 12:04:42 --> Helper loaded: url_helper
INFO - 2023-09-24 12:04:42 --> Helper loaded: file_helper
INFO - 2023-09-24 12:04:42 --> Helper loaded: form_helper
INFO - 2023-09-24 12:04:42 --> Helper loaded: my_helper
INFO - 2023-09-24 12:04:42 --> Database Driver Class Initialized
INFO - 2023-09-24 12:04:42 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-24 12:04:42 --> Controller Class Initialized
INFO - 2023-09-24 12:05:21 --> Config Class Initialized
INFO - 2023-09-24 12:05:21 --> Hooks Class Initialized
DEBUG - 2023-09-24 12:05:21 --> UTF-8 Support Enabled
INFO - 2023-09-24 12:05:21 --> Utf8 Class Initialized
INFO - 2023-09-24 12:05:21 --> URI Class Initialized
INFO - 2023-09-24 12:05:21 --> Router Class Initialized
INFO - 2023-09-24 12:05:21 --> Output Class Initialized
INFO - 2023-09-24 12:05:21 --> Security Class Initialized
DEBUG - 2023-09-24 12:05:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-24 12:05:21 --> Input Class Initialized
INFO - 2023-09-24 12:05:21 --> Language Class Initialized
INFO - 2023-09-24 12:05:21 --> Language Class Initialized
INFO - 2023-09-24 12:05:21 --> Config Class Initialized
INFO - 2023-09-24 12:05:21 --> Loader Class Initialized
INFO - 2023-09-24 12:05:21 --> Helper loaded: url_helper
INFO - 2023-09-24 12:05:21 --> Helper loaded: file_helper
INFO - 2023-09-24 12:05:21 --> Helper loaded: form_helper
INFO - 2023-09-24 12:05:21 --> Helper loaded: my_helper
INFO - 2023-09-24 12:05:21 --> Database Driver Class Initialized
INFO - 2023-09-24 12:05:21 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-24 12:05:21 --> Controller Class Initialized
INFO - 2023-09-24 12:05:21 --> Final output sent to browser
DEBUG - 2023-09-24 12:05:21 --> Total execution time: 0.0569
INFO - 2023-09-24 12:05:27 --> Config Class Initialized
INFO - 2023-09-24 12:05:27 --> Hooks Class Initialized
DEBUG - 2023-09-24 12:05:27 --> UTF-8 Support Enabled
INFO - 2023-09-24 12:05:27 --> Utf8 Class Initialized
INFO - 2023-09-24 12:05:27 --> URI Class Initialized
INFO - 2023-09-24 12:05:27 --> Router Class Initialized
INFO - 2023-09-24 12:05:27 --> Output Class Initialized
INFO - 2023-09-24 12:05:27 --> Security Class Initialized
DEBUG - 2023-09-24 12:05:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-24 12:05:27 --> Input Class Initialized
INFO - 2023-09-24 12:05:27 --> Language Class Initialized
INFO - 2023-09-24 12:05:27 --> Language Class Initialized
INFO - 2023-09-24 12:05:27 --> Config Class Initialized
INFO - 2023-09-24 12:05:27 --> Loader Class Initialized
INFO - 2023-09-24 12:05:27 --> Helper loaded: url_helper
INFO - 2023-09-24 12:05:27 --> Helper loaded: file_helper
INFO - 2023-09-24 12:05:27 --> Helper loaded: form_helper
INFO - 2023-09-24 12:05:27 --> Helper loaded: my_helper
INFO - 2023-09-24 12:05:27 --> Database Driver Class Initialized
INFO - 2023-09-24 12:05:27 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-24 12:05:27 --> Controller Class Initialized
INFO - 2023-09-24 12:05:27 --> Config Class Initialized
INFO - 2023-09-24 12:05:27 --> Hooks Class Initialized
DEBUG - 2023-09-24 12:05:27 --> UTF-8 Support Enabled
INFO - 2023-09-24 12:05:27 --> Utf8 Class Initialized
INFO - 2023-09-24 12:05:27 --> URI Class Initialized
INFO - 2023-09-24 12:05:27 --> Router Class Initialized
INFO - 2023-09-24 12:05:27 --> Output Class Initialized
INFO - 2023-09-24 12:05:27 --> Security Class Initialized
DEBUG - 2023-09-24 12:05:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-24 12:05:27 --> Input Class Initialized
INFO - 2023-09-24 12:05:27 --> Language Class Initialized
INFO - 2023-09-24 12:05:27 --> Language Class Initialized
INFO - 2023-09-24 12:05:27 --> Config Class Initialized
INFO - 2023-09-24 12:05:27 --> Loader Class Initialized
INFO - 2023-09-24 12:05:27 --> Helper loaded: url_helper
INFO - 2023-09-24 12:05:27 --> Helper loaded: file_helper
INFO - 2023-09-24 12:05:27 --> Helper loaded: form_helper
INFO - 2023-09-24 12:05:27 --> Helper loaded: my_helper
INFO - 2023-09-24 12:05:27 --> Database Driver Class Initialized
INFO - 2023-09-24 12:05:27 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-24 12:05:27 --> Controller Class Initialized
DEBUG - 2023-09-24 12:05:27 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/login/views/login.php
DEBUG - 2023-09-24 12:05:27 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-09-24 12:05:27 --> Final output sent to browser
DEBUG - 2023-09-24 12:05:27 --> Total execution time: 0.0362
INFO - 2023-09-24 12:05:29 --> Config Class Initialized
INFO - 2023-09-24 12:05:29 --> Hooks Class Initialized
DEBUG - 2023-09-24 12:05:29 --> UTF-8 Support Enabled
INFO - 2023-09-24 12:05:29 --> Utf8 Class Initialized
INFO - 2023-09-24 12:05:29 --> URI Class Initialized
INFO - 2023-09-24 12:05:29 --> Router Class Initialized
INFO - 2023-09-24 12:05:29 --> Output Class Initialized
INFO - 2023-09-24 12:05:29 --> Security Class Initialized
DEBUG - 2023-09-24 12:05:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-24 12:05:29 --> Input Class Initialized
INFO - 2023-09-24 12:05:29 --> Language Class Initialized
INFO - 2023-09-24 12:05:29 --> Language Class Initialized
INFO - 2023-09-24 12:05:29 --> Config Class Initialized
INFO - 2023-09-24 12:05:29 --> Loader Class Initialized
INFO - 2023-09-24 12:05:29 --> Helper loaded: url_helper
INFO - 2023-09-24 12:05:29 --> Helper loaded: file_helper
INFO - 2023-09-24 12:05:29 --> Helper loaded: form_helper
INFO - 2023-09-24 12:05:29 --> Helper loaded: my_helper
INFO - 2023-09-24 12:05:29 --> Database Driver Class Initialized
INFO - 2023-09-24 12:05:29 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-24 12:05:29 --> Controller Class Initialized
INFO - 2023-09-24 12:05:29 --> Helper loaded: cookie_helper
INFO - 2023-09-24 12:05:29 --> Final output sent to browser
DEBUG - 2023-09-24 12:05:29 --> Total execution time: 0.0425
INFO - 2023-09-24 12:05:30 --> Config Class Initialized
INFO - 2023-09-24 12:05:30 --> Hooks Class Initialized
DEBUG - 2023-09-24 12:05:30 --> UTF-8 Support Enabled
INFO - 2023-09-24 12:05:30 --> Utf8 Class Initialized
INFO - 2023-09-24 12:05:30 --> URI Class Initialized
INFO - 2023-09-24 12:05:30 --> Router Class Initialized
INFO - 2023-09-24 12:05:30 --> Output Class Initialized
INFO - 2023-09-24 12:05:30 --> Security Class Initialized
DEBUG - 2023-09-24 12:05:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-24 12:05:30 --> Input Class Initialized
INFO - 2023-09-24 12:05:30 --> Language Class Initialized
INFO - 2023-09-24 12:05:30 --> Language Class Initialized
INFO - 2023-09-24 12:05:30 --> Config Class Initialized
INFO - 2023-09-24 12:05:30 --> Loader Class Initialized
INFO - 2023-09-24 12:05:30 --> Helper loaded: url_helper
INFO - 2023-09-24 12:05:30 --> Helper loaded: file_helper
INFO - 2023-09-24 12:05:30 --> Helper loaded: form_helper
INFO - 2023-09-24 12:05:30 --> Helper loaded: my_helper
INFO - 2023-09-24 12:05:30 --> Database Driver Class Initialized
INFO - 2023-09-24 12:05:30 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-24 12:05:30 --> Controller Class Initialized
DEBUG - 2023-09-24 12:05:30 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/home/views/v_home_guru.php
DEBUG - 2023-09-24 12:05:30 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-09-24 12:05:30 --> Final output sent to browser
DEBUG - 2023-09-24 12:05:30 --> Total execution time: 0.0350
INFO - 2023-09-24 12:05:44 --> Config Class Initialized
INFO - 2023-09-24 12:05:44 --> Hooks Class Initialized
DEBUG - 2023-09-24 12:05:44 --> UTF-8 Support Enabled
INFO - 2023-09-24 12:05:44 --> Utf8 Class Initialized
INFO - 2023-09-24 12:05:44 --> URI Class Initialized
INFO - 2023-09-24 12:05:44 --> Router Class Initialized
INFO - 2023-09-24 12:05:44 --> Output Class Initialized
INFO - 2023-09-24 12:05:44 --> Security Class Initialized
DEBUG - 2023-09-24 12:05:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-24 12:05:44 --> Input Class Initialized
INFO - 2023-09-24 12:05:44 --> Language Class Initialized
INFO - 2023-09-24 12:05:44 --> Language Class Initialized
INFO - 2023-09-24 12:05:44 --> Config Class Initialized
INFO - 2023-09-24 12:05:44 --> Loader Class Initialized
INFO - 2023-09-24 12:05:44 --> Helper loaded: url_helper
INFO - 2023-09-24 12:05:44 --> Helper loaded: file_helper
INFO - 2023-09-24 12:05:44 --> Helper loaded: form_helper
INFO - 2023-09-24 12:05:44 --> Helper loaded: my_helper
INFO - 2023-09-24 12:05:44 --> Database Driver Class Initialized
INFO - 2023-09-24 12:05:44 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-24 12:05:44 --> Controller Class Initialized
DEBUG - 2023-09-24 12:05:44 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/view_mapel/views/v_view_mapel.php
DEBUG - 2023-09-24 12:05:44 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-09-24 12:05:44 --> Final output sent to browser
DEBUG - 2023-09-24 12:05:44 --> Total execution time: 0.0795
INFO - 2023-09-24 12:05:47 --> Config Class Initialized
INFO - 2023-09-24 12:05:47 --> Hooks Class Initialized
DEBUG - 2023-09-24 12:05:47 --> UTF-8 Support Enabled
INFO - 2023-09-24 12:05:47 --> Utf8 Class Initialized
INFO - 2023-09-24 12:05:47 --> URI Class Initialized
INFO - 2023-09-24 12:05:47 --> Router Class Initialized
INFO - 2023-09-24 12:05:47 --> Output Class Initialized
INFO - 2023-09-24 12:05:47 --> Security Class Initialized
DEBUG - 2023-09-24 12:05:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-24 12:05:47 --> Input Class Initialized
INFO - 2023-09-24 12:05:47 --> Language Class Initialized
INFO - 2023-09-24 12:05:47 --> Language Class Initialized
INFO - 2023-09-24 12:05:47 --> Config Class Initialized
INFO - 2023-09-24 12:05:47 --> Loader Class Initialized
INFO - 2023-09-24 12:05:47 --> Helper loaded: url_helper
INFO - 2023-09-24 12:05:47 --> Helper loaded: file_helper
INFO - 2023-09-24 12:05:47 --> Helper loaded: form_helper
INFO - 2023-09-24 12:05:47 --> Helper loaded: my_helper
INFO - 2023-09-24 12:05:47 --> Database Driver Class Initialized
INFO - 2023-09-24 12:05:47 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-24 12:05:47 --> Controller Class Initialized
DEBUG - 2023-09-24 12:05:48 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/views/list.php
DEBUG - 2023-09-24 12:05:48 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-09-24 12:05:48 --> Final output sent to browser
DEBUG - 2023-09-24 12:05:48 --> Total execution time: 0.0455
INFO - 2023-09-24 12:05:48 --> Config Class Initialized
INFO - 2023-09-24 12:05:48 --> Hooks Class Initialized
DEBUG - 2023-09-24 12:05:48 --> UTF-8 Support Enabled
INFO - 2023-09-24 12:05:48 --> Utf8 Class Initialized
INFO - 2023-09-24 12:05:48 --> URI Class Initialized
INFO - 2023-09-24 12:05:48 --> Router Class Initialized
INFO - 2023-09-24 12:05:48 --> Output Class Initialized
INFO - 2023-09-24 12:05:48 --> Security Class Initialized
DEBUG - 2023-09-24 12:05:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-24 12:05:48 --> Input Class Initialized
INFO - 2023-09-24 12:05:48 --> Language Class Initialized
INFO - 2023-09-24 12:05:48 --> Language Class Initialized
INFO - 2023-09-24 12:05:48 --> Config Class Initialized
INFO - 2023-09-24 12:05:48 --> Loader Class Initialized
INFO - 2023-09-24 12:05:48 --> Helper loaded: url_helper
INFO - 2023-09-24 12:05:48 --> Helper loaded: file_helper
INFO - 2023-09-24 12:05:48 --> Helper loaded: form_helper
INFO - 2023-09-24 12:05:48 --> Helper loaded: my_helper
INFO - 2023-09-24 12:05:48 --> Database Driver Class Initialized
INFO - 2023-09-24 12:05:48 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-24 12:05:48 --> Controller Class Initialized
INFO - 2023-09-24 12:05:49 --> Config Class Initialized
INFO - 2023-09-24 12:05:49 --> Hooks Class Initialized
DEBUG - 2023-09-24 12:05:49 --> UTF-8 Support Enabled
INFO - 2023-09-24 12:05:49 --> Utf8 Class Initialized
INFO - 2023-09-24 12:05:49 --> URI Class Initialized
INFO - 2023-09-24 12:05:49 --> Router Class Initialized
INFO - 2023-09-24 12:05:49 --> Output Class Initialized
INFO - 2023-09-24 12:05:49 --> Security Class Initialized
DEBUG - 2023-09-24 12:05:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-24 12:05:49 --> Input Class Initialized
INFO - 2023-09-24 12:05:49 --> Language Class Initialized
INFO - 2023-09-24 12:05:49 --> Language Class Initialized
INFO - 2023-09-24 12:05:49 --> Config Class Initialized
INFO - 2023-09-24 12:05:49 --> Loader Class Initialized
INFO - 2023-09-24 12:05:49 --> Helper loaded: url_helper
INFO - 2023-09-24 12:05:49 --> Helper loaded: file_helper
INFO - 2023-09-24 12:05:49 --> Helper loaded: form_helper
INFO - 2023-09-24 12:05:49 --> Helper loaded: my_helper
INFO - 2023-09-24 12:05:49 --> Database Driver Class Initialized
INFO - 2023-09-24 12:05:49 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-24 12:05:49 --> Controller Class Initialized
INFO - 2023-09-24 12:05:49 --> Final output sent to browser
DEBUG - 2023-09-24 12:05:49 --> Total execution time: 0.0358
INFO - 2023-09-24 12:08:47 --> Config Class Initialized
INFO - 2023-09-24 12:08:47 --> Hooks Class Initialized
DEBUG - 2023-09-24 12:08:47 --> UTF-8 Support Enabled
INFO - 2023-09-24 12:08:47 --> Utf8 Class Initialized
INFO - 2023-09-24 12:08:47 --> URI Class Initialized
INFO - 2023-09-24 12:08:47 --> Router Class Initialized
INFO - 2023-09-24 12:08:47 --> Output Class Initialized
INFO - 2023-09-24 12:08:47 --> Security Class Initialized
DEBUG - 2023-09-24 12:08:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-24 12:08:47 --> Input Class Initialized
INFO - 2023-09-24 12:08:47 --> Language Class Initialized
INFO - 2023-09-24 12:08:47 --> Language Class Initialized
INFO - 2023-09-24 12:08:47 --> Config Class Initialized
INFO - 2023-09-24 12:08:47 --> Loader Class Initialized
INFO - 2023-09-24 12:08:47 --> Helper loaded: url_helper
INFO - 2023-09-24 12:08:47 --> Helper loaded: file_helper
INFO - 2023-09-24 12:08:47 --> Helper loaded: form_helper
INFO - 2023-09-24 12:08:47 --> Helper loaded: my_helper
INFO - 2023-09-24 12:08:47 --> Database Driver Class Initialized
INFO - 2023-09-24 12:08:47 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-24 12:08:47 --> Controller Class Initialized
INFO - 2023-09-24 12:08:47 --> Final output sent to browser
DEBUG - 2023-09-24 12:08:47 --> Total execution time: 0.0592
INFO - 2023-09-24 12:08:56 --> Config Class Initialized
INFO - 2023-09-24 12:08:56 --> Hooks Class Initialized
DEBUG - 2023-09-24 12:08:56 --> UTF-8 Support Enabled
INFO - 2023-09-24 12:08:56 --> Utf8 Class Initialized
INFO - 2023-09-24 12:08:56 --> URI Class Initialized
INFO - 2023-09-24 12:08:56 --> Router Class Initialized
INFO - 2023-09-24 12:08:56 --> Output Class Initialized
INFO - 2023-09-24 12:08:56 --> Security Class Initialized
DEBUG - 2023-09-24 12:08:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-24 12:08:56 --> Input Class Initialized
INFO - 2023-09-24 12:08:56 --> Language Class Initialized
INFO - 2023-09-24 12:08:56 --> Language Class Initialized
INFO - 2023-09-24 12:08:56 --> Config Class Initialized
INFO - 2023-09-24 12:08:56 --> Loader Class Initialized
INFO - 2023-09-24 12:08:56 --> Helper loaded: url_helper
INFO - 2023-09-24 12:08:56 --> Helper loaded: file_helper
INFO - 2023-09-24 12:08:56 --> Helper loaded: form_helper
INFO - 2023-09-24 12:08:56 --> Helper loaded: my_helper
INFO - 2023-09-24 12:08:56 --> Database Driver Class Initialized
INFO - 2023-09-24 12:08:56 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-24 12:08:56 --> Controller Class Initialized
INFO - 2023-09-24 12:08:56 --> Final output sent to browser
DEBUG - 2023-09-24 12:08:56 --> Total execution time: 0.0695
INFO - 2023-09-24 12:22:15 --> Config Class Initialized
INFO - 2023-09-24 12:22:15 --> Hooks Class Initialized
DEBUG - 2023-09-24 12:22:15 --> UTF-8 Support Enabled
INFO - 2023-09-24 12:22:15 --> Utf8 Class Initialized
INFO - 2023-09-24 12:22:15 --> URI Class Initialized
INFO - 2023-09-24 12:22:15 --> Router Class Initialized
INFO - 2023-09-24 12:22:15 --> Output Class Initialized
INFO - 2023-09-24 12:22:15 --> Security Class Initialized
DEBUG - 2023-09-24 12:22:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-24 12:22:15 --> Input Class Initialized
INFO - 2023-09-24 12:22:15 --> Language Class Initialized
INFO - 2023-09-24 12:22:15 --> Language Class Initialized
INFO - 2023-09-24 12:22:15 --> Config Class Initialized
INFO - 2023-09-24 12:22:15 --> Loader Class Initialized
INFO - 2023-09-24 12:22:15 --> Helper loaded: url_helper
INFO - 2023-09-24 12:22:15 --> Helper loaded: file_helper
INFO - 2023-09-24 12:22:15 --> Helper loaded: form_helper
INFO - 2023-09-24 12:22:15 --> Helper loaded: my_helper
INFO - 2023-09-24 12:22:15 --> Database Driver Class Initialized
INFO - 2023-09-24 12:22:15 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-24 12:22:15 --> Controller Class Initialized
INFO - 2023-09-24 12:22:15 --> Final output sent to browser
DEBUG - 2023-09-24 12:22:15 --> Total execution time: 0.0290
INFO - 2023-09-24 12:22:15 --> Config Class Initialized
INFO - 2023-09-24 12:22:15 --> Hooks Class Initialized
DEBUG - 2023-09-24 12:22:15 --> UTF-8 Support Enabled
INFO - 2023-09-24 12:22:15 --> Utf8 Class Initialized
INFO - 2023-09-24 12:22:15 --> URI Class Initialized
INFO - 2023-09-24 12:22:16 --> Router Class Initialized
INFO - 2023-09-24 12:22:16 --> Output Class Initialized
INFO - 2023-09-24 12:22:16 --> Security Class Initialized
DEBUG - 2023-09-24 12:22:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-24 12:22:16 --> Input Class Initialized
INFO - 2023-09-24 12:22:16 --> Language Class Initialized
INFO - 2023-09-24 12:22:16 --> Language Class Initialized
INFO - 2023-09-24 12:22:16 --> Config Class Initialized
INFO - 2023-09-24 12:22:16 --> Loader Class Initialized
INFO - 2023-09-24 12:22:16 --> Helper loaded: url_helper
INFO - 2023-09-24 12:22:16 --> Helper loaded: file_helper
INFO - 2023-09-24 12:22:16 --> Helper loaded: form_helper
INFO - 2023-09-24 12:22:16 --> Helper loaded: my_helper
INFO - 2023-09-24 12:22:16 --> Database Driver Class Initialized
INFO - 2023-09-24 12:22:16 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-24 12:22:16 --> Controller Class Initialized
INFO - 2023-09-24 12:22:16 --> Config Class Initialized
INFO - 2023-09-24 12:22:16 --> Hooks Class Initialized
DEBUG - 2023-09-24 12:22:16 --> UTF-8 Support Enabled
INFO - 2023-09-24 12:22:16 --> Utf8 Class Initialized
INFO - 2023-09-24 12:22:16 --> URI Class Initialized
INFO - 2023-09-24 12:22:16 --> Router Class Initialized
INFO - 2023-09-24 12:22:16 --> Output Class Initialized
INFO - 2023-09-24 12:22:16 --> Security Class Initialized
DEBUG - 2023-09-24 12:22:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-24 12:22:16 --> Input Class Initialized
INFO - 2023-09-24 12:22:16 --> Language Class Initialized
INFO - 2023-09-24 12:22:17 --> Language Class Initialized
INFO - 2023-09-24 12:22:17 --> Config Class Initialized
INFO - 2023-09-24 12:22:17 --> Loader Class Initialized
INFO - 2023-09-24 12:22:17 --> Helper loaded: url_helper
INFO - 2023-09-24 12:22:17 --> Helper loaded: file_helper
INFO - 2023-09-24 12:22:17 --> Helper loaded: form_helper
INFO - 2023-09-24 12:22:17 --> Helper loaded: my_helper
INFO - 2023-09-24 12:22:17 --> Database Driver Class Initialized
INFO - 2023-09-24 12:22:17 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-24 12:22:17 --> Controller Class Initialized
INFO - 2023-09-24 12:22:17 --> Final output sent to browser
DEBUG - 2023-09-24 12:22:17 --> Total execution time: 0.0314
INFO - 2023-09-24 12:22:26 --> Config Class Initialized
INFO - 2023-09-24 12:22:26 --> Hooks Class Initialized
DEBUG - 2023-09-24 12:22:26 --> UTF-8 Support Enabled
INFO - 2023-09-24 12:22:26 --> Utf8 Class Initialized
INFO - 2023-09-24 12:22:26 --> URI Class Initialized
INFO - 2023-09-24 12:22:26 --> Router Class Initialized
INFO - 2023-09-24 12:22:26 --> Output Class Initialized
INFO - 2023-09-24 12:22:26 --> Security Class Initialized
DEBUG - 2023-09-24 12:22:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-24 12:22:26 --> Input Class Initialized
INFO - 2023-09-24 12:22:26 --> Language Class Initialized
INFO - 2023-09-24 12:22:26 --> Language Class Initialized
INFO - 2023-09-24 12:22:26 --> Config Class Initialized
INFO - 2023-09-24 12:22:26 --> Loader Class Initialized
INFO - 2023-09-24 12:22:26 --> Helper loaded: url_helper
INFO - 2023-09-24 12:22:26 --> Helper loaded: file_helper
INFO - 2023-09-24 12:22:26 --> Helper loaded: form_helper
INFO - 2023-09-24 12:22:26 --> Helper loaded: my_helper
INFO - 2023-09-24 12:22:26 --> Database Driver Class Initialized
INFO - 2023-09-24 12:22:26 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-24 12:22:26 --> Controller Class Initialized
INFO - 2023-09-24 12:22:26 --> Final output sent to browser
DEBUG - 2023-09-24 12:22:26 --> Total execution time: 0.0341
INFO - 2023-09-24 12:22:26 --> Config Class Initialized
INFO - 2023-09-24 12:22:26 --> Hooks Class Initialized
DEBUG - 2023-09-24 12:22:26 --> UTF-8 Support Enabled
INFO - 2023-09-24 12:22:26 --> Utf8 Class Initialized
INFO - 2023-09-24 12:22:26 --> URI Class Initialized
INFO - 2023-09-24 12:22:26 --> Router Class Initialized
INFO - 2023-09-24 12:22:26 --> Output Class Initialized
INFO - 2023-09-24 12:22:26 --> Security Class Initialized
DEBUG - 2023-09-24 12:22:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-24 12:22:26 --> Input Class Initialized
INFO - 2023-09-24 12:22:26 --> Language Class Initialized
INFO - 2023-09-24 12:22:26 --> Language Class Initialized
INFO - 2023-09-24 12:22:26 --> Config Class Initialized
INFO - 2023-09-24 12:22:26 --> Loader Class Initialized
INFO - 2023-09-24 12:22:26 --> Helper loaded: url_helper
INFO - 2023-09-24 12:22:26 --> Helper loaded: file_helper
INFO - 2023-09-24 12:22:26 --> Helper loaded: form_helper
INFO - 2023-09-24 12:22:26 --> Helper loaded: my_helper
INFO - 2023-09-24 12:22:26 --> Database Driver Class Initialized
INFO - 2023-09-24 12:22:26 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-24 12:22:26 --> Controller Class Initialized
INFO - 2023-09-24 12:22:27 --> Config Class Initialized
INFO - 2023-09-24 12:22:27 --> Hooks Class Initialized
DEBUG - 2023-09-24 12:22:27 --> UTF-8 Support Enabled
INFO - 2023-09-24 12:22:27 --> Utf8 Class Initialized
INFO - 2023-09-24 12:22:27 --> URI Class Initialized
INFO - 2023-09-24 12:22:27 --> Router Class Initialized
INFO - 2023-09-24 12:22:27 --> Output Class Initialized
INFO - 2023-09-24 12:22:27 --> Security Class Initialized
DEBUG - 2023-09-24 12:22:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-24 12:22:27 --> Input Class Initialized
INFO - 2023-09-24 12:22:27 --> Language Class Initialized
INFO - 2023-09-24 12:22:27 --> Language Class Initialized
INFO - 2023-09-24 12:22:27 --> Config Class Initialized
INFO - 2023-09-24 12:22:27 --> Loader Class Initialized
INFO - 2023-09-24 12:22:27 --> Helper loaded: url_helper
INFO - 2023-09-24 12:22:27 --> Helper loaded: file_helper
INFO - 2023-09-24 12:22:27 --> Helper loaded: form_helper
INFO - 2023-09-24 12:22:27 --> Helper loaded: my_helper
INFO - 2023-09-24 12:22:27 --> Database Driver Class Initialized
INFO - 2023-09-24 12:22:27 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-24 12:22:27 --> Controller Class Initialized
INFO - 2023-09-24 12:22:27 --> Final output sent to browser
DEBUG - 2023-09-24 12:22:27 --> Total execution time: 0.0295
INFO - 2023-09-24 12:22:37 --> Config Class Initialized
INFO - 2023-09-24 12:22:37 --> Hooks Class Initialized
DEBUG - 2023-09-24 12:22:37 --> UTF-8 Support Enabled
INFO - 2023-09-24 12:22:37 --> Utf8 Class Initialized
INFO - 2023-09-24 12:22:37 --> URI Class Initialized
INFO - 2023-09-24 12:22:37 --> Router Class Initialized
INFO - 2023-09-24 12:22:37 --> Output Class Initialized
INFO - 2023-09-24 12:22:37 --> Security Class Initialized
DEBUG - 2023-09-24 12:22:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-24 12:22:37 --> Input Class Initialized
INFO - 2023-09-24 12:22:37 --> Language Class Initialized
INFO - 2023-09-24 12:22:37 --> Language Class Initialized
INFO - 2023-09-24 12:22:37 --> Config Class Initialized
INFO - 2023-09-24 12:22:37 --> Loader Class Initialized
INFO - 2023-09-24 12:22:37 --> Helper loaded: url_helper
INFO - 2023-09-24 12:22:37 --> Helper loaded: file_helper
INFO - 2023-09-24 12:22:37 --> Helper loaded: form_helper
INFO - 2023-09-24 12:22:37 --> Helper loaded: my_helper
INFO - 2023-09-24 12:22:37 --> Database Driver Class Initialized
INFO - 2023-09-24 12:22:37 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-24 12:22:37 --> Controller Class Initialized
INFO - 2023-09-24 12:22:37 --> Final output sent to browser
DEBUG - 2023-09-24 12:22:37 --> Total execution time: 0.0428
INFO - 2023-09-24 12:22:37 --> Config Class Initialized
INFO - 2023-09-24 12:22:37 --> Hooks Class Initialized
DEBUG - 2023-09-24 12:22:37 --> UTF-8 Support Enabled
INFO - 2023-09-24 12:22:37 --> Utf8 Class Initialized
INFO - 2023-09-24 12:22:37 --> URI Class Initialized
INFO - 2023-09-24 12:22:37 --> Router Class Initialized
INFO - 2023-09-24 12:22:37 --> Output Class Initialized
INFO - 2023-09-24 12:22:37 --> Security Class Initialized
DEBUG - 2023-09-24 12:22:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-24 12:22:37 --> Input Class Initialized
INFO - 2023-09-24 12:22:37 --> Language Class Initialized
INFO - 2023-09-24 12:22:37 --> Language Class Initialized
INFO - 2023-09-24 12:22:37 --> Config Class Initialized
INFO - 2023-09-24 12:22:37 --> Loader Class Initialized
INFO - 2023-09-24 12:22:37 --> Helper loaded: url_helper
INFO - 2023-09-24 12:22:37 --> Helper loaded: file_helper
INFO - 2023-09-24 12:22:37 --> Helper loaded: form_helper
INFO - 2023-09-24 12:22:37 --> Helper loaded: my_helper
INFO - 2023-09-24 12:22:37 --> Database Driver Class Initialized
INFO - 2023-09-24 12:22:37 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-24 12:22:37 --> Controller Class Initialized
INFO - 2023-09-24 12:22:38 --> Config Class Initialized
INFO - 2023-09-24 12:22:38 --> Hooks Class Initialized
DEBUG - 2023-09-24 12:22:38 --> UTF-8 Support Enabled
INFO - 2023-09-24 12:22:38 --> Utf8 Class Initialized
INFO - 2023-09-24 12:22:38 --> URI Class Initialized
INFO - 2023-09-24 12:22:38 --> Router Class Initialized
INFO - 2023-09-24 12:22:38 --> Output Class Initialized
INFO - 2023-09-24 12:22:38 --> Security Class Initialized
DEBUG - 2023-09-24 12:22:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-24 12:22:38 --> Input Class Initialized
INFO - 2023-09-24 12:22:38 --> Language Class Initialized
INFO - 2023-09-24 12:22:38 --> Language Class Initialized
INFO - 2023-09-24 12:22:38 --> Config Class Initialized
INFO - 2023-09-24 12:22:38 --> Loader Class Initialized
INFO - 2023-09-24 12:22:38 --> Helper loaded: url_helper
INFO - 2023-09-24 12:22:38 --> Helper loaded: file_helper
INFO - 2023-09-24 12:22:38 --> Helper loaded: form_helper
INFO - 2023-09-24 12:22:38 --> Helper loaded: my_helper
INFO - 2023-09-24 12:22:38 --> Database Driver Class Initialized
INFO - 2023-09-24 12:22:38 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-24 12:22:38 --> Controller Class Initialized
INFO - 2023-09-24 12:22:38 --> Final output sent to browser
DEBUG - 2023-09-24 12:22:38 --> Total execution time: 0.0323
INFO - 2023-09-24 12:22:56 --> Config Class Initialized
INFO - 2023-09-24 12:22:56 --> Hooks Class Initialized
DEBUG - 2023-09-24 12:22:56 --> UTF-8 Support Enabled
INFO - 2023-09-24 12:22:56 --> Utf8 Class Initialized
INFO - 2023-09-24 12:22:56 --> URI Class Initialized
INFO - 2023-09-24 12:22:56 --> Router Class Initialized
INFO - 2023-09-24 12:22:56 --> Output Class Initialized
INFO - 2023-09-24 12:22:56 --> Security Class Initialized
DEBUG - 2023-09-24 12:22:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-24 12:22:56 --> Input Class Initialized
INFO - 2023-09-24 12:22:56 --> Language Class Initialized
INFO - 2023-09-24 12:22:56 --> Language Class Initialized
INFO - 2023-09-24 12:22:56 --> Config Class Initialized
INFO - 2023-09-24 12:22:56 --> Loader Class Initialized
INFO - 2023-09-24 12:22:56 --> Helper loaded: url_helper
INFO - 2023-09-24 12:22:56 --> Helper loaded: file_helper
INFO - 2023-09-24 12:22:56 --> Helper loaded: form_helper
INFO - 2023-09-24 12:22:56 --> Helper loaded: my_helper
INFO - 2023-09-24 12:22:56 --> Database Driver Class Initialized
INFO - 2023-09-24 12:22:56 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-24 12:22:56 --> Controller Class Initialized
INFO - 2023-09-24 12:22:56 --> Final output sent to browser
DEBUG - 2023-09-24 12:22:56 --> Total execution time: 0.0310
INFO - 2023-09-24 12:22:56 --> Config Class Initialized
INFO - 2023-09-24 12:22:56 --> Hooks Class Initialized
DEBUG - 2023-09-24 12:22:56 --> UTF-8 Support Enabled
INFO - 2023-09-24 12:22:56 --> Utf8 Class Initialized
INFO - 2023-09-24 12:22:56 --> URI Class Initialized
INFO - 2023-09-24 12:22:56 --> Router Class Initialized
INFO - 2023-09-24 12:22:56 --> Output Class Initialized
INFO - 2023-09-24 12:22:56 --> Security Class Initialized
DEBUG - 2023-09-24 12:22:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-24 12:22:56 --> Input Class Initialized
INFO - 2023-09-24 12:22:56 --> Language Class Initialized
INFO - 2023-09-24 12:22:56 --> Language Class Initialized
INFO - 2023-09-24 12:22:56 --> Config Class Initialized
INFO - 2023-09-24 12:22:56 --> Loader Class Initialized
INFO - 2023-09-24 12:22:56 --> Helper loaded: url_helper
INFO - 2023-09-24 12:22:56 --> Helper loaded: file_helper
INFO - 2023-09-24 12:22:56 --> Helper loaded: form_helper
INFO - 2023-09-24 12:22:56 --> Helper loaded: my_helper
INFO - 2023-09-24 12:22:56 --> Database Driver Class Initialized
INFO - 2023-09-24 12:22:56 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-24 12:22:56 --> Controller Class Initialized
INFO - 2023-09-24 12:22:57 --> Config Class Initialized
INFO - 2023-09-24 12:22:57 --> Hooks Class Initialized
DEBUG - 2023-09-24 12:22:57 --> UTF-8 Support Enabled
INFO - 2023-09-24 12:22:57 --> Utf8 Class Initialized
INFO - 2023-09-24 12:22:57 --> URI Class Initialized
INFO - 2023-09-24 12:22:57 --> Router Class Initialized
INFO - 2023-09-24 12:22:57 --> Output Class Initialized
INFO - 2023-09-24 12:22:57 --> Security Class Initialized
DEBUG - 2023-09-24 12:22:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-24 12:22:57 --> Input Class Initialized
INFO - 2023-09-24 12:22:57 --> Language Class Initialized
INFO - 2023-09-24 12:22:57 --> Language Class Initialized
INFO - 2023-09-24 12:22:57 --> Config Class Initialized
INFO - 2023-09-24 12:22:57 --> Loader Class Initialized
INFO - 2023-09-24 12:22:57 --> Helper loaded: url_helper
INFO - 2023-09-24 12:22:57 --> Helper loaded: file_helper
INFO - 2023-09-24 12:22:57 --> Helper loaded: form_helper
INFO - 2023-09-24 12:22:57 --> Helper loaded: my_helper
INFO - 2023-09-24 12:22:57 --> Database Driver Class Initialized
INFO - 2023-09-24 12:22:57 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-24 12:22:57 --> Controller Class Initialized
INFO - 2023-09-24 12:22:57 --> Final output sent to browser
DEBUG - 2023-09-24 12:22:57 --> Total execution time: 0.0294
INFO - 2023-09-24 12:23:14 --> Config Class Initialized
INFO - 2023-09-24 12:23:14 --> Hooks Class Initialized
DEBUG - 2023-09-24 12:23:14 --> UTF-8 Support Enabled
INFO - 2023-09-24 12:23:14 --> Utf8 Class Initialized
INFO - 2023-09-24 12:23:14 --> URI Class Initialized
INFO - 2023-09-24 12:23:14 --> Router Class Initialized
INFO - 2023-09-24 12:23:14 --> Output Class Initialized
INFO - 2023-09-24 12:23:14 --> Security Class Initialized
DEBUG - 2023-09-24 12:23:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-24 12:23:14 --> Input Class Initialized
INFO - 2023-09-24 12:23:14 --> Language Class Initialized
INFO - 2023-09-24 12:23:14 --> Language Class Initialized
INFO - 2023-09-24 12:23:14 --> Config Class Initialized
INFO - 2023-09-24 12:23:14 --> Loader Class Initialized
INFO - 2023-09-24 12:23:14 --> Helper loaded: url_helper
INFO - 2023-09-24 12:23:14 --> Helper loaded: file_helper
INFO - 2023-09-24 12:23:14 --> Helper loaded: form_helper
INFO - 2023-09-24 12:23:14 --> Helper loaded: my_helper
INFO - 2023-09-24 12:23:14 --> Database Driver Class Initialized
INFO - 2023-09-24 12:23:14 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-24 12:23:14 --> Controller Class Initialized
INFO - 2023-09-24 12:23:14 --> Final output sent to browser
DEBUG - 2023-09-24 12:23:14 --> Total execution time: 0.0943
INFO - 2023-09-24 12:23:14 --> Config Class Initialized
INFO - 2023-09-24 12:23:14 --> Hooks Class Initialized
DEBUG - 2023-09-24 12:23:14 --> UTF-8 Support Enabled
INFO - 2023-09-24 12:23:14 --> Utf8 Class Initialized
INFO - 2023-09-24 12:23:14 --> URI Class Initialized
INFO - 2023-09-24 12:23:14 --> Router Class Initialized
INFO - 2023-09-24 12:23:14 --> Output Class Initialized
INFO - 2023-09-24 12:23:14 --> Security Class Initialized
DEBUG - 2023-09-24 12:23:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-24 12:23:14 --> Input Class Initialized
INFO - 2023-09-24 12:23:14 --> Language Class Initialized
INFO - 2023-09-24 12:23:14 --> Language Class Initialized
INFO - 2023-09-24 12:23:14 --> Config Class Initialized
INFO - 2023-09-24 12:23:14 --> Loader Class Initialized
INFO - 2023-09-24 12:23:14 --> Helper loaded: url_helper
INFO - 2023-09-24 12:23:14 --> Helper loaded: file_helper
INFO - 2023-09-24 12:23:14 --> Helper loaded: form_helper
INFO - 2023-09-24 12:23:14 --> Helper loaded: my_helper
INFO - 2023-09-24 12:23:14 --> Database Driver Class Initialized
INFO - 2023-09-24 12:23:14 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-24 12:23:14 --> Controller Class Initialized
INFO - 2023-09-24 12:23:16 --> Config Class Initialized
INFO - 2023-09-24 12:23:16 --> Hooks Class Initialized
DEBUG - 2023-09-24 12:23:16 --> UTF-8 Support Enabled
INFO - 2023-09-24 12:23:16 --> Utf8 Class Initialized
INFO - 2023-09-24 12:23:16 --> URI Class Initialized
INFO - 2023-09-24 12:23:16 --> Router Class Initialized
INFO - 2023-09-24 12:23:16 --> Output Class Initialized
INFO - 2023-09-24 12:23:16 --> Security Class Initialized
DEBUG - 2023-09-24 12:23:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-24 12:23:16 --> Input Class Initialized
INFO - 2023-09-24 12:23:16 --> Language Class Initialized
INFO - 2023-09-24 12:23:16 --> Language Class Initialized
INFO - 2023-09-24 12:23:16 --> Config Class Initialized
INFO - 2023-09-24 12:23:16 --> Loader Class Initialized
INFO - 2023-09-24 12:23:16 --> Helper loaded: url_helper
INFO - 2023-09-24 12:23:16 --> Helper loaded: file_helper
INFO - 2023-09-24 12:23:16 --> Helper loaded: form_helper
INFO - 2023-09-24 12:23:16 --> Helper loaded: my_helper
INFO - 2023-09-24 12:23:16 --> Database Driver Class Initialized
INFO - 2023-09-24 12:23:16 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-24 12:23:16 --> Controller Class Initialized
INFO - 2023-09-24 12:23:16 --> Final output sent to browser
DEBUG - 2023-09-24 12:23:16 --> Total execution time: 0.0320
INFO - 2023-09-24 12:23:27 --> Config Class Initialized
INFO - 2023-09-24 12:23:27 --> Hooks Class Initialized
DEBUG - 2023-09-24 12:23:27 --> UTF-8 Support Enabled
INFO - 2023-09-24 12:23:27 --> Utf8 Class Initialized
INFO - 2023-09-24 12:23:27 --> URI Class Initialized
INFO - 2023-09-24 12:23:27 --> Router Class Initialized
INFO - 2023-09-24 12:23:27 --> Output Class Initialized
INFO - 2023-09-24 12:23:27 --> Security Class Initialized
DEBUG - 2023-09-24 12:23:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-24 12:23:27 --> Input Class Initialized
INFO - 2023-09-24 12:23:27 --> Language Class Initialized
INFO - 2023-09-24 12:23:27 --> Language Class Initialized
INFO - 2023-09-24 12:23:27 --> Config Class Initialized
INFO - 2023-09-24 12:23:27 --> Loader Class Initialized
INFO - 2023-09-24 12:23:27 --> Helper loaded: url_helper
INFO - 2023-09-24 12:23:27 --> Helper loaded: file_helper
INFO - 2023-09-24 12:23:27 --> Helper loaded: form_helper
INFO - 2023-09-24 12:23:27 --> Helper loaded: my_helper
INFO - 2023-09-24 12:23:27 --> Database Driver Class Initialized
INFO - 2023-09-24 12:23:27 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-24 12:23:27 --> Controller Class Initialized
INFO - 2023-09-24 12:23:27 --> Final output sent to browser
DEBUG - 2023-09-24 12:23:27 --> Total execution time: 0.0425
INFO - 2023-09-24 12:23:27 --> Config Class Initialized
INFO - 2023-09-24 12:23:27 --> Hooks Class Initialized
DEBUG - 2023-09-24 12:23:27 --> UTF-8 Support Enabled
INFO - 2023-09-24 12:23:27 --> Utf8 Class Initialized
INFO - 2023-09-24 12:23:27 --> URI Class Initialized
INFO - 2023-09-24 12:23:27 --> Router Class Initialized
INFO - 2023-09-24 12:23:27 --> Output Class Initialized
INFO - 2023-09-24 12:23:27 --> Security Class Initialized
DEBUG - 2023-09-24 12:23:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-24 12:23:27 --> Input Class Initialized
INFO - 2023-09-24 12:23:27 --> Language Class Initialized
INFO - 2023-09-24 12:23:27 --> Language Class Initialized
INFO - 2023-09-24 12:23:27 --> Config Class Initialized
INFO - 2023-09-24 12:23:27 --> Loader Class Initialized
INFO - 2023-09-24 12:23:27 --> Helper loaded: url_helper
INFO - 2023-09-24 12:23:27 --> Helper loaded: file_helper
INFO - 2023-09-24 12:23:27 --> Helper loaded: form_helper
INFO - 2023-09-24 12:23:27 --> Helper loaded: my_helper
INFO - 2023-09-24 12:23:27 --> Database Driver Class Initialized
INFO - 2023-09-24 12:23:27 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-24 12:23:27 --> Controller Class Initialized
INFO - 2023-09-24 12:23:29 --> Config Class Initialized
INFO - 2023-09-24 12:23:29 --> Hooks Class Initialized
DEBUG - 2023-09-24 12:23:29 --> UTF-8 Support Enabled
INFO - 2023-09-24 12:23:29 --> Utf8 Class Initialized
INFO - 2023-09-24 12:23:29 --> URI Class Initialized
INFO - 2023-09-24 12:23:29 --> Router Class Initialized
INFO - 2023-09-24 12:23:29 --> Output Class Initialized
INFO - 2023-09-24 12:23:29 --> Security Class Initialized
DEBUG - 2023-09-24 12:23:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-24 12:23:29 --> Input Class Initialized
INFO - 2023-09-24 12:23:29 --> Language Class Initialized
INFO - 2023-09-24 12:23:29 --> Language Class Initialized
INFO - 2023-09-24 12:23:29 --> Config Class Initialized
INFO - 2023-09-24 12:23:29 --> Loader Class Initialized
INFO - 2023-09-24 12:23:29 --> Helper loaded: url_helper
INFO - 2023-09-24 12:23:29 --> Helper loaded: file_helper
INFO - 2023-09-24 12:23:29 --> Helper loaded: form_helper
INFO - 2023-09-24 12:23:29 --> Helper loaded: my_helper
INFO - 2023-09-24 12:23:29 --> Database Driver Class Initialized
INFO - 2023-09-24 12:23:29 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-24 12:23:29 --> Controller Class Initialized
INFO - 2023-09-24 12:23:29 --> Final output sent to browser
DEBUG - 2023-09-24 12:23:29 --> Total execution time: 0.0374
INFO - 2023-09-24 12:23:38 --> Config Class Initialized
INFO - 2023-09-24 12:23:38 --> Hooks Class Initialized
DEBUG - 2023-09-24 12:23:38 --> UTF-8 Support Enabled
INFO - 2023-09-24 12:23:38 --> Utf8 Class Initialized
INFO - 2023-09-24 12:23:38 --> URI Class Initialized
INFO - 2023-09-24 12:23:38 --> Router Class Initialized
INFO - 2023-09-24 12:23:38 --> Output Class Initialized
INFO - 2023-09-24 12:23:38 --> Security Class Initialized
DEBUG - 2023-09-24 12:23:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-24 12:23:38 --> Input Class Initialized
INFO - 2023-09-24 12:23:38 --> Language Class Initialized
INFO - 2023-09-24 12:23:38 --> Language Class Initialized
INFO - 2023-09-24 12:23:38 --> Config Class Initialized
INFO - 2023-09-24 12:23:38 --> Loader Class Initialized
INFO - 2023-09-24 12:23:38 --> Helper loaded: url_helper
INFO - 2023-09-24 12:23:38 --> Helper loaded: file_helper
INFO - 2023-09-24 12:23:38 --> Helper loaded: form_helper
INFO - 2023-09-24 12:23:38 --> Helper loaded: my_helper
INFO - 2023-09-24 12:23:38 --> Database Driver Class Initialized
INFO - 2023-09-24 12:23:38 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-24 12:23:38 --> Controller Class Initialized
INFO - 2023-09-24 12:23:39 --> Final output sent to browser
DEBUG - 2023-09-24 12:23:39 --> Total execution time: 0.0733
INFO - 2023-09-24 12:23:39 --> Config Class Initialized
INFO - 2023-09-24 12:23:39 --> Hooks Class Initialized
DEBUG - 2023-09-24 12:23:39 --> UTF-8 Support Enabled
INFO - 2023-09-24 12:23:39 --> Utf8 Class Initialized
INFO - 2023-09-24 12:23:39 --> URI Class Initialized
INFO - 2023-09-24 12:23:39 --> Router Class Initialized
INFO - 2023-09-24 12:23:39 --> Output Class Initialized
INFO - 2023-09-24 12:23:39 --> Security Class Initialized
DEBUG - 2023-09-24 12:23:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-24 12:23:39 --> Input Class Initialized
INFO - 2023-09-24 12:23:39 --> Language Class Initialized
INFO - 2023-09-24 12:23:39 --> Language Class Initialized
INFO - 2023-09-24 12:23:39 --> Config Class Initialized
INFO - 2023-09-24 12:23:39 --> Loader Class Initialized
INFO - 2023-09-24 12:23:39 --> Helper loaded: url_helper
INFO - 2023-09-24 12:23:39 --> Helper loaded: file_helper
INFO - 2023-09-24 12:23:39 --> Helper loaded: form_helper
INFO - 2023-09-24 12:23:39 --> Helper loaded: my_helper
INFO - 2023-09-24 12:23:39 --> Database Driver Class Initialized
INFO - 2023-09-24 12:23:39 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-24 12:23:39 --> Controller Class Initialized
INFO - 2023-09-24 12:23:41 --> Config Class Initialized
INFO - 2023-09-24 12:23:41 --> Hooks Class Initialized
DEBUG - 2023-09-24 12:23:41 --> UTF-8 Support Enabled
INFO - 2023-09-24 12:23:41 --> Utf8 Class Initialized
INFO - 2023-09-24 12:23:41 --> URI Class Initialized
INFO - 2023-09-24 12:23:41 --> Router Class Initialized
INFO - 2023-09-24 12:23:41 --> Output Class Initialized
INFO - 2023-09-24 12:23:41 --> Security Class Initialized
DEBUG - 2023-09-24 12:23:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-24 12:23:41 --> Input Class Initialized
INFO - 2023-09-24 12:23:41 --> Language Class Initialized
INFO - 2023-09-24 12:23:41 --> Language Class Initialized
INFO - 2023-09-24 12:23:41 --> Config Class Initialized
INFO - 2023-09-24 12:23:41 --> Loader Class Initialized
INFO - 2023-09-24 12:23:41 --> Helper loaded: url_helper
INFO - 2023-09-24 12:23:41 --> Helper loaded: file_helper
INFO - 2023-09-24 12:23:41 --> Helper loaded: form_helper
INFO - 2023-09-24 12:23:41 --> Helper loaded: my_helper
INFO - 2023-09-24 12:23:41 --> Database Driver Class Initialized
INFO - 2023-09-24 12:23:41 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-24 12:23:41 --> Controller Class Initialized
INFO - 2023-09-24 12:23:41 --> Final output sent to browser
DEBUG - 2023-09-24 12:23:41 --> Total execution time: 0.0307
INFO - 2023-09-24 12:28:48 --> Config Class Initialized
INFO - 2023-09-24 12:28:48 --> Hooks Class Initialized
DEBUG - 2023-09-24 12:28:48 --> UTF-8 Support Enabled
INFO - 2023-09-24 12:28:48 --> Utf8 Class Initialized
INFO - 2023-09-24 12:28:48 --> URI Class Initialized
INFO - 2023-09-24 12:28:48 --> Router Class Initialized
INFO - 2023-09-24 12:28:48 --> Output Class Initialized
INFO - 2023-09-24 12:28:48 --> Security Class Initialized
DEBUG - 2023-09-24 12:28:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-24 12:28:48 --> Input Class Initialized
INFO - 2023-09-24 12:28:48 --> Language Class Initialized
INFO - 2023-09-24 12:28:48 --> Language Class Initialized
INFO - 2023-09-24 12:28:48 --> Config Class Initialized
INFO - 2023-09-24 12:28:48 --> Loader Class Initialized
INFO - 2023-09-24 12:28:48 --> Helper loaded: url_helper
INFO - 2023-09-24 12:28:48 --> Helper loaded: file_helper
INFO - 2023-09-24 12:28:48 --> Helper loaded: form_helper
INFO - 2023-09-24 12:28:48 --> Helper loaded: my_helper
INFO - 2023-09-24 12:28:48 --> Database Driver Class Initialized
INFO - 2023-09-24 12:28:48 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-24 12:28:48 --> Controller Class Initialized
INFO - 2023-09-24 12:28:48 --> Final output sent to browser
DEBUG - 2023-09-24 12:28:48 --> Total execution time: 0.0349
INFO - 2023-09-24 12:28:57 --> Config Class Initialized
INFO - 2023-09-24 12:28:57 --> Hooks Class Initialized
DEBUG - 2023-09-24 12:28:57 --> UTF-8 Support Enabled
INFO - 2023-09-24 12:28:57 --> Utf8 Class Initialized
INFO - 2023-09-24 12:28:57 --> URI Class Initialized
INFO - 2023-09-24 12:28:57 --> Router Class Initialized
INFO - 2023-09-24 12:28:57 --> Output Class Initialized
INFO - 2023-09-24 12:28:57 --> Security Class Initialized
DEBUG - 2023-09-24 12:28:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-24 12:28:57 --> Input Class Initialized
INFO - 2023-09-24 12:28:57 --> Language Class Initialized
INFO - 2023-09-24 12:28:57 --> Language Class Initialized
INFO - 2023-09-24 12:28:57 --> Config Class Initialized
INFO - 2023-09-24 12:28:57 --> Loader Class Initialized
INFO - 2023-09-24 12:28:57 --> Helper loaded: url_helper
INFO - 2023-09-24 12:28:57 --> Helper loaded: file_helper
INFO - 2023-09-24 12:28:57 --> Helper loaded: form_helper
INFO - 2023-09-24 12:28:57 --> Helper loaded: my_helper
INFO - 2023-09-24 12:28:57 --> Database Driver Class Initialized
INFO - 2023-09-24 12:28:57 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-24 12:28:57 --> Controller Class Initialized
INFO - 2023-09-24 12:28:57 --> Final output sent to browser
DEBUG - 2023-09-24 12:28:57 --> Total execution time: 0.0321
INFO - 2023-09-24 12:28:57 --> Config Class Initialized
INFO - 2023-09-24 12:28:57 --> Hooks Class Initialized
DEBUG - 2023-09-24 12:28:57 --> UTF-8 Support Enabled
INFO - 2023-09-24 12:28:57 --> Utf8 Class Initialized
INFO - 2023-09-24 12:28:57 --> URI Class Initialized
INFO - 2023-09-24 12:28:57 --> Router Class Initialized
INFO - 2023-09-24 12:28:57 --> Output Class Initialized
INFO - 2023-09-24 12:28:57 --> Security Class Initialized
DEBUG - 2023-09-24 12:28:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-24 12:28:57 --> Input Class Initialized
INFO - 2023-09-24 12:28:57 --> Language Class Initialized
INFO - 2023-09-24 12:28:57 --> Language Class Initialized
INFO - 2023-09-24 12:28:57 --> Config Class Initialized
INFO - 2023-09-24 12:28:57 --> Loader Class Initialized
INFO - 2023-09-24 12:28:57 --> Helper loaded: url_helper
INFO - 2023-09-24 12:28:57 --> Helper loaded: file_helper
INFO - 2023-09-24 12:28:57 --> Helper loaded: form_helper
INFO - 2023-09-24 12:28:57 --> Helper loaded: my_helper
INFO - 2023-09-24 12:28:57 --> Database Driver Class Initialized
INFO - 2023-09-24 12:28:57 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-24 12:28:57 --> Controller Class Initialized
INFO - 2023-09-24 12:28:58 --> Config Class Initialized
INFO - 2023-09-24 12:28:58 --> Hooks Class Initialized
DEBUG - 2023-09-24 12:28:58 --> UTF-8 Support Enabled
INFO - 2023-09-24 12:28:58 --> Utf8 Class Initialized
INFO - 2023-09-24 12:28:58 --> URI Class Initialized
INFO - 2023-09-24 12:28:58 --> Router Class Initialized
INFO - 2023-09-24 12:28:58 --> Output Class Initialized
INFO - 2023-09-24 12:28:58 --> Security Class Initialized
DEBUG - 2023-09-24 12:28:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-24 12:28:58 --> Input Class Initialized
INFO - 2023-09-24 12:28:58 --> Language Class Initialized
INFO - 2023-09-24 12:28:58 --> Language Class Initialized
INFO - 2023-09-24 12:28:58 --> Config Class Initialized
INFO - 2023-09-24 12:28:58 --> Loader Class Initialized
INFO - 2023-09-24 12:28:58 --> Helper loaded: url_helper
INFO - 2023-09-24 12:28:58 --> Helper loaded: file_helper
INFO - 2023-09-24 12:28:58 --> Helper loaded: form_helper
INFO - 2023-09-24 12:28:58 --> Helper loaded: my_helper
INFO - 2023-09-24 12:28:58 --> Database Driver Class Initialized
INFO - 2023-09-24 12:28:58 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-24 12:28:58 --> Controller Class Initialized
INFO - 2023-09-24 12:28:58 --> Final output sent to browser
DEBUG - 2023-09-24 12:28:58 --> Total execution time: 0.0313
INFO - 2023-09-24 12:29:07 --> Config Class Initialized
INFO - 2023-09-24 12:29:07 --> Hooks Class Initialized
DEBUG - 2023-09-24 12:29:07 --> UTF-8 Support Enabled
INFO - 2023-09-24 12:29:07 --> Utf8 Class Initialized
INFO - 2023-09-24 12:29:07 --> URI Class Initialized
INFO - 2023-09-24 12:29:07 --> Router Class Initialized
INFO - 2023-09-24 12:29:07 --> Output Class Initialized
INFO - 2023-09-24 12:29:07 --> Security Class Initialized
DEBUG - 2023-09-24 12:29:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-24 12:29:07 --> Input Class Initialized
INFO - 2023-09-24 12:29:07 --> Language Class Initialized
INFO - 2023-09-24 12:29:07 --> Language Class Initialized
INFO - 2023-09-24 12:29:07 --> Config Class Initialized
INFO - 2023-09-24 12:29:07 --> Loader Class Initialized
INFO - 2023-09-24 12:29:07 --> Helper loaded: url_helper
INFO - 2023-09-24 12:29:07 --> Helper loaded: file_helper
INFO - 2023-09-24 12:29:07 --> Helper loaded: form_helper
INFO - 2023-09-24 12:29:07 --> Helper loaded: my_helper
INFO - 2023-09-24 12:29:07 --> Database Driver Class Initialized
INFO - 2023-09-24 12:29:07 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-24 12:29:07 --> Controller Class Initialized
INFO - 2023-09-24 12:29:07 --> Final output sent to browser
DEBUG - 2023-09-24 12:29:07 --> Total execution time: 0.0341
INFO - 2023-09-24 12:29:07 --> Config Class Initialized
INFO - 2023-09-24 12:29:07 --> Hooks Class Initialized
DEBUG - 2023-09-24 12:29:07 --> UTF-8 Support Enabled
INFO - 2023-09-24 12:29:07 --> Utf8 Class Initialized
INFO - 2023-09-24 12:29:07 --> URI Class Initialized
INFO - 2023-09-24 12:29:07 --> Router Class Initialized
INFO - 2023-09-24 12:29:07 --> Output Class Initialized
INFO - 2023-09-24 12:29:07 --> Security Class Initialized
DEBUG - 2023-09-24 12:29:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-24 12:29:07 --> Input Class Initialized
INFO - 2023-09-24 12:29:07 --> Language Class Initialized
INFO - 2023-09-24 12:29:07 --> Language Class Initialized
INFO - 2023-09-24 12:29:07 --> Config Class Initialized
INFO - 2023-09-24 12:29:07 --> Loader Class Initialized
INFO - 2023-09-24 12:29:07 --> Helper loaded: url_helper
INFO - 2023-09-24 12:29:07 --> Helper loaded: file_helper
INFO - 2023-09-24 12:29:07 --> Helper loaded: form_helper
INFO - 2023-09-24 12:29:07 --> Helper loaded: my_helper
INFO - 2023-09-24 12:29:07 --> Database Driver Class Initialized
INFO - 2023-09-24 12:29:07 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-24 12:29:07 --> Controller Class Initialized
INFO - 2023-09-24 12:29:08 --> Config Class Initialized
INFO - 2023-09-24 12:29:08 --> Hooks Class Initialized
DEBUG - 2023-09-24 12:29:08 --> UTF-8 Support Enabled
INFO - 2023-09-24 12:29:08 --> Utf8 Class Initialized
INFO - 2023-09-24 12:29:08 --> URI Class Initialized
INFO - 2023-09-24 12:29:08 --> Router Class Initialized
INFO - 2023-09-24 12:29:08 --> Output Class Initialized
INFO - 2023-09-24 12:29:08 --> Security Class Initialized
DEBUG - 2023-09-24 12:29:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-24 12:29:08 --> Input Class Initialized
INFO - 2023-09-24 12:29:08 --> Language Class Initialized
INFO - 2023-09-24 12:29:08 --> Language Class Initialized
INFO - 2023-09-24 12:29:08 --> Config Class Initialized
INFO - 2023-09-24 12:29:08 --> Loader Class Initialized
INFO - 2023-09-24 12:29:08 --> Helper loaded: url_helper
INFO - 2023-09-24 12:29:08 --> Helper loaded: file_helper
INFO - 2023-09-24 12:29:08 --> Helper loaded: form_helper
INFO - 2023-09-24 12:29:08 --> Helper loaded: my_helper
INFO - 2023-09-24 12:29:08 --> Database Driver Class Initialized
INFO - 2023-09-24 12:29:08 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-24 12:29:08 --> Controller Class Initialized
INFO - 2023-09-24 12:29:08 --> Final output sent to browser
DEBUG - 2023-09-24 12:29:08 --> Total execution time: 0.0303
INFO - 2023-09-24 12:29:17 --> Config Class Initialized
INFO - 2023-09-24 12:29:17 --> Hooks Class Initialized
DEBUG - 2023-09-24 12:29:17 --> UTF-8 Support Enabled
INFO - 2023-09-24 12:29:17 --> Utf8 Class Initialized
INFO - 2023-09-24 12:29:17 --> URI Class Initialized
INFO - 2023-09-24 12:29:17 --> Router Class Initialized
INFO - 2023-09-24 12:29:17 --> Output Class Initialized
INFO - 2023-09-24 12:29:17 --> Security Class Initialized
DEBUG - 2023-09-24 12:29:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-24 12:29:17 --> Input Class Initialized
INFO - 2023-09-24 12:29:17 --> Language Class Initialized
INFO - 2023-09-24 12:29:17 --> Language Class Initialized
INFO - 2023-09-24 12:29:17 --> Config Class Initialized
INFO - 2023-09-24 12:29:17 --> Loader Class Initialized
INFO - 2023-09-24 12:29:17 --> Helper loaded: url_helper
INFO - 2023-09-24 12:29:17 --> Helper loaded: file_helper
INFO - 2023-09-24 12:29:17 --> Helper loaded: form_helper
INFO - 2023-09-24 12:29:17 --> Helper loaded: my_helper
INFO - 2023-09-24 12:29:17 --> Database Driver Class Initialized
INFO - 2023-09-24 12:29:17 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-24 12:29:17 --> Controller Class Initialized
INFO - 2023-09-24 12:29:17 --> Final output sent to browser
DEBUG - 2023-09-24 12:29:17 --> Total execution time: 0.0430
INFO - 2023-09-24 12:29:17 --> Config Class Initialized
INFO - 2023-09-24 12:29:17 --> Hooks Class Initialized
DEBUG - 2023-09-24 12:29:17 --> UTF-8 Support Enabled
INFO - 2023-09-24 12:29:17 --> Utf8 Class Initialized
INFO - 2023-09-24 12:29:17 --> URI Class Initialized
INFO - 2023-09-24 12:29:17 --> Router Class Initialized
INFO - 2023-09-24 12:29:17 --> Output Class Initialized
INFO - 2023-09-24 12:29:17 --> Security Class Initialized
DEBUG - 2023-09-24 12:29:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-24 12:29:17 --> Input Class Initialized
INFO - 2023-09-24 12:29:17 --> Language Class Initialized
INFO - 2023-09-24 12:29:17 --> Language Class Initialized
INFO - 2023-09-24 12:29:17 --> Config Class Initialized
INFO - 2023-09-24 12:29:17 --> Loader Class Initialized
INFO - 2023-09-24 12:29:17 --> Helper loaded: url_helper
INFO - 2023-09-24 12:29:17 --> Helper loaded: file_helper
INFO - 2023-09-24 12:29:17 --> Helper loaded: form_helper
INFO - 2023-09-24 12:29:17 --> Helper loaded: my_helper
INFO - 2023-09-24 12:29:17 --> Database Driver Class Initialized
INFO - 2023-09-24 12:29:17 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-24 12:29:17 --> Controller Class Initialized
INFO - 2023-09-24 12:29:18 --> Config Class Initialized
INFO - 2023-09-24 12:29:18 --> Hooks Class Initialized
DEBUG - 2023-09-24 12:29:18 --> UTF-8 Support Enabled
INFO - 2023-09-24 12:29:18 --> Utf8 Class Initialized
INFO - 2023-09-24 12:29:18 --> URI Class Initialized
INFO - 2023-09-24 12:29:18 --> Router Class Initialized
INFO - 2023-09-24 12:29:18 --> Output Class Initialized
INFO - 2023-09-24 12:29:18 --> Security Class Initialized
DEBUG - 2023-09-24 12:29:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-24 12:29:18 --> Input Class Initialized
INFO - 2023-09-24 12:29:18 --> Language Class Initialized
INFO - 2023-09-24 12:29:18 --> Language Class Initialized
INFO - 2023-09-24 12:29:18 --> Config Class Initialized
INFO - 2023-09-24 12:29:18 --> Loader Class Initialized
INFO - 2023-09-24 12:29:18 --> Helper loaded: url_helper
INFO - 2023-09-24 12:29:18 --> Helper loaded: file_helper
INFO - 2023-09-24 12:29:18 --> Helper loaded: form_helper
INFO - 2023-09-24 12:29:18 --> Helper loaded: my_helper
INFO - 2023-09-24 12:29:18 --> Database Driver Class Initialized
INFO - 2023-09-24 12:29:18 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-24 12:29:18 --> Controller Class Initialized
INFO - 2023-09-24 12:29:18 --> Final output sent to browser
DEBUG - 2023-09-24 12:29:18 --> Total execution time: 0.0369
INFO - 2023-09-24 12:29:26 --> Config Class Initialized
INFO - 2023-09-24 12:29:26 --> Hooks Class Initialized
DEBUG - 2023-09-24 12:29:26 --> UTF-8 Support Enabled
INFO - 2023-09-24 12:29:26 --> Utf8 Class Initialized
INFO - 2023-09-24 12:29:26 --> URI Class Initialized
INFO - 2023-09-24 12:29:26 --> Router Class Initialized
INFO - 2023-09-24 12:29:26 --> Output Class Initialized
INFO - 2023-09-24 12:29:26 --> Security Class Initialized
DEBUG - 2023-09-24 12:29:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-24 12:29:26 --> Input Class Initialized
INFO - 2023-09-24 12:29:26 --> Language Class Initialized
INFO - 2023-09-24 12:29:26 --> Language Class Initialized
INFO - 2023-09-24 12:29:26 --> Config Class Initialized
INFO - 2023-09-24 12:29:26 --> Loader Class Initialized
INFO - 2023-09-24 12:29:26 --> Helper loaded: url_helper
INFO - 2023-09-24 12:29:26 --> Helper loaded: file_helper
INFO - 2023-09-24 12:29:26 --> Helper loaded: form_helper
INFO - 2023-09-24 12:29:26 --> Helper loaded: my_helper
INFO - 2023-09-24 12:29:26 --> Database Driver Class Initialized
INFO - 2023-09-24 12:29:26 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-24 12:29:26 --> Controller Class Initialized
INFO - 2023-09-24 12:29:26 --> Final output sent to browser
DEBUG - 2023-09-24 12:29:26 --> Total execution time: 0.0449
INFO - 2023-09-24 12:29:26 --> Config Class Initialized
INFO - 2023-09-24 12:29:26 --> Hooks Class Initialized
DEBUG - 2023-09-24 12:29:26 --> UTF-8 Support Enabled
INFO - 2023-09-24 12:29:26 --> Utf8 Class Initialized
INFO - 2023-09-24 12:29:26 --> URI Class Initialized
INFO - 2023-09-24 12:29:26 --> Router Class Initialized
INFO - 2023-09-24 12:29:26 --> Output Class Initialized
INFO - 2023-09-24 12:29:26 --> Security Class Initialized
DEBUG - 2023-09-24 12:29:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-24 12:29:26 --> Input Class Initialized
INFO - 2023-09-24 12:29:26 --> Language Class Initialized
INFO - 2023-09-24 12:29:26 --> Language Class Initialized
INFO - 2023-09-24 12:29:26 --> Config Class Initialized
INFO - 2023-09-24 12:29:26 --> Loader Class Initialized
INFO - 2023-09-24 12:29:26 --> Helper loaded: url_helper
INFO - 2023-09-24 12:29:26 --> Helper loaded: file_helper
INFO - 2023-09-24 12:29:26 --> Helper loaded: form_helper
INFO - 2023-09-24 12:29:26 --> Helper loaded: my_helper
INFO - 2023-09-24 12:29:26 --> Database Driver Class Initialized
INFO - 2023-09-24 12:29:26 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-24 12:29:26 --> Controller Class Initialized
INFO - 2023-09-24 12:29:27 --> Config Class Initialized
INFO - 2023-09-24 12:29:27 --> Hooks Class Initialized
DEBUG - 2023-09-24 12:29:27 --> UTF-8 Support Enabled
INFO - 2023-09-24 12:29:27 --> Utf8 Class Initialized
INFO - 2023-09-24 12:29:27 --> URI Class Initialized
INFO - 2023-09-24 12:29:27 --> Router Class Initialized
INFO - 2023-09-24 12:29:27 --> Output Class Initialized
INFO - 2023-09-24 12:29:27 --> Security Class Initialized
DEBUG - 2023-09-24 12:29:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-24 12:29:27 --> Input Class Initialized
INFO - 2023-09-24 12:29:27 --> Language Class Initialized
INFO - 2023-09-24 12:29:27 --> Language Class Initialized
INFO - 2023-09-24 12:29:27 --> Config Class Initialized
INFO - 2023-09-24 12:29:27 --> Loader Class Initialized
INFO - 2023-09-24 12:29:27 --> Helper loaded: url_helper
INFO - 2023-09-24 12:29:27 --> Helper loaded: file_helper
INFO - 2023-09-24 12:29:27 --> Helper loaded: form_helper
INFO - 2023-09-24 12:29:27 --> Helper loaded: my_helper
INFO - 2023-09-24 12:29:27 --> Database Driver Class Initialized
INFO - 2023-09-24 12:29:27 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-24 12:29:27 --> Controller Class Initialized
INFO - 2023-09-24 12:29:27 --> Final output sent to browser
DEBUG - 2023-09-24 12:29:27 --> Total execution time: 0.0293
INFO - 2023-09-24 12:29:35 --> Config Class Initialized
INFO - 2023-09-24 12:29:35 --> Hooks Class Initialized
DEBUG - 2023-09-24 12:29:35 --> UTF-8 Support Enabled
INFO - 2023-09-24 12:29:35 --> Utf8 Class Initialized
INFO - 2023-09-24 12:29:35 --> URI Class Initialized
INFO - 2023-09-24 12:29:35 --> Router Class Initialized
INFO - 2023-09-24 12:29:35 --> Output Class Initialized
INFO - 2023-09-24 12:29:35 --> Security Class Initialized
DEBUG - 2023-09-24 12:29:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-24 12:29:35 --> Input Class Initialized
INFO - 2023-09-24 12:29:35 --> Language Class Initialized
INFO - 2023-09-24 12:29:35 --> Language Class Initialized
INFO - 2023-09-24 12:29:35 --> Config Class Initialized
INFO - 2023-09-24 12:29:35 --> Loader Class Initialized
INFO - 2023-09-24 12:29:35 --> Helper loaded: url_helper
INFO - 2023-09-24 12:29:35 --> Helper loaded: file_helper
INFO - 2023-09-24 12:29:35 --> Helper loaded: form_helper
INFO - 2023-09-24 12:29:35 --> Helper loaded: my_helper
INFO - 2023-09-24 12:29:35 --> Database Driver Class Initialized
INFO - 2023-09-24 12:29:35 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-24 12:29:35 --> Controller Class Initialized
INFO - 2023-09-24 12:29:35 --> Final output sent to browser
DEBUG - 2023-09-24 12:29:35 --> Total execution time: 0.0349
INFO - 2023-09-24 12:29:35 --> Config Class Initialized
INFO - 2023-09-24 12:29:35 --> Hooks Class Initialized
DEBUG - 2023-09-24 12:29:35 --> UTF-8 Support Enabled
INFO - 2023-09-24 12:29:35 --> Utf8 Class Initialized
INFO - 2023-09-24 12:29:35 --> URI Class Initialized
INFO - 2023-09-24 12:29:35 --> Router Class Initialized
INFO - 2023-09-24 12:29:35 --> Output Class Initialized
INFO - 2023-09-24 12:29:35 --> Security Class Initialized
DEBUG - 2023-09-24 12:29:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-24 12:29:35 --> Input Class Initialized
INFO - 2023-09-24 12:29:35 --> Language Class Initialized
INFO - 2023-09-24 12:29:35 --> Language Class Initialized
INFO - 2023-09-24 12:29:35 --> Config Class Initialized
INFO - 2023-09-24 12:29:35 --> Loader Class Initialized
INFO - 2023-09-24 12:29:35 --> Helper loaded: url_helper
INFO - 2023-09-24 12:29:35 --> Helper loaded: file_helper
INFO - 2023-09-24 12:29:35 --> Helper loaded: form_helper
INFO - 2023-09-24 12:29:35 --> Helper loaded: my_helper
INFO - 2023-09-24 12:29:35 --> Database Driver Class Initialized
INFO - 2023-09-24 12:29:35 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-24 12:29:35 --> Controller Class Initialized
INFO - 2023-09-24 12:29:36 --> Config Class Initialized
INFO - 2023-09-24 12:29:36 --> Hooks Class Initialized
DEBUG - 2023-09-24 12:29:36 --> UTF-8 Support Enabled
INFO - 2023-09-24 12:29:36 --> Utf8 Class Initialized
INFO - 2023-09-24 12:29:36 --> URI Class Initialized
INFO - 2023-09-24 12:29:36 --> Router Class Initialized
INFO - 2023-09-24 12:29:36 --> Output Class Initialized
INFO - 2023-09-24 12:29:36 --> Security Class Initialized
DEBUG - 2023-09-24 12:29:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-24 12:29:36 --> Input Class Initialized
INFO - 2023-09-24 12:29:36 --> Language Class Initialized
INFO - 2023-09-24 12:29:36 --> Language Class Initialized
INFO - 2023-09-24 12:29:36 --> Config Class Initialized
INFO - 2023-09-24 12:29:36 --> Loader Class Initialized
INFO - 2023-09-24 12:29:36 --> Helper loaded: url_helper
INFO - 2023-09-24 12:29:36 --> Helper loaded: file_helper
INFO - 2023-09-24 12:29:36 --> Helper loaded: form_helper
INFO - 2023-09-24 12:29:36 --> Helper loaded: my_helper
INFO - 2023-09-24 12:29:36 --> Database Driver Class Initialized
INFO - 2023-09-24 12:29:36 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-24 12:29:36 --> Controller Class Initialized
INFO - 2023-09-24 12:29:36 --> Final output sent to browser
DEBUG - 2023-09-24 12:29:36 --> Total execution time: 0.0309
INFO - 2023-09-24 12:29:48 --> Config Class Initialized
INFO - 2023-09-24 12:29:48 --> Hooks Class Initialized
DEBUG - 2023-09-24 12:29:48 --> UTF-8 Support Enabled
INFO - 2023-09-24 12:29:48 --> Utf8 Class Initialized
INFO - 2023-09-24 12:29:48 --> URI Class Initialized
INFO - 2023-09-24 12:29:48 --> Router Class Initialized
INFO - 2023-09-24 12:29:48 --> Output Class Initialized
INFO - 2023-09-24 12:29:48 --> Security Class Initialized
DEBUG - 2023-09-24 12:29:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-24 12:29:48 --> Input Class Initialized
INFO - 2023-09-24 12:29:48 --> Language Class Initialized
INFO - 2023-09-24 12:29:48 --> Language Class Initialized
INFO - 2023-09-24 12:29:48 --> Config Class Initialized
INFO - 2023-09-24 12:29:48 --> Loader Class Initialized
INFO - 2023-09-24 12:29:48 --> Helper loaded: url_helper
INFO - 2023-09-24 12:29:48 --> Helper loaded: file_helper
INFO - 2023-09-24 12:29:48 --> Helper loaded: form_helper
INFO - 2023-09-24 12:29:48 --> Helper loaded: my_helper
INFO - 2023-09-24 12:29:48 --> Database Driver Class Initialized
INFO - 2023-09-24 12:29:48 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-24 12:29:48 --> Controller Class Initialized
INFO - 2023-09-24 12:29:48 --> Final output sent to browser
DEBUG - 2023-09-24 12:29:48 --> Total execution time: 0.0488
INFO - 2023-09-24 12:29:49 --> Config Class Initialized
INFO - 2023-09-24 12:29:49 --> Hooks Class Initialized
DEBUG - 2023-09-24 12:29:49 --> UTF-8 Support Enabled
INFO - 2023-09-24 12:29:49 --> Utf8 Class Initialized
INFO - 2023-09-24 12:29:49 --> URI Class Initialized
INFO - 2023-09-24 12:29:49 --> Router Class Initialized
INFO - 2023-09-24 12:29:49 --> Output Class Initialized
INFO - 2023-09-24 12:29:49 --> Security Class Initialized
DEBUG - 2023-09-24 12:29:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-24 12:29:49 --> Input Class Initialized
INFO - 2023-09-24 12:29:49 --> Language Class Initialized
INFO - 2023-09-24 12:29:49 --> Language Class Initialized
INFO - 2023-09-24 12:29:49 --> Config Class Initialized
INFO - 2023-09-24 12:29:49 --> Loader Class Initialized
INFO - 2023-09-24 12:29:49 --> Helper loaded: url_helper
INFO - 2023-09-24 12:29:49 --> Helper loaded: file_helper
INFO - 2023-09-24 12:29:49 --> Helper loaded: form_helper
INFO - 2023-09-24 12:29:49 --> Helper loaded: my_helper
INFO - 2023-09-24 12:29:49 --> Database Driver Class Initialized
INFO - 2023-09-24 12:29:49 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-24 12:29:49 --> Controller Class Initialized
INFO - 2023-09-24 12:29:50 --> Config Class Initialized
INFO - 2023-09-24 12:29:50 --> Hooks Class Initialized
DEBUG - 2023-09-24 12:29:50 --> UTF-8 Support Enabled
INFO - 2023-09-24 12:29:50 --> Utf8 Class Initialized
INFO - 2023-09-24 12:29:50 --> URI Class Initialized
INFO - 2023-09-24 12:29:50 --> Router Class Initialized
INFO - 2023-09-24 12:29:50 --> Output Class Initialized
INFO - 2023-09-24 12:29:50 --> Security Class Initialized
DEBUG - 2023-09-24 12:29:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-24 12:29:50 --> Input Class Initialized
INFO - 2023-09-24 12:29:50 --> Language Class Initialized
INFO - 2023-09-24 12:29:50 --> Language Class Initialized
INFO - 2023-09-24 12:29:50 --> Config Class Initialized
INFO - 2023-09-24 12:29:50 --> Loader Class Initialized
INFO - 2023-09-24 12:29:50 --> Helper loaded: url_helper
INFO - 2023-09-24 12:29:50 --> Helper loaded: file_helper
INFO - 2023-09-24 12:29:50 --> Helper loaded: form_helper
INFO - 2023-09-24 12:29:50 --> Helper loaded: my_helper
INFO - 2023-09-24 12:29:50 --> Database Driver Class Initialized
INFO - 2023-09-24 12:29:50 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-24 12:29:50 --> Controller Class Initialized
INFO - 2023-09-24 12:29:50 --> Final output sent to browser
DEBUG - 2023-09-24 12:29:50 --> Total execution time: 0.0431
INFO - 2023-09-24 12:29:57 --> Config Class Initialized
INFO - 2023-09-24 12:29:57 --> Hooks Class Initialized
DEBUG - 2023-09-24 12:29:57 --> UTF-8 Support Enabled
INFO - 2023-09-24 12:29:57 --> Utf8 Class Initialized
INFO - 2023-09-24 12:29:57 --> URI Class Initialized
INFO - 2023-09-24 12:29:57 --> Router Class Initialized
INFO - 2023-09-24 12:29:57 --> Output Class Initialized
INFO - 2023-09-24 12:29:57 --> Security Class Initialized
DEBUG - 2023-09-24 12:29:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-24 12:29:57 --> Input Class Initialized
INFO - 2023-09-24 12:29:57 --> Language Class Initialized
INFO - 2023-09-24 12:29:57 --> Language Class Initialized
INFO - 2023-09-24 12:29:57 --> Config Class Initialized
INFO - 2023-09-24 12:29:57 --> Loader Class Initialized
INFO - 2023-09-24 12:29:57 --> Helper loaded: url_helper
INFO - 2023-09-24 12:29:57 --> Helper loaded: file_helper
INFO - 2023-09-24 12:29:57 --> Helper loaded: form_helper
INFO - 2023-09-24 12:29:57 --> Helper loaded: my_helper
INFO - 2023-09-24 12:29:57 --> Database Driver Class Initialized
INFO - 2023-09-24 12:29:57 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-24 12:29:57 --> Controller Class Initialized
INFO - 2023-09-24 12:29:58 --> Final output sent to browser
DEBUG - 2023-09-24 12:29:58 --> Total execution time: 0.0862
INFO - 2023-09-24 12:29:58 --> Config Class Initialized
INFO - 2023-09-24 12:29:58 --> Hooks Class Initialized
DEBUG - 2023-09-24 12:29:58 --> UTF-8 Support Enabled
INFO - 2023-09-24 12:29:58 --> Utf8 Class Initialized
INFO - 2023-09-24 12:29:58 --> URI Class Initialized
INFO - 2023-09-24 12:29:58 --> Router Class Initialized
INFO - 2023-09-24 12:29:58 --> Output Class Initialized
INFO - 2023-09-24 12:29:58 --> Security Class Initialized
DEBUG - 2023-09-24 12:29:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-24 12:29:58 --> Input Class Initialized
INFO - 2023-09-24 12:29:58 --> Language Class Initialized
INFO - 2023-09-24 12:29:58 --> Language Class Initialized
INFO - 2023-09-24 12:29:58 --> Config Class Initialized
INFO - 2023-09-24 12:29:58 --> Loader Class Initialized
INFO - 2023-09-24 12:29:58 --> Helper loaded: url_helper
INFO - 2023-09-24 12:29:58 --> Helper loaded: file_helper
INFO - 2023-09-24 12:29:58 --> Helper loaded: form_helper
INFO - 2023-09-24 12:29:58 --> Helper loaded: my_helper
INFO - 2023-09-24 12:29:58 --> Database Driver Class Initialized
INFO - 2023-09-24 12:29:58 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-24 12:29:58 --> Controller Class Initialized
INFO - 2023-09-24 12:29:59 --> Config Class Initialized
INFO - 2023-09-24 12:29:59 --> Hooks Class Initialized
DEBUG - 2023-09-24 12:29:59 --> UTF-8 Support Enabled
INFO - 2023-09-24 12:29:59 --> Utf8 Class Initialized
INFO - 2023-09-24 12:29:59 --> URI Class Initialized
INFO - 2023-09-24 12:29:59 --> Router Class Initialized
INFO - 2023-09-24 12:29:59 --> Output Class Initialized
INFO - 2023-09-24 12:29:59 --> Security Class Initialized
DEBUG - 2023-09-24 12:29:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-24 12:29:59 --> Input Class Initialized
INFO - 2023-09-24 12:29:59 --> Language Class Initialized
INFO - 2023-09-24 12:29:59 --> Language Class Initialized
INFO - 2023-09-24 12:29:59 --> Config Class Initialized
INFO - 2023-09-24 12:29:59 --> Loader Class Initialized
INFO - 2023-09-24 12:29:59 --> Helper loaded: url_helper
INFO - 2023-09-24 12:29:59 --> Helper loaded: file_helper
INFO - 2023-09-24 12:29:59 --> Helper loaded: form_helper
INFO - 2023-09-24 12:29:59 --> Helper loaded: my_helper
INFO - 2023-09-24 12:29:59 --> Database Driver Class Initialized
INFO - 2023-09-24 12:29:59 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-24 12:29:59 --> Controller Class Initialized
INFO - 2023-09-24 12:29:59 --> Final output sent to browser
DEBUG - 2023-09-24 12:29:59 --> Total execution time: 0.0339
INFO - 2023-09-24 12:30:09 --> Config Class Initialized
INFO - 2023-09-24 12:30:09 --> Hooks Class Initialized
DEBUG - 2023-09-24 12:30:09 --> UTF-8 Support Enabled
INFO - 2023-09-24 12:30:09 --> Utf8 Class Initialized
INFO - 2023-09-24 12:30:09 --> URI Class Initialized
INFO - 2023-09-24 12:30:09 --> Router Class Initialized
INFO - 2023-09-24 12:30:09 --> Output Class Initialized
INFO - 2023-09-24 12:30:09 --> Security Class Initialized
DEBUG - 2023-09-24 12:30:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-24 12:30:09 --> Input Class Initialized
INFO - 2023-09-24 12:30:09 --> Language Class Initialized
INFO - 2023-09-24 12:30:10 --> Language Class Initialized
INFO - 2023-09-24 12:30:10 --> Config Class Initialized
INFO - 2023-09-24 12:30:10 --> Loader Class Initialized
INFO - 2023-09-24 12:30:10 --> Helper loaded: url_helper
INFO - 2023-09-24 12:30:10 --> Helper loaded: file_helper
INFO - 2023-09-24 12:30:10 --> Helper loaded: form_helper
INFO - 2023-09-24 12:30:10 --> Helper loaded: my_helper
INFO - 2023-09-24 12:30:10 --> Database Driver Class Initialized
INFO - 2023-09-24 12:30:10 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-24 12:30:10 --> Controller Class Initialized
INFO - 2023-09-24 12:30:10 --> Final output sent to browser
DEBUG - 2023-09-24 12:30:10 --> Total execution time: 0.0995
INFO - 2023-09-24 12:30:10 --> Config Class Initialized
INFO - 2023-09-24 12:30:10 --> Hooks Class Initialized
DEBUG - 2023-09-24 12:30:10 --> UTF-8 Support Enabled
INFO - 2023-09-24 12:30:10 --> Utf8 Class Initialized
INFO - 2023-09-24 12:30:10 --> URI Class Initialized
INFO - 2023-09-24 12:30:10 --> Router Class Initialized
INFO - 2023-09-24 12:30:10 --> Output Class Initialized
INFO - 2023-09-24 12:30:10 --> Security Class Initialized
DEBUG - 2023-09-24 12:30:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-24 12:30:10 --> Input Class Initialized
INFO - 2023-09-24 12:30:10 --> Language Class Initialized
INFO - 2023-09-24 12:30:10 --> Language Class Initialized
INFO - 2023-09-24 12:30:10 --> Config Class Initialized
INFO - 2023-09-24 12:30:10 --> Loader Class Initialized
INFO - 2023-09-24 12:30:10 --> Helper loaded: url_helper
INFO - 2023-09-24 12:30:10 --> Helper loaded: file_helper
INFO - 2023-09-24 12:30:10 --> Helper loaded: form_helper
INFO - 2023-09-24 12:30:10 --> Helper loaded: my_helper
INFO - 2023-09-24 12:30:10 --> Database Driver Class Initialized
INFO - 2023-09-24 12:30:10 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-24 12:30:10 --> Controller Class Initialized
INFO - 2023-09-24 12:30:15 --> Config Class Initialized
INFO - 2023-09-24 12:30:15 --> Hooks Class Initialized
DEBUG - 2023-09-24 12:30:15 --> UTF-8 Support Enabled
INFO - 2023-09-24 12:30:15 --> Utf8 Class Initialized
INFO - 2023-09-24 12:30:15 --> URI Class Initialized
INFO - 2023-09-24 12:30:15 --> Router Class Initialized
INFO - 2023-09-24 12:30:15 --> Output Class Initialized
INFO - 2023-09-24 12:30:15 --> Security Class Initialized
DEBUG - 2023-09-24 12:30:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-24 12:30:15 --> Input Class Initialized
INFO - 2023-09-24 12:30:15 --> Language Class Initialized
INFO - 2023-09-24 12:30:15 --> Language Class Initialized
INFO - 2023-09-24 12:30:15 --> Config Class Initialized
INFO - 2023-09-24 12:30:15 --> Loader Class Initialized
INFO - 2023-09-24 12:30:15 --> Helper loaded: url_helper
INFO - 2023-09-24 12:30:15 --> Helper loaded: file_helper
INFO - 2023-09-24 12:30:15 --> Helper loaded: form_helper
INFO - 2023-09-24 12:30:15 --> Helper loaded: my_helper
INFO - 2023-09-24 12:30:15 --> Database Driver Class Initialized
INFO - 2023-09-24 12:30:15 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-24 12:30:15 --> Controller Class Initialized
INFO - 2023-09-24 12:30:15 --> Final output sent to browser
DEBUG - 2023-09-24 12:30:15 --> Total execution time: 0.0323
INFO - 2023-09-24 12:30:26 --> Config Class Initialized
INFO - 2023-09-24 12:30:26 --> Hooks Class Initialized
DEBUG - 2023-09-24 12:30:26 --> UTF-8 Support Enabled
INFO - 2023-09-24 12:30:26 --> Utf8 Class Initialized
INFO - 2023-09-24 12:30:26 --> URI Class Initialized
INFO - 2023-09-24 12:30:26 --> Router Class Initialized
INFO - 2023-09-24 12:30:26 --> Output Class Initialized
INFO - 2023-09-24 12:30:26 --> Security Class Initialized
DEBUG - 2023-09-24 12:30:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-24 12:30:26 --> Input Class Initialized
INFO - 2023-09-24 12:30:26 --> Language Class Initialized
INFO - 2023-09-24 12:30:26 --> Language Class Initialized
INFO - 2023-09-24 12:30:26 --> Config Class Initialized
INFO - 2023-09-24 12:30:26 --> Loader Class Initialized
INFO - 2023-09-24 12:30:26 --> Helper loaded: url_helper
INFO - 2023-09-24 12:30:26 --> Helper loaded: file_helper
INFO - 2023-09-24 12:30:26 --> Helper loaded: form_helper
INFO - 2023-09-24 12:30:26 --> Helper loaded: my_helper
INFO - 2023-09-24 12:30:26 --> Database Driver Class Initialized
INFO - 2023-09-24 12:30:26 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-24 12:30:26 --> Controller Class Initialized
INFO - 2023-09-24 12:30:26 --> Final output sent to browser
DEBUG - 2023-09-24 12:30:26 --> Total execution time: 0.0400
INFO - 2023-09-24 12:30:26 --> Config Class Initialized
INFO - 2023-09-24 12:30:26 --> Hooks Class Initialized
DEBUG - 2023-09-24 12:30:26 --> UTF-8 Support Enabled
INFO - 2023-09-24 12:30:26 --> Utf8 Class Initialized
INFO - 2023-09-24 12:30:26 --> URI Class Initialized
INFO - 2023-09-24 12:30:26 --> Router Class Initialized
INFO - 2023-09-24 12:30:26 --> Output Class Initialized
INFO - 2023-09-24 12:30:26 --> Security Class Initialized
DEBUG - 2023-09-24 12:30:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-24 12:30:26 --> Input Class Initialized
INFO - 2023-09-24 12:30:26 --> Language Class Initialized
INFO - 2023-09-24 12:30:26 --> Language Class Initialized
INFO - 2023-09-24 12:30:26 --> Config Class Initialized
INFO - 2023-09-24 12:30:26 --> Loader Class Initialized
INFO - 2023-09-24 12:30:26 --> Helper loaded: url_helper
INFO - 2023-09-24 12:30:26 --> Helper loaded: file_helper
INFO - 2023-09-24 12:30:26 --> Helper loaded: form_helper
INFO - 2023-09-24 12:30:26 --> Helper loaded: my_helper
INFO - 2023-09-24 12:30:26 --> Database Driver Class Initialized
INFO - 2023-09-24 12:30:26 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-24 12:30:26 --> Controller Class Initialized
INFO - 2023-09-24 12:30:27 --> Config Class Initialized
INFO - 2023-09-24 12:30:27 --> Hooks Class Initialized
DEBUG - 2023-09-24 12:30:27 --> UTF-8 Support Enabled
INFO - 2023-09-24 12:30:27 --> Utf8 Class Initialized
INFO - 2023-09-24 12:30:27 --> URI Class Initialized
INFO - 2023-09-24 12:30:27 --> Router Class Initialized
INFO - 2023-09-24 12:30:27 --> Output Class Initialized
INFO - 2023-09-24 12:30:27 --> Security Class Initialized
DEBUG - 2023-09-24 12:30:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-24 12:30:27 --> Input Class Initialized
INFO - 2023-09-24 12:30:27 --> Language Class Initialized
INFO - 2023-09-24 12:30:27 --> Language Class Initialized
INFO - 2023-09-24 12:30:27 --> Config Class Initialized
INFO - 2023-09-24 12:30:27 --> Loader Class Initialized
INFO - 2023-09-24 12:30:27 --> Helper loaded: url_helper
INFO - 2023-09-24 12:30:27 --> Helper loaded: file_helper
INFO - 2023-09-24 12:30:27 --> Helper loaded: form_helper
INFO - 2023-09-24 12:30:27 --> Helper loaded: my_helper
INFO - 2023-09-24 12:30:27 --> Database Driver Class Initialized
INFO - 2023-09-24 12:30:27 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-24 12:30:27 --> Controller Class Initialized
INFO - 2023-09-24 12:30:27 --> Final output sent to browser
DEBUG - 2023-09-24 12:30:27 --> Total execution time: 0.0363
INFO - 2023-09-24 12:30:37 --> Config Class Initialized
INFO - 2023-09-24 12:30:37 --> Hooks Class Initialized
DEBUG - 2023-09-24 12:30:37 --> UTF-8 Support Enabled
INFO - 2023-09-24 12:30:37 --> Utf8 Class Initialized
INFO - 2023-09-24 12:30:37 --> URI Class Initialized
INFO - 2023-09-24 12:30:37 --> Router Class Initialized
INFO - 2023-09-24 12:30:37 --> Output Class Initialized
INFO - 2023-09-24 12:30:37 --> Security Class Initialized
DEBUG - 2023-09-24 12:30:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-24 12:30:37 --> Input Class Initialized
INFO - 2023-09-24 12:30:37 --> Language Class Initialized
INFO - 2023-09-24 12:30:37 --> Language Class Initialized
INFO - 2023-09-24 12:30:37 --> Config Class Initialized
INFO - 2023-09-24 12:30:37 --> Loader Class Initialized
INFO - 2023-09-24 12:30:37 --> Helper loaded: url_helper
INFO - 2023-09-24 12:30:37 --> Helper loaded: file_helper
INFO - 2023-09-24 12:30:37 --> Helper loaded: form_helper
INFO - 2023-09-24 12:30:37 --> Helper loaded: my_helper
INFO - 2023-09-24 12:30:37 --> Database Driver Class Initialized
INFO - 2023-09-24 12:30:37 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-24 12:30:37 --> Controller Class Initialized
INFO - 2023-09-24 12:30:37 --> Final output sent to browser
DEBUG - 2023-09-24 12:30:37 --> Total execution time: 0.0338
INFO - 2023-09-24 12:30:37 --> Config Class Initialized
INFO - 2023-09-24 12:30:37 --> Hooks Class Initialized
DEBUG - 2023-09-24 12:30:37 --> UTF-8 Support Enabled
INFO - 2023-09-24 12:30:37 --> Utf8 Class Initialized
INFO - 2023-09-24 12:30:37 --> URI Class Initialized
INFO - 2023-09-24 12:30:37 --> Router Class Initialized
INFO - 2023-09-24 12:30:37 --> Output Class Initialized
INFO - 2023-09-24 12:30:37 --> Security Class Initialized
DEBUG - 2023-09-24 12:30:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-24 12:30:37 --> Input Class Initialized
INFO - 2023-09-24 12:30:37 --> Language Class Initialized
INFO - 2023-09-24 12:30:37 --> Language Class Initialized
INFO - 2023-09-24 12:30:37 --> Config Class Initialized
INFO - 2023-09-24 12:30:37 --> Loader Class Initialized
INFO - 2023-09-24 12:30:37 --> Helper loaded: url_helper
INFO - 2023-09-24 12:30:37 --> Helper loaded: file_helper
INFO - 2023-09-24 12:30:37 --> Helper loaded: form_helper
INFO - 2023-09-24 12:30:37 --> Helper loaded: my_helper
INFO - 2023-09-24 12:30:37 --> Database Driver Class Initialized
INFO - 2023-09-24 12:30:37 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-24 12:30:37 --> Controller Class Initialized
INFO - 2023-09-24 12:30:40 --> Config Class Initialized
INFO - 2023-09-24 12:30:40 --> Hooks Class Initialized
DEBUG - 2023-09-24 12:30:40 --> UTF-8 Support Enabled
INFO - 2023-09-24 12:30:40 --> Utf8 Class Initialized
INFO - 2023-09-24 12:30:40 --> URI Class Initialized
INFO - 2023-09-24 12:30:40 --> Router Class Initialized
INFO - 2023-09-24 12:30:40 --> Output Class Initialized
INFO - 2023-09-24 12:30:40 --> Security Class Initialized
DEBUG - 2023-09-24 12:30:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-24 12:30:40 --> Input Class Initialized
INFO - 2023-09-24 12:30:40 --> Language Class Initialized
INFO - 2023-09-24 12:30:40 --> Language Class Initialized
INFO - 2023-09-24 12:30:40 --> Config Class Initialized
INFO - 2023-09-24 12:30:40 --> Loader Class Initialized
INFO - 2023-09-24 12:30:40 --> Helper loaded: url_helper
INFO - 2023-09-24 12:30:40 --> Helper loaded: file_helper
INFO - 2023-09-24 12:30:40 --> Helper loaded: form_helper
INFO - 2023-09-24 12:30:40 --> Helper loaded: my_helper
INFO - 2023-09-24 12:30:40 --> Database Driver Class Initialized
INFO - 2023-09-24 12:30:40 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-24 12:30:40 --> Controller Class Initialized
INFO - 2023-09-24 12:30:40 --> Final output sent to browser
DEBUG - 2023-09-24 12:30:40 --> Total execution time: 0.0356
INFO - 2023-09-24 12:30:58 --> Config Class Initialized
INFO - 2023-09-24 12:30:58 --> Hooks Class Initialized
DEBUG - 2023-09-24 12:30:58 --> UTF-8 Support Enabled
INFO - 2023-09-24 12:30:58 --> Utf8 Class Initialized
INFO - 2023-09-24 12:30:58 --> URI Class Initialized
INFO - 2023-09-24 12:30:58 --> Router Class Initialized
INFO - 2023-09-24 12:30:58 --> Output Class Initialized
INFO - 2023-09-24 12:30:58 --> Security Class Initialized
DEBUG - 2023-09-24 12:30:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-24 12:30:58 --> Input Class Initialized
INFO - 2023-09-24 12:30:58 --> Language Class Initialized
INFO - 2023-09-24 12:30:58 --> Language Class Initialized
INFO - 2023-09-24 12:30:58 --> Config Class Initialized
INFO - 2023-09-24 12:30:58 --> Loader Class Initialized
INFO - 2023-09-24 12:30:58 --> Helper loaded: url_helper
INFO - 2023-09-24 12:30:58 --> Helper loaded: file_helper
INFO - 2023-09-24 12:30:58 --> Helper loaded: form_helper
INFO - 2023-09-24 12:30:58 --> Helper loaded: my_helper
INFO - 2023-09-24 12:30:58 --> Database Driver Class Initialized
INFO - 2023-09-24 12:30:58 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-24 12:30:58 --> Controller Class Initialized
INFO - 2023-09-24 12:30:58 --> Final output sent to browser
DEBUG - 2023-09-24 12:30:58 --> Total execution time: 0.0649
INFO - 2023-09-24 12:31:25 --> Config Class Initialized
INFO - 2023-09-24 12:31:25 --> Hooks Class Initialized
DEBUG - 2023-09-24 12:31:25 --> UTF-8 Support Enabled
INFO - 2023-09-24 12:31:25 --> Utf8 Class Initialized
INFO - 2023-09-24 12:31:25 --> URI Class Initialized
INFO - 2023-09-24 12:31:25 --> Router Class Initialized
INFO - 2023-09-24 12:31:25 --> Output Class Initialized
INFO - 2023-09-24 12:31:25 --> Security Class Initialized
DEBUG - 2023-09-24 12:31:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-24 12:31:25 --> Input Class Initialized
INFO - 2023-09-24 12:31:25 --> Language Class Initialized
INFO - 2023-09-24 12:31:25 --> Language Class Initialized
INFO - 2023-09-24 12:31:25 --> Config Class Initialized
INFO - 2023-09-24 12:31:25 --> Loader Class Initialized
INFO - 2023-09-24 12:31:25 --> Helper loaded: url_helper
INFO - 2023-09-24 12:31:25 --> Helper loaded: file_helper
INFO - 2023-09-24 12:31:25 --> Helper loaded: form_helper
INFO - 2023-09-24 12:31:25 --> Helper loaded: my_helper
INFO - 2023-09-24 12:31:25 --> Database Driver Class Initialized
INFO - 2023-09-24 12:31:25 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-24 12:31:25 --> Controller Class Initialized
INFO - 2023-09-24 12:31:25 --> Final output sent to browser
DEBUG - 2023-09-24 12:31:25 --> Total execution time: 0.0424
INFO - 2023-09-24 12:31:25 --> Config Class Initialized
INFO - 2023-09-24 12:31:25 --> Hooks Class Initialized
DEBUG - 2023-09-24 12:31:25 --> UTF-8 Support Enabled
INFO - 2023-09-24 12:31:25 --> Utf8 Class Initialized
INFO - 2023-09-24 12:31:25 --> URI Class Initialized
INFO - 2023-09-24 12:31:25 --> Router Class Initialized
INFO - 2023-09-24 12:31:25 --> Output Class Initialized
INFO - 2023-09-24 12:31:25 --> Security Class Initialized
DEBUG - 2023-09-24 12:31:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-24 12:31:25 --> Input Class Initialized
INFO - 2023-09-24 12:31:25 --> Language Class Initialized
INFO - 2023-09-24 12:31:25 --> Language Class Initialized
INFO - 2023-09-24 12:31:25 --> Config Class Initialized
INFO - 2023-09-24 12:31:25 --> Loader Class Initialized
INFO - 2023-09-24 12:31:25 --> Helper loaded: url_helper
INFO - 2023-09-24 12:31:25 --> Helper loaded: file_helper
INFO - 2023-09-24 12:31:25 --> Helper loaded: form_helper
INFO - 2023-09-24 12:31:25 --> Helper loaded: my_helper
INFO - 2023-09-24 12:31:25 --> Database Driver Class Initialized
INFO - 2023-09-24 12:31:25 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-24 12:31:25 --> Controller Class Initialized
INFO - 2023-09-24 12:31:33 --> Config Class Initialized
INFO - 2023-09-24 12:31:33 --> Hooks Class Initialized
DEBUG - 2023-09-24 12:31:33 --> UTF-8 Support Enabled
INFO - 2023-09-24 12:31:33 --> Utf8 Class Initialized
INFO - 2023-09-24 12:31:33 --> URI Class Initialized
INFO - 2023-09-24 12:31:33 --> Router Class Initialized
INFO - 2023-09-24 12:31:33 --> Output Class Initialized
INFO - 2023-09-24 12:31:33 --> Security Class Initialized
DEBUG - 2023-09-24 12:31:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-24 12:31:33 --> Input Class Initialized
INFO - 2023-09-24 12:31:33 --> Language Class Initialized
INFO - 2023-09-24 12:31:33 --> Language Class Initialized
INFO - 2023-09-24 12:31:33 --> Config Class Initialized
INFO - 2023-09-24 12:31:33 --> Loader Class Initialized
INFO - 2023-09-24 12:31:33 --> Helper loaded: url_helper
INFO - 2023-09-24 12:31:33 --> Helper loaded: file_helper
INFO - 2023-09-24 12:31:33 --> Helper loaded: form_helper
INFO - 2023-09-24 12:31:33 --> Helper loaded: my_helper
INFO - 2023-09-24 12:31:33 --> Database Driver Class Initialized
INFO - 2023-09-24 12:31:33 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-24 12:31:33 --> Controller Class Initialized
INFO - 2023-09-24 12:31:33 --> Final output sent to browser
DEBUG - 2023-09-24 12:31:33 --> Total execution time: 0.0426
INFO - 2023-09-24 12:31:40 --> Config Class Initialized
INFO - 2023-09-24 12:31:40 --> Hooks Class Initialized
DEBUG - 2023-09-24 12:31:40 --> UTF-8 Support Enabled
INFO - 2023-09-24 12:31:40 --> Utf8 Class Initialized
INFO - 2023-09-24 12:31:40 --> URI Class Initialized
INFO - 2023-09-24 12:31:40 --> Router Class Initialized
INFO - 2023-09-24 12:31:40 --> Output Class Initialized
INFO - 2023-09-24 12:31:40 --> Security Class Initialized
DEBUG - 2023-09-24 12:31:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-24 12:31:40 --> Input Class Initialized
INFO - 2023-09-24 12:31:40 --> Language Class Initialized
INFO - 2023-09-24 12:31:40 --> Language Class Initialized
INFO - 2023-09-24 12:31:40 --> Config Class Initialized
INFO - 2023-09-24 12:31:40 --> Loader Class Initialized
INFO - 2023-09-24 12:31:40 --> Helper loaded: url_helper
INFO - 2023-09-24 12:31:40 --> Helper loaded: file_helper
INFO - 2023-09-24 12:31:40 --> Helper loaded: form_helper
INFO - 2023-09-24 12:31:40 --> Helper loaded: my_helper
INFO - 2023-09-24 12:31:40 --> Database Driver Class Initialized
INFO - 2023-09-24 12:31:40 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-24 12:31:40 --> Controller Class Initialized
INFO - 2023-09-24 12:31:40 --> Final output sent to browser
DEBUG - 2023-09-24 12:31:40 --> Total execution time: 0.0381
INFO - 2023-09-24 12:31:40 --> Config Class Initialized
INFO - 2023-09-24 12:31:40 --> Hooks Class Initialized
DEBUG - 2023-09-24 12:31:40 --> UTF-8 Support Enabled
INFO - 2023-09-24 12:31:40 --> Utf8 Class Initialized
INFO - 2023-09-24 12:31:40 --> URI Class Initialized
INFO - 2023-09-24 12:31:40 --> Router Class Initialized
INFO - 2023-09-24 12:31:40 --> Output Class Initialized
INFO - 2023-09-24 12:31:40 --> Security Class Initialized
DEBUG - 2023-09-24 12:31:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-24 12:31:40 --> Input Class Initialized
INFO - 2023-09-24 12:31:40 --> Language Class Initialized
INFO - 2023-09-24 12:31:40 --> Language Class Initialized
INFO - 2023-09-24 12:31:40 --> Config Class Initialized
INFO - 2023-09-24 12:31:40 --> Loader Class Initialized
INFO - 2023-09-24 12:31:40 --> Helper loaded: url_helper
INFO - 2023-09-24 12:31:40 --> Helper loaded: file_helper
INFO - 2023-09-24 12:31:40 --> Helper loaded: form_helper
INFO - 2023-09-24 12:31:40 --> Helper loaded: my_helper
INFO - 2023-09-24 12:31:40 --> Database Driver Class Initialized
INFO - 2023-09-24 12:31:40 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-24 12:31:40 --> Controller Class Initialized
INFO - 2023-09-24 12:31:44 --> Config Class Initialized
INFO - 2023-09-24 12:31:44 --> Hooks Class Initialized
DEBUG - 2023-09-24 12:31:44 --> UTF-8 Support Enabled
INFO - 2023-09-24 12:31:44 --> Utf8 Class Initialized
INFO - 2023-09-24 12:31:44 --> URI Class Initialized
INFO - 2023-09-24 12:31:44 --> Router Class Initialized
INFO - 2023-09-24 12:31:44 --> Output Class Initialized
INFO - 2023-09-24 12:31:44 --> Security Class Initialized
DEBUG - 2023-09-24 12:31:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-24 12:31:44 --> Input Class Initialized
INFO - 2023-09-24 12:31:44 --> Language Class Initialized
INFO - 2023-09-24 12:31:44 --> Language Class Initialized
INFO - 2023-09-24 12:31:44 --> Config Class Initialized
INFO - 2023-09-24 12:31:44 --> Loader Class Initialized
INFO - 2023-09-24 12:31:44 --> Helper loaded: url_helper
INFO - 2023-09-24 12:31:44 --> Helper loaded: file_helper
INFO - 2023-09-24 12:31:44 --> Helper loaded: form_helper
INFO - 2023-09-24 12:31:44 --> Helper loaded: my_helper
INFO - 2023-09-24 12:31:44 --> Database Driver Class Initialized
INFO - 2023-09-24 12:31:44 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-24 12:31:44 --> Controller Class Initialized
INFO - 2023-09-24 12:31:44 --> Final output sent to browser
DEBUG - 2023-09-24 12:31:44 --> Total execution time: 0.0701
INFO - 2023-09-24 12:31:50 --> Config Class Initialized
INFO - 2023-09-24 12:31:50 --> Hooks Class Initialized
DEBUG - 2023-09-24 12:31:50 --> UTF-8 Support Enabled
INFO - 2023-09-24 12:31:50 --> Utf8 Class Initialized
INFO - 2023-09-24 12:31:50 --> URI Class Initialized
INFO - 2023-09-24 12:31:50 --> Router Class Initialized
INFO - 2023-09-24 12:31:50 --> Output Class Initialized
INFO - 2023-09-24 12:31:50 --> Security Class Initialized
DEBUG - 2023-09-24 12:31:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-24 12:31:50 --> Input Class Initialized
INFO - 2023-09-24 12:31:50 --> Language Class Initialized
INFO - 2023-09-24 12:31:50 --> Language Class Initialized
INFO - 2023-09-24 12:31:50 --> Config Class Initialized
INFO - 2023-09-24 12:31:50 --> Loader Class Initialized
INFO - 2023-09-24 12:31:50 --> Helper loaded: url_helper
INFO - 2023-09-24 12:31:50 --> Helper loaded: file_helper
INFO - 2023-09-24 12:31:50 --> Helper loaded: form_helper
INFO - 2023-09-24 12:31:50 --> Helper loaded: my_helper
INFO - 2023-09-24 12:31:50 --> Database Driver Class Initialized
INFO - 2023-09-24 12:31:50 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-24 12:31:50 --> Controller Class Initialized
INFO - 2023-09-24 12:31:50 --> Final output sent to browser
DEBUG - 2023-09-24 12:31:50 --> Total execution time: 0.0321
INFO - 2023-09-24 12:31:54 --> Config Class Initialized
INFO - 2023-09-24 12:31:54 --> Hooks Class Initialized
DEBUG - 2023-09-24 12:31:54 --> UTF-8 Support Enabled
INFO - 2023-09-24 12:31:54 --> Utf8 Class Initialized
INFO - 2023-09-24 12:31:54 --> URI Class Initialized
INFO - 2023-09-24 12:31:54 --> Router Class Initialized
INFO - 2023-09-24 12:31:54 --> Output Class Initialized
INFO - 2023-09-24 12:31:54 --> Security Class Initialized
DEBUG - 2023-09-24 12:31:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-24 12:31:54 --> Input Class Initialized
INFO - 2023-09-24 12:31:54 --> Language Class Initialized
INFO - 2023-09-24 12:31:54 --> Language Class Initialized
INFO - 2023-09-24 12:31:54 --> Config Class Initialized
INFO - 2023-09-24 12:31:54 --> Loader Class Initialized
INFO - 2023-09-24 12:31:54 --> Helper loaded: url_helper
INFO - 2023-09-24 12:31:54 --> Helper loaded: file_helper
INFO - 2023-09-24 12:31:54 --> Helper loaded: form_helper
INFO - 2023-09-24 12:31:54 --> Helper loaded: my_helper
INFO - 2023-09-24 12:31:54 --> Database Driver Class Initialized
INFO - 2023-09-24 12:31:54 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-24 12:31:54 --> Controller Class Initialized
INFO - 2023-09-24 12:31:54 --> Final output sent to browser
DEBUG - 2023-09-24 12:31:54 --> Total execution time: 0.0286
INFO - 2023-09-24 12:31:54 --> Config Class Initialized
INFO - 2023-09-24 12:31:54 --> Hooks Class Initialized
DEBUG - 2023-09-24 12:31:54 --> UTF-8 Support Enabled
INFO - 2023-09-24 12:31:54 --> Utf8 Class Initialized
INFO - 2023-09-24 12:31:54 --> URI Class Initialized
INFO - 2023-09-24 12:31:54 --> Router Class Initialized
INFO - 2023-09-24 12:31:54 --> Output Class Initialized
INFO - 2023-09-24 12:31:54 --> Security Class Initialized
DEBUG - 2023-09-24 12:31:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-24 12:31:54 --> Input Class Initialized
INFO - 2023-09-24 12:31:54 --> Language Class Initialized
INFO - 2023-09-24 12:31:54 --> Language Class Initialized
INFO - 2023-09-24 12:31:54 --> Config Class Initialized
INFO - 2023-09-24 12:31:54 --> Loader Class Initialized
INFO - 2023-09-24 12:31:54 --> Helper loaded: url_helper
INFO - 2023-09-24 12:31:54 --> Helper loaded: file_helper
INFO - 2023-09-24 12:31:54 --> Helper loaded: form_helper
INFO - 2023-09-24 12:31:54 --> Helper loaded: my_helper
INFO - 2023-09-24 12:31:54 --> Database Driver Class Initialized
INFO - 2023-09-24 12:31:54 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-24 12:31:54 --> Controller Class Initialized
INFO - 2023-09-24 12:31:56 --> Config Class Initialized
INFO - 2023-09-24 12:31:56 --> Hooks Class Initialized
DEBUG - 2023-09-24 12:31:56 --> UTF-8 Support Enabled
INFO - 2023-09-24 12:31:56 --> Utf8 Class Initialized
INFO - 2023-09-24 12:31:56 --> URI Class Initialized
INFO - 2023-09-24 12:31:56 --> Router Class Initialized
INFO - 2023-09-24 12:31:56 --> Output Class Initialized
INFO - 2023-09-24 12:31:56 --> Security Class Initialized
DEBUG - 2023-09-24 12:31:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-24 12:31:56 --> Input Class Initialized
INFO - 2023-09-24 12:31:56 --> Language Class Initialized
INFO - 2023-09-24 12:31:56 --> Language Class Initialized
INFO - 2023-09-24 12:31:56 --> Config Class Initialized
INFO - 2023-09-24 12:31:56 --> Loader Class Initialized
INFO - 2023-09-24 12:31:56 --> Helper loaded: url_helper
INFO - 2023-09-24 12:31:56 --> Helper loaded: file_helper
INFO - 2023-09-24 12:31:56 --> Helper loaded: form_helper
INFO - 2023-09-24 12:31:56 --> Helper loaded: my_helper
INFO - 2023-09-24 12:31:56 --> Database Driver Class Initialized
INFO - 2023-09-24 12:31:56 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-24 12:31:56 --> Controller Class Initialized
INFO - 2023-09-24 12:31:56 --> Final output sent to browser
DEBUG - 2023-09-24 12:31:56 --> Total execution time: 0.0314
INFO - 2023-09-24 12:32:09 --> Config Class Initialized
INFO - 2023-09-24 12:32:09 --> Hooks Class Initialized
DEBUG - 2023-09-24 12:32:09 --> UTF-8 Support Enabled
INFO - 2023-09-24 12:32:09 --> Utf8 Class Initialized
INFO - 2023-09-24 12:32:09 --> URI Class Initialized
INFO - 2023-09-24 12:32:09 --> Router Class Initialized
INFO - 2023-09-24 12:32:09 --> Output Class Initialized
INFO - 2023-09-24 12:32:09 --> Security Class Initialized
DEBUG - 2023-09-24 12:32:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-24 12:32:09 --> Input Class Initialized
INFO - 2023-09-24 12:32:09 --> Language Class Initialized
INFO - 2023-09-24 12:32:09 --> Language Class Initialized
INFO - 2023-09-24 12:32:09 --> Config Class Initialized
INFO - 2023-09-24 12:32:09 --> Loader Class Initialized
INFO - 2023-09-24 12:32:09 --> Helper loaded: url_helper
INFO - 2023-09-24 12:32:09 --> Helper loaded: file_helper
INFO - 2023-09-24 12:32:09 --> Helper loaded: form_helper
INFO - 2023-09-24 12:32:09 --> Helper loaded: my_helper
INFO - 2023-09-24 12:32:09 --> Database Driver Class Initialized
INFO - 2023-09-24 12:32:09 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-24 12:32:09 --> Controller Class Initialized
INFO - 2023-09-24 12:32:09 --> Final output sent to browser
DEBUG - 2023-09-24 12:32:09 --> Total execution time: 0.0358
INFO - 2023-09-24 12:32:09 --> Config Class Initialized
INFO - 2023-09-24 12:32:09 --> Hooks Class Initialized
DEBUG - 2023-09-24 12:32:09 --> UTF-8 Support Enabled
INFO - 2023-09-24 12:32:09 --> Utf8 Class Initialized
INFO - 2023-09-24 12:32:09 --> URI Class Initialized
INFO - 2023-09-24 12:32:09 --> Router Class Initialized
INFO - 2023-09-24 12:32:09 --> Output Class Initialized
INFO - 2023-09-24 12:32:09 --> Security Class Initialized
DEBUG - 2023-09-24 12:32:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-24 12:32:09 --> Input Class Initialized
INFO - 2023-09-24 12:32:09 --> Language Class Initialized
INFO - 2023-09-24 12:32:09 --> Language Class Initialized
INFO - 2023-09-24 12:32:09 --> Config Class Initialized
INFO - 2023-09-24 12:32:09 --> Loader Class Initialized
INFO - 2023-09-24 12:32:09 --> Helper loaded: url_helper
INFO - 2023-09-24 12:32:09 --> Helper loaded: file_helper
INFO - 2023-09-24 12:32:09 --> Helper loaded: form_helper
INFO - 2023-09-24 12:32:09 --> Helper loaded: my_helper
INFO - 2023-09-24 12:32:09 --> Database Driver Class Initialized
INFO - 2023-09-24 12:32:09 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-24 12:32:09 --> Controller Class Initialized
INFO - 2023-09-24 12:32:11 --> Config Class Initialized
INFO - 2023-09-24 12:32:11 --> Hooks Class Initialized
DEBUG - 2023-09-24 12:32:11 --> UTF-8 Support Enabled
INFO - 2023-09-24 12:32:11 --> Utf8 Class Initialized
INFO - 2023-09-24 12:32:11 --> URI Class Initialized
INFO - 2023-09-24 12:32:11 --> Router Class Initialized
INFO - 2023-09-24 12:32:11 --> Output Class Initialized
INFO - 2023-09-24 12:32:11 --> Security Class Initialized
DEBUG - 2023-09-24 12:32:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-24 12:32:11 --> Input Class Initialized
INFO - 2023-09-24 12:32:11 --> Language Class Initialized
INFO - 2023-09-24 12:32:11 --> Language Class Initialized
INFO - 2023-09-24 12:32:11 --> Config Class Initialized
INFO - 2023-09-24 12:32:11 --> Loader Class Initialized
INFO - 2023-09-24 12:32:11 --> Helper loaded: url_helper
INFO - 2023-09-24 12:32:11 --> Helper loaded: file_helper
INFO - 2023-09-24 12:32:11 --> Helper loaded: form_helper
INFO - 2023-09-24 12:32:11 --> Helper loaded: my_helper
INFO - 2023-09-24 12:32:11 --> Database Driver Class Initialized
INFO - 2023-09-24 12:32:11 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-24 12:32:11 --> Controller Class Initialized
INFO - 2023-09-24 12:32:11 --> Final output sent to browser
DEBUG - 2023-09-24 12:32:11 --> Total execution time: 0.0374
INFO - 2023-09-24 12:32:24 --> Config Class Initialized
INFO - 2023-09-24 12:32:24 --> Hooks Class Initialized
DEBUG - 2023-09-24 12:32:24 --> UTF-8 Support Enabled
INFO - 2023-09-24 12:32:24 --> Utf8 Class Initialized
INFO - 2023-09-24 12:32:24 --> URI Class Initialized
INFO - 2023-09-24 12:32:24 --> Router Class Initialized
INFO - 2023-09-24 12:32:24 --> Output Class Initialized
INFO - 2023-09-24 12:32:24 --> Security Class Initialized
DEBUG - 2023-09-24 12:32:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-24 12:32:24 --> Input Class Initialized
INFO - 2023-09-24 12:32:24 --> Language Class Initialized
INFO - 2023-09-24 12:32:24 --> Language Class Initialized
INFO - 2023-09-24 12:32:24 --> Config Class Initialized
INFO - 2023-09-24 12:32:24 --> Loader Class Initialized
INFO - 2023-09-24 12:32:24 --> Helper loaded: url_helper
INFO - 2023-09-24 12:32:24 --> Helper loaded: file_helper
INFO - 2023-09-24 12:32:24 --> Helper loaded: form_helper
INFO - 2023-09-24 12:32:24 --> Helper loaded: my_helper
INFO - 2023-09-24 12:32:24 --> Database Driver Class Initialized
INFO - 2023-09-24 12:32:24 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-24 12:32:24 --> Controller Class Initialized
INFO - 2023-09-24 12:32:24 --> Final output sent to browser
DEBUG - 2023-09-24 12:32:24 --> Total execution time: 0.0340
INFO - 2023-09-24 12:32:24 --> Config Class Initialized
INFO - 2023-09-24 12:32:24 --> Hooks Class Initialized
DEBUG - 2023-09-24 12:32:24 --> UTF-8 Support Enabled
INFO - 2023-09-24 12:32:24 --> Utf8 Class Initialized
INFO - 2023-09-24 12:32:24 --> URI Class Initialized
INFO - 2023-09-24 12:32:24 --> Router Class Initialized
INFO - 2023-09-24 12:32:24 --> Output Class Initialized
INFO - 2023-09-24 12:32:24 --> Security Class Initialized
DEBUG - 2023-09-24 12:32:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-24 12:32:24 --> Input Class Initialized
INFO - 2023-09-24 12:32:24 --> Language Class Initialized
INFO - 2023-09-24 12:32:24 --> Language Class Initialized
INFO - 2023-09-24 12:32:24 --> Config Class Initialized
INFO - 2023-09-24 12:32:24 --> Loader Class Initialized
INFO - 2023-09-24 12:32:24 --> Helper loaded: url_helper
INFO - 2023-09-24 12:32:24 --> Helper loaded: file_helper
INFO - 2023-09-24 12:32:24 --> Helper loaded: form_helper
INFO - 2023-09-24 12:32:24 --> Helper loaded: my_helper
INFO - 2023-09-24 12:32:24 --> Database Driver Class Initialized
INFO - 2023-09-24 12:32:24 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-24 12:32:24 --> Controller Class Initialized
INFO - 2023-09-24 12:32:33 --> Config Class Initialized
INFO - 2023-09-24 12:32:33 --> Hooks Class Initialized
DEBUG - 2023-09-24 12:32:33 --> UTF-8 Support Enabled
INFO - 2023-09-24 12:32:33 --> Utf8 Class Initialized
INFO - 2023-09-24 12:32:33 --> URI Class Initialized
INFO - 2023-09-24 12:32:33 --> Router Class Initialized
INFO - 2023-09-24 12:32:33 --> Output Class Initialized
INFO - 2023-09-24 12:32:33 --> Security Class Initialized
DEBUG - 2023-09-24 12:32:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-24 12:32:33 --> Input Class Initialized
INFO - 2023-09-24 12:32:33 --> Language Class Initialized
INFO - 2023-09-24 12:32:33 --> Language Class Initialized
INFO - 2023-09-24 12:32:33 --> Config Class Initialized
INFO - 2023-09-24 12:32:33 --> Loader Class Initialized
INFO - 2023-09-24 12:32:33 --> Helper loaded: url_helper
INFO - 2023-09-24 12:32:33 --> Helper loaded: file_helper
INFO - 2023-09-24 12:32:33 --> Helper loaded: form_helper
INFO - 2023-09-24 12:32:33 --> Helper loaded: my_helper
INFO - 2023-09-24 12:32:33 --> Database Driver Class Initialized
INFO - 2023-09-24 12:32:33 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-24 12:32:33 --> Controller Class Initialized
INFO - 2023-09-24 12:32:33 --> Final output sent to browser
DEBUG - 2023-09-24 12:32:33 --> Total execution time: 0.0541
INFO - 2023-09-24 12:32:43 --> Config Class Initialized
INFO - 2023-09-24 12:32:43 --> Hooks Class Initialized
DEBUG - 2023-09-24 12:32:43 --> UTF-8 Support Enabled
INFO - 2023-09-24 12:32:43 --> Utf8 Class Initialized
INFO - 2023-09-24 12:32:43 --> URI Class Initialized
INFO - 2023-09-24 12:32:43 --> Router Class Initialized
INFO - 2023-09-24 12:32:43 --> Output Class Initialized
INFO - 2023-09-24 12:32:43 --> Security Class Initialized
DEBUG - 2023-09-24 12:32:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-24 12:32:43 --> Input Class Initialized
INFO - 2023-09-24 12:32:43 --> Language Class Initialized
INFO - 2023-09-24 12:32:43 --> Language Class Initialized
INFO - 2023-09-24 12:32:43 --> Config Class Initialized
INFO - 2023-09-24 12:32:43 --> Loader Class Initialized
INFO - 2023-09-24 12:32:43 --> Helper loaded: url_helper
INFO - 2023-09-24 12:32:43 --> Helper loaded: file_helper
INFO - 2023-09-24 12:32:43 --> Helper loaded: form_helper
INFO - 2023-09-24 12:32:43 --> Helper loaded: my_helper
INFO - 2023-09-24 12:32:43 --> Database Driver Class Initialized
INFO - 2023-09-24 12:32:43 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-24 12:32:43 --> Controller Class Initialized
INFO - 2023-09-24 12:32:43 --> Final output sent to browser
DEBUG - 2023-09-24 12:32:43 --> Total execution time: 0.0318
INFO - 2023-09-24 12:32:43 --> Config Class Initialized
INFO - 2023-09-24 12:32:43 --> Hooks Class Initialized
DEBUG - 2023-09-24 12:32:43 --> UTF-8 Support Enabled
INFO - 2023-09-24 12:32:43 --> Utf8 Class Initialized
INFO - 2023-09-24 12:32:43 --> URI Class Initialized
INFO - 2023-09-24 12:32:43 --> Router Class Initialized
INFO - 2023-09-24 12:32:43 --> Output Class Initialized
INFO - 2023-09-24 12:32:43 --> Security Class Initialized
DEBUG - 2023-09-24 12:32:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-24 12:32:43 --> Input Class Initialized
INFO - 2023-09-24 12:32:43 --> Language Class Initialized
INFO - 2023-09-24 12:32:43 --> Language Class Initialized
INFO - 2023-09-24 12:32:43 --> Config Class Initialized
INFO - 2023-09-24 12:32:43 --> Loader Class Initialized
INFO - 2023-09-24 12:32:43 --> Helper loaded: url_helper
INFO - 2023-09-24 12:32:43 --> Helper loaded: file_helper
INFO - 2023-09-24 12:32:43 --> Helper loaded: form_helper
INFO - 2023-09-24 12:32:43 --> Helper loaded: my_helper
INFO - 2023-09-24 12:32:43 --> Database Driver Class Initialized
INFO - 2023-09-24 12:32:43 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-24 12:32:43 --> Controller Class Initialized
INFO - 2023-09-24 12:32:53 --> Config Class Initialized
INFO - 2023-09-24 12:32:53 --> Hooks Class Initialized
DEBUG - 2023-09-24 12:32:53 --> UTF-8 Support Enabled
INFO - 2023-09-24 12:32:53 --> Utf8 Class Initialized
INFO - 2023-09-24 12:32:53 --> URI Class Initialized
INFO - 2023-09-24 12:32:53 --> Router Class Initialized
INFO - 2023-09-24 12:32:53 --> Output Class Initialized
INFO - 2023-09-24 12:32:53 --> Security Class Initialized
DEBUG - 2023-09-24 12:32:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-24 12:32:53 --> Input Class Initialized
INFO - 2023-09-24 12:32:53 --> Language Class Initialized
INFO - 2023-09-24 12:32:53 --> Language Class Initialized
INFO - 2023-09-24 12:32:53 --> Config Class Initialized
INFO - 2023-09-24 12:32:53 --> Loader Class Initialized
INFO - 2023-09-24 12:32:53 --> Helper loaded: url_helper
INFO - 2023-09-24 12:32:53 --> Helper loaded: file_helper
INFO - 2023-09-24 12:32:53 --> Helper loaded: form_helper
INFO - 2023-09-24 12:32:53 --> Helper loaded: my_helper
INFO - 2023-09-24 12:32:53 --> Database Driver Class Initialized
INFO - 2023-09-24 12:32:53 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-24 12:32:53 --> Controller Class Initialized
INFO - 2023-09-24 12:32:53 --> Final output sent to browser
DEBUG - 2023-09-24 12:32:53 --> Total execution time: 0.0311
INFO - 2023-09-24 12:33:00 --> Config Class Initialized
INFO - 2023-09-24 12:33:00 --> Hooks Class Initialized
DEBUG - 2023-09-24 12:33:00 --> UTF-8 Support Enabled
INFO - 2023-09-24 12:33:00 --> Utf8 Class Initialized
INFO - 2023-09-24 12:33:00 --> URI Class Initialized
INFO - 2023-09-24 12:33:00 --> Router Class Initialized
INFO - 2023-09-24 12:33:00 --> Output Class Initialized
INFO - 2023-09-24 12:33:00 --> Security Class Initialized
DEBUG - 2023-09-24 12:33:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-24 12:33:00 --> Input Class Initialized
INFO - 2023-09-24 12:33:00 --> Language Class Initialized
INFO - 2023-09-24 12:33:00 --> Language Class Initialized
INFO - 2023-09-24 12:33:00 --> Config Class Initialized
INFO - 2023-09-24 12:33:00 --> Loader Class Initialized
INFO - 2023-09-24 12:33:00 --> Helper loaded: url_helper
INFO - 2023-09-24 12:33:00 --> Helper loaded: file_helper
INFO - 2023-09-24 12:33:00 --> Helper loaded: form_helper
INFO - 2023-09-24 12:33:00 --> Helper loaded: my_helper
INFO - 2023-09-24 12:33:00 --> Database Driver Class Initialized
INFO - 2023-09-24 12:33:00 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-24 12:33:00 --> Controller Class Initialized
INFO - 2023-09-24 12:33:00 --> Final output sent to browser
DEBUG - 2023-09-24 12:33:00 --> Total execution time: 0.0862
INFO - 2023-09-24 12:33:00 --> Config Class Initialized
INFO - 2023-09-24 12:33:00 --> Hooks Class Initialized
DEBUG - 2023-09-24 12:33:00 --> UTF-8 Support Enabled
INFO - 2023-09-24 12:33:00 --> Utf8 Class Initialized
INFO - 2023-09-24 12:33:00 --> URI Class Initialized
INFO - 2023-09-24 12:33:00 --> Router Class Initialized
INFO - 2023-09-24 12:33:00 --> Output Class Initialized
INFO - 2023-09-24 12:33:00 --> Security Class Initialized
DEBUG - 2023-09-24 12:33:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-24 12:33:00 --> Input Class Initialized
INFO - 2023-09-24 12:33:00 --> Language Class Initialized
INFO - 2023-09-24 12:33:00 --> Language Class Initialized
INFO - 2023-09-24 12:33:00 --> Config Class Initialized
INFO - 2023-09-24 12:33:00 --> Loader Class Initialized
INFO - 2023-09-24 12:33:00 --> Helper loaded: url_helper
INFO - 2023-09-24 12:33:00 --> Helper loaded: file_helper
INFO - 2023-09-24 12:33:00 --> Helper loaded: form_helper
INFO - 2023-09-24 12:33:00 --> Helper loaded: my_helper
INFO - 2023-09-24 12:33:00 --> Database Driver Class Initialized
INFO - 2023-09-24 12:33:00 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-24 12:33:00 --> Controller Class Initialized
INFO - 2023-09-24 12:33:01 --> Config Class Initialized
INFO - 2023-09-24 12:33:01 --> Hooks Class Initialized
DEBUG - 2023-09-24 12:33:01 --> UTF-8 Support Enabled
INFO - 2023-09-24 12:33:01 --> Utf8 Class Initialized
INFO - 2023-09-24 12:33:01 --> URI Class Initialized
INFO - 2023-09-24 12:33:01 --> Router Class Initialized
INFO - 2023-09-24 12:33:01 --> Output Class Initialized
INFO - 2023-09-24 12:33:01 --> Security Class Initialized
DEBUG - 2023-09-24 12:33:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-24 12:33:01 --> Input Class Initialized
INFO - 2023-09-24 12:33:01 --> Language Class Initialized
INFO - 2023-09-24 12:33:01 --> Language Class Initialized
INFO - 2023-09-24 12:33:01 --> Config Class Initialized
INFO - 2023-09-24 12:33:01 --> Loader Class Initialized
INFO - 2023-09-24 12:33:01 --> Helper loaded: url_helper
INFO - 2023-09-24 12:33:01 --> Helper loaded: file_helper
INFO - 2023-09-24 12:33:01 --> Helper loaded: form_helper
INFO - 2023-09-24 12:33:01 --> Helper loaded: my_helper
INFO - 2023-09-24 12:33:01 --> Database Driver Class Initialized
INFO - 2023-09-24 12:33:01 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-24 12:33:01 --> Controller Class Initialized
INFO - 2023-09-24 12:33:01 --> Final output sent to browser
DEBUG - 2023-09-24 12:33:01 --> Total execution time: 0.0826
INFO - 2023-09-24 12:33:10 --> Config Class Initialized
INFO - 2023-09-24 12:33:10 --> Hooks Class Initialized
DEBUG - 2023-09-24 12:33:10 --> UTF-8 Support Enabled
INFO - 2023-09-24 12:33:10 --> Utf8 Class Initialized
INFO - 2023-09-24 12:33:10 --> URI Class Initialized
INFO - 2023-09-24 12:33:10 --> Router Class Initialized
INFO - 2023-09-24 12:33:10 --> Output Class Initialized
INFO - 2023-09-24 12:33:10 --> Security Class Initialized
DEBUG - 2023-09-24 12:33:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-24 12:33:10 --> Input Class Initialized
INFO - 2023-09-24 12:33:10 --> Language Class Initialized
INFO - 2023-09-24 12:33:10 --> Language Class Initialized
INFO - 2023-09-24 12:33:10 --> Config Class Initialized
INFO - 2023-09-24 12:33:10 --> Loader Class Initialized
INFO - 2023-09-24 12:33:10 --> Helper loaded: url_helper
INFO - 2023-09-24 12:33:10 --> Helper loaded: file_helper
INFO - 2023-09-24 12:33:10 --> Helper loaded: form_helper
INFO - 2023-09-24 12:33:10 --> Helper loaded: my_helper
INFO - 2023-09-24 12:33:10 --> Database Driver Class Initialized
INFO - 2023-09-24 12:33:10 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-24 12:33:10 --> Controller Class Initialized
INFO - 2023-09-24 12:33:10 --> Final output sent to browser
DEBUG - 2023-09-24 12:33:10 --> Total execution time: 0.0368
INFO - 2023-09-24 12:33:10 --> Config Class Initialized
INFO - 2023-09-24 12:33:10 --> Hooks Class Initialized
DEBUG - 2023-09-24 12:33:10 --> UTF-8 Support Enabled
INFO - 2023-09-24 12:33:10 --> Utf8 Class Initialized
INFO - 2023-09-24 12:33:10 --> URI Class Initialized
INFO - 2023-09-24 12:33:10 --> Router Class Initialized
INFO - 2023-09-24 12:33:10 --> Output Class Initialized
INFO - 2023-09-24 12:33:10 --> Security Class Initialized
DEBUG - 2023-09-24 12:33:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-24 12:33:10 --> Input Class Initialized
INFO - 2023-09-24 12:33:10 --> Language Class Initialized
INFO - 2023-09-24 12:33:10 --> Language Class Initialized
INFO - 2023-09-24 12:33:10 --> Config Class Initialized
INFO - 2023-09-24 12:33:10 --> Loader Class Initialized
INFO - 2023-09-24 12:33:10 --> Helper loaded: url_helper
INFO - 2023-09-24 12:33:10 --> Helper loaded: file_helper
INFO - 2023-09-24 12:33:10 --> Helper loaded: form_helper
INFO - 2023-09-24 12:33:10 --> Helper loaded: my_helper
INFO - 2023-09-24 12:33:10 --> Database Driver Class Initialized
INFO - 2023-09-24 12:33:10 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-24 12:33:10 --> Controller Class Initialized
INFO - 2023-09-24 12:33:11 --> Config Class Initialized
INFO - 2023-09-24 12:33:11 --> Hooks Class Initialized
DEBUG - 2023-09-24 12:33:11 --> UTF-8 Support Enabled
INFO - 2023-09-24 12:33:11 --> Utf8 Class Initialized
INFO - 2023-09-24 12:33:11 --> URI Class Initialized
INFO - 2023-09-24 12:33:11 --> Router Class Initialized
INFO - 2023-09-24 12:33:11 --> Output Class Initialized
INFO - 2023-09-24 12:33:11 --> Security Class Initialized
DEBUG - 2023-09-24 12:33:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-24 12:33:11 --> Input Class Initialized
INFO - 2023-09-24 12:33:11 --> Language Class Initialized
INFO - 2023-09-24 12:33:11 --> Language Class Initialized
INFO - 2023-09-24 12:33:11 --> Config Class Initialized
INFO - 2023-09-24 12:33:11 --> Loader Class Initialized
INFO - 2023-09-24 12:33:11 --> Helper loaded: url_helper
INFO - 2023-09-24 12:33:11 --> Helper loaded: file_helper
INFO - 2023-09-24 12:33:11 --> Helper loaded: form_helper
INFO - 2023-09-24 12:33:11 --> Helper loaded: my_helper
INFO - 2023-09-24 12:33:11 --> Database Driver Class Initialized
INFO - 2023-09-24 12:33:11 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-24 12:33:11 --> Controller Class Initialized
INFO - 2023-09-24 12:33:11 --> Final output sent to browser
DEBUG - 2023-09-24 12:33:11 --> Total execution time: 0.0642
INFO - 2023-09-24 12:33:23 --> Config Class Initialized
INFO - 2023-09-24 12:33:23 --> Hooks Class Initialized
DEBUG - 2023-09-24 12:33:23 --> UTF-8 Support Enabled
INFO - 2023-09-24 12:33:23 --> Utf8 Class Initialized
INFO - 2023-09-24 12:33:23 --> URI Class Initialized
INFO - 2023-09-24 12:33:23 --> Router Class Initialized
INFO - 2023-09-24 12:33:23 --> Output Class Initialized
INFO - 2023-09-24 12:33:23 --> Security Class Initialized
DEBUG - 2023-09-24 12:33:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-24 12:33:23 --> Input Class Initialized
INFO - 2023-09-24 12:33:23 --> Language Class Initialized
INFO - 2023-09-24 12:33:23 --> Language Class Initialized
INFO - 2023-09-24 12:33:23 --> Config Class Initialized
INFO - 2023-09-24 12:33:23 --> Loader Class Initialized
INFO - 2023-09-24 12:33:23 --> Helper loaded: url_helper
INFO - 2023-09-24 12:33:23 --> Helper loaded: file_helper
INFO - 2023-09-24 12:33:23 --> Helper loaded: form_helper
INFO - 2023-09-24 12:33:23 --> Helper loaded: my_helper
INFO - 2023-09-24 12:33:23 --> Database Driver Class Initialized
INFO - 2023-09-24 12:33:23 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-24 12:33:23 --> Controller Class Initialized
INFO - 2023-09-24 12:33:23 --> Final output sent to browser
DEBUG - 2023-09-24 12:33:23 --> Total execution time: 0.0421
INFO - 2023-09-24 12:33:23 --> Config Class Initialized
INFO - 2023-09-24 12:33:23 --> Hooks Class Initialized
DEBUG - 2023-09-24 12:33:23 --> UTF-8 Support Enabled
INFO - 2023-09-24 12:33:23 --> Utf8 Class Initialized
INFO - 2023-09-24 12:33:23 --> URI Class Initialized
INFO - 2023-09-24 12:33:23 --> Router Class Initialized
INFO - 2023-09-24 12:33:23 --> Output Class Initialized
INFO - 2023-09-24 12:33:23 --> Security Class Initialized
DEBUG - 2023-09-24 12:33:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-24 12:33:23 --> Input Class Initialized
INFO - 2023-09-24 12:33:23 --> Language Class Initialized
INFO - 2023-09-24 12:33:23 --> Language Class Initialized
INFO - 2023-09-24 12:33:23 --> Config Class Initialized
INFO - 2023-09-24 12:33:23 --> Loader Class Initialized
INFO - 2023-09-24 12:33:23 --> Helper loaded: url_helper
INFO - 2023-09-24 12:33:23 --> Helper loaded: file_helper
INFO - 2023-09-24 12:33:23 --> Helper loaded: form_helper
INFO - 2023-09-24 12:33:23 --> Helper loaded: my_helper
INFO - 2023-09-24 12:33:23 --> Database Driver Class Initialized
INFO - 2023-09-24 12:33:23 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-24 12:33:23 --> Controller Class Initialized
INFO - 2023-09-24 12:33:24 --> Config Class Initialized
INFO - 2023-09-24 12:33:24 --> Hooks Class Initialized
DEBUG - 2023-09-24 12:33:24 --> UTF-8 Support Enabled
INFO - 2023-09-24 12:33:24 --> Utf8 Class Initialized
INFO - 2023-09-24 12:33:24 --> URI Class Initialized
INFO - 2023-09-24 12:33:24 --> Router Class Initialized
INFO - 2023-09-24 12:33:24 --> Output Class Initialized
INFO - 2023-09-24 12:33:24 --> Security Class Initialized
DEBUG - 2023-09-24 12:33:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-24 12:33:24 --> Input Class Initialized
INFO - 2023-09-24 12:33:24 --> Language Class Initialized
INFO - 2023-09-24 12:33:24 --> Language Class Initialized
INFO - 2023-09-24 12:33:24 --> Config Class Initialized
INFO - 2023-09-24 12:33:24 --> Loader Class Initialized
INFO - 2023-09-24 12:33:24 --> Helper loaded: url_helper
INFO - 2023-09-24 12:33:24 --> Helper loaded: file_helper
INFO - 2023-09-24 12:33:24 --> Helper loaded: form_helper
INFO - 2023-09-24 12:33:24 --> Helper loaded: my_helper
INFO - 2023-09-24 12:33:24 --> Database Driver Class Initialized
INFO - 2023-09-24 12:33:24 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-24 12:33:24 --> Controller Class Initialized
INFO - 2023-09-24 12:33:24 --> Final output sent to browser
DEBUG - 2023-09-24 12:33:24 --> Total execution time: 0.1181
INFO - 2023-09-24 12:33:35 --> Config Class Initialized
INFO - 2023-09-24 12:33:35 --> Hooks Class Initialized
DEBUG - 2023-09-24 12:33:35 --> UTF-8 Support Enabled
INFO - 2023-09-24 12:33:35 --> Utf8 Class Initialized
INFO - 2023-09-24 12:33:35 --> URI Class Initialized
INFO - 2023-09-24 12:33:35 --> Router Class Initialized
INFO - 2023-09-24 12:33:35 --> Output Class Initialized
INFO - 2023-09-24 12:33:35 --> Security Class Initialized
DEBUG - 2023-09-24 12:33:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-24 12:33:35 --> Input Class Initialized
INFO - 2023-09-24 12:33:35 --> Language Class Initialized
INFO - 2023-09-24 12:33:35 --> Language Class Initialized
INFO - 2023-09-24 12:33:35 --> Config Class Initialized
INFO - 2023-09-24 12:33:35 --> Loader Class Initialized
INFO - 2023-09-24 12:33:35 --> Helper loaded: url_helper
INFO - 2023-09-24 12:33:35 --> Helper loaded: file_helper
INFO - 2023-09-24 12:33:35 --> Helper loaded: form_helper
INFO - 2023-09-24 12:33:35 --> Helper loaded: my_helper
INFO - 2023-09-24 12:33:35 --> Database Driver Class Initialized
INFO - 2023-09-24 12:33:35 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-24 12:33:35 --> Controller Class Initialized
INFO - 2023-09-24 12:33:35 --> Final output sent to browser
DEBUG - 2023-09-24 12:33:35 --> Total execution time: 0.0323
INFO - 2023-09-24 12:33:35 --> Config Class Initialized
INFO - 2023-09-24 12:33:35 --> Hooks Class Initialized
DEBUG - 2023-09-24 12:33:35 --> UTF-8 Support Enabled
INFO - 2023-09-24 12:33:35 --> Utf8 Class Initialized
INFO - 2023-09-24 12:33:35 --> URI Class Initialized
INFO - 2023-09-24 12:33:35 --> Router Class Initialized
INFO - 2023-09-24 12:33:35 --> Output Class Initialized
INFO - 2023-09-24 12:33:35 --> Security Class Initialized
DEBUG - 2023-09-24 12:33:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-24 12:33:35 --> Input Class Initialized
INFO - 2023-09-24 12:33:35 --> Language Class Initialized
INFO - 2023-09-24 12:33:35 --> Language Class Initialized
INFO - 2023-09-24 12:33:35 --> Config Class Initialized
INFO - 2023-09-24 12:33:35 --> Loader Class Initialized
INFO - 2023-09-24 12:33:35 --> Helper loaded: url_helper
INFO - 2023-09-24 12:33:35 --> Helper loaded: file_helper
INFO - 2023-09-24 12:33:35 --> Helper loaded: form_helper
INFO - 2023-09-24 12:33:35 --> Helper loaded: my_helper
INFO - 2023-09-24 12:33:35 --> Database Driver Class Initialized
INFO - 2023-09-24 12:33:35 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-24 12:33:35 --> Controller Class Initialized
INFO - 2023-09-24 12:33:36 --> Config Class Initialized
INFO - 2023-09-24 12:33:36 --> Hooks Class Initialized
DEBUG - 2023-09-24 12:33:36 --> UTF-8 Support Enabled
INFO - 2023-09-24 12:33:36 --> Utf8 Class Initialized
INFO - 2023-09-24 12:33:36 --> URI Class Initialized
INFO - 2023-09-24 12:33:36 --> Router Class Initialized
INFO - 2023-09-24 12:33:36 --> Output Class Initialized
INFO - 2023-09-24 12:33:36 --> Security Class Initialized
DEBUG - 2023-09-24 12:33:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-24 12:33:36 --> Input Class Initialized
INFO - 2023-09-24 12:33:36 --> Language Class Initialized
INFO - 2023-09-24 12:33:36 --> Language Class Initialized
INFO - 2023-09-24 12:33:36 --> Config Class Initialized
INFO - 2023-09-24 12:33:36 --> Loader Class Initialized
INFO - 2023-09-24 12:33:36 --> Helper loaded: url_helper
INFO - 2023-09-24 12:33:36 --> Helper loaded: file_helper
INFO - 2023-09-24 12:33:36 --> Helper loaded: form_helper
INFO - 2023-09-24 12:33:36 --> Helper loaded: my_helper
INFO - 2023-09-24 12:33:36 --> Database Driver Class Initialized
INFO - 2023-09-24 12:33:36 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-24 12:33:36 --> Controller Class Initialized
INFO - 2023-09-24 12:33:36 --> Final output sent to browser
DEBUG - 2023-09-24 12:33:36 --> Total execution time: 0.0377
INFO - 2023-09-24 12:33:44 --> Config Class Initialized
INFO - 2023-09-24 12:33:44 --> Hooks Class Initialized
DEBUG - 2023-09-24 12:33:44 --> UTF-8 Support Enabled
INFO - 2023-09-24 12:33:44 --> Utf8 Class Initialized
INFO - 2023-09-24 12:33:44 --> URI Class Initialized
INFO - 2023-09-24 12:33:44 --> Router Class Initialized
INFO - 2023-09-24 12:33:44 --> Output Class Initialized
INFO - 2023-09-24 12:33:44 --> Security Class Initialized
DEBUG - 2023-09-24 12:33:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-24 12:33:44 --> Input Class Initialized
INFO - 2023-09-24 12:33:44 --> Language Class Initialized
INFO - 2023-09-24 12:33:44 --> Language Class Initialized
INFO - 2023-09-24 12:33:44 --> Config Class Initialized
INFO - 2023-09-24 12:33:44 --> Loader Class Initialized
INFO - 2023-09-24 12:33:44 --> Helper loaded: url_helper
INFO - 2023-09-24 12:33:44 --> Helper loaded: file_helper
INFO - 2023-09-24 12:33:44 --> Helper loaded: form_helper
INFO - 2023-09-24 12:33:44 --> Helper loaded: my_helper
INFO - 2023-09-24 12:33:44 --> Database Driver Class Initialized
INFO - 2023-09-24 12:33:44 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-24 12:33:44 --> Controller Class Initialized
INFO - 2023-09-24 12:33:44 --> Final output sent to browser
DEBUG - 2023-09-24 12:33:44 --> Total execution time: 0.0337
INFO - 2023-09-24 12:33:44 --> Config Class Initialized
INFO - 2023-09-24 12:33:44 --> Hooks Class Initialized
DEBUG - 2023-09-24 12:33:44 --> UTF-8 Support Enabled
INFO - 2023-09-24 12:33:44 --> Utf8 Class Initialized
INFO - 2023-09-24 12:33:44 --> URI Class Initialized
INFO - 2023-09-24 12:33:44 --> Router Class Initialized
INFO - 2023-09-24 12:33:44 --> Output Class Initialized
INFO - 2023-09-24 12:33:44 --> Security Class Initialized
DEBUG - 2023-09-24 12:33:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-24 12:33:44 --> Input Class Initialized
INFO - 2023-09-24 12:33:44 --> Language Class Initialized
INFO - 2023-09-24 12:33:44 --> Language Class Initialized
INFO - 2023-09-24 12:33:44 --> Config Class Initialized
INFO - 2023-09-24 12:33:44 --> Loader Class Initialized
INFO - 2023-09-24 12:33:44 --> Helper loaded: url_helper
INFO - 2023-09-24 12:33:44 --> Helper loaded: file_helper
INFO - 2023-09-24 12:33:44 --> Helper loaded: form_helper
INFO - 2023-09-24 12:33:44 --> Helper loaded: my_helper
INFO - 2023-09-24 12:33:44 --> Database Driver Class Initialized
INFO - 2023-09-24 12:33:44 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-24 12:33:44 --> Controller Class Initialized
INFO - 2023-09-24 12:33:50 --> Config Class Initialized
INFO - 2023-09-24 12:33:50 --> Hooks Class Initialized
DEBUG - 2023-09-24 12:33:50 --> UTF-8 Support Enabled
INFO - 2023-09-24 12:33:50 --> Utf8 Class Initialized
INFO - 2023-09-24 12:33:50 --> URI Class Initialized
INFO - 2023-09-24 12:33:50 --> Router Class Initialized
INFO - 2023-09-24 12:33:50 --> Output Class Initialized
INFO - 2023-09-24 12:33:50 --> Security Class Initialized
DEBUG - 2023-09-24 12:33:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-24 12:33:50 --> Input Class Initialized
INFO - 2023-09-24 12:33:50 --> Language Class Initialized
INFO - 2023-09-24 12:33:50 --> Language Class Initialized
INFO - 2023-09-24 12:33:50 --> Config Class Initialized
INFO - 2023-09-24 12:33:50 --> Loader Class Initialized
INFO - 2023-09-24 12:33:50 --> Helper loaded: url_helper
INFO - 2023-09-24 12:33:50 --> Helper loaded: file_helper
INFO - 2023-09-24 12:33:50 --> Helper loaded: form_helper
INFO - 2023-09-24 12:33:50 --> Helper loaded: my_helper
INFO - 2023-09-24 12:33:50 --> Database Driver Class Initialized
INFO - 2023-09-24 12:33:50 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-24 12:33:50 --> Controller Class Initialized
INFO - 2023-09-24 12:33:50 --> Final output sent to browser
DEBUG - 2023-09-24 12:33:50 --> Total execution time: 0.1114
INFO - 2023-09-24 12:33:55 --> Config Class Initialized
INFO - 2023-09-24 12:33:55 --> Hooks Class Initialized
DEBUG - 2023-09-24 12:33:55 --> UTF-8 Support Enabled
INFO - 2023-09-24 12:33:55 --> Utf8 Class Initialized
INFO - 2023-09-24 12:33:55 --> URI Class Initialized
INFO - 2023-09-24 12:33:55 --> Router Class Initialized
INFO - 2023-09-24 12:33:55 --> Output Class Initialized
INFO - 2023-09-24 12:33:55 --> Security Class Initialized
DEBUG - 2023-09-24 12:33:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-24 12:33:55 --> Input Class Initialized
INFO - 2023-09-24 12:33:55 --> Language Class Initialized
INFO - 2023-09-24 12:33:55 --> Language Class Initialized
INFO - 2023-09-24 12:33:55 --> Config Class Initialized
INFO - 2023-09-24 12:33:55 --> Loader Class Initialized
INFO - 2023-09-24 12:33:55 --> Helper loaded: url_helper
INFO - 2023-09-24 12:33:55 --> Helper loaded: file_helper
INFO - 2023-09-24 12:33:55 --> Helper loaded: form_helper
INFO - 2023-09-24 12:33:55 --> Helper loaded: my_helper
INFO - 2023-09-24 12:33:55 --> Database Driver Class Initialized
INFO - 2023-09-24 12:33:55 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-24 12:33:55 --> Controller Class Initialized
INFO - 2023-09-24 12:33:55 --> Final output sent to browser
DEBUG - 2023-09-24 12:33:55 --> Total execution time: 0.0317
INFO - 2023-09-24 12:34:05 --> Config Class Initialized
INFO - 2023-09-24 12:34:05 --> Hooks Class Initialized
DEBUG - 2023-09-24 12:34:05 --> UTF-8 Support Enabled
INFO - 2023-09-24 12:34:05 --> Utf8 Class Initialized
INFO - 2023-09-24 12:34:05 --> URI Class Initialized
INFO - 2023-09-24 12:34:05 --> Router Class Initialized
INFO - 2023-09-24 12:34:05 --> Output Class Initialized
INFO - 2023-09-24 12:34:05 --> Security Class Initialized
DEBUG - 2023-09-24 12:34:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-24 12:34:05 --> Input Class Initialized
INFO - 2023-09-24 12:34:05 --> Language Class Initialized
INFO - 2023-09-24 12:34:05 --> Language Class Initialized
INFO - 2023-09-24 12:34:05 --> Config Class Initialized
INFO - 2023-09-24 12:34:05 --> Loader Class Initialized
INFO - 2023-09-24 12:34:05 --> Helper loaded: url_helper
INFO - 2023-09-24 12:34:05 --> Helper loaded: file_helper
INFO - 2023-09-24 12:34:05 --> Helper loaded: form_helper
INFO - 2023-09-24 12:34:05 --> Helper loaded: my_helper
INFO - 2023-09-24 12:34:05 --> Database Driver Class Initialized
INFO - 2023-09-24 12:34:05 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-24 12:34:05 --> Controller Class Initialized
INFO - 2023-09-24 12:34:05 --> Final output sent to browser
DEBUG - 2023-09-24 12:34:05 --> Total execution time: 0.0338
INFO - 2023-09-24 12:34:05 --> Config Class Initialized
INFO - 2023-09-24 12:34:05 --> Hooks Class Initialized
DEBUG - 2023-09-24 12:34:05 --> UTF-8 Support Enabled
INFO - 2023-09-24 12:34:05 --> Utf8 Class Initialized
INFO - 2023-09-24 12:34:05 --> URI Class Initialized
INFO - 2023-09-24 12:34:05 --> Router Class Initialized
INFO - 2023-09-24 12:34:05 --> Output Class Initialized
INFO - 2023-09-24 12:34:05 --> Security Class Initialized
DEBUG - 2023-09-24 12:34:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-24 12:34:05 --> Input Class Initialized
INFO - 2023-09-24 12:34:05 --> Language Class Initialized
INFO - 2023-09-24 12:34:05 --> Language Class Initialized
INFO - 2023-09-24 12:34:05 --> Config Class Initialized
INFO - 2023-09-24 12:34:05 --> Loader Class Initialized
INFO - 2023-09-24 12:34:05 --> Helper loaded: url_helper
INFO - 2023-09-24 12:34:05 --> Helper loaded: file_helper
INFO - 2023-09-24 12:34:05 --> Helper loaded: form_helper
INFO - 2023-09-24 12:34:05 --> Helper loaded: my_helper
INFO - 2023-09-24 12:34:05 --> Database Driver Class Initialized
INFO - 2023-09-24 12:34:05 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-24 12:34:05 --> Controller Class Initialized
INFO - 2023-09-24 12:34:06 --> Config Class Initialized
INFO - 2023-09-24 12:34:06 --> Hooks Class Initialized
DEBUG - 2023-09-24 12:34:06 --> UTF-8 Support Enabled
INFO - 2023-09-24 12:34:06 --> Utf8 Class Initialized
INFO - 2023-09-24 12:34:06 --> URI Class Initialized
INFO - 2023-09-24 12:34:06 --> Router Class Initialized
INFO - 2023-09-24 12:34:06 --> Output Class Initialized
INFO - 2023-09-24 12:34:06 --> Security Class Initialized
DEBUG - 2023-09-24 12:34:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-24 12:34:06 --> Input Class Initialized
INFO - 2023-09-24 12:34:06 --> Language Class Initialized
INFO - 2023-09-24 12:34:06 --> Language Class Initialized
INFO - 2023-09-24 12:34:06 --> Config Class Initialized
INFO - 2023-09-24 12:34:06 --> Loader Class Initialized
INFO - 2023-09-24 12:34:06 --> Helper loaded: url_helper
INFO - 2023-09-24 12:34:06 --> Helper loaded: file_helper
INFO - 2023-09-24 12:34:06 --> Helper loaded: form_helper
INFO - 2023-09-24 12:34:06 --> Helper loaded: my_helper
INFO - 2023-09-24 12:34:06 --> Database Driver Class Initialized
INFO - 2023-09-24 12:34:06 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-24 12:34:06 --> Controller Class Initialized
INFO - 2023-09-24 12:34:06 --> Final output sent to browser
DEBUG - 2023-09-24 12:34:06 --> Total execution time: 0.0308
INFO - 2023-09-24 12:34:14 --> Config Class Initialized
INFO - 2023-09-24 12:34:14 --> Hooks Class Initialized
DEBUG - 2023-09-24 12:34:14 --> UTF-8 Support Enabled
INFO - 2023-09-24 12:34:14 --> Utf8 Class Initialized
INFO - 2023-09-24 12:34:14 --> URI Class Initialized
INFO - 2023-09-24 12:34:14 --> Router Class Initialized
INFO - 2023-09-24 12:34:14 --> Output Class Initialized
INFO - 2023-09-24 12:34:14 --> Security Class Initialized
DEBUG - 2023-09-24 12:34:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-24 12:34:14 --> Input Class Initialized
INFO - 2023-09-24 12:34:14 --> Language Class Initialized
INFO - 2023-09-24 12:34:14 --> Language Class Initialized
INFO - 2023-09-24 12:34:14 --> Config Class Initialized
INFO - 2023-09-24 12:34:14 --> Loader Class Initialized
INFO - 2023-09-24 12:34:14 --> Helper loaded: url_helper
INFO - 2023-09-24 12:34:14 --> Helper loaded: file_helper
INFO - 2023-09-24 12:34:14 --> Helper loaded: form_helper
INFO - 2023-09-24 12:34:14 --> Helper loaded: my_helper
INFO - 2023-09-24 12:34:14 --> Database Driver Class Initialized
INFO - 2023-09-24 12:34:14 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-24 12:34:14 --> Controller Class Initialized
INFO - 2023-09-24 12:34:14 --> Final output sent to browser
DEBUG - 2023-09-24 12:34:14 --> Total execution time: 0.0341
INFO - 2023-09-24 12:34:14 --> Config Class Initialized
INFO - 2023-09-24 12:34:14 --> Hooks Class Initialized
DEBUG - 2023-09-24 12:34:14 --> UTF-8 Support Enabled
INFO - 2023-09-24 12:34:14 --> Utf8 Class Initialized
INFO - 2023-09-24 12:34:14 --> URI Class Initialized
INFO - 2023-09-24 12:34:14 --> Router Class Initialized
INFO - 2023-09-24 12:34:14 --> Output Class Initialized
INFO - 2023-09-24 12:34:14 --> Security Class Initialized
DEBUG - 2023-09-24 12:34:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-24 12:34:14 --> Input Class Initialized
INFO - 2023-09-24 12:34:14 --> Language Class Initialized
INFO - 2023-09-24 12:34:14 --> Language Class Initialized
INFO - 2023-09-24 12:34:14 --> Config Class Initialized
INFO - 2023-09-24 12:34:14 --> Loader Class Initialized
INFO - 2023-09-24 12:34:14 --> Helper loaded: url_helper
INFO - 2023-09-24 12:34:14 --> Helper loaded: file_helper
INFO - 2023-09-24 12:34:14 --> Helper loaded: form_helper
INFO - 2023-09-24 12:34:14 --> Helper loaded: my_helper
INFO - 2023-09-24 12:34:14 --> Database Driver Class Initialized
INFO - 2023-09-24 12:34:14 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-24 12:34:14 --> Controller Class Initialized
INFO - 2023-09-24 12:34:59 --> Config Class Initialized
INFO - 2023-09-24 12:34:59 --> Hooks Class Initialized
DEBUG - 2023-09-24 12:34:59 --> UTF-8 Support Enabled
INFO - 2023-09-24 12:34:59 --> Utf8 Class Initialized
INFO - 2023-09-24 12:34:59 --> URI Class Initialized
INFO - 2023-09-24 12:34:59 --> Router Class Initialized
INFO - 2023-09-24 12:34:59 --> Output Class Initialized
INFO - 2023-09-24 12:34:59 --> Security Class Initialized
DEBUG - 2023-09-24 12:34:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-24 12:34:59 --> Input Class Initialized
INFO - 2023-09-24 12:34:59 --> Language Class Initialized
INFO - 2023-09-24 12:34:59 --> Language Class Initialized
INFO - 2023-09-24 12:34:59 --> Config Class Initialized
INFO - 2023-09-24 12:34:59 --> Loader Class Initialized
INFO - 2023-09-24 12:34:59 --> Helper loaded: url_helper
INFO - 2023-09-24 12:34:59 --> Helper loaded: file_helper
INFO - 2023-09-24 12:34:59 --> Helper loaded: form_helper
INFO - 2023-09-24 12:34:59 --> Helper loaded: my_helper
INFO - 2023-09-24 12:34:59 --> Database Driver Class Initialized
INFO - 2023-09-24 12:34:59 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-24 12:34:59 --> Controller Class Initialized
INFO - 2023-09-24 12:34:59 --> Final output sent to browser
DEBUG - 2023-09-24 12:34:59 --> Total execution time: 0.0394
INFO - 2023-09-24 12:35:09 --> Config Class Initialized
INFO - 2023-09-24 12:35:09 --> Hooks Class Initialized
DEBUG - 2023-09-24 12:35:09 --> UTF-8 Support Enabled
INFO - 2023-09-24 12:35:09 --> Utf8 Class Initialized
INFO - 2023-09-24 12:35:09 --> URI Class Initialized
INFO - 2023-09-24 12:35:09 --> Router Class Initialized
INFO - 2023-09-24 12:35:09 --> Output Class Initialized
INFO - 2023-09-24 12:35:09 --> Security Class Initialized
DEBUG - 2023-09-24 12:35:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-24 12:35:09 --> Input Class Initialized
INFO - 2023-09-24 12:35:09 --> Language Class Initialized
INFO - 2023-09-24 12:35:09 --> Language Class Initialized
INFO - 2023-09-24 12:35:09 --> Config Class Initialized
INFO - 2023-09-24 12:35:09 --> Loader Class Initialized
INFO - 2023-09-24 12:35:09 --> Helper loaded: url_helper
INFO - 2023-09-24 12:35:09 --> Helper loaded: file_helper
INFO - 2023-09-24 12:35:09 --> Helper loaded: form_helper
INFO - 2023-09-24 12:35:09 --> Helper loaded: my_helper
INFO - 2023-09-24 12:35:09 --> Database Driver Class Initialized
INFO - 2023-09-24 12:35:09 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-24 12:35:09 --> Controller Class Initialized
INFO - 2023-09-24 12:35:09 --> Final output sent to browser
DEBUG - 2023-09-24 12:35:09 --> Total execution time: 0.0349
INFO - 2023-09-24 12:35:09 --> Config Class Initialized
INFO - 2023-09-24 12:35:09 --> Hooks Class Initialized
DEBUG - 2023-09-24 12:35:09 --> UTF-8 Support Enabled
INFO - 2023-09-24 12:35:09 --> Utf8 Class Initialized
INFO - 2023-09-24 12:35:09 --> URI Class Initialized
INFO - 2023-09-24 12:35:09 --> Router Class Initialized
INFO - 2023-09-24 12:35:09 --> Output Class Initialized
INFO - 2023-09-24 12:35:09 --> Security Class Initialized
DEBUG - 2023-09-24 12:35:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-24 12:35:09 --> Input Class Initialized
INFO - 2023-09-24 12:35:09 --> Language Class Initialized
INFO - 2023-09-24 12:35:09 --> Language Class Initialized
INFO - 2023-09-24 12:35:09 --> Config Class Initialized
INFO - 2023-09-24 12:35:09 --> Loader Class Initialized
INFO - 2023-09-24 12:35:09 --> Helper loaded: url_helper
INFO - 2023-09-24 12:35:09 --> Helper loaded: file_helper
INFO - 2023-09-24 12:35:09 --> Helper loaded: form_helper
INFO - 2023-09-24 12:35:09 --> Helper loaded: my_helper
INFO - 2023-09-24 12:35:09 --> Database Driver Class Initialized
INFO - 2023-09-24 12:35:09 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-24 12:35:09 --> Controller Class Initialized
INFO - 2023-09-24 12:35:10 --> Config Class Initialized
INFO - 2023-09-24 12:35:10 --> Hooks Class Initialized
DEBUG - 2023-09-24 12:35:10 --> UTF-8 Support Enabled
INFO - 2023-09-24 12:35:10 --> Utf8 Class Initialized
INFO - 2023-09-24 12:35:10 --> URI Class Initialized
INFO - 2023-09-24 12:35:10 --> Router Class Initialized
INFO - 2023-09-24 12:35:10 --> Output Class Initialized
INFO - 2023-09-24 12:35:10 --> Security Class Initialized
DEBUG - 2023-09-24 12:35:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-24 12:35:10 --> Input Class Initialized
INFO - 2023-09-24 12:35:10 --> Language Class Initialized
INFO - 2023-09-24 12:35:10 --> Language Class Initialized
INFO - 2023-09-24 12:35:10 --> Config Class Initialized
INFO - 2023-09-24 12:35:10 --> Loader Class Initialized
INFO - 2023-09-24 12:35:10 --> Helper loaded: url_helper
INFO - 2023-09-24 12:35:10 --> Helper loaded: file_helper
INFO - 2023-09-24 12:35:10 --> Helper loaded: form_helper
INFO - 2023-09-24 12:35:10 --> Helper loaded: my_helper
INFO - 2023-09-24 12:35:10 --> Database Driver Class Initialized
INFO - 2023-09-24 12:35:10 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-24 12:35:10 --> Controller Class Initialized
INFO - 2023-09-24 12:35:10 --> Final output sent to browser
DEBUG - 2023-09-24 12:35:10 --> Total execution time: 0.0302
INFO - 2023-09-24 12:35:19 --> Config Class Initialized
INFO - 2023-09-24 12:35:19 --> Hooks Class Initialized
DEBUG - 2023-09-24 12:35:19 --> UTF-8 Support Enabled
INFO - 2023-09-24 12:35:19 --> Utf8 Class Initialized
INFO - 2023-09-24 12:35:19 --> URI Class Initialized
INFO - 2023-09-24 12:35:19 --> Router Class Initialized
INFO - 2023-09-24 12:35:19 --> Output Class Initialized
INFO - 2023-09-24 12:35:19 --> Security Class Initialized
DEBUG - 2023-09-24 12:35:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-24 12:35:19 --> Input Class Initialized
INFO - 2023-09-24 12:35:19 --> Language Class Initialized
INFO - 2023-09-24 12:35:19 --> Language Class Initialized
INFO - 2023-09-24 12:35:19 --> Config Class Initialized
INFO - 2023-09-24 12:35:19 --> Loader Class Initialized
INFO - 2023-09-24 12:35:19 --> Helper loaded: url_helper
INFO - 2023-09-24 12:35:19 --> Helper loaded: file_helper
INFO - 2023-09-24 12:35:19 --> Helper loaded: form_helper
INFO - 2023-09-24 12:35:19 --> Helper loaded: my_helper
INFO - 2023-09-24 12:35:19 --> Database Driver Class Initialized
INFO - 2023-09-24 12:35:19 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-24 12:35:19 --> Controller Class Initialized
INFO - 2023-09-24 12:35:19 --> Final output sent to browser
DEBUG - 2023-09-24 12:35:19 --> Total execution time: 0.0415
INFO - 2023-09-24 12:35:19 --> Config Class Initialized
INFO - 2023-09-24 12:35:19 --> Hooks Class Initialized
DEBUG - 2023-09-24 12:35:19 --> UTF-8 Support Enabled
INFO - 2023-09-24 12:35:19 --> Utf8 Class Initialized
INFO - 2023-09-24 12:35:19 --> URI Class Initialized
INFO - 2023-09-24 12:35:19 --> Router Class Initialized
INFO - 2023-09-24 12:35:19 --> Output Class Initialized
INFO - 2023-09-24 12:35:19 --> Security Class Initialized
DEBUG - 2023-09-24 12:35:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-24 12:35:19 --> Input Class Initialized
INFO - 2023-09-24 12:35:19 --> Language Class Initialized
INFO - 2023-09-24 12:35:19 --> Language Class Initialized
INFO - 2023-09-24 12:35:19 --> Config Class Initialized
INFO - 2023-09-24 12:35:19 --> Loader Class Initialized
INFO - 2023-09-24 12:35:19 --> Helper loaded: url_helper
INFO - 2023-09-24 12:35:19 --> Helper loaded: file_helper
INFO - 2023-09-24 12:35:19 --> Helper loaded: form_helper
INFO - 2023-09-24 12:35:19 --> Helper loaded: my_helper
INFO - 2023-09-24 12:35:19 --> Database Driver Class Initialized
INFO - 2023-09-24 12:35:19 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-24 12:35:19 --> Controller Class Initialized
INFO - 2023-09-24 12:35:20 --> Config Class Initialized
INFO - 2023-09-24 12:35:20 --> Hooks Class Initialized
DEBUG - 2023-09-24 12:35:20 --> UTF-8 Support Enabled
INFO - 2023-09-24 12:35:20 --> Utf8 Class Initialized
INFO - 2023-09-24 12:35:20 --> URI Class Initialized
INFO - 2023-09-24 12:35:20 --> Router Class Initialized
INFO - 2023-09-24 12:35:20 --> Output Class Initialized
INFO - 2023-09-24 12:35:20 --> Security Class Initialized
DEBUG - 2023-09-24 12:35:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-24 12:35:20 --> Input Class Initialized
INFO - 2023-09-24 12:35:20 --> Language Class Initialized
INFO - 2023-09-24 12:35:20 --> Language Class Initialized
INFO - 2023-09-24 12:35:20 --> Config Class Initialized
INFO - 2023-09-24 12:35:20 --> Loader Class Initialized
INFO - 2023-09-24 12:35:20 --> Helper loaded: url_helper
INFO - 2023-09-24 12:35:20 --> Helper loaded: file_helper
INFO - 2023-09-24 12:35:20 --> Helper loaded: form_helper
INFO - 2023-09-24 12:35:20 --> Helper loaded: my_helper
INFO - 2023-09-24 12:35:20 --> Database Driver Class Initialized
INFO - 2023-09-24 12:35:20 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-24 12:35:20 --> Controller Class Initialized
INFO - 2023-09-24 12:35:20 --> Final output sent to browser
DEBUG - 2023-09-24 12:35:20 --> Total execution time: 0.1008
INFO - 2023-09-24 12:35:32 --> Config Class Initialized
INFO - 2023-09-24 12:35:32 --> Hooks Class Initialized
DEBUG - 2023-09-24 12:35:32 --> UTF-8 Support Enabled
INFO - 2023-09-24 12:35:32 --> Utf8 Class Initialized
INFO - 2023-09-24 12:35:32 --> URI Class Initialized
INFO - 2023-09-24 12:35:32 --> Router Class Initialized
INFO - 2023-09-24 12:35:32 --> Output Class Initialized
INFO - 2023-09-24 12:35:32 --> Security Class Initialized
DEBUG - 2023-09-24 12:35:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-24 12:35:32 --> Input Class Initialized
INFO - 2023-09-24 12:35:32 --> Language Class Initialized
INFO - 2023-09-24 12:35:32 --> Language Class Initialized
INFO - 2023-09-24 12:35:32 --> Config Class Initialized
INFO - 2023-09-24 12:35:32 --> Loader Class Initialized
INFO - 2023-09-24 12:35:32 --> Helper loaded: url_helper
INFO - 2023-09-24 12:35:32 --> Helper loaded: file_helper
INFO - 2023-09-24 12:35:32 --> Helper loaded: form_helper
INFO - 2023-09-24 12:35:32 --> Helper loaded: my_helper
INFO - 2023-09-24 12:35:32 --> Database Driver Class Initialized
INFO - 2023-09-24 12:35:32 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-24 12:35:32 --> Controller Class Initialized
INFO - 2023-09-24 12:35:32 --> Final output sent to browser
DEBUG - 2023-09-24 12:35:32 --> Total execution time: 0.0333
INFO - 2023-09-24 12:35:32 --> Config Class Initialized
INFO - 2023-09-24 12:35:32 --> Hooks Class Initialized
DEBUG - 2023-09-24 12:35:32 --> UTF-8 Support Enabled
INFO - 2023-09-24 12:35:32 --> Utf8 Class Initialized
INFO - 2023-09-24 12:35:32 --> URI Class Initialized
INFO - 2023-09-24 12:35:32 --> Router Class Initialized
INFO - 2023-09-24 12:35:32 --> Output Class Initialized
INFO - 2023-09-24 12:35:32 --> Security Class Initialized
DEBUG - 2023-09-24 12:35:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-24 12:35:32 --> Input Class Initialized
INFO - 2023-09-24 12:35:32 --> Language Class Initialized
INFO - 2023-09-24 12:35:32 --> Language Class Initialized
INFO - 2023-09-24 12:35:32 --> Config Class Initialized
INFO - 2023-09-24 12:35:32 --> Loader Class Initialized
INFO - 2023-09-24 12:35:32 --> Helper loaded: url_helper
INFO - 2023-09-24 12:35:32 --> Helper loaded: file_helper
INFO - 2023-09-24 12:35:32 --> Helper loaded: form_helper
INFO - 2023-09-24 12:35:32 --> Helper loaded: my_helper
INFO - 2023-09-24 12:35:32 --> Database Driver Class Initialized
INFO - 2023-09-24 12:35:32 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-24 12:35:32 --> Controller Class Initialized
INFO - 2023-09-24 12:35:37 --> Config Class Initialized
INFO - 2023-09-24 12:35:37 --> Hooks Class Initialized
DEBUG - 2023-09-24 12:35:37 --> UTF-8 Support Enabled
INFO - 2023-09-24 12:35:37 --> Utf8 Class Initialized
INFO - 2023-09-24 12:35:37 --> URI Class Initialized
INFO - 2023-09-24 12:35:37 --> Router Class Initialized
INFO - 2023-09-24 12:35:37 --> Output Class Initialized
INFO - 2023-09-24 12:35:37 --> Security Class Initialized
DEBUG - 2023-09-24 12:35:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-24 12:35:37 --> Input Class Initialized
INFO - 2023-09-24 12:35:37 --> Language Class Initialized
INFO - 2023-09-24 12:35:37 --> Language Class Initialized
INFO - 2023-09-24 12:35:37 --> Config Class Initialized
INFO - 2023-09-24 12:35:37 --> Loader Class Initialized
INFO - 2023-09-24 12:35:37 --> Helper loaded: url_helper
INFO - 2023-09-24 12:35:37 --> Helper loaded: file_helper
INFO - 2023-09-24 12:35:37 --> Helper loaded: form_helper
INFO - 2023-09-24 12:35:37 --> Helper loaded: my_helper
INFO - 2023-09-24 12:35:37 --> Database Driver Class Initialized
INFO - 2023-09-24 12:35:37 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-24 12:35:37 --> Controller Class Initialized
INFO - 2023-09-24 12:35:37 --> Final output sent to browser
DEBUG - 2023-09-24 12:35:37 --> Total execution time: 0.0310
INFO - 2023-09-24 12:35:48 --> Config Class Initialized
INFO - 2023-09-24 12:35:48 --> Hooks Class Initialized
DEBUG - 2023-09-24 12:35:48 --> UTF-8 Support Enabled
INFO - 2023-09-24 12:35:48 --> Utf8 Class Initialized
INFO - 2023-09-24 12:35:48 --> URI Class Initialized
INFO - 2023-09-24 12:35:48 --> Router Class Initialized
INFO - 2023-09-24 12:35:48 --> Output Class Initialized
INFO - 2023-09-24 12:35:48 --> Security Class Initialized
DEBUG - 2023-09-24 12:35:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-24 12:35:48 --> Input Class Initialized
INFO - 2023-09-24 12:35:48 --> Language Class Initialized
INFO - 2023-09-24 12:35:48 --> Language Class Initialized
INFO - 2023-09-24 12:35:48 --> Config Class Initialized
INFO - 2023-09-24 12:35:48 --> Loader Class Initialized
INFO - 2023-09-24 12:35:48 --> Helper loaded: url_helper
INFO - 2023-09-24 12:35:48 --> Helper loaded: file_helper
INFO - 2023-09-24 12:35:48 --> Helper loaded: form_helper
INFO - 2023-09-24 12:35:48 --> Helper loaded: my_helper
INFO - 2023-09-24 12:35:48 --> Database Driver Class Initialized
INFO - 2023-09-24 12:35:48 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-24 12:35:48 --> Controller Class Initialized
INFO - 2023-09-24 12:35:48 --> Final output sent to browser
DEBUG - 2023-09-24 12:35:48 --> Total execution time: 0.0403
INFO - 2023-09-24 12:35:49 --> Config Class Initialized
INFO - 2023-09-24 12:35:49 --> Hooks Class Initialized
DEBUG - 2023-09-24 12:35:49 --> UTF-8 Support Enabled
INFO - 2023-09-24 12:35:49 --> Utf8 Class Initialized
INFO - 2023-09-24 12:35:49 --> URI Class Initialized
INFO - 2023-09-24 12:35:49 --> Router Class Initialized
INFO - 2023-09-24 12:35:49 --> Output Class Initialized
INFO - 2023-09-24 12:35:49 --> Security Class Initialized
DEBUG - 2023-09-24 12:35:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-24 12:35:49 --> Input Class Initialized
INFO - 2023-09-24 12:35:49 --> Language Class Initialized
INFO - 2023-09-24 12:35:49 --> Language Class Initialized
INFO - 2023-09-24 12:35:49 --> Config Class Initialized
INFO - 2023-09-24 12:35:49 --> Loader Class Initialized
INFO - 2023-09-24 12:35:49 --> Helper loaded: url_helper
INFO - 2023-09-24 12:35:49 --> Helper loaded: file_helper
INFO - 2023-09-24 12:35:49 --> Helper loaded: form_helper
INFO - 2023-09-24 12:35:49 --> Helper loaded: my_helper
INFO - 2023-09-24 12:35:49 --> Database Driver Class Initialized
INFO - 2023-09-24 12:35:49 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-24 12:35:49 --> Controller Class Initialized
INFO - 2023-09-24 12:35:49 --> Config Class Initialized
INFO - 2023-09-24 12:35:49 --> Hooks Class Initialized
DEBUG - 2023-09-24 12:35:49 --> UTF-8 Support Enabled
INFO - 2023-09-24 12:35:49 --> Utf8 Class Initialized
INFO - 2023-09-24 12:35:49 --> URI Class Initialized
INFO - 2023-09-24 12:35:49 --> Router Class Initialized
INFO - 2023-09-24 12:35:49 --> Output Class Initialized
INFO - 2023-09-24 12:35:49 --> Security Class Initialized
DEBUG - 2023-09-24 12:35:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-24 12:35:49 --> Input Class Initialized
INFO - 2023-09-24 12:35:49 --> Language Class Initialized
INFO - 2023-09-24 12:35:49 --> Language Class Initialized
INFO - 2023-09-24 12:35:49 --> Config Class Initialized
INFO - 2023-09-24 12:35:49 --> Loader Class Initialized
INFO - 2023-09-24 12:35:49 --> Helper loaded: url_helper
INFO - 2023-09-24 12:35:49 --> Helper loaded: file_helper
INFO - 2023-09-24 12:35:49 --> Helper loaded: form_helper
INFO - 2023-09-24 12:35:49 --> Helper loaded: my_helper
INFO - 2023-09-24 12:35:49 --> Database Driver Class Initialized
INFO - 2023-09-24 12:35:49 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-24 12:35:49 --> Controller Class Initialized
INFO - 2023-09-24 12:35:49 --> Final output sent to browser
DEBUG - 2023-09-24 12:35:49 --> Total execution time: 0.0345
INFO - 2023-09-24 12:35:58 --> Config Class Initialized
INFO - 2023-09-24 12:35:58 --> Hooks Class Initialized
DEBUG - 2023-09-24 12:35:58 --> UTF-8 Support Enabled
INFO - 2023-09-24 12:35:58 --> Utf8 Class Initialized
INFO - 2023-09-24 12:35:58 --> URI Class Initialized
INFO - 2023-09-24 12:35:58 --> Router Class Initialized
INFO - 2023-09-24 12:35:58 --> Output Class Initialized
INFO - 2023-09-24 12:35:58 --> Security Class Initialized
DEBUG - 2023-09-24 12:35:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-24 12:35:58 --> Input Class Initialized
INFO - 2023-09-24 12:35:58 --> Language Class Initialized
INFO - 2023-09-24 12:35:58 --> Language Class Initialized
INFO - 2023-09-24 12:35:58 --> Config Class Initialized
INFO - 2023-09-24 12:35:58 --> Loader Class Initialized
INFO - 2023-09-24 12:35:58 --> Helper loaded: url_helper
INFO - 2023-09-24 12:35:58 --> Helper loaded: file_helper
INFO - 2023-09-24 12:35:58 --> Helper loaded: form_helper
INFO - 2023-09-24 12:35:58 --> Helper loaded: my_helper
INFO - 2023-09-24 12:35:58 --> Database Driver Class Initialized
INFO - 2023-09-24 12:35:58 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-24 12:35:58 --> Controller Class Initialized
INFO - 2023-09-24 12:35:58 --> Final output sent to browser
DEBUG - 2023-09-24 12:35:58 --> Total execution time: 0.0301
INFO - 2023-09-24 12:35:58 --> Config Class Initialized
INFO - 2023-09-24 12:35:58 --> Hooks Class Initialized
DEBUG - 2023-09-24 12:35:58 --> UTF-8 Support Enabled
INFO - 2023-09-24 12:35:58 --> Utf8 Class Initialized
INFO - 2023-09-24 12:35:58 --> URI Class Initialized
INFO - 2023-09-24 12:35:58 --> Router Class Initialized
INFO - 2023-09-24 12:35:58 --> Output Class Initialized
INFO - 2023-09-24 12:35:58 --> Security Class Initialized
DEBUG - 2023-09-24 12:35:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-24 12:35:58 --> Input Class Initialized
INFO - 2023-09-24 12:35:58 --> Language Class Initialized
INFO - 2023-09-24 12:35:58 --> Language Class Initialized
INFO - 2023-09-24 12:35:58 --> Config Class Initialized
INFO - 2023-09-24 12:35:58 --> Loader Class Initialized
INFO - 2023-09-24 12:35:58 --> Helper loaded: url_helper
INFO - 2023-09-24 12:35:58 --> Helper loaded: file_helper
INFO - 2023-09-24 12:35:58 --> Helper loaded: form_helper
INFO - 2023-09-24 12:35:58 --> Helper loaded: my_helper
INFO - 2023-09-24 12:35:58 --> Database Driver Class Initialized
INFO - 2023-09-24 12:35:58 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-24 12:35:58 --> Controller Class Initialized
INFO - 2023-09-24 12:35:59 --> Config Class Initialized
INFO - 2023-09-24 12:35:59 --> Hooks Class Initialized
DEBUG - 2023-09-24 12:35:59 --> UTF-8 Support Enabled
INFO - 2023-09-24 12:35:59 --> Utf8 Class Initialized
INFO - 2023-09-24 12:35:59 --> URI Class Initialized
INFO - 2023-09-24 12:35:59 --> Router Class Initialized
INFO - 2023-09-24 12:35:59 --> Output Class Initialized
INFO - 2023-09-24 12:35:59 --> Security Class Initialized
DEBUG - 2023-09-24 12:35:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-24 12:35:59 --> Input Class Initialized
INFO - 2023-09-24 12:35:59 --> Language Class Initialized
INFO - 2023-09-24 12:35:59 --> Language Class Initialized
INFO - 2023-09-24 12:35:59 --> Config Class Initialized
INFO - 2023-09-24 12:35:59 --> Loader Class Initialized
INFO - 2023-09-24 12:35:59 --> Helper loaded: url_helper
INFO - 2023-09-24 12:35:59 --> Helper loaded: file_helper
INFO - 2023-09-24 12:35:59 --> Helper loaded: form_helper
INFO - 2023-09-24 12:35:59 --> Helper loaded: my_helper
INFO - 2023-09-24 12:35:59 --> Database Driver Class Initialized
INFO - 2023-09-24 12:35:59 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-24 12:35:59 --> Controller Class Initialized
INFO - 2023-09-24 12:35:59 --> Final output sent to browser
DEBUG - 2023-09-24 12:35:59 --> Total execution time: 0.0322
INFO - 2023-09-24 12:36:12 --> Config Class Initialized
INFO - 2023-09-24 12:36:12 --> Hooks Class Initialized
DEBUG - 2023-09-24 12:36:12 --> UTF-8 Support Enabled
INFO - 2023-09-24 12:36:12 --> Utf8 Class Initialized
INFO - 2023-09-24 12:36:12 --> URI Class Initialized
INFO - 2023-09-24 12:36:12 --> Router Class Initialized
INFO - 2023-09-24 12:36:12 --> Output Class Initialized
INFO - 2023-09-24 12:36:12 --> Security Class Initialized
DEBUG - 2023-09-24 12:36:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-24 12:36:12 --> Input Class Initialized
INFO - 2023-09-24 12:36:12 --> Language Class Initialized
INFO - 2023-09-24 12:36:12 --> Language Class Initialized
INFO - 2023-09-24 12:36:12 --> Config Class Initialized
INFO - 2023-09-24 12:36:12 --> Loader Class Initialized
INFO - 2023-09-24 12:36:12 --> Helper loaded: url_helper
INFO - 2023-09-24 12:36:12 --> Helper loaded: file_helper
INFO - 2023-09-24 12:36:12 --> Helper loaded: form_helper
INFO - 2023-09-24 12:36:12 --> Helper loaded: my_helper
INFO - 2023-09-24 12:36:12 --> Database Driver Class Initialized
INFO - 2023-09-24 12:36:12 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-24 12:36:12 --> Controller Class Initialized
INFO - 2023-09-24 12:36:12 --> Final output sent to browser
DEBUG - 2023-09-24 12:36:12 --> Total execution time: 0.0430
INFO - 2023-09-24 12:36:12 --> Config Class Initialized
INFO - 2023-09-24 12:36:12 --> Hooks Class Initialized
DEBUG - 2023-09-24 12:36:12 --> UTF-8 Support Enabled
INFO - 2023-09-24 12:36:12 --> Utf8 Class Initialized
INFO - 2023-09-24 12:36:12 --> URI Class Initialized
INFO - 2023-09-24 12:36:12 --> Router Class Initialized
INFO - 2023-09-24 12:36:12 --> Output Class Initialized
INFO - 2023-09-24 12:36:12 --> Security Class Initialized
DEBUG - 2023-09-24 12:36:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-24 12:36:12 --> Input Class Initialized
INFO - 2023-09-24 12:36:12 --> Language Class Initialized
INFO - 2023-09-24 12:36:12 --> Language Class Initialized
INFO - 2023-09-24 12:36:12 --> Config Class Initialized
INFO - 2023-09-24 12:36:12 --> Loader Class Initialized
INFO - 2023-09-24 12:36:12 --> Helper loaded: url_helper
INFO - 2023-09-24 12:36:12 --> Helper loaded: file_helper
INFO - 2023-09-24 12:36:12 --> Helper loaded: form_helper
INFO - 2023-09-24 12:36:12 --> Helper loaded: my_helper
INFO - 2023-09-24 12:36:12 --> Database Driver Class Initialized
INFO - 2023-09-24 12:36:12 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-24 12:36:12 --> Controller Class Initialized
INFO - 2023-09-24 12:36:14 --> Config Class Initialized
INFO - 2023-09-24 12:36:14 --> Hooks Class Initialized
DEBUG - 2023-09-24 12:36:14 --> UTF-8 Support Enabled
INFO - 2023-09-24 12:36:14 --> Utf8 Class Initialized
INFO - 2023-09-24 12:36:14 --> URI Class Initialized
INFO - 2023-09-24 12:36:14 --> Router Class Initialized
INFO - 2023-09-24 12:36:14 --> Output Class Initialized
INFO - 2023-09-24 12:36:14 --> Security Class Initialized
DEBUG - 2023-09-24 12:36:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-24 12:36:14 --> Input Class Initialized
INFO - 2023-09-24 12:36:14 --> Language Class Initialized
INFO - 2023-09-24 12:36:14 --> Language Class Initialized
INFO - 2023-09-24 12:36:14 --> Config Class Initialized
INFO - 2023-09-24 12:36:14 --> Loader Class Initialized
INFO - 2023-09-24 12:36:14 --> Helper loaded: url_helper
INFO - 2023-09-24 12:36:14 --> Helper loaded: file_helper
INFO - 2023-09-24 12:36:14 --> Helper loaded: form_helper
INFO - 2023-09-24 12:36:14 --> Helper loaded: my_helper
INFO - 2023-09-24 12:36:14 --> Database Driver Class Initialized
INFO - 2023-09-24 12:36:14 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-24 12:36:14 --> Controller Class Initialized
INFO - 2023-09-24 12:36:14 --> Final output sent to browser
DEBUG - 2023-09-24 12:36:14 --> Total execution time: 0.0323
INFO - 2023-09-24 12:36:34 --> Config Class Initialized
INFO - 2023-09-24 12:36:34 --> Hooks Class Initialized
DEBUG - 2023-09-24 12:36:34 --> UTF-8 Support Enabled
INFO - 2023-09-24 12:36:34 --> Utf8 Class Initialized
INFO - 2023-09-24 12:36:34 --> URI Class Initialized
INFO - 2023-09-24 12:36:34 --> Router Class Initialized
INFO - 2023-09-24 12:36:34 --> Output Class Initialized
INFO - 2023-09-24 12:36:34 --> Security Class Initialized
DEBUG - 2023-09-24 12:36:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-24 12:36:34 --> Input Class Initialized
INFO - 2023-09-24 12:36:34 --> Language Class Initialized
INFO - 2023-09-24 12:36:34 --> Language Class Initialized
INFO - 2023-09-24 12:36:34 --> Config Class Initialized
INFO - 2023-09-24 12:36:34 --> Loader Class Initialized
INFO - 2023-09-24 12:36:34 --> Helper loaded: url_helper
INFO - 2023-09-24 12:36:34 --> Helper loaded: file_helper
INFO - 2023-09-24 12:36:34 --> Helper loaded: form_helper
INFO - 2023-09-24 12:36:34 --> Helper loaded: my_helper
INFO - 2023-09-24 12:36:34 --> Database Driver Class Initialized
INFO - 2023-09-24 12:36:34 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-24 12:36:34 --> Controller Class Initialized
INFO - 2023-09-24 12:36:34 --> Final output sent to browser
DEBUG - 2023-09-24 12:36:34 --> Total execution time: 0.0308
INFO - 2023-09-24 12:36:37 --> Config Class Initialized
INFO - 2023-09-24 12:36:37 --> Hooks Class Initialized
DEBUG - 2023-09-24 12:36:37 --> UTF-8 Support Enabled
INFO - 2023-09-24 12:36:37 --> Utf8 Class Initialized
INFO - 2023-09-24 12:36:37 --> URI Class Initialized
INFO - 2023-09-24 12:36:37 --> Router Class Initialized
INFO - 2023-09-24 12:36:37 --> Output Class Initialized
INFO - 2023-09-24 12:36:37 --> Security Class Initialized
DEBUG - 2023-09-24 12:36:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-24 12:36:37 --> Input Class Initialized
INFO - 2023-09-24 12:36:37 --> Language Class Initialized
INFO - 2023-09-24 12:36:37 --> Language Class Initialized
INFO - 2023-09-24 12:36:37 --> Config Class Initialized
INFO - 2023-09-24 12:36:37 --> Loader Class Initialized
INFO - 2023-09-24 12:36:37 --> Helper loaded: url_helper
INFO - 2023-09-24 12:36:37 --> Helper loaded: file_helper
INFO - 2023-09-24 12:36:37 --> Helper loaded: form_helper
INFO - 2023-09-24 12:36:37 --> Helper loaded: my_helper
INFO - 2023-09-24 12:36:37 --> Database Driver Class Initialized
INFO - 2023-09-24 12:36:37 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-24 12:36:37 --> Controller Class Initialized
INFO - 2023-09-24 12:36:37 --> Final output sent to browser
DEBUG - 2023-09-24 12:36:37 --> Total execution time: 0.0359
INFO - 2023-09-24 12:36:37 --> Config Class Initialized
INFO - 2023-09-24 12:36:37 --> Hooks Class Initialized
DEBUG - 2023-09-24 12:36:37 --> UTF-8 Support Enabled
INFO - 2023-09-24 12:36:37 --> Utf8 Class Initialized
INFO - 2023-09-24 12:36:37 --> URI Class Initialized
INFO - 2023-09-24 12:36:37 --> Router Class Initialized
INFO - 2023-09-24 12:36:37 --> Output Class Initialized
INFO - 2023-09-24 12:36:37 --> Security Class Initialized
DEBUG - 2023-09-24 12:36:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-24 12:36:37 --> Input Class Initialized
INFO - 2023-09-24 12:36:37 --> Language Class Initialized
INFO - 2023-09-24 12:36:37 --> Language Class Initialized
INFO - 2023-09-24 12:36:37 --> Config Class Initialized
INFO - 2023-09-24 12:36:37 --> Loader Class Initialized
INFO - 2023-09-24 12:36:37 --> Helper loaded: url_helper
INFO - 2023-09-24 12:36:37 --> Helper loaded: file_helper
INFO - 2023-09-24 12:36:37 --> Helper loaded: form_helper
INFO - 2023-09-24 12:36:37 --> Helper loaded: my_helper
INFO - 2023-09-24 12:36:37 --> Database Driver Class Initialized
INFO - 2023-09-24 12:36:37 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-24 12:36:37 --> Controller Class Initialized
INFO - 2023-09-24 12:36:46 --> Config Class Initialized
INFO - 2023-09-24 12:36:46 --> Hooks Class Initialized
DEBUG - 2023-09-24 12:36:46 --> UTF-8 Support Enabled
INFO - 2023-09-24 12:36:46 --> Utf8 Class Initialized
INFO - 2023-09-24 12:36:46 --> URI Class Initialized
INFO - 2023-09-24 12:36:46 --> Router Class Initialized
INFO - 2023-09-24 12:36:46 --> Output Class Initialized
INFO - 2023-09-24 12:36:46 --> Security Class Initialized
DEBUG - 2023-09-24 12:36:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-24 12:36:46 --> Input Class Initialized
INFO - 2023-09-24 12:36:46 --> Language Class Initialized
INFO - 2023-09-24 12:36:46 --> Language Class Initialized
INFO - 2023-09-24 12:36:46 --> Config Class Initialized
INFO - 2023-09-24 12:36:46 --> Loader Class Initialized
INFO - 2023-09-24 12:36:46 --> Helper loaded: url_helper
INFO - 2023-09-24 12:36:46 --> Helper loaded: file_helper
INFO - 2023-09-24 12:36:46 --> Helper loaded: form_helper
INFO - 2023-09-24 12:36:46 --> Helper loaded: my_helper
INFO - 2023-09-24 12:36:46 --> Database Driver Class Initialized
INFO - 2023-09-24 12:36:46 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-24 12:36:46 --> Controller Class Initialized
INFO - 2023-09-24 12:36:46 --> Final output sent to browser
DEBUG - 2023-09-24 12:36:46 --> Total execution time: 0.0635
INFO - 2023-09-24 12:36:53 --> Config Class Initialized
INFO - 2023-09-24 12:36:53 --> Hooks Class Initialized
DEBUG - 2023-09-24 12:36:53 --> UTF-8 Support Enabled
INFO - 2023-09-24 12:36:53 --> Utf8 Class Initialized
INFO - 2023-09-24 12:36:53 --> URI Class Initialized
INFO - 2023-09-24 12:36:53 --> Router Class Initialized
INFO - 2023-09-24 12:36:53 --> Output Class Initialized
INFO - 2023-09-24 12:36:53 --> Security Class Initialized
DEBUG - 2023-09-24 12:36:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-24 12:36:53 --> Input Class Initialized
INFO - 2023-09-24 12:36:53 --> Language Class Initialized
INFO - 2023-09-24 12:36:53 --> Language Class Initialized
INFO - 2023-09-24 12:36:53 --> Config Class Initialized
INFO - 2023-09-24 12:36:53 --> Loader Class Initialized
INFO - 2023-09-24 12:36:53 --> Helper loaded: url_helper
INFO - 2023-09-24 12:36:53 --> Helper loaded: file_helper
INFO - 2023-09-24 12:36:53 --> Helper loaded: form_helper
INFO - 2023-09-24 12:36:53 --> Helper loaded: my_helper
INFO - 2023-09-24 12:36:53 --> Database Driver Class Initialized
INFO - 2023-09-24 12:36:53 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-24 12:36:53 --> Controller Class Initialized
INFO - 2023-09-24 12:36:53 --> Final output sent to browser
DEBUG - 2023-09-24 12:36:53 --> Total execution time: 0.0345
INFO - 2023-09-24 12:36:53 --> Config Class Initialized
INFO - 2023-09-24 12:36:53 --> Hooks Class Initialized
DEBUG - 2023-09-24 12:36:53 --> UTF-8 Support Enabled
INFO - 2023-09-24 12:36:53 --> Utf8 Class Initialized
INFO - 2023-09-24 12:36:53 --> URI Class Initialized
INFO - 2023-09-24 12:36:53 --> Router Class Initialized
INFO - 2023-09-24 12:36:53 --> Output Class Initialized
INFO - 2023-09-24 12:36:53 --> Security Class Initialized
DEBUG - 2023-09-24 12:36:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-24 12:36:53 --> Input Class Initialized
INFO - 2023-09-24 12:36:53 --> Language Class Initialized
INFO - 2023-09-24 12:36:53 --> Language Class Initialized
INFO - 2023-09-24 12:36:53 --> Config Class Initialized
INFO - 2023-09-24 12:36:53 --> Loader Class Initialized
INFO - 2023-09-24 12:36:53 --> Helper loaded: url_helper
INFO - 2023-09-24 12:36:53 --> Helper loaded: file_helper
INFO - 2023-09-24 12:36:53 --> Helper loaded: form_helper
INFO - 2023-09-24 12:36:53 --> Helper loaded: my_helper
INFO - 2023-09-24 12:36:53 --> Database Driver Class Initialized
INFO - 2023-09-24 12:36:53 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-24 12:36:53 --> Controller Class Initialized
INFO - 2023-09-24 12:36:53 --> Config Class Initialized
INFO - 2023-09-24 12:36:53 --> Hooks Class Initialized
DEBUG - 2023-09-24 12:36:53 --> UTF-8 Support Enabled
INFO - 2023-09-24 12:36:53 --> Utf8 Class Initialized
INFO - 2023-09-24 12:36:53 --> URI Class Initialized
INFO - 2023-09-24 12:36:53 --> Router Class Initialized
INFO - 2023-09-24 12:36:53 --> Output Class Initialized
INFO - 2023-09-24 12:36:53 --> Security Class Initialized
DEBUG - 2023-09-24 12:36:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-24 12:36:53 --> Input Class Initialized
INFO - 2023-09-24 12:36:53 --> Language Class Initialized
INFO - 2023-09-24 12:36:53 --> Language Class Initialized
INFO - 2023-09-24 12:36:53 --> Config Class Initialized
INFO - 2023-09-24 12:36:53 --> Loader Class Initialized
INFO - 2023-09-24 12:36:53 --> Helper loaded: url_helper
INFO - 2023-09-24 12:36:53 --> Helper loaded: file_helper
INFO - 2023-09-24 12:36:53 --> Helper loaded: form_helper
INFO - 2023-09-24 12:36:53 --> Helper loaded: my_helper
INFO - 2023-09-24 12:36:54 --> Database Driver Class Initialized
INFO - 2023-09-24 12:36:54 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-24 12:36:54 --> Controller Class Initialized
INFO - 2023-09-24 12:36:54 --> Final output sent to browser
DEBUG - 2023-09-24 12:36:54 --> Total execution time: 0.0482
INFO - 2023-09-24 12:37:03 --> Config Class Initialized
INFO - 2023-09-24 12:37:03 --> Hooks Class Initialized
DEBUG - 2023-09-24 12:37:03 --> UTF-8 Support Enabled
INFO - 2023-09-24 12:37:03 --> Utf8 Class Initialized
INFO - 2023-09-24 12:37:03 --> URI Class Initialized
INFO - 2023-09-24 12:37:03 --> Router Class Initialized
INFO - 2023-09-24 12:37:03 --> Output Class Initialized
INFO - 2023-09-24 12:37:03 --> Security Class Initialized
DEBUG - 2023-09-24 12:37:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-24 12:37:03 --> Input Class Initialized
INFO - 2023-09-24 12:37:03 --> Language Class Initialized
INFO - 2023-09-24 12:37:03 --> Language Class Initialized
INFO - 2023-09-24 12:37:03 --> Config Class Initialized
INFO - 2023-09-24 12:37:03 --> Loader Class Initialized
INFO - 2023-09-24 12:37:03 --> Helper loaded: url_helper
INFO - 2023-09-24 12:37:03 --> Helper loaded: file_helper
INFO - 2023-09-24 12:37:03 --> Helper loaded: form_helper
INFO - 2023-09-24 12:37:03 --> Helper loaded: my_helper
INFO - 2023-09-24 12:37:03 --> Database Driver Class Initialized
INFO - 2023-09-24 12:37:03 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-24 12:37:03 --> Controller Class Initialized
INFO - 2023-09-24 12:37:03 --> Final output sent to browser
DEBUG - 2023-09-24 12:37:03 --> Total execution time: 0.0417
INFO - 2023-09-24 12:37:06 --> Config Class Initialized
INFO - 2023-09-24 12:37:06 --> Hooks Class Initialized
DEBUG - 2023-09-24 12:37:06 --> UTF-8 Support Enabled
INFO - 2023-09-24 12:37:06 --> Utf8 Class Initialized
INFO - 2023-09-24 12:37:06 --> URI Class Initialized
INFO - 2023-09-24 12:37:06 --> Router Class Initialized
INFO - 2023-09-24 12:37:06 --> Output Class Initialized
INFO - 2023-09-24 12:37:06 --> Security Class Initialized
DEBUG - 2023-09-24 12:37:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-24 12:37:06 --> Input Class Initialized
INFO - 2023-09-24 12:37:06 --> Language Class Initialized
INFO - 2023-09-24 12:37:06 --> Language Class Initialized
INFO - 2023-09-24 12:37:06 --> Config Class Initialized
INFO - 2023-09-24 12:37:06 --> Loader Class Initialized
INFO - 2023-09-24 12:37:06 --> Helper loaded: url_helper
INFO - 2023-09-24 12:37:06 --> Helper loaded: file_helper
INFO - 2023-09-24 12:37:06 --> Helper loaded: form_helper
INFO - 2023-09-24 12:37:06 --> Helper loaded: my_helper
INFO - 2023-09-24 12:37:06 --> Database Driver Class Initialized
INFO - 2023-09-24 12:37:06 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-24 12:37:06 --> Controller Class Initialized
INFO - 2023-09-24 12:37:08 --> Config Class Initialized
INFO - 2023-09-24 12:37:08 --> Hooks Class Initialized
DEBUG - 2023-09-24 12:37:08 --> UTF-8 Support Enabled
INFO - 2023-09-24 12:37:08 --> Utf8 Class Initialized
INFO - 2023-09-24 12:37:08 --> URI Class Initialized
INFO - 2023-09-24 12:37:08 --> Router Class Initialized
INFO - 2023-09-24 12:37:08 --> Output Class Initialized
INFO - 2023-09-24 12:37:08 --> Security Class Initialized
DEBUG - 2023-09-24 12:37:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-24 12:37:08 --> Input Class Initialized
INFO - 2023-09-24 12:37:08 --> Language Class Initialized
INFO - 2023-09-24 12:37:08 --> Language Class Initialized
INFO - 2023-09-24 12:37:08 --> Config Class Initialized
INFO - 2023-09-24 12:37:08 --> Loader Class Initialized
INFO - 2023-09-24 12:37:08 --> Helper loaded: url_helper
INFO - 2023-09-24 12:37:08 --> Helper loaded: file_helper
INFO - 2023-09-24 12:37:08 --> Helper loaded: form_helper
INFO - 2023-09-24 12:37:08 --> Helper loaded: my_helper
INFO - 2023-09-24 12:37:08 --> Database Driver Class Initialized
INFO - 2023-09-24 12:37:08 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-24 12:37:08 --> Controller Class Initialized
INFO - 2023-09-24 12:37:08 --> Final output sent to browser
DEBUG - 2023-09-24 12:37:08 --> Total execution time: 0.0327
INFO - 2023-09-24 12:37:34 --> Config Class Initialized
INFO - 2023-09-24 12:37:34 --> Hooks Class Initialized
DEBUG - 2023-09-24 12:37:34 --> UTF-8 Support Enabled
INFO - 2023-09-24 12:37:34 --> Utf8 Class Initialized
INFO - 2023-09-24 12:37:34 --> URI Class Initialized
INFO - 2023-09-24 12:37:34 --> Router Class Initialized
INFO - 2023-09-24 12:37:34 --> Output Class Initialized
INFO - 2023-09-24 12:37:34 --> Security Class Initialized
DEBUG - 2023-09-24 12:37:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-24 12:37:34 --> Input Class Initialized
INFO - 2023-09-24 12:37:34 --> Language Class Initialized
INFO - 2023-09-24 12:37:34 --> Language Class Initialized
INFO - 2023-09-24 12:37:34 --> Config Class Initialized
INFO - 2023-09-24 12:37:34 --> Loader Class Initialized
INFO - 2023-09-24 12:37:34 --> Helper loaded: url_helper
INFO - 2023-09-24 12:37:34 --> Helper loaded: file_helper
INFO - 2023-09-24 12:37:34 --> Helper loaded: form_helper
INFO - 2023-09-24 12:37:34 --> Helper loaded: my_helper
INFO - 2023-09-24 12:37:34 --> Database Driver Class Initialized
INFO - 2023-09-24 12:37:34 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-24 12:37:34 --> Controller Class Initialized
INFO - 2023-09-24 12:37:34 --> Final output sent to browser
DEBUG - 2023-09-24 12:37:34 --> Total execution time: 0.0870
INFO - 2023-09-24 12:37:34 --> Config Class Initialized
INFO - 2023-09-24 12:37:34 --> Hooks Class Initialized
DEBUG - 2023-09-24 12:37:34 --> UTF-8 Support Enabled
INFO - 2023-09-24 12:37:34 --> Utf8 Class Initialized
INFO - 2023-09-24 12:37:34 --> URI Class Initialized
INFO - 2023-09-24 12:37:34 --> Router Class Initialized
INFO - 2023-09-24 12:37:34 --> Output Class Initialized
INFO - 2023-09-24 12:37:34 --> Security Class Initialized
DEBUG - 2023-09-24 12:37:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-24 12:37:34 --> Input Class Initialized
INFO - 2023-09-24 12:37:34 --> Language Class Initialized
INFO - 2023-09-24 12:37:34 --> Language Class Initialized
INFO - 2023-09-24 12:37:34 --> Config Class Initialized
INFO - 2023-09-24 12:37:34 --> Loader Class Initialized
INFO - 2023-09-24 12:37:34 --> Helper loaded: url_helper
INFO - 2023-09-24 12:37:34 --> Helper loaded: file_helper
INFO - 2023-09-24 12:37:34 --> Helper loaded: form_helper
INFO - 2023-09-24 12:37:34 --> Helper loaded: my_helper
INFO - 2023-09-24 12:37:34 --> Database Driver Class Initialized
INFO - 2023-09-24 12:37:34 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-24 12:37:34 --> Controller Class Initialized
INFO - 2023-09-24 12:37:41 --> Config Class Initialized
INFO - 2023-09-24 12:37:41 --> Hooks Class Initialized
DEBUG - 2023-09-24 12:37:41 --> UTF-8 Support Enabled
INFO - 2023-09-24 12:37:41 --> Utf8 Class Initialized
INFO - 2023-09-24 12:37:41 --> URI Class Initialized
INFO - 2023-09-24 12:37:41 --> Router Class Initialized
INFO - 2023-09-24 12:37:41 --> Output Class Initialized
INFO - 2023-09-24 12:37:41 --> Security Class Initialized
DEBUG - 2023-09-24 12:37:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-24 12:37:41 --> Input Class Initialized
INFO - 2023-09-24 12:37:41 --> Language Class Initialized
INFO - 2023-09-24 12:37:41 --> Language Class Initialized
INFO - 2023-09-24 12:37:41 --> Config Class Initialized
INFO - 2023-09-24 12:37:41 --> Loader Class Initialized
INFO - 2023-09-24 12:37:41 --> Helper loaded: url_helper
INFO - 2023-09-24 12:37:41 --> Helper loaded: file_helper
INFO - 2023-09-24 12:37:41 --> Helper loaded: form_helper
INFO - 2023-09-24 12:37:41 --> Helper loaded: my_helper
INFO - 2023-09-24 12:37:41 --> Database Driver Class Initialized
INFO - 2023-09-24 12:37:41 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-24 12:37:41 --> Controller Class Initialized
INFO - 2023-09-24 12:37:41 --> Final output sent to browser
DEBUG - 2023-09-24 12:37:41 --> Total execution time: 0.0326
INFO - 2023-09-24 12:37:48 --> Config Class Initialized
INFO - 2023-09-24 12:37:48 --> Hooks Class Initialized
DEBUG - 2023-09-24 12:37:48 --> UTF-8 Support Enabled
INFO - 2023-09-24 12:37:48 --> Utf8 Class Initialized
INFO - 2023-09-24 12:37:48 --> URI Class Initialized
INFO - 2023-09-24 12:37:48 --> Router Class Initialized
INFO - 2023-09-24 12:37:48 --> Output Class Initialized
INFO - 2023-09-24 12:37:48 --> Security Class Initialized
DEBUG - 2023-09-24 12:37:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-24 12:37:48 --> Input Class Initialized
INFO - 2023-09-24 12:37:48 --> Language Class Initialized
INFO - 2023-09-24 12:37:48 --> Language Class Initialized
INFO - 2023-09-24 12:37:48 --> Config Class Initialized
INFO - 2023-09-24 12:37:48 --> Loader Class Initialized
INFO - 2023-09-24 12:37:48 --> Helper loaded: url_helper
INFO - 2023-09-24 12:37:48 --> Helper loaded: file_helper
INFO - 2023-09-24 12:37:48 --> Helper loaded: form_helper
INFO - 2023-09-24 12:37:48 --> Helper loaded: my_helper
INFO - 2023-09-24 12:37:48 --> Database Driver Class Initialized
INFO - 2023-09-24 12:37:48 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-24 12:37:48 --> Controller Class Initialized
INFO - 2023-09-24 12:37:48 --> Final output sent to browser
DEBUG - 2023-09-24 12:37:48 --> Total execution time: 0.0339
INFO - 2023-09-24 12:37:49 --> Config Class Initialized
INFO - 2023-09-24 12:37:49 --> Hooks Class Initialized
DEBUG - 2023-09-24 12:37:49 --> UTF-8 Support Enabled
INFO - 2023-09-24 12:37:49 --> Utf8 Class Initialized
INFO - 2023-09-24 12:37:49 --> URI Class Initialized
INFO - 2023-09-24 12:37:49 --> Router Class Initialized
INFO - 2023-09-24 12:37:49 --> Output Class Initialized
INFO - 2023-09-24 12:37:49 --> Security Class Initialized
DEBUG - 2023-09-24 12:37:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-24 12:37:49 --> Input Class Initialized
INFO - 2023-09-24 12:37:49 --> Language Class Initialized
INFO - 2023-09-24 12:37:49 --> Language Class Initialized
INFO - 2023-09-24 12:37:49 --> Config Class Initialized
INFO - 2023-09-24 12:37:49 --> Loader Class Initialized
INFO - 2023-09-24 12:37:49 --> Helper loaded: url_helper
INFO - 2023-09-24 12:37:49 --> Helper loaded: file_helper
INFO - 2023-09-24 12:37:49 --> Helper loaded: form_helper
INFO - 2023-09-24 12:37:49 --> Helper loaded: my_helper
INFO - 2023-09-24 12:37:49 --> Database Driver Class Initialized
INFO - 2023-09-24 12:37:49 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-24 12:37:49 --> Controller Class Initialized
INFO - 2023-09-24 12:37:49 --> Config Class Initialized
INFO - 2023-09-24 12:37:49 --> Hooks Class Initialized
DEBUG - 2023-09-24 12:37:49 --> UTF-8 Support Enabled
INFO - 2023-09-24 12:37:49 --> Utf8 Class Initialized
INFO - 2023-09-24 12:37:49 --> URI Class Initialized
INFO - 2023-09-24 12:37:49 --> Router Class Initialized
INFO - 2023-09-24 12:37:49 --> Output Class Initialized
INFO - 2023-09-24 12:37:49 --> Security Class Initialized
DEBUG - 2023-09-24 12:37:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-24 12:37:49 --> Input Class Initialized
INFO - 2023-09-24 12:37:49 --> Language Class Initialized
INFO - 2023-09-24 12:37:49 --> Language Class Initialized
INFO - 2023-09-24 12:37:49 --> Config Class Initialized
INFO - 2023-09-24 12:37:49 --> Loader Class Initialized
INFO - 2023-09-24 12:37:49 --> Helper loaded: url_helper
INFO - 2023-09-24 12:37:49 --> Helper loaded: file_helper
INFO - 2023-09-24 12:37:49 --> Helper loaded: form_helper
INFO - 2023-09-24 12:37:49 --> Helper loaded: my_helper
INFO - 2023-09-24 12:37:49 --> Database Driver Class Initialized
INFO - 2023-09-24 12:37:49 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-24 12:37:49 --> Controller Class Initialized
INFO - 2023-09-24 12:37:49 --> Final output sent to browser
DEBUG - 2023-09-24 12:37:49 --> Total execution time: 0.0437
INFO - 2023-09-24 12:38:01 --> Config Class Initialized
INFO - 2023-09-24 12:38:01 --> Hooks Class Initialized
DEBUG - 2023-09-24 12:38:01 --> UTF-8 Support Enabled
INFO - 2023-09-24 12:38:01 --> Utf8 Class Initialized
INFO - 2023-09-24 12:38:01 --> URI Class Initialized
INFO - 2023-09-24 12:38:01 --> Router Class Initialized
INFO - 2023-09-24 12:38:01 --> Output Class Initialized
INFO - 2023-09-24 12:38:01 --> Security Class Initialized
DEBUG - 2023-09-24 12:38:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-24 12:38:01 --> Input Class Initialized
INFO - 2023-09-24 12:38:01 --> Language Class Initialized
INFO - 2023-09-24 12:38:01 --> Language Class Initialized
INFO - 2023-09-24 12:38:01 --> Config Class Initialized
INFO - 2023-09-24 12:38:01 --> Loader Class Initialized
INFO - 2023-09-24 12:38:01 --> Helper loaded: url_helper
INFO - 2023-09-24 12:38:01 --> Helper loaded: file_helper
INFO - 2023-09-24 12:38:01 --> Helper loaded: form_helper
INFO - 2023-09-24 12:38:01 --> Helper loaded: my_helper
INFO - 2023-09-24 12:38:01 --> Database Driver Class Initialized
INFO - 2023-09-24 12:38:01 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-24 12:38:01 --> Controller Class Initialized
INFO - 2023-09-24 12:38:01 --> Final output sent to browser
DEBUG - 2023-09-24 12:38:01 --> Total execution time: 0.0446
INFO - 2023-09-24 12:38:01 --> Config Class Initialized
INFO - 2023-09-24 12:38:01 --> Hooks Class Initialized
DEBUG - 2023-09-24 12:38:01 --> UTF-8 Support Enabled
INFO - 2023-09-24 12:38:01 --> Utf8 Class Initialized
INFO - 2023-09-24 12:38:01 --> URI Class Initialized
INFO - 2023-09-24 12:38:01 --> Router Class Initialized
INFO - 2023-09-24 12:38:01 --> Output Class Initialized
INFO - 2023-09-24 12:38:01 --> Security Class Initialized
DEBUG - 2023-09-24 12:38:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-24 12:38:01 --> Input Class Initialized
INFO - 2023-09-24 12:38:01 --> Language Class Initialized
INFO - 2023-09-24 12:38:01 --> Language Class Initialized
INFO - 2023-09-24 12:38:01 --> Config Class Initialized
INFO - 2023-09-24 12:38:01 --> Loader Class Initialized
INFO - 2023-09-24 12:38:01 --> Helper loaded: url_helper
INFO - 2023-09-24 12:38:01 --> Helper loaded: file_helper
INFO - 2023-09-24 12:38:01 --> Helper loaded: form_helper
INFO - 2023-09-24 12:38:01 --> Helper loaded: my_helper
INFO - 2023-09-24 12:38:01 --> Database Driver Class Initialized
INFO - 2023-09-24 12:38:01 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-24 12:38:01 --> Controller Class Initialized
INFO - 2023-09-24 12:38:05 --> Config Class Initialized
INFO - 2023-09-24 12:38:05 --> Hooks Class Initialized
DEBUG - 2023-09-24 12:38:05 --> UTF-8 Support Enabled
INFO - 2023-09-24 12:38:05 --> Utf8 Class Initialized
INFO - 2023-09-24 12:38:05 --> URI Class Initialized
INFO - 2023-09-24 12:38:05 --> Router Class Initialized
INFO - 2023-09-24 12:38:05 --> Output Class Initialized
INFO - 2023-09-24 12:38:05 --> Security Class Initialized
DEBUG - 2023-09-24 12:38:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-24 12:38:05 --> Input Class Initialized
INFO - 2023-09-24 12:38:05 --> Language Class Initialized
INFO - 2023-09-24 12:38:05 --> Language Class Initialized
INFO - 2023-09-24 12:38:05 --> Config Class Initialized
INFO - 2023-09-24 12:38:05 --> Loader Class Initialized
INFO - 2023-09-24 12:38:05 --> Helper loaded: url_helper
INFO - 2023-09-24 12:38:05 --> Helper loaded: file_helper
INFO - 2023-09-24 12:38:05 --> Helper loaded: form_helper
INFO - 2023-09-24 12:38:05 --> Helper loaded: my_helper
INFO - 2023-09-24 12:38:05 --> Database Driver Class Initialized
INFO - 2023-09-24 12:38:05 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-24 12:38:05 --> Controller Class Initialized
INFO - 2023-09-24 12:38:05 --> Final output sent to browser
DEBUG - 2023-09-24 12:38:05 --> Total execution time: 0.0315
INFO - 2023-09-24 12:38:13 --> Config Class Initialized
INFO - 2023-09-24 12:38:13 --> Hooks Class Initialized
DEBUG - 2023-09-24 12:38:13 --> UTF-8 Support Enabled
INFO - 2023-09-24 12:38:13 --> Utf8 Class Initialized
INFO - 2023-09-24 12:38:13 --> URI Class Initialized
INFO - 2023-09-24 12:38:13 --> Router Class Initialized
INFO - 2023-09-24 12:38:13 --> Output Class Initialized
INFO - 2023-09-24 12:38:13 --> Security Class Initialized
DEBUG - 2023-09-24 12:38:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-24 12:38:13 --> Input Class Initialized
INFO - 2023-09-24 12:38:13 --> Language Class Initialized
INFO - 2023-09-24 12:38:13 --> Language Class Initialized
INFO - 2023-09-24 12:38:13 --> Config Class Initialized
INFO - 2023-09-24 12:38:13 --> Loader Class Initialized
INFO - 2023-09-24 12:38:13 --> Helper loaded: url_helper
INFO - 2023-09-24 12:38:13 --> Helper loaded: file_helper
INFO - 2023-09-24 12:38:13 --> Helper loaded: form_helper
INFO - 2023-09-24 12:38:13 --> Helper loaded: my_helper
INFO - 2023-09-24 12:38:13 --> Database Driver Class Initialized
INFO - 2023-09-24 12:38:13 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-24 12:38:13 --> Controller Class Initialized
INFO - 2023-09-24 12:38:13 --> Final output sent to browser
DEBUG - 2023-09-24 12:38:13 --> Total execution time: 0.0340
INFO - 2023-09-24 12:38:13 --> Config Class Initialized
INFO - 2023-09-24 12:38:13 --> Hooks Class Initialized
DEBUG - 2023-09-24 12:38:13 --> UTF-8 Support Enabled
INFO - 2023-09-24 12:38:13 --> Utf8 Class Initialized
INFO - 2023-09-24 12:38:13 --> URI Class Initialized
INFO - 2023-09-24 12:38:13 --> Router Class Initialized
INFO - 2023-09-24 12:38:13 --> Output Class Initialized
INFO - 2023-09-24 12:38:13 --> Security Class Initialized
DEBUG - 2023-09-24 12:38:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-24 12:38:13 --> Input Class Initialized
INFO - 2023-09-24 12:38:13 --> Language Class Initialized
INFO - 2023-09-24 12:38:13 --> Language Class Initialized
INFO - 2023-09-24 12:38:13 --> Config Class Initialized
INFO - 2023-09-24 12:38:13 --> Loader Class Initialized
INFO - 2023-09-24 12:38:13 --> Helper loaded: url_helper
INFO - 2023-09-24 12:38:13 --> Helper loaded: file_helper
INFO - 2023-09-24 12:38:13 --> Helper loaded: form_helper
INFO - 2023-09-24 12:38:13 --> Helper loaded: my_helper
INFO - 2023-09-24 12:38:13 --> Database Driver Class Initialized
INFO - 2023-09-24 12:38:13 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-24 12:38:13 --> Controller Class Initialized
INFO - 2023-09-24 12:38:15 --> Config Class Initialized
INFO - 2023-09-24 12:38:15 --> Hooks Class Initialized
DEBUG - 2023-09-24 12:38:15 --> UTF-8 Support Enabled
INFO - 2023-09-24 12:38:15 --> Utf8 Class Initialized
INFO - 2023-09-24 12:38:15 --> URI Class Initialized
INFO - 2023-09-24 12:38:15 --> Router Class Initialized
INFO - 2023-09-24 12:38:15 --> Output Class Initialized
INFO - 2023-09-24 12:38:15 --> Security Class Initialized
DEBUG - 2023-09-24 12:38:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-24 12:38:15 --> Input Class Initialized
INFO - 2023-09-24 12:38:15 --> Language Class Initialized
INFO - 2023-09-24 12:38:15 --> Language Class Initialized
INFO - 2023-09-24 12:38:15 --> Config Class Initialized
INFO - 2023-09-24 12:38:15 --> Loader Class Initialized
INFO - 2023-09-24 12:38:15 --> Helper loaded: url_helper
INFO - 2023-09-24 12:38:15 --> Helper loaded: file_helper
INFO - 2023-09-24 12:38:15 --> Helper loaded: form_helper
INFO - 2023-09-24 12:38:15 --> Helper loaded: my_helper
INFO - 2023-09-24 12:38:15 --> Database Driver Class Initialized
INFO - 2023-09-24 12:38:15 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-24 12:38:15 --> Controller Class Initialized
INFO - 2023-09-24 12:38:15 --> Final output sent to browser
DEBUG - 2023-09-24 12:38:15 --> Total execution time: 0.0366
INFO - 2023-09-24 12:38:25 --> Config Class Initialized
INFO - 2023-09-24 12:38:25 --> Hooks Class Initialized
DEBUG - 2023-09-24 12:38:25 --> UTF-8 Support Enabled
INFO - 2023-09-24 12:38:25 --> Utf8 Class Initialized
INFO - 2023-09-24 12:38:25 --> URI Class Initialized
INFO - 2023-09-24 12:38:25 --> Router Class Initialized
INFO - 2023-09-24 12:38:25 --> Output Class Initialized
INFO - 2023-09-24 12:38:25 --> Security Class Initialized
DEBUG - 2023-09-24 12:38:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-24 12:38:25 --> Input Class Initialized
INFO - 2023-09-24 12:38:25 --> Language Class Initialized
INFO - 2023-09-24 12:38:25 --> Language Class Initialized
INFO - 2023-09-24 12:38:25 --> Config Class Initialized
INFO - 2023-09-24 12:38:25 --> Loader Class Initialized
INFO - 2023-09-24 12:38:25 --> Helper loaded: url_helper
INFO - 2023-09-24 12:38:25 --> Helper loaded: file_helper
INFO - 2023-09-24 12:38:25 --> Helper loaded: form_helper
INFO - 2023-09-24 12:38:25 --> Helper loaded: my_helper
INFO - 2023-09-24 12:38:25 --> Database Driver Class Initialized
INFO - 2023-09-24 12:38:25 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-24 12:38:25 --> Controller Class Initialized
INFO - 2023-09-24 12:38:25 --> Final output sent to browser
DEBUG - 2023-09-24 12:38:25 --> Total execution time: 0.0897
INFO - 2023-09-24 12:38:25 --> Config Class Initialized
INFO - 2023-09-24 12:38:25 --> Hooks Class Initialized
DEBUG - 2023-09-24 12:38:25 --> UTF-8 Support Enabled
INFO - 2023-09-24 12:38:25 --> Utf8 Class Initialized
INFO - 2023-09-24 12:38:25 --> URI Class Initialized
INFO - 2023-09-24 12:38:25 --> Router Class Initialized
INFO - 2023-09-24 12:38:25 --> Output Class Initialized
INFO - 2023-09-24 12:38:25 --> Security Class Initialized
DEBUG - 2023-09-24 12:38:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-24 12:38:25 --> Input Class Initialized
INFO - 2023-09-24 12:38:25 --> Language Class Initialized
INFO - 2023-09-24 12:38:25 --> Language Class Initialized
INFO - 2023-09-24 12:38:25 --> Config Class Initialized
INFO - 2023-09-24 12:38:25 --> Loader Class Initialized
INFO - 2023-09-24 12:38:25 --> Helper loaded: url_helper
INFO - 2023-09-24 12:38:25 --> Helper loaded: file_helper
INFO - 2023-09-24 12:38:25 --> Helper loaded: form_helper
INFO - 2023-09-24 12:38:25 --> Helper loaded: my_helper
INFO - 2023-09-24 12:38:25 --> Database Driver Class Initialized
INFO - 2023-09-24 12:38:25 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-24 12:38:25 --> Controller Class Initialized
INFO - 2023-09-24 12:38:26 --> Config Class Initialized
INFO - 2023-09-24 12:38:26 --> Hooks Class Initialized
DEBUG - 2023-09-24 12:38:26 --> UTF-8 Support Enabled
INFO - 2023-09-24 12:38:26 --> Utf8 Class Initialized
INFO - 2023-09-24 12:38:26 --> URI Class Initialized
INFO - 2023-09-24 12:38:26 --> Router Class Initialized
INFO - 2023-09-24 12:38:26 --> Output Class Initialized
INFO - 2023-09-24 12:38:26 --> Security Class Initialized
DEBUG - 2023-09-24 12:38:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-24 12:38:26 --> Input Class Initialized
INFO - 2023-09-24 12:38:26 --> Language Class Initialized
INFO - 2023-09-24 12:38:26 --> Language Class Initialized
INFO - 2023-09-24 12:38:26 --> Config Class Initialized
INFO - 2023-09-24 12:38:26 --> Loader Class Initialized
INFO - 2023-09-24 12:38:26 --> Helper loaded: url_helper
INFO - 2023-09-24 12:38:26 --> Helper loaded: file_helper
INFO - 2023-09-24 12:38:26 --> Helper loaded: form_helper
INFO - 2023-09-24 12:38:26 --> Helper loaded: my_helper
INFO - 2023-09-24 12:38:26 --> Database Driver Class Initialized
INFO - 2023-09-24 12:38:26 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-24 12:38:26 --> Controller Class Initialized
INFO - 2023-09-24 12:38:26 --> Final output sent to browser
DEBUG - 2023-09-24 12:38:26 --> Total execution time: 0.0329
INFO - 2023-09-24 12:38:41 --> Config Class Initialized
INFO - 2023-09-24 12:38:41 --> Hooks Class Initialized
DEBUG - 2023-09-24 12:38:41 --> UTF-8 Support Enabled
INFO - 2023-09-24 12:38:41 --> Utf8 Class Initialized
INFO - 2023-09-24 12:38:41 --> URI Class Initialized
INFO - 2023-09-24 12:38:41 --> Router Class Initialized
INFO - 2023-09-24 12:38:41 --> Output Class Initialized
INFO - 2023-09-24 12:38:41 --> Security Class Initialized
DEBUG - 2023-09-24 12:38:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-24 12:38:41 --> Input Class Initialized
INFO - 2023-09-24 12:38:41 --> Language Class Initialized
INFO - 2023-09-24 12:38:41 --> Language Class Initialized
INFO - 2023-09-24 12:38:41 --> Config Class Initialized
INFO - 2023-09-24 12:38:41 --> Loader Class Initialized
INFO - 2023-09-24 12:38:41 --> Helper loaded: url_helper
INFO - 2023-09-24 12:38:41 --> Helper loaded: file_helper
INFO - 2023-09-24 12:38:41 --> Helper loaded: form_helper
INFO - 2023-09-24 12:38:41 --> Helper loaded: my_helper
INFO - 2023-09-24 12:38:41 --> Database Driver Class Initialized
INFO - 2023-09-24 12:38:41 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-24 12:38:41 --> Controller Class Initialized
INFO - 2023-09-24 12:38:41 --> Final output sent to browser
DEBUG - 2023-09-24 12:38:41 --> Total execution time: 0.0371
INFO - 2023-09-24 12:38:41 --> Config Class Initialized
INFO - 2023-09-24 12:38:41 --> Hooks Class Initialized
DEBUG - 2023-09-24 12:38:41 --> UTF-8 Support Enabled
INFO - 2023-09-24 12:38:41 --> Utf8 Class Initialized
INFO - 2023-09-24 12:38:41 --> URI Class Initialized
INFO - 2023-09-24 12:38:41 --> Router Class Initialized
INFO - 2023-09-24 12:38:41 --> Output Class Initialized
INFO - 2023-09-24 12:38:41 --> Security Class Initialized
DEBUG - 2023-09-24 12:38:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-24 12:38:41 --> Input Class Initialized
INFO - 2023-09-24 12:38:41 --> Language Class Initialized
INFO - 2023-09-24 12:38:41 --> Language Class Initialized
INFO - 2023-09-24 12:38:41 --> Config Class Initialized
INFO - 2023-09-24 12:38:41 --> Loader Class Initialized
INFO - 2023-09-24 12:38:41 --> Helper loaded: url_helper
INFO - 2023-09-24 12:38:41 --> Helper loaded: file_helper
INFO - 2023-09-24 12:38:41 --> Helper loaded: form_helper
INFO - 2023-09-24 12:38:41 --> Helper loaded: my_helper
INFO - 2023-09-24 12:38:41 --> Database Driver Class Initialized
INFO - 2023-09-24 12:38:41 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-24 12:38:41 --> Controller Class Initialized
INFO - 2023-09-24 12:38:43 --> Config Class Initialized
INFO - 2023-09-24 12:38:43 --> Hooks Class Initialized
DEBUG - 2023-09-24 12:38:43 --> UTF-8 Support Enabled
INFO - 2023-09-24 12:38:43 --> Utf8 Class Initialized
INFO - 2023-09-24 12:38:43 --> URI Class Initialized
INFO - 2023-09-24 12:38:43 --> Router Class Initialized
INFO - 2023-09-24 12:38:43 --> Output Class Initialized
INFO - 2023-09-24 12:38:43 --> Security Class Initialized
DEBUG - 2023-09-24 12:38:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-24 12:38:43 --> Input Class Initialized
INFO - 2023-09-24 12:38:43 --> Language Class Initialized
INFO - 2023-09-24 12:38:43 --> Language Class Initialized
INFO - 2023-09-24 12:38:43 --> Config Class Initialized
INFO - 2023-09-24 12:38:43 --> Loader Class Initialized
INFO - 2023-09-24 12:38:43 --> Helper loaded: url_helper
INFO - 2023-09-24 12:38:43 --> Helper loaded: file_helper
INFO - 2023-09-24 12:38:43 --> Helper loaded: form_helper
INFO - 2023-09-24 12:38:43 --> Helper loaded: my_helper
INFO - 2023-09-24 12:38:43 --> Database Driver Class Initialized
INFO - 2023-09-24 12:38:43 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-24 12:38:43 --> Controller Class Initialized
INFO - 2023-09-24 12:38:43 --> Final output sent to browser
DEBUG - 2023-09-24 12:38:43 --> Total execution time: 0.0310
INFO - 2023-09-24 12:38:58 --> Config Class Initialized
INFO - 2023-09-24 12:38:58 --> Hooks Class Initialized
DEBUG - 2023-09-24 12:38:58 --> UTF-8 Support Enabled
INFO - 2023-09-24 12:38:58 --> Utf8 Class Initialized
INFO - 2023-09-24 12:38:58 --> URI Class Initialized
INFO - 2023-09-24 12:38:58 --> Router Class Initialized
INFO - 2023-09-24 12:38:58 --> Output Class Initialized
INFO - 2023-09-24 12:38:58 --> Security Class Initialized
DEBUG - 2023-09-24 12:38:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-24 12:38:58 --> Input Class Initialized
INFO - 2023-09-24 12:38:58 --> Language Class Initialized
INFO - 2023-09-24 12:38:58 --> Language Class Initialized
INFO - 2023-09-24 12:38:58 --> Config Class Initialized
INFO - 2023-09-24 12:38:58 --> Loader Class Initialized
INFO - 2023-09-24 12:38:58 --> Helper loaded: url_helper
INFO - 2023-09-24 12:38:58 --> Helper loaded: file_helper
INFO - 2023-09-24 12:38:58 --> Helper loaded: form_helper
INFO - 2023-09-24 12:38:58 --> Helper loaded: my_helper
INFO - 2023-09-24 12:38:58 --> Database Driver Class Initialized
INFO - 2023-09-24 12:38:58 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-24 12:38:58 --> Controller Class Initialized
INFO - 2023-09-24 12:38:58 --> Final output sent to browser
DEBUG - 2023-09-24 12:38:58 --> Total execution time: 0.0758
INFO - 2023-09-24 12:38:58 --> Config Class Initialized
INFO - 2023-09-24 12:38:58 --> Hooks Class Initialized
DEBUG - 2023-09-24 12:38:58 --> UTF-8 Support Enabled
INFO - 2023-09-24 12:38:58 --> Utf8 Class Initialized
INFO - 2023-09-24 12:38:58 --> URI Class Initialized
INFO - 2023-09-24 12:38:58 --> Router Class Initialized
INFO - 2023-09-24 12:38:58 --> Output Class Initialized
INFO - 2023-09-24 12:38:58 --> Security Class Initialized
DEBUG - 2023-09-24 12:38:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-24 12:38:58 --> Input Class Initialized
INFO - 2023-09-24 12:38:58 --> Language Class Initialized
INFO - 2023-09-24 12:38:58 --> Language Class Initialized
INFO - 2023-09-24 12:38:58 --> Config Class Initialized
INFO - 2023-09-24 12:38:58 --> Loader Class Initialized
INFO - 2023-09-24 12:38:58 --> Helper loaded: url_helper
INFO - 2023-09-24 12:38:58 --> Helper loaded: file_helper
INFO - 2023-09-24 12:38:58 --> Helper loaded: form_helper
INFO - 2023-09-24 12:38:58 --> Helper loaded: my_helper
INFO - 2023-09-24 12:38:58 --> Database Driver Class Initialized
INFO - 2023-09-24 12:38:58 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-24 12:38:58 --> Controller Class Initialized
INFO - 2023-09-24 12:38:59 --> Config Class Initialized
INFO - 2023-09-24 12:38:59 --> Hooks Class Initialized
DEBUG - 2023-09-24 12:38:59 --> UTF-8 Support Enabled
INFO - 2023-09-24 12:38:59 --> Utf8 Class Initialized
INFO - 2023-09-24 12:38:59 --> URI Class Initialized
INFO - 2023-09-24 12:38:59 --> Router Class Initialized
INFO - 2023-09-24 12:38:59 --> Output Class Initialized
INFO - 2023-09-24 12:38:59 --> Security Class Initialized
DEBUG - 2023-09-24 12:38:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-24 12:38:59 --> Input Class Initialized
INFO - 2023-09-24 12:38:59 --> Language Class Initialized
INFO - 2023-09-24 12:38:59 --> Language Class Initialized
INFO - 2023-09-24 12:38:59 --> Config Class Initialized
INFO - 2023-09-24 12:38:59 --> Loader Class Initialized
INFO - 2023-09-24 12:38:59 --> Helper loaded: url_helper
INFO - 2023-09-24 12:38:59 --> Helper loaded: file_helper
INFO - 2023-09-24 12:38:59 --> Helper loaded: form_helper
INFO - 2023-09-24 12:38:59 --> Helper loaded: my_helper
INFO - 2023-09-24 12:38:59 --> Database Driver Class Initialized
INFO - 2023-09-24 12:38:59 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-24 12:38:59 --> Controller Class Initialized
INFO - 2023-09-24 12:38:59 --> Final output sent to browser
DEBUG - 2023-09-24 12:38:59 --> Total execution time: 0.0418
INFO - 2023-09-24 12:39:08 --> Config Class Initialized
INFO - 2023-09-24 12:39:08 --> Hooks Class Initialized
DEBUG - 2023-09-24 12:39:08 --> UTF-8 Support Enabled
INFO - 2023-09-24 12:39:08 --> Utf8 Class Initialized
INFO - 2023-09-24 12:39:08 --> URI Class Initialized
INFO - 2023-09-24 12:39:08 --> Router Class Initialized
INFO - 2023-09-24 12:39:08 --> Output Class Initialized
INFO - 2023-09-24 12:39:08 --> Security Class Initialized
DEBUG - 2023-09-24 12:39:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-24 12:39:08 --> Input Class Initialized
INFO - 2023-09-24 12:39:08 --> Language Class Initialized
INFO - 2023-09-24 12:39:08 --> Language Class Initialized
INFO - 2023-09-24 12:39:08 --> Config Class Initialized
INFO - 2023-09-24 12:39:08 --> Loader Class Initialized
INFO - 2023-09-24 12:39:08 --> Helper loaded: url_helper
INFO - 2023-09-24 12:39:08 --> Helper loaded: file_helper
INFO - 2023-09-24 12:39:08 --> Helper loaded: form_helper
INFO - 2023-09-24 12:39:08 --> Helper loaded: my_helper
INFO - 2023-09-24 12:39:08 --> Database Driver Class Initialized
INFO - 2023-09-24 12:39:08 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-24 12:39:08 --> Controller Class Initialized
INFO - 2023-09-24 12:39:08 --> Final output sent to browser
DEBUG - 2023-09-24 12:39:08 --> Total execution time: 0.0383
INFO - 2023-09-24 12:39:08 --> Config Class Initialized
INFO - 2023-09-24 12:39:08 --> Hooks Class Initialized
DEBUG - 2023-09-24 12:39:08 --> UTF-8 Support Enabled
INFO - 2023-09-24 12:39:08 --> Utf8 Class Initialized
INFO - 2023-09-24 12:39:08 --> URI Class Initialized
INFO - 2023-09-24 12:39:08 --> Router Class Initialized
INFO - 2023-09-24 12:39:08 --> Output Class Initialized
INFO - 2023-09-24 12:39:08 --> Security Class Initialized
DEBUG - 2023-09-24 12:39:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-24 12:39:08 --> Input Class Initialized
INFO - 2023-09-24 12:39:08 --> Language Class Initialized
INFO - 2023-09-24 12:39:08 --> Language Class Initialized
INFO - 2023-09-24 12:39:08 --> Config Class Initialized
INFO - 2023-09-24 12:39:08 --> Loader Class Initialized
INFO - 2023-09-24 12:39:08 --> Helper loaded: url_helper
INFO - 2023-09-24 12:39:08 --> Helper loaded: file_helper
INFO - 2023-09-24 12:39:08 --> Helper loaded: form_helper
INFO - 2023-09-24 12:39:08 --> Helper loaded: my_helper
INFO - 2023-09-24 12:39:08 --> Database Driver Class Initialized
INFO - 2023-09-24 12:39:08 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-24 12:39:08 --> Controller Class Initialized
INFO - 2023-09-24 12:39:09 --> Config Class Initialized
INFO - 2023-09-24 12:39:09 --> Hooks Class Initialized
DEBUG - 2023-09-24 12:39:09 --> UTF-8 Support Enabled
INFO - 2023-09-24 12:39:09 --> Utf8 Class Initialized
INFO - 2023-09-24 12:39:09 --> URI Class Initialized
INFO - 2023-09-24 12:39:09 --> Router Class Initialized
INFO - 2023-09-24 12:39:09 --> Output Class Initialized
INFO - 2023-09-24 12:39:09 --> Security Class Initialized
DEBUG - 2023-09-24 12:39:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-24 12:39:09 --> Input Class Initialized
INFO - 2023-09-24 12:39:09 --> Language Class Initialized
INFO - 2023-09-24 12:39:09 --> Language Class Initialized
INFO - 2023-09-24 12:39:09 --> Config Class Initialized
INFO - 2023-09-24 12:39:09 --> Loader Class Initialized
INFO - 2023-09-24 12:39:09 --> Helper loaded: url_helper
INFO - 2023-09-24 12:39:09 --> Helper loaded: file_helper
INFO - 2023-09-24 12:39:09 --> Helper loaded: form_helper
INFO - 2023-09-24 12:39:09 --> Helper loaded: my_helper
INFO - 2023-09-24 12:39:09 --> Database Driver Class Initialized
INFO - 2023-09-24 12:39:09 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-24 12:39:09 --> Controller Class Initialized
INFO - 2023-09-24 12:39:09 --> Final output sent to browser
DEBUG - 2023-09-24 12:39:09 --> Total execution time: 0.0333
INFO - 2023-09-24 12:39:19 --> Config Class Initialized
INFO - 2023-09-24 12:39:19 --> Hooks Class Initialized
DEBUG - 2023-09-24 12:39:19 --> UTF-8 Support Enabled
INFO - 2023-09-24 12:39:19 --> Utf8 Class Initialized
INFO - 2023-09-24 12:39:19 --> URI Class Initialized
INFO - 2023-09-24 12:39:19 --> Router Class Initialized
INFO - 2023-09-24 12:39:19 --> Output Class Initialized
INFO - 2023-09-24 12:39:19 --> Security Class Initialized
DEBUG - 2023-09-24 12:39:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-24 12:39:19 --> Input Class Initialized
INFO - 2023-09-24 12:39:19 --> Language Class Initialized
INFO - 2023-09-24 12:39:19 --> Language Class Initialized
INFO - 2023-09-24 12:39:19 --> Config Class Initialized
INFO - 2023-09-24 12:39:19 --> Loader Class Initialized
INFO - 2023-09-24 12:39:19 --> Helper loaded: url_helper
INFO - 2023-09-24 12:39:19 --> Helper loaded: file_helper
INFO - 2023-09-24 12:39:19 --> Helper loaded: form_helper
INFO - 2023-09-24 12:39:19 --> Helper loaded: my_helper
INFO - 2023-09-24 12:39:19 --> Database Driver Class Initialized
INFO - 2023-09-24 12:39:19 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-24 12:39:19 --> Controller Class Initialized
INFO - 2023-09-24 12:39:19 --> Final output sent to browser
DEBUG - 2023-09-24 12:39:19 --> Total execution time: 0.0367
INFO - 2023-09-24 12:39:19 --> Config Class Initialized
INFO - 2023-09-24 12:39:19 --> Hooks Class Initialized
DEBUG - 2023-09-24 12:39:19 --> UTF-8 Support Enabled
INFO - 2023-09-24 12:39:19 --> Utf8 Class Initialized
INFO - 2023-09-24 12:39:19 --> URI Class Initialized
INFO - 2023-09-24 12:39:19 --> Router Class Initialized
INFO - 2023-09-24 12:39:19 --> Output Class Initialized
INFO - 2023-09-24 12:39:19 --> Security Class Initialized
DEBUG - 2023-09-24 12:39:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-24 12:39:19 --> Input Class Initialized
INFO - 2023-09-24 12:39:19 --> Language Class Initialized
INFO - 2023-09-24 12:39:19 --> Language Class Initialized
INFO - 2023-09-24 12:39:19 --> Config Class Initialized
INFO - 2023-09-24 12:39:19 --> Loader Class Initialized
INFO - 2023-09-24 12:39:19 --> Helper loaded: url_helper
INFO - 2023-09-24 12:39:19 --> Helper loaded: file_helper
INFO - 2023-09-24 12:39:19 --> Helper loaded: form_helper
INFO - 2023-09-24 12:39:19 --> Helper loaded: my_helper
INFO - 2023-09-24 12:39:19 --> Database Driver Class Initialized
INFO - 2023-09-24 12:39:19 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-24 12:39:19 --> Controller Class Initialized
INFO - 2023-09-24 12:39:21 --> Config Class Initialized
INFO - 2023-09-24 12:39:21 --> Hooks Class Initialized
DEBUG - 2023-09-24 12:39:21 --> UTF-8 Support Enabled
INFO - 2023-09-24 12:39:21 --> Utf8 Class Initialized
INFO - 2023-09-24 12:39:21 --> URI Class Initialized
INFO - 2023-09-24 12:39:21 --> Router Class Initialized
INFO - 2023-09-24 12:39:21 --> Output Class Initialized
INFO - 2023-09-24 12:39:21 --> Security Class Initialized
DEBUG - 2023-09-24 12:39:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-24 12:39:21 --> Input Class Initialized
INFO - 2023-09-24 12:39:21 --> Language Class Initialized
INFO - 2023-09-24 12:39:21 --> Language Class Initialized
INFO - 2023-09-24 12:39:21 --> Config Class Initialized
INFO - 2023-09-24 12:39:21 --> Loader Class Initialized
INFO - 2023-09-24 12:39:21 --> Helper loaded: url_helper
INFO - 2023-09-24 12:39:21 --> Helper loaded: file_helper
INFO - 2023-09-24 12:39:21 --> Helper loaded: form_helper
INFO - 2023-09-24 12:39:21 --> Helper loaded: my_helper
INFO - 2023-09-24 12:39:21 --> Database Driver Class Initialized
INFO - 2023-09-24 12:39:21 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-24 12:39:21 --> Controller Class Initialized
INFO - 2023-09-24 12:39:21 --> Final output sent to browser
DEBUG - 2023-09-24 12:39:21 --> Total execution time: 0.0327
INFO - 2023-09-24 12:39:29 --> Config Class Initialized
INFO - 2023-09-24 12:39:29 --> Hooks Class Initialized
DEBUG - 2023-09-24 12:39:29 --> UTF-8 Support Enabled
INFO - 2023-09-24 12:39:29 --> Utf8 Class Initialized
INFO - 2023-09-24 12:39:29 --> URI Class Initialized
INFO - 2023-09-24 12:39:29 --> Router Class Initialized
INFO - 2023-09-24 12:39:29 --> Output Class Initialized
INFO - 2023-09-24 12:39:29 --> Security Class Initialized
DEBUG - 2023-09-24 12:39:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-24 12:39:29 --> Input Class Initialized
INFO - 2023-09-24 12:39:29 --> Language Class Initialized
INFO - 2023-09-24 12:39:29 --> Language Class Initialized
INFO - 2023-09-24 12:39:29 --> Config Class Initialized
INFO - 2023-09-24 12:39:29 --> Loader Class Initialized
INFO - 2023-09-24 12:39:29 --> Helper loaded: url_helper
INFO - 2023-09-24 12:39:29 --> Helper loaded: file_helper
INFO - 2023-09-24 12:39:29 --> Helper loaded: form_helper
INFO - 2023-09-24 12:39:29 --> Helper loaded: my_helper
INFO - 2023-09-24 12:39:29 --> Database Driver Class Initialized
INFO - 2023-09-24 12:39:29 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-24 12:39:29 --> Controller Class Initialized
INFO - 2023-09-24 12:39:29 --> Final output sent to browser
DEBUG - 2023-09-24 12:39:29 --> Total execution time: 0.0881
INFO - 2023-09-24 12:39:29 --> Config Class Initialized
INFO - 2023-09-24 12:39:29 --> Hooks Class Initialized
DEBUG - 2023-09-24 12:39:29 --> UTF-8 Support Enabled
INFO - 2023-09-24 12:39:29 --> Utf8 Class Initialized
INFO - 2023-09-24 12:39:29 --> URI Class Initialized
INFO - 2023-09-24 12:39:29 --> Router Class Initialized
INFO - 2023-09-24 12:39:29 --> Output Class Initialized
INFO - 2023-09-24 12:39:29 --> Security Class Initialized
DEBUG - 2023-09-24 12:39:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-24 12:39:29 --> Input Class Initialized
INFO - 2023-09-24 12:39:29 --> Language Class Initialized
INFO - 2023-09-24 12:39:29 --> Language Class Initialized
INFO - 2023-09-24 12:39:29 --> Config Class Initialized
INFO - 2023-09-24 12:39:29 --> Loader Class Initialized
INFO - 2023-09-24 12:39:29 --> Helper loaded: url_helper
INFO - 2023-09-24 12:39:29 --> Helper loaded: file_helper
INFO - 2023-09-24 12:39:29 --> Helper loaded: form_helper
INFO - 2023-09-24 12:39:29 --> Helper loaded: my_helper
INFO - 2023-09-24 12:39:29 --> Database Driver Class Initialized
INFO - 2023-09-24 12:39:29 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-24 12:39:29 --> Controller Class Initialized
INFO - 2023-09-24 12:39:30 --> Config Class Initialized
INFO - 2023-09-24 12:39:30 --> Hooks Class Initialized
DEBUG - 2023-09-24 12:39:30 --> UTF-8 Support Enabled
INFO - 2023-09-24 12:39:30 --> Utf8 Class Initialized
INFO - 2023-09-24 12:39:30 --> URI Class Initialized
INFO - 2023-09-24 12:39:30 --> Router Class Initialized
INFO - 2023-09-24 12:39:30 --> Output Class Initialized
INFO - 2023-09-24 12:39:30 --> Security Class Initialized
DEBUG - 2023-09-24 12:39:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-24 12:39:30 --> Input Class Initialized
INFO - 2023-09-24 12:39:30 --> Language Class Initialized
INFO - 2023-09-24 12:39:30 --> Language Class Initialized
INFO - 2023-09-24 12:39:30 --> Config Class Initialized
INFO - 2023-09-24 12:39:30 --> Loader Class Initialized
INFO - 2023-09-24 12:39:30 --> Helper loaded: url_helper
INFO - 2023-09-24 12:39:30 --> Helper loaded: file_helper
INFO - 2023-09-24 12:39:30 --> Helper loaded: form_helper
INFO - 2023-09-24 12:39:30 --> Helper loaded: my_helper
INFO - 2023-09-24 12:39:30 --> Database Driver Class Initialized
INFO - 2023-09-24 12:39:30 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-24 12:39:30 --> Controller Class Initialized
INFO - 2023-09-24 12:39:30 --> Final output sent to browser
DEBUG - 2023-09-24 12:39:30 --> Total execution time: 0.0383
INFO - 2023-09-24 12:39:37 --> Config Class Initialized
INFO - 2023-09-24 12:39:37 --> Hooks Class Initialized
DEBUG - 2023-09-24 12:39:37 --> UTF-8 Support Enabled
INFO - 2023-09-24 12:39:37 --> Utf8 Class Initialized
INFO - 2023-09-24 12:39:37 --> URI Class Initialized
INFO - 2023-09-24 12:39:37 --> Router Class Initialized
INFO - 2023-09-24 12:39:37 --> Output Class Initialized
INFO - 2023-09-24 12:39:37 --> Security Class Initialized
DEBUG - 2023-09-24 12:39:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-24 12:39:37 --> Input Class Initialized
INFO - 2023-09-24 12:39:37 --> Language Class Initialized
INFO - 2023-09-24 12:39:37 --> Language Class Initialized
INFO - 2023-09-24 12:39:37 --> Config Class Initialized
INFO - 2023-09-24 12:39:37 --> Loader Class Initialized
INFO - 2023-09-24 12:39:37 --> Helper loaded: url_helper
INFO - 2023-09-24 12:39:37 --> Helper loaded: file_helper
INFO - 2023-09-24 12:39:37 --> Helper loaded: form_helper
INFO - 2023-09-24 12:39:37 --> Helper loaded: my_helper
INFO - 2023-09-24 12:39:37 --> Database Driver Class Initialized
INFO - 2023-09-24 12:39:37 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-24 12:39:37 --> Controller Class Initialized
INFO - 2023-09-24 12:39:37 --> Final output sent to browser
DEBUG - 2023-09-24 12:39:37 --> Total execution time: 0.0570
INFO - 2023-09-24 12:39:37 --> Config Class Initialized
INFO - 2023-09-24 12:39:37 --> Hooks Class Initialized
DEBUG - 2023-09-24 12:39:37 --> UTF-8 Support Enabled
INFO - 2023-09-24 12:39:37 --> Utf8 Class Initialized
INFO - 2023-09-24 12:39:37 --> URI Class Initialized
INFO - 2023-09-24 12:39:37 --> Router Class Initialized
INFO - 2023-09-24 12:39:37 --> Output Class Initialized
INFO - 2023-09-24 12:39:37 --> Security Class Initialized
DEBUG - 2023-09-24 12:39:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-24 12:39:37 --> Input Class Initialized
INFO - 2023-09-24 12:39:37 --> Language Class Initialized
INFO - 2023-09-24 12:39:37 --> Language Class Initialized
INFO - 2023-09-24 12:39:37 --> Config Class Initialized
INFO - 2023-09-24 12:39:37 --> Loader Class Initialized
INFO - 2023-09-24 12:39:37 --> Helper loaded: url_helper
INFO - 2023-09-24 12:39:37 --> Helper loaded: file_helper
INFO - 2023-09-24 12:39:37 --> Helper loaded: form_helper
INFO - 2023-09-24 12:39:37 --> Helper loaded: my_helper
INFO - 2023-09-24 12:39:37 --> Database Driver Class Initialized
INFO - 2023-09-24 12:39:37 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-24 12:39:37 --> Controller Class Initialized
INFO - 2023-09-24 12:39:44 --> Config Class Initialized
INFO - 2023-09-24 12:39:44 --> Hooks Class Initialized
DEBUG - 2023-09-24 12:39:44 --> UTF-8 Support Enabled
INFO - 2023-09-24 12:39:44 --> Utf8 Class Initialized
INFO - 2023-09-24 12:39:44 --> URI Class Initialized
INFO - 2023-09-24 12:39:44 --> Router Class Initialized
INFO - 2023-09-24 12:39:44 --> Output Class Initialized
INFO - 2023-09-24 12:39:44 --> Security Class Initialized
DEBUG - 2023-09-24 12:39:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-24 12:39:44 --> Input Class Initialized
INFO - 2023-09-24 12:39:44 --> Language Class Initialized
INFO - 2023-09-24 12:39:44 --> Language Class Initialized
INFO - 2023-09-24 12:39:44 --> Config Class Initialized
INFO - 2023-09-24 12:39:44 --> Loader Class Initialized
INFO - 2023-09-24 12:39:44 --> Helper loaded: url_helper
INFO - 2023-09-24 12:39:44 --> Helper loaded: file_helper
INFO - 2023-09-24 12:39:44 --> Helper loaded: form_helper
INFO - 2023-09-24 12:39:44 --> Helper loaded: my_helper
INFO - 2023-09-24 12:39:44 --> Database Driver Class Initialized
INFO - 2023-09-24 12:39:44 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-24 12:39:44 --> Controller Class Initialized
ERROR - 2023-09-24 12:39:45 --> Severity: Notice --> Undefined offset: 26 /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/controllers/N_pengetahuan.php 393
ERROR - 2023-09-24 12:39:45 --> Severity: error --> Exception: Invalid cell coordinate 7 /www/wwwroot/report.mhis.link/bangka/secondary/application/third_party/PHP_Excel/PHPExcel/Cell.php 558
INFO - 2023-09-24 12:39:48 --> Config Class Initialized
INFO - 2023-09-24 12:39:48 --> Hooks Class Initialized
DEBUG - 2023-09-24 12:39:48 --> UTF-8 Support Enabled
INFO - 2023-09-24 12:39:48 --> Utf8 Class Initialized
INFO - 2023-09-24 12:39:48 --> URI Class Initialized
INFO - 2023-09-24 12:39:48 --> Router Class Initialized
INFO - 2023-09-24 12:39:48 --> Output Class Initialized
INFO - 2023-09-24 12:39:48 --> Security Class Initialized
DEBUG - 2023-09-24 12:39:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-24 12:39:48 --> Input Class Initialized
INFO - 2023-09-24 12:39:48 --> Language Class Initialized
INFO - 2023-09-24 12:39:48 --> Language Class Initialized
INFO - 2023-09-24 12:39:48 --> Config Class Initialized
INFO - 2023-09-24 12:39:48 --> Loader Class Initialized
INFO - 2023-09-24 12:39:48 --> Helper loaded: url_helper
INFO - 2023-09-24 12:39:48 --> Helper loaded: file_helper
INFO - 2023-09-24 12:39:48 --> Helper loaded: form_helper
INFO - 2023-09-24 12:39:48 --> Helper loaded: my_helper
INFO - 2023-09-24 12:39:48 --> Database Driver Class Initialized
INFO - 2023-09-24 12:39:48 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-24 12:39:48 --> Controller Class Initialized
DEBUG - 2023-09-24 12:39:48 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/views/list.php
DEBUG - 2023-09-24 12:39:48 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-09-24 12:39:48 --> Final output sent to browser
DEBUG - 2023-09-24 12:39:48 --> Total execution time: 0.0973
INFO - 2023-09-24 12:39:48 --> Config Class Initialized
INFO - 2023-09-24 12:39:48 --> Hooks Class Initialized
DEBUG - 2023-09-24 12:39:48 --> UTF-8 Support Enabled
INFO - 2023-09-24 12:39:48 --> Utf8 Class Initialized
INFO - 2023-09-24 12:39:48 --> URI Class Initialized
INFO - 2023-09-24 12:39:48 --> Router Class Initialized
INFO - 2023-09-24 12:39:48 --> Output Class Initialized
INFO - 2023-09-24 12:39:48 --> Security Class Initialized
DEBUG - 2023-09-24 12:39:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-24 12:39:48 --> Input Class Initialized
INFO - 2023-09-24 12:39:48 --> Language Class Initialized
INFO - 2023-09-24 12:39:48 --> Language Class Initialized
INFO - 2023-09-24 12:39:48 --> Config Class Initialized
INFO - 2023-09-24 12:39:48 --> Loader Class Initialized
INFO - 2023-09-24 12:39:48 --> Helper loaded: url_helper
INFO - 2023-09-24 12:39:48 --> Helper loaded: file_helper
INFO - 2023-09-24 12:39:48 --> Helper loaded: form_helper
INFO - 2023-09-24 12:39:48 --> Helper loaded: my_helper
INFO - 2023-09-24 12:39:48 --> Database Driver Class Initialized
INFO - 2023-09-24 12:39:48 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-24 12:39:48 --> Controller Class Initialized
INFO - 2023-09-24 12:45:27 --> Config Class Initialized
INFO - 2023-09-24 12:45:27 --> Hooks Class Initialized
DEBUG - 2023-09-24 12:45:27 --> UTF-8 Support Enabled
INFO - 2023-09-24 12:45:27 --> Utf8 Class Initialized
INFO - 2023-09-24 12:45:27 --> URI Class Initialized
INFO - 2023-09-24 12:45:27 --> Router Class Initialized
INFO - 2023-09-24 12:45:27 --> Output Class Initialized
INFO - 2023-09-24 12:45:27 --> Security Class Initialized
DEBUG - 2023-09-24 12:45:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-24 12:45:27 --> Input Class Initialized
INFO - 2023-09-24 12:45:27 --> Language Class Initialized
INFO - 2023-09-24 12:45:27 --> Language Class Initialized
INFO - 2023-09-24 12:45:27 --> Config Class Initialized
INFO - 2023-09-24 12:45:27 --> Loader Class Initialized
INFO - 2023-09-24 12:45:27 --> Helper loaded: url_helper
INFO - 2023-09-24 12:45:27 --> Helper loaded: file_helper
INFO - 2023-09-24 12:45:27 --> Helper loaded: form_helper
INFO - 2023-09-24 12:45:27 --> Helper loaded: my_helper
INFO - 2023-09-24 12:45:27 --> Database Driver Class Initialized
INFO - 2023-09-24 12:45:27 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-24 12:45:27 --> Controller Class Initialized
ERROR - 2023-09-24 12:45:27 --> Severity: Notice --> Undefined offset: 26 /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/controllers/N_pengetahuan.php 393
ERROR - 2023-09-24 12:45:27 --> Severity: error --> Exception: Invalid cell coordinate 7 /www/wwwroot/report.mhis.link/bangka/secondary/application/third_party/PHP_Excel/PHPExcel/Cell.php 558
INFO - 2023-09-24 12:45:29 --> Config Class Initialized
INFO - 2023-09-24 12:45:29 --> Hooks Class Initialized
DEBUG - 2023-09-24 12:45:29 --> UTF-8 Support Enabled
INFO - 2023-09-24 12:45:29 --> Utf8 Class Initialized
INFO - 2023-09-24 12:45:29 --> URI Class Initialized
INFO - 2023-09-24 12:45:29 --> Router Class Initialized
INFO - 2023-09-24 12:45:29 --> Output Class Initialized
INFO - 2023-09-24 12:45:29 --> Security Class Initialized
DEBUG - 2023-09-24 12:45:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-24 12:45:29 --> Input Class Initialized
INFO - 2023-09-24 12:45:29 --> Language Class Initialized
INFO - 2023-09-24 12:45:29 --> Language Class Initialized
INFO - 2023-09-24 12:45:29 --> Config Class Initialized
INFO - 2023-09-24 12:45:29 --> Loader Class Initialized
INFO - 2023-09-24 12:45:29 --> Helper loaded: url_helper
INFO - 2023-09-24 12:45:29 --> Helper loaded: file_helper
INFO - 2023-09-24 12:45:29 --> Helper loaded: form_helper
INFO - 2023-09-24 12:45:29 --> Helper loaded: my_helper
INFO - 2023-09-24 12:45:29 --> Database Driver Class Initialized
INFO - 2023-09-24 12:45:29 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-24 12:45:29 --> Controller Class Initialized
DEBUG - 2023-09-24 12:45:29 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/views/list.php
DEBUG - 2023-09-24 12:45:29 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-09-24 12:45:29 --> Final output sent to browser
DEBUG - 2023-09-24 12:45:29 --> Total execution time: 0.0355
INFO - 2023-09-24 12:45:29 --> Config Class Initialized
INFO - 2023-09-24 12:45:29 --> Hooks Class Initialized
DEBUG - 2023-09-24 12:45:29 --> UTF-8 Support Enabled
INFO - 2023-09-24 12:45:29 --> Utf8 Class Initialized
INFO - 2023-09-24 12:45:29 --> URI Class Initialized
INFO - 2023-09-24 12:45:29 --> Router Class Initialized
INFO - 2023-09-24 12:45:29 --> Output Class Initialized
INFO - 2023-09-24 12:45:29 --> Security Class Initialized
DEBUG - 2023-09-24 12:45:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-24 12:45:29 --> Input Class Initialized
INFO - 2023-09-24 12:45:29 --> Language Class Initialized
INFO - 2023-09-24 12:45:29 --> Language Class Initialized
INFO - 2023-09-24 12:45:29 --> Config Class Initialized
INFO - 2023-09-24 12:45:29 --> Loader Class Initialized
INFO - 2023-09-24 12:45:29 --> Helper loaded: url_helper
INFO - 2023-09-24 12:45:29 --> Helper loaded: file_helper
INFO - 2023-09-24 12:45:29 --> Helper loaded: form_helper
INFO - 2023-09-24 12:45:29 --> Helper loaded: my_helper
INFO - 2023-09-24 12:45:29 --> Database Driver Class Initialized
INFO - 2023-09-24 12:45:29 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-24 12:45:29 --> Controller Class Initialized
INFO - 2023-09-24 12:45:51 --> Config Class Initialized
INFO - 2023-09-24 12:45:51 --> Hooks Class Initialized
DEBUG - 2023-09-24 12:45:51 --> UTF-8 Support Enabled
INFO - 2023-09-24 12:45:51 --> Utf8 Class Initialized
INFO - 2023-09-24 12:45:51 --> URI Class Initialized
DEBUG - 2023-09-24 12:45:51 --> No URI present. Default controller set.
INFO - 2023-09-24 12:45:51 --> Router Class Initialized
INFO - 2023-09-24 12:45:51 --> Output Class Initialized
INFO - 2023-09-24 12:45:51 --> Security Class Initialized
DEBUG - 2023-09-24 12:45:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-24 12:45:51 --> Input Class Initialized
INFO - 2023-09-24 12:45:51 --> Language Class Initialized
INFO - 2023-09-24 12:45:51 --> Language Class Initialized
INFO - 2023-09-24 12:45:51 --> Config Class Initialized
INFO - 2023-09-24 12:45:51 --> Loader Class Initialized
INFO - 2023-09-24 12:45:51 --> Helper loaded: url_helper
INFO - 2023-09-24 12:45:51 --> Helper loaded: file_helper
INFO - 2023-09-24 12:45:51 --> Helper loaded: form_helper
INFO - 2023-09-24 12:45:51 --> Helper loaded: my_helper
INFO - 2023-09-24 12:45:51 --> Database Driver Class Initialized
INFO - 2023-09-24 12:45:51 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-24 12:45:51 --> Controller Class Initialized
DEBUG - 2023-09-24 12:45:51 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/home/views/v_home_guru.php
DEBUG - 2023-09-24 12:45:51 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-09-24 12:45:51 --> Final output sent to browser
DEBUG - 2023-09-24 12:45:51 --> Total execution time: 0.0381
