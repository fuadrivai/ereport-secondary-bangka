<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2024-08-25 14:39:57 --> Config Class Initialized
INFO - 2024-08-25 14:39:57 --> Hooks Class Initialized
DEBUG - 2024-08-25 14:39:57 --> UTF-8 Support Enabled
INFO - 2024-08-25 14:39:57 --> Utf8 Class Initialized
INFO - 2024-08-25 14:39:57 --> URI Class Initialized
INFO - 2024-08-25 14:39:57 --> Router Class Initialized
INFO - 2024-08-25 14:39:57 --> Output Class Initialized
INFO - 2024-08-25 14:39:57 --> Security Class Initialized
DEBUG - 2024-08-25 14:39:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-08-25 14:39:57 --> Input Class Initialized
INFO - 2024-08-25 14:39:57 --> Language Class Initialized
INFO - 2024-08-25 14:39:57 --> Language Class Initialized
INFO - 2024-08-25 14:39:57 --> Config Class Initialized
INFO - 2024-08-25 14:39:57 --> Loader Class Initialized
INFO - 2024-08-25 14:39:57 --> Helper loaded: url_helper
INFO - 2024-08-25 14:39:57 --> Helper loaded: file_helper
INFO - 2024-08-25 14:39:57 --> Helper loaded: form_helper
INFO - 2024-08-25 14:39:57 --> Helper loaded: my_helper
INFO - 2024-08-25 14:39:57 --> Database Driver Class Initialized
INFO - 2024-08-25 14:39:57 --> Session: Class initialized using 'files' driver.
INFO - 2024-08-25 14:39:57 --> Controller Class Initialized
INFO - 2024-08-25 14:39:57 --> Helper loaded: cookie_helper
INFO - 2024-08-25 14:39:57 --> Final output sent to browser
DEBUG - 2024-08-25 14:39:57 --> Total execution time: 0.0667
INFO - 2024-08-25 14:39:57 --> Config Class Initialized
INFO - 2024-08-25 14:39:57 --> Hooks Class Initialized
DEBUG - 2024-08-25 14:39:57 --> UTF-8 Support Enabled
INFO - 2024-08-25 14:39:57 --> Utf8 Class Initialized
INFO - 2024-08-25 14:39:57 --> URI Class Initialized
INFO - 2024-08-25 14:39:57 --> Router Class Initialized
INFO - 2024-08-25 14:39:57 --> Output Class Initialized
INFO - 2024-08-25 14:39:57 --> Security Class Initialized
DEBUG - 2024-08-25 14:39:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-08-25 14:39:57 --> Input Class Initialized
INFO - 2024-08-25 14:39:57 --> Language Class Initialized
INFO - 2024-08-25 14:39:57 --> Language Class Initialized
INFO - 2024-08-25 14:39:57 --> Config Class Initialized
INFO - 2024-08-25 14:39:57 --> Loader Class Initialized
INFO - 2024-08-25 14:39:57 --> Helper loaded: url_helper
INFO - 2024-08-25 14:39:57 --> Helper loaded: file_helper
INFO - 2024-08-25 14:39:57 --> Helper loaded: form_helper
INFO - 2024-08-25 14:39:57 --> Helper loaded: my_helper
INFO - 2024-08-25 14:39:57 --> Database Driver Class Initialized
INFO - 2024-08-25 14:39:57 --> Session: Class initialized using 'files' driver.
INFO - 2024-08-25 14:39:57 --> Controller Class Initialized
INFO - 2024-08-25 14:39:57 --> Helper loaded: cookie_helper
INFO - 2024-08-25 14:39:58 --> Config Class Initialized
INFO - 2024-08-25 14:39:58 --> Hooks Class Initialized
DEBUG - 2024-08-25 14:39:58 --> UTF-8 Support Enabled
INFO - 2024-08-25 14:39:58 --> Utf8 Class Initialized
INFO - 2024-08-25 14:39:58 --> URI Class Initialized
INFO - 2024-08-25 14:39:58 --> Router Class Initialized
INFO - 2024-08-25 14:39:58 --> Output Class Initialized
INFO - 2024-08-25 14:39:58 --> Security Class Initialized
DEBUG - 2024-08-25 14:39:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-08-25 14:39:58 --> Input Class Initialized
INFO - 2024-08-25 14:39:58 --> Language Class Initialized
INFO - 2024-08-25 14:39:58 --> Language Class Initialized
INFO - 2024-08-25 14:39:58 --> Config Class Initialized
INFO - 2024-08-25 14:39:58 --> Loader Class Initialized
INFO - 2024-08-25 14:39:58 --> Helper loaded: url_helper
INFO - 2024-08-25 14:39:58 --> Helper loaded: file_helper
INFO - 2024-08-25 14:39:58 --> Helper loaded: form_helper
INFO - 2024-08-25 14:39:58 --> Helper loaded: my_helper
INFO - 2024-08-25 14:39:58 --> Database Driver Class Initialized
INFO - 2024-08-25 14:39:58 --> Session: Class initialized using 'files' driver.
INFO - 2024-08-25 14:39:58 --> Controller Class Initialized
DEBUG - 2024-08-25 14:39:58 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/lihat_raport/views/list.php
DEBUG - 2024-08-25 14:39:58 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-08-25 14:39:58 --> Final output sent to browser
DEBUG - 2024-08-25 14:39:58 --> Total execution time: 0.1929
INFO - 2024-08-25 14:40:20 --> Config Class Initialized
INFO - 2024-08-25 14:40:20 --> Hooks Class Initialized
DEBUG - 2024-08-25 14:40:20 --> UTF-8 Support Enabled
INFO - 2024-08-25 14:40:20 --> Utf8 Class Initialized
INFO - 2024-08-25 14:40:20 --> URI Class Initialized
INFO - 2024-08-25 14:40:20 --> Router Class Initialized
INFO - 2024-08-25 14:40:20 --> Output Class Initialized
INFO - 2024-08-25 14:40:20 --> Security Class Initialized
DEBUG - 2024-08-25 14:40:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-08-25 14:40:20 --> Input Class Initialized
INFO - 2024-08-25 14:40:20 --> Language Class Initialized
INFO - 2024-08-25 14:40:20 --> Language Class Initialized
INFO - 2024-08-25 14:40:20 --> Config Class Initialized
INFO - 2024-08-25 14:40:20 --> Loader Class Initialized
INFO - 2024-08-25 14:40:20 --> Helper loaded: url_helper
INFO - 2024-08-25 14:40:20 --> Helper loaded: file_helper
INFO - 2024-08-25 14:40:20 --> Helper loaded: form_helper
INFO - 2024-08-25 14:40:20 --> Helper loaded: my_helper
INFO - 2024-08-25 14:40:20 --> Database Driver Class Initialized
INFO - 2024-08-25 14:40:20 --> Session: Class initialized using 'files' driver.
INFO - 2024-08-25 14:40:20 --> Controller Class Initialized
INFO - 2024-08-25 14:40:20 --> Helper loaded: cookie_helper
INFO - 2024-08-25 14:40:20 --> Final output sent to browser
DEBUG - 2024-08-25 14:40:20 --> Total execution time: 0.0474
INFO - 2024-08-25 14:40:20 --> Config Class Initialized
INFO - 2024-08-25 14:40:20 --> Hooks Class Initialized
DEBUG - 2024-08-25 14:40:20 --> UTF-8 Support Enabled
INFO - 2024-08-25 14:40:20 --> Utf8 Class Initialized
INFO - 2024-08-25 14:40:20 --> URI Class Initialized
INFO - 2024-08-25 14:40:20 --> Router Class Initialized
INFO - 2024-08-25 14:40:20 --> Output Class Initialized
INFO - 2024-08-25 14:40:20 --> Security Class Initialized
DEBUG - 2024-08-25 14:40:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-08-25 14:40:20 --> Input Class Initialized
INFO - 2024-08-25 14:40:20 --> Language Class Initialized
INFO - 2024-08-25 14:40:20 --> Language Class Initialized
INFO - 2024-08-25 14:40:20 --> Config Class Initialized
INFO - 2024-08-25 14:40:20 --> Loader Class Initialized
INFO - 2024-08-25 14:40:20 --> Helper loaded: url_helper
INFO - 2024-08-25 14:40:20 --> Helper loaded: file_helper
INFO - 2024-08-25 14:40:20 --> Helper loaded: form_helper
INFO - 2024-08-25 14:40:20 --> Helper loaded: my_helper
INFO - 2024-08-25 14:40:20 --> Database Driver Class Initialized
INFO - 2024-08-25 14:40:20 --> Session: Class initialized using 'files' driver.
INFO - 2024-08-25 14:40:20 --> Controller Class Initialized
INFO - 2024-08-25 14:40:20 --> Helper loaded: cookie_helper
INFO - 2024-08-25 14:40:20 --> Config Class Initialized
INFO - 2024-08-25 14:40:20 --> Hooks Class Initialized
DEBUG - 2024-08-25 14:40:20 --> UTF-8 Support Enabled
INFO - 2024-08-25 14:40:20 --> Utf8 Class Initialized
INFO - 2024-08-25 14:40:20 --> URI Class Initialized
INFO - 2024-08-25 14:40:20 --> Router Class Initialized
INFO - 2024-08-25 14:40:20 --> Output Class Initialized
INFO - 2024-08-25 14:40:20 --> Security Class Initialized
DEBUG - 2024-08-25 14:40:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-08-25 14:40:20 --> Input Class Initialized
INFO - 2024-08-25 14:40:20 --> Language Class Initialized
INFO - 2024-08-25 14:40:20 --> Language Class Initialized
INFO - 2024-08-25 14:40:20 --> Config Class Initialized
INFO - 2024-08-25 14:40:20 --> Loader Class Initialized
INFO - 2024-08-25 14:40:20 --> Helper loaded: url_helper
INFO - 2024-08-25 14:40:20 --> Helper loaded: file_helper
INFO - 2024-08-25 14:40:20 --> Helper loaded: form_helper
INFO - 2024-08-25 14:40:20 --> Helper loaded: my_helper
INFO - 2024-08-25 14:40:20 --> Database Driver Class Initialized
INFO - 2024-08-25 14:40:20 --> Session: Class initialized using 'files' driver.
INFO - 2024-08-25 14:40:20 --> Controller Class Initialized
DEBUG - 2024-08-25 14:40:20 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/lihat_raport/views/list.php
DEBUG - 2024-08-25 14:40:20 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-08-25 14:40:20 --> Final output sent to browser
DEBUG - 2024-08-25 14:40:20 --> Total execution time: 0.0354
INFO - 2024-08-25 14:40:29 --> Config Class Initialized
INFO - 2024-08-25 14:40:29 --> Hooks Class Initialized
DEBUG - 2024-08-25 14:40:29 --> UTF-8 Support Enabled
INFO - 2024-08-25 14:40:29 --> Utf8 Class Initialized
INFO - 2024-08-25 14:40:29 --> URI Class Initialized
DEBUG - 2024-08-25 14:40:29 --> No URI present. Default controller set.
INFO - 2024-08-25 14:40:29 --> Router Class Initialized
INFO - 2024-08-25 14:40:29 --> Output Class Initialized
INFO - 2024-08-25 14:40:29 --> Security Class Initialized
DEBUG - 2024-08-25 14:40:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-08-25 14:40:29 --> Input Class Initialized
INFO - 2024-08-25 14:40:29 --> Language Class Initialized
INFO - 2024-08-25 14:40:29 --> Language Class Initialized
INFO - 2024-08-25 14:40:29 --> Config Class Initialized
INFO - 2024-08-25 14:40:29 --> Loader Class Initialized
INFO - 2024-08-25 14:40:29 --> Helper loaded: url_helper
INFO - 2024-08-25 14:40:29 --> Helper loaded: file_helper
INFO - 2024-08-25 14:40:29 --> Helper loaded: form_helper
INFO - 2024-08-25 14:40:29 --> Helper loaded: my_helper
INFO - 2024-08-25 14:40:29 --> Database Driver Class Initialized
INFO - 2024-08-25 14:40:29 --> Session: Class initialized using 'files' driver.
INFO - 2024-08-25 14:40:29 --> Controller Class Initialized
DEBUG - 2024-08-25 14:40:29 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/home/views/v_home_siswa.php
DEBUG - 2024-08-25 14:40:29 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-08-25 14:40:29 --> Final output sent to browser
DEBUG - 2024-08-25 14:40:29 --> Total execution time: 0.0325
INFO - 2024-08-25 15:30:13 --> Config Class Initialized
INFO - 2024-08-25 15:30:13 --> Hooks Class Initialized
DEBUG - 2024-08-25 15:30:13 --> UTF-8 Support Enabled
INFO - 2024-08-25 15:30:13 --> Utf8 Class Initialized
INFO - 2024-08-25 15:30:13 --> URI Class Initialized
INFO - 2024-08-25 15:30:13 --> Router Class Initialized
INFO - 2024-08-25 15:30:13 --> Output Class Initialized
INFO - 2024-08-25 15:30:13 --> Security Class Initialized
DEBUG - 2024-08-25 15:30:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-08-25 15:30:13 --> Input Class Initialized
INFO - 2024-08-25 15:30:13 --> Language Class Initialized
INFO - 2024-08-25 15:30:13 --> Language Class Initialized
INFO - 2024-08-25 15:30:13 --> Config Class Initialized
INFO - 2024-08-25 15:30:13 --> Loader Class Initialized
INFO - 2024-08-25 15:30:13 --> Helper loaded: url_helper
INFO - 2024-08-25 15:30:13 --> Helper loaded: file_helper
INFO - 2024-08-25 15:30:13 --> Helper loaded: form_helper
INFO - 2024-08-25 15:30:13 --> Helper loaded: my_helper
INFO - 2024-08-25 15:30:13 --> Database Driver Class Initialized
INFO - 2024-08-25 15:30:13 --> Session: Class initialized using 'files' driver.
INFO - 2024-08-25 15:30:13 --> Controller Class Initialized
INFO - 2024-08-25 15:30:13 --> Final output sent to browser
DEBUG - 2024-08-25 15:30:13 --> Total execution time: 0.2478
INFO - 2024-08-25 15:36:25 --> Config Class Initialized
INFO - 2024-08-25 15:36:25 --> Hooks Class Initialized
DEBUG - 2024-08-25 15:36:25 --> UTF-8 Support Enabled
INFO - 2024-08-25 15:36:25 --> Utf8 Class Initialized
INFO - 2024-08-25 15:36:25 --> URI Class Initialized
INFO - 2024-08-25 15:36:25 --> Router Class Initialized
INFO - 2024-08-25 15:36:25 --> Output Class Initialized
INFO - 2024-08-25 15:36:25 --> Security Class Initialized
DEBUG - 2024-08-25 15:36:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-08-25 15:36:25 --> Input Class Initialized
INFO - 2024-08-25 15:36:25 --> Language Class Initialized
INFO - 2024-08-25 15:36:25 --> Language Class Initialized
INFO - 2024-08-25 15:36:25 --> Config Class Initialized
INFO - 2024-08-25 15:36:25 --> Loader Class Initialized
INFO - 2024-08-25 15:36:25 --> Helper loaded: url_helper
INFO - 2024-08-25 15:36:25 --> Helper loaded: file_helper
INFO - 2024-08-25 15:36:25 --> Helper loaded: form_helper
INFO - 2024-08-25 15:36:25 --> Helper loaded: my_helper
INFO - 2024-08-25 15:36:25 --> Database Driver Class Initialized
INFO - 2024-08-25 15:36:25 --> Session: Class initialized using 'files' driver.
INFO - 2024-08-25 15:36:25 --> Controller Class Initialized
INFO - 2024-08-25 15:36:25 --> Final output sent to browser
DEBUG - 2024-08-25 15:36:25 --> Total execution time: 0.0885
INFO - 2024-08-25 15:36:31 --> Config Class Initialized
INFO - 2024-08-25 15:36:31 --> Hooks Class Initialized
DEBUG - 2024-08-25 15:36:31 --> UTF-8 Support Enabled
INFO - 2024-08-25 15:36:31 --> Utf8 Class Initialized
INFO - 2024-08-25 15:36:31 --> URI Class Initialized
INFO - 2024-08-25 15:36:31 --> Router Class Initialized
INFO - 2024-08-25 15:36:31 --> Output Class Initialized
INFO - 2024-08-25 15:36:31 --> Security Class Initialized
DEBUG - 2024-08-25 15:36:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-08-25 15:36:31 --> Input Class Initialized
INFO - 2024-08-25 15:36:31 --> Language Class Initialized
INFO - 2024-08-25 15:36:31 --> Language Class Initialized
INFO - 2024-08-25 15:36:31 --> Config Class Initialized
INFO - 2024-08-25 15:36:31 --> Loader Class Initialized
INFO - 2024-08-25 15:36:31 --> Helper loaded: url_helper
INFO - 2024-08-25 15:36:31 --> Helper loaded: file_helper
INFO - 2024-08-25 15:36:31 --> Helper loaded: form_helper
INFO - 2024-08-25 15:36:31 --> Helper loaded: my_helper
INFO - 2024-08-25 15:36:31 --> Database Driver Class Initialized
INFO - 2024-08-25 15:36:31 --> Session: Class initialized using 'files' driver.
INFO - 2024-08-25 15:36:31 --> Controller Class Initialized
INFO - 2024-08-25 15:36:31 --> Final output sent to browser
DEBUG - 2024-08-25 15:36:31 --> Total execution time: 0.0467
INFO - 2024-08-25 15:36:41 --> Config Class Initialized
INFO - 2024-08-25 15:36:41 --> Hooks Class Initialized
DEBUG - 2024-08-25 15:36:41 --> UTF-8 Support Enabled
INFO - 2024-08-25 15:36:41 --> Utf8 Class Initialized
INFO - 2024-08-25 15:36:41 --> URI Class Initialized
INFO - 2024-08-25 15:36:41 --> Router Class Initialized
INFO - 2024-08-25 15:36:41 --> Output Class Initialized
INFO - 2024-08-25 15:36:41 --> Security Class Initialized
DEBUG - 2024-08-25 15:36:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-08-25 15:36:41 --> Input Class Initialized
INFO - 2024-08-25 15:36:41 --> Language Class Initialized
INFO - 2024-08-25 15:36:41 --> Language Class Initialized
INFO - 2024-08-25 15:36:41 --> Config Class Initialized
INFO - 2024-08-25 15:36:41 --> Loader Class Initialized
INFO - 2024-08-25 15:36:41 --> Helper loaded: url_helper
INFO - 2024-08-25 15:36:41 --> Helper loaded: file_helper
INFO - 2024-08-25 15:36:41 --> Helper loaded: form_helper
INFO - 2024-08-25 15:36:41 --> Helper loaded: my_helper
INFO - 2024-08-25 15:36:41 --> Database Driver Class Initialized
INFO - 2024-08-25 15:36:41 --> Session: Class initialized using 'files' driver.
INFO - 2024-08-25 15:36:41 --> Controller Class Initialized
INFO - 2024-08-25 15:36:41 --> Final output sent to browser
DEBUG - 2024-08-25 15:36:41 --> Total execution time: 0.3256
