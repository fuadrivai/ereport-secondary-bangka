<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2023-11-28 09:43:32 --> Config Class Initialized
INFO - 2023-11-28 09:43:32 --> Hooks Class Initialized
DEBUG - 2023-11-28 09:43:32 --> UTF-8 Support Enabled
INFO - 2023-11-28 09:43:32 --> Utf8 Class Initialized
INFO - 2023-11-28 09:43:32 --> URI Class Initialized
DEBUG - 2023-11-28 09:43:32 --> No URI present. Default controller set.
INFO - 2023-11-28 09:43:32 --> Router Class Initialized
INFO - 2023-11-28 09:43:32 --> Output Class Initialized
INFO - 2023-11-28 09:43:32 --> Security Class Initialized
DEBUG - 2023-11-28 09:43:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-28 09:43:32 --> Input Class Initialized
INFO - 2023-11-28 09:43:32 --> Language Class Initialized
INFO - 2023-11-28 09:43:32 --> Language Class Initialized
INFO - 2023-11-28 09:43:32 --> Config Class Initialized
INFO - 2023-11-28 09:43:32 --> Loader Class Initialized
INFO - 2023-11-28 09:43:32 --> Helper loaded: url_helper
INFO - 2023-11-28 09:43:32 --> Helper loaded: file_helper
INFO - 2023-11-28 09:43:32 --> Helper loaded: form_helper
INFO - 2023-11-28 09:43:32 --> Helper loaded: my_helper
INFO - 2023-11-28 09:43:32 --> Database Driver Class Initialized
INFO - 2023-11-28 09:43:32 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-28 09:43:32 --> Controller Class Initialized
DEBUG - 2023-11-28 09:43:32 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/home/views/v_home.php
DEBUG - 2023-11-28 09:43:32 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-11-28 09:43:32 --> Final output sent to browser
DEBUG - 2023-11-28 09:43:32 --> Total execution time: 0.0559
INFO - 2023-11-28 09:43:33 --> Config Class Initialized
INFO - 2023-11-28 09:43:33 --> Hooks Class Initialized
DEBUG - 2023-11-28 09:43:33 --> UTF-8 Support Enabled
INFO - 2023-11-28 09:43:33 --> Utf8 Class Initialized
INFO - 2023-11-28 09:43:33 --> URI Class Initialized
INFO - 2023-11-28 09:43:33 --> Router Class Initialized
INFO - 2023-11-28 09:43:33 --> Output Class Initialized
INFO - 2023-11-28 09:43:33 --> Security Class Initialized
DEBUG - 2023-11-28 09:43:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-28 09:43:33 --> Input Class Initialized
INFO - 2023-11-28 09:43:33 --> Language Class Initialized
INFO - 2023-11-28 09:43:33 --> Language Class Initialized
INFO - 2023-11-28 09:43:33 --> Config Class Initialized
INFO - 2023-11-28 09:43:33 --> Loader Class Initialized
INFO - 2023-11-28 09:43:33 --> Helper loaded: url_helper
INFO - 2023-11-28 09:43:33 --> Helper loaded: file_helper
INFO - 2023-11-28 09:43:33 --> Helper loaded: form_helper
INFO - 2023-11-28 09:43:33 --> Helper loaded: my_helper
INFO - 2023-11-28 09:43:33 --> Database Driver Class Initialized
INFO - 2023-11-28 09:43:33 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-28 09:43:33 --> Controller Class Initialized
DEBUG - 2023-11-28 09:43:33 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/data_mapel/views/list.php
DEBUG - 2023-11-28 09:43:33 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-11-28 09:43:33 --> Final output sent to browser
DEBUG - 2023-11-28 09:43:33 --> Total execution time: 0.0341
INFO - 2023-11-28 09:43:33 --> Config Class Initialized
INFO - 2023-11-28 09:43:33 --> Hooks Class Initialized
DEBUG - 2023-11-28 09:43:33 --> UTF-8 Support Enabled
INFO - 2023-11-28 09:43:33 --> Utf8 Class Initialized
INFO - 2023-11-28 09:43:33 --> URI Class Initialized
INFO - 2023-11-28 09:43:33 --> Router Class Initialized
INFO - 2023-11-28 09:43:33 --> Output Class Initialized
INFO - 2023-11-28 09:43:33 --> Security Class Initialized
DEBUG - 2023-11-28 09:43:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-28 09:43:33 --> Input Class Initialized
INFO - 2023-11-28 09:43:33 --> Language Class Initialized
ERROR - 2023-11-28 09:43:33 --> 404 Page Not Found: /index
INFO - 2023-11-28 09:43:33 --> Config Class Initialized
INFO - 2023-11-28 09:43:33 --> Hooks Class Initialized
DEBUG - 2023-11-28 09:43:33 --> UTF-8 Support Enabled
INFO - 2023-11-28 09:43:33 --> Utf8 Class Initialized
INFO - 2023-11-28 09:43:33 --> URI Class Initialized
INFO - 2023-11-28 09:43:33 --> Router Class Initialized
INFO - 2023-11-28 09:43:33 --> Output Class Initialized
INFO - 2023-11-28 09:43:33 --> Security Class Initialized
DEBUG - 2023-11-28 09:43:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-28 09:43:33 --> Input Class Initialized
INFO - 2023-11-28 09:43:33 --> Language Class Initialized
INFO - 2023-11-28 09:43:33 --> Language Class Initialized
INFO - 2023-11-28 09:43:33 --> Config Class Initialized
INFO - 2023-11-28 09:43:33 --> Loader Class Initialized
INFO - 2023-11-28 09:43:33 --> Helper loaded: url_helper
INFO - 2023-11-28 09:43:33 --> Helper loaded: file_helper
INFO - 2023-11-28 09:43:33 --> Helper loaded: form_helper
INFO - 2023-11-28 09:43:33 --> Helper loaded: my_helper
INFO - 2023-11-28 09:43:33 --> Database Driver Class Initialized
INFO - 2023-11-28 09:43:33 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-28 09:43:33 --> Controller Class Initialized
INFO - 2023-11-28 09:43:35 --> Config Class Initialized
INFO - 2023-11-28 09:43:35 --> Hooks Class Initialized
DEBUG - 2023-11-28 09:43:35 --> UTF-8 Support Enabled
INFO - 2023-11-28 09:43:35 --> Utf8 Class Initialized
INFO - 2023-11-28 09:43:35 --> URI Class Initialized
INFO - 2023-11-28 09:43:35 --> Router Class Initialized
INFO - 2023-11-28 09:43:35 --> Output Class Initialized
INFO - 2023-11-28 09:43:35 --> Security Class Initialized
DEBUG - 2023-11-28 09:43:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-28 09:43:35 --> Input Class Initialized
INFO - 2023-11-28 09:43:35 --> Language Class Initialized
INFO - 2023-11-28 09:43:35 --> Language Class Initialized
INFO - 2023-11-28 09:43:35 --> Config Class Initialized
INFO - 2023-11-28 09:43:35 --> Loader Class Initialized
INFO - 2023-11-28 09:43:35 --> Helper loaded: url_helper
INFO - 2023-11-28 09:43:35 --> Helper loaded: file_helper
INFO - 2023-11-28 09:43:35 --> Helper loaded: form_helper
INFO - 2023-11-28 09:43:35 --> Helper loaded: my_helper
INFO - 2023-11-28 09:43:35 --> Database Driver Class Initialized
INFO - 2023-11-28 09:43:35 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-28 09:43:35 --> Controller Class Initialized
INFO - 2023-11-28 09:43:35 --> Final output sent to browser
DEBUG - 2023-11-28 09:43:35 --> Total execution time: 0.0350
INFO - 2023-11-28 09:58:46 --> Config Class Initialized
INFO - 2023-11-28 09:58:46 --> Hooks Class Initialized
DEBUG - 2023-11-28 09:58:46 --> UTF-8 Support Enabled
INFO - 2023-11-28 09:58:46 --> Utf8 Class Initialized
INFO - 2023-11-28 09:58:46 --> URI Class Initialized
INFO - 2023-11-28 09:58:46 --> Router Class Initialized
INFO - 2023-11-28 09:58:46 --> Output Class Initialized
INFO - 2023-11-28 09:58:46 --> Security Class Initialized
DEBUG - 2023-11-28 09:58:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-28 09:58:46 --> Input Class Initialized
INFO - 2023-11-28 09:58:46 --> Language Class Initialized
INFO - 2023-11-28 09:58:46 --> Language Class Initialized
INFO - 2023-11-28 09:58:46 --> Config Class Initialized
INFO - 2023-11-28 09:58:46 --> Loader Class Initialized
INFO - 2023-11-28 09:58:46 --> Helper loaded: url_helper
INFO - 2023-11-28 09:58:46 --> Helper loaded: file_helper
INFO - 2023-11-28 09:58:46 --> Helper loaded: form_helper
INFO - 2023-11-28 09:58:46 --> Helper loaded: my_helper
INFO - 2023-11-28 09:58:46 --> Database Driver Class Initialized
INFO - 2023-11-28 09:58:46 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-28 09:58:46 --> Controller Class Initialized
INFO - 2023-11-28 09:58:47 --> Config Class Initialized
INFO - 2023-11-28 09:58:47 --> Hooks Class Initialized
DEBUG - 2023-11-28 09:58:47 --> UTF-8 Support Enabled
INFO - 2023-11-28 09:58:47 --> Utf8 Class Initialized
INFO - 2023-11-28 09:58:47 --> URI Class Initialized
INFO - 2023-11-28 09:58:47 --> Router Class Initialized
INFO - 2023-11-28 09:58:47 --> Output Class Initialized
INFO - 2023-11-28 09:58:47 --> Security Class Initialized
DEBUG - 2023-11-28 09:58:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-28 09:58:47 --> Input Class Initialized
INFO - 2023-11-28 09:58:47 --> Language Class Initialized
INFO - 2023-11-28 09:58:47 --> Language Class Initialized
INFO - 2023-11-28 09:58:47 --> Config Class Initialized
INFO - 2023-11-28 09:58:47 --> Loader Class Initialized
INFO - 2023-11-28 09:58:47 --> Helper loaded: url_helper
INFO - 2023-11-28 09:58:47 --> Helper loaded: file_helper
INFO - 2023-11-28 09:58:47 --> Helper loaded: form_helper
INFO - 2023-11-28 09:58:47 --> Helper loaded: my_helper
INFO - 2023-11-28 09:58:47 --> Database Driver Class Initialized
INFO - 2023-11-28 09:58:47 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-28 09:58:47 --> Controller Class Initialized
INFO - 2023-11-28 11:19:56 --> Config Class Initialized
INFO - 2023-11-28 11:19:56 --> Hooks Class Initialized
DEBUG - 2023-11-28 11:19:56 --> UTF-8 Support Enabled
INFO - 2023-11-28 11:19:56 --> Utf8 Class Initialized
INFO - 2023-11-28 11:19:56 --> URI Class Initialized
INFO - 2023-11-28 11:19:56 --> Router Class Initialized
INFO - 2023-11-28 11:19:56 --> Output Class Initialized
INFO - 2023-11-28 11:19:56 --> Security Class Initialized
DEBUG - 2023-11-28 11:19:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-28 11:19:56 --> Input Class Initialized
INFO - 2023-11-28 11:19:56 --> Language Class Initialized
INFO - 2023-11-28 11:19:56 --> Language Class Initialized
INFO - 2023-11-28 11:19:56 --> Config Class Initialized
INFO - 2023-11-28 11:19:56 --> Loader Class Initialized
INFO - 2023-11-28 11:19:56 --> Helper loaded: url_helper
INFO - 2023-11-28 11:19:56 --> Helper loaded: file_helper
INFO - 2023-11-28 11:19:56 --> Helper loaded: form_helper
INFO - 2023-11-28 11:19:56 --> Helper loaded: my_helper
INFO - 2023-11-28 11:19:56 --> Database Driver Class Initialized
INFO - 2023-11-28 11:19:56 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-28 11:19:56 --> Controller Class Initialized
INFO - 2023-11-28 11:19:56 --> Config Class Initialized
INFO - 2023-11-28 11:19:56 --> Hooks Class Initialized
DEBUG - 2023-11-28 11:19:56 --> UTF-8 Support Enabled
INFO - 2023-11-28 11:19:56 --> Utf8 Class Initialized
INFO - 2023-11-28 11:19:56 --> URI Class Initialized
INFO - 2023-11-28 11:19:56 --> Router Class Initialized
INFO - 2023-11-28 11:19:56 --> Output Class Initialized
INFO - 2023-11-28 11:19:56 --> Security Class Initialized
DEBUG - 2023-11-28 11:19:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-28 11:19:56 --> Input Class Initialized
INFO - 2023-11-28 11:19:56 --> Language Class Initialized
INFO - 2023-11-28 11:19:56 --> Language Class Initialized
INFO - 2023-11-28 11:19:56 --> Config Class Initialized
INFO - 2023-11-28 11:19:56 --> Loader Class Initialized
INFO - 2023-11-28 11:19:56 --> Helper loaded: url_helper
INFO - 2023-11-28 11:19:56 --> Helper loaded: file_helper
INFO - 2023-11-28 11:19:56 --> Helper loaded: form_helper
INFO - 2023-11-28 11:19:56 --> Helper loaded: my_helper
INFO - 2023-11-28 11:19:56 --> Database Driver Class Initialized
INFO - 2023-11-28 11:19:56 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-28 11:19:56 --> Controller Class Initialized
DEBUG - 2023-11-28 11:19:56 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/login/views/login.php
DEBUG - 2023-11-28 11:19:56 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-11-28 11:19:56 --> Final output sent to browser
DEBUG - 2023-11-28 11:19:56 --> Total execution time: 0.0376
INFO - 2023-11-28 11:19:59 --> Config Class Initialized
INFO - 2023-11-28 11:19:59 --> Hooks Class Initialized
DEBUG - 2023-11-28 11:19:59 --> UTF-8 Support Enabled
INFO - 2023-11-28 11:19:59 --> Utf8 Class Initialized
INFO - 2023-11-28 11:19:59 --> URI Class Initialized
INFO - 2023-11-28 11:19:59 --> Router Class Initialized
INFO - 2023-11-28 11:19:59 --> Output Class Initialized
INFO - 2023-11-28 11:19:59 --> Security Class Initialized
DEBUG - 2023-11-28 11:19:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-28 11:19:59 --> Input Class Initialized
INFO - 2023-11-28 11:19:59 --> Language Class Initialized
INFO - 2023-11-28 11:19:59 --> Language Class Initialized
INFO - 2023-11-28 11:19:59 --> Config Class Initialized
INFO - 2023-11-28 11:19:59 --> Loader Class Initialized
INFO - 2023-11-28 11:19:59 --> Helper loaded: url_helper
INFO - 2023-11-28 11:19:59 --> Helper loaded: file_helper
INFO - 2023-11-28 11:19:59 --> Helper loaded: form_helper
INFO - 2023-11-28 11:19:59 --> Helper loaded: my_helper
INFO - 2023-11-28 11:19:59 --> Database Driver Class Initialized
INFO - 2023-11-28 11:19:59 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-28 11:19:59 --> Controller Class Initialized
INFO - 2023-11-28 11:19:59 --> Helper loaded: cookie_helper
INFO - 2023-11-28 11:19:59 --> Final output sent to browser
DEBUG - 2023-11-28 11:19:59 --> Total execution time: 0.0575
INFO - 2023-11-28 11:19:59 --> Config Class Initialized
INFO - 2023-11-28 11:19:59 --> Hooks Class Initialized
DEBUG - 2023-11-28 11:19:59 --> UTF-8 Support Enabled
INFO - 2023-11-28 11:19:59 --> Utf8 Class Initialized
INFO - 2023-11-28 11:19:59 --> URI Class Initialized
INFO - 2023-11-28 11:19:59 --> Router Class Initialized
INFO - 2023-11-28 11:19:59 --> Output Class Initialized
INFO - 2023-11-28 11:19:59 --> Security Class Initialized
DEBUG - 2023-11-28 11:19:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-28 11:19:59 --> Input Class Initialized
INFO - 2023-11-28 11:19:59 --> Language Class Initialized
INFO - 2023-11-28 11:19:59 --> Language Class Initialized
INFO - 2023-11-28 11:19:59 --> Config Class Initialized
INFO - 2023-11-28 11:19:59 --> Loader Class Initialized
INFO - 2023-11-28 11:19:59 --> Helper loaded: url_helper
INFO - 2023-11-28 11:19:59 --> Helper loaded: file_helper
INFO - 2023-11-28 11:19:59 --> Helper loaded: form_helper
INFO - 2023-11-28 11:19:59 --> Helper loaded: my_helper
INFO - 2023-11-28 11:19:59 --> Database Driver Class Initialized
INFO - 2023-11-28 11:19:59 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-28 11:19:59 --> Controller Class Initialized
DEBUG - 2023-11-28 11:19:59 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/home/views/v_home_guru.php
DEBUG - 2023-11-28 11:19:59 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-11-28 11:19:59 --> Final output sent to browser
DEBUG - 2023-11-28 11:19:59 --> Total execution time: 0.0410
INFO - 2023-11-28 11:20:02 --> Config Class Initialized
INFO - 2023-11-28 11:20:02 --> Hooks Class Initialized
DEBUG - 2023-11-28 11:20:02 --> UTF-8 Support Enabled
INFO - 2023-11-28 11:20:02 --> Utf8 Class Initialized
INFO - 2023-11-28 11:20:02 --> URI Class Initialized
INFO - 2023-11-28 11:20:02 --> Router Class Initialized
INFO - 2023-11-28 11:20:02 --> Output Class Initialized
INFO - 2023-11-28 11:20:02 --> Security Class Initialized
DEBUG - 2023-11-28 11:20:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-28 11:20:02 --> Input Class Initialized
INFO - 2023-11-28 11:20:02 --> Language Class Initialized
INFO - 2023-11-28 11:20:02 --> Language Class Initialized
INFO - 2023-11-28 11:20:02 --> Config Class Initialized
INFO - 2023-11-28 11:20:02 --> Loader Class Initialized
INFO - 2023-11-28 11:20:02 --> Helper loaded: url_helper
INFO - 2023-11-28 11:20:02 --> Helper loaded: file_helper
INFO - 2023-11-28 11:20:02 --> Helper loaded: form_helper
INFO - 2023-11-28 11:20:02 --> Helper loaded: my_helper
INFO - 2023-11-28 11:20:02 --> Database Driver Class Initialized
INFO - 2023-11-28 11:20:02 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-28 11:20:02 --> Controller Class Initialized
DEBUG - 2023-11-28 11:20:02 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/view_mapel/views/v_view_mapel.php
DEBUG - 2023-11-28 11:20:02 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-11-28 11:20:02 --> Final output sent to browser
DEBUG - 2023-11-28 11:20:02 --> Total execution time: 0.1912
INFO - 2023-11-28 11:20:10 --> Config Class Initialized
INFO - 2023-11-28 11:20:10 --> Hooks Class Initialized
DEBUG - 2023-11-28 11:20:10 --> UTF-8 Support Enabled
INFO - 2023-11-28 11:20:10 --> Utf8 Class Initialized
INFO - 2023-11-28 11:20:10 --> URI Class Initialized
INFO - 2023-11-28 11:20:10 --> Router Class Initialized
INFO - 2023-11-28 11:20:10 --> Output Class Initialized
INFO - 2023-11-28 11:20:10 --> Security Class Initialized
DEBUG - 2023-11-28 11:20:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-28 11:20:10 --> Input Class Initialized
INFO - 2023-11-28 11:20:10 --> Language Class Initialized
INFO - 2023-11-28 11:20:10 --> Language Class Initialized
INFO - 2023-11-28 11:20:10 --> Config Class Initialized
INFO - 2023-11-28 11:20:10 --> Loader Class Initialized
INFO - 2023-11-28 11:20:10 --> Helper loaded: url_helper
INFO - 2023-11-28 11:20:10 --> Helper loaded: file_helper
INFO - 2023-11-28 11:20:10 --> Helper loaded: form_helper
INFO - 2023-11-28 11:20:10 --> Helper loaded: my_helper
INFO - 2023-11-28 11:20:10 --> Database Driver Class Initialized
INFO - 2023-11-28 11:20:10 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-28 11:20:10 --> Controller Class Initialized
DEBUG - 2023-11-28 11:20:10 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/views/list.php
DEBUG - 2023-11-28 11:20:10 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-11-28 11:20:10 --> Final output sent to browser
DEBUG - 2023-11-28 11:20:10 --> Total execution time: 0.2924
INFO - 2023-11-28 11:20:10 --> Config Class Initialized
INFO - 2023-11-28 11:20:10 --> Hooks Class Initialized
DEBUG - 2023-11-28 11:20:10 --> UTF-8 Support Enabled
INFO - 2023-11-28 11:20:10 --> Utf8 Class Initialized
INFO - 2023-11-28 11:20:10 --> URI Class Initialized
INFO - 2023-11-28 11:20:10 --> Router Class Initialized
INFO - 2023-11-28 11:20:10 --> Output Class Initialized
INFO - 2023-11-28 11:20:10 --> Security Class Initialized
DEBUG - 2023-11-28 11:20:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-28 11:20:10 --> Input Class Initialized
INFO - 2023-11-28 11:20:10 --> Language Class Initialized
INFO - 2023-11-28 11:20:10 --> Language Class Initialized
INFO - 2023-11-28 11:20:10 --> Config Class Initialized
INFO - 2023-11-28 11:20:10 --> Loader Class Initialized
INFO - 2023-11-28 11:20:10 --> Helper loaded: url_helper
INFO - 2023-11-28 11:20:10 --> Helper loaded: file_helper
INFO - 2023-11-28 11:20:10 --> Helper loaded: form_helper
INFO - 2023-11-28 11:20:10 --> Helper loaded: my_helper
INFO - 2023-11-28 11:20:10 --> Database Driver Class Initialized
INFO - 2023-11-28 11:20:10 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-28 11:20:10 --> Controller Class Initialized
INFO - 2023-11-28 11:20:13 --> Config Class Initialized
INFO - 2023-11-28 11:20:13 --> Hooks Class Initialized
DEBUG - 2023-11-28 11:20:13 --> UTF-8 Support Enabled
INFO - 2023-11-28 11:20:13 --> Utf8 Class Initialized
INFO - 2023-11-28 11:20:13 --> URI Class Initialized
INFO - 2023-11-28 11:20:13 --> Router Class Initialized
INFO - 2023-11-28 11:20:13 --> Output Class Initialized
INFO - 2023-11-28 11:20:13 --> Security Class Initialized
DEBUG - 2023-11-28 11:20:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-28 11:20:13 --> Input Class Initialized
INFO - 2023-11-28 11:20:13 --> Language Class Initialized
INFO - 2023-11-28 11:20:13 --> Language Class Initialized
INFO - 2023-11-28 11:20:13 --> Config Class Initialized
INFO - 2023-11-28 11:20:13 --> Loader Class Initialized
INFO - 2023-11-28 11:20:13 --> Helper loaded: url_helper
INFO - 2023-11-28 11:20:13 --> Helper loaded: file_helper
INFO - 2023-11-28 11:20:13 --> Helper loaded: form_helper
INFO - 2023-11-28 11:20:13 --> Helper loaded: my_helper
INFO - 2023-11-28 11:20:13 --> Database Driver Class Initialized
INFO - 2023-11-28 11:20:13 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-28 11:20:13 --> Controller Class Initialized
INFO - 2023-11-28 11:20:17 --> Config Class Initialized
INFO - 2023-11-28 11:20:17 --> Hooks Class Initialized
DEBUG - 2023-11-28 11:20:17 --> UTF-8 Support Enabled
INFO - 2023-11-28 11:20:17 --> Utf8 Class Initialized
INFO - 2023-11-28 11:20:17 --> URI Class Initialized
INFO - 2023-11-28 11:20:17 --> Router Class Initialized
INFO - 2023-11-28 11:20:17 --> Output Class Initialized
INFO - 2023-11-28 11:20:17 --> Security Class Initialized
DEBUG - 2023-11-28 11:20:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-28 11:20:17 --> Input Class Initialized
INFO - 2023-11-28 11:20:17 --> Language Class Initialized
INFO - 2023-11-28 11:20:17 --> Language Class Initialized
INFO - 2023-11-28 11:20:17 --> Config Class Initialized
INFO - 2023-11-28 11:20:17 --> Loader Class Initialized
INFO - 2023-11-28 11:20:17 --> Helper loaded: url_helper
INFO - 2023-11-28 11:20:17 --> Helper loaded: file_helper
INFO - 2023-11-28 11:20:17 --> Helper loaded: form_helper
INFO - 2023-11-28 11:20:17 --> Helper loaded: my_helper
INFO - 2023-11-28 11:20:17 --> Database Driver Class Initialized
INFO - 2023-11-28 11:20:17 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-28 11:20:17 --> Controller Class Initialized
DEBUG - 2023-11-28 11:20:17 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/view_mapel/views/v_view_mapel.php
DEBUG - 2023-11-28 11:20:17 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-11-28 11:20:17 --> Final output sent to browser
DEBUG - 2023-11-28 11:20:17 --> Total execution time: 0.0335
INFO - 2023-11-28 11:20:18 --> Config Class Initialized
INFO - 2023-11-28 11:20:18 --> Hooks Class Initialized
DEBUG - 2023-11-28 11:20:18 --> UTF-8 Support Enabled
INFO - 2023-11-28 11:20:18 --> Utf8 Class Initialized
INFO - 2023-11-28 11:20:18 --> URI Class Initialized
INFO - 2023-11-28 11:20:18 --> Router Class Initialized
INFO - 2023-11-28 11:20:18 --> Output Class Initialized
INFO - 2023-11-28 11:20:18 --> Security Class Initialized
DEBUG - 2023-11-28 11:20:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-28 11:20:18 --> Input Class Initialized
INFO - 2023-11-28 11:20:18 --> Language Class Initialized
INFO - 2023-11-28 11:20:18 --> Language Class Initialized
INFO - 2023-11-28 11:20:18 --> Config Class Initialized
INFO - 2023-11-28 11:20:18 --> Loader Class Initialized
INFO - 2023-11-28 11:20:18 --> Helper loaded: url_helper
INFO - 2023-11-28 11:20:18 --> Helper loaded: file_helper
INFO - 2023-11-28 11:20:18 --> Helper loaded: form_helper
INFO - 2023-11-28 11:20:18 --> Helper loaded: my_helper
INFO - 2023-11-28 11:20:18 --> Database Driver Class Initialized
INFO - 2023-11-28 11:20:18 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-28 11:20:18 --> Controller Class Initialized
DEBUG - 2023-11-28 11:20:18 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/views/list.php
DEBUG - 2023-11-28 11:20:18 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-11-28 11:20:18 --> Final output sent to browser
DEBUG - 2023-11-28 11:20:18 --> Total execution time: 0.0488
INFO - 2023-11-28 11:20:18 --> Config Class Initialized
INFO - 2023-11-28 11:20:18 --> Hooks Class Initialized
DEBUG - 2023-11-28 11:20:18 --> UTF-8 Support Enabled
INFO - 2023-11-28 11:20:18 --> Utf8 Class Initialized
INFO - 2023-11-28 11:20:18 --> URI Class Initialized
INFO - 2023-11-28 11:20:18 --> Router Class Initialized
INFO - 2023-11-28 11:20:18 --> Output Class Initialized
INFO - 2023-11-28 11:20:18 --> Security Class Initialized
DEBUG - 2023-11-28 11:20:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-28 11:20:18 --> Input Class Initialized
INFO - 2023-11-28 11:20:18 --> Language Class Initialized
INFO - 2023-11-28 11:20:18 --> Language Class Initialized
INFO - 2023-11-28 11:20:18 --> Config Class Initialized
INFO - 2023-11-28 11:20:18 --> Loader Class Initialized
INFO - 2023-11-28 11:20:18 --> Helper loaded: url_helper
INFO - 2023-11-28 11:20:18 --> Helper loaded: file_helper
INFO - 2023-11-28 11:20:18 --> Helper loaded: form_helper
INFO - 2023-11-28 11:20:18 --> Helper loaded: my_helper
INFO - 2023-11-28 11:20:18 --> Database Driver Class Initialized
INFO - 2023-11-28 11:20:18 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-28 11:20:18 --> Controller Class Initialized
INFO - 2023-11-28 11:20:20 --> Config Class Initialized
INFO - 2023-11-28 11:20:20 --> Hooks Class Initialized
DEBUG - 2023-11-28 11:20:20 --> UTF-8 Support Enabled
INFO - 2023-11-28 11:20:20 --> Utf8 Class Initialized
INFO - 2023-11-28 11:20:20 --> URI Class Initialized
INFO - 2023-11-28 11:20:20 --> Router Class Initialized
INFO - 2023-11-28 11:20:20 --> Output Class Initialized
INFO - 2023-11-28 11:20:20 --> Security Class Initialized
DEBUG - 2023-11-28 11:20:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-28 11:20:20 --> Input Class Initialized
INFO - 2023-11-28 11:20:20 --> Language Class Initialized
INFO - 2023-11-28 11:20:20 --> Language Class Initialized
INFO - 2023-11-28 11:20:20 --> Config Class Initialized
INFO - 2023-11-28 11:20:20 --> Loader Class Initialized
INFO - 2023-11-28 11:20:20 --> Helper loaded: url_helper
INFO - 2023-11-28 11:20:20 --> Helper loaded: file_helper
INFO - 2023-11-28 11:20:20 --> Helper loaded: form_helper
INFO - 2023-11-28 11:20:20 --> Helper loaded: my_helper
INFO - 2023-11-28 11:20:20 --> Database Driver Class Initialized
INFO - 2023-11-28 11:20:20 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-28 11:20:20 --> Controller Class Initialized
