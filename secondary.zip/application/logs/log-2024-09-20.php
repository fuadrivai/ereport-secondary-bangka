<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2024-09-20 09:54:20 --> Config Class Initialized
INFO - 2024-09-20 09:54:20 --> Hooks Class Initialized
DEBUG - 2024-09-20 09:54:20 --> UTF-8 Support Enabled
INFO - 2024-09-20 09:54:20 --> Utf8 Class Initialized
INFO - 2024-09-20 09:54:20 --> URI Class Initialized
INFO - 2024-09-20 09:54:20 --> Router Class Initialized
INFO - 2024-09-20 09:54:20 --> Output Class Initialized
INFO - 2024-09-20 09:54:20 --> Security Class Initialized
DEBUG - 2024-09-20 09:54:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-20 09:54:20 --> Input Class Initialized
INFO - 2024-09-20 09:54:20 --> Language Class Initialized
INFO - 2024-09-20 09:54:20 --> Language Class Initialized
INFO - 2024-09-20 09:54:20 --> Config Class Initialized
INFO - 2024-09-20 09:54:20 --> Loader Class Initialized
INFO - 2024-09-20 09:54:20 --> Helper loaded: url_helper
INFO - 2024-09-20 09:54:20 --> Helper loaded: file_helper
INFO - 2024-09-20 09:54:20 --> Helper loaded: form_helper
INFO - 2024-09-20 09:54:20 --> Helper loaded: my_helper
INFO - 2024-09-20 09:54:20 --> Database Driver Class Initialized
INFO - 2024-09-20 09:54:20 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-20 09:54:20 --> Controller Class Initialized
DEBUG - 2024-09-20 09:54:20 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/login/views/login.php
DEBUG - 2024-09-20 09:54:20 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-09-20 09:54:20 --> Final output sent to browser
DEBUG - 2024-09-20 09:54:20 --> Total execution time: 0.0553
INFO - 2024-09-20 09:54:33 --> Config Class Initialized
INFO - 2024-09-20 09:54:33 --> Hooks Class Initialized
DEBUG - 2024-09-20 09:54:33 --> UTF-8 Support Enabled
INFO - 2024-09-20 09:54:33 --> Utf8 Class Initialized
INFO - 2024-09-20 09:54:33 --> URI Class Initialized
INFO - 2024-09-20 09:54:33 --> Router Class Initialized
INFO - 2024-09-20 09:54:33 --> Output Class Initialized
INFO - 2024-09-20 09:54:33 --> Security Class Initialized
DEBUG - 2024-09-20 09:54:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-20 09:54:33 --> Input Class Initialized
INFO - 2024-09-20 09:54:33 --> Language Class Initialized
INFO - 2024-09-20 09:54:33 --> Language Class Initialized
INFO - 2024-09-20 09:54:33 --> Config Class Initialized
INFO - 2024-09-20 09:54:33 --> Loader Class Initialized
INFO - 2024-09-20 09:54:33 --> Helper loaded: url_helper
INFO - 2024-09-20 09:54:33 --> Helper loaded: file_helper
INFO - 2024-09-20 09:54:33 --> Helper loaded: form_helper
INFO - 2024-09-20 09:54:33 --> Helper loaded: my_helper
INFO - 2024-09-20 09:54:33 --> Database Driver Class Initialized
INFO - 2024-09-20 09:54:33 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-20 09:54:33 --> Controller Class Initialized
INFO - 2024-09-20 09:54:33 --> Helper loaded: cookie_helper
INFO - 2024-09-20 09:54:33 --> Final output sent to browser
DEBUG - 2024-09-20 09:54:33 --> Total execution time: 0.0395
INFO - 2024-09-20 09:54:33 --> Config Class Initialized
INFO - 2024-09-20 09:54:33 --> Hooks Class Initialized
DEBUG - 2024-09-20 09:54:33 --> UTF-8 Support Enabled
INFO - 2024-09-20 09:54:33 --> Utf8 Class Initialized
INFO - 2024-09-20 09:54:33 --> URI Class Initialized
INFO - 2024-09-20 09:54:33 --> Router Class Initialized
INFO - 2024-09-20 09:54:33 --> Output Class Initialized
INFO - 2024-09-20 09:54:33 --> Security Class Initialized
DEBUG - 2024-09-20 09:54:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-20 09:54:33 --> Input Class Initialized
INFO - 2024-09-20 09:54:33 --> Language Class Initialized
INFO - 2024-09-20 09:54:33 --> Language Class Initialized
INFO - 2024-09-20 09:54:33 --> Config Class Initialized
INFO - 2024-09-20 09:54:33 --> Loader Class Initialized
INFO - 2024-09-20 09:54:33 --> Helper loaded: url_helper
INFO - 2024-09-20 09:54:33 --> Helper loaded: file_helper
INFO - 2024-09-20 09:54:33 --> Helper loaded: form_helper
INFO - 2024-09-20 09:54:33 --> Helper loaded: my_helper
INFO - 2024-09-20 09:54:33 --> Database Driver Class Initialized
INFO - 2024-09-20 09:54:33 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-20 09:54:33 --> Controller Class Initialized
DEBUG - 2024-09-20 09:54:33 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/home/views/v_home_guru.php
DEBUG - 2024-09-20 09:54:33 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-09-20 09:54:33 --> Final output sent to browser
DEBUG - 2024-09-20 09:54:33 --> Total execution time: 0.0319
INFO - 2024-09-20 09:54:37 --> Config Class Initialized
INFO - 2024-09-20 09:54:37 --> Hooks Class Initialized
DEBUG - 2024-09-20 09:54:37 --> UTF-8 Support Enabled
INFO - 2024-09-20 09:54:37 --> Utf8 Class Initialized
INFO - 2024-09-20 09:54:37 --> URI Class Initialized
INFO - 2024-09-20 09:54:37 --> Router Class Initialized
INFO - 2024-09-20 09:54:37 --> Output Class Initialized
INFO - 2024-09-20 09:54:37 --> Security Class Initialized
DEBUG - 2024-09-20 09:54:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-20 09:54:37 --> Input Class Initialized
INFO - 2024-09-20 09:54:37 --> Language Class Initialized
INFO - 2024-09-20 09:54:37 --> Language Class Initialized
INFO - 2024-09-20 09:54:37 --> Config Class Initialized
INFO - 2024-09-20 09:54:37 --> Loader Class Initialized
INFO - 2024-09-20 09:54:37 --> Helper loaded: url_helper
INFO - 2024-09-20 09:54:37 --> Helper loaded: file_helper
INFO - 2024-09-20 09:54:37 --> Helper loaded: form_helper
INFO - 2024-09-20 09:54:37 --> Helper loaded: my_helper
INFO - 2024-09-20 09:54:37 --> Database Driver Class Initialized
INFO - 2024-09-20 09:54:37 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-20 09:54:37 --> Controller Class Initialized
DEBUG - 2024-09-20 09:54:37 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/view_mapel/views/v_view_mapel.php
DEBUG - 2024-09-20 09:54:37 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-09-20 09:54:37 --> Final output sent to browser
DEBUG - 2024-09-20 09:54:37 --> Total execution time: 0.0324
INFO - 2024-09-20 09:54:41 --> Config Class Initialized
INFO - 2024-09-20 09:54:41 --> Hooks Class Initialized
DEBUG - 2024-09-20 09:54:41 --> UTF-8 Support Enabled
INFO - 2024-09-20 09:54:41 --> Utf8 Class Initialized
INFO - 2024-09-20 09:54:41 --> URI Class Initialized
INFO - 2024-09-20 09:54:41 --> Router Class Initialized
INFO - 2024-09-20 09:54:41 --> Output Class Initialized
INFO - 2024-09-20 09:54:41 --> Security Class Initialized
DEBUG - 2024-09-20 09:54:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-20 09:54:41 --> Input Class Initialized
INFO - 2024-09-20 09:54:41 --> Language Class Initialized
INFO - 2024-09-20 09:54:41 --> Language Class Initialized
INFO - 2024-09-20 09:54:41 --> Config Class Initialized
INFO - 2024-09-20 09:54:41 --> Loader Class Initialized
INFO - 2024-09-20 09:54:41 --> Helper loaded: url_helper
INFO - 2024-09-20 09:54:41 --> Helper loaded: file_helper
INFO - 2024-09-20 09:54:41 --> Helper loaded: form_helper
INFO - 2024-09-20 09:54:41 --> Helper loaded: my_helper
INFO - 2024-09-20 09:54:41 --> Database Driver Class Initialized
INFO - 2024-09-20 09:54:41 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-20 09:54:41 --> Controller Class Initialized
DEBUG - 2024-09-20 09:54:41 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/views/list.php
DEBUG - 2024-09-20 09:54:41 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-09-20 09:54:41 --> Final output sent to browser
DEBUG - 2024-09-20 09:54:41 --> Total execution time: 0.0373
INFO - 2024-09-20 09:54:41 --> Config Class Initialized
INFO - 2024-09-20 09:54:41 --> Hooks Class Initialized
DEBUG - 2024-09-20 09:54:41 --> UTF-8 Support Enabled
INFO - 2024-09-20 09:54:41 --> Utf8 Class Initialized
INFO - 2024-09-20 09:54:41 --> URI Class Initialized
INFO - 2024-09-20 09:54:41 --> Router Class Initialized
INFO - 2024-09-20 09:54:41 --> Output Class Initialized
INFO - 2024-09-20 09:54:41 --> Security Class Initialized
DEBUG - 2024-09-20 09:54:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-20 09:54:41 --> Input Class Initialized
INFO - 2024-09-20 09:54:41 --> Language Class Initialized
INFO - 2024-09-20 09:54:41 --> Language Class Initialized
INFO - 2024-09-20 09:54:41 --> Config Class Initialized
INFO - 2024-09-20 09:54:41 --> Loader Class Initialized
INFO - 2024-09-20 09:54:41 --> Helper loaded: url_helper
INFO - 2024-09-20 09:54:41 --> Helper loaded: file_helper
INFO - 2024-09-20 09:54:41 --> Helper loaded: form_helper
INFO - 2024-09-20 09:54:41 --> Helper loaded: my_helper
INFO - 2024-09-20 09:54:41 --> Database Driver Class Initialized
INFO - 2024-09-20 09:54:41 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-20 09:54:41 --> Controller Class Initialized
INFO - 2024-09-20 09:54:46 --> Config Class Initialized
INFO - 2024-09-20 09:54:46 --> Hooks Class Initialized
DEBUG - 2024-09-20 09:54:46 --> UTF-8 Support Enabled
INFO - 2024-09-20 09:54:46 --> Utf8 Class Initialized
INFO - 2024-09-20 09:54:46 --> URI Class Initialized
INFO - 2024-09-20 09:54:46 --> Router Class Initialized
INFO - 2024-09-20 09:54:46 --> Output Class Initialized
INFO - 2024-09-20 09:54:46 --> Security Class Initialized
DEBUG - 2024-09-20 09:54:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-20 09:54:46 --> Input Class Initialized
INFO - 2024-09-20 09:54:46 --> Language Class Initialized
INFO - 2024-09-20 09:54:46 --> Language Class Initialized
INFO - 2024-09-20 09:54:46 --> Config Class Initialized
INFO - 2024-09-20 09:54:46 --> Loader Class Initialized
INFO - 2024-09-20 09:54:46 --> Helper loaded: url_helper
INFO - 2024-09-20 09:54:46 --> Helper loaded: file_helper
INFO - 2024-09-20 09:54:46 --> Helper loaded: form_helper
INFO - 2024-09-20 09:54:46 --> Helper loaded: my_helper
INFO - 2024-09-20 09:54:46 --> Database Driver Class Initialized
INFO - 2024-09-20 09:54:46 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-20 09:54:46 --> Controller Class Initialized
INFO - 2024-09-20 09:54:46 --> Final output sent to browser
DEBUG - 2024-09-20 09:54:46 --> Total execution time: 0.0309
INFO - 2024-09-20 09:55:33 --> Config Class Initialized
INFO - 2024-09-20 09:55:33 --> Hooks Class Initialized
DEBUG - 2024-09-20 09:55:33 --> UTF-8 Support Enabled
INFO - 2024-09-20 09:55:33 --> Utf8 Class Initialized
INFO - 2024-09-20 09:55:33 --> URI Class Initialized
INFO - 2024-09-20 09:55:33 --> Router Class Initialized
INFO - 2024-09-20 09:55:33 --> Output Class Initialized
INFO - 2024-09-20 09:55:33 --> Security Class Initialized
DEBUG - 2024-09-20 09:55:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-20 09:55:33 --> Input Class Initialized
INFO - 2024-09-20 09:55:33 --> Language Class Initialized
INFO - 2024-09-20 09:55:33 --> Language Class Initialized
INFO - 2024-09-20 09:55:33 --> Config Class Initialized
INFO - 2024-09-20 09:55:33 --> Loader Class Initialized
INFO - 2024-09-20 09:55:33 --> Helper loaded: url_helper
INFO - 2024-09-20 09:55:33 --> Helper loaded: file_helper
INFO - 2024-09-20 09:55:33 --> Helper loaded: form_helper
INFO - 2024-09-20 09:55:33 --> Helper loaded: my_helper
INFO - 2024-09-20 09:55:33 --> Database Driver Class Initialized
INFO - 2024-09-20 09:55:33 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-20 09:55:33 --> Controller Class Initialized
INFO - 2024-09-20 09:55:33 --> Final output sent to browser
DEBUG - 2024-09-20 09:55:33 --> Total execution time: 0.1321
INFO - 2024-09-20 09:56:17 --> Config Class Initialized
INFO - 2024-09-20 09:56:17 --> Hooks Class Initialized
DEBUG - 2024-09-20 09:56:17 --> UTF-8 Support Enabled
INFO - 2024-09-20 09:56:17 --> Utf8 Class Initialized
INFO - 2024-09-20 09:56:17 --> URI Class Initialized
INFO - 2024-09-20 09:56:17 --> Router Class Initialized
INFO - 2024-09-20 09:56:17 --> Output Class Initialized
INFO - 2024-09-20 09:56:17 --> Security Class Initialized
DEBUG - 2024-09-20 09:56:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-20 09:56:17 --> Input Class Initialized
INFO - 2024-09-20 09:56:17 --> Language Class Initialized
INFO - 2024-09-20 09:56:17 --> Language Class Initialized
INFO - 2024-09-20 09:56:17 --> Config Class Initialized
INFO - 2024-09-20 09:56:17 --> Loader Class Initialized
INFO - 2024-09-20 09:56:17 --> Helper loaded: url_helper
INFO - 2024-09-20 09:56:17 --> Helper loaded: file_helper
INFO - 2024-09-20 09:56:17 --> Helper loaded: form_helper
INFO - 2024-09-20 09:56:17 --> Helper loaded: my_helper
INFO - 2024-09-20 09:56:17 --> Database Driver Class Initialized
INFO - 2024-09-20 09:56:17 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-20 09:56:17 --> Controller Class Initialized
INFO - 2024-09-20 09:56:17 --> Final output sent to browser
DEBUG - 2024-09-20 09:56:17 --> Total execution time: 0.1403
INFO - 2024-09-20 09:56:26 --> Config Class Initialized
INFO - 2024-09-20 09:56:26 --> Hooks Class Initialized
DEBUG - 2024-09-20 09:56:26 --> UTF-8 Support Enabled
INFO - 2024-09-20 09:56:26 --> Utf8 Class Initialized
INFO - 2024-09-20 09:56:26 --> URI Class Initialized
INFO - 2024-09-20 09:56:26 --> Router Class Initialized
INFO - 2024-09-20 09:56:26 --> Output Class Initialized
INFO - 2024-09-20 09:56:26 --> Security Class Initialized
DEBUG - 2024-09-20 09:56:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-20 09:56:26 --> Input Class Initialized
INFO - 2024-09-20 09:56:26 --> Language Class Initialized
INFO - 2024-09-20 09:56:26 --> Language Class Initialized
INFO - 2024-09-20 09:56:26 --> Config Class Initialized
INFO - 2024-09-20 09:56:26 --> Loader Class Initialized
INFO - 2024-09-20 09:56:26 --> Helper loaded: url_helper
INFO - 2024-09-20 09:56:26 --> Helper loaded: file_helper
INFO - 2024-09-20 09:56:26 --> Helper loaded: form_helper
INFO - 2024-09-20 09:56:26 --> Helper loaded: my_helper
INFO - 2024-09-20 09:56:26 --> Database Driver Class Initialized
INFO - 2024-09-20 09:56:26 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-20 09:56:26 --> Controller Class Initialized
INFO - 2024-09-20 09:56:26 --> Final output sent to browser
DEBUG - 2024-09-20 09:56:26 --> Total execution time: 0.1270
INFO - 2024-09-20 09:56:34 --> Config Class Initialized
INFO - 2024-09-20 09:56:34 --> Hooks Class Initialized
DEBUG - 2024-09-20 09:56:34 --> UTF-8 Support Enabled
INFO - 2024-09-20 09:56:34 --> Utf8 Class Initialized
INFO - 2024-09-20 09:56:34 --> URI Class Initialized
INFO - 2024-09-20 09:56:34 --> Router Class Initialized
INFO - 2024-09-20 09:56:34 --> Output Class Initialized
INFO - 2024-09-20 09:56:34 --> Security Class Initialized
DEBUG - 2024-09-20 09:56:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-20 09:56:34 --> Input Class Initialized
INFO - 2024-09-20 09:56:34 --> Language Class Initialized
INFO - 2024-09-20 09:56:34 --> Language Class Initialized
INFO - 2024-09-20 09:56:34 --> Config Class Initialized
INFO - 2024-09-20 09:56:34 --> Loader Class Initialized
INFO - 2024-09-20 09:56:34 --> Helper loaded: url_helper
INFO - 2024-09-20 09:56:34 --> Helper loaded: file_helper
INFO - 2024-09-20 09:56:34 --> Helper loaded: form_helper
INFO - 2024-09-20 09:56:34 --> Helper loaded: my_helper
INFO - 2024-09-20 09:56:34 --> Database Driver Class Initialized
INFO - 2024-09-20 09:56:34 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-20 09:56:34 --> Controller Class Initialized
INFO - 2024-09-20 09:56:34 --> Final output sent to browser
DEBUG - 2024-09-20 09:56:34 --> Total execution time: 0.3803
INFO - 2024-09-20 09:56:40 --> Config Class Initialized
INFO - 2024-09-20 09:56:40 --> Hooks Class Initialized
DEBUG - 2024-09-20 09:56:40 --> UTF-8 Support Enabled
INFO - 2024-09-20 09:56:40 --> Utf8 Class Initialized
INFO - 2024-09-20 09:56:40 --> URI Class Initialized
INFO - 2024-09-20 09:56:40 --> Router Class Initialized
INFO - 2024-09-20 09:56:40 --> Output Class Initialized
INFO - 2024-09-20 09:56:40 --> Security Class Initialized
DEBUG - 2024-09-20 09:56:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-20 09:56:40 --> Input Class Initialized
INFO - 2024-09-20 09:56:40 --> Language Class Initialized
INFO - 2024-09-20 09:56:40 --> Language Class Initialized
INFO - 2024-09-20 09:56:40 --> Config Class Initialized
INFO - 2024-09-20 09:56:40 --> Loader Class Initialized
INFO - 2024-09-20 09:56:40 --> Helper loaded: url_helper
INFO - 2024-09-20 09:56:40 --> Helper loaded: file_helper
INFO - 2024-09-20 09:56:40 --> Helper loaded: form_helper
INFO - 2024-09-20 09:56:40 --> Helper loaded: my_helper
INFO - 2024-09-20 09:56:40 --> Database Driver Class Initialized
INFO - 2024-09-20 09:56:40 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-20 09:56:40 --> Controller Class Initialized
INFO - 2024-09-20 09:56:40 --> Final output sent to browser
DEBUG - 2024-09-20 09:56:40 --> Total execution time: 0.1433
INFO - 2024-09-20 09:56:45 --> Config Class Initialized
INFO - 2024-09-20 09:56:45 --> Hooks Class Initialized
DEBUG - 2024-09-20 09:56:45 --> UTF-8 Support Enabled
INFO - 2024-09-20 09:56:45 --> Utf8 Class Initialized
INFO - 2024-09-20 09:56:45 --> URI Class Initialized
INFO - 2024-09-20 09:56:45 --> Router Class Initialized
INFO - 2024-09-20 09:56:45 --> Output Class Initialized
INFO - 2024-09-20 09:56:45 --> Security Class Initialized
DEBUG - 2024-09-20 09:56:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-20 09:56:45 --> Input Class Initialized
INFO - 2024-09-20 09:56:45 --> Language Class Initialized
INFO - 2024-09-20 09:56:45 --> Language Class Initialized
INFO - 2024-09-20 09:56:45 --> Config Class Initialized
INFO - 2024-09-20 09:56:45 --> Loader Class Initialized
INFO - 2024-09-20 09:56:45 --> Helper loaded: url_helper
INFO - 2024-09-20 09:56:45 --> Helper loaded: file_helper
INFO - 2024-09-20 09:56:45 --> Helper loaded: form_helper
INFO - 2024-09-20 09:56:45 --> Helper loaded: my_helper
INFO - 2024-09-20 09:56:45 --> Database Driver Class Initialized
INFO - 2024-09-20 09:56:45 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-20 09:56:45 --> Controller Class Initialized
INFO - 2024-09-20 09:56:45 --> Final output sent to browser
DEBUG - 2024-09-20 09:56:45 --> Total execution time: 0.2666
INFO - 2024-09-20 09:56:55 --> Config Class Initialized
INFO - 2024-09-20 09:56:55 --> Hooks Class Initialized
DEBUG - 2024-09-20 09:56:55 --> UTF-8 Support Enabled
INFO - 2024-09-20 09:56:55 --> Utf8 Class Initialized
INFO - 2024-09-20 09:56:55 --> URI Class Initialized
INFO - 2024-09-20 09:56:55 --> Router Class Initialized
INFO - 2024-09-20 09:56:55 --> Output Class Initialized
INFO - 2024-09-20 09:56:55 --> Security Class Initialized
DEBUG - 2024-09-20 09:56:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-20 09:56:55 --> Input Class Initialized
INFO - 2024-09-20 09:56:55 --> Language Class Initialized
INFO - 2024-09-20 09:56:55 --> Language Class Initialized
INFO - 2024-09-20 09:56:55 --> Config Class Initialized
INFO - 2024-09-20 09:56:55 --> Loader Class Initialized
INFO - 2024-09-20 09:56:55 --> Helper loaded: url_helper
INFO - 2024-09-20 09:56:55 --> Helper loaded: file_helper
INFO - 2024-09-20 09:56:55 --> Helper loaded: form_helper
INFO - 2024-09-20 09:56:55 --> Helper loaded: my_helper
INFO - 2024-09-20 09:56:55 --> Database Driver Class Initialized
INFO - 2024-09-20 09:56:55 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-20 09:56:55 --> Controller Class Initialized
INFO - 2024-09-20 09:56:55 --> Final output sent to browser
DEBUG - 2024-09-20 09:56:55 --> Total execution time: 0.1189
INFO - 2024-09-20 09:57:00 --> Config Class Initialized
INFO - 2024-09-20 09:57:00 --> Hooks Class Initialized
DEBUG - 2024-09-20 09:57:00 --> UTF-8 Support Enabled
INFO - 2024-09-20 09:57:00 --> Utf8 Class Initialized
INFO - 2024-09-20 09:57:00 --> URI Class Initialized
INFO - 2024-09-20 09:57:00 --> Router Class Initialized
INFO - 2024-09-20 09:57:00 --> Output Class Initialized
INFO - 2024-09-20 09:57:00 --> Security Class Initialized
DEBUG - 2024-09-20 09:57:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-20 09:57:00 --> Input Class Initialized
INFO - 2024-09-20 09:57:00 --> Language Class Initialized
INFO - 2024-09-20 09:57:00 --> Language Class Initialized
INFO - 2024-09-20 09:57:00 --> Config Class Initialized
INFO - 2024-09-20 09:57:00 --> Loader Class Initialized
INFO - 2024-09-20 09:57:00 --> Helper loaded: url_helper
INFO - 2024-09-20 09:57:00 --> Helper loaded: file_helper
INFO - 2024-09-20 09:57:00 --> Helper loaded: form_helper
INFO - 2024-09-20 09:57:00 --> Helper loaded: my_helper
INFO - 2024-09-20 09:57:00 --> Database Driver Class Initialized
INFO - 2024-09-20 09:57:00 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-20 09:57:00 --> Controller Class Initialized
INFO - 2024-09-20 09:57:00 --> Final output sent to browser
DEBUG - 2024-09-20 09:57:00 --> Total execution time: 0.1437
INFO - 2024-09-20 09:57:07 --> Config Class Initialized
INFO - 2024-09-20 09:57:07 --> Hooks Class Initialized
DEBUG - 2024-09-20 09:57:07 --> UTF-8 Support Enabled
INFO - 2024-09-20 09:57:07 --> Utf8 Class Initialized
INFO - 2024-09-20 09:57:07 --> URI Class Initialized
INFO - 2024-09-20 09:57:07 --> Router Class Initialized
INFO - 2024-09-20 09:57:07 --> Output Class Initialized
INFO - 2024-09-20 09:57:07 --> Security Class Initialized
DEBUG - 2024-09-20 09:57:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-20 09:57:07 --> Input Class Initialized
INFO - 2024-09-20 09:57:07 --> Language Class Initialized
INFO - 2024-09-20 09:57:07 --> Language Class Initialized
INFO - 2024-09-20 09:57:07 --> Config Class Initialized
INFO - 2024-09-20 09:57:07 --> Loader Class Initialized
INFO - 2024-09-20 09:57:07 --> Helper loaded: url_helper
INFO - 2024-09-20 09:57:07 --> Helper loaded: file_helper
INFO - 2024-09-20 09:57:07 --> Helper loaded: form_helper
INFO - 2024-09-20 09:57:07 --> Helper loaded: my_helper
INFO - 2024-09-20 09:57:07 --> Database Driver Class Initialized
INFO - 2024-09-20 09:57:07 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-20 09:57:07 --> Controller Class Initialized
INFO - 2024-09-20 09:57:07 --> Final output sent to browser
DEBUG - 2024-09-20 09:57:07 --> Total execution time: 0.1356
INFO - 2024-09-20 09:57:13 --> Config Class Initialized
INFO - 2024-09-20 09:57:13 --> Hooks Class Initialized
DEBUG - 2024-09-20 09:57:13 --> UTF-8 Support Enabled
INFO - 2024-09-20 09:57:13 --> Utf8 Class Initialized
INFO - 2024-09-20 09:57:13 --> URI Class Initialized
INFO - 2024-09-20 09:57:13 --> Router Class Initialized
INFO - 2024-09-20 09:57:13 --> Output Class Initialized
INFO - 2024-09-20 09:57:13 --> Security Class Initialized
DEBUG - 2024-09-20 09:57:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-20 09:57:13 --> Input Class Initialized
INFO - 2024-09-20 09:57:13 --> Language Class Initialized
INFO - 2024-09-20 09:57:13 --> Language Class Initialized
INFO - 2024-09-20 09:57:13 --> Config Class Initialized
INFO - 2024-09-20 09:57:13 --> Loader Class Initialized
INFO - 2024-09-20 09:57:13 --> Helper loaded: url_helper
INFO - 2024-09-20 09:57:13 --> Helper loaded: file_helper
INFO - 2024-09-20 09:57:13 --> Helper loaded: form_helper
INFO - 2024-09-20 09:57:13 --> Helper loaded: my_helper
INFO - 2024-09-20 09:57:13 --> Database Driver Class Initialized
INFO - 2024-09-20 09:57:13 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-20 09:57:13 --> Controller Class Initialized
INFO - 2024-09-20 09:57:14 --> Final output sent to browser
DEBUG - 2024-09-20 09:57:14 --> Total execution time: 0.1480
INFO - 2024-09-20 09:57:27 --> Config Class Initialized
INFO - 2024-09-20 09:57:27 --> Hooks Class Initialized
DEBUG - 2024-09-20 09:57:27 --> UTF-8 Support Enabled
INFO - 2024-09-20 09:57:27 --> Utf8 Class Initialized
INFO - 2024-09-20 09:57:27 --> URI Class Initialized
INFO - 2024-09-20 09:57:27 --> Router Class Initialized
INFO - 2024-09-20 09:57:27 --> Output Class Initialized
INFO - 2024-09-20 09:57:27 --> Security Class Initialized
DEBUG - 2024-09-20 09:57:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-20 09:57:27 --> Input Class Initialized
INFO - 2024-09-20 09:57:27 --> Language Class Initialized
INFO - 2024-09-20 09:57:27 --> Language Class Initialized
INFO - 2024-09-20 09:57:27 --> Config Class Initialized
INFO - 2024-09-20 09:57:27 --> Loader Class Initialized
INFO - 2024-09-20 09:57:27 --> Helper loaded: url_helper
INFO - 2024-09-20 09:57:27 --> Helper loaded: file_helper
INFO - 2024-09-20 09:57:27 --> Helper loaded: form_helper
INFO - 2024-09-20 09:57:27 --> Helper loaded: my_helper
INFO - 2024-09-20 09:57:27 --> Database Driver Class Initialized
INFO - 2024-09-20 09:57:27 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-20 09:57:27 --> Controller Class Initialized
INFO - 2024-09-20 09:57:27 --> Final output sent to browser
DEBUG - 2024-09-20 09:57:27 --> Total execution time: 0.1683
INFO - 2024-09-20 09:57:32 --> Config Class Initialized
INFO - 2024-09-20 09:57:32 --> Hooks Class Initialized
DEBUG - 2024-09-20 09:57:32 --> UTF-8 Support Enabled
INFO - 2024-09-20 09:57:32 --> Utf8 Class Initialized
INFO - 2024-09-20 09:57:32 --> URI Class Initialized
INFO - 2024-09-20 09:57:32 --> Router Class Initialized
INFO - 2024-09-20 09:57:32 --> Output Class Initialized
INFO - 2024-09-20 09:57:32 --> Security Class Initialized
DEBUG - 2024-09-20 09:57:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-20 09:57:32 --> Input Class Initialized
INFO - 2024-09-20 09:57:32 --> Language Class Initialized
INFO - 2024-09-20 09:57:32 --> Language Class Initialized
INFO - 2024-09-20 09:57:32 --> Config Class Initialized
INFO - 2024-09-20 09:57:32 --> Loader Class Initialized
INFO - 2024-09-20 09:57:32 --> Helper loaded: url_helper
INFO - 2024-09-20 09:57:32 --> Helper loaded: file_helper
INFO - 2024-09-20 09:57:32 --> Helper loaded: form_helper
INFO - 2024-09-20 09:57:32 --> Helper loaded: my_helper
INFO - 2024-09-20 09:57:32 --> Database Driver Class Initialized
INFO - 2024-09-20 09:57:32 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-20 09:57:32 --> Controller Class Initialized
INFO - 2024-09-20 09:57:32 --> Final output sent to browser
DEBUG - 2024-09-20 09:57:32 --> Total execution time: 0.1322
INFO - 2024-09-20 09:57:39 --> Config Class Initialized
INFO - 2024-09-20 09:57:39 --> Hooks Class Initialized
DEBUG - 2024-09-20 09:57:39 --> UTF-8 Support Enabled
INFO - 2024-09-20 09:57:39 --> Utf8 Class Initialized
INFO - 2024-09-20 09:57:39 --> URI Class Initialized
INFO - 2024-09-20 09:57:39 --> Router Class Initialized
INFO - 2024-09-20 09:57:39 --> Output Class Initialized
INFO - 2024-09-20 09:57:39 --> Security Class Initialized
DEBUG - 2024-09-20 09:57:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-20 09:57:39 --> Input Class Initialized
INFO - 2024-09-20 09:57:39 --> Language Class Initialized
INFO - 2024-09-20 09:57:39 --> Language Class Initialized
INFO - 2024-09-20 09:57:39 --> Config Class Initialized
INFO - 2024-09-20 09:57:39 --> Loader Class Initialized
INFO - 2024-09-20 09:57:39 --> Helper loaded: url_helper
INFO - 2024-09-20 09:57:39 --> Helper loaded: file_helper
INFO - 2024-09-20 09:57:39 --> Helper loaded: form_helper
INFO - 2024-09-20 09:57:39 --> Helper loaded: my_helper
INFO - 2024-09-20 09:57:39 --> Database Driver Class Initialized
INFO - 2024-09-20 09:57:39 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-20 09:57:39 --> Controller Class Initialized
INFO - 2024-09-20 09:57:39 --> Final output sent to browser
DEBUG - 2024-09-20 09:57:39 --> Total execution time: 0.1254
INFO - 2024-09-20 10:05:57 --> Config Class Initialized
INFO - 2024-09-20 10:05:57 --> Hooks Class Initialized
DEBUG - 2024-09-20 10:05:57 --> UTF-8 Support Enabled
INFO - 2024-09-20 10:05:57 --> Utf8 Class Initialized
INFO - 2024-09-20 10:05:57 --> URI Class Initialized
INFO - 2024-09-20 10:05:57 --> Router Class Initialized
INFO - 2024-09-20 10:05:57 --> Output Class Initialized
INFO - 2024-09-20 10:05:57 --> Security Class Initialized
DEBUG - 2024-09-20 10:05:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-20 10:05:57 --> Input Class Initialized
INFO - 2024-09-20 10:05:57 --> Language Class Initialized
INFO - 2024-09-20 10:05:57 --> Language Class Initialized
INFO - 2024-09-20 10:05:57 --> Config Class Initialized
INFO - 2024-09-20 10:05:57 --> Loader Class Initialized
INFO - 2024-09-20 10:05:57 --> Helper loaded: url_helper
INFO - 2024-09-20 10:05:57 --> Helper loaded: file_helper
INFO - 2024-09-20 10:05:57 --> Helper loaded: form_helper
INFO - 2024-09-20 10:05:57 --> Helper loaded: my_helper
INFO - 2024-09-20 10:05:57 --> Database Driver Class Initialized
INFO - 2024-09-20 10:05:57 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-20 10:05:57 --> Controller Class Initialized
INFO - 2024-09-20 10:05:57 --> Final output sent to browser
DEBUG - 2024-09-20 10:05:57 --> Total execution time: 0.2956
INFO - 2024-09-20 10:07:24 --> Config Class Initialized
INFO - 2024-09-20 10:07:24 --> Hooks Class Initialized
DEBUG - 2024-09-20 10:07:24 --> UTF-8 Support Enabled
INFO - 2024-09-20 10:07:24 --> Utf8 Class Initialized
INFO - 2024-09-20 10:07:24 --> URI Class Initialized
INFO - 2024-09-20 10:07:24 --> Router Class Initialized
INFO - 2024-09-20 10:07:24 --> Output Class Initialized
INFO - 2024-09-20 10:07:24 --> Security Class Initialized
DEBUG - 2024-09-20 10:07:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-20 10:07:24 --> Input Class Initialized
INFO - 2024-09-20 10:07:24 --> Language Class Initialized
INFO - 2024-09-20 10:07:24 --> Language Class Initialized
INFO - 2024-09-20 10:07:24 --> Config Class Initialized
INFO - 2024-09-20 10:07:24 --> Loader Class Initialized
INFO - 2024-09-20 10:07:24 --> Helper loaded: url_helper
INFO - 2024-09-20 10:07:24 --> Helper loaded: file_helper
INFO - 2024-09-20 10:07:24 --> Helper loaded: form_helper
INFO - 2024-09-20 10:07:24 --> Helper loaded: my_helper
INFO - 2024-09-20 10:07:24 --> Database Driver Class Initialized
INFO - 2024-09-20 10:07:24 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-20 10:07:24 --> Controller Class Initialized
INFO - 2024-09-20 10:07:24 --> Final output sent to browser
DEBUG - 2024-09-20 10:07:24 --> Total execution time: 0.1962
INFO - 2024-09-20 10:07:30 --> Config Class Initialized
INFO - 2024-09-20 10:07:30 --> Hooks Class Initialized
DEBUG - 2024-09-20 10:07:30 --> UTF-8 Support Enabled
INFO - 2024-09-20 10:07:30 --> Utf8 Class Initialized
INFO - 2024-09-20 10:07:30 --> URI Class Initialized
INFO - 2024-09-20 10:07:30 --> Router Class Initialized
INFO - 2024-09-20 10:07:30 --> Output Class Initialized
INFO - 2024-09-20 10:07:30 --> Security Class Initialized
DEBUG - 2024-09-20 10:07:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-20 10:07:30 --> Input Class Initialized
INFO - 2024-09-20 10:07:30 --> Language Class Initialized
INFO - 2024-09-20 10:07:30 --> Language Class Initialized
INFO - 2024-09-20 10:07:30 --> Config Class Initialized
INFO - 2024-09-20 10:07:30 --> Loader Class Initialized
INFO - 2024-09-20 10:07:30 --> Helper loaded: url_helper
INFO - 2024-09-20 10:07:30 --> Helper loaded: file_helper
INFO - 2024-09-20 10:07:30 --> Helper loaded: form_helper
INFO - 2024-09-20 10:07:30 --> Helper loaded: my_helper
INFO - 2024-09-20 10:07:30 --> Database Driver Class Initialized
INFO - 2024-09-20 10:07:30 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-20 10:07:30 --> Controller Class Initialized
DEBUG - 2024-09-20 10:07:30 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/view_mapel/views/v_view_mapel.php
DEBUG - 2024-09-20 10:07:30 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-09-20 10:07:30 --> Final output sent to browser
DEBUG - 2024-09-20 10:07:30 --> Total execution time: 0.0378
INFO - 2024-09-20 10:07:32 --> Config Class Initialized
INFO - 2024-09-20 10:07:32 --> Hooks Class Initialized
DEBUG - 2024-09-20 10:07:32 --> UTF-8 Support Enabled
INFO - 2024-09-20 10:07:32 --> Utf8 Class Initialized
INFO - 2024-09-20 10:07:32 --> URI Class Initialized
INFO - 2024-09-20 10:07:32 --> Router Class Initialized
INFO - 2024-09-20 10:07:32 --> Output Class Initialized
INFO - 2024-09-20 10:07:32 --> Security Class Initialized
DEBUG - 2024-09-20 10:07:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-20 10:07:32 --> Input Class Initialized
INFO - 2024-09-20 10:07:32 --> Language Class Initialized
INFO - 2024-09-20 10:07:32 --> Language Class Initialized
INFO - 2024-09-20 10:07:32 --> Config Class Initialized
INFO - 2024-09-20 10:07:32 --> Loader Class Initialized
INFO - 2024-09-20 10:07:32 --> Helper loaded: url_helper
INFO - 2024-09-20 10:07:32 --> Helper loaded: file_helper
INFO - 2024-09-20 10:07:32 --> Helper loaded: form_helper
INFO - 2024-09-20 10:07:32 --> Helper loaded: my_helper
INFO - 2024-09-20 10:07:32 --> Database Driver Class Initialized
INFO - 2024-09-20 10:07:32 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-20 10:07:32 --> Controller Class Initialized
DEBUG - 2024-09-20 10:07:32 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_catatan_guru/views/list.php
DEBUG - 2024-09-20 10:07:32 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-09-20 10:07:32 --> Final output sent to browser
DEBUG - 2024-09-20 10:07:32 --> Total execution time: 0.1256
INFO - 2024-09-20 10:08:04 --> Config Class Initialized
INFO - 2024-09-20 10:08:04 --> Hooks Class Initialized
DEBUG - 2024-09-20 10:08:04 --> UTF-8 Support Enabled
INFO - 2024-09-20 10:08:04 --> Utf8 Class Initialized
INFO - 2024-09-20 10:08:04 --> URI Class Initialized
INFO - 2024-09-20 10:08:04 --> Router Class Initialized
INFO - 2024-09-20 10:08:04 --> Output Class Initialized
INFO - 2024-09-20 10:08:04 --> Security Class Initialized
DEBUG - 2024-09-20 10:08:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-20 10:08:04 --> Input Class Initialized
INFO - 2024-09-20 10:08:04 --> Language Class Initialized
INFO - 2024-09-20 10:08:04 --> Language Class Initialized
INFO - 2024-09-20 10:08:04 --> Config Class Initialized
INFO - 2024-09-20 10:08:04 --> Loader Class Initialized
INFO - 2024-09-20 10:08:04 --> Helper loaded: url_helper
INFO - 2024-09-20 10:08:04 --> Helper loaded: file_helper
INFO - 2024-09-20 10:08:04 --> Helper loaded: form_helper
INFO - 2024-09-20 10:08:04 --> Helper loaded: my_helper
INFO - 2024-09-20 10:08:04 --> Database Driver Class Initialized
INFO - 2024-09-20 10:08:04 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-20 10:08:04 --> Controller Class Initialized
INFO - 2024-09-20 10:08:04 --> Final output sent to browser
DEBUG - 2024-09-20 10:08:04 --> Total execution time: 0.0375
INFO - 2024-09-20 10:12:00 --> Config Class Initialized
INFO - 2024-09-20 10:12:00 --> Hooks Class Initialized
DEBUG - 2024-09-20 10:12:00 --> UTF-8 Support Enabled
INFO - 2024-09-20 10:12:00 --> Utf8 Class Initialized
INFO - 2024-09-20 10:12:00 --> URI Class Initialized
INFO - 2024-09-20 10:12:00 --> Router Class Initialized
INFO - 2024-09-20 10:12:00 --> Output Class Initialized
INFO - 2024-09-20 10:12:00 --> Security Class Initialized
DEBUG - 2024-09-20 10:12:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-20 10:12:00 --> Input Class Initialized
INFO - 2024-09-20 10:12:00 --> Language Class Initialized
INFO - 2024-09-20 10:12:00 --> Language Class Initialized
INFO - 2024-09-20 10:12:00 --> Config Class Initialized
INFO - 2024-09-20 10:12:00 --> Loader Class Initialized
INFO - 2024-09-20 10:12:00 --> Helper loaded: url_helper
INFO - 2024-09-20 10:12:00 --> Helper loaded: file_helper
INFO - 2024-09-20 10:12:00 --> Helper loaded: form_helper
INFO - 2024-09-20 10:12:00 --> Helper loaded: my_helper
INFO - 2024-09-20 10:12:00 --> Database Driver Class Initialized
INFO - 2024-09-20 10:12:00 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-20 10:12:00 --> Controller Class Initialized
ERROR - 2024-09-20 10:12:00 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near 's comprehension skills. You are beginning to understand the main ideas and detai' at line 1 - Invalid query: INSERT INTO t_nilai_cat (tasm,jenis,id_guru_mapel, id_mapel_kd, id_siswa, nilai, nilai_mid) VALUES ('20241', 'c', '51', '10', '73', '-', 'There is a noticeable betterment in the student's comprehension skills. You are beginning to understand the main ideas and details in reading assignments and are making efforts to grasp vocabulary and context within texts. Furthermore, in terms of writing, assignments are becoming more organized and structured, with fewer grammatical errors, although some persist. You are demonstrating increased clarity and coherence in conveying ideas in your writing. Regarding participation, you are engaging more frequently in classroom discussions, contributing occasionally to group activities, and taking initial steps to overcome shyness in verbal communication.')
INFO - 2024-09-20 10:12:00 --> Language file loaded: language/english/db_lang.php
INFO - 2024-09-20 10:12:51 --> Config Class Initialized
INFO - 2024-09-20 10:12:51 --> Hooks Class Initialized
DEBUG - 2024-09-20 10:12:51 --> UTF-8 Support Enabled
INFO - 2024-09-20 10:12:51 --> Utf8 Class Initialized
INFO - 2024-09-20 10:12:51 --> URI Class Initialized
INFO - 2024-09-20 10:12:51 --> Router Class Initialized
INFO - 2024-09-20 10:12:51 --> Output Class Initialized
INFO - 2024-09-20 10:12:51 --> Security Class Initialized
DEBUG - 2024-09-20 10:12:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-20 10:12:51 --> Input Class Initialized
INFO - 2024-09-20 10:12:51 --> Language Class Initialized
INFO - 2024-09-20 10:12:51 --> Language Class Initialized
INFO - 2024-09-20 10:12:51 --> Config Class Initialized
INFO - 2024-09-20 10:12:51 --> Loader Class Initialized
INFO - 2024-09-20 10:12:51 --> Helper loaded: url_helper
INFO - 2024-09-20 10:12:51 --> Helper loaded: file_helper
INFO - 2024-09-20 10:12:51 --> Helper loaded: form_helper
INFO - 2024-09-20 10:12:51 --> Helper loaded: my_helper
INFO - 2024-09-20 10:12:51 --> Database Driver Class Initialized
INFO - 2024-09-20 10:12:51 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-20 10:12:51 --> Controller Class Initialized
ERROR - 2024-09-20 10:12:51 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near 's comprehension skills. You are beginning to understand the main ideas and detai' at line 1 - Invalid query: INSERT INTO t_nilai_cat (tasm,jenis,id_guru_mapel, id_mapel_kd, id_siswa, nilai, nilai_mid) VALUES ('20241', 'c', '51', '10', '73', '-', 'There is a noticeable betterment in the student's comprehension skills. You are beginning to understand the main ideas and details in reading assignments and are making efforts to grasp vocabulary and context within texts. Furthermore, in terms of writing, assignments are becoming more organized and structured, with fewer grammatical errors, although some persist. You are demonstrating increased clarity and coherence in conveying ideas in your writing. Regarding participation, you are engaging more frequently in classroom discussions, contributing occasionally to group activities, and taking initial steps to overcome shyness in verbal communication.')
INFO - 2024-09-20 10:12:51 --> Language file loaded: language/english/db_lang.php
INFO - 2024-09-20 10:12:57 --> Config Class Initialized
INFO - 2024-09-20 10:12:57 --> Hooks Class Initialized
DEBUG - 2024-09-20 10:12:57 --> UTF-8 Support Enabled
INFO - 2024-09-20 10:12:57 --> Utf8 Class Initialized
INFO - 2024-09-20 10:12:57 --> URI Class Initialized
INFO - 2024-09-20 10:12:57 --> Router Class Initialized
INFO - 2024-09-20 10:12:57 --> Output Class Initialized
INFO - 2024-09-20 10:12:57 --> Security Class Initialized
DEBUG - 2024-09-20 10:12:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-20 10:12:57 --> Input Class Initialized
INFO - 2024-09-20 10:12:57 --> Language Class Initialized
INFO - 2024-09-20 10:12:57 --> Language Class Initialized
INFO - 2024-09-20 10:12:57 --> Config Class Initialized
INFO - 2024-09-20 10:12:57 --> Loader Class Initialized
INFO - 2024-09-20 10:12:57 --> Helper loaded: url_helper
INFO - 2024-09-20 10:12:57 --> Helper loaded: file_helper
INFO - 2024-09-20 10:12:57 --> Helper loaded: form_helper
INFO - 2024-09-20 10:12:57 --> Helper loaded: my_helper
INFO - 2024-09-20 10:12:57 --> Database Driver Class Initialized
INFO - 2024-09-20 10:12:57 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-20 10:12:57 --> Controller Class Initialized
ERROR - 2024-09-20 10:12:57 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near 's comprehension skills. You are beginning to understand the main ideas and detai' at line 1 - Invalid query: INSERT INTO t_nilai_cat (tasm,jenis,id_guru_mapel, id_mapel_kd, id_siswa, nilai, nilai_mid) VALUES ('20241', 'c', '51', '10', '73', '-', 'There is a noticeable betterment in the student's comprehension skills. You are beginning to understand the main ideas and details in reading assignments and are making efforts to grasp vocabulary and context within texts. Furthermore, in terms of writing, assignments are becoming more organized and structured, with fewer grammatical errors, although some persist. You are demonstrating increased clarity and coherence in conveying ideas in your writing. Regarding participation, you are engaging more frequently in classroom discussions, contributing occasionally to group activities, and taking initial steps to overcome shyness in verbal communication.')
INFO - 2024-09-20 10:12:57 --> Language file loaded: language/english/db_lang.php
INFO - 2024-09-20 10:13:05 --> Config Class Initialized
INFO - 2024-09-20 10:13:05 --> Hooks Class Initialized
DEBUG - 2024-09-20 10:13:05 --> UTF-8 Support Enabled
INFO - 2024-09-20 10:13:05 --> Utf8 Class Initialized
INFO - 2024-09-20 10:13:05 --> URI Class Initialized
INFO - 2024-09-20 10:13:05 --> Router Class Initialized
INFO - 2024-09-20 10:13:05 --> Output Class Initialized
INFO - 2024-09-20 10:13:05 --> Security Class Initialized
DEBUG - 2024-09-20 10:13:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-20 10:13:05 --> Input Class Initialized
INFO - 2024-09-20 10:13:05 --> Language Class Initialized
INFO - 2024-09-20 10:13:05 --> Language Class Initialized
INFO - 2024-09-20 10:13:05 --> Config Class Initialized
INFO - 2024-09-20 10:13:05 --> Loader Class Initialized
INFO - 2024-09-20 10:13:05 --> Helper loaded: url_helper
INFO - 2024-09-20 10:13:05 --> Helper loaded: file_helper
INFO - 2024-09-20 10:13:05 --> Helper loaded: form_helper
INFO - 2024-09-20 10:13:05 --> Helper loaded: my_helper
INFO - 2024-09-20 10:13:05 --> Database Driver Class Initialized
INFO - 2024-09-20 10:13:05 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-20 10:13:05 --> Controller Class Initialized
ERROR - 2024-09-20 10:13:05 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near 's comprehension skills. You are beginning to understand the main ideas and detai' at line 1 - Invalid query: INSERT INTO t_nilai_cat (tasm,jenis,id_guru_mapel, id_mapel_kd, id_siswa, nilai, nilai_mid) VALUES ('20241', 'c', '51', '10', '73', '-', 'There is a noticeable betterment in the student's comprehension skills. You are beginning to understand the main ideas and details in reading assignments and are making efforts to grasp vocabulary and context within texts. Furthermore, in terms of writing, assignments are becoming more organized and structured, with fewer grammatical errors, although some persist. You are demonstrating increased clarity and coherence in conveying ideas in your writing. Regarding participation, you are engaging more frequently in classroom discussions, contributing occasionally to group activities, and taking initial steps to overcome shyness in verbal communication.')
INFO - 2024-09-20 10:13:05 --> Language file loaded: language/english/db_lang.php
INFO - 2024-09-20 10:13:07 --> Config Class Initialized
INFO - 2024-09-20 10:13:07 --> Hooks Class Initialized
DEBUG - 2024-09-20 10:13:07 --> UTF-8 Support Enabled
INFO - 2024-09-20 10:13:07 --> Utf8 Class Initialized
INFO - 2024-09-20 10:13:07 --> URI Class Initialized
INFO - 2024-09-20 10:13:07 --> Router Class Initialized
INFO - 2024-09-20 10:13:07 --> Output Class Initialized
INFO - 2024-09-20 10:13:07 --> Security Class Initialized
DEBUG - 2024-09-20 10:13:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-20 10:13:07 --> Input Class Initialized
INFO - 2024-09-20 10:13:07 --> Language Class Initialized
INFO - 2024-09-20 10:13:07 --> Language Class Initialized
INFO - 2024-09-20 10:13:07 --> Config Class Initialized
INFO - 2024-09-20 10:13:07 --> Loader Class Initialized
INFO - 2024-09-20 10:13:07 --> Helper loaded: url_helper
INFO - 2024-09-20 10:13:07 --> Helper loaded: file_helper
INFO - 2024-09-20 10:13:07 --> Helper loaded: form_helper
INFO - 2024-09-20 10:13:07 --> Helper loaded: my_helper
INFO - 2024-09-20 10:13:07 --> Database Driver Class Initialized
INFO - 2024-09-20 10:13:07 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-20 10:13:07 --> Controller Class Initialized
DEBUG - 2024-09-20 10:13:07 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_catatan_guru/views/list.php
DEBUG - 2024-09-20 10:13:07 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-09-20 10:13:07 --> Final output sent to browser
DEBUG - 2024-09-20 10:13:07 --> Total execution time: 0.0351
INFO - 2024-09-20 10:13:11 --> Config Class Initialized
INFO - 2024-09-20 10:13:11 --> Hooks Class Initialized
DEBUG - 2024-09-20 10:13:11 --> UTF-8 Support Enabled
INFO - 2024-09-20 10:13:11 --> Utf8 Class Initialized
INFO - 2024-09-20 10:13:11 --> URI Class Initialized
INFO - 2024-09-20 10:13:11 --> Router Class Initialized
INFO - 2024-09-20 10:13:11 --> Output Class Initialized
INFO - 2024-09-20 10:13:11 --> Security Class Initialized
DEBUG - 2024-09-20 10:13:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-20 10:13:11 --> Input Class Initialized
INFO - 2024-09-20 10:13:11 --> Language Class Initialized
INFO - 2024-09-20 10:13:11 --> Language Class Initialized
INFO - 2024-09-20 10:13:11 --> Config Class Initialized
INFO - 2024-09-20 10:13:11 --> Loader Class Initialized
INFO - 2024-09-20 10:13:11 --> Helper loaded: url_helper
INFO - 2024-09-20 10:13:11 --> Helper loaded: file_helper
INFO - 2024-09-20 10:13:11 --> Helper loaded: form_helper
INFO - 2024-09-20 10:13:11 --> Helper loaded: my_helper
INFO - 2024-09-20 10:13:11 --> Database Driver Class Initialized
INFO - 2024-09-20 10:13:11 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-20 10:13:11 --> Controller Class Initialized
INFO - 2024-09-20 10:13:11 --> Final output sent to browser
DEBUG - 2024-09-20 10:13:11 --> Total execution time: 0.0369
INFO - 2024-09-20 10:44:26 --> Config Class Initialized
INFO - 2024-09-20 10:44:26 --> Hooks Class Initialized
DEBUG - 2024-09-20 10:44:26 --> UTF-8 Support Enabled
INFO - 2024-09-20 10:44:26 --> Utf8 Class Initialized
INFO - 2024-09-20 10:44:26 --> URI Class Initialized
INFO - 2024-09-20 10:44:26 --> Router Class Initialized
INFO - 2024-09-20 10:44:26 --> Output Class Initialized
INFO - 2024-09-20 10:44:26 --> Security Class Initialized
DEBUG - 2024-09-20 10:44:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-20 10:44:26 --> Input Class Initialized
INFO - 2024-09-20 10:44:26 --> Language Class Initialized
INFO - 2024-09-20 10:44:26 --> Language Class Initialized
INFO - 2024-09-20 10:44:26 --> Config Class Initialized
INFO - 2024-09-20 10:44:26 --> Loader Class Initialized
INFO - 2024-09-20 10:44:26 --> Helper loaded: url_helper
INFO - 2024-09-20 10:44:26 --> Helper loaded: file_helper
INFO - 2024-09-20 10:44:26 --> Helper loaded: form_helper
INFO - 2024-09-20 10:44:26 --> Helper loaded: my_helper
INFO - 2024-09-20 10:44:26 --> Database Driver Class Initialized
INFO - 2024-09-20 10:44:26 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-20 10:44:26 --> Controller Class Initialized
DEBUG - 2024-09-20 10:44:26 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/login/views/login.php
DEBUG - 2024-09-20 10:44:26 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-09-20 10:44:26 --> Final output sent to browser
DEBUG - 2024-09-20 10:44:26 --> Total execution time: 0.0465
INFO - 2024-09-20 10:44:26 --> Config Class Initialized
INFO - 2024-09-20 10:44:26 --> Hooks Class Initialized
DEBUG - 2024-09-20 10:44:26 --> UTF-8 Support Enabled
INFO - 2024-09-20 10:44:26 --> Utf8 Class Initialized
INFO - 2024-09-20 10:44:26 --> URI Class Initialized
INFO - 2024-09-20 10:44:26 --> Router Class Initialized
INFO - 2024-09-20 10:44:26 --> Output Class Initialized
INFO - 2024-09-20 10:44:26 --> Security Class Initialized
DEBUG - 2024-09-20 10:44:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-20 10:44:26 --> Input Class Initialized
INFO - 2024-09-20 10:44:26 --> Language Class Initialized
INFO - 2024-09-20 10:44:26 --> Language Class Initialized
INFO - 2024-09-20 10:44:26 --> Config Class Initialized
INFO - 2024-09-20 10:44:26 --> Loader Class Initialized
INFO - 2024-09-20 10:44:26 --> Helper loaded: url_helper
INFO - 2024-09-20 10:44:26 --> Helper loaded: file_helper
INFO - 2024-09-20 10:44:26 --> Helper loaded: form_helper
INFO - 2024-09-20 10:44:26 --> Helper loaded: my_helper
INFO - 2024-09-20 10:44:26 --> Database Driver Class Initialized
INFO - 2024-09-20 10:44:26 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-20 10:44:26 --> Controller Class Initialized
DEBUG - 2024-09-20 10:44:26 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/login/views/login.php
DEBUG - 2024-09-20 10:44:26 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-09-20 10:44:26 --> Final output sent to browser
DEBUG - 2024-09-20 10:44:26 --> Total execution time: 0.0351
INFO - 2024-09-20 10:44:30 --> Config Class Initialized
INFO - 2024-09-20 10:44:30 --> Hooks Class Initialized
DEBUG - 2024-09-20 10:44:30 --> UTF-8 Support Enabled
INFO - 2024-09-20 10:44:30 --> Utf8 Class Initialized
INFO - 2024-09-20 10:44:30 --> URI Class Initialized
INFO - 2024-09-20 10:44:30 --> Router Class Initialized
INFO - 2024-09-20 10:44:30 --> Output Class Initialized
INFO - 2024-09-20 10:44:30 --> Security Class Initialized
DEBUG - 2024-09-20 10:44:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-20 10:44:30 --> Input Class Initialized
INFO - 2024-09-20 10:44:30 --> Language Class Initialized
INFO - 2024-09-20 10:44:30 --> Language Class Initialized
INFO - 2024-09-20 10:44:30 --> Config Class Initialized
INFO - 2024-09-20 10:44:30 --> Loader Class Initialized
INFO - 2024-09-20 10:44:30 --> Helper loaded: url_helper
INFO - 2024-09-20 10:44:30 --> Helper loaded: file_helper
INFO - 2024-09-20 10:44:30 --> Helper loaded: form_helper
INFO - 2024-09-20 10:44:30 --> Helper loaded: my_helper
INFO - 2024-09-20 10:44:30 --> Database Driver Class Initialized
INFO - 2024-09-20 10:44:30 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-20 10:44:30 --> Controller Class Initialized
INFO - 2024-09-20 10:44:30 --> Helper loaded: cookie_helper
INFO - 2024-09-20 10:44:30 --> Final output sent to browser
DEBUG - 2024-09-20 10:44:30 --> Total execution time: 0.0426
INFO - 2024-09-20 10:44:30 --> Config Class Initialized
INFO - 2024-09-20 10:44:30 --> Hooks Class Initialized
DEBUG - 2024-09-20 10:44:30 --> UTF-8 Support Enabled
INFO - 2024-09-20 10:44:30 --> Utf8 Class Initialized
INFO - 2024-09-20 10:44:30 --> URI Class Initialized
INFO - 2024-09-20 10:44:30 --> Router Class Initialized
INFO - 2024-09-20 10:44:30 --> Output Class Initialized
INFO - 2024-09-20 10:44:30 --> Security Class Initialized
DEBUG - 2024-09-20 10:44:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-20 10:44:30 --> Input Class Initialized
INFO - 2024-09-20 10:44:30 --> Language Class Initialized
INFO - 2024-09-20 10:44:30 --> Language Class Initialized
INFO - 2024-09-20 10:44:30 --> Config Class Initialized
INFO - 2024-09-20 10:44:30 --> Loader Class Initialized
INFO - 2024-09-20 10:44:30 --> Helper loaded: url_helper
INFO - 2024-09-20 10:44:30 --> Helper loaded: file_helper
INFO - 2024-09-20 10:44:30 --> Helper loaded: form_helper
INFO - 2024-09-20 10:44:30 --> Helper loaded: my_helper
INFO - 2024-09-20 10:44:30 --> Database Driver Class Initialized
INFO - 2024-09-20 10:44:30 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-20 10:44:30 --> Controller Class Initialized
DEBUG - 2024-09-20 10:44:30 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/home/views/v_home_guru.php
DEBUG - 2024-09-20 10:44:30 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-09-20 10:44:30 --> Final output sent to browser
DEBUG - 2024-09-20 10:44:30 --> Total execution time: 0.0333
INFO - 2024-09-20 10:44:32 --> Config Class Initialized
INFO - 2024-09-20 10:44:32 --> Hooks Class Initialized
DEBUG - 2024-09-20 10:44:32 --> UTF-8 Support Enabled
INFO - 2024-09-20 10:44:32 --> Utf8 Class Initialized
INFO - 2024-09-20 10:44:32 --> URI Class Initialized
INFO - 2024-09-20 10:44:32 --> Router Class Initialized
INFO - 2024-09-20 10:44:32 --> Output Class Initialized
INFO - 2024-09-20 10:44:32 --> Security Class Initialized
DEBUG - 2024-09-20 10:44:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-20 10:44:32 --> Input Class Initialized
INFO - 2024-09-20 10:44:32 --> Language Class Initialized
INFO - 2024-09-20 10:44:32 --> Language Class Initialized
INFO - 2024-09-20 10:44:32 --> Config Class Initialized
INFO - 2024-09-20 10:44:32 --> Loader Class Initialized
INFO - 2024-09-20 10:44:32 --> Helper loaded: url_helper
INFO - 2024-09-20 10:44:32 --> Helper loaded: file_helper
INFO - 2024-09-20 10:44:32 --> Helper loaded: form_helper
INFO - 2024-09-20 10:44:32 --> Helper loaded: my_helper
INFO - 2024-09-20 10:44:32 --> Database Driver Class Initialized
INFO - 2024-09-20 10:44:32 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-20 10:44:32 --> Controller Class Initialized
DEBUG - 2024-09-20 10:44:32 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/view_mapel/views/v_view_mapel.php
DEBUG - 2024-09-20 10:44:32 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-09-20 10:44:32 --> Final output sent to browser
DEBUG - 2024-09-20 10:44:32 --> Total execution time: 0.0365
INFO - 2024-09-20 10:44:34 --> Config Class Initialized
INFO - 2024-09-20 10:44:34 --> Hooks Class Initialized
DEBUG - 2024-09-20 10:44:34 --> UTF-8 Support Enabled
INFO - 2024-09-20 10:44:34 --> Utf8 Class Initialized
INFO - 2024-09-20 10:44:34 --> URI Class Initialized
INFO - 2024-09-20 10:44:34 --> Router Class Initialized
INFO - 2024-09-20 10:44:34 --> Output Class Initialized
INFO - 2024-09-20 10:44:34 --> Security Class Initialized
DEBUG - 2024-09-20 10:44:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-20 10:44:34 --> Input Class Initialized
INFO - 2024-09-20 10:44:34 --> Language Class Initialized
INFO - 2024-09-20 10:44:34 --> Language Class Initialized
INFO - 2024-09-20 10:44:34 --> Config Class Initialized
INFO - 2024-09-20 10:44:34 --> Loader Class Initialized
INFO - 2024-09-20 10:44:34 --> Helper loaded: url_helper
INFO - 2024-09-20 10:44:34 --> Helper loaded: file_helper
INFO - 2024-09-20 10:44:34 --> Helper loaded: form_helper
INFO - 2024-09-20 10:44:34 --> Helper loaded: my_helper
INFO - 2024-09-20 10:44:34 --> Database Driver Class Initialized
INFO - 2024-09-20 10:44:34 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-20 10:44:34 --> Controller Class Initialized
DEBUG - 2024-09-20 10:44:34 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/views/list.php
DEBUG - 2024-09-20 10:44:34 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-09-20 10:44:34 --> Final output sent to browser
DEBUG - 2024-09-20 10:44:34 --> Total execution time: 0.0392
INFO - 2024-09-20 10:44:34 --> Config Class Initialized
INFO - 2024-09-20 10:44:34 --> Hooks Class Initialized
DEBUG - 2024-09-20 10:44:34 --> UTF-8 Support Enabled
INFO - 2024-09-20 10:44:34 --> Utf8 Class Initialized
INFO - 2024-09-20 10:44:34 --> URI Class Initialized
INFO - 2024-09-20 10:44:34 --> Router Class Initialized
INFO - 2024-09-20 10:44:34 --> Output Class Initialized
INFO - 2024-09-20 10:44:34 --> Security Class Initialized
DEBUG - 2024-09-20 10:44:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-20 10:44:34 --> Input Class Initialized
INFO - 2024-09-20 10:44:34 --> Language Class Initialized
INFO - 2024-09-20 10:44:34 --> Language Class Initialized
INFO - 2024-09-20 10:44:34 --> Config Class Initialized
INFO - 2024-09-20 10:44:34 --> Loader Class Initialized
INFO - 2024-09-20 10:44:34 --> Helper loaded: url_helper
INFO - 2024-09-20 10:44:34 --> Helper loaded: file_helper
INFO - 2024-09-20 10:44:34 --> Helper loaded: form_helper
INFO - 2024-09-20 10:44:34 --> Helper loaded: my_helper
INFO - 2024-09-20 10:44:34 --> Database Driver Class Initialized
INFO - 2024-09-20 10:44:34 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-20 10:44:34 --> Controller Class Initialized
INFO - 2024-09-20 10:44:40 --> Config Class Initialized
INFO - 2024-09-20 10:44:40 --> Hooks Class Initialized
DEBUG - 2024-09-20 10:44:40 --> UTF-8 Support Enabled
INFO - 2024-09-20 10:44:40 --> Utf8 Class Initialized
INFO - 2024-09-20 10:44:40 --> URI Class Initialized
INFO - 2024-09-20 10:44:40 --> Router Class Initialized
INFO - 2024-09-20 10:44:40 --> Output Class Initialized
INFO - 2024-09-20 10:44:40 --> Security Class Initialized
DEBUG - 2024-09-20 10:44:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-20 10:44:40 --> Input Class Initialized
INFO - 2024-09-20 10:44:40 --> Language Class Initialized
INFO - 2024-09-20 10:44:40 --> Language Class Initialized
INFO - 2024-09-20 10:44:40 --> Config Class Initialized
INFO - 2024-09-20 10:44:40 --> Loader Class Initialized
INFO - 2024-09-20 10:44:40 --> Helper loaded: url_helper
INFO - 2024-09-20 10:44:40 --> Helper loaded: file_helper
INFO - 2024-09-20 10:44:40 --> Helper loaded: form_helper
INFO - 2024-09-20 10:44:40 --> Helper loaded: my_helper
INFO - 2024-09-20 10:44:40 --> Database Driver Class Initialized
INFO - 2024-09-20 10:44:40 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-20 10:44:40 --> Controller Class Initialized
DEBUG - 2024-09-20 10:44:40 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/view_mapel/views/v_view_mapel.php
DEBUG - 2024-09-20 10:44:40 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-09-20 10:44:40 --> Final output sent to browser
DEBUG - 2024-09-20 10:44:40 --> Total execution time: 0.0332
INFO - 2024-09-20 10:44:42 --> Config Class Initialized
INFO - 2024-09-20 10:44:42 --> Hooks Class Initialized
DEBUG - 2024-09-20 10:44:42 --> UTF-8 Support Enabled
INFO - 2024-09-20 10:44:42 --> Utf8 Class Initialized
INFO - 2024-09-20 10:44:42 --> URI Class Initialized
INFO - 2024-09-20 10:44:42 --> Router Class Initialized
INFO - 2024-09-20 10:44:42 --> Output Class Initialized
INFO - 2024-09-20 10:44:42 --> Security Class Initialized
DEBUG - 2024-09-20 10:44:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-20 10:44:42 --> Input Class Initialized
INFO - 2024-09-20 10:44:42 --> Language Class Initialized
INFO - 2024-09-20 10:44:42 --> Language Class Initialized
INFO - 2024-09-20 10:44:42 --> Config Class Initialized
INFO - 2024-09-20 10:44:42 --> Loader Class Initialized
INFO - 2024-09-20 10:44:42 --> Helper loaded: url_helper
INFO - 2024-09-20 10:44:42 --> Helper loaded: file_helper
INFO - 2024-09-20 10:44:42 --> Helper loaded: form_helper
INFO - 2024-09-20 10:44:42 --> Helper loaded: my_helper
INFO - 2024-09-20 10:44:42 --> Database Driver Class Initialized
INFO - 2024-09-20 10:44:42 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-20 10:44:42 --> Controller Class Initialized
DEBUG - 2024-09-20 10:44:42 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_catatan_guru/views/list.php
DEBUG - 2024-09-20 10:44:42 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-09-20 10:44:42 --> Final output sent to browser
DEBUG - 2024-09-20 10:44:42 --> Total execution time: 0.0339
INFO - 2024-09-20 10:44:44 --> Config Class Initialized
INFO - 2024-09-20 10:44:44 --> Hooks Class Initialized
DEBUG - 2024-09-20 10:44:44 --> UTF-8 Support Enabled
INFO - 2024-09-20 10:44:44 --> Utf8 Class Initialized
INFO - 2024-09-20 10:44:44 --> URI Class Initialized
INFO - 2024-09-20 10:44:44 --> Router Class Initialized
INFO - 2024-09-20 10:44:44 --> Output Class Initialized
INFO - 2024-09-20 10:44:44 --> Security Class Initialized
DEBUG - 2024-09-20 10:44:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-20 10:44:44 --> Input Class Initialized
INFO - 2024-09-20 10:44:44 --> Language Class Initialized
INFO - 2024-09-20 10:44:44 --> Language Class Initialized
INFO - 2024-09-20 10:44:44 --> Config Class Initialized
INFO - 2024-09-20 10:44:44 --> Loader Class Initialized
INFO - 2024-09-20 10:44:44 --> Helper loaded: url_helper
INFO - 2024-09-20 10:44:44 --> Helper loaded: file_helper
INFO - 2024-09-20 10:44:44 --> Helper loaded: form_helper
INFO - 2024-09-20 10:44:44 --> Helper loaded: my_helper
INFO - 2024-09-20 10:44:44 --> Database Driver Class Initialized
INFO - 2024-09-20 10:44:44 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-20 10:44:44 --> Controller Class Initialized
INFO - 2024-09-20 10:44:44 --> Final output sent to browser
DEBUG - 2024-09-20 10:44:44 --> Total execution time: 0.0310
INFO - 2024-09-20 10:45:27 --> Config Class Initialized
INFO - 2024-09-20 10:45:27 --> Hooks Class Initialized
DEBUG - 2024-09-20 10:45:27 --> UTF-8 Support Enabled
INFO - 2024-09-20 10:45:27 --> Utf8 Class Initialized
INFO - 2024-09-20 10:45:27 --> URI Class Initialized
INFO - 2024-09-20 10:45:27 --> Router Class Initialized
INFO - 2024-09-20 10:45:27 --> Output Class Initialized
INFO - 2024-09-20 10:45:27 --> Security Class Initialized
DEBUG - 2024-09-20 10:45:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-20 10:45:27 --> Input Class Initialized
INFO - 2024-09-20 10:45:27 --> Language Class Initialized
INFO - 2024-09-20 10:45:27 --> Language Class Initialized
INFO - 2024-09-20 10:45:27 --> Config Class Initialized
INFO - 2024-09-20 10:45:27 --> Loader Class Initialized
INFO - 2024-09-20 10:45:27 --> Helper loaded: url_helper
INFO - 2024-09-20 10:45:27 --> Helper loaded: file_helper
INFO - 2024-09-20 10:45:27 --> Helper loaded: form_helper
INFO - 2024-09-20 10:45:27 --> Helper loaded: my_helper
INFO - 2024-09-20 10:45:27 --> Database Driver Class Initialized
INFO - 2024-09-20 10:45:27 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-20 10:45:27 --> Controller Class Initialized
INFO - 2024-09-20 10:45:27 --> Final output sent to browser
DEBUG - 2024-09-20 10:45:27 --> Total execution time: 0.2207
INFO - 2024-09-20 10:45:31 --> Config Class Initialized
INFO - 2024-09-20 10:45:31 --> Hooks Class Initialized
DEBUG - 2024-09-20 10:45:31 --> UTF-8 Support Enabled
INFO - 2024-09-20 10:45:31 --> Utf8 Class Initialized
INFO - 2024-09-20 10:45:31 --> URI Class Initialized
INFO - 2024-09-20 10:45:31 --> Router Class Initialized
INFO - 2024-09-20 10:45:31 --> Output Class Initialized
INFO - 2024-09-20 10:45:31 --> Security Class Initialized
DEBUG - 2024-09-20 10:45:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-20 10:45:31 --> Input Class Initialized
INFO - 2024-09-20 10:45:31 --> Language Class Initialized
INFO - 2024-09-20 10:45:31 --> Language Class Initialized
INFO - 2024-09-20 10:45:31 --> Config Class Initialized
INFO - 2024-09-20 10:45:31 --> Loader Class Initialized
INFO - 2024-09-20 10:45:31 --> Helper loaded: url_helper
INFO - 2024-09-20 10:45:31 --> Helper loaded: file_helper
INFO - 2024-09-20 10:45:31 --> Helper loaded: form_helper
INFO - 2024-09-20 10:45:31 --> Helper loaded: my_helper
INFO - 2024-09-20 10:45:31 --> Database Driver Class Initialized
INFO - 2024-09-20 10:45:31 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-20 10:45:31 --> Controller Class Initialized
DEBUG - 2024-09-20 10:45:31 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/view_mapel/views/v_view_mapel.php
DEBUG - 2024-09-20 10:45:31 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-09-20 10:45:31 --> Final output sent to browser
DEBUG - 2024-09-20 10:45:31 --> Total execution time: 0.0451
INFO - 2024-09-20 10:45:32 --> Config Class Initialized
INFO - 2024-09-20 10:45:32 --> Hooks Class Initialized
DEBUG - 2024-09-20 10:45:33 --> UTF-8 Support Enabled
INFO - 2024-09-20 10:45:33 --> Utf8 Class Initialized
INFO - 2024-09-20 10:45:33 --> URI Class Initialized
INFO - 2024-09-20 10:45:33 --> Router Class Initialized
INFO - 2024-09-20 10:45:33 --> Output Class Initialized
INFO - 2024-09-20 10:45:33 --> Security Class Initialized
DEBUG - 2024-09-20 10:45:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-20 10:45:33 --> Input Class Initialized
INFO - 2024-09-20 10:45:33 --> Language Class Initialized
INFO - 2024-09-20 10:45:33 --> Language Class Initialized
INFO - 2024-09-20 10:45:33 --> Config Class Initialized
INFO - 2024-09-20 10:45:33 --> Loader Class Initialized
INFO - 2024-09-20 10:45:33 --> Helper loaded: url_helper
INFO - 2024-09-20 10:45:33 --> Helper loaded: file_helper
INFO - 2024-09-20 10:45:33 --> Helper loaded: form_helper
INFO - 2024-09-20 10:45:33 --> Helper loaded: my_helper
INFO - 2024-09-20 10:45:33 --> Database Driver Class Initialized
INFO - 2024-09-20 10:45:33 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-20 10:45:33 --> Controller Class Initialized
DEBUG - 2024-09-20 10:45:33 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_catatan_guru/views/list.php
DEBUG - 2024-09-20 10:45:33 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-09-20 10:45:33 --> Final output sent to browser
DEBUG - 2024-09-20 10:45:33 --> Total execution time: 0.0379
INFO - 2024-09-20 10:45:35 --> Config Class Initialized
INFO - 2024-09-20 10:45:35 --> Hooks Class Initialized
DEBUG - 2024-09-20 10:45:35 --> UTF-8 Support Enabled
INFO - 2024-09-20 10:45:35 --> Utf8 Class Initialized
INFO - 2024-09-20 10:45:35 --> URI Class Initialized
INFO - 2024-09-20 10:45:35 --> Router Class Initialized
INFO - 2024-09-20 10:45:35 --> Output Class Initialized
INFO - 2024-09-20 10:45:35 --> Security Class Initialized
DEBUG - 2024-09-20 10:45:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-20 10:45:35 --> Input Class Initialized
INFO - 2024-09-20 10:45:35 --> Language Class Initialized
INFO - 2024-09-20 10:45:35 --> Language Class Initialized
INFO - 2024-09-20 10:45:35 --> Config Class Initialized
INFO - 2024-09-20 10:45:35 --> Loader Class Initialized
INFO - 2024-09-20 10:45:35 --> Helper loaded: url_helper
INFO - 2024-09-20 10:45:35 --> Helper loaded: file_helper
INFO - 2024-09-20 10:45:35 --> Helper loaded: form_helper
INFO - 2024-09-20 10:45:35 --> Helper loaded: my_helper
INFO - 2024-09-20 10:45:35 --> Database Driver Class Initialized
INFO - 2024-09-20 10:45:35 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-20 10:45:35 --> Controller Class Initialized
INFO - 2024-09-20 10:45:35 --> Final output sent to browser
DEBUG - 2024-09-20 10:45:35 --> Total execution time: 0.0290
INFO - 2024-09-20 10:46:01 --> Config Class Initialized
INFO - 2024-09-20 10:46:01 --> Hooks Class Initialized
DEBUG - 2024-09-20 10:46:01 --> UTF-8 Support Enabled
INFO - 2024-09-20 10:46:01 --> Utf8 Class Initialized
INFO - 2024-09-20 10:46:01 --> URI Class Initialized
INFO - 2024-09-20 10:46:01 --> Router Class Initialized
INFO - 2024-09-20 10:46:01 --> Output Class Initialized
INFO - 2024-09-20 10:46:01 --> Security Class Initialized
DEBUG - 2024-09-20 10:46:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-20 10:46:01 --> Input Class Initialized
INFO - 2024-09-20 10:46:01 --> Language Class Initialized
INFO - 2024-09-20 10:46:01 --> Language Class Initialized
INFO - 2024-09-20 10:46:01 --> Config Class Initialized
INFO - 2024-09-20 10:46:01 --> Loader Class Initialized
INFO - 2024-09-20 10:46:01 --> Helper loaded: url_helper
INFO - 2024-09-20 10:46:01 --> Helper loaded: file_helper
INFO - 2024-09-20 10:46:01 --> Helper loaded: form_helper
INFO - 2024-09-20 10:46:01 --> Helper loaded: my_helper
INFO - 2024-09-20 10:46:01 --> Database Driver Class Initialized
INFO - 2024-09-20 10:46:01 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-20 10:46:01 --> Controller Class Initialized
ERROR - 2024-09-20 10:46:01 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near 's comprehension skills. You are beginning to understand the main ideas and detai' at line 1 - Invalid query: UPDATE t_nilai_cat SET tasm = '20241', nilai = '-', nilai_mid = 'There is a noticeable betterment in the student's comprehension skills. You are beginning to understand the main ideas and details in reading assignments and are making efforts to grasp vocabulary and context within texts. Furthermore, in terms of writing, assignments are becoming more organized and structured, with fewer grammatical errors, although some persist. You are demonstrating increased clarity and coherence in conveying ideas in your writing. Regarding participation, you are engaging more frequently in classroom discussions, contributing occasionally to group activities, and taking initial steps to overcome shyness in verbal communication.' WHERE id_guru_mapel = '51' AND id_mapel_kd = '10' AND id_siswa = '85' AND jenis = 'c'
INFO - 2024-09-20 10:46:01 --> Language file loaded: language/english/db_lang.php
INFO - 2024-09-20 10:46:46 --> Config Class Initialized
INFO - 2024-09-20 10:46:46 --> Hooks Class Initialized
DEBUG - 2024-09-20 10:46:46 --> UTF-8 Support Enabled
INFO - 2024-09-20 10:46:46 --> Utf8 Class Initialized
INFO - 2024-09-20 10:46:46 --> URI Class Initialized
INFO - 2024-09-20 10:46:46 --> Router Class Initialized
INFO - 2024-09-20 10:46:46 --> Output Class Initialized
INFO - 2024-09-20 10:46:46 --> Security Class Initialized
DEBUG - 2024-09-20 10:46:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-20 10:46:46 --> Input Class Initialized
INFO - 2024-09-20 10:46:46 --> Language Class Initialized
INFO - 2024-09-20 10:46:46 --> Language Class Initialized
INFO - 2024-09-20 10:46:46 --> Config Class Initialized
INFO - 2024-09-20 10:46:46 --> Loader Class Initialized
INFO - 2024-09-20 10:46:46 --> Helper loaded: url_helper
INFO - 2024-09-20 10:46:46 --> Helper loaded: file_helper
INFO - 2024-09-20 10:46:46 --> Helper loaded: form_helper
INFO - 2024-09-20 10:46:46 --> Helper loaded: my_helper
INFO - 2024-09-20 10:46:46 --> Database Driver Class Initialized
INFO - 2024-09-20 10:46:46 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-20 10:46:46 --> Controller Class Initialized
ERROR - 2024-09-20 10:46:46 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near 's comprehension skills. You are beginning to understand the main ideas and detai' at line 1 - Invalid query: UPDATE t_nilai_cat SET tasm = '20241', nilai = '-', nilai_mid = 'There is a noticeable betterment in the student's comprehension skills. You are beginning to understand the main ideas and details in reading assignments and are making efforts to grasp vocabulary and context within texts. Furthermore, in terms of writing, assignments are becoming more organized and structured, with fewer grammatical errors, although some persist. You are demonstrating increased clarity and coherence in conveying ideas in your writing. Regarding participation, you are engaging more frequently in classroom discussions, contributing occasionally to group activities, and taking initial steps to overcome shyness in verbal communication.' WHERE id_guru_mapel = '51' AND id_mapel_kd = '10' AND id_siswa = '90' AND jenis = 'c'
INFO - 2024-09-20 10:46:46 --> Language file loaded: language/english/db_lang.php
INFO - 2024-09-20 10:47:31 --> Config Class Initialized
INFO - 2024-09-20 10:47:31 --> Hooks Class Initialized
DEBUG - 2024-09-20 10:47:31 --> UTF-8 Support Enabled
INFO - 2024-09-20 10:47:31 --> Utf8 Class Initialized
INFO - 2024-09-20 10:47:31 --> URI Class Initialized
INFO - 2024-09-20 10:47:31 --> Router Class Initialized
INFO - 2024-09-20 10:47:31 --> Output Class Initialized
INFO - 2024-09-20 10:47:31 --> Security Class Initialized
DEBUG - 2024-09-20 10:47:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-20 10:47:31 --> Input Class Initialized
INFO - 2024-09-20 10:47:31 --> Language Class Initialized
INFO - 2024-09-20 10:47:31 --> Language Class Initialized
INFO - 2024-09-20 10:47:31 --> Config Class Initialized
INFO - 2024-09-20 10:47:31 --> Loader Class Initialized
INFO - 2024-09-20 10:47:31 --> Helper loaded: url_helper
INFO - 2024-09-20 10:47:31 --> Helper loaded: file_helper
INFO - 2024-09-20 10:47:31 --> Helper loaded: form_helper
INFO - 2024-09-20 10:47:31 --> Helper loaded: my_helper
INFO - 2024-09-20 10:47:31 --> Database Driver Class Initialized
INFO - 2024-09-20 10:47:31 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-20 10:47:31 --> Controller Class Initialized
ERROR - 2024-09-20 10:47:31 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near 's comprehension skills. You are beginning to understand the main ideas and detai' at line 1 - Invalid query: UPDATE t_nilai_cat SET tasm = '20241', nilai = '-', nilai_mid = 'There is a noticeable betterment in the student's comprehension skills. You are beginning to understand the main ideas and details in reading assignments and are making efforts to grasp vocabulary and context within texts. Furthermore, in terms of writing, assignments are becoming more organized and structured, with fewer grammatical errors, although some persist. You are demonstrating increased clarity and coherence in conveying ideas in your writing. Regarding participation, you are engaging more frequently in classroom discussions, contributing occasionally to group activities, and taking initial steps to overcome shyness in verbal communication.' WHERE id_guru_mapel = '51' AND id_mapel_kd = '10' AND id_siswa = '73' AND jenis = 'c'
INFO - 2024-09-20 10:47:31 --> Language file loaded: language/english/db_lang.php
INFO - 2024-09-20 10:47:33 --> Config Class Initialized
INFO - 2024-09-20 10:47:33 --> Hooks Class Initialized
DEBUG - 2024-09-20 10:47:33 --> UTF-8 Support Enabled
INFO - 2024-09-20 10:47:33 --> Utf8 Class Initialized
INFO - 2024-09-20 10:47:33 --> URI Class Initialized
INFO - 2024-09-20 10:47:33 --> Router Class Initialized
INFO - 2024-09-20 10:47:33 --> Output Class Initialized
INFO - 2024-09-20 10:47:33 --> Security Class Initialized
DEBUG - 2024-09-20 10:47:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-20 10:47:33 --> Input Class Initialized
INFO - 2024-09-20 10:47:33 --> Language Class Initialized
INFO - 2024-09-20 10:47:33 --> Language Class Initialized
INFO - 2024-09-20 10:47:33 --> Config Class Initialized
INFO - 2024-09-20 10:47:33 --> Loader Class Initialized
INFO - 2024-09-20 10:47:33 --> Helper loaded: url_helper
INFO - 2024-09-20 10:47:33 --> Helper loaded: file_helper
INFO - 2024-09-20 10:47:33 --> Helper loaded: form_helper
INFO - 2024-09-20 10:47:33 --> Helper loaded: my_helper
INFO - 2024-09-20 10:47:33 --> Database Driver Class Initialized
INFO - 2024-09-20 10:47:33 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-20 10:47:33 --> Controller Class Initialized
ERROR - 2024-09-20 10:47:33 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near 's comprehension skills. You are beginning to understand the main ideas and detai' at line 1 - Invalid query: UPDATE t_nilai_cat SET tasm = '20241', nilai = '-', nilai_mid = 'There is a noticeable betterment in the student's comprehension skills. You are beginning to understand the main ideas and details in reading assignments and are making efforts to grasp vocabulary and context within texts. Furthermore, in terms of writing, assignments are becoming more organized and structured, with fewer grammatical errors, although some persist. You are demonstrating increased clarity and coherence in conveying ideas in your writing. Regarding participation, you are engaging more frequently in classroom discussions, contributing occasionally to group activities, and taking initial steps to overcome shyness in verbal communication.' WHERE id_guru_mapel = '51' AND id_mapel_kd = '10' AND id_siswa = '73' AND jenis = 'c'
INFO - 2024-09-20 10:47:33 --> Language file loaded: language/english/db_lang.php
INFO - 2024-09-20 10:47:33 --> Config Class Initialized
INFO - 2024-09-20 10:47:33 --> Hooks Class Initialized
DEBUG - 2024-09-20 10:47:33 --> UTF-8 Support Enabled
INFO - 2024-09-20 10:47:33 --> Utf8 Class Initialized
INFO - 2024-09-20 10:47:33 --> URI Class Initialized
INFO - 2024-09-20 10:47:33 --> Router Class Initialized
INFO - 2024-09-20 10:47:33 --> Output Class Initialized
INFO - 2024-09-20 10:47:33 --> Security Class Initialized
DEBUG - 2024-09-20 10:47:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-20 10:47:33 --> Input Class Initialized
INFO - 2024-09-20 10:47:33 --> Language Class Initialized
INFO - 2024-09-20 10:47:33 --> Language Class Initialized
INFO - 2024-09-20 10:47:33 --> Config Class Initialized
INFO - 2024-09-20 10:47:33 --> Loader Class Initialized
INFO - 2024-09-20 10:47:33 --> Helper loaded: url_helper
INFO - 2024-09-20 10:47:33 --> Helper loaded: file_helper
INFO - 2024-09-20 10:47:33 --> Helper loaded: form_helper
INFO - 2024-09-20 10:47:33 --> Helper loaded: my_helper
INFO - 2024-09-20 10:47:33 --> Database Driver Class Initialized
INFO - 2024-09-20 10:47:33 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-20 10:47:33 --> Controller Class Initialized
ERROR - 2024-09-20 10:47:33 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near 's comprehension skills. You are beginning to understand the main ideas and detai' at line 1 - Invalid query: UPDATE t_nilai_cat SET tasm = '20241', nilai = '-', nilai_mid = 'There is a noticeable betterment in the student's comprehension skills. You are beginning to understand the main ideas and details in reading assignments and are making efforts to grasp vocabulary and context within texts. Furthermore, in terms of writing, assignments are becoming more organized and structured, with fewer grammatical errors, although some persist. You are demonstrating increased clarity and coherence in conveying ideas in your writing. Regarding participation, you are engaging more frequently in classroom discussions, contributing occasionally to group activities, and taking initial steps to overcome shyness in verbal communication.' WHERE id_guru_mapel = '51' AND id_mapel_kd = '10' AND id_siswa = '73' AND jenis = 'c'
INFO - 2024-09-20 10:47:33 --> Language file loaded: language/english/db_lang.php
INFO - 2024-09-20 10:47:33 --> Config Class Initialized
INFO - 2024-09-20 10:47:33 --> Hooks Class Initialized
DEBUG - 2024-09-20 10:47:33 --> UTF-8 Support Enabled
INFO - 2024-09-20 10:47:33 --> Utf8 Class Initialized
INFO - 2024-09-20 10:47:33 --> URI Class Initialized
INFO - 2024-09-20 10:47:33 --> Router Class Initialized
INFO - 2024-09-20 10:47:33 --> Output Class Initialized
INFO - 2024-09-20 10:47:33 --> Security Class Initialized
DEBUG - 2024-09-20 10:47:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-20 10:47:33 --> Input Class Initialized
INFO - 2024-09-20 10:47:33 --> Language Class Initialized
INFO - 2024-09-20 10:47:33 --> Language Class Initialized
INFO - 2024-09-20 10:47:33 --> Config Class Initialized
INFO - 2024-09-20 10:47:33 --> Loader Class Initialized
INFO - 2024-09-20 10:47:33 --> Helper loaded: url_helper
INFO - 2024-09-20 10:47:33 --> Helper loaded: file_helper
INFO - 2024-09-20 10:47:33 --> Helper loaded: form_helper
INFO - 2024-09-20 10:47:33 --> Helper loaded: my_helper
INFO - 2024-09-20 10:47:33 --> Database Driver Class Initialized
INFO - 2024-09-20 10:47:33 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-20 10:47:33 --> Controller Class Initialized
ERROR - 2024-09-20 10:47:33 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near 's comprehension skills. You are beginning to understand the main ideas and detai' at line 1 - Invalid query: UPDATE t_nilai_cat SET tasm = '20241', nilai = '-', nilai_mid = 'There is a noticeable betterment in the student's comprehension skills. You are beginning to understand the main ideas and details in reading assignments and are making efforts to grasp vocabulary and context within texts. Furthermore, in terms of writing, assignments are becoming more organized and structured, with fewer grammatical errors, although some persist. You are demonstrating increased clarity and coherence in conveying ideas in your writing. Regarding participation, you are engaging more frequently in classroom discussions, contributing occasionally to group activities, and taking initial steps to overcome shyness in verbal communication.' WHERE id_guru_mapel = '51' AND id_mapel_kd = '10' AND id_siswa = '73' AND jenis = 'c'
INFO - 2024-09-20 10:47:33 --> Language file loaded: language/english/db_lang.php
INFO - 2024-09-20 10:47:33 --> Config Class Initialized
INFO - 2024-09-20 10:47:33 --> Hooks Class Initialized
DEBUG - 2024-09-20 10:47:33 --> UTF-8 Support Enabled
INFO - 2024-09-20 10:47:33 --> Utf8 Class Initialized
INFO - 2024-09-20 10:47:33 --> URI Class Initialized
INFO - 2024-09-20 10:47:33 --> Router Class Initialized
INFO - 2024-09-20 10:47:33 --> Output Class Initialized
INFO - 2024-09-20 10:47:33 --> Security Class Initialized
DEBUG - 2024-09-20 10:47:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-20 10:47:33 --> Input Class Initialized
INFO - 2024-09-20 10:47:33 --> Language Class Initialized
INFO - 2024-09-20 10:47:33 --> Language Class Initialized
INFO - 2024-09-20 10:47:33 --> Config Class Initialized
INFO - 2024-09-20 10:47:33 --> Loader Class Initialized
INFO - 2024-09-20 10:47:33 --> Helper loaded: url_helper
INFO - 2024-09-20 10:47:33 --> Helper loaded: file_helper
INFO - 2024-09-20 10:47:33 --> Helper loaded: form_helper
INFO - 2024-09-20 10:47:33 --> Helper loaded: my_helper
INFO - 2024-09-20 10:47:33 --> Database Driver Class Initialized
INFO - 2024-09-20 10:47:34 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-20 10:47:34 --> Controller Class Initialized
ERROR - 2024-09-20 10:47:34 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near 's comprehension skills. You are beginning to understand the main ideas and detai' at line 1 - Invalid query: UPDATE t_nilai_cat SET tasm = '20241', nilai = '-', nilai_mid = 'There is a noticeable betterment in the student's comprehension skills. You are beginning to understand the main ideas and details in reading assignments and are making efforts to grasp vocabulary and context within texts. Furthermore, in terms of writing, assignments are becoming more organized and structured, with fewer grammatical errors, although some persist. You are demonstrating increased clarity and coherence in conveying ideas in your writing. Regarding participation, you are engaging more frequently in classroom discussions, contributing occasionally to group activities, and taking initial steps to overcome shyness in verbal communication.' WHERE id_guru_mapel = '51' AND id_mapel_kd = '10' AND id_siswa = '73' AND jenis = 'c'
INFO - 2024-09-20 10:47:34 --> Language file loaded: language/english/db_lang.php
INFO - 2024-09-20 10:47:34 --> Config Class Initialized
INFO - 2024-09-20 10:47:34 --> Hooks Class Initialized
DEBUG - 2024-09-20 10:47:34 --> UTF-8 Support Enabled
INFO - 2024-09-20 10:47:34 --> Utf8 Class Initialized
INFO - 2024-09-20 10:47:34 --> URI Class Initialized
INFO - 2024-09-20 10:47:34 --> Router Class Initialized
INFO - 2024-09-20 10:47:34 --> Output Class Initialized
INFO - 2024-09-20 10:47:34 --> Security Class Initialized
DEBUG - 2024-09-20 10:47:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-20 10:47:34 --> Input Class Initialized
INFO - 2024-09-20 10:47:34 --> Language Class Initialized
INFO - 2024-09-20 10:47:34 --> Language Class Initialized
INFO - 2024-09-20 10:47:34 --> Config Class Initialized
INFO - 2024-09-20 10:47:34 --> Loader Class Initialized
INFO - 2024-09-20 10:47:34 --> Helper loaded: url_helper
INFO - 2024-09-20 10:47:34 --> Helper loaded: file_helper
INFO - 2024-09-20 10:47:34 --> Helper loaded: form_helper
INFO - 2024-09-20 10:47:34 --> Helper loaded: my_helper
INFO - 2024-09-20 10:47:34 --> Database Driver Class Initialized
INFO - 2024-09-20 10:47:34 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-20 10:47:34 --> Controller Class Initialized
ERROR - 2024-09-20 10:47:34 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near 's comprehension skills. You are beginning to understand the main ideas and detai' at line 1 - Invalid query: UPDATE t_nilai_cat SET tasm = '20241', nilai = '-', nilai_mid = 'There is a noticeable betterment in the student's comprehension skills. You are beginning to understand the main ideas and details in reading assignments and are making efforts to grasp vocabulary and context within texts. Furthermore, in terms of writing, assignments are becoming more organized and structured, with fewer grammatical errors, although some persist. You are demonstrating increased clarity and coherence in conveying ideas in your writing. Regarding participation, you are engaging more frequently in classroom discussions, contributing occasionally to group activities, and taking initial steps to overcome shyness in verbal communication.' WHERE id_guru_mapel = '51' AND id_mapel_kd = '10' AND id_siswa = '73' AND jenis = 'c'
INFO - 2024-09-20 10:47:34 --> Language file loaded: language/english/db_lang.php
INFO - 2024-09-20 10:47:35 --> Config Class Initialized
INFO - 2024-09-20 10:47:35 --> Hooks Class Initialized
DEBUG - 2024-09-20 10:47:35 --> UTF-8 Support Enabled
INFO - 2024-09-20 10:47:35 --> Utf8 Class Initialized
INFO - 2024-09-20 10:47:35 --> URI Class Initialized
INFO - 2024-09-20 10:47:35 --> Router Class Initialized
INFO - 2024-09-20 10:47:35 --> Output Class Initialized
INFO - 2024-09-20 10:47:35 --> Security Class Initialized
DEBUG - 2024-09-20 10:47:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-20 10:47:35 --> Input Class Initialized
INFO - 2024-09-20 10:47:35 --> Language Class Initialized
INFO - 2024-09-20 10:47:35 --> Language Class Initialized
INFO - 2024-09-20 10:47:35 --> Config Class Initialized
INFO - 2024-09-20 10:47:35 --> Loader Class Initialized
INFO - 2024-09-20 10:47:35 --> Helper loaded: url_helper
INFO - 2024-09-20 10:47:35 --> Helper loaded: file_helper
INFO - 2024-09-20 10:47:35 --> Helper loaded: form_helper
INFO - 2024-09-20 10:47:35 --> Helper loaded: my_helper
INFO - 2024-09-20 10:47:35 --> Database Driver Class Initialized
INFO - 2024-09-20 10:47:35 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-20 10:47:35 --> Controller Class Initialized
ERROR - 2024-09-20 10:47:35 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near 's comprehension skills. You are beginning to understand the main ideas and detai' at line 1 - Invalid query: UPDATE t_nilai_cat SET tasm = '20241', nilai = '-', nilai_mid = 'There is a noticeable betterment in the student's comprehension skills. You are beginning to understand the main ideas and details in reading assignments and are making efforts to grasp vocabulary and context within texts. Furthermore, in terms of writing, assignments are becoming more organized and structured, with fewer grammatical errors, although some persist. You are demonstrating increased clarity and coherence in conveying ideas in your writing. Regarding participation, you are engaging more frequently in classroom discussions, contributing occasionally to group activities, and taking initial steps to overcome shyness in verbal communication.' WHERE id_guru_mapel = '51' AND id_mapel_kd = '10' AND id_siswa = '73' AND jenis = 'c'
INFO - 2024-09-20 10:47:35 --> Language file loaded: language/english/db_lang.php
INFO - 2024-09-20 10:47:44 --> Config Class Initialized
INFO - 2024-09-20 10:47:44 --> Hooks Class Initialized
DEBUG - 2024-09-20 10:47:44 --> UTF-8 Support Enabled
INFO - 2024-09-20 10:47:44 --> Utf8 Class Initialized
INFO - 2024-09-20 10:47:44 --> URI Class Initialized
INFO - 2024-09-20 10:47:44 --> Router Class Initialized
INFO - 2024-09-20 10:47:44 --> Output Class Initialized
INFO - 2024-09-20 10:47:44 --> Security Class Initialized
DEBUG - 2024-09-20 10:47:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-20 10:47:44 --> Input Class Initialized
INFO - 2024-09-20 10:47:44 --> Language Class Initialized
INFO - 2024-09-20 10:47:44 --> Language Class Initialized
INFO - 2024-09-20 10:47:44 --> Config Class Initialized
INFO - 2024-09-20 10:47:44 --> Loader Class Initialized
INFO - 2024-09-20 10:47:44 --> Helper loaded: url_helper
INFO - 2024-09-20 10:47:44 --> Helper loaded: file_helper
INFO - 2024-09-20 10:47:44 --> Helper loaded: form_helper
INFO - 2024-09-20 10:47:44 --> Helper loaded: my_helper
INFO - 2024-09-20 10:47:44 --> Database Driver Class Initialized
INFO - 2024-09-20 10:47:44 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-20 10:47:44 --> Controller Class Initialized
INFO - 2024-09-20 10:47:44 --> Final output sent to browser
DEBUG - 2024-09-20 10:47:44 --> Total execution time: 0.0691
INFO - 2024-09-20 10:48:35 --> Config Class Initialized
INFO - 2024-09-20 10:48:35 --> Hooks Class Initialized
DEBUG - 2024-09-20 10:48:35 --> UTF-8 Support Enabled
INFO - 2024-09-20 10:48:35 --> Utf8 Class Initialized
INFO - 2024-09-20 10:48:35 --> URI Class Initialized
INFO - 2024-09-20 10:48:35 --> Router Class Initialized
INFO - 2024-09-20 10:48:35 --> Output Class Initialized
INFO - 2024-09-20 10:48:35 --> Security Class Initialized
DEBUG - 2024-09-20 10:48:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-20 10:48:35 --> Input Class Initialized
INFO - 2024-09-20 10:48:35 --> Language Class Initialized
INFO - 2024-09-20 10:48:35 --> Language Class Initialized
INFO - 2024-09-20 10:48:35 --> Config Class Initialized
INFO - 2024-09-20 10:48:35 --> Loader Class Initialized
INFO - 2024-09-20 10:48:35 --> Helper loaded: url_helper
INFO - 2024-09-20 10:48:35 --> Helper loaded: file_helper
INFO - 2024-09-20 10:48:35 --> Helper loaded: form_helper
INFO - 2024-09-20 10:48:35 --> Helper loaded: my_helper
INFO - 2024-09-20 10:48:35 --> Database Driver Class Initialized
INFO - 2024-09-20 10:48:36 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-20 10:48:36 --> Controller Class Initialized
ERROR - 2024-09-20 10:48:36 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near 's comprehension skills. You are beginning to understand the main ideas and detai' at line 1 - Invalid query: UPDATE t_nilai_cat SET tasm = '20241', nilai = '-', nilai_mid = 'There is a noticeable betterment in the student's comprehension skills. You are beginning to understand the main ideas and details in reading assignments and are making efforts to grasp vocabulary and context within texts. Furthermore, in terms of writing, assignments are becoming more organized and structured, with fewer grammatical errors, although some persist. You are demonstrating increased clarity and coherence in conveying ideas in your writing. Regarding participation, you are engaging more frequently in classroom discussions, contributing occasionally to group activities, and taking initial steps to overcome shyness in verbal communication.' WHERE id_guru_mapel = '51' AND id_mapel_kd = '10' AND id_siswa = '73' AND jenis = 'c'
INFO - 2024-09-20 10:48:36 --> Language file loaded: language/english/db_lang.php
INFO - 2024-09-20 10:48:36 --> Config Class Initialized
INFO - 2024-09-20 10:48:36 --> Hooks Class Initialized
DEBUG - 2024-09-20 10:48:36 --> UTF-8 Support Enabled
INFO - 2024-09-20 10:48:36 --> Utf8 Class Initialized
INFO - 2024-09-20 10:48:36 --> URI Class Initialized
INFO - 2024-09-20 10:48:36 --> Router Class Initialized
INFO - 2024-09-20 10:48:36 --> Output Class Initialized
INFO - 2024-09-20 10:48:36 --> Security Class Initialized
DEBUG - 2024-09-20 10:48:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-20 10:48:36 --> Input Class Initialized
INFO - 2024-09-20 10:48:36 --> Language Class Initialized
INFO - 2024-09-20 10:48:36 --> Language Class Initialized
INFO - 2024-09-20 10:48:36 --> Config Class Initialized
INFO - 2024-09-20 10:48:36 --> Loader Class Initialized
INFO - 2024-09-20 10:48:36 --> Helper loaded: url_helper
INFO - 2024-09-20 10:48:36 --> Helper loaded: file_helper
INFO - 2024-09-20 10:48:36 --> Helper loaded: form_helper
INFO - 2024-09-20 10:48:36 --> Helper loaded: my_helper
INFO - 2024-09-20 10:48:36 --> Database Driver Class Initialized
INFO - 2024-09-20 10:48:36 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-20 10:48:36 --> Controller Class Initialized
ERROR - 2024-09-20 10:48:36 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near 's comprehension skills. You are beginning to understand the main ideas and detai' at line 1 - Invalid query: UPDATE t_nilai_cat SET tasm = '20241', nilai = '-', nilai_mid = 'There is a noticeable betterment in the student's comprehension skills. You are beginning to understand the main ideas and details in reading assignments and are making efforts to grasp vocabulary and context within texts. Furthermore, in terms of writing, assignments are becoming more organized and structured, with fewer grammatical errors, although some persist. You are demonstrating increased clarity and coherence in conveying ideas in your writing. Regarding participation, you are engaging more frequently in classroom discussions, contributing occasionally to group activities, and taking initial steps to overcome shyness in verbal communication.' WHERE id_guru_mapel = '51' AND id_mapel_kd = '10' AND id_siswa = '73' AND jenis = 'c'
INFO - 2024-09-20 10:48:36 --> Language file loaded: language/english/db_lang.php
INFO - 2024-09-20 10:48:36 --> Config Class Initialized
INFO - 2024-09-20 10:48:36 --> Hooks Class Initialized
DEBUG - 2024-09-20 10:48:36 --> UTF-8 Support Enabled
INFO - 2024-09-20 10:48:36 --> Utf8 Class Initialized
INFO - 2024-09-20 10:48:36 --> URI Class Initialized
INFO - 2024-09-20 10:48:36 --> Router Class Initialized
INFO - 2024-09-20 10:48:36 --> Output Class Initialized
INFO - 2024-09-20 10:48:36 --> Security Class Initialized
DEBUG - 2024-09-20 10:48:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-20 10:48:36 --> Input Class Initialized
INFO - 2024-09-20 10:48:36 --> Language Class Initialized
INFO - 2024-09-20 10:48:36 --> Language Class Initialized
INFO - 2024-09-20 10:48:36 --> Config Class Initialized
INFO - 2024-09-20 10:48:36 --> Loader Class Initialized
INFO - 2024-09-20 10:48:36 --> Helper loaded: url_helper
INFO - 2024-09-20 10:48:36 --> Helper loaded: file_helper
INFO - 2024-09-20 10:48:36 --> Helper loaded: form_helper
INFO - 2024-09-20 10:48:36 --> Helper loaded: my_helper
INFO - 2024-09-20 10:48:36 --> Database Driver Class Initialized
INFO - 2024-09-20 10:48:36 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-20 10:48:36 --> Controller Class Initialized
ERROR - 2024-09-20 10:48:36 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near 's comprehension skills. You are beginning to understand the main ideas and detai' at line 1 - Invalid query: UPDATE t_nilai_cat SET tasm = '20241', nilai = '-', nilai_mid = 'There is a noticeable betterment in the student's comprehension skills. You are beginning to understand the main ideas and details in reading assignments and are making efforts to grasp vocabulary and context within texts. Furthermore, in terms of writing, assignments are becoming more organized and structured, with fewer grammatical errors, although some persist. You are demonstrating increased clarity and coherence in conveying ideas in your writing. Regarding participation, you are engaging more frequently in classroom discussions, contributing occasionally to group activities, and taking initial steps to overcome shyness in verbal communication.' WHERE id_guru_mapel = '51' AND id_mapel_kd = '10' AND id_siswa = '73' AND jenis = 'c'
INFO - 2024-09-20 10:48:36 --> Language file loaded: language/english/db_lang.php
INFO - 2024-09-20 10:48:37 --> Config Class Initialized
INFO - 2024-09-20 10:48:37 --> Hooks Class Initialized
DEBUG - 2024-09-20 10:48:37 --> UTF-8 Support Enabled
INFO - 2024-09-20 10:48:37 --> Utf8 Class Initialized
INFO - 2024-09-20 10:48:37 --> URI Class Initialized
INFO - 2024-09-20 10:48:37 --> Router Class Initialized
INFO - 2024-09-20 10:48:37 --> Output Class Initialized
INFO - 2024-09-20 10:48:37 --> Security Class Initialized
DEBUG - 2024-09-20 10:48:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-20 10:48:37 --> Input Class Initialized
INFO - 2024-09-20 10:48:37 --> Language Class Initialized
INFO - 2024-09-20 10:48:37 --> Language Class Initialized
INFO - 2024-09-20 10:48:37 --> Config Class Initialized
INFO - 2024-09-20 10:48:37 --> Loader Class Initialized
INFO - 2024-09-20 10:48:37 --> Helper loaded: url_helper
INFO - 2024-09-20 10:48:37 --> Helper loaded: file_helper
INFO - 2024-09-20 10:48:37 --> Helper loaded: form_helper
INFO - 2024-09-20 10:48:37 --> Helper loaded: my_helper
INFO - 2024-09-20 10:48:37 --> Database Driver Class Initialized
INFO - 2024-09-20 10:48:37 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-20 10:48:37 --> Controller Class Initialized
ERROR - 2024-09-20 10:48:37 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near 's comprehension skills. You are beginning to understand the main ideas and detai' at line 1 - Invalid query: UPDATE t_nilai_cat SET tasm = '20241', nilai = '-', nilai_mid = 'There is a noticeable betterment in the student's comprehension skills. You are beginning to understand the main ideas and details in reading assignments and are making efforts to grasp vocabulary and context within texts. Furthermore, in terms of writing, assignments are becoming more organized and structured, with fewer grammatical errors, although some persist. You are demonstrating increased clarity and coherence in conveying ideas in your writing. Regarding participation, you are engaging more frequently in classroom discussions, contributing occasionally to group activities, and taking initial steps to overcome shyness in verbal communication.' WHERE id_guru_mapel = '51' AND id_mapel_kd = '10' AND id_siswa = '73' AND jenis = 'c'
INFO - 2024-09-20 10:48:37 --> Language file loaded: language/english/db_lang.php
INFO - 2024-09-20 10:48:41 --> Config Class Initialized
INFO - 2024-09-20 10:48:41 --> Hooks Class Initialized
DEBUG - 2024-09-20 10:48:41 --> UTF-8 Support Enabled
INFO - 2024-09-20 10:48:41 --> Utf8 Class Initialized
INFO - 2024-09-20 10:48:41 --> URI Class Initialized
INFO - 2024-09-20 10:48:41 --> Router Class Initialized
INFO - 2024-09-20 10:48:41 --> Output Class Initialized
INFO - 2024-09-20 10:48:41 --> Security Class Initialized
DEBUG - 2024-09-20 10:48:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-20 10:48:41 --> Input Class Initialized
INFO - 2024-09-20 10:48:41 --> Language Class Initialized
INFO - 2024-09-20 10:48:41 --> Language Class Initialized
INFO - 2024-09-20 10:48:41 --> Config Class Initialized
INFO - 2024-09-20 10:48:41 --> Loader Class Initialized
INFO - 2024-09-20 10:48:41 --> Helper loaded: url_helper
INFO - 2024-09-20 10:48:41 --> Helper loaded: file_helper
INFO - 2024-09-20 10:48:41 --> Helper loaded: form_helper
INFO - 2024-09-20 10:48:41 --> Helper loaded: my_helper
INFO - 2024-09-20 10:48:41 --> Database Driver Class Initialized
INFO - 2024-09-20 10:48:41 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-20 10:48:41 --> Controller Class Initialized
DEBUG - 2024-09-20 10:48:41 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/view_mapel/views/v_view_mapel.php
DEBUG - 2024-09-20 10:48:41 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-09-20 10:48:41 --> Final output sent to browser
DEBUG - 2024-09-20 10:48:41 --> Total execution time: 0.0276
INFO - 2024-09-20 10:48:43 --> Config Class Initialized
INFO - 2024-09-20 10:48:43 --> Hooks Class Initialized
DEBUG - 2024-09-20 10:48:43 --> UTF-8 Support Enabled
INFO - 2024-09-20 10:48:43 --> Utf8 Class Initialized
INFO - 2024-09-20 10:48:43 --> URI Class Initialized
INFO - 2024-09-20 10:48:43 --> Router Class Initialized
INFO - 2024-09-20 10:48:43 --> Output Class Initialized
INFO - 2024-09-20 10:48:43 --> Security Class Initialized
DEBUG - 2024-09-20 10:48:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-20 10:48:43 --> Input Class Initialized
INFO - 2024-09-20 10:48:43 --> Language Class Initialized
INFO - 2024-09-20 10:48:43 --> Language Class Initialized
INFO - 2024-09-20 10:48:43 --> Config Class Initialized
INFO - 2024-09-20 10:48:43 --> Loader Class Initialized
INFO - 2024-09-20 10:48:43 --> Helper loaded: url_helper
INFO - 2024-09-20 10:48:43 --> Helper loaded: file_helper
INFO - 2024-09-20 10:48:43 --> Helper loaded: form_helper
INFO - 2024-09-20 10:48:43 --> Helper loaded: my_helper
INFO - 2024-09-20 10:48:43 --> Database Driver Class Initialized
INFO - 2024-09-20 10:48:43 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-20 10:48:43 --> Controller Class Initialized
DEBUG - 2024-09-20 10:48:43 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/views/list.php
DEBUG - 2024-09-20 10:48:43 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-09-20 10:48:43 --> Final output sent to browser
DEBUG - 2024-09-20 10:48:43 --> Total execution time: 0.0348
INFO - 2024-09-20 10:48:43 --> Config Class Initialized
INFO - 2024-09-20 10:48:43 --> Hooks Class Initialized
DEBUG - 2024-09-20 10:48:43 --> UTF-8 Support Enabled
INFO - 2024-09-20 10:48:43 --> Utf8 Class Initialized
INFO - 2024-09-20 10:48:43 --> URI Class Initialized
INFO - 2024-09-20 10:48:43 --> Router Class Initialized
INFO - 2024-09-20 10:48:43 --> Output Class Initialized
INFO - 2024-09-20 10:48:43 --> Security Class Initialized
DEBUG - 2024-09-20 10:48:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-20 10:48:43 --> Input Class Initialized
INFO - 2024-09-20 10:48:43 --> Language Class Initialized
INFO - 2024-09-20 10:48:43 --> Language Class Initialized
INFO - 2024-09-20 10:48:43 --> Config Class Initialized
INFO - 2024-09-20 10:48:43 --> Loader Class Initialized
INFO - 2024-09-20 10:48:43 --> Helper loaded: url_helper
INFO - 2024-09-20 10:48:43 --> Helper loaded: file_helper
INFO - 2024-09-20 10:48:43 --> Helper loaded: form_helper
INFO - 2024-09-20 10:48:43 --> Helper loaded: my_helper
INFO - 2024-09-20 10:48:43 --> Database Driver Class Initialized
INFO - 2024-09-20 10:48:43 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-20 10:48:43 --> Controller Class Initialized
INFO - 2024-09-20 10:48:46 --> Config Class Initialized
INFO - 2024-09-20 10:48:46 --> Hooks Class Initialized
DEBUG - 2024-09-20 10:48:46 --> UTF-8 Support Enabled
INFO - 2024-09-20 10:48:46 --> Utf8 Class Initialized
INFO - 2024-09-20 10:48:46 --> URI Class Initialized
INFO - 2024-09-20 10:48:46 --> Router Class Initialized
INFO - 2024-09-20 10:48:46 --> Output Class Initialized
INFO - 2024-09-20 10:48:46 --> Security Class Initialized
DEBUG - 2024-09-20 10:48:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-20 10:48:46 --> Input Class Initialized
INFO - 2024-09-20 10:48:46 --> Language Class Initialized
INFO - 2024-09-20 10:48:46 --> Language Class Initialized
INFO - 2024-09-20 10:48:46 --> Config Class Initialized
INFO - 2024-09-20 10:48:46 --> Loader Class Initialized
INFO - 2024-09-20 10:48:46 --> Helper loaded: url_helper
INFO - 2024-09-20 10:48:46 --> Helper loaded: file_helper
INFO - 2024-09-20 10:48:46 --> Helper loaded: form_helper
INFO - 2024-09-20 10:48:46 --> Helper loaded: my_helper
INFO - 2024-09-20 10:48:46 --> Database Driver Class Initialized
INFO - 2024-09-20 10:48:46 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-20 10:48:46 --> Controller Class Initialized
INFO - 2024-09-20 10:48:46 --> Final output sent to browser
DEBUG - 2024-09-20 10:48:46 --> Total execution time: 0.0510
INFO - 2024-09-20 10:48:53 --> Config Class Initialized
INFO - 2024-09-20 10:48:53 --> Hooks Class Initialized
DEBUG - 2024-09-20 10:48:53 --> UTF-8 Support Enabled
INFO - 2024-09-20 10:48:53 --> Utf8 Class Initialized
INFO - 2024-09-20 10:48:53 --> URI Class Initialized
INFO - 2024-09-20 10:48:53 --> Router Class Initialized
INFO - 2024-09-20 10:48:53 --> Output Class Initialized
INFO - 2024-09-20 10:48:53 --> Security Class Initialized
DEBUG - 2024-09-20 10:48:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-20 10:48:53 --> Input Class Initialized
INFO - 2024-09-20 10:48:53 --> Language Class Initialized
INFO - 2024-09-20 10:48:53 --> Language Class Initialized
INFO - 2024-09-20 10:48:53 --> Config Class Initialized
INFO - 2024-09-20 10:48:53 --> Loader Class Initialized
INFO - 2024-09-20 10:48:53 --> Helper loaded: url_helper
INFO - 2024-09-20 10:48:53 --> Helper loaded: file_helper
INFO - 2024-09-20 10:48:53 --> Helper loaded: form_helper
INFO - 2024-09-20 10:48:53 --> Helper loaded: my_helper
INFO - 2024-09-20 10:48:53 --> Database Driver Class Initialized
INFO - 2024-09-20 10:48:53 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-20 10:48:53 --> Controller Class Initialized
INFO - 2024-09-20 10:48:53 --> Final output sent to browser
DEBUG - 2024-09-20 10:48:53 --> Total execution time: 0.0398
INFO - 2024-09-20 10:48:57 --> Config Class Initialized
INFO - 2024-09-20 10:48:57 --> Hooks Class Initialized
DEBUG - 2024-09-20 10:48:57 --> UTF-8 Support Enabled
INFO - 2024-09-20 10:48:57 --> Utf8 Class Initialized
INFO - 2024-09-20 10:48:57 --> URI Class Initialized
INFO - 2024-09-20 10:48:57 --> Router Class Initialized
INFO - 2024-09-20 10:48:57 --> Output Class Initialized
INFO - 2024-09-20 10:48:57 --> Security Class Initialized
DEBUG - 2024-09-20 10:48:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-20 10:48:57 --> Input Class Initialized
INFO - 2024-09-20 10:48:57 --> Language Class Initialized
INFO - 2024-09-20 10:48:57 --> Language Class Initialized
INFO - 2024-09-20 10:48:57 --> Config Class Initialized
INFO - 2024-09-20 10:48:57 --> Loader Class Initialized
INFO - 2024-09-20 10:48:57 --> Helper loaded: url_helper
INFO - 2024-09-20 10:48:57 --> Helper loaded: file_helper
INFO - 2024-09-20 10:48:57 --> Helper loaded: form_helper
INFO - 2024-09-20 10:48:57 --> Helper loaded: my_helper
INFO - 2024-09-20 10:48:57 --> Database Driver Class Initialized
INFO - 2024-09-20 10:48:57 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-20 10:48:57 --> Controller Class Initialized
INFO - 2024-09-20 10:48:57 --> Final output sent to browser
DEBUG - 2024-09-20 10:48:57 --> Total execution time: 0.0304
INFO - 2024-09-20 10:49:03 --> Config Class Initialized
INFO - 2024-09-20 10:49:03 --> Hooks Class Initialized
DEBUG - 2024-09-20 10:49:03 --> UTF-8 Support Enabled
INFO - 2024-09-20 10:49:03 --> Utf8 Class Initialized
INFO - 2024-09-20 10:49:03 --> URI Class Initialized
INFO - 2024-09-20 10:49:03 --> Router Class Initialized
INFO - 2024-09-20 10:49:03 --> Output Class Initialized
INFO - 2024-09-20 10:49:03 --> Security Class Initialized
DEBUG - 2024-09-20 10:49:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-20 10:49:03 --> Input Class Initialized
INFO - 2024-09-20 10:49:03 --> Language Class Initialized
INFO - 2024-09-20 10:49:03 --> Language Class Initialized
INFO - 2024-09-20 10:49:03 --> Config Class Initialized
INFO - 2024-09-20 10:49:03 --> Loader Class Initialized
INFO - 2024-09-20 10:49:03 --> Helper loaded: url_helper
INFO - 2024-09-20 10:49:03 --> Helper loaded: file_helper
INFO - 2024-09-20 10:49:03 --> Helper loaded: form_helper
INFO - 2024-09-20 10:49:03 --> Helper loaded: my_helper
INFO - 2024-09-20 10:49:03 --> Database Driver Class Initialized
INFO - 2024-09-20 10:49:03 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-20 10:49:03 --> Controller Class Initialized
INFO - 2024-09-20 10:49:03 --> Final output sent to browser
DEBUG - 2024-09-20 10:49:03 --> Total execution time: 0.0741
INFO - 2024-09-20 10:49:07 --> Config Class Initialized
INFO - 2024-09-20 10:49:07 --> Hooks Class Initialized
DEBUG - 2024-09-20 10:49:07 --> UTF-8 Support Enabled
INFO - 2024-09-20 10:49:07 --> Utf8 Class Initialized
INFO - 2024-09-20 10:49:07 --> URI Class Initialized
INFO - 2024-09-20 10:49:07 --> Router Class Initialized
INFO - 2024-09-20 10:49:07 --> Output Class Initialized
INFO - 2024-09-20 10:49:07 --> Security Class Initialized
DEBUG - 2024-09-20 10:49:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-20 10:49:07 --> Input Class Initialized
INFO - 2024-09-20 10:49:07 --> Language Class Initialized
INFO - 2024-09-20 10:49:07 --> Language Class Initialized
INFO - 2024-09-20 10:49:07 --> Config Class Initialized
INFO - 2024-09-20 10:49:07 --> Loader Class Initialized
INFO - 2024-09-20 10:49:07 --> Helper loaded: url_helper
INFO - 2024-09-20 10:49:07 --> Helper loaded: file_helper
INFO - 2024-09-20 10:49:07 --> Helper loaded: form_helper
INFO - 2024-09-20 10:49:07 --> Helper loaded: my_helper
INFO - 2024-09-20 10:49:07 --> Database Driver Class Initialized
INFO - 2024-09-20 10:49:07 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-20 10:49:07 --> Controller Class Initialized
INFO - 2024-09-20 10:49:07 --> Final output sent to browser
DEBUG - 2024-09-20 10:49:07 --> Total execution time: 0.0314
INFO - 2024-09-20 10:49:11 --> Config Class Initialized
INFO - 2024-09-20 10:49:11 --> Hooks Class Initialized
DEBUG - 2024-09-20 10:49:11 --> UTF-8 Support Enabled
INFO - 2024-09-20 10:49:11 --> Utf8 Class Initialized
INFO - 2024-09-20 10:49:11 --> URI Class Initialized
INFO - 2024-09-20 10:49:11 --> Router Class Initialized
INFO - 2024-09-20 10:49:11 --> Output Class Initialized
INFO - 2024-09-20 10:49:11 --> Security Class Initialized
DEBUG - 2024-09-20 10:49:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-20 10:49:11 --> Input Class Initialized
INFO - 2024-09-20 10:49:11 --> Language Class Initialized
INFO - 2024-09-20 10:49:11 --> Language Class Initialized
INFO - 2024-09-20 10:49:11 --> Config Class Initialized
INFO - 2024-09-20 10:49:11 --> Loader Class Initialized
INFO - 2024-09-20 10:49:11 --> Helper loaded: url_helper
INFO - 2024-09-20 10:49:11 --> Helper loaded: file_helper
INFO - 2024-09-20 10:49:11 --> Helper loaded: form_helper
INFO - 2024-09-20 10:49:11 --> Helper loaded: my_helper
INFO - 2024-09-20 10:49:11 --> Database Driver Class Initialized
INFO - 2024-09-20 10:49:11 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-20 10:49:11 --> Controller Class Initialized
INFO - 2024-09-20 10:49:11 --> Final output sent to browser
DEBUG - 2024-09-20 10:49:11 --> Total execution time: 0.0304
INFO - 2024-09-20 10:49:19 --> Config Class Initialized
INFO - 2024-09-20 10:49:19 --> Hooks Class Initialized
DEBUG - 2024-09-20 10:49:19 --> UTF-8 Support Enabled
INFO - 2024-09-20 10:49:19 --> Utf8 Class Initialized
INFO - 2024-09-20 10:49:19 --> URI Class Initialized
INFO - 2024-09-20 10:49:19 --> Router Class Initialized
INFO - 2024-09-20 10:49:19 --> Output Class Initialized
INFO - 2024-09-20 10:49:19 --> Security Class Initialized
DEBUG - 2024-09-20 10:49:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-20 10:49:19 --> Input Class Initialized
INFO - 2024-09-20 10:49:19 --> Language Class Initialized
INFO - 2024-09-20 10:49:19 --> Language Class Initialized
INFO - 2024-09-20 10:49:19 --> Config Class Initialized
INFO - 2024-09-20 10:49:19 --> Loader Class Initialized
INFO - 2024-09-20 10:49:19 --> Helper loaded: url_helper
INFO - 2024-09-20 10:49:19 --> Helper loaded: file_helper
INFO - 2024-09-20 10:49:19 --> Helper loaded: form_helper
INFO - 2024-09-20 10:49:19 --> Helper loaded: my_helper
INFO - 2024-09-20 10:49:19 --> Database Driver Class Initialized
INFO - 2024-09-20 10:49:19 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-20 10:49:19 --> Controller Class Initialized
DEBUG - 2024-09-20 10:49:19 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/view_mapel/views/v_view_mapel.php
DEBUG - 2024-09-20 10:49:19 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-09-20 10:49:19 --> Final output sent to browser
DEBUG - 2024-09-20 10:49:19 --> Total execution time: 0.0283
INFO - 2024-09-20 10:49:22 --> Config Class Initialized
INFO - 2024-09-20 10:49:22 --> Hooks Class Initialized
DEBUG - 2024-09-20 10:49:22 --> UTF-8 Support Enabled
INFO - 2024-09-20 10:49:22 --> Utf8 Class Initialized
INFO - 2024-09-20 10:49:22 --> URI Class Initialized
INFO - 2024-09-20 10:49:22 --> Router Class Initialized
INFO - 2024-09-20 10:49:22 --> Output Class Initialized
INFO - 2024-09-20 10:49:22 --> Security Class Initialized
DEBUG - 2024-09-20 10:49:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-20 10:49:22 --> Input Class Initialized
INFO - 2024-09-20 10:49:22 --> Language Class Initialized
INFO - 2024-09-20 10:49:22 --> Language Class Initialized
INFO - 2024-09-20 10:49:22 --> Config Class Initialized
INFO - 2024-09-20 10:49:22 --> Loader Class Initialized
INFO - 2024-09-20 10:49:22 --> Helper loaded: url_helper
INFO - 2024-09-20 10:49:22 --> Helper loaded: file_helper
INFO - 2024-09-20 10:49:22 --> Helper loaded: form_helper
INFO - 2024-09-20 10:49:22 --> Helper loaded: my_helper
INFO - 2024-09-20 10:49:22 --> Database Driver Class Initialized
INFO - 2024-09-20 10:49:22 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-20 10:49:22 --> Controller Class Initialized
DEBUG - 2024-09-20 10:49:22 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_catatan_guru/views/list.php
DEBUG - 2024-09-20 10:49:22 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-09-20 10:49:22 --> Final output sent to browser
DEBUG - 2024-09-20 10:49:22 --> Total execution time: 0.0313
INFO - 2024-09-20 10:49:25 --> Config Class Initialized
INFO - 2024-09-20 10:49:25 --> Hooks Class Initialized
DEBUG - 2024-09-20 10:49:25 --> UTF-8 Support Enabled
INFO - 2024-09-20 10:49:25 --> Utf8 Class Initialized
INFO - 2024-09-20 10:49:25 --> URI Class Initialized
INFO - 2024-09-20 10:49:25 --> Router Class Initialized
INFO - 2024-09-20 10:49:25 --> Output Class Initialized
INFO - 2024-09-20 10:49:25 --> Security Class Initialized
DEBUG - 2024-09-20 10:49:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-20 10:49:25 --> Input Class Initialized
INFO - 2024-09-20 10:49:25 --> Language Class Initialized
INFO - 2024-09-20 10:49:25 --> Language Class Initialized
INFO - 2024-09-20 10:49:25 --> Config Class Initialized
INFO - 2024-09-20 10:49:25 --> Loader Class Initialized
INFO - 2024-09-20 10:49:25 --> Helper loaded: url_helper
INFO - 2024-09-20 10:49:25 --> Helper loaded: file_helper
INFO - 2024-09-20 10:49:25 --> Helper loaded: form_helper
INFO - 2024-09-20 10:49:25 --> Helper loaded: my_helper
INFO - 2024-09-20 10:49:25 --> Database Driver Class Initialized
INFO - 2024-09-20 10:49:25 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-20 10:49:25 --> Controller Class Initialized
INFO - 2024-09-20 10:49:25 --> Final output sent to browser
DEBUG - 2024-09-20 10:49:25 --> Total execution time: 0.0297
INFO - 2024-09-20 10:49:32 --> Config Class Initialized
INFO - 2024-09-20 10:49:32 --> Hooks Class Initialized
DEBUG - 2024-09-20 10:49:32 --> UTF-8 Support Enabled
INFO - 2024-09-20 10:49:32 --> Utf8 Class Initialized
INFO - 2024-09-20 10:49:32 --> URI Class Initialized
INFO - 2024-09-20 10:49:32 --> Router Class Initialized
INFO - 2024-09-20 10:49:32 --> Output Class Initialized
INFO - 2024-09-20 10:49:32 --> Security Class Initialized
DEBUG - 2024-09-20 10:49:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-20 10:49:32 --> Input Class Initialized
INFO - 2024-09-20 10:49:32 --> Language Class Initialized
INFO - 2024-09-20 10:49:32 --> Language Class Initialized
INFO - 2024-09-20 10:49:32 --> Config Class Initialized
INFO - 2024-09-20 10:49:32 --> Loader Class Initialized
INFO - 2024-09-20 10:49:32 --> Helper loaded: url_helper
INFO - 2024-09-20 10:49:32 --> Helper loaded: file_helper
INFO - 2024-09-20 10:49:32 --> Helper loaded: form_helper
INFO - 2024-09-20 10:49:32 --> Helper loaded: my_helper
INFO - 2024-09-20 10:49:32 --> Database Driver Class Initialized
INFO - 2024-09-20 10:49:32 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-20 10:49:32 --> Controller Class Initialized
INFO - 2024-09-20 10:54:09 --> Config Class Initialized
INFO - 2024-09-20 10:54:09 --> Hooks Class Initialized
DEBUG - 2024-09-20 10:54:09 --> UTF-8 Support Enabled
INFO - 2024-09-20 10:54:09 --> Utf8 Class Initialized
INFO - 2024-09-20 10:54:09 --> URI Class Initialized
INFO - 2024-09-20 10:54:09 --> Router Class Initialized
INFO - 2024-09-20 10:54:09 --> Output Class Initialized
INFO - 2024-09-20 10:54:09 --> Security Class Initialized
DEBUG - 2024-09-20 10:54:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-20 10:54:09 --> Input Class Initialized
INFO - 2024-09-20 10:54:09 --> Language Class Initialized
INFO - 2024-09-20 10:54:09 --> Language Class Initialized
INFO - 2024-09-20 10:54:09 --> Config Class Initialized
INFO - 2024-09-20 10:54:09 --> Loader Class Initialized
INFO - 2024-09-20 10:54:09 --> Helper loaded: url_helper
INFO - 2024-09-20 10:54:09 --> Helper loaded: file_helper
INFO - 2024-09-20 10:54:09 --> Helper loaded: form_helper
INFO - 2024-09-20 10:54:09 --> Helper loaded: my_helper
INFO - 2024-09-20 10:54:09 --> Database Driver Class Initialized
INFO - 2024-09-20 10:54:09 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-20 10:54:09 --> Controller Class Initialized
DEBUG - 2024-09-20 10:54:09 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_catatan_guru/views/form.php
DEBUG - 2024-09-20 10:54:09 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-09-20 10:54:09 --> Final output sent to browser
DEBUG - 2024-09-20 10:54:09 --> Total execution time: 0.0591
INFO - 2024-09-20 10:54:16 --> Config Class Initialized
INFO - 2024-09-20 10:54:16 --> Hooks Class Initialized
DEBUG - 2024-09-20 10:54:16 --> UTF-8 Support Enabled
INFO - 2024-09-20 10:54:16 --> Utf8 Class Initialized
INFO - 2024-09-20 10:54:16 --> URI Class Initialized
INFO - 2024-09-20 10:54:16 --> Router Class Initialized
INFO - 2024-09-20 10:54:16 --> Output Class Initialized
INFO - 2024-09-20 10:54:16 --> Security Class Initialized
DEBUG - 2024-09-20 10:54:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-20 10:54:16 --> Input Class Initialized
INFO - 2024-09-20 10:54:16 --> Language Class Initialized
INFO - 2024-09-20 10:54:16 --> Language Class Initialized
INFO - 2024-09-20 10:54:16 --> Config Class Initialized
INFO - 2024-09-20 10:54:16 --> Loader Class Initialized
INFO - 2024-09-20 10:54:16 --> Helper loaded: url_helper
INFO - 2024-09-20 10:54:16 --> Helper loaded: file_helper
INFO - 2024-09-20 10:54:16 --> Helper loaded: form_helper
INFO - 2024-09-20 10:54:16 --> Helper loaded: my_helper
INFO - 2024-09-20 10:54:16 --> Database Driver Class Initialized
INFO - 2024-09-20 10:54:16 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-20 10:54:16 --> Controller Class Initialized
INFO - 2024-09-20 10:54:16 --> Config Class Initialized
INFO - 2024-09-20 10:54:16 --> Hooks Class Initialized
DEBUG - 2024-09-20 10:54:16 --> UTF-8 Support Enabled
INFO - 2024-09-20 10:54:16 --> Utf8 Class Initialized
INFO - 2024-09-20 10:54:16 --> URI Class Initialized
INFO - 2024-09-20 10:54:16 --> Router Class Initialized
INFO - 2024-09-20 10:54:16 --> Output Class Initialized
INFO - 2024-09-20 10:54:16 --> Security Class Initialized
DEBUG - 2024-09-20 10:54:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-20 10:54:16 --> Input Class Initialized
INFO - 2024-09-20 10:54:16 --> Language Class Initialized
INFO - 2024-09-20 10:54:16 --> Language Class Initialized
INFO - 2024-09-20 10:54:16 --> Config Class Initialized
INFO - 2024-09-20 10:54:16 --> Loader Class Initialized
INFO - 2024-09-20 10:54:16 --> Helper loaded: url_helper
INFO - 2024-09-20 10:54:16 --> Helper loaded: file_helper
INFO - 2024-09-20 10:54:16 --> Helper loaded: form_helper
INFO - 2024-09-20 10:54:16 --> Helper loaded: my_helper
INFO - 2024-09-20 10:54:16 --> Database Driver Class Initialized
INFO - 2024-09-20 10:54:16 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-20 10:54:16 --> Controller Class Initialized
DEBUG - 2024-09-20 10:54:16 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_catatan_guru/views/list.php
DEBUG - 2024-09-20 10:54:16 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-09-20 10:54:16 --> Final output sent to browser
DEBUG - 2024-09-20 10:54:16 --> Total execution time: 0.0486
INFO - 2024-09-20 10:54:20 --> Config Class Initialized
INFO - 2024-09-20 10:54:20 --> Hooks Class Initialized
DEBUG - 2024-09-20 10:54:20 --> UTF-8 Support Enabled
INFO - 2024-09-20 10:54:20 --> Utf8 Class Initialized
INFO - 2024-09-20 10:54:20 --> URI Class Initialized
INFO - 2024-09-20 10:54:20 --> Router Class Initialized
INFO - 2024-09-20 10:54:20 --> Output Class Initialized
INFO - 2024-09-20 10:54:20 --> Security Class Initialized
DEBUG - 2024-09-20 10:54:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-20 10:54:20 --> Input Class Initialized
INFO - 2024-09-20 10:54:20 --> Language Class Initialized
INFO - 2024-09-20 10:54:20 --> Language Class Initialized
INFO - 2024-09-20 10:54:20 --> Config Class Initialized
INFO - 2024-09-20 10:54:20 --> Loader Class Initialized
INFO - 2024-09-20 10:54:20 --> Helper loaded: url_helper
INFO - 2024-09-20 10:54:20 --> Helper loaded: file_helper
INFO - 2024-09-20 10:54:20 --> Helper loaded: form_helper
INFO - 2024-09-20 10:54:20 --> Helper loaded: my_helper
INFO - 2024-09-20 10:54:20 --> Database Driver Class Initialized
INFO - 2024-09-20 10:54:20 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-20 10:54:20 --> Controller Class Initialized
INFO - 2024-09-20 10:54:20 --> Final output sent to browser
DEBUG - 2024-09-20 10:54:20 --> Total execution time: 0.0517
INFO - 2024-09-20 10:54:26 --> Config Class Initialized
INFO - 2024-09-20 10:54:26 --> Hooks Class Initialized
DEBUG - 2024-09-20 10:54:26 --> UTF-8 Support Enabled
INFO - 2024-09-20 10:54:26 --> Utf8 Class Initialized
INFO - 2024-09-20 10:54:26 --> URI Class Initialized
INFO - 2024-09-20 10:54:26 --> Router Class Initialized
INFO - 2024-09-20 10:54:26 --> Output Class Initialized
INFO - 2024-09-20 10:54:26 --> Security Class Initialized
DEBUG - 2024-09-20 10:54:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-20 10:54:26 --> Input Class Initialized
INFO - 2024-09-20 10:54:26 --> Language Class Initialized
INFO - 2024-09-20 10:54:26 --> Language Class Initialized
INFO - 2024-09-20 10:54:26 --> Config Class Initialized
INFO - 2024-09-20 10:54:26 --> Loader Class Initialized
INFO - 2024-09-20 10:54:26 --> Helper loaded: url_helper
INFO - 2024-09-20 10:54:26 --> Helper loaded: file_helper
INFO - 2024-09-20 10:54:26 --> Helper loaded: form_helper
INFO - 2024-09-20 10:54:26 --> Helper loaded: my_helper
INFO - 2024-09-20 10:54:26 --> Database Driver Class Initialized
INFO - 2024-09-20 10:54:26 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-20 10:54:26 --> Controller Class Initialized
DEBUG - 2024-09-20 10:54:26 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/view_mapel/views/v_view_mapel.php
DEBUG - 2024-09-20 10:54:26 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-09-20 10:54:26 --> Final output sent to browser
DEBUG - 2024-09-20 10:54:26 --> Total execution time: 0.0331
INFO - 2024-09-20 10:55:12 --> Config Class Initialized
INFO - 2024-09-20 10:55:12 --> Hooks Class Initialized
DEBUG - 2024-09-20 10:55:12 --> UTF-8 Support Enabled
INFO - 2024-09-20 10:55:12 --> Utf8 Class Initialized
INFO - 2024-09-20 10:55:12 --> URI Class Initialized
INFO - 2024-09-20 10:55:12 --> Router Class Initialized
INFO - 2024-09-20 10:55:12 --> Output Class Initialized
INFO - 2024-09-20 10:55:12 --> Security Class Initialized
DEBUG - 2024-09-20 10:55:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-20 10:55:12 --> Input Class Initialized
INFO - 2024-09-20 10:55:12 --> Language Class Initialized
INFO - 2024-09-20 10:55:12 --> Language Class Initialized
INFO - 2024-09-20 10:55:12 --> Config Class Initialized
INFO - 2024-09-20 10:55:12 --> Loader Class Initialized
INFO - 2024-09-20 10:55:12 --> Helper loaded: url_helper
INFO - 2024-09-20 10:55:12 --> Helper loaded: file_helper
INFO - 2024-09-20 10:55:12 --> Helper loaded: form_helper
INFO - 2024-09-20 10:55:12 --> Helper loaded: my_helper
INFO - 2024-09-20 10:55:12 --> Database Driver Class Initialized
INFO - 2024-09-20 10:55:12 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-20 10:55:12 --> Controller Class Initialized
DEBUG - 2024-09-20 10:55:12 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_catatan_guru/views/list.php
DEBUG - 2024-09-20 10:55:12 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-09-20 10:55:12 --> Final output sent to browser
DEBUG - 2024-09-20 10:55:12 --> Total execution time: 0.0322
INFO - 2024-09-20 10:55:29 --> Config Class Initialized
INFO - 2024-09-20 10:55:29 --> Hooks Class Initialized
DEBUG - 2024-09-20 10:55:29 --> UTF-8 Support Enabled
INFO - 2024-09-20 10:55:29 --> Utf8 Class Initialized
INFO - 2024-09-20 10:55:29 --> URI Class Initialized
DEBUG - 2024-09-20 10:55:29 --> No URI present. Default controller set.
INFO - 2024-09-20 10:55:29 --> Router Class Initialized
INFO - 2024-09-20 10:55:29 --> Output Class Initialized
INFO - 2024-09-20 10:55:29 --> Security Class Initialized
DEBUG - 2024-09-20 10:55:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-20 10:55:29 --> Input Class Initialized
INFO - 2024-09-20 10:55:29 --> Language Class Initialized
INFO - 2024-09-20 10:55:29 --> Language Class Initialized
INFO - 2024-09-20 10:55:29 --> Config Class Initialized
INFO - 2024-09-20 10:55:29 --> Loader Class Initialized
INFO - 2024-09-20 10:55:29 --> Helper loaded: url_helper
INFO - 2024-09-20 10:55:29 --> Helper loaded: file_helper
INFO - 2024-09-20 10:55:29 --> Helper loaded: form_helper
INFO - 2024-09-20 10:55:29 --> Helper loaded: my_helper
INFO - 2024-09-20 10:55:29 --> Database Driver Class Initialized
INFO - 2024-09-20 10:55:29 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-20 10:55:29 --> Controller Class Initialized
DEBUG - 2024-09-20 10:55:29 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/home/views/v_home_guru.php
DEBUG - 2024-09-20 10:55:29 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-09-20 10:55:29 --> Final output sent to browser
DEBUG - 2024-09-20 10:55:29 --> Total execution time: 0.0320
