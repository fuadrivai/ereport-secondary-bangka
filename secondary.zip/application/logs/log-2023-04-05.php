<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2023-04-05 08:41:32 --> Config Class Initialized
INFO - 2023-04-05 08:41:32 --> Hooks Class Initialized
DEBUG - 2023-04-05 08:41:32 --> UTF-8 Support Enabled
INFO - 2023-04-05 08:41:32 --> Utf8 Class Initialized
INFO - 2023-04-05 08:41:32 --> URI Class Initialized
DEBUG - 2023-04-05 08:41:32 --> No URI present. Default controller set.
INFO - 2023-04-05 08:41:32 --> Router Class Initialized
INFO - 2023-04-05 08:41:32 --> Output Class Initialized
INFO - 2023-04-05 08:41:32 --> Security Class Initialized
DEBUG - 2023-04-05 08:41:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-05 08:41:32 --> Input Class Initialized
INFO - 2023-04-05 08:41:32 --> Language Class Initialized
INFO - 2023-04-05 08:41:32 --> Language Class Initialized
INFO - 2023-04-05 08:41:32 --> Config Class Initialized
INFO - 2023-04-05 08:41:32 --> Loader Class Initialized
INFO - 2023-04-05 08:41:32 --> Helper loaded: url_helper
INFO - 2023-04-05 08:41:32 --> Helper loaded: file_helper
INFO - 2023-04-05 08:41:32 --> Helper loaded: form_helper
INFO - 2023-04-05 08:41:32 --> Helper loaded: my_helper
INFO - 2023-04-05 08:41:32 --> Database Driver Class Initialized
DEBUG - 2023-04-05 08:41:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-04-05 08:41:32 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-05 08:41:32 --> Controller Class Initialized
INFO - 2023-04-05 08:41:33 --> Config Class Initialized
INFO - 2023-04-05 08:41:33 --> Hooks Class Initialized
DEBUG - 2023-04-05 08:41:33 --> UTF-8 Support Enabled
INFO - 2023-04-05 08:41:33 --> Utf8 Class Initialized
INFO - 2023-04-05 08:41:33 --> URI Class Initialized
INFO - 2023-04-05 08:41:33 --> Router Class Initialized
INFO - 2023-04-05 08:41:33 --> Output Class Initialized
INFO - 2023-04-05 08:41:33 --> Security Class Initialized
DEBUG - 2023-04-05 08:41:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-05 08:41:33 --> Input Class Initialized
INFO - 2023-04-05 08:41:33 --> Language Class Initialized
INFO - 2023-04-05 08:41:33 --> Language Class Initialized
INFO - 2023-04-05 08:41:33 --> Config Class Initialized
INFO - 2023-04-05 08:41:33 --> Loader Class Initialized
INFO - 2023-04-05 08:41:33 --> Helper loaded: url_helper
INFO - 2023-04-05 08:41:33 --> Helper loaded: file_helper
INFO - 2023-04-05 08:41:33 --> Helper loaded: form_helper
INFO - 2023-04-05 08:41:33 --> Helper loaded: my_helper
INFO - 2023-04-05 08:41:33 --> Database Driver Class Initialized
DEBUG - 2023-04-05 08:41:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-04-05 08:41:33 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-05 08:41:33 --> Controller Class Initialized
DEBUG - 2023-04-05 08:41:33 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/login/views/login.php
DEBUG - 2023-04-05 08:41:33 --> File loaded: C:\xampp\htdocs\myraportk13\application\views\template_utama.php
INFO - 2023-04-05 08:41:33 --> Final output sent to browser
DEBUG - 2023-04-05 08:41:33 --> Total execution time: 0.1441
INFO - 2023-04-05 08:41:41 --> Config Class Initialized
INFO - 2023-04-05 08:41:41 --> Hooks Class Initialized
DEBUG - 2023-04-05 08:41:41 --> UTF-8 Support Enabled
INFO - 2023-04-05 08:41:41 --> Utf8 Class Initialized
INFO - 2023-04-05 08:41:41 --> URI Class Initialized
INFO - 2023-04-05 08:41:41 --> Router Class Initialized
INFO - 2023-04-05 08:41:41 --> Output Class Initialized
INFO - 2023-04-05 08:41:41 --> Security Class Initialized
DEBUG - 2023-04-05 08:41:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-05 08:41:41 --> Input Class Initialized
INFO - 2023-04-05 08:41:41 --> Language Class Initialized
INFO - 2023-04-05 08:41:41 --> Language Class Initialized
INFO - 2023-04-05 08:41:41 --> Config Class Initialized
INFO - 2023-04-05 08:41:41 --> Loader Class Initialized
INFO - 2023-04-05 08:41:41 --> Helper loaded: url_helper
INFO - 2023-04-05 08:41:41 --> Helper loaded: file_helper
INFO - 2023-04-05 08:41:41 --> Helper loaded: form_helper
INFO - 2023-04-05 08:41:41 --> Helper loaded: my_helper
INFO - 2023-04-05 08:41:41 --> Database Driver Class Initialized
DEBUG - 2023-04-05 08:41:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-04-05 08:41:41 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-05 08:41:41 --> Controller Class Initialized
INFO - 2023-04-05 08:41:41 --> Helper loaded: cookie_helper
INFO - 2023-04-05 08:41:41 --> Final output sent to browser
DEBUG - 2023-04-05 08:41:41 --> Total execution time: 0.0504
INFO - 2023-04-05 08:41:41 --> Config Class Initialized
INFO - 2023-04-05 08:41:41 --> Hooks Class Initialized
DEBUG - 2023-04-05 08:41:41 --> UTF-8 Support Enabled
INFO - 2023-04-05 08:41:41 --> Utf8 Class Initialized
INFO - 2023-04-05 08:41:41 --> URI Class Initialized
INFO - 2023-04-05 08:41:42 --> Router Class Initialized
INFO - 2023-04-05 08:41:42 --> Output Class Initialized
INFO - 2023-04-05 08:41:42 --> Security Class Initialized
DEBUG - 2023-04-05 08:41:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-05 08:41:42 --> Input Class Initialized
INFO - 2023-04-05 08:41:42 --> Language Class Initialized
INFO - 2023-04-05 08:41:42 --> Language Class Initialized
INFO - 2023-04-05 08:41:42 --> Config Class Initialized
INFO - 2023-04-05 08:41:42 --> Loader Class Initialized
INFO - 2023-04-05 08:41:42 --> Helper loaded: url_helper
INFO - 2023-04-05 08:41:42 --> Helper loaded: file_helper
INFO - 2023-04-05 08:41:42 --> Helper loaded: form_helper
INFO - 2023-04-05 08:41:42 --> Helper loaded: my_helper
INFO - 2023-04-05 08:41:42 --> Database Driver Class Initialized
DEBUG - 2023-04-05 08:41:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-04-05 08:41:42 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-05 08:41:42 --> Controller Class Initialized
DEBUG - 2023-04-05 08:41:42 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/home/views/v_home_guru.php
DEBUG - 2023-04-05 08:41:42 --> File loaded: C:\xampp\htdocs\myraportk13\application\views\template_utama.php
INFO - 2023-04-05 08:41:42 --> Final output sent to browser
DEBUG - 2023-04-05 08:41:42 --> Total execution time: 0.0606
INFO - 2023-04-05 08:41:44 --> Config Class Initialized
INFO - 2023-04-05 08:41:44 --> Hooks Class Initialized
DEBUG - 2023-04-05 08:41:44 --> UTF-8 Support Enabled
INFO - 2023-04-05 08:41:44 --> Utf8 Class Initialized
INFO - 2023-04-05 08:41:44 --> URI Class Initialized
INFO - 2023-04-05 08:41:44 --> Router Class Initialized
INFO - 2023-04-05 08:41:44 --> Output Class Initialized
INFO - 2023-04-05 08:41:44 --> Security Class Initialized
DEBUG - 2023-04-05 08:41:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-05 08:41:44 --> Input Class Initialized
INFO - 2023-04-05 08:41:44 --> Language Class Initialized
INFO - 2023-04-05 08:41:44 --> Language Class Initialized
INFO - 2023-04-05 08:41:44 --> Config Class Initialized
INFO - 2023-04-05 08:41:44 --> Loader Class Initialized
INFO - 2023-04-05 08:41:44 --> Helper loaded: url_helper
INFO - 2023-04-05 08:41:44 --> Helper loaded: file_helper
INFO - 2023-04-05 08:41:44 --> Helper loaded: form_helper
INFO - 2023-04-05 08:41:44 --> Helper loaded: my_helper
INFO - 2023-04-05 08:41:44 --> Database Driver Class Initialized
DEBUG - 2023-04-05 08:41:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-04-05 08:41:44 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-05 08:41:44 --> Controller Class Initialized
DEBUG - 2023-04-05 08:41:44 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/cetak_raport_pts/views/list.php
DEBUG - 2023-04-05 08:41:44 --> File loaded: C:\xampp\htdocs\myraportk13\application\views\template_utama.php
INFO - 2023-04-05 08:41:44 --> Final output sent to browser
DEBUG - 2023-04-05 08:41:44 --> Total execution time: 0.0573
INFO - 2023-04-05 08:41:45 --> Config Class Initialized
INFO - 2023-04-05 08:41:45 --> Hooks Class Initialized
DEBUG - 2023-04-05 08:41:45 --> UTF-8 Support Enabled
INFO - 2023-04-05 08:41:45 --> Utf8 Class Initialized
INFO - 2023-04-05 08:41:45 --> URI Class Initialized
INFO - 2023-04-05 08:41:45 --> Router Class Initialized
INFO - 2023-04-05 08:41:45 --> Output Class Initialized
INFO - 2023-04-05 08:41:45 --> Security Class Initialized
DEBUG - 2023-04-05 08:41:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-05 08:41:45 --> Input Class Initialized
INFO - 2023-04-05 08:41:45 --> Language Class Initialized
INFO - 2023-04-05 08:41:45 --> Language Class Initialized
INFO - 2023-04-05 08:41:45 --> Config Class Initialized
INFO - 2023-04-05 08:41:45 --> Loader Class Initialized
INFO - 2023-04-05 08:41:45 --> Helper loaded: url_helper
INFO - 2023-04-05 08:41:45 --> Helper loaded: file_helper
INFO - 2023-04-05 08:41:45 --> Helper loaded: form_helper
INFO - 2023-04-05 08:41:45 --> Helper loaded: my_helper
INFO - 2023-04-05 08:41:45 --> Database Driver Class Initialized
DEBUG - 2023-04-05 08:41:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-04-05 08:41:45 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-05 08:41:45 --> Controller Class Initialized
DEBUG - 2023-04-05 08:41:45 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/cetak_raport_pts/views/cetak_pts_mh.php
INFO - 2023-04-05 08:41:47 --> Config Class Initialized
INFO - 2023-04-05 08:41:47 --> Hooks Class Initialized
DEBUG - 2023-04-05 08:41:47 --> UTF-8 Support Enabled
INFO - 2023-04-05 08:41:47 --> Utf8 Class Initialized
INFO - 2023-04-05 08:41:47 --> URI Class Initialized
INFO - 2023-04-05 08:41:47 --> Router Class Initialized
INFO - 2023-04-05 08:41:47 --> Output Class Initialized
INFO - 2023-04-05 08:41:47 --> Security Class Initialized
DEBUG - 2023-04-05 08:41:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-05 08:41:47 --> Input Class Initialized
INFO - 2023-04-05 08:41:47 --> Language Class Initialized
INFO - 2023-04-05 08:41:47 --> Language Class Initialized
INFO - 2023-04-05 08:41:47 --> Config Class Initialized
INFO - 2023-04-05 08:41:47 --> Loader Class Initialized
INFO - 2023-04-05 08:41:47 --> Helper loaded: url_helper
INFO - 2023-04-05 08:41:47 --> Helper loaded: file_helper
INFO - 2023-04-05 08:41:47 --> Helper loaded: form_helper
INFO - 2023-04-05 08:41:47 --> Helper loaded: my_helper
INFO - 2023-04-05 08:41:47 --> Database Driver Class Initialized
DEBUG - 2023-04-05 08:41:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-04-05 08:41:48 --> Final output sent to browser
DEBUG - 2023-04-05 08:41:48 --> Total execution time: 2.3201
INFO - 2023-04-05 08:41:48 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-05 08:41:48 --> Controller Class Initialized
DEBUG - 2023-04-05 08:41:48 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/cetak_raport/views/list.php
DEBUG - 2023-04-05 08:41:48 --> File loaded: C:\xampp\htdocs\myraportk13\application\views\template_utama.php
INFO - 2023-04-05 08:41:48 --> Final output sent to browser
DEBUG - 2023-04-05 08:41:48 --> Total execution time: 0.7987
INFO - 2023-04-05 08:41:50 --> Config Class Initialized
INFO - 2023-04-05 08:41:50 --> Hooks Class Initialized
DEBUG - 2023-04-05 08:41:50 --> UTF-8 Support Enabled
INFO - 2023-04-05 08:41:50 --> Utf8 Class Initialized
INFO - 2023-04-05 08:41:50 --> URI Class Initialized
INFO - 2023-04-05 08:41:50 --> Router Class Initialized
INFO - 2023-04-05 08:41:50 --> Output Class Initialized
INFO - 2023-04-05 08:41:50 --> Security Class Initialized
DEBUG - 2023-04-05 08:41:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-05 08:41:50 --> Input Class Initialized
INFO - 2023-04-05 08:41:50 --> Language Class Initialized
INFO - 2023-04-05 08:41:50 --> Language Class Initialized
INFO - 2023-04-05 08:41:50 --> Config Class Initialized
INFO - 2023-04-05 08:41:50 --> Loader Class Initialized
INFO - 2023-04-05 08:41:50 --> Helper loaded: url_helper
INFO - 2023-04-05 08:41:50 --> Helper loaded: file_helper
INFO - 2023-04-05 08:41:50 --> Helper loaded: form_helper
INFO - 2023-04-05 08:41:50 --> Helper loaded: my_helper
INFO - 2023-04-05 08:41:50 --> Database Driver Class Initialized
DEBUG - 2023-04-05 08:41:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-04-05 08:41:50 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-05 08:41:50 --> Controller Class Initialized
DEBUG - 2023-04-05 08:41:50 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/cetak_raport/views/cetak_mh.php
INFO - 2023-04-05 08:41:51 --> Final output sent to browser
DEBUG - 2023-04-05 08:41:51 --> Total execution time: 1.2029
INFO - 2023-04-05 08:43:24 --> Config Class Initialized
INFO - 2023-04-05 08:43:24 --> Hooks Class Initialized
DEBUG - 2023-04-05 08:43:24 --> UTF-8 Support Enabled
INFO - 2023-04-05 08:43:24 --> Utf8 Class Initialized
INFO - 2023-04-05 08:43:24 --> URI Class Initialized
INFO - 2023-04-05 08:43:24 --> Router Class Initialized
INFO - 2023-04-05 08:43:24 --> Output Class Initialized
INFO - 2023-04-05 08:43:24 --> Security Class Initialized
DEBUG - 2023-04-05 08:43:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-05 08:43:24 --> Input Class Initialized
INFO - 2023-04-05 08:43:24 --> Language Class Initialized
INFO - 2023-04-05 08:43:24 --> Language Class Initialized
INFO - 2023-04-05 08:43:24 --> Config Class Initialized
INFO - 2023-04-05 08:43:24 --> Loader Class Initialized
INFO - 2023-04-05 08:43:24 --> Helper loaded: url_helper
INFO - 2023-04-05 08:43:24 --> Helper loaded: file_helper
INFO - 2023-04-05 08:43:24 --> Helper loaded: form_helper
INFO - 2023-04-05 08:43:24 --> Helper loaded: my_helper
INFO - 2023-04-05 08:43:24 --> Database Driver Class Initialized
DEBUG - 2023-04-05 08:43:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-04-05 08:43:24 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-05 08:43:24 --> Controller Class Initialized
DEBUG - 2023-04-05 08:43:24 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/cetak_raport_pts/views/cetak_pts_mh.php
INFO - 2023-04-05 08:43:25 --> Final output sent to browser
DEBUG - 2023-04-05 08:43:25 --> Total execution time: 1.1291
INFO - 2023-04-05 08:43:29 --> Config Class Initialized
INFO - 2023-04-05 08:43:29 --> Hooks Class Initialized
DEBUG - 2023-04-05 08:43:29 --> UTF-8 Support Enabled
INFO - 2023-04-05 08:43:29 --> Utf8 Class Initialized
INFO - 2023-04-05 08:43:29 --> URI Class Initialized
INFO - 2023-04-05 08:43:29 --> Router Class Initialized
INFO - 2023-04-05 08:43:29 --> Output Class Initialized
INFO - 2023-04-05 08:43:29 --> Security Class Initialized
DEBUG - 2023-04-05 08:43:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-05 08:43:29 --> Input Class Initialized
INFO - 2023-04-05 08:43:29 --> Language Class Initialized
INFO - 2023-04-05 08:43:29 --> Language Class Initialized
INFO - 2023-04-05 08:43:29 --> Config Class Initialized
INFO - 2023-04-05 08:43:29 --> Loader Class Initialized
INFO - 2023-04-05 08:43:29 --> Helper loaded: url_helper
INFO - 2023-04-05 08:43:29 --> Helper loaded: file_helper
INFO - 2023-04-05 08:43:29 --> Helper loaded: form_helper
INFO - 2023-04-05 08:43:29 --> Helper loaded: my_helper
INFO - 2023-04-05 08:43:29 --> Database Driver Class Initialized
DEBUG - 2023-04-05 08:43:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-04-05 08:43:29 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-05 08:43:29 --> Controller Class Initialized
DEBUG - 2023-04-05 08:43:29 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/cetak_raport/views/cetak_mh.php
INFO - 2023-04-05 08:43:30 --> Final output sent to browser
DEBUG - 2023-04-05 08:43:30 --> Total execution time: 1.1721
INFO - 2023-04-05 08:44:30 --> Config Class Initialized
INFO - 2023-04-05 08:44:30 --> Hooks Class Initialized
DEBUG - 2023-04-05 08:44:30 --> UTF-8 Support Enabled
INFO - 2023-04-05 08:44:30 --> Utf8 Class Initialized
INFO - 2023-04-05 08:44:30 --> URI Class Initialized
INFO - 2023-04-05 08:44:30 --> Router Class Initialized
INFO - 2023-04-05 08:44:30 --> Output Class Initialized
INFO - 2023-04-05 08:44:30 --> Security Class Initialized
DEBUG - 2023-04-05 08:44:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-05 08:44:30 --> Input Class Initialized
INFO - 2023-04-05 08:44:30 --> Language Class Initialized
INFO - 2023-04-05 08:44:30 --> Language Class Initialized
INFO - 2023-04-05 08:44:30 --> Config Class Initialized
INFO - 2023-04-05 08:44:30 --> Loader Class Initialized
INFO - 2023-04-05 08:44:30 --> Helper loaded: url_helper
INFO - 2023-04-05 08:44:30 --> Helper loaded: file_helper
INFO - 2023-04-05 08:44:30 --> Helper loaded: form_helper
INFO - 2023-04-05 08:44:30 --> Helper loaded: my_helper
INFO - 2023-04-05 08:44:30 --> Database Driver Class Initialized
DEBUG - 2023-04-05 08:44:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-04-05 08:44:30 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-05 08:44:30 --> Controller Class Initialized
DEBUG - 2023-04-05 08:44:30 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/cetak_raport/views/cetak_mh.php
INFO - 2023-04-05 08:44:31 --> Final output sent to browser
DEBUG - 2023-04-05 08:44:31 --> Total execution time: 1.1758
INFO - 2023-04-05 08:44:33 --> Config Class Initialized
INFO - 2023-04-05 08:44:33 --> Hooks Class Initialized
DEBUG - 2023-04-05 08:44:33 --> UTF-8 Support Enabled
INFO - 2023-04-05 08:44:33 --> Utf8 Class Initialized
INFO - 2023-04-05 08:44:33 --> URI Class Initialized
INFO - 2023-04-05 08:44:33 --> Router Class Initialized
INFO - 2023-04-05 08:44:33 --> Output Class Initialized
INFO - 2023-04-05 08:44:33 --> Security Class Initialized
DEBUG - 2023-04-05 08:44:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-05 08:44:33 --> Input Class Initialized
INFO - 2023-04-05 08:44:33 --> Language Class Initialized
INFO - 2023-04-05 08:44:33 --> Language Class Initialized
INFO - 2023-04-05 08:44:33 --> Config Class Initialized
INFO - 2023-04-05 08:44:33 --> Loader Class Initialized
INFO - 2023-04-05 08:44:33 --> Helper loaded: url_helper
INFO - 2023-04-05 08:44:33 --> Helper loaded: file_helper
INFO - 2023-04-05 08:44:33 --> Helper loaded: form_helper
INFO - 2023-04-05 08:44:33 --> Helper loaded: my_helper
INFO - 2023-04-05 08:44:33 --> Database Driver Class Initialized
DEBUG - 2023-04-05 08:44:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-04-05 08:44:33 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-05 08:44:33 --> Controller Class Initialized
DEBUG - 2023-04-05 08:44:33 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/cetak_raport_pts/views/cetak_pts_mh.php
INFO - 2023-04-05 08:44:34 --> Final output sent to browser
DEBUG - 2023-04-05 08:44:34 --> Total execution time: 1.1771
INFO - 2023-04-05 08:47:34 --> Config Class Initialized
INFO - 2023-04-05 08:47:34 --> Hooks Class Initialized
DEBUG - 2023-04-05 08:47:34 --> UTF-8 Support Enabled
INFO - 2023-04-05 08:47:34 --> Utf8 Class Initialized
INFO - 2023-04-05 08:47:34 --> URI Class Initialized
INFO - 2023-04-05 08:47:34 --> Router Class Initialized
INFO - 2023-04-05 08:47:34 --> Output Class Initialized
INFO - 2023-04-05 08:47:34 --> Security Class Initialized
DEBUG - 2023-04-05 08:47:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-05 08:47:34 --> Input Class Initialized
INFO - 2023-04-05 08:47:34 --> Language Class Initialized
INFO - 2023-04-05 08:47:34 --> Language Class Initialized
INFO - 2023-04-05 08:47:34 --> Config Class Initialized
INFO - 2023-04-05 08:47:34 --> Loader Class Initialized
INFO - 2023-04-05 08:47:34 --> Helper loaded: url_helper
INFO - 2023-04-05 08:47:34 --> Helper loaded: file_helper
INFO - 2023-04-05 08:47:34 --> Helper loaded: form_helper
INFO - 2023-04-05 08:47:34 --> Helper loaded: my_helper
INFO - 2023-04-05 08:47:34 --> Database Driver Class Initialized
DEBUG - 2023-04-05 08:47:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-04-05 08:47:34 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-05 08:47:34 --> Controller Class Initialized
DEBUG - 2023-04-05 08:47:34 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/cetak_raport_pts/views/cetak_pts_mh.php
INFO - 2023-04-05 08:47:35 --> Final output sent to browser
DEBUG - 2023-04-05 08:47:35 --> Total execution time: 1.1293
INFO - 2023-04-05 08:47:59 --> Config Class Initialized
INFO - 2023-04-05 08:47:59 --> Hooks Class Initialized
DEBUG - 2023-04-05 08:47:59 --> UTF-8 Support Enabled
INFO - 2023-04-05 08:47:59 --> Utf8 Class Initialized
INFO - 2023-04-05 08:47:59 --> URI Class Initialized
INFO - 2023-04-05 08:47:59 --> Router Class Initialized
INFO - 2023-04-05 08:47:59 --> Output Class Initialized
INFO - 2023-04-05 08:47:59 --> Security Class Initialized
DEBUG - 2023-04-05 08:47:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-05 08:47:59 --> Input Class Initialized
INFO - 2023-04-05 08:47:59 --> Language Class Initialized
INFO - 2023-04-05 08:47:59 --> Language Class Initialized
INFO - 2023-04-05 08:47:59 --> Config Class Initialized
INFO - 2023-04-05 08:47:59 --> Loader Class Initialized
INFO - 2023-04-05 08:47:59 --> Helper loaded: url_helper
INFO - 2023-04-05 08:47:59 --> Helper loaded: file_helper
INFO - 2023-04-05 08:47:59 --> Helper loaded: form_helper
INFO - 2023-04-05 08:47:59 --> Helper loaded: my_helper
INFO - 2023-04-05 08:47:59 --> Database Driver Class Initialized
DEBUG - 2023-04-05 08:47:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-04-05 08:47:59 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-05 08:47:59 --> Controller Class Initialized
DEBUG - 2023-04-05 08:47:59 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/cetak_raport/views/cetak_mh.php
INFO - 2023-04-05 08:48:00 --> Final output sent to browser
DEBUG - 2023-04-05 08:48:00 --> Total execution time: 1.1764
INFO - 2023-04-05 08:48:59 --> Config Class Initialized
INFO - 2023-04-05 08:48:59 --> Hooks Class Initialized
DEBUG - 2023-04-05 08:48:59 --> UTF-8 Support Enabled
INFO - 2023-04-05 08:48:59 --> Utf8 Class Initialized
INFO - 2023-04-05 08:48:59 --> URI Class Initialized
INFO - 2023-04-05 08:48:59 --> Router Class Initialized
INFO - 2023-04-05 08:48:59 --> Output Class Initialized
INFO - 2023-04-05 08:48:59 --> Security Class Initialized
DEBUG - 2023-04-05 08:48:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-05 08:48:59 --> Input Class Initialized
INFO - 2023-04-05 08:48:59 --> Language Class Initialized
INFO - 2023-04-05 08:48:59 --> Language Class Initialized
INFO - 2023-04-05 08:48:59 --> Config Class Initialized
INFO - 2023-04-05 08:48:59 --> Loader Class Initialized
INFO - 2023-04-05 08:48:59 --> Helper loaded: url_helper
INFO - 2023-04-05 08:48:59 --> Helper loaded: file_helper
INFO - 2023-04-05 08:48:59 --> Helper loaded: form_helper
INFO - 2023-04-05 08:48:59 --> Helper loaded: my_helper
INFO - 2023-04-05 08:48:59 --> Database Driver Class Initialized
DEBUG - 2023-04-05 08:48:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-04-05 08:48:59 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-05 08:48:59 --> Controller Class Initialized
INFO - 2023-04-05 08:48:59 --> Helper loaded: cookie_helper
INFO - 2023-04-05 08:48:59 --> Config Class Initialized
INFO - 2023-04-05 08:48:59 --> Hooks Class Initialized
DEBUG - 2023-04-05 08:48:59 --> UTF-8 Support Enabled
INFO - 2023-04-05 08:48:59 --> Utf8 Class Initialized
INFO - 2023-04-05 08:48:59 --> URI Class Initialized
INFO - 2023-04-05 08:48:59 --> Router Class Initialized
INFO - 2023-04-05 08:48:59 --> Output Class Initialized
INFO - 2023-04-05 08:48:59 --> Security Class Initialized
DEBUG - 2023-04-05 08:48:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-05 08:48:59 --> Input Class Initialized
INFO - 2023-04-05 08:48:59 --> Language Class Initialized
INFO - 2023-04-05 08:48:59 --> Language Class Initialized
INFO - 2023-04-05 08:48:59 --> Config Class Initialized
INFO - 2023-04-05 08:48:59 --> Loader Class Initialized
INFO - 2023-04-05 08:48:59 --> Helper loaded: url_helper
INFO - 2023-04-05 08:48:59 --> Helper loaded: file_helper
INFO - 2023-04-05 08:48:59 --> Helper loaded: form_helper
INFO - 2023-04-05 08:48:59 --> Helper loaded: my_helper
INFO - 2023-04-05 08:48:59 --> Database Driver Class Initialized
DEBUG - 2023-04-05 08:48:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-04-05 08:48:59 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-05 08:48:59 --> Controller Class Initialized
INFO - 2023-04-05 08:48:59 --> Config Class Initialized
INFO - 2023-04-05 08:48:59 --> Hooks Class Initialized
DEBUG - 2023-04-05 08:48:59 --> UTF-8 Support Enabled
INFO - 2023-04-05 08:48:59 --> Utf8 Class Initialized
INFO - 2023-04-05 08:48:59 --> URI Class Initialized
INFO - 2023-04-05 08:48:59 --> Router Class Initialized
INFO - 2023-04-05 08:48:59 --> Output Class Initialized
INFO - 2023-04-05 08:48:59 --> Security Class Initialized
DEBUG - 2023-04-05 08:48:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-05 08:48:59 --> Input Class Initialized
INFO - 2023-04-05 08:48:59 --> Language Class Initialized
INFO - 2023-04-05 08:48:59 --> Language Class Initialized
INFO - 2023-04-05 08:48:59 --> Config Class Initialized
INFO - 2023-04-05 08:48:59 --> Loader Class Initialized
INFO - 2023-04-05 08:48:59 --> Helper loaded: url_helper
INFO - 2023-04-05 08:48:59 --> Helper loaded: file_helper
INFO - 2023-04-05 08:48:59 --> Helper loaded: form_helper
INFO - 2023-04-05 08:48:59 --> Helper loaded: my_helper
INFO - 2023-04-05 08:48:59 --> Database Driver Class Initialized
DEBUG - 2023-04-05 08:48:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-04-05 08:48:59 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-05 08:48:59 --> Controller Class Initialized
DEBUG - 2023-04-05 08:48:59 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/login/views/login.php
DEBUG - 2023-04-05 08:48:59 --> File loaded: C:\xampp\htdocs\myraportk13\application\views\template_utama.php
INFO - 2023-04-05 08:48:59 --> Final output sent to browser
DEBUG - 2023-04-05 08:48:59 --> Total execution time: 0.0406
INFO - 2023-04-05 08:49:05 --> Config Class Initialized
INFO - 2023-04-05 08:49:05 --> Hooks Class Initialized
DEBUG - 2023-04-05 08:49:05 --> UTF-8 Support Enabled
INFO - 2023-04-05 08:49:05 --> Utf8 Class Initialized
INFO - 2023-04-05 08:49:05 --> URI Class Initialized
INFO - 2023-04-05 08:49:05 --> Router Class Initialized
INFO - 2023-04-05 08:49:05 --> Output Class Initialized
INFO - 2023-04-05 08:49:05 --> Security Class Initialized
DEBUG - 2023-04-05 08:49:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-05 08:49:05 --> Input Class Initialized
INFO - 2023-04-05 08:49:05 --> Language Class Initialized
INFO - 2023-04-05 08:49:05 --> Language Class Initialized
INFO - 2023-04-05 08:49:05 --> Config Class Initialized
INFO - 2023-04-05 08:49:05 --> Loader Class Initialized
INFO - 2023-04-05 08:49:05 --> Helper loaded: url_helper
INFO - 2023-04-05 08:49:05 --> Helper loaded: file_helper
INFO - 2023-04-05 08:49:05 --> Helper loaded: form_helper
INFO - 2023-04-05 08:49:05 --> Helper loaded: my_helper
INFO - 2023-04-05 08:49:05 --> Database Driver Class Initialized
DEBUG - 2023-04-05 08:49:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-04-05 08:49:05 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-05 08:49:05 --> Controller Class Initialized
INFO - 2023-04-05 08:49:05 --> Helper loaded: cookie_helper
INFO - 2023-04-05 08:49:05 --> Final output sent to browser
DEBUG - 2023-04-05 08:49:05 --> Total execution time: 0.0397
INFO - 2023-04-05 08:49:05 --> Config Class Initialized
INFO - 2023-04-05 08:49:05 --> Hooks Class Initialized
DEBUG - 2023-04-05 08:49:05 --> UTF-8 Support Enabled
INFO - 2023-04-05 08:49:05 --> Utf8 Class Initialized
INFO - 2023-04-05 08:49:05 --> URI Class Initialized
INFO - 2023-04-05 08:49:05 --> Router Class Initialized
INFO - 2023-04-05 08:49:05 --> Output Class Initialized
INFO - 2023-04-05 08:49:05 --> Security Class Initialized
DEBUG - 2023-04-05 08:49:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-05 08:49:05 --> Input Class Initialized
INFO - 2023-04-05 08:49:05 --> Language Class Initialized
INFO - 2023-04-05 08:49:05 --> Language Class Initialized
INFO - 2023-04-05 08:49:05 --> Config Class Initialized
INFO - 2023-04-05 08:49:05 --> Loader Class Initialized
INFO - 2023-04-05 08:49:05 --> Helper loaded: url_helper
INFO - 2023-04-05 08:49:05 --> Helper loaded: file_helper
INFO - 2023-04-05 08:49:05 --> Helper loaded: form_helper
INFO - 2023-04-05 08:49:05 --> Helper loaded: my_helper
INFO - 2023-04-05 08:49:05 --> Database Driver Class Initialized
DEBUG - 2023-04-05 08:49:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-04-05 08:49:05 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-05 08:49:05 --> Controller Class Initialized
DEBUG - 2023-04-05 08:49:05 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/home/views/v_home_guru.php
DEBUG - 2023-04-05 08:49:05 --> File loaded: C:\xampp\htdocs\myraportk13\application\views\template_utama.php
INFO - 2023-04-05 08:49:05 --> Final output sent to browser
DEBUG - 2023-04-05 08:49:05 --> Total execution time: 0.0288
INFO - 2023-04-05 08:49:07 --> Config Class Initialized
INFO - 2023-04-05 08:49:07 --> Hooks Class Initialized
DEBUG - 2023-04-05 08:49:07 --> UTF-8 Support Enabled
INFO - 2023-04-05 08:49:07 --> Utf8 Class Initialized
INFO - 2023-04-05 08:49:07 --> URI Class Initialized
INFO - 2023-04-05 08:49:07 --> Router Class Initialized
INFO - 2023-04-05 08:49:07 --> Output Class Initialized
INFO - 2023-04-05 08:49:07 --> Security Class Initialized
DEBUG - 2023-04-05 08:49:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-05 08:49:07 --> Input Class Initialized
INFO - 2023-04-05 08:49:07 --> Language Class Initialized
INFO - 2023-04-05 08:49:07 --> Language Class Initialized
INFO - 2023-04-05 08:49:07 --> Config Class Initialized
INFO - 2023-04-05 08:49:07 --> Loader Class Initialized
INFO - 2023-04-05 08:49:07 --> Helper loaded: url_helper
INFO - 2023-04-05 08:49:07 --> Helper loaded: file_helper
INFO - 2023-04-05 08:49:07 --> Helper loaded: form_helper
INFO - 2023-04-05 08:49:07 --> Helper loaded: my_helper
INFO - 2023-04-05 08:49:07 --> Database Driver Class Initialized
DEBUG - 2023-04-05 08:49:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-04-05 08:49:07 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-05 08:49:07 --> Controller Class Initialized
DEBUG - 2023-04-05 08:49:07 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/view_mapel/views/v_view_mapel.php
DEBUG - 2023-04-05 08:49:07 --> File loaded: C:\xampp\htdocs\myraportk13\application\views\template_utama.php
INFO - 2023-04-05 08:49:07 --> Final output sent to browser
DEBUG - 2023-04-05 08:49:07 --> Total execution time: 0.0916
INFO - 2023-04-05 08:49:11 --> Config Class Initialized
INFO - 2023-04-05 08:49:11 --> Hooks Class Initialized
DEBUG - 2023-04-05 08:49:11 --> UTF-8 Support Enabled
INFO - 2023-04-05 08:49:11 --> Utf8 Class Initialized
INFO - 2023-04-05 08:49:11 --> URI Class Initialized
INFO - 2023-04-05 08:49:11 --> Router Class Initialized
INFO - 2023-04-05 08:49:11 --> Output Class Initialized
INFO - 2023-04-05 08:49:11 --> Security Class Initialized
DEBUG - 2023-04-05 08:49:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-05 08:49:11 --> Input Class Initialized
INFO - 2023-04-05 08:49:11 --> Language Class Initialized
INFO - 2023-04-05 08:49:12 --> Language Class Initialized
INFO - 2023-04-05 08:49:12 --> Config Class Initialized
INFO - 2023-04-05 08:49:12 --> Loader Class Initialized
INFO - 2023-04-05 08:49:12 --> Helper loaded: url_helper
INFO - 2023-04-05 08:49:12 --> Helper loaded: file_helper
INFO - 2023-04-05 08:49:12 --> Helper loaded: form_helper
INFO - 2023-04-05 08:49:12 --> Helper loaded: my_helper
INFO - 2023-04-05 08:49:12 --> Database Driver Class Initialized
DEBUG - 2023-04-05 08:49:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-04-05 08:49:12 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-05 08:49:12 --> Controller Class Initialized
DEBUG - 2023-04-05 08:49:12 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/n_keterampilan/views/list.php
DEBUG - 2023-04-05 08:49:12 --> File loaded: C:\xampp\htdocs\myraportk13\application\views\template_utama.php
INFO - 2023-04-05 08:49:12 --> Final output sent to browser
DEBUG - 2023-04-05 08:49:12 --> Total execution time: 0.0969
INFO - 2023-04-05 08:49:16 --> Config Class Initialized
INFO - 2023-04-05 08:49:16 --> Hooks Class Initialized
DEBUG - 2023-04-05 08:49:16 --> UTF-8 Support Enabled
INFO - 2023-04-05 08:49:16 --> Utf8 Class Initialized
INFO - 2023-04-05 08:49:16 --> URI Class Initialized
INFO - 2023-04-05 08:49:16 --> Router Class Initialized
INFO - 2023-04-05 08:49:16 --> Output Class Initialized
INFO - 2023-04-05 08:49:16 --> Security Class Initialized
DEBUG - 2023-04-05 08:49:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-05 08:49:16 --> Input Class Initialized
INFO - 2023-04-05 08:49:16 --> Language Class Initialized
INFO - 2023-04-05 08:49:16 --> Language Class Initialized
INFO - 2023-04-05 08:49:16 --> Config Class Initialized
INFO - 2023-04-05 08:49:16 --> Loader Class Initialized
INFO - 2023-04-05 08:49:16 --> Helper loaded: url_helper
INFO - 2023-04-05 08:49:16 --> Helper loaded: file_helper
INFO - 2023-04-05 08:49:16 --> Helper loaded: form_helper
INFO - 2023-04-05 08:49:16 --> Helper loaded: my_helper
INFO - 2023-04-05 08:49:16 --> Database Driver Class Initialized
DEBUG - 2023-04-05 08:49:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-04-05 08:49:16 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-05 08:49:16 --> Controller Class Initialized
DEBUG - 2023-04-05 08:49:16 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/view_mapel/views/v_view_mapel.php
DEBUG - 2023-04-05 08:49:16 --> File loaded: C:\xampp\htdocs\myraportk13\application\views\template_utama.php
INFO - 2023-04-05 08:49:16 --> Final output sent to browser
DEBUG - 2023-04-05 08:49:16 --> Total execution time: 0.0303
INFO - 2023-04-05 08:49:17 --> Config Class Initialized
INFO - 2023-04-05 08:49:17 --> Hooks Class Initialized
DEBUG - 2023-04-05 08:49:17 --> UTF-8 Support Enabled
INFO - 2023-04-05 08:49:17 --> Utf8 Class Initialized
INFO - 2023-04-05 08:49:17 --> URI Class Initialized
INFO - 2023-04-05 08:49:17 --> Router Class Initialized
INFO - 2023-04-05 08:49:17 --> Output Class Initialized
INFO - 2023-04-05 08:49:17 --> Security Class Initialized
DEBUG - 2023-04-05 08:49:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-05 08:49:17 --> Input Class Initialized
INFO - 2023-04-05 08:49:17 --> Language Class Initialized
INFO - 2023-04-05 08:49:17 --> Language Class Initialized
INFO - 2023-04-05 08:49:17 --> Config Class Initialized
INFO - 2023-04-05 08:49:17 --> Loader Class Initialized
INFO - 2023-04-05 08:49:17 --> Helper loaded: url_helper
INFO - 2023-04-05 08:49:17 --> Helper loaded: file_helper
INFO - 2023-04-05 08:49:17 --> Helper loaded: form_helper
INFO - 2023-04-05 08:49:17 --> Helper loaded: my_helper
INFO - 2023-04-05 08:49:17 --> Database Driver Class Initialized
DEBUG - 2023-04-05 08:49:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-04-05 08:49:17 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-05 08:49:17 --> Controller Class Initialized
DEBUG - 2023-04-05 08:49:17 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/n_pengetahuan/views/list.php
DEBUG - 2023-04-05 08:49:17 --> File loaded: C:\xampp\htdocs\myraportk13\application\views\template_utama.php
INFO - 2023-04-05 08:49:17 --> Final output sent to browser
DEBUG - 2023-04-05 08:49:17 --> Total execution time: 0.0784
INFO - 2023-04-05 08:49:17 --> Config Class Initialized
INFO - 2023-04-05 08:49:17 --> Hooks Class Initialized
DEBUG - 2023-04-05 08:49:17 --> UTF-8 Support Enabled
INFO - 2023-04-05 08:49:17 --> Utf8 Class Initialized
INFO - 2023-04-05 08:49:17 --> URI Class Initialized
INFO - 2023-04-05 08:49:17 --> Router Class Initialized
INFO - 2023-04-05 08:49:17 --> Output Class Initialized
INFO - 2023-04-05 08:49:17 --> Security Class Initialized
DEBUG - 2023-04-05 08:49:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-05 08:49:17 --> Input Class Initialized
INFO - 2023-04-05 08:49:17 --> Language Class Initialized
INFO - 2023-04-05 08:49:17 --> Language Class Initialized
INFO - 2023-04-05 08:49:17 --> Config Class Initialized
INFO - 2023-04-05 08:49:17 --> Loader Class Initialized
INFO - 2023-04-05 08:49:17 --> Helper loaded: url_helper
INFO - 2023-04-05 08:49:17 --> Helper loaded: file_helper
INFO - 2023-04-05 08:49:17 --> Helper loaded: form_helper
INFO - 2023-04-05 08:49:17 --> Helper loaded: my_helper
INFO - 2023-04-05 08:49:17 --> Database Driver Class Initialized
DEBUG - 2023-04-05 08:49:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-04-05 08:49:17 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-05 08:49:17 --> Controller Class Initialized
INFO - 2023-04-05 08:49:48 --> Config Class Initialized
INFO - 2023-04-05 08:49:48 --> Hooks Class Initialized
DEBUG - 2023-04-05 08:49:48 --> UTF-8 Support Enabled
INFO - 2023-04-05 08:49:48 --> Utf8 Class Initialized
INFO - 2023-04-05 08:49:48 --> URI Class Initialized
INFO - 2023-04-05 08:49:48 --> Router Class Initialized
INFO - 2023-04-05 08:49:48 --> Output Class Initialized
INFO - 2023-04-05 08:49:48 --> Security Class Initialized
DEBUG - 2023-04-05 08:49:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-05 08:49:48 --> Input Class Initialized
INFO - 2023-04-05 08:49:48 --> Language Class Initialized
INFO - 2023-04-05 08:49:48 --> Language Class Initialized
INFO - 2023-04-05 08:49:48 --> Config Class Initialized
INFO - 2023-04-05 08:49:48 --> Loader Class Initialized
INFO - 2023-04-05 08:49:48 --> Helper loaded: url_helper
INFO - 2023-04-05 08:49:48 --> Helper loaded: file_helper
INFO - 2023-04-05 08:49:48 --> Helper loaded: form_helper
INFO - 2023-04-05 08:49:48 --> Helper loaded: my_helper
INFO - 2023-04-05 08:49:48 --> Database Driver Class Initialized
DEBUG - 2023-04-05 08:49:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-04-05 08:49:48 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-05 08:49:48 --> Controller Class Initialized
INFO - 2023-04-05 08:49:48 --> Final output sent to browser
DEBUG - 2023-04-05 08:49:48 --> Total execution time: 0.0425
INFO - 2023-04-05 08:49:55 --> Config Class Initialized
INFO - 2023-04-05 08:49:55 --> Hooks Class Initialized
DEBUG - 2023-04-05 08:49:55 --> UTF-8 Support Enabled
INFO - 2023-04-05 08:49:55 --> Utf8 Class Initialized
INFO - 2023-04-05 08:49:55 --> URI Class Initialized
INFO - 2023-04-05 08:49:55 --> Router Class Initialized
INFO - 2023-04-05 08:49:55 --> Output Class Initialized
INFO - 2023-04-05 08:49:55 --> Security Class Initialized
DEBUG - 2023-04-05 08:49:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-05 08:49:55 --> Input Class Initialized
INFO - 2023-04-05 08:49:55 --> Language Class Initialized
INFO - 2023-04-05 08:49:55 --> Language Class Initialized
INFO - 2023-04-05 08:49:55 --> Config Class Initialized
INFO - 2023-04-05 08:49:55 --> Loader Class Initialized
INFO - 2023-04-05 08:49:55 --> Helper loaded: url_helper
INFO - 2023-04-05 08:49:55 --> Helper loaded: file_helper
INFO - 2023-04-05 08:49:55 --> Helper loaded: form_helper
INFO - 2023-04-05 08:49:55 --> Helper loaded: my_helper
INFO - 2023-04-05 08:49:55 --> Database Driver Class Initialized
DEBUG - 2023-04-05 08:49:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-04-05 08:49:55 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-05 08:49:55 --> Controller Class Initialized
INFO - 2023-04-05 08:49:55 --> Final output sent to browser
DEBUG - 2023-04-05 08:49:55 --> Total execution time: 0.0430
INFO - 2023-04-05 08:49:56 --> Config Class Initialized
INFO - 2023-04-05 08:49:56 --> Hooks Class Initialized
DEBUG - 2023-04-05 08:49:56 --> UTF-8 Support Enabled
INFO - 2023-04-05 08:49:56 --> Utf8 Class Initialized
INFO - 2023-04-05 08:49:56 --> URI Class Initialized
INFO - 2023-04-05 08:49:56 --> Router Class Initialized
INFO - 2023-04-05 08:49:56 --> Output Class Initialized
INFO - 2023-04-05 08:49:56 --> Security Class Initialized
DEBUG - 2023-04-05 08:49:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-05 08:49:56 --> Input Class Initialized
INFO - 2023-04-05 08:49:56 --> Language Class Initialized
INFO - 2023-04-05 08:49:56 --> Language Class Initialized
INFO - 2023-04-05 08:49:56 --> Config Class Initialized
INFO - 2023-04-05 08:49:56 --> Loader Class Initialized
INFO - 2023-04-05 08:49:56 --> Helper loaded: url_helper
INFO - 2023-04-05 08:49:56 --> Helper loaded: file_helper
INFO - 2023-04-05 08:49:56 --> Helper loaded: form_helper
INFO - 2023-04-05 08:49:56 --> Helper loaded: my_helper
INFO - 2023-04-05 08:49:56 --> Database Driver Class Initialized
DEBUG - 2023-04-05 08:49:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-04-05 08:49:56 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-05 08:49:56 --> Controller Class Initialized
INFO - 2023-04-05 08:49:56 --> Final output sent to browser
DEBUG - 2023-04-05 08:49:56 --> Total execution time: 0.0285
INFO - 2023-04-05 08:49:59 --> Config Class Initialized
INFO - 2023-04-05 08:49:59 --> Hooks Class Initialized
DEBUG - 2023-04-05 08:49:59 --> UTF-8 Support Enabled
INFO - 2023-04-05 08:49:59 --> Utf8 Class Initialized
INFO - 2023-04-05 08:49:59 --> URI Class Initialized
INFO - 2023-04-05 08:49:59 --> Router Class Initialized
INFO - 2023-04-05 08:49:59 --> Output Class Initialized
INFO - 2023-04-05 08:49:59 --> Security Class Initialized
DEBUG - 2023-04-05 08:49:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-05 08:49:59 --> Input Class Initialized
INFO - 2023-04-05 08:49:59 --> Language Class Initialized
INFO - 2023-04-05 08:49:59 --> Language Class Initialized
INFO - 2023-04-05 08:49:59 --> Config Class Initialized
INFO - 2023-04-05 08:49:59 --> Loader Class Initialized
INFO - 2023-04-05 08:49:59 --> Helper loaded: url_helper
INFO - 2023-04-05 08:49:59 --> Helper loaded: file_helper
INFO - 2023-04-05 08:49:59 --> Helper loaded: form_helper
INFO - 2023-04-05 08:49:59 --> Helper loaded: my_helper
INFO - 2023-04-05 08:49:59 --> Database Driver Class Initialized
DEBUG - 2023-04-05 08:50:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-04-05 08:50:00 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-05 08:50:00 --> Controller Class Initialized
INFO - 2023-04-05 08:50:00 --> Final output sent to browser
DEBUG - 2023-04-05 08:50:00 --> Total execution time: 0.0313
INFO - 2023-04-05 08:50:03 --> Config Class Initialized
INFO - 2023-04-05 08:50:03 --> Hooks Class Initialized
DEBUG - 2023-04-05 08:50:03 --> UTF-8 Support Enabled
INFO - 2023-04-05 08:50:03 --> Utf8 Class Initialized
INFO - 2023-04-05 08:50:03 --> URI Class Initialized
INFO - 2023-04-05 08:50:03 --> Router Class Initialized
INFO - 2023-04-05 08:50:03 --> Output Class Initialized
INFO - 2023-04-05 08:50:03 --> Security Class Initialized
DEBUG - 2023-04-05 08:50:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-05 08:50:03 --> Input Class Initialized
INFO - 2023-04-05 08:50:03 --> Language Class Initialized
INFO - 2023-04-05 08:50:03 --> Language Class Initialized
INFO - 2023-04-05 08:50:03 --> Config Class Initialized
INFO - 2023-04-05 08:50:03 --> Loader Class Initialized
INFO - 2023-04-05 08:50:03 --> Helper loaded: url_helper
INFO - 2023-04-05 08:50:03 --> Helper loaded: file_helper
INFO - 2023-04-05 08:50:03 --> Helper loaded: form_helper
INFO - 2023-04-05 08:50:03 --> Helper loaded: my_helper
INFO - 2023-04-05 08:50:03 --> Database Driver Class Initialized
DEBUG - 2023-04-05 08:50:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-04-05 08:50:03 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-05 08:50:03 --> Controller Class Initialized
DEBUG - 2023-04-05 08:50:03 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/cetak_raport_pts/views/cetak_pts_mh.php
INFO - 2023-04-05 08:50:04 --> Final output sent to browser
DEBUG - 2023-04-05 08:50:04 --> Total execution time: 1.1892
INFO - 2023-04-05 08:50:05 --> Config Class Initialized
INFO - 2023-04-05 08:50:05 --> Hooks Class Initialized
DEBUG - 2023-04-05 08:50:05 --> UTF-8 Support Enabled
INFO - 2023-04-05 08:50:05 --> Utf8 Class Initialized
INFO - 2023-04-05 08:50:05 --> URI Class Initialized
INFO - 2023-04-05 08:50:05 --> Router Class Initialized
INFO - 2023-04-05 08:50:05 --> Output Class Initialized
INFO - 2023-04-05 08:50:05 --> Security Class Initialized
DEBUG - 2023-04-05 08:50:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-05 08:50:05 --> Input Class Initialized
INFO - 2023-04-05 08:50:05 --> Language Class Initialized
INFO - 2023-04-05 08:50:05 --> Language Class Initialized
INFO - 2023-04-05 08:50:05 --> Config Class Initialized
INFO - 2023-04-05 08:50:05 --> Loader Class Initialized
INFO - 2023-04-05 08:50:05 --> Helper loaded: url_helper
INFO - 2023-04-05 08:50:05 --> Helper loaded: file_helper
INFO - 2023-04-05 08:50:05 --> Helper loaded: form_helper
INFO - 2023-04-05 08:50:05 --> Helper loaded: my_helper
INFO - 2023-04-05 08:50:05 --> Database Driver Class Initialized
DEBUG - 2023-04-05 08:50:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-04-05 08:50:05 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-05 08:50:05 --> Controller Class Initialized
DEBUG - 2023-04-05 08:50:05 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/cetak_raport/views/cetak_mh.php
INFO - 2023-04-05 08:50:06 --> Final output sent to browser
DEBUG - 2023-04-05 08:50:06 --> Total execution time: 1.1562
INFO - 2023-04-05 08:50:34 --> Config Class Initialized
INFO - 2023-04-05 08:50:34 --> Hooks Class Initialized
DEBUG - 2023-04-05 08:50:34 --> UTF-8 Support Enabled
INFO - 2023-04-05 08:50:34 --> Utf8 Class Initialized
INFO - 2023-04-05 08:50:34 --> URI Class Initialized
INFO - 2023-04-05 08:50:34 --> Router Class Initialized
INFO - 2023-04-05 08:50:34 --> Output Class Initialized
INFO - 2023-04-05 08:50:34 --> Security Class Initialized
DEBUG - 2023-04-05 08:50:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-05 08:50:34 --> Input Class Initialized
INFO - 2023-04-05 08:50:34 --> Language Class Initialized
INFO - 2023-04-05 08:50:34 --> Language Class Initialized
INFO - 2023-04-05 08:50:34 --> Config Class Initialized
INFO - 2023-04-05 08:50:34 --> Loader Class Initialized
INFO - 2023-04-05 08:50:34 --> Helper loaded: url_helper
INFO - 2023-04-05 08:50:34 --> Helper loaded: file_helper
INFO - 2023-04-05 08:50:34 --> Helper loaded: form_helper
INFO - 2023-04-05 08:50:34 --> Helper loaded: my_helper
INFO - 2023-04-05 08:50:34 --> Database Driver Class Initialized
DEBUG - 2023-04-05 08:50:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-04-05 08:50:34 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-05 08:50:34 --> Controller Class Initialized
INFO - 2023-04-05 08:50:34 --> Final output sent to browser
DEBUG - 2023-04-05 08:50:34 --> Total execution time: 0.0400
INFO - 2023-04-05 08:50:35 --> Config Class Initialized
INFO - 2023-04-05 08:50:35 --> Hooks Class Initialized
DEBUG - 2023-04-05 08:50:35 --> UTF-8 Support Enabled
INFO - 2023-04-05 08:50:35 --> Utf8 Class Initialized
INFO - 2023-04-05 08:50:35 --> URI Class Initialized
INFO - 2023-04-05 08:50:35 --> Router Class Initialized
INFO - 2023-04-05 08:50:35 --> Output Class Initialized
INFO - 2023-04-05 08:50:35 --> Security Class Initialized
DEBUG - 2023-04-05 08:50:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-05 08:50:35 --> Input Class Initialized
INFO - 2023-04-05 08:50:35 --> Language Class Initialized
INFO - 2023-04-05 08:50:35 --> Language Class Initialized
INFO - 2023-04-05 08:50:35 --> Config Class Initialized
INFO - 2023-04-05 08:50:35 --> Loader Class Initialized
INFO - 2023-04-05 08:50:35 --> Helper loaded: url_helper
INFO - 2023-04-05 08:50:35 --> Helper loaded: file_helper
INFO - 2023-04-05 08:50:35 --> Helper loaded: form_helper
INFO - 2023-04-05 08:50:35 --> Helper loaded: my_helper
INFO - 2023-04-05 08:50:35 --> Database Driver Class Initialized
DEBUG - 2023-04-05 08:50:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-04-05 08:50:35 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-05 08:50:35 --> Controller Class Initialized
INFO - 2023-04-05 08:50:35 --> Final output sent to browser
DEBUG - 2023-04-05 08:50:35 --> Total execution time: 0.0485
INFO - 2023-04-05 08:51:12 --> Config Class Initialized
INFO - 2023-04-05 08:51:12 --> Hooks Class Initialized
DEBUG - 2023-04-05 08:51:12 --> UTF-8 Support Enabled
INFO - 2023-04-05 08:51:12 --> Utf8 Class Initialized
INFO - 2023-04-05 08:51:12 --> URI Class Initialized
INFO - 2023-04-05 08:51:12 --> Router Class Initialized
INFO - 2023-04-05 08:51:12 --> Output Class Initialized
INFO - 2023-04-05 08:51:12 --> Security Class Initialized
DEBUG - 2023-04-05 08:51:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-05 08:51:12 --> Input Class Initialized
INFO - 2023-04-05 08:51:12 --> Language Class Initialized
INFO - 2023-04-05 08:51:12 --> Language Class Initialized
INFO - 2023-04-05 08:51:12 --> Config Class Initialized
INFO - 2023-04-05 08:51:12 --> Loader Class Initialized
INFO - 2023-04-05 08:51:12 --> Helper loaded: url_helper
INFO - 2023-04-05 08:51:12 --> Helper loaded: file_helper
INFO - 2023-04-05 08:51:12 --> Helper loaded: form_helper
INFO - 2023-04-05 08:51:12 --> Helper loaded: my_helper
INFO - 2023-04-05 08:51:12 --> Database Driver Class Initialized
DEBUG - 2023-04-05 08:51:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-04-05 08:51:12 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-05 08:51:12 --> Controller Class Initialized
INFO - 2023-04-05 08:51:12 --> Final output sent to browser
DEBUG - 2023-04-05 08:51:12 --> Total execution time: 0.0455
INFO - 2023-04-05 08:53:56 --> Config Class Initialized
INFO - 2023-04-05 08:53:56 --> Hooks Class Initialized
DEBUG - 2023-04-05 08:53:56 --> UTF-8 Support Enabled
INFO - 2023-04-05 08:53:56 --> Utf8 Class Initialized
INFO - 2023-04-05 08:53:56 --> URI Class Initialized
INFO - 2023-04-05 08:53:56 --> Router Class Initialized
INFO - 2023-04-05 08:53:56 --> Output Class Initialized
INFO - 2023-04-05 08:53:56 --> Security Class Initialized
DEBUG - 2023-04-05 08:53:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-05 08:53:56 --> Input Class Initialized
INFO - 2023-04-05 08:53:56 --> Language Class Initialized
INFO - 2023-04-05 08:53:56 --> Language Class Initialized
INFO - 2023-04-05 08:53:56 --> Config Class Initialized
INFO - 2023-04-05 08:53:56 --> Loader Class Initialized
INFO - 2023-04-05 08:53:56 --> Helper loaded: url_helper
INFO - 2023-04-05 08:53:56 --> Helper loaded: file_helper
INFO - 2023-04-05 08:53:56 --> Helper loaded: form_helper
INFO - 2023-04-05 08:53:56 --> Helper loaded: my_helper
INFO - 2023-04-05 08:53:56 --> Database Driver Class Initialized
DEBUG - 2023-04-05 08:53:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-04-05 08:53:56 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-05 08:53:56 --> Controller Class Initialized
INFO - 2023-04-05 08:53:56 --> Final output sent to browser
DEBUG - 2023-04-05 08:53:56 --> Total execution time: 0.0268
INFO - 2023-04-05 08:53:58 --> Config Class Initialized
INFO - 2023-04-05 08:53:58 --> Hooks Class Initialized
DEBUG - 2023-04-05 08:53:58 --> UTF-8 Support Enabled
INFO - 2023-04-05 08:53:58 --> Utf8 Class Initialized
INFO - 2023-04-05 08:53:58 --> URI Class Initialized
INFO - 2023-04-05 08:53:58 --> Router Class Initialized
INFO - 2023-04-05 08:53:58 --> Output Class Initialized
INFO - 2023-04-05 08:53:58 --> Security Class Initialized
DEBUG - 2023-04-05 08:53:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-05 08:53:58 --> Input Class Initialized
INFO - 2023-04-05 08:53:58 --> Language Class Initialized
INFO - 2023-04-05 08:53:58 --> Language Class Initialized
INFO - 2023-04-05 08:53:58 --> Config Class Initialized
INFO - 2023-04-05 08:53:58 --> Loader Class Initialized
INFO - 2023-04-05 08:53:58 --> Helper loaded: url_helper
INFO - 2023-04-05 08:53:58 --> Helper loaded: file_helper
INFO - 2023-04-05 08:53:58 --> Helper loaded: form_helper
INFO - 2023-04-05 08:53:58 --> Helper loaded: my_helper
INFO - 2023-04-05 08:53:58 --> Database Driver Class Initialized
DEBUG - 2023-04-05 08:53:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-04-05 08:53:58 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-05 08:53:58 --> Controller Class Initialized
INFO - 2023-04-05 08:53:58 --> Final output sent to browser
DEBUG - 2023-04-05 08:53:58 --> Total execution time: 0.0444
INFO - 2023-04-05 08:53:59 --> Config Class Initialized
INFO - 2023-04-05 08:53:59 --> Hooks Class Initialized
DEBUG - 2023-04-05 08:53:59 --> UTF-8 Support Enabled
INFO - 2023-04-05 08:53:59 --> Utf8 Class Initialized
INFO - 2023-04-05 08:53:59 --> URI Class Initialized
INFO - 2023-04-05 08:53:59 --> Router Class Initialized
INFO - 2023-04-05 08:53:59 --> Output Class Initialized
INFO - 2023-04-05 08:53:59 --> Security Class Initialized
DEBUG - 2023-04-05 08:53:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-05 08:53:59 --> Input Class Initialized
INFO - 2023-04-05 08:53:59 --> Language Class Initialized
INFO - 2023-04-05 08:53:59 --> Language Class Initialized
INFO - 2023-04-05 08:53:59 --> Config Class Initialized
INFO - 2023-04-05 08:53:59 --> Loader Class Initialized
INFO - 2023-04-05 08:53:59 --> Helper loaded: url_helper
INFO - 2023-04-05 08:53:59 --> Helper loaded: file_helper
INFO - 2023-04-05 08:53:59 --> Helper loaded: form_helper
INFO - 2023-04-05 08:53:59 --> Helper loaded: my_helper
INFO - 2023-04-05 08:53:59 --> Database Driver Class Initialized
DEBUG - 2023-04-05 08:53:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-04-05 08:53:59 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-05 08:53:59 --> Controller Class Initialized
INFO - 2023-04-05 08:53:59 --> Final output sent to browser
DEBUG - 2023-04-05 08:53:59 --> Total execution time: 0.0255
INFO - 2023-04-05 08:56:28 --> Config Class Initialized
INFO - 2023-04-05 08:56:28 --> Hooks Class Initialized
DEBUG - 2023-04-05 08:56:28 --> UTF-8 Support Enabled
INFO - 2023-04-05 08:56:28 --> Utf8 Class Initialized
INFO - 2023-04-05 08:56:28 --> URI Class Initialized
INFO - 2023-04-05 08:56:28 --> Router Class Initialized
INFO - 2023-04-05 08:56:28 --> Output Class Initialized
INFO - 2023-04-05 08:56:28 --> Security Class Initialized
DEBUG - 2023-04-05 08:56:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-05 08:56:28 --> Input Class Initialized
INFO - 2023-04-05 08:56:28 --> Language Class Initialized
INFO - 2023-04-05 08:56:28 --> Language Class Initialized
INFO - 2023-04-05 08:56:28 --> Config Class Initialized
INFO - 2023-04-05 08:56:28 --> Loader Class Initialized
INFO - 2023-04-05 08:56:28 --> Helper loaded: url_helper
INFO - 2023-04-05 08:56:28 --> Helper loaded: file_helper
INFO - 2023-04-05 08:56:28 --> Helper loaded: form_helper
INFO - 2023-04-05 08:56:28 --> Helper loaded: my_helper
INFO - 2023-04-05 08:56:28 --> Database Driver Class Initialized
DEBUG - 2023-04-05 08:56:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-04-05 08:56:28 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-05 08:56:28 --> Controller Class Initialized
ERROR - 2023-04-05 08:56:28 --> Severity: Notice --> Undefined variable: kkmx C:\xampp\htdocs\myraportk13\application\modules\cetak_raport_pts\controllers\Cetak_raport_pts.php 206
ERROR - 2023-04-05 08:56:28 --> Severity: Notice --> Undefined variable: lang_mapel C:\xampp\htdocs\myraportk13\application\modules\cetak_raport_pts\controllers\Cetak_raport_pts.php 207
ERROR - 2023-04-05 08:56:28 --> Severity: Notice --> Undefined variable: kkmx C:\xampp\htdocs\myraportk13\application\modules\cetak_raport_pts\controllers\Cetak_raport_pts.php 341
ERROR - 2023-04-05 08:56:28 --> Severity: Notice --> Undefined variable: lang_mapel C:\xampp\htdocs\myraportk13\application\modules\cetak_raport_pts\controllers\Cetak_raport_pts.php 341
ERROR - 2023-04-05 08:56:28 --> Severity: Notice --> Undefined variable: kkmx C:\xampp\htdocs\myraportk13\application\modules\cetak_raport_pts\controllers\Cetak_raport_pts.php 342
ERROR - 2023-04-05 08:56:28 --> Severity: Notice --> Undefined variable: lang_mapel C:\xampp\htdocs\myraportk13\application\modules\cetak_raport_pts\controllers\Cetak_raport_pts.php 343
ERROR - 2023-04-05 08:56:28 --> Severity: Notice --> Undefined variable: kkmx C:\xampp\htdocs\myraportk13\application\modules\cetak_raport_pts\controllers\Cetak_raport_pts.php 397
ERROR - 2023-04-05 08:56:28 --> Severity: Notice --> Undefined variable: kkmx C:\xampp\htdocs\myraportk13\application\modules\cetak_raport_pts\controllers\Cetak_raport_pts.php 397
ERROR - 2023-04-05 08:56:28 --> Severity: Notice --> Undefined variable: kkmx C:\xampp\htdocs\myraportk13\application\modules\cetak_raport_pts\controllers\Cetak_raport_pts.php 397
ERROR - 2023-04-05 08:56:28 --> Severity: Notice --> Undefined variable: kkmx C:\xampp\htdocs\myraportk13\application\modules\cetak_raport_pts\controllers\Cetak_raport_pts.php 397
ERROR - 2023-04-05 08:56:28 --> Severity: Notice --> Undefined variable: kkmx C:\xampp\htdocs\myraportk13\application\modules\cetak_raport_pts\controllers\Cetak_raport_pts.php 397
ERROR - 2023-04-05 08:56:28 --> Severity: Notice --> Undefined variable: kkmx C:\xampp\htdocs\myraportk13\application\modules\cetak_raport_pts\controllers\Cetak_raport_pts.php 397
ERROR - 2023-04-05 08:56:28 --> Severity: Notice --> Undefined variable: kkmx C:\xampp\htdocs\myraportk13\application\modules\cetak_raport_pts\controllers\Cetak_raport_pts.php 397
ERROR - 2023-04-05 08:56:28 --> Severity: Notice --> Undefined variable: lang_mapel C:\xampp\htdocs\myraportk13\application\modules\cetak_raport_pts\controllers\Cetak_raport_pts.php 735
ERROR - 2023-04-05 08:56:28 --> Severity: Notice --> Undefined variable: lang_mapel C:\xampp\htdocs\myraportk13\application\modules\cetak_raport_pts\controllers\Cetak_raport_pts.php 738
ERROR - 2023-04-05 08:56:28 --> Severity: Notice --> Undefined variable: lang_mapel C:\xampp\htdocs\myraportk13\application\modules\cetak_raport_pts\controllers\Cetak_raport_pts.php 972
DEBUG - 2023-04-05 08:56:28 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/cetak_raport_pts/views/cetak_pts_mh.php
INFO - 2023-04-05 08:56:29 --> Final output sent to browser
DEBUG - 2023-04-05 08:56:29 --> Total execution time: 1.3088
INFO - 2023-04-05 08:57:30 --> Config Class Initialized
INFO - 2023-04-05 08:57:30 --> Hooks Class Initialized
DEBUG - 2023-04-05 08:57:30 --> UTF-8 Support Enabled
INFO - 2023-04-05 08:57:30 --> Utf8 Class Initialized
INFO - 2023-04-05 08:57:30 --> URI Class Initialized
INFO - 2023-04-05 08:57:30 --> Router Class Initialized
INFO - 2023-04-05 08:57:30 --> Output Class Initialized
INFO - 2023-04-05 08:57:30 --> Security Class Initialized
DEBUG - 2023-04-05 08:57:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-05 08:57:30 --> Input Class Initialized
INFO - 2023-04-05 08:57:30 --> Language Class Initialized
INFO - 2023-04-05 08:57:30 --> Language Class Initialized
INFO - 2023-04-05 08:57:30 --> Config Class Initialized
INFO - 2023-04-05 08:57:30 --> Loader Class Initialized
INFO - 2023-04-05 08:57:30 --> Helper loaded: url_helper
INFO - 2023-04-05 08:57:30 --> Helper loaded: file_helper
INFO - 2023-04-05 08:57:30 --> Helper loaded: form_helper
INFO - 2023-04-05 08:57:30 --> Helper loaded: my_helper
INFO - 2023-04-05 08:57:30 --> Database Driver Class Initialized
DEBUG - 2023-04-05 08:57:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-04-05 08:57:30 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-05 08:57:30 --> Controller Class Initialized
DEBUG - 2023-04-05 08:57:30 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/cetak_raport_pts/views/cetak_pts_mh.php
INFO - 2023-04-05 08:57:31 --> Final output sent to browser
DEBUG - 2023-04-05 08:57:31 --> Total execution time: 1.1653
INFO - 2023-04-05 08:57:40 --> Config Class Initialized
INFO - 2023-04-05 08:57:40 --> Hooks Class Initialized
DEBUG - 2023-04-05 08:57:40 --> UTF-8 Support Enabled
INFO - 2023-04-05 08:57:40 --> Utf8 Class Initialized
INFO - 2023-04-05 08:57:40 --> URI Class Initialized
INFO - 2023-04-05 08:57:40 --> Router Class Initialized
INFO - 2023-04-05 08:57:40 --> Output Class Initialized
INFO - 2023-04-05 08:57:40 --> Security Class Initialized
DEBUG - 2023-04-05 08:57:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-05 08:57:40 --> Input Class Initialized
INFO - 2023-04-05 08:57:40 --> Language Class Initialized
INFO - 2023-04-05 08:57:40 --> Language Class Initialized
INFO - 2023-04-05 08:57:40 --> Config Class Initialized
INFO - 2023-04-05 08:57:40 --> Loader Class Initialized
INFO - 2023-04-05 08:57:40 --> Helper loaded: url_helper
INFO - 2023-04-05 08:57:40 --> Helper loaded: file_helper
INFO - 2023-04-05 08:57:40 --> Helper loaded: form_helper
INFO - 2023-04-05 08:57:40 --> Helper loaded: my_helper
INFO - 2023-04-05 08:57:40 --> Database Driver Class Initialized
DEBUG - 2023-04-05 08:57:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-04-05 08:57:40 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-05 08:57:40 --> Controller Class Initialized
INFO - 2023-04-05 08:57:40 --> Final output sent to browser
DEBUG - 2023-04-05 08:57:40 --> Total execution time: 0.0472
INFO - 2023-04-05 08:58:14 --> Config Class Initialized
INFO - 2023-04-05 08:58:14 --> Hooks Class Initialized
DEBUG - 2023-04-05 08:58:14 --> UTF-8 Support Enabled
INFO - 2023-04-05 08:58:14 --> Utf8 Class Initialized
INFO - 2023-04-05 08:58:14 --> URI Class Initialized
INFO - 2023-04-05 08:58:14 --> Router Class Initialized
INFO - 2023-04-05 08:58:14 --> Output Class Initialized
INFO - 2023-04-05 08:58:14 --> Security Class Initialized
DEBUG - 2023-04-05 08:58:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-05 08:58:14 --> Input Class Initialized
INFO - 2023-04-05 08:58:14 --> Language Class Initialized
INFO - 2023-04-05 08:58:14 --> Language Class Initialized
INFO - 2023-04-05 08:58:14 --> Config Class Initialized
INFO - 2023-04-05 08:58:14 --> Loader Class Initialized
INFO - 2023-04-05 08:58:14 --> Helper loaded: url_helper
INFO - 2023-04-05 08:58:14 --> Helper loaded: file_helper
INFO - 2023-04-05 08:58:14 --> Helper loaded: form_helper
INFO - 2023-04-05 08:58:14 --> Helper loaded: my_helper
INFO - 2023-04-05 08:58:14 --> Database Driver Class Initialized
DEBUG - 2023-04-05 08:58:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-04-05 08:58:14 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-05 08:58:14 --> Controller Class Initialized
DEBUG - 2023-04-05 08:58:14 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/cetak_raport_pts/views/cetak_pts_mh.php
INFO - 2023-04-05 08:58:15 --> Final output sent to browser
DEBUG - 2023-04-05 08:58:15 --> Total execution time: 1.1838
INFO - 2023-04-05 08:58:33 --> Config Class Initialized
INFO - 2023-04-05 08:58:33 --> Hooks Class Initialized
DEBUG - 2023-04-05 08:58:33 --> UTF-8 Support Enabled
INFO - 2023-04-05 08:58:33 --> Utf8 Class Initialized
INFO - 2023-04-05 08:58:33 --> URI Class Initialized
INFO - 2023-04-05 08:58:33 --> Router Class Initialized
INFO - 2023-04-05 08:58:33 --> Output Class Initialized
INFO - 2023-04-05 08:58:33 --> Security Class Initialized
DEBUG - 2023-04-05 08:58:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-05 08:58:33 --> Input Class Initialized
INFO - 2023-04-05 08:58:33 --> Language Class Initialized
INFO - 2023-04-05 08:58:33 --> Language Class Initialized
INFO - 2023-04-05 08:58:33 --> Config Class Initialized
INFO - 2023-04-05 08:58:33 --> Loader Class Initialized
INFO - 2023-04-05 08:58:33 --> Helper loaded: url_helper
INFO - 2023-04-05 08:58:33 --> Helper loaded: file_helper
INFO - 2023-04-05 08:58:33 --> Helper loaded: form_helper
INFO - 2023-04-05 08:58:33 --> Helper loaded: my_helper
INFO - 2023-04-05 08:58:33 --> Database Driver Class Initialized
DEBUG - 2023-04-05 08:58:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-04-05 08:58:33 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-05 08:58:33 --> Controller Class Initialized
DEBUG - 2023-04-05 08:58:33 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/cetak_raport_pts/views/cetak_pts_mh.php
INFO - 2023-04-05 08:58:34 --> Final output sent to browser
DEBUG - 2023-04-05 08:58:34 --> Total execution time: 1.1323
INFO - 2023-04-05 08:58:44 --> Config Class Initialized
INFO - 2023-04-05 08:58:44 --> Hooks Class Initialized
DEBUG - 2023-04-05 08:58:44 --> UTF-8 Support Enabled
INFO - 2023-04-05 08:58:44 --> Utf8 Class Initialized
INFO - 2023-04-05 08:58:44 --> URI Class Initialized
INFO - 2023-04-05 08:58:44 --> Router Class Initialized
INFO - 2023-04-05 08:58:44 --> Output Class Initialized
INFO - 2023-04-05 08:58:44 --> Security Class Initialized
DEBUG - 2023-04-05 08:58:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-05 08:58:44 --> Input Class Initialized
INFO - 2023-04-05 08:58:44 --> Language Class Initialized
INFO - 2023-04-05 08:58:44 --> Language Class Initialized
INFO - 2023-04-05 08:58:44 --> Config Class Initialized
INFO - 2023-04-05 08:58:44 --> Loader Class Initialized
INFO - 2023-04-05 08:58:44 --> Helper loaded: url_helper
INFO - 2023-04-05 08:58:44 --> Helper loaded: file_helper
INFO - 2023-04-05 08:58:44 --> Helper loaded: form_helper
INFO - 2023-04-05 08:58:44 --> Helper loaded: my_helper
INFO - 2023-04-05 08:58:44 --> Database Driver Class Initialized
DEBUG - 2023-04-05 08:58:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-04-05 08:58:44 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-05 08:58:44 --> Controller Class Initialized
DEBUG - 2023-04-05 08:58:44 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/view_mapel/views/v_view_mapel.php
DEBUG - 2023-04-05 08:58:44 --> File loaded: C:\xampp\htdocs\myraportk13\application\views\template_utama.php
INFO - 2023-04-05 08:58:44 --> Final output sent to browser
DEBUG - 2023-04-05 08:58:44 --> Total execution time: 0.0332
INFO - 2023-04-05 08:58:46 --> Config Class Initialized
INFO - 2023-04-05 08:58:46 --> Hooks Class Initialized
DEBUG - 2023-04-05 08:58:46 --> UTF-8 Support Enabled
INFO - 2023-04-05 08:58:46 --> Utf8 Class Initialized
INFO - 2023-04-05 08:58:46 --> URI Class Initialized
INFO - 2023-04-05 08:58:46 --> Router Class Initialized
INFO - 2023-04-05 08:58:46 --> Output Class Initialized
INFO - 2023-04-05 08:58:46 --> Security Class Initialized
DEBUG - 2023-04-05 08:58:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-05 08:58:46 --> Input Class Initialized
INFO - 2023-04-05 08:58:46 --> Language Class Initialized
INFO - 2023-04-05 08:58:46 --> Language Class Initialized
INFO - 2023-04-05 08:58:46 --> Config Class Initialized
INFO - 2023-04-05 08:58:46 --> Loader Class Initialized
INFO - 2023-04-05 08:58:46 --> Helper loaded: url_helper
INFO - 2023-04-05 08:58:46 --> Helper loaded: file_helper
INFO - 2023-04-05 08:58:46 --> Helper loaded: form_helper
INFO - 2023-04-05 08:58:46 --> Helper loaded: my_helper
INFO - 2023-04-05 08:58:46 --> Database Driver Class Initialized
DEBUG - 2023-04-05 08:58:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-04-05 08:58:46 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-05 08:58:46 --> Controller Class Initialized
DEBUG - 2023-04-05 08:58:46 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/n_keterampilan/views/list.php
DEBUG - 2023-04-05 08:58:46 --> File loaded: C:\xampp\htdocs\myraportk13\application\views\template_utama.php
INFO - 2023-04-05 08:58:46 --> Final output sent to browser
DEBUG - 2023-04-05 08:58:46 --> Total execution time: 0.0371
INFO - 2023-04-05 08:58:47 --> Config Class Initialized
INFO - 2023-04-05 08:58:47 --> Hooks Class Initialized
DEBUG - 2023-04-05 08:58:47 --> UTF-8 Support Enabled
INFO - 2023-04-05 08:58:47 --> Utf8 Class Initialized
INFO - 2023-04-05 08:58:47 --> URI Class Initialized
INFO - 2023-04-05 08:58:47 --> Router Class Initialized
INFO - 2023-04-05 08:58:47 --> Output Class Initialized
INFO - 2023-04-05 08:58:47 --> Security Class Initialized
DEBUG - 2023-04-05 08:58:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-05 08:58:47 --> Input Class Initialized
INFO - 2023-04-05 08:58:47 --> Language Class Initialized
INFO - 2023-04-05 08:58:47 --> Language Class Initialized
INFO - 2023-04-05 08:58:47 --> Config Class Initialized
INFO - 2023-04-05 08:58:47 --> Loader Class Initialized
INFO - 2023-04-05 08:58:47 --> Helper loaded: url_helper
INFO - 2023-04-05 08:58:47 --> Helper loaded: file_helper
INFO - 2023-04-05 08:58:47 --> Helper loaded: form_helper
INFO - 2023-04-05 08:58:47 --> Helper loaded: my_helper
INFO - 2023-04-05 08:58:47 --> Database Driver Class Initialized
DEBUG - 2023-04-05 08:58:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-04-05 08:58:47 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-05 08:58:47 --> Controller Class Initialized
INFO - 2023-04-05 08:58:47 --> Final output sent to browser
DEBUG - 2023-04-05 08:58:47 --> Total execution time: 0.0256
INFO - 2023-04-05 09:00:59 --> Config Class Initialized
INFO - 2023-04-05 09:00:59 --> Hooks Class Initialized
DEBUG - 2023-04-05 09:00:59 --> UTF-8 Support Enabled
INFO - 2023-04-05 09:00:59 --> Utf8 Class Initialized
INFO - 2023-04-05 09:00:59 --> URI Class Initialized
INFO - 2023-04-05 09:00:59 --> Router Class Initialized
INFO - 2023-04-05 09:00:59 --> Output Class Initialized
INFO - 2023-04-05 09:00:59 --> Security Class Initialized
DEBUG - 2023-04-05 09:00:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-05 09:00:59 --> Input Class Initialized
INFO - 2023-04-05 09:00:59 --> Language Class Initialized
INFO - 2023-04-05 09:00:59 --> Language Class Initialized
INFO - 2023-04-05 09:00:59 --> Config Class Initialized
INFO - 2023-04-05 09:00:59 --> Loader Class Initialized
INFO - 2023-04-05 09:00:59 --> Helper loaded: url_helper
INFO - 2023-04-05 09:00:59 --> Helper loaded: file_helper
INFO - 2023-04-05 09:00:59 --> Helper loaded: form_helper
INFO - 2023-04-05 09:00:59 --> Helper loaded: my_helper
INFO - 2023-04-05 09:00:59 --> Database Driver Class Initialized
DEBUG - 2023-04-05 09:00:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-04-05 09:00:59 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-05 09:00:59 --> Controller Class Initialized
DEBUG - 2023-04-05 09:00:59 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/cetak_raport_pts/views/cetak_pts_mh.php
INFO - 2023-04-05 09:01:01 --> Final output sent to browser
DEBUG - 2023-04-05 09:01:01 --> Total execution time: 1.1114
INFO - 2023-04-05 09:11:05 --> Config Class Initialized
INFO - 2023-04-05 09:11:05 --> Hooks Class Initialized
DEBUG - 2023-04-05 09:11:05 --> UTF-8 Support Enabled
INFO - 2023-04-05 09:11:05 --> Utf8 Class Initialized
INFO - 2023-04-05 09:11:05 --> URI Class Initialized
INFO - 2023-04-05 09:11:05 --> Router Class Initialized
INFO - 2023-04-05 09:11:05 --> Output Class Initialized
INFO - 2023-04-05 09:11:05 --> Security Class Initialized
DEBUG - 2023-04-05 09:11:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-05 09:11:05 --> Input Class Initialized
INFO - 2023-04-05 09:11:05 --> Language Class Initialized
INFO - 2023-04-05 09:11:05 --> Language Class Initialized
INFO - 2023-04-05 09:11:05 --> Config Class Initialized
INFO - 2023-04-05 09:11:05 --> Loader Class Initialized
INFO - 2023-04-05 09:11:05 --> Helper loaded: url_helper
INFO - 2023-04-05 09:11:05 --> Helper loaded: file_helper
INFO - 2023-04-05 09:11:05 --> Helper loaded: form_helper
INFO - 2023-04-05 09:11:05 --> Helper loaded: my_helper
INFO - 2023-04-05 09:11:05 --> Database Driver Class Initialized
DEBUG - 2023-04-05 09:11:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-04-05 09:11:05 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-05 09:11:05 --> Controller Class Initialized
DEBUG - 2023-04-05 09:11:05 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/view_mapel/views/v_view_mapel.php
DEBUG - 2023-04-05 09:11:05 --> File loaded: C:\xampp\htdocs\myraportk13\application\views\template_utama.php
INFO - 2023-04-05 09:11:05 --> Final output sent to browser
DEBUG - 2023-04-05 09:11:05 --> Total execution time: 0.0383
INFO - 2023-04-05 09:11:08 --> Config Class Initialized
INFO - 2023-04-05 09:11:08 --> Hooks Class Initialized
DEBUG - 2023-04-05 09:11:08 --> UTF-8 Support Enabled
INFO - 2023-04-05 09:11:08 --> Utf8 Class Initialized
INFO - 2023-04-05 09:11:08 --> URI Class Initialized
INFO - 2023-04-05 09:11:08 --> Router Class Initialized
INFO - 2023-04-05 09:11:08 --> Output Class Initialized
INFO - 2023-04-05 09:11:08 --> Security Class Initialized
DEBUG - 2023-04-05 09:11:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-05 09:11:08 --> Input Class Initialized
INFO - 2023-04-05 09:11:08 --> Language Class Initialized
INFO - 2023-04-05 09:11:08 --> Language Class Initialized
INFO - 2023-04-05 09:11:08 --> Config Class Initialized
INFO - 2023-04-05 09:11:08 --> Loader Class Initialized
INFO - 2023-04-05 09:11:08 --> Helper loaded: url_helper
INFO - 2023-04-05 09:11:08 --> Helper loaded: file_helper
INFO - 2023-04-05 09:11:08 --> Helper loaded: form_helper
INFO - 2023-04-05 09:11:08 --> Helper loaded: my_helper
INFO - 2023-04-05 09:11:08 --> Database Driver Class Initialized
DEBUG - 2023-04-05 09:11:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-04-05 09:11:08 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-05 09:11:08 --> Controller Class Initialized
INFO - 2023-04-05 09:11:08 --> Helper loaded: cookie_helper
INFO - 2023-04-05 09:11:08 --> Config Class Initialized
INFO - 2023-04-05 09:11:08 --> Hooks Class Initialized
DEBUG - 2023-04-05 09:11:08 --> UTF-8 Support Enabled
INFO - 2023-04-05 09:11:08 --> Utf8 Class Initialized
INFO - 2023-04-05 09:11:08 --> URI Class Initialized
INFO - 2023-04-05 09:11:08 --> Router Class Initialized
INFO - 2023-04-05 09:11:08 --> Output Class Initialized
INFO - 2023-04-05 09:11:08 --> Security Class Initialized
DEBUG - 2023-04-05 09:11:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-05 09:11:08 --> Input Class Initialized
INFO - 2023-04-05 09:11:08 --> Language Class Initialized
INFO - 2023-04-05 09:11:08 --> Language Class Initialized
INFO - 2023-04-05 09:11:08 --> Config Class Initialized
INFO - 2023-04-05 09:11:08 --> Loader Class Initialized
INFO - 2023-04-05 09:11:08 --> Helper loaded: url_helper
INFO - 2023-04-05 09:11:08 --> Helper loaded: file_helper
INFO - 2023-04-05 09:11:08 --> Helper loaded: form_helper
INFO - 2023-04-05 09:11:08 --> Helper loaded: my_helper
INFO - 2023-04-05 09:11:08 --> Database Driver Class Initialized
DEBUG - 2023-04-05 09:11:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-04-05 09:11:08 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-05 09:11:08 --> Controller Class Initialized
INFO - 2023-04-05 09:11:08 --> Config Class Initialized
INFO - 2023-04-05 09:11:08 --> Hooks Class Initialized
DEBUG - 2023-04-05 09:11:08 --> UTF-8 Support Enabled
INFO - 2023-04-05 09:11:08 --> Utf8 Class Initialized
INFO - 2023-04-05 09:11:08 --> URI Class Initialized
INFO - 2023-04-05 09:11:08 --> Router Class Initialized
INFO - 2023-04-05 09:11:08 --> Output Class Initialized
INFO - 2023-04-05 09:11:08 --> Security Class Initialized
DEBUG - 2023-04-05 09:11:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-05 09:11:08 --> Input Class Initialized
INFO - 2023-04-05 09:11:08 --> Language Class Initialized
INFO - 2023-04-05 09:11:08 --> Language Class Initialized
INFO - 2023-04-05 09:11:08 --> Config Class Initialized
INFO - 2023-04-05 09:11:08 --> Loader Class Initialized
INFO - 2023-04-05 09:11:08 --> Helper loaded: url_helper
INFO - 2023-04-05 09:11:08 --> Helper loaded: file_helper
INFO - 2023-04-05 09:11:08 --> Helper loaded: form_helper
INFO - 2023-04-05 09:11:08 --> Helper loaded: my_helper
INFO - 2023-04-05 09:11:08 --> Database Driver Class Initialized
DEBUG - 2023-04-05 09:11:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-04-05 09:11:08 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-05 09:11:08 --> Controller Class Initialized
DEBUG - 2023-04-05 09:11:08 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/login/views/login.php
DEBUG - 2023-04-05 09:11:08 --> File loaded: C:\xampp\htdocs\myraportk13\application\views\template_utama.php
INFO - 2023-04-05 09:11:08 --> Final output sent to browser
DEBUG - 2023-04-05 09:11:08 --> Total execution time: 0.0234
INFO - 2023-04-05 09:11:13 --> Config Class Initialized
INFO - 2023-04-05 09:11:13 --> Hooks Class Initialized
DEBUG - 2023-04-05 09:11:13 --> UTF-8 Support Enabled
INFO - 2023-04-05 09:11:13 --> Utf8 Class Initialized
INFO - 2023-04-05 09:11:13 --> URI Class Initialized
INFO - 2023-04-05 09:11:13 --> Router Class Initialized
INFO - 2023-04-05 09:11:13 --> Output Class Initialized
INFO - 2023-04-05 09:11:13 --> Security Class Initialized
DEBUG - 2023-04-05 09:11:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-05 09:11:13 --> Input Class Initialized
INFO - 2023-04-05 09:11:13 --> Language Class Initialized
INFO - 2023-04-05 09:11:13 --> Language Class Initialized
INFO - 2023-04-05 09:11:13 --> Config Class Initialized
INFO - 2023-04-05 09:11:13 --> Loader Class Initialized
INFO - 2023-04-05 09:11:13 --> Helper loaded: url_helper
INFO - 2023-04-05 09:11:13 --> Helper loaded: file_helper
INFO - 2023-04-05 09:11:13 --> Helper loaded: form_helper
INFO - 2023-04-05 09:11:13 --> Helper loaded: my_helper
INFO - 2023-04-05 09:11:13 --> Database Driver Class Initialized
DEBUG - 2023-04-05 09:11:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-04-05 09:11:13 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-05 09:11:13 --> Controller Class Initialized
INFO - 2023-04-05 09:11:13 --> Helper loaded: cookie_helper
INFO - 2023-04-05 09:11:13 --> Final output sent to browser
DEBUG - 2023-04-05 09:11:13 --> Total execution time: 0.0436
INFO - 2023-04-05 09:11:13 --> Config Class Initialized
INFO - 2023-04-05 09:11:13 --> Hooks Class Initialized
DEBUG - 2023-04-05 09:11:13 --> UTF-8 Support Enabled
INFO - 2023-04-05 09:11:13 --> Utf8 Class Initialized
INFO - 2023-04-05 09:11:13 --> URI Class Initialized
INFO - 2023-04-05 09:11:13 --> Router Class Initialized
INFO - 2023-04-05 09:11:13 --> Output Class Initialized
INFO - 2023-04-05 09:11:13 --> Security Class Initialized
DEBUG - 2023-04-05 09:11:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-05 09:11:13 --> Input Class Initialized
INFO - 2023-04-05 09:11:13 --> Language Class Initialized
INFO - 2023-04-05 09:11:13 --> Language Class Initialized
INFO - 2023-04-05 09:11:13 --> Config Class Initialized
INFO - 2023-04-05 09:11:13 --> Loader Class Initialized
INFO - 2023-04-05 09:11:13 --> Helper loaded: url_helper
INFO - 2023-04-05 09:11:13 --> Helper loaded: file_helper
INFO - 2023-04-05 09:11:13 --> Helper loaded: form_helper
INFO - 2023-04-05 09:11:13 --> Helper loaded: my_helper
INFO - 2023-04-05 09:11:13 --> Database Driver Class Initialized
DEBUG - 2023-04-05 09:11:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-04-05 09:11:13 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-05 09:11:13 --> Controller Class Initialized
DEBUG - 2023-04-05 09:11:13 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/home/views/v_home_guru.php
DEBUG - 2023-04-05 09:11:13 --> File loaded: C:\xampp\htdocs\myraportk13\application\views\template_utama.php
INFO - 2023-04-05 09:11:13 --> Final output sent to browser
DEBUG - 2023-04-05 09:11:13 --> Total execution time: 0.0313
INFO - 2023-04-05 09:11:16 --> Config Class Initialized
INFO - 2023-04-05 09:11:16 --> Hooks Class Initialized
DEBUG - 2023-04-05 09:11:16 --> UTF-8 Support Enabled
INFO - 2023-04-05 09:11:16 --> Utf8 Class Initialized
INFO - 2023-04-05 09:11:16 --> URI Class Initialized
INFO - 2023-04-05 09:11:16 --> Router Class Initialized
INFO - 2023-04-05 09:11:16 --> Output Class Initialized
INFO - 2023-04-05 09:11:16 --> Security Class Initialized
DEBUG - 2023-04-05 09:11:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-05 09:11:16 --> Input Class Initialized
INFO - 2023-04-05 09:11:16 --> Language Class Initialized
INFO - 2023-04-05 09:11:16 --> Language Class Initialized
INFO - 2023-04-05 09:11:16 --> Config Class Initialized
INFO - 2023-04-05 09:11:16 --> Loader Class Initialized
INFO - 2023-04-05 09:11:16 --> Helper loaded: url_helper
INFO - 2023-04-05 09:11:16 --> Helper loaded: file_helper
INFO - 2023-04-05 09:11:16 --> Helper loaded: form_helper
INFO - 2023-04-05 09:11:16 --> Helper loaded: my_helper
INFO - 2023-04-05 09:11:16 --> Database Driver Class Initialized
DEBUG - 2023-04-05 09:11:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-04-05 09:11:16 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-05 09:11:16 --> Controller Class Initialized
DEBUG - 2023-04-05 09:11:16 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/cetak_raport/views/list.php
DEBUG - 2023-04-05 09:11:16 --> File loaded: C:\xampp\htdocs\myraportk13\application\views\template_utama.php
INFO - 2023-04-05 09:11:16 --> Final output sent to browser
DEBUG - 2023-04-05 09:11:16 --> Total execution time: 0.0310
INFO - 2023-04-05 09:11:17 --> Config Class Initialized
INFO - 2023-04-05 09:11:17 --> Hooks Class Initialized
DEBUG - 2023-04-05 09:11:17 --> UTF-8 Support Enabled
INFO - 2023-04-05 09:11:17 --> Utf8 Class Initialized
INFO - 2023-04-05 09:11:17 --> URI Class Initialized
INFO - 2023-04-05 09:11:17 --> Router Class Initialized
INFO - 2023-04-05 09:11:17 --> Output Class Initialized
INFO - 2023-04-05 09:11:17 --> Security Class Initialized
DEBUG - 2023-04-05 09:11:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-05 09:11:17 --> Input Class Initialized
INFO - 2023-04-05 09:11:17 --> Language Class Initialized
INFO - 2023-04-05 09:11:17 --> Language Class Initialized
INFO - 2023-04-05 09:11:17 --> Config Class Initialized
INFO - 2023-04-05 09:11:17 --> Loader Class Initialized
INFO - 2023-04-05 09:11:17 --> Helper loaded: url_helper
INFO - 2023-04-05 09:11:17 --> Helper loaded: file_helper
INFO - 2023-04-05 09:11:17 --> Helper loaded: form_helper
INFO - 2023-04-05 09:11:17 --> Helper loaded: my_helper
INFO - 2023-04-05 09:11:17 --> Database Driver Class Initialized
DEBUG - 2023-04-05 09:11:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-04-05 09:11:17 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-05 09:11:17 --> Controller Class Initialized
DEBUG - 2023-04-05 09:11:17 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/cetak_raport/views/cetak_rapot.php
INFO - 2023-04-05 09:11:18 --> Final output sent to browser
DEBUG - 2023-04-05 09:11:18 --> Total execution time: 1.2539
