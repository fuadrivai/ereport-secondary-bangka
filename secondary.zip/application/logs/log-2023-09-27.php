<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2023-09-27 08:42:41 --> Config Class Initialized
INFO - 2023-09-27 08:42:41 --> Hooks Class Initialized
DEBUG - 2023-09-27 08:42:41 --> UTF-8 Support Enabled
INFO - 2023-09-27 08:42:41 --> Utf8 Class Initialized
INFO - 2023-09-27 08:42:41 --> URI Class Initialized
INFO - 2023-09-27 08:42:41 --> Router Class Initialized
INFO - 2023-09-27 08:42:41 --> Output Class Initialized
INFO - 2023-09-27 08:42:41 --> Security Class Initialized
DEBUG - 2023-09-27 08:42:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-27 08:42:41 --> Input Class Initialized
INFO - 2023-09-27 08:42:41 --> Language Class Initialized
INFO - 2023-09-27 08:42:41 --> Language Class Initialized
INFO - 2023-09-27 08:42:41 --> Config Class Initialized
INFO - 2023-09-27 08:42:41 --> Loader Class Initialized
INFO - 2023-09-27 08:42:41 --> Helper loaded: url_helper
INFO - 2023-09-27 08:42:41 --> Helper loaded: file_helper
INFO - 2023-09-27 08:42:41 --> Helper loaded: form_helper
INFO - 2023-09-27 08:42:41 --> Helper loaded: my_helper
INFO - 2023-09-27 08:42:41 --> Database Driver Class Initialized
INFO - 2023-09-27 08:42:41 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-27 08:42:41 --> Controller Class Initialized
INFO - 2023-09-27 08:42:41 --> Config Class Initialized
INFO - 2023-09-27 08:42:41 --> Hooks Class Initialized
DEBUG - 2023-09-27 08:42:41 --> UTF-8 Support Enabled
INFO - 2023-09-27 08:42:41 --> Utf8 Class Initialized
INFO - 2023-09-27 08:42:41 --> URI Class Initialized
INFO - 2023-09-27 08:42:41 --> Router Class Initialized
INFO - 2023-09-27 08:42:41 --> Output Class Initialized
INFO - 2023-09-27 08:42:41 --> Security Class Initialized
DEBUG - 2023-09-27 08:42:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-27 08:42:41 --> Input Class Initialized
INFO - 2023-09-27 08:42:41 --> Language Class Initialized
INFO - 2023-09-27 08:42:41 --> Language Class Initialized
INFO - 2023-09-27 08:42:41 --> Config Class Initialized
INFO - 2023-09-27 08:42:41 --> Loader Class Initialized
INFO - 2023-09-27 08:42:41 --> Helper loaded: url_helper
INFO - 2023-09-27 08:42:41 --> Helper loaded: file_helper
INFO - 2023-09-27 08:42:41 --> Helper loaded: form_helper
INFO - 2023-09-27 08:42:41 --> Helper loaded: my_helper
INFO - 2023-09-27 08:42:41 --> Database Driver Class Initialized
INFO - 2023-09-27 08:42:41 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-27 08:42:41 --> Controller Class Initialized
DEBUG - 2023-09-27 08:42:41 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/login/views/login.php
DEBUG - 2023-09-27 08:42:41 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-09-27 08:42:41 --> Final output sent to browser
DEBUG - 2023-09-27 08:42:41 --> Total execution time: 0.0376
INFO - 2023-09-27 08:42:45 --> Config Class Initialized
INFO - 2023-09-27 08:42:45 --> Hooks Class Initialized
DEBUG - 2023-09-27 08:42:45 --> UTF-8 Support Enabled
INFO - 2023-09-27 08:42:45 --> Utf8 Class Initialized
INFO - 2023-09-27 08:42:45 --> URI Class Initialized
INFO - 2023-09-27 08:42:45 --> Router Class Initialized
INFO - 2023-09-27 08:42:45 --> Output Class Initialized
INFO - 2023-09-27 08:42:45 --> Security Class Initialized
DEBUG - 2023-09-27 08:42:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-27 08:42:45 --> Input Class Initialized
INFO - 2023-09-27 08:42:45 --> Language Class Initialized
INFO - 2023-09-27 08:42:45 --> Language Class Initialized
INFO - 2023-09-27 08:42:45 --> Config Class Initialized
INFO - 2023-09-27 08:42:45 --> Loader Class Initialized
INFO - 2023-09-27 08:42:45 --> Helper loaded: url_helper
INFO - 2023-09-27 08:42:45 --> Helper loaded: file_helper
INFO - 2023-09-27 08:42:45 --> Helper loaded: form_helper
INFO - 2023-09-27 08:42:45 --> Helper loaded: my_helper
INFO - 2023-09-27 08:42:45 --> Database Driver Class Initialized
INFO - 2023-09-27 08:42:45 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-27 08:42:45 --> Controller Class Initialized
INFO - 2023-09-27 08:42:45 --> Helper loaded: cookie_helper
INFO - 2023-09-27 08:42:45 --> Final output sent to browser
DEBUG - 2023-09-27 08:42:45 --> Total execution time: 0.0534
INFO - 2023-09-27 08:42:45 --> Config Class Initialized
INFO - 2023-09-27 08:42:45 --> Hooks Class Initialized
DEBUG - 2023-09-27 08:42:45 --> UTF-8 Support Enabled
INFO - 2023-09-27 08:42:45 --> Utf8 Class Initialized
INFO - 2023-09-27 08:42:45 --> URI Class Initialized
INFO - 2023-09-27 08:42:45 --> Router Class Initialized
INFO - 2023-09-27 08:42:45 --> Output Class Initialized
INFO - 2023-09-27 08:42:45 --> Security Class Initialized
DEBUG - 2023-09-27 08:42:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-27 08:42:45 --> Input Class Initialized
INFO - 2023-09-27 08:42:45 --> Language Class Initialized
INFO - 2023-09-27 08:42:45 --> Language Class Initialized
INFO - 2023-09-27 08:42:45 --> Config Class Initialized
INFO - 2023-09-27 08:42:45 --> Loader Class Initialized
INFO - 2023-09-27 08:42:45 --> Helper loaded: url_helper
INFO - 2023-09-27 08:42:45 --> Helper loaded: file_helper
INFO - 2023-09-27 08:42:45 --> Helper loaded: form_helper
INFO - 2023-09-27 08:42:45 --> Helper loaded: my_helper
INFO - 2023-09-27 08:42:45 --> Database Driver Class Initialized
INFO - 2023-09-27 08:42:45 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-27 08:42:45 --> Controller Class Initialized
DEBUG - 2023-09-27 08:42:45 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/home/views/v_home_guru.php
DEBUG - 2023-09-27 08:42:45 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-09-27 08:42:45 --> Final output sent to browser
DEBUG - 2023-09-27 08:42:45 --> Total execution time: 0.0416
INFO - 2023-09-27 08:42:48 --> Config Class Initialized
INFO - 2023-09-27 08:42:48 --> Hooks Class Initialized
DEBUG - 2023-09-27 08:42:48 --> UTF-8 Support Enabled
INFO - 2023-09-27 08:42:48 --> Utf8 Class Initialized
INFO - 2023-09-27 08:42:48 --> URI Class Initialized
INFO - 2023-09-27 08:42:48 --> Router Class Initialized
INFO - 2023-09-27 08:42:48 --> Output Class Initialized
INFO - 2023-09-27 08:42:48 --> Security Class Initialized
DEBUG - 2023-09-27 08:42:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-27 08:42:48 --> Input Class Initialized
INFO - 2023-09-27 08:42:48 --> Language Class Initialized
INFO - 2023-09-27 08:42:48 --> Language Class Initialized
INFO - 2023-09-27 08:42:48 --> Config Class Initialized
INFO - 2023-09-27 08:42:48 --> Loader Class Initialized
INFO - 2023-09-27 08:42:48 --> Helper loaded: url_helper
INFO - 2023-09-27 08:42:48 --> Helper loaded: file_helper
INFO - 2023-09-27 08:42:48 --> Helper loaded: form_helper
INFO - 2023-09-27 08:42:48 --> Helper loaded: my_helper
INFO - 2023-09-27 08:42:48 --> Database Driver Class Initialized
INFO - 2023-09-27 08:42:48 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-27 08:42:48 --> Controller Class Initialized
DEBUG - 2023-09-27 08:42:48 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/view_mapel/views/v_view_mapel.php
DEBUG - 2023-09-27 08:42:48 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-09-27 08:42:48 --> Final output sent to browser
DEBUG - 2023-09-27 08:42:48 --> Total execution time: 0.0380
INFO - 2023-09-27 08:42:52 --> Config Class Initialized
INFO - 2023-09-27 08:42:52 --> Hooks Class Initialized
DEBUG - 2023-09-27 08:42:52 --> UTF-8 Support Enabled
INFO - 2023-09-27 08:42:52 --> Utf8 Class Initialized
INFO - 2023-09-27 08:42:52 --> URI Class Initialized
INFO - 2023-09-27 08:42:52 --> Router Class Initialized
INFO - 2023-09-27 08:42:52 --> Output Class Initialized
INFO - 2023-09-27 08:42:52 --> Security Class Initialized
DEBUG - 2023-09-27 08:42:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-27 08:42:52 --> Input Class Initialized
INFO - 2023-09-27 08:42:52 --> Language Class Initialized
INFO - 2023-09-27 08:42:52 --> Language Class Initialized
INFO - 2023-09-27 08:42:52 --> Config Class Initialized
INFO - 2023-09-27 08:42:52 --> Loader Class Initialized
INFO - 2023-09-27 08:42:53 --> Helper loaded: url_helper
INFO - 2023-09-27 08:42:53 --> Helper loaded: file_helper
INFO - 2023-09-27 08:42:53 --> Helper loaded: form_helper
INFO - 2023-09-27 08:42:53 --> Helper loaded: my_helper
INFO - 2023-09-27 08:42:53 --> Database Driver Class Initialized
INFO - 2023-09-27 08:42:53 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-27 08:42:53 --> Controller Class Initialized
DEBUG - 2023-09-27 08:42:53 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/views/list.php
DEBUG - 2023-09-27 08:42:53 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-09-27 08:42:53 --> Final output sent to browser
DEBUG - 2023-09-27 08:42:53 --> Total execution time: 0.0862
INFO - 2023-09-27 08:42:53 --> Config Class Initialized
INFO - 2023-09-27 08:42:53 --> Hooks Class Initialized
DEBUG - 2023-09-27 08:42:53 --> UTF-8 Support Enabled
INFO - 2023-09-27 08:42:53 --> Utf8 Class Initialized
INFO - 2023-09-27 08:42:53 --> URI Class Initialized
INFO - 2023-09-27 08:42:53 --> Router Class Initialized
INFO - 2023-09-27 08:42:53 --> Output Class Initialized
INFO - 2023-09-27 08:42:53 --> Security Class Initialized
DEBUG - 2023-09-27 08:42:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-27 08:42:53 --> Input Class Initialized
INFO - 2023-09-27 08:42:53 --> Language Class Initialized
INFO - 2023-09-27 08:42:53 --> Language Class Initialized
INFO - 2023-09-27 08:42:53 --> Config Class Initialized
INFO - 2023-09-27 08:42:53 --> Loader Class Initialized
INFO - 2023-09-27 08:42:53 --> Helper loaded: url_helper
INFO - 2023-09-27 08:42:53 --> Helper loaded: file_helper
INFO - 2023-09-27 08:42:53 --> Helper loaded: form_helper
INFO - 2023-09-27 08:42:53 --> Helper loaded: my_helper
INFO - 2023-09-27 08:42:53 --> Database Driver Class Initialized
INFO - 2023-09-27 08:42:53 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-27 08:42:53 --> Controller Class Initialized
INFO - 2023-09-27 08:42:56 --> Config Class Initialized
INFO - 2023-09-27 08:42:56 --> Hooks Class Initialized
DEBUG - 2023-09-27 08:42:56 --> UTF-8 Support Enabled
INFO - 2023-09-27 08:42:56 --> Utf8 Class Initialized
INFO - 2023-09-27 08:42:56 --> URI Class Initialized
INFO - 2023-09-27 08:42:56 --> Router Class Initialized
INFO - 2023-09-27 08:42:56 --> Output Class Initialized
INFO - 2023-09-27 08:42:56 --> Security Class Initialized
DEBUG - 2023-09-27 08:42:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-27 08:42:56 --> Input Class Initialized
INFO - 2023-09-27 08:42:56 --> Language Class Initialized
INFO - 2023-09-27 08:42:56 --> Language Class Initialized
INFO - 2023-09-27 08:42:56 --> Config Class Initialized
INFO - 2023-09-27 08:42:56 --> Loader Class Initialized
INFO - 2023-09-27 08:42:56 --> Helper loaded: url_helper
INFO - 2023-09-27 08:42:56 --> Helper loaded: file_helper
INFO - 2023-09-27 08:42:56 --> Helper loaded: form_helper
INFO - 2023-09-27 08:42:56 --> Helper loaded: my_helper
INFO - 2023-09-27 08:42:56 --> Database Driver Class Initialized
INFO - 2023-09-27 08:42:56 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-27 08:42:56 --> Controller Class Initialized
INFO - 2023-09-27 08:45:00 --> Config Class Initialized
INFO - 2023-09-27 08:45:00 --> Hooks Class Initialized
DEBUG - 2023-09-27 08:45:00 --> UTF-8 Support Enabled
INFO - 2023-09-27 08:45:00 --> Utf8 Class Initialized
INFO - 2023-09-27 08:45:00 --> URI Class Initialized
DEBUG - 2023-09-27 08:45:00 --> No URI present. Default controller set.
INFO - 2023-09-27 08:45:00 --> Router Class Initialized
INFO - 2023-09-27 08:45:00 --> Output Class Initialized
INFO - 2023-09-27 08:45:00 --> Security Class Initialized
DEBUG - 2023-09-27 08:45:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-27 08:45:00 --> Input Class Initialized
INFO - 2023-09-27 08:45:00 --> Language Class Initialized
INFO - 2023-09-27 08:45:00 --> Language Class Initialized
INFO - 2023-09-27 08:45:00 --> Config Class Initialized
INFO - 2023-09-27 08:45:00 --> Loader Class Initialized
INFO - 2023-09-27 08:45:00 --> Helper loaded: url_helper
INFO - 2023-09-27 08:45:00 --> Helper loaded: file_helper
INFO - 2023-09-27 08:45:00 --> Helper loaded: form_helper
INFO - 2023-09-27 08:45:00 --> Helper loaded: my_helper
INFO - 2023-09-27 08:45:00 --> Database Driver Class Initialized
INFO - 2023-09-27 08:45:00 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-27 08:45:00 --> Controller Class Initialized
DEBUG - 2023-09-27 08:45:00 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/home/views/v_home_guru.php
DEBUG - 2023-09-27 08:45:00 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-09-27 08:45:00 --> Final output sent to browser
DEBUG - 2023-09-27 08:45:00 --> Total execution time: 0.0741
INFO - 2023-09-27 08:45:02 --> Config Class Initialized
INFO - 2023-09-27 08:45:02 --> Hooks Class Initialized
DEBUG - 2023-09-27 08:45:02 --> UTF-8 Support Enabled
INFO - 2023-09-27 08:45:02 --> Utf8 Class Initialized
INFO - 2023-09-27 08:45:02 --> URI Class Initialized
INFO - 2023-09-27 08:45:02 --> Router Class Initialized
INFO - 2023-09-27 08:45:02 --> Output Class Initialized
INFO - 2023-09-27 08:45:02 --> Security Class Initialized
DEBUG - 2023-09-27 08:45:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-27 08:45:02 --> Input Class Initialized
INFO - 2023-09-27 08:45:02 --> Language Class Initialized
INFO - 2023-09-27 08:45:02 --> Language Class Initialized
INFO - 2023-09-27 08:45:02 --> Config Class Initialized
INFO - 2023-09-27 08:45:02 --> Loader Class Initialized
INFO - 2023-09-27 08:45:02 --> Helper loaded: url_helper
INFO - 2023-09-27 08:45:02 --> Helper loaded: file_helper
INFO - 2023-09-27 08:45:02 --> Helper loaded: form_helper
INFO - 2023-09-27 08:45:02 --> Helper loaded: my_helper
INFO - 2023-09-27 08:45:02 --> Database Driver Class Initialized
INFO - 2023-09-27 08:45:02 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-27 08:45:02 --> Controller Class Initialized
DEBUG - 2023-09-27 08:45:02 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/view_mapel/views/v_view_mapel.php
DEBUG - 2023-09-27 08:45:02 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-09-27 08:45:02 --> Final output sent to browser
DEBUG - 2023-09-27 08:45:02 --> Total execution time: 0.0443
INFO - 2023-09-27 08:45:05 --> Config Class Initialized
INFO - 2023-09-27 08:45:05 --> Hooks Class Initialized
DEBUG - 2023-09-27 08:45:05 --> UTF-8 Support Enabled
INFO - 2023-09-27 08:45:05 --> Utf8 Class Initialized
INFO - 2023-09-27 08:45:05 --> URI Class Initialized
DEBUG - 2023-09-27 08:45:05 --> No URI present. Default controller set.
INFO - 2023-09-27 08:45:05 --> Router Class Initialized
INFO - 2023-09-27 08:45:05 --> Output Class Initialized
INFO - 2023-09-27 08:45:05 --> Security Class Initialized
DEBUG - 2023-09-27 08:45:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-27 08:45:05 --> Input Class Initialized
INFO - 2023-09-27 08:45:05 --> Language Class Initialized
INFO - 2023-09-27 08:45:05 --> Language Class Initialized
INFO - 2023-09-27 08:45:05 --> Config Class Initialized
INFO - 2023-09-27 08:45:05 --> Loader Class Initialized
INFO - 2023-09-27 08:45:05 --> Helper loaded: url_helper
INFO - 2023-09-27 08:45:05 --> Helper loaded: file_helper
INFO - 2023-09-27 08:45:05 --> Helper loaded: form_helper
INFO - 2023-09-27 08:45:05 --> Helper loaded: my_helper
INFO - 2023-09-27 08:45:05 --> Database Driver Class Initialized
INFO - 2023-09-27 08:45:05 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-27 08:45:05 --> Controller Class Initialized
DEBUG - 2023-09-27 08:45:05 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/home/views/v_home_guru.php
DEBUG - 2023-09-27 08:45:05 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-09-27 08:45:05 --> Final output sent to browser
DEBUG - 2023-09-27 08:45:05 --> Total execution time: 0.0925
INFO - 2023-09-27 08:45:07 --> Config Class Initialized
INFO - 2023-09-27 08:45:07 --> Hooks Class Initialized
DEBUG - 2023-09-27 08:45:07 --> UTF-8 Support Enabled
INFO - 2023-09-27 08:45:07 --> Utf8 Class Initialized
INFO - 2023-09-27 08:45:07 --> URI Class Initialized
DEBUG - 2023-09-27 08:45:07 --> No URI present. Default controller set.
INFO - 2023-09-27 08:45:07 --> Router Class Initialized
INFO - 2023-09-27 08:45:07 --> Output Class Initialized
INFO - 2023-09-27 08:45:07 --> Security Class Initialized
DEBUG - 2023-09-27 08:45:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-27 08:45:07 --> Input Class Initialized
INFO - 2023-09-27 08:45:07 --> Language Class Initialized
INFO - 2023-09-27 08:45:07 --> Language Class Initialized
INFO - 2023-09-27 08:45:07 --> Config Class Initialized
INFO - 2023-09-27 08:45:07 --> Loader Class Initialized
INFO - 2023-09-27 08:45:07 --> Helper loaded: url_helper
INFO - 2023-09-27 08:45:07 --> Helper loaded: file_helper
INFO - 2023-09-27 08:45:07 --> Helper loaded: form_helper
INFO - 2023-09-27 08:45:07 --> Helper loaded: my_helper
INFO - 2023-09-27 08:45:07 --> Database Driver Class Initialized
INFO - 2023-09-27 08:45:07 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-27 08:45:07 --> Controller Class Initialized
DEBUG - 2023-09-27 08:45:08 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/home/views/v_home_guru.php
DEBUG - 2023-09-27 08:45:08 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-09-27 08:45:08 --> Final output sent to browser
DEBUG - 2023-09-27 08:45:08 --> Total execution time: 0.2238
INFO - 2023-09-27 15:14:00 --> Config Class Initialized
INFO - 2023-09-27 15:14:00 --> Hooks Class Initialized
DEBUG - 2023-09-27 15:14:00 --> UTF-8 Support Enabled
INFO - 2023-09-27 15:14:00 --> Utf8 Class Initialized
INFO - 2023-09-27 15:14:00 --> URI Class Initialized
INFO - 2023-09-27 15:14:00 --> Router Class Initialized
INFO - 2023-09-27 15:14:00 --> Output Class Initialized
INFO - 2023-09-27 15:14:00 --> Security Class Initialized
DEBUG - 2023-09-27 15:14:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-27 15:14:00 --> Input Class Initialized
INFO - 2023-09-27 15:14:00 --> Language Class Initialized
INFO - 2023-09-27 15:14:00 --> Language Class Initialized
INFO - 2023-09-27 15:14:00 --> Config Class Initialized
INFO - 2023-09-27 15:14:00 --> Loader Class Initialized
INFO - 2023-09-27 15:14:00 --> Helper loaded: url_helper
INFO - 2023-09-27 15:14:00 --> Helper loaded: file_helper
INFO - 2023-09-27 15:14:00 --> Helper loaded: form_helper
INFO - 2023-09-27 15:14:00 --> Helper loaded: my_helper
INFO - 2023-09-27 15:14:00 --> Database Driver Class Initialized
INFO - 2023-09-27 15:14:00 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-27 15:14:00 --> Controller Class Initialized
INFO - 2023-09-27 15:14:00 --> Config Class Initialized
INFO - 2023-09-27 15:14:00 --> Hooks Class Initialized
DEBUG - 2023-09-27 15:14:00 --> UTF-8 Support Enabled
INFO - 2023-09-27 15:14:00 --> Utf8 Class Initialized
INFO - 2023-09-27 15:14:00 --> URI Class Initialized
INFO - 2023-09-27 15:14:00 --> Router Class Initialized
INFO - 2023-09-27 15:14:00 --> Output Class Initialized
INFO - 2023-09-27 15:14:00 --> Security Class Initialized
DEBUG - 2023-09-27 15:14:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-27 15:14:00 --> Input Class Initialized
INFO - 2023-09-27 15:14:00 --> Language Class Initialized
INFO - 2023-09-27 15:14:00 --> Language Class Initialized
INFO - 2023-09-27 15:14:00 --> Config Class Initialized
INFO - 2023-09-27 15:14:00 --> Loader Class Initialized
INFO - 2023-09-27 15:14:00 --> Helper loaded: url_helper
INFO - 2023-09-27 15:14:00 --> Helper loaded: file_helper
INFO - 2023-09-27 15:14:00 --> Helper loaded: form_helper
INFO - 2023-09-27 15:14:00 --> Helper loaded: my_helper
INFO - 2023-09-27 15:14:00 --> Database Driver Class Initialized
INFO - 2023-09-27 15:14:00 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-27 15:14:00 --> Controller Class Initialized
DEBUG - 2023-09-27 15:14:00 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/login/views/login.php
DEBUG - 2023-09-27 15:14:00 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-09-27 15:14:00 --> Final output sent to browser
DEBUG - 2023-09-27 15:14:00 --> Total execution time: 0.0637
INFO - 2023-09-27 15:14:03 --> Config Class Initialized
INFO - 2023-09-27 15:14:03 --> Hooks Class Initialized
DEBUG - 2023-09-27 15:14:03 --> UTF-8 Support Enabled
INFO - 2023-09-27 15:14:03 --> Utf8 Class Initialized
INFO - 2023-09-27 15:14:03 --> URI Class Initialized
INFO - 2023-09-27 15:14:03 --> Router Class Initialized
INFO - 2023-09-27 15:14:03 --> Output Class Initialized
INFO - 2023-09-27 15:14:03 --> Security Class Initialized
DEBUG - 2023-09-27 15:14:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-27 15:14:03 --> Input Class Initialized
INFO - 2023-09-27 15:14:03 --> Language Class Initialized
INFO - 2023-09-27 15:14:03 --> Language Class Initialized
INFO - 2023-09-27 15:14:03 --> Config Class Initialized
INFO - 2023-09-27 15:14:03 --> Loader Class Initialized
INFO - 2023-09-27 15:14:03 --> Helper loaded: url_helper
INFO - 2023-09-27 15:14:03 --> Helper loaded: file_helper
INFO - 2023-09-27 15:14:03 --> Helper loaded: form_helper
INFO - 2023-09-27 15:14:03 --> Helper loaded: my_helper
INFO - 2023-09-27 15:14:03 --> Database Driver Class Initialized
INFO - 2023-09-27 15:14:03 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-27 15:14:03 --> Controller Class Initialized
INFO - 2023-09-27 15:14:03 --> Helper loaded: cookie_helper
INFO - 2023-09-27 15:14:03 --> Final output sent to browser
DEBUG - 2023-09-27 15:14:03 --> Total execution time: 0.0745
INFO - 2023-09-27 15:14:03 --> Config Class Initialized
INFO - 2023-09-27 15:14:03 --> Hooks Class Initialized
DEBUG - 2023-09-27 15:14:03 --> UTF-8 Support Enabled
INFO - 2023-09-27 15:14:03 --> Utf8 Class Initialized
INFO - 2023-09-27 15:14:03 --> URI Class Initialized
INFO - 2023-09-27 15:14:03 --> Router Class Initialized
INFO - 2023-09-27 15:14:03 --> Output Class Initialized
INFO - 2023-09-27 15:14:03 --> Security Class Initialized
DEBUG - 2023-09-27 15:14:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-27 15:14:03 --> Input Class Initialized
INFO - 2023-09-27 15:14:03 --> Language Class Initialized
INFO - 2023-09-27 15:14:03 --> Language Class Initialized
INFO - 2023-09-27 15:14:03 --> Config Class Initialized
INFO - 2023-09-27 15:14:03 --> Loader Class Initialized
INFO - 2023-09-27 15:14:03 --> Helper loaded: url_helper
INFO - 2023-09-27 15:14:03 --> Helper loaded: file_helper
INFO - 2023-09-27 15:14:03 --> Helper loaded: form_helper
INFO - 2023-09-27 15:14:03 --> Helper loaded: my_helper
INFO - 2023-09-27 15:14:03 --> Database Driver Class Initialized
INFO - 2023-09-27 15:14:03 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-27 15:14:03 --> Controller Class Initialized
DEBUG - 2023-09-27 15:14:03 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/home/views/v_home_guru.php
DEBUG - 2023-09-27 15:14:03 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-09-27 15:14:03 --> Final output sent to browser
DEBUG - 2023-09-27 15:14:03 --> Total execution time: 0.1240
INFO - 2023-09-27 15:14:06 --> Config Class Initialized
INFO - 2023-09-27 15:14:06 --> Hooks Class Initialized
DEBUG - 2023-09-27 15:14:06 --> UTF-8 Support Enabled
INFO - 2023-09-27 15:14:06 --> Utf8 Class Initialized
INFO - 2023-09-27 15:14:06 --> URI Class Initialized
INFO - 2023-09-27 15:14:06 --> Router Class Initialized
INFO - 2023-09-27 15:14:06 --> Output Class Initialized
INFO - 2023-09-27 15:14:06 --> Security Class Initialized
DEBUG - 2023-09-27 15:14:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-27 15:14:06 --> Input Class Initialized
INFO - 2023-09-27 15:14:06 --> Language Class Initialized
INFO - 2023-09-27 15:14:06 --> Language Class Initialized
INFO - 2023-09-27 15:14:06 --> Config Class Initialized
INFO - 2023-09-27 15:14:06 --> Loader Class Initialized
INFO - 2023-09-27 15:14:06 --> Helper loaded: url_helper
INFO - 2023-09-27 15:14:06 --> Helper loaded: file_helper
INFO - 2023-09-27 15:14:06 --> Helper loaded: form_helper
INFO - 2023-09-27 15:14:06 --> Helper loaded: my_helper
INFO - 2023-09-27 15:14:06 --> Database Driver Class Initialized
INFO - 2023-09-27 15:14:06 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-27 15:14:06 --> Controller Class Initialized
DEBUG - 2023-09-27 15:14:06 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/view_mapel/views/v_view_mapel.php
DEBUG - 2023-09-27 15:14:06 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-09-27 15:14:06 --> Final output sent to browser
DEBUG - 2023-09-27 15:14:06 --> Total execution time: 0.0773
INFO - 2023-09-27 15:14:18 --> Config Class Initialized
INFO - 2023-09-27 15:14:18 --> Hooks Class Initialized
DEBUG - 2023-09-27 15:14:18 --> UTF-8 Support Enabled
INFO - 2023-09-27 15:14:18 --> Utf8 Class Initialized
INFO - 2023-09-27 15:14:18 --> URI Class Initialized
INFO - 2023-09-27 15:14:18 --> Router Class Initialized
INFO - 2023-09-27 15:14:18 --> Output Class Initialized
INFO - 2023-09-27 15:14:18 --> Security Class Initialized
DEBUG - 2023-09-27 15:14:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-27 15:14:18 --> Input Class Initialized
INFO - 2023-09-27 15:14:18 --> Language Class Initialized
INFO - 2023-09-27 15:14:18 --> Language Class Initialized
INFO - 2023-09-27 15:14:18 --> Config Class Initialized
INFO - 2023-09-27 15:14:18 --> Loader Class Initialized
INFO - 2023-09-27 15:14:18 --> Helper loaded: url_helper
INFO - 2023-09-27 15:14:18 --> Helper loaded: file_helper
INFO - 2023-09-27 15:14:18 --> Helper loaded: form_helper
INFO - 2023-09-27 15:14:18 --> Helper loaded: my_helper
INFO - 2023-09-27 15:14:18 --> Database Driver Class Initialized
INFO - 2023-09-27 15:14:18 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-27 15:14:18 --> Controller Class Initialized
DEBUG - 2023-09-27 15:14:19 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/views/list.php
DEBUG - 2023-09-27 15:14:19 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-09-27 15:14:19 --> Final output sent to browser
DEBUG - 2023-09-27 15:14:19 --> Total execution time: 0.0908
INFO - 2023-09-27 15:14:19 --> Config Class Initialized
INFO - 2023-09-27 15:14:19 --> Hooks Class Initialized
DEBUG - 2023-09-27 15:14:19 --> UTF-8 Support Enabled
INFO - 2023-09-27 15:14:19 --> Utf8 Class Initialized
INFO - 2023-09-27 15:14:19 --> URI Class Initialized
INFO - 2023-09-27 15:14:19 --> Router Class Initialized
INFO - 2023-09-27 15:14:19 --> Output Class Initialized
INFO - 2023-09-27 15:14:19 --> Security Class Initialized
DEBUG - 2023-09-27 15:14:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-27 15:14:19 --> Input Class Initialized
INFO - 2023-09-27 15:14:19 --> Language Class Initialized
INFO - 2023-09-27 15:14:19 --> Language Class Initialized
INFO - 2023-09-27 15:14:19 --> Config Class Initialized
INFO - 2023-09-27 15:14:19 --> Loader Class Initialized
INFO - 2023-09-27 15:14:19 --> Helper loaded: url_helper
INFO - 2023-09-27 15:14:19 --> Helper loaded: file_helper
INFO - 2023-09-27 15:14:19 --> Helper loaded: form_helper
INFO - 2023-09-27 15:14:19 --> Helper loaded: my_helper
INFO - 2023-09-27 15:14:19 --> Database Driver Class Initialized
INFO - 2023-09-27 15:14:19 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-27 15:14:19 --> Controller Class Initialized
INFO - 2023-09-27 15:23:33 --> Config Class Initialized
INFO - 2023-09-27 15:23:33 --> Hooks Class Initialized
DEBUG - 2023-09-27 15:23:33 --> UTF-8 Support Enabled
INFO - 2023-09-27 15:23:33 --> Utf8 Class Initialized
INFO - 2023-09-27 15:23:33 --> URI Class Initialized
INFO - 2023-09-27 15:23:33 --> Router Class Initialized
INFO - 2023-09-27 15:23:33 --> Output Class Initialized
INFO - 2023-09-27 15:23:33 --> Security Class Initialized
DEBUG - 2023-09-27 15:23:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-27 15:23:33 --> Input Class Initialized
INFO - 2023-09-27 15:23:33 --> Language Class Initialized
INFO - 2023-09-27 15:23:33 --> Language Class Initialized
INFO - 2023-09-27 15:23:33 --> Config Class Initialized
INFO - 2023-09-27 15:23:33 --> Loader Class Initialized
INFO - 2023-09-27 15:23:33 --> Helper loaded: url_helper
INFO - 2023-09-27 15:23:33 --> Helper loaded: file_helper
INFO - 2023-09-27 15:23:33 --> Helper loaded: form_helper
INFO - 2023-09-27 15:23:33 --> Helper loaded: my_helper
INFO - 2023-09-27 15:23:33 --> Database Driver Class Initialized
INFO - 2023-09-27 15:23:33 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-27 15:23:33 --> Controller Class Initialized
DEBUG - 2023-09-27 15:23:33 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/views/form.php
DEBUG - 2023-09-27 15:23:33 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-09-27 15:23:33 --> Final output sent to browser
DEBUG - 2023-09-27 15:23:33 --> Total execution time: 0.2152
INFO - 2023-09-27 15:23:42 --> Config Class Initialized
INFO - 2023-09-27 15:23:42 --> Hooks Class Initialized
DEBUG - 2023-09-27 15:23:42 --> UTF-8 Support Enabled
INFO - 2023-09-27 15:23:42 --> Utf8 Class Initialized
INFO - 2023-09-27 15:23:42 --> URI Class Initialized
INFO - 2023-09-27 15:23:42 --> Router Class Initialized
INFO - 2023-09-27 15:23:42 --> Output Class Initialized
INFO - 2023-09-27 15:23:42 --> Security Class Initialized
DEBUG - 2023-09-27 15:23:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-27 15:23:42 --> Input Class Initialized
INFO - 2023-09-27 15:23:42 --> Language Class Initialized
INFO - 2023-09-27 15:23:42 --> Language Class Initialized
INFO - 2023-09-27 15:23:42 --> Config Class Initialized
INFO - 2023-09-27 15:23:42 --> Loader Class Initialized
INFO - 2023-09-27 15:23:42 --> Helper loaded: url_helper
INFO - 2023-09-27 15:23:42 --> Helper loaded: file_helper
INFO - 2023-09-27 15:23:42 --> Helper loaded: form_helper
INFO - 2023-09-27 15:23:42 --> Helper loaded: my_helper
INFO - 2023-09-27 15:23:42 --> Database Driver Class Initialized
INFO - 2023-09-27 15:23:42 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-27 15:23:42 --> Controller Class Initialized
INFO - 2023-09-27 15:23:42 --> Config Class Initialized
INFO - 2023-09-27 15:23:42 --> Hooks Class Initialized
DEBUG - 2023-09-27 15:23:42 --> UTF-8 Support Enabled
INFO - 2023-09-27 15:23:42 --> Utf8 Class Initialized
INFO - 2023-09-27 15:23:42 --> URI Class Initialized
INFO - 2023-09-27 15:23:42 --> Router Class Initialized
INFO - 2023-09-27 15:23:42 --> Output Class Initialized
INFO - 2023-09-27 15:23:42 --> Security Class Initialized
DEBUG - 2023-09-27 15:23:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-27 15:23:42 --> Input Class Initialized
INFO - 2023-09-27 15:23:42 --> Language Class Initialized
INFO - 2023-09-27 15:23:42 --> Language Class Initialized
INFO - 2023-09-27 15:23:42 --> Config Class Initialized
INFO - 2023-09-27 15:23:42 --> Loader Class Initialized
INFO - 2023-09-27 15:23:42 --> Helper loaded: url_helper
INFO - 2023-09-27 15:23:42 --> Helper loaded: file_helper
INFO - 2023-09-27 15:23:42 --> Helper loaded: form_helper
INFO - 2023-09-27 15:23:42 --> Helper loaded: my_helper
INFO - 2023-09-27 15:23:42 --> Database Driver Class Initialized
INFO - 2023-09-27 15:23:42 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-27 15:23:42 --> Controller Class Initialized
DEBUG - 2023-09-27 15:23:42 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/views/list.php
DEBUG - 2023-09-27 15:23:42 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-09-27 15:23:42 --> Final output sent to browser
DEBUG - 2023-09-27 15:23:42 --> Total execution time: 0.0401
INFO - 2023-09-27 15:23:43 --> Config Class Initialized
INFO - 2023-09-27 15:23:43 --> Hooks Class Initialized
DEBUG - 2023-09-27 15:23:43 --> UTF-8 Support Enabled
INFO - 2023-09-27 15:23:43 --> Utf8 Class Initialized
INFO - 2023-09-27 15:23:43 --> URI Class Initialized
INFO - 2023-09-27 15:23:43 --> Router Class Initialized
INFO - 2023-09-27 15:23:43 --> Output Class Initialized
INFO - 2023-09-27 15:23:43 --> Security Class Initialized
DEBUG - 2023-09-27 15:23:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-27 15:23:43 --> Input Class Initialized
INFO - 2023-09-27 15:23:43 --> Language Class Initialized
INFO - 2023-09-27 15:23:43 --> Language Class Initialized
INFO - 2023-09-27 15:23:43 --> Config Class Initialized
INFO - 2023-09-27 15:23:43 --> Loader Class Initialized
INFO - 2023-09-27 15:23:43 --> Helper loaded: url_helper
INFO - 2023-09-27 15:23:43 --> Helper loaded: file_helper
INFO - 2023-09-27 15:23:43 --> Helper loaded: form_helper
INFO - 2023-09-27 15:23:43 --> Helper loaded: my_helper
INFO - 2023-09-27 15:23:43 --> Database Driver Class Initialized
INFO - 2023-09-27 15:23:43 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-27 15:23:43 --> Controller Class Initialized
INFO - 2023-09-27 15:23:48 --> Config Class Initialized
INFO - 2023-09-27 15:23:48 --> Hooks Class Initialized
DEBUG - 2023-09-27 15:23:48 --> UTF-8 Support Enabled
INFO - 2023-09-27 15:23:48 --> Utf8 Class Initialized
INFO - 2023-09-27 15:23:48 --> URI Class Initialized
INFO - 2023-09-27 15:23:48 --> Router Class Initialized
INFO - 2023-09-27 15:23:48 --> Output Class Initialized
INFO - 2023-09-27 15:23:48 --> Security Class Initialized
DEBUG - 2023-09-27 15:23:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-27 15:23:48 --> Input Class Initialized
INFO - 2023-09-27 15:23:48 --> Language Class Initialized
INFO - 2023-09-27 15:23:48 --> Language Class Initialized
INFO - 2023-09-27 15:23:48 --> Config Class Initialized
INFO - 2023-09-27 15:23:48 --> Loader Class Initialized
INFO - 2023-09-27 15:23:48 --> Helper loaded: url_helper
INFO - 2023-09-27 15:23:48 --> Helper loaded: file_helper
INFO - 2023-09-27 15:23:48 --> Helper loaded: form_helper
INFO - 2023-09-27 15:23:48 --> Helper loaded: my_helper
INFO - 2023-09-27 15:23:48 --> Database Driver Class Initialized
INFO - 2023-09-27 15:23:48 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-27 15:23:48 --> Controller Class Initialized
INFO - 2023-09-27 15:23:48 --> Final output sent to browser
DEBUG - 2023-09-27 15:23:48 --> Total execution time: 0.1796
INFO - 2023-09-27 15:23:55 --> Config Class Initialized
INFO - 2023-09-27 15:23:55 --> Hooks Class Initialized
DEBUG - 2023-09-27 15:23:55 --> UTF-8 Support Enabled
INFO - 2023-09-27 15:23:55 --> Utf8 Class Initialized
INFO - 2023-09-27 15:23:55 --> URI Class Initialized
INFO - 2023-09-27 15:23:55 --> Router Class Initialized
INFO - 2023-09-27 15:23:55 --> Output Class Initialized
INFO - 2023-09-27 15:23:55 --> Security Class Initialized
DEBUG - 2023-09-27 15:23:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-27 15:23:55 --> Input Class Initialized
INFO - 2023-09-27 15:23:55 --> Language Class Initialized
INFO - 2023-09-27 15:23:55 --> Language Class Initialized
INFO - 2023-09-27 15:23:55 --> Config Class Initialized
INFO - 2023-09-27 15:23:55 --> Loader Class Initialized
INFO - 2023-09-27 15:23:55 --> Helper loaded: url_helper
INFO - 2023-09-27 15:23:55 --> Helper loaded: file_helper
INFO - 2023-09-27 15:23:55 --> Helper loaded: form_helper
INFO - 2023-09-27 15:23:55 --> Helper loaded: my_helper
INFO - 2023-09-27 15:23:56 --> Database Driver Class Initialized
INFO - 2023-09-27 15:23:56 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-27 15:23:56 --> Controller Class Initialized
INFO - 2023-09-27 15:23:56 --> Final output sent to browser
DEBUG - 2023-09-27 15:23:56 --> Total execution time: 0.1804
INFO - 2023-09-27 15:24:04 --> Config Class Initialized
INFO - 2023-09-27 15:24:04 --> Hooks Class Initialized
DEBUG - 2023-09-27 15:24:04 --> UTF-8 Support Enabled
INFO - 2023-09-27 15:24:04 --> Utf8 Class Initialized
INFO - 2023-09-27 15:24:04 --> URI Class Initialized
INFO - 2023-09-27 15:24:04 --> Router Class Initialized
INFO - 2023-09-27 15:24:04 --> Output Class Initialized
INFO - 2023-09-27 15:24:04 --> Security Class Initialized
DEBUG - 2023-09-27 15:24:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-27 15:24:04 --> Input Class Initialized
INFO - 2023-09-27 15:24:04 --> Language Class Initialized
INFO - 2023-09-27 15:24:05 --> Language Class Initialized
INFO - 2023-09-27 15:24:05 --> Config Class Initialized
INFO - 2023-09-27 15:24:05 --> Loader Class Initialized
INFO - 2023-09-27 15:24:05 --> Helper loaded: url_helper
INFO - 2023-09-27 15:24:05 --> Helper loaded: file_helper
INFO - 2023-09-27 15:24:05 --> Helper loaded: form_helper
INFO - 2023-09-27 15:24:05 --> Helper loaded: my_helper
INFO - 2023-09-27 15:24:05 --> Database Driver Class Initialized
INFO - 2023-09-27 15:24:05 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-27 15:24:05 --> Controller Class Initialized
INFO - 2023-09-27 15:24:05 --> Final output sent to browser
DEBUG - 2023-09-27 15:24:05 --> Total execution time: 0.3088
INFO - 2023-09-27 15:24:09 --> Config Class Initialized
INFO - 2023-09-27 15:24:09 --> Hooks Class Initialized
DEBUG - 2023-09-27 15:24:09 --> UTF-8 Support Enabled
INFO - 2023-09-27 15:24:09 --> Utf8 Class Initialized
INFO - 2023-09-27 15:24:09 --> URI Class Initialized
INFO - 2023-09-27 15:24:09 --> Router Class Initialized
INFO - 2023-09-27 15:24:09 --> Output Class Initialized
INFO - 2023-09-27 15:24:09 --> Security Class Initialized
DEBUG - 2023-09-27 15:24:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-27 15:24:09 --> Input Class Initialized
INFO - 2023-09-27 15:24:09 --> Language Class Initialized
INFO - 2023-09-27 15:24:09 --> Language Class Initialized
INFO - 2023-09-27 15:24:09 --> Config Class Initialized
INFO - 2023-09-27 15:24:09 --> Loader Class Initialized
INFO - 2023-09-27 15:24:09 --> Helper loaded: url_helper
INFO - 2023-09-27 15:24:09 --> Helper loaded: file_helper
INFO - 2023-09-27 15:24:09 --> Helper loaded: form_helper
INFO - 2023-09-27 15:24:09 --> Helper loaded: my_helper
INFO - 2023-09-27 15:24:09 --> Database Driver Class Initialized
INFO - 2023-09-27 15:24:09 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-27 15:24:09 --> Controller Class Initialized
INFO - 2023-09-27 15:24:09 --> Final output sent to browser
DEBUG - 2023-09-27 15:24:09 --> Total execution time: 0.0565
INFO - 2023-09-27 15:24:19 --> Config Class Initialized
INFO - 2023-09-27 15:24:19 --> Hooks Class Initialized
DEBUG - 2023-09-27 15:24:19 --> UTF-8 Support Enabled
INFO - 2023-09-27 15:24:19 --> Utf8 Class Initialized
INFO - 2023-09-27 15:24:19 --> URI Class Initialized
INFO - 2023-09-27 15:24:19 --> Router Class Initialized
INFO - 2023-09-27 15:24:19 --> Output Class Initialized
INFO - 2023-09-27 15:24:19 --> Security Class Initialized
DEBUG - 2023-09-27 15:24:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-27 15:24:19 --> Input Class Initialized
INFO - 2023-09-27 15:24:19 --> Language Class Initialized
INFO - 2023-09-27 15:24:19 --> Language Class Initialized
INFO - 2023-09-27 15:24:19 --> Config Class Initialized
INFO - 2023-09-27 15:24:19 --> Loader Class Initialized
INFO - 2023-09-27 15:24:19 --> Helper loaded: url_helper
INFO - 2023-09-27 15:24:20 --> Helper loaded: file_helper
INFO - 2023-09-27 15:24:20 --> Helper loaded: form_helper
INFO - 2023-09-27 15:24:20 --> Helper loaded: my_helper
INFO - 2023-09-27 15:24:20 --> Database Driver Class Initialized
INFO - 2023-09-27 15:24:20 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-27 15:24:20 --> Controller Class Initialized
INFO - 2023-09-27 15:24:20 --> Final output sent to browser
DEBUG - 2023-09-27 15:24:20 --> Total execution time: 0.7372
INFO - 2023-09-27 15:24:24 --> Config Class Initialized
INFO - 2023-09-27 15:24:24 --> Hooks Class Initialized
DEBUG - 2023-09-27 15:24:24 --> UTF-8 Support Enabled
INFO - 2023-09-27 15:24:24 --> Utf8 Class Initialized
INFO - 2023-09-27 15:24:24 --> URI Class Initialized
INFO - 2023-09-27 15:24:24 --> Router Class Initialized
INFO - 2023-09-27 15:24:24 --> Output Class Initialized
INFO - 2023-09-27 15:24:24 --> Security Class Initialized
DEBUG - 2023-09-27 15:24:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-27 15:24:24 --> Input Class Initialized
INFO - 2023-09-27 15:24:24 --> Language Class Initialized
INFO - 2023-09-27 15:24:24 --> Language Class Initialized
INFO - 2023-09-27 15:24:24 --> Config Class Initialized
INFO - 2023-09-27 15:24:24 --> Loader Class Initialized
INFO - 2023-09-27 15:24:24 --> Helper loaded: url_helper
INFO - 2023-09-27 15:24:24 --> Helper loaded: file_helper
INFO - 2023-09-27 15:24:24 --> Helper loaded: form_helper
INFO - 2023-09-27 15:24:24 --> Helper loaded: my_helper
INFO - 2023-09-27 15:24:24 --> Database Driver Class Initialized
INFO - 2023-09-27 15:24:24 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-27 15:24:24 --> Controller Class Initialized
INFO - 2023-09-27 15:24:24 --> Final output sent to browser
DEBUG - 2023-09-27 15:24:24 --> Total execution time: 0.0772
INFO - 2023-09-27 15:24:29 --> Config Class Initialized
INFO - 2023-09-27 15:24:29 --> Hooks Class Initialized
DEBUG - 2023-09-27 15:24:29 --> UTF-8 Support Enabled
INFO - 2023-09-27 15:24:29 --> Utf8 Class Initialized
INFO - 2023-09-27 15:24:29 --> URI Class Initialized
INFO - 2023-09-27 15:24:29 --> Router Class Initialized
INFO - 2023-09-27 15:24:29 --> Output Class Initialized
INFO - 2023-09-27 15:24:29 --> Security Class Initialized
DEBUG - 2023-09-27 15:24:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-27 15:24:29 --> Input Class Initialized
INFO - 2023-09-27 15:24:29 --> Language Class Initialized
INFO - 2023-09-27 15:24:29 --> Language Class Initialized
INFO - 2023-09-27 15:24:29 --> Config Class Initialized
INFO - 2023-09-27 15:24:29 --> Loader Class Initialized
INFO - 2023-09-27 15:24:29 --> Helper loaded: url_helper
INFO - 2023-09-27 15:24:29 --> Helper loaded: file_helper
INFO - 2023-09-27 15:24:29 --> Helper loaded: form_helper
INFO - 2023-09-27 15:24:29 --> Helper loaded: my_helper
INFO - 2023-09-27 15:24:29 --> Database Driver Class Initialized
INFO - 2023-09-27 15:24:29 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-27 15:24:29 --> Controller Class Initialized
INFO - 2023-09-27 15:24:29 --> Final output sent to browser
DEBUG - 2023-09-27 15:24:29 --> Total execution time: 0.0850
INFO - 2023-09-27 15:24:36 --> Config Class Initialized
INFO - 2023-09-27 15:24:36 --> Hooks Class Initialized
DEBUG - 2023-09-27 15:24:36 --> UTF-8 Support Enabled
INFO - 2023-09-27 15:24:36 --> Utf8 Class Initialized
INFO - 2023-09-27 15:24:36 --> URI Class Initialized
INFO - 2023-09-27 15:24:36 --> Router Class Initialized
INFO - 2023-09-27 15:24:36 --> Output Class Initialized
INFO - 2023-09-27 15:24:36 --> Security Class Initialized
DEBUG - 2023-09-27 15:24:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-27 15:24:36 --> Input Class Initialized
INFO - 2023-09-27 15:24:36 --> Language Class Initialized
INFO - 2023-09-27 15:24:36 --> Language Class Initialized
INFO - 2023-09-27 15:24:36 --> Config Class Initialized
INFO - 2023-09-27 15:24:36 --> Loader Class Initialized
INFO - 2023-09-27 15:24:36 --> Helper loaded: url_helper
INFO - 2023-09-27 15:24:36 --> Helper loaded: file_helper
INFO - 2023-09-27 15:24:36 --> Helper loaded: form_helper
INFO - 2023-09-27 15:24:36 --> Helper loaded: my_helper
INFO - 2023-09-27 15:24:36 --> Database Driver Class Initialized
INFO - 2023-09-27 15:24:36 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-27 15:24:36 --> Controller Class Initialized
INFO - 2023-09-27 15:24:36 --> Final output sent to browser
DEBUG - 2023-09-27 15:24:36 --> Total execution time: 0.0359
INFO - 2023-09-27 15:24:40 --> Config Class Initialized
INFO - 2023-09-27 15:24:40 --> Hooks Class Initialized
DEBUG - 2023-09-27 15:24:40 --> UTF-8 Support Enabled
INFO - 2023-09-27 15:24:40 --> Utf8 Class Initialized
INFO - 2023-09-27 15:24:40 --> URI Class Initialized
INFO - 2023-09-27 15:24:40 --> Router Class Initialized
INFO - 2023-09-27 15:24:40 --> Output Class Initialized
INFO - 2023-09-27 15:24:40 --> Security Class Initialized
DEBUG - 2023-09-27 15:24:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-27 15:24:40 --> Input Class Initialized
INFO - 2023-09-27 15:24:40 --> Language Class Initialized
INFO - 2023-09-27 15:24:40 --> Language Class Initialized
INFO - 2023-09-27 15:24:40 --> Config Class Initialized
INFO - 2023-09-27 15:24:40 --> Loader Class Initialized
INFO - 2023-09-27 15:24:40 --> Helper loaded: url_helper
INFO - 2023-09-27 15:24:40 --> Helper loaded: file_helper
INFO - 2023-09-27 15:24:40 --> Helper loaded: form_helper
INFO - 2023-09-27 15:24:40 --> Helper loaded: my_helper
INFO - 2023-09-27 15:24:40 --> Database Driver Class Initialized
INFO - 2023-09-27 15:24:40 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-27 15:24:40 --> Controller Class Initialized
INFO - 2023-09-27 15:24:40 --> Final output sent to browser
DEBUG - 2023-09-27 15:24:40 --> Total execution time: 0.1705
INFO - 2023-09-27 22:58:48 --> Config Class Initialized
INFO - 2023-09-27 22:58:48 --> Hooks Class Initialized
DEBUG - 2023-09-27 22:58:48 --> UTF-8 Support Enabled
INFO - 2023-09-27 22:58:48 --> Utf8 Class Initialized
INFO - 2023-09-27 22:58:48 --> URI Class Initialized
INFO - 2023-09-27 22:58:48 --> Router Class Initialized
INFO - 2023-09-27 22:58:48 --> Output Class Initialized
INFO - 2023-09-27 22:58:48 --> Security Class Initialized
DEBUG - 2023-09-27 22:58:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-27 22:58:48 --> Input Class Initialized
INFO - 2023-09-27 22:58:48 --> Language Class Initialized
INFO - 2023-09-27 22:58:48 --> Language Class Initialized
INFO - 2023-09-27 22:58:48 --> Config Class Initialized
INFO - 2023-09-27 22:58:48 --> Loader Class Initialized
INFO - 2023-09-27 22:58:48 --> Helper loaded: url_helper
INFO - 2023-09-27 22:58:48 --> Helper loaded: file_helper
INFO - 2023-09-27 22:58:48 --> Helper loaded: form_helper
INFO - 2023-09-27 22:58:48 --> Helper loaded: my_helper
INFO - 2023-09-27 22:58:48 --> Database Driver Class Initialized
INFO - 2023-09-27 22:58:48 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-27 22:58:48 --> Controller Class Initialized
INFO - 2023-09-27 22:58:48 --> Config Class Initialized
INFO - 2023-09-27 22:58:48 --> Hooks Class Initialized
DEBUG - 2023-09-27 22:58:48 --> UTF-8 Support Enabled
INFO - 2023-09-27 22:58:48 --> Utf8 Class Initialized
INFO - 2023-09-27 22:58:48 --> URI Class Initialized
INFO - 2023-09-27 22:58:48 --> Router Class Initialized
INFO - 2023-09-27 22:58:48 --> Output Class Initialized
INFO - 2023-09-27 22:58:48 --> Security Class Initialized
DEBUG - 2023-09-27 22:58:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-27 22:58:48 --> Input Class Initialized
INFO - 2023-09-27 22:58:48 --> Language Class Initialized
INFO - 2023-09-27 22:58:48 --> Language Class Initialized
INFO - 2023-09-27 22:58:48 --> Config Class Initialized
INFO - 2023-09-27 22:58:48 --> Loader Class Initialized
INFO - 2023-09-27 22:58:48 --> Helper loaded: url_helper
INFO - 2023-09-27 22:58:48 --> Helper loaded: file_helper
INFO - 2023-09-27 22:58:48 --> Helper loaded: form_helper
INFO - 2023-09-27 22:58:48 --> Helper loaded: my_helper
INFO - 2023-09-27 22:58:48 --> Database Driver Class Initialized
INFO - 2023-09-27 22:58:48 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-27 22:58:48 --> Controller Class Initialized
DEBUG - 2023-09-27 22:58:48 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/login/views/login.php
DEBUG - 2023-09-27 22:58:48 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-09-27 22:58:48 --> Final output sent to browser
DEBUG - 2023-09-27 22:58:48 --> Total execution time: 0.0397
INFO - 2023-09-27 22:58:52 --> Config Class Initialized
INFO - 2023-09-27 22:58:52 --> Hooks Class Initialized
DEBUG - 2023-09-27 22:58:52 --> UTF-8 Support Enabled
INFO - 2023-09-27 22:58:52 --> Utf8 Class Initialized
INFO - 2023-09-27 22:58:52 --> URI Class Initialized
INFO - 2023-09-27 22:58:52 --> Router Class Initialized
INFO - 2023-09-27 22:58:52 --> Output Class Initialized
INFO - 2023-09-27 22:58:52 --> Security Class Initialized
DEBUG - 2023-09-27 22:58:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-27 22:58:52 --> Input Class Initialized
INFO - 2023-09-27 22:58:52 --> Language Class Initialized
INFO - 2023-09-27 22:58:52 --> Language Class Initialized
INFO - 2023-09-27 22:58:52 --> Config Class Initialized
INFO - 2023-09-27 22:58:52 --> Loader Class Initialized
INFO - 2023-09-27 22:58:52 --> Helper loaded: url_helper
INFO - 2023-09-27 22:58:52 --> Helper loaded: file_helper
INFO - 2023-09-27 22:58:52 --> Helper loaded: form_helper
INFO - 2023-09-27 22:58:52 --> Helper loaded: my_helper
INFO - 2023-09-27 22:58:52 --> Database Driver Class Initialized
INFO - 2023-09-27 22:58:52 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-27 22:58:52 --> Controller Class Initialized
INFO - 2023-09-27 22:58:52 --> Helper loaded: cookie_helper
INFO - 2023-09-27 22:58:52 --> Final output sent to browser
DEBUG - 2023-09-27 22:58:52 --> Total execution time: 0.0449
INFO - 2023-09-27 22:58:52 --> Config Class Initialized
INFO - 2023-09-27 22:58:52 --> Hooks Class Initialized
DEBUG - 2023-09-27 22:58:52 --> UTF-8 Support Enabled
INFO - 2023-09-27 22:58:52 --> Utf8 Class Initialized
INFO - 2023-09-27 22:58:52 --> URI Class Initialized
INFO - 2023-09-27 22:58:52 --> Router Class Initialized
INFO - 2023-09-27 22:58:52 --> Output Class Initialized
INFO - 2023-09-27 22:58:52 --> Security Class Initialized
DEBUG - 2023-09-27 22:58:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-27 22:58:52 --> Input Class Initialized
INFO - 2023-09-27 22:58:52 --> Language Class Initialized
INFO - 2023-09-27 22:58:52 --> Language Class Initialized
INFO - 2023-09-27 22:58:52 --> Config Class Initialized
INFO - 2023-09-27 22:58:52 --> Loader Class Initialized
INFO - 2023-09-27 22:58:52 --> Helper loaded: url_helper
INFO - 2023-09-27 22:58:52 --> Helper loaded: file_helper
INFO - 2023-09-27 22:58:52 --> Helper loaded: form_helper
INFO - 2023-09-27 22:58:52 --> Helper loaded: my_helper
INFO - 2023-09-27 22:58:52 --> Database Driver Class Initialized
INFO - 2023-09-27 22:58:52 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-27 22:58:52 --> Controller Class Initialized
DEBUG - 2023-09-27 22:58:52 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/home/views/v_home_guru.php
DEBUG - 2023-09-27 22:58:52 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-09-27 22:58:52 --> Final output sent to browser
DEBUG - 2023-09-27 22:58:52 --> Total execution time: 0.0429
INFO - 2023-09-27 22:58:55 --> Config Class Initialized
INFO - 2023-09-27 22:58:55 --> Hooks Class Initialized
DEBUG - 2023-09-27 22:58:55 --> UTF-8 Support Enabled
INFO - 2023-09-27 22:58:55 --> Utf8 Class Initialized
INFO - 2023-09-27 22:58:55 --> URI Class Initialized
INFO - 2023-09-27 22:58:55 --> Router Class Initialized
INFO - 2023-09-27 22:58:55 --> Output Class Initialized
INFO - 2023-09-27 22:58:55 --> Security Class Initialized
DEBUG - 2023-09-27 22:58:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-27 22:58:55 --> Input Class Initialized
INFO - 2023-09-27 22:58:55 --> Language Class Initialized
INFO - 2023-09-27 22:58:55 --> Language Class Initialized
INFO - 2023-09-27 22:58:55 --> Config Class Initialized
INFO - 2023-09-27 22:58:55 --> Loader Class Initialized
INFO - 2023-09-27 22:58:55 --> Helper loaded: url_helper
INFO - 2023-09-27 22:58:55 --> Helper loaded: file_helper
INFO - 2023-09-27 22:58:55 --> Helper loaded: form_helper
INFO - 2023-09-27 22:58:55 --> Helper loaded: my_helper
INFO - 2023-09-27 22:58:55 --> Database Driver Class Initialized
INFO - 2023-09-27 22:58:55 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-27 22:58:55 --> Controller Class Initialized
DEBUG - 2023-09-27 22:58:55 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/view_mapel/views/v_view_mapel.php
DEBUG - 2023-09-27 22:58:55 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-09-27 22:58:55 --> Final output sent to browser
DEBUG - 2023-09-27 22:58:55 --> Total execution time: 0.0407
INFO - 2023-09-27 22:58:57 --> Config Class Initialized
INFO - 2023-09-27 22:58:57 --> Hooks Class Initialized
DEBUG - 2023-09-27 22:58:57 --> UTF-8 Support Enabled
INFO - 2023-09-27 22:58:57 --> Utf8 Class Initialized
INFO - 2023-09-27 22:58:57 --> URI Class Initialized
INFO - 2023-09-27 22:58:57 --> Router Class Initialized
INFO - 2023-09-27 22:58:57 --> Output Class Initialized
INFO - 2023-09-27 22:58:57 --> Security Class Initialized
DEBUG - 2023-09-27 22:58:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-27 22:58:57 --> Input Class Initialized
INFO - 2023-09-27 22:58:57 --> Language Class Initialized
INFO - 2023-09-27 22:58:57 --> Language Class Initialized
INFO - 2023-09-27 22:58:57 --> Config Class Initialized
INFO - 2023-09-27 22:58:57 --> Loader Class Initialized
INFO - 2023-09-27 22:58:57 --> Helper loaded: url_helper
INFO - 2023-09-27 22:58:57 --> Helper loaded: file_helper
INFO - 2023-09-27 22:58:57 --> Helper loaded: form_helper
INFO - 2023-09-27 22:58:57 --> Helper loaded: my_helper
INFO - 2023-09-27 22:58:57 --> Database Driver Class Initialized
INFO - 2023-09-27 22:58:57 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-27 22:58:57 --> Controller Class Initialized
DEBUG - 2023-09-27 22:58:57 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/views/list.php
DEBUG - 2023-09-27 22:58:57 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-09-27 22:58:57 --> Final output sent to browser
DEBUG - 2023-09-27 22:58:57 --> Total execution time: 0.0717
INFO - 2023-09-27 22:58:57 --> Config Class Initialized
INFO - 2023-09-27 22:58:57 --> Hooks Class Initialized
DEBUG - 2023-09-27 22:58:57 --> UTF-8 Support Enabled
INFO - 2023-09-27 22:58:57 --> Utf8 Class Initialized
INFO - 2023-09-27 22:58:57 --> URI Class Initialized
INFO - 2023-09-27 22:58:57 --> Router Class Initialized
INFO - 2023-09-27 22:58:57 --> Output Class Initialized
INFO - 2023-09-27 22:58:57 --> Security Class Initialized
DEBUG - 2023-09-27 22:58:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-27 22:58:57 --> Input Class Initialized
INFO - 2023-09-27 22:58:57 --> Language Class Initialized
INFO - 2023-09-27 22:58:57 --> Language Class Initialized
INFO - 2023-09-27 22:58:57 --> Config Class Initialized
INFO - 2023-09-27 22:58:57 --> Loader Class Initialized
INFO - 2023-09-27 22:58:57 --> Helper loaded: url_helper
INFO - 2023-09-27 22:58:57 --> Helper loaded: file_helper
INFO - 2023-09-27 22:58:57 --> Helper loaded: form_helper
INFO - 2023-09-27 22:58:57 --> Helper loaded: my_helper
INFO - 2023-09-27 22:58:57 --> Database Driver Class Initialized
INFO - 2023-09-27 22:58:57 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-27 22:58:57 --> Controller Class Initialized
INFO - 2023-09-27 22:59:28 --> Config Class Initialized
INFO - 2023-09-27 22:59:28 --> Hooks Class Initialized
DEBUG - 2023-09-27 22:59:28 --> UTF-8 Support Enabled
INFO - 2023-09-27 22:59:28 --> Utf8 Class Initialized
INFO - 2023-09-27 22:59:28 --> URI Class Initialized
INFO - 2023-09-27 22:59:28 --> Router Class Initialized
INFO - 2023-09-27 22:59:28 --> Output Class Initialized
INFO - 2023-09-27 22:59:28 --> Security Class Initialized
DEBUG - 2023-09-27 22:59:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-27 22:59:28 --> Input Class Initialized
INFO - 2023-09-27 22:59:28 --> Language Class Initialized
INFO - 2023-09-27 22:59:28 --> Language Class Initialized
INFO - 2023-09-27 22:59:28 --> Config Class Initialized
INFO - 2023-09-27 22:59:28 --> Loader Class Initialized
INFO - 2023-09-27 22:59:28 --> Helper loaded: url_helper
INFO - 2023-09-27 22:59:28 --> Helper loaded: file_helper
INFO - 2023-09-27 22:59:28 --> Helper loaded: form_helper
INFO - 2023-09-27 22:59:28 --> Helper loaded: my_helper
INFO - 2023-09-27 22:59:28 --> Database Driver Class Initialized
INFO - 2023-09-27 22:59:28 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-27 22:59:28 --> Controller Class Initialized
INFO - 2023-09-27 22:59:28 --> Final output sent to browser
DEBUG - 2023-09-27 22:59:28 --> Total execution time: 0.0349
INFO - 2023-09-27 23:01:04 --> Config Class Initialized
INFO - 2023-09-27 23:01:04 --> Hooks Class Initialized
DEBUG - 2023-09-27 23:01:04 --> UTF-8 Support Enabled
INFO - 2023-09-27 23:01:04 --> Utf8 Class Initialized
INFO - 2023-09-27 23:01:04 --> URI Class Initialized
INFO - 2023-09-27 23:01:04 --> Router Class Initialized
INFO - 2023-09-27 23:01:04 --> Output Class Initialized
INFO - 2023-09-27 23:01:04 --> Security Class Initialized
DEBUG - 2023-09-27 23:01:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-27 23:01:04 --> Input Class Initialized
INFO - 2023-09-27 23:01:04 --> Language Class Initialized
INFO - 2023-09-27 23:01:04 --> Language Class Initialized
INFO - 2023-09-27 23:01:04 --> Config Class Initialized
INFO - 2023-09-27 23:01:04 --> Loader Class Initialized
INFO - 2023-09-27 23:01:04 --> Helper loaded: url_helper
INFO - 2023-09-27 23:01:04 --> Helper loaded: file_helper
INFO - 2023-09-27 23:01:04 --> Helper loaded: form_helper
INFO - 2023-09-27 23:01:04 --> Helper loaded: my_helper
INFO - 2023-09-27 23:01:04 --> Database Driver Class Initialized
INFO - 2023-09-27 23:01:04 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-27 23:01:04 --> Controller Class Initialized
INFO - 2023-09-27 23:01:04 --> Final output sent to browser
DEBUG - 2023-09-27 23:01:04 --> Total execution time: 0.1185
INFO - 2023-09-27 23:01:10 --> Config Class Initialized
INFO - 2023-09-27 23:01:10 --> Hooks Class Initialized
DEBUG - 2023-09-27 23:01:10 --> UTF-8 Support Enabled
INFO - 2023-09-27 23:01:10 --> Utf8 Class Initialized
INFO - 2023-09-27 23:01:10 --> URI Class Initialized
INFO - 2023-09-27 23:01:10 --> Router Class Initialized
INFO - 2023-09-27 23:01:10 --> Output Class Initialized
INFO - 2023-09-27 23:01:10 --> Security Class Initialized
DEBUG - 2023-09-27 23:01:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-27 23:01:10 --> Input Class Initialized
INFO - 2023-09-27 23:01:10 --> Language Class Initialized
INFO - 2023-09-27 23:01:10 --> Language Class Initialized
INFO - 2023-09-27 23:01:10 --> Config Class Initialized
INFO - 2023-09-27 23:01:10 --> Loader Class Initialized
INFO - 2023-09-27 23:01:10 --> Helper loaded: url_helper
INFO - 2023-09-27 23:01:10 --> Helper loaded: file_helper
INFO - 2023-09-27 23:01:10 --> Helper loaded: form_helper
INFO - 2023-09-27 23:01:10 --> Helper loaded: my_helper
INFO - 2023-09-27 23:01:10 --> Database Driver Class Initialized
INFO - 2023-09-27 23:01:10 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-27 23:01:10 --> Controller Class Initialized
INFO - 2023-09-27 23:01:10 --> Final output sent to browser
DEBUG - 2023-09-27 23:01:10 --> Total execution time: 0.0409
INFO - 2023-09-27 23:01:10 --> Config Class Initialized
INFO - 2023-09-27 23:01:10 --> Hooks Class Initialized
DEBUG - 2023-09-27 23:01:10 --> UTF-8 Support Enabled
INFO - 2023-09-27 23:01:10 --> Utf8 Class Initialized
INFO - 2023-09-27 23:01:10 --> URI Class Initialized
INFO - 2023-09-27 23:01:10 --> Router Class Initialized
INFO - 2023-09-27 23:01:10 --> Output Class Initialized
INFO - 2023-09-27 23:01:10 --> Security Class Initialized
DEBUG - 2023-09-27 23:01:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-27 23:01:10 --> Input Class Initialized
INFO - 2023-09-27 23:01:10 --> Language Class Initialized
INFO - 2023-09-27 23:01:10 --> Language Class Initialized
INFO - 2023-09-27 23:01:10 --> Config Class Initialized
INFO - 2023-09-27 23:01:10 --> Loader Class Initialized
INFO - 2023-09-27 23:01:10 --> Helper loaded: url_helper
INFO - 2023-09-27 23:01:10 --> Helper loaded: file_helper
INFO - 2023-09-27 23:01:10 --> Helper loaded: form_helper
INFO - 2023-09-27 23:01:10 --> Helper loaded: my_helper
INFO - 2023-09-27 23:01:10 --> Database Driver Class Initialized
INFO - 2023-09-27 23:01:10 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-27 23:01:10 --> Controller Class Initialized
INFO - 2023-09-27 23:01:12 --> Config Class Initialized
INFO - 2023-09-27 23:01:12 --> Hooks Class Initialized
DEBUG - 2023-09-27 23:01:12 --> UTF-8 Support Enabled
INFO - 2023-09-27 23:01:12 --> Utf8 Class Initialized
INFO - 2023-09-27 23:01:12 --> URI Class Initialized
INFO - 2023-09-27 23:01:12 --> Router Class Initialized
INFO - 2023-09-27 23:01:12 --> Output Class Initialized
INFO - 2023-09-27 23:01:12 --> Security Class Initialized
DEBUG - 2023-09-27 23:01:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-27 23:01:12 --> Input Class Initialized
INFO - 2023-09-27 23:01:12 --> Language Class Initialized
INFO - 2023-09-27 23:01:12 --> Language Class Initialized
INFO - 2023-09-27 23:01:12 --> Config Class Initialized
INFO - 2023-09-27 23:01:12 --> Loader Class Initialized
INFO - 2023-09-27 23:01:12 --> Helper loaded: url_helper
INFO - 2023-09-27 23:01:12 --> Helper loaded: file_helper
INFO - 2023-09-27 23:01:12 --> Helper loaded: form_helper
INFO - 2023-09-27 23:01:12 --> Helper loaded: my_helper
INFO - 2023-09-27 23:01:12 --> Database Driver Class Initialized
INFO - 2023-09-27 23:01:12 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-27 23:01:12 --> Controller Class Initialized
INFO - 2023-09-27 23:01:12 --> Final output sent to browser
DEBUG - 2023-09-27 23:01:12 --> Total execution time: 0.0413
INFO - 2023-09-27 23:01:37 --> Config Class Initialized
INFO - 2023-09-27 23:01:37 --> Hooks Class Initialized
DEBUG - 2023-09-27 23:01:37 --> UTF-8 Support Enabled
INFO - 2023-09-27 23:01:37 --> Utf8 Class Initialized
INFO - 2023-09-27 23:01:37 --> URI Class Initialized
INFO - 2023-09-27 23:01:37 --> Router Class Initialized
INFO - 2023-09-27 23:01:37 --> Output Class Initialized
INFO - 2023-09-27 23:01:37 --> Security Class Initialized
DEBUG - 2023-09-27 23:01:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-27 23:01:37 --> Input Class Initialized
INFO - 2023-09-27 23:01:37 --> Language Class Initialized
INFO - 2023-09-27 23:01:37 --> Language Class Initialized
INFO - 2023-09-27 23:01:37 --> Config Class Initialized
INFO - 2023-09-27 23:01:37 --> Loader Class Initialized
INFO - 2023-09-27 23:01:37 --> Helper loaded: url_helper
INFO - 2023-09-27 23:01:37 --> Helper loaded: file_helper
INFO - 2023-09-27 23:01:37 --> Helper loaded: form_helper
INFO - 2023-09-27 23:01:37 --> Helper loaded: my_helper
INFO - 2023-09-27 23:01:37 --> Database Driver Class Initialized
INFO - 2023-09-27 23:01:37 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-27 23:01:37 --> Controller Class Initialized
INFO - 2023-09-27 23:01:37 --> Final output sent to browser
DEBUG - 2023-09-27 23:01:37 --> Total execution time: 0.0464
INFO - 2023-09-27 23:01:38 --> Config Class Initialized
INFO - 2023-09-27 23:01:38 --> Hooks Class Initialized
DEBUG - 2023-09-27 23:01:38 --> UTF-8 Support Enabled
INFO - 2023-09-27 23:01:38 --> Utf8 Class Initialized
INFO - 2023-09-27 23:01:38 --> URI Class Initialized
INFO - 2023-09-27 23:01:38 --> Router Class Initialized
INFO - 2023-09-27 23:01:38 --> Output Class Initialized
INFO - 2023-09-27 23:01:38 --> Security Class Initialized
DEBUG - 2023-09-27 23:01:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-27 23:01:38 --> Input Class Initialized
INFO - 2023-09-27 23:01:38 --> Language Class Initialized
INFO - 2023-09-27 23:01:38 --> Language Class Initialized
INFO - 2023-09-27 23:01:38 --> Config Class Initialized
INFO - 2023-09-27 23:01:38 --> Loader Class Initialized
INFO - 2023-09-27 23:01:38 --> Helper loaded: url_helper
INFO - 2023-09-27 23:01:38 --> Helper loaded: file_helper
INFO - 2023-09-27 23:01:38 --> Helper loaded: form_helper
INFO - 2023-09-27 23:01:38 --> Helper loaded: my_helper
INFO - 2023-09-27 23:01:38 --> Database Driver Class Initialized
INFO - 2023-09-27 23:01:38 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-27 23:01:38 --> Controller Class Initialized
INFO - 2023-09-27 23:01:42 --> Config Class Initialized
INFO - 2023-09-27 23:01:42 --> Hooks Class Initialized
DEBUG - 2023-09-27 23:01:42 --> UTF-8 Support Enabled
INFO - 2023-09-27 23:01:42 --> Utf8 Class Initialized
INFO - 2023-09-27 23:01:42 --> URI Class Initialized
INFO - 2023-09-27 23:01:42 --> Router Class Initialized
INFO - 2023-09-27 23:01:42 --> Output Class Initialized
INFO - 2023-09-27 23:01:42 --> Security Class Initialized
DEBUG - 2023-09-27 23:01:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-27 23:01:42 --> Input Class Initialized
INFO - 2023-09-27 23:01:42 --> Language Class Initialized
INFO - 2023-09-27 23:01:42 --> Language Class Initialized
INFO - 2023-09-27 23:01:42 --> Config Class Initialized
INFO - 2023-09-27 23:01:42 --> Loader Class Initialized
INFO - 2023-09-27 23:01:42 --> Helper loaded: url_helper
INFO - 2023-09-27 23:01:42 --> Helper loaded: file_helper
INFO - 2023-09-27 23:01:42 --> Helper loaded: form_helper
INFO - 2023-09-27 23:01:42 --> Helper loaded: my_helper
INFO - 2023-09-27 23:01:42 --> Database Driver Class Initialized
INFO - 2023-09-27 23:01:42 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-27 23:01:42 --> Controller Class Initialized
INFO - 2023-09-27 23:01:42 --> Final output sent to browser
DEBUG - 2023-09-27 23:01:42 --> Total execution time: 0.2117
INFO - 2023-09-27 23:01:44 --> Config Class Initialized
INFO - 2023-09-27 23:01:44 --> Hooks Class Initialized
DEBUG - 2023-09-27 23:01:44 --> UTF-8 Support Enabled
INFO - 2023-09-27 23:01:44 --> Utf8 Class Initialized
INFO - 2023-09-27 23:01:44 --> URI Class Initialized
INFO - 2023-09-27 23:01:44 --> Router Class Initialized
INFO - 2023-09-27 23:01:44 --> Output Class Initialized
INFO - 2023-09-27 23:01:44 --> Security Class Initialized
DEBUG - 2023-09-27 23:01:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-27 23:01:44 --> Input Class Initialized
INFO - 2023-09-27 23:01:44 --> Language Class Initialized
INFO - 2023-09-27 23:01:44 --> Language Class Initialized
INFO - 2023-09-27 23:01:44 --> Config Class Initialized
INFO - 2023-09-27 23:01:44 --> Loader Class Initialized
INFO - 2023-09-27 23:01:44 --> Helper loaded: url_helper
INFO - 2023-09-27 23:01:44 --> Helper loaded: file_helper
INFO - 2023-09-27 23:01:44 --> Helper loaded: form_helper
INFO - 2023-09-27 23:01:44 --> Helper loaded: my_helper
INFO - 2023-09-27 23:01:44 --> Database Driver Class Initialized
INFO - 2023-09-27 23:01:44 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-27 23:01:44 --> Controller Class Initialized
INFO - 2023-09-27 23:10:56 --> Config Class Initialized
INFO - 2023-09-27 23:10:56 --> Hooks Class Initialized
DEBUG - 2023-09-27 23:10:56 --> UTF-8 Support Enabled
INFO - 2023-09-27 23:10:56 --> Utf8 Class Initialized
INFO - 2023-09-27 23:10:56 --> URI Class Initialized
INFO - 2023-09-27 23:10:56 --> Router Class Initialized
INFO - 2023-09-27 23:10:56 --> Output Class Initialized
INFO - 2023-09-27 23:10:56 --> Security Class Initialized
DEBUG - 2023-09-27 23:10:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-27 23:10:56 --> Input Class Initialized
INFO - 2023-09-27 23:10:56 --> Language Class Initialized
INFO - 2023-09-27 23:10:56 --> Language Class Initialized
INFO - 2023-09-27 23:10:56 --> Config Class Initialized
INFO - 2023-09-27 23:10:56 --> Loader Class Initialized
INFO - 2023-09-27 23:10:56 --> Helper loaded: url_helper
INFO - 2023-09-27 23:10:56 --> Helper loaded: file_helper
INFO - 2023-09-27 23:10:56 --> Helper loaded: form_helper
INFO - 2023-09-27 23:10:56 --> Helper loaded: my_helper
INFO - 2023-09-27 23:10:56 --> Database Driver Class Initialized
INFO - 2023-09-27 23:10:56 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-27 23:10:56 --> Controller Class Initialized
DEBUG - 2023-09-27 23:10:56 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/views/form.php
DEBUG - 2023-09-27 23:10:56 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-09-27 23:10:56 --> Final output sent to browser
DEBUG - 2023-09-27 23:10:56 --> Total execution time: 0.0753
INFO - 2023-09-27 23:11:06 --> Config Class Initialized
INFO - 2023-09-27 23:11:06 --> Hooks Class Initialized
DEBUG - 2023-09-27 23:11:06 --> UTF-8 Support Enabled
INFO - 2023-09-27 23:11:06 --> Utf8 Class Initialized
INFO - 2023-09-27 23:11:06 --> URI Class Initialized
INFO - 2023-09-27 23:11:06 --> Router Class Initialized
INFO - 2023-09-27 23:11:06 --> Output Class Initialized
INFO - 2023-09-27 23:11:06 --> Security Class Initialized
DEBUG - 2023-09-27 23:11:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-27 23:11:06 --> Input Class Initialized
INFO - 2023-09-27 23:11:06 --> Language Class Initialized
INFO - 2023-09-27 23:11:06 --> Language Class Initialized
INFO - 2023-09-27 23:11:06 --> Config Class Initialized
INFO - 2023-09-27 23:11:06 --> Loader Class Initialized
INFO - 2023-09-27 23:11:06 --> Helper loaded: url_helper
INFO - 2023-09-27 23:11:06 --> Helper loaded: file_helper
INFO - 2023-09-27 23:11:06 --> Helper loaded: form_helper
INFO - 2023-09-27 23:11:06 --> Helper loaded: my_helper
INFO - 2023-09-27 23:11:06 --> Database Driver Class Initialized
INFO - 2023-09-27 23:11:06 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-27 23:11:06 --> Controller Class Initialized
INFO - 2023-09-27 23:11:07 --> Config Class Initialized
INFO - 2023-09-27 23:11:07 --> Hooks Class Initialized
DEBUG - 2023-09-27 23:11:07 --> UTF-8 Support Enabled
INFO - 2023-09-27 23:11:07 --> Utf8 Class Initialized
INFO - 2023-09-27 23:11:07 --> URI Class Initialized
INFO - 2023-09-27 23:11:07 --> Router Class Initialized
INFO - 2023-09-27 23:11:07 --> Output Class Initialized
INFO - 2023-09-27 23:11:07 --> Security Class Initialized
DEBUG - 2023-09-27 23:11:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-27 23:11:07 --> Input Class Initialized
INFO - 2023-09-27 23:11:07 --> Language Class Initialized
INFO - 2023-09-27 23:11:07 --> Language Class Initialized
INFO - 2023-09-27 23:11:07 --> Config Class Initialized
INFO - 2023-09-27 23:11:07 --> Loader Class Initialized
INFO - 2023-09-27 23:11:07 --> Helper loaded: url_helper
INFO - 2023-09-27 23:11:07 --> Helper loaded: file_helper
INFO - 2023-09-27 23:11:07 --> Helper loaded: form_helper
INFO - 2023-09-27 23:11:07 --> Helper loaded: my_helper
INFO - 2023-09-27 23:11:07 --> Database Driver Class Initialized
INFO - 2023-09-27 23:11:07 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-27 23:11:07 --> Controller Class Initialized
DEBUG - 2023-09-27 23:11:07 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/views/list.php
DEBUG - 2023-09-27 23:11:07 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-09-27 23:11:07 --> Final output sent to browser
DEBUG - 2023-09-27 23:11:07 --> Total execution time: 0.0404
INFO - 2023-09-27 23:11:07 --> Config Class Initialized
INFO - 2023-09-27 23:11:07 --> Hooks Class Initialized
DEBUG - 2023-09-27 23:11:07 --> UTF-8 Support Enabled
INFO - 2023-09-27 23:11:07 --> Utf8 Class Initialized
INFO - 2023-09-27 23:11:07 --> URI Class Initialized
INFO - 2023-09-27 23:11:07 --> Router Class Initialized
INFO - 2023-09-27 23:11:07 --> Output Class Initialized
INFO - 2023-09-27 23:11:07 --> Security Class Initialized
DEBUG - 2023-09-27 23:11:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-27 23:11:07 --> Input Class Initialized
INFO - 2023-09-27 23:11:07 --> Language Class Initialized
INFO - 2023-09-27 23:11:07 --> Language Class Initialized
INFO - 2023-09-27 23:11:07 --> Config Class Initialized
INFO - 2023-09-27 23:11:07 --> Loader Class Initialized
INFO - 2023-09-27 23:11:07 --> Helper loaded: url_helper
INFO - 2023-09-27 23:11:07 --> Helper loaded: file_helper
INFO - 2023-09-27 23:11:07 --> Helper loaded: form_helper
INFO - 2023-09-27 23:11:07 --> Helper loaded: my_helper
INFO - 2023-09-27 23:11:07 --> Database Driver Class Initialized
INFO - 2023-09-27 23:11:07 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-27 23:11:07 --> Controller Class Initialized
INFO - 2023-09-27 23:11:10 --> Config Class Initialized
INFO - 2023-09-27 23:11:10 --> Hooks Class Initialized
DEBUG - 2023-09-27 23:11:10 --> UTF-8 Support Enabled
INFO - 2023-09-27 23:11:10 --> Utf8 Class Initialized
INFO - 2023-09-27 23:11:10 --> URI Class Initialized
INFO - 2023-09-27 23:11:10 --> Router Class Initialized
INFO - 2023-09-27 23:11:10 --> Output Class Initialized
INFO - 2023-09-27 23:11:10 --> Security Class Initialized
DEBUG - 2023-09-27 23:11:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-27 23:11:10 --> Input Class Initialized
INFO - 2023-09-27 23:11:10 --> Language Class Initialized
INFO - 2023-09-27 23:11:11 --> Language Class Initialized
INFO - 2023-09-27 23:11:11 --> Config Class Initialized
INFO - 2023-09-27 23:11:11 --> Loader Class Initialized
INFO - 2023-09-27 23:11:11 --> Helper loaded: url_helper
INFO - 2023-09-27 23:11:11 --> Helper loaded: file_helper
INFO - 2023-09-27 23:11:11 --> Helper loaded: form_helper
INFO - 2023-09-27 23:11:11 --> Helper loaded: my_helper
INFO - 2023-09-27 23:11:11 --> Database Driver Class Initialized
INFO - 2023-09-27 23:11:11 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-27 23:11:11 --> Controller Class Initialized
INFO - 2023-09-27 23:11:11 --> Final output sent to browser
DEBUG - 2023-09-27 23:11:11 --> Total execution time: 0.4744
INFO - 2023-09-27 23:11:17 --> Config Class Initialized
INFO - 2023-09-27 23:11:17 --> Hooks Class Initialized
DEBUG - 2023-09-27 23:11:17 --> UTF-8 Support Enabled
INFO - 2023-09-27 23:11:17 --> Utf8 Class Initialized
INFO - 2023-09-27 23:11:17 --> URI Class Initialized
INFO - 2023-09-27 23:11:17 --> Router Class Initialized
INFO - 2023-09-27 23:11:17 --> Output Class Initialized
INFO - 2023-09-27 23:11:17 --> Security Class Initialized
DEBUG - 2023-09-27 23:11:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-27 23:11:17 --> Input Class Initialized
INFO - 2023-09-27 23:11:17 --> Language Class Initialized
INFO - 2023-09-27 23:11:17 --> Language Class Initialized
INFO - 2023-09-27 23:11:17 --> Config Class Initialized
INFO - 2023-09-27 23:11:17 --> Loader Class Initialized
INFO - 2023-09-27 23:11:17 --> Helper loaded: url_helper
INFO - 2023-09-27 23:11:17 --> Helper loaded: file_helper
INFO - 2023-09-27 23:11:17 --> Helper loaded: form_helper
INFO - 2023-09-27 23:11:17 --> Helper loaded: my_helper
INFO - 2023-09-27 23:11:17 --> Database Driver Class Initialized
INFO - 2023-09-27 23:11:17 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-27 23:11:17 --> Controller Class Initialized
INFO - 2023-09-27 23:11:17 --> Final output sent to browser
DEBUG - 2023-09-27 23:11:17 --> Total execution time: 0.0480
INFO - 2023-09-27 23:11:23 --> Config Class Initialized
INFO - 2023-09-27 23:11:23 --> Hooks Class Initialized
DEBUG - 2023-09-27 23:11:23 --> UTF-8 Support Enabled
INFO - 2023-09-27 23:11:23 --> Utf8 Class Initialized
INFO - 2023-09-27 23:11:23 --> URI Class Initialized
INFO - 2023-09-27 23:11:23 --> Router Class Initialized
INFO - 2023-09-27 23:11:23 --> Output Class Initialized
INFO - 2023-09-27 23:11:23 --> Security Class Initialized
DEBUG - 2023-09-27 23:11:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-27 23:11:23 --> Input Class Initialized
INFO - 2023-09-27 23:11:23 --> Language Class Initialized
INFO - 2023-09-27 23:11:23 --> Language Class Initialized
INFO - 2023-09-27 23:11:23 --> Config Class Initialized
INFO - 2023-09-27 23:11:23 --> Loader Class Initialized
INFO - 2023-09-27 23:11:23 --> Helper loaded: url_helper
INFO - 2023-09-27 23:11:23 --> Helper loaded: file_helper
INFO - 2023-09-27 23:11:23 --> Helper loaded: form_helper
INFO - 2023-09-27 23:11:23 --> Helper loaded: my_helper
INFO - 2023-09-27 23:11:23 --> Database Driver Class Initialized
INFO - 2023-09-27 23:11:23 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-27 23:11:23 --> Controller Class Initialized
DEBUG - 2023-09-27 23:11:23 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/view_mapel/views/v_view_mapel.php
DEBUG - 2023-09-27 23:11:23 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-09-27 23:11:23 --> Final output sent to browser
DEBUG - 2023-09-27 23:11:23 --> Total execution time: 0.0379
INFO - 2023-09-27 23:11:28 --> Config Class Initialized
INFO - 2023-09-27 23:11:28 --> Hooks Class Initialized
DEBUG - 2023-09-27 23:11:28 --> UTF-8 Support Enabled
INFO - 2023-09-27 23:11:28 --> Utf8 Class Initialized
INFO - 2023-09-27 23:11:28 --> URI Class Initialized
INFO - 2023-09-27 23:11:28 --> Router Class Initialized
INFO - 2023-09-27 23:11:28 --> Output Class Initialized
INFO - 2023-09-27 23:11:28 --> Security Class Initialized
DEBUG - 2023-09-27 23:11:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-27 23:11:28 --> Input Class Initialized
INFO - 2023-09-27 23:11:28 --> Language Class Initialized
INFO - 2023-09-27 23:11:28 --> Language Class Initialized
INFO - 2023-09-27 23:11:28 --> Config Class Initialized
INFO - 2023-09-27 23:11:28 --> Loader Class Initialized
INFO - 2023-09-27 23:11:28 --> Helper loaded: url_helper
INFO - 2023-09-27 23:11:28 --> Helper loaded: file_helper
INFO - 2023-09-27 23:11:28 --> Helper loaded: form_helper
INFO - 2023-09-27 23:11:28 --> Helper loaded: my_helper
INFO - 2023-09-27 23:11:28 --> Database Driver Class Initialized
INFO - 2023-09-27 23:11:28 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-27 23:11:28 --> Controller Class Initialized
DEBUG - 2023-09-27 23:11:28 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/views/list.php
DEBUG - 2023-09-27 23:11:28 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-09-27 23:11:28 --> Final output sent to browser
DEBUG - 2023-09-27 23:11:28 --> Total execution time: 0.0380
INFO - 2023-09-27 23:11:28 --> Config Class Initialized
INFO - 2023-09-27 23:11:28 --> Hooks Class Initialized
DEBUG - 2023-09-27 23:11:28 --> UTF-8 Support Enabled
INFO - 2023-09-27 23:11:28 --> Utf8 Class Initialized
INFO - 2023-09-27 23:11:28 --> URI Class Initialized
INFO - 2023-09-27 23:11:28 --> Router Class Initialized
INFO - 2023-09-27 23:11:28 --> Output Class Initialized
INFO - 2023-09-27 23:11:28 --> Security Class Initialized
DEBUG - 2023-09-27 23:11:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-27 23:11:28 --> Input Class Initialized
INFO - 2023-09-27 23:11:28 --> Language Class Initialized
INFO - 2023-09-27 23:11:28 --> Language Class Initialized
INFO - 2023-09-27 23:11:28 --> Config Class Initialized
INFO - 2023-09-27 23:11:28 --> Loader Class Initialized
INFO - 2023-09-27 23:11:28 --> Helper loaded: url_helper
INFO - 2023-09-27 23:11:28 --> Helper loaded: file_helper
INFO - 2023-09-27 23:11:28 --> Helper loaded: form_helper
INFO - 2023-09-27 23:11:28 --> Helper loaded: my_helper
INFO - 2023-09-27 23:11:28 --> Database Driver Class Initialized
INFO - 2023-09-27 23:11:28 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-27 23:11:28 --> Controller Class Initialized
INFO - 2023-09-27 23:11:30 --> Config Class Initialized
INFO - 2023-09-27 23:11:30 --> Hooks Class Initialized
DEBUG - 2023-09-27 23:11:30 --> UTF-8 Support Enabled
INFO - 2023-09-27 23:11:30 --> Utf8 Class Initialized
INFO - 2023-09-27 23:11:30 --> URI Class Initialized
INFO - 2023-09-27 23:11:30 --> Router Class Initialized
INFO - 2023-09-27 23:11:30 --> Output Class Initialized
INFO - 2023-09-27 23:11:30 --> Security Class Initialized
DEBUG - 2023-09-27 23:11:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-27 23:11:30 --> Input Class Initialized
INFO - 2023-09-27 23:11:30 --> Language Class Initialized
INFO - 2023-09-27 23:11:30 --> Language Class Initialized
INFO - 2023-09-27 23:11:30 --> Config Class Initialized
INFO - 2023-09-27 23:11:30 --> Loader Class Initialized
INFO - 2023-09-27 23:11:30 --> Helper loaded: url_helper
INFO - 2023-09-27 23:11:30 --> Helper loaded: file_helper
INFO - 2023-09-27 23:11:30 --> Helper loaded: form_helper
INFO - 2023-09-27 23:11:30 --> Helper loaded: my_helper
INFO - 2023-09-27 23:11:30 --> Database Driver Class Initialized
INFO - 2023-09-27 23:11:30 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-27 23:11:30 --> Controller Class Initialized
INFO - 2023-09-27 23:11:30 --> Final output sent to browser
DEBUG - 2023-09-27 23:11:30 --> Total execution time: 0.0511
INFO - 2023-09-27 23:11:36 --> Config Class Initialized
INFO - 2023-09-27 23:11:36 --> Hooks Class Initialized
DEBUG - 2023-09-27 23:11:36 --> UTF-8 Support Enabled
INFO - 2023-09-27 23:11:36 --> Utf8 Class Initialized
INFO - 2023-09-27 23:11:36 --> URI Class Initialized
INFO - 2023-09-27 23:11:36 --> Router Class Initialized
INFO - 2023-09-27 23:11:36 --> Output Class Initialized
INFO - 2023-09-27 23:11:36 --> Security Class Initialized
DEBUG - 2023-09-27 23:11:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-27 23:11:36 --> Input Class Initialized
INFO - 2023-09-27 23:11:36 --> Language Class Initialized
INFO - 2023-09-27 23:11:36 --> Language Class Initialized
INFO - 2023-09-27 23:11:36 --> Config Class Initialized
INFO - 2023-09-27 23:11:36 --> Loader Class Initialized
INFO - 2023-09-27 23:11:36 --> Helper loaded: url_helper
INFO - 2023-09-27 23:11:36 --> Helper loaded: file_helper
INFO - 2023-09-27 23:11:36 --> Helper loaded: form_helper
INFO - 2023-09-27 23:11:36 --> Helper loaded: my_helper
INFO - 2023-09-27 23:11:36 --> Database Driver Class Initialized
INFO - 2023-09-27 23:11:36 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-27 23:11:36 --> Controller Class Initialized
DEBUG - 2023-09-27 23:11:36 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/view_mapel/views/v_view_mapel.php
DEBUG - 2023-09-27 23:11:36 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-09-27 23:11:36 --> Final output sent to browser
DEBUG - 2023-09-27 23:11:36 --> Total execution time: 0.0384
INFO - 2023-09-27 23:11:38 --> Config Class Initialized
INFO - 2023-09-27 23:11:38 --> Hooks Class Initialized
DEBUG - 2023-09-27 23:11:38 --> UTF-8 Support Enabled
INFO - 2023-09-27 23:11:38 --> Utf8 Class Initialized
INFO - 2023-09-27 23:11:38 --> URI Class Initialized
INFO - 2023-09-27 23:11:38 --> Router Class Initialized
INFO - 2023-09-27 23:11:38 --> Output Class Initialized
INFO - 2023-09-27 23:11:38 --> Security Class Initialized
DEBUG - 2023-09-27 23:11:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-27 23:11:38 --> Input Class Initialized
INFO - 2023-09-27 23:11:38 --> Language Class Initialized
INFO - 2023-09-27 23:11:38 --> Language Class Initialized
INFO - 2023-09-27 23:11:38 --> Config Class Initialized
INFO - 2023-09-27 23:11:38 --> Loader Class Initialized
INFO - 2023-09-27 23:11:38 --> Helper loaded: url_helper
INFO - 2023-09-27 23:11:38 --> Helper loaded: file_helper
INFO - 2023-09-27 23:11:38 --> Helper loaded: form_helper
INFO - 2023-09-27 23:11:38 --> Helper loaded: my_helper
INFO - 2023-09-27 23:11:38 --> Database Driver Class Initialized
INFO - 2023-09-27 23:11:38 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-27 23:11:38 --> Controller Class Initialized
DEBUG - 2023-09-27 23:11:38 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_catatan_guru/views/list.php
DEBUG - 2023-09-27 23:11:38 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-09-27 23:11:38 --> Final output sent to browser
DEBUG - 2023-09-27 23:11:38 --> Total execution time: 0.0532
INFO - 2023-09-27 23:11:43 --> Config Class Initialized
INFO - 2023-09-27 23:11:43 --> Hooks Class Initialized
DEBUG - 2023-09-27 23:11:43 --> UTF-8 Support Enabled
INFO - 2023-09-27 23:11:43 --> Utf8 Class Initialized
INFO - 2023-09-27 23:11:43 --> URI Class Initialized
INFO - 2023-09-27 23:11:43 --> Router Class Initialized
INFO - 2023-09-27 23:11:43 --> Output Class Initialized
INFO - 2023-09-27 23:11:43 --> Security Class Initialized
DEBUG - 2023-09-27 23:11:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-27 23:11:43 --> Input Class Initialized
INFO - 2023-09-27 23:11:43 --> Language Class Initialized
INFO - 2023-09-27 23:11:43 --> Language Class Initialized
INFO - 2023-09-27 23:11:43 --> Config Class Initialized
INFO - 2023-09-27 23:11:43 --> Loader Class Initialized
INFO - 2023-09-27 23:11:43 --> Helper loaded: url_helper
INFO - 2023-09-27 23:11:43 --> Helper loaded: file_helper
INFO - 2023-09-27 23:11:43 --> Helper loaded: form_helper
INFO - 2023-09-27 23:11:43 --> Helper loaded: my_helper
INFO - 2023-09-27 23:11:43 --> Database Driver Class Initialized
INFO - 2023-09-27 23:11:43 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-27 23:11:43 --> Controller Class Initialized
INFO - 2023-09-27 23:11:43 --> Final output sent to browser
DEBUG - 2023-09-27 23:11:43 --> Total execution time: 0.0596
