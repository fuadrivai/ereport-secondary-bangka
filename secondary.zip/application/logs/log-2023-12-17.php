<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2023-12-17 15:31:23 --> Config Class Initialized
INFO - 2023-12-17 15:31:23 --> Hooks Class Initialized
DEBUG - 2023-12-17 15:31:23 --> UTF-8 Support Enabled
INFO - 2023-12-17 15:31:23 --> Utf8 Class Initialized
INFO - 2023-12-17 15:31:23 --> URI Class Initialized
INFO - 2023-12-17 15:31:23 --> Router Class Initialized
INFO - 2023-12-17 15:31:23 --> Output Class Initialized
INFO - 2023-12-17 15:31:23 --> Security Class Initialized
DEBUG - 2023-12-17 15:31:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-17 15:31:23 --> Input Class Initialized
INFO - 2023-12-17 15:31:23 --> Language Class Initialized
INFO - 2023-12-17 15:31:23 --> Language Class Initialized
INFO - 2023-12-17 15:31:23 --> Config Class Initialized
INFO - 2023-12-17 15:31:23 --> Loader Class Initialized
INFO - 2023-12-17 15:31:23 --> Helper loaded: url_helper
INFO - 2023-12-17 15:31:23 --> Helper loaded: file_helper
INFO - 2023-12-17 15:31:23 --> Helper loaded: form_helper
INFO - 2023-12-17 15:31:23 --> Helper loaded: my_helper
INFO - 2023-12-17 15:31:23 --> Database Driver Class Initialized
INFO - 2023-12-17 15:31:23 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-17 15:31:23 --> Controller Class Initialized
INFO - 2023-12-17 15:31:23 --> Helper loaded: cookie_helper
INFO - 2023-12-17 15:31:23 --> Final output sent to browser
DEBUG - 2023-12-17 15:31:23 --> Total execution time: 0.1427
INFO - 2023-12-17 15:31:23 --> Config Class Initialized
INFO - 2023-12-17 15:31:23 --> Hooks Class Initialized
DEBUG - 2023-12-17 15:31:23 --> UTF-8 Support Enabled
INFO - 2023-12-17 15:31:23 --> Utf8 Class Initialized
INFO - 2023-12-17 15:31:23 --> URI Class Initialized
INFO - 2023-12-17 15:31:23 --> Router Class Initialized
INFO - 2023-12-17 15:31:23 --> Output Class Initialized
INFO - 2023-12-17 15:31:23 --> Security Class Initialized
DEBUG - 2023-12-17 15:31:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-17 15:31:23 --> Input Class Initialized
INFO - 2023-12-17 15:31:23 --> Language Class Initialized
INFO - 2023-12-17 15:31:23 --> Language Class Initialized
INFO - 2023-12-17 15:31:23 --> Config Class Initialized
INFO - 2023-12-17 15:31:23 --> Loader Class Initialized
INFO - 2023-12-17 15:31:23 --> Helper loaded: url_helper
INFO - 2023-12-17 15:31:23 --> Helper loaded: file_helper
INFO - 2023-12-17 15:31:23 --> Helper loaded: form_helper
INFO - 2023-12-17 15:31:23 --> Helper loaded: my_helper
INFO - 2023-12-17 15:31:23 --> Database Driver Class Initialized
INFO - 2023-12-17 15:31:24 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-17 15:31:24 --> Controller Class Initialized
INFO - 2023-12-17 15:31:24 --> Helper loaded: cookie_helper
INFO - 2023-12-17 15:31:24 --> Config Class Initialized
INFO - 2023-12-17 15:31:24 --> Hooks Class Initialized
DEBUG - 2023-12-17 15:31:24 --> UTF-8 Support Enabled
INFO - 2023-12-17 15:31:24 --> Utf8 Class Initialized
INFO - 2023-12-17 15:31:24 --> URI Class Initialized
INFO - 2023-12-17 15:31:24 --> Router Class Initialized
INFO - 2023-12-17 15:31:24 --> Output Class Initialized
INFO - 2023-12-17 15:31:24 --> Security Class Initialized
DEBUG - 2023-12-17 15:31:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-17 15:31:24 --> Input Class Initialized
INFO - 2023-12-17 15:31:24 --> Language Class Initialized
INFO - 2023-12-17 15:31:24 --> Language Class Initialized
INFO - 2023-12-17 15:31:24 --> Config Class Initialized
INFO - 2023-12-17 15:31:24 --> Loader Class Initialized
INFO - 2023-12-17 15:31:24 --> Helper loaded: url_helper
INFO - 2023-12-17 15:31:24 --> Helper loaded: file_helper
INFO - 2023-12-17 15:31:24 --> Helper loaded: form_helper
INFO - 2023-12-17 15:31:24 --> Helper loaded: my_helper
INFO - 2023-12-17 15:31:24 --> Database Driver Class Initialized
INFO - 2023-12-17 15:31:24 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-17 15:31:24 --> Controller Class Initialized
DEBUG - 2023-12-17 15:31:24 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/lihat_raport/views/list.php
DEBUG - 2023-12-17 15:31:24 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-12-17 15:31:24 --> Final output sent to browser
DEBUG - 2023-12-17 15:31:24 --> Total execution time: 0.1034
INFO - 2023-12-17 15:31:26 --> Config Class Initialized
INFO - 2023-12-17 15:31:26 --> Hooks Class Initialized
DEBUG - 2023-12-17 15:31:26 --> UTF-8 Support Enabled
INFO - 2023-12-17 15:31:26 --> Utf8 Class Initialized
INFO - 2023-12-17 15:31:26 --> URI Class Initialized
INFO - 2023-12-17 15:31:26 --> Router Class Initialized
INFO - 2023-12-17 15:31:26 --> Output Class Initialized
INFO - 2023-12-17 15:31:26 --> Security Class Initialized
DEBUG - 2023-12-17 15:31:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-17 15:31:26 --> Input Class Initialized
INFO - 2023-12-17 15:31:26 --> Language Class Initialized
INFO - 2023-12-17 15:31:26 --> Language Class Initialized
INFO - 2023-12-17 15:31:26 --> Config Class Initialized
INFO - 2023-12-17 15:31:26 --> Loader Class Initialized
INFO - 2023-12-17 15:31:26 --> Helper loaded: url_helper
INFO - 2023-12-17 15:31:26 --> Helper loaded: file_helper
INFO - 2023-12-17 15:31:26 --> Helper loaded: form_helper
INFO - 2023-12-17 15:31:26 --> Helper loaded: my_helper
INFO - 2023-12-17 15:31:26 --> Database Driver Class Initialized
INFO - 2023-12-17 15:31:26 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-17 15:31:26 --> Controller Class Initialized
INFO - 2023-12-17 15:31:26 --> Helper loaded: cookie_helper
INFO - 2023-12-17 15:31:26 --> Final output sent to browser
DEBUG - 2023-12-17 15:31:26 --> Total execution time: 0.0411
INFO - 2023-12-17 15:31:26 --> Config Class Initialized
INFO - 2023-12-17 15:31:26 --> Hooks Class Initialized
DEBUG - 2023-12-17 15:31:26 --> UTF-8 Support Enabled
INFO - 2023-12-17 15:31:26 --> Utf8 Class Initialized
INFO - 2023-12-17 15:31:26 --> URI Class Initialized
INFO - 2023-12-17 15:31:26 --> Router Class Initialized
INFO - 2023-12-17 15:31:26 --> Output Class Initialized
INFO - 2023-12-17 15:31:26 --> Security Class Initialized
DEBUG - 2023-12-17 15:31:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-17 15:31:26 --> Input Class Initialized
INFO - 2023-12-17 15:31:26 --> Language Class Initialized
INFO - 2023-12-17 15:31:26 --> Language Class Initialized
INFO - 2023-12-17 15:31:26 --> Config Class Initialized
INFO - 2023-12-17 15:31:26 --> Loader Class Initialized
INFO - 2023-12-17 15:31:26 --> Config Class Initialized
INFO - 2023-12-17 15:31:26 --> Hooks Class Initialized
DEBUG - 2023-12-17 15:31:26 --> UTF-8 Support Enabled
INFO - 2023-12-17 15:31:26 --> Utf8 Class Initialized
INFO - 2023-12-17 15:31:26 --> URI Class Initialized
INFO - 2023-12-17 15:31:26 --> Router Class Initialized
INFO - 2023-12-17 15:31:26 --> Output Class Initialized
INFO - 2023-12-17 15:31:26 --> Security Class Initialized
DEBUG - 2023-12-17 15:31:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-17 15:31:26 --> Input Class Initialized
INFO - 2023-12-17 15:31:26 --> Language Class Initialized
INFO - 2023-12-17 15:31:26 --> Language Class Initialized
INFO - 2023-12-17 15:31:26 --> Config Class Initialized
INFO - 2023-12-17 15:31:26 --> Loader Class Initialized
INFO - 2023-12-17 15:31:26 --> Helper loaded: url_helper
INFO - 2023-12-17 15:31:26 --> Helper loaded: file_helper
INFO - 2023-12-17 15:31:26 --> Helper loaded: url_helper
INFO - 2023-12-17 15:31:26 --> Helper loaded: file_helper
INFO - 2023-12-17 15:31:26 --> Helper loaded: form_helper
INFO - 2023-12-17 15:31:26 --> Helper loaded: my_helper
INFO - 2023-12-17 15:31:26 --> Database Driver Class Initialized
INFO - 2023-12-17 15:31:26 --> Helper loaded: form_helper
INFO - 2023-12-17 15:31:26 --> Helper loaded: my_helper
INFO - 2023-12-17 15:31:26 --> Database Driver Class Initialized
INFO - 2023-12-17 15:31:26 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-17 15:31:26 --> Controller Class Initialized
INFO - 2023-12-17 15:31:26 --> Helper loaded: cookie_helper
INFO - 2023-12-17 15:31:26 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-17 15:31:26 --> Controller Class Initialized
INFO - 2023-12-17 15:31:26 --> Helper loaded: cookie_helper
INFO - 2023-12-17 15:31:26 --> Config Class Initialized
INFO - 2023-12-17 15:31:26 --> Hooks Class Initialized
DEBUG - 2023-12-17 15:31:26 --> UTF-8 Support Enabled
INFO - 2023-12-17 15:31:26 --> Utf8 Class Initialized
INFO - 2023-12-17 15:31:26 --> URI Class Initialized
INFO - 2023-12-17 15:31:26 --> Router Class Initialized
INFO - 2023-12-17 15:31:26 --> Output Class Initialized
INFO - 2023-12-17 15:31:26 --> Security Class Initialized
DEBUG - 2023-12-17 15:31:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-17 15:31:26 --> Input Class Initialized
INFO - 2023-12-17 15:31:26 --> Language Class Initialized
INFO - 2023-12-17 15:31:26 --> Language Class Initialized
INFO - 2023-12-17 15:31:26 --> Config Class Initialized
INFO - 2023-12-17 15:31:26 --> Loader Class Initialized
INFO - 2023-12-17 15:31:26 --> Helper loaded: url_helper
INFO - 2023-12-17 15:31:26 --> Helper loaded: file_helper
INFO - 2023-12-17 15:31:26 --> Helper loaded: form_helper
INFO - 2023-12-17 15:31:26 --> Helper loaded: my_helper
INFO - 2023-12-17 15:31:26 --> Database Driver Class Initialized
INFO - 2023-12-17 15:31:26 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-17 15:31:26 --> Controller Class Initialized
DEBUG - 2023-12-17 15:31:26 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/lihat_raport/views/list.php
DEBUG - 2023-12-17 15:31:26 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-12-17 15:31:26 --> Final output sent to browser
DEBUG - 2023-12-17 15:31:26 --> Total execution time: 0.0821
INFO - 2023-12-17 15:31:35 --> Config Class Initialized
INFO - 2023-12-17 15:31:35 --> Hooks Class Initialized
DEBUG - 2023-12-17 15:31:35 --> UTF-8 Support Enabled
INFO - 2023-12-17 15:31:35 --> Utf8 Class Initialized
INFO - 2023-12-17 15:31:35 --> URI Class Initialized
INFO - 2023-12-17 15:31:35 --> Router Class Initialized
INFO - 2023-12-17 15:31:35 --> Output Class Initialized
INFO - 2023-12-17 15:31:35 --> Security Class Initialized
DEBUG - 2023-12-17 15:31:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-17 15:31:35 --> Input Class Initialized
INFO - 2023-12-17 15:31:35 --> Language Class Initialized
INFO - 2023-12-17 15:31:35 --> Language Class Initialized
INFO - 2023-12-17 15:31:35 --> Config Class Initialized
INFO - 2023-12-17 15:31:35 --> Loader Class Initialized
INFO - 2023-12-17 15:31:35 --> Helper loaded: url_helper
INFO - 2023-12-17 15:31:35 --> Helper loaded: file_helper
INFO - 2023-12-17 15:31:35 --> Helper loaded: form_helper
INFO - 2023-12-17 15:31:35 --> Helper loaded: my_helper
INFO - 2023-12-17 15:31:35 --> Database Driver Class Initialized
INFO - 2023-12-17 15:31:35 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-17 15:31:35 --> Controller Class Initialized
DEBUG - 2023-12-17 15:31:35 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/views/cetak_ikm.php
INFO - 2023-12-17 15:31:38 --> Final output sent to browser
DEBUG - 2023-12-17 15:31:38 --> Total execution time: 2.5659
INFO - 2023-12-17 15:32:37 --> Config Class Initialized
INFO - 2023-12-17 15:32:37 --> Hooks Class Initialized
DEBUG - 2023-12-17 15:32:37 --> UTF-8 Support Enabled
INFO - 2023-12-17 15:32:37 --> Utf8 Class Initialized
INFO - 2023-12-17 15:32:37 --> URI Class Initialized
INFO - 2023-12-17 15:32:37 --> Router Class Initialized
INFO - 2023-12-17 15:32:37 --> Output Class Initialized
INFO - 2023-12-17 15:32:37 --> Security Class Initialized
DEBUG - 2023-12-17 15:32:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-17 15:32:37 --> Input Class Initialized
INFO - 2023-12-17 15:32:37 --> Language Class Initialized
INFO - 2023-12-17 15:32:37 --> Language Class Initialized
INFO - 2023-12-17 15:32:37 --> Config Class Initialized
INFO - 2023-12-17 15:32:37 --> Loader Class Initialized
INFO - 2023-12-17 15:32:37 --> Helper loaded: url_helper
INFO - 2023-12-17 15:32:37 --> Helper loaded: file_helper
INFO - 2023-12-17 15:32:37 --> Helper loaded: form_helper
INFO - 2023-12-17 15:32:37 --> Helper loaded: my_helper
INFO - 2023-12-17 15:32:37 --> Database Driver Class Initialized
INFO - 2023-12-17 15:32:37 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-17 15:32:37 --> Controller Class Initialized
DEBUG - 2023-12-17 15:32:37 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/views/cetak_mh.php
INFO - 2023-12-17 15:32:44 --> Final output sent to browser
DEBUG - 2023-12-17 15:32:44 --> Total execution time: 7.8718
