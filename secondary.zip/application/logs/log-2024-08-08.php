<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2024-08-08 15:36:01 --> Config Class Initialized
INFO - 2024-08-08 15:36:01 --> Hooks Class Initialized
DEBUG - 2024-08-08 15:36:01 --> UTF-8 Support Enabled
INFO - 2024-08-08 15:36:01 --> Utf8 Class Initialized
INFO - 2024-08-08 15:36:01 --> URI Class Initialized
INFO - 2024-08-08 15:36:01 --> Router Class Initialized
INFO - 2024-08-08 15:36:01 --> Output Class Initialized
INFO - 2024-08-08 15:36:01 --> Security Class Initialized
DEBUG - 2024-08-08 15:36:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-08-08 15:36:01 --> Input Class Initialized
INFO - 2024-08-08 15:36:01 --> Language Class Initialized
INFO - 2024-08-08 15:36:02 --> Language Class Initialized
INFO - 2024-08-08 15:36:02 --> Config Class Initialized
INFO - 2024-08-08 15:36:02 --> Loader Class Initialized
INFO - 2024-08-08 15:36:02 --> Helper loaded: url_helper
INFO - 2024-08-08 15:36:02 --> Helper loaded: file_helper
INFO - 2024-08-08 15:36:02 --> Helper loaded: form_helper
INFO - 2024-08-08 15:36:02 --> Helper loaded: my_helper
INFO - 2024-08-08 15:36:02 --> Database Driver Class Initialized
INFO - 2024-08-08 15:36:02 --> Session: Class initialized using 'files' driver.
INFO - 2024-08-08 15:36:02 --> Controller Class Initialized
INFO - 2024-08-08 15:36:02 --> Helper loaded: cookie_helper
INFO - 2024-08-08 15:36:02 --> Final output sent to browser
DEBUG - 2024-08-08 15:36:02 --> Total execution time: 0.4434
INFO - 2024-08-08 15:36:02 --> Config Class Initialized
INFO - 2024-08-08 15:36:02 --> Hooks Class Initialized
DEBUG - 2024-08-08 15:36:02 --> UTF-8 Support Enabled
INFO - 2024-08-08 15:36:02 --> Utf8 Class Initialized
INFO - 2024-08-08 15:36:02 --> URI Class Initialized
INFO - 2024-08-08 15:36:02 --> Router Class Initialized
INFO - 2024-08-08 15:36:02 --> Output Class Initialized
INFO - 2024-08-08 15:36:02 --> Security Class Initialized
DEBUG - 2024-08-08 15:36:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-08-08 15:36:02 --> Input Class Initialized
INFO - 2024-08-08 15:36:02 --> Language Class Initialized
INFO - 2024-08-08 15:36:02 --> Language Class Initialized
INFO - 2024-08-08 15:36:02 --> Config Class Initialized
INFO - 2024-08-08 15:36:02 --> Loader Class Initialized
INFO - 2024-08-08 15:36:02 --> Helper loaded: url_helper
INFO - 2024-08-08 15:36:02 --> Helper loaded: file_helper
INFO - 2024-08-08 15:36:02 --> Helper loaded: form_helper
INFO - 2024-08-08 15:36:02 --> Helper loaded: my_helper
INFO - 2024-08-08 15:36:02 --> Database Driver Class Initialized
INFO - 2024-08-08 15:36:02 --> Session: Class initialized using 'files' driver.
INFO - 2024-08-08 15:36:02 --> Controller Class Initialized
INFO - 2024-08-08 15:36:02 --> Helper loaded: cookie_helper
INFO - 2024-08-08 15:36:02 --> Config Class Initialized
INFO - 2024-08-08 15:36:02 --> Hooks Class Initialized
DEBUG - 2024-08-08 15:36:02 --> UTF-8 Support Enabled
INFO - 2024-08-08 15:36:02 --> Utf8 Class Initialized
INFO - 2024-08-08 15:36:02 --> URI Class Initialized
INFO - 2024-08-08 15:36:02 --> Router Class Initialized
INFO - 2024-08-08 15:36:02 --> Output Class Initialized
INFO - 2024-08-08 15:36:02 --> Security Class Initialized
DEBUG - 2024-08-08 15:36:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-08-08 15:36:02 --> Input Class Initialized
INFO - 2024-08-08 15:36:02 --> Language Class Initialized
INFO - 2024-08-08 15:36:02 --> Language Class Initialized
INFO - 2024-08-08 15:36:02 --> Config Class Initialized
INFO - 2024-08-08 15:36:02 --> Loader Class Initialized
INFO - 2024-08-08 15:36:02 --> Helper loaded: url_helper
INFO - 2024-08-08 15:36:02 --> Helper loaded: file_helper
INFO - 2024-08-08 15:36:02 --> Helper loaded: form_helper
INFO - 2024-08-08 15:36:02 --> Helper loaded: my_helper
INFO - 2024-08-08 15:36:02 --> Database Driver Class Initialized
INFO - 2024-08-08 15:36:02 --> Session: Class initialized using 'files' driver.
INFO - 2024-08-08 15:36:02 --> Controller Class Initialized
DEBUG - 2024-08-08 15:36:02 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/lihat_raport/views/list.php
DEBUG - 2024-08-08 15:36:02 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-08-08 15:36:02 --> Final output sent to browser
DEBUG - 2024-08-08 15:36:02 --> Total execution time: 0.0378
INFO - 2024-08-08 19:55:19 --> Config Class Initialized
INFO - 2024-08-08 19:55:19 --> Hooks Class Initialized
DEBUG - 2024-08-08 19:55:19 --> UTF-8 Support Enabled
INFO - 2024-08-08 19:55:19 --> Utf8 Class Initialized
INFO - 2024-08-08 19:55:19 --> URI Class Initialized
INFO - 2024-08-08 19:55:19 --> Router Class Initialized
INFO - 2024-08-08 19:55:19 --> Output Class Initialized
INFO - 2024-08-08 19:55:20 --> Security Class Initialized
DEBUG - 2024-08-08 19:55:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-08-08 19:55:20 --> Input Class Initialized
INFO - 2024-08-08 19:55:20 --> Language Class Initialized
INFO - 2024-08-08 19:55:20 --> Language Class Initialized
INFO - 2024-08-08 19:55:20 --> Config Class Initialized
INFO - 2024-08-08 19:55:20 --> Loader Class Initialized
INFO - 2024-08-08 19:55:20 --> Helper loaded: url_helper
INFO - 2024-08-08 19:55:20 --> Helper loaded: file_helper
INFO - 2024-08-08 19:55:20 --> Helper loaded: form_helper
INFO - 2024-08-08 19:55:20 --> Helper loaded: my_helper
INFO - 2024-08-08 19:55:20 --> Database Driver Class Initialized
INFO - 2024-08-08 19:55:20 --> Session: Class initialized using 'files' driver.
INFO - 2024-08-08 19:55:20 --> Controller Class Initialized
INFO - 2024-08-08 19:55:20 --> Helper loaded: cookie_helper
INFO - 2024-08-08 19:55:20 --> Final output sent to browser
DEBUG - 2024-08-08 19:55:20 --> Total execution time: 1.0023
INFO - 2024-08-08 19:55:20 --> Config Class Initialized
INFO - 2024-08-08 19:55:20 --> Hooks Class Initialized
DEBUG - 2024-08-08 19:55:20 --> UTF-8 Support Enabled
INFO - 2024-08-08 19:55:20 --> Utf8 Class Initialized
INFO - 2024-08-08 19:55:20 --> URI Class Initialized
INFO - 2024-08-08 19:55:20 --> Router Class Initialized
INFO - 2024-08-08 19:55:20 --> Output Class Initialized
INFO - 2024-08-08 19:55:20 --> Security Class Initialized
DEBUG - 2024-08-08 19:55:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-08-08 19:55:20 --> Input Class Initialized
INFO - 2024-08-08 19:55:20 --> Language Class Initialized
INFO - 2024-08-08 19:55:20 --> Language Class Initialized
INFO - 2024-08-08 19:55:20 --> Config Class Initialized
INFO - 2024-08-08 19:55:20 --> Loader Class Initialized
INFO - 2024-08-08 19:55:20 --> Helper loaded: url_helper
INFO - 2024-08-08 19:55:20 --> Helper loaded: file_helper
INFO - 2024-08-08 19:55:20 --> Helper loaded: form_helper
INFO - 2024-08-08 19:55:20 --> Helper loaded: my_helper
INFO - 2024-08-08 19:55:20 --> Database Driver Class Initialized
INFO - 2024-08-08 19:55:20 --> Session: Class initialized using 'files' driver.
INFO - 2024-08-08 19:55:20 --> Controller Class Initialized
INFO - 2024-08-08 19:55:20 --> Helper loaded: cookie_helper
INFO - 2024-08-08 19:55:20 --> Config Class Initialized
INFO - 2024-08-08 19:55:20 --> Hooks Class Initialized
DEBUG - 2024-08-08 19:55:20 --> UTF-8 Support Enabled
INFO - 2024-08-08 19:55:20 --> Utf8 Class Initialized
INFO - 2024-08-08 19:55:20 --> URI Class Initialized
INFO - 2024-08-08 19:55:20 --> Router Class Initialized
INFO - 2024-08-08 19:55:20 --> Output Class Initialized
INFO - 2024-08-08 19:55:20 --> Security Class Initialized
DEBUG - 2024-08-08 19:55:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-08-08 19:55:20 --> Input Class Initialized
INFO - 2024-08-08 19:55:20 --> Language Class Initialized
INFO - 2024-08-08 19:55:20 --> Language Class Initialized
INFO - 2024-08-08 19:55:20 --> Config Class Initialized
INFO - 2024-08-08 19:55:20 --> Loader Class Initialized
INFO - 2024-08-08 19:55:20 --> Helper loaded: url_helper
INFO - 2024-08-08 19:55:20 --> Helper loaded: file_helper
INFO - 2024-08-08 19:55:20 --> Helper loaded: form_helper
INFO - 2024-08-08 19:55:20 --> Helper loaded: my_helper
INFO - 2024-08-08 19:55:20 --> Database Driver Class Initialized
INFO - 2024-08-08 19:55:20 --> Session: Class initialized using 'files' driver.
INFO - 2024-08-08 19:55:20 --> Controller Class Initialized
DEBUG - 2024-08-08 19:55:21 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/lihat_raport/views/list.php
DEBUG - 2024-08-08 19:55:21 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-08-08 19:55:21 --> Final output sent to browser
DEBUG - 2024-08-08 19:55:21 --> Total execution time: 0.0557
