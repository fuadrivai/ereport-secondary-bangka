<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2023-11-30 09:13:31 --> Config Class Initialized
INFO - 2023-11-30 09:13:31 --> Hooks Class Initialized
DEBUG - 2023-11-30 09:13:31 --> UTF-8 Support Enabled
INFO - 2023-11-30 09:13:31 --> Utf8 Class Initialized
INFO - 2023-11-30 09:13:31 --> URI Class Initialized
INFO - 2023-11-30 09:13:31 --> Router Class Initialized
INFO - 2023-11-30 09:13:31 --> Output Class Initialized
INFO - 2023-11-30 09:13:31 --> Security Class Initialized
DEBUG - 2023-11-30 09:13:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-30 09:13:31 --> Input Class Initialized
INFO - 2023-11-30 09:13:31 --> Language Class Initialized
INFO - 2023-11-30 09:13:31 --> Language Class Initialized
INFO - 2023-11-30 09:13:31 --> Config Class Initialized
INFO - 2023-11-30 09:13:31 --> Loader Class Initialized
INFO - 2023-11-30 09:13:31 --> Helper loaded: url_helper
INFO - 2023-11-30 09:13:31 --> Helper loaded: file_helper
INFO - 2023-11-30 09:13:31 --> Helper loaded: form_helper
INFO - 2023-11-30 09:13:31 --> Helper loaded: my_helper
INFO - 2023-11-30 09:13:31 --> Database Driver Class Initialized
INFO - 2023-11-30 09:13:31 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-30 09:13:31 --> Controller Class Initialized
ERROR - 2023-11-30 09:13:31 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_catatan_kl1/controllers/N_catatan_kl1.php 19
ERROR - 2023-11-30 09:13:31 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_catatan_kl1/controllers/N_catatan_kl1.php 20
DEBUG - 2023-11-30 09:13:31 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_catatan_kl1/views/list.php
DEBUG - 2023-11-30 09:13:31 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-11-30 09:13:31 --> Final output sent to browser
DEBUG - 2023-11-30 09:13:31 --> Total execution time: 0.1543
INFO - 2023-11-30 15:51:47 --> Config Class Initialized
INFO - 2023-11-30 15:51:47 --> Hooks Class Initialized
DEBUG - 2023-11-30 15:51:47 --> UTF-8 Support Enabled
INFO - 2023-11-30 15:51:47 --> Utf8 Class Initialized
INFO - 2023-11-30 15:51:47 --> URI Class Initialized
INFO - 2023-11-30 15:51:47 --> Router Class Initialized
INFO - 2023-11-30 15:51:47 --> Output Class Initialized
INFO - 2023-11-30 15:51:47 --> Security Class Initialized
DEBUG - 2023-11-30 15:51:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-30 15:51:47 --> Input Class Initialized
INFO - 2023-11-30 15:51:47 --> Language Class Initialized
INFO - 2023-11-30 15:51:47 --> Language Class Initialized
INFO - 2023-11-30 15:51:47 --> Config Class Initialized
INFO - 2023-11-30 15:51:47 --> Loader Class Initialized
INFO - 2023-11-30 15:51:47 --> Helper loaded: url_helper
INFO - 2023-11-30 15:51:47 --> Helper loaded: file_helper
INFO - 2023-11-30 15:51:47 --> Helper loaded: form_helper
INFO - 2023-11-30 15:51:47 --> Helper loaded: my_helper
INFO - 2023-11-30 15:51:47 --> Database Driver Class Initialized
INFO - 2023-11-30 15:51:47 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-30 15:51:47 --> Controller Class Initialized
DEBUG - 2023-11-30 15:51:47 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/login/views/login.php
DEBUG - 2023-11-30 15:51:47 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-11-30 15:51:47 --> Final output sent to browser
DEBUG - 2023-11-30 15:51:47 --> Total execution time: 0.0576
INFO - 2023-11-30 15:51:50 --> Config Class Initialized
INFO - 2023-11-30 15:51:50 --> Hooks Class Initialized
DEBUG - 2023-11-30 15:51:50 --> UTF-8 Support Enabled
INFO - 2023-11-30 15:51:50 --> Utf8 Class Initialized
INFO - 2023-11-30 15:51:50 --> URI Class Initialized
INFO - 2023-11-30 15:51:50 --> Router Class Initialized
INFO - 2023-11-30 15:51:50 --> Output Class Initialized
INFO - 2023-11-30 15:51:50 --> Security Class Initialized
DEBUG - 2023-11-30 15:51:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-30 15:51:50 --> Input Class Initialized
INFO - 2023-11-30 15:51:50 --> Language Class Initialized
INFO - 2023-11-30 15:51:50 --> Language Class Initialized
INFO - 2023-11-30 15:51:50 --> Config Class Initialized
INFO - 2023-11-30 15:51:50 --> Loader Class Initialized
INFO - 2023-11-30 15:51:50 --> Helper loaded: url_helper
INFO - 2023-11-30 15:51:50 --> Helper loaded: file_helper
INFO - 2023-11-30 15:51:50 --> Helper loaded: form_helper
INFO - 2023-11-30 15:51:50 --> Helper loaded: my_helper
INFO - 2023-11-30 15:51:50 --> Database Driver Class Initialized
INFO - 2023-11-30 15:51:50 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-30 15:51:50 --> Controller Class Initialized
INFO - 2023-11-30 15:51:50 --> Helper loaded: cookie_helper
INFO - 2023-11-30 15:51:50 --> Final output sent to browser
DEBUG - 2023-11-30 15:51:50 --> Total execution time: 0.0628
INFO - 2023-11-30 15:51:50 --> Config Class Initialized
INFO - 2023-11-30 15:51:50 --> Hooks Class Initialized
DEBUG - 2023-11-30 15:51:50 --> UTF-8 Support Enabled
INFO - 2023-11-30 15:51:50 --> Utf8 Class Initialized
INFO - 2023-11-30 15:51:50 --> URI Class Initialized
INFO - 2023-11-30 15:51:50 --> Router Class Initialized
INFO - 2023-11-30 15:51:50 --> Output Class Initialized
INFO - 2023-11-30 15:51:50 --> Security Class Initialized
DEBUG - 2023-11-30 15:51:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-30 15:51:50 --> Input Class Initialized
INFO - 2023-11-30 15:51:50 --> Language Class Initialized
INFO - 2023-11-30 15:51:50 --> Language Class Initialized
INFO - 2023-11-30 15:51:50 --> Config Class Initialized
INFO - 2023-11-30 15:51:50 --> Loader Class Initialized
INFO - 2023-11-30 15:51:50 --> Helper loaded: url_helper
INFO - 2023-11-30 15:51:50 --> Helper loaded: file_helper
INFO - 2023-11-30 15:51:50 --> Helper loaded: form_helper
INFO - 2023-11-30 15:51:50 --> Helper loaded: my_helper
INFO - 2023-11-30 15:51:50 --> Database Driver Class Initialized
INFO - 2023-11-30 15:51:50 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-30 15:51:50 --> Controller Class Initialized
DEBUG - 2023-11-30 15:51:50 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/home/views/v_home.php
DEBUG - 2023-11-30 15:51:50 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-11-30 15:51:50 --> Final output sent to browser
DEBUG - 2023-11-30 15:51:50 --> Total execution time: 0.0413
INFO - 2023-11-30 16:08:35 --> Config Class Initialized
INFO - 2023-11-30 16:08:35 --> Hooks Class Initialized
DEBUG - 2023-11-30 16:08:35 --> UTF-8 Support Enabled
INFO - 2023-11-30 16:08:35 --> Utf8 Class Initialized
INFO - 2023-11-30 16:08:35 --> URI Class Initialized
INFO - 2023-11-30 16:08:35 --> Router Class Initialized
INFO - 2023-11-30 16:08:35 --> Output Class Initialized
INFO - 2023-11-30 16:08:35 --> Security Class Initialized
DEBUG - 2023-11-30 16:08:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-30 16:08:35 --> Input Class Initialized
INFO - 2023-11-30 16:08:35 --> Language Class Initialized
INFO - 2023-11-30 16:08:35 --> Language Class Initialized
INFO - 2023-11-30 16:08:35 --> Config Class Initialized
INFO - 2023-11-30 16:08:35 --> Loader Class Initialized
INFO - 2023-11-30 16:08:35 --> Helper loaded: url_helper
INFO - 2023-11-30 16:08:35 --> Helper loaded: file_helper
INFO - 2023-11-30 16:08:35 --> Helper loaded: form_helper
INFO - 2023-11-30 16:08:35 --> Helper loaded: my_helper
INFO - 2023-11-30 16:08:35 --> Database Driver Class Initialized
INFO - 2023-11-30 16:08:35 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-30 16:08:35 --> Controller Class Initialized
DEBUG - 2023-11-30 16:08:35 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/data_mapel/views/list.php
DEBUG - 2023-11-30 16:08:35 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-11-30 16:08:35 --> Final output sent to browser
DEBUG - 2023-11-30 16:08:35 --> Total execution time: 0.0651
INFO - 2023-11-30 16:08:35 --> Config Class Initialized
INFO - 2023-11-30 16:08:35 --> Hooks Class Initialized
DEBUG - 2023-11-30 16:08:35 --> UTF-8 Support Enabled
INFO - 2023-11-30 16:08:35 --> Utf8 Class Initialized
INFO - 2023-11-30 16:08:35 --> URI Class Initialized
INFO - 2023-11-30 16:08:35 --> Router Class Initialized
INFO - 2023-11-30 16:08:35 --> Output Class Initialized
INFO - 2023-11-30 16:08:35 --> Security Class Initialized
DEBUG - 2023-11-30 16:08:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-30 16:08:35 --> Input Class Initialized
INFO - 2023-11-30 16:08:35 --> Language Class Initialized
ERROR - 2023-11-30 16:08:35 --> 404 Page Not Found: /index
INFO - 2023-11-30 16:08:35 --> Config Class Initialized
INFO - 2023-11-30 16:08:35 --> Hooks Class Initialized
DEBUG - 2023-11-30 16:08:35 --> UTF-8 Support Enabled
INFO - 2023-11-30 16:08:35 --> Utf8 Class Initialized
INFO - 2023-11-30 16:08:35 --> URI Class Initialized
INFO - 2023-11-30 16:08:35 --> Router Class Initialized
INFO - 2023-11-30 16:08:35 --> Output Class Initialized
INFO - 2023-11-30 16:08:35 --> Security Class Initialized
DEBUG - 2023-11-30 16:08:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-30 16:08:35 --> Input Class Initialized
INFO - 2023-11-30 16:08:35 --> Language Class Initialized
INFO - 2023-11-30 16:08:35 --> Language Class Initialized
INFO - 2023-11-30 16:08:35 --> Config Class Initialized
INFO - 2023-11-30 16:08:35 --> Loader Class Initialized
INFO - 2023-11-30 16:08:35 --> Helper loaded: url_helper
INFO - 2023-11-30 16:08:35 --> Helper loaded: file_helper
INFO - 2023-11-30 16:08:35 --> Helper loaded: form_helper
INFO - 2023-11-30 16:08:35 --> Helper loaded: my_helper
INFO - 2023-11-30 16:08:35 --> Database Driver Class Initialized
INFO - 2023-11-30 16:08:35 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-30 16:08:35 --> Controller Class Initialized
INFO - 2023-11-30 16:08:37 --> Config Class Initialized
INFO - 2023-11-30 16:08:37 --> Hooks Class Initialized
DEBUG - 2023-11-30 16:08:37 --> UTF-8 Support Enabled
INFO - 2023-11-30 16:08:37 --> Utf8 Class Initialized
INFO - 2023-11-30 16:08:37 --> URI Class Initialized
INFO - 2023-11-30 16:08:37 --> Router Class Initialized
INFO - 2023-11-30 16:08:37 --> Output Class Initialized
INFO - 2023-11-30 16:08:37 --> Security Class Initialized
DEBUG - 2023-11-30 16:08:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-30 16:08:37 --> Input Class Initialized
INFO - 2023-11-30 16:08:37 --> Language Class Initialized
INFO - 2023-11-30 16:08:37 --> Language Class Initialized
INFO - 2023-11-30 16:08:37 --> Config Class Initialized
INFO - 2023-11-30 16:08:37 --> Loader Class Initialized
INFO - 2023-11-30 16:08:37 --> Helper loaded: url_helper
INFO - 2023-11-30 16:08:37 --> Helper loaded: file_helper
INFO - 2023-11-30 16:08:37 --> Helper loaded: form_helper
INFO - 2023-11-30 16:08:37 --> Helper loaded: my_helper
INFO - 2023-11-30 16:08:37 --> Database Driver Class Initialized
INFO - 2023-11-30 16:08:37 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-30 16:08:37 --> Controller Class Initialized
INFO - 2023-11-30 16:08:37 --> Final output sent to browser
DEBUG - 2023-11-30 16:08:37 --> Total execution time: 0.0405
INFO - 2023-11-30 16:09:06 --> Config Class Initialized
INFO - 2023-11-30 16:09:06 --> Hooks Class Initialized
DEBUG - 2023-11-30 16:09:06 --> UTF-8 Support Enabled
INFO - 2023-11-30 16:09:06 --> Utf8 Class Initialized
INFO - 2023-11-30 16:09:06 --> URI Class Initialized
INFO - 2023-11-30 16:09:06 --> Router Class Initialized
INFO - 2023-11-30 16:09:06 --> Output Class Initialized
INFO - 2023-11-30 16:09:06 --> Security Class Initialized
DEBUG - 2023-11-30 16:09:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-30 16:09:06 --> Input Class Initialized
INFO - 2023-11-30 16:09:06 --> Language Class Initialized
INFO - 2023-11-30 16:09:06 --> Language Class Initialized
INFO - 2023-11-30 16:09:06 --> Config Class Initialized
INFO - 2023-11-30 16:09:06 --> Loader Class Initialized
INFO - 2023-11-30 16:09:06 --> Helper loaded: url_helper
INFO - 2023-11-30 16:09:06 --> Helper loaded: file_helper
INFO - 2023-11-30 16:09:06 --> Helper loaded: form_helper
INFO - 2023-11-30 16:09:06 --> Helper loaded: my_helper
INFO - 2023-11-30 16:09:06 --> Database Driver Class Initialized
INFO - 2023-11-30 16:09:06 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-30 16:09:06 --> Controller Class Initialized
INFO - 2023-11-30 16:09:07 --> Final output sent to browser
DEBUG - 2023-11-30 16:09:07 --> Total execution time: 0.5073
INFO - 2023-11-30 16:09:07 --> Config Class Initialized
INFO - 2023-11-30 16:09:07 --> Hooks Class Initialized
DEBUG - 2023-11-30 16:09:07 --> UTF-8 Support Enabled
INFO - 2023-11-30 16:09:07 --> Utf8 Class Initialized
INFO - 2023-11-30 16:09:07 --> URI Class Initialized
INFO - 2023-11-30 16:09:07 --> Router Class Initialized
INFO - 2023-11-30 16:09:07 --> Output Class Initialized
INFO - 2023-11-30 16:09:07 --> Security Class Initialized
DEBUG - 2023-11-30 16:09:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-30 16:09:07 --> Input Class Initialized
INFO - 2023-11-30 16:09:07 --> Language Class Initialized
ERROR - 2023-11-30 16:09:07 --> 404 Page Not Found: /index
INFO - 2023-11-30 16:09:07 --> Config Class Initialized
INFO - 2023-11-30 16:09:07 --> Hooks Class Initialized
DEBUG - 2023-11-30 16:09:07 --> UTF-8 Support Enabled
INFO - 2023-11-30 16:09:07 --> Utf8 Class Initialized
INFO - 2023-11-30 16:09:07 --> URI Class Initialized
INFO - 2023-11-30 16:09:07 --> Router Class Initialized
INFO - 2023-11-30 16:09:07 --> Output Class Initialized
INFO - 2023-11-30 16:09:07 --> Security Class Initialized
DEBUG - 2023-11-30 16:09:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-30 16:09:07 --> Input Class Initialized
INFO - 2023-11-30 16:09:07 --> Language Class Initialized
INFO - 2023-11-30 16:09:07 --> Language Class Initialized
INFO - 2023-11-30 16:09:07 --> Config Class Initialized
INFO - 2023-11-30 16:09:07 --> Loader Class Initialized
INFO - 2023-11-30 16:09:07 --> Helper loaded: url_helper
INFO - 2023-11-30 16:09:07 --> Helper loaded: file_helper
INFO - 2023-11-30 16:09:07 --> Helper loaded: form_helper
INFO - 2023-11-30 16:09:07 --> Helper loaded: my_helper
INFO - 2023-11-30 16:09:07 --> Database Driver Class Initialized
INFO - 2023-11-30 16:09:07 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-30 16:09:07 --> Controller Class Initialized
INFO - 2023-11-30 16:09:14 --> Config Class Initialized
INFO - 2023-11-30 16:09:14 --> Hooks Class Initialized
DEBUG - 2023-11-30 16:09:14 --> UTF-8 Support Enabled
INFO - 2023-11-30 16:09:14 --> Utf8 Class Initialized
INFO - 2023-11-30 16:09:14 --> URI Class Initialized
INFO - 2023-11-30 16:09:14 --> Router Class Initialized
INFO - 2023-11-30 16:09:14 --> Output Class Initialized
INFO - 2023-11-30 16:09:14 --> Security Class Initialized
DEBUG - 2023-11-30 16:09:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-30 16:09:14 --> Input Class Initialized
INFO - 2023-11-30 16:09:14 --> Language Class Initialized
INFO - 2023-11-30 16:09:14 --> Language Class Initialized
INFO - 2023-11-30 16:09:14 --> Config Class Initialized
INFO - 2023-11-30 16:09:14 --> Loader Class Initialized
INFO - 2023-11-30 16:09:14 --> Helper loaded: url_helper
INFO - 2023-11-30 16:09:14 --> Helper loaded: file_helper
INFO - 2023-11-30 16:09:14 --> Helper loaded: form_helper
INFO - 2023-11-30 16:09:14 --> Helper loaded: my_helper
INFO - 2023-11-30 16:09:14 --> Database Driver Class Initialized
INFO - 2023-11-30 16:09:14 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-30 16:09:14 --> Controller Class Initialized
DEBUG - 2023-11-30 16:09:14 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/set_mapel/views/list.php
DEBUG - 2023-11-30 16:09:14 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-11-30 16:09:14 --> Final output sent to browser
DEBUG - 2023-11-30 16:09:14 --> Total execution time: 0.0350
INFO - 2023-11-30 16:09:15 --> Config Class Initialized
INFO - 2023-11-30 16:09:15 --> Hooks Class Initialized
DEBUG - 2023-11-30 16:09:15 --> UTF-8 Support Enabled
INFO - 2023-11-30 16:09:15 --> Utf8 Class Initialized
INFO - 2023-11-30 16:09:15 --> URI Class Initialized
INFO - 2023-11-30 16:09:15 --> Router Class Initialized
INFO - 2023-11-30 16:09:15 --> Output Class Initialized
INFO - 2023-11-30 16:09:15 --> Security Class Initialized
DEBUG - 2023-11-30 16:09:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-30 16:09:15 --> Input Class Initialized
INFO - 2023-11-30 16:09:15 --> Language Class Initialized
ERROR - 2023-11-30 16:09:15 --> 404 Page Not Found: /index
INFO - 2023-11-30 16:09:15 --> Config Class Initialized
INFO - 2023-11-30 16:09:15 --> Hooks Class Initialized
DEBUG - 2023-11-30 16:09:15 --> UTF-8 Support Enabled
INFO - 2023-11-30 16:09:15 --> Utf8 Class Initialized
INFO - 2023-11-30 16:09:15 --> URI Class Initialized
INFO - 2023-11-30 16:09:15 --> Router Class Initialized
INFO - 2023-11-30 16:09:15 --> Output Class Initialized
INFO - 2023-11-30 16:09:15 --> Security Class Initialized
DEBUG - 2023-11-30 16:09:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-30 16:09:15 --> Input Class Initialized
INFO - 2023-11-30 16:09:15 --> Language Class Initialized
INFO - 2023-11-30 16:09:15 --> Language Class Initialized
INFO - 2023-11-30 16:09:15 --> Config Class Initialized
INFO - 2023-11-30 16:09:15 --> Loader Class Initialized
INFO - 2023-11-30 16:09:15 --> Helper loaded: url_helper
INFO - 2023-11-30 16:09:15 --> Helper loaded: file_helper
INFO - 2023-11-30 16:09:15 --> Helper loaded: form_helper
INFO - 2023-11-30 16:09:15 --> Helper loaded: my_helper
INFO - 2023-11-30 16:09:15 --> Database Driver Class Initialized
INFO - 2023-11-30 16:09:15 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-30 16:09:15 --> Controller Class Initialized
INFO - 2023-11-30 16:09:17 --> Config Class Initialized
INFO - 2023-11-30 16:09:17 --> Hooks Class Initialized
DEBUG - 2023-11-30 16:09:17 --> UTF-8 Support Enabled
INFO - 2023-11-30 16:09:17 --> Utf8 Class Initialized
INFO - 2023-11-30 16:09:17 --> URI Class Initialized
INFO - 2023-11-30 16:09:17 --> Router Class Initialized
INFO - 2023-11-30 16:09:17 --> Output Class Initialized
INFO - 2023-11-30 16:09:17 --> Security Class Initialized
DEBUG - 2023-11-30 16:09:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-30 16:09:17 --> Input Class Initialized
INFO - 2023-11-30 16:09:17 --> Language Class Initialized
INFO - 2023-11-30 16:09:17 --> Language Class Initialized
INFO - 2023-11-30 16:09:17 --> Config Class Initialized
INFO - 2023-11-30 16:09:17 --> Loader Class Initialized
INFO - 2023-11-30 16:09:17 --> Helper loaded: url_helper
INFO - 2023-11-30 16:09:17 --> Helper loaded: file_helper
INFO - 2023-11-30 16:09:17 --> Helper loaded: form_helper
INFO - 2023-11-30 16:09:17 --> Helper loaded: my_helper
INFO - 2023-11-30 16:09:17 --> Database Driver Class Initialized
INFO - 2023-11-30 16:09:17 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-30 16:09:17 --> Controller Class Initialized
DEBUG - 2023-11-30 16:09:17 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/set_mapel/views/form.php
DEBUG - 2023-11-30 16:09:17 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-11-30 16:09:17 --> Final output sent to browser
DEBUG - 2023-11-30 16:09:17 --> Total execution time: 0.0360
INFO - 2023-11-30 16:09:30 --> Config Class Initialized
INFO - 2023-11-30 16:09:30 --> Hooks Class Initialized
DEBUG - 2023-11-30 16:09:30 --> UTF-8 Support Enabled
INFO - 2023-11-30 16:09:30 --> Utf8 Class Initialized
INFO - 2023-11-30 16:09:30 --> URI Class Initialized
INFO - 2023-11-30 16:09:30 --> Router Class Initialized
INFO - 2023-11-30 16:09:30 --> Output Class Initialized
INFO - 2023-11-30 16:09:30 --> Security Class Initialized
DEBUG - 2023-11-30 16:09:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-30 16:09:30 --> Input Class Initialized
INFO - 2023-11-30 16:09:30 --> Language Class Initialized
INFO - 2023-11-30 16:09:30 --> Language Class Initialized
INFO - 2023-11-30 16:09:30 --> Config Class Initialized
INFO - 2023-11-30 16:09:30 --> Loader Class Initialized
INFO - 2023-11-30 16:09:30 --> Helper loaded: url_helper
INFO - 2023-11-30 16:09:30 --> Helper loaded: file_helper
INFO - 2023-11-30 16:09:30 --> Helper loaded: form_helper
INFO - 2023-11-30 16:09:30 --> Helper loaded: my_helper
INFO - 2023-11-30 16:09:30 --> Database Driver Class Initialized
INFO - 2023-11-30 16:09:30 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-30 16:09:30 --> Controller Class Initialized
INFO - 2023-11-30 16:09:30 --> Config Class Initialized
INFO - 2023-11-30 16:09:30 --> Hooks Class Initialized
DEBUG - 2023-11-30 16:09:30 --> UTF-8 Support Enabled
INFO - 2023-11-30 16:09:30 --> Utf8 Class Initialized
INFO - 2023-11-30 16:09:30 --> URI Class Initialized
INFO - 2023-11-30 16:09:30 --> Router Class Initialized
INFO - 2023-11-30 16:09:30 --> Output Class Initialized
INFO - 2023-11-30 16:09:30 --> Security Class Initialized
DEBUG - 2023-11-30 16:09:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-30 16:09:30 --> Input Class Initialized
INFO - 2023-11-30 16:09:30 --> Language Class Initialized
INFO - 2023-11-30 16:09:30 --> Language Class Initialized
INFO - 2023-11-30 16:09:30 --> Config Class Initialized
INFO - 2023-11-30 16:09:30 --> Loader Class Initialized
INFO - 2023-11-30 16:09:30 --> Helper loaded: url_helper
INFO - 2023-11-30 16:09:30 --> Helper loaded: file_helper
INFO - 2023-11-30 16:09:30 --> Helper loaded: form_helper
INFO - 2023-11-30 16:09:30 --> Helper loaded: my_helper
INFO - 2023-11-30 16:09:30 --> Database Driver Class Initialized
INFO - 2023-11-30 16:09:30 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-30 16:09:30 --> Controller Class Initialized
DEBUG - 2023-11-30 16:09:30 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/set_mapel/views/list.php
DEBUG - 2023-11-30 16:09:30 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-11-30 16:09:30 --> Final output sent to browser
DEBUG - 2023-11-30 16:09:30 --> Total execution time: 0.0387
INFO - 2023-11-30 16:09:30 --> Config Class Initialized
INFO - 2023-11-30 16:09:30 --> Hooks Class Initialized
DEBUG - 2023-11-30 16:09:30 --> UTF-8 Support Enabled
INFO - 2023-11-30 16:09:30 --> Utf8 Class Initialized
INFO - 2023-11-30 16:09:30 --> URI Class Initialized
INFO - 2023-11-30 16:09:30 --> Router Class Initialized
INFO - 2023-11-30 16:09:30 --> Output Class Initialized
INFO - 2023-11-30 16:09:30 --> Security Class Initialized
DEBUG - 2023-11-30 16:09:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-30 16:09:30 --> Input Class Initialized
INFO - 2023-11-30 16:09:30 --> Language Class Initialized
ERROR - 2023-11-30 16:09:30 --> 404 Page Not Found: /index
INFO - 2023-11-30 16:09:30 --> Config Class Initialized
INFO - 2023-11-30 16:09:30 --> Hooks Class Initialized
DEBUG - 2023-11-30 16:09:30 --> UTF-8 Support Enabled
INFO - 2023-11-30 16:09:30 --> Utf8 Class Initialized
INFO - 2023-11-30 16:09:30 --> URI Class Initialized
INFO - 2023-11-30 16:09:30 --> Router Class Initialized
INFO - 2023-11-30 16:09:30 --> Output Class Initialized
INFO - 2023-11-30 16:09:30 --> Security Class Initialized
DEBUG - 2023-11-30 16:09:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-30 16:09:30 --> Input Class Initialized
INFO - 2023-11-30 16:09:30 --> Language Class Initialized
INFO - 2023-11-30 16:09:30 --> Language Class Initialized
INFO - 2023-11-30 16:09:30 --> Config Class Initialized
INFO - 2023-11-30 16:09:30 --> Loader Class Initialized
INFO - 2023-11-30 16:09:30 --> Helper loaded: url_helper
INFO - 2023-11-30 16:09:30 --> Helper loaded: file_helper
INFO - 2023-11-30 16:09:30 --> Helper loaded: form_helper
INFO - 2023-11-30 16:09:30 --> Helper loaded: my_helper
INFO - 2023-11-30 16:09:30 --> Database Driver Class Initialized
INFO - 2023-11-30 16:09:30 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-30 16:09:30 --> Controller Class Initialized
INFO - 2023-11-30 16:09:36 --> Config Class Initialized
INFO - 2023-11-30 16:09:36 --> Hooks Class Initialized
DEBUG - 2023-11-30 16:09:36 --> UTF-8 Support Enabled
INFO - 2023-11-30 16:09:36 --> Utf8 Class Initialized
INFO - 2023-11-30 16:09:36 --> URI Class Initialized
INFO - 2023-11-30 16:09:36 --> Router Class Initialized
INFO - 2023-11-30 16:09:36 --> Output Class Initialized
INFO - 2023-11-30 16:09:36 --> Security Class Initialized
DEBUG - 2023-11-30 16:09:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-30 16:09:36 --> Input Class Initialized
INFO - 2023-11-30 16:09:36 --> Language Class Initialized
INFO - 2023-11-30 16:09:36 --> Language Class Initialized
INFO - 2023-11-30 16:09:36 --> Config Class Initialized
INFO - 2023-11-30 16:09:36 --> Loader Class Initialized
INFO - 2023-11-30 16:09:36 --> Helper loaded: url_helper
INFO - 2023-11-30 16:09:36 --> Helper loaded: file_helper
INFO - 2023-11-30 16:09:36 --> Helper loaded: form_helper
INFO - 2023-11-30 16:09:36 --> Helper loaded: my_helper
INFO - 2023-11-30 16:09:36 --> Database Driver Class Initialized
INFO - 2023-11-30 16:09:36 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-30 16:09:36 --> Controller Class Initialized
INFO - 2023-11-30 16:09:36 --> Helper loaded: cookie_helper
INFO - 2023-11-30 16:09:36 --> Config Class Initialized
INFO - 2023-11-30 16:09:36 --> Hooks Class Initialized
DEBUG - 2023-11-30 16:09:36 --> UTF-8 Support Enabled
INFO - 2023-11-30 16:09:36 --> Utf8 Class Initialized
INFO - 2023-11-30 16:09:36 --> URI Class Initialized
INFO - 2023-11-30 16:09:36 --> Router Class Initialized
INFO - 2023-11-30 16:09:36 --> Output Class Initialized
INFO - 2023-11-30 16:09:36 --> Security Class Initialized
DEBUG - 2023-11-30 16:09:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-30 16:09:36 --> Input Class Initialized
INFO - 2023-11-30 16:09:36 --> Language Class Initialized
INFO - 2023-11-30 16:09:36 --> Language Class Initialized
INFO - 2023-11-30 16:09:36 --> Config Class Initialized
INFO - 2023-11-30 16:09:36 --> Loader Class Initialized
INFO - 2023-11-30 16:09:36 --> Helper loaded: url_helper
INFO - 2023-11-30 16:09:36 --> Helper loaded: file_helper
INFO - 2023-11-30 16:09:36 --> Helper loaded: form_helper
INFO - 2023-11-30 16:09:36 --> Helper loaded: my_helper
INFO - 2023-11-30 16:09:36 --> Database Driver Class Initialized
INFO - 2023-11-30 16:09:36 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-30 16:09:36 --> Controller Class Initialized
INFO - 2023-11-30 16:09:36 --> Config Class Initialized
INFO - 2023-11-30 16:09:36 --> Hooks Class Initialized
DEBUG - 2023-11-30 16:09:36 --> UTF-8 Support Enabled
INFO - 2023-11-30 16:09:36 --> Utf8 Class Initialized
INFO - 2023-11-30 16:09:36 --> URI Class Initialized
INFO - 2023-11-30 16:09:36 --> Router Class Initialized
INFO - 2023-11-30 16:09:36 --> Output Class Initialized
INFO - 2023-11-30 16:09:36 --> Security Class Initialized
DEBUG - 2023-11-30 16:09:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-30 16:09:36 --> Input Class Initialized
INFO - 2023-11-30 16:09:36 --> Language Class Initialized
INFO - 2023-11-30 16:09:36 --> Language Class Initialized
INFO - 2023-11-30 16:09:36 --> Config Class Initialized
INFO - 2023-11-30 16:09:36 --> Loader Class Initialized
INFO - 2023-11-30 16:09:36 --> Helper loaded: url_helper
INFO - 2023-11-30 16:09:36 --> Helper loaded: file_helper
INFO - 2023-11-30 16:09:36 --> Helper loaded: form_helper
INFO - 2023-11-30 16:09:36 --> Helper loaded: my_helper
INFO - 2023-11-30 16:09:36 --> Database Driver Class Initialized
INFO - 2023-11-30 16:09:36 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-30 16:09:36 --> Controller Class Initialized
DEBUG - 2023-11-30 16:09:36 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/login/views/login.php
DEBUG - 2023-11-30 16:09:36 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-11-30 16:09:36 --> Final output sent to browser
DEBUG - 2023-11-30 16:09:36 --> Total execution time: 0.1161
INFO - 2023-11-30 16:09:48 --> Config Class Initialized
INFO - 2023-11-30 16:09:48 --> Hooks Class Initialized
DEBUG - 2023-11-30 16:09:48 --> UTF-8 Support Enabled
INFO - 2023-11-30 16:09:48 --> Utf8 Class Initialized
INFO - 2023-11-30 16:09:48 --> URI Class Initialized
INFO - 2023-11-30 16:09:48 --> Router Class Initialized
INFO - 2023-11-30 16:09:48 --> Output Class Initialized
INFO - 2023-11-30 16:09:48 --> Security Class Initialized
DEBUG - 2023-11-30 16:09:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-30 16:09:48 --> Input Class Initialized
INFO - 2023-11-30 16:09:48 --> Language Class Initialized
INFO - 2023-11-30 16:09:48 --> Language Class Initialized
INFO - 2023-11-30 16:09:48 --> Config Class Initialized
INFO - 2023-11-30 16:09:48 --> Loader Class Initialized
INFO - 2023-11-30 16:09:48 --> Helper loaded: url_helper
INFO - 2023-11-30 16:09:48 --> Helper loaded: file_helper
INFO - 2023-11-30 16:09:48 --> Helper loaded: form_helper
INFO - 2023-11-30 16:09:48 --> Helper loaded: my_helper
INFO - 2023-11-30 16:09:48 --> Database Driver Class Initialized
INFO - 2023-11-30 16:09:48 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-30 16:09:48 --> Controller Class Initialized
INFO - 2023-11-30 16:09:48 --> Helper loaded: cookie_helper
INFO - 2023-11-30 16:09:48 --> Final output sent to browser
DEBUG - 2023-11-30 16:09:48 --> Total execution time: 0.2594
INFO - 2023-11-30 16:09:48 --> Config Class Initialized
INFO - 2023-11-30 16:09:48 --> Hooks Class Initialized
DEBUG - 2023-11-30 16:09:48 --> UTF-8 Support Enabled
INFO - 2023-11-30 16:09:48 --> Utf8 Class Initialized
INFO - 2023-11-30 16:09:48 --> URI Class Initialized
INFO - 2023-11-30 16:09:48 --> Router Class Initialized
INFO - 2023-11-30 16:09:48 --> Output Class Initialized
INFO - 2023-11-30 16:09:48 --> Security Class Initialized
DEBUG - 2023-11-30 16:09:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-30 16:09:48 --> Input Class Initialized
INFO - 2023-11-30 16:09:48 --> Language Class Initialized
INFO - 2023-11-30 16:09:48 --> Language Class Initialized
INFO - 2023-11-30 16:09:48 --> Config Class Initialized
INFO - 2023-11-30 16:09:48 --> Loader Class Initialized
INFO - 2023-11-30 16:09:48 --> Helper loaded: url_helper
INFO - 2023-11-30 16:09:48 --> Helper loaded: file_helper
INFO - 2023-11-30 16:09:48 --> Helper loaded: form_helper
INFO - 2023-11-30 16:09:48 --> Helper loaded: my_helper
INFO - 2023-11-30 16:09:48 --> Database Driver Class Initialized
INFO - 2023-11-30 16:09:48 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-30 16:09:48 --> Controller Class Initialized
DEBUG - 2023-11-30 16:09:48 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/home/views/v_home_guru.php
DEBUG - 2023-11-30 16:09:48 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-11-30 16:09:48 --> Final output sent to browser
DEBUG - 2023-11-30 16:09:48 --> Total execution time: 0.0470
INFO - 2023-11-30 16:09:55 --> Config Class Initialized
INFO - 2023-11-30 16:09:55 --> Hooks Class Initialized
DEBUG - 2023-11-30 16:09:55 --> UTF-8 Support Enabled
INFO - 2023-11-30 16:09:55 --> Utf8 Class Initialized
INFO - 2023-11-30 16:09:55 --> URI Class Initialized
INFO - 2023-11-30 16:09:55 --> Router Class Initialized
INFO - 2023-11-30 16:09:55 --> Output Class Initialized
INFO - 2023-11-30 16:09:55 --> Security Class Initialized
DEBUG - 2023-11-30 16:09:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-30 16:09:55 --> Input Class Initialized
INFO - 2023-11-30 16:09:55 --> Language Class Initialized
INFO - 2023-11-30 16:09:55 --> Language Class Initialized
INFO - 2023-11-30 16:09:55 --> Config Class Initialized
INFO - 2023-11-30 16:09:55 --> Loader Class Initialized
INFO - 2023-11-30 16:09:55 --> Helper loaded: url_helper
INFO - 2023-11-30 16:09:55 --> Helper loaded: file_helper
INFO - 2023-11-30 16:09:55 --> Helper loaded: form_helper
INFO - 2023-11-30 16:09:55 --> Helper loaded: my_helper
INFO - 2023-11-30 16:09:55 --> Database Driver Class Initialized
INFO - 2023-11-30 16:09:55 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-30 16:09:55 --> Controller Class Initialized
DEBUG - 2023-11-30 16:09:55 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/view_mapel/views/v_view_mapel.php
DEBUG - 2023-11-30 16:09:55 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-11-30 16:09:55 --> Final output sent to browser
DEBUG - 2023-11-30 16:09:55 --> Total execution time: 0.0551
INFO - 2023-11-30 16:09:58 --> Config Class Initialized
INFO - 2023-11-30 16:09:58 --> Hooks Class Initialized
DEBUG - 2023-11-30 16:09:58 --> UTF-8 Support Enabled
INFO - 2023-11-30 16:09:58 --> Utf8 Class Initialized
INFO - 2023-11-30 16:09:58 --> URI Class Initialized
INFO - 2023-11-30 16:09:58 --> Router Class Initialized
INFO - 2023-11-30 16:09:58 --> Output Class Initialized
INFO - 2023-11-30 16:09:58 --> Security Class Initialized
DEBUG - 2023-11-30 16:09:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-30 16:09:58 --> Input Class Initialized
INFO - 2023-11-30 16:09:58 --> Language Class Initialized
INFO - 2023-11-30 16:09:58 --> Language Class Initialized
INFO - 2023-11-30 16:09:58 --> Config Class Initialized
INFO - 2023-11-30 16:09:58 --> Loader Class Initialized
INFO - 2023-11-30 16:09:58 --> Helper loaded: url_helper
INFO - 2023-11-30 16:09:58 --> Helper loaded: file_helper
INFO - 2023-11-30 16:09:58 --> Helper loaded: form_helper
INFO - 2023-11-30 16:09:58 --> Helper loaded: my_helper
INFO - 2023-11-30 16:09:58 --> Database Driver Class Initialized
INFO - 2023-11-30 16:09:58 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-30 16:09:58 --> Controller Class Initialized
DEBUG - 2023-11-30 16:09:58 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/views/list.php
DEBUG - 2023-11-30 16:09:58 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-11-30 16:09:58 --> Final output sent to browser
DEBUG - 2023-11-30 16:09:58 --> Total execution time: 0.0711
INFO - 2023-11-30 16:09:58 --> Config Class Initialized
INFO - 2023-11-30 16:09:58 --> Hooks Class Initialized
DEBUG - 2023-11-30 16:09:58 --> UTF-8 Support Enabled
INFO - 2023-11-30 16:09:58 --> Utf8 Class Initialized
INFO - 2023-11-30 16:09:58 --> URI Class Initialized
INFO - 2023-11-30 16:09:58 --> Router Class Initialized
INFO - 2023-11-30 16:09:58 --> Output Class Initialized
INFO - 2023-11-30 16:09:58 --> Security Class Initialized
DEBUG - 2023-11-30 16:09:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-30 16:09:58 --> Input Class Initialized
INFO - 2023-11-30 16:09:58 --> Language Class Initialized
INFO - 2023-11-30 16:09:58 --> Language Class Initialized
INFO - 2023-11-30 16:09:58 --> Config Class Initialized
INFO - 2023-11-30 16:09:58 --> Loader Class Initialized
INFO - 2023-11-30 16:09:58 --> Helper loaded: url_helper
INFO - 2023-11-30 16:09:58 --> Helper loaded: file_helper
INFO - 2023-11-30 16:09:58 --> Helper loaded: form_helper
INFO - 2023-11-30 16:09:58 --> Helper loaded: my_helper
INFO - 2023-11-30 16:09:58 --> Database Driver Class Initialized
INFO - 2023-11-30 16:09:58 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-30 16:09:58 --> Controller Class Initialized
INFO - 2023-11-30 16:10:01 --> Config Class Initialized
INFO - 2023-11-30 16:10:01 --> Hooks Class Initialized
DEBUG - 2023-11-30 16:10:01 --> UTF-8 Support Enabled
INFO - 2023-11-30 16:10:01 --> Utf8 Class Initialized
INFO - 2023-11-30 16:10:01 --> URI Class Initialized
INFO - 2023-11-30 16:10:01 --> Router Class Initialized
INFO - 2023-11-30 16:10:01 --> Output Class Initialized
INFO - 2023-11-30 16:10:01 --> Security Class Initialized
DEBUG - 2023-11-30 16:10:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-30 16:10:01 --> Input Class Initialized
INFO - 2023-11-30 16:10:01 --> Language Class Initialized
INFO - 2023-11-30 16:10:01 --> Language Class Initialized
INFO - 2023-11-30 16:10:01 --> Config Class Initialized
INFO - 2023-11-30 16:10:01 --> Loader Class Initialized
INFO - 2023-11-30 16:10:01 --> Helper loaded: url_helper
INFO - 2023-11-30 16:10:01 --> Helper loaded: file_helper
INFO - 2023-11-30 16:10:01 --> Helper loaded: form_helper
INFO - 2023-11-30 16:10:01 --> Helper loaded: my_helper
INFO - 2023-11-30 16:10:01 --> Database Driver Class Initialized
INFO - 2023-11-30 16:10:01 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-30 16:10:01 --> Controller Class Initialized
INFO - 2023-11-30 16:10:01 --> Helper loaded: cookie_helper
INFO - 2023-11-30 16:10:01 --> Config Class Initialized
INFO - 2023-11-30 16:10:01 --> Hooks Class Initialized
DEBUG - 2023-11-30 16:10:01 --> UTF-8 Support Enabled
INFO - 2023-11-30 16:10:01 --> Utf8 Class Initialized
INFO - 2023-11-30 16:10:01 --> URI Class Initialized
INFO - 2023-11-30 16:10:01 --> Router Class Initialized
INFO - 2023-11-30 16:10:01 --> Output Class Initialized
INFO - 2023-11-30 16:10:01 --> Security Class Initialized
DEBUG - 2023-11-30 16:10:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-30 16:10:01 --> Input Class Initialized
INFO - 2023-11-30 16:10:01 --> Language Class Initialized
INFO - 2023-11-30 16:10:01 --> Language Class Initialized
INFO - 2023-11-30 16:10:01 --> Config Class Initialized
INFO - 2023-11-30 16:10:01 --> Loader Class Initialized
INFO - 2023-11-30 16:10:01 --> Helper loaded: url_helper
INFO - 2023-11-30 16:10:01 --> Helper loaded: file_helper
INFO - 2023-11-30 16:10:01 --> Helper loaded: form_helper
INFO - 2023-11-30 16:10:01 --> Helper loaded: my_helper
INFO - 2023-11-30 16:10:01 --> Database Driver Class Initialized
INFO - 2023-11-30 16:10:01 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-30 16:10:01 --> Controller Class Initialized
INFO - 2023-11-30 16:10:01 --> Config Class Initialized
INFO - 2023-11-30 16:10:01 --> Hooks Class Initialized
DEBUG - 2023-11-30 16:10:01 --> UTF-8 Support Enabled
INFO - 2023-11-30 16:10:01 --> Utf8 Class Initialized
INFO - 2023-11-30 16:10:01 --> URI Class Initialized
INFO - 2023-11-30 16:10:01 --> Router Class Initialized
INFO - 2023-11-30 16:10:01 --> Output Class Initialized
INFO - 2023-11-30 16:10:01 --> Security Class Initialized
DEBUG - 2023-11-30 16:10:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-30 16:10:01 --> Input Class Initialized
INFO - 2023-11-30 16:10:01 --> Language Class Initialized
INFO - 2023-11-30 16:10:01 --> Language Class Initialized
INFO - 2023-11-30 16:10:01 --> Config Class Initialized
INFO - 2023-11-30 16:10:01 --> Loader Class Initialized
INFO - 2023-11-30 16:10:01 --> Helper loaded: url_helper
INFO - 2023-11-30 16:10:01 --> Helper loaded: file_helper
INFO - 2023-11-30 16:10:01 --> Helper loaded: form_helper
INFO - 2023-11-30 16:10:01 --> Helper loaded: my_helper
INFO - 2023-11-30 16:10:01 --> Database Driver Class Initialized
INFO - 2023-11-30 16:10:01 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-30 16:10:01 --> Controller Class Initialized
DEBUG - 2023-11-30 16:10:01 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/login/views/login.php
DEBUG - 2023-11-30 16:10:01 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-11-30 16:10:01 --> Final output sent to browser
DEBUG - 2023-11-30 16:10:01 --> Total execution time: 0.0422
INFO - 2023-11-30 16:10:05 --> Config Class Initialized
INFO - 2023-11-30 16:10:05 --> Hooks Class Initialized
DEBUG - 2023-11-30 16:10:05 --> UTF-8 Support Enabled
INFO - 2023-11-30 16:10:05 --> Utf8 Class Initialized
INFO - 2023-11-30 16:10:05 --> URI Class Initialized
INFO - 2023-11-30 16:10:05 --> Router Class Initialized
INFO - 2023-11-30 16:10:05 --> Output Class Initialized
INFO - 2023-11-30 16:10:05 --> Security Class Initialized
DEBUG - 2023-11-30 16:10:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-30 16:10:05 --> Input Class Initialized
INFO - 2023-11-30 16:10:05 --> Language Class Initialized
INFO - 2023-11-30 16:10:05 --> Language Class Initialized
INFO - 2023-11-30 16:10:05 --> Config Class Initialized
INFO - 2023-11-30 16:10:05 --> Loader Class Initialized
INFO - 2023-11-30 16:10:05 --> Helper loaded: url_helper
INFO - 2023-11-30 16:10:05 --> Helper loaded: file_helper
INFO - 2023-11-30 16:10:05 --> Helper loaded: form_helper
INFO - 2023-11-30 16:10:05 --> Helper loaded: my_helper
INFO - 2023-11-30 16:10:05 --> Database Driver Class Initialized
INFO - 2023-11-30 16:10:05 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-30 16:10:05 --> Controller Class Initialized
INFO - 2023-11-30 16:10:05 --> Helper loaded: cookie_helper
INFO - 2023-11-30 16:10:05 --> Final output sent to browser
DEBUG - 2023-11-30 16:10:05 --> Total execution time: 0.0523
INFO - 2023-11-30 16:10:05 --> Config Class Initialized
INFO - 2023-11-30 16:10:05 --> Hooks Class Initialized
DEBUG - 2023-11-30 16:10:05 --> UTF-8 Support Enabled
INFO - 2023-11-30 16:10:05 --> Utf8 Class Initialized
INFO - 2023-11-30 16:10:05 --> URI Class Initialized
INFO - 2023-11-30 16:10:05 --> Router Class Initialized
INFO - 2023-11-30 16:10:05 --> Output Class Initialized
INFO - 2023-11-30 16:10:05 --> Security Class Initialized
DEBUG - 2023-11-30 16:10:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-30 16:10:05 --> Input Class Initialized
INFO - 2023-11-30 16:10:05 --> Language Class Initialized
INFO - 2023-11-30 16:10:05 --> Language Class Initialized
INFO - 2023-11-30 16:10:05 --> Config Class Initialized
INFO - 2023-11-30 16:10:05 --> Loader Class Initialized
INFO - 2023-11-30 16:10:05 --> Helper loaded: url_helper
INFO - 2023-11-30 16:10:05 --> Helper loaded: file_helper
INFO - 2023-11-30 16:10:05 --> Helper loaded: form_helper
INFO - 2023-11-30 16:10:05 --> Helper loaded: my_helper
INFO - 2023-11-30 16:10:05 --> Database Driver Class Initialized
INFO - 2023-11-30 16:10:05 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-30 16:10:05 --> Controller Class Initialized
DEBUG - 2023-11-30 16:10:05 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/home/views/v_home_guru.php
DEBUG - 2023-11-30 16:10:05 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-11-30 16:10:05 --> Final output sent to browser
DEBUG - 2023-11-30 16:10:05 --> Total execution time: 0.0421
INFO - 2023-11-30 16:10:12 --> Config Class Initialized
INFO - 2023-11-30 16:10:12 --> Hooks Class Initialized
DEBUG - 2023-11-30 16:10:12 --> UTF-8 Support Enabled
INFO - 2023-11-30 16:10:12 --> Utf8 Class Initialized
INFO - 2023-11-30 16:10:12 --> URI Class Initialized
INFO - 2023-11-30 16:10:12 --> Router Class Initialized
INFO - 2023-11-30 16:10:12 --> Output Class Initialized
INFO - 2023-11-30 16:10:12 --> Security Class Initialized
DEBUG - 2023-11-30 16:10:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-30 16:10:12 --> Input Class Initialized
INFO - 2023-11-30 16:10:12 --> Language Class Initialized
INFO - 2023-11-30 16:10:12 --> Language Class Initialized
INFO - 2023-11-30 16:10:12 --> Config Class Initialized
INFO - 2023-11-30 16:10:12 --> Loader Class Initialized
INFO - 2023-11-30 16:10:12 --> Helper loaded: url_helper
INFO - 2023-11-30 16:10:12 --> Helper loaded: file_helper
INFO - 2023-11-30 16:10:12 --> Helper loaded: form_helper
INFO - 2023-11-30 16:10:12 --> Helper loaded: my_helper
INFO - 2023-11-30 16:10:12 --> Database Driver Class Initialized
INFO - 2023-11-30 16:10:12 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-30 16:10:12 --> Controller Class Initialized
DEBUG - 2023-11-30 16:10:12 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/views/list.php
DEBUG - 2023-11-30 16:10:12 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-11-30 16:10:12 --> Final output sent to browser
DEBUG - 2023-11-30 16:10:12 --> Total execution time: 0.0789
INFO - 2023-11-30 16:10:15 --> Config Class Initialized
INFO - 2023-11-30 16:10:15 --> Hooks Class Initialized
DEBUG - 2023-11-30 16:10:15 --> UTF-8 Support Enabled
INFO - 2023-11-30 16:10:15 --> Utf8 Class Initialized
INFO - 2023-11-30 16:10:15 --> URI Class Initialized
INFO - 2023-11-30 16:10:15 --> Router Class Initialized
INFO - 2023-11-30 16:10:15 --> Output Class Initialized
INFO - 2023-11-30 16:10:15 --> Security Class Initialized
DEBUG - 2023-11-30 16:10:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-30 16:10:15 --> Input Class Initialized
INFO - 2023-11-30 16:10:15 --> Language Class Initialized
INFO - 2023-11-30 16:10:15 --> Language Class Initialized
INFO - 2023-11-30 16:10:15 --> Config Class Initialized
INFO - 2023-11-30 16:10:15 --> Loader Class Initialized
INFO - 2023-11-30 16:10:15 --> Helper loaded: url_helper
INFO - 2023-11-30 16:10:15 --> Helper loaded: file_helper
INFO - 2023-11-30 16:10:15 --> Helper loaded: form_helper
INFO - 2023-11-30 16:10:15 --> Helper loaded: my_helper
INFO - 2023-11-30 16:10:15 --> Database Driver Class Initialized
INFO - 2023-11-30 16:10:15 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-30 16:10:15 --> Controller Class Initialized
DEBUG - 2023-11-30 16:10:15 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/views/cetak_ikm.php
INFO - 2023-11-30 16:10:18 --> Final output sent to browser
DEBUG - 2023-11-30 16:10:18 --> Total execution time: 2.9195
INFO - 2023-11-30 16:10:19 --> Config Class Initialized
INFO - 2023-11-30 16:10:19 --> Hooks Class Initialized
DEBUG - 2023-11-30 16:10:19 --> UTF-8 Support Enabled
INFO - 2023-11-30 16:10:19 --> Utf8 Class Initialized
INFO - 2023-11-30 16:10:19 --> URI Class Initialized
INFO - 2023-11-30 16:10:19 --> Router Class Initialized
INFO - 2023-11-30 16:10:19 --> Output Class Initialized
INFO - 2023-11-30 16:10:19 --> Security Class Initialized
DEBUG - 2023-11-30 16:10:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-30 16:10:19 --> Input Class Initialized
INFO - 2023-11-30 16:10:19 --> Language Class Initialized
INFO - 2023-11-30 16:10:19 --> Language Class Initialized
INFO - 2023-11-30 16:10:19 --> Config Class Initialized
INFO - 2023-11-30 16:10:19 --> Loader Class Initialized
INFO - 2023-11-30 16:10:19 --> Helper loaded: url_helper
INFO - 2023-11-30 16:10:19 --> Helper loaded: file_helper
INFO - 2023-11-30 16:10:19 --> Helper loaded: form_helper
INFO - 2023-11-30 16:10:19 --> Helper loaded: my_helper
INFO - 2023-11-30 16:10:19 --> Database Driver Class Initialized
INFO - 2023-11-30 16:10:19 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-30 16:10:19 --> Controller Class Initialized
ERROR - 2023-11-30 16:10:20 --> Severity: Notice --> Undefined offset: 21 /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 2369
ERROR - 2023-11-30 16:10:20 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 2369
ERROR - 2023-11-30 16:10:20 --> Severity: Warning --> Invalid argument supplied for foreach() /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 2369
ERROR - 2023-11-30 16:10:20 --> Severity: Notice --> Undefined offset: 22 /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 2407
ERROR - 2023-11-30 16:10:20 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 2407
ERROR - 2023-11-30 16:10:20 --> Severity: Warning --> Invalid argument supplied for foreach() /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 2407
ERROR - 2023-11-30 16:10:20 --> Severity: Notice --> Undefined offset: 23 /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 2445
ERROR - 2023-11-30 16:10:20 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 2445
ERROR - 2023-11-30 16:10:20 --> Severity: Warning --> Invalid argument supplied for foreach() /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 2445
DEBUG - 2023-11-30 16:10:20 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/views/cetak_mh.php
INFO - 2023-11-30 16:10:33 --> Final output sent to browser
DEBUG - 2023-11-30 16:10:33 --> Total execution time: 14.0863
INFO - 2023-11-30 16:11:06 --> Config Class Initialized
INFO - 2023-11-30 16:11:06 --> Hooks Class Initialized
DEBUG - 2023-11-30 16:11:06 --> UTF-8 Support Enabled
INFO - 2023-11-30 16:11:06 --> Utf8 Class Initialized
INFO - 2023-11-30 16:11:06 --> URI Class Initialized
INFO - 2023-11-30 16:11:06 --> Router Class Initialized
INFO - 2023-11-30 16:11:06 --> Output Class Initialized
INFO - 2023-11-30 16:11:06 --> Security Class Initialized
DEBUG - 2023-11-30 16:11:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-30 16:11:06 --> Input Class Initialized
INFO - 2023-11-30 16:11:06 --> Language Class Initialized
INFO - 2023-11-30 16:11:06 --> Language Class Initialized
INFO - 2023-11-30 16:11:06 --> Config Class Initialized
INFO - 2023-11-30 16:11:06 --> Loader Class Initialized
INFO - 2023-11-30 16:11:06 --> Helper loaded: url_helper
INFO - 2023-11-30 16:11:06 --> Helper loaded: file_helper
INFO - 2023-11-30 16:11:06 --> Helper loaded: form_helper
INFO - 2023-11-30 16:11:06 --> Helper loaded: my_helper
INFO - 2023-11-30 16:11:06 --> Database Driver Class Initialized
INFO - 2023-11-30 16:11:06 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-30 16:11:06 --> Controller Class Initialized
ERROR - 2023-11-30 16:11:06 --> Severity: Notice --> Undefined offset: 21 /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 2369
ERROR - 2023-11-30 16:11:06 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 2369
ERROR - 2023-11-30 16:11:06 --> Severity: Warning --> Invalid argument supplied for foreach() /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 2369
ERROR - 2023-11-30 16:11:06 --> Severity: Notice --> Undefined offset: 22 /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 2407
ERROR - 2023-11-30 16:11:06 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 2407
ERROR - 2023-11-30 16:11:06 --> Severity: Warning --> Invalid argument supplied for foreach() /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 2407
ERROR - 2023-11-30 16:11:06 --> Severity: Notice --> Undefined offset: 23 /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 2445
ERROR - 2023-11-30 16:11:06 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 2445
ERROR - 2023-11-30 16:11:06 --> Severity: Warning --> Invalid argument supplied for foreach() /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 2445
DEBUG - 2023-11-30 16:11:06 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/views/cetak_mh.php
INFO - 2023-11-30 16:11:13 --> Final output sent to browser
DEBUG - 2023-11-30 16:11:13 --> Total execution time: 6.9594
INFO - 2023-11-30 16:11:25 --> Config Class Initialized
INFO - 2023-11-30 16:11:25 --> Hooks Class Initialized
DEBUG - 2023-11-30 16:11:25 --> UTF-8 Support Enabled
INFO - 2023-11-30 16:11:25 --> Utf8 Class Initialized
INFO - 2023-11-30 16:11:25 --> URI Class Initialized
INFO - 2023-11-30 16:11:25 --> Router Class Initialized
INFO - 2023-11-30 16:11:25 --> Output Class Initialized
INFO - 2023-11-30 16:11:25 --> Security Class Initialized
DEBUG - 2023-11-30 16:11:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-30 16:11:25 --> Input Class Initialized
INFO - 2023-11-30 16:11:25 --> Language Class Initialized
INFO - 2023-11-30 16:11:25 --> Language Class Initialized
INFO - 2023-11-30 16:11:25 --> Config Class Initialized
INFO - 2023-11-30 16:11:25 --> Loader Class Initialized
INFO - 2023-11-30 16:11:25 --> Helper loaded: url_helper
INFO - 2023-11-30 16:11:25 --> Helper loaded: file_helper
INFO - 2023-11-30 16:11:25 --> Helper loaded: form_helper
INFO - 2023-11-30 16:11:25 --> Helper loaded: my_helper
INFO - 2023-11-30 16:11:25 --> Database Driver Class Initialized
INFO - 2023-11-30 16:11:25 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-30 16:11:25 --> Controller Class Initialized
INFO - 2023-11-30 16:11:25 --> Helper loaded: cookie_helper
INFO - 2023-11-30 16:11:25 --> Config Class Initialized
INFO - 2023-11-30 16:11:25 --> Hooks Class Initialized
DEBUG - 2023-11-30 16:11:25 --> UTF-8 Support Enabled
INFO - 2023-11-30 16:11:25 --> Utf8 Class Initialized
INFO - 2023-11-30 16:11:25 --> URI Class Initialized
INFO - 2023-11-30 16:11:25 --> Router Class Initialized
INFO - 2023-11-30 16:11:25 --> Output Class Initialized
INFO - 2023-11-30 16:11:25 --> Security Class Initialized
DEBUG - 2023-11-30 16:11:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-30 16:11:25 --> Input Class Initialized
INFO - 2023-11-30 16:11:25 --> Language Class Initialized
INFO - 2023-11-30 16:11:25 --> Language Class Initialized
INFO - 2023-11-30 16:11:25 --> Config Class Initialized
INFO - 2023-11-30 16:11:25 --> Loader Class Initialized
INFO - 2023-11-30 16:11:25 --> Helper loaded: url_helper
INFO - 2023-11-30 16:11:25 --> Helper loaded: file_helper
INFO - 2023-11-30 16:11:25 --> Helper loaded: form_helper
INFO - 2023-11-30 16:11:25 --> Helper loaded: my_helper
INFO - 2023-11-30 16:11:25 --> Database Driver Class Initialized
INFO - 2023-11-30 16:11:25 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-30 16:11:25 --> Controller Class Initialized
INFO - 2023-11-30 16:11:25 --> Config Class Initialized
INFO - 2023-11-30 16:11:25 --> Hooks Class Initialized
DEBUG - 2023-11-30 16:11:25 --> UTF-8 Support Enabled
INFO - 2023-11-30 16:11:25 --> Utf8 Class Initialized
INFO - 2023-11-30 16:11:25 --> URI Class Initialized
INFO - 2023-11-30 16:11:25 --> Router Class Initialized
INFO - 2023-11-30 16:11:25 --> Output Class Initialized
INFO - 2023-11-30 16:11:25 --> Security Class Initialized
DEBUG - 2023-11-30 16:11:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-30 16:11:25 --> Input Class Initialized
INFO - 2023-11-30 16:11:25 --> Language Class Initialized
INFO - 2023-11-30 16:11:25 --> Language Class Initialized
INFO - 2023-11-30 16:11:25 --> Config Class Initialized
INFO - 2023-11-30 16:11:25 --> Loader Class Initialized
INFO - 2023-11-30 16:11:25 --> Helper loaded: url_helper
INFO - 2023-11-30 16:11:25 --> Helper loaded: file_helper
INFO - 2023-11-30 16:11:25 --> Helper loaded: form_helper
INFO - 2023-11-30 16:11:25 --> Helper loaded: my_helper
INFO - 2023-11-30 16:11:25 --> Database Driver Class Initialized
INFO - 2023-11-30 16:11:25 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-30 16:11:25 --> Controller Class Initialized
DEBUG - 2023-11-30 16:11:25 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/login/views/login.php
DEBUG - 2023-11-30 16:11:25 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-11-30 16:11:25 --> Final output sent to browser
DEBUG - 2023-11-30 16:11:25 --> Total execution time: 0.0455
