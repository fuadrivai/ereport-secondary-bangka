<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2023-12-19 09:55:13 --> Config Class Initialized
INFO - 2023-12-19 09:55:13 --> Hooks Class Initialized
DEBUG - 2023-12-19 09:55:13 --> UTF-8 Support Enabled
INFO - 2023-12-19 09:55:13 --> Utf8 Class Initialized
INFO - 2023-12-19 09:55:13 --> URI Class Initialized
INFO - 2023-12-19 09:55:13 --> Router Class Initialized
INFO - 2023-12-19 09:55:13 --> Output Class Initialized
INFO - 2023-12-19 09:55:13 --> Security Class Initialized
DEBUG - 2023-12-19 09:55:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-19 09:55:13 --> Input Class Initialized
INFO - 2023-12-19 09:55:13 --> Language Class Initialized
INFO - 2023-12-19 09:55:13 --> Language Class Initialized
INFO - 2023-12-19 09:55:13 --> Config Class Initialized
INFO - 2023-12-19 09:55:13 --> Loader Class Initialized
INFO - 2023-12-19 09:55:13 --> Helper loaded: url_helper
INFO - 2023-12-19 09:55:13 --> Helper loaded: file_helper
INFO - 2023-12-19 09:55:13 --> Helper loaded: form_helper
INFO - 2023-12-19 09:55:13 --> Helper loaded: my_helper
INFO - 2023-12-19 09:55:13 --> Database Driver Class Initialized
INFO - 2023-12-19 09:55:13 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-19 09:55:13 --> Controller Class Initialized
ERROR - 2023-12-19 09:55:13 --> Severity: Notice --> Undefined index: projek /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1837
ERROR - 2023-12-19 09:55:13 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2023-12-19 09:55:13 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2023-12-19 09:55:13 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2023-12-19 09:55:13 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2023-12-19 09:55:13 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2023-12-19 09:55:13 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2023-12-19 09:55:13 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2023-12-19 09:55:13 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2023-12-19 09:55:13 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2023-12-19 09:55:13 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2023-12-19 09:55:13 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2023-12-19 09:55:13 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2023-12-19 09:55:13 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2023-12-19 09:55:13 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2023-12-19 09:55:13 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2023-12-19 09:55:13 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2023-12-19 09:55:13 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2023-12-19 09:55:13 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2023-12-19 09:55:13 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2023-12-19 09:55:13 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2023-12-19 09:55:13 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2023-12-19 09:55:13 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2023-12-19 09:55:13 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
DEBUG - 2023-12-19 09:55:13 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/views/cetak_projek.php
INFO - 2023-12-19 09:55:21 --> Final output sent to browser
DEBUG - 2023-12-19 09:55:21 --> Total execution time: 7.6462
INFO - 2023-12-19 09:55:21 --> Config Class Initialized
INFO - 2023-12-19 09:55:21 --> Hooks Class Initialized
DEBUG - 2023-12-19 09:55:21 --> UTF-8 Support Enabled
INFO - 2023-12-19 09:55:21 --> Utf8 Class Initialized
INFO - 2023-12-19 09:55:21 --> URI Class Initialized
INFO - 2023-12-19 09:55:21 --> Router Class Initialized
INFO - 2023-12-19 09:55:21 --> Output Class Initialized
INFO - 2023-12-19 09:55:21 --> Security Class Initialized
DEBUG - 2023-12-19 09:55:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-19 09:55:21 --> Input Class Initialized
INFO - 2023-12-19 09:55:21 --> Language Class Initialized
INFO - 2023-12-19 09:55:22 --> Language Class Initialized
INFO - 2023-12-19 09:55:22 --> Config Class Initialized
INFO - 2023-12-19 09:55:22 --> Loader Class Initialized
INFO - 2023-12-19 09:55:22 --> Helper loaded: url_helper
INFO - 2023-12-19 09:55:22 --> Helper loaded: file_helper
INFO - 2023-12-19 09:55:22 --> Helper loaded: form_helper
INFO - 2023-12-19 09:55:22 --> Helper loaded: my_helper
INFO - 2023-12-19 09:55:22 --> Database Driver Class Initialized
INFO - 2023-12-19 09:55:22 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-19 09:55:22 --> Controller Class Initialized
ERROR - 2023-12-19 09:55:22 --> Severity: Notice --> Undefined index: projek /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1837
ERROR - 2023-12-19 09:55:22 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2023-12-19 09:55:22 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2023-12-19 09:55:22 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2023-12-19 09:55:22 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2023-12-19 09:55:22 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2023-12-19 09:55:22 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2023-12-19 09:55:22 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2023-12-19 09:55:22 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2023-12-19 09:55:22 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2023-12-19 09:55:22 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2023-12-19 09:55:22 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2023-12-19 09:55:22 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2023-12-19 09:55:22 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2023-12-19 09:55:22 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2023-12-19 09:55:22 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2023-12-19 09:55:22 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2023-12-19 09:55:22 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2023-12-19 09:55:22 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2023-12-19 09:55:22 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2023-12-19 09:55:22 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2023-12-19 09:55:22 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2023-12-19 09:55:22 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2023-12-19 09:55:22 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
DEBUG - 2023-12-19 09:55:22 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/views/cetak_projek.php
INFO - 2023-12-19 09:55:30 --> Final output sent to browser
DEBUG - 2023-12-19 09:55:30 --> Total execution time: 8.1604
