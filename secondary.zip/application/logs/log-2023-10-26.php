<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2023-10-26 09:44:36 --> Config Class Initialized
INFO - 2023-10-26 09:44:36 --> Hooks Class Initialized
DEBUG - 2023-10-26 09:44:36 --> UTF-8 Support Enabled
INFO - 2023-10-26 09:44:36 --> Utf8 Class Initialized
INFO - 2023-10-26 09:44:36 --> URI Class Initialized
INFO - 2023-10-26 09:44:36 --> Router Class Initialized
INFO - 2023-10-26 09:44:36 --> Output Class Initialized
INFO - 2023-10-26 09:44:36 --> Security Class Initialized
DEBUG - 2023-10-26 09:44:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-26 09:44:36 --> Input Class Initialized
INFO - 2023-10-26 09:44:36 --> Language Class Initialized
INFO - 2023-10-26 09:44:36 --> Language Class Initialized
INFO - 2023-10-26 09:44:36 --> Config Class Initialized
INFO - 2023-10-26 09:44:36 --> Loader Class Initialized
INFO - 2023-10-26 09:44:36 --> Helper loaded: url_helper
INFO - 2023-10-26 09:44:36 --> Helper loaded: file_helper
INFO - 2023-10-26 09:44:36 --> Helper loaded: form_helper
INFO - 2023-10-26 09:44:36 --> Helper loaded: my_helper
INFO - 2023-10-26 09:44:36 --> Database Driver Class Initialized
INFO - 2023-10-26 09:44:36 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-26 09:44:36 --> Controller Class Initialized
DEBUG - 2023-10-26 09:44:36 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/login/views/login.php
DEBUG - 2023-10-26 09:44:36 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-10-26 09:44:36 --> Final output sent to browser
DEBUG - 2023-10-26 09:44:36 --> Total execution time: 0.0954
