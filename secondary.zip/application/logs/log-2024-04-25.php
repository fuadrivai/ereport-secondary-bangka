<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2024-04-25 10:16:51 --> Config Class Initialized
INFO - 2024-04-25 10:16:51 --> Hooks Class Initialized
DEBUG - 2024-04-25 10:16:51 --> UTF-8 Support Enabled
INFO - 2024-04-25 10:16:51 --> Utf8 Class Initialized
INFO - 2024-04-25 10:16:51 --> URI Class Initialized
INFO - 2024-04-25 10:16:51 --> Router Class Initialized
INFO - 2024-04-25 10:16:51 --> Output Class Initialized
INFO - 2024-04-25 10:16:51 --> Security Class Initialized
DEBUG - 2024-04-25 10:16:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-04-25 10:16:51 --> Input Class Initialized
INFO - 2024-04-25 10:16:51 --> Language Class Initialized
INFO - 2024-04-25 10:16:51 --> Language Class Initialized
INFO - 2024-04-25 10:16:51 --> Config Class Initialized
INFO - 2024-04-25 10:16:51 --> Loader Class Initialized
INFO - 2024-04-25 10:16:51 --> Helper loaded: url_helper
INFO - 2024-04-25 10:16:51 --> Helper loaded: file_helper
INFO - 2024-04-25 10:16:51 --> Helper loaded: form_helper
INFO - 2024-04-25 10:16:51 --> Helper loaded: my_helper
INFO - 2024-04-25 10:16:51 --> Database Driver Class Initialized
INFO - 2024-04-25 10:16:51 --> Session: Class initialized using 'files' driver.
INFO - 2024-04-25 10:16:51 --> Controller Class Initialized
DEBUG - 2024-04-25 10:16:51 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/login/views/login.php
DEBUG - 2024-04-25 10:16:51 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-04-25 10:16:51 --> Final output sent to browser
DEBUG - 2024-04-25 10:16:51 --> Total execution time: 0.0422
