<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2023-01-14 03:42:23 --> Config Class Initialized
INFO - 2023-01-14 03:42:23 --> Hooks Class Initialized
DEBUG - 2023-01-14 03:42:23 --> UTF-8 Support Enabled
INFO - 2023-01-14 03:42:23 --> Utf8 Class Initialized
INFO - 2023-01-14 03:42:23 --> URI Class Initialized
DEBUG - 2023-01-14 03:42:23 --> No URI present. Default controller set.
INFO - 2023-01-14 03:42:23 --> Router Class Initialized
INFO - 2023-01-14 03:42:23 --> Output Class Initialized
INFO - 2023-01-14 03:42:23 --> Security Class Initialized
DEBUG - 2023-01-14 03:42:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-14 03:42:23 --> Input Class Initialized
INFO - 2023-01-14 03:42:23 --> Language Class Initialized
INFO - 2023-01-14 03:42:23 --> Language Class Initialized
INFO - 2023-01-14 03:42:23 --> Config Class Initialized
INFO - 2023-01-14 03:42:23 --> Loader Class Initialized
INFO - 2023-01-14 03:42:23 --> Helper loaded: url_helper
INFO - 2023-01-14 03:42:23 --> Helper loaded: file_helper
INFO - 2023-01-14 03:42:23 --> Helper loaded: form_helper
INFO - 2023-01-14 03:42:23 --> Helper loaded: my_helper
INFO - 2023-01-14 03:42:23 --> Database Driver Class Initialized
DEBUG - 2023-01-14 03:42:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-01-14 03:42:23 --> Session: Class initialized using 'files' driver.
INFO - 2023-01-14 03:42:23 --> Controller Class Initialized
INFO - 2023-01-14 03:42:23 --> Config Class Initialized
INFO - 2023-01-14 03:42:23 --> Hooks Class Initialized
DEBUG - 2023-01-14 03:42:23 --> UTF-8 Support Enabled
INFO - 2023-01-14 03:42:23 --> Utf8 Class Initialized
INFO - 2023-01-14 03:42:23 --> URI Class Initialized
INFO - 2023-01-14 03:42:23 --> Router Class Initialized
INFO - 2023-01-14 03:42:23 --> Output Class Initialized
INFO - 2023-01-14 03:42:23 --> Security Class Initialized
DEBUG - 2023-01-14 03:42:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-14 03:42:23 --> Input Class Initialized
INFO - 2023-01-14 03:42:23 --> Language Class Initialized
INFO - 2023-01-14 03:42:24 --> Language Class Initialized
INFO - 2023-01-14 03:42:24 --> Config Class Initialized
INFO - 2023-01-14 03:42:24 --> Loader Class Initialized
INFO - 2023-01-14 03:42:24 --> Helper loaded: url_helper
INFO - 2023-01-14 03:42:24 --> Helper loaded: file_helper
INFO - 2023-01-14 03:42:24 --> Helper loaded: form_helper
INFO - 2023-01-14 03:42:24 --> Helper loaded: my_helper
INFO - 2023-01-14 03:42:24 --> Database Driver Class Initialized
DEBUG - 2023-01-14 03:42:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-01-14 03:42:24 --> Session: Class initialized using 'files' driver.
INFO - 2023-01-14 03:42:24 --> Controller Class Initialized
DEBUG - 2023-01-14 03:42:24 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/login/views/login.php
DEBUG - 2023-01-14 03:42:24 --> File loaded: C:\xampp\htdocs\myraportk13\application\views\template_utama.php
INFO - 2023-01-14 03:42:24 --> Final output sent to browser
DEBUG - 2023-01-14 03:42:24 --> Total execution time: 0.0931
INFO - 2023-01-14 03:42:30 --> Config Class Initialized
INFO - 2023-01-14 03:42:30 --> Hooks Class Initialized
DEBUG - 2023-01-14 03:42:30 --> UTF-8 Support Enabled
INFO - 2023-01-14 03:42:30 --> Utf8 Class Initialized
INFO - 2023-01-14 03:42:30 --> URI Class Initialized
INFO - 2023-01-14 03:42:30 --> Router Class Initialized
INFO - 2023-01-14 03:42:30 --> Output Class Initialized
INFO - 2023-01-14 03:42:30 --> Security Class Initialized
DEBUG - 2023-01-14 03:42:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-14 03:42:30 --> Input Class Initialized
INFO - 2023-01-14 03:42:30 --> Language Class Initialized
INFO - 2023-01-14 03:42:31 --> Language Class Initialized
INFO - 2023-01-14 03:42:31 --> Config Class Initialized
INFO - 2023-01-14 03:42:31 --> Loader Class Initialized
INFO - 2023-01-14 03:42:31 --> Helper loaded: url_helper
INFO - 2023-01-14 03:42:31 --> Helper loaded: file_helper
INFO - 2023-01-14 03:42:31 --> Helper loaded: form_helper
INFO - 2023-01-14 03:42:31 --> Helper loaded: my_helper
INFO - 2023-01-14 03:42:31 --> Database Driver Class Initialized
DEBUG - 2023-01-14 03:42:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-01-14 03:42:31 --> Session: Class initialized using 'files' driver.
INFO - 2023-01-14 03:42:31 --> Controller Class Initialized
INFO - 2023-01-14 03:42:31 --> Helper loaded: cookie_helper
INFO - 2023-01-14 03:42:31 --> Final output sent to browser
DEBUG - 2023-01-14 03:42:31 --> Total execution time: 0.0646
INFO - 2023-01-14 03:42:31 --> Config Class Initialized
INFO - 2023-01-14 03:42:31 --> Hooks Class Initialized
DEBUG - 2023-01-14 03:42:31 --> UTF-8 Support Enabled
INFO - 2023-01-14 03:42:31 --> Utf8 Class Initialized
INFO - 2023-01-14 03:42:31 --> URI Class Initialized
INFO - 2023-01-14 03:42:31 --> Router Class Initialized
INFO - 2023-01-14 03:42:31 --> Output Class Initialized
INFO - 2023-01-14 03:42:31 --> Security Class Initialized
DEBUG - 2023-01-14 03:42:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-14 03:42:31 --> Input Class Initialized
INFO - 2023-01-14 03:42:31 --> Language Class Initialized
INFO - 2023-01-14 03:42:31 --> Language Class Initialized
INFO - 2023-01-14 03:42:31 --> Config Class Initialized
INFO - 2023-01-14 03:42:31 --> Loader Class Initialized
INFO - 2023-01-14 03:42:31 --> Helper loaded: url_helper
INFO - 2023-01-14 03:42:31 --> Helper loaded: file_helper
INFO - 2023-01-14 03:42:31 --> Helper loaded: form_helper
INFO - 2023-01-14 03:42:31 --> Helper loaded: my_helper
INFO - 2023-01-14 03:42:31 --> Database Driver Class Initialized
DEBUG - 2023-01-14 03:42:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-01-14 03:42:31 --> Session: Class initialized using 'files' driver.
INFO - 2023-01-14 03:42:31 --> Controller Class Initialized
DEBUG - 2023-01-14 03:42:31 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/home/views/v_home.php
DEBUG - 2023-01-14 03:42:31 --> File loaded: C:\xampp\htdocs\myraportk13\application\views\template_utama.php
INFO - 2023-01-14 03:42:31 --> Final output sent to browser
DEBUG - 2023-01-14 03:42:31 --> Total execution time: 0.1168
INFO - 2023-01-14 03:42:41 --> Config Class Initialized
INFO - 2023-01-14 03:42:41 --> Hooks Class Initialized
DEBUG - 2023-01-14 03:42:41 --> UTF-8 Support Enabled
INFO - 2023-01-14 03:42:41 --> Utf8 Class Initialized
INFO - 2023-01-14 03:42:41 --> URI Class Initialized
INFO - 2023-01-14 03:42:41 --> Router Class Initialized
INFO - 2023-01-14 03:42:41 --> Output Class Initialized
INFO - 2023-01-14 03:42:41 --> Security Class Initialized
DEBUG - 2023-01-14 03:42:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-14 03:42:41 --> Input Class Initialized
INFO - 2023-01-14 03:42:41 --> Language Class Initialized
INFO - 2023-01-14 03:42:41 --> Language Class Initialized
INFO - 2023-01-14 03:42:41 --> Config Class Initialized
INFO - 2023-01-14 03:42:41 --> Loader Class Initialized
INFO - 2023-01-14 03:42:41 --> Helper loaded: url_helper
INFO - 2023-01-14 03:42:41 --> Helper loaded: file_helper
INFO - 2023-01-14 03:42:41 --> Helper loaded: form_helper
INFO - 2023-01-14 03:42:41 --> Helper loaded: my_helper
INFO - 2023-01-14 03:42:41 --> Database Driver Class Initialized
DEBUG - 2023-01-14 03:42:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-01-14 03:42:41 --> Session: Class initialized using 'files' driver.
INFO - 2023-01-14 03:42:41 --> Controller Class Initialized
INFO - 2023-01-14 03:42:41 --> Helper loaded: cookie_helper
INFO - 2023-01-14 03:42:41 --> Config Class Initialized
INFO - 2023-01-14 03:42:41 --> Hooks Class Initialized
DEBUG - 2023-01-14 03:42:41 --> UTF-8 Support Enabled
INFO - 2023-01-14 03:42:41 --> Utf8 Class Initialized
INFO - 2023-01-14 03:42:41 --> URI Class Initialized
INFO - 2023-01-14 03:42:41 --> Router Class Initialized
INFO - 2023-01-14 03:42:41 --> Output Class Initialized
INFO - 2023-01-14 03:42:41 --> Security Class Initialized
DEBUG - 2023-01-14 03:42:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-14 03:42:41 --> Input Class Initialized
INFO - 2023-01-14 03:42:41 --> Language Class Initialized
INFO - 2023-01-14 03:42:41 --> Language Class Initialized
INFO - 2023-01-14 03:42:41 --> Config Class Initialized
INFO - 2023-01-14 03:42:41 --> Loader Class Initialized
INFO - 2023-01-14 03:42:41 --> Helper loaded: url_helper
INFO - 2023-01-14 03:42:41 --> Helper loaded: file_helper
INFO - 2023-01-14 03:42:41 --> Helper loaded: form_helper
INFO - 2023-01-14 03:42:41 --> Helper loaded: my_helper
INFO - 2023-01-14 03:42:41 --> Database Driver Class Initialized
DEBUG - 2023-01-14 03:42:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-01-14 03:42:41 --> Session: Class initialized using 'files' driver.
INFO - 2023-01-14 03:42:41 --> Controller Class Initialized
INFO - 2023-01-14 03:42:41 --> Config Class Initialized
INFO - 2023-01-14 03:42:41 --> Hooks Class Initialized
DEBUG - 2023-01-14 03:42:41 --> UTF-8 Support Enabled
INFO - 2023-01-14 03:42:41 --> Utf8 Class Initialized
INFO - 2023-01-14 03:42:41 --> URI Class Initialized
INFO - 2023-01-14 03:42:41 --> Router Class Initialized
INFO - 2023-01-14 03:42:41 --> Output Class Initialized
INFO - 2023-01-14 03:42:41 --> Security Class Initialized
DEBUG - 2023-01-14 03:42:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-14 03:42:41 --> Input Class Initialized
INFO - 2023-01-14 03:42:41 --> Language Class Initialized
INFO - 2023-01-14 03:42:41 --> Language Class Initialized
INFO - 2023-01-14 03:42:41 --> Config Class Initialized
INFO - 2023-01-14 03:42:41 --> Loader Class Initialized
INFO - 2023-01-14 03:42:41 --> Helper loaded: url_helper
INFO - 2023-01-14 03:42:41 --> Helper loaded: file_helper
INFO - 2023-01-14 03:42:41 --> Helper loaded: form_helper
INFO - 2023-01-14 03:42:41 --> Helper loaded: my_helper
INFO - 2023-01-14 03:42:41 --> Database Driver Class Initialized
DEBUG - 2023-01-14 03:42:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-01-14 03:42:41 --> Session: Class initialized using 'files' driver.
INFO - 2023-01-14 03:42:41 --> Controller Class Initialized
DEBUG - 2023-01-14 03:42:41 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/login/views/login.php
DEBUG - 2023-01-14 03:42:41 --> File loaded: C:\xampp\htdocs\myraportk13\application\views\template_utama.php
INFO - 2023-01-14 03:42:41 --> Final output sent to browser
DEBUG - 2023-01-14 03:42:41 --> Total execution time: 0.0436
INFO - 2023-01-14 03:44:15 --> Config Class Initialized
INFO - 2023-01-14 03:44:15 --> Hooks Class Initialized
DEBUG - 2023-01-14 03:44:15 --> UTF-8 Support Enabled
INFO - 2023-01-14 03:44:15 --> Utf8 Class Initialized
INFO - 2023-01-14 03:44:15 --> URI Class Initialized
INFO - 2023-01-14 03:44:15 --> Router Class Initialized
INFO - 2023-01-14 03:44:15 --> Output Class Initialized
INFO - 2023-01-14 03:44:15 --> Security Class Initialized
DEBUG - 2023-01-14 03:44:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-14 03:44:15 --> Input Class Initialized
INFO - 2023-01-14 03:44:15 --> Language Class Initialized
INFO - 2023-01-14 03:44:15 --> Language Class Initialized
INFO - 2023-01-14 03:44:15 --> Config Class Initialized
INFO - 2023-01-14 03:44:15 --> Loader Class Initialized
INFO - 2023-01-14 03:44:15 --> Helper loaded: url_helper
INFO - 2023-01-14 03:44:15 --> Helper loaded: file_helper
INFO - 2023-01-14 03:44:15 --> Helper loaded: form_helper
INFO - 2023-01-14 03:44:15 --> Helper loaded: my_helper
INFO - 2023-01-14 03:44:15 --> Database Driver Class Initialized
DEBUG - 2023-01-14 03:44:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-01-14 03:44:15 --> Session: Class initialized using 'files' driver.
INFO - 2023-01-14 03:44:15 --> Controller Class Initialized
INFO - 2023-01-14 03:44:15 --> Helper loaded: cookie_helper
INFO - 2023-01-14 03:44:15 --> Final output sent to browser
DEBUG - 2023-01-14 03:44:15 --> Total execution time: 0.0756
INFO - 2023-01-14 03:44:15 --> Config Class Initialized
INFO - 2023-01-14 03:44:15 --> Hooks Class Initialized
DEBUG - 2023-01-14 03:44:15 --> UTF-8 Support Enabled
INFO - 2023-01-14 03:44:15 --> Utf8 Class Initialized
INFO - 2023-01-14 03:44:15 --> URI Class Initialized
INFO - 2023-01-14 03:44:15 --> Router Class Initialized
INFO - 2023-01-14 03:44:15 --> Output Class Initialized
INFO - 2023-01-14 03:44:15 --> Security Class Initialized
DEBUG - 2023-01-14 03:44:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-14 03:44:15 --> Input Class Initialized
INFO - 2023-01-14 03:44:15 --> Language Class Initialized
INFO - 2023-01-14 03:44:15 --> Language Class Initialized
INFO - 2023-01-14 03:44:15 --> Config Class Initialized
INFO - 2023-01-14 03:44:15 --> Loader Class Initialized
INFO - 2023-01-14 03:44:15 --> Helper loaded: url_helper
INFO - 2023-01-14 03:44:15 --> Helper loaded: file_helper
INFO - 2023-01-14 03:44:15 --> Helper loaded: form_helper
INFO - 2023-01-14 03:44:15 --> Helper loaded: my_helper
INFO - 2023-01-14 03:44:15 --> Database Driver Class Initialized
DEBUG - 2023-01-14 03:44:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-01-14 03:44:15 --> Session: Class initialized using 'files' driver.
INFO - 2023-01-14 03:44:15 --> Controller Class Initialized
DEBUG - 2023-01-14 03:44:15 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/home/views/v_home_guru.php
DEBUG - 2023-01-14 03:44:15 --> File loaded: C:\xampp\htdocs\myraportk13\application\views\template_utama.php
INFO - 2023-01-14 03:44:15 --> Final output sent to browser
DEBUG - 2023-01-14 03:44:15 --> Total execution time: 0.0986
INFO - 2023-01-14 03:44:19 --> Config Class Initialized
INFO - 2023-01-14 03:44:19 --> Hooks Class Initialized
DEBUG - 2023-01-14 03:44:19 --> UTF-8 Support Enabled
INFO - 2023-01-14 03:44:19 --> Utf8 Class Initialized
INFO - 2023-01-14 03:44:19 --> URI Class Initialized
INFO - 2023-01-14 03:44:19 --> Router Class Initialized
INFO - 2023-01-14 03:44:19 --> Output Class Initialized
INFO - 2023-01-14 03:44:19 --> Security Class Initialized
DEBUG - 2023-01-14 03:44:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-14 03:44:19 --> Input Class Initialized
INFO - 2023-01-14 03:44:19 --> Language Class Initialized
INFO - 2023-01-14 03:44:19 --> Language Class Initialized
INFO - 2023-01-14 03:44:19 --> Config Class Initialized
INFO - 2023-01-14 03:44:19 --> Loader Class Initialized
INFO - 2023-01-14 03:44:19 --> Helper loaded: url_helper
INFO - 2023-01-14 03:44:19 --> Helper loaded: file_helper
INFO - 2023-01-14 03:44:19 --> Helper loaded: form_helper
INFO - 2023-01-14 03:44:19 --> Helper loaded: my_helper
INFO - 2023-01-14 03:44:19 --> Database Driver Class Initialized
DEBUG - 2023-01-14 03:44:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-01-14 03:44:19 --> Session: Class initialized using 'files' driver.
INFO - 2023-01-14 03:44:19 --> Controller Class Initialized
DEBUG - 2023-01-14 03:44:19 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/n_sikap_sp/views/list.php
DEBUG - 2023-01-14 03:44:19 --> File loaded: C:\xampp\htdocs\myraportk13\application\views\template_utama.php
INFO - 2023-01-14 03:44:19 --> Final output sent to browser
DEBUG - 2023-01-14 03:44:19 --> Total execution time: 0.0926
INFO - 2023-01-14 03:44:22 --> Config Class Initialized
INFO - 2023-01-14 03:44:22 --> Hooks Class Initialized
DEBUG - 2023-01-14 03:44:22 --> UTF-8 Support Enabled
INFO - 2023-01-14 03:44:22 --> Utf8 Class Initialized
INFO - 2023-01-14 03:44:22 --> URI Class Initialized
INFO - 2023-01-14 03:44:22 --> Router Class Initialized
INFO - 2023-01-14 03:44:22 --> Output Class Initialized
INFO - 2023-01-14 03:44:22 --> Security Class Initialized
DEBUG - 2023-01-14 03:44:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-14 03:44:22 --> Input Class Initialized
INFO - 2023-01-14 03:44:22 --> Language Class Initialized
INFO - 2023-01-14 03:44:22 --> Language Class Initialized
INFO - 2023-01-14 03:44:22 --> Config Class Initialized
INFO - 2023-01-14 03:44:22 --> Loader Class Initialized
INFO - 2023-01-14 03:44:22 --> Helper loaded: url_helper
INFO - 2023-01-14 03:44:22 --> Helper loaded: file_helper
INFO - 2023-01-14 03:44:22 --> Helper loaded: form_helper
INFO - 2023-01-14 03:44:22 --> Helper loaded: my_helper
INFO - 2023-01-14 03:44:22 --> Database Driver Class Initialized
DEBUG - 2023-01-14 03:44:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-01-14 03:44:22 --> Session: Class initialized using 'files' driver.
INFO - 2023-01-14 03:44:22 --> Controller Class Initialized
DEBUG - 2023-01-14 03:44:22 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/n_sikap_so/views/list.php
DEBUG - 2023-01-14 03:44:22 --> File loaded: C:\xampp\htdocs\myraportk13\application\views\template_utama.php
INFO - 2023-01-14 03:44:22 --> Final output sent to browser
DEBUG - 2023-01-14 03:44:22 --> Total execution time: 0.0807
INFO - 2023-01-14 03:44:23 --> Config Class Initialized
INFO - 2023-01-14 03:44:23 --> Hooks Class Initialized
DEBUG - 2023-01-14 03:44:23 --> UTF-8 Support Enabled
INFO - 2023-01-14 03:44:23 --> Utf8 Class Initialized
INFO - 2023-01-14 03:44:23 --> URI Class Initialized
INFO - 2023-01-14 03:44:23 --> Router Class Initialized
INFO - 2023-01-14 03:44:23 --> Output Class Initialized
INFO - 2023-01-14 03:44:23 --> Security Class Initialized
DEBUG - 2023-01-14 03:44:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-14 03:44:23 --> Input Class Initialized
INFO - 2023-01-14 03:44:23 --> Language Class Initialized
INFO - 2023-01-14 03:44:23 --> Language Class Initialized
INFO - 2023-01-14 03:44:23 --> Config Class Initialized
INFO - 2023-01-14 03:44:23 --> Loader Class Initialized
INFO - 2023-01-14 03:44:23 --> Helper loaded: url_helper
INFO - 2023-01-14 03:44:23 --> Helper loaded: file_helper
INFO - 2023-01-14 03:44:23 --> Helper loaded: form_helper
INFO - 2023-01-14 03:44:23 --> Helper loaded: my_helper
INFO - 2023-01-14 03:44:23 --> Database Driver Class Initialized
DEBUG - 2023-01-14 03:44:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-01-14 03:44:23 --> Session: Class initialized using 'files' driver.
INFO - 2023-01-14 03:44:23 --> Controller Class Initialized
DEBUG - 2023-01-14 03:44:23 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/n_ekstra/views/list.php
DEBUG - 2023-01-14 03:44:23 --> File loaded: C:\xampp\htdocs\myraportk13\application\views\template_utama.php
INFO - 2023-01-14 03:44:23 --> Final output sent to browser
DEBUG - 2023-01-14 03:44:23 --> Total execution time: 0.0820
INFO - 2023-01-14 03:44:27 --> Config Class Initialized
INFO - 2023-01-14 03:44:27 --> Hooks Class Initialized
DEBUG - 2023-01-14 03:44:27 --> UTF-8 Support Enabled
INFO - 2023-01-14 03:44:27 --> Utf8 Class Initialized
INFO - 2023-01-14 03:44:27 --> URI Class Initialized
INFO - 2023-01-14 03:44:27 --> Router Class Initialized
INFO - 2023-01-14 03:44:27 --> Output Class Initialized
INFO - 2023-01-14 03:44:27 --> Security Class Initialized
DEBUG - 2023-01-14 03:44:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-14 03:44:27 --> Input Class Initialized
INFO - 2023-01-14 03:44:27 --> Language Class Initialized
INFO - 2023-01-14 03:44:27 --> Language Class Initialized
INFO - 2023-01-14 03:44:27 --> Config Class Initialized
INFO - 2023-01-14 03:44:27 --> Loader Class Initialized
INFO - 2023-01-14 03:44:27 --> Helper loaded: url_helper
INFO - 2023-01-14 03:44:27 --> Helper loaded: file_helper
INFO - 2023-01-14 03:44:27 --> Helper loaded: form_helper
INFO - 2023-01-14 03:44:27 --> Helper loaded: my_helper
INFO - 2023-01-14 03:44:27 --> Database Driver Class Initialized
DEBUG - 2023-01-14 03:44:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-01-14 03:44:27 --> Session: Class initialized using 'files' driver.
INFO - 2023-01-14 03:44:27 --> Controller Class Initialized
INFO - 2023-01-14 03:44:27 --> Final output sent to browser
DEBUG - 2023-01-14 03:44:27 --> Total execution time: 0.0471
INFO - 2023-01-14 03:44:30 --> Config Class Initialized
INFO - 2023-01-14 03:44:30 --> Hooks Class Initialized
DEBUG - 2023-01-14 03:44:30 --> UTF-8 Support Enabled
INFO - 2023-01-14 03:44:30 --> Utf8 Class Initialized
INFO - 2023-01-14 03:44:30 --> URI Class Initialized
INFO - 2023-01-14 03:44:30 --> Router Class Initialized
INFO - 2023-01-14 03:44:30 --> Output Class Initialized
INFO - 2023-01-14 03:44:30 --> Security Class Initialized
DEBUG - 2023-01-14 03:44:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-14 03:44:30 --> Input Class Initialized
INFO - 2023-01-14 03:44:30 --> Language Class Initialized
INFO - 2023-01-14 03:44:30 --> Language Class Initialized
INFO - 2023-01-14 03:44:30 --> Config Class Initialized
INFO - 2023-01-14 03:44:30 --> Loader Class Initialized
INFO - 2023-01-14 03:44:30 --> Helper loaded: url_helper
INFO - 2023-01-14 03:44:30 --> Helper loaded: file_helper
INFO - 2023-01-14 03:44:30 --> Helper loaded: form_helper
INFO - 2023-01-14 03:44:30 --> Helper loaded: my_helper
INFO - 2023-01-14 03:44:30 --> Database Driver Class Initialized
DEBUG - 2023-01-14 03:44:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-01-14 03:44:30 --> Session: Class initialized using 'files' driver.
INFO - 2023-01-14 03:44:30 --> Controller Class Initialized
DEBUG - 2023-01-14 03:44:30 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/n_catatan/views/list.php
DEBUG - 2023-01-14 03:44:30 --> File loaded: C:\xampp\htdocs\myraportk13\application\views\template_utama.php
INFO - 2023-01-14 03:44:30 --> Final output sent to browser
DEBUG - 2023-01-14 03:44:30 --> Total execution time: 0.0841
INFO - 2023-01-14 03:44:39 --> Config Class Initialized
INFO - 2023-01-14 03:44:39 --> Hooks Class Initialized
DEBUG - 2023-01-14 03:44:39 --> UTF-8 Support Enabled
INFO - 2023-01-14 03:44:39 --> Utf8 Class Initialized
INFO - 2023-01-14 03:44:39 --> URI Class Initialized
INFO - 2023-01-14 03:44:39 --> Router Class Initialized
INFO - 2023-01-14 03:44:39 --> Output Class Initialized
INFO - 2023-01-14 03:44:39 --> Security Class Initialized
DEBUG - 2023-01-14 03:44:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-14 03:44:39 --> Input Class Initialized
INFO - 2023-01-14 03:44:39 --> Language Class Initialized
INFO - 2023-01-14 03:44:39 --> Language Class Initialized
INFO - 2023-01-14 03:44:39 --> Config Class Initialized
INFO - 2023-01-14 03:44:39 --> Loader Class Initialized
INFO - 2023-01-14 03:44:39 --> Helper loaded: url_helper
INFO - 2023-01-14 03:44:39 --> Helper loaded: file_helper
INFO - 2023-01-14 03:44:39 --> Helper loaded: form_helper
INFO - 2023-01-14 03:44:39 --> Helper loaded: my_helper
INFO - 2023-01-14 03:44:39 --> Database Driver Class Initialized
DEBUG - 2023-01-14 03:44:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-01-14 03:44:39 --> Session: Class initialized using 'files' driver.
INFO - 2023-01-14 03:44:39 --> Controller Class Initialized
DEBUG - 2023-01-14 03:44:39 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/n_absensi/views/list.php
DEBUG - 2023-01-14 03:44:39 --> File loaded: C:\xampp\htdocs\myraportk13\application\views\template_utama.php
INFO - 2023-01-14 03:44:39 --> Final output sent to browser
DEBUG - 2023-01-14 03:44:39 --> Total execution time: 0.0952
INFO - 2023-01-14 03:44:40 --> Config Class Initialized
INFO - 2023-01-14 03:44:40 --> Hooks Class Initialized
DEBUG - 2023-01-14 03:44:40 --> UTF-8 Support Enabled
INFO - 2023-01-14 03:44:40 --> Utf8 Class Initialized
INFO - 2023-01-14 03:44:40 --> URI Class Initialized
INFO - 2023-01-14 03:44:40 --> Router Class Initialized
INFO - 2023-01-14 03:44:40 --> Output Class Initialized
INFO - 2023-01-14 03:44:40 --> Security Class Initialized
DEBUG - 2023-01-14 03:44:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-14 03:44:40 --> Input Class Initialized
INFO - 2023-01-14 03:44:40 --> Language Class Initialized
INFO - 2023-01-14 03:44:40 --> Language Class Initialized
INFO - 2023-01-14 03:44:40 --> Config Class Initialized
INFO - 2023-01-14 03:44:40 --> Loader Class Initialized
INFO - 2023-01-14 03:44:40 --> Helper loaded: url_helper
INFO - 2023-01-14 03:44:40 --> Helper loaded: file_helper
INFO - 2023-01-14 03:44:40 --> Helper loaded: form_helper
INFO - 2023-01-14 03:44:40 --> Helper loaded: my_helper
INFO - 2023-01-14 03:44:40 --> Database Driver Class Initialized
DEBUG - 2023-01-14 03:44:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-01-14 03:44:40 --> Session: Class initialized using 'files' driver.
INFO - 2023-01-14 03:44:40 --> Controller Class Initialized
DEBUG - 2023-01-14 03:44:40 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/n_sikap_so/views/list.php
DEBUG - 2023-01-14 03:44:40 --> File loaded: C:\xampp\htdocs\myraportk13\application\views\template_utama.php
INFO - 2023-01-14 03:44:40 --> Final output sent to browser
DEBUG - 2023-01-14 03:44:40 --> Total execution time: 0.0551
INFO - 2023-01-14 03:44:42 --> Config Class Initialized
INFO - 2023-01-14 03:44:42 --> Hooks Class Initialized
DEBUG - 2023-01-14 03:44:42 --> UTF-8 Support Enabled
INFO - 2023-01-14 03:44:42 --> Utf8 Class Initialized
INFO - 2023-01-14 03:44:42 --> URI Class Initialized
INFO - 2023-01-14 03:44:42 --> Router Class Initialized
INFO - 2023-01-14 03:44:42 --> Output Class Initialized
INFO - 2023-01-14 03:44:42 --> Security Class Initialized
DEBUG - 2023-01-14 03:44:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-14 03:44:42 --> Input Class Initialized
INFO - 2023-01-14 03:44:42 --> Language Class Initialized
INFO - 2023-01-14 03:44:42 --> Language Class Initialized
INFO - 2023-01-14 03:44:42 --> Config Class Initialized
INFO - 2023-01-14 03:44:42 --> Loader Class Initialized
INFO - 2023-01-14 03:44:42 --> Helper loaded: url_helper
INFO - 2023-01-14 03:44:42 --> Helper loaded: file_helper
INFO - 2023-01-14 03:44:42 --> Helper loaded: form_helper
INFO - 2023-01-14 03:44:42 --> Helper loaded: my_helper
INFO - 2023-01-14 03:44:42 --> Database Driver Class Initialized
DEBUG - 2023-01-14 03:44:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-01-14 03:44:42 --> Session: Class initialized using 'files' driver.
INFO - 2023-01-14 03:44:42 --> Controller Class Initialized
DEBUG - 2023-01-14 03:44:42 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/n_absensi/views/list.php
DEBUG - 2023-01-14 03:44:42 --> File loaded: C:\xampp\htdocs\myraportk13\application\views\template_utama.php
INFO - 2023-01-14 03:44:42 --> Final output sent to browser
DEBUG - 2023-01-14 03:44:42 --> Total execution time: 0.0571
INFO - 2023-01-14 03:44:44 --> Config Class Initialized
INFO - 2023-01-14 03:44:44 --> Hooks Class Initialized
DEBUG - 2023-01-14 03:44:44 --> UTF-8 Support Enabled
INFO - 2023-01-14 03:44:44 --> Utf8 Class Initialized
INFO - 2023-01-14 03:44:44 --> URI Class Initialized
INFO - 2023-01-14 03:44:44 --> Router Class Initialized
INFO - 2023-01-14 03:44:44 --> Output Class Initialized
INFO - 2023-01-14 03:44:44 --> Security Class Initialized
DEBUG - 2023-01-14 03:44:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-14 03:44:44 --> Input Class Initialized
INFO - 2023-01-14 03:44:44 --> Language Class Initialized
INFO - 2023-01-14 03:44:44 --> Language Class Initialized
INFO - 2023-01-14 03:44:44 --> Config Class Initialized
INFO - 2023-01-14 03:44:44 --> Loader Class Initialized
INFO - 2023-01-14 03:44:44 --> Helper loaded: url_helper
INFO - 2023-01-14 03:44:44 --> Helper loaded: file_helper
INFO - 2023-01-14 03:44:44 --> Helper loaded: form_helper
INFO - 2023-01-14 03:44:44 --> Helper loaded: my_helper
INFO - 2023-01-14 03:44:44 --> Database Driver Class Initialized
DEBUG - 2023-01-14 03:44:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-01-14 03:44:44 --> Session: Class initialized using 'files' driver.
INFO - 2023-01-14 03:44:44 --> Controller Class Initialized
DEBUG - 2023-01-14 03:44:44 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/n_prestasi/views/list.php
DEBUG - 2023-01-14 03:44:44 --> File loaded: C:\xampp\htdocs\myraportk13\application\views\template_utama.php
INFO - 2023-01-14 03:44:44 --> Final output sent to browser
DEBUG - 2023-01-14 03:44:44 --> Total execution time: 0.0761
INFO - 2023-01-14 03:44:44 --> Config Class Initialized
INFO - 2023-01-14 03:44:44 --> Hooks Class Initialized
DEBUG - 2023-01-14 03:44:44 --> UTF-8 Support Enabled
INFO - 2023-01-14 03:44:44 --> Utf8 Class Initialized
INFO - 2023-01-14 03:44:44 --> URI Class Initialized
INFO - 2023-01-14 03:44:44 --> Router Class Initialized
INFO - 2023-01-14 03:44:44 --> Output Class Initialized
INFO - 2023-01-14 03:44:44 --> Security Class Initialized
DEBUG - 2023-01-14 03:44:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-14 03:44:44 --> Input Class Initialized
INFO - 2023-01-14 03:44:44 --> Language Class Initialized
INFO - 2023-01-14 03:44:44 --> Language Class Initialized
INFO - 2023-01-14 03:44:44 --> Config Class Initialized
INFO - 2023-01-14 03:44:44 --> Loader Class Initialized
INFO - 2023-01-14 03:44:44 --> Helper loaded: url_helper
INFO - 2023-01-14 03:44:44 --> Helper loaded: file_helper
INFO - 2023-01-14 03:44:44 --> Helper loaded: form_helper
INFO - 2023-01-14 03:44:44 --> Helper loaded: my_helper
INFO - 2023-01-14 03:44:44 --> Database Driver Class Initialized
DEBUG - 2023-01-14 03:44:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-01-14 03:44:44 --> Session: Class initialized using 'files' driver.
INFO - 2023-01-14 03:44:44 --> Controller Class Initialized
INFO - 2023-01-14 03:44:48 --> Config Class Initialized
INFO - 2023-01-14 03:44:48 --> Hooks Class Initialized
DEBUG - 2023-01-14 03:44:48 --> UTF-8 Support Enabled
INFO - 2023-01-14 03:44:48 --> Utf8 Class Initialized
INFO - 2023-01-14 03:44:48 --> URI Class Initialized
INFO - 2023-01-14 03:44:48 --> Router Class Initialized
INFO - 2023-01-14 03:44:48 --> Output Class Initialized
INFO - 2023-01-14 03:44:48 --> Security Class Initialized
DEBUG - 2023-01-14 03:44:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-14 03:44:48 --> Input Class Initialized
INFO - 2023-01-14 03:44:48 --> Language Class Initialized
INFO - 2023-01-14 03:44:48 --> Language Class Initialized
INFO - 2023-01-14 03:44:48 --> Config Class Initialized
INFO - 2023-01-14 03:44:48 --> Loader Class Initialized
INFO - 2023-01-14 03:44:48 --> Helper loaded: url_helper
INFO - 2023-01-14 03:44:48 --> Helper loaded: file_helper
INFO - 2023-01-14 03:44:48 --> Helper loaded: form_helper
INFO - 2023-01-14 03:44:48 --> Helper loaded: my_helper
INFO - 2023-01-14 03:44:48 --> Database Driver Class Initialized
DEBUG - 2023-01-14 03:44:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-01-14 03:44:48 --> Session: Class initialized using 'files' driver.
INFO - 2023-01-14 03:44:48 --> Controller Class Initialized
DEBUG - 2023-01-14 03:44:48 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/n_catatan/views/list.php
DEBUG - 2023-01-14 03:44:48 --> File loaded: C:\xampp\htdocs\myraportk13\application\views\template_utama.php
INFO - 2023-01-14 03:44:48 --> Final output sent to browser
DEBUG - 2023-01-14 03:44:48 --> Total execution time: 0.0585
INFO - 2023-01-14 03:44:49 --> Config Class Initialized
INFO - 2023-01-14 03:44:49 --> Hooks Class Initialized
DEBUG - 2023-01-14 03:44:49 --> UTF-8 Support Enabled
INFO - 2023-01-14 03:44:49 --> Utf8 Class Initialized
INFO - 2023-01-14 03:44:49 --> URI Class Initialized
INFO - 2023-01-14 03:44:49 --> Router Class Initialized
INFO - 2023-01-14 03:44:49 --> Output Class Initialized
INFO - 2023-01-14 03:44:49 --> Security Class Initialized
DEBUG - 2023-01-14 03:44:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-14 03:44:49 --> Input Class Initialized
INFO - 2023-01-14 03:44:49 --> Language Class Initialized
INFO - 2023-01-14 03:44:49 --> Language Class Initialized
INFO - 2023-01-14 03:44:49 --> Config Class Initialized
INFO - 2023-01-14 03:44:49 --> Loader Class Initialized
INFO - 2023-01-14 03:44:49 --> Helper loaded: url_helper
INFO - 2023-01-14 03:44:49 --> Helper loaded: file_helper
INFO - 2023-01-14 03:44:49 --> Helper loaded: form_helper
INFO - 2023-01-14 03:44:49 --> Helper loaded: my_helper
INFO - 2023-01-14 03:44:49 --> Database Driver Class Initialized
DEBUG - 2023-01-14 03:44:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-01-14 03:44:49 --> Session: Class initialized using 'files' driver.
INFO - 2023-01-14 03:44:49 --> Controller Class Initialized
DEBUG - 2023-01-14 03:44:49 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/cetak_raport_pts/views/list.php
DEBUG - 2023-01-14 03:44:49 --> File loaded: C:\xampp\htdocs\myraportk13\application\views\template_utama.php
INFO - 2023-01-14 03:44:49 --> Final output sent to browser
DEBUG - 2023-01-14 03:44:49 --> Total execution time: 0.0708
INFO - 2023-01-14 03:44:51 --> Config Class Initialized
INFO - 2023-01-14 03:44:51 --> Hooks Class Initialized
DEBUG - 2023-01-14 03:44:52 --> UTF-8 Support Enabled
INFO - 2023-01-14 03:44:52 --> Utf8 Class Initialized
INFO - 2023-01-14 03:44:52 --> URI Class Initialized
INFO - 2023-01-14 03:44:52 --> Router Class Initialized
INFO - 2023-01-14 03:44:52 --> Output Class Initialized
INFO - 2023-01-14 03:44:52 --> Security Class Initialized
DEBUG - 2023-01-14 03:44:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-14 03:44:52 --> Input Class Initialized
INFO - 2023-01-14 03:44:52 --> Language Class Initialized
INFO - 2023-01-14 03:44:52 --> Language Class Initialized
INFO - 2023-01-14 03:44:52 --> Config Class Initialized
INFO - 2023-01-14 03:44:52 --> Loader Class Initialized
INFO - 2023-01-14 03:44:52 --> Helper loaded: url_helper
INFO - 2023-01-14 03:44:52 --> Helper loaded: file_helper
INFO - 2023-01-14 03:44:52 --> Helper loaded: form_helper
INFO - 2023-01-14 03:44:52 --> Helper loaded: my_helper
INFO - 2023-01-14 03:44:52 --> Database Driver Class Initialized
DEBUG - 2023-01-14 03:44:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-01-14 03:44:52 --> Session: Class initialized using 'files' driver.
INFO - 2023-01-14 03:44:52 --> Controller Class Initialized
DEBUG - 2023-01-14 03:44:52 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/cetak_raport_pts/views/cetak_rapot_pts.php
INFO - 2023-01-14 03:44:52 --> Final output sent to browser
DEBUG - 2023-01-14 03:44:52 --> Total execution time: 0.1116
INFO - 2023-01-14 03:45:07 --> Config Class Initialized
INFO - 2023-01-14 03:45:07 --> Hooks Class Initialized
DEBUG - 2023-01-14 03:45:07 --> UTF-8 Support Enabled
INFO - 2023-01-14 03:45:07 --> Utf8 Class Initialized
INFO - 2023-01-14 03:45:07 --> URI Class Initialized
INFO - 2023-01-14 03:45:07 --> Router Class Initialized
INFO - 2023-01-14 03:45:07 --> Output Class Initialized
INFO - 2023-01-14 03:45:07 --> Security Class Initialized
DEBUG - 2023-01-14 03:45:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-14 03:45:07 --> Input Class Initialized
INFO - 2023-01-14 03:45:07 --> Language Class Initialized
INFO - 2023-01-14 03:45:07 --> Language Class Initialized
INFO - 2023-01-14 03:45:07 --> Config Class Initialized
INFO - 2023-01-14 03:45:07 --> Loader Class Initialized
INFO - 2023-01-14 03:45:07 --> Helper loaded: url_helper
INFO - 2023-01-14 03:45:07 --> Helper loaded: file_helper
INFO - 2023-01-14 03:45:07 --> Helper loaded: form_helper
INFO - 2023-01-14 03:45:07 --> Helper loaded: my_helper
INFO - 2023-01-14 03:45:07 --> Database Driver Class Initialized
DEBUG - 2023-01-14 03:45:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-01-14 03:45:07 --> Session: Class initialized using 'files' driver.
INFO - 2023-01-14 03:45:07 --> Controller Class Initialized
DEBUG - 2023-01-14 03:45:07 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/cetak_raport_pts/views/cetak_rapot_pts.php
INFO - 2023-01-14 03:45:07 --> Final output sent to browser
DEBUG - 2023-01-14 03:45:07 --> Total execution time: 0.0431
INFO - 2023-01-14 03:45:19 --> Config Class Initialized
INFO - 2023-01-14 03:45:19 --> Hooks Class Initialized
DEBUG - 2023-01-14 03:45:19 --> UTF-8 Support Enabled
INFO - 2023-01-14 03:45:19 --> Utf8 Class Initialized
INFO - 2023-01-14 03:45:19 --> URI Class Initialized
INFO - 2023-01-14 03:45:19 --> Router Class Initialized
INFO - 2023-01-14 03:45:19 --> Output Class Initialized
INFO - 2023-01-14 03:45:19 --> Security Class Initialized
DEBUG - 2023-01-14 03:45:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-14 03:45:19 --> Input Class Initialized
INFO - 2023-01-14 03:45:19 --> Language Class Initialized
INFO - 2023-01-14 03:45:19 --> Language Class Initialized
INFO - 2023-01-14 03:45:19 --> Config Class Initialized
INFO - 2023-01-14 03:45:19 --> Loader Class Initialized
INFO - 2023-01-14 03:45:19 --> Helper loaded: url_helper
INFO - 2023-01-14 03:45:19 --> Helper loaded: file_helper
INFO - 2023-01-14 03:45:19 --> Helper loaded: form_helper
INFO - 2023-01-14 03:45:19 --> Helper loaded: my_helper
INFO - 2023-01-14 03:45:19 --> Database Driver Class Initialized
DEBUG - 2023-01-14 03:45:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-01-14 03:45:19 --> Session: Class initialized using 'files' driver.
INFO - 2023-01-14 03:45:19 --> Controller Class Initialized
DEBUG - 2023-01-14 03:45:19 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/view_mapel/views/v_view_mapel.php
DEBUG - 2023-01-14 03:45:19 --> File loaded: C:\xampp\htdocs\myraportk13\application\views\template_utama.php
INFO - 2023-01-14 03:45:19 --> Final output sent to browser
DEBUG - 2023-01-14 03:45:19 --> Total execution time: 0.0975
INFO - 2023-01-14 03:45:20 --> Config Class Initialized
INFO - 2023-01-14 03:45:20 --> Hooks Class Initialized
DEBUG - 2023-01-14 03:45:20 --> UTF-8 Support Enabled
INFO - 2023-01-14 03:45:20 --> Utf8 Class Initialized
INFO - 2023-01-14 03:45:20 --> URI Class Initialized
INFO - 2023-01-14 03:45:20 --> Router Class Initialized
INFO - 2023-01-14 03:45:20 --> Output Class Initialized
INFO - 2023-01-14 03:45:20 --> Security Class Initialized
DEBUG - 2023-01-14 03:45:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-14 03:45:20 --> Input Class Initialized
INFO - 2023-01-14 03:45:20 --> Language Class Initialized
INFO - 2023-01-14 03:45:20 --> Language Class Initialized
INFO - 2023-01-14 03:45:20 --> Config Class Initialized
INFO - 2023-01-14 03:45:20 --> Loader Class Initialized
INFO - 2023-01-14 03:45:20 --> Helper loaded: url_helper
INFO - 2023-01-14 03:45:20 --> Helper loaded: file_helper
INFO - 2023-01-14 03:45:20 --> Helper loaded: form_helper
INFO - 2023-01-14 03:45:20 --> Helper loaded: my_helper
INFO - 2023-01-14 03:45:20 --> Database Driver Class Initialized
DEBUG - 2023-01-14 03:45:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-01-14 03:45:20 --> Session: Class initialized using 'files' driver.
INFO - 2023-01-14 03:45:20 --> Controller Class Initialized
DEBUG - 2023-01-14 03:45:20 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/n_icb/views/list.php
DEBUG - 2023-01-14 03:45:20 --> File loaded: C:\xampp\htdocs\myraportk13\application\views\template_utama.php
INFO - 2023-01-14 03:45:20 --> Final output sent to browser
DEBUG - 2023-01-14 03:45:20 --> Total execution time: 0.0962
INFO - 2023-01-14 03:45:20 --> Config Class Initialized
INFO - 2023-01-14 03:45:20 --> Hooks Class Initialized
DEBUG - 2023-01-14 03:45:20 --> UTF-8 Support Enabled
INFO - 2023-01-14 03:45:20 --> Utf8 Class Initialized
INFO - 2023-01-14 03:45:20 --> URI Class Initialized
INFO - 2023-01-14 03:45:20 --> Router Class Initialized
INFO - 2023-01-14 03:45:20 --> Output Class Initialized
INFO - 2023-01-14 03:45:20 --> Security Class Initialized
DEBUG - 2023-01-14 03:45:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-14 03:45:20 --> Input Class Initialized
INFO - 2023-01-14 03:45:20 --> Language Class Initialized
INFO - 2023-01-14 03:45:20 --> Language Class Initialized
INFO - 2023-01-14 03:45:20 --> Config Class Initialized
INFO - 2023-01-14 03:45:20 --> Loader Class Initialized
INFO - 2023-01-14 03:45:20 --> Helper loaded: url_helper
INFO - 2023-01-14 03:45:20 --> Helper loaded: file_helper
INFO - 2023-01-14 03:45:20 --> Helper loaded: form_helper
INFO - 2023-01-14 03:45:20 --> Helper loaded: my_helper
INFO - 2023-01-14 03:45:20 --> Database Driver Class Initialized
DEBUG - 2023-01-14 03:45:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-01-14 03:45:20 --> Session: Class initialized using 'files' driver.
INFO - 2023-01-14 03:45:20 --> Controller Class Initialized
INFO - 2023-01-14 03:45:24 --> Config Class Initialized
INFO - 2023-01-14 03:45:24 --> Hooks Class Initialized
DEBUG - 2023-01-14 03:45:24 --> UTF-8 Support Enabled
INFO - 2023-01-14 03:45:24 --> Utf8 Class Initialized
INFO - 2023-01-14 03:45:24 --> URI Class Initialized
INFO - 2023-01-14 03:45:24 --> Router Class Initialized
INFO - 2023-01-14 03:45:24 --> Output Class Initialized
INFO - 2023-01-14 03:45:24 --> Security Class Initialized
DEBUG - 2023-01-14 03:45:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-14 03:45:24 --> Input Class Initialized
INFO - 2023-01-14 03:45:24 --> Language Class Initialized
INFO - 2023-01-14 03:45:24 --> Language Class Initialized
INFO - 2023-01-14 03:45:24 --> Config Class Initialized
INFO - 2023-01-14 03:45:24 --> Loader Class Initialized
INFO - 2023-01-14 03:45:24 --> Helper loaded: url_helper
INFO - 2023-01-14 03:45:24 --> Helper loaded: file_helper
INFO - 2023-01-14 03:45:24 --> Helper loaded: form_helper
INFO - 2023-01-14 03:45:24 --> Helper loaded: my_helper
INFO - 2023-01-14 03:45:24 --> Database Driver Class Initialized
DEBUG - 2023-01-14 03:45:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-01-14 03:45:24 --> Session: Class initialized using 'files' driver.
INFO - 2023-01-14 03:45:24 --> Controller Class Initialized
INFO - 2023-01-14 03:45:24 --> Final output sent to browser
DEBUG - 2023-01-14 03:45:24 --> Total execution time: 0.0575
INFO - 2023-01-14 03:48:05 --> Config Class Initialized
INFO - 2023-01-14 03:48:05 --> Hooks Class Initialized
DEBUG - 2023-01-14 03:48:05 --> UTF-8 Support Enabled
INFO - 2023-01-14 03:48:05 --> Utf8 Class Initialized
INFO - 2023-01-14 03:48:05 --> URI Class Initialized
INFO - 2023-01-14 03:48:05 --> Router Class Initialized
INFO - 2023-01-14 03:48:05 --> Output Class Initialized
INFO - 2023-01-14 03:48:05 --> Security Class Initialized
DEBUG - 2023-01-14 03:48:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-14 03:48:05 --> Input Class Initialized
INFO - 2023-01-14 03:48:05 --> Language Class Initialized
INFO - 2023-01-14 03:48:05 --> Language Class Initialized
INFO - 2023-01-14 03:48:05 --> Config Class Initialized
INFO - 2023-01-14 03:48:05 --> Loader Class Initialized
INFO - 2023-01-14 03:48:05 --> Helper loaded: url_helper
INFO - 2023-01-14 03:48:05 --> Helper loaded: file_helper
INFO - 2023-01-14 03:48:05 --> Helper loaded: form_helper
INFO - 2023-01-14 03:48:05 --> Helper loaded: my_helper
INFO - 2023-01-14 03:48:05 --> Database Driver Class Initialized
DEBUG - 2023-01-14 03:48:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-01-14 03:48:05 --> Session: Class initialized using 'files' driver.
INFO - 2023-01-14 03:48:05 --> Controller Class Initialized
DEBUG - 2023-01-14 03:48:05 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/view_mapel/views/v_view_mapel.php
DEBUG - 2023-01-14 03:48:05 --> File loaded: C:\xampp\htdocs\myraportk13\application\views\template_utama.php
INFO - 2023-01-14 03:48:05 --> Final output sent to browser
DEBUG - 2023-01-14 03:48:05 --> Total execution time: 0.0401
INFO - 2023-01-14 03:48:36 --> Config Class Initialized
INFO - 2023-01-14 03:48:36 --> Hooks Class Initialized
DEBUG - 2023-01-14 03:48:36 --> UTF-8 Support Enabled
INFO - 2023-01-14 03:48:36 --> Utf8 Class Initialized
INFO - 2023-01-14 03:48:36 --> URI Class Initialized
INFO - 2023-01-14 03:48:36 --> Router Class Initialized
INFO - 2023-01-14 03:48:36 --> Output Class Initialized
INFO - 2023-01-14 03:48:36 --> Security Class Initialized
DEBUG - 2023-01-14 03:48:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-14 03:48:36 --> Input Class Initialized
INFO - 2023-01-14 03:48:36 --> Language Class Initialized
INFO - 2023-01-14 03:48:36 --> Language Class Initialized
INFO - 2023-01-14 03:48:36 --> Config Class Initialized
INFO - 2023-01-14 03:48:36 --> Loader Class Initialized
INFO - 2023-01-14 03:48:36 --> Helper loaded: url_helper
INFO - 2023-01-14 03:48:36 --> Helper loaded: file_helper
INFO - 2023-01-14 03:48:36 --> Helper loaded: form_helper
INFO - 2023-01-14 03:48:36 --> Helper loaded: my_helper
INFO - 2023-01-14 03:48:36 --> Database Driver Class Initialized
DEBUG - 2023-01-14 03:48:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-01-14 03:48:36 --> Session: Class initialized using 'files' driver.
INFO - 2023-01-14 03:48:36 --> Controller Class Initialized
INFO - 2023-01-14 03:48:36 --> Helper loaded: cookie_helper
INFO - 2023-01-14 03:48:36 --> Config Class Initialized
INFO - 2023-01-14 03:48:36 --> Hooks Class Initialized
DEBUG - 2023-01-14 03:48:36 --> UTF-8 Support Enabled
INFO - 2023-01-14 03:48:36 --> Utf8 Class Initialized
INFO - 2023-01-14 03:48:36 --> URI Class Initialized
INFO - 2023-01-14 03:48:36 --> Router Class Initialized
INFO - 2023-01-14 03:48:36 --> Output Class Initialized
INFO - 2023-01-14 03:48:36 --> Security Class Initialized
DEBUG - 2023-01-14 03:48:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-14 03:48:36 --> Input Class Initialized
INFO - 2023-01-14 03:48:36 --> Language Class Initialized
INFO - 2023-01-14 03:48:36 --> Language Class Initialized
INFO - 2023-01-14 03:48:36 --> Config Class Initialized
INFO - 2023-01-14 03:48:36 --> Loader Class Initialized
INFO - 2023-01-14 03:48:36 --> Helper loaded: url_helper
INFO - 2023-01-14 03:48:36 --> Helper loaded: file_helper
INFO - 2023-01-14 03:48:36 --> Helper loaded: form_helper
INFO - 2023-01-14 03:48:36 --> Helper loaded: my_helper
INFO - 2023-01-14 03:48:36 --> Database Driver Class Initialized
DEBUG - 2023-01-14 03:48:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-01-14 03:48:36 --> Session: Class initialized using 'files' driver.
INFO - 2023-01-14 03:48:36 --> Controller Class Initialized
INFO - 2023-01-14 03:48:36 --> Config Class Initialized
INFO - 2023-01-14 03:48:36 --> Hooks Class Initialized
DEBUG - 2023-01-14 03:48:36 --> UTF-8 Support Enabled
INFO - 2023-01-14 03:48:36 --> Utf8 Class Initialized
INFO - 2023-01-14 03:48:36 --> URI Class Initialized
INFO - 2023-01-14 03:48:36 --> Router Class Initialized
INFO - 2023-01-14 03:48:36 --> Output Class Initialized
INFO - 2023-01-14 03:48:36 --> Security Class Initialized
DEBUG - 2023-01-14 03:48:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-14 03:48:36 --> Input Class Initialized
INFO - 2023-01-14 03:48:36 --> Language Class Initialized
INFO - 2023-01-14 03:48:36 --> Language Class Initialized
INFO - 2023-01-14 03:48:36 --> Config Class Initialized
INFO - 2023-01-14 03:48:36 --> Loader Class Initialized
INFO - 2023-01-14 03:48:36 --> Helper loaded: url_helper
INFO - 2023-01-14 03:48:36 --> Helper loaded: file_helper
INFO - 2023-01-14 03:48:36 --> Helper loaded: form_helper
INFO - 2023-01-14 03:48:36 --> Helper loaded: my_helper
INFO - 2023-01-14 03:48:36 --> Database Driver Class Initialized
DEBUG - 2023-01-14 03:48:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-01-14 03:48:36 --> Session: Class initialized using 'files' driver.
INFO - 2023-01-14 03:48:36 --> Controller Class Initialized
DEBUG - 2023-01-14 03:48:36 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/login/views/login.php
DEBUG - 2023-01-14 03:48:36 --> File loaded: C:\xampp\htdocs\myraportk13\application\views\template_utama.php
INFO - 2023-01-14 03:48:36 --> Final output sent to browser
DEBUG - 2023-01-14 03:48:36 --> Total execution time: 0.0416
INFO - 2023-01-14 03:48:43 --> Config Class Initialized
INFO - 2023-01-14 03:48:43 --> Hooks Class Initialized
DEBUG - 2023-01-14 03:48:43 --> UTF-8 Support Enabled
INFO - 2023-01-14 03:48:43 --> Utf8 Class Initialized
INFO - 2023-01-14 03:48:43 --> URI Class Initialized
INFO - 2023-01-14 03:48:43 --> Router Class Initialized
INFO - 2023-01-14 03:48:43 --> Output Class Initialized
INFO - 2023-01-14 03:48:43 --> Security Class Initialized
DEBUG - 2023-01-14 03:48:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-14 03:48:43 --> Input Class Initialized
INFO - 2023-01-14 03:48:43 --> Language Class Initialized
INFO - 2023-01-14 03:48:43 --> Language Class Initialized
INFO - 2023-01-14 03:48:43 --> Config Class Initialized
INFO - 2023-01-14 03:48:43 --> Loader Class Initialized
INFO - 2023-01-14 03:48:43 --> Helper loaded: url_helper
INFO - 2023-01-14 03:48:43 --> Helper loaded: file_helper
INFO - 2023-01-14 03:48:43 --> Helper loaded: form_helper
INFO - 2023-01-14 03:48:43 --> Helper loaded: my_helper
INFO - 2023-01-14 03:48:43 --> Database Driver Class Initialized
DEBUG - 2023-01-14 03:48:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-01-14 03:48:43 --> Session: Class initialized using 'files' driver.
INFO - 2023-01-14 03:48:43 --> Controller Class Initialized
INFO - 2023-01-14 03:48:43 --> Helper loaded: cookie_helper
INFO - 2023-01-14 03:48:43 --> Final output sent to browser
DEBUG - 2023-01-14 03:48:43 --> Total execution time: 0.0617
INFO - 2023-01-14 03:48:43 --> Config Class Initialized
INFO - 2023-01-14 03:48:43 --> Hooks Class Initialized
DEBUG - 2023-01-14 03:48:43 --> UTF-8 Support Enabled
INFO - 2023-01-14 03:48:43 --> Utf8 Class Initialized
INFO - 2023-01-14 03:48:43 --> URI Class Initialized
INFO - 2023-01-14 03:48:43 --> Router Class Initialized
INFO - 2023-01-14 03:48:43 --> Output Class Initialized
INFO - 2023-01-14 03:48:43 --> Security Class Initialized
DEBUG - 2023-01-14 03:48:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-14 03:48:43 --> Input Class Initialized
INFO - 2023-01-14 03:48:43 --> Language Class Initialized
INFO - 2023-01-14 03:48:43 --> Language Class Initialized
INFO - 2023-01-14 03:48:43 --> Config Class Initialized
INFO - 2023-01-14 03:48:43 --> Loader Class Initialized
INFO - 2023-01-14 03:48:43 --> Helper loaded: url_helper
INFO - 2023-01-14 03:48:43 --> Helper loaded: file_helper
INFO - 2023-01-14 03:48:43 --> Helper loaded: form_helper
INFO - 2023-01-14 03:48:43 --> Helper loaded: my_helper
INFO - 2023-01-14 03:48:43 --> Database Driver Class Initialized
DEBUG - 2023-01-14 03:48:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-01-14 03:48:43 --> Session: Class initialized using 'files' driver.
INFO - 2023-01-14 03:48:43 --> Controller Class Initialized
DEBUG - 2023-01-14 03:48:43 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/home/views/v_home.php
DEBUG - 2023-01-14 03:48:43 --> File loaded: C:\xampp\htdocs\myraportk13\application\views\template_utama.php
INFO - 2023-01-14 03:48:43 --> Final output sent to browser
DEBUG - 2023-01-14 03:48:43 --> Total execution time: 0.0451
INFO - 2023-01-14 03:48:47 --> Config Class Initialized
INFO - 2023-01-14 03:48:47 --> Hooks Class Initialized
DEBUG - 2023-01-14 03:48:47 --> UTF-8 Support Enabled
INFO - 2023-01-14 03:48:47 --> Utf8 Class Initialized
INFO - 2023-01-14 03:48:47 --> URI Class Initialized
INFO - 2023-01-14 03:48:47 --> Router Class Initialized
INFO - 2023-01-14 03:48:47 --> Output Class Initialized
INFO - 2023-01-14 03:48:47 --> Security Class Initialized
DEBUG - 2023-01-14 03:48:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-14 03:48:47 --> Input Class Initialized
INFO - 2023-01-14 03:48:47 --> Language Class Initialized
INFO - 2023-01-14 03:48:47 --> Language Class Initialized
INFO - 2023-01-14 03:48:47 --> Config Class Initialized
INFO - 2023-01-14 03:48:47 --> Loader Class Initialized
INFO - 2023-01-14 03:48:47 --> Helper loaded: url_helper
INFO - 2023-01-14 03:48:47 --> Helper loaded: file_helper
INFO - 2023-01-14 03:48:47 --> Helper loaded: form_helper
INFO - 2023-01-14 03:48:47 --> Helper loaded: my_helper
INFO - 2023-01-14 03:48:47 --> Database Driver Class Initialized
DEBUG - 2023-01-14 03:48:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-01-14 03:48:47 --> Session: Class initialized using 'files' driver.
INFO - 2023-01-14 03:48:47 --> Controller Class Initialized
DEBUG - 2023-01-14 03:48:47 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/data_mapel/views/list.php
DEBUG - 2023-01-14 03:48:47 --> File loaded: C:\xampp\htdocs\myraportk13\application\views\template_utama.php
INFO - 2023-01-14 03:48:47 --> Final output sent to browser
DEBUG - 2023-01-14 03:48:47 --> Total execution time: 0.0897
INFO - 2023-01-14 03:48:47 --> Config Class Initialized
INFO - 2023-01-14 03:48:47 --> Hooks Class Initialized
DEBUG - 2023-01-14 03:48:47 --> UTF-8 Support Enabled
INFO - 2023-01-14 03:48:47 --> Utf8 Class Initialized
INFO - 2023-01-14 03:48:47 --> URI Class Initialized
INFO - 2023-01-14 03:48:47 --> Router Class Initialized
INFO - 2023-01-14 03:48:47 --> Output Class Initialized
INFO - 2023-01-14 03:48:47 --> Security Class Initialized
DEBUG - 2023-01-14 03:48:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-14 03:48:47 --> Input Class Initialized
INFO - 2023-01-14 03:48:47 --> Language Class Initialized
INFO - 2023-01-14 03:48:47 --> Language Class Initialized
INFO - 2023-01-14 03:48:47 --> Config Class Initialized
INFO - 2023-01-14 03:48:47 --> Loader Class Initialized
INFO - 2023-01-14 03:48:47 --> Helper loaded: url_helper
INFO - 2023-01-14 03:48:47 --> Helper loaded: file_helper
INFO - 2023-01-14 03:48:47 --> Helper loaded: form_helper
INFO - 2023-01-14 03:48:47 --> Helper loaded: my_helper
INFO - 2023-01-14 03:48:47 --> Database Driver Class Initialized
DEBUG - 2023-01-14 03:48:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-01-14 03:48:47 --> Session: Class initialized using 'files' driver.
INFO - 2023-01-14 03:48:47 --> Controller Class Initialized
INFO - 2023-01-14 03:48:50 --> Config Class Initialized
INFO - 2023-01-14 03:48:50 --> Hooks Class Initialized
DEBUG - 2023-01-14 03:48:50 --> UTF-8 Support Enabled
INFO - 2023-01-14 03:48:50 --> Utf8 Class Initialized
INFO - 2023-01-14 03:48:50 --> URI Class Initialized
INFO - 2023-01-14 03:48:50 --> Router Class Initialized
INFO - 2023-01-14 03:48:50 --> Output Class Initialized
INFO - 2023-01-14 03:48:50 --> Security Class Initialized
DEBUG - 2023-01-14 03:48:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-14 03:48:50 --> Input Class Initialized
INFO - 2023-01-14 03:48:50 --> Language Class Initialized
INFO - 2023-01-14 03:48:50 --> Language Class Initialized
INFO - 2023-01-14 03:48:50 --> Config Class Initialized
INFO - 2023-01-14 03:48:50 --> Loader Class Initialized
INFO - 2023-01-14 03:48:50 --> Helper loaded: url_helper
INFO - 2023-01-14 03:48:50 --> Helper loaded: file_helper
INFO - 2023-01-14 03:48:50 --> Helper loaded: form_helper
INFO - 2023-01-14 03:48:50 --> Helper loaded: my_helper
INFO - 2023-01-14 03:48:50 --> Database Driver Class Initialized
DEBUG - 2023-01-14 03:48:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-01-14 03:48:50 --> Session: Class initialized using 'files' driver.
INFO - 2023-01-14 03:48:50 --> Controller Class Initialized
INFO - 2023-01-14 03:48:50 --> Final output sent to browser
DEBUG - 2023-01-14 03:48:50 --> Total execution time: 0.0399
INFO - 2023-01-14 03:49:17 --> Config Class Initialized
INFO - 2023-01-14 03:49:17 --> Hooks Class Initialized
DEBUG - 2023-01-14 03:49:17 --> UTF-8 Support Enabled
INFO - 2023-01-14 03:49:17 --> Utf8 Class Initialized
INFO - 2023-01-14 03:49:17 --> URI Class Initialized
INFO - 2023-01-14 03:49:17 --> Router Class Initialized
INFO - 2023-01-14 03:49:17 --> Output Class Initialized
INFO - 2023-01-14 03:49:17 --> Security Class Initialized
DEBUG - 2023-01-14 03:49:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-14 03:49:17 --> Input Class Initialized
INFO - 2023-01-14 03:49:17 --> Language Class Initialized
INFO - 2023-01-14 03:49:17 --> Language Class Initialized
INFO - 2023-01-14 03:49:17 --> Config Class Initialized
INFO - 2023-01-14 03:49:17 --> Loader Class Initialized
INFO - 2023-01-14 03:49:17 --> Helper loaded: url_helper
INFO - 2023-01-14 03:49:17 --> Helper loaded: file_helper
INFO - 2023-01-14 03:49:17 --> Helper loaded: form_helper
INFO - 2023-01-14 03:49:17 --> Helper loaded: my_helper
INFO - 2023-01-14 03:49:17 --> Database Driver Class Initialized
DEBUG - 2023-01-14 03:49:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-01-14 03:49:17 --> Session: Class initialized using 'files' driver.
INFO - 2023-01-14 03:49:17 --> Controller Class Initialized
INFO - 2023-01-14 03:49:17 --> Final output sent to browser
DEBUG - 2023-01-14 03:49:17 --> Total execution time: 0.0550
INFO - 2023-01-14 03:52:47 --> Config Class Initialized
INFO - 2023-01-14 03:52:47 --> Hooks Class Initialized
DEBUG - 2023-01-14 03:52:47 --> UTF-8 Support Enabled
INFO - 2023-01-14 03:52:47 --> Utf8 Class Initialized
INFO - 2023-01-14 03:52:47 --> URI Class Initialized
INFO - 2023-01-14 03:52:47 --> Router Class Initialized
INFO - 2023-01-14 03:52:47 --> Output Class Initialized
INFO - 2023-01-14 03:52:47 --> Security Class Initialized
DEBUG - 2023-01-14 03:52:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-14 03:52:47 --> Input Class Initialized
INFO - 2023-01-14 03:52:47 --> Language Class Initialized
INFO - 2023-01-14 03:52:47 --> Language Class Initialized
INFO - 2023-01-14 03:52:47 --> Config Class Initialized
INFO - 2023-01-14 03:52:47 --> Loader Class Initialized
INFO - 2023-01-14 03:52:47 --> Helper loaded: url_helper
INFO - 2023-01-14 03:52:47 --> Helper loaded: file_helper
INFO - 2023-01-14 03:52:47 --> Helper loaded: form_helper
INFO - 2023-01-14 03:52:47 --> Helper loaded: my_helper
INFO - 2023-01-14 03:52:47 --> Database Driver Class Initialized
DEBUG - 2023-01-14 03:52:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-01-14 03:52:47 --> Session: Class initialized using 'files' driver.
INFO - 2023-01-14 03:52:47 --> Controller Class Initialized
DEBUG - 2023-01-14 03:52:47 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/data_mapel/views/list.php
DEBUG - 2023-01-14 03:52:47 --> File loaded: C:\xampp\htdocs\myraportk13\application\views\template_utama.php
INFO - 2023-01-14 03:52:47 --> Final output sent to browser
DEBUG - 2023-01-14 03:52:47 --> Total execution time: 0.0570
INFO - 2023-01-14 03:52:48 --> Config Class Initialized
INFO - 2023-01-14 03:52:48 --> Hooks Class Initialized
DEBUG - 2023-01-14 03:52:48 --> UTF-8 Support Enabled
INFO - 2023-01-14 03:52:48 --> Utf8 Class Initialized
INFO - 2023-01-14 03:52:48 --> URI Class Initialized
INFO - 2023-01-14 03:52:48 --> Router Class Initialized
INFO - 2023-01-14 03:52:48 --> Output Class Initialized
INFO - 2023-01-14 03:52:48 --> Security Class Initialized
DEBUG - 2023-01-14 03:52:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-14 03:52:48 --> Input Class Initialized
INFO - 2023-01-14 03:52:48 --> Language Class Initialized
INFO - 2023-01-14 03:52:48 --> Language Class Initialized
INFO - 2023-01-14 03:52:48 --> Config Class Initialized
INFO - 2023-01-14 03:52:48 --> Loader Class Initialized
INFO - 2023-01-14 03:52:48 --> Helper loaded: url_helper
INFO - 2023-01-14 03:52:48 --> Helper loaded: file_helper
INFO - 2023-01-14 03:52:48 --> Helper loaded: form_helper
INFO - 2023-01-14 03:52:48 --> Helper loaded: my_helper
INFO - 2023-01-14 03:52:48 --> Database Driver Class Initialized
DEBUG - 2023-01-14 03:52:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-01-14 03:52:48 --> Session: Class initialized using 'files' driver.
INFO - 2023-01-14 03:52:48 --> Controller Class Initialized
INFO - 2023-01-14 03:52:55 --> Config Class Initialized
INFO - 2023-01-14 03:52:55 --> Hooks Class Initialized
DEBUG - 2023-01-14 03:52:55 --> UTF-8 Support Enabled
INFO - 2023-01-14 03:52:55 --> Utf8 Class Initialized
INFO - 2023-01-14 03:52:55 --> URI Class Initialized
INFO - 2023-01-14 03:52:55 --> Router Class Initialized
INFO - 2023-01-14 03:52:55 --> Output Class Initialized
INFO - 2023-01-14 03:52:55 --> Security Class Initialized
DEBUG - 2023-01-14 03:52:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-14 03:52:55 --> Input Class Initialized
INFO - 2023-01-14 03:52:55 --> Language Class Initialized
INFO - 2023-01-14 03:52:55 --> Language Class Initialized
INFO - 2023-01-14 03:52:55 --> Config Class Initialized
INFO - 2023-01-14 03:52:55 --> Loader Class Initialized
INFO - 2023-01-14 03:52:55 --> Helper loaded: url_helper
INFO - 2023-01-14 03:52:55 --> Helper loaded: file_helper
INFO - 2023-01-14 03:52:55 --> Helper loaded: form_helper
INFO - 2023-01-14 03:52:55 --> Helper loaded: my_helper
INFO - 2023-01-14 03:52:55 --> Database Driver Class Initialized
DEBUG - 2023-01-14 03:52:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-01-14 03:52:55 --> Session: Class initialized using 'files' driver.
INFO - 2023-01-14 03:52:55 --> Controller Class Initialized
INFO - 2023-01-14 03:52:55 --> Final output sent to browser
DEBUG - 2023-01-14 03:52:55 --> Total execution time: 0.0409
INFO - 2023-01-14 03:53:00 --> Config Class Initialized
INFO - 2023-01-14 03:53:00 --> Hooks Class Initialized
DEBUG - 2023-01-14 03:53:00 --> UTF-8 Support Enabled
INFO - 2023-01-14 03:53:00 --> Utf8 Class Initialized
INFO - 2023-01-14 03:53:00 --> URI Class Initialized
INFO - 2023-01-14 03:53:00 --> Router Class Initialized
INFO - 2023-01-14 03:53:00 --> Output Class Initialized
INFO - 2023-01-14 03:53:00 --> Security Class Initialized
DEBUG - 2023-01-14 03:53:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-14 03:53:00 --> Input Class Initialized
INFO - 2023-01-14 03:53:00 --> Language Class Initialized
INFO - 2023-01-14 03:53:00 --> Language Class Initialized
INFO - 2023-01-14 03:53:00 --> Config Class Initialized
INFO - 2023-01-14 03:53:00 --> Loader Class Initialized
INFO - 2023-01-14 03:53:00 --> Helper loaded: url_helper
INFO - 2023-01-14 03:53:00 --> Helper loaded: file_helper
INFO - 2023-01-14 03:53:00 --> Helper loaded: form_helper
INFO - 2023-01-14 03:53:00 --> Helper loaded: my_helper
INFO - 2023-01-14 03:53:00 --> Database Driver Class Initialized
DEBUG - 2023-01-14 03:53:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-01-14 03:53:00 --> Session: Class initialized using 'files' driver.
INFO - 2023-01-14 03:53:00 --> Controller Class Initialized
INFO - 2023-01-14 03:53:00 --> Helper loaded: cookie_helper
INFO - 2023-01-14 03:53:00 --> Config Class Initialized
INFO - 2023-01-14 03:53:00 --> Hooks Class Initialized
DEBUG - 2023-01-14 03:53:00 --> UTF-8 Support Enabled
INFO - 2023-01-14 03:53:00 --> Utf8 Class Initialized
INFO - 2023-01-14 03:53:00 --> URI Class Initialized
INFO - 2023-01-14 03:53:00 --> Router Class Initialized
INFO - 2023-01-14 03:53:00 --> Output Class Initialized
INFO - 2023-01-14 03:53:00 --> Security Class Initialized
DEBUG - 2023-01-14 03:53:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-14 03:53:00 --> Input Class Initialized
INFO - 2023-01-14 03:53:00 --> Language Class Initialized
INFO - 2023-01-14 03:53:00 --> Language Class Initialized
INFO - 2023-01-14 03:53:00 --> Config Class Initialized
INFO - 2023-01-14 03:53:00 --> Loader Class Initialized
INFO - 2023-01-14 03:53:00 --> Helper loaded: url_helper
INFO - 2023-01-14 03:53:00 --> Helper loaded: file_helper
INFO - 2023-01-14 03:53:00 --> Helper loaded: form_helper
INFO - 2023-01-14 03:53:00 --> Helper loaded: my_helper
INFO - 2023-01-14 03:53:00 --> Database Driver Class Initialized
DEBUG - 2023-01-14 03:53:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-01-14 03:53:00 --> Session: Class initialized using 'files' driver.
INFO - 2023-01-14 03:53:00 --> Controller Class Initialized
INFO - 2023-01-14 03:53:00 --> Config Class Initialized
INFO - 2023-01-14 03:53:00 --> Hooks Class Initialized
DEBUG - 2023-01-14 03:53:00 --> UTF-8 Support Enabled
INFO - 2023-01-14 03:53:00 --> Utf8 Class Initialized
INFO - 2023-01-14 03:53:00 --> URI Class Initialized
INFO - 2023-01-14 03:53:00 --> Router Class Initialized
INFO - 2023-01-14 03:53:00 --> Output Class Initialized
INFO - 2023-01-14 03:53:00 --> Security Class Initialized
DEBUG - 2023-01-14 03:53:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-14 03:53:00 --> Input Class Initialized
INFO - 2023-01-14 03:53:00 --> Language Class Initialized
INFO - 2023-01-14 03:53:00 --> Language Class Initialized
INFO - 2023-01-14 03:53:00 --> Config Class Initialized
INFO - 2023-01-14 03:53:00 --> Loader Class Initialized
INFO - 2023-01-14 03:53:00 --> Helper loaded: url_helper
INFO - 2023-01-14 03:53:00 --> Helper loaded: file_helper
INFO - 2023-01-14 03:53:00 --> Helper loaded: form_helper
INFO - 2023-01-14 03:53:00 --> Helper loaded: my_helper
INFO - 2023-01-14 03:53:00 --> Database Driver Class Initialized
DEBUG - 2023-01-14 03:53:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-01-14 03:53:00 --> Session: Class initialized using 'files' driver.
INFO - 2023-01-14 03:53:00 --> Controller Class Initialized
DEBUG - 2023-01-14 03:53:00 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/login/views/login.php
DEBUG - 2023-01-14 03:53:00 --> File loaded: C:\xampp\htdocs\myraportk13\application\views\template_utama.php
INFO - 2023-01-14 03:53:00 --> Final output sent to browser
DEBUG - 2023-01-14 03:53:00 --> Total execution time: 0.0356
INFO - 2023-01-14 03:53:04 --> Config Class Initialized
INFO - 2023-01-14 03:53:04 --> Hooks Class Initialized
DEBUG - 2023-01-14 03:53:04 --> UTF-8 Support Enabled
INFO - 2023-01-14 03:53:04 --> Utf8 Class Initialized
INFO - 2023-01-14 03:53:04 --> URI Class Initialized
INFO - 2023-01-14 03:53:04 --> Router Class Initialized
INFO - 2023-01-14 03:53:04 --> Output Class Initialized
INFO - 2023-01-14 03:53:04 --> Security Class Initialized
DEBUG - 2023-01-14 03:53:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-14 03:53:04 --> Input Class Initialized
INFO - 2023-01-14 03:53:04 --> Language Class Initialized
INFO - 2023-01-14 03:53:04 --> Language Class Initialized
INFO - 2023-01-14 03:53:04 --> Config Class Initialized
INFO - 2023-01-14 03:53:04 --> Loader Class Initialized
INFO - 2023-01-14 03:53:04 --> Helper loaded: url_helper
INFO - 2023-01-14 03:53:04 --> Helper loaded: file_helper
INFO - 2023-01-14 03:53:04 --> Helper loaded: form_helper
INFO - 2023-01-14 03:53:04 --> Helper loaded: my_helper
INFO - 2023-01-14 03:53:04 --> Database Driver Class Initialized
DEBUG - 2023-01-14 03:53:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-01-14 03:53:04 --> Session: Class initialized using 'files' driver.
INFO - 2023-01-14 03:53:04 --> Controller Class Initialized
INFO - 2023-01-14 03:53:04 --> Helper loaded: cookie_helper
INFO - 2023-01-14 03:53:04 --> Final output sent to browser
DEBUG - 2023-01-14 03:53:04 --> Total execution time: 0.0609
INFO - 2023-01-14 03:53:04 --> Config Class Initialized
INFO - 2023-01-14 03:53:04 --> Hooks Class Initialized
DEBUG - 2023-01-14 03:53:04 --> UTF-8 Support Enabled
INFO - 2023-01-14 03:53:04 --> Utf8 Class Initialized
INFO - 2023-01-14 03:53:04 --> URI Class Initialized
INFO - 2023-01-14 03:53:04 --> Router Class Initialized
INFO - 2023-01-14 03:53:04 --> Output Class Initialized
INFO - 2023-01-14 03:53:04 --> Security Class Initialized
DEBUG - 2023-01-14 03:53:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-14 03:53:04 --> Input Class Initialized
INFO - 2023-01-14 03:53:04 --> Language Class Initialized
INFO - 2023-01-14 03:53:04 --> Language Class Initialized
INFO - 2023-01-14 03:53:04 --> Config Class Initialized
INFO - 2023-01-14 03:53:04 --> Loader Class Initialized
INFO - 2023-01-14 03:53:04 --> Helper loaded: url_helper
INFO - 2023-01-14 03:53:04 --> Helper loaded: file_helper
INFO - 2023-01-14 03:53:04 --> Helper loaded: form_helper
INFO - 2023-01-14 03:53:04 --> Helper loaded: my_helper
INFO - 2023-01-14 03:53:04 --> Database Driver Class Initialized
DEBUG - 2023-01-14 03:53:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-01-14 03:53:04 --> Session: Class initialized using 'files' driver.
INFO - 2023-01-14 03:53:04 --> Controller Class Initialized
DEBUG - 2023-01-14 03:53:04 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/home/views/v_home_guru.php
DEBUG - 2023-01-14 03:53:04 --> File loaded: C:\xampp\htdocs\myraportk13\application\views\template_utama.php
INFO - 2023-01-14 03:53:04 --> Final output sent to browser
DEBUG - 2023-01-14 03:53:04 --> Total execution time: 0.0679
INFO - 2023-01-14 03:53:07 --> Config Class Initialized
INFO - 2023-01-14 03:53:07 --> Hooks Class Initialized
DEBUG - 2023-01-14 03:53:07 --> UTF-8 Support Enabled
INFO - 2023-01-14 03:53:07 --> Utf8 Class Initialized
INFO - 2023-01-14 03:53:07 --> URI Class Initialized
INFO - 2023-01-14 03:53:07 --> Router Class Initialized
INFO - 2023-01-14 03:53:07 --> Output Class Initialized
INFO - 2023-01-14 03:53:08 --> Security Class Initialized
DEBUG - 2023-01-14 03:53:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-14 03:53:08 --> Input Class Initialized
INFO - 2023-01-14 03:53:08 --> Language Class Initialized
INFO - 2023-01-14 03:53:08 --> Language Class Initialized
INFO - 2023-01-14 03:53:08 --> Config Class Initialized
INFO - 2023-01-14 03:53:08 --> Loader Class Initialized
INFO - 2023-01-14 03:53:08 --> Helper loaded: url_helper
INFO - 2023-01-14 03:53:08 --> Helper loaded: file_helper
INFO - 2023-01-14 03:53:08 --> Helper loaded: form_helper
INFO - 2023-01-14 03:53:08 --> Helper loaded: my_helper
INFO - 2023-01-14 03:53:08 --> Database Driver Class Initialized
DEBUG - 2023-01-14 03:53:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-01-14 03:53:08 --> Session: Class initialized using 'files' driver.
INFO - 2023-01-14 03:53:08 --> Controller Class Initialized
DEBUG - 2023-01-14 03:53:08 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/view_mapel/views/v_view_mapel.php
DEBUG - 2023-01-14 03:53:08 --> File loaded: C:\xampp\htdocs\myraportk13\application\views\template_utama.php
INFO - 2023-01-14 03:53:08 --> Final output sent to browser
DEBUG - 2023-01-14 03:53:08 --> Total execution time: 0.0567
INFO - 2023-01-14 03:53:12 --> Config Class Initialized
INFO - 2023-01-14 03:53:12 --> Hooks Class Initialized
DEBUG - 2023-01-14 03:53:12 --> UTF-8 Support Enabled
INFO - 2023-01-14 03:53:12 --> Utf8 Class Initialized
INFO - 2023-01-14 03:53:12 --> URI Class Initialized
INFO - 2023-01-14 03:53:12 --> Router Class Initialized
INFO - 2023-01-14 03:53:12 --> Output Class Initialized
INFO - 2023-01-14 03:53:12 --> Security Class Initialized
DEBUG - 2023-01-14 03:53:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-14 03:53:12 --> Input Class Initialized
INFO - 2023-01-14 03:53:12 --> Language Class Initialized
INFO - 2023-01-14 03:53:12 --> Language Class Initialized
INFO - 2023-01-14 03:53:12 --> Config Class Initialized
INFO - 2023-01-14 03:53:12 --> Loader Class Initialized
INFO - 2023-01-14 03:53:12 --> Helper loaded: url_helper
INFO - 2023-01-14 03:53:12 --> Helper loaded: file_helper
INFO - 2023-01-14 03:53:12 --> Helper loaded: form_helper
INFO - 2023-01-14 03:53:12 --> Helper loaded: my_helper
INFO - 2023-01-14 03:53:12 --> Database Driver Class Initialized
DEBUG - 2023-01-14 03:53:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-01-14 03:53:12 --> Session: Class initialized using 'files' driver.
INFO - 2023-01-14 03:53:12 --> Controller Class Initialized
DEBUG - 2023-01-14 03:53:12 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/n_icb/views/list.php
DEBUG - 2023-01-14 03:53:12 --> File loaded: C:\xampp\htdocs\myraportk13\application\views\template_utama.php
INFO - 2023-01-14 03:53:12 --> Final output sent to browser
DEBUG - 2023-01-14 03:53:12 --> Total execution time: 0.0390
INFO - 2023-01-14 03:53:12 --> Config Class Initialized
INFO - 2023-01-14 03:53:12 --> Hooks Class Initialized
DEBUG - 2023-01-14 03:53:12 --> UTF-8 Support Enabled
INFO - 2023-01-14 03:53:12 --> Utf8 Class Initialized
INFO - 2023-01-14 03:53:12 --> URI Class Initialized
INFO - 2023-01-14 03:53:12 --> Router Class Initialized
INFO - 2023-01-14 03:53:12 --> Output Class Initialized
INFO - 2023-01-14 03:53:12 --> Security Class Initialized
DEBUG - 2023-01-14 03:53:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-14 03:53:12 --> Input Class Initialized
INFO - 2023-01-14 03:53:12 --> Language Class Initialized
INFO - 2023-01-14 03:53:12 --> Language Class Initialized
INFO - 2023-01-14 03:53:12 --> Config Class Initialized
INFO - 2023-01-14 03:53:12 --> Loader Class Initialized
INFO - 2023-01-14 03:53:12 --> Helper loaded: url_helper
INFO - 2023-01-14 03:53:12 --> Helper loaded: file_helper
INFO - 2023-01-14 03:53:12 --> Helper loaded: form_helper
INFO - 2023-01-14 03:53:12 --> Helper loaded: my_helper
INFO - 2023-01-14 03:53:12 --> Database Driver Class Initialized
DEBUG - 2023-01-14 03:53:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-01-14 03:53:12 --> Session: Class initialized using 'files' driver.
INFO - 2023-01-14 03:53:12 --> Controller Class Initialized
INFO - 2023-01-14 03:53:14 --> Config Class Initialized
INFO - 2023-01-14 03:53:14 --> Hooks Class Initialized
DEBUG - 2023-01-14 03:53:14 --> UTF-8 Support Enabled
INFO - 2023-01-14 03:53:14 --> Utf8 Class Initialized
INFO - 2023-01-14 03:53:14 --> URI Class Initialized
INFO - 2023-01-14 03:53:14 --> Router Class Initialized
INFO - 2023-01-14 03:53:14 --> Output Class Initialized
INFO - 2023-01-14 03:53:14 --> Security Class Initialized
DEBUG - 2023-01-14 03:53:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-14 03:53:14 --> Input Class Initialized
INFO - 2023-01-14 03:53:14 --> Language Class Initialized
INFO - 2023-01-14 03:53:14 --> Language Class Initialized
INFO - 2023-01-14 03:53:14 --> Config Class Initialized
INFO - 2023-01-14 03:53:14 --> Loader Class Initialized
INFO - 2023-01-14 03:53:14 --> Helper loaded: url_helper
INFO - 2023-01-14 03:53:14 --> Helper loaded: file_helper
INFO - 2023-01-14 03:53:14 --> Helper loaded: form_helper
INFO - 2023-01-14 03:53:14 --> Helper loaded: my_helper
INFO - 2023-01-14 03:53:14 --> Database Driver Class Initialized
DEBUG - 2023-01-14 03:53:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-01-14 03:53:14 --> Session: Class initialized using 'files' driver.
INFO - 2023-01-14 03:53:14 --> Controller Class Initialized
INFO - 2023-01-14 03:53:14 --> Final output sent to browser
DEBUG - 2023-01-14 03:53:14 --> Total execution time: 0.0649
INFO - 2023-01-14 03:53:17 --> Config Class Initialized
INFO - 2023-01-14 03:53:17 --> Hooks Class Initialized
DEBUG - 2023-01-14 03:53:17 --> UTF-8 Support Enabled
INFO - 2023-01-14 03:53:17 --> Utf8 Class Initialized
INFO - 2023-01-14 03:53:17 --> URI Class Initialized
INFO - 2023-01-14 03:53:17 --> Router Class Initialized
INFO - 2023-01-14 03:53:17 --> Output Class Initialized
INFO - 2023-01-14 03:53:17 --> Security Class Initialized
DEBUG - 2023-01-14 03:53:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-14 03:53:17 --> Input Class Initialized
INFO - 2023-01-14 03:53:17 --> Language Class Initialized
INFO - 2023-01-14 03:53:17 --> Language Class Initialized
INFO - 2023-01-14 03:53:17 --> Config Class Initialized
INFO - 2023-01-14 03:53:17 --> Loader Class Initialized
INFO - 2023-01-14 03:53:17 --> Helper loaded: url_helper
INFO - 2023-01-14 03:53:17 --> Helper loaded: file_helper
INFO - 2023-01-14 03:53:17 --> Helper loaded: form_helper
INFO - 2023-01-14 03:53:17 --> Helper loaded: my_helper
INFO - 2023-01-14 03:53:17 --> Database Driver Class Initialized
DEBUG - 2023-01-14 03:53:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-01-14 03:53:17 --> Session: Class initialized using 'files' driver.
INFO - 2023-01-14 03:53:17 --> Controller Class Initialized
INFO - 2023-01-14 03:53:17 --> Final output sent to browser
DEBUG - 2023-01-14 03:53:17 --> Total execution time: 0.0568
INFO - 2023-01-14 03:53:21 --> Config Class Initialized
INFO - 2023-01-14 03:53:21 --> Hooks Class Initialized
DEBUG - 2023-01-14 03:53:21 --> UTF-8 Support Enabled
INFO - 2023-01-14 03:53:21 --> Utf8 Class Initialized
INFO - 2023-01-14 03:53:21 --> URI Class Initialized
INFO - 2023-01-14 03:53:21 --> Router Class Initialized
INFO - 2023-01-14 03:53:21 --> Output Class Initialized
INFO - 2023-01-14 03:53:21 --> Security Class Initialized
DEBUG - 2023-01-14 03:53:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-14 03:53:21 --> Input Class Initialized
INFO - 2023-01-14 03:53:21 --> Language Class Initialized
INFO - 2023-01-14 03:53:21 --> Language Class Initialized
INFO - 2023-01-14 03:53:21 --> Config Class Initialized
INFO - 2023-01-14 03:53:21 --> Loader Class Initialized
INFO - 2023-01-14 03:53:21 --> Helper loaded: url_helper
INFO - 2023-01-14 03:53:21 --> Helper loaded: file_helper
INFO - 2023-01-14 03:53:21 --> Helper loaded: form_helper
INFO - 2023-01-14 03:53:21 --> Helper loaded: my_helper
INFO - 2023-01-14 03:53:21 --> Database Driver Class Initialized
DEBUG - 2023-01-14 03:53:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-01-14 03:53:21 --> Session: Class initialized using 'files' driver.
INFO - 2023-01-14 03:53:21 --> Controller Class Initialized
DEBUG - 2023-01-14 03:53:21 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/view_mapel/views/v_view_mapel.php
DEBUG - 2023-01-14 03:53:21 --> File loaded: C:\xampp\htdocs\myraportk13\application\views\template_utama.php
INFO - 2023-01-14 03:53:21 --> Final output sent to browser
DEBUG - 2023-01-14 03:53:21 --> Total execution time: 0.0441
INFO - 2023-01-14 03:53:41 --> Config Class Initialized
INFO - 2023-01-14 03:53:41 --> Hooks Class Initialized
DEBUG - 2023-01-14 03:53:41 --> UTF-8 Support Enabled
INFO - 2023-01-14 03:53:41 --> Utf8 Class Initialized
INFO - 2023-01-14 03:53:41 --> URI Class Initialized
INFO - 2023-01-14 03:53:41 --> Router Class Initialized
INFO - 2023-01-14 03:53:41 --> Output Class Initialized
INFO - 2023-01-14 03:53:41 --> Security Class Initialized
DEBUG - 2023-01-14 03:53:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-14 03:53:41 --> Input Class Initialized
INFO - 2023-01-14 03:53:41 --> Language Class Initialized
INFO - 2023-01-14 03:53:41 --> Language Class Initialized
INFO - 2023-01-14 03:53:41 --> Config Class Initialized
INFO - 2023-01-14 03:53:41 --> Loader Class Initialized
INFO - 2023-01-14 03:53:41 --> Helper loaded: url_helper
INFO - 2023-01-14 03:53:41 --> Helper loaded: file_helper
INFO - 2023-01-14 03:53:41 --> Helper loaded: form_helper
INFO - 2023-01-14 03:53:41 --> Helper loaded: my_helper
INFO - 2023-01-14 03:53:41 --> Database Driver Class Initialized
DEBUG - 2023-01-14 03:53:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-01-14 03:53:41 --> Session: Class initialized using 'files' driver.
INFO - 2023-01-14 03:53:41 --> Controller Class Initialized
INFO - 2023-01-14 03:53:41 --> Helper loaded: cookie_helper
INFO - 2023-01-14 03:53:41 --> Config Class Initialized
INFO - 2023-01-14 03:53:41 --> Hooks Class Initialized
DEBUG - 2023-01-14 03:53:41 --> UTF-8 Support Enabled
INFO - 2023-01-14 03:53:41 --> Utf8 Class Initialized
INFO - 2023-01-14 03:53:41 --> URI Class Initialized
INFO - 2023-01-14 03:53:41 --> Router Class Initialized
INFO - 2023-01-14 03:53:41 --> Output Class Initialized
INFO - 2023-01-14 03:53:41 --> Security Class Initialized
DEBUG - 2023-01-14 03:53:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-14 03:53:41 --> Input Class Initialized
INFO - 2023-01-14 03:53:41 --> Language Class Initialized
INFO - 2023-01-14 03:53:41 --> Language Class Initialized
INFO - 2023-01-14 03:53:41 --> Config Class Initialized
INFO - 2023-01-14 03:53:41 --> Loader Class Initialized
INFO - 2023-01-14 03:53:41 --> Helper loaded: url_helper
INFO - 2023-01-14 03:53:41 --> Helper loaded: file_helper
INFO - 2023-01-14 03:53:41 --> Helper loaded: form_helper
INFO - 2023-01-14 03:53:41 --> Helper loaded: my_helper
INFO - 2023-01-14 03:53:41 --> Database Driver Class Initialized
DEBUG - 2023-01-14 03:53:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-01-14 03:53:41 --> Session: Class initialized using 'files' driver.
INFO - 2023-01-14 03:53:41 --> Controller Class Initialized
INFO - 2023-01-14 03:53:41 --> Config Class Initialized
INFO - 2023-01-14 03:53:41 --> Hooks Class Initialized
DEBUG - 2023-01-14 03:53:41 --> UTF-8 Support Enabled
INFO - 2023-01-14 03:53:41 --> Utf8 Class Initialized
INFO - 2023-01-14 03:53:41 --> URI Class Initialized
INFO - 2023-01-14 03:53:41 --> Router Class Initialized
INFO - 2023-01-14 03:53:41 --> Output Class Initialized
INFO - 2023-01-14 03:53:41 --> Security Class Initialized
DEBUG - 2023-01-14 03:53:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-14 03:53:41 --> Input Class Initialized
INFO - 2023-01-14 03:53:42 --> Language Class Initialized
INFO - 2023-01-14 03:53:42 --> Language Class Initialized
INFO - 2023-01-14 03:53:42 --> Config Class Initialized
INFO - 2023-01-14 03:53:42 --> Loader Class Initialized
INFO - 2023-01-14 03:53:42 --> Helper loaded: url_helper
INFO - 2023-01-14 03:53:42 --> Helper loaded: file_helper
INFO - 2023-01-14 03:53:42 --> Helper loaded: form_helper
INFO - 2023-01-14 03:53:42 --> Helper loaded: my_helper
INFO - 2023-01-14 03:53:42 --> Database Driver Class Initialized
DEBUG - 2023-01-14 03:53:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-01-14 03:53:42 --> Session: Class initialized using 'files' driver.
INFO - 2023-01-14 03:53:42 --> Controller Class Initialized
DEBUG - 2023-01-14 03:53:42 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/login/views/login.php
DEBUG - 2023-01-14 03:53:42 --> File loaded: C:\xampp\htdocs\myraportk13\application\views\template_utama.php
INFO - 2023-01-14 03:53:42 --> Final output sent to browser
DEBUG - 2023-01-14 03:53:42 --> Total execution time: 0.0319
INFO - 2023-01-14 03:53:49 --> Config Class Initialized
INFO - 2023-01-14 03:53:49 --> Hooks Class Initialized
DEBUG - 2023-01-14 03:53:49 --> UTF-8 Support Enabled
INFO - 2023-01-14 03:53:49 --> Utf8 Class Initialized
INFO - 2023-01-14 03:53:49 --> URI Class Initialized
INFO - 2023-01-14 03:53:49 --> Router Class Initialized
INFO - 2023-01-14 03:53:49 --> Output Class Initialized
INFO - 2023-01-14 03:53:49 --> Security Class Initialized
DEBUG - 2023-01-14 03:53:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-14 03:53:49 --> Input Class Initialized
INFO - 2023-01-14 03:53:49 --> Language Class Initialized
INFO - 2023-01-14 03:53:49 --> Language Class Initialized
INFO - 2023-01-14 03:53:49 --> Config Class Initialized
INFO - 2023-01-14 03:53:49 --> Loader Class Initialized
INFO - 2023-01-14 03:53:49 --> Helper loaded: url_helper
INFO - 2023-01-14 03:53:49 --> Helper loaded: file_helper
INFO - 2023-01-14 03:53:49 --> Helper loaded: form_helper
INFO - 2023-01-14 03:53:49 --> Helper loaded: my_helper
INFO - 2023-01-14 03:53:49 --> Database Driver Class Initialized
DEBUG - 2023-01-14 03:53:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-01-14 03:53:49 --> Session: Class initialized using 'files' driver.
INFO - 2023-01-14 03:53:49 --> Controller Class Initialized
INFO - 2023-01-14 03:53:49 --> Helper loaded: cookie_helper
INFO - 2023-01-14 03:53:49 --> Final output sent to browser
DEBUG - 2023-01-14 03:53:49 --> Total execution time: 0.0396
INFO - 2023-01-14 03:53:49 --> Config Class Initialized
INFO - 2023-01-14 03:53:49 --> Hooks Class Initialized
DEBUG - 2023-01-14 03:53:49 --> UTF-8 Support Enabled
INFO - 2023-01-14 03:53:49 --> Utf8 Class Initialized
INFO - 2023-01-14 03:53:49 --> URI Class Initialized
INFO - 2023-01-14 03:53:49 --> Router Class Initialized
INFO - 2023-01-14 03:53:49 --> Output Class Initialized
INFO - 2023-01-14 03:53:49 --> Security Class Initialized
DEBUG - 2023-01-14 03:53:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-14 03:53:49 --> Input Class Initialized
INFO - 2023-01-14 03:53:49 --> Language Class Initialized
INFO - 2023-01-14 03:53:49 --> Language Class Initialized
INFO - 2023-01-14 03:53:49 --> Config Class Initialized
INFO - 2023-01-14 03:53:49 --> Loader Class Initialized
INFO - 2023-01-14 03:53:49 --> Helper loaded: url_helper
INFO - 2023-01-14 03:53:49 --> Helper loaded: file_helper
INFO - 2023-01-14 03:53:49 --> Helper loaded: form_helper
INFO - 2023-01-14 03:53:49 --> Helper loaded: my_helper
INFO - 2023-01-14 03:53:49 --> Database Driver Class Initialized
DEBUG - 2023-01-14 03:53:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-01-14 03:53:49 --> Session: Class initialized using 'files' driver.
INFO - 2023-01-14 03:53:49 --> Controller Class Initialized
DEBUG - 2023-01-14 03:53:49 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/home/views/v_home_guru.php
DEBUG - 2023-01-14 03:53:49 --> File loaded: C:\xampp\htdocs\myraportk13\application\views\template_utama.php
INFO - 2023-01-14 03:53:49 --> Final output sent to browser
DEBUG - 2023-01-14 03:53:49 --> Total execution time: 0.0491
INFO - 2023-01-14 03:53:52 --> Config Class Initialized
INFO - 2023-01-14 03:53:52 --> Hooks Class Initialized
DEBUG - 2023-01-14 03:53:52 --> UTF-8 Support Enabled
INFO - 2023-01-14 03:53:52 --> Utf8 Class Initialized
INFO - 2023-01-14 03:53:52 --> URI Class Initialized
INFO - 2023-01-14 03:53:52 --> Router Class Initialized
INFO - 2023-01-14 03:53:52 --> Output Class Initialized
INFO - 2023-01-14 03:53:52 --> Security Class Initialized
DEBUG - 2023-01-14 03:53:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-14 03:53:52 --> Input Class Initialized
INFO - 2023-01-14 03:53:52 --> Language Class Initialized
INFO - 2023-01-14 03:53:52 --> Language Class Initialized
INFO - 2023-01-14 03:53:52 --> Config Class Initialized
INFO - 2023-01-14 03:53:52 --> Loader Class Initialized
INFO - 2023-01-14 03:53:52 --> Helper loaded: url_helper
INFO - 2023-01-14 03:53:52 --> Helper loaded: file_helper
INFO - 2023-01-14 03:53:52 --> Helper loaded: form_helper
INFO - 2023-01-14 03:53:52 --> Helper loaded: my_helper
INFO - 2023-01-14 03:53:52 --> Database Driver Class Initialized
DEBUG - 2023-01-14 03:53:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-01-14 03:53:52 --> Session: Class initialized using 'files' driver.
INFO - 2023-01-14 03:53:52 --> Controller Class Initialized
DEBUG - 2023-01-14 03:53:52 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/view_mapel/views/v_view_mapel.php
DEBUG - 2023-01-14 03:53:52 --> File loaded: C:\xampp\htdocs\myraportk13\application\views\template_utama.php
INFO - 2023-01-14 03:53:52 --> Final output sent to browser
DEBUG - 2023-01-14 03:53:52 --> Total execution time: 0.0369
INFO - 2023-01-14 03:56:47 --> Config Class Initialized
INFO - 2023-01-14 03:56:47 --> Hooks Class Initialized
DEBUG - 2023-01-14 03:56:47 --> UTF-8 Support Enabled
INFO - 2023-01-14 03:56:47 --> Utf8 Class Initialized
INFO - 2023-01-14 03:56:47 --> URI Class Initialized
INFO - 2023-01-14 03:56:47 --> Router Class Initialized
INFO - 2023-01-14 03:56:47 --> Output Class Initialized
INFO - 2023-01-14 03:56:47 --> Security Class Initialized
DEBUG - 2023-01-14 03:56:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-14 03:56:47 --> Input Class Initialized
INFO - 2023-01-14 03:56:47 --> Language Class Initialized
INFO - 2023-01-14 03:56:47 --> Language Class Initialized
INFO - 2023-01-14 03:56:47 --> Config Class Initialized
INFO - 2023-01-14 03:56:47 --> Loader Class Initialized
INFO - 2023-01-14 03:56:47 --> Helper loaded: url_helper
INFO - 2023-01-14 03:56:47 --> Helper loaded: file_helper
INFO - 2023-01-14 03:56:47 --> Helper loaded: form_helper
INFO - 2023-01-14 03:56:47 --> Helper loaded: my_helper
INFO - 2023-01-14 03:56:47 --> Database Driver Class Initialized
DEBUG - 2023-01-14 03:56:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-01-14 03:56:47 --> Session: Class initialized using 'files' driver.
INFO - 2023-01-14 03:56:47 --> Controller Class Initialized
DEBUG - 2023-01-14 03:56:47 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/view_mapel/views/v_view_mapel.php
DEBUG - 2023-01-14 03:56:47 --> File loaded: C:\xampp\htdocs\myraportk13\application\views\template_utama.php
INFO - 2023-01-14 03:56:47 --> Final output sent to browser
DEBUG - 2023-01-14 03:56:47 --> Total execution time: 0.0425
INFO - 2023-01-14 03:57:22 --> Config Class Initialized
INFO - 2023-01-14 03:57:22 --> Hooks Class Initialized
DEBUG - 2023-01-14 03:57:22 --> UTF-8 Support Enabled
INFO - 2023-01-14 03:57:22 --> Utf8 Class Initialized
INFO - 2023-01-14 03:57:22 --> URI Class Initialized
INFO - 2023-01-14 03:57:22 --> Router Class Initialized
INFO - 2023-01-14 03:57:22 --> Output Class Initialized
INFO - 2023-01-14 03:57:22 --> Security Class Initialized
DEBUG - 2023-01-14 03:57:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-14 03:57:22 --> Input Class Initialized
INFO - 2023-01-14 03:57:22 --> Language Class Initialized
INFO - 2023-01-14 03:57:22 --> Language Class Initialized
INFO - 2023-01-14 03:57:22 --> Config Class Initialized
INFO - 2023-01-14 03:57:22 --> Loader Class Initialized
INFO - 2023-01-14 03:57:22 --> Helper loaded: url_helper
INFO - 2023-01-14 03:57:22 --> Helper loaded: file_helper
INFO - 2023-01-14 03:57:22 --> Helper loaded: form_helper
INFO - 2023-01-14 03:57:22 --> Helper loaded: my_helper
INFO - 2023-01-14 03:57:22 --> Database Driver Class Initialized
DEBUG - 2023-01-14 03:57:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-01-14 03:57:22 --> Session: Class initialized using 'files' driver.
INFO - 2023-01-14 03:57:22 --> Controller Class Initialized
DEBUG - 2023-01-14 03:57:22 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/view_mapel/views/v_view_mapel.php
DEBUG - 2023-01-14 03:57:22 --> File loaded: C:\xampp\htdocs\myraportk13\application\views\template_utama.php
INFO - 2023-01-14 03:57:22 --> Final output sent to browser
DEBUG - 2023-01-14 03:57:22 --> Total execution time: 0.0578
INFO - 2023-01-14 03:57:33 --> Config Class Initialized
INFO - 2023-01-14 03:57:33 --> Hooks Class Initialized
DEBUG - 2023-01-14 03:57:33 --> UTF-8 Support Enabled
INFO - 2023-01-14 03:57:33 --> Utf8 Class Initialized
INFO - 2023-01-14 03:57:33 --> URI Class Initialized
INFO - 2023-01-14 03:57:33 --> Router Class Initialized
INFO - 2023-01-14 03:57:33 --> Output Class Initialized
INFO - 2023-01-14 03:57:33 --> Security Class Initialized
DEBUG - 2023-01-14 03:57:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-14 03:57:33 --> Input Class Initialized
INFO - 2023-01-14 03:57:33 --> Language Class Initialized
INFO - 2023-01-14 03:57:33 --> Language Class Initialized
INFO - 2023-01-14 03:57:33 --> Config Class Initialized
INFO - 2023-01-14 03:57:33 --> Loader Class Initialized
INFO - 2023-01-14 03:57:33 --> Helper loaded: url_helper
INFO - 2023-01-14 03:57:33 --> Helper loaded: file_helper
INFO - 2023-01-14 03:57:33 --> Helper loaded: form_helper
INFO - 2023-01-14 03:57:33 --> Helper loaded: my_helper
INFO - 2023-01-14 03:57:33 --> Database Driver Class Initialized
DEBUG - 2023-01-14 03:57:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-01-14 03:57:33 --> Session: Class initialized using 'files' driver.
INFO - 2023-01-14 03:57:33 --> Controller Class Initialized
DEBUG - 2023-01-14 03:57:33 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/view_mapel/views/v_view_mapel.php
DEBUG - 2023-01-14 03:57:33 --> File loaded: C:\xampp\htdocs\myraportk13\application\views\template_utama.php
INFO - 2023-01-14 03:57:33 --> Final output sent to browser
DEBUG - 2023-01-14 03:57:33 --> Total execution time: 0.0575
INFO - 2023-01-14 03:57:44 --> Config Class Initialized
INFO - 2023-01-14 03:57:44 --> Hooks Class Initialized
DEBUG - 2023-01-14 03:57:44 --> UTF-8 Support Enabled
INFO - 2023-01-14 03:57:44 --> Utf8 Class Initialized
INFO - 2023-01-14 03:57:44 --> URI Class Initialized
INFO - 2023-01-14 03:57:44 --> Router Class Initialized
INFO - 2023-01-14 03:57:44 --> Output Class Initialized
INFO - 2023-01-14 03:57:44 --> Security Class Initialized
DEBUG - 2023-01-14 03:57:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-14 03:57:44 --> Input Class Initialized
INFO - 2023-01-14 03:57:44 --> Language Class Initialized
INFO - 2023-01-14 03:57:44 --> Language Class Initialized
INFO - 2023-01-14 03:57:44 --> Config Class Initialized
INFO - 2023-01-14 03:57:44 --> Loader Class Initialized
INFO - 2023-01-14 03:57:44 --> Helper loaded: url_helper
INFO - 2023-01-14 03:57:44 --> Helper loaded: file_helper
INFO - 2023-01-14 03:57:44 --> Helper loaded: form_helper
INFO - 2023-01-14 03:57:44 --> Helper loaded: my_helper
INFO - 2023-01-14 03:57:44 --> Database Driver Class Initialized
DEBUG - 2023-01-14 03:57:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-01-14 03:57:44 --> Session: Class initialized using 'files' driver.
INFO - 2023-01-14 03:57:44 --> Controller Class Initialized
INFO - 2023-01-14 03:57:44 --> Helper loaded: cookie_helper
INFO - 2023-01-14 03:57:44 --> Config Class Initialized
INFO - 2023-01-14 03:57:44 --> Hooks Class Initialized
DEBUG - 2023-01-14 03:57:44 --> UTF-8 Support Enabled
INFO - 2023-01-14 03:57:44 --> Utf8 Class Initialized
INFO - 2023-01-14 03:57:44 --> URI Class Initialized
INFO - 2023-01-14 03:57:44 --> Router Class Initialized
INFO - 2023-01-14 03:57:44 --> Output Class Initialized
INFO - 2023-01-14 03:57:44 --> Security Class Initialized
DEBUG - 2023-01-14 03:57:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-14 03:57:44 --> Input Class Initialized
INFO - 2023-01-14 03:57:44 --> Language Class Initialized
INFO - 2023-01-14 03:57:44 --> Language Class Initialized
INFO - 2023-01-14 03:57:44 --> Config Class Initialized
INFO - 2023-01-14 03:57:44 --> Loader Class Initialized
INFO - 2023-01-14 03:57:44 --> Helper loaded: url_helper
INFO - 2023-01-14 03:57:44 --> Helper loaded: file_helper
INFO - 2023-01-14 03:57:44 --> Helper loaded: form_helper
INFO - 2023-01-14 03:57:44 --> Helper loaded: my_helper
INFO - 2023-01-14 03:57:44 --> Database Driver Class Initialized
DEBUG - 2023-01-14 03:57:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-01-14 03:57:44 --> Session: Class initialized using 'files' driver.
INFO - 2023-01-14 03:57:44 --> Controller Class Initialized
INFO - 2023-01-14 03:57:45 --> Config Class Initialized
INFO - 2023-01-14 03:57:45 --> Hooks Class Initialized
DEBUG - 2023-01-14 03:57:45 --> UTF-8 Support Enabled
INFO - 2023-01-14 03:57:45 --> Utf8 Class Initialized
INFO - 2023-01-14 03:57:45 --> URI Class Initialized
INFO - 2023-01-14 03:57:45 --> Router Class Initialized
INFO - 2023-01-14 03:57:45 --> Output Class Initialized
INFO - 2023-01-14 03:57:45 --> Security Class Initialized
DEBUG - 2023-01-14 03:57:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-14 03:57:45 --> Input Class Initialized
INFO - 2023-01-14 03:57:45 --> Language Class Initialized
INFO - 2023-01-14 03:57:45 --> Language Class Initialized
INFO - 2023-01-14 03:57:45 --> Config Class Initialized
INFO - 2023-01-14 03:57:45 --> Loader Class Initialized
INFO - 2023-01-14 03:57:45 --> Helper loaded: url_helper
INFO - 2023-01-14 03:57:45 --> Helper loaded: file_helper
INFO - 2023-01-14 03:57:45 --> Helper loaded: form_helper
INFO - 2023-01-14 03:57:45 --> Helper loaded: my_helper
INFO - 2023-01-14 03:57:45 --> Database Driver Class Initialized
DEBUG - 2023-01-14 03:57:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-01-14 03:57:45 --> Session: Class initialized using 'files' driver.
INFO - 2023-01-14 03:57:45 --> Controller Class Initialized
DEBUG - 2023-01-14 03:57:45 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/login/views/login.php
DEBUG - 2023-01-14 03:57:45 --> File loaded: C:\xampp\htdocs\myraportk13\application\views\template_utama.php
INFO - 2023-01-14 03:57:45 --> Final output sent to browser
DEBUG - 2023-01-14 03:57:45 --> Total execution time: 0.0325
INFO - 2023-01-14 03:57:51 --> Config Class Initialized
INFO - 2023-01-14 03:57:51 --> Hooks Class Initialized
DEBUG - 2023-01-14 03:57:51 --> UTF-8 Support Enabled
INFO - 2023-01-14 03:57:51 --> Utf8 Class Initialized
INFO - 2023-01-14 03:57:51 --> URI Class Initialized
INFO - 2023-01-14 03:57:51 --> Router Class Initialized
INFO - 2023-01-14 03:57:51 --> Output Class Initialized
INFO - 2023-01-14 03:57:51 --> Security Class Initialized
DEBUG - 2023-01-14 03:57:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-14 03:57:51 --> Input Class Initialized
INFO - 2023-01-14 03:57:51 --> Language Class Initialized
INFO - 2023-01-14 03:57:51 --> Language Class Initialized
INFO - 2023-01-14 03:57:51 --> Config Class Initialized
INFO - 2023-01-14 03:57:51 --> Loader Class Initialized
INFO - 2023-01-14 03:57:51 --> Helper loaded: url_helper
INFO - 2023-01-14 03:57:51 --> Helper loaded: file_helper
INFO - 2023-01-14 03:57:51 --> Helper loaded: form_helper
INFO - 2023-01-14 03:57:51 --> Helper loaded: my_helper
INFO - 2023-01-14 03:57:51 --> Database Driver Class Initialized
DEBUG - 2023-01-14 03:57:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-01-14 03:57:51 --> Session: Class initialized using 'files' driver.
INFO - 2023-01-14 03:57:51 --> Controller Class Initialized
INFO - 2023-01-14 03:57:51 --> Helper loaded: cookie_helper
INFO - 2023-01-14 03:57:51 --> Final output sent to browser
DEBUG - 2023-01-14 03:57:51 --> Total execution time: 0.0397
INFO - 2023-01-14 03:57:51 --> Config Class Initialized
INFO - 2023-01-14 03:57:51 --> Hooks Class Initialized
DEBUG - 2023-01-14 03:57:51 --> UTF-8 Support Enabled
INFO - 2023-01-14 03:57:51 --> Utf8 Class Initialized
INFO - 2023-01-14 03:57:51 --> URI Class Initialized
INFO - 2023-01-14 03:57:51 --> Router Class Initialized
INFO - 2023-01-14 03:57:51 --> Output Class Initialized
INFO - 2023-01-14 03:57:51 --> Security Class Initialized
DEBUG - 2023-01-14 03:57:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-14 03:57:51 --> Input Class Initialized
INFO - 2023-01-14 03:57:51 --> Language Class Initialized
INFO - 2023-01-14 03:57:51 --> Language Class Initialized
INFO - 2023-01-14 03:57:51 --> Config Class Initialized
INFO - 2023-01-14 03:57:51 --> Loader Class Initialized
INFO - 2023-01-14 03:57:51 --> Helper loaded: url_helper
INFO - 2023-01-14 03:57:51 --> Helper loaded: file_helper
INFO - 2023-01-14 03:57:51 --> Helper loaded: form_helper
INFO - 2023-01-14 03:57:51 --> Helper loaded: my_helper
INFO - 2023-01-14 03:57:51 --> Database Driver Class Initialized
DEBUG - 2023-01-14 03:57:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-01-14 03:57:51 --> Session: Class initialized using 'files' driver.
INFO - 2023-01-14 03:57:51 --> Controller Class Initialized
DEBUG - 2023-01-14 03:57:51 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/home/views/v_home.php
DEBUG - 2023-01-14 03:57:51 --> File loaded: C:\xampp\htdocs\myraportk13\application\views\template_utama.php
INFO - 2023-01-14 03:57:51 --> Final output sent to browser
DEBUG - 2023-01-14 03:57:51 --> Total execution time: 0.0626
INFO - 2023-01-14 03:57:53 --> Config Class Initialized
INFO - 2023-01-14 03:57:53 --> Hooks Class Initialized
DEBUG - 2023-01-14 03:57:53 --> UTF-8 Support Enabled
INFO - 2023-01-14 03:57:53 --> Utf8 Class Initialized
INFO - 2023-01-14 03:57:53 --> URI Class Initialized
INFO - 2023-01-14 03:57:53 --> Router Class Initialized
INFO - 2023-01-14 03:57:53 --> Output Class Initialized
INFO - 2023-01-14 03:57:53 --> Security Class Initialized
DEBUG - 2023-01-14 03:57:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-14 03:57:53 --> Input Class Initialized
INFO - 2023-01-14 03:57:53 --> Language Class Initialized
INFO - 2023-01-14 03:57:53 --> Language Class Initialized
INFO - 2023-01-14 03:57:53 --> Config Class Initialized
INFO - 2023-01-14 03:57:53 --> Loader Class Initialized
INFO - 2023-01-14 03:57:53 --> Helper loaded: url_helper
INFO - 2023-01-14 03:57:53 --> Helper loaded: file_helper
INFO - 2023-01-14 03:57:53 --> Helper loaded: form_helper
INFO - 2023-01-14 03:57:53 --> Helper loaded: my_helper
INFO - 2023-01-14 03:57:53 --> Database Driver Class Initialized
DEBUG - 2023-01-14 03:57:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-01-14 03:57:53 --> Session: Class initialized using 'files' driver.
INFO - 2023-01-14 03:57:53 --> Controller Class Initialized
DEBUG - 2023-01-14 03:57:53 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/data_guru/views/list.php
DEBUG - 2023-01-14 03:57:53 --> File loaded: C:\xampp\htdocs\myraportk13\application\views\template_utama.php
INFO - 2023-01-14 03:57:53 --> Final output sent to browser
DEBUG - 2023-01-14 03:57:53 --> Total execution time: 0.0845
INFO - 2023-01-14 03:57:53 --> Config Class Initialized
INFO - 2023-01-14 03:57:53 --> Hooks Class Initialized
DEBUG - 2023-01-14 03:57:53 --> UTF-8 Support Enabled
INFO - 2023-01-14 03:57:53 --> Utf8 Class Initialized
INFO - 2023-01-14 03:57:53 --> URI Class Initialized
INFO - 2023-01-14 03:57:53 --> Router Class Initialized
INFO - 2023-01-14 03:57:53 --> Output Class Initialized
INFO - 2023-01-14 03:57:53 --> Security Class Initialized
DEBUG - 2023-01-14 03:57:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-14 03:57:53 --> Input Class Initialized
INFO - 2023-01-14 03:57:53 --> Language Class Initialized
INFO - 2023-01-14 03:57:53 --> Language Class Initialized
INFO - 2023-01-14 03:57:53 --> Config Class Initialized
INFO - 2023-01-14 03:57:53 --> Loader Class Initialized
INFO - 2023-01-14 03:57:53 --> Helper loaded: url_helper
INFO - 2023-01-14 03:57:53 --> Helper loaded: file_helper
INFO - 2023-01-14 03:57:53 --> Helper loaded: form_helper
INFO - 2023-01-14 03:57:53 --> Helper loaded: my_helper
INFO - 2023-01-14 03:57:53 --> Database Driver Class Initialized
DEBUG - 2023-01-14 03:57:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-01-14 03:57:53 --> Session: Class initialized using 'files' driver.
INFO - 2023-01-14 03:57:53 --> Controller Class Initialized
INFO - 2023-01-14 03:57:54 --> Config Class Initialized
INFO - 2023-01-14 03:57:54 --> Hooks Class Initialized
DEBUG - 2023-01-14 03:57:54 --> UTF-8 Support Enabled
INFO - 2023-01-14 03:57:54 --> Utf8 Class Initialized
INFO - 2023-01-14 03:57:54 --> URI Class Initialized
INFO - 2023-01-14 03:57:54 --> Router Class Initialized
INFO - 2023-01-14 03:57:54 --> Output Class Initialized
INFO - 2023-01-14 03:57:54 --> Security Class Initialized
DEBUG - 2023-01-14 03:57:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-14 03:57:54 --> Input Class Initialized
INFO - 2023-01-14 03:57:54 --> Language Class Initialized
INFO - 2023-01-14 03:57:54 --> Language Class Initialized
INFO - 2023-01-14 03:57:54 --> Config Class Initialized
INFO - 2023-01-14 03:57:54 --> Loader Class Initialized
INFO - 2023-01-14 03:57:54 --> Helper loaded: url_helper
INFO - 2023-01-14 03:57:54 --> Helper loaded: file_helper
INFO - 2023-01-14 03:57:54 --> Helper loaded: form_helper
INFO - 2023-01-14 03:57:54 --> Helper loaded: my_helper
INFO - 2023-01-14 03:57:54 --> Database Driver Class Initialized
DEBUG - 2023-01-14 03:57:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-01-14 03:57:54 --> Session: Class initialized using 'files' driver.
INFO - 2023-01-14 03:57:54 --> Controller Class Initialized
DEBUG - 2023-01-14 03:57:54 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/data_kelas/views/list.php
DEBUG - 2023-01-14 03:57:54 --> File loaded: C:\xampp\htdocs\myraportk13\application\views\template_utama.php
INFO - 2023-01-14 03:57:54 --> Final output sent to browser
DEBUG - 2023-01-14 03:57:54 --> Total execution time: 0.0703
INFO - 2023-01-14 03:57:54 --> Config Class Initialized
INFO - 2023-01-14 03:57:54 --> Hooks Class Initialized
DEBUG - 2023-01-14 03:57:54 --> UTF-8 Support Enabled
INFO - 2023-01-14 03:57:54 --> Utf8 Class Initialized
INFO - 2023-01-14 03:57:54 --> URI Class Initialized
INFO - 2023-01-14 03:57:54 --> Router Class Initialized
INFO - 2023-01-14 03:57:54 --> Output Class Initialized
INFO - 2023-01-14 03:57:54 --> Security Class Initialized
DEBUG - 2023-01-14 03:57:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-14 03:57:54 --> Input Class Initialized
INFO - 2023-01-14 03:57:54 --> Language Class Initialized
INFO - 2023-01-14 03:57:54 --> Language Class Initialized
INFO - 2023-01-14 03:57:54 --> Config Class Initialized
INFO - 2023-01-14 03:57:54 --> Loader Class Initialized
INFO - 2023-01-14 03:57:54 --> Helper loaded: url_helper
INFO - 2023-01-14 03:57:54 --> Helper loaded: file_helper
INFO - 2023-01-14 03:57:54 --> Helper loaded: form_helper
INFO - 2023-01-14 03:57:54 --> Helper loaded: my_helper
INFO - 2023-01-14 03:57:54 --> Database Driver Class Initialized
DEBUG - 2023-01-14 03:57:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-01-14 03:57:54 --> Session: Class initialized using 'files' driver.
INFO - 2023-01-14 03:57:54 --> Controller Class Initialized
INFO - 2023-01-14 03:57:56 --> Config Class Initialized
INFO - 2023-01-14 03:57:56 --> Hooks Class Initialized
DEBUG - 2023-01-14 03:57:56 --> UTF-8 Support Enabled
INFO - 2023-01-14 03:57:56 --> Utf8 Class Initialized
INFO - 2023-01-14 03:57:56 --> URI Class Initialized
INFO - 2023-01-14 03:57:56 --> Router Class Initialized
INFO - 2023-01-14 03:57:56 --> Output Class Initialized
INFO - 2023-01-14 03:57:56 --> Security Class Initialized
DEBUG - 2023-01-14 03:57:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-14 03:57:56 --> Input Class Initialized
INFO - 2023-01-14 03:57:56 --> Language Class Initialized
INFO - 2023-01-14 03:57:56 --> Language Class Initialized
INFO - 2023-01-14 03:57:56 --> Config Class Initialized
INFO - 2023-01-14 03:57:56 --> Loader Class Initialized
INFO - 2023-01-14 03:57:56 --> Helper loaded: url_helper
INFO - 2023-01-14 03:57:56 --> Helper loaded: file_helper
INFO - 2023-01-14 03:57:56 --> Helper loaded: form_helper
INFO - 2023-01-14 03:57:56 --> Helper loaded: my_helper
INFO - 2023-01-14 03:57:56 --> Database Driver Class Initialized
DEBUG - 2023-01-14 03:57:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-01-14 03:57:56 --> Session: Class initialized using 'files' driver.
INFO - 2023-01-14 03:57:56 --> Controller Class Initialized
DEBUG - 2023-01-14 03:57:56 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/data_mapel/views/list.php
DEBUG - 2023-01-14 03:57:56 --> File loaded: C:\xampp\htdocs\myraportk13\application\views\template_utama.php
INFO - 2023-01-14 03:57:56 --> Final output sent to browser
DEBUG - 2023-01-14 03:57:56 --> Total execution time: 0.0546
INFO - 2023-01-14 03:57:56 --> Config Class Initialized
INFO - 2023-01-14 03:57:56 --> Hooks Class Initialized
DEBUG - 2023-01-14 03:57:56 --> UTF-8 Support Enabled
INFO - 2023-01-14 03:57:56 --> Utf8 Class Initialized
INFO - 2023-01-14 03:57:56 --> URI Class Initialized
INFO - 2023-01-14 03:57:56 --> Router Class Initialized
INFO - 2023-01-14 03:57:56 --> Output Class Initialized
INFO - 2023-01-14 03:57:56 --> Security Class Initialized
DEBUG - 2023-01-14 03:57:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-14 03:57:56 --> Input Class Initialized
INFO - 2023-01-14 03:57:56 --> Language Class Initialized
INFO - 2023-01-14 03:57:56 --> Language Class Initialized
INFO - 2023-01-14 03:57:56 --> Config Class Initialized
INFO - 2023-01-14 03:57:56 --> Loader Class Initialized
INFO - 2023-01-14 03:57:56 --> Helper loaded: url_helper
INFO - 2023-01-14 03:57:56 --> Helper loaded: file_helper
INFO - 2023-01-14 03:57:56 --> Helper loaded: form_helper
INFO - 2023-01-14 03:57:56 --> Helper loaded: my_helper
INFO - 2023-01-14 03:57:56 --> Database Driver Class Initialized
DEBUG - 2023-01-14 03:57:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-01-14 03:57:56 --> Session: Class initialized using 'files' driver.
INFO - 2023-01-14 03:57:56 --> Controller Class Initialized
INFO - 2023-01-14 03:57:58 --> Config Class Initialized
INFO - 2023-01-14 03:57:58 --> Hooks Class Initialized
DEBUG - 2023-01-14 03:57:58 --> UTF-8 Support Enabled
INFO - 2023-01-14 03:57:58 --> Utf8 Class Initialized
INFO - 2023-01-14 03:57:58 --> URI Class Initialized
INFO - 2023-01-14 03:57:58 --> Router Class Initialized
INFO - 2023-01-14 03:57:58 --> Output Class Initialized
INFO - 2023-01-14 03:57:58 --> Security Class Initialized
DEBUG - 2023-01-14 03:57:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-14 03:57:58 --> Input Class Initialized
INFO - 2023-01-14 03:57:58 --> Language Class Initialized
INFO - 2023-01-14 03:57:58 --> Language Class Initialized
INFO - 2023-01-14 03:57:58 --> Config Class Initialized
INFO - 2023-01-14 03:57:58 --> Loader Class Initialized
INFO - 2023-01-14 03:57:58 --> Helper loaded: url_helper
INFO - 2023-01-14 03:57:58 --> Helper loaded: file_helper
INFO - 2023-01-14 03:57:58 --> Helper loaded: form_helper
INFO - 2023-01-14 03:57:58 --> Helper loaded: my_helper
INFO - 2023-01-14 03:57:58 --> Database Driver Class Initialized
DEBUG - 2023-01-14 03:57:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-01-14 03:57:58 --> Session: Class initialized using 'files' driver.
INFO - 2023-01-14 03:57:58 --> Controller Class Initialized
INFO - 2023-01-14 03:57:58 --> Final output sent to browser
DEBUG - 2023-01-14 03:57:58 --> Total execution time: 0.0564
INFO - 2023-01-14 03:58:08 --> Config Class Initialized
INFO - 2023-01-14 03:58:08 --> Hooks Class Initialized
DEBUG - 2023-01-14 03:58:08 --> UTF-8 Support Enabled
INFO - 2023-01-14 03:58:08 --> Utf8 Class Initialized
INFO - 2023-01-14 03:58:08 --> URI Class Initialized
INFO - 2023-01-14 03:58:08 --> Router Class Initialized
INFO - 2023-01-14 03:58:08 --> Output Class Initialized
INFO - 2023-01-14 03:58:08 --> Security Class Initialized
DEBUG - 2023-01-14 03:58:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-14 03:58:08 --> Input Class Initialized
INFO - 2023-01-14 03:58:08 --> Language Class Initialized
INFO - 2023-01-14 03:58:08 --> Language Class Initialized
INFO - 2023-01-14 03:58:08 --> Config Class Initialized
INFO - 2023-01-14 03:58:08 --> Loader Class Initialized
INFO - 2023-01-14 03:58:08 --> Helper loaded: url_helper
INFO - 2023-01-14 03:58:08 --> Helper loaded: file_helper
INFO - 2023-01-14 03:58:08 --> Helper loaded: form_helper
INFO - 2023-01-14 03:58:08 --> Helper loaded: my_helper
INFO - 2023-01-14 03:58:08 --> Database Driver Class Initialized
DEBUG - 2023-01-14 03:58:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-01-14 03:58:08 --> Session: Class initialized using 'files' driver.
INFO - 2023-01-14 03:58:08 --> Controller Class Initialized
INFO - 2023-01-14 03:58:08 --> Final output sent to browser
DEBUG - 2023-01-14 03:58:08 --> Total execution time: 0.0384
INFO - 2023-01-14 03:58:08 --> Config Class Initialized
INFO - 2023-01-14 03:58:08 --> Hooks Class Initialized
DEBUG - 2023-01-14 03:58:08 --> UTF-8 Support Enabled
INFO - 2023-01-14 03:58:08 --> Utf8 Class Initialized
INFO - 2023-01-14 03:58:08 --> URI Class Initialized
INFO - 2023-01-14 03:58:08 --> Router Class Initialized
INFO - 2023-01-14 03:58:08 --> Output Class Initialized
INFO - 2023-01-14 03:58:08 --> Security Class Initialized
DEBUG - 2023-01-14 03:58:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-14 03:58:08 --> Input Class Initialized
INFO - 2023-01-14 03:58:08 --> Language Class Initialized
INFO - 2023-01-14 03:58:08 --> Language Class Initialized
INFO - 2023-01-14 03:58:08 --> Config Class Initialized
INFO - 2023-01-14 03:58:08 --> Loader Class Initialized
INFO - 2023-01-14 03:58:08 --> Helper loaded: url_helper
INFO - 2023-01-14 03:58:08 --> Helper loaded: file_helper
INFO - 2023-01-14 03:58:08 --> Helper loaded: form_helper
INFO - 2023-01-14 03:58:08 --> Helper loaded: my_helper
INFO - 2023-01-14 03:58:08 --> Database Driver Class Initialized
DEBUG - 2023-01-14 03:58:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-01-14 03:58:08 --> Session: Class initialized using 'files' driver.
INFO - 2023-01-14 03:58:08 --> Controller Class Initialized
INFO - 2023-01-14 03:58:10 --> Config Class Initialized
INFO - 2023-01-14 03:58:10 --> Hooks Class Initialized
DEBUG - 2023-01-14 03:58:10 --> UTF-8 Support Enabled
INFO - 2023-01-14 03:58:10 --> Utf8 Class Initialized
INFO - 2023-01-14 03:58:10 --> URI Class Initialized
INFO - 2023-01-14 03:58:10 --> Router Class Initialized
INFO - 2023-01-14 03:58:10 --> Output Class Initialized
INFO - 2023-01-14 03:58:10 --> Security Class Initialized
DEBUG - 2023-01-14 03:58:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-14 03:58:10 --> Input Class Initialized
INFO - 2023-01-14 03:58:10 --> Language Class Initialized
INFO - 2023-01-14 03:58:10 --> Language Class Initialized
INFO - 2023-01-14 03:58:10 --> Config Class Initialized
INFO - 2023-01-14 03:58:10 --> Loader Class Initialized
INFO - 2023-01-14 03:58:10 --> Helper loaded: url_helper
INFO - 2023-01-14 03:58:10 --> Helper loaded: file_helper
INFO - 2023-01-14 03:58:10 --> Helper loaded: form_helper
INFO - 2023-01-14 03:58:10 --> Helper loaded: my_helper
INFO - 2023-01-14 03:58:10 --> Database Driver Class Initialized
DEBUG - 2023-01-14 03:58:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-01-14 03:58:10 --> Session: Class initialized using 'files' driver.
INFO - 2023-01-14 03:58:10 --> Controller Class Initialized
INFO - 2023-01-14 03:58:10 --> Final output sent to browser
DEBUG - 2023-01-14 03:58:10 --> Total execution time: 0.0566
INFO - 2023-01-14 03:58:32 --> Config Class Initialized
INFO - 2023-01-14 03:58:32 --> Hooks Class Initialized
DEBUG - 2023-01-14 03:58:32 --> UTF-8 Support Enabled
INFO - 2023-01-14 03:58:32 --> Utf8 Class Initialized
INFO - 2023-01-14 03:58:32 --> URI Class Initialized
INFO - 2023-01-14 03:58:32 --> Router Class Initialized
INFO - 2023-01-14 03:58:32 --> Output Class Initialized
INFO - 2023-01-14 03:58:32 --> Security Class Initialized
DEBUG - 2023-01-14 03:58:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-14 03:58:32 --> Input Class Initialized
INFO - 2023-01-14 03:58:32 --> Language Class Initialized
INFO - 2023-01-14 03:58:32 --> Language Class Initialized
INFO - 2023-01-14 03:58:32 --> Config Class Initialized
INFO - 2023-01-14 03:58:32 --> Loader Class Initialized
INFO - 2023-01-14 03:58:32 --> Helper loaded: url_helper
INFO - 2023-01-14 03:58:32 --> Helper loaded: file_helper
INFO - 2023-01-14 03:58:32 --> Helper loaded: form_helper
INFO - 2023-01-14 03:58:32 --> Helper loaded: my_helper
INFO - 2023-01-14 03:58:32 --> Database Driver Class Initialized
DEBUG - 2023-01-14 03:58:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-01-14 03:58:32 --> Session: Class initialized using 'files' driver.
INFO - 2023-01-14 03:58:32 --> Controller Class Initialized
INFO - 2023-01-14 03:58:32 --> Final output sent to browser
DEBUG - 2023-01-14 03:58:32 --> Total execution time: 0.0510
INFO - 2023-01-14 03:58:32 --> Config Class Initialized
INFO - 2023-01-14 03:58:32 --> Hooks Class Initialized
DEBUG - 2023-01-14 03:58:32 --> UTF-8 Support Enabled
INFO - 2023-01-14 03:58:32 --> Utf8 Class Initialized
INFO - 2023-01-14 03:58:32 --> URI Class Initialized
INFO - 2023-01-14 03:58:32 --> Router Class Initialized
INFO - 2023-01-14 03:58:32 --> Output Class Initialized
INFO - 2023-01-14 03:58:32 --> Security Class Initialized
DEBUG - 2023-01-14 03:58:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-14 03:58:32 --> Input Class Initialized
INFO - 2023-01-14 03:58:32 --> Language Class Initialized
INFO - 2023-01-14 03:58:32 --> Language Class Initialized
INFO - 2023-01-14 03:58:32 --> Config Class Initialized
INFO - 2023-01-14 03:58:32 --> Loader Class Initialized
INFO - 2023-01-14 03:58:32 --> Helper loaded: url_helper
INFO - 2023-01-14 03:58:32 --> Helper loaded: file_helper
INFO - 2023-01-14 03:58:32 --> Helper loaded: form_helper
INFO - 2023-01-14 03:58:32 --> Helper loaded: my_helper
INFO - 2023-01-14 03:58:32 --> Database Driver Class Initialized
DEBUG - 2023-01-14 03:58:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-01-14 03:58:32 --> Session: Class initialized using 'files' driver.
INFO - 2023-01-14 03:58:32 --> Controller Class Initialized
INFO - 2023-01-14 03:58:45 --> Config Class Initialized
INFO - 2023-01-14 03:58:45 --> Hooks Class Initialized
DEBUG - 2023-01-14 03:58:45 --> UTF-8 Support Enabled
INFO - 2023-01-14 03:58:45 --> Utf8 Class Initialized
INFO - 2023-01-14 03:58:45 --> URI Class Initialized
INFO - 2023-01-14 03:58:45 --> Router Class Initialized
INFO - 2023-01-14 03:58:45 --> Output Class Initialized
INFO - 2023-01-14 03:58:45 --> Security Class Initialized
DEBUG - 2023-01-14 03:58:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-14 03:58:45 --> Input Class Initialized
INFO - 2023-01-14 03:58:45 --> Language Class Initialized
INFO - 2023-01-14 03:58:45 --> Language Class Initialized
INFO - 2023-01-14 03:58:45 --> Config Class Initialized
INFO - 2023-01-14 03:58:45 --> Loader Class Initialized
INFO - 2023-01-14 03:58:45 --> Helper loaded: url_helper
INFO - 2023-01-14 03:58:45 --> Helper loaded: file_helper
INFO - 2023-01-14 03:58:45 --> Helper loaded: form_helper
INFO - 2023-01-14 03:58:45 --> Helper loaded: my_helper
INFO - 2023-01-14 03:58:45 --> Database Driver Class Initialized
DEBUG - 2023-01-14 03:58:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-01-14 03:58:45 --> Session: Class initialized using 'files' driver.
INFO - 2023-01-14 03:58:45 --> Controller Class Initialized
DEBUG - 2023-01-14 03:58:45 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/set_kelas/views/list.php
DEBUG - 2023-01-14 03:58:45 --> File loaded: C:\xampp\htdocs\myraportk13\application\views\template_utama.php
INFO - 2023-01-14 03:58:45 --> Final output sent to browser
DEBUG - 2023-01-14 03:58:45 --> Total execution time: 0.0707
INFO - 2023-01-14 03:58:48 --> Config Class Initialized
INFO - 2023-01-14 03:58:48 --> Hooks Class Initialized
DEBUG - 2023-01-14 03:58:48 --> UTF-8 Support Enabled
INFO - 2023-01-14 03:58:48 --> Utf8 Class Initialized
INFO - 2023-01-14 03:58:48 --> URI Class Initialized
INFO - 2023-01-14 03:58:48 --> Router Class Initialized
INFO - 2023-01-14 03:58:48 --> Output Class Initialized
INFO - 2023-01-14 03:58:48 --> Security Class Initialized
DEBUG - 2023-01-14 03:58:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-14 03:58:48 --> Input Class Initialized
INFO - 2023-01-14 03:58:48 --> Language Class Initialized
INFO - 2023-01-14 03:58:48 --> Language Class Initialized
INFO - 2023-01-14 03:58:48 --> Config Class Initialized
INFO - 2023-01-14 03:58:48 --> Loader Class Initialized
INFO - 2023-01-14 03:58:48 --> Helper loaded: url_helper
INFO - 2023-01-14 03:58:48 --> Helper loaded: file_helper
INFO - 2023-01-14 03:58:48 --> Helper loaded: form_helper
INFO - 2023-01-14 03:58:48 --> Helper loaded: my_helper
INFO - 2023-01-14 03:58:48 --> Database Driver Class Initialized
DEBUG - 2023-01-14 03:58:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-01-14 03:58:48 --> Session: Class initialized using 'files' driver.
INFO - 2023-01-14 03:58:48 --> Controller Class Initialized
DEBUG - 2023-01-14 03:58:48 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/set_walikelas/views/list.php
DEBUG - 2023-01-14 03:58:48 --> File loaded: C:\xampp\htdocs\myraportk13\application\views\template_utama.php
INFO - 2023-01-14 03:58:48 --> Final output sent to browser
DEBUG - 2023-01-14 03:58:48 --> Total execution time: 0.0887
INFO - 2023-01-14 03:58:48 --> Config Class Initialized
INFO - 2023-01-14 03:58:48 --> Hooks Class Initialized
DEBUG - 2023-01-14 03:58:48 --> UTF-8 Support Enabled
INFO - 2023-01-14 03:58:48 --> Utf8 Class Initialized
INFO - 2023-01-14 03:58:48 --> URI Class Initialized
INFO - 2023-01-14 03:58:48 --> Router Class Initialized
INFO - 2023-01-14 03:58:48 --> Output Class Initialized
INFO - 2023-01-14 03:58:48 --> Security Class Initialized
DEBUG - 2023-01-14 03:58:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-14 03:58:48 --> Input Class Initialized
INFO - 2023-01-14 03:58:48 --> Language Class Initialized
INFO - 2023-01-14 03:58:48 --> Language Class Initialized
INFO - 2023-01-14 03:58:48 --> Config Class Initialized
INFO - 2023-01-14 03:58:48 --> Loader Class Initialized
INFO - 2023-01-14 03:58:48 --> Helper loaded: url_helper
INFO - 2023-01-14 03:58:48 --> Helper loaded: file_helper
INFO - 2023-01-14 03:58:48 --> Helper loaded: form_helper
INFO - 2023-01-14 03:58:48 --> Helper loaded: my_helper
INFO - 2023-01-14 03:58:48 --> Database Driver Class Initialized
DEBUG - 2023-01-14 03:58:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-01-14 03:58:48 --> Session: Class initialized using 'files' driver.
INFO - 2023-01-14 03:58:48 --> Controller Class Initialized
INFO - 2023-01-14 03:58:50 --> Config Class Initialized
INFO - 2023-01-14 03:58:50 --> Hooks Class Initialized
DEBUG - 2023-01-14 03:58:50 --> UTF-8 Support Enabled
INFO - 2023-01-14 03:58:50 --> Utf8 Class Initialized
INFO - 2023-01-14 03:58:50 --> URI Class Initialized
INFO - 2023-01-14 03:58:50 --> Router Class Initialized
INFO - 2023-01-14 03:58:50 --> Output Class Initialized
INFO - 2023-01-14 03:58:50 --> Security Class Initialized
DEBUG - 2023-01-14 03:58:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-14 03:58:50 --> Input Class Initialized
INFO - 2023-01-14 03:58:50 --> Language Class Initialized
INFO - 2023-01-14 03:58:50 --> Language Class Initialized
INFO - 2023-01-14 03:58:50 --> Config Class Initialized
INFO - 2023-01-14 03:58:50 --> Loader Class Initialized
INFO - 2023-01-14 03:58:50 --> Helper loaded: url_helper
INFO - 2023-01-14 03:58:50 --> Helper loaded: file_helper
INFO - 2023-01-14 03:58:50 --> Helper loaded: form_helper
INFO - 2023-01-14 03:58:50 --> Helper loaded: my_helper
INFO - 2023-01-14 03:58:50 --> Database Driver Class Initialized
DEBUG - 2023-01-14 03:58:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-01-14 03:58:50 --> Session: Class initialized using 'files' driver.
INFO - 2023-01-14 03:58:50 --> Controller Class Initialized
DEBUG - 2023-01-14 03:58:50 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/set_mapel/views/list.php
DEBUG - 2023-01-14 03:58:50 --> File loaded: C:\xampp\htdocs\myraportk13\application\views\template_utama.php
INFO - 2023-01-14 03:58:50 --> Final output sent to browser
DEBUG - 2023-01-14 03:58:50 --> Total execution time: 0.0635
INFO - 2023-01-14 03:58:50 --> Config Class Initialized
INFO - 2023-01-14 03:58:50 --> Hooks Class Initialized
DEBUG - 2023-01-14 03:58:50 --> UTF-8 Support Enabled
INFO - 2023-01-14 03:58:50 --> Utf8 Class Initialized
INFO - 2023-01-14 03:58:50 --> URI Class Initialized
INFO - 2023-01-14 03:58:50 --> Router Class Initialized
INFO - 2023-01-14 03:58:50 --> Output Class Initialized
INFO - 2023-01-14 03:58:50 --> Security Class Initialized
DEBUG - 2023-01-14 03:58:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-14 03:58:50 --> Input Class Initialized
INFO - 2023-01-14 03:58:50 --> Language Class Initialized
INFO - 2023-01-14 03:58:50 --> Language Class Initialized
INFO - 2023-01-14 03:58:50 --> Config Class Initialized
INFO - 2023-01-14 03:58:50 --> Loader Class Initialized
INFO - 2023-01-14 03:58:50 --> Helper loaded: url_helper
INFO - 2023-01-14 03:58:50 --> Helper loaded: file_helper
INFO - 2023-01-14 03:58:50 --> Helper loaded: form_helper
INFO - 2023-01-14 03:58:50 --> Helper loaded: my_helper
INFO - 2023-01-14 03:58:50 --> Database Driver Class Initialized
DEBUG - 2023-01-14 03:58:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-01-14 03:58:50 --> Session: Class initialized using 'files' driver.
INFO - 2023-01-14 03:58:50 --> Controller Class Initialized
INFO - 2023-01-14 03:58:53 --> Config Class Initialized
INFO - 2023-01-14 03:58:53 --> Hooks Class Initialized
DEBUG - 2023-01-14 03:58:53 --> UTF-8 Support Enabled
INFO - 2023-01-14 03:58:53 --> Utf8 Class Initialized
INFO - 2023-01-14 03:58:53 --> URI Class Initialized
INFO - 2023-01-14 03:58:53 --> Router Class Initialized
INFO - 2023-01-14 03:58:53 --> Output Class Initialized
INFO - 2023-01-14 03:58:53 --> Security Class Initialized
DEBUG - 2023-01-14 03:58:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-14 03:58:53 --> Input Class Initialized
INFO - 2023-01-14 03:58:53 --> Language Class Initialized
INFO - 2023-01-14 03:58:53 --> Language Class Initialized
INFO - 2023-01-14 03:58:53 --> Config Class Initialized
INFO - 2023-01-14 03:58:53 --> Loader Class Initialized
INFO - 2023-01-14 03:58:53 --> Helper loaded: url_helper
INFO - 2023-01-14 03:58:53 --> Helper loaded: file_helper
INFO - 2023-01-14 03:58:53 --> Helper loaded: form_helper
INFO - 2023-01-14 03:58:53 --> Helper loaded: my_helper
INFO - 2023-01-14 03:58:53 --> Database Driver Class Initialized
DEBUG - 2023-01-14 03:58:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-01-14 03:58:53 --> Session: Class initialized using 'files' driver.
INFO - 2023-01-14 03:58:53 --> Controller Class Initialized
DEBUG - 2023-01-14 03:58:53 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/set_mapel/views/form.php
DEBUG - 2023-01-14 03:58:53 --> File loaded: C:\xampp\htdocs\myraportk13\application\views\template_utama.php
INFO - 2023-01-14 03:58:53 --> Final output sent to browser
DEBUG - 2023-01-14 03:58:53 --> Total execution time: 0.0783
INFO - 2023-01-14 03:59:03 --> Config Class Initialized
INFO - 2023-01-14 03:59:03 --> Hooks Class Initialized
DEBUG - 2023-01-14 03:59:03 --> UTF-8 Support Enabled
INFO - 2023-01-14 03:59:03 --> Utf8 Class Initialized
INFO - 2023-01-14 03:59:03 --> URI Class Initialized
INFO - 2023-01-14 03:59:03 --> Router Class Initialized
INFO - 2023-01-14 03:59:03 --> Output Class Initialized
INFO - 2023-01-14 03:59:03 --> Security Class Initialized
DEBUG - 2023-01-14 03:59:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-14 03:59:03 --> Input Class Initialized
INFO - 2023-01-14 03:59:03 --> Language Class Initialized
INFO - 2023-01-14 03:59:03 --> Language Class Initialized
INFO - 2023-01-14 03:59:03 --> Config Class Initialized
INFO - 2023-01-14 03:59:03 --> Loader Class Initialized
INFO - 2023-01-14 03:59:03 --> Helper loaded: url_helper
INFO - 2023-01-14 03:59:03 --> Helper loaded: file_helper
INFO - 2023-01-14 03:59:03 --> Helper loaded: form_helper
INFO - 2023-01-14 03:59:03 --> Helper loaded: my_helper
INFO - 2023-01-14 03:59:03 --> Database Driver Class Initialized
DEBUG - 2023-01-14 03:59:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-01-14 03:59:03 --> Session: Class initialized using 'files' driver.
INFO - 2023-01-14 03:59:03 --> Controller Class Initialized
INFO - 2023-01-14 03:59:03 --> Config Class Initialized
INFO - 2023-01-14 03:59:03 --> Hooks Class Initialized
DEBUG - 2023-01-14 03:59:03 --> UTF-8 Support Enabled
INFO - 2023-01-14 03:59:03 --> Utf8 Class Initialized
INFO - 2023-01-14 03:59:03 --> URI Class Initialized
INFO - 2023-01-14 03:59:03 --> Router Class Initialized
INFO - 2023-01-14 03:59:03 --> Output Class Initialized
INFO - 2023-01-14 03:59:03 --> Security Class Initialized
DEBUG - 2023-01-14 03:59:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-14 03:59:03 --> Input Class Initialized
INFO - 2023-01-14 03:59:03 --> Language Class Initialized
INFO - 2023-01-14 03:59:03 --> Language Class Initialized
INFO - 2023-01-14 03:59:03 --> Config Class Initialized
INFO - 2023-01-14 03:59:03 --> Loader Class Initialized
INFO - 2023-01-14 03:59:03 --> Helper loaded: url_helper
INFO - 2023-01-14 03:59:03 --> Helper loaded: file_helper
INFO - 2023-01-14 03:59:03 --> Helper loaded: form_helper
INFO - 2023-01-14 03:59:03 --> Helper loaded: my_helper
INFO - 2023-01-14 03:59:03 --> Database Driver Class Initialized
DEBUG - 2023-01-14 03:59:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-01-14 03:59:03 --> Session: Class initialized using 'files' driver.
INFO - 2023-01-14 03:59:03 --> Controller Class Initialized
DEBUG - 2023-01-14 03:59:03 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/set_mapel/views/list.php
DEBUG - 2023-01-14 03:59:03 --> File loaded: C:\xampp\htdocs\myraportk13\application\views\template_utama.php
INFO - 2023-01-14 03:59:03 --> Final output sent to browser
DEBUG - 2023-01-14 03:59:03 --> Total execution time: 0.0503
INFO - 2023-01-14 03:59:03 --> Config Class Initialized
INFO - 2023-01-14 03:59:03 --> Hooks Class Initialized
DEBUG - 2023-01-14 03:59:03 --> UTF-8 Support Enabled
INFO - 2023-01-14 03:59:03 --> Utf8 Class Initialized
INFO - 2023-01-14 03:59:03 --> URI Class Initialized
INFO - 2023-01-14 03:59:03 --> Router Class Initialized
INFO - 2023-01-14 03:59:03 --> Output Class Initialized
INFO - 2023-01-14 03:59:03 --> Security Class Initialized
DEBUG - 2023-01-14 03:59:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-14 03:59:03 --> Input Class Initialized
INFO - 2023-01-14 03:59:03 --> Language Class Initialized
INFO - 2023-01-14 03:59:03 --> Language Class Initialized
INFO - 2023-01-14 03:59:03 --> Config Class Initialized
INFO - 2023-01-14 03:59:03 --> Loader Class Initialized
INFO - 2023-01-14 03:59:03 --> Helper loaded: url_helper
INFO - 2023-01-14 03:59:03 --> Helper loaded: file_helper
INFO - 2023-01-14 03:59:03 --> Helper loaded: form_helper
INFO - 2023-01-14 03:59:03 --> Helper loaded: my_helper
INFO - 2023-01-14 03:59:03 --> Database Driver Class Initialized
DEBUG - 2023-01-14 03:59:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-01-14 03:59:03 --> Session: Class initialized using 'files' driver.
INFO - 2023-01-14 03:59:03 --> Controller Class Initialized
INFO - 2023-01-14 03:59:05 --> Config Class Initialized
INFO - 2023-01-14 03:59:05 --> Hooks Class Initialized
DEBUG - 2023-01-14 03:59:05 --> UTF-8 Support Enabled
INFO - 2023-01-14 03:59:05 --> Utf8 Class Initialized
INFO - 2023-01-14 03:59:05 --> URI Class Initialized
INFO - 2023-01-14 03:59:05 --> Router Class Initialized
INFO - 2023-01-14 03:59:05 --> Output Class Initialized
INFO - 2023-01-14 03:59:05 --> Security Class Initialized
DEBUG - 2023-01-14 03:59:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-14 03:59:05 --> Input Class Initialized
INFO - 2023-01-14 03:59:05 --> Language Class Initialized
INFO - 2023-01-14 03:59:05 --> Language Class Initialized
INFO - 2023-01-14 03:59:05 --> Config Class Initialized
INFO - 2023-01-14 03:59:05 --> Loader Class Initialized
INFO - 2023-01-14 03:59:05 --> Helper loaded: url_helper
INFO - 2023-01-14 03:59:05 --> Helper loaded: file_helper
INFO - 2023-01-14 03:59:05 --> Helper loaded: form_helper
INFO - 2023-01-14 03:59:05 --> Helper loaded: my_helper
INFO - 2023-01-14 03:59:05 --> Database Driver Class Initialized
DEBUG - 2023-01-14 03:59:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-01-14 03:59:05 --> Session: Class initialized using 'files' driver.
INFO - 2023-01-14 03:59:05 --> Controller Class Initialized
INFO - 2023-01-14 03:59:05 --> Helper loaded: cookie_helper
INFO - 2023-01-14 03:59:05 --> Config Class Initialized
INFO - 2023-01-14 03:59:05 --> Hooks Class Initialized
DEBUG - 2023-01-14 03:59:05 --> UTF-8 Support Enabled
INFO - 2023-01-14 03:59:05 --> Utf8 Class Initialized
INFO - 2023-01-14 03:59:05 --> URI Class Initialized
INFO - 2023-01-14 03:59:05 --> Router Class Initialized
INFO - 2023-01-14 03:59:05 --> Output Class Initialized
INFO - 2023-01-14 03:59:05 --> Security Class Initialized
DEBUG - 2023-01-14 03:59:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-14 03:59:05 --> Input Class Initialized
INFO - 2023-01-14 03:59:05 --> Language Class Initialized
INFO - 2023-01-14 03:59:05 --> Language Class Initialized
INFO - 2023-01-14 03:59:05 --> Config Class Initialized
INFO - 2023-01-14 03:59:05 --> Loader Class Initialized
INFO - 2023-01-14 03:59:05 --> Helper loaded: url_helper
INFO - 2023-01-14 03:59:05 --> Helper loaded: file_helper
INFO - 2023-01-14 03:59:05 --> Helper loaded: form_helper
INFO - 2023-01-14 03:59:05 --> Helper loaded: my_helper
INFO - 2023-01-14 03:59:05 --> Database Driver Class Initialized
DEBUG - 2023-01-14 03:59:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-01-14 03:59:05 --> Session: Class initialized using 'files' driver.
INFO - 2023-01-14 03:59:05 --> Controller Class Initialized
INFO - 2023-01-14 03:59:05 --> Config Class Initialized
INFO - 2023-01-14 03:59:05 --> Hooks Class Initialized
DEBUG - 2023-01-14 03:59:05 --> UTF-8 Support Enabled
INFO - 2023-01-14 03:59:05 --> Utf8 Class Initialized
INFO - 2023-01-14 03:59:05 --> URI Class Initialized
INFO - 2023-01-14 03:59:06 --> Router Class Initialized
INFO - 2023-01-14 03:59:06 --> Output Class Initialized
INFO - 2023-01-14 03:59:06 --> Security Class Initialized
DEBUG - 2023-01-14 03:59:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-14 03:59:06 --> Input Class Initialized
INFO - 2023-01-14 03:59:06 --> Language Class Initialized
INFO - 2023-01-14 03:59:06 --> Language Class Initialized
INFO - 2023-01-14 03:59:06 --> Config Class Initialized
INFO - 2023-01-14 03:59:06 --> Loader Class Initialized
INFO - 2023-01-14 03:59:06 --> Helper loaded: url_helper
INFO - 2023-01-14 03:59:06 --> Helper loaded: file_helper
INFO - 2023-01-14 03:59:06 --> Helper loaded: form_helper
INFO - 2023-01-14 03:59:06 --> Helper loaded: my_helper
INFO - 2023-01-14 03:59:06 --> Database Driver Class Initialized
DEBUG - 2023-01-14 03:59:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-01-14 03:59:06 --> Session: Class initialized using 'files' driver.
INFO - 2023-01-14 03:59:06 --> Controller Class Initialized
DEBUG - 2023-01-14 03:59:06 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/login/views/login.php
DEBUG - 2023-01-14 03:59:06 --> File loaded: C:\xampp\htdocs\myraportk13\application\views\template_utama.php
INFO - 2023-01-14 03:59:06 --> Final output sent to browser
DEBUG - 2023-01-14 03:59:06 --> Total execution time: 0.0405
INFO - 2023-01-14 04:00:42 --> Config Class Initialized
INFO - 2023-01-14 04:00:42 --> Hooks Class Initialized
DEBUG - 2023-01-14 04:00:42 --> UTF-8 Support Enabled
INFO - 2023-01-14 04:00:42 --> Utf8 Class Initialized
INFO - 2023-01-14 04:00:42 --> URI Class Initialized
INFO - 2023-01-14 04:00:42 --> Router Class Initialized
INFO - 2023-01-14 04:00:42 --> Output Class Initialized
INFO - 2023-01-14 04:00:42 --> Security Class Initialized
DEBUG - 2023-01-14 04:00:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-14 04:00:42 --> Input Class Initialized
INFO - 2023-01-14 04:00:42 --> Language Class Initialized
INFO - 2023-01-14 04:00:42 --> Language Class Initialized
INFO - 2023-01-14 04:00:42 --> Config Class Initialized
INFO - 2023-01-14 04:00:42 --> Loader Class Initialized
INFO - 2023-01-14 04:00:42 --> Helper loaded: url_helper
INFO - 2023-01-14 04:00:42 --> Helper loaded: file_helper
INFO - 2023-01-14 04:00:42 --> Helper loaded: form_helper
INFO - 2023-01-14 04:00:42 --> Helper loaded: my_helper
INFO - 2023-01-14 04:00:42 --> Database Driver Class Initialized
DEBUG - 2023-01-14 04:00:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-01-14 04:00:42 --> Session: Class initialized using 'files' driver.
INFO - 2023-01-14 04:00:42 --> Controller Class Initialized
INFO - 2023-01-14 04:00:42 --> Helper loaded: cookie_helper
INFO - 2023-01-14 04:00:42 --> Final output sent to browser
DEBUG - 2023-01-14 04:00:42 --> Total execution time: 0.0443
INFO - 2023-01-14 04:00:42 --> Config Class Initialized
INFO - 2023-01-14 04:00:42 --> Hooks Class Initialized
DEBUG - 2023-01-14 04:00:42 --> UTF-8 Support Enabled
INFO - 2023-01-14 04:00:42 --> Utf8 Class Initialized
INFO - 2023-01-14 04:00:42 --> URI Class Initialized
INFO - 2023-01-14 04:00:42 --> Router Class Initialized
INFO - 2023-01-14 04:00:42 --> Output Class Initialized
INFO - 2023-01-14 04:00:42 --> Security Class Initialized
DEBUG - 2023-01-14 04:00:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-14 04:00:42 --> Input Class Initialized
INFO - 2023-01-14 04:00:42 --> Language Class Initialized
INFO - 2023-01-14 04:00:42 --> Language Class Initialized
INFO - 2023-01-14 04:00:42 --> Config Class Initialized
INFO - 2023-01-14 04:00:42 --> Loader Class Initialized
INFO - 2023-01-14 04:00:42 --> Helper loaded: url_helper
INFO - 2023-01-14 04:00:42 --> Helper loaded: file_helper
INFO - 2023-01-14 04:00:42 --> Helper loaded: form_helper
INFO - 2023-01-14 04:00:42 --> Helper loaded: my_helper
INFO - 2023-01-14 04:00:42 --> Database Driver Class Initialized
DEBUG - 2023-01-14 04:00:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-01-14 04:00:42 --> Session: Class initialized using 'files' driver.
INFO - 2023-01-14 04:00:42 --> Controller Class Initialized
DEBUG - 2023-01-14 04:00:42 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/home/views/v_home_guru.php
DEBUG - 2023-01-14 04:00:42 --> File loaded: C:\xampp\htdocs\myraportk13\application\views\template_utama.php
INFO - 2023-01-14 04:00:42 --> Final output sent to browser
DEBUG - 2023-01-14 04:00:42 --> Total execution time: 0.0615
INFO - 2023-01-14 04:00:44 --> Config Class Initialized
INFO - 2023-01-14 04:00:44 --> Hooks Class Initialized
DEBUG - 2023-01-14 04:00:44 --> UTF-8 Support Enabled
INFO - 2023-01-14 04:00:44 --> Utf8 Class Initialized
INFO - 2023-01-14 04:00:44 --> URI Class Initialized
INFO - 2023-01-14 04:00:44 --> Router Class Initialized
INFO - 2023-01-14 04:00:44 --> Output Class Initialized
INFO - 2023-01-14 04:00:44 --> Security Class Initialized
DEBUG - 2023-01-14 04:00:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-14 04:00:44 --> Input Class Initialized
INFO - 2023-01-14 04:00:44 --> Language Class Initialized
INFO - 2023-01-14 04:00:44 --> Language Class Initialized
INFO - 2023-01-14 04:00:44 --> Config Class Initialized
INFO - 2023-01-14 04:00:44 --> Loader Class Initialized
INFO - 2023-01-14 04:00:44 --> Helper loaded: url_helper
INFO - 2023-01-14 04:00:44 --> Helper loaded: file_helper
INFO - 2023-01-14 04:00:44 --> Helper loaded: form_helper
INFO - 2023-01-14 04:00:44 --> Helper loaded: my_helper
INFO - 2023-01-14 04:00:44 --> Database Driver Class Initialized
DEBUG - 2023-01-14 04:00:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-01-14 04:00:44 --> Session: Class initialized using 'files' driver.
INFO - 2023-01-14 04:00:44 --> Controller Class Initialized
DEBUG - 2023-01-14 04:00:44 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/view_mapel/views/v_view_mapel.php
DEBUG - 2023-01-14 04:00:44 --> File loaded: C:\xampp\htdocs\myraportk13\application\views\template_utama.php
INFO - 2023-01-14 04:00:44 --> Final output sent to browser
DEBUG - 2023-01-14 04:00:44 --> Total execution time: 0.0538
INFO - 2023-01-14 04:00:49 --> Config Class Initialized
INFO - 2023-01-14 04:00:49 --> Hooks Class Initialized
DEBUG - 2023-01-14 04:00:49 --> UTF-8 Support Enabled
INFO - 2023-01-14 04:00:49 --> Utf8 Class Initialized
INFO - 2023-01-14 04:00:49 --> URI Class Initialized
INFO - 2023-01-14 04:00:49 --> Router Class Initialized
INFO - 2023-01-14 04:00:49 --> Output Class Initialized
INFO - 2023-01-14 04:00:49 --> Security Class Initialized
DEBUG - 2023-01-14 04:00:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-14 04:00:49 --> Input Class Initialized
INFO - 2023-01-14 04:00:49 --> Language Class Initialized
INFO - 2023-01-14 04:00:49 --> Language Class Initialized
INFO - 2023-01-14 04:00:49 --> Config Class Initialized
INFO - 2023-01-14 04:00:49 --> Loader Class Initialized
INFO - 2023-01-14 04:00:49 --> Helper loaded: url_helper
INFO - 2023-01-14 04:00:49 --> Helper loaded: file_helper
INFO - 2023-01-14 04:00:49 --> Helper loaded: form_helper
INFO - 2023-01-14 04:00:49 --> Helper loaded: my_helper
INFO - 2023-01-14 04:00:49 --> Database Driver Class Initialized
DEBUG - 2023-01-14 04:00:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-01-14 04:00:49 --> Session: Class initialized using 'files' driver.
INFO - 2023-01-14 04:00:49 --> Controller Class Initialized
DEBUG - 2023-01-14 04:00:49 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/n_icb/views/list.php
DEBUG - 2023-01-14 04:00:49 --> File loaded: C:\xampp\htdocs\myraportk13\application\views\template_utama.php
INFO - 2023-01-14 04:00:49 --> Final output sent to browser
DEBUG - 2023-01-14 04:00:49 --> Total execution time: 0.0366
INFO - 2023-01-14 04:00:49 --> Config Class Initialized
INFO - 2023-01-14 04:00:49 --> Hooks Class Initialized
DEBUG - 2023-01-14 04:00:49 --> UTF-8 Support Enabled
INFO - 2023-01-14 04:00:49 --> Utf8 Class Initialized
INFO - 2023-01-14 04:00:49 --> URI Class Initialized
INFO - 2023-01-14 04:00:49 --> Router Class Initialized
INFO - 2023-01-14 04:00:49 --> Output Class Initialized
INFO - 2023-01-14 04:00:49 --> Security Class Initialized
DEBUG - 2023-01-14 04:00:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-14 04:00:49 --> Input Class Initialized
INFO - 2023-01-14 04:00:49 --> Language Class Initialized
INFO - 2023-01-14 04:00:49 --> Language Class Initialized
INFO - 2023-01-14 04:00:49 --> Config Class Initialized
INFO - 2023-01-14 04:00:49 --> Loader Class Initialized
INFO - 2023-01-14 04:00:49 --> Helper loaded: url_helper
INFO - 2023-01-14 04:00:49 --> Helper loaded: file_helper
INFO - 2023-01-14 04:00:49 --> Helper loaded: form_helper
INFO - 2023-01-14 04:00:49 --> Helper loaded: my_helper
INFO - 2023-01-14 04:00:49 --> Database Driver Class Initialized
DEBUG - 2023-01-14 04:00:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-01-14 04:00:49 --> Session: Class initialized using 'files' driver.
INFO - 2023-01-14 04:00:49 --> Controller Class Initialized
INFO - 2023-01-14 04:00:52 --> Config Class Initialized
INFO - 2023-01-14 04:00:52 --> Hooks Class Initialized
DEBUG - 2023-01-14 04:00:52 --> UTF-8 Support Enabled
INFO - 2023-01-14 04:00:52 --> Utf8 Class Initialized
INFO - 2023-01-14 04:00:52 --> URI Class Initialized
INFO - 2023-01-14 04:00:52 --> Router Class Initialized
INFO - 2023-01-14 04:00:52 --> Output Class Initialized
INFO - 2023-01-14 04:00:52 --> Security Class Initialized
DEBUG - 2023-01-14 04:00:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-14 04:00:52 --> Input Class Initialized
INFO - 2023-01-14 04:00:52 --> Language Class Initialized
INFO - 2023-01-14 04:00:52 --> Language Class Initialized
INFO - 2023-01-14 04:00:52 --> Config Class Initialized
INFO - 2023-01-14 04:00:52 --> Loader Class Initialized
INFO - 2023-01-14 04:00:52 --> Helper loaded: url_helper
INFO - 2023-01-14 04:00:52 --> Helper loaded: file_helper
INFO - 2023-01-14 04:00:52 --> Helper loaded: form_helper
INFO - 2023-01-14 04:00:52 --> Helper loaded: my_helper
INFO - 2023-01-14 04:00:52 --> Database Driver Class Initialized
DEBUG - 2023-01-14 04:00:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-01-14 04:00:52 --> Session: Class initialized using 'files' driver.
INFO - 2023-01-14 04:00:52 --> Controller Class Initialized
DEBUG - 2023-01-14 04:00:52 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/view_mapel/views/v_view_mapel.php
DEBUG - 2023-01-14 04:00:52 --> File loaded: C:\xampp\htdocs\myraportk13\application\views\template_utama.php
INFO - 2023-01-14 04:00:52 --> Final output sent to browser
DEBUG - 2023-01-14 04:00:52 --> Total execution time: 0.0578
INFO - 2023-01-14 04:00:59 --> Config Class Initialized
INFO - 2023-01-14 04:00:59 --> Hooks Class Initialized
DEBUG - 2023-01-14 04:00:59 --> UTF-8 Support Enabled
INFO - 2023-01-14 04:00:59 --> Utf8 Class Initialized
INFO - 2023-01-14 04:00:59 --> URI Class Initialized
INFO - 2023-01-14 04:00:59 --> Router Class Initialized
INFO - 2023-01-14 04:00:59 --> Output Class Initialized
INFO - 2023-01-14 04:00:59 --> Security Class Initialized
DEBUG - 2023-01-14 04:00:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-14 04:00:59 --> Input Class Initialized
INFO - 2023-01-14 04:00:59 --> Language Class Initialized
INFO - 2023-01-14 04:00:59 --> Language Class Initialized
INFO - 2023-01-14 04:00:59 --> Config Class Initialized
INFO - 2023-01-14 04:00:59 --> Loader Class Initialized
INFO - 2023-01-14 04:00:59 --> Helper loaded: url_helper
INFO - 2023-01-14 04:00:59 --> Helper loaded: file_helper
INFO - 2023-01-14 04:00:59 --> Helper loaded: form_helper
INFO - 2023-01-14 04:00:59 --> Helper loaded: my_helper
INFO - 2023-01-14 04:00:59 --> Database Driver Class Initialized
DEBUG - 2023-01-14 04:00:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-01-14 04:00:59 --> Session: Class initialized using 'files' driver.
INFO - 2023-01-14 04:00:59 --> Controller Class Initialized
DEBUG - 2023-01-14 04:00:59 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/n_icb/views/list.php
DEBUG - 2023-01-14 04:00:59 --> File loaded: C:\xampp\htdocs\myraportk13\application\views\template_utama.php
INFO - 2023-01-14 04:00:59 --> Final output sent to browser
DEBUG - 2023-01-14 04:00:59 --> Total execution time: 0.0565
INFO - 2023-01-14 04:00:59 --> Config Class Initialized
INFO - 2023-01-14 04:00:59 --> Hooks Class Initialized
DEBUG - 2023-01-14 04:00:59 --> UTF-8 Support Enabled
INFO - 2023-01-14 04:00:59 --> Utf8 Class Initialized
INFO - 2023-01-14 04:00:59 --> URI Class Initialized
INFO - 2023-01-14 04:00:59 --> Router Class Initialized
INFO - 2023-01-14 04:00:59 --> Output Class Initialized
INFO - 2023-01-14 04:00:59 --> Security Class Initialized
DEBUG - 2023-01-14 04:00:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-14 04:00:59 --> Input Class Initialized
INFO - 2023-01-14 04:00:59 --> Language Class Initialized
INFO - 2023-01-14 04:00:59 --> Language Class Initialized
INFO - 2023-01-14 04:00:59 --> Config Class Initialized
INFO - 2023-01-14 04:00:59 --> Loader Class Initialized
INFO - 2023-01-14 04:00:59 --> Helper loaded: url_helper
INFO - 2023-01-14 04:00:59 --> Helper loaded: file_helper
INFO - 2023-01-14 04:00:59 --> Helper loaded: form_helper
INFO - 2023-01-14 04:00:59 --> Helper loaded: my_helper
INFO - 2023-01-14 04:00:59 --> Database Driver Class Initialized
DEBUG - 2023-01-14 04:00:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-01-14 04:00:59 --> Session: Class initialized using 'files' driver.
INFO - 2023-01-14 04:00:59 --> Controller Class Initialized
INFO - 2023-01-14 04:01:01 --> Config Class Initialized
INFO - 2023-01-14 04:01:01 --> Hooks Class Initialized
DEBUG - 2023-01-14 04:01:01 --> UTF-8 Support Enabled
INFO - 2023-01-14 04:01:01 --> Utf8 Class Initialized
INFO - 2023-01-14 04:01:01 --> URI Class Initialized
INFO - 2023-01-14 04:01:01 --> Router Class Initialized
INFO - 2023-01-14 04:01:01 --> Output Class Initialized
INFO - 2023-01-14 04:01:01 --> Security Class Initialized
DEBUG - 2023-01-14 04:01:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-14 04:01:01 --> Input Class Initialized
INFO - 2023-01-14 04:01:01 --> Language Class Initialized
INFO - 2023-01-14 04:01:01 --> Language Class Initialized
INFO - 2023-01-14 04:01:01 --> Config Class Initialized
INFO - 2023-01-14 04:01:01 --> Loader Class Initialized
INFO - 2023-01-14 04:01:01 --> Helper loaded: url_helper
INFO - 2023-01-14 04:01:01 --> Helper loaded: file_helper
INFO - 2023-01-14 04:01:01 --> Helper loaded: form_helper
INFO - 2023-01-14 04:01:01 --> Helper loaded: my_helper
INFO - 2023-01-14 04:01:01 --> Database Driver Class Initialized
DEBUG - 2023-01-14 04:01:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-01-14 04:01:01 --> Session: Class initialized using 'files' driver.
INFO - 2023-01-14 04:01:01 --> Controller Class Initialized
DEBUG - 2023-01-14 04:01:01 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/view_mapel/views/v_view_mapel.php
DEBUG - 2023-01-14 04:01:01 --> File loaded: C:\xampp\htdocs\myraportk13\application\views\template_utama.php
INFO - 2023-01-14 04:01:01 --> Final output sent to browser
DEBUG - 2023-01-14 04:01:01 --> Total execution time: 0.0584
INFO - 2023-01-14 16:42:20 --> Config Class Initialized
INFO - 2023-01-14 16:42:20 --> Hooks Class Initialized
DEBUG - 2023-01-14 16:42:20 --> UTF-8 Support Enabled
INFO - 2023-01-14 16:42:20 --> Utf8 Class Initialized
INFO - 2023-01-14 16:42:20 --> URI Class Initialized
INFO - 2023-01-14 16:42:20 --> Router Class Initialized
INFO - 2023-01-14 16:42:20 --> Output Class Initialized
INFO - 2023-01-14 16:42:20 --> Security Class Initialized
DEBUG - 2023-01-14 16:42:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-14 16:42:20 --> Input Class Initialized
INFO - 2023-01-14 16:42:20 --> Language Class Initialized
INFO - 2023-01-14 16:42:20 --> Language Class Initialized
INFO - 2023-01-14 16:42:20 --> Config Class Initialized
INFO - 2023-01-14 16:42:20 --> Loader Class Initialized
INFO - 2023-01-14 16:42:20 --> Helper loaded: url_helper
INFO - 2023-01-14 16:42:20 --> Helper loaded: file_helper
INFO - 2023-01-14 16:42:21 --> Helper loaded: form_helper
INFO - 2023-01-14 16:42:21 --> Helper loaded: my_helper
INFO - 2023-01-14 16:42:21 --> Database Driver Class Initialized
DEBUG - 2023-01-14 16:42:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-01-14 16:42:21 --> Session: Class initialized using 'files' driver.
INFO - 2023-01-14 16:42:21 --> Controller Class Initialized
INFO - 2023-01-14 16:42:21 --> Config Class Initialized
INFO - 2023-01-14 16:42:21 --> Hooks Class Initialized
DEBUG - 2023-01-14 16:42:21 --> UTF-8 Support Enabled
INFO - 2023-01-14 16:42:21 --> Utf8 Class Initialized
INFO - 2023-01-14 16:42:21 --> URI Class Initialized
INFO - 2023-01-14 16:42:21 --> Router Class Initialized
INFO - 2023-01-14 16:42:21 --> Output Class Initialized
INFO - 2023-01-14 16:42:21 --> Security Class Initialized
DEBUG - 2023-01-14 16:42:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-14 16:42:21 --> Input Class Initialized
INFO - 2023-01-14 16:42:21 --> Language Class Initialized
INFO - 2023-01-14 16:42:21 --> Language Class Initialized
INFO - 2023-01-14 16:42:21 --> Config Class Initialized
INFO - 2023-01-14 16:42:21 --> Loader Class Initialized
INFO - 2023-01-14 16:42:21 --> Helper loaded: url_helper
INFO - 2023-01-14 16:42:21 --> Helper loaded: file_helper
INFO - 2023-01-14 16:42:21 --> Helper loaded: form_helper
INFO - 2023-01-14 16:42:21 --> Helper loaded: my_helper
INFO - 2023-01-14 16:42:21 --> Database Driver Class Initialized
DEBUG - 2023-01-14 16:42:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-01-14 16:42:21 --> Session: Class initialized using 'files' driver.
INFO - 2023-01-14 16:42:21 --> Controller Class Initialized
DEBUG - 2023-01-14 16:42:21 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/login/views/login.php
DEBUG - 2023-01-14 16:42:21 --> File loaded: C:\xampp\htdocs\myraportk13\application\views\template_utama.php
INFO - 2023-01-14 16:42:21 --> Final output sent to browser
DEBUG - 2023-01-14 16:42:21 --> Total execution time: 0.1035
INFO - 2023-01-14 16:48:34 --> Config Class Initialized
INFO - 2023-01-14 16:48:34 --> Hooks Class Initialized
DEBUG - 2023-01-14 16:48:34 --> UTF-8 Support Enabled
INFO - 2023-01-14 16:48:34 --> Utf8 Class Initialized
INFO - 2023-01-14 16:48:34 --> URI Class Initialized
INFO - 2023-01-14 16:48:34 --> Router Class Initialized
INFO - 2023-01-14 16:48:34 --> Output Class Initialized
INFO - 2023-01-14 16:48:34 --> Security Class Initialized
DEBUG - 2023-01-14 16:48:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-14 16:48:34 --> Input Class Initialized
INFO - 2023-01-14 16:48:34 --> Language Class Initialized
INFO - 2023-01-14 16:48:34 --> Language Class Initialized
INFO - 2023-01-14 16:48:34 --> Config Class Initialized
INFO - 2023-01-14 16:48:34 --> Loader Class Initialized
INFO - 2023-01-14 16:48:34 --> Helper loaded: url_helper
INFO - 2023-01-14 16:48:34 --> Helper loaded: file_helper
INFO - 2023-01-14 16:48:34 --> Helper loaded: form_helper
INFO - 2023-01-14 16:48:34 --> Helper loaded: my_helper
INFO - 2023-01-14 16:48:34 --> Database Driver Class Initialized
DEBUG - 2023-01-14 16:48:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-01-14 16:48:35 --> Session: Class initialized using 'files' driver.
INFO - 2023-01-14 16:48:35 --> Controller Class Initialized
INFO - 2023-01-14 16:48:35 --> Helper loaded: cookie_helper
INFO - 2023-01-14 16:48:35 --> Final output sent to browser
DEBUG - 2023-01-14 16:48:35 --> Total execution time: 0.0791
INFO - 2023-01-14 16:48:35 --> Config Class Initialized
INFO - 2023-01-14 16:48:35 --> Hooks Class Initialized
DEBUG - 2023-01-14 16:48:35 --> UTF-8 Support Enabled
INFO - 2023-01-14 16:48:35 --> Utf8 Class Initialized
INFO - 2023-01-14 16:48:35 --> URI Class Initialized
INFO - 2023-01-14 16:48:35 --> Router Class Initialized
INFO - 2023-01-14 16:48:35 --> Output Class Initialized
INFO - 2023-01-14 16:48:35 --> Security Class Initialized
DEBUG - 2023-01-14 16:48:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-14 16:48:35 --> Input Class Initialized
INFO - 2023-01-14 16:48:35 --> Language Class Initialized
INFO - 2023-01-14 16:48:35 --> Language Class Initialized
INFO - 2023-01-14 16:48:35 --> Config Class Initialized
INFO - 2023-01-14 16:48:35 --> Loader Class Initialized
INFO - 2023-01-14 16:48:35 --> Helper loaded: url_helper
INFO - 2023-01-14 16:48:35 --> Helper loaded: file_helper
INFO - 2023-01-14 16:48:35 --> Helper loaded: form_helper
INFO - 2023-01-14 16:48:35 --> Helper loaded: my_helper
INFO - 2023-01-14 16:48:35 --> Database Driver Class Initialized
DEBUG - 2023-01-14 16:48:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-01-14 16:48:35 --> Session: Class initialized using 'files' driver.
INFO - 2023-01-14 16:48:35 --> Controller Class Initialized
DEBUG - 2023-01-14 16:48:35 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/home/views/v_home_guru.php
DEBUG - 2023-01-14 16:48:35 --> File loaded: C:\xampp\htdocs\myraportk13\application\views\template_utama.php
INFO - 2023-01-14 16:48:35 --> Final output sent to browser
DEBUG - 2023-01-14 16:48:35 --> Total execution time: 0.1257
INFO - 2023-01-14 16:48:38 --> Config Class Initialized
INFO - 2023-01-14 16:48:38 --> Hooks Class Initialized
DEBUG - 2023-01-14 16:48:38 --> UTF-8 Support Enabled
INFO - 2023-01-14 16:48:38 --> Utf8 Class Initialized
INFO - 2023-01-14 16:48:38 --> URI Class Initialized
INFO - 2023-01-14 16:48:38 --> Router Class Initialized
INFO - 2023-01-14 16:48:38 --> Output Class Initialized
INFO - 2023-01-14 16:48:38 --> Security Class Initialized
DEBUG - 2023-01-14 16:48:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-14 16:48:38 --> Input Class Initialized
INFO - 2023-01-14 16:48:38 --> Language Class Initialized
INFO - 2023-01-14 16:48:38 --> Language Class Initialized
INFO - 2023-01-14 16:48:38 --> Config Class Initialized
INFO - 2023-01-14 16:48:38 --> Loader Class Initialized
INFO - 2023-01-14 16:48:38 --> Helper loaded: url_helper
INFO - 2023-01-14 16:48:38 --> Helper loaded: file_helper
INFO - 2023-01-14 16:48:38 --> Helper loaded: form_helper
INFO - 2023-01-14 16:48:38 --> Helper loaded: my_helper
INFO - 2023-01-14 16:48:38 --> Database Driver Class Initialized
DEBUG - 2023-01-14 16:48:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-01-14 16:48:39 --> Session: Class initialized using 'files' driver.
INFO - 2023-01-14 16:48:39 --> Controller Class Initialized
DEBUG - 2023-01-14 16:48:39 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/view_mapel/views/v_view_mapel.php
DEBUG - 2023-01-14 16:48:39 --> File loaded: C:\xampp\htdocs\myraportk13\application\views\template_utama.php
INFO - 2023-01-14 16:48:39 --> Final output sent to browser
DEBUG - 2023-01-14 16:48:39 --> Total execution time: 0.0806
INFO - 2023-01-14 16:48:55 --> Config Class Initialized
INFO - 2023-01-14 16:48:55 --> Hooks Class Initialized
DEBUG - 2023-01-14 16:48:55 --> UTF-8 Support Enabled
INFO - 2023-01-14 16:48:55 --> Utf8 Class Initialized
INFO - 2023-01-14 16:48:55 --> URI Class Initialized
INFO - 2023-01-14 16:48:55 --> Router Class Initialized
INFO - 2023-01-14 16:48:55 --> Output Class Initialized
INFO - 2023-01-14 16:48:55 --> Security Class Initialized
DEBUG - 2023-01-14 16:48:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-14 16:48:55 --> Input Class Initialized
INFO - 2023-01-14 16:48:55 --> Language Class Initialized
INFO - 2023-01-14 16:48:55 --> Language Class Initialized
INFO - 2023-01-14 16:48:55 --> Config Class Initialized
INFO - 2023-01-14 16:48:55 --> Loader Class Initialized
INFO - 2023-01-14 16:48:55 --> Helper loaded: url_helper
INFO - 2023-01-14 16:48:55 --> Helper loaded: file_helper
INFO - 2023-01-14 16:48:55 --> Helper loaded: form_helper
INFO - 2023-01-14 16:48:55 --> Helper loaded: my_helper
INFO - 2023-01-14 16:48:55 --> Database Driver Class Initialized
DEBUG - 2023-01-14 16:48:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-01-14 16:48:55 --> Session: Class initialized using 'files' driver.
INFO - 2023-01-14 16:48:55 --> Controller Class Initialized
DEBUG - 2023-01-14 16:48:55 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/n_icb/views/list.php
DEBUG - 2023-01-14 16:48:55 --> File loaded: C:\xampp\htdocs\myraportk13\application\views\template_utama.php
INFO - 2023-01-14 16:48:55 --> Final output sent to browser
DEBUG - 2023-01-14 16:48:55 --> Total execution time: 0.0784
INFO - 2023-01-14 16:48:55 --> Config Class Initialized
INFO - 2023-01-14 16:48:55 --> Hooks Class Initialized
DEBUG - 2023-01-14 16:48:55 --> UTF-8 Support Enabled
INFO - 2023-01-14 16:48:55 --> Utf8 Class Initialized
INFO - 2023-01-14 16:48:55 --> URI Class Initialized
INFO - 2023-01-14 16:48:55 --> Router Class Initialized
INFO - 2023-01-14 16:48:55 --> Output Class Initialized
INFO - 2023-01-14 16:48:55 --> Security Class Initialized
DEBUG - 2023-01-14 16:48:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-14 16:48:55 --> Input Class Initialized
INFO - 2023-01-14 16:48:55 --> Language Class Initialized
INFO - 2023-01-14 16:48:55 --> Language Class Initialized
INFO - 2023-01-14 16:48:55 --> Config Class Initialized
INFO - 2023-01-14 16:48:55 --> Loader Class Initialized
INFO - 2023-01-14 16:48:55 --> Helper loaded: url_helper
INFO - 2023-01-14 16:48:55 --> Helper loaded: file_helper
INFO - 2023-01-14 16:48:55 --> Helper loaded: form_helper
INFO - 2023-01-14 16:48:55 --> Helper loaded: my_helper
INFO - 2023-01-14 16:48:55 --> Database Driver Class Initialized
DEBUG - 2023-01-14 16:48:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-01-14 16:48:55 --> Session: Class initialized using 'files' driver.
INFO - 2023-01-14 16:48:55 --> Controller Class Initialized
INFO - 2023-01-14 16:48:57 --> Config Class Initialized
INFO - 2023-01-14 16:48:57 --> Hooks Class Initialized
DEBUG - 2023-01-14 16:48:57 --> UTF-8 Support Enabled
INFO - 2023-01-14 16:48:57 --> Utf8 Class Initialized
INFO - 2023-01-14 16:48:57 --> URI Class Initialized
INFO - 2023-01-14 16:48:57 --> Router Class Initialized
INFO - 2023-01-14 16:48:57 --> Output Class Initialized
INFO - 2023-01-14 16:48:57 --> Security Class Initialized
DEBUG - 2023-01-14 16:48:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-14 16:48:57 --> Input Class Initialized
INFO - 2023-01-14 16:48:57 --> Language Class Initialized
INFO - 2023-01-14 16:48:57 --> Language Class Initialized
INFO - 2023-01-14 16:48:57 --> Config Class Initialized
INFO - 2023-01-14 16:48:57 --> Loader Class Initialized
INFO - 2023-01-14 16:48:57 --> Helper loaded: url_helper
INFO - 2023-01-14 16:48:57 --> Helper loaded: file_helper
INFO - 2023-01-14 16:48:57 --> Helper loaded: form_helper
INFO - 2023-01-14 16:48:57 --> Helper loaded: my_helper
INFO - 2023-01-14 16:48:57 --> Database Driver Class Initialized
DEBUG - 2023-01-14 16:48:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-01-14 16:48:57 --> Session: Class initialized using 'files' driver.
INFO - 2023-01-14 16:48:57 --> Controller Class Initialized
DEBUG - 2023-01-14 16:48:57 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/view_mapel/views/v_view_mapel.php
DEBUG - 2023-01-14 16:48:57 --> File loaded: C:\xampp\htdocs\myraportk13\application\views\template_utama.php
INFO - 2023-01-14 16:48:57 --> Final output sent to browser
DEBUG - 2023-01-14 16:48:57 --> Total execution time: 0.0410
INFO - 2023-01-14 16:49:00 --> Config Class Initialized
INFO - 2023-01-14 16:49:00 --> Hooks Class Initialized
DEBUG - 2023-01-14 16:49:00 --> UTF-8 Support Enabled
INFO - 2023-01-14 16:49:00 --> Utf8 Class Initialized
INFO - 2023-01-14 16:49:00 --> URI Class Initialized
INFO - 2023-01-14 16:49:00 --> Router Class Initialized
INFO - 2023-01-14 16:49:00 --> Output Class Initialized
INFO - 2023-01-14 16:49:00 --> Security Class Initialized
DEBUG - 2023-01-14 16:49:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-14 16:49:00 --> Input Class Initialized
INFO - 2023-01-14 16:49:00 --> Language Class Initialized
INFO - 2023-01-14 16:49:00 --> Language Class Initialized
INFO - 2023-01-14 16:49:00 --> Config Class Initialized
INFO - 2023-01-14 16:49:00 --> Loader Class Initialized
INFO - 2023-01-14 16:49:00 --> Helper loaded: url_helper
INFO - 2023-01-14 16:49:00 --> Helper loaded: file_helper
INFO - 2023-01-14 16:49:00 --> Helper loaded: form_helper
INFO - 2023-01-14 16:49:00 --> Helper loaded: my_helper
INFO - 2023-01-14 16:49:00 --> Database Driver Class Initialized
DEBUG - 2023-01-14 16:49:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-01-14 16:49:00 --> Session: Class initialized using 'files' driver.
INFO - 2023-01-14 16:49:00 --> Controller Class Initialized
DEBUG - 2023-01-14 16:49:00 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/n_icb/views/list.php
DEBUG - 2023-01-14 16:49:00 --> File loaded: C:\xampp\htdocs\myraportk13\application\views\template_utama.php
INFO - 2023-01-14 16:49:00 --> Final output sent to browser
DEBUG - 2023-01-14 16:49:00 --> Total execution time: 0.0567
INFO - 2023-01-14 16:49:00 --> Config Class Initialized
INFO - 2023-01-14 16:49:00 --> Hooks Class Initialized
DEBUG - 2023-01-14 16:49:00 --> UTF-8 Support Enabled
INFO - 2023-01-14 16:49:00 --> Utf8 Class Initialized
INFO - 2023-01-14 16:49:00 --> URI Class Initialized
INFO - 2023-01-14 16:49:00 --> Router Class Initialized
INFO - 2023-01-14 16:49:00 --> Output Class Initialized
INFO - 2023-01-14 16:49:00 --> Security Class Initialized
DEBUG - 2023-01-14 16:49:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-14 16:49:00 --> Input Class Initialized
INFO - 2023-01-14 16:49:00 --> Language Class Initialized
INFO - 2023-01-14 16:49:00 --> Language Class Initialized
INFO - 2023-01-14 16:49:00 --> Config Class Initialized
INFO - 2023-01-14 16:49:00 --> Loader Class Initialized
INFO - 2023-01-14 16:49:00 --> Helper loaded: url_helper
INFO - 2023-01-14 16:49:00 --> Helper loaded: file_helper
INFO - 2023-01-14 16:49:00 --> Helper loaded: form_helper
INFO - 2023-01-14 16:49:00 --> Helper loaded: my_helper
INFO - 2023-01-14 16:49:00 --> Database Driver Class Initialized
DEBUG - 2023-01-14 16:49:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-01-14 16:49:00 --> Session: Class initialized using 'files' driver.
INFO - 2023-01-14 16:49:00 --> Controller Class Initialized
INFO - 2023-01-14 16:49:06 --> Config Class Initialized
INFO - 2023-01-14 16:49:06 --> Hooks Class Initialized
DEBUG - 2023-01-14 16:49:06 --> UTF-8 Support Enabled
INFO - 2023-01-14 16:49:06 --> Utf8 Class Initialized
INFO - 2023-01-14 16:49:06 --> URI Class Initialized
INFO - 2023-01-14 16:49:06 --> Router Class Initialized
INFO - 2023-01-14 16:49:06 --> Output Class Initialized
INFO - 2023-01-14 16:49:06 --> Security Class Initialized
DEBUG - 2023-01-14 16:49:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-14 16:49:06 --> Input Class Initialized
INFO - 2023-01-14 16:49:06 --> Language Class Initialized
INFO - 2023-01-14 16:49:06 --> Language Class Initialized
INFO - 2023-01-14 16:49:06 --> Config Class Initialized
INFO - 2023-01-14 16:49:06 --> Loader Class Initialized
INFO - 2023-01-14 16:49:06 --> Helper loaded: url_helper
INFO - 2023-01-14 16:49:06 --> Helper loaded: file_helper
INFO - 2023-01-14 16:49:06 --> Helper loaded: form_helper
INFO - 2023-01-14 16:49:06 --> Helper loaded: my_helper
INFO - 2023-01-14 16:49:06 --> Database Driver Class Initialized
DEBUG - 2023-01-14 16:49:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-01-14 16:49:06 --> Session: Class initialized using 'files' driver.
INFO - 2023-01-14 16:49:06 --> Controller Class Initialized
INFO - 2023-01-14 16:49:06 --> Final output sent to browser
DEBUG - 2023-01-14 16:49:06 --> Total execution time: 0.0654
INFO - 2023-01-14 16:49:11 --> Config Class Initialized
INFO - 2023-01-14 16:49:11 --> Hooks Class Initialized
DEBUG - 2023-01-14 16:49:11 --> UTF-8 Support Enabled
INFO - 2023-01-14 16:49:11 --> Utf8 Class Initialized
INFO - 2023-01-14 16:49:11 --> URI Class Initialized
INFO - 2023-01-14 16:49:11 --> Router Class Initialized
INFO - 2023-01-14 16:49:11 --> Output Class Initialized
INFO - 2023-01-14 16:49:12 --> Security Class Initialized
DEBUG - 2023-01-14 16:49:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-14 16:49:12 --> Input Class Initialized
INFO - 2023-01-14 16:49:12 --> Language Class Initialized
INFO - 2023-01-14 16:49:12 --> Language Class Initialized
INFO - 2023-01-14 16:49:12 --> Config Class Initialized
INFO - 2023-01-14 16:49:12 --> Loader Class Initialized
INFO - 2023-01-14 16:49:12 --> Helper loaded: url_helper
INFO - 2023-01-14 16:49:12 --> Helper loaded: file_helper
INFO - 2023-01-14 16:49:12 --> Helper loaded: form_helper
INFO - 2023-01-14 16:49:12 --> Helper loaded: my_helper
INFO - 2023-01-14 16:49:12 --> Database Driver Class Initialized
DEBUG - 2023-01-14 16:49:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-01-14 16:49:12 --> Session: Class initialized using 'files' driver.
INFO - 2023-01-14 16:49:12 --> Controller Class Initialized
DEBUG - 2023-01-14 16:49:12 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/view_mapel/views/v_view_mapel.php
DEBUG - 2023-01-14 16:49:12 --> File loaded: C:\xampp\htdocs\myraportk13\application\views\template_utama.php
INFO - 2023-01-14 16:49:12 --> Final output sent to browser
DEBUG - 2023-01-14 16:49:12 --> Total execution time: 0.0558
INFO - 2023-01-14 16:49:17 --> Config Class Initialized
INFO - 2023-01-14 16:49:17 --> Hooks Class Initialized
DEBUG - 2023-01-14 16:49:17 --> UTF-8 Support Enabled
INFO - 2023-01-14 16:49:17 --> Utf8 Class Initialized
INFO - 2023-01-14 16:49:17 --> URI Class Initialized
INFO - 2023-01-14 16:49:17 --> Router Class Initialized
INFO - 2023-01-14 16:49:17 --> Output Class Initialized
INFO - 2023-01-14 16:49:17 --> Security Class Initialized
DEBUG - 2023-01-14 16:49:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-14 16:49:17 --> Input Class Initialized
INFO - 2023-01-14 16:49:17 --> Language Class Initialized
INFO - 2023-01-14 16:49:17 --> Language Class Initialized
INFO - 2023-01-14 16:49:17 --> Config Class Initialized
INFO - 2023-01-14 16:49:17 --> Loader Class Initialized
INFO - 2023-01-14 16:49:17 --> Helper loaded: url_helper
INFO - 2023-01-14 16:49:17 --> Helper loaded: file_helper
INFO - 2023-01-14 16:49:17 --> Helper loaded: form_helper
INFO - 2023-01-14 16:49:17 --> Helper loaded: my_helper
INFO - 2023-01-14 16:49:17 --> Database Driver Class Initialized
DEBUG - 2023-01-14 16:49:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-01-14 16:49:17 --> Session: Class initialized using 'files' driver.
INFO - 2023-01-14 16:49:17 --> Controller Class Initialized
INFO - 2023-01-14 16:49:17 --> Helper loaded: cookie_helper
INFO - 2023-01-14 16:49:17 --> Config Class Initialized
INFO - 2023-01-14 16:49:17 --> Hooks Class Initialized
DEBUG - 2023-01-14 16:49:17 --> UTF-8 Support Enabled
INFO - 2023-01-14 16:49:17 --> Utf8 Class Initialized
INFO - 2023-01-14 16:49:17 --> URI Class Initialized
INFO - 2023-01-14 16:49:17 --> Router Class Initialized
INFO - 2023-01-14 16:49:17 --> Output Class Initialized
INFO - 2023-01-14 16:49:17 --> Security Class Initialized
DEBUG - 2023-01-14 16:49:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-14 16:49:17 --> Input Class Initialized
INFO - 2023-01-14 16:49:17 --> Language Class Initialized
INFO - 2023-01-14 16:49:17 --> Language Class Initialized
INFO - 2023-01-14 16:49:17 --> Config Class Initialized
INFO - 2023-01-14 16:49:17 --> Loader Class Initialized
INFO - 2023-01-14 16:49:17 --> Helper loaded: url_helper
INFO - 2023-01-14 16:49:17 --> Helper loaded: file_helper
INFO - 2023-01-14 16:49:17 --> Helper loaded: form_helper
INFO - 2023-01-14 16:49:17 --> Helper loaded: my_helper
INFO - 2023-01-14 16:49:17 --> Database Driver Class Initialized
DEBUG - 2023-01-14 16:49:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-01-14 16:49:17 --> Session: Class initialized using 'files' driver.
INFO - 2023-01-14 16:49:17 --> Controller Class Initialized
INFO - 2023-01-14 16:49:17 --> Config Class Initialized
INFO - 2023-01-14 16:49:17 --> Hooks Class Initialized
DEBUG - 2023-01-14 16:49:17 --> UTF-8 Support Enabled
INFO - 2023-01-14 16:49:17 --> Utf8 Class Initialized
INFO - 2023-01-14 16:49:17 --> URI Class Initialized
INFO - 2023-01-14 16:49:17 --> Router Class Initialized
INFO - 2023-01-14 16:49:17 --> Output Class Initialized
INFO - 2023-01-14 16:49:17 --> Security Class Initialized
DEBUG - 2023-01-14 16:49:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-14 16:49:17 --> Input Class Initialized
INFO - 2023-01-14 16:49:17 --> Language Class Initialized
INFO - 2023-01-14 16:49:17 --> Language Class Initialized
INFO - 2023-01-14 16:49:17 --> Config Class Initialized
INFO - 2023-01-14 16:49:17 --> Loader Class Initialized
INFO - 2023-01-14 16:49:17 --> Helper loaded: url_helper
INFO - 2023-01-14 16:49:17 --> Helper loaded: file_helper
INFO - 2023-01-14 16:49:17 --> Helper loaded: form_helper
INFO - 2023-01-14 16:49:17 --> Helper loaded: my_helper
INFO - 2023-01-14 16:49:17 --> Database Driver Class Initialized
DEBUG - 2023-01-14 16:49:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-01-14 16:49:17 --> Session: Class initialized using 'files' driver.
INFO - 2023-01-14 16:49:17 --> Controller Class Initialized
DEBUG - 2023-01-14 16:49:17 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/login/views/login.php
DEBUG - 2023-01-14 16:49:17 --> File loaded: C:\xampp\htdocs\myraportk13\application\views\template_utama.php
INFO - 2023-01-14 16:49:17 --> Final output sent to browser
DEBUG - 2023-01-14 16:49:17 --> Total execution time: 0.0512
INFO - 2023-01-14 16:49:38 --> Config Class Initialized
INFO - 2023-01-14 16:49:38 --> Hooks Class Initialized
DEBUG - 2023-01-14 16:49:38 --> UTF-8 Support Enabled
INFO - 2023-01-14 16:49:38 --> Utf8 Class Initialized
INFO - 2023-01-14 16:49:38 --> URI Class Initialized
INFO - 2023-01-14 16:49:38 --> Router Class Initialized
INFO - 2023-01-14 16:49:38 --> Output Class Initialized
INFO - 2023-01-14 16:49:38 --> Security Class Initialized
DEBUG - 2023-01-14 16:49:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-14 16:49:38 --> Input Class Initialized
INFO - 2023-01-14 16:49:38 --> Language Class Initialized
INFO - 2023-01-14 16:49:38 --> Language Class Initialized
INFO - 2023-01-14 16:49:38 --> Config Class Initialized
INFO - 2023-01-14 16:49:38 --> Loader Class Initialized
INFO - 2023-01-14 16:49:38 --> Helper loaded: url_helper
INFO - 2023-01-14 16:49:38 --> Helper loaded: file_helper
INFO - 2023-01-14 16:49:38 --> Helper loaded: form_helper
INFO - 2023-01-14 16:49:38 --> Helper loaded: my_helper
INFO - 2023-01-14 16:49:38 --> Database Driver Class Initialized
DEBUG - 2023-01-14 16:49:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-01-14 16:49:38 --> Session: Class initialized using 'files' driver.
INFO - 2023-01-14 16:49:38 --> Controller Class Initialized
INFO - 2023-01-14 16:49:38 --> Helper loaded: cookie_helper
INFO - 2023-01-14 16:49:38 --> Final output sent to browser
DEBUG - 2023-01-14 16:49:38 --> Total execution time: 0.0674
INFO - 2023-01-14 16:49:38 --> Config Class Initialized
INFO - 2023-01-14 16:49:38 --> Hooks Class Initialized
DEBUG - 2023-01-14 16:49:38 --> UTF-8 Support Enabled
INFO - 2023-01-14 16:49:38 --> Utf8 Class Initialized
INFO - 2023-01-14 16:49:38 --> URI Class Initialized
INFO - 2023-01-14 16:49:38 --> Router Class Initialized
INFO - 2023-01-14 16:49:38 --> Output Class Initialized
INFO - 2023-01-14 16:49:38 --> Security Class Initialized
DEBUG - 2023-01-14 16:49:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-14 16:49:38 --> Input Class Initialized
INFO - 2023-01-14 16:49:38 --> Language Class Initialized
INFO - 2023-01-14 16:49:38 --> Language Class Initialized
INFO - 2023-01-14 16:49:38 --> Config Class Initialized
INFO - 2023-01-14 16:49:38 --> Loader Class Initialized
INFO - 2023-01-14 16:49:38 --> Helper loaded: url_helper
INFO - 2023-01-14 16:49:38 --> Helper loaded: file_helper
INFO - 2023-01-14 16:49:38 --> Helper loaded: form_helper
INFO - 2023-01-14 16:49:38 --> Helper loaded: my_helper
INFO - 2023-01-14 16:49:38 --> Database Driver Class Initialized
DEBUG - 2023-01-14 16:49:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-01-14 16:49:38 --> Session: Class initialized using 'files' driver.
INFO - 2023-01-14 16:49:38 --> Controller Class Initialized
DEBUG - 2023-01-14 16:49:38 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/home/views/v_home_guru.php
DEBUG - 2023-01-14 16:49:38 --> File loaded: C:\xampp\htdocs\myraportk13\application\views\template_utama.php
INFO - 2023-01-14 16:49:38 --> Final output sent to browser
DEBUG - 2023-01-14 16:49:38 --> Total execution time: 0.0449
INFO - 2023-01-14 16:49:41 --> Config Class Initialized
INFO - 2023-01-14 16:49:41 --> Hooks Class Initialized
DEBUG - 2023-01-14 16:49:41 --> UTF-8 Support Enabled
INFO - 2023-01-14 16:49:41 --> Utf8 Class Initialized
INFO - 2023-01-14 16:49:41 --> URI Class Initialized
INFO - 2023-01-14 16:49:41 --> Router Class Initialized
INFO - 2023-01-14 16:49:41 --> Output Class Initialized
INFO - 2023-01-14 16:49:41 --> Security Class Initialized
DEBUG - 2023-01-14 16:49:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-14 16:49:41 --> Input Class Initialized
INFO - 2023-01-14 16:49:41 --> Language Class Initialized
INFO - 2023-01-14 16:49:41 --> Language Class Initialized
INFO - 2023-01-14 16:49:41 --> Config Class Initialized
INFO - 2023-01-14 16:49:41 --> Loader Class Initialized
INFO - 2023-01-14 16:49:41 --> Helper loaded: url_helper
INFO - 2023-01-14 16:49:41 --> Helper loaded: file_helper
INFO - 2023-01-14 16:49:41 --> Helper loaded: form_helper
INFO - 2023-01-14 16:49:41 --> Helper loaded: my_helper
INFO - 2023-01-14 16:49:41 --> Database Driver Class Initialized
DEBUG - 2023-01-14 16:49:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-01-14 16:49:41 --> Session: Class initialized using 'files' driver.
INFO - 2023-01-14 16:49:41 --> Controller Class Initialized
DEBUG - 2023-01-14 16:49:41 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/cetak_raport/views/list.php
DEBUG - 2023-01-14 16:49:41 --> File loaded: C:\xampp\htdocs\myraportk13\application\views\template_utama.php
INFO - 2023-01-14 16:49:41 --> Final output sent to browser
DEBUG - 2023-01-14 16:49:41 --> Total execution time: 0.0925
INFO - 2023-01-14 16:49:44 --> Config Class Initialized
INFO - 2023-01-14 16:49:44 --> Hooks Class Initialized
DEBUG - 2023-01-14 16:49:44 --> UTF-8 Support Enabled
INFO - 2023-01-14 16:49:44 --> Utf8 Class Initialized
INFO - 2023-01-14 16:49:44 --> URI Class Initialized
INFO - 2023-01-14 16:49:44 --> Router Class Initialized
INFO - 2023-01-14 16:49:44 --> Output Class Initialized
INFO - 2023-01-14 16:49:44 --> Security Class Initialized
DEBUG - 2023-01-14 16:49:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-14 16:49:44 --> Input Class Initialized
INFO - 2023-01-14 16:49:44 --> Language Class Initialized
INFO - 2023-01-14 16:49:44 --> Language Class Initialized
INFO - 2023-01-14 16:49:44 --> Config Class Initialized
INFO - 2023-01-14 16:49:44 --> Loader Class Initialized
INFO - 2023-01-14 16:49:44 --> Helper loaded: url_helper
INFO - 2023-01-14 16:49:44 --> Helper loaded: file_helper
INFO - 2023-01-14 16:49:44 --> Helper loaded: form_helper
INFO - 2023-01-14 16:49:44 --> Helper loaded: my_helper
INFO - 2023-01-14 16:49:44 --> Database Driver Class Initialized
DEBUG - 2023-01-14 16:49:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-01-14 16:49:44 --> Session: Class initialized using 'files' driver.
INFO - 2023-01-14 16:49:44 --> Controller Class Initialized
DEBUG - 2023-01-14 16:49:44 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/cetak_raport/views/cetak_mh.php
INFO - 2023-01-14 16:49:47 --> Final output sent to browser
DEBUG - 2023-01-14 16:49:47 --> Total execution time: 2.4789
INFO - 2023-01-14 16:50:15 --> Config Class Initialized
INFO - 2023-01-14 16:50:15 --> Hooks Class Initialized
DEBUG - 2023-01-14 16:50:15 --> UTF-8 Support Enabled
INFO - 2023-01-14 16:50:15 --> Utf8 Class Initialized
INFO - 2023-01-14 16:50:15 --> URI Class Initialized
INFO - 2023-01-14 16:50:15 --> Router Class Initialized
INFO - 2023-01-14 16:50:15 --> Output Class Initialized
INFO - 2023-01-14 16:50:15 --> Security Class Initialized
DEBUG - 2023-01-14 16:50:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-14 16:50:15 --> Input Class Initialized
INFO - 2023-01-14 16:50:15 --> Language Class Initialized
INFO - 2023-01-14 16:50:15 --> Language Class Initialized
INFO - 2023-01-14 16:50:15 --> Config Class Initialized
INFO - 2023-01-14 16:50:15 --> Loader Class Initialized
INFO - 2023-01-14 16:50:15 --> Helper loaded: url_helper
INFO - 2023-01-14 16:50:15 --> Helper loaded: file_helper
INFO - 2023-01-14 16:50:15 --> Helper loaded: form_helper
INFO - 2023-01-14 16:50:15 --> Helper loaded: my_helper
INFO - 2023-01-14 16:50:15 --> Database Driver Class Initialized
DEBUG - 2023-01-14 16:50:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-01-14 16:50:15 --> Session: Class initialized using 'files' driver.
INFO - 2023-01-14 16:50:15 --> Controller Class Initialized
DEBUG - 2023-01-14 16:50:15 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/view_mapel/views/v_view_mapel.php
DEBUG - 2023-01-14 16:50:15 --> File loaded: C:\xampp\htdocs\myraportk13\application\views\template_utama.php
INFO - 2023-01-14 16:50:15 --> Final output sent to browser
DEBUG - 2023-01-14 16:50:15 --> Total execution time: 0.0355
INFO - 2023-01-14 16:50:18 --> Config Class Initialized
INFO - 2023-01-14 16:50:18 --> Hooks Class Initialized
DEBUG - 2023-01-14 16:50:18 --> UTF-8 Support Enabled
INFO - 2023-01-14 16:50:18 --> Utf8 Class Initialized
INFO - 2023-01-14 16:50:18 --> URI Class Initialized
INFO - 2023-01-14 16:50:18 --> Router Class Initialized
INFO - 2023-01-14 16:50:18 --> Output Class Initialized
INFO - 2023-01-14 16:50:18 --> Security Class Initialized
DEBUG - 2023-01-14 16:50:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-14 16:50:18 --> Input Class Initialized
INFO - 2023-01-14 16:50:18 --> Language Class Initialized
INFO - 2023-01-14 16:50:18 --> Language Class Initialized
INFO - 2023-01-14 16:50:18 --> Config Class Initialized
INFO - 2023-01-14 16:50:18 --> Loader Class Initialized
INFO - 2023-01-14 16:50:18 --> Helper loaded: url_helper
INFO - 2023-01-14 16:50:18 --> Helper loaded: file_helper
INFO - 2023-01-14 16:50:18 --> Helper loaded: form_helper
INFO - 2023-01-14 16:50:18 --> Helper loaded: my_helper
INFO - 2023-01-14 16:50:18 --> Database Driver Class Initialized
DEBUG - 2023-01-14 16:50:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-01-14 16:50:18 --> Session: Class initialized using 'files' driver.
INFO - 2023-01-14 16:50:18 --> Controller Class Initialized
DEBUG - 2023-01-14 16:50:18 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/n_icb/views/list.php
DEBUG - 2023-01-14 16:50:18 --> File loaded: C:\xampp\htdocs\myraportk13\application\views\template_utama.php
INFO - 2023-01-14 16:50:18 --> Final output sent to browser
DEBUG - 2023-01-14 16:50:18 --> Total execution time: 0.0570
INFO - 2023-01-14 16:50:18 --> Config Class Initialized
INFO - 2023-01-14 16:50:18 --> Hooks Class Initialized
DEBUG - 2023-01-14 16:50:18 --> UTF-8 Support Enabled
INFO - 2023-01-14 16:50:18 --> Utf8 Class Initialized
INFO - 2023-01-14 16:50:18 --> URI Class Initialized
INFO - 2023-01-14 16:50:18 --> Router Class Initialized
INFO - 2023-01-14 16:50:18 --> Output Class Initialized
INFO - 2023-01-14 16:50:18 --> Security Class Initialized
DEBUG - 2023-01-14 16:50:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-14 16:50:18 --> Input Class Initialized
INFO - 2023-01-14 16:50:18 --> Language Class Initialized
INFO - 2023-01-14 16:50:18 --> Language Class Initialized
INFO - 2023-01-14 16:50:18 --> Config Class Initialized
INFO - 2023-01-14 16:50:18 --> Loader Class Initialized
INFO - 2023-01-14 16:50:18 --> Helper loaded: url_helper
INFO - 2023-01-14 16:50:18 --> Helper loaded: file_helper
INFO - 2023-01-14 16:50:18 --> Helper loaded: form_helper
INFO - 2023-01-14 16:50:18 --> Helper loaded: my_helper
INFO - 2023-01-14 16:50:18 --> Database Driver Class Initialized
DEBUG - 2023-01-14 16:50:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-01-14 16:50:18 --> Session: Class initialized using 'files' driver.
INFO - 2023-01-14 16:50:18 --> Controller Class Initialized
INFO - 2023-01-14 16:50:41 --> Config Class Initialized
INFO - 2023-01-14 16:50:41 --> Hooks Class Initialized
DEBUG - 2023-01-14 16:50:41 --> UTF-8 Support Enabled
INFO - 2023-01-14 16:50:41 --> Utf8 Class Initialized
INFO - 2023-01-14 16:50:41 --> URI Class Initialized
INFO - 2023-01-14 16:50:41 --> Router Class Initialized
INFO - 2023-01-14 16:50:41 --> Output Class Initialized
INFO - 2023-01-14 16:50:41 --> Security Class Initialized
DEBUG - 2023-01-14 16:50:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-14 16:50:41 --> Input Class Initialized
INFO - 2023-01-14 16:50:41 --> Language Class Initialized
INFO - 2023-01-14 16:50:41 --> Language Class Initialized
INFO - 2023-01-14 16:50:41 --> Config Class Initialized
INFO - 2023-01-14 16:50:41 --> Loader Class Initialized
INFO - 2023-01-14 16:50:41 --> Helper loaded: url_helper
INFO - 2023-01-14 16:50:41 --> Helper loaded: file_helper
INFO - 2023-01-14 16:50:41 --> Helper loaded: form_helper
INFO - 2023-01-14 16:50:41 --> Helper loaded: my_helper
INFO - 2023-01-14 16:50:41 --> Database Driver Class Initialized
DEBUG - 2023-01-14 16:50:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-01-14 16:50:41 --> Session: Class initialized using 'files' driver.
INFO - 2023-01-14 16:50:41 --> Controller Class Initialized
INFO - 2023-01-14 16:50:41 --> Final output sent to browser
DEBUG - 2023-01-14 16:50:41 --> Total execution time: 0.0707
INFO - 2023-01-14 16:50:46 --> Config Class Initialized
INFO - 2023-01-14 16:50:46 --> Hooks Class Initialized
DEBUG - 2023-01-14 16:50:46 --> UTF-8 Support Enabled
INFO - 2023-01-14 16:50:46 --> Utf8 Class Initialized
INFO - 2023-01-14 16:50:46 --> URI Class Initialized
INFO - 2023-01-14 16:50:46 --> Router Class Initialized
INFO - 2023-01-14 16:50:46 --> Output Class Initialized
INFO - 2023-01-14 16:50:46 --> Security Class Initialized
DEBUG - 2023-01-14 16:50:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-14 16:50:46 --> Input Class Initialized
INFO - 2023-01-14 16:50:46 --> Language Class Initialized
INFO - 2023-01-14 16:50:46 --> Language Class Initialized
INFO - 2023-01-14 16:50:46 --> Config Class Initialized
INFO - 2023-01-14 16:50:46 --> Loader Class Initialized
INFO - 2023-01-14 16:50:46 --> Helper loaded: url_helper
INFO - 2023-01-14 16:50:46 --> Helper loaded: file_helper
INFO - 2023-01-14 16:50:46 --> Helper loaded: form_helper
INFO - 2023-01-14 16:50:46 --> Helper loaded: my_helper
INFO - 2023-01-14 16:50:46 --> Database Driver Class Initialized
DEBUG - 2023-01-14 16:50:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-01-14 16:50:46 --> Session: Class initialized using 'files' driver.
INFO - 2023-01-14 16:50:46 --> Controller Class Initialized
INFO - 2023-01-14 16:50:46 --> Final output sent to browser
DEBUG - 2023-01-14 16:50:46 --> Total execution time: 0.0569
INFO - 2023-01-14 16:50:46 --> Config Class Initialized
INFO - 2023-01-14 16:50:46 --> Hooks Class Initialized
DEBUG - 2023-01-14 16:50:46 --> UTF-8 Support Enabled
INFO - 2023-01-14 16:50:46 --> Utf8 Class Initialized
INFO - 2023-01-14 16:50:46 --> URI Class Initialized
INFO - 2023-01-14 16:50:46 --> Router Class Initialized
INFO - 2023-01-14 16:50:46 --> Output Class Initialized
INFO - 2023-01-14 16:50:46 --> Security Class Initialized
DEBUG - 2023-01-14 16:50:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-14 16:50:46 --> Input Class Initialized
INFO - 2023-01-14 16:50:46 --> Language Class Initialized
INFO - 2023-01-14 16:50:46 --> Language Class Initialized
INFO - 2023-01-14 16:50:46 --> Config Class Initialized
INFO - 2023-01-14 16:50:46 --> Loader Class Initialized
INFO - 2023-01-14 16:50:46 --> Helper loaded: url_helper
INFO - 2023-01-14 16:50:46 --> Helper loaded: file_helper
INFO - 2023-01-14 16:50:46 --> Helper loaded: form_helper
INFO - 2023-01-14 16:50:46 --> Helper loaded: my_helper
INFO - 2023-01-14 16:50:46 --> Database Driver Class Initialized
DEBUG - 2023-01-14 16:50:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-01-14 16:50:46 --> Session: Class initialized using 'files' driver.
INFO - 2023-01-14 16:50:46 --> Controller Class Initialized
INFO - 2023-01-14 16:50:47 --> Config Class Initialized
INFO - 2023-01-14 16:50:47 --> Hooks Class Initialized
DEBUG - 2023-01-14 16:50:47 --> UTF-8 Support Enabled
INFO - 2023-01-14 16:50:47 --> Utf8 Class Initialized
INFO - 2023-01-14 16:50:47 --> URI Class Initialized
INFO - 2023-01-14 16:50:47 --> Router Class Initialized
INFO - 2023-01-14 16:50:47 --> Output Class Initialized
INFO - 2023-01-14 16:50:47 --> Security Class Initialized
DEBUG - 2023-01-14 16:50:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-14 16:50:47 --> Input Class Initialized
INFO - 2023-01-14 16:50:47 --> Language Class Initialized
INFO - 2023-01-14 16:50:47 --> Language Class Initialized
INFO - 2023-01-14 16:50:47 --> Config Class Initialized
INFO - 2023-01-14 16:50:48 --> Loader Class Initialized
INFO - 2023-01-14 16:50:48 --> Helper loaded: url_helper
INFO - 2023-01-14 16:50:48 --> Helper loaded: file_helper
INFO - 2023-01-14 16:50:48 --> Helper loaded: form_helper
INFO - 2023-01-14 16:50:48 --> Helper loaded: my_helper
INFO - 2023-01-14 16:50:48 --> Database Driver Class Initialized
DEBUG - 2023-01-14 16:50:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-01-14 16:50:48 --> Session: Class initialized using 'files' driver.
INFO - 2023-01-14 16:50:48 --> Controller Class Initialized
INFO - 2023-01-14 16:50:48 --> Final output sent to browser
DEBUG - 2023-01-14 16:50:48 --> Total execution time: 0.0678
INFO - 2023-01-14 16:50:53 --> Config Class Initialized
INFO - 2023-01-14 16:50:53 --> Hooks Class Initialized
DEBUG - 2023-01-14 16:50:53 --> UTF-8 Support Enabled
INFO - 2023-01-14 16:50:53 --> Utf8 Class Initialized
INFO - 2023-01-14 16:50:53 --> URI Class Initialized
INFO - 2023-01-14 16:50:53 --> Router Class Initialized
INFO - 2023-01-14 16:50:53 --> Output Class Initialized
INFO - 2023-01-14 16:50:53 --> Security Class Initialized
DEBUG - 2023-01-14 16:50:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-14 16:50:53 --> Input Class Initialized
INFO - 2023-01-14 16:50:53 --> Language Class Initialized
INFO - 2023-01-14 16:50:53 --> Language Class Initialized
INFO - 2023-01-14 16:50:53 --> Config Class Initialized
INFO - 2023-01-14 16:50:53 --> Loader Class Initialized
INFO - 2023-01-14 16:50:53 --> Helper loaded: url_helper
INFO - 2023-01-14 16:50:53 --> Helper loaded: file_helper
INFO - 2023-01-14 16:50:53 --> Helper loaded: form_helper
INFO - 2023-01-14 16:50:53 --> Helper loaded: my_helper
INFO - 2023-01-14 16:50:53 --> Database Driver Class Initialized
DEBUG - 2023-01-14 16:50:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-01-14 16:50:53 --> Session: Class initialized using 'files' driver.
INFO - 2023-01-14 16:50:53 --> Controller Class Initialized
INFO - 2023-01-14 16:50:53 --> Final output sent to browser
DEBUG - 2023-01-14 16:50:53 --> Total execution time: 0.0619
INFO - 2023-01-14 16:57:52 --> Config Class Initialized
INFO - 2023-01-14 16:57:52 --> Hooks Class Initialized
DEBUG - 2023-01-14 16:57:52 --> UTF-8 Support Enabled
INFO - 2023-01-14 16:57:52 --> Utf8 Class Initialized
INFO - 2023-01-14 16:57:52 --> URI Class Initialized
INFO - 2023-01-14 16:57:52 --> Router Class Initialized
INFO - 2023-01-14 16:57:52 --> Output Class Initialized
INFO - 2023-01-14 16:57:52 --> Security Class Initialized
DEBUG - 2023-01-14 16:57:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-14 16:57:52 --> Input Class Initialized
INFO - 2023-01-14 16:57:52 --> Language Class Initialized
INFO - 2023-01-14 16:57:52 --> Language Class Initialized
INFO - 2023-01-14 16:57:52 --> Config Class Initialized
INFO - 2023-01-14 16:57:52 --> Loader Class Initialized
INFO - 2023-01-14 16:57:52 --> Helper loaded: url_helper
INFO - 2023-01-14 16:57:52 --> Helper loaded: file_helper
INFO - 2023-01-14 16:57:52 --> Helper loaded: form_helper
INFO - 2023-01-14 16:57:52 --> Helper loaded: my_helper
INFO - 2023-01-14 16:57:52 --> Database Driver Class Initialized
DEBUG - 2023-01-14 16:57:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-01-14 16:57:52 --> Session: Class initialized using 'files' driver.
INFO - 2023-01-14 16:57:52 --> Controller Class Initialized
DEBUG - 2023-01-14 16:57:52 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/cetak_raport/views/cetak_mh.php
INFO - 2023-01-14 16:57:54 --> Final output sent to browser
DEBUG - 2023-01-14 16:57:54 --> Total execution time: 1.5044
INFO - 2023-01-14 17:01:32 --> Config Class Initialized
INFO - 2023-01-14 17:01:32 --> Hooks Class Initialized
DEBUG - 2023-01-14 17:01:32 --> UTF-8 Support Enabled
INFO - 2023-01-14 17:01:32 --> Utf8 Class Initialized
INFO - 2023-01-14 17:01:32 --> URI Class Initialized
INFO - 2023-01-14 17:01:32 --> Router Class Initialized
INFO - 2023-01-14 17:01:32 --> Output Class Initialized
INFO - 2023-01-14 17:01:32 --> Security Class Initialized
DEBUG - 2023-01-14 17:01:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-14 17:01:32 --> Input Class Initialized
INFO - 2023-01-14 17:01:32 --> Language Class Initialized
INFO - 2023-01-14 17:01:32 --> Language Class Initialized
INFO - 2023-01-14 17:01:32 --> Config Class Initialized
INFO - 2023-01-14 17:01:32 --> Loader Class Initialized
INFO - 2023-01-14 17:01:32 --> Helper loaded: url_helper
INFO - 2023-01-14 17:01:32 --> Helper loaded: file_helper
INFO - 2023-01-14 17:01:32 --> Helper loaded: form_helper
INFO - 2023-01-14 17:01:32 --> Helper loaded: my_helper
INFO - 2023-01-14 17:01:32 --> Database Driver Class Initialized
DEBUG - 2023-01-14 17:01:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-01-14 17:01:32 --> Session: Class initialized using 'files' driver.
INFO - 2023-01-14 17:01:32 --> Controller Class Initialized
ERROR - 2023-01-14 17:01:32 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\myraportk13\application\modules\cetak_raport\controllers\Cetak_raport.php 1093
ERROR - 2023-01-14 17:01:32 --> Severity: Notice --> Undefined variable: Array C:\xampp\htdocs\myraportk13\application\modules\cetak_raport\controllers\Cetak_raport.php 1093
ERROR - 2023-01-14 17:01:32 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\myraportk13\application\modules\cetak_raport\controllers\Cetak_raport.php 1093
ERROR - 2023-01-14 17:01:32 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\myraportk13\application\modules\cetak_raport\controllers\Cetak_raport.php 1093
ERROR - 2023-01-14 17:01:32 --> Severity: Notice --> Undefined offset: 1 C:\xampp\htdocs\myraportk13\application\modules\cetak_raport\controllers\Cetak_raport.php 1094
DEBUG - 2023-01-14 17:01:32 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/cetak_raport/views/cetak_mh.php
INFO - 2023-01-14 17:01:34 --> Final output sent to browser
DEBUG - 2023-01-14 17:01:34 --> Total execution time: 1.5494
INFO - 2023-01-14 17:02:25 --> Config Class Initialized
INFO - 2023-01-14 17:02:25 --> Hooks Class Initialized
DEBUG - 2023-01-14 17:02:25 --> UTF-8 Support Enabled
INFO - 2023-01-14 17:02:25 --> Utf8 Class Initialized
INFO - 2023-01-14 17:02:25 --> URI Class Initialized
INFO - 2023-01-14 17:02:25 --> Router Class Initialized
INFO - 2023-01-14 17:02:25 --> Output Class Initialized
INFO - 2023-01-14 17:02:25 --> Security Class Initialized
DEBUG - 2023-01-14 17:02:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-14 17:02:25 --> Input Class Initialized
INFO - 2023-01-14 17:02:25 --> Language Class Initialized
INFO - 2023-01-14 17:02:25 --> Language Class Initialized
INFO - 2023-01-14 17:02:25 --> Config Class Initialized
INFO - 2023-01-14 17:02:25 --> Loader Class Initialized
INFO - 2023-01-14 17:02:25 --> Helper loaded: url_helper
INFO - 2023-01-14 17:02:25 --> Helper loaded: file_helper
INFO - 2023-01-14 17:02:25 --> Helper loaded: form_helper
INFO - 2023-01-14 17:02:25 --> Helper loaded: my_helper
INFO - 2023-01-14 17:02:25 --> Database Driver Class Initialized
DEBUG - 2023-01-14 17:02:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-01-14 17:02:25 --> Session: Class initialized using 'files' driver.
INFO - 2023-01-14 17:02:25 --> Controller Class Initialized
ERROR - 2023-01-14 17:02:25 --> Severity: Notice --> Undefined variable: pc_nilai_icb C:\xampp\htdocs\myraportk13\application\modules\cetak_raport\controllers\Cetak_raport.php 1096
ERROR - 2023-01-14 17:02:25 --> Severity: Notice --> Undefined variable:  C:\xampp\htdocs\myraportk13\application\modules\cetak_raport\controllers\Cetak_raport.php 1096
ERROR - 2023-01-14 17:02:25 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\myraportk13\application\modules\cetak_raport\controllers\Cetak_raport.php 1096
ERROR - 2023-01-14 17:02:25 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\myraportk13\application\modules\cetak_raport\controllers\Cetak_raport.php 1093
ERROR - 2023-01-14 17:02:25 --> Severity: Notice --> Undefined variable: Array C:\xampp\htdocs\myraportk13\application\modules\cetak_raport\controllers\Cetak_raport.php 1093
ERROR - 2023-01-14 17:02:25 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\myraportk13\application\modules\cetak_raport\controllers\Cetak_raport.php 1093
ERROR - 2023-01-14 17:02:25 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\myraportk13\application\modules\cetak_raport\controllers\Cetak_raport.php 1093
ERROR - 2023-01-14 17:02:25 --> Severity: Notice --> Undefined offset: 1 C:\xampp\htdocs\myraportk13\application\modules\cetak_raport\controllers\Cetak_raport.php 1094
ERROR - 2023-01-14 17:02:25 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\myraportk13\application\modules\cetak_raport\controllers\Cetak_raport.php 1096
ERROR - 2023-01-14 17:02:25 --> Severity: Notice --> Undefined variable: Array C:\xampp\htdocs\myraportk13\application\modules\cetak_raport\controllers\Cetak_raport.php 1096
ERROR - 2023-01-14 17:02:25 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\myraportk13\application\modules\cetak_raport\controllers\Cetak_raport.php 1096
DEBUG - 2023-01-14 17:02:25 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/cetak_raport/views/cetak_mh.php
INFO - 2023-01-14 17:02:27 --> Final output sent to browser
DEBUG - 2023-01-14 17:02:27 --> Total execution time: 1.5749
INFO - 2023-01-14 17:02:46 --> Config Class Initialized
INFO - 2023-01-14 17:02:46 --> Hooks Class Initialized
DEBUG - 2023-01-14 17:02:46 --> UTF-8 Support Enabled
INFO - 2023-01-14 17:02:46 --> Utf8 Class Initialized
INFO - 2023-01-14 17:02:46 --> URI Class Initialized
INFO - 2023-01-14 17:02:46 --> Router Class Initialized
INFO - 2023-01-14 17:02:46 --> Output Class Initialized
INFO - 2023-01-14 17:02:46 --> Security Class Initialized
DEBUG - 2023-01-14 17:02:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-14 17:02:46 --> Input Class Initialized
INFO - 2023-01-14 17:02:46 --> Language Class Initialized
INFO - 2023-01-14 17:02:46 --> Language Class Initialized
INFO - 2023-01-14 17:02:46 --> Config Class Initialized
INFO - 2023-01-14 17:02:46 --> Loader Class Initialized
INFO - 2023-01-14 17:02:46 --> Helper loaded: url_helper
INFO - 2023-01-14 17:02:46 --> Helper loaded: file_helper
INFO - 2023-01-14 17:02:46 --> Helper loaded: form_helper
INFO - 2023-01-14 17:02:46 --> Helper loaded: my_helper
INFO - 2023-01-14 17:02:46 --> Database Driver Class Initialized
DEBUG - 2023-01-14 17:02:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-01-14 17:02:46 --> Session: Class initialized using 'files' driver.
INFO - 2023-01-14 17:02:46 --> Controller Class Initialized
ERROR - 2023-01-14 17:02:46 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\myraportk13\application\modules\cetak_raport\controllers\Cetak_raport.php 1093
ERROR - 2023-01-14 17:02:46 --> Severity: Notice --> Undefined variable: Array C:\xampp\htdocs\myraportk13\application\modules\cetak_raport\controllers\Cetak_raport.php 1093
ERROR - 2023-01-14 17:02:46 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\myraportk13\application\modules\cetak_raport\controllers\Cetak_raport.php 1093
ERROR - 2023-01-14 17:02:46 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\myraportk13\application\modules\cetak_raport\controllers\Cetak_raport.php 1093
ERROR - 2023-01-14 17:02:46 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\myraportk13\application\modules\cetak_raport\controllers\Cetak_raport.php 1094
ERROR - 2023-01-14 17:02:46 --> Severity: Notice --> Undefined variable: Array C:\xampp\htdocs\myraportk13\application\modules\cetak_raport\controllers\Cetak_raport.php 1094
ERROR - 2023-01-14 17:02:46 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\myraportk13\application\modules\cetak_raport\controllers\Cetak_raport.php 1094
DEBUG - 2023-01-14 17:02:46 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/cetak_raport/views/cetak_mh.php
INFO - 2023-01-14 17:02:48 --> Final output sent to browser
DEBUG - 2023-01-14 17:02:48 --> Total execution time: 1.4817
INFO - 2023-01-14 17:03:48 --> Config Class Initialized
INFO - 2023-01-14 17:03:48 --> Hooks Class Initialized
DEBUG - 2023-01-14 17:03:48 --> UTF-8 Support Enabled
INFO - 2023-01-14 17:03:48 --> Utf8 Class Initialized
INFO - 2023-01-14 17:03:48 --> URI Class Initialized
INFO - 2023-01-14 17:03:48 --> Router Class Initialized
INFO - 2023-01-14 17:03:48 --> Output Class Initialized
INFO - 2023-01-14 17:03:48 --> Security Class Initialized
DEBUG - 2023-01-14 17:03:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-14 17:03:48 --> Input Class Initialized
INFO - 2023-01-14 17:03:48 --> Language Class Initialized
INFO - 2023-01-14 17:03:48 --> Language Class Initialized
INFO - 2023-01-14 17:03:48 --> Config Class Initialized
INFO - 2023-01-14 17:03:48 --> Loader Class Initialized
INFO - 2023-01-14 17:03:48 --> Helper loaded: url_helper
INFO - 2023-01-14 17:03:48 --> Helper loaded: file_helper
INFO - 2023-01-14 17:03:48 --> Helper loaded: form_helper
INFO - 2023-01-14 17:03:48 --> Helper loaded: my_helper
INFO - 2023-01-14 17:03:48 --> Database Driver Class Initialized
DEBUG - 2023-01-14 17:03:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-01-14 17:03:48 --> Session: Class initialized using 'files' driver.
INFO - 2023-01-14 17:03:48 --> Controller Class Initialized
ERROR - 2023-01-14 17:03:48 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\myraportk13\application\modules\cetak_raport\controllers\Cetak_raport.php 1093
ERROR - 2023-01-14 17:03:48 --> Severity: Notice --> Undefined variable: Array C:\xampp\htdocs\myraportk13\application\modules\cetak_raport\controllers\Cetak_raport.php 1093
ERROR - 2023-01-14 17:03:48 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\myraportk13\application\modules\cetak_raport\controllers\Cetak_raport.php 1093
ERROR - 2023-01-14 17:03:48 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\myraportk13\application\modules\cetak_raport\controllers\Cetak_raport.php 1093
ERROR - 2023-01-14 17:03:48 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\myraportk13\application\modules\cetak_raport\controllers\Cetak_raport.php 1093
ERROR - 2023-01-14 17:03:48 --> Severity: Notice --> Undefined offset: 1 C:\xampp\htdocs\myraportk13\application\modules\cetak_raport\controllers\Cetak_raport.php 1094
DEBUG - 2023-01-14 17:03:48 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/cetak_raport/views/cetak_mh.php
INFO - 2023-01-14 17:03:50 --> Final output sent to browser
DEBUG - 2023-01-14 17:03:50 --> Total execution time: 1.5347
INFO - 2023-01-14 17:04:59 --> Config Class Initialized
INFO - 2023-01-14 17:04:59 --> Hooks Class Initialized
DEBUG - 2023-01-14 17:04:59 --> UTF-8 Support Enabled
INFO - 2023-01-14 17:04:59 --> Utf8 Class Initialized
INFO - 2023-01-14 17:04:59 --> URI Class Initialized
INFO - 2023-01-14 17:04:59 --> Router Class Initialized
INFO - 2023-01-14 17:04:59 --> Output Class Initialized
INFO - 2023-01-14 17:04:59 --> Security Class Initialized
DEBUG - 2023-01-14 17:04:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-14 17:04:59 --> Input Class Initialized
INFO - 2023-01-14 17:04:59 --> Language Class Initialized
INFO - 2023-01-14 17:04:59 --> Language Class Initialized
INFO - 2023-01-14 17:04:59 --> Config Class Initialized
INFO - 2023-01-14 17:04:59 --> Loader Class Initialized
INFO - 2023-01-14 17:04:59 --> Helper loaded: url_helper
INFO - 2023-01-14 17:04:59 --> Helper loaded: file_helper
INFO - 2023-01-14 17:04:59 --> Helper loaded: form_helper
INFO - 2023-01-14 17:04:59 --> Helper loaded: my_helper
INFO - 2023-01-14 17:04:59 --> Database Driver Class Initialized
DEBUG - 2023-01-14 17:04:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-01-14 17:04:59 --> Session: Class initialized using 'files' driver.
INFO - 2023-01-14 17:04:59 --> Controller Class Initialized
ERROR - 2023-01-14 17:04:59 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\myraportk13\application\modules\cetak_raport\controllers\Cetak_raport.php 1093
ERROR - 2023-01-14 17:04:59 --> Severity: Notice --> Undefined variable: Array C:\xampp\htdocs\myraportk13\application\modules\cetak_raport\controllers\Cetak_raport.php 1093
ERROR - 2023-01-14 17:04:59 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\myraportk13\application\modules\cetak_raport\controllers\Cetak_raport.php 1093
ERROR - 2023-01-14 17:04:59 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\myraportk13\application\modules\cetak_raport\controllers\Cetak_raport.php 1093
ERROR - 2023-01-14 17:04:59 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\myraportk13\application\modules\cetak_raport\controllers\Cetak_raport.php 1093
ERROR - 2023-01-14 17:04:59 --> Severity: Notice --> Undefined offset: 1 C:\xampp\htdocs\myraportk13\application\modules\cetak_raport\controllers\Cetak_raport.php 1094
DEBUG - 2023-01-14 17:04:59 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/cetak_raport/views/cetak_mh.php
INFO - 2023-01-14 17:05:00 --> Final output sent to browser
DEBUG - 2023-01-14 17:05:00 --> Total execution time: 1.4363
INFO - 2023-01-14 17:05:30 --> Config Class Initialized
INFO - 2023-01-14 17:05:30 --> Hooks Class Initialized
DEBUG - 2023-01-14 17:05:30 --> UTF-8 Support Enabled
INFO - 2023-01-14 17:05:30 --> Utf8 Class Initialized
INFO - 2023-01-14 17:05:30 --> URI Class Initialized
INFO - 2023-01-14 17:05:30 --> Router Class Initialized
INFO - 2023-01-14 17:05:30 --> Output Class Initialized
INFO - 2023-01-14 17:05:30 --> Security Class Initialized
DEBUG - 2023-01-14 17:05:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-14 17:05:30 --> Input Class Initialized
INFO - 2023-01-14 17:05:30 --> Language Class Initialized
INFO - 2023-01-14 17:05:30 --> Language Class Initialized
INFO - 2023-01-14 17:05:30 --> Config Class Initialized
INFO - 2023-01-14 17:05:30 --> Loader Class Initialized
INFO - 2023-01-14 17:05:30 --> Helper loaded: url_helper
INFO - 2023-01-14 17:05:30 --> Helper loaded: file_helper
INFO - 2023-01-14 17:05:30 --> Helper loaded: form_helper
INFO - 2023-01-14 17:05:30 --> Helper loaded: my_helper
INFO - 2023-01-14 17:05:30 --> Database Driver Class Initialized
DEBUG - 2023-01-14 17:05:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-01-14 17:05:30 --> Session: Class initialized using 'files' driver.
INFO - 2023-01-14 17:05:30 --> Controller Class Initialized
DEBUG - 2023-01-14 17:05:30 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/cetak_raport/views/cetak_mh.php
INFO - 2023-01-14 17:05:31 --> Final output sent to browser
DEBUG - 2023-01-14 17:05:31 --> Total execution time: 1.4408
INFO - 2023-01-14 17:05:58 --> Config Class Initialized
INFO - 2023-01-14 17:05:58 --> Hooks Class Initialized
DEBUG - 2023-01-14 17:05:58 --> UTF-8 Support Enabled
INFO - 2023-01-14 17:05:58 --> Utf8 Class Initialized
INFO - 2023-01-14 17:05:58 --> URI Class Initialized
INFO - 2023-01-14 17:05:58 --> Router Class Initialized
INFO - 2023-01-14 17:05:58 --> Output Class Initialized
INFO - 2023-01-14 17:05:58 --> Security Class Initialized
DEBUG - 2023-01-14 17:05:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-14 17:05:58 --> Input Class Initialized
INFO - 2023-01-14 17:05:58 --> Language Class Initialized
INFO - 2023-01-14 17:05:58 --> Language Class Initialized
INFO - 2023-01-14 17:05:58 --> Config Class Initialized
INFO - 2023-01-14 17:05:58 --> Loader Class Initialized
INFO - 2023-01-14 17:05:58 --> Helper loaded: url_helper
INFO - 2023-01-14 17:05:58 --> Helper loaded: file_helper
INFO - 2023-01-14 17:05:58 --> Helper loaded: form_helper
INFO - 2023-01-14 17:05:58 --> Helper loaded: my_helper
INFO - 2023-01-14 17:05:58 --> Database Driver Class Initialized
DEBUG - 2023-01-14 17:05:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-01-14 17:05:58 --> Session: Class initialized using 'files' driver.
INFO - 2023-01-14 17:05:58 --> Controller Class Initialized
ERROR - 2023-01-14 17:05:58 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\myraportk13\application\modules\cetak_raport\controllers\Cetak_raport.php 1093
ERROR - 2023-01-14 17:05:58 --> Severity: Notice --> Undefined variable: Array C:\xampp\htdocs\myraportk13\application\modules\cetak_raport\controllers\Cetak_raport.php 1093
ERROR - 2023-01-14 17:05:58 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\myraportk13\application\modules\cetak_raport\controllers\Cetak_raport.php 1093
ERROR - 2023-01-14 17:05:58 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\myraportk13\application\modules\cetak_raport\controllers\Cetak_raport.php 1093
ERROR - 2023-01-14 17:05:58 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\myraportk13\application\modules\cetak_raport\controllers\Cetak_raport.php 1093
DEBUG - 2023-01-14 17:05:58 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/cetak_raport/views/cetak_mh.php
INFO - 2023-01-14 17:06:00 --> Final output sent to browser
DEBUG - 2023-01-14 17:06:00 --> Total execution time: 1.5473
INFO - 2023-01-14 17:07:29 --> Config Class Initialized
INFO - 2023-01-14 17:07:29 --> Hooks Class Initialized
DEBUG - 2023-01-14 17:07:29 --> UTF-8 Support Enabled
INFO - 2023-01-14 17:07:29 --> Utf8 Class Initialized
INFO - 2023-01-14 17:07:29 --> URI Class Initialized
INFO - 2023-01-14 17:07:29 --> Router Class Initialized
INFO - 2023-01-14 17:07:29 --> Output Class Initialized
INFO - 2023-01-14 17:07:29 --> Security Class Initialized
DEBUG - 2023-01-14 17:07:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-14 17:07:29 --> Input Class Initialized
INFO - 2023-01-14 17:07:29 --> Language Class Initialized
INFO - 2023-01-14 17:07:29 --> Language Class Initialized
INFO - 2023-01-14 17:07:29 --> Config Class Initialized
INFO - 2023-01-14 17:07:29 --> Loader Class Initialized
INFO - 2023-01-14 17:07:29 --> Helper loaded: url_helper
INFO - 2023-01-14 17:07:29 --> Helper loaded: file_helper
INFO - 2023-01-14 17:07:29 --> Helper loaded: form_helper
INFO - 2023-01-14 17:07:29 --> Helper loaded: my_helper
INFO - 2023-01-14 17:07:29 --> Database Driver Class Initialized
DEBUG - 2023-01-14 17:07:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-01-14 17:07:29 --> Session: Class initialized using 'files' driver.
INFO - 2023-01-14 17:07:29 --> Controller Class Initialized
ERROR - 2023-01-14 17:07:29 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\myraportk13\application\modules\cetak_raport\controllers\Cetak_raport.php 1093
ERROR - 2023-01-14 17:07:29 --> Severity: Notice --> Undefined variable: Array C:\xampp\htdocs\myraportk13\application\modules\cetak_raport\controllers\Cetak_raport.php 1093
ERROR - 2023-01-14 17:07:29 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\myraportk13\application\modules\cetak_raport\controllers\Cetak_raport.php 1093
ERROR - 2023-01-14 17:07:29 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\myraportk13\application\modules\cetak_raport\controllers\Cetak_raport.php 1093
ERROR - 2023-01-14 17:07:29 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\myraportk13\application\modules\cetak_raport\controllers\Cetak_raport.php 1093
DEBUG - 2023-01-14 17:07:29 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/cetak_raport/views/cetak_mh.php
INFO - 2023-01-14 17:07:31 --> Final output sent to browser
DEBUG - 2023-01-14 17:07:31 --> Total execution time: 1.4512
INFO - 2023-01-14 17:07:57 --> Config Class Initialized
INFO - 2023-01-14 17:07:57 --> Hooks Class Initialized
DEBUG - 2023-01-14 17:07:57 --> UTF-8 Support Enabled
INFO - 2023-01-14 17:07:57 --> Utf8 Class Initialized
INFO - 2023-01-14 17:07:57 --> URI Class Initialized
INFO - 2023-01-14 17:07:57 --> Router Class Initialized
INFO - 2023-01-14 17:07:57 --> Output Class Initialized
INFO - 2023-01-14 17:07:57 --> Security Class Initialized
DEBUG - 2023-01-14 17:07:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-14 17:07:57 --> Input Class Initialized
INFO - 2023-01-14 17:07:57 --> Language Class Initialized
INFO - 2023-01-14 17:07:57 --> Language Class Initialized
INFO - 2023-01-14 17:07:57 --> Config Class Initialized
INFO - 2023-01-14 17:07:57 --> Loader Class Initialized
INFO - 2023-01-14 17:07:57 --> Helper loaded: url_helper
INFO - 2023-01-14 17:07:57 --> Helper loaded: file_helper
INFO - 2023-01-14 17:07:57 --> Helper loaded: form_helper
INFO - 2023-01-14 17:07:57 --> Helper loaded: my_helper
INFO - 2023-01-14 17:07:57 --> Database Driver Class Initialized
DEBUG - 2023-01-14 17:07:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-01-14 17:07:57 --> Session: Class initialized using 'files' driver.
INFO - 2023-01-14 17:07:57 --> Controller Class Initialized
ERROR - 2023-01-14 17:07:57 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\myraportk13\application\modules\cetak_raport\controllers\Cetak_raport.php 1093
ERROR - 2023-01-14 17:07:57 --> Severity: Notice --> Undefined variable: Array C:\xampp\htdocs\myraportk13\application\modules\cetak_raport\controllers\Cetak_raport.php 1093
ERROR - 2023-01-14 17:07:57 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\myraportk13\application\modules\cetak_raport\controllers\Cetak_raport.php 1093
ERROR - 2023-01-14 17:07:57 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\myraportk13\application\modules\cetak_raport\controllers\Cetak_raport.php 1093
ERROR - 2023-01-14 17:07:57 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\myraportk13\application\modules\cetak_raport\controllers\Cetak_raport.php 1093
DEBUG - 2023-01-14 17:07:57 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/cetak_raport/views/cetak_mh.php
INFO - 2023-01-14 17:07:59 --> Final output sent to browser
DEBUG - 2023-01-14 17:07:59 --> Total execution time: 1.4480
INFO - 2023-01-14 17:08:37 --> Config Class Initialized
INFO - 2023-01-14 17:08:37 --> Hooks Class Initialized
DEBUG - 2023-01-14 17:08:37 --> UTF-8 Support Enabled
INFO - 2023-01-14 17:08:37 --> Utf8 Class Initialized
INFO - 2023-01-14 17:08:37 --> URI Class Initialized
INFO - 2023-01-14 17:08:37 --> Router Class Initialized
INFO - 2023-01-14 17:08:37 --> Output Class Initialized
INFO - 2023-01-14 17:08:37 --> Security Class Initialized
DEBUG - 2023-01-14 17:08:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-14 17:08:37 --> Input Class Initialized
INFO - 2023-01-14 17:08:37 --> Language Class Initialized
INFO - 2023-01-14 17:08:37 --> Language Class Initialized
INFO - 2023-01-14 17:08:37 --> Config Class Initialized
INFO - 2023-01-14 17:08:37 --> Loader Class Initialized
INFO - 2023-01-14 17:08:37 --> Helper loaded: url_helper
INFO - 2023-01-14 17:08:37 --> Helper loaded: file_helper
INFO - 2023-01-14 17:08:37 --> Helper loaded: form_helper
INFO - 2023-01-14 17:08:37 --> Helper loaded: my_helper
INFO - 2023-01-14 17:08:37 --> Database Driver Class Initialized
DEBUG - 2023-01-14 17:08:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-01-14 17:08:37 --> Session: Class initialized using 'files' driver.
INFO - 2023-01-14 17:08:37 --> Controller Class Initialized
ERROR - 2023-01-14 17:08:37 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\myraportk13\application\modules\cetak_raport\controllers\Cetak_raport.php 1093
ERROR - 2023-01-14 17:08:37 --> Severity: Notice --> Undefined variable: Array C:\xampp\htdocs\myraportk13\application\modules\cetak_raport\controllers\Cetak_raport.php 1093
ERROR - 2023-01-14 17:08:37 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\myraportk13\application\modules\cetak_raport\controllers\Cetak_raport.php 1093
ERROR - 2023-01-14 17:08:37 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\myraportk13\application\modules\cetak_raport\controllers\Cetak_raport.php 1093
ERROR - 2023-01-14 17:08:37 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\myraportk13\application\modules\cetak_raport\controllers\Cetak_raport.php 1093
DEBUG - 2023-01-14 17:08:37 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/cetak_raport/views/cetak_mh.php
INFO - 2023-01-14 17:08:39 --> Final output sent to browser
DEBUG - 2023-01-14 17:08:39 --> Total execution time: 1.5063
INFO - 2023-01-14 17:09:43 --> Config Class Initialized
INFO - 2023-01-14 17:09:43 --> Hooks Class Initialized
DEBUG - 2023-01-14 17:09:43 --> UTF-8 Support Enabled
INFO - 2023-01-14 17:09:44 --> Utf8 Class Initialized
INFO - 2023-01-14 17:09:44 --> URI Class Initialized
INFO - 2023-01-14 17:09:44 --> Router Class Initialized
INFO - 2023-01-14 17:09:44 --> Output Class Initialized
INFO - 2023-01-14 17:09:44 --> Security Class Initialized
DEBUG - 2023-01-14 17:09:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-14 17:09:44 --> Input Class Initialized
INFO - 2023-01-14 17:09:44 --> Language Class Initialized
INFO - 2023-01-14 17:09:44 --> Language Class Initialized
INFO - 2023-01-14 17:09:44 --> Config Class Initialized
INFO - 2023-01-14 17:09:44 --> Loader Class Initialized
INFO - 2023-01-14 17:09:44 --> Helper loaded: url_helper
INFO - 2023-01-14 17:09:44 --> Helper loaded: file_helper
INFO - 2023-01-14 17:09:44 --> Helper loaded: form_helper
INFO - 2023-01-14 17:09:44 --> Helper loaded: my_helper
INFO - 2023-01-14 17:09:44 --> Database Driver Class Initialized
DEBUG - 2023-01-14 17:09:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-01-14 17:09:44 --> Session: Class initialized using 'files' driver.
INFO - 2023-01-14 17:09:44 --> Controller Class Initialized
ERROR - 2023-01-14 17:09:44 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\myraportk13\application\modules\cetak_raport\controllers\Cetak_raport.php 1093
ERROR - 2023-01-14 17:09:44 --> Severity: Notice --> Undefined variable: Array C:\xampp\htdocs\myraportk13\application\modules\cetak_raport\controllers\Cetak_raport.php 1093
ERROR - 2023-01-14 17:09:44 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\myraportk13\application\modules\cetak_raport\controllers\Cetak_raport.php 1093
ERROR - 2023-01-14 17:09:44 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\myraportk13\application\modules\cetak_raport\controllers\Cetak_raport.php 1093
DEBUG - 2023-01-14 17:09:44 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/cetak_raport/views/cetak_mh.php
INFO - 2023-01-14 17:09:45 --> Final output sent to browser
DEBUG - 2023-01-14 17:09:45 --> Total execution time: 1.5069
INFO - 2023-01-14 17:12:08 --> Config Class Initialized
INFO - 2023-01-14 17:12:08 --> Hooks Class Initialized
DEBUG - 2023-01-14 17:12:08 --> UTF-8 Support Enabled
INFO - 2023-01-14 17:12:08 --> Utf8 Class Initialized
INFO - 2023-01-14 17:12:08 --> URI Class Initialized
INFO - 2023-01-14 17:12:08 --> Router Class Initialized
INFO - 2023-01-14 17:12:08 --> Output Class Initialized
INFO - 2023-01-14 17:12:08 --> Security Class Initialized
DEBUG - 2023-01-14 17:12:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-14 17:12:08 --> Input Class Initialized
INFO - 2023-01-14 17:12:08 --> Language Class Initialized
INFO - 2023-01-14 17:12:08 --> Language Class Initialized
INFO - 2023-01-14 17:12:08 --> Config Class Initialized
INFO - 2023-01-14 17:12:08 --> Loader Class Initialized
INFO - 2023-01-14 17:12:08 --> Helper loaded: url_helper
INFO - 2023-01-14 17:12:08 --> Helper loaded: file_helper
INFO - 2023-01-14 17:12:08 --> Helper loaded: form_helper
INFO - 2023-01-14 17:12:08 --> Helper loaded: my_helper
INFO - 2023-01-14 17:12:08 --> Database Driver Class Initialized
DEBUG - 2023-01-14 17:12:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-01-14 17:12:08 --> Session: Class initialized using 'files' driver.
INFO - 2023-01-14 17:12:08 --> Controller Class Initialized
DEBUG - 2023-01-14 17:12:08 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/cetak_raport/views/cetak_mh.php
INFO - 2023-01-14 17:12:09 --> Final output sent to browser
DEBUG - 2023-01-14 17:12:09 --> Total execution time: 1.4580
INFO - 2023-01-14 17:12:29 --> Config Class Initialized
INFO - 2023-01-14 17:12:29 --> Hooks Class Initialized
DEBUG - 2023-01-14 17:12:29 --> UTF-8 Support Enabled
INFO - 2023-01-14 17:12:29 --> Utf8 Class Initialized
INFO - 2023-01-14 17:12:29 --> URI Class Initialized
INFO - 2023-01-14 17:12:29 --> Router Class Initialized
INFO - 2023-01-14 17:12:29 --> Output Class Initialized
INFO - 2023-01-14 17:12:29 --> Security Class Initialized
DEBUG - 2023-01-14 17:12:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-14 17:12:29 --> Input Class Initialized
INFO - 2023-01-14 17:12:29 --> Language Class Initialized
INFO - 2023-01-14 17:12:29 --> Language Class Initialized
INFO - 2023-01-14 17:12:29 --> Config Class Initialized
INFO - 2023-01-14 17:12:29 --> Loader Class Initialized
INFO - 2023-01-14 17:12:29 --> Helper loaded: url_helper
INFO - 2023-01-14 17:12:29 --> Helper loaded: file_helper
INFO - 2023-01-14 17:12:29 --> Helper loaded: form_helper
INFO - 2023-01-14 17:12:29 --> Helper loaded: my_helper
INFO - 2023-01-14 17:12:29 --> Database Driver Class Initialized
DEBUG - 2023-01-14 17:12:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-01-14 17:12:29 --> Session: Class initialized using 'files' driver.
INFO - 2023-01-14 17:12:29 --> Controller Class Initialized
ERROR - 2023-01-14 17:12:29 --> Severity: Warning --> explode() expects parameter 2 to be string, array given C:\xampp\htdocs\myraportk13\application\modules\cetak_raport\controllers\Cetak_raport.php 1093
DEBUG - 2023-01-14 17:12:29 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/cetak_raport/views/cetak_mh.php
INFO - 2023-01-14 17:12:31 --> Final output sent to browser
DEBUG - 2023-01-14 17:12:31 --> Total execution time: 1.4902
INFO - 2023-01-14 17:13:59 --> Config Class Initialized
INFO - 2023-01-14 17:13:59 --> Hooks Class Initialized
DEBUG - 2023-01-14 17:13:59 --> UTF-8 Support Enabled
INFO - 2023-01-14 17:13:59 --> Utf8 Class Initialized
INFO - 2023-01-14 17:13:59 --> URI Class Initialized
INFO - 2023-01-14 17:13:59 --> Router Class Initialized
INFO - 2023-01-14 17:13:59 --> Output Class Initialized
INFO - 2023-01-14 17:13:59 --> Security Class Initialized
DEBUG - 2023-01-14 17:13:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-14 17:13:59 --> Input Class Initialized
INFO - 2023-01-14 17:13:59 --> Language Class Initialized
INFO - 2023-01-14 17:13:59 --> Language Class Initialized
INFO - 2023-01-14 17:13:59 --> Config Class Initialized
INFO - 2023-01-14 17:13:59 --> Loader Class Initialized
INFO - 2023-01-14 17:13:59 --> Helper loaded: url_helper
INFO - 2023-01-14 17:13:59 --> Helper loaded: file_helper
INFO - 2023-01-14 17:13:59 --> Helper loaded: form_helper
INFO - 2023-01-14 17:13:59 --> Helper loaded: my_helper
INFO - 2023-01-14 17:13:59 --> Database Driver Class Initialized
DEBUG - 2023-01-14 17:13:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-01-14 17:13:59 --> Session: Class initialized using 'files' driver.
INFO - 2023-01-14 17:13:59 --> Controller Class Initialized
DEBUG - 2023-01-14 17:13:59 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/cetak_raport/views/cetak_mh.php
INFO - 2023-01-14 17:14:00 --> Final output sent to browser
DEBUG - 2023-01-14 17:14:00 --> Total execution time: 1.4695
INFO - 2023-01-14 17:15:49 --> Config Class Initialized
INFO - 2023-01-14 17:15:49 --> Hooks Class Initialized
DEBUG - 2023-01-14 17:15:49 --> UTF-8 Support Enabled
INFO - 2023-01-14 17:15:49 --> Utf8 Class Initialized
INFO - 2023-01-14 17:15:49 --> URI Class Initialized
INFO - 2023-01-14 17:15:49 --> Router Class Initialized
INFO - 2023-01-14 17:15:49 --> Output Class Initialized
INFO - 2023-01-14 17:15:49 --> Security Class Initialized
DEBUG - 2023-01-14 17:15:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-14 17:15:49 --> Input Class Initialized
INFO - 2023-01-14 17:15:49 --> Language Class Initialized
INFO - 2023-01-14 17:15:49 --> Language Class Initialized
INFO - 2023-01-14 17:15:49 --> Config Class Initialized
INFO - 2023-01-14 17:15:49 --> Loader Class Initialized
INFO - 2023-01-14 17:15:49 --> Helper loaded: url_helper
INFO - 2023-01-14 17:15:49 --> Helper loaded: file_helper
INFO - 2023-01-14 17:15:49 --> Helper loaded: form_helper
INFO - 2023-01-14 17:15:49 --> Helper loaded: my_helper
INFO - 2023-01-14 17:15:49 --> Database Driver Class Initialized
DEBUG - 2023-01-14 17:15:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-01-14 17:15:49 --> Session: Class initialized using 'files' driver.
INFO - 2023-01-14 17:15:49 --> Controller Class Initialized
ERROR - 2023-01-14 17:15:49 --> Severity: Warning --> explode() expects parameter 2 to be string, array given C:\xampp\htdocs\myraportk13\application\modules\cetak_raport\controllers\Cetak_raport.php 1093
DEBUG - 2023-01-14 17:15:49 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/cetak_raport/views/cetak_mh.php
INFO - 2023-01-14 17:15:50 --> Final output sent to browser
DEBUG - 2023-01-14 17:15:50 --> Total execution time: 1.3507
INFO - 2023-01-14 17:17:15 --> Config Class Initialized
INFO - 2023-01-14 17:17:15 --> Hooks Class Initialized
DEBUG - 2023-01-14 17:17:15 --> UTF-8 Support Enabled
INFO - 2023-01-14 17:17:15 --> Utf8 Class Initialized
INFO - 2023-01-14 17:17:15 --> URI Class Initialized
INFO - 2023-01-14 17:17:15 --> Router Class Initialized
INFO - 2023-01-14 17:17:15 --> Output Class Initialized
INFO - 2023-01-14 17:17:15 --> Security Class Initialized
DEBUG - 2023-01-14 17:17:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-14 17:17:15 --> Input Class Initialized
INFO - 2023-01-14 17:17:15 --> Language Class Initialized
INFO - 2023-01-14 17:17:15 --> Language Class Initialized
INFO - 2023-01-14 17:17:15 --> Config Class Initialized
INFO - 2023-01-14 17:17:15 --> Loader Class Initialized
INFO - 2023-01-14 17:17:15 --> Helper loaded: url_helper
INFO - 2023-01-14 17:17:15 --> Helper loaded: file_helper
INFO - 2023-01-14 17:17:15 --> Helper loaded: form_helper
INFO - 2023-01-14 17:17:15 --> Helper loaded: my_helper
INFO - 2023-01-14 17:17:15 --> Database Driver Class Initialized
DEBUG - 2023-01-14 17:17:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-01-14 17:17:15 --> Session: Class initialized using 'files' driver.
INFO - 2023-01-14 17:17:15 --> Controller Class Initialized
DEBUG - 2023-01-14 17:17:15 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/cetak_raport/views/cetak_mh.php
INFO - 2023-01-14 17:17:16 --> Final output sent to browser
DEBUG - 2023-01-14 17:17:16 --> Total execution time: 1.4301
INFO - 2023-01-14 17:18:06 --> Config Class Initialized
INFO - 2023-01-14 17:18:06 --> Hooks Class Initialized
DEBUG - 2023-01-14 17:18:06 --> UTF-8 Support Enabled
INFO - 2023-01-14 17:18:06 --> Utf8 Class Initialized
INFO - 2023-01-14 17:18:06 --> URI Class Initialized
INFO - 2023-01-14 17:18:06 --> Router Class Initialized
INFO - 2023-01-14 17:18:06 --> Output Class Initialized
INFO - 2023-01-14 17:18:06 --> Security Class Initialized
DEBUG - 2023-01-14 17:18:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-14 17:18:06 --> Input Class Initialized
INFO - 2023-01-14 17:18:06 --> Language Class Initialized
INFO - 2023-01-14 17:18:06 --> Language Class Initialized
INFO - 2023-01-14 17:18:06 --> Config Class Initialized
INFO - 2023-01-14 17:18:06 --> Loader Class Initialized
INFO - 2023-01-14 17:18:06 --> Helper loaded: url_helper
INFO - 2023-01-14 17:18:06 --> Helper loaded: file_helper
INFO - 2023-01-14 17:18:06 --> Helper loaded: form_helper
INFO - 2023-01-14 17:18:06 --> Helper loaded: my_helper
INFO - 2023-01-14 17:18:06 --> Database Driver Class Initialized
DEBUG - 2023-01-14 17:18:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-01-14 17:18:06 --> Session: Class initialized using 'files' driver.
INFO - 2023-01-14 17:18:06 --> Controller Class Initialized
DEBUG - 2023-01-14 17:18:06 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/cetak_raport/views/cetak_mh.php
INFO - 2023-01-14 17:18:07 --> Final output sent to browser
DEBUG - 2023-01-14 17:18:07 --> Total execution time: 1.3488
