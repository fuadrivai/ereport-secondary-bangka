<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2024-02-27 12:22:10 --> Config Class Initialized
INFO - 2024-02-27 12:22:10 --> Hooks Class Initialized
DEBUG - 2024-02-27 12:22:10 --> UTF-8 Support Enabled
INFO - 2024-02-27 12:22:10 --> Utf8 Class Initialized
INFO - 2024-02-27 12:22:10 --> URI Class Initialized
DEBUG - 2024-02-27 12:22:10 --> No URI present. Default controller set.
INFO - 2024-02-27 12:22:10 --> Router Class Initialized
INFO - 2024-02-27 12:22:10 --> Output Class Initialized
INFO - 2024-02-27 12:22:10 --> Security Class Initialized
DEBUG - 2024-02-27 12:22:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-27 12:22:10 --> Input Class Initialized
INFO - 2024-02-27 12:22:10 --> Language Class Initialized
INFO - 2024-02-27 12:22:10 --> Language Class Initialized
INFO - 2024-02-27 12:22:10 --> Config Class Initialized
INFO - 2024-02-27 12:22:10 --> Loader Class Initialized
INFO - 2024-02-27 12:22:10 --> Helper loaded: url_helper
INFO - 2024-02-27 12:22:10 --> Helper loaded: file_helper
INFO - 2024-02-27 12:22:10 --> Helper loaded: form_helper
INFO - 2024-02-27 12:22:10 --> Helper loaded: my_helper
INFO - 2024-02-27 12:22:10 --> Database Driver Class Initialized
INFO - 2024-02-27 12:22:10 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-27 12:22:10 --> Controller Class Initialized
DEBUG - 2024-02-27 12:22:10 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/home/views/v_home_guru.php
DEBUG - 2024-02-27 12:22:10 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-02-27 12:22:10 --> Final output sent to browser
DEBUG - 2024-02-27 12:22:10 --> Total execution time: 0.0789
INFO - 2024-02-27 12:22:14 --> Config Class Initialized
INFO - 2024-02-27 12:22:14 --> Hooks Class Initialized
DEBUG - 2024-02-27 12:22:14 --> UTF-8 Support Enabled
INFO - 2024-02-27 12:22:14 --> Utf8 Class Initialized
INFO - 2024-02-27 12:22:14 --> URI Class Initialized
INFO - 2024-02-27 12:22:14 --> Router Class Initialized
INFO - 2024-02-27 12:22:14 --> Output Class Initialized
INFO - 2024-02-27 12:22:14 --> Security Class Initialized
DEBUG - 2024-02-27 12:22:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-27 12:22:14 --> Input Class Initialized
INFO - 2024-02-27 12:22:14 --> Language Class Initialized
INFO - 2024-02-27 12:22:14 --> Language Class Initialized
INFO - 2024-02-27 12:22:14 --> Config Class Initialized
INFO - 2024-02-27 12:22:14 --> Loader Class Initialized
INFO - 2024-02-27 12:22:14 --> Helper loaded: url_helper
INFO - 2024-02-27 12:22:14 --> Helper loaded: file_helper
INFO - 2024-02-27 12:22:14 --> Helper loaded: form_helper
INFO - 2024-02-27 12:22:14 --> Helper loaded: my_helper
INFO - 2024-02-27 12:22:14 --> Database Driver Class Initialized
INFO - 2024-02-27 12:22:14 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-27 12:22:14 --> Controller Class Initialized
INFO - 2024-02-27 12:22:14 --> Helper loaded: cookie_helper
INFO - 2024-02-27 12:22:14 --> Config Class Initialized
INFO - 2024-02-27 12:22:14 --> Hooks Class Initialized
DEBUG - 2024-02-27 12:22:14 --> UTF-8 Support Enabled
INFO - 2024-02-27 12:22:14 --> Utf8 Class Initialized
INFO - 2024-02-27 12:22:14 --> URI Class Initialized
INFO - 2024-02-27 12:22:14 --> Router Class Initialized
INFO - 2024-02-27 12:22:14 --> Output Class Initialized
INFO - 2024-02-27 12:22:14 --> Security Class Initialized
DEBUG - 2024-02-27 12:22:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-27 12:22:14 --> Input Class Initialized
INFO - 2024-02-27 12:22:14 --> Language Class Initialized
INFO - 2024-02-27 12:22:14 --> Language Class Initialized
INFO - 2024-02-27 12:22:14 --> Config Class Initialized
INFO - 2024-02-27 12:22:14 --> Loader Class Initialized
INFO - 2024-02-27 12:22:14 --> Helper loaded: url_helper
INFO - 2024-02-27 12:22:14 --> Helper loaded: file_helper
INFO - 2024-02-27 12:22:14 --> Helper loaded: form_helper
INFO - 2024-02-27 12:22:14 --> Helper loaded: my_helper
INFO - 2024-02-27 12:22:14 --> Database Driver Class Initialized
INFO - 2024-02-27 12:22:14 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-27 12:22:14 --> Controller Class Initialized
INFO - 2024-02-27 12:22:14 --> Config Class Initialized
INFO - 2024-02-27 12:22:14 --> Hooks Class Initialized
DEBUG - 2024-02-27 12:22:14 --> UTF-8 Support Enabled
INFO - 2024-02-27 12:22:14 --> Utf8 Class Initialized
INFO - 2024-02-27 12:22:14 --> URI Class Initialized
INFO - 2024-02-27 12:22:14 --> Router Class Initialized
INFO - 2024-02-27 12:22:14 --> Output Class Initialized
INFO - 2024-02-27 12:22:14 --> Security Class Initialized
DEBUG - 2024-02-27 12:22:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-27 12:22:14 --> Input Class Initialized
INFO - 2024-02-27 12:22:14 --> Language Class Initialized
INFO - 2024-02-27 12:22:14 --> Language Class Initialized
INFO - 2024-02-27 12:22:14 --> Config Class Initialized
INFO - 2024-02-27 12:22:14 --> Loader Class Initialized
INFO - 2024-02-27 12:22:14 --> Helper loaded: url_helper
INFO - 2024-02-27 12:22:14 --> Helper loaded: file_helper
INFO - 2024-02-27 12:22:14 --> Helper loaded: form_helper
INFO - 2024-02-27 12:22:14 --> Helper loaded: my_helper
INFO - 2024-02-27 12:22:14 --> Database Driver Class Initialized
INFO - 2024-02-27 12:22:14 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-27 12:22:14 --> Controller Class Initialized
DEBUG - 2024-02-27 12:22:14 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/login/views/login.php
DEBUG - 2024-02-27 12:22:14 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-02-27 12:22:14 --> Final output sent to browser
DEBUG - 2024-02-27 12:22:14 --> Total execution time: 0.0398
INFO - 2024-02-27 12:22:18 --> Config Class Initialized
INFO - 2024-02-27 12:22:18 --> Hooks Class Initialized
DEBUG - 2024-02-27 12:22:18 --> UTF-8 Support Enabled
INFO - 2024-02-27 12:22:18 --> Utf8 Class Initialized
INFO - 2024-02-27 12:22:18 --> URI Class Initialized
INFO - 2024-02-27 12:22:18 --> Router Class Initialized
INFO - 2024-02-27 12:22:18 --> Output Class Initialized
INFO - 2024-02-27 12:22:18 --> Security Class Initialized
DEBUG - 2024-02-27 12:22:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-27 12:22:18 --> Input Class Initialized
INFO - 2024-02-27 12:22:18 --> Language Class Initialized
INFO - 2024-02-27 12:22:18 --> Language Class Initialized
INFO - 2024-02-27 12:22:18 --> Config Class Initialized
INFO - 2024-02-27 12:22:18 --> Loader Class Initialized
INFO - 2024-02-27 12:22:18 --> Helper loaded: url_helper
INFO - 2024-02-27 12:22:18 --> Helper loaded: file_helper
INFO - 2024-02-27 12:22:18 --> Helper loaded: form_helper
INFO - 2024-02-27 12:22:18 --> Helper loaded: my_helper
INFO - 2024-02-27 12:22:18 --> Database Driver Class Initialized
INFO - 2024-02-27 12:22:18 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-27 12:22:18 --> Controller Class Initialized
INFO - 2024-02-27 12:22:18 --> Helper loaded: cookie_helper
INFO - 2024-02-27 12:22:18 --> Final output sent to browser
DEBUG - 2024-02-27 12:22:18 --> Total execution time: 0.0397
INFO - 2024-02-27 12:22:18 --> Config Class Initialized
INFO - 2024-02-27 12:22:18 --> Hooks Class Initialized
DEBUG - 2024-02-27 12:22:18 --> UTF-8 Support Enabled
INFO - 2024-02-27 12:22:18 --> Utf8 Class Initialized
INFO - 2024-02-27 12:22:18 --> URI Class Initialized
INFO - 2024-02-27 12:22:18 --> Router Class Initialized
INFO - 2024-02-27 12:22:18 --> Output Class Initialized
INFO - 2024-02-27 12:22:18 --> Security Class Initialized
DEBUG - 2024-02-27 12:22:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-27 12:22:18 --> Input Class Initialized
INFO - 2024-02-27 12:22:18 --> Language Class Initialized
INFO - 2024-02-27 12:22:18 --> Language Class Initialized
INFO - 2024-02-27 12:22:18 --> Config Class Initialized
INFO - 2024-02-27 12:22:18 --> Loader Class Initialized
INFO - 2024-02-27 12:22:18 --> Helper loaded: url_helper
INFO - 2024-02-27 12:22:18 --> Helper loaded: file_helper
INFO - 2024-02-27 12:22:18 --> Helper loaded: form_helper
INFO - 2024-02-27 12:22:18 --> Helper loaded: my_helper
INFO - 2024-02-27 12:22:18 --> Database Driver Class Initialized
INFO - 2024-02-27 12:22:18 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-27 12:22:18 --> Controller Class Initialized
DEBUG - 2024-02-27 12:22:18 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/home/views/v_home_guru.php
DEBUG - 2024-02-27 12:22:18 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-02-27 12:22:18 --> Final output sent to browser
DEBUG - 2024-02-27 12:22:18 --> Total execution time: 0.0328
INFO - 2024-02-27 12:22:20 --> Config Class Initialized
INFO - 2024-02-27 12:22:20 --> Hooks Class Initialized
DEBUG - 2024-02-27 12:22:20 --> UTF-8 Support Enabled
INFO - 2024-02-27 12:22:20 --> Utf8 Class Initialized
INFO - 2024-02-27 12:22:20 --> URI Class Initialized
INFO - 2024-02-27 12:22:20 --> Router Class Initialized
INFO - 2024-02-27 12:22:20 --> Output Class Initialized
INFO - 2024-02-27 12:22:20 --> Security Class Initialized
DEBUG - 2024-02-27 12:22:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-27 12:22:20 --> Input Class Initialized
INFO - 2024-02-27 12:22:20 --> Language Class Initialized
INFO - 2024-02-27 12:22:20 --> Language Class Initialized
INFO - 2024-02-27 12:22:20 --> Config Class Initialized
INFO - 2024-02-27 12:22:20 --> Loader Class Initialized
INFO - 2024-02-27 12:22:20 --> Helper loaded: url_helper
INFO - 2024-02-27 12:22:20 --> Helper loaded: file_helper
INFO - 2024-02-27 12:22:20 --> Helper loaded: form_helper
INFO - 2024-02-27 12:22:20 --> Helper loaded: my_helper
INFO - 2024-02-27 12:22:20 --> Database Driver Class Initialized
INFO - 2024-02-27 12:22:20 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-27 12:22:20 --> Controller Class Initialized
DEBUG - 2024-02-27 12:22:20 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/view_mapel/views/v_view_mapel.php
DEBUG - 2024-02-27 12:22:20 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-02-27 12:22:20 --> Final output sent to browser
DEBUG - 2024-02-27 12:22:20 --> Total execution time: 0.0375
INFO - 2024-02-27 12:22:23 --> Config Class Initialized
INFO - 2024-02-27 12:22:23 --> Hooks Class Initialized
DEBUG - 2024-02-27 12:22:23 --> UTF-8 Support Enabled
INFO - 2024-02-27 12:22:23 --> Utf8 Class Initialized
INFO - 2024-02-27 12:22:23 --> URI Class Initialized
INFO - 2024-02-27 12:22:23 --> Router Class Initialized
INFO - 2024-02-27 12:22:23 --> Output Class Initialized
INFO - 2024-02-27 12:22:23 --> Security Class Initialized
DEBUG - 2024-02-27 12:22:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-27 12:22:23 --> Input Class Initialized
INFO - 2024-02-27 12:22:23 --> Language Class Initialized
INFO - 2024-02-27 12:22:23 --> Language Class Initialized
INFO - 2024-02-27 12:22:23 --> Config Class Initialized
INFO - 2024-02-27 12:22:23 --> Loader Class Initialized
INFO - 2024-02-27 12:22:23 --> Helper loaded: url_helper
INFO - 2024-02-27 12:22:23 --> Helper loaded: file_helper
INFO - 2024-02-27 12:22:23 --> Helper loaded: form_helper
INFO - 2024-02-27 12:22:23 --> Helper loaded: my_helper
INFO - 2024-02-27 12:22:23 --> Database Driver Class Initialized
INFO - 2024-02-27 12:22:23 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-27 12:22:23 --> Controller Class Initialized
DEBUG - 2024-02-27 12:22:23 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/views/list.php
DEBUG - 2024-02-27 12:22:23 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-02-27 12:22:23 --> Final output sent to browser
DEBUG - 2024-02-27 12:22:23 --> Total execution time: 0.0417
INFO - 2024-02-27 12:22:23 --> Config Class Initialized
INFO - 2024-02-27 12:22:23 --> Hooks Class Initialized
DEBUG - 2024-02-27 12:22:23 --> UTF-8 Support Enabled
INFO - 2024-02-27 12:22:23 --> Utf8 Class Initialized
INFO - 2024-02-27 12:22:23 --> URI Class Initialized
INFO - 2024-02-27 12:22:23 --> Router Class Initialized
INFO - 2024-02-27 12:22:23 --> Output Class Initialized
INFO - 2024-02-27 12:22:23 --> Security Class Initialized
DEBUG - 2024-02-27 12:22:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-27 12:22:23 --> Input Class Initialized
INFO - 2024-02-27 12:22:23 --> Language Class Initialized
INFO - 2024-02-27 12:22:24 --> Language Class Initialized
INFO - 2024-02-27 12:22:24 --> Config Class Initialized
INFO - 2024-02-27 12:22:24 --> Loader Class Initialized
INFO - 2024-02-27 12:22:24 --> Helper loaded: url_helper
INFO - 2024-02-27 12:22:24 --> Helper loaded: file_helper
INFO - 2024-02-27 12:22:24 --> Helper loaded: form_helper
INFO - 2024-02-27 12:22:24 --> Helper loaded: my_helper
INFO - 2024-02-27 12:22:24 --> Database Driver Class Initialized
INFO - 2024-02-27 12:22:24 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-27 12:22:24 --> Controller Class Initialized
INFO - 2024-02-27 12:22:26 --> Config Class Initialized
INFO - 2024-02-27 12:22:26 --> Hooks Class Initialized
DEBUG - 2024-02-27 12:22:26 --> UTF-8 Support Enabled
INFO - 2024-02-27 12:22:26 --> Utf8 Class Initialized
INFO - 2024-02-27 12:22:26 --> URI Class Initialized
INFO - 2024-02-27 12:22:26 --> Router Class Initialized
INFO - 2024-02-27 12:22:26 --> Output Class Initialized
INFO - 2024-02-27 12:22:26 --> Security Class Initialized
DEBUG - 2024-02-27 12:22:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-27 12:22:26 --> Input Class Initialized
INFO - 2024-02-27 12:22:26 --> Language Class Initialized
INFO - 2024-02-27 12:22:26 --> Language Class Initialized
INFO - 2024-02-27 12:22:26 --> Config Class Initialized
INFO - 2024-02-27 12:22:26 --> Loader Class Initialized
INFO - 2024-02-27 12:22:26 --> Helper loaded: url_helper
INFO - 2024-02-27 12:22:26 --> Helper loaded: file_helper
INFO - 2024-02-27 12:22:26 --> Helper loaded: form_helper
INFO - 2024-02-27 12:22:26 --> Helper loaded: my_helper
INFO - 2024-02-27 12:22:26 --> Database Driver Class Initialized
INFO - 2024-02-27 12:22:26 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-27 12:22:26 --> Controller Class Initialized
