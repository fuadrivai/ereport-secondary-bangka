<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2024-08-14 10:12:58 --> Config Class Initialized
INFO - 2024-08-14 10:12:58 --> Hooks Class Initialized
DEBUG - 2024-08-14 10:12:58 --> UTF-8 Support Enabled
INFO - 2024-08-14 10:12:58 --> Utf8 Class Initialized
INFO - 2024-08-14 10:12:58 --> URI Class Initialized
INFO - 2024-08-14 10:12:58 --> Router Class Initialized
INFO - 2024-08-14 10:12:58 --> Output Class Initialized
INFO - 2024-08-14 10:12:58 --> Security Class Initialized
DEBUG - 2024-08-14 10:12:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-08-14 10:12:58 --> Input Class Initialized
INFO - 2024-08-14 10:12:58 --> Language Class Initialized
INFO - 2024-08-14 10:12:58 --> Language Class Initialized
INFO - 2024-08-14 10:12:58 --> Config Class Initialized
INFO - 2024-08-14 10:12:58 --> Loader Class Initialized
INFO - 2024-08-14 10:12:58 --> Helper loaded: url_helper
INFO - 2024-08-14 10:12:58 --> Helper loaded: file_helper
INFO - 2024-08-14 10:12:58 --> Helper loaded: form_helper
INFO - 2024-08-14 10:12:58 --> Helper loaded: my_helper
INFO - 2024-08-14 10:12:58 --> Database Driver Class Initialized
INFO - 2024-08-14 10:12:58 --> Session: Class initialized using 'files' driver.
INFO - 2024-08-14 10:12:58 --> Controller Class Initialized
INFO - 2024-08-14 10:12:58 --> Helper loaded: cookie_helper
INFO - 2024-08-14 10:12:58 --> Final output sent to browser
DEBUG - 2024-08-14 10:12:58 --> Total execution time: 0.0581
INFO - 2024-08-14 10:12:58 --> Config Class Initialized
INFO - 2024-08-14 10:12:58 --> Hooks Class Initialized
DEBUG - 2024-08-14 10:12:58 --> UTF-8 Support Enabled
INFO - 2024-08-14 10:12:58 --> Utf8 Class Initialized
INFO - 2024-08-14 10:12:58 --> URI Class Initialized
INFO - 2024-08-14 10:12:58 --> Router Class Initialized
INFO - 2024-08-14 10:12:58 --> Output Class Initialized
INFO - 2024-08-14 10:12:58 --> Security Class Initialized
DEBUG - 2024-08-14 10:12:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-08-14 10:12:58 --> Input Class Initialized
INFO - 2024-08-14 10:12:58 --> Language Class Initialized
INFO - 2024-08-14 10:12:58 --> Language Class Initialized
INFO - 2024-08-14 10:12:58 --> Config Class Initialized
INFO - 2024-08-14 10:12:58 --> Loader Class Initialized
INFO - 2024-08-14 10:12:58 --> Helper loaded: url_helper
INFO - 2024-08-14 10:12:58 --> Helper loaded: file_helper
INFO - 2024-08-14 10:12:58 --> Helper loaded: form_helper
INFO - 2024-08-14 10:12:58 --> Helper loaded: my_helper
INFO - 2024-08-14 10:12:58 --> Database Driver Class Initialized
INFO - 2024-08-14 10:12:58 --> Session: Class initialized using 'files' driver.
INFO - 2024-08-14 10:12:58 --> Controller Class Initialized
INFO - 2024-08-14 10:12:58 --> Helper loaded: cookie_helper
INFO - 2024-08-14 10:12:58 --> Config Class Initialized
INFO - 2024-08-14 10:12:58 --> Hooks Class Initialized
DEBUG - 2024-08-14 10:12:58 --> UTF-8 Support Enabled
INFO - 2024-08-14 10:12:58 --> Utf8 Class Initialized
INFO - 2024-08-14 10:12:58 --> URI Class Initialized
INFO - 2024-08-14 10:12:58 --> Router Class Initialized
INFO - 2024-08-14 10:12:58 --> Output Class Initialized
INFO - 2024-08-14 10:12:58 --> Security Class Initialized
DEBUG - 2024-08-14 10:12:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-08-14 10:12:58 --> Input Class Initialized
INFO - 2024-08-14 10:12:58 --> Language Class Initialized
INFO - 2024-08-14 10:12:58 --> Language Class Initialized
INFO - 2024-08-14 10:12:58 --> Config Class Initialized
INFO - 2024-08-14 10:12:58 --> Loader Class Initialized
INFO - 2024-08-14 10:12:58 --> Helper loaded: url_helper
INFO - 2024-08-14 10:12:58 --> Helper loaded: file_helper
INFO - 2024-08-14 10:12:58 --> Helper loaded: form_helper
INFO - 2024-08-14 10:12:58 --> Helper loaded: my_helper
INFO - 2024-08-14 10:12:58 --> Database Driver Class Initialized
INFO - 2024-08-14 10:12:58 --> Session: Class initialized using 'files' driver.
INFO - 2024-08-14 10:12:58 --> Controller Class Initialized
DEBUG - 2024-08-14 10:12:58 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/lihat_raport/views/list.php
DEBUG - 2024-08-14 10:12:58 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-08-14 10:12:58 --> Final output sent to browser
DEBUG - 2024-08-14 10:12:58 --> Total execution time: 0.0371
INFO - 2024-08-14 10:31:45 --> Config Class Initialized
INFO - 2024-08-14 10:31:45 --> Hooks Class Initialized
DEBUG - 2024-08-14 10:31:45 --> UTF-8 Support Enabled
INFO - 2024-08-14 10:31:45 --> Utf8 Class Initialized
INFO - 2024-08-14 10:31:45 --> URI Class Initialized
INFO - 2024-08-14 10:31:45 --> Router Class Initialized
INFO - 2024-08-14 10:31:45 --> Output Class Initialized
INFO - 2024-08-14 10:31:45 --> Security Class Initialized
DEBUG - 2024-08-14 10:31:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-08-14 10:31:45 --> Input Class Initialized
INFO - 2024-08-14 10:31:45 --> Language Class Initialized
INFO - 2024-08-14 10:31:45 --> Language Class Initialized
INFO - 2024-08-14 10:31:45 --> Config Class Initialized
INFO - 2024-08-14 10:31:45 --> Loader Class Initialized
INFO - 2024-08-14 10:31:45 --> Helper loaded: url_helper
INFO - 2024-08-14 10:31:45 --> Helper loaded: file_helper
INFO - 2024-08-14 10:31:45 --> Helper loaded: form_helper
INFO - 2024-08-14 10:31:45 --> Helper loaded: my_helper
INFO - 2024-08-14 10:31:45 --> Database Driver Class Initialized
INFO - 2024-08-14 10:31:45 --> Session: Class initialized using 'files' driver.
INFO - 2024-08-14 10:31:45 --> Controller Class Initialized
DEBUG - 2024-08-14 10:31:45 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/login/views/login.php
DEBUG - 2024-08-14 10:31:45 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-08-14 10:31:45 --> Final output sent to browser
DEBUG - 2024-08-14 10:31:45 --> Total execution time: 0.0463
INFO - 2024-08-14 10:31:50 --> Config Class Initialized
INFO - 2024-08-14 10:31:50 --> Hooks Class Initialized
DEBUG - 2024-08-14 10:31:50 --> UTF-8 Support Enabled
INFO - 2024-08-14 10:31:50 --> Utf8 Class Initialized
INFO - 2024-08-14 10:31:50 --> URI Class Initialized
INFO - 2024-08-14 10:31:50 --> Router Class Initialized
INFO - 2024-08-14 10:31:50 --> Output Class Initialized
INFO - 2024-08-14 10:31:50 --> Security Class Initialized
DEBUG - 2024-08-14 10:31:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-08-14 10:31:50 --> Input Class Initialized
INFO - 2024-08-14 10:31:50 --> Language Class Initialized
INFO - 2024-08-14 10:31:50 --> Language Class Initialized
INFO - 2024-08-14 10:31:50 --> Config Class Initialized
INFO - 2024-08-14 10:31:50 --> Loader Class Initialized
INFO - 2024-08-14 10:31:50 --> Helper loaded: url_helper
INFO - 2024-08-14 10:31:50 --> Helper loaded: file_helper
INFO - 2024-08-14 10:31:50 --> Helper loaded: form_helper
INFO - 2024-08-14 10:31:50 --> Helper loaded: my_helper
INFO - 2024-08-14 10:31:50 --> Database Driver Class Initialized
INFO - 2024-08-14 10:31:50 --> Session: Class initialized using 'files' driver.
INFO - 2024-08-14 10:31:50 --> Controller Class Initialized
INFO - 2024-08-14 10:31:51 --> Helper loaded: cookie_helper
INFO - 2024-08-14 10:31:51 --> Final output sent to browser
DEBUG - 2024-08-14 10:31:51 --> Total execution time: 0.2619
INFO - 2024-08-14 10:31:51 --> Config Class Initialized
INFO - 2024-08-14 10:31:51 --> Hooks Class Initialized
DEBUG - 2024-08-14 10:31:51 --> UTF-8 Support Enabled
INFO - 2024-08-14 10:31:51 --> Utf8 Class Initialized
INFO - 2024-08-14 10:31:51 --> URI Class Initialized
INFO - 2024-08-14 10:31:51 --> Router Class Initialized
INFO - 2024-08-14 10:31:51 --> Output Class Initialized
INFO - 2024-08-14 10:31:51 --> Security Class Initialized
DEBUG - 2024-08-14 10:31:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-08-14 10:31:51 --> Input Class Initialized
INFO - 2024-08-14 10:31:51 --> Language Class Initialized
INFO - 2024-08-14 10:31:51 --> Language Class Initialized
INFO - 2024-08-14 10:31:51 --> Config Class Initialized
INFO - 2024-08-14 10:31:51 --> Loader Class Initialized
INFO - 2024-08-14 10:31:51 --> Helper loaded: url_helper
INFO - 2024-08-14 10:31:51 --> Helper loaded: file_helper
INFO - 2024-08-14 10:31:51 --> Helper loaded: form_helper
INFO - 2024-08-14 10:31:51 --> Helper loaded: my_helper
INFO - 2024-08-14 10:31:51 --> Database Driver Class Initialized
INFO - 2024-08-14 10:31:51 --> Session: Class initialized using 'files' driver.
INFO - 2024-08-14 10:31:51 --> Controller Class Initialized
DEBUG - 2024-08-14 10:31:51 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/home/views/v_home.php
DEBUG - 2024-08-14 10:31:51 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-08-14 10:31:51 --> Final output sent to browser
DEBUG - 2024-08-14 10:31:51 --> Total execution time: 0.0474
INFO - 2024-08-14 10:32:04 --> Config Class Initialized
INFO - 2024-08-14 10:32:04 --> Hooks Class Initialized
DEBUG - 2024-08-14 10:32:04 --> UTF-8 Support Enabled
INFO - 2024-08-14 10:32:04 --> Utf8 Class Initialized
INFO - 2024-08-14 10:32:04 --> URI Class Initialized
INFO - 2024-08-14 10:32:04 --> Router Class Initialized
INFO - 2024-08-14 10:32:04 --> Output Class Initialized
INFO - 2024-08-14 10:32:04 --> Security Class Initialized
DEBUG - 2024-08-14 10:32:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-08-14 10:32:04 --> Input Class Initialized
INFO - 2024-08-14 10:32:04 --> Language Class Initialized
INFO - 2024-08-14 10:32:04 --> Language Class Initialized
INFO - 2024-08-14 10:32:04 --> Config Class Initialized
INFO - 2024-08-14 10:32:04 --> Loader Class Initialized
INFO - 2024-08-14 10:32:04 --> Helper loaded: url_helper
INFO - 2024-08-14 10:32:04 --> Helper loaded: file_helper
INFO - 2024-08-14 10:32:04 --> Helper loaded: form_helper
INFO - 2024-08-14 10:32:04 --> Helper loaded: my_helper
INFO - 2024-08-14 10:32:04 --> Database Driver Class Initialized
INFO - 2024-08-14 10:32:04 --> Session: Class initialized using 'files' driver.
INFO - 2024-08-14 10:32:04 --> Controller Class Initialized
DEBUG - 2024-08-14 10:32:04 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/set_walikelas/views/list.php
DEBUG - 2024-08-14 10:32:04 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-08-14 10:32:04 --> Final output sent to browser
DEBUG - 2024-08-14 10:32:04 --> Total execution time: 0.0356
INFO - 2024-08-14 10:32:04 --> Config Class Initialized
INFO - 2024-08-14 10:32:04 --> Hooks Class Initialized
DEBUG - 2024-08-14 10:32:04 --> UTF-8 Support Enabled
INFO - 2024-08-14 10:32:04 --> Utf8 Class Initialized
INFO - 2024-08-14 10:32:04 --> URI Class Initialized
INFO - 2024-08-14 10:32:04 --> Router Class Initialized
INFO - 2024-08-14 10:32:04 --> Output Class Initialized
INFO - 2024-08-14 10:32:04 --> Security Class Initialized
DEBUG - 2024-08-14 10:32:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-08-14 10:32:04 --> Input Class Initialized
INFO - 2024-08-14 10:32:04 --> Language Class Initialized
ERROR - 2024-08-14 10:32:04 --> 404 Page Not Found: /index
INFO - 2024-08-14 10:32:04 --> Config Class Initialized
INFO - 2024-08-14 10:32:04 --> Hooks Class Initialized
DEBUG - 2024-08-14 10:32:04 --> UTF-8 Support Enabled
INFO - 2024-08-14 10:32:04 --> Utf8 Class Initialized
INFO - 2024-08-14 10:32:04 --> URI Class Initialized
INFO - 2024-08-14 10:32:04 --> Router Class Initialized
INFO - 2024-08-14 10:32:04 --> Output Class Initialized
INFO - 2024-08-14 10:32:04 --> Security Class Initialized
DEBUG - 2024-08-14 10:32:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-08-14 10:32:04 --> Input Class Initialized
INFO - 2024-08-14 10:32:04 --> Language Class Initialized
INFO - 2024-08-14 10:32:04 --> Language Class Initialized
INFO - 2024-08-14 10:32:04 --> Config Class Initialized
INFO - 2024-08-14 10:32:04 --> Loader Class Initialized
INFO - 2024-08-14 10:32:04 --> Helper loaded: url_helper
INFO - 2024-08-14 10:32:04 --> Helper loaded: file_helper
INFO - 2024-08-14 10:32:04 --> Helper loaded: form_helper
INFO - 2024-08-14 10:32:04 --> Helper loaded: my_helper
INFO - 2024-08-14 10:32:04 --> Database Driver Class Initialized
INFO - 2024-08-14 10:32:04 --> Session: Class initialized using 'files' driver.
INFO - 2024-08-14 10:32:04 --> Controller Class Initialized
INFO - 2024-08-14 10:32:05 --> Config Class Initialized
INFO - 2024-08-14 10:32:05 --> Hooks Class Initialized
DEBUG - 2024-08-14 10:32:05 --> UTF-8 Support Enabled
INFO - 2024-08-14 10:32:05 --> Utf8 Class Initialized
INFO - 2024-08-14 10:32:05 --> URI Class Initialized
INFO - 2024-08-14 10:32:05 --> Router Class Initialized
INFO - 2024-08-14 10:32:05 --> Output Class Initialized
INFO - 2024-08-14 10:32:05 --> Security Class Initialized
DEBUG - 2024-08-14 10:32:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-08-14 10:32:05 --> Input Class Initialized
INFO - 2024-08-14 10:32:05 --> Language Class Initialized
INFO - 2024-08-14 10:32:05 --> Language Class Initialized
INFO - 2024-08-14 10:32:05 --> Config Class Initialized
INFO - 2024-08-14 10:32:05 --> Loader Class Initialized
INFO - 2024-08-14 10:32:05 --> Helper loaded: url_helper
INFO - 2024-08-14 10:32:05 --> Helper loaded: file_helper
INFO - 2024-08-14 10:32:05 --> Helper loaded: form_helper
INFO - 2024-08-14 10:32:05 --> Helper loaded: my_helper
INFO - 2024-08-14 10:32:05 --> Database Driver Class Initialized
INFO - 2024-08-14 10:32:05 --> Session: Class initialized using 'files' driver.
INFO - 2024-08-14 10:32:05 --> Controller Class Initialized
INFO - 2024-08-14 10:32:05 --> Final output sent to browser
DEBUG - 2024-08-14 10:32:05 --> Total execution time: 0.0393
INFO - 2024-08-14 10:32:11 --> Config Class Initialized
INFO - 2024-08-14 10:32:11 --> Hooks Class Initialized
DEBUG - 2024-08-14 10:32:11 --> UTF-8 Support Enabled
INFO - 2024-08-14 10:32:11 --> Utf8 Class Initialized
INFO - 2024-08-14 10:32:11 --> URI Class Initialized
INFO - 2024-08-14 10:32:11 --> Router Class Initialized
INFO - 2024-08-14 10:32:11 --> Output Class Initialized
INFO - 2024-08-14 10:32:11 --> Security Class Initialized
DEBUG - 2024-08-14 10:32:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-08-14 10:32:11 --> Input Class Initialized
INFO - 2024-08-14 10:32:11 --> Language Class Initialized
INFO - 2024-08-14 10:32:11 --> Language Class Initialized
INFO - 2024-08-14 10:32:11 --> Config Class Initialized
INFO - 2024-08-14 10:32:11 --> Loader Class Initialized
INFO - 2024-08-14 10:32:11 --> Helper loaded: url_helper
INFO - 2024-08-14 10:32:11 --> Helper loaded: file_helper
INFO - 2024-08-14 10:32:11 --> Helper loaded: form_helper
INFO - 2024-08-14 10:32:11 --> Helper loaded: my_helper
INFO - 2024-08-14 10:32:11 --> Database Driver Class Initialized
INFO - 2024-08-14 10:32:11 --> Session: Class initialized using 'files' driver.
INFO - 2024-08-14 10:32:11 --> Controller Class Initialized
INFO - 2024-08-14 10:32:11 --> Final output sent to browser
DEBUG - 2024-08-14 10:32:11 --> Total execution time: 0.0359
INFO - 2024-08-14 10:32:11 --> Config Class Initialized
INFO - 2024-08-14 10:32:11 --> Hooks Class Initialized
DEBUG - 2024-08-14 10:32:11 --> UTF-8 Support Enabled
INFO - 2024-08-14 10:32:11 --> Utf8 Class Initialized
INFO - 2024-08-14 10:32:11 --> URI Class Initialized
INFO - 2024-08-14 10:32:11 --> Router Class Initialized
INFO - 2024-08-14 10:32:11 --> Output Class Initialized
INFO - 2024-08-14 10:32:11 --> Security Class Initialized
DEBUG - 2024-08-14 10:32:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-08-14 10:32:11 --> Input Class Initialized
INFO - 2024-08-14 10:32:11 --> Language Class Initialized
ERROR - 2024-08-14 10:32:11 --> 404 Page Not Found: /index
INFO - 2024-08-14 10:32:11 --> Config Class Initialized
INFO - 2024-08-14 10:32:11 --> Hooks Class Initialized
DEBUG - 2024-08-14 10:32:11 --> UTF-8 Support Enabled
INFO - 2024-08-14 10:32:11 --> Utf8 Class Initialized
INFO - 2024-08-14 10:32:11 --> URI Class Initialized
INFO - 2024-08-14 10:32:11 --> Router Class Initialized
INFO - 2024-08-14 10:32:11 --> Output Class Initialized
INFO - 2024-08-14 10:32:11 --> Security Class Initialized
DEBUG - 2024-08-14 10:32:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-08-14 10:32:11 --> Input Class Initialized
INFO - 2024-08-14 10:32:11 --> Language Class Initialized
INFO - 2024-08-14 10:32:11 --> Language Class Initialized
INFO - 2024-08-14 10:32:11 --> Config Class Initialized
INFO - 2024-08-14 10:32:11 --> Loader Class Initialized
INFO - 2024-08-14 10:32:11 --> Helper loaded: url_helper
INFO - 2024-08-14 10:32:11 --> Helper loaded: file_helper
INFO - 2024-08-14 10:32:11 --> Helper loaded: form_helper
INFO - 2024-08-14 10:32:11 --> Helper loaded: my_helper
INFO - 2024-08-14 10:32:11 --> Database Driver Class Initialized
INFO - 2024-08-14 10:32:11 --> Session: Class initialized using 'files' driver.
INFO - 2024-08-14 10:32:11 --> Controller Class Initialized
INFO - 2024-08-14 10:32:14 --> Config Class Initialized
INFO - 2024-08-14 10:32:14 --> Hooks Class Initialized
DEBUG - 2024-08-14 10:32:14 --> UTF-8 Support Enabled
INFO - 2024-08-14 10:32:14 --> Utf8 Class Initialized
INFO - 2024-08-14 10:32:14 --> URI Class Initialized
INFO - 2024-08-14 10:32:14 --> Router Class Initialized
INFO - 2024-08-14 10:32:14 --> Output Class Initialized
INFO - 2024-08-14 10:32:14 --> Security Class Initialized
DEBUG - 2024-08-14 10:32:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-08-14 10:32:14 --> Input Class Initialized
INFO - 2024-08-14 10:32:14 --> Language Class Initialized
INFO - 2024-08-14 10:32:14 --> Language Class Initialized
INFO - 2024-08-14 10:32:14 --> Config Class Initialized
INFO - 2024-08-14 10:32:14 --> Loader Class Initialized
INFO - 2024-08-14 10:32:14 --> Helper loaded: url_helper
INFO - 2024-08-14 10:32:14 --> Helper loaded: file_helper
INFO - 2024-08-14 10:32:14 --> Helper loaded: form_helper
INFO - 2024-08-14 10:32:14 --> Helper loaded: my_helper
INFO - 2024-08-14 10:32:14 --> Database Driver Class Initialized
INFO - 2024-08-14 10:32:14 --> Session: Class initialized using 'files' driver.
INFO - 2024-08-14 10:32:14 --> Controller Class Initialized
DEBUG - 2024-08-14 10:32:14 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/data_guru/views/list.php
DEBUG - 2024-08-14 10:32:14 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-08-14 10:32:14 --> Final output sent to browser
DEBUG - 2024-08-14 10:32:14 --> Total execution time: 0.0287
INFO - 2024-08-14 10:32:14 --> Config Class Initialized
INFO - 2024-08-14 10:32:14 --> Hooks Class Initialized
DEBUG - 2024-08-14 10:32:14 --> UTF-8 Support Enabled
INFO - 2024-08-14 10:32:14 --> Utf8 Class Initialized
INFO - 2024-08-14 10:32:14 --> URI Class Initialized
INFO - 2024-08-14 10:32:14 --> Router Class Initialized
INFO - 2024-08-14 10:32:14 --> Output Class Initialized
INFO - 2024-08-14 10:32:14 --> Security Class Initialized
DEBUG - 2024-08-14 10:32:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-08-14 10:32:14 --> Input Class Initialized
INFO - 2024-08-14 10:32:14 --> Language Class Initialized
ERROR - 2024-08-14 10:32:14 --> 404 Page Not Found: /index
INFO - 2024-08-14 10:32:14 --> Config Class Initialized
INFO - 2024-08-14 10:32:14 --> Hooks Class Initialized
DEBUG - 2024-08-14 10:32:14 --> UTF-8 Support Enabled
INFO - 2024-08-14 10:32:14 --> Utf8 Class Initialized
INFO - 2024-08-14 10:32:14 --> URI Class Initialized
INFO - 2024-08-14 10:32:14 --> Router Class Initialized
INFO - 2024-08-14 10:32:14 --> Output Class Initialized
INFO - 2024-08-14 10:32:14 --> Security Class Initialized
DEBUG - 2024-08-14 10:32:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-08-14 10:32:14 --> Input Class Initialized
INFO - 2024-08-14 10:32:14 --> Language Class Initialized
INFO - 2024-08-14 10:32:14 --> Language Class Initialized
INFO - 2024-08-14 10:32:14 --> Config Class Initialized
INFO - 2024-08-14 10:32:14 --> Loader Class Initialized
INFO - 2024-08-14 10:32:14 --> Helper loaded: url_helper
INFO - 2024-08-14 10:32:14 --> Helper loaded: file_helper
INFO - 2024-08-14 10:32:14 --> Helper loaded: form_helper
INFO - 2024-08-14 10:32:14 --> Helper loaded: my_helper
INFO - 2024-08-14 10:32:14 --> Database Driver Class Initialized
INFO - 2024-08-14 10:32:14 --> Session: Class initialized using 'files' driver.
INFO - 2024-08-14 10:32:14 --> Controller Class Initialized
INFO - 2024-08-14 10:32:21 --> Config Class Initialized
INFO - 2024-08-14 10:32:21 --> Hooks Class Initialized
DEBUG - 2024-08-14 10:32:21 --> UTF-8 Support Enabled
INFO - 2024-08-14 10:32:21 --> Utf8 Class Initialized
INFO - 2024-08-14 10:32:21 --> URI Class Initialized
INFO - 2024-08-14 10:32:21 --> Router Class Initialized
INFO - 2024-08-14 10:32:21 --> Output Class Initialized
INFO - 2024-08-14 10:32:21 --> Security Class Initialized
DEBUG - 2024-08-14 10:32:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-08-14 10:32:21 --> Input Class Initialized
INFO - 2024-08-14 10:32:21 --> Language Class Initialized
INFO - 2024-08-14 10:32:21 --> Language Class Initialized
INFO - 2024-08-14 10:32:21 --> Config Class Initialized
INFO - 2024-08-14 10:32:21 --> Loader Class Initialized
INFO - 2024-08-14 10:32:21 --> Helper loaded: url_helper
INFO - 2024-08-14 10:32:21 --> Helper loaded: file_helper
INFO - 2024-08-14 10:32:21 --> Helper loaded: form_helper
INFO - 2024-08-14 10:32:21 --> Helper loaded: my_helper
INFO - 2024-08-14 10:32:21 --> Database Driver Class Initialized
INFO - 2024-08-14 10:32:21 --> Session: Class initialized using 'files' driver.
INFO - 2024-08-14 10:32:21 --> Controller Class Initialized
INFO - 2024-08-14 10:32:21 --> Helper loaded: cookie_helper
INFO - 2024-08-14 10:32:21 --> Config Class Initialized
INFO - 2024-08-14 10:32:21 --> Hooks Class Initialized
DEBUG - 2024-08-14 10:32:21 --> UTF-8 Support Enabled
INFO - 2024-08-14 10:32:21 --> Utf8 Class Initialized
INFO - 2024-08-14 10:32:21 --> URI Class Initialized
INFO - 2024-08-14 10:32:21 --> Router Class Initialized
INFO - 2024-08-14 10:32:21 --> Output Class Initialized
INFO - 2024-08-14 10:32:21 --> Security Class Initialized
DEBUG - 2024-08-14 10:32:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-08-14 10:32:21 --> Input Class Initialized
INFO - 2024-08-14 10:32:21 --> Language Class Initialized
INFO - 2024-08-14 10:32:21 --> Language Class Initialized
INFO - 2024-08-14 10:32:21 --> Config Class Initialized
INFO - 2024-08-14 10:32:21 --> Loader Class Initialized
INFO - 2024-08-14 10:32:21 --> Helper loaded: url_helper
INFO - 2024-08-14 10:32:21 --> Helper loaded: file_helper
INFO - 2024-08-14 10:32:21 --> Helper loaded: form_helper
INFO - 2024-08-14 10:32:21 --> Helper loaded: my_helper
INFO - 2024-08-14 10:32:21 --> Database Driver Class Initialized
INFO - 2024-08-14 10:32:21 --> Session: Class initialized using 'files' driver.
INFO - 2024-08-14 10:32:21 --> Controller Class Initialized
INFO - 2024-08-14 10:32:21 --> Config Class Initialized
INFO - 2024-08-14 10:32:21 --> Hooks Class Initialized
DEBUG - 2024-08-14 10:32:21 --> UTF-8 Support Enabled
INFO - 2024-08-14 10:32:21 --> Utf8 Class Initialized
INFO - 2024-08-14 10:32:21 --> URI Class Initialized
INFO - 2024-08-14 10:32:21 --> Router Class Initialized
INFO - 2024-08-14 10:32:21 --> Output Class Initialized
INFO - 2024-08-14 10:32:21 --> Security Class Initialized
DEBUG - 2024-08-14 10:32:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-08-14 10:32:21 --> Input Class Initialized
INFO - 2024-08-14 10:32:21 --> Language Class Initialized
INFO - 2024-08-14 10:32:21 --> Language Class Initialized
INFO - 2024-08-14 10:32:21 --> Config Class Initialized
INFO - 2024-08-14 10:32:21 --> Loader Class Initialized
INFO - 2024-08-14 10:32:21 --> Helper loaded: url_helper
INFO - 2024-08-14 10:32:21 --> Helper loaded: file_helper
INFO - 2024-08-14 10:32:21 --> Helper loaded: form_helper
INFO - 2024-08-14 10:32:21 --> Helper loaded: my_helper
INFO - 2024-08-14 10:32:21 --> Database Driver Class Initialized
INFO - 2024-08-14 10:32:21 --> Session: Class initialized using 'files' driver.
INFO - 2024-08-14 10:32:21 --> Controller Class Initialized
DEBUG - 2024-08-14 10:32:21 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/login/views/login.php
DEBUG - 2024-08-14 10:32:21 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-08-14 10:32:21 --> Final output sent to browser
DEBUG - 2024-08-14 10:32:21 --> Total execution time: 0.0345
INFO - 2024-08-14 10:32:27 --> Config Class Initialized
INFO - 2024-08-14 10:32:27 --> Hooks Class Initialized
DEBUG - 2024-08-14 10:32:27 --> UTF-8 Support Enabled
INFO - 2024-08-14 10:32:27 --> Utf8 Class Initialized
INFO - 2024-08-14 10:32:27 --> URI Class Initialized
INFO - 2024-08-14 10:32:27 --> Router Class Initialized
INFO - 2024-08-14 10:32:27 --> Output Class Initialized
INFO - 2024-08-14 10:32:27 --> Security Class Initialized
DEBUG - 2024-08-14 10:32:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-08-14 10:32:27 --> Input Class Initialized
INFO - 2024-08-14 10:32:27 --> Language Class Initialized
INFO - 2024-08-14 10:32:27 --> Language Class Initialized
INFO - 2024-08-14 10:32:27 --> Config Class Initialized
INFO - 2024-08-14 10:32:27 --> Loader Class Initialized
INFO - 2024-08-14 10:32:27 --> Helper loaded: url_helper
INFO - 2024-08-14 10:32:27 --> Helper loaded: file_helper
INFO - 2024-08-14 10:32:27 --> Helper loaded: form_helper
INFO - 2024-08-14 10:32:27 --> Helper loaded: my_helper
INFO - 2024-08-14 10:32:27 --> Database Driver Class Initialized
INFO - 2024-08-14 10:32:27 --> Session: Class initialized using 'files' driver.
INFO - 2024-08-14 10:32:27 --> Controller Class Initialized
INFO - 2024-08-14 10:32:27 --> Helper loaded: cookie_helper
INFO - 2024-08-14 10:32:27 --> Final output sent to browser
DEBUG - 2024-08-14 10:32:27 --> Total execution time: 0.0730
INFO - 2024-08-14 10:32:27 --> Config Class Initialized
INFO - 2024-08-14 10:32:27 --> Hooks Class Initialized
DEBUG - 2024-08-14 10:32:27 --> UTF-8 Support Enabled
INFO - 2024-08-14 10:32:27 --> Utf8 Class Initialized
INFO - 2024-08-14 10:32:27 --> URI Class Initialized
INFO - 2024-08-14 10:32:27 --> Router Class Initialized
INFO - 2024-08-14 10:32:27 --> Output Class Initialized
INFO - 2024-08-14 10:32:27 --> Security Class Initialized
DEBUG - 2024-08-14 10:32:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-08-14 10:32:27 --> Input Class Initialized
INFO - 2024-08-14 10:32:27 --> Language Class Initialized
INFO - 2024-08-14 10:32:27 --> Language Class Initialized
INFO - 2024-08-14 10:32:27 --> Config Class Initialized
INFO - 2024-08-14 10:32:27 --> Loader Class Initialized
INFO - 2024-08-14 10:32:27 --> Helper loaded: url_helper
INFO - 2024-08-14 10:32:27 --> Helper loaded: file_helper
INFO - 2024-08-14 10:32:27 --> Helper loaded: form_helper
INFO - 2024-08-14 10:32:27 --> Helper loaded: my_helper
INFO - 2024-08-14 10:32:27 --> Database Driver Class Initialized
INFO - 2024-08-14 10:32:27 --> Session: Class initialized using 'files' driver.
INFO - 2024-08-14 10:32:27 --> Controller Class Initialized
DEBUG - 2024-08-14 10:32:27 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/home/views/v_home_guru.php
DEBUG - 2024-08-14 10:32:27 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-08-14 10:32:27 --> Final output sent to browser
DEBUG - 2024-08-14 10:32:27 --> Total execution time: 0.1887
INFO - 2024-08-14 10:32:30 --> Config Class Initialized
INFO - 2024-08-14 10:32:30 --> Hooks Class Initialized
DEBUG - 2024-08-14 10:32:30 --> UTF-8 Support Enabled
INFO - 2024-08-14 10:32:30 --> Utf8 Class Initialized
INFO - 2024-08-14 10:32:30 --> URI Class Initialized
INFO - 2024-08-14 10:32:30 --> Router Class Initialized
INFO - 2024-08-14 10:32:30 --> Output Class Initialized
INFO - 2024-08-14 10:32:30 --> Security Class Initialized
DEBUG - 2024-08-14 10:32:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-08-14 10:32:30 --> Input Class Initialized
INFO - 2024-08-14 10:32:30 --> Language Class Initialized
INFO - 2024-08-14 10:32:30 --> Language Class Initialized
INFO - 2024-08-14 10:32:30 --> Config Class Initialized
INFO - 2024-08-14 10:32:30 --> Loader Class Initialized
INFO - 2024-08-14 10:32:30 --> Helper loaded: url_helper
INFO - 2024-08-14 10:32:30 --> Helper loaded: file_helper
INFO - 2024-08-14 10:32:30 --> Helper loaded: form_helper
INFO - 2024-08-14 10:32:30 --> Helper loaded: my_helper
INFO - 2024-08-14 10:32:30 --> Database Driver Class Initialized
INFO - 2024-08-14 10:32:30 --> Session: Class initialized using 'files' driver.
INFO - 2024-08-14 10:32:30 --> Controller Class Initialized
DEBUG - 2024-08-14 10:32:30 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/pengumuman/views/list.php
DEBUG - 2024-08-14 10:32:30 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-08-14 10:32:30 --> Final output sent to browser
DEBUG - 2024-08-14 10:32:30 --> Total execution time: 0.0271
INFO - 2024-08-14 10:32:30 --> Config Class Initialized
INFO - 2024-08-14 10:32:30 --> Hooks Class Initialized
DEBUG - 2024-08-14 10:32:30 --> UTF-8 Support Enabled
INFO - 2024-08-14 10:32:30 --> Utf8 Class Initialized
INFO - 2024-08-14 10:32:30 --> URI Class Initialized
INFO - 2024-08-14 10:32:30 --> Router Class Initialized
INFO - 2024-08-14 10:32:30 --> Output Class Initialized
INFO - 2024-08-14 10:32:30 --> Security Class Initialized
DEBUG - 2024-08-14 10:32:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-08-14 10:32:30 --> Input Class Initialized
INFO - 2024-08-14 10:32:30 --> Language Class Initialized
ERROR - 2024-08-14 10:32:30 --> 404 Page Not Found: /index
INFO - 2024-08-14 10:32:30 --> Config Class Initialized
INFO - 2024-08-14 10:32:30 --> Hooks Class Initialized
DEBUG - 2024-08-14 10:32:30 --> UTF-8 Support Enabled
INFO - 2024-08-14 10:32:30 --> Utf8 Class Initialized
INFO - 2024-08-14 10:32:30 --> URI Class Initialized
INFO - 2024-08-14 10:32:30 --> Router Class Initialized
INFO - 2024-08-14 10:32:30 --> Output Class Initialized
INFO - 2024-08-14 10:32:30 --> Security Class Initialized
DEBUG - 2024-08-14 10:32:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-08-14 10:32:30 --> Input Class Initialized
INFO - 2024-08-14 10:32:30 --> Language Class Initialized
INFO - 2024-08-14 10:32:30 --> Language Class Initialized
INFO - 2024-08-14 10:32:30 --> Config Class Initialized
INFO - 2024-08-14 10:32:30 --> Loader Class Initialized
INFO - 2024-08-14 10:32:30 --> Helper loaded: url_helper
INFO - 2024-08-14 10:32:30 --> Helper loaded: file_helper
INFO - 2024-08-14 10:32:30 --> Helper loaded: form_helper
INFO - 2024-08-14 10:32:30 --> Helper loaded: my_helper
INFO - 2024-08-14 10:32:30 --> Database Driver Class Initialized
INFO - 2024-08-14 10:32:30 --> Session: Class initialized using 'files' driver.
INFO - 2024-08-14 10:32:30 --> Controller Class Initialized
INFO - 2024-08-14 10:32:35 --> Config Class Initialized
INFO - 2024-08-14 10:32:35 --> Hooks Class Initialized
DEBUG - 2024-08-14 10:32:35 --> UTF-8 Support Enabled
INFO - 2024-08-14 10:32:35 --> Utf8 Class Initialized
INFO - 2024-08-14 10:32:35 --> URI Class Initialized
INFO - 2024-08-14 10:32:35 --> Router Class Initialized
INFO - 2024-08-14 10:32:35 --> Output Class Initialized
INFO - 2024-08-14 10:32:35 --> Security Class Initialized
DEBUG - 2024-08-14 10:32:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-08-14 10:32:35 --> Input Class Initialized
INFO - 2024-08-14 10:32:35 --> Language Class Initialized
INFO - 2024-08-14 10:32:35 --> Language Class Initialized
INFO - 2024-08-14 10:32:35 --> Config Class Initialized
INFO - 2024-08-14 10:32:35 --> Loader Class Initialized
INFO - 2024-08-14 10:32:35 --> Helper loaded: url_helper
INFO - 2024-08-14 10:32:35 --> Helper loaded: file_helper
INFO - 2024-08-14 10:32:35 --> Helper loaded: form_helper
INFO - 2024-08-14 10:32:35 --> Helper loaded: my_helper
INFO - 2024-08-14 10:32:35 --> Database Driver Class Initialized
INFO - 2024-08-14 10:32:35 --> Session: Class initialized using 'files' driver.
INFO - 2024-08-14 10:32:35 --> Controller Class Initialized
INFO - 2024-08-14 10:32:35 --> Helper loaded: cookie_helper
INFO - 2024-08-14 10:32:35 --> Config Class Initialized
INFO - 2024-08-14 10:32:35 --> Hooks Class Initialized
DEBUG - 2024-08-14 10:32:35 --> UTF-8 Support Enabled
INFO - 2024-08-14 10:32:35 --> Utf8 Class Initialized
INFO - 2024-08-14 10:32:35 --> URI Class Initialized
INFO - 2024-08-14 10:32:35 --> Router Class Initialized
INFO - 2024-08-14 10:32:35 --> Output Class Initialized
INFO - 2024-08-14 10:32:35 --> Security Class Initialized
DEBUG - 2024-08-14 10:32:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-08-14 10:32:35 --> Input Class Initialized
INFO - 2024-08-14 10:32:35 --> Language Class Initialized
INFO - 2024-08-14 10:32:35 --> Language Class Initialized
INFO - 2024-08-14 10:32:35 --> Config Class Initialized
INFO - 2024-08-14 10:32:35 --> Loader Class Initialized
INFO - 2024-08-14 10:32:35 --> Helper loaded: url_helper
INFO - 2024-08-14 10:32:35 --> Helper loaded: file_helper
INFO - 2024-08-14 10:32:35 --> Helper loaded: form_helper
INFO - 2024-08-14 10:32:35 --> Helper loaded: my_helper
INFO - 2024-08-14 10:32:35 --> Database Driver Class Initialized
INFO - 2024-08-14 10:32:35 --> Session: Class initialized using 'files' driver.
INFO - 2024-08-14 10:32:35 --> Controller Class Initialized
INFO - 2024-08-14 10:32:35 --> Config Class Initialized
INFO - 2024-08-14 10:32:35 --> Hooks Class Initialized
DEBUG - 2024-08-14 10:32:35 --> UTF-8 Support Enabled
INFO - 2024-08-14 10:32:35 --> Utf8 Class Initialized
INFO - 2024-08-14 10:32:35 --> URI Class Initialized
INFO - 2024-08-14 10:32:35 --> Router Class Initialized
INFO - 2024-08-14 10:32:35 --> Output Class Initialized
INFO - 2024-08-14 10:32:35 --> Security Class Initialized
DEBUG - 2024-08-14 10:32:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-08-14 10:32:35 --> Input Class Initialized
INFO - 2024-08-14 10:32:35 --> Language Class Initialized
INFO - 2024-08-14 10:32:35 --> Language Class Initialized
INFO - 2024-08-14 10:32:35 --> Config Class Initialized
INFO - 2024-08-14 10:32:35 --> Loader Class Initialized
INFO - 2024-08-14 10:32:35 --> Helper loaded: url_helper
INFO - 2024-08-14 10:32:35 --> Helper loaded: file_helper
INFO - 2024-08-14 10:32:35 --> Helper loaded: form_helper
INFO - 2024-08-14 10:32:35 --> Helper loaded: my_helper
INFO - 2024-08-14 10:32:35 --> Database Driver Class Initialized
INFO - 2024-08-14 10:32:35 --> Session: Class initialized using 'files' driver.
INFO - 2024-08-14 10:32:35 --> Controller Class Initialized
DEBUG - 2024-08-14 10:32:35 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/login/views/login.php
DEBUG - 2024-08-14 10:32:35 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-08-14 10:32:35 --> Final output sent to browser
DEBUG - 2024-08-14 10:32:35 --> Total execution time: 0.0275
INFO - 2024-08-14 10:32:40 --> Config Class Initialized
INFO - 2024-08-14 10:32:40 --> Hooks Class Initialized
DEBUG - 2024-08-14 10:32:40 --> UTF-8 Support Enabled
INFO - 2024-08-14 10:32:40 --> Utf8 Class Initialized
INFO - 2024-08-14 10:32:40 --> URI Class Initialized
INFO - 2024-08-14 10:32:40 --> Router Class Initialized
INFO - 2024-08-14 10:32:40 --> Output Class Initialized
INFO - 2024-08-14 10:32:40 --> Security Class Initialized
DEBUG - 2024-08-14 10:32:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-08-14 10:32:40 --> Input Class Initialized
INFO - 2024-08-14 10:32:40 --> Language Class Initialized
INFO - 2024-08-14 10:32:40 --> Language Class Initialized
INFO - 2024-08-14 10:32:40 --> Config Class Initialized
INFO - 2024-08-14 10:32:40 --> Loader Class Initialized
INFO - 2024-08-14 10:32:40 --> Helper loaded: url_helper
INFO - 2024-08-14 10:32:40 --> Helper loaded: file_helper
INFO - 2024-08-14 10:32:40 --> Helper loaded: form_helper
INFO - 2024-08-14 10:32:40 --> Helper loaded: my_helper
INFO - 2024-08-14 10:32:40 --> Database Driver Class Initialized
INFO - 2024-08-14 10:32:40 --> Session: Class initialized using 'files' driver.
INFO - 2024-08-14 10:32:40 --> Controller Class Initialized
INFO - 2024-08-14 10:32:40 --> Helper loaded: cookie_helper
INFO - 2024-08-14 10:32:40 --> Final output sent to browser
DEBUG - 2024-08-14 10:32:40 --> Total execution time: 0.0299
INFO - 2024-08-14 10:32:40 --> Config Class Initialized
INFO - 2024-08-14 10:32:40 --> Hooks Class Initialized
DEBUG - 2024-08-14 10:32:40 --> UTF-8 Support Enabled
INFO - 2024-08-14 10:32:40 --> Utf8 Class Initialized
INFO - 2024-08-14 10:32:40 --> URI Class Initialized
INFO - 2024-08-14 10:32:40 --> Router Class Initialized
INFO - 2024-08-14 10:32:40 --> Output Class Initialized
INFO - 2024-08-14 10:32:40 --> Security Class Initialized
DEBUG - 2024-08-14 10:32:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-08-14 10:32:40 --> Input Class Initialized
INFO - 2024-08-14 10:32:40 --> Language Class Initialized
INFO - 2024-08-14 10:32:40 --> Language Class Initialized
INFO - 2024-08-14 10:32:40 --> Config Class Initialized
INFO - 2024-08-14 10:32:40 --> Loader Class Initialized
INFO - 2024-08-14 10:32:40 --> Helper loaded: url_helper
INFO - 2024-08-14 10:32:40 --> Helper loaded: file_helper
INFO - 2024-08-14 10:32:40 --> Helper loaded: form_helper
INFO - 2024-08-14 10:32:40 --> Helper loaded: my_helper
INFO - 2024-08-14 10:32:40 --> Database Driver Class Initialized
INFO - 2024-08-14 10:32:40 --> Session: Class initialized using 'files' driver.
INFO - 2024-08-14 10:32:40 --> Controller Class Initialized
DEBUG - 2024-08-14 10:32:40 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/home/views/v_home.php
DEBUG - 2024-08-14 10:32:40 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-08-14 10:32:40 --> Final output sent to browser
DEBUG - 2024-08-14 10:32:40 --> Total execution time: 0.0377
INFO - 2024-08-14 10:32:43 --> Config Class Initialized
INFO - 2024-08-14 10:32:43 --> Hooks Class Initialized
DEBUG - 2024-08-14 10:32:43 --> UTF-8 Support Enabled
INFO - 2024-08-14 10:32:43 --> Utf8 Class Initialized
INFO - 2024-08-14 10:32:43 --> URI Class Initialized
INFO - 2024-08-14 10:32:43 --> Router Class Initialized
INFO - 2024-08-14 10:32:43 --> Output Class Initialized
INFO - 2024-08-14 10:32:43 --> Security Class Initialized
DEBUG - 2024-08-14 10:32:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-08-14 10:32:43 --> Input Class Initialized
INFO - 2024-08-14 10:32:43 --> Language Class Initialized
INFO - 2024-08-14 10:32:43 --> Language Class Initialized
INFO - 2024-08-14 10:32:43 --> Config Class Initialized
INFO - 2024-08-14 10:32:43 --> Loader Class Initialized
INFO - 2024-08-14 10:32:43 --> Helper loaded: url_helper
INFO - 2024-08-14 10:32:43 --> Helper loaded: file_helper
INFO - 2024-08-14 10:32:43 --> Helper loaded: form_helper
INFO - 2024-08-14 10:32:43 --> Helper loaded: my_helper
INFO - 2024-08-14 10:32:43 --> Database Driver Class Initialized
INFO - 2024-08-14 10:32:43 --> Session: Class initialized using 'files' driver.
INFO - 2024-08-14 10:32:43 --> Controller Class Initialized
DEBUG - 2024-08-14 10:32:43 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/set_walikelas/views/list.php
DEBUG - 2024-08-14 10:32:43 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-08-14 10:32:43 --> Final output sent to browser
DEBUG - 2024-08-14 10:32:43 --> Total execution time: 0.0327
INFO - 2024-08-14 10:32:43 --> Config Class Initialized
INFO - 2024-08-14 10:32:43 --> Hooks Class Initialized
DEBUG - 2024-08-14 10:32:43 --> UTF-8 Support Enabled
INFO - 2024-08-14 10:32:43 --> Utf8 Class Initialized
INFO - 2024-08-14 10:32:43 --> URI Class Initialized
INFO - 2024-08-14 10:32:43 --> Router Class Initialized
INFO - 2024-08-14 10:32:43 --> Output Class Initialized
INFO - 2024-08-14 10:32:43 --> Security Class Initialized
DEBUG - 2024-08-14 10:32:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-08-14 10:32:43 --> Input Class Initialized
INFO - 2024-08-14 10:32:43 --> Language Class Initialized
ERROR - 2024-08-14 10:32:43 --> 404 Page Not Found: /index
INFO - 2024-08-14 10:32:43 --> Config Class Initialized
INFO - 2024-08-14 10:32:43 --> Hooks Class Initialized
DEBUG - 2024-08-14 10:32:43 --> UTF-8 Support Enabled
INFO - 2024-08-14 10:32:43 --> Utf8 Class Initialized
INFO - 2024-08-14 10:32:43 --> URI Class Initialized
INFO - 2024-08-14 10:32:43 --> Router Class Initialized
INFO - 2024-08-14 10:32:43 --> Output Class Initialized
INFO - 2024-08-14 10:32:43 --> Security Class Initialized
DEBUG - 2024-08-14 10:32:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-08-14 10:32:43 --> Input Class Initialized
INFO - 2024-08-14 10:32:43 --> Language Class Initialized
INFO - 2024-08-14 10:32:43 --> Language Class Initialized
INFO - 2024-08-14 10:32:43 --> Config Class Initialized
INFO - 2024-08-14 10:32:43 --> Loader Class Initialized
INFO - 2024-08-14 10:32:43 --> Helper loaded: url_helper
INFO - 2024-08-14 10:32:43 --> Helper loaded: file_helper
INFO - 2024-08-14 10:32:43 --> Helper loaded: form_helper
INFO - 2024-08-14 10:32:43 --> Helper loaded: my_helper
INFO - 2024-08-14 10:32:43 --> Database Driver Class Initialized
INFO - 2024-08-14 10:32:43 --> Session: Class initialized using 'files' driver.
INFO - 2024-08-14 10:32:43 --> Controller Class Initialized
INFO - 2024-08-14 10:32:45 --> Config Class Initialized
INFO - 2024-08-14 10:32:45 --> Hooks Class Initialized
DEBUG - 2024-08-14 10:32:45 --> UTF-8 Support Enabled
INFO - 2024-08-14 10:32:45 --> Utf8 Class Initialized
INFO - 2024-08-14 10:32:45 --> URI Class Initialized
INFO - 2024-08-14 10:32:45 --> Router Class Initialized
INFO - 2024-08-14 10:32:45 --> Output Class Initialized
INFO - 2024-08-14 10:32:45 --> Security Class Initialized
DEBUG - 2024-08-14 10:32:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-08-14 10:32:45 --> Input Class Initialized
INFO - 2024-08-14 10:32:45 --> Language Class Initialized
INFO - 2024-08-14 10:32:45 --> Language Class Initialized
INFO - 2024-08-14 10:32:45 --> Config Class Initialized
INFO - 2024-08-14 10:32:45 --> Loader Class Initialized
INFO - 2024-08-14 10:32:45 --> Helper loaded: url_helper
INFO - 2024-08-14 10:32:45 --> Helper loaded: file_helper
INFO - 2024-08-14 10:32:45 --> Helper loaded: form_helper
INFO - 2024-08-14 10:32:45 --> Helper loaded: my_helper
INFO - 2024-08-14 10:32:45 --> Database Driver Class Initialized
INFO - 2024-08-14 10:32:45 --> Session: Class initialized using 'files' driver.
INFO - 2024-08-14 10:32:45 --> Controller Class Initialized
INFO - 2024-08-14 10:32:45 --> Final output sent to browser
DEBUG - 2024-08-14 10:32:45 --> Total execution time: 0.0399
INFO - 2024-08-14 10:32:45 --> Config Class Initialized
INFO - 2024-08-14 10:32:45 --> Hooks Class Initialized
DEBUG - 2024-08-14 10:32:45 --> UTF-8 Support Enabled
INFO - 2024-08-14 10:32:45 --> Utf8 Class Initialized
INFO - 2024-08-14 10:32:45 --> URI Class Initialized
INFO - 2024-08-14 10:32:45 --> Router Class Initialized
INFO - 2024-08-14 10:32:45 --> Output Class Initialized
INFO - 2024-08-14 10:32:45 --> Security Class Initialized
DEBUG - 2024-08-14 10:32:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-08-14 10:32:45 --> Input Class Initialized
INFO - 2024-08-14 10:32:45 --> Language Class Initialized
ERROR - 2024-08-14 10:32:45 --> 404 Page Not Found: /index
INFO - 2024-08-14 10:32:45 --> Config Class Initialized
INFO - 2024-08-14 10:32:45 --> Hooks Class Initialized
DEBUG - 2024-08-14 10:32:45 --> UTF-8 Support Enabled
INFO - 2024-08-14 10:32:45 --> Utf8 Class Initialized
INFO - 2024-08-14 10:32:45 --> URI Class Initialized
INFO - 2024-08-14 10:32:45 --> Router Class Initialized
INFO - 2024-08-14 10:32:45 --> Output Class Initialized
INFO - 2024-08-14 10:32:45 --> Security Class Initialized
DEBUG - 2024-08-14 10:32:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-08-14 10:32:45 --> Input Class Initialized
INFO - 2024-08-14 10:32:45 --> Language Class Initialized
INFO - 2024-08-14 10:32:45 --> Language Class Initialized
INFO - 2024-08-14 10:32:45 --> Config Class Initialized
INFO - 2024-08-14 10:32:45 --> Loader Class Initialized
INFO - 2024-08-14 10:32:45 --> Helper loaded: url_helper
INFO - 2024-08-14 10:32:45 --> Helper loaded: file_helper
INFO - 2024-08-14 10:32:45 --> Helper loaded: form_helper
INFO - 2024-08-14 10:32:45 --> Helper loaded: my_helper
INFO - 2024-08-14 10:32:45 --> Database Driver Class Initialized
INFO - 2024-08-14 10:32:45 --> Session: Class initialized using 'files' driver.
INFO - 2024-08-14 10:32:45 --> Controller Class Initialized
INFO - 2024-08-14 10:32:49 --> Config Class Initialized
INFO - 2024-08-14 10:32:49 --> Hooks Class Initialized
DEBUG - 2024-08-14 10:32:49 --> UTF-8 Support Enabled
INFO - 2024-08-14 10:32:49 --> Utf8 Class Initialized
INFO - 2024-08-14 10:32:49 --> URI Class Initialized
INFO - 2024-08-14 10:32:49 --> Router Class Initialized
INFO - 2024-08-14 10:32:49 --> Output Class Initialized
INFO - 2024-08-14 10:32:49 --> Security Class Initialized
DEBUG - 2024-08-14 10:32:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-08-14 10:32:49 --> Input Class Initialized
INFO - 2024-08-14 10:32:49 --> Language Class Initialized
INFO - 2024-08-14 10:32:49 --> Language Class Initialized
INFO - 2024-08-14 10:32:49 --> Config Class Initialized
INFO - 2024-08-14 10:32:49 --> Loader Class Initialized
INFO - 2024-08-14 10:32:49 --> Helper loaded: url_helper
INFO - 2024-08-14 10:32:49 --> Helper loaded: file_helper
INFO - 2024-08-14 10:32:49 --> Helper loaded: form_helper
INFO - 2024-08-14 10:32:49 --> Helper loaded: my_helper
INFO - 2024-08-14 10:32:49 --> Database Driver Class Initialized
INFO - 2024-08-14 10:32:49 --> Session: Class initialized using 'files' driver.
INFO - 2024-08-14 10:32:49 --> Controller Class Initialized
INFO - 2024-08-14 10:32:49 --> Helper loaded: cookie_helper
INFO - 2024-08-14 10:32:49 --> Config Class Initialized
INFO - 2024-08-14 10:32:49 --> Hooks Class Initialized
DEBUG - 2024-08-14 10:32:49 --> UTF-8 Support Enabled
INFO - 2024-08-14 10:32:49 --> Utf8 Class Initialized
INFO - 2024-08-14 10:32:49 --> URI Class Initialized
INFO - 2024-08-14 10:32:49 --> Router Class Initialized
INFO - 2024-08-14 10:32:49 --> Output Class Initialized
INFO - 2024-08-14 10:32:49 --> Security Class Initialized
DEBUG - 2024-08-14 10:32:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-08-14 10:32:49 --> Input Class Initialized
INFO - 2024-08-14 10:32:49 --> Language Class Initialized
INFO - 2024-08-14 10:32:49 --> Language Class Initialized
INFO - 2024-08-14 10:32:49 --> Config Class Initialized
INFO - 2024-08-14 10:32:49 --> Loader Class Initialized
INFO - 2024-08-14 10:32:49 --> Helper loaded: url_helper
INFO - 2024-08-14 10:32:49 --> Helper loaded: file_helper
INFO - 2024-08-14 10:32:49 --> Helper loaded: form_helper
INFO - 2024-08-14 10:32:49 --> Helper loaded: my_helper
INFO - 2024-08-14 10:32:49 --> Database Driver Class Initialized
INFO - 2024-08-14 10:32:49 --> Session: Class initialized using 'files' driver.
INFO - 2024-08-14 10:32:49 --> Controller Class Initialized
INFO - 2024-08-14 10:32:49 --> Config Class Initialized
INFO - 2024-08-14 10:32:49 --> Hooks Class Initialized
DEBUG - 2024-08-14 10:32:49 --> UTF-8 Support Enabled
INFO - 2024-08-14 10:32:49 --> Utf8 Class Initialized
INFO - 2024-08-14 10:32:49 --> URI Class Initialized
INFO - 2024-08-14 10:32:49 --> Router Class Initialized
INFO - 2024-08-14 10:32:49 --> Output Class Initialized
INFO - 2024-08-14 10:32:49 --> Security Class Initialized
DEBUG - 2024-08-14 10:32:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-08-14 10:32:49 --> Input Class Initialized
INFO - 2024-08-14 10:32:49 --> Language Class Initialized
INFO - 2024-08-14 10:32:49 --> Language Class Initialized
INFO - 2024-08-14 10:32:49 --> Config Class Initialized
INFO - 2024-08-14 10:32:49 --> Loader Class Initialized
INFO - 2024-08-14 10:32:49 --> Helper loaded: url_helper
INFO - 2024-08-14 10:32:49 --> Helper loaded: file_helper
INFO - 2024-08-14 10:32:49 --> Helper loaded: form_helper
INFO - 2024-08-14 10:32:49 --> Helper loaded: my_helper
INFO - 2024-08-14 10:32:49 --> Database Driver Class Initialized
INFO - 2024-08-14 10:32:49 --> Session: Class initialized using 'files' driver.
INFO - 2024-08-14 10:32:49 --> Controller Class Initialized
DEBUG - 2024-08-14 10:32:49 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/login/views/login.php
DEBUG - 2024-08-14 10:32:49 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-08-14 10:32:49 --> Final output sent to browser
DEBUG - 2024-08-14 10:32:49 --> Total execution time: 0.0356
