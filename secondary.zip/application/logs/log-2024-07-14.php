<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2024-07-14 07:49:10 --> Config Class Initialized
INFO - 2024-07-14 07:49:10 --> Hooks Class Initialized
DEBUG - 2024-07-14 07:49:10 --> UTF-8 Support Enabled
INFO - 2024-07-14 07:49:10 --> Utf8 Class Initialized
INFO - 2024-07-14 07:49:10 --> URI Class Initialized
INFO - 2024-07-14 07:49:10 --> Router Class Initialized
INFO - 2024-07-14 07:49:10 --> Output Class Initialized
INFO - 2024-07-14 07:49:10 --> Security Class Initialized
DEBUG - 2024-07-14 07:49:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-07-14 07:49:10 --> Input Class Initialized
INFO - 2024-07-14 07:49:10 --> Language Class Initialized
INFO - 2024-07-14 07:49:10 --> Language Class Initialized
INFO - 2024-07-14 07:49:10 --> Config Class Initialized
INFO - 2024-07-14 07:49:10 --> Loader Class Initialized
INFO - 2024-07-14 07:49:10 --> Helper loaded: url_helper
INFO - 2024-07-14 07:49:10 --> Helper loaded: file_helper
INFO - 2024-07-14 07:49:10 --> Helper loaded: form_helper
INFO - 2024-07-14 07:49:10 --> Helper loaded: my_helper
INFO - 2024-07-14 07:49:10 --> Database Driver Class Initialized
INFO - 2024-07-14 07:49:10 --> Session: Class initialized using 'files' driver.
INFO - 2024-07-14 07:49:10 --> Controller Class Initialized
INFO - 2024-07-14 07:49:10 --> Helper loaded: cookie_helper
INFO - 2024-07-14 07:49:10 --> Final output sent to browser
DEBUG - 2024-07-14 07:49:10 --> Total execution time: 0.0746
INFO - 2024-07-14 07:49:12 --> Config Class Initialized
INFO - 2024-07-14 07:49:12 --> Hooks Class Initialized
DEBUG - 2024-07-14 07:49:12 --> UTF-8 Support Enabled
INFO - 2024-07-14 07:49:12 --> Utf8 Class Initialized
INFO - 2024-07-14 07:49:12 --> URI Class Initialized
INFO - 2024-07-14 07:49:12 --> Router Class Initialized
INFO - 2024-07-14 07:49:12 --> Output Class Initialized
INFO - 2024-07-14 07:49:12 --> Security Class Initialized
DEBUG - 2024-07-14 07:49:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-07-14 07:49:12 --> Input Class Initialized
INFO - 2024-07-14 07:49:12 --> Language Class Initialized
INFO - 2024-07-14 07:49:12 --> Language Class Initialized
INFO - 2024-07-14 07:49:12 --> Config Class Initialized
INFO - 2024-07-14 07:49:12 --> Loader Class Initialized
INFO - 2024-07-14 07:49:12 --> Helper loaded: url_helper
INFO - 2024-07-14 07:49:12 --> Helper loaded: file_helper
INFO - 2024-07-14 07:49:12 --> Helper loaded: form_helper
INFO - 2024-07-14 07:49:12 --> Helper loaded: my_helper
INFO - 2024-07-14 07:49:12 --> Database Driver Class Initialized
INFO - 2024-07-14 07:49:12 --> Session: Class initialized using 'files' driver.
INFO - 2024-07-14 07:49:12 --> Controller Class Initialized
INFO - 2024-07-14 07:49:12 --> Helper loaded: cookie_helper
INFO - 2024-07-14 07:49:12 --> Config Class Initialized
INFO - 2024-07-14 07:49:12 --> Hooks Class Initialized
DEBUG - 2024-07-14 07:49:12 --> UTF-8 Support Enabled
INFO - 2024-07-14 07:49:12 --> Utf8 Class Initialized
INFO - 2024-07-14 07:49:12 --> URI Class Initialized
INFO - 2024-07-14 07:49:12 --> Router Class Initialized
INFO - 2024-07-14 07:49:12 --> Output Class Initialized
INFO - 2024-07-14 07:49:12 --> Security Class Initialized
DEBUG - 2024-07-14 07:49:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-07-14 07:49:12 --> Input Class Initialized
INFO - 2024-07-14 07:49:12 --> Language Class Initialized
INFO - 2024-07-14 07:49:12 --> Language Class Initialized
INFO - 2024-07-14 07:49:12 --> Config Class Initialized
INFO - 2024-07-14 07:49:12 --> Loader Class Initialized
INFO - 2024-07-14 07:49:12 --> Helper loaded: url_helper
INFO - 2024-07-14 07:49:12 --> Helper loaded: file_helper
INFO - 2024-07-14 07:49:12 --> Helper loaded: form_helper
INFO - 2024-07-14 07:49:12 --> Helper loaded: my_helper
INFO - 2024-07-14 07:49:12 --> Database Driver Class Initialized
INFO - 2024-07-14 07:49:12 --> Session: Class initialized using 'files' driver.
INFO - 2024-07-14 07:49:12 --> Controller Class Initialized
INFO - 2024-07-14 07:49:12 --> Helper loaded: cookie_helper
INFO - 2024-07-14 07:49:12 --> Final output sent to browser
DEBUG - 2024-07-14 07:49:12 --> Total execution time: 0.0266
INFO - 2024-07-14 07:49:12 --> Config Class Initialized
INFO - 2024-07-14 07:49:12 --> Hooks Class Initialized
DEBUG - 2024-07-14 07:49:12 --> UTF-8 Support Enabled
INFO - 2024-07-14 07:49:12 --> Utf8 Class Initialized
INFO - 2024-07-14 07:49:12 --> URI Class Initialized
INFO - 2024-07-14 07:49:12 --> Router Class Initialized
INFO - 2024-07-14 07:49:12 --> Output Class Initialized
INFO - 2024-07-14 07:49:12 --> Security Class Initialized
DEBUG - 2024-07-14 07:49:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-07-14 07:49:12 --> Input Class Initialized
INFO - 2024-07-14 07:49:12 --> Language Class Initialized
INFO - 2024-07-14 07:49:12 --> Language Class Initialized
INFO - 2024-07-14 07:49:12 --> Config Class Initialized
INFO - 2024-07-14 07:49:12 --> Loader Class Initialized
INFO - 2024-07-14 07:49:12 --> Helper loaded: url_helper
INFO - 2024-07-14 07:49:12 --> Helper loaded: file_helper
INFO - 2024-07-14 07:49:12 --> Helper loaded: form_helper
INFO - 2024-07-14 07:49:12 --> Helper loaded: my_helper
INFO - 2024-07-14 07:49:12 --> Database Driver Class Initialized
INFO - 2024-07-14 07:49:12 --> Session: Class initialized using 'files' driver.
INFO - 2024-07-14 07:49:12 --> Controller Class Initialized
DEBUG - 2024-07-14 07:49:12 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/lihat_raport/views/list.php
DEBUG - 2024-07-14 07:49:12 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-07-14 07:49:12 --> Final output sent to browser
DEBUG - 2024-07-14 07:49:12 --> Total execution time: 0.0459
INFO - 2024-07-14 07:49:12 --> Config Class Initialized
INFO - 2024-07-14 07:49:12 --> Hooks Class Initialized
DEBUG - 2024-07-14 07:49:12 --> UTF-8 Support Enabled
INFO - 2024-07-14 07:49:12 --> Utf8 Class Initialized
INFO - 2024-07-14 07:49:12 --> URI Class Initialized
INFO - 2024-07-14 07:49:12 --> Router Class Initialized
INFO - 2024-07-14 07:49:12 --> Output Class Initialized
INFO - 2024-07-14 07:49:12 --> Security Class Initialized
DEBUG - 2024-07-14 07:49:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-07-14 07:49:12 --> Input Class Initialized
INFO - 2024-07-14 07:49:12 --> Language Class Initialized
INFO - 2024-07-14 07:49:12 --> Language Class Initialized
INFO - 2024-07-14 07:49:12 --> Config Class Initialized
INFO - 2024-07-14 07:49:12 --> Loader Class Initialized
INFO - 2024-07-14 07:49:12 --> Helper loaded: url_helper
INFO - 2024-07-14 07:49:12 --> Helper loaded: file_helper
INFO - 2024-07-14 07:49:12 --> Helper loaded: form_helper
INFO - 2024-07-14 07:49:12 --> Helper loaded: my_helper
INFO - 2024-07-14 07:49:12 --> Database Driver Class Initialized
INFO - 2024-07-14 07:49:12 --> Session: Class initialized using 'files' driver.
INFO - 2024-07-14 07:49:12 --> Controller Class Initialized
INFO - 2024-07-14 07:49:12 --> Helper loaded: cookie_helper
INFO - 2024-07-14 07:49:12 --> Config Class Initialized
INFO - 2024-07-14 07:49:12 --> Hooks Class Initialized
DEBUG - 2024-07-14 07:49:12 --> UTF-8 Support Enabled
INFO - 2024-07-14 07:49:12 --> Utf8 Class Initialized
INFO - 2024-07-14 07:49:12 --> URI Class Initialized
INFO - 2024-07-14 07:49:12 --> Router Class Initialized
INFO - 2024-07-14 07:49:12 --> Output Class Initialized
INFO - 2024-07-14 07:49:12 --> Security Class Initialized
DEBUG - 2024-07-14 07:49:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-07-14 07:49:12 --> Input Class Initialized
INFO - 2024-07-14 07:49:12 --> Language Class Initialized
INFO - 2024-07-14 07:49:12 --> Language Class Initialized
INFO - 2024-07-14 07:49:12 --> Config Class Initialized
INFO - 2024-07-14 07:49:12 --> Loader Class Initialized
INFO - 2024-07-14 07:49:12 --> Helper loaded: url_helper
INFO - 2024-07-14 07:49:12 --> Helper loaded: file_helper
INFO - 2024-07-14 07:49:12 --> Helper loaded: form_helper
INFO - 2024-07-14 07:49:12 --> Helper loaded: my_helper
INFO - 2024-07-14 07:49:12 --> Database Driver Class Initialized
INFO - 2024-07-14 07:49:12 --> Session: Class initialized using 'files' driver.
INFO - 2024-07-14 07:49:12 --> Controller Class Initialized
DEBUG - 2024-07-14 07:49:12 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/lihat_raport/views/list.php
DEBUG - 2024-07-14 07:49:12 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-07-14 07:49:12 --> Final output sent to browser
DEBUG - 2024-07-14 07:49:12 --> Total execution time: 0.0400
INFO - 2024-07-14 07:49:13 --> Config Class Initialized
INFO - 2024-07-14 07:49:13 --> Hooks Class Initialized
DEBUG - 2024-07-14 07:49:13 --> UTF-8 Support Enabled
INFO - 2024-07-14 07:49:13 --> Utf8 Class Initialized
INFO - 2024-07-14 07:49:13 --> URI Class Initialized
INFO - 2024-07-14 07:49:13 --> Router Class Initialized
INFO - 2024-07-14 07:49:13 --> Output Class Initialized
INFO - 2024-07-14 07:49:13 --> Security Class Initialized
DEBUG - 2024-07-14 07:49:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-07-14 07:49:13 --> Input Class Initialized
INFO - 2024-07-14 07:49:13 --> Language Class Initialized
INFO - 2024-07-14 07:49:13 --> Language Class Initialized
INFO - 2024-07-14 07:49:13 --> Config Class Initialized
INFO - 2024-07-14 07:49:13 --> Loader Class Initialized
INFO - 2024-07-14 07:49:13 --> Helper loaded: url_helper
INFO - 2024-07-14 07:49:13 --> Helper loaded: file_helper
INFO - 2024-07-14 07:49:13 --> Helper loaded: form_helper
INFO - 2024-07-14 07:49:13 --> Helper loaded: my_helper
INFO - 2024-07-14 07:49:13 --> Database Driver Class Initialized
INFO - 2024-07-14 07:49:13 --> Session: Class initialized using 'files' driver.
INFO - 2024-07-14 07:49:13 --> Controller Class Initialized
INFO - 2024-07-14 07:49:13 --> Helper loaded: cookie_helper
INFO - 2024-07-14 07:49:13 --> Final output sent to browser
DEBUG - 2024-07-14 07:49:13 --> Total execution time: 0.0334
INFO - 2024-07-14 07:49:13 --> Config Class Initialized
INFO - 2024-07-14 07:49:13 --> Hooks Class Initialized
DEBUG - 2024-07-14 07:49:13 --> UTF-8 Support Enabled
INFO - 2024-07-14 07:49:13 --> Utf8 Class Initialized
INFO - 2024-07-14 07:49:13 --> URI Class Initialized
INFO - 2024-07-14 07:49:13 --> Router Class Initialized
INFO - 2024-07-14 07:49:13 --> Output Class Initialized
INFO - 2024-07-14 07:49:13 --> Security Class Initialized
DEBUG - 2024-07-14 07:49:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-07-14 07:49:13 --> Input Class Initialized
INFO - 2024-07-14 07:49:13 --> Language Class Initialized
INFO - 2024-07-14 07:49:13 --> Language Class Initialized
INFO - 2024-07-14 07:49:13 --> Config Class Initialized
INFO - 2024-07-14 07:49:13 --> Loader Class Initialized
INFO - 2024-07-14 07:49:13 --> Helper loaded: url_helper
INFO - 2024-07-14 07:49:13 --> Helper loaded: file_helper
INFO - 2024-07-14 07:49:13 --> Helper loaded: form_helper
INFO - 2024-07-14 07:49:13 --> Helper loaded: my_helper
INFO - 2024-07-14 07:49:13 --> Database Driver Class Initialized
INFO - 2024-07-14 07:49:13 --> Session: Class initialized using 'files' driver.
INFO - 2024-07-14 07:49:13 --> Controller Class Initialized
INFO - 2024-07-14 07:49:13 --> Helper loaded: cookie_helper
INFO - 2024-07-14 07:49:14 --> Config Class Initialized
INFO - 2024-07-14 07:49:14 --> Hooks Class Initialized
DEBUG - 2024-07-14 07:49:14 --> UTF-8 Support Enabled
INFO - 2024-07-14 07:49:14 --> Utf8 Class Initialized
INFO - 2024-07-14 07:49:14 --> URI Class Initialized
INFO - 2024-07-14 07:49:14 --> Router Class Initialized
INFO - 2024-07-14 07:49:14 --> Output Class Initialized
INFO - 2024-07-14 07:49:14 --> Security Class Initialized
DEBUG - 2024-07-14 07:49:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-07-14 07:49:14 --> Input Class Initialized
INFO - 2024-07-14 07:49:14 --> Language Class Initialized
INFO - 2024-07-14 07:49:14 --> Language Class Initialized
INFO - 2024-07-14 07:49:14 --> Config Class Initialized
INFO - 2024-07-14 07:49:14 --> Loader Class Initialized
INFO - 2024-07-14 07:49:14 --> Helper loaded: url_helper
INFO - 2024-07-14 07:49:14 --> Helper loaded: file_helper
INFO - 2024-07-14 07:49:14 --> Helper loaded: form_helper
INFO - 2024-07-14 07:49:14 --> Helper loaded: my_helper
INFO - 2024-07-14 07:49:14 --> Database Driver Class Initialized
INFO - 2024-07-14 07:49:14 --> Config Class Initialized
INFO - 2024-07-14 07:49:14 --> Hooks Class Initialized
DEBUG - 2024-07-14 07:49:14 --> UTF-8 Support Enabled
INFO - 2024-07-14 07:49:14 --> Utf8 Class Initialized
INFO - 2024-07-14 07:49:14 --> Session: Class initialized using 'files' driver.
INFO - 2024-07-14 07:49:14 --> Controller Class Initialized
INFO - 2024-07-14 07:49:14 --> URI Class Initialized
INFO - 2024-07-14 07:49:14 --> Router Class Initialized
INFO - 2024-07-14 07:49:14 --> Output Class Initialized
INFO - 2024-07-14 07:49:14 --> Security Class Initialized
DEBUG - 2024-07-14 07:49:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-07-14 07:49:14 --> Input Class Initialized
INFO - 2024-07-14 07:49:14 --> Language Class Initialized
INFO - 2024-07-14 07:49:14 --> Language Class Initialized
INFO - 2024-07-14 07:49:14 --> Config Class Initialized
INFO - 2024-07-14 07:49:14 --> Loader Class Initialized
INFO - 2024-07-14 07:49:14 --> Helper loaded: url_helper
INFO - 2024-07-14 07:49:14 --> Helper loaded: file_helper
INFO - 2024-07-14 07:49:14 --> Helper loaded: form_helper
INFO - 2024-07-14 07:49:14 --> Helper loaded: my_helper
DEBUG - 2024-07-14 07:49:14 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/lihat_raport/views/list.php
DEBUG - 2024-07-14 07:49:14 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-07-14 07:49:14 --> Final output sent to browser
DEBUG - 2024-07-14 07:49:14 --> Total execution time: 0.0547
INFO - 2024-07-14 07:49:14 --> Database Driver Class Initialized
INFO - 2024-07-14 07:49:14 --> Session: Class initialized using 'files' driver.
INFO - 2024-07-14 07:49:14 --> Controller Class Initialized
DEBUG - 2024-07-14 07:49:14 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/lihat_raport/views/list.php
DEBUG - 2024-07-14 07:49:14 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-07-14 07:49:14 --> Final output sent to browser
DEBUG - 2024-07-14 07:49:14 --> Total execution time: 0.0398
INFO - 2024-07-14 07:49:38 --> Config Class Initialized
INFO - 2024-07-14 07:49:38 --> Hooks Class Initialized
DEBUG - 2024-07-14 07:49:38 --> UTF-8 Support Enabled
INFO - 2024-07-14 07:49:38 --> Utf8 Class Initialized
INFO - 2024-07-14 07:49:38 --> URI Class Initialized
INFO - 2024-07-14 07:49:38 --> Router Class Initialized
INFO - 2024-07-14 07:49:38 --> Output Class Initialized
INFO - 2024-07-14 07:49:38 --> Security Class Initialized
DEBUG - 2024-07-14 07:49:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-07-14 07:49:38 --> Input Class Initialized
INFO - 2024-07-14 07:49:38 --> Language Class Initialized
INFO - 2024-07-14 07:49:38 --> Language Class Initialized
INFO - 2024-07-14 07:49:38 --> Config Class Initialized
INFO - 2024-07-14 07:49:38 --> Loader Class Initialized
INFO - 2024-07-14 07:49:38 --> Helper loaded: url_helper
INFO - 2024-07-14 07:49:38 --> Helper loaded: file_helper
INFO - 2024-07-14 07:49:38 --> Helper loaded: form_helper
INFO - 2024-07-14 07:49:38 --> Helper loaded: my_helper
INFO - 2024-07-14 07:49:38 --> Database Driver Class Initialized
INFO - 2024-07-14 07:49:38 --> Session: Class initialized using 'files' driver.
INFO - 2024-07-14 07:49:38 --> Controller Class Initialized
INFO - 2024-07-14 07:49:38 --> Helper loaded: cookie_helper
INFO - 2024-07-14 07:49:38 --> Final output sent to browser
DEBUG - 2024-07-14 07:49:38 --> Total execution time: 0.0326
INFO - 2024-07-14 07:49:39 --> Config Class Initialized
INFO - 2024-07-14 07:49:39 --> Hooks Class Initialized
DEBUG - 2024-07-14 07:49:39 --> UTF-8 Support Enabled
INFO - 2024-07-14 07:49:39 --> Utf8 Class Initialized
INFO - 2024-07-14 07:49:39 --> URI Class Initialized
INFO - 2024-07-14 07:49:39 --> Router Class Initialized
INFO - 2024-07-14 07:49:39 --> Output Class Initialized
INFO - 2024-07-14 07:49:39 --> Security Class Initialized
DEBUG - 2024-07-14 07:49:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-07-14 07:49:39 --> Input Class Initialized
INFO - 2024-07-14 07:49:39 --> Language Class Initialized
INFO - 2024-07-14 07:49:39 --> Language Class Initialized
INFO - 2024-07-14 07:49:39 --> Config Class Initialized
INFO - 2024-07-14 07:49:39 --> Loader Class Initialized
INFO - 2024-07-14 07:49:39 --> Helper loaded: url_helper
INFO - 2024-07-14 07:49:39 --> Helper loaded: file_helper
INFO - 2024-07-14 07:49:39 --> Helper loaded: form_helper
INFO - 2024-07-14 07:49:39 --> Helper loaded: my_helper
INFO - 2024-07-14 07:49:39 --> Database Driver Class Initialized
INFO - 2024-07-14 07:49:39 --> Session: Class initialized using 'files' driver.
INFO - 2024-07-14 07:49:39 --> Controller Class Initialized
INFO - 2024-07-14 07:49:39 --> Helper loaded: cookie_helper
INFO - 2024-07-14 07:49:39 --> Config Class Initialized
INFO - 2024-07-14 07:49:39 --> Hooks Class Initialized
DEBUG - 2024-07-14 07:49:39 --> UTF-8 Support Enabled
INFO - 2024-07-14 07:49:39 --> Utf8 Class Initialized
INFO - 2024-07-14 07:49:39 --> URI Class Initialized
INFO - 2024-07-14 07:49:39 --> Router Class Initialized
INFO - 2024-07-14 07:49:39 --> Output Class Initialized
INFO - 2024-07-14 07:49:39 --> Security Class Initialized
DEBUG - 2024-07-14 07:49:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-07-14 07:49:39 --> Input Class Initialized
INFO - 2024-07-14 07:49:39 --> Language Class Initialized
INFO - 2024-07-14 07:49:39 --> Language Class Initialized
INFO - 2024-07-14 07:49:39 --> Config Class Initialized
INFO - 2024-07-14 07:49:39 --> Loader Class Initialized
INFO - 2024-07-14 07:49:39 --> Helper loaded: url_helper
INFO - 2024-07-14 07:49:39 --> Helper loaded: file_helper
INFO - 2024-07-14 07:49:39 --> Helper loaded: form_helper
INFO - 2024-07-14 07:49:39 --> Helper loaded: my_helper
INFO - 2024-07-14 07:49:39 --> Database Driver Class Initialized
INFO - 2024-07-14 07:49:39 --> Session: Class initialized using 'files' driver.
INFO - 2024-07-14 07:49:39 --> Controller Class Initialized
DEBUG - 2024-07-14 07:49:39 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/lihat_raport/views/list.php
DEBUG - 2024-07-14 07:49:39 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-07-14 07:49:39 --> Final output sent to browser
DEBUG - 2024-07-14 07:49:39 --> Total execution time: 0.0467
INFO - 2024-07-14 07:49:52 --> Config Class Initialized
INFO - 2024-07-14 07:49:52 --> Hooks Class Initialized
DEBUG - 2024-07-14 07:49:52 --> UTF-8 Support Enabled
INFO - 2024-07-14 07:49:52 --> Utf8 Class Initialized
INFO - 2024-07-14 07:49:52 --> URI Class Initialized
INFO - 2024-07-14 07:49:52 --> Router Class Initialized
INFO - 2024-07-14 07:49:52 --> Output Class Initialized
INFO - 2024-07-14 07:49:52 --> Security Class Initialized
DEBUG - 2024-07-14 07:49:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-07-14 07:49:52 --> Input Class Initialized
INFO - 2024-07-14 07:49:52 --> Language Class Initialized
INFO - 2024-07-14 07:49:52 --> Language Class Initialized
INFO - 2024-07-14 07:49:52 --> Config Class Initialized
INFO - 2024-07-14 07:49:52 --> Loader Class Initialized
INFO - 2024-07-14 07:49:52 --> Helper loaded: url_helper
INFO - 2024-07-14 07:49:52 --> Helper loaded: file_helper
INFO - 2024-07-14 07:49:52 --> Helper loaded: form_helper
INFO - 2024-07-14 07:49:52 --> Helper loaded: my_helper
INFO - 2024-07-14 07:49:52 --> Database Driver Class Initialized
INFO - 2024-07-14 07:49:52 --> Session: Class initialized using 'files' driver.
INFO - 2024-07-14 07:49:52 --> Controller Class Initialized
ERROR - 2024-07-14 07:49:52 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php 36
ERROR - 2024-07-14 07:49:52 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php 119
ERROR - 2024-07-14 07:49:52 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php 126
DEBUG - 2024-07-14 07:49:52 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php
ERROR - 2024-07-14 07:49:55 --> Severity: error --> Exception: The content of the TD tag does not fit on only one page /www/wwwroot/report.mhis.link/bangka/secondary/aset/html2pdf/spipu/html2pdf/src/Html2Pdf.php 5680
ERROR - 2024-07-14 07:49:55 --> Severity: Warning --> unlink(/tmp/__tcpdf_7d9cda40de8a6c90fbe0b50a9d24b74b_imgmask_alpha_5c8c5820de2d21abc04c055a7edbdf01): No such file or directory /www/wwwroot/report.mhis.link/bangka/secondary/aset/html2pdf/tecnickcom/tcpdf/tcpdf.php 7801
ERROR - 2024-07-14 07:49:55 --> Severity: Warning --> unlink(/tmp/__tcpdf_7d9cda40de8a6c90fbe0b50a9d24b74b_imgmask_plain_5c8c5820de2d21abc04c055a7edbdf01): No such file or directory /www/wwwroot/report.mhis.link/bangka/secondary/aset/html2pdf/tecnickcom/tcpdf/tcpdf.php 7801
ERROR - 2024-07-14 07:49:55 --> Severity: Warning --> unlink(/tmp/__tcpdf_7d9cda40de8a6c90fbe0b50a9d24b74b_imgmask_alpha_9b9826062a8f1eb306f7a4635f009d01): No such file or directory /www/wwwroot/report.mhis.link/bangka/secondary/aset/html2pdf/tecnickcom/tcpdf/tcpdf.php 7801
ERROR - 2024-07-14 07:49:55 --> Severity: Warning --> unlink(/tmp/__tcpdf_7d9cda40de8a6c90fbe0b50a9d24b74b_imgmask_plain_9b9826062a8f1eb306f7a4635f009d01): No such file or directory /www/wwwroot/report.mhis.link/bangka/secondary/aset/html2pdf/tecnickcom/tcpdf/tcpdf.php 7801
INFO - 2024-07-14 07:50:09 --> Config Class Initialized
INFO - 2024-07-14 07:50:09 --> Hooks Class Initialized
DEBUG - 2024-07-14 07:50:09 --> UTF-8 Support Enabled
INFO - 2024-07-14 07:50:09 --> Utf8 Class Initialized
INFO - 2024-07-14 07:50:09 --> URI Class Initialized
INFO - 2024-07-14 07:50:09 --> Router Class Initialized
INFO - 2024-07-14 07:50:09 --> Output Class Initialized
INFO - 2024-07-14 07:50:09 --> Security Class Initialized
DEBUG - 2024-07-14 07:50:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-07-14 07:50:09 --> Input Class Initialized
INFO - 2024-07-14 07:50:09 --> Language Class Initialized
INFO - 2024-07-14 07:50:09 --> Language Class Initialized
INFO - 2024-07-14 07:50:09 --> Config Class Initialized
INFO - 2024-07-14 07:50:09 --> Loader Class Initialized
INFO - 2024-07-14 07:50:09 --> Helper loaded: url_helper
INFO - 2024-07-14 07:50:09 --> Helper loaded: file_helper
INFO - 2024-07-14 07:50:09 --> Helper loaded: form_helper
INFO - 2024-07-14 07:50:09 --> Helper loaded: my_helper
INFO - 2024-07-14 07:50:09 --> Database Driver Class Initialized
INFO - 2024-07-14 07:50:09 --> Session: Class initialized using 'files' driver.
INFO - 2024-07-14 07:50:09 --> Controller Class Initialized
DEBUG - 2024-07-14 07:50:09 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/views/cetak_tahfiz.php
INFO - 2024-07-14 07:50:12 --> Final output sent to browser
DEBUG - 2024-07-14 07:50:12 --> Total execution time: 3.2832
INFO - 2024-07-14 07:52:10 --> Config Class Initialized
INFO - 2024-07-14 07:52:10 --> Hooks Class Initialized
DEBUG - 2024-07-14 07:52:10 --> UTF-8 Support Enabled
INFO - 2024-07-14 07:52:10 --> Utf8 Class Initialized
INFO - 2024-07-14 07:52:10 --> URI Class Initialized
INFO - 2024-07-14 07:52:10 --> Router Class Initialized
INFO - 2024-07-14 07:52:10 --> Output Class Initialized
INFO - 2024-07-14 07:52:10 --> Security Class Initialized
DEBUG - 2024-07-14 07:52:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-07-14 07:52:10 --> Input Class Initialized
INFO - 2024-07-14 07:52:10 --> Language Class Initialized
INFO - 2024-07-14 07:52:10 --> Language Class Initialized
INFO - 2024-07-14 07:52:10 --> Config Class Initialized
INFO - 2024-07-14 07:52:10 --> Loader Class Initialized
INFO - 2024-07-14 07:52:10 --> Helper loaded: url_helper
INFO - 2024-07-14 07:52:10 --> Helper loaded: file_helper
INFO - 2024-07-14 07:52:10 --> Helper loaded: form_helper
INFO - 2024-07-14 07:52:10 --> Helper loaded: my_helper
INFO - 2024-07-14 07:52:10 --> Database Driver Class Initialized
INFO - 2024-07-14 07:52:10 --> Session: Class initialized using 'files' driver.
INFO - 2024-07-14 07:52:10 --> Controller Class Initialized
ERROR - 2024-07-14 07:52:10 --> Severity: Notice --> Undefined index: projek /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1837
ERROR - 2024-07-14 07:52:10 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2024-07-14 07:52:10 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2024-07-14 07:52:10 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2024-07-14 07:52:10 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2024-07-14 07:52:10 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2024-07-14 07:52:10 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2024-07-14 07:52:10 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2024-07-14 07:52:10 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2024-07-14 07:52:10 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2024-07-14 07:52:10 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2024-07-14 07:52:10 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2024-07-14 07:52:10 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2024-07-14 07:52:10 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2024-07-14 07:52:10 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2024-07-14 07:52:10 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2024-07-14 07:52:10 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2024-07-14 07:52:10 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2024-07-14 07:52:10 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2024-07-14 07:52:10 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2024-07-14 07:52:10 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2024-07-14 07:52:10 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2024-07-14 07:52:10 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2024-07-14 07:52:10 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2024-07-14 07:52:10 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2024-07-14 07:52:10 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2024-07-14 07:52:10 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2024-07-14 07:52:10 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2024-07-14 07:52:10 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2024-07-14 07:52:10 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2024-07-14 07:52:10 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2024-07-14 07:52:10 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2024-07-14 07:52:10 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2024-07-14 07:52:10 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2024-07-14 07:52:10 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2024-07-14 07:52:10 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2024-07-14 07:52:10 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2024-07-14 07:52:10 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2024-07-14 07:52:10 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2024-07-14 07:52:10 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2024-07-14 07:52:10 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/views/cetak_projek.php 67
ERROR - 2024-07-14 07:52:10 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/views/cetak_projek.php 297
ERROR - 2024-07-14 07:52:10 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/views/cetak_projek.php 307
DEBUG - 2024-07-14 07:52:10 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/views/cetak_projek.php
ERROR - 2024-07-14 07:52:14 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 2031
INFO - 2024-07-14 07:52:15 --> Final output sent to browser
DEBUG - 2024-07-14 07:52:15 --> Total execution time: 5.1201
INFO - 2024-07-14 07:55:16 --> Config Class Initialized
INFO - 2024-07-14 07:55:16 --> Hooks Class Initialized
DEBUG - 2024-07-14 07:55:16 --> UTF-8 Support Enabled
INFO - 2024-07-14 07:55:16 --> Utf8 Class Initialized
INFO - 2024-07-14 07:55:16 --> URI Class Initialized
INFO - 2024-07-14 07:55:16 --> Router Class Initialized
INFO - 2024-07-14 07:55:16 --> Output Class Initialized
INFO - 2024-07-14 07:55:16 --> Security Class Initialized
DEBUG - 2024-07-14 07:55:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-07-14 07:55:16 --> Input Class Initialized
INFO - 2024-07-14 07:55:16 --> Language Class Initialized
INFO - 2024-07-14 07:55:16 --> Language Class Initialized
INFO - 2024-07-14 07:55:16 --> Config Class Initialized
INFO - 2024-07-14 07:55:16 --> Loader Class Initialized
INFO - 2024-07-14 07:55:16 --> Helper loaded: url_helper
INFO - 2024-07-14 07:55:16 --> Helper loaded: file_helper
INFO - 2024-07-14 07:55:16 --> Helper loaded: form_helper
INFO - 2024-07-14 07:55:16 --> Helper loaded: my_helper
INFO - 2024-07-14 07:55:16 --> Database Driver Class Initialized
INFO - 2024-07-14 07:55:16 --> Session: Class initialized using 'files' driver.
INFO - 2024-07-14 07:55:16 --> Controller Class Initialized
ERROR - 2024-07-14 07:55:16 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/views/cetak_mh.php 48
ERROR - 2024-07-14 07:55:16 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/views/cetak_mh.php 143
ERROR - 2024-07-14 07:55:16 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/views/cetak_mh.php 150
DEBUG - 2024-07-14 07:55:16 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/views/cetak_mh.php
ERROR - 2024-07-14 07:55:21 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 3875
ERROR - 2024-07-14 07:55:21 --> Severity: error --> Exception: TCPDF ERROR: Some data has already been output, can't send PDF file /www/wwwroot/report.mhis.link/bangka/secondary/aset/html2pdf/tecnickcom/tcpdf/tcpdf.php 2950
INFO - 2024-07-14 07:55:29 --> Config Class Initialized
INFO - 2024-07-14 07:55:29 --> Hooks Class Initialized
DEBUG - 2024-07-14 07:55:29 --> UTF-8 Support Enabled
INFO - 2024-07-14 07:55:29 --> Utf8 Class Initialized
INFO - 2024-07-14 07:55:29 --> URI Class Initialized
INFO - 2024-07-14 07:55:29 --> Router Class Initialized
INFO - 2024-07-14 07:55:29 --> Output Class Initialized
INFO - 2024-07-14 07:55:29 --> Security Class Initialized
DEBUG - 2024-07-14 07:55:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-07-14 07:55:29 --> Input Class Initialized
INFO - 2024-07-14 07:55:29 --> Language Class Initialized
INFO - 2024-07-14 07:55:29 --> Language Class Initialized
INFO - 2024-07-14 07:55:29 --> Config Class Initialized
INFO - 2024-07-14 07:55:29 --> Loader Class Initialized
INFO - 2024-07-14 07:55:29 --> Helper loaded: url_helper
INFO - 2024-07-14 07:55:29 --> Helper loaded: file_helper
INFO - 2024-07-14 07:55:29 --> Helper loaded: form_helper
INFO - 2024-07-14 07:55:29 --> Helper loaded: my_helper
INFO - 2024-07-14 07:55:29 --> Database Driver Class Initialized
INFO - 2024-07-14 07:55:29 --> Session: Class initialized using 'files' driver.
INFO - 2024-07-14 07:55:29 --> Controller Class Initialized
ERROR - 2024-07-14 07:55:30 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/views/cetak_ikm.php 64
ERROR - 2024-07-14 07:55:30 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/views/cetak_ikm.php 307
ERROR - 2024-07-14 07:55:30 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/views/cetak_ikm.php 317
DEBUG - 2024-07-14 07:55:30 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/views/cetak_ikm.php
ERROR - 2024-07-14 07:55:31 --> Severity: error --> Exception: The content of the TD tag does not fit on only one page /www/wwwroot/report.mhis.link/bangka/secondary/aset/html2pdf/spipu/html2pdf/src/Html2Pdf.php 5680
ERROR - 2024-07-14 07:55:31 --> Severity: Warning --> unlink(/tmp/__tcpdf_946d3260d390923a0119a3d9d8bd6f1f_imgmask_alpha_5c8c5820de2d21abc04c055a7edbdf01): No such file or directory /www/wwwroot/report.mhis.link/bangka/secondary/aset/html2pdf/tecnickcom/tcpdf/tcpdf.php 7801
ERROR - 2024-07-14 07:55:31 --> Severity: Warning --> unlink(/tmp/__tcpdf_946d3260d390923a0119a3d9d8bd6f1f_imgmask_plain_5c8c5820de2d21abc04c055a7edbdf01): No such file or directory /www/wwwroot/report.mhis.link/bangka/secondary/aset/html2pdf/tecnickcom/tcpdf/tcpdf.php 7801
INFO - 2024-07-14 07:55:36 --> Config Class Initialized
INFO - 2024-07-14 07:55:36 --> Hooks Class Initialized
DEBUG - 2024-07-14 07:55:36 --> UTF-8 Support Enabled
INFO - 2024-07-14 07:55:36 --> Utf8 Class Initialized
INFO - 2024-07-14 07:55:36 --> URI Class Initialized
INFO - 2024-07-14 07:55:36 --> Router Class Initialized
INFO - 2024-07-14 07:55:36 --> Output Class Initialized
INFO - 2024-07-14 07:55:36 --> Security Class Initialized
DEBUG - 2024-07-14 07:55:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-07-14 07:55:36 --> Input Class Initialized
INFO - 2024-07-14 07:55:36 --> Language Class Initialized
INFO - 2024-07-14 07:55:36 --> Language Class Initialized
INFO - 2024-07-14 07:55:36 --> Config Class Initialized
INFO - 2024-07-14 07:55:36 --> Loader Class Initialized
INFO - 2024-07-14 07:55:36 --> Helper loaded: url_helper
INFO - 2024-07-14 07:55:36 --> Helper loaded: file_helper
INFO - 2024-07-14 07:55:36 --> Helper loaded: form_helper
INFO - 2024-07-14 07:55:36 --> Helper loaded: my_helper
INFO - 2024-07-14 07:55:36 --> Database Driver Class Initialized
INFO - 2024-07-14 07:55:36 --> Session: Class initialized using 'files' driver.
INFO - 2024-07-14 07:55:36 --> Controller Class Initialized
ERROR - 2024-07-14 07:55:36 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php 36
ERROR - 2024-07-14 07:55:36 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php 119
ERROR - 2024-07-14 07:55:36 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php 126
DEBUG - 2024-07-14 07:55:36 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php
INFO - 2024-07-14 07:55:39 --> Final output sent to browser
DEBUG - 2024-07-14 07:55:39 --> Total execution time: 2.6200
INFO - 2024-07-14 07:56:59 --> Config Class Initialized
INFO - 2024-07-14 07:56:59 --> Hooks Class Initialized
DEBUG - 2024-07-14 07:56:59 --> UTF-8 Support Enabled
INFO - 2024-07-14 07:56:59 --> Utf8 Class Initialized
INFO - 2024-07-14 07:56:59 --> URI Class Initialized
INFO - 2024-07-14 07:56:59 --> Router Class Initialized
INFO - 2024-07-14 07:56:59 --> Output Class Initialized
INFO - 2024-07-14 07:56:59 --> Security Class Initialized
DEBUG - 2024-07-14 07:56:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-07-14 07:56:59 --> Input Class Initialized
INFO - 2024-07-14 07:56:59 --> Language Class Initialized
INFO - 2024-07-14 07:56:59 --> Language Class Initialized
INFO - 2024-07-14 07:56:59 --> Config Class Initialized
INFO - 2024-07-14 07:56:59 --> Loader Class Initialized
INFO - 2024-07-14 07:56:59 --> Helper loaded: url_helper
INFO - 2024-07-14 07:56:59 --> Helper loaded: file_helper
INFO - 2024-07-14 07:56:59 --> Helper loaded: form_helper
INFO - 2024-07-14 07:56:59 --> Helper loaded: my_helper
INFO - 2024-07-14 07:56:59 --> Database Driver Class Initialized
INFO - 2024-07-14 07:56:59 --> Session: Class initialized using 'files' driver.
INFO - 2024-07-14 07:56:59 --> Controller Class Initialized
ERROR - 2024-07-14 07:56:59 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/views/cetak_mh.php 48
ERROR - 2024-07-14 07:56:59 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/views/cetak_mh.php 143
ERROR - 2024-07-14 07:56:59 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/views/cetak_mh.php 150
DEBUG - 2024-07-14 07:56:59 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/views/cetak_mh.php
ERROR - 2024-07-14 07:57:03 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 3875
ERROR - 2024-07-14 07:57:03 --> Severity: error --> Exception: TCPDF ERROR: Some data has already been output, can't send PDF file /www/wwwroot/report.mhis.link/bangka/secondary/aset/html2pdf/tecnickcom/tcpdf/tcpdf.php 2950
INFO - 2024-07-14 07:57:05 --> Config Class Initialized
INFO - 2024-07-14 07:57:05 --> Hooks Class Initialized
DEBUG - 2024-07-14 07:57:05 --> UTF-8 Support Enabled
INFO - 2024-07-14 07:57:05 --> Utf8 Class Initialized
INFO - 2024-07-14 07:57:05 --> URI Class Initialized
INFO - 2024-07-14 07:57:05 --> Router Class Initialized
INFO - 2024-07-14 07:57:05 --> Output Class Initialized
INFO - 2024-07-14 07:57:05 --> Security Class Initialized
DEBUG - 2024-07-14 07:57:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-07-14 07:57:05 --> Input Class Initialized
INFO - 2024-07-14 07:57:05 --> Language Class Initialized
INFO - 2024-07-14 07:57:05 --> Language Class Initialized
INFO - 2024-07-14 07:57:05 --> Config Class Initialized
INFO - 2024-07-14 07:57:05 --> Loader Class Initialized
INFO - 2024-07-14 07:57:05 --> Helper loaded: url_helper
INFO - 2024-07-14 07:57:05 --> Helper loaded: file_helper
INFO - 2024-07-14 07:57:05 --> Helper loaded: form_helper
INFO - 2024-07-14 07:57:05 --> Helper loaded: my_helper
INFO - 2024-07-14 07:57:05 --> Database Driver Class Initialized
INFO - 2024-07-14 07:57:05 --> Session: Class initialized using 'files' driver.
INFO - 2024-07-14 07:57:05 --> Controller Class Initialized
ERROR - 2024-07-14 07:57:05 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/views/cetak_mh.php 48
ERROR - 2024-07-14 07:57:05 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/views/cetak_mh.php 143
ERROR - 2024-07-14 07:57:05 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/views/cetak_mh.php 150
DEBUG - 2024-07-14 07:57:05 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/views/cetak_mh.php
ERROR - 2024-07-14 07:57:10 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 3875
ERROR - 2024-07-14 07:57:10 --> Severity: error --> Exception: TCPDF ERROR: Some data has already been output, can't send PDF file /www/wwwroot/report.mhis.link/bangka/secondary/aset/html2pdf/tecnickcom/tcpdf/tcpdf.php 2950
INFO - 2024-07-14 07:57:10 --> Config Class Initialized
INFO - 2024-07-14 07:57:10 --> Hooks Class Initialized
DEBUG - 2024-07-14 07:57:10 --> UTF-8 Support Enabled
INFO - 2024-07-14 07:57:10 --> Utf8 Class Initialized
INFO - 2024-07-14 07:57:10 --> URI Class Initialized
INFO - 2024-07-14 07:57:10 --> Router Class Initialized
INFO - 2024-07-14 07:57:10 --> Output Class Initialized
INFO - 2024-07-14 07:57:10 --> Security Class Initialized
DEBUG - 2024-07-14 07:57:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-07-14 07:57:10 --> Input Class Initialized
INFO - 2024-07-14 07:57:10 --> Language Class Initialized
INFO - 2024-07-14 07:57:10 --> Language Class Initialized
INFO - 2024-07-14 07:57:10 --> Config Class Initialized
INFO - 2024-07-14 07:57:10 --> Loader Class Initialized
INFO - 2024-07-14 07:57:10 --> Helper loaded: url_helper
INFO - 2024-07-14 07:57:10 --> Helper loaded: file_helper
INFO - 2024-07-14 07:57:10 --> Helper loaded: form_helper
INFO - 2024-07-14 07:57:10 --> Helper loaded: my_helper
INFO - 2024-07-14 07:57:10 --> Database Driver Class Initialized
INFO - 2024-07-14 07:57:10 --> Session: Class initialized using 'files' driver.
INFO - 2024-07-14 07:57:10 --> Controller Class Initialized
ERROR - 2024-07-14 07:57:10 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/views/cetak_ikm.php 64
ERROR - 2024-07-14 07:57:10 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/views/cetak_ikm.php 307
ERROR - 2024-07-14 07:57:10 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/views/cetak_ikm.php 317
DEBUG - 2024-07-14 07:57:10 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/views/cetak_ikm.php
ERROR - 2024-07-14 07:57:11 --> Severity: error --> Exception: The content of the TD tag does not fit on only one page /www/wwwroot/report.mhis.link/bangka/secondary/aset/html2pdf/spipu/html2pdf/src/Html2Pdf.php 5680
ERROR - 2024-07-14 07:57:11 --> Severity: Warning --> unlink(/tmp/__tcpdf_b53015bc89380ad848b2c8aaf5e5db53_imgmask_alpha_5c8c5820de2d21abc04c055a7edbdf01): No such file or directory /www/wwwroot/report.mhis.link/bangka/secondary/aset/html2pdf/tecnickcom/tcpdf/tcpdf.php 7801
ERROR - 2024-07-14 07:57:11 --> Severity: Warning --> unlink(/tmp/__tcpdf_b53015bc89380ad848b2c8aaf5e5db53_imgmask_plain_5c8c5820de2d21abc04c055a7edbdf01): No such file or directory /www/wwwroot/report.mhis.link/bangka/secondary/aset/html2pdf/tecnickcom/tcpdf/tcpdf.php 7801
INFO - 2024-07-14 07:57:25 --> Config Class Initialized
INFO - 2024-07-14 07:57:25 --> Hooks Class Initialized
DEBUG - 2024-07-14 07:57:25 --> UTF-8 Support Enabled
INFO - 2024-07-14 07:57:25 --> Utf8 Class Initialized
INFO - 2024-07-14 07:57:25 --> URI Class Initialized
DEBUG - 2024-07-14 07:57:25 --> No URI present. Default controller set.
INFO - 2024-07-14 07:57:25 --> Router Class Initialized
INFO - 2024-07-14 07:57:25 --> Output Class Initialized
INFO - 2024-07-14 07:57:25 --> Security Class Initialized
DEBUG - 2024-07-14 07:57:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-07-14 07:57:25 --> Input Class Initialized
INFO - 2024-07-14 07:57:25 --> Language Class Initialized
INFO - 2024-07-14 07:57:25 --> Language Class Initialized
INFO - 2024-07-14 07:57:25 --> Config Class Initialized
INFO - 2024-07-14 07:57:25 --> Loader Class Initialized
INFO - 2024-07-14 07:57:25 --> Helper loaded: url_helper
INFO - 2024-07-14 07:57:25 --> Helper loaded: file_helper
INFO - 2024-07-14 07:57:25 --> Helper loaded: form_helper
INFO - 2024-07-14 07:57:25 --> Helper loaded: my_helper
INFO - 2024-07-14 07:57:25 --> Database Driver Class Initialized
INFO - 2024-07-14 07:57:25 --> Session: Class initialized using 'files' driver.
INFO - 2024-07-14 07:57:25 --> Controller Class Initialized
DEBUG - 2024-07-14 07:57:25 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/home/views/v_home_siswa.php
DEBUG - 2024-07-14 07:57:25 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-07-14 07:57:25 --> Final output sent to browser
DEBUG - 2024-07-14 07:57:25 --> Total execution time: 0.0321
