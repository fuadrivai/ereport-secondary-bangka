<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2024-03-26 15:53:31 --> Config Class Initialized
INFO - 2024-03-26 15:53:31 --> Hooks Class Initialized
DEBUG - 2024-03-26 15:53:31 --> UTF-8 Support Enabled
INFO - 2024-03-26 15:53:31 --> Utf8 Class Initialized
INFO - 2024-03-26 15:53:31 --> URI Class Initialized
INFO - 2024-03-26 15:53:31 --> Router Class Initialized
INFO - 2024-03-26 15:53:31 --> Output Class Initialized
INFO - 2024-03-26 15:53:31 --> Security Class Initialized
DEBUG - 2024-03-26 15:53:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-26 15:53:31 --> Input Class Initialized
INFO - 2024-03-26 15:53:31 --> Language Class Initialized
INFO - 2024-03-26 15:53:31 --> Language Class Initialized
INFO - 2024-03-26 15:53:31 --> Config Class Initialized
INFO - 2024-03-26 15:53:31 --> Loader Class Initialized
INFO - 2024-03-26 15:53:31 --> Helper loaded: url_helper
INFO - 2024-03-26 15:53:31 --> Helper loaded: file_helper
INFO - 2024-03-26 15:53:31 --> Helper loaded: form_helper
INFO - 2024-03-26 15:53:31 --> Helper loaded: my_helper
INFO - 2024-03-26 15:53:31 --> Database Driver Class Initialized
INFO - 2024-03-26 15:53:31 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-26 15:53:31 --> Controller Class Initialized
DEBUG - 2024-03-26 15:53:32 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/login/views/login.php
DEBUG - 2024-03-26 15:53:32 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-03-26 15:53:32 --> Final output sent to browser
DEBUG - 2024-03-26 15:53:32 --> Total execution time: 0.5938
INFO - 2024-03-26 16:57:42 --> Config Class Initialized
INFO - 2024-03-26 16:57:42 --> Hooks Class Initialized
DEBUG - 2024-03-26 16:57:42 --> UTF-8 Support Enabled
INFO - 2024-03-26 16:57:42 --> Utf8 Class Initialized
INFO - 2024-03-26 16:57:42 --> URI Class Initialized
INFO - 2024-03-26 16:57:42 --> Router Class Initialized
INFO - 2024-03-26 16:57:42 --> Output Class Initialized
INFO - 2024-03-26 16:57:42 --> Security Class Initialized
DEBUG - 2024-03-26 16:57:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-26 16:57:42 --> Input Class Initialized
INFO - 2024-03-26 16:57:42 --> Language Class Initialized
INFO - 2024-03-26 16:57:42 --> Language Class Initialized
INFO - 2024-03-26 16:57:42 --> Config Class Initialized
INFO - 2024-03-26 16:57:42 --> Loader Class Initialized
INFO - 2024-03-26 16:57:42 --> Helper loaded: url_helper
INFO - 2024-03-26 16:57:42 --> Helper loaded: file_helper
INFO - 2024-03-26 16:57:42 --> Helper loaded: form_helper
INFO - 2024-03-26 16:57:42 --> Helper loaded: my_helper
INFO - 2024-03-26 16:57:42 --> Database Driver Class Initialized
INFO - 2024-03-26 16:57:42 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-26 16:57:42 --> Controller Class Initialized
DEBUG - 2024-03-26 16:57:42 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/home/views/v_home.php
DEBUG - 2024-03-26 16:57:42 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-03-26 16:57:42 --> Final output sent to browser
DEBUG - 2024-03-26 16:57:42 --> Total execution time: 0.0607
