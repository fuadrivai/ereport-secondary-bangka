<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2019-09-18 03:39:30 --> Config Class Initialized
INFO - 2019-09-18 03:39:30 --> Hooks Class Initialized
DEBUG - 2019-09-18 03:39:30 --> UTF-8 Support Enabled
INFO - 2019-09-18 03:39:30 --> Utf8 Class Initialized
INFO - 2019-09-18 03:39:30 --> URI Class Initialized
DEBUG - 2019-09-18 03:39:30 --> No URI present. Default controller set.
INFO - 2019-09-18 03:39:30 --> Router Class Initialized
INFO - 2019-09-18 03:39:30 --> Output Class Initialized
INFO - 2019-09-18 03:39:30 --> Security Class Initialized
DEBUG - 2019-09-18 03:39:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-09-18 03:39:30 --> Input Class Initialized
INFO - 2019-09-18 03:39:30 --> Language Class Initialized
INFO - 2019-09-18 03:39:31 --> Language Class Initialized
INFO - 2019-09-18 03:39:31 --> Config Class Initialized
INFO - 2019-09-18 03:39:31 --> Loader Class Initialized
INFO - 2019-09-18 03:39:31 --> Helper loaded: url_helper
INFO - 2019-09-18 03:39:31 --> Helper loaded: file_helper
INFO - 2019-09-18 03:39:31 --> Helper loaded: form_helper
INFO - 2019-09-18 03:39:31 --> Helper loaded: my_helper
INFO - 2019-09-18 03:39:31 --> Database Driver Class Initialized
DEBUG - 2019-09-18 03:39:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-09-18 03:39:31 --> Session: Class initialized using 'files' driver.
INFO - 2019-09-18 03:39:31 --> Controller Class Initialized
INFO - 2019-09-18 03:40:06 --> Config Class Initialized
INFO - 2019-09-18 03:40:06 --> Hooks Class Initialized
DEBUG - 2019-09-18 03:40:06 --> UTF-8 Support Enabled
INFO - 2019-09-18 03:40:06 --> Utf8 Class Initialized
INFO - 2019-09-18 03:40:06 --> URI Class Initialized
DEBUG - 2019-09-18 03:40:06 --> No URI present. Default controller set.
INFO - 2019-09-18 03:40:06 --> Router Class Initialized
INFO - 2019-09-18 03:40:06 --> Output Class Initialized
INFO - 2019-09-18 03:40:06 --> Security Class Initialized
DEBUG - 2019-09-18 03:40:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-09-18 03:40:06 --> Input Class Initialized
INFO - 2019-09-18 03:40:06 --> Language Class Initialized
INFO - 2019-09-18 03:40:06 --> Language Class Initialized
INFO - 2019-09-18 03:40:06 --> Config Class Initialized
INFO - 2019-09-18 03:40:06 --> Loader Class Initialized
INFO - 2019-09-18 03:40:06 --> Helper loaded: url_helper
INFO - 2019-09-18 03:40:06 --> Helper loaded: file_helper
INFO - 2019-09-18 03:40:06 --> Helper loaded: form_helper
INFO - 2019-09-18 03:40:06 --> Helper loaded: my_helper
INFO - 2019-09-18 03:40:06 --> Database Driver Class Initialized
DEBUG - 2019-09-18 03:40:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-09-18 03:40:06 --> Session: Class initialized using 'files' driver.
INFO - 2019-09-18 03:40:06 --> Controller Class Initialized
INFO - 2019-09-18 03:40:06 --> Config Class Initialized
INFO - 2019-09-18 03:40:06 --> Hooks Class Initialized
DEBUG - 2019-09-18 03:40:06 --> UTF-8 Support Enabled
INFO - 2019-09-18 03:40:06 --> Utf8 Class Initialized
INFO - 2019-09-18 03:40:07 --> URI Class Initialized
INFO - 2019-09-18 03:40:07 --> Router Class Initialized
INFO - 2019-09-18 03:40:07 --> Output Class Initialized
INFO - 2019-09-18 03:40:07 --> Security Class Initialized
DEBUG - 2019-09-18 03:40:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-09-18 03:40:07 --> Input Class Initialized
INFO - 2019-09-18 03:40:07 --> Language Class Initialized
INFO - 2019-09-18 03:40:07 --> Language Class Initialized
INFO - 2019-09-18 03:40:07 --> Config Class Initialized
INFO - 2019-09-18 03:40:07 --> Loader Class Initialized
INFO - 2019-09-18 03:40:07 --> Helper loaded: url_helper
INFO - 2019-09-18 03:40:07 --> Helper loaded: file_helper
INFO - 2019-09-18 03:40:07 --> Helper loaded: form_helper
INFO - 2019-09-18 03:40:07 --> Helper loaded: my_helper
INFO - 2019-09-18 03:40:07 --> Database Driver Class Initialized
DEBUG - 2019-09-18 03:40:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-09-18 03:40:07 --> Session: Class initialized using 'files' driver.
INFO - 2019-09-18 03:40:07 --> Controller Class Initialized
DEBUG - 2019-09-18 03:40:07 --> File loaded: C:\xampp\htdocs\nilai\application\modules/login/views/login.php
DEBUG - 2019-09-18 03:40:07 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2019-09-18 03:40:07 --> Final output sent to browser
DEBUG - 2019-09-18 03:40:07 --> Total execution time: 0.4020
INFO - 2019-09-18 03:40:23 --> Config Class Initialized
INFO - 2019-09-18 03:40:23 --> Hooks Class Initialized
DEBUG - 2019-09-18 03:40:23 --> UTF-8 Support Enabled
INFO - 2019-09-18 03:40:23 --> Utf8 Class Initialized
INFO - 2019-09-18 03:40:23 --> URI Class Initialized
INFO - 2019-09-18 03:40:23 --> Router Class Initialized
INFO - 2019-09-18 03:40:23 --> Output Class Initialized
INFO - 2019-09-18 03:40:23 --> Security Class Initialized
DEBUG - 2019-09-18 03:40:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-09-18 03:40:23 --> Input Class Initialized
INFO - 2019-09-18 03:40:23 --> Language Class Initialized
INFO - 2019-09-18 03:40:23 --> Language Class Initialized
INFO - 2019-09-18 03:40:23 --> Config Class Initialized
INFO - 2019-09-18 03:40:23 --> Loader Class Initialized
INFO - 2019-09-18 03:40:23 --> Helper loaded: url_helper
INFO - 2019-09-18 03:40:23 --> Helper loaded: file_helper
INFO - 2019-09-18 03:40:23 --> Helper loaded: form_helper
INFO - 2019-09-18 03:40:23 --> Helper loaded: my_helper
INFO - 2019-09-18 03:40:23 --> Database Driver Class Initialized
DEBUG - 2019-09-18 03:40:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-09-18 03:40:23 --> Session: Class initialized using 'files' driver.
INFO - 2019-09-18 03:40:23 --> Controller Class Initialized
INFO - 2019-09-18 03:40:23 --> Final output sent to browser
DEBUG - 2019-09-18 03:40:23 --> Total execution time: 0.2450
INFO - 2019-09-18 03:40:42 --> Config Class Initialized
INFO - 2019-09-18 03:40:42 --> Hooks Class Initialized
DEBUG - 2019-09-18 03:40:42 --> UTF-8 Support Enabled
INFO - 2019-09-18 03:40:42 --> Utf8 Class Initialized
INFO - 2019-09-18 03:40:42 --> URI Class Initialized
INFO - 2019-09-18 03:40:42 --> Router Class Initialized
INFO - 2019-09-18 03:40:42 --> Output Class Initialized
INFO - 2019-09-18 03:40:42 --> Security Class Initialized
DEBUG - 2019-09-18 03:40:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-09-18 03:40:42 --> Input Class Initialized
INFO - 2019-09-18 03:40:42 --> Language Class Initialized
INFO - 2019-09-18 03:40:42 --> Language Class Initialized
INFO - 2019-09-18 03:40:42 --> Config Class Initialized
INFO - 2019-09-18 03:40:42 --> Loader Class Initialized
INFO - 2019-09-18 03:40:42 --> Helper loaded: url_helper
INFO - 2019-09-18 03:40:42 --> Helper loaded: file_helper
INFO - 2019-09-18 03:40:42 --> Helper loaded: form_helper
INFO - 2019-09-18 03:40:42 --> Helper loaded: my_helper
INFO - 2019-09-18 03:40:42 --> Database Driver Class Initialized
DEBUG - 2019-09-18 03:40:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-09-18 03:40:42 --> Session: Class initialized using 'files' driver.
INFO - 2019-09-18 03:40:42 --> Controller Class Initialized
DEBUG - 2019-09-18 03:40:42 --> File loaded: C:\xampp\htdocs\nilai\application\modules/login/views/login.php
DEBUG - 2019-09-18 03:40:42 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2019-09-18 03:40:42 --> Final output sent to browser
DEBUG - 2019-09-18 03:40:42 --> Total execution time: 0.2850
INFO - 2019-09-18 03:40:48 --> Config Class Initialized
INFO - 2019-09-18 03:40:48 --> Hooks Class Initialized
DEBUG - 2019-09-18 03:40:48 --> UTF-8 Support Enabled
INFO - 2019-09-18 03:40:48 --> Utf8 Class Initialized
INFO - 2019-09-18 03:40:48 --> URI Class Initialized
INFO - 2019-09-18 03:40:48 --> Router Class Initialized
INFO - 2019-09-18 03:40:48 --> Output Class Initialized
INFO - 2019-09-18 03:40:48 --> Security Class Initialized
DEBUG - 2019-09-18 03:40:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-09-18 03:40:48 --> Input Class Initialized
INFO - 2019-09-18 03:40:48 --> Language Class Initialized
INFO - 2019-09-18 03:40:48 --> Language Class Initialized
INFO - 2019-09-18 03:40:48 --> Config Class Initialized
INFO - 2019-09-18 03:40:48 --> Loader Class Initialized
INFO - 2019-09-18 03:40:48 --> Helper loaded: url_helper
INFO - 2019-09-18 03:40:48 --> Helper loaded: file_helper
INFO - 2019-09-18 03:40:48 --> Helper loaded: form_helper
INFO - 2019-09-18 03:40:48 --> Helper loaded: my_helper
INFO - 2019-09-18 03:40:48 --> Database Driver Class Initialized
DEBUG - 2019-09-18 03:40:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-09-18 03:40:48 --> Session: Class initialized using 'files' driver.
INFO - 2019-09-18 03:40:48 --> Controller Class Initialized
INFO - 2019-09-18 03:40:48 --> Final output sent to browser
DEBUG - 2019-09-18 03:40:48 --> Total execution time: 0.3050
INFO - 2019-09-18 03:41:28 --> Config Class Initialized
INFO - 2019-09-18 03:41:28 --> Hooks Class Initialized
DEBUG - 2019-09-18 03:41:28 --> UTF-8 Support Enabled
INFO - 2019-09-18 03:41:28 --> Utf8 Class Initialized
INFO - 2019-09-18 03:41:28 --> URI Class Initialized
INFO - 2019-09-18 03:41:28 --> Router Class Initialized
INFO - 2019-09-18 03:41:28 --> Output Class Initialized
INFO - 2019-09-18 03:41:28 --> Security Class Initialized
DEBUG - 2019-09-18 03:41:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-09-18 03:41:28 --> Input Class Initialized
INFO - 2019-09-18 03:41:28 --> Language Class Initialized
ERROR - 2019-09-18 03:41:28 --> 404 Page Not Found: /index
INFO - 2019-09-18 03:41:31 --> Config Class Initialized
INFO - 2019-09-18 03:41:31 --> Hooks Class Initialized
DEBUG - 2019-09-18 03:41:31 --> UTF-8 Support Enabled
INFO - 2019-09-18 03:41:31 --> Utf8 Class Initialized
INFO - 2019-09-18 03:41:31 --> URI Class Initialized
INFO - 2019-09-18 03:41:31 --> Router Class Initialized
INFO - 2019-09-18 03:41:31 --> Output Class Initialized
INFO - 2019-09-18 03:41:31 --> Security Class Initialized
DEBUG - 2019-09-18 03:41:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-09-18 03:41:31 --> Input Class Initialized
INFO - 2019-09-18 03:41:31 --> Language Class Initialized
INFO - 2019-09-18 03:41:31 --> Language Class Initialized
INFO - 2019-09-18 03:41:31 --> Config Class Initialized
INFO - 2019-09-18 03:41:31 --> Loader Class Initialized
INFO - 2019-09-18 03:41:31 --> Helper loaded: url_helper
INFO - 2019-09-18 03:41:31 --> Helper loaded: file_helper
INFO - 2019-09-18 03:41:31 --> Helper loaded: form_helper
INFO - 2019-09-18 03:41:31 --> Helper loaded: my_helper
INFO - 2019-09-18 03:41:31 --> Database Driver Class Initialized
DEBUG - 2019-09-18 03:41:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-09-18 03:41:31 --> Session: Class initialized using 'files' driver.
INFO - 2019-09-18 03:41:31 --> Controller Class Initialized
DEBUG - 2019-09-18 03:41:31 --> File loaded: C:\xampp\htdocs\nilai\application\modules/login/views/login.php
DEBUG - 2019-09-18 03:41:31 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2019-09-18 03:41:31 --> Final output sent to browser
DEBUG - 2019-09-18 03:41:31 --> Total execution time: 0.2650
INFO - 2019-09-18 03:41:53 --> Config Class Initialized
INFO - 2019-09-18 03:41:53 --> Hooks Class Initialized
DEBUG - 2019-09-18 03:41:53 --> UTF-8 Support Enabled
INFO - 2019-09-18 03:41:53 --> Utf8 Class Initialized
INFO - 2019-09-18 03:41:53 --> URI Class Initialized
INFO - 2019-09-18 03:41:53 --> Router Class Initialized
INFO - 2019-09-18 03:41:53 --> Output Class Initialized
INFO - 2019-09-18 03:41:53 --> Security Class Initialized
DEBUG - 2019-09-18 03:41:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-09-18 03:41:54 --> Input Class Initialized
INFO - 2019-09-18 03:41:54 --> Language Class Initialized
INFO - 2019-09-18 03:41:54 --> Language Class Initialized
INFO - 2019-09-18 03:41:54 --> Config Class Initialized
INFO - 2019-09-18 03:41:54 --> Loader Class Initialized
INFO - 2019-09-18 03:41:54 --> Helper loaded: url_helper
INFO - 2019-09-18 03:41:54 --> Helper loaded: file_helper
INFO - 2019-09-18 03:41:54 --> Helper loaded: form_helper
INFO - 2019-09-18 03:41:54 --> Helper loaded: my_helper
INFO - 2019-09-18 03:41:54 --> Database Driver Class Initialized
DEBUG - 2019-09-18 03:41:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-09-18 03:41:54 --> Session: Class initialized using 'files' driver.
INFO - 2019-09-18 03:41:54 --> Controller Class Initialized
INFO - 2019-09-18 03:41:54 --> Final output sent to browser
DEBUG - 2019-09-18 03:41:54 --> Total execution time: 0.3570
INFO - 2019-09-18 03:43:11 --> Config Class Initialized
INFO - 2019-09-18 03:43:11 --> Hooks Class Initialized
DEBUG - 2019-09-18 03:43:11 --> UTF-8 Support Enabled
INFO - 2019-09-18 03:43:11 --> Utf8 Class Initialized
INFO - 2019-09-18 03:43:11 --> URI Class Initialized
INFO - 2019-09-18 03:43:11 --> Router Class Initialized
INFO - 2019-09-18 03:43:11 --> Output Class Initialized
INFO - 2019-09-18 03:43:11 --> Security Class Initialized
DEBUG - 2019-09-18 03:43:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-09-18 03:43:11 --> Input Class Initialized
INFO - 2019-09-18 03:43:11 --> Language Class Initialized
INFO - 2019-09-18 03:43:11 --> Language Class Initialized
INFO - 2019-09-18 03:43:11 --> Config Class Initialized
INFO - 2019-09-18 03:43:11 --> Loader Class Initialized
INFO - 2019-09-18 03:43:11 --> Helper loaded: url_helper
INFO - 2019-09-18 03:43:11 --> Helper loaded: file_helper
INFO - 2019-09-18 03:43:11 --> Helper loaded: form_helper
INFO - 2019-09-18 03:43:11 --> Helper loaded: my_helper
INFO - 2019-09-18 03:43:11 --> Database Driver Class Initialized
DEBUG - 2019-09-18 03:43:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-09-18 03:43:11 --> Session: Class initialized using 'files' driver.
INFO - 2019-09-18 03:43:11 --> Controller Class Initialized
ERROR - 2019-09-18 03:43:11 --> Query error: Table 'db_nilai.tahun' doesn't exist - Invalid query: SELECT tahun FROM tahun WHERE aktif = 'Y'
INFO - 2019-09-18 03:43:11 --> Language file loaded: language/english/db_lang.php
INFO - 2019-09-18 03:43:27 --> Config Class Initialized
INFO - 2019-09-18 03:43:27 --> Hooks Class Initialized
DEBUG - 2019-09-18 03:43:27 --> UTF-8 Support Enabled
INFO - 2019-09-18 03:43:27 --> Utf8 Class Initialized
INFO - 2019-09-18 03:43:27 --> URI Class Initialized
INFO - 2019-09-18 03:43:28 --> Router Class Initialized
INFO - 2019-09-18 03:43:28 --> Output Class Initialized
INFO - 2019-09-18 03:43:28 --> Security Class Initialized
DEBUG - 2019-09-18 03:43:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-09-18 03:43:28 --> Input Class Initialized
INFO - 2019-09-18 03:43:28 --> Language Class Initialized
INFO - 2019-09-18 03:43:28 --> Language Class Initialized
INFO - 2019-09-18 03:43:28 --> Config Class Initialized
INFO - 2019-09-18 03:43:28 --> Loader Class Initialized
INFO - 2019-09-18 03:43:28 --> Helper loaded: url_helper
INFO - 2019-09-18 03:43:28 --> Helper loaded: file_helper
INFO - 2019-09-18 03:43:28 --> Helper loaded: form_helper
INFO - 2019-09-18 03:43:28 --> Helper loaded: my_helper
INFO - 2019-09-18 03:43:28 --> Database Driver Class Initialized
DEBUG - 2019-09-18 03:43:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-09-18 03:43:28 --> Session: Class initialized using 'files' driver.
INFO - 2019-09-18 03:43:28 --> Controller Class Initialized
DEBUG - 2019-09-18 03:43:28 --> File loaded: C:\xampp\htdocs\nilai\application\modules/login/views/login.php
DEBUG - 2019-09-18 03:43:28 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2019-09-18 03:43:28 --> Final output sent to browser
DEBUG - 2019-09-18 03:43:28 --> Total execution time: 0.2960
INFO - 2019-09-18 03:43:35 --> Config Class Initialized
INFO - 2019-09-18 03:43:35 --> Hooks Class Initialized
DEBUG - 2019-09-18 03:43:35 --> UTF-8 Support Enabled
INFO - 2019-09-18 03:43:35 --> Utf8 Class Initialized
INFO - 2019-09-18 03:43:35 --> URI Class Initialized
INFO - 2019-09-18 03:43:35 --> Router Class Initialized
INFO - 2019-09-18 03:43:35 --> Output Class Initialized
INFO - 2019-09-18 03:43:35 --> Security Class Initialized
DEBUG - 2019-09-18 03:43:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-09-18 03:43:35 --> Input Class Initialized
INFO - 2019-09-18 03:43:35 --> Language Class Initialized
INFO - 2019-09-18 03:43:35 --> Language Class Initialized
INFO - 2019-09-18 03:43:35 --> Config Class Initialized
INFO - 2019-09-18 03:43:35 --> Loader Class Initialized
INFO - 2019-09-18 03:43:35 --> Helper loaded: url_helper
INFO - 2019-09-18 03:43:35 --> Helper loaded: file_helper
INFO - 2019-09-18 03:43:35 --> Helper loaded: form_helper
INFO - 2019-09-18 03:43:35 --> Helper loaded: my_helper
INFO - 2019-09-18 03:43:35 --> Database Driver Class Initialized
DEBUG - 2019-09-18 03:43:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-09-18 03:43:35 --> Session: Class initialized using 'files' driver.
INFO - 2019-09-18 03:43:35 --> Controller Class Initialized
INFO - 2019-09-18 03:43:35 --> Helper loaded: cookie_helper
INFO - 2019-09-18 03:43:35 --> Final output sent to browser
DEBUG - 2019-09-18 03:43:35 --> Total execution time: 0.4350
INFO - 2019-09-18 03:43:38 --> Config Class Initialized
INFO - 2019-09-18 03:43:38 --> Hooks Class Initialized
DEBUG - 2019-09-18 03:43:38 --> UTF-8 Support Enabled
INFO - 2019-09-18 03:43:38 --> Utf8 Class Initialized
INFO - 2019-09-18 03:43:38 --> URI Class Initialized
INFO - 2019-09-18 03:43:38 --> Router Class Initialized
INFO - 2019-09-18 03:43:38 --> Output Class Initialized
INFO - 2019-09-18 03:43:38 --> Security Class Initialized
DEBUG - 2019-09-18 03:43:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-09-18 03:43:38 --> Input Class Initialized
INFO - 2019-09-18 03:43:38 --> Language Class Initialized
INFO - 2019-09-18 03:43:38 --> Language Class Initialized
INFO - 2019-09-18 03:43:38 --> Config Class Initialized
INFO - 2019-09-18 03:43:38 --> Loader Class Initialized
INFO - 2019-09-18 03:43:38 --> Helper loaded: url_helper
INFO - 2019-09-18 03:43:39 --> Helper loaded: file_helper
INFO - 2019-09-18 03:43:39 --> Helper loaded: form_helper
INFO - 2019-09-18 03:43:39 --> Helper loaded: my_helper
INFO - 2019-09-18 03:43:39 --> Database Driver Class Initialized
DEBUG - 2019-09-18 03:43:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-09-18 03:43:39 --> Session: Class initialized using 'files' driver.
INFO - 2019-09-18 03:43:39 --> Controller Class Initialized
DEBUG - 2019-09-18 03:43:39 --> File loaded: C:\xampp\htdocs\nilai\application\modules/home/views/v_home.php
DEBUG - 2019-09-18 03:43:39 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2019-09-18 03:43:39 --> Final output sent to browser
DEBUG - 2019-09-18 03:43:39 --> Total execution time: 0.4920
INFO - 2019-09-18 03:43:41 --> Config Class Initialized
INFO - 2019-09-18 03:43:41 --> Hooks Class Initialized
DEBUG - 2019-09-18 03:43:41 --> UTF-8 Support Enabled
INFO - 2019-09-18 03:43:41 --> Utf8 Class Initialized
INFO - 2019-09-18 03:43:41 --> URI Class Initialized
DEBUG - 2019-09-18 03:43:41 --> No URI present. Default controller set.
INFO - 2019-09-18 03:43:41 --> Router Class Initialized
INFO - 2019-09-18 03:43:41 --> Output Class Initialized
INFO - 2019-09-18 03:43:41 --> Security Class Initialized
DEBUG - 2019-09-18 03:43:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-09-18 03:43:42 --> Input Class Initialized
INFO - 2019-09-18 03:43:42 --> Language Class Initialized
INFO - 2019-09-18 03:43:42 --> Language Class Initialized
INFO - 2019-09-18 03:43:42 --> Config Class Initialized
INFO - 2019-09-18 03:43:42 --> Loader Class Initialized
INFO - 2019-09-18 03:43:42 --> Helper loaded: url_helper
INFO - 2019-09-18 03:43:42 --> Helper loaded: file_helper
INFO - 2019-09-18 03:43:42 --> Helper loaded: form_helper
INFO - 2019-09-18 03:43:42 --> Helper loaded: my_helper
INFO - 2019-09-18 03:43:42 --> Database Driver Class Initialized
DEBUG - 2019-09-18 03:43:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-09-18 03:43:42 --> Session: Class initialized using 'files' driver.
INFO - 2019-09-18 03:43:42 --> Controller Class Initialized
DEBUG - 2019-09-18 03:43:42 --> File loaded: C:\xampp\htdocs\nilai\application\modules/home/views/v_home.php
DEBUG - 2019-09-18 03:43:42 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2019-09-18 03:43:42 --> Final output sent to browser
DEBUG - 2019-09-18 03:43:42 --> Total execution time: 0.3610
INFO - 2019-09-18 03:43:43 --> Config Class Initialized
INFO - 2019-09-18 03:43:43 --> Hooks Class Initialized
DEBUG - 2019-09-18 03:43:43 --> UTF-8 Support Enabled
INFO - 2019-09-18 03:43:43 --> Utf8 Class Initialized
INFO - 2019-09-18 03:43:43 --> URI Class Initialized
INFO - 2019-09-18 03:43:43 --> Router Class Initialized
INFO - 2019-09-18 03:43:43 --> Output Class Initialized
INFO - 2019-09-18 03:43:43 --> Security Class Initialized
DEBUG - 2019-09-18 03:43:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-09-18 03:43:43 --> Input Class Initialized
INFO - 2019-09-18 03:43:43 --> Language Class Initialized
INFO - 2019-09-18 03:43:43 --> Language Class Initialized
INFO - 2019-09-18 03:43:43 --> Config Class Initialized
INFO - 2019-09-18 03:43:43 --> Loader Class Initialized
INFO - 2019-09-18 03:43:43 --> Helper loaded: url_helper
INFO - 2019-09-18 03:43:43 --> Helper loaded: file_helper
INFO - 2019-09-18 03:43:43 --> Helper loaded: form_helper
INFO - 2019-09-18 03:43:43 --> Helper loaded: my_helper
INFO - 2019-09-18 03:43:43 --> Database Driver Class Initialized
DEBUG - 2019-09-18 03:43:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-09-18 03:43:43 --> Session: Class initialized using 'files' driver.
INFO - 2019-09-18 03:43:43 --> Controller Class Initialized
DEBUG - 2019-09-18 03:43:43 --> File loaded: C:\xampp\htdocs\nilai\application\modules/data_guru/views/list.php
DEBUG - 2019-09-18 03:43:43 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2019-09-18 03:43:43 --> Final output sent to browser
DEBUG - 2019-09-18 03:43:43 --> Total execution time: 0.2950
INFO - 2019-09-18 03:43:44 --> Config Class Initialized
INFO - 2019-09-18 03:43:44 --> Hooks Class Initialized
DEBUG - 2019-09-18 03:43:44 --> UTF-8 Support Enabled
INFO - 2019-09-18 03:43:44 --> Utf8 Class Initialized
INFO - 2019-09-18 03:43:44 --> URI Class Initialized
INFO - 2019-09-18 03:43:44 --> Router Class Initialized
INFO - 2019-09-18 03:43:44 --> Output Class Initialized
INFO - 2019-09-18 03:43:44 --> Security Class Initialized
DEBUG - 2019-09-18 03:43:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-09-18 03:43:44 --> Input Class Initialized
INFO - 2019-09-18 03:43:44 --> Language Class Initialized
INFO - 2019-09-18 03:43:44 --> Language Class Initialized
INFO - 2019-09-18 03:43:44 --> Config Class Initialized
INFO - 2019-09-18 03:43:44 --> Loader Class Initialized
INFO - 2019-09-18 03:43:44 --> Helper loaded: url_helper
INFO - 2019-09-18 03:43:44 --> Helper loaded: file_helper
INFO - 2019-09-18 03:43:44 --> Helper loaded: form_helper
INFO - 2019-09-18 03:43:44 --> Helper loaded: my_helper
INFO - 2019-09-18 03:43:44 --> Database Driver Class Initialized
DEBUG - 2019-09-18 03:43:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-09-18 03:43:44 --> Session: Class initialized using 'files' driver.
INFO - 2019-09-18 03:43:44 --> Controller Class Initialized
INFO - 2019-09-18 03:43:47 --> Config Class Initialized
INFO - 2019-09-18 03:43:47 --> Hooks Class Initialized
DEBUG - 2019-09-18 03:43:47 --> UTF-8 Support Enabled
INFO - 2019-09-18 03:43:47 --> Utf8 Class Initialized
INFO - 2019-09-18 03:43:47 --> URI Class Initialized
INFO - 2019-09-18 03:43:47 --> Router Class Initialized
INFO - 2019-09-18 03:43:47 --> Output Class Initialized
INFO - 2019-09-18 03:43:47 --> Security Class Initialized
DEBUG - 2019-09-18 03:43:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-09-18 03:43:47 --> Input Class Initialized
INFO - 2019-09-18 03:43:47 --> Language Class Initialized
INFO - 2019-09-18 03:43:47 --> Language Class Initialized
INFO - 2019-09-18 03:43:47 --> Config Class Initialized
INFO - 2019-09-18 03:43:47 --> Loader Class Initialized
INFO - 2019-09-18 03:43:47 --> Helper loaded: url_helper
INFO - 2019-09-18 03:43:47 --> Helper loaded: file_helper
INFO - 2019-09-18 03:43:47 --> Helper loaded: form_helper
INFO - 2019-09-18 03:43:47 --> Helper loaded: my_helper
INFO - 2019-09-18 03:43:47 --> Database Driver Class Initialized
DEBUG - 2019-09-18 03:43:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-09-18 03:43:47 --> Session: Class initialized using 'files' driver.
INFO - 2019-09-18 03:43:47 --> Controller Class Initialized
DEBUG - 2019-09-18 03:43:47 --> File loaded: C:\xampp\htdocs\nilai\application\modules/data_kelas/views/list.php
DEBUG - 2019-09-18 03:43:47 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2019-09-18 03:43:47 --> Final output sent to browser
DEBUG - 2019-09-18 03:43:47 --> Total execution time: 0.3050
INFO - 2019-09-18 03:43:47 --> Config Class Initialized
INFO - 2019-09-18 03:43:47 --> Hooks Class Initialized
DEBUG - 2019-09-18 03:43:47 --> UTF-8 Support Enabled
INFO - 2019-09-18 03:43:47 --> Utf8 Class Initialized
INFO - 2019-09-18 03:43:47 --> URI Class Initialized
INFO - 2019-09-18 03:43:47 --> Router Class Initialized
INFO - 2019-09-18 03:43:47 --> Output Class Initialized
INFO - 2019-09-18 03:43:47 --> Security Class Initialized
DEBUG - 2019-09-18 03:43:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-09-18 03:43:47 --> Input Class Initialized
INFO - 2019-09-18 03:43:47 --> Language Class Initialized
INFO - 2019-09-18 03:43:47 --> Language Class Initialized
INFO - 2019-09-18 03:43:47 --> Config Class Initialized
INFO - 2019-09-18 03:43:47 --> Loader Class Initialized
INFO - 2019-09-18 03:43:47 --> Helper loaded: url_helper
INFO - 2019-09-18 03:43:47 --> Helper loaded: file_helper
INFO - 2019-09-18 03:43:47 --> Helper loaded: form_helper
INFO - 2019-09-18 03:43:47 --> Helper loaded: my_helper
INFO - 2019-09-18 03:43:47 --> Database Driver Class Initialized
DEBUG - 2019-09-18 03:43:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-09-18 03:43:47 --> Session: Class initialized using 'files' driver.
INFO - 2019-09-18 03:43:47 --> Controller Class Initialized
INFO - 2019-09-18 03:43:49 --> Config Class Initialized
INFO - 2019-09-18 03:43:49 --> Hooks Class Initialized
DEBUG - 2019-09-18 03:43:49 --> UTF-8 Support Enabled
INFO - 2019-09-18 03:43:49 --> Utf8 Class Initialized
INFO - 2019-09-18 03:43:49 --> URI Class Initialized
INFO - 2019-09-18 03:43:49 --> Router Class Initialized
INFO - 2019-09-18 03:43:49 --> Output Class Initialized
INFO - 2019-09-18 03:43:49 --> Security Class Initialized
DEBUG - 2019-09-18 03:43:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-09-18 03:43:49 --> Input Class Initialized
INFO - 2019-09-18 03:43:49 --> Language Class Initialized
INFO - 2019-09-18 03:43:49 --> Language Class Initialized
INFO - 2019-09-18 03:43:49 --> Config Class Initialized
INFO - 2019-09-18 03:43:49 --> Loader Class Initialized
INFO - 2019-09-18 03:43:49 --> Helper loaded: url_helper
INFO - 2019-09-18 03:43:49 --> Helper loaded: file_helper
INFO - 2019-09-18 03:43:49 --> Helper loaded: form_helper
INFO - 2019-09-18 03:43:49 --> Helper loaded: my_helper
INFO - 2019-09-18 03:43:49 --> Database Driver Class Initialized
DEBUG - 2019-09-18 03:43:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-09-18 03:43:49 --> Session: Class initialized using 'files' driver.
INFO - 2019-09-18 03:43:49 --> Controller Class Initialized
INFO - 2019-09-18 03:43:49 --> Final output sent to browser
DEBUG - 2019-09-18 03:43:49 --> Total execution time: 0.2430
INFO - 2019-09-18 03:43:51 --> Config Class Initialized
INFO - 2019-09-18 03:43:51 --> Hooks Class Initialized
DEBUG - 2019-09-18 03:43:51 --> UTF-8 Support Enabled
INFO - 2019-09-18 03:43:51 --> Utf8 Class Initialized
INFO - 2019-09-18 03:43:51 --> URI Class Initialized
INFO - 2019-09-18 03:43:51 --> Router Class Initialized
INFO - 2019-09-18 03:43:51 --> Output Class Initialized
INFO - 2019-09-18 03:43:51 --> Security Class Initialized
DEBUG - 2019-09-18 03:43:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-09-18 03:43:51 --> Input Class Initialized
INFO - 2019-09-18 03:43:51 --> Language Class Initialized
INFO - 2019-09-18 03:43:51 --> Language Class Initialized
INFO - 2019-09-18 03:43:51 --> Config Class Initialized
INFO - 2019-09-18 03:43:51 --> Loader Class Initialized
INFO - 2019-09-18 03:43:51 --> Helper loaded: url_helper
INFO - 2019-09-18 03:43:51 --> Helper loaded: file_helper
INFO - 2019-09-18 03:43:51 --> Helper loaded: form_helper
INFO - 2019-09-18 03:43:51 --> Helper loaded: my_helper
INFO - 2019-09-18 03:43:51 --> Database Driver Class Initialized
DEBUG - 2019-09-18 03:43:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-09-18 03:43:51 --> Session: Class initialized using 'files' driver.
INFO - 2019-09-18 03:43:51 --> Controller Class Initialized
INFO - 2019-09-18 03:43:51 --> Final output sent to browser
DEBUG - 2019-09-18 03:43:51 --> Total execution time: 0.2810
INFO - 2019-09-18 03:43:51 --> Config Class Initialized
INFO - 2019-09-18 03:43:51 --> Hooks Class Initialized
DEBUG - 2019-09-18 03:43:51 --> UTF-8 Support Enabled
INFO - 2019-09-18 03:43:51 --> Utf8 Class Initialized
INFO - 2019-09-18 03:43:51 --> URI Class Initialized
INFO - 2019-09-18 03:43:51 --> Router Class Initialized
INFO - 2019-09-18 03:43:51 --> Output Class Initialized
INFO - 2019-09-18 03:43:51 --> Security Class Initialized
DEBUG - 2019-09-18 03:43:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-09-18 03:43:51 --> Input Class Initialized
INFO - 2019-09-18 03:43:51 --> Language Class Initialized
INFO - 2019-09-18 03:43:51 --> Language Class Initialized
INFO - 2019-09-18 03:43:51 --> Config Class Initialized
INFO - 2019-09-18 03:43:51 --> Loader Class Initialized
INFO - 2019-09-18 03:43:51 --> Helper loaded: url_helper
INFO - 2019-09-18 03:43:51 --> Helper loaded: file_helper
INFO - 2019-09-18 03:43:51 --> Helper loaded: form_helper
INFO - 2019-09-18 03:43:51 --> Helper loaded: my_helper
INFO - 2019-09-18 03:43:51 --> Database Driver Class Initialized
DEBUG - 2019-09-18 03:43:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-09-18 03:43:51 --> Session: Class initialized using 'files' driver.
INFO - 2019-09-18 03:43:51 --> Controller Class Initialized
INFO - 2019-09-18 03:43:56 --> Config Class Initialized
INFO - 2019-09-18 03:43:56 --> Hooks Class Initialized
DEBUG - 2019-09-18 03:43:56 --> UTF-8 Support Enabled
INFO - 2019-09-18 03:43:56 --> Utf8 Class Initialized
INFO - 2019-09-18 03:43:56 --> URI Class Initialized
INFO - 2019-09-18 03:43:56 --> Router Class Initialized
INFO - 2019-09-18 03:43:56 --> Output Class Initialized
INFO - 2019-09-18 03:43:56 --> Security Class Initialized
DEBUG - 2019-09-18 03:43:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-09-18 03:43:56 --> Input Class Initialized
INFO - 2019-09-18 03:43:56 --> Language Class Initialized
INFO - 2019-09-18 03:43:56 --> Language Class Initialized
INFO - 2019-09-18 03:43:56 --> Config Class Initialized
INFO - 2019-09-18 03:43:56 --> Loader Class Initialized
INFO - 2019-09-18 03:43:56 --> Helper loaded: url_helper
INFO - 2019-09-18 03:43:56 --> Helper loaded: file_helper
INFO - 2019-09-18 03:43:56 --> Helper loaded: form_helper
INFO - 2019-09-18 03:43:56 --> Helper loaded: my_helper
INFO - 2019-09-18 03:43:56 --> Database Driver Class Initialized
DEBUG - 2019-09-18 03:43:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-09-18 03:43:56 --> Session: Class initialized using 'files' driver.
INFO - 2019-09-18 03:43:56 --> Controller Class Initialized
DEBUG - 2019-09-18 03:43:56 --> File loaded: C:\xampp\htdocs\nilai\application\modules/set_mapel/views/list.php
DEBUG - 2019-09-18 03:43:56 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2019-09-18 03:43:56 --> Final output sent to browser
DEBUG - 2019-09-18 03:43:56 --> Total execution time: 0.3020
INFO - 2019-09-18 03:43:56 --> Config Class Initialized
INFO - 2019-09-18 03:43:56 --> Hooks Class Initialized
DEBUG - 2019-09-18 03:43:56 --> UTF-8 Support Enabled
INFO - 2019-09-18 03:43:56 --> Utf8 Class Initialized
INFO - 2019-09-18 03:43:56 --> URI Class Initialized
INFO - 2019-09-18 03:43:56 --> Router Class Initialized
INFO - 2019-09-18 03:43:56 --> Output Class Initialized
INFO - 2019-09-18 03:43:56 --> Security Class Initialized
DEBUG - 2019-09-18 03:43:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-09-18 03:43:56 --> Input Class Initialized
INFO - 2019-09-18 03:43:56 --> Language Class Initialized
INFO - 2019-09-18 03:43:56 --> Language Class Initialized
INFO - 2019-09-18 03:43:56 --> Config Class Initialized
INFO - 2019-09-18 03:43:56 --> Loader Class Initialized
INFO - 2019-09-18 03:43:56 --> Helper loaded: url_helper
INFO - 2019-09-18 03:43:56 --> Helper loaded: file_helper
INFO - 2019-09-18 03:43:56 --> Helper loaded: form_helper
INFO - 2019-09-18 03:43:56 --> Helper loaded: my_helper
INFO - 2019-09-18 03:43:56 --> Database Driver Class Initialized
DEBUG - 2019-09-18 03:43:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-09-18 03:43:56 --> Session: Class initialized using 'files' driver.
INFO - 2019-09-18 03:43:56 --> Controller Class Initialized
INFO - 2019-09-18 03:43:59 --> Config Class Initialized
INFO - 2019-09-18 03:43:59 --> Hooks Class Initialized
DEBUG - 2019-09-18 03:43:59 --> UTF-8 Support Enabled
INFO - 2019-09-18 03:43:59 --> Utf8 Class Initialized
INFO - 2019-09-18 03:43:59 --> URI Class Initialized
INFO - 2019-09-18 03:43:59 --> Router Class Initialized
INFO - 2019-09-18 03:43:59 --> Output Class Initialized
INFO - 2019-09-18 03:43:59 --> Security Class Initialized
DEBUG - 2019-09-18 03:43:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-09-18 03:43:59 --> Input Class Initialized
INFO - 2019-09-18 03:43:59 --> Language Class Initialized
INFO - 2019-09-18 03:43:59 --> Language Class Initialized
INFO - 2019-09-18 03:43:59 --> Config Class Initialized
INFO - 2019-09-18 03:43:59 --> Loader Class Initialized
INFO - 2019-09-18 03:43:59 --> Helper loaded: url_helper
INFO - 2019-09-18 03:43:59 --> Helper loaded: file_helper
INFO - 2019-09-18 03:43:59 --> Helper loaded: form_helper
INFO - 2019-09-18 03:43:59 --> Helper loaded: my_helper
INFO - 2019-09-18 03:43:59 --> Database Driver Class Initialized
DEBUG - 2019-09-18 03:43:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-09-18 03:43:59 --> Session: Class initialized using 'files' driver.
INFO - 2019-09-18 03:43:59 --> Controller Class Initialized
DEBUG - 2019-09-18 03:43:59 --> File loaded: C:\xampp\htdocs\nilai\application\modules/data_mapel/views/list.php
DEBUG - 2019-09-18 03:43:59 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2019-09-18 03:43:59 --> Final output sent to browser
DEBUG - 2019-09-18 03:43:59 --> Total execution time: 0.3140
INFO - 2019-09-18 03:44:00 --> Config Class Initialized
INFO - 2019-09-18 03:44:00 --> Hooks Class Initialized
DEBUG - 2019-09-18 03:44:00 --> UTF-8 Support Enabled
INFO - 2019-09-18 03:44:00 --> Utf8 Class Initialized
INFO - 2019-09-18 03:44:00 --> URI Class Initialized
INFO - 2019-09-18 03:44:00 --> Router Class Initialized
INFO - 2019-09-18 03:44:00 --> Output Class Initialized
INFO - 2019-09-18 03:44:00 --> Security Class Initialized
DEBUG - 2019-09-18 03:44:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-09-18 03:44:00 --> Input Class Initialized
INFO - 2019-09-18 03:44:00 --> Language Class Initialized
INFO - 2019-09-18 03:44:00 --> Language Class Initialized
INFO - 2019-09-18 03:44:00 --> Config Class Initialized
INFO - 2019-09-18 03:44:00 --> Loader Class Initialized
INFO - 2019-09-18 03:44:00 --> Helper loaded: url_helper
INFO - 2019-09-18 03:44:00 --> Helper loaded: file_helper
INFO - 2019-09-18 03:44:00 --> Helper loaded: form_helper
INFO - 2019-09-18 03:44:00 --> Helper loaded: my_helper
INFO - 2019-09-18 03:44:00 --> Database Driver Class Initialized
DEBUG - 2019-09-18 03:44:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-09-18 03:44:00 --> Session: Class initialized using 'files' driver.
INFO - 2019-09-18 03:44:00 --> Controller Class Initialized
INFO - 2019-09-18 03:44:03 --> Config Class Initialized
INFO - 2019-09-18 03:44:03 --> Hooks Class Initialized
DEBUG - 2019-09-18 03:44:03 --> UTF-8 Support Enabled
INFO - 2019-09-18 03:44:03 --> Utf8 Class Initialized
INFO - 2019-09-18 03:44:03 --> URI Class Initialized
INFO - 2019-09-18 03:44:03 --> Router Class Initialized
INFO - 2019-09-18 03:44:03 --> Output Class Initialized
INFO - 2019-09-18 03:44:03 --> Security Class Initialized
DEBUG - 2019-09-18 03:44:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-09-18 03:44:03 --> Input Class Initialized
INFO - 2019-09-18 03:44:03 --> Language Class Initialized
INFO - 2019-09-18 03:44:03 --> Language Class Initialized
INFO - 2019-09-18 03:44:03 --> Config Class Initialized
INFO - 2019-09-18 03:44:03 --> Loader Class Initialized
INFO - 2019-09-18 03:44:03 --> Helper loaded: url_helper
INFO - 2019-09-18 03:44:03 --> Helper loaded: file_helper
INFO - 2019-09-18 03:44:03 --> Helper loaded: form_helper
INFO - 2019-09-18 03:44:03 --> Helper loaded: my_helper
INFO - 2019-09-18 03:44:03 --> Database Driver Class Initialized
DEBUG - 2019-09-18 03:44:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-09-18 03:44:03 --> Session: Class initialized using 'files' driver.
INFO - 2019-09-18 03:44:03 --> Controller Class Initialized
DEBUG - 2019-09-18 03:44:03 --> File loaded: C:\xampp\htdocs\nilai\application\modules/data_siswa/views/list.php
DEBUG - 2019-09-18 03:44:03 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2019-09-18 03:44:03 --> Final output sent to browser
DEBUG - 2019-09-18 03:44:03 --> Total execution time: 0.3030
INFO - 2019-09-18 03:44:03 --> Config Class Initialized
INFO - 2019-09-18 03:44:03 --> Hooks Class Initialized
DEBUG - 2019-09-18 03:44:03 --> UTF-8 Support Enabled
INFO - 2019-09-18 03:44:03 --> Utf8 Class Initialized
INFO - 2019-09-18 03:44:03 --> URI Class Initialized
INFO - 2019-09-18 03:44:03 --> Router Class Initialized
INFO - 2019-09-18 03:44:03 --> Output Class Initialized
INFO - 2019-09-18 03:44:03 --> Security Class Initialized
DEBUG - 2019-09-18 03:44:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-09-18 03:44:03 --> Input Class Initialized
INFO - 2019-09-18 03:44:03 --> Language Class Initialized
INFO - 2019-09-18 03:44:03 --> Language Class Initialized
INFO - 2019-09-18 03:44:03 --> Config Class Initialized
INFO - 2019-09-18 03:44:03 --> Loader Class Initialized
INFO - 2019-09-18 03:44:03 --> Helper loaded: url_helper
INFO - 2019-09-18 03:44:03 --> Helper loaded: file_helper
INFO - 2019-09-18 03:44:03 --> Helper loaded: form_helper
INFO - 2019-09-18 03:44:03 --> Helper loaded: my_helper
INFO - 2019-09-18 03:44:03 --> Database Driver Class Initialized
DEBUG - 2019-09-18 03:44:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-09-18 03:44:03 --> Session: Class initialized using 'files' driver.
INFO - 2019-09-18 03:44:03 --> Controller Class Initialized
INFO - 2019-09-18 03:44:05 --> Config Class Initialized
INFO - 2019-09-18 03:44:05 --> Hooks Class Initialized
DEBUG - 2019-09-18 03:44:05 --> UTF-8 Support Enabled
INFO - 2019-09-18 03:44:05 --> Utf8 Class Initialized
INFO - 2019-09-18 03:44:05 --> URI Class Initialized
INFO - 2019-09-18 03:44:05 --> Router Class Initialized
INFO - 2019-09-18 03:44:05 --> Output Class Initialized
INFO - 2019-09-18 03:44:05 --> Security Class Initialized
DEBUG - 2019-09-18 03:44:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-09-18 03:44:05 --> Input Class Initialized
INFO - 2019-09-18 03:44:05 --> Language Class Initialized
INFO - 2019-09-18 03:44:05 --> Language Class Initialized
INFO - 2019-09-18 03:44:05 --> Config Class Initialized
INFO - 2019-09-18 03:44:05 --> Loader Class Initialized
INFO - 2019-09-18 03:44:05 --> Helper loaded: url_helper
INFO - 2019-09-18 03:44:05 --> Helper loaded: file_helper
INFO - 2019-09-18 03:44:05 --> Helper loaded: form_helper
INFO - 2019-09-18 03:44:05 --> Helper loaded: my_helper
INFO - 2019-09-18 03:44:05 --> Database Driver Class Initialized
DEBUG - 2019-09-18 03:44:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-09-18 03:44:05 --> Session: Class initialized using 'files' driver.
INFO - 2019-09-18 03:44:05 --> Controller Class Initialized
DEBUG - 2019-09-18 03:44:05 --> File loaded: C:\xampp\htdocs\nilai\application\modules/data_guru/views/list.php
DEBUG - 2019-09-18 03:44:05 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2019-09-18 03:44:05 --> Final output sent to browser
DEBUG - 2019-09-18 03:44:05 --> Total execution time: 0.2770
INFO - 2019-09-18 03:44:05 --> Config Class Initialized
INFO - 2019-09-18 03:44:05 --> Hooks Class Initialized
DEBUG - 2019-09-18 03:44:05 --> UTF-8 Support Enabled
INFO - 2019-09-18 03:44:05 --> Utf8 Class Initialized
INFO - 2019-09-18 03:44:05 --> URI Class Initialized
INFO - 2019-09-18 03:44:05 --> Router Class Initialized
INFO - 2019-09-18 03:44:05 --> Output Class Initialized
INFO - 2019-09-18 03:44:05 --> Security Class Initialized
DEBUG - 2019-09-18 03:44:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-09-18 03:44:05 --> Input Class Initialized
INFO - 2019-09-18 03:44:05 --> Language Class Initialized
INFO - 2019-09-18 03:44:05 --> Language Class Initialized
INFO - 2019-09-18 03:44:05 --> Config Class Initialized
INFO - 2019-09-18 03:44:05 --> Loader Class Initialized
INFO - 2019-09-18 03:44:05 --> Helper loaded: url_helper
INFO - 2019-09-18 03:44:05 --> Helper loaded: file_helper
INFO - 2019-09-18 03:44:05 --> Helper loaded: form_helper
INFO - 2019-09-18 03:44:05 --> Helper loaded: my_helper
INFO - 2019-09-18 03:44:05 --> Database Driver Class Initialized
DEBUG - 2019-09-18 03:44:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-09-18 03:44:05 --> Session: Class initialized using 'files' driver.
INFO - 2019-09-18 03:44:05 --> Controller Class Initialized
INFO - 2019-09-18 03:44:23 --> Config Class Initialized
INFO - 2019-09-18 03:44:23 --> Hooks Class Initialized
DEBUG - 2019-09-18 03:44:23 --> UTF-8 Support Enabled
INFO - 2019-09-18 03:44:23 --> Utf8 Class Initialized
INFO - 2019-09-18 03:44:23 --> URI Class Initialized
INFO - 2019-09-18 03:44:23 --> Router Class Initialized
INFO - 2019-09-18 03:44:23 --> Output Class Initialized
INFO - 2019-09-18 03:44:23 --> Security Class Initialized
DEBUG - 2019-09-18 03:44:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-09-18 03:44:23 --> Input Class Initialized
INFO - 2019-09-18 03:44:23 --> Language Class Initialized
INFO - 2019-09-18 03:44:23 --> Language Class Initialized
INFO - 2019-09-18 03:44:23 --> Config Class Initialized
INFO - 2019-09-18 03:44:23 --> Loader Class Initialized
INFO - 2019-09-18 03:44:23 --> Helper loaded: url_helper
INFO - 2019-09-18 03:44:23 --> Helper loaded: file_helper
INFO - 2019-09-18 03:44:23 --> Helper loaded: form_helper
INFO - 2019-09-18 03:44:23 --> Helper loaded: my_helper
INFO - 2019-09-18 03:44:23 --> Database Driver Class Initialized
DEBUG - 2019-09-18 03:44:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-09-18 03:44:23 --> Session: Class initialized using 'files' driver.
INFO - 2019-09-18 03:44:23 --> Controller Class Initialized
INFO - 2019-09-18 03:44:23 --> Final output sent to browser
DEBUG - 2019-09-18 03:44:23 --> Total execution time: 0.2790
INFO - 2019-09-18 03:44:29 --> Config Class Initialized
INFO - 2019-09-18 03:44:29 --> Hooks Class Initialized
DEBUG - 2019-09-18 03:44:29 --> UTF-8 Support Enabled
INFO - 2019-09-18 03:44:29 --> Utf8 Class Initialized
INFO - 2019-09-18 03:44:29 --> URI Class Initialized
INFO - 2019-09-18 03:44:29 --> Router Class Initialized
INFO - 2019-09-18 03:44:29 --> Output Class Initialized
INFO - 2019-09-18 03:44:29 --> Security Class Initialized
DEBUG - 2019-09-18 03:44:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-09-18 03:44:29 --> Input Class Initialized
INFO - 2019-09-18 03:44:29 --> Language Class Initialized
INFO - 2019-09-18 03:44:29 --> Language Class Initialized
INFO - 2019-09-18 03:44:29 --> Config Class Initialized
INFO - 2019-09-18 03:44:30 --> Loader Class Initialized
INFO - 2019-09-18 03:44:30 --> Helper loaded: url_helper
INFO - 2019-09-18 03:44:30 --> Helper loaded: file_helper
INFO - 2019-09-18 03:44:30 --> Helper loaded: form_helper
INFO - 2019-09-18 03:44:30 --> Helper loaded: my_helper
INFO - 2019-09-18 03:44:30 --> Database Driver Class Initialized
DEBUG - 2019-09-18 03:44:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-09-18 03:44:30 --> Session: Class initialized using 'files' driver.
INFO - 2019-09-18 03:44:30 --> Controller Class Initialized
INFO - 2019-09-18 03:44:30 --> Final output sent to browser
DEBUG - 2019-09-18 03:44:30 --> Total execution time: 0.5900
INFO - 2019-09-18 03:44:30 --> Config Class Initialized
INFO - 2019-09-18 03:44:30 --> Hooks Class Initialized
DEBUG - 2019-09-18 03:44:30 --> UTF-8 Support Enabled
INFO - 2019-09-18 03:44:30 --> Utf8 Class Initialized
INFO - 2019-09-18 03:44:30 --> URI Class Initialized
INFO - 2019-09-18 03:44:30 --> Router Class Initialized
INFO - 2019-09-18 03:44:30 --> Output Class Initialized
INFO - 2019-09-18 03:44:30 --> Security Class Initialized
DEBUG - 2019-09-18 03:44:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-09-18 03:44:30 --> Input Class Initialized
INFO - 2019-09-18 03:44:30 --> Language Class Initialized
INFO - 2019-09-18 03:44:30 --> Language Class Initialized
INFO - 2019-09-18 03:44:30 --> Config Class Initialized
INFO - 2019-09-18 03:44:30 --> Loader Class Initialized
INFO - 2019-09-18 03:44:30 --> Helper loaded: url_helper
INFO - 2019-09-18 03:44:30 --> Helper loaded: file_helper
INFO - 2019-09-18 03:44:30 --> Helper loaded: form_helper
INFO - 2019-09-18 03:44:30 --> Helper loaded: my_helper
INFO - 2019-09-18 03:44:30 --> Database Driver Class Initialized
DEBUG - 2019-09-18 03:44:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-09-18 03:44:30 --> Session: Class initialized using 'files' driver.
INFO - 2019-09-18 03:44:30 --> Controller Class Initialized
INFO - 2019-09-18 03:44:33 --> Config Class Initialized
INFO - 2019-09-18 03:44:33 --> Hooks Class Initialized
DEBUG - 2019-09-18 03:44:33 --> UTF-8 Support Enabled
INFO - 2019-09-18 03:44:33 --> Utf8 Class Initialized
INFO - 2019-09-18 03:44:33 --> URI Class Initialized
INFO - 2019-09-18 03:44:33 --> Router Class Initialized
INFO - 2019-09-18 03:44:33 --> Output Class Initialized
INFO - 2019-09-18 03:44:33 --> Security Class Initialized
DEBUG - 2019-09-18 03:44:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-09-18 03:44:33 --> Input Class Initialized
INFO - 2019-09-18 03:44:33 --> Language Class Initialized
INFO - 2019-09-18 03:44:33 --> Language Class Initialized
INFO - 2019-09-18 03:44:33 --> Config Class Initialized
INFO - 2019-09-18 03:44:33 --> Loader Class Initialized
INFO - 2019-09-18 03:44:33 --> Helper loaded: url_helper
INFO - 2019-09-18 03:44:33 --> Helper loaded: file_helper
INFO - 2019-09-18 03:44:33 --> Helper loaded: form_helper
INFO - 2019-09-18 03:44:33 --> Helper loaded: my_helper
INFO - 2019-09-18 03:44:33 --> Database Driver Class Initialized
DEBUG - 2019-09-18 03:44:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-09-18 03:44:33 --> Session: Class initialized using 'files' driver.
INFO - 2019-09-18 03:44:33 --> Controller Class Initialized
INFO - 2019-09-18 03:44:33 --> Final output sent to browser
DEBUG - 2019-09-18 03:44:33 --> Total execution time: 0.3340
INFO - 2019-09-18 03:44:33 --> Config Class Initialized
INFO - 2019-09-18 03:44:33 --> Hooks Class Initialized
DEBUG - 2019-09-18 03:44:33 --> UTF-8 Support Enabled
INFO - 2019-09-18 03:44:33 --> Utf8 Class Initialized
INFO - 2019-09-18 03:44:33 --> URI Class Initialized
INFO - 2019-09-18 03:44:33 --> Router Class Initialized
INFO - 2019-09-18 03:44:33 --> Output Class Initialized
INFO - 2019-09-18 03:44:33 --> Security Class Initialized
DEBUG - 2019-09-18 03:44:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-09-18 03:44:33 --> Input Class Initialized
INFO - 2019-09-18 03:44:33 --> Language Class Initialized
INFO - 2019-09-18 03:44:33 --> Language Class Initialized
INFO - 2019-09-18 03:44:33 --> Config Class Initialized
INFO - 2019-09-18 03:44:33 --> Loader Class Initialized
INFO - 2019-09-18 03:44:33 --> Helper loaded: url_helper
INFO - 2019-09-18 03:44:33 --> Helper loaded: file_helper
INFO - 2019-09-18 03:44:33 --> Helper loaded: form_helper
INFO - 2019-09-18 03:44:33 --> Helper loaded: my_helper
INFO - 2019-09-18 03:44:33 --> Database Driver Class Initialized
DEBUG - 2019-09-18 03:44:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-09-18 03:44:33 --> Session: Class initialized using 'files' driver.
INFO - 2019-09-18 03:44:33 --> Controller Class Initialized
INFO - 2019-09-18 03:44:36 --> Config Class Initialized
INFO - 2019-09-18 03:44:36 --> Hooks Class Initialized
DEBUG - 2019-09-18 03:44:36 --> UTF-8 Support Enabled
INFO - 2019-09-18 03:44:36 --> Utf8 Class Initialized
INFO - 2019-09-18 03:44:36 --> URI Class Initialized
INFO - 2019-09-18 03:44:36 --> Router Class Initialized
INFO - 2019-09-18 03:44:36 --> Output Class Initialized
INFO - 2019-09-18 03:44:36 --> Security Class Initialized
DEBUG - 2019-09-18 03:44:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-09-18 03:44:36 --> Input Class Initialized
INFO - 2019-09-18 03:44:36 --> Language Class Initialized
INFO - 2019-09-18 03:44:36 --> Language Class Initialized
INFO - 2019-09-18 03:44:36 --> Config Class Initialized
INFO - 2019-09-18 03:44:36 --> Loader Class Initialized
INFO - 2019-09-18 03:44:36 --> Helper loaded: url_helper
INFO - 2019-09-18 03:44:36 --> Helper loaded: file_helper
INFO - 2019-09-18 03:44:36 --> Helper loaded: form_helper
INFO - 2019-09-18 03:44:36 --> Helper loaded: my_helper
INFO - 2019-09-18 03:44:36 --> Database Driver Class Initialized
DEBUG - 2019-09-18 03:44:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-09-18 03:44:36 --> Session: Class initialized using 'files' driver.
INFO - 2019-09-18 03:44:36 --> Controller Class Initialized
DEBUG - 2019-09-18 03:44:36 --> File loaded: C:\xampp\htdocs\nilai\application\modules/set_walikelas/views/list.php
DEBUG - 2019-09-18 03:44:36 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2019-09-18 03:44:36 --> Final output sent to browser
DEBUG - 2019-09-18 03:44:36 --> Total execution time: 0.3290
INFO - 2019-09-18 03:44:36 --> Config Class Initialized
INFO - 2019-09-18 03:44:36 --> Hooks Class Initialized
DEBUG - 2019-09-18 03:44:36 --> UTF-8 Support Enabled
INFO - 2019-09-18 03:44:36 --> Utf8 Class Initialized
INFO - 2019-09-18 03:44:36 --> URI Class Initialized
INFO - 2019-09-18 03:44:36 --> Router Class Initialized
INFO - 2019-09-18 03:44:36 --> Output Class Initialized
INFO - 2019-09-18 03:44:36 --> Security Class Initialized
DEBUG - 2019-09-18 03:44:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-09-18 03:44:36 --> Input Class Initialized
INFO - 2019-09-18 03:44:36 --> Language Class Initialized
INFO - 2019-09-18 03:44:36 --> Language Class Initialized
INFO - 2019-09-18 03:44:36 --> Config Class Initialized
INFO - 2019-09-18 03:44:36 --> Loader Class Initialized
INFO - 2019-09-18 03:44:36 --> Helper loaded: url_helper
INFO - 2019-09-18 03:44:36 --> Helper loaded: file_helper
INFO - 2019-09-18 03:44:36 --> Helper loaded: form_helper
INFO - 2019-09-18 03:44:36 --> Helper loaded: my_helper
INFO - 2019-09-18 03:44:36 --> Database Driver Class Initialized
DEBUG - 2019-09-18 03:44:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-09-18 03:44:36 --> Session: Class initialized using 'files' driver.
INFO - 2019-09-18 03:44:36 --> Controller Class Initialized
INFO - 2019-09-18 03:44:38 --> Config Class Initialized
INFO - 2019-09-18 03:44:38 --> Hooks Class Initialized
DEBUG - 2019-09-18 03:44:38 --> UTF-8 Support Enabled
INFO - 2019-09-18 03:44:38 --> Utf8 Class Initialized
INFO - 2019-09-18 03:44:38 --> URI Class Initialized
INFO - 2019-09-18 03:44:38 --> Router Class Initialized
INFO - 2019-09-18 03:44:38 --> Output Class Initialized
INFO - 2019-09-18 03:44:38 --> Security Class Initialized
DEBUG - 2019-09-18 03:44:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-09-18 03:44:38 --> Input Class Initialized
INFO - 2019-09-18 03:44:39 --> Language Class Initialized
INFO - 2019-09-18 03:44:39 --> Language Class Initialized
INFO - 2019-09-18 03:44:39 --> Config Class Initialized
INFO - 2019-09-18 03:44:39 --> Loader Class Initialized
INFO - 2019-09-18 03:44:39 --> Helper loaded: url_helper
INFO - 2019-09-18 03:44:39 --> Helper loaded: file_helper
INFO - 2019-09-18 03:44:39 --> Helper loaded: form_helper
INFO - 2019-09-18 03:44:39 --> Helper loaded: my_helper
INFO - 2019-09-18 03:44:39 --> Database Driver Class Initialized
DEBUG - 2019-09-18 03:44:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-09-18 03:44:39 --> Session: Class initialized using 'files' driver.
INFO - 2019-09-18 03:44:39 --> Controller Class Initialized
INFO - 2019-09-18 03:44:39 --> Final output sent to browser
DEBUG - 2019-09-18 03:44:39 --> Total execution time: 0.2830
INFO - 2019-09-18 03:44:46 --> Config Class Initialized
INFO - 2019-09-18 03:44:46 --> Hooks Class Initialized
DEBUG - 2019-09-18 03:44:46 --> UTF-8 Support Enabled
INFO - 2019-09-18 03:44:46 --> Utf8 Class Initialized
INFO - 2019-09-18 03:44:46 --> URI Class Initialized
INFO - 2019-09-18 03:44:46 --> Router Class Initialized
INFO - 2019-09-18 03:44:46 --> Output Class Initialized
INFO - 2019-09-18 03:44:46 --> Security Class Initialized
DEBUG - 2019-09-18 03:44:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-09-18 03:44:46 --> Input Class Initialized
INFO - 2019-09-18 03:44:46 --> Language Class Initialized
INFO - 2019-09-18 03:44:46 --> Language Class Initialized
INFO - 2019-09-18 03:44:46 --> Config Class Initialized
INFO - 2019-09-18 03:44:46 --> Loader Class Initialized
INFO - 2019-09-18 03:44:46 --> Helper loaded: url_helper
INFO - 2019-09-18 03:44:46 --> Helper loaded: file_helper
INFO - 2019-09-18 03:44:46 --> Helper loaded: form_helper
INFO - 2019-09-18 03:44:46 --> Helper loaded: my_helper
INFO - 2019-09-18 03:44:46 --> Database Driver Class Initialized
DEBUG - 2019-09-18 03:44:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-09-18 03:44:46 --> Session: Class initialized using 'files' driver.
INFO - 2019-09-18 03:44:46 --> Controller Class Initialized
INFO - 2019-09-18 03:44:46 --> Final output sent to browser
DEBUG - 2019-09-18 03:44:46 --> Total execution time: 0.2760
INFO - 2019-09-18 03:44:52 --> Config Class Initialized
INFO - 2019-09-18 03:44:52 --> Hooks Class Initialized
DEBUG - 2019-09-18 03:44:52 --> UTF-8 Support Enabled
INFO - 2019-09-18 03:44:52 --> Utf8 Class Initialized
INFO - 2019-09-18 03:44:52 --> URI Class Initialized
INFO - 2019-09-18 03:44:52 --> Router Class Initialized
INFO - 2019-09-18 03:44:52 --> Output Class Initialized
INFO - 2019-09-18 03:44:52 --> Security Class Initialized
DEBUG - 2019-09-18 03:44:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-09-18 03:44:52 --> Input Class Initialized
INFO - 2019-09-18 03:44:52 --> Language Class Initialized
INFO - 2019-09-18 03:44:52 --> Language Class Initialized
INFO - 2019-09-18 03:44:52 --> Config Class Initialized
INFO - 2019-09-18 03:44:52 --> Loader Class Initialized
INFO - 2019-09-18 03:44:52 --> Helper loaded: url_helper
INFO - 2019-09-18 03:44:52 --> Helper loaded: file_helper
INFO - 2019-09-18 03:44:52 --> Helper loaded: form_helper
INFO - 2019-09-18 03:44:52 --> Helper loaded: my_helper
INFO - 2019-09-18 03:44:52 --> Database Driver Class Initialized
DEBUG - 2019-09-18 03:44:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-09-18 03:44:52 --> Session: Class initialized using 'files' driver.
INFO - 2019-09-18 03:44:52 --> Controller Class Initialized
DEBUG - 2019-09-18 03:44:52 --> File loaded: C:\xampp\htdocs\nilai\application\modules/set_walikelas/views/list.php
DEBUG - 2019-09-18 03:44:52 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2019-09-18 03:44:52 --> Final output sent to browser
DEBUG - 2019-09-18 03:44:52 --> Total execution time: 0.2910
INFO - 2019-09-18 03:44:52 --> Config Class Initialized
INFO - 2019-09-18 03:44:52 --> Hooks Class Initialized
DEBUG - 2019-09-18 03:44:52 --> UTF-8 Support Enabled
INFO - 2019-09-18 03:44:52 --> Utf8 Class Initialized
INFO - 2019-09-18 03:44:52 --> URI Class Initialized
INFO - 2019-09-18 03:44:52 --> Router Class Initialized
INFO - 2019-09-18 03:44:52 --> Output Class Initialized
INFO - 2019-09-18 03:44:52 --> Security Class Initialized
DEBUG - 2019-09-18 03:44:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-09-18 03:44:52 --> Input Class Initialized
INFO - 2019-09-18 03:44:52 --> Language Class Initialized
INFO - 2019-09-18 03:44:52 --> Language Class Initialized
INFO - 2019-09-18 03:44:52 --> Config Class Initialized
INFO - 2019-09-18 03:44:52 --> Loader Class Initialized
INFO - 2019-09-18 03:44:52 --> Helper loaded: url_helper
INFO - 2019-09-18 03:44:52 --> Helper loaded: file_helper
INFO - 2019-09-18 03:44:52 --> Helper loaded: form_helper
INFO - 2019-09-18 03:44:52 --> Helper loaded: my_helper
INFO - 2019-09-18 03:44:52 --> Database Driver Class Initialized
DEBUG - 2019-09-18 03:44:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-09-18 03:44:52 --> Session: Class initialized using 'files' driver.
INFO - 2019-09-18 03:44:52 --> Controller Class Initialized
INFO - 2019-09-18 03:44:53 --> Config Class Initialized
INFO - 2019-09-18 03:44:53 --> Hooks Class Initialized
DEBUG - 2019-09-18 03:44:53 --> UTF-8 Support Enabled
INFO - 2019-09-18 03:44:53 --> Utf8 Class Initialized
INFO - 2019-09-18 03:44:53 --> URI Class Initialized
INFO - 2019-09-18 03:44:53 --> Router Class Initialized
INFO - 2019-09-18 03:44:53 --> Output Class Initialized
INFO - 2019-09-18 03:44:53 --> Security Class Initialized
DEBUG - 2019-09-18 03:44:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-09-18 03:44:53 --> Input Class Initialized
INFO - 2019-09-18 03:44:53 --> Language Class Initialized
INFO - 2019-09-18 03:44:53 --> Language Class Initialized
INFO - 2019-09-18 03:44:53 --> Config Class Initialized
INFO - 2019-09-18 03:44:53 --> Loader Class Initialized
INFO - 2019-09-18 03:44:53 --> Helper loaded: url_helper
INFO - 2019-09-18 03:44:53 --> Helper loaded: file_helper
INFO - 2019-09-18 03:44:53 --> Helper loaded: form_helper
INFO - 2019-09-18 03:44:53 --> Helper loaded: my_helper
INFO - 2019-09-18 03:44:53 --> Database Driver Class Initialized
DEBUG - 2019-09-18 03:44:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-09-18 03:44:53 --> Session: Class initialized using 'files' driver.
INFO - 2019-09-18 03:44:53 --> Controller Class Initialized
DEBUG - 2019-09-18 03:44:53 --> File loaded: C:\xampp\htdocs\nilai\application\modules/set_mapel/views/list.php
DEBUG - 2019-09-18 03:44:53 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2019-09-18 03:44:53 --> Final output sent to browser
DEBUG - 2019-09-18 03:44:53 --> Total execution time: 0.3350
INFO - 2019-09-18 03:44:53 --> Config Class Initialized
INFO - 2019-09-18 03:44:53 --> Hooks Class Initialized
DEBUG - 2019-09-18 03:44:53 --> UTF-8 Support Enabled
INFO - 2019-09-18 03:44:53 --> Utf8 Class Initialized
INFO - 2019-09-18 03:44:53 --> URI Class Initialized
INFO - 2019-09-18 03:44:53 --> Router Class Initialized
INFO - 2019-09-18 03:44:53 --> Output Class Initialized
INFO - 2019-09-18 03:44:53 --> Security Class Initialized
DEBUG - 2019-09-18 03:44:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-09-18 03:44:53 --> Input Class Initialized
INFO - 2019-09-18 03:44:53 --> Language Class Initialized
INFO - 2019-09-18 03:44:53 --> Language Class Initialized
INFO - 2019-09-18 03:44:53 --> Config Class Initialized
INFO - 2019-09-18 03:44:53 --> Loader Class Initialized
INFO - 2019-09-18 03:44:53 --> Helper loaded: url_helper
INFO - 2019-09-18 03:44:53 --> Helper loaded: file_helper
INFO - 2019-09-18 03:44:53 --> Helper loaded: form_helper
INFO - 2019-09-18 03:44:53 --> Helper loaded: my_helper
INFO - 2019-09-18 03:44:53 --> Database Driver Class Initialized
DEBUG - 2019-09-18 03:44:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-09-18 03:44:53 --> Session: Class initialized using 'files' driver.
INFO - 2019-09-18 03:44:53 --> Controller Class Initialized
INFO - 2019-09-18 03:44:55 --> Config Class Initialized
INFO - 2019-09-18 03:44:55 --> Hooks Class Initialized
DEBUG - 2019-09-18 03:44:55 --> UTF-8 Support Enabled
INFO - 2019-09-18 03:44:55 --> Utf8 Class Initialized
INFO - 2019-09-18 03:44:55 --> URI Class Initialized
INFO - 2019-09-18 03:44:55 --> Router Class Initialized
INFO - 2019-09-18 03:44:55 --> Output Class Initialized
INFO - 2019-09-18 03:44:55 --> Security Class Initialized
DEBUG - 2019-09-18 03:44:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-09-18 03:44:55 --> Input Class Initialized
INFO - 2019-09-18 03:44:55 --> Language Class Initialized
INFO - 2019-09-18 03:44:55 --> Language Class Initialized
INFO - 2019-09-18 03:44:55 --> Config Class Initialized
INFO - 2019-09-18 03:44:55 --> Loader Class Initialized
INFO - 2019-09-18 03:44:55 --> Helper loaded: url_helper
INFO - 2019-09-18 03:44:55 --> Helper loaded: file_helper
INFO - 2019-09-18 03:44:55 --> Helper loaded: form_helper
INFO - 2019-09-18 03:44:55 --> Helper loaded: my_helper
INFO - 2019-09-18 03:44:55 --> Database Driver Class Initialized
DEBUG - 2019-09-18 03:44:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-09-18 03:44:55 --> Session: Class initialized using 'files' driver.
INFO - 2019-09-18 03:44:55 --> Controller Class Initialized
DEBUG - 2019-09-18 03:44:55 --> File loaded: C:\xampp\htdocs\nilai\application\modules/data_ekstra/views/list.php
DEBUG - 2019-09-18 03:44:55 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2019-09-18 03:44:55 --> Final output sent to browser
DEBUG - 2019-09-18 03:44:55 --> Total execution time: 0.3140
INFO - 2019-09-18 03:44:55 --> Config Class Initialized
INFO - 2019-09-18 03:44:55 --> Hooks Class Initialized
DEBUG - 2019-09-18 03:44:55 --> UTF-8 Support Enabled
INFO - 2019-09-18 03:44:55 --> Utf8 Class Initialized
INFO - 2019-09-18 03:44:55 --> URI Class Initialized
INFO - 2019-09-18 03:44:55 --> Router Class Initialized
INFO - 2019-09-18 03:44:56 --> Output Class Initialized
INFO - 2019-09-18 03:44:56 --> Security Class Initialized
DEBUG - 2019-09-18 03:44:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-09-18 03:44:56 --> Input Class Initialized
INFO - 2019-09-18 03:44:56 --> Language Class Initialized
INFO - 2019-09-18 03:44:56 --> Language Class Initialized
INFO - 2019-09-18 03:44:56 --> Config Class Initialized
INFO - 2019-09-18 03:44:56 --> Loader Class Initialized
INFO - 2019-09-18 03:44:56 --> Helper loaded: url_helper
INFO - 2019-09-18 03:44:56 --> Helper loaded: file_helper
INFO - 2019-09-18 03:44:56 --> Helper loaded: form_helper
INFO - 2019-09-18 03:44:56 --> Helper loaded: my_helper
INFO - 2019-09-18 03:44:56 --> Database Driver Class Initialized
DEBUG - 2019-09-18 03:44:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-09-18 03:44:56 --> Session: Class initialized using 'files' driver.
INFO - 2019-09-18 03:44:56 --> Controller Class Initialized
INFO - 2019-09-18 03:44:57 --> Config Class Initialized
INFO - 2019-09-18 03:44:57 --> Hooks Class Initialized
DEBUG - 2019-09-18 03:44:57 --> UTF-8 Support Enabled
INFO - 2019-09-18 03:44:57 --> Utf8 Class Initialized
INFO - 2019-09-18 03:44:57 --> URI Class Initialized
DEBUG - 2019-09-18 03:44:57 --> No URI present. Default controller set.
INFO - 2019-09-18 03:44:57 --> Router Class Initialized
INFO - 2019-09-18 03:44:57 --> Output Class Initialized
INFO - 2019-09-18 03:44:57 --> Security Class Initialized
DEBUG - 2019-09-18 03:44:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-09-18 03:44:57 --> Input Class Initialized
INFO - 2019-09-18 03:44:57 --> Language Class Initialized
INFO - 2019-09-18 03:44:57 --> Language Class Initialized
INFO - 2019-09-18 03:44:57 --> Config Class Initialized
INFO - 2019-09-18 03:44:57 --> Loader Class Initialized
INFO - 2019-09-18 03:44:57 --> Helper loaded: url_helper
INFO - 2019-09-18 03:44:57 --> Helper loaded: file_helper
INFO - 2019-09-18 03:44:57 --> Helper loaded: form_helper
INFO - 2019-09-18 03:44:57 --> Helper loaded: my_helper
INFO - 2019-09-18 03:44:57 --> Database Driver Class Initialized
DEBUG - 2019-09-18 03:44:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-09-18 03:44:57 --> Session: Class initialized using 'files' driver.
INFO - 2019-09-18 03:44:57 --> Controller Class Initialized
DEBUG - 2019-09-18 03:44:57 --> File loaded: C:\xampp\htdocs\nilai\application\modules/home/views/v_home.php
DEBUG - 2019-09-18 03:44:57 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2019-09-18 03:44:57 --> Final output sent to browser
DEBUG - 2019-09-18 03:44:57 --> Total execution time: 0.3060
INFO - 2019-09-18 03:45:00 --> Config Class Initialized
INFO - 2019-09-18 03:45:00 --> Hooks Class Initialized
DEBUG - 2019-09-18 03:45:00 --> UTF-8 Support Enabled
INFO - 2019-09-18 03:45:00 --> Utf8 Class Initialized
INFO - 2019-09-18 03:45:00 --> URI Class Initialized
INFO - 2019-09-18 03:45:00 --> Router Class Initialized
INFO - 2019-09-18 03:45:00 --> Output Class Initialized
INFO - 2019-09-18 03:45:00 --> Security Class Initialized
DEBUG - 2019-09-18 03:45:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-09-18 03:45:00 --> Input Class Initialized
INFO - 2019-09-18 03:45:00 --> Language Class Initialized
INFO - 2019-09-18 03:45:00 --> Language Class Initialized
INFO - 2019-09-18 03:45:00 --> Config Class Initialized
INFO - 2019-09-18 03:45:00 --> Loader Class Initialized
INFO - 2019-09-18 03:45:00 --> Helper loaded: url_helper
INFO - 2019-09-18 03:45:00 --> Helper loaded: file_helper
INFO - 2019-09-18 03:45:00 --> Helper loaded: form_helper
INFO - 2019-09-18 03:45:00 --> Helper loaded: my_helper
INFO - 2019-09-18 03:45:00 --> Database Driver Class Initialized
DEBUG - 2019-09-18 03:45:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-09-18 03:45:00 --> Session: Class initialized using 'files' driver.
INFO - 2019-09-18 03:45:00 --> Controller Class Initialized
DEBUG - 2019-09-18 03:45:00 --> File loaded: C:\xampp\htdocs\nilai\application\modules/data_siswa/views/list.php
DEBUG - 2019-09-18 03:45:00 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2019-09-18 03:45:00 --> Final output sent to browser
DEBUG - 2019-09-18 03:45:00 --> Total execution time: 0.2950
INFO - 2019-09-18 03:45:00 --> Config Class Initialized
INFO - 2019-09-18 03:45:00 --> Hooks Class Initialized
DEBUG - 2019-09-18 03:45:01 --> UTF-8 Support Enabled
INFO - 2019-09-18 03:45:01 --> Utf8 Class Initialized
INFO - 2019-09-18 03:45:01 --> URI Class Initialized
INFO - 2019-09-18 03:45:01 --> Router Class Initialized
INFO - 2019-09-18 03:45:01 --> Output Class Initialized
INFO - 2019-09-18 03:45:01 --> Security Class Initialized
DEBUG - 2019-09-18 03:45:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-09-18 03:45:01 --> Input Class Initialized
INFO - 2019-09-18 03:45:01 --> Language Class Initialized
INFO - 2019-09-18 03:45:01 --> Language Class Initialized
INFO - 2019-09-18 03:45:01 --> Config Class Initialized
INFO - 2019-09-18 03:45:01 --> Loader Class Initialized
INFO - 2019-09-18 03:45:01 --> Helper loaded: url_helper
INFO - 2019-09-18 03:45:01 --> Helper loaded: file_helper
INFO - 2019-09-18 03:45:01 --> Helper loaded: form_helper
INFO - 2019-09-18 03:45:01 --> Helper loaded: my_helper
INFO - 2019-09-18 03:45:01 --> Database Driver Class Initialized
DEBUG - 2019-09-18 03:45:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-09-18 03:45:01 --> Session: Class initialized using 'files' driver.
INFO - 2019-09-18 03:45:01 --> Controller Class Initialized
INFO - 2019-09-18 03:45:03 --> Config Class Initialized
INFO - 2019-09-18 03:45:03 --> Hooks Class Initialized
DEBUG - 2019-09-18 03:45:03 --> UTF-8 Support Enabled
INFO - 2019-09-18 03:45:03 --> Utf8 Class Initialized
INFO - 2019-09-18 03:45:03 --> URI Class Initialized
DEBUG - 2019-09-18 03:45:03 --> No URI present. Default controller set.
INFO - 2019-09-18 03:45:03 --> Router Class Initialized
INFO - 2019-09-18 03:45:03 --> Output Class Initialized
INFO - 2019-09-18 03:45:03 --> Security Class Initialized
DEBUG - 2019-09-18 03:45:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-09-18 03:45:03 --> Input Class Initialized
INFO - 2019-09-18 03:45:03 --> Language Class Initialized
INFO - 2019-09-18 03:45:03 --> Language Class Initialized
INFO - 2019-09-18 03:45:03 --> Config Class Initialized
INFO - 2019-09-18 03:45:03 --> Loader Class Initialized
INFO - 2019-09-18 03:45:03 --> Helper loaded: url_helper
INFO - 2019-09-18 03:45:03 --> Helper loaded: file_helper
INFO - 2019-09-18 03:45:03 --> Helper loaded: form_helper
INFO - 2019-09-18 03:45:03 --> Helper loaded: my_helper
INFO - 2019-09-18 03:45:03 --> Database Driver Class Initialized
DEBUG - 2019-09-18 03:45:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-09-18 03:45:03 --> Session: Class initialized using 'files' driver.
INFO - 2019-09-18 03:45:03 --> Controller Class Initialized
DEBUG - 2019-09-18 03:45:03 --> File loaded: C:\xampp\htdocs\nilai\application\modules/home/views/v_home.php
DEBUG - 2019-09-18 03:45:03 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2019-09-18 03:45:03 --> Final output sent to browser
DEBUG - 2019-09-18 03:45:03 --> Total execution time: 0.3110
INFO - 2019-09-18 03:45:15 --> Config Class Initialized
INFO - 2019-09-18 03:45:15 --> Hooks Class Initialized
DEBUG - 2019-09-18 03:45:15 --> UTF-8 Support Enabled
INFO - 2019-09-18 03:45:16 --> Utf8 Class Initialized
INFO - 2019-09-18 03:45:16 --> URI Class Initialized
INFO - 2019-09-18 03:45:16 --> Router Class Initialized
INFO - 2019-09-18 03:45:16 --> Output Class Initialized
INFO - 2019-09-18 03:45:16 --> Security Class Initialized
DEBUG - 2019-09-18 03:45:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-09-18 03:45:16 --> Input Class Initialized
INFO - 2019-09-18 03:45:16 --> Language Class Initialized
INFO - 2019-09-18 03:45:16 --> Language Class Initialized
INFO - 2019-09-18 03:45:16 --> Config Class Initialized
INFO - 2019-09-18 03:45:16 --> Loader Class Initialized
INFO - 2019-09-18 03:45:16 --> Helper loaded: url_helper
INFO - 2019-09-18 03:45:16 --> Helper loaded: file_helper
INFO - 2019-09-18 03:45:16 --> Helper loaded: form_helper
INFO - 2019-09-18 03:45:16 --> Helper loaded: my_helper
INFO - 2019-09-18 03:45:16 --> Database Driver Class Initialized
DEBUG - 2019-09-18 03:45:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-09-18 03:45:16 --> Session: Class initialized using 'files' driver.
INFO - 2019-09-18 03:45:16 --> Controller Class Initialized
DEBUG - 2019-09-18 03:45:16 --> File loaded: C:\xampp\htdocs\nilai\application\modules/data_ekstra/views/list.php
DEBUG - 2019-09-18 03:45:16 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2019-09-18 03:45:16 --> Final output sent to browser
DEBUG - 2019-09-18 03:45:16 --> Total execution time: 0.2990
INFO - 2019-09-18 03:45:16 --> Config Class Initialized
INFO - 2019-09-18 03:45:16 --> Hooks Class Initialized
DEBUG - 2019-09-18 03:45:16 --> UTF-8 Support Enabled
INFO - 2019-09-18 03:45:16 --> Utf8 Class Initialized
INFO - 2019-09-18 03:45:16 --> URI Class Initialized
INFO - 2019-09-18 03:45:16 --> Router Class Initialized
INFO - 2019-09-18 03:45:16 --> Output Class Initialized
INFO - 2019-09-18 03:45:16 --> Security Class Initialized
DEBUG - 2019-09-18 03:45:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-09-18 03:45:16 --> Input Class Initialized
INFO - 2019-09-18 03:45:16 --> Language Class Initialized
INFO - 2019-09-18 03:45:16 --> Language Class Initialized
INFO - 2019-09-18 03:45:16 --> Config Class Initialized
INFO - 2019-09-18 03:45:16 --> Loader Class Initialized
INFO - 2019-09-18 03:45:16 --> Helper loaded: url_helper
INFO - 2019-09-18 03:45:16 --> Helper loaded: file_helper
INFO - 2019-09-18 03:45:16 --> Helper loaded: form_helper
INFO - 2019-09-18 03:45:16 --> Helper loaded: my_helper
INFO - 2019-09-18 03:45:16 --> Database Driver Class Initialized
DEBUG - 2019-09-18 03:45:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-09-18 03:45:16 --> Session: Class initialized using 'files' driver.
INFO - 2019-09-18 03:45:16 --> Controller Class Initialized
INFO - 2019-09-18 03:45:18 --> Config Class Initialized
INFO - 2019-09-18 03:45:18 --> Hooks Class Initialized
DEBUG - 2019-09-18 03:45:18 --> UTF-8 Support Enabled
INFO - 2019-09-18 03:45:18 --> Utf8 Class Initialized
INFO - 2019-09-18 03:45:18 --> URI Class Initialized
INFO - 2019-09-18 03:45:18 --> Router Class Initialized
INFO - 2019-09-18 03:45:18 --> Output Class Initialized
INFO - 2019-09-18 03:45:18 --> Security Class Initialized
DEBUG - 2019-09-18 03:45:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-09-18 03:45:18 --> Input Class Initialized
INFO - 2019-09-18 03:45:18 --> Language Class Initialized
INFO - 2019-09-18 03:45:19 --> Language Class Initialized
INFO - 2019-09-18 03:45:19 --> Config Class Initialized
INFO - 2019-09-18 03:45:19 --> Loader Class Initialized
INFO - 2019-09-18 03:45:19 --> Helper loaded: url_helper
INFO - 2019-09-18 03:45:19 --> Helper loaded: file_helper
INFO - 2019-09-18 03:45:19 --> Helper loaded: form_helper
INFO - 2019-09-18 03:45:19 --> Helper loaded: my_helper
INFO - 2019-09-18 03:45:19 --> Database Driver Class Initialized
DEBUG - 2019-09-18 03:45:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-09-18 03:45:19 --> Session: Class initialized using 'files' driver.
INFO - 2019-09-18 03:45:19 --> Controller Class Initialized
DEBUG - 2019-09-18 03:45:19 --> File loaded: C:\xampp\htdocs\nilai\application\modules/set_kelas/views/list.php
DEBUG - 2019-09-18 03:45:19 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2019-09-18 03:45:19 --> Final output sent to browser
DEBUG - 2019-09-18 03:45:19 --> Total execution time: 0.3270
INFO - 2019-09-18 03:45:20 --> Config Class Initialized
INFO - 2019-09-18 03:45:20 --> Hooks Class Initialized
DEBUG - 2019-09-18 03:45:20 --> UTF-8 Support Enabled
INFO - 2019-09-18 03:45:20 --> Utf8 Class Initialized
INFO - 2019-09-18 03:45:20 --> URI Class Initialized
DEBUG - 2019-09-18 03:45:20 --> No URI present. Default controller set.
INFO - 2019-09-18 03:45:20 --> Router Class Initialized
INFO - 2019-09-18 03:45:20 --> Output Class Initialized
INFO - 2019-09-18 03:45:20 --> Security Class Initialized
DEBUG - 2019-09-18 03:45:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-09-18 03:45:20 --> Input Class Initialized
INFO - 2019-09-18 03:45:20 --> Language Class Initialized
INFO - 2019-09-18 03:45:20 --> Language Class Initialized
INFO - 2019-09-18 03:45:20 --> Config Class Initialized
INFO - 2019-09-18 03:45:20 --> Loader Class Initialized
INFO - 2019-09-18 03:45:20 --> Helper loaded: url_helper
INFO - 2019-09-18 03:45:20 --> Helper loaded: file_helper
INFO - 2019-09-18 03:45:20 --> Helper loaded: form_helper
INFO - 2019-09-18 03:45:20 --> Helper loaded: my_helper
INFO - 2019-09-18 03:45:20 --> Database Driver Class Initialized
DEBUG - 2019-09-18 03:45:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-09-18 03:45:20 --> Session: Class initialized using 'files' driver.
INFO - 2019-09-18 03:45:20 --> Controller Class Initialized
DEBUG - 2019-09-18 03:45:20 --> File loaded: C:\xampp\htdocs\nilai\application\modules/home/views/v_home.php
DEBUG - 2019-09-18 03:45:20 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2019-09-18 03:45:20 --> Final output sent to browser
DEBUG - 2019-09-18 03:45:20 --> Total execution time: 0.3100
INFO - 2019-09-18 03:45:22 --> Config Class Initialized
INFO - 2019-09-18 03:45:22 --> Hooks Class Initialized
DEBUG - 2019-09-18 03:45:22 --> UTF-8 Support Enabled
INFO - 2019-09-18 03:45:22 --> Utf8 Class Initialized
INFO - 2019-09-18 03:45:22 --> URI Class Initialized
DEBUG - 2019-09-18 03:45:22 --> No URI present. Default controller set.
INFO - 2019-09-18 03:45:22 --> Router Class Initialized
INFO - 2019-09-18 03:45:22 --> Output Class Initialized
INFO - 2019-09-18 03:45:22 --> Security Class Initialized
DEBUG - 2019-09-18 03:45:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-09-18 03:45:22 --> Input Class Initialized
INFO - 2019-09-18 03:45:22 --> Language Class Initialized
INFO - 2019-09-18 03:45:22 --> Language Class Initialized
INFO - 2019-09-18 03:45:22 --> Config Class Initialized
INFO - 2019-09-18 03:45:22 --> Loader Class Initialized
INFO - 2019-09-18 03:45:22 --> Helper loaded: url_helper
INFO - 2019-09-18 03:45:22 --> Helper loaded: file_helper
INFO - 2019-09-18 03:45:22 --> Helper loaded: form_helper
INFO - 2019-09-18 03:45:22 --> Helper loaded: my_helper
INFO - 2019-09-18 03:45:22 --> Database Driver Class Initialized
DEBUG - 2019-09-18 03:45:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-09-18 03:45:22 --> Session: Class initialized using 'files' driver.
INFO - 2019-09-18 03:45:22 --> Controller Class Initialized
DEBUG - 2019-09-18 03:45:22 --> File loaded: C:\xampp\htdocs\nilai\application\modules/home/views/v_home.php
DEBUG - 2019-09-18 03:45:22 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2019-09-18 03:45:22 --> Final output sent to browser
DEBUG - 2019-09-18 03:45:22 --> Total execution time: 0.3080
INFO - 2019-09-18 03:45:26 --> Config Class Initialized
INFO - 2019-09-18 03:45:26 --> Hooks Class Initialized
DEBUG - 2019-09-18 03:45:26 --> UTF-8 Support Enabled
INFO - 2019-09-18 03:45:26 --> Utf8 Class Initialized
INFO - 2019-09-18 03:45:26 --> URI Class Initialized
INFO - 2019-09-18 03:45:26 --> Router Class Initialized
INFO - 2019-09-18 03:45:26 --> Output Class Initialized
INFO - 2019-09-18 03:45:26 --> Security Class Initialized
DEBUG - 2019-09-18 03:45:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-09-18 03:45:26 --> Input Class Initialized
INFO - 2019-09-18 03:45:26 --> Language Class Initialized
INFO - 2019-09-18 03:45:26 --> Language Class Initialized
INFO - 2019-09-18 03:45:27 --> Config Class Initialized
INFO - 2019-09-18 03:45:27 --> Loader Class Initialized
INFO - 2019-09-18 03:45:27 --> Helper loaded: url_helper
INFO - 2019-09-18 03:45:27 --> Helper loaded: file_helper
INFO - 2019-09-18 03:45:27 --> Helper loaded: form_helper
INFO - 2019-09-18 03:45:27 --> Helper loaded: my_helper
INFO - 2019-09-18 03:45:27 --> Database Driver Class Initialized
DEBUG - 2019-09-18 03:45:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-09-18 03:45:27 --> Session: Class initialized using 'files' driver.
INFO - 2019-09-18 03:45:27 --> Controller Class Initialized
DEBUG - 2019-09-18 03:45:27 --> File loaded: C:\xampp\htdocs\nilai\application\modules/data_siswa/views/list.php
DEBUG - 2019-09-18 03:45:27 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2019-09-18 03:45:27 --> Final output sent to browser
DEBUG - 2019-09-18 03:45:27 --> Total execution time: 0.3100
INFO - 2019-09-18 03:45:27 --> Config Class Initialized
INFO - 2019-09-18 03:45:27 --> Hooks Class Initialized
DEBUG - 2019-09-18 03:45:27 --> UTF-8 Support Enabled
INFO - 2019-09-18 03:45:27 --> Utf8 Class Initialized
INFO - 2019-09-18 03:45:27 --> URI Class Initialized
INFO - 2019-09-18 03:45:27 --> Router Class Initialized
INFO - 2019-09-18 03:45:27 --> Output Class Initialized
INFO - 2019-09-18 03:45:27 --> Security Class Initialized
DEBUG - 2019-09-18 03:45:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-09-18 03:45:27 --> Input Class Initialized
INFO - 2019-09-18 03:45:27 --> Language Class Initialized
INFO - 2019-09-18 03:45:27 --> Language Class Initialized
INFO - 2019-09-18 03:45:27 --> Config Class Initialized
INFO - 2019-09-18 03:45:27 --> Loader Class Initialized
INFO - 2019-09-18 03:45:27 --> Helper loaded: url_helper
INFO - 2019-09-18 03:45:27 --> Helper loaded: file_helper
INFO - 2019-09-18 03:45:27 --> Helper loaded: form_helper
INFO - 2019-09-18 03:45:27 --> Helper loaded: my_helper
INFO - 2019-09-18 03:45:27 --> Database Driver Class Initialized
DEBUG - 2019-09-18 03:45:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-09-18 03:45:27 --> Session: Class initialized using 'files' driver.
INFO - 2019-09-18 03:45:27 --> Controller Class Initialized
INFO - 2019-09-18 03:45:27 --> Config Class Initialized
INFO - 2019-09-18 03:45:27 --> Hooks Class Initialized
DEBUG - 2019-09-18 03:45:27 --> UTF-8 Support Enabled
INFO - 2019-09-18 03:45:27 --> Utf8 Class Initialized
INFO - 2019-09-18 03:45:27 --> URI Class Initialized
INFO - 2019-09-18 03:45:27 --> Router Class Initialized
INFO - 2019-09-18 03:45:27 --> Output Class Initialized
INFO - 2019-09-18 03:45:27 --> Security Class Initialized
DEBUG - 2019-09-18 03:45:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-09-18 03:45:27 --> Input Class Initialized
INFO - 2019-09-18 03:45:27 --> Language Class Initialized
INFO - 2019-09-18 03:45:28 --> Language Class Initialized
INFO - 2019-09-18 03:45:28 --> Config Class Initialized
INFO - 2019-09-18 03:45:28 --> Loader Class Initialized
INFO - 2019-09-18 03:45:28 --> Helper loaded: url_helper
INFO - 2019-09-18 03:45:28 --> Helper loaded: file_helper
INFO - 2019-09-18 03:45:28 --> Helper loaded: form_helper
INFO - 2019-09-18 03:45:28 --> Helper loaded: my_helper
INFO - 2019-09-18 03:45:28 --> Database Driver Class Initialized
DEBUG - 2019-09-18 03:45:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-09-18 03:45:28 --> Session: Class initialized using 'files' driver.
INFO - 2019-09-18 03:45:28 --> Controller Class Initialized
DEBUG - 2019-09-18 03:45:28 --> File loaded: C:\xampp\htdocs\nilai\application\modules/data_guru/views/list.php
DEBUG - 2019-09-18 03:45:28 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2019-09-18 03:45:28 --> Final output sent to browser
DEBUG - 2019-09-18 03:45:28 --> Total execution time: 0.4380
INFO - 2019-09-18 03:45:28 --> Config Class Initialized
INFO - 2019-09-18 03:45:28 --> Hooks Class Initialized
DEBUG - 2019-09-18 03:45:28 --> UTF-8 Support Enabled
INFO - 2019-09-18 03:45:28 --> Utf8 Class Initialized
INFO - 2019-09-18 03:45:28 --> URI Class Initialized
INFO - 2019-09-18 03:45:28 --> Router Class Initialized
INFO - 2019-09-18 03:45:28 --> Output Class Initialized
INFO - 2019-09-18 03:45:28 --> Security Class Initialized
DEBUG - 2019-09-18 03:45:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-09-18 03:45:28 --> Input Class Initialized
INFO - 2019-09-18 03:45:28 --> Language Class Initialized
INFO - 2019-09-18 03:45:28 --> Language Class Initialized
INFO - 2019-09-18 03:45:28 --> Config Class Initialized
INFO - 2019-09-18 03:45:28 --> Loader Class Initialized
INFO - 2019-09-18 03:45:28 --> Helper loaded: url_helper
INFO - 2019-09-18 03:45:28 --> Helper loaded: file_helper
INFO - 2019-09-18 03:45:28 --> Helper loaded: form_helper
INFO - 2019-09-18 03:45:28 --> Helper loaded: my_helper
INFO - 2019-09-18 03:45:28 --> Database Driver Class Initialized
DEBUG - 2019-09-18 03:45:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-09-18 03:45:28 --> Session: Class initialized using 'files' driver.
INFO - 2019-09-18 03:45:28 --> Controller Class Initialized
INFO - 2019-09-18 03:45:34 --> Config Class Initialized
INFO - 2019-09-18 03:45:34 --> Hooks Class Initialized
DEBUG - 2019-09-18 03:45:34 --> UTF-8 Support Enabled
INFO - 2019-09-18 03:45:34 --> Utf8 Class Initialized
INFO - 2019-09-18 03:45:34 --> URI Class Initialized
INFO - 2019-09-18 03:45:34 --> Router Class Initialized
INFO - 2019-09-18 03:45:34 --> Output Class Initialized
INFO - 2019-09-18 03:45:34 --> Security Class Initialized
DEBUG - 2019-09-18 03:45:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-09-18 03:45:34 --> Input Class Initialized
INFO - 2019-09-18 03:45:34 --> Language Class Initialized
INFO - 2019-09-18 03:45:34 --> Language Class Initialized
INFO - 2019-09-18 03:45:34 --> Config Class Initialized
INFO - 2019-09-18 03:45:34 --> Loader Class Initialized
INFO - 2019-09-18 03:45:34 --> Helper loaded: url_helper
INFO - 2019-09-18 03:45:34 --> Helper loaded: file_helper
INFO - 2019-09-18 03:45:34 --> Helper loaded: form_helper
INFO - 2019-09-18 03:45:34 --> Helper loaded: my_helper
INFO - 2019-09-18 03:45:34 --> Database Driver Class Initialized
DEBUG - 2019-09-18 03:45:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-09-18 03:45:34 --> Session: Class initialized using 'files' driver.
INFO - 2019-09-18 03:45:34 --> Controller Class Initialized
INFO - 2019-09-18 03:45:34 --> Final output sent to browser
DEBUG - 2019-09-18 03:45:34 --> Total execution time: 0.2810
INFO - 2019-09-18 03:45:38 --> Config Class Initialized
INFO - 2019-09-18 03:45:38 --> Hooks Class Initialized
DEBUG - 2019-09-18 03:45:38 --> UTF-8 Support Enabled
INFO - 2019-09-18 03:45:38 --> Utf8 Class Initialized
INFO - 2019-09-18 03:45:38 --> URI Class Initialized
INFO - 2019-09-18 03:45:38 --> Router Class Initialized
INFO - 2019-09-18 03:45:38 --> Output Class Initialized
INFO - 2019-09-18 03:45:38 --> Security Class Initialized
DEBUG - 2019-09-18 03:45:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-09-18 03:45:38 --> Input Class Initialized
INFO - 2019-09-18 03:45:38 --> Language Class Initialized
INFO - 2019-09-18 03:45:38 --> Language Class Initialized
INFO - 2019-09-18 03:45:38 --> Config Class Initialized
INFO - 2019-09-18 03:45:38 --> Loader Class Initialized
INFO - 2019-09-18 03:45:38 --> Helper loaded: url_helper
INFO - 2019-09-18 03:45:38 --> Helper loaded: file_helper
INFO - 2019-09-18 03:45:38 --> Helper loaded: form_helper
INFO - 2019-09-18 03:45:38 --> Helper loaded: my_helper
INFO - 2019-09-18 03:45:38 --> Database Driver Class Initialized
DEBUG - 2019-09-18 03:45:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-09-18 03:45:38 --> Session: Class initialized using 'files' driver.
INFO - 2019-09-18 03:45:38 --> Controller Class Initialized
INFO - 2019-09-18 03:45:38 --> Final output sent to browser
DEBUG - 2019-09-18 03:45:38 --> Total execution time: 0.2840
INFO - 2019-09-18 03:46:00 --> Config Class Initialized
INFO - 2019-09-18 03:46:00 --> Hooks Class Initialized
DEBUG - 2019-09-18 03:46:00 --> UTF-8 Support Enabled
INFO - 2019-09-18 03:46:00 --> Utf8 Class Initialized
INFO - 2019-09-18 03:46:00 --> URI Class Initialized
DEBUG - 2019-09-18 03:46:00 --> No URI present. Default controller set.
INFO - 2019-09-18 03:46:00 --> Router Class Initialized
INFO - 2019-09-18 03:46:00 --> Output Class Initialized
INFO - 2019-09-18 03:46:00 --> Security Class Initialized
DEBUG - 2019-09-18 03:46:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-09-18 03:46:00 --> Input Class Initialized
INFO - 2019-09-18 03:46:00 --> Language Class Initialized
INFO - 2019-09-18 03:46:00 --> Language Class Initialized
INFO - 2019-09-18 03:46:00 --> Config Class Initialized
INFO - 2019-09-18 03:46:00 --> Loader Class Initialized
INFO - 2019-09-18 03:46:00 --> Helper loaded: url_helper
INFO - 2019-09-18 03:46:00 --> Helper loaded: file_helper
INFO - 2019-09-18 03:46:00 --> Helper loaded: form_helper
INFO - 2019-09-18 03:46:00 --> Helper loaded: my_helper
INFO - 2019-09-18 03:46:00 --> Database Driver Class Initialized
DEBUG - 2019-09-18 03:46:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-09-18 03:46:00 --> Session: Class initialized using 'files' driver.
INFO - 2019-09-18 03:46:00 --> Controller Class Initialized
DEBUG - 2019-09-18 03:46:00 --> File loaded: C:\xampp\htdocs\nilai\application\modules/home/views/v_home.php
DEBUG - 2019-09-18 03:46:00 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2019-09-18 03:46:00 --> Final output sent to browser
DEBUG - 2019-09-18 03:46:00 --> Total execution time: 0.3290
INFO - 2019-09-18 03:46:37 --> Config Class Initialized
INFO - 2019-09-18 03:46:37 --> Hooks Class Initialized
DEBUG - 2019-09-18 03:46:37 --> UTF-8 Support Enabled
INFO - 2019-09-18 03:46:37 --> Utf8 Class Initialized
INFO - 2019-09-18 03:46:37 --> URI Class Initialized
INFO - 2019-09-18 03:46:37 --> Router Class Initialized
INFO - 2019-09-18 03:46:37 --> Output Class Initialized
INFO - 2019-09-18 03:46:37 --> Security Class Initialized
DEBUG - 2019-09-18 03:46:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-09-18 03:46:37 --> Input Class Initialized
INFO - 2019-09-18 03:46:37 --> Language Class Initialized
INFO - 2019-09-18 03:46:37 --> Language Class Initialized
INFO - 2019-09-18 03:46:37 --> Config Class Initialized
INFO - 2019-09-18 03:46:37 --> Loader Class Initialized
INFO - 2019-09-18 03:46:37 --> Helper loaded: url_helper
INFO - 2019-09-18 03:46:37 --> Helper loaded: file_helper
INFO - 2019-09-18 03:46:37 --> Helper loaded: form_helper
INFO - 2019-09-18 03:46:37 --> Helper loaded: my_helper
INFO - 2019-09-18 03:46:37 --> Database Driver Class Initialized
DEBUG - 2019-09-18 03:46:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-09-18 03:46:37 --> Session: Class initialized using 'files' driver.
INFO - 2019-09-18 03:46:37 --> Controller Class Initialized
DEBUG - 2019-09-18 03:46:37 --> File loaded: C:\xampp\htdocs\nilai\application\modules/data_guru/views/list.php
DEBUG - 2019-09-18 03:46:37 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2019-09-18 03:46:37 --> Final output sent to browser
DEBUG - 2019-09-18 03:46:37 --> Total execution time: 0.3210
INFO - 2019-09-18 03:46:37 --> Config Class Initialized
INFO - 2019-09-18 03:46:37 --> Hooks Class Initialized
DEBUG - 2019-09-18 03:46:37 --> UTF-8 Support Enabled
INFO - 2019-09-18 03:46:37 --> Utf8 Class Initialized
INFO - 2019-09-18 03:46:37 --> URI Class Initialized
INFO - 2019-09-18 03:46:37 --> Router Class Initialized
INFO - 2019-09-18 03:46:37 --> Output Class Initialized
INFO - 2019-09-18 03:46:37 --> Security Class Initialized
DEBUG - 2019-09-18 03:46:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-09-18 03:46:37 --> Input Class Initialized
INFO - 2019-09-18 03:46:37 --> Language Class Initialized
INFO - 2019-09-18 03:46:37 --> Language Class Initialized
INFO - 2019-09-18 03:46:37 --> Config Class Initialized
INFO - 2019-09-18 03:46:37 --> Loader Class Initialized
INFO - 2019-09-18 03:46:37 --> Helper loaded: url_helper
INFO - 2019-09-18 03:46:37 --> Helper loaded: file_helper
INFO - 2019-09-18 03:46:37 --> Helper loaded: form_helper
INFO - 2019-09-18 03:46:37 --> Helper loaded: my_helper
INFO - 2019-09-18 03:46:37 --> Database Driver Class Initialized
DEBUG - 2019-09-18 03:46:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-09-18 03:46:37 --> Session: Class initialized using 'files' driver.
INFO - 2019-09-18 03:46:37 --> Controller Class Initialized
INFO - 2019-09-18 03:46:39 --> Config Class Initialized
INFO - 2019-09-18 03:46:39 --> Hooks Class Initialized
DEBUG - 2019-09-18 03:46:39 --> UTF-8 Support Enabled
INFO - 2019-09-18 03:46:39 --> Utf8 Class Initialized
INFO - 2019-09-18 03:46:39 --> URI Class Initialized
INFO - 2019-09-18 03:46:39 --> Router Class Initialized
INFO - 2019-09-18 03:46:39 --> Output Class Initialized
INFO - 2019-09-18 03:46:39 --> Security Class Initialized
DEBUG - 2019-09-18 03:46:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-09-18 03:46:39 --> Input Class Initialized
INFO - 2019-09-18 03:46:39 --> Language Class Initialized
INFO - 2019-09-18 03:46:39 --> Language Class Initialized
INFO - 2019-09-18 03:46:39 --> Config Class Initialized
INFO - 2019-09-18 03:46:39 --> Loader Class Initialized
INFO - 2019-09-18 03:46:39 --> Helper loaded: url_helper
INFO - 2019-09-18 03:46:39 --> Helper loaded: file_helper
INFO - 2019-09-18 03:46:39 --> Helper loaded: form_helper
INFO - 2019-09-18 03:46:39 --> Helper loaded: my_helper
INFO - 2019-09-18 03:46:39 --> Database Driver Class Initialized
DEBUG - 2019-09-18 03:46:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-09-18 03:46:39 --> Session: Class initialized using 'files' driver.
INFO - 2019-09-18 03:46:39 --> Controller Class Initialized
INFO - 2019-09-18 03:46:39 --> Helper loaded: cookie_helper
INFO - 2019-09-18 03:46:39 --> Config Class Initialized
INFO - 2019-09-18 03:46:39 --> Hooks Class Initialized
DEBUG - 2019-09-18 03:46:39 --> UTF-8 Support Enabled
INFO - 2019-09-18 03:46:39 --> Utf8 Class Initialized
INFO - 2019-09-18 03:46:39 --> URI Class Initialized
INFO - 2019-09-18 03:46:39 --> Router Class Initialized
INFO - 2019-09-18 03:46:39 --> Output Class Initialized
INFO - 2019-09-18 03:46:40 --> Security Class Initialized
DEBUG - 2019-09-18 03:46:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-09-18 03:46:40 --> Input Class Initialized
INFO - 2019-09-18 03:46:40 --> Language Class Initialized
INFO - 2019-09-18 03:46:40 --> Language Class Initialized
INFO - 2019-09-18 03:46:40 --> Config Class Initialized
INFO - 2019-09-18 03:46:40 --> Loader Class Initialized
INFO - 2019-09-18 03:46:40 --> Helper loaded: url_helper
INFO - 2019-09-18 03:46:40 --> Helper loaded: file_helper
INFO - 2019-09-18 03:46:40 --> Helper loaded: form_helper
INFO - 2019-09-18 03:46:40 --> Helper loaded: my_helper
INFO - 2019-09-18 03:46:40 --> Database Driver Class Initialized
DEBUG - 2019-09-18 03:46:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-09-18 03:46:40 --> Session: Class initialized using 'files' driver.
INFO - 2019-09-18 03:46:40 --> Controller Class Initialized
DEBUG - 2019-09-18 03:46:40 --> File loaded: C:\xampp\htdocs\nilai\application\modules/home/views/v_home.php
DEBUG - 2019-09-18 03:46:40 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2019-09-18 03:46:40 --> Final output sent to browser
DEBUG - 2019-09-18 03:46:40 --> Total execution time: 0.3020
INFO - 2019-09-18 03:46:42 --> Config Class Initialized
INFO - 2019-09-18 03:46:42 --> Hooks Class Initialized
DEBUG - 2019-09-18 03:46:42 --> UTF-8 Support Enabled
INFO - 2019-09-18 03:46:42 --> Utf8 Class Initialized
INFO - 2019-09-18 03:46:42 --> URI Class Initialized
INFO - 2019-09-18 03:46:42 --> Router Class Initialized
INFO - 2019-09-18 03:46:42 --> Output Class Initialized
INFO - 2019-09-18 03:46:42 --> Security Class Initialized
DEBUG - 2019-09-18 03:46:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-09-18 03:46:42 --> Input Class Initialized
INFO - 2019-09-18 03:46:42 --> Language Class Initialized
INFO - 2019-09-18 03:46:42 --> Language Class Initialized
INFO - 2019-09-18 03:46:42 --> Config Class Initialized
INFO - 2019-09-18 03:46:42 --> Loader Class Initialized
INFO - 2019-09-18 03:46:42 --> Helper loaded: url_helper
INFO - 2019-09-18 03:46:43 --> Helper loaded: file_helper
INFO - 2019-09-18 03:46:43 --> Helper loaded: form_helper
INFO - 2019-09-18 03:46:43 --> Helper loaded: my_helper
INFO - 2019-09-18 03:46:43 --> Database Driver Class Initialized
DEBUG - 2019-09-18 03:46:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-09-18 03:46:43 --> Session: Class initialized using 'files' driver.
INFO - 2019-09-18 03:46:43 --> Controller Class Initialized
INFO - 2019-09-18 03:46:43 --> Helper loaded: cookie_helper
INFO - 2019-09-18 03:46:43 --> Config Class Initialized
INFO - 2019-09-18 03:46:43 --> Hooks Class Initialized
DEBUG - 2019-09-18 03:46:43 --> UTF-8 Support Enabled
INFO - 2019-09-18 03:46:43 --> Utf8 Class Initialized
INFO - 2019-09-18 03:46:43 --> URI Class Initialized
INFO - 2019-09-18 03:46:43 --> Router Class Initialized
INFO - 2019-09-18 03:46:43 --> Output Class Initialized
INFO - 2019-09-18 03:46:43 --> Security Class Initialized
DEBUG - 2019-09-18 03:46:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-09-18 03:46:43 --> Input Class Initialized
INFO - 2019-09-18 03:46:43 --> Language Class Initialized
INFO - 2019-09-18 03:46:43 --> Language Class Initialized
INFO - 2019-09-18 03:46:43 --> Config Class Initialized
INFO - 2019-09-18 03:46:43 --> Loader Class Initialized
INFO - 2019-09-18 03:46:43 --> Helper loaded: url_helper
INFO - 2019-09-18 03:46:43 --> Helper loaded: file_helper
INFO - 2019-09-18 03:46:43 --> Helper loaded: form_helper
INFO - 2019-09-18 03:46:43 --> Helper loaded: my_helper
INFO - 2019-09-18 03:46:43 --> Database Driver Class Initialized
DEBUG - 2019-09-18 03:46:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-09-18 03:46:43 --> Session: Class initialized using 'files' driver.
INFO - 2019-09-18 03:46:43 --> Controller Class Initialized
DEBUG - 2019-09-18 03:46:43 --> File loaded: C:\xampp\htdocs\nilai\application\modules/home/views/v_home.php
DEBUG - 2019-09-18 03:46:43 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2019-09-18 03:46:43 --> Final output sent to browser
DEBUG - 2019-09-18 03:46:43 --> Total execution time: 0.2940
INFO - 2019-09-18 03:46:44 --> Config Class Initialized
INFO - 2019-09-18 03:46:44 --> Hooks Class Initialized
DEBUG - 2019-09-18 03:46:44 --> UTF-8 Support Enabled
INFO - 2019-09-18 03:46:44 --> Utf8 Class Initialized
INFO - 2019-09-18 03:46:44 --> URI Class Initialized
INFO - 2019-09-18 03:46:44 --> Router Class Initialized
INFO - 2019-09-18 03:46:44 --> Output Class Initialized
INFO - 2019-09-18 03:46:44 --> Security Class Initialized
DEBUG - 2019-09-18 03:46:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-09-18 03:46:44 --> Input Class Initialized
INFO - 2019-09-18 03:46:44 --> Language Class Initialized
INFO - 2019-09-18 03:46:44 --> Language Class Initialized
INFO - 2019-09-18 03:46:44 --> Config Class Initialized
INFO - 2019-09-18 03:46:44 --> Loader Class Initialized
INFO - 2019-09-18 03:46:44 --> Helper loaded: url_helper
INFO - 2019-09-18 03:46:44 --> Helper loaded: file_helper
INFO - 2019-09-18 03:46:44 --> Helper loaded: form_helper
INFO - 2019-09-18 03:46:44 --> Helper loaded: my_helper
INFO - 2019-09-18 03:46:44 --> Database Driver Class Initialized
DEBUG - 2019-09-18 03:46:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-09-18 03:46:44 --> Session: Class initialized using 'files' driver.
INFO - 2019-09-18 03:46:44 --> Controller Class Initialized
INFO - 2019-09-18 03:46:44 --> Helper loaded: cookie_helper
INFO - 2019-09-18 03:46:44 --> Config Class Initialized
INFO - 2019-09-18 03:46:44 --> Hooks Class Initialized
DEBUG - 2019-09-18 03:46:44 --> UTF-8 Support Enabled
INFO - 2019-09-18 03:46:44 --> Utf8 Class Initialized
INFO - 2019-09-18 03:46:44 --> URI Class Initialized
INFO - 2019-09-18 03:46:44 --> Router Class Initialized
INFO - 2019-09-18 03:46:44 --> Output Class Initialized
INFO - 2019-09-18 03:46:44 --> Security Class Initialized
DEBUG - 2019-09-18 03:46:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-09-18 03:46:44 --> Input Class Initialized
INFO - 2019-09-18 03:46:44 --> Language Class Initialized
INFO - 2019-09-18 03:46:44 --> Language Class Initialized
INFO - 2019-09-18 03:46:44 --> Config Class Initialized
INFO - 2019-09-18 03:46:44 --> Loader Class Initialized
INFO - 2019-09-18 03:46:44 --> Helper loaded: url_helper
INFO - 2019-09-18 03:46:44 --> Helper loaded: file_helper
INFO - 2019-09-18 03:46:44 --> Helper loaded: form_helper
INFO - 2019-09-18 03:46:44 --> Helper loaded: my_helper
INFO - 2019-09-18 03:46:44 --> Database Driver Class Initialized
DEBUG - 2019-09-18 03:46:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-09-18 03:46:45 --> Session: Class initialized using 'files' driver.
INFO - 2019-09-18 03:46:45 --> Controller Class Initialized
DEBUG - 2019-09-18 03:46:45 --> File loaded: C:\xampp\htdocs\nilai\application\modules/home/views/v_home.php
DEBUG - 2019-09-18 03:46:45 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2019-09-18 03:46:45 --> Final output sent to browser
DEBUG - 2019-09-18 03:46:45 --> Total execution time: 0.2950
INFO - 2019-09-18 03:46:47 --> Config Class Initialized
INFO - 2019-09-18 03:46:47 --> Hooks Class Initialized
DEBUG - 2019-09-18 03:46:47 --> UTF-8 Support Enabled
INFO - 2019-09-18 03:46:47 --> Utf8 Class Initialized
INFO - 2019-09-18 03:46:47 --> URI Class Initialized
DEBUG - 2019-09-18 03:46:47 --> No URI present. Default controller set.
INFO - 2019-09-18 03:46:47 --> Router Class Initialized
INFO - 2019-09-18 03:46:47 --> Output Class Initialized
INFO - 2019-09-18 03:46:47 --> Security Class Initialized
DEBUG - 2019-09-18 03:46:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-09-18 03:46:47 --> Input Class Initialized
INFO - 2019-09-18 03:46:47 --> Language Class Initialized
INFO - 2019-09-18 03:46:47 --> Language Class Initialized
INFO - 2019-09-18 03:46:47 --> Config Class Initialized
INFO - 2019-09-18 03:46:47 --> Loader Class Initialized
INFO - 2019-09-18 03:46:47 --> Helper loaded: url_helper
INFO - 2019-09-18 03:46:47 --> Helper loaded: file_helper
INFO - 2019-09-18 03:46:47 --> Helper loaded: form_helper
INFO - 2019-09-18 03:46:47 --> Helper loaded: my_helper
INFO - 2019-09-18 03:46:47 --> Database Driver Class Initialized
DEBUG - 2019-09-18 03:46:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-09-18 03:46:47 --> Session: Class initialized using 'files' driver.
INFO - 2019-09-18 03:46:47 --> Controller Class Initialized
DEBUG - 2019-09-18 03:46:48 --> File loaded: C:\xampp\htdocs\nilai\application\modules/home/views/v_home.php
DEBUG - 2019-09-18 03:46:48 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2019-09-18 03:46:48 --> Final output sent to browser
DEBUG - 2019-09-18 03:46:48 --> Total execution time: 0.4270
INFO - 2019-09-18 03:46:50 --> Config Class Initialized
INFO - 2019-09-18 03:46:50 --> Hooks Class Initialized
DEBUG - 2019-09-18 03:46:50 --> UTF-8 Support Enabled
INFO - 2019-09-18 03:46:50 --> Utf8 Class Initialized
INFO - 2019-09-18 03:46:50 --> URI Class Initialized
INFO - 2019-09-18 03:46:50 --> Router Class Initialized
INFO - 2019-09-18 03:46:50 --> Output Class Initialized
INFO - 2019-09-18 03:46:50 --> Security Class Initialized
DEBUG - 2019-09-18 03:46:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-09-18 03:46:50 --> Input Class Initialized
INFO - 2019-09-18 03:46:50 --> Language Class Initialized
INFO - 2019-09-18 03:46:50 --> Language Class Initialized
INFO - 2019-09-18 03:46:50 --> Config Class Initialized
INFO - 2019-09-18 03:46:50 --> Loader Class Initialized
INFO - 2019-09-18 03:46:50 --> Helper loaded: url_helper
INFO - 2019-09-18 03:46:50 --> Helper loaded: file_helper
INFO - 2019-09-18 03:46:50 --> Helper loaded: form_helper
INFO - 2019-09-18 03:46:50 --> Helper loaded: my_helper
INFO - 2019-09-18 03:46:50 --> Database Driver Class Initialized
DEBUG - 2019-09-18 03:46:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-09-18 03:46:50 --> Session: Class initialized using 'files' driver.
INFO - 2019-09-18 03:46:50 --> Controller Class Initialized
INFO - 2019-09-18 03:46:50 --> Helper loaded: cookie_helper
INFO - 2019-09-18 03:46:50 --> Config Class Initialized
INFO - 2019-09-18 03:46:50 --> Hooks Class Initialized
DEBUG - 2019-09-18 03:46:50 --> UTF-8 Support Enabled
INFO - 2019-09-18 03:46:50 --> Utf8 Class Initialized
INFO - 2019-09-18 03:46:50 --> URI Class Initialized
INFO - 2019-09-18 03:46:50 --> Router Class Initialized
INFO - 2019-09-18 03:46:50 --> Output Class Initialized
INFO - 2019-09-18 03:46:50 --> Security Class Initialized
DEBUG - 2019-09-18 03:46:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-09-18 03:46:50 --> Input Class Initialized
INFO - 2019-09-18 03:46:50 --> Language Class Initialized
INFO - 2019-09-18 03:46:50 --> Language Class Initialized
INFO - 2019-09-18 03:46:50 --> Config Class Initialized
INFO - 2019-09-18 03:46:50 --> Loader Class Initialized
INFO - 2019-09-18 03:46:50 --> Helper loaded: url_helper
INFO - 2019-09-18 03:46:50 --> Helper loaded: file_helper
INFO - 2019-09-18 03:46:50 --> Helper loaded: form_helper
INFO - 2019-09-18 03:46:50 --> Helper loaded: my_helper
INFO - 2019-09-18 03:46:50 --> Database Driver Class Initialized
DEBUG - 2019-09-18 03:46:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-09-18 03:46:50 --> Session: Class initialized using 'files' driver.
INFO - 2019-09-18 03:46:50 --> Controller Class Initialized
DEBUG - 2019-09-18 03:46:50 --> File loaded: C:\xampp\htdocs\nilai\application\modules/home/views/v_home.php
DEBUG - 2019-09-18 03:46:50 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2019-09-18 03:46:50 --> Final output sent to browser
DEBUG - 2019-09-18 03:46:50 --> Total execution time: 0.2970
INFO - 2019-09-18 03:46:53 --> Config Class Initialized
INFO - 2019-09-18 03:46:53 --> Hooks Class Initialized
DEBUG - 2019-09-18 03:46:53 --> UTF-8 Support Enabled
INFO - 2019-09-18 03:46:53 --> Utf8 Class Initialized
INFO - 2019-09-18 03:46:53 --> URI Class Initialized
DEBUG - 2019-09-18 03:46:53 --> No URI present. Default controller set.
INFO - 2019-09-18 03:46:53 --> Router Class Initialized
INFO - 2019-09-18 03:46:53 --> Output Class Initialized
INFO - 2019-09-18 03:46:53 --> Security Class Initialized
DEBUG - 2019-09-18 03:46:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-09-18 03:46:53 --> Input Class Initialized
INFO - 2019-09-18 03:46:53 --> Language Class Initialized
INFO - 2019-09-18 03:46:53 --> Language Class Initialized
INFO - 2019-09-18 03:46:53 --> Config Class Initialized
INFO - 2019-09-18 03:46:53 --> Loader Class Initialized
INFO - 2019-09-18 03:46:53 --> Helper loaded: url_helper
INFO - 2019-09-18 03:46:53 --> Helper loaded: file_helper
INFO - 2019-09-18 03:46:53 --> Helper loaded: form_helper
INFO - 2019-09-18 03:46:53 --> Helper loaded: my_helper
INFO - 2019-09-18 03:46:53 --> Database Driver Class Initialized
DEBUG - 2019-09-18 03:46:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-09-18 03:46:53 --> Session: Class initialized using 'files' driver.
INFO - 2019-09-18 03:46:53 --> Controller Class Initialized
DEBUG - 2019-09-18 03:46:53 --> File loaded: C:\xampp\htdocs\nilai\application\modules/home/views/v_home.php
DEBUG - 2019-09-18 03:46:53 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2019-09-18 03:46:53 --> Final output sent to browser
DEBUG - 2019-09-18 03:46:53 --> Total execution time: 0.3330
INFO - 2019-09-18 03:46:59 --> Config Class Initialized
INFO - 2019-09-18 03:46:59 --> Hooks Class Initialized
DEBUG - 2019-09-18 03:46:59 --> UTF-8 Support Enabled
INFO - 2019-09-18 03:46:59 --> Utf8 Class Initialized
INFO - 2019-09-18 03:46:59 --> URI Class Initialized
DEBUG - 2019-09-18 03:46:59 --> No URI present. Default controller set.
INFO - 2019-09-18 03:46:59 --> Router Class Initialized
INFO - 2019-09-18 03:46:59 --> Output Class Initialized
INFO - 2019-09-18 03:46:59 --> Security Class Initialized
DEBUG - 2019-09-18 03:46:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-09-18 03:46:59 --> Input Class Initialized
INFO - 2019-09-18 03:46:59 --> Language Class Initialized
INFO - 2019-09-18 03:46:59 --> Language Class Initialized
INFO - 2019-09-18 03:46:59 --> Config Class Initialized
INFO - 2019-09-18 03:46:59 --> Loader Class Initialized
INFO - 2019-09-18 03:46:59 --> Helper loaded: url_helper
INFO - 2019-09-18 03:46:59 --> Helper loaded: file_helper
INFO - 2019-09-18 03:46:59 --> Helper loaded: form_helper
INFO - 2019-09-18 03:46:59 --> Helper loaded: my_helper
INFO - 2019-09-18 03:46:59 --> Database Driver Class Initialized
DEBUG - 2019-09-18 03:46:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-09-18 03:46:59 --> Session: Class initialized using 'files' driver.
INFO - 2019-09-18 03:46:59 --> Controller Class Initialized
DEBUG - 2019-09-18 03:46:59 --> File loaded: C:\xampp\htdocs\nilai\application\modules/home/views/v_home.php
DEBUG - 2019-09-18 03:46:59 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2019-09-18 03:46:59 --> Final output sent to browser
DEBUG - 2019-09-18 03:46:59 --> Total execution time: 0.3480
INFO - 2019-09-18 03:47:04 --> Config Class Initialized
INFO - 2019-09-18 03:47:04 --> Hooks Class Initialized
DEBUG - 2019-09-18 03:47:04 --> UTF-8 Support Enabled
INFO - 2019-09-18 03:47:04 --> Utf8 Class Initialized
INFO - 2019-09-18 03:47:04 --> URI Class Initialized
INFO - 2019-09-18 03:47:04 --> Router Class Initialized
INFO - 2019-09-18 03:47:04 --> Output Class Initialized
INFO - 2019-09-18 03:47:04 --> Security Class Initialized
DEBUG - 2019-09-18 03:47:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-09-18 03:47:04 --> Input Class Initialized
INFO - 2019-09-18 03:47:04 --> Language Class Initialized
INFO - 2019-09-18 03:47:04 --> Language Class Initialized
INFO - 2019-09-18 03:47:04 --> Config Class Initialized
INFO - 2019-09-18 03:47:04 --> Loader Class Initialized
INFO - 2019-09-18 03:47:04 --> Helper loaded: url_helper
INFO - 2019-09-18 03:47:04 --> Helper loaded: file_helper
INFO - 2019-09-18 03:47:04 --> Helper loaded: form_helper
INFO - 2019-09-18 03:47:04 --> Helper loaded: my_helper
INFO - 2019-09-18 03:47:04 --> Database Driver Class Initialized
DEBUG - 2019-09-18 03:47:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-09-18 03:47:04 --> Session: Class initialized using 'files' driver.
INFO - 2019-09-18 03:47:04 --> Controller Class Initialized
INFO - 2019-09-18 03:47:04 --> Helper loaded: cookie_helper
INFO - 2019-09-18 03:47:04 --> Config Class Initialized
INFO - 2019-09-18 03:47:04 --> Hooks Class Initialized
DEBUG - 2019-09-18 03:47:04 --> UTF-8 Support Enabled
INFO - 2019-09-18 03:47:04 --> Utf8 Class Initialized
INFO - 2019-09-18 03:47:04 --> URI Class Initialized
INFO - 2019-09-18 03:47:04 --> Router Class Initialized
INFO - 2019-09-18 03:47:04 --> Output Class Initialized
INFO - 2019-09-18 03:47:04 --> Security Class Initialized
DEBUG - 2019-09-18 03:47:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-09-18 03:47:04 --> Input Class Initialized
INFO - 2019-09-18 03:47:04 --> Language Class Initialized
INFO - 2019-09-18 03:47:04 --> Language Class Initialized
INFO - 2019-09-18 03:47:04 --> Config Class Initialized
INFO - 2019-09-18 03:47:04 --> Loader Class Initialized
INFO - 2019-09-18 03:47:05 --> Helper loaded: url_helper
INFO - 2019-09-18 03:47:05 --> Helper loaded: file_helper
INFO - 2019-09-18 03:47:05 --> Helper loaded: form_helper
INFO - 2019-09-18 03:47:05 --> Helper loaded: my_helper
INFO - 2019-09-18 03:47:05 --> Database Driver Class Initialized
DEBUG - 2019-09-18 03:47:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-09-18 03:47:05 --> Session: Class initialized using 'files' driver.
INFO - 2019-09-18 03:47:05 --> Controller Class Initialized
DEBUG - 2019-09-18 03:47:05 --> File loaded: C:\xampp\htdocs\nilai\application\modules/home/views/v_home.php
DEBUG - 2019-09-18 03:47:05 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2019-09-18 03:47:05 --> Final output sent to browser
DEBUG - 2019-09-18 03:47:05 --> Total execution time: 0.3130
INFO - 2019-09-18 03:47:16 --> Config Class Initialized
INFO - 2019-09-18 03:47:16 --> Hooks Class Initialized
DEBUG - 2019-09-18 03:47:16 --> UTF-8 Support Enabled
INFO - 2019-09-18 03:47:16 --> Utf8 Class Initialized
INFO - 2019-09-18 03:47:16 --> URI Class Initialized
INFO - 2019-09-18 03:47:16 --> Router Class Initialized
INFO - 2019-09-18 03:47:16 --> Output Class Initialized
INFO - 2019-09-18 03:47:16 --> Security Class Initialized
DEBUG - 2019-09-18 03:47:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-09-18 03:47:16 --> Input Class Initialized
INFO - 2019-09-18 03:47:16 --> Language Class Initialized
INFO - 2019-09-18 03:47:16 --> Language Class Initialized
INFO - 2019-09-18 03:47:16 --> Config Class Initialized
INFO - 2019-09-18 03:47:16 --> Loader Class Initialized
INFO - 2019-09-18 03:47:16 --> Helper loaded: url_helper
INFO - 2019-09-18 03:47:16 --> Helper loaded: file_helper
INFO - 2019-09-18 03:47:16 --> Helper loaded: form_helper
INFO - 2019-09-18 03:47:16 --> Helper loaded: my_helper
INFO - 2019-09-18 03:47:16 --> Database Driver Class Initialized
DEBUG - 2019-09-18 03:47:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-09-18 03:47:16 --> Session: Class initialized using 'files' driver.
INFO - 2019-09-18 03:47:16 --> Controller Class Initialized
INFO - 2019-09-18 03:47:16 --> Config Class Initialized
INFO - 2019-09-18 03:47:16 --> Hooks Class Initialized
DEBUG - 2019-09-18 03:47:16 --> UTF-8 Support Enabled
INFO - 2019-09-18 03:47:16 --> Utf8 Class Initialized
INFO - 2019-09-18 03:47:16 --> URI Class Initialized
INFO - 2019-09-18 03:47:16 --> Router Class Initialized
INFO - 2019-09-18 03:47:16 --> Output Class Initialized
INFO - 2019-09-18 03:47:16 --> Security Class Initialized
DEBUG - 2019-09-18 03:47:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-09-18 03:47:16 --> Input Class Initialized
INFO - 2019-09-18 03:47:16 --> Language Class Initialized
INFO - 2019-09-18 03:47:17 --> Language Class Initialized
INFO - 2019-09-18 03:47:17 --> Config Class Initialized
INFO - 2019-09-18 03:47:17 --> Loader Class Initialized
INFO - 2019-09-18 03:47:17 --> Helper loaded: url_helper
INFO - 2019-09-18 03:47:17 --> Helper loaded: file_helper
INFO - 2019-09-18 03:47:17 --> Helper loaded: form_helper
INFO - 2019-09-18 03:47:17 --> Helper loaded: my_helper
INFO - 2019-09-18 03:47:17 --> Database Driver Class Initialized
DEBUG - 2019-09-18 03:47:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-09-18 03:47:17 --> Session: Class initialized using 'files' driver.
INFO - 2019-09-18 03:47:17 --> Controller Class Initialized
DEBUG - 2019-09-18 03:47:17 --> File loaded: C:\xampp\htdocs\nilai\application\modules/login/views/login.php
DEBUG - 2019-09-18 03:47:17 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2019-09-18 03:47:17 --> Final output sent to browser
DEBUG - 2019-09-18 03:47:17 --> Total execution time: 0.3140
INFO - 2019-09-18 03:47:36 --> Config Class Initialized
INFO - 2019-09-18 03:47:36 --> Hooks Class Initialized
DEBUG - 2019-09-18 03:47:36 --> UTF-8 Support Enabled
INFO - 2019-09-18 03:47:36 --> Utf8 Class Initialized
INFO - 2019-09-18 03:47:36 --> URI Class Initialized
INFO - 2019-09-18 03:47:36 --> Router Class Initialized
INFO - 2019-09-18 03:47:36 --> Output Class Initialized
INFO - 2019-09-18 03:47:36 --> Security Class Initialized
DEBUG - 2019-09-18 03:47:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-09-18 03:47:37 --> Input Class Initialized
INFO - 2019-09-18 03:47:37 --> Language Class Initialized
INFO - 2019-09-18 03:47:37 --> Language Class Initialized
INFO - 2019-09-18 03:47:37 --> Config Class Initialized
INFO - 2019-09-18 03:47:37 --> Loader Class Initialized
INFO - 2019-09-18 03:47:37 --> Helper loaded: url_helper
INFO - 2019-09-18 03:47:37 --> Helper loaded: file_helper
INFO - 2019-09-18 03:47:37 --> Helper loaded: form_helper
INFO - 2019-09-18 03:47:37 --> Helper loaded: my_helper
INFO - 2019-09-18 03:47:37 --> Database Driver Class Initialized
DEBUG - 2019-09-18 03:47:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-09-18 03:47:37 --> Session: Class initialized using 'files' driver.
INFO - 2019-09-18 03:47:37 --> Controller Class Initialized
INFO - 2019-09-18 03:47:37 --> Helper loaded: cookie_helper
INFO - 2019-09-18 03:47:37 --> Final output sent to browser
DEBUG - 2019-09-18 03:47:37 --> Total execution time: 0.3450
INFO - 2019-09-18 03:47:39 --> Config Class Initialized
INFO - 2019-09-18 03:47:39 --> Hooks Class Initialized
DEBUG - 2019-09-18 03:47:39 --> UTF-8 Support Enabled
INFO - 2019-09-18 03:47:39 --> Utf8 Class Initialized
INFO - 2019-09-18 03:47:39 --> URI Class Initialized
INFO - 2019-09-18 03:47:39 --> Router Class Initialized
INFO - 2019-09-18 03:47:39 --> Output Class Initialized
INFO - 2019-09-18 03:47:39 --> Security Class Initialized
DEBUG - 2019-09-18 03:47:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-09-18 03:47:39 --> Input Class Initialized
INFO - 2019-09-18 03:47:39 --> Language Class Initialized
INFO - 2019-09-18 03:47:39 --> Language Class Initialized
INFO - 2019-09-18 03:47:39 --> Config Class Initialized
INFO - 2019-09-18 03:47:39 --> Loader Class Initialized
INFO - 2019-09-18 03:47:39 --> Helper loaded: url_helper
INFO - 2019-09-18 03:47:39 --> Helper loaded: file_helper
INFO - 2019-09-18 03:47:39 --> Helper loaded: form_helper
INFO - 2019-09-18 03:47:39 --> Helper loaded: my_helper
INFO - 2019-09-18 03:47:39 --> Database Driver Class Initialized
DEBUG - 2019-09-18 03:47:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-09-18 03:47:39 --> Session: Class initialized using 'files' driver.
INFO - 2019-09-18 03:47:39 --> Controller Class Initialized
DEBUG - 2019-09-18 03:47:39 --> File loaded: C:\xampp\htdocs\nilai\application\modules/home/views/v_home.php
DEBUG - 2019-09-18 03:47:39 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2019-09-18 03:47:39 --> Final output sent to browser
DEBUG - 2019-09-18 03:47:39 --> Total execution time: 0.4200
INFO - 2019-09-18 03:47:46 --> Config Class Initialized
INFO - 2019-09-18 03:47:46 --> Hooks Class Initialized
DEBUG - 2019-09-18 03:47:46 --> UTF-8 Support Enabled
INFO - 2019-09-18 03:47:46 --> Utf8 Class Initialized
INFO - 2019-09-18 03:47:46 --> URI Class Initialized
INFO - 2019-09-18 03:47:46 --> Router Class Initialized
INFO - 2019-09-18 03:47:46 --> Output Class Initialized
INFO - 2019-09-18 03:47:46 --> Security Class Initialized
DEBUG - 2019-09-18 03:47:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-09-18 03:47:46 --> Input Class Initialized
INFO - 2019-09-18 03:47:46 --> Language Class Initialized
INFO - 2019-09-18 03:47:46 --> Language Class Initialized
INFO - 2019-09-18 03:47:46 --> Config Class Initialized
INFO - 2019-09-18 03:47:46 --> Loader Class Initialized
INFO - 2019-09-18 03:47:46 --> Helper loaded: url_helper
INFO - 2019-09-18 03:47:46 --> Helper loaded: file_helper
INFO - 2019-09-18 03:47:46 --> Helper loaded: form_helper
INFO - 2019-09-18 03:47:46 --> Helper loaded: my_helper
INFO - 2019-09-18 03:47:46 --> Database Driver Class Initialized
DEBUG - 2019-09-18 03:47:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-09-18 03:47:46 --> Session: Class initialized using 'files' driver.
INFO - 2019-09-18 03:47:46 --> Controller Class Initialized
DEBUG - 2019-09-18 03:47:46 --> File loaded: C:\xampp\htdocs\nilai\application\modules/view_mapel/views/v_view_mapel.php
DEBUG - 2019-09-18 03:47:46 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2019-09-18 03:47:46 --> Final output sent to browser
DEBUG - 2019-09-18 03:47:46 --> Total execution time: 0.3530
INFO - 2019-09-18 03:47:47 --> Config Class Initialized
INFO - 2019-09-18 03:47:47 --> Hooks Class Initialized
DEBUG - 2019-09-18 03:47:47 --> UTF-8 Support Enabled
INFO - 2019-09-18 03:47:47 --> Utf8 Class Initialized
INFO - 2019-09-18 03:47:47 --> URI Class Initialized
INFO - 2019-09-18 03:47:47 --> Router Class Initialized
INFO - 2019-09-18 03:47:47 --> Output Class Initialized
INFO - 2019-09-18 03:47:47 --> Security Class Initialized
DEBUG - 2019-09-18 03:47:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-09-18 03:47:47 --> Input Class Initialized
INFO - 2019-09-18 03:47:47 --> Language Class Initialized
INFO - 2019-09-18 03:47:47 --> Language Class Initialized
INFO - 2019-09-18 03:47:47 --> Config Class Initialized
INFO - 2019-09-18 03:47:47 --> Loader Class Initialized
INFO - 2019-09-18 03:47:47 --> Helper loaded: url_helper
INFO - 2019-09-18 03:47:47 --> Helper loaded: file_helper
INFO - 2019-09-18 03:47:47 --> Helper loaded: form_helper
INFO - 2019-09-18 03:47:47 --> Helper loaded: my_helper
INFO - 2019-09-18 03:47:47 --> Database Driver Class Initialized
DEBUG - 2019-09-18 03:47:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-09-18 03:47:47 --> Session: Class initialized using 'files' driver.
INFO - 2019-09-18 03:47:47 --> Controller Class Initialized
DEBUG - 2019-09-18 03:47:47 --> File loaded: C:\xampp\htdocs\nilai\application\modules/riwayat_mengajar/views/list.php
DEBUG - 2019-09-18 03:47:47 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2019-09-18 03:47:47 --> Final output sent to browser
DEBUG - 2019-09-18 03:47:47 --> Total execution time: 0.4620
INFO - 2019-09-18 03:47:48 --> Config Class Initialized
INFO - 2019-09-18 03:47:48 --> Hooks Class Initialized
DEBUG - 2019-09-18 03:47:48 --> UTF-8 Support Enabled
INFO - 2019-09-18 03:47:48 --> Utf8 Class Initialized
INFO - 2019-09-18 03:47:48 --> URI Class Initialized
INFO - 2019-09-18 03:47:48 --> Router Class Initialized
INFO - 2019-09-18 03:47:48 --> Output Class Initialized
INFO - 2019-09-18 03:47:48 --> Security Class Initialized
DEBUG - 2019-09-18 03:47:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-09-18 03:47:48 --> Input Class Initialized
INFO - 2019-09-18 03:47:48 --> Language Class Initialized
INFO - 2019-09-18 03:47:48 --> Language Class Initialized
INFO - 2019-09-18 03:47:48 --> Config Class Initialized
INFO - 2019-09-18 03:47:48 --> Loader Class Initialized
INFO - 2019-09-18 03:47:48 --> Helper loaded: url_helper
INFO - 2019-09-18 03:47:48 --> Helper loaded: file_helper
INFO - 2019-09-18 03:47:48 --> Helper loaded: form_helper
INFO - 2019-09-18 03:47:48 --> Helper loaded: my_helper
INFO - 2019-09-18 03:47:48 --> Database Driver Class Initialized
DEBUG - 2019-09-18 03:47:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-09-18 03:47:48 --> Session: Class initialized using 'files' driver.
INFO - 2019-09-18 03:47:48 --> Controller Class Initialized
DEBUG - 2019-09-18 03:47:48 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_sikap_so/views/list.php
DEBUG - 2019-09-18 03:47:48 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2019-09-18 03:47:48 --> Final output sent to browser
DEBUG - 2019-09-18 03:47:48 --> Total execution time: 0.3780
INFO - 2019-09-18 03:47:50 --> Config Class Initialized
INFO - 2019-09-18 03:47:50 --> Hooks Class Initialized
DEBUG - 2019-09-18 03:47:50 --> UTF-8 Support Enabled
INFO - 2019-09-18 03:47:50 --> Utf8 Class Initialized
INFO - 2019-09-18 03:47:50 --> URI Class Initialized
INFO - 2019-09-18 03:47:50 --> Router Class Initialized
INFO - 2019-09-18 03:47:50 --> Output Class Initialized
INFO - 2019-09-18 03:47:50 --> Security Class Initialized
DEBUG - 2019-09-18 03:47:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-09-18 03:47:50 --> Input Class Initialized
INFO - 2019-09-18 03:47:50 --> Language Class Initialized
INFO - 2019-09-18 03:47:50 --> Language Class Initialized
INFO - 2019-09-18 03:47:50 --> Config Class Initialized
INFO - 2019-09-18 03:47:50 --> Loader Class Initialized
INFO - 2019-09-18 03:47:50 --> Helper loaded: url_helper
INFO - 2019-09-18 03:47:50 --> Helper loaded: file_helper
INFO - 2019-09-18 03:47:50 --> Helper loaded: form_helper
INFO - 2019-09-18 03:47:50 --> Helper loaded: my_helper
INFO - 2019-09-18 03:47:50 --> Database Driver Class Initialized
DEBUG - 2019-09-18 03:47:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-09-18 03:47:50 --> Session: Class initialized using 'files' driver.
INFO - 2019-09-18 03:47:50 --> Controller Class Initialized
DEBUG - 2019-09-18 03:47:50 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_sikap_sp/views/list.php
DEBUG - 2019-09-18 03:47:50 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2019-09-18 03:47:50 --> Final output sent to browser
DEBUG - 2019-09-18 03:47:50 --> Total execution time: 0.3640
INFO - 2019-09-18 03:47:54 --> Config Class Initialized
INFO - 2019-09-18 03:47:54 --> Hooks Class Initialized
DEBUG - 2019-09-18 03:47:54 --> UTF-8 Support Enabled
INFO - 2019-09-18 03:47:54 --> Utf8 Class Initialized
INFO - 2019-09-18 03:47:54 --> URI Class Initialized
INFO - 2019-09-18 03:47:54 --> Router Class Initialized
INFO - 2019-09-18 03:47:54 --> Output Class Initialized
INFO - 2019-09-18 03:47:54 --> Security Class Initialized
DEBUG - 2019-09-18 03:47:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-09-18 03:47:54 --> Input Class Initialized
INFO - 2019-09-18 03:47:54 --> Language Class Initialized
INFO - 2019-09-18 03:47:54 --> Language Class Initialized
INFO - 2019-09-18 03:47:54 --> Config Class Initialized
INFO - 2019-09-18 03:47:54 --> Loader Class Initialized
INFO - 2019-09-18 03:47:54 --> Helper loaded: url_helper
INFO - 2019-09-18 03:47:54 --> Helper loaded: file_helper
INFO - 2019-09-18 03:47:54 --> Helper loaded: form_helper
INFO - 2019-09-18 03:47:54 --> Helper loaded: my_helper
INFO - 2019-09-18 03:47:54 --> Database Driver Class Initialized
DEBUG - 2019-09-18 03:47:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-09-18 03:47:54 --> Session: Class initialized using 'files' driver.
INFO - 2019-09-18 03:47:54 --> Controller Class Initialized
DEBUG - 2019-09-18 03:47:54 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_absensi/views/list.php
DEBUG - 2019-09-18 03:47:54 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2019-09-18 03:47:54 --> Final output sent to browser
DEBUG - 2019-09-18 03:47:54 --> Total execution time: 0.4920
INFO - 2019-09-18 03:47:56 --> Config Class Initialized
INFO - 2019-09-18 03:47:56 --> Hooks Class Initialized
DEBUG - 2019-09-18 03:47:56 --> UTF-8 Support Enabled
INFO - 2019-09-18 03:47:56 --> Utf8 Class Initialized
INFO - 2019-09-18 03:47:56 --> URI Class Initialized
INFO - 2019-09-18 03:47:56 --> Router Class Initialized
INFO - 2019-09-18 03:47:56 --> Output Class Initialized
INFO - 2019-09-18 03:47:56 --> Security Class Initialized
DEBUG - 2019-09-18 03:47:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-09-18 03:47:56 --> Input Class Initialized
INFO - 2019-09-18 03:47:56 --> Language Class Initialized
INFO - 2019-09-18 03:47:56 --> Language Class Initialized
INFO - 2019-09-18 03:47:56 --> Config Class Initialized
INFO - 2019-09-18 03:47:56 --> Loader Class Initialized
INFO - 2019-09-18 03:47:56 --> Helper loaded: url_helper
INFO - 2019-09-18 03:47:56 --> Helper loaded: file_helper
INFO - 2019-09-18 03:47:56 --> Helper loaded: form_helper
INFO - 2019-09-18 03:47:56 --> Helper loaded: my_helper
INFO - 2019-09-18 03:47:56 --> Database Driver Class Initialized
DEBUG - 2019-09-18 03:47:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-09-18 03:47:56 --> Session: Class initialized using 'files' driver.
INFO - 2019-09-18 03:47:56 --> Controller Class Initialized
DEBUG - 2019-09-18 03:47:56 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_prestasi/views/list.php
DEBUG - 2019-09-18 03:47:56 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2019-09-18 03:47:56 --> Final output sent to browser
DEBUG - 2019-09-18 03:47:56 --> Total execution time: 0.3720
INFO - 2019-09-18 03:47:56 --> Config Class Initialized
INFO - 2019-09-18 03:47:56 --> Hooks Class Initialized
DEBUG - 2019-09-18 03:47:56 --> UTF-8 Support Enabled
INFO - 2019-09-18 03:47:56 --> Utf8 Class Initialized
INFO - 2019-09-18 03:47:56 --> URI Class Initialized
INFO - 2019-09-18 03:47:56 --> Router Class Initialized
INFO - 2019-09-18 03:47:56 --> Output Class Initialized
INFO - 2019-09-18 03:47:56 --> Security Class Initialized
DEBUG - 2019-09-18 03:47:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-09-18 03:47:56 --> Input Class Initialized
INFO - 2019-09-18 03:47:56 --> Language Class Initialized
INFO - 2019-09-18 03:47:56 --> Language Class Initialized
INFO - 2019-09-18 03:47:56 --> Config Class Initialized
INFO - 2019-09-18 03:47:56 --> Loader Class Initialized
INFO - 2019-09-18 03:47:56 --> Helper loaded: url_helper
INFO - 2019-09-18 03:47:56 --> Helper loaded: file_helper
INFO - 2019-09-18 03:47:56 --> Helper loaded: form_helper
INFO - 2019-09-18 03:47:56 --> Helper loaded: my_helper
INFO - 2019-09-18 03:47:56 --> Database Driver Class Initialized
DEBUG - 2019-09-18 03:47:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-09-18 03:47:56 --> Session: Class initialized using 'files' driver.
INFO - 2019-09-18 03:47:56 --> Controller Class Initialized
INFO - 2019-09-18 03:47:58 --> Config Class Initialized
INFO - 2019-09-18 03:47:58 --> Hooks Class Initialized
DEBUG - 2019-09-18 03:47:58 --> UTF-8 Support Enabled
INFO - 2019-09-18 03:47:58 --> Utf8 Class Initialized
INFO - 2019-09-18 03:47:58 --> URI Class Initialized
INFO - 2019-09-18 03:47:58 --> Router Class Initialized
INFO - 2019-09-18 03:47:58 --> Output Class Initialized
INFO - 2019-09-18 03:47:58 --> Security Class Initialized
DEBUG - 2019-09-18 03:47:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-09-18 03:47:58 --> Input Class Initialized
INFO - 2019-09-18 03:47:58 --> Language Class Initialized
INFO - 2019-09-18 03:47:58 --> Language Class Initialized
INFO - 2019-09-18 03:47:58 --> Config Class Initialized
INFO - 2019-09-18 03:47:58 --> Loader Class Initialized
INFO - 2019-09-18 03:47:58 --> Helper loaded: url_helper
INFO - 2019-09-18 03:47:58 --> Helper loaded: file_helper
INFO - 2019-09-18 03:47:58 --> Helper loaded: form_helper
INFO - 2019-09-18 03:47:58 --> Helper loaded: my_helper
INFO - 2019-09-18 03:47:58 --> Database Driver Class Initialized
DEBUG - 2019-09-18 03:47:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-09-18 03:47:58 --> Session: Class initialized using 'files' driver.
INFO - 2019-09-18 03:47:58 --> Controller Class Initialized
DEBUG - 2019-09-18 03:47:58 --> File loaded: C:\xampp\htdocs\nilai\application\modules/view_mapel/views/v_view_mapel.php
DEBUG - 2019-09-18 03:47:58 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2019-09-18 03:47:58 --> Final output sent to browser
DEBUG - 2019-09-18 03:47:58 --> Total execution time: 0.3500
INFO - 2019-09-18 03:47:59 --> Config Class Initialized
INFO - 2019-09-18 03:47:59 --> Hooks Class Initialized
DEBUG - 2019-09-18 03:47:59 --> UTF-8 Support Enabled
INFO - 2019-09-18 03:47:59 --> Utf8 Class Initialized
INFO - 2019-09-18 03:47:59 --> URI Class Initialized
DEBUG - 2019-09-18 03:47:59 --> No URI present. Default controller set.
INFO - 2019-09-18 03:47:59 --> Router Class Initialized
INFO - 2019-09-18 03:47:59 --> Output Class Initialized
INFO - 2019-09-18 03:47:59 --> Security Class Initialized
DEBUG - 2019-09-18 03:47:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-09-18 03:47:59 --> Input Class Initialized
INFO - 2019-09-18 03:47:59 --> Language Class Initialized
INFO - 2019-09-18 03:47:59 --> Language Class Initialized
INFO - 2019-09-18 03:47:59 --> Config Class Initialized
INFO - 2019-09-18 03:47:59 --> Loader Class Initialized
INFO - 2019-09-18 03:47:59 --> Helper loaded: url_helper
INFO - 2019-09-18 03:47:59 --> Helper loaded: file_helper
INFO - 2019-09-18 03:47:59 --> Helper loaded: form_helper
INFO - 2019-09-18 03:47:59 --> Helper loaded: my_helper
INFO - 2019-09-18 03:47:59 --> Database Driver Class Initialized
DEBUG - 2019-09-18 03:47:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-09-18 03:47:59 --> Session: Class initialized using 'files' driver.
INFO - 2019-09-18 03:47:59 --> Controller Class Initialized
DEBUG - 2019-09-18 03:47:59 --> File loaded: C:\xampp\htdocs\nilai\application\modules/home/views/v_home.php
DEBUG - 2019-09-18 03:47:59 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2019-09-18 03:47:59 --> Final output sent to browser
DEBUG - 2019-09-18 03:47:59 --> Total execution time: 0.3380
INFO - 2019-09-18 03:48:00 --> Config Class Initialized
INFO - 2019-09-18 03:48:00 --> Hooks Class Initialized
DEBUG - 2019-09-18 03:48:00 --> UTF-8 Support Enabled
INFO - 2019-09-18 03:48:00 --> Utf8 Class Initialized
INFO - 2019-09-18 03:48:00 --> URI Class Initialized
INFO - 2019-09-18 03:48:00 --> Router Class Initialized
INFO - 2019-09-18 03:48:00 --> Output Class Initialized
INFO - 2019-09-18 03:48:00 --> Security Class Initialized
DEBUG - 2019-09-18 03:48:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-09-18 03:48:00 --> Input Class Initialized
INFO - 2019-09-18 03:48:00 --> Language Class Initialized
INFO - 2019-09-18 03:48:00 --> Language Class Initialized
INFO - 2019-09-18 03:48:00 --> Config Class Initialized
INFO - 2019-09-18 03:48:00 --> Loader Class Initialized
INFO - 2019-09-18 03:48:00 --> Helper loaded: url_helper
INFO - 2019-09-18 03:48:00 --> Helper loaded: file_helper
INFO - 2019-09-18 03:48:00 --> Helper loaded: form_helper
INFO - 2019-09-18 03:48:00 --> Helper loaded: my_helper
INFO - 2019-09-18 03:48:00 --> Database Driver Class Initialized
DEBUG - 2019-09-18 03:48:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-09-18 03:48:00 --> Session: Class initialized using 'files' driver.
INFO - 2019-09-18 03:48:00 --> Controller Class Initialized
DEBUG - 2019-09-18 03:48:00 --> File loaded: C:\xampp\htdocs\nilai\application\modules/view_mapel/views/v_view_mapel.php
DEBUG - 2019-09-18 03:48:00 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2019-09-18 03:48:00 --> Final output sent to browser
DEBUG - 2019-09-18 03:48:00 --> Total execution time: 0.3280
INFO - 2019-09-18 03:48:03 --> Config Class Initialized
INFO - 2019-09-18 03:48:03 --> Hooks Class Initialized
DEBUG - 2019-09-18 03:48:03 --> UTF-8 Support Enabled
INFO - 2019-09-18 03:48:03 --> Utf8 Class Initialized
INFO - 2019-09-18 03:48:03 --> URI Class Initialized
INFO - 2019-09-18 03:48:03 --> Router Class Initialized
INFO - 2019-09-18 03:48:03 --> Output Class Initialized
INFO - 2019-09-18 03:48:04 --> Security Class Initialized
DEBUG - 2019-09-18 03:48:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-09-18 03:48:04 --> Input Class Initialized
INFO - 2019-09-18 03:48:04 --> Language Class Initialized
INFO - 2019-09-18 03:48:04 --> Language Class Initialized
INFO - 2019-09-18 03:48:04 --> Config Class Initialized
INFO - 2019-09-18 03:48:04 --> Loader Class Initialized
INFO - 2019-09-18 03:48:04 --> Helper loaded: url_helper
INFO - 2019-09-18 03:48:04 --> Helper loaded: file_helper
INFO - 2019-09-18 03:48:04 --> Helper loaded: form_helper
INFO - 2019-09-18 03:48:04 --> Helper loaded: my_helper
INFO - 2019-09-18 03:48:04 --> Database Driver Class Initialized
DEBUG - 2019-09-18 03:48:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-09-18 03:48:04 --> Session: Class initialized using 'files' driver.
INFO - 2019-09-18 03:48:04 --> Controller Class Initialized
DEBUG - 2019-09-18 03:48:04 --> File loaded: C:\xampp\htdocs\nilai\application\modules/riwayat_mengajar/views/list.php
DEBUG - 2019-09-18 03:48:04 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2019-09-18 03:48:04 --> Final output sent to browser
DEBUG - 2019-09-18 03:48:04 --> Total execution time: 0.3260
INFO - 2019-09-18 03:48:05 --> Config Class Initialized
INFO - 2019-09-18 03:48:05 --> Hooks Class Initialized
DEBUG - 2019-09-18 03:48:05 --> UTF-8 Support Enabled
INFO - 2019-09-18 03:48:05 --> Utf8 Class Initialized
INFO - 2019-09-18 03:48:05 --> URI Class Initialized
DEBUG - 2019-09-18 03:48:05 --> No URI present. Default controller set.
INFO - 2019-09-18 03:48:05 --> Router Class Initialized
INFO - 2019-09-18 03:48:05 --> Output Class Initialized
INFO - 2019-09-18 03:48:05 --> Security Class Initialized
DEBUG - 2019-09-18 03:48:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-09-18 03:48:05 --> Input Class Initialized
INFO - 2019-09-18 03:48:05 --> Language Class Initialized
INFO - 2019-09-18 03:48:05 --> Language Class Initialized
INFO - 2019-09-18 03:48:05 --> Config Class Initialized
INFO - 2019-09-18 03:48:05 --> Loader Class Initialized
INFO - 2019-09-18 03:48:05 --> Helper loaded: url_helper
INFO - 2019-09-18 03:48:05 --> Helper loaded: file_helper
INFO - 2019-09-18 03:48:05 --> Helper loaded: form_helper
INFO - 2019-09-18 03:48:05 --> Helper loaded: my_helper
INFO - 2019-09-18 03:48:05 --> Database Driver Class Initialized
DEBUG - 2019-09-18 03:48:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-09-18 03:48:05 --> Session: Class initialized using 'files' driver.
INFO - 2019-09-18 03:48:05 --> Controller Class Initialized
DEBUG - 2019-09-18 03:48:05 --> File loaded: C:\xampp\htdocs\nilai\application\modules/home/views/v_home.php
DEBUG - 2019-09-18 03:48:05 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2019-09-18 03:48:05 --> Final output sent to browser
DEBUG - 2019-09-18 03:48:05 --> Total execution time: 0.3460
INFO - 2019-09-18 03:48:06 --> Config Class Initialized
INFO - 2019-09-18 03:48:06 --> Hooks Class Initialized
DEBUG - 2019-09-18 03:48:06 --> UTF-8 Support Enabled
INFO - 2019-09-18 03:48:06 --> Utf8 Class Initialized
INFO - 2019-09-18 03:48:06 --> URI Class Initialized
INFO - 2019-09-18 03:48:06 --> Router Class Initialized
INFO - 2019-09-18 03:48:06 --> Output Class Initialized
INFO - 2019-09-18 03:48:06 --> Security Class Initialized
DEBUG - 2019-09-18 03:48:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-09-18 03:48:06 --> Input Class Initialized
INFO - 2019-09-18 03:48:06 --> Language Class Initialized
INFO - 2019-09-18 03:48:06 --> Language Class Initialized
INFO - 2019-09-18 03:48:06 --> Config Class Initialized
INFO - 2019-09-18 03:48:06 --> Loader Class Initialized
INFO - 2019-09-18 03:48:06 --> Helper loaded: url_helper
INFO - 2019-09-18 03:48:06 --> Helper loaded: file_helper
INFO - 2019-09-18 03:48:06 --> Helper loaded: form_helper
INFO - 2019-09-18 03:48:06 --> Helper loaded: my_helper
INFO - 2019-09-18 03:48:06 --> Database Driver Class Initialized
DEBUG - 2019-09-18 03:48:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-09-18 03:48:06 --> Session: Class initialized using 'files' driver.
INFO - 2019-09-18 03:48:06 --> Controller Class Initialized
DEBUG - 2019-09-18 03:48:06 --> File loaded: C:\xampp\htdocs\nilai\application\modules/view_mapel/views/v_view_mapel.php
DEBUG - 2019-09-18 03:48:06 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2019-09-18 03:48:06 --> Final output sent to browser
DEBUG - 2019-09-18 03:48:06 --> Total execution time: 0.3310
INFO - 2019-09-18 03:48:08 --> Config Class Initialized
INFO - 2019-09-18 03:48:08 --> Hooks Class Initialized
DEBUG - 2019-09-18 03:48:08 --> UTF-8 Support Enabled
INFO - 2019-09-18 03:48:08 --> Utf8 Class Initialized
INFO - 2019-09-18 03:48:08 --> URI Class Initialized
INFO - 2019-09-18 03:48:08 --> Router Class Initialized
INFO - 2019-09-18 03:48:08 --> Output Class Initialized
INFO - 2019-09-18 03:48:08 --> Security Class Initialized
DEBUG - 2019-09-18 03:48:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-09-18 03:48:08 --> Input Class Initialized
INFO - 2019-09-18 03:48:08 --> Language Class Initialized
INFO - 2019-09-18 03:48:08 --> Language Class Initialized
INFO - 2019-09-18 03:48:08 --> Config Class Initialized
INFO - 2019-09-18 03:48:08 --> Loader Class Initialized
INFO - 2019-09-18 03:48:08 --> Helper loaded: url_helper
INFO - 2019-09-18 03:48:08 --> Helper loaded: file_helper
INFO - 2019-09-18 03:48:08 --> Helper loaded: form_helper
INFO - 2019-09-18 03:48:08 --> Helper loaded: my_helper
INFO - 2019-09-18 03:48:08 --> Database Driver Class Initialized
DEBUG - 2019-09-18 03:48:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-09-18 03:48:08 --> Session: Class initialized using 'files' driver.
INFO - 2019-09-18 03:48:08 --> Controller Class Initialized
DEBUG - 2019-09-18 03:48:08 --> File loaded: C:\xampp\htdocs\nilai\application\modules/riwayat_mengajar/views/list.php
DEBUG - 2019-09-18 03:48:08 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2019-09-18 03:48:08 --> Final output sent to browser
DEBUG - 2019-09-18 03:48:08 --> Total execution time: 0.3530
INFO - 2019-09-18 03:48:11 --> Config Class Initialized
INFO - 2019-09-18 03:48:11 --> Hooks Class Initialized
DEBUG - 2019-09-18 03:48:11 --> UTF-8 Support Enabled
INFO - 2019-09-18 03:48:11 --> Utf8 Class Initialized
INFO - 2019-09-18 03:48:11 --> URI Class Initialized
INFO - 2019-09-18 03:48:11 --> Router Class Initialized
INFO - 2019-09-18 03:48:11 --> Output Class Initialized
INFO - 2019-09-18 03:48:11 --> Security Class Initialized
DEBUG - 2019-09-18 03:48:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-09-18 03:48:11 --> Input Class Initialized
INFO - 2019-09-18 03:48:11 --> Language Class Initialized
INFO - 2019-09-18 03:48:11 --> Language Class Initialized
INFO - 2019-09-18 03:48:11 --> Config Class Initialized
INFO - 2019-09-18 03:48:11 --> Loader Class Initialized
INFO - 2019-09-18 03:48:11 --> Helper loaded: url_helper
INFO - 2019-09-18 03:48:12 --> Helper loaded: file_helper
INFO - 2019-09-18 03:48:12 --> Helper loaded: form_helper
INFO - 2019-09-18 03:48:12 --> Helper loaded: my_helper
INFO - 2019-09-18 03:48:12 --> Database Driver Class Initialized
DEBUG - 2019-09-18 03:48:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-09-18 03:48:12 --> Session: Class initialized using 'files' driver.
INFO - 2019-09-18 03:48:12 --> Controller Class Initialized
DEBUG - 2019-09-18 03:48:12 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/list.php
DEBUG - 2019-09-18 03:48:12 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2019-09-18 03:48:12 --> Final output sent to browser
DEBUG - 2019-09-18 03:48:12 --> Total execution time: 0.3750
INFO - 2019-09-18 03:48:15 --> Config Class Initialized
INFO - 2019-09-18 03:48:15 --> Hooks Class Initialized
DEBUG - 2019-09-18 03:48:15 --> UTF-8 Support Enabled
INFO - 2019-09-18 03:48:15 --> Utf8 Class Initialized
INFO - 2019-09-18 03:48:15 --> URI Class Initialized
INFO - 2019-09-18 03:48:15 --> Router Class Initialized
INFO - 2019-09-18 03:48:15 --> Output Class Initialized
INFO - 2019-09-18 03:48:15 --> Security Class Initialized
DEBUG - 2019-09-18 03:48:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-09-18 03:48:15 --> Input Class Initialized
INFO - 2019-09-18 03:48:15 --> Language Class Initialized
INFO - 2019-09-18 03:48:15 --> Language Class Initialized
INFO - 2019-09-18 03:48:15 --> Config Class Initialized
INFO - 2019-09-18 03:48:15 --> Loader Class Initialized
INFO - 2019-09-18 03:48:15 --> Helper loaded: url_helper
INFO - 2019-09-18 03:48:15 --> Helper loaded: file_helper
INFO - 2019-09-18 03:48:15 --> Helper loaded: form_helper
INFO - 2019-09-18 03:48:15 --> Helper loaded: my_helper
INFO - 2019-09-18 03:48:15 --> Database Driver Class Initialized
DEBUG - 2019-09-18 03:48:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-09-18 03:48:15 --> Session: Class initialized using 'files' driver.
INFO - 2019-09-18 03:48:15 --> Controller Class Initialized
DEBUG - 2019-09-18 03:48:15 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_sampul1.php
INFO - 2019-09-18 03:48:15 --> Final output sent to browser
DEBUG - 2019-09-18 03:48:15 --> Total execution time: 0.4230
INFO - 2019-09-18 03:48:19 --> Config Class Initialized
INFO - 2019-09-18 03:48:19 --> Hooks Class Initialized
DEBUG - 2019-09-18 03:48:19 --> UTF-8 Support Enabled
INFO - 2019-09-18 03:48:19 --> Utf8 Class Initialized
INFO - 2019-09-18 03:48:19 --> URI Class Initialized
INFO - 2019-09-18 03:48:19 --> Router Class Initialized
INFO - 2019-09-18 03:48:19 --> Output Class Initialized
INFO - 2019-09-18 03:48:19 --> Security Class Initialized
DEBUG - 2019-09-18 03:48:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-09-18 03:48:19 --> Input Class Initialized
INFO - 2019-09-18 03:48:20 --> Language Class Initialized
INFO - 2019-09-18 03:48:20 --> Language Class Initialized
INFO - 2019-09-18 03:48:20 --> Config Class Initialized
INFO - 2019-09-18 03:48:20 --> Loader Class Initialized
INFO - 2019-09-18 03:48:20 --> Helper loaded: url_helper
INFO - 2019-09-18 03:48:20 --> Helper loaded: file_helper
INFO - 2019-09-18 03:48:20 --> Helper loaded: form_helper
INFO - 2019-09-18 03:48:20 --> Helper loaded: my_helper
INFO - 2019-09-18 03:48:20 --> Database Driver Class Initialized
DEBUG - 2019-09-18 03:48:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-09-18 03:48:20 --> Session: Class initialized using 'files' driver.
INFO - 2019-09-18 03:48:20 --> Controller Class Initialized
DEBUG - 2019-09-18 03:48:20 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_sampul2.php
INFO - 2019-09-18 03:48:20 --> Final output sent to browser
DEBUG - 2019-09-18 03:48:20 --> Total execution time: 0.4110
INFO - 2019-09-18 03:48:23 --> Config Class Initialized
INFO - 2019-09-18 03:48:23 --> Hooks Class Initialized
DEBUG - 2019-09-18 03:48:23 --> UTF-8 Support Enabled
INFO - 2019-09-18 03:48:23 --> Utf8 Class Initialized
INFO - 2019-09-18 03:48:23 --> URI Class Initialized
INFO - 2019-09-18 03:48:23 --> Router Class Initialized
INFO - 2019-09-18 03:48:23 --> Output Class Initialized
INFO - 2019-09-18 03:48:23 --> Security Class Initialized
DEBUG - 2019-09-18 03:48:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-09-18 03:48:23 --> Input Class Initialized
INFO - 2019-09-18 03:48:23 --> Language Class Initialized
INFO - 2019-09-18 03:48:23 --> Language Class Initialized
INFO - 2019-09-18 03:48:23 --> Config Class Initialized
INFO - 2019-09-18 03:48:23 --> Loader Class Initialized
INFO - 2019-09-18 03:48:23 --> Helper loaded: url_helper
INFO - 2019-09-18 03:48:23 --> Helper loaded: file_helper
INFO - 2019-09-18 03:48:23 --> Helper loaded: form_helper
INFO - 2019-09-18 03:48:23 --> Helper loaded: my_helper
INFO - 2019-09-18 03:48:23 --> Database Driver Class Initialized
DEBUG - 2019-09-18 03:48:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-09-18 03:48:23 --> Session: Class initialized using 'files' driver.
INFO - 2019-09-18 03:48:23 --> Controller Class Initialized
DEBUG - 2019-09-18 03:48:23 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_rapot.php
INFO - 2019-09-18 03:48:23 --> Final output sent to browser
DEBUG - 2019-09-18 03:48:23 --> Total execution time: 0.4960
INFO - 2019-09-18 03:48:38 --> Config Class Initialized
INFO - 2019-09-18 03:48:38 --> Hooks Class Initialized
DEBUG - 2019-09-18 03:48:38 --> UTF-8 Support Enabled
INFO - 2019-09-18 03:48:38 --> Utf8 Class Initialized
INFO - 2019-09-18 03:48:38 --> URI Class Initialized
INFO - 2019-09-18 03:48:38 --> Router Class Initialized
INFO - 2019-09-18 03:48:38 --> Output Class Initialized
INFO - 2019-09-18 03:48:38 --> Security Class Initialized
DEBUG - 2019-09-18 03:48:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-09-18 03:48:38 --> Input Class Initialized
INFO - 2019-09-18 03:48:38 --> Language Class Initialized
INFO - 2019-09-18 03:48:38 --> Language Class Initialized
INFO - 2019-09-18 03:48:38 --> Config Class Initialized
INFO - 2019-09-18 03:48:38 --> Loader Class Initialized
INFO - 2019-09-18 03:48:38 --> Helper loaded: url_helper
INFO - 2019-09-18 03:48:38 --> Helper loaded: file_helper
INFO - 2019-09-18 03:48:38 --> Helper loaded: form_helper
INFO - 2019-09-18 03:48:38 --> Helper loaded: my_helper
INFO - 2019-09-18 03:48:39 --> Database Driver Class Initialized
DEBUG - 2019-09-18 03:48:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-09-18 03:48:39 --> Session: Class initialized using 'files' driver.
INFO - 2019-09-18 03:48:39 --> Controller Class Initialized
DEBUG - 2019-09-18 03:48:39 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_sampul2.php
INFO - 2019-09-18 03:48:39 --> Final output sent to browser
DEBUG - 2019-09-18 03:48:39 --> Total execution time: 0.4020
INFO - 2019-09-18 03:48:46 --> Config Class Initialized
INFO - 2019-09-18 03:48:46 --> Hooks Class Initialized
DEBUG - 2019-09-18 03:48:46 --> UTF-8 Support Enabled
INFO - 2019-09-18 03:48:46 --> Utf8 Class Initialized
INFO - 2019-09-18 03:48:46 --> URI Class Initialized
INFO - 2019-09-18 03:48:46 --> Router Class Initialized
INFO - 2019-09-18 03:48:46 --> Output Class Initialized
INFO - 2019-09-18 03:48:46 --> Security Class Initialized
DEBUG - 2019-09-18 03:48:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-09-18 03:48:46 --> Input Class Initialized
INFO - 2019-09-18 03:48:46 --> Language Class Initialized
INFO - 2019-09-18 03:48:46 --> Language Class Initialized
INFO - 2019-09-18 03:48:46 --> Config Class Initialized
INFO - 2019-09-18 03:48:46 --> Loader Class Initialized
INFO - 2019-09-18 03:48:46 --> Helper loaded: url_helper
INFO - 2019-09-18 03:48:46 --> Helper loaded: file_helper
INFO - 2019-09-18 03:48:46 --> Helper loaded: form_helper
INFO - 2019-09-18 03:48:46 --> Helper loaded: my_helper
INFO - 2019-09-18 03:48:46 --> Database Driver Class Initialized
DEBUG - 2019-09-18 03:48:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-09-18 03:48:46 --> Session: Class initialized using 'files' driver.
INFO - 2019-09-18 03:48:46 --> Controller Class Initialized
DEBUG - 2019-09-18 03:48:46 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_sikap_so/views/list.php
DEBUG - 2019-09-18 03:48:46 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2019-09-18 03:48:46 --> Final output sent to browser
DEBUG - 2019-09-18 03:48:46 --> Total execution time: 0.3530
INFO - 2019-09-18 03:48:53 --> Config Class Initialized
INFO - 2019-09-18 03:48:53 --> Hooks Class Initialized
DEBUG - 2019-09-18 03:48:53 --> UTF-8 Support Enabled
INFO - 2019-09-18 03:48:53 --> Utf8 Class Initialized
INFO - 2019-09-18 03:48:53 --> URI Class Initialized
INFO - 2019-09-18 03:48:53 --> Router Class Initialized
INFO - 2019-09-18 03:48:53 --> Output Class Initialized
INFO - 2019-09-18 03:48:53 --> Security Class Initialized
DEBUG - 2019-09-18 03:48:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-09-18 03:48:53 --> Input Class Initialized
INFO - 2019-09-18 03:48:53 --> Language Class Initialized
INFO - 2019-09-18 03:48:53 --> Language Class Initialized
INFO - 2019-09-18 03:48:53 --> Config Class Initialized
INFO - 2019-09-18 03:48:53 --> Loader Class Initialized
INFO - 2019-09-18 03:48:53 --> Helper loaded: url_helper
INFO - 2019-09-18 03:48:53 --> Helper loaded: file_helper
INFO - 2019-09-18 03:48:53 --> Helper loaded: form_helper
INFO - 2019-09-18 03:48:53 --> Helper loaded: my_helper
INFO - 2019-09-18 03:48:53 --> Database Driver Class Initialized
DEBUG - 2019-09-18 03:48:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-09-18 03:48:53 --> Session: Class initialized using 'files' driver.
INFO - 2019-09-18 03:48:53 --> Controller Class Initialized
INFO - 2019-09-18 03:48:53 --> Final output sent to browser
DEBUG - 2019-09-18 03:48:53 --> Total execution time: 0.3080
INFO - 2019-09-18 03:49:04 --> Config Class Initialized
INFO - 2019-09-18 03:49:04 --> Hooks Class Initialized
DEBUG - 2019-09-18 03:49:04 --> UTF-8 Support Enabled
INFO - 2019-09-18 03:49:04 --> Utf8 Class Initialized
INFO - 2019-09-18 03:49:04 --> URI Class Initialized
INFO - 2019-09-18 03:49:05 --> Router Class Initialized
INFO - 2019-09-18 03:49:05 --> Output Class Initialized
INFO - 2019-09-18 03:49:05 --> Security Class Initialized
DEBUG - 2019-09-18 03:49:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-09-18 03:49:05 --> Input Class Initialized
INFO - 2019-09-18 03:49:05 --> Language Class Initialized
INFO - 2019-09-18 03:49:05 --> Language Class Initialized
INFO - 2019-09-18 03:49:05 --> Config Class Initialized
INFO - 2019-09-18 03:49:05 --> Loader Class Initialized
INFO - 2019-09-18 03:49:05 --> Helper loaded: url_helper
INFO - 2019-09-18 03:49:05 --> Helper loaded: file_helper
INFO - 2019-09-18 03:49:05 --> Helper loaded: form_helper
INFO - 2019-09-18 03:49:05 --> Helper loaded: my_helper
INFO - 2019-09-18 03:49:05 --> Database Driver Class Initialized
DEBUG - 2019-09-18 03:49:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-09-18 03:49:05 --> Session: Class initialized using 'files' driver.
INFO - 2019-09-18 03:49:05 --> Controller Class Initialized
INFO - 2019-09-18 03:49:05 --> Final output sent to browser
DEBUG - 2019-09-18 03:49:05 --> Total execution time: 0.5440
INFO - 2019-09-18 03:49:11 --> Config Class Initialized
INFO - 2019-09-18 03:49:11 --> Hooks Class Initialized
DEBUG - 2019-09-18 03:49:11 --> UTF-8 Support Enabled
INFO - 2019-09-18 03:49:11 --> Utf8 Class Initialized
INFO - 2019-09-18 03:49:11 --> URI Class Initialized
INFO - 2019-09-18 03:49:11 --> Router Class Initialized
INFO - 2019-09-18 03:49:11 --> Output Class Initialized
INFO - 2019-09-18 03:49:11 --> Security Class Initialized
DEBUG - 2019-09-18 03:49:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-09-18 03:49:11 --> Input Class Initialized
INFO - 2019-09-18 03:49:11 --> Language Class Initialized
INFO - 2019-09-18 03:49:11 --> Language Class Initialized
INFO - 2019-09-18 03:49:11 --> Config Class Initialized
INFO - 2019-09-18 03:49:11 --> Loader Class Initialized
INFO - 2019-09-18 03:49:11 --> Helper loaded: url_helper
INFO - 2019-09-18 03:49:11 --> Helper loaded: file_helper
INFO - 2019-09-18 03:49:11 --> Helper loaded: form_helper
INFO - 2019-09-18 03:49:11 --> Helper loaded: my_helper
INFO - 2019-09-18 03:49:11 --> Database Driver Class Initialized
DEBUG - 2019-09-18 03:49:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-09-18 03:49:11 --> Session: Class initialized using 'files' driver.
INFO - 2019-09-18 03:49:11 --> Controller Class Initialized
INFO - 2019-09-18 03:49:11 --> Final output sent to browser
DEBUG - 2019-09-18 03:49:11 --> Total execution time: 0.3440
INFO - 2019-09-18 03:49:15 --> Config Class Initialized
INFO - 2019-09-18 03:49:15 --> Hooks Class Initialized
DEBUG - 2019-09-18 03:49:15 --> UTF-8 Support Enabled
INFO - 2019-09-18 03:49:15 --> Utf8 Class Initialized
INFO - 2019-09-18 03:49:15 --> URI Class Initialized
INFO - 2019-09-18 03:49:15 --> Router Class Initialized
INFO - 2019-09-18 03:49:15 --> Output Class Initialized
INFO - 2019-09-18 03:49:15 --> Security Class Initialized
DEBUG - 2019-09-18 03:49:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-09-18 03:49:16 --> Input Class Initialized
INFO - 2019-09-18 03:49:16 --> Language Class Initialized
INFO - 2019-09-18 03:49:16 --> Language Class Initialized
INFO - 2019-09-18 03:49:16 --> Config Class Initialized
INFO - 2019-09-18 03:49:16 --> Loader Class Initialized
INFO - 2019-09-18 03:49:16 --> Helper loaded: url_helper
INFO - 2019-09-18 03:49:16 --> Helper loaded: file_helper
INFO - 2019-09-18 03:49:16 --> Helper loaded: form_helper
INFO - 2019-09-18 03:49:16 --> Helper loaded: my_helper
INFO - 2019-09-18 03:49:16 --> Database Driver Class Initialized
DEBUG - 2019-09-18 03:49:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-09-18 03:49:16 --> Session: Class initialized using 'files' driver.
INFO - 2019-09-18 03:49:16 --> Controller Class Initialized
INFO - 2019-09-18 03:49:16 --> Final output sent to browser
DEBUG - 2019-09-18 03:49:16 --> Total execution time: 0.6940
INFO - 2019-09-18 03:49:19 --> Config Class Initialized
INFO - 2019-09-18 03:49:19 --> Hooks Class Initialized
DEBUG - 2019-09-18 03:49:19 --> UTF-8 Support Enabled
INFO - 2019-09-18 03:49:19 --> Utf8 Class Initialized
INFO - 2019-09-18 03:49:20 --> URI Class Initialized
INFO - 2019-09-18 03:49:20 --> Router Class Initialized
INFO - 2019-09-18 03:49:20 --> Output Class Initialized
INFO - 2019-09-18 03:49:20 --> Security Class Initialized
DEBUG - 2019-09-18 03:49:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-09-18 03:49:20 --> Input Class Initialized
INFO - 2019-09-18 03:49:20 --> Language Class Initialized
INFO - 2019-09-18 03:49:20 --> Language Class Initialized
INFO - 2019-09-18 03:49:20 --> Config Class Initialized
INFO - 2019-09-18 03:49:20 --> Loader Class Initialized
INFO - 2019-09-18 03:49:20 --> Helper loaded: url_helper
INFO - 2019-09-18 03:49:20 --> Helper loaded: file_helper
INFO - 2019-09-18 03:49:20 --> Helper loaded: form_helper
INFO - 2019-09-18 03:49:20 --> Helper loaded: my_helper
INFO - 2019-09-18 03:49:20 --> Database Driver Class Initialized
DEBUG - 2019-09-18 03:49:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-09-18 03:49:20 --> Session: Class initialized using 'files' driver.
INFO - 2019-09-18 03:49:20 --> Controller Class Initialized
DEBUG - 2019-09-18 03:49:20 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_sikap_so/views/cetak.php
INFO - 2019-09-18 03:49:20 --> Final output sent to browser
DEBUG - 2019-09-18 03:49:20 --> Total execution time: 0.4270
INFO - 2019-09-18 03:49:30 --> Config Class Initialized
INFO - 2019-09-18 03:49:30 --> Hooks Class Initialized
DEBUG - 2019-09-18 03:49:30 --> UTF-8 Support Enabled
INFO - 2019-09-18 03:49:30 --> Utf8 Class Initialized
INFO - 2019-09-18 03:49:30 --> URI Class Initialized
INFO - 2019-09-18 03:49:30 --> Router Class Initialized
INFO - 2019-09-18 03:49:30 --> Output Class Initialized
INFO - 2019-09-18 03:49:30 --> Security Class Initialized
DEBUG - 2019-09-18 03:49:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-09-18 03:49:30 --> Input Class Initialized
INFO - 2019-09-18 03:49:30 --> Language Class Initialized
INFO - 2019-09-18 03:49:30 --> Language Class Initialized
INFO - 2019-09-18 03:49:30 --> Config Class Initialized
INFO - 2019-09-18 03:49:30 --> Loader Class Initialized
INFO - 2019-09-18 03:49:30 --> Helper loaded: url_helper
INFO - 2019-09-18 03:49:30 --> Helper loaded: file_helper
INFO - 2019-09-18 03:49:30 --> Helper loaded: form_helper
INFO - 2019-09-18 03:49:30 --> Helper loaded: my_helper
INFO - 2019-09-18 03:49:30 --> Database Driver Class Initialized
DEBUG - 2019-09-18 03:49:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-09-18 03:49:30 --> Session: Class initialized using 'files' driver.
INFO - 2019-09-18 03:49:30 --> Controller Class Initialized
DEBUG - 2019-09-18 03:49:30 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_leger/views/landing.php
DEBUG - 2019-09-18 03:49:30 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2019-09-18 03:49:30 --> Final output sent to browser
DEBUG - 2019-09-18 03:49:30 --> Total execution time: 0.3780
INFO - 2019-09-18 03:49:32 --> Config Class Initialized
INFO - 2019-09-18 03:49:32 --> Hooks Class Initialized
DEBUG - 2019-09-18 03:49:32 --> UTF-8 Support Enabled
INFO - 2019-09-18 03:49:32 --> Utf8 Class Initialized
INFO - 2019-09-18 03:49:32 --> URI Class Initialized
INFO - 2019-09-18 03:49:32 --> Router Class Initialized
INFO - 2019-09-18 03:49:32 --> Output Class Initialized
INFO - 2019-09-18 03:49:32 --> Security Class Initialized
DEBUG - 2019-09-18 03:49:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-09-18 03:49:32 --> Input Class Initialized
INFO - 2019-09-18 03:49:32 --> Language Class Initialized
INFO - 2019-09-18 03:49:32 --> Language Class Initialized
INFO - 2019-09-18 03:49:32 --> Config Class Initialized
INFO - 2019-09-18 03:49:32 --> Loader Class Initialized
INFO - 2019-09-18 03:49:32 --> Helper loaded: url_helper
INFO - 2019-09-18 03:49:32 --> Helper loaded: file_helper
INFO - 2019-09-18 03:49:32 --> Helper loaded: form_helper
INFO - 2019-09-18 03:49:32 --> Helper loaded: my_helper
INFO - 2019-09-18 03:49:32 --> Database Driver Class Initialized
DEBUG - 2019-09-18 03:49:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-09-18 03:49:32 --> Session: Class initialized using 'files' driver.
INFO - 2019-09-18 03:49:32 --> Controller Class Initialized
DEBUG - 2019-09-18 03:49:33 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_leger/views/cetak.php
INFO - 2019-09-18 03:49:33 --> Final output sent to browser
DEBUG - 2019-09-18 03:49:33 --> Total execution time: 0.4580
INFO - 2019-09-18 03:49:36 --> Config Class Initialized
INFO - 2019-09-18 03:49:36 --> Hooks Class Initialized
DEBUG - 2019-09-18 03:49:36 --> UTF-8 Support Enabled
INFO - 2019-09-18 03:49:36 --> Utf8 Class Initialized
INFO - 2019-09-18 03:49:36 --> URI Class Initialized
INFO - 2019-09-18 03:49:36 --> Router Class Initialized
INFO - 2019-09-18 03:49:36 --> Output Class Initialized
INFO - 2019-09-18 03:49:36 --> Security Class Initialized
DEBUG - 2019-09-18 03:49:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-09-18 03:49:36 --> Input Class Initialized
INFO - 2019-09-18 03:49:36 --> Language Class Initialized
INFO - 2019-09-18 03:49:36 --> Language Class Initialized
INFO - 2019-09-18 03:49:36 --> Config Class Initialized
INFO - 2019-09-18 03:49:36 --> Loader Class Initialized
INFO - 2019-09-18 03:49:36 --> Helper loaded: url_helper
INFO - 2019-09-18 03:49:36 --> Helper loaded: file_helper
INFO - 2019-09-18 03:49:36 --> Helper loaded: form_helper
INFO - 2019-09-18 03:49:36 --> Helper loaded: my_helper
INFO - 2019-09-18 03:49:36 --> Database Driver Class Initialized
DEBUG - 2019-09-18 03:49:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-09-18 03:49:36 --> Session: Class initialized using 'files' driver.
INFO - 2019-09-18 03:49:36 --> Controller Class Initialized
DEBUG - 2019-09-18 03:49:36 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_leger/views/cetak_ekstra.php
INFO - 2019-09-18 03:49:37 --> Final output sent to browser
DEBUG - 2019-09-18 03:49:37 --> Total execution time: 0.3920
INFO - 2019-09-18 03:49:40 --> Config Class Initialized
INFO - 2019-09-18 03:49:40 --> Hooks Class Initialized
DEBUG - 2019-09-18 03:49:40 --> UTF-8 Support Enabled
INFO - 2019-09-18 03:49:40 --> Utf8 Class Initialized
INFO - 2019-09-18 03:49:40 --> URI Class Initialized
INFO - 2019-09-18 03:49:40 --> Router Class Initialized
INFO - 2019-09-18 03:49:40 --> Output Class Initialized
INFO - 2019-09-18 03:49:40 --> Security Class Initialized
DEBUG - 2019-09-18 03:49:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-09-18 03:49:40 --> Input Class Initialized
INFO - 2019-09-18 03:49:40 --> Language Class Initialized
INFO - 2019-09-18 03:49:40 --> Language Class Initialized
INFO - 2019-09-18 03:49:40 --> Config Class Initialized
INFO - 2019-09-18 03:49:40 --> Loader Class Initialized
INFO - 2019-09-18 03:49:40 --> Helper loaded: url_helper
INFO - 2019-09-18 03:49:40 --> Helper loaded: file_helper
INFO - 2019-09-18 03:49:40 --> Helper loaded: form_helper
INFO - 2019-09-18 03:49:40 --> Helper loaded: my_helper
INFO - 2019-09-18 03:49:40 --> Database Driver Class Initialized
DEBUG - 2019-09-18 03:49:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-09-18 03:49:41 --> Session: Class initialized using 'files' driver.
INFO - 2019-09-18 03:49:41 --> Controller Class Initialized
DEBUG - 2019-09-18 03:49:41 --> File loaded: C:\xampp\htdocs\nilai\application\modules/home/views/v_ubah_password.php
DEBUG - 2019-09-18 03:49:41 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2019-09-18 03:49:41 --> Final output sent to browser
DEBUG - 2019-09-18 03:49:41 --> Total execution time: 0.3990
INFO - 2019-09-18 03:49:42 --> Config Class Initialized
INFO - 2019-09-18 03:49:42 --> Hooks Class Initialized
DEBUG - 2019-09-18 03:49:42 --> UTF-8 Support Enabled
INFO - 2019-09-18 03:49:42 --> Utf8 Class Initialized
INFO - 2019-09-18 03:49:42 --> URI Class Initialized
INFO - 2019-09-18 03:49:42 --> Router Class Initialized
INFO - 2019-09-18 03:49:42 --> Output Class Initialized
INFO - 2019-09-18 03:49:42 --> Security Class Initialized
DEBUG - 2019-09-18 03:49:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-09-18 03:49:42 --> Input Class Initialized
INFO - 2019-09-18 03:49:42 --> Language Class Initialized
INFO - 2019-09-18 03:49:42 --> Language Class Initialized
INFO - 2019-09-18 03:49:42 --> Config Class Initialized
INFO - 2019-09-18 03:49:42 --> Loader Class Initialized
INFO - 2019-09-18 03:49:42 --> Helper loaded: url_helper
INFO - 2019-09-18 03:49:42 --> Helper loaded: file_helper
INFO - 2019-09-18 03:49:42 --> Helper loaded: form_helper
INFO - 2019-09-18 03:49:42 --> Helper loaded: my_helper
INFO - 2019-09-18 03:49:42 --> Database Driver Class Initialized
DEBUG - 2019-09-18 03:49:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-09-18 03:49:42 --> Session: Class initialized using 'files' driver.
INFO - 2019-09-18 03:49:42 --> Controller Class Initialized
DEBUG - 2019-09-18 03:49:42 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/list.php
DEBUG - 2019-09-18 03:49:42 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2019-09-18 03:49:42 --> Final output sent to browser
DEBUG - 2019-09-18 03:49:42 --> Total execution time: 0.3400
INFO - 2019-09-18 03:49:43 --> Config Class Initialized
INFO - 2019-09-18 03:49:43 --> Hooks Class Initialized
DEBUG - 2019-09-18 03:49:43 --> UTF-8 Support Enabled
INFO - 2019-09-18 03:49:43 --> Utf8 Class Initialized
INFO - 2019-09-18 03:49:43 --> URI Class Initialized
INFO - 2019-09-18 03:49:43 --> Router Class Initialized
INFO - 2019-09-18 03:49:43 --> Output Class Initialized
INFO - 2019-09-18 03:49:43 --> Security Class Initialized
DEBUG - 2019-09-18 03:49:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-09-18 03:49:43 --> Input Class Initialized
INFO - 2019-09-18 03:49:44 --> Language Class Initialized
INFO - 2019-09-18 03:49:44 --> Language Class Initialized
INFO - 2019-09-18 03:49:44 --> Config Class Initialized
INFO - 2019-09-18 03:49:44 --> Loader Class Initialized
INFO - 2019-09-18 03:49:44 --> Helper loaded: url_helper
INFO - 2019-09-18 03:49:44 --> Helper loaded: file_helper
INFO - 2019-09-18 03:49:44 --> Helper loaded: form_helper
INFO - 2019-09-18 03:49:44 --> Helper loaded: my_helper
INFO - 2019-09-18 03:49:44 --> Database Driver Class Initialized
DEBUG - 2019-09-18 03:49:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-09-18 03:49:44 --> Session: Class initialized using 'files' driver.
INFO - 2019-09-18 03:49:44 --> Controller Class Initialized
DEBUG - 2019-09-18 03:49:44 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_catatan/views/list.php
DEBUG - 2019-09-18 03:49:44 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2019-09-18 03:49:44 --> Final output sent to browser
DEBUG - 2019-09-18 03:49:44 --> Total execution time: 0.6790
INFO - 2019-09-18 03:49:46 --> Config Class Initialized
INFO - 2019-09-18 03:49:46 --> Hooks Class Initialized
DEBUG - 2019-09-18 03:49:46 --> UTF-8 Support Enabled
INFO - 2019-09-18 03:49:46 --> Utf8 Class Initialized
INFO - 2019-09-18 03:49:46 --> URI Class Initialized
DEBUG - 2019-09-18 03:49:46 --> No URI present. Default controller set.
INFO - 2019-09-18 03:49:46 --> Router Class Initialized
INFO - 2019-09-18 03:49:46 --> Output Class Initialized
INFO - 2019-09-18 03:49:46 --> Security Class Initialized
DEBUG - 2019-09-18 03:49:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-09-18 03:49:46 --> Input Class Initialized
INFO - 2019-09-18 03:49:46 --> Language Class Initialized
INFO - 2019-09-18 03:49:46 --> Language Class Initialized
INFO - 2019-09-18 03:49:46 --> Config Class Initialized
INFO - 2019-09-18 03:49:46 --> Loader Class Initialized
INFO - 2019-09-18 03:49:46 --> Helper loaded: url_helper
INFO - 2019-09-18 03:49:46 --> Helper loaded: file_helper
INFO - 2019-09-18 03:49:46 --> Helper loaded: form_helper
INFO - 2019-09-18 03:49:46 --> Helper loaded: my_helper
INFO - 2019-09-18 03:49:46 --> Database Driver Class Initialized
DEBUG - 2019-09-18 03:49:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-09-18 03:49:46 --> Session: Class initialized using 'files' driver.
INFO - 2019-09-18 03:49:46 --> Controller Class Initialized
DEBUG - 2019-09-18 03:49:46 --> File loaded: C:\xampp\htdocs\nilai\application\modules/home/views/v_home.php
DEBUG - 2019-09-18 03:49:46 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2019-09-18 03:49:46 --> Final output sent to browser
DEBUG - 2019-09-18 03:49:46 --> Total execution time: 0.3550
INFO - 2019-09-18 03:49:47 --> Config Class Initialized
INFO - 2019-09-18 03:49:47 --> Hooks Class Initialized
DEBUG - 2019-09-18 03:49:47 --> UTF-8 Support Enabled
INFO - 2019-09-18 03:49:47 --> Utf8 Class Initialized
INFO - 2019-09-18 03:49:47 --> URI Class Initialized
INFO - 2019-09-18 03:49:47 --> Router Class Initialized
INFO - 2019-09-18 03:49:47 --> Output Class Initialized
INFO - 2019-09-18 03:49:47 --> Security Class Initialized
DEBUG - 2019-09-18 03:49:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-09-18 03:49:47 --> Input Class Initialized
INFO - 2019-09-18 03:49:47 --> Language Class Initialized
INFO - 2019-09-18 03:49:47 --> Language Class Initialized
INFO - 2019-09-18 03:49:47 --> Config Class Initialized
INFO - 2019-09-18 03:49:47 --> Loader Class Initialized
INFO - 2019-09-18 03:49:47 --> Helper loaded: url_helper
INFO - 2019-09-18 03:49:47 --> Helper loaded: file_helper
INFO - 2019-09-18 03:49:47 --> Helper loaded: form_helper
INFO - 2019-09-18 03:49:47 --> Helper loaded: my_helper
INFO - 2019-09-18 03:49:47 --> Database Driver Class Initialized
DEBUG - 2019-09-18 03:49:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-09-18 03:49:47 --> Session: Class initialized using 'files' driver.
INFO - 2019-09-18 03:49:47 --> Controller Class Initialized
DEBUG - 2019-09-18 03:49:47 --> File loaded: C:\xampp\htdocs\nilai\application\modules/view_mapel/views/v_view_mapel.php
DEBUG - 2019-09-18 03:49:47 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2019-09-18 03:49:47 --> Final output sent to browser
DEBUG - 2019-09-18 03:49:47 --> Total execution time: 0.3470
INFO - 2019-09-18 03:49:54 --> Config Class Initialized
INFO - 2019-09-18 03:49:54 --> Hooks Class Initialized
DEBUG - 2019-09-18 03:49:54 --> UTF-8 Support Enabled
INFO - 2019-09-18 03:49:54 --> Utf8 Class Initialized
INFO - 2019-09-18 03:49:54 --> URI Class Initialized
DEBUG - 2019-09-18 03:49:54 --> No URI present. Default controller set.
INFO - 2019-09-18 03:49:54 --> Router Class Initialized
INFO - 2019-09-18 03:49:54 --> Output Class Initialized
INFO - 2019-09-18 03:49:54 --> Security Class Initialized
DEBUG - 2019-09-18 03:49:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-09-18 03:49:54 --> Input Class Initialized
INFO - 2019-09-18 03:49:54 --> Language Class Initialized
INFO - 2019-09-18 03:49:54 --> Language Class Initialized
INFO - 2019-09-18 03:49:54 --> Config Class Initialized
INFO - 2019-09-18 03:49:54 --> Loader Class Initialized
INFO - 2019-09-18 03:49:54 --> Helper loaded: url_helper
INFO - 2019-09-18 03:49:54 --> Helper loaded: file_helper
INFO - 2019-09-18 03:49:54 --> Helper loaded: form_helper
INFO - 2019-09-18 03:49:54 --> Helper loaded: my_helper
INFO - 2019-09-18 03:49:54 --> Database Driver Class Initialized
DEBUG - 2019-09-18 03:49:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-09-18 03:49:54 --> Session: Class initialized using 'files' driver.
INFO - 2019-09-18 03:49:54 --> Controller Class Initialized
DEBUG - 2019-09-18 03:49:54 --> File loaded: C:\xampp\htdocs\nilai\application\modules/home/views/v_home.php
DEBUG - 2019-09-18 03:49:54 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2019-09-18 03:49:54 --> Final output sent to browser
DEBUG - 2019-09-18 03:49:55 --> Total execution time: 0.3680
INFO - 2019-09-18 03:49:56 --> Config Class Initialized
INFO - 2019-09-18 03:49:56 --> Hooks Class Initialized
DEBUG - 2019-09-18 03:49:56 --> UTF-8 Support Enabled
INFO - 2019-09-18 03:49:56 --> Utf8 Class Initialized
INFO - 2019-09-18 03:49:56 --> URI Class Initialized
INFO - 2019-09-18 03:49:56 --> Router Class Initialized
INFO - 2019-09-18 03:49:56 --> Output Class Initialized
INFO - 2019-09-18 03:49:56 --> Security Class Initialized
DEBUG - 2019-09-18 03:49:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-09-18 03:49:56 --> Input Class Initialized
INFO - 2019-09-18 03:49:56 --> Language Class Initialized
INFO - 2019-09-18 03:49:56 --> Language Class Initialized
INFO - 2019-09-18 03:49:56 --> Config Class Initialized
INFO - 2019-09-18 03:49:56 --> Loader Class Initialized
INFO - 2019-09-18 03:49:56 --> Helper loaded: url_helper
INFO - 2019-09-18 03:49:56 --> Helper loaded: file_helper
INFO - 2019-09-18 03:49:56 --> Helper loaded: form_helper
INFO - 2019-09-18 03:49:56 --> Helper loaded: my_helper
INFO - 2019-09-18 03:49:56 --> Database Driver Class Initialized
DEBUG - 2019-09-18 03:49:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-09-18 03:49:56 --> Session: Class initialized using 'files' driver.
INFO - 2019-09-18 03:49:56 --> Controller Class Initialized
DEBUG - 2019-09-18 03:49:56 --> File loaded: C:\xampp\htdocs\nilai\application\modules/view_mapel/views/v_view_mapel.php
DEBUG - 2019-09-18 03:49:57 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2019-09-18 03:49:57 --> Final output sent to browser
DEBUG - 2019-09-18 03:49:57 --> Total execution time: 0.3480
INFO - 2019-09-18 03:49:58 --> Config Class Initialized
INFO - 2019-09-18 03:49:58 --> Hooks Class Initialized
DEBUG - 2019-09-18 03:49:58 --> UTF-8 Support Enabled
INFO - 2019-09-18 03:49:58 --> Utf8 Class Initialized
INFO - 2019-09-18 03:49:58 --> URI Class Initialized
INFO - 2019-09-18 03:49:58 --> Router Class Initialized
INFO - 2019-09-18 03:49:58 --> Output Class Initialized
INFO - 2019-09-18 03:49:58 --> Security Class Initialized
DEBUG - 2019-09-18 03:49:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-09-18 03:49:58 --> Input Class Initialized
INFO - 2019-09-18 03:49:58 --> Language Class Initialized
INFO - 2019-09-18 03:49:58 --> Language Class Initialized
INFO - 2019-09-18 03:49:58 --> Config Class Initialized
INFO - 2019-09-18 03:49:58 --> Loader Class Initialized
INFO - 2019-09-18 03:49:58 --> Helper loaded: url_helper
INFO - 2019-09-18 03:49:58 --> Helper loaded: file_helper
INFO - 2019-09-18 03:49:58 --> Helper loaded: form_helper
INFO - 2019-09-18 03:49:58 --> Helper loaded: my_helper
INFO - 2019-09-18 03:49:58 --> Database Driver Class Initialized
DEBUG - 2019-09-18 03:49:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-09-18 03:49:58 --> Session: Class initialized using 'files' driver.
INFO - 2019-09-18 03:49:58 --> Controller Class Initialized
DEBUG - 2019-09-18 03:49:58 --> File loaded: C:\xampp\htdocs\nilai\application\modules/riwayat_mengajar/views/list.php
DEBUG - 2019-09-18 03:49:58 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2019-09-18 03:49:58 --> Final output sent to browser
DEBUG - 2019-09-18 03:49:58 --> Total execution time: 0.3470
INFO - 2019-09-18 03:49:59 --> Config Class Initialized
INFO - 2019-09-18 03:50:00 --> Hooks Class Initialized
DEBUG - 2019-09-18 03:50:00 --> UTF-8 Support Enabled
INFO - 2019-09-18 03:50:00 --> Utf8 Class Initialized
INFO - 2019-09-18 03:50:00 --> URI Class Initialized
INFO - 2019-09-18 03:50:00 --> Router Class Initialized
INFO - 2019-09-18 03:50:00 --> Output Class Initialized
INFO - 2019-09-18 03:50:00 --> Security Class Initialized
DEBUG - 2019-09-18 03:50:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-09-18 03:50:00 --> Input Class Initialized
INFO - 2019-09-18 03:50:00 --> Language Class Initialized
INFO - 2019-09-18 03:50:00 --> Language Class Initialized
INFO - 2019-09-18 03:50:00 --> Config Class Initialized
INFO - 2019-09-18 03:50:00 --> Loader Class Initialized
INFO - 2019-09-18 03:50:00 --> Helper loaded: url_helper
INFO - 2019-09-18 03:50:00 --> Helper loaded: file_helper
INFO - 2019-09-18 03:50:00 --> Helper loaded: form_helper
INFO - 2019-09-18 03:50:00 --> Helper loaded: my_helper
INFO - 2019-09-18 03:50:00 --> Database Driver Class Initialized
DEBUG - 2019-09-18 03:50:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-09-18 03:50:00 --> Session: Class initialized using 'files' driver.
INFO - 2019-09-18 03:50:00 --> Controller Class Initialized
DEBUG - 2019-09-18 03:50:00 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_sikap_sp/views/list.php
DEBUG - 2019-09-18 03:50:00 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2019-09-18 03:50:00 --> Final output sent to browser
DEBUG - 2019-09-18 03:50:00 --> Total execution time: 0.3640
INFO - 2019-09-18 03:50:01 --> Config Class Initialized
INFO - 2019-09-18 03:50:01 --> Hooks Class Initialized
DEBUG - 2019-09-18 03:50:01 --> UTF-8 Support Enabled
INFO - 2019-09-18 03:50:01 --> Utf8 Class Initialized
INFO - 2019-09-18 03:50:01 --> URI Class Initialized
INFO - 2019-09-18 03:50:01 --> Router Class Initialized
INFO - 2019-09-18 03:50:01 --> Output Class Initialized
INFO - 2019-09-18 03:50:01 --> Security Class Initialized
DEBUG - 2019-09-18 03:50:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-09-18 03:50:01 --> Input Class Initialized
INFO - 2019-09-18 03:50:01 --> Language Class Initialized
INFO - 2019-09-18 03:50:01 --> Language Class Initialized
INFO - 2019-09-18 03:50:01 --> Config Class Initialized
INFO - 2019-09-18 03:50:01 --> Loader Class Initialized
INFO - 2019-09-18 03:50:01 --> Helper loaded: url_helper
INFO - 2019-09-18 03:50:01 --> Helper loaded: file_helper
INFO - 2019-09-18 03:50:01 --> Helper loaded: form_helper
INFO - 2019-09-18 03:50:01 --> Helper loaded: my_helper
INFO - 2019-09-18 03:50:01 --> Database Driver Class Initialized
DEBUG - 2019-09-18 03:50:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-09-18 03:50:01 --> Session: Class initialized using 'files' driver.
INFO - 2019-09-18 03:50:01 --> Controller Class Initialized
DEBUG - 2019-09-18 03:50:01 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_sikap_so/views/list.php
DEBUG - 2019-09-18 03:50:01 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2019-09-18 03:50:01 --> Final output sent to browser
DEBUG - 2019-09-18 03:50:01 --> Total execution time: 0.3540
INFO - 2019-09-18 03:50:02 --> Config Class Initialized
INFO - 2019-09-18 03:50:02 --> Hooks Class Initialized
DEBUG - 2019-09-18 03:50:02 --> UTF-8 Support Enabled
INFO - 2019-09-18 03:50:02 --> Utf8 Class Initialized
INFO - 2019-09-18 03:50:02 --> URI Class Initialized
INFO - 2019-09-18 03:50:02 --> Router Class Initialized
INFO - 2019-09-18 03:50:02 --> Output Class Initialized
INFO - 2019-09-18 03:50:02 --> Security Class Initialized
DEBUG - 2019-09-18 03:50:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-09-18 03:50:02 --> Input Class Initialized
INFO - 2019-09-18 03:50:02 --> Language Class Initialized
INFO - 2019-09-18 03:50:02 --> Language Class Initialized
INFO - 2019-09-18 03:50:02 --> Config Class Initialized
INFO - 2019-09-18 03:50:02 --> Loader Class Initialized
INFO - 2019-09-18 03:50:02 --> Helper loaded: url_helper
INFO - 2019-09-18 03:50:02 --> Helper loaded: file_helper
INFO - 2019-09-18 03:50:02 --> Helper loaded: form_helper
INFO - 2019-09-18 03:50:02 --> Helper loaded: my_helper
INFO - 2019-09-18 03:50:02 --> Database Driver Class Initialized
DEBUG - 2019-09-18 03:50:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-09-18 03:50:02 --> Session: Class initialized using 'files' driver.
INFO - 2019-09-18 03:50:02 --> Controller Class Initialized
DEBUG - 2019-09-18 03:50:02 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_ekstra/views/list.php
DEBUG - 2019-09-18 03:50:02 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2019-09-18 03:50:02 --> Final output sent to browser
DEBUG - 2019-09-18 03:50:02 --> Total execution time: 0.4100
INFO - 2019-09-18 03:50:04 --> Config Class Initialized
INFO - 2019-09-18 03:50:04 --> Hooks Class Initialized
DEBUG - 2019-09-18 03:50:04 --> UTF-8 Support Enabled
INFO - 2019-09-18 03:50:04 --> Utf8 Class Initialized
INFO - 2019-09-18 03:50:04 --> URI Class Initialized
DEBUG - 2019-09-18 03:50:04 --> No URI present. Default controller set.
INFO - 2019-09-18 03:50:04 --> Router Class Initialized
INFO - 2019-09-18 03:50:04 --> Output Class Initialized
INFO - 2019-09-18 03:50:04 --> Security Class Initialized
DEBUG - 2019-09-18 03:50:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-09-18 03:50:04 --> Input Class Initialized
INFO - 2019-09-18 03:50:04 --> Language Class Initialized
INFO - 2019-09-18 03:50:04 --> Language Class Initialized
INFO - 2019-09-18 03:50:04 --> Config Class Initialized
INFO - 2019-09-18 03:50:04 --> Loader Class Initialized
INFO - 2019-09-18 03:50:04 --> Helper loaded: url_helper
INFO - 2019-09-18 03:50:04 --> Helper loaded: file_helper
INFO - 2019-09-18 03:50:04 --> Helper loaded: form_helper
INFO - 2019-09-18 03:50:04 --> Helper loaded: my_helper
INFO - 2019-09-18 03:50:04 --> Database Driver Class Initialized
DEBUG - 2019-09-18 03:50:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-09-18 03:50:04 --> Session: Class initialized using 'files' driver.
INFO - 2019-09-18 03:50:04 --> Controller Class Initialized
DEBUG - 2019-09-18 03:50:04 --> File loaded: C:\xampp\htdocs\nilai\application\modules/home/views/v_home.php
DEBUG - 2019-09-18 03:50:04 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2019-09-18 03:50:04 --> Final output sent to browser
DEBUG - 2019-09-18 03:50:04 --> Total execution time: 0.4050
INFO - 2019-09-18 03:50:04 --> Config Class Initialized
INFO - 2019-09-18 03:50:04 --> Hooks Class Initialized
DEBUG - 2019-09-18 03:50:04 --> UTF-8 Support Enabled
INFO - 2019-09-18 03:50:04 --> Utf8 Class Initialized
INFO - 2019-09-18 03:50:04 --> URI Class Initialized
INFO - 2019-09-18 03:50:04 --> Router Class Initialized
INFO - 2019-09-18 03:50:04 --> Output Class Initialized
INFO - 2019-09-18 03:50:04 --> Security Class Initialized
DEBUG - 2019-09-18 03:50:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-09-18 03:50:04 --> Input Class Initialized
INFO - 2019-09-18 03:50:04 --> Language Class Initialized
INFO - 2019-09-18 03:50:04 --> Language Class Initialized
INFO - 2019-09-18 03:50:04 --> Config Class Initialized
INFO - 2019-09-18 03:50:04 --> Loader Class Initialized
INFO - 2019-09-18 03:50:05 --> Helper loaded: url_helper
INFO - 2019-09-18 03:50:05 --> Helper loaded: file_helper
INFO - 2019-09-18 03:50:05 --> Helper loaded: form_helper
INFO - 2019-09-18 03:50:05 --> Helper loaded: my_helper
INFO - 2019-09-18 03:50:05 --> Database Driver Class Initialized
DEBUG - 2019-09-18 03:50:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2019-09-18 03:50:05 --> Session: Class initialized using 'files' driver.
INFO - 2019-09-18 03:50:05 --> Controller Class Initialized
DEBUG - 2019-09-18 03:50:05 --> File loaded: C:\xampp\htdocs\nilai\application\modules/view_mapel/views/v_view_mapel.php
DEBUG - 2019-09-18 03:50:05 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2019-09-18 03:50:05 --> Final output sent to browser
DEBUG - 2019-09-18 03:50:05 --> Total execution time: 0.3770
