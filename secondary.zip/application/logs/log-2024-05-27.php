<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2024-05-27 07:57:08 --> Config Class Initialized
INFO - 2024-05-27 07:57:08 --> Hooks Class Initialized
DEBUG - 2024-05-27 07:57:08 --> UTF-8 Support Enabled
INFO - 2024-05-27 07:57:08 --> Utf8 Class Initialized
INFO - 2024-05-27 07:57:08 --> URI Class Initialized
INFO - 2024-05-27 07:57:08 --> Router Class Initialized
INFO - 2024-05-27 07:57:08 --> Output Class Initialized
INFO - 2024-05-27 07:57:08 --> Security Class Initialized
DEBUG - 2024-05-27 07:57:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-05-27 07:57:08 --> Input Class Initialized
INFO - 2024-05-27 07:57:08 --> Language Class Initialized
INFO - 2024-05-27 07:57:08 --> Language Class Initialized
INFO - 2024-05-27 07:57:08 --> Config Class Initialized
INFO - 2024-05-27 07:57:08 --> Loader Class Initialized
INFO - 2024-05-27 07:57:08 --> Helper loaded: url_helper
INFO - 2024-05-27 07:57:08 --> Helper loaded: file_helper
INFO - 2024-05-27 07:57:08 --> Helper loaded: form_helper
INFO - 2024-05-27 07:57:08 --> Helper loaded: my_helper
INFO - 2024-05-27 07:57:08 --> Database Driver Class Initialized
INFO - 2024-05-27 07:57:08 --> Session: Class initialized using 'files' driver.
INFO - 2024-05-27 07:57:08 --> Controller Class Initialized
DEBUG - 2024-05-27 07:57:08 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/login/views/login.php
DEBUG - 2024-05-27 07:57:08 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-05-27 07:57:08 --> Final output sent to browser
DEBUG - 2024-05-27 07:57:08 --> Total execution time: 0.0466
INFO - 2024-05-27 09:02:40 --> Config Class Initialized
INFO - 2024-05-27 09:02:40 --> Hooks Class Initialized
DEBUG - 2024-05-27 09:02:40 --> UTF-8 Support Enabled
INFO - 2024-05-27 09:02:40 --> Utf8 Class Initialized
INFO - 2024-05-27 09:02:40 --> URI Class Initialized
INFO - 2024-05-27 09:02:40 --> Router Class Initialized
INFO - 2024-05-27 09:02:40 --> Output Class Initialized
INFO - 2024-05-27 09:02:40 --> Security Class Initialized
DEBUG - 2024-05-27 09:02:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-05-27 09:02:40 --> Input Class Initialized
INFO - 2024-05-27 09:02:40 --> Language Class Initialized
INFO - 2024-05-27 09:02:40 --> Language Class Initialized
INFO - 2024-05-27 09:02:40 --> Config Class Initialized
INFO - 2024-05-27 09:02:40 --> Loader Class Initialized
INFO - 2024-05-27 09:02:40 --> Helper loaded: url_helper
INFO - 2024-05-27 09:02:40 --> Helper loaded: file_helper
INFO - 2024-05-27 09:02:40 --> Helper loaded: form_helper
INFO - 2024-05-27 09:02:40 --> Helper loaded: my_helper
INFO - 2024-05-27 09:02:40 --> Database Driver Class Initialized
INFO - 2024-05-27 09:02:40 --> Session: Class initialized using 'files' driver.
INFO - 2024-05-27 09:02:40 --> Controller Class Initialized
DEBUG - 2024-05-27 09:02:40 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/login/views/login.php
DEBUG - 2024-05-27 09:02:40 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-05-27 09:02:40 --> Final output sent to browser
DEBUG - 2024-05-27 09:02:40 --> Total execution time: 0.0526
INFO - 2024-05-27 09:02:41 --> Config Class Initialized
INFO - 2024-05-27 09:02:41 --> Hooks Class Initialized
DEBUG - 2024-05-27 09:02:41 --> UTF-8 Support Enabled
INFO - 2024-05-27 09:02:41 --> Utf8 Class Initialized
INFO - 2024-05-27 09:02:41 --> URI Class Initialized
INFO - 2024-05-27 09:02:41 --> Router Class Initialized
INFO - 2024-05-27 09:02:41 --> Output Class Initialized
INFO - 2024-05-27 09:02:41 --> Security Class Initialized
DEBUG - 2024-05-27 09:02:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-05-27 09:02:41 --> Input Class Initialized
INFO - 2024-05-27 09:02:41 --> Language Class Initialized
INFO - 2024-05-27 09:02:41 --> Language Class Initialized
INFO - 2024-05-27 09:02:41 --> Config Class Initialized
INFO - 2024-05-27 09:02:41 --> Loader Class Initialized
INFO - 2024-05-27 09:02:41 --> Helper loaded: url_helper
INFO - 2024-05-27 09:02:41 --> Helper loaded: file_helper
INFO - 2024-05-27 09:02:41 --> Helper loaded: form_helper
INFO - 2024-05-27 09:02:41 --> Helper loaded: my_helper
INFO - 2024-05-27 09:02:41 --> Database Driver Class Initialized
INFO - 2024-05-27 09:02:41 --> Session: Class initialized using 'files' driver.
INFO - 2024-05-27 09:02:41 --> Controller Class Initialized
DEBUG - 2024-05-27 09:02:41 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/login/views/login.php
DEBUG - 2024-05-27 09:02:41 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-05-27 09:02:41 --> Final output sent to browser
DEBUG - 2024-05-27 09:02:41 --> Total execution time: 0.0295
INFO - 2024-05-27 09:44:50 --> Config Class Initialized
INFO - 2024-05-27 09:44:50 --> Hooks Class Initialized
DEBUG - 2024-05-27 09:44:50 --> UTF-8 Support Enabled
INFO - 2024-05-27 09:44:50 --> Utf8 Class Initialized
INFO - 2024-05-27 09:44:50 --> URI Class Initialized
INFO - 2024-05-27 09:44:50 --> Router Class Initialized
INFO - 2024-05-27 09:44:50 --> Output Class Initialized
INFO - 2024-05-27 09:44:50 --> Security Class Initialized
DEBUG - 2024-05-27 09:44:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-05-27 09:44:50 --> Input Class Initialized
INFO - 2024-05-27 09:44:50 --> Language Class Initialized
INFO - 2024-05-27 09:44:50 --> Language Class Initialized
INFO - 2024-05-27 09:44:50 --> Config Class Initialized
INFO - 2024-05-27 09:44:50 --> Loader Class Initialized
INFO - 2024-05-27 09:44:50 --> Helper loaded: url_helper
INFO - 2024-05-27 09:44:50 --> Helper loaded: file_helper
INFO - 2024-05-27 09:44:50 --> Helper loaded: form_helper
INFO - 2024-05-27 09:44:50 --> Helper loaded: my_helper
INFO - 2024-05-27 09:44:50 --> Database Driver Class Initialized
INFO - 2024-05-27 09:44:50 --> Session: Class initialized using 'files' driver.
INFO - 2024-05-27 09:44:50 --> Controller Class Initialized
DEBUG - 2024-05-27 09:44:50 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/login/views/login.php
DEBUG - 2024-05-27 09:44:50 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-05-27 09:44:50 --> Final output sent to browser
DEBUG - 2024-05-27 09:44:50 --> Total execution time: 0.0495
INFO - 2024-05-27 09:45:02 --> Config Class Initialized
INFO - 2024-05-27 09:45:02 --> Hooks Class Initialized
DEBUG - 2024-05-27 09:45:02 --> UTF-8 Support Enabled
INFO - 2024-05-27 09:45:02 --> Utf8 Class Initialized
INFO - 2024-05-27 09:45:02 --> URI Class Initialized
INFO - 2024-05-27 09:45:02 --> Router Class Initialized
INFO - 2024-05-27 09:45:02 --> Output Class Initialized
INFO - 2024-05-27 09:45:02 --> Security Class Initialized
DEBUG - 2024-05-27 09:45:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-05-27 09:45:02 --> Input Class Initialized
INFO - 2024-05-27 09:45:02 --> Language Class Initialized
INFO - 2024-05-27 09:45:02 --> Language Class Initialized
INFO - 2024-05-27 09:45:02 --> Config Class Initialized
INFO - 2024-05-27 09:45:02 --> Loader Class Initialized
INFO - 2024-05-27 09:45:02 --> Helper loaded: url_helper
INFO - 2024-05-27 09:45:02 --> Helper loaded: file_helper
INFO - 2024-05-27 09:45:02 --> Helper loaded: form_helper
INFO - 2024-05-27 09:45:02 --> Helper loaded: my_helper
INFO - 2024-05-27 09:45:02 --> Database Driver Class Initialized
INFO - 2024-05-27 09:45:02 --> Session: Class initialized using 'files' driver.
INFO - 2024-05-27 09:45:02 --> Controller Class Initialized
INFO - 2024-05-27 09:45:02 --> Helper loaded: cookie_helper
INFO - 2024-05-27 09:45:02 --> Final output sent to browser
DEBUG - 2024-05-27 09:45:02 --> Total execution time: 0.0473
INFO - 2024-05-27 09:45:02 --> Config Class Initialized
INFO - 2024-05-27 09:45:02 --> Hooks Class Initialized
DEBUG - 2024-05-27 09:45:02 --> UTF-8 Support Enabled
INFO - 2024-05-27 09:45:02 --> Utf8 Class Initialized
INFO - 2024-05-27 09:45:02 --> URI Class Initialized
INFO - 2024-05-27 09:45:02 --> Router Class Initialized
INFO - 2024-05-27 09:45:02 --> Output Class Initialized
INFO - 2024-05-27 09:45:02 --> Security Class Initialized
DEBUG - 2024-05-27 09:45:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-05-27 09:45:02 --> Input Class Initialized
INFO - 2024-05-27 09:45:02 --> Language Class Initialized
INFO - 2024-05-27 09:45:02 --> Language Class Initialized
INFO - 2024-05-27 09:45:02 --> Config Class Initialized
INFO - 2024-05-27 09:45:02 --> Loader Class Initialized
INFO - 2024-05-27 09:45:02 --> Helper loaded: url_helper
INFO - 2024-05-27 09:45:02 --> Helper loaded: file_helper
INFO - 2024-05-27 09:45:02 --> Helper loaded: form_helper
INFO - 2024-05-27 09:45:02 --> Helper loaded: my_helper
INFO - 2024-05-27 09:45:02 --> Database Driver Class Initialized
INFO - 2024-05-27 09:45:02 --> Session: Class initialized using 'files' driver.
INFO - 2024-05-27 09:45:02 --> Controller Class Initialized
DEBUG - 2024-05-27 09:45:02 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/home/views/v_home_guru.php
DEBUG - 2024-05-27 09:45:02 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-05-27 09:45:02 --> Final output sent to browser
DEBUG - 2024-05-27 09:45:02 --> Total execution time: 0.0512
INFO - 2024-05-27 09:45:05 --> Config Class Initialized
INFO - 2024-05-27 09:45:05 --> Hooks Class Initialized
DEBUG - 2024-05-27 09:45:05 --> UTF-8 Support Enabled
INFO - 2024-05-27 09:45:05 --> Utf8 Class Initialized
INFO - 2024-05-27 09:45:05 --> URI Class Initialized
INFO - 2024-05-27 09:45:05 --> Router Class Initialized
INFO - 2024-05-27 09:45:05 --> Output Class Initialized
INFO - 2024-05-27 09:45:05 --> Security Class Initialized
DEBUG - 2024-05-27 09:45:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-05-27 09:45:05 --> Input Class Initialized
INFO - 2024-05-27 09:45:05 --> Language Class Initialized
INFO - 2024-05-27 09:45:05 --> Language Class Initialized
INFO - 2024-05-27 09:45:05 --> Config Class Initialized
INFO - 2024-05-27 09:45:05 --> Loader Class Initialized
INFO - 2024-05-27 09:45:05 --> Helper loaded: url_helper
INFO - 2024-05-27 09:45:05 --> Helper loaded: file_helper
INFO - 2024-05-27 09:45:05 --> Helper loaded: form_helper
INFO - 2024-05-27 09:45:05 --> Helper loaded: my_helper
INFO - 2024-05-27 09:45:05 --> Database Driver Class Initialized
INFO - 2024-05-27 09:45:05 --> Session: Class initialized using 'files' driver.
INFO - 2024-05-27 09:45:05 --> Controller Class Initialized
DEBUG - 2024-05-27 09:45:05 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/view_mapel/views/v_view_mapel.php
DEBUG - 2024-05-27 09:45:05 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-05-27 09:45:05 --> Final output sent to browser
DEBUG - 2024-05-27 09:45:05 --> Total execution time: 0.0362
INFO - 2024-05-27 09:45:20 --> Config Class Initialized
INFO - 2024-05-27 09:45:20 --> Hooks Class Initialized
DEBUG - 2024-05-27 09:45:20 --> UTF-8 Support Enabled
INFO - 2024-05-27 09:45:20 --> Utf8 Class Initialized
INFO - 2024-05-27 09:45:20 --> URI Class Initialized
INFO - 2024-05-27 09:45:20 --> Router Class Initialized
INFO - 2024-05-27 09:45:20 --> Output Class Initialized
INFO - 2024-05-27 09:45:20 --> Security Class Initialized
DEBUG - 2024-05-27 09:45:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-05-27 09:45:20 --> Input Class Initialized
INFO - 2024-05-27 09:45:20 --> Language Class Initialized
INFO - 2024-05-27 09:45:20 --> Language Class Initialized
INFO - 2024-05-27 09:45:20 --> Config Class Initialized
INFO - 2024-05-27 09:45:20 --> Loader Class Initialized
INFO - 2024-05-27 09:45:20 --> Helper loaded: url_helper
INFO - 2024-05-27 09:45:20 --> Helper loaded: file_helper
INFO - 2024-05-27 09:45:20 --> Helper loaded: form_helper
INFO - 2024-05-27 09:45:20 --> Helper loaded: my_helper
INFO - 2024-05-27 09:45:20 --> Database Driver Class Initialized
INFO - 2024-05-27 09:45:20 --> Session: Class initialized using 'files' driver.
INFO - 2024-05-27 09:45:20 --> Controller Class Initialized
DEBUG - 2024-05-27 09:45:20 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/login/views/login.php
DEBUG - 2024-05-27 09:45:20 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-05-27 09:45:20 --> Final output sent to browser
DEBUG - 2024-05-27 09:45:20 --> Total execution time: 0.0786
