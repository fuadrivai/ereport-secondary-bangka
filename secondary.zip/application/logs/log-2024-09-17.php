<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2024-09-17 11:29:01 --> Config Class Initialized
INFO - 2024-09-17 11:29:01 --> Hooks Class Initialized
DEBUG - 2024-09-17 11:29:01 --> UTF-8 Support Enabled
INFO - 2024-09-17 11:29:01 --> Utf8 Class Initialized
INFO - 2024-09-17 11:29:01 --> URI Class Initialized
INFO - 2024-09-17 11:29:02 --> Router Class Initialized
INFO - 2024-09-17 11:29:02 --> Output Class Initialized
INFO - 2024-09-17 11:29:02 --> Security Class Initialized
DEBUG - 2024-09-17 11:29:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-17 11:29:02 --> Input Class Initialized
INFO - 2024-09-17 11:29:02 --> Language Class Initialized
INFO - 2024-09-17 11:29:02 --> Language Class Initialized
INFO - 2024-09-17 11:29:02 --> Config Class Initialized
INFO - 2024-09-17 11:29:02 --> Loader Class Initialized
INFO - 2024-09-17 11:29:02 --> Helper loaded: url_helper
INFO - 2024-09-17 11:29:02 --> Helper loaded: file_helper
INFO - 2024-09-17 11:29:02 --> Helper loaded: form_helper
INFO - 2024-09-17 11:29:02 --> Helper loaded: my_helper
INFO - 2024-09-17 11:29:02 --> Database Driver Class Initialized
INFO - 2024-09-17 11:29:02 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-17 11:29:02 --> Controller Class Initialized
INFO - 2024-09-17 11:29:02 --> Final output sent to browser
DEBUG - 2024-09-17 11:29:02 --> Total execution time: 0.3290
INFO - 2024-09-17 11:29:07 --> Config Class Initialized
INFO - 2024-09-17 11:29:07 --> Hooks Class Initialized
DEBUG - 2024-09-17 11:29:07 --> UTF-8 Support Enabled
INFO - 2024-09-17 11:29:07 --> Utf8 Class Initialized
INFO - 2024-09-17 11:29:07 --> URI Class Initialized
INFO - 2024-09-17 11:29:07 --> Router Class Initialized
INFO - 2024-09-17 11:29:07 --> Output Class Initialized
INFO - 2024-09-17 11:29:07 --> Security Class Initialized
DEBUG - 2024-09-17 11:29:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-17 11:29:07 --> Input Class Initialized
INFO - 2024-09-17 11:29:07 --> Language Class Initialized
INFO - 2024-09-17 11:29:07 --> Language Class Initialized
INFO - 2024-09-17 11:29:07 --> Config Class Initialized
INFO - 2024-09-17 11:29:07 --> Loader Class Initialized
INFO - 2024-09-17 11:29:07 --> Helper loaded: url_helper
INFO - 2024-09-17 11:29:07 --> Helper loaded: file_helper
INFO - 2024-09-17 11:29:07 --> Helper loaded: form_helper
INFO - 2024-09-17 11:29:07 --> Helper loaded: my_helper
INFO - 2024-09-17 11:29:07 --> Database Driver Class Initialized
INFO - 2024-09-17 11:29:07 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-17 11:29:07 --> Controller Class Initialized
INFO - 2024-09-17 11:29:07 --> Final output sent to browser
DEBUG - 2024-09-17 11:29:07 --> Total execution time: 0.0295
INFO - 2024-09-17 12:20:38 --> Config Class Initialized
INFO - 2024-09-17 12:20:38 --> Hooks Class Initialized
DEBUG - 2024-09-17 12:20:38 --> UTF-8 Support Enabled
INFO - 2024-09-17 12:20:38 --> Utf8 Class Initialized
INFO - 2024-09-17 12:20:38 --> URI Class Initialized
INFO - 2024-09-17 12:20:38 --> Router Class Initialized
INFO - 2024-09-17 12:20:38 --> Output Class Initialized
INFO - 2024-09-17 12:20:38 --> Security Class Initialized
DEBUG - 2024-09-17 12:20:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-17 12:20:38 --> Input Class Initialized
INFO - 2024-09-17 12:20:38 --> Language Class Initialized
INFO - 2024-09-17 12:20:38 --> Language Class Initialized
INFO - 2024-09-17 12:20:38 --> Config Class Initialized
INFO - 2024-09-17 12:20:38 --> Loader Class Initialized
INFO - 2024-09-17 12:20:38 --> Helper loaded: url_helper
INFO - 2024-09-17 12:20:38 --> Helper loaded: file_helper
INFO - 2024-09-17 12:20:38 --> Helper loaded: form_helper
INFO - 2024-09-17 12:20:38 --> Helper loaded: my_helper
INFO - 2024-09-17 12:20:38 --> Database Driver Class Initialized
INFO - 2024-09-17 12:20:38 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-17 12:20:38 --> Controller Class Initialized
DEBUG - 2024-09-17 12:20:38 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/login/views/login.php
DEBUG - 2024-09-17 12:20:38 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-09-17 12:20:38 --> Final output sent to browser
DEBUG - 2024-09-17 12:20:38 --> Total execution time: 0.0535
INFO - 2024-09-17 12:21:55 --> Config Class Initialized
INFO - 2024-09-17 12:21:55 --> Hooks Class Initialized
DEBUG - 2024-09-17 12:21:55 --> UTF-8 Support Enabled
INFO - 2024-09-17 12:21:55 --> Utf8 Class Initialized
INFO - 2024-09-17 12:21:55 --> URI Class Initialized
INFO - 2024-09-17 12:21:55 --> Router Class Initialized
INFO - 2024-09-17 12:21:55 --> Output Class Initialized
INFO - 2024-09-17 12:21:55 --> Security Class Initialized
DEBUG - 2024-09-17 12:21:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-17 12:21:55 --> Input Class Initialized
INFO - 2024-09-17 12:21:55 --> Language Class Initialized
INFO - 2024-09-17 12:21:55 --> Language Class Initialized
INFO - 2024-09-17 12:21:55 --> Config Class Initialized
INFO - 2024-09-17 12:21:55 --> Loader Class Initialized
INFO - 2024-09-17 12:21:55 --> Helper loaded: url_helper
INFO - 2024-09-17 12:21:55 --> Helper loaded: file_helper
INFO - 2024-09-17 12:21:55 --> Helper loaded: form_helper
INFO - 2024-09-17 12:21:55 --> Helper loaded: my_helper
INFO - 2024-09-17 12:21:55 --> Database Driver Class Initialized
INFO - 2024-09-17 12:21:55 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-17 12:21:55 --> Controller Class Initialized
DEBUG - 2024-09-17 12:21:55 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/login/views/login.php
DEBUG - 2024-09-17 12:21:55 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-09-17 12:21:55 --> Final output sent to browser
DEBUG - 2024-09-17 12:21:55 --> Total execution time: 0.1956
INFO - 2024-09-17 12:22:31 --> Config Class Initialized
INFO - 2024-09-17 12:22:31 --> Hooks Class Initialized
DEBUG - 2024-09-17 12:22:31 --> UTF-8 Support Enabled
INFO - 2024-09-17 12:22:31 --> Utf8 Class Initialized
INFO - 2024-09-17 12:22:31 --> URI Class Initialized
INFO - 2024-09-17 12:22:31 --> Router Class Initialized
INFO - 2024-09-17 12:22:31 --> Output Class Initialized
INFO - 2024-09-17 12:22:31 --> Security Class Initialized
DEBUG - 2024-09-17 12:22:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-17 12:22:31 --> Input Class Initialized
INFO - 2024-09-17 12:22:31 --> Language Class Initialized
INFO - 2024-09-17 12:22:31 --> Language Class Initialized
INFO - 2024-09-17 12:22:31 --> Config Class Initialized
INFO - 2024-09-17 12:22:31 --> Loader Class Initialized
INFO - 2024-09-17 12:22:31 --> Helper loaded: url_helper
INFO - 2024-09-17 12:22:31 --> Helper loaded: file_helper
INFO - 2024-09-17 12:22:31 --> Helper loaded: form_helper
INFO - 2024-09-17 12:22:31 --> Helper loaded: my_helper
INFO - 2024-09-17 12:22:31 --> Database Driver Class Initialized
INFO - 2024-09-17 12:22:31 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-17 12:22:31 --> Controller Class Initialized
INFO - 2024-09-17 12:22:31 --> Final output sent to browser
DEBUG - 2024-09-17 12:22:31 --> Total execution time: 0.0329
INFO - 2024-09-17 12:22:38 --> Config Class Initialized
INFO - 2024-09-17 12:22:38 --> Hooks Class Initialized
DEBUG - 2024-09-17 12:22:38 --> UTF-8 Support Enabled
INFO - 2024-09-17 12:22:38 --> Utf8 Class Initialized
INFO - 2024-09-17 12:22:38 --> URI Class Initialized
INFO - 2024-09-17 12:22:38 --> Router Class Initialized
INFO - 2024-09-17 12:22:38 --> Output Class Initialized
INFO - 2024-09-17 12:22:38 --> Security Class Initialized
DEBUG - 2024-09-17 12:22:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-17 12:22:38 --> Input Class Initialized
INFO - 2024-09-17 12:22:38 --> Language Class Initialized
INFO - 2024-09-17 12:22:39 --> Language Class Initialized
INFO - 2024-09-17 12:22:39 --> Config Class Initialized
INFO - 2024-09-17 12:22:39 --> Loader Class Initialized
INFO - 2024-09-17 12:22:39 --> Helper loaded: url_helper
INFO - 2024-09-17 12:22:39 --> Helper loaded: file_helper
INFO - 2024-09-17 12:22:39 --> Helper loaded: form_helper
INFO - 2024-09-17 12:22:39 --> Helper loaded: my_helper
INFO - 2024-09-17 12:22:39 --> Database Driver Class Initialized
INFO - 2024-09-17 12:22:39 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-17 12:22:39 --> Controller Class Initialized
INFO - 2024-09-17 12:22:39 --> Final output sent to browser
DEBUG - 2024-09-17 12:22:39 --> Total execution time: 0.0305
INFO - 2024-09-17 12:34:41 --> Config Class Initialized
INFO - 2024-09-17 12:34:41 --> Hooks Class Initialized
DEBUG - 2024-09-17 12:34:41 --> UTF-8 Support Enabled
INFO - 2024-09-17 12:34:41 --> Utf8 Class Initialized
INFO - 2024-09-17 12:34:41 --> URI Class Initialized
INFO - 2024-09-17 12:34:41 --> Router Class Initialized
INFO - 2024-09-17 12:34:41 --> Output Class Initialized
INFO - 2024-09-17 12:34:41 --> Security Class Initialized
DEBUG - 2024-09-17 12:34:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-17 12:34:41 --> Input Class Initialized
INFO - 2024-09-17 12:34:41 --> Language Class Initialized
INFO - 2024-09-17 12:34:41 --> Language Class Initialized
INFO - 2024-09-17 12:34:41 --> Config Class Initialized
INFO - 2024-09-17 12:34:41 --> Loader Class Initialized
INFO - 2024-09-17 12:34:41 --> Helper loaded: url_helper
INFO - 2024-09-17 12:34:41 --> Helper loaded: file_helper
INFO - 2024-09-17 12:34:41 --> Helper loaded: form_helper
INFO - 2024-09-17 12:34:41 --> Helper loaded: my_helper
INFO - 2024-09-17 12:34:41 --> Database Driver Class Initialized
INFO - 2024-09-17 12:34:41 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-17 12:34:41 --> Controller Class Initialized
DEBUG - 2024-09-17 12:34:41 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/login/views/login.php
DEBUG - 2024-09-17 12:34:41 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-09-17 12:34:41 --> Final output sent to browser
DEBUG - 2024-09-17 12:34:41 --> Total execution time: 0.0271
INFO - 2024-09-17 12:34:47 --> Config Class Initialized
INFO - 2024-09-17 12:34:47 --> Hooks Class Initialized
DEBUG - 2024-09-17 12:34:47 --> UTF-8 Support Enabled
INFO - 2024-09-17 12:34:47 --> Utf8 Class Initialized
INFO - 2024-09-17 12:34:47 --> URI Class Initialized
INFO - 2024-09-17 12:34:47 --> Router Class Initialized
INFO - 2024-09-17 12:34:47 --> Output Class Initialized
INFO - 2024-09-17 12:34:47 --> Security Class Initialized
DEBUG - 2024-09-17 12:34:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-17 12:34:47 --> Input Class Initialized
INFO - 2024-09-17 12:34:47 --> Language Class Initialized
INFO - 2024-09-17 12:34:47 --> Language Class Initialized
INFO - 2024-09-17 12:34:47 --> Config Class Initialized
INFO - 2024-09-17 12:34:47 --> Loader Class Initialized
INFO - 2024-09-17 12:34:47 --> Helper loaded: url_helper
INFO - 2024-09-17 12:34:47 --> Helper loaded: file_helper
INFO - 2024-09-17 12:34:47 --> Helper loaded: form_helper
INFO - 2024-09-17 12:34:47 --> Helper loaded: my_helper
INFO - 2024-09-17 12:34:47 --> Database Driver Class Initialized
INFO - 2024-09-17 12:34:47 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-17 12:34:47 --> Controller Class Initialized
INFO - 2024-09-17 12:34:47 --> Helper loaded: cookie_helper
INFO - 2024-09-17 12:34:47 --> Final output sent to browser
DEBUG - 2024-09-17 12:34:47 --> Total execution time: 0.0400
INFO - 2024-09-17 12:34:47 --> Config Class Initialized
INFO - 2024-09-17 12:34:47 --> Hooks Class Initialized
DEBUG - 2024-09-17 12:34:47 --> UTF-8 Support Enabled
INFO - 2024-09-17 12:34:47 --> Utf8 Class Initialized
INFO - 2024-09-17 12:34:47 --> URI Class Initialized
INFO - 2024-09-17 12:34:47 --> Router Class Initialized
INFO - 2024-09-17 12:34:47 --> Output Class Initialized
INFO - 2024-09-17 12:34:47 --> Security Class Initialized
DEBUG - 2024-09-17 12:34:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-17 12:34:47 --> Input Class Initialized
INFO - 2024-09-17 12:34:47 --> Language Class Initialized
INFO - 2024-09-17 12:34:47 --> Language Class Initialized
INFO - 2024-09-17 12:34:47 --> Config Class Initialized
INFO - 2024-09-17 12:34:47 --> Loader Class Initialized
INFO - 2024-09-17 12:34:47 --> Helper loaded: url_helper
INFO - 2024-09-17 12:34:47 --> Helper loaded: file_helper
INFO - 2024-09-17 12:34:47 --> Helper loaded: form_helper
INFO - 2024-09-17 12:34:47 --> Helper loaded: my_helper
INFO - 2024-09-17 12:34:47 --> Database Driver Class Initialized
INFO - 2024-09-17 12:34:47 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-17 12:34:47 --> Controller Class Initialized
DEBUG - 2024-09-17 12:34:47 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/home/views/v_home.php
DEBUG - 2024-09-17 12:34:47 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-09-17 12:34:47 --> Final output sent to browser
DEBUG - 2024-09-17 12:34:47 --> Total execution time: 0.2535
INFO - 2024-09-17 12:35:02 --> Config Class Initialized
INFO - 2024-09-17 12:35:02 --> Hooks Class Initialized
DEBUG - 2024-09-17 12:35:02 --> UTF-8 Support Enabled
INFO - 2024-09-17 12:35:02 --> Utf8 Class Initialized
INFO - 2024-09-17 12:35:02 --> URI Class Initialized
INFO - 2024-09-17 12:35:02 --> Router Class Initialized
INFO - 2024-09-17 12:35:02 --> Output Class Initialized
INFO - 2024-09-17 12:35:02 --> Security Class Initialized
DEBUG - 2024-09-17 12:35:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-17 12:35:02 --> Input Class Initialized
INFO - 2024-09-17 12:35:02 --> Language Class Initialized
INFO - 2024-09-17 12:35:02 --> Language Class Initialized
INFO - 2024-09-17 12:35:02 --> Config Class Initialized
INFO - 2024-09-17 12:35:02 --> Loader Class Initialized
INFO - 2024-09-17 12:35:02 --> Helper loaded: url_helper
INFO - 2024-09-17 12:35:02 --> Helper loaded: file_helper
INFO - 2024-09-17 12:35:02 --> Helper loaded: form_helper
INFO - 2024-09-17 12:35:02 --> Helper loaded: my_helper
INFO - 2024-09-17 12:35:02 --> Database Driver Class Initialized
INFO - 2024-09-17 12:35:02 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-17 12:35:02 --> Controller Class Initialized
DEBUG - 2024-09-17 12:35:02 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/data_guru/views/list.php
DEBUG - 2024-09-17 12:35:02 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-09-17 12:35:02 --> Final output sent to browser
DEBUG - 2024-09-17 12:35:02 --> Total execution time: 0.0391
INFO - 2024-09-17 12:35:02 --> Config Class Initialized
INFO - 2024-09-17 12:35:02 --> Hooks Class Initialized
DEBUG - 2024-09-17 12:35:02 --> UTF-8 Support Enabled
INFO - 2024-09-17 12:35:02 --> Utf8 Class Initialized
INFO - 2024-09-17 12:35:02 --> URI Class Initialized
INFO - 2024-09-17 12:35:02 --> Router Class Initialized
INFO - 2024-09-17 12:35:02 --> Output Class Initialized
INFO - 2024-09-17 12:35:02 --> Security Class Initialized
DEBUG - 2024-09-17 12:35:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-17 12:35:02 --> Input Class Initialized
INFO - 2024-09-17 12:35:02 --> Language Class Initialized
ERROR - 2024-09-17 12:35:02 --> 404 Page Not Found: /index
INFO - 2024-09-17 12:35:02 --> Config Class Initialized
INFO - 2024-09-17 12:35:02 --> Hooks Class Initialized
DEBUG - 2024-09-17 12:35:02 --> UTF-8 Support Enabled
INFO - 2024-09-17 12:35:02 --> Utf8 Class Initialized
INFO - 2024-09-17 12:35:02 --> URI Class Initialized
INFO - 2024-09-17 12:35:02 --> Router Class Initialized
INFO - 2024-09-17 12:35:02 --> Output Class Initialized
INFO - 2024-09-17 12:35:02 --> Security Class Initialized
DEBUG - 2024-09-17 12:35:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-17 12:35:02 --> Input Class Initialized
INFO - 2024-09-17 12:35:02 --> Language Class Initialized
INFO - 2024-09-17 12:35:02 --> Language Class Initialized
INFO - 2024-09-17 12:35:02 --> Config Class Initialized
INFO - 2024-09-17 12:35:02 --> Loader Class Initialized
INFO - 2024-09-17 12:35:02 --> Helper loaded: url_helper
INFO - 2024-09-17 12:35:02 --> Helper loaded: file_helper
INFO - 2024-09-17 12:35:02 --> Helper loaded: form_helper
INFO - 2024-09-17 12:35:02 --> Helper loaded: my_helper
INFO - 2024-09-17 12:35:02 --> Database Driver Class Initialized
INFO - 2024-09-17 12:35:02 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-17 12:35:02 --> Controller Class Initialized
INFO - 2024-09-17 12:35:05 --> Config Class Initialized
INFO - 2024-09-17 12:35:05 --> Hooks Class Initialized
DEBUG - 2024-09-17 12:35:05 --> UTF-8 Support Enabled
INFO - 2024-09-17 12:35:05 --> Utf8 Class Initialized
INFO - 2024-09-17 12:35:05 --> URI Class Initialized
INFO - 2024-09-17 12:35:05 --> Router Class Initialized
INFO - 2024-09-17 12:35:05 --> Output Class Initialized
INFO - 2024-09-17 12:35:05 --> Security Class Initialized
DEBUG - 2024-09-17 12:35:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-17 12:35:05 --> Input Class Initialized
INFO - 2024-09-17 12:35:05 --> Language Class Initialized
INFO - 2024-09-17 12:35:05 --> Language Class Initialized
INFO - 2024-09-17 12:35:05 --> Config Class Initialized
INFO - 2024-09-17 12:35:05 --> Loader Class Initialized
INFO - 2024-09-17 12:35:05 --> Helper loaded: url_helper
INFO - 2024-09-17 12:35:05 --> Helper loaded: file_helper
INFO - 2024-09-17 12:35:05 --> Helper loaded: form_helper
INFO - 2024-09-17 12:35:05 --> Helper loaded: my_helper
INFO - 2024-09-17 12:35:05 --> Database Driver Class Initialized
INFO - 2024-09-17 12:35:05 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-17 12:35:05 --> Controller Class Initialized
INFO - 2024-09-17 12:35:05 --> Final output sent to browser
DEBUG - 2024-09-17 12:35:05 --> Total execution time: 0.0296
INFO - 2024-09-17 12:36:20 --> Config Class Initialized
INFO - 2024-09-17 12:36:20 --> Hooks Class Initialized
DEBUG - 2024-09-17 12:36:20 --> UTF-8 Support Enabled
INFO - 2024-09-17 12:36:20 --> Utf8 Class Initialized
INFO - 2024-09-17 12:36:20 --> URI Class Initialized
INFO - 2024-09-17 12:36:20 --> Router Class Initialized
INFO - 2024-09-17 12:36:20 --> Output Class Initialized
INFO - 2024-09-17 12:36:20 --> Security Class Initialized
DEBUG - 2024-09-17 12:36:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-17 12:36:20 --> Input Class Initialized
INFO - 2024-09-17 12:36:20 --> Language Class Initialized
INFO - 2024-09-17 12:36:20 --> Language Class Initialized
INFO - 2024-09-17 12:36:20 --> Config Class Initialized
INFO - 2024-09-17 12:36:20 --> Loader Class Initialized
INFO - 2024-09-17 12:36:20 --> Helper loaded: url_helper
INFO - 2024-09-17 12:36:20 --> Helper loaded: file_helper
INFO - 2024-09-17 12:36:20 --> Helper loaded: form_helper
INFO - 2024-09-17 12:36:20 --> Helper loaded: my_helper
INFO - 2024-09-17 12:36:20 --> Database Driver Class Initialized
INFO - 2024-09-17 12:36:20 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-17 12:36:20 --> Controller Class Initialized
INFO - 2024-09-17 12:36:20 --> Final output sent to browser
DEBUG - 2024-09-17 12:36:20 --> Total execution time: 0.0289
INFO - 2024-09-17 12:37:32 --> Config Class Initialized
INFO - 2024-09-17 12:37:32 --> Hooks Class Initialized
DEBUG - 2024-09-17 12:37:32 --> UTF-8 Support Enabled
INFO - 2024-09-17 12:37:32 --> Utf8 Class Initialized
INFO - 2024-09-17 12:37:32 --> URI Class Initialized
INFO - 2024-09-17 12:37:32 --> Router Class Initialized
INFO - 2024-09-17 12:37:32 --> Output Class Initialized
INFO - 2024-09-17 12:37:32 --> Security Class Initialized
DEBUG - 2024-09-17 12:37:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-17 12:37:32 --> Input Class Initialized
INFO - 2024-09-17 12:37:32 --> Language Class Initialized
INFO - 2024-09-17 12:37:32 --> Language Class Initialized
INFO - 2024-09-17 12:37:32 --> Config Class Initialized
INFO - 2024-09-17 12:37:32 --> Loader Class Initialized
INFO - 2024-09-17 12:37:32 --> Helper loaded: url_helper
INFO - 2024-09-17 12:37:32 --> Helper loaded: file_helper
INFO - 2024-09-17 12:37:32 --> Helper loaded: form_helper
INFO - 2024-09-17 12:37:32 --> Helper loaded: my_helper
INFO - 2024-09-17 12:37:32 --> Database Driver Class Initialized
INFO - 2024-09-17 12:37:32 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-17 12:37:32 --> Controller Class Initialized
DEBUG - 2024-09-17 12:37:32 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/set_mapel/views/list.php
DEBUG - 2024-09-17 12:37:32 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-09-17 12:37:32 --> Final output sent to browser
DEBUG - 2024-09-17 12:37:32 --> Total execution time: 0.0342
INFO - 2024-09-17 12:37:32 --> Config Class Initialized
INFO - 2024-09-17 12:37:32 --> Hooks Class Initialized
DEBUG - 2024-09-17 12:37:32 --> UTF-8 Support Enabled
INFO - 2024-09-17 12:37:32 --> Utf8 Class Initialized
INFO - 2024-09-17 12:37:32 --> URI Class Initialized
INFO - 2024-09-17 12:37:32 --> Router Class Initialized
INFO - 2024-09-17 12:37:32 --> Output Class Initialized
INFO - 2024-09-17 12:37:32 --> Security Class Initialized
DEBUG - 2024-09-17 12:37:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-17 12:37:32 --> Input Class Initialized
INFO - 2024-09-17 12:37:32 --> Language Class Initialized
ERROR - 2024-09-17 12:37:32 --> 404 Page Not Found: /index
INFO - 2024-09-17 12:37:32 --> Config Class Initialized
INFO - 2024-09-17 12:37:32 --> Hooks Class Initialized
DEBUG - 2024-09-17 12:37:32 --> UTF-8 Support Enabled
INFO - 2024-09-17 12:37:32 --> Utf8 Class Initialized
INFO - 2024-09-17 12:37:32 --> URI Class Initialized
INFO - 2024-09-17 12:37:32 --> Router Class Initialized
INFO - 2024-09-17 12:37:32 --> Output Class Initialized
INFO - 2024-09-17 12:37:32 --> Security Class Initialized
DEBUG - 2024-09-17 12:37:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-17 12:37:32 --> Input Class Initialized
INFO - 2024-09-17 12:37:32 --> Language Class Initialized
INFO - 2024-09-17 12:37:32 --> Language Class Initialized
INFO - 2024-09-17 12:37:32 --> Config Class Initialized
INFO - 2024-09-17 12:37:32 --> Loader Class Initialized
INFO - 2024-09-17 12:37:32 --> Helper loaded: url_helper
INFO - 2024-09-17 12:37:32 --> Helper loaded: file_helper
INFO - 2024-09-17 12:37:32 --> Helper loaded: form_helper
INFO - 2024-09-17 12:37:32 --> Helper loaded: my_helper
INFO - 2024-09-17 12:37:32 --> Database Driver Class Initialized
INFO - 2024-09-17 12:37:32 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-17 12:37:32 --> Controller Class Initialized
INFO - 2024-09-17 12:37:35 --> Config Class Initialized
INFO - 2024-09-17 12:37:35 --> Hooks Class Initialized
DEBUG - 2024-09-17 12:37:35 --> UTF-8 Support Enabled
INFO - 2024-09-17 12:37:35 --> Utf8 Class Initialized
INFO - 2024-09-17 12:37:35 --> URI Class Initialized
INFO - 2024-09-17 12:37:35 --> Router Class Initialized
INFO - 2024-09-17 12:37:35 --> Output Class Initialized
INFO - 2024-09-17 12:37:35 --> Security Class Initialized
DEBUG - 2024-09-17 12:37:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-17 12:37:35 --> Input Class Initialized
INFO - 2024-09-17 12:37:35 --> Language Class Initialized
INFO - 2024-09-17 12:37:35 --> Language Class Initialized
INFO - 2024-09-17 12:37:35 --> Config Class Initialized
INFO - 2024-09-17 12:37:35 --> Loader Class Initialized
INFO - 2024-09-17 12:37:35 --> Helper loaded: url_helper
INFO - 2024-09-17 12:37:35 --> Helper loaded: file_helper
INFO - 2024-09-17 12:37:35 --> Helper loaded: form_helper
INFO - 2024-09-17 12:37:35 --> Helper loaded: my_helper
INFO - 2024-09-17 12:37:35 --> Database Driver Class Initialized
INFO - 2024-09-17 12:37:35 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-17 12:37:35 --> Controller Class Initialized
DEBUG - 2024-09-17 12:37:35 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/set_mapel/views/form.php
DEBUG - 2024-09-17 12:37:35 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-09-17 12:37:35 --> Final output sent to browser
DEBUG - 2024-09-17 12:37:35 --> Total execution time: 0.0303
INFO - 2024-09-17 12:37:51 --> Config Class Initialized
INFO - 2024-09-17 12:37:51 --> Hooks Class Initialized
DEBUG - 2024-09-17 12:37:51 --> UTF-8 Support Enabled
INFO - 2024-09-17 12:37:51 --> Utf8 Class Initialized
INFO - 2024-09-17 12:37:51 --> URI Class Initialized
INFO - 2024-09-17 12:37:51 --> Router Class Initialized
INFO - 2024-09-17 12:37:51 --> Output Class Initialized
INFO - 2024-09-17 12:37:51 --> Security Class Initialized
DEBUG - 2024-09-17 12:37:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-17 12:37:51 --> Input Class Initialized
INFO - 2024-09-17 12:37:51 --> Language Class Initialized
INFO - 2024-09-17 12:37:51 --> Language Class Initialized
INFO - 2024-09-17 12:37:51 --> Config Class Initialized
INFO - 2024-09-17 12:37:51 --> Loader Class Initialized
INFO - 2024-09-17 12:37:51 --> Helper loaded: url_helper
INFO - 2024-09-17 12:37:51 --> Helper loaded: file_helper
INFO - 2024-09-17 12:37:51 --> Helper loaded: form_helper
INFO - 2024-09-17 12:37:51 --> Helper loaded: my_helper
INFO - 2024-09-17 12:37:51 --> Database Driver Class Initialized
INFO - 2024-09-17 12:37:51 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-17 12:37:51 --> Controller Class Initialized
DEBUG - 2024-09-17 12:37:51 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/set_mapel/views/list.php
DEBUG - 2024-09-17 12:37:51 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-09-17 12:37:51 --> Final output sent to browser
DEBUG - 2024-09-17 12:37:51 --> Total execution time: 0.0302
INFO - 2024-09-17 12:37:51 --> Config Class Initialized
INFO - 2024-09-17 12:37:51 --> Hooks Class Initialized
DEBUG - 2024-09-17 12:37:51 --> UTF-8 Support Enabled
INFO - 2024-09-17 12:37:51 --> Utf8 Class Initialized
INFO - 2024-09-17 12:37:51 --> URI Class Initialized
INFO - 2024-09-17 12:37:51 --> Router Class Initialized
INFO - 2024-09-17 12:37:51 --> Output Class Initialized
INFO - 2024-09-17 12:37:51 --> Security Class Initialized
DEBUG - 2024-09-17 12:37:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-17 12:37:51 --> Input Class Initialized
INFO - 2024-09-17 12:37:51 --> Language Class Initialized
ERROR - 2024-09-17 12:37:51 --> 404 Page Not Found: /index
INFO - 2024-09-17 12:37:51 --> Config Class Initialized
INFO - 2024-09-17 12:37:51 --> Hooks Class Initialized
DEBUG - 2024-09-17 12:37:51 --> UTF-8 Support Enabled
INFO - 2024-09-17 12:37:51 --> Utf8 Class Initialized
INFO - 2024-09-17 12:37:51 --> URI Class Initialized
INFO - 2024-09-17 12:37:51 --> Router Class Initialized
INFO - 2024-09-17 12:37:51 --> Output Class Initialized
INFO - 2024-09-17 12:37:51 --> Security Class Initialized
DEBUG - 2024-09-17 12:37:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-17 12:37:51 --> Input Class Initialized
INFO - 2024-09-17 12:37:51 --> Language Class Initialized
INFO - 2024-09-17 12:37:51 --> Language Class Initialized
INFO - 2024-09-17 12:37:51 --> Config Class Initialized
INFO - 2024-09-17 12:37:51 --> Loader Class Initialized
INFO - 2024-09-17 12:37:51 --> Helper loaded: url_helper
INFO - 2024-09-17 12:37:51 --> Helper loaded: file_helper
INFO - 2024-09-17 12:37:51 --> Helper loaded: form_helper
INFO - 2024-09-17 12:37:51 --> Helper loaded: my_helper
INFO - 2024-09-17 12:37:51 --> Database Driver Class Initialized
INFO - 2024-09-17 12:37:51 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-17 12:37:51 --> Controller Class Initialized
INFO - 2024-09-17 12:38:01 --> Config Class Initialized
INFO - 2024-09-17 12:38:01 --> Hooks Class Initialized
DEBUG - 2024-09-17 12:38:01 --> UTF-8 Support Enabled
INFO - 2024-09-17 12:38:01 --> Utf8 Class Initialized
INFO - 2024-09-17 12:38:01 --> URI Class Initialized
INFO - 2024-09-17 12:38:01 --> Router Class Initialized
INFO - 2024-09-17 12:38:01 --> Output Class Initialized
INFO - 2024-09-17 12:38:01 --> Security Class Initialized
DEBUG - 2024-09-17 12:38:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-17 12:38:01 --> Input Class Initialized
INFO - 2024-09-17 12:38:01 --> Language Class Initialized
INFO - 2024-09-17 12:38:01 --> Language Class Initialized
INFO - 2024-09-17 12:38:01 --> Config Class Initialized
INFO - 2024-09-17 12:38:01 --> Loader Class Initialized
INFO - 2024-09-17 12:38:01 --> Helper loaded: url_helper
INFO - 2024-09-17 12:38:01 --> Helper loaded: file_helper
INFO - 2024-09-17 12:38:01 --> Helper loaded: form_helper
INFO - 2024-09-17 12:38:01 --> Helper loaded: my_helper
INFO - 2024-09-17 12:38:01 --> Database Driver Class Initialized
INFO - 2024-09-17 12:38:01 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-17 12:38:01 --> Controller Class Initialized
DEBUG - 2024-09-17 12:38:01 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/set_walikelas/views/list.php
DEBUG - 2024-09-17 12:38:01 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-09-17 12:38:01 --> Final output sent to browser
DEBUG - 2024-09-17 12:38:01 --> Total execution time: 0.0804
INFO - 2024-09-17 12:38:02 --> Config Class Initialized
INFO - 2024-09-17 12:38:02 --> Hooks Class Initialized
DEBUG - 2024-09-17 12:38:02 --> UTF-8 Support Enabled
INFO - 2024-09-17 12:38:02 --> Utf8 Class Initialized
INFO - 2024-09-17 12:38:02 --> URI Class Initialized
INFO - 2024-09-17 12:38:02 --> Router Class Initialized
INFO - 2024-09-17 12:38:02 --> Output Class Initialized
INFO - 2024-09-17 12:38:02 --> Security Class Initialized
DEBUG - 2024-09-17 12:38:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-17 12:38:02 --> Input Class Initialized
INFO - 2024-09-17 12:38:02 --> Language Class Initialized
ERROR - 2024-09-17 12:38:02 --> 404 Page Not Found: /index
INFO - 2024-09-17 12:38:02 --> Config Class Initialized
INFO - 2024-09-17 12:38:02 --> Hooks Class Initialized
DEBUG - 2024-09-17 12:38:02 --> UTF-8 Support Enabled
INFO - 2024-09-17 12:38:02 --> Utf8 Class Initialized
INFO - 2024-09-17 12:38:02 --> URI Class Initialized
INFO - 2024-09-17 12:38:02 --> Router Class Initialized
INFO - 2024-09-17 12:38:02 --> Output Class Initialized
INFO - 2024-09-17 12:38:02 --> Security Class Initialized
DEBUG - 2024-09-17 12:38:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-17 12:38:02 --> Input Class Initialized
INFO - 2024-09-17 12:38:02 --> Language Class Initialized
INFO - 2024-09-17 12:38:02 --> Language Class Initialized
INFO - 2024-09-17 12:38:02 --> Config Class Initialized
INFO - 2024-09-17 12:38:02 --> Loader Class Initialized
INFO - 2024-09-17 12:38:02 --> Helper loaded: url_helper
INFO - 2024-09-17 12:38:02 --> Helper loaded: file_helper
INFO - 2024-09-17 12:38:02 --> Helper loaded: form_helper
INFO - 2024-09-17 12:38:02 --> Helper loaded: my_helper
INFO - 2024-09-17 12:38:02 --> Database Driver Class Initialized
INFO - 2024-09-17 12:38:02 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-17 12:38:02 --> Controller Class Initialized
INFO - 2024-09-17 12:38:07 --> Config Class Initialized
INFO - 2024-09-17 12:38:07 --> Hooks Class Initialized
DEBUG - 2024-09-17 12:38:07 --> UTF-8 Support Enabled
INFO - 2024-09-17 12:38:07 --> Utf8 Class Initialized
INFO - 2024-09-17 12:38:07 --> URI Class Initialized
INFO - 2024-09-17 12:38:07 --> Router Class Initialized
INFO - 2024-09-17 12:38:07 --> Output Class Initialized
INFO - 2024-09-17 12:38:07 --> Security Class Initialized
DEBUG - 2024-09-17 12:38:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-17 12:38:07 --> Input Class Initialized
INFO - 2024-09-17 12:38:07 --> Language Class Initialized
INFO - 2024-09-17 12:38:07 --> Language Class Initialized
INFO - 2024-09-17 12:38:07 --> Config Class Initialized
INFO - 2024-09-17 12:38:07 --> Loader Class Initialized
INFO - 2024-09-17 12:38:07 --> Helper loaded: url_helper
INFO - 2024-09-17 12:38:07 --> Helper loaded: file_helper
INFO - 2024-09-17 12:38:07 --> Helper loaded: form_helper
INFO - 2024-09-17 12:38:07 --> Helper loaded: my_helper
INFO - 2024-09-17 12:38:07 --> Database Driver Class Initialized
INFO - 2024-09-17 12:38:07 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-17 12:38:07 --> Controller Class Initialized
DEBUG - 2024-09-17 12:38:07 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/data_siswa/views/list.php
DEBUG - 2024-09-17 12:38:07 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-09-17 12:38:07 --> Final output sent to browser
DEBUG - 2024-09-17 12:38:07 --> Total execution time: 0.1029
INFO - 2024-09-17 12:38:07 --> Config Class Initialized
INFO - 2024-09-17 12:38:07 --> Hooks Class Initialized
DEBUG - 2024-09-17 12:38:07 --> UTF-8 Support Enabled
INFO - 2024-09-17 12:38:07 --> Utf8 Class Initialized
INFO - 2024-09-17 12:38:07 --> URI Class Initialized
INFO - 2024-09-17 12:38:07 --> Router Class Initialized
INFO - 2024-09-17 12:38:07 --> Output Class Initialized
INFO - 2024-09-17 12:38:07 --> Security Class Initialized
DEBUG - 2024-09-17 12:38:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-17 12:38:07 --> Input Class Initialized
INFO - 2024-09-17 12:38:07 --> Language Class Initialized
ERROR - 2024-09-17 12:38:07 --> 404 Page Not Found: /index
INFO - 2024-09-17 12:38:07 --> Config Class Initialized
INFO - 2024-09-17 12:38:07 --> Hooks Class Initialized
DEBUG - 2024-09-17 12:38:07 --> UTF-8 Support Enabled
INFO - 2024-09-17 12:38:07 --> Utf8 Class Initialized
INFO - 2024-09-17 12:38:07 --> URI Class Initialized
INFO - 2024-09-17 12:38:07 --> Router Class Initialized
INFO - 2024-09-17 12:38:07 --> Output Class Initialized
INFO - 2024-09-17 12:38:07 --> Security Class Initialized
DEBUG - 2024-09-17 12:38:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-17 12:38:07 --> Input Class Initialized
INFO - 2024-09-17 12:38:07 --> Language Class Initialized
INFO - 2024-09-17 12:38:07 --> Language Class Initialized
INFO - 2024-09-17 12:38:07 --> Config Class Initialized
INFO - 2024-09-17 12:38:07 --> Loader Class Initialized
INFO - 2024-09-17 12:38:07 --> Helper loaded: url_helper
INFO - 2024-09-17 12:38:07 --> Helper loaded: file_helper
INFO - 2024-09-17 12:38:07 --> Helper loaded: form_helper
INFO - 2024-09-17 12:38:07 --> Helper loaded: my_helper
INFO - 2024-09-17 12:38:07 --> Database Driver Class Initialized
INFO - 2024-09-17 12:38:07 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-17 12:38:07 --> Controller Class Initialized
INFO - 2024-09-17 12:38:22 --> Config Class Initialized
INFO - 2024-09-17 12:38:22 --> Hooks Class Initialized
DEBUG - 2024-09-17 12:38:22 --> UTF-8 Support Enabled
INFO - 2024-09-17 12:38:22 --> Utf8 Class Initialized
INFO - 2024-09-17 12:38:22 --> URI Class Initialized
INFO - 2024-09-17 12:38:22 --> Router Class Initialized
INFO - 2024-09-17 12:38:22 --> Output Class Initialized
INFO - 2024-09-17 12:38:22 --> Security Class Initialized
DEBUG - 2024-09-17 12:38:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-17 12:38:22 --> Input Class Initialized
INFO - 2024-09-17 12:38:22 --> Language Class Initialized
INFO - 2024-09-17 12:38:22 --> Language Class Initialized
INFO - 2024-09-17 12:38:22 --> Config Class Initialized
INFO - 2024-09-17 12:38:22 --> Loader Class Initialized
INFO - 2024-09-17 12:38:22 --> Helper loaded: url_helper
INFO - 2024-09-17 12:38:22 --> Helper loaded: file_helper
INFO - 2024-09-17 12:38:22 --> Helper loaded: form_helper
INFO - 2024-09-17 12:38:22 --> Helper loaded: my_helper
INFO - 2024-09-17 12:38:22 --> Database Driver Class Initialized
INFO - 2024-09-17 12:38:22 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-17 12:38:22 --> Controller Class Initialized
DEBUG - 2024-09-17 12:38:22 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/tahun/views/list.php
DEBUG - 2024-09-17 12:38:22 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-09-17 12:38:22 --> Final output sent to browser
DEBUG - 2024-09-17 12:38:22 --> Total execution time: 0.0367
INFO - 2024-09-17 12:38:22 --> Config Class Initialized
INFO - 2024-09-17 12:38:22 --> Hooks Class Initialized
DEBUG - 2024-09-17 12:38:22 --> UTF-8 Support Enabled
INFO - 2024-09-17 12:38:22 --> Utf8 Class Initialized
INFO - 2024-09-17 12:38:22 --> URI Class Initialized
INFO - 2024-09-17 12:38:22 --> Router Class Initialized
INFO - 2024-09-17 12:38:22 --> Output Class Initialized
INFO - 2024-09-17 12:38:22 --> Security Class Initialized
DEBUG - 2024-09-17 12:38:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-17 12:38:22 --> Input Class Initialized
INFO - 2024-09-17 12:38:22 --> Language Class Initialized
ERROR - 2024-09-17 12:38:22 --> 404 Page Not Found: /index
INFO - 2024-09-17 12:38:22 --> Config Class Initialized
INFO - 2024-09-17 12:38:22 --> Hooks Class Initialized
DEBUG - 2024-09-17 12:38:22 --> UTF-8 Support Enabled
INFO - 2024-09-17 12:38:22 --> Utf8 Class Initialized
INFO - 2024-09-17 12:38:22 --> URI Class Initialized
INFO - 2024-09-17 12:38:22 --> Router Class Initialized
INFO - 2024-09-17 12:38:22 --> Output Class Initialized
INFO - 2024-09-17 12:38:22 --> Security Class Initialized
DEBUG - 2024-09-17 12:38:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-17 12:38:22 --> Input Class Initialized
INFO - 2024-09-17 12:38:22 --> Language Class Initialized
INFO - 2024-09-17 12:38:22 --> Language Class Initialized
INFO - 2024-09-17 12:38:22 --> Config Class Initialized
INFO - 2024-09-17 12:38:22 --> Loader Class Initialized
INFO - 2024-09-17 12:38:22 --> Helper loaded: url_helper
INFO - 2024-09-17 12:38:22 --> Helper loaded: file_helper
INFO - 2024-09-17 12:38:22 --> Helper loaded: form_helper
INFO - 2024-09-17 12:38:22 --> Helper loaded: my_helper
INFO - 2024-09-17 12:38:22 --> Database Driver Class Initialized
INFO - 2024-09-17 12:38:22 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-17 12:38:22 --> Controller Class Initialized
INFO - 2024-09-17 12:38:28 --> Config Class Initialized
INFO - 2024-09-17 12:38:28 --> Hooks Class Initialized
DEBUG - 2024-09-17 12:38:28 --> UTF-8 Support Enabled
INFO - 2024-09-17 12:38:28 --> Utf8 Class Initialized
INFO - 2024-09-17 12:38:28 --> URI Class Initialized
INFO - 2024-09-17 12:38:28 --> Router Class Initialized
INFO - 2024-09-17 12:38:28 --> Output Class Initialized
INFO - 2024-09-17 12:38:28 --> Security Class Initialized
DEBUG - 2024-09-17 12:38:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-17 12:38:28 --> Input Class Initialized
INFO - 2024-09-17 12:38:28 --> Language Class Initialized
INFO - 2024-09-17 12:38:28 --> Language Class Initialized
INFO - 2024-09-17 12:38:28 --> Config Class Initialized
INFO - 2024-09-17 12:38:28 --> Loader Class Initialized
INFO - 2024-09-17 12:38:28 --> Helper loaded: url_helper
INFO - 2024-09-17 12:38:28 --> Helper loaded: file_helper
INFO - 2024-09-17 12:38:28 --> Helper loaded: form_helper
INFO - 2024-09-17 12:38:28 --> Helper loaded: my_helper
INFO - 2024-09-17 12:38:28 --> Database Driver Class Initialized
INFO - 2024-09-17 12:38:28 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-17 12:38:28 --> Controller Class Initialized
DEBUG - 2024-09-17 12:38:28 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/data_siswa/views/list.php
DEBUG - 2024-09-17 12:38:28 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-09-17 12:38:28 --> Final output sent to browser
DEBUG - 2024-09-17 12:38:28 --> Total execution time: 0.0282
INFO - 2024-09-17 12:38:28 --> Config Class Initialized
INFO - 2024-09-17 12:38:28 --> Hooks Class Initialized
DEBUG - 2024-09-17 12:38:28 --> UTF-8 Support Enabled
INFO - 2024-09-17 12:38:28 --> Utf8 Class Initialized
INFO - 2024-09-17 12:38:28 --> URI Class Initialized
INFO - 2024-09-17 12:38:28 --> Router Class Initialized
INFO - 2024-09-17 12:38:28 --> Output Class Initialized
INFO - 2024-09-17 12:38:28 --> Security Class Initialized
DEBUG - 2024-09-17 12:38:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-17 12:38:28 --> Input Class Initialized
INFO - 2024-09-17 12:38:28 --> Language Class Initialized
ERROR - 2024-09-17 12:38:28 --> 404 Page Not Found: /index
INFO - 2024-09-17 12:38:29 --> Config Class Initialized
INFO - 2024-09-17 12:38:29 --> Hooks Class Initialized
DEBUG - 2024-09-17 12:38:29 --> UTF-8 Support Enabled
INFO - 2024-09-17 12:38:29 --> Utf8 Class Initialized
INFO - 2024-09-17 12:38:29 --> URI Class Initialized
INFO - 2024-09-17 12:38:29 --> Router Class Initialized
INFO - 2024-09-17 12:38:29 --> Output Class Initialized
INFO - 2024-09-17 12:38:29 --> Security Class Initialized
DEBUG - 2024-09-17 12:38:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-17 12:38:29 --> Input Class Initialized
INFO - 2024-09-17 12:38:29 --> Language Class Initialized
INFO - 2024-09-17 12:38:29 --> Language Class Initialized
INFO - 2024-09-17 12:38:29 --> Config Class Initialized
INFO - 2024-09-17 12:38:29 --> Loader Class Initialized
INFO - 2024-09-17 12:38:29 --> Helper loaded: url_helper
INFO - 2024-09-17 12:38:29 --> Helper loaded: file_helper
INFO - 2024-09-17 12:38:29 --> Helper loaded: form_helper
INFO - 2024-09-17 12:38:29 --> Helper loaded: my_helper
INFO - 2024-09-17 12:38:29 --> Database Driver Class Initialized
INFO - 2024-09-17 12:38:29 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-17 12:38:29 --> Controller Class Initialized
INFO - 2024-09-17 12:38:30 --> Config Class Initialized
INFO - 2024-09-17 12:38:30 --> Hooks Class Initialized
DEBUG - 2024-09-17 12:38:30 --> UTF-8 Support Enabled
INFO - 2024-09-17 12:38:30 --> Utf8 Class Initialized
INFO - 2024-09-17 12:38:30 --> URI Class Initialized
INFO - 2024-09-17 12:38:30 --> Router Class Initialized
INFO - 2024-09-17 12:38:30 --> Output Class Initialized
INFO - 2024-09-17 12:38:30 --> Security Class Initialized
DEBUG - 2024-09-17 12:38:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-17 12:38:30 --> Input Class Initialized
INFO - 2024-09-17 12:38:30 --> Language Class Initialized
INFO - 2024-09-17 12:38:30 --> Language Class Initialized
INFO - 2024-09-17 12:38:30 --> Config Class Initialized
INFO - 2024-09-17 12:38:30 --> Loader Class Initialized
INFO - 2024-09-17 12:38:30 --> Helper loaded: url_helper
INFO - 2024-09-17 12:38:30 --> Helper loaded: file_helper
INFO - 2024-09-17 12:38:30 --> Helper loaded: form_helper
INFO - 2024-09-17 12:38:30 --> Helper loaded: my_helper
INFO - 2024-09-17 12:38:30 --> Database Driver Class Initialized
INFO - 2024-09-17 12:38:30 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-17 12:38:30 --> Controller Class Initialized
DEBUG - 2024-09-17 12:38:30 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/data_kelas/views/list.php
DEBUG - 2024-09-17 12:38:30 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-09-17 12:38:30 --> Final output sent to browser
DEBUG - 2024-09-17 12:38:30 --> Total execution time: 0.0339
INFO - 2024-09-17 12:38:30 --> Config Class Initialized
INFO - 2024-09-17 12:38:30 --> Hooks Class Initialized
DEBUG - 2024-09-17 12:38:30 --> UTF-8 Support Enabled
INFO - 2024-09-17 12:38:30 --> Utf8 Class Initialized
INFO - 2024-09-17 12:38:30 --> URI Class Initialized
INFO - 2024-09-17 12:38:30 --> Router Class Initialized
INFO - 2024-09-17 12:38:30 --> Output Class Initialized
INFO - 2024-09-17 12:38:30 --> Security Class Initialized
DEBUG - 2024-09-17 12:38:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-17 12:38:30 --> Input Class Initialized
INFO - 2024-09-17 12:38:30 --> Language Class Initialized
ERROR - 2024-09-17 12:38:30 --> 404 Page Not Found: /index
INFO - 2024-09-17 12:38:30 --> Config Class Initialized
INFO - 2024-09-17 12:38:30 --> Hooks Class Initialized
DEBUG - 2024-09-17 12:38:30 --> UTF-8 Support Enabled
INFO - 2024-09-17 12:38:30 --> Utf8 Class Initialized
INFO - 2024-09-17 12:38:30 --> URI Class Initialized
INFO - 2024-09-17 12:38:30 --> Router Class Initialized
INFO - 2024-09-17 12:38:30 --> Output Class Initialized
INFO - 2024-09-17 12:38:30 --> Security Class Initialized
DEBUG - 2024-09-17 12:38:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-17 12:38:30 --> Input Class Initialized
INFO - 2024-09-17 12:38:30 --> Language Class Initialized
INFO - 2024-09-17 12:38:30 --> Language Class Initialized
INFO - 2024-09-17 12:38:30 --> Config Class Initialized
INFO - 2024-09-17 12:38:30 --> Loader Class Initialized
INFO - 2024-09-17 12:38:30 --> Helper loaded: url_helper
INFO - 2024-09-17 12:38:30 --> Helper loaded: file_helper
INFO - 2024-09-17 12:38:30 --> Helper loaded: form_helper
INFO - 2024-09-17 12:38:30 --> Helper loaded: my_helper
INFO - 2024-09-17 12:38:30 --> Database Driver Class Initialized
INFO - 2024-09-17 12:38:30 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-17 12:38:30 --> Controller Class Initialized
INFO - 2024-09-17 12:38:35 --> Config Class Initialized
INFO - 2024-09-17 12:38:35 --> Hooks Class Initialized
DEBUG - 2024-09-17 12:38:35 --> UTF-8 Support Enabled
INFO - 2024-09-17 12:38:35 --> Utf8 Class Initialized
INFO - 2024-09-17 12:38:35 --> URI Class Initialized
INFO - 2024-09-17 12:38:35 --> Router Class Initialized
INFO - 2024-09-17 12:38:35 --> Output Class Initialized
INFO - 2024-09-17 12:38:35 --> Security Class Initialized
DEBUG - 2024-09-17 12:38:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-17 12:38:35 --> Input Class Initialized
INFO - 2024-09-17 12:38:35 --> Language Class Initialized
INFO - 2024-09-17 12:38:35 --> Language Class Initialized
INFO - 2024-09-17 12:38:35 --> Config Class Initialized
INFO - 2024-09-17 12:38:35 --> Loader Class Initialized
INFO - 2024-09-17 12:38:35 --> Helper loaded: url_helper
INFO - 2024-09-17 12:38:35 --> Helper loaded: file_helper
INFO - 2024-09-17 12:38:35 --> Helper loaded: form_helper
INFO - 2024-09-17 12:38:35 --> Helper loaded: my_helper
INFO - 2024-09-17 12:38:35 --> Database Driver Class Initialized
INFO - 2024-09-17 12:38:35 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-17 12:38:35 --> Controller Class Initialized
DEBUG - 2024-09-17 12:38:35 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/data_kelas_tahfiz/views/list.php
DEBUG - 2024-09-17 12:38:35 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-09-17 12:38:35 --> Final output sent to browser
DEBUG - 2024-09-17 12:38:35 --> Total execution time: 0.0731
INFO - 2024-09-17 12:38:35 --> Config Class Initialized
INFO - 2024-09-17 12:38:35 --> Hooks Class Initialized
DEBUG - 2024-09-17 12:38:35 --> UTF-8 Support Enabled
INFO - 2024-09-17 12:38:35 --> Utf8 Class Initialized
INFO - 2024-09-17 12:38:35 --> URI Class Initialized
INFO - 2024-09-17 12:38:35 --> Router Class Initialized
INFO - 2024-09-17 12:38:35 --> Output Class Initialized
INFO - 2024-09-17 12:38:35 --> Security Class Initialized
DEBUG - 2024-09-17 12:38:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-17 12:38:35 --> Input Class Initialized
INFO - 2024-09-17 12:38:35 --> Language Class Initialized
ERROR - 2024-09-17 12:38:35 --> 404 Page Not Found: /index
INFO - 2024-09-17 12:38:36 --> Config Class Initialized
INFO - 2024-09-17 12:38:36 --> Hooks Class Initialized
DEBUG - 2024-09-17 12:38:36 --> UTF-8 Support Enabled
INFO - 2024-09-17 12:38:36 --> Utf8 Class Initialized
INFO - 2024-09-17 12:38:36 --> URI Class Initialized
INFO - 2024-09-17 12:38:36 --> Router Class Initialized
INFO - 2024-09-17 12:38:36 --> Output Class Initialized
INFO - 2024-09-17 12:38:36 --> Security Class Initialized
DEBUG - 2024-09-17 12:38:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-17 12:38:36 --> Input Class Initialized
INFO - 2024-09-17 12:38:36 --> Language Class Initialized
INFO - 2024-09-17 12:38:36 --> Language Class Initialized
INFO - 2024-09-17 12:38:36 --> Config Class Initialized
INFO - 2024-09-17 12:38:36 --> Loader Class Initialized
INFO - 2024-09-17 12:38:36 --> Helper loaded: url_helper
INFO - 2024-09-17 12:38:36 --> Helper loaded: file_helper
INFO - 2024-09-17 12:38:36 --> Helper loaded: form_helper
INFO - 2024-09-17 12:38:36 --> Helper loaded: my_helper
INFO - 2024-09-17 12:38:36 --> Database Driver Class Initialized
INFO - 2024-09-17 12:38:36 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-17 12:38:36 --> Controller Class Initialized
INFO - 2024-09-17 12:38:39 --> Config Class Initialized
INFO - 2024-09-17 12:38:39 --> Hooks Class Initialized
DEBUG - 2024-09-17 12:38:39 --> UTF-8 Support Enabled
INFO - 2024-09-17 12:38:39 --> Utf8 Class Initialized
INFO - 2024-09-17 12:38:39 --> URI Class Initialized
INFO - 2024-09-17 12:38:39 --> Router Class Initialized
INFO - 2024-09-17 12:38:39 --> Output Class Initialized
INFO - 2024-09-17 12:38:39 --> Security Class Initialized
DEBUG - 2024-09-17 12:38:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-17 12:38:39 --> Input Class Initialized
INFO - 2024-09-17 12:38:39 --> Language Class Initialized
INFO - 2024-09-17 12:38:39 --> Language Class Initialized
INFO - 2024-09-17 12:38:39 --> Config Class Initialized
INFO - 2024-09-17 12:38:39 --> Loader Class Initialized
INFO - 2024-09-17 12:38:39 --> Helper loaded: url_helper
INFO - 2024-09-17 12:38:39 --> Helper loaded: file_helper
INFO - 2024-09-17 12:38:39 --> Helper loaded: form_helper
INFO - 2024-09-17 12:38:39 --> Helper loaded: my_helper
INFO - 2024-09-17 12:38:39 --> Database Driver Class Initialized
INFO - 2024-09-17 12:38:39 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-17 12:38:39 --> Controller Class Initialized
DEBUG - 2024-09-17 12:38:39 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/data_kelas/views/list.php
DEBUG - 2024-09-17 12:38:39 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-09-17 12:38:39 --> Final output sent to browser
DEBUG - 2024-09-17 12:38:39 --> Total execution time: 0.0272
INFO - 2024-09-17 12:38:39 --> Config Class Initialized
INFO - 2024-09-17 12:38:39 --> Hooks Class Initialized
DEBUG - 2024-09-17 12:38:39 --> UTF-8 Support Enabled
INFO - 2024-09-17 12:38:39 --> Utf8 Class Initialized
INFO - 2024-09-17 12:38:39 --> URI Class Initialized
INFO - 2024-09-17 12:38:39 --> Router Class Initialized
INFO - 2024-09-17 12:38:39 --> Output Class Initialized
INFO - 2024-09-17 12:38:39 --> Security Class Initialized
DEBUG - 2024-09-17 12:38:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-17 12:38:39 --> Input Class Initialized
INFO - 2024-09-17 12:38:39 --> Language Class Initialized
ERROR - 2024-09-17 12:38:39 --> 404 Page Not Found: /index
INFO - 2024-09-17 12:38:39 --> Config Class Initialized
INFO - 2024-09-17 12:38:39 --> Hooks Class Initialized
DEBUG - 2024-09-17 12:38:39 --> UTF-8 Support Enabled
INFO - 2024-09-17 12:38:39 --> Utf8 Class Initialized
INFO - 2024-09-17 12:38:39 --> URI Class Initialized
INFO - 2024-09-17 12:38:39 --> Router Class Initialized
INFO - 2024-09-17 12:38:39 --> Output Class Initialized
INFO - 2024-09-17 12:38:39 --> Security Class Initialized
DEBUG - 2024-09-17 12:38:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-17 12:38:39 --> Input Class Initialized
INFO - 2024-09-17 12:38:39 --> Language Class Initialized
INFO - 2024-09-17 12:38:39 --> Language Class Initialized
INFO - 2024-09-17 12:38:39 --> Config Class Initialized
INFO - 2024-09-17 12:38:39 --> Loader Class Initialized
INFO - 2024-09-17 12:38:39 --> Helper loaded: url_helper
INFO - 2024-09-17 12:38:39 --> Helper loaded: file_helper
INFO - 2024-09-17 12:38:39 --> Helper loaded: form_helper
INFO - 2024-09-17 12:38:39 --> Helper loaded: my_helper
INFO - 2024-09-17 12:38:39 --> Database Driver Class Initialized
INFO - 2024-09-17 12:38:39 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-17 12:38:39 --> Controller Class Initialized
INFO - 2024-09-17 12:38:43 --> Config Class Initialized
INFO - 2024-09-17 12:38:43 --> Hooks Class Initialized
DEBUG - 2024-09-17 12:38:43 --> UTF-8 Support Enabled
INFO - 2024-09-17 12:38:43 --> Utf8 Class Initialized
INFO - 2024-09-17 12:38:43 --> URI Class Initialized
INFO - 2024-09-17 12:38:43 --> Router Class Initialized
INFO - 2024-09-17 12:38:43 --> Output Class Initialized
INFO - 2024-09-17 12:38:43 --> Security Class Initialized
DEBUG - 2024-09-17 12:38:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-17 12:38:43 --> Input Class Initialized
INFO - 2024-09-17 12:38:43 --> Language Class Initialized
INFO - 2024-09-17 12:38:43 --> Language Class Initialized
INFO - 2024-09-17 12:38:43 --> Config Class Initialized
INFO - 2024-09-17 12:38:43 --> Loader Class Initialized
INFO - 2024-09-17 12:38:43 --> Helper loaded: url_helper
INFO - 2024-09-17 12:38:43 --> Helper loaded: file_helper
INFO - 2024-09-17 12:38:43 --> Helper loaded: form_helper
INFO - 2024-09-17 12:38:43 --> Helper loaded: my_helper
INFO - 2024-09-17 12:38:43 --> Database Driver Class Initialized
INFO - 2024-09-17 12:38:43 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-17 12:38:43 --> Controller Class Initialized
DEBUG - 2024-09-17 12:38:43 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/data_mapel/views/list.php
DEBUG - 2024-09-17 12:38:43 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-09-17 12:38:43 --> Final output sent to browser
DEBUG - 2024-09-17 12:38:43 --> Total execution time: 0.0392
INFO - 2024-09-17 12:38:43 --> Config Class Initialized
INFO - 2024-09-17 12:38:43 --> Hooks Class Initialized
DEBUG - 2024-09-17 12:38:43 --> UTF-8 Support Enabled
INFO - 2024-09-17 12:38:43 --> Utf8 Class Initialized
INFO - 2024-09-17 12:38:43 --> URI Class Initialized
INFO - 2024-09-17 12:38:43 --> Router Class Initialized
INFO - 2024-09-17 12:38:43 --> Output Class Initialized
INFO - 2024-09-17 12:38:43 --> Security Class Initialized
DEBUG - 2024-09-17 12:38:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-17 12:38:43 --> Input Class Initialized
INFO - 2024-09-17 12:38:43 --> Language Class Initialized
ERROR - 2024-09-17 12:38:43 --> 404 Page Not Found: /index
INFO - 2024-09-17 12:38:43 --> Config Class Initialized
INFO - 2024-09-17 12:38:43 --> Hooks Class Initialized
DEBUG - 2024-09-17 12:38:43 --> UTF-8 Support Enabled
INFO - 2024-09-17 12:38:43 --> Utf8 Class Initialized
INFO - 2024-09-17 12:38:43 --> URI Class Initialized
INFO - 2024-09-17 12:38:43 --> Router Class Initialized
INFO - 2024-09-17 12:38:43 --> Output Class Initialized
INFO - 2024-09-17 12:38:43 --> Security Class Initialized
DEBUG - 2024-09-17 12:38:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-17 12:38:43 --> Input Class Initialized
INFO - 2024-09-17 12:38:43 --> Language Class Initialized
INFO - 2024-09-17 12:38:43 --> Language Class Initialized
INFO - 2024-09-17 12:38:43 --> Config Class Initialized
INFO - 2024-09-17 12:38:43 --> Loader Class Initialized
INFO - 2024-09-17 12:38:43 --> Helper loaded: url_helper
INFO - 2024-09-17 12:38:43 --> Helper loaded: file_helper
INFO - 2024-09-17 12:38:43 --> Helper loaded: form_helper
INFO - 2024-09-17 12:38:43 --> Helper loaded: my_helper
INFO - 2024-09-17 12:38:43 --> Database Driver Class Initialized
INFO - 2024-09-17 12:38:43 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-17 12:38:43 --> Controller Class Initialized
INFO - 2024-09-17 12:38:51 --> Config Class Initialized
INFO - 2024-09-17 12:38:51 --> Hooks Class Initialized
DEBUG - 2024-09-17 12:38:51 --> UTF-8 Support Enabled
INFO - 2024-09-17 12:38:51 --> Utf8 Class Initialized
INFO - 2024-09-17 12:38:51 --> URI Class Initialized
INFO - 2024-09-17 12:38:51 --> Router Class Initialized
INFO - 2024-09-17 12:38:51 --> Output Class Initialized
INFO - 2024-09-17 12:38:51 --> Security Class Initialized
DEBUG - 2024-09-17 12:38:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-17 12:38:51 --> Input Class Initialized
INFO - 2024-09-17 12:38:51 --> Language Class Initialized
INFO - 2024-09-17 12:38:51 --> Language Class Initialized
INFO - 2024-09-17 12:38:51 --> Config Class Initialized
INFO - 2024-09-17 12:38:51 --> Loader Class Initialized
INFO - 2024-09-17 12:38:51 --> Helper loaded: url_helper
INFO - 2024-09-17 12:38:51 --> Helper loaded: file_helper
INFO - 2024-09-17 12:38:51 --> Helper loaded: form_helper
INFO - 2024-09-17 12:38:51 --> Helper loaded: my_helper
INFO - 2024-09-17 12:38:51 --> Database Driver Class Initialized
INFO - 2024-09-17 12:38:51 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-17 12:38:51 --> Controller Class Initialized
DEBUG - 2024-09-17 12:38:51 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/tahun/views/list.php
DEBUG - 2024-09-17 12:38:51 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-09-17 12:38:51 --> Final output sent to browser
DEBUG - 2024-09-17 12:38:51 --> Total execution time: 0.0323
INFO - 2024-09-17 12:38:52 --> Config Class Initialized
INFO - 2024-09-17 12:38:52 --> Hooks Class Initialized
DEBUG - 2024-09-17 12:38:52 --> UTF-8 Support Enabled
INFO - 2024-09-17 12:38:52 --> Utf8 Class Initialized
INFO - 2024-09-17 12:38:52 --> URI Class Initialized
INFO - 2024-09-17 12:38:52 --> Router Class Initialized
INFO - 2024-09-17 12:38:52 --> Output Class Initialized
INFO - 2024-09-17 12:38:52 --> Security Class Initialized
DEBUG - 2024-09-17 12:38:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-17 12:38:52 --> Input Class Initialized
INFO - 2024-09-17 12:38:52 --> Language Class Initialized
ERROR - 2024-09-17 12:38:52 --> 404 Page Not Found: /index
INFO - 2024-09-17 12:38:52 --> Config Class Initialized
INFO - 2024-09-17 12:38:52 --> Hooks Class Initialized
DEBUG - 2024-09-17 12:38:52 --> UTF-8 Support Enabled
INFO - 2024-09-17 12:38:52 --> Utf8 Class Initialized
INFO - 2024-09-17 12:38:52 --> URI Class Initialized
INFO - 2024-09-17 12:38:52 --> Router Class Initialized
INFO - 2024-09-17 12:38:52 --> Output Class Initialized
INFO - 2024-09-17 12:38:52 --> Security Class Initialized
DEBUG - 2024-09-17 12:38:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-17 12:38:52 --> Input Class Initialized
INFO - 2024-09-17 12:38:52 --> Language Class Initialized
INFO - 2024-09-17 12:38:52 --> Language Class Initialized
INFO - 2024-09-17 12:38:52 --> Config Class Initialized
INFO - 2024-09-17 12:38:52 --> Loader Class Initialized
INFO - 2024-09-17 12:38:52 --> Helper loaded: url_helper
INFO - 2024-09-17 12:38:52 --> Helper loaded: file_helper
INFO - 2024-09-17 12:38:52 --> Helper loaded: form_helper
INFO - 2024-09-17 12:38:52 --> Helper loaded: my_helper
INFO - 2024-09-17 12:38:52 --> Database Driver Class Initialized
INFO - 2024-09-17 12:38:52 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-17 12:38:52 --> Controller Class Initialized
INFO - 2024-09-17 12:38:55 --> Config Class Initialized
INFO - 2024-09-17 12:38:55 --> Hooks Class Initialized
DEBUG - 2024-09-17 12:38:55 --> UTF-8 Support Enabled
INFO - 2024-09-17 12:38:55 --> Utf8 Class Initialized
INFO - 2024-09-17 12:38:55 --> URI Class Initialized
INFO - 2024-09-17 12:38:55 --> Router Class Initialized
INFO - 2024-09-17 12:38:55 --> Output Class Initialized
INFO - 2024-09-17 12:38:55 --> Security Class Initialized
DEBUG - 2024-09-17 12:38:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-17 12:38:55 --> Input Class Initialized
INFO - 2024-09-17 12:38:55 --> Language Class Initialized
INFO - 2024-09-17 12:38:55 --> Language Class Initialized
INFO - 2024-09-17 12:38:55 --> Config Class Initialized
INFO - 2024-09-17 12:38:55 --> Loader Class Initialized
INFO - 2024-09-17 12:38:55 --> Helper loaded: url_helper
INFO - 2024-09-17 12:38:55 --> Helper loaded: file_helper
INFO - 2024-09-17 12:38:55 --> Helper loaded: form_helper
INFO - 2024-09-17 12:38:55 --> Helper loaded: my_helper
INFO - 2024-09-17 12:38:55 --> Database Driver Class Initialized
INFO - 2024-09-17 12:38:55 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-17 12:38:55 --> Controller Class Initialized
DEBUG - 2024-09-17 12:38:55 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/set_kelas/views/list.php
DEBUG - 2024-09-17 12:38:55 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-09-17 12:38:55 --> Final output sent to browser
DEBUG - 2024-09-17 12:38:55 --> Total execution time: 0.0305
INFO - 2024-09-17 12:39:07 --> Config Class Initialized
INFO - 2024-09-17 12:39:07 --> Hooks Class Initialized
DEBUG - 2024-09-17 12:39:07 --> UTF-8 Support Enabled
INFO - 2024-09-17 12:39:07 --> Utf8 Class Initialized
INFO - 2024-09-17 12:39:07 --> URI Class Initialized
INFO - 2024-09-17 12:39:07 --> Router Class Initialized
INFO - 2024-09-17 12:39:07 --> Output Class Initialized
INFO - 2024-09-17 12:39:07 --> Security Class Initialized
DEBUG - 2024-09-17 12:39:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-17 12:39:07 --> Input Class Initialized
INFO - 2024-09-17 12:39:07 --> Language Class Initialized
INFO - 2024-09-17 12:39:07 --> Language Class Initialized
INFO - 2024-09-17 12:39:07 --> Config Class Initialized
INFO - 2024-09-17 12:39:07 --> Loader Class Initialized
INFO - 2024-09-17 12:39:07 --> Helper loaded: url_helper
INFO - 2024-09-17 12:39:07 --> Helper loaded: file_helper
INFO - 2024-09-17 12:39:07 --> Helper loaded: form_helper
INFO - 2024-09-17 12:39:07 --> Helper loaded: my_helper
INFO - 2024-09-17 12:39:07 --> Database Driver Class Initialized
INFO - 2024-09-17 12:39:07 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-17 12:39:07 --> Controller Class Initialized
DEBUG - 2024-09-17 12:39:07 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/set_mapel/views/list.php
DEBUG - 2024-09-17 12:39:07 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-09-17 12:39:07 --> Final output sent to browser
DEBUG - 2024-09-17 12:39:07 --> Total execution time: 0.0367
INFO - 2024-09-17 12:39:07 --> Config Class Initialized
INFO - 2024-09-17 12:39:07 --> Hooks Class Initialized
DEBUG - 2024-09-17 12:39:07 --> UTF-8 Support Enabled
INFO - 2024-09-17 12:39:07 --> Utf8 Class Initialized
INFO - 2024-09-17 12:39:07 --> URI Class Initialized
INFO - 2024-09-17 12:39:07 --> Router Class Initialized
INFO - 2024-09-17 12:39:07 --> Output Class Initialized
INFO - 2024-09-17 12:39:07 --> Security Class Initialized
DEBUG - 2024-09-17 12:39:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-17 12:39:07 --> Input Class Initialized
INFO - 2024-09-17 12:39:07 --> Language Class Initialized
ERROR - 2024-09-17 12:39:07 --> 404 Page Not Found: /index
INFO - 2024-09-17 12:39:07 --> Config Class Initialized
INFO - 2024-09-17 12:39:07 --> Hooks Class Initialized
DEBUG - 2024-09-17 12:39:07 --> UTF-8 Support Enabled
INFO - 2024-09-17 12:39:07 --> Utf8 Class Initialized
INFO - 2024-09-17 12:39:07 --> URI Class Initialized
INFO - 2024-09-17 12:39:07 --> Router Class Initialized
INFO - 2024-09-17 12:39:07 --> Output Class Initialized
INFO - 2024-09-17 12:39:07 --> Security Class Initialized
DEBUG - 2024-09-17 12:39:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-17 12:39:07 --> Input Class Initialized
INFO - 2024-09-17 12:39:07 --> Language Class Initialized
INFO - 2024-09-17 12:39:07 --> Language Class Initialized
INFO - 2024-09-17 12:39:07 --> Config Class Initialized
INFO - 2024-09-17 12:39:07 --> Loader Class Initialized
INFO - 2024-09-17 12:39:07 --> Helper loaded: url_helper
INFO - 2024-09-17 12:39:07 --> Helper loaded: file_helper
INFO - 2024-09-17 12:39:07 --> Helper loaded: form_helper
INFO - 2024-09-17 12:39:07 --> Helper loaded: my_helper
INFO - 2024-09-17 12:39:07 --> Database Driver Class Initialized
INFO - 2024-09-17 12:39:07 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-17 12:39:07 --> Controller Class Initialized
INFO - 2024-09-17 12:39:09 --> Config Class Initialized
INFO - 2024-09-17 12:39:09 --> Hooks Class Initialized
DEBUG - 2024-09-17 12:39:09 --> UTF-8 Support Enabled
INFO - 2024-09-17 12:39:09 --> Utf8 Class Initialized
INFO - 2024-09-17 12:39:09 --> URI Class Initialized
INFO - 2024-09-17 12:39:09 --> Router Class Initialized
INFO - 2024-09-17 12:39:09 --> Output Class Initialized
INFO - 2024-09-17 12:39:09 --> Security Class Initialized
DEBUG - 2024-09-17 12:39:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-17 12:39:09 --> Input Class Initialized
INFO - 2024-09-17 12:39:09 --> Language Class Initialized
INFO - 2024-09-17 12:39:09 --> Language Class Initialized
INFO - 2024-09-17 12:39:09 --> Config Class Initialized
INFO - 2024-09-17 12:39:09 --> Loader Class Initialized
INFO - 2024-09-17 12:39:09 --> Helper loaded: url_helper
INFO - 2024-09-17 12:39:09 --> Helper loaded: file_helper
INFO - 2024-09-17 12:39:09 --> Helper loaded: form_helper
INFO - 2024-09-17 12:39:09 --> Helper loaded: my_helper
INFO - 2024-09-17 12:39:09 --> Database Driver Class Initialized
INFO - 2024-09-17 12:39:09 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-17 12:39:09 --> Controller Class Initialized
DEBUG - 2024-09-17 12:39:09 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/set_mapel/views/form.php
DEBUG - 2024-09-17 12:39:09 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-09-17 12:39:09 --> Final output sent to browser
DEBUG - 2024-09-17 12:39:09 --> Total execution time: 0.0256
INFO - 2024-09-17 12:39:50 --> Config Class Initialized
INFO - 2024-09-17 12:39:50 --> Hooks Class Initialized
DEBUG - 2024-09-17 12:39:50 --> UTF-8 Support Enabled
INFO - 2024-09-17 12:39:50 --> Utf8 Class Initialized
INFO - 2024-09-17 12:39:50 --> URI Class Initialized
INFO - 2024-09-17 12:39:50 --> Router Class Initialized
INFO - 2024-09-17 12:39:50 --> Output Class Initialized
INFO - 2024-09-17 12:39:50 --> Security Class Initialized
DEBUG - 2024-09-17 12:39:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-17 12:39:50 --> Input Class Initialized
INFO - 2024-09-17 12:39:50 --> Language Class Initialized
INFO - 2024-09-17 12:39:50 --> Language Class Initialized
INFO - 2024-09-17 12:39:50 --> Config Class Initialized
INFO - 2024-09-17 12:39:50 --> Loader Class Initialized
INFO - 2024-09-17 12:39:50 --> Helper loaded: url_helper
INFO - 2024-09-17 12:39:50 --> Helper loaded: file_helper
INFO - 2024-09-17 12:39:50 --> Helper loaded: form_helper
INFO - 2024-09-17 12:39:50 --> Helper loaded: my_helper
INFO - 2024-09-17 12:39:50 --> Database Driver Class Initialized
INFO - 2024-09-17 12:39:50 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-17 12:39:50 --> Controller Class Initialized
INFO - 2024-09-17 12:39:50 --> Config Class Initialized
INFO - 2024-09-17 12:39:50 --> Hooks Class Initialized
DEBUG - 2024-09-17 12:39:50 --> UTF-8 Support Enabled
INFO - 2024-09-17 12:39:50 --> Utf8 Class Initialized
INFO - 2024-09-17 12:39:50 --> URI Class Initialized
INFO - 2024-09-17 12:39:50 --> Router Class Initialized
INFO - 2024-09-17 12:39:50 --> Output Class Initialized
INFO - 2024-09-17 12:39:50 --> Security Class Initialized
DEBUG - 2024-09-17 12:39:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-17 12:39:50 --> Input Class Initialized
INFO - 2024-09-17 12:39:50 --> Language Class Initialized
INFO - 2024-09-17 12:39:50 --> Language Class Initialized
INFO - 2024-09-17 12:39:50 --> Config Class Initialized
INFO - 2024-09-17 12:39:50 --> Loader Class Initialized
INFO - 2024-09-17 12:39:50 --> Helper loaded: url_helper
INFO - 2024-09-17 12:39:50 --> Helper loaded: file_helper
INFO - 2024-09-17 12:39:50 --> Helper loaded: form_helper
INFO - 2024-09-17 12:39:50 --> Helper loaded: my_helper
INFO - 2024-09-17 12:39:50 --> Database Driver Class Initialized
INFO - 2024-09-17 12:39:50 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-17 12:39:50 --> Controller Class Initialized
DEBUG - 2024-09-17 12:39:50 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/set_mapel/views/list.php
DEBUG - 2024-09-17 12:39:50 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-09-17 12:39:50 --> Final output sent to browser
DEBUG - 2024-09-17 12:39:50 --> Total execution time: 0.0314
INFO - 2024-09-17 12:39:50 --> Config Class Initialized
INFO - 2024-09-17 12:39:50 --> Hooks Class Initialized
DEBUG - 2024-09-17 12:39:50 --> UTF-8 Support Enabled
INFO - 2024-09-17 12:39:50 --> Utf8 Class Initialized
INFO - 2024-09-17 12:39:50 --> URI Class Initialized
INFO - 2024-09-17 12:39:50 --> Router Class Initialized
INFO - 2024-09-17 12:39:50 --> Output Class Initialized
INFO - 2024-09-17 12:39:50 --> Security Class Initialized
DEBUG - 2024-09-17 12:39:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-17 12:39:50 --> Input Class Initialized
INFO - 2024-09-17 12:39:50 --> Language Class Initialized
ERROR - 2024-09-17 12:39:50 --> 404 Page Not Found: /index
INFO - 2024-09-17 12:39:50 --> Config Class Initialized
INFO - 2024-09-17 12:39:50 --> Hooks Class Initialized
DEBUG - 2024-09-17 12:39:50 --> UTF-8 Support Enabled
INFO - 2024-09-17 12:39:50 --> Utf8 Class Initialized
INFO - 2024-09-17 12:39:50 --> URI Class Initialized
INFO - 2024-09-17 12:39:50 --> Router Class Initialized
INFO - 2024-09-17 12:39:50 --> Output Class Initialized
INFO - 2024-09-17 12:39:50 --> Security Class Initialized
DEBUG - 2024-09-17 12:39:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-17 12:39:50 --> Input Class Initialized
INFO - 2024-09-17 12:39:50 --> Language Class Initialized
INFO - 2024-09-17 12:39:50 --> Language Class Initialized
INFO - 2024-09-17 12:39:50 --> Config Class Initialized
INFO - 2024-09-17 12:39:50 --> Loader Class Initialized
INFO - 2024-09-17 12:39:50 --> Helper loaded: url_helper
INFO - 2024-09-17 12:39:50 --> Helper loaded: file_helper
INFO - 2024-09-17 12:39:50 --> Helper loaded: form_helper
INFO - 2024-09-17 12:39:50 --> Helper loaded: my_helper
INFO - 2024-09-17 12:39:50 --> Database Driver Class Initialized
INFO - 2024-09-17 12:39:50 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-17 12:39:50 --> Controller Class Initialized
INFO - 2024-09-17 12:39:52 --> Config Class Initialized
INFO - 2024-09-17 12:39:52 --> Hooks Class Initialized
DEBUG - 2024-09-17 12:39:52 --> UTF-8 Support Enabled
INFO - 2024-09-17 12:39:52 --> Utf8 Class Initialized
INFO - 2024-09-17 12:39:52 --> URI Class Initialized
INFO - 2024-09-17 12:39:52 --> Router Class Initialized
INFO - 2024-09-17 12:39:52 --> Output Class Initialized
INFO - 2024-09-17 12:39:52 --> Security Class Initialized
DEBUG - 2024-09-17 12:39:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-17 12:39:52 --> Input Class Initialized
INFO - 2024-09-17 12:39:52 --> Language Class Initialized
INFO - 2024-09-17 12:39:52 --> Language Class Initialized
INFO - 2024-09-17 12:39:52 --> Config Class Initialized
INFO - 2024-09-17 12:39:52 --> Loader Class Initialized
INFO - 2024-09-17 12:39:52 --> Helper loaded: url_helper
INFO - 2024-09-17 12:39:52 --> Helper loaded: file_helper
INFO - 2024-09-17 12:39:52 --> Helper loaded: form_helper
INFO - 2024-09-17 12:39:52 --> Helper loaded: my_helper
INFO - 2024-09-17 12:39:52 --> Database Driver Class Initialized
INFO - 2024-09-17 12:39:52 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-17 12:39:52 --> Controller Class Initialized
DEBUG - 2024-09-17 12:39:52 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/set_mapel/views/form.php
DEBUG - 2024-09-17 12:39:52 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-09-17 12:39:52 --> Final output sent to browser
DEBUG - 2024-09-17 12:39:52 --> Total execution time: 0.0493
INFO - 2024-09-17 12:40:04 --> Config Class Initialized
INFO - 2024-09-17 12:40:04 --> Hooks Class Initialized
DEBUG - 2024-09-17 12:40:04 --> UTF-8 Support Enabled
INFO - 2024-09-17 12:40:04 --> Utf8 Class Initialized
INFO - 2024-09-17 12:40:04 --> URI Class Initialized
INFO - 2024-09-17 12:40:04 --> Router Class Initialized
INFO - 2024-09-17 12:40:04 --> Output Class Initialized
INFO - 2024-09-17 12:40:04 --> Security Class Initialized
DEBUG - 2024-09-17 12:40:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-17 12:40:04 --> Input Class Initialized
INFO - 2024-09-17 12:40:04 --> Language Class Initialized
INFO - 2024-09-17 12:40:04 --> Language Class Initialized
INFO - 2024-09-17 12:40:04 --> Config Class Initialized
INFO - 2024-09-17 12:40:04 --> Loader Class Initialized
INFO - 2024-09-17 12:40:04 --> Helper loaded: url_helper
INFO - 2024-09-17 12:40:04 --> Helper loaded: file_helper
INFO - 2024-09-17 12:40:04 --> Helper loaded: form_helper
INFO - 2024-09-17 12:40:04 --> Helper loaded: my_helper
INFO - 2024-09-17 12:40:04 --> Database Driver Class Initialized
INFO - 2024-09-17 12:40:04 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-17 12:40:04 --> Controller Class Initialized
INFO - 2024-09-17 12:40:04 --> Config Class Initialized
INFO - 2024-09-17 12:40:04 --> Hooks Class Initialized
DEBUG - 2024-09-17 12:40:04 --> UTF-8 Support Enabled
INFO - 2024-09-17 12:40:04 --> Utf8 Class Initialized
INFO - 2024-09-17 12:40:04 --> URI Class Initialized
INFO - 2024-09-17 12:40:04 --> Router Class Initialized
INFO - 2024-09-17 12:40:04 --> Output Class Initialized
INFO - 2024-09-17 12:40:04 --> Security Class Initialized
DEBUG - 2024-09-17 12:40:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-17 12:40:04 --> Input Class Initialized
INFO - 2024-09-17 12:40:04 --> Language Class Initialized
INFO - 2024-09-17 12:40:04 --> Language Class Initialized
INFO - 2024-09-17 12:40:04 --> Config Class Initialized
INFO - 2024-09-17 12:40:04 --> Loader Class Initialized
INFO - 2024-09-17 12:40:04 --> Helper loaded: url_helper
INFO - 2024-09-17 12:40:04 --> Helper loaded: file_helper
INFO - 2024-09-17 12:40:04 --> Helper loaded: form_helper
INFO - 2024-09-17 12:40:04 --> Helper loaded: my_helper
INFO - 2024-09-17 12:40:04 --> Database Driver Class Initialized
INFO - 2024-09-17 12:40:04 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-17 12:40:04 --> Controller Class Initialized
DEBUG - 2024-09-17 12:40:04 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/set_mapel/views/list.php
DEBUG - 2024-09-17 12:40:04 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-09-17 12:40:04 --> Final output sent to browser
DEBUG - 2024-09-17 12:40:04 --> Total execution time: 0.0519
INFO - 2024-09-17 12:40:04 --> Config Class Initialized
INFO - 2024-09-17 12:40:04 --> Hooks Class Initialized
DEBUG - 2024-09-17 12:40:04 --> UTF-8 Support Enabled
INFO - 2024-09-17 12:40:04 --> Utf8 Class Initialized
INFO - 2024-09-17 12:40:04 --> URI Class Initialized
INFO - 2024-09-17 12:40:04 --> Router Class Initialized
INFO - 2024-09-17 12:40:04 --> Output Class Initialized
INFO - 2024-09-17 12:40:04 --> Security Class Initialized
DEBUG - 2024-09-17 12:40:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-17 12:40:04 --> Input Class Initialized
INFO - 2024-09-17 12:40:04 --> Language Class Initialized
ERROR - 2024-09-17 12:40:04 --> 404 Page Not Found: /index
INFO - 2024-09-17 12:40:04 --> Config Class Initialized
INFO - 2024-09-17 12:40:04 --> Hooks Class Initialized
DEBUG - 2024-09-17 12:40:04 --> UTF-8 Support Enabled
INFO - 2024-09-17 12:40:04 --> Utf8 Class Initialized
INFO - 2024-09-17 12:40:04 --> URI Class Initialized
INFO - 2024-09-17 12:40:04 --> Router Class Initialized
INFO - 2024-09-17 12:40:04 --> Output Class Initialized
INFO - 2024-09-17 12:40:04 --> Security Class Initialized
DEBUG - 2024-09-17 12:40:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-17 12:40:04 --> Input Class Initialized
INFO - 2024-09-17 12:40:04 --> Language Class Initialized
INFO - 2024-09-17 12:40:04 --> Language Class Initialized
INFO - 2024-09-17 12:40:04 --> Config Class Initialized
INFO - 2024-09-17 12:40:04 --> Loader Class Initialized
INFO - 2024-09-17 12:40:04 --> Helper loaded: url_helper
INFO - 2024-09-17 12:40:04 --> Helper loaded: file_helper
INFO - 2024-09-17 12:40:04 --> Helper loaded: form_helper
INFO - 2024-09-17 12:40:04 --> Helper loaded: my_helper
INFO - 2024-09-17 12:40:04 --> Database Driver Class Initialized
INFO - 2024-09-17 12:40:04 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-17 12:40:04 --> Controller Class Initialized
INFO - 2024-09-17 12:40:08 --> Config Class Initialized
INFO - 2024-09-17 12:40:08 --> Hooks Class Initialized
DEBUG - 2024-09-17 12:40:08 --> UTF-8 Support Enabled
INFO - 2024-09-17 12:40:08 --> Utf8 Class Initialized
INFO - 2024-09-17 12:40:08 --> URI Class Initialized
INFO - 2024-09-17 12:40:08 --> Router Class Initialized
INFO - 2024-09-17 12:40:08 --> Output Class Initialized
INFO - 2024-09-17 12:40:08 --> Security Class Initialized
DEBUG - 2024-09-17 12:40:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-17 12:40:08 --> Input Class Initialized
INFO - 2024-09-17 12:40:08 --> Language Class Initialized
INFO - 2024-09-17 12:40:08 --> Language Class Initialized
INFO - 2024-09-17 12:40:08 --> Config Class Initialized
INFO - 2024-09-17 12:40:08 --> Loader Class Initialized
INFO - 2024-09-17 12:40:08 --> Helper loaded: url_helper
INFO - 2024-09-17 12:40:08 --> Helper loaded: file_helper
INFO - 2024-09-17 12:40:08 --> Helper loaded: form_helper
INFO - 2024-09-17 12:40:08 --> Helper loaded: my_helper
INFO - 2024-09-17 12:40:08 --> Database Driver Class Initialized
INFO - 2024-09-17 12:40:08 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-17 12:40:08 --> Controller Class Initialized
DEBUG - 2024-09-17 12:40:08 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/set_mapel/views/form.php
DEBUG - 2024-09-17 12:40:08 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-09-17 12:40:08 --> Final output sent to browser
DEBUG - 2024-09-17 12:40:08 --> Total execution time: 0.0301
INFO - 2024-09-17 12:40:23 --> Config Class Initialized
INFO - 2024-09-17 12:40:23 --> Hooks Class Initialized
DEBUG - 2024-09-17 12:40:23 --> UTF-8 Support Enabled
INFO - 2024-09-17 12:40:23 --> Utf8 Class Initialized
INFO - 2024-09-17 12:40:23 --> URI Class Initialized
INFO - 2024-09-17 12:40:23 --> Router Class Initialized
INFO - 2024-09-17 12:40:23 --> Output Class Initialized
INFO - 2024-09-17 12:40:23 --> Security Class Initialized
DEBUG - 2024-09-17 12:40:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-17 12:40:23 --> Input Class Initialized
INFO - 2024-09-17 12:40:23 --> Language Class Initialized
INFO - 2024-09-17 12:40:23 --> Language Class Initialized
INFO - 2024-09-17 12:40:23 --> Config Class Initialized
INFO - 2024-09-17 12:40:23 --> Loader Class Initialized
INFO - 2024-09-17 12:40:23 --> Helper loaded: url_helper
INFO - 2024-09-17 12:40:23 --> Helper loaded: file_helper
INFO - 2024-09-17 12:40:23 --> Helper loaded: form_helper
INFO - 2024-09-17 12:40:23 --> Helper loaded: my_helper
INFO - 2024-09-17 12:40:23 --> Database Driver Class Initialized
INFO - 2024-09-17 12:40:23 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-17 12:40:23 --> Controller Class Initialized
INFO - 2024-09-17 12:40:23 --> Config Class Initialized
INFO - 2024-09-17 12:40:23 --> Hooks Class Initialized
DEBUG - 2024-09-17 12:40:23 --> UTF-8 Support Enabled
INFO - 2024-09-17 12:40:23 --> Utf8 Class Initialized
INFO - 2024-09-17 12:40:23 --> URI Class Initialized
INFO - 2024-09-17 12:40:23 --> Router Class Initialized
INFO - 2024-09-17 12:40:23 --> Output Class Initialized
INFO - 2024-09-17 12:40:23 --> Security Class Initialized
DEBUG - 2024-09-17 12:40:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-17 12:40:23 --> Input Class Initialized
INFO - 2024-09-17 12:40:23 --> Language Class Initialized
INFO - 2024-09-17 12:40:23 --> Language Class Initialized
INFO - 2024-09-17 12:40:23 --> Config Class Initialized
INFO - 2024-09-17 12:40:23 --> Loader Class Initialized
INFO - 2024-09-17 12:40:23 --> Helper loaded: url_helper
INFO - 2024-09-17 12:40:23 --> Helper loaded: file_helper
INFO - 2024-09-17 12:40:23 --> Helper loaded: form_helper
INFO - 2024-09-17 12:40:23 --> Helper loaded: my_helper
INFO - 2024-09-17 12:40:23 --> Database Driver Class Initialized
INFO - 2024-09-17 12:40:23 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-17 12:40:23 --> Controller Class Initialized
DEBUG - 2024-09-17 12:40:23 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/set_mapel/views/list.php
DEBUG - 2024-09-17 12:40:23 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-09-17 12:40:23 --> Final output sent to browser
DEBUG - 2024-09-17 12:40:23 --> Total execution time: 0.0277
INFO - 2024-09-17 12:40:23 --> Config Class Initialized
INFO - 2024-09-17 12:40:23 --> Hooks Class Initialized
DEBUG - 2024-09-17 12:40:23 --> UTF-8 Support Enabled
INFO - 2024-09-17 12:40:23 --> Utf8 Class Initialized
INFO - 2024-09-17 12:40:23 --> URI Class Initialized
INFO - 2024-09-17 12:40:23 --> Router Class Initialized
INFO - 2024-09-17 12:40:23 --> Output Class Initialized
INFO - 2024-09-17 12:40:23 --> Security Class Initialized
DEBUG - 2024-09-17 12:40:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-17 12:40:23 --> Input Class Initialized
INFO - 2024-09-17 12:40:23 --> Language Class Initialized
ERROR - 2024-09-17 12:40:23 --> 404 Page Not Found: /index
INFO - 2024-09-17 12:40:24 --> Config Class Initialized
INFO - 2024-09-17 12:40:24 --> Hooks Class Initialized
DEBUG - 2024-09-17 12:40:24 --> UTF-8 Support Enabled
INFO - 2024-09-17 12:40:24 --> Utf8 Class Initialized
INFO - 2024-09-17 12:40:24 --> URI Class Initialized
INFO - 2024-09-17 12:40:24 --> Router Class Initialized
INFO - 2024-09-17 12:40:24 --> Output Class Initialized
INFO - 2024-09-17 12:40:24 --> Security Class Initialized
DEBUG - 2024-09-17 12:40:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-17 12:40:24 --> Input Class Initialized
INFO - 2024-09-17 12:40:24 --> Language Class Initialized
INFO - 2024-09-17 12:40:24 --> Language Class Initialized
INFO - 2024-09-17 12:40:24 --> Config Class Initialized
INFO - 2024-09-17 12:40:24 --> Loader Class Initialized
INFO - 2024-09-17 12:40:24 --> Helper loaded: url_helper
INFO - 2024-09-17 12:40:24 --> Helper loaded: file_helper
INFO - 2024-09-17 12:40:24 --> Helper loaded: form_helper
INFO - 2024-09-17 12:40:24 --> Helper loaded: my_helper
INFO - 2024-09-17 12:40:24 --> Database Driver Class Initialized
INFO - 2024-09-17 12:40:24 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-17 12:40:24 --> Controller Class Initialized
INFO - 2024-09-17 12:40:26 --> Config Class Initialized
INFO - 2024-09-17 12:40:26 --> Hooks Class Initialized
DEBUG - 2024-09-17 12:40:26 --> UTF-8 Support Enabled
INFO - 2024-09-17 12:40:26 --> Utf8 Class Initialized
INFO - 2024-09-17 12:40:26 --> URI Class Initialized
INFO - 2024-09-17 12:40:26 --> Router Class Initialized
INFO - 2024-09-17 12:40:26 --> Output Class Initialized
INFO - 2024-09-17 12:40:26 --> Security Class Initialized
DEBUG - 2024-09-17 12:40:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-17 12:40:26 --> Input Class Initialized
INFO - 2024-09-17 12:40:26 --> Language Class Initialized
INFO - 2024-09-17 12:40:26 --> Language Class Initialized
INFO - 2024-09-17 12:40:26 --> Config Class Initialized
INFO - 2024-09-17 12:40:26 --> Loader Class Initialized
INFO - 2024-09-17 12:40:26 --> Helper loaded: url_helper
INFO - 2024-09-17 12:40:26 --> Helper loaded: file_helper
INFO - 2024-09-17 12:40:26 --> Helper loaded: form_helper
INFO - 2024-09-17 12:40:26 --> Helper loaded: my_helper
INFO - 2024-09-17 12:40:26 --> Database Driver Class Initialized
INFO - 2024-09-17 12:40:26 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-17 12:40:26 --> Controller Class Initialized
DEBUG - 2024-09-17 12:40:26 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/set_mapel/views/form.php
DEBUG - 2024-09-17 12:40:26 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-09-17 12:40:26 --> Final output sent to browser
DEBUG - 2024-09-17 12:40:26 --> Total execution time: 0.0290
INFO - 2024-09-17 12:40:40 --> Config Class Initialized
INFO - 2024-09-17 12:40:40 --> Hooks Class Initialized
DEBUG - 2024-09-17 12:40:40 --> UTF-8 Support Enabled
INFO - 2024-09-17 12:40:40 --> Utf8 Class Initialized
INFO - 2024-09-17 12:40:40 --> URI Class Initialized
INFO - 2024-09-17 12:40:40 --> Router Class Initialized
INFO - 2024-09-17 12:40:40 --> Output Class Initialized
INFO - 2024-09-17 12:40:40 --> Security Class Initialized
DEBUG - 2024-09-17 12:40:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-17 12:40:40 --> Input Class Initialized
INFO - 2024-09-17 12:40:40 --> Language Class Initialized
INFO - 2024-09-17 12:40:40 --> Language Class Initialized
INFO - 2024-09-17 12:40:40 --> Config Class Initialized
INFO - 2024-09-17 12:40:40 --> Loader Class Initialized
INFO - 2024-09-17 12:40:40 --> Helper loaded: url_helper
INFO - 2024-09-17 12:40:40 --> Helper loaded: file_helper
INFO - 2024-09-17 12:40:40 --> Helper loaded: form_helper
INFO - 2024-09-17 12:40:40 --> Helper loaded: my_helper
INFO - 2024-09-17 12:40:40 --> Database Driver Class Initialized
INFO - 2024-09-17 12:40:40 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-17 12:40:40 --> Controller Class Initialized
INFO - 2024-09-17 12:40:40 --> Config Class Initialized
INFO - 2024-09-17 12:40:40 --> Hooks Class Initialized
DEBUG - 2024-09-17 12:40:40 --> UTF-8 Support Enabled
INFO - 2024-09-17 12:40:40 --> Utf8 Class Initialized
INFO - 2024-09-17 12:40:40 --> URI Class Initialized
INFO - 2024-09-17 12:40:40 --> Router Class Initialized
INFO - 2024-09-17 12:40:40 --> Output Class Initialized
INFO - 2024-09-17 12:40:40 --> Security Class Initialized
DEBUG - 2024-09-17 12:40:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-17 12:40:40 --> Input Class Initialized
INFO - 2024-09-17 12:40:40 --> Language Class Initialized
INFO - 2024-09-17 12:40:40 --> Language Class Initialized
INFO - 2024-09-17 12:40:40 --> Config Class Initialized
INFO - 2024-09-17 12:40:40 --> Loader Class Initialized
INFO - 2024-09-17 12:40:40 --> Helper loaded: url_helper
INFO - 2024-09-17 12:40:40 --> Helper loaded: file_helper
INFO - 2024-09-17 12:40:40 --> Helper loaded: form_helper
INFO - 2024-09-17 12:40:40 --> Helper loaded: my_helper
INFO - 2024-09-17 12:40:40 --> Database Driver Class Initialized
INFO - 2024-09-17 12:40:40 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-17 12:40:40 --> Controller Class Initialized
DEBUG - 2024-09-17 12:40:40 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/set_mapel/views/list.php
DEBUG - 2024-09-17 12:40:40 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-09-17 12:40:40 --> Final output sent to browser
DEBUG - 2024-09-17 12:40:40 --> Total execution time: 0.0352
INFO - 2024-09-17 12:40:40 --> Config Class Initialized
INFO - 2024-09-17 12:40:40 --> Hooks Class Initialized
DEBUG - 2024-09-17 12:40:40 --> UTF-8 Support Enabled
INFO - 2024-09-17 12:40:40 --> Utf8 Class Initialized
INFO - 2024-09-17 12:40:40 --> URI Class Initialized
INFO - 2024-09-17 12:40:40 --> Router Class Initialized
INFO - 2024-09-17 12:40:40 --> Output Class Initialized
INFO - 2024-09-17 12:40:40 --> Security Class Initialized
DEBUG - 2024-09-17 12:40:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-17 12:40:40 --> Input Class Initialized
INFO - 2024-09-17 12:40:40 --> Language Class Initialized
ERROR - 2024-09-17 12:40:40 --> 404 Page Not Found: /index
INFO - 2024-09-17 12:40:40 --> Config Class Initialized
INFO - 2024-09-17 12:40:40 --> Hooks Class Initialized
DEBUG - 2024-09-17 12:40:40 --> UTF-8 Support Enabled
INFO - 2024-09-17 12:40:40 --> Utf8 Class Initialized
INFO - 2024-09-17 12:40:40 --> URI Class Initialized
INFO - 2024-09-17 12:40:40 --> Router Class Initialized
INFO - 2024-09-17 12:40:40 --> Output Class Initialized
INFO - 2024-09-17 12:40:40 --> Security Class Initialized
DEBUG - 2024-09-17 12:40:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-17 12:40:40 --> Input Class Initialized
INFO - 2024-09-17 12:40:40 --> Language Class Initialized
INFO - 2024-09-17 12:40:40 --> Language Class Initialized
INFO - 2024-09-17 12:40:40 --> Config Class Initialized
INFO - 2024-09-17 12:40:40 --> Loader Class Initialized
INFO - 2024-09-17 12:40:40 --> Helper loaded: url_helper
INFO - 2024-09-17 12:40:40 --> Helper loaded: file_helper
INFO - 2024-09-17 12:40:40 --> Helper loaded: form_helper
INFO - 2024-09-17 12:40:40 --> Helper loaded: my_helper
INFO - 2024-09-17 12:40:40 --> Database Driver Class Initialized
INFO - 2024-09-17 12:40:40 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-17 12:40:40 --> Controller Class Initialized
INFO - 2024-09-17 12:40:41 --> Config Class Initialized
INFO - 2024-09-17 12:40:41 --> Hooks Class Initialized
DEBUG - 2024-09-17 12:40:41 --> UTF-8 Support Enabled
INFO - 2024-09-17 12:40:41 --> Utf8 Class Initialized
INFO - 2024-09-17 12:40:41 --> URI Class Initialized
INFO - 2024-09-17 12:40:41 --> Router Class Initialized
INFO - 2024-09-17 12:40:41 --> Output Class Initialized
INFO - 2024-09-17 12:40:41 --> Security Class Initialized
DEBUG - 2024-09-17 12:40:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-17 12:40:41 --> Input Class Initialized
INFO - 2024-09-17 12:40:41 --> Language Class Initialized
INFO - 2024-09-17 12:40:41 --> Language Class Initialized
INFO - 2024-09-17 12:40:41 --> Config Class Initialized
INFO - 2024-09-17 12:40:41 --> Loader Class Initialized
INFO - 2024-09-17 12:40:41 --> Helper loaded: url_helper
INFO - 2024-09-17 12:40:41 --> Helper loaded: file_helper
INFO - 2024-09-17 12:40:41 --> Helper loaded: form_helper
INFO - 2024-09-17 12:40:41 --> Helper loaded: my_helper
INFO - 2024-09-17 12:40:41 --> Database Driver Class Initialized
INFO - 2024-09-17 12:40:41 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-17 12:40:41 --> Controller Class Initialized
DEBUG - 2024-09-17 12:40:41 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/set_mapel/views/form.php
DEBUG - 2024-09-17 12:40:41 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-09-17 12:40:41 --> Final output sent to browser
DEBUG - 2024-09-17 12:40:41 --> Total execution time: 0.0435
INFO - 2024-09-17 12:40:56 --> Config Class Initialized
INFO - 2024-09-17 12:40:56 --> Hooks Class Initialized
DEBUG - 2024-09-17 12:40:56 --> UTF-8 Support Enabled
INFO - 2024-09-17 12:40:56 --> Utf8 Class Initialized
INFO - 2024-09-17 12:40:56 --> URI Class Initialized
INFO - 2024-09-17 12:40:56 --> Router Class Initialized
INFO - 2024-09-17 12:40:56 --> Output Class Initialized
INFO - 2024-09-17 12:40:56 --> Security Class Initialized
DEBUG - 2024-09-17 12:40:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-17 12:40:56 --> Input Class Initialized
INFO - 2024-09-17 12:40:56 --> Language Class Initialized
INFO - 2024-09-17 12:40:56 --> Language Class Initialized
INFO - 2024-09-17 12:40:56 --> Config Class Initialized
INFO - 2024-09-17 12:40:56 --> Loader Class Initialized
INFO - 2024-09-17 12:40:56 --> Helper loaded: url_helper
INFO - 2024-09-17 12:40:56 --> Helper loaded: file_helper
INFO - 2024-09-17 12:40:56 --> Helper loaded: form_helper
INFO - 2024-09-17 12:40:56 --> Helper loaded: my_helper
INFO - 2024-09-17 12:40:56 --> Database Driver Class Initialized
INFO - 2024-09-17 12:40:56 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-17 12:40:56 --> Controller Class Initialized
INFO - 2024-09-17 12:40:56 --> Config Class Initialized
INFO - 2024-09-17 12:40:56 --> Hooks Class Initialized
DEBUG - 2024-09-17 12:40:56 --> UTF-8 Support Enabled
INFO - 2024-09-17 12:40:56 --> Utf8 Class Initialized
INFO - 2024-09-17 12:40:56 --> URI Class Initialized
INFO - 2024-09-17 12:40:56 --> Router Class Initialized
INFO - 2024-09-17 12:40:56 --> Output Class Initialized
INFO - 2024-09-17 12:40:56 --> Security Class Initialized
DEBUG - 2024-09-17 12:40:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-17 12:40:56 --> Input Class Initialized
INFO - 2024-09-17 12:40:56 --> Language Class Initialized
INFO - 2024-09-17 12:40:56 --> Language Class Initialized
INFO - 2024-09-17 12:40:56 --> Config Class Initialized
INFO - 2024-09-17 12:40:56 --> Loader Class Initialized
INFO - 2024-09-17 12:40:56 --> Helper loaded: url_helper
INFO - 2024-09-17 12:40:56 --> Helper loaded: file_helper
INFO - 2024-09-17 12:40:56 --> Helper loaded: form_helper
INFO - 2024-09-17 12:40:56 --> Helper loaded: my_helper
INFO - 2024-09-17 12:40:56 --> Database Driver Class Initialized
INFO - 2024-09-17 12:40:56 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-17 12:40:56 --> Controller Class Initialized
DEBUG - 2024-09-17 12:40:56 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/set_mapel/views/list.php
DEBUG - 2024-09-17 12:40:56 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-09-17 12:40:56 --> Final output sent to browser
DEBUG - 2024-09-17 12:40:56 --> Total execution time: 0.0494
INFO - 2024-09-17 12:40:57 --> Config Class Initialized
INFO - 2024-09-17 12:40:57 --> Hooks Class Initialized
DEBUG - 2024-09-17 12:40:57 --> UTF-8 Support Enabled
INFO - 2024-09-17 12:40:57 --> Utf8 Class Initialized
INFO - 2024-09-17 12:40:57 --> URI Class Initialized
INFO - 2024-09-17 12:40:57 --> Router Class Initialized
INFO - 2024-09-17 12:40:57 --> Output Class Initialized
INFO - 2024-09-17 12:40:57 --> Security Class Initialized
DEBUG - 2024-09-17 12:40:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-17 12:40:57 --> Input Class Initialized
INFO - 2024-09-17 12:40:57 --> Language Class Initialized
ERROR - 2024-09-17 12:40:57 --> 404 Page Not Found: /index
INFO - 2024-09-17 12:40:57 --> Config Class Initialized
INFO - 2024-09-17 12:40:57 --> Hooks Class Initialized
DEBUG - 2024-09-17 12:40:57 --> UTF-8 Support Enabled
INFO - 2024-09-17 12:40:57 --> Utf8 Class Initialized
INFO - 2024-09-17 12:40:57 --> URI Class Initialized
INFO - 2024-09-17 12:40:57 --> Router Class Initialized
INFO - 2024-09-17 12:40:57 --> Output Class Initialized
INFO - 2024-09-17 12:40:57 --> Security Class Initialized
DEBUG - 2024-09-17 12:40:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-17 12:40:57 --> Input Class Initialized
INFO - 2024-09-17 12:40:57 --> Language Class Initialized
INFO - 2024-09-17 12:40:57 --> Language Class Initialized
INFO - 2024-09-17 12:40:57 --> Config Class Initialized
INFO - 2024-09-17 12:40:57 --> Loader Class Initialized
INFO - 2024-09-17 12:40:57 --> Helper loaded: url_helper
INFO - 2024-09-17 12:40:57 --> Helper loaded: file_helper
INFO - 2024-09-17 12:40:57 --> Helper loaded: form_helper
INFO - 2024-09-17 12:40:57 --> Helper loaded: my_helper
INFO - 2024-09-17 12:40:57 --> Database Driver Class Initialized
INFO - 2024-09-17 12:40:57 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-17 12:40:57 --> Controller Class Initialized
INFO - 2024-09-17 12:40:59 --> Config Class Initialized
INFO - 2024-09-17 12:40:59 --> Hooks Class Initialized
DEBUG - 2024-09-17 12:40:59 --> UTF-8 Support Enabled
INFO - 2024-09-17 12:40:59 --> Utf8 Class Initialized
INFO - 2024-09-17 12:40:59 --> URI Class Initialized
INFO - 2024-09-17 12:40:59 --> Router Class Initialized
INFO - 2024-09-17 12:40:59 --> Output Class Initialized
INFO - 2024-09-17 12:40:59 --> Security Class Initialized
DEBUG - 2024-09-17 12:40:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-17 12:40:59 --> Input Class Initialized
INFO - 2024-09-17 12:40:59 --> Language Class Initialized
INFO - 2024-09-17 12:40:59 --> Language Class Initialized
INFO - 2024-09-17 12:40:59 --> Config Class Initialized
INFO - 2024-09-17 12:40:59 --> Loader Class Initialized
INFO - 2024-09-17 12:40:59 --> Helper loaded: url_helper
INFO - 2024-09-17 12:40:59 --> Helper loaded: file_helper
INFO - 2024-09-17 12:40:59 --> Helper loaded: form_helper
INFO - 2024-09-17 12:40:59 --> Helper loaded: my_helper
INFO - 2024-09-17 12:40:59 --> Database Driver Class Initialized
INFO - 2024-09-17 12:40:59 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-17 12:40:59 --> Controller Class Initialized
DEBUG - 2024-09-17 12:40:59 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/set_mapel/views/form.php
DEBUG - 2024-09-17 12:40:59 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-09-17 12:40:59 --> Final output sent to browser
DEBUG - 2024-09-17 12:40:59 --> Total execution time: 0.0990
INFO - 2024-09-17 12:41:25 --> Config Class Initialized
INFO - 2024-09-17 12:41:25 --> Hooks Class Initialized
DEBUG - 2024-09-17 12:41:25 --> UTF-8 Support Enabled
INFO - 2024-09-17 12:41:25 --> Utf8 Class Initialized
INFO - 2024-09-17 12:41:25 --> URI Class Initialized
INFO - 2024-09-17 12:41:25 --> Router Class Initialized
INFO - 2024-09-17 12:41:25 --> Output Class Initialized
INFO - 2024-09-17 12:41:25 --> Security Class Initialized
DEBUG - 2024-09-17 12:41:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-17 12:41:25 --> Input Class Initialized
INFO - 2024-09-17 12:41:25 --> Language Class Initialized
INFO - 2024-09-17 12:41:25 --> Language Class Initialized
INFO - 2024-09-17 12:41:25 --> Config Class Initialized
INFO - 2024-09-17 12:41:25 --> Loader Class Initialized
INFO - 2024-09-17 12:41:25 --> Helper loaded: url_helper
INFO - 2024-09-17 12:41:25 --> Helper loaded: file_helper
INFO - 2024-09-17 12:41:25 --> Helper loaded: form_helper
INFO - 2024-09-17 12:41:25 --> Helper loaded: my_helper
INFO - 2024-09-17 12:41:25 --> Database Driver Class Initialized
INFO - 2024-09-17 12:41:25 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-17 12:41:25 --> Controller Class Initialized
INFO - 2024-09-17 12:41:25 --> Config Class Initialized
INFO - 2024-09-17 12:41:25 --> Hooks Class Initialized
DEBUG - 2024-09-17 12:41:25 --> UTF-8 Support Enabled
INFO - 2024-09-17 12:41:25 --> Utf8 Class Initialized
INFO - 2024-09-17 12:41:25 --> URI Class Initialized
INFO - 2024-09-17 12:41:25 --> Router Class Initialized
INFO - 2024-09-17 12:41:25 --> Output Class Initialized
INFO - 2024-09-17 12:41:25 --> Security Class Initialized
DEBUG - 2024-09-17 12:41:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-17 12:41:25 --> Input Class Initialized
INFO - 2024-09-17 12:41:25 --> Language Class Initialized
INFO - 2024-09-17 12:41:25 --> Language Class Initialized
INFO - 2024-09-17 12:41:25 --> Config Class Initialized
INFO - 2024-09-17 12:41:25 --> Loader Class Initialized
INFO - 2024-09-17 12:41:25 --> Helper loaded: url_helper
INFO - 2024-09-17 12:41:25 --> Helper loaded: file_helper
INFO - 2024-09-17 12:41:25 --> Helper loaded: form_helper
INFO - 2024-09-17 12:41:25 --> Helper loaded: my_helper
INFO - 2024-09-17 12:41:25 --> Database Driver Class Initialized
INFO - 2024-09-17 12:41:25 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-17 12:41:25 --> Controller Class Initialized
DEBUG - 2024-09-17 12:41:25 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/set_mapel/views/list.php
DEBUG - 2024-09-17 12:41:25 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-09-17 12:41:25 --> Final output sent to browser
DEBUG - 2024-09-17 12:41:25 --> Total execution time: 0.0246
INFO - 2024-09-17 12:41:25 --> Config Class Initialized
INFO - 2024-09-17 12:41:25 --> Hooks Class Initialized
DEBUG - 2024-09-17 12:41:25 --> UTF-8 Support Enabled
INFO - 2024-09-17 12:41:25 --> Utf8 Class Initialized
INFO - 2024-09-17 12:41:25 --> URI Class Initialized
INFO - 2024-09-17 12:41:25 --> Router Class Initialized
INFO - 2024-09-17 12:41:25 --> Output Class Initialized
INFO - 2024-09-17 12:41:25 --> Security Class Initialized
DEBUG - 2024-09-17 12:41:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-17 12:41:25 --> Input Class Initialized
INFO - 2024-09-17 12:41:25 --> Language Class Initialized
ERROR - 2024-09-17 12:41:25 --> 404 Page Not Found: /index
INFO - 2024-09-17 12:41:25 --> Config Class Initialized
INFO - 2024-09-17 12:41:25 --> Hooks Class Initialized
DEBUG - 2024-09-17 12:41:25 --> UTF-8 Support Enabled
INFO - 2024-09-17 12:41:25 --> Utf8 Class Initialized
INFO - 2024-09-17 12:41:25 --> URI Class Initialized
INFO - 2024-09-17 12:41:25 --> Router Class Initialized
INFO - 2024-09-17 12:41:25 --> Output Class Initialized
INFO - 2024-09-17 12:41:25 --> Security Class Initialized
DEBUG - 2024-09-17 12:41:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-17 12:41:25 --> Input Class Initialized
INFO - 2024-09-17 12:41:25 --> Language Class Initialized
INFO - 2024-09-17 12:41:25 --> Language Class Initialized
INFO - 2024-09-17 12:41:25 --> Config Class Initialized
INFO - 2024-09-17 12:41:25 --> Loader Class Initialized
INFO - 2024-09-17 12:41:25 --> Helper loaded: url_helper
INFO - 2024-09-17 12:41:25 --> Helper loaded: file_helper
INFO - 2024-09-17 12:41:25 --> Helper loaded: form_helper
INFO - 2024-09-17 12:41:25 --> Helper loaded: my_helper
INFO - 2024-09-17 12:41:25 --> Database Driver Class Initialized
INFO - 2024-09-17 12:41:25 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-17 12:41:25 --> Controller Class Initialized
INFO - 2024-09-17 12:41:27 --> Config Class Initialized
INFO - 2024-09-17 12:41:27 --> Hooks Class Initialized
DEBUG - 2024-09-17 12:41:27 --> UTF-8 Support Enabled
INFO - 2024-09-17 12:41:27 --> Utf8 Class Initialized
INFO - 2024-09-17 12:41:27 --> URI Class Initialized
INFO - 2024-09-17 12:41:27 --> Router Class Initialized
INFO - 2024-09-17 12:41:27 --> Output Class Initialized
INFO - 2024-09-17 12:41:27 --> Security Class Initialized
DEBUG - 2024-09-17 12:41:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-17 12:41:27 --> Input Class Initialized
INFO - 2024-09-17 12:41:27 --> Language Class Initialized
INFO - 2024-09-17 12:41:27 --> Language Class Initialized
INFO - 2024-09-17 12:41:27 --> Config Class Initialized
INFO - 2024-09-17 12:41:27 --> Loader Class Initialized
INFO - 2024-09-17 12:41:27 --> Helper loaded: url_helper
INFO - 2024-09-17 12:41:27 --> Helper loaded: file_helper
INFO - 2024-09-17 12:41:27 --> Helper loaded: form_helper
INFO - 2024-09-17 12:41:27 --> Helper loaded: my_helper
INFO - 2024-09-17 12:41:27 --> Database Driver Class Initialized
INFO - 2024-09-17 12:41:27 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-17 12:41:27 --> Controller Class Initialized
DEBUG - 2024-09-17 12:41:27 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/set_mapel/views/form.php
DEBUG - 2024-09-17 12:41:27 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-09-17 12:41:27 --> Final output sent to browser
DEBUG - 2024-09-17 12:41:27 --> Total execution time: 0.0317
INFO - 2024-09-17 12:41:40 --> Config Class Initialized
INFO - 2024-09-17 12:41:40 --> Hooks Class Initialized
DEBUG - 2024-09-17 12:41:40 --> UTF-8 Support Enabled
INFO - 2024-09-17 12:41:40 --> Utf8 Class Initialized
INFO - 2024-09-17 12:41:40 --> URI Class Initialized
INFO - 2024-09-17 12:41:40 --> Router Class Initialized
INFO - 2024-09-17 12:41:40 --> Output Class Initialized
INFO - 2024-09-17 12:41:40 --> Security Class Initialized
DEBUG - 2024-09-17 12:41:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-17 12:41:40 --> Input Class Initialized
INFO - 2024-09-17 12:41:40 --> Language Class Initialized
INFO - 2024-09-17 12:41:40 --> Language Class Initialized
INFO - 2024-09-17 12:41:40 --> Config Class Initialized
INFO - 2024-09-17 12:41:40 --> Loader Class Initialized
INFO - 2024-09-17 12:41:40 --> Helper loaded: url_helper
INFO - 2024-09-17 12:41:40 --> Helper loaded: file_helper
INFO - 2024-09-17 12:41:40 --> Helper loaded: form_helper
INFO - 2024-09-17 12:41:40 --> Helper loaded: my_helper
INFO - 2024-09-17 12:41:40 --> Database Driver Class Initialized
INFO - 2024-09-17 12:41:40 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-17 12:41:40 --> Controller Class Initialized
INFO - 2024-09-17 12:41:40 --> Config Class Initialized
INFO - 2024-09-17 12:41:40 --> Hooks Class Initialized
DEBUG - 2024-09-17 12:41:40 --> UTF-8 Support Enabled
INFO - 2024-09-17 12:41:40 --> Utf8 Class Initialized
INFO - 2024-09-17 12:41:40 --> URI Class Initialized
INFO - 2024-09-17 12:41:40 --> Router Class Initialized
INFO - 2024-09-17 12:41:40 --> Output Class Initialized
INFO - 2024-09-17 12:41:40 --> Security Class Initialized
DEBUG - 2024-09-17 12:41:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-17 12:41:40 --> Input Class Initialized
INFO - 2024-09-17 12:41:40 --> Language Class Initialized
INFO - 2024-09-17 12:41:40 --> Language Class Initialized
INFO - 2024-09-17 12:41:40 --> Config Class Initialized
INFO - 2024-09-17 12:41:40 --> Loader Class Initialized
INFO - 2024-09-17 12:41:40 --> Helper loaded: url_helper
INFO - 2024-09-17 12:41:40 --> Helper loaded: file_helper
INFO - 2024-09-17 12:41:40 --> Helper loaded: form_helper
INFO - 2024-09-17 12:41:40 --> Helper loaded: my_helper
INFO - 2024-09-17 12:41:40 --> Database Driver Class Initialized
INFO - 2024-09-17 12:41:40 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-17 12:41:40 --> Controller Class Initialized
DEBUG - 2024-09-17 12:41:40 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/set_mapel/views/list.php
DEBUG - 2024-09-17 12:41:40 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-09-17 12:41:40 --> Final output sent to browser
DEBUG - 2024-09-17 12:41:40 --> Total execution time: 0.0544
INFO - 2024-09-17 12:41:40 --> Config Class Initialized
INFO - 2024-09-17 12:41:40 --> Hooks Class Initialized
DEBUG - 2024-09-17 12:41:40 --> UTF-8 Support Enabled
INFO - 2024-09-17 12:41:40 --> Utf8 Class Initialized
INFO - 2024-09-17 12:41:40 --> URI Class Initialized
INFO - 2024-09-17 12:41:40 --> Router Class Initialized
INFO - 2024-09-17 12:41:40 --> Output Class Initialized
INFO - 2024-09-17 12:41:40 --> Security Class Initialized
DEBUG - 2024-09-17 12:41:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-17 12:41:40 --> Input Class Initialized
INFO - 2024-09-17 12:41:40 --> Language Class Initialized
ERROR - 2024-09-17 12:41:40 --> 404 Page Not Found: /index
INFO - 2024-09-17 12:41:40 --> Config Class Initialized
INFO - 2024-09-17 12:41:40 --> Hooks Class Initialized
DEBUG - 2024-09-17 12:41:40 --> UTF-8 Support Enabled
INFO - 2024-09-17 12:41:40 --> Utf8 Class Initialized
INFO - 2024-09-17 12:41:40 --> URI Class Initialized
INFO - 2024-09-17 12:41:40 --> Router Class Initialized
INFO - 2024-09-17 12:41:40 --> Output Class Initialized
INFO - 2024-09-17 12:41:40 --> Security Class Initialized
DEBUG - 2024-09-17 12:41:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-17 12:41:40 --> Input Class Initialized
INFO - 2024-09-17 12:41:40 --> Language Class Initialized
INFO - 2024-09-17 12:41:40 --> Language Class Initialized
INFO - 2024-09-17 12:41:40 --> Config Class Initialized
INFO - 2024-09-17 12:41:40 --> Loader Class Initialized
INFO - 2024-09-17 12:41:40 --> Helper loaded: url_helper
INFO - 2024-09-17 12:41:40 --> Helper loaded: file_helper
INFO - 2024-09-17 12:41:40 --> Helper loaded: form_helper
INFO - 2024-09-17 12:41:40 --> Helper loaded: my_helper
INFO - 2024-09-17 12:41:40 --> Database Driver Class Initialized
INFO - 2024-09-17 12:41:40 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-17 12:41:40 --> Controller Class Initialized
INFO - 2024-09-17 12:41:42 --> Config Class Initialized
INFO - 2024-09-17 12:41:42 --> Hooks Class Initialized
DEBUG - 2024-09-17 12:41:42 --> UTF-8 Support Enabled
INFO - 2024-09-17 12:41:42 --> Utf8 Class Initialized
INFO - 2024-09-17 12:41:42 --> URI Class Initialized
INFO - 2024-09-17 12:41:42 --> Router Class Initialized
INFO - 2024-09-17 12:41:42 --> Output Class Initialized
INFO - 2024-09-17 12:41:42 --> Security Class Initialized
DEBUG - 2024-09-17 12:41:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-17 12:41:42 --> Input Class Initialized
INFO - 2024-09-17 12:41:42 --> Language Class Initialized
INFO - 2024-09-17 12:41:42 --> Language Class Initialized
INFO - 2024-09-17 12:41:42 --> Config Class Initialized
INFO - 2024-09-17 12:41:42 --> Loader Class Initialized
INFO - 2024-09-17 12:41:42 --> Helper loaded: url_helper
INFO - 2024-09-17 12:41:42 --> Helper loaded: file_helper
INFO - 2024-09-17 12:41:42 --> Helper loaded: form_helper
INFO - 2024-09-17 12:41:42 --> Helper loaded: my_helper
INFO - 2024-09-17 12:41:42 --> Database Driver Class Initialized
INFO - 2024-09-17 12:41:42 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-17 12:41:42 --> Controller Class Initialized
DEBUG - 2024-09-17 12:41:42 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/set_mapel/views/form.php
DEBUG - 2024-09-17 12:41:42 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-09-17 12:41:42 --> Final output sent to browser
DEBUG - 2024-09-17 12:41:42 --> Total execution time: 0.0290
INFO - 2024-09-17 12:41:55 --> Config Class Initialized
INFO - 2024-09-17 12:41:55 --> Hooks Class Initialized
DEBUG - 2024-09-17 12:41:55 --> UTF-8 Support Enabled
INFO - 2024-09-17 12:41:55 --> Utf8 Class Initialized
INFO - 2024-09-17 12:41:55 --> URI Class Initialized
INFO - 2024-09-17 12:41:55 --> Router Class Initialized
INFO - 2024-09-17 12:41:55 --> Output Class Initialized
INFO - 2024-09-17 12:41:55 --> Security Class Initialized
DEBUG - 2024-09-17 12:41:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-17 12:41:55 --> Input Class Initialized
INFO - 2024-09-17 12:41:55 --> Language Class Initialized
INFO - 2024-09-17 12:41:55 --> Language Class Initialized
INFO - 2024-09-17 12:41:55 --> Config Class Initialized
INFO - 2024-09-17 12:41:55 --> Loader Class Initialized
INFO - 2024-09-17 12:41:55 --> Helper loaded: url_helper
INFO - 2024-09-17 12:41:55 --> Helper loaded: file_helper
INFO - 2024-09-17 12:41:55 --> Helper loaded: form_helper
INFO - 2024-09-17 12:41:55 --> Helper loaded: my_helper
INFO - 2024-09-17 12:41:55 --> Database Driver Class Initialized
INFO - 2024-09-17 12:41:55 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-17 12:41:55 --> Controller Class Initialized
INFO - 2024-09-17 12:41:55 --> Config Class Initialized
INFO - 2024-09-17 12:41:55 --> Hooks Class Initialized
DEBUG - 2024-09-17 12:41:55 --> UTF-8 Support Enabled
INFO - 2024-09-17 12:41:55 --> Utf8 Class Initialized
INFO - 2024-09-17 12:41:55 --> URI Class Initialized
INFO - 2024-09-17 12:41:55 --> Router Class Initialized
INFO - 2024-09-17 12:41:55 --> Output Class Initialized
INFO - 2024-09-17 12:41:55 --> Security Class Initialized
DEBUG - 2024-09-17 12:41:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-17 12:41:55 --> Input Class Initialized
INFO - 2024-09-17 12:41:55 --> Language Class Initialized
INFO - 2024-09-17 12:41:55 --> Language Class Initialized
INFO - 2024-09-17 12:41:55 --> Config Class Initialized
INFO - 2024-09-17 12:41:55 --> Loader Class Initialized
INFO - 2024-09-17 12:41:55 --> Helper loaded: url_helper
INFO - 2024-09-17 12:41:55 --> Helper loaded: file_helper
INFO - 2024-09-17 12:41:55 --> Helper loaded: form_helper
INFO - 2024-09-17 12:41:55 --> Helper loaded: my_helper
INFO - 2024-09-17 12:41:55 --> Database Driver Class Initialized
INFO - 2024-09-17 12:41:55 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-17 12:41:55 --> Controller Class Initialized
DEBUG - 2024-09-17 12:41:55 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/set_mapel/views/list.php
DEBUG - 2024-09-17 12:41:55 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-09-17 12:41:55 --> Final output sent to browser
DEBUG - 2024-09-17 12:41:55 --> Total execution time: 0.0390
INFO - 2024-09-17 12:41:56 --> Config Class Initialized
INFO - 2024-09-17 12:41:56 --> Hooks Class Initialized
DEBUG - 2024-09-17 12:41:56 --> UTF-8 Support Enabled
INFO - 2024-09-17 12:41:56 --> Utf8 Class Initialized
INFO - 2024-09-17 12:41:56 --> URI Class Initialized
INFO - 2024-09-17 12:41:56 --> Router Class Initialized
INFO - 2024-09-17 12:41:56 --> Output Class Initialized
INFO - 2024-09-17 12:41:56 --> Security Class Initialized
DEBUG - 2024-09-17 12:41:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-17 12:41:56 --> Input Class Initialized
INFO - 2024-09-17 12:41:56 --> Language Class Initialized
ERROR - 2024-09-17 12:41:56 --> 404 Page Not Found: /index
INFO - 2024-09-17 12:41:56 --> Config Class Initialized
INFO - 2024-09-17 12:41:56 --> Hooks Class Initialized
DEBUG - 2024-09-17 12:41:56 --> UTF-8 Support Enabled
INFO - 2024-09-17 12:41:56 --> Utf8 Class Initialized
INFO - 2024-09-17 12:41:56 --> URI Class Initialized
INFO - 2024-09-17 12:41:56 --> Router Class Initialized
INFO - 2024-09-17 12:41:56 --> Output Class Initialized
INFO - 2024-09-17 12:41:56 --> Security Class Initialized
DEBUG - 2024-09-17 12:41:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-17 12:41:56 --> Input Class Initialized
INFO - 2024-09-17 12:41:56 --> Language Class Initialized
INFO - 2024-09-17 12:41:56 --> Language Class Initialized
INFO - 2024-09-17 12:41:56 --> Config Class Initialized
INFO - 2024-09-17 12:41:56 --> Loader Class Initialized
INFO - 2024-09-17 12:41:56 --> Helper loaded: url_helper
INFO - 2024-09-17 12:41:56 --> Helper loaded: file_helper
INFO - 2024-09-17 12:41:56 --> Helper loaded: form_helper
INFO - 2024-09-17 12:41:56 --> Helper loaded: my_helper
INFO - 2024-09-17 12:41:56 --> Database Driver Class Initialized
INFO - 2024-09-17 12:41:56 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-17 12:41:56 --> Controller Class Initialized
INFO - 2024-09-17 12:42:23 --> Config Class Initialized
INFO - 2024-09-17 12:42:23 --> Hooks Class Initialized
DEBUG - 2024-09-17 12:42:23 --> UTF-8 Support Enabled
INFO - 2024-09-17 12:42:23 --> Utf8 Class Initialized
INFO - 2024-09-17 12:42:23 --> URI Class Initialized
INFO - 2024-09-17 12:42:23 --> Router Class Initialized
INFO - 2024-09-17 12:42:23 --> Output Class Initialized
INFO - 2024-09-17 12:42:23 --> Security Class Initialized
DEBUG - 2024-09-17 12:42:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-17 12:42:23 --> Input Class Initialized
INFO - 2024-09-17 12:42:23 --> Language Class Initialized
INFO - 2024-09-17 12:42:23 --> Language Class Initialized
INFO - 2024-09-17 12:42:23 --> Config Class Initialized
INFO - 2024-09-17 12:42:23 --> Loader Class Initialized
INFO - 2024-09-17 12:42:23 --> Helper loaded: url_helper
INFO - 2024-09-17 12:42:23 --> Helper loaded: file_helper
INFO - 2024-09-17 12:42:23 --> Helper loaded: form_helper
INFO - 2024-09-17 12:42:23 --> Helper loaded: my_helper
INFO - 2024-09-17 12:42:23 --> Database Driver Class Initialized
INFO - 2024-09-17 12:42:23 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-17 12:42:23 --> Controller Class Initialized
INFO - 2024-09-17 12:42:23 --> Final output sent to browser
DEBUG - 2024-09-17 12:42:23 --> Total execution time: 0.0640
INFO - 2024-09-17 12:42:23 --> Config Class Initialized
INFO - 2024-09-17 12:42:23 --> Hooks Class Initialized
DEBUG - 2024-09-17 12:42:23 --> UTF-8 Support Enabled
INFO - 2024-09-17 12:42:23 --> Utf8 Class Initialized
INFO - 2024-09-17 12:42:23 --> URI Class Initialized
INFO - 2024-09-17 12:42:23 --> Router Class Initialized
INFO - 2024-09-17 12:42:23 --> Output Class Initialized
INFO - 2024-09-17 12:42:23 --> Security Class Initialized
DEBUG - 2024-09-17 12:42:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-17 12:42:23 --> Input Class Initialized
INFO - 2024-09-17 12:42:23 --> Language Class Initialized
ERROR - 2024-09-17 12:42:23 --> 404 Page Not Found: /index
INFO - 2024-09-17 12:42:23 --> Config Class Initialized
INFO - 2024-09-17 12:42:23 --> Hooks Class Initialized
DEBUG - 2024-09-17 12:42:23 --> UTF-8 Support Enabled
INFO - 2024-09-17 12:42:23 --> Utf8 Class Initialized
INFO - 2024-09-17 12:42:23 --> URI Class Initialized
INFO - 2024-09-17 12:42:23 --> Router Class Initialized
INFO - 2024-09-17 12:42:23 --> Output Class Initialized
INFO - 2024-09-17 12:42:23 --> Security Class Initialized
DEBUG - 2024-09-17 12:42:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-17 12:42:23 --> Input Class Initialized
INFO - 2024-09-17 12:42:23 --> Language Class Initialized
INFO - 2024-09-17 12:42:23 --> Language Class Initialized
INFO - 2024-09-17 12:42:23 --> Config Class Initialized
INFO - 2024-09-17 12:42:23 --> Loader Class Initialized
INFO - 2024-09-17 12:42:23 --> Helper loaded: url_helper
INFO - 2024-09-17 12:42:23 --> Helper loaded: file_helper
INFO - 2024-09-17 12:42:23 --> Helper loaded: form_helper
INFO - 2024-09-17 12:42:23 --> Helper loaded: my_helper
INFO - 2024-09-17 12:42:23 --> Database Driver Class Initialized
INFO - 2024-09-17 12:42:23 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-17 12:42:23 --> Controller Class Initialized
INFO - 2024-09-17 12:42:27 --> Config Class Initialized
INFO - 2024-09-17 12:42:27 --> Hooks Class Initialized
DEBUG - 2024-09-17 12:42:27 --> UTF-8 Support Enabled
INFO - 2024-09-17 12:42:27 --> Utf8 Class Initialized
INFO - 2024-09-17 12:42:27 --> URI Class Initialized
INFO - 2024-09-17 12:42:27 --> Router Class Initialized
INFO - 2024-09-17 12:42:27 --> Output Class Initialized
INFO - 2024-09-17 12:42:27 --> Security Class Initialized
DEBUG - 2024-09-17 12:42:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-17 12:42:27 --> Input Class Initialized
INFO - 2024-09-17 12:42:27 --> Language Class Initialized
INFO - 2024-09-17 12:42:27 --> Language Class Initialized
INFO - 2024-09-17 12:42:27 --> Config Class Initialized
INFO - 2024-09-17 12:42:27 --> Loader Class Initialized
INFO - 2024-09-17 12:42:27 --> Helper loaded: url_helper
INFO - 2024-09-17 12:42:27 --> Helper loaded: file_helper
INFO - 2024-09-17 12:42:27 --> Helper loaded: form_helper
INFO - 2024-09-17 12:42:27 --> Helper loaded: my_helper
INFO - 2024-09-17 12:42:27 --> Database Driver Class Initialized
INFO - 2024-09-17 12:42:27 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-17 12:42:27 --> Controller Class Initialized
INFO - 2024-09-17 12:42:27 --> Final output sent to browser
DEBUG - 2024-09-17 12:42:27 --> Total execution time: 0.0287
INFO - 2024-09-17 12:42:27 --> Config Class Initialized
INFO - 2024-09-17 12:42:27 --> Hooks Class Initialized
DEBUG - 2024-09-17 12:42:27 --> UTF-8 Support Enabled
INFO - 2024-09-17 12:42:27 --> Utf8 Class Initialized
INFO - 2024-09-17 12:42:27 --> URI Class Initialized
INFO - 2024-09-17 12:42:27 --> Router Class Initialized
INFO - 2024-09-17 12:42:27 --> Output Class Initialized
INFO - 2024-09-17 12:42:27 --> Security Class Initialized
DEBUG - 2024-09-17 12:42:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-17 12:42:27 --> Input Class Initialized
INFO - 2024-09-17 12:42:27 --> Language Class Initialized
ERROR - 2024-09-17 12:42:27 --> 404 Page Not Found: /index
INFO - 2024-09-17 12:42:27 --> Config Class Initialized
INFO - 2024-09-17 12:42:27 --> Hooks Class Initialized
DEBUG - 2024-09-17 12:42:27 --> UTF-8 Support Enabled
INFO - 2024-09-17 12:42:27 --> Utf8 Class Initialized
INFO - 2024-09-17 12:42:27 --> URI Class Initialized
INFO - 2024-09-17 12:42:27 --> Router Class Initialized
INFO - 2024-09-17 12:42:27 --> Output Class Initialized
INFO - 2024-09-17 12:42:27 --> Security Class Initialized
DEBUG - 2024-09-17 12:42:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-17 12:42:27 --> Input Class Initialized
INFO - 2024-09-17 12:42:27 --> Language Class Initialized
INFO - 2024-09-17 12:42:27 --> Language Class Initialized
INFO - 2024-09-17 12:42:27 --> Config Class Initialized
INFO - 2024-09-17 12:42:27 --> Loader Class Initialized
INFO - 2024-09-17 12:42:27 --> Helper loaded: url_helper
INFO - 2024-09-17 12:42:27 --> Helper loaded: file_helper
INFO - 2024-09-17 12:42:27 --> Helper loaded: form_helper
INFO - 2024-09-17 12:42:27 --> Helper loaded: my_helper
INFO - 2024-09-17 12:42:27 --> Database Driver Class Initialized
INFO - 2024-09-17 12:42:27 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-17 12:42:27 --> Controller Class Initialized
INFO - 2024-09-17 12:42:30 --> Config Class Initialized
INFO - 2024-09-17 12:42:30 --> Hooks Class Initialized
DEBUG - 2024-09-17 12:42:30 --> UTF-8 Support Enabled
INFO - 2024-09-17 12:42:30 --> Utf8 Class Initialized
INFO - 2024-09-17 12:42:30 --> URI Class Initialized
INFO - 2024-09-17 12:42:30 --> Router Class Initialized
INFO - 2024-09-17 12:42:30 --> Output Class Initialized
INFO - 2024-09-17 12:42:30 --> Security Class Initialized
DEBUG - 2024-09-17 12:42:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-17 12:42:30 --> Input Class Initialized
INFO - 2024-09-17 12:42:30 --> Language Class Initialized
INFO - 2024-09-17 12:42:30 --> Language Class Initialized
INFO - 2024-09-17 12:42:30 --> Config Class Initialized
INFO - 2024-09-17 12:42:30 --> Loader Class Initialized
INFO - 2024-09-17 12:42:30 --> Helper loaded: url_helper
INFO - 2024-09-17 12:42:30 --> Helper loaded: file_helper
INFO - 2024-09-17 12:42:30 --> Helper loaded: form_helper
INFO - 2024-09-17 12:42:30 --> Helper loaded: my_helper
INFO - 2024-09-17 12:42:30 --> Database Driver Class Initialized
INFO - 2024-09-17 12:42:30 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-17 12:42:30 --> Controller Class Initialized
DEBUG - 2024-09-17 12:42:30 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/set_mapel/views/form.php
DEBUG - 2024-09-17 12:42:30 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-09-17 12:42:30 --> Final output sent to browser
DEBUG - 2024-09-17 12:42:30 --> Total execution time: 0.0354
INFO - 2024-09-17 12:42:39 --> Config Class Initialized
INFO - 2024-09-17 12:42:39 --> Hooks Class Initialized
DEBUG - 2024-09-17 12:42:39 --> UTF-8 Support Enabled
INFO - 2024-09-17 12:42:39 --> Utf8 Class Initialized
INFO - 2024-09-17 12:42:39 --> URI Class Initialized
INFO - 2024-09-17 12:42:39 --> Router Class Initialized
INFO - 2024-09-17 12:42:39 --> Output Class Initialized
INFO - 2024-09-17 12:42:39 --> Security Class Initialized
DEBUG - 2024-09-17 12:42:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-17 12:42:39 --> Input Class Initialized
INFO - 2024-09-17 12:42:39 --> Language Class Initialized
INFO - 2024-09-17 12:42:39 --> Language Class Initialized
INFO - 2024-09-17 12:42:39 --> Config Class Initialized
INFO - 2024-09-17 12:42:39 --> Loader Class Initialized
INFO - 2024-09-17 12:42:39 --> Helper loaded: url_helper
INFO - 2024-09-17 12:42:39 --> Helper loaded: file_helper
INFO - 2024-09-17 12:42:39 --> Helper loaded: form_helper
INFO - 2024-09-17 12:42:39 --> Helper loaded: my_helper
INFO - 2024-09-17 12:42:39 --> Database Driver Class Initialized
INFO - 2024-09-17 12:42:39 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-17 12:42:39 --> Controller Class Initialized
INFO - 2024-09-17 12:42:40 --> Config Class Initialized
INFO - 2024-09-17 12:42:40 --> Hooks Class Initialized
DEBUG - 2024-09-17 12:42:40 --> UTF-8 Support Enabled
INFO - 2024-09-17 12:42:40 --> Utf8 Class Initialized
INFO - 2024-09-17 12:42:40 --> URI Class Initialized
INFO - 2024-09-17 12:42:40 --> Router Class Initialized
INFO - 2024-09-17 12:42:40 --> Output Class Initialized
INFO - 2024-09-17 12:42:40 --> Security Class Initialized
DEBUG - 2024-09-17 12:42:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-17 12:42:40 --> Input Class Initialized
INFO - 2024-09-17 12:42:40 --> Language Class Initialized
INFO - 2024-09-17 12:42:40 --> Language Class Initialized
INFO - 2024-09-17 12:42:40 --> Config Class Initialized
INFO - 2024-09-17 12:42:40 --> Loader Class Initialized
INFO - 2024-09-17 12:42:40 --> Helper loaded: url_helper
INFO - 2024-09-17 12:42:40 --> Helper loaded: file_helper
INFO - 2024-09-17 12:42:40 --> Helper loaded: form_helper
INFO - 2024-09-17 12:42:40 --> Helper loaded: my_helper
INFO - 2024-09-17 12:42:40 --> Database Driver Class Initialized
INFO - 2024-09-17 12:42:40 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-17 12:42:40 --> Controller Class Initialized
DEBUG - 2024-09-17 12:42:40 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/set_mapel/views/list.php
DEBUG - 2024-09-17 12:42:40 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-09-17 12:42:40 --> Final output sent to browser
DEBUG - 2024-09-17 12:42:40 --> Total execution time: 0.0345
INFO - 2024-09-17 12:42:40 --> Config Class Initialized
INFO - 2024-09-17 12:42:40 --> Hooks Class Initialized
DEBUG - 2024-09-17 12:42:40 --> UTF-8 Support Enabled
INFO - 2024-09-17 12:42:40 --> Utf8 Class Initialized
INFO - 2024-09-17 12:42:40 --> URI Class Initialized
INFO - 2024-09-17 12:42:40 --> Router Class Initialized
INFO - 2024-09-17 12:42:40 --> Output Class Initialized
INFO - 2024-09-17 12:42:40 --> Security Class Initialized
DEBUG - 2024-09-17 12:42:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-17 12:42:40 --> Input Class Initialized
INFO - 2024-09-17 12:42:40 --> Language Class Initialized
ERROR - 2024-09-17 12:42:40 --> 404 Page Not Found: /index
INFO - 2024-09-17 12:42:40 --> Config Class Initialized
INFO - 2024-09-17 12:42:40 --> Hooks Class Initialized
DEBUG - 2024-09-17 12:42:40 --> UTF-8 Support Enabled
INFO - 2024-09-17 12:42:40 --> Utf8 Class Initialized
INFO - 2024-09-17 12:42:40 --> URI Class Initialized
INFO - 2024-09-17 12:42:40 --> Router Class Initialized
INFO - 2024-09-17 12:42:40 --> Output Class Initialized
INFO - 2024-09-17 12:42:40 --> Security Class Initialized
DEBUG - 2024-09-17 12:42:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-17 12:42:40 --> Input Class Initialized
INFO - 2024-09-17 12:42:40 --> Language Class Initialized
INFO - 2024-09-17 12:42:40 --> Language Class Initialized
INFO - 2024-09-17 12:42:40 --> Config Class Initialized
INFO - 2024-09-17 12:42:40 --> Loader Class Initialized
INFO - 2024-09-17 12:42:40 --> Helper loaded: url_helper
INFO - 2024-09-17 12:42:40 --> Helper loaded: file_helper
INFO - 2024-09-17 12:42:40 --> Helper loaded: form_helper
INFO - 2024-09-17 12:42:40 --> Helper loaded: my_helper
INFO - 2024-09-17 12:42:40 --> Database Driver Class Initialized
INFO - 2024-09-17 12:42:40 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-17 12:42:40 --> Controller Class Initialized
INFO - 2024-09-17 12:42:41 --> Config Class Initialized
INFO - 2024-09-17 12:42:41 --> Hooks Class Initialized
DEBUG - 2024-09-17 12:42:41 --> UTF-8 Support Enabled
INFO - 2024-09-17 12:42:41 --> Utf8 Class Initialized
INFO - 2024-09-17 12:42:41 --> URI Class Initialized
INFO - 2024-09-17 12:42:41 --> Router Class Initialized
INFO - 2024-09-17 12:42:41 --> Output Class Initialized
INFO - 2024-09-17 12:42:41 --> Security Class Initialized
DEBUG - 2024-09-17 12:42:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-17 12:42:41 --> Input Class Initialized
INFO - 2024-09-17 12:42:41 --> Language Class Initialized
INFO - 2024-09-17 12:42:41 --> Language Class Initialized
INFO - 2024-09-17 12:42:41 --> Config Class Initialized
INFO - 2024-09-17 12:42:41 --> Loader Class Initialized
INFO - 2024-09-17 12:42:41 --> Helper loaded: url_helper
INFO - 2024-09-17 12:42:41 --> Helper loaded: file_helper
INFO - 2024-09-17 12:42:41 --> Helper loaded: form_helper
INFO - 2024-09-17 12:42:41 --> Helper loaded: my_helper
INFO - 2024-09-17 12:42:42 --> Database Driver Class Initialized
INFO - 2024-09-17 12:42:42 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-17 12:42:42 --> Controller Class Initialized
DEBUG - 2024-09-17 12:42:42 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/set_mapel/views/form.php
DEBUG - 2024-09-17 12:42:42 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-09-17 12:42:42 --> Final output sent to browser
DEBUG - 2024-09-17 12:42:42 --> Total execution time: 0.0336
INFO - 2024-09-17 12:42:53 --> Config Class Initialized
INFO - 2024-09-17 12:42:53 --> Hooks Class Initialized
DEBUG - 2024-09-17 12:42:53 --> UTF-8 Support Enabled
INFO - 2024-09-17 12:42:53 --> Utf8 Class Initialized
INFO - 2024-09-17 12:42:53 --> URI Class Initialized
INFO - 2024-09-17 12:42:53 --> Router Class Initialized
INFO - 2024-09-17 12:42:53 --> Output Class Initialized
INFO - 2024-09-17 12:42:53 --> Security Class Initialized
DEBUG - 2024-09-17 12:42:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-17 12:42:53 --> Input Class Initialized
INFO - 2024-09-17 12:42:53 --> Language Class Initialized
INFO - 2024-09-17 12:42:53 --> Language Class Initialized
INFO - 2024-09-17 12:42:53 --> Config Class Initialized
INFO - 2024-09-17 12:42:53 --> Loader Class Initialized
INFO - 2024-09-17 12:42:53 --> Helper loaded: url_helper
INFO - 2024-09-17 12:42:53 --> Helper loaded: file_helper
INFO - 2024-09-17 12:42:53 --> Helper loaded: form_helper
INFO - 2024-09-17 12:42:53 --> Helper loaded: my_helper
INFO - 2024-09-17 12:42:53 --> Database Driver Class Initialized
INFO - 2024-09-17 12:42:53 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-17 12:42:53 --> Controller Class Initialized
INFO - 2024-09-17 12:42:53 --> Config Class Initialized
INFO - 2024-09-17 12:42:53 --> Hooks Class Initialized
DEBUG - 2024-09-17 12:42:53 --> UTF-8 Support Enabled
INFO - 2024-09-17 12:42:53 --> Utf8 Class Initialized
INFO - 2024-09-17 12:42:53 --> URI Class Initialized
INFO - 2024-09-17 12:42:53 --> Router Class Initialized
INFO - 2024-09-17 12:42:53 --> Output Class Initialized
INFO - 2024-09-17 12:42:53 --> Security Class Initialized
DEBUG - 2024-09-17 12:42:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-17 12:42:53 --> Input Class Initialized
INFO - 2024-09-17 12:42:53 --> Language Class Initialized
INFO - 2024-09-17 12:42:53 --> Language Class Initialized
INFO - 2024-09-17 12:42:53 --> Config Class Initialized
INFO - 2024-09-17 12:42:53 --> Loader Class Initialized
INFO - 2024-09-17 12:42:53 --> Helper loaded: url_helper
INFO - 2024-09-17 12:42:53 --> Helper loaded: file_helper
INFO - 2024-09-17 12:42:53 --> Helper loaded: form_helper
INFO - 2024-09-17 12:42:53 --> Helper loaded: my_helper
INFO - 2024-09-17 12:42:53 --> Database Driver Class Initialized
INFO - 2024-09-17 12:42:53 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-17 12:42:53 --> Controller Class Initialized
DEBUG - 2024-09-17 12:42:54 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/set_mapel/views/list.php
DEBUG - 2024-09-17 12:42:54 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-09-17 12:42:54 --> Final output sent to browser
DEBUG - 2024-09-17 12:42:54 --> Total execution time: 0.0282
INFO - 2024-09-17 12:42:54 --> Config Class Initialized
INFO - 2024-09-17 12:42:54 --> Hooks Class Initialized
DEBUG - 2024-09-17 12:42:54 --> UTF-8 Support Enabled
INFO - 2024-09-17 12:42:54 --> Utf8 Class Initialized
INFO - 2024-09-17 12:42:54 --> URI Class Initialized
INFO - 2024-09-17 12:42:54 --> Router Class Initialized
INFO - 2024-09-17 12:42:54 --> Output Class Initialized
INFO - 2024-09-17 12:42:54 --> Security Class Initialized
DEBUG - 2024-09-17 12:42:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-17 12:42:54 --> Input Class Initialized
INFO - 2024-09-17 12:42:54 --> Language Class Initialized
ERROR - 2024-09-17 12:42:54 --> 404 Page Not Found: /index
INFO - 2024-09-17 12:42:54 --> Config Class Initialized
INFO - 2024-09-17 12:42:54 --> Hooks Class Initialized
DEBUG - 2024-09-17 12:42:54 --> UTF-8 Support Enabled
INFO - 2024-09-17 12:42:54 --> Utf8 Class Initialized
INFO - 2024-09-17 12:42:54 --> URI Class Initialized
INFO - 2024-09-17 12:42:54 --> Router Class Initialized
INFO - 2024-09-17 12:42:54 --> Output Class Initialized
INFO - 2024-09-17 12:42:54 --> Security Class Initialized
DEBUG - 2024-09-17 12:42:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-17 12:42:54 --> Input Class Initialized
INFO - 2024-09-17 12:42:54 --> Language Class Initialized
INFO - 2024-09-17 12:42:54 --> Language Class Initialized
INFO - 2024-09-17 12:42:54 --> Config Class Initialized
INFO - 2024-09-17 12:42:54 --> Loader Class Initialized
INFO - 2024-09-17 12:42:54 --> Helper loaded: url_helper
INFO - 2024-09-17 12:42:54 --> Helper loaded: file_helper
INFO - 2024-09-17 12:42:54 --> Helper loaded: form_helper
INFO - 2024-09-17 12:42:54 --> Helper loaded: my_helper
INFO - 2024-09-17 12:42:54 --> Database Driver Class Initialized
INFO - 2024-09-17 12:42:54 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-17 12:42:54 --> Controller Class Initialized
INFO - 2024-09-17 12:42:56 --> Config Class Initialized
INFO - 2024-09-17 12:42:56 --> Hooks Class Initialized
DEBUG - 2024-09-17 12:42:56 --> UTF-8 Support Enabled
INFO - 2024-09-17 12:42:56 --> Utf8 Class Initialized
INFO - 2024-09-17 12:42:56 --> URI Class Initialized
INFO - 2024-09-17 12:42:56 --> Router Class Initialized
INFO - 2024-09-17 12:42:56 --> Output Class Initialized
INFO - 2024-09-17 12:42:56 --> Security Class Initialized
DEBUG - 2024-09-17 12:42:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-17 12:42:56 --> Input Class Initialized
INFO - 2024-09-17 12:42:56 --> Language Class Initialized
INFO - 2024-09-17 12:42:56 --> Language Class Initialized
INFO - 2024-09-17 12:42:56 --> Config Class Initialized
INFO - 2024-09-17 12:42:56 --> Loader Class Initialized
INFO - 2024-09-17 12:42:56 --> Helper loaded: url_helper
INFO - 2024-09-17 12:42:56 --> Helper loaded: file_helper
INFO - 2024-09-17 12:42:56 --> Helper loaded: form_helper
INFO - 2024-09-17 12:42:56 --> Helper loaded: my_helper
INFO - 2024-09-17 12:42:56 --> Database Driver Class Initialized
INFO - 2024-09-17 12:42:56 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-17 12:42:56 --> Controller Class Initialized
DEBUG - 2024-09-17 12:42:56 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/set_mapel/views/form.php
DEBUG - 2024-09-17 12:42:56 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-09-17 12:42:56 --> Final output sent to browser
DEBUG - 2024-09-17 12:42:56 --> Total execution time: 0.0247
INFO - 2024-09-17 12:43:12 --> Config Class Initialized
INFO - 2024-09-17 12:43:12 --> Hooks Class Initialized
DEBUG - 2024-09-17 12:43:12 --> UTF-8 Support Enabled
INFO - 2024-09-17 12:43:12 --> Utf8 Class Initialized
INFO - 2024-09-17 12:43:12 --> URI Class Initialized
INFO - 2024-09-17 12:43:12 --> Router Class Initialized
INFO - 2024-09-17 12:43:12 --> Output Class Initialized
INFO - 2024-09-17 12:43:12 --> Security Class Initialized
DEBUG - 2024-09-17 12:43:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-17 12:43:12 --> Input Class Initialized
INFO - 2024-09-17 12:43:12 --> Language Class Initialized
INFO - 2024-09-17 12:43:12 --> Language Class Initialized
INFO - 2024-09-17 12:43:12 --> Config Class Initialized
INFO - 2024-09-17 12:43:12 --> Loader Class Initialized
INFO - 2024-09-17 12:43:12 --> Helper loaded: url_helper
INFO - 2024-09-17 12:43:12 --> Helper loaded: file_helper
INFO - 2024-09-17 12:43:12 --> Helper loaded: form_helper
INFO - 2024-09-17 12:43:12 --> Helper loaded: my_helper
INFO - 2024-09-17 12:43:12 --> Database Driver Class Initialized
INFO - 2024-09-17 12:43:12 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-17 12:43:12 --> Controller Class Initialized
INFO - 2024-09-17 12:43:13 --> Config Class Initialized
INFO - 2024-09-17 12:43:13 --> Hooks Class Initialized
DEBUG - 2024-09-17 12:43:13 --> UTF-8 Support Enabled
INFO - 2024-09-17 12:43:13 --> Utf8 Class Initialized
INFO - 2024-09-17 12:43:13 --> URI Class Initialized
INFO - 2024-09-17 12:43:13 --> Router Class Initialized
INFO - 2024-09-17 12:43:13 --> Output Class Initialized
INFO - 2024-09-17 12:43:13 --> Security Class Initialized
DEBUG - 2024-09-17 12:43:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-17 12:43:13 --> Input Class Initialized
INFO - 2024-09-17 12:43:13 --> Language Class Initialized
INFO - 2024-09-17 12:43:13 --> Language Class Initialized
INFO - 2024-09-17 12:43:13 --> Config Class Initialized
INFO - 2024-09-17 12:43:13 --> Loader Class Initialized
INFO - 2024-09-17 12:43:13 --> Helper loaded: url_helper
INFO - 2024-09-17 12:43:13 --> Helper loaded: file_helper
INFO - 2024-09-17 12:43:13 --> Helper loaded: form_helper
INFO - 2024-09-17 12:43:13 --> Helper loaded: my_helper
INFO - 2024-09-17 12:43:13 --> Database Driver Class Initialized
INFO - 2024-09-17 12:43:13 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-17 12:43:13 --> Controller Class Initialized
DEBUG - 2024-09-17 12:43:13 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/set_mapel/views/list.php
DEBUG - 2024-09-17 12:43:13 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-09-17 12:43:13 --> Final output sent to browser
DEBUG - 2024-09-17 12:43:13 --> Total execution time: 0.0295
INFO - 2024-09-17 12:43:13 --> Config Class Initialized
INFO - 2024-09-17 12:43:13 --> Hooks Class Initialized
DEBUG - 2024-09-17 12:43:13 --> UTF-8 Support Enabled
INFO - 2024-09-17 12:43:13 --> Utf8 Class Initialized
INFO - 2024-09-17 12:43:13 --> URI Class Initialized
INFO - 2024-09-17 12:43:13 --> Router Class Initialized
INFO - 2024-09-17 12:43:13 --> Output Class Initialized
INFO - 2024-09-17 12:43:13 --> Security Class Initialized
DEBUG - 2024-09-17 12:43:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-17 12:43:13 --> Input Class Initialized
INFO - 2024-09-17 12:43:13 --> Language Class Initialized
ERROR - 2024-09-17 12:43:13 --> 404 Page Not Found: /index
INFO - 2024-09-17 12:43:13 --> Config Class Initialized
INFO - 2024-09-17 12:43:13 --> Hooks Class Initialized
DEBUG - 2024-09-17 12:43:13 --> UTF-8 Support Enabled
INFO - 2024-09-17 12:43:13 --> Utf8 Class Initialized
INFO - 2024-09-17 12:43:13 --> URI Class Initialized
INFO - 2024-09-17 12:43:13 --> Router Class Initialized
INFO - 2024-09-17 12:43:13 --> Output Class Initialized
INFO - 2024-09-17 12:43:13 --> Security Class Initialized
DEBUG - 2024-09-17 12:43:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-17 12:43:13 --> Input Class Initialized
INFO - 2024-09-17 12:43:13 --> Language Class Initialized
INFO - 2024-09-17 12:43:13 --> Language Class Initialized
INFO - 2024-09-17 12:43:13 --> Config Class Initialized
INFO - 2024-09-17 12:43:13 --> Loader Class Initialized
INFO - 2024-09-17 12:43:13 --> Helper loaded: url_helper
INFO - 2024-09-17 12:43:13 --> Helper loaded: file_helper
INFO - 2024-09-17 12:43:13 --> Helper loaded: form_helper
INFO - 2024-09-17 12:43:13 --> Helper loaded: my_helper
INFO - 2024-09-17 12:43:13 --> Database Driver Class Initialized
INFO - 2024-09-17 12:43:13 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-17 12:43:13 --> Controller Class Initialized
INFO - 2024-09-17 12:43:15 --> Config Class Initialized
INFO - 2024-09-17 12:43:15 --> Hooks Class Initialized
DEBUG - 2024-09-17 12:43:15 --> UTF-8 Support Enabled
INFO - 2024-09-17 12:43:15 --> Utf8 Class Initialized
INFO - 2024-09-17 12:43:15 --> URI Class Initialized
INFO - 2024-09-17 12:43:15 --> Router Class Initialized
INFO - 2024-09-17 12:43:15 --> Output Class Initialized
INFO - 2024-09-17 12:43:15 --> Security Class Initialized
DEBUG - 2024-09-17 12:43:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-17 12:43:15 --> Input Class Initialized
INFO - 2024-09-17 12:43:15 --> Language Class Initialized
INFO - 2024-09-17 12:43:15 --> Language Class Initialized
INFO - 2024-09-17 12:43:15 --> Config Class Initialized
INFO - 2024-09-17 12:43:15 --> Loader Class Initialized
INFO - 2024-09-17 12:43:15 --> Helper loaded: url_helper
INFO - 2024-09-17 12:43:15 --> Helper loaded: file_helper
INFO - 2024-09-17 12:43:15 --> Helper loaded: form_helper
INFO - 2024-09-17 12:43:15 --> Helper loaded: my_helper
INFO - 2024-09-17 12:43:15 --> Database Driver Class Initialized
INFO - 2024-09-17 12:43:15 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-17 12:43:15 --> Controller Class Initialized
DEBUG - 2024-09-17 12:43:15 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/set_mapel/views/form.php
DEBUG - 2024-09-17 12:43:15 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-09-17 12:43:15 --> Final output sent to browser
DEBUG - 2024-09-17 12:43:15 --> Total execution time: 0.0505
INFO - 2024-09-17 12:43:31 --> Config Class Initialized
INFO - 2024-09-17 12:43:31 --> Hooks Class Initialized
DEBUG - 2024-09-17 12:43:31 --> UTF-8 Support Enabled
INFO - 2024-09-17 12:43:31 --> Utf8 Class Initialized
INFO - 2024-09-17 12:43:31 --> URI Class Initialized
INFO - 2024-09-17 12:43:31 --> Router Class Initialized
INFO - 2024-09-17 12:43:31 --> Output Class Initialized
INFO - 2024-09-17 12:43:31 --> Security Class Initialized
DEBUG - 2024-09-17 12:43:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-17 12:43:32 --> Input Class Initialized
INFO - 2024-09-17 12:43:32 --> Language Class Initialized
INFO - 2024-09-17 12:43:32 --> Language Class Initialized
INFO - 2024-09-17 12:43:32 --> Config Class Initialized
INFO - 2024-09-17 12:43:32 --> Loader Class Initialized
INFO - 2024-09-17 12:43:32 --> Helper loaded: url_helper
INFO - 2024-09-17 12:43:32 --> Helper loaded: file_helper
INFO - 2024-09-17 12:43:32 --> Helper loaded: form_helper
INFO - 2024-09-17 12:43:32 --> Helper loaded: my_helper
INFO - 2024-09-17 12:43:32 --> Database Driver Class Initialized
INFO - 2024-09-17 12:43:32 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-17 12:43:32 --> Controller Class Initialized
INFO - 2024-09-17 12:43:32 --> Config Class Initialized
INFO - 2024-09-17 12:43:32 --> Hooks Class Initialized
DEBUG - 2024-09-17 12:43:32 --> UTF-8 Support Enabled
INFO - 2024-09-17 12:43:32 --> Utf8 Class Initialized
INFO - 2024-09-17 12:43:32 --> URI Class Initialized
INFO - 2024-09-17 12:43:32 --> Router Class Initialized
INFO - 2024-09-17 12:43:32 --> Output Class Initialized
INFO - 2024-09-17 12:43:32 --> Security Class Initialized
DEBUG - 2024-09-17 12:43:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-17 12:43:32 --> Input Class Initialized
INFO - 2024-09-17 12:43:32 --> Language Class Initialized
INFO - 2024-09-17 12:43:32 --> Language Class Initialized
INFO - 2024-09-17 12:43:32 --> Config Class Initialized
INFO - 2024-09-17 12:43:32 --> Loader Class Initialized
INFO - 2024-09-17 12:43:32 --> Helper loaded: url_helper
INFO - 2024-09-17 12:43:32 --> Helper loaded: file_helper
INFO - 2024-09-17 12:43:32 --> Helper loaded: form_helper
INFO - 2024-09-17 12:43:32 --> Helper loaded: my_helper
INFO - 2024-09-17 12:43:32 --> Database Driver Class Initialized
INFO - 2024-09-17 12:43:32 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-17 12:43:32 --> Controller Class Initialized
DEBUG - 2024-09-17 12:43:32 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/set_mapel/views/list.php
DEBUG - 2024-09-17 12:43:32 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-09-17 12:43:32 --> Final output sent to browser
DEBUG - 2024-09-17 12:43:32 --> Total execution time: 0.0273
INFO - 2024-09-17 12:43:32 --> Config Class Initialized
INFO - 2024-09-17 12:43:32 --> Hooks Class Initialized
DEBUG - 2024-09-17 12:43:32 --> UTF-8 Support Enabled
INFO - 2024-09-17 12:43:32 --> Utf8 Class Initialized
INFO - 2024-09-17 12:43:32 --> URI Class Initialized
INFO - 2024-09-17 12:43:32 --> Router Class Initialized
INFO - 2024-09-17 12:43:32 --> Output Class Initialized
INFO - 2024-09-17 12:43:32 --> Security Class Initialized
DEBUG - 2024-09-17 12:43:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-17 12:43:32 --> Input Class Initialized
INFO - 2024-09-17 12:43:32 --> Language Class Initialized
ERROR - 2024-09-17 12:43:32 --> 404 Page Not Found: /index
INFO - 2024-09-17 12:43:32 --> Config Class Initialized
INFO - 2024-09-17 12:43:32 --> Hooks Class Initialized
DEBUG - 2024-09-17 12:43:32 --> UTF-8 Support Enabled
INFO - 2024-09-17 12:43:32 --> Utf8 Class Initialized
INFO - 2024-09-17 12:43:32 --> URI Class Initialized
INFO - 2024-09-17 12:43:32 --> Router Class Initialized
INFO - 2024-09-17 12:43:32 --> Output Class Initialized
INFO - 2024-09-17 12:43:32 --> Security Class Initialized
DEBUG - 2024-09-17 12:43:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-17 12:43:32 --> Input Class Initialized
INFO - 2024-09-17 12:43:32 --> Language Class Initialized
INFO - 2024-09-17 12:43:32 --> Language Class Initialized
INFO - 2024-09-17 12:43:32 --> Config Class Initialized
INFO - 2024-09-17 12:43:32 --> Loader Class Initialized
INFO - 2024-09-17 12:43:32 --> Helper loaded: url_helper
INFO - 2024-09-17 12:43:32 --> Helper loaded: file_helper
INFO - 2024-09-17 12:43:32 --> Helper loaded: form_helper
INFO - 2024-09-17 12:43:32 --> Helper loaded: my_helper
INFO - 2024-09-17 12:43:32 --> Database Driver Class Initialized
INFO - 2024-09-17 12:43:32 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-17 12:43:32 --> Controller Class Initialized
INFO - 2024-09-17 12:43:33 --> Config Class Initialized
INFO - 2024-09-17 12:43:33 --> Hooks Class Initialized
DEBUG - 2024-09-17 12:43:33 --> UTF-8 Support Enabled
INFO - 2024-09-17 12:43:33 --> Utf8 Class Initialized
INFO - 2024-09-17 12:43:33 --> URI Class Initialized
INFO - 2024-09-17 12:43:33 --> Router Class Initialized
INFO - 2024-09-17 12:43:33 --> Output Class Initialized
INFO - 2024-09-17 12:43:33 --> Security Class Initialized
DEBUG - 2024-09-17 12:43:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-17 12:43:33 --> Input Class Initialized
INFO - 2024-09-17 12:43:33 --> Language Class Initialized
INFO - 2024-09-17 12:43:33 --> Language Class Initialized
INFO - 2024-09-17 12:43:33 --> Config Class Initialized
INFO - 2024-09-17 12:43:33 --> Loader Class Initialized
INFO - 2024-09-17 12:43:33 --> Helper loaded: url_helper
INFO - 2024-09-17 12:43:33 --> Helper loaded: file_helper
INFO - 2024-09-17 12:43:33 --> Helper loaded: form_helper
INFO - 2024-09-17 12:43:33 --> Helper loaded: my_helper
INFO - 2024-09-17 12:43:33 --> Database Driver Class Initialized
INFO - 2024-09-17 12:43:33 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-17 12:43:33 --> Controller Class Initialized
DEBUG - 2024-09-17 12:43:33 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/set_mapel/views/form.php
DEBUG - 2024-09-17 12:43:33 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-09-17 12:43:33 --> Final output sent to browser
DEBUG - 2024-09-17 12:43:33 --> Total execution time: 0.0280
INFO - 2024-09-17 12:43:49 --> Config Class Initialized
INFO - 2024-09-17 12:43:49 --> Hooks Class Initialized
DEBUG - 2024-09-17 12:43:49 --> UTF-8 Support Enabled
INFO - 2024-09-17 12:43:49 --> Utf8 Class Initialized
INFO - 2024-09-17 12:43:49 --> URI Class Initialized
INFO - 2024-09-17 12:43:49 --> Router Class Initialized
INFO - 2024-09-17 12:43:49 --> Output Class Initialized
INFO - 2024-09-17 12:43:49 --> Security Class Initialized
DEBUG - 2024-09-17 12:43:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-17 12:43:49 --> Input Class Initialized
INFO - 2024-09-17 12:43:49 --> Language Class Initialized
INFO - 2024-09-17 12:43:49 --> Language Class Initialized
INFO - 2024-09-17 12:43:49 --> Config Class Initialized
INFO - 2024-09-17 12:43:49 --> Loader Class Initialized
INFO - 2024-09-17 12:43:49 --> Helper loaded: url_helper
INFO - 2024-09-17 12:43:49 --> Helper loaded: file_helper
INFO - 2024-09-17 12:43:49 --> Helper loaded: form_helper
INFO - 2024-09-17 12:43:49 --> Helper loaded: my_helper
INFO - 2024-09-17 12:43:49 --> Database Driver Class Initialized
INFO - 2024-09-17 12:43:49 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-17 12:43:49 --> Controller Class Initialized
INFO - 2024-09-17 12:43:49 --> Config Class Initialized
INFO - 2024-09-17 12:43:49 --> Hooks Class Initialized
DEBUG - 2024-09-17 12:43:49 --> UTF-8 Support Enabled
INFO - 2024-09-17 12:43:49 --> Utf8 Class Initialized
INFO - 2024-09-17 12:43:49 --> URI Class Initialized
INFO - 2024-09-17 12:43:49 --> Router Class Initialized
INFO - 2024-09-17 12:43:49 --> Output Class Initialized
INFO - 2024-09-17 12:43:49 --> Security Class Initialized
DEBUG - 2024-09-17 12:43:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-17 12:43:49 --> Input Class Initialized
INFO - 2024-09-17 12:43:49 --> Language Class Initialized
INFO - 2024-09-17 12:43:49 --> Language Class Initialized
INFO - 2024-09-17 12:43:49 --> Config Class Initialized
INFO - 2024-09-17 12:43:49 --> Loader Class Initialized
INFO - 2024-09-17 12:43:49 --> Helper loaded: url_helper
INFO - 2024-09-17 12:43:49 --> Helper loaded: file_helper
INFO - 2024-09-17 12:43:49 --> Helper loaded: form_helper
INFO - 2024-09-17 12:43:49 --> Helper loaded: my_helper
INFO - 2024-09-17 12:43:49 --> Database Driver Class Initialized
INFO - 2024-09-17 12:43:49 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-17 12:43:49 --> Controller Class Initialized
DEBUG - 2024-09-17 12:43:49 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/set_mapel/views/list.php
DEBUG - 2024-09-17 12:43:49 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-09-17 12:43:49 --> Final output sent to browser
DEBUG - 2024-09-17 12:43:49 --> Total execution time: 0.0282
INFO - 2024-09-17 12:43:49 --> Config Class Initialized
INFO - 2024-09-17 12:43:49 --> Hooks Class Initialized
DEBUG - 2024-09-17 12:43:49 --> UTF-8 Support Enabled
INFO - 2024-09-17 12:43:49 --> Utf8 Class Initialized
INFO - 2024-09-17 12:43:49 --> URI Class Initialized
INFO - 2024-09-17 12:43:49 --> Router Class Initialized
INFO - 2024-09-17 12:43:49 --> Output Class Initialized
INFO - 2024-09-17 12:43:49 --> Security Class Initialized
DEBUG - 2024-09-17 12:43:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-17 12:43:49 --> Input Class Initialized
INFO - 2024-09-17 12:43:49 --> Language Class Initialized
ERROR - 2024-09-17 12:43:49 --> 404 Page Not Found: /index
INFO - 2024-09-17 12:43:49 --> Config Class Initialized
INFO - 2024-09-17 12:43:49 --> Hooks Class Initialized
DEBUG - 2024-09-17 12:43:49 --> UTF-8 Support Enabled
INFO - 2024-09-17 12:43:49 --> Utf8 Class Initialized
INFO - 2024-09-17 12:43:49 --> URI Class Initialized
INFO - 2024-09-17 12:43:49 --> Router Class Initialized
INFO - 2024-09-17 12:43:49 --> Output Class Initialized
INFO - 2024-09-17 12:43:49 --> Security Class Initialized
DEBUG - 2024-09-17 12:43:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-17 12:43:49 --> Input Class Initialized
INFO - 2024-09-17 12:43:49 --> Language Class Initialized
INFO - 2024-09-17 12:43:49 --> Language Class Initialized
INFO - 2024-09-17 12:43:49 --> Config Class Initialized
INFO - 2024-09-17 12:43:49 --> Loader Class Initialized
INFO - 2024-09-17 12:43:49 --> Helper loaded: url_helper
INFO - 2024-09-17 12:43:49 --> Helper loaded: file_helper
INFO - 2024-09-17 12:43:49 --> Helper loaded: form_helper
INFO - 2024-09-17 12:43:49 --> Helper loaded: my_helper
INFO - 2024-09-17 12:43:49 --> Database Driver Class Initialized
INFO - 2024-09-17 12:43:49 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-17 12:43:49 --> Controller Class Initialized
INFO - 2024-09-17 12:43:50 --> Config Class Initialized
INFO - 2024-09-17 12:43:50 --> Hooks Class Initialized
DEBUG - 2024-09-17 12:43:50 --> UTF-8 Support Enabled
INFO - 2024-09-17 12:43:50 --> Utf8 Class Initialized
INFO - 2024-09-17 12:43:50 --> URI Class Initialized
INFO - 2024-09-17 12:43:50 --> Router Class Initialized
INFO - 2024-09-17 12:43:50 --> Output Class Initialized
INFO - 2024-09-17 12:43:50 --> Security Class Initialized
DEBUG - 2024-09-17 12:43:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-17 12:43:50 --> Input Class Initialized
INFO - 2024-09-17 12:43:50 --> Language Class Initialized
INFO - 2024-09-17 12:43:50 --> Language Class Initialized
INFO - 2024-09-17 12:43:50 --> Config Class Initialized
INFO - 2024-09-17 12:43:50 --> Loader Class Initialized
INFO - 2024-09-17 12:43:50 --> Helper loaded: url_helper
INFO - 2024-09-17 12:43:50 --> Helper loaded: file_helper
INFO - 2024-09-17 12:43:50 --> Helper loaded: form_helper
INFO - 2024-09-17 12:43:50 --> Helper loaded: my_helper
INFO - 2024-09-17 12:43:51 --> Database Driver Class Initialized
INFO - 2024-09-17 12:43:51 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-17 12:43:51 --> Controller Class Initialized
DEBUG - 2024-09-17 12:43:51 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/set_mapel/views/form.php
DEBUG - 2024-09-17 12:43:51 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-09-17 12:43:51 --> Final output sent to browser
DEBUG - 2024-09-17 12:43:51 --> Total execution time: 0.0289
INFO - 2024-09-17 12:44:05 --> Config Class Initialized
INFO - 2024-09-17 12:44:05 --> Hooks Class Initialized
DEBUG - 2024-09-17 12:44:05 --> UTF-8 Support Enabled
INFO - 2024-09-17 12:44:05 --> Utf8 Class Initialized
INFO - 2024-09-17 12:44:05 --> URI Class Initialized
INFO - 2024-09-17 12:44:05 --> Router Class Initialized
INFO - 2024-09-17 12:44:05 --> Output Class Initialized
INFO - 2024-09-17 12:44:05 --> Security Class Initialized
DEBUG - 2024-09-17 12:44:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-17 12:44:05 --> Input Class Initialized
INFO - 2024-09-17 12:44:05 --> Language Class Initialized
INFO - 2024-09-17 12:44:05 --> Language Class Initialized
INFO - 2024-09-17 12:44:05 --> Config Class Initialized
INFO - 2024-09-17 12:44:05 --> Loader Class Initialized
INFO - 2024-09-17 12:44:05 --> Helper loaded: url_helper
INFO - 2024-09-17 12:44:05 --> Helper loaded: file_helper
INFO - 2024-09-17 12:44:05 --> Helper loaded: form_helper
INFO - 2024-09-17 12:44:05 --> Helper loaded: my_helper
INFO - 2024-09-17 12:44:05 --> Database Driver Class Initialized
INFO - 2024-09-17 12:44:05 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-17 12:44:05 --> Controller Class Initialized
INFO - 2024-09-17 12:44:05 --> Config Class Initialized
INFO - 2024-09-17 12:44:05 --> Hooks Class Initialized
DEBUG - 2024-09-17 12:44:05 --> UTF-8 Support Enabled
INFO - 2024-09-17 12:44:05 --> Utf8 Class Initialized
INFO - 2024-09-17 12:44:05 --> URI Class Initialized
INFO - 2024-09-17 12:44:05 --> Router Class Initialized
INFO - 2024-09-17 12:44:05 --> Output Class Initialized
INFO - 2024-09-17 12:44:05 --> Security Class Initialized
DEBUG - 2024-09-17 12:44:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-17 12:44:05 --> Input Class Initialized
INFO - 2024-09-17 12:44:05 --> Language Class Initialized
INFO - 2024-09-17 12:44:05 --> Language Class Initialized
INFO - 2024-09-17 12:44:05 --> Config Class Initialized
INFO - 2024-09-17 12:44:05 --> Loader Class Initialized
INFO - 2024-09-17 12:44:05 --> Helper loaded: url_helper
INFO - 2024-09-17 12:44:05 --> Helper loaded: file_helper
INFO - 2024-09-17 12:44:05 --> Helper loaded: form_helper
INFO - 2024-09-17 12:44:05 --> Helper loaded: my_helper
INFO - 2024-09-17 12:44:05 --> Database Driver Class Initialized
INFO - 2024-09-17 12:44:05 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-17 12:44:05 --> Controller Class Initialized
DEBUG - 2024-09-17 12:44:05 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/set_mapel/views/list.php
DEBUG - 2024-09-17 12:44:05 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-09-17 12:44:05 --> Final output sent to browser
DEBUG - 2024-09-17 12:44:05 --> Total execution time: 0.0294
INFO - 2024-09-17 12:44:05 --> Config Class Initialized
INFO - 2024-09-17 12:44:05 --> Hooks Class Initialized
DEBUG - 2024-09-17 12:44:05 --> UTF-8 Support Enabled
INFO - 2024-09-17 12:44:05 --> Utf8 Class Initialized
INFO - 2024-09-17 12:44:05 --> URI Class Initialized
INFO - 2024-09-17 12:44:05 --> Router Class Initialized
INFO - 2024-09-17 12:44:05 --> Output Class Initialized
INFO - 2024-09-17 12:44:05 --> Security Class Initialized
DEBUG - 2024-09-17 12:44:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-17 12:44:05 --> Input Class Initialized
INFO - 2024-09-17 12:44:05 --> Language Class Initialized
ERROR - 2024-09-17 12:44:05 --> 404 Page Not Found: /index
INFO - 2024-09-17 12:44:05 --> Config Class Initialized
INFO - 2024-09-17 12:44:05 --> Hooks Class Initialized
DEBUG - 2024-09-17 12:44:05 --> UTF-8 Support Enabled
INFO - 2024-09-17 12:44:05 --> Utf8 Class Initialized
INFO - 2024-09-17 12:44:05 --> URI Class Initialized
INFO - 2024-09-17 12:44:05 --> Router Class Initialized
INFO - 2024-09-17 12:44:05 --> Output Class Initialized
INFO - 2024-09-17 12:44:05 --> Security Class Initialized
DEBUG - 2024-09-17 12:44:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-17 12:44:05 --> Input Class Initialized
INFO - 2024-09-17 12:44:05 --> Language Class Initialized
INFO - 2024-09-17 12:44:05 --> Language Class Initialized
INFO - 2024-09-17 12:44:05 --> Config Class Initialized
INFO - 2024-09-17 12:44:05 --> Loader Class Initialized
INFO - 2024-09-17 12:44:05 --> Helper loaded: url_helper
INFO - 2024-09-17 12:44:05 --> Helper loaded: file_helper
INFO - 2024-09-17 12:44:05 --> Helper loaded: form_helper
INFO - 2024-09-17 12:44:05 --> Helper loaded: my_helper
INFO - 2024-09-17 12:44:05 --> Database Driver Class Initialized
INFO - 2024-09-17 12:44:05 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-17 12:44:05 --> Controller Class Initialized
INFO - 2024-09-17 12:44:07 --> Config Class Initialized
INFO - 2024-09-17 12:44:07 --> Hooks Class Initialized
DEBUG - 2024-09-17 12:44:07 --> UTF-8 Support Enabled
INFO - 2024-09-17 12:44:07 --> Utf8 Class Initialized
INFO - 2024-09-17 12:44:07 --> URI Class Initialized
INFO - 2024-09-17 12:44:07 --> Router Class Initialized
INFO - 2024-09-17 12:44:07 --> Output Class Initialized
INFO - 2024-09-17 12:44:07 --> Security Class Initialized
DEBUG - 2024-09-17 12:44:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-17 12:44:07 --> Input Class Initialized
INFO - 2024-09-17 12:44:07 --> Language Class Initialized
INFO - 2024-09-17 12:44:07 --> Language Class Initialized
INFO - 2024-09-17 12:44:07 --> Config Class Initialized
INFO - 2024-09-17 12:44:07 --> Loader Class Initialized
INFO - 2024-09-17 12:44:07 --> Helper loaded: url_helper
INFO - 2024-09-17 12:44:07 --> Helper loaded: file_helper
INFO - 2024-09-17 12:44:07 --> Helper loaded: form_helper
INFO - 2024-09-17 12:44:07 --> Helper loaded: my_helper
INFO - 2024-09-17 12:44:07 --> Database Driver Class Initialized
INFO - 2024-09-17 12:44:07 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-17 12:44:07 --> Controller Class Initialized
DEBUG - 2024-09-17 12:44:07 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/set_mapel/views/form.php
DEBUG - 2024-09-17 12:44:07 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-09-17 12:44:07 --> Final output sent to browser
DEBUG - 2024-09-17 12:44:07 --> Total execution time: 0.0532
INFO - 2024-09-17 12:45:15 --> Config Class Initialized
INFO - 2024-09-17 12:45:15 --> Hooks Class Initialized
DEBUG - 2024-09-17 12:45:15 --> UTF-8 Support Enabled
INFO - 2024-09-17 12:45:15 --> Utf8 Class Initialized
INFO - 2024-09-17 12:45:15 --> URI Class Initialized
INFO - 2024-09-17 12:45:15 --> Router Class Initialized
INFO - 2024-09-17 12:45:15 --> Output Class Initialized
INFO - 2024-09-17 12:45:15 --> Security Class Initialized
DEBUG - 2024-09-17 12:45:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-17 12:45:15 --> Input Class Initialized
INFO - 2024-09-17 12:45:15 --> Language Class Initialized
INFO - 2024-09-17 12:45:15 --> Language Class Initialized
INFO - 2024-09-17 12:45:15 --> Config Class Initialized
INFO - 2024-09-17 12:45:15 --> Loader Class Initialized
INFO - 2024-09-17 12:45:15 --> Helper loaded: url_helper
INFO - 2024-09-17 12:45:15 --> Helper loaded: file_helper
INFO - 2024-09-17 12:45:15 --> Helper loaded: form_helper
INFO - 2024-09-17 12:45:15 --> Helper loaded: my_helper
INFO - 2024-09-17 12:45:15 --> Database Driver Class Initialized
INFO - 2024-09-17 12:45:15 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-17 12:45:15 --> Controller Class Initialized
DEBUG - 2024-09-17 12:45:15 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/data_ekstra/views/list.php
DEBUG - 2024-09-17 12:45:15 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-09-17 12:45:15 --> Final output sent to browser
DEBUG - 2024-09-17 12:45:15 --> Total execution time: 0.0659
INFO - 2024-09-17 12:45:15 --> Config Class Initialized
INFO - 2024-09-17 12:45:15 --> Hooks Class Initialized
DEBUG - 2024-09-17 12:45:15 --> UTF-8 Support Enabled
INFO - 2024-09-17 12:45:15 --> Utf8 Class Initialized
INFO - 2024-09-17 12:45:15 --> URI Class Initialized
INFO - 2024-09-17 12:45:15 --> Router Class Initialized
INFO - 2024-09-17 12:45:15 --> Output Class Initialized
INFO - 2024-09-17 12:45:15 --> Security Class Initialized
DEBUG - 2024-09-17 12:45:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-17 12:45:15 --> Input Class Initialized
INFO - 2024-09-17 12:45:15 --> Language Class Initialized
ERROR - 2024-09-17 12:45:15 --> 404 Page Not Found: /index
INFO - 2024-09-17 12:45:15 --> Config Class Initialized
INFO - 2024-09-17 12:45:15 --> Hooks Class Initialized
DEBUG - 2024-09-17 12:45:15 --> UTF-8 Support Enabled
INFO - 2024-09-17 12:45:15 --> Utf8 Class Initialized
INFO - 2024-09-17 12:45:15 --> URI Class Initialized
INFO - 2024-09-17 12:45:15 --> Router Class Initialized
INFO - 2024-09-17 12:45:15 --> Output Class Initialized
INFO - 2024-09-17 12:45:15 --> Security Class Initialized
DEBUG - 2024-09-17 12:45:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-17 12:45:15 --> Input Class Initialized
INFO - 2024-09-17 12:45:15 --> Language Class Initialized
INFO - 2024-09-17 12:45:15 --> Language Class Initialized
INFO - 2024-09-17 12:45:15 --> Config Class Initialized
INFO - 2024-09-17 12:45:15 --> Loader Class Initialized
INFO - 2024-09-17 12:45:15 --> Helper loaded: url_helper
INFO - 2024-09-17 12:45:15 --> Helper loaded: file_helper
INFO - 2024-09-17 12:45:15 --> Helper loaded: form_helper
INFO - 2024-09-17 12:45:15 --> Helper loaded: my_helper
INFO - 2024-09-17 12:45:15 --> Database Driver Class Initialized
INFO - 2024-09-17 12:45:15 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-17 12:45:15 --> Controller Class Initialized
INFO - 2024-09-17 12:45:32 --> Config Class Initialized
INFO - 2024-09-17 12:45:32 --> Hooks Class Initialized
DEBUG - 2024-09-17 12:45:32 --> UTF-8 Support Enabled
INFO - 2024-09-17 12:45:32 --> Utf8 Class Initialized
INFO - 2024-09-17 12:45:32 --> URI Class Initialized
INFO - 2024-09-17 12:45:32 --> Router Class Initialized
INFO - 2024-09-17 12:45:32 --> Output Class Initialized
INFO - 2024-09-17 12:45:32 --> Security Class Initialized
DEBUG - 2024-09-17 12:45:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-17 12:45:32 --> Input Class Initialized
INFO - 2024-09-17 12:45:32 --> Language Class Initialized
INFO - 2024-09-17 12:45:32 --> Language Class Initialized
INFO - 2024-09-17 12:45:32 --> Config Class Initialized
INFO - 2024-09-17 12:45:32 --> Loader Class Initialized
INFO - 2024-09-17 12:45:32 --> Helper loaded: url_helper
INFO - 2024-09-17 12:45:32 --> Helper loaded: file_helper
INFO - 2024-09-17 12:45:32 --> Helper loaded: form_helper
INFO - 2024-09-17 12:45:32 --> Helper loaded: my_helper
INFO - 2024-09-17 12:45:32 --> Database Driver Class Initialized
INFO - 2024-09-17 12:45:32 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-17 12:45:32 --> Controller Class Initialized
INFO - 2024-09-17 12:45:32 --> Final output sent to browser
DEBUG - 2024-09-17 12:45:32 --> Total execution time: 0.0347
INFO - 2024-09-17 12:45:37 --> Config Class Initialized
INFO - 2024-09-17 12:45:37 --> Hooks Class Initialized
DEBUG - 2024-09-17 12:45:37 --> UTF-8 Support Enabled
INFO - 2024-09-17 12:45:37 --> Utf8 Class Initialized
INFO - 2024-09-17 12:45:37 --> URI Class Initialized
INFO - 2024-09-17 12:45:37 --> Router Class Initialized
INFO - 2024-09-17 12:45:37 --> Output Class Initialized
INFO - 2024-09-17 12:45:37 --> Security Class Initialized
DEBUG - 2024-09-17 12:45:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-17 12:45:37 --> Input Class Initialized
INFO - 2024-09-17 12:45:37 --> Language Class Initialized
INFO - 2024-09-17 12:45:37 --> Language Class Initialized
INFO - 2024-09-17 12:45:37 --> Config Class Initialized
INFO - 2024-09-17 12:45:37 --> Loader Class Initialized
INFO - 2024-09-17 12:45:37 --> Helper loaded: url_helper
INFO - 2024-09-17 12:45:37 --> Helper loaded: file_helper
INFO - 2024-09-17 12:45:37 --> Helper loaded: form_helper
INFO - 2024-09-17 12:45:37 --> Helper loaded: my_helper
INFO - 2024-09-17 12:45:37 --> Database Driver Class Initialized
INFO - 2024-09-17 12:45:37 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-17 12:45:37 --> Controller Class Initialized
INFO - 2024-09-17 12:45:37 --> Final output sent to browser
DEBUG - 2024-09-17 12:45:37 --> Total execution time: 0.0270
INFO - 2024-09-17 12:45:38 --> Config Class Initialized
INFO - 2024-09-17 12:45:38 --> Hooks Class Initialized
DEBUG - 2024-09-17 12:45:38 --> UTF-8 Support Enabled
INFO - 2024-09-17 12:45:38 --> Utf8 Class Initialized
INFO - 2024-09-17 12:45:38 --> URI Class Initialized
INFO - 2024-09-17 12:45:38 --> Router Class Initialized
INFO - 2024-09-17 12:45:38 --> Output Class Initialized
INFO - 2024-09-17 12:45:38 --> Security Class Initialized
DEBUG - 2024-09-17 12:45:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-17 12:45:38 --> Input Class Initialized
INFO - 2024-09-17 12:45:38 --> Language Class Initialized
ERROR - 2024-09-17 12:45:38 --> 404 Page Not Found: /index
INFO - 2024-09-17 12:45:38 --> Config Class Initialized
INFO - 2024-09-17 12:45:38 --> Hooks Class Initialized
DEBUG - 2024-09-17 12:45:38 --> UTF-8 Support Enabled
INFO - 2024-09-17 12:45:38 --> Utf8 Class Initialized
INFO - 2024-09-17 12:45:38 --> URI Class Initialized
INFO - 2024-09-17 12:45:38 --> Router Class Initialized
INFO - 2024-09-17 12:45:38 --> Output Class Initialized
INFO - 2024-09-17 12:45:38 --> Security Class Initialized
DEBUG - 2024-09-17 12:45:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-17 12:45:38 --> Input Class Initialized
INFO - 2024-09-17 12:45:38 --> Language Class Initialized
INFO - 2024-09-17 12:45:38 --> Language Class Initialized
INFO - 2024-09-17 12:45:38 --> Config Class Initialized
INFO - 2024-09-17 12:45:38 --> Loader Class Initialized
INFO - 2024-09-17 12:45:38 --> Helper loaded: url_helper
INFO - 2024-09-17 12:45:38 --> Helper loaded: file_helper
INFO - 2024-09-17 12:45:38 --> Helper loaded: form_helper
INFO - 2024-09-17 12:45:38 --> Helper loaded: my_helper
INFO - 2024-09-17 12:45:38 --> Database Driver Class Initialized
INFO - 2024-09-17 12:45:38 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-17 12:45:38 --> Controller Class Initialized
INFO - 2024-09-17 12:45:39 --> Config Class Initialized
INFO - 2024-09-17 12:45:39 --> Hooks Class Initialized
DEBUG - 2024-09-17 12:45:39 --> UTF-8 Support Enabled
INFO - 2024-09-17 12:45:39 --> Utf8 Class Initialized
INFO - 2024-09-17 12:45:39 --> URI Class Initialized
INFO - 2024-09-17 12:45:39 --> Router Class Initialized
INFO - 2024-09-17 12:45:39 --> Output Class Initialized
INFO - 2024-09-17 12:45:39 --> Security Class Initialized
DEBUG - 2024-09-17 12:45:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-17 12:45:39 --> Input Class Initialized
INFO - 2024-09-17 12:45:39 --> Language Class Initialized
INFO - 2024-09-17 12:45:39 --> Language Class Initialized
INFO - 2024-09-17 12:45:39 --> Config Class Initialized
INFO - 2024-09-17 12:45:39 --> Loader Class Initialized
INFO - 2024-09-17 12:45:39 --> Helper loaded: url_helper
INFO - 2024-09-17 12:45:39 --> Helper loaded: file_helper
INFO - 2024-09-17 12:45:39 --> Helper loaded: form_helper
INFO - 2024-09-17 12:45:39 --> Helper loaded: my_helper
INFO - 2024-09-17 12:45:39 --> Database Driver Class Initialized
INFO - 2024-09-17 12:45:39 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-17 12:45:39 --> Controller Class Initialized
INFO - 2024-09-17 12:45:39 --> Final output sent to browser
DEBUG - 2024-09-17 12:45:39 --> Total execution time: 0.0256
INFO - 2024-09-17 12:46:13 --> Config Class Initialized
INFO - 2024-09-17 12:46:13 --> Hooks Class Initialized
DEBUG - 2024-09-17 12:46:13 --> UTF-8 Support Enabled
INFO - 2024-09-17 12:46:13 --> Utf8 Class Initialized
INFO - 2024-09-17 12:46:13 --> URI Class Initialized
INFO - 2024-09-17 12:46:13 --> Router Class Initialized
INFO - 2024-09-17 12:46:13 --> Output Class Initialized
INFO - 2024-09-17 12:46:13 --> Security Class Initialized
DEBUG - 2024-09-17 12:46:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-17 12:46:13 --> Input Class Initialized
INFO - 2024-09-17 12:46:13 --> Language Class Initialized
INFO - 2024-09-17 12:46:13 --> Language Class Initialized
INFO - 2024-09-17 12:46:13 --> Config Class Initialized
INFO - 2024-09-17 12:46:13 --> Loader Class Initialized
INFO - 2024-09-17 12:46:13 --> Helper loaded: url_helper
INFO - 2024-09-17 12:46:13 --> Helper loaded: file_helper
INFO - 2024-09-17 12:46:13 --> Helper loaded: form_helper
INFO - 2024-09-17 12:46:13 --> Helper loaded: my_helper
INFO - 2024-09-17 12:46:13 --> Database Driver Class Initialized
INFO - 2024-09-17 12:46:13 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-17 12:46:13 --> Controller Class Initialized
INFO - 2024-09-17 12:46:13 --> Final output sent to browser
DEBUG - 2024-09-17 12:46:13 --> Total execution time: 0.0392
INFO - 2024-09-17 12:46:13 --> Config Class Initialized
INFO - 2024-09-17 12:46:13 --> Hooks Class Initialized
DEBUG - 2024-09-17 12:46:13 --> UTF-8 Support Enabled
INFO - 2024-09-17 12:46:13 --> Utf8 Class Initialized
INFO - 2024-09-17 12:46:13 --> URI Class Initialized
INFO - 2024-09-17 12:46:13 --> Router Class Initialized
INFO - 2024-09-17 12:46:13 --> Output Class Initialized
INFO - 2024-09-17 12:46:13 --> Security Class Initialized
DEBUG - 2024-09-17 12:46:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-17 12:46:13 --> Input Class Initialized
INFO - 2024-09-17 12:46:13 --> Language Class Initialized
ERROR - 2024-09-17 12:46:13 --> 404 Page Not Found: /index
INFO - 2024-09-17 12:46:13 --> Config Class Initialized
INFO - 2024-09-17 12:46:13 --> Hooks Class Initialized
DEBUG - 2024-09-17 12:46:13 --> UTF-8 Support Enabled
INFO - 2024-09-17 12:46:13 --> Utf8 Class Initialized
INFO - 2024-09-17 12:46:13 --> URI Class Initialized
INFO - 2024-09-17 12:46:13 --> Router Class Initialized
INFO - 2024-09-17 12:46:13 --> Output Class Initialized
INFO - 2024-09-17 12:46:13 --> Security Class Initialized
DEBUG - 2024-09-17 12:46:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-17 12:46:13 --> Input Class Initialized
INFO - 2024-09-17 12:46:13 --> Language Class Initialized
INFO - 2024-09-17 12:46:13 --> Language Class Initialized
INFO - 2024-09-17 12:46:13 --> Config Class Initialized
INFO - 2024-09-17 12:46:13 --> Loader Class Initialized
INFO - 2024-09-17 12:46:13 --> Helper loaded: url_helper
INFO - 2024-09-17 12:46:13 --> Helper loaded: file_helper
INFO - 2024-09-17 12:46:13 --> Helper loaded: form_helper
INFO - 2024-09-17 12:46:13 --> Helper loaded: my_helper
INFO - 2024-09-17 12:46:13 --> Database Driver Class Initialized
INFO - 2024-09-17 12:46:13 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-17 12:46:13 --> Controller Class Initialized
INFO - 2024-09-17 12:46:23 --> Config Class Initialized
INFO - 2024-09-17 12:46:23 --> Hooks Class Initialized
DEBUG - 2024-09-17 12:46:23 --> UTF-8 Support Enabled
INFO - 2024-09-17 12:46:23 --> Utf8 Class Initialized
INFO - 2024-09-17 12:46:23 --> URI Class Initialized
INFO - 2024-09-17 12:46:23 --> Router Class Initialized
INFO - 2024-09-17 12:46:23 --> Output Class Initialized
INFO - 2024-09-17 12:46:23 --> Security Class Initialized
DEBUG - 2024-09-17 12:46:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-17 12:46:23 --> Input Class Initialized
INFO - 2024-09-17 12:46:23 --> Language Class Initialized
INFO - 2024-09-17 12:46:23 --> Language Class Initialized
INFO - 2024-09-17 12:46:23 --> Config Class Initialized
INFO - 2024-09-17 12:46:23 --> Loader Class Initialized
INFO - 2024-09-17 12:46:23 --> Helper loaded: url_helper
INFO - 2024-09-17 12:46:23 --> Helper loaded: file_helper
INFO - 2024-09-17 12:46:23 --> Helper loaded: form_helper
INFO - 2024-09-17 12:46:23 --> Helper loaded: my_helper
INFO - 2024-09-17 12:46:23 --> Database Driver Class Initialized
INFO - 2024-09-17 12:46:23 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-17 12:46:23 --> Controller Class Initialized
INFO - 2024-09-17 12:46:23 --> Final output sent to browser
DEBUG - 2024-09-17 12:46:23 --> Total execution time: 0.0428
INFO - 2024-09-17 12:46:30 --> Config Class Initialized
INFO - 2024-09-17 12:46:30 --> Hooks Class Initialized
DEBUG - 2024-09-17 12:46:30 --> UTF-8 Support Enabled
INFO - 2024-09-17 12:46:30 --> Utf8 Class Initialized
INFO - 2024-09-17 12:46:30 --> URI Class Initialized
INFO - 2024-09-17 12:46:30 --> Router Class Initialized
INFO - 2024-09-17 12:46:30 --> Output Class Initialized
INFO - 2024-09-17 12:46:30 --> Security Class Initialized
DEBUG - 2024-09-17 12:46:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-17 12:46:30 --> Input Class Initialized
INFO - 2024-09-17 12:46:30 --> Language Class Initialized
INFO - 2024-09-17 12:46:30 --> Language Class Initialized
INFO - 2024-09-17 12:46:30 --> Config Class Initialized
INFO - 2024-09-17 12:46:30 --> Loader Class Initialized
INFO - 2024-09-17 12:46:30 --> Helper loaded: url_helper
INFO - 2024-09-17 12:46:30 --> Helper loaded: file_helper
INFO - 2024-09-17 12:46:30 --> Helper loaded: form_helper
INFO - 2024-09-17 12:46:30 --> Helper loaded: my_helper
INFO - 2024-09-17 12:46:30 --> Database Driver Class Initialized
INFO - 2024-09-17 12:46:30 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-17 12:46:30 --> Controller Class Initialized
INFO - 2024-09-17 12:46:30 --> Final output sent to browser
DEBUG - 2024-09-17 12:46:30 --> Total execution time: 0.0272
INFO - 2024-09-17 12:46:30 --> Config Class Initialized
INFO - 2024-09-17 12:46:30 --> Hooks Class Initialized
DEBUG - 2024-09-17 12:46:30 --> UTF-8 Support Enabled
INFO - 2024-09-17 12:46:30 --> Utf8 Class Initialized
INFO - 2024-09-17 12:46:30 --> URI Class Initialized
INFO - 2024-09-17 12:46:30 --> Router Class Initialized
INFO - 2024-09-17 12:46:30 --> Output Class Initialized
INFO - 2024-09-17 12:46:30 --> Security Class Initialized
DEBUG - 2024-09-17 12:46:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-17 12:46:30 --> Input Class Initialized
INFO - 2024-09-17 12:46:30 --> Language Class Initialized
ERROR - 2024-09-17 12:46:30 --> 404 Page Not Found: /index
INFO - 2024-09-17 12:46:30 --> Config Class Initialized
INFO - 2024-09-17 12:46:30 --> Hooks Class Initialized
DEBUG - 2024-09-17 12:46:30 --> UTF-8 Support Enabled
INFO - 2024-09-17 12:46:30 --> Utf8 Class Initialized
INFO - 2024-09-17 12:46:30 --> URI Class Initialized
INFO - 2024-09-17 12:46:30 --> Router Class Initialized
INFO - 2024-09-17 12:46:30 --> Output Class Initialized
INFO - 2024-09-17 12:46:30 --> Security Class Initialized
DEBUG - 2024-09-17 12:46:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-17 12:46:30 --> Input Class Initialized
INFO - 2024-09-17 12:46:30 --> Language Class Initialized
INFO - 2024-09-17 12:46:30 --> Language Class Initialized
INFO - 2024-09-17 12:46:30 --> Config Class Initialized
INFO - 2024-09-17 12:46:30 --> Loader Class Initialized
INFO - 2024-09-17 12:46:30 --> Helper loaded: url_helper
INFO - 2024-09-17 12:46:30 --> Helper loaded: file_helper
INFO - 2024-09-17 12:46:30 --> Helper loaded: form_helper
INFO - 2024-09-17 12:46:30 --> Helper loaded: my_helper
INFO - 2024-09-17 12:46:30 --> Database Driver Class Initialized
INFO - 2024-09-17 12:46:30 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-17 12:46:30 --> Controller Class Initialized
INFO - 2024-09-17 12:46:38 --> Config Class Initialized
INFO - 2024-09-17 12:46:38 --> Hooks Class Initialized
DEBUG - 2024-09-17 12:46:38 --> UTF-8 Support Enabled
INFO - 2024-09-17 12:46:38 --> Utf8 Class Initialized
INFO - 2024-09-17 12:46:38 --> URI Class Initialized
INFO - 2024-09-17 12:46:38 --> Router Class Initialized
INFO - 2024-09-17 12:46:38 --> Output Class Initialized
INFO - 2024-09-17 12:46:38 --> Security Class Initialized
DEBUG - 2024-09-17 12:46:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-17 12:46:38 --> Input Class Initialized
INFO - 2024-09-17 12:46:38 --> Language Class Initialized
INFO - 2024-09-17 12:46:38 --> Language Class Initialized
INFO - 2024-09-17 12:46:38 --> Config Class Initialized
INFO - 2024-09-17 12:46:38 --> Loader Class Initialized
INFO - 2024-09-17 12:46:38 --> Helper loaded: url_helper
INFO - 2024-09-17 12:46:38 --> Helper loaded: file_helper
INFO - 2024-09-17 12:46:38 --> Helper loaded: form_helper
INFO - 2024-09-17 12:46:38 --> Helper loaded: my_helper
INFO - 2024-09-17 12:46:38 --> Database Driver Class Initialized
INFO - 2024-09-17 12:46:38 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-17 12:46:38 --> Controller Class Initialized
DEBUG - 2024-09-17 12:46:38 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/data_projek/views/list.php
DEBUG - 2024-09-17 12:46:38 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-09-17 12:46:38 --> Final output sent to browser
DEBUG - 2024-09-17 12:46:38 --> Total execution time: 0.0752
INFO - 2024-09-17 12:46:38 --> Config Class Initialized
INFO - 2024-09-17 12:46:38 --> Hooks Class Initialized
DEBUG - 2024-09-17 12:46:38 --> UTF-8 Support Enabled
INFO - 2024-09-17 12:46:38 --> Utf8 Class Initialized
INFO - 2024-09-17 12:46:38 --> URI Class Initialized
INFO - 2024-09-17 12:46:38 --> Router Class Initialized
INFO - 2024-09-17 12:46:38 --> Output Class Initialized
INFO - 2024-09-17 12:46:38 --> Security Class Initialized
DEBUG - 2024-09-17 12:46:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-17 12:46:38 --> Input Class Initialized
INFO - 2024-09-17 12:46:38 --> Language Class Initialized
ERROR - 2024-09-17 12:46:38 --> 404 Page Not Found: /index
INFO - 2024-09-17 12:46:38 --> Config Class Initialized
INFO - 2024-09-17 12:46:38 --> Hooks Class Initialized
DEBUG - 2024-09-17 12:46:38 --> UTF-8 Support Enabled
INFO - 2024-09-17 12:46:38 --> Utf8 Class Initialized
INFO - 2024-09-17 12:46:38 --> URI Class Initialized
INFO - 2024-09-17 12:46:38 --> Router Class Initialized
INFO - 2024-09-17 12:46:38 --> Output Class Initialized
INFO - 2024-09-17 12:46:38 --> Security Class Initialized
DEBUG - 2024-09-17 12:46:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-17 12:46:38 --> Input Class Initialized
INFO - 2024-09-17 12:46:38 --> Language Class Initialized
INFO - 2024-09-17 12:46:38 --> Language Class Initialized
INFO - 2024-09-17 12:46:38 --> Config Class Initialized
INFO - 2024-09-17 12:46:38 --> Loader Class Initialized
INFO - 2024-09-17 12:46:38 --> Helper loaded: url_helper
INFO - 2024-09-17 12:46:38 --> Helper loaded: file_helper
INFO - 2024-09-17 12:46:38 --> Helper loaded: form_helper
INFO - 2024-09-17 12:46:38 --> Helper loaded: my_helper
INFO - 2024-09-17 12:46:38 --> Database Driver Class Initialized
INFO - 2024-09-17 12:46:38 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-17 12:46:38 --> Controller Class Initialized
INFO - 2024-09-17 12:47:02 --> Config Class Initialized
INFO - 2024-09-17 12:47:02 --> Hooks Class Initialized
DEBUG - 2024-09-17 12:47:02 --> UTF-8 Support Enabled
INFO - 2024-09-17 12:47:02 --> Utf8 Class Initialized
INFO - 2024-09-17 12:47:02 --> URI Class Initialized
INFO - 2024-09-17 12:47:02 --> Router Class Initialized
INFO - 2024-09-17 12:47:02 --> Output Class Initialized
INFO - 2024-09-17 12:47:02 --> Security Class Initialized
DEBUG - 2024-09-17 12:47:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-17 12:47:02 --> Input Class Initialized
INFO - 2024-09-17 12:47:02 --> Language Class Initialized
INFO - 2024-09-17 12:47:02 --> Language Class Initialized
INFO - 2024-09-17 12:47:02 --> Config Class Initialized
INFO - 2024-09-17 12:47:02 --> Loader Class Initialized
INFO - 2024-09-17 12:47:02 --> Helper loaded: url_helper
INFO - 2024-09-17 12:47:02 --> Helper loaded: file_helper
INFO - 2024-09-17 12:47:02 --> Helper loaded: form_helper
INFO - 2024-09-17 12:47:02 --> Helper loaded: my_helper
INFO - 2024-09-17 12:47:02 --> Database Driver Class Initialized
INFO - 2024-09-17 12:47:02 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-17 12:47:02 --> Controller Class Initialized
DEBUG - 2024-09-17 12:47:02 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/data_kelas_tahfiz/views/list.php
DEBUG - 2024-09-17 12:47:02 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-09-17 12:47:02 --> Final output sent to browser
DEBUG - 2024-09-17 12:47:02 --> Total execution time: 0.0278
INFO - 2024-09-17 12:47:02 --> Config Class Initialized
INFO - 2024-09-17 12:47:02 --> Hooks Class Initialized
DEBUG - 2024-09-17 12:47:02 --> UTF-8 Support Enabled
INFO - 2024-09-17 12:47:02 --> Utf8 Class Initialized
INFO - 2024-09-17 12:47:02 --> URI Class Initialized
INFO - 2024-09-17 12:47:02 --> Router Class Initialized
INFO - 2024-09-17 12:47:02 --> Output Class Initialized
INFO - 2024-09-17 12:47:02 --> Security Class Initialized
DEBUG - 2024-09-17 12:47:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-17 12:47:02 --> Input Class Initialized
INFO - 2024-09-17 12:47:02 --> Language Class Initialized
ERROR - 2024-09-17 12:47:02 --> 404 Page Not Found: /index
INFO - 2024-09-17 12:47:03 --> Config Class Initialized
INFO - 2024-09-17 12:47:03 --> Hooks Class Initialized
DEBUG - 2024-09-17 12:47:03 --> UTF-8 Support Enabled
INFO - 2024-09-17 12:47:03 --> Utf8 Class Initialized
INFO - 2024-09-17 12:47:03 --> URI Class Initialized
INFO - 2024-09-17 12:47:03 --> Router Class Initialized
INFO - 2024-09-17 12:47:03 --> Output Class Initialized
INFO - 2024-09-17 12:47:03 --> Security Class Initialized
DEBUG - 2024-09-17 12:47:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-17 12:47:03 --> Input Class Initialized
INFO - 2024-09-17 12:47:03 --> Language Class Initialized
INFO - 2024-09-17 12:47:03 --> Language Class Initialized
INFO - 2024-09-17 12:47:03 --> Config Class Initialized
INFO - 2024-09-17 12:47:03 --> Loader Class Initialized
INFO - 2024-09-17 12:47:03 --> Helper loaded: url_helper
INFO - 2024-09-17 12:47:03 --> Helper loaded: file_helper
INFO - 2024-09-17 12:47:03 --> Helper loaded: form_helper
INFO - 2024-09-17 12:47:03 --> Helper loaded: my_helper
INFO - 2024-09-17 12:47:03 --> Database Driver Class Initialized
INFO - 2024-09-17 12:47:03 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-17 12:47:03 --> Controller Class Initialized
INFO - 2024-09-17 12:47:17 --> Config Class Initialized
INFO - 2024-09-17 12:47:17 --> Hooks Class Initialized
DEBUG - 2024-09-17 12:47:17 --> UTF-8 Support Enabled
INFO - 2024-09-17 12:47:17 --> Utf8 Class Initialized
INFO - 2024-09-17 12:47:17 --> URI Class Initialized
INFO - 2024-09-17 12:47:17 --> Router Class Initialized
INFO - 2024-09-17 12:47:17 --> Output Class Initialized
INFO - 2024-09-17 12:47:17 --> Security Class Initialized
DEBUG - 2024-09-17 12:47:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-17 12:47:17 --> Input Class Initialized
INFO - 2024-09-17 12:47:17 --> Language Class Initialized
INFO - 2024-09-17 12:47:17 --> Language Class Initialized
INFO - 2024-09-17 12:47:17 --> Config Class Initialized
INFO - 2024-09-17 12:47:17 --> Loader Class Initialized
INFO - 2024-09-17 12:47:17 --> Helper loaded: url_helper
INFO - 2024-09-17 12:47:17 --> Helper loaded: file_helper
INFO - 2024-09-17 12:47:17 --> Helper loaded: form_helper
INFO - 2024-09-17 12:47:17 --> Helper loaded: my_helper
INFO - 2024-09-17 12:47:17 --> Database Driver Class Initialized
INFO - 2024-09-17 12:47:17 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-17 12:47:17 --> Controller Class Initialized
DEBUG - 2024-09-17 12:47:17 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/set_kelas_tahfiz/views/list.php
DEBUG - 2024-09-17 12:47:17 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-09-17 12:47:17 --> Final output sent to browser
DEBUG - 2024-09-17 12:47:17 --> Total execution time: 0.0675
INFO - 2024-09-17 12:47:22 --> Config Class Initialized
INFO - 2024-09-17 12:47:22 --> Hooks Class Initialized
DEBUG - 2024-09-17 12:47:22 --> UTF-8 Support Enabled
INFO - 2024-09-17 12:47:22 --> Utf8 Class Initialized
INFO - 2024-09-17 12:47:22 --> URI Class Initialized
INFO - 2024-09-17 12:47:22 --> Router Class Initialized
INFO - 2024-09-17 12:47:22 --> Output Class Initialized
INFO - 2024-09-17 12:47:22 --> Security Class Initialized
DEBUG - 2024-09-17 12:47:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-17 12:47:22 --> Input Class Initialized
INFO - 2024-09-17 12:47:22 --> Language Class Initialized
INFO - 2024-09-17 12:47:22 --> Language Class Initialized
INFO - 2024-09-17 12:47:22 --> Config Class Initialized
INFO - 2024-09-17 12:47:22 --> Loader Class Initialized
INFO - 2024-09-17 12:47:22 --> Helper loaded: url_helper
INFO - 2024-09-17 12:47:22 --> Helper loaded: file_helper
INFO - 2024-09-17 12:47:22 --> Helper loaded: form_helper
INFO - 2024-09-17 12:47:22 --> Helper loaded: my_helper
INFO - 2024-09-17 12:47:22 --> Database Driver Class Initialized
INFO - 2024-09-17 12:47:22 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-17 12:47:22 --> Controller Class Initialized
DEBUG - 2024-09-17 12:47:22 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/data_kelas_tahfiz/views/list.php
DEBUG - 2024-09-17 12:47:22 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-09-17 12:47:22 --> Final output sent to browser
DEBUG - 2024-09-17 12:47:22 --> Total execution time: 0.1239
INFO - 2024-09-17 12:47:22 --> Config Class Initialized
INFO - 2024-09-17 12:47:22 --> Hooks Class Initialized
DEBUG - 2024-09-17 12:47:22 --> UTF-8 Support Enabled
INFO - 2024-09-17 12:47:22 --> Utf8 Class Initialized
INFO - 2024-09-17 12:47:22 --> URI Class Initialized
INFO - 2024-09-17 12:47:22 --> Router Class Initialized
INFO - 2024-09-17 12:47:22 --> Output Class Initialized
INFO - 2024-09-17 12:47:22 --> Security Class Initialized
DEBUG - 2024-09-17 12:47:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-17 12:47:22 --> Input Class Initialized
INFO - 2024-09-17 12:47:22 --> Language Class Initialized
ERROR - 2024-09-17 12:47:22 --> 404 Page Not Found: /index
INFO - 2024-09-17 12:47:22 --> Config Class Initialized
INFO - 2024-09-17 12:47:22 --> Hooks Class Initialized
DEBUG - 2024-09-17 12:47:22 --> UTF-8 Support Enabled
INFO - 2024-09-17 12:47:22 --> Utf8 Class Initialized
INFO - 2024-09-17 12:47:22 --> URI Class Initialized
INFO - 2024-09-17 12:47:22 --> Router Class Initialized
INFO - 2024-09-17 12:47:22 --> Output Class Initialized
INFO - 2024-09-17 12:47:22 --> Security Class Initialized
DEBUG - 2024-09-17 12:47:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-17 12:47:22 --> Input Class Initialized
INFO - 2024-09-17 12:47:22 --> Language Class Initialized
INFO - 2024-09-17 12:47:22 --> Language Class Initialized
INFO - 2024-09-17 12:47:22 --> Config Class Initialized
INFO - 2024-09-17 12:47:22 --> Loader Class Initialized
INFO - 2024-09-17 12:47:22 --> Helper loaded: url_helper
INFO - 2024-09-17 12:47:22 --> Helper loaded: file_helper
INFO - 2024-09-17 12:47:22 --> Helper loaded: form_helper
INFO - 2024-09-17 12:47:22 --> Helper loaded: my_helper
INFO - 2024-09-17 12:47:22 --> Database Driver Class Initialized
INFO - 2024-09-17 12:47:22 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-17 12:47:22 --> Controller Class Initialized
INFO - 2024-09-17 12:47:25 --> Config Class Initialized
INFO - 2024-09-17 12:47:25 --> Hooks Class Initialized
DEBUG - 2024-09-17 12:47:25 --> UTF-8 Support Enabled
INFO - 2024-09-17 12:47:25 --> Utf8 Class Initialized
INFO - 2024-09-17 12:47:25 --> URI Class Initialized
INFO - 2024-09-17 12:47:25 --> Router Class Initialized
INFO - 2024-09-17 12:47:25 --> Output Class Initialized
INFO - 2024-09-17 12:47:25 --> Security Class Initialized
DEBUG - 2024-09-17 12:47:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-17 12:47:25 --> Input Class Initialized
INFO - 2024-09-17 12:47:25 --> Language Class Initialized
INFO - 2024-09-17 12:47:25 --> Language Class Initialized
INFO - 2024-09-17 12:47:25 --> Config Class Initialized
INFO - 2024-09-17 12:47:25 --> Loader Class Initialized
INFO - 2024-09-17 12:47:25 --> Helper loaded: url_helper
INFO - 2024-09-17 12:47:25 --> Helper loaded: file_helper
INFO - 2024-09-17 12:47:25 --> Helper loaded: form_helper
INFO - 2024-09-17 12:47:25 --> Helper loaded: my_helper
INFO - 2024-09-17 12:47:25 --> Database Driver Class Initialized
INFO - 2024-09-17 12:47:25 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-17 12:47:25 --> Controller Class Initialized
INFO - 2024-09-17 12:47:25 --> Final output sent to browser
DEBUG - 2024-09-17 12:47:25 --> Total execution time: 0.0257
INFO - 2024-09-17 12:47:53 --> Config Class Initialized
INFO - 2024-09-17 12:47:53 --> Hooks Class Initialized
DEBUG - 2024-09-17 12:47:53 --> UTF-8 Support Enabled
INFO - 2024-09-17 12:47:53 --> Utf8 Class Initialized
INFO - 2024-09-17 12:47:53 --> URI Class Initialized
INFO - 2024-09-17 12:47:53 --> Router Class Initialized
INFO - 2024-09-17 12:47:53 --> Output Class Initialized
INFO - 2024-09-17 12:47:53 --> Security Class Initialized
DEBUG - 2024-09-17 12:47:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-17 12:47:53 --> Input Class Initialized
INFO - 2024-09-17 12:47:53 --> Language Class Initialized
INFO - 2024-09-17 12:47:53 --> Language Class Initialized
INFO - 2024-09-17 12:47:53 --> Config Class Initialized
INFO - 2024-09-17 12:47:53 --> Loader Class Initialized
INFO - 2024-09-17 12:47:53 --> Helper loaded: url_helper
INFO - 2024-09-17 12:47:53 --> Helper loaded: file_helper
INFO - 2024-09-17 12:47:53 --> Helper loaded: form_helper
INFO - 2024-09-17 12:47:53 --> Helper loaded: my_helper
INFO - 2024-09-17 12:47:53 --> Database Driver Class Initialized
INFO - 2024-09-17 12:47:53 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-17 12:47:53 --> Controller Class Initialized
INFO - 2024-09-17 12:47:53 --> Final output sent to browser
DEBUG - 2024-09-17 12:47:53 --> Total execution time: 0.0259
INFO - 2024-09-17 12:47:53 --> Config Class Initialized
INFO - 2024-09-17 12:47:53 --> Hooks Class Initialized
DEBUG - 2024-09-17 12:47:53 --> UTF-8 Support Enabled
INFO - 2024-09-17 12:47:53 --> Utf8 Class Initialized
INFO - 2024-09-17 12:47:53 --> URI Class Initialized
INFO - 2024-09-17 12:47:53 --> Router Class Initialized
INFO - 2024-09-17 12:47:53 --> Output Class Initialized
INFO - 2024-09-17 12:47:53 --> Security Class Initialized
DEBUG - 2024-09-17 12:47:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-17 12:47:53 --> Input Class Initialized
INFO - 2024-09-17 12:47:53 --> Language Class Initialized
ERROR - 2024-09-17 12:47:53 --> 404 Page Not Found: /index
INFO - 2024-09-17 12:47:53 --> Config Class Initialized
INFO - 2024-09-17 12:47:53 --> Hooks Class Initialized
DEBUG - 2024-09-17 12:47:53 --> UTF-8 Support Enabled
INFO - 2024-09-17 12:47:53 --> Utf8 Class Initialized
INFO - 2024-09-17 12:47:53 --> URI Class Initialized
INFO - 2024-09-17 12:47:53 --> Router Class Initialized
INFO - 2024-09-17 12:47:53 --> Output Class Initialized
INFO - 2024-09-17 12:47:53 --> Security Class Initialized
DEBUG - 2024-09-17 12:47:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-17 12:47:53 --> Input Class Initialized
INFO - 2024-09-17 12:47:53 --> Language Class Initialized
INFO - 2024-09-17 12:47:53 --> Language Class Initialized
INFO - 2024-09-17 12:47:53 --> Config Class Initialized
INFO - 2024-09-17 12:47:53 --> Loader Class Initialized
INFO - 2024-09-17 12:47:53 --> Helper loaded: url_helper
INFO - 2024-09-17 12:47:53 --> Helper loaded: file_helper
INFO - 2024-09-17 12:47:53 --> Helper loaded: form_helper
INFO - 2024-09-17 12:47:53 --> Helper loaded: my_helper
INFO - 2024-09-17 12:47:53 --> Database Driver Class Initialized
INFO - 2024-09-17 12:47:53 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-17 12:47:53 --> Controller Class Initialized
INFO - 2024-09-17 12:48:02 --> Config Class Initialized
INFO - 2024-09-17 12:48:02 --> Hooks Class Initialized
DEBUG - 2024-09-17 12:48:02 --> UTF-8 Support Enabled
INFO - 2024-09-17 12:48:02 --> Utf8 Class Initialized
INFO - 2024-09-17 12:48:02 --> URI Class Initialized
INFO - 2024-09-17 12:48:02 --> Router Class Initialized
INFO - 2024-09-17 12:48:02 --> Output Class Initialized
INFO - 2024-09-17 12:48:02 --> Security Class Initialized
DEBUG - 2024-09-17 12:48:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-17 12:48:02 --> Input Class Initialized
INFO - 2024-09-17 12:48:02 --> Language Class Initialized
INFO - 2024-09-17 12:48:02 --> Language Class Initialized
INFO - 2024-09-17 12:48:02 --> Config Class Initialized
INFO - 2024-09-17 12:48:02 --> Loader Class Initialized
INFO - 2024-09-17 12:48:02 --> Helper loaded: url_helper
INFO - 2024-09-17 12:48:02 --> Helper loaded: file_helper
INFO - 2024-09-17 12:48:02 --> Helper loaded: form_helper
INFO - 2024-09-17 12:48:02 --> Helper loaded: my_helper
INFO - 2024-09-17 12:48:02 --> Database Driver Class Initialized
INFO - 2024-09-17 12:48:02 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-17 12:48:02 --> Controller Class Initialized
DEBUG - 2024-09-17 12:48:02 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/set_kelas_tahfiz/views/list.php
DEBUG - 2024-09-17 12:48:02 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-09-17 12:48:02 --> Final output sent to browser
DEBUG - 2024-09-17 12:48:02 --> Total execution time: 0.0297
INFO - 2024-09-17 12:48:04 --> Config Class Initialized
INFO - 2024-09-17 12:48:04 --> Hooks Class Initialized
DEBUG - 2024-09-17 12:48:04 --> UTF-8 Support Enabled
INFO - 2024-09-17 12:48:04 --> Utf8 Class Initialized
INFO - 2024-09-17 12:48:04 --> URI Class Initialized
INFO - 2024-09-17 12:48:04 --> Router Class Initialized
INFO - 2024-09-17 12:48:04 --> Output Class Initialized
INFO - 2024-09-17 12:48:04 --> Security Class Initialized
DEBUG - 2024-09-17 12:48:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-17 12:48:04 --> Input Class Initialized
INFO - 2024-09-17 12:48:04 --> Language Class Initialized
INFO - 2024-09-17 12:48:04 --> Language Class Initialized
INFO - 2024-09-17 12:48:04 --> Config Class Initialized
INFO - 2024-09-17 12:48:04 --> Loader Class Initialized
INFO - 2024-09-17 12:48:04 --> Helper loaded: url_helper
INFO - 2024-09-17 12:48:04 --> Helper loaded: file_helper
INFO - 2024-09-17 12:48:04 --> Helper loaded: form_helper
INFO - 2024-09-17 12:48:04 --> Helper loaded: my_helper
INFO - 2024-09-17 12:48:04 --> Database Driver Class Initialized
INFO - 2024-09-17 12:48:04 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-17 12:48:04 --> Controller Class Initialized
ERROR - 2024-09-17 12:48:04 --> Severity: Notice --> Undefined index: tingkat /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/set_kelas_tahfiz/views/form.php 49
ERROR - 2024-09-17 12:48:04 --> Severity: Notice --> Undefined index: tingkat /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/set_kelas_tahfiz/views/form.php 49
ERROR - 2024-09-17 12:48:04 --> Severity: Notice --> Undefined index: tingkat /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/set_kelas_tahfiz/views/form.php 49
ERROR - 2024-09-17 12:48:04 --> Severity: Notice --> Undefined index: tingkat /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/set_kelas_tahfiz/views/form.php 49
ERROR - 2024-09-17 12:48:04 --> Severity: Notice --> Undefined index: tingkat /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/set_kelas_tahfiz/views/form.php 49
ERROR - 2024-09-17 12:48:04 --> Severity: Notice --> Undefined index: tingkat /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/set_kelas_tahfiz/views/form.php 49
ERROR - 2024-09-17 12:48:04 --> Severity: Notice --> Undefined index: tingkat /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/set_kelas_tahfiz/views/form.php 49
ERROR - 2024-09-17 12:48:04 --> Severity: Notice --> Undefined index: tingkat /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/set_kelas_tahfiz/views/form.php 49
ERROR - 2024-09-17 12:48:04 --> Severity: Notice --> Undefined index: tingkat /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/set_kelas_tahfiz/views/form.php 49
ERROR - 2024-09-17 12:48:04 --> Severity: Notice --> Undefined index: tingkat /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/set_kelas_tahfiz/views/form.php 49
ERROR - 2024-09-17 12:48:04 --> Severity: Notice --> Undefined index: tingkat /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/set_kelas_tahfiz/views/form.php 49
ERROR - 2024-09-17 12:48:04 --> Severity: Notice --> Undefined index: tingkat /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/set_kelas_tahfiz/views/form.php 49
ERROR - 2024-09-17 12:48:04 --> Severity: Notice --> Undefined index: tingkat /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/set_kelas_tahfiz/views/form.php 49
ERROR - 2024-09-17 12:48:04 --> Severity: Notice --> Undefined index: tingkat /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/set_kelas_tahfiz/views/form.php 49
ERROR - 2024-09-17 12:48:04 --> Severity: Notice --> Undefined index: tingkat /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/set_kelas_tahfiz/views/form.php 49
ERROR - 2024-09-17 12:48:04 --> Severity: Notice --> Undefined index: tingkat /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/set_kelas_tahfiz/views/form.php 49
ERROR - 2024-09-17 12:48:04 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/set_kelas_tahfiz/views/form.php 49
ERROR - 2024-09-17 12:48:04 --> Severity: Notice --> Undefined index: kelas /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/set_kelas_tahfiz/views/form.php 59
ERROR - 2024-09-17 12:48:04 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/set_kelas_tahfiz/views/form.php 49
ERROR - 2024-09-17 12:48:04 --> Severity: Notice --> Undefined index: kelas /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/set_kelas_tahfiz/views/form.php 59
ERROR - 2024-09-17 12:48:04 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/set_kelas_tahfiz/views/form.php 49
ERROR - 2024-09-17 12:48:04 --> Severity: Notice --> Undefined index: kelas /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/set_kelas_tahfiz/views/form.php 59
ERROR - 2024-09-17 12:48:04 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/set_kelas_tahfiz/views/form.php 49
ERROR - 2024-09-17 12:48:04 --> Severity: Notice --> Undefined index: kelas /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/set_kelas_tahfiz/views/form.php 59
ERROR - 2024-09-17 12:48:04 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/set_kelas_tahfiz/views/form.php 49
ERROR - 2024-09-17 12:48:04 --> Severity: Notice --> Undefined index: kelas /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/set_kelas_tahfiz/views/form.php 59
ERROR - 2024-09-17 12:48:04 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/set_kelas_tahfiz/views/form.php 49
ERROR - 2024-09-17 12:48:04 --> Severity: Notice --> Undefined index: kelas /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/set_kelas_tahfiz/views/form.php 59
ERROR - 2024-09-17 12:48:04 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/set_kelas_tahfiz/views/form.php 49
ERROR - 2024-09-17 12:48:04 --> Severity: Notice --> Undefined index: kelas /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/set_kelas_tahfiz/views/form.php 59
ERROR - 2024-09-17 12:48:04 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/set_kelas_tahfiz/views/form.php 49
ERROR - 2024-09-17 12:48:04 --> Severity: Notice --> Undefined index: kelas /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/set_kelas_tahfiz/views/form.php 59
ERROR - 2024-09-17 12:48:04 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/set_kelas_tahfiz/views/form.php 49
ERROR - 2024-09-17 12:48:04 --> Severity: Notice --> Undefined index: kelas /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/set_kelas_tahfiz/views/form.php 59
ERROR - 2024-09-17 12:48:04 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/set_kelas_tahfiz/views/form.php 49
ERROR - 2024-09-17 12:48:04 --> Severity: Notice --> Undefined index: kelas /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/set_kelas_tahfiz/views/form.php 59
ERROR - 2024-09-17 12:48:04 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/set_kelas_tahfiz/views/form.php 49
ERROR - 2024-09-17 12:48:04 --> Severity: Notice --> Undefined index: kelas /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/set_kelas_tahfiz/views/form.php 59
ERROR - 2024-09-17 12:48:04 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/set_kelas_tahfiz/views/form.php 49
ERROR - 2024-09-17 12:48:04 --> Severity: Notice --> Undefined index: kelas /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/set_kelas_tahfiz/views/form.php 59
ERROR - 2024-09-17 12:48:04 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/set_kelas_tahfiz/views/form.php 49
ERROR - 2024-09-17 12:48:04 --> Severity: Notice --> Undefined index: kelas /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/set_kelas_tahfiz/views/form.php 59
ERROR - 2024-09-17 12:48:04 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/set_kelas_tahfiz/views/form.php 49
ERROR - 2024-09-17 12:48:04 --> Severity: Notice --> Undefined index: kelas /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/set_kelas_tahfiz/views/form.php 59
ERROR - 2024-09-17 12:48:04 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/set_kelas_tahfiz/views/form.php 49
ERROR - 2024-09-17 12:48:04 --> Severity: Notice --> Undefined index: kelas /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/set_kelas_tahfiz/views/form.php 59
ERROR - 2024-09-17 12:48:04 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/set_kelas_tahfiz/views/form.php 49
ERROR - 2024-09-17 12:48:04 --> Severity: Notice --> Undefined index: kelas /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/set_kelas_tahfiz/views/form.php 59
ERROR - 2024-09-17 12:48:04 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/set_kelas_tahfiz/views/form.php 49
ERROR - 2024-09-17 12:48:04 --> Severity: Notice --> Undefined index: kelas /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/set_kelas_tahfiz/views/form.php 59
ERROR - 2024-09-17 12:48:04 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/set_kelas_tahfiz/views/form.php 49
ERROR - 2024-09-17 12:48:04 --> Severity: Notice --> Undefined index: kelas /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/set_kelas_tahfiz/views/form.php 59
ERROR - 2024-09-17 12:48:04 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/set_kelas_tahfiz/views/form.php 49
ERROR - 2024-09-17 12:48:04 --> Severity: Notice --> Undefined index: kelas /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/set_kelas_tahfiz/views/form.php 59
ERROR - 2024-09-17 12:48:04 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/set_kelas_tahfiz/views/form.php 49
ERROR - 2024-09-17 12:48:04 --> Severity: Notice --> Undefined index: kelas /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/set_kelas_tahfiz/views/form.php 59
ERROR - 2024-09-17 12:48:04 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/set_kelas_tahfiz/views/form.php 49
ERROR - 2024-09-17 12:48:04 --> Severity: Notice --> Undefined index: kelas /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/set_kelas_tahfiz/views/form.php 59
ERROR - 2024-09-17 12:48:04 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/set_kelas_tahfiz/views/form.php 49
ERROR - 2024-09-17 12:48:04 --> Severity: Notice --> Undefined index: kelas /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/set_kelas_tahfiz/views/form.php 59
ERROR - 2024-09-17 12:48:04 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/set_kelas_tahfiz/views/form.php 49
ERROR - 2024-09-17 12:48:04 --> Severity: Notice --> Undefined index: kelas /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/set_kelas_tahfiz/views/form.php 59
ERROR - 2024-09-17 12:48:04 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/set_kelas_tahfiz/views/form.php 49
ERROR - 2024-09-17 12:48:04 --> Severity: Notice --> Undefined index: kelas /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/set_kelas_tahfiz/views/form.php 59
ERROR - 2024-09-17 12:48:04 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/set_kelas_tahfiz/views/form.php 49
ERROR - 2024-09-17 12:48:04 --> Severity: Notice --> Undefined index: kelas /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/set_kelas_tahfiz/views/form.php 59
ERROR - 2024-09-17 12:48:04 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/set_kelas_tahfiz/views/form.php 49
ERROR - 2024-09-17 12:48:04 --> Severity: Notice --> Undefined index: kelas /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/set_kelas_tahfiz/views/form.php 59
ERROR - 2024-09-17 12:48:04 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/set_kelas_tahfiz/views/form.php 49
ERROR - 2024-09-17 12:48:04 --> Severity: Notice --> Undefined index: kelas /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/set_kelas_tahfiz/views/form.php 59
ERROR - 2024-09-17 12:48:04 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/set_kelas_tahfiz/views/form.php 49
ERROR - 2024-09-17 12:48:04 --> Severity: Notice --> Undefined index: kelas /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/set_kelas_tahfiz/views/form.php 59
ERROR - 2024-09-17 12:48:04 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/set_kelas_tahfiz/views/form.php 49
ERROR - 2024-09-17 12:48:04 --> Severity: Notice --> Undefined index: kelas /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/set_kelas_tahfiz/views/form.php 59
ERROR - 2024-09-17 12:48:04 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/set_kelas_tahfiz/views/form.php 49
ERROR - 2024-09-17 12:48:04 --> Severity: Notice --> Undefined index: kelas /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/set_kelas_tahfiz/views/form.php 59
ERROR - 2024-09-17 12:48:04 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/set_kelas_tahfiz/views/form.php 49
ERROR - 2024-09-17 12:48:04 --> Severity: Notice --> Undefined index: kelas /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/set_kelas_tahfiz/views/form.php 59
ERROR - 2024-09-17 12:48:04 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/set_kelas_tahfiz/views/form.php 49
ERROR - 2024-09-17 12:48:04 --> Severity: Notice --> Undefined index: kelas /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/set_kelas_tahfiz/views/form.php 59
ERROR - 2024-09-17 12:48:04 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/set_kelas_tahfiz/views/form.php 49
ERROR - 2024-09-17 12:48:04 --> Severity: Notice --> Undefined index: kelas /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/set_kelas_tahfiz/views/form.php 59
ERROR - 2024-09-17 12:48:04 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/set_kelas_tahfiz/views/form.php 49
ERROR - 2024-09-17 12:48:04 --> Severity: Notice --> Undefined index: kelas /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/set_kelas_tahfiz/views/form.php 59
ERROR - 2024-09-17 12:48:04 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/set_kelas_tahfiz/views/form.php 49
ERROR - 2024-09-17 12:48:04 --> Severity: Notice --> Undefined index: kelas /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/set_kelas_tahfiz/views/form.php 59
ERROR - 2024-09-17 12:48:04 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/set_kelas_tahfiz/views/form.php 49
ERROR - 2024-09-17 12:48:04 --> Severity: Notice --> Undefined index: kelas /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/set_kelas_tahfiz/views/form.php 59
ERROR - 2024-09-17 12:48:04 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/set_kelas_tahfiz/views/form.php 49
ERROR - 2024-09-17 12:48:04 --> Severity: Notice --> Undefined index: kelas /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/set_kelas_tahfiz/views/form.php 59
ERROR - 2024-09-17 12:48:04 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/set_kelas_tahfiz/views/form.php 49
ERROR - 2024-09-17 12:48:04 --> Severity: Notice --> Undefined index: kelas /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/set_kelas_tahfiz/views/form.php 59
ERROR - 2024-09-17 12:48:04 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/set_kelas_tahfiz/views/form.php 49
ERROR - 2024-09-17 12:48:04 --> Severity: Notice --> Undefined index: kelas /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/set_kelas_tahfiz/views/form.php 59
ERROR - 2024-09-17 12:48:04 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/set_kelas_tahfiz/views/form.php 49
ERROR - 2024-09-17 12:48:04 --> Severity: Notice --> Undefined index: kelas /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/set_kelas_tahfiz/views/form.php 59
ERROR - 2024-09-17 12:48:04 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/set_kelas_tahfiz/views/form.php 49
ERROR - 2024-09-17 12:48:04 --> Severity: Notice --> Undefined index: kelas /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/set_kelas_tahfiz/views/form.php 59
DEBUG - 2024-09-17 12:48:04 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/set_kelas_tahfiz/views/form.php
DEBUG - 2024-09-17 12:48:04 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-09-17 12:48:04 --> Final output sent to browser
DEBUG - 2024-09-17 12:48:04 --> Total execution time: 0.1055
INFO - 2024-09-17 12:48:47 --> Config Class Initialized
INFO - 2024-09-17 12:48:47 --> Hooks Class Initialized
DEBUG - 2024-09-17 12:48:47 --> UTF-8 Support Enabled
INFO - 2024-09-17 12:48:47 --> Utf8 Class Initialized
INFO - 2024-09-17 12:48:47 --> URI Class Initialized
INFO - 2024-09-17 12:48:47 --> Router Class Initialized
INFO - 2024-09-17 12:48:47 --> Output Class Initialized
INFO - 2024-09-17 12:48:47 --> Security Class Initialized
DEBUG - 2024-09-17 12:48:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-17 12:48:47 --> Input Class Initialized
INFO - 2024-09-17 12:48:47 --> Language Class Initialized
INFO - 2024-09-17 12:48:47 --> Language Class Initialized
INFO - 2024-09-17 12:48:47 --> Config Class Initialized
INFO - 2024-09-17 12:48:47 --> Loader Class Initialized
INFO - 2024-09-17 12:48:47 --> Helper loaded: url_helper
INFO - 2024-09-17 12:48:47 --> Helper loaded: file_helper
INFO - 2024-09-17 12:48:47 --> Helper loaded: form_helper
INFO - 2024-09-17 12:48:47 --> Helper loaded: my_helper
INFO - 2024-09-17 12:48:47 --> Database Driver Class Initialized
INFO - 2024-09-17 12:48:47 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-17 12:48:47 --> Controller Class Initialized
DEBUG - 2024-09-17 12:48:47 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/data_mapel/views/list.php
DEBUG - 2024-09-17 12:48:47 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-09-17 12:48:47 --> Final output sent to browser
DEBUG - 2024-09-17 12:48:47 --> Total execution time: 0.0297
INFO - 2024-09-17 12:48:47 --> Config Class Initialized
INFO - 2024-09-17 12:48:47 --> Hooks Class Initialized
DEBUG - 2024-09-17 12:48:47 --> UTF-8 Support Enabled
INFO - 2024-09-17 12:48:47 --> Utf8 Class Initialized
INFO - 2024-09-17 12:48:47 --> URI Class Initialized
INFO - 2024-09-17 12:48:47 --> Router Class Initialized
INFO - 2024-09-17 12:48:47 --> Output Class Initialized
INFO - 2024-09-17 12:48:47 --> Security Class Initialized
DEBUG - 2024-09-17 12:48:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-17 12:48:47 --> Input Class Initialized
INFO - 2024-09-17 12:48:47 --> Language Class Initialized
ERROR - 2024-09-17 12:48:47 --> 404 Page Not Found: /index
INFO - 2024-09-17 12:48:47 --> Config Class Initialized
INFO - 2024-09-17 12:48:47 --> Hooks Class Initialized
DEBUG - 2024-09-17 12:48:47 --> UTF-8 Support Enabled
INFO - 2024-09-17 12:48:47 --> Utf8 Class Initialized
INFO - 2024-09-17 12:48:47 --> URI Class Initialized
INFO - 2024-09-17 12:48:47 --> Router Class Initialized
INFO - 2024-09-17 12:48:47 --> Output Class Initialized
INFO - 2024-09-17 12:48:47 --> Security Class Initialized
DEBUG - 2024-09-17 12:48:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-17 12:48:47 --> Input Class Initialized
INFO - 2024-09-17 12:48:47 --> Language Class Initialized
INFO - 2024-09-17 12:48:47 --> Language Class Initialized
INFO - 2024-09-17 12:48:47 --> Config Class Initialized
INFO - 2024-09-17 12:48:47 --> Loader Class Initialized
INFO - 2024-09-17 12:48:47 --> Helper loaded: url_helper
INFO - 2024-09-17 12:48:47 --> Helper loaded: file_helper
INFO - 2024-09-17 12:48:47 --> Helper loaded: form_helper
INFO - 2024-09-17 12:48:47 --> Helper loaded: my_helper
INFO - 2024-09-17 12:48:47 --> Database Driver Class Initialized
INFO - 2024-09-17 12:48:47 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-17 12:48:47 --> Controller Class Initialized
INFO - 2024-09-17 12:48:59 --> Config Class Initialized
INFO - 2024-09-17 12:48:59 --> Hooks Class Initialized
DEBUG - 2024-09-17 12:48:59 --> UTF-8 Support Enabled
INFO - 2024-09-17 12:48:59 --> Utf8 Class Initialized
INFO - 2024-09-17 12:48:59 --> URI Class Initialized
INFO - 2024-09-17 12:48:59 --> Router Class Initialized
INFO - 2024-09-17 12:48:59 --> Output Class Initialized
INFO - 2024-09-17 12:48:59 --> Security Class Initialized
DEBUG - 2024-09-17 12:48:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-17 12:48:59 --> Input Class Initialized
INFO - 2024-09-17 12:48:59 --> Language Class Initialized
INFO - 2024-09-17 12:48:59 --> Language Class Initialized
INFO - 2024-09-17 12:48:59 --> Config Class Initialized
INFO - 2024-09-17 12:48:59 --> Loader Class Initialized
INFO - 2024-09-17 12:48:59 --> Helper loaded: url_helper
INFO - 2024-09-17 12:48:59 --> Helper loaded: file_helper
INFO - 2024-09-17 12:48:59 --> Helper loaded: form_helper
INFO - 2024-09-17 12:48:59 --> Helper loaded: my_helper
INFO - 2024-09-17 12:48:59 --> Database Driver Class Initialized
INFO - 2024-09-17 12:48:59 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-17 12:48:59 --> Controller Class Initialized
DEBUG - 2024-09-17 12:48:59 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/data_mapel/views/list.php
DEBUG - 2024-09-17 12:48:59 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-09-17 12:48:59 --> Final output sent to browser
DEBUG - 2024-09-17 12:48:59 --> Total execution time: 0.0284
INFO - 2024-09-17 12:48:59 --> Config Class Initialized
INFO - 2024-09-17 12:48:59 --> Hooks Class Initialized
DEBUG - 2024-09-17 12:48:59 --> UTF-8 Support Enabled
INFO - 2024-09-17 12:48:59 --> Utf8 Class Initialized
INFO - 2024-09-17 12:48:59 --> URI Class Initialized
INFO - 2024-09-17 12:48:59 --> Router Class Initialized
INFO - 2024-09-17 12:48:59 --> Output Class Initialized
INFO - 2024-09-17 12:48:59 --> Security Class Initialized
DEBUG - 2024-09-17 12:48:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-17 12:48:59 --> Input Class Initialized
INFO - 2024-09-17 12:48:59 --> Language Class Initialized
ERROR - 2024-09-17 12:48:59 --> 404 Page Not Found: /index
INFO - 2024-09-17 12:48:59 --> Config Class Initialized
INFO - 2024-09-17 12:48:59 --> Hooks Class Initialized
DEBUG - 2024-09-17 12:48:59 --> UTF-8 Support Enabled
INFO - 2024-09-17 12:48:59 --> Utf8 Class Initialized
INFO - 2024-09-17 12:48:59 --> URI Class Initialized
INFO - 2024-09-17 12:48:59 --> Router Class Initialized
INFO - 2024-09-17 12:48:59 --> Output Class Initialized
INFO - 2024-09-17 12:48:59 --> Security Class Initialized
DEBUG - 2024-09-17 12:48:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-17 12:48:59 --> Input Class Initialized
INFO - 2024-09-17 12:48:59 --> Language Class Initialized
INFO - 2024-09-17 12:48:59 --> Language Class Initialized
INFO - 2024-09-17 12:48:59 --> Config Class Initialized
INFO - 2024-09-17 12:48:59 --> Loader Class Initialized
INFO - 2024-09-17 12:48:59 --> Helper loaded: url_helper
INFO - 2024-09-17 12:48:59 --> Helper loaded: file_helper
INFO - 2024-09-17 12:48:59 --> Helper loaded: form_helper
INFO - 2024-09-17 12:48:59 --> Helper loaded: my_helper
INFO - 2024-09-17 12:48:59 --> Database Driver Class Initialized
INFO - 2024-09-17 12:48:59 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-17 12:48:59 --> Controller Class Initialized
INFO - 2024-09-17 12:49:12 --> Config Class Initialized
INFO - 2024-09-17 12:49:12 --> Hooks Class Initialized
DEBUG - 2024-09-17 12:49:12 --> UTF-8 Support Enabled
INFO - 2024-09-17 12:49:12 --> Utf8 Class Initialized
INFO - 2024-09-17 12:49:12 --> URI Class Initialized
INFO - 2024-09-17 12:49:12 --> Router Class Initialized
INFO - 2024-09-17 12:49:12 --> Output Class Initialized
INFO - 2024-09-17 12:49:12 --> Security Class Initialized
DEBUG - 2024-09-17 12:49:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-17 12:49:12 --> Input Class Initialized
INFO - 2024-09-17 12:49:12 --> Language Class Initialized
INFO - 2024-09-17 12:49:12 --> Language Class Initialized
INFO - 2024-09-17 12:49:12 --> Config Class Initialized
INFO - 2024-09-17 12:49:12 --> Loader Class Initialized
INFO - 2024-09-17 12:49:12 --> Helper loaded: url_helper
INFO - 2024-09-17 12:49:12 --> Helper loaded: file_helper
INFO - 2024-09-17 12:49:12 --> Helper loaded: form_helper
INFO - 2024-09-17 12:49:12 --> Helper loaded: my_helper
INFO - 2024-09-17 12:49:12 --> Database Driver Class Initialized
INFO - 2024-09-17 12:49:12 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-17 12:49:12 --> Controller Class Initialized
DEBUG - 2024-09-17 12:49:12 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/set_mapel/views/list.php
DEBUG - 2024-09-17 12:49:12 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-09-17 12:49:12 --> Final output sent to browser
DEBUG - 2024-09-17 12:49:12 --> Total execution time: 0.0301
INFO - 2024-09-17 12:49:13 --> Config Class Initialized
INFO - 2024-09-17 12:49:13 --> Hooks Class Initialized
DEBUG - 2024-09-17 12:49:13 --> UTF-8 Support Enabled
INFO - 2024-09-17 12:49:13 --> Utf8 Class Initialized
INFO - 2024-09-17 12:49:13 --> URI Class Initialized
INFO - 2024-09-17 12:49:13 --> Router Class Initialized
INFO - 2024-09-17 12:49:13 --> Output Class Initialized
INFO - 2024-09-17 12:49:13 --> Security Class Initialized
DEBUG - 2024-09-17 12:49:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-17 12:49:13 --> Input Class Initialized
INFO - 2024-09-17 12:49:13 --> Language Class Initialized
ERROR - 2024-09-17 12:49:13 --> 404 Page Not Found: /index
INFO - 2024-09-17 12:49:13 --> Config Class Initialized
INFO - 2024-09-17 12:49:13 --> Hooks Class Initialized
DEBUG - 2024-09-17 12:49:13 --> UTF-8 Support Enabled
INFO - 2024-09-17 12:49:13 --> Utf8 Class Initialized
INFO - 2024-09-17 12:49:13 --> URI Class Initialized
INFO - 2024-09-17 12:49:13 --> Router Class Initialized
INFO - 2024-09-17 12:49:13 --> Output Class Initialized
INFO - 2024-09-17 12:49:13 --> Security Class Initialized
DEBUG - 2024-09-17 12:49:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-17 12:49:13 --> Input Class Initialized
INFO - 2024-09-17 12:49:13 --> Language Class Initialized
INFO - 2024-09-17 12:49:13 --> Language Class Initialized
INFO - 2024-09-17 12:49:13 --> Config Class Initialized
INFO - 2024-09-17 12:49:13 --> Loader Class Initialized
INFO - 2024-09-17 12:49:13 --> Helper loaded: url_helper
INFO - 2024-09-17 12:49:13 --> Helper loaded: file_helper
INFO - 2024-09-17 12:49:13 --> Helper loaded: form_helper
INFO - 2024-09-17 12:49:13 --> Helper loaded: my_helper
INFO - 2024-09-17 12:49:13 --> Database Driver Class Initialized
INFO - 2024-09-17 12:49:13 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-17 12:49:13 --> Controller Class Initialized
INFO - 2024-09-17 12:49:17 --> Config Class Initialized
INFO - 2024-09-17 12:49:17 --> Hooks Class Initialized
DEBUG - 2024-09-17 12:49:17 --> UTF-8 Support Enabled
INFO - 2024-09-17 12:49:17 --> Utf8 Class Initialized
INFO - 2024-09-17 12:49:17 --> URI Class Initialized
INFO - 2024-09-17 12:49:17 --> Router Class Initialized
INFO - 2024-09-17 12:49:17 --> Output Class Initialized
INFO - 2024-09-17 12:49:17 --> Security Class Initialized
DEBUG - 2024-09-17 12:49:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-17 12:49:17 --> Input Class Initialized
INFO - 2024-09-17 12:49:17 --> Language Class Initialized
INFO - 2024-09-17 12:49:17 --> Language Class Initialized
INFO - 2024-09-17 12:49:17 --> Config Class Initialized
INFO - 2024-09-17 12:49:17 --> Loader Class Initialized
INFO - 2024-09-17 12:49:17 --> Helper loaded: url_helper
INFO - 2024-09-17 12:49:17 --> Helper loaded: file_helper
INFO - 2024-09-17 12:49:17 --> Helper loaded: form_helper
INFO - 2024-09-17 12:49:17 --> Helper loaded: my_helper
INFO - 2024-09-17 12:49:17 --> Database Driver Class Initialized
INFO - 2024-09-17 12:49:17 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-17 12:49:17 --> Controller Class Initialized
DEBUG - 2024-09-17 12:49:17 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/set_mapel/views/form.php
DEBUG - 2024-09-17 12:49:17 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-09-17 12:49:17 --> Final output sent to browser
DEBUG - 2024-09-17 12:49:17 --> Total execution time: 0.0265
INFO - 2024-09-17 12:49:42 --> Config Class Initialized
INFO - 2024-09-17 12:49:42 --> Hooks Class Initialized
DEBUG - 2024-09-17 12:49:42 --> UTF-8 Support Enabled
INFO - 2024-09-17 12:49:42 --> Utf8 Class Initialized
INFO - 2024-09-17 12:49:42 --> URI Class Initialized
INFO - 2024-09-17 12:49:42 --> Router Class Initialized
INFO - 2024-09-17 12:49:42 --> Output Class Initialized
INFO - 2024-09-17 12:49:42 --> Security Class Initialized
DEBUG - 2024-09-17 12:49:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-17 12:49:42 --> Input Class Initialized
INFO - 2024-09-17 12:49:42 --> Language Class Initialized
INFO - 2024-09-17 12:49:42 --> Language Class Initialized
INFO - 2024-09-17 12:49:42 --> Config Class Initialized
INFO - 2024-09-17 12:49:42 --> Loader Class Initialized
INFO - 2024-09-17 12:49:42 --> Helper loaded: url_helper
INFO - 2024-09-17 12:49:42 --> Helper loaded: file_helper
INFO - 2024-09-17 12:49:42 --> Helper loaded: form_helper
INFO - 2024-09-17 12:49:42 --> Helper loaded: my_helper
INFO - 2024-09-17 12:49:42 --> Database Driver Class Initialized
INFO - 2024-09-17 12:49:42 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-17 12:49:42 --> Controller Class Initialized
DEBUG - 2024-09-17 12:49:42 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/data_mapel/views/list.php
DEBUG - 2024-09-17 12:49:42 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-09-17 12:49:42 --> Final output sent to browser
DEBUG - 2024-09-17 12:49:42 --> Total execution time: 0.0243
INFO - 2024-09-17 12:49:42 --> Config Class Initialized
INFO - 2024-09-17 12:49:42 --> Hooks Class Initialized
DEBUG - 2024-09-17 12:49:42 --> UTF-8 Support Enabled
INFO - 2024-09-17 12:49:42 --> Utf8 Class Initialized
INFO - 2024-09-17 12:49:42 --> URI Class Initialized
INFO - 2024-09-17 12:49:42 --> Router Class Initialized
INFO - 2024-09-17 12:49:42 --> Output Class Initialized
INFO - 2024-09-17 12:49:42 --> Security Class Initialized
DEBUG - 2024-09-17 12:49:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-17 12:49:42 --> Input Class Initialized
INFO - 2024-09-17 12:49:42 --> Language Class Initialized
ERROR - 2024-09-17 12:49:42 --> 404 Page Not Found: /index
INFO - 2024-09-17 12:49:42 --> Config Class Initialized
INFO - 2024-09-17 12:49:42 --> Hooks Class Initialized
DEBUG - 2024-09-17 12:49:42 --> UTF-8 Support Enabled
INFO - 2024-09-17 12:49:42 --> Utf8 Class Initialized
INFO - 2024-09-17 12:49:42 --> URI Class Initialized
INFO - 2024-09-17 12:49:42 --> Router Class Initialized
INFO - 2024-09-17 12:49:42 --> Output Class Initialized
INFO - 2024-09-17 12:49:42 --> Security Class Initialized
DEBUG - 2024-09-17 12:49:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-17 12:49:42 --> Input Class Initialized
INFO - 2024-09-17 12:49:42 --> Language Class Initialized
INFO - 2024-09-17 12:49:42 --> Language Class Initialized
INFO - 2024-09-17 12:49:42 --> Config Class Initialized
INFO - 2024-09-17 12:49:42 --> Loader Class Initialized
INFO - 2024-09-17 12:49:42 --> Helper loaded: url_helper
INFO - 2024-09-17 12:49:42 --> Helper loaded: file_helper
INFO - 2024-09-17 12:49:42 --> Helper loaded: form_helper
INFO - 2024-09-17 12:49:42 --> Helper loaded: my_helper
INFO - 2024-09-17 12:49:42 --> Database Driver Class Initialized
INFO - 2024-09-17 12:49:42 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-17 12:49:42 --> Controller Class Initialized
INFO - 2024-09-17 12:49:47 --> Config Class Initialized
INFO - 2024-09-17 12:49:47 --> Hooks Class Initialized
DEBUG - 2024-09-17 12:49:47 --> UTF-8 Support Enabled
INFO - 2024-09-17 12:49:47 --> Utf8 Class Initialized
INFO - 2024-09-17 12:49:47 --> URI Class Initialized
INFO - 2024-09-17 12:49:47 --> Router Class Initialized
INFO - 2024-09-17 12:49:47 --> Output Class Initialized
INFO - 2024-09-17 12:49:47 --> Security Class Initialized
DEBUG - 2024-09-17 12:49:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-17 12:49:47 --> Input Class Initialized
INFO - 2024-09-17 12:49:47 --> Language Class Initialized
INFO - 2024-09-17 12:49:47 --> Language Class Initialized
INFO - 2024-09-17 12:49:47 --> Config Class Initialized
INFO - 2024-09-17 12:49:47 --> Loader Class Initialized
INFO - 2024-09-17 12:49:47 --> Helper loaded: url_helper
INFO - 2024-09-17 12:49:47 --> Helper loaded: file_helper
INFO - 2024-09-17 12:49:47 --> Helper loaded: form_helper
INFO - 2024-09-17 12:49:47 --> Helper loaded: my_helper
INFO - 2024-09-17 12:49:47 --> Database Driver Class Initialized
INFO - 2024-09-17 12:49:47 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-17 12:49:47 --> Controller Class Initialized
INFO - 2024-09-17 12:49:47 --> Final output sent to browser
DEBUG - 2024-09-17 12:49:47 --> Total execution time: 0.0480
INFO - 2024-09-17 12:49:53 --> Config Class Initialized
INFO - 2024-09-17 12:49:53 --> Hooks Class Initialized
DEBUG - 2024-09-17 12:49:53 --> UTF-8 Support Enabled
INFO - 2024-09-17 12:49:53 --> Utf8 Class Initialized
INFO - 2024-09-17 12:49:53 --> URI Class Initialized
INFO - 2024-09-17 12:49:53 --> Router Class Initialized
INFO - 2024-09-17 12:49:53 --> Output Class Initialized
INFO - 2024-09-17 12:49:53 --> Security Class Initialized
DEBUG - 2024-09-17 12:49:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-17 12:49:53 --> Input Class Initialized
INFO - 2024-09-17 12:49:53 --> Language Class Initialized
INFO - 2024-09-17 12:49:53 --> Language Class Initialized
INFO - 2024-09-17 12:49:53 --> Config Class Initialized
INFO - 2024-09-17 12:49:53 --> Loader Class Initialized
INFO - 2024-09-17 12:49:53 --> Helper loaded: url_helper
INFO - 2024-09-17 12:49:53 --> Helper loaded: file_helper
INFO - 2024-09-17 12:49:53 --> Helper loaded: form_helper
INFO - 2024-09-17 12:49:53 --> Helper loaded: my_helper
INFO - 2024-09-17 12:49:53 --> Database Driver Class Initialized
INFO - 2024-09-17 12:49:53 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-17 12:49:53 --> Controller Class Initialized
INFO - 2024-09-17 12:49:53 --> Final output sent to browser
DEBUG - 2024-09-17 12:49:53 --> Total execution time: 0.0250
INFO - 2024-09-17 12:49:53 --> Config Class Initialized
INFO - 2024-09-17 12:49:53 --> Hooks Class Initialized
DEBUG - 2024-09-17 12:49:53 --> UTF-8 Support Enabled
INFO - 2024-09-17 12:49:53 --> Utf8 Class Initialized
INFO - 2024-09-17 12:49:53 --> URI Class Initialized
INFO - 2024-09-17 12:49:53 --> Router Class Initialized
INFO - 2024-09-17 12:49:53 --> Output Class Initialized
INFO - 2024-09-17 12:49:53 --> Security Class Initialized
DEBUG - 2024-09-17 12:49:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-17 12:49:53 --> Input Class Initialized
INFO - 2024-09-17 12:49:53 --> Language Class Initialized
ERROR - 2024-09-17 12:49:53 --> 404 Page Not Found: /index
INFO - 2024-09-17 12:49:53 --> Config Class Initialized
INFO - 2024-09-17 12:49:53 --> Hooks Class Initialized
DEBUG - 2024-09-17 12:49:53 --> UTF-8 Support Enabled
INFO - 2024-09-17 12:49:53 --> Utf8 Class Initialized
INFO - 2024-09-17 12:49:53 --> URI Class Initialized
INFO - 2024-09-17 12:49:53 --> Router Class Initialized
INFO - 2024-09-17 12:49:53 --> Output Class Initialized
INFO - 2024-09-17 12:49:53 --> Security Class Initialized
DEBUG - 2024-09-17 12:49:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-17 12:49:53 --> Input Class Initialized
INFO - 2024-09-17 12:49:53 --> Language Class Initialized
INFO - 2024-09-17 12:49:53 --> Language Class Initialized
INFO - 2024-09-17 12:49:53 --> Config Class Initialized
INFO - 2024-09-17 12:49:53 --> Loader Class Initialized
INFO - 2024-09-17 12:49:53 --> Helper loaded: url_helper
INFO - 2024-09-17 12:49:53 --> Helper loaded: file_helper
INFO - 2024-09-17 12:49:53 --> Helper loaded: form_helper
INFO - 2024-09-17 12:49:53 --> Helper loaded: my_helper
INFO - 2024-09-17 12:49:53 --> Database Driver Class Initialized
INFO - 2024-09-17 12:49:53 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-17 12:49:53 --> Controller Class Initialized
INFO - 2024-09-17 12:49:58 --> Config Class Initialized
INFO - 2024-09-17 12:49:58 --> Hooks Class Initialized
DEBUG - 2024-09-17 12:49:58 --> UTF-8 Support Enabled
INFO - 2024-09-17 12:49:58 --> Utf8 Class Initialized
INFO - 2024-09-17 12:49:58 --> URI Class Initialized
INFO - 2024-09-17 12:49:58 --> Router Class Initialized
INFO - 2024-09-17 12:49:58 --> Output Class Initialized
INFO - 2024-09-17 12:49:58 --> Security Class Initialized
DEBUG - 2024-09-17 12:49:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-17 12:49:58 --> Input Class Initialized
INFO - 2024-09-17 12:49:58 --> Language Class Initialized
INFO - 2024-09-17 12:49:58 --> Language Class Initialized
INFO - 2024-09-17 12:49:58 --> Config Class Initialized
INFO - 2024-09-17 12:49:58 --> Loader Class Initialized
INFO - 2024-09-17 12:49:58 --> Helper loaded: url_helper
INFO - 2024-09-17 12:49:58 --> Helper loaded: file_helper
INFO - 2024-09-17 12:49:58 --> Helper loaded: form_helper
INFO - 2024-09-17 12:49:58 --> Helper loaded: my_helper
INFO - 2024-09-17 12:49:58 --> Database Driver Class Initialized
INFO - 2024-09-17 12:49:58 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-17 12:49:58 --> Controller Class Initialized
INFO - 2024-09-17 12:49:58 --> Final output sent to browser
DEBUG - 2024-09-17 12:49:58 --> Total execution time: 0.0331
INFO - 2024-09-17 12:50:00 --> Config Class Initialized
INFO - 2024-09-17 12:50:00 --> Hooks Class Initialized
DEBUG - 2024-09-17 12:50:00 --> UTF-8 Support Enabled
INFO - 2024-09-17 12:50:00 --> Utf8 Class Initialized
INFO - 2024-09-17 12:50:00 --> URI Class Initialized
INFO - 2024-09-17 12:50:00 --> Router Class Initialized
INFO - 2024-09-17 12:50:00 --> Output Class Initialized
INFO - 2024-09-17 12:50:00 --> Security Class Initialized
DEBUG - 2024-09-17 12:50:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-17 12:50:00 --> Input Class Initialized
INFO - 2024-09-17 12:50:00 --> Language Class Initialized
INFO - 2024-09-17 12:50:00 --> Language Class Initialized
INFO - 2024-09-17 12:50:00 --> Config Class Initialized
INFO - 2024-09-17 12:50:00 --> Loader Class Initialized
INFO - 2024-09-17 12:50:00 --> Helper loaded: url_helper
INFO - 2024-09-17 12:50:00 --> Helper loaded: file_helper
INFO - 2024-09-17 12:50:00 --> Helper loaded: form_helper
INFO - 2024-09-17 12:50:00 --> Helper loaded: my_helper
INFO - 2024-09-17 12:50:00 --> Database Driver Class Initialized
INFO - 2024-09-17 12:50:00 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-17 12:50:00 --> Controller Class Initialized
INFO - 2024-09-17 12:50:00 --> Final output sent to browser
DEBUG - 2024-09-17 12:50:00 --> Total execution time: 0.0284
INFO - 2024-09-17 12:50:00 --> Config Class Initialized
INFO - 2024-09-17 12:50:00 --> Hooks Class Initialized
DEBUG - 2024-09-17 12:50:00 --> UTF-8 Support Enabled
INFO - 2024-09-17 12:50:00 --> Utf8 Class Initialized
INFO - 2024-09-17 12:50:00 --> URI Class Initialized
INFO - 2024-09-17 12:50:00 --> Router Class Initialized
INFO - 2024-09-17 12:50:00 --> Output Class Initialized
INFO - 2024-09-17 12:50:00 --> Security Class Initialized
DEBUG - 2024-09-17 12:50:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-17 12:50:00 --> Input Class Initialized
INFO - 2024-09-17 12:50:00 --> Language Class Initialized
ERROR - 2024-09-17 12:50:00 --> 404 Page Not Found: /index
INFO - 2024-09-17 12:50:00 --> Config Class Initialized
INFO - 2024-09-17 12:50:00 --> Hooks Class Initialized
DEBUG - 2024-09-17 12:50:00 --> UTF-8 Support Enabled
INFO - 2024-09-17 12:50:00 --> Utf8 Class Initialized
INFO - 2024-09-17 12:50:00 --> URI Class Initialized
INFO - 2024-09-17 12:50:00 --> Router Class Initialized
INFO - 2024-09-17 12:50:00 --> Output Class Initialized
INFO - 2024-09-17 12:50:00 --> Security Class Initialized
DEBUG - 2024-09-17 12:50:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-17 12:50:00 --> Input Class Initialized
INFO - 2024-09-17 12:50:00 --> Language Class Initialized
INFO - 2024-09-17 12:50:00 --> Language Class Initialized
INFO - 2024-09-17 12:50:00 --> Config Class Initialized
INFO - 2024-09-17 12:50:00 --> Loader Class Initialized
INFO - 2024-09-17 12:50:00 --> Helper loaded: url_helper
INFO - 2024-09-17 12:50:00 --> Helper loaded: file_helper
INFO - 2024-09-17 12:50:00 --> Helper loaded: form_helper
INFO - 2024-09-17 12:50:00 --> Helper loaded: my_helper
INFO - 2024-09-17 12:50:00 --> Database Driver Class Initialized
INFO - 2024-09-17 12:50:00 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-17 12:50:00 --> Controller Class Initialized
INFO - 2024-09-17 12:50:07 --> Config Class Initialized
INFO - 2024-09-17 12:50:07 --> Hooks Class Initialized
DEBUG - 2024-09-17 12:50:07 --> UTF-8 Support Enabled
INFO - 2024-09-17 12:50:07 --> Utf8 Class Initialized
INFO - 2024-09-17 12:50:07 --> URI Class Initialized
INFO - 2024-09-17 12:50:07 --> Router Class Initialized
INFO - 2024-09-17 12:50:07 --> Output Class Initialized
INFO - 2024-09-17 12:50:07 --> Security Class Initialized
DEBUG - 2024-09-17 12:50:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-17 12:50:07 --> Input Class Initialized
INFO - 2024-09-17 12:50:07 --> Language Class Initialized
INFO - 2024-09-17 12:50:07 --> Language Class Initialized
INFO - 2024-09-17 12:50:07 --> Config Class Initialized
INFO - 2024-09-17 12:50:07 --> Loader Class Initialized
INFO - 2024-09-17 12:50:07 --> Helper loaded: url_helper
INFO - 2024-09-17 12:50:07 --> Helper loaded: file_helper
INFO - 2024-09-17 12:50:07 --> Helper loaded: form_helper
INFO - 2024-09-17 12:50:07 --> Helper loaded: my_helper
INFO - 2024-09-17 12:50:07 --> Database Driver Class Initialized
INFO - 2024-09-17 12:50:07 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-17 12:50:07 --> Controller Class Initialized
DEBUG - 2024-09-17 12:50:07 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/set_mapel/views/list.php
DEBUG - 2024-09-17 12:50:07 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-09-17 12:50:07 --> Final output sent to browser
DEBUG - 2024-09-17 12:50:07 --> Total execution time: 0.0824
INFO - 2024-09-17 12:50:07 --> Config Class Initialized
INFO - 2024-09-17 12:50:07 --> Hooks Class Initialized
DEBUG - 2024-09-17 12:50:07 --> UTF-8 Support Enabled
INFO - 2024-09-17 12:50:07 --> Utf8 Class Initialized
INFO - 2024-09-17 12:50:07 --> URI Class Initialized
INFO - 2024-09-17 12:50:07 --> Router Class Initialized
INFO - 2024-09-17 12:50:07 --> Output Class Initialized
INFO - 2024-09-17 12:50:07 --> Security Class Initialized
DEBUG - 2024-09-17 12:50:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-17 12:50:07 --> Input Class Initialized
INFO - 2024-09-17 12:50:07 --> Language Class Initialized
ERROR - 2024-09-17 12:50:07 --> 404 Page Not Found: /index
INFO - 2024-09-17 12:50:07 --> Config Class Initialized
INFO - 2024-09-17 12:50:07 --> Hooks Class Initialized
DEBUG - 2024-09-17 12:50:07 --> UTF-8 Support Enabled
INFO - 2024-09-17 12:50:07 --> Utf8 Class Initialized
INFO - 2024-09-17 12:50:07 --> URI Class Initialized
INFO - 2024-09-17 12:50:07 --> Router Class Initialized
INFO - 2024-09-17 12:50:07 --> Output Class Initialized
INFO - 2024-09-17 12:50:07 --> Security Class Initialized
DEBUG - 2024-09-17 12:50:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-17 12:50:07 --> Input Class Initialized
INFO - 2024-09-17 12:50:07 --> Language Class Initialized
INFO - 2024-09-17 12:50:07 --> Language Class Initialized
INFO - 2024-09-17 12:50:07 --> Config Class Initialized
INFO - 2024-09-17 12:50:07 --> Loader Class Initialized
INFO - 2024-09-17 12:50:07 --> Helper loaded: url_helper
INFO - 2024-09-17 12:50:07 --> Helper loaded: file_helper
INFO - 2024-09-17 12:50:07 --> Helper loaded: form_helper
INFO - 2024-09-17 12:50:07 --> Helper loaded: my_helper
INFO - 2024-09-17 12:50:07 --> Database Driver Class Initialized
INFO - 2024-09-17 12:50:07 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-17 12:50:07 --> Controller Class Initialized
INFO - 2024-09-17 12:50:08 --> Config Class Initialized
INFO - 2024-09-17 12:50:08 --> Hooks Class Initialized
DEBUG - 2024-09-17 12:50:08 --> UTF-8 Support Enabled
INFO - 2024-09-17 12:50:08 --> Utf8 Class Initialized
INFO - 2024-09-17 12:50:08 --> URI Class Initialized
INFO - 2024-09-17 12:50:08 --> Router Class Initialized
INFO - 2024-09-17 12:50:08 --> Output Class Initialized
INFO - 2024-09-17 12:50:08 --> Security Class Initialized
DEBUG - 2024-09-17 12:50:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-17 12:50:08 --> Input Class Initialized
INFO - 2024-09-17 12:50:08 --> Language Class Initialized
INFO - 2024-09-17 12:50:08 --> Language Class Initialized
INFO - 2024-09-17 12:50:08 --> Config Class Initialized
INFO - 2024-09-17 12:50:08 --> Loader Class Initialized
INFO - 2024-09-17 12:50:08 --> Helper loaded: url_helper
INFO - 2024-09-17 12:50:08 --> Helper loaded: file_helper
INFO - 2024-09-17 12:50:08 --> Helper loaded: form_helper
INFO - 2024-09-17 12:50:08 --> Helper loaded: my_helper
INFO - 2024-09-17 12:50:08 --> Database Driver Class Initialized
INFO - 2024-09-17 12:50:08 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-17 12:50:08 --> Controller Class Initialized
DEBUG - 2024-09-17 12:50:08 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/set_mapel/views/form.php
DEBUG - 2024-09-17 12:50:08 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-09-17 12:50:08 --> Final output sent to browser
DEBUG - 2024-09-17 12:50:08 --> Total execution time: 0.0274
INFO - 2024-09-17 12:50:25 --> Config Class Initialized
INFO - 2024-09-17 12:50:25 --> Hooks Class Initialized
DEBUG - 2024-09-17 12:50:25 --> UTF-8 Support Enabled
INFO - 2024-09-17 12:50:25 --> Utf8 Class Initialized
INFO - 2024-09-17 12:50:25 --> URI Class Initialized
INFO - 2024-09-17 12:50:25 --> Router Class Initialized
INFO - 2024-09-17 12:50:25 --> Output Class Initialized
INFO - 2024-09-17 12:50:25 --> Security Class Initialized
DEBUG - 2024-09-17 12:50:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-17 12:50:25 --> Input Class Initialized
INFO - 2024-09-17 12:50:25 --> Language Class Initialized
INFO - 2024-09-17 12:50:25 --> Language Class Initialized
INFO - 2024-09-17 12:50:25 --> Config Class Initialized
INFO - 2024-09-17 12:50:25 --> Loader Class Initialized
INFO - 2024-09-17 12:50:25 --> Helper loaded: url_helper
INFO - 2024-09-17 12:50:25 --> Helper loaded: file_helper
INFO - 2024-09-17 12:50:25 --> Helper loaded: form_helper
INFO - 2024-09-17 12:50:25 --> Helper loaded: my_helper
INFO - 2024-09-17 12:50:25 --> Database Driver Class Initialized
INFO - 2024-09-17 12:50:25 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-17 12:50:25 --> Controller Class Initialized
INFO - 2024-09-17 12:50:25 --> Config Class Initialized
INFO - 2024-09-17 12:50:25 --> Hooks Class Initialized
DEBUG - 2024-09-17 12:50:25 --> UTF-8 Support Enabled
INFO - 2024-09-17 12:50:25 --> Utf8 Class Initialized
INFO - 2024-09-17 12:50:25 --> URI Class Initialized
INFO - 2024-09-17 12:50:25 --> Router Class Initialized
INFO - 2024-09-17 12:50:25 --> Output Class Initialized
INFO - 2024-09-17 12:50:25 --> Security Class Initialized
DEBUG - 2024-09-17 12:50:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-17 12:50:25 --> Input Class Initialized
INFO - 2024-09-17 12:50:25 --> Language Class Initialized
INFO - 2024-09-17 12:50:25 --> Language Class Initialized
INFO - 2024-09-17 12:50:25 --> Config Class Initialized
INFO - 2024-09-17 12:50:25 --> Loader Class Initialized
INFO - 2024-09-17 12:50:25 --> Helper loaded: url_helper
INFO - 2024-09-17 12:50:25 --> Helper loaded: file_helper
INFO - 2024-09-17 12:50:25 --> Helper loaded: form_helper
INFO - 2024-09-17 12:50:25 --> Helper loaded: my_helper
INFO - 2024-09-17 12:50:25 --> Database Driver Class Initialized
INFO - 2024-09-17 12:50:25 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-17 12:50:25 --> Controller Class Initialized
DEBUG - 2024-09-17 12:50:25 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/set_mapel/views/list.php
DEBUG - 2024-09-17 12:50:25 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-09-17 12:50:25 --> Final output sent to browser
DEBUG - 2024-09-17 12:50:25 --> Total execution time: 0.0249
INFO - 2024-09-17 12:50:26 --> Config Class Initialized
INFO - 2024-09-17 12:50:26 --> Hooks Class Initialized
DEBUG - 2024-09-17 12:50:26 --> UTF-8 Support Enabled
INFO - 2024-09-17 12:50:26 --> Utf8 Class Initialized
INFO - 2024-09-17 12:50:26 --> URI Class Initialized
INFO - 2024-09-17 12:50:26 --> Router Class Initialized
INFO - 2024-09-17 12:50:26 --> Output Class Initialized
INFO - 2024-09-17 12:50:26 --> Security Class Initialized
DEBUG - 2024-09-17 12:50:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-17 12:50:26 --> Input Class Initialized
INFO - 2024-09-17 12:50:26 --> Language Class Initialized
ERROR - 2024-09-17 12:50:26 --> 404 Page Not Found: /index
INFO - 2024-09-17 12:50:26 --> Config Class Initialized
INFO - 2024-09-17 12:50:26 --> Hooks Class Initialized
DEBUG - 2024-09-17 12:50:26 --> UTF-8 Support Enabled
INFO - 2024-09-17 12:50:26 --> Utf8 Class Initialized
INFO - 2024-09-17 12:50:26 --> URI Class Initialized
INFO - 2024-09-17 12:50:26 --> Router Class Initialized
INFO - 2024-09-17 12:50:26 --> Output Class Initialized
INFO - 2024-09-17 12:50:26 --> Security Class Initialized
DEBUG - 2024-09-17 12:50:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-17 12:50:26 --> Input Class Initialized
INFO - 2024-09-17 12:50:26 --> Language Class Initialized
INFO - 2024-09-17 12:50:26 --> Language Class Initialized
INFO - 2024-09-17 12:50:26 --> Config Class Initialized
INFO - 2024-09-17 12:50:26 --> Loader Class Initialized
INFO - 2024-09-17 12:50:26 --> Helper loaded: url_helper
INFO - 2024-09-17 12:50:26 --> Helper loaded: file_helper
INFO - 2024-09-17 12:50:26 --> Helper loaded: form_helper
INFO - 2024-09-17 12:50:26 --> Helper loaded: my_helper
INFO - 2024-09-17 12:50:26 --> Database Driver Class Initialized
INFO - 2024-09-17 12:50:26 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-17 12:50:26 --> Controller Class Initialized
INFO - 2024-09-17 12:50:27 --> Config Class Initialized
INFO - 2024-09-17 12:50:27 --> Hooks Class Initialized
DEBUG - 2024-09-17 12:50:27 --> UTF-8 Support Enabled
INFO - 2024-09-17 12:50:27 --> Utf8 Class Initialized
INFO - 2024-09-17 12:50:27 --> URI Class Initialized
INFO - 2024-09-17 12:50:27 --> Router Class Initialized
INFO - 2024-09-17 12:50:27 --> Output Class Initialized
INFO - 2024-09-17 12:50:27 --> Security Class Initialized
DEBUG - 2024-09-17 12:50:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-17 12:50:27 --> Input Class Initialized
INFO - 2024-09-17 12:50:27 --> Language Class Initialized
INFO - 2024-09-17 12:50:27 --> Language Class Initialized
INFO - 2024-09-17 12:50:27 --> Config Class Initialized
INFO - 2024-09-17 12:50:27 --> Loader Class Initialized
INFO - 2024-09-17 12:50:27 --> Helper loaded: url_helper
INFO - 2024-09-17 12:50:27 --> Helper loaded: file_helper
INFO - 2024-09-17 12:50:27 --> Helper loaded: form_helper
INFO - 2024-09-17 12:50:27 --> Helper loaded: my_helper
INFO - 2024-09-17 12:50:27 --> Database Driver Class Initialized
INFO - 2024-09-17 12:50:27 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-17 12:50:27 --> Controller Class Initialized
DEBUG - 2024-09-17 12:50:27 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/set_mapel/views/form.php
DEBUG - 2024-09-17 12:50:27 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-09-17 12:50:27 --> Final output sent to browser
DEBUG - 2024-09-17 12:50:27 --> Total execution time: 0.0498
INFO - 2024-09-17 12:50:38 --> Config Class Initialized
INFO - 2024-09-17 12:50:38 --> Hooks Class Initialized
DEBUG - 2024-09-17 12:50:38 --> UTF-8 Support Enabled
INFO - 2024-09-17 12:50:38 --> Utf8 Class Initialized
INFO - 2024-09-17 12:50:38 --> URI Class Initialized
INFO - 2024-09-17 12:50:38 --> Router Class Initialized
INFO - 2024-09-17 12:50:38 --> Output Class Initialized
INFO - 2024-09-17 12:50:38 --> Security Class Initialized
DEBUG - 2024-09-17 12:50:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-17 12:50:38 --> Input Class Initialized
INFO - 2024-09-17 12:50:38 --> Language Class Initialized
INFO - 2024-09-17 12:50:38 --> Language Class Initialized
INFO - 2024-09-17 12:50:38 --> Config Class Initialized
INFO - 2024-09-17 12:50:38 --> Loader Class Initialized
INFO - 2024-09-17 12:50:38 --> Helper loaded: url_helper
INFO - 2024-09-17 12:50:38 --> Helper loaded: file_helper
INFO - 2024-09-17 12:50:38 --> Helper loaded: form_helper
INFO - 2024-09-17 12:50:38 --> Helper loaded: my_helper
INFO - 2024-09-17 12:50:38 --> Database Driver Class Initialized
INFO - 2024-09-17 12:50:38 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-17 12:50:38 --> Controller Class Initialized
INFO - 2024-09-17 12:50:38 --> Config Class Initialized
INFO - 2024-09-17 12:50:38 --> Hooks Class Initialized
DEBUG - 2024-09-17 12:50:38 --> UTF-8 Support Enabled
INFO - 2024-09-17 12:50:38 --> Utf8 Class Initialized
INFO - 2024-09-17 12:50:38 --> URI Class Initialized
INFO - 2024-09-17 12:50:38 --> Router Class Initialized
INFO - 2024-09-17 12:50:38 --> Output Class Initialized
INFO - 2024-09-17 12:50:38 --> Security Class Initialized
DEBUG - 2024-09-17 12:50:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-17 12:50:38 --> Input Class Initialized
INFO - 2024-09-17 12:50:38 --> Language Class Initialized
INFO - 2024-09-17 12:50:38 --> Language Class Initialized
INFO - 2024-09-17 12:50:38 --> Config Class Initialized
INFO - 2024-09-17 12:50:38 --> Loader Class Initialized
INFO - 2024-09-17 12:50:38 --> Helper loaded: url_helper
INFO - 2024-09-17 12:50:38 --> Helper loaded: file_helper
INFO - 2024-09-17 12:50:38 --> Helper loaded: form_helper
INFO - 2024-09-17 12:50:38 --> Helper loaded: my_helper
INFO - 2024-09-17 12:50:38 --> Database Driver Class Initialized
INFO - 2024-09-17 12:50:38 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-17 12:50:38 --> Controller Class Initialized
DEBUG - 2024-09-17 12:50:38 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/set_mapel/views/list.php
DEBUG - 2024-09-17 12:50:38 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-09-17 12:50:38 --> Final output sent to browser
DEBUG - 2024-09-17 12:50:38 --> Total execution time: 0.0256
INFO - 2024-09-17 12:50:38 --> Config Class Initialized
INFO - 2024-09-17 12:50:38 --> Hooks Class Initialized
DEBUG - 2024-09-17 12:50:38 --> UTF-8 Support Enabled
INFO - 2024-09-17 12:50:38 --> Utf8 Class Initialized
INFO - 2024-09-17 12:50:38 --> URI Class Initialized
INFO - 2024-09-17 12:50:38 --> Router Class Initialized
INFO - 2024-09-17 12:50:38 --> Output Class Initialized
INFO - 2024-09-17 12:50:38 --> Security Class Initialized
DEBUG - 2024-09-17 12:50:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-17 12:50:38 --> Input Class Initialized
INFO - 2024-09-17 12:50:38 --> Language Class Initialized
ERROR - 2024-09-17 12:50:38 --> 404 Page Not Found: /index
INFO - 2024-09-17 12:50:38 --> Config Class Initialized
INFO - 2024-09-17 12:50:38 --> Hooks Class Initialized
DEBUG - 2024-09-17 12:50:38 --> UTF-8 Support Enabled
INFO - 2024-09-17 12:50:38 --> Utf8 Class Initialized
INFO - 2024-09-17 12:50:38 --> URI Class Initialized
INFO - 2024-09-17 12:50:38 --> Router Class Initialized
INFO - 2024-09-17 12:50:38 --> Output Class Initialized
INFO - 2024-09-17 12:50:38 --> Security Class Initialized
DEBUG - 2024-09-17 12:50:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-17 12:50:38 --> Input Class Initialized
INFO - 2024-09-17 12:50:38 --> Language Class Initialized
INFO - 2024-09-17 12:50:38 --> Language Class Initialized
INFO - 2024-09-17 12:50:38 --> Config Class Initialized
INFO - 2024-09-17 12:50:38 --> Loader Class Initialized
INFO - 2024-09-17 12:50:38 --> Helper loaded: url_helper
INFO - 2024-09-17 12:50:38 --> Helper loaded: file_helper
INFO - 2024-09-17 12:50:38 --> Helper loaded: form_helper
INFO - 2024-09-17 12:50:38 --> Helper loaded: my_helper
INFO - 2024-09-17 12:50:38 --> Database Driver Class Initialized
INFO - 2024-09-17 12:50:38 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-17 12:50:38 --> Controller Class Initialized
INFO - 2024-09-17 12:50:39 --> Config Class Initialized
INFO - 2024-09-17 12:50:39 --> Hooks Class Initialized
DEBUG - 2024-09-17 12:50:39 --> UTF-8 Support Enabled
INFO - 2024-09-17 12:50:39 --> Utf8 Class Initialized
INFO - 2024-09-17 12:50:39 --> URI Class Initialized
INFO - 2024-09-17 12:50:39 --> Router Class Initialized
INFO - 2024-09-17 12:50:39 --> Output Class Initialized
INFO - 2024-09-17 12:50:39 --> Security Class Initialized
DEBUG - 2024-09-17 12:50:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-17 12:50:39 --> Input Class Initialized
INFO - 2024-09-17 12:50:39 --> Language Class Initialized
INFO - 2024-09-17 12:50:39 --> Language Class Initialized
INFO - 2024-09-17 12:50:39 --> Config Class Initialized
INFO - 2024-09-17 12:50:39 --> Loader Class Initialized
INFO - 2024-09-17 12:50:39 --> Helper loaded: url_helper
INFO - 2024-09-17 12:50:39 --> Helper loaded: file_helper
INFO - 2024-09-17 12:50:39 --> Helper loaded: form_helper
INFO - 2024-09-17 12:50:39 --> Helper loaded: my_helper
INFO - 2024-09-17 12:50:39 --> Database Driver Class Initialized
INFO - 2024-09-17 12:50:39 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-17 12:50:39 --> Controller Class Initialized
DEBUG - 2024-09-17 12:50:39 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/set_mapel/views/form.php
DEBUG - 2024-09-17 12:50:39 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-09-17 12:50:39 --> Final output sent to browser
DEBUG - 2024-09-17 12:50:39 --> Total execution time: 0.0283
INFO - 2024-09-17 12:50:51 --> Config Class Initialized
INFO - 2024-09-17 12:50:51 --> Hooks Class Initialized
DEBUG - 2024-09-17 12:50:51 --> UTF-8 Support Enabled
INFO - 2024-09-17 12:50:51 --> Utf8 Class Initialized
INFO - 2024-09-17 12:50:51 --> URI Class Initialized
INFO - 2024-09-17 12:50:51 --> Router Class Initialized
INFO - 2024-09-17 12:50:51 --> Output Class Initialized
INFO - 2024-09-17 12:50:51 --> Security Class Initialized
DEBUG - 2024-09-17 12:50:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-17 12:50:51 --> Input Class Initialized
INFO - 2024-09-17 12:50:51 --> Language Class Initialized
INFO - 2024-09-17 12:50:51 --> Language Class Initialized
INFO - 2024-09-17 12:50:51 --> Config Class Initialized
INFO - 2024-09-17 12:50:51 --> Loader Class Initialized
INFO - 2024-09-17 12:50:51 --> Helper loaded: url_helper
INFO - 2024-09-17 12:50:51 --> Helper loaded: file_helper
INFO - 2024-09-17 12:50:51 --> Helper loaded: form_helper
INFO - 2024-09-17 12:50:51 --> Helper loaded: my_helper
INFO - 2024-09-17 12:50:51 --> Database Driver Class Initialized
INFO - 2024-09-17 12:50:51 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-17 12:50:51 --> Controller Class Initialized
INFO - 2024-09-17 12:50:52 --> Config Class Initialized
INFO - 2024-09-17 12:50:52 --> Hooks Class Initialized
DEBUG - 2024-09-17 12:50:52 --> UTF-8 Support Enabled
INFO - 2024-09-17 12:50:52 --> Utf8 Class Initialized
INFO - 2024-09-17 12:50:52 --> URI Class Initialized
INFO - 2024-09-17 12:50:52 --> Router Class Initialized
INFO - 2024-09-17 12:50:52 --> Output Class Initialized
INFO - 2024-09-17 12:50:52 --> Security Class Initialized
DEBUG - 2024-09-17 12:50:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-17 12:50:52 --> Input Class Initialized
INFO - 2024-09-17 12:50:52 --> Language Class Initialized
INFO - 2024-09-17 12:50:52 --> Language Class Initialized
INFO - 2024-09-17 12:50:52 --> Config Class Initialized
INFO - 2024-09-17 12:50:52 --> Loader Class Initialized
INFO - 2024-09-17 12:50:52 --> Helper loaded: url_helper
INFO - 2024-09-17 12:50:52 --> Helper loaded: file_helper
INFO - 2024-09-17 12:50:52 --> Helper loaded: form_helper
INFO - 2024-09-17 12:50:52 --> Helper loaded: my_helper
INFO - 2024-09-17 12:50:52 --> Database Driver Class Initialized
INFO - 2024-09-17 12:50:52 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-17 12:50:52 --> Controller Class Initialized
DEBUG - 2024-09-17 12:50:52 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/set_mapel/views/list.php
DEBUG - 2024-09-17 12:50:52 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-09-17 12:50:52 --> Final output sent to browser
DEBUG - 2024-09-17 12:50:52 --> Total execution time: 0.0640
INFO - 2024-09-17 12:50:52 --> Config Class Initialized
INFO - 2024-09-17 12:50:52 --> Hooks Class Initialized
DEBUG - 2024-09-17 12:50:52 --> UTF-8 Support Enabled
INFO - 2024-09-17 12:50:52 --> Utf8 Class Initialized
INFO - 2024-09-17 12:50:52 --> URI Class Initialized
INFO - 2024-09-17 12:50:52 --> Router Class Initialized
INFO - 2024-09-17 12:50:52 --> Output Class Initialized
INFO - 2024-09-17 12:50:52 --> Security Class Initialized
DEBUG - 2024-09-17 12:50:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-17 12:50:52 --> Input Class Initialized
INFO - 2024-09-17 12:50:52 --> Language Class Initialized
ERROR - 2024-09-17 12:50:52 --> 404 Page Not Found: /index
INFO - 2024-09-17 12:50:52 --> Config Class Initialized
INFO - 2024-09-17 12:50:52 --> Hooks Class Initialized
DEBUG - 2024-09-17 12:50:52 --> UTF-8 Support Enabled
INFO - 2024-09-17 12:50:52 --> Utf8 Class Initialized
INFO - 2024-09-17 12:50:52 --> URI Class Initialized
INFO - 2024-09-17 12:50:52 --> Router Class Initialized
INFO - 2024-09-17 12:50:52 --> Output Class Initialized
INFO - 2024-09-17 12:50:52 --> Security Class Initialized
DEBUG - 2024-09-17 12:50:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-17 12:50:52 --> Input Class Initialized
INFO - 2024-09-17 12:50:52 --> Language Class Initialized
INFO - 2024-09-17 12:50:52 --> Language Class Initialized
INFO - 2024-09-17 12:50:52 --> Config Class Initialized
INFO - 2024-09-17 12:50:52 --> Loader Class Initialized
INFO - 2024-09-17 12:50:52 --> Helper loaded: url_helper
INFO - 2024-09-17 12:50:52 --> Helper loaded: file_helper
INFO - 2024-09-17 12:50:52 --> Helper loaded: form_helper
INFO - 2024-09-17 12:50:52 --> Helper loaded: my_helper
INFO - 2024-09-17 12:50:52 --> Database Driver Class Initialized
INFO - 2024-09-17 12:50:52 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-17 12:50:52 --> Controller Class Initialized
INFO - 2024-09-17 12:50:54 --> Config Class Initialized
INFO - 2024-09-17 12:50:54 --> Hooks Class Initialized
DEBUG - 2024-09-17 12:50:54 --> UTF-8 Support Enabled
INFO - 2024-09-17 12:50:54 --> Utf8 Class Initialized
INFO - 2024-09-17 12:50:54 --> URI Class Initialized
INFO - 2024-09-17 12:50:54 --> Router Class Initialized
INFO - 2024-09-17 12:50:54 --> Output Class Initialized
INFO - 2024-09-17 12:50:54 --> Security Class Initialized
DEBUG - 2024-09-17 12:50:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-17 12:50:54 --> Input Class Initialized
INFO - 2024-09-17 12:50:54 --> Language Class Initialized
INFO - 2024-09-17 12:50:54 --> Language Class Initialized
INFO - 2024-09-17 12:50:54 --> Config Class Initialized
INFO - 2024-09-17 12:50:54 --> Loader Class Initialized
INFO - 2024-09-17 12:50:54 --> Helper loaded: url_helper
INFO - 2024-09-17 12:50:54 --> Helper loaded: file_helper
INFO - 2024-09-17 12:50:54 --> Helper loaded: form_helper
INFO - 2024-09-17 12:50:54 --> Helper loaded: my_helper
INFO - 2024-09-17 12:50:54 --> Database Driver Class Initialized
INFO - 2024-09-17 12:50:54 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-17 12:50:54 --> Controller Class Initialized
DEBUG - 2024-09-17 12:50:54 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/set_mapel/views/form.php
DEBUG - 2024-09-17 12:50:54 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-09-17 12:50:54 --> Final output sent to browser
DEBUG - 2024-09-17 12:50:54 --> Total execution time: 0.0278
INFO - 2024-09-17 12:52:31 --> Config Class Initialized
INFO - 2024-09-17 12:52:31 --> Hooks Class Initialized
DEBUG - 2024-09-17 12:52:31 --> UTF-8 Support Enabled
INFO - 2024-09-17 12:52:31 --> Utf8 Class Initialized
INFO - 2024-09-17 12:52:31 --> URI Class Initialized
INFO - 2024-09-17 12:52:31 --> Router Class Initialized
INFO - 2024-09-17 12:52:31 --> Output Class Initialized
INFO - 2024-09-17 12:52:31 --> Security Class Initialized
DEBUG - 2024-09-17 12:52:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-17 12:52:31 --> Input Class Initialized
INFO - 2024-09-17 12:52:31 --> Language Class Initialized
INFO - 2024-09-17 12:52:31 --> Language Class Initialized
INFO - 2024-09-17 12:52:31 --> Config Class Initialized
INFO - 2024-09-17 12:52:31 --> Loader Class Initialized
INFO - 2024-09-17 12:52:31 --> Helper loaded: url_helper
INFO - 2024-09-17 12:52:31 --> Helper loaded: file_helper
INFO - 2024-09-17 12:52:31 --> Helper loaded: form_helper
INFO - 2024-09-17 12:52:31 --> Helper loaded: my_helper
INFO - 2024-09-17 12:52:31 --> Database Driver Class Initialized
INFO - 2024-09-17 12:52:31 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-17 12:52:31 --> Controller Class Initialized
INFO - 2024-09-17 12:52:31 --> Config Class Initialized
INFO - 2024-09-17 12:52:31 --> Hooks Class Initialized
DEBUG - 2024-09-17 12:52:31 --> UTF-8 Support Enabled
INFO - 2024-09-17 12:52:31 --> Utf8 Class Initialized
INFO - 2024-09-17 12:52:31 --> URI Class Initialized
INFO - 2024-09-17 12:52:31 --> Router Class Initialized
INFO - 2024-09-17 12:52:31 --> Output Class Initialized
INFO - 2024-09-17 12:52:31 --> Security Class Initialized
DEBUG - 2024-09-17 12:52:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-17 12:52:31 --> Input Class Initialized
INFO - 2024-09-17 12:52:31 --> Language Class Initialized
INFO - 2024-09-17 12:52:31 --> Language Class Initialized
INFO - 2024-09-17 12:52:31 --> Config Class Initialized
INFO - 2024-09-17 12:52:31 --> Loader Class Initialized
INFO - 2024-09-17 12:52:31 --> Helper loaded: url_helper
INFO - 2024-09-17 12:52:31 --> Helper loaded: file_helper
INFO - 2024-09-17 12:52:31 --> Helper loaded: form_helper
INFO - 2024-09-17 12:52:31 --> Helper loaded: my_helper
INFO - 2024-09-17 12:52:31 --> Database Driver Class Initialized
INFO - 2024-09-17 12:52:31 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-17 12:52:31 --> Controller Class Initialized
DEBUG - 2024-09-17 12:52:31 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/set_mapel/views/list.php
DEBUG - 2024-09-17 12:52:31 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-09-17 12:52:31 --> Final output sent to browser
DEBUG - 2024-09-17 12:52:31 --> Total execution time: 0.0285
INFO - 2024-09-17 12:52:32 --> Config Class Initialized
INFO - 2024-09-17 12:52:32 --> Hooks Class Initialized
DEBUG - 2024-09-17 12:52:32 --> UTF-8 Support Enabled
INFO - 2024-09-17 12:52:32 --> Utf8 Class Initialized
INFO - 2024-09-17 12:52:32 --> URI Class Initialized
INFO - 2024-09-17 12:52:32 --> Router Class Initialized
INFO - 2024-09-17 12:52:32 --> Output Class Initialized
INFO - 2024-09-17 12:52:32 --> Security Class Initialized
DEBUG - 2024-09-17 12:52:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-17 12:52:32 --> Input Class Initialized
INFO - 2024-09-17 12:52:32 --> Language Class Initialized
ERROR - 2024-09-17 12:52:32 --> 404 Page Not Found: /index
INFO - 2024-09-17 12:52:32 --> Config Class Initialized
INFO - 2024-09-17 12:52:32 --> Hooks Class Initialized
DEBUG - 2024-09-17 12:52:32 --> UTF-8 Support Enabled
INFO - 2024-09-17 12:52:32 --> Utf8 Class Initialized
INFO - 2024-09-17 12:52:32 --> URI Class Initialized
INFO - 2024-09-17 12:52:32 --> Router Class Initialized
INFO - 2024-09-17 12:52:32 --> Output Class Initialized
INFO - 2024-09-17 12:52:32 --> Security Class Initialized
DEBUG - 2024-09-17 12:52:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-17 12:52:32 --> Input Class Initialized
INFO - 2024-09-17 12:52:32 --> Language Class Initialized
INFO - 2024-09-17 12:52:32 --> Language Class Initialized
INFO - 2024-09-17 12:52:32 --> Config Class Initialized
INFO - 2024-09-17 12:52:32 --> Loader Class Initialized
INFO - 2024-09-17 12:52:32 --> Helper loaded: url_helper
INFO - 2024-09-17 12:52:32 --> Helper loaded: file_helper
INFO - 2024-09-17 12:52:32 --> Helper loaded: form_helper
INFO - 2024-09-17 12:52:32 --> Helper loaded: my_helper
INFO - 2024-09-17 12:52:32 --> Database Driver Class Initialized
INFO - 2024-09-17 12:52:32 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-17 12:52:32 --> Controller Class Initialized
INFO - 2024-09-17 12:52:33 --> Config Class Initialized
INFO - 2024-09-17 12:52:33 --> Hooks Class Initialized
DEBUG - 2024-09-17 12:52:33 --> UTF-8 Support Enabled
INFO - 2024-09-17 12:52:33 --> Utf8 Class Initialized
INFO - 2024-09-17 12:52:33 --> URI Class Initialized
INFO - 2024-09-17 12:52:33 --> Router Class Initialized
INFO - 2024-09-17 12:52:33 --> Output Class Initialized
INFO - 2024-09-17 12:52:33 --> Security Class Initialized
DEBUG - 2024-09-17 12:52:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-17 12:52:33 --> Input Class Initialized
INFO - 2024-09-17 12:52:33 --> Language Class Initialized
INFO - 2024-09-17 12:52:33 --> Language Class Initialized
INFO - 2024-09-17 12:52:33 --> Config Class Initialized
INFO - 2024-09-17 12:52:33 --> Loader Class Initialized
INFO - 2024-09-17 12:52:33 --> Helper loaded: url_helper
INFO - 2024-09-17 12:52:33 --> Helper loaded: file_helper
INFO - 2024-09-17 12:52:33 --> Helper loaded: form_helper
INFO - 2024-09-17 12:52:33 --> Helper loaded: my_helper
INFO - 2024-09-17 12:52:33 --> Database Driver Class Initialized
INFO - 2024-09-17 12:52:33 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-17 12:52:33 --> Controller Class Initialized
DEBUG - 2024-09-17 12:52:33 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/set_mapel/views/form.php
DEBUG - 2024-09-17 12:52:33 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-09-17 12:52:33 --> Final output sent to browser
DEBUG - 2024-09-17 12:52:33 --> Total execution time: 0.0320
INFO - 2024-09-17 12:52:46 --> Config Class Initialized
INFO - 2024-09-17 12:52:46 --> Hooks Class Initialized
DEBUG - 2024-09-17 12:52:46 --> UTF-8 Support Enabled
INFO - 2024-09-17 12:52:46 --> Utf8 Class Initialized
INFO - 2024-09-17 12:52:46 --> URI Class Initialized
INFO - 2024-09-17 12:52:46 --> Router Class Initialized
INFO - 2024-09-17 12:52:46 --> Output Class Initialized
INFO - 2024-09-17 12:52:46 --> Security Class Initialized
DEBUG - 2024-09-17 12:52:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-17 12:52:46 --> Input Class Initialized
INFO - 2024-09-17 12:52:46 --> Language Class Initialized
INFO - 2024-09-17 12:52:46 --> Language Class Initialized
INFO - 2024-09-17 12:52:46 --> Config Class Initialized
INFO - 2024-09-17 12:52:46 --> Loader Class Initialized
INFO - 2024-09-17 12:52:46 --> Helper loaded: url_helper
INFO - 2024-09-17 12:52:46 --> Helper loaded: file_helper
INFO - 2024-09-17 12:52:46 --> Helper loaded: form_helper
INFO - 2024-09-17 12:52:46 --> Helper loaded: my_helper
INFO - 2024-09-17 12:52:46 --> Database Driver Class Initialized
INFO - 2024-09-17 12:52:46 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-17 12:52:46 --> Controller Class Initialized
INFO - 2024-09-17 12:52:46 --> Config Class Initialized
INFO - 2024-09-17 12:52:46 --> Hooks Class Initialized
DEBUG - 2024-09-17 12:52:46 --> UTF-8 Support Enabled
INFO - 2024-09-17 12:52:46 --> Utf8 Class Initialized
INFO - 2024-09-17 12:52:46 --> URI Class Initialized
INFO - 2024-09-17 12:52:46 --> Router Class Initialized
INFO - 2024-09-17 12:52:46 --> Output Class Initialized
INFO - 2024-09-17 12:52:46 --> Security Class Initialized
DEBUG - 2024-09-17 12:52:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-17 12:52:46 --> Input Class Initialized
INFO - 2024-09-17 12:52:46 --> Language Class Initialized
INFO - 2024-09-17 12:52:46 --> Language Class Initialized
INFO - 2024-09-17 12:52:46 --> Config Class Initialized
INFO - 2024-09-17 12:52:46 --> Loader Class Initialized
INFO - 2024-09-17 12:52:46 --> Helper loaded: url_helper
INFO - 2024-09-17 12:52:46 --> Helper loaded: file_helper
INFO - 2024-09-17 12:52:46 --> Helper loaded: form_helper
INFO - 2024-09-17 12:52:46 --> Helper loaded: my_helper
INFO - 2024-09-17 12:52:46 --> Database Driver Class Initialized
INFO - 2024-09-17 12:52:46 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-17 12:52:46 --> Controller Class Initialized
DEBUG - 2024-09-17 12:52:46 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/set_mapel/views/list.php
DEBUG - 2024-09-17 12:52:46 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-09-17 12:52:46 --> Final output sent to browser
DEBUG - 2024-09-17 12:52:46 --> Total execution time: 0.0290
INFO - 2024-09-17 12:52:46 --> Config Class Initialized
INFO - 2024-09-17 12:52:46 --> Hooks Class Initialized
DEBUG - 2024-09-17 12:52:46 --> UTF-8 Support Enabled
INFO - 2024-09-17 12:52:46 --> Utf8 Class Initialized
INFO - 2024-09-17 12:52:46 --> URI Class Initialized
INFO - 2024-09-17 12:52:46 --> Router Class Initialized
INFO - 2024-09-17 12:52:46 --> Output Class Initialized
INFO - 2024-09-17 12:52:46 --> Security Class Initialized
DEBUG - 2024-09-17 12:52:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-17 12:52:46 --> Input Class Initialized
INFO - 2024-09-17 12:52:46 --> Language Class Initialized
ERROR - 2024-09-17 12:52:46 --> 404 Page Not Found: /index
INFO - 2024-09-17 12:52:46 --> Config Class Initialized
INFO - 2024-09-17 12:52:46 --> Hooks Class Initialized
DEBUG - 2024-09-17 12:52:46 --> UTF-8 Support Enabled
INFO - 2024-09-17 12:52:46 --> Utf8 Class Initialized
INFO - 2024-09-17 12:52:46 --> URI Class Initialized
INFO - 2024-09-17 12:52:46 --> Router Class Initialized
INFO - 2024-09-17 12:52:46 --> Output Class Initialized
INFO - 2024-09-17 12:52:46 --> Security Class Initialized
DEBUG - 2024-09-17 12:52:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-17 12:52:46 --> Input Class Initialized
INFO - 2024-09-17 12:52:46 --> Language Class Initialized
INFO - 2024-09-17 12:52:46 --> Language Class Initialized
INFO - 2024-09-17 12:52:46 --> Config Class Initialized
INFO - 2024-09-17 12:52:46 --> Loader Class Initialized
INFO - 2024-09-17 12:52:46 --> Helper loaded: url_helper
INFO - 2024-09-17 12:52:46 --> Helper loaded: file_helper
INFO - 2024-09-17 12:52:46 --> Helper loaded: form_helper
INFO - 2024-09-17 12:52:46 --> Helper loaded: my_helper
INFO - 2024-09-17 12:52:46 --> Database Driver Class Initialized
INFO - 2024-09-17 12:52:46 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-17 12:52:46 --> Controller Class Initialized
INFO - 2024-09-17 12:52:48 --> Config Class Initialized
INFO - 2024-09-17 12:52:48 --> Hooks Class Initialized
DEBUG - 2024-09-17 12:52:48 --> UTF-8 Support Enabled
INFO - 2024-09-17 12:52:48 --> Utf8 Class Initialized
INFO - 2024-09-17 12:52:48 --> URI Class Initialized
INFO - 2024-09-17 12:52:48 --> Router Class Initialized
INFO - 2024-09-17 12:52:48 --> Output Class Initialized
INFO - 2024-09-17 12:52:48 --> Security Class Initialized
DEBUG - 2024-09-17 12:52:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-17 12:52:48 --> Input Class Initialized
INFO - 2024-09-17 12:52:48 --> Language Class Initialized
INFO - 2024-09-17 12:52:48 --> Language Class Initialized
INFO - 2024-09-17 12:52:48 --> Config Class Initialized
INFO - 2024-09-17 12:52:48 --> Loader Class Initialized
INFO - 2024-09-17 12:52:48 --> Helper loaded: url_helper
INFO - 2024-09-17 12:52:48 --> Helper loaded: file_helper
INFO - 2024-09-17 12:52:48 --> Helper loaded: form_helper
INFO - 2024-09-17 12:52:48 --> Helper loaded: my_helper
INFO - 2024-09-17 12:52:48 --> Database Driver Class Initialized
INFO - 2024-09-17 12:52:48 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-17 12:52:48 --> Controller Class Initialized
DEBUG - 2024-09-17 12:52:48 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/set_mapel/views/form.php
DEBUG - 2024-09-17 12:52:48 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-09-17 12:52:48 --> Final output sent to browser
DEBUG - 2024-09-17 12:52:48 --> Total execution time: 0.0305
INFO - 2024-09-17 12:53:04 --> Config Class Initialized
INFO - 2024-09-17 12:53:04 --> Hooks Class Initialized
DEBUG - 2024-09-17 12:53:04 --> UTF-8 Support Enabled
INFO - 2024-09-17 12:53:04 --> Utf8 Class Initialized
INFO - 2024-09-17 12:53:04 --> URI Class Initialized
INFO - 2024-09-17 12:53:04 --> Router Class Initialized
INFO - 2024-09-17 12:53:04 --> Output Class Initialized
INFO - 2024-09-17 12:53:04 --> Security Class Initialized
DEBUG - 2024-09-17 12:53:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-17 12:53:04 --> Input Class Initialized
INFO - 2024-09-17 12:53:04 --> Language Class Initialized
INFO - 2024-09-17 12:53:04 --> Language Class Initialized
INFO - 2024-09-17 12:53:04 --> Config Class Initialized
INFO - 2024-09-17 12:53:04 --> Loader Class Initialized
INFO - 2024-09-17 12:53:04 --> Helper loaded: url_helper
INFO - 2024-09-17 12:53:04 --> Helper loaded: file_helper
INFO - 2024-09-17 12:53:04 --> Helper loaded: form_helper
INFO - 2024-09-17 12:53:04 --> Helper loaded: my_helper
INFO - 2024-09-17 12:53:04 --> Database Driver Class Initialized
INFO - 2024-09-17 12:53:04 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-17 12:53:04 --> Controller Class Initialized
INFO - 2024-09-17 12:53:04 --> Config Class Initialized
INFO - 2024-09-17 12:53:04 --> Hooks Class Initialized
DEBUG - 2024-09-17 12:53:04 --> UTF-8 Support Enabled
INFO - 2024-09-17 12:53:04 --> Utf8 Class Initialized
INFO - 2024-09-17 12:53:04 --> URI Class Initialized
INFO - 2024-09-17 12:53:04 --> Router Class Initialized
INFO - 2024-09-17 12:53:04 --> Output Class Initialized
INFO - 2024-09-17 12:53:04 --> Security Class Initialized
DEBUG - 2024-09-17 12:53:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-17 12:53:04 --> Input Class Initialized
INFO - 2024-09-17 12:53:04 --> Language Class Initialized
INFO - 2024-09-17 12:53:04 --> Language Class Initialized
INFO - 2024-09-17 12:53:04 --> Config Class Initialized
INFO - 2024-09-17 12:53:04 --> Loader Class Initialized
INFO - 2024-09-17 12:53:04 --> Helper loaded: url_helper
INFO - 2024-09-17 12:53:04 --> Helper loaded: file_helper
INFO - 2024-09-17 12:53:04 --> Helper loaded: form_helper
INFO - 2024-09-17 12:53:04 --> Helper loaded: my_helper
INFO - 2024-09-17 12:53:04 --> Database Driver Class Initialized
INFO - 2024-09-17 12:53:04 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-17 12:53:04 --> Controller Class Initialized
DEBUG - 2024-09-17 12:53:04 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/set_mapel/views/list.php
DEBUG - 2024-09-17 12:53:04 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-09-17 12:53:04 --> Final output sent to browser
DEBUG - 2024-09-17 12:53:04 --> Total execution time: 0.0313
INFO - 2024-09-17 12:53:04 --> Config Class Initialized
INFO - 2024-09-17 12:53:04 --> Hooks Class Initialized
DEBUG - 2024-09-17 12:53:04 --> UTF-8 Support Enabled
INFO - 2024-09-17 12:53:04 --> Utf8 Class Initialized
INFO - 2024-09-17 12:53:04 --> URI Class Initialized
INFO - 2024-09-17 12:53:04 --> Router Class Initialized
INFO - 2024-09-17 12:53:04 --> Output Class Initialized
INFO - 2024-09-17 12:53:04 --> Security Class Initialized
DEBUG - 2024-09-17 12:53:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-17 12:53:04 --> Input Class Initialized
INFO - 2024-09-17 12:53:04 --> Language Class Initialized
ERROR - 2024-09-17 12:53:04 --> 404 Page Not Found: /index
INFO - 2024-09-17 12:53:05 --> Config Class Initialized
INFO - 2024-09-17 12:53:05 --> Hooks Class Initialized
DEBUG - 2024-09-17 12:53:05 --> UTF-8 Support Enabled
INFO - 2024-09-17 12:53:05 --> Utf8 Class Initialized
INFO - 2024-09-17 12:53:05 --> URI Class Initialized
INFO - 2024-09-17 12:53:05 --> Router Class Initialized
INFO - 2024-09-17 12:53:05 --> Output Class Initialized
INFO - 2024-09-17 12:53:05 --> Security Class Initialized
DEBUG - 2024-09-17 12:53:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-17 12:53:05 --> Input Class Initialized
INFO - 2024-09-17 12:53:05 --> Language Class Initialized
INFO - 2024-09-17 12:53:05 --> Language Class Initialized
INFO - 2024-09-17 12:53:05 --> Config Class Initialized
INFO - 2024-09-17 12:53:05 --> Loader Class Initialized
INFO - 2024-09-17 12:53:05 --> Helper loaded: url_helper
INFO - 2024-09-17 12:53:05 --> Helper loaded: file_helper
INFO - 2024-09-17 12:53:05 --> Helper loaded: form_helper
INFO - 2024-09-17 12:53:05 --> Helper loaded: my_helper
INFO - 2024-09-17 12:53:05 --> Database Driver Class Initialized
INFO - 2024-09-17 12:53:05 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-17 12:53:05 --> Controller Class Initialized
INFO - 2024-09-17 12:53:06 --> Config Class Initialized
INFO - 2024-09-17 12:53:06 --> Hooks Class Initialized
DEBUG - 2024-09-17 12:53:06 --> UTF-8 Support Enabled
INFO - 2024-09-17 12:53:06 --> Utf8 Class Initialized
INFO - 2024-09-17 12:53:06 --> URI Class Initialized
INFO - 2024-09-17 12:53:06 --> Router Class Initialized
INFO - 2024-09-17 12:53:06 --> Output Class Initialized
INFO - 2024-09-17 12:53:06 --> Security Class Initialized
DEBUG - 2024-09-17 12:53:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-17 12:53:06 --> Input Class Initialized
INFO - 2024-09-17 12:53:06 --> Language Class Initialized
INFO - 2024-09-17 12:53:06 --> Language Class Initialized
INFO - 2024-09-17 12:53:06 --> Config Class Initialized
INFO - 2024-09-17 12:53:06 --> Loader Class Initialized
INFO - 2024-09-17 12:53:06 --> Helper loaded: url_helper
INFO - 2024-09-17 12:53:06 --> Helper loaded: file_helper
INFO - 2024-09-17 12:53:06 --> Helper loaded: form_helper
INFO - 2024-09-17 12:53:06 --> Helper loaded: my_helper
INFO - 2024-09-17 12:53:06 --> Database Driver Class Initialized
INFO - 2024-09-17 12:53:06 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-17 12:53:06 --> Controller Class Initialized
DEBUG - 2024-09-17 12:53:06 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/set_mapel/views/form.php
DEBUG - 2024-09-17 12:53:06 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-09-17 12:53:06 --> Final output sent to browser
DEBUG - 2024-09-17 12:53:06 --> Total execution time: 0.0316
INFO - 2024-09-17 12:53:18 --> Config Class Initialized
INFO - 2024-09-17 12:53:18 --> Hooks Class Initialized
DEBUG - 2024-09-17 12:53:18 --> UTF-8 Support Enabled
INFO - 2024-09-17 12:53:18 --> Utf8 Class Initialized
INFO - 2024-09-17 12:53:18 --> URI Class Initialized
INFO - 2024-09-17 12:53:18 --> Router Class Initialized
INFO - 2024-09-17 12:53:18 --> Output Class Initialized
INFO - 2024-09-17 12:53:18 --> Security Class Initialized
DEBUG - 2024-09-17 12:53:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-17 12:53:18 --> Input Class Initialized
INFO - 2024-09-17 12:53:18 --> Language Class Initialized
INFO - 2024-09-17 12:53:18 --> Language Class Initialized
INFO - 2024-09-17 12:53:18 --> Config Class Initialized
INFO - 2024-09-17 12:53:18 --> Loader Class Initialized
INFO - 2024-09-17 12:53:18 --> Helper loaded: url_helper
INFO - 2024-09-17 12:53:18 --> Helper loaded: file_helper
INFO - 2024-09-17 12:53:18 --> Helper loaded: form_helper
INFO - 2024-09-17 12:53:18 --> Helper loaded: my_helper
INFO - 2024-09-17 12:53:18 --> Database Driver Class Initialized
INFO - 2024-09-17 12:53:18 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-17 12:53:18 --> Controller Class Initialized
INFO - 2024-09-17 12:53:18 --> Config Class Initialized
INFO - 2024-09-17 12:53:18 --> Hooks Class Initialized
DEBUG - 2024-09-17 12:53:18 --> UTF-8 Support Enabled
INFO - 2024-09-17 12:53:18 --> Utf8 Class Initialized
INFO - 2024-09-17 12:53:18 --> URI Class Initialized
INFO - 2024-09-17 12:53:18 --> Router Class Initialized
INFO - 2024-09-17 12:53:18 --> Output Class Initialized
INFO - 2024-09-17 12:53:18 --> Security Class Initialized
DEBUG - 2024-09-17 12:53:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-17 12:53:18 --> Input Class Initialized
INFO - 2024-09-17 12:53:18 --> Language Class Initialized
INFO - 2024-09-17 12:53:18 --> Language Class Initialized
INFO - 2024-09-17 12:53:18 --> Config Class Initialized
INFO - 2024-09-17 12:53:18 --> Loader Class Initialized
INFO - 2024-09-17 12:53:18 --> Helper loaded: url_helper
INFO - 2024-09-17 12:53:18 --> Helper loaded: file_helper
INFO - 2024-09-17 12:53:18 --> Helper loaded: form_helper
INFO - 2024-09-17 12:53:18 --> Helper loaded: my_helper
INFO - 2024-09-17 12:53:18 --> Database Driver Class Initialized
INFO - 2024-09-17 12:53:18 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-17 12:53:18 --> Controller Class Initialized
DEBUG - 2024-09-17 12:53:18 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/set_mapel/views/list.php
DEBUG - 2024-09-17 12:53:18 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-09-17 12:53:18 --> Final output sent to browser
DEBUG - 2024-09-17 12:53:18 --> Total execution time: 0.0914
INFO - 2024-09-17 12:53:18 --> Config Class Initialized
INFO - 2024-09-17 12:53:18 --> Hooks Class Initialized
DEBUG - 2024-09-17 12:53:18 --> UTF-8 Support Enabled
INFO - 2024-09-17 12:53:18 --> Utf8 Class Initialized
INFO - 2024-09-17 12:53:18 --> URI Class Initialized
INFO - 2024-09-17 12:53:18 --> Router Class Initialized
INFO - 2024-09-17 12:53:18 --> Output Class Initialized
INFO - 2024-09-17 12:53:18 --> Security Class Initialized
DEBUG - 2024-09-17 12:53:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-17 12:53:18 --> Input Class Initialized
INFO - 2024-09-17 12:53:18 --> Language Class Initialized
ERROR - 2024-09-17 12:53:18 --> 404 Page Not Found: /index
INFO - 2024-09-17 12:53:18 --> Config Class Initialized
INFO - 2024-09-17 12:53:18 --> Hooks Class Initialized
DEBUG - 2024-09-17 12:53:18 --> UTF-8 Support Enabled
INFO - 2024-09-17 12:53:18 --> Utf8 Class Initialized
INFO - 2024-09-17 12:53:18 --> URI Class Initialized
INFO - 2024-09-17 12:53:18 --> Router Class Initialized
INFO - 2024-09-17 12:53:18 --> Output Class Initialized
INFO - 2024-09-17 12:53:18 --> Security Class Initialized
DEBUG - 2024-09-17 12:53:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-17 12:53:18 --> Input Class Initialized
INFO - 2024-09-17 12:53:18 --> Language Class Initialized
INFO - 2024-09-17 12:53:18 --> Language Class Initialized
INFO - 2024-09-17 12:53:18 --> Config Class Initialized
INFO - 2024-09-17 12:53:18 --> Loader Class Initialized
INFO - 2024-09-17 12:53:18 --> Helper loaded: url_helper
INFO - 2024-09-17 12:53:18 --> Helper loaded: file_helper
INFO - 2024-09-17 12:53:18 --> Helper loaded: form_helper
INFO - 2024-09-17 12:53:18 --> Helper loaded: my_helper
INFO - 2024-09-17 12:53:18 --> Database Driver Class Initialized
INFO - 2024-09-17 12:53:18 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-17 12:53:18 --> Controller Class Initialized
INFO - 2024-09-17 12:53:19 --> Config Class Initialized
INFO - 2024-09-17 12:53:19 --> Hooks Class Initialized
DEBUG - 2024-09-17 12:53:19 --> UTF-8 Support Enabled
INFO - 2024-09-17 12:53:19 --> Utf8 Class Initialized
INFO - 2024-09-17 12:53:19 --> URI Class Initialized
INFO - 2024-09-17 12:53:19 --> Router Class Initialized
INFO - 2024-09-17 12:53:19 --> Output Class Initialized
INFO - 2024-09-17 12:53:19 --> Security Class Initialized
DEBUG - 2024-09-17 12:53:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-17 12:53:19 --> Input Class Initialized
INFO - 2024-09-17 12:53:19 --> Language Class Initialized
INFO - 2024-09-17 12:53:19 --> Language Class Initialized
INFO - 2024-09-17 12:53:19 --> Config Class Initialized
INFO - 2024-09-17 12:53:19 --> Loader Class Initialized
INFO - 2024-09-17 12:53:19 --> Helper loaded: url_helper
INFO - 2024-09-17 12:53:19 --> Helper loaded: file_helper
INFO - 2024-09-17 12:53:19 --> Helper loaded: form_helper
INFO - 2024-09-17 12:53:19 --> Helper loaded: my_helper
INFO - 2024-09-17 12:53:19 --> Database Driver Class Initialized
INFO - 2024-09-17 12:53:19 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-17 12:53:19 --> Controller Class Initialized
DEBUG - 2024-09-17 12:53:19 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/set_mapel/views/form.php
DEBUG - 2024-09-17 12:53:19 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-09-17 12:53:19 --> Final output sent to browser
DEBUG - 2024-09-17 12:53:19 --> Total execution time: 0.0384
INFO - 2024-09-17 12:53:29 --> Config Class Initialized
INFO - 2024-09-17 12:53:29 --> Hooks Class Initialized
DEBUG - 2024-09-17 12:53:29 --> UTF-8 Support Enabled
INFO - 2024-09-17 12:53:29 --> Utf8 Class Initialized
INFO - 2024-09-17 12:53:29 --> URI Class Initialized
INFO - 2024-09-17 12:53:29 --> Router Class Initialized
INFO - 2024-09-17 12:53:29 --> Output Class Initialized
INFO - 2024-09-17 12:53:29 --> Security Class Initialized
DEBUG - 2024-09-17 12:53:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-17 12:53:29 --> Input Class Initialized
INFO - 2024-09-17 12:53:29 --> Language Class Initialized
INFO - 2024-09-17 12:53:29 --> Language Class Initialized
INFO - 2024-09-17 12:53:29 --> Config Class Initialized
INFO - 2024-09-17 12:53:29 --> Loader Class Initialized
INFO - 2024-09-17 12:53:29 --> Helper loaded: url_helper
INFO - 2024-09-17 12:53:29 --> Helper loaded: file_helper
INFO - 2024-09-17 12:53:29 --> Helper loaded: form_helper
INFO - 2024-09-17 12:53:29 --> Helper loaded: my_helper
INFO - 2024-09-17 12:53:29 --> Database Driver Class Initialized
INFO - 2024-09-17 12:53:29 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-17 12:53:29 --> Controller Class Initialized
INFO - 2024-09-17 12:53:29 --> Config Class Initialized
INFO - 2024-09-17 12:53:29 --> Hooks Class Initialized
DEBUG - 2024-09-17 12:53:29 --> UTF-8 Support Enabled
INFO - 2024-09-17 12:53:29 --> Utf8 Class Initialized
INFO - 2024-09-17 12:53:29 --> URI Class Initialized
INFO - 2024-09-17 12:53:29 --> Router Class Initialized
INFO - 2024-09-17 12:53:29 --> Output Class Initialized
INFO - 2024-09-17 12:53:29 --> Security Class Initialized
DEBUG - 2024-09-17 12:53:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-17 12:53:29 --> Input Class Initialized
INFO - 2024-09-17 12:53:29 --> Language Class Initialized
INFO - 2024-09-17 12:53:29 --> Language Class Initialized
INFO - 2024-09-17 12:53:29 --> Config Class Initialized
INFO - 2024-09-17 12:53:29 --> Loader Class Initialized
INFO - 2024-09-17 12:53:29 --> Helper loaded: url_helper
INFO - 2024-09-17 12:53:29 --> Helper loaded: file_helper
INFO - 2024-09-17 12:53:29 --> Helper loaded: form_helper
INFO - 2024-09-17 12:53:29 --> Helper loaded: my_helper
INFO - 2024-09-17 12:53:29 --> Database Driver Class Initialized
INFO - 2024-09-17 12:53:29 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-17 12:53:29 --> Controller Class Initialized
DEBUG - 2024-09-17 12:53:29 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/set_mapel/views/list.php
DEBUG - 2024-09-17 12:53:29 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-09-17 12:53:29 --> Final output sent to browser
DEBUG - 2024-09-17 12:53:29 --> Total execution time: 0.0340
INFO - 2024-09-17 12:53:29 --> Config Class Initialized
INFO - 2024-09-17 12:53:29 --> Hooks Class Initialized
DEBUG - 2024-09-17 12:53:29 --> UTF-8 Support Enabled
INFO - 2024-09-17 12:53:29 --> Utf8 Class Initialized
INFO - 2024-09-17 12:53:29 --> URI Class Initialized
INFO - 2024-09-17 12:53:29 --> Router Class Initialized
INFO - 2024-09-17 12:53:29 --> Output Class Initialized
INFO - 2024-09-17 12:53:29 --> Security Class Initialized
DEBUG - 2024-09-17 12:53:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-17 12:53:29 --> Input Class Initialized
INFO - 2024-09-17 12:53:29 --> Language Class Initialized
ERROR - 2024-09-17 12:53:29 --> 404 Page Not Found: /index
INFO - 2024-09-17 12:53:29 --> Config Class Initialized
INFO - 2024-09-17 12:53:29 --> Hooks Class Initialized
DEBUG - 2024-09-17 12:53:29 --> UTF-8 Support Enabled
INFO - 2024-09-17 12:53:29 --> Utf8 Class Initialized
INFO - 2024-09-17 12:53:29 --> URI Class Initialized
INFO - 2024-09-17 12:53:29 --> Router Class Initialized
INFO - 2024-09-17 12:53:29 --> Output Class Initialized
INFO - 2024-09-17 12:53:29 --> Security Class Initialized
DEBUG - 2024-09-17 12:53:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-17 12:53:29 --> Input Class Initialized
INFO - 2024-09-17 12:53:29 --> Language Class Initialized
INFO - 2024-09-17 12:53:29 --> Language Class Initialized
INFO - 2024-09-17 12:53:29 --> Config Class Initialized
INFO - 2024-09-17 12:53:29 --> Loader Class Initialized
INFO - 2024-09-17 12:53:29 --> Helper loaded: url_helper
INFO - 2024-09-17 12:53:29 --> Helper loaded: file_helper
INFO - 2024-09-17 12:53:29 --> Helper loaded: form_helper
INFO - 2024-09-17 12:53:29 --> Helper loaded: my_helper
INFO - 2024-09-17 12:53:29 --> Database Driver Class Initialized
INFO - 2024-09-17 12:53:29 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-17 12:53:29 --> Controller Class Initialized
INFO - 2024-09-17 12:53:31 --> Config Class Initialized
INFO - 2024-09-17 12:53:31 --> Hooks Class Initialized
DEBUG - 2024-09-17 12:53:31 --> UTF-8 Support Enabled
INFO - 2024-09-17 12:53:31 --> Utf8 Class Initialized
INFO - 2024-09-17 12:53:31 --> URI Class Initialized
INFO - 2024-09-17 12:53:31 --> Router Class Initialized
INFO - 2024-09-17 12:53:31 --> Output Class Initialized
INFO - 2024-09-17 12:53:31 --> Security Class Initialized
DEBUG - 2024-09-17 12:53:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-17 12:53:31 --> Input Class Initialized
INFO - 2024-09-17 12:53:31 --> Language Class Initialized
INFO - 2024-09-17 12:53:31 --> Language Class Initialized
INFO - 2024-09-17 12:53:31 --> Config Class Initialized
INFO - 2024-09-17 12:53:31 --> Loader Class Initialized
INFO - 2024-09-17 12:53:31 --> Helper loaded: url_helper
INFO - 2024-09-17 12:53:31 --> Helper loaded: file_helper
INFO - 2024-09-17 12:53:31 --> Helper loaded: form_helper
INFO - 2024-09-17 12:53:31 --> Helper loaded: my_helper
INFO - 2024-09-17 12:53:31 --> Database Driver Class Initialized
INFO - 2024-09-17 12:53:31 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-17 12:53:31 --> Controller Class Initialized
DEBUG - 2024-09-17 12:53:31 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/set_mapel/views/form.php
DEBUG - 2024-09-17 12:53:31 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-09-17 12:53:31 --> Final output sent to browser
DEBUG - 2024-09-17 12:53:31 --> Total execution time: 0.0282
INFO - 2024-09-17 12:53:41 --> Config Class Initialized
INFO - 2024-09-17 12:53:41 --> Hooks Class Initialized
DEBUG - 2024-09-17 12:53:41 --> UTF-8 Support Enabled
INFO - 2024-09-17 12:53:41 --> Utf8 Class Initialized
INFO - 2024-09-17 12:53:41 --> URI Class Initialized
INFO - 2024-09-17 12:53:41 --> Router Class Initialized
INFO - 2024-09-17 12:53:41 --> Output Class Initialized
INFO - 2024-09-17 12:53:41 --> Security Class Initialized
DEBUG - 2024-09-17 12:53:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-17 12:53:41 --> Input Class Initialized
INFO - 2024-09-17 12:53:41 --> Language Class Initialized
INFO - 2024-09-17 12:53:41 --> Language Class Initialized
INFO - 2024-09-17 12:53:41 --> Config Class Initialized
INFO - 2024-09-17 12:53:41 --> Loader Class Initialized
INFO - 2024-09-17 12:53:41 --> Helper loaded: url_helper
INFO - 2024-09-17 12:53:41 --> Helper loaded: file_helper
INFO - 2024-09-17 12:53:41 --> Helper loaded: form_helper
INFO - 2024-09-17 12:53:41 --> Helper loaded: my_helper
INFO - 2024-09-17 12:53:41 --> Database Driver Class Initialized
INFO - 2024-09-17 12:53:41 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-17 12:53:41 --> Controller Class Initialized
INFO - 2024-09-17 12:53:42 --> Config Class Initialized
INFO - 2024-09-17 12:53:42 --> Hooks Class Initialized
DEBUG - 2024-09-17 12:53:42 --> UTF-8 Support Enabled
INFO - 2024-09-17 12:53:42 --> Utf8 Class Initialized
INFO - 2024-09-17 12:53:42 --> URI Class Initialized
INFO - 2024-09-17 12:53:42 --> Router Class Initialized
INFO - 2024-09-17 12:53:42 --> Output Class Initialized
INFO - 2024-09-17 12:53:42 --> Security Class Initialized
DEBUG - 2024-09-17 12:53:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-17 12:53:42 --> Input Class Initialized
INFO - 2024-09-17 12:53:42 --> Language Class Initialized
INFO - 2024-09-17 12:53:42 --> Language Class Initialized
INFO - 2024-09-17 12:53:42 --> Config Class Initialized
INFO - 2024-09-17 12:53:42 --> Loader Class Initialized
INFO - 2024-09-17 12:53:42 --> Helper loaded: url_helper
INFO - 2024-09-17 12:53:42 --> Helper loaded: file_helper
INFO - 2024-09-17 12:53:42 --> Helper loaded: form_helper
INFO - 2024-09-17 12:53:42 --> Helper loaded: my_helper
INFO - 2024-09-17 12:53:42 --> Database Driver Class Initialized
INFO - 2024-09-17 12:53:42 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-17 12:53:42 --> Controller Class Initialized
DEBUG - 2024-09-17 12:53:42 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/set_mapel/views/list.php
DEBUG - 2024-09-17 12:53:42 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-09-17 12:53:42 --> Final output sent to browser
DEBUG - 2024-09-17 12:53:42 --> Total execution time: 0.0282
INFO - 2024-09-17 12:53:42 --> Config Class Initialized
INFO - 2024-09-17 12:53:42 --> Hooks Class Initialized
DEBUG - 2024-09-17 12:53:42 --> UTF-8 Support Enabled
INFO - 2024-09-17 12:53:42 --> Utf8 Class Initialized
INFO - 2024-09-17 12:53:42 --> URI Class Initialized
INFO - 2024-09-17 12:53:42 --> Router Class Initialized
INFO - 2024-09-17 12:53:42 --> Output Class Initialized
INFO - 2024-09-17 12:53:42 --> Security Class Initialized
DEBUG - 2024-09-17 12:53:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-17 12:53:42 --> Input Class Initialized
INFO - 2024-09-17 12:53:42 --> Language Class Initialized
ERROR - 2024-09-17 12:53:42 --> 404 Page Not Found: /index
INFO - 2024-09-17 12:53:42 --> Config Class Initialized
INFO - 2024-09-17 12:53:42 --> Hooks Class Initialized
DEBUG - 2024-09-17 12:53:42 --> UTF-8 Support Enabled
INFO - 2024-09-17 12:53:42 --> Utf8 Class Initialized
INFO - 2024-09-17 12:53:42 --> URI Class Initialized
INFO - 2024-09-17 12:53:42 --> Router Class Initialized
INFO - 2024-09-17 12:53:42 --> Output Class Initialized
INFO - 2024-09-17 12:53:42 --> Security Class Initialized
DEBUG - 2024-09-17 12:53:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-17 12:53:42 --> Input Class Initialized
INFO - 2024-09-17 12:53:42 --> Language Class Initialized
INFO - 2024-09-17 12:53:42 --> Language Class Initialized
INFO - 2024-09-17 12:53:42 --> Config Class Initialized
INFO - 2024-09-17 12:53:42 --> Loader Class Initialized
INFO - 2024-09-17 12:53:42 --> Helper loaded: url_helper
INFO - 2024-09-17 12:53:42 --> Helper loaded: file_helper
INFO - 2024-09-17 12:53:42 --> Helper loaded: form_helper
INFO - 2024-09-17 12:53:42 --> Helper loaded: my_helper
INFO - 2024-09-17 12:53:42 --> Database Driver Class Initialized
INFO - 2024-09-17 12:53:42 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-17 12:53:42 --> Controller Class Initialized
INFO - 2024-09-17 12:53:46 --> Config Class Initialized
INFO - 2024-09-17 12:53:46 --> Hooks Class Initialized
DEBUG - 2024-09-17 12:53:46 --> UTF-8 Support Enabled
INFO - 2024-09-17 12:53:46 --> Utf8 Class Initialized
INFO - 2024-09-17 12:53:46 --> URI Class Initialized
INFO - 2024-09-17 12:53:46 --> Router Class Initialized
INFO - 2024-09-17 12:53:46 --> Output Class Initialized
INFO - 2024-09-17 12:53:46 --> Security Class Initialized
DEBUG - 2024-09-17 12:53:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-17 12:53:46 --> Input Class Initialized
INFO - 2024-09-17 12:53:46 --> Language Class Initialized
INFO - 2024-09-17 12:53:46 --> Language Class Initialized
INFO - 2024-09-17 12:53:46 --> Config Class Initialized
INFO - 2024-09-17 12:53:46 --> Loader Class Initialized
INFO - 2024-09-17 12:53:46 --> Helper loaded: url_helper
INFO - 2024-09-17 12:53:46 --> Helper loaded: file_helper
INFO - 2024-09-17 12:53:46 --> Helper loaded: form_helper
INFO - 2024-09-17 12:53:46 --> Helper loaded: my_helper
INFO - 2024-09-17 12:53:46 --> Database Driver Class Initialized
INFO - 2024-09-17 12:53:46 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-17 12:53:46 --> Controller Class Initialized
DEBUG - 2024-09-17 12:53:46 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/set_mapel/views/form.php
DEBUG - 2024-09-17 12:53:46 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-09-17 12:53:46 --> Final output sent to browser
DEBUG - 2024-09-17 12:53:46 --> Total execution time: 0.0372
INFO - 2024-09-17 12:54:06 --> Config Class Initialized
INFO - 2024-09-17 12:54:06 --> Hooks Class Initialized
DEBUG - 2024-09-17 12:54:06 --> UTF-8 Support Enabled
INFO - 2024-09-17 12:54:06 --> Utf8 Class Initialized
INFO - 2024-09-17 12:54:06 --> URI Class Initialized
INFO - 2024-09-17 12:54:06 --> Router Class Initialized
INFO - 2024-09-17 12:54:06 --> Output Class Initialized
INFO - 2024-09-17 12:54:06 --> Security Class Initialized
DEBUG - 2024-09-17 12:54:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-17 12:54:06 --> Input Class Initialized
INFO - 2024-09-17 12:54:06 --> Language Class Initialized
INFO - 2024-09-17 12:54:06 --> Language Class Initialized
INFO - 2024-09-17 12:54:06 --> Config Class Initialized
INFO - 2024-09-17 12:54:06 --> Loader Class Initialized
INFO - 2024-09-17 12:54:06 --> Helper loaded: url_helper
INFO - 2024-09-17 12:54:06 --> Helper loaded: file_helper
INFO - 2024-09-17 12:54:06 --> Helper loaded: form_helper
INFO - 2024-09-17 12:54:06 --> Helper loaded: my_helper
INFO - 2024-09-17 12:54:06 --> Database Driver Class Initialized
INFO - 2024-09-17 12:54:06 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-17 12:54:06 --> Controller Class Initialized
DEBUG - 2024-09-17 12:54:06 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/data_projek/views/list.php
DEBUG - 2024-09-17 12:54:06 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-09-17 12:54:06 --> Final output sent to browser
DEBUG - 2024-09-17 12:54:06 --> Total execution time: 0.0316
INFO - 2024-09-17 12:54:06 --> Config Class Initialized
INFO - 2024-09-17 12:54:06 --> Hooks Class Initialized
DEBUG - 2024-09-17 12:54:06 --> UTF-8 Support Enabled
INFO - 2024-09-17 12:54:06 --> Utf8 Class Initialized
INFO - 2024-09-17 12:54:06 --> URI Class Initialized
INFO - 2024-09-17 12:54:06 --> Router Class Initialized
INFO - 2024-09-17 12:54:06 --> Output Class Initialized
INFO - 2024-09-17 12:54:06 --> Security Class Initialized
DEBUG - 2024-09-17 12:54:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-17 12:54:06 --> Input Class Initialized
INFO - 2024-09-17 12:54:06 --> Language Class Initialized
ERROR - 2024-09-17 12:54:06 --> 404 Page Not Found: /index
INFO - 2024-09-17 12:54:06 --> Config Class Initialized
INFO - 2024-09-17 12:54:06 --> Hooks Class Initialized
DEBUG - 2024-09-17 12:54:06 --> UTF-8 Support Enabled
INFO - 2024-09-17 12:54:06 --> Utf8 Class Initialized
INFO - 2024-09-17 12:54:06 --> URI Class Initialized
INFO - 2024-09-17 12:54:06 --> Router Class Initialized
INFO - 2024-09-17 12:54:06 --> Output Class Initialized
INFO - 2024-09-17 12:54:06 --> Security Class Initialized
DEBUG - 2024-09-17 12:54:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-17 12:54:06 --> Input Class Initialized
INFO - 2024-09-17 12:54:06 --> Language Class Initialized
INFO - 2024-09-17 12:54:06 --> Language Class Initialized
INFO - 2024-09-17 12:54:06 --> Config Class Initialized
INFO - 2024-09-17 12:54:06 --> Loader Class Initialized
INFO - 2024-09-17 12:54:06 --> Helper loaded: url_helper
INFO - 2024-09-17 12:54:06 --> Helper loaded: file_helper
INFO - 2024-09-17 12:54:06 --> Helper loaded: form_helper
INFO - 2024-09-17 12:54:06 --> Helper loaded: my_helper
INFO - 2024-09-17 12:54:06 --> Database Driver Class Initialized
INFO - 2024-09-17 12:54:06 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-17 12:54:06 --> Controller Class Initialized
INFO - 2024-09-17 12:54:12 --> Config Class Initialized
INFO - 2024-09-17 12:54:12 --> Hooks Class Initialized
DEBUG - 2024-09-17 12:54:12 --> UTF-8 Support Enabled
INFO - 2024-09-17 12:54:12 --> Utf8 Class Initialized
INFO - 2024-09-17 12:54:12 --> URI Class Initialized
INFO - 2024-09-17 12:54:12 --> Router Class Initialized
INFO - 2024-09-17 12:54:12 --> Output Class Initialized
INFO - 2024-09-17 12:54:12 --> Security Class Initialized
DEBUG - 2024-09-17 12:54:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-17 12:54:12 --> Input Class Initialized
INFO - 2024-09-17 12:54:12 --> Language Class Initialized
INFO - 2024-09-17 12:54:12 --> Language Class Initialized
INFO - 2024-09-17 12:54:12 --> Config Class Initialized
INFO - 2024-09-17 12:54:12 --> Loader Class Initialized
INFO - 2024-09-17 12:54:12 --> Helper loaded: url_helper
INFO - 2024-09-17 12:54:12 --> Helper loaded: file_helper
INFO - 2024-09-17 12:54:12 --> Helper loaded: form_helper
INFO - 2024-09-17 12:54:12 --> Helper loaded: my_helper
INFO - 2024-09-17 12:54:12 --> Database Driver Class Initialized
INFO - 2024-09-17 12:54:12 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-17 12:54:12 --> Controller Class Initialized
DEBUG - 2024-09-17 12:54:12 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/data_kelompok/views/list.php
DEBUG - 2024-09-17 12:54:12 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-09-17 12:54:12 --> Final output sent to browser
DEBUG - 2024-09-17 12:54:12 --> Total execution time: 0.0664
INFO - 2024-09-17 12:54:13 --> Config Class Initialized
INFO - 2024-09-17 12:54:13 --> Hooks Class Initialized
DEBUG - 2024-09-17 12:54:13 --> UTF-8 Support Enabled
INFO - 2024-09-17 12:54:13 --> Utf8 Class Initialized
INFO - 2024-09-17 12:54:13 --> URI Class Initialized
INFO - 2024-09-17 12:54:13 --> Router Class Initialized
INFO - 2024-09-17 12:54:13 --> Output Class Initialized
INFO - 2024-09-17 12:54:13 --> Security Class Initialized
DEBUG - 2024-09-17 12:54:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-17 12:54:13 --> Input Class Initialized
INFO - 2024-09-17 12:54:13 --> Language Class Initialized
ERROR - 2024-09-17 12:54:13 --> 404 Page Not Found: /index
INFO - 2024-09-17 12:54:13 --> Config Class Initialized
INFO - 2024-09-17 12:54:13 --> Hooks Class Initialized
DEBUG - 2024-09-17 12:54:13 --> UTF-8 Support Enabled
INFO - 2024-09-17 12:54:13 --> Utf8 Class Initialized
INFO - 2024-09-17 12:54:13 --> URI Class Initialized
INFO - 2024-09-17 12:54:13 --> Router Class Initialized
INFO - 2024-09-17 12:54:13 --> Output Class Initialized
INFO - 2024-09-17 12:54:13 --> Security Class Initialized
DEBUG - 2024-09-17 12:54:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-17 12:54:13 --> Input Class Initialized
INFO - 2024-09-17 12:54:13 --> Language Class Initialized
INFO - 2024-09-17 12:54:13 --> Language Class Initialized
INFO - 2024-09-17 12:54:13 --> Config Class Initialized
INFO - 2024-09-17 12:54:13 --> Loader Class Initialized
INFO - 2024-09-17 12:54:13 --> Helper loaded: url_helper
INFO - 2024-09-17 12:54:13 --> Helper loaded: file_helper
INFO - 2024-09-17 12:54:13 --> Helper loaded: form_helper
INFO - 2024-09-17 12:54:13 --> Helper loaded: my_helper
INFO - 2024-09-17 12:54:13 --> Database Driver Class Initialized
INFO - 2024-09-17 12:54:13 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-17 12:54:13 --> Controller Class Initialized
INFO - 2024-09-17 12:54:29 --> Config Class Initialized
INFO - 2024-09-17 12:54:29 --> Hooks Class Initialized
DEBUG - 2024-09-17 12:54:29 --> UTF-8 Support Enabled
INFO - 2024-09-17 12:54:29 --> Utf8 Class Initialized
INFO - 2024-09-17 12:54:29 --> URI Class Initialized
INFO - 2024-09-17 12:54:29 --> Router Class Initialized
INFO - 2024-09-17 12:54:29 --> Output Class Initialized
INFO - 2024-09-17 12:54:29 --> Security Class Initialized
DEBUG - 2024-09-17 12:54:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-17 12:54:29 --> Input Class Initialized
INFO - 2024-09-17 12:54:29 --> Language Class Initialized
INFO - 2024-09-17 12:54:29 --> Language Class Initialized
INFO - 2024-09-17 12:54:29 --> Config Class Initialized
INFO - 2024-09-17 12:54:29 --> Loader Class Initialized
INFO - 2024-09-17 12:54:29 --> Helper loaded: url_helper
INFO - 2024-09-17 12:54:29 --> Helper loaded: file_helper
INFO - 2024-09-17 12:54:29 --> Helper loaded: form_helper
INFO - 2024-09-17 12:54:29 --> Helper loaded: my_helper
INFO - 2024-09-17 12:54:29 --> Database Driver Class Initialized
INFO - 2024-09-17 12:54:29 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-17 12:54:29 --> Controller Class Initialized
DEBUG - 2024-09-17 12:54:29 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/data_guru/views/list.php
DEBUG - 2024-09-17 12:54:29 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-09-17 12:54:29 --> Final output sent to browser
DEBUG - 2024-09-17 12:54:29 --> Total execution time: 0.0333
INFO - 2024-09-17 12:54:29 --> Config Class Initialized
INFO - 2024-09-17 12:54:29 --> Hooks Class Initialized
DEBUG - 2024-09-17 12:54:29 --> UTF-8 Support Enabled
INFO - 2024-09-17 12:54:29 --> Utf8 Class Initialized
INFO - 2024-09-17 12:54:29 --> URI Class Initialized
INFO - 2024-09-17 12:54:29 --> Router Class Initialized
INFO - 2024-09-17 12:54:29 --> Output Class Initialized
INFO - 2024-09-17 12:54:29 --> Security Class Initialized
DEBUG - 2024-09-17 12:54:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-17 12:54:29 --> Input Class Initialized
INFO - 2024-09-17 12:54:29 --> Language Class Initialized
ERROR - 2024-09-17 12:54:29 --> 404 Page Not Found: /index
INFO - 2024-09-17 12:54:29 --> Config Class Initialized
INFO - 2024-09-17 12:54:29 --> Hooks Class Initialized
DEBUG - 2024-09-17 12:54:29 --> UTF-8 Support Enabled
INFO - 2024-09-17 12:54:29 --> Utf8 Class Initialized
INFO - 2024-09-17 12:54:29 --> URI Class Initialized
INFO - 2024-09-17 12:54:29 --> Router Class Initialized
INFO - 2024-09-17 12:54:29 --> Output Class Initialized
INFO - 2024-09-17 12:54:29 --> Security Class Initialized
DEBUG - 2024-09-17 12:54:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-17 12:54:29 --> Input Class Initialized
INFO - 2024-09-17 12:54:29 --> Language Class Initialized
INFO - 2024-09-17 12:54:29 --> Language Class Initialized
INFO - 2024-09-17 12:54:29 --> Config Class Initialized
INFO - 2024-09-17 12:54:29 --> Loader Class Initialized
INFO - 2024-09-17 12:54:29 --> Helper loaded: url_helper
INFO - 2024-09-17 12:54:29 --> Helper loaded: file_helper
INFO - 2024-09-17 12:54:29 --> Helper loaded: form_helper
INFO - 2024-09-17 12:54:29 --> Helper loaded: my_helper
INFO - 2024-09-17 12:54:29 --> Database Driver Class Initialized
INFO - 2024-09-17 12:54:29 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-17 12:54:29 --> Controller Class Initialized
INFO - 2024-09-17 12:54:41 --> Config Class Initialized
INFO - 2024-09-17 12:54:41 --> Hooks Class Initialized
DEBUG - 2024-09-17 12:54:41 --> UTF-8 Support Enabled
INFO - 2024-09-17 12:54:41 --> Utf8 Class Initialized
INFO - 2024-09-17 12:54:41 --> URI Class Initialized
INFO - 2024-09-17 12:54:41 --> Router Class Initialized
INFO - 2024-09-17 12:54:41 --> Output Class Initialized
INFO - 2024-09-17 12:54:41 --> Security Class Initialized
DEBUG - 2024-09-17 12:54:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-17 12:54:41 --> Input Class Initialized
INFO - 2024-09-17 12:54:41 --> Language Class Initialized
INFO - 2024-09-17 12:54:41 --> Language Class Initialized
INFO - 2024-09-17 12:54:41 --> Config Class Initialized
INFO - 2024-09-17 12:54:41 --> Loader Class Initialized
INFO - 2024-09-17 12:54:41 --> Helper loaded: url_helper
INFO - 2024-09-17 12:54:41 --> Helper loaded: file_helper
INFO - 2024-09-17 12:54:41 --> Helper loaded: form_helper
INFO - 2024-09-17 12:54:41 --> Helper loaded: my_helper
INFO - 2024-09-17 12:54:41 --> Database Driver Class Initialized
INFO - 2024-09-17 12:54:41 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-17 12:54:41 --> Controller Class Initialized
DEBUG - 2024-09-17 12:54:41 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/data_siswa/views/list.php
DEBUG - 2024-09-17 12:54:41 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-09-17 12:54:41 --> Final output sent to browser
DEBUG - 2024-09-17 12:54:41 --> Total execution time: 0.0262
INFO - 2024-09-17 12:54:42 --> Config Class Initialized
INFO - 2024-09-17 12:54:42 --> Hooks Class Initialized
DEBUG - 2024-09-17 12:54:42 --> UTF-8 Support Enabled
INFO - 2024-09-17 12:54:42 --> Utf8 Class Initialized
INFO - 2024-09-17 12:54:42 --> URI Class Initialized
INFO - 2024-09-17 12:54:42 --> Router Class Initialized
INFO - 2024-09-17 12:54:42 --> Output Class Initialized
INFO - 2024-09-17 12:54:42 --> Security Class Initialized
DEBUG - 2024-09-17 12:54:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-17 12:54:42 --> Input Class Initialized
INFO - 2024-09-17 12:54:42 --> Language Class Initialized
ERROR - 2024-09-17 12:54:42 --> 404 Page Not Found: /index
INFO - 2024-09-17 12:54:42 --> Config Class Initialized
INFO - 2024-09-17 12:54:42 --> Hooks Class Initialized
DEBUG - 2024-09-17 12:54:42 --> UTF-8 Support Enabled
INFO - 2024-09-17 12:54:42 --> Utf8 Class Initialized
INFO - 2024-09-17 12:54:42 --> URI Class Initialized
INFO - 2024-09-17 12:54:42 --> Router Class Initialized
INFO - 2024-09-17 12:54:42 --> Output Class Initialized
INFO - 2024-09-17 12:54:42 --> Security Class Initialized
DEBUG - 2024-09-17 12:54:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-17 12:54:42 --> Input Class Initialized
INFO - 2024-09-17 12:54:42 --> Language Class Initialized
INFO - 2024-09-17 12:54:42 --> Language Class Initialized
INFO - 2024-09-17 12:54:42 --> Config Class Initialized
INFO - 2024-09-17 12:54:42 --> Loader Class Initialized
INFO - 2024-09-17 12:54:42 --> Helper loaded: url_helper
INFO - 2024-09-17 12:54:42 --> Helper loaded: file_helper
INFO - 2024-09-17 12:54:42 --> Helper loaded: form_helper
INFO - 2024-09-17 12:54:42 --> Helper loaded: my_helper
INFO - 2024-09-17 12:54:42 --> Database Driver Class Initialized
INFO - 2024-09-17 12:54:42 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-17 12:54:42 --> Controller Class Initialized
INFO - 2024-09-17 12:54:48 --> Config Class Initialized
INFO - 2024-09-17 12:54:48 --> Hooks Class Initialized
DEBUG - 2024-09-17 12:54:48 --> UTF-8 Support Enabled
INFO - 2024-09-17 12:54:48 --> Utf8 Class Initialized
INFO - 2024-09-17 12:54:48 --> URI Class Initialized
INFO - 2024-09-17 12:54:48 --> Router Class Initialized
INFO - 2024-09-17 12:54:48 --> Output Class Initialized
INFO - 2024-09-17 12:54:48 --> Security Class Initialized
DEBUG - 2024-09-17 12:54:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-17 12:54:48 --> Input Class Initialized
INFO - 2024-09-17 12:54:48 --> Language Class Initialized
INFO - 2024-09-17 12:54:48 --> Language Class Initialized
INFO - 2024-09-17 12:54:48 --> Config Class Initialized
INFO - 2024-09-17 12:54:48 --> Loader Class Initialized
INFO - 2024-09-17 12:54:48 --> Helper loaded: url_helper
INFO - 2024-09-17 12:54:48 --> Helper loaded: file_helper
INFO - 2024-09-17 12:54:48 --> Helper loaded: form_helper
INFO - 2024-09-17 12:54:48 --> Helper loaded: my_helper
INFO - 2024-09-17 12:54:48 --> Database Driver Class Initialized
INFO - 2024-09-17 12:54:48 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-17 12:54:48 --> Controller Class Initialized
INFO - 2024-09-17 14:33:48 --> Config Class Initialized
INFO - 2024-09-17 14:33:48 --> Hooks Class Initialized
DEBUG - 2024-09-17 14:33:48 --> UTF-8 Support Enabled
INFO - 2024-09-17 14:33:48 --> Utf8 Class Initialized
INFO - 2024-09-17 14:33:48 --> URI Class Initialized
INFO - 2024-09-17 14:33:48 --> Router Class Initialized
INFO - 2024-09-17 14:33:48 --> Output Class Initialized
INFO - 2024-09-17 14:33:48 --> Security Class Initialized
DEBUG - 2024-09-17 14:33:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-17 14:33:48 --> Input Class Initialized
INFO - 2024-09-17 14:33:48 --> Language Class Initialized
INFO - 2024-09-17 14:33:48 --> Language Class Initialized
INFO - 2024-09-17 14:33:48 --> Config Class Initialized
INFO - 2024-09-17 14:33:48 --> Loader Class Initialized
INFO - 2024-09-17 14:33:48 --> Helper loaded: url_helper
INFO - 2024-09-17 14:33:48 --> Helper loaded: file_helper
INFO - 2024-09-17 14:33:48 --> Helper loaded: form_helper
INFO - 2024-09-17 14:33:48 --> Helper loaded: my_helper
INFO - 2024-09-17 14:33:48 --> Database Driver Class Initialized
INFO - 2024-09-17 14:33:48 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-17 14:33:48 --> Controller Class Initialized
DEBUG - 2024-09-17 14:33:48 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/login/views/login.php
DEBUG - 2024-09-17 14:33:48 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-09-17 14:33:48 --> Final output sent to browser
DEBUG - 2024-09-17 14:33:48 --> Total execution time: 0.0577
INFO - 2024-09-17 14:33:49 --> Config Class Initialized
INFO - 2024-09-17 14:33:49 --> Hooks Class Initialized
DEBUG - 2024-09-17 14:33:49 --> UTF-8 Support Enabled
INFO - 2024-09-17 14:33:49 --> Utf8 Class Initialized
INFO - 2024-09-17 14:33:49 --> URI Class Initialized
INFO - 2024-09-17 14:33:49 --> Router Class Initialized
INFO - 2024-09-17 14:33:49 --> Output Class Initialized
INFO - 2024-09-17 14:33:49 --> Security Class Initialized
DEBUG - 2024-09-17 14:33:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-17 14:33:49 --> Input Class Initialized
INFO - 2024-09-17 14:33:49 --> Language Class Initialized
INFO - 2024-09-17 14:33:49 --> Language Class Initialized
INFO - 2024-09-17 14:33:49 --> Config Class Initialized
INFO - 2024-09-17 14:33:49 --> Loader Class Initialized
INFO - 2024-09-17 14:33:49 --> Helper loaded: url_helper
INFO - 2024-09-17 14:33:49 --> Helper loaded: file_helper
INFO - 2024-09-17 14:33:49 --> Helper loaded: form_helper
INFO - 2024-09-17 14:33:49 --> Helper loaded: my_helper
INFO - 2024-09-17 14:33:49 --> Database Driver Class Initialized
INFO - 2024-09-17 14:33:49 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-17 14:33:49 --> Controller Class Initialized
DEBUG - 2024-09-17 14:33:49 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/login/views/login.php
DEBUG - 2024-09-17 14:33:49 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-09-17 14:33:49 --> Final output sent to browser
DEBUG - 2024-09-17 14:33:49 --> Total execution time: 0.0330
INFO - 2024-09-17 14:39:05 --> Config Class Initialized
INFO - 2024-09-17 14:39:05 --> Hooks Class Initialized
DEBUG - 2024-09-17 14:39:05 --> UTF-8 Support Enabled
INFO - 2024-09-17 14:39:05 --> Utf8 Class Initialized
INFO - 2024-09-17 14:39:05 --> URI Class Initialized
INFO - 2024-09-17 14:39:05 --> Router Class Initialized
INFO - 2024-09-17 14:39:05 --> Output Class Initialized
INFO - 2024-09-17 14:39:05 --> Security Class Initialized
DEBUG - 2024-09-17 14:39:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-17 14:39:05 --> Input Class Initialized
INFO - 2024-09-17 14:39:05 --> Language Class Initialized
INFO - 2024-09-17 14:39:05 --> Language Class Initialized
INFO - 2024-09-17 14:39:05 --> Config Class Initialized
INFO - 2024-09-17 14:39:05 --> Loader Class Initialized
INFO - 2024-09-17 14:39:05 --> Helper loaded: url_helper
INFO - 2024-09-17 14:39:05 --> Helper loaded: file_helper
INFO - 2024-09-17 14:39:05 --> Helper loaded: form_helper
INFO - 2024-09-17 14:39:05 --> Helper loaded: my_helper
INFO - 2024-09-17 14:39:05 --> Database Driver Class Initialized
INFO - 2024-09-17 14:39:05 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-17 14:39:05 --> Controller Class Initialized
DEBUG - 2024-09-17 14:39:05 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/login/views/login.php
DEBUG - 2024-09-17 14:39:05 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-09-17 14:39:05 --> Final output sent to browser
DEBUG - 2024-09-17 14:39:05 --> Total execution time: 0.0356
INFO - 2024-09-17 14:39:23 --> Config Class Initialized
INFO - 2024-09-17 14:39:23 --> Hooks Class Initialized
DEBUG - 2024-09-17 14:39:23 --> UTF-8 Support Enabled
INFO - 2024-09-17 14:39:23 --> Utf8 Class Initialized
INFO - 2024-09-17 14:39:23 --> URI Class Initialized
INFO - 2024-09-17 14:39:23 --> Router Class Initialized
INFO - 2024-09-17 14:39:23 --> Output Class Initialized
INFO - 2024-09-17 14:39:23 --> Security Class Initialized
DEBUG - 2024-09-17 14:39:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-17 14:39:23 --> Input Class Initialized
INFO - 2024-09-17 14:39:23 --> Language Class Initialized
INFO - 2024-09-17 14:39:23 --> Language Class Initialized
INFO - 2024-09-17 14:39:23 --> Config Class Initialized
INFO - 2024-09-17 14:39:23 --> Loader Class Initialized
INFO - 2024-09-17 14:39:23 --> Helper loaded: url_helper
INFO - 2024-09-17 14:39:23 --> Helper loaded: file_helper
INFO - 2024-09-17 14:39:23 --> Helper loaded: form_helper
INFO - 2024-09-17 14:39:23 --> Helper loaded: my_helper
INFO - 2024-09-17 14:39:23 --> Database Driver Class Initialized
INFO - 2024-09-17 14:39:23 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-17 14:39:23 --> Controller Class Initialized
INFO - 2024-09-17 14:39:23 --> Helper loaded: cookie_helper
INFO - 2024-09-17 14:39:23 --> Final output sent to browser
DEBUG - 2024-09-17 14:39:23 --> Total execution time: 0.0381
INFO - 2024-09-17 14:39:23 --> Config Class Initialized
INFO - 2024-09-17 14:39:23 --> Hooks Class Initialized
DEBUG - 2024-09-17 14:39:23 --> UTF-8 Support Enabled
INFO - 2024-09-17 14:39:23 --> Utf8 Class Initialized
INFO - 2024-09-17 14:39:23 --> URI Class Initialized
INFO - 2024-09-17 14:39:23 --> Router Class Initialized
INFO - 2024-09-17 14:39:23 --> Output Class Initialized
INFO - 2024-09-17 14:39:23 --> Security Class Initialized
DEBUG - 2024-09-17 14:39:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-17 14:39:23 --> Input Class Initialized
INFO - 2024-09-17 14:39:23 --> Language Class Initialized
INFO - 2024-09-17 14:39:23 --> Language Class Initialized
INFO - 2024-09-17 14:39:23 --> Config Class Initialized
INFO - 2024-09-17 14:39:23 --> Loader Class Initialized
INFO - 2024-09-17 14:39:23 --> Helper loaded: url_helper
INFO - 2024-09-17 14:39:23 --> Helper loaded: file_helper
INFO - 2024-09-17 14:39:23 --> Helper loaded: form_helper
INFO - 2024-09-17 14:39:23 --> Helper loaded: my_helper
INFO - 2024-09-17 14:39:23 --> Database Driver Class Initialized
INFO - 2024-09-17 14:39:23 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-17 14:39:23 --> Controller Class Initialized
DEBUG - 2024-09-17 14:39:23 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/home/views/v_home_guru.php
DEBUG - 2024-09-17 14:39:23 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-09-17 14:39:23 --> Final output sent to browser
DEBUG - 2024-09-17 14:39:23 --> Total execution time: 0.0436
INFO - 2024-09-17 14:39:38 --> Config Class Initialized
INFO - 2024-09-17 14:39:38 --> Hooks Class Initialized
DEBUG - 2024-09-17 14:39:38 --> UTF-8 Support Enabled
INFO - 2024-09-17 14:39:38 --> Utf8 Class Initialized
INFO - 2024-09-17 14:39:38 --> URI Class Initialized
DEBUG - 2024-09-17 14:39:38 --> No URI present. Default controller set.
INFO - 2024-09-17 14:39:38 --> Router Class Initialized
INFO - 2024-09-17 14:39:38 --> Output Class Initialized
INFO - 2024-09-17 14:39:38 --> Security Class Initialized
DEBUG - 2024-09-17 14:39:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-17 14:39:38 --> Input Class Initialized
INFO - 2024-09-17 14:39:38 --> Language Class Initialized
INFO - 2024-09-17 14:39:38 --> Language Class Initialized
INFO - 2024-09-17 14:39:38 --> Config Class Initialized
INFO - 2024-09-17 14:39:38 --> Loader Class Initialized
INFO - 2024-09-17 14:39:38 --> Helper loaded: url_helper
INFO - 2024-09-17 14:39:38 --> Helper loaded: file_helper
INFO - 2024-09-17 14:39:38 --> Helper loaded: form_helper
INFO - 2024-09-17 14:39:38 --> Helper loaded: my_helper
INFO - 2024-09-17 14:39:39 --> Database Driver Class Initialized
INFO - 2024-09-17 14:39:39 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-17 14:39:39 --> Controller Class Initialized
DEBUG - 2024-09-17 14:39:39 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/home/views/v_home_guru.php
DEBUG - 2024-09-17 14:39:39 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-09-17 14:39:39 --> Final output sent to browser
DEBUG - 2024-09-17 14:39:39 --> Total execution time: 0.0309
INFO - 2024-09-17 16:02:57 --> Config Class Initialized
INFO - 2024-09-17 16:02:57 --> Hooks Class Initialized
DEBUG - 2024-09-17 16:02:57 --> UTF-8 Support Enabled
INFO - 2024-09-17 16:02:57 --> Utf8 Class Initialized
INFO - 2024-09-17 16:02:57 --> URI Class Initialized
INFO - 2024-09-17 16:02:57 --> Router Class Initialized
INFO - 2024-09-17 16:02:57 --> Output Class Initialized
INFO - 2024-09-17 16:02:57 --> Security Class Initialized
DEBUG - 2024-09-17 16:02:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-17 16:02:57 --> Input Class Initialized
INFO - 2024-09-17 16:02:57 --> Language Class Initialized
INFO - 2024-09-17 16:02:57 --> Language Class Initialized
INFO - 2024-09-17 16:02:57 --> Config Class Initialized
INFO - 2024-09-17 16:02:57 --> Loader Class Initialized
INFO - 2024-09-17 16:02:57 --> Helper loaded: url_helper
INFO - 2024-09-17 16:02:57 --> Helper loaded: file_helper
INFO - 2024-09-17 16:02:57 --> Helper loaded: form_helper
INFO - 2024-09-17 16:02:57 --> Helper loaded: my_helper
INFO - 2024-09-17 16:02:57 --> Database Driver Class Initialized
INFO - 2024-09-17 16:02:57 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-17 16:02:57 --> Controller Class Initialized
INFO - 2024-09-17 16:02:57 --> Helper loaded: cookie_helper
INFO - 2024-09-17 16:02:57 --> Final output sent to browser
DEBUG - 2024-09-17 16:02:57 --> Total execution time: 0.0644
INFO - 2024-09-17 16:02:57 --> Config Class Initialized
INFO - 2024-09-17 16:02:57 --> Hooks Class Initialized
DEBUG - 2024-09-17 16:02:57 --> UTF-8 Support Enabled
INFO - 2024-09-17 16:02:57 --> Utf8 Class Initialized
INFO - 2024-09-17 16:02:57 --> URI Class Initialized
INFO - 2024-09-17 16:02:57 --> Router Class Initialized
INFO - 2024-09-17 16:02:57 --> Output Class Initialized
INFO - 2024-09-17 16:02:57 --> Security Class Initialized
DEBUG - 2024-09-17 16:02:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-17 16:02:57 --> Input Class Initialized
INFO - 2024-09-17 16:02:57 --> Language Class Initialized
INFO - 2024-09-17 16:02:57 --> Language Class Initialized
INFO - 2024-09-17 16:02:57 --> Config Class Initialized
INFO - 2024-09-17 16:02:57 --> Loader Class Initialized
INFO - 2024-09-17 16:02:57 --> Helper loaded: url_helper
INFO - 2024-09-17 16:02:57 --> Helper loaded: file_helper
INFO - 2024-09-17 16:02:57 --> Helper loaded: form_helper
INFO - 2024-09-17 16:02:57 --> Helper loaded: my_helper
INFO - 2024-09-17 16:02:57 --> Database Driver Class Initialized
INFO - 2024-09-17 16:02:57 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-17 16:02:57 --> Controller Class Initialized
INFO - 2024-09-17 16:02:57 --> Helper loaded: cookie_helper
INFO - 2024-09-17 16:02:57 --> Config Class Initialized
INFO - 2024-09-17 16:02:57 --> Hooks Class Initialized
DEBUG - 2024-09-17 16:02:57 --> UTF-8 Support Enabled
INFO - 2024-09-17 16:02:57 --> Utf8 Class Initialized
INFO - 2024-09-17 16:02:57 --> URI Class Initialized
INFO - 2024-09-17 16:02:57 --> Router Class Initialized
INFO - 2024-09-17 16:02:57 --> Output Class Initialized
INFO - 2024-09-17 16:02:57 --> Security Class Initialized
DEBUG - 2024-09-17 16:02:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-17 16:02:57 --> Input Class Initialized
INFO - 2024-09-17 16:02:57 --> Language Class Initialized
INFO - 2024-09-17 16:02:57 --> Language Class Initialized
INFO - 2024-09-17 16:02:57 --> Config Class Initialized
INFO - 2024-09-17 16:02:57 --> Loader Class Initialized
INFO - 2024-09-17 16:02:57 --> Helper loaded: url_helper
INFO - 2024-09-17 16:02:57 --> Helper loaded: file_helper
INFO - 2024-09-17 16:02:57 --> Helper loaded: form_helper
INFO - 2024-09-17 16:02:57 --> Helper loaded: my_helper
INFO - 2024-09-17 16:02:57 --> Database Driver Class Initialized
INFO - 2024-09-17 16:02:57 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-17 16:02:57 --> Controller Class Initialized
DEBUG - 2024-09-17 16:02:57 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/lihat_raport/views/list.php
DEBUG - 2024-09-17 16:02:57 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-09-17 16:02:57 --> Final output sent to browser
DEBUG - 2024-09-17 16:02:57 --> Total execution time: 0.0453
INFO - 2024-09-17 23:14:59 --> Config Class Initialized
INFO - 2024-09-17 23:14:59 --> Hooks Class Initialized
DEBUG - 2024-09-17 23:14:59 --> UTF-8 Support Enabled
INFO - 2024-09-17 23:14:59 --> Utf8 Class Initialized
INFO - 2024-09-17 23:14:59 --> URI Class Initialized
INFO - 2024-09-17 23:14:59 --> Router Class Initialized
INFO - 2024-09-17 23:14:59 --> Output Class Initialized
INFO - 2024-09-17 23:14:59 --> Security Class Initialized
DEBUG - 2024-09-17 23:14:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-17 23:14:59 --> Input Class Initialized
INFO - 2024-09-17 23:14:59 --> Language Class Initialized
INFO - 2024-09-17 23:14:59 --> Language Class Initialized
INFO - 2024-09-17 23:14:59 --> Config Class Initialized
INFO - 2024-09-17 23:14:59 --> Loader Class Initialized
INFO - 2024-09-17 23:14:59 --> Helper loaded: url_helper
INFO - 2024-09-17 23:14:59 --> Helper loaded: file_helper
INFO - 2024-09-17 23:14:59 --> Helper loaded: form_helper
INFO - 2024-09-17 23:14:59 --> Helper loaded: my_helper
INFO - 2024-09-17 23:14:59 --> Database Driver Class Initialized
INFO - 2024-09-17 23:14:59 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-17 23:14:59 --> Controller Class Initialized
INFO - 2024-09-17 23:14:59 --> Helper loaded: cookie_helper
INFO - 2024-09-17 23:14:59 --> Final output sent to browser
DEBUG - 2024-09-17 23:14:59 --> Total execution time: 0.0827
INFO - 2024-09-17 23:15:00 --> Config Class Initialized
INFO - 2024-09-17 23:15:00 --> Hooks Class Initialized
DEBUG - 2024-09-17 23:15:00 --> UTF-8 Support Enabled
INFO - 2024-09-17 23:15:00 --> Utf8 Class Initialized
INFO - 2024-09-17 23:15:00 --> URI Class Initialized
INFO - 2024-09-17 23:15:00 --> Router Class Initialized
INFO - 2024-09-17 23:15:00 --> Output Class Initialized
INFO - 2024-09-17 23:15:00 --> Security Class Initialized
DEBUG - 2024-09-17 23:15:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-17 23:15:00 --> Input Class Initialized
INFO - 2024-09-17 23:15:00 --> Language Class Initialized
INFO - 2024-09-17 23:15:00 --> Language Class Initialized
INFO - 2024-09-17 23:15:00 --> Config Class Initialized
INFO - 2024-09-17 23:15:00 --> Loader Class Initialized
INFO - 2024-09-17 23:15:00 --> Helper loaded: url_helper
INFO - 2024-09-17 23:15:00 --> Helper loaded: file_helper
INFO - 2024-09-17 23:15:00 --> Helper loaded: form_helper
INFO - 2024-09-17 23:15:00 --> Helper loaded: my_helper
INFO - 2024-09-17 23:15:00 --> Database Driver Class Initialized
INFO - 2024-09-17 23:15:00 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-17 23:15:00 --> Controller Class Initialized
INFO - 2024-09-17 23:15:00 --> Helper loaded: cookie_helper
INFO - 2024-09-17 23:15:00 --> Config Class Initialized
INFO - 2024-09-17 23:15:00 --> Hooks Class Initialized
DEBUG - 2024-09-17 23:15:00 --> UTF-8 Support Enabled
INFO - 2024-09-17 23:15:00 --> Utf8 Class Initialized
INFO - 2024-09-17 23:15:00 --> URI Class Initialized
INFO - 2024-09-17 23:15:00 --> Router Class Initialized
INFO - 2024-09-17 23:15:00 --> Output Class Initialized
INFO - 2024-09-17 23:15:00 --> Security Class Initialized
DEBUG - 2024-09-17 23:15:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-17 23:15:00 --> Input Class Initialized
INFO - 2024-09-17 23:15:00 --> Language Class Initialized
INFO - 2024-09-17 23:15:00 --> Language Class Initialized
INFO - 2024-09-17 23:15:00 --> Config Class Initialized
INFO - 2024-09-17 23:15:00 --> Loader Class Initialized
INFO - 2024-09-17 23:15:00 --> Helper loaded: url_helper
INFO - 2024-09-17 23:15:00 --> Helper loaded: file_helper
INFO - 2024-09-17 23:15:00 --> Helper loaded: form_helper
INFO - 2024-09-17 23:15:00 --> Helper loaded: my_helper
INFO - 2024-09-17 23:15:00 --> Database Driver Class Initialized
INFO - 2024-09-17 23:15:00 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-17 23:15:00 --> Controller Class Initialized
DEBUG - 2024-09-17 23:15:00 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/lihat_raport/views/list.php
DEBUG - 2024-09-17 23:15:00 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-09-17 23:15:00 --> Final output sent to browser
DEBUG - 2024-09-17 23:15:00 --> Total execution time: 0.0389
INFO - 2024-09-17 23:15:04 --> Config Class Initialized
INFO - 2024-09-17 23:15:04 --> Hooks Class Initialized
DEBUG - 2024-09-17 23:15:04 --> UTF-8 Support Enabled
INFO - 2024-09-17 23:15:04 --> Utf8 Class Initialized
INFO - 2024-09-17 23:15:04 --> URI Class Initialized
INFO - 2024-09-17 23:15:04 --> Router Class Initialized
INFO - 2024-09-17 23:15:04 --> Output Class Initialized
INFO - 2024-09-17 23:15:04 --> Security Class Initialized
DEBUG - 2024-09-17 23:15:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-17 23:15:04 --> Input Class Initialized
INFO - 2024-09-17 23:15:04 --> Language Class Initialized
INFO - 2024-09-17 23:15:04 --> Language Class Initialized
INFO - 2024-09-17 23:15:04 --> Config Class Initialized
INFO - 2024-09-17 23:15:04 --> Loader Class Initialized
INFO - 2024-09-17 23:15:04 --> Helper loaded: url_helper
INFO - 2024-09-17 23:15:04 --> Helper loaded: file_helper
INFO - 2024-09-17 23:15:04 --> Helper loaded: form_helper
INFO - 2024-09-17 23:15:04 --> Helper loaded: my_helper
INFO - 2024-09-17 23:15:04 --> Database Driver Class Initialized
INFO - 2024-09-17 23:15:04 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-17 23:15:04 --> Controller Class Initialized
ERROR - 2024-09-17 23:15:04 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1160
ERROR - 2024-09-17 23:15:04 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1692
ERROR - 2024-09-17 23:15:04 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1729
ERROR - 2024-09-17 23:15:04 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1767
ERROR - 2024-09-17 23:15:04 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1806
ERROR - 2024-09-17 23:15:04 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1883
ERROR - 2024-09-17 23:15:04 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1962
ERROR - 2024-09-17 23:15:04 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 2042
ERROR - 2024-09-17 23:15:04 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 2122
ERROR - 2024-09-17 23:15:04 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 2202
ERROR - 2024-09-17 23:15:04 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 2277
ERROR - 2024-09-17 23:15:04 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php 32
ERROR - 2024-09-17 23:15:04 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php 32
DEBUG - 2024-09-17 23:15:04 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php
INFO - 2024-09-17 23:15:07 --> Final output sent to browser
DEBUG - 2024-09-17 23:15:07 --> Total execution time: 2.9056
INFO - 2024-09-17 23:15:07 --> Config Class Initialized
INFO - 2024-09-17 23:15:07 --> Hooks Class Initialized
DEBUG - 2024-09-17 23:15:07 --> UTF-8 Support Enabled
INFO - 2024-09-17 23:15:07 --> Utf8 Class Initialized
INFO - 2024-09-17 23:15:07 --> URI Class Initialized
INFO - 2024-09-17 23:15:07 --> Router Class Initialized
INFO - 2024-09-17 23:15:07 --> Output Class Initialized
INFO - 2024-09-17 23:15:07 --> Security Class Initialized
DEBUG - 2024-09-17 23:15:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-17 23:15:07 --> Input Class Initialized
INFO - 2024-09-17 23:15:07 --> Language Class Initialized
INFO - 2024-09-17 23:15:07 --> Language Class Initialized
INFO - 2024-09-17 23:15:07 --> Config Class Initialized
INFO - 2024-09-17 23:15:07 --> Loader Class Initialized
INFO - 2024-09-17 23:15:07 --> Helper loaded: url_helper
INFO - 2024-09-17 23:15:07 --> Helper loaded: file_helper
INFO - 2024-09-17 23:15:07 --> Helper loaded: form_helper
INFO - 2024-09-17 23:15:07 --> Helper loaded: my_helper
INFO - 2024-09-17 23:15:07 --> Database Driver Class Initialized
INFO - 2024-09-17 23:15:07 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-17 23:15:07 --> Controller Class Initialized
ERROR - 2024-09-17 23:15:07 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1160
ERROR - 2024-09-17 23:15:07 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1692
ERROR - 2024-09-17 23:15:07 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1729
ERROR - 2024-09-17 23:15:07 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1767
ERROR - 2024-09-17 23:15:07 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1806
ERROR - 2024-09-17 23:15:07 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1883
ERROR - 2024-09-17 23:15:07 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1962
ERROR - 2024-09-17 23:15:07 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 2042
ERROR - 2024-09-17 23:15:07 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 2122
ERROR - 2024-09-17 23:15:07 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 2202
ERROR - 2024-09-17 23:15:07 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 2277
ERROR - 2024-09-17 23:15:07 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php 32
ERROR - 2024-09-17 23:15:07 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php 32
DEBUG - 2024-09-17 23:15:07 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php
INFO - 2024-09-17 23:15:10 --> Final output sent to browser
DEBUG - 2024-09-17 23:15:10 --> Total execution time: 2.6580
INFO - 2024-09-17 23:15:10 --> Config Class Initialized
INFO - 2024-09-17 23:15:10 --> Hooks Class Initialized
DEBUG - 2024-09-17 23:15:10 --> UTF-8 Support Enabled
INFO - 2024-09-17 23:15:10 --> Utf8 Class Initialized
INFO - 2024-09-17 23:15:10 --> URI Class Initialized
INFO - 2024-09-17 23:15:10 --> Router Class Initialized
INFO - 2024-09-17 23:15:10 --> Output Class Initialized
INFO - 2024-09-17 23:15:10 --> Security Class Initialized
DEBUG - 2024-09-17 23:15:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-17 23:15:10 --> Input Class Initialized
INFO - 2024-09-17 23:15:10 --> Language Class Initialized
INFO - 2024-09-17 23:15:10 --> Language Class Initialized
INFO - 2024-09-17 23:15:10 --> Config Class Initialized
INFO - 2024-09-17 23:15:10 --> Loader Class Initialized
INFO - 2024-09-17 23:15:10 --> Helper loaded: url_helper
INFO - 2024-09-17 23:15:10 --> Helper loaded: file_helper
INFO - 2024-09-17 23:15:10 --> Helper loaded: form_helper
INFO - 2024-09-17 23:15:10 --> Helper loaded: my_helper
INFO - 2024-09-17 23:15:10 --> Database Driver Class Initialized
INFO - 2024-09-17 23:15:10 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-17 23:15:10 --> Controller Class Initialized
ERROR - 2024-09-17 23:15:10 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1160
ERROR - 2024-09-17 23:15:10 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1692
ERROR - 2024-09-17 23:15:10 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1729
ERROR - 2024-09-17 23:15:10 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1767
ERROR - 2024-09-17 23:15:10 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1806
ERROR - 2024-09-17 23:15:10 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1883
ERROR - 2024-09-17 23:15:10 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1962
ERROR - 2024-09-17 23:15:10 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 2042
ERROR - 2024-09-17 23:15:10 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 2122
ERROR - 2024-09-17 23:15:10 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 2202
ERROR - 2024-09-17 23:15:10 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 2277
ERROR - 2024-09-17 23:15:10 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php 32
ERROR - 2024-09-17 23:15:10 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php 32
DEBUG - 2024-09-17 23:15:10 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php
INFO - 2024-09-17 23:15:13 --> Final output sent to browser
DEBUG - 2024-09-17 23:15:13 --> Total execution time: 2.7382
