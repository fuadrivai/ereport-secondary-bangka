<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2024-09-07 05:05:12 --> Config Class Initialized
INFO - 2024-09-07 05:05:12 --> Hooks Class Initialized
DEBUG - 2024-09-07 05:05:12 --> UTF-8 Support Enabled
INFO - 2024-09-07 05:05:12 --> Utf8 Class Initialized
INFO - 2024-09-07 05:05:12 --> URI Class Initialized
INFO - 2024-09-07 05:05:12 --> Router Class Initialized
INFO - 2024-09-07 05:05:12 --> Output Class Initialized
INFO - 2024-09-07 05:05:12 --> Security Class Initialized
DEBUG - 2024-09-07 05:05:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-07 05:05:12 --> Input Class Initialized
INFO - 2024-09-07 05:05:12 --> Language Class Initialized
INFO - 2024-09-07 05:05:12 --> Language Class Initialized
INFO - 2024-09-07 05:05:12 --> Config Class Initialized
INFO - 2024-09-07 05:05:12 --> Loader Class Initialized
INFO - 2024-09-07 05:05:12 --> Helper loaded: url_helper
INFO - 2024-09-07 05:05:12 --> Helper loaded: file_helper
INFO - 2024-09-07 05:05:12 --> Helper loaded: form_helper
INFO - 2024-09-07 05:05:12 --> Helper loaded: my_helper
INFO - 2024-09-07 05:05:12 --> Database Driver Class Initialized
INFO - 2024-09-07 05:05:12 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-07 05:05:12 --> Controller Class Initialized
INFO - 2024-09-07 05:05:12 --> Helper loaded: cookie_helper
INFO - 2024-09-07 05:05:12 --> Final output sent to browser
DEBUG - 2024-09-07 05:05:12 --> Total execution time: 0.0712
INFO - 2024-09-07 05:05:13 --> Config Class Initialized
INFO - 2024-09-07 05:05:13 --> Hooks Class Initialized
DEBUG - 2024-09-07 05:05:13 --> UTF-8 Support Enabled
INFO - 2024-09-07 05:05:13 --> Utf8 Class Initialized
INFO - 2024-09-07 05:05:13 --> URI Class Initialized
INFO - 2024-09-07 05:05:13 --> Router Class Initialized
INFO - 2024-09-07 05:05:13 --> Output Class Initialized
INFO - 2024-09-07 05:05:13 --> Security Class Initialized
DEBUG - 2024-09-07 05:05:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-07 05:05:13 --> Input Class Initialized
INFO - 2024-09-07 05:05:13 --> Language Class Initialized
INFO - 2024-09-07 05:05:13 --> Language Class Initialized
INFO - 2024-09-07 05:05:13 --> Config Class Initialized
INFO - 2024-09-07 05:05:13 --> Loader Class Initialized
INFO - 2024-09-07 05:05:13 --> Helper loaded: url_helper
INFO - 2024-09-07 05:05:13 --> Helper loaded: file_helper
INFO - 2024-09-07 05:05:13 --> Helper loaded: form_helper
INFO - 2024-09-07 05:05:13 --> Helper loaded: my_helper
INFO - 2024-09-07 05:05:13 --> Database Driver Class Initialized
INFO - 2024-09-07 05:05:13 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-07 05:05:13 --> Controller Class Initialized
INFO - 2024-09-07 05:05:13 --> Helper loaded: cookie_helper
INFO - 2024-09-07 05:05:13 --> Config Class Initialized
INFO - 2024-09-07 05:05:13 --> Hooks Class Initialized
DEBUG - 2024-09-07 05:05:13 --> UTF-8 Support Enabled
INFO - 2024-09-07 05:05:13 --> Utf8 Class Initialized
INFO - 2024-09-07 05:05:13 --> URI Class Initialized
INFO - 2024-09-07 05:05:13 --> Router Class Initialized
INFO - 2024-09-07 05:05:13 --> Output Class Initialized
INFO - 2024-09-07 05:05:13 --> Security Class Initialized
DEBUG - 2024-09-07 05:05:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-07 05:05:13 --> Input Class Initialized
INFO - 2024-09-07 05:05:13 --> Language Class Initialized
INFO - 2024-09-07 05:05:13 --> Language Class Initialized
INFO - 2024-09-07 05:05:13 --> Config Class Initialized
INFO - 2024-09-07 05:05:13 --> Loader Class Initialized
INFO - 2024-09-07 05:05:13 --> Helper loaded: url_helper
INFO - 2024-09-07 05:05:13 --> Helper loaded: file_helper
INFO - 2024-09-07 05:05:13 --> Helper loaded: form_helper
INFO - 2024-09-07 05:05:13 --> Helper loaded: my_helper
INFO - 2024-09-07 05:05:13 --> Database Driver Class Initialized
INFO - 2024-09-07 05:05:13 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-07 05:05:13 --> Controller Class Initialized
DEBUG - 2024-09-07 05:05:13 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/lihat_raport/views/list.php
DEBUG - 2024-09-07 05:05:13 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-09-07 05:05:13 --> Final output sent to browser
DEBUG - 2024-09-07 05:05:13 --> Total execution time: 0.0356
