<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2023-09-28 19:41:51 --> Config Class Initialized
INFO - 2023-09-28 19:41:51 --> Hooks Class Initialized
DEBUG - 2023-09-28 19:41:51 --> UTF-8 Support Enabled
INFO - 2023-09-28 19:41:51 --> Utf8 Class Initialized
INFO - 2023-09-28 19:41:51 --> URI Class Initialized
INFO - 2023-09-28 19:41:51 --> Router Class Initialized
INFO - 2023-09-28 19:41:51 --> Output Class Initialized
INFO - 2023-09-28 19:41:51 --> Security Class Initialized
DEBUG - 2023-09-28 19:41:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-28 19:41:51 --> Input Class Initialized
INFO - 2023-09-28 19:41:51 --> Language Class Initialized
INFO - 2023-09-28 19:41:51 --> Language Class Initialized
INFO - 2023-09-28 19:41:51 --> Config Class Initialized
INFO - 2023-09-28 19:41:51 --> Loader Class Initialized
INFO - 2023-09-28 19:41:51 --> Helper loaded: url_helper
INFO - 2023-09-28 19:41:51 --> Helper loaded: file_helper
INFO - 2023-09-28 19:41:51 --> Helper loaded: form_helper
INFO - 2023-09-28 19:41:51 --> Helper loaded: my_helper
INFO - 2023-09-28 19:41:51 --> Database Driver Class Initialized
INFO - 2023-09-28 19:41:51 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-28 19:41:51 --> Controller Class Initialized
DEBUG - 2023-09-28 19:41:51 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/login/views/login.php
DEBUG - 2023-09-28 19:41:51 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-09-28 19:41:51 --> Final output sent to browser
DEBUG - 2023-09-28 19:41:51 --> Total execution time: 0.4973
INFO - 2023-09-28 21:12:56 --> Config Class Initialized
INFO - 2023-09-28 21:12:56 --> Hooks Class Initialized
DEBUG - 2023-09-28 21:12:56 --> UTF-8 Support Enabled
INFO - 2023-09-28 21:12:56 --> Utf8 Class Initialized
INFO - 2023-09-28 21:12:56 --> URI Class Initialized
DEBUG - 2023-09-28 21:12:56 --> No URI present. Default controller set.
INFO - 2023-09-28 21:12:56 --> Router Class Initialized
INFO - 2023-09-28 21:12:56 --> Output Class Initialized
INFO - 2023-09-28 21:12:56 --> Security Class Initialized
DEBUG - 2023-09-28 21:12:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-28 21:12:56 --> Input Class Initialized
INFO - 2023-09-28 21:12:56 --> Language Class Initialized
INFO - 2023-09-28 21:12:56 --> Language Class Initialized
INFO - 2023-09-28 21:12:56 --> Config Class Initialized
INFO - 2023-09-28 21:12:56 --> Loader Class Initialized
INFO - 2023-09-28 21:12:56 --> Helper loaded: url_helper
INFO - 2023-09-28 21:12:56 --> Helper loaded: file_helper
INFO - 2023-09-28 21:12:56 --> Helper loaded: form_helper
INFO - 2023-09-28 21:12:56 --> Helper loaded: my_helper
INFO - 2023-09-28 21:12:56 --> Database Driver Class Initialized
INFO - 2023-09-28 21:12:56 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-28 21:12:56 --> Controller Class Initialized
INFO - 2023-09-28 21:12:57 --> Config Class Initialized
INFO - 2023-09-28 21:12:57 --> Hooks Class Initialized
DEBUG - 2023-09-28 21:12:57 --> UTF-8 Support Enabled
INFO - 2023-09-28 21:12:57 --> Utf8 Class Initialized
INFO - 2023-09-28 21:12:57 --> URI Class Initialized
INFO - 2023-09-28 21:12:57 --> Router Class Initialized
INFO - 2023-09-28 21:12:57 --> Output Class Initialized
INFO - 2023-09-28 21:12:57 --> Security Class Initialized
DEBUG - 2023-09-28 21:12:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-28 21:12:57 --> Input Class Initialized
INFO - 2023-09-28 21:12:57 --> Language Class Initialized
INFO - 2023-09-28 21:12:57 --> Language Class Initialized
INFO - 2023-09-28 21:12:57 --> Config Class Initialized
INFO - 2023-09-28 21:12:57 --> Loader Class Initialized
INFO - 2023-09-28 21:12:57 --> Helper loaded: url_helper
INFO - 2023-09-28 21:12:57 --> Helper loaded: file_helper
INFO - 2023-09-28 21:12:57 --> Helper loaded: form_helper
INFO - 2023-09-28 21:12:57 --> Helper loaded: my_helper
INFO - 2023-09-28 21:12:57 --> Database Driver Class Initialized
INFO - 2023-09-28 21:12:57 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-28 21:12:57 --> Controller Class Initialized
DEBUG - 2023-09-28 21:12:57 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/login/views/login.php
DEBUG - 2023-09-28 21:12:57 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-09-28 21:12:57 --> Final output sent to browser
DEBUG - 2023-09-28 21:12:57 --> Total execution time: 0.0526
INFO - 2023-09-28 21:12:58 --> Config Class Initialized
INFO - 2023-09-28 21:12:58 --> Hooks Class Initialized
DEBUG - 2023-09-28 21:12:58 --> UTF-8 Support Enabled
INFO - 2023-09-28 21:12:58 --> Utf8 Class Initialized
INFO - 2023-09-28 21:12:58 --> URI Class Initialized
INFO - 2023-09-28 21:12:58 --> Router Class Initialized
INFO - 2023-09-28 21:12:58 --> Output Class Initialized
INFO - 2023-09-28 21:12:58 --> Security Class Initialized
DEBUG - 2023-09-28 21:12:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-28 21:12:58 --> Input Class Initialized
INFO - 2023-09-28 21:12:58 --> Language Class Initialized
INFO - 2023-09-28 21:12:58 --> Language Class Initialized
INFO - 2023-09-28 21:12:58 --> Config Class Initialized
INFO - 2023-09-28 21:12:58 --> Loader Class Initialized
INFO - 2023-09-28 21:12:58 --> Helper loaded: url_helper
INFO - 2023-09-28 21:12:58 --> Helper loaded: file_helper
INFO - 2023-09-28 21:12:58 --> Helper loaded: form_helper
INFO - 2023-09-28 21:12:59 --> Helper loaded: my_helper
INFO - 2023-09-28 21:12:59 --> Database Driver Class Initialized
INFO - 2023-09-28 21:12:59 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-28 21:12:59 --> Controller Class Initialized
INFO - 2023-09-28 21:12:59 --> Helper loaded: cookie_helper
INFO - 2023-09-28 21:12:59 --> Final output sent to browser
DEBUG - 2023-09-28 21:12:59 --> Total execution time: 0.0734
INFO - 2023-09-28 21:12:59 --> Config Class Initialized
INFO - 2023-09-28 21:12:59 --> Hooks Class Initialized
DEBUG - 2023-09-28 21:12:59 --> UTF-8 Support Enabled
INFO - 2023-09-28 21:12:59 --> Utf8 Class Initialized
INFO - 2023-09-28 21:12:59 --> URI Class Initialized
INFO - 2023-09-28 21:12:59 --> Router Class Initialized
INFO - 2023-09-28 21:12:59 --> Output Class Initialized
INFO - 2023-09-28 21:12:59 --> Security Class Initialized
DEBUG - 2023-09-28 21:12:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-28 21:12:59 --> Input Class Initialized
INFO - 2023-09-28 21:12:59 --> Language Class Initialized
INFO - 2023-09-28 21:12:59 --> Language Class Initialized
INFO - 2023-09-28 21:12:59 --> Config Class Initialized
INFO - 2023-09-28 21:12:59 --> Loader Class Initialized
INFO - 2023-09-28 21:12:59 --> Helper loaded: url_helper
INFO - 2023-09-28 21:12:59 --> Helper loaded: file_helper
INFO - 2023-09-28 21:12:59 --> Helper loaded: form_helper
INFO - 2023-09-28 21:12:59 --> Helper loaded: my_helper
INFO - 2023-09-28 21:12:59 --> Database Driver Class Initialized
INFO - 2023-09-28 21:12:59 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-28 21:12:59 --> Controller Class Initialized
DEBUG - 2023-09-28 21:12:59 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/home/views/v_home_guru.php
DEBUG - 2023-09-28 21:12:59 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-09-28 21:12:59 --> Final output sent to browser
DEBUG - 2023-09-28 21:12:59 --> Total execution time: 0.0357
INFO - 2023-09-28 21:13:02 --> Config Class Initialized
INFO - 2023-09-28 21:13:02 --> Hooks Class Initialized
DEBUG - 2023-09-28 21:13:02 --> UTF-8 Support Enabled
INFO - 2023-09-28 21:13:02 --> Utf8 Class Initialized
INFO - 2023-09-28 21:13:02 --> URI Class Initialized
INFO - 2023-09-28 21:13:02 --> Router Class Initialized
INFO - 2023-09-28 21:13:02 --> Output Class Initialized
INFO - 2023-09-28 21:13:02 --> Security Class Initialized
DEBUG - 2023-09-28 21:13:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-28 21:13:02 --> Input Class Initialized
INFO - 2023-09-28 21:13:02 --> Language Class Initialized
INFO - 2023-09-28 21:13:02 --> Language Class Initialized
INFO - 2023-09-28 21:13:02 --> Config Class Initialized
INFO - 2023-09-28 21:13:02 --> Loader Class Initialized
INFO - 2023-09-28 21:13:02 --> Helper loaded: url_helper
INFO - 2023-09-28 21:13:02 --> Helper loaded: file_helper
INFO - 2023-09-28 21:13:02 --> Helper loaded: form_helper
INFO - 2023-09-28 21:13:02 --> Helper loaded: my_helper
INFO - 2023-09-28 21:13:02 --> Database Driver Class Initialized
INFO - 2023-09-28 21:13:02 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-28 21:13:02 --> Controller Class Initialized
DEBUG - 2023-09-28 21:13:02 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/view_mapel/views/v_view_mapel.php
DEBUG - 2023-09-28 21:13:02 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-09-28 21:13:02 --> Final output sent to browser
DEBUG - 2023-09-28 21:13:02 --> Total execution time: 0.1661
INFO - 2023-09-28 21:13:47 --> Config Class Initialized
INFO - 2023-09-28 21:13:47 --> Hooks Class Initialized
DEBUG - 2023-09-28 21:13:47 --> UTF-8 Support Enabled
INFO - 2023-09-28 21:13:47 --> Utf8 Class Initialized
INFO - 2023-09-28 21:13:47 --> URI Class Initialized
INFO - 2023-09-28 21:13:47 --> Router Class Initialized
INFO - 2023-09-28 21:13:47 --> Output Class Initialized
INFO - 2023-09-28 21:13:47 --> Security Class Initialized
DEBUG - 2023-09-28 21:13:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-28 21:13:47 --> Input Class Initialized
INFO - 2023-09-28 21:13:47 --> Language Class Initialized
INFO - 2023-09-28 21:13:47 --> Language Class Initialized
INFO - 2023-09-28 21:13:47 --> Config Class Initialized
INFO - 2023-09-28 21:13:47 --> Loader Class Initialized
INFO - 2023-09-28 21:13:47 --> Helper loaded: url_helper
INFO - 2023-09-28 21:13:47 --> Helper loaded: file_helper
INFO - 2023-09-28 21:13:47 --> Helper loaded: form_helper
INFO - 2023-09-28 21:13:47 --> Helper loaded: my_helper
INFO - 2023-09-28 21:13:47 --> Database Driver Class Initialized
INFO - 2023-09-28 21:13:47 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-28 21:13:47 --> Controller Class Initialized
DEBUG - 2023-09-28 21:13:47 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/views/list.php
DEBUG - 2023-09-28 21:13:47 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-09-28 21:13:47 --> Final output sent to browser
DEBUG - 2023-09-28 21:13:47 --> Total execution time: 0.1312
INFO - 2023-09-28 21:13:48 --> Config Class Initialized
INFO - 2023-09-28 21:13:48 --> Hooks Class Initialized
DEBUG - 2023-09-28 21:13:48 --> UTF-8 Support Enabled
INFO - 2023-09-28 21:13:48 --> Utf8 Class Initialized
INFO - 2023-09-28 21:13:48 --> URI Class Initialized
INFO - 2023-09-28 21:13:48 --> Router Class Initialized
INFO - 2023-09-28 21:13:48 --> Output Class Initialized
INFO - 2023-09-28 21:13:48 --> Security Class Initialized
DEBUG - 2023-09-28 21:13:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-28 21:13:48 --> Input Class Initialized
INFO - 2023-09-28 21:13:48 --> Language Class Initialized
INFO - 2023-09-28 21:13:48 --> Language Class Initialized
INFO - 2023-09-28 21:13:48 --> Config Class Initialized
INFO - 2023-09-28 21:13:48 --> Loader Class Initialized
INFO - 2023-09-28 21:13:48 --> Helper loaded: url_helper
INFO - 2023-09-28 21:13:48 --> Helper loaded: file_helper
INFO - 2023-09-28 21:13:48 --> Helper loaded: form_helper
INFO - 2023-09-28 21:13:48 --> Helper loaded: my_helper
INFO - 2023-09-28 21:13:48 --> Database Driver Class Initialized
INFO - 2023-09-28 21:13:48 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-28 21:13:48 --> Controller Class Initialized
INFO - 2023-09-28 21:15:33 --> Config Class Initialized
INFO - 2023-09-28 21:15:33 --> Hooks Class Initialized
DEBUG - 2023-09-28 21:15:33 --> UTF-8 Support Enabled
INFO - 2023-09-28 21:15:33 --> Utf8 Class Initialized
INFO - 2023-09-28 21:15:33 --> URI Class Initialized
INFO - 2023-09-28 21:15:33 --> Router Class Initialized
INFO - 2023-09-28 21:15:33 --> Output Class Initialized
INFO - 2023-09-28 21:15:33 --> Security Class Initialized
DEBUG - 2023-09-28 21:15:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-28 21:15:33 --> Input Class Initialized
INFO - 2023-09-28 21:15:33 --> Language Class Initialized
INFO - 2023-09-28 21:15:33 --> Language Class Initialized
INFO - 2023-09-28 21:15:33 --> Config Class Initialized
INFO - 2023-09-28 21:15:33 --> Loader Class Initialized
INFO - 2023-09-28 21:15:33 --> Helper loaded: url_helper
INFO - 2023-09-28 21:15:33 --> Helper loaded: file_helper
INFO - 2023-09-28 21:15:33 --> Helper loaded: form_helper
INFO - 2023-09-28 21:15:33 --> Helper loaded: my_helper
INFO - 2023-09-28 21:15:33 --> Database Driver Class Initialized
INFO - 2023-09-28 21:15:33 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-28 21:15:33 --> Controller Class Initialized
INFO - 2023-09-28 21:15:33 --> Final output sent to browser
DEBUG - 2023-09-28 21:15:33 --> Total execution time: 0.1249
INFO - 2023-09-28 21:16:04 --> Config Class Initialized
INFO - 2023-09-28 21:16:04 --> Hooks Class Initialized
DEBUG - 2023-09-28 21:16:04 --> UTF-8 Support Enabled
INFO - 2023-09-28 21:16:04 --> Utf8 Class Initialized
INFO - 2023-09-28 21:16:04 --> URI Class Initialized
INFO - 2023-09-28 21:16:04 --> Router Class Initialized
INFO - 2023-09-28 21:16:04 --> Output Class Initialized
INFO - 2023-09-28 21:16:04 --> Security Class Initialized
DEBUG - 2023-09-28 21:16:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-28 21:16:04 --> Input Class Initialized
INFO - 2023-09-28 21:16:04 --> Language Class Initialized
INFO - 2023-09-28 21:16:04 --> Language Class Initialized
INFO - 2023-09-28 21:16:04 --> Config Class Initialized
INFO - 2023-09-28 21:16:04 --> Loader Class Initialized
INFO - 2023-09-28 21:16:04 --> Helper loaded: url_helper
INFO - 2023-09-28 21:16:04 --> Helper loaded: file_helper
INFO - 2023-09-28 21:16:04 --> Helper loaded: form_helper
INFO - 2023-09-28 21:16:04 --> Helper loaded: my_helper
INFO - 2023-09-28 21:16:04 --> Database Driver Class Initialized
INFO - 2023-09-28 21:16:04 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-28 21:16:04 --> Controller Class Initialized
INFO - 2023-09-28 21:16:04 --> Final output sent to browser
DEBUG - 2023-09-28 21:16:04 --> Total execution time: 0.0926
INFO - 2023-09-28 21:16:04 --> Config Class Initialized
INFO - 2023-09-28 21:16:04 --> Hooks Class Initialized
DEBUG - 2023-09-28 21:16:04 --> UTF-8 Support Enabled
INFO - 2023-09-28 21:16:04 --> Utf8 Class Initialized
INFO - 2023-09-28 21:16:04 --> URI Class Initialized
INFO - 2023-09-28 21:16:04 --> Router Class Initialized
INFO - 2023-09-28 21:16:04 --> Output Class Initialized
INFO - 2023-09-28 21:16:04 --> Security Class Initialized
DEBUG - 2023-09-28 21:16:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-28 21:16:04 --> Input Class Initialized
INFO - 2023-09-28 21:16:04 --> Language Class Initialized
INFO - 2023-09-28 21:16:04 --> Language Class Initialized
INFO - 2023-09-28 21:16:04 --> Config Class Initialized
INFO - 2023-09-28 21:16:04 --> Loader Class Initialized
INFO - 2023-09-28 21:16:04 --> Helper loaded: url_helper
INFO - 2023-09-28 21:16:04 --> Helper loaded: file_helper
INFO - 2023-09-28 21:16:04 --> Helper loaded: form_helper
INFO - 2023-09-28 21:16:04 --> Helper loaded: my_helper
INFO - 2023-09-28 21:16:04 --> Database Driver Class Initialized
INFO - 2023-09-28 21:16:04 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-28 21:16:04 --> Controller Class Initialized
INFO - 2023-09-28 21:16:07 --> Config Class Initialized
INFO - 2023-09-28 21:16:07 --> Hooks Class Initialized
DEBUG - 2023-09-28 21:16:07 --> UTF-8 Support Enabled
INFO - 2023-09-28 21:16:07 --> Utf8 Class Initialized
INFO - 2023-09-28 21:16:07 --> URI Class Initialized
INFO - 2023-09-28 21:16:07 --> Router Class Initialized
INFO - 2023-09-28 21:16:07 --> Output Class Initialized
INFO - 2023-09-28 21:16:07 --> Security Class Initialized
DEBUG - 2023-09-28 21:16:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-28 21:16:07 --> Input Class Initialized
INFO - 2023-09-28 21:16:07 --> Language Class Initialized
INFO - 2023-09-28 21:16:07 --> Language Class Initialized
INFO - 2023-09-28 21:16:07 --> Config Class Initialized
INFO - 2023-09-28 21:16:07 --> Loader Class Initialized
INFO - 2023-09-28 21:16:07 --> Helper loaded: url_helper
INFO - 2023-09-28 21:16:07 --> Helper loaded: file_helper
INFO - 2023-09-28 21:16:07 --> Helper loaded: form_helper
INFO - 2023-09-28 21:16:07 --> Helper loaded: my_helper
INFO - 2023-09-28 21:16:07 --> Database Driver Class Initialized
INFO - 2023-09-28 21:16:07 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-28 21:16:07 --> Controller Class Initialized
INFO - 2023-09-28 21:16:07 --> Final output sent to browser
DEBUG - 2023-09-28 21:16:07 --> Total execution time: 0.1083
INFO - 2023-09-28 21:16:07 --> Config Class Initialized
INFO - 2023-09-28 21:16:07 --> Hooks Class Initialized
DEBUG - 2023-09-28 21:16:07 --> UTF-8 Support Enabled
INFO - 2023-09-28 21:16:07 --> Utf8 Class Initialized
INFO - 2023-09-28 21:16:07 --> URI Class Initialized
INFO - 2023-09-28 21:16:07 --> Router Class Initialized
INFO - 2023-09-28 21:16:07 --> Output Class Initialized
INFO - 2023-09-28 21:16:07 --> Security Class Initialized
DEBUG - 2023-09-28 21:16:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-28 21:16:07 --> Input Class Initialized
INFO - 2023-09-28 21:16:07 --> Language Class Initialized
INFO - 2023-09-28 21:16:07 --> Language Class Initialized
INFO - 2023-09-28 21:16:07 --> Config Class Initialized
INFO - 2023-09-28 21:16:07 --> Loader Class Initialized
INFO - 2023-09-28 21:16:07 --> Helper loaded: url_helper
INFO - 2023-09-28 21:16:07 --> Helper loaded: file_helper
INFO - 2023-09-28 21:16:07 --> Helper loaded: form_helper
INFO - 2023-09-28 21:16:07 --> Helper loaded: my_helper
INFO - 2023-09-28 21:16:07 --> Database Driver Class Initialized
INFO - 2023-09-28 21:16:07 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-28 21:16:07 --> Controller Class Initialized
INFO - 2023-09-28 21:16:07 --> Config Class Initialized
INFO - 2023-09-28 21:16:07 --> Hooks Class Initialized
DEBUG - 2023-09-28 21:16:07 --> UTF-8 Support Enabled
INFO - 2023-09-28 21:16:07 --> Utf8 Class Initialized
INFO - 2023-09-28 21:16:07 --> URI Class Initialized
INFO - 2023-09-28 21:16:07 --> Router Class Initialized
INFO - 2023-09-28 21:16:07 --> Output Class Initialized
INFO - 2023-09-28 21:16:07 --> Security Class Initialized
DEBUG - 2023-09-28 21:16:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-28 21:16:07 --> Input Class Initialized
INFO - 2023-09-28 21:16:07 --> Language Class Initialized
INFO - 2023-09-28 21:16:07 --> Language Class Initialized
INFO - 2023-09-28 21:16:07 --> Config Class Initialized
INFO - 2023-09-28 21:16:07 --> Loader Class Initialized
INFO - 2023-09-28 21:16:07 --> Helper loaded: url_helper
INFO - 2023-09-28 21:16:07 --> Helper loaded: file_helper
INFO - 2023-09-28 21:16:07 --> Helper loaded: form_helper
INFO - 2023-09-28 21:16:07 --> Helper loaded: my_helper
INFO - 2023-09-28 21:16:07 --> Database Driver Class Initialized
INFO - 2023-09-28 21:16:08 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-28 21:16:08 --> Controller Class Initialized
INFO - 2023-09-28 21:16:08 --> Final output sent to browser
DEBUG - 2023-09-28 21:16:08 --> Total execution time: 0.2491
INFO - 2023-09-28 21:16:08 --> Config Class Initialized
INFO - 2023-09-28 21:16:08 --> Hooks Class Initialized
DEBUG - 2023-09-28 21:16:08 --> UTF-8 Support Enabled
INFO - 2023-09-28 21:16:08 --> Utf8 Class Initialized
INFO - 2023-09-28 21:16:08 --> URI Class Initialized
INFO - 2023-09-28 21:16:08 --> Router Class Initialized
INFO - 2023-09-28 21:16:08 --> Output Class Initialized
INFO - 2023-09-28 21:16:08 --> Security Class Initialized
DEBUG - 2023-09-28 21:16:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-28 21:16:08 --> Input Class Initialized
INFO - 2023-09-28 21:16:08 --> Language Class Initialized
INFO - 2023-09-28 21:16:08 --> Language Class Initialized
INFO - 2023-09-28 21:16:08 --> Config Class Initialized
INFO - 2023-09-28 21:16:08 --> Loader Class Initialized
INFO - 2023-09-28 21:16:08 --> Helper loaded: url_helper
INFO - 2023-09-28 21:16:08 --> Helper loaded: file_helper
INFO - 2023-09-28 21:16:08 --> Helper loaded: form_helper
INFO - 2023-09-28 21:16:08 --> Helper loaded: my_helper
INFO - 2023-09-28 21:16:08 --> Database Driver Class Initialized
INFO - 2023-09-28 21:16:08 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-28 21:16:08 --> Controller Class Initialized
INFO - 2023-09-28 21:16:09 --> Config Class Initialized
INFO - 2023-09-28 21:16:09 --> Hooks Class Initialized
DEBUG - 2023-09-28 21:16:09 --> UTF-8 Support Enabled
INFO - 2023-09-28 21:16:09 --> Utf8 Class Initialized
INFO - 2023-09-28 21:16:09 --> URI Class Initialized
INFO - 2023-09-28 21:16:09 --> Router Class Initialized
INFO - 2023-09-28 21:16:09 --> Output Class Initialized
INFO - 2023-09-28 21:16:09 --> Security Class Initialized
DEBUG - 2023-09-28 21:16:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-28 21:16:09 --> Input Class Initialized
INFO - 2023-09-28 21:16:09 --> Language Class Initialized
INFO - 2023-09-28 21:16:09 --> Language Class Initialized
INFO - 2023-09-28 21:16:09 --> Config Class Initialized
INFO - 2023-09-28 21:16:09 --> Loader Class Initialized
INFO - 2023-09-28 21:16:09 --> Helper loaded: url_helper
INFO - 2023-09-28 21:16:09 --> Helper loaded: file_helper
INFO - 2023-09-28 21:16:09 --> Helper loaded: form_helper
INFO - 2023-09-28 21:16:09 --> Helper loaded: my_helper
INFO - 2023-09-28 21:16:09 --> Database Driver Class Initialized
INFO - 2023-09-28 21:16:09 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-28 21:16:09 --> Controller Class Initialized
INFO - 2023-09-28 21:16:09 --> Final output sent to browser
DEBUG - 2023-09-28 21:16:09 --> Total execution time: 0.0747
INFO - 2023-09-28 21:16:09 --> Config Class Initialized
INFO - 2023-09-28 21:16:09 --> Hooks Class Initialized
DEBUG - 2023-09-28 21:16:09 --> UTF-8 Support Enabled
INFO - 2023-09-28 21:16:09 --> Utf8 Class Initialized
INFO - 2023-09-28 21:16:09 --> URI Class Initialized
INFO - 2023-09-28 21:16:09 --> Router Class Initialized
INFO - 2023-09-28 21:16:09 --> Output Class Initialized
INFO - 2023-09-28 21:16:09 --> Security Class Initialized
DEBUG - 2023-09-28 21:16:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-28 21:16:09 --> Input Class Initialized
INFO - 2023-09-28 21:16:09 --> Language Class Initialized
INFO - 2023-09-28 21:16:09 --> Language Class Initialized
INFO - 2023-09-28 21:16:09 --> Config Class Initialized
INFO - 2023-09-28 21:16:09 --> Loader Class Initialized
INFO - 2023-09-28 21:16:09 --> Helper loaded: url_helper
INFO - 2023-09-28 21:16:09 --> Helper loaded: file_helper
INFO - 2023-09-28 21:16:09 --> Helper loaded: form_helper
INFO - 2023-09-28 21:16:09 --> Helper loaded: my_helper
INFO - 2023-09-28 21:16:09 --> Database Driver Class Initialized
INFO - 2023-09-28 21:16:09 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-28 21:16:09 --> Controller Class Initialized
INFO - 2023-09-28 21:16:10 --> Config Class Initialized
INFO - 2023-09-28 21:16:10 --> Hooks Class Initialized
DEBUG - 2023-09-28 21:16:10 --> UTF-8 Support Enabled
INFO - 2023-09-28 21:16:10 --> Utf8 Class Initialized
INFO - 2023-09-28 21:16:10 --> URI Class Initialized
INFO - 2023-09-28 21:16:10 --> Router Class Initialized
INFO - 2023-09-28 21:16:10 --> Output Class Initialized
INFO - 2023-09-28 21:16:10 --> Security Class Initialized
DEBUG - 2023-09-28 21:16:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-28 21:16:10 --> Input Class Initialized
INFO - 2023-09-28 21:16:10 --> Language Class Initialized
INFO - 2023-09-28 21:16:10 --> Language Class Initialized
INFO - 2023-09-28 21:16:10 --> Config Class Initialized
INFO - 2023-09-28 21:16:10 --> Loader Class Initialized
INFO - 2023-09-28 21:16:10 --> Helper loaded: url_helper
INFO - 2023-09-28 21:16:10 --> Helper loaded: file_helper
INFO - 2023-09-28 21:16:10 --> Helper loaded: form_helper
INFO - 2023-09-28 21:16:10 --> Helper loaded: my_helper
INFO - 2023-09-28 21:16:10 --> Database Driver Class Initialized
INFO - 2023-09-28 21:16:10 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-28 21:16:10 --> Controller Class Initialized
INFO - 2023-09-28 21:16:10 --> Final output sent to browser
DEBUG - 2023-09-28 21:16:10 --> Total execution time: 0.0519
INFO - 2023-09-28 21:16:10 --> Config Class Initialized
INFO - 2023-09-28 21:16:10 --> Hooks Class Initialized
DEBUG - 2023-09-28 21:16:10 --> UTF-8 Support Enabled
INFO - 2023-09-28 21:16:10 --> Utf8 Class Initialized
INFO - 2023-09-28 21:16:10 --> URI Class Initialized
INFO - 2023-09-28 21:16:10 --> Router Class Initialized
INFO - 2023-09-28 21:16:10 --> Output Class Initialized
INFO - 2023-09-28 21:16:10 --> Security Class Initialized
DEBUG - 2023-09-28 21:16:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-28 21:16:10 --> Input Class Initialized
INFO - 2023-09-28 21:16:10 --> Language Class Initialized
INFO - 2023-09-28 21:16:10 --> Language Class Initialized
INFO - 2023-09-28 21:16:10 --> Config Class Initialized
INFO - 2023-09-28 21:16:10 --> Loader Class Initialized
INFO - 2023-09-28 21:16:10 --> Helper loaded: url_helper
INFO - 2023-09-28 21:16:10 --> Helper loaded: file_helper
INFO - 2023-09-28 21:16:10 --> Helper loaded: form_helper
INFO - 2023-09-28 21:16:10 --> Helper loaded: my_helper
INFO - 2023-09-28 21:16:10 --> Database Driver Class Initialized
INFO - 2023-09-28 21:16:10 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-28 21:16:10 --> Controller Class Initialized
INFO - 2023-09-28 21:16:11 --> Config Class Initialized
INFO - 2023-09-28 21:16:11 --> Hooks Class Initialized
DEBUG - 2023-09-28 21:16:11 --> UTF-8 Support Enabled
INFO - 2023-09-28 21:16:11 --> Utf8 Class Initialized
INFO - 2023-09-28 21:16:11 --> URI Class Initialized
INFO - 2023-09-28 21:16:11 --> Router Class Initialized
INFO - 2023-09-28 21:16:11 --> Output Class Initialized
INFO - 2023-09-28 21:16:11 --> Security Class Initialized
DEBUG - 2023-09-28 21:16:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-28 21:16:11 --> Input Class Initialized
INFO - 2023-09-28 21:16:11 --> Language Class Initialized
INFO - 2023-09-28 21:16:11 --> Language Class Initialized
INFO - 2023-09-28 21:16:11 --> Config Class Initialized
INFO - 2023-09-28 21:16:11 --> Loader Class Initialized
INFO - 2023-09-28 21:16:11 --> Helper loaded: url_helper
INFO - 2023-09-28 21:16:11 --> Helper loaded: file_helper
INFO - 2023-09-28 21:16:11 --> Helper loaded: form_helper
INFO - 2023-09-28 21:16:11 --> Helper loaded: my_helper
INFO - 2023-09-28 21:16:11 --> Database Driver Class Initialized
INFO - 2023-09-28 21:16:11 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-28 21:16:11 --> Controller Class Initialized
INFO - 2023-09-28 21:16:11 --> Final output sent to browser
DEBUG - 2023-09-28 21:16:11 --> Total execution time: 0.0429
INFO - 2023-09-28 21:16:11 --> Config Class Initialized
INFO - 2023-09-28 21:16:11 --> Hooks Class Initialized
DEBUG - 2023-09-28 21:16:11 --> UTF-8 Support Enabled
INFO - 2023-09-28 21:16:11 --> Utf8 Class Initialized
INFO - 2023-09-28 21:16:11 --> URI Class Initialized
INFO - 2023-09-28 21:16:11 --> Router Class Initialized
INFO - 2023-09-28 21:16:11 --> Output Class Initialized
INFO - 2023-09-28 21:16:11 --> Security Class Initialized
DEBUG - 2023-09-28 21:16:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-28 21:16:11 --> Input Class Initialized
INFO - 2023-09-28 21:16:11 --> Language Class Initialized
INFO - 2023-09-28 21:16:11 --> Language Class Initialized
INFO - 2023-09-28 21:16:11 --> Config Class Initialized
INFO - 2023-09-28 21:16:11 --> Loader Class Initialized
INFO - 2023-09-28 21:16:11 --> Helper loaded: url_helper
INFO - 2023-09-28 21:16:11 --> Helper loaded: file_helper
INFO - 2023-09-28 21:16:11 --> Helper loaded: form_helper
INFO - 2023-09-28 21:16:11 --> Helper loaded: my_helper
INFO - 2023-09-28 21:16:11 --> Database Driver Class Initialized
INFO - 2023-09-28 21:16:11 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-28 21:16:11 --> Controller Class Initialized
INFO - 2023-09-28 21:16:12 --> Config Class Initialized
INFO - 2023-09-28 21:16:12 --> Hooks Class Initialized
DEBUG - 2023-09-28 21:16:12 --> UTF-8 Support Enabled
INFO - 2023-09-28 21:16:12 --> Utf8 Class Initialized
INFO - 2023-09-28 21:16:12 --> URI Class Initialized
INFO - 2023-09-28 21:16:12 --> Router Class Initialized
INFO - 2023-09-28 21:16:12 --> Output Class Initialized
INFO - 2023-09-28 21:16:12 --> Security Class Initialized
DEBUG - 2023-09-28 21:16:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-28 21:16:12 --> Input Class Initialized
INFO - 2023-09-28 21:16:12 --> Language Class Initialized
INFO - 2023-09-28 21:16:12 --> Language Class Initialized
INFO - 2023-09-28 21:16:12 --> Config Class Initialized
INFO - 2023-09-28 21:16:12 --> Loader Class Initialized
INFO - 2023-09-28 21:16:12 --> Helper loaded: url_helper
INFO - 2023-09-28 21:16:12 --> Helper loaded: file_helper
INFO - 2023-09-28 21:16:12 --> Helper loaded: form_helper
INFO - 2023-09-28 21:16:12 --> Helper loaded: my_helper
INFO - 2023-09-28 21:16:12 --> Database Driver Class Initialized
INFO - 2023-09-28 21:16:12 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-28 21:16:12 --> Controller Class Initialized
INFO - 2023-09-28 21:16:12 --> Final output sent to browser
DEBUG - 2023-09-28 21:16:12 --> Total execution time: 0.0422
INFO - 2023-09-28 21:16:12 --> Config Class Initialized
INFO - 2023-09-28 21:16:12 --> Hooks Class Initialized
DEBUG - 2023-09-28 21:16:12 --> UTF-8 Support Enabled
INFO - 2023-09-28 21:16:12 --> Utf8 Class Initialized
INFO - 2023-09-28 21:16:12 --> URI Class Initialized
INFO - 2023-09-28 21:16:12 --> Router Class Initialized
INFO - 2023-09-28 21:16:12 --> Output Class Initialized
INFO - 2023-09-28 21:16:12 --> Security Class Initialized
DEBUG - 2023-09-28 21:16:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-28 21:16:12 --> Input Class Initialized
INFO - 2023-09-28 21:16:12 --> Language Class Initialized
INFO - 2023-09-28 21:16:12 --> Language Class Initialized
INFO - 2023-09-28 21:16:12 --> Config Class Initialized
INFO - 2023-09-28 21:16:12 --> Loader Class Initialized
INFO - 2023-09-28 21:16:12 --> Helper loaded: url_helper
INFO - 2023-09-28 21:16:12 --> Helper loaded: file_helper
INFO - 2023-09-28 21:16:12 --> Helper loaded: form_helper
INFO - 2023-09-28 21:16:12 --> Helper loaded: my_helper
INFO - 2023-09-28 21:16:12 --> Database Driver Class Initialized
INFO - 2023-09-28 21:16:12 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-28 21:16:12 --> Controller Class Initialized
INFO - 2023-09-28 21:16:14 --> Config Class Initialized
INFO - 2023-09-28 21:16:14 --> Hooks Class Initialized
DEBUG - 2023-09-28 21:16:14 --> UTF-8 Support Enabled
INFO - 2023-09-28 21:16:14 --> Utf8 Class Initialized
INFO - 2023-09-28 21:16:14 --> URI Class Initialized
INFO - 2023-09-28 21:16:14 --> Router Class Initialized
INFO - 2023-09-28 21:16:14 --> Output Class Initialized
INFO - 2023-09-28 21:16:14 --> Security Class Initialized
DEBUG - 2023-09-28 21:16:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-28 21:16:14 --> Input Class Initialized
INFO - 2023-09-28 21:16:14 --> Language Class Initialized
INFO - 2023-09-28 21:16:14 --> Language Class Initialized
INFO - 2023-09-28 21:16:14 --> Config Class Initialized
INFO - 2023-09-28 21:16:14 --> Loader Class Initialized
INFO - 2023-09-28 21:16:14 --> Helper loaded: url_helper
INFO - 2023-09-28 21:16:14 --> Helper loaded: file_helper
INFO - 2023-09-28 21:16:14 --> Helper loaded: form_helper
INFO - 2023-09-28 21:16:14 --> Helper loaded: my_helper
INFO - 2023-09-28 21:16:14 --> Database Driver Class Initialized
INFO - 2023-09-28 21:16:14 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-28 21:16:14 --> Controller Class Initialized
INFO - 2023-09-28 21:16:14 --> Final output sent to browser
DEBUG - 2023-09-28 21:16:14 --> Total execution time: 0.0393
INFO - 2023-09-28 21:16:14 --> Config Class Initialized
INFO - 2023-09-28 21:16:14 --> Hooks Class Initialized
DEBUG - 2023-09-28 21:16:14 --> UTF-8 Support Enabled
INFO - 2023-09-28 21:16:14 --> Utf8 Class Initialized
INFO - 2023-09-28 21:16:14 --> URI Class Initialized
INFO - 2023-09-28 21:16:14 --> Router Class Initialized
INFO - 2023-09-28 21:16:14 --> Output Class Initialized
INFO - 2023-09-28 21:16:14 --> Security Class Initialized
DEBUG - 2023-09-28 21:16:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-28 21:16:14 --> Input Class Initialized
INFO - 2023-09-28 21:16:14 --> Language Class Initialized
INFO - 2023-09-28 21:16:14 --> Language Class Initialized
INFO - 2023-09-28 21:16:14 --> Config Class Initialized
INFO - 2023-09-28 21:16:14 --> Loader Class Initialized
INFO - 2023-09-28 21:16:14 --> Helper loaded: url_helper
INFO - 2023-09-28 21:16:14 --> Helper loaded: file_helper
INFO - 2023-09-28 21:16:14 --> Helper loaded: form_helper
INFO - 2023-09-28 21:16:14 --> Helper loaded: my_helper
INFO - 2023-09-28 21:16:14 --> Database Driver Class Initialized
INFO - 2023-09-28 21:16:14 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-28 21:16:14 --> Controller Class Initialized
INFO - 2023-09-28 21:16:16 --> Config Class Initialized
INFO - 2023-09-28 21:16:16 --> Hooks Class Initialized
DEBUG - 2023-09-28 21:16:16 --> UTF-8 Support Enabled
INFO - 2023-09-28 21:16:16 --> Utf8 Class Initialized
INFO - 2023-09-28 21:16:16 --> URI Class Initialized
INFO - 2023-09-28 21:16:16 --> Router Class Initialized
INFO - 2023-09-28 21:16:16 --> Output Class Initialized
INFO - 2023-09-28 21:16:16 --> Security Class Initialized
DEBUG - 2023-09-28 21:16:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-28 21:16:16 --> Input Class Initialized
INFO - 2023-09-28 21:16:16 --> Language Class Initialized
INFO - 2023-09-28 21:16:16 --> Language Class Initialized
INFO - 2023-09-28 21:16:16 --> Config Class Initialized
INFO - 2023-09-28 21:16:16 --> Loader Class Initialized
INFO - 2023-09-28 21:16:16 --> Helper loaded: url_helper
INFO - 2023-09-28 21:16:16 --> Helper loaded: file_helper
INFO - 2023-09-28 21:16:16 --> Helper loaded: form_helper
INFO - 2023-09-28 21:16:16 --> Helper loaded: my_helper
INFO - 2023-09-28 21:16:16 --> Database Driver Class Initialized
INFO - 2023-09-28 21:16:16 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-28 21:16:16 --> Controller Class Initialized
INFO - 2023-09-28 21:16:16 --> Final output sent to browser
DEBUG - 2023-09-28 21:16:16 --> Total execution time: 0.0386
INFO - 2023-09-28 21:16:16 --> Config Class Initialized
INFO - 2023-09-28 21:16:16 --> Hooks Class Initialized
DEBUG - 2023-09-28 21:16:16 --> UTF-8 Support Enabled
INFO - 2023-09-28 21:16:16 --> Utf8 Class Initialized
INFO - 2023-09-28 21:16:16 --> URI Class Initialized
INFO - 2023-09-28 21:16:16 --> Router Class Initialized
INFO - 2023-09-28 21:16:16 --> Output Class Initialized
INFO - 2023-09-28 21:16:16 --> Security Class Initialized
DEBUG - 2023-09-28 21:16:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-28 21:16:16 --> Input Class Initialized
INFO - 2023-09-28 21:16:16 --> Language Class Initialized
INFO - 2023-09-28 21:16:16 --> Language Class Initialized
INFO - 2023-09-28 21:16:16 --> Config Class Initialized
INFO - 2023-09-28 21:16:16 --> Loader Class Initialized
INFO - 2023-09-28 21:16:16 --> Helper loaded: url_helper
INFO - 2023-09-28 21:16:16 --> Helper loaded: file_helper
INFO - 2023-09-28 21:16:16 --> Helper loaded: form_helper
INFO - 2023-09-28 21:16:16 --> Helper loaded: my_helper
INFO - 2023-09-28 21:16:16 --> Database Driver Class Initialized
INFO - 2023-09-28 21:16:16 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-28 21:16:16 --> Controller Class Initialized
INFO - 2023-09-28 21:16:17 --> Config Class Initialized
INFO - 2023-09-28 21:16:17 --> Hooks Class Initialized
DEBUG - 2023-09-28 21:16:17 --> UTF-8 Support Enabled
INFO - 2023-09-28 21:16:17 --> Utf8 Class Initialized
INFO - 2023-09-28 21:16:17 --> URI Class Initialized
INFO - 2023-09-28 21:16:17 --> Router Class Initialized
INFO - 2023-09-28 21:16:17 --> Output Class Initialized
INFO - 2023-09-28 21:16:17 --> Security Class Initialized
DEBUG - 2023-09-28 21:16:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-28 21:16:17 --> Input Class Initialized
INFO - 2023-09-28 21:16:17 --> Language Class Initialized
INFO - 2023-09-28 21:16:17 --> Language Class Initialized
INFO - 2023-09-28 21:16:17 --> Config Class Initialized
INFO - 2023-09-28 21:16:17 --> Loader Class Initialized
INFO - 2023-09-28 21:16:17 --> Helper loaded: url_helper
INFO - 2023-09-28 21:16:17 --> Helper loaded: file_helper
INFO - 2023-09-28 21:16:17 --> Helper loaded: form_helper
INFO - 2023-09-28 21:16:17 --> Helper loaded: my_helper
INFO - 2023-09-28 21:16:17 --> Database Driver Class Initialized
INFO - 2023-09-28 21:16:17 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-28 21:16:17 --> Controller Class Initialized
INFO - 2023-09-28 21:16:17 --> Final output sent to browser
DEBUG - 2023-09-28 21:16:17 --> Total execution time: 0.1162
INFO - 2023-09-28 21:16:17 --> Config Class Initialized
INFO - 2023-09-28 21:16:17 --> Hooks Class Initialized
DEBUG - 2023-09-28 21:16:17 --> UTF-8 Support Enabled
INFO - 2023-09-28 21:16:17 --> Utf8 Class Initialized
INFO - 2023-09-28 21:16:17 --> URI Class Initialized
INFO - 2023-09-28 21:16:17 --> Router Class Initialized
INFO - 2023-09-28 21:16:17 --> Output Class Initialized
INFO - 2023-09-28 21:16:17 --> Security Class Initialized
DEBUG - 2023-09-28 21:16:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-28 21:16:17 --> Input Class Initialized
INFO - 2023-09-28 21:16:17 --> Language Class Initialized
INFO - 2023-09-28 21:16:17 --> Language Class Initialized
INFO - 2023-09-28 21:16:17 --> Config Class Initialized
INFO - 2023-09-28 21:16:17 --> Loader Class Initialized
INFO - 2023-09-28 21:16:17 --> Helper loaded: url_helper
INFO - 2023-09-28 21:16:17 --> Helper loaded: file_helper
INFO - 2023-09-28 21:16:17 --> Helper loaded: form_helper
INFO - 2023-09-28 21:16:17 --> Helper loaded: my_helper
INFO - 2023-09-28 21:16:18 --> Database Driver Class Initialized
INFO - 2023-09-28 21:16:18 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-28 21:16:18 --> Controller Class Initialized
INFO - 2023-09-28 21:16:19 --> Config Class Initialized
INFO - 2023-09-28 21:16:19 --> Hooks Class Initialized
DEBUG - 2023-09-28 21:16:19 --> UTF-8 Support Enabled
INFO - 2023-09-28 21:16:19 --> Utf8 Class Initialized
INFO - 2023-09-28 21:16:19 --> URI Class Initialized
INFO - 2023-09-28 21:16:19 --> Router Class Initialized
INFO - 2023-09-28 21:16:19 --> Output Class Initialized
INFO - 2023-09-28 21:16:19 --> Security Class Initialized
DEBUG - 2023-09-28 21:16:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-28 21:16:19 --> Input Class Initialized
INFO - 2023-09-28 21:16:19 --> Language Class Initialized
INFO - 2023-09-28 21:16:19 --> Language Class Initialized
INFO - 2023-09-28 21:16:19 --> Config Class Initialized
INFO - 2023-09-28 21:16:19 --> Loader Class Initialized
INFO - 2023-09-28 21:16:19 --> Helper loaded: url_helper
INFO - 2023-09-28 21:16:19 --> Helper loaded: file_helper
INFO - 2023-09-28 21:16:19 --> Helper loaded: form_helper
INFO - 2023-09-28 21:16:19 --> Helper loaded: my_helper
INFO - 2023-09-28 21:16:19 --> Database Driver Class Initialized
INFO - 2023-09-28 21:16:19 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-28 21:16:19 --> Controller Class Initialized
INFO - 2023-09-28 21:16:19 --> Final output sent to browser
DEBUG - 2023-09-28 21:16:19 --> Total execution time: 0.0422
INFO - 2023-09-28 21:16:19 --> Config Class Initialized
INFO - 2023-09-28 21:16:19 --> Hooks Class Initialized
DEBUG - 2023-09-28 21:16:19 --> UTF-8 Support Enabled
INFO - 2023-09-28 21:16:19 --> Utf8 Class Initialized
INFO - 2023-09-28 21:16:19 --> URI Class Initialized
INFO - 2023-09-28 21:16:19 --> Router Class Initialized
INFO - 2023-09-28 21:16:19 --> Output Class Initialized
INFO - 2023-09-28 21:16:19 --> Security Class Initialized
DEBUG - 2023-09-28 21:16:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-28 21:16:19 --> Input Class Initialized
INFO - 2023-09-28 21:16:19 --> Language Class Initialized
INFO - 2023-09-28 21:16:19 --> Language Class Initialized
INFO - 2023-09-28 21:16:19 --> Config Class Initialized
INFO - 2023-09-28 21:16:19 --> Loader Class Initialized
INFO - 2023-09-28 21:16:19 --> Helper loaded: url_helper
INFO - 2023-09-28 21:16:19 --> Helper loaded: file_helper
INFO - 2023-09-28 21:16:19 --> Helper loaded: form_helper
INFO - 2023-09-28 21:16:19 --> Helper loaded: my_helper
INFO - 2023-09-28 21:16:19 --> Database Driver Class Initialized
INFO - 2023-09-28 21:16:19 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-28 21:16:19 --> Controller Class Initialized
INFO - 2023-09-28 21:16:20 --> Config Class Initialized
INFO - 2023-09-28 21:16:20 --> Hooks Class Initialized
DEBUG - 2023-09-28 21:16:20 --> UTF-8 Support Enabled
INFO - 2023-09-28 21:16:20 --> Utf8 Class Initialized
INFO - 2023-09-28 21:16:20 --> URI Class Initialized
INFO - 2023-09-28 21:16:20 --> Router Class Initialized
INFO - 2023-09-28 21:16:20 --> Output Class Initialized
INFO - 2023-09-28 21:16:20 --> Security Class Initialized
DEBUG - 2023-09-28 21:16:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-28 21:16:20 --> Input Class Initialized
INFO - 2023-09-28 21:16:20 --> Language Class Initialized
INFO - 2023-09-28 21:16:20 --> Language Class Initialized
INFO - 2023-09-28 21:16:20 --> Config Class Initialized
INFO - 2023-09-28 21:16:20 --> Loader Class Initialized
INFO - 2023-09-28 21:16:20 --> Helper loaded: url_helper
INFO - 2023-09-28 21:16:20 --> Helper loaded: file_helper
INFO - 2023-09-28 21:16:20 --> Helper loaded: form_helper
INFO - 2023-09-28 21:16:20 --> Helper loaded: my_helper
INFO - 2023-09-28 21:16:20 --> Database Driver Class Initialized
INFO - 2023-09-28 21:16:20 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-28 21:16:20 --> Controller Class Initialized
INFO - 2023-09-28 21:16:20 --> Final output sent to browser
DEBUG - 2023-09-28 21:16:20 --> Total execution time: 0.1349
INFO - 2023-09-28 21:16:20 --> Config Class Initialized
INFO - 2023-09-28 21:16:20 --> Hooks Class Initialized
DEBUG - 2023-09-28 21:16:20 --> UTF-8 Support Enabled
INFO - 2023-09-28 21:16:20 --> Utf8 Class Initialized
INFO - 2023-09-28 21:16:20 --> URI Class Initialized
INFO - 2023-09-28 21:16:20 --> Router Class Initialized
INFO - 2023-09-28 21:16:20 --> Output Class Initialized
INFO - 2023-09-28 21:16:20 --> Security Class Initialized
DEBUG - 2023-09-28 21:16:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-28 21:16:20 --> Input Class Initialized
INFO - 2023-09-28 21:16:20 --> Language Class Initialized
INFO - 2023-09-28 21:16:20 --> Language Class Initialized
INFO - 2023-09-28 21:16:20 --> Config Class Initialized
INFO - 2023-09-28 21:16:20 --> Loader Class Initialized
INFO - 2023-09-28 21:16:20 --> Helper loaded: url_helper
INFO - 2023-09-28 21:16:20 --> Helper loaded: file_helper
INFO - 2023-09-28 21:16:20 --> Helper loaded: form_helper
INFO - 2023-09-28 21:16:20 --> Helper loaded: my_helper
INFO - 2023-09-28 21:16:20 --> Database Driver Class Initialized
INFO - 2023-09-28 21:16:20 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-28 21:16:20 --> Controller Class Initialized
INFO - 2023-09-28 21:16:21 --> Config Class Initialized
INFO - 2023-09-28 21:16:21 --> Hooks Class Initialized
DEBUG - 2023-09-28 21:16:21 --> UTF-8 Support Enabled
INFO - 2023-09-28 21:16:21 --> Utf8 Class Initialized
INFO - 2023-09-28 21:16:21 --> URI Class Initialized
INFO - 2023-09-28 21:16:21 --> Router Class Initialized
INFO - 2023-09-28 21:16:21 --> Output Class Initialized
INFO - 2023-09-28 21:16:21 --> Security Class Initialized
DEBUG - 2023-09-28 21:16:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-28 21:16:21 --> Input Class Initialized
INFO - 2023-09-28 21:16:21 --> Language Class Initialized
INFO - 2023-09-28 21:16:21 --> Language Class Initialized
INFO - 2023-09-28 21:16:21 --> Config Class Initialized
INFO - 2023-09-28 21:16:21 --> Loader Class Initialized
INFO - 2023-09-28 21:16:21 --> Helper loaded: url_helper
INFO - 2023-09-28 21:16:21 --> Helper loaded: file_helper
INFO - 2023-09-28 21:16:21 --> Helper loaded: form_helper
INFO - 2023-09-28 21:16:21 --> Helper loaded: my_helper
INFO - 2023-09-28 21:16:21 --> Database Driver Class Initialized
INFO - 2023-09-28 21:16:21 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-28 21:16:21 --> Controller Class Initialized
INFO - 2023-09-28 21:16:21 --> Final output sent to browser
DEBUG - 2023-09-28 21:16:21 --> Total execution time: 0.0380
INFO - 2023-09-28 21:16:21 --> Config Class Initialized
INFO - 2023-09-28 21:16:21 --> Hooks Class Initialized
DEBUG - 2023-09-28 21:16:21 --> UTF-8 Support Enabled
INFO - 2023-09-28 21:16:21 --> Utf8 Class Initialized
INFO - 2023-09-28 21:16:21 --> URI Class Initialized
INFO - 2023-09-28 21:16:21 --> Router Class Initialized
INFO - 2023-09-28 21:16:21 --> Output Class Initialized
INFO - 2023-09-28 21:16:21 --> Security Class Initialized
DEBUG - 2023-09-28 21:16:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-28 21:16:21 --> Input Class Initialized
INFO - 2023-09-28 21:16:21 --> Language Class Initialized
INFO - 2023-09-28 21:16:21 --> Language Class Initialized
INFO - 2023-09-28 21:16:21 --> Config Class Initialized
INFO - 2023-09-28 21:16:21 --> Loader Class Initialized
INFO - 2023-09-28 21:16:21 --> Helper loaded: url_helper
INFO - 2023-09-28 21:16:21 --> Helper loaded: file_helper
INFO - 2023-09-28 21:16:21 --> Helper loaded: form_helper
INFO - 2023-09-28 21:16:21 --> Helper loaded: my_helper
INFO - 2023-09-28 21:16:21 --> Database Driver Class Initialized
INFO - 2023-09-28 21:16:21 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-28 21:16:21 --> Controller Class Initialized
INFO - 2023-09-28 21:16:22 --> Config Class Initialized
INFO - 2023-09-28 21:16:22 --> Hooks Class Initialized
DEBUG - 2023-09-28 21:16:22 --> UTF-8 Support Enabled
INFO - 2023-09-28 21:16:22 --> Utf8 Class Initialized
INFO - 2023-09-28 21:16:22 --> URI Class Initialized
INFO - 2023-09-28 21:16:22 --> Router Class Initialized
INFO - 2023-09-28 21:16:22 --> Output Class Initialized
INFO - 2023-09-28 21:16:22 --> Security Class Initialized
DEBUG - 2023-09-28 21:16:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-28 21:16:22 --> Input Class Initialized
INFO - 2023-09-28 21:16:22 --> Language Class Initialized
INFO - 2023-09-28 21:16:22 --> Language Class Initialized
INFO - 2023-09-28 21:16:22 --> Config Class Initialized
INFO - 2023-09-28 21:16:22 --> Loader Class Initialized
INFO - 2023-09-28 21:16:22 --> Helper loaded: url_helper
INFO - 2023-09-28 21:16:22 --> Helper loaded: file_helper
INFO - 2023-09-28 21:16:22 --> Helper loaded: form_helper
INFO - 2023-09-28 21:16:22 --> Helper loaded: my_helper
INFO - 2023-09-28 21:16:22 --> Database Driver Class Initialized
INFO - 2023-09-28 21:16:22 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-28 21:16:22 --> Controller Class Initialized
INFO - 2023-09-28 21:16:22 --> Final output sent to browser
DEBUG - 2023-09-28 21:16:22 --> Total execution time: 0.0426
INFO - 2023-09-28 21:16:22 --> Config Class Initialized
INFO - 2023-09-28 21:16:22 --> Hooks Class Initialized
DEBUG - 2023-09-28 21:16:22 --> UTF-8 Support Enabled
INFO - 2023-09-28 21:16:22 --> Utf8 Class Initialized
INFO - 2023-09-28 21:16:22 --> URI Class Initialized
INFO - 2023-09-28 21:16:22 --> Router Class Initialized
INFO - 2023-09-28 21:16:22 --> Output Class Initialized
INFO - 2023-09-28 21:16:22 --> Security Class Initialized
DEBUG - 2023-09-28 21:16:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-28 21:16:22 --> Input Class Initialized
INFO - 2023-09-28 21:16:22 --> Language Class Initialized
INFO - 2023-09-28 21:16:22 --> Language Class Initialized
INFO - 2023-09-28 21:16:22 --> Config Class Initialized
INFO - 2023-09-28 21:16:22 --> Loader Class Initialized
INFO - 2023-09-28 21:16:22 --> Helper loaded: url_helper
INFO - 2023-09-28 21:16:22 --> Helper loaded: file_helper
INFO - 2023-09-28 21:16:22 --> Helper loaded: form_helper
INFO - 2023-09-28 21:16:22 --> Helper loaded: my_helper
INFO - 2023-09-28 21:16:22 --> Database Driver Class Initialized
INFO - 2023-09-28 21:16:22 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-28 21:16:22 --> Controller Class Initialized
INFO - 2023-09-28 21:16:23 --> Config Class Initialized
INFO - 2023-09-28 21:16:23 --> Hooks Class Initialized
DEBUG - 2023-09-28 21:16:23 --> UTF-8 Support Enabled
INFO - 2023-09-28 21:16:23 --> Utf8 Class Initialized
INFO - 2023-09-28 21:16:23 --> URI Class Initialized
INFO - 2023-09-28 21:16:23 --> Router Class Initialized
INFO - 2023-09-28 21:16:23 --> Output Class Initialized
INFO - 2023-09-28 21:16:23 --> Security Class Initialized
DEBUG - 2023-09-28 21:16:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-28 21:16:23 --> Input Class Initialized
INFO - 2023-09-28 21:16:23 --> Language Class Initialized
INFO - 2023-09-28 21:16:23 --> Language Class Initialized
INFO - 2023-09-28 21:16:23 --> Config Class Initialized
INFO - 2023-09-28 21:16:23 --> Loader Class Initialized
INFO - 2023-09-28 21:16:23 --> Helper loaded: url_helper
INFO - 2023-09-28 21:16:23 --> Helper loaded: file_helper
INFO - 2023-09-28 21:16:23 --> Helper loaded: form_helper
INFO - 2023-09-28 21:16:23 --> Helper loaded: my_helper
INFO - 2023-09-28 21:16:23 --> Database Driver Class Initialized
INFO - 2023-09-28 21:16:23 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-28 21:16:23 --> Controller Class Initialized
INFO - 2023-09-28 21:16:23 --> Final output sent to browser
DEBUG - 2023-09-28 21:16:23 --> Total execution time: 0.0445
INFO - 2023-09-28 21:16:23 --> Config Class Initialized
INFO - 2023-09-28 21:16:23 --> Hooks Class Initialized
DEBUG - 2023-09-28 21:16:23 --> UTF-8 Support Enabled
INFO - 2023-09-28 21:16:23 --> Utf8 Class Initialized
INFO - 2023-09-28 21:16:23 --> URI Class Initialized
INFO - 2023-09-28 21:16:23 --> Router Class Initialized
INFO - 2023-09-28 21:16:23 --> Output Class Initialized
INFO - 2023-09-28 21:16:23 --> Security Class Initialized
DEBUG - 2023-09-28 21:16:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-28 21:16:23 --> Input Class Initialized
INFO - 2023-09-28 21:16:23 --> Language Class Initialized
INFO - 2023-09-28 21:16:23 --> Language Class Initialized
INFO - 2023-09-28 21:16:23 --> Config Class Initialized
INFO - 2023-09-28 21:16:23 --> Loader Class Initialized
INFO - 2023-09-28 21:16:23 --> Helper loaded: url_helper
INFO - 2023-09-28 21:16:23 --> Helper loaded: file_helper
INFO - 2023-09-28 21:16:23 --> Helper loaded: form_helper
INFO - 2023-09-28 21:16:23 --> Helper loaded: my_helper
INFO - 2023-09-28 21:16:23 --> Database Driver Class Initialized
INFO - 2023-09-28 21:16:23 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-28 21:16:23 --> Controller Class Initialized
INFO - 2023-09-28 21:16:25 --> Config Class Initialized
INFO - 2023-09-28 21:16:25 --> Hooks Class Initialized
DEBUG - 2023-09-28 21:16:25 --> UTF-8 Support Enabled
INFO - 2023-09-28 21:16:25 --> Utf8 Class Initialized
INFO - 2023-09-28 21:16:25 --> URI Class Initialized
INFO - 2023-09-28 21:16:25 --> Router Class Initialized
INFO - 2023-09-28 21:16:25 --> Output Class Initialized
INFO - 2023-09-28 21:16:25 --> Security Class Initialized
DEBUG - 2023-09-28 21:16:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-28 21:16:25 --> Input Class Initialized
INFO - 2023-09-28 21:16:25 --> Language Class Initialized
INFO - 2023-09-28 21:16:25 --> Language Class Initialized
INFO - 2023-09-28 21:16:25 --> Config Class Initialized
INFO - 2023-09-28 21:16:25 --> Loader Class Initialized
INFO - 2023-09-28 21:16:25 --> Helper loaded: url_helper
INFO - 2023-09-28 21:16:25 --> Helper loaded: file_helper
INFO - 2023-09-28 21:16:25 --> Helper loaded: form_helper
INFO - 2023-09-28 21:16:25 --> Helper loaded: my_helper
INFO - 2023-09-28 21:16:25 --> Database Driver Class Initialized
INFO - 2023-09-28 21:16:25 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-28 21:16:25 --> Controller Class Initialized
INFO - 2023-09-28 21:16:25 --> Final output sent to browser
DEBUG - 2023-09-28 21:16:25 --> Total execution time: 0.0462
INFO - 2023-09-28 21:16:25 --> Config Class Initialized
INFO - 2023-09-28 21:16:25 --> Hooks Class Initialized
DEBUG - 2023-09-28 21:16:25 --> UTF-8 Support Enabled
INFO - 2023-09-28 21:16:25 --> Utf8 Class Initialized
INFO - 2023-09-28 21:16:25 --> URI Class Initialized
INFO - 2023-09-28 21:16:25 --> Router Class Initialized
INFO - 2023-09-28 21:16:25 --> Output Class Initialized
INFO - 2023-09-28 21:16:25 --> Security Class Initialized
DEBUG - 2023-09-28 21:16:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-28 21:16:25 --> Input Class Initialized
INFO - 2023-09-28 21:16:25 --> Language Class Initialized
INFO - 2023-09-28 21:16:25 --> Language Class Initialized
INFO - 2023-09-28 21:16:25 --> Config Class Initialized
INFO - 2023-09-28 21:16:25 --> Loader Class Initialized
INFO - 2023-09-28 21:16:25 --> Helper loaded: url_helper
INFO - 2023-09-28 21:16:25 --> Helper loaded: file_helper
INFO - 2023-09-28 21:16:25 --> Helper loaded: form_helper
INFO - 2023-09-28 21:16:25 --> Helper loaded: my_helper
INFO - 2023-09-28 21:16:25 --> Database Driver Class Initialized
INFO - 2023-09-28 21:16:25 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-28 21:16:25 --> Controller Class Initialized
INFO - 2023-09-28 21:16:27 --> Config Class Initialized
INFO - 2023-09-28 21:16:27 --> Hooks Class Initialized
DEBUG - 2023-09-28 21:16:27 --> UTF-8 Support Enabled
INFO - 2023-09-28 21:16:27 --> Utf8 Class Initialized
INFO - 2023-09-28 21:16:27 --> URI Class Initialized
INFO - 2023-09-28 21:16:27 --> Router Class Initialized
INFO - 2023-09-28 21:16:27 --> Output Class Initialized
INFO - 2023-09-28 21:16:27 --> Security Class Initialized
DEBUG - 2023-09-28 21:16:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-28 21:16:27 --> Input Class Initialized
INFO - 2023-09-28 21:16:27 --> Language Class Initialized
INFO - 2023-09-28 21:16:27 --> Language Class Initialized
INFO - 2023-09-28 21:16:27 --> Config Class Initialized
INFO - 2023-09-28 21:16:27 --> Loader Class Initialized
INFO - 2023-09-28 21:16:27 --> Helper loaded: url_helper
INFO - 2023-09-28 21:16:27 --> Helper loaded: file_helper
INFO - 2023-09-28 21:16:27 --> Helper loaded: form_helper
INFO - 2023-09-28 21:16:27 --> Helper loaded: my_helper
INFO - 2023-09-28 21:16:27 --> Database Driver Class Initialized
INFO - 2023-09-28 21:16:27 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-28 21:16:27 --> Controller Class Initialized
INFO - 2023-09-28 21:16:27 --> Final output sent to browser
DEBUG - 2023-09-28 21:16:27 --> Total execution time: 0.1533
INFO - 2023-09-28 21:16:27 --> Config Class Initialized
INFO - 2023-09-28 21:16:27 --> Hooks Class Initialized
DEBUG - 2023-09-28 21:16:27 --> UTF-8 Support Enabled
INFO - 2023-09-28 21:16:27 --> Utf8 Class Initialized
INFO - 2023-09-28 21:16:27 --> URI Class Initialized
INFO - 2023-09-28 21:16:27 --> Router Class Initialized
INFO - 2023-09-28 21:16:27 --> Output Class Initialized
INFO - 2023-09-28 21:16:27 --> Security Class Initialized
DEBUG - 2023-09-28 21:16:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-28 21:16:27 --> Input Class Initialized
INFO - 2023-09-28 21:16:27 --> Language Class Initialized
INFO - 2023-09-28 21:16:27 --> Language Class Initialized
INFO - 2023-09-28 21:16:27 --> Config Class Initialized
INFO - 2023-09-28 21:16:27 --> Loader Class Initialized
INFO - 2023-09-28 21:16:27 --> Helper loaded: url_helper
INFO - 2023-09-28 21:16:27 --> Helper loaded: file_helper
INFO - 2023-09-28 21:16:27 --> Helper loaded: form_helper
INFO - 2023-09-28 21:16:27 --> Helper loaded: my_helper
INFO - 2023-09-28 21:16:27 --> Database Driver Class Initialized
INFO - 2023-09-28 21:16:27 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-28 21:16:27 --> Controller Class Initialized
INFO - 2023-09-28 21:16:30 --> Config Class Initialized
INFO - 2023-09-28 21:16:30 --> Hooks Class Initialized
DEBUG - 2023-09-28 21:16:30 --> UTF-8 Support Enabled
INFO - 2023-09-28 21:16:30 --> Utf8 Class Initialized
INFO - 2023-09-28 21:16:30 --> URI Class Initialized
INFO - 2023-09-28 21:16:30 --> Router Class Initialized
INFO - 2023-09-28 21:16:30 --> Output Class Initialized
INFO - 2023-09-28 21:16:30 --> Security Class Initialized
DEBUG - 2023-09-28 21:16:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-28 21:16:30 --> Input Class Initialized
INFO - 2023-09-28 21:16:30 --> Language Class Initialized
INFO - 2023-09-28 21:16:30 --> Language Class Initialized
INFO - 2023-09-28 21:16:30 --> Config Class Initialized
INFO - 2023-09-28 21:16:30 --> Loader Class Initialized
INFO - 2023-09-28 21:16:30 --> Helper loaded: url_helper
INFO - 2023-09-28 21:16:30 --> Helper loaded: file_helper
INFO - 2023-09-28 21:16:30 --> Helper loaded: form_helper
INFO - 2023-09-28 21:16:30 --> Helper loaded: my_helper
INFO - 2023-09-28 21:16:30 --> Database Driver Class Initialized
INFO - 2023-09-28 21:16:30 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-28 21:16:30 --> Controller Class Initialized
INFO - 2023-09-28 21:16:30 --> Final output sent to browser
DEBUG - 2023-09-28 21:16:30 --> Total execution time: 0.0524
INFO - 2023-09-28 21:16:30 --> Config Class Initialized
INFO - 2023-09-28 21:16:30 --> Hooks Class Initialized
DEBUG - 2023-09-28 21:16:30 --> UTF-8 Support Enabled
INFO - 2023-09-28 21:16:30 --> Utf8 Class Initialized
INFO - 2023-09-28 21:16:30 --> URI Class Initialized
INFO - 2023-09-28 21:16:30 --> Router Class Initialized
INFO - 2023-09-28 21:16:30 --> Output Class Initialized
INFO - 2023-09-28 21:16:30 --> Security Class Initialized
DEBUG - 2023-09-28 21:16:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-28 21:16:30 --> Input Class Initialized
INFO - 2023-09-28 21:16:30 --> Language Class Initialized
INFO - 2023-09-28 21:16:30 --> Language Class Initialized
INFO - 2023-09-28 21:16:30 --> Config Class Initialized
INFO - 2023-09-28 21:16:30 --> Loader Class Initialized
INFO - 2023-09-28 21:16:30 --> Helper loaded: url_helper
INFO - 2023-09-28 21:16:30 --> Helper loaded: file_helper
INFO - 2023-09-28 21:16:30 --> Helper loaded: form_helper
INFO - 2023-09-28 21:16:30 --> Helper loaded: my_helper
INFO - 2023-09-28 21:16:30 --> Database Driver Class Initialized
INFO - 2023-09-28 21:16:30 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-28 21:16:30 --> Controller Class Initialized
INFO - 2023-09-28 21:16:31 --> Config Class Initialized
INFO - 2023-09-28 21:16:31 --> Hooks Class Initialized
DEBUG - 2023-09-28 21:16:31 --> UTF-8 Support Enabled
INFO - 2023-09-28 21:16:31 --> Utf8 Class Initialized
INFO - 2023-09-28 21:16:31 --> URI Class Initialized
INFO - 2023-09-28 21:16:31 --> Router Class Initialized
INFO - 2023-09-28 21:16:31 --> Output Class Initialized
INFO - 2023-09-28 21:16:31 --> Security Class Initialized
DEBUG - 2023-09-28 21:16:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-28 21:16:31 --> Input Class Initialized
INFO - 2023-09-28 21:16:31 --> Language Class Initialized
INFO - 2023-09-28 21:16:31 --> Language Class Initialized
INFO - 2023-09-28 21:16:31 --> Config Class Initialized
INFO - 2023-09-28 21:16:31 --> Loader Class Initialized
INFO - 2023-09-28 21:16:31 --> Helper loaded: url_helper
INFO - 2023-09-28 21:16:31 --> Helper loaded: file_helper
INFO - 2023-09-28 21:16:31 --> Helper loaded: form_helper
INFO - 2023-09-28 21:16:31 --> Helper loaded: my_helper
INFO - 2023-09-28 21:16:31 --> Database Driver Class Initialized
INFO - 2023-09-28 21:16:31 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-28 21:16:31 --> Controller Class Initialized
INFO - 2023-09-28 21:16:31 --> Final output sent to browser
DEBUG - 2023-09-28 21:16:31 --> Total execution time: 0.0498
INFO - 2023-09-28 21:16:31 --> Config Class Initialized
INFO - 2023-09-28 21:16:31 --> Hooks Class Initialized
DEBUG - 2023-09-28 21:16:31 --> UTF-8 Support Enabled
INFO - 2023-09-28 21:16:31 --> Utf8 Class Initialized
INFO - 2023-09-28 21:16:31 --> URI Class Initialized
INFO - 2023-09-28 21:16:31 --> Router Class Initialized
INFO - 2023-09-28 21:16:31 --> Output Class Initialized
INFO - 2023-09-28 21:16:31 --> Security Class Initialized
DEBUG - 2023-09-28 21:16:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-28 21:16:31 --> Input Class Initialized
INFO - 2023-09-28 21:16:31 --> Language Class Initialized
INFO - 2023-09-28 21:16:31 --> Language Class Initialized
INFO - 2023-09-28 21:16:31 --> Config Class Initialized
INFO - 2023-09-28 21:16:31 --> Loader Class Initialized
INFO - 2023-09-28 21:16:31 --> Helper loaded: url_helper
INFO - 2023-09-28 21:16:31 --> Helper loaded: file_helper
INFO - 2023-09-28 21:16:31 --> Helper loaded: form_helper
INFO - 2023-09-28 21:16:31 --> Helper loaded: my_helper
INFO - 2023-09-28 21:16:31 --> Database Driver Class Initialized
INFO - 2023-09-28 21:16:31 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-28 21:16:31 --> Controller Class Initialized
INFO - 2023-09-28 21:16:32 --> Config Class Initialized
INFO - 2023-09-28 21:16:32 --> Hooks Class Initialized
DEBUG - 2023-09-28 21:16:32 --> UTF-8 Support Enabled
INFO - 2023-09-28 21:16:32 --> Utf8 Class Initialized
INFO - 2023-09-28 21:16:32 --> URI Class Initialized
INFO - 2023-09-28 21:16:32 --> Router Class Initialized
INFO - 2023-09-28 21:16:32 --> Output Class Initialized
INFO - 2023-09-28 21:16:32 --> Security Class Initialized
DEBUG - 2023-09-28 21:16:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-28 21:16:32 --> Input Class Initialized
INFO - 2023-09-28 21:16:32 --> Language Class Initialized
INFO - 2023-09-28 21:16:32 --> Language Class Initialized
INFO - 2023-09-28 21:16:32 --> Config Class Initialized
INFO - 2023-09-28 21:16:32 --> Loader Class Initialized
INFO - 2023-09-28 21:16:32 --> Helper loaded: url_helper
INFO - 2023-09-28 21:16:32 --> Helper loaded: file_helper
INFO - 2023-09-28 21:16:32 --> Helper loaded: form_helper
INFO - 2023-09-28 21:16:32 --> Helper loaded: my_helper
INFO - 2023-09-28 21:16:32 --> Database Driver Class Initialized
INFO - 2023-09-28 21:16:32 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-28 21:16:32 --> Controller Class Initialized
INFO - 2023-09-28 21:16:32 --> Final output sent to browser
DEBUG - 2023-09-28 21:16:32 --> Total execution time: 0.0380
INFO - 2023-09-28 21:16:32 --> Config Class Initialized
INFO - 2023-09-28 21:16:32 --> Hooks Class Initialized
DEBUG - 2023-09-28 21:16:32 --> UTF-8 Support Enabled
INFO - 2023-09-28 21:16:32 --> Utf8 Class Initialized
INFO - 2023-09-28 21:16:32 --> URI Class Initialized
INFO - 2023-09-28 21:16:32 --> Router Class Initialized
INFO - 2023-09-28 21:16:32 --> Output Class Initialized
INFO - 2023-09-28 21:16:32 --> Security Class Initialized
DEBUG - 2023-09-28 21:16:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-28 21:16:32 --> Input Class Initialized
INFO - 2023-09-28 21:16:32 --> Language Class Initialized
INFO - 2023-09-28 21:16:32 --> Language Class Initialized
INFO - 2023-09-28 21:16:32 --> Config Class Initialized
INFO - 2023-09-28 21:16:32 --> Loader Class Initialized
INFO - 2023-09-28 21:16:32 --> Helper loaded: url_helper
INFO - 2023-09-28 21:16:32 --> Helper loaded: file_helper
INFO - 2023-09-28 21:16:32 --> Helper loaded: form_helper
INFO - 2023-09-28 21:16:32 --> Helper loaded: my_helper
INFO - 2023-09-28 21:16:32 --> Database Driver Class Initialized
INFO - 2023-09-28 21:16:32 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-28 21:16:32 --> Controller Class Initialized
INFO - 2023-09-28 21:16:33 --> Config Class Initialized
INFO - 2023-09-28 21:16:33 --> Hooks Class Initialized
DEBUG - 2023-09-28 21:16:33 --> UTF-8 Support Enabled
INFO - 2023-09-28 21:16:33 --> Utf8 Class Initialized
INFO - 2023-09-28 21:16:33 --> URI Class Initialized
INFO - 2023-09-28 21:16:33 --> Router Class Initialized
INFO - 2023-09-28 21:16:33 --> Output Class Initialized
INFO - 2023-09-28 21:16:33 --> Security Class Initialized
DEBUG - 2023-09-28 21:16:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-28 21:16:33 --> Input Class Initialized
INFO - 2023-09-28 21:16:33 --> Language Class Initialized
INFO - 2023-09-28 21:16:33 --> Language Class Initialized
INFO - 2023-09-28 21:16:33 --> Config Class Initialized
INFO - 2023-09-28 21:16:33 --> Loader Class Initialized
INFO - 2023-09-28 21:16:33 --> Helper loaded: url_helper
INFO - 2023-09-28 21:16:33 --> Helper loaded: file_helper
INFO - 2023-09-28 21:16:33 --> Helper loaded: form_helper
INFO - 2023-09-28 21:16:33 --> Helper loaded: my_helper
INFO - 2023-09-28 21:16:33 --> Database Driver Class Initialized
INFO - 2023-09-28 21:16:33 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-28 21:16:33 --> Controller Class Initialized
INFO - 2023-09-28 21:16:33 --> Final output sent to browser
DEBUG - 2023-09-28 21:16:33 --> Total execution time: 0.0450
INFO - 2023-09-28 21:16:33 --> Config Class Initialized
INFO - 2023-09-28 21:16:33 --> Hooks Class Initialized
DEBUG - 2023-09-28 21:16:33 --> UTF-8 Support Enabled
INFO - 2023-09-28 21:16:33 --> Utf8 Class Initialized
INFO - 2023-09-28 21:16:33 --> URI Class Initialized
INFO - 2023-09-28 21:16:33 --> Router Class Initialized
INFO - 2023-09-28 21:16:33 --> Output Class Initialized
INFO - 2023-09-28 21:16:33 --> Security Class Initialized
DEBUG - 2023-09-28 21:16:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-28 21:16:33 --> Input Class Initialized
INFO - 2023-09-28 21:16:33 --> Language Class Initialized
INFO - 2023-09-28 21:16:33 --> Language Class Initialized
INFO - 2023-09-28 21:16:33 --> Config Class Initialized
INFO - 2023-09-28 21:16:33 --> Loader Class Initialized
INFO - 2023-09-28 21:16:33 --> Helper loaded: url_helper
INFO - 2023-09-28 21:16:33 --> Helper loaded: file_helper
INFO - 2023-09-28 21:16:33 --> Helper loaded: form_helper
INFO - 2023-09-28 21:16:33 --> Helper loaded: my_helper
INFO - 2023-09-28 21:16:33 --> Database Driver Class Initialized
INFO - 2023-09-28 21:16:33 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-28 21:16:33 --> Controller Class Initialized
INFO - 2023-09-28 21:16:34 --> Config Class Initialized
INFO - 2023-09-28 21:16:34 --> Hooks Class Initialized
DEBUG - 2023-09-28 21:16:34 --> UTF-8 Support Enabled
INFO - 2023-09-28 21:16:34 --> Utf8 Class Initialized
INFO - 2023-09-28 21:16:34 --> URI Class Initialized
INFO - 2023-09-28 21:16:34 --> Router Class Initialized
INFO - 2023-09-28 21:16:34 --> Output Class Initialized
INFO - 2023-09-28 21:16:34 --> Security Class Initialized
DEBUG - 2023-09-28 21:16:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-28 21:16:34 --> Input Class Initialized
INFO - 2023-09-28 21:16:34 --> Language Class Initialized
INFO - 2023-09-28 21:16:34 --> Language Class Initialized
INFO - 2023-09-28 21:16:34 --> Config Class Initialized
INFO - 2023-09-28 21:16:34 --> Loader Class Initialized
INFO - 2023-09-28 21:16:34 --> Helper loaded: url_helper
INFO - 2023-09-28 21:16:34 --> Helper loaded: file_helper
INFO - 2023-09-28 21:16:34 --> Helper loaded: form_helper
INFO - 2023-09-28 21:16:34 --> Helper loaded: my_helper
INFO - 2023-09-28 21:16:34 --> Database Driver Class Initialized
INFO - 2023-09-28 21:16:34 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-28 21:16:34 --> Controller Class Initialized
INFO - 2023-09-28 21:16:34 --> Final output sent to browser
DEBUG - 2023-09-28 21:16:34 --> Total execution time: 0.0417
INFO - 2023-09-28 21:16:34 --> Config Class Initialized
INFO - 2023-09-28 21:16:34 --> Hooks Class Initialized
DEBUG - 2023-09-28 21:16:34 --> UTF-8 Support Enabled
INFO - 2023-09-28 21:16:34 --> Utf8 Class Initialized
INFO - 2023-09-28 21:16:34 --> URI Class Initialized
INFO - 2023-09-28 21:16:34 --> Router Class Initialized
INFO - 2023-09-28 21:16:34 --> Output Class Initialized
INFO - 2023-09-28 21:16:34 --> Security Class Initialized
DEBUG - 2023-09-28 21:16:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-28 21:16:34 --> Input Class Initialized
INFO - 2023-09-28 21:16:34 --> Language Class Initialized
INFO - 2023-09-28 21:16:34 --> Language Class Initialized
INFO - 2023-09-28 21:16:34 --> Config Class Initialized
INFO - 2023-09-28 21:16:34 --> Loader Class Initialized
INFO - 2023-09-28 21:16:34 --> Helper loaded: url_helper
INFO - 2023-09-28 21:16:34 --> Helper loaded: file_helper
INFO - 2023-09-28 21:16:34 --> Helper loaded: form_helper
INFO - 2023-09-28 21:16:34 --> Helper loaded: my_helper
INFO - 2023-09-28 21:16:34 --> Database Driver Class Initialized
INFO - 2023-09-28 21:16:34 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-28 21:16:34 --> Controller Class Initialized
INFO - 2023-09-28 21:16:35 --> Config Class Initialized
INFO - 2023-09-28 21:16:35 --> Hooks Class Initialized
DEBUG - 2023-09-28 21:16:35 --> UTF-8 Support Enabled
INFO - 2023-09-28 21:16:35 --> Utf8 Class Initialized
INFO - 2023-09-28 21:16:35 --> URI Class Initialized
INFO - 2023-09-28 21:16:35 --> Router Class Initialized
INFO - 2023-09-28 21:16:35 --> Output Class Initialized
INFO - 2023-09-28 21:16:35 --> Security Class Initialized
DEBUG - 2023-09-28 21:16:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-28 21:16:35 --> Input Class Initialized
INFO - 2023-09-28 21:16:35 --> Language Class Initialized
INFO - 2023-09-28 21:16:35 --> Language Class Initialized
INFO - 2023-09-28 21:16:35 --> Config Class Initialized
INFO - 2023-09-28 21:16:35 --> Loader Class Initialized
INFO - 2023-09-28 21:16:35 --> Helper loaded: url_helper
INFO - 2023-09-28 21:16:35 --> Helper loaded: file_helper
INFO - 2023-09-28 21:16:35 --> Helper loaded: form_helper
INFO - 2023-09-28 21:16:35 --> Helper loaded: my_helper
INFO - 2023-09-28 21:16:35 --> Database Driver Class Initialized
INFO - 2023-09-28 21:16:35 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-28 21:16:35 --> Controller Class Initialized
INFO - 2023-09-28 21:16:35 --> Final output sent to browser
DEBUG - 2023-09-28 21:16:35 --> Total execution time: 0.0588
INFO - 2023-09-28 21:16:35 --> Config Class Initialized
INFO - 2023-09-28 21:16:35 --> Hooks Class Initialized
DEBUG - 2023-09-28 21:16:35 --> UTF-8 Support Enabled
INFO - 2023-09-28 21:16:35 --> Utf8 Class Initialized
INFO - 2023-09-28 21:16:35 --> URI Class Initialized
INFO - 2023-09-28 21:16:35 --> Router Class Initialized
INFO - 2023-09-28 21:16:35 --> Output Class Initialized
INFO - 2023-09-28 21:16:35 --> Security Class Initialized
DEBUG - 2023-09-28 21:16:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-28 21:16:35 --> Input Class Initialized
INFO - 2023-09-28 21:16:35 --> Language Class Initialized
INFO - 2023-09-28 21:16:35 --> Language Class Initialized
INFO - 2023-09-28 21:16:35 --> Config Class Initialized
INFO - 2023-09-28 21:16:35 --> Loader Class Initialized
INFO - 2023-09-28 21:16:35 --> Helper loaded: url_helper
INFO - 2023-09-28 21:16:35 --> Helper loaded: file_helper
INFO - 2023-09-28 21:16:36 --> Helper loaded: form_helper
INFO - 2023-09-28 21:16:36 --> Helper loaded: my_helper
INFO - 2023-09-28 21:16:36 --> Database Driver Class Initialized
INFO - 2023-09-28 21:16:36 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-28 21:16:36 --> Controller Class Initialized
INFO - 2023-09-28 21:16:37 --> Config Class Initialized
INFO - 2023-09-28 21:16:37 --> Hooks Class Initialized
DEBUG - 2023-09-28 21:16:37 --> UTF-8 Support Enabled
INFO - 2023-09-28 21:16:37 --> Utf8 Class Initialized
INFO - 2023-09-28 21:16:37 --> URI Class Initialized
INFO - 2023-09-28 21:16:37 --> Router Class Initialized
INFO - 2023-09-28 21:16:37 --> Output Class Initialized
INFO - 2023-09-28 21:16:37 --> Security Class Initialized
DEBUG - 2023-09-28 21:16:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-28 21:16:37 --> Input Class Initialized
INFO - 2023-09-28 21:16:37 --> Language Class Initialized
INFO - 2023-09-28 21:16:37 --> Language Class Initialized
INFO - 2023-09-28 21:16:37 --> Config Class Initialized
INFO - 2023-09-28 21:16:37 --> Loader Class Initialized
INFO - 2023-09-28 21:16:37 --> Helper loaded: url_helper
INFO - 2023-09-28 21:16:37 --> Helper loaded: file_helper
INFO - 2023-09-28 21:16:37 --> Helper loaded: form_helper
INFO - 2023-09-28 21:16:37 --> Helper loaded: my_helper
INFO - 2023-09-28 21:16:37 --> Database Driver Class Initialized
INFO - 2023-09-28 21:16:37 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-28 21:16:37 --> Controller Class Initialized
INFO - 2023-09-28 21:16:37 --> Final output sent to browser
DEBUG - 2023-09-28 21:16:37 --> Total execution time: 0.0384
INFO - 2023-09-28 21:16:37 --> Config Class Initialized
INFO - 2023-09-28 21:16:37 --> Hooks Class Initialized
DEBUG - 2023-09-28 21:16:37 --> UTF-8 Support Enabled
INFO - 2023-09-28 21:16:37 --> Utf8 Class Initialized
INFO - 2023-09-28 21:16:37 --> URI Class Initialized
INFO - 2023-09-28 21:16:37 --> Router Class Initialized
INFO - 2023-09-28 21:16:37 --> Output Class Initialized
INFO - 2023-09-28 21:16:37 --> Security Class Initialized
DEBUG - 2023-09-28 21:16:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-28 21:16:37 --> Input Class Initialized
INFO - 2023-09-28 21:16:37 --> Language Class Initialized
INFO - 2023-09-28 21:16:37 --> Language Class Initialized
INFO - 2023-09-28 21:16:37 --> Config Class Initialized
INFO - 2023-09-28 21:16:37 --> Loader Class Initialized
INFO - 2023-09-28 21:16:37 --> Helper loaded: url_helper
INFO - 2023-09-28 21:16:37 --> Helper loaded: file_helper
INFO - 2023-09-28 21:16:37 --> Helper loaded: form_helper
INFO - 2023-09-28 21:16:37 --> Helper loaded: my_helper
INFO - 2023-09-28 21:16:37 --> Database Driver Class Initialized
INFO - 2023-09-28 21:16:37 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-28 21:16:37 --> Controller Class Initialized
INFO - 2023-09-28 21:16:38 --> Config Class Initialized
INFO - 2023-09-28 21:16:38 --> Hooks Class Initialized
DEBUG - 2023-09-28 21:16:38 --> UTF-8 Support Enabled
INFO - 2023-09-28 21:16:38 --> Utf8 Class Initialized
INFO - 2023-09-28 21:16:38 --> URI Class Initialized
INFO - 2023-09-28 21:16:38 --> Router Class Initialized
INFO - 2023-09-28 21:16:38 --> Output Class Initialized
INFO - 2023-09-28 21:16:38 --> Security Class Initialized
DEBUG - 2023-09-28 21:16:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-28 21:16:38 --> Input Class Initialized
INFO - 2023-09-28 21:16:38 --> Language Class Initialized
INFO - 2023-09-28 21:16:38 --> Language Class Initialized
INFO - 2023-09-28 21:16:38 --> Config Class Initialized
INFO - 2023-09-28 21:16:38 --> Loader Class Initialized
INFO - 2023-09-28 21:16:38 --> Helper loaded: url_helper
INFO - 2023-09-28 21:16:38 --> Helper loaded: file_helper
INFO - 2023-09-28 21:16:38 --> Helper loaded: form_helper
INFO - 2023-09-28 21:16:38 --> Helper loaded: my_helper
INFO - 2023-09-28 21:16:38 --> Database Driver Class Initialized
INFO - 2023-09-28 21:16:38 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-28 21:16:38 --> Controller Class Initialized
INFO - 2023-09-28 21:16:38 --> Final output sent to browser
DEBUG - 2023-09-28 21:16:38 --> Total execution time: 0.0704
INFO - 2023-09-28 21:16:38 --> Config Class Initialized
INFO - 2023-09-28 21:16:38 --> Hooks Class Initialized
DEBUG - 2023-09-28 21:16:38 --> UTF-8 Support Enabled
INFO - 2023-09-28 21:16:38 --> Utf8 Class Initialized
INFO - 2023-09-28 21:16:38 --> URI Class Initialized
INFO - 2023-09-28 21:16:38 --> Router Class Initialized
INFO - 2023-09-28 21:16:38 --> Output Class Initialized
INFO - 2023-09-28 21:16:38 --> Security Class Initialized
DEBUG - 2023-09-28 21:16:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-28 21:16:38 --> Input Class Initialized
INFO - 2023-09-28 21:16:38 --> Language Class Initialized
INFO - 2023-09-28 21:16:38 --> Language Class Initialized
INFO - 2023-09-28 21:16:38 --> Config Class Initialized
INFO - 2023-09-28 21:16:38 --> Loader Class Initialized
INFO - 2023-09-28 21:16:38 --> Helper loaded: url_helper
INFO - 2023-09-28 21:16:38 --> Helper loaded: file_helper
INFO - 2023-09-28 21:16:38 --> Helper loaded: form_helper
INFO - 2023-09-28 21:16:38 --> Helper loaded: my_helper
INFO - 2023-09-28 21:16:38 --> Database Driver Class Initialized
INFO - 2023-09-28 21:16:38 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-28 21:16:38 --> Controller Class Initialized
INFO - 2023-09-28 21:16:39 --> Config Class Initialized
INFO - 2023-09-28 21:16:39 --> Hooks Class Initialized
DEBUG - 2023-09-28 21:16:39 --> UTF-8 Support Enabled
INFO - 2023-09-28 21:16:39 --> Utf8 Class Initialized
INFO - 2023-09-28 21:16:39 --> URI Class Initialized
INFO - 2023-09-28 21:16:39 --> Router Class Initialized
INFO - 2023-09-28 21:16:39 --> Output Class Initialized
INFO - 2023-09-28 21:16:39 --> Security Class Initialized
DEBUG - 2023-09-28 21:16:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-28 21:16:39 --> Input Class Initialized
INFO - 2023-09-28 21:16:39 --> Language Class Initialized
INFO - 2023-09-28 21:16:39 --> Language Class Initialized
INFO - 2023-09-28 21:16:39 --> Config Class Initialized
INFO - 2023-09-28 21:16:39 --> Loader Class Initialized
INFO - 2023-09-28 21:16:39 --> Helper loaded: url_helper
INFO - 2023-09-28 21:16:39 --> Helper loaded: file_helper
INFO - 2023-09-28 21:16:39 --> Helper loaded: form_helper
INFO - 2023-09-28 21:16:39 --> Helper loaded: my_helper
INFO - 2023-09-28 21:16:39 --> Database Driver Class Initialized
INFO - 2023-09-28 21:16:39 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-28 21:16:39 --> Controller Class Initialized
INFO - 2023-09-28 21:16:39 --> Final output sent to browser
DEBUG - 2023-09-28 21:16:39 --> Total execution time: 0.1343
INFO - 2023-09-28 21:16:39 --> Config Class Initialized
INFO - 2023-09-28 21:16:39 --> Hooks Class Initialized
DEBUG - 2023-09-28 21:16:39 --> UTF-8 Support Enabled
INFO - 2023-09-28 21:16:39 --> Utf8 Class Initialized
INFO - 2023-09-28 21:16:39 --> URI Class Initialized
INFO - 2023-09-28 21:16:39 --> Router Class Initialized
INFO - 2023-09-28 21:16:39 --> Output Class Initialized
INFO - 2023-09-28 21:16:39 --> Security Class Initialized
DEBUG - 2023-09-28 21:16:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-28 21:16:39 --> Input Class Initialized
INFO - 2023-09-28 21:16:39 --> Language Class Initialized
INFO - 2023-09-28 21:16:39 --> Language Class Initialized
INFO - 2023-09-28 21:16:39 --> Config Class Initialized
INFO - 2023-09-28 21:16:39 --> Loader Class Initialized
INFO - 2023-09-28 21:16:39 --> Helper loaded: url_helper
INFO - 2023-09-28 21:16:39 --> Helper loaded: file_helper
INFO - 2023-09-28 21:16:39 --> Helper loaded: form_helper
INFO - 2023-09-28 21:16:39 --> Helper loaded: my_helper
INFO - 2023-09-28 21:16:39 --> Database Driver Class Initialized
INFO - 2023-09-28 21:16:39 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-28 21:16:39 --> Controller Class Initialized
INFO - 2023-09-28 21:16:41 --> Config Class Initialized
INFO - 2023-09-28 21:16:41 --> Hooks Class Initialized
DEBUG - 2023-09-28 21:16:41 --> UTF-8 Support Enabled
INFO - 2023-09-28 21:16:41 --> Utf8 Class Initialized
INFO - 2023-09-28 21:16:41 --> URI Class Initialized
INFO - 2023-09-28 21:16:41 --> Router Class Initialized
INFO - 2023-09-28 21:16:41 --> Output Class Initialized
INFO - 2023-09-28 21:16:41 --> Security Class Initialized
DEBUG - 2023-09-28 21:16:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-28 21:16:41 --> Input Class Initialized
INFO - 2023-09-28 21:16:41 --> Language Class Initialized
INFO - 2023-09-28 21:16:41 --> Language Class Initialized
INFO - 2023-09-28 21:16:41 --> Config Class Initialized
INFO - 2023-09-28 21:16:41 --> Loader Class Initialized
INFO - 2023-09-28 21:16:41 --> Helper loaded: url_helper
INFO - 2023-09-28 21:16:41 --> Helper loaded: file_helper
INFO - 2023-09-28 21:16:41 --> Helper loaded: form_helper
INFO - 2023-09-28 21:16:41 --> Helper loaded: my_helper
INFO - 2023-09-28 21:16:41 --> Database Driver Class Initialized
INFO - 2023-09-28 21:16:41 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-28 21:16:41 --> Controller Class Initialized
INFO - 2023-09-28 21:16:41 --> Final output sent to browser
DEBUG - 2023-09-28 21:16:41 --> Total execution time: 0.0441
INFO - 2023-09-28 21:16:41 --> Config Class Initialized
INFO - 2023-09-28 21:16:41 --> Hooks Class Initialized
DEBUG - 2023-09-28 21:16:41 --> UTF-8 Support Enabled
INFO - 2023-09-28 21:16:41 --> Utf8 Class Initialized
INFO - 2023-09-28 21:16:41 --> URI Class Initialized
INFO - 2023-09-28 21:16:41 --> Router Class Initialized
INFO - 2023-09-28 21:16:41 --> Output Class Initialized
INFO - 2023-09-28 21:16:41 --> Security Class Initialized
DEBUG - 2023-09-28 21:16:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-28 21:16:41 --> Input Class Initialized
INFO - 2023-09-28 21:16:41 --> Language Class Initialized
INFO - 2023-09-28 21:16:41 --> Language Class Initialized
INFO - 2023-09-28 21:16:41 --> Config Class Initialized
INFO - 2023-09-28 21:16:41 --> Loader Class Initialized
INFO - 2023-09-28 21:16:41 --> Helper loaded: url_helper
INFO - 2023-09-28 21:16:41 --> Helper loaded: file_helper
INFO - 2023-09-28 21:16:41 --> Helper loaded: form_helper
INFO - 2023-09-28 21:16:41 --> Helper loaded: my_helper
INFO - 2023-09-28 21:16:41 --> Database Driver Class Initialized
INFO - 2023-09-28 21:16:41 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-28 21:16:41 --> Controller Class Initialized
INFO - 2023-09-28 21:16:43 --> Config Class Initialized
INFO - 2023-09-28 21:16:43 --> Hooks Class Initialized
DEBUG - 2023-09-28 21:16:43 --> UTF-8 Support Enabled
INFO - 2023-09-28 21:16:43 --> Utf8 Class Initialized
INFO - 2023-09-28 21:16:43 --> URI Class Initialized
INFO - 2023-09-28 21:16:43 --> Router Class Initialized
INFO - 2023-09-28 21:16:43 --> Output Class Initialized
INFO - 2023-09-28 21:16:43 --> Security Class Initialized
DEBUG - 2023-09-28 21:16:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-28 21:16:43 --> Input Class Initialized
INFO - 2023-09-28 21:16:43 --> Language Class Initialized
INFO - 2023-09-28 21:16:43 --> Language Class Initialized
INFO - 2023-09-28 21:16:43 --> Config Class Initialized
INFO - 2023-09-28 21:16:43 --> Loader Class Initialized
INFO - 2023-09-28 21:16:43 --> Helper loaded: url_helper
INFO - 2023-09-28 21:16:43 --> Helper loaded: file_helper
INFO - 2023-09-28 21:16:43 --> Helper loaded: form_helper
INFO - 2023-09-28 21:16:43 --> Helper loaded: my_helper
INFO - 2023-09-28 21:16:43 --> Database Driver Class Initialized
INFO - 2023-09-28 21:16:43 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-28 21:16:43 --> Controller Class Initialized
INFO - 2023-09-28 21:16:44 --> Final output sent to browser
DEBUG - 2023-09-28 21:16:44 --> Total execution time: 0.1378
INFO - 2023-09-28 21:16:44 --> Config Class Initialized
INFO - 2023-09-28 21:16:44 --> Hooks Class Initialized
DEBUG - 2023-09-28 21:16:44 --> UTF-8 Support Enabled
INFO - 2023-09-28 21:16:44 --> Utf8 Class Initialized
INFO - 2023-09-28 21:16:44 --> URI Class Initialized
INFO - 2023-09-28 21:16:44 --> Router Class Initialized
INFO - 2023-09-28 21:16:44 --> Output Class Initialized
INFO - 2023-09-28 21:16:44 --> Security Class Initialized
DEBUG - 2023-09-28 21:16:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-28 21:16:44 --> Input Class Initialized
INFO - 2023-09-28 21:16:44 --> Language Class Initialized
INFO - 2023-09-28 21:16:44 --> Language Class Initialized
INFO - 2023-09-28 21:16:44 --> Config Class Initialized
INFO - 2023-09-28 21:16:44 --> Loader Class Initialized
INFO - 2023-09-28 21:16:44 --> Helper loaded: url_helper
INFO - 2023-09-28 21:16:44 --> Helper loaded: file_helper
INFO - 2023-09-28 21:16:44 --> Helper loaded: form_helper
INFO - 2023-09-28 21:16:44 --> Helper loaded: my_helper
INFO - 2023-09-28 21:16:44 --> Database Driver Class Initialized
INFO - 2023-09-28 21:16:44 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-28 21:16:44 --> Controller Class Initialized
INFO - 2023-09-28 21:16:45 --> Config Class Initialized
INFO - 2023-09-28 21:16:45 --> Hooks Class Initialized
DEBUG - 2023-09-28 21:16:45 --> UTF-8 Support Enabled
INFO - 2023-09-28 21:16:45 --> Utf8 Class Initialized
INFO - 2023-09-28 21:16:45 --> URI Class Initialized
INFO - 2023-09-28 21:16:45 --> Router Class Initialized
INFO - 2023-09-28 21:16:45 --> Output Class Initialized
INFO - 2023-09-28 21:16:45 --> Security Class Initialized
DEBUG - 2023-09-28 21:16:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-28 21:16:45 --> Input Class Initialized
INFO - 2023-09-28 21:16:45 --> Language Class Initialized
INFO - 2023-09-28 21:16:45 --> Language Class Initialized
INFO - 2023-09-28 21:16:45 --> Config Class Initialized
INFO - 2023-09-28 21:16:45 --> Loader Class Initialized
INFO - 2023-09-28 21:16:45 --> Helper loaded: url_helper
INFO - 2023-09-28 21:16:45 --> Helper loaded: file_helper
INFO - 2023-09-28 21:16:45 --> Helper loaded: form_helper
INFO - 2023-09-28 21:16:45 --> Helper loaded: my_helper
INFO - 2023-09-28 21:16:45 --> Database Driver Class Initialized
INFO - 2023-09-28 21:16:45 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-28 21:16:45 --> Controller Class Initialized
INFO - 2023-09-28 21:16:45 --> Final output sent to browser
DEBUG - 2023-09-28 21:16:45 --> Total execution time: 0.0960
INFO - 2023-09-28 21:16:45 --> Config Class Initialized
INFO - 2023-09-28 21:16:45 --> Hooks Class Initialized
DEBUG - 2023-09-28 21:16:45 --> UTF-8 Support Enabled
INFO - 2023-09-28 21:16:45 --> Utf8 Class Initialized
INFO - 2023-09-28 21:16:45 --> URI Class Initialized
INFO - 2023-09-28 21:16:45 --> Router Class Initialized
INFO - 2023-09-28 21:16:45 --> Output Class Initialized
INFO - 2023-09-28 21:16:45 --> Security Class Initialized
DEBUG - 2023-09-28 21:16:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-28 21:16:45 --> Input Class Initialized
INFO - 2023-09-28 21:16:45 --> Language Class Initialized
INFO - 2023-09-28 21:16:45 --> Language Class Initialized
INFO - 2023-09-28 21:16:45 --> Config Class Initialized
INFO - 2023-09-28 21:16:45 --> Loader Class Initialized
INFO - 2023-09-28 21:16:45 --> Helper loaded: url_helper
INFO - 2023-09-28 21:16:45 --> Helper loaded: file_helper
INFO - 2023-09-28 21:16:45 --> Helper loaded: form_helper
INFO - 2023-09-28 21:16:45 --> Helper loaded: my_helper
INFO - 2023-09-28 21:16:45 --> Database Driver Class Initialized
INFO - 2023-09-28 21:16:45 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-28 21:16:45 --> Controller Class Initialized
INFO - 2023-09-28 21:16:46 --> Config Class Initialized
INFO - 2023-09-28 21:16:46 --> Hooks Class Initialized
DEBUG - 2023-09-28 21:16:46 --> UTF-8 Support Enabled
INFO - 2023-09-28 21:16:46 --> Utf8 Class Initialized
INFO - 2023-09-28 21:16:46 --> URI Class Initialized
INFO - 2023-09-28 21:16:46 --> Router Class Initialized
INFO - 2023-09-28 21:16:46 --> Output Class Initialized
INFO - 2023-09-28 21:16:46 --> Security Class Initialized
DEBUG - 2023-09-28 21:16:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-28 21:16:46 --> Input Class Initialized
INFO - 2023-09-28 21:16:46 --> Language Class Initialized
INFO - 2023-09-28 21:16:46 --> Language Class Initialized
INFO - 2023-09-28 21:16:46 --> Config Class Initialized
INFO - 2023-09-28 21:16:46 --> Loader Class Initialized
INFO - 2023-09-28 21:16:46 --> Helper loaded: url_helper
INFO - 2023-09-28 21:16:46 --> Helper loaded: file_helper
INFO - 2023-09-28 21:16:46 --> Helper loaded: form_helper
INFO - 2023-09-28 21:16:46 --> Helper loaded: my_helper
INFO - 2023-09-28 21:16:46 --> Database Driver Class Initialized
INFO - 2023-09-28 21:16:46 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-28 21:16:46 --> Controller Class Initialized
INFO - 2023-09-28 21:16:46 --> Final output sent to browser
DEBUG - 2023-09-28 21:16:46 --> Total execution time: 0.0506
INFO - 2023-09-28 21:16:47 --> Config Class Initialized
INFO - 2023-09-28 21:16:47 --> Hooks Class Initialized
DEBUG - 2023-09-28 21:16:47 --> UTF-8 Support Enabled
INFO - 2023-09-28 21:16:47 --> Utf8 Class Initialized
INFO - 2023-09-28 21:16:47 --> URI Class Initialized
INFO - 2023-09-28 21:16:47 --> Router Class Initialized
INFO - 2023-09-28 21:16:47 --> Output Class Initialized
INFO - 2023-09-28 21:16:47 --> Security Class Initialized
DEBUG - 2023-09-28 21:16:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-28 21:16:47 --> Input Class Initialized
INFO - 2023-09-28 21:16:47 --> Language Class Initialized
INFO - 2023-09-28 21:16:47 --> Language Class Initialized
INFO - 2023-09-28 21:16:47 --> Config Class Initialized
INFO - 2023-09-28 21:16:47 --> Loader Class Initialized
INFO - 2023-09-28 21:16:47 --> Helper loaded: url_helper
INFO - 2023-09-28 21:16:47 --> Helper loaded: file_helper
INFO - 2023-09-28 21:16:47 --> Helper loaded: form_helper
INFO - 2023-09-28 21:16:47 --> Helper loaded: my_helper
INFO - 2023-09-28 21:16:47 --> Database Driver Class Initialized
INFO - 2023-09-28 21:16:47 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-28 21:16:47 --> Controller Class Initialized
INFO - 2023-09-28 21:16:48 --> Config Class Initialized
INFO - 2023-09-28 21:16:48 --> Hooks Class Initialized
DEBUG - 2023-09-28 21:16:48 --> UTF-8 Support Enabled
INFO - 2023-09-28 21:16:48 --> Utf8 Class Initialized
INFO - 2023-09-28 21:16:48 --> URI Class Initialized
INFO - 2023-09-28 21:16:48 --> Router Class Initialized
INFO - 2023-09-28 21:16:48 --> Output Class Initialized
INFO - 2023-09-28 21:16:48 --> Security Class Initialized
DEBUG - 2023-09-28 21:16:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-28 21:16:48 --> Input Class Initialized
INFO - 2023-09-28 21:16:48 --> Language Class Initialized
INFO - 2023-09-28 21:16:48 --> Language Class Initialized
INFO - 2023-09-28 21:16:48 --> Config Class Initialized
INFO - 2023-09-28 21:16:48 --> Loader Class Initialized
INFO - 2023-09-28 21:16:48 --> Helper loaded: url_helper
INFO - 2023-09-28 21:16:48 --> Helper loaded: file_helper
INFO - 2023-09-28 21:16:48 --> Helper loaded: form_helper
INFO - 2023-09-28 21:16:48 --> Helper loaded: my_helper
INFO - 2023-09-28 21:16:48 --> Database Driver Class Initialized
INFO - 2023-09-28 21:16:48 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-28 21:16:48 --> Controller Class Initialized
INFO - 2023-09-28 21:16:48 --> Final output sent to browser
DEBUG - 2023-09-28 21:16:48 --> Total execution time: 0.0359
INFO - 2023-09-28 21:16:48 --> Config Class Initialized
INFO - 2023-09-28 21:16:48 --> Hooks Class Initialized
DEBUG - 2023-09-28 21:16:48 --> UTF-8 Support Enabled
INFO - 2023-09-28 21:16:48 --> Utf8 Class Initialized
INFO - 2023-09-28 21:16:48 --> URI Class Initialized
INFO - 2023-09-28 21:16:48 --> Router Class Initialized
INFO - 2023-09-28 21:16:48 --> Output Class Initialized
INFO - 2023-09-28 21:16:48 --> Security Class Initialized
DEBUG - 2023-09-28 21:16:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-28 21:16:48 --> Input Class Initialized
INFO - 2023-09-28 21:16:48 --> Language Class Initialized
INFO - 2023-09-28 21:16:48 --> Language Class Initialized
INFO - 2023-09-28 21:16:48 --> Config Class Initialized
INFO - 2023-09-28 21:16:48 --> Loader Class Initialized
INFO - 2023-09-28 21:16:48 --> Helper loaded: url_helper
INFO - 2023-09-28 21:16:48 --> Helper loaded: file_helper
INFO - 2023-09-28 21:16:48 --> Helper loaded: form_helper
INFO - 2023-09-28 21:16:48 --> Helper loaded: my_helper
INFO - 2023-09-28 21:16:48 --> Database Driver Class Initialized
INFO - 2023-09-28 21:16:48 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-28 21:16:48 --> Controller Class Initialized
INFO - 2023-09-28 21:16:49 --> Config Class Initialized
INFO - 2023-09-28 21:16:49 --> Hooks Class Initialized
DEBUG - 2023-09-28 21:16:49 --> UTF-8 Support Enabled
INFO - 2023-09-28 21:16:49 --> Utf8 Class Initialized
INFO - 2023-09-28 21:16:49 --> URI Class Initialized
INFO - 2023-09-28 21:16:49 --> Router Class Initialized
INFO - 2023-09-28 21:16:49 --> Output Class Initialized
INFO - 2023-09-28 21:16:49 --> Security Class Initialized
DEBUG - 2023-09-28 21:16:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-28 21:16:49 --> Input Class Initialized
INFO - 2023-09-28 21:16:49 --> Language Class Initialized
INFO - 2023-09-28 21:16:49 --> Language Class Initialized
INFO - 2023-09-28 21:16:49 --> Config Class Initialized
INFO - 2023-09-28 21:16:49 --> Loader Class Initialized
INFO - 2023-09-28 21:16:49 --> Helper loaded: url_helper
INFO - 2023-09-28 21:16:49 --> Helper loaded: file_helper
INFO - 2023-09-28 21:16:49 --> Helper loaded: form_helper
INFO - 2023-09-28 21:16:49 --> Helper loaded: my_helper
INFO - 2023-09-28 21:16:49 --> Database Driver Class Initialized
INFO - 2023-09-28 21:16:49 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-28 21:16:49 --> Controller Class Initialized
INFO - 2023-09-28 21:16:49 --> Final output sent to browser
DEBUG - 2023-09-28 21:16:49 --> Total execution time: 0.0425
INFO - 2023-09-28 21:16:49 --> Config Class Initialized
INFO - 2023-09-28 21:16:49 --> Hooks Class Initialized
DEBUG - 2023-09-28 21:16:49 --> UTF-8 Support Enabled
INFO - 2023-09-28 21:16:49 --> Utf8 Class Initialized
INFO - 2023-09-28 21:16:49 --> URI Class Initialized
INFO - 2023-09-28 21:16:49 --> Router Class Initialized
INFO - 2023-09-28 21:16:49 --> Output Class Initialized
INFO - 2023-09-28 21:16:49 --> Security Class Initialized
DEBUG - 2023-09-28 21:16:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-28 21:16:49 --> Input Class Initialized
INFO - 2023-09-28 21:16:49 --> Language Class Initialized
INFO - 2023-09-28 21:16:49 --> Language Class Initialized
INFO - 2023-09-28 21:16:49 --> Config Class Initialized
INFO - 2023-09-28 21:16:49 --> Loader Class Initialized
INFO - 2023-09-28 21:16:49 --> Helper loaded: url_helper
INFO - 2023-09-28 21:16:49 --> Helper loaded: file_helper
INFO - 2023-09-28 21:16:49 --> Helper loaded: form_helper
INFO - 2023-09-28 21:16:49 --> Helper loaded: my_helper
INFO - 2023-09-28 21:16:49 --> Database Driver Class Initialized
INFO - 2023-09-28 21:16:49 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-28 21:16:49 --> Controller Class Initialized
INFO - 2023-09-28 21:16:51 --> Config Class Initialized
INFO - 2023-09-28 21:16:51 --> Hooks Class Initialized
DEBUG - 2023-09-28 21:16:51 --> UTF-8 Support Enabled
INFO - 2023-09-28 21:16:51 --> Utf8 Class Initialized
INFO - 2023-09-28 21:16:51 --> URI Class Initialized
INFO - 2023-09-28 21:16:51 --> Router Class Initialized
INFO - 2023-09-28 21:16:51 --> Output Class Initialized
INFO - 2023-09-28 21:16:51 --> Security Class Initialized
DEBUG - 2023-09-28 21:16:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-28 21:16:51 --> Input Class Initialized
INFO - 2023-09-28 21:16:51 --> Language Class Initialized
INFO - 2023-09-28 21:16:51 --> Language Class Initialized
INFO - 2023-09-28 21:16:51 --> Config Class Initialized
INFO - 2023-09-28 21:16:51 --> Loader Class Initialized
INFO - 2023-09-28 21:16:51 --> Helper loaded: url_helper
INFO - 2023-09-28 21:16:51 --> Helper loaded: file_helper
INFO - 2023-09-28 21:16:51 --> Helper loaded: form_helper
INFO - 2023-09-28 21:16:51 --> Helper loaded: my_helper
INFO - 2023-09-28 21:16:51 --> Database Driver Class Initialized
INFO - 2023-09-28 21:16:51 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-28 21:16:51 --> Controller Class Initialized
INFO - 2023-09-28 21:16:51 --> Final output sent to browser
DEBUG - 2023-09-28 21:16:51 --> Total execution time: 0.0768
INFO - 2023-09-28 21:16:51 --> Config Class Initialized
INFO - 2023-09-28 21:16:51 --> Hooks Class Initialized
DEBUG - 2023-09-28 21:16:51 --> UTF-8 Support Enabled
INFO - 2023-09-28 21:16:51 --> Utf8 Class Initialized
INFO - 2023-09-28 21:16:51 --> URI Class Initialized
INFO - 2023-09-28 21:16:51 --> Router Class Initialized
INFO - 2023-09-28 21:16:51 --> Output Class Initialized
INFO - 2023-09-28 21:16:51 --> Security Class Initialized
DEBUG - 2023-09-28 21:16:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-28 21:16:51 --> Input Class Initialized
INFO - 2023-09-28 21:16:51 --> Language Class Initialized
INFO - 2023-09-28 21:16:51 --> Language Class Initialized
INFO - 2023-09-28 21:16:51 --> Config Class Initialized
INFO - 2023-09-28 21:16:51 --> Loader Class Initialized
INFO - 2023-09-28 21:16:51 --> Helper loaded: url_helper
INFO - 2023-09-28 21:16:51 --> Helper loaded: file_helper
INFO - 2023-09-28 21:16:51 --> Helper loaded: form_helper
INFO - 2023-09-28 21:16:51 --> Helper loaded: my_helper
INFO - 2023-09-28 21:16:51 --> Database Driver Class Initialized
INFO - 2023-09-28 21:16:51 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-28 21:16:51 --> Controller Class Initialized
INFO - 2023-09-28 21:16:53 --> Config Class Initialized
INFO - 2023-09-28 21:16:53 --> Hooks Class Initialized
DEBUG - 2023-09-28 21:16:53 --> UTF-8 Support Enabled
INFO - 2023-09-28 21:16:53 --> Utf8 Class Initialized
INFO - 2023-09-28 21:16:53 --> URI Class Initialized
INFO - 2023-09-28 21:16:53 --> Router Class Initialized
INFO - 2023-09-28 21:16:53 --> Output Class Initialized
INFO - 2023-09-28 21:16:53 --> Security Class Initialized
DEBUG - 2023-09-28 21:16:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-28 21:16:53 --> Input Class Initialized
INFO - 2023-09-28 21:16:53 --> Language Class Initialized
INFO - 2023-09-28 21:16:53 --> Language Class Initialized
INFO - 2023-09-28 21:16:53 --> Config Class Initialized
INFO - 2023-09-28 21:16:53 --> Loader Class Initialized
INFO - 2023-09-28 21:16:53 --> Helper loaded: url_helper
INFO - 2023-09-28 21:16:53 --> Helper loaded: file_helper
INFO - 2023-09-28 21:16:53 --> Helper loaded: form_helper
INFO - 2023-09-28 21:16:53 --> Helper loaded: my_helper
INFO - 2023-09-28 21:16:53 --> Database Driver Class Initialized
INFO - 2023-09-28 21:16:53 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-28 21:16:53 --> Controller Class Initialized
INFO - 2023-09-28 21:16:53 --> Final output sent to browser
DEBUG - 2023-09-28 21:16:53 --> Total execution time: 0.0475
INFO - 2023-09-28 21:16:53 --> Config Class Initialized
INFO - 2023-09-28 21:16:53 --> Hooks Class Initialized
DEBUG - 2023-09-28 21:16:53 --> UTF-8 Support Enabled
INFO - 2023-09-28 21:16:53 --> Utf8 Class Initialized
INFO - 2023-09-28 21:16:53 --> URI Class Initialized
INFO - 2023-09-28 21:16:53 --> Router Class Initialized
INFO - 2023-09-28 21:16:53 --> Output Class Initialized
INFO - 2023-09-28 21:16:53 --> Security Class Initialized
DEBUG - 2023-09-28 21:16:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-28 21:16:53 --> Input Class Initialized
INFO - 2023-09-28 21:16:53 --> Language Class Initialized
INFO - 2023-09-28 21:16:53 --> Language Class Initialized
INFO - 2023-09-28 21:16:53 --> Config Class Initialized
INFO - 2023-09-28 21:16:53 --> Loader Class Initialized
INFO - 2023-09-28 21:16:53 --> Helper loaded: url_helper
INFO - 2023-09-28 21:16:53 --> Helper loaded: file_helper
INFO - 2023-09-28 21:16:53 --> Helper loaded: form_helper
INFO - 2023-09-28 21:16:53 --> Helper loaded: my_helper
INFO - 2023-09-28 21:16:53 --> Database Driver Class Initialized
INFO - 2023-09-28 21:16:53 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-28 21:16:53 --> Controller Class Initialized
INFO - 2023-09-28 21:16:55 --> Config Class Initialized
INFO - 2023-09-28 21:16:55 --> Hooks Class Initialized
DEBUG - 2023-09-28 21:16:55 --> UTF-8 Support Enabled
INFO - 2023-09-28 21:16:55 --> Utf8 Class Initialized
INFO - 2023-09-28 21:16:55 --> URI Class Initialized
INFO - 2023-09-28 21:16:55 --> Router Class Initialized
INFO - 2023-09-28 21:16:55 --> Output Class Initialized
INFO - 2023-09-28 21:16:55 --> Security Class Initialized
DEBUG - 2023-09-28 21:16:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-28 21:16:55 --> Input Class Initialized
INFO - 2023-09-28 21:16:55 --> Language Class Initialized
INFO - 2023-09-28 21:16:55 --> Language Class Initialized
INFO - 2023-09-28 21:16:55 --> Config Class Initialized
INFO - 2023-09-28 21:16:55 --> Loader Class Initialized
INFO - 2023-09-28 21:16:55 --> Helper loaded: url_helper
INFO - 2023-09-28 21:16:55 --> Helper loaded: file_helper
INFO - 2023-09-28 21:16:55 --> Helper loaded: form_helper
INFO - 2023-09-28 21:16:55 --> Helper loaded: my_helper
INFO - 2023-09-28 21:16:55 --> Database Driver Class Initialized
INFO - 2023-09-28 21:16:55 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-28 21:16:55 --> Controller Class Initialized
INFO - 2023-09-28 21:16:55 --> Final output sent to browser
DEBUG - 2023-09-28 21:16:55 --> Total execution time: 0.0917
INFO - 2023-09-28 21:16:55 --> Config Class Initialized
INFO - 2023-09-28 21:16:55 --> Hooks Class Initialized
DEBUG - 2023-09-28 21:16:55 --> UTF-8 Support Enabled
INFO - 2023-09-28 21:16:55 --> Utf8 Class Initialized
INFO - 2023-09-28 21:16:55 --> URI Class Initialized
INFO - 2023-09-28 21:16:55 --> Router Class Initialized
INFO - 2023-09-28 21:16:55 --> Output Class Initialized
INFO - 2023-09-28 21:16:55 --> Security Class Initialized
DEBUG - 2023-09-28 21:16:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-28 21:16:55 --> Input Class Initialized
INFO - 2023-09-28 21:16:55 --> Language Class Initialized
INFO - 2023-09-28 21:16:55 --> Language Class Initialized
INFO - 2023-09-28 21:16:55 --> Config Class Initialized
INFO - 2023-09-28 21:16:55 --> Loader Class Initialized
INFO - 2023-09-28 21:16:55 --> Helper loaded: url_helper
INFO - 2023-09-28 21:16:55 --> Helper loaded: file_helper
INFO - 2023-09-28 21:16:55 --> Helper loaded: form_helper
INFO - 2023-09-28 21:16:55 --> Helper loaded: my_helper
INFO - 2023-09-28 21:16:55 --> Database Driver Class Initialized
INFO - 2023-09-28 21:16:55 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-28 21:16:55 --> Controller Class Initialized
INFO - 2023-09-28 21:16:57 --> Config Class Initialized
INFO - 2023-09-28 21:16:57 --> Hooks Class Initialized
DEBUG - 2023-09-28 21:16:57 --> UTF-8 Support Enabled
INFO - 2023-09-28 21:16:57 --> Utf8 Class Initialized
INFO - 2023-09-28 21:16:57 --> URI Class Initialized
INFO - 2023-09-28 21:16:57 --> Router Class Initialized
INFO - 2023-09-28 21:16:57 --> Output Class Initialized
INFO - 2023-09-28 21:16:57 --> Security Class Initialized
DEBUG - 2023-09-28 21:16:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-28 21:16:57 --> Input Class Initialized
INFO - 2023-09-28 21:16:57 --> Language Class Initialized
INFO - 2023-09-28 21:16:57 --> Language Class Initialized
INFO - 2023-09-28 21:16:57 --> Config Class Initialized
INFO - 2023-09-28 21:16:57 --> Loader Class Initialized
INFO - 2023-09-28 21:16:57 --> Helper loaded: url_helper
INFO - 2023-09-28 21:16:57 --> Helper loaded: file_helper
INFO - 2023-09-28 21:16:57 --> Helper loaded: form_helper
INFO - 2023-09-28 21:16:57 --> Helper loaded: my_helper
INFO - 2023-09-28 21:16:57 --> Database Driver Class Initialized
INFO - 2023-09-28 21:16:57 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-28 21:16:57 --> Controller Class Initialized
INFO - 2023-09-28 21:16:57 --> Final output sent to browser
DEBUG - 2023-09-28 21:16:57 --> Total execution time: 0.0468
INFO - 2023-09-28 21:16:57 --> Config Class Initialized
INFO - 2023-09-28 21:16:57 --> Hooks Class Initialized
DEBUG - 2023-09-28 21:16:57 --> UTF-8 Support Enabled
INFO - 2023-09-28 21:16:57 --> Utf8 Class Initialized
INFO - 2023-09-28 21:16:57 --> URI Class Initialized
INFO - 2023-09-28 21:16:57 --> Router Class Initialized
INFO - 2023-09-28 21:16:57 --> Output Class Initialized
INFO - 2023-09-28 21:16:57 --> Security Class Initialized
DEBUG - 2023-09-28 21:16:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-28 21:16:57 --> Input Class Initialized
INFO - 2023-09-28 21:16:57 --> Language Class Initialized
INFO - 2023-09-28 21:16:57 --> Language Class Initialized
INFO - 2023-09-28 21:16:57 --> Config Class Initialized
INFO - 2023-09-28 21:16:57 --> Loader Class Initialized
INFO - 2023-09-28 21:16:57 --> Helper loaded: url_helper
INFO - 2023-09-28 21:16:57 --> Helper loaded: file_helper
INFO - 2023-09-28 21:16:57 --> Helper loaded: form_helper
INFO - 2023-09-28 21:16:57 --> Helper loaded: my_helper
INFO - 2023-09-28 21:16:57 --> Database Driver Class Initialized
INFO - 2023-09-28 21:16:57 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-28 21:16:57 --> Controller Class Initialized
INFO - 2023-09-28 21:16:58 --> Config Class Initialized
INFO - 2023-09-28 21:16:58 --> Hooks Class Initialized
DEBUG - 2023-09-28 21:16:58 --> UTF-8 Support Enabled
INFO - 2023-09-28 21:16:58 --> Utf8 Class Initialized
INFO - 2023-09-28 21:16:58 --> URI Class Initialized
INFO - 2023-09-28 21:16:58 --> Router Class Initialized
INFO - 2023-09-28 21:16:58 --> Output Class Initialized
INFO - 2023-09-28 21:16:58 --> Security Class Initialized
DEBUG - 2023-09-28 21:16:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-28 21:16:58 --> Input Class Initialized
INFO - 2023-09-28 21:16:58 --> Language Class Initialized
INFO - 2023-09-28 21:16:58 --> Language Class Initialized
INFO - 2023-09-28 21:16:58 --> Config Class Initialized
INFO - 2023-09-28 21:16:58 --> Loader Class Initialized
INFO - 2023-09-28 21:16:58 --> Helper loaded: url_helper
INFO - 2023-09-28 21:16:58 --> Helper loaded: file_helper
INFO - 2023-09-28 21:16:58 --> Helper loaded: form_helper
INFO - 2023-09-28 21:16:58 --> Helper loaded: my_helper
INFO - 2023-09-28 21:16:58 --> Database Driver Class Initialized
INFO - 2023-09-28 21:16:58 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-28 21:16:58 --> Controller Class Initialized
INFO - 2023-09-28 21:16:58 --> Final output sent to browser
DEBUG - 2023-09-28 21:16:58 --> Total execution time: 0.0342
INFO - 2023-09-28 21:16:58 --> Config Class Initialized
INFO - 2023-09-28 21:16:58 --> Hooks Class Initialized
DEBUG - 2023-09-28 21:16:58 --> UTF-8 Support Enabled
INFO - 2023-09-28 21:16:58 --> Utf8 Class Initialized
INFO - 2023-09-28 21:16:58 --> URI Class Initialized
INFO - 2023-09-28 21:16:58 --> Router Class Initialized
INFO - 2023-09-28 21:16:58 --> Output Class Initialized
INFO - 2023-09-28 21:16:58 --> Security Class Initialized
DEBUG - 2023-09-28 21:16:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-28 21:16:58 --> Input Class Initialized
INFO - 2023-09-28 21:16:58 --> Language Class Initialized
INFO - 2023-09-28 21:16:58 --> Language Class Initialized
INFO - 2023-09-28 21:16:58 --> Config Class Initialized
INFO - 2023-09-28 21:16:58 --> Loader Class Initialized
INFO - 2023-09-28 21:16:58 --> Helper loaded: url_helper
INFO - 2023-09-28 21:16:58 --> Helper loaded: file_helper
INFO - 2023-09-28 21:16:58 --> Helper loaded: form_helper
INFO - 2023-09-28 21:16:58 --> Helper loaded: my_helper
INFO - 2023-09-28 21:16:58 --> Database Driver Class Initialized
INFO - 2023-09-28 21:16:58 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-28 21:16:58 --> Controller Class Initialized
INFO - 2023-09-28 21:16:59 --> Config Class Initialized
INFO - 2023-09-28 21:16:59 --> Hooks Class Initialized
DEBUG - 2023-09-28 21:16:59 --> UTF-8 Support Enabled
INFO - 2023-09-28 21:16:59 --> Utf8 Class Initialized
INFO - 2023-09-28 21:16:59 --> URI Class Initialized
INFO - 2023-09-28 21:16:59 --> Router Class Initialized
INFO - 2023-09-28 21:16:59 --> Output Class Initialized
INFO - 2023-09-28 21:16:59 --> Security Class Initialized
DEBUG - 2023-09-28 21:16:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-28 21:16:59 --> Input Class Initialized
INFO - 2023-09-28 21:16:59 --> Language Class Initialized
INFO - 2023-09-28 21:16:59 --> Language Class Initialized
INFO - 2023-09-28 21:16:59 --> Config Class Initialized
INFO - 2023-09-28 21:16:59 --> Loader Class Initialized
INFO - 2023-09-28 21:16:59 --> Helper loaded: url_helper
INFO - 2023-09-28 21:16:59 --> Helper loaded: file_helper
INFO - 2023-09-28 21:16:59 --> Helper loaded: form_helper
INFO - 2023-09-28 21:16:59 --> Helper loaded: my_helper
INFO - 2023-09-28 21:16:59 --> Database Driver Class Initialized
INFO - 2023-09-28 21:16:59 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-28 21:16:59 --> Controller Class Initialized
INFO - 2023-09-28 21:16:59 --> Final output sent to browser
DEBUG - 2023-09-28 21:16:59 --> Total execution time: 0.0412
INFO - 2023-09-28 21:16:59 --> Config Class Initialized
INFO - 2023-09-28 21:16:59 --> Hooks Class Initialized
DEBUG - 2023-09-28 21:16:59 --> UTF-8 Support Enabled
INFO - 2023-09-28 21:16:59 --> Utf8 Class Initialized
INFO - 2023-09-28 21:16:59 --> URI Class Initialized
INFO - 2023-09-28 21:16:59 --> Router Class Initialized
INFO - 2023-09-28 21:16:59 --> Output Class Initialized
INFO - 2023-09-28 21:16:59 --> Security Class Initialized
DEBUG - 2023-09-28 21:16:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-28 21:16:59 --> Input Class Initialized
INFO - 2023-09-28 21:16:59 --> Language Class Initialized
INFO - 2023-09-28 21:16:59 --> Language Class Initialized
INFO - 2023-09-28 21:16:59 --> Config Class Initialized
INFO - 2023-09-28 21:16:59 --> Loader Class Initialized
INFO - 2023-09-28 21:16:59 --> Helper loaded: url_helper
INFO - 2023-09-28 21:16:59 --> Helper loaded: file_helper
INFO - 2023-09-28 21:16:59 --> Helper loaded: form_helper
INFO - 2023-09-28 21:16:59 --> Helper loaded: my_helper
INFO - 2023-09-28 21:16:59 --> Database Driver Class Initialized
INFO - 2023-09-28 21:16:59 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-28 21:16:59 --> Controller Class Initialized
INFO - 2023-09-28 21:17:00 --> Config Class Initialized
INFO - 2023-09-28 21:17:00 --> Hooks Class Initialized
DEBUG - 2023-09-28 21:17:00 --> UTF-8 Support Enabled
INFO - 2023-09-28 21:17:00 --> Utf8 Class Initialized
INFO - 2023-09-28 21:17:00 --> URI Class Initialized
INFO - 2023-09-28 21:17:00 --> Router Class Initialized
INFO - 2023-09-28 21:17:00 --> Output Class Initialized
INFO - 2023-09-28 21:17:00 --> Security Class Initialized
DEBUG - 2023-09-28 21:17:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-28 21:17:00 --> Input Class Initialized
INFO - 2023-09-28 21:17:00 --> Language Class Initialized
INFO - 2023-09-28 21:17:00 --> Language Class Initialized
INFO - 2023-09-28 21:17:00 --> Config Class Initialized
INFO - 2023-09-28 21:17:00 --> Loader Class Initialized
INFO - 2023-09-28 21:17:00 --> Helper loaded: url_helper
INFO - 2023-09-28 21:17:00 --> Helper loaded: file_helper
INFO - 2023-09-28 21:17:00 --> Helper loaded: form_helper
INFO - 2023-09-28 21:17:00 --> Helper loaded: my_helper
INFO - 2023-09-28 21:17:00 --> Database Driver Class Initialized
INFO - 2023-09-28 21:17:00 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-28 21:17:00 --> Controller Class Initialized
INFO - 2023-09-28 21:17:00 --> Final output sent to browser
DEBUG - 2023-09-28 21:17:00 --> Total execution time: 0.0421
INFO - 2023-09-28 21:17:00 --> Config Class Initialized
INFO - 2023-09-28 21:17:00 --> Hooks Class Initialized
DEBUG - 2023-09-28 21:17:00 --> UTF-8 Support Enabled
INFO - 2023-09-28 21:17:00 --> Utf8 Class Initialized
INFO - 2023-09-28 21:17:00 --> URI Class Initialized
INFO - 2023-09-28 21:17:00 --> Router Class Initialized
INFO - 2023-09-28 21:17:00 --> Output Class Initialized
INFO - 2023-09-28 21:17:00 --> Security Class Initialized
DEBUG - 2023-09-28 21:17:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-28 21:17:00 --> Input Class Initialized
INFO - 2023-09-28 21:17:00 --> Language Class Initialized
INFO - 2023-09-28 21:17:00 --> Language Class Initialized
INFO - 2023-09-28 21:17:00 --> Config Class Initialized
INFO - 2023-09-28 21:17:00 --> Loader Class Initialized
INFO - 2023-09-28 21:17:00 --> Helper loaded: url_helper
INFO - 2023-09-28 21:17:00 --> Helper loaded: file_helper
INFO - 2023-09-28 21:17:00 --> Helper loaded: form_helper
INFO - 2023-09-28 21:17:00 --> Helper loaded: my_helper
INFO - 2023-09-28 21:17:00 --> Database Driver Class Initialized
INFO - 2023-09-28 21:17:00 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-28 21:17:00 --> Controller Class Initialized
INFO - 2023-09-28 21:17:03 --> Config Class Initialized
INFO - 2023-09-28 21:17:03 --> Hooks Class Initialized
DEBUG - 2023-09-28 21:17:03 --> UTF-8 Support Enabled
INFO - 2023-09-28 21:17:03 --> Utf8 Class Initialized
INFO - 2023-09-28 21:17:03 --> URI Class Initialized
INFO - 2023-09-28 21:17:03 --> Router Class Initialized
INFO - 2023-09-28 21:17:03 --> Output Class Initialized
INFO - 2023-09-28 21:17:03 --> Security Class Initialized
DEBUG - 2023-09-28 21:17:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-28 21:17:03 --> Input Class Initialized
INFO - 2023-09-28 21:17:03 --> Language Class Initialized
INFO - 2023-09-28 21:17:03 --> Language Class Initialized
INFO - 2023-09-28 21:17:03 --> Config Class Initialized
INFO - 2023-09-28 21:17:03 --> Loader Class Initialized
INFO - 2023-09-28 21:17:03 --> Helper loaded: url_helper
INFO - 2023-09-28 21:17:03 --> Helper loaded: file_helper
INFO - 2023-09-28 21:17:03 --> Helper loaded: form_helper
INFO - 2023-09-28 21:17:03 --> Helper loaded: my_helper
INFO - 2023-09-28 21:17:03 --> Database Driver Class Initialized
INFO - 2023-09-28 21:17:03 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-28 21:17:03 --> Controller Class Initialized
INFO - 2023-09-28 21:17:03 --> Final output sent to browser
DEBUG - 2023-09-28 21:17:03 --> Total execution time: 0.0454
INFO - 2023-09-28 21:17:03 --> Config Class Initialized
INFO - 2023-09-28 21:17:03 --> Hooks Class Initialized
DEBUG - 2023-09-28 21:17:03 --> UTF-8 Support Enabled
INFO - 2023-09-28 21:17:03 --> Utf8 Class Initialized
INFO - 2023-09-28 21:17:03 --> URI Class Initialized
INFO - 2023-09-28 21:17:03 --> Router Class Initialized
INFO - 2023-09-28 21:17:03 --> Output Class Initialized
INFO - 2023-09-28 21:17:03 --> Security Class Initialized
DEBUG - 2023-09-28 21:17:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-28 21:17:03 --> Input Class Initialized
INFO - 2023-09-28 21:17:03 --> Language Class Initialized
INFO - 2023-09-28 21:17:03 --> Language Class Initialized
INFO - 2023-09-28 21:17:03 --> Config Class Initialized
INFO - 2023-09-28 21:17:03 --> Loader Class Initialized
INFO - 2023-09-28 21:17:03 --> Helper loaded: url_helper
INFO - 2023-09-28 21:17:03 --> Helper loaded: file_helper
INFO - 2023-09-28 21:17:03 --> Helper loaded: form_helper
INFO - 2023-09-28 21:17:03 --> Helper loaded: my_helper
INFO - 2023-09-28 21:17:03 --> Database Driver Class Initialized
INFO - 2023-09-28 21:17:03 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-28 21:17:03 --> Controller Class Initialized
INFO - 2023-09-28 21:17:04 --> Config Class Initialized
INFO - 2023-09-28 21:17:04 --> Hooks Class Initialized
DEBUG - 2023-09-28 21:17:04 --> UTF-8 Support Enabled
INFO - 2023-09-28 21:17:04 --> Utf8 Class Initialized
INFO - 2023-09-28 21:17:04 --> URI Class Initialized
INFO - 2023-09-28 21:17:04 --> Router Class Initialized
INFO - 2023-09-28 21:17:04 --> Output Class Initialized
INFO - 2023-09-28 21:17:04 --> Security Class Initialized
DEBUG - 2023-09-28 21:17:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-28 21:17:04 --> Input Class Initialized
INFO - 2023-09-28 21:17:04 --> Language Class Initialized
INFO - 2023-09-28 21:17:04 --> Language Class Initialized
INFO - 2023-09-28 21:17:04 --> Config Class Initialized
INFO - 2023-09-28 21:17:04 --> Loader Class Initialized
INFO - 2023-09-28 21:17:04 --> Helper loaded: url_helper
INFO - 2023-09-28 21:17:04 --> Helper loaded: file_helper
INFO - 2023-09-28 21:17:04 --> Helper loaded: form_helper
INFO - 2023-09-28 21:17:04 --> Helper loaded: my_helper
INFO - 2023-09-28 21:17:04 --> Database Driver Class Initialized
INFO - 2023-09-28 21:17:04 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-28 21:17:04 --> Controller Class Initialized
INFO - 2023-09-28 21:17:04 --> Final output sent to browser
DEBUG - 2023-09-28 21:17:04 --> Total execution time: 0.1071
INFO - 2023-09-28 21:21:37 --> Config Class Initialized
INFO - 2023-09-28 21:21:37 --> Hooks Class Initialized
DEBUG - 2023-09-28 21:21:37 --> UTF-8 Support Enabled
INFO - 2023-09-28 21:21:37 --> Utf8 Class Initialized
INFO - 2023-09-28 21:21:37 --> URI Class Initialized
INFO - 2023-09-28 21:21:37 --> Router Class Initialized
INFO - 2023-09-28 21:21:37 --> Output Class Initialized
INFO - 2023-09-28 21:21:37 --> Security Class Initialized
DEBUG - 2023-09-28 21:21:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-28 21:21:37 --> Input Class Initialized
INFO - 2023-09-28 21:21:37 --> Language Class Initialized
INFO - 2023-09-28 21:21:37 --> Language Class Initialized
INFO - 2023-09-28 21:21:37 --> Config Class Initialized
INFO - 2023-09-28 21:21:37 --> Loader Class Initialized
INFO - 2023-09-28 21:21:37 --> Helper loaded: url_helper
INFO - 2023-09-28 21:21:37 --> Helper loaded: file_helper
INFO - 2023-09-28 21:21:37 --> Helper loaded: form_helper
INFO - 2023-09-28 21:21:37 --> Helper loaded: my_helper
INFO - 2023-09-28 21:21:37 --> Database Driver Class Initialized
INFO - 2023-09-28 21:21:37 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-28 21:21:37 --> Controller Class Initialized
INFO - 2023-09-28 21:21:37 --> Final output sent to browser
DEBUG - 2023-09-28 21:21:37 --> Total execution time: 0.3786
INFO - 2023-09-28 21:21:37 --> Config Class Initialized
INFO - 2023-09-28 21:21:37 --> Hooks Class Initialized
DEBUG - 2023-09-28 21:21:37 --> UTF-8 Support Enabled
INFO - 2023-09-28 21:21:37 --> Utf8 Class Initialized
INFO - 2023-09-28 21:21:37 --> URI Class Initialized
INFO - 2023-09-28 21:21:37 --> Router Class Initialized
INFO - 2023-09-28 21:21:37 --> Output Class Initialized
INFO - 2023-09-28 21:21:37 --> Security Class Initialized
DEBUG - 2023-09-28 21:21:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-28 21:21:37 --> Input Class Initialized
INFO - 2023-09-28 21:21:37 --> Language Class Initialized
INFO - 2023-09-28 21:21:37 --> Language Class Initialized
INFO - 2023-09-28 21:21:37 --> Config Class Initialized
INFO - 2023-09-28 21:21:37 --> Loader Class Initialized
INFO - 2023-09-28 21:21:37 --> Helper loaded: url_helper
INFO - 2023-09-28 21:21:37 --> Helper loaded: file_helper
INFO - 2023-09-28 21:21:37 --> Helper loaded: form_helper
INFO - 2023-09-28 21:21:37 --> Helper loaded: my_helper
INFO - 2023-09-28 21:21:37 --> Database Driver Class Initialized
INFO - 2023-09-28 21:21:37 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-28 21:21:37 --> Controller Class Initialized
INFO - 2023-09-28 21:21:39 --> Config Class Initialized
INFO - 2023-09-28 21:21:39 --> Hooks Class Initialized
DEBUG - 2023-09-28 21:21:39 --> UTF-8 Support Enabled
INFO - 2023-09-28 21:21:39 --> Utf8 Class Initialized
INFO - 2023-09-28 21:21:39 --> URI Class Initialized
INFO - 2023-09-28 21:21:39 --> Router Class Initialized
INFO - 2023-09-28 21:21:39 --> Output Class Initialized
INFO - 2023-09-28 21:21:39 --> Security Class Initialized
DEBUG - 2023-09-28 21:21:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-28 21:21:39 --> Input Class Initialized
INFO - 2023-09-28 21:21:39 --> Language Class Initialized
INFO - 2023-09-28 21:21:39 --> Language Class Initialized
INFO - 2023-09-28 21:21:39 --> Config Class Initialized
INFO - 2023-09-28 21:21:39 --> Loader Class Initialized
INFO - 2023-09-28 21:21:39 --> Helper loaded: url_helper
INFO - 2023-09-28 21:21:39 --> Helper loaded: file_helper
INFO - 2023-09-28 21:21:39 --> Helper loaded: form_helper
INFO - 2023-09-28 21:21:39 --> Helper loaded: my_helper
INFO - 2023-09-28 21:21:39 --> Database Driver Class Initialized
INFO - 2023-09-28 21:21:39 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-28 21:21:39 --> Controller Class Initialized
INFO - 2023-09-28 21:21:39 --> Final output sent to browser
DEBUG - 2023-09-28 21:21:39 --> Total execution time: 0.0670
INFO - 2023-09-28 21:21:43 --> Config Class Initialized
INFO - 2023-09-28 21:21:43 --> Hooks Class Initialized
DEBUG - 2023-09-28 21:21:43 --> UTF-8 Support Enabled
INFO - 2023-09-28 21:21:43 --> Utf8 Class Initialized
INFO - 2023-09-28 21:21:43 --> URI Class Initialized
INFO - 2023-09-28 21:21:43 --> Router Class Initialized
INFO - 2023-09-28 21:21:43 --> Output Class Initialized
INFO - 2023-09-28 21:21:43 --> Security Class Initialized
DEBUG - 2023-09-28 21:21:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-28 21:21:43 --> Input Class Initialized
INFO - 2023-09-28 21:21:43 --> Language Class Initialized
INFO - 2023-09-28 21:21:43 --> Language Class Initialized
INFO - 2023-09-28 21:21:43 --> Config Class Initialized
INFO - 2023-09-28 21:21:43 --> Loader Class Initialized
INFO - 2023-09-28 21:21:43 --> Helper loaded: url_helper
INFO - 2023-09-28 21:21:43 --> Helper loaded: file_helper
INFO - 2023-09-28 21:21:43 --> Helper loaded: form_helper
INFO - 2023-09-28 21:21:43 --> Helper loaded: my_helper
INFO - 2023-09-28 21:21:43 --> Database Driver Class Initialized
INFO - 2023-09-28 21:21:43 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-28 21:21:43 --> Controller Class Initialized
INFO - 2023-09-28 21:21:43 --> Final output sent to browser
DEBUG - 2023-09-28 21:21:43 --> Total execution time: 0.0470
INFO - 2023-09-28 21:23:30 --> Config Class Initialized
INFO - 2023-09-28 21:23:30 --> Hooks Class Initialized
DEBUG - 2023-09-28 21:23:30 --> UTF-8 Support Enabled
INFO - 2023-09-28 21:23:30 --> Utf8 Class Initialized
INFO - 2023-09-28 21:23:30 --> URI Class Initialized
INFO - 2023-09-28 21:23:30 --> Router Class Initialized
INFO - 2023-09-28 21:23:30 --> Output Class Initialized
INFO - 2023-09-28 21:23:30 --> Security Class Initialized
DEBUG - 2023-09-28 21:23:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-28 21:23:30 --> Input Class Initialized
INFO - 2023-09-28 21:23:30 --> Language Class Initialized
INFO - 2023-09-28 21:23:30 --> Language Class Initialized
INFO - 2023-09-28 21:23:30 --> Config Class Initialized
INFO - 2023-09-28 21:23:30 --> Loader Class Initialized
INFO - 2023-09-28 21:23:30 --> Helper loaded: url_helper
INFO - 2023-09-28 21:23:30 --> Helper loaded: file_helper
INFO - 2023-09-28 21:23:30 --> Helper loaded: form_helper
INFO - 2023-09-28 21:23:30 --> Helper loaded: my_helper
INFO - 2023-09-28 21:23:30 --> Database Driver Class Initialized
INFO - 2023-09-28 21:23:30 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-28 21:23:30 --> Controller Class Initialized
INFO - 2023-09-28 21:23:31 --> Final output sent to browser
DEBUG - 2023-09-28 21:23:31 --> Total execution time: 0.0946
INFO - 2023-09-28 21:24:06 --> Config Class Initialized
INFO - 2023-09-28 21:24:06 --> Hooks Class Initialized
DEBUG - 2023-09-28 21:24:06 --> UTF-8 Support Enabled
INFO - 2023-09-28 21:24:06 --> Utf8 Class Initialized
INFO - 2023-09-28 21:24:06 --> URI Class Initialized
INFO - 2023-09-28 21:24:06 --> Router Class Initialized
INFO - 2023-09-28 21:24:06 --> Output Class Initialized
INFO - 2023-09-28 21:24:06 --> Security Class Initialized
DEBUG - 2023-09-28 21:24:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-28 21:24:06 --> Input Class Initialized
INFO - 2023-09-28 21:24:06 --> Language Class Initialized
INFO - 2023-09-28 21:24:06 --> Language Class Initialized
INFO - 2023-09-28 21:24:06 --> Config Class Initialized
INFO - 2023-09-28 21:24:06 --> Loader Class Initialized
INFO - 2023-09-28 21:24:06 --> Helper loaded: url_helper
INFO - 2023-09-28 21:24:06 --> Helper loaded: file_helper
INFO - 2023-09-28 21:24:06 --> Helper loaded: form_helper
INFO - 2023-09-28 21:24:06 --> Helper loaded: my_helper
INFO - 2023-09-28 21:24:06 --> Database Driver Class Initialized
INFO - 2023-09-28 21:24:06 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-28 21:24:06 --> Controller Class Initialized
INFO - 2023-09-28 21:24:06 --> Final output sent to browser
DEBUG - 2023-09-28 21:24:06 --> Total execution time: 0.0682
INFO - 2023-09-28 21:24:08 --> Config Class Initialized
INFO - 2023-09-28 21:24:08 --> Hooks Class Initialized
DEBUG - 2023-09-28 21:24:08 --> UTF-8 Support Enabled
INFO - 2023-09-28 21:24:08 --> Utf8 Class Initialized
INFO - 2023-09-28 21:24:08 --> URI Class Initialized
INFO - 2023-09-28 21:24:08 --> Router Class Initialized
INFO - 2023-09-28 21:24:08 --> Output Class Initialized
INFO - 2023-09-28 21:24:08 --> Security Class Initialized
DEBUG - 2023-09-28 21:24:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-28 21:24:08 --> Input Class Initialized
INFO - 2023-09-28 21:24:08 --> Language Class Initialized
INFO - 2023-09-28 21:24:08 --> Language Class Initialized
INFO - 2023-09-28 21:24:08 --> Config Class Initialized
INFO - 2023-09-28 21:24:08 --> Loader Class Initialized
INFO - 2023-09-28 21:24:08 --> Helper loaded: url_helper
INFO - 2023-09-28 21:24:08 --> Helper loaded: file_helper
INFO - 2023-09-28 21:24:08 --> Helper loaded: form_helper
INFO - 2023-09-28 21:24:08 --> Helper loaded: my_helper
INFO - 2023-09-28 21:24:08 --> Database Driver Class Initialized
INFO - 2023-09-28 21:24:08 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-28 21:24:08 --> Controller Class Initialized
INFO - 2023-09-28 21:24:08 --> Final output sent to browser
DEBUG - 2023-09-28 21:24:08 --> Total execution time: 0.0804
INFO - 2023-09-28 21:24:11 --> Config Class Initialized
INFO - 2023-09-28 21:24:11 --> Hooks Class Initialized
DEBUG - 2023-09-28 21:24:11 --> UTF-8 Support Enabled
INFO - 2023-09-28 21:24:11 --> Utf8 Class Initialized
INFO - 2023-09-28 21:24:11 --> URI Class Initialized
INFO - 2023-09-28 21:24:11 --> Router Class Initialized
INFO - 2023-09-28 21:24:11 --> Output Class Initialized
INFO - 2023-09-28 21:24:11 --> Security Class Initialized
DEBUG - 2023-09-28 21:24:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-28 21:24:11 --> Input Class Initialized
INFO - 2023-09-28 21:24:11 --> Language Class Initialized
INFO - 2023-09-28 21:24:11 --> Language Class Initialized
INFO - 2023-09-28 21:24:11 --> Config Class Initialized
INFO - 2023-09-28 21:24:11 --> Loader Class Initialized
INFO - 2023-09-28 21:24:11 --> Helper loaded: url_helper
INFO - 2023-09-28 21:24:11 --> Helper loaded: file_helper
INFO - 2023-09-28 21:24:11 --> Helper loaded: form_helper
INFO - 2023-09-28 21:24:11 --> Helper loaded: my_helper
INFO - 2023-09-28 21:24:11 --> Database Driver Class Initialized
INFO - 2023-09-28 21:24:11 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-28 21:24:11 --> Controller Class Initialized
INFO - 2023-09-28 21:24:29 --> Config Class Initialized
INFO - 2023-09-28 21:24:29 --> Hooks Class Initialized
DEBUG - 2023-09-28 21:24:29 --> UTF-8 Support Enabled
INFO - 2023-09-28 21:24:29 --> Utf8 Class Initialized
INFO - 2023-09-28 21:24:29 --> URI Class Initialized
INFO - 2023-09-28 21:24:29 --> Router Class Initialized
INFO - 2023-09-28 21:24:29 --> Output Class Initialized
INFO - 2023-09-28 21:24:29 --> Security Class Initialized
DEBUG - 2023-09-28 21:24:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-28 21:24:29 --> Input Class Initialized
INFO - 2023-09-28 21:24:29 --> Language Class Initialized
INFO - 2023-09-28 21:24:29 --> Language Class Initialized
INFO - 2023-09-28 21:24:29 --> Config Class Initialized
INFO - 2023-09-28 21:24:29 --> Loader Class Initialized
INFO - 2023-09-28 21:24:29 --> Helper loaded: url_helper
INFO - 2023-09-28 21:24:29 --> Helper loaded: file_helper
INFO - 2023-09-28 21:24:29 --> Helper loaded: form_helper
INFO - 2023-09-28 21:24:29 --> Helper loaded: my_helper
INFO - 2023-09-28 21:24:29 --> Database Driver Class Initialized
INFO - 2023-09-28 21:24:29 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-28 21:24:29 --> Controller Class Initialized
DEBUG - 2023-09-28 21:24:29 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/view_mapel/views/v_view_mapel.php
DEBUG - 2023-09-28 21:24:29 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-09-28 21:24:29 --> Final output sent to browser
DEBUG - 2023-09-28 21:24:29 --> Total execution time: 0.1002
INFO - 2023-09-28 21:24:31 --> Config Class Initialized
INFO - 2023-09-28 21:24:31 --> Hooks Class Initialized
DEBUG - 2023-09-28 21:24:31 --> UTF-8 Support Enabled
INFO - 2023-09-28 21:24:31 --> Utf8 Class Initialized
INFO - 2023-09-28 21:24:31 --> URI Class Initialized
INFO - 2023-09-28 21:24:31 --> Router Class Initialized
INFO - 2023-09-28 21:24:31 --> Output Class Initialized
INFO - 2023-09-28 21:24:31 --> Security Class Initialized
DEBUG - 2023-09-28 21:24:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-28 21:24:31 --> Input Class Initialized
INFO - 2023-09-28 21:24:31 --> Language Class Initialized
INFO - 2023-09-28 21:24:31 --> Language Class Initialized
INFO - 2023-09-28 21:24:31 --> Config Class Initialized
INFO - 2023-09-28 21:24:31 --> Loader Class Initialized
INFO - 2023-09-28 21:24:31 --> Helper loaded: url_helper
INFO - 2023-09-28 21:24:31 --> Helper loaded: file_helper
INFO - 2023-09-28 21:24:31 --> Helper loaded: form_helper
INFO - 2023-09-28 21:24:31 --> Helper loaded: my_helper
INFO - 2023-09-28 21:24:31 --> Database Driver Class Initialized
INFO - 2023-09-28 21:24:31 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-28 21:24:31 --> Controller Class Initialized
DEBUG - 2023-09-28 21:24:31 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/views/list.php
DEBUG - 2023-09-28 21:24:31 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-09-28 21:24:31 --> Final output sent to browser
DEBUG - 2023-09-28 21:24:31 --> Total execution time: 0.0787
INFO - 2023-09-28 21:24:31 --> Config Class Initialized
INFO - 2023-09-28 21:24:31 --> Hooks Class Initialized
DEBUG - 2023-09-28 21:24:31 --> UTF-8 Support Enabled
INFO - 2023-09-28 21:24:31 --> Utf8 Class Initialized
INFO - 2023-09-28 21:24:31 --> URI Class Initialized
INFO - 2023-09-28 21:24:31 --> Router Class Initialized
INFO - 2023-09-28 21:24:31 --> Output Class Initialized
INFO - 2023-09-28 21:24:31 --> Security Class Initialized
DEBUG - 2023-09-28 21:24:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-28 21:24:31 --> Input Class Initialized
INFO - 2023-09-28 21:24:31 --> Language Class Initialized
INFO - 2023-09-28 21:24:31 --> Language Class Initialized
INFO - 2023-09-28 21:24:31 --> Config Class Initialized
INFO - 2023-09-28 21:24:31 --> Loader Class Initialized
INFO - 2023-09-28 21:24:31 --> Helper loaded: url_helper
INFO - 2023-09-28 21:24:31 --> Helper loaded: file_helper
INFO - 2023-09-28 21:24:31 --> Helper loaded: form_helper
INFO - 2023-09-28 21:24:31 --> Helper loaded: my_helper
INFO - 2023-09-28 21:24:31 --> Database Driver Class Initialized
INFO - 2023-09-28 21:24:31 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-28 21:24:31 --> Controller Class Initialized
INFO - 2023-09-28 21:24:39 --> Config Class Initialized
INFO - 2023-09-28 21:24:39 --> Hooks Class Initialized
DEBUG - 2023-09-28 21:24:39 --> UTF-8 Support Enabled
INFO - 2023-09-28 21:24:39 --> Utf8 Class Initialized
INFO - 2023-09-28 21:24:39 --> URI Class Initialized
INFO - 2023-09-28 21:24:39 --> Router Class Initialized
INFO - 2023-09-28 21:24:39 --> Output Class Initialized
INFO - 2023-09-28 21:24:39 --> Security Class Initialized
DEBUG - 2023-09-28 21:24:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-28 21:24:39 --> Input Class Initialized
INFO - 2023-09-28 21:24:39 --> Language Class Initialized
INFO - 2023-09-28 21:24:39 --> Language Class Initialized
INFO - 2023-09-28 21:24:39 --> Config Class Initialized
INFO - 2023-09-28 21:24:39 --> Loader Class Initialized
INFO - 2023-09-28 21:24:39 --> Helper loaded: url_helper
INFO - 2023-09-28 21:24:39 --> Helper loaded: file_helper
INFO - 2023-09-28 21:24:39 --> Helper loaded: form_helper
INFO - 2023-09-28 21:24:39 --> Helper loaded: my_helper
INFO - 2023-09-28 21:24:39 --> Database Driver Class Initialized
INFO - 2023-09-28 21:24:39 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-28 21:24:39 --> Controller Class Initialized
INFO - 2023-09-28 21:24:39 --> Final output sent to browser
DEBUG - 2023-09-28 21:24:39 --> Total execution time: 0.0436
INFO - 2023-09-28 21:24:39 --> Config Class Initialized
INFO - 2023-09-28 21:24:39 --> Hooks Class Initialized
DEBUG - 2023-09-28 21:24:39 --> UTF-8 Support Enabled
INFO - 2023-09-28 21:24:39 --> Utf8 Class Initialized
INFO - 2023-09-28 21:24:39 --> URI Class Initialized
INFO - 2023-09-28 21:24:39 --> Router Class Initialized
INFO - 2023-09-28 21:24:39 --> Output Class Initialized
INFO - 2023-09-28 21:24:39 --> Security Class Initialized
DEBUG - 2023-09-28 21:24:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-28 21:24:39 --> Input Class Initialized
INFO - 2023-09-28 21:24:39 --> Language Class Initialized
INFO - 2023-09-28 21:24:39 --> Language Class Initialized
INFO - 2023-09-28 21:24:39 --> Config Class Initialized
INFO - 2023-09-28 21:24:39 --> Loader Class Initialized
INFO - 2023-09-28 21:24:39 --> Helper loaded: url_helper
INFO - 2023-09-28 21:24:39 --> Helper loaded: file_helper
INFO - 2023-09-28 21:24:39 --> Helper loaded: form_helper
INFO - 2023-09-28 21:24:39 --> Helper loaded: my_helper
INFO - 2023-09-28 21:24:39 --> Database Driver Class Initialized
INFO - 2023-09-28 21:24:39 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-28 21:24:39 --> Controller Class Initialized
INFO - 2023-09-28 21:24:39 --> Final output sent to browser
DEBUG - 2023-09-28 21:24:39 --> Total execution time: 0.0379
INFO - 2023-09-28 21:24:45 --> Config Class Initialized
INFO - 2023-09-28 21:24:45 --> Hooks Class Initialized
DEBUG - 2023-09-28 21:24:45 --> UTF-8 Support Enabled
INFO - 2023-09-28 21:24:45 --> Utf8 Class Initialized
INFO - 2023-09-28 21:24:45 --> URI Class Initialized
INFO - 2023-09-28 21:24:45 --> Router Class Initialized
INFO - 2023-09-28 21:24:45 --> Output Class Initialized
INFO - 2023-09-28 21:24:45 --> Security Class Initialized
DEBUG - 2023-09-28 21:24:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-28 21:24:45 --> Input Class Initialized
INFO - 2023-09-28 21:24:45 --> Language Class Initialized
INFO - 2023-09-28 21:24:45 --> Language Class Initialized
INFO - 2023-09-28 21:24:45 --> Config Class Initialized
INFO - 2023-09-28 21:24:45 --> Loader Class Initialized
INFO - 2023-09-28 21:24:45 --> Helper loaded: url_helper
INFO - 2023-09-28 21:24:45 --> Helper loaded: file_helper
INFO - 2023-09-28 21:24:45 --> Helper loaded: form_helper
INFO - 2023-09-28 21:24:45 --> Helper loaded: my_helper
INFO - 2023-09-28 21:24:45 --> Database Driver Class Initialized
INFO - 2023-09-28 21:24:45 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-28 21:24:45 --> Controller Class Initialized
INFO - 2023-09-28 21:24:45 --> Final output sent to browser
DEBUG - 2023-09-28 21:24:45 --> Total execution time: 0.0540
INFO - 2023-09-28 21:24:45 --> Config Class Initialized
INFO - 2023-09-28 21:24:45 --> Hooks Class Initialized
DEBUG - 2023-09-28 21:24:45 --> UTF-8 Support Enabled
INFO - 2023-09-28 21:24:45 --> Utf8 Class Initialized
INFO - 2023-09-28 21:24:45 --> URI Class Initialized
INFO - 2023-09-28 21:24:45 --> Router Class Initialized
INFO - 2023-09-28 21:24:45 --> Output Class Initialized
INFO - 2023-09-28 21:24:45 --> Security Class Initialized
DEBUG - 2023-09-28 21:24:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-28 21:24:45 --> Input Class Initialized
INFO - 2023-09-28 21:24:45 --> Language Class Initialized
INFO - 2023-09-28 21:24:45 --> Language Class Initialized
INFO - 2023-09-28 21:24:45 --> Config Class Initialized
INFO - 2023-09-28 21:24:45 --> Loader Class Initialized
INFO - 2023-09-28 21:24:45 --> Helper loaded: url_helper
INFO - 2023-09-28 21:24:45 --> Helper loaded: file_helper
INFO - 2023-09-28 21:24:45 --> Helper loaded: form_helper
INFO - 2023-09-28 21:24:45 --> Helper loaded: my_helper
INFO - 2023-09-28 21:24:45 --> Database Driver Class Initialized
INFO - 2023-09-28 21:24:45 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-28 21:24:45 --> Controller Class Initialized
INFO - 2023-09-28 21:24:46 --> Config Class Initialized
INFO - 2023-09-28 21:24:46 --> Hooks Class Initialized
DEBUG - 2023-09-28 21:24:46 --> UTF-8 Support Enabled
INFO - 2023-09-28 21:24:46 --> Utf8 Class Initialized
INFO - 2023-09-28 21:24:46 --> URI Class Initialized
INFO - 2023-09-28 21:24:46 --> Router Class Initialized
INFO - 2023-09-28 21:24:46 --> Output Class Initialized
INFO - 2023-09-28 21:24:46 --> Security Class Initialized
DEBUG - 2023-09-28 21:24:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-28 21:24:46 --> Input Class Initialized
INFO - 2023-09-28 21:24:46 --> Language Class Initialized
INFO - 2023-09-28 21:24:46 --> Language Class Initialized
INFO - 2023-09-28 21:24:46 --> Config Class Initialized
INFO - 2023-09-28 21:24:46 --> Loader Class Initialized
INFO - 2023-09-28 21:24:46 --> Helper loaded: url_helper
INFO - 2023-09-28 21:24:46 --> Helper loaded: file_helper
INFO - 2023-09-28 21:24:46 --> Helper loaded: form_helper
INFO - 2023-09-28 21:24:46 --> Helper loaded: my_helper
INFO - 2023-09-28 21:24:46 --> Database Driver Class Initialized
INFO - 2023-09-28 21:24:46 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-28 21:24:46 --> Controller Class Initialized
INFO - 2023-09-28 21:24:46 --> Final output sent to browser
DEBUG - 2023-09-28 21:24:46 --> Total execution time: 0.0429
INFO - 2023-09-28 21:24:46 --> Config Class Initialized
INFO - 2023-09-28 21:24:46 --> Hooks Class Initialized
DEBUG - 2023-09-28 21:24:46 --> UTF-8 Support Enabled
INFO - 2023-09-28 21:24:46 --> Utf8 Class Initialized
INFO - 2023-09-28 21:24:46 --> URI Class Initialized
INFO - 2023-09-28 21:24:46 --> Router Class Initialized
INFO - 2023-09-28 21:24:46 --> Output Class Initialized
INFO - 2023-09-28 21:24:46 --> Security Class Initialized
DEBUG - 2023-09-28 21:24:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-28 21:24:46 --> Input Class Initialized
INFO - 2023-09-28 21:24:46 --> Language Class Initialized
INFO - 2023-09-28 21:24:46 --> Language Class Initialized
INFO - 2023-09-28 21:24:46 --> Config Class Initialized
INFO - 2023-09-28 21:24:46 --> Loader Class Initialized
INFO - 2023-09-28 21:24:46 --> Helper loaded: url_helper
INFO - 2023-09-28 21:24:46 --> Helper loaded: file_helper
INFO - 2023-09-28 21:24:46 --> Helper loaded: form_helper
INFO - 2023-09-28 21:24:46 --> Helper loaded: my_helper
INFO - 2023-09-28 21:24:46 --> Database Driver Class Initialized
INFO - 2023-09-28 21:24:46 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-28 21:24:46 --> Controller Class Initialized
INFO - 2023-09-28 21:24:47 --> Config Class Initialized
INFO - 2023-09-28 21:24:47 --> Hooks Class Initialized
DEBUG - 2023-09-28 21:24:47 --> UTF-8 Support Enabled
INFO - 2023-09-28 21:24:47 --> Utf8 Class Initialized
INFO - 2023-09-28 21:24:47 --> URI Class Initialized
INFO - 2023-09-28 21:24:47 --> Router Class Initialized
INFO - 2023-09-28 21:24:47 --> Output Class Initialized
INFO - 2023-09-28 21:24:47 --> Security Class Initialized
DEBUG - 2023-09-28 21:24:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-28 21:24:47 --> Input Class Initialized
INFO - 2023-09-28 21:24:47 --> Language Class Initialized
INFO - 2023-09-28 21:24:47 --> Language Class Initialized
INFO - 2023-09-28 21:24:47 --> Config Class Initialized
INFO - 2023-09-28 21:24:47 --> Loader Class Initialized
INFO - 2023-09-28 21:24:47 --> Helper loaded: url_helper
INFO - 2023-09-28 21:24:47 --> Helper loaded: file_helper
INFO - 2023-09-28 21:24:47 --> Helper loaded: form_helper
INFO - 2023-09-28 21:24:47 --> Helper loaded: my_helper
INFO - 2023-09-28 21:24:47 --> Database Driver Class Initialized
INFO - 2023-09-28 21:24:47 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-28 21:24:47 --> Controller Class Initialized
INFO - 2023-09-28 21:24:47 --> Final output sent to browser
DEBUG - 2023-09-28 21:24:47 --> Total execution time: 0.0394
INFO - 2023-09-28 21:24:47 --> Config Class Initialized
INFO - 2023-09-28 21:24:47 --> Hooks Class Initialized
DEBUG - 2023-09-28 21:24:47 --> UTF-8 Support Enabled
INFO - 2023-09-28 21:24:47 --> Utf8 Class Initialized
INFO - 2023-09-28 21:24:47 --> URI Class Initialized
INFO - 2023-09-28 21:24:47 --> Router Class Initialized
INFO - 2023-09-28 21:24:47 --> Output Class Initialized
INFO - 2023-09-28 21:24:47 --> Security Class Initialized
DEBUG - 2023-09-28 21:24:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-28 21:24:47 --> Input Class Initialized
INFO - 2023-09-28 21:24:47 --> Language Class Initialized
INFO - 2023-09-28 21:24:47 --> Language Class Initialized
INFO - 2023-09-28 21:24:47 --> Config Class Initialized
INFO - 2023-09-28 21:24:47 --> Loader Class Initialized
INFO - 2023-09-28 21:24:47 --> Helper loaded: url_helper
INFO - 2023-09-28 21:24:47 --> Helper loaded: file_helper
INFO - 2023-09-28 21:24:47 --> Helper loaded: form_helper
INFO - 2023-09-28 21:24:47 --> Helper loaded: my_helper
INFO - 2023-09-28 21:24:47 --> Database Driver Class Initialized
INFO - 2023-09-28 21:24:47 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-28 21:24:47 --> Controller Class Initialized
INFO - 2023-09-28 21:24:48 --> Config Class Initialized
INFO - 2023-09-28 21:24:48 --> Hooks Class Initialized
DEBUG - 2023-09-28 21:24:48 --> UTF-8 Support Enabled
INFO - 2023-09-28 21:24:48 --> Utf8 Class Initialized
INFO - 2023-09-28 21:24:48 --> URI Class Initialized
INFO - 2023-09-28 21:24:48 --> Router Class Initialized
INFO - 2023-09-28 21:24:48 --> Output Class Initialized
INFO - 2023-09-28 21:24:48 --> Security Class Initialized
DEBUG - 2023-09-28 21:24:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-28 21:24:48 --> Input Class Initialized
INFO - 2023-09-28 21:24:48 --> Language Class Initialized
INFO - 2023-09-28 21:24:48 --> Language Class Initialized
INFO - 2023-09-28 21:24:48 --> Config Class Initialized
INFO - 2023-09-28 21:24:48 --> Loader Class Initialized
INFO - 2023-09-28 21:24:48 --> Helper loaded: url_helper
INFO - 2023-09-28 21:24:48 --> Helper loaded: file_helper
INFO - 2023-09-28 21:24:48 --> Helper loaded: form_helper
INFO - 2023-09-28 21:24:48 --> Helper loaded: my_helper
INFO - 2023-09-28 21:24:48 --> Database Driver Class Initialized
INFO - 2023-09-28 21:24:48 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-28 21:24:48 --> Controller Class Initialized
INFO - 2023-09-28 21:24:48 --> Final output sent to browser
DEBUG - 2023-09-28 21:24:48 --> Total execution time: 0.1601
INFO - 2023-09-28 21:24:48 --> Config Class Initialized
INFO - 2023-09-28 21:24:48 --> Hooks Class Initialized
DEBUG - 2023-09-28 21:24:48 --> UTF-8 Support Enabled
INFO - 2023-09-28 21:24:48 --> Utf8 Class Initialized
INFO - 2023-09-28 21:24:48 --> URI Class Initialized
INFO - 2023-09-28 21:24:48 --> Router Class Initialized
INFO - 2023-09-28 21:24:48 --> Output Class Initialized
INFO - 2023-09-28 21:24:48 --> Security Class Initialized
DEBUG - 2023-09-28 21:24:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-28 21:24:48 --> Input Class Initialized
INFO - 2023-09-28 21:24:48 --> Language Class Initialized
INFO - 2023-09-28 21:24:48 --> Language Class Initialized
INFO - 2023-09-28 21:24:48 --> Config Class Initialized
INFO - 2023-09-28 21:24:48 --> Loader Class Initialized
INFO - 2023-09-28 21:24:48 --> Helper loaded: url_helper
INFO - 2023-09-28 21:24:48 --> Helper loaded: file_helper
INFO - 2023-09-28 21:24:48 --> Helper loaded: form_helper
INFO - 2023-09-28 21:24:48 --> Helper loaded: my_helper
INFO - 2023-09-28 21:24:48 --> Database Driver Class Initialized
INFO - 2023-09-28 21:24:48 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-28 21:24:48 --> Controller Class Initialized
INFO - 2023-09-28 21:24:48 --> Config Class Initialized
INFO - 2023-09-28 21:24:48 --> Hooks Class Initialized
DEBUG - 2023-09-28 21:24:48 --> UTF-8 Support Enabled
INFO - 2023-09-28 21:24:48 --> Utf8 Class Initialized
INFO - 2023-09-28 21:24:48 --> URI Class Initialized
INFO - 2023-09-28 21:24:48 --> Router Class Initialized
INFO - 2023-09-28 21:24:48 --> Output Class Initialized
INFO - 2023-09-28 21:24:49 --> Security Class Initialized
DEBUG - 2023-09-28 21:24:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-28 21:24:49 --> Input Class Initialized
INFO - 2023-09-28 21:24:49 --> Language Class Initialized
INFO - 2023-09-28 21:24:49 --> Language Class Initialized
INFO - 2023-09-28 21:24:49 --> Config Class Initialized
INFO - 2023-09-28 21:24:49 --> Loader Class Initialized
INFO - 2023-09-28 21:24:49 --> Helper loaded: url_helper
INFO - 2023-09-28 21:24:49 --> Helper loaded: file_helper
INFO - 2023-09-28 21:24:49 --> Helper loaded: form_helper
INFO - 2023-09-28 21:24:49 --> Helper loaded: my_helper
INFO - 2023-09-28 21:24:49 --> Database Driver Class Initialized
INFO - 2023-09-28 21:24:49 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-28 21:24:49 --> Controller Class Initialized
INFO - 2023-09-28 21:24:49 --> Final output sent to browser
DEBUG - 2023-09-28 21:24:49 --> Total execution time: 0.0495
INFO - 2023-09-28 21:24:49 --> Config Class Initialized
INFO - 2023-09-28 21:24:49 --> Hooks Class Initialized
DEBUG - 2023-09-28 21:24:49 --> UTF-8 Support Enabled
INFO - 2023-09-28 21:24:49 --> Utf8 Class Initialized
INFO - 2023-09-28 21:24:49 --> URI Class Initialized
INFO - 2023-09-28 21:24:49 --> Router Class Initialized
INFO - 2023-09-28 21:24:49 --> Output Class Initialized
INFO - 2023-09-28 21:24:49 --> Security Class Initialized
DEBUG - 2023-09-28 21:24:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-28 21:24:49 --> Input Class Initialized
INFO - 2023-09-28 21:24:49 --> Language Class Initialized
INFO - 2023-09-28 21:24:49 --> Language Class Initialized
INFO - 2023-09-28 21:24:49 --> Config Class Initialized
INFO - 2023-09-28 21:24:49 --> Loader Class Initialized
INFO - 2023-09-28 21:24:49 --> Helper loaded: url_helper
INFO - 2023-09-28 21:24:49 --> Helper loaded: file_helper
INFO - 2023-09-28 21:24:49 --> Helper loaded: form_helper
INFO - 2023-09-28 21:24:49 --> Helper loaded: my_helper
INFO - 2023-09-28 21:24:49 --> Database Driver Class Initialized
INFO - 2023-09-28 21:24:49 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-28 21:24:49 --> Controller Class Initialized
INFO - 2023-09-28 21:24:49 --> Config Class Initialized
INFO - 2023-09-28 21:24:49 --> Hooks Class Initialized
DEBUG - 2023-09-28 21:24:49 --> UTF-8 Support Enabled
INFO - 2023-09-28 21:24:49 --> Utf8 Class Initialized
INFO - 2023-09-28 21:24:49 --> URI Class Initialized
INFO - 2023-09-28 21:24:49 --> Router Class Initialized
INFO - 2023-09-28 21:24:49 --> Output Class Initialized
INFO - 2023-09-28 21:24:49 --> Security Class Initialized
DEBUG - 2023-09-28 21:24:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-28 21:24:49 --> Input Class Initialized
INFO - 2023-09-28 21:24:49 --> Language Class Initialized
INFO - 2023-09-28 21:24:49 --> Language Class Initialized
INFO - 2023-09-28 21:24:49 --> Config Class Initialized
INFO - 2023-09-28 21:24:49 --> Loader Class Initialized
INFO - 2023-09-28 21:24:49 --> Helper loaded: url_helper
INFO - 2023-09-28 21:24:49 --> Helper loaded: file_helper
INFO - 2023-09-28 21:24:49 --> Helper loaded: form_helper
INFO - 2023-09-28 21:24:49 --> Helper loaded: my_helper
INFO - 2023-09-28 21:24:49 --> Database Driver Class Initialized
INFO - 2023-09-28 21:24:49 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-28 21:24:49 --> Controller Class Initialized
INFO - 2023-09-28 21:24:49 --> Final output sent to browser
DEBUG - 2023-09-28 21:24:49 --> Total execution time: 0.0593
INFO - 2023-09-28 21:24:50 --> Config Class Initialized
INFO - 2023-09-28 21:24:50 --> Hooks Class Initialized
DEBUG - 2023-09-28 21:24:50 --> UTF-8 Support Enabled
INFO - 2023-09-28 21:24:50 --> Utf8 Class Initialized
INFO - 2023-09-28 21:24:50 --> URI Class Initialized
INFO - 2023-09-28 21:24:50 --> Router Class Initialized
INFO - 2023-09-28 21:24:50 --> Output Class Initialized
INFO - 2023-09-28 21:24:50 --> Security Class Initialized
DEBUG - 2023-09-28 21:24:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-28 21:24:50 --> Input Class Initialized
INFO - 2023-09-28 21:24:50 --> Language Class Initialized
INFO - 2023-09-28 21:24:50 --> Language Class Initialized
INFO - 2023-09-28 21:24:50 --> Config Class Initialized
INFO - 2023-09-28 21:24:50 --> Loader Class Initialized
INFO - 2023-09-28 21:24:50 --> Helper loaded: url_helper
INFO - 2023-09-28 21:24:50 --> Helper loaded: file_helper
INFO - 2023-09-28 21:24:50 --> Helper loaded: form_helper
INFO - 2023-09-28 21:24:50 --> Helper loaded: my_helper
INFO - 2023-09-28 21:24:50 --> Database Driver Class Initialized
INFO - 2023-09-28 21:24:50 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-28 21:24:50 --> Controller Class Initialized
INFO - 2023-09-28 21:24:50 --> Final output sent to browser
DEBUG - 2023-09-28 21:24:50 --> Total execution time: 0.0470
INFO - 2023-09-28 21:24:50 --> Config Class Initialized
INFO - 2023-09-28 21:24:50 --> Hooks Class Initialized
DEBUG - 2023-09-28 21:24:50 --> UTF-8 Support Enabled
INFO - 2023-09-28 21:24:50 --> Utf8 Class Initialized
INFO - 2023-09-28 21:24:50 --> URI Class Initialized
INFO - 2023-09-28 21:24:50 --> Router Class Initialized
INFO - 2023-09-28 21:24:50 --> Output Class Initialized
INFO - 2023-09-28 21:24:50 --> Security Class Initialized
DEBUG - 2023-09-28 21:24:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-28 21:24:50 --> Input Class Initialized
INFO - 2023-09-28 21:24:50 --> Language Class Initialized
INFO - 2023-09-28 21:24:50 --> Language Class Initialized
INFO - 2023-09-28 21:24:50 --> Config Class Initialized
INFO - 2023-09-28 21:24:50 --> Loader Class Initialized
INFO - 2023-09-28 21:24:50 --> Helper loaded: url_helper
INFO - 2023-09-28 21:24:50 --> Helper loaded: file_helper
INFO - 2023-09-28 21:24:50 --> Helper loaded: form_helper
INFO - 2023-09-28 21:24:50 --> Helper loaded: my_helper
INFO - 2023-09-28 21:24:50 --> Database Driver Class Initialized
INFO - 2023-09-28 21:24:50 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-28 21:24:50 --> Controller Class Initialized
INFO - 2023-09-28 21:24:52 --> Config Class Initialized
INFO - 2023-09-28 21:24:52 --> Hooks Class Initialized
DEBUG - 2023-09-28 21:24:52 --> UTF-8 Support Enabled
INFO - 2023-09-28 21:24:52 --> Utf8 Class Initialized
INFO - 2023-09-28 21:24:52 --> URI Class Initialized
INFO - 2023-09-28 21:24:52 --> Router Class Initialized
INFO - 2023-09-28 21:24:52 --> Output Class Initialized
INFO - 2023-09-28 21:24:52 --> Security Class Initialized
DEBUG - 2023-09-28 21:24:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-28 21:24:52 --> Input Class Initialized
INFO - 2023-09-28 21:24:52 --> Language Class Initialized
INFO - 2023-09-28 21:24:52 --> Language Class Initialized
INFO - 2023-09-28 21:24:52 --> Config Class Initialized
INFO - 2023-09-28 21:24:52 --> Loader Class Initialized
INFO - 2023-09-28 21:24:52 --> Helper loaded: url_helper
INFO - 2023-09-28 21:24:52 --> Helper loaded: file_helper
INFO - 2023-09-28 21:24:52 --> Helper loaded: form_helper
INFO - 2023-09-28 21:24:52 --> Helper loaded: my_helper
INFO - 2023-09-28 21:24:52 --> Database Driver Class Initialized
INFO - 2023-09-28 21:24:52 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-28 21:24:52 --> Controller Class Initialized
INFO - 2023-09-28 21:24:52 --> Final output sent to browser
DEBUG - 2023-09-28 21:24:52 --> Total execution time: 0.0475
INFO - 2023-09-28 21:24:52 --> Config Class Initialized
INFO - 2023-09-28 21:24:52 --> Hooks Class Initialized
DEBUG - 2023-09-28 21:24:52 --> UTF-8 Support Enabled
INFO - 2023-09-28 21:24:52 --> Utf8 Class Initialized
INFO - 2023-09-28 21:24:52 --> URI Class Initialized
INFO - 2023-09-28 21:24:52 --> Router Class Initialized
INFO - 2023-09-28 21:24:52 --> Output Class Initialized
INFO - 2023-09-28 21:24:52 --> Security Class Initialized
DEBUG - 2023-09-28 21:24:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-28 21:24:52 --> Input Class Initialized
INFO - 2023-09-28 21:24:52 --> Language Class Initialized
INFO - 2023-09-28 21:24:52 --> Language Class Initialized
INFO - 2023-09-28 21:24:52 --> Config Class Initialized
INFO - 2023-09-28 21:24:52 --> Loader Class Initialized
INFO - 2023-09-28 21:24:52 --> Helper loaded: url_helper
INFO - 2023-09-28 21:24:52 --> Helper loaded: file_helper
INFO - 2023-09-28 21:24:52 --> Helper loaded: form_helper
INFO - 2023-09-28 21:24:52 --> Helper loaded: my_helper
INFO - 2023-09-28 21:24:52 --> Database Driver Class Initialized
INFO - 2023-09-28 21:24:52 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-28 21:24:52 --> Controller Class Initialized
INFO - 2023-09-28 21:24:53 --> Config Class Initialized
INFO - 2023-09-28 21:24:53 --> Hooks Class Initialized
DEBUG - 2023-09-28 21:24:53 --> UTF-8 Support Enabled
INFO - 2023-09-28 21:24:53 --> Utf8 Class Initialized
INFO - 2023-09-28 21:24:53 --> URI Class Initialized
INFO - 2023-09-28 21:24:53 --> Router Class Initialized
INFO - 2023-09-28 21:24:53 --> Output Class Initialized
INFO - 2023-09-28 21:24:53 --> Security Class Initialized
DEBUG - 2023-09-28 21:24:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-28 21:24:53 --> Input Class Initialized
INFO - 2023-09-28 21:24:53 --> Language Class Initialized
INFO - 2023-09-28 21:24:53 --> Language Class Initialized
INFO - 2023-09-28 21:24:53 --> Config Class Initialized
INFO - 2023-09-28 21:24:53 --> Loader Class Initialized
INFO - 2023-09-28 21:24:53 --> Helper loaded: url_helper
INFO - 2023-09-28 21:24:53 --> Helper loaded: file_helper
INFO - 2023-09-28 21:24:53 --> Helper loaded: form_helper
INFO - 2023-09-28 21:24:53 --> Helper loaded: my_helper
INFO - 2023-09-28 21:24:53 --> Database Driver Class Initialized
INFO - 2023-09-28 21:24:53 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-28 21:24:53 --> Controller Class Initialized
INFO - 2023-09-28 21:24:53 --> Final output sent to browser
DEBUG - 2023-09-28 21:24:53 --> Total execution time: 0.0386
INFO - 2023-09-28 21:24:54 --> Config Class Initialized
INFO - 2023-09-28 21:24:54 --> Hooks Class Initialized
DEBUG - 2023-09-28 21:24:54 --> UTF-8 Support Enabled
INFO - 2023-09-28 21:24:54 --> Utf8 Class Initialized
INFO - 2023-09-28 21:24:54 --> URI Class Initialized
INFO - 2023-09-28 21:24:54 --> Router Class Initialized
INFO - 2023-09-28 21:24:54 --> Output Class Initialized
INFO - 2023-09-28 21:24:54 --> Security Class Initialized
DEBUG - 2023-09-28 21:24:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-28 21:24:54 --> Input Class Initialized
INFO - 2023-09-28 21:24:54 --> Language Class Initialized
INFO - 2023-09-28 21:24:54 --> Language Class Initialized
INFO - 2023-09-28 21:24:54 --> Config Class Initialized
INFO - 2023-09-28 21:24:54 --> Loader Class Initialized
INFO - 2023-09-28 21:24:54 --> Helper loaded: url_helper
INFO - 2023-09-28 21:24:54 --> Helper loaded: file_helper
INFO - 2023-09-28 21:24:54 --> Helper loaded: form_helper
INFO - 2023-09-28 21:24:54 --> Helper loaded: my_helper
INFO - 2023-09-28 21:24:54 --> Database Driver Class Initialized
INFO - 2023-09-28 21:24:54 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-28 21:24:54 --> Controller Class Initialized
INFO - 2023-09-28 21:24:55 --> Config Class Initialized
INFO - 2023-09-28 21:24:55 --> Hooks Class Initialized
DEBUG - 2023-09-28 21:24:55 --> UTF-8 Support Enabled
INFO - 2023-09-28 21:24:55 --> Utf8 Class Initialized
INFO - 2023-09-28 21:24:55 --> URI Class Initialized
INFO - 2023-09-28 21:24:55 --> Router Class Initialized
INFO - 2023-09-28 21:24:55 --> Output Class Initialized
INFO - 2023-09-28 21:24:55 --> Security Class Initialized
DEBUG - 2023-09-28 21:24:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-28 21:24:55 --> Input Class Initialized
INFO - 2023-09-28 21:24:55 --> Language Class Initialized
INFO - 2023-09-28 21:24:55 --> Language Class Initialized
INFO - 2023-09-28 21:24:55 --> Config Class Initialized
INFO - 2023-09-28 21:24:55 --> Loader Class Initialized
INFO - 2023-09-28 21:24:55 --> Helper loaded: url_helper
INFO - 2023-09-28 21:24:55 --> Helper loaded: file_helper
INFO - 2023-09-28 21:24:55 --> Helper loaded: form_helper
INFO - 2023-09-28 21:24:55 --> Helper loaded: my_helper
INFO - 2023-09-28 21:24:55 --> Database Driver Class Initialized
INFO - 2023-09-28 21:24:55 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-28 21:24:55 --> Controller Class Initialized
INFO - 2023-09-28 21:24:55 --> Final output sent to browser
DEBUG - 2023-09-28 21:24:55 --> Total execution time: 0.0503
INFO - 2023-09-28 21:24:55 --> Config Class Initialized
INFO - 2023-09-28 21:24:55 --> Hooks Class Initialized
DEBUG - 2023-09-28 21:24:55 --> UTF-8 Support Enabled
INFO - 2023-09-28 21:24:55 --> Utf8 Class Initialized
INFO - 2023-09-28 21:24:55 --> URI Class Initialized
INFO - 2023-09-28 21:24:55 --> Router Class Initialized
INFO - 2023-09-28 21:24:55 --> Output Class Initialized
INFO - 2023-09-28 21:24:55 --> Security Class Initialized
DEBUG - 2023-09-28 21:24:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-28 21:24:55 --> Input Class Initialized
INFO - 2023-09-28 21:24:55 --> Language Class Initialized
INFO - 2023-09-28 21:24:55 --> Language Class Initialized
INFO - 2023-09-28 21:24:55 --> Config Class Initialized
INFO - 2023-09-28 21:24:55 --> Loader Class Initialized
INFO - 2023-09-28 21:24:55 --> Helper loaded: url_helper
INFO - 2023-09-28 21:24:55 --> Helper loaded: file_helper
INFO - 2023-09-28 21:24:55 --> Helper loaded: form_helper
INFO - 2023-09-28 21:24:55 --> Helper loaded: my_helper
INFO - 2023-09-28 21:24:55 --> Database Driver Class Initialized
INFO - 2023-09-28 21:24:55 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-28 21:24:55 --> Controller Class Initialized
INFO - 2023-09-28 21:24:56 --> Config Class Initialized
INFO - 2023-09-28 21:24:56 --> Hooks Class Initialized
DEBUG - 2023-09-28 21:24:56 --> UTF-8 Support Enabled
INFO - 2023-09-28 21:24:56 --> Utf8 Class Initialized
INFO - 2023-09-28 21:24:56 --> URI Class Initialized
INFO - 2023-09-28 21:24:56 --> Router Class Initialized
INFO - 2023-09-28 21:24:56 --> Output Class Initialized
INFO - 2023-09-28 21:24:56 --> Security Class Initialized
DEBUG - 2023-09-28 21:24:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-28 21:24:56 --> Input Class Initialized
INFO - 2023-09-28 21:24:56 --> Language Class Initialized
INFO - 2023-09-28 21:24:56 --> Language Class Initialized
INFO - 2023-09-28 21:24:56 --> Config Class Initialized
INFO - 2023-09-28 21:24:56 --> Loader Class Initialized
INFO - 2023-09-28 21:24:56 --> Helper loaded: url_helper
INFO - 2023-09-28 21:24:56 --> Helper loaded: file_helper
INFO - 2023-09-28 21:24:56 --> Helper loaded: form_helper
INFO - 2023-09-28 21:24:56 --> Helper loaded: my_helper
INFO - 2023-09-28 21:24:56 --> Database Driver Class Initialized
INFO - 2023-09-28 21:24:56 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-28 21:24:56 --> Controller Class Initialized
INFO - 2023-09-28 21:24:56 --> Final output sent to browser
DEBUG - 2023-09-28 21:24:56 --> Total execution time: 0.1253
INFO - 2023-09-28 21:24:56 --> Config Class Initialized
INFO - 2023-09-28 21:24:56 --> Hooks Class Initialized
DEBUG - 2023-09-28 21:24:56 --> UTF-8 Support Enabled
INFO - 2023-09-28 21:24:56 --> Utf8 Class Initialized
INFO - 2023-09-28 21:24:56 --> URI Class Initialized
INFO - 2023-09-28 21:24:56 --> Router Class Initialized
INFO - 2023-09-28 21:24:56 --> Output Class Initialized
INFO - 2023-09-28 21:24:56 --> Security Class Initialized
DEBUG - 2023-09-28 21:24:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-28 21:24:56 --> Input Class Initialized
INFO - 2023-09-28 21:24:56 --> Language Class Initialized
INFO - 2023-09-28 21:24:56 --> Language Class Initialized
INFO - 2023-09-28 21:24:56 --> Config Class Initialized
INFO - 2023-09-28 21:24:56 --> Loader Class Initialized
INFO - 2023-09-28 21:24:56 --> Helper loaded: url_helper
INFO - 2023-09-28 21:24:56 --> Helper loaded: file_helper
INFO - 2023-09-28 21:24:56 --> Helper loaded: form_helper
INFO - 2023-09-28 21:24:56 --> Helper loaded: my_helper
INFO - 2023-09-28 21:24:56 --> Database Driver Class Initialized
INFO - 2023-09-28 21:24:56 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-28 21:24:56 --> Controller Class Initialized
INFO - 2023-09-28 21:24:57 --> Config Class Initialized
INFO - 2023-09-28 21:24:57 --> Hooks Class Initialized
DEBUG - 2023-09-28 21:24:57 --> UTF-8 Support Enabled
INFO - 2023-09-28 21:24:57 --> Utf8 Class Initialized
INFO - 2023-09-28 21:24:57 --> URI Class Initialized
INFO - 2023-09-28 21:24:57 --> Router Class Initialized
INFO - 2023-09-28 21:24:57 --> Output Class Initialized
INFO - 2023-09-28 21:24:57 --> Security Class Initialized
DEBUG - 2023-09-28 21:24:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-28 21:24:57 --> Input Class Initialized
INFO - 2023-09-28 21:24:57 --> Language Class Initialized
INFO - 2023-09-28 21:24:57 --> Language Class Initialized
INFO - 2023-09-28 21:24:57 --> Config Class Initialized
INFO - 2023-09-28 21:24:57 --> Loader Class Initialized
INFO - 2023-09-28 21:24:57 --> Helper loaded: url_helper
INFO - 2023-09-28 21:24:57 --> Helper loaded: file_helper
INFO - 2023-09-28 21:24:57 --> Helper loaded: form_helper
INFO - 2023-09-28 21:24:57 --> Helper loaded: my_helper
INFO - 2023-09-28 21:24:57 --> Database Driver Class Initialized
INFO - 2023-09-28 21:24:57 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-28 21:24:57 --> Controller Class Initialized
INFO - 2023-09-28 21:24:57 --> Final output sent to browser
DEBUG - 2023-09-28 21:24:57 --> Total execution time: 0.0418
INFO - 2023-09-28 21:24:57 --> Config Class Initialized
INFO - 2023-09-28 21:24:57 --> Hooks Class Initialized
DEBUG - 2023-09-28 21:24:57 --> UTF-8 Support Enabled
INFO - 2023-09-28 21:24:57 --> Utf8 Class Initialized
INFO - 2023-09-28 21:24:57 --> URI Class Initialized
INFO - 2023-09-28 21:24:57 --> Router Class Initialized
INFO - 2023-09-28 21:24:57 --> Output Class Initialized
INFO - 2023-09-28 21:24:57 --> Security Class Initialized
DEBUG - 2023-09-28 21:24:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-28 21:24:57 --> Input Class Initialized
INFO - 2023-09-28 21:24:57 --> Language Class Initialized
INFO - 2023-09-28 21:24:57 --> Language Class Initialized
INFO - 2023-09-28 21:24:57 --> Config Class Initialized
INFO - 2023-09-28 21:24:57 --> Loader Class Initialized
INFO - 2023-09-28 21:24:57 --> Helper loaded: url_helper
INFO - 2023-09-28 21:24:57 --> Helper loaded: file_helper
INFO - 2023-09-28 21:24:57 --> Helper loaded: form_helper
INFO - 2023-09-28 21:24:57 --> Helper loaded: my_helper
INFO - 2023-09-28 21:24:57 --> Database Driver Class Initialized
INFO - 2023-09-28 21:24:57 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-28 21:24:57 --> Controller Class Initialized
INFO - 2023-09-28 21:24:58 --> Config Class Initialized
INFO - 2023-09-28 21:24:58 --> Hooks Class Initialized
DEBUG - 2023-09-28 21:24:58 --> UTF-8 Support Enabled
INFO - 2023-09-28 21:24:58 --> Utf8 Class Initialized
INFO - 2023-09-28 21:24:58 --> URI Class Initialized
INFO - 2023-09-28 21:24:58 --> Router Class Initialized
INFO - 2023-09-28 21:24:58 --> Output Class Initialized
INFO - 2023-09-28 21:24:58 --> Security Class Initialized
DEBUG - 2023-09-28 21:24:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-28 21:24:58 --> Input Class Initialized
INFO - 2023-09-28 21:24:58 --> Language Class Initialized
INFO - 2023-09-28 21:24:58 --> Language Class Initialized
INFO - 2023-09-28 21:24:58 --> Config Class Initialized
INFO - 2023-09-28 21:24:58 --> Loader Class Initialized
INFO - 2023-09-28 21:24:58 --> Helper loaded: url_helper
INFO - 2023-09-28 21:24:58 --> Helper loaded: file_helper
INFO - 2023-09-28 21:24:58 --> Helper loaded: form_helper
INFO - 2023-09-28 21:24:58 --> Helper loaded: my_helper
INFO - 2023-09-28 21:24:58 --> Database Driver Class Initialized
INFO - 2023-09-28 21:24:58 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-28 21:24:58 --> Controller Class Initialized
INFO - 2023-09-28 21:24:58 --> Final output sent to browser
DEBUG - 2023-09-28 21:24:58 --> Total execution time: 0.0379
INFO - 2023-09-28 21:24:58 --> Config Class Initialized
INFO - 2023-09-28 21:24:58 --> Hooks Class Initialized
DEBUG - 2023-09-28 21:24:58 --> UTF-8 Support Enabled
INFO - 2023-09-28 21:24:58 --> Utf8 Class Initialized
INFO - 2023-09-28 21:24:58 --> URI Class Initialized
INFO - 2023-09-28 21:24:58 --> Router Class Initialized
INFO - 2023-09-28 21:24:58 --> Output Class Initialized
INFO - 2023-09-28 21:24:58 --> Security Class Initialized
DEBUG - 2023-09-28 21:24:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-28 21:24:58 --> Input Class Initialized
INFO - 2023-09-28 21:24:58 --> Language Class Initialized
INFO - 2023-09-28 21:24:58 --> Language Class Initialized
INFO - 2023-09-28 21:24:58 --> Config Class Initialized
INFO - 2023-09-28 21:24:58 --> Loader Class Initialized
INFO - 2023-09-28 21:24:58 --> Helper loaded: url_helper
INFO - 2023-09-28 21:24:58 --> Helper loaded: file_helper
INFO - 2023-09-28 21:24:58 --> Helper loaded: form_helper
INFO - 2023-09-28 21:24:58 --> Helper loaded: my_helper
INFO - 2023-09-28 21:24:58 --> Database Driver Class Initialized
INFO - 2023-09-28 21:24:58 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-28 21:24:58 --> Controller Class Initialized
INFO - 2023-09-28 21:25:00 --> Config Class Initialized
INFO - 2023-09-28 21:25:00 --> Hooks Class Initialized
DEBUG - 2023-09-28 21:25:00 --> UTF-8 Support Enabled
INFO - 2023-09-28 21:25:00 --> Utf8 Class Initialized
INFO - 2023-09-28 21:25:00 --> URI Class Initialized
INFO - 2023-09-28 21:25:00 --> Router Class Initialized
INFO - 2023-09-28 21:25:00 --> Output Class Initialized
INFO - 2023-09-28 21:25:00 --> Security Class Initialized
DEBUG - 2023-09-28 21:25:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-28 21:25:00 --> Input Class Initialized
INFO - 2023-09-28 21:25:00 --> Language Class Initialized
INFO - 2023-09-28 21:25:00 --> Language Class Initialized
INFO - 2023-09-28 21:25:00 --> Config Class Initialized
INFO - 2023-09-28 21:25:00 --> Loader Class Initialized
INFO - 2023-09-28 21:25:00 --> Helper loaded: url_helper
INFO - 2023-09-28 21:25:00 --> Helper loaded: file_helper
INFO - 2023-09-28 21:25:00 --> Helper loaded: form_helper
INFO - 2023-09-28 21:25:00 --> Helper loaded: my_helper
INFO - 2023-09-28 21:25:00 --> Database Driver Class Initialized
INFO - 2023-09-28 21:25:00 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-28 21:25:00 --> Controller Class Initialized
INFO - 2023-09-28 21:25:00 --> Final output sent to browser
DEBUG - 2023-09-28 21:25:00 --> Total execution time: 0.0507
INFO - 2023-09-28 21:25:00 --> Config Class Initialized
INFO - 2023-09-28 21:25:00 --> Hooks Class Initialized
DEBUG - 2023-09-28 21:25:00 --> UTF-8 Support Enabled
INFO - 2023-09-28 21:25:00 --> Utf8 Class Initialized
INFO - 2023-09-28 21:25:00 --> URI Class Initialized
INFO - 2023-09-28 21:25:00 --> Router Class Initialized
INFO - 2023-09-28 21:25:00 --> Output Class Initialized
INFO - 2023-09-28 21:25:00 --> Security Class Initialized
DEBUG - 2023-09-28 21:25:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-28 21:25:00 --> Input Class Initialized
INFO - 2023-09-28 21:25:00 --> Language Class Initialized
INFO - 2023-09-28 21:25:00 --> Language Class Initialized
INFO - 2023-09-28 21:25:00 --> Config Class Initialized
INFO - 2023-09-28 21:25:00 --> Loader Class Initialized
INFO - 2023-09-28 21:25:00 --> Helper loaded: url_helper
INFO - 2023-09-28 21:25:00 --> Helper loaded: file_helper
INFO - 2023-09-28 21:25:00 --> Helper loaded: form_helper
INFO - 2023-09-28 21:25:00 --> Helper loaded: my_helper
INFO - 2023-09-28 21:25:00 --> Database Driver Class Initialized
INFO - 2023-09-28 21:25:00 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-28 21:25:00 --> Controller Class Initialized
INFO - 2023-09-28 21:25:02 --> Config Class Initialized
INFO - 2023-09-28 21:25:02 --> Hooks Class Initialized
DEBUG - 2023-09-28 21:25:02 --> UTF-8 Support Enabled
INFO - 2023-09-28 21:25:02 --> Utf8 Class Initialized
INFO - 2023-09-28 21:25:02 --> URI Class Initialized
INFO - 2023-09-28 21:25:02 --> Router Class Initialized
INFO - 2023-09-28 21:25:02 --> Output Class Initialized
INFO - 2023-09-28 21:25:02 --> Security Class Initialized
DEBUG - 2023-09-28 21:25:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-28 21:25:02 --> Input Class Initialized
INFO - 2023-09-28 21:25:02 --> Language Class Initialized
INFO - 2023-09-28 21:25:02 --> Language Class Initialized
INFO - 2023-09-28 21:25:02 --> Config Class Initialized
INFO - 2023-09-28 21:25:02 --> Loader Class Initialized
INFO - 2023-09-28 21:25:02 --> Helper loaded: url_helper
INFO - 2023-09-28 21:25:02 --> Helper loaded: file_helper
INFO - 2023-09-28 21:25:02 --> Helper loaded: form_helper
INFO - 2023-09-28 21:25:02 --> Helper loaded: my_helper
INFO - 2023-09-28 21:25:02 --> Database Driver Class Initialized
INFO - 2023-09-28 21:25:02 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-28 21:25:02 --> Controller Class Initialized
INFO - 2023-09-28 21:25:02 --> Final output sent to browser
DEBUG - 2023-09-28 21:25:02 --> Total execution time: 0.1983
INFO - 2023-09-28 21:25:02 --> Config Class Initialized
INFO - 2023-09-28 21:25:02 --> Hooks Class Initialized
DEBUG - 2023-09-28 21:25:02 --> UTF-8 Support Enabled
INFO - 2023-09-28 21:25:02 --> Utf8 Class Initialized
INFO - 2023-09-28 21:25:02 --> URI Class Initialized
INFO - 2023-09-28 21:25:02 --> Router Class Initialized
INFO - 2023-09-28 21:25:02 --> Output Class Initialized
INFO - 2023-09-28 21:25:02 --> Security Class Initialized
DEBUG - 2023-09-28 21:25:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-28 21:25:02 --> Input Class Initialized
INFO - 2023-09-28 21:25:02 --> Language Class Initialized
INFO - 2023-09-28 21:25:02 --> Language Class Initialized
INFO - 2023-09-28 21:25:02 --> Config Class Initialized
INFO - 2023-09-28 21:25:02 --> Loader Class Initialized
INFO - 2023-09-28 21:25:02 --> Helper loaded: url_helper
INFO - 2023-09-28 21:25:02 --> Helper loaded: file_helper
INFO - 2023-09-28 21:25:02 --> Helper loaded: form_helper
INFO - 2023-09-28 21:25:02 --> Helper loaded: my_helper
INFO - 2023-09-28 21:25:02 --> Database Driver Class Initialized
INFO - 2023-09-28 21:25:02 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-28 21:25:02 --> Controller Class Initialized
INFO - 2023-09-28 21:25:03 --> Config Class Initialized
INFO - 2023-09-28 21:25:03 --> Hooks Class Initialized
DEBUG - 2023-09-28 21:25:03 --> UTF-8 Support Enabled
INFO - 2023-09-28 21:25:03 --> Utf8 Class Initialized
INFO - 2023-09-28 21:25:03 --> URI Class Initialized
INFO - 2023-09-28 21:25:04 --> Router Class Initialized
INFO - 2023-09-28 21:25:04 --> Output Class Initialized
INFO - 2023-09-28 21:25:04 --> Security Class Initialized
DEBUG - 2023-09-28 21:25:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-28 21:25:04 --> Input Class Initialized
INFO - 2023-09-28 21:25:04 --> Language Class Initialized
INFO - 2023-09-28 21:25:04 --> Language Class Initialized
INFO - 2023-09-28 21:25:04 --> Config Class Initialized
INFO - 2023-09-28 21:25:04 --> Loader Class Initialized
INFO - 2023-09-28 21:25:04 --> Helper loaded: url_helper
INFO - 2023-09-28 21:25:04 --> Helper loaded: file_helper
INFO - 2023-09-28 21:25:04 --> Helper loaded: form_helper
INFO - 2023-09-28 21:25:04 --> Helper loaded: my_helper
INFO - 2023-09-28 21:25:04 --> Database Driver Class Initialized
INFO - 2023-09-28 21:25:04 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-28 21:25:04 --> Controller Class Initialized
INFO - 2023-09-28 21:25:04 --> Final output sent to browser
DEBUG - 2023-09-28 21:25:04 --> Total execution time: 0.2456
INFO - 2023-09-28 21:25:04 --> Config Class Initialized
INFO - 2023-09-28 21:25:04 --> Hooks Class Initialized
DEBUG - 2023-09-28 21:25:04 --> UTF-8 Support Enabled
INFO - 2023-09-28 21:25:04 --> Utf8 Class Initialized
INFO - 2023-09-28 21:25:04 --> URI Class Initialized
INFO - 2023-09-28 21:25:04 --> Router Class Initialized
INFO - 2023-09-28 21:25:04 --> Output Class Initialized
INFO - 2023-09-28 21:25:04 --> Security Class Initialized
DEBUG - 2023-09-28 21:25:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-28 21:25:04 --> Input Class Initialized
INFO - 2023-09-28 21:25:04 --> Language Class Initialized
INFO - 2023-09-28 21:25:04 --> Language Class Initialized
INFO - 2023-09-28 21:25:04 --> Config Class Initialized
INFO - 2023-09-28 21:25:04 --> Loader Class Initialized
INFO - 2023-09-28 21:25:04 --> Helper loaded: url_helper
INFO - 2023-09-28 21:25:04 --> Helper loaded: file_helper
INFO - 2023-09-28 21:25:04 --> Helper loaded: form_helper
INFO - 2023-09-28 21:25:04 --> Helper loaded: my_helper
INFO - 2023-09-28 21:25:04 --> Database Driver Class Initialized
INFO - 2023-09-28 21:25:04 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-28 21:25:04 --> Controller Class Initialized
INFO - 2023-09-28 21:25:05 --> Config Class Initialized
INFO - 2023-09-28 21:25:05 --> Hooks Class Initialized
DEBUG - 2023-09-28 21:25:05 --> UTF-8 Support Enabled
INFO - 2023-09-28 21:25:05 --> Utf8 Class Initialized
INFO - 2023-09-28 21:25:05 --> URI Class Initialized
INFO - 2023-09-28 21:25:05 --> Router Class Initialized
INFO - 2023-09-28 21:25:05 --> Output Class Initialized
INFO - 2023-09-28 21:25:05 --> Security Class Initialized
DEBUG - 2023-09-28 21:25:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-28 21:25:05 --> Input Class Initialized
INFO - 2023-09-28 21:25:05 --> Language Class Initialized
INFO - 2023-09-28 21:25:05 --> Language Class Initialized
INFO - 2023-09-28 21:25:05 --> Config Class Initialized
INFO - 2023-09-28 21:25:05 --> Loader Class Initialized
INFO - 2023-09-28 21:25:05 --> Helper loaded: url_helper
INFO - 2023-09-28 21:25:05 --> Helper loaded: file_helper
INFO - 2023-09-28 21:25:05 --> Helper loaded: form_helper
INFO - 2023-09-28 21:25:05 --> Helper loaded: my_helper
INFO - 2023-09-28 21:25:05 --> Database Driver Class Initialized
INFO - 2023-09-28 21:25:05 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-28 21:25:05 --> Controller Class Initialized
INFO - 2023-09-28 21:25:05 --> Final output sent to browser
DEBUG - 2023-09-28 21:25:05 --> Total execution time: 0.0378
INFO - 2023-09-28 21:25:05 --> Config Class Initialized
INFO - 2023-09-28 21:25:05 --> Hooks Class Initialized
DEBUG - 2023-09-28 21:25:05 --> UTF-8 Support Enabled
INFO - 2023-09-28 21:25:05 --> Utf8 Class Initialized
INFO - 2023-09-28 21:25:05 --> URI Class Initialized
INFO - 2023-09-28 21:25:05 --> Router Class Initialized
INFO - 2023-09-28 21:25:05 --> Output Class Initialized
INFO - 2023-09-28 21:25:05 --> Security Class Initialized
DEBUG - 2023-09-28 21:25:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-28 21:25:05 --> Input Class Initialized
INFO - 2023-09-28 21:25:05 --> Language Class Initialized
INFO - 2023-09-28 21:25:05 --> Language Class Initialized
INFO - 2023-09-28 21:25:05 --> Config Class Initialized
INFO - 2023-09-28 21:25:05 --> Loader Class Initialized
INFO - 2023-09-28 21:25:05 --> Helper loaded: url_helper
INFO - 2023-09-28 21:25:05 --> Helper loaded: file_helper
INFO - 2023-09-28 21:25:05 --> Helper loaded: form_helper
INFO - 2023-09-28 21:25:05 --> Helper loaded: my_helper
INFO - 2023-09-28 21:25:05 --> Database Driver Class Initialized
INFO - 2023-09-28 21:25:05 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-28 21:25:05 --> Controller Class Initialized
INFO - 2023-09-28 21:25:07 --> Config Class Initialized
INFO - 2023-09-28 21:25:07 --> Hooks Class Initialized
DEBUG - 2023-09-28 21:25:07 --> UTF-8 Support Enabled
INFO - 2023-09-28 21:25:07 --> Utf8 Class Initialized
INFO - 2023-09-28 21:25:07 --> URI Class Initialized
INFO - 2023-09-28 21:25:07 --> Router Class Initialized
INFO - 2023-09-28 21:25:07 --> Output Class Initialized
INFO - 2023-09-28 21:25:07 --> Security Class Initialized
DEBUG - 2023-09-28 21:25:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-28 21:25:07 --> Input Class Initialized
INFO - 2023-09-28 21:25:07 --> Language Class Initialized
INFO - 2023-09-28 21:25:07 --> Language Class Initialized
INFO - 2023-09-28 21:25:07 --> Config Class Initialized
INFO - 2023-09-28 21:25:07 --> Loader Class Initialized
INFO - 2023-09-28 21:25:07 --> Helper loaded: url_helper
INFO - 2023-09-28 21:25:07 --> Helper loaded: file_helper
INFO - 2023-09-28 21:25:07 --> Helper loaded: form_helper
INFO - 2023-09-28 21:25:07 --> Helper loaded: my_helper
INFO - 2023-09-28 21:25:07 --> Database Driver Class Initialized
INFO - 2023-09-28 21:25:07 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-28 21:25:07 --> Controller Class Initialized
INFO - 2023-09-28 21:25:07 --> Final output sent to browser
DEBUG - 2023-09-28 21:25:07 --> Total execution time: 0.0413
INFO - 2023-09-28 21:25:07 --> Config Class Initialized
INFO - 2023-09-28 21:25:07 --> Hooks Class Initialized
DEBUG - 2023-09-28 21:25:07 --> UTF-8 Support Enabled
INFO - 2023-09-28 21:25:07 --> Utf8 Class Initialized
INFO - 2023-09-28 21:25:07 --> URI Class Initialized
INFO - 2023-09-28 21:25:07 --> Router Class Initialized
INFO - 2023-09-28 21:25:07 --> Output Class Initialized
INFO - 2023-09-28 21:25:07 --> Security Class Initialized
DEBUG - 2023-09-28 21:25:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-28 21:25:07 --> Input Class Initialized
INFO - 2023-09-28 21:25:07 --> Language Class Initialized
INFO - 2023-09-28 21:25:07 --> Language Class Initialized
INFO - 2023-09-28 21:25:07 --> Config Class Initialized
INFO - 2023-09-28 21:25:07 --> Loader Class Initialized
INFO - 2023-09-28 21:25:07 --> Helper loaded: url_helper
INFO - 2023-09-28 21:25:07 --> Helper loaded: file_helper
INFO - 2023-09-28 21:25:07 --> Helper loaded: form_helper
INFO - 2023-09-28 21:25:07 --> Helper loaded: my_helper
INFO - 2023-09-28 21:25:07 --> Database Driver Class Initialized
INFO - 2023-09-28 21:25:07 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-28 21:25:07 --> Controller Class Initialized
INFO - 2023-09-28 21:25:08 --> Config Class Initialized
INFO - 2023-09-28 21:25:08 --> Hooks Class Initialized
DEBUG - 2023-09-28 21:25:08 --> UTF-8 Support Enabled
INFO - 2023-09-28 21:25:08 --> Utf8 Class Initialized
INFO - 2023-09-28 21:25:08 --> URI Class Initialized
INFO - 2023-09-28 21:25:08 --> Router Class Initialized
INFO - 2023-09-28 21:25:08 --> Output Class Initialized
INFO - 2023-09-28 21:25:08 --> Security Class Initialized
DEBUG - 2023-09-28 21:25:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-28 21:25:08 --> Input Class Initialized
INFO - 2023-09-28 21:25:08 --> Language Class Initialized
INFO - 2023-09-28 21:25:08 --> Language Class Initialized
INFO - 2023-09-28 21:25:08 --> Config Class Initialized
INFO - 2023-09-28 21:25:08 --> Loader Class Initialized
INFO - 2023-09-28 21:25:08 --> Helper loaded: url_helper
INFO - 2023-09-28 21:25:08 --> Helper loaded: file_helper
INFO - 2023-09-28 21:25:08 --> Helper loaded: form_helper
INFO - 2023-09-28 21:25:08 --> Helper loaded: my_helper
INFO - 2023-09-28 21:25:08 --> Database Driver Class Initialized
INFO - 2023-09-28 21:25:08 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-28 21:25:08 --> Controller Class Initialized
INFO - 2023-09-28 21:25:08 --> Final output sent to browser
DEBUG - 2023-09-28 21:25:08 --> Total execution time: 0.1305
INFO - 2023-09-28 21:25:08 --> Config Class Initialized
INFO - 2023-09-28 21:25:08 --> Hooks Class Initialized
DEBUG - 2023-09-28 21:25:08 --> UTF-8 Support Enabled
INFO - 2023-09-28 21:25:08 --> Utf8 Class Initialized
INFO - 2023-09-28 21:25:08 --> URI Class Initialized
INFO - 2023-09-28 21:25:08 --> Router Class Initialized
INFO - 2023-09-28 21:25:08 --> Output Class Initialized
INFO - 2023-09-28 21:25:08 --> Security Class Initialized
DEBUG - 2023-09-28 21:25:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-28 21:25:08 --> Input Class Initialized
INFO - 2023-09-28 21:25:08 --> Language Class Initialized
INFO - 2023-09-28 21:25:08 --> Language Class Initialized
INFO - 2023-09-28 21:25:08 --> Config Class Initialized
INFO - 2023-09-28 21:25:08 --> Loader Class Initialized
INFO - 2023-09-28 21:25:08 --> Helper loaded: url_helper
INFO - 2023-09-28 21:25:08 --> Helper loaded: file_helper
INFO - 2023-09-28 21:25:08 --> Helper loaded: form_helper
INFO - 2023-09-28 21:25:08 --> Helper loaded: my_helper
INFO - 2023-09-28 21:25:08 --> Database Driver Class Initialized
INFO - 2023-09-28 21:25:08 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-28 21:25:08 --> Controller Class Initialized
INFO - 2023-09-28 21:25:10 --> Config Class Initialized
INFO - 2023-09-28 21:25:10 --> Hooks Class Initialized
DEBUG - 2023-09-28 21:25:10 --> UTF-8 Support Enabled
INFO - 2023-09-28 21:25:10 --> Utf8 Class Initialized
INFO - 2023-09-28 21:25:10 --> URI Class Initialized
INFO - 2023-09-28 21:25:10 --> Router Class Initialized
INFO - 2023-09-28 21:25:10 --> Output Class Initialized
INFO - 2023-09-28 21:25:10 --> Security Class Initialized
DEBUG - 2023-09-28 21:25:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-28 21:25:10 --> Input Class Initialized
INFO - 2023-09-28 21:25:10 --> Language Class Initialized
INFO - 2023-09-28 21:25:10 --> Language Class Initialized
INFO - 2023-09-28 21:25:10 --> Config Class Initialized
INFO - 2023-09-28 21:25:10 --> Loader Class Initialized
INFO - 2023-09-28 21:25:10 --> Helper loaded: url_helper
INFO - 2023-09-28 21:25:10 --> Helper loaded: file_helper
INFO - 2023-09-28 21:25:10 --> Helper loaded: form_helper
INFO - 2023-09-28 21:25:10 --> Helper loaded: my_helper
INFO - 2023-09-28 21:25:10 --> Database Driver Class Initialized
INFO - 2023-09-28 21:25:10 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-28 21:25:10 --> Controller Class Initialized
INFO - 2023-09-28 21:25:10 --> Final output sent to browser
DEBUG - 2023-09-28 21:25:10 --> Total execution time: 0.0401
INFO - 2023-09-28 21:25:10 --> Config Class Initialized
INFO - 2023-09-28 21:25:10 --> Hooks Class Initialized
DEBUG - 2023-09-28 21:25:10 --> UTF-8 Support Enabled
INFO - 2023-09-28 21:25:10 --> Utf8 Class Initialized
INFO - 2023-09-28 21:25:10 --> URI Class Initialized
INFO - 2023-09-28 21:25:10 --> Router Class Initialized
INFO - 2023-09-28 21:25:10 --> Output Class Initialized
INFO - 2023-09-28 21:25:10 --> Security Class Initialized
DEBUG - 2023-09-28 21:25:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-28 21:25:10 --> Input Class Initialized
INFO - 2023-09-28 21:25:10 --> Language Class Initialized
INFO - 2023-09-28 21:25:10 --> Language Class Initialized
INFO - 2023-09-28 21:25:10 --> Config Class Initialized
INFO - 2023-09-28 21:25:10 --> Loader Class Initialized
INFO - 2023-09-28 21:25:10 --> Helper loaded: url_helper
INFO - 2023-09-28 21:25:10 --> Helper loaded: file_helper
INFO - 2023-09-28 21:25:10 --> Helper loaded: form_helper
INFO - 2023-09-28 21:25:10 --> Helper loaded: my_helper
INFO - 2023-09-28 21:25:10 --> Database Driver Class Initialized
INFO - 2023-09-28 21:25:10 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-28 21:25:10 --> Controller Class Initialized
INFO - 2023-09-28 21:25:11 --> Config Class Initialized
INFO - 2023-09-28 21:25:11 --> Hooks Class Initialized
DEBUG - 2023-09-28 21:25:11 --> UTF-8 Support Enabled
INFO - 2023-09-28 21:25:11 --> Utf8 Class Initialized
INFO - 2023-09-28 21:25:11 --> URI Class Initialized
INFO - 2023-09-28 21:25:11 --> Router Class Initialized
INFO - 2023-09-28 21:25:11 --> Output Class Initialized
INFO - 2023-09-28 21:25:11 --> Security Class Initialized
DEBUG - 2023-09-28 21:25:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-28 21:25:11 --> Input Class Initialized
INFO - 2023-09-28 21:25:11 --> Language Class Initialized
INFO - 2023-09-28 21:25:11 --> Language Class Initialized
INFO - 2023-09-28 21:25:11 --> Config Class Initialized
INFO - 2023-09-28 21:25:11 --> Loader Class Initialized
INFO - 2023-09-28 21:25:11 --> Helper loaded: url_helper
INFO - 2023-09-28 21:25:11 --> Helper loaded: file_helper
INFO - 2023-09-28 21:25:11 --> Helper loaded: form_helper
INFO - 2023-09-28 21:25:11 --> Helper loaded: my_helper
INFO - 2023-09-28 21:25:11 --> Database Driver Class Initialized
INFO - 2023-09-28 21:25:11 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-28 21:25:11 --> Controller Class Initialized
INFO - 2023-09-28 21:25:11 --> Final output sent to browser
DEBUG - 2023-09-28 21:25:11 --> Total execution time: 0.1385
INFO - 2023-09-28 21:25:12 --> Config Class Initialized
INFO - 2023-09-28 21:25:12 --> Hooks Class Initialized
DEBUG - 2023-09-28 21:25:12 --> UTF-8 Support Enabled
INFO - 2023-09-28 21:25:12 --> Utf8 Class Initialized
INFO - 2023-09-28 21:25:12 --> URI Class Initialized
INFO - 2023-09-28 21:25:12 --> Router Class Initialized
INFO - 2023-09-28 21:25:12 --> Output Class Initialized
INFO - 2023-09-28 21:25:12 --> Security Class Initialized
DEBUG - 2023-09-28 21:25:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-28 21:25:12 --> Input Class Initialized
INFO - 2023-09-28 21:25:12 --> Language Class Initialized
INFO - 2023-09-28 21:25:12 --> Language Class Initialized
INFO - 2023-09-28 21:25:12 --> Config Class Initialized
INFO - 2023-09-28 21:25:12 --> Loader Class Initialized
INFO - 2023-09-28 21:25:12 --> Helper loaded: url_helper
INFO - 2023-09-28 21:25:12 --> Helper loaded: file_helper
INFO - 2023-09-28 21:25:12 --> Helper loaded: form_helper
INFO - 2023-09-28 21:25:12 --> Helper loaded: my_helper
INFO - 2023-09-28 21:25:12 --> Database Driver Class Initialized
INFO - 2023-09-28 21:25:12 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-28 21:25:12 --> Controller Class Initialized
INFO - 2023-09-28 21:25:13 --> Config Class Initialized
INFO - 2023-09-28 21:25:13 --> Hooks Class Initialized
DEBUG - 2023-09-28 21:25:13 --> UTF-8 Support Enabled
INFO - 2023-09-28 21:25:13 --> Utf8 Class Initialized
INFO - 2023-09-28 21:25:13 --> URI Class Initialized
INFO - 2023-09-28 21:25:13 --> Router Class Initialized
INFO - 2023-09-28 21:25:13 --> Output Class Initialized
INFO - 2023-09-28 21:25:13 --> Security Class Initialized
DEBUG - 2023-09-28 21:25:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-28 21:25:13 --> Input Class Initialized
INFO - 2023-09-28 21:25:13 --> Language Class Initialized
INFO - 2023-09-28 21:25:13 --> Language Class Initialized
INFO - 2023-09-28 21:25:13 --> Config Class Initialized
INFO - 2023-09-28 21:25:13 --> Loader Class Initialized
INFO - 2023-09-28 21:25:13 --> Helper loaded: url_helper
INFO - 2023-09-28 21:25:13 --> Helper loaded: file_helper
INFO - 2023-09-28 21:25:13 --> Helper loaded: form_helper
INFO - 2023-09-28 21:25:13 --> Helper loaded: my_helper
INFO - 2023-09-28 21:25:13 --> Database Driver Class Initialized
INFO - 2023-09-28 21:25:13 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-28 21:25:13 --> Controller Class Initialized
INFO - 2023-09-28 21:25:13 --> Final output sent to browser
DEBUG - 2023-09-28 21:25:13 --> Total execution time: 0.0403
INFO - 2023-09-28 21:25:14 --> Config Class Initialized
INFO - 2023-09-28 21:25:14 --> Hooks Class Initialized
DEBUG - 2023-09-28 21:25:14 --> UTF-8 Support Enabled
INFO - 2023-09-28 21:25:14 --> Utf8 Class Initialized
INFO - 2023-09-28 21:25:14 --> URI Class Initialized
INFO - 2023-09-28 21:25:14 --> Router Class Initialized
INFO - 2023-09-28 21:25:14 --> Output Class Initialized
INFO - 2023-09-28 21:25:14 --> Security Class Initialized
DEBUG - 2023-09-28 21:25:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-28 21:25:14 --> Input Class Initialized
INFO - 2023-09-28 21:25:14 --> Language Class Initialized
INFO - 2023-09-28 21:25:14 --> Language Class Initialized
INFO - 2023-09-28 21:25:14 --> Config Class Initialized
INFO - 2023-09-28 21:25:14 --> Loader Class Initialized
INFO - 2023-09-28 21:25:14 --> Helper loaded: url_helper
INFO - 2023-09-28 21:25:14 --> Helper loaded: file_helper
INFO - 2023-09-28 21:25:14 --> Helper loaded: form_helper
INFO - 2023-09-28 21:25:14 --> Helper loaded: my_helper
INFO - 2023-09-28 21:25:14 --> Database Driver Class Initialized
INFO - 2023-09-28 21:25:14 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-28 21:25:14 --> Controller Class Initialized
INFO - 2023-09-28 21:25:15 --> Config Class Initialized
INFO - 2023-09-28 21:25:15 --> Hooks Class Initialized
DEBUG - 2023-09-28 21:25:15 --> UTF-8 Support Enabled
INFO - 2023-09-28 21:25:15 --> Utf8 Class Initialized
INFO - 2023-09-28 21:25:15 --> URI Class Initialized
INFO - 2023-09-28 21:25:15 --> Router Class Initialized
INFO - 2023-09-28 21:25:15 --> Output Class Initialized
INFO - 2023-09-28 21:25:15 --> Security Class Initialized
DEBUG - 2023-09-28 21:25:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-28 21:25:15 --> Input Class Initialized
INFO - 2023-09-28 21:25:15 --> Language Class Initialized
INFO - 2023-09-28 21:25:15 --> Language Class Initialized
INFO - 2023-09-28 21:25:15 --> Config Class Initialized
INFO - 2023-09-28 21:25:15 --> Loader Class Initialized
INFO - 2023-09-28 21:25:15 --> Helper loaded: url_helper
INFO - 2023-09-28 21:25:15 --> Helper loaded: file_helper
INFO - 2023-09-28 21:25:15 --> Helper loaded: form_helper
INFO - 2023-09-28 21:25:15 --> Helper loaded: my_helper
INFO - 2023-09-28 21:25:15 --> Database Driver Class Initialized
INFO - 2023-09-28 21:25:15 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-28 21:25:15 --> Controller Class Initialized
INFO - 2023-09-28 21:25:15 --> Final output sent to browser
DEBUG - 2023-09-28 21:25:15 --> Total execution time: 0.1165
INFO - 2023-09-28 21:25:15 --> Config Class Initialized
INFO - 2023-09-28 21:25:15 --> Hooks Class Initialized
DEBUG - 2023-09-28 21:25:15 --> UTF-8 Support Enabled
INFO - 2023-09-28 21:25:15 --> Utf8 Class Initialized
INFO - 2023-09-28 21:25:15 --> URI Class Initialized
INFO - 2023-09-28 21:25:15 --> Router Class Initialized
INFO - 2023-09-28 21:25:15 --> Output Class Initialized
INFO - 2023-09-28 21:25:15 --> Security Class Initialized
DEBUG - 2023-09-28 21:25:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-28 21:25:15 --> Input Class Initialized
INFO - 2023-09-28 21:25:15 --> Language Class Initialized
INFO - 2023-09-28 21:25:15 --> Language Class Initialized
INFO - 2023-09-28 21:25:15 --> Config Class Initialized
INFO - 2023-09-28 21:25:15 --> Loader Class Initialized
INFO - 2023-09-28 21:25:15 --> Helper loaded: url_helper
INFO - 2023-09-28 21:25:15 --> Helper loaded: file_helper
INFO - 2023-09-28 21:25:15 --> Helper loaded: form_helper
INFO - 2023-09-28 21:25:15 --> Helper loaded: my_helper
INFO - 2023-09-28 21:25:15 --> Database Driver Class Initialized
INFO - 2023-09-28 21:25:15 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-28 21:25:15 --> Controller Class Initialized
INFO - 2023-09-28 21:25:16 --> Config Class Initialized
INFO - 2023-09-28 21:25:16 --> Hooks Class Initialized
DEBUG - 2023-09-28 21:25:16 --> UTF-8 Support Enabled
INFO - 2023-09-28 21:25:16 --> Utf8 Class Initialized
INFO - 2023-09-28 21:25:16 --> URI Class Initialized
INFO - 2023-09-28 21:25:16 --> Router Class Initialized
INFO - 2023-09-28 21:25:16 --> Output Class Initialized
INFO - 2023-09-28 21:25:16 --> Security Class Initialized
DEBUG - 2023-09-28 21:25:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-28 21:25:16 --> Input Class Initialized
INFO - 2023-09-28 21:25:16 --> Language Class Initialized
INFO - 2023-09-28 21:25:16 --> Language Class Initialized
INFO - 2023-09-28 21:25:16 --> Config Class Initialized
INFO - 2023-09-28 21:25:16 --> Loader Class Initialized
INFO - 2023-09-28 21:25:16 --> Helper loaded: url_helper
INFO - 2023-09-28 21:25:16 --> Helper loaded: file_helper
INFO - 2023-09-28 21:25:16 --> Helper loaded: form_helper
INFO - 2023-09-28 21:25:16 --> Helper loaded: my_helper
INFO - 2023-09-28 21:25:16 --> Database Driver Class Initialized
INFO - 2023-09-28 21:25:16 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-28 21:25:16 --> Controller Class Initialized
INFO - 2023-09-28 21:25:16 --> Final output sent to browser
DEBUG - 2023-09-28 21:25:16 --> Total execution time: 0.0426
INFO - 2023-09-28 21:25:16 --> Config Class Initialized
INFO - 2023-09-28 21:25:16 --> Hooks Class Initialized
DEBUG - 2023-09-28 21:25:16 --> UTF-8 Support Enabled
INFO - 2023-09-28 21:25:16 --> Utf8 Class Initialized
INFO - 2023-09-28 21:25:16 --> URI Class Initialized
INFO - 2023-09-28 21:25:16 --> Router Class Initialized
INFO - 2023-09-28 21:25:16 --> Output Class Initialized
INFO - 2023-09-28 21:25:16 --> Security Class Initialized
DEBUG - 2023-09-28 21:25:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-28 21:25:16 --> Input Class Initialized
INFO - 2023-09-28 21:25:16 --> Language Class Initialized
INFO - 2023-09-28 21:25:16 --> Language Class Initialized
INFO - 2023-09-28 21:25:16 --> Config Class Initialized
INFO - 2023-09-28 21:25:16 --> Loader Class Initialized
INFO - 2023-09-28 21:25:16 --> Helper loaded: url_helper
INFO - 2023-09-28 21:25:16 --> Helper loaded: file_helper
INFO - 2023-09-28 21:25:16 --> Helper loaded: form_helper
INFO - 2023-09-28 21:25:16 --> Helper loaded: my_helper
INFO - 2023-09-28 21:25:16 --> Database Driver Class Initialized
INFO - 2023-09-28 21:25:16 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-28 21:25:16 --> Controller Class Initialized
INFO - 2023-09-28 21:25:17 --> Config Class Initialized
INFO - 2023-09-28 21:25:17 --> Hooks Class Initialized
DEBUG - 2023-09-28 21:25:17 --> UTF-8 Support Enabled
INFO - 2023-09-28 21:25:17 --> Utf8 Class Initialized
INFO - 2023-09-28 21:25:17 --> URI Class Initialized
INFO - 2023-09-28 21:25:17 --> Router Class Initialized
INFO - 2023-09-28 21:25:17 --> Output Class Initialized
INFO - 2023-09-28 21:25:17 --> Security Class Initialized
DEBUG - 2023-09-28 21:25:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-28 21:25:17 --> Input Class Initialized
INFO - 2023-09-28 21:25:17 --> Language Class Initialized
INFO - 2023-09-28 21:25:17 --> Language Class Initialized
INFO - 2023-09-28 21:25:17 --> Config Class Initialized
INFO - 2023-09-28 21:25:17 --> Loader Class Initialized
INFO - 2023-09-28 21:25:17 --> Helper loaded: url_helper
INFO - 2023-09-28 21:25:17 --> Helper loaded: file_helper
INFO - 2023-09-28 21:25:17 --> Helper loaded: form_helper
INFO - 2023-09-28 21:25:17 --> Helper loaded: my_helper
INFO - 2023-09-28 21:25:17 --> Database Driver Class Initialized
INFO - 2023-09-28 21:25:17 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-28 21:25:17 --> Controller Class Initialized
INFO - 2023-09-28 21:25:17 --> Final output sent to browser
DEBUG - 2023-09-28 21:25:17 --> Total execution time: 0.0470
INFO - 2023-09-28 21:25:17 --> Config Class Initialized
INFO - 2023-09-28 21:25:17 --> Hooks Class Initialized
DEBUG - 2023-09-28 21:25:17 --> UTF-8 Support Enabled
INFO - 2023-09-28 21:25:17 --> Utf8 Class Initialized
INFO - 2023-09-28 21:25:17 --> URI Class Initialized
INFO - 2023-09-28 21:25:17 --> Router Class Initialized
INFO - 2023-09-28 21:25:17 --> Output Class Initialized
INFO - 2023-09-28 21:25:17 --> Security Class Initialized
DEBUG - 2023-09-28 21:25:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-28 21:25:17 --> Input Class Initialized
INFO - 2023-09-28 21:25:17 --> Language Class Initialized
INFO - 2023-09-28 21:25:17 --> Language Class Initialized
INFO - 2023-09-28 21:25:17 --> Config Class Initialized
INFO - 2023-09-28 21:25:17 --> Loader Class Initialized
INFO - 2023-09-28 21:25:17 --> Helper loaded: url_helper
INFO - 2023-09-28 21:25:17 --> Helper loaded: file_helper
INFO - 2023-09-28 21:25:17 --> Helper loaded: form_helper
INFO - 2023-09-28 21:25:17 --> Helper loaded: my_helper
INFO - 2023-09-28 21:25:17 --> Database Driver Class Initialized
INFO - 2023-09-28 21:25:17 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-28 21:25:17 --> Controller Class Initialized
INFO - 2023-09-28 21:25:19 --> Config Class Initialized
INFO - 2023-09-28 21:25:19 --> Hooks Class Initialized
DEBUG - 2023-09-28 21:25:19 --> UTF-8 Support Enabled
INFO - 2023-09-28 21:25:19 --> Utf8 Class Initialized
INFO - 2023-09-28 21:25:19 --> URI Class Initialized
INFO - 2023-09-28 21:25:19 --> Router Class Initialized
INFO - 2023-09-28 21:25:19 --> Output Class Initialized
INFO - 2023-09-28 21:25:19 --> Security Class Initialized
DEBUG - 2023-09-28 21:25:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-28 21:25:19 --> Input Class Initialized
INFO - 2023-09-28 21:25:19 --> Language Class Initialized
INFO - 2023-09-28 21:25:19 --> Language Class Initialized
INFO - 2023-09-28 21:25:19 --> Config Class Initialized
INFO - 2023-09-28 21:25:19 --> Loader Class Initialized
INFO - 2023-09-28 21:25:19 --> Helper loaded: url_helper
INFO - 2023-09-28 21:25:19 --> Helper loaded: file_helper
INFO - 2023-09-28 21:25:19 --> Helper loaded: form_helper
INFO - 2023-09-28 21:25:19 --> Helper loaded: my_helper
INFO - 2023-09-28 21:25:19 --> Database Driver Class Initialized
INFO - 2023-09-28 21:25:19 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-28 21:25:19 --> Controller Class Initialized
INFO - 2023-09-28 21:25:19 --> Final output sent to browser
DEBUG - 2023-09-28 21:25:19 --> Total execution time: 0.0773
INFO - 2023-09-28 21:25:19 --> Config Class Initialized
INFO - 2023-09-28 21:25:19 --> Hooks Class Initialized
DEBUG - 2023-09-28 21:25:19 --> UTF-8 Support Enabled
INFO - 2023-09-28 21:25:19 --> Utf8 Class Initialized
INFO - 2023-09-28 21:25:19 --> URI Class Initialized
INFO - 2023-09-28 21:25:19 --> Router Class Initialized
INFO - 2023-09-28 21:25:19 --> Output Class Initialized
INFO - 2023-09-28 21:25:19 --> Security Class Initialized
DEBUG - 2023-09-28 21:25:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-28 21:25:19 --> Input Class Initialized
INFO - 2023-09-28 21:25:19 --> Language Class Initialized
INFO - 2023-09-28 21:25:19 --> Language Class Initialized
INFO - 2023-09-28 21:25:19 --> Config Class Initialized
INFO - 2023-09-28 21:25:19 --> Loader Class Initialized
INFO - 2023-09-28 21:25:19 --> Helper loaded: url_helper
INFO - 2023-09-28 21:25:19 --> Helper loaded: file_helper
INFO - 2023-09-28 21:25:19 --> Helper loaded: form_helper
INFO - 2023-09-28 21:25:19 --> Helper loaded: my_helper
INFO - 2023-09-28 21:25:19 --> Database Driver Class Initialized
INFO - 2023-09-28 21:25:19 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-28 21:25:19 --> Controller Class Initialized
INFO - 2023-09-28 21:25:20 --> Config Class Initialized
INFO - 2023-09-28 21:25:20 --> Hooks Class Initialized
DEBUG - 2023-09-28 21:25:20 --> UTF-8 Support Enabled
INFO - 2023-09-28 21:25:20 --> Utf8 Class Initialized
INFO - 2023-09-28 21:25:20 --> URI Class Initialized
INFO - 2023-09-28 21:25:20 --> Router Class Initialized
INFO - 2023-09-28 21:25:20 --> Output Class Initialized
INFO - 2023-09-28 21:25:20 --> Security Class Initialized
DEBUG - 2023-09-28 21:25:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-28 21:25:20 --> Input Class Initialized
INFO - 2023-09-28 21:25:20 --> Language Class Initialized
INFO - 2023-09-28 21:25:20 --> Language Class Initialized
INFO - 2023-09-28 21:25:20 --> Config Class Initialized
INFO - 2023-09-28 21:25:20 --> Loader Class Initialized
INFO - 2023-09-28 21:25:20 --> Helper loaded: url_helper
INFO - 2023-09-28 21:25:20 --> Helper loaded: file_helper
INFO - 2023-09-28 21:25:20 --> Helper loaded: form_helper
INFO - 2023-09-28 21:25:20 --> Helper loaded: my_helper
INFO - 2023-09-28 21:25:20 --> Database Driver Class Initialized
INFO - 2023-09-28 21:25:20 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-28 21:25:20 --> Controller Class Initialized
INFO - 2023-09-28 21:25:20 --> Final output sent to browser
DEBUG - 2023-09-28 21:25:20 --> Total execution time: 0.0952
INFO - 2023-09-28 21:25:20 --> Config Class Initialized
INFO - 2023-09-28 21:25:20 --> Hooks Class Initialized
DEBUG - 2023-09-28 21:25:20 --> UTF-8 Support Enabled
INFO - 2023-09-28 21:25:20 --> Utf8 Class Initialized
INFO - 2023-09-28 21:25:20 --> URI Class Initialized
INFO - 2023-09-28 21:25:20 --> Router Class Initialized
INFO - 2023-09-28 21:25:20 --> Output Class Initialized
INFO - 2023-09-28 21:25:20 --> Security Class Initialized
DEBUG - 2023-09-28 21:25:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-28 21:25:20 --> Input Class Initialized
INFO - 2023-09-28 21:25:20 --> Language Class Initialized
INFO - 2023-09-28 21:25:20 --> Language Class Initialized
INFO - 2023-09-28 21:25:20 --> Config Class Initialized
INFO - 2023-09-28 21:25:20 --> Loader Class Initialized
INFO - 2023-09-28 21:25:20 --> Helper loaded: url_helper
INFO - 2023-09-28 21:25:20 --> Helper loaded: file_helper
INFO - 2023-09-28 21:25:20 --> Helper loaded: form_helper
INFO - 2023-09-28 21:25:20 --> Helper loaded: my_helper
INFO - 2023-09-28 21:25:20 --> Database Driver Class Initialized
INFO - 2023-09-28 21:25:20 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-28 21:25:20 --> Controller Class Initialized
INFO - 2023-09-28 21:25:21 --> Config Class Initialized
INFO - 2023-09-28 21:25:21 --> Hooks Class Initialized
DEBUG - 2023-09-28 21:25:21 --> UTF-8 Support Enabled
INFO - 2023-09-28 21:25:21 --> Utf8 Class Initialized
INFO - 2023-09-28 21:25:21 --> URI Class Initialized
INFO - 2023-09-28 21:25:21 --> Router Class Initialized
INFO - 2023-09-28 21:25:21 --> Output Class Initialized
INFO - 2023-09-28 21:25:21 --> Security Class Initialized
DEBUG - 2023-09-28 21:25:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-28 21:25:21 --> Input Class Initialized
INFO - 2023-09-28 21:25:21 --> Language Class Initialized
INFO - 2023-09-28 21:25:21 --> Language Class Initialized
INFO - 2023-09-28 21:25:21 --> Config Class Initialized
INFO - 2023-09-28 21:25:21 --> Loader Class Initialized
INFO - 2023-09-28 21:25:21 --> Helper loaded: url_helper
INFO - 2023-09-28 21:25:21 --> Helper loaded: file_helper
INFO - 2023-09-28 21:25:21 --> Helper loaded: form_helper
INFO - 2023-09-28 21:25:21 --> Helper loaded: my_helper
INFO - 2023-09-28 21:25:21 --> Database Driver Class Initialized
INFO - 2023-09-28 21:25:21 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-28 21:25:21 --> Controller Class Initialized
INFO - 2023-09-28 21:25:21 --> Final output sent to browser
DEBUG - 2023-09-28 21:25:21 --> Total execution time: 0.0922
INFO - 2023-09-28 21:25:22 --> Config Class Initialized
INFO - 2023-09-28 21:25:22 --> Hooks Class Initialized
DEBUG - 2023-09-28 21:25:22 --> UTF-8 Support Enabled
INFO - 2023-09-28 21:25:22 --> Utf8 Class Initialized
INFO - 2023-09-28 21:25:22 --> URI Class Initialized
INFO - 2023-09-28 21:25:22 --> Router Class Initialized
INFO - 2023-09-28 21:25:22 --> Output Class Initialized
INFO - 2023-09-28 21:25:22 --> Security Class Initialized
DEBUG - 2023-09-28 21:25:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-28 21:25:22 --> Input Class Initialized
INFO - 2023-09-28 21:25:22 --> Language Class Initialized
INFO - 2023-09-28 21:25:22 --> Language Class Initialized
INFO - 2023-09-28 21:25:22 --> Config Class Initialized
INFO - 2023-09-28 21:25:22 --> Loader Class Initialized
INFO - 2023-09-28 21:25:22 --> Helper loaded: url_helper
INFO - 2023-09-28 21:25:22 --> Helper loaded: file_helper
INFO - 2023-09-28 21:25:22 --> Helper loaded: form_helper
INFO - 2023-09-28 21:25:22 --> Helper loaded: my_helper
INFO - 2023-09-28 21:25:22 --> Database Driver Class Initialized
INFO - 2023-09-28 21:25:22 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-28 21:25:22 --> Controller Class Initialized
INFO - 2023-09-28 21:25:22 --> Config Class Initialized
INFO - 2023-09-28 21:25:22 --> Hooks Class Initialized
DEBUG - 2023-09-28 21:25:22 --> UTF-8 Support Enabled
INFO - 2023-09-28 21:25:22 --> Utf8 Class Initialized
INFO - 2023-09-28 21:25:22 --> URI Class Initialized
INFO - 2023-09-28 21:25:22 --> Router Class Initialized
INFO - 2023-09-28 21:25:22 --> Output Class Initialized
INFO - 2023-09-28 21:25:22 --> Security Class Initialized
DEBUG - 2023-09-28 21:25:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-28 21:25:22 --> Input Class Initialized
INFO - 2023-09-28 21:25:22 --> Language Class Initialized
INFO - 2023-09-28 21:25:22 --> Language Class Initialized
INFO - 2023-09-28 21:25:22 --> Config Class Initialized
INFO - 2023-09-28 21:25:22 --> Loader Class Initialized
INFO - 2023-09-28 21:25:22 --> Helper loaded: url_helper
INFO - 2023-09-28 21:25:22 --> Helper loaded: file_helper
INFO - 2023-09-28 21:25:22 --> Helper loaded: form_helper
INFO - 2023-09-28 21:25:22 --> Helper loaded: my_helper
INFO - 2023-09-28 21:25:22 --> Database Driver Class Initialized
INFO - 2023-09-28 21:25:22 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-28 21:25:22 --> Controller Class Initialized
INFO - 2023-09-28 21:25:22 --> Final output sent to browser
DEBUG - 2023-09-28 21:25:22 --> Total execution time: 0.0436
INFO - 2023-09-28 21:25:23 --> Config Class Initialized
INFO - 2023-09-28 21:25:23 --> Hooks Class Initialized
DEBUG - 2023-09-28 21:25:23 --> UTF-8 Support Enabled
INFO - 2023-09-28 21:25:23 --> Utf8 Class Initialized
INFO - 2023-09-28 21:25:23 --> URI Class Initialized
INFO - 2023-09-28 21:25:23 --> Router Class Initialized
INFO - 2023-09-28 21:25:23 --> Output Class Initialized
INFO - 2023-09-28 21:25:23 --> Security Class Initialized
DEBUG - 2023-09-28 21:25:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-28 21:25:23 --> Input Class Initialized
INFO - 2023-09-28 21:25:23 --> Language Class Initialized
INFO - 2023-09-28 21:25:23 --> Language Class Initialized
INFO - 2023-09-28 21:25:23 --> Config Class Initialized
INFO - 2023-09-28 21:25:23 --> Loader Class Initialized
INFO - 2023-09-28 21:25:23 --> Helper loaded: url_helper
INFO - 2023-09-28 21:25:23 --> Helper loaded: file_helper
INFO - 2023-09-28 21:25:23 --> Helper loaded: form_helper
INFO - 2023-09-28 21:25:23 --> Helper loaded: my_helper
INFO - 2023-09-28 21:25:23 --> Database Driver Class Initialized
INFO - 2023-09-28 21:25:23 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-28 21:25:23 --> Controller Class Initialized
INFO - 2023-09-28 21:25:24 --> Config Class Initialized
INFO - 2023-09-28 21:25:24 --> Hooks Class Initialized
DEBUG - 2023-09-28 21:25:24 --> UTF-8 Support Enabled
INFO - 2023-09-28 21:25:24 --> Utf8 Class Initialized
INFO - 2023-09-28 21:25:24 --> URI Class Initialized
INFO - 2023-09-28 21:25:24 --> Router Class Initialized
INFO - 2023-09-28 21:25:24 --> Output Class Initialized
INFO - 2023-09-28 21:25:24 --> Security Class Initialized
DEBUG - 2023-09-28 21:25:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-28 21:25:24 --> Input Class Initialized
INFO - 2023-09-28 21:25:24 --> Language Class Initialized
INFO - 2023-09-28 21:25:24 --> Language Class Initialized
INFO - 2023-09-28 21:25:24 --> Config Class Initialized
INFO - 2023-09-28 21:25:24 --> Loader Class Initialized
INFO - 2023-09-28 21:25:24 --> Helper loaded: url_helper
INFO - 2023-09-28 21:25:24 --> Helper loaded: file_helper
INFO - 2023-09-28 21:25:24 --> Helper loaded: form_helper
INFO - 2023-09-28 21:25:24 --> Helper loaded: my_helper
INFO - 2023-09-28 21:25:24 --> Database Driver Class Initialized
INFO - 2023-09-28 21:25:24 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-28 21:25:24 --> Controller Class Initialized
INFO - 2023-09-28 21:25:25 --> Final output sent to browser
DEBUG - 2023-09-28 21:25:25 --> Total execution time: 0.1627
INFO - 2023-09-28 21:25:25 --> Config Class Initialized
INFO - 2023-09-28 21:25:25 --> Hooks Class Initialized
DEBUG - 2023-09-28 21:25:25 --> UTF-8 Support Enabled
INFO - 2023-09-28 21:25:25 --> Utf8 Class Initialized
INFO - 2023-09-28 21:25:25 --> URI Class Initialized
INFO - 2023-09-28 21:25:25 --> Router Class Initialized
INFO - 2023-09-28 21:25:25 --> Output Class Initialized
INFO - 2023-09-28 21:25:25 --> Security Class Initialized
DEBUG - 2023-09-28 21:25:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-28 21:25:25 --> Input Class Initialized
INFO - 2023-09-28 21:25:25 --> Language Class Initialized
INFO - 2023-09-28 21:25:25 --> Language Class Initialized
INFO - 2023-09-28 21:25:25 --> Config Class Initialized
INFO - 2023-09-28 21:25:25 --> Loader Class Initialized
INFO - 2023-09-28 21:25:25 --> Helper loaded: url_helper
INFO - 2023-09-28 21:25:25 --> Helper loaded: file_helper
INFO - 2023-09-28 21:25:25 --> Helper loaded: form_helper
INFO - 2023-09-28 21:25:25 --> Helper loaded: my_helper
INFO - 2023-09-28 21:25:25 --> Database Driver Class Initialized
INFO - 2023-09-28 21:25:25 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-28 21:25:25 --> Controller Class Initialized
INFO - 2023-09-28 21:25:26 --> Config Class Initialized
INFO - 2023-09-28 21:25:26 --> Hooks Class Initialized
DEBUG - 2023-09-28 21:25:26 --> UTF-8 Support Enabled
INFO - 2023-09-28 21:25:26 --> Utf8 Class Initialized
INFO - 2023-09-28 21:25:26 --> URI Class Initialized
INFO - 2023-09-28 21:25:26 --> Router Class Initialized
INFO - 2023-09-28 21:25:26 --> Output Class Initialized
INFO - 2023-09-28 21:25:26 --> Security Class Initialized
DEBUG - 2023-09-28 21:25:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-28 21:25:26 --> Input Class Initialized
INFO - 2023-09-28 21:25:26 --> Language Class Initialized
INFO - 2023-09-28 21:25:26 --> Language Class Initialized
INFO - 2023-09-28 21:25:26 --> Config Class Initialized
INFO - 2023-09-28 21:25:26 --> Loader Class Initialized
INFO - 2023-09-28 21:25:26 --> Helper loaded: url_helper
INFO - 2023-09-28 21:25:26 --> Helper loaded: file_helper
INFO - 2023-09-28 21:25:26 --> Helper loaded: form_helper
INFO - 2023-09-28 21:25:26 --> Helper loaded: my_helper
INFO - 2023-09-28 21:25:26 --> Database Driver Class Initialized
INFO - 2023-09-28 21:25:26 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-28 21:25:26 --> Controller Class Initialized
INFO - 2023-09-28 21:25:26 --> Final output sent to browser
DEBUG - 2023-09-28 21:25:26 --> Total execution time: 0.1625
INFO - 2023-09-28 21:25:26 --> Config Class Initialized
INFO - 2023-09-28 21:25:26 --> Hooks Class Initialized
DEBUG - 2023-09-28 21:25:26 --> UTF-8 Support Enabled
INFO - 2023-09-28 21:25:26 --> Utf8 Class Initialized
INFO - 2023-09-28 21:25:26 --> URI Class Initialized
INFO - 2023-09-28 21:25:26 --> Router Class Initialized
INFO - 2023-09-28 21:25:26 --> Output Class Initialized
INFO - 2023-09-28 21:25:26 --> Security Class Initialized
DEBUG - 2023-09-28 21:25:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-28 21:25:26 --> Input Class Initialized
INFO - 2023-09-28 21:25:26 --> Language Class Initialized
INFO - 2023-09-28 21:25:26 --> Language Class Initialized
INFO - 2023-09-28 21:25:26 --> Config Class Initialized
INFO - 2023-09-28 21:25:26 --> Loader Class Initialized
INFO - 2023-09-28 21:25:26 --> Helper loaded: url_helper
INFO - 2023-09-28 21:25:26 --> Helper loaded: file_helper
INFO - 2023-09-28 21:25:26 --> Helper loaded: form_helper
INFO - 2023-09-28 21:25:26 --> Helper loaded: my_helper
INFO - 2023-09-28 21:25:26 --> Database Driver Class Initialized
INFO - 2023-09-28 21:25:26 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-28 21:25:26 --> Controller Class Initialized
INFO - 2023-09-28 21:25:27 --> Config Class Initialized
INFO - 2023-09-28 21:25:27 --> Hooks Class Initialized
DEBUG - 2023-09-28 21:25:27 --> UTF-8 Support Enabled
INFO - 2023-09-28 21:25:27 --> Utf8 Class Initialized
INFO - 2023-09-28 21:25:27 --> URI Class Initialized
INFO - 2023-09-28 21:25:27 --> Router Class Initialized
INFO - 2023-09-28 21:25:27 --> Output Class Initialized
INFO - 2023-09-28 21:25:27 --> Security Class Initialized
DEBUG - 2023-09-28 21:25:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-28 21:25:27 --> Input Class Initialized
INFO - 2023-09-28 21:25:27 --> Language Class Initialized
INFO - 2023-09-28 21:25:27 --> Language Class Initialized
INFO - 2023-09-28 21:25:27 --> Config Class Initialized
INFO - 2023-09-28 21:25:27 --> Loader Class Initialized
INFO - 2023-09-28 21:25:27 --> Helper loaded: url_helper
INFO - 2023-09-28 21:25:27 --> Helper loaded: file_helper
INFO - 2023-09-28 21:25:27 --> Helper loaded: form_helper
INFO - 2023-09-28 21:25:27 --> Helper loaded: my_helper
INFO - 2023-09-28 21:25:27 --> Database Driver Class Initialized
INFO - 2023-09-28 21:25:27 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-28 21:25:27 --> Controller Class Initialized
INFO - 2023-09-28 21:25:27 --> Final output sent to browser
DEBUG - 2023-09-28 21:25:27 --> Total execution time: 0.0388
INFO - 2023-09-28 21:25:27 --> Config Class Initialized
INFO - 2023-09-28 21:25:27 --> Hooks Class Initialized
DEBUG - 2023-09-28 21:25:27 --> UTF-8 Support Enabled
INFO - 2023-09-28 21:25:27 --> Utf8 Class Initialized
INFO - 2023-09-28 21:25:27 --> URI Class Initialized
INFO - 2023-09-28 21:25:27 --> Router Class Initialized
INFO - 2023-09-28 21:25:27 --> Output Class Initialized
INFO - 2023-09-28 21:25:27 --> Security Class Initialized
DEBUG - 2023-09-28 21:25:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-28 21:25:27 --> Input Class Initialized
INFO - 2023-09-28 21:25:27 --> Language Class Initialized
INFO - 2023-09-28 21:25:27 --> Language Class Initialized
INFO - 2023-09-28 21:25:27 --> Config Class Initialized
INFO - 2023-09-28 21:25:27 --> Loader Class Initialized
INFO - 2023-09-28 21:25:27 --> Helper loaded: url_helper
INFO - 2023-09-28 21:25:27 --> Helper loaded: file_helper
INFO - 2023-09-28 21:25:27 --> Helper loaded: form_helper
INFO - 2023-09-28 21:25:27 --> Helper loaded: my_helper
INFO - 2023-09-28 21:25:27 --> Database Driver Class Initialized
INFO - 2023-09-28 21:25:27 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-28 21:25:27 --> Controller Class Initialized
INFO - 2023-09-28 21:25:29 --> Config Class Initialized
INFO - 2023-09-28 21:25:29 --> Hooks Class Initialized
DEBUG - 2023-09-28 21:25:29 --> UTF-8 Support Enabled
INFO - 2023-09-28 21:25:29 --> Utf8 Class Initialized
INFO - 2023-09-28 21:25:29 --> URI Class Initialized
INFO - 2023-09-28 21:25:29 --> Router Class Initialized
INFO - 2023-09-28 21:25:29 --> Output Class Initialized
INFO - 2023-09-28 21:25:29 --> Security Class Initialized
DEBUG - 2023-09-28 21:25:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-28 21:25:29 --> Input Class Initialized
INFO - 2023-09-28 21:25:29 --> Language Class Initialized
INFO - 2023-09-28 21:25:29 --> Language Class Initialized
INFO - 2023-09-28 21:25:29 --> Config Class Initialized
INFO - 2023-09-28 21:25:29 --> Loader Class Initialized
INFO - 2023-09-28 21:25:29 --> Helper loaded: url_helper
INFO - 2023-09-28 21:25:29 --> Helper loaded: file_helper
INFO - 2023-09-28 21:25:29 --> Helper loaded: form_helper
INFO - 2023-09-28 21:25:29 --> Helper loaded: my_helper
INFO - 2023-09-28 21:25:29 --> Database Driver Class Initialized
INFO - 2023-09-28 21:25:29 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-28 21:25:29 --> Controller Class Initialized
INFO - 2023-09-28 21:25:29 --> Final output sent to browser
DEBUG - 2023-09-28 21:25:29 --> Total execution time: 0.0980
INFO - 2023-09-28 21:25:29 --> Config Class Initialized
INFO - 2023-09-28 21:25:29 --> Hooks Class Initialized
DEBUG - 2023-09-28 21:25:29 --> UTF-8 Support Enabled
INFO - 2023-09-28 21:25:29 --> Utf8 Class Initialized
INFO - 2023-09-28 21:25:29 --> URI Class Initialized
INFO - 2023-09-28 21:25:29 --> Router Class Initialized
INFO - 2023-09-28 21:25:29 --> Output Class Initialized
INFO - 2023-09-28 21:25:29 --> Security Class Initialized
DEBUG - 2023-09-28 21:25:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-28 21:25:29 --> Input Class Initialized
INFO - 2023-09-28 21:25:29 --> Language Class Initialized
INFO - 2023-09-28 21:25:29 --> Language Class Initialized
INFO - 2023-09-28 21:25:29 --> Config Class Initialized
INFO - 2023-09-28 21:25:29 --> Loader Class Initialized
INFO - 2023-09-28 21:25:29 --> Helper loaded: url_helper
INFO - 2023-09-28 21:25:29 --> Helper loaded: file_helper
INFO - 2023-09-28 21:25:29 --> Helper loaded: form_helper
INFO - 2023-09-28 21:25:29 --> Helper loaded: my_helper
INFO - 2023-09-28 21:25:29 --> Database Driver Class Initialized
INFO - 2023-09-28 21:25:29 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-28 21:25:29 --> Controller Class Initialized
INFO - 2023-09-28 21:25:30 --> Config Class Initialized
INFO - 2023-09-28 21:25:30 --> Hooks Class Initialized
DEBUG - 2023-09-28 21:25:30 --> UTF-8 Support Enabled
INFO - 2023-09-28 21:25:30 --> Utf8 Class Initialized
INFO - 2023-09-28 21:25:30 --> URI Class Initialized
INFO - 2023-09-28 21:25:30 --> Router Class Initialized
INFO - 2023-09-28 21:25:30 --> Output Class Initialized
INFO - 2023-09-28 21:25:30 --> Security Class Initialized
DEBUG - 2023-09-28 21:25:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-28 21:25:30 --> Input Class Initialized
INFO - 2023-09-28 21:25:30 --> Language Class Initialized
INFO - 2023-09-28 21:25:30 --> Language Class Initialized
INFO - 2023-09-28 21:25:30 --> Config Class Initialized
INFO - 2023-09-28 21:25:30 --> Loader Class Initialized
INFO - 2023-09-28 21:25:30 --> Helper loaded: url_helper
INFO - 2023-09-28 21:25:30 --> Helper loaded: file_helper
INFO - 2023-09-28 21:25:30 --> Helper loaded: form_helper
INFO - 2023-09-28 21:25:30 --> Helper loaded: my_helper
INFO - 2023-09-28 21:25:30 --> Database Driver Class Initialized
INFO - 2023-09-28 21:25:30 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-28 21:25:30 --> Controller Class Initialized
INFO - 2023-09-28 21:25:30 --> Final output sent to browser
DEBUG - 2023-09-28 21:25:30 --> Total execution time: 0.0603
INFO - 2023-09-28 21:25:30 --> Config Class Initialized
INFO - 2023-09-28 21:25:30 --> Hooks Class Initialized
DEBUG - 2023-09-28 21:25:30 --> UTF-8 Support Enabled
INFO - 2023-09-28 21:25:30 --> Utf8 Class Initialized
INFO - 2023-09-28 21:25:30 --> URI Class Initialized
INFO - 2023-09-28 21:25:30 --> Router Class Initialized
INFO - 2023-09-28 21:25:30 --> Output Class Initialized
INFO - 2023-09-28 21:25:30 --> Security Class Initialized
DEBUG - 2023-09-28 21:25:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-28 21:25:30 --> Input Class Initialized
INFO - 2023-09-28 21:25:30 --> Language Class Initialized
INFO - 2023-09-28 21:25:30 --> Language Class Initialized
INFO - 2023-09-28 21:25:30 --> Config Class Initialized
INFO - 2023-09-28 21:25:30 --> Loader Class Initialized
INFO - 2023-09-28 21:25:30 --> Helper loaded: url_helper
INFO - 2023-09-28 21:25:30 --> Helper loaded: file_helper
INFO - 2023-09-28 21:25:30 --> Helper loaded: form_helper
INFO - 2023-09-28 21:25:30 --> Helper loaded: my_helper
INFO - 2023-09-28 21:25:30 --> Database Driver Class Initialized
INFO - 2023-09-28 21:25:30 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-28 21:25:30 --> Controller Class Initialized
INFO - 2023-09-28 21:25:32 --> Config Class Initialized
INFO - 2023-09-28 21:25:32 --> Hooks Class Initialized
DEBUG - 2023-09-28 21:25:32 --> UTF-8 Support Enabled
INFO - 2023-09-28 21:25:32 --> Utf8 Class Initialized
INFO - 2023-09-28 21:25:32 --> URI Class Initialized
INFO - 2023-09-28 21:25:32 --> Router Class Initialized
INFO - 2023-09-28 21:25:32 --> Output Class Initialized
INFO - 2023-09-28 21:25:32 --> Security Class Initialized
DEBUG - 2023-09-28 21:25:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-28 21:25:32 --> Input Class Initialized
INFO - 2023-09-28 21:25:32 --> Language Class Initialized
INFO - 2023-09-28 21:25:32 --> Language Class Initialized
INFO - 2023-09-28 21:25:32 --> Config Class Initialized
INFO - 2023-09-28 21:25:32 --> Loader Class Initialized
INFO - 2023-09-28 21:25:32 --> Helper loaded: url_helper
INFO - 2023-09-28 21:25:32 --> Helper loaded: file_helper
INFO - 2023-09-28 21:25:32 --> Helper loaded: form_helper
INFO - 2023-09-28 21:25:32 --> Helper loaded: my_helper
INFO - 2023-09-28 21:25:32 --> Database Driver Class Initialized
INFO - 2023-09-28 21:25:32 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-28 21:25:32 --> Controller Class Initialized
INFO - 2023-09-28 21:25:32 --> Final output sent to browser
DEBUG - 2023-09-28 21:25:32 --> Total execution time: 0.0895
INFO - 2023-09-28 21:25:32 --> Config Class Initialized
INFO - 2023-09-28 21:25:32 --> Hooks Class Initialized
DEBUG - 2023-09-28 21:25:32 --> UTF-8 Support Enabled
INFO - 2023-09-28 21:25:32 --> Utf8 Class Initialized
INFO - 2023-09-28 21:25:32 --> URI Class Initialized
INFO - 2023-09-28 21:25:32 --> Router Class Initialized
INFO - 2023-09-28 21:25:32 --> Output Class Initialized
INFO - 2023-09-28 21:25:32 --> Security Class Initialized
DEBUG - 2023-09-28 21:25:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-28 21:25:32 --> Input Class Initialized
INFO - 2023-09-28 21:25:32 --> Language Class Initialized
INFO - 2023-09-28 21:25:32 --> Language Class Initialized
INFO - 2023-09-28 21:25:32 --> Config Class Initialized
INFO - 2023-09-28 21:25:32 --> Loader Class Initialized
INFO - 2023-09-28 21:25:32 --> Helper loaded: url_helper
INFO - 2023-09-28 21:25:32 --> Helper loaded: file_helper
INFO - 2023-09-28 21:25:32 --> Helper loaded: form_helper
INFO - 2023-09-28 21:25:32 --> Helper loaded: my_helper
INFO - 2023-09-28 21:25:32 --> Database Driver Class Initialized
INFO - 2023-09-28 21:25:32 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-28 21:25:32 --> Controller Class Initialized
INFO - 2023-09-28 21:25:33 --> Config Class Initialized
INFO - 2023-09-28 21:25:33 --> Hooks Class Initialized
DEBUG - 2023-09-28 21:25:33 --> UTF-8 Support Enabled
INFO - 2023-09-28 21:25:33 --> Utf8 Class Initialized
INFO - 2023-09-28 21:25:33 --> URI Class Initialized
INFO - 2023-09-28 21:25:33 --> Router Class Initialized
INFO - 2023-09-28 21:25:33 --> Output Class Initialized
INFO - 2023-09-28 21:25:33 --> Security Class Initialized
DEBUG - 2023-09-28 21:25:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-28 21:25:33 --> Input Class Initialized
INFO - 2023-09-28 21:25:33 --> Language Class Initialized
INFO - 2023-09-28 21:25:33 --> Language Class Initialized
INFO - 2023-09-28 21:25:33 --> Config Class Initialized
INFO - 2023-09-28 21:25:33 --> Loader Class Initialized
INFO - 2023-09-28 21:25:33 --> Helper loaded: url_helper
INFO - 2023-09-28 21:25:33 --> Helper loaded: file_helper
INFO - 2023-09-28 21:25:33 --> Helper loaded: form_helper
INFO - 2023-09-28 21:25:33 --> Helper loaded: my_helper
INFO - 2023-09-28 21:25:33 --> Database Driver Class Initialized
INFO - 2023-09-28 21:25:33 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-28 21:25:33 --> Controller Class Initialized
INFO - 2023-09-28 21:25:33 --> Final output sent to browser
DEBUG - 2023-09-28 21:25:33 --> Total execution time: 0.1104
INFO - 2023-09-28 21:25:33 --> Config Class Initialized
INFO - 2023-09-28 21:25:33 --> Hooks Class Initialized
DEBUG - 2023-09-28 21:25:33 --> UTF-8 Support Enabled
INFO - 2023-09-28 21:25:33 --> Utf8 Class Initialized
INFO - 2023-09-28 21:25:33 --> URI Class Initialized
INFO - 2023-09-28 21:25:33 --> Router Class Initialized
INFO - 2023-09-28 21:25:33 --> Output Class Initialized
INFO - 2023-09-28 21:25:33 --> Security Class Initialized
DEBUG - 2023-09-28 21:25:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-28 21:25:33 --> Input Class Initialized
INFO - 2023-09-28 21:25:33 --> Language Class Initialized
INFO - 2023-09-28 21:25:33 --> Language Class Initialized
INFO - 2023-09-28 21:25:33 --> Config Class Initialized
INFO - 2023-09-28 21:25:33 --> Loader Class Initialized
INFO - 2023-09-28 21:25:33 --> Helper loaded: url_helper
INFO - 2023-09-28 21:25:33 --> Helper loaded: file_helper
INFO - 2023-09-28 21:25:33 --> Helper loaded: form_helper
INFO - 2023-09-28 21:25:33 --> Helper loaded: my_helper
INFO - 2023-09-28 21:25:33 --> Database Driver Class Initialized
INFO - 2023-09-28 21:25:33 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-28 21:25:33 --> Controller Class Initialized
INFO - 2023-09-28 21:25:35 --> Config Class Initialized
INFO - 2023-09-28 21:25:35 --> Hooks Class Initialized
DEBUG - 2023-09-28 21:25:35 --> UTF-8 Support Enabled
INFO - 2023-09-28 21:25:35 --> Utf8 Class Initialized
INFO - 2023-09-28 21:25:35 --> URI Class Initialized
INFO - 2023-09-28 21:25:35 --> Router Class Initialized
INFO - 2023-09-28 21:25:35 --> Output Class Initialized
INFO - 2023-09-28 21:25:35 --> Security Class Initialized
DEBUG - 2023-09-28 21:25:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-28 21:25:35 --> Input Class Initialized
INFO - 2023-09-28 21:25:35 --> Language Class Initialized
INFO - 2023-09-28 21:25:35 --> Language Class Initialized
INFO - 2023-09-28 21:25:35 --> Config Class Initialized
INFO - 2023-09-28 21:25:35 --> Loader Class Initialized
INFO - 2023-09-28 21:25:35 --> Helper loaded: url_helper
INFO - 2023-09-28 21:25:35 --> Helper loaded: file_helper
INFO - 2023-09-28 21:25:35 --> Helper loaded: form_helper
INFO - 2023-09-28 21:25:35 --> Helper loaded: my_helper
INFO - 2023-09-28 21:25:35 --> Database Driver Class Initialized
INFO - 2023-09-28 21:25:35 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-28 21:25:35 --> Controller Class Initialized
INFO - 2023-09-28 21:25:35 --> Final output sent to browser
DEBUG - 2023-09-28 21:25:35 --> Total execution time: 0.0455
INFO - 2023-09-28 21:25:35 --> Config Class Initialized
INFO - 2023-09-28 21:25:35 --> Hooks Class Initialized
DEBUG - 2023-09-28 21:25:35 --> UTF-8 Support Enabled
INFO - 2023-09-28 21:25:35 --> Utf8 Class Initialized
INFO - 2023-09-28 21:25:35 --> URI Class Initialized
INFO - 2023-09-28 21:25:35 --> Router Class Initialized
INFO - 2023-09-28 21:25:35 --> Output Class Initialized
INFO - 2023-09-28 21:25:35 --> Security Class Initialized
DEBUG - 2023-09-28 21:25:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-28 21:25:35 --> Input Class Initialized
INFO - 2023-09-28 21:25:35 --> Language Class Initialized
INFO - 2023-09-28 21:25:35 --> Language Class Initialized
INFO - 2023-09-28 21:25:35 --> Config Class Initialized
INFO - 2023-09-28 21:25:35 --> Loader Class Initialized
INFO - 2023-09-28 21:25:35 --> Config Class Initialized
INFO - 2023-09-28 21:25:35 --> Hooks Class Initialized
DEBUG - 2023-09-28 21:25:35 --> UTF-8 Support Enabled
INFO - 2023-09-28 21:25:35 --> Utf8 Class Initialized
INFO - 2023-09-28 21:25:35 --> URI Class Initialized
INFO - 2023-09-28 21:25:35 --> Router Class Initialized
INFO - 2023-09-28 21:25:35 --> Output Class Initialized
INFO - 2023-09-28 21:25:35 --> Security Class Initialized
DEBUG - 2023-09-28 21:25:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-28 21:25:35 --> Input Class Initialized
INFO - 2023-09-28 21:25:35 --> Language Class Initialized
INFO - 2023-09-28 21:25:35 --> Helper loaded: url_helper
INFO - 2023-09-28 21:25:35 --> Helper loaded: file_helper
INFO - 2023-09-28 21:25:35 --> Helper loaded: form_helper
INFO - 2023-09-28 21:25:35 --> Helper loaded: my_helper
INFO - 2023-09-28 21:25:35 --> Language Class Initialized
INFO - 2023-09-28 21:25:35 --> Config Class Initialized
INFO - 2023-09-28 21:25:35 --> Loader Class Initialized
INFO - 2023-09-28 21:25:35 --> Helper loaded: url_helper
INFO - 2023-09-28 21:25:35 --> Helper loaded: file_helper
INFO - 2023-09-28 21:25:35 --> Helper loaded: form_helper
INFO - 2023-09-28 21:25:35 --> Helper loaded: my_helper
INFO - 2023-09-28 21:25:35 --> Database Driver Class Initialized
INFO - 2023-09-28 21:25:35 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-28 21:25:35 --> Controller Class Initialized
INFO - 2023-09-28 21:25:35 --> Final output sent to browser
DEBUG - 2023-09-28 21:25:35 --> Total execution time: 0.0754
INFO - 2023-09-28 21:25:35 --> Database Driver Class Initialized
INFO - 2023-09-28 21:25:35 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-28 21:25:35 --> Controller Class Initialized
INFO - 2023-09-28 21:25:36 --> Config Class Initialized
INFO - 2023-09-28 21:25:36 --> Hooks Class Initialized
DEBUG - 2023-09-28 21:25:36 --> UTF-8 Support Enabled
INFO - 2023-09-28 21:25:36 --> Utf8 Class Initialized
INFO - 2023-09-28 21:25:36 --> URI Class Initialized
INFO - 2023-09-28 21:25:36 --> Router Class Initialized
INFO - 2023-09-28 21:25:36 --> Output Class Initialized
INFO - 2023-09-28 21:25:36 --> Security Class Initialized
DEBUG - 2023-09-28 21:25:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-28 21:25:36 --> Input Class Initialized
INFO - 2023-09-28 21:25:36 --> Language Class Initialized
INFO - 2023-09-28 21:25:36 --> Language Class Initialized
INFO - 2023-09-28 21:25:36 --> Config Class Initialized
INFO - 2023-09-28 21:25:36 --> Loader Class Initialized
INFO - 2023-09-28 21:25:36 --> Helper loaded: url_helper
INFO - 2023-09-28 21:25:36 --> Helper loaded: file_helper
INFO - 2023-09-28 21:25:36 --> Helper loaded: form_helper
INFO - 2023-09-28 21:25:36 --> Helper loaded: my_helper
INFO - 2023-09-28 21:25:36 --> Database Driver Class Initialized
INFO - 2023-09-28 21:25:36 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-28 21:25:36 --> Controller Class Initialized
INFO - 2023-09-28 21:25:36 --> Config Class Initialized
INFO - 2023-09-28 21:25:36 --> Hooks Class Initialized
DEBUG - 2023-09-28 21:25:36 --> UTF-8 Support Enabled
INFO - 2023-09-28 21:25:36 --> Utf8 Class Initialized
INFO - 2023-09-28 21:25:36 --> URI Class Initialized
INFO - 2023-09-28 21:25:36 --> Router Class Initialized
INFO - 2023-09-28 21:25:36 --> Output Class Initialized
INFO - 2023-09-28 21:25:36 --> Security Class Initialized
DEBUG - 2023-09-28 21:25:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-28 21:25:36 --> Input Class Initialized
INFO - 2023-09-28 21:25:36 --> Language Class Initialized
INFO - 2023-09-28 21:25:36 --> Language Class Initialized
INFO - 2023-09-28 21:25:36 --> Config Class Initialized
INFO - 2023-09-28 21:25:36 --> Loader Class Initialized
INFO - 2023-09-28 21:25:36 --> Helper loaded: url_helper
INFO - 2023-09-28 21:25:36 --> Helper loaded: file_helper
INFO - 2023-09-28 21:25:36 --> Helper loaded: form_helper
INFO - 2023-09-28 21:25:36 --> Helper loaded: my_helper
INFO - 2023-09-28 21:25:36 --> Database Driver Class Initialized
INFO - 2023-09-28 21:25:36 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-28 21:25:36 --> Controller Class Initialized
INFO - 2023-09-28 21:25:37 --> Final output sent to browser
DEBUG - 2023-09-28 21:25:37 --> Total execution time: 0.1340
INFO - 2023-09-28 21:25:37 --> Config Class Initialized
INFO - 2023-09-28 21:25:37 --> Hooks Class Initialized
DEBUG - 2023-09-28 21:25:37 --> UTF-8 Support Enabled
INFO - 2023-09-28 21:25:37 --> Utf8 Class Initialized
INFO - 2023-09-28 21:25:37 --> URI Class Initialized
INFO - 2023-09-28 21:25:37 --> Router Class Initialized
INFO - 2023-09-28 21:25:37 --> Output Class Initialized
INFO - 2023-09-28 21:25:37 --> Security Class Initialized
DEBUG - 2023-09-28 21:25:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-28 21:25:37 --> Input Class Initialized
INFO - 2023-09-28 21:25:37 --> Language Class Initialized
INFO - 2023-09-28 21:25:37 --> Language Class Initialized
INFO - 2023-09-28 21:25:37 --> Config Class Initialized
INFO - 2023-09-28 21:25:37 --> Loader Class Initialized
INFO - 2023-09-28 21:25:37 --> Helper loaded: url_helper
INFO - 2023-09-28 21:25:37 --> Helper loaded: file_helper
INFO - 2023-09-28 21:25:37 --> Helper loaded: form_helper
INFO - 2023-09-28 21:25:37 --> Helper loaded: my_helper
INFO - 2023-09-28 21:25:37 --> Database Driver Class Initialized
INFO - 2023-09-28 21:25:37 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-28 21:25:37 --> Controller Class Initialized
INFO - 2023-09-28 21:25:38 --> Config Class Initialized
INFO - 2023-09-28 21:25:38 --> Hooks Class Initialized
DEBUG - 2023-09-28 21:25:38 --> UTF-8 Support Enabled
INFO - 2023-09-28 21:25:38 --> Utf8 Class Initialized
INFO - 2023-09-28 21:25:38 --> URI Class Initialized
INFO - 2023-09-28 21:25:38 --> Router Class Initialized
INFO - 2023-09-28 21:25:38 --> Output Class Initialized
INFO - 2023-09-28 21:25:38 --> Security Class Initialized
DEBUG - 2023-09-28 21:25:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-28 21:25:38 --> Input Class Initialized
INFO - 2023-09-28 21:25:38 --> Language Class Initialized
INFO - 2023-09-28 21:25:38 --> Language Class Initialized
INFO - 2023-09-28 21:25:38 --> Config Class Initialized
INFO - 2023-09-28 21:25:38 --> Loader Class Initialized
INFO - 2023-09-28 21:25:38 --> Helper loaded: url_helper
INFO - 2023-09-28 21:25:38 --> Helper loaded: file_helper
INFO - 2023-09-28 21:25:38 --> Helper loaded: form_helper
INFO - 2023-09-28 21:25:38 --> Helper loaded: my_helper
INFO - 2023-09-28 21:25:38 --> Database Driver Class Initialized
INFO - 2023-09-28 21:25:38 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-28 21:25:38 --> Controller Class Initialized
INFO - 2023-09-28 21:25:38 --> Final output sent to browser
DEBUG - 2023-09-28 21:25:38 --> Total execution time: 0.0827
INFO - 2023-09-28 21:25:38 --> Config Class Initialized
INFO - 2023-09-28 21:25:38 --> Hooks Class Initialized
DEBUG - 2023-09-28 21:25:38 --> UTF-8 Support Enabled
INFO - 2023-09-28 21:25:38 --> Utf8 Class Initialized
INFO - 2023-09-28 21:25:38 --> URI Class Initialized
INFO - 2023-09-28 21:25:38 --> Router Class Initialized
INFO - 2023-09-28 21:25:38 --> Output Class Initialized
INFO - 2023-09-28 21:25:38 --> Security Class Initialized
DEBUG - 2023-09-28 21:25:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-28 21:25:38 --> Input Class Initialized
INFO - 2023-09-28 21:25:38 --> Language Class Initialized
INFO - 2023-09-28 21:25:38 --> Language Class Initialized
INFO - 2023-09-28 21:25:38 --> Config Class Initialized
INFO - 2023-09-28 21:25:38 --> Loader Class Initialized
INFO - 2023-09-28 21:25:38 --> Helper loaded: url_helper
INFO - 2023-09-28 21:25:38 --> Helper loaded: file_helper
INFO - 2023-09-28 21:25:38 --> Helper loaded: form_helper
INFO - 2023-09-28 21:25:38 --> Helper loaded: my_helper
INFO - 2023-09-28 21:25:38 --> Database Driver Class Initialized
INFO - 2023-09-28 21:25:38 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-28 21:25:38 --> Controller Class Initialized
INFO - 2023-09-28 21:25:40 --> Config Class Initialized
INFO - 2023-09-28 21:25:40 --> Hooks Class Initialized
DEBUG - 2023-09-28 21:25:40 --> UTF-8 Support Enabled
INFO - 2023-09-28 21:25:40 --> Utf8 Class Initialized
INFO - 2023-09-28 21:25:40 --> URI Class Initialized
INFO - 2023-09-28 21:25:40 --> Router Class Initialized
INFO - 2023-09-28 21:25:40 --> Output Class Initialized
INFO - 2023-09-28 21:25:40 --> Security Class Initialized
DEBUG - 2023-09-28 21:25:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-28 21:25:40 --> Input Class Initialized
INFO - 2023-09-28 21:25:40 --> Language Class Initialized
INFO - 2023-09-28 21:25:40 --> Language Class Initialized
INFO - 2023-09-28 21:25:40 --> Config Class Initialized
INFO - 2023-09-28 21:25:40 --> Loader Class Initialized
INFO - 2023-09-28 21:25:40 --> Helper loaded: url_helper
INFO - 2023-09-28 21:25:40 --> Helper loaded: file_helper
INFO - 2023-09-28 21:25:40 --> Helper loaded: form_helper
INFO - 2023-09-28 21:25:40 --> Helper loaded: my_helper
INFO - 2023-09-28 21:25:40 --> Database Driver Class Initialized
INFO - 2023-09-28 21:25:40 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-28 21:25:40 --> Controller Class Initialized
INFO - 2023-09-28 21:25:40 --> Final output sent to browser
DEBUG - 2023-09-28 21:25:40 --> Total execution time: 0.0356
INFO - 2023-09-28 21:25:40 --> Config Class Initialized
INFO - 2023-09-28 21:25:40 --> Hooks Class Initialized
DEBUG - 2023-09-28 21:25:40 --> UTF-8 Support Enabled
INFO - 2023-09-28 21:25:40 --> Utf8 Class Initialized
INFO - 2023-09-28 21:25:40 --> URI Class Initialized
INFO - 2023-09-28 21:25:40 --> Router Class Initialized
INFO - 2023-09-28 21:25:40 --> Output Class Initialized
INFO - 2023-09-28 21:25:40 --> Security Class Initialized
DEBUG - 2023-09-28 21:25:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-28 21:25:40 --> Input Class Initialized
INFO - 2023-09-28 21:25:40 --> Language Class Initialized
INFO - 2023-09-28 21:25:40 --> Language Class Initialized
INFO - 2023-09-28 21:25:40 --> Config Class Initialized
INFO - 2023-09-28 21:25:40 --> Loader Class Initialized
INFO - 2023-09-28 21:25:40 --> Helper loaded: url_helper
INFO - 2023-09-28 21:25:40 --> Helper loaded: file_helper
INFO - 2023-09-28 21:25:40 --> Helper loaded: form_helper
INFO - 2023-09-28 21:25:40 --> Helper loaded: my_helper
INFO - 2023-09-28 21:25:40 --> Database Driver Class Initialized
INFO - 2023-09-28 21:25:40 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-28 21:25:40 --> Controller Class Initialized
INFO - 2023-09-28 21:25:41 --> Config Class Initialized
INFO - 2023-09-28 21:25:41 --> Hooks Class Initialized
DEBUG - 2023-09-28 21:25:41 --> UTF-8 Support Enabled
INFO - 2023-09-28 21:25:41 --> Utf8 Class Initialized
INFO - 2023-09-28 21:25:41 --> URI Class Initialized
INFO - 2023-09-28 21:25:41 --> Router Class Initialized
INFO - 2023-09-28 21:25:41 --> Output Class Initialized
INFO - 2023-09-28 21:25:41 --> Security Class Initialized
DEBUG - 2023-09-28 21:25:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-28 21:25:41 --> Input Class Initialized
INFO - 2023-09-28 21:25:41 --> Language Class Initialized
INFO - 2023-09-28 21:25:41 --> Language Class Initialized
INFO - 2023-09-28 21:25:41 --> Config Class Initialized
INFO - 2023-09-28 21:25:41 --> Loader Class Initialized
INFO - 2023-09-28 21:25:41 --> Helper loaded: url_helper
INFO - 2023-09-28 21:25:41 --> Helper loaded: file_helper
INFO - 2023-09-28 21:25:41 --> Helper loaded: form_helper
INFO - 2023-09-28 21:25:41 --> Helper loaded: my_helper
INFO - 2023-09-28 21:25:41 --> Database Driver Class Initialized
INFO - 2023-09-28 21:25:41 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-28 21:25:41 --> Controller Class Initialized
INFO - 2023-09-28 21:25:41 --> Final output sent to browser
DEBUG - 2023-09-28 21:25:41 --> Total execution time: 0.0555
INFO - 2023-09-28 21:25:42 --> Config Class Initialized
INFO - 2023-09-28 21:25:42 --> Hooks Class Initialized
DEBUG - 2023-09-28 21:25:42 --> UTF-8 Support Enabled
INFO - 2023-09-28 21:25:42 --> Utf8 Class Initialized
INFO - 2023-09-28 21:25:42 --> URI Class Initialized
INFO - 2023-09-28 21:25:42 --> Router Class Initialized
INFO - 2023-09-28 21:25:42 --> Output Class Initialized
INFO - 2023-09-28 21:25:42 --> Security Class Initialized
DEBUG - 2023-09-28 21:25:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-28 21:25:42 --> Input Class Initialized
INFO - 2023-09-28 21:25:42 --> Language Class Initialized
INFO - 2023-09-28 21:25:42 --> Language Class Initialized
INFO - 2023-09-28 21:25:42 --> Config Class Initialized
INFO - 2023-09-28 21:25:42 --> Loader Class Initialized
INFO - 2023-09-28 21:25:42 --> Helper loaded: url_helper
INFO - 2023-09-28 21:25:42 --> Helper loaded: file_helper
INFO - 2023-09-28 21:25:42 --> Helper loaded: form_helper
INFO - 2023-09-28 21:25:42 --> Helper loaded: my_helper
INFO - 2023-09-28 21:25:42 --> Database Driver Class Initialized
INFO - 2023-09-28 21:25:42 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-28 21:25:42 --> Controller Class Initialized
INFO - 2023-09-28 21:25:43 --> Config Class Initialized
INFO - 2023-09-28 21:25:43 --> Hooks Class Initialized
DEBUG - 2023-09-28 21:25:43 --> UTF-8 Support Enabled
INFO - 2023-09-28 21:25:43 --> Utf8 Class Initialized
INFO - 2023-09-28 21:25:43 --> URI Class Initialized
INFO - 2023-09-28 21:25:43 --> Router Class Initialized
INFO - 2023-09-28 21:25:43 --> Output Class Initialized
INFO - 2023-09-28 21:25:43 --> Security Class Initialized
DEBUG - 2023-09-28 21:25:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-28 21:25:43 --> Input Class Initialized
INFO - 2023-09-28 21:25:43 --> Language Class Initialized
INFO - 2023-09-28 21:25:43 --> Language Class Initialized
INFO - 2023-09-28 21:25:43 --> Config Class Initialized
INFO - 2023-09-28 21:25:43 --> Loader Class Initialized
INFO - 2023-09-28 21:25:43 --> Helper loaded: url_helper
INFO - 2023-09-28 21:25:43 --> Helper loaded: file_helper
INFO - 2023-09-28 21:25:43 --> Helper loaded: form_helper
INFO - 2023-09-28 21:25:43 --> Helper loaded: my_helper
INFO - 2023-09-28 21:25:43 --> Database Driver Class Initialized
INFO - 2023-09-28 21:25:43 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-28 21:25:43 --> Controller Class Initialized
INFO - 2023-09-28 21:25:43 --> Final output sent to browser
DEBUG - 2023-09-28 21:25:43 --> Total execution time: 0.0569
INFO - 2023-09-28 21:25:43 --> Config Class Initialized
INFO - 2023-09-28 21:25:43 --> Hooks Class Initialized
DEBUG - 2023-09-28 21:25:43 --> UTF-8 Support Enabled
INFO - 2023-09-28 21:25:43 --> Utf8 Class Initialized
INFO - 2023-09-28 21:25:43 --> URI Class Initialized
INFO - 2023-09-28 21:25:43 --> Router Class Initialized
INFO - 2023-09-28 21:25:43 --> Output Class Initialized
INFO - 2023-09-28 21:25:43 --> Security Class Initialized
DEBUG - 2023-09-28 21:25:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-28 21:25:43 --> Input Class Initialized
INFO - 2023-09-28 21:25:43 --> Language Class Initialized
INFO - 2023-09-28 21:25:43 --> Language Class Initialized
INFO - 2023-09-28 21:25:43 --> Config Class Initialized
INFO - 2023-09-28 21:25:43 --> Loader Class Initialized
INFO - 2023-09-28 21:25:43 --> Helper loaded: url_helper
INFO - 2023-09-28 21:25:43 --> Helper loaded: file_helper
INFO - 2023-09-28 21:25:43 --> Helper loaded: form_helper
INFO - 2023-09-28 21:25:43 --> Helper loaded: my_helper
INFO - 2023-09-28 21:25:43 --> Database Driver Class Initialized
INFO - 2023-09-28 21:25:43 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-28 21:25:43 --> Controller Class Initialized
INFO - 2023-09-28 21:25:44 --> Config Class Initialized
INFO - 2023-09-28 21:25:44 --> Hooks Class Initialized
DEBUG - 2023-09-28 21:25:44 --> UTF-8 Support Enabled
INFO - 2023-09-28 21:25:44 --> Utf8 Class Initialized
INFO - 2023-09-28 21:25:44 --> URI Class Initialized
INFO - 2023-09-28 21:25:44 --> Router Class Initialized
INFO - 2023-09-28 21:25:44 --> Output Class Initialized
INFO - 2023-09-28 21:25:44 --> Security Class Initialized
DEBUG - 2023-09-28 21:25:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-28 21:25:44 --> Input Class Initialized
INFO - 2023-09-28 21:25:44 --> Language Class Initialized
INFO - 2023-09-28 21:25:44 --> Language Class Initialized
INFO - 2023-09-28 21:25:44 --> Config Class Initialized
INFO - 2023-09-28 21:25:44 --> Loader Class Initialized
INFO - 2023-09-28 21:25:44 --> Helper loaded: url_helper
INFO - 2023-09-28 21:25:44 --> Helper loaded: file_helper
INFO - 2023-09-28 21:25:44 --> Helper loaded: form_helper
INFO - 2023-09-28 21:25:44 --> Helper loaded: my_helper
INFO - 2023-09-28 21:25:44 --> Database Driver Class Initialized
INFO - 2023-09-28 21:25:44 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-28 21:25:44 --> Controller Class Initialized
INFO - 2023-09-28 21:25:44 --> Final output sent to browser
DEBUG - 2023-09-28 21:25:44 --> Total execution time: 0.0454
INFO - 2023-09-28 21:25:44 --> Config Class Initialized
INFO - 2023-09-28 21:25:44 --> Hooks Class Initialized
DEBUG - 2023-09-28 21:25:44 --> UTF-8 Support Enabled
INFO - 2023-09-28 21:25:44 --> Utf8 Class Initialized
INFO - 2023-09-28 21:25:44 --> URI Class Initialized
INFO - 2023-09-28 21:25:44 --> Router Class Initialized
INFO - 2023-09-28 21:25:44 --> Output Class Initialized
INFO - 2023-09-28 21:25:44 --> Security Class Initialized
DEBUG - 2023-09-28 21:25:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-28 21:25:44 --> Input Class Initialized
INFO - 2023-09-28 21:25:44 --> Language Class Initialized
INFO - 2023-09-28 21:25:44 --> Language Class Initialized
INFO - 2023-09-28 21:25:44 --> Config Class Initialized
INFO - 2023-09-28 21:25:44 --> Loader Class Initialized
INFO - 2023-09-28 21:25:44 --> Helper loaded: url_helper
INFO - 2023-09-28 21:25:44 --> Helper loaded: file_helper
INFO - 2023-09-28 21:25:44 --> Helper loaded: form_helper
INFO - 2023-09-28 21:25:44 --> Helper loaded: my_helper
INFO - 2023-09-28 21:25:44 --> Database Driver Class Initialized
INFO - 2023-09-28 21:25:44 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-28 21:25:44 --> Controller Class Initialized
INFO - 2023-09-28 21:25:47 --> Config Class Initialized
INFO - 2023-09-28 21:25:47 --> Hooks Class Initialized
DEBUG - 2023-09-28 21:25:47 --> UTF-8 Support Enabled
INFO - 2023-09-28 21:25:47 --> Utf8 Class Initialized
INFO - 2023-09-28 21:25:47 --> URI Class Initialized
INFO - 2023-09-28 21:25:47 --> Router Class Initialized
INFO - 2023-09-28 21:25:47 --> Output Class Initialized
INFO - 2023-09-28 21:25:47 --> Security Class Initialized
DEBUG - 2023-09-28 21:25:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-28 21:25:47 --> Input Class Initialized
INFO - 2023-09-28 21:25:47 --> Language Class Initialized
INFO - 2023-09-28 21:25:47 --> Language Class Initialized
INFO - 2023-09-28 21:25:47 --> Config Class Initialized
INFO - 2023-09-28 21:25:47 --> Loader Class Initialized
INFO - 2023-09-28 21:25:47 --> Helper loaded: url_helper
INFO - 2023-09-28 21:25:47 --> Helper loaded: file_helper
INFO - 2023-09-28 21:25:47 --> Helper loaded: form_helper
INFO - 2023-09-28 21:25:47 --> Helper loaded: my_helper
INFO - 2023-09-28 21:25:47 --> Database Driver Class Initialized
INFO - 2023-09-28 21:25:47 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-28 21:25:47 --> Controller Class Initialized
INFO - 2023-09-28 21:25:47 --> Final output sent to browser
DEBUG - 2023-09-28 21:25:47 --> Total execution time: 0.0407
INFO - 2023-09-28 21:25:47 --> Config Class Initialized
INFO - 2023-09-28 21:25:47 --> Hooks Class Initialized
DEBUG - 2023-09-28 21:25:47 --> UTF-8 Support Enabled
INFO - 2023-09-28 21:25:47 --> Utf8 Class Initialized
INFO - 2023-09-28 21:25:47 --> URI Class Initialized
INFO - 2023-09-28 21:25:47 --> Router Class Initialized
INFO - 2023-09-28 21:25:47 --> Output Class Initialized
INFO - 2023-09-28 21:25:47 --> Security Class Initialized
DEBUG - 2023-09-28 21:25:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-28 21:25:47 --> Input Class Initialized
INFO - 2023-09-28 21:25:47 --> Language Class Initialized
INFO - 2023-09-28 21:25:47 --> Language Class Initialized
INFO - 2023-09-28 21:25:47 --> Config Class Initialized
INFO - 2023-09-28 21:25:47 --> Loader Class Initialized
INFO - 2023-09-28 21:25:47 --> Helper loaded: url_helper
INFO - 2023-09-28 21:25:47 --> Helper loaded: file_helper
INFO - 2023-09-28 21:25:47 --> Helper loaded: form_helper
INFO - 2023-09-28 21:25:47 --> Helper loaded: my_helper
INFO - 2023-09-28 21:25:47 --> Database Driver Class Initialized
INFO - 2023-09-28 21:25:47 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-28 21:25:47 --> Controller Class Initialized
INFO - 2023-09-28 21:25:49 --> Config Class Initialized
INFO - 2023-09-28 21:25:49 --> Hooks Class Initialized
DEBUG - 2023-09-28 21:25:49 --> UTF-8 Support Enabled
INFO - 2023-09-28 21:25:49 --> Utf8 Class Initialized
INFO - 2023-09-28 21:25:49 --> URI Class Initialized
INFO - 2023-09-28 21:25:49 --> Router Class Initialized
INFO - 2023-09-28 21:25:49 --> Output Class Initialized
INFO - 2023-09-28 21:25:49 --> Security Class Initialized
DEBUG - 2023-09-28 21:25:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-28 21:25:49 --> Input Class Initialized
INFO - 2023-09-28 21:25:49 --> Language Class Initialized
INFO - 2023-09-28 21:25:49 --> Language Class Initialized
INFO - 2023-09-28 21:25:49 --> Config Class Initialized
INFO - 2023-09-28 21:25:49 --> Loader Class Initialized
INFO - 2023-09-28 21:25:49 --> Helper loaded: url_helper
INFO - 2023-09-28 21:25:49 --> Helper loaded: file_helper
INFO - 2023-09-28 21:25:49 --> Helper loaded: form_helper
INFO - 2023-09-28 21:25:49 --> Helper loaded: my_helper
INFO - 2023-09-28 21:25:49 --> Database Driver Class Initialized
INFO - 2023-09-28 21:25:49 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-28 21:25:49 --> Controller Class Initialized
INFO - 2023-09-28 21:25:49 --> Final output sent to browser
DEBUG - 2023-09-28 21:25:49 --> Total execution time: 0.0512
INFO - 2023-09-28 21:28:33 --> Config Class Initialized
INFO - 2023-09-28 21:28:33 --> Hooks Class Initialized
DEBUG - 2023-09-28 21:28:33 --> UTF-8 Support Enabled
INFO - 2023-09-28 21:28:33 --> Utf8 Class Initialized
INFO - 2023-09-28 21:28:33 --> URI Class Initialized
INFO - 2023-09-28 21:28:33 --> Router Class Initialized
INFO - 2023-09-28 21:28:33 --> Output Class Initialized
INFO - 2023-09-28 21:28:33 --> Security Class Initialized
DEBUG - 2023-09-28 21:28:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-28 21:28:33 --> Input Class Initialized
INFO - 2023-09-28 21:28:33 --> Language Class Initialized
INFO - 2023-09-28 21:28:33 --> Language Class Initialized
INFO - 2023-09-28 21:28:33 --> Config Class Initialized
INFO - 2023-09-28 21:28:33 --> Loader Class Initialized
INFO - 2023-09-28 21:28:33 --> Helper loaded: url_helper
INFO - 2023-09-28 21:28:33 --> Helper loaded: file_helper
INFO - 2023-09-28 21:28:33 --> Helper loaded: form_helper
INFO - 2023-09-28 21:28:33 --> Helper loaded: my_helper
INFO - 2023-09-28 21:28:33 --> Database Driver Class Initialized
INFO - 2023-09-28 21:28:33 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-28 21:28:33 --> Controller Class Initialized
INFO - 2023-09-28 21:28:33 --> Final output sent to browser
DEBUG - 2023-09-28 21:28:33 --> Total execution time: 0.0377
INFO - 2023-09-28 21:28:34 --> Config Class Initialized
INFO - 2023-09-28 21:28:34 --> Hooks Class Initialized
DEBUG - 2023-09-28 21:28:34 --> UTF-8 Support Enabled
INFO - 2023-09-28 21:28:34 --> Utf8 Class Initialized
INFO - 2023-09-28 21:28:34 --> URI Class Initialized
INFO - 2023-09-28 21:28:34 --> Router Class Initialized
INFO - 2023-09-28 21:28:34 --> Output Class Initialized
INFO - 2023-09-28 21:28:34 --> Security Class Initialized
DEBUG - 2023-09-28 21:28:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-28 21:28:34 --> Input Class Initialized
INFO - 2023-09-28 21:28:34 --> Language Class Initialized
INFO - 2023-09-28 21:28:34 --> Language Class Initialized
INFO - 2023-09-28 21:28:34 --> Config Class Initialized
INFO - 2023-09-28 21:28:34 --> Loader Class Initialized
INFO - 2023-09-28 21:28:34 --> Helper loaded: url_helper
INFO - 2023-09-28 21:28:34 --> Helper loaded: file_helper
INFO - 2023-09-28 21:28:34 --> Helper loaded: form_helper
INFO - 2023-09-28 21:28:34 --> Helper loaded: my_helper
INFO - 2023-09-28 21:28:34 --> Database Driver Class Initialized
INFO - 2023-09-28 21:28:34 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-28 21:28:34 --> Controller Class Initialized
INFO - 2023-09-28 21:28:49 --> Config Class Initialized
INFO - 2023-09-28 21:28:49 --> Hooks Class Initialized
DEBUG - 2023-09-28 21:28:49 --> UTF-8 Support Enabled
INFO - 2023-09-28 21:28:49 --> Utf8 Class Initialized
INFO - 2023-09-28 21:28:49 --> URI Class Initialized
INFO - 2023-09-28 21:28:49 --> Router Class Initialized
INFO - 2023-09-28 21:28:49 --> Output Class Initialized
INFO - 2023-09-28 21:28:49 --> Security Class Initialized
DEBUG - 2023-09-28 21:28:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-28 21:28:49 --> Input Class Initialized
INFO - 2023-09-28 21:28:49 --> Language Class Initialized
INFO - 2023-09-28 21:28:49 --> Language Class Initialized
INFO - 2023-09-28 21:28:49 --> Config Class Initialized
INFO - 2023-09-28 21:28:49 --> Loader Class Initialized
INFO - 2023-09-28 21:28:49 --> Helper loaded: url_helper
INFO - 2023-09-28 21:28:49 --> Helper loaded: file_helper
INFO - 2023-09-28 21:28:49 --> Helper loaded: form_helper
INFO - 2023-09-28 21:28:49 --> Helper loaded: my_helper
INFO - 2023-09-28 21:28:49 --> Database Driver Class Initialized
INFO - 2023-09-28 21:28:49 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-28 21:28:49 --> Controller Class Initialized
INFO - 2023-09-28 21:28:49 --> Final output sent to browser
DEBUG - 2023-09-28 21:28:49 --> Total execution time: 0.0738
INFO - 2023-09-28 21:28:50 --> Config Class Initialized
INFO - 2023-09-28 21:28:50 --> Hooks Class Initialized
DEBUG - 2023-09-28 21:28:50 --> UTF-8 Support Enabled
INFO - 2023-09-28 21:28:50 --> Utf8 Class Initialized
INFO - 2023-09-28 21:28:50 --> URI Class Initialized
INFO - 2023-09-28 21:28:50 --> Router Class Initialized
INFO - 2023-09-28 21:28:50 --> Output Class Initialized
INFO - 2023-09-28 21:28:50 --> Security Class Initialized
DEBUG - 2023-09-28 21:28:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-28 21:28:50 --> Input Class Initialized
INFO - 2023-09-28 21:28:50 --> Language Class Initialized
INFO - 2023-09-28 21:28:50 --> Language Class Initialized
INFO - 2023-09-28 21:28:50 --> Config Class Initialized
INFO - 2023-09-28 21:28:50 --> Loader Class Initialized
INFO - 2023-09-28 21:28:50 --> Helper loaded: url_helper
INFO - 2023-09-28 21:28:50 --> Helper loaded: file_helper
INFO - 2023-09-28 21:28:50 --> Helper loaded: form_helper
INFO - 2023-09-28 21:28:50 --> Helper loaded: my_helper
INFO - 2023-09-28 21:28:50 --> Database Driver Class Initialized
INFO - 2023-09-28 21:28:50 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-28 21:28:50 --> Controller Class Initialized
INFO - 2023-09-28 21:28:50 --> Final output sent to browser
DEBUG - 2023-09-28 21:28:50 --> Total execution time: 0.0359
INFO - 2023-09-28 21:28:53 --> Config Class Initialized
INFO - 2023-09-28 21:28:53 --> Hooks Class Initialized
DEBUG - 2023-09-28 21:28:53 --> UTF-8 Support Enabled
INFO - 2023-09-28 21:28:53 --> Utf8 Class Initialized
INFO - 2023-09-28 21:28:53 --> URI Class Initialized
INFO - 2023-09-28 21:28:53 --> Router Class Initialized
INFO - 2023-09-28 21:28:53 --> Output Class Initialized
INFO - 2023-09-28 21:28:53 --> Security Class Initialized
DEBUG - 2023-09-28 21:28:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-28 21:28:53 --> Input Class Initialized
INFO - 2023-09-28 21:28:53 --> Language Class Initialized
INFO - 2023-09-28 21:28:53 --> Language Class Initialized
INFO - 2023-09-28 21:28:53 --> Config Class Initialized
INFO - 2023-09-28 21:28:53 --> Loader Class Initialized
INFO - 2023-09-28 21:28:53 --> Helper loaded: url_helper
INFO - 2023-09-28 21:28:53 --> Helper loaded: file_helper
INFO - 2023-09-28 21:28:53 --> Helper loaded: form_helper
INFO - 2023-09-28 21:28:53 --> Helper loaded: my_helper
INFO - 2023-09-28 21:28:53 --> Database Driver Class Initialized
INFO - 2023-09-28 21:28:53 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-28 21:28:53 --> Controller Class Initialized
INFO - 2023-09-28 21:28:53 --> Final output sent to browser
DEBUG - 2023-09-28 21:28:53 --> Total execution time: 0.0580
INFO - 2023-09-28 21:28:55 --> Config Class Initialized
INFO - 2023-09-28 21:28:55 --> Hooks Class Initialized
DEBUG - 2023-09-28 21:28:55 --> UTF-8 Support Enabled
INFO - 2023-09-28 21:28:55 --> Utf8 Class Initialized
INFO - 2023-09-28 21:28:55 --> URI Class Initialized
INFO - 2023-09-28 21:28:55 --> Router Class Initialized
INFO - 2023-09-28 21:28:55 --> Output Class Initialized
INFO - 2023-09-28 21:28:55 --> Security Class Initialized
DEBUG - 2023-09-28 21:28:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-28 21:28:55 --> Input Class Initialized
INFO - 2023-09-28 21:28:55 --> Language Class Initialized
INFO - 2023-09-28 21:28:55 --> Language Class Initialized
INFO - 2023-09-28 21:28:55 --> Config Class Initialized
INFO - 2023-09-28 21:28:55 --> Loader Class Initialized
INFO - 2023-09-28 21:28:55 --> Helper loaded: url_helper
INFO - 2023-09-28 21:28:55 --> Helper loaded: file_helper
INFO - 2023-09-28 21:28:55 --> Helper loaded: form_helper
INFO - 2023-09-28 21:28:55 --> Helper loaded: my_helper
INFO - 2023-09-28 21:28:55 --> Database Driver Class Initialized
INFO - 2023-09-28 21:28:55 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-28 21:28:55 --> Controller Class Initialized
INFO - 2023-09-28 21:28:55 --> Final output sent to browser
DEBUG - 2023-09-28 21:28:55 --> Total execution time: 0.1187
INFO - 2023-09-28 21:30:08 --> Config Class Initialized
INFO - 2023-09-28 21:30:08 --> Hooks Class Initialized
DEBUG - 2023-09-28 21:30:08 --> UTF-8 Support Enabled
INFO - 2023-09-28 21:30:08 --> Utf8 Class Initialized
INFO - 2023-09-28 21:30:08 --> URI Class Initialized
INFO - 2023-09-28 21:30:08 --> Router Class Initialized
INFO - 2023-09-28 21:30:08 --> Output Class Initialized
INFO - 2023-09-28 21:30:08 --> Security Class Initialized
DEBUG - 2023-09-28 21:30:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-28 21:30:08 --> Input Class Initialized
INFO - 2023-09-28 21:30:08 --> Language Class Initialized
INFO - 2023-09-28 21:30:08 --> Language Class Initialized
INFO - 2023-09-28 21:30:08 --> Config Class Initialized
INFO - 2023-09-28 21:30:08 --> Loader Class Initialized
INFO - 2023-09-28 21:30:08 --> Helper loaded: url_helper
INFO - 2023-09-28 21:30:08 --> Helper loaded: file_helper
INFO - 2023-09-28 21:30:08 --> Helper loaded: form_helper
INFO - 2023-09-28 21:30:08 --> Helper loaded: my_helper
INFO - 2023-09-28 21:30:08 --> Database Driver Class Initialized
INFO - 2023-09-28 21:30:08 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-28 21:30:08 --> Controller Class Initialized
INFO - 2023-09-28 21:30:08 --> Final output sent to browser
DEBUG - 2023-09-28 21:30:08 --> Total execution time: 0.0960
INFO - 2023-09-28 22:02:39 --> Config Class Initialized
INFO - 2023-09-28 22:02:39 --> Hooks Class Initialized
DEBUG - 2023-09-28 22:02:39 --> UTF-8 Support Enabled
INFO - 2023-09-28 22:02:39 --> Utf8 Class Initialized
INFO - 2023-09-28 22:02:39 --> URI Class Initialized
INFO - 2023-09-28 22:02:39 --> Router Class Initialized
INFO - 2023-09-28 22:02:39 --> Output Class Initialized
INFO - 2023-09-28 22:02:39 --> Security Class Initialized
DEBUG - 2023-09-28 22:02:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-28 22:02:39 --> Input Class Initialized
INFO - 2023-09-28 22:02:39 --> Language Class Initialized
INFO - 2023-09-28 22:02:39 --> Language Class Initialized
INFO - 2023-09-28 22:02:39 --> Config Class Initialized
INFO - 2023-09-28 22:02:39 --> Loader Class Initialized
INFO - 2023-09-28 22:02:39 --> Helper loaded: url_helper
INFO - 2023-09-28 22:02:39 --> Helper loaded: file_helper
INFO - 2023-09-28 22:02:39 --> Helper loaded: form_helper
INFO - 2023-09-28 22:02:39 --> Helper loaded: my_helper
INFO - 2023-09-28 22:02:39 --> Database Driver Class Initialized
INFO - 2023-09-28 22:02:39 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-28 22:02:39 --> Controller Class Initialized
DEBUG - 2023-09-28 22:02:39 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/login/views/login.php
DEBUG - 2023-09-28 22:02:39 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-09-28 22:02:39 --> Final output sent to browser
DEBUG - 2023-09-28 22:02:39 --> Total execution time: 0.0798
INFO - 2023-09-28 22:02:53 --> Config Class Initialized
INFO - 2023-09-28 22:02:53 --> Hooks Class Initialized
DEBUG - 2023-09-28 22:02:53 --> UTF-8 Support Enabled
INFO - 2023-09-28 22:02:53 --> Utf8 Class Initialized
INFO - 2023-09-28 22:02:53 --> URI Class Initialized
INFO - 2023-09-28 22:02:53 --> Router Class Initialized
INFO - 2023-09-28 22:02:53 --> Output Class Initialized
INFO - 2023-09-28 22:02:53 --> Security Class Initialized
DEBUG - 2023-09-28 22:02:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-28 22:02:53 --> Input Class Initialized
INFO - 2023-09-28 22:02:53 --> Language Class Initialized
INFO - 2023-09-28 22:02:53 --> Language Class Initialized
INFO - 2023-09-28 22:02:53 --> Config Class Initialized
INFO - 2023-09-28 22:02:53 --> Loader Class Initialized
INFO - 2023-09-28 22:02:53 --> Helper loaded: url_helper
INFO - 2023-09-28 22:02:53 --> Helper loaded: file_helper
INFO - 2023-09-28 22:02:53 --> Helper loaded: form_helper
INFO - 2023-09-28 22:02:53 --> Helper loaded: my_helper
INFO - 2023-09-28 22:02:53 --> Database Driver Class Initialized
INFO - 2023-09-28 22:02:53 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-28 22:02:53 --> Controller Class Initialized
INFO - 2023-09-28 22:02:53 --> Helper loaded: cookie_helper
INFO - 2023-09-28 22:02:53 --> Final output sent to browser
DEBUG - 2023-09-28 22:02:53 --> Total execution time: 0.0622
INFO - 2023-09-28 22:02:54 --> Config Class Initialized
INFO - 2023-09-28 22:02:54 --> Hooks Class Initialized
DEBUG - 2023-09-28 22:02:54 --> UTF-8 Support Enabled
INFO - 2023-09-28 22:02:54 --> Utf8 Class Initialized
INFO - 2023-09-28 22:02:54 --> URI Class Initialized
INFO - 2023-09-28 22:02:54 --> Router Class Initialized
INFO - 2023-09-28 22:02:54 --> Output Class Initialized
INFO - 2023-09-28 22:02:54 --> Security Class Initialized
DEBUG - 2023-09-28 22:02:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-28 22:02:54 --> Input Class Initialized
INFO - 2023-09-28 22:02:54 --> Language Class Initialized
INFO - 2023-09-28 22:02:54 --> Language Class Initialized
INFO - 2023-09-28 22:02:54 --> Config Class Initialized
INFO - 2023-09-28 22:02:54 --> Loader Class Initialized
INFO - 2023-09-28 22:02:54 --> Helper loaded: url_helper
INFO - 2023-09-28 22:02:54 --> Helper loaded: file_helper
INFO - 2023-09-28 22:02:54 --> Helper loaded: form_helper
INFO - 2023-09-28 22:02:54 --> Helper loaded: my_helper
INFO - 2023-09-28 22:02:54 --> Database Driver Class Initialized
INFO - 2023-09-28 22:02:54 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-28 22:02:54 --> Controller Class Initialized
DEBUG - 2023-09-28 22:02:54 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/home/views/v_home_guru.php
DEBUG - 2023-09-28 22:02:54 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-09-28 22:02:54 --> Final output sent to browser
DEBUG - 2023-09-28 22:02:54 --> Total execution time: 0.0487
INFO - 2023-09-28 22:03:00 --> Config Class Initialized
INFO - 2023-09-28 22:03:00 --> Hooks Class Initialized
DEBUG - 2023-09-28 22:03:00 --> UTF-8 Support Enabled
INFO - 2023-09-28 22:03:00 --> Utf8 Class Initialized
INFO - 2023-09-28 22:03:00 --> URI Class Initialized
INFO - 2023-09-28 22:03:00 --> Router Class Initialized
INFO - 2023-09-28 22:03:00 --> Output Class Initialized
INFO - 2023-09-28 22:03:00 --> Security Class Initialized
DEBUG - 2023-09-28 22:03:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-28 22:03:00 --> Input Class Initialized
INFO - 2023-09-28 22:03:00 --> Language Class Initialized
INFO - 2023-09-28 22:03:00 --> Language Class Initialized
INFO - 2023-09-28 22:03:00 --> Config Class Initialized
INFO - 2023-09-28 22:03:00 --> Loader Class Initialized
INFO - 2023-09-28 22:03:00 --> Helper loaded: url_helper
INFO - 2023-09-28 22:03:00 --> Helper loaded: file_helper
INFO - 2023-09-28 22:03:00 --> Helper loaded: form_helper
INFO - 2023-09-28 22:03:00 --> Helper loaded: my_helper
INFO - 2023-09-28 22:03:00 --> Database Driver Class Initialized
INFO - 2023-09-28 22:03:00 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-28 22:03:00 --> Controller Class Initialized
DEBUG - 2023-09-28 22:03:00 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/view_mapel/views/v_view_mapel.php
DEBUG - 2023-09-28 22:03:00 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-09-28 22:03:00 --> Final output sent to browser
DEBUG - 2023-09-28 22:03:00 --> Total execution time: 0.0495
INFO - 2023-09-28 22:03:04 --> Config Class Initialized
INFO - 2023-09-28 22:03:04 --> Hooks Class Initialized
DEBUG - 2023-09-28 22:03:04 --> UTF-8 Support Enabled
INFO - 2023-09-28 22:03:04 --> Utf8 Class Initialized
INFO - 2023-09-28 22:03:04 --> URI Class Initialized
INFO - 2023-09-28 22:03:04 --> Router Class Initialized
INFO - 2023-09-28 22:03:04 --> Output Class Initialized
INFO - 2023-09-28 22:03:04 --> Security Class Initialized
DEBUG - 2023-09-28 22:03:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-28 22:03:04 --> Input Class Initialized
INFO - 2023-09-28 22:03:04 --> Language Class Initialized
INFO - 2023-09-28 22:03:04 --> Language Class Initialized
INFO - 2023-09-28 22:03:04 --> Config Class Initialized
INFO - 2023-09-28 22:03:04 --> Loader Class Initialized
INFO - 2023-09-28 22:03:04 --> Helper loaded: url_helper
INFO - 2023-09-28 22:03:04 --> Helper loaded: file_helper
INFO - 2023-09-28 22:03:04 --> Helper loaded: form_helper
INFO - 2023-09-28 22:03:04 --> Helper loaded: my_helper
INFO - 2023-09-28 22:03:04 --> Database Driver Class Initialized
INFO - 2023-09-28 22:03:04 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-28 22:03:04 --> Controller Class Initialized
DEBUG - 2023-09-28 22:03:04 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/views/list.php
DEBUG - 2023-09-28 22:03:04 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-09-28 22:03:04 --> Final output sent to browser
DEBUG - 2023-09-28 22:03:04 --> Total execution time: 0.0514
INFO - 2023-09-28 22:03:04 --> Config Class Initialized
INFO - 2023-09-28 22:03:04 --> Hooks Class Initialized
DEBUG - 2023-09-28 22:03:04 --> UTF-8 Support Enabled
INFO - 2023-09-28 22:03:04 --> Utf8 Class Initialized
INFO - 2023-09-28 22:03:04 --> URI Class Initialized
INFO - 2023-09-28 22:03:04 --> Router Class Initialized
INFO - 2023-09-28 22:03:04 --> Output Class Initialized
INFO - 2023-09-28 22:03:04 --> Security Class Initialized
DEBUG - 2023-09-28 22:03:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-28 22:03:04 --> Input Class Initialized
INFO - 2023-09-28 22:03:04 --> Language Class Initialized
INFO - 2023-09-28 22:03:04 --> Language Class Initialized
INFO - 2023-09-28 22:03:04 --> Config Class Initialized
INFO - 2023-09-28 22:03:04 --> Loader Class Initialized
INFO - 2023-09-28 22:03:04 --> Helper loaded: url_helper
INFO - 2023-09-28 22:03:04 --> Helper loaded: file_helper
INFO - 2023-09-28 22:03:04 --> Helper loaded: form_helper
INFO - 2023-09-28 22:03:04 --> Helper loaded: my_helper
INFO - 2023-09-28 22:03:04 --> Database Driver Class Initialized
INFO - 2023-09-28 22:03:04 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-28 22:03:04 --> Controller Class Initialized
INFO - 2023-09-28 22:03:12 --> Config Class Initialized
INFO - 2023-09-28 22:03:12 --> Hooks Class Initialized
DEBUG - 2023-09-28 22:03:12 --> UTF-8 Support Enabled
INFO - 2023-09-28 22:03:12 --> Utf8 Class Initialized
INFO - 2023-09-28 22:03:12 --> URI Class Initialized
INFO - 2023-09-28 22:03:12 --> Router Class Initialized
INFO - 2023-09-28 22:03:12 --> Output Class Initialized
INFO - 2023-09-28 22:03:12 --> Security Class Initialized
DEBUG - 2023-09-28 22:03:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-28 22:03:12 --> Input Class Initialized
INFO - 2023-09-28 22:03:12 --> Language Class Initialized
INFO - 2023-09-28 22:03:12 --> Language Class Initialized
INFO - 2023-09-28 22:03:12 --> Config Class Initialized
INFO - 2023-09-28 22:03:12 --> Loader Class Initialized
INFO - 2023-09-28 22:03:12 --> Helper loaded: url_helper
INFO - 2023-09-28 22:03:12 --> Helper loaded: file_helper
INFO - 2023-09-28 22:03:12 --> Helper loaded: form_helper
INFO - 2023-09-28 22:03:12 --> Helper loaded: my_helper
INFO - 2023-09-28 22:03:12 --> Database Driver Class Initialized
INFO - 2023-09-28 22:03:12 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-28 22:03:12 --> Controller Class Initialized
INFO - 2023-09-28 22:03:12 --> Final output sent to browser
DEBUG - 2023-09-28 22:03:12 --> Total execution time: 0.2614
INFO - 2023-09-28 23:27:34 --> Config Class Initialized
INFO - 2023-09-28 23:27:34 --> Hooks Class Initialized
DEBUG - 2023-09-28 23:27:34 --> UTF-8 Support Enabled
INFO - 2023-09-28 23:27:34 --> Utf8 Class Initialized
INFO - 2023-09-28 23:27:34 --> URI Class Initialized
DEBUG - 2023-09-28 23:27:34 --> No URI present. Default controller set.
INFO - 2023-09-28 23:27:34 --> Router Class Initialized
INFO - 2023-09-28 23:27:34 --> Output Class Initialized
INFO - 2023-09-28 23:27:34 --> Security Class Initialized
DEBUG - 2023-09-28 23:27:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-28 23:27:34 --> Input Class Initialized
INFO - 2023-09-28 23:27:34 --> Language Class Initialized
INFO - 2023-09-28 23:27:34 --> Language Class Initialized
INFO - 2023-09-28 23:27:34 --> Config Class Initialized
INFO - 2023-09-28 23:27:34 --> Loader Class Initialized
INFO - 2023-09-28 23:27:34 --> Helper loaded: url_helper
INFO - 2023-09-28 23:27:34 --> Helper loaded: file_helper
INFO - 2023-09-28 23:27:34 --> Helper loaded: form_helper
INFO - 2023-09-28 23:27:34 --> Helper loaded: my_helper
INFO - 2023-09-28 23:27:34 --> Database Driver Class Initialized
INFO - 2023-09-28 23:27:34 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-28 23:27:34 --> Controller Class Initialized
DEBUG - 2023-09-28 23:27:34 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/home/views/v_home_guru.php
DEBUG - 2023-09-28 23:27:34 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-09-28 23:27:34 --> Final output sent to browser
DEBUG - 2023-09-28 23:27:34 --> Total execution time: 0.0657
INFO - 2023-09-28 23:27:43 --> Config Class Initialized
INFO - 2023-09-28 23:27:43 --> Hooks Class Initialized
DEBUG - 2023-09-28 23:27:43 --> UTF-8 Support Enabled
INFO - 2023-09-28 23:27:43 --> Utf8 Class Initialized
INFO - 2023-09-28 23:27:43 --> URI Class Initialized
INFO - 2023-09-28 23:27:43 --> Router Class Initialized
INFO - 2023-09-28 23:27:43 --> Output Class Initialized
INFO - 2023-09-28 23:27:43 --> Security Class Initialized
DEBUG - 2023-09-28 23:27:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-28 23:27:43 --> Input Class Initialized
INFO - 2023-09-28 23:27:43 --> Language Class Initialized
INFO - 2023-09-28 23:27:43 --> Language Class Initialized
INFO - 2023-09-28 23:27:43 --> Config Class Initialized
INFO - 2023-09-28 23:27:43 --> Loader Class Initialized
INFO - 2023-09-28 23:27:43 --> Helper loaded: url_helper
INFO - 2023-09-28 23:27:43 --> Helper loaded: file_helper
INFO - 2023-09-28 23:27:43 --> Helper loaded: form_helper
INFO - 2023-09-28 23:27:43 --> Helper loaded: my_helper
INFO - 2023-09-28 23:27:43 --> Database Driver Class Initialized
INFO - 2023-09-28 23:27:43 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-28 23:27:43 --> Controller Class Initialized
DEBUG - 2023-09-28 23:27:43 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/riwayat_mengajar/views/list.php
DEBUG - 2023-09-28 23:27:43 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-09-28 23:27:43 --> Final output sent to browser
DEBUG - 2023-09-28 23:27:43 --> Total execution time: 0.1035
