<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2023-08-18 06:37:38 --> Config Class Initialized
INFO - 2023-08-18 06:37:38 --> Hooks Class Initialized
DEBUG - 2023-08-18 06:37:38 --> UTF-8 Support Enabled
INFO - 2023-08-18 06:37:38 --> Utf8 Class Initialized
INFO - 2023-08-18 06:37:38 --> URI Class Initialized
DEBUG - 2023-08-18 06:37:38 --> No URI present. Default controller set.
INFO - 2023-08-18 06:37:38 --> Router Class Initialized
INFO - 2023-08-18 06:37:38 --> Output Class Initialized
INFO - 2023-08-18 06:37:38 --> Security Class Initialized
DEBUG - 2023-08-18 06:37:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-18 06:37:38 --> Input Class Initialized
INFO - 2023-08-18 06:37:38 --> Language Class Initialized
INFO - 2023-08-18 06:37:38 --> Language Class Initialized
INFO - 2023-08-18 06:37:38 --> Config Class Initialized
INFO - 2023-08-18 06:37:38 --> Loader Class Initialized
INFO - 2023-08-18 06:37:38 --> Helper loaded: url_helper
INFO - 2023-08-18 06:37:38 --> Helper loaded: file_helper
INFO - 2023-08-18 06:37:38 --> Helper loaded: form_helper
INFO - 2023-08-18 06:37:38 --> Helper loaded: my_helper
INFO - 2023-08-18 06:37:38 --> Database Driver Class Initialized
DEBUG - 2023-08-18 06:37:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-18 06:37:38 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-18 06:37:38 --> Controller Class Initialized
INFO - 2023-08-18 06:37:38 --> Config Class Initialized
INFO - 2023-08-18 06:37:38 --> Hooks Class Initialized
DEBUG - 2023-08-18 06:37:38 --> UTF-8 Support Enabled
INFO - 2023-08-18 06:37:38 --> Utf8 Class Initialized
INFO - 2023-08-18 06:37:38 --> URI Class Initialized
INFO - 2023-08-18 06:37:38 --> Router Class Initialized
INFO - 2023-08-18 06:37:38 --> Output Class Initialized
INFO - 2023-08-18 06:37:38 --> Security Class Initialized
DEBUG - 2023-08-18 06:37:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-18 06:37:38 --> Input Class Initialized
INFO - 2023-08-18 06:37:38 --> Language Class Initialized
INFO - 2023-08-18 06:37:38 --> Language Class Initialized
INFO - 2023-08-18 06:37:38 --> Config Class Initialized
INFO - 2023-08-18 06:37:38 --> Loader Class Initialized
INFO - 2023-08-18 06:37:38 --> Helper loaded: url_helper
INFO - 2023-08-18 06:37:38 --> Helper loaded: file_helper
INFO - 2023-08-18 06:37:38 --> Helper loaded: form_helper
INFO - 2023-08-18 06:37:38 --> Helper loaded: my_helper
INFO - 2023-08-18 06:37:38 --> Database Driver Class Initialized
DEBUG - 2023-08-18 06:37:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-18 06:37:38 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-18 06:37:38 --> Controller Class Initialized
DEBUG - 2023-08-18 06:37:38 --> File loaded: C:\xampp\htdocs\myraportk13\bintaro\secondary\application\modules/login/views/login.php
DEBUG - 2023-08-18 06:37:38 --> File loaded: C:\xampp\htdocs\myraportk13\bintaro\secondary\application\views\template_utama.php
INFO - 2023-08-18 06:37:38 --> Final output sent to browser
DEBUG - 2023-08-18 06:37:38 --> Total execution time: 0.0469
INFO - 2023-08-18 06:37:42 --> Config Class Initialized
INFO - 2023-08-18 06:37:42 --> Hooks Class Initialized
DEBUG - 2023-08-18 06:37:42 --> UTF-8 Support Enabled
INFO - 2023-08-18 06:37:42 --> Utf8 Class Initialized
INFO - 2023-08-18 06:37:42 --> URI Class Initialized
INFO - 2023-08-18 06:37:42 --> Router Class Initialized
INFO - 2023-08-18 06:37:42 --> Output Class Initialized
INFO - 2023-08-18 06:37:42 --> Security Class Initialized
DEBUG - 2023-08-18 06:37:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-18 06:37:42 --> Input Class Initialized
INFO - 2023-08-18 06:37:42 --> Language Class Initialized
INFO - 2023-08-18 06:37:42 --> Language Class Initialized
INFO - 2023-08-18 06:37:42 --> Config Class Initialized
INFO - 2023-08-18 06:37:42 --> Loader Class Initialized
INFO - 2023-08-18 06:37:42 --> Helper loaded: url_helper
INFO - 2023-08-18 06:37:42 --> Helper loaded: file_helper
INFO - 2023-08-18 06:37:42 --> Helper loaded: form_helper
INFO - 2023-08-18 06:37:42 --> Helper loaded: my_helper
INFO - 2023-08-18 06:37:42 --> Database Driver Class Initialized
DEBUG - 2023-08-18 06:37:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-18 06:37:42 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-18 06:37:42 --> Controller Class Initialized
INFO - 2023-08-18 06:37:42 --> Helper loaded: cookie_helper
INFO - 2023-08-18 06:37:42 --> Final output sent to browser
DEBUG - 2023-08-18 06:37:42 --> Total execution time: 0.0661
INFO - 2023-08-18 06:37:42 --> Config Class Initialized
INFO - 2023-08-18 06:37:42 --> Hooks Class Initialized
DEBUG - 2023-08-18 06:37:42 --> UTF-8 Support Enabled
INFO - 2023-08-18 06:37:42 --> Utf8 Class Initialized
INFO - 2023-08-18 06:37:42 --> URI Class Initialized
INFO - 2023-08-18 06:37:42 --> Router Class Initialized
INFO - 2023-08-18 06:37:42 --> Output Class Initialized
INFO - 2023-08-18 06:37:42 --> Security Class Initialized
DEBUG - 2023-08-18 06:37:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-18 06:37:42 --> Input Class Initialized
INFO - 2023-08-18 06:37:42 --> Language Class Initialized
INFO - 2023-08-18 06:37:42 --> Language Class Initialized
INFO - 2023-08-18 06:37:42 --> Config Class Initialized
INFO - 2023-08-18 06:37:42 --> Loader Class Initialized
INFO - 2023-08-18 06:37:42 --> Helper loaded: url_helper
INFO - 2023-08-18 06:37:42 --> Helper loaded: file_helper
INFO - 2023-08-18 06:37:42 --> Helper loaded: form_helper
INFO - 2023-08-18 06:37:42 --> Helper loaded: my_helper
INFO - 2023-08-18 06:37:42 --> Database Driver Class Initialized
DEBUG - 2023-08-18 06:37:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-18 06:37:42 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-18 06:37:42 --> Controller Class Initialized
DEBUG - 2023-08-18 06:37:42 --> File loaded: C:\xampp\htdocs\myraportk13\bintaro\secondary\application\modules/home/views/v_home.php
DEBUG - 2023-08-18 06:37:42 --> File loaded: C:\xampp\htdocs\myraportk13\bintaro\secondary\application\views\template_utama.php
INFO - 2023-08-18 06:37:42 --> Final output sent to browser
DEBUG - 2023-08-18 06:37:42 --> Total execution time: 0.0466
INFO - 2023-08-18 06:37:44 --> Config Class Initialized
INFO - 2023-08-18 06:37:44 --> Hooks Class Initialized
DEBUG - 2023-08-18 06:37:44 --> UTF-8 Support Enabled
INFO - 2023-08-18 06:37:44 --> Utf8 Class Initialized
INFO - 2023-08-18 06:37:44 --> URI Class Initialized
INFO - 2023-08-18 06:37:44 --> Router Class Initialized
INFO - 2023-08-18 06:37:44 --> Output Class Initialized
INFO - 2023-08-18 06:37:44 --> Security Class Initialized
DEBUG - 2023-08-18 06:37:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-18 06:37:44 --> Input Class Initialized
INFO - 2023-08-18 06:37:44 --> Language Class Initialized
INFO - 2023-08-18 06:37:44 --> Language Class Initialized
INFO - 2023-08-18 06:37:44 --> Config Class Initialized
INFO - 2023-08-18 06:37:44 --> Loader Class Initialized
INFO - 2023-08-18 06:37:44 --> Helper loaded: url_helper
INFO - 2023-08-18 06:37:44 --> Helper loaded: file_helper
INFO - 2023-08-18 06:37:44 --> Helper loaded: form_helper
INFO - 2023-08-18 06:37:44 --> Helper loaded: my_helper
INFO - 2023-08-18 06:37:44 --> Database Driver Class Initialized
DEBUG - 2023-08-18 06:37:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-18 06:37:44 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-18 06:37:44 --> Controller Class Initialized
DEBUG - 2023-08-18 06:37:44 --> File loaded: C:\xampp\htdocs\myraportk13\bintaro\secondary\application\modules/data_guru/views/list.php
DEBUG - 2023-08-18 06:37:44 --> File loaded: C:\xampp\htdocs\myraportk13\bintaro\secondary\application\views\template_utama.php
INFO - 2023-08-18 06:37:44 --> Final output sent to browser
DEBUG - 2023-08-18 06:37:44 --> Total execution time: 0.0338
INFO - 2023-08-18 06:37:44 --> Config Class Initialized
INFO - 2023-08-18 06:37:44 --> Hooks Class Initialized
DEBUG - 2023-08-18 06:37:44 --> UTF-8 Support Enabled
INFO - 2023-08-18 06:37:44 --> Utf8 Class Initialized
INFO - 2023-08-18 06:37:44 --> URI Class Initialized
INFO - 2023-08-18 06:37:44 --> Router Class Initialized
INFO - 2023-08-18 06:37:44 --> Output Class Initialized
INFO - 2023-08-18 06:37:44 --> Security Class Initialized
DEBUG - 2023-08-18 06:37:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-18 06:37:44 --> Input Class Initialized
INFO - 2023-08-18 06:37:44 --> Language Class Initialized
INFO - 2023-08-18 06:37:44 --> Language Class Initialized
INFO - 2023-08-18 06:37:44 --> Config Class Initialized
INFO - 2023-08-18 06:37:44 --> Loader Class Initialized
INFO - 2023-08-18 06:37:44 --> Helper loaded: url_helper
INFO - 2023-08-18 06:37:44 --> Helper loaded: file_helper
INFO - 2023-08-18 06:37:44 --> Helper loaded: form_helper
INFO - 2023-08-18 06:37:44 --> Helper loaded: my_helper
INFO - 2023-08-18 06:37:44 --> Database Driver Class Initialized
DEBUG - 2023-08-18 06:37:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-18 06:37:44 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-18 06:37:44 --> Controller Class Initialized
INFO - 2023-08-18 06:37:46 --> Config Class Initialized
INFO - 2023-08-18 06:37:46 --> Hooks Class Initialized
DEBUG - 2023-08-18 06:37:46 --> UTF-8 Support Enabled
INFO - 2023-08-18 06:37:46 --> Utf8 Class Initialized
INFO - 2023-08-18 06:37:46 --> URI Class Initialized
INFO - 2023-08-18 06:37:46 --> Router Class Initialized
INFO - 2023-08-18 06:37:46 --> Output Class Initialized
INFO - 2023-08-18 06:37:46 --> Security Class Initialized
DEBUG - 2023-08-18 06:37:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-18 06:37:46 --> Input Class Initialized
INFO - 2023-08-18 06:37:46 --> Language Class Initialized
INFO - 2023-08-18 06:37:46 --> Language Class Initialized
INFO - 2023-08-18 06:37:46 --> Config Class Initialized
INFO - 2023-08-18 06:37:46 --> Loader Class Initialized
INFO - 2023-08-18 06:37:46 --> Helper loaded: url_helper
INFO - 2023-08-18 06:37:46 --> Helper loaded: file_helper
INFO - 2023-08-18 06:37:46 --> Helper loaded: form_helper
INFO - 2023-08-18 06:37:46 --> Helper loaded: my_helper
INFO - 2023-08-18 06:37:46 --> Database Driver Class Initialized
DEBUG - 2023-08-18 06:37:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-18 06:37:46 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-18 06:37:46 --> Controller Class Initialized
DEBUG - 2023-08-18 06:37:46 --> File loaded: C:\xampp\htdocs\myraportk13\bintaro\secondary\application\modules/data_kelas/views/list.php
DEBUG - 2023-08-18 06:37:46 --> File loaded: C:\xampp\htdocs\myraportk13\bintaro\secondary\application\views\template_utama.php
INFO - 2023-08-18 06:37:46 --> Final output sent to browser
DEBUG - 2023-08-18 06:37:46 --> Total execution time: 0.0334
INFO - 2023-08-18 06:37:46 --> Config Class Initialized
INFO - 2023-08-18 06:37:46 --> Hooks Class Initialized
DEBUG - 2023-08-18 06:37:46 --> UTF-8 Support Enabled
INFO - 2023-08-18 06:37:46 --> Utf8 Class Initialized
INFO - 2023-08-18 06:37:46 --> URI Class Initialized
INFO - 2023-08-18 06:37:46 --> Router Class Initialized
INFO - 2023-08-18 06:37:46 --> Output Class Initialized
INFO - 2023-08-18 06:37:46 --> Security Class Initialized
DEBUG - 2023-08-18 06:37:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-18 06:37:46 --> Input Class Initialized
INFO - 2023-08-18 06:37:46 --> Language Class Initialized
INFO - 2023-08-18 06:37:46 --> Language Class Initialized
INFO - 2023-08-18 06:37:46 --> Config Class Initialized
INFO - 2023-08-18 06:37:46 --> Loader Class Initialized
INFO - 2023-08-18 06:37:46 --> Helper loaded: url_helper
INFO - 2023-08-18 06:37:46 --> Helper loaded: file_helper
INFO - 2023-08-18 06:37:46 --> Helper loaded: form_helper
INFO - 2023-08-18 06:37:46 --> Helper loaded: my_helper
INFO - 2023-08-18 06:37:46 --> Database Driver Class Initialized
DEBUG - 2023-08-18 06:37:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-18 06:37:46 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-18 06:37:46 --> Controller Class Initialized
INFO - 2023-08-18 06:38:07 --> Config Class Initialized
INFO - 2023-08-18 06:38:07 --> Hooks Class Initialized
DEBUG - 2023-08-18 06:38:07 --> UTF-8 Support Enabled
INFO - 2023-08-18 06:38:07 --> Utf8 Class Initialized
INFO - 2023-08-18 06:38:07 --> URI Class Initialized
INFO - 2023-08-18 06:38:07 --> Router Class Initialized
INFO - 2023-08-18 06:38:07 --> Output Class Initialized
INFO - 2023-08-18 06:38:07 --> Security Class Initialized
DEBUG - 2023-08-18 06:38:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-18 06:38:07 --> Input Class Initialized
INFO - 2023-08-18 06:38:07 --> Language Class Initialized
INFO - 2023-08-18 06:38:07 --> Language Class Initialized
INFO - 2023-08-18 06:38:07 --> Config Class Initialized
INFO - 2023-08-18 06:38:07 --> Loader Class Initialized
INFO - 2023-08-18 06:38:07 --> Helper loaded: url_helper
INFO - 2023-08-18 06:38:07 --> Helper loaded: file_helper
INFO - 2023-08-18 06:38:07 --> Helper loaded: form_helper
INFO - 2023-08-18 06:38:07 --> Helper loaded: my_helper
INFO - 2023-08-18 06:38:07 --> Database Driver Class Initialized
DEBUG - 2023-08-18 06:38:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-18 06:38:07 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-18 06:38:07 --> Controller Class Initialized
DEBUG - 2023-08-18 06:38:07 --> File loaded: C:\xampp\htdocs\myraportk13\bintaro\secondary\application\modules/data_kelas/views/list.php
DEBUG - 2023-08-18 06:38:07 --> File loaded: C:\xampp\htdocs\myraportk13\bintaro\secondary\application\views\template_utama.php
INFO - 2023-08-18 06:38:07 --> Final output sent to browser
DEBUG - 2023-08-18 06:38:07 --> Total execution time: 0.0312
INFO - 2023-08-18 06:38:07 --> Config Class Initialized
INFO - 2023-08-18 06:38:07 --> Hooks Class Initialized
DEBUG - 2023-08-18 06:38:07 --> UTF-8 Support Enabled
INFO - 2023-08-18 06:38:07 --> Utf8 Class Initialized
INFO - 2023-08-18 06:38:07 --> URI Class Initialized
INFO - 2023-08-18 06:38:07 --> Router Class Initialized
INFO - 2023-08-18 06:38:07 --> Output Class Initialized
INFO - 2023-08-18 06:38:07 --> Security Class Initialized
DEBUG - 2023-08-18 06:38:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-18 06:38:07 --> Input Class Initialized
INFO - 2023-08-18 06:38:07 --> Language Class Initialized
INFO - 2023-08-18 06:38:07 --> Language Class Initialized
INFO - 2023-08-18 06:38:07 --> Config Class Initialized
INFO - 2023-08-18 06:38:07 --> Loader Class Initialized
INFO - 2023-08-18 06:38:07 --> Helper loaded: url_helper
INFO - 2023-08-18 06:38:07 --> Helper loaded: file_helper
INFO - 2023-08-18 06:38:07 --> Helper loaded: form_helper
INFO - 2023-08-18 06:38:07 --> Helper loaded: my_helper
INFO - 2023-08-18 06:38:07 --> Database Driver Class Initialized
DEBUG - 2023-08-18 06:38:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-18 06:38:07 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-18 06:38:07 --> Controller Class Initialized
INFO - 2023-08-18 06:38:08 --> Config Class Initialized
INFO - 2023-08-18 06:38:08 --> Hooks Class Initialized
DEBUG - 2023-08-18 06:38:08 --> UTF-8 Support Enabled
INFO - 2023-08-18 06:38:08 --> Utf8 Class Initialized
INFO - 2023-08-18 06:38:08 --> URI Class Initialized
INFO - 2023-08-18 06:38:08 --> Router Class Initialized
INFO - 2023-08-18 06:38:08 --> Output Class Initialized
INFO - 2023-08-18 06:38:08 --> Security Class Initialized
DEBUG - 2023-08-18 06:38:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-18 06:38:08 --> Input Class Initialized
INFO - 2023-08-18 06:38:08 --> Language Class Initialized
INFO - 2023-08-18 06:38:08 --> Language Class Initialized
INFO - 2023-08-18 06:38:08 --> Config Class Initialized
INFO - 2023-08-18 06:38:08 --> Loader Class Initialized
INFO - 2023-08-18 06:38:08 --> Helper loaded: url_helper
INFO - 2023-08-18 06:38:08 --> Helper loaded: file_helper
INFO - 2023-08-18 06:38:08 --> Helper loaded: form_helper
INFO - 2023-08-18 06:38:08 --> Helper loaded: my_helper
INFO - 2023-08-18 06:38:08 --> Database Driver Class Initialized
DEBUG - 2023-08-18 06:38:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-18 06:38:08 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-18 06:38:08 --> Controller Class Initialized
DEBUG - 2023-08-18 06:38:08 --> File loaded: C:\xampp\htdocs\myraportk13\bintaro\secondary\application\modules/data_mapel/views/list.php
DEBUG - 2023-08-18 06:38:08 --> File loaded: C:\xampp\htdocs\myraportk13\bintaro\secondary\application\views\template_utama.php
INFO - 2023-08-18 06:38:08 --> Final output sent to browser
DEBUG - 2023-08-18 06:38:08 --> Total execution time: 0.0375
INFO - 2023-08-18 06:38:08 --> Config Class Initialized
INFO - 2023-08-18 06:38:08 --> Hooks Class Initialized
DEBUG - 2023-08-18 06:38:08 --> UTF-8 Support Enabled
INFO - 2023-08-18 06:38:08 --> Utf8 Class Initialized
INFO - 2023-08-18 06:38:08 --> URI Class Initialized
INFO - 2023-08-18 06:38:08 --> Router Class Initialized
INFO - 2023-08-18 06:38:08 --> Output Class Initialized
INFO - 2023-08-18 06:38:08 --> Security Class Initialized
DEBUG - 2023-08-18 06:38:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-18 06:38:08 --> Input Class Initialized
INFO - 2023-08-18 06:38:08 --> Language Class Initialized
INFO - 2023-08-18 06:38:08 --> Language Class Initialized
INFO - 2023-08-18 06:38:08 --> Config Class Initialized
INFO - 2023-08-18 06:38:08 --> Loader Class Initialized
INFO - 2023-08-18 06:38:08 --> Helper loaded: url_helper
INFO - 2023-08-18 06:38:08 --> Helper loaded: file_helper
INFO - 2023-08-18 06:38:08 --> Helper loaded: form_helper
INFO - 2023-08-18 06:38:08 --> Helper loaded: my_helper
INFO - 2023-08-18 06:38:08 --> Database Driver Class Initialized
DEBUG - 2023-08-18 06:38:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-18 06:38:08 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-18 06:38:08 --> Controller Class Initialized
INFO - 2023-08-18 06:39:38 --> Config Class Initialized
INFO - 2023-08-18 06:39:38 --> Hooks Class Initialized
DEBUG - 2023-08-18 06:39:38 --> UTF-8 Support Enabled
INFO - 2023-08-18 06:39:38 --> Utf8 Class Initialized
INFO - 2023-08-18 06:39:38 --> URI Class Initialized
INFO - 2023-08-18 06:39:38 --> Router Class Initialized
INFO - 2023-08-18 06:39:38 --> Output Class Initialized
INFO - 2023-08-18 06:39:38 --> Security Class Initialized
DEBUG - 2023-08-18 06:39:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-18 06:39:38 --> Input Class Initialized
INFO - 2023-08-18 06:39:38 --> Language Class Initialized
INFO - 2023-08-18 06:39:38 --> Language Class Initialized
INFO - 2023-08-18 06:39:38 --> Config Class Initialized
INFO - 2023-08-18 06:39:38 --> Loader Class Initialized
INFO - 2023-08-18 06:39:38 --> Helper loaded: url_helper
INFO - 2023-08-18 06:39:38 --> Helper loaded: file_helper
INFO - 2023-08-18 06:39:38 --> Helper loaded: form_helper
INFO - 2023-08-18 06:39:38 --> Helper loaded: my_helper
INFO - 2023-08-18 06:39:38 --> Database Driver Class Initialized
DEBUG - 2023-08-18 06:39:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-18 06:39:38 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-18 06:39:38 --> Controller Class Initialized
DEBUG - 2023-08-18 06:39:38 --> File loaded: C:\xampp\htdocs\myraportk13\bintaro\secondary\application\modules/data_mapel/views/list.php
DEBUG - 2023-08-18 06:39:38 --> File loaded: C:\xampp\htdocs\myraportk13\bintaro\secondary\application\views\template_utama.php
INFO - 2023-08-18 06:39:38 --> Final output sent to browser
DEBUG - 2023-08-18 06:39:38 --> Total execution time: 0.0738
INFO - 2023-08-18 06:39:38 --> Config Class Initialized
INFO - 2023-08-18 06:39:38 --> Hooks Class Initialized
DEBUG - 2023-08-18 06:39:38 --> UTF-8 Support Enabled
INFO - 2023-08-18 06:39:38 --> Utf8 Class Initialized
INFO - 2023-08-18 06:39:38 --> URI Class Initialized
INFO - 2023-08-18 06:39:38 --> Router Class Initialized
INFO - 2023-08-18 06:39:38 --> Output Class Initialized
INFO - 2023-08-18 06:39:38 --> Security Class Initialized
DEBUG - 2023-08-18 06:39:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-18 06:39:38 --> Input Class Initialized
INFO - 2023-08-18 06:39:38 --> Language Class Initialized
INFO - 2023-08-18 06:39:38 --> Language Class Initialized
INFO - 2023-08-18 06:39:38 --> Config Class Initialized
INFO - 2023-08-18 06:39:38 --> Loader Class Initialized
INFO - 2023-08-18 06:39:38 --> Helper loaded: url_helper
INFO - 2023-08-18 06:39:38 --> Helper loaded: file_helper
INFO - 2023-08-18 06:39:38 --> Helper loaded: form_helper
INFO - 2023-08-18 06:39:38 --> Helper loaded: my_helper
INFO - 2023-08-18 06:39:38 --> Database Driver Class Initialized
DEBUG - 2023-08-18 06:39:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-18 06:39:38 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-18 06:39:38 --> Controller Class Initialized
INFO - 2023-08-18 06:39:39 --> Config Class Initialized
INFO - 2023-08-18 06:39:39 --> Hooks Class Initialized
DEBUG - 2023-08-18 06:39:39 --> UTF-8 Support Enabled
INFO - 2023-08-18 06:39:39 --> Utf8 Class Initialized
INFO - 2023-08-18 06:39:39 --> URI Class Initialized
INFO - 2023-08-18 06:39:39 --> Router Class Initialized
INFO - 2023-08-18 06:39:39 --> Output Class Initialized
INFO - 2023-08-18 06:39:39 --> Security Class Initialized
DEBUG - 2023-08-18 06:39:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-18 06:39:39 --> Input Class Initialized
INFO - 2023-08-18 06:39:39 --> Language Class Initialized
INFO - 2023-08-18 06:39:39 --> Language Class Initialized
INFO - 2023-08-18 06:39:39 --> Config Class Initialized
INFO - 2023-08-18 06:39:39 --> Loader Class Initialized
INFO - 2023-08-18 06:39:39 --> Helper loaded: url_helper
INFO - 2023-08-18 06:39:39 --> Helper loaded: file_helper
INFO - 2023-08-18 06:39:39 --> Helper loaded: form_helper
INFO - 2023-08-18 06:39:39 --> Helper loaded: my_helper
INFO - 2023-08-18 06:39:39 --> Database Driver Class Initialized
DEBUG - 2023-08-18 06:39:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-18 06:39:39 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-18 06:39:39 --> Controller Class Initialized
INFO - 2023-08-18 06:39:39 --> Final output sent to browser
DEBUG - 2023-08-18 06:39:39 --> Total execution time: 0.0392
INFO - 2023-08-18 06:40:13 --> Config Class Initialized
INFO - 2023-08-18 06:40:13 --> Hooks Class Initialized
DEBUG - 2023-08-18 06:40:13 --> UTF-8 Support Enabled
INFO - 2023-08-18 06:40:13 --> Utf8 Class Initialized
INFO - 2023-08-18 06:40:13 --> URI Class Initialized
INFO - 2023-08-18 06:40:13 --> Router Class Initialized
INFO - 2023-08-18 06:40:13 --> Output Class Initialized
INFO - 2023-08-18 06:40:13 --> Security Class Initialized
DEBUG - 2023-08-18 06:40:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-18 06:40:13 --> Input Class Initialized
INFO - 2023-08-18 06:40:13 --> Language Class Initialized
INFO - 2023-08-18 06:40:13 --> Language Class Initialized
INFO - 2023-08-18 06:40:13 --> Config Class Initialized
INFO - 2023-08-18 06:40:13 --> Loader Class Initialized
INFO - 2023-08-18 06:40:13 --> Helper loaded: url_helper
INFO - 2023-08-18 06:40:13 --> Helper loaded: file_helper
INFO - 2023-08-18 06:40:13 --> Helper loaded: form_helper
INFO - 2023-08-18 06:40:13 --> Helper loaded: my_helper
INFO - 2023-08-18 06:40:13 --> Database Driver Class Initialized
DEBUG - 2023-08-18 06:40:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-18 06:40:13 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-18 06:40:13 --> Controller Class Initialized
DEBUG - 2023-08-18 06:40:13 --> File loaded: C:\xampp\htdocs\myraportk13\bintaro\secondary\application\modules/data_mapel/views/list.php
DEBUG - 2023-08-18 06:40:13 --> File loaded: C:\xampp\htdocs\myraportk13\bintaro\secondary\application\views\template_utama.php
INFO - 2023-08-18 06:40:13 --> Final output sent to browser
DEBUG - 2023-08-18 06:40:13 --> Total execution time: 0.0660
INFO - 2023-08-18 06:40:13 --> Config Class Initialized
INFO - 2023-08-18 06:40:13 --> Hooks Class Initialized
DEBUG - 2023-08-18 06:40:13 --> UTF-8 Support Enabled
INFO - 2023-08-18 06:40:13 --> Utf8 Class Initialized
INFO - 2023-08-18 06:40:13 --> URI Class Initialized
INFO - 2023-08-18 06:40:13 --> Router Class Initialized
INFO - 2023-08-18 06:40:13 --> Output Class Initialized
INFO - 2023-08-18 06:40:13 --> Security Class Initialized
DEBUG - 2023-08-18 06:40:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-18 06:40:13 --> Input Class Initialized
INFO - 2023-08-18 06:40:13 --> Language Class Initialized
INFO - 2023-08-18 06:40:13 --> Language Class Initialized
INFO - 2023-08-18 06:40:13 --> Config Class Initialized
INFO - 2023-08-18 06:40:13 --> Loader Class Initialized
INFO - 2023-08-18 06:40:13 --> Helper loaded: url_helper
INFO - 2023-08-18 06:40:13 --> Helper loaded: file_helper
INFO - 2023-08-18 06:40:13 --> Helper loaded: form_helper
INFO - 2023-08-18 06:40:13 --> Helper loaded: my_helper
INFO - 2023-08-18 06:40:13 --> Database Driver Class Initialized
DEBUG - 2023-08-18 06:40:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-18 06:40:13 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-18 06:40:13 --> Controller Class Initialized
INFO - 2023-08-18 06:40:14 --> Config Class Initialized
INFO - 2023-08-18 06:40:14 --> Hooks Class Initialized
DEBUG - 2023-08-18 06:40:14 --> UTF-8 Support Enabled
INFO - 2023-08-18 06:40:14 --> Utf8 Class Initialized
INFO - 2023-08-18 06:40:14 --> URI Class Initialized
INFO - 2023-08-18 06:40:14 --> Router Class Initialized
INFO - 2023-08-18 06:40:14 --> Output Class Initialized
INFO - 2023-08-18 06:40:14 --> Security Class Initialized
DEBUG - 2023-08-18 06:40:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-18 06:40:14 --> Input Class Initialized
INFO - 2023-08-18 06:40:14 --> Language Class Initialized
INFO - 2023-08-18 06:40:14 --> Language Class Initialized
INFO - 2023-08-18 06:40:14 --> Config Class Initialized
INFO - 2023-08-18 06:40:14 --> Loader Class Initialized
INFO - 2023-08-18 06:40:14 --> Helper loaded: url_helper
INFO - 2023-08-18 06:40:14 --> Helper loaded: file_helper
INFO - 2023-08-18 06:40:14 --> Helper loaded: form_helper
INFO - 2023-08-18 06:40:14 --> Helper loaded: my_helper
INFO - 2023-08-18 06:40:14 --> Database Driver Class Initialized
DEBUG - 2023-08-18 06:40:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-18 06:40:14 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-18 06:40:14 --> Controller Class Initialized
INFO - 2023-08-18 06:40:14 --> Final output sent to browser
DEBUG - 2023-08-18 06:40:14 --> Total execution time: 0.0338
INFO - 2023-08-18 06:40:29 --> Config Class Initialized
INFO - 2023-08-18 06:40:29 --> Hooks Class Initialized
DEBUG - 2023-08-18 06:40:29 --> UTF-8 Support Enabled
INFO - 2023-08-18 06:40:29 --> Utf8 Class Initialized
INFO - 2023-08-18 06:40:29 --> URI Class Initialized
INFO - 2023-08-18 06:40:29 --> Router Class Initialized
INFO - 2023-08-18 06:40:29 --> Output Class Initialized
INFO - 2023-08-18 06:40:29 --> Security Class Initialized
DEBUG - 2023-08-18 06:40:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-18 06:40:29 --> Input Class Initialized
INFO - 2023-08-18 06:40:29 --> Language Class Initialized
INFO - 2023-08-18 06:40:29 --> Language Class Initialized
INFO - 2023-08-18 06:40:29 --> Config Class Initialized
INFO - 2023-08-18 06:40:29 --> Loader Class Initialized
INFO - 2023-08-18 06:40:29 --> Helper loaded: url_helper
INFO - 2023-08-18 06:40:29 --> Helper loaded: file_helper
INFO - 2023-08-18 06:40:29 --> Helper loaded: form_helper
INFO - 2023-08-18 06:40:29 --> Helper loaded: my_helper
INFO - 2023-08-18 06:40:29 --> Database Driver Class Initialized
DEBUG - 2023-08-18 06:40:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-18 06:40:29 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-18 06:40:29 --> Controller Class Initialized
INFO - 2023-08-18 06:40:29 --> Helper loaded: cookie_helper
INFO - 2023-08-18 06:40:29 --> Config Class Initialized
INFO - 2023-08-18 06:40:29 --> Hooks Class Initialized
DEBUG - 2023-08-18 06:40:29 --> UTF-8 Support Enabled
INFO - 2023-08-18 06:40:29 --> Utf8 Class Initialized
INFO - 2023-08-18 06:40:29 --> URI Class Initialized
INFO - 2023-08-18 06:40:29 --> Router Class Initialized
INFO - 2023-08-18 06:40:29 --> Output Class Initialized
INFO - 2023-08-18 06:40:29 --> Security Class Initialized
DEBUG - 2023-08-18 06:40:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-18 06:40:29 --> Input Class Initialized
INFO - 2023-08-18 06:40:29 --> Language Class Initialized
INFO - 2023-08-18 06:40:29 --> Language Class Initialized
INFO - 2023-08-18 06:40:29 --> Config Class Initialized
INFO - 2023-08-18 06:40:29 --> Loader Class Initialized
INFO - 2023-08-18 06:40:29 --> Helper loaded: url_helper
INFO - 2023-08-18 06:40:29 --> Helper loaded: file_helper
INFO - 2023-08-18 06:40:29 --> Helper loaded: form_helper
INFO - 2023-08-18 06:40:29 --> Helper loaded: my_helper
INFO - 2023-08-18 06:40:29 --> Database Driver Class Initialized
DEBUG - 2023-08-18 06:40:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-18 06:40:29 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-18 06:40:29 --> Controller Class Initialized
INFO - 2023-08-18 06:40:29 --> Config Class Initialized
INFO - 2023-08-18 06:40:29 --> Hooks Class Initialized
DEBUG - 2023-08-18 06:40:29 --> UTF-8 Support Enabled
INFO - 2023-08-18 06:40:29 --> Utf8 Class Initialized
INFO - 2023-08-18 06:40:29 --> URI Class Initialized
INFO - 2023-08-18 06:40:29 --> Router Class Initialized
INFO - 2023-08-18 06:40:29 --> Output Class Initialized
INFO - 2023-08-18 06:40:29 --> Security Class Initialized
DEBUG - 2023-08-18 06:40:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-18 06:40:29 --> Input Class Initialized
INFO - 2023-08-18 06:40:29 --> Language Class Initialized
INFO - 2023-08-18 06:40:29 --> Language Class Initialized
INFO - 2023-08-18 06:40:29 --> Config Class Initialized
INFO - 2023-08-18 06:40:29 --> Loader Class Initialized
INFO - 2023-08-18 06:40:29 --> Helper loaded: url_helper
INFO - 2023-08-18 06:40:29 --> Helper loaded: file_helper
INFO - 2023-08-18 06:40:29 --> Helper loaded: form_helper
INFO - 2023-08-18 06:40:29 --> Helper loaded: my_helper
INFO - 2023-08-18 06:40:29 --> Database Driver Class Initialized
DEBUG - 2023-08-18 06:40:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-18 06:40:29 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-18 06:40:29 --> Controller Class Initialized
DEBUG - 2023-08-18 06:40:29 --> File loaded: C:\xampp\htdocs\myraportk13\bintaro\secondary\application\modules/login/views/login.php
DEBUG - 2023-08-18 06:40:29 --> File loaded: C:\xampp\htdocs\myraportk13\bintaro\secondary\application\views\template_utama.php
INFO - 2023-08-18 06:40:29 --> Final output sent to browser
DEBUG - 2023-08-18 06:40:29 --> Total execution time: 0.0242
INFO - 2023-08-18 06:40:36 --> Config Class Initialized
INFO - 2023-08-18 06:40:36 --> Hooks Class Initialized
DEBUG - 2023-08-18 06:40:36 --> UTF-8 Support Enabled
INFO - 2023-08-18 06:40:36 --> Utf8 Class Initialized
INFO - 2023-08-18 06:40:36 --> URI Class Initialized
INFO - 2023-08-18 06:40:36 --> Router Class Initialized
INFO - 2023-08-18 06:40:36 --> Output Class Initialized
INFO - 2023-08-18 06:40:36 --> Security Class Initialized
DEBUG - 2023-08-18 06:40:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-18 06:40:36 --> Input Class Initialized
INFO - 2023-08-18 06:40:36 --> Language Class Initialized
INFO - 2023-08-18 06:40:36 --> Language Class Initialized
INFO - 2023-08-18 06:40:36 --> Config Class Initialized
INFO - 2023-08-18 06:40:36 --> Loader Class Initialized
INFO - 2023-08-18 06:40:36 --> Helper loaded: url_helper
INFO - 2023-08-18 06:40:36 --> Helper loaded: file_helper
INFO - 2023-08-18 06:40:36 --> Helper loaded: form_helper
INFO - 2023-08-18 06:40:36 --> Helper loaded: my_helper
INFO - 2023-08-18 06:40:36 --> Database Driver Class Initialized
DEBUG - 2023-08-18 06:40:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-18 06:40:36 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-18 06:40:36 --> Controller Class Initialized
INFO - 2023-08-18 06:40:36 --> Helper loaded: cookie_helper
INFO - 2023-08-18 06:40:36 --> Final output sent to browser
DEBUG - 2023-08-18 06:40:36 --> Total execution time: 0.0335
INFO - 2023-08-18 06:40:36 --> Config Class Initialized
INFO - 2023-08-18 06:40:36 --> Hooks Class Initialized
DEBUG - 2023-08-18 06:40:36 --> UTF-8 Support Enabled
INFO - 2023-08-18 06:40:36 --> Utf8 Class Initialized
INFO - 2023-08-18 06:40:36 --> URI Class Initialized
INFO - 2023-08-18 06:40:36 --> Router Class Initialized
INFO - 2023-08-18 06:40:36 --> Output Class Initialized
INFO - 2023-08-18 06:40:36 --> Security Class Initialized
DEBUG - 2023-08-18 06:40:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-18 06:40:36 --> Input Class Initialized
INFO - 2023-08-18 06:40:36 --> Language Class Initialized
INFO - 2023-08-18 06:40:36 --> Language Class Initialized
INFO - 2023-08-18 06:40:36 --> Config Class Initialized
INFO - 2023-08-18 06:40:36 --> Loader Class Initialized
INFO - 2023-08-18 06:40:36 --> Helper loaded: url_helper
INFO - 2023-08-18 06:40:36 --> Helper loaded: file_helper
INFO - 2023-08-18 06:40:36 --> Helper loaded: form_helper
INFO - 2023-08-18 06:40:37 --> Helper loaded: my_helper
INFO - 2023-08-18 06:40:37 --> Database Driver Class Initialized
DEBUG - 2023-08-18 06:40:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-18 06:40:37 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-18 06:40:37 --> Controller Class Initialized
DEBUG - 2023-08-18 06:40:37 --> File loaded: C:\xampp\htdocs\myraportk13\bintaro\secondary\application\modules/home/views/v_home_guru.php
DEBUG - 2023-08-18 06:40:37 --> File loaded: C:\xampp\htdocs\myraportk13\bintaro\secondary\application\views\template_utama.php
INFO - 2023-08-18 06:40:37 --> Final output sent to browser
DEBUG - 2023-08-18 06:40:37 --> Total execution time: 0.0390
INFO - 2023-08-18 06:40:39 --> Config Class Initialized
INFO - 2023-08-18 06:40:39 --> Hooks Class Initialized
DEBUG - 2023-08-18 06:40:39 --> UTF-8 Support Enabled
INFO - 2023-08-18 06:40:39 --> Utf8 Class Initialized
INFO - 2023-08-18 06:40:39 --> URI Class Initialized
INFO - 2023-08-18 06:40:39 --> Router Class Initialized
INFO - 2023-08-18 06:40:39 --> Output Class Initialized
INFO - 2023-08-18 06:40:39 --> Security Class Initialized
DEBUG - 2023-08-18 06:40:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-18 06:40:39 --> Input Class Initialized
INFO - 2023-08-18 06:40:39 --> Language Class Initialized
INFO - 2023-08-18 06:40:39 --> Language Class Initialized
INFO - 2023-08-18 06:40:39 --> Config Class Initialized
INFO - 2023-08-18 06:40:39 --> Loader Class Initialized
INFO - 2023-08-18 06:40:39 --> Helper loaded: url_helper
INFO - 2023-08-18 06:40:39 --> Helper loaded: file_helper
INFO - 2023-08-18 06:40:39 --> Helper loaded: form_helper
INFO - 2023-08-18 06:40:39 --> Helper loaded: my_helper
INFO - 2023-08-18 06:40:39 --> Database Driver Class Initialized
DEBUG - 2023-08-18 06:40:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-18 06:40:39 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-18 06:40:39 --> Controller Class Initialized
DEBUG - 2023-08-18 06:40:39 --> File loaded: C:\xampp\htdocs\myraportk13\bintaro\secondary\application\modules/cetak_raport_pts/views/list.php
DEBUG - 2023-08-18 06:40:39 --> File loaded: C:\xampp\htdocs\myraportk13\bintaro\secondary\application\views\template_utama.php
INFO - 2023-08-18 06:40:39 --> Final output sent to browser
DEBUG - 2023-08-18 06:40:39 --> Total execution time: 0.0360
INFO - 2023-08-18 06:40:41 --> Config Class Initialized
INFO - 2023-08-18 06:40:41 --> Hooks Class Initialized
DEBUG - 2023-08-18 06:40:41 --> UTF-8 Support Enabled
INFO - 2023-08-18 06:40:41 --> Utf8 Class Initialized
INFO - 2023-08-18 06:40:41 --> URI Class Initialized
INFO - 2023-08-18 06:40:41 --> Router Class Initialized
INFO - 2023-08-18 06:40:41 --> Output Class Initialized
INFO - 2023-08-18 06:40:41 --> Security Class Initialized
DEBUG - 2023-08-18 06:40:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-18 06:40:41 --> Input Class Initialized
INFO - 2023-08-18 06:40:41 --> Language Class Initialized
INFO - 2023-08-18 06:40:41 --> Language Class Initialized
INFO - 2023-08-18 06:40:41 --> Config Class Initialized
INFO - 2023-08-18 06:40:41 --> Loader Class Initialized
INFO - 2023-08-18 06:40:41 --> Helper loaded: url_helper
INFO - 2023-08-18 06:40:41 --> Helper loaded: file_helper
INFO - 2023-08-18 06:40:41 --> Helper loaded: form_helper
INFO - 2023-08-18 06:40:41 --> Helper loaded: my_helper
INFO - 2023-08-18 06:40:41 --> Database Driver Class Initialized
DEBUG - 2023-08-18 06:40:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-18 06:40:41 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-18 06:40:41 --> Controller Class Initialized
DEBUG - 2023-08-18 06:40:41 --> File loaded: C:\xampp\htdocs\myraportk13\bintaro\secondary\application\modules/cetak_raport_pts/views/cetak_pts_mh.php
INFO - 2023-08-18 06:40:42 --> Final output sent to browser
DEBUG - 2023-08-18 06:40:42 --> Total execution time: 1.0827
INFO - 2023-08-18 06:45:22 --> Config Class Initialized
INFO - 2023-08-18 06:45:22 --> Hooks Class Initialized
DEBUG - 2023-08-18 06:45:22 --> UTF-8 Support Enabled
INFO - 2023-08-18 06:45:22 --> Utf8 Class Initialized
INFO - 2023-08-18 06:45:22 --> URI Class Initialized
INFO - 2023-08-18 06:45:22 --> Router Class Initialized
INFO - 2023-08-18 06:45:22 --> Output Class Initialized
INFO - 2023-08-18 06:45:22 --> Security Class Initialized
DEBUG - 2023-08-18 06:45:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-18 06:45:22 --> Input Class Initialized
INFO - 2023-08-18 06:45:22 --> Language Class Initialized
INFO - 2023-08-18 06:45:22 --> Language Class Initialized
INFO - 2023-08-18 06:45:22 --> Config Class Initialized
INFO - 2023-08-18 06:45:22 --> Loader Class Initialized
INFO - 2023-08-18 06:45:22 --> Helper loaded: url_helper
INFO - 2023-08-18 06:45:22 --> Helper loaded: file_helper
INFO - 2023-08-18 06:45:22 --> Helper loaded: form_helper
INFO - 2023-08-18 06:45:22 --> Helper loaded: my_helper
INFO - 2023-08-18 06:45:22 --> Database Driver Class Initialized
DEBUG - 2023-08-18 06:45:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-18 06:45:22 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-18 06:45:22 --> Controller Class Initialized
DEBUG - 2023-08-18 06:45:22 --> File loaded: C:\xampp\htdocs\myraportk13\bintaro\secondary\application\modules/cetak_raport_pts/views/cetak_pts_mh.php
INFO - 2023-08-18 06:45:23 --> Final output sent to browser
DEBUG - 2023-08-18 06:45:23 --> Total execution time: 1.0519
INFO - 2023-08-18 06:56:27 --> Config Class Initialized
INFO - 2023-08-18 06:56:27 --> Hooks Class Initialized
DEBUG - 2023-08-18 06:56:27 --> UTF-8 Support Enabled
INFO - 2023-08-18 06:56:27 --> Utf8 Class Initialized
INFO - 2023-08-18 06:56:27 --> URI Class Initialized
INFO - 2023-08-18 06:56:27 --> Router Class Initialized
INFO - 2023-08-18 06:56:27 --> Output Class Initialized
INFO - 2023-08-18 06:56:27 --> Security Class Initialized
DEBUG - 2023-08-18 06:56:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-18 06:56:27 --> Input Class Initialized
INFO - 2023-08-18 06:56:27 --> Language Class Initialized
INFO - 2023-08-18 06:56:27 --> Language Class Initialized
INFO - 2023-08-18 06:56:27 --> Config Class Initialized
INFO - 2023-08-18 06:56:27 --> Loader Class Initialized
INFO - 2023-08-18 06:56:27 --> Helper loaded: url_helper
INFO - 2023-08-18 06:56:27 --> Helper loaded: file_helper
INFO - 2023-08-18 06:56:27 --> Helper loaded: form_helper
INFO - 2023-08-18 06:56:27 --> Helper loaded: my_helper
INFO - 2023-08-18 06:56:27 --> Database Driver Class Initialized
DEBUG - 2023-08-18 06:56:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-18 06:56:27 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-18 06:56:27 --> Controller Class Initialized
INFO - 2023-08-18 06:56:27 --> Helper loaded: cookie_helper
INFO - 2023-08-18 06:56:27 --> Config Class Initialized
INFO - 2023-08-18 06:56:27 --> Hooks Class Initialized
DEBUG - 2023-08-18 06:56:27 --> UTF-8 Support Enabled
INFO - 2023-08-18 06:56:27 --> Utf8 Class Initialized
INFO - 2023-08-18 06:56:27 --> URI Class Initialized
INFO - 2023-08-18 06:56:27 --> Router Class Initialized
INFO - 2023-08-18 06:56:27 --> Output Class Initialized
INFO - 2023-08-18 06:56:27 --> Security Class Initialized
DEBUG - 2023-08-18 06:56:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-18 06:56:27 --> Input Class Initialized
INFO - 2023-08-18 06:56:27 --> Language Class Initialized
INFO - 2023-08-18 06:56:27 --> Language Class Initialized
INFO - 2023-08-18 06:56:27 --> Config Class Initialized
INFO - 2023-08-18 06:56:27 --> Loader Class Initialized
INFO - 2023-08-18 06:56:27 --> Helper loaded: url_helper
INFO - 2023-08-18 06:56:27 --> Helper loaded: file_helper
INFO - 2023-08-18 06:56:27 --> Helper loaded: form_helper
INFO - 2023-08-18 06:56:27 --> Helper loaded: my_helper
INFO - 2023-08-18 06:56:27 --> Database Driver Class Initialized
DEBUG - 2023-08-18 06:56:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-18 06:56:27 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-18 06:56:27 --> Controller Class Initialized
INFO - 2023-08-18 06:56:27 --> Config Class Initialized
INFO - 2023-08-18 06:56:27 --> Hooks Class Initialized
DEBUG - 2023-08-18 06:56:27 --> UTF-8 Support Enabled
INFO - 2023-08-18 06:56:27 --> Utf8 Class Initialized
INFO - 2023-08-18 06:56:27 --> URI Class Initialized
INFO - 2023-08-18 06:56:27 --> Router Class Initialized
INFO - 2023-08-18 06:56:27 --> Output Class Initialized
INFO - 2023-08-18 06:56:27 --> Security Class Initialized
DEBUG - 2023-08-18 06:56:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-18 06:56:27 --> Input Class Initialized
INFO - 2023-08-18 06:56:27 --> Language Class Initialized
INFO - 2023-08-18 06:56:27 --> Language Class Initialized
INFO - 2023-08-18 06:56:27 --> Config Class Initialized
INFO - 2023-08-18 06:56:27 --> Loader Class Initialized
INFO - 2023-08-18 06:56:27 --> Helper loaded: url_helper
INFO - 2023-08-18 06:56:27 --> Helper loaded: file_helper
INFO - 2023-08-18 06:56:27 --> Helper loaded: form_helper
INFO - 2023-08-18 06:56:27 --> Helper loaded: my_helper
INFO - 2023-08-18 06:56:27 --> Database Driver Class Initialized
DEBUG - 2023-08-18 06:56:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-18 06:56:27 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-18 06:56:27 --> Controller Class Initialized
DEBUG - 2023-08-18 06:56:27 --> File loaded: C:\xampp\htdocs\myraportk13\bintaro\secondary\application\modules/login/views/login.php
DEBUG - 2023-08-18 06:56:27 --> File loaded: C:\xampp\htdocs\myraportk13\bintaro\secondary\application\views\template_utama.php
INFO - 2023-08-18 06:56:27 --> Final output sent to browser
DEBUG - 2023-08-18 06:56:27 --> Total execution time: 0.0257
INFO - 2023-08-18 10:18:34 --> Config Class Initialized
INFO - 2023-08-18 10:18:34 --> Hooks Class Initialized
DEBUG - 2023-08-18 10:18:34 --> UTF-8 Support Enabled
INFO - 2023-08-18 10:18:34 --> Utf8 Class Initialized
INFO - 2023-08-18 10:18:34 --> URI Class Initialized
DEBUG - 2023-08-18 10:18:34 --> No URI present. Default controller set.
INFO - 2023-08-18 10:18:34 --> Router Class Initialized
INFO - 2023-08-18 10:18:34 --> Output Class Initialized
INFO - 2023-08-18 10:18:34 --> Security Class Initialized
DEBUG - 2023-08-18 10:18:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-18 10:18:34 --> Input Class Initialized
INFO - 2023-08-18 10:18:34 --> Language Class Initialized
INFO - 2023-08-18 10:18:34 --> Language Class Initialized
INFO - 2023-08-18 10:18:34 --> Config Class Initialized
INFO - 2023-08-18 10:18:34 --> Loader Class Initialized
INFO - 2023-08-18 10:18:34 --> Helper loaded: url_helper
INFO - 2023-08-18 10:18:34 --> Helper loaded: file_helper
INFO - 2023-08-18 10:18:34 --> Helper loaded: form_helper
INFO - 2023-08-18 10:18:34 --> Helper loaded: my_helper
INFO - 2023-08-18 10:18:34 --> Database Driver Class Initialized
DEBUG - 2023-08-18 10:18:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-18 10:18:34 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-18 10:18:34 --> Controller Class Initialized
INFO - 2023-08-18 10:18:34 --> Config Class Initialized
INFO - 2023-08-18 10:18:34 --> Hooks Class Initialized
DEBUG - 2023-08-18 10:18:34 --> UTF-8 Support Enabled
INFO - 2023-08-18 10:18:34 --> Utf8 Class Initialized
INFO - 2023-08-18 10:18:34 --> URI Class Initialized
INFO - 2023-08-18 10:18:34 --> Router Class Initialized
INFO - 2023-08-18 10:18:34 --> Output Class Initialized
INFO - 2023-08-18 10:18:34 --> Security Class Initialized
DEBUG - 2023-08-18 10:18:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-18 10:18:34 --> Input Class Initialized
INFO - 2023-08-18 10:18:34 --> Language Class Initialized
INFO - 2023-08-18 10:18:34 --> Language Class Initialized
INFO - 2023-08-18 10:18:34 --> Config Class Initialized
INFO - 2023-08-18 10:18:34 --> Loader Class Initialized
INFO - 2023-08-18 10:18:34 --> Helper loaded: url_helper
INFO - 2023-08-18 10:18:34 --> Helper loaded: file_helper
INFO - 2023-08-18 10:18:34 --> Helper loaded: form_helper
INFO - 2023-08-18 10:18:34 --> Helper loaded: my_helper
INFO - 2023-08-18 10:18:34 --> Database Driver Class Initialized
DEBUG - 2023-08-18 10:18:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-18 10:18:34 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-18 10:18:34 --> Controller Class Initialized
DEBUG - 2023-08-18 10:18:34 --> File loaded: C:\xampp\htdocs\myraportk13\bintaro\secondary\application\modules/login/views/login.php
DEBUG - 2023-08-18 10:18:34 --> File loaded: C:\xampp\htdocs\myraportk13\bintaro\secondary\application\views\template_utama.php
INFO - 2023-08-18 10:18:34 --> Final output sent to browser
DEBUG - 2023-08-18 10:18:34 --> Total execution time: 0.0270
INFO - 2023-08-18 10:18:39 --> Config Class Initialized
INFO - 2023-08-18 10:18:39 --> Hooks Class Initialized
DEBUG - 2023-08-18 10:18:39 --> UTF-8 Support Enabled
INFO - 2023-08-18 10:18:39 --> Utf8 Class Initialized
INFO - 2023-08-18 10:18:39 --> URI Class Initialized
INFO - 2023-08-18 10:18:39 --> Router Class Initialized
INFO - 2023-08-18 10:18:39 --> Output Class Initialized
INFO - 2023-08-18 10:18:39 --> Security Class Initialized
DEBUG - 2023-08-18 10:18:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-18 10:18:39 --> Input Class Initialized
INFO - 2023-08-18 10:18:39 --> Language Class Initialized
INFO - 2023-08-18 10:18:39 --> Language Class Initialized
INFO - 2023-08-18 10:18:39 --> Config Class Initialized
INFO - 2023-08-18 10:18:39 --> Loader Class Initialized
INFO - 2023-08-18 10:18:39 --> Helper loaded: url_helper
INFO - 2023-08-18 10:18:39 --> Helper loaded: file_helper
INFO - 2023-08-18 10:18:39 --> Helper loaded: form_helper
INFO - 2023-08-18 10:18:39 --> Helper loaded: my_helper
INFO - 2023-08-18 10:18:39 --> Database Driver Class Initialized
DEBUG - 2023-08-18 10:18:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-18 10:18:39 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-18 10:18:39 --> Controller Class Initialized
INFO - 2023-08-18 10:18:39 --> Helper loaded: cookie_helper
INFO - 2023-08-18 10:18:39 --> Final output sent to browser
DEBUG - 2023-08-18 10:18:39 --> Total execution time: 0.0539
INFO - 2023-08-18 10:18:39 --> Config Class Initialized
INFO - 2023-08-18 10:18:39 --> Hooks Class Initialized
DEBUG - 2023-08-18 10:18:39 --> UTF-8 Support Enabled
INFO - 2023-08-18 10:18:39 --> Utf8 Class Initialized
INFO - 2023-08-18 10:18:39 --> URI Class Initialized
INFO - 2023-08-18 10:18:39 --> Router Class Initialized
INFO - 2023-08-18 10:18:39 --> Output Class Initialized
INFO - 2023-08-18 10:18:39 --> Security Class Initialized
DEBUG - 2023-08-18 10:18:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-18 10:18:39 --> Input Class Initialized
INFO - 2023-08-18 10:18:39 --> Language Class Initialized
INFO - 2023-08-18 10:18:39 --> Language Class Initialized
INFO - 2023-08-18 10:18:39 --> Config Class Initialized
INFO - 2023-08-18 10:18:39 --> Loader Class Initialized
INFO - 2023-08-18 10:18:39 --> Helper loaded: url_helper
INFO - 2023-08-18 10:18:39 --> Helper loaded: file_helper
INFO - 2023-08-18 10:18:39 --> Helper loaded: form_helper
INFO - 2023-08-18 10:18:39 --> Helper loaded: my_helper
INFO - 2023-08-18 10:18:39 --> Database Driver Class Initialized
DEBUG - 2023-08-18 10:18:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-18 10:18:39 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-18 10:18:39 --> Controller Class Initialized
DEBUG - 2023-08-18 10:18:39 --> File loaded: C:\xampp\htdocs\myraportk13\bintaro\secondary\application\modules/home/views/v_home_guru.php
DEBUG - 2023-08-18 10:18:39 --> File loaded: C:\xampp\htdocs\myraportk13\bintaro\secondary\application\views\template_utama.php
INFO - 2023-08-18 10:18:39 --> Final output sent to browser
DEBUG - 2023-08-18 10:18:39 --> Total execution time: 0.0372
INFO - 2023-08-18 10:18:42 --> Config Class Initialized
INFO - 2023-08-18 10:18:42 --> Hooks Class Initialized
DEBUG - 2023-08-18 10:18:42 --> UTF-8 Support Enabled
INFO - 2023-08-18 10:18:42 --> Utf8 Class Initialized
INFO - 2023-08-18 10:18:42 --> URI Class Initialized
INFO - 2023-08-18 10:18:42 --> Router Class Initialized
INFO - 2023-08-18 10:18:42 --> Output Class Initialized
INFO - 2023-08-18 10:18:42 --> Security Class Initialized
DEBUG - 2023-08-18 10:18:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-18 10:18:42 --> Input Class Initialized
INFO - 2023-08-18 10:18:42 --> Language Class Initialized
INFO - 2023-08-18 10:18:42 --> Language Class Initialized
INFO - 2023-08-18 10:18:42 --> Config Class Initialized
INFO - 2023-08-18 10:18:42 --> Loader Class Initialized
INFO - 2023-08-18 10:18:42 --> Helper loaded: url_helper
INFO - 2023-08-18 10:18:42 --> Helper loaded: file_helper
INFO - 2023-08-18 10:18:42 --> Helper loaded: form_helper
INFO - 2023-08-18 10:18:42 --> Helper loaded: my_helper
INFO - 2023-08-18 10:18:42 --> Database Driver Class Initialized
DEBUG - 2023-08-18 10:18:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-18 10:18:42 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-18 10:18:42 --> Controller Class Initialized
DEBUG - 2023-08-18 10:18:42 --> File loaded: C:\xampp\htdocs\myraportk13\bintaro\secondary\application\modules/cetak_raport_pts/views/list.php
DEBUG - 2023-08-18 10:18:42 --> File loaded: C:\xampp\htdocs\myraportk13\bintaro\secondary\application\views\template_utama.php
INFO - 2023-08-18 10:18:42 --> Final output sent to browser
DEBUG - 2023-08-18 10:18:42 --> Total execution time: 0.0501
INFO - 2023-08-18 10:18:43 --> Config Class Initialized
INFO - 2023-08-18 10:18:43 --> Hooks Class Initialized
DEBUG - 2023-08-18 10:18:43 --> UTF-8 Support Enabled
INFO - 2023-08-18 10:18:43 --> Utf8 Class Initialized
INFO - 2023-08-18 10:18:43 --> URI Class Initialized
INFO - 2023-08-18 10:18:43 --> Router Class Initialized
INFO - 2023-08-18 10:18:43 --> Output Class Initialized
INFO - 2023-08-18 10:18:43 --> Security Class Initialized
DEBUG - 2023-08-18 10:18:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-18 10:18:43 --> Input Class Initialized
INFO - 2023-08-18 10:18:43 --> Language Class Initialized
INFO - 2023-08-18 10:18:43 --> Language Class Initialized
INFO - 2023-08-18 10:18:43 --> Config Class Initialized
INFO - 2023-08-18 10:18:43 --> Loader Class Initialized
INFO - 2023-08-18 10:18:43 --> Helper loaded: url_helper
INFO - 2023-08-18 10:18:43 --> Helper loaded: file_helper
INFO - 2023-08-18 10:18:43 --> Helper loaded: form_helper
INFO - 2023-08-18 10:18:43 --> Helper loaded: my_helper
INFO - 2023-08-18 10:18:43 --> Database Driver Class Initialized
DEBUG - 2023-08-18 10:18:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-18 10:18:43 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-18 10:18:43 --> Controller Class Initialized
DEBUG - 2023-08-18 10:18:43 --> File loaded: C:\xampp\htdocs\myraportk13\bintaro\secondary\application\modules/cetak_raport_pts/views/cetak_pts_mh.php
INFO - 2023-08-18 10:18:44 --> Final output sent to browser
DEBUG - 2023-08-18 10:18:44 --> Total execution time: 1.0569
INFO - 2023-08-18 10:20:24 --> Config Class Initialized
INFO - 2023-08-18 10:20:24 --> Hooks Class Initialized
DEBUG - 2023-08-18 10:20:24 --> UTF-8 Support Enabled
INFO - 2023-08-18 10:20:24 --> Utf8 Class Initialized
INFO - 2023-08-18 10:20:24 --> URI Class Initialized
INFO - 2023-08-18 10:20:24 --> Router Class Initialized
INFO - 2023-08-18 10:20:24 --> Output Class Initialized
INFO - 2023-08-18 10:20:24 --> Security Class Initialized
DEBUG - 2023-08-18 10:20:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-18 10:20:24 --> Input Class Initialized
INFO - 2023-08-18 10:20:24 --> Language Class Initialized
INFO - 2023-08-18 10:20:24 --> Language Class Initialized
INFO - 2023-08-18 10:20:24 --> Config Class Initialized
INFO - 2023-08-18 10:20:24 --> Loader Class Initialized
INFO - 2023-08-18 10:20:24 --> Helper loaded: url_helper
INFO - 2023-08-18 10:20:24 --> Helper loaded: file_helper
INFO - 2023-08-18 10:20:24 --> Helper loaded: form_helper
INFO - 2023-08-18 10:20:24 --> Helper loaded: my_helper
INFO - 2023-08-18 10:20:24 --> Database Driver Class Initialized
DEBUG - 2023-08-18 10:20:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-18 10:20:24 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-18 10:20:24 --> Controller Class Initialized
DEBUG - 2023-08-18 10:20:24 --> File loaded: C:\xampp\htdocs\myraportk13\bintaro\secondary\application\modules/view_mapel/views/v_view_mapel.php
DEBUG - 2023-08-18 10:20:24 --> File loaded: C:\xampp\htdocs\myraportk13\bintaro\secondary\application\views\template_utama.php
INFO - 2023-08-18 10:20:24 --> Final output sent to browser
DEBUG - 2023-08-18 10:20:24 --> Total execution time: 0.0537
