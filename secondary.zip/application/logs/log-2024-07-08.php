<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2024-07-08 13:33:17 --> Config Class Initialized
INFO - 2024-07-08 13:33:17 --> Hooks Class Initialized
DEBUG - 2024-07-08 13:33:17 --> UTF-8 Support Enabled
INFO - 2024-07-08 13:33:17 --> Utf8 Class Initialized
INFO - 2024-07-08 13:33:17 --> URI Class Initialized
INFO - 2024-07-08 13:33:17 --> Router Class Initialized
INFO - 2024-07-08 13:33:17 --> Output Class Initialized
INFO - 2024-07-08 13:33:17 --> Security Class Initialized
DEBUG - 2024-07-08 13:33:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-07-08 13:33:17 --> Input Class Initialized
INFO - 2024-07-08 13:33:17 --> Language Class Initialized
INFO - 2024-07-08 13:33:17 --> Language Class Initialized
INFO - 2024-07-08 13:33:17 --> Config Class Initialized
INFO - 2024-07-08 13:33:17 --> Loader Class Initialized
INFO - 2024-07-08 13:33:17 --> Helper loaded: url_helper
INFO - 2024-07-08 13:33:17 --> Helper loaded: file_helper
INFO - 2024-07-08 13:33:17 --> Helper loaded: form_helper
INFO - 2024-07-08 13:33:17 --> Helper loaded: my_helper
INFO - 2024-07-08 13:33:17 --> Database Driver Class Initialized
INFO - 2024-07-08 13:33:17 --> Session: Class initialized using 'files' driver.
INFO - 2024-07-08 13:33:17 --> Controller Class Initialized
DEBUG - 2024-07-08 13:33:17 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/set_kelas/views/list.php
DEBUG - 2024-07-08 13:33:17 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-07-08 13:33:17 --> Final output sent to browser
DEBUG - 2024-07-08 13:33:17 --> Total execution time: 0.1058
INFO - 2024-07-08 13:33:20 --> Config Class Initialized
INFO - 2024-07-08 13:33:20 --> Hooks Class Initialized
DEBUG - 2024-07-08 13:33:20 --> UTF-8 Support Enabled
INFO - 2024-07-08 13:33:20 --> Utf8 Class Initialized
INFO - 2024-07-08 13:33:20 --> URI Class Initialized
INFO - 2024-07-08 13:33:20 --> Router Class Initialized
INFO - 2024-07-08 13:33:20 --> Output Class Initialized
INFO - 2024-07-08 13:33:20 --> Security Class Initialized
DEBUG - 2024-07-08 13:33:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-07-08 13:33:20 --> Input Class Initialized
INFO - 2024-07-08 13:33:20 --> Language Class Initialized
INFO - 2024-07-08 13:33:20 --> Language Class Initialized
INFO - 2024-07-08 13:33:20 --> Config Class Initialized
INFO - 2024-07-08 13:33:20 --> Loader Class Initialized
INFO - 2024-07-08 13:33:20 --> Helper loaded: url_helper
INFO - 2024-07-08 13:33:20 --> Helper loaded: file_helper
INFO - 2024-07-08 13:33:20 --> Helper loaded: form_helper
INFO - 2024-07-08 13:33:20 --> Helper loaded: my_helper
INFO - 2024-07-08 13:33:20 --> Database Driver Class Initialized
INFO - 2024-07-08 13:33:20 --> Session: Class initialized using 'files' driver.
INFO - 2024-07-08 13:33:20 --> Controller Class Initialized
DEBUG - 2024-07-08 13:33:20 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/tahun/views/list.php
DEBUG - 2024-07-08 13:33:20 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-07-08 13:33:20 --> Final output sent to browser
DEBUG - 2024-07-08 13:33:20 --> Total execution time: 0.0405
INFO - 2024-07-08 13:33:20 --> Config Class Initialized
INFO - 2024-07-08 13:33:20 --> Hooks Class Initialized
DEBUG - 2024-07-08 13:33:20 --> UTF-8 Support Enabled
INFO - 2024-07-08 13:33:20 --> Utf8 Class Initialized
INFO - 2024-07-08 13:33:20 --> URI Class Initialized
INFO - 2024-07-08 13:33:20 --> Router Class Initialized
INFO - 2024-07-08 13:33:20 --> Output Class Initialized
INFO - 2024-07-08 13:33:20 --> Security Class Initialized
DEBUG - 2024-07-08 13:33:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-07-08 13:33:20 --> Input Class Initialized
INFO - 2024-07-08 13:33:20 --> Language Class Initialized
ERROR - 2024-07-08 13:33:20 --> 404 Page Not Found: /index
INFO - 2024-07-08 13:33:20 --> Config Class Initialized
INFO - 2024-07-08 13:33:20 --> Hooks Class Initialized
DEBUG - 2024-07-08 13:33:20 --> UTF-8 Support Enabled
INFO - 2024-07-08 13:33:20 --> Utf8 Class Initialized
INFO - 2024-07-08 13:33:20 --> URI Class Initialized
INFO - 2024-07-08 13:33:20 --> Router Class Initialized
INFO - 2024-07-08 13:33:20 --> Output Class Initialized
INFO - 2024-07-08 13:33:20 --> Security Class Initialized
DEBUG - 2024-07-08 13:33:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-07-08 13:33:20 --> Input Class Initialized
INFO - 2024-07-08 13:33:20 --> Language Class Initialized
INFO - 2024-07-08 13:33:20 --> Language Class Initialized
INFO - 2024-07-08 13:33:20 --> Config Class Initialized
INFO - 2024-07-08 13:33:20 --> Loader Class Initialized
INFO - 2024-07-08 13:33:20 --> Helper loaded: url_helper
INFO - 2024-07-08 13:33:20 --> Helper loaded: file_helper
INFO - 2024-07-08 13:33:20 --> Helper loaded: form_helper
INFO - 2024-07-08 13:33:20 --> Helper loaded: my_helper
INFO - 2024-07-08 13:33:20 --> Database Driver Class Initialized
INFO - 2024-07-08 13:33:20 --> Session: Class initialized using 'files' driver.
INFO - 2024-07-08 13:33:20 --> Controller Class Initialized
INFO - 2024-07-08 13:36:23 --> Config Class Initialized
INFO - 2024-07-08 13:36:23 --> Hooks Class Initialized
DEBUG - 2024-07-08 13:36:23 --> UTF-8 Support Enabled
INFO - 2024-07-08 13:36:23 --> Utf8 Class Initialized
INFO - 2024-07-08 13:36:23 --> URI Class Initialized
INFO - 2024-07-08 13:36:23 --> Router Class Initialized
INFO - 2024-07-08 13:36:23 --> Output Class Initialized
INFO - 2024-07-08 13:36:23 --> Security Class Initialized
DEBUG - 2024-07-08 13:36:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-07-08 13:36:23 --> Input Class Initialized
INFO - 2024-07-08 13:36:23 --> Language Class Initialized
INFO - 2024-07-08 13:36:23 --> Language Class Initialized
INFO - 2024-07-08 13:36:23 --> Config Class Initialized
INFO - 2024-07-08 13:36:23 --> Loader Class Initialized
INFO - 2024-07-08 13:36:23 --> Helper loaded: url_helper
INFO - 2024-07-08 13:36:23 --> Helper loaded: file_helper
INFO - 2024-07-08 13:36:23 --> Helper loaded: form_helper
INFO - 2024-07-08 13:36:23 --> Helper loaded: my_helper
INFO - 2024-07-08 13:36:23 --> Database Driver Class Initialized
INFO - 2024-07-08 13:36:23 --> Session: Class initialized using 'files' driver.
INFO - 2024-07-08 13:36:23 --> Controller Class Initialized
DEBUG - 2024-07-08 13:36:23 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/set_kelas/views/list.php
DEBUG - 2024-07-08 13:36:23 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-07-08 13:36:23 --> Final output sent to browser
DEBUG - 2024-07-08 13:36:23 --> Total execution time: 0.0928
INFO - 2024-07-08 13:36:27 --> Config Class Initialized
INFO - 2024-07-08 13:36:27 --> Hooks Class Initialized
DEBUG - 2024-07-08 13:36:27 --> UTF-8 Support Enabled
INFO - 2024-07-08 13:36:27 --> Utf8 Class Initialized
INFO - 2024-07-08 13:36:27 --> URI Class Initialized
INFO - 2024-07-08 13:36:27 --> Router Class Initialized
INFO - 2024-07-08 13:36:27 --> Output Class Initialized
INFO - 2024-07-08 13:36:27 --> Security Class Initialized
DEBUG - 2024-07-08 13:36:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-07-08 13:36:27 --> Input Class Initialized
INFO - 2024-07-08 13:36:27 --> Language Class Initialized
INFO - 2024-07-08 13:36:27 --> Language Class Initialized
INFO - 2024-07-08 13:36:27 --> Config Class Initialized
INFO - 2024-07-08 13:36:27 --> Loader Class Initialized
INFO - 2024-07-08 13:36:27 --> Helper loaded: url_helper
INFO - 2024-07-08 13:36:27 --> Helper loaded: file_helper
INFO - 2024-07-08 13:36:27 --> Helper loaded: form_helper
INFO - 2024-07-08 13:36:27 --> Helper loaded: my_helper
INFO - 2024-07-08 13:36:27 --> Database Driver Class Initialized
INFO - 2024-07-08 13:36:27 --> Session: Class initialized using 'files' driver.
INFO - 2024-07-08 13:36:27 --> Controller Class Initialized
DEBUG - 2024-07-08 13:36:27 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/data_siswa/views/list.php
DEBUG - 2024-07-08 13:36:27 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-07-08 13:36:27 --> Final output sent to browser
DEBUG - 2024-07-08 13:36:27 --> Total execution time: 0.0419
INFO - 2024-07-08 13:36:27 --> Config Class Initialized
INFO - 2024-07-08 13:36:27 --> Hooks Class Initialized
DEBUG - 2024-07-08 13:36:27 --> UTF-8 Support Enabled
INFO - 2024-07-08 13:36:27 --> Utf8 Class Initialized
INFO - 2024-07-08 13:36:27 --> URI Class Initialized
INFO - 2024-07-08 13:36:27 --> Router Class Initialized
INFO - 2024-07-08 13:36:27 --> Output Class Initialized
INFO - 2024-07-08 13:36:27 --> Security Class Initialized
DEBUG - 2024-07-08 13:36:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-07-08 13:36:27 --> Input Class Initialized
INFO - 2024-07-08 13:36:27 --> Language Class Initialized
ERROR - 2024-07-08 13:36:27 --> 404 Page Not Found: /index
INFO - 2024-07-08 13:36:27 --> Config Class Initialized
INFO - 2024-07-08 13:36:27 --> Hooks Class Initialized
DEBUG - 2024-07-08 13:36:27 --> UTF-8 Support Enabled
INFO - 2024-07-08 13:36:27 --> Utf8 Class Initialized
INFO - 2024-07-08 13:36:27 --> URI Class Initialized
INFO - 2024-07-08 13:36:27 --> Router Class Initialized
INFO - 2024-07-08 13:36:27 --> Output Class Initialized
INFO - 2024-07-08 13:36:27 --> Security Class Initialized
DEBUG - 2024-07-08 13:36:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-07-08 13:36:27 --> Input Class Initialized
INFO - 2024-07-08 13:36:27 --> Language Class Initialized
INFO - 2024-07-08 13:36:27 --> Language Class Initialized
INFO - 2024-07-08 13:36:27 --> Config Class Initialized
INFO - 2024-07-08 13:36:27 --> Loader Class Initialized
INFO - 2024-07-08 13:36:27 --> Helper loaded: url_helper
INFO - 2024-07-08 13:36:27 --> Helper loaded: file_helper
INFO - 2024-07-08 13:36:27 --> Helper loaded: form_helper
INFO - 2024-07-08 13:36:27 --> Helper loaded: my_helper
INFO - 2024-07-08 13:36:27 --> Database Driver Class Initialized
INFO - 2024-07-08 13:36:27 --> Session: Class initialized using 'files' driver.
INFO - 2024-07-08 13:36:27 --> Controller Class Initialized
INFO - 2024-07-08 13:36:30 --> Config Class Initialized
INFO - 2024-07-08 13:36:30 --> Hooks Class Initialized
DEBUG - 2024-07-08 13:36:30 --> UTF-8 Support Enabled
INFO - 2024-07-08 13:36:30 --> Utf8 Class Initialized
INFO - 2024-07-08 13:36:30 --> URI Class Initialized
INFO - 2024-07-08 13:36:30 --> Router Class Initialized
INFO - 2024-07-08 13:36:30 --> Output Class Initialized
INFO - 2024-07-08 13:36:30 --> Security Class Initialized
DEBUG - 2024-07-08 13:36:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-07-08 13:36:30 --> Input Class Initialized
INFO - 2024-07-08 13:36:30 --> Language Class Initialized
INFO - 2024-07-08 13:36:30 --> Language Class Initialized
INFO - 2024-07-08 13:36:30 --> Config Class Initialized
INFO - 2024-07-08 13:36:30 --> Loader Class Initialized
INFO - 2024-07-08 13:36:30 --> Helper loaded: url_helper
INFO - 2024-07-08 13:36:30 --> Helper loaded: file_helper
INFO - 2024-07-08 13:36:30 --> Helper loaded: form_helper
INFO - 2024-07-08 13:36:30 --> Helper loaded: my_helper
INFO - 2024-07-08 13:36:30 --> Database Driver Class Initialized
INFO - 2024-07-08 13:36:30 --> Session: Class initialized using 'files' driver.
INFO - 2024-07-08 13:36:30 --> Controller Class Initialized
INFO - 2024-07-08 13:47:16 --> Config Class Initialized
INFO - 2024-07-08 13:47:16 --> Hooks Class Initialized
DEBUG - 2024-07-08 13:47:16 --> UTF-8 Support Enabled
INFO - 2024-07-08 13:47:16 --> Utf8 Class Initialized
INFO - 2024-07-08 13:47:16 --> URI Class Initialized
INFO - 2024-07-08 13:47:16 --> Router Class Initialized
INFO - 2024-07-08 13:47:16 --> Output Class Initialized
INFO - 2024-07-08 13:47:16 --> Security Class Initialized
DEBUG - 2024-07-08 13:47:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-07-08 13:47:16 --> Input Class Initialized
INFO - 2024-07-08 13:47:16 --> Language Class Initialized
INFO - 2024-07-08 13:47:16 --> Language Class Initialized
INFO - 2024-07-08 13:47:16 --> Config Class Initialized
INFO - 2024-07-08 13:47:16 --> Loader Class Initialized
INFO - 2024-07-08 13:47:16 --> Helper loaded: url_helper
INFO - 2024-07-08 13:47:16 --> Helper loaded: file_helper
INFO - 2024-07-08 13:47:16 --> Helper loaded: form_helper
INFO - 2024-07-08 13:47:16 --> Helper loaded: my_helper
INFO - 2024-07-08 13:47:16 --> Database Driver Class Initialized
INFO - 2024-07-08 13:47:16 --> Session: Class initialized using 'files' driver.
INFO - 2024-07-08 13:47:16 --> Controller Class Initialized
DEBUG - 2024-07-08 13:47:16 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/set_kelas/views/list.php
DEBUG - 2024-07-08 13:47:16 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-07-08 13:47:16 --> Final output sent to browser
DEBUG - 2024-07-08 13:47:16 --> Total execution time: 0.0371
INFO - 2024-07-08 13:51:31 --> Config Class Initialized
INFO - 2024-07-08 13:51:31 --> Hooks Class Initialized
DEBUG - 2024-07-08 13:51:31 --> UTF-8 Support Enabled
INFO - 2024-07-08 13:51:31 --> Utf8 Class Initialized
INFO - 2024-07-08 13:51:31 --> URI Class Initialized
INFO - 2024-07-08 13:51:31 --> Router Class Initialized
INFO - 2024-07-08 13:51:31 --> Output Class Initialized
INFO - 2024-07-08 13:51:31 --> Security Class Initialized
DEBUG - 2024-07-08 13:51:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-07-08 13:51:31 --> Input Class Initialized
INFO - 2024-07-08 13:51:31 --> Language Class Initialized
INFO - 2024-07-08 13:51:31 --> Language Class Initialized
INFO - 2024-07-08 13:51:31 --> Config Class Initialized
INFO - 2024-07-08 13:51:31 --> Loader Class Initialized
INFO - 2024-07-08 13:51:31 --> Helper loaded: url_helper
INFO - 2024-07-08 13:51:31 --> Helper loaded: file_helper
INFO - 2024-07-08 13:51:31 --> Helper loaded: form_helper
INFO - 2024-07-08 13:51:31 --> Helper loaded: my_helper
INFO - 2024-07-08 13:51:31 --> Database Driver Class Initialized
INFO - 2024-07-08 13:51:31 --> Session: Class initialized using 'files' driver.
INFO - 2024-07-08 13:51:31 --> Controller Class Initialized
DEBUG - 2024-07-08 13:51:31 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/login/views/login.php
DEBUG - 2024-07-08 13:51:31 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-07-08 13:51:31 --> Final output sent to browser
DEBUG - 2024-07-08 13:51:31 --> Total execution time: 0.0350
INFO - 2024-07-08 13:51:43 --> Config Class Initialized
INFO - 2024-07-08 13:51:43 --> Hooks Class Initialized
DEBUG - 2024-07-08 13:51:43 --> UTF-8 Support Enabled
INFO - 2024-07-08 13:51:43 --> Utf8 Class Initialized
INFO - 2024-07-08 13:51:43 --> URI Class Initialized
INFO - 2024-07-08 13:51:43 --> Router Class Initialized
INFO - 2024-07-08 13:51:43 --> Output Class Initialized
INFO - 2024-07-08 13:51:43 --> Security Class Initialized
DEBUG - 2024-07-08 13:51:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-07-08 13:51:43 --> Input Class Initialized
INFO - 2024-07-08 13:51:43 --> Language Class Initialized
INFO - 2024-07-08 13:51:43 --> Language Class Initialized
INFO - 2024-07-08 13:51:43 --> Config Class Initialized
INFO - 2024-07-08 13:51:43 --> Loader Class Initialized
INFO - 2024-07-08 13:51:43 --> Helper loaded: url_helper
INFO - 2024-07-08 13:51:43 --> Helper loaded: file_helper
INFO - 2024-07-08 13:51:43 --> Helper loaded: form_helper
INFO - 2024-07-08 13:51:43 --> Helper loaded: my_helper
INFO - 2024-07-08 13:51:43 --> Database Driver Class Initialized
INFO - 2024-07-08 13:51:43 --> Session: Class initialized using 'files' driver.
INFO - 2024-07-08 13:51:43 --> Controller Class Initialized
INFO - 2024-07-08 13:51:43 --> Helper loaded: cookie_helper
INFO - 2024-07-08 13:51:43 --> Final output sent to browser
DEBUG - 2024-07-08 13:51:43 --> Total execution time: 0.0366
INFO - 2024-07-08 13:51:43 --> Config Class Initialized
INFO - 2024-07-08 13:51:43 --> Hooks Class Initialized
DEBUG - 2024-07-08 13:51:43 --> UTF-8 Support Enabled
INFO - 2024-07-08 13:51:43 --> Utf8 Class Initialized
INFO - 2024-07-08 13:51:43 --> URI Class Initialized
INFO - 2024-07-08 13:51:43 --> Router Class Initialized
INFO - 2024-07-08 13:51:43 --> Output Class Initialized
INFO - 2024-07-08 13:51:43 --> Security Class Initialized
DEBUG - 2024-07-08 13:51:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-07-08 13:51:43 --> Input Class Initialized
INFO - 2024-07-08 13:51:43 --> Language Class Initialized
INFO - 2024-07-08 13:51:43 --> Language Class Initialized
INFO - 2024-07-08 13:51:43 --> Config Class Initialized
INFO - 2024-07-08 13:51:43 --> Loader Class Initialized
INFO - 2024-07-08 13:51:43 --> Helper loaded: url_helper
INFO - 2024-07-08 13:51:43 --> Helper loaded: file_helper
INFO - 2024-07-08 13:51:43 --> Helper loaded: form_helper
INFO - 2024-07-08 13:51:43 --> Helper loaded: my_helper
INFO - 2024-07-08 13:51:43 --> Database Driver Class Initialized
INFO - 2024-07-08 13:51:43 --> Session: Class initialized using 'files' driver.
INFO - 2024-07-08 13:51:43 --> Controller Class Initialized
DEBUG - 2024-07-08 13:51:43 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/home/views/v_home.php
DEBUG - 2024-07-08 13:51:43 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-07-08 13:51:43 --> Final output sent to browser
DEBUG - 2024-07-08 13:51:43 --> Total execution time: 0.0640
INFO - 2024-07-08 13:52:01 --> Config Class Initialized
INFO - 2024-07-08 13:52:01 --> Hooks Class Initialized
DEBUG - 2024-07-08 13:52:01 --> UTF-8 Support Enabled
INFO - 2024-07-08 13:52:01 --> Utf8 Class Initialized
INFO - 2024-07-08 13:52:01 --> URI Class Initialized
INFO - 2024-07-08 13:52:01 --> Router Class Initialized
INFO - 2024-07-08 13:52:01 --> Output Class Initialized
INFO - 2024-07-08 13:52:01 --> Security Class Initialized
DEBUG - 2024-07-08 13:52:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-07-08 13:52:01 --> Input Class Initialized
INFO - 2024-07-08 13:52:01 --> Language Class Initialized
INFO - 2024-07-08 13:52:01 --> Language Class Initialized
INFO - 2024-07-08 13:52:01 --> Config Class Initialized
INFO - 2024-07-08 13:52:01 --> Loader Class Initialized
INFO - 2024-07-08 13:52:01 --> Helper loaded: url_helper
INFO - 2024-07-08 13:52:01 --> Helper loaded: file_helper
INFO - 2024-07-08 13:52:01 --> Helper loaded: form_helper
INFO - 2024-07-08 13:52:01 --> Helper loaded: my_helper
INFO - 2024-07-08 13:52:01 --> Database Driver Class Initialized
INFO - 2024-07-08 13:52:01 --> Session: Class initialized using 'files' driver.
INFO - 2024-07-08 13:52:01 --> Controller Class Initialized
DEBUG - 2024-07-08 13:52:01 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/data_siswa/views/list.php
DEBUG - 2024-07-08 13:52:01 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-07-08 13:52:01 --> Final output sent to browser
DEBUG - 2024-07-08 13:52:01 --> Total execution time: 0.1422
INFO - 2024-07-08 13:52:02 --> Config Class Initialized
INFO - 2024-07-08 13:52:02 --> Hooks Class Initialized
DEBUG - 2024-07-08 13:52:02 --> UTF-8 Support Enabled
INFO - 2024-07-08 13:52:02 --> Utf8 Class Initialized
INFO - 2024-07-08 13:52:02 --> URI Class Initialized
INFO - 2024-07-08 13:52:02 --> Router Class Initialized
INFO - 2024-07-08 13:52:02 --> Output Class Initialized
INFO - 2024-07-08 13:52:02 --> Security Class Initialized
DEBUG - 2024-07-08 13:52:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-07-08 13:52:02 --> Input Class Initialized
INFO - 2024-07-08 13:52:02 --> Language Class Initialized
ERROR - 2024-07-08 13:52:02 --> 404 Page Not Found: /index
INFO - 2024-07-08 13:52:02 --> Config Class Initialized
INFO - 2024-07-08 13:52:02 --> Hooks Class Initialized
DEBUG - 2024-07-08 13:52:02 --> UTF-8 Support Enabled
INFO - 2024-07-08 13:52:02 --> Utf8 Class Initialized
INFO - 2024-07-08 13:52:02 --> URI Class Initialized
INFO - 2024-07-08 13:52:02 --> Router Class Initialized
INFO - 2024-07-08 13:52:02 --> Output Class Initialized
INFO - 2024-07-08 13:52:02 --> Security Class Initialized
DEBUG - 2024-07-08 13:52:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-07-08 13:52:02 --> Input Class Initialized
INFO - 2024-07-08 13:52:02 --> Language Class Initialized
INFO - 2024-07-08 13:52:02 --> Language Class Initialized
INFO - 2024-07-08 13:52:02 --> Config Class Initialized
INFO - 2024-07-08 13:52:02 --> Loader Class Initialized
INFO - 2024-07-08 13:52:02 --> Helper loaded: url_helper
INFO - 2024-07-08 13:52:02 --> Helper loaded: file_helper
INFO - 2024-07-08 13:52:02 --> Helper loaded: form_helper
INFO - 2024-07-08 13:52:02 --> Helper loaded: my_helper
INFO - 2024-07-08 13:52:02 --> Database Driver Class Initialized
INFO - 2024-07-08 13:52:02 --> Session: Class initialized using 'files' driver.
INFO - 2024-07-08 13:52:02 --> Controller Class Initialized
INFO - 2024-07-08 14:25:36 --> Config Class Initialized
INFO - 2024-07-08 14:25:36 --> Hooks Class Initialized
DEBUG - 2024-07-08 14:25:36 --> UTF-8 Support Enabled
INFO - 2024-07-08 14:25:36 --> Utf8 Class Initialized
INFO - 2024-07-08 14:25:37 --> URI Class Initialized
INFO - 2024-07-08 14:25:37 --> Router Class Initialized
INFO - 2024-07-08 14:25:37 --> Output Class Initialized
INFO - 2024-07-08 14:25:37 --> Security Class Initialized
DEBUG - 2024-07-08 14:25:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-07-08 14:25:37 --> Input Class Initialized
INFO - 2024-07-08 14:25:37 --> Language Class Initialized
INFO - 2024-07-08 14:25:37 --> Language Class Initialized
INFO - 2024-07-08 14:25:37 --> Config Class Initialized
INFO - 2024-07-08 14:25:37 --> Loader Class Initialized
INFO - 2024-07-08 14:25:37 --> Helper loaded: url_helper
INFO - 2024-07-08 14:25:37 --> Helper loaded: file_helper
INFO - 2024-07-08 14:25:37 --> Helper loaded: form_helper
INFO - 2024-07-08 14:25:37 --> Helper loaded: my_helper
INFO - 2024-07-08 14:25:37 --> Database Driver Class Initialized
INFO - 2024-07-08 14:25:37 --> Session: Class initialized using 'files' driver.
INFO - 2024-07-08 14:25:37 --> Controller Class Initialized
DEBUG - 2024-07-08 14:25:37 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/data_siswa/views/list.php
DEBUG - 2024-07-08 14:25:37 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-07-08 14:25:37 --> Final output sent to browser
DEBUG - 2024-07-08 14:25:37 --> Total execution time: 0.1239
INFO - 2024-07-08 14:25:37 --> Config Class Initialized
INFO - 2024-07-08 14:25:37 --> Hooks Class Initialized
DEBUG - 2024-07-08 14:25:37 --> UTF-8 Support Enabled
INFO - 2024-07-08 14:25:37 --> Utf8 Class Initialized
INFO - 2024-07-08 14:25:37 --> URI Class Initialized
INFO - 2024-07-08 14:25:37 --> Router Class Initialized
INFO - 2024-07-08 14:25:37 --> Output Class Initialized
INFO - 2024-07-08 14:25:37 --> Security Class Initialized
DEBUG - 2024-07-08 14:25:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-07-08 14:25:37 --> Input Class Initialized
INFO - 2024-07-08 14:25:37 --> Language Class Initialized
ERROR - 2024-07-08 14:25:37 --> 404 Page Not Found: /index
INFO - 2024-07-08 14:25:37 --> Config Class Initialized
INFO - 2024-07-08 14:25:37 --> Hooks Class Initialized
DEBUG - 2024-07-08 14:25:37 --> UTF-8 Support Enabled
INFO - 2024-07-08 14:25:37 --> Utf8 Class Initialized
INFO - 2024-07-08 14:25:37 --> URI Class Initialized
INFO - 2024-07-08 14:25:37 --> Router Class Initialized
INFO - 2024-07-08 14:25:37 --> Output Class Initialized
INFO - 2024-07-08 14:25:37 --> Security Class Initialized
DEBUG - 2024-07-08 14:25:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-07-08 14:25:37 --> Input Class Initialized
INFO - 2024-07-08 14:25:37 --> Language Class Initialized
INFO - 2024-07-08 14:25:37 --> Language Class Initialized
INFO - 2024-07-08 14:25:37 --> Config Class Initialized
INFO - 2024-07-08 14:25:37 --> Loader Class Initialized
INFO - 2024-07-08 14:25:37 --> Helper loaded: url_helper
INFO - 2024-07-08 14:25:37 --> Helper loaded: file_helper
INFO - 2024-07-08 14:25:37 --> Helper loaded: form_helper
INFO - 2024-07-08 14:25:37 --> Helper loaded: my_helper
INFO - 2024-07-08 14:25:37 --> Database Driver Class Initialized
INFO - 2024-07-08 14:25:37 --> Session: Class initialized using 'files' driver.
INFO - 2024-07-08 14:25:37 --> Controller Class Initialized
INFO - 2024-07-08 14:25:44 --> Config Class Initialized
INFO - 2024-07-08 14:25:44 --> Hooks Class Initialized
DEBUG - 2024-07-08 14:25:44 --> UTF-8 Support Enabled
INFO - 2024-07-08 14:25:44 --> Utf8 Class Initialized
INFO - 2024-07-08 14:25:44 --> URI Class Initialized
INFO - 2024-07-08 14:25:44 --> Router Class Initialized
INFO - 2024-07-08 14:25:44 --> Output Class Initialized
INFO - 2024-07-08 14:25:44 --> Security Class Initialized
DEBUG - 2024-07-08 14:25:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-07-08 14:25:44 --> Input Class Initialized
INFO - 2024-07-08 14:25:44 --> Language Class Initialized
INFO - 2024-07-08 14:25:44 --> Language Class Initialized
INFO - 2024-07-08 14:25:44 --> Config Class Initialized
INFO - 2024-07-08 14:25:44 --> Loader Class Initialized
INFO - 2024-07-08 14:25:44 --> Helper loaded: url_helper
INFO - 2024-07-08 14:25:44 --> Helper loaded: file_helper
INFO - 2024-07-08 14:25:44 --> Helper loaded: form_helper
INFO - 2024-07-08 14:25:44 --> Helper loaded: my_helper
INFO - 2024-07-08 14:25:44 --> Database Driver Class Initialized
INFO - 2024-07-08 14:25:44 --> Session: Class initialized using 'files' driver.
INFO - 2024-07-08 14:25:44 --> Controller Class Initialized
DEBUG - 2024-07-08 14:25:44 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/data_kelas/views/list.php
DEBUG - 2024-07-08 14:25:44 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-07-08 14:25:44 --> Final output sent to browser
DEBUG - 2024-07-08 14:25:44 --> Total execution time: 0.0418
INFO - 2024-07-08 14:25:44 --> Config Class Initialized
INFO - 2024-07-08 14:25:44 --> Hooks Class Initialized
DEBUG - 2024-07-08 14:25:44 --> UTF-8 Support Enabled
INFO - 2024-07-08 14:25:44 --> Utf8 Class Initialized
INFO - 2024-07-08 14:25:44 --> URI Class Initialized
INFO - 2024-07-08 14:25:44 --> Router Class Initialized
INFO - 2024-07-08 14:25:44 --> Output Class Initialized
INFO - 2024-07-08 14:25:44 --> Security Class Initialized
DEBUG - 2024-07-08 14:25:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-07-08 14:25:44 --> Input Class Initialized
INFO - 2024-07-08 14:25:44 --> Language Class Initialized
ERROR - 2024-07-08 14:25:44 --> 404 Page Not Found: /index
INFO - 2024-07-08 14:25:44 --> Config Class Initialized
INFO - 2024-07-08 14:25:44 --> Hooks Class Initialized
DEBUG - 2024-07-08 14:25:44 --> UTF-8 Support Enabled
INFO - 2024-07-08 14:25:44 --> Utf8 Class Initialized
INFO - 2024-07-08 14:25:44 --> URI Class Initialized
INFO - 2024-07-08 14:25:44 --> Router Class Initialized
INFO - 2024-07-08 14:25:44 --> Output Class Initialized
INFO - 2024-07-08 14:25:44 --> Security Class Initialized
DEBUG - 2024-07-08 14:25:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-07-08 14:25:44 --> Input Class Initialized
INFO - 2024-07-08 14:25:44 --> Language Class Initialized
INFO - 2024-07-08 14:25:44 --> Language Class Initialized
INFO - 2024-07-08 14:25:44 --> Config Class Initialized
INFO - 2024-07-08 14:25:44 --> Loader Class Initialized
INFO - 2024-07-08 14:25:44 --> Helper loaded: url_helper
INFO - 2024-07-08 14:25:44 --> Helper loaded: file_helper
INFO - 2024-07-08 14:25:44 --> Helper loaded: form_helper
INFO - 2024-07-08 14:25:44 --> Helper loaded: my_helper
INFO - 2024-07-08 14:25:44 --> Database Driver Class Initialized
INFO - 2024-07-08 14:25:44 --> Session: Class initialized using 'files' driver.
INFO - 2024-07-08 14:25:44 --> Controller Class Initialized
INFO - 2024-07-08 15:12:57 --> Config Class Initialized
INFO - 2024-07-08 15:12:57 --> Hooks Class Initialized
DEBUG - 2024-07-08 15:12:57 --> UTF-8 Support Enabled
INFO - 2024-07-08 15:12:57 --> Utf8 Class Initialized
INFO - 2024-07-08 15:12:57 --> URI Class Initialized
INFO - 2024-07-08 15:12:57 --> Router Class Initialized
INFO - 2024-07-08 15:12:57 --> Output Class Initialized
INFO - 2024-07-08 15:12:57 --> Security Class Initialized
DEBUG - 2024-07-08 15:12:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-07-08 15:12:57 --> Input Class Initialized
INFO - 2024-07-08 15:12:57 --> Language Class Initialized
INFO - 2024-07-08 15:12:57 --> Language Class Initialized
INFO - 2024-07-08 15:12:57 --> Config Class Initialized
INFO - 2024-07-08 15:12:57 --> Loader Class Initialized
INFO - 2024-07-08 15:12:57 --> Helper loaded: url_helper
INFO - 2024-07-08 15:12:57 --> Helper loaded: file_helper
INFO - 2024-07-08 15:12:57 --> Helper loaded: form_helper
INFO - 2024-07-08 15:12:57 --> Helper loaded: my_helper
INFO - 2024-07-08 15:12:57 --> Database Driver Class Initialized
INFO - 2024-07-08 15:12:57 --> Session: Class initialized using 'files' driver.
INFO - 2024-07-08 15:12:57 --> Controller Class Initialized
DEBUG - 2024-07-08 15:12:57 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/data_siswa/views/list.php
DEBUG - 2024-07-08 15:12:57 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-07-08 15:12:57 --> Final output sent to browser
DEBUG - 2024-07-08 15:12:57 --> Total execution time: 0.0559
INFO - 2024-07-08 15:12:57 --> Config Class Initialized
INFO - 2024-07-08 15:12:57 --> Hooks Class Initialized
DEBUG - 2024-07-08 15:12:57 --> UTF-8 Support Enabled
INFO - 2024-07-08 15:12:57 --> Utf8 Class Initialized
INFO - 2024-07-08 15:12:57 --> URI Class Initialized
INFO - 2024-07-08 15:12:57 --> Router Class Initialized
INFO - 2024-07-08 15:12:57 --> Output Class Initialized
INFO - 2024-07-08 15:12:57 --> Security Class Initialized
DEBUG - 2024-07-08 15:12:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-07-08 15:12:57 --> Input Class Initialized
INFO - 2024-07-08 15:12:57 --> Language Class Initialized
ERROR - 2024-07-08 15:12:57 --> 404 Page Not Found: /index
INFO - 2024-07-08 15:12:57 --> Config Class Initialized
INFO - 2024-07-08 15:12:57 --> Hooks Class Initialized
DEBUG - 2024-07-08 15:12:57 --> UTF-8 Support Enabled
INFO - 2024-07-08 15:12:57 --> Utf8 Class Initialized
INFO - 2024-07-08 15:12:57 --> URI Class Initialized
INFO - 2024-07-08 15:12:57 --> Router Class Initialized
INFO - 2024-07-08 15:12:57 --> Output Class Initialized
INFO - 2024-07-08 15:12:57 --> Security Class Initialized
DEBUG - 2024-07-08 15:12:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-07-08 15:12:57 --> Input Class Initialized
INFO - 2024-07-08 15:12:57 --> Language Class Initialized
INFO - 2024-07-08 15:12:57 --> Language Class Initialized
INFO - 2024-07-08 15:12:57 --> Config Class Initialized
INFO - 2024-07-08 15:12:57 --> Loader Class Initialized
INFO - 2024-07-08 15:12:57 --> Helper loaded: url_helper
INFO - 2024-07-08 15:12:57 --> Helper loaded: file_helper
INFO - 2024-07-08 15:12:57 --> Helper loaded: form_helper
INFO - 2024-07-08 15:12:57 --> Helper loaded: my_helper
INFO - 2024-07-08 15:12:57 --> Database Driver Class Initialized
INFO - 2024-07-08 15:12:57 --> Session: Class initialized using 'files' driver.
INFO - 2024-07-08 15:12:57 --> Controller Class Initialized
INFO - 2024-07-08 15:13:03 --> Config Class Initialized
INFO - 2024-07-08 15:13:03 --> Hooks Class Initialized
DEBUG - 2024-07-08 15:13:03 --> UTF-8 Support Enabled
INFO - 2024-07-08 15:13:03 --> Utf8 Class Initialized
INFO - 2024-07-08 15:13:03 --> URI Class Initialized
INFO - 2024-07-08 15:13:03 --> Router Class Initialized
INFO - 2024-07-08 15:13:03 --> Output Class Initialized
INFO - 2024-07-08 15:13:03 --> Security Class Initialized
DEBUG - 2024-07-08 15:13:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-07-08 15:13:03 --> Input Class Initialized
INFO - 2024-07-08 15:13:03 --> Language Class Initialized
INFO - 2024-07-08 15:13:03 --> Language Class Initialized
INFO - 2024-07-08 15:13:03 --> Config Class Initialized
INFO - 2024-07-08 15:13:03 --> Loader Class Initialized
INFO - 2024-07-08 15:13:03 --> Helper loaded: url_helper
INFO - 2024-07-08 15:13:03 --> Helper loaded: file_helper
INFO - 2024-07-08 15:13:03 --> Helper loaded: form_helper
INFO - 2024-07-08 15:13:03 --> Helper loaded: my_helper
INFO - 2024-07-08 15:13:03 --> Database Driver Class Initialized
INFO - 2024-07-08 15:13:03 --> Session: Class initialized using 'files' driver.
INFO - 2024-07-08 15:13:03 --> Controller Class Initialized
ERROR - 2024-07-08 15:13:03 --> Severity: Notice --> Undefined variable: status_form /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/data_siswa/views/form.php 231
DEBUG - 2024-07-08 15:13:03 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/data_siswa/views/form.php
DEBUG - 2024-07-08 15:13:03 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-07-08 15:13:03 --> Final output sent to browser
DEBUG - 2024-07-08 15:13:03 --> Total execution time: 0.1581
INFO - 2024-07-08 15:13:16 --> Config Class Initialized
INFO - 2024-07-08 15:13:16 --> Hooks Class Initialized
DEBUG - 2024-07-08 15:13:16 --> UTF-8 Support Enabled
INFO - 2024-07-08 15:13:16 --> Utf8 Class Initialized
INFO - 2024-07-08 15:13:16 --> URI Class Initialized
INFO - 2024-07-08 15:13:16 --> Router Class Initialized
INFO - 2024-07-08 15:13:16 --> Output Class Initialized
INFO - 2024-07-08 15:13:16 --> Security Class Initialized
DEBUG - 2024-07-08 15:13:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-07-08 15:13:16 --> Input Class Initialized
INFO - 2024-07-08 15:13:16 --> Language Class Initialized
INFO - 2024-07-08 15:13:16 --> Language Class Initialized
INFO - 2024-07-08 15:13:16 --> Config Class Initialized
INFO - 2024-07-08 15:13:16 --> Loader Class Initialized
INFO - 2024-07-08 15:13:16 --> Helper loaded: url_helper
INFO - 2024-07-08 15:13:16 --> Helper loaded: file_helper
INFO - 2024-07-08 15:13:16 --> Helper loaded: form_helper
INFO - 2024-07-08 15:13:16 --> Helper loaded: my_helper
INFO - 2024-07-08 15:13:16 --> Database Driver Class Initialized
INFO - 2024-07-08 15:13:16 --> Session: Class initialized using 'files' driver.
INFO - 2024-07-08 15:13:16 --> Controller Class Initialized
DEBUG - 2024-07-08 15:13:16 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/data_siswa/views/list.php
DEBUG - 2024-07-08 15:13:16 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-07-08 15:13:16 --> Final output sent to browser
DEBUG - 2024-07-08 15:13:16 --> Total execution time: 0.0363
INFO - 2024-07-08 15:13:16 --> Config Class Initialized
INFO - 2024-07-08 15:13:16 --> Hooks Class Initialized
DEBUG - 2024-07-08 15:13:16 --> UTF-8 Support Enabled
INFO - 2024-07-08 15:13:16 --> Utf8 Class Initialized
INFO - 2024-07-08 15:13:16 --> URI Class Initialized
INFO - 2024-07-08 15:13:16 --> Router Class Initialized
INFO - 2024-07-08 15:13:16 --> Output Class Initialized
INFO - 2024-07-08 15:13:16 --> Security Class Initialized
DEBUG - 2024-07-08 15:13:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-07-08 15:13:16 --> Input Class Initialized
INFO - 2024-07-08 15:13:16 --> Language Class Initialized
ERROR - 2024-07-08 15:13:16 --> 404 Page Not Found: /index
INFO - 2024-07-08 15:13:16 --> Config Class Initialized
INFO - 2024-07-08 15:13:16 --> Hooks Class Initialized
DEBUG - 2024-07-08 15:13:16 --> UTF-8 Support Enabled
INFO - 2024-07-08 15:13:16 --> Utf8 Class Initialized
INFO - 2024-07-08 15:13:16 --> URI Class Initialized
INFO - 2024-07-08 15:13:16 --> Router Class Initialized
INFO - 2024-07-08 15:13:16 --> Output Class Initialized
INFO - 2024-07-08 15:13:16 --> Security Class Initialized
DEBUG - 2024-07-08 15:13:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-07-08 15:13:16 --> Input Class Initialized
INFO - 2024-07-08 15:13:16 --> Language Class Initialized
INFO - 2024-07-08 15:13:16 --> Language Class Initialized
INFO - 2024-07-08 15:13:16 --> Config Class Initialized
INFO - 2024-07-08 15:13:16 --> Loader Class Initialized
INFO - 2024-07-08 15:13:16 --> Helper loaded: url_helper
INFO - 2024-07-08 15:13:16 --> Helper loaded: file_helper
INFO - 2024-07-08 15:13:16 --> Helper loaded: form_helper
INFO - 2024-07-08 15:13:16 --> Helper loaded: my_helper
INFO - 2024-07-08 15:13:16 --> Database Driver Class Initialized
INFO - 2024-07-08 15:13:16 --> Session: Class initialized using 'files' driver.
INFO - 2024-07-08 15:13:16 --> Controller Class Initialized
INFO - 2024-07-08 15:14:25 --> Config Class Initialized
INFO - 2024-07-08 15:14:25 --> Hooks Class Initialized
DEBUG - 2024-07-08 15:14:25 --> UTF-8 Support Enabled
INFO - 2024-07-08 15:14:25 --> Utf8 Class Initialized
INFO - 2024-07-08 15:14:25 --> URI Class Initialized
INFO - 2024-07-08 15:14:25 --> Router Class Initialized
INFO - 2024-07-08 15:14:25 --> Output Class Initialized
INFO - 2024-07-08 15:14:25 --> Security Class Initialized
DEBUG - 2024-07-08 15:14:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-07-08 15:14:25 --> Input Class Initialized
INFO - 2024-07-08 15:14:25 --> Language Class Initialized
INFO - 2024-07-08 15:14:25 --> Language Class Initialized
INFO - 2024-07-08 15:14:25 --> Config Class Initialized
INFO - 2024-07-08 15:14:25 --> Loader Class Initialized
INFO - 2024-07-08 15:14:25 --> Helper loaded: url_helper
INFO - 2024-07-08 15:14:25 --> Helper loaded: file_helper
INFO - 2024-07-08 15:14:25 --> Helper loaded: form_helper
INFO - 2024-07-08 15:14:25 --> Helper loaded: my_helper
INFO - 2024-07-08 15:14:25 --> Database Driver Class Initialized
INFO - 2024-07-08 15:14:25 --> Session: Class initialized using 'files' driver.
INFO - 2024-07-08 15:14:25 --> Controller Class Initialized
DEBUG - 2024-07-08 15:14:25 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/data_siswa/views/form_import.php
DEBUG - 2024-07-08 15:14:25 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-07-08 15:14:25 --> Final output sent to browser
DEBUG - 2024-07-08 15:14:25 --> Total execution time: 0.0656
INFO - 2024-07-08 15:15:09 --> Config Class Initialized
INFO - 2024-07-08 15:15:09 --> Hooks Class Initialized
DEBUG - 2024-07-08 15:15:09 --> UTF-8 Support Enabled
INFO - 2024-07-08 15:15:09 --> Utf8 Class Initialized
INFO - 2024-07-08 15:15:09 --> URI Class Initialized
INFO - 2024-07-08 15:15:09 --> Router Class Initialized
INFO - 2024-07-08 15:15:09 --> Output Class Initialized
INFO - 2024-07-08 15:15:09 --> Security Class Initialized
DEBUG - 2024-07-08 15:15:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-07-08 15:15:09 --> Input Class Initialized
INFO - 2024-07-08 15:15:09 --> Language Class Initialized
INFO - 2024-07-08 15:15:09 --> Language Class Initialized
INFO - 2024-07-08 15:15:09 --> Config Class Initialized
INFO - 2024-07-08 15:15:09 --> Loader Class Initialized
INFO - 2024-07-08 15:15:09 --> Helper loaded: url_helper
INFO - 2024-07-08 15:15:09 --> Helper loaded: file_helper
INFO - 2024-07-08 15:15:09 --> Helper loaded: form_helper
INFO - 2024-07-08 15:15:09 --> Helper loaded: my_helper
INFO - 2024-07-08 15:15:09 --> Database Driver Class Initialized
INFO - 2024-07-08 15:15:09 --> Session: Class initialized using 'files' driver.
INFO - 2024-07-08 15:15:09 --> Controller Class Initialized
ERROR - 2024-07-08 15:15:09 --> Severity: error --> Exception: Workbook does not contain sheet:data_siswa /www/wwwroot/report.mhis.link/bangka/secondary/application/third_party/PHP_Excel/PHPExcel.php 711
INFO - 2024-07-08 15:15:11 --> Config Class Initialized
INFO - 2024-07-08 15:15:11 --> Hooks Class Initialized
DEBUG - 2024-07-08 15:15:11 --> UTF-8 Support Enabled
INFO - 2024-07-08 15:15:11 --> Utf8 Class Initialized
INFO - 2024-07-08 15:15:11 --> URI Class Initialized
INFO - 2024-07-08 15:15:11 --> Router Class Initialized
INFO - 2024-07-08 15:15:11 --> Output Class Initialized
INFO - 2024-07-08 15:15:11 --> Security Class Initialized
DEBUG - 2024-07-08 15:15:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-07-08 15:15:11 --> Input Class Initialized
INFO - 2024-07-08 15:15:11 --> Language Class Initialized
INFO - 2024-07-08 15:15:11 --> Language Class Initialized
INFO - 2024-07-08 15:15:11 --> Config Class Initialized
INFO - 2024-07-08 15:15:11 --> Loader Class Initialized
INFO - 2024-07-08 15:15:11 --> Helper loaded: url_helper
INFO - 2024-07-08 15:15:11 --> Helper loaded: file_helper
INFO - 2024-07-08 15:15:11 --> Helper loaded: form_helper
INFO - 2024-07-08 15:15:11 --> Helper loaded: my_helper
INFO - 2024-07-08 15:15:11 --> Database Driver Class Initialized
INFO - 2024-07-08 15:15:11 --> Session: Class initialized using 'files' driver.
INFO - 2024-07-08 15:15:11 --> Controller Class Initialized
DEBUG - 2024-07-08 15:15:11 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/data_siswa/views/form_import.php
DEBUG - 2024-07-08 15:15:11 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-07-08 15:15:11 --> Final output sent to browser
DEBUG - 2024-07-08 15:15:11 --> Total execution time: 0.0355
INFO - 2024-07-08 15:16:16 --> Config Class Initialized
INFO - 2024-07-08 15:16:16 --> Hooks Class Initialized
DEBUG - 2024-07-08 15:16:16 --> UTF-8 Support Enabled
INFO - 2024-07-08 15:16:16 --> Utf8 Class Initialized
INFO - 2024-07-08 15:16:16 --> URI Class Initialized
INFO - 2024-07-08 15:16:16 --> Router Class Initialized
INFO - 2024-07-08 15:16:16 --> Output Class Initialized
INFO - 2024-07-08 15:16:16 --> Security Class Initialized
DEBUG - 2024-07-08 15:16:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-07-08 15:16:16 --> Input Class Initialized
INFO - 2024-07-08 15:16:16 --> Language Class Initialized
INFO - 2024-07-08 15:16:16 --> Language Class Initialized
INFO - 2024-07-08 15:16:16 --> Config Class Initialized
INFO - 2024-07-08 15:16:16 --> Loader Class Initialized
INFO - 2024-07-08 15:16:16 --> Helper loaded: url_helper
INFO - 2024-07-08 15:16:16 --> Helper loaded: file_helper
INFO - 2024-07-08 15:16:16 --> Helper loaded: form_helper
INFO - 2024-07-08 15:16:16 --> Helper loaded: my_helper
INFO - 2024-07-08 15:16:16 --> Database Driver Class Initialized
INFO - 2024-07-08 15:16:16 --> Session: Class initialized using 'files' driver.
INFO - 2024-07-08 15:16:16 --> Controller Class Initialized
ERROR - 2024-07-08 15:16:16 --> Severity: 8192 --> Array and string offset access syntax with curly braces is deprecated /www/wwwroot/report.mhis.link/bangka/secondary/application/third_party/PHP_Excel/PHPExcel/Reader/Excel5.php 1862
ERROR - 2024-07-08 15:16:16 --> Severity: 8192 --> Array and string offset access syntax with curly braces is deprecated /www/wwwroot/report.mhis.link/bangka/secondary/application/third_party/PHP_Excel/PHPExcel/Reader/Excel5.php 1921
ERROR - 2024-07-08 15:16:16 --> Severity: 8192 --> Array and string offset access syntax with curly braces is deprecated /www/wwwroot/report.mhis.link/bangka/secondary/application/third_party/PHP_Excel/PHPExcel/Reader/Excel5.php 2060
ERROR - 2024-07-08 15:16:16 --> Severity: 8192 --> Array and string offset access syntax with curly braces is deprecated /www/wwwroot/report.mhis.link/bangka/secondary/application/third_party/PHP_Excel/PHPExcel/Reader/Excel5.php 2085
ERROR - 2024-07-08 15:16:16 --> Severity: 8192 --> Array and string offset access syntax with curly braces is deprecated /www/wwwroot/report.mhis.link/bangka/secondary/application/third_party/PHP_Excel/PHPExcel/Reader/Excel5.php 2095
ERROR - 2024-07-08 15:16:16 --> Severity: 8192 --> Array and string offset access syntax with curly braces is deprecated /www/wwwroot/report.mhis.link/bangka/secondary/application/third_party/PHP_Excel/PHPExcel/Reader/Excel5.php 2113
ERROR - 2024-07-08 15:16:16 --> Severity: 8192 --> Array and string offset access syntax with curly braces is deprecated /www/wwwroot/report.mhis.link/bangka/secondary/application/third_party/PHP_Excel/PHPExcel/Reader/Excel5.php 2126
ERROR - 2024-07-08 15:16:16 --> Severity: 8192 --> Array and string offset access syntax with curly braces is deprecated /www/wwwroot/report.mhis.link/bangka/secondary/application/third_party/PHP_Excel/PHPExcel/Reader/Excel5.php 2130
ERROR - 2024-07-08 15:16:16 --> Severity: 8192 --> Array and string offset access syntax with curly braces is deprecated /www/wwwroot/report.mhis.link/bangka/secondary/application/third_party/PHP_Excel/PHPExcel/Reader/Excel5.php 2212
ERROR - 2024-07-08 15:16:16 --> Severity: 8192 --> Array and string offset access syntax with curly braces is deprecated /www/wwwroot/report.mhis.link/bangka/secondary/application/third_party/PHP_Excel/PHPExcel/Reader/Excel5.php 2336
ERROR - 2024-07-08 15:16:16 --> Severity: 8192 --> Array and string offset access syntax with curly braces is deprecated /www/wwwroot/report.mhis.link/bangka/secondary/application/third_party/PHP_Excel/PHPExcel/Reader/Excel5.php 2336
ERROR - 2024-07-08 15:16:16 --> Severity: 8192 --> Array and string offset access syntax with curly braces is deprecated /www/wwwroot/report.mhis.link/bangka/secondary/application/third_party/PHP_Excel/PHPExcel/Reader/Excel5.php 2336
ERROR - 2024-07-08 15:16:16 --> Severity: 8192 --> Array and string offset access syntax with curly braces is deprecated /www/wwwroot/report.mhis.link/bangka/secondary/application/third_party/PHP_Excel/PHPExcel/Reader/Excel5.php 2352
ERROR - 2024-07-08 15:16:16 --> Severity: 8192 --> Array and string offset access syntax with curly braces is deprecated /www/wwwroot/report.mhis.link/bangka/secondary/application/third_party/PHP_Excel/PHPExcel/Reader/Excel5.php 2352
ERROR - 2024-07-08 15:16:16 --> Severity: 8192 --> Array and string offset access syntax with curly braces is deprecated /www/wwwroot/report.mhis.link/bangka/secondary/application/third_party/PHP_Excel/PHPExcel/Reader/Excel5.php 2352
ERROR - 2024-07-08 15:16:16 --> Severity: 8192 --> Array and string offset access syntax with curly braces is deprecated /www/wwwroot/report.mhis.link/bangka/secondary/application/third_party/PHP_Excel/PHPExcel/Reader/Excel5.php 2368
ERROR - 2024-07-08 15:16:16 --> Severity: 8192 --> Array and string offset access syntax with curly braces is deprecated /www/wwwroot/report.mhis.link/bangka/secondary/application/third_party/PHP_Excel/PHPExcel/Reader/Excel5.php 2368
ERROR - 2024-07-08 15:16:16 --> Severity: 8192 --> Array and string offset access syntax with curly braces is deprecated /www/wwwroot/report.mhis.link/bangka/secondary/application/third_party/PHP_Excel/PHPExcel/Reader/Excel5.php 2368
ERROR - 2024-07-08 15:16:16 --> Severity: 8192 --> Array and string offset access syntax with curly braces is deprecated /www/wwwroot/report.mhis.link/bangka/secondary/application/third_party/PHP_Excel/PHPExcel/Reader/Excel5.php 2384
ERROR - 2024-07-08 15:16:16 --> Severity: 8192 --> Array and string offset access syntax with curly braces is deprecated /www/wwwroot/report.mhis.link/bangka/secondary/application/third_party/PHP_Excel/PHPExcel/Reader/Excel5.php 2384
ERROR - 2024-07-08 15:16:16 --> Severity: 8192 --> Array and string offset access syntax with curly braces is deprecated /www/wwwroot/report.mhis.link/bangka/secondary/application/third_party/PHP_Excel/PHPExcel/Reader/Excel5.php 2384
ERROR - 2024-07-08 15:16:16 --> Severity: 8192 --> Array and string offset access syntax with curly braces is deprecated /www/wwwroot/report.mhis.link/bangka/secondary/application/third_party/PHP_Excel/PHPExcel/Reader/Excel5.php 2400
ERROR - 2024-07-08 15:16:16 --> Severity: 8192 --> Array and string offset access syntax with curly braces is deprecated /www/wwwroot/report.mhis.link/bangka/secondary/application/third_party/PHP_Excel/PHPExcel/Reader/Excel5.php 2400
ERROR - 2024-07-08 15:16:16 --> Severity: 8192 --> Array and string offset access syntax with curly braces is deprecated /www/wwwroot/report.mhis.link/bangka/secondary/application/third_party/PHP_Excel/PHPExcel/Reader/Excel5.php 2400
ERROR - 2024-07-08 15:16:16 --> Severity: 8192 --> Array and string offset access syntax with curly braces is deprecated /www/wwwroot/report.mhis.link/bangka/secondary/application/third_party/PHP_Excel/PHPExcel/Reader/Excel5.php 2416
ERROR - 2024-07-08 15:16:16 --> Severity: 8192 --> Array and string offset access syntax with curly braces is deprecated /www/wwwroot/report.mhis.link/bangka/secondary/application/third_party/PHP_Excel/PHPExcel/Reader/Excel5.php 2416
ERROR - 2024-07-08 15:16:16 --> Severity: 8192 --> Array and string offset access syntax with curly braces is deprecated /www/wwwroot/report.mhis.link/bangka/secondary/application/third_party/PHP_Excel/PHPExcel/Reader/Excel5.php 2416
ERROR - 2024-07-08 15:16:16 --> Severity: 8192 --> Array and string offset access syntax with curly braces is deprecated /www/wwwroot/report.mhis.link/bangka/secondary/application/third_party/PHP_Excel/PHPExcel/Reader/Excel5.php 2432
ERROR - 2024-07-08 15:16:16 --> Severity: 8192 --> Array and string offset access syntax with curly braces is deprecated /www/wwwroot/report.mhis.link/bangka/secondary/application/third_party/PHP_Excel/PHPExcel/Reader/Excel5.php 2432
ERROR - 2024-07-08 15:16:16 --> Severity: 8192 --> Array and string offset access syntax with curly braces is deprecated /www/wwwroot/report.mhis.link/bangka/secondary/application/third_party/PHP_Excel/PHPExcel/Reader/Excel5.php 2432
ERROR - 2024-07-08 15:16:16 --> Severity: 8192 --> Array and string offset access syntax with curly braces is deprecated /www/wwwroot/report.mhis.link/bangka/secondary/application/third_party/PHP_Excel/PHPExcel/Reader/Excel5.php 2448
ERROR - 2024-07-08 15:16:16 --> Severity: 8192 --> Array and string offset access syntax with curly braces is deprecated /www/wwwroot/report.mhis.link/bangka/secondary/application/third_party/PHP_Excel/PHPExcel/Reader/Excel5.php 2448
ERROR - 2024-07-08 15:16:16 --> Severity: 8192 --> Array and string offset access syntax with curly braces is deprecated /www/wwwroot/report.mhis.link/bangka/secondary/application/third_party/PHP_Excel/PHPExcel/Reader/Excel5.php 2448
ERROR - 2024-07-08 15:16:16 --> Severity: 8192 --> Array and string offset access syntax with curly braces is deprecated /www/wwwroot/report.mhis.link/bangka/secondary/application/third_party/PHP_Excel/PHPExcel/Reader/Excel5.php 2490
ERROR - 2024-07-08 15:16:16 --> Severity: 8192 --> Array and string offset access syntax with curly braces is deprecated /www/wwwroot/report.mhis.link/bangka/secondary/application/third_party/PHP_Excel/PHPExcel/Reader/Excel5.php 2557
ERROR - 2024-07-08 15:16:16 --> Severity: 8192 --> Array and string offset access syntax with curly braces is deprecated /www/wwwroot/report.mhis.link/bangka/secondary/application/third_party/PHP_Excel/PHPExcel/Reader/Excel5.php 2565
ERROR - 2024-07-08 15:16:16 --> Severity: 8192 --> Array and string offset access syntax with curly braces is deprecated /www/wwwroot/report.mhis.link/bangka/secondary/application/third_party/PHP_Excel/PHPExcel/Reader/Excel5.php 2744
ERROR - 2024-07-08 15:16:16 --> Severity: 8192 --> Array and string offset access syntax with curly braces is deprecated /www/wwwroot/report.mhis.link/bangka/secondary/application/third_party/PHP_Excel/PHPExcel/Reader/Excel5.php 2828
ERROR - 2024-07-08 15:16:16 --> Severity: 8192 --> Array and string offset access syntax with curly braces is deprecated /www/wwwroot/report.mhis.link/bangka/secondary/application/third_party/PHP_Excel/PHPExcel/Reader/Excel5.php 2897
ERROR - 2024-07-08 15:16:16 --> Severity: 8192 --> Array and string offset access syntax with curly braces is deprecated /www/wwwroot/report.mhis.link/bangka/secondary/application/third_party/PHP_Excel/PHPExcel/Reader/Excel5.php 2921
ERROR - 2024-07-08 15:16:16 --> Severity: 8192 --> Array and string offset access syntax with curly braces is deprecated /www/wwwroot/report.mhis.link/bangka/secondary/application/third_party/PHP_Excel/PHPExcel/Reader/Excel5.php 3820
ERROR - 2024-07-08 15:16:16 --> Severity: 8192 --> Array and string offset access syntax with curly braces is deprecated /www/wwwroot/report.mhis.link/bangka/secondary/application/third_party/PHP_Excel/PHPExcel/Reader/Excel5.php 3844
ERROR - 2024-07-08 15:16:16 --> Severity: 8192 --> Array and string offset access syntax with curly braces is deprecated /www/wwwroot/report.mhis.link/bangka/secondary/application/third_party/PHP_Excel/PHPExcel/Reader/Excel5.php 3845
ERROR - 2024-07-08 15:16:16 --> Severity: 8192 --> Array and string offset access syntax with curly braces is deprecated /www/wwwroot/report.mhis.link/bangka/secondary/application/third_party/PHP_Excel/PHPExcel/Reader/Excel5.php 3846
ERROR - 2024-07-08 15:16:16 --> Severity: 8192 --> Array and string offset access syntax with curly braces is deprecated /www/wwwroot/report.mhis.link/bangka/secondary/application/third_party/PHP_Excel/PHPExcel/Reader/Excel5.php 3860
ERROR - 2024-07-08 15:16:16 --> Severity: 8192 --> Array and string offset access syntax with curly braces is deprecated /www/wwwroot/report.mhis.link/bangka/secondary/application/third_party/PHP_Excel/PHPExcel/Reader/Excel5.php 3861
ERROR - 2024-07-08 15:16:16 --> Severity: 8192 --> Array and string offset access syntax with curly braces is deprecated /www/wwwroot/report.mhis.link/bangka/secondary/application/third_party/PHP_Excel/PHPExcel/Reader/Excel5.php 3862
ERROR - 2024-07-08 15:16:16 --> Severity: 8192 --> Array and string offset access syntax with curly braces is deprecated /www/wwwroot/report.mhis.link/bangka/secondary/application/third_party/PHP_Excel/PHPExcel/Reader/Excel5.php 3866
ERROR - 2024-07-08 15:16:16 --> Severity: 8192 --> Array and string offset access syntax with curly braces is deprecated /www/wwwroot/report.mhis.link/bangka/secondary/application/third_party/PHP_Excel/PHPExcel/Reader/Excel5.php 3868
ERROR - 2024-07-08 15:16:16 --> Severity: 8192 --> Array and string offset access syntax with curly braces is deprecated /www/wwwroot/report.mhis.link/bangka/secondary/application/third_party/PHP_Excel/PHPExcel/Reader/Excel5.php 3869
ERROR - 2024-07-08 15:16:16 --> Severity: 8192 --> Array and string offset access syntax with curly braces is deprecated /www/wwwroot/report.mhis.link/bangka/secondary/application/third_party/PHP_Excel/PHPExcel/Reader/Excel5.php 3870
ERROR - 2024-07-08 15:16:16 --> Severity: 8192 --> Array and string offset access syntax with curly braces is deprecated /www/wwwroot/report.mhis.link/bangka/secondary/application/third_party/PHP_Excel/PHPExcel/Reader/Excel5.php 3874
ERROR - 2024-07-08 15:16:16 --> Severity: 8192 --> Array and string offset access syntax with curly braces is deprecated /www/wwwroot/report.mhis.link/bangka/secondary/application/third_party/PHP_Excel/PHPExcel/Reader/Excel5.php 3876
ERROR - 2024-07-08 15:16:16 --> Severity: 8192 --> Array and string offset access syntax with curly braces is deprecated /www/wwwroot/report.mhis.link/bangka/secondary/application/third_party/PHP_Excel/PHPExcel/Reader/Excel5.php 3877
ERROR - 2024-07-08 15:16:16 --> Severity: 8192 --> Array and string offset access syntax with curly braces is deprecated /www/wwwroot/report.mhis.link/bangka/secondary/application/third_party/PHP_Excel/PHPExcel/Reader/Excel5.php 3878
ERROR - 2024-07-08 15:16:16 --> Severity: 8192 --> Array and string offset access syntax with curly braces is deprecated /www/wwwroot/report.mhis.link/bangka/secondary/application/third_party/PHP_Excel/PHPExcel/Reader/Excel5.php 3946
ERROR - 2024-07-08 15:16:16 --> Severity: 8192 --> Array and string offset access syntax with curly braces is deprecated /www/wwwroot/report.mhis.link/bangka/secondary/application/third_party/PHP_Excel/PHPExcel/Reader/Excel5.php 4013
ERROR - 2024-07-08 15:16:16 --> Severity: 8192 --> Array and string offset access syntax with curly braces is deprecated /www/wwwroot/report.mhis.link/bangka/secondary/application/third_party/PHP_Excel/PHPExcel/Reader/Excel5.php 4016
ERROR - 2024-07-08 15:16:16 --> Severity: 8192 --> Array and string offset access syntax with curly braces is deprecated /www/wwwroot/report.mhis.link/bangka/secondary/application/third_party/PHP_Excel/PHPExcel/Reader/Excel5.php 4394
ERROR - 2024-07-08 15:16:16 --> Severity: 8192 --> Array and string offset access syntax with curly braces is deprecated /www/wwwroot/report.mhis.link/bangka/secondary/application/third_party/PHP_Excel/PHPExcel/Reader/Excel5.php 4546
ERROR - 2024-07-08 15:16:16 --> Severity: 8192 --> Array and string offset access syntax with curly braces is deprecated /www/wwwroot/report.mhis.link/bangka/secondary/application/third_party/PHP_Excel/PHPExcel/Reader/Excel5.php 4548
ERROR - 2024-07-08 15:16:16 --> Severity: 8192 --> Array and string offset access syntax with curly braces is deprecated /www/wwwroot/report.mhis.link/bangka/secondary/application/third_party/PHP_Excel/PHPExcel/Reader/Excel5.php 6093
ERROR - 2024-07-08 15:16:16 --> Severity: 8192 --> Array and string offset access syntax with curly braces is deprecated /www/wwwroot/report.mhis.link/bangka/secondary/application/third_party/PHP_Excel/PHPExcel/Reader/Excel5.php 6096
ERROR - 2024-07-08 15:16:16 --> Severity: 8192 --> Array and string offset access syntax with curly braces is deprecated /www/wwwroot/report.mhis.link/bangka/secondary/application/third_party/PHP_Excel/PHPExcel/Reader/Excel5.php 6503
ERROR - 2024-07-08 15:16:16 --> Severity: 8192 --> Array and string offset access syntax with curly braces is deprecated /www/wwwroot/report.mhis.link/bangka/secondary/application/third_party/PHP_Excel/PHPExcel/Reader/Excel5.php 6506
ERROR - 2024-07-08 15:16:16 --> Severity: 8192 --> Array and string offset access syntax with curly braces is deprecated /www/wwwroot/report.mhis.link/bangka/secondary/application/third_party/PHP_Excel/PHPExcel/Reader/Excel5.php 6509
ERROR - 2024-07-08 15:16:16 --> Severity: Warning --> "continue" targeting switch is equivalent to "break". Did you mean to use "continue 2"? /www/wwwroot/report.mhis.link/bangka/secondary/application/third_party/PHP_Excel/PHPExcel/Shared/OLE.php 290
ERROR - 2024-07-08 15:16:16 --> Severity: 8192 --> Array and string offset access syntax with curly braces is deprecated /www/wwwroot/report.mhis.link/bangka/secondary/application/third_party/PHP_Excel/PHPExcel/Shared/OLE.php 450
ERROR - 2024-07-08 15:16:16 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /www/wwwroot/report.mhis.link/bangka/secondary/system/core/Exceptions.php:271) /www/wwwroot/report.mhis.link/bangka/secondary/system/helpers/url_helper.php 564
INFO - 2024-07-08 15:16:22 --> Config Class Initialized
INFO - 2024-07-08 15:16:22 --> Hooks Class Initialized
DEBUG - 2024-07-08 15:16:22 --> UTF-8 Support Enabled
INFO - 2024-07-08 15:16:22 --> Utf8 Class Initialized
INFO - 2024-07-08 15:16:22 --> URI Class Initialized
INFO - 2024-07-08 15:16:22 --> Router Class Initialized
INFO - 2024-07-08 15:16:22 --> Output Class Initialized
INFO - 2024-07-08 15:16:22 --> Security Class Initialized
DEBUG - 2024-07-08 15:16:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-07-08 15:16:22 --> Input Class Initialized
INFO - 2024-07-08 15:16:22 --> Language Class Initialized
INFO - 2024-07-08 15:16:22 --> Language Class Initialized
INFO - 2024-07-08 15:16:22 --> Config Class Initialized
INFO - 2024-07-08 15:16:22 --> Loader Class Initialized
INFO - 2024-07-08 15:16:22 --> Helper loaded: url_helper
INFO - 2024-07-08 15:16:22 --> Helper loaded: file_helper
INFO - 2024-07-08 15:16:22 --> Helper loaded: form_helper
INFO - 2024-07-08 15:16:22 --> Helper loaded: my_helper
INFO - 2024-07-08 15:16:22 --> Database Driver Class Initialized
INFO - 2024-07-08 15:16:22 --> Session: Class initialized using 'files' driver.
INFO - 2024-07-08 15:16:22 --> Controller Class Initialized
DEBUG - 2024-07-08 15:16:22 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/data_siswa/views/form_import.php
DEBUG - 2024-07-08 15:16:22 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-07-08 15:16:22 --> Final output sent to browser
DEBUG - 2024-07-08 15:16:22 --> Total execution time: 0.0421
INFO - 2024-07-08 15:16:25 --> Config Class Initialized
INFO - 2024-07-08 15:16:25 --> Hooks Class Initialized
DEBUG - 2024-07-08 15:16:25 --> UTF-8 Support Enabled
INFO - 2024-07-08 15:16:25 --> Utf8 Class Initialized
INFO - 2024-07-08 15:16:25 --> URI Class Initialized
INFO - 2024-07-08 15:16:25 --> Router Class Initialized
INFO - 2024-07-08 15:16:25 --> Output Class Initialized
INFO - 2024-07-08 15:16:25 --> Security Class Initialized
DEBUG - 2024-07-08 15:16:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-07-08 15:16:25 --> Input Class Initialized
INFO - 2024-07-08 15:16:25 --> Language Class Initialized
INFO - 2024-07-08 15:16:25 --> Language Class Initialized
INFO - 2024-07-08 15:16:25 --> Config Class Initialized
INFO - 2024-07-08 15:16:25 --> Loader Class Initialized
INFO - 2024-07-08 15:16:25 --> Helper loaded: url_helper
INFO - 2024-07-08 15:16:25 --> Helper loaded: file_helper
INFO - 2024-07-08 15:16:25 --> Helper loaded: form_helper
INFO - 2024-07-08 15:16:25 --> Helper loaded: my_helper
INFO - 2024-07-08 15:16:25 --> Database Driver Class Initialized
INFO - 2024-07-08 15:16:25 --> Session: Class initialized using 'files' driver.
INFO - 2024-07-08 15:16:25 --> Controller Class Initialized
DEBUG - 2024-07-08 15:16:25 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/data_siswa/views/list.php
DEBUG - 2024-07-08 15:16:25 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-07-08 15:16:25 --> Final output sent to browser
DEBUG - 2024-07-08 15:16:25 --> Total execution time: 0.0875
INFO - 2024-07-08 15:16:25 --> Config Class Initialized
INFO - 2024-07-08 15:16:25 --> Hooks Class Initialized
DEBUG - 2024-07-08 15:16:25 --> UTF-8 Support Enabled
INFO - 2024-07-08 15:16:25 --> Utf8 Class Initialized
INFO - 2024-07-08 15:16:25 --> URI Class Initialized
INFO - 2024-07-08 15:16:25 --> Router Class Initialized
INFO - 2024-07-08 15:16:25 --> Output Class Initialized
INFO - 2024-07-08 15:16:25 --> Security Class Initialized
DEBUG - 2024-07-08 15:16:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-07-08 15:16:25 --> Input Class Initialized
INFO - 2024-07-08 15:16:25 --> Language Class Initialized
ERROR - 2024-07-08 15:16:25 --> 404 Page Not Found: /index
INFO - 2024-07-08 15:16:26 --> Config Class Initialized
INFO - 2024-07-08 15:16:26 --> Hooks Class Initialized
DEBUG - 2024-07-08 15:16:26 --> UTF-8 Support Enabled
INFO - 2024-07-08 15:16:26 --> Utf8 Class Initialized
INFO - 2024-07-08 15:16:26 --> URI Class Initialized
INFO - 2024-07-08 15:16:26 --> Router Class Initialized
INFO - 2024-07-08 15:16:26 --> Output Class Initialized
INFO - 2024-07-08 15:16:26 --> Security Class Initialized
DEBUG - 2024-07-08 15:16:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-07-08 15:16:26 --> Input Class Initialized
INFO - 2024-07-08 15:16:26 --> Language Class Initialized
INFO - 2024-07-08 15:16:26 --> Language Class Initialized
INFO - 2024-07-08 15:16:26 --> Config Class Initialized
INFO - 2024-07-08 15:16:26 --> Loader Class Initialized
INFO - 2024-07-08 15:16:26 --> Helper loaded: url_helper
INFO - 2024-07-08 15:16:26 --> Helper loaded: file_helper
INFO - 2024-07-08 15:16:26 --> Helper loaded: form_helper
INFO - 2024-07-08 15:16:26 --> Helper loaded: my_helper
INFO - 2024-07-08 15:16:26 --> Database Driver Class Initialized
INFO - 2024-07-08 15:16:26 --> Session: Class initialized using 'files' driver.
INFO - 2024-07-08 15:16:26 --> Controller Class Initialized
INFO - 2024-07-08 15:16:29 --> Config Class Initialized
INFO - 2024-07-08 15:16:29 --> Hooks Class Initialized
DEBUG - 2024-07-08 15:16:29 --> UTF-8 Support Enabled
INFO - 2024-07-08 15:16:29 --> Utf8 Class Initialized
INFO - 2024-07-08 15:16:29 --> URI Class Initialized
INFO - 2024-07-08 15:16:29 --> Router Class Initialized
INFO - 2024-07-08 15:16:29 --> Output Class Initialized
INFO - 2024-07-08 15:16:29 --> Security Class Initialized
DEBUG - 2024-07-08 15:16:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-07-08 15:16:29 --> Input Class Initialized
INFO - 2024-07-08 15:16:29 --> Language Class Initialized
INFO - 2024-07-08 15:16:29 --> Language Class Initialized
INFO - 2024-07-08 15:16:29 --> Config Class Initialized
INFO - 2024-07-08 15:16:29 --> Loader Class Initialized
INFO - 2024-07-08 15:16:29 --> Helper loaded: url_helper
INFO - 2024-07-08 15:16:29 --> Helper loaded: file_helper
INFO - 2024-07-08 15:16:29 --> Helper loaded: form_helper
INFO - 2024-07-08 15:16:29 --> Helper loaded: my_helper
INFO - 2024-07-08 15:16:29 --> Database Driver Class Initialized
INFO - 2024-07-08 15:16:29 --> Session: Class initialized using 'files' driver.
INFO - 2024-07-08 15:16:29 --> Controller Class Initialized
INFO - 2024-07-08 15:16:32 --> Config Class Initialized
INFO - 2024-07-08 15:16:32 --> Hooks Class Initialized
DEBUG - 2024-07-08 15:16:32 --> UTF-8 Support Enabled
INFO - 2024-07-08 15:16:32 --> Utf8 Class Initialized
INFO - 2024-07-08 15:16:32 --> URI Class Initialized
INFO - 2024-07-08 15:16:32 --> Router Class Initialized
INFO - 2024-07-08 15:16:32 --> Output Class Initialized
INFO - 2024-07-08 15:16:32 --> Security Class Initialized
DEBUG - 2024-07-08 15:16:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-07-08 15:16:32 --> Input Class Initialized
INFO - 2024-07-08 15:16:32 --> Language Class Initialized
INFO - 2024-07-08 15:16:32 --> Language Class Initialized
INFO - 2024-07-08 15:16:32 --> Config Class Initialized
INFO - 2024-07-08 15:16:32 --> Loader Class Initialized
INFO - 2024-07-08 15:16:32 --> Helper loaded: url_helper
INFO - 2024-07-08 15:16:32 --> Helper loaded: file_helper
INFO - 2024-07-08 15:16:32 --> Helper loaded: form_helper
INFO - 2024-07-08 15:16:32 --> Helper loaded: my_helper
INFO - 2024-07-08 15:16:32 --> Database Driver Class Initialized
INFO - 2024-07-08 15:16:32 --> Session: Class initialized using 'files' driver.
INFO - 2024-07-08 15:16:32 --> Controller Class Initialized
INFO - 2024-07-08 15:16:34 --> Config Class Initialized
INFO - 2024-07-08 15:16:34 --> Hooks Class Initialized
DEBUG - 2024-07-08 15:16:34 --> UTF-8 Support Enabled
INFO - 2024-07-08 15:16:34 --> Utf8 Class Initialized
INFO - 2024-07-08 15:16:34 --> URI Class Initialized
INFO - 2024-07-08 15:16:34 --> Router Class Initialized
INFO - 2024-07-08 15:16:34 --> Output Class Initialized
INFO - 2024-07-08 15:16:34 --> Security Class Initialized
DEBUG - 2024-07-08 15:16:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-07-08 15:16:34 --> Input Class Initialized
INFO - 2024-07-08 15:16:34 --> Language Class Initialized
INFO - 2024-07-08 15:16:34 --> Language Class Initialized
INFO - 2024-07-08 15:16:34 --> Config Class Initialized
INFO - 2024-07-08 15:16:34 --> Loader Class Initialized
INFO - 2024-07-08 15:16:34 --> Helper loaded: url_helper
INFO - 2024-07-08 15:16:34 --> Helper loaded: file_helper
INFO - 2024-07-08 15:16:34 --> Helper loaded: form_helper
INFO - 2024-07-08 15:16:34 --> Helper loaded: my_helper
INFO - 2024-07-08 15:16:34 --> Database Driver Class Initialized
INFO - 2024-07-08 15:16:34 --> Session: Class initialized using 'files' driver.
INFO - 2024-07-08 15:16:34 --> Controller Class Initialized
INFO - 2024-07-08 15:16:37 --> Config Class Initialized
INFO - 2024-07-08 15:16:37 --> Hooks Class Initialized
DEBUG - 2024-07-08 15:16:37 --> UTF-8 Support Enabled
INFO - 2024-07-08 15:16:37 --> Utf8 Class Initialized
INFO - 2024-07-08 15:16:37 --> URI Class Initialized
INFO - 2024-07-08 15:16:37 --> Router Class Initialized
INFO - 2024-07-08 15:16:37 --> Output Class Initialized
INFO - 2024-07-08 15:16:37 --> Security Class Initialized
DEBUG - 2024-07-08 15:16:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-07-08 15:16:37 --> Input Class Initialized
INFO - 2024-07-08 15:16:37 --> Language Class Initialized
INFO - 2024-07-08 15:16:37 --> Language Class Initialized
INFO - 2024-07-08 15:16:37 --> Config Class Initialized
INFO - 2024-07-08 15:16:37 --> Loader Class Initialized
INFO - 2024-07-08 15:16:37 --> Helper loaded: url_helper
INFO - 2024-07-08 15:16:37 --> Helper loaded: file_helper
INFO - 2024-07-08 15:16:37 --> Helper loaded: form_helper
INFO - 2024-07-08 15:16:37 --> Helper loaded: my_helper
INFO - 2024-07-08 15:16:37 --> Database Driver Class Initialized
INFO - 2024-07-08 15:16:37 --> Session: Class initialized using 'files' driver.
INFO - 2024-07-08 15:16:37 --> Controller Class Initialized
ERROR - 2024-07-08 15:16:37 --> Severity: Notice --> Undefined variable: status_form /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/data_siswa/views/form.php 231
DEBUG - 2024-07-08 15:16:37 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/data_siswa/views/form.php
DEBUG - 2024-07-08 15:16:37 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-07-08 15:16:37 --> Final output sent to browser
DEBUG - 2024-07-08 15:16:37 --> Total execution time: 0.0437
INFO - 2024-07-08 15:17:09 --> Config Class Initialized
INFO - 2024-07-08 15:17:09 --> Hooks Class Initialized
DEBUG - 2024-07-08 15:17:09 --> UTF-8 Support Enabled
INFO - 2024-07-08 15:17:09 --> Utf8 Class Initialized
INFO - 2024-07-08 15:17:09 --> URI Class Initialized
INFO - 2024-07-08 15:17:09 --> Router Class Initialized
INFO - 2024-07-08 15:17:09 --> Output Class Initialized
INFO - 2024-07-08 15:17:09 --> Security Class Initialized
DEBUG - 2024-07-08 15:17:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-07-08 15:17:09 --> Input Class Initialized
INFO - 2024-07-08 15:17:09 --> Language Class Initialized
INFO - 2024-07-08 15:17:09 --> Language Class Initialized
INFO - 2024-07-08 15:17:09 --> Config Class Initialized
INFO - 2024-07-08 15:17:09 --> Loader Class Initialized
INFO - 2024-07-08 15:17:09 --> Helper loaded: url_helper
INFO - 2024-07-08 15:17:09 --> Helper loaded: file_helper
INFO - 2024-07-08 15:17:09 --> Helper loaded: form_helper
INFO - 2024-07-08 15:17:09 --> Helper loaded: my_helper
INFO - 2024-07-08 15:17:09 --> Database Driver Class Initialized
INFO - 2024-07-08 15:17:09 --> Session: Class initialized using 'files' driver.
INFO - 2024-07-08 15:17:09 --> Controller Class Initialized
DEBUG - 2024-07-08 15:17:09 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/data_siswa/views/list.php
DEBUG - 2024-07-08 15:17:09 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-07-08 15:17:09 --> Final output sent to browser
DEBUG - 2024-07-08 15:17:09 --> Total execution time: 0.0353
INFO - 2024-07-08 15:17:09 --> Config Class Initialized
INFO - 2024-07-08 15:17:09 --> Hooks Class Initialized
DEBUG - 2024-07-08 15:17:09 --> UTF-8 Support Enabled
INFO - 2024-07-08 15:17:09 --> Utf8 Class Initialized
INFO - 2024-07-08 15:17:09 --> URI Class Initialized
INFO - 2024-07-08 15:17:09 --> Router Class Initialized
INFO - 2024-07-08 15:17:09 --> Output Class Initialized
INFO - 2024-07-08 15:17:09 --> Security Class Initialized
DEBUG - 2024-07-08 15:17:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-07-08 15:17:09 --> Input Class Initialized
INFO - 2024-07-08 15:17:09 --> Language Class Initialized
ERROR - 2024-07-08 15:17:09 --> 404 Page Not Found: /index
INFO - 2024-07-08 15:17:09 --> Config Class Initialized
INFO - 2024-07-08 15:17:09 --> Hooks Class Initialized
DEBUG - 2024-07-08 15:17:09 --> UTF-8 Support Enabled
INFO - 2024-07-08 15:17:09 --> Utf8 Class Initialized
INFO - 2024-07-08 15:17:09 --> URI Class Initialized
INFO - 2024-07-08 15:17:09 --> Router Class Initialized
INFO - 2024-07-08 15:17:09 --> Output Class Initialized
INFO - 2024-07-08 15:17:09 --> Security Class Initialized
DEBUG - 2024-07-08 15:17:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-07-08 15:17:09 --> Input Class Initialized
INFO - 2024-07-08 15:17:09 --> Language Class Initialized
INFO - 2024-07-08 15:17:09 --> Language Class Initialized
INFO - 2024-07-08 15:17:09 --> Config Class Initialized
INFO - 2024-07-08 15:17:09 --> Loader Class Initialized
INFO - 2024-07-08 15:17:09 --> Helper loaded: url_helper
INFO - 2024-07-08 15:17:09 --> Helper loaded: file_helper
INFO - 2024-07-08 15:17:09 --> Helper loaded: form_helper
INFO - 2024-07-08 15:17:09 --> Helper loaded: my_helper
INFO - 2024-07-08 15:17:09 --> Database Driver Class Initialized
INFO - 2024-07-08 15:17:09 --> Session: Class initialized using 'files' driver.
INFO - 2024-07-08 15:17:09 --> Controller Class Initialized
INFO - 2024-07-08 15:17:12 --> Config Class Initialized
INFO - 2024-07-08 15:17:12 --> Hooks Class Initialized
DEBUG - 2024-07-08 15:17:12 --> UTF-8 Support Enabled
INFO - 2024-07-08 15:17:12 --> Utf8 Class Initialized
INFO - 2024-07-08 15:17:12 --> URI Class Initialized
INFO - 2024-07-08 15:17:12 --> Router Class Initialized
INFO - 2024-07-08 15:17:12 --> Output Class Initialized
INFO - 2024-07-08 15:17:12 --> Security Class Initialized
DEBUG - 2024-07-08 15:17:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-07-08 15:17:12 --> Input Class Initialized
INFO - 2024-07-08 15:17:12 --> Language Class Initialized
INFO - 2024-07-08 15:17:12 --> Language Class Initialized
INFO - 2024-07-08 15:17:12 --> Config Class Initialized
INFO - 2024-07-08 15:17:12 --> Loader Class Initialized
INFO - 2024-07-08 15:17:12 --> Helper loaded: url_helper
INFO - 2024-07-08 15:17:12 --> Helper loaded: file_helper
INFO - 2024-07-08 15:17:12 --> Helper loaded: form_helper
INFO - 2024-07-08 15:17:12 --> Helper loaded: my_helper
INFO - 2024-07-08 15:17:12 --> Database Driver Class Initialized
INFO - 2024-07-08 15:17:12 --> Session: Class initialized using 'files' driver.
INFO - 2024-07-08 15:17:12 --> Controller Class Initialized
INFO - 2024-07-08 15:17:36 --> Config Class Initialized
INFO - 2024-07-08 15:17:36 --> Hooks Class Initialized
DEBUG - 2024-07-08 15:17:36 --> UTF-8 Support Enabled
INFO - 2024-07-08 15:17:36 --> Utf8 Class Initialized
INFO - 2024-07-08 15:17:36 --> URI Class Initialized
INFO - 2024-07-08 15:17:36 --> Router Class Initialized
INFO - 2024-07-08 15:17:36 --> Output Class Initialized
INFO - 2024-07-08 15:17:36 --> Security Class Initialized
DEBUG - 2024-07-08 15:17:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-07-08 15:17:36 --> Input Class Initialized
INFO - 2024-07-08 15:17:36 --> Language Class Initialized
INFO - 2024-07-08 15:17:36 --> Language Class Initialized
INFO - 2024-07-08 15:17:36 --> Config Class Initialized
INFO - 2024-07-08 15:17:36 --> Loader Class Initialized
INFO - 2024-07-08 15:17:36 --> Helper loaded: url_helper
INFO - 2024-07-08 15:17:36 --> Helper loaded: file_helper
INFO - 2024-07-08 15:17:36 --> Helper loaded: form_helper
INFO - 2024-07-08 15:17:36 --> Helper loaded: my_helper
INFO - 2024-07-08 15:17:36 --> Database Driver Class Initialized
INFO - 2024-07-08 15:17:36 --> Session: Class initialized using 'files' driver.
INFO - 2024-07-08 15:17:36 --> Controller Class Initialized
INFO - 2024-07-08 15:17:36 --> Config Class Initialized
INFO - 2024-07-08 15:17:36 --> Hooks Class Initialized
DEBUG - 2024-07-08 15:17:36 --> UTF-8 Support Enabled
INFO - 2024-07-08 15:17:36 --> Utf8 Class Initialized
INFO - 2024-07-08 15:17:36 --> URI Class Initialized
INFO - 2024-07-08 15:17:36 --> Router Class Initialized
INFO - 2024-07-08 15:17:36 --> Output Class Initialized
INFO - 2024-07-08 15:17:36 --> Security Class Initialized
DEBUG - 2024-07-08 15:17:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-07-08 15:17:36 --> Input Class Initialized
INFO - 2024-07-08 15:17:36 --> Language Class Initialized
INFO - 2024-07-08 15:17:36 --> Language Class Initialized
INFO - 2024-07-08 15:17:36 --> Config Class Initialized
INFO - 2024-07-08 15:17:36 --> Loader Class Initialized
INFO - 2024-07-08 15:17:36 --> Helper loaded: url_helper
INFO - 2024-07-08 15:17:36 --> Helper loaded: file_helper
INFO - 2024-07-08 15:17:36 --> Helper loaded: form_helper
INFO - 2024-07-08 15:17:36 --> Helper loaded: my_helper
INFO - 2024-07-08 15:17:36 --> Database Driver Class Initialized
INFO - 2024-07-08 15:17:36 --> Session: Class initialized using 'files' driver.
INFO - 2024-07-08 15:17:36 --> Controller Class Initialized
DEBUG - 2024-07-08 15:17:36 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/data_siswa/views/list.php
DEBUG - 2024-07-08 15:17:36 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-07-08 15:17:36 --> Final output sent to browser
DEBUG - 2024-07-08 15:17:36 --> Total execution time: 0.0289
INFO - 2024-07-08 15:17:36 --> Config Class Initialized
INFO - 2024-07-08 15:17:36 --> Hooks Class Initialized
DEBUG - 2024-07-08 15:17:36 --> UTF-8 Support Enabled
INFO - 2024-07-08 15:17:36 --> Utf8 Class Initialized
INFO - 2024-07-08 15:17:36 --> URI Class Initialized
INFO - 2024-07-08 15:17:36 --> Router Class Initialized
INFO - 2024-07-08 15:17:36 --> Output Class Initialized
INFO - 2024-07-08 15:17:36 --> Security Class Initialized
DEBUG - 2024-07-08 15:17:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-07-08 15:17:36 --> Input Class Initialized
INFO - 2024-07-08 15:17:36 --> Language Class Initialized
ERROR - 2024-07-08 15:17:36 --> 404 Page Not Found: /index
INFO - 2024-07-08 15:17:36 --> Config Class Initialized
INFO - 2024-07-08 15:17:36 --> Hooks Class Initialized
DEBUG - 2024-07-08 15:17:36 --> UTF-8 Support Enabled
INFO - 2024-07-08 15:17:36 --> Utf8 Class Initialized
INFO - 2024-07-08 15:17:36 --> URI Class Initialized
INFO - 2024-07-08 15:17:36 --> Router Class Initialized
INFO - 2024-07-08 15:17:36 --> Output Class Initialized
INFO - 2024-07-08 15:17:36 --> Security Class Initialized
DEBUG - 2024-07-08 15:17:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-07-08 15:17:36 --> Input Class Initialized
INFO - 2024-07-08 15:17:36 --> Language Class Initialized
INFO - 2024-07-08 15:17:36 --> Language Class Initialized
INFO - 2024-07-08 15:17:36 --> Config Class Initialized
INFO - 2024-07-08 15:17:36 --> Loader Class Initialized
INFO - 2024-07-08 15:17:36 --> Helper loaded: url_helper
INFO - 2024-07-08 15:17:36 --> Helper loaded: file_helper
INFO - 2024-07-08 15:17:36 --> Helper loaded: form_helper
INFO - 2024-07-08 15:17:36 --> Helper loaded: my_helper
INFO - 2024-07-08 15:17:36 --> Database Driver Class Initialized
INFO - 2024-07-08 15:17:36 --> Session: Class initialized using 'files' driver.
INFO - 2024-07-08 15:17:36 --> Controller Class Initialized
INFO - 2024-07-08 15:17:41 --> Config Class Initialized
INFO - 2024-07-08 15:17:41 --> Hooks Class Initialized
DEBUG - 2024-07-08 15:17:41 --> UTF-8 Support Enabled
INFO - 2024-07-08 15:17:41 --> Utf8 Class Initialized
INFO - 2024-07-08 15:17:41 --> URI Class Initialized
INFO - 2024-07-08 15:17:41 --> Router Class Initialized
INFO - 2024-07-08 15:17:41 --> Output Class Initialized
INFO - 2024-07-08 15:17:41 --> Security Class Initialized
DEBUG - 2024-07-08 15:17:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-07-08 15:17:41 --> Input Class Initialized
INFO - 2024-07-08 15:17:41 --> Language Class Initialized
INFO - 2024-07-08 15:17:41 --> Language Class Initialized
INFO - 2024-07-08 15:17:41 --> Config Class Initialized
INFO - 2024-07-08 15:17:41 --> Loader Class Initialized
INFO - 2024-07-08 15:17:41 --> Helper loaded: url_helper
INFO - 2024-07-08 15:17:41 --> Helper loaded: file_helper
INFO - 2024-07-08 15:17:41 --> Helper loaded: form_helper
INFO - 2024-07-08 15:17:41 --> Helper loaded: my_helper
INFO - 2024-07-08 15:17:41 --> Database Driver Class Initialized
INFO - 2024-07-08 15:17:41 --> Session: Class initialized using 'files' driver.
INFO - 2024-07-08 15:17:41 --> Controller Class Initialized
INFO - 2024-07-08 15:17:42 --> Config Class Initialized
INFO - 2024-07-08 15:17:42 --> Hooks Class Initialized
DEBUG - 2024-07-08 15:17:42 --> UTF-8 Support Enabled
INFO - 2024-07-08 15:17:42 --> Utf8 Class Initialized
INFO - 2024-07-08 15:17:42 --> URI Class Initialized
INFO - 2024-07-08 15:17:42 --> Router Class Initialized
INFO - 2024-07-08 15:17:42 --> Output Class Initialized
INFO - 2024-07-08 15:17:42 --> Security Class Initialized
DEBUG - 2024-07-08 15:17:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-07-08 15:17:42 --> Input Class Initialized
INFO - 2024-07-08 15:17:42 --> Language Class Initialized
INFO - 2024-07-08 15:17:42 --> Language Class Initialized
INFO - 2024-07-08 15:17:42 --> Config Class Initialized
INFO - 2024-07-08 15:17:42 --> Loader Class Initialized
INFO - 2024-07-08 15:17:42 --> Helper loaded: url_helper
INFO - 2024-07-08 15:17:42 --> Helper loaded: file_helper
INFO - 2024-07-08 15:17:42 --> Helper loaded: form_helper
INFO - 2024-07-08 15:17:42 --> Helper loaded: my_helper
INFO - 2024-07-08 15:17:42 --> Database Driver Class Initialized
INFO - 2024-07-08 15:17:42 --> Session: Class initialized using 'files' driver.
INFO - 2024-07-08 15:17:42 --> Controller Class Initialized
INFO - 2024-07-08 15:17:45 --> Config Class Initialized
INFO - 2024-07-08 15:17:45 --> Hooks Class Initialized
DEBUG - 2024-07-08 15:17:45 --> UTF-8 Support Enabled
INFO - 2024-07-08 15:17:45 --> Utf8 Class Initialized
INFO - 2024-07-08 15:17:45 --> URI Class Initialized
INFO - 2024-07-08 15:17:45 --> Router Class Initialized
INFO - 2024-07-08 15:17:45 --> Output Class Initialized
INFO - 2024-07-08 15:17:45 --> Security Class Initialized
DEBUG - 2024-07-08 15:17:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-07-08 15:17:45 --> Input Class Initialized
INFO - 2024-07-08 15:17:45 --> Language Class Initialized
INFO - 2024-07-08 15:17:45 --> Language Class Initialized
INFO - 2024-07-08 15:17:45 --> Config Class Initialized
INFO - 2024-07-08 15:17:45 --> Loader Class Initialized
INFO - 2024-07-08 15:17:45 --> Helper loaded: url_helper
INFO - 2024-07-08 15:17:45 --> Helper loaded: file_helper
INFO - 2024-07-08 15:17:45 --> Helper loaded: form_helper
INFO - 2024-07-08 15:17:45 --> Helper loaded: my_helper
INFO - 2024-07-08 15:17:45 --> Database Driver Class Initialized
INFO - 2024-07-08 15:17:45 --> Session: Class initialized using 'files' driver.
INFO - 2024-07-08 15:17:45 --> Controller Class Initialized
INFO - 2024-07-08 15:17:45 --> Config Class Initialized
INFO - 2024-07-08 15:17:45 --> Hooks Class Initialized
DEBUG - 2024-07-08 15:17:45 --> UTF-8 Support Enabled
INFO - 2024-07-08 15:17:45 --> Utf8 Class Initialized
INFO - 2024-07-08 15:17:45 --> URI Class Initialized
INFO - 2024-07-08 15:17:45 --> Router Class Initialized
INFO - 2024-07-08 15:17:45 --> Output Class Initialized
INFO - 2024-07-08 15:17:45 --> Security Class Initialized
DEBUG - 2024-07-08 15:17:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-07-08 15:17:45 --> Input Class Initialized
INFO - 2024-07-08 15:17:45 --> Language Class Initialized
INFO - 2024-07-08 15:17:45 --> Language Class Initialized
INFO - 2024-07-08 15:17:45 --> Config Class Initialized
INFO - 2024-07-08 15:17:45 --> Loader Class Initialized
INFO - 2024-07-08 15:17:45 --> Helper loaded: url_helper
INFO - 2024-07-08 15:17:45 --> Helper loaded: file_helper
INFO - 2024-07-08 15:17:45 --> Helper loaded: form_helper
INFO - 2024-07-08 15:17:45 --> Helper loaded: my_helper
INFO - 2024-07-08 15:17:45 --> Database Driver Class Initialized
INFO - 2024-07-08 15:17:45 --> Session: Class initialized using 'files' driver.
INFO - 2024-07-08 15:17:45 --> Controller Class Initialized
DEBUG - 2024-07-08 15:17:45 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/data_siswa/views/list.php
DEBUG - 2024-07-08 15:17:45 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-07-08 15:17:45 --> Final output sent to browser
DEBUG - 2024-07-08 15:17:45 --> Total execution time: 0.0910
INFO - 2024-07-08 15:17:45 --> Config Class Initialized
INFO - 2024-07-08 15:17:45 --> Hooks Class Initialized
DEBUG - 2024-07-08 15:17:45 --> UTF-8 Support Enabled
INFO - 2024-07-08 15:17:45 --> Utf8 Class Initialized
INFO - 2024-07-08 15:17:45 --> URI Class Initialized
INFO - 2024-07-08 15:17:45 --> Router Class Initialized
INFO - 2024-07-08 15:17:45 --> Output Class Initialized
INFO - 2024-07-08 15:17:45 --> Security Class Initialized
DEBUG - 2024-07-08 15:17:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-07-08 15:17:45 --> Input Class Initialized
INFO - 2024-07-08 15:17:45 --> Language Class Initialized
ERROR - 2024-07-08 15:17:45 --> 404 Page Not Found: /index
INFO - 2024-07-08 15:17:45 --> Config Class Initialized
INFO - 2024-07-08 15:17:45 --> Hooks Class Initialized
DEBUG - 2024-07-08 15:17:45 --> UTF-8 Support Enabled
INFO - 2024-07-08 15:17:45 --> Utf8 Class Initialized
INFO - 2024-07-08 15:17:45 --> URI Class Initialized
INFO - 2024-07-08 15:17:45 --> Router Class Initialized
INFO - 2024-07-08 15:17:45 --> Output Class Initialized
INFO - 2024-07-08 15:17:45 --> Security Class Initialized
DEBUG - 2024-07-08 15:17:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-07-08 15:17:45 --> Input Class Initialized
INFO - 2024-07-08 15:17:45 --> Language Class Initialized
INFO - 2024-07-08 15:17:45 --> Language Class Initialized
INFO - 2024-07-08 15:17:45 --> Config Class Initialized
INFO - 2024-07-08 15:17:45 --> Loader Class Initialized
INFO - 2024-07-08 15:17:45 --> Helper loaded: url_helper
INFO - 2024-07-08 15:17:45 --> Helper loaded: file_helper
INFO - 2024-07-08 15:17:45 --> Helper loaded: form_helper
INFO - 2024-07-08 15:17:45 --> Helper loaded: my_helper
INFO - 2024-07-08 15:17:45 --> Database Driver Class Initialized
INFO - 2024-07-08 15:17:45 --> Session: Class initialized using 'files' driver.
INFO - 2024-07-08 15:17:45 --> Controller Class Initialized
INFO - 2024-07-08 15:17:47 --> Config Class Initialized
INFO - 2024-07-08 15:17:47 --> Hooks Class Initialized
DEBUG - 2024-07-08 15:17:47 --> UTF-8 Support Enabled
INFO - 2024-07-08 15:17:47 --> Utf8 Class Initialized
INFO - 2024-07-08 15:17:47 --> URI Class Initialized
INFO - 2024-07-08 15:17:47 --> Router Class Initialized
INFO - 2024-07-08 15:17:47 --> Output Class Initialized
INFO - 2024-07-08 15:17:47 --> Security Class Initialized
DEBUG - 2024-07-08 15:17:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-07-08 15:17:47 --> Input Class Initialized
INFO - 2024-07-08 15:17:47 --> Language Class Initialized
INFO - 2024-07-08 15:17:47 --> Language Class Initialized
INFO - 2024-07-08 15:17:47 --> Config Class Initialized
INFO - 2024-07-08 15:17:47 --> Loader Class Initialized
INFO - 2024-07-08 15:17:47 --> Helper loaded: url_helper
INFO - 2024-07-08 15:17:47 --> Helper loaded: file_helper
INFO - 2024-07-08 15:17:47 --> Helper loaded: form_helper
INFO - 2024-07-08 15:17:47 --> Helper loaded: my_helper
INFO - 2024-07-08 15:17:47 --> Database Driver Class Initialized
INFO - 2024-07-08 15:17:47 --> Session: Class initialized using 'files' driver.
INFO - 2024-07-08 15:17:47 --> Controller Class Initialized
INFO - 2024-07-08 15:17:49 --> Config Class Initialized
INFO - 2024-07-08 15:17:49 --> Hooks Class Initialized
DEBUG - 2024-07-08 15:17:49 --> UTF-8 Support Enabled
INFO - 2024-07-08 15:17:49 --> Utf8 Class Initialized
INFO - 2024-07-08 15:17:49 --> URI Class Initialized
INFO - 2024-07-08 15:17:49 --> Router Class Initialized
INFO - 2024-07-08 15:17:49 --> Output Class Initialized
INFO - 2024-07-08 15:17:49 --> Security Class Initialized
DEBUG - 2024-07-08 15:17:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-07-08 15:17:49 --> Input Class Initialized
INFO - 2024-07-08 15:17:49 --> Language Class Initialized
INFO - 2024-07-08 15:17:49 --> Language Class Initialized
INFO - 2024-07-08 15:17:49 --> Config Class Initialized
INFO - 2024-07-08 15:17:49 --> Loader Class Initialized
INFO - 2024-07-08 15:17:49 --> Helper loaded: url_helper
INFO - 2024-07-08 15:17:49 --> Helper loaded: file_helper
INFO - 2024-07-08 15:17:49 --> Helper loaded: form_helper
INFO - 2024-07-08 15:17:49 --> Helper loaded: my_helper
INFO - 2024-07-08 15:17:49 --> Database Driver Class Initialized
INFO - 2024-07-08 15:17:49 --> Session: Class initialized using 'files' driver.
INFO - 2024-07-08 15:17:49 --> Controller Class Initialized
INFO - 2024-07-08 15:17:49 --> Config Class Initialized
INFO - 2024-07-08 15:17:49 --> Hooks Class Initialized
DEBUG - 2024-07-08 15:17:49 --> UTF-8 Support Enabled
INFO - 2024-07-08 15:17:49 --> Utf8 Class Initialized
INFO - 2024-07-08 15:17:49 --> URI Class Initialized
INFO - 2024-07-08 15:17:49 --> Router Class Initialized
INFO - 2024-07-08 15:17:49 --> Output Class Initialized
INFO - 2024-07-08 15:17:49 --> Security Class Initialized
DEBUG - 2024-07-08 15:17:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-07-08 15:17:49 --> Input Class Initialized
INFO - 2024-07-08 15:17:49 --> Language Class Initialized
INFO - 2024-07-08 15:17:49 --> Language Class Initialized
INFO - 2024-07-08 15:17:49 --> Config Class Initialized
INFO - 2024-07-08 15:17:49 --> Loader Class Initialized
INFO - 2024-07-08 15:17:49 --> Helper loaded: url_helper
INFO - 2024-07-08 15:17:49 --> Helper loaded: file_helper
INFO - 2024-07-08 15:17:49 --> Helper loaded: form_helper
INFO - 2024-07-08 15:17:49 --> Helper loaded: my_helper
INFO - 2024-07-08 15:17:49 --> Database Driver Class Initialized
INFO - 2024-07-08 15:17:49 --> Session: Class initialized using 'files' driver.
INFO - 2024-07-08 15:17:49 --> Controller Class Initialized
DEBUG - 2024-07-08 15:17:49 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/data_siswa/views/list.php
DEBUG - 2024-07-08 15:17:49 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-07-08 15:17:49 --> Final output sent to browser
DEBUG - 2024-07-08 15:17:49 --> Total execution time: 0.0369
INFO - 2024-07-08 15:17:49 --> Config Class Initialized
INFO - 2024-07-08 15:17:49 --> Hooks Class Initialized
DEBUG - 2024-07-08 15:17:49 --> UTF-8 Support Enabled
INFO - 2024-07-08 15:17:49 --> Utf8 Class Initialized
INFO - 2024-07-08 15:17:49 --> URI Class Initialized
INFO - 2024-07-08 15:17:49 --> Router Class Initialized
INFO - 2024-07-08 15:17:49 --> Output Class Initialized
INFO - 2024-07-08 15:17:49 --> Security Class Initialized
DEBUG - 2024-07-08 15:17:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-07-08 15:17:49 --> Input Class Initialized
INFO - 2024-07-08 15:17:49 --> Language Class Initialized
ERROR - 2024-07-08 15:17:49 --> 404 Page Not Found: /index
INFO - 2024-07-08 15:17:49 --> Config Class Initialized
INFO - 2024-07-08 15:17:49 --> Hooks Class Initialized
DEBUG - 2024-07-08 15:17:49 --> UTF-8 Support Enabled
INFO - 2024-07-08 15:17:49 --> Utf8 Class Initialized
INFO - 2024-07-08 15:17:49 --> URI Class Initialized
INFO - 2024-07-08 15:17:49 --> Router Class Initialized
INFO - 2024-07-08 15:17:49 --> Output Class Initialized
INFO - 2024-07-08 15:17:49 --> Security Class Initialized
DEBUG - 2024-07-08 15:17:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-07-08 15:17:49 --> Input Class Initialized
INFO - 2024-07-08 15:17:49 --> Language Class Initialized
INFO - 2024-07-08 15:17:49 --> Language Class Initialized
INFO - 2024-07-08 15:17:49 --> Config Class Initialized
INFO - 2024-07-08 15:17:49 --> Loader Class Initialized
INFO - 2024-07-08 15:17:49 --> Helper loaded: url_helper
INFO - 2024-07-08 15:17:49 --> Helper loaded: file_helper
INFO - 2024-07-08 15:17:50 --> Helper loaded: form_helper
INFO - 2024-07-08 15:17:50 --> Helper loaded: my_helper
INFO - 2024-07-08 15:17:50 --> Database Driver Class Initialized
INFO - 2024-07-08 15:17:50 --> Session: Class initialized using 'files' driver.
INFO - 2024-07-08 15:17:50 --> Controller Class Initialized
INFO - 2024-07-08 15:17:51 --> Config Class Initialized
INFO - 2024-07-08 15:17:51 --> Hooks Class Initialized
DEBUG - 2024-07-08 15:17:51 --> UTF-8 Support Enabled
INFO - 2024-07-08 15:17:51 --> Utf8 Class Initialized
INFO - 2024-07-08 15:17:51 --> URI Class Initialized
INFO - 2024-07-08 15:17:51 --> Router Class Initialized
INFO - 2024-07-08 15:17:51 --> Output Class Initialized
INFO - 2024-07-08 15:17:51 --> Security Class Initialized
DEBUG - 2024-07-08 15:17:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-07-08 15:17:51 --> Input Class Initialized
INFO - 2024-07-08 15:17:51 --> Language Class Initialized
INFO - 2024-07-08 15:17:51 --> Language Class Initialized
INFO - 2024-07-08 15:17:51 --> Config Class Initialized
INFO - 2024-07-08 15:17:51 --> Loader Class Initialized
INFO - 2024-07-08 15:17:51 --> Helper loaded: url_helper
INFO - 2024-07-08 15:17:51 --> Helper loaded: file_helper
INFO - 2024-07-08 15:17:51 --> Helper loaded: form_helper
INFO - 2024-07-08 15:17:51 --> Helper loaded: my_helper
INFO - 2024-07-08 15:17:51 --> Database Driver Class Initialized
INFO - 2024-07-08 15:17:51 --> Session: Class initialized using 'files' driver.
INFO - 2024-07-08 15:17:51 --> Controller Class Initialized
INFO - 2024-07-08 15:17:53 --> Config Class Initialized
INFO - 2024-07-08 15:17:53 --> Hooks Class Initialized
DEBUG - 2024-07-08 15:17:53 --> UTF-8 Support Enabled
INFO - 2024-07-08 15:17:53 --> Utf8 Class Initialized
INFO - 2024-07-08 15:17:53 --> URI Class Initialized
INFO - 2024-07-08 15:17:53 --> Router Class Initialized
INFO - 2024-07-08 15:17:53 --> Output Class Initialized
INFO - 2024-07-08 15:17:53 --> Security Class Initialized
DEBUG - 2024-07-08 15:17:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-07-08 15:17:53 --> Input Class Initialized
INFO - 2024-07-08 15:17:53 --> Language Class Initialized
INFO - 2024-07-08 15:17:53 --> Language Class Initialized
INFO - 2024-07-08 15:17:53 --> Config Class Initialized
INFO - 2024-07-08 15:17:53 --> Loader Class Initialized
INFO - 2024-07-08 15:17:53 --> Helper loaded: url_helper
INFO - 2024-07-08 15:17:53 --> Helper loaded: file_helper
INFO - 2024-07-08 15:17:53 --> Helper loaded: form_helper
INFO - 2024-07-08 15:17:53 --> Helper loaded: my_helper
INFO - 2024-07-08 15:17:53 --> Database Driver Class Initialized
INFO - 2024-07-08 15:17:53 --> Session: Class initialized using 'files' driver.
INFO - 2024-07-08 15:17:53 --> Controller Class Initialized
INFO - 2024-07-08 15:17:53 --> Config Class Initialized
INFO - 2024-07-08 15:17:53 --> Hooks Class Initialized
DEBUG - 2024-07-08 15:17:53 --> UTF-8 Support Enabled
INFO - 2024-07-08 15:17:53 --> Utf8 Class Initialized
INFO - 2024-07-08 15:17:53 --> URI Class Initialized
INFO - 2024-07-08 15:17:53 --> Router Class Initialized
INFO - 2024-07-08 15:17:53 --> Output Class Initialized
INFO - 2024-07-08 15:17:53 --> Security Class Initialized
DEBUG - 2024-07-08 15:17:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-07-08 15:17:53 --> Input Class Initialized
INFO - 2024-07-08 15:17:53 --> Language Class Initialized
INFO - 2024-07-08 15:17:53 --> Language Class Initialized
INFO - 2024-07-08 15:17:53 --> Config Class Initialized
INFO - 2024-07-08 15:17:53 --> Loader Class Initialized
INFO - 2024-07-08 15:17:53 --> Helper loaded: url_helper
INFO - 2024-07-08 15:17:53 --> Helper loaded: file_helper
INFO - 2024-07-08 15:17:53 --> Helper loaded: form_helper
INFO - 2024-07-08 15:17:53 --> Helper loaded: my_helper
INFO - 2024-07-08 15:17:53 --> Database Driver Class Initialized
INFO - 2024-07-08 15:17:53 --> Session: Class initialized using 'files' driver.
INFO - 2024-07-08 15:17:53 --> Controller Class Initialized
DEBUG - 2024-07-08 15:17:53 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/data_siswa/views/list.php
DEBUG - 2024-07-08 15:17:53 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-07-08 15:17:53 --> Final output sent to browser
DEBUG - 2024-07-08 15:17:53 --> Total execution time: 0.0377
INFO - 2024-07-08 15:17:54 --> Config Class Initialized
INFO - 2024-07-08 15:17:54 --> Hooks Class Initialized
DEBUG - 2024-07-08 15:17:54 --> UTF-8 Support Enabled
INFO - 2024-07-08 15:17:54 --> Utf8 Class Initialized
INFO - 2024-07-08 15:17:54 --> URI Class Initialized
INFO - 2024-07-08 15:17:54 --> Router Class Initialized
INFO - 2024-07-08 15:17:54 --> Output Class Initialized
INFO - 2024-07-08 15:17:54 --> Security Class Initialized
DEBUG - 2024-07-08 15:17:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-07-08 15:17:54 --> Input Class Initialized
INFO - 2024-07-08 15:17:54 --> Language Class Initialized
ERROR - 2024-07-08 15:17:54 --> 404 Page Not Found: /index
INFO - 2024-07-08 15:17:54 --> Config Class Initialized
INFO - 2024-07-08 15:17:54 --> Hooks Class Initialized
DEBUG - 2024-07-08 15:17:54 --> UTF-8 Support Enabled
INFO - 2024-07-08 15:17:54 --> Utf8 Class Initialized
INFO - 2024-07-08 15:17:54 --> URI Class Initialized
INFO - 2024-07-08 15:17:54 --> Router Class Initialized
INFO - 2024-07-08 15:17:54 --> Output Class Initialized
INFO - 2024-07-08 15:17:54 --> Security Class Initialized
DEBUG - 2024-07-08 15:17:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-07-08 15:17:54 --> Input Class Initialized
INFO - 2024-07-08 15:17:54 --> Language Class Initialized
INFO - 2024-07-08 15:17:54 --> Language Class Initialized
INFO - 2024-07-08 15:17:54 --> Config Class Initialized
INFO - 2024-07-08 15:17:54 --> Loader Class Initialized
INFO - 2024-07-08 15:17:54 --> Helper loaded: url_helper
INFO - 2024-07-08 15:17:54 --> Helper loaded: file_helper
INFO - 2024-07-08 15:17:54 --> Helper loaded: form_helper
INFO - 2024-07-08 15:17:54 --> Helper loaded: my_helper
INFO - 2024-07-08 15:17:54 --> Database Driver Class Initialized
INFO - 2024-07-08 15:17:54 --> Session: Class initialized using 'files' driver.
INFO - 2024-07-08 15:17:54 --> Controller Class Initialized
INFO - 2024-07-08 15:17:55 --> Config Class Initialized
INFO - 2024-07-08 15:17:55 --> Hooks Class Initialized
DEBUG - 2024-07-08 15:17:55 --> UTF-8 Support Enabled
INFO - 2024-07-08 15:17:55 --> Utf8 Class Initialized
INFO - 2024-07-08 15:17:55 --> URI Class Initialized
INFO - 2024-07-08 15:17:55 --> Router Class Initialized
INFO - 2024-07-08 15:17:55 --> Output Class Initialized
INFO - 2024-07-08 15:17:55 --> Security Class Initialized
DEBUG - 2024-07-08 15:17:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-07-08 15:17:55 --> Input Class Initialized
INFO - 2024-07-08 15:17:55 --> Language Class Initialized
INFO - 2024-07-08 15:17:55 --> Language Class Initialized
INFO - 2024-07-08 15:17:55 --> Config Class Initialized
INFO - 2024-07-08 15:17:55 --> Loader Class Initialized
INFO - 2024-07-08 15:17:55 --> Helper loaded: url_helper
INFO - 2024-07-08 15:17:55 --> Helper loaded: file_helper
INFO - 2024-07-08 15:17:55 --> Helper loaded: form_helper
INFO - 2024-07-08 15:17:55 --> Helper loaded: my_helper
INFO - 2024-07-08 15:17:55 --> Database Driver Class Initialized
INFO - 2024-07-08 15:17:55 --> Session: Class initialized using 'files' driver.
INFO - 2024-07-08 15:17:55 --> Controller Class Initialized
INFO - 2024-07-08 15:17:57 --> Config Class Initialized
INFO - 2024-07-08 15:17:57 --> Hooks Class Initialized
DEBUG - 2024-07-08 15:17:57 --> UTF-8 Support Enabled
INFO - 2024-07-08 15:17:57 --> Utf8 Class Initialized
INFO - 2024-07-08 15:17:57 --> URI Class Initialized
INFO - 2024-07-08 15:17:57 --> Router Class Initialized
INFO - 2024-07-08 15:17:57 --> Output Class Initialized
INFO - 2024-07-08 15:17:57 --> Security Class Initialized
DEBUG - 2024-07-08 15:17:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-07-08 15:17:57 --> Input Class Initialized
INFO - 2024-07-08 15:17:57 --> Language Class Initialized
INFO - 2024-07-08 15:17:57 --> Language Class Initialized
INFO - 2024-07-08 15:17:57 --> Config Class Initialized
INFO - 2024-07-08 15:17:57 --> Loader Class Initialized
INFO - 2024-07-08 15:17:57 --> Helper loaded: url_helper
INFO - 2024-07-08 15:17:57 --> Helper loaded: file_helper
INFO - 2024-07-08 15:17:57 --> Helper loaded: form_helper
INFO - 2024-07-08 15:17:57 --> Helper loaded: my_helper
INFO - 2024-07-08 15:17:57 --> Database Driver Class Initialized
INFO - 2024-07-08 15:17:57 --> Session: Class initialized using 'files' driver.
INFO - 2024-07-08 15:17:57 --> Controller Class Initialized
INFO - 2024-07-08 15:17:57 --> Config Class Initialized
INFO - 2024-07-08 15:17:57 --> Hooks Class Initialized
DEBUG - 2024-07-08 15:17:57 --> UTF-8 Support Enabled
INFO - 2024-07-08 15:17:57 --> Utf8 Class Initialized
INFO - 2024-07-08 15:17:57 --> URI Class Initialized
INFO - 2024-07-08 15:17:57 --> Router Class Initialized
INFO - 2024-07-08 15:17:57 --> Output Class Initialized
INFO - 2024-07-08 15:17:57 --> Security Class Initialized
DEBUG - 2024-07-08 15:17:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-07-08 15:17:57 --> Input Class Initialized
INFO - 2024-07-08 15:17:57 --> Language Class Initialized
INFO - 2024-07-08 15:17:57 --> Language Class Initialized
INFO - 2024-07-08 15:17:57 --> Config Class Initialized
INFO - 2024-07-08 15:17:57 --> Loader Class Initialized
INFO - 2024-07-08 15:17:57 --> Helper loaded: url_helper
INFO - 2024-07-08 15:17:57 --> Helper loaded: file_helper
INFO - 2024-07-08 15:17:57 --> Helper loaded: form_helper
INFO - 2024-07-08 15:17:57 --> Helper loaded: my_helper
INFO - 2024-07-08 15:17:57 --> Database Driver Class Initialized
INFO - 2024-07-08 15:17:57 --> Session: Class initialized using 'files' driver.
INFO - 2024-07-08 15:17:57 --> Controller Class Initialized
DEBUG - 2024-07-08 15:17:57 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/data_siswa/views/list.php
DEBUG - 2024-07-08 15:17:57 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-07-08 15:17:57 --> Final output sent to browser
DEBUG - 2024-07-08 15:17:57 --> Total execution time: 0.0551
INFO - 2024-07-08 15:17:57 --> Config Class Initialized
INFO - 2024-07-08 15:17:57 --> Hooks Class Initialized
DEBUG - 2024-07-08 15:17:57 --> UTF-8 Support Enabled
INFO - 2024-07-08 15:17:57 --> Utf8 Class Initialized
INFO - 2024-07-08 15:17:57 --> URI Class Initialized
INFO - 2024-07-08 15:17:57 --> Router Class Initialized
INFO - 2024-07-08 15:17:57 --> Output Class Initialized
INFO - 2024-07-08 15:17:57 --> Security Class Initialized
DEBUG - 2024-07-08 15:17:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-07-08 15:17:57 --> Input Class Initialized
INFO - 2024-07-08 15:17:57 --> Language Class Initialized
ERROR - 2024-07-08 15:17:57 --> 404 Page Not Found: /index
INFO - 2024-07-08 15:17:57 --> Config Class Initialized
INFO - 2024-07-08 15:17:57 --> Hooks Class Initialized
DEBUG - 2024-07-08 15:17:57 --> UTF-8 Support Enabled
INFO - 2024-07-08 15:17:57 --> Utf8 Class Initialized
INFO - 2024-07-08 15:17:57 --> URI Class Initialized
INFO - 2024-07-08 15:17:57 --> Router Class Initialized
INFO - 2024-07-08 15:17:57 --> Output Class Initialized
INFO - 2024-07-08 15:17:57 --> Security Class Initialized
DEBUG - 2024-07-08 15:17:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-07-08 15:17:57 --> Input Class Initialized
INFO - 2024-07-08 15:17:57 --> Language Class Initialized
INFO - 2024-07-08 15:17:57 --> Language Class Initialized
INFO - 2024-07-08 15:17:57 --> Config Class Initialized
INFO - 2024-07-08 15:17:57 --> Loader Class Initialized
INFO - 2024-07-08 15:17:57 --> Helper loaded: url_helper
INFO - 2024-07-08 15:17:57 --> Helper loaded: file_helper
INFO - 2024-07-08 15:17:57 --> Helper loaded: form_helper
INFO - 2024-07-08 15:17:57 --> Helper loaded: my_helper
INFO - 2024-07-08 15:17:57 --> Database Driver Class Initialized
INFO - 2024-07-08 15:17:57 --> Session: Class initialized using 'files' driver.
INFO - 2024-07-08 15:17:57 --> Controller Class Initialized
INFO - 2024-07-08 15:17:59 --> Config Class Initialized
INFO - 2024-07-08 15:17:59 --> Hooks Class Initialized
DEBUG - 2024-07-08 15:17:59 --> UTF-8 Support Enabled
INFO - 2024-07-08 15:17:59 --> Utf8 Class Initialized
INFO - 2024-07-08 15:17:59 --> URI Class Initialized
INFO - 2024-07-08 15:17:59 --> Router Class Initialized
INFO - 2024-07-08 15:17:59 --> Output Class Initialized
INFO - 2024-07-08 15:17:59 --> Security Class Initialized
DEBUG - 2024-07-08 15:17:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-07-08 15:17:59 --> Input Class Initialized
INFO - 2024-07-08 15:17:59 --> Language Class Initialized
INFO - 2024-07-08 15:17:59 --> Language Class Initialized
INFO - 2024-07-08 15:17:59 --> Config Class Initialized
INFO - 2024-07-08 15:17:59 --> Loader Class Initialized
INFO - 2024-07-08 15:17:59 --> Helper loaded: url_helper
INFO - 2024-07-08 15:17:59 --> Helper loaded: file_helper
INFO - 2024-07-08 15:17:59 --> Helper loaded: form_helper
INFO - 2024-07-08 15:17:59 --> Helper loaded: my_helper
INFO - 2024-07-08 15:17:59 --> Database Driver Class Initialized
INFO - 2024-07-08 15:17:59 --> Session: Class initialized using 'files' driver.
INFO - 2024-07-08 15:17:59 --> Controller Class Initialized
INFO - 2024-07-08 15:18:01 --> Config Class Initialized
INFO - 2024-07-08 15:18:01 --> Hooks Class Initialized
DEBUG - 2024-07-08 15:18:01 --> UTF-8 Support Enabled
INFO - 2024-07-08 15:18:01 --> Utf8 Class Initialized
INFO - 2024-07-08 15:18:01 --> URI Class Initialized
INFO - 2024-07-08 15:18:01 --> Router Class Initialized
INFO - 2024-07-08 15:18:01 --> Output Class Initialized
INFO - 2024-07-08 15:18:01 --> Security Class Initialized
DEBUG - 2024-07-08 15:18:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-07-08 15:18:01 --> Input Class Initialized
INFO - 2024-07-08 15:18:01 --> Language Class Initialized
INFO - 2024-07-08 15:18:01 --> Language Class Initialized
INFO - 2024-07-08 15:18:01 --> Config Class Initialized
INFO - 2024-07-08 15:18:01 --> Loader Class Initialized
INFO - 2024-07-08 15:18:01 --> Helper loaded: url_helper
INFO - 2024-07-08 15:18:01 --> Helper loaded: file_helper
INFO - 2024-07-08 15:18:01 --> Helper loaded: form_helper
INFO - 2024-07-08 15:18:01 --> Helper loaded: my_helper
INFO - 2024-07-08 15:18:01 --> Database Driver Class Initialized
INFO - 2024-07-08 15:18:01 --> Session: Class initialized using 'files' driver.
INFO - 2024-07-08 15:18:01 --> Controller Class Initialized
INFO - 2024-07-08 15:18:02 --> Config Class Initialized
INFO - 2024-07-08 15:18:02 --> Hooks Class Initialized
DEBUG - 2024-07-08 15:18:02 --> UTF-8 Support Enabled
INFO - 2024-07-08 15:18:02 --> Utf8 Class Initialized
INFO - 2024-07-08 15:18:02 --> URI Class Initialized
INFO - 2024-07-08 15:18:02 --> Router Class Initialized
INFO - 2024-07-08 15:18:02 --> Output Class Initialized
INFO - 2024-07-08 15:18:02 --> Security Class Initialized
DEBUG - 2024-07-08 15:18:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-07-08 15:18:02 --> Input Class Initialized
INFO - 2024-07-08 15:18:02 --> Language Class Initialized
INFO - 2024-07-08 15:18:02 --> Language Class Initialized
INFO - 2024-07-08 15:18:02 --> Config Class Initialized
INFO - 2024-07-08 15:18:02 --> Loader Class Initialized
INFO - 2024-07-08 15:18:02 --> Helper loaded: url_helper
INFO - 2024-07-08 15:18:02 --> Helper loaded: file_helper
INFO - 2024-07-08 15:18:02 --> Helper loaded: form_helper
INFO - 2024-07-08 15:18:02 --> Helper loaded: my_helper
INFO - 2024-07-08 15:18:02 --> Database Driver Class Initialized
INFO - 2024-07-08 15:18:02 --> Session: Class initialized using 'files' driver.
INFO - 2024-07-08 15:18:02 --> Controller Class Initialized
DEBUG - 2024-07-08 15:18:02 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/data_siswa/views/list.php
DEBUG - 2024-07-08 15:18:02 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-07-08 15:18:02 --> Final output sent to browser
DEBUG - 2024-07-08 15:18:02 --> Total execution time: 0.0894
INFO - 2024-07-08 15:18:02 --> Config Class Initialized
INFO - 2024-07-08 15:18:02 --> Hooks Class Initialized
DEBUG - 2024-07-08 15:18:02 --> UTF-8 Support Enabled
INFO - 2024-07-08 15:18:02 --> Utf8 Class Initialized
INFO - 2024-07-08 15:18:02 --> URI Class Initialized
INFO - 2024-07-08 15:18:02 --> Router Class Initialized
INFO - 2024-07-08 15:18:02 --> Output Class Initialized
INFO - 2024-07-08 15:18:02 --> Security Class Initialized
DEBUG - 2024-07-08 15:18:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-07-08 15:18:02 --> Input Class Initialized
INFO - 2024-07-08 15:18:02 --> Language Class Initialized
ERROR - 2024-07-08 15:18:02 --> 404 Page Not Found: /index
INFO - 2024-07-08 15:18:02 --> Config Class Initialized
INFO - 2024-07-08 15:18:02 --> Hooks Class Initialized
DEBUG - 2024-07-08 15:18:02 --> UTF-8 Support Enabled
INFO - 2024-07-08 15:18:02 --> Utf8 Class Initialized
INFO - 2024-07-08 15:18:02 --> URI Class Initialized
INFO - 2024-07-08 15:18:02 --> Router Class Initialized
INFO - 2024-07-08 15:18:02 --> Output Class Initialized
INFO - 2024-07-08 15:18:02 --> Security Class Initialized
DEBUG - 2024-07-08 15:18:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-07-08 15:18:02 --> Input Class Initialized
INFO - 2024-07-08 15:18:02 --> Language Class Initialized
INFO - 2024-07-08 15:18:02 --> Language Class Initialized
INFO - 2024-07-08 15:18:02 --> Config Class Initialized
INFO - 2024-07-08 15:18:02 --> Loader Class Initialized
INFO - 2024-07-08 15:18:02 --> Helper loaded: url_helper
INFO - 2024-07-08 15:18:02 --> Helper loaded: file_helper
INFO - 2024-07-08 15:18:02 --> Helper loaded: form_helper
INFO - 2024-07-08 15:18:02 --> Helper loaded: my_helper
INFO - 2024-07-08 15:18:02 --> Database Driver Class Initialized
INFO - 2024-07-08 15:18:02 --> Session: Class initialized using 'files' driver.
INFO - 2024-07-08 15:18:02 --> Controller Class Initialized
INFO - 2024-07-08 15:18:03 --> Config Class Initialized
INFO - 2024-07-08 15:18:03 --> Hooks Class Initialized
DEBUG - 2024-07-08 15:18:03 --> UTF-8 Support Enabled
INFO - 2024-07-08 15:18:03 --> Utf8 Class Initialized
INFO - 2024-07-08 15:18:03 --> URI Class Initialized
INFO - 2024-07-08 15:18:03 --> Router Class Initialized
INFO - 2024-07-08 15:18:03 --> Output Class Initialized
INFO - 2024-07-08 15:18:03 --> Security Class Initialized
DEBUG - 2024-07-08 15:18:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-07-08 15:18:03 --> Input Class Initialized
INFO - 2024-07-08 15:18:03 --> Language Class Initialized
INFO - 2024-07-08 15:18:03 --> Language Class Initialized
INFO - 2024-07-08 15:18:03 --> Config Class Initialized
INFO - 2024-07-08 15:18:03 --> Loader Class Initialized
INFO - 2024-07-08 15:18:03 --> Helper loaded: url_helper
INFO - 2024-07-08 15:18:03 --> Helper loaded: file_helper
INFO - 2024-07-08 15:18:03 --> Helper loaded: form_helper
INFO - 2024-07-08 15:18:03 --> Helper loaded: my_helper
INFO - 2024-07-08 15:18:03 --> Database Driver Class Initialized
INFO - 2024-07-08 15:18:03 --> Session: Class initialized using 'files' driver.
INFO - 2024-07-08 15:18:03 --> Controller Class Initialized
INFO - 2024-07-08 15:18:06 --> Config Class Initialized
INFO - 2024-07-08 15:18:06 --> Hooks Class Initialized
DEBUG - 2024-07-08 15:18:06 --> UTF-8 Support Enabled
INFO - 2024-07-08 15:18:06 --> Utf8 Class Initialized
INFO - 2024-07-08 15:18:06 --> URI Class Initialized
INFO - 2024-07-08 15:18:06 --> Router Class Initialized
INFO - 2024-07-08 15:18:06 --> Output Class Initialized
INFO - 2024-07-08 15:18:06 --> Security Class Initialized
DEBUG - 2024-07-08 15:18:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-07-08 15:18:06 --> Input Class Initialized
INFO - 2024-07-08 15:18:06 --> Language Class Initialized
INFO - 2024-07-08 15:18:06 --> Language Class Initialized
INFO - 2024-07-08 15:18:06 --> Config Class Initialized
INFO - 2024-07-08 15:18:06 --> Loader Class Initialized
INFO - 2024-07-08 15:18:06 --> Helper loaded: url_helper
INFO - 2024-07-08 15:18:06 --> Helper loaded: file_helper
INFO - 2024-07-08 15:18:06 --> Helper loaded: form_helper
INFO - 2024-07-08 15:18:06 --> Helper loaded: my_helper
INFO - 2024-07-08 15:18:06 --> Database Driver Class Initialized
INFO - 2024-07-08 15:18:06 --> Session: Class initialized using 'files' driver.
INFO - 2024-07-08 15:18:06 --> Controller Class Initialized
INFO - 2024-07-08 15:18:06 --> Config Class Initialized
INFO - 2024-07-08 15:18:06 --> Hooks Class Initialized
DEBUG - 2024-07-08 15:18:06 --> UTF-8 Support Enabled
INFO - 2024-07-08 15:18:06 --> Utf8 Class Initialized
INFO - 2024-07-08 15:18:06 --> URI Class Initialized
INFO - 2024-07-08 15:18:06 --> Router Class Initialized
INFO - 2024-07-08 15:18:06 --> Output Class Initialized
INFO - 2024-07-08 15:18:06 --> Security Class Initialized
DEBUG - 2024-07-08 15:18:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-07-08 15:18:06 --> Input Class Initialized
INFO - 2024-07-08 15:18:06 --> Language Class Initialized
INFO - 2024-07-08 15:18:06 --> Language Class Initialized
INFO - 2024-07-08 15:18:06 --> Config Class Initialized
INFO - 2024-07-08 15:18:06 --> Loader Class Initialized
INFO - 2024-07-08 15:18:06 --> Helper loaded: url_helper
INFO - 2024-07-08 15:18:06 --> Helper loaded: file_helper
INFO - 2024-07-08 15:18:06 --> Helper loaded: form_helper
INFO - 2024-07-08 15:18:06 --> Helper loaded: my_helper
INFO - 2024-07-08 15:18:06 --> Database Driver Class Initialized
INFO - 2024-07-08 15:18:06 --> Session: Class initialized using 'files' driver.
INFO - 2024-07-08 15:18:06 --> Controller Class Initialized
DEBUG - 2024-07-08 15:18:06 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/data_siswa/views/list.php
DEBUG - 2024-07-08 15:18:06 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-07-08 15:18:06 --> Final output sent to browser
DEBUG - 2024-07-08 15:18:06 --> Total execution time: 0.0364
INFO - 2024-07-08 15:18:06 --> Config Class Initialized
INFO - 2024-07-08 15:18:06 --> Hooks Class Initialized
DEBUG - 2024-07-08 15:18:06 --> UTF-8 Support Enabled
INFO - 2024-07-08 15:18:06 --> Utf8 Class Initialized
INFO - 2024-07-08 15:18:06 --> URI Class Initialized
INFO - 2024-07-08 15:18:06 --> Router Class Initialized
INFO - 2024-07-08 15:18:06 --> Output Class Initialized
INFO - 2024-07-08 15:18:06 --> Security Class Initialized
DEBUG - 2024-07-08 15:18:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-07-08 15:18:06 --> Input Class Initialized
INFO - 2024-07-08 15:18:06 --> Language Class Initialized
ERROR - 2024-07-08 15:18:06 --> 404 Page Not Found: /index
INFO - 2024-07-08 15:18:06 --> Config Class Initialized
INFO - 2024-07-08 15:18:06 --> Hooks Class Initialized
DEBUG - 2024-07-08 15:18:06 --> UTF-8 Support Enabled
INFO - 2024-07-08 15:18:06 --> Utf8 Class Initialized
INFO - 2024-07-08 15:18:06 --> URI Class Initialized
INFO - 2024-07-08 15:18:06 --> Router Class Initialized
INFO - 2024-07-08 15:18:06 --> Output Class Initialized
INFO - 2024-07-08 15:18:06 --> Security Class Initialized
DEBUG - 2024-07-08 15:18:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-07-08 15:18:06 --> Input Class Initialized
INFO - 2024-07-08 15:18:06 --> Language Class Initialized
INFO - 2024-07-08 15:18:06 --> Language Class Initialized
INFO - 2024-07-08 15:18:06 --> Config Class Initialized
INFO - 2024-07-08 15:18:06 --> Loader Class Initialized
INFO - 2024-07-08 15:18:06 --> Helper loaded: url_helper
INFO - 2024-07-08 15:18:06 --> Helper loaded: file_helper
INFO - 2024-07-08 15:18:06 --> Helper loaded: form_helper
INFO - 2024-07-08 15:18:06 --> Helper loaded: my_helper
INFO - 2024-07-08 15:18:06 --> Database Driver Class Initialized
INFO - 2024-07-08 15:18:06 --> Session: Class initialized using 'files' driver.
INFO - 2024-07-08 15:18:06 --> Controller Class Initialized
INFO - 2024-07-08 15:18:08 --> Config Class Initialized
INFO - 2024-07-08 15:18:08 --> Hooks Class Initialized
DEBUG - 2024-07-08 15:18:08 --> UTF-8 Support Enabled
INFO - 2024-07-08 15:18:08 --> Utf8 Class Initialized
INFO - 2024-07-08 15:18:08 --> URI Class Initialized
INFO - 2024-07-08 15:18:08 --> Router Class Initialized
INFO - 2024-07-08 15:18:08 --> Output Class Initialized
INFO - 2024-07-08 15:18:08 --> Security Class Initialized
DEBUG - 2024-07-08 15:18:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-07-08 15:18:08 --> Input Class Initialized
INFO - 2024-07-08 15:18:08 --> Language Class Initialized
INFO - 2024-07-08 15:18:08 --> Language Class Initialized
INFO - 2024-07-08 15:18:08 --> Config Class Initialized
INFO - 2024-07-08 15:18:08 --> Loader Class Initialized
INFO - 2024-07-08 15:18:08 --> Helper loaded: url_helper
INFO - 2024-07-08 15:18:08 --> Helper loaded: file_helper
INFO - 2024-07-08 15:18:08 --> Helper loaded: form_helper
INFO - 2024-07-08 15:18:08 --> Helper loaded: my_helper
INFO - 2024-07-08 15:18:08 --> Database Driver Class Initialized
INFO - 2024-07-08 15:18:08 --> Session: Class initialized using 'files' driver.
INFO - 2024-07-08 15:18:08 --> Controller Class Initialized
INFO - 2024-07-08 15:18:10 --> Config Class Initialized
INFO - 2024-07-08 15:18:10 --> Hooks Class Initialized
DEBUG - 2024-07-08 15:18:10 --> UTF-8 Support Enabled
INFO - 2024-07-08 15:18:10 --> Utf8 Class Initialized
INFO - 2024-07-08 15:18:10 --> URI Class Initialized
INFO - 2024-07-08 15:18:10 --> Router Class Initialized
INFO - 2024-07-08 15:18:10 --> Output Class Initialized
INFO - 2024-07-08 15:18:10 --> Security Class Initialized
DEBUG - 2024-07-08 15:18:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-07-08 15:18:10 --> Input Class Initialized
INFO - 2024-07-08 15:18:10 --> Language Class Initialized
INFO - 2024-07-08 15:18:10 --> Language Class Initialized
INFO - 2024-07-08 15:18:10 --> Config Class Initialized
INFO - 2024-07-08 15:18:10 --> Loader Class Initialized
INFO - 2024-07-08 15:18:10 --> Helper loaded: url_helper
INFO - 2024-07-08 15:18:10 --> Helper loaded: file_helper
INFO - 2024-07-08 15:18:10 --> Helper loaded: form_helper
INFO - 2024-07-08 15:18:10 --> Helper loaded: my_helper
INFO - 2024-07-08 15:18:10 --> Database Driver Class Initialized
INFO - 2024-07-08 15:18:10 --> Session: Class initialized using 'files' driver.
INFO - 2024-07-08 15:18:10 --> Controller Class Initialized
INFO - 2024-07-08 15:18:10 --> Config Class Initialized
INFO - 2024-07-08 15:18:10 --> Hooks Class Initialized
DEBUG - 2024-07-08 15:18:10 --> UTF-8 Support Enabled
INFO - 2024-07-08 15:18:10 --> Utf8 Class Initialized
INFO - 2024-07-08 15:18:10 --> URI Class Initialized
INFO - 2024-07-08 15:18:10 --> Router Class Initialized
INFO - 2024-07-08 15:18:10 --> Output Class Initialized
INFO - 2024-07-08 15:18:10 --> Security Class Initialized
DEBUG - 2024-07-08 15:18:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-07-08 15:18:10 --> Input Class Initialized
INFO - 2024-07-08 15:18:10 --> Language Class Initialized
INFO - 2024-07-08 15:18:10 --> Language Class Initialized
INFO - 2024-07-08 15:18:10 --> Config Class Initialized
INFO - 2024-07-08 15:18:10 --> Loader Class Initialized
INFO - 2024-07-08 15:18:10 --> Helper loaded: url_helper
INFO - 2024-07-08 15:18:10 --> Helper loaded: file_helper
INFO - 2024-07-08 15:18:10 --> Helper loaded: form_helper
INFO - 2024-07-08 15:18:10 --> Helper loaded: my_helper
INFO - 2024-07-08 15:18:10 --> Database Driver Class Initialized
INFO - 2024-07-08 15:18:10 --> Session: Class initialized using 'files' driver.
INFO - 2024-07-08 15:18:10 --> Controller Class Initialized
DEBUG - 2024-07-08 15:18:10 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/data_siswa/views/list.php
DEBUG - 2024-07-08 15:18:10 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-07-08 15:18:10 --> Final output sent to browser
DEBUG - 2024-07-08 15:18:10 --> Total execution time: 0.0366
INFO - 2024-07-08 15:18:10 --> Config Class Initialized
INFO - 2024-07-08 15:18:10 --> Hooks Class Initialized
DEBUG - 2024-07-08 15:18:10 --> UTF-8 Support Enabled
INFO - 2024-07-08 15:18:10 --> Utf8 Class Initialized
INFO - 2024-07-08 15:18:10 --> URI Class Initialized
INFO - 2024-07-08 15:18:10 --> Router Class Initialized
INFO - 2024-07-08 15:18:10 --> Output Class Initialized
INFO - 2024-07-08 15:18:10 --> Security Class Initialized
DEBUG - 2024-07-08 15:18:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-07-08 15:18:10 --> Input Class Initialized
INFO - 2024-07-08 15:18:10 --> Language Class Initialized
ERROR - 2024-07-08 15:18:10 --> 404 Page Not Found: /index
INFO - 2024-07-08 15:18:11 --> Config Class Initialized
INFO - 2024-07-08 15:18:11 --> Hooks Class Initialized
DEBUG - 2024-07-08 15:18:11 --> UTF-8 Support Enabled
INFO - 2024-07-08 15:18:11 --> Utf8 Class Initialized
INFO - 2024-07-08 15:18:11 --> URI Class Initialized
INFO - 2024-07-08 15:18:11 --> Router Class Initialized
INFO - 2024-07-08 15:18:11 --> Output Class Initialized
INFO - 2024-07-08 15:18:11 --> Security Class Initialized
DEBUG - 2024-07-08 15:18:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-07-08 15:18:11 --> Input Class Initialized
INFO - 2024-07-08 15:18:11 --> Language Class Initialized
INFO - 2024-07-08 15:18:11 --> Language Class Initialized
INFO - 2024-07-08 15:18:11 --> Config Class Initialized
INFO - 2024-07-08 15:18:11 --> Loader Class Initialized
INFO - 2024-07-08 15:18:11 --> Helper loaded: url_helper
INFO - 2024-07-08 15:18:11 --> Helper loaded: file_helper
INFO - 2024-07-08 15:18:11 --> Helper loaded: form_helper
INFO - 2024-07-08 15:18:11 --> Helper loaded: my_helper
INFO - 2024-07-08 15:18:11 --> Database Driver Class Initialized
INFO - 2024-07-08 15:18:11 --> Session: Class initialized using 'files' driver.
INFO - 2024-07-08 15:18:11 --> Controller Class Initialized
INFO - 2024-07-08 15:18:12 --> Config Class Initialized
INFO - 2024-07-08 15:18:12 --> Hooks Class Initialized
DEBUG - 2024-07-08 15:18:12 --> UTF-8 Support Enabled
INFO - 2024-07-08 15:18:12 --> Utf8 Class Initialized
INFO - 2024-07-08 15:18:12 --> URI Class Initialized
INFO - 2024-07-08 15:18:12 --> Router Class Initialized
INFO - 2024-07-08 15:18:12 --> Output Class Initialized
INFO - 2024-07-08 15:18:12 --> Security Class Initialized
DEBUG - 2024-07-08 15:18:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-07-08 15:18:12 --> Input Class Initialized
INFO - 2024-07-08 15:18:12 --> Language Class Initialized
INFO - 2024-07-08 15:18:12 --> Language Class Initialized
INFO - 2024-07-08 15:18:12 --> Config Class Initialized
INFO - 2024-07-08 15:18:12 --> Loader Class Initialized
INFO - 2024-07-08 15:18:12 --> Helper loaded: url_helper
INFO - 2024-07-08 15:18:12 --> Helper loaded: file_helper
INFO - 2024-07-08 15:18:12 --> Helper loaded: form_helper
INFO - 2024-07-08 15:18:12 --> Helper loaded: my_helper
INFO - 2024-07-08 15:18:12 --> Database Driver Class Initialized
INFO - 2024-07-08 15:18:12 --> Session: Class initialized using 'files' driver.
INFO - 2024-07-08 15:18:12 --> Controller Class Initialized
INFO - 2024-07-08 15:18:14 --> Config Class Initialized
INFO - 2024-07-08 15:18:14 --> Hooks Class Initialized
DEBUG - 2024-07-08 15:18:14 --> UTF-8 Support Enabled
INFO - 2024-07-08 15:18:14 --> Utf8 Class Initialized
INFO - 2024-07-08 15:18:14 --> URI Class Initialized
INFO - 2024-07-08 15:18:14 --> Router Class Initialized
INFO - 2024-07-08 15:18:14 --> Output Class Initialized
INFO - 2024-07-08 15:18:14 --> Security Class Initialized
DEBUG - 2024-07-08 15:18:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-07-08 15:18:14 --> Input Class Initialized
INFO - 2024-07-08 15:18:14 --> Language Class Initialized
INFO - 2024-07-08 15:18:14 --> Language Class Initialized
INFO - 2024-07-08 15:18:14 --> Config Class Initialized
INFO - 2024-07-08 15:18:14 --> Loader Class Initialized
INFO - 2024-07-08 15:18:14 --> Helper loaded: url_helper
INFO - 2024-07-08 15:18:14 --> Helper loaded: file_helper
INFO - 2024-07-08 15:18:14 --> Helper loaded: form_helper
INFO - 2024-07-08 15:18:14 --> Helper loaded: my_helper
INFO - 2024-07-08 15:18:14 --> Database Driver Class Initialized
INFO - 2024-07-08 15:18:14 --> Session: Class initialized using 'files' driver.
INFO - 2024-07-08 15:18:14 --> Controller Class Initialized
INFO - 2024-07-08 15:18:14 --> Config Class Initialized
INFO - 2024-07-08 15:18:14 --> Hooks Class Initialized
DEBUG - 2024-07-08 15:18:14 --> UTF-8 Support Enabled
INFO - 2024-07-08 15:18:14 --> Utf8 Class Initialized
INFO - 2024-07-08 15:18:14 --> URI Class Initialized
INFO - 2024-07-08 15:18:14 --> Router Class Initialized
INFO - 2024-07-08 15:18:14 --> Output Class Initialized
INFO - 2024-07-08 15:18:14 --> Security Class Initialized
DEBUG - 2024-07-08 15:18:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-07-08 15:18:14 --> Input Class Initialized
INFO - 2024-07-08 15:18:14 --> Language Class Initialized
INFO - 2024-07-08 15:18:14 --> Language Class Initialized
INFO - 2024-07-08 15:18:14 --> Config Class Initialized
INFO - 2024-07-08 15:18:14 --> Loader Class Initialized
INFO - 2024-07-08 15:18:14 --> Helper loaded: url_helper
INFO - 2024-07-08 15:18:14 --> Helper loaded: file_helper
INFO - 2024-07-08 15:18:14 --> Helper loaded: form_helper
INFO - 2024-07-08 15:18:14 --> Helper loaded: my_helper
INFO - 2024-07-08 15:18:14 --> Database Driver Class Initialized
INFO - 2024-07-08 15:18:14 --> Session: Class initialized using 'files' driver.
INFO - 2024-07-08 15:18:14 --> Controller Class Initialized
DEBUG - 2024-07-08 15:18:14 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/data_siswa/views/list.php
DEBUG - 2024-07-08 15:18:14 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-07-08 15:18:14 --> Final output sent to browser
DEBUG - 2024-07-08 15:18:14 --> Total execution time: 0.0321
INFO - 2024-07-08 15:18:14 --> Config Class Initialized
INFO - 2024-07-08 15:18:14 --> Hooks Class Initialized
DEBUG - 2024-07-08 15:18:14 --> UTF-8 Support Enabled
INFO - 2024-07-08 15:18:14 --> Utf8 Class Initialized
INFO - 2024-07-08 15:18:14 --> URI Class Initialized
INFO - 2024-07-08 15:18:14 --> Router Class Initialized
INFO - 2024-07-08 15:18:14 --> Output Class Initialized
INFO - 2024-07-08 15:18:14 --> Security Class Initialized
DEBUG - 2024-07-08 15:18:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-07-08 15:18:14 --> Input Class Initialized
INFO - 2024-07-08 15:18:14 --> Language Class Initialized
ERROR - 2024-07-08 15:18:14 --> 404 Page Not Found: /index
INFO - 2024-07-08 15:18:14 --> Config Class Initialized
INFO - 2024-07-08 15:18:14 --> Hooks Class Initialized
DEBUG - 2024-07-08 15:18:14 --> UTF-8 Support Enabled
INFO - 2024-07-08 15:18:14 --> Utf8 Class Initialized
INFO - 2024-07-08 15:18:14 --> URI Class Initialized
INFO - 2024-07-08 15:18:14 --> Router Class Initialized
INFO - 2024-07-08 15:18:14 --> Output Class Initialized
INFO - 2024-07-08 15:18:14 --> Security Class Initialized
DEBUG - 2024-07-08 15:18:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-07-08 15:18:14 --> Input Class Initialized
INFO - 2024-07-08 15:18:14 --> Language Class Initialized
INFO - 2024-07-08 15:18:14 --> Language Class Initialized
INFO - 2024-07-08 15:18:14 --> Config Class Initialized
INFO - 2024-07-08 15:18:14 --> Loader Class Initialized
INFO - 2024-07-08 15:18:14 --> Helper loaded: url_helper
INFO - 2024-07-08 15:18:14 --> Helper loaded: file_helper
INFO - 2024-07-08 15:18:14 --> Helper loaded: form_helper
INFO - 2024-07-08 15:18:14 --> Helper loaded: my_helper
INFO - 2024-07-08 15:18:14 --> Database Driver Class Initialized
INFO - 2024-07-08 15:18:14 --> Session: Class initialized using 'files' driver.
INFO - 2024-07-08 15:18:14 --> Controller Class Initialized
INFO - 2024-07-08 15:18:15 --> Config Class Initialized
INFO - 2024-07-08 15:18:15 --> Hooks Class Initialized
DEBUG - 2024-07-08 15:18:15 --> UTF-8 Support Enabled
INFO - 2024-07-08 15:18:15 --> Utf8 Class Initialized
INFO - 2024-07-08 15:18:15 --> URI Class Initialized
INFO - 2024-07-08 15:18:15 --> Router Class Initialized
INFO - 2024-07-08 15:18:15 --> Output Class Initialized
INFO - 2024-07-08 15:18:15 --> Security Class Initialized
DEBUG - 2024-07-08 15:18:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-07-08 15:18:15 --> Input Class Initialized
INFO - 2024-07-08 15:18:15 --> Language Class Initialized
INFO - 2024-07-08 15:18:15 --> Language Class Initialized
INFO - 2024-07-08 15:18:15 --> Config Class Initialized
INFO - 2024-07-08 15:18:15 --> Loader Class Initialized
INFO - 2024-07-08 15:18:15 --> Helper loaded: url_helper
INFO - 2024-07-08 15:18:15 --> Helper loaded: file_helper
INFO - 2024-07-08 15:18:15 --> Helper loaded: form_helper
INFO - 2024-07-08 15:18:15 --> Helper loaded: my_helper
INFO - 2024-07-08 15:18:15 --> Database Driver Class Initialized
INFO - 2024-07-08 15:18:15 --> Session: Class initialized using 'files' driver.
INFO - 2024-07-08 15:18:15 --> Controller Class Initialized
INFO - 2024-07-08 15:18:18 --> Config Class Initialized
INFO - 2024-07-08 15:18:18 --> Hooks Class Initialized
DEBUG - 2024-07-08 15:18:18 --> UTF-8 Support Enabled
INFO - 2024-07-08 15:18:18 --> Utf8 Class Initialized
INFO - 2024-07-08 15:18:18 --> URI Class Initialized
INFO - 2024-07-08 15:18:18 --> Router Class Initialized
INFO - 2024-07-08 15:18:18 --> Output Class Initialized
INFO - 2024-07-08 15:18:18 --> Security Class Initialized
DEBUG - 2024-07-08 15:18:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-07-08 15:18:18 --> Input Class Initialized
INFO - 2024-07-08 15:18:18 --> Language Class Initialized
INFO - 2024-07-08 15:18:18 --> Language Class Initialized
INFO - 2024-07-08 15:18:18 --> Config Class Initialized
INFO - 2024-07-08 15:18:18 --> Loader Class Initialized
INFO - 2024-07-08 15:18:18 --> Helper loaded: url_helper
INFO - 2024-07-08 15:18:18 --> Helper loaded: file_helper
INFO - 2024-07-08 15:18:18 --> Helper loaded: form_helper
INFO - 2024-07-08 15:18:18 --> Helper loaded: my_helper
INFO - 2024-07-08 15:18:18 --> Database Driver Class Initialized
INFO - 2024-07-08 15:18:18 --> Session: Class initialized using 'files' driver.
INFO - 2024-07-08 15:18:18 --> Controller Class Initialized
INFO - 2024-07-08 15:18:18 --> Config Class Initialized
INFO - 2024-07-08 15:18:18 --> Hooks Class Initialized
DEBUG - 2024-07-08 15:18:18 --> UTF-8 Support Enabled
INFO - 2024-07-08 15:18:18 --> Utf8 Class Initialized
INFO - 2024-07-08 15:18:18 --> URI Class Initialized
INFO - 2024-07-08 15:18:18 --> Router Class Initialized
INFO - 2024-07-08 15:18:18 --> Output Class Initialized
INFO - 2024-07-08 15:18:18 --> Security Class Initialized
DEBUG - 2024-07-08 15:18:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-07-08 15:18:18 --> Input Class Initialized
INFO - 2024-07-08 15:18:18 --> Language Class Initialized
INFO - 2024-07-08 15:18:18 --> Language Class Initialized
INFO - 2024-07-08 15:18:18 --> Config Class Initialized
INFO - 2024-07-08 15:18:18 --> Loader Class Initialized
INFO - 2024-07-08 15:18:18 --> Helper loaded: url_helper
INFO - 2024-07-08 15:18:18 --> Helper loaded: file_helper
INFO - 2024-07-08 15:18:18 --> Helper loaded: form_helper
INFO - 2024-07-08 15:18:18 --> Helper loaded: my_helper
INFO - 2024-07-08 15:18:18 --> Database Driver Class Initialized
INFO - 2024-07-08 15:18:18 --> Session: Class initialized using 'files' driver.
INFO - 2024-07-08 15:18:18 --> Controller Class Initialized
DEBUG - 2024-07-08 15:18:18 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/data_siswa/views/list.php
DEBUG - 2024-07-08 15:18:18 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-07-08 15:18:18 --> Final output sent to browser
DEBUG - 2024-07-08 15:18:18 --> Total execution time: 0.0379
INFO - 2024-07-08 15:18:18 --> Config Class Initialized
INFO - 2024-07-08 15:18:18 --> Hooks Class Initialized
DEBUG - 2024-07-08 15:18:18 --> UTF-8 Support Enabled
INFO - 2024-07-08 15:18:18 --> Utf8 Class Initialized
INFO - 2024-07-08 15:18:18 --> URI Class Initialized
INFO - 2024-07-08 15:18:18 --> Router Class Initialized
INFO - 2024-07-08 15:18:18 --> Output Class Initialized
INFO - 2024-07-08 15:18:18 --> Security Class Initialized
DEBUG - 2024-07-08 15:18:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-07-08 15:18:18 --> Input Class Initialized
INFO - 2024-07-08 15:18:18 --> Language Class Initialized
ERROR - 2024-07-08 15:18:18 --> 404 Page Not Found: /index
INFO - 2024-07-08 15:18:18 --> Config Class Initialized
INFO - 2024-07-08 15:18:18 --> Hooks Class Initialized
DEBUG - 2024-07-08 15:18:18 --> UTF-8 Support Enabled
INFO - 2024-07-08 15:18:18 --> Utf8 Class Initialized
INFO - 2024-07-08 15:18:18 --> URI Class Initialized
INFO - 2024-07-08 15:18:18 --> Router Class Initialized
INFO - 2024-07-08 15:18:18 --> Output Class Initialized
INFO - 2024-07-08 15:18:18 --> Security Class Initialized
DEBUG - 2024-07-08 15:18:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-07-08 15:18:18 --> Input Class Initialized
INFO - 2024-07-08 15:18:18 --> Language Class Initialized
INFO - 2024-07-08 15:18:18 --> Language Class Initialized
INFO - 2024-07-08 15:18:18 --> Config Class Initialized
INFO - 2024-07-08 15:18:18 --> Loader Class Initialized
INFO - 2024-07-08 15:18:18 --> Helper loaded: url_helper
INFO - 2024-07-08 15:18:18 --> Helper loaded: file_helper
INFO - 2024-07-08 15:18:18 --> Helper loaded: form_helper
INFO - 2024-07-08 15:18:18 --> Helper loaded: my_helper
INFO - 2024-07-08 15:18:18 --> Database Driver Class Initialized
INFO - 2024-07-08 15:18:18 --> Session: Class initialized using 'files' driver.
INFO - 2024-07-08 15:18:18 --> Controller Class Initialized
INFO - 2024-07-08 15:18:19 --> Config Class Initialized
INFO - 2024-07-08 15:18:19 --> Hooks Class Initialized
DEBUG - 2024-07-08 15:18:19 --> UTF-8 Support Enabled
INFO - 2024-07-08 15:18:19 --> Utf8 Class Initialized
INFO - 2024-07-08 15:18:19 --> URI Class Initialized
INFO - 2024-07-08 15:18:19 --> Router Class Initialized
INFO - 2024-07-08 15:18:19 --> Output Class Initialized
INFO - 2024-07-08 15:18:19 --> Security Class Initialized
DEBUG - 2024-07-08 15:18:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-07-08 15:18:19 --> Input Class Initialized
INFO - 2024-07-08 15:18:19 --> Language Class Initialized
INFO - 2024-07-08 15:18:19 --> Language Class Initialized
INFO - 2024-07-08 15:18:19 --> Config Class Initialized
INFO - 2024-07-08 15:18:19 --> Loader Class Initialized
INFO - 2024-07-08 15:18:19 --> Helper loaded: url_helper
INFO - 2024-07-08 15:18:19 --> Helper loaded: file_helper
INFO - 2024-07-08 15:18:19 --> Helper loaded: form_helper
INFO - 2024-07-08 15:18:19 --> Helper loaded: my_helper
INFO - 2024-07-08 15:18:19 --> Database Driver Class Initialized
INFO - 2024-07-08 15:18:19 --> Session: Class initialized using 'files' driver.
INFO - 2024-07-08 15:18:19 --> Controller Class Initialized
INFO - 2024-07-08 15:18:22 --> Config Class Initialized
INFO - 2024-07-08 15:18:22 --> Hooks Class Initialized
DEBUG - 2024-07-08 15:18:22 --> UTF-8 Support Enabled
INFO - 2024-07-08 15:18:22 --> Utf8 Class Initialized
INFO - 2024-07-08 15:18:22 --> URI Class Initialized
INFO - 2024-07-08 15:18:22 --> Router Class Initialized
INFO - 2024-07-08 15:18:22 --> Output Class Initialized
INFO - 2024-07-08 15:18:22 --> Security Class Initialized
DEBUG - 2024-07-08 15:18:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-07-08 15:18:22 --> Input Class Initialized
INFO - 2024-07-08 15:18:22 --> Language Class Initialized
INFO - 2024-07-08 15:18:22 --> Language Class Initialized
INFO - 2024-07-08 15:18:22 --> Config Class Initialized
INFO - 2024-07-08 15:18:22 --> Loader Class Initialized
INFO - 2024-07-08 15:18:22 --> Helper loaded: url_helper
INFO - 2024-07-08 15:18:22 --> Helper loaded: file_helper
INFO - 2024-07-08 15:18:22 --> Helper loaded: form_helper
INFO - 2024-07-08 15:18:22 --> Helper loaded: my_helper
INFO - 2024-07-08 15:18:22 --> Database Driver Class Initialized
INFO - 2024-07-08 15:18:22 --> Session: Class initialized using 'files' driver.
INFO - 2024-07-08 15:18:22 --> Controller Class Initialized
INFO - 2024-07-08 15:18:22 --> Config Class Initialized
INFO - 2024-07-08 15:18:22 --> Hooks Class Initialized
DEBUG - 2024-07-08 15:18:22 --> UTF-8 Support Enabled
INFO - 2024-07-08 15:18:22 --> Utf8 Class Initialized
INFO - 2024-07-08 15:18:22 --> URI Class Initialized
INFO - 2024-07-08 15:18:22 --> Router Class Initialized
INFO - 2024-07-08 15:18:22 --> Output Class Initialized
INFO - 2024-07-08 15:18:22 --> Security Class Initialized
DEBUG - 2024-07-08 15:18:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-07-08 15:18:22 --> Input Class Initialized
INFO - 2024-07-08 15:18:22 --> Language Class Initialized
INFO - 2024-07-08 15:18:22 --> Language Class Initialized
INFO - 2024-07-08 15:18:22 --> Config Class Initialized
INFO - 2024-07-08 15:18:22 --> Loader Class Initialized
INFO - 2024-07-08 15:18:22 --> Helper loaded: url_helper
INFO - 2024-07-08 15:18:22 --> Helper loaded: file_helper
INFO - 2024-07-08 15:18:22 --> Helper loaded: form_helper
INFO - 2024-07-08 15:18:22 --> Helper loaded: my_helper
INFO - 2024-07-08 15:18:22 --> Database Driver Class Initialized
INFO - 2024-07-08 15:18:22 --> Session: Class initialized using 'files' driver.
INFO - 2024-07-08 15:18:22 --> Controller Class Initialized
DEBUG - 2024-07-08 15:18:22 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/data_siswa/views/list.php
DEBUG - 2024-07-08 15:18:22 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-07-08 15:18:22 --> Final output sent to browser
DEBUG - 2024-07-08 15:18:22 --> Total execution time: 0.0563
INFO - 2024-07-08 15:18:22 --> Config Class Initialized
INFO - 2024-07-08 15:18:22 --> Hooks Class Initialized
DEBUG - 2024-07-08 15:18:22 --> UTF-8 Support Enabled
INFO - 2024-07-08 15:18:22 --> Utf8 Class Initialized
INFO - 2024-07-08 15:18:22 --> URI Class Initialized
INFO - 2024-07-08 15:18:22 --> Router Class Initialized
INFO - 2024-07-08 15:18:22 --> Output Class Initialized
INFO - 2024-07-08 15:18:22 --> Security Class Initialized
DEBUG - 2024-07-08 15:18:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-07-08 15:18:22 --> Input Class Initialized
INFO - 2024-07-08 15:18:22 --> Language Class Initialized
ERROR - 2024-07-08 15:18:22 --> 404 Page Not Found: /index
INFO - 2024-07-08 15:18:22 --> Config Class Initialized
INFO - 2024-07-08 15:18:22 --> Hooks Class Initialized
DEBUG - 2024-07-08 15:18:22 --> UTF-8 Support Enabled
INFO - 2024-07-08 15:18:22 --> Utf8 Class Initialized
INFO - 2024-07-08 15:18:22 --> URI Class Initialized
INFO - 2024-07-08 15:18:22 --> Router Class Initialized
INFO - 2024-07-08 15:18:22 --> Output Class Initialized
INFO - 2024-07-08 15:18:22 --> Security Class Initialized
DEBUG - 2024-07-08 15:18:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-07-08 15:18:22 --> Input Class Initialized
INFO - 2024-07-08 15:18:22 --> Language Class Initialized
INFO - 2024-07-08 15:18:22 --> Language Class Initialized
INFO - 2024-07-08 15:18:22 --> Config Class Initialized
INFO - 2024-07-08 15:18:22 --> Loader Class Initialized
INFO - 2024-07-08 15:18:22 --> Helper loaded: url_helper
INFO - 2024-07-08 15:18:22 --> Helper loaded: file_helper
INFO - 2024-07-08 15:18:22 --> Helper loaded: form_helper
INFO - 2024-07-08 15:18:22 --> Helper loaded: my_helper
INFO - 2024-07-08 15:18:22 --> Database Driver Class Initialized
INFO - 2024-07-08 15:18:22 --> Session: Class initialized using 'files' driver.
INFO - 2024-07-08 15:18:22 --> Controller Class Initialized
INFO - 2024-07-08 15:18:25 --> Config Class Initialized
INFO - 2024-07-08 15:18:25 --> Hooks Class Initialized
DEBUG - 2024-07-08 15:18:25 --> UTF-8 Support Enabled
INFO - 2024-07-08 15:18:25 --> Utf8 Class Initialized
INFO - 2024-07-08 15:18:25 --> URI Class Initialized
INFO - 2024-07-08 15:18:25 --> Router Class Initialized
INFO - 2024-07-08 15:18:25 --> Output Class Initialized
INFO - 2024-07-08 15:18:25 --> Security Class Initialized
DEBUG - 2024-07-08 15:18:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-07-08 15:18:25 --> Input Class Initialized
INFO - 2024-07-08 15:18:25 --> Language Class Initialized
INFO - 2024-07-08 15:18:25 --> Language Class Initialized
INFO - 2024-07-08 15:18:25 --> Config Class Initialized
INFO - 2024-07-08 15:18:25 --> Loader Class Initialized
INFO - 2024-07-08 15:18:25 --> Helper loaded: url_helper
INFO - 2024-07-08 15:18:25 --> Helper loaded: file_helper
INFO - 2024-07-08 15:18:25 --> Helper loaded: form_helper
INFO - 2024-07-08 15:18:25 --> Helper loaded: my_helper
INFO - 2024-07-08 15:18:25 --> Database Driver Class Initialized
INFO - 2024-07-08 15:18:25 --> Session: Class initialized using 'files' driver.
INFO - 2024-07-08 15:18:25 --> Controller Class Initialized
INFO - 2024-07-08 15:18:28 --> Config Class Initialized
INFO - 2024-07-08 15:18:28 --> Hooks Class Initialized
DEBUG - 2024-07-08 15:18:28 --> UTF-8 Support Enabled
INFO - 2024-07-08 15:18:28 --> Utf8 Class Initialized
INFO - 2024-07-08 15:18:28 --> URI Class Initialized
INFO - 2024-07-08 15:18:28 --> Router Class Initialized
INFO - 2024-07-08 15:18:28 --> Output Class Initialized
INFO - 2024-07-08 15:18:28 --> Security Class Initialized
DEBUG - 2024-07-08 15:18:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-07-08 15:18:28 --> Input Class Initialized
INFO - 2024-07-08 15:18:28 --> Language Class Initialized
INFO - 2024-07-08 15:18:28 --> Language Class Initialized
INFO - 2024-07-08 15:18:28 --> Config Class Initialized
INFO - 2024-07-08 15:18:28 --> Loader Class Initialized
INFO - 2024-07-08 15:18:28 --> Helper loaded: url_helper
INFO - 2024-07-08 15:18:28 --> Helper loaded: file_helper
INFO - 2024-07-08 15:18:28 --> Helper loaded: form_helper
INFO - 2024-07-08 15:18:28 --> Helper loaded: my_helper
INFO - 2024-07-08 15:18:28 --> Database Driver Class Initialized
INFO - 2024-07-08 15:18:28 --> Session: Class initialized using 'files' driver.
INFO - 2024-07-08 15:18:28 --> Controller Class Initialized
INFO - 2024-07-08 15:18:28 --> Config Class Initialized
INFO - 2024-07-08 15:18:28 --> Hooks Class Initialized
DEBUG - 2024-07-08 15:18:28 --> UTF-8 Support Enabled
INFO - 2024-07-08 15:18:28 --> Utf8 Class Initialized
INFO - 2024-07-08 15:18:28 --> URI Class Initialized
INFO - 2024-07-08 15:18:28 --> Router Class Initialized
INFO - 2024-07-08 15:18:28 --> Output Class Initialized
INFO - 2024-07-08 15:18:28 --> Security Class Initialized
DEBUG - 2024-07-08 15:18:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-07-08 15:18:28 --> Input Class Initialized
INFO - 2024-07-08 15:18:28 --> Language Class Initialized
INFO - 2024-07-08 15:18:28 --> Language Class Initialized
INFO - 2024-07-08 15:18:28 --> Config Class Initialized
INFO - 2024-07-08 15:18:28 --> Loader Class Initialized
INFO - 2024-07-08 15:18:28 --> Helper loaded: url_helper
INFO - 2024-07-08 15:18:28 --> Helper loaded: file_helper
INFO - 2024-07-08 15:18:28 --> Helper loaded: form_helper
INFO - 2024-07-08 15:18:28 --> Helper loaded: my_helper
INFO - 2024-07-08 15:18:28 --> Database Driver Class Initialized
INFO - 2024-07-08 15:18:28 --> Session: Class initialized using 'files' driver.
INFO - 2024-07-08 15:18:28 --> Controller Class Initialized
DEBUG - 2024-07-08 15:18:28 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/data_siswa/views/list.php
DEBUG - 2024-07-08 15:18:28 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-07-08 15:18:28 --> Final output sent to browser
DEBUG - 2024-07-08 15:18:28 --> Total execution time: 0.0781
INFO - 2024-07-08 15:18:28 --> Config Class Initialized
INFO - 2024-07-08 15:18:28 --> Hooks Class Initialized
DEBUG - 2024-07-08 15:18:28 --> UTF-8 Support Enabled
INFO - 2024-07-08 15:18:28 --> Utf8 Class Initialized
INFO - 2024-07-08 15:18:28 --> URI Class Initialized
INFO - 2024-07-08 15:18:28 --> Router Class Initialized
INFO - 2024-07-08 15:18:28 --> Output Class Initialized
INFO - 2024-07-08 15:18:28 --> Security Class Initialized
DEBUG - 2024-07-08 15:18:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-07-08 15:18:28 --> Input Class Initialized
INFO - 2024-07-08 15:18:28 --> Language Class Initialized
ERROR - 2024-07-08 15:18:28 --> 404 Page Not Found: /index
INFO - 2024-07-08 15:18:28 --> Config Class Initialized
INFO - 2024-07-08 15:18:28 --> Hooks Class Initialized
DEBUG - 2024-07-08 15:18:28 --> UTF-8 Support Enabled
INFO - 2024-07-08 15:18:28 --> Utf8 Class Initialized
INFO - 2024-07-08 15:18:28 --> URI Class Initialized
INFO - 2024-07-08 15:18:28 --> Router Class Initialized
INFO - 2024-07-08 15:18:28 --> Output Class Initialized
INFO - 2024-07-08 15:18:28 --> Security Class Initialized
DEBUG - 2024-07-08 15:18:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-07-08 15:18:28 --> Input Class Initialized
INFO - 2024-07-08 15:18:28 --> Language Class Initialized
INFO - 2024-07-08 15:18:28 --> Language Class Initialized
INFO - 2024-07-08 15:18:28 --> Config Class Initialized
INFO - 2024-07-08 15:18:28 --> Loader Class Initialized
INFO - 2024-07-08 15:18:28 --> Helper loaded: url_helper
INFO - 2024-07-08 15:18:28 --> Helper loaded: file_helper
INFO - 2024-07-08 15:18:28 --> Helper loaded: form_helper
INFO - 2024-07-08 15:18:28 --> Helper loaded: my_helper
INFO - 2024-07-08 15:18:28 --> Database Driver Class Initialized
INFO - 2024-07-08 15:18:28 --> Session: Class initialized using 'files' driver.
INFO - 2024-07-08 15:18:28 --> Controller Class Initialized
INFO - 2024-07-08 15:18:32 --> Config Class Initialized
INFO - 2024-07-08 15:18:32 --> Hooks Class Initialized
DEBUG - 2024-07-08 15:18:32 --> UTF-8 Support Enabled
INFO - 2024-07-08 15:18:32 --> Utf8 Class Initialized
INFO - 2024-07-08 15:18:32 --> URI Class Initialized
INFO - 2024-07-08 15:18:32 --> Router Class Initialized
INFO - 2024-07-08 15:18:32 --> Output Class Initialized
INFO - 2024-07-08 15:18:32 --> Security Class Initialized
DEBUG - 2024-07-08 15:18:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-07-08 15:18:32 --> Input Class Initialized
INFO - 2024-07-08 15:18:32 --> Language Class Initialized
INFO - 2024-07-08 15:18:32 --> Language Class Initialized
INFO - 2024-07-08 15:18:32 --> Config Class Initialized
INFO - 2024-07-08 15:18:32 --> Loader Class Initialized
INFO - 2024-07-08 15:18:32 --> Helper loaded: url_helper
INFO - 2024-07-08 15:18:32 --> Helper loaded: file_helper
INFO - 2024-07-08 15:18:32 --> Helper loaded: form_helper
INFO - 2024-07-08 15:18:32 --> Helper loaded: my_helper
INFO - 2024-07-08 15:18:32 --> Database Driver Class Initialized
INFO - 2024-07-08 15:18:32 --> Session: Class initialized using 'files' driver.
INFO - 2024-07-08 15:18:32 --> Controller Class Initialized
INFO - 2024-07-08 15:18:34 --> Config Class Initialized
INFO - 2024-07-08 15:18:34 --> Hooks Class Initialized
DEBUG - 2024-07-08 15:18:34 --> UTF-8 Support Enabled
INFO - 2024-07-08 15:18:34 --> Utf8 Class Initialized
INFO - 2024-07-08 15:18:34 --> URI Class Initialized
INFO - 2024-07-08 15:18:34 --> Router Class Initialized
INFO - 2024-07-08 15:18:34 --> Output Class Initialized
INFO - 2024-07-08 15:18:34 --> Security Class Initialized
DEBUG - 2024-07-08 15:18:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-07-08 15:18:34 --> Input Class Initialized
INFO - 2024-07-08 15:18:34 --> Language Class Initialized
INFO - 2024-07-08 15:18:34 --> Language Class Initialized
INFO - 2024-07-08 15:18:34 --> Config Class Initialized
INFO - 2024-07-08 15:18:34 --> Loader Class Initialized
INFO - 2024-07-08 15:18:34 --> Helper loaded: url_helper
INFO - 2024-07-08 15:18:34 --> Helper loaded: file_helper
INFO - 2024-07-08 15:18:34 --> Helper loaded: form_helper
INFO - 2024-07-08 15:18:34 --> Helper loaded: my_helper
INFO - 2024-07-08 15:18:34 --> Database Driver Class Initialized
INFO - 2024-07-08 15:18:34 --> Session: Class initialized using 'files' driver.
INFO - 2024-07-08 15:18:34 --> Controller Class Initialized
INFO - 2024-07-08 15:18:34 --> Config Class Initialized
INFO - 2024-07-08 15:18:34 --> Hooks Class Initialized
DEBUG - 2024-07-08 15:18:34 --> UTF-8 Support Enabled
INFO - 2024-07-08 15:18:34 --> Utf8 Class Initialized
INFO - 2024-07-08 15:18:34 --> URI Class Initialized
INFO - 2024-07-08 15:18:34 --> Router Class Initialized
INFO - 2024-07-08 15:18:34 --> Output Class Initialized
INFO - 2024-07-08 15:18:34 --> Security Class Initialized
DEBUG - 2024-07-08 15:18:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-07-08 15:18:34 --> Input Class Initialized
INFO - 2024-07-08 15:18:34 --> Language Class Initialized
INFO - 2024-07-08 15:18:34 --> Language Class Initialized
INFO - 2024-07-08 15:18:34 --> Config Class Initialized
INFO - 2024-07-08 15:18:34 --> Loader Class Initialized
INFO - 2024-07-08 15:18:34 --> Helper loaded: url_helper
INFO - 2024-07-08 15:18:34 --> Helper loaded: file_helper
INFO - 2024-07-08 15:18:34 --> Helper loaded: form_helper
INFO - 2024-07-08 15:18:34 --> Helper loaded: my_helper
INFO - 2024-07-08 15:18:34 --> Database Driver Class Initialized
INFO - 2024-07-08 15:18:34 --> Session: Class initialized using 'files' driver.
INFO - 2024-07-08 15:18:34 --> Controller Class Initialized
DEBUG - 2024-07-08 15:18:34 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/data_siswa/views/list.php
DEBUG - 2024-07-08 15:18:34 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-07-08 15:18:34 --> Final output sent to browser
DEBUG - 2024-07-08 15:18:34 --> Total execution time: 0.0327
INFO - 2024-07-08 15:18:34 --> Config Class Initialized
INFO - 2024-07-08 15:18:34 --> Hooks Class Initialized
DEBUG - 2024-07-08 15:18:34 --> UTF-8 Support Enabled
INFO - 2024-07-08 15:18:34 --> Utf8 Class Initialized
INFO - 2024-07-08 15:18:34 --> URI Class Initialized
INFO - 2024-07-08 15:18:34 --> Router Class Initialized
INFO - 2024-07-08 15:18:34 --> Output Class Initialized
INFO - 2024-07-08 15:18:34 --> Security Class Initialized
DEBUG - 2024-07-08 15:18:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-07-08 15:18:34 --> Input Class Initialized
INFO - 2024-07-08 15:18:34 --> Language Class Initialized
ERROR - 2024-07-08 15:18:34 --> 404 Page Not Found: /index
INFO - 2024-07-08 15:18:34 --> Config Class Initialized
INFO - 2024-07-08 15:18:34 --> Hooks Class Initialized
DEBUG - 2024-07-08 15:18:34 --> UTF-8 Support Enabled
INFO - 2024-07-08 15:18:34 --> Utf8 Class Initialized
INFO - 2024-07-08 15:18:34 --> URI Class Initialized
INFO - 2024-07-08 15:18:34 --> Router Class Initialized
INFO - 2024-07-08 15:18:34 --> Output Class Initialized
INFO - 2024-07-08 15:18:34 --> Security Class Initialized
DEBUG - 2024-07-08 15:18:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-07-08 15:18:34 --> Input Class Initialized
INFO - 2024-07-08 15:18:34 --> Language Class Initialized
INFO - 2024-07-08 15:18:34 --> Language Class Initialized
INFO - 2024-07-08 15:18:34 --> Config Class Initialized
INFO - 2024-07-08 15:18:34 --> Loader Class Initialized
INFO - 2024-07-08 15:18:34 --> Helper loaded: url_helper
INFO - 2024-07-08 15:18:34 --> Helper loaded: file_helper
INFO - 2024-07-08 15:18:34 --> Helper loaded: form_helper
INFO - 2024-07-08 15:18:34 --> Helper loaded: my_helper
INFO - 2024-07-08 15:18:34 --> Database Driver Class Initialized
INFO - 2024-07-08 15:18:34 --> Session: Class initialized using 'files' driver.
INFO - 2024-07-08 15:18:34 --> Controller Class Initialized
INFO - 2024-07-08 15:18:35 --> Config Class Initialized
INFO - 2024-07-08 15:18:35 --> Hooks Class Initialized
DEBUG - 2024-07-08 15:18:35 --> UTF-8 Support Enabled
INFO - 2024-07-08 15:18:35 --> Utf8 Class Initialized
INFO - 2024-07-08 15:18:35 --> URI Class Initialized
INFO - 2024-07-08 15:18:35 --> Router Class Initialized
INFO - 2024-07-08 15:18:35 --> Output Class Initialized
INFO - 2024-07-08 15:18:35 --> Security Class Initialized
DEBUG - 2024-07-08 15:18:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-07-08 15:18:35 --> Input Class Initialized
INFO - 2024-07-08 15:18:35 --> Language Class Initialized
INFO - 2024-07-08 15:18:35 --> Language Class Initialized
INFO - 2024-07-08 15:18:35 --> Config Class Initialized
INFO - 2024-07-08 15:18:35 --> Loader Class Initialized
INFO - 2024-07-08 15:18:35 --> Helper loaded: url_helper
INFO - 2024-07-08 15:18:35 --> Helper loaded: file_helper
INFO - 2024-07-08 15:18:35 --> Helper loaded: form_helper
INFO - 2024-07-08 15:18:35 --> Helper loaded: my_helper
INFO - 2024-07-08 15:18:35 --> Database Driver Class Initialized
INFO - 2024-07-08 15:18:35 --> Session: Class initialized using 'files' driver.
INFO - 2024-07-08 15:18:35 --> Controller Class Initialized
INFO - 2024-07-08 15:18:38 --> Config Class Initialized
INFO - 2024-07-08 15:18:38 --> Hooks Class Initialized
DEBUG - 2024-07-08 15:18:38 --> UTF-8 Support Enabled
INFO - 2024-07-08 15:18:38 --> Utf8 Class Initialized
INFO - 2024-07-08 15:18:38 --> URI Class Initialized
INFO - 2024-07-08 15:18:38 --> Router Class Initialized
INFO - 2024-07-08 15:18:38 --> Output Class Initialized
INFO - 2024-07-08 15:18:38 --> Security Class Initialized
DEBUG - 2024-07-08 15:18:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-07-08 15:18:38 --> Input Class Initialized
INFO - 2024-07-08 15:18:38 --> Language Class Initialized
INFO - 2024-07-08 15:18:38 --> Language Class Initialized
INFO - 2024-07-08 15:18:38 --> Config Class Initialized
INFO - 2024-07-08 15:18:38 --> Loader Class Initialized
INFO - 2024-07-08 15:18:38 --> Helper loaded: url_helper
INFO - 2024-07-08 15:18:38 --> Helper loaded: file_helper
INFO - 2024-07-08 15:18:38 --> Helper loaded: form_helper
INFO - 2024-07-08 15:18:38 --> Helper loaded: my_helper
INFO - 2024-07-08 15:18:38 --> Database Driver Class Initialized
INFO - 2024-07-08 15:18:38 --> Session: Class initialized using 'files' driver.
INFO - 2024-07-08 15:18:38 --> Controller Class Initialized
INFO - 2024-07-08 15:18:38 --> Config Class Initialized
INFO - 2024-07-08 15:18:38 --> Hooks Class Initialized
DEBUG - 2024-07-08 15:18:38 --> UTF-8 Support Enabled
INFO - 2024-07-08 15:18:38 --> Utf8 Class Initialized
INFO - 2024-07-08 15:18:38 --> URI Class Initialized
INFO - 2024-07-08 15:18:38 --> Router Class Initialized
INFO - 2024-07-08 15:18:38 --> Output Class Initialized
INFO - 2024-07-08 15:18:38 --> Security Class Initialized
DEBUG - 2024-07-08 15:18:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-07-08 15:18:38 --> Input Class Initialized
INFO - 2024-07-08 15:18:38 --> Language Class Initialized
INFO - 2024-07-08 15:18:38 --> Language Class Initialized
INFO - 2024-07-08 15:18:38 --> Config Class Initialized
INFO - 2024-07-08 15:18:38 --> Loader Class Initialized
INFO - 2024-07-08 15:18:38 --> Helper loaded: url_helper
INFO - 2024-07-08 15:18:38 --> Helper loaded: file_helper
INFO - 2024-07-08 15:18:38 --> Helper loaded: form_helper
INFO - 2024-07-08 15:18:38 --> Helper loaded: my_helper
INFO - 2024-07-08 15:18:38 --> Database Driver Class Initialized
INFO - 2024-07-08 15:18:38 --> Session: Class initialized using 'files' driver.
INFO - 2024-07-08 15:18:38 --> Controller Class Initialized
DEBUG - 2024-07-08 15:18:38 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/data_siswa/views/list.php
DEBUG - 2024-07-08 15:18:38 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-07-08 15:18:38 --> Final output sent to browser
DEBUG - 2024-07-08 15:18:38 --> Total execution time: 0.0296
INFO - 2024-07-08 15:18:38 --> Config Class Initialized
INFO - 2024-07-08 15:18:38 --> Hooks Class Initialized
DEBUG - 2024-07-08 15:18:38 --> UTF-8 Support Enabled
INFO - 2024-07-08 15:18:38 --> Utf8 Class Initialized
INFO - 2024-07-08 15:18:38 --> URI Class Initialized
INFO - 2024-07-08 15:18:38 --> Router Class Initialized
INFO - 2024-07-08 15:18:38 --> Output Class Initialized
INFO - 2024-07-08 15:18:38 --> Security Class Initialized
DEBUG - 2024-07-08 15:18:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-07-08 15:18:38 --> Input Class Initialized
INFO - 2024-07-08 15:18:38 --> Language Class Initialized
ERROR - 2024-07-08 15:18:38 --> 404 Page Not Found: /index
INFO - 2024-07-08 15:18:38 --> Config Class Initialized
INFO - 2024-07-08 15:18:38 --> Hooks Class Initialized
DEBUG - 2024-07-08 15:18:38 --> UTF-8 Support Enabled
INFO - 2024-07-08 15:18:38 --> Utf8 Class Initialized
INFO - 2024-07-08 15:18:38 --> URI Class Initialized
INFO - 2024-07-08 15:18:38 --> Router Class Initialized
INFO - 2024-07-08 15:18:38 --> Output Class Initialized
INFO - 2024-07-08 15:18:38 --> Security Class Initialized
DEBUG - 2024-07-08 15:18:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-07-08 15:18:38 --> Input Class Initialized
INFO - 2024-07-08 15:18:38 --> Language Class Initialized
INFO - 2024-07-08 15:18:38 --> Language Class Initialized
INFO - 2024-07-08 15:18:38 --> Config Class Initialized
INFO - 2024-07-08 15:18:38 --> Loader Class Initialized
INFO - 2024-07-08 15:18:38 --> Helper loaded: url_helper
INFO - 2024-07-08 15:18:38 --> Helper loaded: file_helper
INFO - 2024-07-08 15:18:38 --> Helper loaded: form_helper
INFO - 2024-07-08 15:18:38 --> Helper loaded: my_helper
INFO - 2024-07-08 15:18:38 --> Database Driver Class Initialized
INFO - 2024-07-08 15:18:38 --> Session: Class initialized using 'files' driver.
INFO - 2024-07-08 15:18:38 --> Controller Class Initialized
INFO - 2024-07-08 15:18:40 --> Config Class Initialized
INFO - 2024-07-08 15:18:40 --> Hooks Class Initialized
DEBUG - 2024-07-08 15:18:40 --> UTF-8 Support Enabled
INFO - 2024-07-08 15:18:40 --> Utf8 Class Initialized
INFO - 2024-07-08 15:18:40 --> URI Class Initialized
INFO - 2024-07-08 15:18:40 --> Router Class Initialized
INFO - 2024-07-08 15:18:40 --> Output Class Initialized
INFO - 2024-07-08 15:18:40 --> Security Class Initialized
DEBUG - 2024-07-08 15:18:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-07-08 15:18:40 --> Input Class Initialized
INFO - 2024-07-08 15:18:40 --> Language Class Initialized
INFO - 2024-07-08 15:18:40 --> Language Class Initialized
INFO - 2024-07-08 15:18:40 --> Config Class Initialized
INFO - 2024-07-08 15:18:40 --> Loader Class Initialized
INFO - 2024-07-08 15:18:40 --> Helper loaded: url_helper
INFO - 2024-07-08 15:18:40 --> Helper loaded: file_helper
INFO - 2024-07-08 15:18:40 --> Helper loaded: form_helper
INFO - 2024-07-08 15:18:40 --> Helper loaded: my_helper
INFO - 2024-07-08 15:18:40 --> Database Driver Class Initialized
INFO - 2024-07-08 15:18:40 --> Session: Class initialized using 'files' driver.
INFO - 2024-07-08 15:18:40 --> Controller Class Initialized
INFO - 2024-07-08 15:18:42 --> Config Class Initialized
INFO - 2024-07-08 15:18:42 --> Hooks Class Initialized
DEBUG - 2024-07-08 15:18:42 --> UTF-8 Support Enabled
INFO - 2024-07-08 15:18:42 --> Utf8 Class Initialized
INFO - 2024-07-08 15:18:42 --> URI Class Initialized
INFO - 2024-07-08 15:18:42 --> Router Class Initialized
INFO - 2024-07-08 15:18:42 --> Output Class Initialized
INFO - 2024-07-08 15:18:42 --> Security Class Initialized
DEBUG - 2024-07-08 15:18:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-07-08 15:18:42 --> Input Class Initialized
INFO - 2024-07-08 15:18:42 --> Language Class Initialized
INFO - 2024-07-08 15:18:42 --> Language Class Initialized
INFO - 2024-07-08 15:18:42 --> Config Class Initialized
INFO - 2024-07-08 15:18:42 --> Loader Class Initialized
INFO - 2024-07-08 15:18:42 --> Helper loaded: url_helper
INFO - 2024-07-08 15:18:42 --> Helper loaded: file_helper
INFO - 2024-07-08 15:18:42 --> Helper loaded: form_helper
INFO - 2024-07-08 15:18:42 --> Helper loaded: my_helper
INFO - 2024-07-08 15:18:42 --> Database Driver Class Initialized
INFO - 2024-07-08 15:18:42 --> Session: Class initialized using 'files' driver.
INFO - 2024-07-08 15:18:42 --> Controller Class Initialized
INFO - 2024-07-08 15:18:42 --> Config Class Initialized
INFO - 2024-07-08 15:18:42 --> Hooks Class Initialized
DEBUG - 2024-07-08 15:18:42 --> UTF-8 Support Enabled
INFO - 2024-07-08 15:18:42 --> Utf8 Class Initialized
INFO - 2024-07-08 15:18:42 --> URI Class Initialized
INFO - 2024-07-08 15:18:42 --> Router Class Initialized
INFO - 2024-07-08 15:18:42 --> Output Class Initialized
INFO - 2024-07-08 15:18:42 --> Security Class Initialized
DEBUG - 2024-07-08 15:18:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-07-08 15:18:42 --> Input Class Initialized
INFO - 2024-07-08 15:18:42 --> Language Class Initialized
INFO - 2024-07-08 15:18:42 --> Language Class Initialized
INFO - 2024-07-08 15:18:42 --> Config Class Initialized
INFO - 2024-07-08 15:18:42 --> Loader Class Initialized
INFO - 2024-07-08 15:18:42 --> Helper loaded: url_helper
INFO - 2024-07-08 15:18:42 --> Helper loaded: file_helper
INFO - 2024-07-08 15:18:42 --> Helper loaded: form_helper
INFO - 2024-07-08 15:18:42 --> Helper loaded: my_helper
INFO - 2024-07-08 15:18:42 --> Database Driver Class Initialized
INFO - 2024-07-08 15:18:42 --> Session: Class initialized using 'files' driver.
INFO - 2024-07-08 15:18:42 --> Controller Class Initialized
DEBUG - 2024-07-08 15:18:42 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/data_siswa/views/list.php
DEBUG - 2024-07-08 15:18:42 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-07-08 15:18:42 --> Final output sent to browser
DEBUG - 2024-07-08 15:18:42 --> Total execution time: 0.0341
INFO - 2024-07-08 15:18:42 --> Config Class Initialized
INFO - 2024-07-08 15:18:42 --> Hooks Class Initialized
DEBUG - 2024-07-08 15:18:42 --> UTF-8 Support Enabled
INFO - 2024-07-08 15:18:42 --> Utf8 Class Initialized
INFO - 2024-07-08 15:18:42 --> URI Class Initialized
INFO - 2024-07-08 15:18:42 --> Router Class Initialized
INFO - 2024-07-08 15:18:42 --> Output Class Initialized
INFO - 2024-07-08 15:18:42 --> Security Class Initialized
DEBUG - 2024-07-08 15:18:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-07-08 15:18:42 --> Input Class Initialized
INFO - 2024-07-08 15:18:42 --> Language Class Initialized
ERROR - 2024-07-08 15:18:42 --> 404 Page Not Found: /index
INFO - 2024-07-08 15:18:42 --> Config Class Initialized
INFO - 2024-07-08 15:18:42 --> Hooks Class Initialized
DEBUG - 2024-07-08 15:18:42 --> UTF-8 Support Enabled
INFO - 2024-07-08 15:18:42 --> Utf8 Class Initialized
INFO - 2024-07-08 15:18:42 --> URI Class Initialized
INFO - 2024-07-08 15:18:42 --> Router Class Initialized
INFO - 2024-07-08 15:18:42 --> Output Class Initialized
INFO - 2024-07-08 15:18:42 --> Security Class Initialized
DEBUG - 2024-07-08 15:18:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-07-08 15:18:42 --> Input Class Initialized
INFO - 2024-07-08 15:18:42 --> Language Class Initialized
INFO - 2024-07-08 15:18:42 --> Language Class Initialized
INFO - 2024-07-08 15:18:42 --> Config Class Initialized
INFO - 2024-07-08 15:18:42 --> Loader Class Initialized
INFO - 2024-07-08 15:18:42 --> Helper loaded: url_helper
INFO - 2024-07-08 15:18:42 --> Helper loaded: file_helper
INFO - 2024-07-08 15:18:42 --> Helper loaded: form_helper
INFO - 2024-07-08 15:18:42 --> Helper loaded: my_helper
INFO - 2024-07-08 15:18:42 --> Database Driver Class Initialized
INFO - 2024-07-08 15:18:42 --> Session: Class initialized using 'files' driver.
INFO - 2024-07-08 15:18:42 --> Controller Class Initialized
INFO - 2024-07-08 15:18:43 --> Config Class Initialized
INFO - 2024-07-08 15:18:43 --> Hooks Class Initialized
DEBUG - 2024-07-08 15:18:43 --> UTF-8 Support Enabled
INFO - 2024-07-08 15:18:43 --> Utf8 Class Initialized
INFO - 2024-07-08 15:18:43 --> URI Class Initialized
INFO - 2024-07-08 15:18:43 --> Router Class Initialized
INFO - 2024-07-08 15:18:43 --> Output Class Initialized
INFO - 2024-07-08 15:18:43 --> Security Class Initialized
DEBUG - 2024-07-08 15:18:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-07-08 15:18:43 --> Input Class Initialized
INFO - 2024-07-08 15:18:43 --> Language Class Initialized
INFO - 2024-07-08 15:18:43 --> Language Class Initialized
INFO - 2024-07-08 15:18:43 --> Config Class Initialized
INFO - 2024-07-08 15:18:43 --> Loader Class Initialized
INFO - 2024-07-08 15:18:43 --> Helper loaded: url_helper
INFO - 2024-07-08 15:18:43 --> Helper loaded: file_helper
INFO - 2024-07-08 15:18:43 --> Helper loaded: form_helper
INFO - 2024-07-08 15:18:43 --> Helper loaded: my_helper
INFO - 2024-07-08 15:18:43 --> Database Driver Class Initialized
INFO - 2024-07-08 15:18:43 --> Session: Class initialized using 'files' driver.
INFO - 2024-07-08 15:18:43 --> Controller Class Initialized
INFO - 2024-07-08 15:18:46 --> Config Class Initialized
INFO - 2024-07-08 15:18:46 --> Hooks Class Initialized
DEBUG - 2024-07-08 15:18:46 --> UTF-8 Support Enabled
INFO - 2024-07-08 15:18:46 --> Utf8 Class Initialized
INFO - 2024-07-08 15:18:46 --> URI Class Initialized
INFO - 2024-07-08 15:18:46 --> Router Class Initialized
INFO - 2024-07-08 15:18:46 --> Output Class Initialized
INFO - 2024-07-08 15:18:46 --> Security Class Initialized
DEBUG - 2024-07-08 15:18:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-07-08 15:18:46 --> Input Class Initialized
INFO - 2024-07-08 15:18:46 --> Language Class Initialized
INFO - 2024-07-08 15:18:46 --> Language Class Initialized
INFO - 2024-07-08 15:18:46 --> Config Class Initialized
INFO - 2024-07-08 15:18:46 --> Loader Class Initialized
INFO - 2024-07-08 15:18:46 --> Helper loaded: url_helper
INFO - 2024-07-08 15:18:46 --> Helper loaded: file_helper
INFO - 2024-07-08 15:18:46 --> Helper loaded: form_helper
INFO - 2024-07-08 15:18:46 --> Helper loaded: my_helper
INFO - 2024-07-08 15:18:46 --> Database Driver Class Initialized
INFO - 2024-07-08 15:18:46 --> Session: Class initialized using 'files' driver.
INFO - 2024-07-08 15:18:46 --> Controller Class Initialized
INFO - 2024-07-08 15:18:46 --> Config Class Initialized
INFO - 2024-07-08 15:18:46 --> Hooks Class Initialized
DEBUG - 2024-07-08 15:18:46 --> UTF-8 Support Enabled
INFO - 2024-07-08 15:18:46 --> Utf8 Class Initialized
INFO - 2024-07-08 15:18:46 --> URI Class Initialized
INFO - 2024-07-08 15:18:46 --> Router Class Initialized
INFO - 2024-07-08 15:18:46 --> Output Class Initialized
INFO - 2024-07-08 15:18:46 --> Security Class Initialized
DEBUG - 2024-07-08 15:18:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-07-08 15:18:46 --> Input Class Initialized
INFO - 2024-07-08 15:18:46 --> Language Class Initialized
INFO - 2024-07-08 15:18:46 --> Language Class Initialized
INFO - 2024-07-08 15:18:46 --> Config Class Initialized
INFO - 2024-07-08 15:18:46 --> Loader Class Initialized
INFO - 2024-07-08 15:18:46 --> Helper loaded: url_helper
INFO - 2024-07-08 15:18:46 --> Helper loaded: file_helper
INFO - 2024-07-08 15:18:46 --> Helper loaded: form_helper
INFO - 2024-07-08 15:18:46 --> Helper loaded: my_helper
INFO - 2024-07-08 15:18:46 --> Database Driver Class Initialized
INFO - 2024-07-08 15:18:46 --> Session: Class initialized using 'files' driver.
INFO - 2024-07-08 15:18:46 --> Controller Class Initialized
DEBUG - 2024-07-08 15:18:46 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/data_siswa/views/list.php
DEBUG - 2024-07-08 15:18:46 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-07-08 15:18:46 --> Final output sent to browser
DEBUG - 2024-07-08 15:18:46 --> Total execution time: 0.0530
INFO - 2024-07-08 15:18:46 --> Config Class Initialized
INFO - 2024-07-08 15:18:46 --> Hooks Class Initialized
DEBUG - 2024-07-08 15:18:46 --> UTF-8 Support Enabled
INFO - 2024-07-08 15:18:46 --> Utf8 Class Initialized
INFO - 2024-07-08 15:18:46 --> URI Class Initialized
INFO - 2024-07-08 15:18:46 --> Router Class Initialized
INFO - 2024-07-08 15:18:46 --> Output Class Initialized
INFO - 2024-07-08 15:18:46 --> Security Class Initialized
DEBUG - 2024-07-08 15:18:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-07-08 15:18:46 --> Input Class Initialized
INFO - 2024-07-08 15:18:46 --> Language Class Initialized
ERROR - 2024-07-08 15:18:46 --> 404 Page Not Found: /index
INFO - 2024-07-08 15:18:46 --> Config Class Initialized
INFO - 2024-07-08 15:18:46 --> Hooks Class Initialized
DEBUG - 2024-07-08 15:18:46 --> UTF-8 Support Enabled
INFO - 2024-07-08 15:18:46 --> Utf8 Class Initialized
INFO - 2024-07-08 15:18:46 --> URI Class Initialized
INFO - 2024-07-08 15:18:46 --> Router Class Initialized
INFO - 2024-07-08 15:18:46 --> Output Class Initialized
INFO - 2024-07-08 15:18:46 --> Security Class Initialized
DEBUG - 2024-07-08 15:18:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-07-08 15:18:46 --> Input Class Initialized
INFO - 2024-07-08 15:18:46 --> Language Class Initialized
INFO - 2024-07-08 15:18:46 --> Language Class Initialized
INFO - 2024-07-08 15:18:46 --> Config Class Initialized
INFO - 2024-07-08 15:18:46 --> Loader Class Initialized
INFO - 2024-07-08 15:18:46 --> Helper loaded: url_helper
INFO - 2024-07-08 15:18:46 --> Helper loaded: file_helper
INFO - 2024-07-08 15:18:46 --> Helper loaded: form_helper
INFO - 2024-07-08 15:18:46 --> Helper loaded: my_helper
INFO - 2024-07-08 15:18:46 --> Database Driver Class Initialized
INFO - 2024-07-08 15:18:46 --> Session: Class initialized using 'files' driver.
INFO - 2024-07-08 15:18:46 --> Controller Class Initialized
INFO - 2024-07-08 15:18:47 --> Config Class Initialized
INFO - 2024-07-08 15:18:47 --> Hooks Class Initialized
DEBUG - 2024-07-08 15:18:47 --> UTF-8 Support Enabled
INFO - 2024-07-08 15:18:47 --> Utf8 Class Initialized
INFO - 2024-07-08 15:18:47 --> URI Class Initialized
INFO - 2024-07-08 15:18:47 --> Router Class Initialized
INFO - 2024-07-08 15:18:47 --> Output Class Initialized
INFO - 2024-07-08 15:18:47 --> Security Class Initialized
DEBUG - 2024-07-08 15:18:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-07-08 15:18:47 --> Input Class Initialized
INFO - 2024-07-08 15:18:47 --> Language Class Initialized
INFO - 2024-07-08 15:18:47 --> Language Class Initialized
INFO - 2024-07-08 15:18:47 --> Config Class Initialized
INFO - 2024-07-08 15:18:47 --> Loader Class Initialized
INFO - 2024-07-08 15:18:47 --> Helper loaded: url_helper
INFO - 2024-07-08 15:18:47 --> Helper loaded: file_helper
INFO - 2024-07-08 15:18:47 --> Helper loaded: form_helper
INFO - 2024-07-08 15:18:47 --> Helper loaded: my_helper
INFO - 2024-07-08 15:18:47 --> Database Driver Class Initialized
INFO - 2024-07-08 15:18:47 --> Session: Class initialized using 'files' driver.
INFO - 2024-07-08 15:18:47 --> Controller Class Initialized
INFO - 2024-07-08 15:18:49 --> Config Class Initialized
INFO - 2024-07-08 15:18:49 --> Hooks Class Initialized
DEBUG - 2024-07-08 15:18:49 --> UTF-8 Support Enabled
INFO - 2024-07-08 15:18:49 --> Utf8 Class Initialized
INFO - 2024-07-08 15:18:50 --> URI Class Initialized
INFO - 2024-07-08 15:18:50 --> Router Class Initialized
INFO - 2024-07-08 15:18:50 --> Output Class Initialized
INFO - 2024-07-08 15:18:50 --> Security Class Initialized
DEBUG - 2024-07-08 15:18:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-07-08 15:18:50 --> Input Class Initialized
INFO - 2024-07-08 15:18:50 --> Language Class Initialized
INFO - 2024-07-08 15:18:50 --> Language Class Initialized
INFO - 2024-07-08 15:18:50 --> Config Class Initialized
INFO - 2024-07-08 15:18:50 --> Loader Class Initialized
INFO - 2024-07-08 15:18:50 --> Helper loaded: url_helper
INFO - 2024-07-08 15:18:50 --> Helper loaded: file_helper
INFO - 2024-07-08 15:18:50 --> Helper loaded: form_helper
INFO - 2024-07-08 15:18:50 --> Helper loaded: my_helper
INFO - 2024-07-08 15:18:50 --> Database Driver Class Initialized
INFO - 2024-07-08 15:18:50 --> Session: Class initialized using 'files' driver.
INFO - 2024-07-08 15:18:50 --> Controller Class Initialized
INFO - 2024-07-08 15:18:50 --> Config Class Initialized
INFO - 2024-07-08 15:18:50 --> Hooks Class Initialized
DEBUG - 2024-07-08 15:18:50 --> UTF-8 Support Enabled
INFO - 2024-07-08 15:18:50 --> Utf8 Class Initialized
INFO - 2024-07-08 15:18:50 --> URI Class Initialized
INFO - 2024-07-08 15:18:50 --> Router Class Initialized
INFO - 2024-07-08 15:18:50 --> Output Class Initialized
INFO - 2024-07-08 15:18:50 --> Security Class Initialized
DEBUG - 2024-07-08 15:18:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-07-08 15:18:50 --> Input Class Initialized
INFO - 2024-07-08 15:18:50 --> Language Class Initialized
INFO - 2024-07-08 15:18:50 --> Language Class Initialized
INFO - 2024-07-08 15:18:50 --> Config Class Initialized
INFO - 2024-07-08 15:18:50 --> Loader Class Initialized
INFO - 2024-07-08 15:18:50 --> Helper loaded: url_helper
INFO - 2024-07-08 15:18:50 --> Helper loaded: file_helper
INFO - 2024-07-08 15:18:50 --> Helper loaded: form_helper
INFO - 2024-07-08 15:18:50 --> Helper loaded: my_helper
INFO - 2024-07-08 15:18:50 --> Database Driver Class Initialized
INFO - 2024-07-08 15:18:50 --> Session: Class initialized using 'files' driver.
INFO - 2024-07-08 15:18:50 --> Controller Class Initialized
DEBUG - 2024-07-08 15:18:50 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/data_siswa/views/list.php
DEBUG - 2024-07-08 15:18:50 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-07-08 15:18:50 --> Final output sent to browser
DEBUG - 2024-07-08 15:18:50 --> Total execution time: 0.0341
INFO - 2024-07-08 15:18:50 --> Config Class Initialized
INFO - 2024-07-08 15:18:50 --> Hooks Class Initialized
DEBUG - 2024-07-08 15:18:50 --> UTF-8 Support Enabled
INFO - 2024-07-08 15:18:50 --> Utf8 Class Initialized
INFO - 2024-07-08 15:18:50 --> URI Class Initialized
INFO - 2024-07-08 15:18:50 --> Router Class Initialized
INFO - 2024-07-08 15:18:50 --> Output Class Initialized
INFO - 2024-07-08 15:18:50 --> Security Class Initialized
DEBUG - 2024-07-08 15:18:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-07-08 15:18:50 --> Input Class Initialized
INFO - 2024-07-08 15:18:50 --> Language Class Initialized
ERROR - 2024-07-08 15:18:50 --> 404 Page Not Found: /index
INFO - 2024-07-08 15:18:50 --> Config Class Initialized
INFO - 2024-07-08 15:18:50 --> Hooks Class Initialized
DEBUG - 2024-07-08 15:18:50 --> UTF-8 Support Enabled
INFO - 2024-07-08 15:18:50 --> Utf8 Class Initialized
INFO - 2024-07-08 15:18:50 --> URI Class Initialized
INFO - 2024-07-08 15:18:50 --> Router Class Initialized
INFO - 2024-07-08 15:18:50 --> Output Class Initialized
INFO - 2024-07-08 15:18:50 --> Security Class Initialized
DEBUG - 2024-07-08 15:18:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-07-08 15:18:50 --> Input Class Initialized
INFO - 2024-07-08 15:18:50 --> Language Class Initialized
INFO - 2024-07-08 15:18:50 --> Language Class Initialized
INFO - 2024-07-08 15:18:50 --> Config Class Initialized
INFO - 2024-07-08 15:18:50 --> Loader Class Initialized
INFO - 2024-07-08 15:18:50 --> Helper loaded: url_helper
INFO - 2024-07-08 15:18:50 --> Helper loaded: file_helper
INFO - 2024-07-08 15:18:50 --> Helper loaded: form_helper
INFO - 2024-07-08 15:18:50 --> Helper loaded: my_helper
INFO - 2024-07-08 15:18:50 --> Database Driver Class Initialized
INFO - 2024-07-08 15:18:50 --> Session: Class initialized using 'files' driver.
INFO - 2024-07-08 15:18:50 --> Controller Class Initialized
INFO - 2024-07-08 15:18:51 --> Config Class Initialized
INFO - 2024-07-08 15:18:51 --> Hooks Class Initialized
DEBUG - 2024-07-08 15:18:51 --> UTF-8 Support Enabled
INFO - 2024-07-08 15:18:51 --> Utf8 Class Initialized
INFO - 2024-07-08 15:18:51 --> URI Class Initialized
INFO - 2024-07-08 15:18:51 --> Router Class Initialized
INFO - 2024-07-08 15:18:51 --> Output Class Initialized
INFO - 2024-07-08 15:18:51 --> Security Class Initialized
DEBUG - 2024-07-08 15:18:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-07-08 15:18:51 --> Input Class Initialized
INFO - 2024-07-08 15:18:51 --> Language Class Initialized
INFO - 2024-07-08 15:18:51 --> Language Class Initialized
INFO - 2024-07-08 15:18:51 --> Config Class Initialized
INFO - 2024-07-08 15:18:51 --> Loader Class Initialized
INFO - 2024-07-08 15:18:51 --> Helper loaded: url_helper
INFO - 2024-07-08 15:18:51 --> Helper loaded: file_helper
INFO - 2024-07-08 15:18:51 --> Helper loaded: form_helper
INFO - 2024-07-08 15:18:51 --> Helper loaded: my_helper
INFO - 2024-07-08 15:18:51 --> Database Driver Class Initialized
INFO - 2024-07-08 15:18:51 --> Session: Class initialized using 'files' driver.
INFO - 2024-07-08 15:18:51 --> Controller Class Initialized
INFO - 2024-07-08 15:18:53 --> Config Class Initialized
INFO - 2024-07-08 15:18:53 --> Hooks Class Initialized
DEBUG - 2024-07-08 15:18:53 --> UTF-8 Support Enabled
INFO - 2024-07-08 15:18:53 --> Utf8 Class Initialized
INFO - 2024-07-08 15:18:53 --> URI Class Initialized
INFO - 2024-07-08 15:18:53 --> Router Class Initialized
INFO - 2024-07-08 15:18:53 --> Output Class Initialized
INFO - 2024-07-08 15:18:53 --> Security Class Initialized
DEBUG - 2024-07-08 15:18:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-07-08 15:18:53 --> Input Class Initialized
INFO - 2024-07-08 15:18:53 --> Language Class Initialized
INFO - 2024-07-08 15:18:53 --> Language Class Initialized
INFO - 2024-07-08 15:18:53 --> Config Class Initialized
INFO - 2024-07-08 15:18:53 --> Loader Class Initialized
INFO - 2024-07-08 15:18:53 --> Helper loaded: url_helper
INFO - 2024-07-08 15:18:53 --> Helper loaded: file_helper
INFO - 2024-07-08 15:18:53 --> Helper loaded: form_helper
INFO - 2024-07-08 15:18:53 --> Helper loaded: my_helper
INFO - 2024-07-08 15:18:53 --> Database Driver Class Initialized
INFO - 2024-07-08 15:18:53 --> Session: Class initialized using 'files' driver.
INFO - 2024-07-08 15:18:53 --> Controller Class Initialized
INFO - 2024-07-08 15:18:53 --> Config Class Initialized
INFO - 2024-07-08 15:18:53 --> Hooks Class Initialized
DEBUG - 2024-07-08 15:18:53 --> UTF-8 Support Enabled
INFO - 2024-07-08 15:18:53 --> Utf8 Class Initialized
INFO - 2024-07-08 15:18:53 --> URI Class Initialized
INFO - 2024-07-08 15:18:53 --> Router Class Initialized
INFO - 2024-07-08 15:18:53 --> Output Class Initialized
INFO - 2024-07-08 15:18:53 --> Security Class Initialized
DEBUG - 2024-07-08 15:18:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-07-08 15:18:53 --> Input Class Initialized
INFO - 2024-07-08 15:18:53 --> Language Class Initialized
INFO - 2024-07-08 15:18:53 --> Language Class Initialized
INFO - 2024-07-08 15:18:53 --> Config Class Initialized
INFO - 2024-07-08 15:18:53 --> Loader Class Initialized
INFO - 2024-07-08 15:18:53 --> Helper loaded: url_helper
INFO - 2024-07-08 15:18:53 --> Helper loaded: file_helper
INFO - 2024-07-08 15:18:53 --> Helper loaded: form_helper
INFO - 2024-07-08 15:18:53 --> Helper loaded: my_helper
INFO - 2024-07-08 15:18:53 --> Database Driver Class Initialized
INFO - 2024-07-08 15:18:53 --> Session: Class initialized using 'files' driver.
INFO - 2024-07-08 15:18:53 --> Controller Class Initialized
DEBUG - 2024-07-08 15:18:53 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/data_siswa/views/list.php
DEBUG - 2024-07-08 15:18:53 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-07-08 15:18:53 --> Final output sent to browser
DEBUG - 2024-07-08 15:18:53 --> Total execution time: 0.0432
INFO - 2024-07-08 15:18:53 --> Config Class Initialized
INFO - 2024-07-08 15:18:53 --> Hooks Class Initialized
DEBUG - 2024-07-08 15:18:53 --> UTF-8 Support Enabled
INFO - 2024-07-08 15:18:53 --> Utf8 Class Initialized
INFO - 2024-07-08 15:18:53 --> URI Class Initialized
INFO - 2024-07-08 15:18:53 --> Router Class Initialized
INFO - 2024-07-08 15:18:53 --> Output Class Initialized
INFO - 2024-07-08 15:18:53 --> Security Class Initialized
DEBUG - 2024-07-08 15:18:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-07-08 15:18:53 --> Input Class Initialized
INFO - 2024-07-08 15:18:53 --> Language Class Initialized
ERROR - 2024-07-08 15:18:53 --> 404 Page Not Found: /index
INFO - 2024-07-08 15:18:53 --> Config Class Initialized
INFO - 2024-07-08 15:18:53 --> Hooks Class Initialized
DEBUG - 2024-07-08 15:18:53 --> UTF-8 Support Enabled
INFO - 2024-07-08 15:18:53 --> Utf8 Class Initialized
INFO - 2024-07-08 15:18:53 --> URI Class Initialized
INFO - 2024-07-08 15:18:53 --> Router Class Initialized
INFO - 2024-07-08 15:18:53 --> Output Class Initialized
INFO - 2024-07-08 15:18:53 --> Security Class Initialized
DEBUG - 2024-07-08 15:18:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-07-08 15:18:53 --> Input Class Initialized
INFO - 2024-07-08 15:18:53 --> Language Class Initialized
INFO - 2024-07-08 15:18:53 --> Language Class Initialized
INFO - 2024-07-08 15:18:53 --> Config Class Initialized
INFO - 2024-07-08 15:18:53 --> Loader Class Initialized
INFO - 2024-07-08 15:18:53 --> Helper loaded: url_helper
INFO - 2024-07-08 15:18:53 --> Helper loaded: file_helper
INFO - 2024-07-08 15:18:53 --> Helper loaded: form_helper
INFO - 2024-07-08 15:18:53 --> Helper loaded: my_helper
INFO - 2024-07-08 15:18:53 --> Database Driver Class Initialized
INFO - 2024-07-08 15:18:53 --> Session: Class initialized using 'files' driver.
INFO - 2024-07-08 15:18:53 --> Controller Class Initialized
INFO - 2024-07-08 15:18:55 --> Config Class Initialized
INFO - 2024-07-08 15:18:55 --> Hooks Class Initialized
DEBUG - 2024-07-08 15:18:55 --> UTF-8 Support Enabled
INFO - 2024-07-08 15:18:55 --> Utf8 Class Initialized
INFO - 2024-07-08 15:18:55 --> URI Class Initialized
INFO - 2024-07-08 15:18:55 --> Router Class Initialized
INFO - 2024-07-08 15:18:55 --> Output Class Initialized
INFO - 2024-07-08 15:18:55 --> Security Class Initialized
DEBUG - 2024-07-08 15:18:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-07-08 15:18:55 --> Input Class Initialized
INFO - 2024-07-08 15:18:55 --> Language Class Initialized
INFO - 2024-07-08 15:18:55 --> Language Class Initialized
INFO - 2024-07-08 15:18:55 --> Config Class Initialized
INFO - 2024-07-08 15:18:55 --> Loader Class Initialized
INFO - 2024-07-08 15:18:55 --> Helper loaded: url_helper
INFO - 2024-07-08 15:18:55 --> Helper loaded: file_helper
INFO - 2024-07-08 15:18:55 --> Helper loaded: form_helper
INFO - 2024-07-08 15:18:55 --> Helper loaded: my_helper
INFO - 2024-07-08 15:18:55 --> Database Driver Class Initialized
INFO - 2024-07-08 15:18:55 --> Session: Class initialized using 'files' driver.
INFO - 2024-07-08 15:18:55 --> Controller Class Initialized
INFO - 2024-07-08 15:18:57 --> Config Class Initialized
INFO - 2024-07-08 15:18:57 --> Hooks Class Initialized
DEBUG - 2024-07-08 15:18:57 --> UTF-8 Support Enabled
INFO - 2024-07-08 15:18:57 --> Utf8 Class Initialized
INFO - 2024-07-08 15:18:57 --> URI Class Initialized
INFO - 2024-07-08 15:18:57 --> Router Class Initialized
INFO - 2024-07-08 15:18:57 --> Output Class Initialized
INFO - 2024-07-08 15:18:57 --> Security Class Initialized
DEBUG - 2024-07-08 15:18:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-07-08 15:18:57 --> Input Class Initialized
INFO - 2024-07-08 15:18:57 --> Language Class Initialized
INFO - 2024-07-08 15:18:57 --> Language Class Initialized
INFO - 2024-07-08 15:18:57 --> Config Class Initialized
INFO - 2024-07-08 15:18:57 --> Loader Class Initialized
INFO - 2024-07-08 15:18:57 --> Helper loaded: url_helper
INFO - 2024-07-08 15:18:57 --> Helper loaded: file_helper
INFO - 2024-07-08 15:18:57 --> Helper loaded: form_helper
INFO - 2024-07-08 15:18:57 --> Helper loaded: my_helper
INFO - 2024-07-08 15:18:57 --> Database Driver Class Initialized
INFO - 2024-07-08 15:18:57 --> Session: Class initialized using 'files' driver.
INFO - 2024-07-08 15:18:57 --> Controller Class Initialized
INFO - 2024-07-08 15:18:57 --> Config Class Initialized
INFO - 2024-07-08 15:18:57 --> Hooks Class Initialized
DEBUG - 2024-07-08 15:18:58 --> UTF-8 Support Enabled
INFO - 2024-07-08 15:18:58 --> Utf8 Class Initialized
INFO - 2024-07-08 15:18:58 --> URI Class Initialized
INFO - 2024-07-08 15:18:58 --> Router Class Initialized
INFO - 2024-07-08 15:18:58 --> Output Class Initialized
INFO - 2024-07-08 15:18:58 --> Security Class Initialized
DEBUG - 2024-07-08 15:18:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-07-08 15:18:58 --> Input Class Initialized
INFO - 2024-07-08 15:18:58 --> Language Class Initialized
INFO - 2024-07-08 15:18:58 --> Language Class Initialized
INFO - 2024-07-08 15:18:58 --> Config Class Initialized
INFO - 2024-07-08 15:18:58 --> Loader Class Initialized
INFO - 2024-07-08 15:18:58 --> Helper loaded: url_helper
INFO - 2024-07-08 15:18:58 --> Helper loaded: file_helper
INFO - 2024-07-08 15:18:58 --> Helper loaded: form_helper
INFO - 2024-07-08 15:18:58 --> Helper loaded: my_helper
INFO - 2024-07-08 15:18:58 --> Database Driver Class Initialized
INFO - 2024-07-08 15:18:58 --> Session: Class initialized using 'files' driver.
INFO - 2024-07-08 15:18:58 --> Controller Class Initialized
DEBUG - 2024-07-08 15:18:58 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/data_siswa/views/list.php
DEBUG - 2024-07-08 15:18:58 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-07-08 15:18:58 --> Final output sent to browser
DEBUG - 2024-07-08 15:18:58 --> Total execution time: 0.0386
INFO - 2024-07-08 15:18:58 --> Config Class Initialized
INFO - 2024-07-08 15:18:58 --> Hooks Class Initialized
DEBUG - 2024-07-08 15:18:58 --> UTF-8 Support Enabled
INFO - 2024-07-08 15:18:58 --> Utf8 Class Initialized
INFO - 2024-07-08 15:18:58 --> URI Class Initialized
INFO - 2024-07-08 15:18:58 --> Router Class Initialized
INFO - 2024-07-08 15:18:58 --> Output Class Initialized
INFO - 2024-07-08 15:18:58 --> Security Class Initialized
DEBUG - 2024-07-08 15:18:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-07-08 15:18:58 --> Input Class Initialized
INFO - 2024-07-08 15:18:58 --> Language Class Initialized
ERROR - 2024-07-08 15:18:58 --> 404 Page Not Found: /index
INFO - 2024-07-08 15:18:58 --> Config Class Initialized
INFO - 2024-07-08 15:18:58 --> Hooks Class Initialized
DEBUG - 2024-07-08 15:18:58 --> UTF-8 Support Enabled
INFO - 2024-07-08 15:18:58 --> Utf8 Class Initialized
INFO - 2024-07-08 15:18:58 --> URI Class Initialized
INFO - 2024-07-08 15:18:58 --> Router Class Initialized
INFO - 2024-07-08 15:18:58 --> Output Class Initialized
INFO - 2024-07-08 15:18:58 --> Security Class Initialized
DEBUG - 2024-07-08 15:18:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-07-08 15:18:58 --> Input Class Initialized
INFO - 2024-07-08 15:18:58 --> Language Class Initialized
INFO - 2024-07-08 15:18:58 --> Language Class Initialized
INFO - 2024-07-08 15:18:58 --> Config Class Initialized
INFO - 2024-07-08 15:18:58 --> Loader Class Initialized
INFO - 2024-07-08 15:18:58 --> Helper loaded: url_helper
INFO - 2024-07-08 15:18:58 --> Helper loaded: file_helper
INFO - 2024-07-08 15:18:58 --> Helper loaded: form_helper
INFO - 2024-07-08 15:18:58 --> Helper loaded: my_helper
INFO - 2024-07-08 15:18:58 --> Database Driver Class Initialized
INFO - 2024-07-08 15:18:58 --> Session: Class initialized using 'files' driver.
INFO - 2024-07-08 15:18:58 --> Controller Class Initialized
INFO - 2024-07-08 15:19:01 --> Config Class Initialized
INFO - 2024-07-08 15:19:01 --> Hooks Class Initialized
DEBUG - 2024-07-08 15:19:01 --> UTF-8 Support Enabled
INFO - 2024-07-08 15:19:01 --> Utf8 Class Initialized
INFO - 2024-07-08 15:19:01 --> URI Class Initialized
INFO - 2024-07-08 15:19:01 --> Router Class Initialized
INFO - 2024-07-08 15:19:01 --> Output Class Initialized
INFO - 2024-07-08 15:19:01 --> Security Class Initialized
DEBUG - 2024-07-08 15:19:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-07-08 15:19:01 --> Input Class Initialized
INFO - 2024-07-08 15:19:01 --> Language Class Initialized
INFO - 2024-07-08 15:19:01 --> Language Class Initialized
INFO - 2024-07-08 15:19:01 --> Config Class Initialized
INFO - 2024-07-08 15:19:01 --> Loader Class Initialized
INFO - 2024-07-08 15:19:01 --> Helper loaded: url_helper
INFO - 2024-07-08 15:19:01 --> Helper loaded: file_helper
INFO - 2024-07-08 15:19:01 --> Helper loaded: form_helper
INFO - 2024-07-08 15:19:01 --> Helper loaded: my_helper
INFO - 2024-07-08 15:19:01 --> Database Driver Class Initialized
INFO - 2024-07-08 15:19:01 --> Session: Class initialized using 'files' driver.
INFO - 2024-07-08 15:19:01 --> Controller Class Initialized
INFO - 2024-07-08 15:19:03 --> Config Class Initialized
INFO - 2024-07-08 15:19:03 --> Hooks Class Initialized
DEBUG - 2024-07-08 15:19:03 --> UTF-8 Support Enabled
INFO - 2024-07-08 15:19:03 --> Utf8 Class Initialized
INFO - 2024-07-08 15:19:03 --> URI Class Initialized
INFO - 2024-07-08 15:19:03 --> Router Class Initialized
INFO - 2024-07-08 15:19:03 --> Output Class Initialized
INFO - 2024-07-08 15:19:03 --> Security Class Initialized
DEBUG - 2024-07-08 15:19:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-07-08 15:19:03 --> Input Class Initialized
INFO - 2024-07-08 15:19:03 --> Language Class Initialized
INFO - 2024-07-08 15:19:03 --> Language Class Initialized
INFO - 2024-07-08 15:19:03 --> Config Class Initialized
INFO - 2024-07-08 15:19:03 --> Loader Class Initialized
INFO - 2024-07-08 15:19:03 --> Helper loaded: url_helper
INFO - 2024-07-08 15:19:03 --> Helper loaded: file_helper
INFO - 2024-07-08 15:19:03 --> Helper loaded: form_helper
INFO - 2024-07-08 15:19:03 --> Helper loaded: my_helper
INFO - 2024-07-08 15:19:03 --> Database Driver Class Initialized
INFO - 2024-07-08 15:19:03 --> Session: Class initialized using 'files' driver.
INFO - 2024-07-08 15:19:03 --> Controller Class Initialized
INFO - 2024-07-08 15:19:03 --> Config Class Initialized
INFO - 2024-07-08 15:19:03 --> Hooks Class Initialized
DEBUG - 2024-07-08 15:19:03 --> UTF-8 Support Enabled
INFO - 2024-07-08 15:19:03 --> Utf8 Class Initialized
INFO - 2024-07-08 15:19:03 --> URI Class Initialized
INFO - 2024-07-08 15:19:03 --> Router Class Initialized
INFO - 2024-07-08 15:19:03 --> Output Class Initialized
INFO - 2024-07-08 15:19:03 --> Security Class Initialized
DEBUG - 2024-07-08 15:19:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-07-08 15:19:03 --> Input Class Initialized
INFO - 2024-07-08 15:19:03 --> Language Class Initialized
INFO - 2024-07-08 15:19:03 --> Language Class Initialized
INFO - 2024-07-08 15:19:03 --> Config Class Initialized
INFO - 2024-07-08 15:19:03 --> Loader Class Initialized
INFO - 2024-07-08 15:19:03 --> Helper loaded: url_helper
INFO - 2024-07-08 15:19:03 --> Helper loaded: file_helper
INFO - 2024-07-08 15:19:04 --> Helper loaded: form_helper
INFO - 2024-07-08 15:19:04 --> Helper loaded: my_helper
INFO - 2024-07-08 15:19:04 --> Database Driver Class Initialized
INFO - 2024-07-08 15:19:04 --> Session: Class initialized using 'files' driver.
INFO - 2024-07-08 15:19:04 --> Controller Class Initialized
DEBUG - 2024-07-08 15:19:04 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/data_siswa/views/list.php
DEBUG - 2024-07-08 15:19:04 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-07-08 15:19:04 --> Final output sent to browser
DEBUG - 2024-07-08 15:19:04 --> Total execution time: 0.1226
INFO - 2024-07-08 15:19:04 --> Config Class Initialized
INFO - 2024-07-08 15:19:04 --> Hooks Class Initialized
DEBUG - 2024-07-08 15:19:04 --> UTF-8 Support Enabled
INFO - 2024-07-08 15:19:04 --> Utf8 Class Initialized
INFO - 2024-07-08 15:19:04 --> URI Class Initialized
INFO - 2024-07-08 15:19:04 --> Router Class Initialized
INFO - 2024-07-08 15:19:04 --> Output Class Initialized
INFO - 2024-07-08 15:19:04 --> Security Class Initialized
DEBUG - 2024-07-08 15:19:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-07-08 15:19:04 --> Input Class Initialized
INFO - 2024-07-08 15:19:04 --> Language Class Initialized
ERROR - 2024-07-08 15:19:04 --> 404 Page Not Found: /index
INFO - 2024-07-08 15:19:04 --> Config Class Initialized
INFO - 2024-07-08 15:19:04 --> Hooks Class Initialized
DEBUG - 2024-07-08 15:19:04 --> UTF-8 Support Enabled
INFO - 2024-07-08 15:19:04 --> Utf8 Class Initialized
INFO - 2024-07-08 15:19:04 --> URI Class Initialized
INFO - 2024-07-08 15:19:04 --> Router Class Initialized
INFO - 2024-07-08 15:19:04 --> Output Class Initialized
INFO - 2024-07-08 15:19:04 --> Security Class Initialized
DEBUG - 2024-07-08 15:19:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-07-08 15:19:04 --> Input Class Initialized
INFO - 2024-07-08 15:19:04 --> Language Class Initialized
INFO - 2024-07-08 15:19:04 --> Language Class Initialized
INFO - 2024-07-08 15:19:04 --> Config Class Initialized
INFO - 2024-07-08 15:19:04 --> Loader Class Initialized
INFO - 2024-07-08 15:19:04 --> Helper loaded: url_helper
INFO - 2024-07-08 15:19:04 --> Helper loaded: file_helper
INFO - 2024-07-08 15:19:04 --> Helper loaded: form_helper
INFO - 2024-07-08 15:19:04 --> Helper loaded: my_helper
INFO - 2024-07-08 15:19:04 --> Database Driver Class Initialized
INFO - 2024-07-08 15:19:04 --> Session: Class initialized using 'files' driver.
INFO - 2024-07-08 15:19:04 --> Controller Class Initialized
INFO - 2024-07-08 15:19:05 --> Config Class Initialized
INFO - 2024-07-08 15:19:05 --> Hooks Class Initialized
DEBUG - 2024-07-08 15:19:05 --> UTF-8 Support Enabled
INFO - 2024-07-08 15:19:05 --> Utf8 Class Initialized
INFO - 2024-07-08 15:19:05 --> URI Class Initialized
INFO - 2024-07-08 15:19:05 --> Router Class Initialized
INFO - 2024-07-08 15:19:05 --> Output Class Initialized
INFO - 2024-07-08 15:19:05 --> Security Class Initialized
DEBUG - 2024-07-08 15:19:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-07-08 15:19:05 --> Input Class Initialized
INFO - 2024-07-08 15:19:05 --> Language Class Initialized
INFO - 2024-07-08 15:19:05 --> Language Class Initialized
INFO - 2024-07-08 15:19:05 --> Config Class Initialized
INFO - 2024-07-08 15:19:05 --> Loader Class Initialized
INFO - 2024-07-08 15:19:05 --> Helper loaded: url_helper
INFO - 2024-07-08 15:19:05 --> Helper loaded: file_helper
INFO - 2024-07-08 15:19:05 --> Helper loaded: form_helper
INFO - 2024-07-08 15:19:05 --> Helper loaded: my_helper
INFO - 2024-07-08 15:19:05 --> Database Driver Class Initialized
INFO - 2024-07-08 15:19:05 --> Session: Class initialized using 'files' driver.
INFO - 2024-07-08 15:19:05 --> Controller Class Initialized
INFO - 2024-07-08 15:19:08 --> Config Class Initialized
INFO - 2024-07-08 15:19:08 --> Hooks Class Initialized
DEBUG - 2024-07-08 15:19:08 --> UTF-8 Support Enabled
INFO - 2024-07-08 15:19:08 --> Utf8 Class Initialized
INFO - 2024-07-08 15:19:08 --> URI Class Initialized
INFO - 2024-07-08 15:19:08 --> Router Class Initialized
INFO - 2024-07-08 15:19:08 --> Output Class Initialized
INFO - 2024-07-08 15:19:08 --> Security Class Initialized
DEBUG - 2024-07-08 15:19:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-07-08 15:19:08 --> Input Class Initialized
INFO - 2024-07-08 15:19:08 --> Language Class Initialized
INFO - 2024-07-08 15:19:08 --> Language Class Initialized
INFO - 2024-07-08 15:19:08 --> Config Class Initialized
INFO - 2024-07-08 15:19:08 --> Loader Class Initialized
INFO - 2024-07-08 15:19:08 --> Helper loaded: url_helper
INFO - 2024-07-08 15:19:08 --> Helper loaded: file_helper
INFO - 2024-07-08 15:19:08 --> Helper loaded: form_helper
INFO - 2024-07-08 15:19:08 --> Helper loaded: my_helper
INFO - 2024-07-08 15:19:08 --> Database Driver Class Initialized
INFO - 2024-07-08 15:19:08 --> Session: Class initialized using 'files' driver.
INFO - 2024-07-08 15:19:08 --> Controller Class Initialized
INFO - 2024-07-08 15:19:08 --> Config Class Initialized
INFO - 2024-07-08 15:19:08 --> Hooks Class Initialized
DEBUG - 2024-07-08 15:19:08 --> UTF-8 Support Enabled
INFO - 2024-07-08 15:19:08 --> Utf8 Class Initialized
INFO - 2024-07-08 15:19:08 --> URI Class Initialized
INFO - 2024-07-08 15:19:08 --> Router Class Initialized
INFO - 2024-07-08 15:19:08 --> Output Class Initialized
INFO - 2024-07-08 15:19:08 --> Security Class Initialized
DEBUG - 2024-07-08 15:19:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-07-08 15:19:08 --> Input Class Initialized
INFO - 2024-07-08 15:19:08 --> Language Class Initialized
INFO - 2024-07-08 15:19:08 --> Language Class Initialized
INFO - 2024-07-08 15:19:08 --> Config Class Initialized
INFO - 2024-07-08 15:19:08 --> Loader Class Initialized
INFO - 2024-07-08 15:19:08 --> Helper loaded: url_helper
INFO - 2024-07-08 15:19:08 --> Helper loaded: file_helper
INFO - 2024-07-08 15:19:08 --> Helper loaded: form_helper
INFO - 2024-07-08 15:19:08 --> Helper loaded: my_helper
INFO - 2024-07-08 15:19:08 --> Database Driver Class Initialized
INFO - 2024-07-08 15:19:08 --> Session: Class initialized using 'files' driver.
INFO - 2024-07-08 15:19:08 --> Controller Class Initialized
DEBUG - 2024-07-08 15:19:08 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/data_siswa/views/list.php
DEBUG - 2024-07-08 15:19:08 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-07-08 15:19:08 --> Final output sent to browser
DEBUG - 2024-07-08 15:19:08 --> Total execution time: 0.0569
INFO - 2024-07-08 15:19:08 --> Config Class Initialized
INFO - 2024-07-08 15:19:08 --> Hooks Class Initialized
DEBUG - 2024-07-08 15:19:08 --> UTF-8 Support Enabled
INFO - 2024-07-08 15:19:08 --> Utf8 Class Initialized
INFO - 2024-07-08 15:19:08 --> URI Class Initialized
INFO - 2024-07-08 15:19:08 --> Router Class Initialized
INFO - 2024-07-08 15:19:08 --> Output Class Initialized
INFO - 2024-07-08 15:19:08 --> Security Class Initialized
DEBUG - 2024-07-08 15:19:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-07-08 15:19:08 --> Input Class Initialized
INFO - 2024-07-08 15:19:08 --> Language Class Initialized
ERROR - 2024-07-08 15:19:08 --> 404 Page Not Found: /index
INFO - 2024-07-08 15:19:08 --> Config Class Initialized
INFO - 2024-07-08 15:19:08 --> Hooks Class Initialized
DEBUG - 2024-07-08 15:19:08 --> UTF-8 Support Enabled
INFO - 2024-07-08 15:19:08 --> Utf8 Class Initialized
INFO - 2024-07-08 15:19:08 --> URI Class Initialized
INFO - 2024-07-08 15:19:08 --> Router Class Initialized
INFO - 2024-07-08 15:19:08 --> Output Class Initialized
INFO - 2024-07-08 15:19:08 --> Security Class Initialized
DEBUG - 2024-07-08 15:19:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-07-08 15:19:08 --> Input Class Initialized
INFO - 2024-07-08 15:19:08 --> Language Class Initialized
INFO - 2024-07-08 15:19:08 --> Language Class Initialized
INFO - 2024-07-08 15:19:08 --> Config Class Initialized
INFO - 2024-07-08 15:19:08 --> Loader Class Initialized
INFO - 2024-07-08 15:19:08 --> Helper loaded: url_helper
INFO - 2024-07-08 15:19:08 --> Helper loaded: file_helper
INFO - 2024-07-08 15:19:08 --> Helper loaded: form_helper
INFO - 2024-07-08 15:19:08 --> Helper loaded: my_helper
INFO - 2024-07-08 15:19:08 --> Database Driver Class Initialized
INFO - 2024-07-08 15:19:08 --> Session: Class initialized using 'files' driver.
INFO - 2024-07-08 15:19:08 --> Controller Class Initialized
INFO - 2024-07-08 15:19:09 --> Config Class Initialized
INFO - 2024-07-08 15:19:09 --> Hooks Class Initialized
DEBUG - 2024-07-08 15:19:09 --> UTF-8 Support Enabled
INFO - 2024-07-08 15:19:09 --> Utf8 Class Initialized
INFO - 2024-07-08 15:19:09 --> URI Class Initialized
INFO - 2024-07-08 15:19:09 --> Router Class Initialized
INFO - 2024-07-08 15:19:09 --> Output Class Initialized
INFO - 2024-07-08 15:19:09 --> Security Class Initialized
DEBUG - 2024-07-08 15:19:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-07-08 15:19:09 --> Input Class Initialized
INFO - 2024-07-08 15:19:09 --> Language Class Initialized
INFO - 2024-07-08 15:19:09 --> Language Class Initialized
INFO - 2024-07-08 15:19:09 --> Config Class Initialized
INFO - 2024-07-08 15:19:09 --> Loader Class Initialized
INFO - 2024-07-08 15:19:09 --> Helper loaded: url_helper
INFO - 2024-07-08 15:19:09 --> Helper loaded: file_helper
INFO - 2024-07-08 15:19:09 --> Helper loaded: form_helper
INFO - 2024-07-08 15:19:09 --> Helper loaded: my_helper
INFO - 2024-07-08 15:19:09 --> Database Driver Class Initialized
INFO - 2024-07-08 15:19:09 --> Session: Class initialized using 'files' driver.
INFO - 2024-07-08 15:19:09 --> Controller Class Initialized
INFO - 2024-07-08 15:19:11 --> Config Class Initialized
INFO - 2024-07-08 15:19:11 --> Hooks Class Initialized
DEBUG - 2024-07-08 15:19:11 --> UTF-8 Support Enabled
INFO - 2024-07-08 15:19:11 --> Utf8 Class Initialized
INFO - 2024-07-08 15:19:11 --> URI Class Initialized
INFO - 2024-07-08 15:19:11 --> Router Class Initialized
INFO - 2024-07-08 15:19:11 --> Output Class Initialized
INFO - 2024-07-08 15:19:11 --> Security Class Initialized
DEBUG - 2024-07-08 15:19:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-07-08 15:19:11 --> Input Class Initialized
INFO - 2024-07-08 15:19:11 --> Language Class Initialized
INFO - 2024-07-08 15:19:11 --> Language Class Initialized
INFO - 2024-07-08 15:19:11 --> Config Class Initialized
INFO - 2024-07-08 15:19:11 --> Loader Class Initialized
INFO - 2024-07-08 15:19:11 --> Helper loaded: url_helper
INFO - 2024-07-08 15:19:11 --> Helper loaded: file_helper
INFO - 2024-07-08 15:19:11 --> Helper loaded: form_helper
INFO - 2024-07-08 15:19:11 --> Helper loaded: my_helper
INFO - 2024-07-08 15:19:11 --> Database Driver Class Initialized
INFO - 2024-07-08 15:19:11 --> Session: Class initialized using 'files' driver.
INFO - 2024-07-08 15:19:11 --> Controller Class Initialized
INFO - 2024-07-08 15:19:11 --> Config Class Initialized
INFO - 2024-07-08 15:19:11 --> Hooks Class Initialized
DEBUG - 2024-07-08 15:19:11 --> UTF-8 Support Enabled
INFO - 2024-07-08 15:19:11 --> Utf8 Class Initialized
INFO - 2024-07-08 15:19:11 --> URI Class Initialized
INFO - 2024-07-08 15:19:11 --> Router Class Initialized
INFO - 2024-07-08 15:19:11 --> Output Class Initialized
INFO - 2024-07-08 15:19:11 --> Security Class Initialized
DEBUG - 2024-07-08 15:19:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-07-08 15:19:11 --> Input Class Initialized
INFO - 2024-07-08 15:19:11 --> Language Class Initialized
INFO - 2024-07-08 15:19:11 --> Language Class Initialized
INFO - 2024-07-08 15:19:11 --> Config Class Initialized
INFO - 2024-07-08 15:19:11 --> Loader Class Initialized
INFO - 2024-07-08 15:19:11 --> Helper loaded: url_helper
INFO - 2024-07-08 15:19:11 --> Helper loaded: file_helper
INFO - 2024-07-08 15:19:11 --> Helper loaded: form_helper
INFO - 2024-07-08 15:19:11 --> Helper loaded: my_helper
INFO - 2024-07-08 15:19:11 --> Database Driver Class Initialized
INFO - 2024-07-08 15:19:11 --> Session: Class initialized using 'files' driver.
INFO - 2024-07-08 15:19:11 --> Controller Class Initialized
DEBUG - 2024-07-08 15:19:11 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/data_siswa/views/list.php
DEBUG - 2024-07-08 15:19:11 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-07-08 15:19:12 --> Final output sent to browser
DEBUG - 2024-07-08 15:19:12 --> Total execution time: 0.0543
INFO - 2024-07-08 15:19:12 --> Config Class Initialized
INFO - 2024-07-08 15:19:12 --> Hooks Class Initialized
DEBUG - 2024-07-08 15:19:12 --> UTF-8 Support Enabled
INFO - 2024-07-08 15:19:12 --> Utf8 Class Initialized
INFO - 2024-07-08 15:19:12 --> URI Class Initialized
INFO - 2024-07-08 15:19:12 --> Router Class Initialized
INFO - 2024-07-08 15:19:12 --> Output Class Initialized
INFO - 2024-07-08 15:19:12 --> Security Class Initialized
DEBUG - 2024-07-08 15:19:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-07-08 15:19:12 --> Input Class Initialized
INFO - 2024-07-08 15:19:12 --> Language Class Initialized
ERROR - 2024-07-08 15:19:12 --> 404 Page Not Found: /index
INFO - 2024-07-08 15:19:12 --> Config Class Initialized
INFO - 2024-07-08 15:19:12 --> Hooks Class Initialized
DEBUG - 2024-07-08 15:19:12 --> UTF-8 Support Enabled
INFO - 2024-07-08 15:19:12 --> Utf8 Class Initialized
INFO - 2024-07-08 15:19:12 --> URI Class Initialized
INFO - 2024-07-08 15:19:12 --> Router Class Initialized
INFO - 2024-07-08 15:19:12 --> Output Class Initialized
INFO - 2024-07-08 15:19:12 --> Security Class Initialized
DEBUG - 2024-07-08 15:19:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-07-08 15:19:12 --> Input Class Initialized
INFO - 2024-07-08 15:19:12 --> Language Class Initialized
INFO - 2024-07-08 15:19:12 --> Language Class Initialized
INFO - 2024-07-08 15:19:12 --> Config Class Initialized
INFO - 2024-07-08 15:19:12 --> Loader Class Initialized
INFO - 2024-07-08 15:19:12 --> Helper loaded: url_helper
INFO - 2024-07-08 15:19:12 --> Helper loaded: file_helper
INFO - 2024-07-08 15:19:12 --> Helper loaded: form_helper
INFO - 2024-07-08 15:19:12 --> Helper loaded: my_helper
INFO - 2024-07-08 15:19:12 --> Database Driver Class Initialized
INFO - 2024-07-08 15:19:12 --> Session: Class initialized using 'files' driver.
INFO - 2024-07-08 15:19:12 --> Controller Class Initialized
INFO - 2024-07-08 15:19:13 --> Config Class Initialized
INFO - 2024-07-08 15:19:13 --> Hooks Class Initialized
DEBUG - 2024-07-08 15:19:13 --> UTF-8 Support Enabled
INFO - 2024-07-08 15:19:13 --> Utf8 Class Initialized
INFO - 2024-07-08 15:19:13 --> URI Class Initialized
INFO - 2024-07-08 15:19:13 --> Router Class Initialized
INFO - 2024-07-08 15:19:13 --> Output Class Initialized
INFO - 2024-07-08 15:19:13 --> Security Class Initialized
DEBUG - 2024-07-08 15:19:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-07-08 15:19:13 --> Input Class Initialized
INFO - 2024-07-08 15:19:13 --> Language Class Initialized
INFO - 2024-07-08 15:19:13 --> Language Class Initialized
INFO - 2024-07-08 15:19:13 --> Config Class Initialized
INFO - 2024-07-08 15:19:13 --> Loader Class Initialized
INFO - 2024-07-08 15:19:13 --> Helper loaded: url_helper
INFO - 2024-07-08 15:19:13 --> Helper loaded: file_helper
INFO - 2024-07-08 15:19:13 --> Helper loaded: form_helper
INFO - 2024-07-08 15:19:13 --> Helper loaded: my_helper
INFO - 2024-07-08 15:19:13 --> Database Driver Class Initialized
INFO - 2024-07-08 15:19:13 --> Session: Class initialized using 'files' driver.
INFO - 2024-07-08 15:19:13 --> Controller Class Initialized
INFO - 2024-07-08 15:19:15 --> Config Class Initialized
INFO - 2024-07-08 15:19:15 --> Hooks Class Initialized
DEBUG - 2024-07-08 15:19:15 --> UTF-8 Support Enabled
INFO - 2024-07-08 15:19:15 --> Utf8 Class Initialized
INFO - 2024-07-08 15:19:15 --> URI Class Initialized
INFO - 2024-07-08 15:19:15 --> Router Class Initialized
INFO - 2024-07-08 15:19:15 --> Output Class Initialized
INFO - 2024-07-08 15:19:15 --> Security Class Initialized
DEBUG - 2024-07-08 15:19:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-07-08 15:19:15 --> Input Class Initialized
INFO - 2024-07-08 15:19:15 --> Language Class Initialized
INFO - 2024-07-08 15:19:15 --> Language Class Initialized
INFO - 2024-07-08 15:19:15 --> Config Class Initialized
INFO - 2024-07-08 15:19:15 --> Loader Class Initialized
INFO - 2024-07-08 15:19:15 --> Helper loaded: url_helper
INFO - 2024-07-08 15:19:15 --> Helper loaded: file_helper
INFO - 2024-07-08 15:19:15 --> Helper loaded: form_helper
INFO - 2024-07-08 15:19:15 --> Helper loaded: my_helper
INFO - 2024-07-08 15:19:15 --> Database Driver Class Initialized
INFO - 2024-07-08 15:19:15 --> Session: Class initialized using 'files' driver.
INFO - 2024-07-08 15:19:15 --> Controller Class Initialized
INFO - 2024-07-08 15:19:15 --> Config Class Initialized
INFO - 2024-07-08 15:19:15 --> Hooks Class Initialized
DEBUG - 2024-07-08 15:19:15 --> UTF-8 Support Enabled
INFO - 2024-07-08 15:19:15 --> Utf8 Class Initialized
INFO - 2024-07-08 15:19:15 --> URI Class Initialized
INFO - 2024-07-08 15:19:15 --> Router Class Initialized
INFO - 2024-07-08 15:19:15 --> Output Class Initialized
INFO - 2024-07-08 15:19:15 --> Security Class Initialized
DEBUG - 2024-07-08 15:19:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-07-08 15:19:15 --> Input Class Initialized
INFO - 2024-07-08 15:19:15 --> Language Class Initialized
INFO - 2024-07-08 15:19:15 --> Language Class Initialized
INFO - 2024-07-08 15:19:15 --> Config Class Initialized
INFO - 2024-07-08 15:19:15 --> Loader Class Initialized
INFO - 2024-07-08 15:19:15 --> Helper loaded: url_helper
INFO - 2024-07-08 15:19:15 --> Helper loaded: file_helper
INFO - 2024-07-08 15:19:15 --> Helper loaded: form_helper
INFO - 2024-07-08 15:19:15 --> Helper loaded: my_helper
INFO - 2024-07-08 15:19:15 --> Database Driver Class Initialized
INFO - 2024-07-08 15:19:15 --> Session: Class initialized using 'files' driver.
INFO - 2024-07-08 15:19:15 --> Controller Class Initialized
DEBUG - 2024-07-08 15:19:15 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/data_siswa/views/list.php
DEBUG - 2024-07-08 15:19:15 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-07-08 15:19:15 --> Final output sent to browser
DEBUG - 2024-07-08 15:19:15 --> Total execution time: 0.0364
INFO - 2024-07-08 15:19:15 --> Config Class Initialized
INFO - 2024-07-08 15:19:15 --> Hooks Class Initialized
DEBUG - 2024-07-08 15:19:15 --> UTF-8 Support Enabled
INFO - 2024-07-08 15:19:15 --> Utf8 Class Initialized
INFO - 2024-07-08 15:19:15 --> URI Class Initialized
INFO - 2024-07-08 15:19:15 --> Router Class Initialized
INFO - 2024-07-08 15:19:15 --> Output Class Initialized
INFO - 2024-07-08 15:19:15 --> Security Class Initialized
DEBUG - 2024-07-08 15:19:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-07-08 15:19:15 --> Input Class Initialized
INFO - 2024-07-08 15:19:15 --> Language Class Initialized
ERROR - 2024-07-08 15:19:15 --> 404 Page Not Found: /index
INFO - 2024-07-08 15:19:15 --> Config Class Initialized
INFO - 2024-07-08 15:19:15 --> Hooks Class Initialized
DEBUG - 2024-07-08 15:19:15 --> UTF-8 Support Enabled
INFO - 2024-07-08 15:19:15 --> Utf8 Class Initialized
INFO - 2024-07-08 15:19:15 --> URI Class Initialized
INFO - 2024-07-08 15:19:15 --> Router Class Initialized
INFO - 2024-07-08 15:19:15 --> Output Class Initialized
INFO - 2024-07-08 15:19:15 --> Security Class Initialized
DEBUG - 2024-07-08 15:19:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-07-08 15:19:15 --> Input Class Initialized
INFO - 2024-07-08 15:19:15 --> Language Class Initialized
INFO - 2024-07-08 15:19:15 --> Language Class Initialized
INFO - 2024-07-08 15:19:15 --> Config Class Initialized
INFO - 2024-07-08 15:19:15 --> Loader Class Initialized
INFO - 2024-07-08 15:19:15 --> Helper loaded: url_helper
INFO - 2024-07-08 15:19:15 --> Helper loaded: file_helper
INFO - 2024-07-08 15:19:15 --> Helper loaded: form_helper
INFO - 2024-07-08 15:19:15 --> Helper loaded: my_helper
INFO - 2024-07-08 15:19:15 --> Database Driver Class Initialized
INFO - 2024-07-08 15:19:15 --> Session: Class initialized using 'files' driver.
INFO - 2024-07-08 15:19:15 --> Controller Class Initialized
INFO - 2024-07-08 15:19:16 --> Config Class Initialized
INFO - 2024-07-08 15:19:16 --> Hooks Class Initialized
DEBUG - 2024-07-08 15:19:16 --> UTF-8 Support Enabled
INFO - 2024-07-08 15:19:16 --> Utf8 Class Initialized
INFO - 2024-07-08 15:19:16 --> URI Class Initialized
INFO - 2024-07-08 15:19:16 --> Router Class Initialized
INFO - 2024-07-08 15:19:16 --> Output Class Initialized
INFO - 2024-07-08 15:19:16 --> Security Class Initialized
DEBUG - 2024-07-08 15:19:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-07-08 15:19:17 --> Input Class Initialized
INFO - 2024-07-08 15:19:17 --> Language Class Initialized
INFO - 2024-07-08 15:19:17 --> Language Class Initialized
INFO - 2024-07-08 15:19:17 --> Config Class Initialized
INFO - 2024-07-08 15:19:17 --> Loader Class Initialized
INFO - 2024-07-08 15:19:17 --> Helper loaded: url_helper
INFO - 2024-07-08 15:19:17 --> Helper loaded: file_helper
INFO - 2024-07-08 15:19:17 --> Helper loaded: form_helper
INFO - 2024-07-08 15:19:17 --> Helper loaded: my_helper
INFO - 2024-07-08 15:19:17 --> Database Driver Class Initialized
INFO - 2024-07-08 15:19:17 --> Session: Class initialized using 'files' driver.
INFO - 2024-07-08 15:19:17 --> Controller Class Initialized
INFO - 2024-07-08 15:19:19 --> Config Class Initialized
INFO - 2024-07-08 15:19:19 --> Hooks Class Initialized
DEBUG - 2024-07-08 15:19:19 --> UTF-8 Support Enabled
INFO - 2024-07-08 15:19:19 --> Utf8 Class Initialized
INFO - 2024-07-08 15:19:19 --> URI Class Initialized
INFO - 2024-07-08 15:19:19 --> Router Class Initialized
INFO - 2024-07-08 15:19:19 --> Output Class Initialized
INFO - 2024-07-08 15:19:19 --> Security Class Initialized
DEBUG - 2024-07-08 15:19:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-07-08 15:19:19 --> Input Class Initialized
INFO - 2024-07-08 15:19:19 --> Language Class Initialized
INFO - 2024-07-08 15:19:19 --> Language Class Initialized
INFO - 2024-07-08 15:19:19 --> Config Class Initialized
INFO - 2024-07-08 15:19:19 --> Loader Class Initialized
INFO - 2024-07-08 15:19:19 --> Helper loaded: url_helper
INFO - 2024-07-08 15:19:19 --> Helper loaded: file_helper
INFO - 2024-07-08 15:19:19 --> Helper loaded: form_helper
INFO - 2024-07-08 15:19:19 --> Helper loaded: my_helper
INFO - 2024-07-08 15:19:19 --> Database Driver Class Initialized
INFO - 2024-07-08 15:19:19 --> Session: Class initialized using 'files' driver.
INFO - 2024-07-08 15:19:19 --> Controller Class Initialized
INFO - 2024-07-08 15:19:19 --> Config Class Initialized
INFO - 2024-07-08 15:19:19 --> Hooks Class Initialized
DEBUG - 2024-07-08 15:19:19 --> UTF-8 Support Enabled
INFO - 2024-07-08 15:19:19 --> Utf8 Class Initialized
INFO - 2024-07-08 15:19:19 --> URI Class Initialized
INFO - 2024-07-08 15:19:19 --> Router Class Initialized
INFO - 2024-07-08 15:19:19 --> Output Class Initialized
INFO - 2024-07-08 15:19:19 --> Security Class Initialized
DEBUG - 2024-07-08 15:19:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-07-08 15:19:19 --> Input Class Initialized
INFO - 2024-07-08 15:19:19 --> Language Class Initialized
INFO - 2024-07-08 15:19:19 --> Language Class Initialized
INFO - 2024-07-08 15:19:19 --> Config Class Initialized
INFO - 2024-07-08 15:19:19 --> Loader Class Initialized
INFO - 2024-07-08 15:19:19 --> Helper loaded: url_helper
INFO - 2024-07-08 15:19:19 --> Helper loaded: file_helper
INFO - 2024-07-08 15:19:19 --> Helper loaded: form_helper
INFO - 2024-07-08 15:19:19 --> Helper loaded: my_helper
INFO - 2024-07-08 15:19:19 --> Database Driver Class Initialized
INFO - 2024-07-08 15:19:19 --> Session: Class initialized using 'files' driver.
INFO - 2024-07-08 15:19:19 --> Controller Class Initialized
DEBUG - 2024-07-08 15:19:19 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/data_siswa/views/list.php
DEBUG - 2024-07-08 15:19:19 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-07-08 15:19:19 --> Final output sent to browser
DEBUG - 2024-07-08 15:19:19 --> Total execution time: 0.0309
INFO - 2024-07-08 15:19:19 --> Config Class Initialized
INFO - 2024-07-08 15:19:19 --> Hooks Class Initialized
DEBUG - 2024-07-08 15:19:19 --> UTF-8 Support Enabled
INFO - 2024-07-08 15:19:19 --> Utf8 Class Initialized
INFO - 2024-07-08 15:19:19 --> URI Class Initialized
INFO - 2024-07-08 15:19:19 --> Router Class Initialized
INFO - 2024-07-08 15:19:19 --> Output Class Initialized
INFO - 2024-07-08 15:19:19 --> Security Class Initialized
DEBUG - 2024-07-08 15:19:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-07-08 15:19:19 --> Input Class Initialized
INFO - 2024-07-08 15:19:19 --> Language Class Initialized
ERROR - 2024-07-08 15:19:19 --> 404 Page Not Found: /index
INFO - 2024-07-08 15:19:19 --> Config Class Initialized
INFO - 2024-07-08 15:19:19 --> Hooks Class Initialized
DEBUG - 2024-07-08 15:19:19 --> UTF-8 Support Enabled
INFO - 2024-07-08 15:19:19 --> Utf8 Class Initialized
INFO - 2024-07-08 15:19:19 --> URI Class Initialized
INFO - 2024-07-08 15:19:19 --> Router Class Initialized
INFO - 2024-07-08 15:19:19 --> Output Class Initialized
INFO - 2024-07-08 15:19:19 --> Security Class Initialized
DEBUG - 2024-07-08 15:19:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-07-08 15:19:19 --> Input Class Initialized
INFO - 2024-07-08 15:19:19 --> Language Class Initialized
INFO - 2024-07-08 15:19:19 --> Language Class Initialized
INFO - 2024-07-08 15:19:19 --> Config Class Initialized
INFO - 2024-07-08 15:19:19 --> Loader Class Initialized
INFO - 2024-07-08 15:19:19 --> Helper loaded: url_helper
INFO - 2024-07-08 15:19:19 --> Helper loaded: file_helper
INFO - 2024-07-08 15:19:19 --> Helper loaded: form_helper
INFO - 2024-07-08 15:19:19 --> Helper loaded: my_helper
INFO - 2024-07-08 15:19:19 --> Database Driver Class Initialized
INFO - 2024-07-08 15:19:19 --> Session: Class initialized using 'files' driver.
INFO - 2024-07-08 15:19:19 --> Controller Class Initialized
INFO - 2024-07-08 15:19:21 --> Config Class Initialized
INFO - 2024-07-08 15:19:21 --> Hooks Class Initialized
DEBUG - 2024-07-08 15:19:21 --> UTF-8 Support Enabled
INFO - 2024-07-08 15:19:21 --> Utf8 Class Initialized
INFO - 2024-07-08 15:19:21 --> URI Class Initialized
INFO - 2024-07-08 15:19:21 --> Router Class Initialized
INFO - 2024-07-08 15:19:21 --> Output Class Initialized
INFO - 2024-07-08 15:19:21 --> Security Class Initialized
DEBUG - 2024-07-08 15:19:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-07-08 15:19:21 --> Input Class Initialized
INFO - 2024-07-08 15:19:21 --> Language Class Initialized
INFO - 2024-07-08 15:19:21 --> Language Class Initialized
INFO - 2024-07-08 15:19:21 --> Config Class Initialized
INFO - 2024-07-08 15:19:21 --> Loader Class Initialized
INFO - 2024-07-08 15:19:21 --> Helper loaded: url_helper
INFO - 2024-07-08 15:19:21 --> Helper loaded: file_helper
INFO - 2024-07-08 15:19:21 --> Helper loaded: form_helper
INFO - 2024-07-08 15:19:21 --> Helper loaded: my_helper
INFO - 2024-07-08 15:19:21 --> Database Driver Class Initialized
INFO - 2024-07-08 15:19:21 --> Session: Class initialized using 'files' driver.
INFO - 2024-07-08 15:19:21 --> Controller Class Initialized
INFO - 2024-07-08 15:19:23 --> Config Class Initialized
INFO - 2024-07-08 15:19:23 --> Hooks Class Initialized
DEBUG - 2024-07-08 15:19:23 --> UTF-8 Support Enabled
INFO - 2024-07-08 15:19:23 --> Utf8 Class Initialized
INFO - 2024-07-08 15:19:23 --> URI Class Initialized
INFO - 2024-07-08 15:19:23 --> Router Class Initialized
INFO - 2024-07-08 15:19:23 --> Output Class Initialized
INFO - 2024-07-08 15:19:23 --> Security Class Initialized
DEBUG - 2024-07-08 15:19:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-07-08 15:19:23 --> Input Class Initialized
INFO - 2024-07-08 15:19:23 --> Language Class Initialized
INFO - 2024-07-08 15:19:23 --> Language Class Initialized
INFO - 2024-07-08 15:19:23 --> Config Class Initialized
INFO - 2024-07-08 15:19:23 --> Loader Class Initialized
INFO - 2024-07-08 15:19:23 --> Helper loaded: url_helper
INFO - 2024-07-08 15:19:23 --> Helper loaded: file_helper
INFO - 2024-07-08 15:19:23 --> Helper loaded: form_helper
INFO - 2024-07-08 15:19:23 --> Helper loaded: my_helper
INFO - 2024-07-08 15:19:23 --> Database Driver Class Initialized
INFO - 2024-07-08 15:19:23 --> Session: Class initialized using 'files' driver.
INFO - 2024-07-08 15:19:23 --> Controller Class Initialized
INFO - 2024-07-08 15:19:23 --> Config Class Initialized
INFO - 2024-07-08 15:19:23 --> Hooks Class Initialized
DEBUG - 2024-07-08 15:19:23 --> UTF-8 Support Enabled
INFO - 2024-07-08 15:19:23 --> Utf8 Class Initialized
INFO - 2024-07-08 15:19:23 --> URI Class Initialized
INFO - 2024-07-08 15:19:23 --> Router Class Initialized
INFO - 2024-07-08 15:19:23 --> Output Class Initialized
INFO - 2024-07-08 15:19:23 --> Security Class Initialized
DEBUG - 2024-07-08 15:19:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-07-08 15:19:23 --> Input Class Initialized
INFO - 2024-07-08 15:19:23 --> Language Class Initialized
INFO - 2024-07-08 15:19:23 --> Language Class Initialized
INFO - 2024-07-08 15:19:23 --> Config Class Initialized
INFO - 2024-07-08 15:19:23 --> Loader Class Initialized
INFO - 2024-07-08 15:19:23 --> Helper loaded: url_helper
INFO - 2024-07-08 15:19:23 --> Helper loaded: file_helper
INFO - 2024-07-08 15:19:23 --> Helper loaded: form_helper
INFO - 2024-07-08 15:19:23 --> Helper loaded: my_helper
INFO - 2024-07-08 15:19:23 --> Database Driver Class Initialized
INFO - 2024-07-08 15:19:23 --> Session: Class initialized using 'files' driver.
INFO - 2024-07-08 15:19:23 --> Controller Class Initialized
DEBUG - 2024-07-08 15:19:23 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/data_siswa/views/list.php
DEBUG - 2024-07-08 15:19:23 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-07-08 15:19:23 --> Final output sent to browser
DEBUG - 2024-07-08 15:19:23 --> Total execution time: 0.0329
INFO - 2024-07-08 15:19:23 --> Config Class Initialized
INFO - 2024-07-08 15:19:23 --> Hooks Class Initialized
DEBUG - 2024-07-08 15:19:23 --> UTF-8 Support Enabled
INFO - 2024-07-08 15:19:23 --> Utf8 Class Initialized
INFO - 2024-07-08 15:19:23 --> URI Class Initialized
INFO - 2024-07-08 15:19:23 --> Router Class Initialized
INFO - 2024-07-08 15:19:23 --> Output Class Initialized
INFO - 2024-07-08 15:19:23 --> Security Class Initialized
DEBUG - 2024-07-08 15:19:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-07-08 15:19:23 --> Input Class Initialized
INFO - 2024-07-08 15:19:23 --> Language Class Initialized
ERROR - 2024-07-08 15:19:23 --> 404 Page Not Found: /index
INFO - 2024-07-08 15:19:23 --> Config Class Initialized
INFO - 2024-07-08 15:19:23 --> Hooks Class Initialized
DEBUG - 2024-07-08 15:19:23 --> UTF-8 Support Enabled
INFO - 2024-07-08 15:19:23 --> Utf8 Class Initialized
INFO - 2024-07-08 15:19:23 --> URI Class Initialized
INFO - 2024-07-08 15:19:23 --> Router Class Initialized
INFO - 2024-07-08 15:19:23 --> Output Class Initialized
INFO - 2024-07-08 15:19:23 --> Security Class Initialized
DEBUG - 2024-07-08 15:19:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-07-08 15:19:23 --> Input Class Initialized
INFO - 2024-07-08 15:19:23 --> Language Class Initialized
INFO - 2024-07-08 15:19:23 --> Language Class Initialized
INFO - 2024-07-08 15:19:23 --> Config Class Initialized
INFO - 2024-07-08 15:19:23 --> Loader Class Initialized
INFO - 2024-07-08 15:19:23 --> Helper loaded: url_helper
INFO - 2024-07-08 15:19:23 --> Helper loaded: file_helper
INFO - 2024-07-08 15:19:23 --> Helper loaded: form_helper
INFO - 2024-07-08 15:19:23 --> Helper loaded: my_helper
INFO - 2024-07-08 15:19:23 --> Database Driver Class Initialized
INFO - 2024-07-08 15:19:23 --> Session: Class initialized using 'files' driver.
INFO - 2024-07-08 15:19:23 --> Controller Class Initialized
INFO - 2024-07-08 15:19:25 --> Config Class Initialized
INFO - 2024-07-08 15:19:25 --> Hooks Class Initialized
DEBUG - 2024-07-08 15:19:25 --> UTF-8 Support Enabled
INFO - 2024-07-08 15:19:25 --> Utf8 Class Initialized
INFO - 2024-07-08 15:19:25 --> URI Class Initialized
INFO - 2024-07-08 15:19:25 --> Router Class Initialized
INFO - 2024-07-08 15:19:25 --> Output Class Initialized
INFO - 2024-07-08 15:19:25 --> Security Class Initialized
DEBUG - 2024-07-08 15:19:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-07-08 15:19:25 --> Input Class Initialized
INFO - 2024-07-08 15:19:25 --> Language Class Initialized
INFO - 2024-07-08 15:19:25 --> Language Class Initialized
INFO - 2024-07-08 15:19:25 --> Config Class Initialized
INFO - 2024-07-08 15:19:25 --> Loader Class Initialized
INFO - 2024-07-08 15:19:25 --> Helper loaded: url_helper
INFO - 2024-07-08 15:19:25 --> Helper loaded: file_helper
INFO - 2024-07-08 15:19:25 --> Helper loaded: form_helper
INFO - 2024-07-08 15:19:25 --> Helper loaded: my_helper
INFO - 2024-07-08 15:19:25 --> Database Driver Class Initialized
INFO - 2024-07-08 15:19:25 --> Session: Class initialized using 'files' driver.
INFO - 2024-07-08 15:19:25 --> Controller Class Initialized
INFO - 2024-07-08 15:19:27 --> Config Class Initialized
INFO - 2024-07-08 15:19:27 --> Hooks Class Initialized
DEBUG - 2024-07-08 15:19:27 --> UTF-8 Support Enabled
INFO - 2024-07-08 15:19:27 --> Utf8 Class Initialized
INFO - 2024-07-08 15:19:27 --> URI Class Initialized
INFO - 2024-07-08 15:19:27 --> Router Class Initialized
INFO - 2024-07-08 15:19:27 --> Output Class Initialized
INFO - 2024-07-08 15:19:27 --> Security Class Initialized
DEBUG - 2024-07-08 15:19:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-07-08 15:19:27 --> Input Class Initialized
INFO - 2024-07-08 15:19:27 --> Language Class Initialized
INFO - 2024-07-08 15:19:27 --> Language Class Initialized
INFO - 2024-07-08 15:19:27 --> Config Class Initialized
INFO - 2024-07-08 15:19:27 --> Loader Class Initialized
INFO - 2024-07-08 15:19:27 --> Helper loaded: url_helper
INFO - 2024-07-08 15:19:27 --> Helper loaded: file_helper
INFO - 2024-07-08 15:19:27 --> Helper loaded: form_helper
INFO - 2024-07-08 15:19:27 --> Helper loaded: my_helper
INFO - 2024-07-08 15:19:27 --> Database Driver Class Initialized
INFO - 2024-07-08 15:19:27 --> Session: Class initialized using 'files' driver.
INFO - 2024-07-08 15:19:27 --> Controller Class Initialized
INFO - 2024-07-08 15:19:27 --> Config Class Initialized
INFO - 2024-07-08 15:19:27 --> Hooks Class Initialized
DEBUG - 2024-07-08 15:19:27 --> UTF-8 Support Enabled
INFO - 2024-07-08 15:19:27 --> Utf8 Class Initialized
INFO - 2024-07-08 15:19:27 --> URI Class Initialized
INFO - 2024-07-08 15:19:27 --> Router Class Initialized
INFO - 2024-07-08 15:19:27 --> Output Class Initialized
INFO - 2024-07-08 15:19:27 --> Security Class Initialized
DEBUG - 2024-07-08 15:19:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-07-08 15:19:27 --> Input Class Initialized
INFO - 2024-07-08 15:19:27 --> Language Class Initialized
INFO - 2024-07-08 15:19:27 --> Language Class Initialized
INFO - 2024-07-08 15:19:27 --> Config Class Initialized
INFO - 2024-07-08 15:19:27 --> Loader Class Initialized
INFO - 2024-07-08 15:19:27 --> Helper loaded: url_helper
INFO - 2024-07-08 15:19:27 --> Helper loaded: file_helper
INFO - 2024-07-08 15:19:27 --> Helper loaded: form_helper
INFO - 2024-07-08 15:19:27 --> Helper loaded: my_helper
INFO - 2024-07-08 15:19:27 --> Database Driver Class Initialized
INFO - 2024-07-08 15:19:27 --> Session: Class initialized using 'files' driver.
INFO - 2024-07-08 15:19:27 --> Controller Class Initialized
DEBUG - 2024-07-08 15:19:27 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/data_siswa/views/list.php
DEBUG - 2024-07-08 15:19:27 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-07-08 15:19:27 --> Final output sent to browser
DEBUG - 2024-07-08 15:19:27 --> Total execution time: 0.0326
INFO - 2024-07-08 15:19:27 --> Config Class Initialized
INFO - 2024-07-08 15:19:27 --> Hooks Class Initialized
DEBUG - 2024-07-08 15:19:27 --> UTF-8 Support Enabled
INFO - 2024-07-08 15:19:27 --> Utf8 Class Initialized
INFO - 2024-07-08 15:19:27 --> URI Class Initialized
INFO - 2024-07-08 15:19:27 --> Router Class Initialized
INFO - 2024-07-08 15:19:27 --> Output Class Initialized
INFO - 2024-07-08 15:19:27 --> Security Class Initialized
DEBUG - 2024-07-08 15:19:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-07-08 15:19:27 --> Input Class Initialized
INFO - 2024-07-08 15:19:27 --> Language Class Initialized
ERROR - 2024-07-08 15:19:27 --> 404 Page Not Found: /index
INFO - 2024-07-08 15:19:27 --> Config Class Initialized
INFO - 2024-07-08 15:19:27 --> Hooks Class Initialized
DEBUG - 2024-07-08 15:19:27 --> UTF-8 Support Enabled
INFO - 2024-07-08 15:19:27 --> Utf8 Class Initialized
INFO - 2024-07-08 15:19:27 --> URI Class Initialized
INFO - 2024-07-08 15:19:27 --> Router Class Initialized
INFO - 2024-07-08 15:19:27 --> Output Class Initialized
INFO - 2024-07-08 15:19:27 --> Security Class Initialized
DEBUG - 2024-07-08 15:19:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-07-08 15:19:27 --> Input Class Initialized
INFO - 2024-07-08 15:19:27 --> Language Class Initialized
INFO - 2024-07-08 15:19:27 --> Language Class Initialized
INFO - 2024-07-08 15:19:27 --> Config Class Initialized
INFO - 2024-07-08 15:19:27 --> Loader Class Initialized
INFO - 2024-07-08 15:19:27 --> Helper loaded: url_helper
INFO - 2024-07-08 15:19:27 --> Helper loaded: file_helper
INFO - 2024-07-08 15:19:27 --> Helper loaded: form_helper
INFO - 2024-07-08 15:19:27 --> Helper loaded: my_helper
INFO - 2024-07-08 15:19:27 --> Database Driver Class Initialized
INFO - 2024-07-08 15:19:27 --> Session: Class initialized using 'files' driver.
INFO - 2024-07-08 15:19:27 --> Controller Class Initialized
INFO - 2024-07-08 15:19:28 --> Config Class Initialized
INFO - 2024-07-08 15:19:28 --> Hooks Class Initialized
DEBUG - 2024-07-08 15:19:28 --> UTF-8 Support Enabled
INFO - 2024-07-08 15:19:28 --> Utf8 Class Initialized
INFO - 2024-07-08 15:19:28 --> URI Class Initialized
INFO - 2024-07-08 15:19:28 --> Router Class Initialized
INFO - 2024-07-08 15:19:28 --> Output Class Initialized
INFO - 2024-07-08 15:19:28 --> Security Class Initialized
DEBUG - 2024-07-08 15:19:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-07-08 15:19:28 --> Input Class Initialized
INFO - 2024-07-08 15:19:28 --> Language Class Initialized
INFO - 2024-07-08 15:19:28 --> Language Class Initialized
INFO - 2024-07-08 15:19:28 --> Config Class Initialized
INFO - 2024-07-08 15:19:28 --> Loader Class Initialized
INFO - 2024-07-08 15:19:28 --> Helper loaded: url_helper
INFO - 2024-07-08 15:19:28 --> Helper loaded: file_helper
INFO - 2024-07-08 15:19:28 --> Helper loaded: form_helper
INFO - 2024-07-08 15:19:28 --> Helper loaded: my_helper
INFO - 2024-07-08 15:19:28 --> Database Driver Class Initialized
INFO - 2024-07-08 15:19:28 --> Session: Class initialized using 'files' driver.
INFO - 2024-07-08 15:19:28 --> Controller Class Initialized
INFO - 2024-07-08 15:19:32 --> Config Class Initialized
INFO - 2024-07-08 15:19:32 --> Hooks Class Initialized
DEBUG - 2024-07-08 15:19:32 --> UTF-8 Support Enabled
INFO - 2024-07-08 15:19:32 --> Utf8 Class Initialized
INFO - 2024-07-08 15:19:32 --> URI Class Initialized
INFO - 2024-07-08 15:19:32 --> Router Class Initialized
INFO - 2024-07-08 15:19:32 --> Output Class Initialized
INFO - 2024-07-08 15:19:32 --> Security Class Initialized
DEBUG - 2024-07-08 15:19:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-07-08 15:19:32 --> Input Class Initialized
INFO - 2024-07-08 15:19:32 --> Language Class Initialized
INFO - 2024-07-08 15:19:32 --> Language Class Initialized
INFO - 2024-07-08 15:19:32 --> Config Class Initialized
INFO - 2024-07-08 15:19:32 --> Loader Class Initialized
INFO - 2024-07-08 15:19:32 --> Helper loaded: url_helper
INFO - 2024-07-08 15:19:32 --> Helper loaded: file_helper
INFO - 2024-07-08 15:19:32 --> Helper loaded: form_helper
INFO - 2024-07-08 15:19:32 --> Helper loaded: my_helper
INFO - 2024-07-08 15:19:32 --> Database Driver Class Initialized
INFO - 2024-07-08 15:19:32 --> Session: Class initialized using 'files' driver.
INFO - 2024-07-08 15:19:32 --> Controller Class Initialized
INFO - 2024-07-08 15:19:32 --> Config Class Initialized
INFO - 2024-07-08 15:19:32 --> Hooks Class Initialized
DEBUG - 2024-07-08 15:19:32 --> UTF-8 Support Enabled
INFO - 2024-07-08 15:19:32 --> Utf8 Class Initialized
INFO - 2024-07-08 15:19:32 --> URI Class Initialized
INFO - 2024-07-08 15:19:32 --> Router Class Initialized
INFO - 2024-07-08 15:19:32 --> Output Class Initialized
INFO - 2024-07-08 15:19:32 --> Security Class Initialized
DEBUG - 2024-07-08 15:19:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-07-08 15:19:32 --> Input Class Initialized
INFO - 2024-07-08 15:19:32 --> Language Class Initialized
INFO - 2024-07-08 15:19:32 --> Language Class Initialized
INFO - 2024-07-08 15:19:32 --> Config Class Initialized
INFO - 2024-07-08 15:19:32 --> Loader Class Initialized
INFO - 2024-07-08 15:19:32 --> Helper loaded: url_helper
INFO - 2024-07-08 15:19:32 --> Helper loaded: file_helper
INFO - 2024-07-08 15:19:32 --> Helper loaded: form_helper
INFO - 2024-07-08 15:19:32 --> Helper loaded: my_helper
INFO - 2024-07-08 15:19:32 --> Database Driver Class Initialized
INFO - 2024-07-08 15:19:32 --> Session: Class initialized using 'files' driver.
INFO - 2024-07-08 15:19:32 --> Controller Class Initialized
DEBUG - 2024-07-08 15:19:32 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/data_siswa/views/list.php
DEBUG - 2024-07-08 15:19:32 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-07-08 15:19:32 --> Final output sent to browser
DEBUG - 2024-07-08 15:19:32 --> Total execution time: 0.0302
INFO - 2024-07-08 15:19:32 --> Config Class Initialized
INFO - 2024-07-08 15:19:32 --> Hooks Class Initialized
DEBUG - 2024-07-08 15:19:32 --> UTF-8 Support Enabled
INFO - 2024-07-08 15:19:32 --> Utf8 Class Initialized
INFO - 2024-07-08 15:19:32 --> URI Class Initialized
INFO - 2024-07-08 15:19:32 --> Router Class Initialized
INFO - 2024-07-08 15:19:32 --> Output Class Initialized
INFO - 2024-07-08 15:19:32 --> Security Class Initialized
DEBUG - 2024-07-08 15:19:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-07-08 15:19:32 --> Input Class Initialized
INFO - 2024-07-08 15:19:32 --> Language Class Initialized
ERROR - 2024-07-08 15:19:32 --> 404 Page Not Found: /index
INFO - 2024-07-08 15:19:32 --> Config Class Initialized
INFO - 2024-07-08 15:19:32 --> Hooks Class Initialized
DEBUG - 2024-07-08 15:19:32 --> UTF-8 Support Enabled
INFO - 2024-07-08 15:19:32 --> Utf8 Class Initialized
INFO - 2024-07-08 15:19:32 --> URI Class Initialized
INFO - 2024-07-08 15:19:32 --> Router Class Initialized
INFO - 2024-07-08 15:19:32 --> Output Class Initialized
INFO - 2024-07-08 15:19:32 --> Security Class Initialized
DEBUG - 2024-07-08 15:19:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-07-08 15:19:32 --> Input Class Initialized
INFO - 2024-07-08 15:19:32 --> Language Class Initialized
INFO - 2024-07-08 15:19:32 --> Language Class Initialized
INFO - 2024-07-08 15:19:32 --> Config Class Initialized
INFO - 2024-07-08 15:19:32 --> Loader Class Initialized
INFO - 2024-07-08 15:19:32 --> Helper loaded: url_helper
INFO - 2024-07-08 15:19:32 --> Helper loaded: file_helper
INFO - 2024-07-08 15:19:32 --> Helper loaded: form_helper
INFO - 2024-07-08 15:19:32 --> Helper loaded: my_helper
INFO - 2024-07-08 15:19:32 --> Database Driver Class Initialized
INFO - 2024-07-08 15:19:32 --> Session: Class initialized using 'files' driver.
INFO - 2024-07-08 15:19:32 --> Controller Class Initialized
INFO - 2024-07-08 15:19:33 --> Config Class Initialized
INFO - 2024-07-08 15:19:33 --> Hooks Class Initialized
DEBUG - 2024-07-08 15:19:33 --> UTF-8 Support Enabled
INFO - 2024-07-08 15:19:33 --> Utf8 Class Initialized
INFO - 2024-07-08 15:19:33 --> URI Class Initialized
INFO - 2024-07-08 15:19:33 --> Router Class Initialized
INFO - 2024-07-08 15:19:33 --> Output Class Initialized
INFO - 2024-07-08 15:19:33 --> Security Class Initialized
DEBUG - 2024-07-08 15:19:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-07-08 15:19:33 --> Input Class Initialized
INFO - 2024-07-08 15:19:33 --> Language Class Initialized
INFO - 2024-07-08 15:19:33 --> Language Class Initialized
INFO - 2024-07-08 15:19:33 --> Config Class Initialized
INFO - 2024-07-08 15:19:33 --> Loader Class Initialized
INFO - 2024-07-08 15:19:33 --> Helper loaded: url_helper
INFO - 2024-07-08 15:19:33 --> Helper loaded: file_helper
INFO - 2024-07-08 15:19:33 --> Helper loaded: form_helper
INFO - 2024-07-08 15:19:33 --> Helper loaded: my_helper
INFO - 2024-07-08 15:19:33 --> Database Driver Class Initialized
INFO - 2024-07-08 15:19:33 --> Session: Class initialized using 'files' driver.
INFO - 2024-07-08 15:19:33 --> Controller Class Initialized
INFO - 2024-07-08 15:19:35 --> Config Class Initialized
INFO - 2024-07-08 15:19:35 --> Hooks Class Initialized
DEBUG - 2024-07-08 15:19:35 --> UTF-8 Support Enabled
INFO - 2024-07-08 15:19:35 --> Utf8 Class Initialized
INFO - 2024-07-08 15:19:35 --> URI Class Initialized
INFO - 2024-07-08 15:19:35 --> Router Class Initialized
INFO - 2024-07-08 15:19:35 --> Output Class Initialized
INFO - 2024-07-08 15:19:35 --> Security Class Initialized
DEBUG - 2024-07-08 15:19:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-07-08 15:19:35 --> Input Class Initialized
INFO - 2024-07-08 15:19:35 --> Language Class Initialized
INFO - 2024-07-08 15:19:35 --> Language Class Initialized
INFO - 2024-07-08 15:19:35 --> Config Class Initialized
INFO - 2024-07-08 15:19:35 --> Loader Class Initialized
INFO - 2024-07-08 15:19:35 --> Helper loaded: url_helper
INFO - 2024-07-08 15:19:35 --> Helper loaded: file_helper
INFO - 2024-07-08 15:19:35 --> Helper loaded: form_helper
INFO - 2024-07-08 15:19:35 --> Helper loaded: my_helper
INFO - 2024-07-08 15:19:35 --> Database Driver Class Initialized
INFO - 2024-07-08 15:19:35 --> Session: Class initialized using 'files' driver.
INFO - 2024-07-08 15:19:35 --> Controller Class Initialized
INFO - 2024-07-08 15:19:35 --> Config Class Initialized
INFO - 2024-07-08 15:19:35 --> Hooks Class Initialized
DEBUG - 2024-07-08 15:19:35 --> UTF-8 Support Enabled
INFO - 2024-07-08 15:19:35 --> Utf8 Class Initialized
INFO - 2024-07-08 15:19:35 --> URI Class Initialized
INFO - 2024-07-08 15:19:35 --> Router Class Initialized
INFO - 2024-07-08 15:19:35 --> Output Class Initialized
INFO - 2024-07-08 15:19:35 --> Security Class Initialized
DEBUG - 2024-07-08 15:19:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-07-08 15:19:35 --> Input Class Initialized
INFO - 2024-07-08 15:19:35 --> Language Class Initialized
INFO - 2024-07-08 15:19:35 --> Language Class Initialized
INFO - 2024-07-08 15:19:35 --> Config Class Initialized
INFO - 2024-07-08 15:19:35 --> Loader Class Initialized
INFO - 2024-07-08 15:19:35 --> Helper loaded: url_helper
INFO - 2024-07-08 15:19:35 --> Helper loaded: file_helper
INFO - 2024-07-08 15:19:35 --> Helper loaded: form_helper
INFO - 2024-07-08 15:19:35 --> Helper loaded: my_helper
INFO - 2024-07-08 15:19:35 --> Database Driver Class Initialized
INFO - 2024-07-08 15:19:35 --> Session: Class initialized using 'files' driver.
INFO - 2024-07-08 15:19:35 --> Controller Class Initialized
DEBUG - 2024-07-08 15:19:35 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/data_siswa/views/list.php
DEBUG - 2024-07-08 15:19:35 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-07-08 15:19:35 --> Final output sent to browser
DEBUG - 2024-07-08 15:19:35 --> Total execution time: 0.0368
INFO - 2024-07-08 15:19:35 --> Config Class Initialized
INFO - 2024-07-08 15:19:35 --> Hooks Class Initialized
DEBUG - 2024-07-08 15:19:35 --> UTF-8 Support Enabled
INFO - 2024-07-08 15:19:35 --> Utf8 Class Initialized
INFO - 2024-07-08 15:19:35 --> URI Class Initialized
INFO - 2024-07-08 15:19:35 --> Router Class Initialized
INFO - 2024-07-08 15:19:35 --> Output Class Initialized
INFO - 2024-07-08 15:19:35 --> Security Class Initialized
DEBUG - 2024-07-08 15:19:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-07-08 15:19:35 --> Input Class Initialized
INFO - 2024-07-08 15:19:35 --> Language Class Initialized
ERROR - 2024-07-08 15:19:35 --> 404 Page Not Found: /index
INFO - 2024-07-08 15:19:35 --> Config Class Initialized
INFO - 2024-07-08 15:19:35 --> Hooks Class Initialized
DEBUG - 2024-07-08 15:19:35 --> UTF-8 Support Enabled
INFO - 2024-07-08 15:19:35 --> Utf8 Class Initialized
INFO - 2024-07-08 15:19:35 --> URI Class Initialized
INFO - 2024-07-08 15:19:35 --> Router Class Initialized
INFO - 2024-07-08 15:19:35 --> Output Class Initialized
INFO - 2024-07-08 15:19:35 --> Security Class Initialized
DEBUG - 2024-07-08 15:19:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-07-08 15:19:35 --> Input Class Initialized
INFO - 2024-07-08 15:19:35 --> Language Class Initialized
INFO - 2024-07-08 15:19:35 --> Language Class Initialized
INFO - 2024-07-08 15:19:35 --> Config Class Initialized
INFO - 2024-07-08 15:19:35 --> Loader Class Initialized
INFO - 2024-07-08 15:19:35 --> Helper loaded: url_helper
INFO - 2024-07-08 15:19:35 --> Helper loaded: file_helper
INFO - 2024-07-08 15:19:35 --> Helper loaded: form_helper
INFO - 2024-07-08 15:19:35 --> Helper loaded: my_helper
INFO - 2024-07-08 15:19:35 --> Database Driver Class Initialized
INFO - 2024-07-08 15:19:35 --> Session: Class initialized using 'files' driver.
INFO - 2024-07-08 15:19:35 --> Controller Class Initialized
INFO - 2024-07-08 15:19:37 --> Config Class Initialized
INFO - 2024-07-08 15:19:37 --> Hooks Class Initialized
DEBUG - 2024-07-08 15:19:37 --> UTF-8 Support Enabled
INFO - 2024-07-08 15:19:37 --> Utf8 Class Initialized
INFO - 2024-07-08 15:19:37 --> URI Class Initialized
INFO - 2024-07-08 15:19:37 --> Router Class Initialized
INFO - 2024-07-08 15:19:37 --> Output Class Initialized
INFO - 2024-07-08 15:19:37 --> Security Class Initialized
DEBUG - 2024-07-08 15:19:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-07-08 15:19:37 --> Input Class Initialized
INFO - 2024-07-08 15:19:37 --> Language Class Initialized
INFO - 2024-07-08 15:19:37 --> Language Class Initialized
INFO - 2024-07-08 15:19:37 --> Config Class Initialized
INFO - 2024-07-08 15:19:37 --> Loader Class Initialized
INFO - 2024-07-08 15:19:37 --> Helper loaded: url_helper
INFO - 2024-07-08 15:19:37 --> Helper loaded: file_helper
INFO - 2024-07-08 15:19:37 --> Helper loaded: form_helper
INFO - 2024-07-08 15:19:37 --> Helper loaded: my_helper
INFO - 2024-07-08 15:19:37 --> Database Driver Class Initialized
INFO - 2024-07-08 15:19:37 --> Session: Class initialized using 'files' driver.
INFO - 2024-07-08 15:19:37 --> Controller Class Initialized
INFO - 2024-07-08 15:19:39 --> Config Class Initialized
INFO - 2024-07-08 15:19:39 --> Hooks Class Initialized
DEBUG - 2024-07-08 15:19:39 --> UTF-8 Support Enabled
INFO - 2024-07-08 15:19:39 --> Utf8 Class Initialized
INFO - 2024-07-08 15:19:39 --> URI Class Initialized
INFO - 2024-07-08 15:19:39 --> Router Class Initialized
INFO - 2024-07-08 15:19:39 --> Output Class Initialized
INFO - 2024-07-08 15:19:39 --> Security Class Initialized
DEBUG - 2024-07-08 15:19:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-07-08 15:19:39 --> Input Class Initialized
INFO - 2024-07-08 15:19:39 --> Language Class Initialized
INFO - 2024-07-08 15:19:39 --> Language Class Initialized
INFO - 2024-07-08 15:19:39 --> Config Class Initialized
INFO - 2024-07-08 15:19:39 --> Loader Class Initialized
INFO - 2024-07-08 15:19:39 --> Helper loaded: url_helper
INFO - 2024-07-08 15:19:39 --> Helper loaded: file_helper
INFO - 2024-07-08 15:19:39 --> Helper loaded: form_helper
INFO - 2024-07-08 15:19:39 --> Helper loaded: my_helper
INFO - 2024-07-08 15:19:39 --> Database Driver Class Initialized
INFO - 2024-07-08 15:19:39 --> Session: Class initialized using 'files' driver.
INFO - 2024-07-08 15:19:39 --> Controller Class Initialized
INFO - 2024-07-08 15:19:39 --> Config Class Initialized
INFO - 2024-07-08 15:19:39 --> Hooks Class Initialized
DEBUG - 2024-07-08 15:19:39 --> UTF-8 Support Enabled
INFO - 2024-07-08 15:19:39 --> Utf8 Class Initialized
INFO - 2024-07-08 15:19:39 --> URI Class Initialized
INFO - 2024-07-08 15:19:39 --> Router Class Initialized
INFO - 2024-07-08 15:19:39 --> Output Class Initialized
INFO - 2024-07-08 15:19:39 --> Security Class Initialized
DEBUG - 2024-07-08 15:19:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-07-08 15:19:39 --> Input Class Initialized
INFO - 2024-07-08 15:19:39 --> Language Class Initialized
INFO - 2024-07-08 15:19:39 --> Language Class Initialized
INFO - 2024-07-08 15:19:39 --> Config Class Initialized
INFO - 2024-07-08 15:19:39 --> Loader Class Initialized
INFO - 2024-07-08 15:19:39 --> Helper loaded: url_helper
INFO - 2024-07-08 15:19:39 --> Helper loaded: file_helper
INFO - 2024-07-08 15:19:39 --> Helper loaded: form_helper
INFO - 2024-07-08 15:19:39 --> Helper loaded: my_helper
INFO - 2024-07-08 15:19:39 --> Database Driver Class Initialized
INFO - 2024-07-08 15:19:39 --> Session: Class initialized using 'files' driver.
INFO - 2024-07-08 15:19:39 --> Controller Class Initialized
DEBUG - 2024-07-08 15:19:39 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/data_siswa/views/list.php
DEBUG - 2024-07-08 15:19:39 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-07-08 15:19:39 --> Final output sent to browser
DEBUG - 2024-07-08 15:19:39 --> Total execution time: 0.0291
INFO - 2024-07-08 15:19:39 --> Config Class Initialized
INFO - 2024-07-08 15:19:39 --> Hooks Class Initialized
DEBUG - 2024-07-08 15:19:39 --> UTF-8 Support Enabled
INFO - 2024-07-08 15:19:39 --> Utf8 Class Initialized
INFO - 2024-07-08 15:19:39 --> URI Class Initialized
INFO - 2024-07-08 15:19:39 --> Router Class Initialized
INFO - 2024-07-08 15:19:39 --> Output Class Initialized
INFO - 2024-07-08 15:19:39 --> Security Class Initialized
DEBUG - 2024-07-08 15:19:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-07-08 15:19:39 --> Input Class Initialized
INFO - 2024-07-08 15:19:39 --> Language Class Initialized
ERROR - 2024-07-08 15:19:39 --> 404 Page Not Found: /index
INFO - 2024-07-08 15:19:39 --> Config Class Initialized
INFO - 2024-07-08 15:19:39 --> Hooks Class Initialized
DEBUG - 2024-07-08 15:19:39 --> UTF-8 Support Enabled
INFO - 2024-07-08 15:19:39 --> Utf8 Class Initialized
INFO - 2024-07-08 15:19:39 --> URI Class Initialized
INFO - 2024-07-08 15:19:39 --> Router Class Initialized
INFO - 2024-07-08 15:19:39 --> Output Class Initialized
INFO - 2024-07-08 15:19:39 --> Security Class Initialized
DEBUG - 2024-07-08 15:19:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-07-08 15:19:39 --> Input Class Initialized
INFO - 2024-07-08 15:19:39 --> Language Class Initialized
INFO - 2024-07-08 15:19:39 --> Language Class Initialized
INFO - 2024-07-08 15:19:39 --> Config Class Initialized
INFO - 2024-07-08 15:19:39 --> Loader Class Initialized
INFO - 2024-07-08 15:19:39 --> Helper loaded: url_helper
INFO - 2024-07-08 15:19:39 --> Helper loaded: file_helper
INFO - 2024-07-08 15:19:39 --> Helper loaded: form_helper
INFO - 2024-07-08 15:19:39 --> Helper loaded: my_helper
INFO - 2024-07-08 15:19:39 --> Database Driver Class Initialized
INFO - 2024-07-08 15:19:39 --> Session: Class initialized using 'files' driver.
INFO - 2024-07-08 15:19:39 --> Controller Class Initialized
INFO - 2024-07-08 15:19:40 --> Config Class Initialized
INFO - 2024-07-08 15:19:40 --> Hooks Class Initialized
DEBUG - 2024-07-08 15:19:40 --> UTF-8 Support Enabled
INFO - 2024-07-08 15:19:40 --> Utf8 Class Initialized
INFO - 2024-07-08 15:19:40 --> URI Class Initialized
INFO - 2024-07-08 15:19:40 --> Router Class Initialized
INFO - 2024-07-08 15:19:40 --> Output Class Initialized
INFO - 2024-07-08 15:19:40 --> Security Class Initialized
DEBUG - 2024-07-08 15:19:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-07-08 15:19:40 --> Input Class Initialized
INFO - 2024-07-08 15:19:40 --> Language Class Initialized
INFO - 2024-07-08 15:19:40 --> Language Class Initialized
INFO - 2024-07-08 15:19:40 --> Config Class Initialized
INFO - 2024-07-08 15:19:40 --> Loader Class Initialized
INFO - 2024-07-08 15:19:40 --> Helper loaded: url_helper
INFO - 2024-07-08 15:19:40 --> Helper loaded: file_helper
INFO - 2024-07-08 15:19:40 --> Helper loaded: form_helper
INFO - 2024-07-08 15:19:40 --> Helper loaded: my_helper
INFO - 2024-07-08 15:19:40 --> Database Driver Class Initialized
INFO - 2024-07-08 15:19:40 --> Session: Class initialized using 'files' driver.
INFO - 2024-07-08 15:19:40 --> Controller Class Initialized
INFO - 2024-07-08 15:19:42 --> Config Class Initialized
INFO - 2024-07-08 15:19:42 --> Hooks Class Initialized
DEBUG - 2024-07-08 15:19:42 --> UTF-8 Support Enabled
INFO - 2024-07-08 15:19:42 --> Utf8 Class Initialized
INFO - 2024-07-08 15:19:42 --> URI Class Initialized
INFO - 2024-07-08 15:19:42 --> Router Class Initialized
INFO - 2024-07-08 15:19:42 --> Output Class Initialized
INFO - 2024-07-08 15:19:42 --> Security Class Initialized
DEBUG - 2024-07-08 15:19:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-07-08 15:19:42 --> Input Class Initialized
INFO - 2024-07-08 15:19:42 --> Language Class Initialized
INFO - 2024-07-08 15:19:42 --> Language Class Initialized
INFO - 2024-07-08 15:19:42 --> Config Class Initialized
INFO - 2024-07-08 15:19:42 --> Loader Class Initialized
INFO - 2024-07-08 15:19:42 --> Helper loaded: url_helper
INFO - 2024-07-08 15:19:42 --> Helper loaded: file_helper
INFO - 2024-07-08 15:19:42 --> Helper loaded: form_helper
INFO - 2024-07-08 15:19:42 --> Helper loaded: my_helper
INFO - 2024-07-08 15:19:42 --> Database Driver Class Initialized
INFO - 2024-07-08 15:19:42 --> Session: Class initialized using 'files' driver.
INFO - 2024-07-08 15:19:42 --> Controller Class Initialized
INFO - 2024-07-08 15:19:42 --> Config Class Initialized
INFO - 2024-07-08 15:19:42 --> Hooks Class Initialized
DEBUG - 2024-07-08 15:19:42 --> UTF-8 Support Enabled
INFO - 2024-07-08 15:19:42 --> Utf8 Class Initialized
INFO - 2024-07-08 15:19:42 --> URI Class Initialized
INFO - 2024-07-08 15:19:42 --> Router Class Initialized
INFO - 2024-07-08 15:19:42 --> Output Class Initialized
INFO - 2024-07-08 15:19:42 --> Security Class Initialized
DEBUG - 2024-07-08 15:19:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-07-08 15:19:42 --> Input Class Initialized
INFO - 2024-07-08 15:19:42 --> Language Class Initialized
INFO - 2024-07-08 15:19:42 --> Language Class Initialized
INFO - 2024-07-08 15:19:42 --> Config Class Initialized
INFO - 2024-07-08 15:19:42 --> Loader Class Initialized
INFO - 2024-07-08 15:19:42 --> Helper loaded: url_helper
INFO - 2024-07-08 15:19:42 --> Helper loaded: file_helper
INFO - 2024-07-08 15:19:42 --> Helper loaded: form_helper
INFO - 2024-07-08 15:19:42 --> Helper loaded: my_helper
INFO - 2024-07-08 15:19:42 --> Database Driver Class Initialized
INFO - 2024-07-08 15:19:42 --> Session: Class initialized using 'files' driver.
INFO - 2024-07-08 15:19:42 --> Controller Class Initialized
DEBUG - 2024-07-08 15:19:42 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/data_siswa/views/list.php
DEBUG - 2024-07-08 15:19:42 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-07-08 15:19:42 --> Final output sent to browser
DEBUG - 2024-07-08 15:19:42 --> Total execution time: 0.0540
INFO - 2024-07-08 15:19:42 --> Config Class Initialized
INFO - 2024-07-08 15:19:42 --> Hooks Class Initialized
DEBUG - 2024-07-08 15:19:42 --> UTF-8 Support Enabled
INFO - 2024-07-08 15:19:42 --> Utf8 Class Initialized
INFO - 2024-07-08 15:19:42 --> URI Class Initialized
INFO - 2024-07-08 15:19:42 --> Router Class Initialized
INFO - 2024-07-08 15:19:42 --> Output Class Initialized
INFO - 2024-07-08 15:19:42 --> Security Class Initialized
DEBUG - 2024-07-08 15:19:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-07-08 15:19:42 --> Input Class Initialized
INFO - 2024-07-08 15:19:42 --> Language Class Initialized
ERROR - 2024-07-08 15:19:42 --> 404 Page Not Found: /index
INFO - 2024-07-08 15:19:42 --> Config Class Initialized
INFO - 2024-07-08 15:19:42 --> Hooks Class Initialized
DEBUG - 2024-07-08 15:19:42 --> UTF-8 Support Enabled
INFO - 2024-07-08 15:19:42 --> Utf8 Class Initialized
INFO - 2024-07-08 15:19:42 --> URI Class Initialized
INFO - 2024-07-08 15:19:42 --> Router Class Initialized
INFO - 2024-07-08 15:19:42 --> Output Class Initialized
INFO - 2024-07-08 15:19:42 --> Security Class Initialized
DEBUG - 2024-07-08 15:19:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-07-08 15:19:42 --> Input Class Initialized
INFO - 2024-07-08 15:19:42 --> Language Class Initialized
INFO - 2024-07-08 15:19:42 --> Language Class Initialized
INFO - 2024-07-08 15:19:42 --> Config Class Initialized
INFO - 2024-07-08 15:19:42 --> Loader Class Initialized
INFO - 2024-07-08 15:19:42 --> Helper loaded: url_helper
INFO - 2024-07-08 15:19:42 --> Helper loaded: file_helper
INFO - 2024-07-08 15:19:42 --> Helper loaded: form_helper
INFO - 2024-07-08 15:19:42 --> Helper loaded: my_helper
INFO - 2024-07-08 15:19:42 --> Database Driver Class Initialized
INFO - 2024-07-08 15:19:42 --> Session: Class initialized using 'files' driver.
INFO - 2024-07-08 15:19:42 --> Controller Class Initialized
INFO - 2024-07-08 15:19:43 --> Config Class Initialized
INFO - 2024-07-08 15:19:43 --> Hooks Class Initialized
DEBUG - 2024-07-08 15:19:43 --> UTF-8 Support Enabled
INFO - 2024-07-08 15:19:43 --> Utf8 Class Initialized
INFO - 2024-07-08 15:19:43 --> URI Class Initialized
INFO - 2024-07-08 15:19:43 --> Router Class Initialized
INFO - 2024-07-08 15:19:43 --> Output Class Initialized
INFO - 2024-07-08 15:19:43 --> Security Class Initialized
DEBUG - 2024-07-08 15:19:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-07-08 15:19:43 --> Input Class Initialized
INFO - 2024-07-08 15:19:43 --> Language Class Initialized
INFO - 2024-07-08 15:19:43 --> Language Class Initialized
INFO - 2024-07-08 15:19:43 --> Config Class Initialized
INFO - 2024-07-08 15:19:43 --> Loader Class Initialized
INFO - 2024-07-08 15:19:43 --> Helper loaded: url_helper
INFO - 2024-07-08 15:19:43 --> Helper loaded: file_helper
INFO - 2024-07-08 15:19:43 --> Helper loaded: form_helper
INFO - 2024-07-08 15:19:43 --> Helper loaded: my_helper
INFO - 2024-07-08 15:19:43 --> Database Driver Class Initialized
INFO - 2024-07-08 15:19:43 --> Session: Class initialized using 'files' driver.
INFO - 2024-07-08 15:19:43 --> Controller Class Initialized
INFO - 2024-07-08 15:19:45 --> Config Class Initialized
INFO - 2024-07-08 15:19:45 --> Hooks Class Initialized
DEBUG - 2024-07-08 15:19:45 --> UTF-8 Support Enabled
INFO - 2024-07-08 15:19:45 --> Utf8 Class Initialized
INFO - 2024-07-08 15:19:45 --> URI Class Initialized
INFO - 2024-07-08 15:19:45 --> Router Class Initialized
INFO - 2024-07-08 15:19:45 --> Output Class Initialized
INFO - 2024-07-08 15:19:45 --> Security Class Initialized
DEBUG - 2024-07-08 15:19:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-07-08 15:19:45 --> Input Class Initialized
INFO - 2024-07-08 15:19:45 --> Language Class Initialized
INFO - 2024-07-08 15:19:45 --> Language Class Initialized
INFO - 2024-07-08 15:19:45 --> Config Class Initialized
INFO - 2024-07-08 15:19:45 --> Loader Class Initialized
INFO - 2024-07-08 15:19:45 --> Helper loaded: url_helper
INFO - 2024-07-08 15:19:45 --> Helper loaded: file_helper
INFO - 2024-07-08 15:19:45 --> Helper loaded: form_helper
INFO - 2024-07-08 15:19:45 --> Helper loaded: my_helper
INFO - 2024-07-08 15:19:45 --> Database Driver Class Initialized
INFO - 2024-07-08 15:19:45 --> Session: Class initialized using 'files' driver.
INFO - 2024-07-08 15:19:45 --> Controller Class Initialized
INFO - 2024-07-08 15:19:45 --> Config Class Initialized
INFO - 2024-07-08 15:19:45 --> Hooks Class Initialized
DEBUG - 2024-07-08 15:19:45 --> UTF-8 Support Enabled
INFO - 2024-07-08 15:19:45 --> Utf8 Class Initialized
INFO - 2024-07-08 15:19:45 --> URI Class Initialized
INFO - 2024-07-08 15:19:45 --> Router Class Initialized
INFO - 2024-07-08 15:19:45 --> Output Class Initialized
INFO - 2024-07-08 15:19:45 --> Security Class Initialized
DEBUG - 2024-07-08 15:19:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-07-08 15:19:45 --> Input Class Initialized
INFO - 2024-07-08 15:19:45 --> Language Class Initialized
INFO - 2024-07-08 15:19:45 --> Language Class Initialized
INFO - 2024-07-08 15:19:45 --> Config Class Initialized
INFO - 2024-07-08 15:19:45 --> Loader Class Initialized
INFO - 2024-07-08 15:19:45 --> Helper loaded: url_helper
INFO - 2024-07-08 15:19:45 --> Helper loaded: file_helper
INFO - 2024-07-08 15:19:45 --> Helper loaded: form_helper
INFO - 2024-07-08 15:19:45 --> Helper loaded: my_helper
INFO - 2024-07-08 15:19:46 --> Database Driver Class Initialized
INFO - 2024-07-08 15:19:46 --> Session: Class initialized using 'files' driver.
INFO - 2024-07-08 15:19:46 --> Controller Class Initialized
DEBUG - 2024-07-08 15:19:46 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/data_siswa/views/list.php
DEBUG - 2024-07-08 15:19:46 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-07-08 15:19:46 --> Final output sent to browser
DEBUG - 2024-07-08 15:19:46 --> Total execution time: 0.0500
INFO - 2024-07-08 15:19:46 --> Config Class Initialized
INFO - 2024-07-08 15:19:46 --> Hooks Class Initialized
DEBUG - 2024-07-08 15:19:46 --> UTF-8 Support Enabled
INFO - 2024-07-08 15:19:46 --> Utf8 Class Initialized
INFO - 2024-07-08 15:19:46 --> URI Class Initialized
INFO - 2024-07-08 15:19:46 --> Router Class Initialized
INFO - 2024-07-08 15:19:46 --> Output Class Initialized
INFO - 2024-07-08 15:19:46 --> Security Class Initialized
DEBUG - 2024-07-08 15:19:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-07-08 15:19:46 --> Input Class Initialized
INFO - 2024-07-08 15:19:46 --> Language Class Initialized
ERROR - 2024-07-08 15:19:46 --> 404 Page Not Found: /index
INFO - 2024-07-08 15:19:46 --> Config Class Initialized
INFO - 2024-07-08 15:19:46 --> Hooks Class Initialized
DEBUG - 2024-07-08 15:19:46 --> UTF-8 Support Enabled
INFO - 2024-07-08 15:19:46 --> Utf8 Class Initialized
INFO - 2024-07-08 15:19:46 --> URI Class Initialized
INFO - 2024-07-08 15:19:46 --> Router Class Initialized
INFO - 2024-07-08 15:19:46 --> Output Class Initialized
INFO - 2024-07-08 15:19:46 --> Security Class Initialized
DEBUG - 2024-07-08 15:19:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-07-08 15:19:46 --> Input Class Initialized
INFO - 2024-07-08 15:19:46 --> Language Class Initialized
INFO - 2024-07-08 15:19:46 --> Language Class Initialized
INFO - 2024-07-08 15:19:46 --> Config Class Initialized
INFO - 2024-07-08 15:19:46 --> Loader Class Initialized
INFO - 2024-07-08 15:19:46 --> Helper loaded: url_helper
INFO - 2024-07-08 15:19:46 --> Helper loaded: file_helper
INFO - 2024-07-08 15:19:46 --> Helper loaded: form_helper
INFO - 2024-07-08 15:19:46 --> Helper loaded: my_helper
INFO - 2024-07-08 15:19:46 --> Database Driver Class Initialized
INFO - 2024-07-08 15:19:46 --> Session: Class initialized using 'files' driver.
INFO - 2024-07-08 15:19:46 --> Controller Class Initialized
INFO - 2024-07-08 15:19:46 --> Config Class Initialized
INFO - 2024-07-08 15:19:46 --> Hooks Class Initialized
DEBUG - 2024-07-08 15:19:46 --> UTF-8 Support Enabled
INFO - 2024-07-08 15:19:46 --> Utf8 Class Initialized
INFO - 2024-07-08 15:19:46 --> URI Class Initialized
INFO - 2024-07-08 15:19:46 --> Router Class Initialized
INFO - 2024-07-08 15:19:46 --> Output Class Initialized
INFO - 2024-07-08 15:19:46 --> Security Class Initialized
DEBUG - 2024-07-08 15:19:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-07-08 15:19:46 --> Input Class Initialized
INFO - 2024-07-08 15:19:46 --> Language Class Initialized
INFO - 2024-07-08 15:19:46 --> Language Class Initialized
INFO - 2024-07-08 15:19:46 --> Config Class Initialized
INFO - 2024-07-08 15:19:46 --> Loader Class Initialized
INFO - 2024-07-08 15:19:46 --> Helper loaded: url_helper
INFO - 2024-07-08 15:19:46 --> Helper loaded: file_helper
INFO - 2024-07-08 15:19:46 --> Helper loaded: form_helper
INFO - 2024-07-08 15:19:46 --> Helper loaded: my_helper
INFO - 2024-07-08 15:19:46 --> Database Driver Class Initialized
INFO - 2024-07-08 15:19:47 --> Session: Class initialized using 'files' driver.
INFO - 2024-07-08 15:19:47 --> Controller Class Initialized
INFO - 2024-07-08 15:19:49 --> Config Class Initialized
INFO - 2024-07-08 15:19:49 --> Hooks Class Initialized
DEBUG - 2024-07-08 15:19:49 --> UTF-8 Support Enabled
INFO - 2024-07-08 15:19:49 --> Utf8 Class Initialized
INFO - 2024-07-08 15:19:49 --> URI Class Initialized
INFO - 2024-07-08 15:19:49 --> Router Class Initialized
INFO - 2024-07-08 15:19:49 --> Output Class Initialized
INFO - 2024-07-08 15:19:49 --> Security Class Initialized
DEBUG - 2024-07-08 15:19:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-07-08 15:19:49 --> Input Class Initialized
INFO - 2024-07-08 15:19:49 --> Language Class Initialized
INFO - 2024-07-08 15:19:49 --> Language Class Initialized
INFO - 2024-07-08 15:19:49 --> Config Class Initialized
INFO - 2024-07-08 15:19:49 --> Loader Class Initialized
INFO - 2024-07-08 15:19:49 --> Helper loaded: url_helper
INFO - 2024-07-08 15:19:49 --> Helper loaded: file_helper
INFO - 2024-07-08 15:19:49 --> Helper loaded: form_helper
INFO - 2024-07-08 15:19:49 --> Helper loaded: my_helper
INFO - 2024-07-08 15:19:49 --> Database Driver Class Initialized
INFO - 2024-07-08 15:19:49 --> Session: Class initialized using 'files' driver.
INFO - 2024-07-08 15:19:49 --> Controller Class Initialized
INFO - 2024-07-08 15:19:49 --> Config Class Initialized
INFO - 2024-07-08 15:19:49 --> Hooks Class Initialized
DEBUG - 2024-07-08 15:19:49 --> UTF-8 Support Enabled
INFO - 2024-07-08 15:19:49 --> Utf8 Class Initialized
INFO - 2024-07-08 15:19:49 --> URI Class Initialized
INFO - 2024-07-08 15:19:49 --> Router Class Initialized
INFO - 2024-07-08 15:19:49 --> Output Class Initialized
INFO - 2024-07-08 15:19:49 --> Security Class Initialized
DEBUG - 2024-07-08 15:19:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-07-08 15:19:49 --> Input Class Initialized
INFO - 2024-07-08 15:19:49 --> Language Class Initialized
INFO - 2024-07-08 15:19:49 --> Language Class Initialized
INFO - 2024-07-08 15:19:49 --> Config Class Initialized
INFO - 2024-07-08 15:19:49 --> Loader Class Initialized
INFO - 2024-07-08 15:19:49 --> Helper loaded: url_helper
INFO - 2024-07-08 15:19:49 --> Helper loaded: file_helper
INFO - 2024-07-08 15:19:49 --> Helper loaded: form_helper
INFO - 2024-07-08 15:19:49 --> Helper loaded: my_helper
INFO - 2024-07-08 15:19:49 --> Database Driver Class Initialized
INFO - 2024-07-08 15:19:49 --> Session: Class initialized using 'files' driver.
INFO - 2024-07-08 15:19:49 --> Controller Class Initialized
DEBUG - 2024-07-08 15:19:49 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/data_siswa/views/list.php
DEBUG - 2024-07-08 15:19:49 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-07-08 15:19:49 --> Final output sent to browser
DEBUG - 2024-07-08 15:19:49 --> Total execution time: 0.0302
INFO - 2024-07-08 15:19:49 --> Config Class Initialized
INFO - 2024-07-08 15:19:49 --> Hooks Class Initialized
DEBUG - 2024-07-08 15:19:49 --> UTF-8 Support Enabled
INFO - 2024-07-08 15:19:49 --> Utf8 Class Initialized
INFO - 2024-07-08 15:19:49 --> URI Class Initialized
INFO - 2024-07-08 15:19:49 --> Router Class Initialized
INFO - 2024-07-08 15:19:49 --> Output Class Initialized
INFO - 2024-07-08 15:19:49 --> Security Class Initialized
DEBUG - 2024-07-08 15:19:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-07-08 15:19:49 --> Input Class Initialized
INFO - 2024-07-08 15:19:49 --> Language Class Initialized
ERROR - 2024-07-08 15:19:49 --> 404 Page Not Found: /index
INFO - 2024-07-08 15:19:49 --> Config Class Initialized
INFO - 2024-07-08 15:19:49 --> Hooks Class Initialized
DEBUG - 2024-07-08 15:19:49 --> UTF-8 Support Enabled
INFO - 2024-07-08 15:19:49 --> Utf8 Class Initialized
INFO - 2024-07-08 15:19:49 --> URI Class Initialized
INFO - 2024-07-08 15:19:49 --> Router Class Initialized
INFO - 2024-07-08 15:19:49 --> Output Class Initialized
INFO - 2024-07-08 15:19:49 --> Security Class Initialized
DEBUG - 2024-07-08 15:19:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-07-08 15:19:49 --> Input Class Initialized
INFO - 2024-07-08 15:19:49 --> Language Class Initialized
INFO - 2024-07-08 15:19:49 --> Language Class Initialized
INFO - 2024-07-08 15:19:49 --> Config Class Initialized
INFO - 2024-07-08 15:19:49 --> Loader Class Initialized
INFO - 2024-07-08 15:19:49 --> Helper loaded: url_helper
INFO - 2024-07-08 15:19:49 --> Helper loaded: file_helper
INFO - 2024-07-08 15:19:49 --> Helper loaded: form_helper
INFO - 2024-07-08 15:19:49 --> Helper loaded: my_helper
INFO - 2024-07-08 15:19:49 --> Database Driver Class Initialized
INFO - 2024-07-08 15:19:49 --> Session: Class initialized using 'files' driver.
INFO - 2024-07-08 15:19:49 --> Controller Class Initialized
INFO - 2024-07-08 15:19:50 --> Config Class Initialized
INFO - 2024-07-08 15:19:50 --> Hooks Class Initialized
DEBUG - 2024-07-08 15:19:50 --> UTF-8 Support Enabled
INFO - 2024-07-08 15:19:50 --> Utf8 Class Initialized
INFO - 2024-07-08 15:19:50 --> URI Class Initialized
INFO - 2024-07-08 15:19:50 --> Router Class Initialized
INFO - 2024-07-08 15:19:50 --> Output Class Initialized
INFO - 2024-07-08 15:19:50 --> Security Class Initialized
DEBUG - 2024-07-08 15:19:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-07-08 15:19:50 --> Input Class Initialized
INFO - 2024-07-08 15:19:50 --> Language Class Initialized
INFO - 2024-07-08 15:19:50 --> Language Class Initialized
INFO - 2024-07-08 15:19:50 --> Config Class Initialized
INFO - 2024-07-08 15:19:50 --> Loader Class Initialized
INFO - 2024-07-08 15:19:50 --> Helper loaded: url_helper
INFO - 2024-07-08 15:19:50 --> Helper loaded: file_helper
INFO - 2024-07-08 15:19:50 --> Helper loaded: form_helper
INFO - 2024-07-08 15:19:50 --> Helper loaded: my_helper
INFO - 2024-07-08 15:19:50 --> Database Driver Class Initialized
INFO - 2024-07-08 15:19:50 --> Session: Class initialized using 'files' driver.
INFO - 2024-07-08 15:19:50 --> Controller Class Initialized
INFO - 2024-07-08 15:19:51 --> Config Class Initialized
INFO - 2024-07-08 15:19:51 --> Hooks Class Initialized
DEBUG - 2024-07-08 15:19:51 --> UTF-8 Support Enabled
INFO - 2024-07-08 15:19:51 --> Utf8 Class Initialized
INFO - 2024-07-08 15:19:51 --> URI Class Initialized
INFO - 2024-07-08 15:19:51 --> Router Class Initialized
INFO - 2024-07-08 15:19:51 --> Output Class Initialized
INFO - 2024-07-08 15:19:51 --> Security Class Initialized
DEBUG - 2024-07-08 15:19:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-07-08 15:19:51 --> Input Class Initialized
INFO - 2024-07-08 15:19:51 --> Language Class Initialized
INFO - 2024-07-08 15:19:51 --> Language Class Initialized
INFO - 2024-07-08 15:19:51 --> Config Class Initialized
INFO - 2024-07-08 15:19:51 --> Loader Class Initialized
INFO - 2024-07-08 15:19:51 --> Helper loaded: url_helper
INFO - 2024-07-08 15:19:51 --> Helper loaded: file_helper
INFO - 2024-07-08 15:19:51 --> Helper loaded: form_helper
INFO - 2024-07-08 15:19:51 --> Helper loaded: my_helper
INFO - 2024-07-08 15:19:51 --> Database Driver Class Initialized
INFO - 2024-07-08 15:19:51 --> Session: Class initialized using 'files' driver.
INFO - 2024-07-08 15:19:51 --> Controller Class Initialized
INFO - 2024-07-08 15:19:53 --> Config Class Initialized
INFO - 2024-07-08 15:19:53 --> Hooks Class Initialized
DEBUG - 2024-07-08 15:19:53 --> UTF-8 Support Enabled
INFO - 2024-07-08 15:19:53 --> Utf8 Class Initialized
INFO - 2024-07-08 15:19:53 --> URI Class Initialized
INFO - 2024-07-08 15:19:53 --> Router Class Initialized
INFO - 2024-07-08 15:19:53 --> Output Class Initialized
INFO - 2024-07-08 15:19:53 --> Security Class Initialized
DEBUG - 2024-07-08 15:19:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-07-08 15:19:53 --> Input Class Initialized
INFO - 2024-07-08 15:19:53 --> Language Class Initialized
INFO - 2024-07-08 15:19:53 --> Language Class Initialized
INFO - 2024-07-08 15:19:53 --> Config Class Initialized
INFO - 2024-07-08 15:19:53 --> Loader Class Initialized
INFO - 2024-07-08 15:19:53 --> Helper loaded: url_helper
INFO - 2024-07-08 15:19:53 --> Helper loaded: file_helper
INFO - 2024-07-08 15:19:53 --> Helper loaded: form_helper
INFO - 2024-07-08 15:19:53 --> Helper loaded: my_helper
INFO - 2024-07-08 15:19:53 --> Database Driver Class Initialized
INFO - 2024-07-08 15:19:53 --> Session: Class initialized using 'files' driver.
INFO - 2024-07-08 15:19:53 --> Controller Class Initialized
INFO - 2024-07-08 15:19:53 --> Config Class Initialized
INFO - 2024-07-08 15:19:53 --> Hooks Class Initialized
DEBUG - 2024-07-08 15:19:53 --> UTF-8 Support Enabled
INFO - 2024-07-08 15:19:53 --> Utf8 Class Initialized
INFO - 2024-07-08 15:19:53 --> URI Class Initialized
INFO - 2024-07-08 15:19:53 --> Router Class Initialized
INFO - 2024-07-08 15:19:53 --> Output Class Initialized
INFO - 2024-07-08 15:19:53 --> Security Class Initialized
DEBUG - 2024-07-08 15:19:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-07-08 15:19:53 --> Input Class Initialized
INFO - 2024-07-08 15:19:53 --> Language Class Initialized
INFO - 2024-07-08 15:19:53 --> Language Class Initialized
INFO - 2024-07-08 15:19:53 --> Config Class Initialized
INFO - 2024-07-08 15:19:53 --> Loader Class Initialized
INFO - 2024-07-08 15:19:53 --> Helper loaded: url_helper
INFO - 2024-07-08 15:19:53 --> Helper loaded: file_helper
INFO - 2024-07-08 15:19:53 --> Helper loaded: form_helper
INFO - 2024-07-08 15:19:53 --> Helper loaded: my_helper
INFO - 2024-07-08 15:19:53 --> Database Driver Class Initialized
INFO - 2024-07-08 15:19:53 --> Session: Class initialized using 'files' driver.
INFO - 2024-07-08 15:19:53 --> Controller Class Initialized
DEBUG - 2024-07-08 15:19:53 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/data_siswa/views/list.php
DEBUG - 2024-07-08 15:19:53 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-07-08 15:19:53 --> Final output sent to browser
DEBUG - 2024-07-08 15:19:53 --> Total execution time: 0.0329
INFO - 2024-07-08 15:19:53 --> Config Class Initialized
INFO - 2024-07-08 15:19:53 --> Hooks Class Initialized
DEBUG - 2024-07-08 15:19:53 --> UTF-8 Support Enabled
INFO - 2024-07-08 15:19:53 --> Utf8 Class Initialized
INFO - 2024-07-08 15:19:53 --> URI Class Initialized
INFO - 2024-07-08 15:19:53 --> Router Class Initialized
INFO - 2024-07-08 15:19:53 --> Output Class Initialized
INFO - 2024-07-08 15:19:53 --> Security Class Initialized
DEBUG - 2024-07-08 15:19:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-07-08 15:19:53 --> Input Class Initialized
INFO - 2024-07-08 15:19:53 --> Language Class Initialized
ERROR - 2024-07-08 15:19:53 --> 404 Page Not Found: /index
INFO - 2024-07-08 15:19:53 --> Config Class Initialized
INFO - 2024-07-08 15:19:53 --> Hooks Class Initialized
DEBUG - 2024-07-08 15:19:53 --> UTF-8 Support Enabled
INFO - 2024-07-08 15:19:53 --> Utf8 Class Initialized
INFO - 2024-07-08 15:19:53 --> URI Class Initialized
INFO - 2024-07-08 15:19:53 --> Router Class Initialized
INFO - 2024-07-08 15:19:53 --> Output Class Initialized
INFO - 2024-07-08 15:19:53 --> Security Class Initialized
DEBUG - 2024-07-08 15:19:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-07-08 15:19:53 --> Input Class Initialized
INFO - 2024-07-08 15:19:53 --> Language Class Initialized
INFO - 2024-07-08 15:19:53 --> Language Class Initialized
INFO - 2024-07-08 15:19:53 --> Config Class Initialized
INFO - 2024-07-08 15:19:53 --> Loader Class Initialized
INFO - 2024-07-08 15:19:53 --> Helper loaded: url_helper
INFO - 2024-07-08 15:19:53 --> Helper loaded: file_helper
INFO - 2024-07-08 15:19:53 --> Helper loaded: form_helper
INFO - 2024-07-08 15:19:53 --> Helper loaded: my_helper
INFO - 2024-07-08 15:19:53 --> Database Driver Class Initialized
INFO - 2024-07-08 15:19:53 --> Session: Class initialized using 'files' driver.
INFO - 2024-07-08 15:19:53 --> Controller Class Initialized
INFO - 2024-07-08 15:19:54 --> Config Class Initialized
INFO - 2024-07-08 15:19:54 --> Hooks Class Initialized
DEBUG - 2024-07-08 15:19:54 --> UTF-8 Support Enabled
INFO - 2024-07-08 15:19:54 --> Utf8 Class Initialized
INFO - 2024-07-08 15:19:54 --> URI Class Initialized
INFO - 2024-07-08 15:19:54 --> Router Class Initialized
INFO - 2024-07-08 15:19:54 --> Output Class Initialized
INFO - 2024-07-08 15:19:54 --> Security Class Initialized
DEBUG - 2024-07-08 15:19:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-07-08 15:19:54 --> Input Class Initialized
INFO - 2024-07-08 15:19:54 --> Language Class Initialized
INFO - 2024-07-08 15:19:54 --> Language Class Initialized
INFO - 2024-07-08 15:19:54 --> Config Class Initialized
INFO - 2024-07-08 15:19:54 --> Loader Class Initialized
INFO - 2024-07-08 15:19:54 --> Helper loaded: url_helper
INFO - 2024-07-08 15:19:54 --> Helper loaded: file_helper
INFO - 2024-07-08 15:19:54 --> Helper loaded: form_helper
INFO - 2024-07-08 15:19:54 --> Helper loaded: my_helper
INFO - 2024-07-08 15:19:54 --> Database Driver Class Initialized
INFO - 2024-07-08 15:19:54 --> Session: Class initialized using 'files' driver.
INFO - 2024-07-08 15:19:54 --> Controller Class Initialized
INFO - 2024-07-08 15:19:57 --> Config Class Initialized
INFO - 2024-07-08 15:19:57 --> Hooks Class Initialized
DEBUG - 2024-07-08 15:19:57 --> UTF-8 Support Enabled
INFO - 2024-07-08 15:19:57 --> Utf8 Class Initialized
INFO - 2024-07-08 15:19:57 --> URI Class Initialized
INFO - 2024-07-08 15:19:57 --> Router Class Initialized
INFO - 2024-07-08 15:19:57 --> Output Class Initialized
INFO - 2024-07-08 15:19:57 --> Security Class Initialized
DEBUG - 2024-07-08 15:19:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-07-08 15:19:57 --> Input Class Initialized
INFO - 2024-07-08 15:19:57 --> Language Class Initialized
INFO - 2024-07-08 15:19:57 --> Language Class Initialized
INFO - 2024-07-08 15:19:57 --> Config Class Initialized
INFO - 2024-07-08 15:19:57 --> Loader Class Initialized
INFO - 2024-07-08 15:19:57 --> Helper loaded: url_helper
INFO - 2024-07-08 15:19:57 --> Helper loaded: file_helper
INFO - 2024-07-08 15:19:57 --> Helper loaded: form_helper
INFO - 2024-07-08 15:19:57 --> Helper loaded: my_helper
INFO - 2024-07-08 15:19:57 --> Database Driver Class Initialized
INFO - 2024-07-08 15:19:57 --> Session: Class initialized using 'files' driver.
INFO - 2024-07-08 15:19:57 --> Controller Class Initialized
INFO - 2024-07-08 15:19:57 --> Config Class Initialized
INFO - 2024-07-08 15:19:57 --> Hooks Class Initialized
DEBUG - 2024-07-08 15:19:57 --> UTF-8 Support Enabled
INFO - 2024-07-08 15:19:57 --> Utf8 Class Initialized
INFO - 2024-07-08 15:19:57 --> URI Class Initialized
INFO - 2024-07-08 15:19:58 --> Router Class Initialized
INFO - 2024-07-08 15:19:58 --> Output Class Initialized
INFO - 2024-07-08 15:19:58 --> Security Class Initialized
DEBUG - 2024-07-08 15:19:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-07-08 15:19:58 --> Input Class Initialized
INFO - 2024-07-08 15:19:58 --> Language Class Initialized
INFO - 2024-07-08 15:19:58 --> Language Class Initialized
INFO - 2024-07-08 15:19:58 --> Config Class Initialized
INFO - 2024-07-08 15:19:58 --> Loader Class Initialized
INFO - 2024-07-08 15:19:58 --> Helper loaded: url_helper
INFO - 2024-07-08 15:19:58 --> Helper loaded: file_helper
INFO - 2024-07-08 15:19:58 --> Helper loaded: form_helper
INFO - 2024-07-08 15:19:58 --> Helper loaded: my_helper
INFO - 2024-07-08 15:19:58 --> Database Driver Class Initialized
INFO - 2024-07-08 15:19:58 --> Session: Class initialized using 'files' driver.
INFO - 2024-07-08 15:19:58 --> Controller Class Initialized
DEBUG - 2024-07-08 15:19:58 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/data_siswa/views/list.php
DEBUG - 2024-07-08 15:19:58 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-07-08 15:19:58 --> Final output sent to browser
DEBUG - 2024-07-08 15:19:58 --> Total execution time: 0.0359
INFO - 2024-07-08 15:19:58 --> Config Class Initialized
INFO - 2024-07-08 15:19:58 --> Hooks Class Initialized
DEBUG - 2024-07-08 15:19:58 --> UTF-8 Support Enabled
INFO - 2024-07-08 15:19:58 --> Utf8 Class Initialized
INFO - 2024-07-08 15:19:58 --> URI Class Initialized
INFO - 2024-07-08 15:19:58 --> Router Class Initialized
INFO - 2024-07-08 15:19:58 --> Output Class Initialized
INFO - 2024-07-08 15:19:58 --> Security Class Initialized
DEBUG - 2024-07-08 15:19:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-07-08 15:19:58 --> Input Class Initialized
INFO - 2024-07-08 15:19:58 --> Language Class Initialized
ERROR - 2024-07-08 15:19:58 --> 404 Page Not Found: /index
INFO - 2024-07-08 15:19:58 --> Config Class Initialized
INFO - 2024-07-08 15:19:58 --> Hooks Class Initialized
DEBUG - 2024-07-08 15:19:58 --> UTF-8 Support Enabled
INFO - 2024-07-08 15:19:58 --> Utf8 Class Initialized
INFO - 2024-07-08 15:19:58 --> URI Class Initialized
INFO - 2024-07-08 15:19:58 --> Router Class Initialized
INFO - 2024-07-08 15:19:58 --> Output Class Initialized
INFO - 2024-07-08 15:19:58 --> Security Class Initialized
DEBUG - 2024-07-08 15:19:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-07-08 15:19:58 --> Input Class Initialized
INFO - 2024-07-08 15:19:58 --> Language Class Initialized
INFO - 2024-07-08 15:19:58 --> Language Class Initialized
INFO - 2024-07-08 15:19:58 --> Config Class Initialized
INFO - 2024-07-08 15:19:58 --> Loader Class Initialized
INFO - 2024-07-08 15:19:58 --> Helper loaded: url_helper
INFO - 2024-07-08 15:19:58 --> Helper loaded: file_helper
INFO - 2024-07-08 15:19:58 --> Helper loaded: form_helper
INFO - 2024-07-08 15:19:58 --> Helper loaded: my_helper
INFO - 2024-07-08 15:19:58 --> Database Driver Class Initialized
INFO - 2024-07-08 15:19:58 --> Session: Class initialized using 'files' driver.
INFO - 2024-07-08 15:19:58 --> Controller Class Initialized
INFO - 2024-07-08 15:19:59 --> Config Class Initialized
INFO - 2024-07-08 15:19:59 --> Hooks Class Initialized
DEBUG - 2024-07-08 15:19:59 --> UTF-8 Support Enabled
INFO - 2024-07-08 15:19:59 --> Utf8 Class Initialized
INFO - 2024-07-08 15:19:59 --> URI Class Initialized
INFO - 2024-07-08 15:19:59 --> Router Class Initialized
INFO - 2024-07-08 15:19:59 --> Output Class Initialized
INFO - 2024-07-08 15:19:59 --> Security Class Initialized
DEBUG - 2024-07-08 15:19:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-07-08 15:19:59 --> Input Class Initialized
INFO - 2024-07-08 15:19:59 --> Language Class Initialized
INFO - 2024-07-08 15:19:59 --> Language Class Initialized
INFO - 2024-07-08 15:19:59 --> Config Class Initialized
INFO - 2024-07-08 15:19:59 --> Loader Class Initialized
INFO - 2024-07-08 15:19:59 --> Helper loaded: url_helper
INFO - 2024-07-08 15:19:59 --> Helper loaded: file_helper
INFO - 2024-07-08 15:19:59 --> Helper loaded: form_helper
INFO - 2024-07-08 15:19:59 --> Helper loaded: my_helper
INFO - 2024-07-08 15:19:59 --> Database Driver Class Initialized
INFO - 2024-07-08 15:19:59 --> Session: Class initialized using 'files' driver.
INFO - 2024-07-08 15:19:59 --> Controller Class Initialized
INFO - 2024-07-08 15:20:02 --> Config Class Initialized
INFO - 2024-07-08 15:20:02 --> Hooks Class Initialized
DEBUG - 2024-07-08 15:20:02 --> UTF-8 Support Enabled
INFO - 2024-07-08 15:20:02 --> Utf8 Class Initialized
INFO - 2024-07-08 15:20:02 --> URI Class Initialized
INFO - 2024-07-08 15:20:02 --> Router Class Initialized
INFO - 2024-07-08 15:20:02 --> Output Class Initialized
INFO - 2024-07-08 15:20:02 --> Security Class Initialized
DEBUG - 2024-07-08 15:20:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-07-08 15:20:02 --> Input Class Initialized
INFO - 2024-07-08 15:20:02 --> Language Class Initialized
INFO - 2024-07-08 15:20:02 --> Language Class Initialized
INFO - 2024-07-08 15:20:02 --> Config Class Initialized
INFO - 2024-07-08 15:20:02 --> Loader Class Initialized
INFO - 2024-07-08 15:20:02 --> Helper loaded: url_helper
INFO - 2024-07-08 15:20:02 --> Helper loaded: file_helper
INFO - 2024-07-08 15:20:02 --> Helper loaded: form_helper
INFO - 2024-07-08 15:20:02 --> Helper loaded: my_helper
INFO - 2024-07-08 15:20:02 --> Database Driver Class Initialized
INFO - 2024-07-08 15:20:02 --> Session: Class initialized using 'files' driver.
INFO - 2024-07-08 15:20:02 --> Controller Class Initialized
INFO - 2024-07-08 15:20:02 --> Config Class Initialized
INFO - 2024-07-08 15:20:02 --> Hooks Class Initialized
DEBUG - 2024-07-08 15:20:02 --> UTF-8 Support Enabled
INFO - 2024-07-08 15:20:02 --> Utf8 Class Initialized
INFO - 2024-07-08 15:20:02 --> URI Class Initialized
INFO - 2024-07-08 15:20:02 --> Router Class Initialized
INFO - 2024-07-08 15:20:02 --> Output Class Initialized
INFO - 2024-07-08 15:20:02 --> Security Class Initialized
DEBUG - 2024-07-08 15:20:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-07-08 15:20:02 --> Input Class Initialized
INFO - 2024-07-08 15:20:02 --> Language Class Initialized
INFO - 2024-07-08 15:20:02 --> Language Class Initialized
INFO - 2024-07-08 15:20:02 --> Config Class Initialized
INFO - 2024-07-08 15:20:02 --> Loader Class Initialized
INFO - 2024-07-08 15:20:02 --> Helper loaded: url_helper
INFO - 2024-07-08 15:20:02 --> Helper loaded: file_helper
INFO - 2024-07-08 15:20:02 --> Helper loaded: form_helper
INFO - 2024-07-08 15:20:02 --> Helper loaded: my_helper
INFO - 2024-07-08 15:20:02 --> Database Driver Class Initialized
INFO - 2024-07-08 15:20:02 --> Session: Class initialized using 'files' driver.
INFO - 2024-07-08 15:20:02 --> Controller Class Initialized
DEBUG - 2024-07-08 15:20:02 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/data_siswa/views/list.php
DEBUG - 2024-07-08 15:20:02 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-07-08 15:20:02 --> Final output sent to browser
DEBUG - 2024-07-08 15:20:02 --> Total execution time: 0.0357
INFO - 2024-07-08 15:20:02 --> Config Class Initialized
INFO - 2024-07-08 15:20:02 --> Hooks Class Initialized
DEBUG - 2024-07-08 15:20:02 --> UTF-8 Support Enabled
INFO - 2024-07-08 15:20:02 --> Utf8 Class Initialized
INFO - 2024-07-08 15:20:02 --> URI Class Initialized
INFO - 2024-07-08 15:20:02 --> Router Class Initialized
INFO - 2024-07-08 15:20:02 --> Output Class Initialized
INFO - 2024-07-08 15:20:02 --> Security Class Initialized
DEBUG - 2024-07-08 15:20:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-07-08 15:20:02 --> Input Class Initialized
INFO - 2024-07-08 15:20:02 --> Language Class Initialized
ERROR - 2024-07-08 15:20:02 --> 404 Page Not Found: /index
INFO - 2024-07-08 15:20:02 --> Config Class Initialized
INFO - 2024-07-08 15:20:02 --> Hooks Class Initialized
DEBUG - 2024-07-08 15:20:02 --> UTF-8 Support Enabled
INFO - 2024-07-08 15:20:02 --> Utf8 Class Initialized
INFO - 2024-07-08 15:20:02 --> URI Class Initialized
INFO - 2024-07-08 15:20:02 --> Router Class Initialized
INFO - 2024-07-08 15:20:02 --> Output Class Initialized
INFO - 2024-07-08 15:20:02 --> Security Class Initialized
DEBUG - 2024-07-08 15:20:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-07-08 15:20:02 --> Input Class Initialized
INFO - 2024-07-08 15:20:02 --> Language Class Initialized
INFO - 2024-07-08 15:20:02 --> Language Class Initialized
INFO - 2024-07-08 15:20:02 --> Config Class Initialized
INFO - 2024-07-08 15:20:02 --> Loader Class Initialized
INFO - 2024-07-08 15:20:02 --> Helper loaded: url_helper
INFO - 2024-07-08 15:20:02 --> Helper loaded: file_helper
INFO - 2024-07-08 15:20:02 --> Helper loaded: form_helper
INFO - 2024-07-08 15:20:02 --> Helper loaded: my_helper
INFO - 2024-07-08 15:20:02 --> Database Driver Class Initialized
INFO - 2024-07-08 15:20:02 --> Session: Class initialized using 'files' driver.
INFO - 2024-07-08 15:20:02 --> Controller Class Initialized
INFO - 2024-07-08 15:20:03 --> Config Class Initialized
INFO - 2024-07-08 15:20:03 --> Hooks Class Initialized
DEBUG - 2024-07-08 15:20:03 --> UTF-8 Support Enabled
INFO - 2024-07-08 15:20:03 --> Utf8 Class Initialized
INFO - 2024-07-08 15:20:03 --> URI Class Initialized
INFO - 2024-07-08 15:20:03 --> Router Class Initialized
INFO - 2024-07-08 15:20:03 --> Output Class Initialized
INFO - 2024-07-08 15:20:03 --> Security Class Initialized
DEBUG - 2024-07-08 15:20:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-07-08 15:20:03 --> Input Class Initialized
INFO - 2024-07-08 15:20:03 --> Language Class Initialized
INFO - 2024-07-08 15:20:03 --> Language Class Initialized
INFO - 2024-07-08 15:20:03 --> Config Class Initialized
INFO - 2024-07-08 15:20:03 --> Loader Class Initialized
INFO - 2024-07-08 15:20:03 --> Helper loaded: url_helper
INFO - 2024-07-08 15:20:03 --> Helper loaded: file_helper
INFO - 2024-07-08 15:20:03 --> Helper loaded: form_helper
INFO - 2024-07-08 15:20:03 --> Helper loaded: my_helper
INFO - 2024-07-08 15:20:03 --> Database Driver Class Initialized
INFO - 2024-07-08 15:20:03 --> Session: Class initialized using 'files' driver.
INFO - 2024-07-08 15:20:03 --> Controller Class Initialized
INFO - 2024-07-08 15:20:06 --> Config Class Initialized
INFO - 2024-07-08 15:20:06 --> Hooks Class Initialized
DEBUG - 2024-07-08 15:20:06 --> UTF-8 Support Enabled
INFO - 2024-07-08 15:20:06 --> Utf8 Class Initialized
INFO - 2024-07-08 15:20:06 --> URI Class Initialized
INFO - 2024-07-08 15:20:06 --> Router Class Initialized
INFO - 2024-07-08 15:20:06 --> Output Class Initialized
INFO - 2024-07-08 15:20:06 --> Security Class Initialized
DEBUG - 2024-07-08 15:20:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-07-08 15:20:06 --> Input Class Initialized
INFO - 2024-07-08 15:20:06 --> Language Class Initialized
INFO - 2024-07-08 15:20:06 --> Language Class Initialized
INFO - 2024-07-08 15:20:06 --> Config Class Initialized
INFO - 2024-07-08 15:20:06 --> Loader Class Initialized
INFO - 2024-07-08 15:20:06 --> Helper loaded: url_helper
INFO - 2024-07-08 15:20:06 --> Helper loaded: file_helper
INFO - 2024-07-08 15:20:06 --> Helper loaded: form_helper
INFO - 2024-07-08 15:20:06 --> Helper loaded: my_helper
INFO - 2024-07-08 15:20:06 --> Database Driver Class Initialized
INFO - 2024-07-08 15:20:06 --> Session: Class initialized using 'files' driver.
INFO - 2024-07-08 15:20:06 --> Controller Class Initialized
INFO - 2024-07-08 15:20:06 --> Config Class Initialized
INFO - 2024-07-08 15:20:06 --> Hooks Class Initialized
DEBUG - 2024-07-08 15:20:06 --> UTF-8 Support Enabled
INFO - 2024-07-08 15:20:06 --> Utf8 Class Initialized
INFO - 2024-07-08 15:20:06 --> URI Class Initialized
INFO - 2024-07-08 15:20:06 --> Router Class Initialized
INFO - 2024-07-08 15:20:06 --> Output Class Initialized
INFO - 2024-07-08 15:20:06 --> Security Class Initialized
DEBUG - 2024-07-08 15:20:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-07-08 15:20:06 --> Input Class Initialized
INFO - 2024-07-08 15:20:06 --> Language Class Initialized
INFO - 2024-07-08 15:20:06 --> Language Class Initialized
INFO - 2024-07-08 15:20:06 --> Config Class Initialized
INFO - 2024-07-08 15:20:06 --> Loader Class Initialized
INFO - 2024-07-08 15:20:06 --> Helper loaded: url_helper
INFO - 2024-07-08 15:20:06 --> Helper loaded: file_helper
INFO - 2024-07-08 15:20:06 --> Helper loaded: form_helper
INFO - 2024-07-08 15:20:06 --> Helper loaded: my_helper
INFO - 2024-07-08 15:20:06 --> Database Driver Class Initialized
INFO - 2024-07-08 15:20:06 --> Session: Class initialized using 'files' driver.
INFO - 2024-07-08 15:20:06 --> Controller Class Initialized
DEBUG - 2024-07-08 15:20:06 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/data_siswa/views/list.php
DEBUG - 2024-07-08 15:20:06 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-07-08 15:20:06 --> Final output sent to browser
DEBUG - 2024-07-08 15:20:06 --> Total execution time: 0.0855
INFO - 2024-07-08 15:20:06 --> Config Class Initialized
INFO - 2024-07-08 15:20:06 --> Hooks Class Initialized
DEBUG - 2024-07-08 15:20:06 --> UTF-8 Support Enabled
INFO - 2024-07-08 15:20:06 --> Utf8 Class Initialized
INFO - 2024-07-08 15:20:06 --> URI Class Initialized
INFO - 2024-07-08 15:20:06 --> Router Class Initialized
INFO - 2024-07-08 15:20:06 --> Output Class Initialized
INFO - 2024-07-08 15:20:06 --> Security Class Initialized
DEBUG - 2024-07-08 15:20:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-07-08 15:20:06 --> Input Class Initialized
INFO - 2024-07-08 15:20:06 --> Language Class Initialized
ERROR - 2024-07-08 15:20:06 --> 404 Page Not Found: /index
INFO - 2024-07-08 15:20:06 --> Config Class Initialized
INFO - 2024-07-08 15:20:06 --> Hooks Class Initialized
DEBUG - 2024-07-08 15:20:06 --> UTF-8 Support Enabled
INFO - 2024-07-08 15:20:06 --> Utf8 Class Initialized
INFO - 2024-07-08 15:20:06 --> URI Class Initialized
INFO - 2024-07-08 15:20:06 --> Router Class Initialized
INFO - 2024-07-08 15:20:06 --> Output Class Initialized
INFO - 2024-07-08 15:20:06 --> Security Class Initialized
DEBUG - 2024-07-08 15:20:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-07-08 15:20:06 --> Input Class Initialized
INFO - 2024-07-08 15:20:06 --> Language Class Initialized
INFO - 2024-07-08 15:20:06 --> Language Class Initialized
INFO - 2024-07-08 15:20:06 --> Config Class Initialized
INFO - 2024-07-08 15:20:06 --> Loader Class Initialized
INFO - 2024-07-08 15:20:06 --> Helper loaded: url_helper
INFO - 2024-07-08 15:20:06 --> Helper loaded: file_helper
INFO - 2024-07-08 15:20:06 --> Helper loaded: form_helper
INFO - 2024-07-08 15:20:06 --> Helper loaded: my_helper
INFO - 2024-07-08 15:20:06 --> Database Driver Class Initialized
INFO - 2024-07-08 15:20:06 --> Session: Class initialized using 'files' driver.
INFO - 2024-07-08 15:20:06 --> Controller Class Initialized
INFO - 2024-07-08 15:22:09 --> Config Class Initialized
INFO - 2024-07-08 15:22:09 --> Hooks Class Initialized
DEBUG - 2024-07-08 15:22:09 --> UTF-8 Support Enabled
INFO - 2024-07-08 15:22:09 --> Utf8 Class Initialized
INFO - 2024-07-08 15:22:09 --> URI Class Initialized
INFO - 2024-07-08 15:22:09 --> Router Class Initialized
INFO - 2024-07-08 15:22:09 --> Output Class Initialized
INFO - 2024-07-08 15:22:09 --> Security Class Initialized
DEBUG - 2024-07-08 15:22:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-07-08 15:22:09 --> Input Class Initialized
INFO - 2024-07-08 15:22:09 --> Language Class Initialized
INFO - 2024-07-08 15:22:09 --> Language Class Initialized
INFO - 2024-07-08 15:22:09 --> Config Class Initialized
INFO - 2024-07-08 15:22:09 --> Loader Class Initialized
INFO - 2024-07-08 15:22:09 --> Helper loaded: url_helper
INFO - 2024-07-08 15:22:09 --> Helper loaded: file_helper
INFO - 2024-07-08 15:22:09 --> Helper loaded: form_helper
INFO - 2024-07-08 15:22:09 --> Helper loaded: my_helper
INFO - 2024-07-08 15:22:09 --> Database Driver Class Initialized
INFO - 2024-07-08 15:22:09 --> Session: Class initialized using 'files' driver.
INFO - 2024-07-08 15:22:09 --> Controller Class Initialized
DEBUG - 2024-07-08 15:22:09 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/data_siswa/views/form_import.php
DEBUG - 2024-07-08 15:22:09 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-07-08 15:22:09 --> Final output sent to browser
DEBUG - 2024-07-08 15:22:09 --> Total execution time: 0.0591
INFO - 2024-07-08 15:22:15 --> Config Class Initialized
INFO - 2024-07-08 15:22:15 --> Hooks Class Initialized
DEBUG - 2024-07-08 15:22:15 --> UTF-8 Support Enabled
INFO - 2024-07-08 15:22:15 --> Utf8 Class Initialized
INFO - 2024-07-08 15:22:15 --> URI Class Initialized
INFO - 2024-07-08 15:22:15 --> Router Class Initialized
INFO - 2024-07-08 15:22:15 --> Output Class Initialized
INFO - 2024-07-08 15:22:15 --> Security Class Initialized
DEBUG - 2024-07-08 15:22:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-07-08 15:22:15 --> Input Class Initialized
INFO - 2024-07-08 15:22:15 --> Language Class Initialized
INFO - 2024-07-08 15:22:15 --> Language Class Initialized
INFO - 2024-07-08 15:22:15 --> Config Class Initialized
INFO - 2024-07-08 15:22:15 --> Loader Class Initialized
INFO - 2024-07-08 15:22:15 --> Helper loaded: url_helper
INFO - 2024-07-08 15:22:15 --> Helper loaded: file_helper
INFO - 2024-07-08 15:22:15 --> Helper loaded: form_helper
INFO - 2024-07-08 15:22:15 --> Helper loaded: my_helper
INFO - 2024-07-08 15:22:15 --> Database Driver Class Initialized
INFO - 2024-07-08 15:22:15 --> Session: Class initialized using 'files' driver.
INFO - 2024-07-08 15:22:15 --> Controller Class Initialized
ERROR - 2024-07-08 15:22:15 --> Severity: 8192 --> Array and string offset access syntax with curly braces is deprecated /www/wwwroot/report.mhis.link/bangka/secondary/application/third_party/PHP_Excel/PHPExcel/Reader/Excel5.php 1862
ERROR - 2024-07-08 15:22:15 --> Severity: 8192 --> Array and string offset access syntax with curly braces is deprecated /www/wwwroot/report.mhis.link/bangka/secondary/application/third_party/PHP_Excel/PHPExcel/Reader/Excel5.php 1921
ERROR - 2024-07-08 15:22:15 --> Severity: 8192 --> Array and string offset access syntax with curly braces is deprecated /www/wwwroot/report.mhis.link/bangka/secondary/application/third_party/PHP_Excel/PHPExcel/Reader/Excel5.php 2060
ERROR - 2024-07-08 15:22:15 --> Severity: 8192 --> Array and string offset access syntax with curly braces is deprecated /www/wwwroot/report.mhis.link/bangka/secondary/application/third_party/PHP_Excel/PHPExcel/Reader/Excel5.php 2085
ERROR - 2024-07-08 15:22:15 --> Severity: 8192 --> Array and string offset access syntax with curly braces is deprecated /www/wwwroot/report.mhis.link/bangka/secondary/application/third_party/PHP_Excel/PHPExcel/Reader/Excel5.php 2095
ERROR - 2024-07-08 15:22:15 --> Severity: 8192 --> Array and string offset access syntax with curly braces is deprecated /www/wwwroot/report.mhis.link/bangka/secondary/application/third_party/PHP_Excel/PHPExcel/Reader/Excel5.php 2113
ERROR - 2024-07-08 15:22:15 --> Severity: 8192 --> Array and string offset access syntax with curly braces is deprecated /www/wwwroot/report.mhis.link/bangka/secondary/application/third_party/PHP_Excel/PHPExcel/Reader/Excel5.php 2126
ERROR - 2024-07-08 15:22:15 --> Severity: 8192 --> Array and string offset access syntax with curly braces is deprecated /www/wwwroot/report.mhis.link/bangka/secondary/application/third_party/PHP_Excel/PHPExcel/Reader/Excel5.php 2130
ERROR - 2024-07-08 15:22:15 --> Severity: 8192 --> Array and string offset access syntax with curly braces is deprecated /www/wwwroot/report.mhis.link/bangka/secondary/application/third_party/PHP_Excel/PHPExcel/Reader/Excel5.php 2212
ERROR - 2024-07-08 15:22:15 --> Severity: 8192 --> Array and string offset access syntax with curly braces is deprecated /www/wwwroot/report.mhis.link/bangka/secondary/application/third_party/PHP_Excel/PHPExcel/Reader/Excel5.php 2336
ERROR - 2024-07-08 15:22:15 --> Severity: 8192 --> Array and string offset access syntax with curly braces is deprecated /www/wwwroot/report.mhis.link/bangka/secondary/application/third_party/PHP_Excel/PHPExcel/Reader/Excel5.php 2336
ERROR - 2024-07-08 15:22:15 --> Severity: 8192 --> Array and string offset access syntax with curly braces is deprecated /www/wwwroot/report.mhis.link/bangka/secondary/application/third_party/PHP_Excel/PHPExcel/Reader/Excel5.php 2336
ERROR - 2024-07-08 15:22:15 --> Severity: 8192 --> Array and string offset access syntax with curly braces is deprecated /www/wwwroot/report.mhis.link/bangka/secondary/application/third_party/PHP_Excel/PHPExcel/Reader/Excel5.php 2352
ERROR - 2024-07-08 15:22:15 --> Severity: 8192 --> Array and string offset access syntax with curly braces is deprecated /www/wwwroot/report.mhis.link/bangka/secondary/application/third_party/PHP_Excel/PHPExcel/Reader/Excel5.php 2352
ERROR - 2024-07-08 15:22:15 --> Severity: 8192 --> Array and string offset access syntax with curly braces is deprecated /www/wwwroot/report.mhis.link/bangka/secondary/application/third_party/PHP_Excel/PHPExcel/Reader/Excel5.php 2352
ERROR - 2024-07-08 15:22:15 --> Severity: 8192 --> Array and string offset access syntax with curly braces is deprecated /www/wwwroot/report.mhis.link/bangka/secondary/application/third_party/PHP_Excel/PHPExcel/Reader/Excel5.php 2368
ERROR - 2024-07-08 15:22:15 --> Severity: 8192 --> Array and string offset access syntax with curly braces is deprecated /www/wwwroot/report.mhis.link/bangka/secondary/application/third_party/PHP_Excel/PHPExcel/Reader/Excel5.php 2368
ERROR - 2024-07-08 15:22:15 --> Severity: 8192 --> Array and string offset access syntax with curly braces is deprecated /www/wwwroot/report.mhis.link/bangka/secondary/application/third_party/PHP_Excel/PHPExcel/Reader/Excel5.php 2368
ERROR - 2024-07-08 15:22:15 --> Severity: 8192 --> Array and string offset access syntax with curly braces is deprecated /www/wwwroot/report.mhis.link/bangka/secondary/application/third_party/PHP_Excel/PHPExcel/Reader/Excel5.php 2384
ERROR - 2024-07-08 15:22:15 --> Severity: 8192 --> Array and string offset access syntax with curly braces is deprecated /www/wwwroot/report.mhis.link/bangka/secondary/application/third_party/PHP_Excel/PHPExcel/Reader/Excel5.php 2384
ERROR - 2024-07-08 15:22:15 --> Severity: 8192 --> Array and string offset access syntax with curly braces is deprecated /www/wwwroot/report.mhis.link/bangka/secondary/application/third_party/PHP_Excel/PHPExcel/Reader/Excel5.php 2384
ERROR - 2024-07-08 15:22:15 --> Severity: 8192 --> Array and string offset access syntax with curly braces is deprecated /www/wwwroot/report.mhis.link/bangka/secondary/application/third_party/PHP_Excel/PHPExcel/Reader/Excel5.php 2400
ERROR - 2024-07-08 15:22:15 --> Severity: 8192 --> Array and string offset access syntax with curly braces is deprecated /www/wwwroot/report.mhis.link/bangka/secondary/application/third_party/PHP_Excel/PHPExcel/Reader/Excel5.php 2400
ERROR - 2024-07-08 15:22:15 --> Severity: 8192 --> Array and string offset access syntax with curly braces is deprecated /www/wwwroot/report.mhis.link/bangka/secondary/application/third_party/PHP_Excel/PHPExcel/Reader/Excel5.php 2400
ERROR - 2024-07-08 15:22:15 --> Severity: 8192 --> Array and string offset access syntax with curly braces is deprecated /www/wwwroot/report.mhis.link/bangka/secondary/application/third_party/PHP_Excel/PHPExcel/Reader/Excel5.php 2416
ERROR - 2024-07-08 15:22:15 --> Severity: 8192 --> Array and string offset access syntax with curly braces is deprecated /www/wwwroot/report.mhis.link/bangka/secondary/application/third_party/PHP_Excel/PHPExcel/Reader/Excel5.php 2416
ERROR - 2024-07-08 15:22:15 --> Severity: 8192 --> Array and string offset access syntax with curly braces is deprecated /www/wwwroot/report.mhis.link/bangka/secondary/application/third_party/PHP_Excel/PHPExcel/Reader/Excel5.php 2416
ERROR - 2024-07-08 15:22:15 --> Severity: 8192 --> Array and string offset access syntax with curly braces is deprecated /www/wwwroot/report.mhis.link/bangka/secondary/application/third_party/PHP_Excel/PHPExcel/Reader/Excel5.php 2432
ERROR - 2024-07-08 15:22:15 --> Severity: 8192 --> Array and string offset access syntax with curly braces is deprecated /www/wwwroot/report.mhis.link/bangka/secondary/application/third_party/PHP_Excel/PHPExcel/Reader/Excel5.php 2432
ERROR - 2024-07-08 15:22:15 --> Severity: 8192 --> Array and string offset access syntax with curly braces is deprecated /www/wwwroot/report.mhis.link/bangka/secondary/application/third_party/PHP_Excel/PHPExcel/Reader/Excel5.php 2432
ERROR - 2024-07-08 15:22:15 --> Severity: 8192 --> Array and string offset access syntax with curly braces is deprecated /www/wwwroot/report.mhis.link/bangka/secondary/application/third_party/PHP_Excel/PHPExcel/Reader/Excel5.php 2448
ERROR - 2024-07-08 15:22:15 --> Severity: 8192 --> Array and string offset access syntax with curly braces is deprecated /www/wwwroot/report.mhis.link/bangka/secondary/application/third_party/PHP_Excel/PHPExcel/Reader/Excel5.php 2448
ERROR - 2024-07-08 15:22:15 --> Severity: 8192 --> Array and string offset access syntax with curly braces is deprecated /www/wwwroot/report.mhis.link/bangka/secondary/application/third_party/PHP_Excel/PHPExcel/Reader/Excel5.php 2448
ERROR - 2024-07-08 15:22:15 --> Severity: 8192 --> Array and string offset access syntax with curly braces is deprecated /www/wwwroot/report.mhis.link/bangka/secondary/application/third_party/PHP_Excel/PHPExcel/Reader/Excel5.php 2490
ERROR - 2024-07-08 15:22:15 --> Severity: 8192 --> Array and string offset access syntax with curly braces is deprecated /www/wwwroot/report.mhis.link/bangka/secondary/application/third_party/PHP_Excel/PHPExcel/Reader/Excel5.php 2557
ERROR - 2024-07-08 15:22:15 --> Severity: 8192 --> Array and string offset access syntax with curly braces is deprecated /www/wwwroot/report.mhis.link/bangka/secondary/application/third_party/PHP_Excel/PHPExcel/Reader/Excel5.php 2565
ERROR - 2024-07-08 15:22:15 --> Severity: 8192 --> Array and string offset access syntax with curly braces is deprecated /www/wwwroot/report.mhis.link/bangka/secondary/application/third_party/PHP_Excel/PHPExcel/Reader/Excel5.php 2744
ERROR - 2024-07-08 15:22:15 --> Severity: 8192 --> Array and string offset access syntax with curly braces is deprecated /www/wwwroot/report.mhis.link/bangka/secondary/application/third_party/PHP_Excel/PHPExcel/Reader/Excel5.php 2828
ERROR - 2024-07-08 15:22:15 --> Severity: 8192 --> Array and string offset access syntax with curly braces is deprecated /www/wwwroot/report.mhis.link/bangka/secondary/application/third_party/PHP_Excel/PHPExcel/Reader/Excel5.php 2897
ERROR - 2024-07-08 15:22:15 --> Severity: 8192 --> Array and string offset access syntax with curly braces is deprecated /www/wwwroot/report.mhis.link/bangka/secondary/application/third_party/PHP_Excel/PHPExcel/Reader/Excel5.php 2921
ERROR - 2024-07-08 15:22:15 --> Severity: 8192 --> Array and string offset access syntax with curly braces is deprecated /www/wwwroot/report.mhis.link/bangka/secondary/application/third_party/PHP_Excel/PHPExcel/Reader/Excel5.php 3820
ERROR - 2024-07-08 15:22:15 --> Severity: 8192 --> Array and string offset access syntax with curly braces is deprecated /www/wwwroot/report.mhis.link/bangka/secondary/application/third_party/PHP_Excel/PHPExcel/Reader/Excel5.php 3844
ERROR - 2024-07-08 15:22:15 --> Severity: 8192 --> Array and string offset access syntax with curly braces is deprecated /www/wwwroot/report.mhis.link/bangka/secondary/application/third_party/PHP_Excel/PHPExcel/Reader/Excel5.php 3845
ERROR - 2024-07-08 15:22:15 --> Severity: 8192 --> Array and string offset access syntax with curly braces is deprecated /www/wwwroot/report.mhis.link/bangka/secondary/application/third_party/PHP_Excel/PHPExcel/Reader/Excel5.php 3846
ERROR - 2024-07-08 15:22:15 --> Severity: 8192 --> Array and string offset access syntax with curly braces is deprecated /www/wwwroot/report.mhis.link/bangka/secondary/application/third_party/PHP_Excel/PHPExcel/Reader/Excel5.php 3860
ERROR - 2024-07-08 15:22:15 --> Severity: 8192 --> Array and string offset access syntax with curly braces is deprecated /www/wwwroot/report.mhis.link/bangka/secondary/application/third_party/PHP_Excel/PHPExcel/Reader/Excel5.php 3861
ERROR - 2024-07-08 15:22:15 --> Severity: 8192 --> Array and string offset access syntax with curly braces is deprecated /www/wwwroot/report.mhis.link/bangka/secondary/application/third_party/PHP_Excel/PHPExcel/Reader/Excel5.php 3862
ERROR - 2024-07-08 15:22:15 --> Severity: 8192 --> Array and string offset access syntax with curly braces is deprecated /www/wwwroot/report.mhis.link/bangka/secondary/application/third_party/PHP_Excel/PHPExcel/Reader/Excel5.php 3866
ERROR - 2024-07-08 15:22:15 --> Severity: 8192 --> Array and string offset access syntax with curly braces is deprecated /www/wwwroot/report.mhis.link/bangka/secondary/application/third_party/PHP_Excel/PHPExcel/Reader/Excel5.php 3868
ERROR - 2024-07-08 15:22:15 --> Severity: 8192 --> Array and string offset access syntax with curly braces is deprecated /www/wwwroot/report.mhis.link/bangka/secondary/application/third_party/PHP_Excel/PHPExcel/Reader/Excel5.php 3869
ERROR - 2024-07-08 15:22:15 --> Severity: 8192 --> Array and string offset access syntax with curly braces is deprecated /www/wwwroot/report.mhis.link/bangka/secondary/application/third_party/PHP_Excel/PHPExcel/Reader/Excel5.php 3870
ERROR - 2024-07-08 15:22:15 --> Severity: 8192 --> Array and string offset access syntax with curly braces is deprecated /www/wwwroot/report.mhis.link/bangka/secondary/application/third_party/PHP_Excel/PHPExcel/Reader/Excel5.php 3874
ERROR - 2024-07-08 15:22:15 --> Severity: 8192 --> Array and string offset access syntax with curly braces is deprecated /www/wwwroot/report.mhis.link/bangka/secondary/application/third_party/PHP_Excel/PHPExcel/Reader/Excel5.php 3876
ERROR - 2024-07-08 15:22:15 --> Severity: 8192 --> Array and string offset access syntax with curly braces is deprecated /www/wwwroot/report.mhis.link/bangka/secondary/application/third_party/PHP_Excel/PHPExcel/Reader/Excel5.php 3877
ERROR - 2024-07-08 15:22:15 --> Severity: 8192 --> Array and string offset access syntax with curly braces is deprecated /www/wwwroot/report.mhis.link/bangka/secondary/application/third_party/PHP_Excel/PHPExcel/Reader/Excel5.php 3878
ERROR - 2024-07-08 15:22:15 --> Severity: 8192 --> Array and string offset access syntax with curly braces is deprecated /www/wwwroot/report.mhis.link/bangka/secondary/application/third_party/PHP_Excel/PHPExcel/Reader/Excel5.php 3946
ERROR - 2024-07-08 15:22:15 --> Severity: 8192 --> Array and string offset access syntax with curly braces is deprecated /www/wwwroot/report.mhis.link/bangka/secondary/application/third_party/PHP_Excel/PHPExcel/Reader/Excel5.php 4013
ERROR - 2024-07-08 15:22:15 --> Severity: 8192 --> Array and string offset access syntax with curly braces is deprecated /www/wwwroot/report.mhis.link/bangka/secondary/application/third_party/PHP_Excel/PHPExcel/Reader/Excel5.php 4016
ERROR - 2024-07-08 15:22:15 --> Severity: 8192 --> Array and string offset access syntax with curly braces is deprecated /www/wwwroot/report.mhis.link/bangka/secondary/application/third_party/PHP_Excel/PHPExcel/Reader/Excel5.php 4394
ERROR - 2024-07-08 15:22:15 --> Severity: 8192 --> Array and string offset access syntax with curly braces is deprecated /www/wwwroot/report.mhis.link/bangka/secondary/application/third_party/PHP_Excel/PHPExcel/Reader/Excel5.php 4546
ERROR - 2024-07-08 15:22:15 --> Severity: 8192 --> Array and string offset access syntax with curly braces is deprecated /www/wwwroot/report.mhis.link/bangka/secondary/application/third_party/PHP_Excel/PHPExcel/Reader/Excel5.php 4548
ERROR - 2024-07-08 15:22:15 --> Severity: 8192 --> Array and string offset access syntax with curly braces is deprecated /www/wwwroot/report.mhis.link/bangka/secondary/application/third_party/PHP_Excel/PHPExcel/Reader/Excel5.php 6093
ERROR - 2024-07-08 15:22:15 --> Severity: 8192 --> Array and string offset access syntax with curly braces is deprecated /www/wwwroot/report.mhis.link/bangka/secondary/application/third_party/PHP_Excel/PHPExcel/Reader/Excel5.php 6096
ERROR - 2024-07-08 15:22:15 --> Severity: 8192 --> Array and string offset access syntax with curly braces is deprecated /www/wwwroot/report.mhis.link/bangka/secondary/application/third_party/PHP_Excel/PHPExcel/Reader/Excel5.php 6503
ERROR - 2024-07-08 15:22:15 --> Severity: 8192 --> Array and string offset access syntax with curly braces is deprecated /www/wwwroot/report.mhis.link/bangka/secondary/application/third_party/PHP_Excel/PHPExcel/Reader/Excel5.php 6506
ERROR - 2024-07-08 15:22:15 --> Severity: 8192 --> Array and string offset access syntax with curly braces is deprecated /www/wwwroot/report.mhis.link/bangka/secondary/application/third_party/PHP_Excel/PHPExcel/Reader/Excel5.php 6509
ERROR - 2024-07-08 15:22:15 --> Severity: Warning --> "continue" targeting switch is equivalent to "break". Did you mean to use "continue 2"? /www/wwwroot/report.mhis.link/bangka/secondary/application/third_party/PHP_Excel/PHPExcel/Shared/OLE.php 290
ERROR - 2024-07-08 15:22:15 --> Severity: 8192 --> Array and string offset access syntax with curly braces is deprecated /www/wwwroot/report.mhis.link/bangka/secondary/application/third_party/PHP_Excel/PHPExcel/Shared/OLE.php 450
ERROR - 2024-07-08 15:22:15 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /www/wwwroot/report.mhis.link/bangka/secondary/system/core/Exceptions.php:271) /www/wwwroot/report.mhis.link/bangka/secondary/system/helpers/url_helper.php 564
INFO - 2024-07-08 15:22:19 --> Config Class Initialized
INFO - 2024-07-08 15:22:19 --> Hooks Class Initialized
DEBUG - 2024-07-08 15:22:19 --> UTF-8 Support Enabled
INFO - 2024-07-08 15:22:19 --> Utf8 Class Initialized
INFO - 2024-07-08 15:22:19 --> URI Class Initialized
INFO - 2024-07-08 15:22:19 --> Router Class Initialized
INFO - 2024-07-08 15:22:19 --> Output Class Initialized
INFO - 2024-07-08 15:22:19 --> Security Class Initialized
DEBUG - 2024-07-08 15:22:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-07-08 15:22:19 --> Input Class Initialized
INFO - 2024-07-08 15:22:19 --> Language Class Initialized
INFO - 2024-07-08 15:22:19 --> Language Class Initialized
INFO - 2024-07-08 15:22:19 --> Config Class Initialized
INFO - 2024-07-08 15:22:19 --> Loader Class Initialized
INFO - 2024-07-08 15:22:19 --> Helper loaded: url_helper
INFO - 2024-07-08 15:22:19 --> Helper loaded: file_helper
INFO - 2024-07-08 15:22:19 --> Helper loaded: form_helper
INFO - 2024-07-08 15:22:19 --> Helper loaded: my_helper
INFO - 2024-07-08 15:22:19 --> Database Driver Class Initialized
INFO - 2024-07-08 15:22:19 --> Session: Class initialized using 'files' driver.
INFO - 2024-07-08 15:22:19 --> Controller Class Initialized
DEBUG - 2024-07-08 15:22:19 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/data_siswa/views/form_import.php
DEBUG - 2024-07-08 15:22:19 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-07-08 15:22:19 --> Final output sent to browser
DEBUG - 2024-07-08 15:22:19 --> Total execution time: 0.0375
INFO - 2024-07-08 15:22:25 --> Config Class Initialized
INFO - 2024-07-08 15:22:25 --> Hooks Class Initialized
DEBUG - 2024-07-08 15:22:25 --> UTF-8 Support Enabled
INFO - 2024-07-08 15:22:25 --> Utf8 Class Initialized
INFO - 2024-07-08 15:22:25 --> URI Class Initialized
INFO - 2024-07-08 15:22:25 --> Router Class Initialized
INFO - 2024-07-08 15:22:25 --> Output Class Initialized
INFO - 2024-07-08 15:22:25 --> Security Class Initialized
DEBUG - 2024-07-08 15:22:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-07-08 15:22:25 --> Input Class Initialized
INFO - 2024-07-08 15:22:25 --> Language Class Initialized
INFO - 2024-07-08 15:22:25 --> Language Class Initialized
INFO - 2024-07-08 15:22:25 --> Config Class Initialized
INFO - 2024-07-08 15:22:25 --> Loader Class Initialized
INFO - 2024-07-08 15:22:25 --> Helper loaded: url_helper
INFO - 2024-07-08 15:22:25 --> Helper loaded: file_helper
INFO - 2024-07-08 15:22:25 --> Helper loaded: form_helper
INFO - 2024-07-08 15:22:25 --> Helper loaded: my_helper
INFO - 2024-07-08 15:22:25 --> Database Driver Class Initialized
INFO - 2024-07-08 15:22:25 --> Session: Class initialized using 'files' driver.
INFO - 2024-07-08 15:22:25 --> Controller Class Initialized
DEBUG - 2024-07-08 15:22:25 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/data_siswa/views/list.php
DEBUG - 2024-07-08 15:22:25 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-07-08 15:22:25 --> Final output sent to browser
DEBUG - 2024-07-08 15:22:25 --> Total execution time: 0.0622
INFO - 2024-07-08 15:22:25 --> Config Class Initialized
INFO - 2024-07-08 15:22:25 --> Hooks Class Initialized
DEBUG - 2024-07-08 15:22:25 --> UTF-8 Support Enabled
INFO - 2024-07-08 15:22:25 --> Utf8 Class Initialized
INFO - 2024-07-08 15:22:25 --> URI Class Initialized
INFO - 2024-07-08 15:22:26 --> Router Class Initialized
INFO - 2024-07-08 15:22:26 --> Output Class Initialized
INFO - 2024-07-08 15:22:26 --> Security Class Initialized
DEBUG - 2024-07-08 15:22:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-07-08 15:22:26 --> Input Class Initialized
INFO - 2024-07-08 15:22:26 --> Language Class Initialized
ERROR - 2024-07-08 15:22:26 --> 404 Page Not Found: /index
INFO - 2024-07-08 15:22:26 --> Config Class Initialized
INFO - 2024-07-08 15:22:26 --> Hooks Class Initialized
DEBUG - 2024-07-08 15:22:26 --> UTF-8 Support Enabled
INFO - 2024-07-08 15:22:26 --> Utf8 Class Initialized
INFO - 2024-07-08 15:22:26 --> URI Class Initialized
INFO - 2024-07-08 15:22:26 --> Router Class Initialized
INFO - 2024-07-08 15:22:26 --> Output Class Initialized
INFO - 2024-07-08 15:22:26 --> Security Class Initialized
DEBUG - 2024-07-08 15:22:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-07-08 15:22:26 --> Input Class Initialized
INFO - 2024-07-08 15:22:26 --> Language Class Initialized
INFO - 2024-07-08 15:22:26 --> Language Class Initialized
INFO - 2024-07-08 15:22:26 --> Config Class Initialized
INFO - 2024-07-08 15:22:26 --> Loader Class Initialized
INFO - 2024-07-08 15:22:26 --> Helper loaded: url_helper
INFO - 2024-07-08 15:22:26 --> Helper loaded: file_helper
INFO - 2024-07-08 15:22:26 --> Helper loaded: form_helper
INFO - 2024-07-08 15:22:26 --> Helper loaded: my_helper
INFO - 2024-07-08 15:22:26 --> Database Driver Class Initialized
INFO - 2024-07-08 15:22:26 --> Session: Class initialized using 'files' driver.
INFO - 2024-07-08 15:22:26 --> Controller Class Initialized
INFO - 2024-07-08 15:22:29 --> Config Class Initialized
INFO - 2024-07-08 15:22:29 --> Hooks Class Initialized
DEBUG - 2024-07-08 15:22:29 --> UTF-8 Support Enabled
INFO - 2024-07-08 15:22:29 --> Utf8 Class Initialized
INFO - 2024-07-08 15:22:29 --> URI Class Initialized
INFO - 2024-07-08 15:22:29 --> Router Class Initialized
INFO - 2024-07-08 15:22:29 --> Output Class Initialized
INFO - 2024-07-08 15:22:29 --> Security Class Initialized
DEBUG - 2024-07-08 15:22:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-07-08 15:22:29 --> Input Class Initialized
INFO - 2024-07-08 15:22:29 --> Language Class Initialized
INFO - 2024-07-08 15:22:29 --> Language Class Initialized
INFO - 2024-07-08 15:22:29 --> Config Class Initialized
INFO - 2024-07-08 15:22:29 --> Loader Class Initialized
INFO - 2024-07-08 15:22:29 --> Helper loaded: url_helper
INFO - 2024-07-08 15:22:29 --> Helper loaded: file_helper
INFO - 2024-07-08 15:22:29 --> Helper loaded: form_helper
INFO - 2024-07-08 15:22:29 --> Helper loaded: my_helper
INFO - 2024-07-08 15:22:29 --> Database Driver Class Initialized
INFO - 2024-07-08 15:22:29 --> Session: Class initialized using 'files' driver.
INFO - 2024-07-08 15:22:29 --> Controller Class Initialized
INFO - 2024-07-08 15:22:31 --> Config Class Initialized
INFO - 2024-07-08 15:22:31 --> Hooks Class Initialized
DEBUG - 2024-07-08 15:22:31 --> UTF-8 Support Enabled
INFO - 2024-07-08 15:22:31 --> Utf8 Class Initialized
INFO - 2024-07-08 15:22:31 --> URI Class Initialized
INFO - 2024-07-08 15:22:31 --> Router Class Initialized
INFO - 2024-07-08 15:22:31 --> Output Class Initialized
INFO - 2024-07-08 15:22:31 --> Security Class Initialized
DEBUG - 2024-07-08 15:22:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-07-08 15:22:31 --> Input Class Initialized
INFO - 2024-07-08 15:22:31 --> Language Class Initialized
INFO - 2024-07-08 15:22:31 --> Language Class Initialized
INFO - 2024-07-08 15:22:31 --> Config Class Initialized
INFO - 2024-07-08 15:22:31 --> Loader Class Initialized
INFO - 2024-07-08 15:22:31 --> Helper loaded: url_helper
INFO - 2024-07-08 15:22:31 --> Helper loaded: file_helper
INFO - 2024-07-08 15:22:31 --> Helper loaded: form_helper
INFO - 2024-07-08 15:22:31 --> Helper loaded: my_helper
INFO - 2024-07-08 15:22:31 --> Database Driver Class Initialized
INFO - 2024-07-08 15:22:31 --> Session: Class initialized using 'files' driver.
INFO - 2024-07-08 15:22:31 --> Controller Class Initialized
ERROR - 2024-07-08 15:22:31 --> Severity: Notice --> Undefined variable: status_form /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/data_siswa/views/form.php 231
DEBUG - 2024-07-08 15:22:31 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/data_siswa/views/form.php
DEBUG - 2024-07-08 15:22:31 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-07-08 15:22:31 --> Final output sent to browser
DEBUG - 2024-07-08 15:22:31 --> Total execution time: 0.0369
INFO - 2024-07-08 15:22:56 --> Config Class Initialized
INFO - 2024-07-08 15:22:56 --> Hooks Class Initialized
DEBUG - 2024-07-08 15:22:56 --> UTF-8 Support Enabled
INFO - 2024-07-08 15:22:56 --> Utf8 Class Initialized
INFO - 2024-07-08 15:22:56 --> URI Class Initialized
INFO - 2024-07-08 15:22:56 --> Router Class Initialized
INFO - 2024-07-08 15:22:56 --> Output Class Initialized
INFO - 2024-07-08 15:22:56 --> Security Class Initialized
DEBUG - 2024-07-08 15:22:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-07-08 15:22:56 --> Input Class Initialized
INFO - 2024-07-08 15:22:56 --> Language Class Initialized
INFO - 2024-07-08 15:22:56 --> Language Class Initialized
INFO - 2024-07-08 15:22:56 --> Config Class Initialized
INFO - 2024-07-08 15:22:56 --> Loader Class Initialized
INFO - 2024-07-08 15:22:56 --> Helper loaded: url_helper
INFO - 2024-07-08 15:22:56 --> Helper loaded: file_helper
INFO - 2024-07-08 15:22:56 --> Helper loaded: form_helper
INFO - 2024-07-08 15:22:56 --> Helper loaded: my_helper
INFO - 2024-07-08 15:22:56 --> Database Driver Class Initialized
INFO - 2024-07-08 15:22:56 --> Session: Class initialized using 'files' driver.
INFO - 2024-07-08 15:22:56 --> Controller Class Initialized
INFO - 2024-07-08 15:22:56 --> Upload Class Initialized
INFO - 2024-07-08 15:22:56 --> Language file loaded: language/english/upload_lang.php
ERROR - 2024-07-08 15:22:56 --> The upload path does not appear to be valid.
INFO - 2024-07-08 15:22:57 --> Config Class Initialized
INFO - 2024-07-08 15:22:57 --> Hooks Class Initialized
DEBUG - 2024-07-08 15:22:57 --> UTF-8 Support Enabled
INFO - 2024-07-08 15:22:57 --> Utf8 Class Initialized
INFO - 2024-07-08 15:22:57 --> URI Class Initialized
INFO - 2024-07-08 15:22:57 --> Router Class Initialized
INFO - 2024-07-08 15:22:57 --> Output Class Initialized
INFO - 2024-07-08 15:22:57 --> Security Class Initialized
DEBUG - 2024-07-08 15:22:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-07-08 15:22:57 --> Input Class Initialized
INFO - 2024-07-08 15:22:57 --> Language Class Initialized
INFO - 2024-07-08 15:22:57 --> Language Class Initialized
INFO - 2024-07-08 15:22:57 --> Config Class Initialized
INFO - 2024-07-08 15:22:57 --> Loader Class Initialized
INFO - 2024-07-08 15:22:57 --> Helper loaded: url_helper
INFO - 2024-07-08 15:22:57 --> Helper loaded: file_helper
INFO - 2024-07-08 15:22:57 --> Helper loaded: form_helper
INFO - 2024-07-08 15:22:57 --> Helper loaded: my_helper
INFO - 2024-07-08 15:22:57 --> Database Driver Class Initialized
INFO - 2024-07-08 15:22:57 --> Session: Class initialized using 'files' driver.
INFO - 2024-07-08 15:22:57 --> Controller Class Initialized
DEBUG - 2024-07-08 15:22:57 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/data_siswa/views/list.php
DEBUG - 2024-07-08 15:22:57 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-07-08 15:22:57 --> Final output sent to browser
DEBUG - 2024-07-08 15:22:57 --> Total execution time: 0.0782
INFO - 2024-07-08 15:22:57 --> Config Class Initialized
INFO - 2024-07-08 15:22:57 --> Hooks Class Initialized
DEBUG - 2024-07-08 15:22:57 --> UTF-8 Support Enabled
INFO - 2024-07-08 15:22:57 --> Utf8 Class Initialized
INFO - 2024-07-08 15:22:57 --> URI Class Initialized
INFO - 2024-07-08 15:22:57 --> Router Class Initialized
INFO - 2024-07-08 15:22:57 --> Output Class Initialized
INFO - 2024-07-08 15:22:57 --> Security Class Initialized
DEBUG - 2024-07-08 15:22:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-07-08 15:22:57 --> Input Class Initialized
INFO - 2024-07-08 15:22:57 --> Language Class Initialized
ERROR - 2024-07-08 15:22:57 --> 404 Page Not Found: /index
INFO - 2024-07-08 15:22:57 --> Config Class Initialized
INFO - 2024-07-08 15:22:57 --> Hooks Class Initialized
DEBUG - 2024-07-08 15:22:57 --> UTF-8 Support Enabled
INFO - 2024-07-08 15:22:57 --> Utf8 Class Initialized
INFO - 2024-07-08 15:22:57 --> URI Class Initialized
INFO - 2024-07-08 15:22:57 --> Router Class Initialized
INFO - 2024-07-08 15:22:57 --> Output Class Initialized
INFO - 2024-07-08 15:22:57 --> Security Class Initialized
DEBUG - 2024-07-08 15:22:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-07-08 15:22:57 --> Input Class Initialized
INFO - 2024-07-08 15:22:57 --> Language Class Initialized
INFO - 2024-07-08 15:22:57 --> Language Class Initialized
INFO - 2024-07-08 15:22:57 --> Config Class Initialized
INFO - 2024-07-08 15:22:57 --> Loader Class Initialized
INFO - 2024-07-08 15:22:57 --> Helper loaded: url_helper
INFO - 2024-07-08 15:22:57 --> Helper loaded: file_helper
INFO - 2024-07-08 15:22:57 --> Helper loaded: form_helper
INFO - 2024-07-08 15:22:57 --> Helper loaded: my_helper
INFO - 2024-07-08 15:22:57 --> Database Driver Class Initialized
INFO - 2024-07-08 15:22:57 --> Session: Class initialized using 'files' driver.
INFO - 2024-07-08 15:22:57 --> Controller Class Initialized
INFO - 2024-07-08 15:22:59 --> Config Class Initialized
INFO - 2024-07-08 15:22:59 --> Hooks Class Initialized
DEBUG - 2024-07-08 15:22:59 --> UTF-8 Support Enabled
INFO - 2024-07-08 15:22:59 --> Utf8 Class Initialized
INFO - 2024-07-08 15:22:59 --> URI Class Initialized
INFO - 2024-07-08 15:22:59 --> Router Class Initialized
INFO - 2024-07-08 15:22:59 --> Output Class Initialized
INFO - 2024-07-08 15:22:59 --> Security Class Initialized
DEBUG - 2024-07-08 15:22:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-07-08 15:22:59 --> Input Class Initialized
INFO - 2024-07-08 15:22:59 --> Language Class Initialized
INFO - 2024-07-08 15:22:59 --> Language Class Initialized
INFO - 2024-07-08 15:22:59 --> Config Class Initialized
INFO - 2024-07-08 15:22:59 --> Loader Class Initialized
INFO - 2024-07-08 15:22:59 --> Helper loaded: url_helper
INFO - 2024-07-08 15:22:59 --> Helper loaded: file_helper
INFO - 2024-07-08 15:22:59 --> Helper loaded: form_helper
INFO - 2024-07-08 15:22:59 --> Helper loaded: my_helper
INFO - 2024-07-08 15:22:59 --> Database Driver Class Initialized
INFO - 2024-07-08 15:22:59 --> Session: Class initialized using 'files' driver.
INFO - 2024-07-08 15:22:59 --> Controller Class Initialized
ERROR - 2024-07-08 15:22:59 --> Severity: Notice --> Undefined variable: status_form /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/data_siswa/views/form.php 231
DEBUG - 2024-07-08 15:22:59 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/data_siswa/views/form.php
DEBUG - 2024-07-08 15:22:59 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-07-08 15:22:59 --> Final output sent to browser
DEBUG - 2024-07-08 15:22:59 --> Total execution time: 0.0731
INFO - 2024-07-08 15:23:07 --> Config Class Initialized
INFO - 2024-07-08 15:23:07 --> Hooks Class Initialized
DEBUG - 2024-07-08 15:23:07 --> UTF-8 Support Enabled
INFO - 2024-07-08 15:23:07 --> Utf8 Class Initialized
INFO - 2024-07-08 15:23:07 --> URI Class Initialized
INFO - 2024-07-08 15:23:07 --> Router Class Initialized
INFO - 2024-07-08 15:23:07 --> Output Class Initialized
INFO - 2024-07-08 15:23:07 --> Security Class Initialized
DEBUG - 2024-07-08 15:23:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-07-08 15:23:07 --> Input Class Initialized
INFO - 2024-07-08 15:23:07 --> Language Class Initialized
INFO - 2024-07-08 15:23:07 --> Language Class Initialized
INFO - 2024-07-08 15:23:07 --> Config Class Initialized
INFO - 2024-07-08 15:23:07 --> Loader Class Initialized
INFO - 2024-07-08 15:23:07 --> Helper loaded: url_helper
INFO - 2024-07-08 15:23:07 --> Helper loaded: file_helper
INFO - 2024-07-08 15:23:07 --> Helper loaded: form_helper
INFO - 2024-07-08 15:23:07 --> Helper loaded: my_helper
INFO - 2024-07-08 15:23:07 --> Database Driver Class Initialized
INFO - 2024-07-08 15:23:07 --> Session: Class initialized using 'files' driver.
INFO - 2024-07-08 15:23:07 --> Controller Class Initialized
DEBUG - 2024-07-08 15:23:07 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/data_siswa/views/list.php
DEBUG - 2024-07-08 15:23:07 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-07-08 15:23:07 --> Final output sent to browser
DEBUG - 2024-07-08 15:23:07 --> Total execution time: 0.0316
INFO - 2024-07-08 15:23:07 --> Config Class Initialized
INFO - 2024-07-08 15:23:07 --> Hooks Class Initialized
DEBUG - 2024-07-08 15:23:07 --> UTF-8 Support Enabled
INFO - 2024-07-08 15:23:07 --> Utf8 Class Initialized
INFO - 2024-07-08 15:23:07 --> URI Class Initialized
INFO - 2024-07-08 15:23:07 --> Router Class Initialized
INFO - 2024-07-08 15:23:07 --> Output Class Initialized
INFO - 2024-07-08 15:23:07 --> Security Class Initialized
DEBUG - 2024-07-08 15:23:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-07-08 15:23:07 --> Input Class Initialized
INFO - 2024-07-08 15:23:07 --> Language Class Initialized
ERROR - 2024-07-08 15:23:07 --> 404 Page Not Found: /index
INFO - 2024-07-08 15:23:07 --> Config Class Initialized
INFO - 2024-07-08 15:23:07 --> Hooks Class Initialized
DEBUG - 2024-07-08 15:23:07 --> UTF-8 Support Enabled
INFO - 2024-07-08 15:23:07 --> Utf8 Class Initialized
INFO - 2024-07-08 15:23:07 --> URI Class Initialized
INFO - 2024-07-08 15:23:07 --> Router Class Initialized
INFO - 2024-07-08 15:23:07 --> Output Class Initialized
INFO - 2024-07-08 15:23:07 --> Security Class Initialized
DEBUG - 2024-07-08 15:23:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-07-08 15:23:07 --> Input Class Initialized
INFO - 2024-07-08 15:23:07 --> Language Class Initialized
INFO - 2024-07-08 15:23:07 --> Language Class Initialized
INFO - 2024-07-08 15:23:07 --> Config Class Initialized
INFO - 2024-07-08 15:23:07 --> Loader Class Initialized
INFO - 2024-07-08 15:23:07 --> Helper loaded: url_helper
INFO - 2024-07-08 15:23:07 --> Helper loaded: file_helper
INFO - 2024-07-08 15:23:07 --> Helper loaded: form_helper
INFO - 2024-07-08 15:23:07 --> Helper loaded: my_helper
INFO - 2024-07-08 15:23:07 --> Database Driver Class Initialized
INFO - 2024-07-08 15:23:07 --> Session: Class initialized using 'files' driver.
INFO - 2024-07-08 15:23:07 --> Controller Class Initialized
INFO - 2024-07-08 15:24:15 --> Config Class Initialized
INFO - 2024-07-08 15:24:15 --> Hooks Class Initialized
DEBUG - 2024-07-08 15:24:15 --> UTF-8 Support Enabled
INFO - 2024-07-08 15:24:15 --> Utf8 Class Initialized
INFO - 2024-07-08 15:24:15 --> URI Class Initialized
INFO - 2024-07-08 15:24:15 --> Router Class Initialized
INFO - 2024-07-08 15:24:15 --> Output Class Initialized
INFO - 2024-07-08 15:24:15 --> Security Class Initialized
DEBUG - 2024-07-08 15:24:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-07-08 15:24:15 --> Input Class Initialized
INFO - 2024-07-08 15:24:15 --> Language Class Initialized
INFO - 2024-07-08 15:24:15 --> Language Class Initialized
INFO - 2024-07-08 15:24:15 --> Config Class Initialized
INFO - 2024-07-08 15:24:15 --> Loader Class Initialized
INFO - 2024-07-08 15:24:15 --> Helper loaded: url_helper
INFO - 2024-07-08 15:24:15 --> Helper loaded: file_helper
INFO - 2024-07-08 15:24:15 --> Helper loaded: form_helper
INFO - 2024-07-08 15:24:15 --> Helper loaded: my_helper
INFO - 2024-07-08 15:24:15 --> Database Driver Class Initialized
INFO - 2024-07-08 15:24:15 --> Session: Class initialized using 'files' driver.
INFO - 2024-07-08 15:24:15 --> Controller Class Initialized
INFO - 2024-07-08 15:24:23 --> Config Class Initialized
INFO - 2024-07-08 15:24:23 --> Hooks Class Initialized
DEBUG - 2024-07-08 15:24:23 --> UTF-8 Support Enabled
INFO - 2024-07-08 15:24:23 --> Utf8 Class Initialized
INFO - 2024-07-08 15:24:23 --> URI Class Initialized
INFO - 2024-07-08 15:24:23 --> Router Class Initialized
INFO - 2024-07-08 15:24:23 --> Output Class Initialized
INFO - 2024-07-08 15:24:23 --> Security Class Initialized
DEBUG - 2024-07-08 15:24:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-07-08 15:24:23 --> Input Class Initialized
INFO - 2024-07-08 15:24:23 --> Language Class Initialized
INFO - 2024-07-08 15:24:23 --> Language Class Initialized
INFO - 2024-07-08 15:24:23 --> Config Class Initialized
INFO - 2024-07-08 15:24:23 --> Loader Class Initialized
INFO - 2024-07-08 15:24:23 --> Helper loaded: url_helper
INFO - 2024-07-08 15:24:23 --> Helper loaded: file_helper
INFO - 2024-07-08 15:24:23 --> Helper loaded: form_helper
INFO - 2024-07-08 15:24:23 --> Helper loaded: my_helper
INFO - 2024-07-08 15:24:23 --> Database Driver Class Initialized
INFO - 2024-07-08 15:24:23 --> Session: Class initialized using 'files' driver.
INFO - 2024-07-08 15:24:23 --> Controller Class Initialized
DEBUG - 2024-07-08 15:24:23 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/data_kelas/views/list.php
DEBUG - 2024-07-08 15:24:23 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-07-08 15:24:23 --> Final output sent to browser
DEBUG - 2024-07-08 15:24:23 --> Total execution time: 0.0530
INFO - 2024-07-08 15:24:23 --> Config Class Initialized
INFO - 2024-07-08 15:24:23 --> Hooks Class Initialized
DEBUG - 2024-07-08 15:24:23 --> UTF-8 Support Enabled
INFO - 2024-07-08 15:24:23 --> Utf8 Class Initialized
INFO - 2024-07-08 15:24:23 --> URI Class Initialized
INFO - 2024-07-08 15:24:23 --> Router Class Initialized
INFO - 2024-07-08 15:24:23 --> Output Class Initialized
INFO - 2024-07-08 15:24:23 --> Security Class Initialized
DEBUG - 2024-07-08 15:24:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-07-08 15:24:23 --> Input Class Initialized
INFO - 2024-07-08 15:24:23 --> Language Class Initialized
ERROR - 2024-07-08 15:24:23 --> 404 Page Not Found: /index
INFO - 2024-07-08 15:24:23 --> Config Class Initialized
INFO - 2024-07-08 15:24:23 --> Hooks Class Initialized
DEBUG - 2024-07-08 15:24:23 --> UTF-8 Support Enabled
INFO - 2024-07-08 15:24:23 --> Utf8 Class Initialized
INFO - 2024-07-08 15:24:23 --> URI Class Initialized
INFO - 2024-07-08 15:24:23 --> Router Class Initialized
INFO - 2024-07-08 15:24:23 --> Output Class Initialized
INFO - 2024-07-08 15:24:23 --> Security Class Initialized
DEBUG - 2024-07-08 15:24:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-07-08 15:24:23 --> Input Class Initialized
INFO - 2024-07-08 15:24:23 --> Language Class Initialized
INFO - 2024-07-08 15:24:23 --> Language Class Initialized
INFO - 2024-07-08 15:24:23 --> Config Class Initialized
INFO - 2024-07-08 15:24:23 --> Loader Class Initialized
INFO - 2024-07-08 15:24:23 --> Helper loaded: url_helper
INFO - 2024-07-08 15:24:23 --> Helper loaded: file_helper
INFO - 2024-07-08 15:24:23 --> Helper loaded: form_helper
INFO - 2024-07-08 15:24:23 --> Helper loaded: my_helper
INFO - 2024-07-08 15:24:23 --> Database Driver Class Initialized
INFO - 2024-07-08 15:24:23 --> Session: Class initialized using 'files' driver.
INFO - 2024-07-08 15:24:23 --> Controller Class Initialized
INFO - 2024-07-08 15:24:25 --> Config Class Initialized
INFO - 2024-07-08 15:24:25 --> Hooks Class Initialized
DEBUG - 2024-07-08 15:24:25 --> UTF-8 Support Enabled
INFO - 2024-07-08 15:24:25 --> Utf8 Class Initialized
INFO - 2024-07-08 15:24:25 --> URI Class Initialized
INFO - 2024-07-08 15:24:25 --> Router Class Initialized
INFO - 2024-07-08 15:24:25 --> Output Class Initialized
INFO - 2024-07-08 15:24:25 --> Security Class Initialized
DEBUG - 2024-07-08 15:24:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-07-08 15:24:25 --> Input Class Initialized
INFO - 2024-07-08 15:24:25 --> Language Class Initialized
INFO - 2024-07-08 15:24:25 --> Language Class Initialized
INFO - 2024-07-08 15:24:25 --> Config Class Initialized
INFO - 2024-07-08 15:24:25 --> Loader Class Initialized
INFO - 2024-07-08 15:24:25 --> Helper loaded: url_helper
INFO - 2024-07-08 15:24:25 --> Helper loaded: file_helper
INFO - 2024-07-08 15:24:25 --> Helper loaded: form_helper
INFO - 2024-07-08 15:24:25 --> Helper loaded: my_helper
INFO - 2024-07-08 15:24:25 --> Database Driver Class Initialized
INFO - 2024-07-08 15:24:25 --> Session: Class initialized using 'files' driver.
INFO - 2024-07-08 15:24:25 --> Controller Class Initialized
INFO - 2024-07-08 15:24:25 --> Final output sent to browser
DEBUG - 2024-07-08 15:24:25 --> Total execution time: 0.0343
INFO - 2024-07-08 15:24:41 --> Config Class Initialized
INFO - 2024-07-08 15:24:41 --> Hooks Class Initialized
DEBUG - 2024-07-08 15:24:41 --> UTF-8 Support Enabled
INFO - 2024-07-08 15:24:41 --> Utf8 Class Initialized
INFO - 2024-07-08 15:24:41 --> URI Class Initialized
INFO - 2024-07-08 15:24:41 --> Router Class Initialized
INFO - 2024-07-08 15:24:41 --> Output Class Initialized
INFO - 2024-07-08 15:24:41 --> Security Class Initialized
DEBUG - 2024-07-08 15:24:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-07-08 15:24:41 --> Input Class Initialized
INFO - 2024-07-08 15:24:41 --> Language Class Initialized
INFO - 2024-07-08 15:24:41 --> Language Class Initialized
INFO - 2024-07-08 15:24:41 --> Config Class Initialized
INFO - 2024-07-08 15:24:41 --> Loader Class Initialized
INFO - 2024-07-08 15:24:41 --> Helper loaded: url_helper
INFO - 2024-07-08 15:24:41 --> Helper loaded: file_helper
INFO - 2024-07-08 15:24:41 --> Helper loaded: form_helper
INFO - 2024-07-08 15:24:41 --> Helper loaded: my_helper
INFO - 2024-07-08 15:24:41 --> Database Driver Class Initialized
INFO - 2024-07-08 15:24:41 --> Session: Class initialized using 'files' driver.
INFO - 2024-07-08 15:24:41 --> Controller Class Initialized
INFO - 2024-07-08 15:24:41 --> Final output sent to browser
DEBUG - 2024-07-08 15:24:41 --> Total execution time: 0.0416
INFO - 2024-07-08 15:24:41 --> Config Class Initialized
INFO - 2024-07-08 15:24:41 --> Hooks Class Initialized
DEBUG - 2024-07-08 15:24:41 --> UTF-8 Support Enabled
INFO - 2024-07-08 15:24:41 --> Utf8 Class Initialized
INFO - 2024-07-08 15:24:41 --> URI Class Initialized
INFO - 2024-07-08 15:24:41 --> Router Class Initialized
INFO - 2024-07-08 15:24:41 --> Output Class Initialized
INFO - 2024-07-08 15:24:41 --> Security Class Initialized
DEBUG - 2024-07-08 15:24:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-07-08 15:24:41 --> Input Class Initialized
INFO - 2024-07-08 15:24:41 --> Language Class Initialized
ERROR - 2024-07-08 15:24:41 --> 404 Page Not Found: /index
INFO - 2024-07-08 15:24:41 --> Config Class Initialized
INFO - 2024-07-08 15:24:41 --> Hooks Class Initialized
DEBUG - 2024-07-08 15:24:41 --> UTF-8 Support Enabled
INFO - 2024-07-08 15:24:41 --> Utf8 Class Initialized
INFO - 2024-07-08 15:24:41 --> URI Class Initialized
INFO - 2024-07-08 15:24:41 --> Router Class Initialized
INFO - 2024-07-08 15:24:41 --> Output Class Initialized
INFO - 2024-07-08 15:24:41 --> Security Class Initialized
DEBUG - 2024-07-08 15:24:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-07-08 15:24:41 --> Input Class Initialized
INFO - 2024-07-08 15:24:41 --> Language Class Initialized
INFO - 2024-07-08 15:24:41 --> Language Class Initialized
INFO - 2024-07-08 15:24:41 --> Config Class Initialized
INFO - 2024-07-08 15:24:41 --> Loader Class Initialized
INFO - 2024-07-08 15:24:41 --> Helper loaded: url_helper
INFO - 2024-07-08 15:24:41 --> Helper loaded: file_helper
INFO - 2024-07-08 15:24:41 --> Helper loaded: form_helper
INFO - 2024-07-08 15:24:41 --> Helper loaded: my_helper
INFO - 2024-07-08 15:24:41 --> Database Driver Class Initialized
INFO - 2024-07-08 15:24:41 --> Session: Class initialized using 'files' driver.
INFO - 2024-07-08 15:24:41 --> Controller Class Initialized
INFO - 2024-07-08 15:24:43 --> Config Class Initialized
INFO - 2024-07-08 15:24:43 --> Hooks Class Initialized
DEBUG - 2024-07-08 15:24:43 --> UTF-8 Support Enabled
INFO - 2024-07-08 15:24:43 --> Utf8 Class Initialized
INFO - 2024-07-08 15:24:43 --> URI Class Initialized
INFO - 2024-07-08 15:24:43 --> Router Class Initialized
INFO - 2024-07-08 15:24:43 --> Output Class Initialized
INFO - 2024-07-08 15:24:43 --> Security Class Initialized
DEBUG - 2024-07-08 15:24:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-07-08 15:24:43 --> Input Class Initialized
INFO - 2024-07-08 15:24:43 --> Language Class Initialized
INFO - 2024-07-08 15:24:43 --> Language Class Initialized
INFO - 2024-07-08 15:24:43 --> Config Class Initialized
INFO - 2024-07-08 15:24:43 --> Loader Class Initialized
INFO - 2024-07-08 15:24:43 --> Helper loaded: url_helper
INFO - 2024-07-08 15:24:43 --> Helper loaded: file_helper
INFO - 2024-07-08 15:24:43 --> Helper loaded: form_helper
INFO - 2024-07-08 15:24:43 --> Helper loaded: my_helper
INFO - 2024-07-08 15:24:43 --> Database Driver Class Initialized
INFO - 2024-07-08 15:24:43 --> Session: Class initialized using 'files' driver.
INFO - 2024-07-08 15:24:43 --> Controller Class Initialized
INFO - 2024-07-08 15:24:43 --> Final output sent to browser
DEBUG - 2024-07-08 15:24:43 --> Total execution time: 0.0701
INFO - 2024-07-08 15:24:51 --> Config Class Initialized
INFO - 2024-07-08 15:24:51 --> Hooks Class Initialized
DEBUG - 2024-07-08 15:24:51 --> UTF-8 Support Enabled
INFO - 2024-07-08 15:24:51 --> Utf8 Class Initialized
INFO - 2024-07-08 15:24:51 --> URI Class Initialized
INFO - 2024-07-08 15:24:51 --> Router Class Initialized
INFO - 2024-07-08 15:24:51 --> Output Class Initialized
INFO - 2024-07-08 15:24:51 --> Security Class Initialized
DEBUG - 2024-07-08 15:24:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-07-08 15:24:51 --> Input Class Initialized
INFO - 2024-07-08 15:24:51 --> Language Class Initialized
INFO - 2024-07-08 15:24:51 --> Language Class Initialized
INFO - 2024-07-08 15:24:51 --> Config Class Initialized
INFO - 2024-07-08 15:24:51 --> Loader Class Initialized
INFO - 2024-07-08 15:24:51 --> Helper loaded: url_helper
INFO - 2024-07-08 15:24:51 --> Helper loaded: file_helper
INFO - 2024-07-08 15:24:51 --> Helper loaded: form_helper
INFO - 2024-07-08 15:24:51 --> Helper loaded: my_helper
INFO - 2024-07-08 15:24:51 --> Database Driver Class Initialized
INFO - 2024-07-08 15:24:51 --> Session: Class initialized using 'files' driver.
INFO - 2024-07-08 15:24:51 --> Controller Class Initialized
INFO - 2024-07-08 15:24:51 --> Final output sent to browser
DEBUG - 2024-07-08 15:24:51 --> Total execution time: 0.0321
INFO - 2024-07-08 15:24:52 --> Config Class Initialized
INFO - 2024-07-08 15:24:52 --> Hooks Class Initialized
DEBUG - 2024-07-08 15:24:52 --> UTF-8 Support Enabled
INFO - 2024-07-08 15:24:52 --> Utf8 Class Initialized
INFO - 2024-07-08 15:24:52 --> URI Class Initialized
INFO - 2024-07-08 15:24:52 --> Router Class Initialized
INFO - 2024-07-08 15:24:52 --> Output Class Initialized
INFO - 2024-07-08 15:24:52 --> Security Class Initialized
DEBUG - 2024-07-08 15:24:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-07-08 15:24:52 --> Input Class Initialized
INFO - 2024-07-08 15:24:52 --> Language Class Initialized
ERROR - 2024-07-08 15:24:52 --> 404 Page Not Found: /index
INFO - 2024-07-08 15:24:52 --> Config Class Initialized
INFO - 2024-07-08 15:24:52 --> Hooks Class Initialized
DEBUG - 2024-07-08 15:24:52 --> UTF-8 Support Enabled
INFO - 2024-07-08 15:24:52 --> Utf8 Class Initialized
INFO - 2024-07-08 15:24:52 --> URI Class Initialized
INFO - 2024-07-08 15:24:52 --> Router Class Initialized
INFO - 2024-07-08 15:24:52 --> Output Class Initialized
INFO - 2024-07-08 15:24:52 --> Security Class Initialized
DEBUG - 2024-07-08 15:24:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-07-08 15:24:52 --> Input Class Initialized
INFO - 2024-07-08 15:24:52 --> Language Class Initialized
INFO - 2024-07-08 15:24:52 --> Language Class Initialized
INFO - 2024-07-08 15:24:52 --> Config Class Initialized
INFO - 2024-07-08 15:24:52 --> Loader Class Initialized
INFO - 2024-07-08 15:24:52 --> Helper loaded: url_helper
INFO - 2024-07-08 15:24:52 --> Helper loaded: file_helper
INFO - 2024-07-08 15:24:52 --> Helper loaded: form_helper
INFO - 2024-07-08 15:24:52 --> Helper loaded: my_helper
INFO - 2024-07-08 15:24:52 --> Database Driver Class Initialized
INFO - 2024-07-08 15:24:52 --> Session: Class initialized using 'files' driver.
INFO - 2024-07-08 15:24:52 --> Controller Class Initialized
INFO - 2024-07-08 15:24:57 --> Config Class Initialized
INFO - 2024-07-08 15:24:57 --> Hooks Class Initialized
DEBUG - 2024-07-08 15:24:57 --> UTF-8 Support Enabled
INFO - 2024-07-08 15:24:57 --> Utf8 Class Initialized
INFO - 2024-07-08 15:24:57 --> URI Class Initialized
INFO - 2024-07-08 15:24:57 --> Router Class Initialized
INFO - 2024-07-08 15:24:57 --> Output Class Initialized
INFO - 2024-07-08 15:24:57 --> Security Class Initialized
DEBUG - 2024-07-08 15:24:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-07-08 15:24:57 --> Input Class Initialized
INFO - 2024-07-08 15:24:57 --> Language Class Initialized
INFO - 2024-07-08 15:24:57 --> Language Class Initialized
INFO - 2024-07-08 15:24:57 --> Config Class Initialized
INFO - 2024-07-08 15:24:57 --> Loader Class Initialized
INFO - 2024-07-08 15:24:57 --> Helper loaded: url_helper
INFO - 2024-07-08 15:24:57 --> Helper loaded: file_helper
INFO - 2024-07-08 15:24:57 --> Helper loaded: form_helper
INFO - 2024-07-08 15:24:57 --> Helper loaded: my_helper
INFO - 2024-07-08 15:24:57 --> Database Driver Class Initialized
INFO - 2024-07-08 15:24:57 --> Session: Class initialized using 'files' driver.
INFO - 2024-07-08 15:24:57 --> Controller Class Initialized
DEBUG - 2024-07-08 15:24:57 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/set_kelas/views/list.php
DEBUG - 2024-07-08 15:24:57 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-07-08 15:24:57 --> Final output sent to browser
DEBUG - 2024-07-08 15:24:57 --> Total execution time: 0.0466
INFO - 2024-07-08 15:25:03 --> Config Class Initialized
INFO - 2024-07-08 15:25:03 --> Hooks Class Initialized
DEBUG - 2024-07-08 15:25:03 --> UTF-8 Support Enabled
INFO - 2024-07-08 15:25:03 --> Utf8 Class Initialized
INFO - 2024-07-08 15:25:03 --> URI Class Initialized
INFO - 2024-07-08 15:25:03 --> Router Class Initialized
INFO - 2024-07-08 15:25:03 --> Output Class Initialized
INFO - 2024-07-08 15:25:03 --> Security Class Initialized
DEBUG - 2024-07-08 15:25:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-07-08 15:25:03 --> Input Class Initialized
INFO - 2024-07-08 15:25:03 --> Language Class Initialized
INFO - 2024-07-08 15:25:03 --> Language Class Initialized
INFO - 2024-07-08 15:25:03 --> Config Class Initialized
INFO - 2024-07-08 15:25:03 --> Loader Class Initialized
INFO - 2024-07-08 15:25:03 --> Helper loaded: url_helper
INFO - 2024-07-08 15:25:03 --> Helper loaded: file_helper
INFO - 2024-07-08 15:25:03 --> Helper loaded: form_helper
INFO - 2024-07-08 15:25:03 --> Helper loaded: my_helper
INFO - 2024-07-08 15:25:03 --> Database Driver Class Initialized
INFO - 2024-07-08 15:25:03 --> Session: Class initialized using 'files' driver.
INFO - 2024-07-08 15:25:03 --> Controller Class Initialized
DEBUG - 2024-07-08 15:25:03 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/data_siswa/views/list.php
DEBUG - 2024-07-08 15:25:03 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-07-08 15:25:03 --> Final output sent to browser
DEBUG - 2024-07-08 15:25:03 --> Total execution time: 0.0701
INFO - 2024-07-08 15:25:03 --> Config Class Initialized
INFO - 2024-07-08 15:25:03 --> Hooks Class Initialized
DEBUG - 2024-07-08 15:25:03 --> UTF-8 Support Enabled
INFO - 2024-07-08 15:25:03 --> Utf8 Class Initialized
INFO - 2024-07-08 15:25:03 --> URI Class Initialized
INFO - 2024-07-08 15:25:03 --> Router Class Initialized
INFO - 2024-07-08 15:25:03 --> Output Class Initialized
INFO - 2024-07-08 15:25:03 --> Security Class Initialized
DEBUG - 2024-07-08 15:25:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-07-08 15:25:03 --> Input Class Initialized
INFO - 2024-07-08 15:25:03 --> Language Class Initialized
ERROR - 2024-07-08 15:25:03 --> 404 Page Not Found: /index
INFO - 2024-07-08 15:25:03 --> Config Class Initialized
INFO - 2024-07-08 15:25:03 --> Hooks Class Initialized
DEBUG - 2024-07-08 15:25:03 --> UTF-8 Support Enabled
INFO - 2024-07-08 15:25:03 --> Utf8 Class Initialized
INFO - 2024-07-08 15:25:03 --> URI Class Initialized
INFO - 2024-07-08 15:25:03 --> Router Class Initialized
INFO - 2024-07-08 15:25:03 --> Output Class Initialized
INFO - 2024-07-08 15:25:03 --> Security Class Initialized
DEBUG - 2024-07-08 15:25:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-07-08 15:25:03 --> Input Class Initialized
INFO - 2024-07-08 15:25:03 --> Language Class Initialized
INFO - 2024-07-08 15:25:03 --> Language Class Initialized
INFO - 2024-07-08 15:25:03 --> Config Class Initialized
INFO - 2024-07-08 15:25:03 --> Loader Class Initialized
INFO - 2024-07-08 15:25:03 --> Helper loaded: url_helper
INFO - 2024-07-08 15:25:03 --> Helper loaded: file_helper
INFO - 2024-07-08 15:25:03 --> Helper loaded: form_helper
INFO - 2024-07-08 15:25:03 --> Helper loaded: my_helper
INFO - 2024-07-08 15:25:03 --> Database Driver Class Initialized
INFO - 2024-07-08 15:25:03 --> Session: Class initialized using 'files' driver.
INFO - 2024-07-08 15:25:03 --> Controller Class Initialized
INFO - 2024-07-08 15:25:05 --> Config Class Initialized
INFO - 2024-07-08 15:25:05 --> Hooks Class Initialized
DEBUG - 2024-07-08 15:25:05 --> UTF-8 Support Enabled
INFO - 2024-07-08 15:25:05 --> Utf8 Class Initialized
INFO - 2024-07-08 15:25:05 --> URI Class Initialized
INFO - 2024-07-08 15:25:05 --> Router Class Initialized
INFO - 2024-07-08 15:25:05 --> Output Class Initialized
INFO - 2024-07-08 15:25:05 --> Security Class Initialized
DEBUG - 2024-07-08 15:25:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-07-08 15:25:05 --> Input Class Initialized
INFO - 2024-07-08 15:25:05 --> Language Class Initialized
INFO - 2024-07-08 15:25:06 --> Language Class Initialized
INFO - 2024-07-08 15:25:06 --> Config Class Initialized
INFO - 2024-07-08 15:25:06 --> Loader Class Initialized
INFO - 2024-07-08 15:25:06 --> Helper loaded: url_helper
INFO - 2024-07-08 15:25:06 --> Helper loaded: file_helper
INFO - 2024-07-08 15:25:06 --> Helper loaded: form_helper
INFO - 2024-07-08 15:25:06 --> Helper loaded: my_helper
INFO - 2024-07-08 15:25:06 --> Database Driver Class Initialized
INFO - 2024-07-08 15:25:06 --> Session: Class initialized using 'files' driver.
INFO - 2024-07-08 15:25:06 --> Controller Class Initialized
DEBUG - 2024-07-08 15:25:06 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/data_siswa/views/list.php
DEBUG - 2024-07-08 15:25:06 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-07-08 15:25:06 --> Final output sent to browser
DEBUG - 2024-07-08 15:25:06 --> Total execution time: 0.0826
INFO - 2024-07-08 15:25:06 --> Config Class Initialized
INFO - 2024-07-08 15:25:06 --> Hooks Class Initialized
DEBUG - 2024-07-08 15:25:06 --> UTF-8 Support Enabled
INFO - 2024-07-08 15:25:06 --> Utf8 Class Initialized
INFO - 2024-07-08 15:25:06 --> URI Class Initialized
INFO - 2024-07-08 15:25:06 --> Router Class Initialized
INFO - 2024-07-08 15:25:06 --> Output Class Initialized
INFO - 2024-07-08 15:25:06 --> Security Class Initialized
DEBUG - 2024-07-08 15:25:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-07-08 15:25:06 --> Input Class Initialized
INFO - 2024-07-08 15:25:06 --> Language Class Initialized
ERROR - 2024-07-08 15:25:06 --> 404 Page Not Found: /index
INFO - 2024-07-08 15:25:06 --> Config Class Initialized
INFO - 2024-07-08 15:25:06 --> Hooks Class Initialized
DEBUG - 2024-07-08 15:25:06 --> UTF-8 Support Enabled
INFO - 2024-07-08 15:25:06 --> Utf8 Class Initialized
INFO - 2024-07-08 15:25:06 --> URI Class Initialized
INFO - 2024-07-08 15:25:06 --> Router Class Initialized
INFO - 2024-07-08 15:25:06 --> Output Class Initialized
INFO - 2024-07-08 15:25:06 --> Security Class Initialized
DEBUG - 2024-07-08 15:25:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-07-08 15:25:06 --> Input Class Initialized
INFO - 2024-07-08 15:25:06 --> Language Class Initialized
INFO - 2024-07-08 15:25:06 --> Language Class Initialized
INFO - 2024-07-08 15:25:06 --> Config Class Initialized
INFO - 2024-07-08 15:25:06 --> Loader Class Initialized
INFO - 2024-07-08 15:25:06 --> Helper loaded: url_helper
INFO - 2024-07-08 15:25:06 --> Helper loaded: file_helper
INFO - 2024-07-08 15:25:06 --> Helper loaded: form_helper
INFO - 2024-07-08 15:25:06 --> Helper loaded: my_helper
INFO - 2024-07-08 15:25:06 --> Database Driver Class Initialized
INFO - 2024-07-08 15:25:06 --> Session: Class initialized using 'files' driver.
INFO - 2024-07-08 15:25:06 --> Controller Class Initialized
INFO - 2024-07-08 15:25:07 --> Config Class Initialized
INFO - 2024-07-08 15:25:07 --> Hooks Class Initialized
DEBUG - 2024-07-08 15:25:07 --> UTF-8 Support Enabled
INFO - 2024-07-08 15:25:07 --> Utf8 Class Initialized
INFO - 2024-07-08 15:25:07 --> URI Class Initialized
INFO - 2024-07-08 15:25:07 --> Router Class Initialized
INFO - 2024-07-08 15:25:07 --> Output Class Initialized
INFO - 2024-07-08 15:25:07 --> Security Class Initialized
DEBUG - 2024-07-08 15:25:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-07-08 15:25:07 --> Input Class Initialized
INFO - 2024-07-08 15:25:07 --> Language Class Initialized
INFO - 2024-07-08 15:25:07 --> Language Class Initialized
INFO - 2024-07-08 15:25:07 --> Config Class Initialized
INFO - 2024-07-08 15:25:07 --> Loader Class Initialized
INFO - 2024-07-08 15:25:07 --> Helper loaded: url_helper
INFO - 2024-07-08 15:25:07 --> Helper loaded: file_helper
INFO - 2024-07-08 15:25:07 --> Helper loaded: form_helper
INFO - 2024-07-08 15:25:07 --> Helper loaded: my_helper
INFO - 2024-07-08 15:25:07 --> Database Driver Class Initialized
INFO - 2024-07-08 15:25:07 --> Session: Class initialized using 'files' driver.
INFO - 2024-07-08 15:25:07 --> Controller Class Initialized
DEBUG - 2024-07-08 15:25:07 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/data_kelas/views/list.php
DEBUG - 2024-07-08 15:25:07 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-07-08 15:25:07 --> Final output sent to browser
DEBUG - 2024-07-08 15:25:07 --> Total execution time: 0.0344
INFO - 2024-07-08 15:25:07 --> Config Class Initialized
INFO - 2024-07-08 15:25:07 --> Hooks Class Initialized
DEBUG - 2024-07-08 15:25:07 --> UTF-8 Support Enabled
INFO - 2024-07-08 15:25:07 --> Utf8 Class Initialized
INFO - 2024-07-08 15:25:07 --> URI Class Initialized
INFO - 2024-07-08 15:25:07 --> Router Class Initialized
INFO - 2024-07-08 15:25:07 --> Output Class Initialized
INFO - 2024-07-08 15:25:07 --> Security Class Initialized
DEBUG - 2024-07-08 15:25:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-07-08 15:25:07 --> Input Class Initialized
INFO - 2024-07-08 15:25:07 --> Language Class Initialized
ERROR - 2024-07-08 15:25:07 --> 404 Page Not Found: /index
INFO - 2024-07-08 15:25:07 --> Config Class Initialized
INFO - 2024-07-08 15:25:07 --> Hooks Class Initialized
DEBUG - 2024-07-08 15:25:07 --> UTF-8 Support Enabled
INFO - 2024-07-08 15:25:07 --> Utf8 Class Initialized
INFO - 2024-07-08 15:25:07 --> URI Class Initialized
INFO - 2024-07-08 15:25:07 --> Router Class Initialized
INFO - 2024-07-08 15:25:07 --> Output Class Initialized
INFO - 2024-07-08 15:25:07 --> Security Class Initialized
DEBUG - 2024-07-08 15:25:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-07-08 15:25:07 --> Input Class Initialized
INFO - 2024-07-08 15:25:07 --> Language Class Initialized
INFO - 2024-07-08 15:25:07 --> Language Class Initialized
INFO - 2024-07-08 15:25:07 --> Config Class Initialized
INFO - 2024-07-08 15:25:07 --> Loader Class Initialized
INFO - 2024-07-08 15:25:07 --> Helper loaded: url_helper
INFO - 2024-07-08 15:25:07 --> Helper loaded: file_helper
INFO - 2024-07-08 15:25:08 --> Helper loaded: form_helper
INFO - 2024-07-08 15:25:08 --> Helper loaded: my_helper
INFO - 2024-07-08 15:25:08 --> Database Driver Class Initialized
INFO - 2024-07-08 15:25:08 --> Session: Class initialized using 'files' driver.
INFO - 2024-07-08 15:25:08 --> Controller Class Initialized
INFO - 2024-07-08 15:25:09 --> Config Class Initialized
INFO - 2024-07-08 15:25:09 --> Hooks Class Initialized
DEBUG - 2024-07-08 15:25:09 --> UTF-8 Support Enabled
INFO - 2024-07-08 15:25:09 --> Utf8 Class Initialized
INFO - 2024-07-08 15:25:09 --> URI Class Initialized
INFO - 2024-07-08 15:25:09 --> Router Class Initialized
INFO - 2024-07-08 15:25:09 --> Output Class Initialized
INFO - 2024-07-08 15:25:09 --> Security Class Initialized
DEBUG - 2024-07-08 15:25:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-07-08 15:25:09 --> Input Class Initialized
INFO - 2024-07-08 15:25:09 --> Language Class Initialized
INFO - 2024-07-08 15:25:09 --> Language Class Initialized
INFO - 2024-07-08 15:25:09 --> Config Class Initialized
INFO - 2024-07-08 15:25:09 --> Loader Class Initialized
INFO - 2024-07-08 15:25:09 --> Helper loaded: url_helper
INFO - 2024-07-08 15:25:09 --> Helper loaded: file_helper
INFO - 2024-07-08 15:25:09 --> Helper loaded: form_helper
INFO - 2024-07-08 15:25:09 --> Helper loaded: my_helper
INFO - 2024-07-08 15:25:09 --> Database Driver Class Initialized
INFO - 2024-07-08 15:25:09 --> Session: Class initialized using 'files' driver.
INFO - 2024-07-08 15:25:09 --> Controller Class Initialized
INFO - 2024-07-08 15:25:09 --> Final output sent to browser
DEBUG - 2024-07-08 15:25:09 --> Total execution time: 0.0441
INFO - 2024-07-08 15:25:15 --> Config Class Initialized
INFO - 2024-07-08 15:25:15 --> Hooks Class Initialized
DEBUG - 2024-07-08 15:25:15 --> UTF-8 Support Enabled
INFO - 2024-07-08 15:25:15 --> Utf8 Class Initialized
INFO - 2024-07-08 15:25:15 --> URI Class Initialized
INFO - 2024-07-08 15:25:15 --> Router Class Initialized
INFO - 2024-07-08 15:25:15 --> Output Class Initialized
INFO - 2024-07-08 15:25:15 --> Security Class Initialized
DEBUG - 2024-07-08 15:25:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-07-08 15:25:15 --> Input Class Initialized
INFO - 2024-07-08 15:25:15 --> Language Class Initialized
INFO - 2024-07-08 15:25:15 --> Language Class Initialized
INFO - 2024-07-08 15:25:15 --> Config Class Initialized
INFO - 2024-07-08 15:25:15 --> Loader Class Initialized
INFO - 2024-07-08 15:25:15 --> Helper loaded: url_helper
INFO - 2024-07-08 15:25:15 --> Helper loaded: file_helper
INFO - 2024-07-08 15:25:15 --> Helper loaded: form_helper
INFO - 2024-07-08 15:25:15 --> Helper loaded: my_helper
INFO - 2024-07-08 15:25:15 --> Database Driver Class Initialized
INFO - 2024-07-08 15:25:15 --> Session: Class initialized using 'files' driver.
INFO - 2024-07-08 15:25:15 --> Controller Class Initialized
INFO - 2024-07-08 15:25:15 --> Final output sent to browser
DEBUG - 2024-07-08 15:25:15 --> Total execution time: 0.1831
INFO - 2024-07-08 15:25:15 --> Config Class Initialized
INFO - 2024-07-08 15:25:15 --> Hooks Class Initialized
DEBUG - 2024-07-08 15:25:15 --> UTF-8 Support Enabled
INFO - 2024-07-08 15:25:15 --> Utf8 Class Initialized
INFO - 2024-07-08 15:25:15 --> URI Class Initialized
INFO - 2024-07-08 15:25:15 --> Router Class Initialized
INFO - 2024-07-08 15:25:15 --> Output Class Initialized
INFO - 2024-07-08 15:25:15 --> Security Class Initialized
DEBUG - 2024-07-08 15:25:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-07-08 15:25:15 --> Input Class Initialized
INFO - 2024-07-08 15:25:15 --> Language Class Initialized
ERROR - 2024-07-08 15:25:15 --> 404 Page Not Found: /index
INFO - 2024-07-08 15:25:15 --> Config Class Initialized
INFO - 2024-07-08 15:25:15 --> Hooks Class Initialized
DEBUG - 2024-07-08 15:25:15 --> UTF-8 Support Enabled
INFO - 2024-07-08 15:25:15 --> Utf8 Class Initialized
INFO - 2024-07-08 15:25:15 --> URI Class Initialized
INFO - 2024-07-08 15:25:15 --> Router Class Initialized
INFO - 2024-07-08 15:25:15 --> Output Class Initialized
INFO - 2024-07-08 15:25:15 --> Security Class Initialized
DEBUG - 2024-07-08 15:25:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-07-08 15:25:15 --> Input Class Initialized
INFO - 2024-07-08 15:25:15 --> Language Class Initialized
INFO - 2024-07-08 15:25:15 --> Language Class Initialized
INFO - 2024-07-08 15:25:15 --> Config Class Initialized
INFO - 2024-07-08 15:25:15 --> Loader Class Initialized
INFO - 2024-07-08 15:25:15 --> Helper loaded: url_helper
INFO - 2024-07-08 15:25:15 --> Helper loaded: file_helper
INFO - 2024-07-08 15:25:15 --> Helper loaded: form_helper
INFO - 2024-07-08 15:25:15 --> Helper loaded: my_helper
INFO - 2024-07-08 15:25:15 --> Database Driver Class Initialized
INFO - 2024-07-08 15:25:15 --> Session: Class initialized using 'files' driver.
INFO - 2024-07-08 15:25:15 --> Controller Class Initialized
INFO - 2024-07-08 15:25:18 --> Config Class Initialized
INFO - 2024-07-08 15:25:18 --> Hooks Class Initialized
DEBUG - 2024-07-08 15:25:18 --> UTF-8 Support Enabled
INFO - 2024-07-08 15:25:18 --> Utf8 Class Initialized
INFO - 2024-07-08 15:25:18 --> URI Class Initialized
INFO - 2024-07-08 15:25:18 --> Router Class Initialized
INFO - 2024-07-08 15:25:18 --> Output Class Initialized
INFO - 2024-07-08 15:25:18 --> Security Class Initialized
DEBUG - 2024-07-08 15:25:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-07-08 15:25:18 --> Input Class Initialized
INFO - 2024-07-08 15:25:18 --> Language Class Initialized
INFO - 2024-07-08 15:25:18 --> Language Class Initialized
INFO - 2024-07-08 15:25:18 --> Config Class Initialized
INFO - 2024-07-08 15:25:18 --> Loader Class Initialized
INFO - 2024-07-08 15:25:18 --> Helper loaded: url_helper
INFO - 2024-07-08 15:25:18 --> Helper loaded: file_helper
INFO - 2024-07-08 15:25:18 --> Helper loaded: form_helper
INFO - 2024-07-08 15:25:18 --> Helper loaded: my_helper
INFO - 2024-07-08 15:25:18 --> Database Driver Class Initialized
INFO - 2024-07-08 15:25:18 --> Session: Class initialized using 'files' driver.
INFO - 2024-07-08 15:25:18 --> Controller Class Initialized
DEBUG - 2024-07-08 15:25:18 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/data_kelas/views/list.php
DEBUG - 2024-07-08 15:25:18 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-07-08 15:25:18 --> Final output sent to browser
DEBUG - 2024-07-08 15:25:18 --> Total execution time: 0.0383
INFO - 2024-07-08 15:25:18 --> Config Class Initialized
INFO - 2024-07-08 15:25:18 --> Hooks Class Initialized
DEBUG - 2024-07-08 15:25:18 --> UTF-8 Support Enabled
INFO - 2024-07-08 15:25:18 --> Utf8 Class Initialized
INFO - 2024-07-08 15:25:18 --> URI Class Initialized
INFO - 2024-07-08 15:25:18 --> Router Class Initialized
INFO - 2024-07-08 15:25:18 --> Output Class Initialized
INFO - 2024-07-08 15:25:18 --> Security Class Initialized
DEBUG - 2024-07-08 15:25:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-07-08 15:25:18 --> Input Class Initialized
INFO - 2024-07-08 15:25:18 --> Language Class Initialized
ERROR - 2024-07-08 15:25:18 --> 404 Page Not Found: /index
INFO - 2024-07-08 15:25:18 --> Config Class Initialized
INFO - 2024-07-08 15:25:18 --> Hooks Class Initialized
DEBUG - 2024-07-08 15:25:18 --> UTF-8 Support Enabled
INFO - 2024-07-08 15:25:18 --> Utf8 Class Initialized
INFO - 2024-07-08 15:25:18 --> URI Class Initialized
INFO - 2024-07-08 15:25:18 --> Router Class Initialized
INFO - 2024-07-08 15:25:18 --> Output Class Initialized
INFO - 2024-07-08 15:25:18 --> Security Class Initialized
DEBUG - 2024-07-08 15:25:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-07-08 15:25:18 --> Input Class Initialized
INFO - 2024-07-08 15:25:18 --> Language Class Initialized
INFO - 2024-07-08 15:25:18 --> Language Class Initialized
INFO - 2024-07-08 15:25:18 --> Config Class Initialized
INFO - 2024-07-08 15:25:18 --> Loader Class Initialized
INFO - 2024-07-08 15:25:18 --> Helper loaded: url_helper
INFO - 2024-07-08 15:25:18 --> Helper loaded: file_helper
INFO - 2024-07-08 15:25:18 --> Helper loaded: form_helper
INFO - 2024-07-08 15:25:18 --> Helper loaded: my_helper
INFO - 2024-07-08 15:25:18 --> Database Driver Class Initialized
INFO - 2024-07-08 15:25:18 --> Session: Class initialized using 'files' driver.
INFO - 2024-07-08 15:25:18 --> Controller Class Initialized
INFO - 2024-07-08 15:25:21 --> Config Class Initialized
INFO - 2024-07-08 15:25:21 --> Hooks Class Initialized
DEBUG - 2024-07-08 15:25:21 --> UTF-8 Support Enabled
INFO - 2024-07-08 15:25:21 --> Utf8 Class Initialized
INFO - 2024-07-08 15:25:21 --> URI Class Initialized
INFO - 2024-07-08 15:25:21 --> Router Class Initialized
INFO - 2024-07-08 15:25:21 --> Output Class Initialized
INFO - 2024-07-08 15:25:21 --> Security Class Initialized
DEBUG - 2024-07-08 15:25:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-07-08 15:25:21 --> Input Class Initialized
INFO - 2024-07-08 15:25:21 --> Language Class Initialized
INFO - 2024-07-08 15:25:21 --> Language Class Initialized
INFO - 2024-07-08 15:25:21 --> Config Class Initialized
INFO - 2024-07-08 15:25:21 --> Loader Class Initialized
INFO - 2024-07-08 15:25:21 --> Helper loaded: url_helper
INFO - 2024-07-08 15:25:21 --> Helper loaded: file_helper
INFO - 2024-07-08 15:25:21 --> Helper loaded: form_helper
INFO - 2024-07-08 15:25:21 --> Helper loaded: my_helper
INFO - 2024-07-08 15:25:21 --> Database Driver Class Initialized
INFO - 2024-07-08 15:25:21 --> Session: Class initialized using 'files' driver.
INFO - 2024-07-08 15:25:21 --> Controller Class Initialized
DEBUG - 2024-07-08 15:25:21 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/data_projek/views/list.php
DEBUG - 2024-07-08 15:25:21 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-07-08 15:25:21 --> Final output sent to browser
DEBUG - 2024-07-08 15:25:21 --> Total execution time: 0.0412
INFO - 2024-07-08 15:25:21 --> Config Class Initialized
INFO - 2024-07-08 15:25:21 --> Hooks Class Initialized
DEBUG - 2024-07-08 15:25:21 --> UTF-8 Support Enabled
INFO - 2024-07-08 15:25:21 --> Utf8 Class Initialized
INFO - 2024-07-08 15:25:21 --> URI Class Initialized
INFO - 2024-07-08 15:25:21 --> Router Class Initialized
INFO - 2024-07-08 15:25:21 --> Output Class Initialized
INFO - 2024-07-08 15:25:21 --> Security Class Initialized
DEBUG - 2024-07-08 15:25:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-07-08 15:25:21 --> Input Class Initialized
INFO - 2024-07-08 15:25:21 --> Language Class Initialized
ERROR - 2024-07-08 15:25:21 --> 404 Page Not Found: /index
INFO - 2024-07-08 15:25:21 --> Config Class Initialized
INFO - 2024-07-08 15:25:21 --> Hooks Class Initialized
DEBUG - 2024-07-08 15:25:21 --> UTF-8 Support Enabled
INFO - 2024-07-08 15:25:21 --> Utf8 Class Initialized
INFO - 2024-07-08 15:25:21 --> URI Class Initialized
INFO - 2024-07-08 15:25:21 --> Router Class Initialized
INFO - 2024-07-08 15:25:21 --> Output Class Initialized
INFO - 2024-07-08 15:25:21 --> Security Class Initialized
DEBUG - 2024-07-08 15:25:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-07-08 15:25:21 --> Input Class Initialized
INFO - 2024-07-08 15:25:21 --> Language Class Initialized
INFO - 2024-07-08 15:25:21 --> Language Class Initialized
INFO - 2024-07-08 15:25:21 --> Config Class Initialized
INFO - 2024-07-08 15:25:21 --> Loader Class Initialized
INFO - 2024-07-08 15:25:21 --> Helper loaded: url_helper
INFO - 2024-07-08 15:25:21 --> Helper loaded: file_helper
INFO - 2024-07-08 15:25:21 --> Helper loaded: form_helper
INFO - 2024-07-08 15:25:21 --> Helper loaded: my_helper
INFO - 2024-07-08 15:25:21 --> Database Driver Class Initialized
INFO - 2024-07-08 15:25:21 --> Session: Class initialized using 'files' driver.
INFO - 2024-07-08 15:25:21 --> Controller Class Initialized
INFO - 2024-07-08 15:25:37 --> Config Class Initialized
INFO - 2024-07-08 15:25:37 --> Hooks Class Initialized
DEBUG - 2024-07-08 15:25:37 --> UTF-8 Support Enabled
INFO - 2024-07-08 15:25:37 --> Utf8 Class Initialized
INFO - 2024-07-08 15:25:37 --> URI Class Initialized
INFO - 2024-07-08 15:25:37 --> Router Class Initialized
INFO - 2024-07-08 15:25:37 --> Output Class Initialized
INFO - 2024-07-08 15:25:37 --> Security Class Initialized
DEBUG - 2024-07-08 15:25:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-07-08 15:25:37 --> Input Class Initialized
INFO - 2024-07-08 15:25:37 --> Language Class Initialized
INFO - 2024-07-08 15:25:37 --> Language Class Initialized
INFO - 2024-07-08 15:25:37 --> Config Class Initialized
INFO - 2024-07-08 15:25:37 --> Loader Class Initialized
INFO - 2024-07-08 15:25:37 --> Helper loaded: url_helper
INFO - 2024-07-08 15:25:37 --> Helper loaded: file_helper
INFO - 2024-07-08 15:25:37 --> Helper loaded: form_helper
INFO - 2024-07-08 15:25:37 --> Helper loaded: my_helper
INFO - 2024-07-08 15:25:37 --> Database Driver Class Initialized
INFO - 2024-07-08 15:25:37 --> Session: Class initialized using 'files' driver.
INFO - 2024-07-08 15:25:37 --> Controller Class Initialized
DEBUG - 2024-07-08 15:25:37 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/data_guru/views/list.php
DEBUG - 2024-07-08 15:25:37 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-07-08 15:25:37 --> Final output sent to browser
DEBUG - 2024-07-08 15:25:37 --> Total execution time: 0.0359
INFO - 2024-07-08 15:25:37 --> Config Class Initialized
INFO - 2024-07-08 15:25:37 --> Hooks Class Initialized
DEBUG - 2024-07-08 15:25:37 --> UTF-8 Support Enabled
INFO - 2024-07-08 15:25:37 --> Utf8 Class Initialized
INFO - 2024-07-08 15:25:37 --> URI Class Initialized
INFO - 2024-07-08 15:25:37 --> Router Class Initialized
INFO - 2024-07-08 15:25:37 --> Output Class Initialized
INFO - 2024-07-08 15:25:37 --> Security Class Initialized
DEBUG - 2024-07-08 15:25:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-07-08 15:25:37 --> Input Class Initialized
INFO - 2024-07-08 15:25:37 --> Language Class Initialized
ERROR - 2024-07-08 15:25:37 --> 404 Page Not Found: /index
INFO - 2024-07-08 15:25:37 --> Config Class Initialized
INFO - 2024-07-08 15:25:37 --> Hooks Class Initialized
DEBUG - 2024-07-08 15:25:37 --> UTF-8 Support Enabled
INFO - 2024-07-08 15:25:37 --> Utf8 Class Initialized
INFO - 2024-07-08 15:25:37 --> URI Class Initialized
INFO - 2024-07-08 15:25:37 --> Router Class Initialized
INFO - 2024-07-08 15:25:37 --> Output Class Initialized
INFO - 2024-07-08 15:25:37 --> Security Class Initialized
DEBUG - 2024-07-08 15:25:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-07-08 15:25:37 --> Input Class Initialized
INFO - 2024-07-08 15:25:37 --> Language Class Initialized
INFO - 2024-07-08 15:25:37 --> Language Class Initialized
INFO - 2024-07-08 15:25:37 --> Config Class Initialized
INFO - 2024-07-08 15:25:37 --> Loader Class Initialized
INFO - 2024-07-08 15:25:37 --> Helper loaded: url_helper
INFO - 2024-07-08 15:25:37 --> Helper loaded: file_helper
INFO - 2024-07-08 15:25:37 --> Helper loaded: form_helper
INFO - 2024-07-08 15:25:37 --> Helper loaded: my_helper
INFO - 2024-07-08 15:25:37 --> Database Driver Class Initialized
INFO - 2024-07-08 15:25:37 --> Session: Class initialized using 'files' driver.
INFO - 2024-07-08 15:25:37 --> Controller Class Initialized
INFO - 2024-07-08 15:25:41 --> Config Class Initialized
INFO - 2024-07-08 15:25:41 --> Hooks Class Initialized
DEBUG - 2024-07-08 15:25:41 --> UTF-8 Support Enabled
INFO - 2024-07-08 15:25:41 --> Utf8 Class Initialized
INFO - 2024-07-08 15:25:41 --> URI Class Initialized
INFO - 2024-07-08 15:25:41 --> Router Class Initialized
INFO - 2024-07-08 15:25:41 --> Output Class Initialized
INFO - 2024-07-08 15:25:41 --> Security Class Initialized
DEBUG - 2024-07-08 15:25:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-07-08 15:25:41 --> Input Class Initialized
INFO - 2024-07-08 15:25:41 --> Language Class Initialized
INFO - 2024-07-08 15:25:41 --> Language Class Initialized
INFO - 2024-07-08 15:25:41 --> Config Class Initialized
INFO - 2024-07-08 15:25:41 --> Loader Class Initialized
INFO - 2024-07-08 15:25:41 --> Helper loaded: url_helper
INFO - 2024-07-08 15:25:41 --> Helper loaded: file_helper
INFO - 2024-07-08 15:25:41 --> Helper loaded: form_helper
INFO - 2024-07-08 15:25:41 --> Helper loaded: my_helper
INFO - 2024-07-08 15:25:41 --> Database Driver Class Initialized
INFO - 2024-07-08 15:25:41 --> Session: Class initialized using 'files' driver.
INFO - 2024-07-08 15:25:41 --> Controller Class Initialized
DEBUG - 2024-07-08 15:25:41 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/data_kelas/views/list.php
DEBUG - 2024-07-08 15:25:41 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-07-08 15:25:41 --> Final output sent to browser
DEBUG - 2024-07-08 15:25:41 --> Total execution time: 0.0291
INFO - 2024-07-08 15:25:41 --> Config Class Initialized
INFO - 2024-07-08 15:25:41 --> Hooks Class Initialized
DEBUG - 2024-07-08 15:25:41 --> UTF-8 Support Enabled
INFO - 2024-07-08 15:25:41 --> Utf8 Class Initialized
INFO - 2024-07-08 15:25:41 --> URI Class Initialized
INFO - 2024-07-08 15:25:41 --> Router Class Initialized
INFO - 2024-07-08 15:25:41 --> Output Class Initialized
INFO - 2024-07-08 15:25:41 --> Security Class Initialized
DEBUG - 2024-07-08 15:25:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-07-08 15:25:41 --> Input Class Initialized
INFO - 2024-07-08 15:25:41 --> Language Class Initialized
ERROR - 2024-07-08 15:25:41 --> 404 Page Not Found: /index
INFO - 2024-07-08 15:25:41 --> Config Class Initialized
INFO - 2024-07-08 15:25:41 --> Hooks Class Initialized
DEBUG - 2024-07-08 15:25:41 --> UTF-8 Support Enabled
INFO - 2024-07-08 15:25:41 --> Utf8 Class Initialized
INFO - 2024-07-08 15:25:41 --> URI Class Initialized
INFO - 2024-07-08 15:25:41 --> Router Class Initialized
INFO - 2024-07-08 15:25:41 --> Output Class Initialized
INFO - 2024-07-08 15:25:41 --> Security Class Initialized
DEBUG - 2024-07-08 15:25:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-07-08 15:25:41 --> Input Class Initialized
INFO - 2024-07-08 15:25:41 --> Language Class Initialized
INFO - 2024-07-08 15:25:41 --> Language Class Initialized
INFO - 2024-07-08 15:25:41 --> Config Class Initialized
INFO - 2024-07-08 15:25:41 --> Loader Class Initialized
INFO - 2024-07-08 15:25:41 --> Helper loaded: url_helper
INFO - 2024-07-08 15:25:41 --> Helper loaded: file_helper
INFO - 2024-07-08 15:25:41 --> Helper loaded: form_helper
INFO - 2024-07-08 15:25:41 --> Helper loaded: my_helper
INFO - 2024-07-08 15:25:41 --> Database Driver Class Initialized
INFO - 2024-07-08 15:25:41 --> Session: Class initialized using 'files' driver.
INFO - 2024-07-08 15:25:41 --> Controller Class Initialized
INFO - 2024-07-08 15:25:49 --> Config Class Initialized
INFO - 2024-07-08 15:25:49 --> Hooks Class Initialized
DEBUG - 2024-07-08 15:25:49 --> UTF-8 Support Enabled
INFO - 2024-07-08 15:25:49 --> Utf8 Class Initialized
INFO - 2024-07-08 15:25:49 --> URI Class Initialized
INFO - 2024-07-08 15:25:49 --> Router Class Initialized
INFO - 2024-07-08 15:25:49 --> Output Class Initialized
INFO - 2024-07-08 15:25:49 --> Security Class Initialized
DEBUG - 2024-07-08 15:25:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-07-08 15:25:49 --> Input Class Initialized
INFO - 2024-07-08 15:25:49 --> Language Class Initialized
INFO - 2024-07-08 15:25:49 --> Language Class Initialized
INFO - 2024-07-08 15:25:49 --> Config Class Initialized
INFO - 2024-07-08 15:25:49 --> Loader Class Initialized
INFO - 2024-07-08 15:25:49 --> Helper loaded: url_helper
INFO - 2024-07-08 15:25:49 --> Helper loaded: file_helper
INFO - 2024-07-08 15:25:49 --> Helper loaded: form_helper
INFO - 2024-07-08 15:25:49 --> Helper loaded: my_helper
INFO - 2024-07-08 15:25:49 --> Database Driver Class Initialized
INFO - 2024-07-08 15:25:49 --> Session: Class initialized using 'files' driver.
INFO - 2024-07-08 15:25:49 --> Controller Class Initialized
INFO - 2024-07-08 15:25:49 --> Final output sent to browser
DEBUG - 2024-07-08 15:25:49 --> Total execution time: 0.0324
INFO - 2024-07-08 15:25:51 --> Config Class Initialized
INFO - 2024-07-08 15:25:51 --> Hooks Class Initialized
DEBUG - 2024-07-08 15:25:51 --> UTF-8 Support Enabled
INFO - 2024-07-08 15:25:51 --> Utf8 Class Initialized
INFO - 2024-07-08 15:25:51 --> URI Class Initialized
INFO - 2024-07-08 15:25:51 --> Router Class Initialized
INFO - 2024-07-08 15:25:51 --> Output Class Initialized
INFO - 2024-07-08 15:25:51 --> Security Class Initialized
DEBUG - 2024-07-08 15:25:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-07-08 15:25:51 --> Input Class Initialized
INFO - 2024-07-08 15:25:51 --> Language Class Initialized
INFO - 2024-07-08 15:25:51 --> Language Class Initialized
INFO - 2024-07-08 15:25:51 --> Config Class Initialized
INFO - 2024-07-08 15:25:51 --> Loader Class Initialized
INFO - 2024-07-08 15:25:51 --> Helper loaded: url_helper
INFO - 2024-07-08 15:25:51 --> Helper loaded: file_helper
INFO - 2024-07-08 15:25:51 --> Helper loaded: form_helper
INFO - 2024-07-08 15:25:51 --> Helper loaded: my_helper
INFO - 2024-07-08 15:25:51 --> Database Driver Class Initialized
INFO - 2024-07-08 15:25:51 --> Session: Class initialized using 'files' driver.
INFO - 2024-07-08 15:25:51 --> Controller Class Initialized
INFO - 2024-07-08 15:25:51 --> Final output sent to browser
DEBUG - 2024-07-08 15:25:51 --> Total execution time: 0.0341
INFO - 2024-07-08 15:25:51 --> Config Class Initialized
INFO - 2024-07-08 15:25:51 --> Hooks Class Initialized
DEBUG - 2024-07-08 15:25:51 --> UTF-8 Support Enabled
INFO - 2024-07-08 15:25:51 --> Utf8 Class Initialized
INFO - 2024-07-08 15:25:51 --> URI Class Initialized
INFO - 2024-07-08 15:25:51 --> Router Class Initialized
INFO - 2024-07-08 15:25:51 --> Output Class Initialized
INFO - 2024-07-08 15:25:51 --> Security Class Initialized
DEBUG - 2024-07-08 15:25:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-07-08 15:25:51 --> Input Class Initialized
INFO - 2024-07-08 15:25:51 --> Language Class Initialized
ERROR - 2024-07-08 15:25:51 --> 404 Page Not Found: /index
INFO - 2024-07-08 15:25:51 --> Config Class Initialized
INFO - 2024-07-08 15:25:51 --> Hooks Class Initialized
DEBUG - 2024-07-08 15:25:51 --> UTF-8 Support Enabled
INFO - 2024-07-08 15:25:51 --> Utf8 Class Initialized
INFO - 2024-07-08 15:25:51 --> URI Class Initialized
INFO - 2024-07-08 15:25:51 --> Router Class Initialized
INFO - 2024-07-08 15:25:51 --> Output Class Initialized
INFO - 2024-07-08 15:25:51 --> Security Class Initialized
DEBUG - 2024-07-08 15:25:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-07-08 15:25:51 --> Input Class Initialized
INFO - 2024-07-08 15:25:51 --> Language Class Initialized
INFO - 2024-07-08 15:25:51 --> Language Class Initialized
INFO - 2024-07-08 15:25:51 --> Config Class Initialized
INFO - 2024-07-08 15:25:51 --> Loader Class Initialized
INFO - 2024-07-08 15:25:51 --> Helper loaded: url_helper
INFO - 2024-07-08 15:25:51 --> Helper loaded: file_helper
INFO - 2024-07-08 15:25:51 --> Helper loaded: form_helper
INFO - 2024-07-08 15:25:51 --> Helper loaded: my_helper
INFO - 2024-07-08 15:25:51 --> Database Driver Class Initialized
INFO - 2024-07-08 15:25:51 --> Session: Class initialized using 'files' driver.
INFO - 2024-07-08 15:25:51 --> Controller Class Initialized
INFO - 2024-07-08 15:25:58 --> Config Class Initialized
INFO - 2024-07-08 15:25:58 --> Hooks Class Initialized
DEBUG - 2024-07-08 15:25:58 --> UTF-8 Support Enabled
INFO - 2024-07-08 15:25:58 --> Utf8 Class Initialized
INFO - 2024-07-08 15:25:58 --> URI Class Initialized
INFO - 2024-07-08 15:25:58 --> Router Class Initialized
INFO - 2024-07-08 15:25:58 --> Output Class Initialized
INFO - 2024-07-08 15:25:58 --> Security Class Initialized
DEBUG - 2024-07-08 15:25:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-07-08 15:25:58 --> Input Class Initialized
INFO - 2024-07-08 15:25:58 --> Language Class Initialized
INFO - 2024-07-08 15:25:58 --> Language Class Initialized
INFO - 2024-07-08 15:25:58 --> Config Class Initialized
INFO - 2024-07-08 15:25:58 --> Loader Class Initialized
INFO - 2024-07-08 15:25:58 --> Helper loaded: url_helper
INFO - 2024-07-08 15:25:58 --> Helper loaded: file_helper
INFO - 2024-07-08 15:25:58 --> Helper loaded: form_helper
INFO - 2024-07-08 15:25:58 --> Helper loaded: my_helper
INFO - 2024-07-08 15:25:58 --> Database Driver Class Initialized
INFO - 2024-07-08 15:25:58 --> Session: Class initialized using 'files' driver.
INFO - 2024-07-08 15:25:58 --> Controller Class Initialized
DEBUG - 2024-07-08 15:25:58 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/tahun/views/list.php
DEBUG - 2024-07-08 15:25:58 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-07-08 15:25:58 --> Final output sent to browser
DEBUG - 2024-07-08 15:25:58 --> Total execution time: 0.0366
INFO - 2024-07-08 15:25:58 --> Config Class Initialized
INFO - 2024-07-08 15:25:58 --> Hooks Class Initialized
DEBUG - 2024-07-08 15:25:58 --> UTF-8 Support Enabled
INFO - 2024-07-08 15:25:58 --> Utf8 Class Initialized
INFO - 2024-07-08 15:25:58 --> URI Class Initialized
INFO - 2024-07-08 15:25:58 --> Router Class Initialized
INFO - 2024-07-08 15:25:58 --> Output Class Initialized
INFO - 2024-07-08 15:25:58 --> Security Class Initialized
DEBUG - 2024-07-08 15:25:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-07-08 15:25:58 --> Input Class Initialized
INFO - 2024-07-08 15:25:58 --> Language Class Initialized
ERROR - 2024-07-08 15:25:58 --> 404 Page Not Found: /index
INFO - 2024-07-08 15:25:58 --> Config Class Initialized
INFO - 2024-07-08 15:25:58 --> Hooks Class Initialized
DEBUG - 2024-07-08 15:25:58 --> UTF-8 Support Enabled
INFO - 2024-07-08 15:25:58 --> Utf8 Class Initialized
INFO - 2024-07-08 15:25:58 --> URI Class Initialized
INFO - 2024-07-08 15:25:58 --> Router Class Initialized
INFO - 2024-07-08 15:25:58 --> Output Class Initialized
INFO - 2024-07-08 15:25:58 --> Security Class Initialized
DEBUG - 2024-07-08 15:25:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-07-08 15:25:58 --> Input Class Initialized
INFO - 2024-07-08 15:25:58 --> Language Class Initialized
INFO - 2024-07-08 15:25:58 --> Language Class Initialized
INFO - 2024-07-08 15:25:58 --> Config Class Initialized
INFO - 2024-07-08 15:25:58 --> Loader Class Initialized
INFO - 2024-07-08 15:25:58 --> Helper loaded: url_helper
INFO - 2024-07-08 15:25:58 --> Helper loaded: file_helper
INFO - 2024-07-08 15:25:58 --> Helper loaded: form_helper
INFO - 2024-07-08 15:25:58 --> Helper loaded: my_helper
INFO - 2024-07-08 15:25:58 --> Database Driver Class Initialized
INFO - 2024-07-08 15:25:58 --> Session: Class initialized using 'files' driver.
INFO - 2024-07-08 15:25:58 --> Controller Class Initialized
INFO - 2024-07-08 15:26:01 --> Config Class Initialized
INFO - 2024-07-08 15:26:01 --> Hooks Class Initialized
DEBUG - 2024-07-08 15:26:01 --> UTF-8 Support Enabled
INFO - 2024-07-08 15:26:01 --> Utf8 Class Initialized
INFO - 2024-07-08 15:26:01 --> URI Class Initialized
INFO - 2024-07-08 15:26:01 --> Router Class Initialized
INFO - 2024-07-08 15:26:01 --> Output Class Initialized
INFO - 2024-07-08 15:26:01 --> Security Class Initialized
DEBUG - 2024-07-08 15:26:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-07-08 15:26:01 --> Input Class Initialized
INFO - 2024-07-08 15:26:01 --> Language Class Initialized
INFO - 2024-07-08 15:26:01 --> Language Class Initialized
INFO - 2024-07-08 15:26:01 --> Config Class Initialized
INFO - 2024-07-08 15:26:01 --> Loader Class Initialized
INFO - 2024-07-08 15:26:01 --> Helper loaded: url_helper
INFO - 2024-07-08 15:26:01 --> Helper loaded: file_helper
INFO - 2024-07-08 15:26:01 --> Helper loaded: form_helper
INFO - 2024-07-08 15:26:01 --> Helper loaded: my_helper
INFO - 2024-07-08 15:26:01 --> Database Driver Class Initialized
INFO - 2024-07-08 15:26:01 --> Session: Class initialized using 'files' driver.
INFO - 2024-07-08 15:26:01 --> Controller Class Initialized
DEBUG - 2024-07-08 15:26:01 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/backup_db/views/list.php
DEBUG - 2024-07-08 15:26:01 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-07-08 15:26:01 --> Final output sent to browser
DEBUG - 2024-07-08 15:26:01 --> Total execution time: 0.0392
INFO - 2024-07-08 15:26:01 --> Config Class Initialized
INFO - 2024-07-08 15:26:01 --> Hooks Class Initialized
DEBUG - 2024-07-08 15:26:01 --> UTF-8 Support Enabled
INFO - 2024-07-08 15:26:01 --> Utf8 Class Initialized
INFO - 2024-07-08 15:26:01 --> URI Class Initialized
INFO - 2024-07-08 15:26:01 --> Router Class Initialized
INFO - 2024-07-08 15:26:01 --> Output Class Initialized
INFO - 2024-07-08 15:26:01 --> Security Class Initialized
DEBUG - 2024-07-08 15:26:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-07-08 15:26:01 --> Input Class Initialized
INFO - 2024-07-08 15:26:01 --> Language Class Initialized
ERROR - 2024-07-08 15:26:01 --> 404 Page Not Found: /index
INFO - 2024-07-08 15:26:01 --> Config Class Initialized
INFO - 2024-07-08 15:26:01 --> Hooks Class Initialized
DEBUG - 2024-07-08 15:26:01 --> UTF-8 Support Enabled
INFO - 2024-07-08 15:26:01 --> Utf8 Class Initialized
INFO - 2024-07-08 15:26:01 --> URI Class Initialized
INFO - 2024-07-08 15:26:01 --> Router Class Initialized
INFO - 2024-07-08 15:26:01 --> Output Class Initialized
INFO - 2024-07-08 15:26:01 --> Security Class Initialized
DEBUG - 2024-07-08 15:26:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-07-08 15:26:01 --> Input Class Initialized
INFO - 2024-07-08 15:26:01 --> Language Class Initialized
INFO - 2024-07-08 15:26:01 --> Language Class Initialized
INFO - 2024-07-08 15:26:01 --> Config Class Initialized
INFO - 2024-07-08 15:26:01 --> Loader Class Initialized
INFO - 2024-07-08 15:26:01 --> Helper loaded: url_helper
INFO - 2024-07-08 15:26:01 --> Helper loaded: file_helper
INFO - 2024-07-08 15:26:01 --> Helper loaded: form_helper
INFO - 2024-07-08 15:26:01 --> Helper loaded: my_helper
INFO - 2024-07-08 15:26:01 --> Database Driver Class Initialized
INFO - 2024-07-08 15:26:01 --> Session: Class initialized using 'files' driver.
INFO - 2024-07-08 15:26:01 --> Controller Class Initialized
INFO - 2024-07-08 15:26:10 --> Config Class Initialized
INFO - 2024-07-08 15:26:10 --> Hooks Class Initialized
DEBUG - 2024-07-08 15:26:10 --> UTF-8 Support Enabled
INFO - 2024-07-08 15:26:10 --> Utf8 Class Initialized
INFO - 2024-07-08 15:26:10 --> URI Class Initialized
INFO - 2024-07-08 15:26:10 --> Router Class Initialized
INFO - 2024-07-08 15:26:10 --> Output Class Initialized
INFO - 2024-07-08 15:26:10 --> Security Class Initialized
DEBUG - 2024-07-08 15:26:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-07-08 15:26:10 --> Input Class Initialized
INFO - 2024-07-08 15:26:10 --> Language Class Initialized
INFO - 2024-07-08 15:26:10 --> Language Class Initialized
INFO - 2024-07-08 15:26:10 --> Config Class Initialized
INFO - 2024-07-08 15:26:10 --> Loader Class Initialized
INFO - 2024-07-08 15:26:10 --> Helper loaded: url_helper
INFO - 2024-07-08 15:26:10 --> Helper loaded: file_helper
INFO - 2024-07-08 15:26:10 --> Helper loaded: form_helper
INFO - 2024-07-08 15:26:10 --> Helper loaded: my_helper
INFO - 2024-07-08 15:26:10 --> Database Driver Class Initialized
INFO - 2024-07-08 15:26:10 --> Session: Class initialized using 'files' driver.
INFO - 2024-07-08 15:26:10 --> Controller Class Initialized
INFO - 2024-07-08 15:26:10 --> Database Utility Class Initialized
INFO - 2024-07-08 15:26:10 --> Zip Compression Class Initialized
ERROR - 2024-07-08 15:26:10 --> Severity: Notice --> Only variables should be assigned by reference /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/backup_db/controllers/Backup_db.php 96
INFO - 2024-07-08 15:26:10 --> Config Class Initialized
INFO - 2024-07-08 15:26:10 --> Hooks Class Initialized
DEBUG - 2024-07-08 15:26:10 --> UTF-8 Support Enabled
INFO - 2024-07-08 15:26:10 --> Utf8 Class Initialized
INFO - 2024-07-08 15:26:10 --> URI Class Initialized
INFO - 2024-07-08 15:26:10 --> Router Class Initialized
INFO - 2024-07-08 15:26:10 --> Output Class Initialized
INFO - 2024-07-08 15:26:10 --> Security Class Initialized
DEBUG - 2024-07-08 15:26:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-07-08 15:26:10 --> Input Class Initialized
INFO - 2024-07-08 15:26:10 --> Language Class Initialized
INFO - 2024-07-08 15:26:10 --> Language Class Initialized
INFO - 2024-07-08 15:26:10 --> Config Class Initialized
INFO - 2024-07-08 15:26:10 --> Loader Class Initialized
INFO - 2024-07-08 15:26:10 --> Helper loaded: url_helper
INFO - 2024-07-08 15:26:10 --> Helper loaded: file_helper
INFO - 2024-07-08 15:26:10 --> Helper loaded: form_helper
INFO - 2024-07-08 15:26:10 --> Helper loaded: my_helper
INFO - 2024-07-08 15:26:10 --> Database Driver Class Initialized
INFO - 2024-07-08 15:26:10 --> Session: Class initialized using 'files' driver.
INFO - 2024-07-08 15:26:10 --> Controller Class Initialized
DEBUG - 2024-07-08 15:26:10 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/backup_db/views/list.php
DEBUG - 2024-07-08 15:26:10 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-07-08 15:26:10 --> Final output sent to browser
DEBUG - 2024-07-08 15:26:10 --> Total execution time: 0.0388
INFO - 2024-07-08 15:26:13 --> Config Class Initialized
INFO - 2024-07-08 15:26:13 --> Hooks Class Initialized
DEBUG - 2024-07-08 15:26:13 --> UTF-8 Support Enabled
INFO - 2024-07-08 15:26:13 --> Utf8 Class Initialized
INFO - 2024-07-08 15:26:13 --> URI Class Initialized
INFO - 2024-07-08 15:26:13 --> Router Class Initialized
INFO - 2024-07-08 15:26:13 --> Output Class Initialized
INFO - 2024-07-08 15:26:13 --> Security Class Initialized
DEBUG - 2024-07-08 15:26:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-07-08 15:26:13 --> Input Class Initialized
INFO - 2024-07-08 15:26:13 --> Language Class Initialized
ERROR - 2024-07-08 15:26:13 --> 404 Page Not Found: /index
INFO - 2024-07-08 15:26:13 --> Config Class Initialized
INFO - 2024-07-08 15:26:13 --> Hooks Class Initialized
DEBUG - 2024-07-08 15:26:13 --> UTF-8 Support Enabled
INFO - 2024-07-08 15:26:13 --> Utf8 Class Initialized
INFO - 2024-07-08 15:26:13 --> URI Class Initialized
INFO - 2024-07-08 15:26:13 --> Router Class Initialized
INFO - 2024-07-08 15:26:13 --> Output Class Initialized
INFO - 2024-07-08 15:26:13 --> Security Class Initialized
DEBUG - 2024-07-08 15:26:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-07-08 15:26:13 --> Input Class Initialized
INFO - 2024-07-08 15:26:13 --> Language Class Initialized
INFO - 2024-07-08 15:26:13 --> Language Class Initialized
INFO - 2024-07-08 15:26:13 --> Config Class Initialized
INFO - 2024-07-08 15:26:13 --> Loader Class Initialized
INFO - 2024-07-08 15:26:13 --> Helper loaded: url_helper
INFO - 2024-07-08 15:26:13 --> Helper loaded: file_helper
INFO - 2024-07-08 15:26:13 --> Helper loaded: form_helper
INFO - 2024-07-08 15:26:13 --> Helper loaded: my_helper
INFO - 2024-07-08 15:26:13 --> Database Driver Class Initialized
INFO - 2024-07-08 15:26:13 --> Session: Class initialized using 'files' driver.
INFO - 2024-07-08 15:26:13 --> Controller Class Initialized
INFO - 2024-07-08 15:26:28 --> Config Class Initialized
INFO - 2024-07-08 15:26:28 --> Hooks Class Initialized
DEBUG - 2024-07-08 15:26:28 --> UTF-8 Support Enabled
INFO - 2024-07-08 15:26:28 --> Utf8 Class Initialized
INFO - 2024-07-08 15:26:28 --> URI Class Initialized
INFO - 2024-07-08 15:26:28 --> Router Class Initialized
INFO - 2024-07-08 15:26:28 --> Output Class Initialized
INFO - 2024-07-08 15:26:28 --> Security Class Initialized
DEBUG - 2024-07-08 15:26:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-07-08 15:26:28 --> Input Class Initialized
INFO - 2024-07-08 15:26:28 --> Language Class Initialized
INFO - 2024-07-08 15:26:28 --> Language Class Initialized
INFO - 2024-07-08 15:26:28 --> Config Class Initialized
INFO - 2024-07-08 15:26:28 --> Loader Class Initialized
INFO - 2024-07-08 15:26:28 --> Helper loaded: url_helper
INFO - 2024-07-08 15:26:28 --> Helper loaded: file_helper
INFO - 2024-07-08 15:26:28 --> Helper loaded: form_helper
INFO - 2024-07-08 15:26:28 --> Helper loaded: my_helper
INFO - 2024-07-08 15:26:28 --> Database Driver Class Initialized
INFO - 2024-07-08 15:26:28 --> Session: Class initialized using 'files' driver.
INFO - 2024-07-08 15:26:28 --> Controller Class Initialized
DEBUG - 2024-07-08 15:26:28 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/tahun/views/list.php
DEBUG - 2024-07-08 15:26:28 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-07-08 15:26:28 --> Final output sent to browser
DEBUG - 2024-07-08 15:26:28 --> Total execution time: 0.0466
INFO - 2024-07-08 15:26:28 --> Config Class Initialized
INFO - 2024-07-08 15:26:28 --> Hooks Class Initialized
DEBUG - 2024-07-08 15:26:28 --> UTF-8 Support Enabled
INFO - 2024-07-08 15:26:28 --> Utf8 Class Initialized
INFO - 2024-07-08 15:26:28 --> URI Class Initialized
INFO - 2024-07-08 15:26:28 --> Router Class Initialized
INFO - 2024-07-08 15:26:28 --> Output Class Initialized
INFO - 2024-07-08 15:26:28 --> Security Class Initialized
DEBUG - 2024-07-08 15:26:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-07-08 15:26:28 --> Input Class Initialized
INFO - 2024-07-08 15:26:28 --> Language Class Initialized
ERROR - 2024-07-08 15:26:28 --> 404 Page Not Found: /index
INFO - 2024-07-08 15:26:28 --> Config Class Initialized
INFO - 2024-07-08 15:26:28 --> Hooks Class Initialized
DEBUG - 2024-07-08 15:26:28 --> UTF-8 Support Enabled
INFO - 2024-07-08 15:26:28 --> Utf8 Class Initialized
INFO - 2024-07-08 15:26:28 --> URI Class Initialized
INFO - 2024-07-08 15:26:28 --> Router Class Initialized
INFO - 2024-07-08 15:26:28 --> Output Class Initialized
INFO - 2024-07-08 15:26:28 --> Security Class Initialized
DEBUG - 2024-07-08 15:26:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-07-08 15:26:28 --> Input Class Initialized
INFO - 2024-07-08 15:26:28 --> Language Class Initialized
INFO - 2024-07-08 15:26:28 --> Language Class Initialized
INFO - 2024-07-08 15:26:28 --> Config Class Initialized
INFO - 2024-07-08 15:26:28 --> Loader Class Initialized
INFO - 2024-07-08 15:26:28 --> Helper loaded: url_helper
INFO - 2024-07-08 15:26:28 --> Helper loaded: file_helper
INFO - 2024-07-08 15:26:28 --> Helper loaded: form_helper
INFO - 2024-07-08 15:26:28 --> Helper loaded: my_helper
INFO - 2024-07-08 15:26:28 --> Database Driver Class Initialized
INFO - 2024-07-08 15:26:28 --> Session: Class initialized using 'files' driver.
INFO - 2024-07-08 15:26:28 --> Controller Class Initialized
INFO - 2024-07-08 15:26:40 --> Config Class Initialized
INFO - 2024-07-08 15:26:40 --> Hooks Class Initialized
DEBUG - 2024-07-08 15:26:40 --> UTF-8 Support Enabled
INFO - 2024-07-08 15:26:40 --> Utf8 Class Initialized
INFO - 2024-07-08 15:26:40 --> URI Class Initialized
INFO - 2024-07-08 15:26:40 --> Router Class Initialized
INFO - 2024-07-08 15:26:40 --> Output Class Initialized
INFO - 2024-07-08 15:26:40 --> Security Class Initialized
DEBUG - 2024-07-08 15:26:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-07-08 15:26:40 --> Input Class Initialized
INFO - 2024-07-08 15:26:40 --> Language Class Initialized
INFO - 2024-07-08 15:26:40 --> Language Class Initialized
INFO - 2024-07-08 15:26:40 --> Config Class Initialized
INFO - 2024-07-08 15:26:40 --> Loader Class Initialized
INFO - 2024-07-08 15:26:40 --> Helper loaded: url_helper
INFO - 2024-07-08 15:26:40 --> Helper loaded: file_helper
INFO - 2024-07-08 15:26:40 --> Helper loaded: form_helper
INFO - 2024-07-08 15:26:40 --> Helper loaded: my_helper
INFO - 2024-07-08 15:26:40 --> Database Driver Class Initialized
INFO - 2024-07-08 15:26:40 --> Session: Class initialized using 'files' driver.
INFO - 2024-07-08 15:26:40 --> Controller Class Initialized
INFO - 2024-07-08 15:26:40 --> Final output sent to browser
DEBUG - 2024-07-08 15:26:40 --> Total execution time: 0.0407
INFO - 2024-07-08 15:26:40 --> Config Class Initialized
INFO - 2024-07-08 15:26:40 --> Hooks Class Initialized
DEBUG - 2024-07-08 15:26:40 --> UTF-8 Support Enabled
INFO - 2024-07-08 15:26:40 --> Utf8 Class Initialized
INFO - 2024-07-08 15:26:40 --> URI Class Initialized
INFO - 2024-07-08 15:26:40 --> Router Class Initialized
INFO - 2024-07-08 15:26:40 --> Output Class Initialized
INFO - 2024-07-08 15:26:40 --> Security Class Initialized
DEBUG - 2024-07-08 15:26:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-07-08 15:26:40 --> Input Class Initialized
INFO - 2024-07-08 15:26:40 --> Language Class Initialized
ERROR - 2024-07-08 15:26:40 --> 404 Page Not Found: /index
INFO - 2024-07-08 15:26:40 --> Config Class Initialized
INFO - 2024-07-08 15:26:40 --> Hooks Class Initialized
DEBUG - 2024-07-08 15:26:40 --> UTF-8 Support Enabled
INFO - 2024-07-08 15:26:40 --> Utf8 Class Initialized
INFO - 2024-07-08 15:26:40 --> URI Class Initialized
INFO - 2024-07-08 15:26:40 --> Router Class Initialized
INFO - 2024-07-08 15:26:40 --> Output Class Initialized
INFO - 2024-07-08 15:26:40 --> Security Class Initialized
DEBUG - 2024-07-08 15:26:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-07-08 15:26:40 --> Input Class Initialized
INFO - 2024-07-08 15:26:40 --> Language Class Initialized
INFO - 2024-07-08 15:26:40 --> Language Class Initialized
INFO - 2024-07-08 15:26:40 --> Config Class Initialized
INFO - 2024-07-08 15:26:40 --> Loader Class Initialized
INFO - 2024-07-08 15:26:40 --> Helper loaded: url_helper
INFO - 2024-07-08 15:26:40 --> Helper loaded: file_helper
INFO - 2024-07-08 15:26:40 --> Helper loaded: form_helper
INFO - 2024-07-08 15:26:40 --> Helper loaded: my_helper
INFO - 2024-07-08 15:26:40 --> Database Driver Class Initialized
INFO - 2024-07-08 15:26:40 --> Session: Class initialized using 'files' driver.
INFO - 2024-07-08 15:26:40 --> Controller Class Initialized
INFO - 2024-07-08 15:26:43 --> Config Class Initialized
INFO - 2024-07-08 15:26:43 --> Hooks Class Initialized
DEBUG - 2024-07-08 15:26:43 --> UTF-8 Support Enabled
INFO - 2024-07-08 15:26:43 --> Utf8 Class Initialized
INFO - 2024-07-08 15:26:43 --> URI Class Initialized
INFO - 2024-07-08 15:26:43 --> Router Class Initialized
INFO - 2024-07-08 15:26:43 --> Output Class Initialized
INFO - 2024-07-08 15:26:43 --> Security Class Initialized
DEBUG - 2024-07-08 15:26:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-07-08 15:26:43 --> Input Class Initialized
INFO - 2024-07-08 15:26:43 --> Language Class Initialized
INFO - 2024-07-08 15:26:43 --> Language Class Initialized
INFO - 2024-07-08 15:26:43 --> Config Class Initialized
INFO - 2024-07-08 15:26:43 --> Loader Class Initialized
INFO - 2024-07-08 15:26:43 --> Helper loaded: url_helper
INFO - 2024-07-08 15:26:43 --> Helper loaded: file_helper
INFO - 2024-07-08 15:26:43 --> Helper loaded: form_helper
INFO - 2024-07-08 15:26:43 --> Helper loaded: my_helper
INFO - 2024-07-08 15:26:43 --> Database Driver Class Initialized
INFO - 2024-07-08 15:26:43 --> Session: Class initialized using 'files' driver.
INFO - 2024-07-08 15:26:43 --> Controller Class Initialized
DEBUG - 2024-07-08 15:26:43 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/backup_db/views/list.php
DEBUG - 2024-07-08 15:26:43 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-07-08 15:26:43 --> Final output sent to browser
DEBUG - 2024-07-08 15:26:43 --> Total execution time: 0.0368
INFO - 2024-07-08 15:26:43 --> Config Class Initialized
INFO - 2024-07-08 15:26:43 --> Hooks Class Initialized
DEBUG - 2024-07-08 15:26:43 --> UTF-8 Support Enabled
INFO - 2024-07-08 15:26:43 --> Utf8 Class Initialized
INFO - 2024-07-08 15:26:43 --> URI Class Initialized
INFO - 2024-07-08 15:26:43 --> Router Class Initialized
INFO - 2024-07-08 15:26:43 --> Output Class Initialized
INFO - 2024-07-08 15:26:43 --> Security Class Initialized
DEBUG - 2024-07-08 15:26:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-07-08 15:26:43 --> Input Class Initialized
INFO - 2024-07-08 15:26:43 --> Language Class Initialized
ERROR - 2024-07-08 15:26:43 --> 404 Page Not Found: /index
INFO - 2024-07-08 15:26:43 --> Config Class Initialized
INFO - 2024-07-08 15:26:43 --> Hooks Class Initialized
DEBUG - 2024-07-08 15:26:43 --> UTF-8 Support Enabled
INFO - 2024-07-08 15:26:43 --> Utf8 Class Initialized
INFO - 2024-07-08 15:26:43 --> URI Class Initialized
INFO - 2024-07-08 15:26:43 --> Router Class Initialized
INFO - 2024-07-08 15:26:43 --> Output Class Initialized
INFO - 2024-07-08 15:26:43 --> Security Class Initialized
DEBUG - 2024-07-08 15:26:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-07-08 15:26:43 --> Input Class Initialized
INFO - 2024-07-08 15:26:43 --> Language Class Initialized
INFO - 2024-07-08 15:26:43 --> Language Class Initialized
INFO - 2024-07-08 15:26:43 --> Config Class Initialized
INFO - 2024-07-08 15:26:43 --> Loader Class Initialized
INFO - 2024-07-08 15:26:43 --> Helper loaded: url_helper
INFO - 2024-07-08 15:26:43 --> Helper loaded: file_helper
INFO - 2024-07-08 15:26:43 --> Helper loaded: form_helper
INFO - 2024-07-08 15:26:43 --> Helper loaded: my_helper
INFO - 2024-07-08 15:26:43 --> Database Driver Class Initialized
INFO - 2024-07-08 15:26:43 --> Session: Class initialized using 'files' driver.
INFO - 2024-07-08 15:26:43 --> Controller Class Initialized
INFO - 2024-07-08 15:26:45 --> Config Class Initialized
INFO - 2024-07-08 15:26:45 --> Hooks Class Initialized
DEBUG - 2024-07-08 15:26:45 --> UTF-8 Support Enabled
INFO - 2024-07-08 15:26:45 --> Utf8 Class Initialized
INFO - 2024-07-08 15:26:45 --> URI Class Initialized
INFO - 2024-07-08 15:26:45 --> Router Class Initialized
INFO - 2024-07-08 15:26:45 --> Output Class Initialized
INFO - 2024-07-08 15:26:45 --> Security Class Initialized
DEBUG - 2024-07-08 15:26:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-07-08 15:26:45 --> Input Class Initialized
INFO - 2024-07-08 15:26:45 --> Language Class Initialized
INFO - 2024-07-08 15:26:45 --> Language Class Initialized
INFO - 2024-07-08 15:26:45 --> Config Class Initialized
INFO - 2024-07-08 15:26:45 --> Loader Class Initialized
INFO - 2024-07-08 15:26:45 --> Helper loaded: url_helper
INFO - 2024-07-08 15:26:45 --> Helper loaded: file_helper
INFO - 2024-07-08 15:26:45 --> Helper loaded: form_helper
INFO - 2024-07-08 15:26:45 --> Helper loaded: my_helper
INFO - 2024-07-08 15:26:45 --> Database Driver Class Initialized
INFO - 2024-07-08 15:26:45 --> Session: Class initialized using 'files' driver.
INFO - 2024-07-08 15:26:45 --> Controller Class Initialized
INFO - 2024-07-08 15:26:45 --> Database Utility Class Initialized
INFO - 2024-07-08 15:26:45 --> Zip Compression Class Initialized
ERROR - 2024-07-08 15:26:45 --> Severity: Notice --> Only variables should be assigned by reference /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/backup_db/controllers/Backup_db.php 96
INFO - 2024-07-08 15:26:45 --> Config Class Initialized
INFO - 2024-07-08 15:26:45 --> Hooks Class Initialized
DEBUG - 2024-07-08 15:26:45 --> UTF-8 Support Enabled
INFO - 2024-07-08 15:26:45 --> Utf8 Class Initialized
INFO - 2024-07-08 15:26:45 --> URI Class Initialized
INFO - 2024-07-08 15:26:45 --> Router Class Initialized
INFO - 2024-07-08 15:26:45 --> Output Class Initialized
INFO - 2024-07-08 15:26:45 --> Security Class Initialized
DEBUG - 2024-07-08 15:26:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-07-08 15:26:45 --> Input Class Initialized
INFO - 2024-07-08 15:26:45 --> Language Class Initialized
INFO - 2024-07-08 15:26:45 --> Language Class Initialized
INFO - 2024-07-08 15:26:45 --> Config Class Initialized
INFO - 2024-07-08 15:26:45 --> Loader Class Initialized
INFO - 2024-07-08 15:26:45 --> Helper loaded: url_helper
INFO - 2024-07-08 15:26:45 --> Helper loaded: file_helper
INFO - 2024-07-08 15:26:45 --> Helper loaded: form_helper
INFO - 2024-07-08 15:26:45 --> Helper loaded: my_helper
INFO - 2024-07-08 15:26:45 --> Database Driver Class Initialized
INFO - 2024-07-08 15:26:45 --> Session: Class initialized using 'files' driver.
INFO - 2024-07-08 15:26:45 --> Controller Class Initialized
DEBUG - 2024-07-08 15:26:45 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/backup_db/views/list.php
DEBUG - 2024-07-08 15:26:45 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-07-08 15:26:45 --> Final output sent to browser
DEBUG - 2024-07-08 15:26:45 --> Total execution time: 0.0412
INFO - 2024-07-08 15:26:47 --> Config Class Initialized
INFO - 2024-07-08 15:26:47 --> Hooks Class Initialized
DEBUG - 2024-07-08 15:26:47 --> UTF-8 Support Enabled
INFO - 2024-07-08 15:26:47 --> Utf8 Class Initialized
INFO - 2024-07-08 15:26:47 --> URI Class Initialized
INFO - 2024-07-08 15:26:47 --> Router Class Initialized
INFO - 2024-07-08 15:26:47 --> Output Class Initialized
INFO - 2024-07-08 15:26:47 --> Security Class Initialized
DEBUG - 2024-07-08 15:26:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-07-08 15:26:47 --> Input Class Initialized
INFO - 2024-07-08 15:26:47 --> Language Class Initialized
ERROR - 2024-07-08 15:26:47 --> 404 Page Not Found: /index
INFO - 2024-07-08 15:26:47 --> Config Class Initialized
INFO - 2024-07-08 15:26:47 --> Hooks Class Initialized
DEBUG - 2024-07-08 15:26:47 --> UTF-8 Support Enabled
INFO - 2024-07-08 15:26:47 --> Utf8 Class Initialized
INFO - 2024-07-08 15:26:47 --> URI Class Initialized
INFO - 2024-07-08 15:26:47 --> Router Class Initialized
INFO - 2024-07-08 15:26:47 --> Output Class Initialized
INFO - 2024-07-08 15:26:47 --> Security Class Initialized
DEBUG - 2024-07-08 15:26:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-07-08 15:26:47 --> Input Class Initialized
INFO - 2024-07-08 15:26:47 --> Language Class Initialized
INFO - 2024-07-08 15:26:47 --> Language Class Initialized
INFO - 2024-07-08 15:26:47 --> Config Class Initialized
INFO - 2024-07-08 15:26:47 --> Loader Class Initialized
INFO - 2024-07-08 15:26:47 --> Helper loaded: url_helper
INFO - 2024-07-08 15:26:47 --> Helper loaded: file_helper
INFO - 2024-07-08 15:26:47 --> Helper loaded: form_helper
INFO - 2024-07-08 15:26:47 --> Helper loaded: my_helper
INFO - 2024-07-08 15:26:47 --> Database Driver Class Initialized
INFO - 2024-07-08 15:26:47 --> Session: Class initialized using 'files' driver.
INFO - 2024-07-08 15:26:47 --> Controller Class Initialized
INFO - 2024-07-08 15:26:54 --> Config Class Initialized
INFO - 2024-07-08 15:26:54 --> Hooks Class Initialized
DEBUG - 2024-07-08 15:26:54 --> UTF-8 Support Enabled
INFO - 2024-07-08 15:26:54 --> Utf8 Class Initialized
INFO - 2024-07-08 15:26:54 --> URI Class Initialized
INFO - 2024-07-08 15:26:54 --> Router Class Initialized
INFO - 2024-07-08 15:26:54 --> Output Class Initialized
INFO - 2024-07-08 15:26:54 --> Security Class Initialized
DEBUG - 2024-07-08 15:26:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-07-08 15:26:54 --> Input Class Initialized
INFO - 2024-07-08 15:26:54 --> Language Class Initialized
INFO - 2024-07-08 15:26:54 --> Language Class Initialized
INFO - 2024-07-08 15:26:54 --> Config Class Initialized
INFO - 2024-07-08 15:26:54 --> Loader Class Initialized
INFO - 2024-07-08 15:26:54 --> Helper loaded: url_helper
INFO - 2024-07-08 15:26:54 --> Helper loaded: file_helper
INFO - 2024-07-08 15:26:54 --> Helper loaded: form_helper
INFO - 2024-07-08 15:26:54 --> Helper loaded: my_helper
INFO - 2024-07-08 15:26:54 --> Database Driver Class Initialized
INFO - 2024-07-08 15:26:54 --> Session: Class initialized using 'files' driver.
INFO - 2024-07-08 15:26:54 --> Controller Class Initialized
DEBUG - 2024-07-08 15:26:54 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/tahun/views/list.php
DEBUG - 2024-07-08 15:26:54 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-07-08 15:26:54 --> Final output sent to browser
DEBUG - 2024-07-08 15:26:54 --> Total execution time: 0.0336
INFO - 2024-07-08 15:26:54 --> Config Class Initialized
INFO - 2024-07-08 15:26:54 --> Hooks Class Initialized
DEBUG - 2024-07-08 15:26:54 --> UTF-8 Support Enabled
INFO - 2024-07-08 15:26:54 --> Utf8 Class Initialized
INFO - 2024-07-08 15:26:54 --> URI Class Initialized
INFO - 2024-07-08 15:26:54 --> Router Class Initialized
INFO - 2024-07-08 15:26:54 --> Output Class Initialized
INFO - 2024-07-08 15:26:54 --> Security Class Initialized
DEBUG - 2024-07-08 15:26:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-07-08 15:26:54 --> Input Class Initialized
INFO - 2024-07-08 15:26:54 --> Language Class Initialized
ERROR - 2024-07-08 15:26:54 --> 404 Page Not Found: /index
INFO - 2024-07-08 15:26:54 --> Config Class Initialized
INFO - 2024-07-08 15:26:54 --> Hooks Class Initialized
DEBUG - 2024-07-08 15:26:54 --> UTF-8 Support Enabled
INFO - 2024-07-08 15:26:54 --> Utf8 Class Initialized
INFO - 2024-07-08 15:26:54 --> URI Class Initialized
INFO - 2024-07-08 15:26:54 --> Router Class Initialized
INFO - 2024-07-08 15:26:54 --> Output Class Initialized
INFO - 2024-07-08 15:26:54 --> Security Class Initialized
DEBUG - 2024-07-08 15:26:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-07-08 15:26:54 --> Input Class Initialized
INFO - 2024-07-08 15:26:54 --> Language Class Initialized
INFO - 2024-07-08 15:26:54 --> Language Class Initialized
INFO - 2024-07-08 15:26:54 --> Config Class Initialized
INFO - 2024-07-08 15:26:54 --> Loader Class Initialized
INFO - 2024-07-08 15:26:54 --> Helper loaded: url_helper
INFO - 2024-07-08 15:26:54 --> Helper loaded: file_helper
INFO - 2024-07-08 15:26:54 --> Helper loaded: form_helper
INFO - 2024-07-08 15:26:54 --> Helper loaded: my_helper
INFO - 2024-07-08 15:26:54 --> Database Driver Class Initialized
INFO - 2024-07-08 15:26:54 --> Session: Class initialized using 'files' driver.
INFO - 2024-07-08 15:26:54 --> Controller Class Initialized
INFO - 2024-07-08 15:26:58 --> Config Class Initialized
INFO - 2024-07-08 15:26:58 --> Hooks Class Initialized
DEBUG - 2024-07-08 15:26:58 --> UTF-8 Support Enabled
INFO - 2024-07-08 15:26:58 --> Utf8 Class Initialized
INFO - 2024-07-08 15:26:58 --> URI Class Initialized
INFO - 2024-07-08 15:26:58 --> Router Class Initialized
INFO - 2024-07-08 15:26:58 --> Output Class Initialized
INFO - 2024-07-08 15:26:58 --> Security Class Initialized
DEBUG - 2024-07-08 15:26:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-07-08 15:26:58 --> Input Class Initialized
INFO - 2024-07-08 15:26:58 --> Language Class Initialized
INFO - 2024-07-08 15:26:58 --> Language Class Initialized
INFO - 2024-07-08 15:26:58 --> Config Class Initialized
INFO - 2024-07-08 15:26:58 --> Loader Class Initialized
INFO - 2024-07-08 15:26:58 --> Helper loaded: url_helper
INFO - 2024-07-08 15:26:58 --> Helper loaded: file_helper
INFO - 2024-07-08 15:26:58 --> Helper loaded: form_helper
INFO - 2024-07-08 15:26:58 --> Helper loaded: my_helper
INFO - 2024-07-08 15:26:58 --> Database Driver Class Initialized
INFO - 2024-07-08 15:26:58 --> Session: Class initialized using 'files' driver.
INFO - 2024-07-08 15:26:58 --> Controller Class Initialized
INFO - 2024-07-08 15:26:58 --> Final output sent to browser
DEBUG - 2024-07-08 15:26:58 --> Total execution time: 0.0352
INFO - 2024-07-08 15:26:58 --> Config Class Initialized
INFO - 2024-07-08 15:26:58 --> Hooks Class Initialized
DEBUG - 2024-07-08 15:26:58 --> UTF-8 Support Enabled
INFO - 2024-07-08 15:26:58 --> Utf8 Class Initialized
INFO - 2024-07-08 15:26:58 --> URI Class Initialized
INFO - 2024-07-08 15:26:58 --> Router Class Initialized
INFO - 2024-07-08 15:26:58 --> Output Class Initialized
INFO - 2024-07-08 15:26:58 --> Security Class Initialized
DEBUG - 2024-07-08 15:26:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-07-08 15:26:58 --> Input Class Initialized
INFO - 2024-07-08 15:26:58 --> Language Class Initialized
ERROR - 2024-07-08 15:26:58 --> 404 Page Not Found: /index
INFO - 2024-07-08 15:26:58 --> Config Class Initialized
INFO - 2024-07-08 15:26:58 --> Hooks Class Initialized
DEBUG - 2024-07-08 15:26:58 --> UTF-8 Support Enabled
INFO - 2024-07-08 15:26:58 --> Utf8 Class Initialized
INFO - 2024-07-08 15:26:58 --> URI Class Initialized
INFO - 2024-07-08 15:26:58 --> Router Class Initialized
INFO - 2024-07-08 15:26:58 --> Output Class Initialized
INFO - 2024-07-08 15:26:58 --> Security Class Initialized
DEBUG - 2024-07-08 15:26:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-07-08 15:26:58 --> Input Class Initialized
INFO - 2024-07-08 15:26:58 --> Language Class Initialized
INFO - 2024-07-08 15:26:58 --> Language Class Initialized
INFO - 2024-07-08 15:26:58 --> Config Class Initialized
INFO - 2024-07-08 15:26:58 --> Loader Class Initialized
INFO - 2024-07-08 15:26:58 --> Helper loaded: url_helper
INFO - 2024-07-08 15:26:58 --> Helper loaded: file_helper
INFO - 2024-07-08 15:26:58 --> Helper loaded: form_helper
INFO - 2024-07-08 15:26:58 --> Helper loaded: my_helper
INFO - 2024-07-08 15:26:58 --> Database Driver Class Initialized
INFO - 2024-07-08 15:26:58 --> Session: Class initialized using 'files' driver.
INFO - 2024-07-08 15:26:58 --> Controller Class Initialized
INFO - 2024-07-08 15:27:00 --> Config Class Initialized
INFO - 2024-07-08 15:27:00 --> Hooks Class Initialized
DEBUG - 2024-07-08 15:27:00 --> UTF-8 Support Enabled
INFO - 2024-07-08 15:27:00 --> Utf8 Class Initialized
INFO - 2024-07-08 15:27:00 --> URI Class Initialized
INFO - 2024-07-08 15:27:00 --> Router Class Initialized
INFO - 2024-07-08 15:27:00 --> Output Class Initialized
INFO - 2024-07-08 15:27:00 --> Security Class Initialized
DEBUG - 2024-07-08 15:27:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-07-08 15:27:00 --> Input Class Initialized
INFO - 2024-07-08 15:27:00 --> Language Class Initialized
INFO - 2024-07-08 15:27:00 --> Language Class Initialized
INFO - 2024-07-08 15:27:00 --> Config Class Initialized
INFO - 2024-07-08 15:27:00 --> Loader Class Initialized
INFO - 2024-07-08 15:27:00 --> Helper loaded: url_helper
INFO - 2024-07-08 15:27:00 --> Helper loaded: file_helper
INFO - 2024-07-08 15:27:00 --> Helper loaded: form_helper
INFO - 2024-07-08 15:27:00 --> Helper loaded: my_helper
INFO - 2024-07-08 15:27:00 --> Database Driver Class Initialized
INFO - 2024-07-08 15:27:00 --> Session: Class initialized using 'files' driver.
INFO - 2024-07-08 15:27:00 --> Controller Class Initialized
DEBUG - 2024-07-08 15:27:00 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/data_siswa/views/list.php
DEBUG - 2024-07-08 15:27:00 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-07-08 15:27:00 --> Final output sent to browser
DEBUG - 2024-07-08 15:27:00 --> Total execution time: 0.0349
INFO - 2024-07-08 15:27:00 --> Config Class Initialized
INFO - 2024-07-08 15:27:00 --> Hooks Class Initialized
DEBUG - 2024-07-08 15:27:00 --> UTF-8 Support Enabled
INFO - 2024-07-08 15:27:00 --> Utf8 Class Initialized
INFO - 2024-07-08 15:27:00 --> URI Class Initialized
INFO - 2024-07-08 15:27:00 --> Router Class Initialized
INFO - 2024-07-08 15:27:00 --> Output Class Initialized
INFO - 2024-07-08 15:27:00 --> Security Class Initialized
DEBUG - 2024-07-08 15:27:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-07-08 15:27:00 --> Input Class Initialized
INFO - 2024-07-08 15:27:00 --> Language Class Initialized
ERROR - 2024-07-08 15:27:00 --> 404 Page Not Found: /index
INFO - 2024-07-08 15:27:00 --> Config Class Initialized
INFO - 2024-07-08 15:27:00 --> Hooks Class Initialized
DEBUG - 2024-07-08 15:27:00 --> UTF-8 Support Enabled
INFO - 2024-07-08 15:27:00 --> Utf8 Class Initialized
INFO - 2024-07-08 15:27:00 --> URI Class Initialized
INFO - 2024-07-08 15:27:00 --> Router Class Initialized
INFO - 2024-07-08 15:27:00 --> Output Class Initialized
INFO - 2024-07-08 15:27:00 --> Security Class Initialized
DEBUG - 2024-07-08 15:27:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-07-08 15:27:00 --> Input Class Initialized
INFO - 2024-07-08 15:27:00 --> Language Class Initialized
INFO - 2024-07-08 15:27:00 --> Language Class Initialized
INFO - 2024-07-08 15:27:00 --> Config Class Initialized
INFO - 2024-07-08 15:27:00 --> Loader Class Initialized
INFO - 2024-07-08 15:27:00 --> Helper loaded: url_helper
INFO - 2024-07-08 15:27:00 --> Helper loaded: file_helper
INFO - 2024-07-08 15:27:00 --> Helper loaded: form_helper
INFO - 2024-07-08 15:27:00 --> Helper loaded: my_helper
INFO - 2024-07-08 15:27:00 --> Database Driver Class Initialized
INFO - 2024-07-08 15:27:00 --> Session: Class initialized using 'files' driver.
INFO - 2024-07-08 15:27:00 --> Controller Class Initialized
INFO - 2024-07-08 15:27:09 --> Config Class Initialized
INFO - 2024-07-08 15:27:09 --> Hooks Class Initialized
DEBUG - 2024-07-08 15:27:09 --> UTF-8 Support Enabled
INFO - 2024-07-08 15:27:09 --> Utf8 Class Initialized
INFO - 2024-07-08 15:27:09 --> URI Class Initialized
INFO - 2024-07-08 15:27:09 --> Router Class Initialized
INFO - 2024-07-08 15:27:09 --> Output Class Initialized
INFO - 2024-07-08 15:27:09 --> Security Class Initialized
DEBUG - 2024-07-08 15:27:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-07-08 15:27:09 --> Input Class Initialized
INFO - 2024-07-08 15:27:09 --> Language Class Initialized
INFO - 2024-07-08 15:27:09 --> Language Class Initialized
INFO - 2024-07-08 15:27:09 --> Config Class Initialized
INFO - 2024-07-08 15:27:09 --> Loader Class Initialized
INFO - 2024-07-08 15:27:09 --> Helper loaded: url_helper
INFO - 2024-07-08 15:27:09 --> Helper loaded: file_helper
INFO - 2024-07-08 15:27:09 --> Helper loaded: form_helper
INFO - 2024-07-08 15:27:09 --> Helper loaded: my_helper
INFO - 2024-07-08 15:27:09 --> Database Driver Class Initialized
INFO - 2024-07-08 15:27:09 --> Session: Class initialized using 'files' driver.
INFO - 2024-07-08 15:27:09 --> Controller Class Initialized
DEBUG - 2024-07-08 15:27:09 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/tahun/views/list.php
DEBUG - 2024-07-08 15:27:09 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-07-08 15:27:09 --> Final output sent to browser
DEBUG - 2024-07-08 15:27:09 --> Total execution time: 0.0378
INFO - 2024-07-08 15:27:09 --> Config Class Initialized
INFO - 2024-07-08 15:27:09 --> Hooks Class Initialized
DEBUG - 2024-07-08 15:27:09 --> UTF-8 Support Enabled
INFO - 2024-07-08 15:27:09 --> Utf8 Class Initialized
INFO - 2024-07-08 15:27:09 --> URI Class Initialized
INFO - 2024-07-08 15:27:09 --> Router Class Initialized
INFO - 2024-07-08 15:27:09 --> Output Class Initialized
INFO - 2024-07-08 15:27:09 --> Security Class Initialized
DEBUG - 2024-07-08 15:27:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-07-08 15:27:09 --> Input Class Initialized
INFO - 2024-07-08 15:27:09 --> Language Class Initialized
ERROR - 2024-07-08 15:27:09 --> 404 Page Not Found: /index
INFO - 2024-07-08 15:27:09 --> Config Class Initialized
INFO - 2024-07-08 15:27:09 --> Hooks Class Initialized
DEBUG - 2024-07-08 15:27:09 --> UTF-8 Support Enabled
INFO - 2024-07-08 15:27:09 --> Utf8 Class Initialized
INFO - 2024-07-08 15:27:09 --> URI Class Initialized
INFO - 2024-07-08 15:27:09 --> Router Class Initialized
INFO - 2024-07-08 15:27:09 --> Output Class Initialized
INFO - 2024-07-08 15:27:09 --> Security Class Initialized
DEBUG - 2024-07-08 15:27:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-07-08 15:27:09 --> Input Class Initialized
INFO - 2024-07-08 15:27:09 --> Language Class Initialized
INFO - 2024-07-08 15:27:09 --> Language Class Initialized
INFO - 2024-07-08 15:27:09 --> Config Class Initialized
INFO - 2024-07-08 15:27:09 --> Loader Class Initialized
INFO - 2024-07-08 15:27:09 --> Helper loaded: url_helper
INFO - 2024-07-08 15:27:09 --> Helper loaded: file_helper
INFO - 2024-07-08 15:27:09 --> Helper loaded: form_helper
INFO - 2024-07-08 15:27:09 --> Helper loaded: my_helper
INFO - 2024-07-08 15:27:09 --> Database Driver Class Initialized
INFO - 2024-07-08 15:27:09 --> Session: Class initialized using 'files' driver.
INFO - 2024-07-08 15:27:09 --> Controller Class Initialized
INFO - 2024-07-08 15:27:10 --> Config Class Initialized
INFO - 2024-07-08 15:27:10 --> Hooks Class Initialized
DEBUG - 2024-07-08 15:27:10 --> UTF-8 Support Enabled
INFO - 2024-07-08 15:27:10 --> Utf8 Class Initialized
INFO - 2024-07-08 15:27:10 --> URI Class Initialized
INFO - 2024-07-08 15:27:10 --> Router Class Initialized
INFO - 2024-07-08 15:27:10 --> Output Class Initialized
INFO - 2024-07-08 15:27:10 --> Security Class Initialized
DEBUG - 2024-07-08 15:27:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-07-08 15:27:10 --> Input Class Initialized
INFO - 2024-07-08 15:27:10 --> Language Class Initialized
INFO - 2024-07-08 15:27:10 --> Language Class Initialized
INFO - 2024-07-08 15:27:10 --> Config Class Initialized
INFO - 2024-07-08 15:27:10 --> Loader Class Initialized
INFO - 2024-07-08 15:27:10 --> Helper loaded: url_helper
INFO - 2024-07-08 15:27:10 --> Helper loaded: file_helper
INFO - 2024-07-08 15:27:10 --> Helper loaded: form_helper
INFO - 2024-07-08 15:27:10 --> Helper loaded: my_helper
INFO - 2024-07-08 15:27:10 --> Database Driver Class Initialized
INFO - 2024-07-08 15:27:10 --> Session: Class initialized using 'files' driver.
INFO - 2024-07-08 15:27:10 --> Controller Class Initialized
INFO - 2024-07-08 15:27:10 --> Final output sent to browser
DEBUG - 2024-07-08 15:27:10 --> Total execution time: 0.0630
INFO - 2024-07-08 15:27:10 --> Config Class Initialized
INFO - 2024-07-08 15:27:10 --> Hooks Class Initialized
DEBUG - 2024-07-08 15:27:10 --> UTF-8 Support Enabled
INFO - 2024-07-08 15:27:10 --> Utf8 Class Initialized
INFO - 2024-07-08 15:27:10 --> URI Class Initialized
INFO - 2024-07-08 15:27:10 --> Router Class Initialized
INFO - 2024-07-08 15:27:10 --> Output Class Initialized
INFO - 2024-07-08 15:27:10 --> Security Class Initialized
DEBUG - 2024-07-08 15:27:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-07-08 15:27:10 --> Input Class Initialized
INFO - 2024-07-08 15:27:10 --> Language Class Initialized
ERROR - 2024-07-08 15:27:10 --> 404 Page Not Found: /index
INFO - 2024-07-08 15:27:11 --> Config Class Initialized
INFO - 2024-07-08 15:27:11 --> Hooks Class Initialized
DEBUG - 2024-07-08 15:27:11 --> UTF-8 Support Enabled
INFO - 2024-07-08 15:27:11 --> Utf8 Class Initialized
INFO - 2024-07-08 15:27:11 --> URI Class Initialized
INFO - 2024-07-08 15:27:11 --> Router Class Initialized
INFO - 2024-07-08 15:27:11 --> Output Class Initialized
INFO - 2024-07-08 15:27:11 --> Security Class Initialized
DEBUG - 2024-07-08 15:27:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-07-08 15:27:11 --> Input Class Initialized
INFO - 2024-07-08 15:27:11 --> Language Class Initialized
INFO - 2024-07-08 15:27:11 --> Language Class Initialized
INFO - 2024-07-08 15:27:11 --> Config Class Initialized
INFO - 2024-07-08 15:27:11 --> Loader Class Initialized
INFO - 2024-07-08 15:27:11 --> Helper loaded: url_helper
INFO - 2024-07-08 15:27:11 --> Helper loaded: file_helper
INFO - 2024-07-08 15:27:11 --> Helper loaded: form_helper
INFO - 2024-07-08 15:27:11 --> Helper loaded: my_helper
INFO - 2024-07-08 15:27:11 --> Database Driver Class Initialized
INFO - 2024-07-08 15:27:11 --> Session: Class initialized using 'files' driver.
INFO - 2024-07-08 15:27:11 --> Controller Class Initialized
INFO - 2024-07-08 15:27:13 --> Config Class Initialized
INFO - 2024-07-08 15:27:13 --> Hooks Class Initialized
DEBUG - 2024-07-08 15:27:13 --> UTF-8 Support Enabled
INFO - 2024-07-08 15:27:13 --> Utf8 Class Initialized
INFO - 2024-07-08 15:27:13 --> URI Class Initialized
INFO - 2024-07-08 15:27:13 --> Router Class Initialized
INFO - 2024-07-08 15:27:13 --> Output Class Initialized
INFO - 2024-07-08 15:27:13 --> Security Class Initialized
DEBUG - 2024-07-08 15:27:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-07-08 15:27:13 --> Input Class Initialized
INFO - 2024-07-08 15:27:13 --> Language Class Initialized
INFO - 2024-07-08 15:27:13 --> Language Class Initialized
INFO - 2024-07-08 15:27:13 --> Config Class Initialized
INFO - 2024-07-08 15:27:13 --> Loader Class Initialized
INFO - 2024-07-08 15:27:13 --> Helper loaded: url_helper
INFO - 2024-07-08 15:27:13 --> Helper loaded: file_helper
INFO - 2024-07-08 15:27:13 --> Helper loaded: form_helper
INFO - 2024-07-08 15:27:13 --> Helper loaded: my_helper
INFO - 2024-07-08 15:27:13 --> Database Driver Class Initialized
INFO - 2024-07-08 15:27:13 --> Session: Class initialized using 'files' driver.
INFO - 2024-07-08 15:27:13 --> Controller Class Initialized
DEBUG - 2024-07-08 15:27:13 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/data_siswa/views/list.php
DEBUG - 2024-07-08 15:27:13 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-07-08 15:27:13 --> Final output sent to browser
DEBUG - 2024-07-08 15:27:13 --> Total execution time: 0.0386
INFO - 2024-07-08 15:27:13 --> Config Class Initialized
INFO - 2024-07-08 15:27:13 --> Hooks Class Initialized
DEBUG - 2024-07-08 15:27:13 --> UTF-8 Support Enabled
INFO - 2024-07-08 15:27:13 --> Utf8 Class Initialized
INFO - 2024-07-08 15:27:13 --> URI Class Initialized
INFO - 2024-07-08 15:27:13 --> Router Class Initialized
INFO - 2024-07-08 15:27:13 --> Output Class Initialized
INFO - 2024-07-08 15:27:13 --> Security Class Initialized
DEBUG - 2024-07-08 15:27:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-07-08 15:27:13 --> Input Class Initialized
INFO - 2024-07-08 15:27:13 --> Language Class Initialized
ERROR - 2024-07-08 15:27:13 --> 404 Page Not Found: /index
INFO - 2024-07-08 15:27:13 --> Config Class Initialized
INFO - 2024-07-08 15:27:13 --> Hooks Class Initialized
DEBUG - 2024-07-08 15:27:13 --> UTF-8 Support Enabled
INFO - 2024-07-08 15:27:13 --> Utf8 Class Initialized
INFO - 2024-07-08 15:27:13 --> URI Class Initialized
INFO - 2024-07-08 15:27:13 --> Router Class Initialized
INFO - 2024-07-08 15:27:13 --> Output Class Initialized
INFO - 2024-07-08 15:27:13 --> Security Class Initialized
DEBUG - 2024-07-08 15:27:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-07-08 15:27:13 --> Input Class Initialized
INFO - 2024-07-08 15:27:13 --> Language Class Initialized
INFO - 2024-07-08 15:27:13 --> Language Class Initialized
INFO - 2024-07-08 15:27:13 --> Config Class Initialized
INFO - 2024-07-08 15:27:13 --> Loader Class Initialized
INFO - 2024-07-08 15:27:13 --> Helper loaded: url_helper
INFO - 2024-07-08 15:27:13 --> Helper loaded: file_helper
INFO - 2024-07-08 15:27:13 --> Helper loaded: form_helper
INFO - 2024-07-08 15:27:13 --> Helper loaded: my_helper
INFO - 2024-07-08 15:27:13 --> Database Driver Class Initialized
INFO - 2024-07-08 15:27:13 --> Session: Class initialized using 'files' driver.
INFO - 2024-07-08 15:27:13 --> Controller Class Initialized
INFO - 2024-07-08 15:27:15 --> Config Class Initialized
INFO - 2024-07-08 15:27:15 --> Hooks Class Initialized
DEBUG - 2024-07-08 15:27:15 --> UTF-8 Support Enabled
INFO - 2024-07-08 15:27:15 --> Utf8 Class Initialized
INFO - 2024-07-08 15:27:15 --> URI Class Initialized
INFO - 2024-07-08 15:27:15 --> Router Class Initialized
INFO - 2024-07-08 15:27:15 --> Output Class Initialized
INFO - 2024-07-08 15:27:15 --> Security Class Initialized
DEBUG - 2024-07-08 15:27:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-07-08 15:27:15 --> Input Class Initialized
INFO - 2024-07-08 15:27:15 --> Language Class Initialized
INFO - 2024-07-08 15:27:15 --> Language Class Initialized
INFO - 2024-07-08 15:27:15 --> Config Class Initialized
INFO - 2024-07-08 15:27:15 --> Loader Class Initialized
INFO - 2024-07-08 15:27:15 --> Helper loaded: url_helper
INFO - 2024-07-08 15:27:15 --> Helper loaded: file_helper
INFO - 2024-07-08 15:27:15 --> Helper loaded: form_helper
INFO - 2024-07-08 15:27:15 --> Helper loaded: my_helper
INFO - 2024-07-08 15:27:15 --> Database Driver Class Initialized
INFO - 2024-07-08 15:27:15 --> Session: Class initialized using 'files' driver.
INFO - 2024-07-08 15:27:15 --> Controller Class Initialized
INFO - 2024-07-08 15:27:22 --> Config Class Initialized
INFO - 2024-07-08 15:27:22 --> Hooks Class Initialized
DEBUG - 2024-07-08 15:27:22 --> UTF-8 Support Enabled
INFO - 2024-07-08 15:27:22 --> Utf8 Class Initialized
INFO - 2024-07-08 15:27:22 --> URI Class Initialized
INFO - 2024-07-08 15:27:22 --> Router Class Initialized
INFO - 2024-07-08 15:27:22 --> Output Class Initialized
INFO - 2024-07-08 15:27:22 --> Security Class Initialized
DEBUG - 2024-07-08 15:27:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-07-08 15:27:22 --> Input Class Initialized
INFO - 2024-07-08 15:27:22 --> Language Class Initialized
INFO - 2024-07-08 15:27:22 --> Language Class Initialized
INFO - 2024-07-08 15:27:22 --> Config Class Initialized
INFO - 2024-07-08 15:27:22 --> Loader Class Initialized
INFO - 2024-07-08 15:27:22 --> Helper loaded: url_helper
INFO - 2024-07-08 15:27:22 --> Helper loaded: file_helper
INFO - 2024-07-08 15:27:22 --> Helper loaded: form_helper
INFO - 2024-07-08 15:27:22 --> Helper loaded: my_helper
INFO - 2024-07-08 15:27:22 --> Database Driver Class Initialized
INFO - 2024-07-08 15:27:22 --> Session: Class initialized using 'files' driver.
INFO - 2024-07-08 15:27:22 --> Controller Class Initialized
INFO - 2024-07-08 15:27:23 --> Config Class Initialized
INFO - 2024-07-08 15:27:23 --> Hooks Class Initialized
DEBUG - 2024-07-08 15:27:23 --> UTF-8 Support Enabled
INFO - 2024-07-08 15:27:23 --> Utf8 Class Initialized
INFO - 2024-07-08 15:27:23 --> URI Class Initialized
INFO - 2024-07-08 15:27:23 --> Router Class Initialized
INFO - 2024-07-08 15:27:23 --> Output Class Initialized
INFO - 2024-07-08 15:27:23 --> Security Class Initialized
DEBUG - 2024-07-08 15:27:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-07-08 15:27:23 --> Input Class Initialized
INFO - 2024-07-08 15:27:23 --> Language Class Initialized
INFO - 2024-07-08 15:27:23 --> Language Class Initialized
INFO - 2024-07-08 15:27:23 --> Config Class Initialized
INFO - 2024-07-08 15:27:23 --> Loader Class Initialized
INFO - 2024-07-08 15:27:23 --> Helper loaded: url_helper
INFO - 2024-07-08 15:27:23 --> Helper loaded: file_helper
INFO - 2024-07-08 15:27:23 --> Helper loaded: form_helper
INFO - 2024-07-08 15:27:23 --> Helper loaded: my_helper
INFO - 2024-07-08 15:27:23 --> Database Driver Class Initialized
INFO - 2024-07-08 15:27:23 --> Session: Class initialized using 'files' driver.
INFO - 2024-07-08 15:27:23 --> Controller Class Initialized
INFO - 2024-07-08 15:27:26 --> Config Class Initialized
INFO - 2024-07-08 15:27:26 --> Hooks Class Initialized
DEBUG - 2024-07-08 15:27:26 --> UTF-8 Support Enabled
INFO - 2024-07-08 15:27:26 --> Utf8 Class Initialized
INFO - 2024-07-08 15:27:26 --> URI Class Initialized
INFO - 2024-07-08 15:27:26 --> Router Class Initialized
INFO - 2024-07-08 15:27:26 --> Output Class Initialized
INFO - 2024-07-08 15:27:26 --> Security Class Initialized
DEBUG - 2024-07-08 15:27:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-07-08 15:27:26 --> Input Class Initialized
INFO - 2024-07-08 15:27:26 --> Language Class Initialized
INFO - 2024-07-08 15:27:26 --> Language Class Initialized
INFO - 2024-07-08 15:27:26 --> Config Class Initialized
INFO - 2024-07-08 15:27:26 --> Loader Class Initialized
INFO - 2024-07-08 15:27:26 --> Helper loaded: url_helper
INFO - 2024-07-08 15:27:26 --> Helper loaded: file_helper
INFO - 2024-07-08 15:27:26 --> Helper loaded: form_helper
INFO - 2024-07-08 15:27:26 --> Helper loaded: my_helper
INFO - 2024-07-08 15:27:26 --> Database Driver Class Initialized
INFO - 2024-07-08 15:27:26 --> Session: Class initialized using 'files' driver.
INFO - 2024-07-08 15:27:26 --> Controller Class Initialized
INFO - 2024-07-08 15:27:26 --> Final output sent to browser
DEBUG - 2024-07-08 15:27:26 --> Total execution time: 0.1026
INFO - 2024-07-08 15:27:26 --> Config Class Initialized
INFO - 2024-07-08 15:27:26 --> Hooks Class Initialized
DEBUG - 2024-07-08 15:27:26 --> UTF-8 Support Enabled
INFO - 2024-07-08 15:27:26 --> Utf8 Class Initialized
INFO - 2024-07-08 15:27:26 --> URI Class Initialized
INFO - 2024-07-08 15:27:26 --> Router Class Initialized
INFO - 2024-07-08 15:27:26 --> Output Class Initialized
INFO - 2024-07-08 15:27:26 --> Security Class Initialized
DEBUG - 2024-07-08 15:27:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-07-08 15:27:26 --> Input Class Initialized
INFO - 2024-07-08 15:27:26 --> Language Class Initialized
ERROR - 2024-07-08 15:27:26 --> 404 Page Not Found: /index
INFO - 2024-07-08 15:27:26 --> Config Class Initialized
INFO - 2024-07-08 15:27:26 --> Hooks Class Initialized
DEBUG - 2024-07-08 15:27:26 --> UTF-8 Support Enabled
INFO - 2024-07-08 15:27:26 --> Utf8 Class Initialized
INFO - 2024-07-08 15:27:26 --> URI Class Initialized
INFO - 2024-07-08 15:27:26 --> Router Class Initialized
INFO - 2024-07-08 15:27:26 --> Output Class Initialized
INFO - 2024-07-08 15:27:26 --> Security Class Initialized
DEBUG - 2024-07-08 15:27:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-07-08 15:27:26 --> Input Class Initialized
INFO - 2024-07-08 15:27:26 --> Language Class Initialized
INFO - 2024-07-08 15:27:26 --> Language Class Initialized
INFO - 2024-07-08 15:27:26 --> Config Class Initialized
INFO - 2024-07-08 15:27:26 --> Loader Class Initialized
INFO - 2024-07-08 15:27:26 --> Helper loaded: url_helper
INFO - 2024-07-08 15:27:26 --> Helper loaded: file_helper
INFO - 2024-07-08 15:27:26 --> Helper loaded: form_helper
INFO - 2024-07-08 15:27:26 --> Helper loaded: my_helper
INFO - 2024-07-08 15:27:26 --> Database Driver Class Initialized
INFO - 2024-07-08 15:27:27 --> Session: Class initialized using 'files' driver.
INFO - 2024-07-08 15:27:27 --> Controller Class Initialized
INFO - 2024-07-08 15:27:28 --> Config Class Initialized
INFO - 2024-07-08 15:27:28 --> Hooks Class Initialized
DEBUG - 2024-07-08 15:27:28 --> UTF-8 Support Enabled
INFO - 2024-07-08 15:27:28 --> Utf8 Class Initialized
INFO - 2024-07-08 15:27:28 --> URI Class Initialized
INFO - 2024-07-08 15:27:28 --> Router Class Initialized
INFO - 2024-07-08 15:27:28 --> Output Class Initialized
INFO - 2024-07-08 15:27:28 --> Security Class Initialized
DEBUG - 2024-07-08 15:27:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-07-08 15:27:28 --> Input Class Initialized
INFO - 2024-07-08 15:27:28 --> Language Class Initialized
INFO - 2024-07-08 15:27:28 --> Language Class Initialized
INFO - 2024-07-08 15:27:28 --> Config Class Initialized
INFO - 2024-07-08 15:27:28 --> Loader Class Initialized
INFO - 2024-07-08 15:27:28 --> Helper loaded: url_helper
INFO - 2024-07-08 15:27:28 --> Helper loaded: file_helper
INFO - 2024-07-08 15:27:28 --> Helper loaded: form_helper
INFO - 2024-07-08 15:27:28 --> Helper loaded: my_helper
INFO - 2024-07-08 15:27:28 --> Database Driver Class Initialized
INFO - 2024-07-08 15:27:28 --> Session: Class initialized using 'files' driver.
INFO - 2024-07-08 15:27:28 --> Controller Class Initialized
INFO - 2024-07-08 15:27:29 --> Config Class Initialized
INFO - 2024-07-08 15:27:29 --> Hooks Class Initialized
DEBUG - 2024-07-08 15:27:29 --> UTF-8 Support Enabled
INFO - 2024-07-08 15:27:29 --> Utf8 Class Initialized
INFO - 2024-07-08 15:27:29 --> URI Class Initialized
INFO - 2024-07-08 15:27:29 --> Router Class Initialized
INFO - 2024-07-08 15:27:29 --> Output Class Initialized
INFO - 2024-07-08 15:27:29 --> Security Class Initialized
DEBUG - 2024-07-08 15:27:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-07-08 15:27:29 --> Input Class Initialized
INFO - 2024-07-08 15:27:29 --> Language Class Initialized
INFO - 2024-07-08 15:27:29 --> Language Class Initialized
INFO - 2024-07-08 15:27:29 --> Config Class Initialized
INFO - 2024-07-08 15:27:29 --> Loader Class Initialized
INFO - 2024-07-08 15:27:29 --> Helper loaded: url_helper
INFO - 2024-07-08 15:27:29 --> Helper loaded: file_helper
INFO - 2024-07-08 15:27:29 --> Helper loaded: form_helper
INFO - 2024-07-08 15:27:29 --> Helper loaded: my_helper
INFO - 2024-07-08 15:27:29 --> Database Driver Class Initialized
INFO - 2024-07-08 15:27:29 --> Session: Class initialized using 'files' driver.
INFO - 2024-07-08 15:27:29 --> Controller Class Initialized
INFO - 2024-07-08 15:27:32 --> Config Class Initialized
INFO - 2024-07-08 15:27:32 --> Hooks Class Initialized
DEBUG - 2024-07-08 15:27:32 --> UTF-8 Support Enabled
INFO - 2024-07-08 15:27:32 --> Utf8 Class Initialized
INFO - 2024-07-08 15:27:32 --> URI Class Initialized
INFO - 2024-07-08 15:27:32 --> Router Class Initialized
INFO - 2024-07-08 15:27:32 --> Output Class Initialized
INFO - 2024-07-08 15:27:32 --> Security Class Initialized
DEBUG - 2024-07-08 15:27:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-07-08 15:27:32 --> Input Class Initialized
INFO - 2024-07-08 15:27:32 --> Language Class Initialized
INFO - 2024-07-08 15:27:32 --> Language Class Initialized
INFO - 2024-07-08 15:27:32 --> Config Class Initialized
INFO - 2024-07-08 15:27:32 --> Loader Class Initialized
INFO - 2024-07-08 15:27:32 --> Helper loaded: url_helper
INFO - 2024-07-08 15:27:32 --> Helper loaded: file_helper
INFO - 2024-07-08 15:27:32 --> Helper loaded: form_helper
INFO - 2024-07-08 15:27:32 --> Helper loaded: my_helper
INFO - 2024-07-08 15:27:32 --> Database Driver Class Initialized
INFO - 2024-07-08 15:27:32 --> Session: Class initialized using 'files' driver.
INFO - 2024-07-08 15:27:32 --> Controller Class Initialized
INFO - 2024-07-08 15:27:32 --> Final output sent to browser
DEBUG - 2024-07-08 15:27:32 --> Total execution time: 0.0393
INFO - 2024-07-08 15:27:32 --> Config Class Initialized
INFO - 2024-07-08 15:27:32 --> Hooks Class Initialized
DEBUG - 2024-07-08 15:27:32 --> UTF-8 Support Enabled
INFO - 2024-07-08 15:27:32 --> Utf8 Class Initialized
INFO - 2024-07-08 15:27:32 --> URI Class Initialized
INFO - 2024-07-08 15:27:32 --> Router Class Initialized
INFO - 2024-07-08 15:27:32 --> Output Class Initialized
INFO - 2024-07-08 15:27:32 --> Security Class Initialized
DEBUG - 2024-07-08 15:27:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-07-08 15:27:32 --> Input Class Initialized
INFO - 2024-07-08 15:27:32 --> Language Class Initialized
ERROR - 2024-07-08 15:27:32 --> 404 Page Not Found: /index
INFO - 2024-07-08 15:27:32 --> Config Class Initialized
INFO - 2024-07-08 15:27:32 --> Hooks Class Initialized
DEBUG - 2024-07-08 15:27:32 --> UTF-8 Support Enabled
INFO - 2024-07-08 15:27:32 --> Utf8 Class Initialized
INFO - 2024-07-08 15:27:32 --> URI Class Initialized
INFO - 2024-07-08 15:27:32 --> Router Class Initialized
INFO - 2024-07-08 15:27:32 --> Output Class Initialized
INFO - 2024-07-08 15:27:32 --> Security Class Initialized
DEBUG - 2024-07-08 15:27:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-07-08 15:27:32 --> Input Class Initialized
INFO - 2024-07-08 15:27:32 --> Language Class Initialized
INFO - 2024-07-08 15:27:32 --> Language Class Initialized
INFO - 2024-07-08 15:27:32 --> Config Class Initialized
INFO - 2024-07-08 15:27:32 --> Loader Class Initialized
INFO - 2024-07-08 15:27:32 --> Helper loaded: url_helper
INFO - 2024-07-08 15:27:32 --> Helper loaded: file_helper
INFO - 2024-07-08 15:27:32 --> Helper loaded: form_helper
INFO - 2024-07-08 15:27:32 --> Helper loaded: my_helper
INFO - 2024-07-08 15:27:32 --> Database Driver Class Initialized
INFO - 2024-07-08 15:27:32 --> Session: Class initialized using 'files' driver.
INFO - 2024-07-08 15:27:32 --> Controller Class Initialized
INFO - 2024-07-08 15:27:35 --> Config Class Initialized
INFO - 2024-07-08 15:27:35 --> Hooks Class Initialized
DEBUG - 2024-07-08 15:27:35 --> UTF-8 Support Enabled
INFO - 2024-07-08 15:27:35 --> Utf8 Class Initialized
INFO - 2024-07-08 15:27:35 --> URI Class Initialized
INFO - 2024-07-08 15:27:35 --> Router Class Initialized
INFO - 2024-07-08 15:27:35 --> Output Class Initialized
INFO - 2024-07-08 15:27:35 --> Security Class Initialized
DEBUG - 2024-07-08 15:27:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-07-08 15:27:35 --> Input Class Initialized
INFO - 2024-07-08 15:27:35 --> Language Class Initialized
INFO - 2024-07-08 15:27:35 --> Language Class Initialized
INFO - 2024-07-08 15:27:35 --> Config Class Initialized
INFO - 2024-07-08 15:27:35 --> Loader Class Initialized
INFO - 2024-07-08 15:27:35 --> Helper loaded: url_helper
INFO - 2024-07-08 15:27:35 --> Helper loaded: file_helper
INFO - 2024-07-08 15:27:35 --> Helper loaded: form_helper
INFO - 2024-07-08 15:27:35 --> Helper loaded: my_helper
INFO - 2024-07-08 15:27:35 --> Database Driver Class Initialized
INFO - 2024-07-08 15:27:35 --> Session: Class initialized using 'files' driver.
INFO - 2024-07-08 15:27:35 --> Controller Class Initialized
INFO - 2024-07-08 15:27:38 --> Config Class Initialized
INFO - 2024-07-08 15:27:38 --> Hooks Class Initialized
DEBUG - 2024-07-08 15:27:38 --> UTF-8 Support Enabled
INFO - 2024-07-08 15:27:38 --> Utf8 Class Initialized
INFO - 2024-07-08 15:27:38 --> URI Class Initialized
INFO - 2024-07-08 15:27:38 --> Router Class Initialized
INFO - 2024-07-08 15:27:38 --> Output Class Initialized
INFO - 2024-07-08 15:27:38 --> Security Class Initialized
DEBUG - 2024-07-08 15:27:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-07-08 15:27:38 --> Input Class Initialized
INFO - 2024-07-08 15:27:38 --> Language Class Initialized
INFO - 2024-07-08 15:27:38 --> Language Class Initialized
INFO - 2024-07-08 15:27:38 --> Config Class Initialized
INFO - 2024-07-08 15:27:38 --> Loader Class Initialized
INFO - 2024-07-08 15:27:38 --> Helper loaded: url_helper
INFO - 2024-07-08 15:27:38 --> Helper loaded: file_helper
INFO - 2024-07-08 15:27:38 --> Helper loaded: form_helper
INFO - 2024-07-08 15:27:38 --> Helper loaded: my_helper
INFO - 2024-07-08 15:27:38 --> Database Driver Class Initialized
INFO - 2024-07-08 15:27:38 --> Session: Class initialized using 'files' driver.
INFO - 2024-07-08 15:27:38 --> Controller Class Initialized
INFO - 2024-07-08 15:27:38 --> Final output sent to browser
DEBUG - 2024-07-08 15:27:38 --> Total execution time: 0.1081
INFO - 2024-07-08 15:27:38 --> Config Class Initialized
INFO - 2024-07-08 15:27:38 --> Hooks Class Initialized
DEBUG - 2024-07-08 15:27:38 --> UTF-8 Support Enabled
INFO - 2024-07-08 15:27:38 --> Utf8 Class Initialized
INFO - 2024-07-08 15:27:38 --> URI Class Initialized
INFO - 2024-07-08 15:27:38 --> Router Class Initialized
INFO - 2024-07-08 15:27:38 --> Output Class Initialized
INFO - 2024-07-08 15:27:38 --> Security Class Initialized
DEBUG - 2024-07-08 15:27:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-07-08 15:27:38 --> Input Class Initialized
INFO - 2024-07-08 15:27:38 --> Language Class Initialized
ERROR - 2024-07-08 15:27:38 --> 404 Page Not Found: /index
INFO - 2024-07-08 15:27:38 --> Config Class Initialized
INFO - 2024-07-08 15:27:38 --> Hooks Class Initialized
DEBUG - 2024-07-08 15:27:38 --> UTF-8 Support Enabled
INFO - 2024-07-08 15:27:38 --> Utf8 Class Initialized
INFO - 2024-07-08 15:27:38 --> URI Class Initialized
INFO - 2024-07-08 15:27:38 --> Router Class Initialized
INFO - 2024-07-08 15:27:38 --> Output Class Initialized
INFO - 2024-07-08 15:27:38 --> Security Class Initialized
DEBUG - 2024-07-08 15:27:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-07-08 15:27:38 --> Input Class Initialized
INFO - 2024-07-08 15:27:38 --> Language Class Initialized
INFO - 2024-07-08 15:27:38 --> Language Class Initialized
INFO - 2024-07-08 15:27:38 --> Config Class Initialized
INFO - 2024-07-08 15:27:38 --> Loader Class Initialized
INFO - 2024-07-08 15:27:38 --> Helper loaded: url_helper
INFO - 2024-07-08 15:27:38 --> Helper loaded: file_helper
INFO - 2024-07-08 15:27:38 --> Helper loaded: form_helper
INFO - 2024-07-08 15:27:38 --> Helper loaded: my_helper
INFO - 2024-07-08 15:27:38 --> Database Driver Class Initialized
INFO - 2024-07-08 15:27:38 --> Session: Class initialized using 'files' driver.
INFO - 2024-07-08 15:27:38 --> Controller Class Initialized
INFO - 2024-07-08 15:27:41 --> Config Class Initialized
INFO - 2024-07-08 15:27:41 --> Hooks Class Initialized
DEBUG - 2024-07-08 15:27:41 --> UTF-8 Support Enabled
INFO - 2024-07-08 15:27:41 --> Utf8 Class Initialized
INFO - 2024-07-08 15:27:41 --> URI Class Initialized
INFO - 2024-07-08 15:27:41 --> Router Class Initialized
INFO - 2024-07-08 15:27:41 --> Output Class Initialized
INFO - 2024-07-08 15:27:41 --> Security Class Initialized
DEBUG - 2024-07-08 15:27:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-07-08 15:27:41 --> Input Class Initialized
INFO - 2024-07-08 15:27:41 --> Language Class Initialized
INFO - 2024-07-08 15:27:41 --> Language Class Initialized
INFO - 2024-07-08 15:27:41 --> Config Class Initialized
INFO - 2024-07-08 15:27:41 --> Loader Class Initialized
INFO - 2024-07-08 15:27:41 --> Helper loaded: url_helper
INFO - 2024-07-08 15:27:41 --> Helper loaded: file_helper
INFO - 2024-07-08 15:27:41 --> Helper loaded: form_helper
INFO - 2024-07-08 15:27:41 --> Helper loaded: my_helper
INFO - 2024-07-08 15:27:41 --> Database Driver Class Initialized
INFO - 2024-07-08 15:27:41 --> Session: Class initialized using 'files' driver.
INFO - 2024-07-08 15:27:41 --> Controller Class Initialized
INFO - 2024-07-08 15:29:17 --> Config Class Initialized
INFO - 2024-07-08 15:29:17 --> Hooks Class Initialized
DEBUG - 2024-07-08 15:29:17 --> UTF-8 Support Enabled
INFO - 2024-07-08 15:29:17 --> Utf8 Class Initialized
INFO - 2024-07-08 15:29:17 --> URI Class Initialized
INFO - 2024-07-08 15:29:17 --> Router Class Initialized
INFO - 2024-07-08 15:29:17 --> Output Class Initialized
INFO - 2024-07-08 15:29:17 --> Security Class Initialized
DEBUG - 2024-07-08 15:29:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-07-08 15:29:17 --> Input Class Initialized
INFO - 2024-07-08 15:29:17 --> Language Class Initialized
INFO - 2024-07-08 15:29:17 --> Language Class Initialized
INFO - 2024-07-08 15:29:17 --> Config Class Initialized
INFO - 2024-07-08 15:29:17 --> Loader Class Initialized
INFO - 2024-07-08 15:29:17 --> Helper loaded: url_helper
INFO - 2024-07-08 15:29:17 --> Helper loaded: file_helper
INFO - 2024-07-08 15:29:17 --> Helper loaded: form_helper
INFO - 2024-07-08 15:29:17 --> Helper loaded: my_helper
INFO - 2024-07-08 15:29:17 --> Database Driver Class Initialized
INFO - 2024-07-08 15:29:17 --> Session: Class initialized using 'files' driver.
INFO - 2024-07-08 15:29:17 --> Controller Class Initialized
INFO - 2024-07-08 15:29:17 --> Final output sent to browser
DEBUG - 2024-07-08 15:29:17 --> Total execution time: 0.0388
INFO - 2024-07-08 15:29:17 --> Config Class Initialized
INFO - 2024-07-08 15:29:17 --> Hooks Class Initialized
DEBUG - 2024-07-08 15:29:17 --> UTF-8 Support Enabled
INFO - 2024-07-08 15:29:17 --> Utf8 Class Initialized
INFO - 2024-07-08 15:29:17 --> URI Class Initialized
INFO - 2024-07-08 15:29:17 --> Router Class Initialized
INFO - 2024-07-08 15:29:17 --> Output Class Initialized
INFO - 2024-07-08 15:29:17 --> Security Class Initialized
DEBUG - 2024-07-08 15:29:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-07-08 15:29:17 --> Input Class Initialized
INFO - 2024-07-08 15:29:17 --> Language Class Initialized
ERROR - 2024-07-08 15:29:17 --> 404 Page Not Found: /index
INFO - 2024-07-08 15:29:17 --> Config Class Initialized
INFO - 2024-07-08 15:29:17 --> Hooks Class Initialized
DEBUG - 2024-07-08 15:29:17 --> UTF-8 Support Enabled
INFO - 2024-07-08 15:29:17 --> Utf8 Class Initialized
INFO - 2024-07-08 15:29:17 --> URI Class Initialized
INFO - 2024-07-08 15:29:17 --> Router Class Initialized
INFO - 2024-07-08 15:29:17 --> Output Class Initialized
INFO - 2024-07-08 15:29:17 --> Security Class Initialized
DEBUG - 2024-07-08 15:29:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-07-08 15:29:17 --> Input Class Initialized
INFO - 2024-07-08 15:29:17 --> Language Class Initialized
INFO - 2024-07-08 15:29:17 --> Language Class Initialized
INFO - 2024-07-08 15:29:17 --> Config Class Initialized
INFO - 2024-07-08 15:29:17 --> Loader Class Initialized
INFO - 2024-07-08 15:29:17 --> Helper loaded: url_helper
INFO - 2024-07-08 15:29:17 --> Helper loaded: file_helper
INFO - 2024-07-08 15:29:17 --> Helper loaded: form_helper
INFO - 2024-07-08 15:29:17 --> Helper loaded: my_helper
INFO - 2024-07-08 15:29:17 --> Database Driver Class Initialized
INFO - 2024-07-08 15:29:17 --> Session: Class initialized using 'files' driver.
INFO - 2024-07-08 15:29:17 --> Controller Class Initialized
INFO - 2024-07-08 15:29:19 --> Config Class Initialized
INFO - 2024-07-08 15:29:19 --> Hooks Class Initialized
DEBUG - 2024-07-08 15:29:19 --> UTF-8 Support Enabled
INFO - 2024-07-08 15:29:19 --> Utf8 Class Initialized
INFO - 2024-07-08 15:29:19 --> URI Class Initialized
INFO - 2024-07-08 15:29:19 --> Router Class Initialized
INFO - 2024-07-08 15:29:19 --> Output Class Initialized
INFO - 2024-07-08 15:29:19 --> Security Class Initialized
DEBUG - 2024-07-08 15:29:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-07-08 15:29:19 --> Input Class Initialized
INFO - 2024-07-08 15:29:19 --> Language Class Initialized
INFO - 2024-07-08 15:29:19 --> Language Class Initialized
INFO - 2024-07-08 15:29:19 --> Config Class Initialized
INFO - 2024-07-08 15:29:19 --> Loader Class Initialized
INFO - 2024-07-08 15:29:19 --> Helper loaded: url_helper
INFO - 2024-07-08 15:29:19 --> Helper loaded: file_helper
INFO - 2024-07-08 15:29:19 --> Helper loaded: form_helper
INFO - 2024-07-08 15:29:19 --> Helper loaded: my_helper
INFO - 2024-07-08 15:29:19 --> Database Driver Class Initialized
INFO - 2024-07-08 15:29:19 --> Session: Class initialized using 'files' driver.
INFO - 2024-07-08 15:29:19 --> Controller Class Initialized
INFO - 2024-07-08 15:29:21 --> Config Class Initialized
INFO - 2024-07-08 15:29:21 --> Hooks Class Initialized
DEBUG - 2024-07-08 15:29:21 --> UTF-8 Support Enabled
INFO - 2024-07-08 15:29:21 --> Utf8 Class Initialized
INFO - 2024-07-08 15:29:21 --> URI Class Initialized
INFO - 2024-07-08 15:29:21 --> Router Class Initialized
INFO - 2024-07-08 15:29:21 --> Output Class Initialized
INFO - 2024-07-08 15:29:21 --> Security Class Initialized
DEBUG - 2024-07-08 15:29:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-07-08 15:29:21 --> Input Class Initialized
INFO - 2024-07-08 15:29:21 --> Language Class Initialized
INFO - 2024-07-08 15:29:21 --> Language Class Initialized
INFO - 2024-07-08 15:29:21 --> Config Class Initialized
INFO - 2024-07-08 15:29:21 --> Loader Class Initialized
INFO - 2024-07-08 15:29:21 --> Helper loaded: url_helper
INFO - 2024-07-08 15:29:21 --> Helper loaded: file_helper
INFO - 2024-07-08 15:29:21 --> Helper loaded: form_helper
INFO - 2024-07-08 15:29:21 --> Helper loaded: my_helper
INFO - 2024-07-08 15:29:21 --> Database Driver Class Initialized
INFO - 2024-07-08 15:29:21 --> Session: Class initialized using 'files' driver.
INFO - 2024-07-08 15:29:21 --> Controller Class Initialized
INFO - 2024-07-08 15:29:21 --> Final output sent to browser
DEBUG - 2024-07-08 15:29:21 --> Total execution time: 0.0419
INFO - 2024-07-08 15:29:21 --> Config Class Initialized
INFO - 2024-07-08 15:29:21 --> Hooks Class Initialized
DEBUG - 2024-07-08 15:29:21 --> UTF-8 Support Enabled
INFO - 2024-07-08 15:29:21 --> Utf8 Class Initialized
INFO - 2024-07-08 15:29:21 --> URI Class Initialized
INFO - 2024-07-08 15:29:21 --> Router Class Initialized
INFO - 2024-07-08 15:29:21 --> Output Class Initialized
INFO - 2024-07-08 15:29:21 --> Security Class Initialized
DEBUG - 2024-07-08 15:29:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-07-08 15:29:21 --> Input Class Initialized
INFO - 2024-07-08 15:29:21 --> Language Class Initialized
ERROR - 2024-07-08 15:29:21 --> 404 Page Not Found: /index
INFO - 2024-07-08 15:29:21 --> Config Class Initialized
INFO - 2024-07-08 15:29:21 --> Hooks Class Initialized
DEBUG - 2024-07-08 15:29:21 --> UTF-8 Support Enabled
INFO - 2024-07-08 15:29:21 --> Utf8 Class Initialized
INFO - 2024-07-08 15:29:21 --> URI Class Initialized
INFO - 2024-07-08 15:29:21 --> Router Class Initialized
INFO - 2024-07-08 15:29:21 --> Output Class Initialized
INFO - 2024-07-08 15:29:21 --> Security Class Initialized
DEBUG - 2024-07-08 15:29:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-07-08 15:29:21 --> Input Class Initialized
INFO - 2024-07-08 15:29:21 --> Language Class Initialized
INFO - 2024-07-08 15:29:21 --> Language Class Initialized
INFO - 2024-07-08 15:29:21 --> Config Class Initialized
INFO - 2024-07-08 15:29:21 --> Loader Class Initialized
INFO - 2024-07-08 15:29:21 --> Helper loaded: url_helper
INFO - 2024-07-08 15:29:21 --> Helper loaded: file_helper
INFO - 2024-07-08 15:29:21 --> Helper loaded: form_helper
INFO - 2024-07-08 15:29:21 --> Helper loaded: my_helper
INFO - 2024-07-08 15:29:21 --> Database Driver Class Initialized
INFO - 2024-07-08 15:29:21 --> Session: Class initialized using 'files' driver.
INFO - 2024-07-08 15:29:21 --> Controller Class Initialized
INFO - 2024-07-08 15:29:22 --> Config Class Initialized
INFO - 2024-07-08 15:29:22 --> Hooks Class Initialized
DEBUG - 2024-07-08 15:29:22 --> UTF-8 Support Enabled
INFO - 2024-07-08 15:29:22 --> Utf8 Class Initialized
INFO - 2024-07-08 15:29:22 --> URI Class Initialized
INFO - 2024-07-08 15:29:22 --> Router Class Initialized
INFO - 2024-07-08 15:29:22 --> Output Class Initialized
INFO - 2024-07-08 15:29:22 --> Security Class Initialized
DEBUG - 2024-07-08 15:29:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-07-08 15:29:22 --> Input Class Initialized
INFO - 2024-07-08 15:29:22 --> Language Class Initialized
INFO - 2024-07-08 15:29:22 --> Language Class Initialized
INFO - 2024-07-08 15:29:22 --> Config Class Initialized
INFO - 2024-07-08 15:29:22 --> Loader Class Initialized
INFO - 2024-07-08 15:29:22 --> Helper loaded: url_helper
INFO - 2024-07-08 15:29:22 --> Helper loaded: file_helper
INFO - 2024-07-08 15:29:22 --> Helper loaded: form_helper
INFO - 2024-07-08 15:29:22 --> Helper loaded: my_helper
INFO - 2024-07-08 15:29:22 --> Database Driver Class Initialized
INFO - 2024-07-08 15:29:22 --> Session: Class initialized using 'files' driver.
INFO - 2024-07-08 15:29:22 --> Controller Class Initialized
INFO - 2024-07-08 15:29:25 --> Config Class Initialized
INFO - 2024-07-08 15:29:25 --> Hooks Class Initialized
DEBUG - 2024-07-08 15:29:25 --> UTF-8 Support Enabled
INFO - 2024-07-08 15:29:25 --> Utf8 Class Initialized
INFO - 2024-07-08 15:29:25 --> URI Class Initialized
INFO - 2024-07-08 15:29:25 --> Router Class Initialized
INFO - 2024-07-08 15:29:25 --> Output Class Initialized
INFO - 2024-07-08 15:29:25 --> Security Class Initialized
DEBUG - 2024-07-08 15:29:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-07-08 15:29:25 --> Input Class Initialized
INFO - 2024-07-08 15:29:25 --> Language Class Initialized
INFO - 2024-07-08 15:29:25 --> Language Class Initialized
INFO - 2024-07-08 15:29:25 --> Config Class Initialized
INFO - 2024-07-08 15:29:25 --> Loader Class Initialized
INFO - 2024-07-08 15:29:25 --> Helper loaded: url_helper
INFO - 2024-07-08 15:29:25 --> Helper loaded: file_helper
INFO - 2024-07-08 15:29:25 --> Helper loaded: form_helper
INFO - 2024-07-08 15:29:25 --> Helper loaded: my_helper
INFO - 2024-07-08 15:29:25 --> Database Driver Class Initialized
INFO - 2024-07-08 15:29:25 --> Session: Class initialized using 'files' driver.
INFO - 2024-07-08 15:29:25 --> Controller Class Initialized
INFO - 2024-07-08 15:29:25 --> Final output sent to browser
DEBUG - 2024-07-08 15:29:25 --> Total execution time: 0.2442
INFO - 2024-07-08 15:29:25 --> Config Class Initialized
INFO - 2024-07-08 15:29:25 --> Hooks Class Initialized
DEBUG - 2024-07-08 15:29:25 --> UTF-8 Support Enabled
INFO - 2024-07-08 15:29:25 --> Utf8 Class Initialized
INFO - 2024-07-08 15:29:25 --> URI Class Initialized
INFO - 2024-07-08 15:29:25 --> Router Class Initialized
INFO - 2024-07-08 15:29:25 --> Output Class Initialized
INFO - 2024-07-08 15:29:25 --> Security Class Initialized
DEBUG - 2024-07-08 15:29:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-07-08 15:29:25 --> Input Class Initialized
INFO - 2024-07-08 15:29:25 --> Language Class Initialized
ERROR - 2024-07-08 15:29:25 --> 404 Page Not Found: /index
INFO - 2024-07-08 15:29:25 --> Config Class Initialized
INFO - 2024-07-08 15:29:25 --> Hooks Class Initialized
DEBUG - 2024-07-08 15:29:25 --> UTF-8 Support Enabled
INFO - 2024-07-08 15:29:25 --> Utf8 Class Initialized
INFO - 2024-07-08 15:29:25 --> URI Class Initialized
INFO - 2024-07-08 15:29:25 --> Router Class Initialized
INFO - 2024-07-08 15:29:25 --> Output Class Initialized
INFO - 2024-07-08 15:29:25 --> Security Class Initialized
DEBUG - 2024-07-08 15:29:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-07-08 15:29:25 --> Input Class Initialized
INFO - 2024-07-08 15:29:25 --> Language Class Initialized
INFO - 2024-07-08 15:29:25 --> Language Class Initialized
INFO - 2024-07-08 15:29:25 --> Config Class Initialized
INFO - 2024-07-08 15:29:25 --> Loader Class Initialized
INFO - 2024-07-08 15:29:25 --> Helper loaded: url_helper
INFO - 2024-07-08 15:29:25 --> Helper loaded: file_helper
INFO - 2024-07-08 15:29:25 --> Helper loaded: form_helper
INFO - 2024-07-08 15:29:25 --> Helper loaded: my_helper
INFO - 2024-07-08 15:29:25 --> Database Driver Class Initialized
INFO - 2024-07-08 15:29:25 --> Session: Class initialized using 'files' driver.
INFO - 2024-07-08 15:29:25 --> Controller Class Initialized
INFO - 2024-07-08 15:29:26 --> Config Class Initialized
INFO - 2024-07-08 15:29:26 --> Hooks Class Initialized
DEBUG - 2024-07-08 15:29:26 --> UTF-8 Support Enabled
INFO - 2024-07-08 15:29:26 --> Utf8 Class Initialized
INFO - 2024-07-08 15:29:26 --> URI Class Initialized
INFO - 2024-07-08 15:29:26 --> Router Class Initialized
INFO - 2024-07-08 15:29:26 --> Output Class Initialized
INFO - 2024-07-08 15:29:26 --> Security Class Initialized
DEBUG - 2024-07-08 15:29:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-07-08 15:29:26 --> Input Class Initialized
INFO - 2024-07-08 15:29:26 --> Language Class Initialized
INFO - 2024-07-08 15:29:26 --> Language Class Initialized
INFO - 2024-07-08 15:29:26 --> Config Class Initialized
INFO - 2024-07-08 15:29:26 --> Loader Class Initialized
INFO - 2024-07-08 15:29:26 --> Helper loaded: url_helper
INFO - 2024-07-08 15:29:26 --> Helper loaded: file_helper
INFO - 2024-07-08 15:29:26 --> Helper loaded: form_helper
INFO - 2024-07-08 15:29:26 --> Helper loaded: my_helper
INFO - 2024-07-08 15:29:26 --> Database Driver Class Initialized
INFO - 2024-07-08 15:29:26 --> Session: Class initialized using 'files' driver.
INFO - 2024-07-08 15:29:26 --> Controller Class Initialized
INFO - 2024-07-08 15:29:29 --> Config Class Initialized
INFO - 2024-07-08 15:29:29 --> Hooks Class Initialized
DEBUG - 2024-07-08 15:29:29 --> UTF-8 Support Enabled
INFO - 2024-07-08 15:29:29 --> Utf8 Class Initialized
INFO - 2024-07-08 15:29:29 --> URI Class Initialized
INFO - 2024-07-08 15:29:29 --> Router Class Initialized
INFO - 2024-07-08 15:29:29 --> Output Class Initialized
INFO - 2024-07-08 15:29:29 --> Security Class Initialized
DEBUG - 2024-07-08 15:29:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-07-08 15:29:29 --> Input Class Initialized
INFO - 2024-07-08 15:29:29 --> Language Class Initialized
INFO - 2024-07-08 15:29:29 --> Language Class Initialized
INFO - 2024-07-08 15:29:29 --> Config Class Initialized
INFO - 2024-07-08 15:29:29 --> Loader Class Initialized
INFO - 2024-07-08 15:29:29 --> Helper loaded: url_helper
INFO - 2024-07-08 15:29:29 --> Helper loaded: file_helper
INFO - 2024-07-08 15:29:29 --> Helper loaded: form_helper
INFO - 2024-07-08 15:29:29 --> Helper loaded: my_helper
INFO - 2024-07-08 15:29:29 --> Database Driver Class Initialized
INFO - 2024-07-08 15:29:29 --> Session: Class initialized using 'files' driver.
INFO - 2024-07-08 15:29:29 --> Controller Class Initialized
INFO - 2024-07-08 15:29:29 --> Final output sent to browser
DEBUG - 2024-07-08 15:29:29 --> Total execution time: 0.0303
INFO - 2024-07-08 15:29:29 --> Config Class Initialized
INFO - 2024-07-08 15:29:29 --> Hooks Class Initialized
DEBUG - 2024-07-08 15:29:29 --> UTF-8 Support Enabled
INFO - 2024-07-08 15:29:29 --> Utf8 Class Initialized
INFO - 2024-07-08 15:29:29 --> URI Class Initialized
INFO - 2024-07-08 15:29:29 --> Router Class Initialized
INFO - 2024-07-08 15:29:29 --> Output Class Initialized
INFO - 2024-07-08 15:29:29 --> Security Class Initialized
DEBUG - 2024-07-08 15:29:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-07-08 15:29:29 --> Input Class Initialized
INFO - 2024-07-08 15:29:29 --> Language Class Initialized
ERROR - 2024-07-08 15:29:29 --> 404 Page Not Found: /index
INFO - 2024-07-08 15:29:29 --> Config Class Initialized
INFO - 2024-07-08 15:29:29 --> Hooks Class Initialized
DEBUG - 2024-07-08 15:29:29 --> UTF-8 Support Enabled
INFO - 2024-07-08 15:29:29 --> Utf8 Class Initialized
INFO - 2024-07-08 15:29:29 --> URI Class Initialized
INFO - 2024-07-08 15:29:29 --> Router Class Initialized
INFO - 2024-07-08 15:29:29 --> Output Class Initialized
INFO - 2024-07-08 15:29:29 --> Security Class Initialized
DEBUG - 2024-07-08 15:29:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-07-08 15:29:29 --> Input Class Initialized
INFO - 2024-07-08 15:29:29 --> Language Class Initialized
INFO - 2024-07-08 15:29:29 --> Language Class Initialized
INFO - 2024-07-08 15:29:29 --> Config Class Initialized
INFO - 2024-07-08 15:29:29 --> Loader Class Initialized
INFO - 2024-07-08 15:29:29 --> Helper loaded: url_helper
INFO - 2024-07-08 15:29:29 --> Helper loaded: file_helper
INFO - 2024-07-08 15:29:29 --> Helper loaded: form_helper
INFO - 2024-07-08 15:29:29 --> Helper loaded: my_helper
INFO - 2024-07-08 15:29:29 --> Database Driver Class Initialized
INFO - 2024-07-08 15:29:29 --> Session: Class initialized using 'files' driver.
INFO - 2024-07-08 15:29:29 --> Controller Class Initialized
INFO - 2024-07-08 15:29:32 --> Config Class Initialized
INFO - 2024-07-08 15:29:32 --> Hooks Class Initialized
DEBUG - 2024-07-08 15:29:32 --> UTF-8 Support Enabled
INFO - 2024-07-08 15:29:32 --> Utf8 Class Initialized
INFO - 2024-07-08 15:29:32 --> URI Class Initialized
INFO - 2024-07-08 15:29:32 --> Router Class Initialized
INFO - 2024-07-08 15:29:32 --> Output Class Initialized
INFO - 2024-07-08 15:29:32 --> Security Class Initialized
DEBUG - 2024-07-08 15:29:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-07-08 15:29:32 --> Input Class Initialized
INFO - 2024-07-08 15:29:32 --> Language Class Initialized
INFO - 2024-07-08 15:29:32 --> Language Class Initialized
INFO - 2024-07-08 15:29:32 --> Config Class Initialized
INFO - 2024-07-08 15:29:32 --> Loader Class Initialized
INFO - 2024-07-08 15:29:32 --> Helper loaded: url_helper
INFO - 2024-07-08 15:29:32 --> Helper loaded: file_helper
INFO - 2024-07-08 15:29:32 --> Helper loaded: form_helper
INFO - 2024-07-08 15:29:32 --> Helper loaded: my_helper
INFO - 2024-07-08 15:29:32 --> Database Driver Class Initialized
INFO - 2024-07-08 15:29:32 --> Session: Class initialized using 'files' driver.
INFO - 2024-07-08 15:29:32 --> Controller Class Initialized
ERROR - 2024-07-08 15:29:32 --> Severity: Notice --> Undefined variable: status_form /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/data_siswa/views/form.php 231
DEBUG - 2024-07-08 15:29:32 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/data_siswa/views/form.php
DEBUG - 2024-07-08 15:29:32 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-07-08 15:29:32 --> Final output sent to browser
DEBUG - 2024-07-08 15:29:32 --> Total execution time: 0.0309
INFO - 2024-07-08 15:29:37 --> Config Class Initialized
INFO - 2024-07-08 15:29:37 --> Hooks Class Initialized
DEBUG - 2024-07-08 15:29:37 --> UTF-8 Support Enabled
INFO - 2024-07-08 15:29:37 --> Utf8 Class Initialized
INFO - 2024-07-08 15:29:37 --> URI Class Initialized
INFO - 2024-07-08 15:29:37 --> Router Class Initialized
INFO - 2024-07-08 15:29:37 --> Output Class Initialized
INFO - 2024-07-08 15:29:37 --> Security Class Initialized
DEBUG - 2024-07-08 15:29:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-07-08 15:29:37 --> Input Class Initialized
INFO - 2024-07-08 15:29:37 --> Language Class Initialized
INFO - 2024-07-08 15:29:37 --> Language Class Initialized
INFO - 2024-07-08 15:29:37 --> Config Class Initialized
INFO - 2024-07-08 15:29:37 --> Loader Class Initialized
INFO - 2024-07-08 15:29:37 --> Helper loaded: url_helper
INFO - 2024-07-08 15:29:37 --> Helper loaded: file_helper
INFO - 2024-07-08 15:29:37 --> Helper loaded: form_helper
INFO - 2024-07-08 15:29:37 --> Helper loaded: my_helper
INFO - 2024-07-08 15:29:37 --> Database Driver Class Initialized
INFO - 2024-07-08 15:29:37 --> Session: Class initialized using 'files' driver.
INFO - 2024-07-08 15:29:37 --> Controller Class Initialized
DEBUG - 2024-07-08 15:29:37 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/data_siswa/views/list.php
DEBUG - 2024-07-08 15:29:37 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-07-08 15:29:37 --> Final output sent to browser
DEBUG - 2024-07-08 15:29:37 --> Total execution time: 0.0304
INFO - 2024-07-08 15:29:37 --> Config Class Initialized
INFO - 2024-07-08 15:29:37 --> Hooks Class Initialized
DEBUG - 2024-07-08 15:29:37 --> UTF-8 Support Enabled
INFO - 2024-07-08 15:29:37 --> Utf8 Class Initialized
INFO - 2024-07-08 15:29:37 --> URI Class Initialized
INFO - 2024-07-08 15:29:37 --> Router Class Initialized
INFO - 2024-07-08 15:29:37 --> Output Class Initialized
INFO - 2024-07-08 15:29:37 --> Security Class Initialized
DEBUG - 2024-07-08 15:29:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-07-08 15:29:37 --> Input Class Initialized
INFO - 2024-07-08 15:29:37 --> Language Class Initialized
ERROR - 2024-07-08 15:29:37 --> 404 Page Not Found: /index
INFO - 2024-07-08 15:29:37 --> Config Class Initialized
INFO - 2024-07-08 15:29:37 --> Hooks Class Initialized
DEBUG - 2024-07-08 15:29:37 --> UTF-8 Support Enabled
INFO - 2024-07-08 15:29:37 --> Utf8 Class Initialized
INFO - 2024-07-08 15:29:37 --> URI Class Initialized
INFO - 2024-07-08 15:29:37 --> Router Class Initialized
INFO - 2024-07-08 15:29:37 --> Output Class Initialized
INFO - 2024-07-08 15:29:37 --> Security Class Initialized
DEBUG - 2024-07-08 15:29:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-07-08 15:29:37 --> Input Class Initialized
INFO - 2024-07-08 15:29:37 --> Language Class Initialized
INFO - 2024-07-08 15:29:37 --> Language Class Initialized
INFO - 2024-07-08 15:29:37 --> Config Class Initialized
INFO - 2024-07-08 15:29:37 --> Loader Class Initialized
INFO - 2024-07-08 15:29:37 --> Helper loaded: url_helper
INFO - 2024-07-08 15:29:37 --> Helper loaded: file_helper
INFO - 2024-07-08 15:29:37 --> Helper loaded: form_helper
INFO - 2024-07-08 15:29:37 --> Helper loaded: my_helper
INFO - 2024-07-08 15:29:37 --> Database Driver Class Initialized
INFO - 2024-07-08 15:29:37 --> Session: Class initialized using 'files' driver.
INFO - 2024-07-08 15:29:37 --> Controller Class Initialized
INFO - 2024-07-08 15:29:42 --> Config Class Initialized
INFO - 2024-07-08 15:29:42 --> Hooks Class Initialized
DEBUG - 2024-07-08 15:29:42 --> UTF-8 Support Enabled
INFO - 2024-07-08 15:29:42 --> Utf8 Class Initialized
INFO - 2024-07-08 15:29:42 --> URI Class Initialized
INFO - 2024-07-08 15:29:42 --> Router Class Initialized
INFO - 2024-07-08 15:29:42 --> Output Class Initialized
INFO - 2024-07-08 15:29:42 --> Security Class Initialized
DEBUG - 2024-07-08 15:29:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-07-08 15:29:42 --> Input Class Initialized
INFO - 2024-07-08 15:29:42 --> Language Class Initialized
INFO - 2024-07-08 15:29:42 --> Language Class Initialized
INFO - 2024-07-08 15:29:42 --> Config Class Initialized
INFO - 2024-07-08 15:29:42 --> Loader Class Initialized
INFO - 2024-07-08 15:29:42 --> Helper loaded: url_helper
INFO - 2024-07-08 15:29:42 --> Helper loaded: file_helper
INFO - 2024-07-08 15:29:42 --> Helper loaded: form_helper
INFO - 2024-07-08 15:29:42 --> Helper loaded: my_helper
INFO - 2024-07-08 15:29:42 --> Database Driver Class Initialized
INFO - 2024-07-08 15:29:42 --> Session: Class initialized using 'files' driver.
INFO - 2024-07-08 15:29:42 --> Controller Class Initialized
INFO - 2024-07-08 15:29:45 --> Config Class Initialized
INFO - 2024-07-08 15:29:45 --> Hooks Class Initialized
DEBUG - 2024-07-08 15:29:45 --> UTF-8 Support Enabled
INFO - 2024-07-08 15:29:45 --> Utf8 Class Initialized
INFO - 2024-07-08 15:29:45 --> URI Class Initialized
INFO - 2024-07-08 15:29:45 --> Router Class Initialized
INFO - 2024-07-08 15:29:45 --> Output Class Initialized
INFO - 2024-07-08 15:29:45 --> Security Class Initialized
DEBUG - 2024-07-08 15:29:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-07-08 15:29:45 --> Input Class Initialized
INFO - 2024-07-08 15:29:45 --> Language Class Initialized
INFO - 2024-07-08 15:29:45 --> Language Class Initialized
INFO - 2024-07-08 15:29:45 --> Config Class Initialized
INFO - 2024-07-08 15:29:45 --> Loader Class Initialized
INFO - 2024-07-08 15:29:45 --> Helper loaded: url_helper
INFO - 2024-07-08 15:29:45 --> Helper loaded: file_helper
INFO - 2024-07-08 15:29:45 --> Helper loaded: form_helper
INFO - 2024-07-08 15:29:45 --> Helper loaded: my_helper
INFO - 2024-07-08 15:29:45 --> Database Driver Class Initialized
INFO - 2024-07-08 15:29:45 --> Session: Class initialized using 'files' driver.
INFO - 2024-07-08 15:29:45 --> Controller Class Initialized
ERROR - 2024-07-08 15:29:45 --> Severity: Notice --> Undefined variable: status_form /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/data_siswa/views/form.php 231
DEBUG - 2024-07-08 15:29:45 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/data_siswa/views/form.php
DEBUG - 2024-07-08 15:29:45 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-07-08 15:29:45 --> Final output sent to browser
DEBUG - 2024-07-08 15:29:45 --> Total execution time: 0.0415
INFO - 2024-07-08 15:29:56 --> Config Class Initialized
INFO - 2024-07-08 15:29:56 --> Hooks Class Initialized
DEBUG - 2024-07-08 15:29:56 --> UTF-8 Support Enabled
INFO - 2024-07-08 15:29:56 --> Utf8 Class Initialized
INFO - 2024-07-08 15:29:56 --> URI Class Initialized
INFO - 2024-07-08 15:29:56 --> Router Class Initialized
INFO - 2024-07-08 15:29:56 --> Output Class Initialized
INFO - 2024-07-08 15:29:56 --> Security Class Initialized
DEBUG - 2024-07-08 15:29:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-07-08 15:29:56 --> Input Class Initialized
INFO - 2024-07-08 15:29:56 --> Language Class Initialized
INFO - 2024-07-08 15:29:56 --> Language Class Initialized
INFO - 2024-07-08 15:29:56 --> Config Class Initialized
INFO - 2024-07-08 15:29:56 --> Loader Class Initialized
INFO - 2024-07-08 15:29:56 --> Helper loaded: url_helper
INFO - 2024-07-08 15:29:56 --> Helper loaded: file_helper
INFO - 2024-07-08 15:29:56 --> Helper loaded: form_helper
INFO - 2024-07-08 15:29:56 --> Helper loaded: my_helper
INFO - 2024-07-08 15:29:56 --> Database Driver Class Initialized
INFO - 2024-07-08 15:29:56 --> Session: Class initialized using 'files' driver.
INFO - 2024-07-08 15:29:56 --> Controller Class Initialized
INFO - 2024-07-08 15:29:56 --> Upload Class Initialized
INFO - 2024-07-08 15:29:56 --> Language file loaded: language/english/upload_lang.php
ERROR - 2024-07-08 15:29:56 --> The upload path does not appear to be valid.
INFO - 2024-07-08 15:29:56 --> Config Class Initialized
INFO - 2024-07-08 15:29:56 --> Hooks Class Initialized
DEBUG - 2024-07-08 15:29:56 --> UTF-8 Support Enabled
INFO - 2024-07-08 15:29:56 --> Utf8 Class Initialized
INFO - 2024-07-08 15:29:56 --> URI Class Initialized
INFO - 2024-07-08 15:29:56 --> Router Class Initialized
INFO - 2024-07-08 15:29:56 --> Output Class Initialized
INFO - 2024-07-08 15:29:56 --> Security Class Initialized
DEBUG - 2024-07-08 15:29:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-07-08 15:29:56 --> Input Class Initialized
INFO - 2024-07-08 15:29:56 --> Language Class Initialized
INFO - 2024-07-08 15:29:56 --> Language Class Initialized
INFO - 2024-07-08 15:29:56 --> Config Class Initialized
INFO - 2024-07-08 15:29:56 --> Loader Class Initialized
INFO - 2024-07-08 15:29:56 --> Helper loaded: url_helper
INFO - 2024-07-08 15:29:56 --> Helper loaded: file_helper
INFO - 2024-07-08 15:29:56 --> Helper loaded: form_helper
INFO - 2024-07-08 15:29:56 --> Helper loaded: my_helper
INFO - 2024-07-08 15:29:56 --> Database Driver Class Initialized
INFO - 2024-07-08 15:29:56 --> Session: Class initialized using 'files' driver.
INFO - 2024-07-08 15:29:56 --> Controller Class Initialized
DEBUG - 2024-07-08 15:29:56 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/data_siswa/views/list.php
DEBUG - 2024-07-08 15:29:56 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-07-08 15:29:56 --> Final output sent to browser
DEBUG - 2024-07-08 15:29:56 --> Total execution time: 0.0329
INFO - 2024-07-08 15:29:56 --> Config Class Initialized
INFO - 2024-07-08 15:29:56 --> Hooks Class Initialized
DEBUG - 2024-07-08 15:29:56 --> UTF-8 Support Enabled
INFO - 2024-07-08 15:29:56 --> Utf8 Class Initialized
INFO - 2024-07-08 15:29:56 --> URI Class Initialized
INFO - 2024-07-08 15:29:56 --> Router Class Initialized
INFO - 2024-07-08 15:29:56 --> Output Class Initialized
INFO - 2024-07-08 15:29:56 --> Security Class Initialized
DEBUG - 2024-07-08 15:29:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-07-08 15:29:56 --> Input Class Initialized
INFO - 2024-07-08 15:29:56 --> Language Class Initialized
ERROR - 2024-07-08 15:29:56 --> 404 Page Not Found: /index
INFO - 2024-07-08 15:29:56 --> Config Class Initialized
INFO - 2024-07-08 15:29:56 --> Hooks Class Initialized
DEBUG - 2024-07-08 15:29:56 --> UTF-8 Support Enabled
INFO - 2024-07-08 15:29:56 --> Utf8 Class Initialized
INFO - 2024-07-08 15:29:56 --> URI Class Initialized
INFO - 2024-07-08 15:29:56 --> Router Class Initialized
INFO - 2024-07-08 15:29:56 --> Output Class Initialized
INFO - 2024-07-08 15:29:56 --> Security Class Initialized
DEBUG - 2024-07-08 15:29:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-07-08 15:29:56 --> Input Class Initialized
INFO - 2024-07-08 15:29:56 --> Language Class Initialized
INFO - 2024-07-08 15:29:56 --> Language Class Initialized
INFO - 2024-07-08 15:29:56 --> Config Class Initialized
INFO - 2024-07-08 15:29:56 --> Loader Class Initialized
INFO - 2024-07-08 15:29:56 --> Helper loaded: url_helper
INFO - 2024-07-08 15:29:56 --> Helper loaded: file_helper
INFO - 2024-07-08 15:29:56 --> Helper loaded: form_helper
INFO - 2024-07-08 15:29:56 --> Helper loaded: my_helper
INFO - 2024-07-08 15:29:56 --> Database Driver Class Initialized
INFO - 2024-07-08 15:29:56 --> Session: Class initialized using 'files' driver.
INFO - 2024-07-08 15:29:56 --> Controller Class Initialized
INFO - 2024-07-08 15:30:05 --> Config Class Initialized
INFO - 2024-07-08 15:30:05 --> Hooks Class Initialized
DEBUG - 2024-07-08 15:30:05 --> UTF-8 Support Enabled
INFO - 2024-07-08 15:30:05 --> Utf8 Class Initialized
INFO - 2024-07-08 15:30:05 --> URI Class Initialized
INFO - 2024-07-08 15:30:05 --> Router Class Initialized
INFO - 2024-07-08 15:30:05 --> Output Class Initialized
INFO - 2024-07-08 15:30:05 --> Security Class Initialized
DEBUG - 2024-07-08 15:30:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-07-08 15:30:05 --> Input Class Initialized
INFO - 2024-07-08 15:30:05 --> Language Class Initialized
INFO - 2024-07-08 15:30:05 --> Language Class Initialized
INFO - 2024-07-08 15:30:05 --> Config Class Initialized
INFO - 2024-07-08 15:30:05 --> Loader Class Initialized
INFO - 2024-07-08 15:30:05 --> Helper loaded: url_helper
INFO - 2024-07-08 15:30:05 --> Helper loaded: file_helper
INFO - 2024-07-08 15:30:05 --> Helper loaded: form_helper
INFO - 2024-07-08 15:30:05 --> Helper loaded: my_helper
INFO - 2024-07-08 15:30:05 --> Database Driver Class Initialized
INFO - 2024-07-08 15:30:05 --> Session: Class initialized using 'files' driver.
INFO - 2024-07-08 15:30:05 --> Controller Class Initialized
INFO - 2024-07-08 15:30:07 --> Config Class Initialized
INFO - 2024-07-08 15:30:07 --> Hooks Class Initialized
DEBUG - 2024-07-08 15:30:07 --> UTF-8 Support Enabled
INFO - 2024-07-08 15:30:07 --> Utf8 Class Initialized
INFO - 2024-07-08 15:30:07 --> URI Class Initialized
INFO - 2024-07-08 15:30:07 --> Router Class Initialized
INFO - 2024-07-08 15:30:07 --> Output Class Initialized
INFO - 2024-07-08 15:30:07 --> Security Class Initialized
DEBUG - 2024-07-08 15:30:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-07-08 15:30:07 --> Input Class Initialized
INFO - 2024-07-08 15:30:07 --> Language Class Initialized
INFO - 2024-07-08 15:30:07 --> Language Class Initialized
INFO - 2024-07-08 15:30:07 --> Config Class Initialized
INFO - 2024-07-08 15:30:07 --> Loader Class Initialized
INFO - 2024-07-08 15:30:07 --> Helper loaded: url_helper
INFO - 2024-07-08 15:30:07 --> Helper loaded: file_helper
INFO - 2024-07-08 15:30:07 --> Helper loaded: form_helper
INFO - 2024-07-08 15:30:07 --> Helper loaded: my_helper
INFO - 2024-07-08 15:30:07 --> Database Driver Class Initialized
INFO - 2024-07-08 15:30:07 --> Session: Class initialized using 'files' driver.
INFO - 2024-07-08 15:30:07 --> Controller Class Initialized
INFO - 2024-07-08 15:30:11 --> Config Class Initialized
INFO - 2024-07-08 15:30:11 --> Hooks Class Initialized
DEBUG - 2024-07-08 15:30:11 --> UTF-8 Support Enabled
INFO - 2024-07-08 15:30:11 --> Utf8 Class Initialized
INFO - 2024-07-08 15:30:11 --> URI Class Initialized
INFO - 2024-07-08 15:30:11 --> Router Class Initialized
INFO - 2024-07-08 15:30:11 --> Output Class Initialized
INFO - 2024-07-08 15:30:11 --> Security Class Initialized
DEBUG - 2024-07-08 15:30:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-07-08 15:30:11 --> Input Class Initialized
INFO - 2024-07-08 15:30:11 --> Language Class Initialized
INFO - 2024-07-08 15:30:11 --> Language Class Initialized
INFO - 2024-07-08 15:30:11 --> Config Class Initialized
INFO - 2024-07-08 15:30:11 --> Loader Class Initialized
INFO - 2024-07-08 15:30:11 --> Helper loaded: url_helper
INFO - 2024-07-08 15:30:11 --> Helper loaded: file_helper
INFO - 2024-07-08 15:30:11 --> Helper loaded: form_helper
INFO - 2024-07-08 15:30:11 --> Helper loaded: my_helper
INFO - 2024-07-08 15:30:11 --> Database Driver Class Initialized
INFO - 2024-07-08 15:30:11 --> Session: Class initialized using 'files' driver.
INFO - 2024-07-08 15:30:11 --> Controller Class Initialized
INFO - 2024-07-08 15:30:11 --> Final output sent to browser
DEBUG - 2024-07-08 15:30:11 --> Total execution time: 0.0668
INFO - 2024-07-08 15:30:11 --> Config Class Initialized
INFO - 2024-07-08 15:30:11 --> Hooks Class Initialized
DEBUG - 2024-07-08 15:30:11 --> UTF-8 Support Enabled
INFO - 2024-07-08 15:30:11 --> Utf8 Class Initialized
INFO - 2024-07-08 15:30:11 --> URI Class Initialized
INFO - 2024-07-08 15:30:11 --> Router Class Initialized
INFO - 2024-07-08 15:30:11 --> Output Class Initialized
INFO - 2024-07-08 15:30:11 --> Security Class Initialized
DEBUG - 2024-07-08 15:30:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-07-08 15:30:11 --> Input Class Initialized
INFO - 2024-07-08 15:30:11 --> Language Class Initialized
ERROR - 2024-07-08 15:30:11 --> 404 Page Not Found: /index
INFO - 2024-07-08 15:30:11 --> Config Class Initialized
INFO - 2024-07-08 15:30:11 --> Hooks Class Initialized
DEBUG - 2024-07-08 15:30:11 --> UTF-8 Support Enabled
INFO - 2024-07-08 15:30:11 --> Utf8 Class Initialized
INFO - 2024-07-08 15:30:11 --> URI Class Initialized
INFO - 2024-07-08 15:30:11 --> Router Class Initialized
INFO - 2024-07-08 15:30:11 --> Output Class Initialized
INFO - 2024-07-08 15:30:11 --> Security Class Initialized
DEBUG - 2024-07-08 15:30:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-07-08 15:30:11 --> Input Class Initialized
INFO - 2024-07-08 15:30:11 --> Language Class Initialized
INFO - 2024-07-08 15:30:11 --> Language Class Initialized
INFO - 2024-07-08 15:30:11 --> Config Class Initialized
INFO - 2024-07-08 15:30:11 --> Loader Class Initialized
INFO - 2024-07-08 15:30:11 --> Helper loaded: url_helper
INFO - 2024-07-08 15:30:11 --> Helper loaded: file_helper
INFO - 2024-07-08 15:30:11 --> Helper loaded: form_helper
INFO - 2024-07-08 15:30:11 --> Helper loaded: my_helper
INFO - 2024-07-08 15:30:11 --> Database Driver Class Initialized
INFO - 2024-07-08 15:30:11 --> Session: Class initialized using 'files' driver.
INFO - 2024-07-08 15:30:11 --> Controller Class Initialized
INFO - 2024-07-08 15:30:14 --> Config Class Initialized
INFO - 2024-07-08 15:30:14 --> Hooks Class Initialized
DEBUG - 2024-07-08 15:30:14 --> UTF-8 Support Enabled
INFO - 2024-07-08 15:30:14 --> Utf8 Class Initialized
INFO - 2024-07-08 15:30:14 --> URI Class Initialized
INFO - 2024-07-08 15:30:14 --> Router Class Initialized
INFO - 2024-07-08 15:30:14 --> Output Class Initialized
INFO - 2024-07-08 15:30:14 --> Security Class Initialized
DEBUG - 2024-07-08 15:30:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-07-08 15:30:14 --> Input Class Initialized
INFO - 2024-07-08 15:30:14 --> Language Class Initialized
INFO - 2024-07-08 15:30:14 --> Language Class Initialized
INFO - 2024-07-08 15:30:14 --> Config Class Initialized
INFO - 2024-07-08 15:30:14 --> Loader Class Initialized
INFO - 2024-07-08 15:30:14 --> Helper loaded: url_helper
INFO - 2024-07-08 15:30:14 --> Helper loaded: file_helper
INFO - 2024-07-08 15:30:14 --> Helper loaded: form_helper
INFO - 2024-07-08 15:30:14 --> Helper loaded: my_helper
INFO - 2024-07-08 15:30:14 --> Database Driver Class Initialized
INFO - 2024-07-08 15:30:14 --> Session: Class initialized using 'files' driver.
INFO - 2024-07-08 15:30:14 --> Controller Class Initialized
INFO - 2024-07-08 15:30:18 --> Config Class Initialized
INFO - 2024-07-08 15:30:18 --> Hooks Class Initialized
DEBUG - 2024-07-08 15:30:18 --> UTF-8 Support Enabled
INFO - 2024-07-08 15:30:18 --> Utf8 Class Initialized
INFO - 2024-07-08 15:30:18 --> URI Class Initialized
INFO - 2024-07-08 15:30:18 --> Router Class Initialized
INFO - 2024-07-08 15:30:18 --> Output Class Initialized
INFO - 2024-07-08 15:30:18 --> Security Class Initialized
DEBUG - 2024-07-08 15:30:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-07-08 15:30:18 --> Input Class Initialized
INFO - 2024-07-08 15:30:18 --> Language Class Initialized
INFO - 2024-07-08 15:30:18 --> Language Class Initialized
INFO - 2024-07-08 15:30:18 --> Config Class Initialized
INFO - 2024-07-08 15:30:18 --> Loader Class Initialized
INFO - 2024-07-08 15:30:18 --> Helper loaded: url_helper
INFO - 2024-07-08 15:30:18 --> Helper loaded: file_helper
INFO - 2024-07-08 15:30:18 --> Helper loaded: form_helper
INFO - 2024-07-08 15:30:18 --> Helper loaded: my_helper
INFO - 2024-07-08 15:30:18 --> Database Driver Class Initialized
INFO - 2024-07-08 15:30:18 --> Session: Class initialized using 'files' driver.
INFO - 2024-07-08 15:30:18 --> Controller Class Initialized
INFO - 2024-07-08 15:30:22 --> Config Class Initialized
INFO - 2024-07-08 15:30:22 --> Hooks Class Initialized
DEBUG - 2024-07-08 15:30:22 --> UTF-8 Support Enabled
INFO - 2024-07-08 15:30:22 --> Utf8 Class Initialized
INFO - 2024-07-08 15:30:22 --> URI Class Initialized
INFO - 2024-07-08 15:30:22 --> Router Class Initialized
INFO - 2024-07-08 15:30:22 --> Output Class Initialized
INFO - 2024-07-08 15:30:22 --> Security Class Initialized
DEBUG - 2024-07-08 15:30:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-07-08 15:30:22 --> Input Class Initialized
INFO - 2024-07-08 15:30:22 --> Language Class Initialized
INFO - 2024-07-08 15:30:22 --> Language Class Initialized
INFO - 2024-07-08 15:30:22 --> Config Class Initialized
INFO - 2024-07-08 15:30:22 --> Loader Class Initialized
INFO - 2024-07-08 15:30:22 --> Helper loaded: url_helper
INFO - 2024-07-08 15:30:22 --> Helper loaded: file_helper
INFO - 2024-07-08 15:30:22 --> Helper loaded: form_helper
INFO - 2024-07-08 15:30:22 --> Helper loaded: my_helper
INFO - 2024-07-08 15:30:22 --> Database Driver Class Initialized
INFO - 2024-07-08 15:30:22 --> Session: Class initialized using 'files' driver.
INFO - 2024-07-08 15:30:22 --> Controller Class Initialized
INFO - 2024-07-08 15:30:22 --> Final output sent to browser
DEBUG - 2024-07-08 15:30:22 --> Total execution time: 0.0459
INFO - 2024-07-08 15:30:22 --> Config Class Initialized
INFO - 2024-07-08 15:30:22 --> Hooks Class Initialized
DEBUG - 2024-07-08 15:30:22 --> UTF-8 Support Enabled
INFO - 2024-07-08 15:30:22 --> Utf8 Class Initialized
INFO - 2024-07-08 15:30:22 --> URI Class Initialized
INFO - 2024-07-08 15:30:22 --> Router Class Initialized
INFO - 2024-07-08 15:30:22 --> Output Class Initialized
INFO - 2024-07-08 15:30:22 --> Security Class Initialized
DEBUG - 2024-07-08 15:30:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-07-08 15:30:22 --> Input Class Initialized
INFO - 2024-07-08 15:30:22 --> Language Class Initialized
ERROR - 2024-07-08 15:30:22 --> 404 Page Not Found: /index
INFO - 2024-07-08 15:30:22 --> Config Class Initialized
INFO - 2024-07-08 15:30:22 --> Hooks Class Initialized
DEBUG - 2024-07-08 15:30:22 --> UTF-8 Support Enabled
INFO - 2024-07-08 15:30:22 --> Utf8 Class Initialized
INFO - 2024-07-08 15:30:22 --> URI Class Initialized
INFO - 2024-07-08 15:30:22 --> Router Class Initialized
INFO - 2024-07-08 15:30:22 --> Output Class Initialized
INFO - 2024-07-08 15:30:22 --> Security Class Initialized
DEBUG - 2024-07-08 15:30:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-07-08 15:30:22 --> Input Class Initialized
INFO - 2024-07-08 15:30:22 --> Language Class Initialized
INFO - 2024-07-08 15:30:22 --> Language Class Initialized
INFO - 2024-07-08 15:30:22 --> Config Class Initialized
INFO - 2024-07-08 15:30:22 --> Loader Class Initialized
INFO - 2024-07-08 15:30:22 --> Helper loaded: url_helper
INFO - 2024-07-08 15:30:22 --> Helper loaded: file_helper
INFO - 2024-07-08 15:30:22 --> Helper loaded: form_helper
INFO - 2024-07-08 15:30:22 --> Helper loaded: my_helper
INFO - 2024-07-08 15:30:23 --> Database Driver Class Initialized
INFO - 2024-07-08 15:30:23 --> Session: Class initialized using 'files' driver.
INFO - 2024-07-08 15:30:23 --> Controller Class Initialized
INFO - 2024-07-08 15:30:40 --> Config Class Initialized
INFO - 2024-07-08 15:30:40 --> Hooks Class Initialized
DEBUG - 2024-07-08 15:30:40 --> UTF-8 Support Enabled
INFO - 2024-07-08 15:30:40 --> Utf8 Class Initialized
INFO - 2024-07-08 15:30:40 --> URI Class Initialized
INFO - 2024-07-08 15:30:40 --> Router Class Initialized
INFO - 2024-07-08 15:30:40 --> Output Class Initialized
INFO - 2024-07-08 15:30:40 --> Security Class Initialized
DEBUG - 2024-07-08 15:30:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-07-08 15:30:40 --> Input Class Initialized
INFO - 2024-07-08 15:30:40 --> Language Class Initialized
INFO - 2024-07-08 15:30:40 --> Language Class Initialized
INFO - 2024-07-08 15:30:40 --> Config Class Initialized
INFO - 2024-07-08 15:30:40 --> Loader Class Initialized
INFO - 2024-07-08 15:30:40 --> Helper loaded: url_helper
INFO - 2024-07-08 15:30:40 --> Helper loaded: file_helper
INFO - 2024-07-08 15:30:40 --> Helper loaded: form_helper
INFO - 2024-07-08 15:30:40 --> Helper loaded: my_helper
INFO - 2024-07-08 15:30:40 --> Database Driver Class Initialized
INFO - 2024-07-08 15:30:40 --> Session: Class initialized using 'files' driver.
INFO - 2024-07-08 15:30:40 --> Controller Class Initialized
INFO - 2024-07-08 15:30:43 --> Config Class Initialized
INFO - 2024-07-08 15:30:43 --> Hooks Class Initialized
DEBUG - 2024-07-08 15:30:43 --> UTF-8 Support Enabled
INFO - 2024-07-08 15:30:43 --> Utf8 Class Initialized
INFO - 2024-07-08 15:30:43 --> URI Class Initialized
INFO - 2024-07-08 15:30:43 --> Router Class Initialized
INFO - 2024-07-08 15:30:43 --> Output Class Initialized
INFO - 2024-07-08 15:30:43 --> Security Class Initialized
DEBUG - 2024-07-08 15:30:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-07-08 15:30:43 --> Input Class Initialized
INFO - 2024-07-08 15:30:43 --> Language Class Initialized
INFO - 2024-07-08 15:30:43 --> Language Class Initialized
INFO - 2024-07-08 15:30:43 --> Config Class Initialized
INFO - 2024-07-08 15:30:43 --> Loader Class Initialized
INFO - 2024-07-08 15:30:43 --> Helper loaded: url_helper
INFO - 2024-07-08 15:30:43 --> Helper loaded: file_helper
INFO - 2024-07-08 15:30:43 --> Helper loaded: form_helper
INFO - 2024-07-08 15:30:43 --> Helper loaded: my_helper
INFO - 2024-07-08 15:30:43 --> Database Driver Class Initialized
INFO - 2024-07-08 15:30:43 --> Session: Class initialized using 'files' driver.
INFO - 2024-07-08 15:30:43 --> Controller Class Initialized
INFO - 2024-07-08 15:30:48 --> Config Class Initialized
INFO - 2024-07-08 15:30:48 --> Hooks Class Initialized
DEBUG - 2024-07-08 15:30:48 --> UTF-8 Support Enabled
INFO - 2024-07-08 15:30:48 --> Utf8 Class Initialized
INFO - 2024-07-08 15:30:48 --> URI Class Initialized
INFO - 2024-07-08 15:30:48 --> Router Class Initialized
INFO - 2024-07-08 15:30:48 --> Output Class Initialized
INFO - 2024-07-08 15:30:48 --> Security Class Initialized
DEBUG - 2024-07-08 15:30:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-07-08 15:30:48 --> Input Class Initialized
INFO - 2024-07-08 15:30:48 --> Language Class Initialized
INFO - 2024-07-08 15:30:48 --> Language Class Initialized
INFO - 2024-07-08 15:30:48 --> Config Class Initialized
INFO - 2024-07-08 15:30:48 --> Loader Class Initialized
INFO - 2024-07-08 15:30:48 --> Helper loaded: url_helper
INFO - 2024-07-08 15:30:48 --> Helper loaded: file_helper
INFO - 2024-07-08 15:30:48 --> Helper loaded: form_helper
INFO - 2024-07-08 15:30:48 --> Helper loaded: my_helper
INFO - 2024-07-08 15:30:48 --> Database Driver Class Initialized
INFO - 2024-07-08 15:30:48 --> Session: Class initialized using 'files' driver.
INFO - 2024-07-08 15:30:48 --> Controller Class Initialized
INFO - 2024-07-08 15:30:48 --> Final output sent to browser
DEBUG - 2024-07-08 15:30:48 --> Total execution time: 0.0545
INFO - 2024-07-08 15:30:48 --> Config Class Initialized
INFO - 2024-07-08 15:30:48 --> Hooks Class Initialized
DEBUG - 2024-07-08 15:30:48 --> UTF-8 Support Enabled
INFO - 2024-07-08 15:30:48 --> Utf8 Class Initialized
INFO - 2024-07-08 15:30:48 --> URI Class Initialized
INFO - 2024-07-08 15:30:48 --> Router Class Initialized
INFO - 2024-07-08 15:30:48 --> Output Class Initialized
INFO - 2024-07-08 15:30:48 --> Security Class Initialized
DEBUG - 2024-07-08 15:30:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-07-08 15:30:48 --> Input Class Initialized
INFO - 2024-07-08 15:30:48 --> Language Class Initialized
ERROR - 2024-07-08 15:30:48 --> 404 Page Not Found: /index
INFO - 2024-07-08 15:30:48 --> Config Class Initialized
INFO - 2024-07-08 15:30:48 --> Hooks Class Initialized
DEBUG - 2024-07-08 15:30:48 --> UTF-8 Support Enabled
INFO - 2024-07-08 15:30:48 --> Utf8 Class Initialized
INFO - 2024-07-08 15:30:48 --> URI Class Initialized
INFO - 2024-07-08 15:30:48 --> Router Class Initialized
INFO - 2024-07-08 15:30:48 --> Output Class Initialized
INFO - 2024-07-08 15:30:48 --> Security Class Initialized
DEBUG - 2024-07-08 15:30:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-07-08 15:30:48 --> Input Class Initialized
INFO - 2024-07-08 15:30:48 --> Language Class Initialized
INFO - 2024-07-08 15:30:48 --> Language Class Initialized
INFO - 2024-07-08 15:30:48 --> Config Class Initialized
INFO - 2024-07-08 15:30:48 --> Loader Class Initialized
INFO - 2024-07-08 15:30:48 --> Helper loaded: url_helper
INFO - 2024-07-08 15:30:48 --> Helper loaded: file_helper
INFO - 2024-07-08 15:30:48 --> Helper loaded: form_helper
INFO - 2024-07-08 15:30:48 --> Helper loaded: my_helper
INFO - 2024-07-08 15:30:48 --> Database Driver Class Initialized
INFO - 2024-07-08 15:30:48 --> Session: Class initialized using 'files' driver.
INFO - 2024-07-08 15:30:48 --> Controller Class Initialized
INFO - 2024-07-08 15:30:50 --> Config Class Initialized
INFO - 2024-07-08 15:30:50 --> Hooks Class Initialized
DEBUG - 2024-07-08 15:30:50 --> UTF-8 Support Enabled
INFO - 2024-07-08 15:30:50 --> Utf8 Class Initialized
INFO - 2024-07-08 15:30:50 --> URI Class Initialized
INFO - 2024-07-08 15:30:50 --> Router Class Initialized
INFO - 2024-07-08 15:30:50 --> Output Class Initialized
INFO - 2024-07-08 15:30:50 --> Security Class Initialized
DEBUG - 2024-07-08 15:30:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-07-08 15:30:50 --> Input Class Initialized
INFO - 2024-07-08 15:30:50 --> Language Class Initialized
INFO - 2024-07-08 15:30:50 --> Language Class Initialized
INFO - 2024-07-08 15:30:50 --> Config Class Initialized
INFO - 2024-07-08 15:30:50 --> Loader Class Initialized
INFO - 2024-07-08 15:30:50 --> Helper loaded: url_helper
INFO - 2024-07-08 15:30:50 --> Helper loaded: file_helper
INFO - 2024-07-08 15:30:50 --> Helper loaded: form_helper
INFO - 2024-07-08 15:30:50 --> Helper loaded: my_helper
INFO - 2024-07-08 15:30:50 --> Database Driver Class Initialized
INFO - 2024-07-08 15:30:50 --> Session: Class initialized using 'files' driver.
INFO - 2024-07-08 15:30:50 --> Controller Class Initialized
INFO - 2024-07-08 15:30:51 --> Config Class Initialized
INFO - 2024-07-08 15:30:51 --> Hooks Class Initialized
DEBUG - 2024-07-08 15:30:51 --> UTF-8 Support Enabled
INFO - 2024-07-08 15:30:51 --> Utf8 Class Initialized
INFO - 2024-07-08 15:30:51 --> URI Class Initialized
INFO - 2024-07-08 15:30:51 --> Router Class Initialized
INFO - 2024-07-08 15:30:51 --> Output Class Initialized
INFO - 2024-07-08 15:30:51 --> Security Class Initialized
DEBUG - 2024-07-08 15:30:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-07-08 15:30:51 --> Input Class Initialized
INFO - 2024-07-08 15:30:51 --> Language Class Initialized
INFO - 2024-07-08 15:30:51 --> Language Class Initialized
INFO - 2024-07-08 15:30:51 --> Config Class Initialized
INFO - 2024-07-08 15:30:51 --> Loader Class Initialized
INFO - 2024-07-08 15:30:51 --> Helper loaded: url_helper
INFO - 2024-07-08 15:30:51 --> Helper loaded: file_helper
INFO - 2024-07-08 15:30:51 --> Helper loaded: form_helper
INFO - 2024-07-08 15:30:51 --> Helper loaded: my_helper
INFO - 2024-07-08 15:30:51 --> Database Driver Class Initialized
INFO - 2024-07-08 15:30:51 --> Session: Class initialized using 'files' driver.
INFO - 2024-07-08 15:30:51 --> Controller Class Initialized
INFO - 2024-07-08 15:30:54 --> Config Class Initialized
INFO - 2024-07-08 15:30:54 --> Hooks Class Initialized
DEBUG - 2024-07-08 15:30:54 --> UTF-8 Support Enabled
INFO - 2024-07-08 15:30:54 --> Utf8 Class Initialized
INFO - 2024-07-08 15:30:54 --> URI Class Initialized
INFO - 2024-07-08 15:30:54 --> Router Class Initialized
INFO - 2024-07-08 15:30:54 --> Output Class Initialized
INFO - 2024-07-08 15:30:54 --> Security Class Initialized
DEBUG - 2024-07-08 15:30:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-07-08 15:30:54 --> Input Class Initialized
INFO - 2024-07-08 15:30:54 --> Language Class Initialized
INFO - 2024-07-08 15:30:54 --> Language Class Initialized
INFO - 2024-07-08 15:30:54 --> Config Class Initialized
INFO - 2024-07-08 15:30:54 --> Loader Class Initialized
INFO - 2024-07-08 15:30:54 --> Helper loaded: url_helper
INFO - 2024-07-08 15:30:54 --> Helper loaded: file_helper
INFO - 2024-07-08 15:30:54 --> Helper loaded: form_helper
INFO - 2024-07-08 15:30:54 --> Helper loaded: my_helper
INFO - 2024-07-08 15:30:54 --> Database Driver Class Initialized
INFO - 2024-07-08 15:30:54 --> Session: Class initialized using 'files' driver.
INFO - 2024-07-08 15:30:54 --> Controller Class Initialized
INFO - 2024-07-08 15:30:54 --> Final output sent to browser
DEBUG - 2024-07-08 15:30:54 --> Total execution time: 0.1072
INFO - 2024-07-08 15:30:54 --> Config Class Initialized
INFO - 2024-07-08 15:30:54 --> Hooks Class Initialized
DEBUG - 2024-07-08 15:30:54 --> UTF-8 Support Enabled
INFO - 2024-07-08 15:30:54 --> Utf8 Class Initialized
INFO - 2024-07-08 15:30:54 --> URI Class Initialized
INFO - 2024-07-08 15:30:54 --> Router Class Initialized
INFO - 2024-07-08 15:30:54 --> Output Class Initialized
INFO - 2024-07-08 15:30:54 --> Security Class Initialized
DEBUG - 2024-07-08 15:30:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-07-08 15:30:54 --> Input Class Initialized
INFO - 2024-07-08 15:30:54 --> Language Class Initialized
ERROR - 2024-07-08 15:30:54 --> 404 Page Not Found: /index
INFO - 2024-07-08 15:30:54 --> Config Class Initialized
INFO - 2024-07-08 15:30:54 --> Hooks Class Initialized
DEBUG - 2024-07-08 15:30:54 --> UTF-8 Support Enabled
INFO - 2024-07-08 15:30:54 --> Utf8 Class Initialized
INFO - 2024-07-08 15:30:54 --> URI Class Initialized
INFO - 2024-07-08 15:30:54 --> Router Class Initialized
INFO - 2024-07-08 15:30:54 --> Output Class Initialized
INFO - 2024-07-08 15:30:54 --> Security Class Initialized
DEBUG - 2024-07-08 15:30:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-07-08 15:30:54 --> Input Class Initialized
INFO - 2024-07-08 15:30:54 --> Language Class Initialized
INFO - 2024-07-08 15:30:54 --> Language Class Initialized
INFO - 2024-07-08 15:30:54 --> Config Class Initialized
INFO - 2024-07-08 15:30:54 --> Loader Class Initialized
INFO - 2024-07-08 15:30:54 --> Helper loaded: url_helper
INFO - 2024-07-08 15:30:54 --> Helper loaded: file_helper
INFO - 2024-07-08 15:30:54 --> Helper loaded: form_helper
INFO - 2024-07-08 15:30:54 --> Helper loaded: my_helper
INFO - 2024-07-08 15:30:54 --> Database Driver Class Initialized
INFO - 2024-07-08 15:30:54 --> Session: Class initialized using 'files' driver.
INFO - 2024-07-08 15:30:54 --> Controller Class Initialized
INFO - 2024-07-08 15:30:59 --> Config Class Initialized
INFO - 2024-07-08 15:30:59 --> Hooks Class Initialized
DEBUG - 2024-07-08 15:30:59 --> UTF-8 Support Enabled
INFO - 2024-07-08 15:30:59 --> Utf8 Class Initialized
INFO - 2024-07-08 15:30:59 --> URI Class Initialized
INFO - 2024-07-08 15:30:59 --> Router Class Initialized
INFO - 2024-07-08 15:30:59 --> Output Class Initialized
INFO - 2024-07-08 15:30:59 --> Security Class Initialized
DEBUG - 2024-07-08 15:30:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-07-08 15:30:59 --> Input Class Initialized
INFO - 2024-07-08 15:30:59 --> Language Class Initialized
INFO - 2024-07-08 15:30:59 --> Language Class Initialized
INFO - 2024-07-08 15:30:59 --> Config Class Initialized
INFO - 2024-07-08 15:30:59 --> Loader Class Initialized
INFO - 2024-07-08 15:30:59 --> Helper loaded: url_helper
INFO - 2024-07-08 15:30:59 --> Helper loaded: file_helper
INFO - 2024-07-08 15:30:59 --> Helper loaded: form_helper
INFO - 2024-07-08 15:30:59 --> Helper loaded: my_helper
INFO - 2024-07-08 15:30:59 --> Database Driver Class Initialized
INFO - 2024-07-08 15:30:59 --> Session: Class initialized using 'files' driver.
INFO - 2024-07-08 15:30:59 --> Controller Class Initialized
ERROR - 2024-07-08 15:30:59 --> Severity: Notice --> Undefined variable: status_form /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/data_siswa/views/form.php 231
DEBUG - 2024-07-08 15:30:59 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/data_siswa/views/form.php
DEBUG - 2024-07-08 15:30:59 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-07-08 15:30:59 --> Final output sent to browser
DEBUG - 2024-07-08 15:30:59 --> Total execution time: 0.0989
INFO - 2024-07-08 15:31:08 --> Config Class Initialized
INFO - 2024-07-08 15:31:08 --> Hooks Class Initialized
DEBUG - 2024-07-08 15:31:08 --> UTF-8 Support Enabled
INFO - 2024-07-08 15:31:08 --> Utf8 Class Initialized
INFO - 2024-07-08 15:31:08 --> URI Class Initialized
INFO - 2024-07-08 15:31:08 --> Router Class Initialized
INFO - 2024-07-08 15:31:08 --> Output Class Initialized
INFO - 2024-07-08 15:31:08 --> Security Class Initialized
DEBUG - 2024-07-08 15:31:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-07-08 15:31:08 --> Input Class Initialized
INFO - 2024-07-08 15:31:08 --> Language Class Initialized
INFO - 2024-07-08 15:31:08 --> Language Class Initialized
INFO - 2024-07-08 15:31:08 --> Config Class Initialized
INFO - 2024-07-08 15:31:08 --> Loader Class Initialized
INFO - 2024-07-08 15:31:08 --> Helper loaded: url_helper
INFO - 2024-07-08 15:31:08 --> Helper loaded: file_helper
INFO - 2024-07-08 15:31:08 --> Helper loaded: form_helper
INFO - 2024-07-08 15:31:08 --> Helper loaded: my_helper
INFO - 2024-07-08 15:31:08 --> Database Driver Class Initialized
INFO - 2024-07-08 15:31:08 --> Session: Class initialized using 'files' driver.
INFO - 2024-07-08 15:31:08 --> Controller Class Initialized
DEBUG - 2024-07-08 15:31:08 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/data_siswa/views/list.php
DEBUG - 2024-07-08 15:31:08 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-07-08 15:31:08 --> Final output sent to browser
DEBUG - 2024-07-08 15:31:08 --> Total execution time: 0.0302
INFO - 2024-07-08 15:31:08 --> Config Class Initialized
INFO - 2024-07-08 15:31:08 --> Hooks Class Initialized
DEBUG - 2024-07-08 15:31:08 --> UTF-8 Support Enabled
INFO - 2024-07-08 15:31:08 --> Utf8 Class Initialized
INFO - 2024-07-08 15:31:08 --> URI Class Initialized
INFO - 2024-07-08 15:31:08 --> Router Class Initialized
INFO - 2024-07-08 15:31:08 --> Output Class Initialized
INFO - 2024-07-08 15:31:08 --> Security Class Initialized
DEBUG - 2024-07-08 15:31:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-07-08 15:31:08 --> Input Class Initialized
INFO - 2024-07-08 15:31:08 --> Language Class Initialized
ERROR - 2024-07-08 15:31:08 --> 404 Page Not Found: /index
INFO - 2024-07-08 15:31:08 --> Config Class Initialized
INFO - 2024-07-08 15:31:08 --> Hooks Class Initialized
DEBUG - 2024-07-08 15:31:08 --> UTF-8 Support Enabled
INFO - 2024-07-08 15:31:08 --> Utf8 Class Initialized
INFO - 2024-07-08 15:31:08 --> URI Class Initialized
INFO - 2024-07-08 15:31:08 --> Router Class Initialized
INFO - 2024-07-08 15:31:08 --> Output Class Initialized
INFO - 2024-07-08 15:31:08 --> Security Class Initialized
DEBUG - 2024-07-08 15:31:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-07-08 15:31:08 --> Input Class Initialized
INFO - 2024-07-08 15:31:08 --> Language Class Initialized
INFO - 2024-07-08 15:31:08 --> Language Class Initialized
INFO - 2024-07-08 15:31:08 --> Config Class Initialized
INFO - 2024-07-08 15:31:08 --> Loader Class Initialized
INFO - 2024-07-08 15:31:08 --> Helper loaded: url_helper
INFO - 2024-07-08 15:31:08 --> Helper loaded: file_helper
INFO - 2024-07-08 15:31:08 --> Helper loaded: form_helper
INFO - 2024-07-08 15:31:08 --> Helper loaded: my_helper
INFO - 2024-07-08 15:31:08 --> Database Driver Class Initialized
INFO - 2024-07-08 15:31:08 --> Session: Class initialized using 'files' driver.
INFO - 2024-07-08 15:31:08 --> Controller Class Initialized
INFO - 2024-07-08 15:31:10 --> Config Class Initialized
INFO - 2024-07-08 15:31:10 --> Hooks Class Initialized
DEBUG - 2024-07-08 15:31:10 --> UTF-8 Support Enabled
INFO - 2024-07-08 15:31:10 --> Utf8 Class Initialized
INFO - 2024-07-08 15:31:10 --> URI Class Initialized
INFO - 2024-07-08 15:31:10 --> Router Class Initialized
INFO - 2024-07-08 15:31:10 --> Output Class Initialized
INFO - 2024-07-08 15:31:10 --> Security Class Initialized
DEBUG - 2024-07-08 15:31:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-07-08 15:31:10 --> Input Class Initialized
INFO - 2024-07-08 15:31:10 --> Language Class Initialized
INFO - 2024-07-08 15:31:10 --> Language Class Initialized
INFO - 2024-07-08 15:31:10 --> Config Class Initialized
INFO - 2024-07-08 15:31:10 --> Loader Class Initialized
INFO - 2024-07-08 15:31:10 --> Helper loaded: url_helper
INFO - 2024-07-08 15:31:10 --> Helper loaded: file_helper
INFO - 2024-07-08 15:31:10 --> Helper loaded: form_helper
INFO - 2024-07-08 15:31:10 --> Helper loaded: my_helper
INFO - 2024-07-08 15:31:10 --> Database Driver Class Initialized
INFO - 2024-07-08 15:31:10 --> Session: Class initialized using 'files' driver.
INFO - 2024-07-08 15:31:10 --> Controller Class Initialized
INFO - 2024-07-08 15:31:13 --> Config Class Initialized
INFO - 2024-07-08 15:31:13 --> Hooks Class Initialized
DEBUG - 2024-07-08 15:31:13 --> UTF-8 Support Enabled
INFO - 2024-07-08 15:31:13 --> Utf8 Class Initialized
INFO - 2024-07-08 15:31:13 --> URI Class Initialized
INFO - 2024-07-08 15:31:13 --> Router Class Initialized
INFO - 2024-07-08 15:31:13 --> Output Class Initialized
INFO - 2024-07-08 15:31:13 --> Security Class Initialized
DEBUG - 2024-07-08 15:31:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-07-08 15:31:13 --> Input Class Initialized
INFO - 2024-07-08 15:31:13 --> Language Class Initialized
INFO - 2024-07-08 15:31:13 --> Language Class Initialized
INFO - 2024-07-08 15:31:13 --> Config Class Initialized
INFO - 2024-07-08 15:31:13 --> Loader Class Initialized
INFO - 2024-07-08 15:31:13 --> Helper loaded: url_helper
INFO - 2024-07-08 15:31:13 --> Helper loaded: file_helper
INFO - 2024-07-08 15:31:13 --> Helper loaded: form_helper
INFO - 2024-07-08 15:31:13 --> Helper loaded: my_helper
INFO - 2024-07-08 15:31:13 --> Database Driver Class Initialized
INFO - 2024-07-08 15:31:13 --> Session: Class initialized using 'files' driver.
INFO - 2024-07-08 15:31:13 --> Controller Class Initialized
ERROR - 2024-07-08 15:31:13 --> Severity: Notice --> Undefined variable: status_form /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/data_siswa/views/form.php 231
DEBUG - 2024-07-08 15:31:13 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/data_siswa/views/form.php
DEBUG - 2024-07-08 15:31:13 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-07-08 15:31:13 --> Final output sent to browser
DEBUG - 2024-07-08 15:31:13 --> Total execution time: 0.0364
INFO - 2024-07-08 15:31:19 --> Config Class Initialized
INFO - 2024-07-08 15:31:19 --> Hooks Class Initialized
DEBUG - 2024-07-08 15:31:19 --> UTF-8 Support Enabled
INFO - 2024-07-08 15:31:19 --> Utf8 Class Initialized
INFO - 2024-07-08 15:31:19 --> URI Class Initialized
INFO - 2024-07-08 15:31:19 --> Router Class Initialized
INFO - 2024-07-08 15:31:19 --> Output Class Initialized
INFO - 2024-07-08 15:31:19 --> Security Class Initialized
DEBUG - 2024-07-08 15:31:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-07-08 15:31:19 --> Input Class Initialized
INFO - 2024-07-08 15:31:19 --> Language Class Initialized
INFO - 2024-07-08 15:31:19 --> Language Class Initialized
INFO - 2024-07-08 15:31:19 --> Config Class Initialized
INFO - 2024-07-08 15:31:19 --> Loader Class Initialized
INFO - 2024-07-08 15:31:19 --> Helper loaded: url_helper
INFO - 2024-07-08 15:31:19 --> Helper loaded: file_helper
INFO - 2024-07-08 15:31:19 --> Helper loaded: form_helper
INFO - 2024-07-08 15:31:19 --> Helper loaded: my_helper
INFO - 2024-07-08 15:31:19 --> Database Driver Class Initialized
INFO - 2024-07-08 15:31:19 --> Session: Class initialized using 'files' driver.
INFO - 2024-07-08 15:31:19 --> Controller Class Initialized
INFO - 2024-07-08 15:31:19 --> Upload Class Initialized
INFO - 2024-07-08 15:31:19 --> Language file loaded: language/english/upload_lang.php
ERROR - 2024-07-08 15:31:19 --> The upload path does not appear to be valid.
INFO - 2024-07-08 15:31:19 --> Config Class Initialized
INFO - 2024-07-08 15:31:19 --> Hooks Class Initialized
DEBUG - 2024-07-08 15:31:19 --> UTF-8 Support Enabled
INFO - 2024-07-08 15:31:19 --> Utf8 Class Initialized
INFO - 2024-07-08 15:31:19 --> URI Class Initialized
INFO - 2024-07-08 15:31:19 --> Router Class Initialized
INFO - 2024-07-08 15:31:19 --> Output Class Initialized
INFO - 2024-07-08 15:31:19 --> Security Class Initialized
DEBUG - 2024-07-08 15:31:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-07-08 15:31:19 --> Input Class Initialized
INFO - 2024-07-08 15:31:19 --> Language Class Initialized
INFO - 2024-07-08 15:31:19 --> Language Class Initialized
INFO - 2024-07-08 15:31:19 --> Config Class Initialized
INFO - 2024-07-08 15:31:19 --> Loader Class Initialized
INFO - 2024-07-08 15:31:19 --> Helper loaded: url_helper
INFO - 2024-07-08 15:31:19 --> Helper loaded: file_helper
INFO - 2024-07-08 15:31:19 --> Helper loaded: form_helper
INFO - 2024-07-08 15:31:19 --> Helper loaded: my_helper
INFO - 2024-07-08 15:31:19 --> Database Driver Class Initialized
INFO - 2024-07-08 15:31:19 --> Session: Class initialized using 'files' driver.
INFO - 2024-07-08 15:31:19 --> Controller Class Initialized
DEBUG - 2024-07-08 15:31:19 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/data_siswa/views/list.php
DEBUG - 2024-07-08 15:31:19 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-07-08 15:31:19 --> Final output sent to browser
DEBUG - 2024-07-08 15:31:19 --> Total execution time: 0.0297
INFO - 2024-07-08 15:31:19 --> Config Class Initialized
INFO - 2024-07-08 15:31:19 --> Hooks Class Initialized
DEBUG - 2024-07-08 15:31:19 --> UTF-8 Support Enabled
INFO - 2024-07-08 15:31:19 --> Utf8 Class Initialized
INFO - 2024-07-08 15:31:19 --> URI Class Initialized
INFO - 2024-07-08 15:31:19 --> Router Class Initialized
INFO - 2024-07-08 15:31:19 --> Output Class Initialized
INFO - 2024-07-08 15:31:19 --> Security Class Initialized
DEBUG - 2024-07-08 15:31:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-07-08 15:31:19 --> Input Class Initialized
INFO - 2024-07-08 15:31:19 --> Language Class Initialized
ERROR - 2024-07-08 15:31:19 --> 404 Page Not Found: /index
INFO - 2024-07-08 15:31:19 --> Config Class Initialized
INFO - 2024-07-08 15:31:19 --> Hooks Class Initialized
DEBUG - 2024-07-08 15:31:19 --> UTF-8 Support Enabled
INFO - 2024-07-08 15:31:19 --> Utf8 Class Initialized
INFO - 2024-07-08 15:31:19 --> URI Class Initialized
INFO - 2024-07-08 15:31:19 --> Router Class Initialized
INFO - 2024-07-08 15:31:19 --> Output Class Initialized
INFO - 2024-07-08 15:31:19 --> Security Class Initialized
DEBUG - 2024-07-08 15:31:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-07-08 15:31:19 --> Input Class Initialized
INFO - 2024-07-08 15:31:19 --> Language Class Initialized
INFO - 2024-07-08 15:31:19 --> Language Class Initialized
INFO - 2024-07-08 15:31:19 --> Config Class Initialized
INFO - 2024-07-08 15:31:19 --> Loader Class Initialized
INFO - 2024-07-08 15:31:19 --> Helper loaded: url_helper
INFO - 2024-07-08 15:31:19 --> Helper loaded: file_helper
INFO - 2024-07-08 15:31:19 --> Helper loaded: form_helper
INFO - 2024-07-08 15:31:19 --> Helper loaded: my_helper
INFO - 2024-07-08 15:31:19 --> Database Driver Class Initialized
INFO - 2024-07-08 15:31:19 --> Session: Class initialized using 'files' driver.
INFO - 2024-07-08 15:31:19 --> Controller Class Initialized
INFO - 2024-07-08 15:31:29 --> Config Class Initialized
INFO - 2024-07-08 15:31:29 --> Hooks Class Initialized
DEBUG - 2024-07-08 15:31:29 --> UTF-8 Support Enabled
INFO - 2024-07-08 15:31:29 --> Utf8 Class Initialized
INFO - 2024-07-08 15:31:29 --> URI Class Initialized
INFO - 2024-07-08 15:31:29 --> Router Class Initialized
INFO - 2024-07-08 15:31:29 --> Output Class Initialized
INFO - 2024-07-08 15:31:29 --> Security Class Initialized
DEBUG - 2024-07-08 15:31:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-07-08 15:31:29 --> Input Class Initialized
INFO - 2024-07-08 15:31:29 --> Language Class Initialized
INFO - 2024-07-08 15:31:29 --> Language Class Initialized
INFO - 2024-07-08 15:31:29 --> Config Class Initialized
INFO - 2024-07-08 15:31:29 --> Loader Class Initialized
INFO - 2024-07-08 15:31:29 --> Helper loaded: url_helper
INFO - 2024-07-08 15:31:29 --> Helper loaded: file_helper
INFO - 2024-07-08 15:31:29 --> Helper loaded: form_helper
INFO - 2024-07-08 15:31:29 --> Helper loaded: my_helper
INFO - 2024-07-08 15:31:29 --> Database Driver Class Initialized
INFO - 2024-07-08 15:31:29 --> Session: Class initialized using 'files' driver.
INFO - 2024-07-08 15:31:29 --> Controller Class Initialized
INFO - 2024-07-08 15:31:30 --> Config Class Initialized
INFO - 2024-07-08 15:31:30 --> Hooks Class Initialized
DEBUG - 2024-07-08 15:31:30 --> UTF-8 Support Enabled
INFO - 2024-07-08 15:31:30 --> Utf8 Class Initialized
INFO - 2024-07-08 15:31:30 --> URI Class Initialized
INFO - 2024-07-08 15:31:30 --> Router Class Initialized
INFO - 2024-07-08 15:31:30 --> Output Class Initialized
INFO - 2024-07-08 15:31:30 --> Security Class Initialized
DEBUG - 2024-07-08 15:31:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-07-08 15:31:30 --> Input Class Initialized
INFO - 2024-07-08 15:31:30 --> Language Class Initialized
INFO - 2024-07-08 15:31:30 --> Language Class Initialized
INFO - 2024-07-08 15:31:30 --> Config Class Initialized
INFO - 2024-07-08 15:31:30 --> Loader Class Initialized
INFO - 2024-07-08 15:31:30 --> Helper loaded: url_helper
INFO - 2024-07-08 15:31:30 --> Helper loaded: file_helper
INFO - 2024-07-08 15:31:30 --> Helper loaded: form_helper
INFO - 2024-07-08 15:31:30 --> Helper loaded: my_helper
INFO - 2024-07-08 15:31:30 --> Database Driver Class Initialized
INFO - 2024-07-08 15:31:30 --> Session: Class initialized using 'files' driver.
INFO - 2024-07-08 15:31:30 --> Controller Class Initialized
INFO - 2024-07-08 15:31:32 --> Config Class Initialized
INFO - 2024-07-08 15:31:32 --> Hooks Class Initialized
DEBUG - 2024-07-08 15:31:32 --> UTF-8 Support Enabled
INFO - 2024-07-08 15:31:32 --> Utf8 Class Initialized
INFO - 2024-07-08 15:31:32 --> URI Class Initialized
INFO - 2024-07-08 15:31:32 --> Router Class Initialized
INFO - 2024-07-08 15:31:32 --> Output Class Initialized
INFO - 2024-07-08 15:31:32 --> Security Class Initialized
DEBUG - 2024-07-08 15:31:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-07-08 15:31:32 --> Input Class Initialized
INFO - 2024-07-08 15:31:32 --> Language Class Initialized
INFO - 2024-07-08 15:31:32 --> Language Class Initialized
INFO - 2024-07-08 15:31:32 --> Config Class Initialized
INFO - 2024-07-08 15:31:32 --> Loader Class Initialized
INFO - 2024-07-08 15:31:32 --> Helper loaded: url_helper
INFO - 2024-07-08 15:31:32 --> Helper loaded: file_helper
INFO - 2024-07-08 15:31:32 --> Helper loaded: form_helper
INFO - 2024-07-08 15:31:32 --> Helper loaded: my_helper
INFO - 2024-07-08 15:31:32 --> Database Driver Class Initialized
INFO - 2024-07-08 15:31:32 --> Session: Class initialized using 'files' driver.
INFO - 2024-07-08 15:31:32 --> Controller Class Initialized
DEBUG - 2024-07-08 15:31:32 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/data_kelas/views/list.php
DEBUG - 2024-07-08 15:31:32 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-07-08 15:31:32 --> Final output sent to browser
DEBUG - 2024-07-08 15:31:32 --> Total execution time: 0.0382
INFO - 2024-07-08 15:31:32 --> Config Class Initialized
INFO - 2024-07-08 15:31:32 --> Hooks Class Initialized
DEBUG - 2024-07-08 15:31:32 --> UTF-8 Support Enabled
INFO - 2024-07-08 15:31:32 --> Utf8 Class Initialized
INFO - 2024-07-08 15:31:32 --> URI Class Initialized
INFO - 2024-07-08 15:31:32 --> Router Class Initialized
INFO - 2024-07-08 15:31:32 --> Output Class Initialized
INFO - 2024-07-08 15:31:32 --> Security Class Initialized
DEBUG - 2024-07-08 15:31:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-07-08 15:31:32 --> Input Class Initialized
INFO - 2024-07-08 15:31:32 --> Language Class Initialized
ERROR - 2024-07-08 15:31:32 --> 404 Page Not Found: /index
INFO - 2024-07-08 15:31:32 --> Config Class Initialized
INFO - 2024-07-08 15:31:32 --> Hooks Class Initialized
DEBUG - 2024-07-08 15:31:32 --> UTF-8 Support Enabled
INFO - 2024-07-08 15:31:32 --> Utf8 Class Initialized
INFO - 2024-07-08 15:31:32 --> URI Class Initialized
INFO - 2024-07-08 15:31:32 --> Router Class Initialized
INFO - 2024-07-08 15:31:32 --> Output Class Initialized
INFO - 2024-07-08 15:31:32 --> Security Class Initialized
DEBUG - 2024-07-08 15:31:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-07-08 15:31:32 --> Input Class Initialized
INFO - 2024-07-08 15:31:32 --> Language Class Initialized
INFO - 2024-07-08 15:31:32 --> Language Class Initialized
INFO - 2024-07-08 15:31:32 --> Config Class Initialized
INFO - 2024-07-08 15:31:32 --> Loader Class Initialized
INFO - 2024-07-08 15:31:32 --> Helper loaded: url_helper
INFO - 2024-07-08 15:31:32 --> Helper loaded: file_helper
INFO - 2024-07-08 15:31:32 --> Helper loaded: form_helper
INFO - 2024-07-08 15:31:32 --> Helper loaded: my_helper
INFO - 2024-07-08 15:31:32 --> Database Driver Class Initialized
INFO - 2024-07-08 15:31:32 --> Session: Class initialized using 'files' driver.
INFO - 2024-07-08 15:31:32 --> Controller Class Initialized
INFO - 2024-07-08 15:31:35 --> Config Class Initialized
INFO - 2024-07-08 15:31:35 --> Hooks Class Initialized
DEBUG - 2024-07-08 15:31:35 --> UTF-8 Support Enabled
INFO - 2024-07-08 15:31:35 --> Utf8 Class Initialized
INFO - 2024-07-08 15:31:35 --> URI Class Initialized
INFO - 2024-07-08 15:31:35 --> Router Class Initialized
INFO - 2024-07-08 15:31:35 --> Output Class Initialized
INFO - 2024-07-08 15:31:35 --> Security Class Initialized
DEBUG - 2024-07-08 15:31:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-07-08 15:31:35 --> Input Class Initialized
INFO - 2024-07-08 15:31:35 --> Language Class Initialized
INFO - 2024-07-08 15:31:35 --> Language Class Initialized
INFO - 2024-07-08 15:31:35 --> Config Class Initialized
INFO - 2024-07-08 15:31:35 --> Loader Class Initialized
INFO - 2024-07-08 15:31:35 --> Helper loaded: url_helper
INFO - 2024-07-08 15:31:35 --> Helper loaded: file_helper
INFO - 2024-07-08 15:31:35 --> Helper loaded: form_helper
INFO - 2024-07-08 15:31:35 --> Helper loaded: my_helper
INFO - 2024-07-08 15:31:35 --> Database Driver Class Initialized
INFO - 2024-07-08 15:31:35 --> Session: Class initialized using 'files' driver.
INFO - 2024-07-08 15:31:35 --> Controller Class Initialized
INFO - 2024-07-08 15:31:35 --> Final output sent to browser
DEBUG - 2024-07-08 15:31:35 --> Total execution time: 0.0455
INFO - 2024-07-08 15:31:41 --> Config Class Initialized
INFO - 2024-07-08 15:31:41 --> Hooks Class Initialized
DEBUG - 2024-07-08 15:31:41 --> UTF-8 Support Enabled
INFO - 2024-07-08 15:31:41 --> Utf8 Class Initialized
INFO - 2024-07-08 15:31:41 --> URI Class Initialized
INFO - 2024-07-08 15:31:41 --> Router Class Initialized
INFO - 2024-07-08 15:31:41 --> Output Class Initialized
INFO - 2024-07-08 15:31:41 --> Security Class Initialized
DEBUG - 2024-07-08 15:31:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-07-08 15:31:41 --> Input Class Initialized
INFO - 2024-07-08 15:31:41 --> Language Class Initialized
INFO - 2024-07-08 15:31:41 --> Language Class Initialized
INFO - 2024-07-08 15:31:41 --> Config Class Initialized
INFO - 2024-07-08 15:31:41 --> Loader Class Initialized
INFO - 2024-07-08 15:31:41 --> Helper loaded: url_helper
INFO - 2024-07-08 15:31:41 --> Helper loaded: file_helper
INFO - 2024-07-08 15:31:41 --> Helper loaded: form_helper
INFO - 2024-07-08 15:31:41 --> Helper loaded: my_helper
INFO - 2024-07-08 15:31:41 --> Database Driver Class Initialized
INFO - 2024-07-08 15:31:41 --> Session: Class initialized using 'files' driver.
INFO - 2024-07-08 15:31:41 --> Controller Class Initialized
INFO - 2024-07-08 15:31:41 --> Final output sent to browser
DEBUG - 2024-07-08 15:31:41 --> Total execution time: 0.0359
INFO - 2024-07-08 15:31:41 --> Config Class Initialized
INFO - 2024-07-08 15:31:41 --> Hooks Class Initialized
DEBUG - 2024-07-08 15:31:41 --> UTF-8 Support Enabled
INFO - 2024-07-08 15:31:41 --> Utf8 Class Initialized
INFO - 2024-07-08 15:31:41 --> URI Class Initialized
INFO - 2024-07-08 15:31:41 --> Router Class Initialized
INFO - 2024-07-08 15:31:41 --> Output Class Initialized
INFO - 2024-07-08 15:31:41 --> Security Class Initialized
DEBUG - 2024-07-08 15:31:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-07-08 15:31:41 --> Input Class Initialized
INFO - 2024-07-08 15:31:41 --> Language Class Initialized
ERROR - 2024-07-08 15:31:41 --> 404 Page Not Found: /index
INFO - 2024-07-08 15:31:41 --> Config Class Initialized
INFO - 2024-07-08 15:31:41 --> Hooks Class Initialized
DEBUG - 2024-07-08 15:31:41 --> UTF-8 Support Enabled
INFO - 2024-07-08 15:31:41 --> Utf8 Class Initialized
INFO - 2024-07-08 15:31:41 --> URI Class Initialized
INFO - 2024-07-08 15:31:41 --> Router Class Initialized
INFO - 2024-07-08 15:31:41 --> Output Class Initialized
INFO - 2024-07-08 15:31:41 --> Security Class Initialized
DEBUG - 2024-07-08 15:31:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-07-08 15:31:41 --> Input Class Initialized
INFO - 2024-07-08 15:31:41 --> Language Class Initialized
INFO - 2024-07-08 15:31:41 --> Language Class Initialized
INFO - 2024-07-08 15:31:41 --> Config Class Initialized
INFO - 2024-07-08 15:31:41 --> Loader Class Initialized
INFO - 2024-07-08 15:31:41 --> Helper loaded: url_helper
INFO - 2024-07-08 15:31:41 --> Helper loaded: file_helper
INFO - 2024-07-08 15:31:41 --> Helper loaded: form_helper
INFO - 2024-07-08 15:31:41 --> Helper loaded: my_helper
INFO - 2024-07-08 15:31:41 --> Database Driver Class Initialized
INFO - 2024-07-08 15:31:41 --> Session: Class initialized using 'files' driver.
INFO - 2024-07-08 15:31:41 --> Controller Class Initialized
INFO - 2024-07-08 15:31:47 --> Config Class Initialized
INFO - 2024-07-08 15:31:47 --> Hooks Class Initialized
DEBUG - 2024-07-08 15:31:47 --> UTF-8 Support Enabled
INFO - 2024-07-08 15:31:47 --> Utf8 Class Initialized
INFO - 2024-07-08 15:31:47 --> URI Class Initialized
INFO - 2024-07-08 15:31:47 --> Router Class Initialized
INFO - 2024-07-08 15:31:47 --> Output Class Initialized
INFO - 2024-07-08 15:31:47 --> Security Class Initialized
DEBUG - 2024-07-08 15:31:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-07-08 15:31:47 --> Input Class Initialized
INFO - 2024-07-08 15:31:47 --> Language Class Initialized
INFO - 2024-07-08 15:31:47 --> Language Class Initialized
INFO - 2024-07-08 15:31:47 --> Config Class Initialized
INFO - 2024-07-08 15:31:47 --> Loader Class Initialized
INFO - 2024-07-08 15:31:47 --> Helper loaded: url_helper
INFO - 2024-07-08 15:31:47 --> Helper loaded: file_helper
INFO - 2024-07-08 15:31:47 --> Helper loaded: form_helper
INFO - 2024-07-08 15:31:47 --> Helper loaded: my_helper
INFO - 2024-07-08 15:31:47 --> Database Driver Class Initialized
INFO - 2024-07-08 15:31:47 --> Session: Class initialized using 'files' driver.
INFO - 2024-07-08 15:31:47 --> Controller Class Initialized
DEBUG - 2024-07-08 15:31:47 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/data_siswa/views/list.php
DEBUG - 2024-07-08 15:31:47 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-07-08 15:31:47 --> Final output sent to browser
DEBUG - 2024-07-08 15:31:47 --> Total execution time: 0.0303
INFO - 2024-07-08 15:31:47 --> Config Class Initialized
INFO - 2024-07-08 15:31:47 --> Hooks Class Initialized
DEBUG - 2024-07-08 15:31:47 --> UTF-8 Support Enabled
INFO - 2024-07-08 15:31:47 --> Utf8 Class Initialized
INFO - 2024-07-08 15:31:47 --> URI Class Initialized
INFO - 2024-07-08 15:31:47 --> Router Class Initialized
INFO - 2024-07-08 15:31:47 --> Output Class Initialized
INFO - 2024-07-08 15:31:47 --> Security Class Initialized
DEBUG - 2024-07-08 15:31:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-07-08 15:31:47 --> Input Class Initialized
INFO - 2024-07-08 15:31:47 --> Language Class Initialized
ERROR - 2024-07-08 15:31:47 --> 404 Page Not Found: /index
INFO - 2024-07-08 15:31:47 --> Config Class Initialized
INFO - 2024-07-08 15:31:47 --> Hooks Class Initialized
DEBUG - 2024-07-08 15:31:47 --> UTF-8 Support Enabled
INFO - 2024-07-08 15:31:47 --> Utf8 Class Initialized
INFO - 2024-07-08 15:31:47 --> URI Class Initialized
INFO - 2024-07-08 15:31:47 --> Router Class Initialized
INFO - 2024-07-08 15:31:47 --> Output Class Initialized
INFO - 2024-07-08 15:31:47 --> Security Class Initialized
DEBUG - 2024-07-08 15:31:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-07-08 15:31:47 --> Input Class Initialized
INFO - 2024-07-08 15:31:47 --> Language Class Initialized
INFO - 2024-07-08 15:31:47 --> Language Class Initialized
INFO - 2024-07-08 15:31:47 --> Config Class Initialized
INFO - 2024-07-08 15:31:47 --> Loader Class Initialized
INFO - 2024-07-08 15:31:47 --> Helper loaded: url_helper
INFO - 2024-07-08 15:31:47 --> Helper loaded: file_helper
INFO - 2024-07-08 15:31:47 --> Helper loaded: form_helper
INFO - 2024-07-08 15:31:47 --> Helper loaded: my_helper
INFO - 2024-07-08 15:31:47 --> Database Driver Class Initialized
INFO - 2024-07-08 15:31:47 --> Session: Class initialized using 'files' driver.
INFO - 2024-07-08 15:31:47 --> Controller Class Initialized
INFO - 2024-07-08 15:32:07 --> Config Class Initialized
INFO - 2024-07-08 15:32:07 --> Hooks Class Initialized
DEBUG - 2024-07-08 15:32:07 --> UTF-8 Support Enabled
INFO - 2024-07-08 15:32:07 --> Utf8 Class Initialized
INFO - 2024-07-08 15:32:07 --> URI Class Initialized
INFO - 2024-07-08 15:32:07 --> Router Class Initialized
INFO - 2024-07-08 15:32:07 --> Output Class Initialized
INFO - 2024-07-08 15:32:07 --> Security Class Initialized
DEBUG - 2024-07-08 15:32:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-07-08 15:32:07 --> Input Class Initialized
INFO - 2024-07-08 15:32:07 --> Language Class Initialized
INFO - 2024-07-08 15:32:07 --> Language Class Initialized
INFO - 2024-07-08 15:32:07 --> Config Class Initialized
INFO - 2024-07-08 15:32:07 --> Loader Class Initialized
INFO - 2024-07-08 15:32:07 --> Helper loaded: url_helper
INFO - 2024-07-08 15:32:07 --> Helper loaded: file_helper
INFO - 2024-07-08 15:32:07 --> Helper loaded: form_helper
INFO - 2024-07-08 15:32:07 --> Helper loaded: my_helper
INFO - 2024-07-08 15:32:07 --> Database Driver Class Initialized
INFO - 2024-07-08 15:32:07 --> Session: Class initialized using 'files' driver.
INFO - 2024-07-08 15:32:07 --> Controller Class Initialized
INFO - 2024-07-08 15:32:11 --> Config Class Initialized
INFO - 2024-07-08 15:32:11 --> Hooks Class Initialized
DEBUG - 2024-07-08 15:32:11 --> UTF-8 Support Enabled
INFO - 2024-07-08 15:32:11 --> Utf8 Class Initialized
INFO - 2024-07-08 15:32:11 --> URI Class Initialized
INFO - 2024-07-08 15:32:11 --> Router Class Initialized
INFO - 2024-07-08 15:32:11 --> Output Class Initialized
INFO - 2024-07-08 15:32:11 --> Security Class Initialized
DEBUG - 2024-07-08 15:32:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-07-08 15:32:11 --> Input Class Initialized
INFO - 2024-07-08 15:32:11 --> Language Class Initialized
INFO - 2024-07-08 15:32:11 --> Language Class Initialized
INFO - 2024-07-08 15:32:11 --> Config Class Initialized
INFO - 2024-07-08 15:32:11 --> Loader Class Initialized
INFO - 2024-07-08 15:32:11 --> Helper loaded: url_helper
INFO - 2024-07-08 15:32:11 --> Helper loaded: file_helper
INFO - 2024-07-08 15:32:11 --> Helper loaded: form_helper
INFO - 2024-07-08 15:32:11 --> Helper loaded: my_helper
INFO - 2024-07-08 15:32:11 --> Database Driver Class Initialized
INFO - 2024-07-08 15:32:11 --> Session: Class initialized using 'files' driver.
INFO - 2024-07-08 15:32:11 --> Controller Class Initialized
INFO - 2024-07-08 15:32:11 --> Final output sent to browser
DEBUG - 2024-07-08 15:32:11 --> Total execution time: 0.0455
INFO - 2024-07-08 15:32:11 --> Config Class Initialized
INFO - 2024-07-08 15:32:11 --> Hooks Class Initialized
DEBUG - 2024-07-08 15:32:11 --> UTF-8 Support Enabled
INFO - 2024-07-08 15:32:11 --> Utf8 Class Initialized
INFO - 2024-07-08 15:32:11 --> URI Class Initialized
INFO - 2024-07-08 15:32:11 --> Router Class Initialized
INFO - 2024-07-08 15:32:11 --> Output Class Initialized
INFO - 2024-07-08 15:32:11 --> Security Class Initialized
DEBUG - 2024-07-08 15:32:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-07-08 15:32:11 --> Input Class Initialized
INFO - 2024-07-08 15:32:11 --> Language Class Initialized
ERROR - 2024-07-08 15:32:11 --> 404 Page Not Found: /index
INFO - 2024-07-08 15:32:11 --> Config Class Initialized
INFO - 2024-07-08 15:32:11 --> Hooks Class Initialized
DEBUG - 2024-07-08 15:32:11 --> UTF-8 Support Enabled
INFO - 2024-07-08 15:32:11 --> Utf8 Class Initialized
INFO - 2024-07-08 15:32:11 --> URI Class Initialized
INFO - 2024-07-08 15:32:11 --> Router Class Initialized
INFO - 2024-07-08 15:32:11 --> Output Class Initialized
INFO - 2024-07-08 15:32:11 --> Security Class Initialized
DEBUG - 2024-07-08 15:32:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-07-08 15:32:11 --> Input Class Initialized
INFO - 2024-07-08 15:32:11 --> Language Class Initialized
INFO - 2024-07-08 15:32:11 --> Language Class Initialized
INFO - 2024-07-08 15:32:11 --> Config Class Initialized
INFO - 2024-07-08 15:32:11 --> Loader Class Initialized
INFO - 2024-07-08 15:32:11 --> Helper loaded: url_helper
INFO - 2024-07-08 15:32:11 --> Helper loaded: file_helper
INFO - 2024-07-08 15:32:11 --> Helper loaded: form_helper
INFO - 2024-07-08 15:32:11 --> Helper loaded: my_helper
INFO - 2024-07-08 15:32:11 --> Database Driver Class Initialized
INFO - 2024-07-08 15:32:11 --> Session: Class initialized using 'files' driver.
INFO - 2024-07-08 15:32:11 --> Controller Class Initialized
INFO - 2024-07-08 15:32:15 --> Config Class Initialized
INFO - 2024-07-08 15:32:15 --> Hooks Class Initialized
DEBUG - 2024-07-08 15:32:15 --> UTF-8 Support Enabled
INFO - 2024-07-08 15:32:15 --> Utf8 Class Initialized
INFO - 2024-07-08 15:32:15 --> URI Class Initialized
INFO - 2024-07-08 15:32:15 --> Router Class Initialized
INFO - 2024-07-08 15:32:15 --> Output Class Initialized
INFO - 2024-07-08 15:32:15 --> Security Class Initialized
DEBUG - 2024-07-08 15:32:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-07-08 15:32:15 --> Input Class Initialized
INFO - 2024-07-08 15:32:15 --> Language Class Initialized
INFO - 2024-07-08 15:32:15 --> Language Class Initialized
INFO - 2024-07-08 15:32:15 --> Config Class Initialized
INFO - 2024-07-08 15:32:15 --> Loader Class Initialized
INFO - 2024-07-08 15:32:15 --> Helper loaded: url_helper
INFO - 2024-07-08 15:32:15 --> Helper loaded: file_helper
INFO - 2024-07-08 15:32:15 --> Helper loaded: form_helper
INFO - 2024-07-08 15:32:15 --> Helper loaded: my_helper
INFO - 2024-07-08 15:32:15 --> Database Driver Class Initialized
INFO - 2024-07-08 15:32:15 --> Session: Class initialized using 'files' driver.
INFO - 2024-07-08 15:32:15 --> Controller Class Initialized
INFO - 2024-07-08 15:33:05 --> Config Class Initialized
INFO - 2024-07-08 15:33:05 --> Hooks Class Initialized
DEBUG - 2024-07-08 15:33:05 --> UTF-8 Support Enabled
INFO - 2024-07-08 15:33:05 --> Utf8 Class Initialized
INFO - 2024-07-08 15:33:05 --> URI Class Initialized
INFO - 2024-07-08 15:33:05 --> Router Class Initialized
INFO - 2024-07-08 15:33:05 --> Output Class Initialized
INFO - 2024-07-08 15:33:05 --> Security Class Initialized
DEBUG - 2024-07-08 15:33:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-07-08 15:33:05 --> Input Class Initialized
INFO - 2024-07-08 15:33:05 --> Language Class Initialized
INFO - 2024-07-08 15:33:05 --> Language Class Initialized
INFO - 2024-07-08 15:33:05 --> Config Class Initialized
INFO - 2024-07-08 15:33:05 --> Loader Class Initialized
INFO - 2024-07-08 15:33:05 --> Helper loaded: url_helper
INFO - 2024-07-08 15:33:05 --> Helper loaded: file_helper
INFO - 2024-07-08 15:33:05 --> Helper loaded: form_helper
INFO - 2024-07-08 15:33:05 --> Helper loaded: my_helper
INFO - 2024-07-08 15:33:05 --> Database Driver Class Initialized
INFO - 2024-07-08 15:33:05 --> Session: Class initialized using 'files' driver.
INFO - 2024-07-08 15:33:05 --> Controller Class Initialized
INFO - 2024-07-08 15:33:05 --> Final output sent to browser
DEBUG - 2024-07-08 15:33:05 --> Total execution time: 0.0464
INFO - 2024-07-08 15:33:05 --> Config Class Initialized
INFO - 2024-07-08 15:33:05 --> Hooks Class Initialized
DEBUG - 2024-07-08 15:33:05 --> UTF-8 Support Enabled
INFO - 2024-07-08 15:33:05 --> Utf8 Class Initialized
INFO - 2024-07-08 15:33:05 --> URI Class Initialized
INFO - 2024-07-08 15:33:05 --> Router Class Initialized
INFO - 2024-07-08 15:33:05 --> Output Class Initialized
INFO - 2024-07-08 15:33:05 --> Security Class Initialized
DEBUG - 2024-07-08 15:33:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-07-08 15:33:05 --> Input Class Initialized
INFO - 2024-07-08 15:33:05 --> Language Class Initialized
ERROR - 2024-07-08 15:33:05 --> 404 Page Not Found: /index
INFO - 2024-07-08 15:33:05 --> Config Class Initialized
INFO - 2024-07-08 15:33:05 --> Hooks Class Initialized
DEBUG - 2024-07-08 15:33:05 --> UTF-8 Support Enabled
INFO - 2024-07-08 15:33:05 --> Utf8 Class Initialized
INFO - 2024-07-08 15:33:05 --> URI Class Initialized
INFO - 2024-07-08 15:33:05 --> Router Class Initialized
INFO - 2024-07-08 15:33:05 --> Output Class Initialized
INFO - 2024-07-08 15:33:05 --> Security Class Initialized
DEBUG - 2024-07-08 15:33:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-07-08 15:33:05 --> Input Class Initialized
INFO - 2024-07-08 15:33:05 --> Language Class Initialized
INFO - 2024-07-08 15:33:05 --> Language Class Initialized
INFO - 2024-07-08 15:33:05 --> Config Class Initialized
INFO - 2024-07-08 15:33:05 --> Loader Class Initialized
INFO - 2024-07-08 15:33:05 --> Helper loaded: url_helper
INFO - 2024-07-08 15:33:05 --> Helper loaded: file_helper
INFO - 2024-07-08 15:33:05 --> Helper loaded: form_helper
INFO - 2024-07-08 15:33:05 --> Helper loaded: my_helper
INFO - 2024-07-08 15:33:05 --> Database Driver Class Initialized
INFO - 2024-07-08 15:33:05 --> Session: Class initialized using 'files' driver.
INFO - 2024-07-08 15:33:05 --> Controller Class Initialized
INFO - 2024-07-08 15:33:06 --> Config Class Initialized
INFO - 2024-07-08 15:33:06 --> Hooks Class Initialized
DEBUG - 2024-07-08 15:33:06 --> UTF-8 Support Enabled
INFO - 2024-07-08 15:33:06 --> Utf8 Class Initialized
INFO - 2024-07-08 15:33:06 --> URI Class Initialized
INFO - 2024-07-08 15:33:06 --> Router Class Initialized
INFO - 2024-07-08 15:33:06 --> Output Class Initialized
INFO - 2024-07-08 15:33:06 --> Security Class Initialized
DEBUG - 2024-07-08 15:33:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-07-08 15:33:06 --> Input Class Initialized
INFO - 2024-07-08 15:33:06 --> Language Class Initialized
INFO - 2024-07-08 15:33:06 --> Language Class Initialized
INFO - 2024-07-08 15:33:06 --> Config Class Initialized
INFO - 2024-07-08 15:33:06 --> Loader Class Initialized
INFO - 2024-07-08 15:33:06 --> Helper loaded: url_helper
INFO - 2024-07-08 15:33:06 --> Helper loaded: file_helper
INFO - 2024-07-08 15:33:06 --> Helper loaded: form_helper
INFO - 2024-07-08 15:33:06 --> Helper loaded: my_helper
INFO - 2024-07-08 15:33:06 --> Database Driver Class Initialized
INFO - 2024-07-08 15:33:06 --> Session: Class initialized using 'files' driver.
INFO - 2024-07-08 15:33:06 --> Controller Class Initialized
INFO - 2024-07-08 15:33:22 --> Config Class Initialized
INFO - 2024-07-08 15:33:22 --> Hooks Class Initialized
DEBUG - 2024-07-08 15:33:22 --> UTF-8 Support Enabled
INFO - 2024-07-08 15:33:22 --> Utf8 Class Initialized
INFO - 2024-07-08 15:33:22 --> URI Class Initialized
INFO - 2024-07-08 15:33:22 --> Router Class Initialized
INFO - 2024-07-08 15:33:22 --> Output Class Initialized
INFO - 2024-07-08 15:33:22 --> Security Class Initialized
DEBUG - 2024-07-08 15:33:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-07-08 15:33:22 --> Input Class Initialized
INFO - 2024-07-08 15:33:22 --> Language Class Initialized
INFO - 2024-07-08 15:33:22 --> Language Class Initialized
INFO - 2024-07-08 15:33:22 --> Config Class Initialized
INFO - 2024-07-08 15:33:22 --> Loader Class Initialized
INFO - 2024-07-08 15:33:22 --> Helper loaded: url_helper
INFO - 2024-07-08 15:33:22 --> Helper loaded: file_helper
INFO - 2024-07-08 15:33:22 --> Helper loaded: form_helper
INFO - 2024-07-08 15:33:22 --> Helper loaded: my_helper
INFO - 2024-07-08 15:33:22 --> Database Driver Class Initialized
INFO - 2024-07-08 15:33:22 --> Session: Class initialized using 'files' driver.
INFO - 2024-07-08 15:33:22 --> Controller Class Initialized
INFO - 2024-07-08 15:33:22 --> Final output sent to browser
DEBUG - 2024-07-08 15:33:22 --> Total execution time: 0.0346
INFO - 2024-07-08 15:33:22 --> Config Class Initialized
INFO - 2024-07-08 15:33:22 --> Hooks Class Initialized
DEBUG - 2024-07-08 15:33:22 --> UTF-8 Support Enabled
INFO - 2024-07-08 15:33:22 --> Utf8 Class Initialized
INFO - 2024-07-08 15:33:22 --> URI Class Initialized
INFO - 2024-07-08 15:33:22 --> Router Class Initialized
INFO - 2024-07-08 15:33:22 --> Output Class Initialized
INFO - 2024-07-08 15:33:22 --> Security Class Initialized
DEBUG - 2024-07-08 15:33:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-07-08 15:33:22 --> Input Class Initialized
INFO - 2024-07-08 15:33:22 --> Language Class Initialized
ERROR - 2024-07-08 15:33:22 --> 404 Page Not Found: /index
INFO - 2024-07-08 15:33:22 --> Config Class Initialized
INFO - 2024-07-08 15:33:22 --> Hooks Class Initialized
DEBUG - 2024-07-08 15:33:22 --> UTF-8 Support Enabled
INFO - 2024-07-08 15:33:22 --> Utf8 Class Initialized
INFO - 2024-07-08 15:33:22 --> URI Class Initialized
INFO - 2024-07-08 15:33:22 --> Router Class Initialized
INFO - 2024-07-08 15:33:22 --> Output Class Initialized
INFO - 2024-07-08 15:33:22 --> Security Class Initialized
DEBUG - 2024-07-08 15:33:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-07-08 15:33:22 --> Input Class Initialized
INFO - 2024-07-08 15:33:22 --> Language Class Initialized
INFO - 2024-07-08 15:33:22 --> Language Class Initialized
INFO - 2024-07-08 15:33:22 --> Config Class Initialized
INFO - 2024-07-08 15:33:22 --> Loader Class Initialized
INFO - 2024-07-08 15:33:22 --> Helper loaded: url_helper
INFO - 2024-07-08 15:33:22 --> Helper loaded: file_helper
INFO - 2024-07-08 15:33:22 --> Helper loaded: form_helper
INFO - 2024-07-08 15:33:22 --> Helper loaded: my_helper
INFO - 2024-07-08 15:33:22 --> Database Driver Class Initialized
INFO - 2024-07-08 15:33:22 --> Session: Class initialized using 'files' driver.
INFO - 2024-07-08 15:33:22 --> Controller Class Initialized
INFO - 2024-07-08 15:33:24 --> Config Class Initialized
INFO - 2024-07-08 15:33:24 --> Hooks Class Initialized
DEBUG - 2024-07-08 15:33:24 --> UTF-8 Support Enabled
INFO - 2024-07-08 15:33:24 --> Utf8 Class Initialized
INFO - 2024-07-08 15:33:24 --> URI Class Initialized
INFO - 2024-07-08 15:33:24 --> Router Class Initialized
INFO - 2024-07-08 15:33:24 --> Output Class Initialized
INFO - 2024-07-08 15:33:24 --> Security Class Initialized
DEBUG - 2024-07-08 15:33:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-07-08 15:33:24 --> Input Class Initialized
INFO - 2024-07-08 15:33:24 --> Language Class Initialized
INFO - 2024-07-08 15:33:24 --> Language Class Initialized
INFO - 2024-07-08 15:33:24 --> Config Class Initialized
INFO - 2024-07-08 15:33:24 --> Loader Class Initialized
INFO - 2024-07-08 15:33:24 --> Helper loaded: url_helper
INFO - 2024-07-08 15:33:24 --> Helper loaded: file_helper
INFO - 2024-07-08 15:33:24 --> Helper loaded: form_helper
INFO - 2024-07-08 15:33:24 --> Helper loaded: my_helper
INFO - 2024-07-08 15:33:24 --> Database Driver Class Initialized
INFO - 2024-07-08 15:33:24 --> Session: Class initialized using 'files' driver.
INFO - 2024-07-08 15:33:24 --> Controller Class Initialized
INFO - 2024-07-08 15:33:26 --> Config Class Initialized
INFO - 2024-07-08 15:33:26 --> Hooks Class Initialized
DEBUG - 2024-07-08 15:33:26 --> UTF-8 Support Enabled
INFO - 2024-07-08 15:33:26 --> Utf8 Class Initialized
INFO - 2024-07-08 15:33:26 --> URI Class Initialized
INFO - 2024-07-08 15:33:26 --> Router Class Initialized
INFO - 2024-07-08 15:33:26 --> Output Class Initialized
INFO - 2024-07-08 15:33:26 --> Security Class Initialized
DEBUG - 2024-07-08 15:33:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-07-08 15:33:26 --> Input Class Initialized
INFO - 2024-07-08 15:33:26 --> Language Class Initialized
INFO - 2024-07-08 15:33:26 --> Language Class Initialized
INFO - 2024-07-08 15:33:26 --> Config Class Initialized
INFO - 2024-07-08 15:33:26 --> Loader Class Initialized
INFO - 2024-07-08 15:33:26 --> Helper loaded: url_helper
INFO - 2024-07-08 15:33:26 --> Helper loaded: file_helper
INFO - 2024-07-08 15:33:26 --> Helper loaded: form_helper
INFO - 2024-07-08 15:33:26 --> Helper loaded: my_helper
INFO - 2024-07-08 15:33:26 --> Database Driver Class Initialized
INFO - 2024-07-08 15:33:26 --> Session: Class initialized using 'files' driver.
INFO - 2024-07-08 15:33:26 --> Controller Class Initialized
INFO - 2024-07-08 15:33:26 --> Final output sent to browser
DEBUG - 2024-07-08 15:33:26 --> Total execution time: 0.0421
INFO - 2024-07-08 15:33:27 --> Config Class Initialized
INFO - 2024-07-08 15:33:27 --> Hooks Class Initialized
DEBUG - 2024-07-08 15:33:27 --> UTF-8 Support Enabled
INFO - 2024-07-08 15:33:27 --> Utf8 Class Initialized
INFO - 2024-07-08 15:33:27 --> URI Class Initialized
INFO - 2024-07-08 15:33:27 --> Router Class Initialized
INFO - 2024-07-08 15:33:27 --> Output Class Initialized
INFO - 2024-07-08 15:33:27 --> Security Class Initialized
DEBUG - 2024-07-08 15:33:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-07-08 15:33:27 --> Input Class Initialized
INFO - 2024-07-08 15:33:27 --> Language Class Initialized
ERROR - 2024-07-08 15:33:27 --> 404 Page Not Found: /index
INFO - 2024-07-08 15:33:27 --> Config Class Initialized
INFO - 2024-07-08 15:33:27 --> Hooks Class Initialized
DEBUG - 2024-07-08 15:33:27 --> UTF-8 Support Enabled
INFO - 2024-07-08 15:33:27 --> Utf8 Class Initialized
INFO - 2024-07-08 15:33:27 --> URI Class Initialized
INFO - 2024-07-08 15:33:27 --> Router Class Initialized
INFO - 2024-07-08 15:33:27 --> Output Class Initialized
INFO - 2024-07-08 15:33:27 --> Security Class Initialized
DEBUG - 2024-07-08 15:33:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-07-08 15:33:27 --> Input Class Initialized
INFO - 2024-07-08 15:33:27 --> Language Class Initialized
INFO - 2024-07-08 15:33:27 --> Language Class Initialized
INFO - 2024-07-08 15:33:27 --> Config Class Initialized
INFO - 2024-07-08 15:33:27 --> Loader Class Initialized
INFO - 2024-07-08 15:33:27 --> Helper loaded: url_helper
INFO - 2024-07-08 15:33:27 --> Helper loaded: file_helper
INFO - 2024-07-08 15:33:27 --> Helper loaded: form_helper
INFO - 2024-07-08 15:33:27 --> Helper loaded: my_helper
INFO - 2024-07-08 15:33:27 --> Database Driver Class Initialized
INFO - 2024-07-08 15:33:27 --> Session: Class initialized using 'files' driver.
INFO - 2024-07-08 15:33:27 --> Controller Class Initialized
INFO - 2024-07-08 15:33:28 --> Config Class Initialized
INFO - 2024-07-08 15:33:28 --> Hooks Class Initialized
DEBUG - 2024-07-08 15:33:28 --> UTF-8 Support Enabled
INFO - 2024-07-08 15:33:28 --> Utf8 Class Initialized
INFO - 2024-07-08 15:33:28 --> URI Class Initialized
INFO - 2024-07-08 15:33:28 --> Router Class Initialized
INFO - 2024-07-08 15:33:28 --> Output Class Initialized
INFO - 2024-07-08 15:33:28 --> Security Class Initialized
DEBUG - 2024-07-08 15:33:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-07-08 15:33:28 --> Input Class Initialized
INFO - 2024-07-08 15:33:28 --> Language Class Initialized
INFO - 2024-07-08 15:33:28 --> Language Class Initialized
INFO - 2024-07-08 15:33:28 --> Config Class Initialized
INFO - 2024-07-08 15:33:28 --> Loader Class Initialized
INFO - 2024-07-08 15:33:28 --> Helper loaded: url_helper
INFO - 2024-07-08 15:33:28 --> Helper loaded: file_helper
INFO - 2024-07-08 15:33:28 --> Helper loaded: form_helper
INFO - 2024-07-08 15:33:28 --> Helper loaded: my_helper
INFO - 2024-07-08 15:33:28 --> Database Driver Class Initialized
INFO - 2024-07-08 15:33:28 --> Session: Class initialized using 'files' driver.
INFO - 2024-07-08 15:33:28 --> Controller Class Initialized
INFO - 2024-07-08 15:33:31 --> Config Class Initialized
INFO - 2024-07-08 15:33:31 --> Hooks Class Initialized
DEBUG - 2024-07-08 15:33:31 --> UTF-8 Support Enabled
INFO - 2024-07-08 15:33:31 --> Utf8 Class Initialized
INFO - 2024-07-08 15:33:31 --> URI Class Initialized
INFO - 2024-07-08 15:33:31 --> Router Class Initialized
INFO - 2024-07-08 15:33:31 --> Output Class Initialized
INFO - 2024-07-08 15:33:31 --> Security Class Initialized
DEBUG - 2024-07-08 15:33:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-07-08 15:33:31 --> Input Class Initialized
INFO - 2024-07-08 15:33:31 --> Language Class Initialized
INFO - 2024-07-08 15:33:31 --> Language Class Initialized
INFO - 2024-07-08 15:33:31 --> Config Class Initialized
INFO - 2024-07-08 15:33:31 --> Loader Class Initialized
INFO - 2024-07-08 15:33:31 --> Helper loaded: url_helper
INFO - 2024-07-08 15:33:31 --> Helper loaded: file_helper
INFO - 2024-07-08 15:33:31 --> Helper loaded: form_helper
INFO - 2024-07-08 15:33:31 --> Helper loaded: my_helper
INFO - 2024-07-08 15:33:31 --> Database Driver Class Initialized
INFO - 2024-07-08 15:33:31 --> Session: Class initialized using 'files' driver.
INFO - 2024-07-08 15:33:31 --> Controller Class Initialized
INFO - 2024-07-08 15:33:31 --> Final output sent to browser
DEBUG - 2024-07-08 15:33:31 --> Total execution time: 0.0913
INFO - 2024-07-08 15:33:31 --> Config Class Initialized
INFO - 2024-07-08 15:33:31 --> Hooks Class Initialized
DEBUG - 2024-07-08 15:33:31 --> UTF-8 Support Enabled
INFO - 2024-07-08 15:33:31 --> Utf8 Class Initialized
INFO - 2024-07-08 15:33:31 --> URI Class Initialized
INFO - 2024-07-08 15:33:31 --> Router Class Initialized
INFO - 2024-07-08 15:33:31 --> Output Class Initialized
INFO - 2024-07-08 15:33:31 --> Security Class Initialized
DEBUG - 2024-07-08 15:33:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-07-08 15:33:31 --> Input Class Initialized
INFO - 2024-07-08 15:33:31 --> Language Class Initialized
ERROR - 2024-07-08 15:33:31 --> 404 Page Not Found: /index
INFO - 2024-07-08 15:33:31 --> Config Class Initialized
INFO - 2024-07-08 15:33:31 --> Hooks Class Initialized
DEBUG - 2024-07-08 15:33:31 --> UTF-8 Support Enabled
INFO - 2024-07-08 15:33:31 --> Utf8 Class Initialized
INFO - 2024-07-08 15:33:31 --> URI Class Initialized
INFO - 2024-07-08 15:33:31 --> Router Class Initialized
INFO - 2024-07-08 15:33:31 --> Output Class Initialized
INFO - 2024-07-08 15:33:31 --> Security Class Initialized
DEBUG - 2024-07-08 15:33:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-07-08 15:33:31 --> Input Class Initialized
INFO - 2024-07-08 15:33:31 --> Language Class Initialized
INFO - 2024-07-08 15:33:31 --> Language Class Initialized
INFO - 2024-07-08 15:33:31 --> Config Class Initialized
INFO - 2024-07-08 15:33:31 --> Loader Class Initialized
INFO - 2024-07-08 15:33:31 --> Helper loaded: url_helper
INFO - 2024-07-08 15:33:31 --> Helper loaded: file_helper
INFO - 2024-07-08 15:33:31 --> Helper loaded: form_helper
INFO - 2024-07-08 15:33:31 --> Helper loaded: my_helper
INFO - 2024-07-08 15:33:31 --> Database Driver Class Initialized
INFO - 2024-07-08 15:33:31 --> Session: Class initialized using 'files' driver.
INFO - 2024-07-08 15:33:31 --> Controller Class Initialized
INFO - 2024-07-08 15:33:33 --> Config Class Initialized
INFO - 2024-07-08 15:33:33 --> Hooks Class Initialized
DEBUG - 2024-07-08 15:33:33 --> UTF-8 Support Enabled
INFO - 2024-07-08 15:33:33 --> Utf8 Class Initialized
INFO - 2024-07-08 15:33:33 --> URI Class Initialized
INFO - 2024-07-08 15:33:33 --> Router Class Initialized
INFO - 2024-07-08 15:33:33 --> Output Class Initialized
INFO - 2024-07-08 15:33:33 --> Security Class Initialized
DEBUG - 2024-07-08 15:33:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-07-08 15:33:33 --> Input Class Initialized
INFO - 2024-07-08 15:33:33 --> Language Class Initialized
INFO - 2024-07-08 15:33:33 --> Language Class Initialized
INFO - 2024-07-08 15:33:33 --> Config Class Initialized
INFO - 2024-07-08 15:33:33 --> Loader Class Initialized
INFO - 2024-07-08 15:33:33 --> Helper loaded: url_helper
INFO - 2024-07-08 15:33:33 --> Helper loaded: file_helper
INFO - 2024-07-08 15:33:33 --> Helper loaded: form_helper
INFO - 2024-07-08 15:33:33 --> Helper loaded: my_helper
INFO - 2024-07-08 15:33:33 --> Database Driver Class Initialized
INFO - 2024-07-08 15:33:33 --> Session: Class initialized using 'files' driver.
INFO - 2024-07-08 15:33:33 --> Controller Class Initialized
INFO - 2024-07-08 15:33:35 --> Config Class Initialized
INFO - 2024-07-08 15:33:35 --> Hooks Class Initialized
DEBUG - 2024-07-08 15:33:35 --> UTF-8 Support Enabled
INFO - 2024-07-08 15:33:35 --> Utf8 Class Initialized
INFO - 2024-07-08 15:33:35 --> URI Class Initialized
INFO - 2024-07-08 15:33:35 --> Router Class Initialized
INFO - 2024-07-08 15:33:35 --> Output Class Initialized
INFO - 2024-07-08 15:33:35 --> Security Class Initialized
DEBUG - 2024-07-08 15:33:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-07-08 15:33:35 --> Input Class Initialized
INFO - 2024-07-08 15:33:35 --> Language Class Initialized
INFO - 2024-07-08 15:33:35 --> Language Class Initialized
INFO - 2024-07-08 15:33:35 --> Config Class Initialized
INFO - 2024-07-08 15:33:35 --> Loader Class Initialized
INFO - 2024-07-08 15:33:35 --> Helper loaded: url_helper
INFO - 2024-07-08 15:33:35 --> Helper loaded: file_helper
INFO - 2024-07-08 15:33:35 --> Helper loaded: form_helper
INFO - 2024-07-08 15:33:36 --> Helper loaded: my_helper
INFO - 2024-07-08 15:33:36 --> Database Driver Class Initialized
INFO - 2024-07-08 15:33:36 --> Session: Class initialized using 'files' driver.
INFO - 2024-07-08 15:33:36 --> Controller Class Initialized
INFO - 2024-07-08 15:33:36 --> Final output sent to browser
DEBUG - 2024-07-08 15:33:36 --> Total execution time: 0.0358
INFO - 2024-07-08 15:33:36 --> Config Class Initialized
INFO - 2024-07-08 15:33:36 --> Hooks Class Initialized
DEBUG - 2024-07-08 15:33:36 --> UTF-8 Support Enabled
INFO - 2024-07-08 15:33:36 --> Utf8 Class Initialized
INFO - 2024-07-08 15:33:36 --> URI Class Initialized
INFO - 2024-07-08 15:33:36 --> Router Class Initialized
INFO - 2024-07-08 15:33:36 --> Output Class Initialized
INFO - 2024-07-08 15:33:36 --> Security Class Initialized
DEBUG - 2024-07-08 15:33:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-07-08 15:33:36 --> Input Class Initialized
INFO - 2024-07-08 15:33:36 --> Language Class Initialized
ERROR - 2024-07-08 15:33:36 --> 404 Page Not Found: /index
INFO - 2024-07-08 15:33:36 --> Config Class Initialized
INFO - 2024-07-08 15:33:36 --> Hooks Class Initialized
DEBUG - 2024-07-08 15:33:36 --> UTF-8 Support Enabled
INFO - 2024-07-08 15:33:36 --> Utf8 Class Initialized
INFO - 2024-07-08 15:33:36 --> URI Class Initialized
INFO - 2024-07-08 15:33:36 --> Router Class Initialized
INFO - 2024-07-08 15:33:36 --> Output Class Initialized
INFO - 2024-07-08 15:33:36 --> Security Class Initialized
DEBUG - 2024-07-08 15:33:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-07-08 15:33:36 --> Input Class Initialized
INFO - 2024-07-08 15:33:36 --> Language Class Initialized
INFO - 2024-07-08 15:33:36 --> Language Class Initialized
INFO - 2024-07-08 15:33:36 --> Config Class Initialized
INFO - 2024-07-08 15:33:36 --> Loader Class Initialized
INFO - 2024-07-08 15:33:36 --> Helper loaded: url_helper
INFO - 2024-07-08 15:33:36 --> Helper loaded: file_helper
INFO - 2024-07-08 15:33:36 --> Helper loaded: form_helper
INFO - 2024-07-08 15:33:36 --> Helper loaded: my_helper
INFO - 2024-07-08 15:33:36 --> Database Driver Class Initialized
INFO - 2024-07-08 15:33:36 --> Session: Class initialized using 'files' driver.
INFO - 2024-07-08 15:33:36 --> Controller Class Initialized
INFO - 2024-07-08 15:33:37 --> Config Class Initialized
INFO - 2024-07-08 15:33:37 --> Hooks Class Initialized
DEBUG - 2024-07-08 15:33:37 --> UTF-8 Support Enabled
INFO - 2024-07-08 15:33:37 --> Utf8 Class Initialized
INFO - 2024-07-08 15:33:37 --> URI Class Initialized
INFO - 2024-07-08 15:33:37 --> Router Class Initialized
INFO - 2024-07-08 15:33:37 --> Output Class Initialized
INFO - 2024-07-08 15:33:37 --> Security Class Initialized
DEBUG - 2024-07-08 15:33:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-07-08 15:33:37 --> Input Class Initialized
INFO - 2024-07-08 15:33:37 --> Language Class Initialized
INFO - 2024-07-08 15:33:37 --> Language Class Initialized
INFO - 2024-07-08 15:33:37 --> Config Class Initialized
INFO - 2024-07-08 15:33:37 --> Loader Class Initialized
INFO - 2024-07-08 15:33:37 --> Helper loaded: url_helper
INFO - 2024-07-08 15:33:37 --> Helper loaded: file_helper
INFO - 2024-07-08 15:33:37 --> Helper loaded: form_helper
INFO - 2024-07-08 15:33:37 --> Helper loaded: my_helper
INFO - 2024-07-08 15:33:37 --> Database Driver Class Initialized
INFO - 2024-07-08 15:33:37 --> Session: Class initialized using 'files' driver.
INFO - 2024-07-08 15:33:37 --> Controller Class Initialized
INFO - 2024-07-08 15:33:39 --> Config Class Initialized
INFO - 2024-07-08 15:33:39 --> Hooks Class Initialized
DEBUG - 2024-07-08 15:33:39 --> UTF-8 Support Enabled
INFO - 2024-07-08 15:33:39 --> Utf8 Class Initialized
INFO - 2024-07-08 15:33:39 --> URI Class Initialized
INFO - 2024-07-08 15:33:39 --> Router Class Initialized
INFO - 2024-07-08 15:33:39 --> Output Class Initialized
INFO - 2024-07-08 15:33:39 --> Security Class Initialized
DEBUG - 2024-07-08 15:33:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-07-08 15:33:39 --> Input Class Initialized
INFO - 2024-07-08 15:33:39 --> Language Class Initialized
INFO - 2024-07-08 15:33:39 --> Language Class Initialized
INFO - 2024-07-08 15:33:39 --> Config Class Initialized
INFO - 2024-07-08 15:33:39 --> Loader Class Initialized
INFO - 2024-07-08 15:33:39 --> Helper loaded: url_helper
INFO - 2024-07-08 15:33:39 --> Helper loaded: file_helper
INFO - 2024-07-08 15:33:39 --> Helper loaded: form_helper
INFO - 2024-07-08 15:33:39 --> Helper loaded: my_helper
INFO - 2024-07-08 15:33:40 --> Database Driver Class Initialized
INFO - 2024-07-08 15:33:40 --> Session: Class initialized using 'files' driver.
INFO - 2024-07-08 15:33:40 --> Controller Class Initialized
INFO - 2024-07-08 15:33:40 --> Final output sent to browser
DEBUG - 2024-07-08 15:33:40 --> Total execution time: 0.0497
INFO - 2024-07-08 15:33:40 --> Config Class Initialized
INFO - 2024-07-08 15:33:40 --> Hooks Class Initialized
DEBUG - 2024-07-08 15:33:40 --> UTF-8 Support Enabled
INFO - 2024-07-08 15:33:40 --> Utf8 Class Initialized
INFO - 2024-07-08 15:33:40 --> URI Class Initialized
INFO - 2024-07-08 15:33:40 --> Router Class Initialized
INFO - 2024-07-08 15:33:40 --> Output Class Initialized
INFO - 2024-07-08 15:33:40 --> Security Class Initialized
DEBUG - 2024-07-08 15:33:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-07-08 15:33:40 --> Input Class Initialized
INFO - 2024-07-08 15:33:40 --> Language Class Initialized
ERROR - 2024-07-08 15:33:40 --> 404 Page Not Found: /index
INFO - 2024-07-08 15:33:40 --> Config Class Initialized
INFO - 2024-07-08 15:33:40 --> Hooks Class Initialized
DEBUG - 2024-07-08 15:33:40 --> UTF-8 Support Enabled
INFO - 2024-07-08 15:33:40 --> Utf8 Class Initialized
INFO - 2024-07-08 15:33:40 --> URI Class Initialized
INFO - 2024-07-08 15:33:40 --> Router Class Initialized
INFO - 2024-07-08 15:33:40 --> Output Class Initialized
INFO - 2024-07-08 15:33:40 --> Security Class Initialized
DEBUG - 2024-07-08 15:33:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-07-08 15:33:40 --> Input Class Initialized
INFO - 2024-07-08 15:33:40 --> Language Class Initialized
INFO - 2024-07-08 15:33:40 --> Language Class Initialized
INFO - 2024-07-08 15:33:40 --> Config Class Initialized
INFO - 2024-07-08 15:33:40 --> Loader Class Initialized
INFO - 2024-07-08 15:33:40 --> Helper loaded: url_helper
INFO - 2024-07-08 15:33:40 --> Helper loaded: file_helper
INFO - 2024-07-08 15:33:40 --> Helper loaded: form_helper
INFO - 2024-07-08 15:33:40 --> Helper loaded: my_helper
INFO - 2024-07-08 15:33:40 --> Database Driver Class Initialized
INFO - 2024-07-08 15:33:40 --> Session: Class initialized using 'files' driver.
INFO - 2024-07-08 15:33:40 --> Controller Class Initialized
INFO - 2024-07-08 15:33:42 --> Config Class Initialized
INFO - 2024-07-08 15:33:42 --> Hooks Class Initialized
DEBUG - 2024-07-08 15:33:42 --> UTF-8 Support Enabled
INFO - 2024-07-08 15:33:42 --> Utf8 Class Initialized
INFO - 2024-07-08 15:33:42 --> URI Class Initialized
INFO - 2024-07-08 15:33:42 --> Router Class Initialized
INFO - 2024-07-08 15:33:42 --> Output Class Initialized
INFO - 2024-07-08 15:33:42 --> Security Class Initialized
DEBUG - 2024-07-08 15:33:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-07-08 15:33:42 --> Input Class Initialized
INFO - 2024-07-08 15:33:42 --> Language Class Initialized
INFO - 2024-07-08 15:33:42 --> Language Class Initialized
INFO - 2024-07-08 15:33:42 --> Config Class Initialized
INFO - 2024-07-08 15:33:42 --> Loader Class Initialized
INFO - 2024-07-08 15:33:42 --> Helper loaded: url_helper
INFO - 2024-07-08 15:33:42 --> Helper loaded: file_helper
INFO - 2024-07-08 15:33:42 --> Helper loaded: form_helper
INFO - 2024-07-08 15:33:42 --> Helper loaded: my_helper
INFO - 2024-07-08 15:33:42 --> Database Driver Class Initialized
INFO - 2024-07-08 15:33:42 --> Session: Class initialized using 'files' driver.
INFO - 2024-07-08 15:33:42 --> Controller Class Initialized
INFO - 2024-07-08 15:33:43 --> Config Class Initialized
INFO - 2024-07-08 15:33:43 --> Hooks Class Initialized
DEBUG - 2024-07-08 15:33:43 --> UTF-8 Support Enabled
INFO - 2024-07-08 15:33:43 --> Utf8 Class Initialized
INFO - 2024-07-08 15:33:43 --> URI Class Initialized
INFO - 2024-07-08 15:33:43 --> Router Class Initialized
INFO - 2024-07-08 15:33:43 --> Output Class Initialized
INFO - 2024-07-08 15:33:43 --> Security Class Initialized
DEBUG - 2024-07-08 15:33:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-07-08 15:33:43 --> Input Class Initialized
INFO - 2024-07-08 15:33:43 --> Language Class Initialized
INFO - 2024-07-08 15:33:43 --> Language Class Initialized
INFO - 2024-07-08 15:33:43 --> Config Class Initialized
INFO - 2024-07-08 15:33:43 --> Loader Class Initialized
INFO - 2024-07-08 15:33:43 --> Helper loaded: url_helper
INFO - 2024-07-08 15:33:43 --> Helper loaded: file_helper
INFO - 2024-07-08 15:33:43 --> Helper loaded: form_helper
INFO - 2024-07-08 15:33:43 --> Helper loaded: my_helper
INFO - 2024-07-08 15:33:43 --> Database Driver Class Initialized
INFO - 2024-07-08 15:33:43 --> Session: Class initialized using 'files' driver.
INFO - 2024-07-08 15:33:43 --> Controller Class Initialized
INFO - 2024-07-08 15:33:46 --> Config Class Initialized
INFO - 2024-07-08 15:33:46 --> Hooks Class Initialized
DEBUG - 2024-07-08 15:33:46 --> UTF-8 Support Enabled
INFO - 2024-07-08 15:33:46 --> Utf8 Class Initialized
INFO - 2024-07-08 15:33:46 --> URI Class Initialized
INFO - 2024-07-08 15:33:46 --> Router Class Initialized
INFO - 2024-07-08 15:33:46 --> Output Class Initialized
INFO - 2024-07-08 15:33:46 --> Security Class Initialized
DEBUG - 2024-07-08 15:33:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-07-08 15:33:46 --> Input Class Initialized
INFO - 2024-07-08 15:33:46 --> Language Class Initialized
INFO - 2024-07-08 15:33:46 --> Language Class Initialized
INFO - 2024-07-08 15:33:46 --> Config Class Initialized
INFO - 2024-07-08 15:33:46 --> Loader Class Initialized
INFO - 2024-07-08 15:33:46 --> Helper loaded: url_helper
INFO - 2024-07-08 15:33:46 --> Helper loaded: file_helper
INFO - 2024-07-08 15:33:46 --> Helper loaded: form_helper
INFO - 2024-07-08 15:33:46 --> Helper loaded: my_helper
INFO - 2024-07-08 15:33:46 --> Database Driver Class Initialized
INFO - 2024-07-08 15:33:46 --> Session: Class initialized using 'files' driver.
INFO - 2024-07-08 15:33:46 --> Controller Class Initialized
INFO - 2024-07-08 15:33:46 --> Final output sent to browser
DEBUG - 2024-07-08 15:33:46 --> Total execution time: 0.0330
INFO - 2024-07-08 15:33:46 --> Config Class Initialized
INFO - 2024-07-08 15:33:46 --> Hooks Class Initialized
DEBUG - 2024-07-08 15:33:46 --> UTF-8 Support Enabled
INFO - 2024-07-08 15:33:46 --> Utf8 Class Initialized
INFO - 2024-07-08 15:33:46 --> URI Class Initialized
INFO - 2024-07-08 15:33:46 --> Router Class Initialized
INFO - 2024-07-08 15:33:46 --> Output Class Initialized
INFO - 2024-07-08 15:33:46 --> Security Class Initialized
DEBUG - 2024-07-08 15:33:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-07-08 15:33:46 --> Input Class Initialized
INFO - 2024-07-08 15:33:46 --> Language Class Initialized
ERROR - 2024-07-08 15:33:46 --> 404 Page Not Found: /index
INFO - 2024-07-08 15:33:46 --> Config Class Initialized
INFO - 2024-07-08 15:33:46 --> Hooks Class Initialized
DEBUG - 2024-07-08 15:33:46 --> UTF-8 Support Enabled
INFO - 2024-07-08 15:33:46 --> Utf8 Class Initialized
INFO - 2024-07-08 15:33:46 --> URI Class Initialized
INFO - 2024-07-08 15:33:46 --> Router Class Initialized
INFO - 2024-07-08 15:33:46 --> Output Class Initialized
INFO - 2024-07-08 15:33:46 --> Security Class Initialized
DEBUG - 2024-07-08 15:33:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-07-08 15:33:46 --> Input Class Initialized
INFO - 2024-07-08 15:33:46 --> Language Class Initialized
INFO - 2024-07-08 15:33:46 --> Language Class Initialized
INFO - 2024-07-08 15:33:46 --> Config Class Initialized
INFO - 2024-07-08 15:33:46 --> Loader Class Initialized
INFO - 2024-07-08 15:33:46 --> Helper loaded: url_helper
INFO - 2024-07-08 15:33:46 --> Helper loaded: file_helper
INFO - 2024-07-08 15:33:46 --> Helper loaded: form_helper
INFO - 2024-07-08 15:33:46 --> Helper loaded: my_helper
INFO - 2024-07-08 15:33:46 --> Database Driver Class Initialized
INFO - 2024-07-08 15:33:46 --> Session: Class initialized using 'files' driver.
INFO - 2024-07-08 15:33:46 --> Controller Class Initialized
INFO - 2024-07-08 15:33:48 --> Config Class Initialized
INFO - 2024-07-08 15:33:48 --> Hooks Class Initialized
DEBUG - 2024-07-08 15:33:48 --> UTF-8 Support Enabled
INFO - 2024-07-08 15:33:48 --> Utf8 Class Initialized
INFO - 2024-07-08 15:33:48 --> URI Class Initialized
INFO - 2024-07-08 15:33:48 --> Router Class Initialized
INFO - 2024-07-08 15:33:48 --> Output Class Initialized
INFO - 2024-07-08 15:33:48 --> Security Class Initialized
DEBUG - 2024-07-08 15:33:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-07-08 15:33:48 --> Input Class Initialized
INFO - 2024-07-08 15:33:48 --> Language Class Initialized
INFO - 2024-07-08 15:33:48 --> Language Class Initialized
INFO - 2024-07-08 15:33:48 --> Config Class Initialized
INFO - 2024-07-08 15:33:48 --> Loader Class Initialized
INFO - 2024-07-08 15:33:48 --> Helper loaded: url_helper
INFO - 2024-07-08 15:33:48 --> Helper loaded: file_helper
INFO - 2024-07-08 15:33:48 --> Helper loaded: form_helper
INFO - 2024-07-08 15:33:48 --> Helper loaded: my_helper
INFO - 2024-07-08 15:33:48 --> Database Driver Class Initialized
INFO - 2024-07-08 15:33:48 --> Session: Class initialized using 'files' driver.
INFO - 2024-07-08 15:33:48 --> Controller Class Initialized
INFO - 2024-07-08 15:33:50 --> Config Class Initialized
INFO - 2024-07-08 15:33:50 --> Hooks Class Initialized
DEBUG - 2024-07-08 15:33:50 --> UTF-8 Support Enabled
INFO - 2024-07-08 15:33:50 --> Utf8 Class Initialized
INFO - 2024-07-08 15:33:50 --> URI Class Initialized
INFO - 2024-07-08 15:33:50 --> Router Class Initialized
INFO - 2024-07-08 15:33:50 --> Output Class Initialized
INFO - 2024-07-08 15:33:50 --> Security Class Initialized
DEBUG - 2024-07-08 15:33:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-07-08 15:33:50 --> Input Class Initialized
INFO - 2024-07-08 15:33:50 --> Language Class Initialized
INFO - 2024-07-08 15:33:50 --> Language Class Initialized
INFO - 2024-07-08 15:33:50 --> Config Class Initialized
INFO - 2024-07-08 15:33:50 --> Loader Class Initialized
INFO - 2024-07-08 15:33:50 --> Helper loaded: url_helper
INFO - 2024-07-08 15:33:50 --> Helper loaded: file_helper
INFO - 2024-07-08 15:33:50 --> Helper loaded: form_helper
INFO - 2024-07-08 15:33:50 --> Helper loaded: my_helper
INFO - 2024-07-08 15:33:50 --> Database Driver Class Initialized
INFO - 2024-07-08 15:33:50 --> Session: Class initialized using 'files' driver.
INFO - 2024-07-08 15:33:50 --> Controller Class Initialized
INFO - 2024-07-08 15:33:50 --> Final output sent to browser
DEBUG - 2024-07-08 15:33:50 --> Total execution time: 0.0296
INFO - 2024-07-08 15:33:50 --> Config Class Initialized
INFO - 2024-07-08 15:33:50 --> Hooks Class Initialized
DEBUG - 2024-07-08 15:33:50 --> UTF-8 Support Enabled
INFO - 2024-07-08 15:33:50 --> Utf8 Class Initialized
INFO - 2024-07-08 15:33:50 --> URI Class Initialized
INFO - 2024-07-08 15:33:50 --> Router Class Initialized
INFO - 2024-07-08 15:33:50 --> Output Class Initialized
INFO - 2024-07-08 15:33:50 --> Security Class Initialized
DEBUG - 2024-07-08 15:33:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-07-08 15:33:50 --> Input Class Initialized
INFO - 2024-07-08 15:33:50 --> Language Class Initialized
ERROR - 2024-07-08 15:33:50 --> 404 Page Not Found: /index
INFO - 2024-07-08 15:33:50 --> Config Class Initialized
INFO - 2024-07-08 15:33:50 --> Hooks Class Initialized
DEBUG - 2024-07-08 15:33:50 --> UTF-8 Support Enabled
INFO - 2024-07-08 15:33:50 --> Utf8 Class Initialized
INFO - 2024-07-08 15:33:50 --> URI Class Initialized
INFO - 2024-07-08 15:33:50 --> Router Class Initialized
INFO - 2024-07-08 15:33:50 --> Output Class Initialized
INFO - 2024-07-08 15:33:50 --> Security Class Initialized
DEBUG - 2024-07-08 15:33:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-07-08 15:33:50 --> Input Class Initialized
INFO - 2024-07-08 15:33:50 --> Language Class Initialized
INFO - 2024-07-08 15:33:50 --> Language Class Initialized
INFO - 2024-07-08 15:33:50 --> Config Class Initialized
INFO - 2024-07-08 15:33:50 --> Loader Class Initialized
INFO - 2024-07-08 15:33:50 --> Helper loaded: url_helper
INFO - 2024-07-08 15:33:50 --> Helper loaded: file_helper
INFO - 2024-07-08 15:33:50 --> Helper loaded: form_helper
INFO - 2024-07-08 15:33:50 --> Helper loaded: my_helper
INFO - 2024-07-08 15:33:50 --> Database Driver Class Initialized
INFO - 2024-07-08 15:33:50 --> Session: Class initialized using 'files' driver.
INFO - 2024-07-08 15:33:50 --> Controller Class Initialized
INFO - 2024-07-08 15:33:52 --> Config Class Initialized
INFO - 2024-07-08 15:33:52 --> Hooks Class Initialized
DEBUG - 2024-07-08 15:33:52 --> UTF-8 Support Enabled
INFO - 2024-07-08 15:33:52 --> Utf8 Class Initialized
INFO - 2024-07-08 15:33:52 --> URI Class Initialized
INFO - 2024-07-08 15:33:52 --> Router Class Initialized
INFO - 2024-07-08 15:33:52 --> Output Class Initialized
INFO - 2024-07-08 15:33:52 --> Security Class Initialized
DEBUG - 2024-07-08 15:33:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-07-08 15:33:52 --> Input Class Initialized
INFO - 2024-07-08 15:33:52 --> Language Class Initialized
INFO - 2024-07-08 15:33:52 --> Language Class Initialized
INFO - 2024-07-08 15:33:52 --> Config Class Initialized
INFO - 2024-07-08 15:33:52 --> Loader Class Initialized
INFO - 2024-07-08 15:33:52 --> Helper loaded: url_helper
INFO - 2024-07-08 15:33:52 --> Helper loaded: file_helper
INFO - 2024-07-08 15:33:52 --> Helper loaded: form_helper
INFO - 2024-07-08 15:33:52 --> Helper loaded: my_helper
INFO - 2024-07-08 15:33:52 --> Database Driver Class Initialized
INFO - 2024-07-08 15:33:52 --> Session: Class initialized using 'files' driver.
INFO - 2024-07-08 15:33:52 --> Controller Class Initialized
INFO - 2024-07-08 15:33:54 --> Config Class Initialized
INFO - 2024-07-08 15:33:54 --> Hooks Class Initialized
DEBUG - 2024-07-08 15:33:54 --> UTF-8 Support Enabled
INFO - 2024-07-08 15:33:54 --> Utf8 Class Initialized
INFO - 2024-07-08 15:33:54 --> URI Class Initialized
INFO - 2024-07-08 15:33:54 --> Router Class Initialized
INFO - 2024-07-08 15:33:54 --> Output Class Initialized
INFO - 2024-07-08 15:33:54 --> Security Class Initialized
DEBUG - 2024-07-08 15:33:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-07-08 15:33:54 --> Input Class Initialized
INFO - 2024-07-08 15:33:54 --> Language Class Initialized
INFO - 2024-07-08 15:33:54 --> Language Class Initialized
INFO - 2024-07-08 15:33:54 --> Config Class Initialized
INFO - 2024-07-08 15:33:54 --> Loader Class Initialized
INFO - 2024-07-08 15:33:54 --> Helper loaded: url_helper
INFO - 2024-07-08 15:33:54 --> Helper loaded: file_helper
INFO - 2024-07-08 15:33:54 --> Helper loaded: form_helper
INFO - 2024-07-08 15:33:54 --> Helper loaded: my_helper
INFO - 2024-07-08 15:33:54 --> Database Driver Class Initialized
INFO - 2024-07-08 15:33:54 --> Session: Class initialized using 'files' driver.
INFO - 2024-07-08 15:33:54 --> Controller Class Initialized
INFO - 2024-07-08 15:33:54 --> Final output sent to browser
DEBUG - 2024-07-08 15:33:54 --> Total execution time: 0.0361
INFO - 2024-07-08 15:33:54 --> Config Class Initialized
INFO - 2024-07-08 15:33:54 --> Hooks Class Initialized
DEBUG - 2024-07-08 15:33:54 --> UTF-8 Support Enabled
INFO - 2024-07-08 15:33:54 --> Utf8 Class Initialized
INFO - 2024-07-08 15:33:54 --> URI Class Initialized
INFO - 2024-07-08 15:33:54 --> Router Class Initialized
INFO - 2024-07-08 15:33:54 --> Output Class Initialized
INFO - 2024-07-08 15:33:54 --> Security Class Initialized
DEBUG - 2024-07-08 15:33:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-07-08 15:33:54 --> Input Class Initialized
INFO - 2024-07-08 15:33:54 --> Language Class Initialized
ERROR - 2024-07-08 15:33:54 --> 404 Page Not Found: /index
INFO - 2024-07-08 15:33:54 --> Config Class Initialized
INFO - 2024-07-08 15:33:54 --> Hooks Class Initialized
DEBUG - 2024-07-08 15:33:54 --> UTF-8 Support Enabled
INFO - 2024-07-08 15:33:54 --> Utf8 Class Initialized
INFO - 2024-07-08 15:33:54 --> URI Class Initialized
INFO - 2024-07-08 15:33:54 --> Router Class Initialized
INFO - 2024-07-08 15:33:54 --> Output Class Initialized
INFO - 2024-07-08 15:33:54 --> Security Class Initialized
DEBUG - 2024-07-08 15:33:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-07-08 15:33:54 --> Input Class Initialized
INFO - 2024-07-08 15:33:54 --> Language Class Initialized
INFO - 2024-07-08 15:33:54 --> Language Class Initialized
INFO - 2024-07-08 15:33:54 --> Config Class Initialized
INFO - 2024-07-08 15:33:54 --> Loader Class Initialized
INFO - 2024-07-08 15:33:54 --> Helper loaded: url_helper
INFO - 2024-07-08 15:33:54 --> Helper loaded: file_helper
INFO - 2024-07-08 15:33:54 --> Helper loaded: form_helper
INFO - 2024-07-08 15:33:54 --> Helper loaded: my_helper
INFO - 2024-07-08 15:33:54 --> Database Driver Class Initialized
INFO - 2024-07-08 15:33:54 --> Session: Class initialized using 'files' driver.
INFO - 2024-07-08 15:33:54 --> Controller Class Initialized
INFO - 2024-07-08 15:33:56 --> Config Class Initialized
INFO - 2024-07-08 15:33:56 --> Hooks Class Initialized
DEBUG - 2024-07-08 15:33:56 --> UTF-8 Support Enabled
INFO - 2024-07-08 15:33:56 --> Utf8 Class Initialized
INFO - 2024-07-08 15:33:56 --> URI Class Initialized
INFO - 2024-07-08 15:33:56 --> Router Class Initialized
INFO - 2024-07-08 15:33:56 --> Output Class Initialized
INFO - 2024-07-08 15:33:56 --> Security Class Initialized
DEBUG - 2024-07-08 15:33:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-07-08 15:33:56 --> Input Class Initialized
INFO - 2024-07-08 15:33:56 --> Language Class Initialized
INFO - 2024-07-08 15:33:56 --> Language Class Initialized
INFO - 2024-07-08 15:33:56 --> Config Class Initialized
INFO - 2024-07-08 15:33:56 --> Loader Class Initialized
INFO - 2024-07-08 15:33:56 --> Helper loaded: url_helper
INFO - 2024-07-08 15:33:56 --> Helper loaded: file_helper
INFO - 2024-07-08 15:33:56 --> Helper loaded: form_helper
INFO - 2024-07-08 15:33:56 --> Helper loaded: my_helper
INFO - 2024-07-08 15:33:56 --> Database Driver Class Initialized
INFO - 2024-07-08 15:33:56 --> Session: Class initialized using 'files' driver.
INFO - 2024-07-08 15:33:56 --> Controller Class Initialized
INFO - 2024-07-08 15:33:59 --> Config Class Initialized
INFO - 2024-07-08 15:33:59 --> Hooks Class Initialized
DEBUG - 2024-07-08 15:33:59 --> UTF-8 Support Enabled
INFO - 2024-07-08 15:33:59 --> Utf8 Class Initialized
INFO - 2024-07-08 15:33:59 --> URI Class Initialized
INFO - 2024-07-08 15:33:59 --> Router Class Initialized
INFO - 2024-07-08 15:33:59 --> Output Class Initialized
INFO - 2024-07-08 15:33:59 --> Security Class Initialized
DEBUG - 2024-07-08 15:33:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-07-08 15:33:59 --> Input Class Initialized
INFO - 2024-07-08 15:33:59 --> Language Class Initialized
INFO - 2024-07-08 15:33:59 --> Language Class Initialized
INFO - 2024-07-08 15:33:59 --> Config Class Initialized
INFO - 2024-07-08 15:33:59 --> Loader Class Initialized
INFO - 2024-07-08 15:33:59 --> Helper loaded: url_helper
INFO - 2024-07-08 15:33:59 --> Helper loaded: file_helper
INFO - 2024-07-08 15:33:59 --> Helper loaded: form_helper
INFO - 2024-07-08 15:33:59 --> Helper loaded: my_helper
INFO - 2024-07-08 15:33:59 --> Database Driver Class Initialized
INFO - 2024-07-08 15:33:59 --> Session: Class initialized using 'files' driver.
INFO - 2024-07-08 15:33:59 --> Controller Class Initialized
INFO - 2024-07-08 15:33:59 --> Final output sent to browser
DEBUG - 2024-07-08 15:33:59 --> Total execution time: 0.0322
INFO - 2024-07-08 15:33:59 --> Config Class Initialized
INFO - 2024-07-08 15:33:59 --> Hooks Class Initialized
DEBUG - 2024-07-08 15:33:59 --> UTF-8 Support Enabled
INFO - 2024-07-08 15:33:59 --> Utf8 Class Initialized
INFO - 2024-07-08 15:33:59 --> URI Class Initialized
INFO - 2024-07-08 15:33:59 --> Router Class Initialized
INFO - 2024-07-08 15:33:59 --> Output Class Initialized
INFO - 2024-07-08 15:33:59 --> Security Class Initialized
DEBUG - 2024-07-08 15:33:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-07-08 15:33:59 --> Input Class Initialized
INFO - 2024-07-08 15:33:59 --> Language Class Initialized
ERROR - 2024-07-08 15:33:59 --> 404 Page Not Found: /index
INFO - 2024-07-08 15:33:59 --> Config Class Initialized
INFO - 2024-07-08 15:33:59 --> Hooks Class Initialized
DEBUG - 2024-07-08 15:33:59 --> UTF-8 Support Enabled
INFO - 2024-07-08 15:33:59 --> Utf8 Class Initialized
INFO - 2024-07-08 15:33:59 --> URI Class Initialized
INFO - 2024-07-08 15:33:59 --> Router Class Initialized
INFO - 2024-07-08 15:33:59 --> Output Class Initialized
INFO - 2024-07-08 15:33:59 --> Security Class Initialized
DEBUG - 2024-07-08 15:33:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-07-08 15:33:59 --> Input Class Initialized
INFO - 2024-07-08 15:33:59 --> Language Class Initialized
INFO - 2024-07-08 15:33:59 --> Language Class Initialized
INFO - 2024-07-08 15:33:59 --> Config Class Initialized
INFO - 2024-07-08 15:33:59 --> Loader Class Initialized
INFO - 2024-07-08 15:33:59 --> Helper loaded: url_helper
INFO - 2024-07-08 15:33:59 --> Helper loaded: file_helper
INFO - 2024-07-08 15:33:59 --> Helper loaded: form_helper
INFO - 2024-07-08 15:33:59 --> Helper loaded: my_helper
INFO - 2024-07-08 15:33:59 --> Database Driver Class Initialized
INFO - 2024-07-08 15:33:59 --> Session: Class initialized using 'files' driver.
INFO - 2024-07-08 15:33:59 --> Controller Class Initialized
INFO - 2024-07-08 15:34:03 --> Config Class Initialized
INFO - 2024-07-08 15:34:03 --> Hooks Class Initialized
DEBUG - 2024-07-08 15:34:03 --> UTF-8 Support Enabled
INFO - 2024-07-08 15:34:03 --> Utf8 Class Initialized
INFO - 2024-07-08 15:34:03 --> URI Class Initialized
INFO - 2024-07-08 15:34:03 --> Router Class Initialized
INFO - 2024-07-08 15:34:03 --> Output Class Initialized
INFO - 2024-07-08 15:34:03 --> Security Class Initialized
DEBUG - 2024-07-08 15:34:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-07-08 15:34:03 --> Input Class Initialized
INFO - 2024-07-08 15:34:03 --> Language Class Initialized
INFO - 2024-07-08 15:34:03 --> Language Class Initialized
INFO - 2024-07-08 15:34:03 --> Config Class Initialized
INFO - 2024-07-08 15:34:03 --> Loader Class Initialized
INFO - 2024-07-08 15:34:03 --> Helper loaded: url_helper
INFO - 2024-07-08 15:34:03 --> Helper loaded: file_helper
INFO - 2024-07-08 15:34:03 --> Helper loaded: form_helper
INFO - 2024-07-08 15:34:03 --> Helper loaded: my_helper
INFO - 2024-07-08 15:34:03 --> Database Driver Class Initialized
INFO - 2024-07-08 15:34:03 --> Session: Class initialized using 'files' driver.
INFO - 2024-07-08 15:34:03 --> Controller Class Initialized
INFO - 2024-07-08 15:34:05 --> Config Class Initialized
INFO - 2024-07-08 15:34:05 --> Hooks Class Initialized
DEBUG - 2024-07-08 15:34:05 --> UTF-8 Support Enabled
INFO - 2024-07-08 15:34:05 --> Utf8 Class Initialized
INFO - 2024-07-08 15:34:05 --> URI Class Initialized
INFO - 2024-07-08 15:34:05 --> Router Class Initialized
INFO - 2024-07-08 15:34:05 --> Output Class Initialized
INFO - 2024-07-08 15:34:05 --> Security Class Initialized
DEBUG - 2024-07-08 15:34:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-07-08 15:34:05 --> Input Class Initialized
INFO - 2024-07-08 15:34:05 --> Language Class Initialized
INFO - 2024-07-08 15:34:05 --> Language Class Initialized
INFO - 2024-07-08 15:34:05 --> Config Class Initialized
INFO - 2024-07-08 15:34:05 --> Loader Class Initialized
INFO - 2024-07-08 15:34:05 --> Helper loaded: url_helper
INFO - 2024-07-08 15:34:05 --> Helper loaded: file_helper
INFO - 2024-07-08 15:34:05 --> Helper loaded: form_helper
INFO - 2024-07-08 15:34:05 --> Helper loaded: my_helper
INFO - 2024-07-08 15:34:05 --> Database Driver Class Initialized
INFO - 2024-07-08 15:34:05 --> Session: Class initialized using 'files' driver.
INFO - 2024-07-08 15:34:05 --> Controller Class Initialized
INFO - 2024-07-08 15:34:05 --> Final output sent to browser
DEBUG - 2024-07-08 15:34:05 --> Total execution time: 0.0395
INFO - 2024-07-08 15:34:05 --> Config Class Initialized
INFO - 2024-07-08 15:34:05 --> Hooks Class Initialized
DEBUG - 2024-07-08 15:34:05 --> UTF-8 Support Enabled
INFO - 2024-07-08 15:34:05 --> Utf8 Class Initialized
INFO - 2024-07-08 15:34:05 --> URI Class Initialized
INFO - 2024-07-08 15:34:05 --> Router Class Initialized
INFO - 2024-07-08 15:34:05 --> Output Class Initialized
INFO - 2024-07-08 15:34:05 --> Security Class Initialized
DEBUG - 2024-07-08 15:34:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-07-08 15:34:05 --> Input Class Initialized
INFO - 2024-07-08 15:34:05 --> Language Class Initialized
ERROR - 2024-07-08 15:34:05 --> 404 Page Not Found: /index
INFO - 2024-07-08 15:34:05 --> Config Class Initialized
INFO - 2024-07-08 15:34:05 --> Hooks Class Initialized
DEBUG - 2024-07-08 15:34:05 --> UTF-8 Support Enabled
INFO - 2024-07-08 15:34:05 --> Utf8 Class Initialized
INFO - 2024-07-08 15:34:05 --> URI Class Initialized
INFO - 2024-07-08 15:34:05 --> Router Class Initialized
INFO - 2024-07-08 15:34:05 --> Output Class Initialized
INFO - 2024-07-08 15:34:05 --> Security Class Initialized
DEBUG - 2024-07-08 15:34:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-07-08 15:34:05 --> Input Class Initialized
INFO - 2024-07-08 15:34:05 --> Language Class Initialized
INFO - 2024-07-08 15:34:05 --> Language Class Initialized
INFO - 2024-07-08 15:34:05 --> Config Class Initialized
INFO - 2024-07-08 15:34:05 --> Loader Class Initialized
INFO - 2024-07-08 15:34:05 --> Helper loaded: url_helper
INFO - 2024-07-08 15:34:05 --> Helper loaded: file_helper
INFO - 2024-07-08 15:34:05 --> Helper loaded: form_helper
INFO - 2024-07-08 15:34:05 --> Helper loaded: my_helper
INFO - 2024-07-08 15:34:05 --> Database Driver Class Initialized
INFO - 2024-07-08 15:34:05 --> Session: Class initialized using 'files' driver.
INFO - 2024-07-08 15:34:05 --> Controller Class Initialized
INFO - 2024-07-08 15:34:10 --> Config Class Initialized
INFO - 2024-07-08 15:34:10 --> Hooks Class Initialized
DEBUG - 2024-07-08 15:34:10 --> UTF-8 Support Enabled
INFO - 2024-07-08 15:34:10 --> Utf8 Class Initialized
INFO - 2024-07-08 15:34:10 --> URI Class Initialized
INFO - 2024-07-08 15:34:10 --> Router Class Initialized
INFO - 2024-07-08 15:34:10 --> Output Class Initialized
INFO - 2024-07-08 15:34:10 --> Security Class Initialized
DEBUG - 2024-07-08 15:34:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-07-08 15:34:10 --> Input Class Initialized
INFO - 2024-07-08 15:34:10 --> Language Class Initialized
INFO - 2024-07-08 15:34:10 --> Language Class Initialized
INFO - 2024-07-08 15:34:10 --> Config Class Initialized
INFO - 2024-07-08 15:34:10 --> Loader Class Initialized
INFO - 2024-07-08 15:34:10 --> Helper loaded: url_helper
INFO - 2024-07-08 15:34:10 --> Helper loaded: file_helper
INFO - 2024-07-08 15:34:10 --> Helper loaded: form_helper
INFO - 2024-07-08 15:34:10 --> Helper loaded: my_helper
INFO - 2024-07-08 15:34:10 --> Database Driver Class Initialized
INFO - 2024-07-08 15:34:10 --> Session: Class initialized using 'files' driver.
INFO - 2024-07-08 15:34:10 --> Controller Class Initialized
INFO - 2024-07-08 15:34:13 --> Config Class Initialized
INFO - 2024-07-08 15:34:13 --> Hooks Class Initialized
DEBUG - 2024-07-08 15:34:13 --> UTF-8 Support Enabled
INFO - 2024-07-08 15:34:13 --> Utf8 Class Initialized
INFO - 2024-07-08 15:34:13 --> URI Class Initialized
INFO - 2024-07-08 15:34:13 --> Router Class Initialized
INFO - 2024-07-08 15:34:13 --> Output Class Initialized
INFO - 2024-07-08 15:34:13 --> Security Class Initialized
DEBUG - 2024-07-08 15:34:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-07-08 15:34:13 --> Input Class Initialized
INFO - 2024-07-08 15:34:13 --> Language Class Initialized
INFO - 2024-07-08 15:34:13 --> Language Class Initialized
INFO - 2024-07-08 15:34:13 --> Config Class Initialized
INFO - 2024-07-08 15:34:13 --> Loader Class Initialized
INFO - 2024-07-08 15:34:13 --> Helper loaded: url_helper
INFO - 2024-07-08 15:34:13 --> Helper loaded: file_helper
INFO - 2024-07-08 15:34:13 --> Helper loaded: form_helper
INFO - 2024-07-08 15:34:13 --> Helper loaded: my_helper
INFO - 2024-07-08 15:34:13 --> Database Driver Class Initialized
INFO - 2024-07-08 15:34:13 --> Session: Class initialized using 'files' driver.
INFO - 2024-07-08 15:34:13 --> Controller Class Initialized
INFO - 2024-07-08 15:34:13 --> Final output sent to browser
DEBUG - 2024-07-08 15:34:13 --> Total execution time: 0.0449
INFO - 2024-07-08 15:34:13 --> Config Class Initialized
INFO - 2024-07-08 15:34:13 --> Hooks Class Initialized
DEBUG - 2024-07-08 15:34:13 --> UTF-8 Support Enabled
INFO - 2024-07-08 15:34:13 --> Utf8 Class Initialized
INFO - 2024-07-08 15:34:13 --> URI Class Initialized
INFO - 2024-07-08 15:34:13 --> Router Class Initialized
INFO - 2024-07-08 15:34:13 --> Output Class Initialized
INFO - 2024-07-08 15:34:13 --> Security Class Initialized
DEBUG - 2024-07-08 15:34:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-07-08 15:34:13 --> Input Class Initialized
INFO - 2024-07-08 15:34:13 --> Language Class Initialized
ERROR - 2024-07-08 15:34:13 --> 404 Page Not Found: /index
INFO - 2024-07-08 15:34:13 --> Config Class Initialized
INFO - 2024-07-08 15:34:13 --> Hooks Class Initialized
DEBUG - 2024-07-08 15:34:13 --> UTF-8 Support Enabled
INFO - 2024-07-08 15:34:13 --> Utf8 Class Initialized
INFO - 2024-07-08 15:34:13 --> URI Class Initialized
INFO - 2024-07-08 15:34:13 --> Router Class Initialized
INFO - 2024-07-08 15:34:13 --> Output Class Initialized
INFO - 2024-07-08 15:34:13 --> Security Class Initialized
DEBUG - 2024-07-08 15:34:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-07-08 15:34:13 --> Input Class Initialized
INFO - 2024-07-08 15:34:13 --> Language Class Initialized
INFO - 2024-07-08 15:34:13 --> Language Class Initialized
INFO - 2024-07-08 15:34:13 --> Config Class Initialized
INFO - 2024-07-08 15:34:13 --> Loader Class Initialized
INFO - 2024-07-08 15:34:13 --> Helper loaded: url_helper
INFO - 2024-07-08 15:34:13 --> Helper loaded: file_helper
INFO - 2024-07-08 15:34:13 --> Helper loaded: form_helper
INFO - 2024-07-08 15:34:13 --> Helper loaded: my_helper
INFO - 2024-07-08 15:34:13 --> Database Driver Class Initialized
INFO - 2024-07-08 15:34:13 --> Session: Class initialized using 'files' driver.
INFO - 2024-07-08 15:34:13 --> Controller Class Initialized
INFO - 2024-07-08 15:34:15 --> Config Class Initialized
INFO - 2024-07-08 15:34:15 --> Hooks Class Initialized
DEBUG - 2024-07-08 15:34:15 --> UTF-8 Support Enabled
INFO - 2024-07-08 15:34:15 --> Utf8 Class Initialized
INFO - 2024-07-08 15:34:15 --> URI Class Initialized
INFO - 2024-07-08 15:34:15 --> Router Class Initialized
INFO - 2024-07-08 15:34:15 --> Output Class Initialized
INFO - 2024-07-08 15:34:15 --> Security Class Initialized
DEBUG - 2024-07-08 15:34:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-07-08 15:34:15 --> Input Class Initialized
INFO - 2024-07-08 15:34:15 --> Language Class Initialized
INFO - 2024-07-08 15:34:15 --> Language Class Initialized
INFO - 2024-07-08 15:34:15 --> Config Class Initialized
INFO - 2024-07-08 15:34:15 --> Loader Class Initialized
INFO - 2024-07-08 15:34:15 --> Helper loaded: url_helper
INFO - 2024-07-08 15:34:15 --> Helper loaded: file_helper
INFO - 2024-07-08 15:34:15 --> Helper loaded: form_helper
INFO - 2024-07-08 15:34:15 --> Helper loaded: my_helper
INFO - 2024-07-08 15:34:15 --> Database Driver Class Initialized
INFO - 2024-07-08 15:34:15 --> Session: Class initialized using 'files' driver.
INFO - 2024-07-08 15:34:15 --> Controller Class Initialized
INFO - 2024-07-08 15:34:18 --> Config Class Initialized
INFO - 2024-07-08 15:34:18 --> Hooks Class Initialized
DEBUG - 2024-07-08 15:34:18 --> UTF-8 Support Enabled
INFO - 2024-07-08 15:34:18 --> Utf8 Class Initialized
INFO - 2024-07-08 15:34:18 --> URI Class Initialized
INFO - 2024-07-08 15:34:18 --> Router Class Initialized
INFO - 2024-07-08 15:34:18 --> Output Class Initialized
INFO - 2024-07-08 15:34:18 --> Security Class Initialized
DEBUG - 2024-07-08 15:34:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-07-08 15:34:18 --> Input Class Initialized
INFO - 2024-07-08 15:34:18 --> Language Class Initialized
INFO - 2024-07-08 15:34:18 --> Language Class Initialized
INFO - 2024-07-08 15:34:18 --> Config Class Initialized
INFO - 2024-07-08 15:34:18 --> Loader Class Initialized
INFO - 2024-07-08 15:34:18 --> Helper loaded: url_helper
INFO - 2024-07-08 15:34:18 --> Helper loaded: file_helper
INFO - 2024-07-08 15:34:18 --> Helper loaded: form_helper
INFO - 2024-07-08 15:34:18 --> Helper loaded: my_helper
INFO - 2024-07-08 15:34:18 --> Database Driver Class Initialized
INFO - 2024-07-08 15:34:18 --> Session: Class initialized using 'files' driver.
INFO - 2024-07-08 15:34:18 --> Controller Class Initialized
INFO - 2024-07-08 15:34:18 --> Final output sent to browser
DEBUG - 2024-07-08 15:34:18 --> Total execution time: 0.0418
INFO - 2024-07-08 15:34:18 --> Config Class Initialized
INFO - 2024-07-08 15:34:18 --> Hooks Class Initialized
DEBUG - 2024-07-08 15:34:18 --> UTF-8 Support Enabled
INFO - 2024-07-08 15:34:18 --> Utf8 Class Initialized
INFO - 2024-07-08 15:34:18 --> URI Class Initialized
INFO - 2024-07-08 15:34:18 --> Router Class Initialized
INFO - 2024-07-08 15:34:18 --> Output Class Initialized
INFO - 2024-07-08 15:34:18 --> Security Class Initialized
DEBUG - 2024-07-08 15:34:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-07-08 15:34:18 --> Input Class Initialized
INFO - 2024-07-08 15:34:18 --> Language Class Initialized
ERROR - 2024-07-08 15:34:18 --> 404 Page Not Found: /index
INFO - 2024-07-08 15:34:18 --> Config Class Initialized
INFO - 2024-07-08 15:34:18 --> Hooks Class Initialized
DEBUG - 2024-07-08 15:34:18 --> UTF-8 Support Enabled
INFO - 2024-07-08 15:34:18 --> Utf8 Class Initialized
INFO - 2024-07-08 15:34:18 --> URI Class Initialized
INFO - 2024-07-08 15:34:18 --> Router Class Initialized
INFO - 2024-07-08 15:34:18 --> Output Class Initialized
INFO - 2024-07-08 15:34:18 --> Security Class Initialized
DEBUG - 2024-07-08 15:34:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-07-08 15:34:18 --> Input Class Initialized
INFO - 2024-07-08 15:34:18 --> Language Class Initialized
INFO - 2024-07-08 15:34:18 --> Language Class Initialized
INFO - 2024-07-08 15:34:18 --> Config Class Initialized
INFO - 2024-07-08 15:34:18 --> Loader Class Initialized
INFO - 2024-07-08 15:34:18 --> Helper loaded: url_helper
INFO - 2024-07-08 15:34:18 --> Helper loaded: file_helper
INFO - 2024-07-08 15:34:18 --> Helper loaded: form_helper
INFO - 2024-07-08 15:34:18 --> Helper loaded: my_helper
INFO - 2024-07-08 15:34:18 --> Database Driver Class Initialized
INFO - 2024-07-08 15:34:18 --> Session: Class initialized using 'files' driver.
INFO - 2024-07-08 15:34:18 --> Controller Class Initialized
INFO - 2024-07-08 15:34:20 --> Config Class Initialized
INFO - 2024-07-08 15:34:20 --> Hooks Class Initialized
DEBUG - 2024-07-08 15:34:20 --> UTF-8 Support Enabled
INFO - 2024-07-08 15:34:20 --> Utf8 Class Initialized
INFO - 2024-07-08 15:34:20 --> URI Class Initialized
INFO - 2024-07-08 15:34:20 --> Router Class Initialized
INFO - 2024-07-08 15:34:20 --> Output Class Initialized
INFO - 2024-07-08 15:34:20 --> Security Class Initialized
DEBUG - 2024-07-08 15:34:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-07-08 15:34:20 --> Input Class Initialized
INFO - 2024-07-08 15:34:20 --> Language Class Initialized
INFO - 2024-07-08 15:34:20 --> Language Class Initialized
INFO - 2024-07-08 15:34:20 --> Config Class Initialized
INFO - 2024-07-08 15:34:20 --> Loader Class Initialized
INFO - 2024-07-08 15:34:20 --> Helper loaded: url_helper
INFO - 2024-07-08 15:34:20 --> Helper loaded: file_helper
INFO - 2024-07-08 15:34:20 --> Helper loaded: form_helper
INFO - 2024-07-08 15:34:20 --> Helper loaded: my_helper
INFO - 2024-07-08 15:34:20 --> Database Driver Class Initialized
INFO - 2024-07-08 15:34:20 --> Session: Class initialized using 'files' driver.
INFO - 2024-07-08 15:34:20 --> Controller Class Initialized
INFO - 2024-07-08 15:34:23 --> Config Class Initialized
INFO - 2024-07-08 15:34:23 --> Hooks Class Initialized
DEBUG - 2024-07-08 15:34:23 --> UTF-8 Support Enabled
INFO - 2024-07-08 15:34:23 --> Utf8 Class Initialized
INFO - 2024-07-08 15:34:23 --> URI Class Initialized
INFO - 2024-07-08 15:34:23 --> Router Class Initialized
INFO - 2024-07-08 15:34:23 --> Output Class Initialized
INFO - 2024-07-08 15:34:23 --> Security Class Initialized
DEBUG - 2024-07-08 15:34:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-07-08 15:34:23 --> Input Class Initialized
INFO - 2024-07-08 15:34:23 --> Language Class Initialized
INFO - 2024-07-08 15:34:23 --> Language Class Initialized
INFO - 2024-07-08 15:34:23 --> Config Class Initialized
INFO - 2024-07-08 15:34:23 --> Loader Class Initialized
INFO - 2024-07-08 15:34:23 --> Helper loaded: url_helper
INFO - 2024-07-08 15:34:23 --> Helper loaded: file_helper
INFO - 2024-07-08 15:34:23 --> Helper loaded: form_helper
INFO - 2024-07-08 15:34:23 --> Helper loaded: my_helper
INFO - 2024-07-08 15:34:23 --> Database Driver Class Initialized
INFO - 2024-07-08 15:34:23 --> Session: Class initialized using 'files' driver.
INFO - 2024-07-08 15:34:23 --> Controller Class Initialized
INFO - 2024-07-08 15:34:23 --> Final output sent to browser
DEBUG - 2024-07-08 15:34:23 --> Total execution time: 0.0415
INFO - 2024-07-08 15:34:23 --> Config Class Initialized
INFO - 2024-07-08 15:34:23 --> Hooks Class Initialized
DEBUG - 2024-07-08 15:34:23 --> UTF-8 Support Enabled
INFO - 2024-07-08 15:34:23 --> Utf8 Class Initialized
INFO - 2024-07-08 15:34:23 --> URI Class Initialized
INFO - 2024-07-08 15:34:23 --> Router Class Initialized
INFO - 2024-07-08 15:34:23 --> Output Class Initialized
INFO - 2024-07-08 15:34:23 --> Security Class Initialized
DEBUG - 2024-07-08 15:34:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-07-08 15:34:23 --> Input Class Initialized
INFO - 2024-07-08 15:34:23 --> Language Class Initialized
ERROR - 2024-07-08 15:34:23 --> 404 Page Not Found: /index
INFO - 2024-07-08 15:34:23 --> Config Class Initialized
INFO - 2024-07-08 15:34:23 --> Hooks Class Initialized
DEBUG - 2024-07-08 15:34:23 --> UTF-8 Support Enabled
INFO - 2024-07-08 15:34:23 --> Utf8 Class Initialized
INFO - 2024-07-08 15:34:23 --> URI Class Initialized
INFO - 2024-07-08 15:34:23 --> Router Class Initialized
INFO - 2024-07-08 15:34:23 --> Output Class Initialized
INFO - 2024-07-08 15:34:23 --> Security Class Initialized
DEBUG - 2024-07-08 15:34:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-07-08 15:34:23 --> Input Class Initialized
INFO - 2024-07-08 15:34:23 --> Language Class Initialized
INFO - 2024-07-08 15:34:23 --> Language Class Initialized
INFO - 2024-07-08 15:34:23 --> Config Class Initialized
INFO - 2024-07-08 15:34:23 --> Loader Class Initialized
INFO - 2024-07-08 15:34:23 --> Helper loaded: url_helper
INFO - 2024-07-08 15:34:23 --> Helper loaded: file_helper
INFO - 2024-07-08 15:34:23 --> Helper loaded: form_helper
INFO - 2024-07-08 15:34:23 --> Helper loaded: my_helper
INFO - 2024-07-08 15:34:23 --> Database Driver Class Initialized
INFO - 2024-07-08 15:34:23 --> Session: Class initialized using 'files' driver.
INFO - 2024-07-08 15:34:23 --> Controller Class Initialized
INFO - 2024-07-08 15:34:24 --> Config Class Initialized
INFO - 2024-07-08 15:34:24 --> Hooks Class Initialized
DEBUG - 2024-07-08 15:34:24 --> UTF-8 Support Enabled
INFO - 2024-07-08 15:34:24 --> Utf8 Class Initialized
INFO - 2024-07-08 15:34:24 --> URI Class Initialized
INFO - 2024-07-08 15:34:24 --> Router Class Initialized
INFO - 2024-07-08 15:34:24 --> Output Class Initialized
INFO - 2024-07-08 15:34:24 --> Security Class Initialized
DEBUG - 2024-07-08 15:34:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-07-08 15:34:24 --> Input Class Initialized
INFO - 2024-07-08 15:34:24 --> Language Class Initialized
INFO - 2024-07-08 15:34:24 --> Language Class Initialized
INFO - 2024-07-08 15:34:24 --> Config Class Initialized
INFO - 2024-07-08 15:34:24 --> Loader Class Initialized
INFO - 2024-07-08 15:34:25 --> Helper loaded: url_helper
INFO - 2024-07-08 15:34:25 --> Helper loaded: file_helper
INFO - 2024-07-08 15:34:25 --> Helper loaded: form_helper
INFO - 2024-07-08 15:34:25 --> Helper loaded: my_helper
INFO - 2024-07-08 15:34:25 --> Database Driver Class Initialized
INFO - 2024-07-08 15:34:25 --> Session: Class initialized using 'files' driver.
INFO - 2024-07-08 15:34:25 --> Controller Class Initialized
INFO - 2024-07-08 15:34:27 --> Config Class Initialized
INFO - 2024-07-08 15:34:27 --> Hooks Class Initialized
DEBUG - 2024-07-08 15:34:27 --> UTF-8 Support Enabled
INFO - 2024-07-08 15:34:27 --> Utf8 Class Initialized
INFO - 2024-07-08 15:34:27 --> URI Class Initialized
INFO - 2024-07-08 15:34:27 --> Router Class Initialized
INFO - 2024-07-08 15:34:27 --> Output Class Initialized
INFO - 2024-07-08 15:34:27 --> Security Class Initialized
DEBUG - 2024-07-08 15:34:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-07-08 15:34:27 --> Input Class Initialized
INFO - 2024-07-08 15:34:27 --> Language Class Initialized
INFO - 2024-07-08 15:34:27 --> Language Class Initialized
INFO - 2024-07-08 15:34:27 --> Config Class Initialized
INFO - 2024-07-08 15:34:27 --> Loader Class Initialized
INFO - 2024-07-08 15:34:27 --> Helper loaded: url_helper
INFO - 2024-07-08 15:34:27 --> Helper loaded: file_helper
INFO - 2024-07-08 15:34:27 --> Helper loaded: form_helper
INFO - 2024-07-08 15:34:27 --> Helper loaded: my_helper
INFO - 2024-07-08 15:34:27 --> Database Driver Class Initialized
INFO - 2024-07-08 15:34:27 --> Session: Class initialized using 'files' driver.
INFO - 2024-07-08 15:34:27 --> Controller Class Initialized
INFO - 2024-07-08 15:34:27 --> Final output sent to browser
DEBUG - 2024-07-08 15:34:27 --> Total execution time: 0.0950
INFO - 2024-07-08 15:34:27 --> Config Class Initialized
INFO - 2024-07-08 15:34:27 --> Hooks Class Initialized
DEBUG - 2024-07-08 15:34:27 --> UTF-8 Support Enabled
INFO - 2024-07-08 15:34:27 --> Utf8 Class Initialized
INFO - 2024-07-08 15:34:27 --> URI Class Initialized
INFO - 2024-07-08 15:34:27 --> Router Class Initialized
INFO - 2024-07-08 15:34:27 --> Output Class Initialized
INFO - 2024-07-08 15:34:27 --> Security Class Initialized
DEBUG - 2024-07-08 15:34:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-07-08 15:34:27 --> Input Class Initialized
INFO - 2024-07-08 15:34:27 --> Language Class Initialized
ERROR - 2024-07-08 15:34:27 --> 404 Page Not Found: /index
INFO - 2024-07-08 15:34:27 --> Config Class Initialized
INFO - 2024-07-08 15:34:27 --> Hooks Class Initialized
DEBUG - 2024-07-08 15:34:27 --> UTF-8 Support Enabled
INFO - 2024-07-08 15:34:27 --> Utf8 Class Initialized
INFO - 2024-07-08 15:34:27 --> URI Class Initialized
INFO - 2024-07-08 15:34:27 --> Router Class Initialized
INFO - 2024-07-08 15:34:27 --> Output Class Initialized
INFO - 2024-07-08 15:34:27 --> Security Class Initialized
DEBUG - 2024-07-08 15:34:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-07-08 15:34:27 --> Input Class Initialized
INFO - 2024-07-08 15:34:27 --> Language Class Initialized
INFO - 2024-07-08 15:34:27 --> Language Class Initialized
INFO - 2024-07-08 15:34:27 --> Config Class Initialized
INFO - 2024-07-08 15:34:27 --> Loader Class Initialized
INFO - 2024-07-08 15:34:27 --> Helper loaded: url_helper
INFO - 2024-07-08 15:34:27 --> Helper loaded: file_helper
INFO - 2024-07-08 15:34:27 --> Helper loaded: form_helper
INFO - 2024-07-08 15:34:27 --> Helper loaded: my_helper
INFO - 2024-07-08 15:34:27 --> Database Driver Class Initialized
INFO - 2024-07-08 15:34:27 --> Session: Class initialized using 'files' driver.
INFO - 2024-07-08 15:34:27 --> Controller Class Initialized
INFO - 2024-07-08 15:34:28 --> Config Class Initialized
INFO - 2024-07-08 15:34:28 --> Hooks Class Initialized
DEBUG - 2024-07-08 15:34:28 --> UTF-8 Support Enabled
INFO - 2024-07-08 15:34:28 --> Utf8 Class Initialized
INFO - 2024-07-08 15:34:28 --> URI Class Initialized
INFO - 2024-07-08 15:34:28 --> Router Class Initialized
INFO - 2024-07-08 15:34:28 --> Output Class Initialized
INFO - 2024-07-08 15:34:28 --> Security Class Initialized
DEBUG - 2024-07-08 15:34:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-07-08 15:34:28 --> Input Class Initialized
INFO - 2024-07-08 15:34:28 --> Language Class Initialized
INFO - 2024-07-08 15:34:28 --> Language Class Initialized
INFO - 2024-07-08 15:34:28 --> Config Class Initialized
INFO - 2024-07-08 15:34:28 --> Loader Class Initialized
INFO - 2024-07-08 15:34:28 --> Helper loaded: url_helper
INFO - 2024-07-08 15:34:28 --> Helper loaded: file_helper
INFO - 2024-07-08 15:34:28 --> Helper loaded: form_helper
INFO - 2024-07-08 15:34:28 --> Helper loaded: my_helper
INFO - 2024-07-08 15:34:28 --> Database Driver Class Initialized
INFO - 2024-07-08 15:34:28 --> Session: Class initialized using 'files' driver.
INFO - 2024-07-08 15:34:28 --> Controller Class Initialized
INFO - 2024-07-08 15:34:31 --> Config Class Initialized
INFO - 2024-07-08 15:34:31 --> Hooks Class Initialized
DEBUG - 2024-07-08 15:34:31 --> UTF-8 Support Enabled
INFO - 2024-07-08 15:34:31 --> Utf8 Class Initialized
INFO - 2024-07-08 15:34:31 --> URI Class Initialized
INFO - 2024-07-08 15:34:31 --> Router Class Initialized
INFO - 2024-07-08 15:34:31 --> Output Class Initialized
INFO - 2024-07-08 15:34:31 --> Security Class Initialized
DEBUG - 2024-07-08 15:34:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-07-08 15:34:31 --> Input Class Initialized
INFO - 2024-07-08 15:34:31 --> Language Class Initialized
INFO - 2024-07-08 15:34:31 --> Language Class Initialized
INFO - 2024-07-08 15:34:31 --> Config Class Initialized
INFO - 2024-07-08 15:34:31 --> Loader Class Initialized
INFO - 2024-07-08 15:34:31 --> Helper loaded: url_helper
INFO - 2024-07-08 15:34:31 --> Helper loaded: file_helper
INFO - 2024-07-08 15:34:31 --> Helper loaded: form_helper
INFO - 2024-07-08 15:34:31 --> Helper loaded: my_helper
INFO - 2024-07-08 15:34:31 --> Database Driver Class Initialized
INFO - 2024-07-08 15:34:31 --> Session: Class initialized using 'files' driver.
INFO - 2024-07-08 15:34:31 --> Controller Class Initialized
INFO - 2024-07-08 15:34:31 --> Final output sent to browser
DEBUG - 2024-07-08 15:34:31 --> Total execution time: 0.0343
INFO - 2024-07-08 15:34:31 --> Config Class Initialized
INFO - 2024-07-08 15:34:31 --> Hooks Class Initialized
DEBUG - 2024-07-08 15:34:31 --> UTF-8 Support Enabled
INFO - 2024-07-08 15:34:31 --> Utf8 Class Initialized
INFO - 2024-07-08 15:34:31 --> URI Class Initialized
INFO - 2024-07-08 15:34:31 --> Router Class Initialized
INFO - 2024-07-08 15:34:31 --> Output Class Initialized
INFO - 2024-07-08 15:34:31 --> Security Class Initialized
DEBUG - 2024-07-08 15:34:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-07-08 15:34:31 --> Input Class Initialized
INFO - 2024-07-08 15:34:31 --> Language Class Initialized
ERROR - 2024-07-08 15:34:31 --> 404 Page Not Found: /index
INFO - 2024-07-08 15:34:31 --> Config Class Initialized
INFO - 2024-07-08 15:34:31 --> Hooks Class Initialized
DEBUG - 2024-07-08 15:34:31 --> UTF-8 Support Enabled
INFO - 2024-07-08 15:34:31 --> Utf8 Class Initialized
INFO - 2024-07-08 15:34:31 --> URI Class Initialized
INFO - 2024-07-08 15:34:31 --> Router Class Initialized
INFO - 2024-07-08 15:34:31 --> Output Class Initialized
INFO - 2024-07-08 15:34:31 --> Security Class Initialized
DEBUG - 2024-07-08 15:34:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-07-08 15:34:31 --> Input Class Initialized
INFO - 2024-07-08 15:34:31 --> Language Class Initialized
INFO - 2024-07-08 15:34:31 --> Language Class Initialized
INFO - 2024-07-08 15:34:31 --> Config Class Initialized
INFO - 2024-07-08 15:34:31 --> Loader Class Initialized
INFO - 2024-07-08 15:34:31 --> Helper loaded: url_helper
INFO - 2024-07-08 15:34:31 --> Helper loaded: file_helper
INFO - 2024-07-08 15:34:31 --> Helper loaded: form_helper
INFO - 2024-07-08 15:34:31 --> Helper loaded: my_helper
INFO - 2024-07-08 15:34:31 --> Database Driver Class Initialized
INFO - 2024-07-08 15:34:31 --> Session: Class initialized using 'files' driver.
INFO - 2024-07-08 15:34:31 --> Controller Class Initialized
INFO - 2024-07-08 15:34:33 --> Config Class Initialized
INFO - 2024-07-08 15:34:33 --> Hooks Class Initialized
DEBUG - 2024-07-08 15:34:33 --> UTF-8 Support Enabled
INFO - 2024-07-08 15:34:33 --> Utf8 Class Initialized
INFO - 2024-07-08 15:34:33 --> URI Class Initialized
INFO - 2024-07-08 15:34:33 --> Router Class Initialized
INFO - 2024-07-08 15:34:33 --> Output Class Initialized
INFO - 2024-07-08 15:34:33 --> Security Class Initialized
DEBUG - 2024-07-08 15:34:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-07-08 15:34:33 --> Input Class Initialized
INFO - 2024-07-08 15:34:33 --> Language Class Initialized
INFO - 2024-07-08 15:34:33 --> Language Class Initialized
INFO - 2024-07-08 15:34:33 --> Config Class Initialized
INFO - 2024-07-08 15:34:33 --> Loader Class Initialized
INFO - 2024-07-08 15:34:33 --> Helper loaded: url_helper
INFO - 2024-07-08 15:34:33 --> Helper loaded: file_helper
INFO - 2024-07-08 15:34:33 --> Helper loaded: form_helper
INFO - 2024-07-08 15:34:33 --> Helper loaded: my_helper
INFO - 2024-07-08 15:34:33 --> Database Driver Class Initialized
INFO - 2024-07-08 15:34:33 --> Session: Class initialized using 'files' driver.
INFO - 2024-07-08 15:34:33 --> Controller Class Initialized
INFO - 2024-07-08 15:34:35 --> Config Class Initialized
INFO - 2024-07-08 15:34:35 --> Hooks Class Initialized
DEBUG - 2024-07-08 15:34:35 --> UTF-8 Support Enabled
INFO - 2024-07-08 15:34:35 --> Utf8 Class Initialized
INFO - 2024-07-08 15:34:35 --> URI Class Initialized
INFO - 2024-07-08 15:34:35 --> Router Class Initialized
INFO - 2024-07-08 15:34:35 --> Output Class Initialized
INFO - 2024-07-08 15:34:35 --> Security Class Initialized
DEBUG - 2024-07-08 15:34:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-07-08 15:34:35 --> Input Class Initialized
INFO - 2024-07-08 15:34:35 --> Language Class Initialized
INFO - 2024-07-08 15:34:35 --> Language Class Initialized
INFO - 2024-07-08 15:34:35 --> Config Class Initialized
INFO - 2024-07-08 15:34:35 --> Loader Class Initialized
INFO - 2024-07-08 15:34:35 --> Helper loaded: url_helper
INFO - 2024-07-08 15:34:35 --> Helper loaded: file_helper
INFO - 2024-07-08 15:34:35 --> Helper loaded: form_helper
INFO - 2024-07-08 15:34:35 --> Helper loaded: my_helper
INFO - 2024-07-08 15:34:35 --> Database Driver Class Initialized
INFO - 2024-07-08 15:34:35 --> Session: Class initialized using 'files' driver.
INFO - 2024-07-08 15:34:35 --> Controller Class Initialized
INFO - 2024-07-08 15:34:38 --> Config Class Initialized
INFO - 2024-07-08 15:34:38 --> Hooks Class Initialized
DEBUG - 2024-07-08 15:34:38 --> UTF-8 Support Enabled
INFO - 2024-07-08 15:34:38 --> Utf8 Class Initialized
INFO - 2024-07-08 15:34:38 --> URI Class Initialized
INFO - 2024-07-08 15:34:38 --> Router Class Initialized
INFO - 2024-07-08 15:34:38 --> Output Class Initialized
INFO - 2024-07-08 15:34:38 --> Security Class Initialized
DEBUG - 2024-07-08 15:34:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-07-08 15:34:38 --> Input Class Initialized
INFO - 2024-07-08 15:34:38 --> Language Class Initialized
INFO - 2024-07-08 15:34:38 --> Language Class Initialized
INFO - 2024-07-08 15:34:38 --> Config Class Initialized
INFO - 2024-07-08 15:34:38 --> Loader Class Initialized
INFO - 2024-07-08 15:34:38 --> Helper loaded: url_helper
INFO - 2024-07-08 15:34:38 --> Helper loaded: file_helper
INFO - 2024-07-08 15:34:38 --> Helper loaded: form_helper
INFO - 2024-07-08 15:34:38 --> Helper loaded: my_helper
INFO - 2024-07-08 15:34:38 --> Database Driver Class Initialized
INFO - 2024-07-08 15:34:38 --> Session: Class initialized using 'files' driver.
INFO - 2024-07-08 15:34:38 --> Controller Class Initialized
INFO - 2024-07-08 15:34:38 --> Final output sent to browser
DEBUG - 2024-07-08 15:34:38 --> Total execution time: 0.0318
INFO - 2024-07-08 15:34:38 --> Config Class Initialized
INFO - 2024-07-08 15:34:38 --> Hooks Class Initialized
DEBUG - 2024-07-08 15:34:38 --> UTF-8 Support Enabled
INFO - 2024-07-08 15:34:38 --> Utf8 Class Initialized
INFO - 2024-07-08 15:34:38 --> URI Class Initialized
INFO - 2024-07-08 15:34:38 --> Router Class Initialized
INFO - 2024-07-08 15:34:38 --> Output Class Initialized
INFO - 2024-07-08 15:34:38 --> Security Class Initialized
DEBUG - 2024-07-08 15:34:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-07-08 15:34:38 --> Input Class Initialized
INFO - 2024-07-08 15:34:38 --> Language Class Initialized
ERROR - 2024-07-08 15:34:38 --> 404 Page Not Found: /index
INFO - 2024-07-08 15:34:38 --> Config Class Initialized
INFO - 2024-07-08 15:34:38 --> Hooks Class Initialized
DEBUG - 2024-07-08 15:34:38 --> UTF-8 Support Enabled
INFO - 2024-07-08 15:34:38 --> Utf8 Class Initialized
INFO - 2024-07-08 15:34:38 --> URI Class Initialized
INFO - 2024-07-08 15:34:38 --> Router Class Initialized
INFO - 2024-07-08 15:34:38 --> Output Class Initialized
INFO - 2024-07-08 15:34:38 --> Security Class Initialized
DEBUG - 2024-07-08 15:34:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-07-08 15:34:38 --> Input Class Initialized
INFO - 2024-07-08 15:34:38 --> Language Class Initialized
INFO - 2024-07-08 15:34:38 --> Language Class Initialized
INFO - 2024-07-08 15:34:38 --> Config Class Initialized
INFO - 2024-07-08 15:34:38 --> Loader Class Initialized
INFO - 2024-07-08 15:34:38 --> Helper loaded: url_helper
INFO - 2024-07-08 15:34:38 --> Helper loaded: file_helper
INFO - 2024-07-08 15:34:38 --> Helper loaded: form_helper
INFO - 2024-07-08 15:34:38 --> Helper loaded: my_helper
INFO - 2024-07-08 15:34:38 --> Database Driver Class Initialized
INFO - 2024-07-08 15:34:38 --> Session: Class initialized using 'files' driver.
INFO - 2024-07-08 15:34:38 --> Controller Class Initialized
INFO - 2024-07-08 15:34:39 --> Config Class Initialized
INFO - 2024-07-08 15:34:39 --> Hooks Class Initialized
DEBUG - 2024-07-08 15:34:39 --> UTF-8 Support Enabled
INFO - 2024-07-08 15:34:39 --> Utf8 Class Initialized
INFO - 2024-07-08 15:34:39 --> URI Class Initialized
INFO - 2024-07-08 15:34:39 --> Router Class Initialized
INFO - 2024-07-08 15:34:39 --> Output Class Initialized
INFO - 2024-07-08 15:34:39 --> Security Class Initialized
DEBUG - 2024-07-08 15:34:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-07-08 15:34:39 --> Input Class Initialized
INFO - 2024-07-08 15:34:39 --> Language Class Initialized
INFO - 2024-07-08 15:34:39 --> Language Class Initialized
INFO - 2024-07-08 15:34:39 --> Config Class Initialized
INFO - 2024-07-08 15:34:39 --> Loader Class Initialized
INFO - 2024-07-08 15:34:39 --> Helper loaded: url_helper
INFO - 2024-07-08 15:34:39 --> Helper loaded: file_helper
INFO - 2024-07-08 15:34:39 --> Helper loaded: form_helper
INFO - 2024-07-08 15:34:39 --> Helper loaded: my_helper
INFO - 2024-07-08 15:34:39 --> Database Driver Class Initialized
INFO - 2024-07-08 15:34:39 --> Session: Class initialized using 'files' driver.
INFO - 2024-07-08 15:34:39 --> Controller Class Initialized
INFO - 2024-07-08 15:34:42 --> Config Class Initialized
INFO - 2024-07-08 15:34:42 --> Hooks Class Initialized
DEBUG - 2024-07-08 15:34:42 --> UTF-8 Support Enabled
INFO - 2024-07-08 15:34:42 --> Utf8 Class Initialized
INFO - 2024-07-08 15:34:42 --> URI Class Initialized
INFO - 2024-07-08 15:34:42 --> Router Class Initialized
INFO - 2024-07-08 15:34:42 --> Output Class Initialized
INFO - 2024-07-08 15:34:42 --> Security Class Initialized
DEBUG - 2024-07-08 15:34:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-07-08 15:34:42 --> Input Class Initialized
INFO - 2024-07-08 15:34:42 --> Language Class Initialized
INFO - 2024-07-08 15:34:42 --> Language Class Initialized
INFO - 2024-07-08 15:34:42 --> Config Class Initialized
INFO - 2024-07-08 15:34:42 --> Loader Class Initialized
INFO - 2024-07-08 15:34:42 --> Helper loaded: url_helper
INFO - 2024-07-08 15:34:42 --> Helper loaded: file_helper
INFO - 2024-07-08 15:34:42 --> Helper loaded: form_helper
INFO - 2024-07-08 15:34:42 --> Helper loaded: my_helper
INFO - 2024-07-08 15:34:42 --> Database Driver Class Initialized
INFO - 2024-07-08 15:34:42 --> Session: Class initialized using 'files' driver.
INFO - 2024-07-08 15:34:42 --> Controller Class Initialized
INFO - 2024-07-08 15:34:42 --> Final output sent to browser
DEBUG - 2024-07-08 15:34:42 --> Total execution time: 0.0414
INFO - 2024-07-08 15:34:42 --> Config Class Initialized
INFO - 2024-07-08 15:34:42 --> Hooks Class Initialized
DEBUG - 2024-07-08 15:34:42 --> UTF-8 Support Enabled
INFO - 2024-07-08 15:34:42 --> Utf8 Class Initialized
INFO - 2024-07-08 15:34:42 --> URI Class Initialized
INFO - 2024-07-08 15:34:42 --> Router Class Initialized
INFO - 2024-07-08 15:34:42 --> Output Class Initialized
INFO - 2024-07-08 15:34:42 --> Security Class Initialized
DEBUG - 2024-07-08 15:34:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-07-08 15:34:42 --> Input Class Initialized
INFO - 2024-07-08 15:34:42 --> Language Class Initialized
ERROR - 2024-07-08 15:34:42 --> 404 Page Not Found: /index
INFO - 2024-07-08 15:34:42 --> Config Class Initialized
INFO - 2024-07-08 15:34:42 --> Hooks Class Initialized
DEBUG - 2024-07-08 15:34:42 --> UTF-8 Support Enabled
INFO - 2024-07-08 15:34:42 --> Utf8 Class Initialized
INFO - 2024-07-08 15:34:42 --> URI Class Initialized
INFO - 2024-07-08 15:34:42 --> Router Class Initialized
INFO - 2024-07-08 15:34:42 --> Output Class Initialized
INFO - 2024-07-08 15:34:42 --> Security Class Initialized
DEBUG - 2024-07-08 15:34:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-07-08 15:34:42 --> Input Class Initialized
INFO - 2024-07-08 15:34:42 --> Language Class Initialized
INFO - 2024-07-08 15:34:42 --> Language Class Initialized
INFO - 2024-07-08 15:34:42 --> Config Class Initialized
INFO - 2024-07-08 15:34:42 --> Loader Class Initialized
INFO - 2024-07-08 15:34:42 --> Helper loaded: url_helper
INFO - 2024-07-08 15:34:42 --> Helper loaded: file_helper
INFO - 2024-07-08 15:34:42 --> Helper loaded: form_helper
INFO - 2024-07-08 15:34:42 --> Helper loaded: my_helper
INFO - 2024-07-08 15:34:42 --> Database Driver Class Initialized
INFO - 2024-07-08 15:34:42 --> Session: Class initialized using 'files' driver.
INFO - 2024-07-08 15:34:42 --> Controller Class Initialized
INFO - 2024-07-08 15:34:44 --> Config Class Initialized
INFO - 2024-07-08 15:34:44 --> Hooks Class Initialized
DEBUG - 2024-07-08 15:34:44 --> UTF-8 Support Enabled
INFO - 2024-07-08 15:34:44 --> Utf8 Class Initialized
INFO - 2024-07-08 15:34:44 --> URI Class Initialized
INFO - 2024-07-08 15:34:44 --> Router Class Initialized
INFO - 2024-07-08 15:34:44 --> Output Class Initialized
INFO - 2024-07-08 15:34:44 --> Security Class Initialized
DEBUG - 2024-07-08 15:34:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-07-08 15:34:44 --> Input Class Initialized
INFO - 2024-07-08 15:34:44 --> Language Class Initialized
INFO - 2024-07-08 15:34:44 --> Language Class Initialized
INFO - 2024-07-08 15:34:44 --> Config Class Initialized
INFO - 2024-07-08 15:34:44 --> Loader Class Initialized
INFO - 2024-07-08 15:34:44 --> Helper loaded: url_helper
INFO - 2024-07-08 15:34:44 --> Helper loaded: file_helper
INFO - 2024-07-08 15:34:44 --> Helper loaded: form_helper
INFO - 2024-07-08 15:34:44 --> Helper loaded: my_helper
INFO - 2024-07-08 15:34:44 --> Database Driver Class Initialized
INFO - 2024-07-08 15:34:44 --> Session: Class initialized using 'files' driver.
INFO - 2024-07-08 15:34:44 --> Controller Class Initialized
INFO - 2024-07-08 15:34:47 --> Config Class Initialized
INFO - 2024-07-08 15:34:47 --> Hooks Class Initialized
DEBUG - 2024-07-08 15:34:47 --> UTF-8 Support Enabled
INFO - 2024-07-08 15:34:47 --> Utf8 Class Initialized
INFO - 2024-07-08 15:34:47 --> URI Class Initialized
INFO - 2024-07-08 15:34:47 --> Router Class Initialized
INFO - 2024-07-08 15:34:47 --> Output Class Initialized
INFO - 2024-07-08 15:34:47 --> Security Class Initialized
DEBUG - 2024-07-08 15:34:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-07-08 15:34:47 --> Input Class Initialized
INFO - 2024-07-08 15:34:47 --> Language Class Initialized
INFO - 2024-07-08 15:34:47 --> Language Class Initialized
INFO - 2024-07-08 15:34:47 --> Config Class Initialized
INFO - 2024-07-08 15:34:47 --> Loader Class Initialized
INFO - 2024-07-08 15:34:47 --> Helper loaded: url_helper
INFO - 2024-07-08 15:34:47 --> Helper loaded: file_helper
INFO - 2024-07-08 15:34:47 --> Helper loaded: form_helper
INFO - 2024-07-08 15:34:47 --> Helper loaded: my_helper
INFO - 2024-07-08 15:34:47 --> Database Driver Class Initialized
INFO - 2024-07-08 15:34:47 --> Session: Class initialized using 'files' driver.
INFO - 2024-07-08 15:34:47 --> Controller Class Initialized
INFO - 2024-07-08 15:34:47 --> Final output sent to browser
DEBUG - 2024-07-08 15:34:47 --> Total execution time: 0.0439
INFO - 2024-07-08 15:34:47 --> Config Class Initialized
INFO - 2024-07-08 15:34:47 --> Hooks Class Initialized
DEBUG - 2024-07-08 15:34:47 --> UTF-8 Support Enabled
INFO - 2024-07-08 15:34:47 --> Utf8 Class Initialized
INFO - 2024-07-08 15:34:47 --> URI Class Initialized
INFO - 2024-07-08 15:34:47 --> Router Class Initialized
INFO - 2024-07-08 15:34:47 --> Output Class Initialized
INFO - 2024-07-08 15:34:47 --> Security Class Initialized
DEBUG - 2024-07-08 15:34:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-07-08 15:34:47 --> Input Class Initialized
INFO - 2024-07-08 15:34:47 --> Language Class Initialized
ERROR - 2024-07-08 15:34:47 --> 404 Page Not Found: /index
INFO - 2024-07-08 15:34:47 --> Config Class Initialized
INFO - 2024-07-08 15:34:47 --> Hooks Class Initialized
DEBUG - 2024-07-08 15:34:47 --> UTF-8 Support Enabled
INFO - 2024-07-08 15:34:47 --> Utf8 Class Initialized
INFO - 2024-07-08 15:34:47 --> URI Class Initialized
INFO - 2024-07-08 15:34:47 --> Router Class Initialized
INFO - 2024-07-08 15:34:47 --> Output Class Initialized
INFO - 2024-07-08 15:34:47 --> Security Class Initialized
DEBUG - 2024-07-08 15:34:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-07-08 15:34:47 --> Input Class Initialized
INFO - 2024-07-08 15:34:47 --> Language Class Initialized
INFO - 2024-07-08 15:34:47 --> Language Class Initialized
INFO - 2024-07-08 15:34:47 --> Config Class Initialized
INFO - 2024-07-08 15:34:47 --> Loader Class Initialized
INFO - 2024-07-08 15:34:47 --> Helper loaded: url_helper
INFO - 2024-07-08 15:34:47 --> Helper loaded: file_helper
INFO - 2024-07-08 15:34:47 --> Helper loaded: form_helper
INFO - 2024-07-08 15:34:47 --> Helper loaded: my_helper
INFO - 2024-07-08 15:34:47 --> Database Driver Class Initialized
INFO - 2024-07-08 15:34:47 --> Session: Class initialized using 'files' driver.
INFO - 2024-07-08 15:34:47 --> Controller Class Initialized
INFO - 2024-07-08 15:34:48 --> Config Class Initialized
INFO - 2024-07-08 15:34:48 --> Hooks Class Initialized
DEBUG - 2024-07-08 15:34:48 --> UTF-8 Support Enabled
INFO - 2024-07-08 15:34:48 --> Utf8 Class Initialized
INFO - 2024-07-08 15:34:48 --> URI Class Initialized
INFO - 2024-07-08 15:34:48 --> Router Class Initialized
INFO - 2024-07-08 15:34:48 --> Output Class Initialized
INFO - 2024-07-08 15:34:48 --> Security Class Initialized
DEBUG - 2024-07-08 15:34:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-07-08 15:34:48 --> Input Class Initialized
INFO - 2024-07-08 15:34:48 --> Language Class Initialized
INFO - 2024-07-08 15:34:48 --> Language Class Initialized
INFO - 2024-07-08 15:34:48 --> Config Class Initialized
INFO - 2024-07-08 15:34:48 --> Loader Class Initialized
INFO - 2024-07-08 15:34:48 --> Helper loaded: url_helper
INFO - 2024-07-08 15:34:48 --> Helper loaded: file_helper
INFO - 2024-07-08 15:34:48 --> Helper loaded: form_helper
INFO - 2024-07-08 15:34:48 --> Helper loaded: my_helper
INFO - 2024-07-08 15:34:48 --> Database Driver Class Initialized
INFO - 2024-07-08 15:34:48 --> Session: Class initialized using 'files' driver.
INFO - 2024-07-08 15:34:48 --> Controller Class Initialized
INFO - 2024-07-08 15:34:51 --> Config Class Initialized
INFO - 2024-07-08 15:34:51 --> Hooks Class Initialized
DEBUG - 2024-07-08 15:34:51 --> UTF-8 Support Enabled
INFO - 2024-07-08 15:34:51 --> Utf8 Class Initialized
INFO - 2024-07-08 15:34:51 --> URI Class Initialized
INFO - 2024-07-08 15:34:51 --> Router Class Initialized
INFO - 2024-07-08 15:34:51 --> Output Class Initialized
INFO - 2024-07-08 15:34:51 --> Security Class Initialized
DEBUG - 2024-07-08 15:34:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-07-08 15:34:51 --> Input Class Initialized
INFO - 2024-07-08 15:34:51 --> Language Class Initialized
INFO - 2024-07-08 15:34:51 --> Language Class Initialized
INFO - 2024-07-08 15:34:51 --> Config Class Initialized
INFO - 2024-07-08 15:34:51 --> Loader Class Initialized
INFO - 2024-07-08 15:34:51 --> Helper loaded: url_helper
INFO - 2024-07-08 15:34:51 --> Helper loaded: file_helper
INFO - 2024-07-08 15:34:51 --> Helper loaded: form_helper
INFO - 2024-07-08 15:34:51 --> Helper loaded: my_helper
INFO - 2024-07-08 15:34:51 --> Database Driver Class Initialized
INFO - 2024-07-08 15:34:51 --> Session: Class initialized using 'files' driver.
INFO - 2024-07-08 15:34:51 --> Controller Class Initialized
INFO - 2024-07-08 15:34:51 --> Final output sent to browser
DEBUG - 2024-07-08 15:34:51 --> Total execution time: 0.0406
INFO - 2024-07-08 15:34:51 --> Config Class Initialized
INFO - 2024-07-08 15:34:51 --> Hooks Class Initialized
DEBUG - 2024-07-08 15:34:51 --> UTF-8 Support Enabled
INFO - 2024-07-08 15:34:51 --> Utf8 Class Initialized
INFO - 2024-07-08 15:34:51 --> URI Class Initialized
INFO - 2024-07-08 15:34:51 --> Router Class Initialized
INFO - 2024-07-08 15:34:51 --> Output Class Initialized
INFO - 2024-07-08 15:34:51 --> Security Class Initialized
DEBUG - 2024-07-08 15:34:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-07-08 15:34:51 --> Input Class Initialized
INFO - 2024-07-08 15:34:51 --> Language Class Initialized
ERROR - 2024-07-08 15:34:51 --> 404 Page Not Found: /index
INFO - 2024-07-08 15:34:51 --> Config Class Initialized
INFO - 2024-07-08 15:34:51 --> Hooks Class Initialized
DEBUG - 2024-07-08 15:34:51 --> UTF-8 Support Enabled
INFO - 2024-07-08 15:34:51 --> Utf8 Class Initialized
INFO - 2024-07-08 15:34:51 --> URI Class Initialized
INFO - 2024-07-08 15:34:51 --> Router Class Initialized
INFO - 2024-07-08 15:34:51 --> Output Class Initialized
INFO - 2024-07-08 15:34:51 --> Security Class Initialized
DEBUG - 2024-07-08 15:34:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-07-08 15:34:51 --> Input Class Initialized
INFO - 2024-07-08 15:34:51 --> Language Class Initialized
INFO - 2024-07-08 15:34:51 --> Language Class Initialized
INFO - 2024-07-08 15:34:51 --> Config Class Initialized
INFO - 2024-07-08 15:34:51 --> Loader Class Initialized
INFO - 2024-07-08 15:34:51 --> Helper loaded: url_helper
INFO - 2024-07-08 15:34:51 --> Helper loaded: file_helper
INFO - 2024-07-08 15:34:51 --> Helper loaded: form_helper
INFO - 2024-07-08 15:34:51 --> Helper loaded: my_helper
INFO - 2024-07-08 15:34:51 --> Database Driver Class Initialized
INFO - 2024-07-08 15:34:51 --> Session: Class initialized using 'files' driver.
INFO - 2024-07-08 15:34:51 --> Controller Class Initialized
INFO - 2024-07-08 15:34:54 --> Config Class Initialized
INFO - 2024-07-08 15:34:54 --> Hooks Class Initialized
DEBUG - 2024-07-08 15:34:54 --> UTF-8 Support Enabled
INFO - 2024-07-08 15:34:54 --> Utf8 Class Initialized
INFO - 2024-07-08 15:34:54 --> URI Class Initialized
INFO - 2024-07-08 15:34:54 --> Router Class Initialized
INFO - 2024-07-08 15:34:54 --> Output Class Initialized
INFO - 2024-07-08 15:34:54 --> Security Class Initialized
DEBUG - 2024-07-08 15:34:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-07-08 15:34:54 --> Input Class Initialized
INFO - 2024-07-08 15:34:54 --> Language Class Initialized
INFO - 2024-07-08 15:34:54 --> Language Class Initialized
INFO - 2024-07-08 15:34:54 --> Config Class Initialized
INFO - 2024-07-08 15:34:54 --> Loader Class Initialized
INFO - 2024-07-08 15:34:54 --> Helper loaded: url_helper
INFO - 2024-07-08 15:34:54 --> Helper loaded: file_helper
INFO - 2024-07-08 15:34:54 --> Helper loaded: form_helper
INFO - 2024-07-08 15:34:54 --> Helper loaded: my_helper
INFO - 2024-07-08 15:34:54 --> Database Driver Class Initialized
INFO - 2024-07-08 15:34:54 --> Session: Class initialized using 'files' driver.
INFO - 2024-07-08 15:34:54 --> Controller Class Initialized
INFO - 2024-07-08 15:34:55 --> Config Class Initialized
INFO - 2024-07-08 15:34:55 --> Hooks Class Initialized
DEBUG - 2024-07-08 15:34:55 --> UTF-8 Support Enabled
INFO - 2024-07-08 15:34:55 --> Utf8 Class Initialized
INFO - 2024-07-08 15:34:55 --> URI Class Initialized
INFO - 2024-07-08 15:34:55 --> Router Class Initialized
INFO - 2024-07-08 15:34:55 --> Output Class Initialized
INFO - 2024-07-08 15:34:55 --> Security Class Initialized
DEBUG - 2024-07-08 15:34:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-07-08 15:34:55 --> Input Class Initialized
INFO - 2024-07-08 15:34:55 --> Language Class Initialized
INFO - 2024-07-08 15:34:55 --> Language Class Initialized
INFO - 2024-07-08 15:34:55 --> Config Class Initialized
INFO - 2024-07-08 15:34:55 --> Loader Class Initialized
INFO - 2024-07-08 15:34:55 --> Helper loaded: url_helper
INFO - 2024-07-08 15:34:55 --> Helper loaded: file_helper
INFO - 2024-07-08 15:34:55 --> Helper loaded: form_helper
INFO - 2024-07-08 15:34:55 --> Helper loaded: my_helper
INFO - 2024-07-08 15:34:55 --> Database Driver Class Initialized
INFO - 2024-07-08 15:34:55 --> Session: Class initialized using 'files' driver.
INFO - 2024-07-08 15:34:55 --> Controller Class Initialized
INFO - 2024-07-08 15:34:57 --> Config Class Initialized
INFO - 2024-07-08 15:34:57 --> Hooks Class Initialized
DEBUG - 2024-07-08 15:34:57 --> UTF-8 Support Enabled
INFO - 2024-07-08 15:34:57 --> Utf8 Class Initialized
INFO - 2024-07-08 15:34:57 --> URI Class Initialized
INFO - 2024-07-08 15:34:57 --> Router Class Initialized
INFO - 2024-07-08 15:34:57 --> Output Class Initialized
INFO - 2024-07-08 15:34:57 --> Security Class Initialized
DEBUG - 2024-07-08 15:34:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-07-08 15:34:57 --> Input Class Initialized
INFO - 2024-07-08 15:34:57 --> Language Class Initialized
INFO - 2024-07-08 15:34:57 --> Language Class Initialized
INFO - 2024-07-08 15:34:57 --> Config Class Initialized
INFO - 2024-07-08 15:34:57 --> Loader Class Initialized
INFO - 2024-07-08 15:34:57 --> Helper loaded: url_helper
INFO - 2024-07-08 15:34:57 --> Helper loaded: file_helper
INFO - 2024-07-08 15:34:57 --> Helper loaded: form_helper
INFO - 2024-07-08 15:34:57 --> Helper loaded: my_helper
INFO - 2024-07-08 15:34:57 --> Database Driver Class Initialized
INFO - 2024-07-08 15:34:57 --> Session: Class initialized using 'files' driver.
INFO - 2024-07-08 15:34:57 --> Controller Class Initialized
INFO - 2024-07-08 15:34:57 --> Final output sent to browser
DEBUG - 2024-07-08 15:34:57 --> Total execution time: 0.0983
INFO - 2024-07-08 15:34:57 --> Config Class Initialized
INFO - 2024-07-08 15:34:57 --> Hooks Class Initialized
DEBUG - 2024-07-08 15:34:57 --> UTF-8 Support Enabled
INFO - 2024-07-08 15:34:57 --> Utf8 Class Initialized
INFO - 2024-07-08 15:34:57 --> URI Class Initialized
INFO - 2024-07-08 15:34:57 --> Router Class Initialized
INFO - 2024-07-08 15:34:57 --> Output Class Initialized
INFO - 2024-07-08 15:34:57 --> Security Class Initialized
DEBUG - 2024-07-08 15:34:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-07-08 15:34:57 --> Input Class Initialized
INFO - 2024-07-08 15:34:57 --> Language Class Initialized
ERROR - 2024-07-08 15:34:57 --> 404 Page Not Found: /index
INFO - 2024-07-08 15:34:58 --> Config Class Initialized
INFO - 2024-07-08 15:34:58 --> Hooks Class Initialized
DEBUG - 2024-07-08 15:34:58 --> UTF-8 Support Enabled
INFO - 2024-07-08 15:34:58 --> Utf8 Class Initialized
INFO - 2024-07-08 15:34:58 --> URI Class Initialized
INFO - 2024-07-08 15:34:58 --> Router Class Initialized
INFO - 2024-07-08 15:34:58 --> Output Class Initialized
INFO - 2024-07-08 15:34:58 --> Security Class Initialized
DEBUG - 2024-07-08 15:34:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-07-08 15:34:58 --> Input Class Initialized
INFO - 2024-07-08 15:34:58 --> Language Class Initialized
INFO - 2024-07-08 15:34:58 --> Language Class Initialized
INFO - 2024-07-08 15:34:58 --> Config Class Initialized
INFO - 2024-07-08 15:34:58 --> Loader Class Initialized
INFO - 2024-07-08 15:34:58 --> Helper loaded: url_helper
INFO - 2024-07-08 15:34:58 --> Helper loaded: file_helper
INFO - 2024-07-08 15:34:58 --> Helper loaded: form_helper
INFO - 2024-07-08 15:34:58 --> Helper loaded: my_helper
INFO - 2024-07-08 15:34:58 --> Database Driver Class Initialized
INFO - 2024-07-08 15:34:58 --> Session: Class initialized using 'files' driver.
INFO - 2024-07-08 15:34:58 --> Controller Class Initialized
INFO - 2024-07-08 15:35:00 --> Config Class Initialized
INFO - 2024-07-08 15:35:00 --> Hooks Class Initialized
DEBUG - 2024-07-08 15:35:00 --> UTF-8 Support Enabled
INFO - 2024-07-08 15:35:00 --> Utf8 Class Initialized
INFO - 2024-07-08 15:35:00 --> URI Class Initialized
INFO - 2024-07-08 15:35:00 --> Router Class Initialized
INFO - 2024-07-08 15:35:00 --> Output Class Initialized
INFO - 2024-07-08 15:35:00 --> Security Class Initialized
DEBUG - 2024-07-08 15:35:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-07-08 15:35:00 --> Input Class Initialized
INFO - 2024-07-08 15:35:00 --> Language Class Initialized
INFO - 2024-07-08 15:35:00 --> Language Class Initialized
INFO - 2024-07-08 15:35:00 --> Config Class Initialized
INFO - 2024-07-08 15:35:00 --> Loader Class Initialized
INFO - 2024-07-08 15:35:00 --> Helper loaded: url_helper
INFO - 2024-07-08 15:35:00 --> Helper loaded: file_helper
INFO - 2024-07-08 15:35:00 --> Helper loaded: form_helper
INFO - 2024-07-08 15:35:00 --> Helper loaded: my_helper
INFO - 2024-07-08 15:35:00 --> Database Driver Class Initialized
INFO - 2024-07-08 15:35:00 --> Session: Class initialized using 'files' driver.
INFO - 2024-07-08 15:35:00 --> Controller Class Initialized
INFO - 2024-07-08 15:35:03 --> Config Class Initialized
INFO - 2024-07-08 15:35:03 --> Hooks Class Initialized
DEBUG - 2024-07-08 15:35:03 --> UTF-8 Support Enabled
INFO - 2024-07-08 15:35:03 --> Utf8 Class Initialized
INFO - 2024-07-08 15:35:03 --> URI Class Initialized
INFO - 2024-07-08 15:35:03 --> Router Class Initialized
INFO - 2024-07-08 15:35:03 --> Output Class Initialized
INFO - 2024-07-08 15:35:03 --> Security Class Initialized
DEBUG - 2024-07-08 15:35:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-07-08 15:35:03 --> Input Class Initialized
INFO - 2024-07-08 15:35:03 --> Language Class Initialized
INFO - 2024-07-08 15:35:03 --> Language Class Initialized
INFO - 2024-07-08 15:35:03 --> Config Class Initialized
INFO - 2024-07-08 15:35:03 --> Loader Class Initialized
INFO - 2024-07-08 15:35:03 --> Helper loaded: url_helper
INFO - 2024-07-08 15:35:03 --> Helper loaded: file_helper
INFO - 2024-07-08 15:35:03 --> Helper loaded: form_helper
INFO - 2024-07-08 15:35:03 --> Helper loaded: my_helper
INFO - 2024-07-08 15:35:03 --> Database Driver Class Initialized
INFO - 2024-07-08 15:35:03 --> Session: Class initialized using 'files' driver.
INFO - 2024-07-08 15:35:03 --> Controller Class Initialized
INFO - 2024-07-08 15:35:03 --> Final output sent to browser
DEBUG - 2024-07-08 15:35:03 --> Total execution time: 0.0434
INFO - 2024-07-08 15:35:03 --> Config Class Initialized
INFO - 2024-07-08 15:35:03 --> Hooks Class Initialized
DEBUG - 2024-07-08 15:35:03 --> UTF-8 Support Enabled
INFO - 2024-07-08 15:35:03 --> Utf8 Class Initialized
INFO - 2024-07-08 15:35:03 --> URI Class Initialized
INFO - 2024-07-08 15:35:03 --> Router Class Initialized
INFO - 2024-07-08 15:35:03 --> Output Class Initialized
INFO - 2024-07-08 15:35:03 --> Security Class Initialized
DEBUG - 2024-07-08 15:35:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-07-08 15:35:03 --> Input Class Initialized
INFO - 2024-07-08 15:35:03 --> Language Class Initialized
ERROR - 2024-07-08 15:35:03 --> 404 Page Not Found: /index
INFO - 2024-07-08 15:35:03 --> Config Class Initialized
INFO - 2024-07-08 15:35:03 --> Hooks Class Initialized
DEBUG - 2024-07-08 15:35:03 --> UTF-8 Support Enabled
INFO - 2024-07-08 15:35:03 --> Utf8 Class Initialized
INFO - 2024-07-08 15:35:03 --> URI Class Initialized
INFO - 2024-07-08 15:35:03 --> Router Class Initialized
INFO - 2024-07-08 15:35:03 --> Output Class Initialized
INFO - 2024-07-08 15:35:03 --> Security Class Initialized
DEBUG - 2024-07-08 15:35:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-07-08 15:35:03 --> Input Class Initialized
INFO - 2024-07-08 15:35:03 --> Language Class Initialized
INFO - 2024-07-08 15:35:03 --> Language Class Initialized
INFO - 2024-07-08 15:35:03 --> Config Class Initialized
INFO - 2024-07-08 15:35:03 --> Loader Class Initialized
INFO - 2024-07-08 15:35:03 --> Helper loaded: url_helper
INFO - 2024-07-08 15:35:03 --> Helper loaded: file_helper
INFO - 2024-07-08 15:35:03 --> Helper loaded: form_helper
INFO - 2024-07-08 15:35:03 --> Helper loaded: my_helper
INFO - 2024-07-08 15:35:03 --> Database Driver Class Initialized
INFO - 2024-07-08 15:35:03 --> Session: Class initialized using 'files' driver.
INFO - 2024-07-08 15:35:03 --> Controller Class Initialized
INFO - 2024-07-08 15:35:06 --> Config Class Initialized
INFO - 2024-07-08 15:35:06 --> Hooks Class Initialized
DEBUG - 2024-07-08 15:35:06 --> UTF-8 Support Enabled
INFO - 2024-07-08 15:35:06 --> Utf8 Class Initialized
INFO - 2024-07-08 15:35:06 --> URI Class Initialized
INFO - 2024-07-08 15:35:06 --> Router Class Initialized
INFO - 2024-07-08 15:35:06 --> Output Class Initialized
INFO - 2024-07-08 15:35:06 --> Security Class Initialized
DEBUG - 2024-07-08 15:35:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-07-08 15:35:06 --> Input Class Initialized
INFO - 2024-07-08 15:35:06 --> Language Class Initialized
INFO - 2024-07-08 15:35:06 --> Language Class Initialized
INFO - 2024-07-08 15:35:06 --> Config Class Initialized
INFO - 2024-07-08 15:35:06 --> Loader Class Initialized
INFO - 2024-07-08 15:35:06 --> Helper loaded: url_helper
INFO - 2024-07-08 15:35:06 --> Helper loaded: file_helper
INFO - 2024-07-08 15:35:06 --> Helper loaded: form_helper
INFO - 2024-07-08 15:35:06 --> Helper loaded: my_helper
INFO - 2024-07-08 15:35:06 --> Database Driver Class Initialized
INFO - 2024-07-08 15:35:06 --> Session: Class initialized using 'files' driver.
INFO - 2024-07-08 15:35:06 --> Controller Class Initialized
INFO - 2024-07-08 15:35:09 --> Config Class Initialized
INFO - 2024-07-08 15:35:09 --> Hooks Class Initialized
DEBUG - 2024-07-08 15:35:09 --> UTF-8 Support Enabled
INFO - 2024-07-08 15:35:09 --> Utf8 Class Initialized
INFO - 2024-07-08 15:35:09 --> URI Class Initialized
INFO - 2024-07-08 15:35:09 --> Router Class Initialized
INFO - 2024-07-08 15:35:09 --> Output Class Initialized
INFO - 2024-07-08 15:35:09 --> Security Class Initialized
DEBUG - 2024-07-08 15:35:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-07-08 15:35:09 --> Input Class Initialized
INFO - 2024-07-08 15:35:09 --> Language Class Initialized
INFO - 2024-07-08 15:35:09 --> Language Class Initialized
INFO - 2024-07-08 15:35:09 --> Config Class Initialized
INFO - 2024-07-08 15:35:09 --> Loader Class Initialized
INFO - 2024-07-08 15:35:09 --> Helper loaded: url_helper
INFO - 2024-07-08 15:35:09 --> Helper loaded: file_helper
INFO - 2024-07-08 15:35:09 --> Helper loaded: form_helper
INFO - 2024-07-08 15:35:09 --> Helper loaded: my_helper
INFO - 2024-07-08 15:35:09 --> Database Driver Class Initialized
INFO - 2024-07-08 15:35:09 --> Session: Class initialized using 'files' driver.
INFO - 2024-07-08 15:35:09 --> Controller Class Initialized
INFO - 2024-07-08 15:35:09 --> Final output sent to browser
DEBUG - 2024-07-08 15:35:09 --> Total execution time: 0.0305
INFO - 2024-07-08 15:35:09 --> Config Class Initialized
INFO - 2024-07-08 15:35:09 --> Hooks Class Initialized
DEBUG - 2024-07-08 15:35:09 --> UTF-8 Support Enabled
INFO - 2024-07-08 15:35:09 --> Utf8 Class Initialized
INFO - 2024-07-08 15:35:09 --> URI Class Initialized
INFO - 2024-07-08 15:35:09 --> Router Class Initialized
INFO - 2024-07-08 15:35:09 --> Output Class Initialized
INFO - 2024-07-08 15:35:09 --> Security Class Initialized
DEBUG - 2024-07-08 15:35:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-07-08 15:35:09 --> Input Class Initialized
INFO - 2024-07-08 15:35:09 --> Language Class Initialized
ERROR - 2024-07-08 15:35:09 --> 404 Page Not Found: /index
INFO - 2024-07-08 15:35:09 --> Config Class Initialized
INFO - 2024-07-08 15:35:09 --> Hooks Class Initialized
DEBUG - 2024-07-08 15:35:09 --> UTF-8 Support Enabled
INFO - 2024-07-08 15:35:09 --> Utf8 Class Initialized
INFO - 2024-07-08 15:35:09 --> URI Class Initialized
INFO - 2024-07-08 15:35:09 --> Router Class Initialized
INFO - 2024-07-08 15:35:09 --> Output Class Initialized
INFO - 2024-07-08 15:35:09 --> Security Class Initialized
DEBUG - 2024-07-08 15:35:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-07-08 15:35:09 --> Input Class Initialized
INFO - 2024-07-08 15:35:09 --> Language Class Initialized
INFO - 2024-07-08 15:35:09 --> Language Class Initialized
INFO - 2024-07-08 15:35:09 --> Config Class Initialized
INFO - 2024-07-08 15:35:09 --> Loader Class Initialized
INFO - 2024-07-08 15:35:09 --> Helper loaded: url_helper
INFO - 2024-07-08 15:35:09 --> Helper loaded: file_helper
INFO - 2024-07-08 15:35:09 --> Helper loaded: form_helper
INFO - 2024-07-08 15:35:09 --> Helper loaded: my_helper
INFO - 2024-07-08 15:35:09 --> Database Driver Class Initialized
INFO - 2024-07-08 15:35:09 --> Session: Class initialized using 'files' driver.
INFO - 2024-07-08 15:35:09 --> Controller Class Initialized
INFO - 2024-07-08 15:35:11 --> Config Class Initialized
INFO - 2024-07-08 15:35:11 --> Hooks Class Initialized
DEBUG - 2024-07-08 15:35:11 --> UTF-8 Support Enabled
INFO - 2024-07-08 15:35:11 --> Utf8 Class Initialized
INFO - 2024-07-08 15:35:11 --> URI Class Initialized
INFO - 2024-07-08 15:35:11 --> Router Class Initialized
INFO - 2024-07-08 15:35:11 --> Output Class Initialized
INFO - 2024-07-08 15:35:11 --> Security Class Initialized
DEBUG - 2024-07-08 15:35:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-07-08 15:35:11 --> Input Class Initialized
INFO - 2024-07-08 15:35:11 --> Language Class Initialized
INFO - 2024-07-08 15:35:11 --> Language Class Initialized
INFO - 2024-07-08 15:35:11 --> Config Class Initialized
INFO - 2024-07-08 15:35:11 --> Loader Class Initialized
INFO - 2024-07-08 15:35:12 --> Helper loaded: url_helper
INFO - 2024-07-08 15:35:12 --> Helper loaded: file_helper
INFO - 2024-07-08 15:35:12 --> Helper loaded: form_helper
INFO - 2024-07-08 15:35:12 --> Helper loaded: my_helper
INFO - 2024-07-08 15:35:12 --> Database Driver Class Initialized
INFO - 2024-07-08 15:35:12 --> Session: Class initialized using 'files' driver.
INFO - 2024-07-08 15:35:12 --> Controller Class Initialized
INFO - 2024-07-08 15:35:14 --> Config Class Initialized
INFO - 2024-07-08 15:35:14 --> Hooks Class Initialized
DEBUG - 2024-07-08 15:35:14 --> UTF-8 Support Enabled
INFO - 2024-07-08 15:35:14 --> Utf8 Class Initialized
INFO - 2024-07-08 15:35:14 --> URI Class Initialized
INFO - 2024-07-08 15:35:14 --> Router Class Initialized
INFO - 2024-07-08 15:35:14 --> Output Class Initialized
INFO - 2024-07-08 15:35:14 --> Security Class Initialized
DEBUG - 2024-07-08 15:35:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-07-08 15:35:14 --> Input Class Initialized
INFO - 2024-07-08 15:35:14 --> Language Class Initialized
INFO - 2024-07-08 15:35:14 --> Language Class Initialized
INFO - 2024-07-08 15:35:14 --> Config Class Initialized
INFO - 2024-07-08 15:35:14 --> Loader Class Initialized
INFO - 2024-07-08 15:35:14 --> Helper loaded: url_helper
INFO - 2024-07-08 15:35:14 --> Helper loaded: file_helper
INFO - 2024-07-08 15:35:14 --> Helper loaded: form_helper
INFO - 2024-07-08 15:35:14 --> Helper loaded: my_helper
INFO - 2024-07-08 15:35:14 --> Database Driver Class Initialized
INFO - 2024-07-08 15:35:14 --> Session: Class initialized using 'files' driver.
INFO - 2024-07-08 15:35:14 --> Controller Class Initialized
INFO - 2024-07-08 15:35:14 --> Final output sent to browser
DEBUG - 2024-07-08 15:35:14 --> Total execution time: 0.0410
INFO - 2024-07-08 15:35:14 --> Config Class Initialized
INFO - 2024-07-08 15:35:14 --> Hooks Class Initialized
DEBUG - 2024-07-08 15:35:14 --> UTF-8 Support Enabled
INFO - 2024-07-08 15:35:14 --> Utf8 Class Initialized
INFO - 2024-07-08 15:35:14 --> URI Class Initialized
INFO - 2024-07-08 15:35:14 --> Router Class Initialized
INFO - 2024-07-08 15:35:14 --> Output Class Initialized
INFO - 2024-07-08 15:35:14 --> Security Class Initialized
DEBUG - 2024-07-08 15:35:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-07-08 15:35:14 --> Input Class Initialized
INFO - 2024-07-08 15:35:14 --> Language Class Initialized
ERROR - 2024-07-08 15:35:14 --> 404 Page Not Found: /index
INFO - 2024-07-08 15:35:14 --> Config Class Initialized
INFO - 2024-07-08 15:35:14 --> Hooks Class Initialized
DEBUG - 2024-07-08 15:35:14 --> UTF-8 Support Enabled
INFO - 2024-07-08 15:35:14 --> Utf8 Class Initialized
INFO - 2024-07-08 15:35:14 --> URI Class Initialized
INFO - 2024-07-08 15:35:14 --> Router Class Initialized
INFO - 2024-07-08 15:35:14 --> Output Class Initialized
INFO - 2024-07-08 15:35:14 --> Security Class Initialized
DEBUG - 2024-07-08 15:35:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-07-08 15:35:14 --> Input Class Initialized
INFO - 2024-07-08 15:35:14 --> Language Class Initialized
INFO - 2024-07-08 15:35:14 --> Language Class Initialized
INFO - 2024-07-08 15:35:14 --> Config Class Initialized
INFO - 2024-07-08 15:35:14 --> Loader Class Initialized
INFO - 2024-07-08 15:35:14 --> Helper loaded: url_helper
INFO - 2024-07-08 15:35:14 --> Helper loaded: file_helper
INFO - 2024-07-08 15:35:14 --> Helper loaded: form_helper
INFO - 2024-07-08 15:35:14 --> Helper loaded: my_helper
INFO - 2024-07-08 15:35:14 --> Database Driver Class Initialized
INFO - 2024-07-08 15:35:14 --> Session: Class initialized using 'files' driver.
INFO - 2024-07-08 15:35:14 --> Controller Class Initialized
INFO - 2024-07-08 15:35:17 --> Config Class Initialized
INFO - 2024-07-08 15:35:17 --> Hooks Class Initialized
DEBUG - 2024-07-08 15:35:17 --> UTF-8 Support Enabled
INFO - 2024-07-08 15:35:17 --> Utf8 Class Initialized
INFO - 2024-07-08 15:35:17 --> URI Class Initialized
INFO - 2024-07-08 15:35:17 --> Router Class Initialized
INFO - 2024-07-08 15:35:17 --> Output Class Initialized
INFO - 2024-07-08 15:35:17 --> Security Class Initialized
DEBUG - 2024-07-08 15:35:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-07-08 15:35:17 --> Input Class Initialized
INFO - 2024-07-08 15:35:17 --> Language Class Initialized
INFO - 2024-07-08 15:35:17 --> Language Class Initialized
INFO - 2024-07-08 15:35:17 --> Config Class Initialized
INFO - 2024-07-08 15:35:17 --> Loader Class Initialized
INFO - 2024-07-08 15:35:17 --> Helper loaded: url_helper
INFO - 2024-07-08 15:35:17 --> Helper loaded: file_helper
INFO - 2024-07-08 15:35:17 --> Helper loaded: form_helper
INFO - 2024-07-08 15:35:17 --> Helper loaded: my_helper
INFO - 2024-07-08 15:35:17 --> Database Driver Class Initialized
INFO - 2024-07-08 15:35:17 --> Session: Class initialized using 'files' driver.
INFO - 2024-07-08 15:35:17 --> Controller Class Initialized
INFO - 2024-07-08 15:35:19 --> Config Class Initialized
INFO - 2024-07-08 15:35:19 --> Hooks Class Initialized
DEBUG - 2024-07-08 15:35:19 --> UTF-8 Support Enabled
INFO - 2024-07-08 15:35:19 --> Utf8 Class Initialized
INFO - 2024-07-08 15:35:19 --> URI Class Initialized
INFO - 2024-07-08 15:35:19 --> Router Class Initialized
INFO - 2024-07-08 15:35:19 --> Output Class Initialized
INFO - 2024-07-08 15:35:19 --> Security Class Initialized
DEBUG - 2024-07-08 15:35:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-07-08 15:35:19 --> Input Class Initialized
INFO - 2024-07-08 15:35:19 --> Language Class Initialized
INFO - 2024-07-08 15:35:19 --> Language Class Initialized
INFO - 2024-07-08 15:35:19 --> Config Class Initialized
INFO - 2024-07-08 15:35:19 --> Loader Class Initialized
INFO - 2024-07-08 15:35:19 --> Helper loaded: url_helper
INFO - 2024-07-08 15:35:19 --> Helper loaded: file_helper
INFO - 2024-07-08 15:35:19 --> Helper loaded: form_helper
INFO - 2024-07-08 15:35:19 --> Helper loaded: my_helper
INFO - 2024-07-08 15:35:19 --> Database Driver Class Initialized
INFO - 2024-07-08 15:35:19 --> Session: Class initialized using 'files' driver.
INFO - 2024-07-08 15:35:19 --> Controller Class Initialized
INFO - 2024-07-08 15:35:21 --> Config Class Initialized
INFO - 2024-07-08 15:35:21 --> Hooks Class Initialized
DEBUG - 2024-07-08 15:35:21 --> UTF-8 Support Enabled
INFO - 2024-07-08 15:35:21 --> Utf8 Class Initialized
INFO - 2024-07-08 15:35:21 --> URI Class Initialized
INFO - 2024-07-08 15:35:21 --> Router Class Initialized
INFO - 2024-07-08 15:35:21 --> Output Class Initialized
INFO - 2024-07-08 15:35:21 --> Security Class Initialized
DEBUG - 2024-07-08 15:35:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-07-08 15:35:21 --> Input Class Initialized
INFO - 2024-07-08 15:35:21 --> Language Class Initialized
INFO - 2024-07-08 15:35:21 --> Language Class Initialized
INFO - 2024-07-08 15:35:21 --> Config Class Initialized
INFO - 2024-07-08 15:35:21 --> Loader Class Initialized
INFO - 2024-07-08 15:35:21 --> Helper loaded: url_helper
INFO - 2024-07-08 15:35:21 --> Helper loaded: file_helper
INFO - 2024-07-08 15:35:21 --> Helper loaded: form_helper
INFO - 2024-07-08 15:35:21 --> Helper loaded: my_helper
INFO - 2024-07-08 15:35:21 --> Database Driver Class Initialized
INFO - 2024-07-08 15:35:21 --> Session: Class initialized using 'files' driver.
INFO - 2024-07-08 15:35:21 --> Controller Class Initialized
INFO - 2024-07-08 15:35:23 --> Config Class Initialized
INFO - 2024-07-08 15:35:23 --> Hooks Class Initialized
DEBUG - 2024-07-08 15:35:23 --> UTF-8 Support Enabled
INFO - 2024-07-08 15:35:23 --> Utf8 Class Initialized
INFO - 2024-07-08 15:35:23 --> URI Class Initialized
INFO - 2024-07-08 15:35:23 --> Router Class Initialized
INFO - 2024-07-08 15:35:23 --> Output Class Initialized
INFO - 2024-07-08 15:35:23 --> Security Class Initialized
DEBUG - 2024-07-08 15:35:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-07-08 15:35:23 --> Input Class Initialized
INFO - 2024-07-08 15:35:23 --> Language Class Initialized
INFO - 2024-07-08 15:35:23 --> Language Class Initialized
INFO - 2024-07-08 15:35:23 --> Config Class Initialized
INFO - 2024-07-08 15:35:23 --> Loader Class Initialized
INFO - 2024-07-08 15:35:23 --> Helper loaded: url_helper
INFO - 2024-07-08 15:35:23 --> Helper loaded: file_helper
INFO - 2024-07-08 15:35:23 --> Helper loaded: form_helper
INFO - 2024-07-08 15:35:23 --> Helper loaded: my_helper
INFO - 2024-07-08 15:35:23 --> Database Driver Class Initialized
INFO - 2024-07-08 15:35:23 --> Session: Class initialized using 'files' driver.
INFO - 2024-07-08 15:35:23 --> Controller Class Initialized
INFO - 2024-07-08 15:35:25 --> Config Class Initialized
INFO - 2024-07-08 15:35:25 --> Hooks Class Initialized
DEBUG - 2024-07-08 15:35:25 --> UTF-8 Support Enabled
INFO - 2024-07-08 15:35:25 --> Utf8 Class Initialized
INFO - 2024-07-08 15:35:25 --> URI Class Initialized
INFO - 2024-07-08 15:35:25 --> Router Class Initialized
INFO - 2024-07-08 15:35:25 --> Output Class Initialized
INFO - 2024-07-08 15:35:25 --> Security Class Initialized
DEBUG - 2024-07-08 15:35:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-07-08 15:35:25 --> Input Class Initialized
INFO - 2024-07-08 15:35:25 --> Language Class Initialized
INFO - 2024-07-08 15:35:25 --> Language Class Initialized
INFO - 2024-07-08 15:35:25 --> Config Class Initialized
INFO - 2024-07-08 15:35:25 --> Loader Class Initialized
INFO - 2024-07-08 15:35:25 --> Helper loaded: url_helper
INFO - 2024-07-08 15:35:25 --> Helper loaded: file_helper
INFO - 2024-07-08 15:35:25 --> Helper loaded: form_helper
INFO - 2024-07-08 15:35:25 --> Helper loaded: my_helper
INFO - 2024-07-08 15:35:25 --> Database Driver Class Initialized
INFO - 2024-07-08 15:35:25 --> Session: Class initialized using 'files' driver.
INFO - 2024-07-08 15:35:25 --> Controller Class Initialized
INFO - 2024-07-08 15:35:46 --> Config Class Initialized
INFO - 2024-07-08 15:35:46 --> Hooks Class Initialized
DEBUG - 2024-07-08 15:35:46 --> UTF-8 Support Enabled
INFO - 2024-07-08 15:35:46 --> Utf8 Class Initialized
INFO - 2024-07-08 15:35:46 --> URI Class Initialized
INFO - 2024-07-08 15:35:46 --> Router Class Initialized
INFO - 2024-07-08 15:35:46 --> Output Class Initialized
INFO - 2024-07-08 15:35:46 --> Security Class Initialized
DEBUG - 2024-07-08 15:35:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-07-08 15:35:46 --> Input Class Initialized
INFO - 2024-07-08 15:35:46 --> Language Class Initialized
INFO - 2024-07-08 15:35:46 --> Language Class Initialized
INFO - 2024-07-08 15:35:46 --> Config Class Initialized
INFO - 2024-07-08 15:35:46 --> Loader Class Initialized
INFO - 2024-07-08 15:35:46 --> Helper loaded: url_helper
INFO - 2024-07-08 15:35:46 --> Helper loaded: file_helper
INFO - 2024-07-08 15:35:46 --> Helper loaded: form_helper
INFO - 2024-07-08 15:35:46 --> Helper loaded: my_helper
INFO - 2024-07-08 15:35:46 --> Database Driver Class Initialized
INFO - 2024-07-08 15:35:46 --> Session: Class initialized using 'files' driver.
INFO - 2024-07-08 15:35:46 --> Controller Class Initialized
DEBUG - 2024-07-08 15:35:46 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/set_kelas/views/list.php
DEBUG - 2024-07-08 15:35:46 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-07-08 15:35:46 --> Final output sent to browser
DEBUG - 2024-07-08 15:35:46 --> Total execution time: 0.1073
INFO - 2024-07-08 15:36:01 --> Config Class Initialized
INFO - 2024-07-08 15:36:01 --> Hooks Class Initialized
DEBUG - 2024-07-08 15:36:01 --> UTF-8 Support Enabled
INFO - 2024-07-08 15:36:01 --> Utf8 Class Initialized
INFO - 2024-07-08 15:36:01 --> URI Class Initialized
INFO - 2024-07-08 15:36:01 --> Router Class Initialized
INFO - 2024-07-08 15:36:01 --> Output Class Initialized
INFO - 2024-07-08 15:36:01 --> Security Class Initialized
DEBUG - 2024-07-08 15:36:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-07-08 15:36:01 --> Input Class Initialized
INFO - 2024-07-08 15:36:01 --> Language Class Initialized
INFO - 2024-07-08 15:36:01 --> Language Class Initialized
INFO - 2024-07-08 15:36:01 --> Config Class Initialized
INFO - 2024-07-08 15:36:01 --> Loader Class Initialized
INFO - 2024-07-08 15:36:01 --> Helper loaded: url_helper
INFO - 2024-07-08 15:36:01 --> Helper loaded: file_helper
INFO - 2024-07-08 15:36:01 --> Helper loaded: form_helper
INFO - 2024-07-08 15:36:01 --> Helper loaded: my_helper
INFO - 2024-07-08 15:36:01 --> Database Driver Class Initialized
INFO - 2024-07-08 15:36:01 --> Session: Class initialized using 'files' driver.
INFO - 2024-07-08 15:36:01 --> Controller Class Initialized
DEBUG - 2024-07-08 15:36:01 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/set_kelas/views/list.php
DEBUG - 2024-07-08 15:36:01 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-07-08 15:36:01 --> Final output sent to browser
DEBUG - 2024-07-08 15:36:01 --> Total execution time: 0.0967
INFO - 2024-07-08 15:36:11 --> Config Class Initialized
INFO - 2024-07-08 15:36:11 --> Hooks Class Initialized
DEBUG - 2024-07-08 15:36:11 --> UTF-8 Support Enabled
INFO - 2024-07-08 15:36:11 --> Utf8 Class Initialized
INFO - 2024-07-08 15:36:11 --> URI Class Initialized
INFO - 2024-07-08 15:36:11 --> Router Class Initialized
INFO - 2024-07-08 15:36:11 --> Output Class Initialized
INFO - 2024-07-08 15:36:11 --> Security Class Initialized
DEBUG - 2024-07-08 15:36:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-07-08 15:36:11 --> Input Class Initialized
INFO - 2024-07-08 15:36:11 --> Language Class Initialized
INFO - 2024-07-08 15:36:11 --> Language Class Initialized
INFO - 2024-07-08 15:36:11 --> Config Class Initialized
INFO - 2024-07-08 15:36:11 --> Loader Class Initialized
INFO - 2024-07-08 15:36:11 --> Helper loaded: url_helper
INFO - 2024-07-08 15:36:11 --> Helper loaded: file_helper
INFO - 2024-07-08 15:36:11 --> Helper loaded: form_helper
INFO - 2024-07-08 15:36:11 --> Helper loaded: my_helper
INFO - 2024-07-08 15:36:11 --> Database Driver Class Initialized
INFO - 2024-07-08 15:36:11 --> Session: Class initialized using 'files' driver.
INFO - 2024-07-08 15:36:11 --> Controller Class Initialized
DEBUG - 2024-07-08 15:36:11 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/data_mapel/views/list.php
DEBUG - 2024-07-08 15:36:11 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-07-08 15:36:11 --> Final output sent to browser
DEBUG - 2024-07-08 15:36:11 --> Total execution time: 0.0801
INFO - 2024-07-08 15:36:11 --> Config Class Initialized
INFO - 2024-07-08 15:36:11 --> Hooks Class Initialized
DEBUG - 2024-07-08 15:36:11 --> UTF-8 Support Enabled
INFO - 2024-07-08 15:36:11 --> Utf8 Class Initialized
INFO - 2024-07-08 15:36:11 --> URI Class Initialized
INFO - 2024-07-08 15:36:11 --> Router Class Initialized
INFO - 2024-07-08 15:36:11 --> Output Class Initialized
INFO - 2024-07-08 15:36:11 --> Security Class Initialized
DEBUG - 2024-07-08 15:36:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-07-08 15:36:11 --> Input Class Initialized
INFO - 2024-07-08 15:36:11 --> Language Class Initialized
ERROR - 2024-07-08 15:36:11 --> 404 Page Not Found: /index
INFO - 2024-07-08 15:36:11 --> Config Class Initialized
INFO - 2024-07-08 15:36:11 --> Hooks Class Initialized
DEBUG - 2024-07-08 15:36:11 --> UTF-8 Support Enabled
INFO - 2024-07-08 15:36:11 --> Utf8 Class Initialized
INFO - 2024-07-08 15:36:11 --> URI Class Initialized
INFO - 2024-07-08 15:36:11 --> Router Class Initialized
INFO - 2024-07-08 15:36:11 --> Output Class Initialized
INFO - 2024-07-08 15:36:11 --> Security Class Initialized
DEBUG - 2024-07-08 15:36:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-07-08 15:36:11 --> Input Class Initialized
INFO - 2024-07-08 15:36:11 --> Language Class Initialized
INFO - 2024-07-08 15:36:11 --> Language Class Initialized
INFO - 2024-07-08 15:36:11 --> Config Class Initialized
INFO - 2024-07-08 15:36:11 --> Loader Class Initialized
INFO - 2024-07-08 15:36:11 --> Helper loaded: url_helper
INFO - 2024-07-08 15:36:11 --> Helper loaded: file_helper
INFO - 2024-07-08 15:36:11 --> Helper loaded: form_helper
INFO - 2024-07-08 15:36:11 --> Helper loaded: my_helper
INFO - 2024-07-08 15:36:11 --> Database Driver Class Initialized
INFO - 2024-07-08 15:36:11 --> Session: Class initialized using 'files' driver.
INFO - 2024-07-08 15:36:11 --> Controller Class Initialized
INFO - 2024-07-08 15:36:12 --> Config Class Initialized
INFO - 2024-07-08 15:36:12 --> Hooks Class Initialized
DEBUG - 2024-07-08 15:36:12 --> UTF-8 Support Enabled
INFO - 2024-07-08 15:36:12 --> Utf8 Class Initialized
INFO - 2024-07-08 15:36:12 --> URI Class Initialized
INFO - 2024-07-08 15:36:12 --> Router Class Initialized
INFO - 2024-07-08 15:36:12 --> Output Class Initialized
INFO - 2024-07-08 15:36:12 --> Security Class Initialized
DEBUG - 2024-07-08 15:36:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-07-08 15:36:12 --> Input Class Initialized
INFO - 2024-07-08 15:36:12 --> Language Class Initialized
INFO - 2024-07-08 15:36:12 --> Language Class Initialized
INFO - 2024-07-08 15:36:12 --> Config Class Initialized
INFO - 2024-07-08 15:36:12 --> Loader Class Initialized
INFO - 2024-07-08 15:36:12 --> Helper loaded: url_helper
INFO - 2024-07-08 15:36:12 --> Helper loaded: file_helper
INFO - 2024-07-08 15:36:12 --> Helper loaded: form_helper
INFO - 2024-07-08 15:36:12 --> Helper loaded: my_helper
INFO - 2024-07-08 15:36:12 --> Database Driver Class Initialized
INFO - 2024-07-08 15:36:12 --> Session: Class initialized using 'files' driver.
INFO - 2024-07-08 15:36:12 --> Controller Class Initialized
DEBUG - 2024-07-08 15:36:12 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/data_kelas/views/list.php
DEBUG - 2024-07-08 15:36:12 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-07-08 15:36:12 --> Final output sent to browser
DEBUG - 2024-07-08 15:36:12 --> Total execution time: 0.0868
INFO - 2024-07-08 15:36:12 --> Config Class Initialized
INFO - 2024-07-08 15:36:12 --> Hooks Class Initialized
DEBUG - 2024-07-08 15:36:12 --> UTF-8 Support Enabled
INFO - 2024-07-08 15:36:12 --> Utf8 Class Initialized
INFO - 2024-07-08 15:36:12 --> URI Class Initialized
INFO - 2024-07-08 15:36:12 --> Router Class Initialized
INFO - 2024-07-08 15:36:12 --> Output Class Initialized
INFO - 2024-07-08 15:36:13 --> Security Class Initialized
DEBUG - 2024-07-08 15:36:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-07-08 15:36:13 --> Input Class Initialized
INFO - 2024-07-08 15:36:13 --> Language Class Initialized
ERROR - 2024-07-08 15:36:13 --> 404 Page Not Found: /index
INFO - 2024-07-08 15:36:13 --> Config Class Initialized
INFO - 2024-07-08 15:36:13 --> Hooks Class Initialized
DEBUG - 2024-07-08 15:36:13 --> UTF-8 Support Enabled
INFO - 2024-07-08 15:36:13 --> Utf8 Class Initialized
INFO - 2024-07-08 15:36:13 --> URI Class Initialized
INFO - 2024-07-08 15:36:13 --> Router Class Initialized
INFO - 2024-07-08 15:36:13 --> Output Class Initialized
INFO - 2024-07-08 15:36:13 --> Security Class Initialized
DEBUG - 2024-07-08 15:36:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-07-08 15:36:13 --> Input Class Initialized
INFO - 2024-07-08 15:36:13 --> Language Class Initialized
INFO - 2024-07-08 15:36:13 --> Language Class Initialized
INFO - 2024-07-08 15:36:13 --> Config Class Initialized
INFO - 2024-07-08 15:36:13 --> Loader Class Initialized
INFO - 2024-07-08 15:36:13 --> Helper loaded: url_helper
INFO - 2024-07-08 15:36:13 --> Helper loaded: file_helper
INFO - 2024-07-08 15:36:13 --> Helper loaded: form_helper
INFO - 2024-07-08 15:36:13 --> Helper loaded: my_helper
INFO - 2024-07-08 15:36:13 --> Database Driver Class Initialized
INFO - 2024-07-08 15:36:13 --> Session: Class initialized using 'files' driver.
INFO - 2024-07-08 15:36:13 --> Controller Class Initialized
INFO - 2024-07-08 15:36:15 --> Config Class Initialized
INFO - 2024-07-08 15:36:15 --> Hooks Class Initialized
DEBUG - 2024-07-08 15:36:15 --> UTF-8 Support Enabled
INFO - 2024-07-08 15:36:15 --> Utf8 Class Initialized
INFO - 2024-07-08 15:36:15 --> URI Class Initialized
INFO - 2024-07-08 15:36:15 --> Router Class Initialized
INFO - 2024-07-08 15:36:15 --> Output Class Initialized
INFO - 2024-07-08 15:36:15 --> Security Class Initialized
DEBUG - 2024-07-08 15:36:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-07-08 15:36:15 --> Input Class Initialized
INFO - 2024-07-08 15:36:15 --> Language Class Initialized
INFO - 2024-07-08 15:36:15 --> Language Class Initialized
INFO - 2024-07-08 15:36:15 --> Config Class Initialized
INFO - 2024-07-08 15:36:15 --> Loader Class Initialized
INFO - 2024-07-08 15:36:15 --> Helper loaded: url_helper
INFO - 2024-07-08 15:36:15 --> Helper loaded: file_helper
INFO - 2024-07-08 15:36:15 --> Helper loaded: form_helper
INFO - 2024-07-08 15:36:15 --> Helper loaded: my_helper
INFO - 2024-07-08 15:36:15 --> Database Driver Class Initialized
INFO - 2024-07-08 15:36:15 --> Session: Class initialized using 'files' driver.
INFO - 2024-07-08 15:36:15 --> Controller Class Initialized
DEBUG - 2024-07-08 15:36:15 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/data_siswa/views/list.php
DEBUG - 2024-07-08 15:36:15 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-07-08 15:36:15 --> Final output sent to browser
DEBUG - 2024-07-08 15:36:15 --> Total execution time: 0.0600
INFO - 2024-07-08 15:36:16 --> Config Class Initialized
INFO - 2024-07-08 15:36:16 --> Hooks Class Initialized
DEBUG - 2024-07-08 15:36:16 --> UTF-8 Support Enabled
INFO - 2024-07-08 15:36:16 --> Utf8 Class Initialized
INFO - 2024-07-08 15:36:16 --> URI Class Initialized
INFO - 2024-07-08 15:36:16 --> Router Class Initialized
INFO - 2024-07-08 15:36:16 --> Output Class Initialized
INFO - 2024-07-08 15:36:16 --> Security Class Initialized
DEBUG - 2024-07-08 15:36:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-07-08 15:36:16 --> Input Class Initialized
INFO - 2024-07-08 15:36:16 --> Language Class Initialized
ERROR - 2024-07-08 15:36:16 --> 404 Page Not Found: /index
INFO - 2024-07-08 15:36:16 --> Config Class Initialized
INFO - 2024-07-08 15:36:16 --> Hooks Class Initialized
DEBUG - 2024-07-08 15:36:16 --> UTF-8 Support Enabled
INFO - 2024-07-08 15:36:16 --> Utf8 Class Initialized
INFO - 2024-07-08 15:36:16 --> URI Class Initialized
INFO - 2024-07-08 15:36:16 --> Router Class Initialized
INFO - 2024-07-08 15:36:16 --> Output Class Initialized
INFO - 2024-07-08 15:36:16 --> Security Class Initialized
DEBUG - 2024-07-08 15:36:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-07-08 15:36:16 --> Input Class Initialized
INFO - 2024-07-08 15:36:16 --> Language Class Initialized
INFO - 2024-07-08 15:36:16 --> Language Class Initialized
INFO - 2024-07-08 15:36:16 --> Config Class Initialized
INFO - 2024-07-08 15:36:16 --> Loader Class Initialized
INFO - 2024-07-08 15:36:16 --> Helper loaded: url_helper
INFO - 2024-07-08 15:36:16 --> Helper loaded: file_helper
INFO - 2024-07-08 15:36:16 --> Helper loaded: form_helper
INFO - 2024-07-08 15:36:16 --> Helper loaded: my_helper
INFO - 2024-07-08 15:36:16 --> Database Driver Class Initialized
INFO - 2024-07-08 15:36:16 --> Session: Class initialized using 'files' driver.
INFO - 2024-07-08 15:36:16 --> Controller Class Initialized
INFO - 2024-07-08 15:36:21 --> Config Class Initialized
INFO - 2024-07-08 15:36:21 --> Hooks Class Initialized
DEBUG - 2024-07-08 15:36:21 --> UTF-8 Support Enabled
INFO - 2024-07-08 15:36:21 --> Utf8 Class Initialized
INFO - 2024-07-08 15:36:21 --> URI Class Initialized
INFO - 2024-07-08 15:36:21 --> Router Class Initialized
INFO - 2024-07-08 15:36:21 --> Output Class Initialized
INFO - 2024-07-08 15:36:21 --> Security Class Initialized
DEBUG - 2024-07-08 15:36:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-07-08 15:36:21 --> Input Class Initialized
INFO - 2024-07-08 15:36:21 --> Language Class Initialized
INFO - 2024-07-08 15:36:21 --> Language Class Initialized
INFO - 2024-07-08 15:36:21 --> Config Class Initialized
INFO - 2024-07-08 15:36:21 --> Loader Class Initialized
INFO - 2024-07-08 15:36:21 --> Helper loaded: url_helper
INFO - 2024-07-08 15:36:21 --> Helper loaded: file_helper
INFO - 2024-07-08 15:36:21 --> Helper loaded: form_helper
INFO - 2024-07-08 15:36:21 --> Helper loaded: my_helper
INFO - 2024-07-08 15:36:21 --> Database Driver Class Initialized
INFO - 2024-07-08 15:36:21 --> Session: Class initialized using 'files' driver.
INFO - 2024-07-08 15:36:21 --> Controller Class Initialized
ERROR - 2024-07-08 15:36:21 --> Severity: Notice --> Undefined variable: status_form /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/data_siswa/views/form.php 231
DEBUG - 2024-07-08 15:36:21 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/data_siswa/views/form.php
DEBUG - 2024-07-08 15:36:21 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-07-08 15:36:21 --> Final output sent to browser
DEBUG - 2024-07-08 15:36:21 --> Total execution time: 0.0400
INFO - 2024-07-08 15:36:27 --> Config Class Initialized
INFO - 2024-07-08 15:36:27 --> Hooks Class Initialized
DEBUG - 2024-07-08 15:36:27 --> UTF-8 Support Enabled
INFO - 2024-07-08 15:36:27 --> Utf8 Class Initialized
INFO - 2024-07-08 15:36:27 --> URI Class Initialized
INFO - 2024-07-08 15:36:27 --> Router Class Initialized
INFO - 2024-07-08 15:36:27 --> Output Class Initialized
INFO - 2024-07-08 15:36:27 --> Security Class Initialized
DEBUG - 2024-07-08 15:36:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-07-08 15:36:27 --> Input Class Initialized
INFO - 2024-07-08 15:36:27 --> Language Class Initialized
INFO - 2024-07-08 15:36:27 --> Language Class Initialized
INFO - 2024-07-08 15:36:27 --> Config Class Initialized
INFO - 2024-07-08 15:36:27 --> Loader Class Initialized
INFO - 2024-07-08 15:36:27 --> Helper loaded: url_helper
INFO - 2024-07-08 15:36:27 --> Helper loaded: file_helper
INFO - 2024-07-08 15:36:27 --> Helper loaded: form_helper
INFO - 2024-07-08 15:36:27 --> Helper loaded: my_helper
INFO - 2024-07-08 15:36:27 --> Database Driver Class Initialized
INFO - 2024-07-08 15:36:27 --> Session: Class initialized using 'files' driver.
INFO - 2024-07-08 15:36:27 --> Controller Class Initialized
INFO - 2024-07-08 15:36:27 --> Upload Class Initialized
INFO - 2024-07-08 15:36:27 --> Language file loaded: language/english/upload_lang.php
ERROR - 2024-07-08 15:36:27 --> The upload path does not appear to be valid.
INFO - 2024-07-08 15:36:27 --> Config Class Initialized
INFO - 2024-07-08 15:36:27 --> Hooks Class Initialized
DEBUG - 2024-07-08 15:36:27 --> UTF-8 Support Enabled
INFO - 2024-07-08 15:36:27 --> Utf8 Class Initialized
INFO - 2024-07-08 15:36:27 --> URI Class Initialized
INFO - 2024-07-08 15:36:27 --> Router Class Initialized
INFO - 2024-07-08 15:36:27 --> Output Class Initialized
INFO - 2024-07-08 15:36:27 --> Security Class Initialized
DEBUG - 2024-07-08 15:36:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-07-08 15:36:27 --> Input Class Initialized
INFO - 2024-07-08 15:36:27 --> Language Class Initialized
INFO - 2024-07-08 15:36:27 --> Language Class Initialized
INFO - 2024-07-08 15:36:27 --> Config Class Initialized
INFO - 2024-07-08 15:36:27 --> Loader Class Initialized
INFO - 2024-07-08 15:36:27 --> Helper loaded: url_helper
INFO - 2024-07-08 15:36:27 --> Helper loaded: file_helper
INFO - 2024-07-08 15:36:27 --> Helper loaded: form_helper
INFO - 2024-07-08 15:36:27 --> Helper loaded: my_helper
INFO - 2024-07-08 15:36:27 --> Database Driver Class Initialized
INFO - 2024-07-08 15:36:27 --> Session: Class initialized using 'files' driver.
INFO - 2024-07-08 15:36:27 --> Controller Class Initialized
DEBUG - 2024-07-08 15:36:27 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/data_siswa/views/list.php
DEBUG - 2024-07-08 15:36:27 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-07-08 15:36:27 --> Final output sent to browser
DEBUG - 2024-07-08 15:36:27 --> Total execution time: 0.0310
INFO - 2024-07-08 15:36:27 --> Config Class Initialized
INFO - 2024-07-08 15:36:27 --> Hooks Class Initialized
DEBUG - 2024-07-08 15:36:27 --> UTF-8 Support Enabled
INFO - 2024-07-08 15:36:27 --> Utf8 Class Initialized
INFO - 2024-07-08 15:36:27 --> URI Class Initialized
INFO - 2024-07-08 15:36:27 --> Router Class Initialized
INFO - 2024-07-08 15:36:27 --> Output Class Initialized
INFO - 2024-07-08 15:36:27 --> Security Class Initialized
DEBUG - 2024-07-08 15:36:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-07-08 15:36:27 --> Input Class Initialized
INFO - 2024-07-08 15:36:27 --> Language Class Initialized
ERROR - 2024-07-08 15:36:27 --> 404 Page Not Found: /index
INFO - 2024-07-08 15:36:27 --> Config Class Initialized
INFO - 2024-07-08 15:36:27 --> Hooks Class Initialized
DEBUG - 2024-07-08 15:36:27 --> UTF-8 Support Enabled
INFO - 2024-07-08 15:36:27 --> Utf8 Class Initialized
INFO - 2024-07-08 15:36:27 --> URI Class Initialized
INFO - 2024-07-08 15:36:27 --> Router Class Initialized
INFO - 2024-07-08 15:36:27 --> Output Class Initialized
INFO - 2024-07-08 15:36:27 --> Security Class Initialized
DEBUG - 2024-07-08 15:36:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-07-08 15:36:27 --> Input Class Initialized
INFO - 2024-07-08 15:36:27 --> Language Class Initialized
INFO - 2024-07-08 15:36:27 --> Language Class Initialized
INFO - 2024-07-08 15:36:27 --> Config Class Initialized
INFO - 2024-07-08 15:36:27 --> Loader Class Initialized
INFO - 2024-07-08 15:36:27 --> Helper loaded: url_helper
INFO - 2024-07-08 15:36:27 --> Helper loaded: file_helper
INFO - 2024-07-08 15:36:27 --> Helper loaded: form_helper
INFO - 2024-07-08 15:36:27 --> Helper loaded: my_helper
INFO - 2024-07-08 15:36:27 --> Database Driver Class Initialized
INFO - 2024-07-08 15:36:27 --> Session: Class initialized using 'files' driver.
INFO - 2024-07-08 15:36:27 --> Controller Class Initialized
INFO - 2024-07-08 15:36:32 --> Config Class Initialized
INFO - 2024-07-08 15:36:32 --> Hooks Class Initialized
DEBUG - 2024-07-08 15:36:32 --> UTF-8 Support Enabled
INFO - 2024-07-08 15:36:32 --> Utf8 Class Initialized
INFO - 2024-07-08 15:36:32 --> URI Class Initialized
INFO - 2024-07-08 15:36:32 --> Router Class Initialized
INFO - 2024-07-08 15:36:32 --> Output Class Initialized
INFO - 2024-07-08 15:36:32 --> Security Class Initialized
DEBUG - 2024-07-08 15:36:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-07-08 15:36:32 --> Input Class Initialized
INFO - 2024-07-08 15:36:32 --> Language Class Initialized
INFO - 2024-07-08 15:36:32 --> Language Class Initialized
INFO - 2024-07-08 15:36:32 --> Config Class Initialized
INFO - 2024-07-08 15:36:32 --> Loader Class Initialized
INFO - 2024-07-08 15:36:32 --> Helper loaded: url_helper
INFO - 2024-07-08 15:36:32 --> Helper loaded: file_helper
INFO - 2024-07-08 15:36:32 --> Helper loaded: form_helper
INFO - 2024-07-08 15:36:32 --> Helper loaded: my_helper
INFO - 2024-07-08 15:36:32 --> Database Driver Class Initialized
INFO - 2024-07-08 15:36:32 --> Session: Class initialized using 'files' driver.
INFO - 2024-07-08 15:36:32 --> Controller Class Initialized
DEBUG - 2024-07-08 15:36:32 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/data_mapel/views/list.php
DEBUG - 2024-07-08 15:36:32 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-07-08 15:36:32 --> Final output sent to browser
DEBUG - 2024-07-08 15:36:32 --> Total execution time: 0.0284
INFO - 2024-07-08 15:36:32 --> Config Class Initialized
INFO - 2024-07-08 15:36:32 --> Hooks Class Initialized
DEBUG - 2024-07-08 15:36:32 --> UTF-8 Support Enabled
INFO - 2024-07-08 15:36:32 --> Utf8 Class Initialized
INFO - 2024-07-08 15:36:32 --> URI Class Initialized
INFO - 2024-07-08 15:36:32 --> Router Class Initialized
INFO - 2024-07-08 15:36:32 --> Output Class Initialized
INFO - 2024-07-08 15:36:32 --> Security Class Initialized
DEBUG - 2024-07-08 15:36:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-07-08 15:36:32 --> Input Class Initialized
INFO - 2024-07-08 15:36:32 --> Language Class Initialized
ERROR - 2024-07-08 15:36:32 --> 404 Page Not Found: /index
INFO - 2024-07-08 15:36:32 --> Config Class Initialized
INFO - 2024-07-08 15:36:32 --> Hooks Class Initialized
DEBUG - 2024-07-08 15:36:32 --> UTF-8 Support Enabled
INFO - 2024-07-08 15:36:32 --> Utf8 Class Initialized
INFO - 2024-07-08 15:36:32 --> URI Class Initialized
INFO - 2024-07-08 15:36:32 --> Router Class Initialized
INFO - 2024-07-08 15:36:32 --> Output Class Initialized
INFO - 2024-07-08 15:36:32 --> Security Class Initialized
DEBUG - 2024-07-08 15:36:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-07-08 15:36:32 --> Input Class Initialized
INFO - 2024-07-08 15:36:32 --> Language Class Initialized
INFO - 2024-07-08 15:36:32 --> Language Class Initialized
INFO - 2024-07-08 15:36:32 --> Config Class Initialized
INFO - 2024-07-08 15:36:32 --> Loader Class Initialized
INFO - 2024-07-08 15:36:32 --> Helper loaded: url_helper
INFO - 2024-07-08 15:36:32 --> Helper loaded: file_helper
INFO - 2024-07-08 15:36:32 --> Helper loaded: form_helper
INFO - 2024-07-08 15:36:32 --> Helper loaded: my_helper
INFO - 2024-07-08 15:36:32 --> Database Driver Class Initialized
INFO - 2024-07-08 15:36:32 --> Session: Class initialized using 'files' driver.
INFO - 2024-07-08 15:36:32 --> Controller Class Initialized
INFO - 2024-07-08 15:36:35 --> Config Class Initialized
INFO - 2024-07-08 15:36:35 --> Hooks Class Initialized
DEBUG - 2024-07-08 15:36:35 --> UTF-8 Support Enabled
INFO - 2024-07-08 15:36:35 --> Utf8 Class Initialized
INFO - 2024-07-08 15:36:35 --> URI Class Initialized
INFO - 2024-07-08 15:36:35 --> Router Class Initialized
INFO - 2024-07-08 15:36:35 --> Output Class Initialized
INFO - 2024-07-08 15:36:35 --> Security Class Initialized
DEBUG - 2024-07-08 15:36:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-07-08 15:36:35 --> Input Class Initialized
INFO - 2024-07-08 15:36:35 --> Language Class Initialized
INFO - 2024-07-08 15:36:35 --> Language Class Initialized
INFO - 2024-07-08 15:36:35 --> Config Class Initialized
INFO - 2024-07-08 15:36:35 --> Loader Class Initialized
INFO - 2024-07-08 15:36:35 --> Helper loaded: url_helper
INFO - 2024-07-08 15:36:35 --> Helper loaded: file_helper
INFO - 2024-07-08 15:36:35 --> Helper loaded: form_helper
INFO - 2024-07-08 15:36:35 --> Helper loaded: my_helper
INFO - 2024-07-08 15:36:35 --> Database Driver Class Initialized
INFO - 2024-07-08 15:36:35 --> Session: Class initialized using 'files' driver.
INFO - 2024-07-08 15:36:35 --> Controller Class Initialized
DEBUG - 2024-07-08 15:36:35 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/set_kelas/views/list.php
DEBUG - 2024-07-08 15:36:35 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-07-08 15:36:35 --> Final output sent to browser
DEBUG - 2024-07-08 15:36:35 --> Total execution time: 0.0360
INFO - 2024-07-08 15:36:38 --> Config Class Initialized
INFO - 2024-07-08 15:36:38 --> Hooks Class Initialized
DEBUG - 2024-07-08 15:36:38 --> UTF-8 Support Enabled
INFO - 2024-07-08 15:36:38 --> Utf8 Class Initialized
INFO - 2024-07-08 15:36:38 --> URI Class Initialized
INFO - 2024-07-08 15:36:38 --> Router Class Initialized
INFO - 2024-07-08 15:36:38 --> Output Class Initialized
INFO - 2024-07-08 15:36:38 --> Security Class Initialized
DEBUG - 2024-07-08 15:36:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-07-08 15:36:38 --> Input Class Initialized
INFO - 2024-07-08 15:36:38 --> Language Class Initialized
INFO - 2024-07-08 15:36:38 --> Language Class Initialized
INFO - 2024-07-08 15:36:38 --> Config Class Initialized
INFO - 2024-07-08 15:36:38 --> Loader Class Initialized
INFO - 2024-07-08 15:36:38 --> Helper loaded: url_helper
INFO - 2024-07-08 15:36:38 --> Helper loaded: file_helper
INFO - 2024-07-08 15:36:38 --> Helper loaded: form_helper
INFO - 2024-07-08 15:36:38 --> Helper loaded: my_helper
INFO - 2024-07-08 15:36:38 --> Database Driver Class Initialized
INFO - 2024-07-08 15:36:38 --> Session: Class initialized using 'files' driver.
INFO - 2024-07-08 15:36:38 --> Controller Class Initialized
ERROR - 2024-07-08 15:36:38 --> Severity: Notice --> Undefined index: tingkat /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/set_kelas/views/form.php 49
ERROR - 2024-07-08 15:36:38 --> Severity: Notice --> Undefined index: tingkat /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/set_kelas/views/form.php 49
ERROR - 2024-07-08 15:36:38 --> Severity: Notice --> Undefined index: tingkat /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/set_kelas/views/form.php 49
ERROR - 2024-07-08 15:36:38 --> Severity: Notice --> Undefined index: tingkat /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/set_kelas/views/form.php 49
ERROR - 2024-07-08 15:36:38 --> Severity: Notice --> Undefined index: tingkat /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/set_kelas/views/form.php 49
ERROR - 2024-07-08 15:36:38 --> Severity: Notice --> Undefined index: tingkat /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/set_kelas/views/form.php 49
ERROR - 2024-07-08 15:36:38 --> Severity: Notice --> Undefined index: tingkat /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/set_kelas/views/form.php 49
ERROR - 2024-07-08 15:36:38 --> Severity: Notice --> Undefined index: tingkat /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/set_kelas/views/form.php 49
ERROR - 2024-07-08 15:36:38 --> Severity: Notice --> Undefined index: tingkat /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/set_kelas/views/form.php 49
ERROR - 2024-07-08 15:36:38 --> Severity: Notice --> Undefined index: tingkat /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/set_kelas/views/form.php 49
ERROR - 2024-07-08 15:36:38 --> Severity: Notice --> Undefined index: tingkat /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/set_kelas/views/form.php 49
ERROR - 2024-07-08 15:36:38 --> Severity: Notice --> Undefined index: tingkat /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/set_kelas/views/form.php 49
ERROR - 2024-07-08 15:36:38 --> Severity: Notice --> Undefined index: tingkat /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/set_kelas/views/form.php 49
ERROR - 2024-07-08 15:36:38 --> Severity: Notice --> Undefined index: tingkat /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/set_kelas/views/form.php 49
ERROR - 2024-07-08 15:36:39 --> Severity: Notice --> Undefined index: tingkat /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/set_kelas/views/form.php 49
ERROR - 2024-07-08 15:36:39 --> Severity: Notice --> Undefined index: tingkat /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/set_kelas/views/form.php 49
ERROR - 2024-07-08 15:36:39 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/set_kelas/views/form.php 49
ERROR - 2024-07-08 15:36:39 --> Severity: Notice --> Undefined index: kelas /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/set_kelas/views/form.php 59
ERROR - 2024-07-08 15:36:39 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/set_kelas/views/form.php 49
ERROR - 2024-07-08 15:36:39 --> Severity: Notice --> Undefined index: kelas /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/set_kelas/views/form.php 59
ERROR - 2024-07-08 15:36:39 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/set_kelas/views/form.php 49
ERROR - 2024-07-08 15:36:39 --> Severity: Notice --> Undefined index: kelas /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/set_kelas/views/form.php 59
ERROR - 2024-07-08 15:36:39 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/set_kelas/views/form.php 49
ERROR - 2024-07-08 15:36:39 --> Severity: Notice --> Undefined index: kelas /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/set_kelas/views/form.php 59
ERROR - 2024-07-08 15:36:39 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/set_kelas/views/form.php 49
ERROR - 2024-07-08 15:36:39 --> Severity: Notice --> Undefined index: kelas /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/set_kelas/views/form.php 59
ERROR - 2024-07-08 15:36:39 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/set_kelas/views/form.php 49
ERROR - 2024-07-08 15:36:39 --> Severity: Notice --> Undefined index: kelas /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/set_kelas/views/form.php 59
ERROR - 2024-07-08 15:36:39 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/set_kelas/views/form.php 49
ERROR - 2024-07-08 15:36:39 --> Severity: Notice --> Undefined index: kelas /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/set_kelas/views/form.php 59
ERROR - 2024-07-08 15:36:39 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/set_kelas/views/form.php 49
ERROR - 2024-07-08 15:36:39 --> Severity: Notice --> Undefined index: kelas /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/set_kelas/views/form.php 59
ERROR - 2024-07-08 15:36:39 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/set_kelas/views/form.php 49
ERROR - 2024-07-08 15:36:39 --> Severity: Notice --> Undefined index: kelas /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/set_kelas/views/form.php 59
ERROR - 2024-07-08 15:36:39 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/set_kelas/views/form.php 49
ERROR - 2024-07-08 15:36:39 --> Severity: Notice --> Undefined index: kelas /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/set_kelas/views/form.php 59
ERROR - 2024-07-08 15:36:39 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/set_kelas/views/form.php 49
ERROR - 2024-07-08 15:36:39 --> Severity: Notice --> Undefined index: kelas /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/set_kelas/views/form.php 59
ERROR - 2024-07-08 15:36:39 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/set_kelas/views/form.php 49
ERROR - 2024-07-08 15:36:39 --> Severity: Notice --> Undefined index: kelas /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/set_kelas/views/form.php 59
ERROR - 2024-07-08 15:36:39 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/set_kelas/views/form.php 49
ERROR - 2024-07-08 15:36:39 --> Severity: Notice --> Undefined index: kelas /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/set_kelas/views/form.php 59
ERROR - 2024-07-08 15:36:39 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/set_kelas/views/form.php 49
ERROR - 2024-07-08 15:36:39 --> Severity: Notice --> Undefined index: kelas /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/set_kelas/views/form.php 59
ERROR - 2024-07-08 15:36:39 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/set_kelas/views/form.php 49
ERROR - 2024-07-08 15:36:39 --> Severity: Notice --> Undefined index: kelas /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/set_kelas/views/form.php 59
ERROR - 2024-07-08 15:36:39 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/set_kelas/views/form.php 49
ERROR - 2024-07-08 15:36:39 --> Severity: Notice --> Undefined index: kelas /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/set_kelas/views/form.php 59
ERROR - 2024-07-08 15:36:39 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/set_kelas/views/form.php 49
ERROR - 2024-07-08 15:36:39 --> Severity: Notice --> Undefined index: kelas /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/set_kelas/views/form.php 59
ERROR - 2024-07-08 15:36:39 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/set_kelas/views/form.php 49
ERROR - 2024-07-08 15:36:39 --> Severity: Notice --> Undefined index: kelas /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/set_kelas/views/form.php 59
ERROR - 2024-07-08 15:36:39 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/set_kelas/views/form.php 49
ERROR - 2024-07-08 15:36:39 --> Severity: Notice --> Undefined index: kelas /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/set_kelas/views/form.php 59
ERROR - 2024-07-08 15:36:39 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/set_kelas/views/form.php 49
ERROR - 2024-07-08 15:36:39 --> Severity: Notice --> Undefined index: kelas /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/set_kelas/views/form.php 59
ERROR - 2024-07-08 15:36:39 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/set_kelas/views/form.php 49
ERROR - 2024-07-08 15:36:39 --> Severity: Notice --> Undefined index: kelas /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/set_kelas/views/form.php 59
ERROR - 2024-07-08 15:36:39 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/set_kelas/views/form.php 49
ERROR - 2024-07-08 15:36:39 --> Severity: Notice --> Undefined index: kelas /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/set_kelas/views/form.php 59
ERROR - 2024-07-08 15:36:39 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/set_kelas/views/form.php 49
ERROR - 2024-07-08 15:36:39 --> Severity: Notice --> Undefined index: kelas /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/set_kelas/views/form.php 59
ERROR - 2024-07-08 15:36:39 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/set_kelas/views/form.php 49
ERROR - 2024-07-08 15:36:39 --> Severity: Notice --> Undefined index: kelas /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/set_kelas/views/form.php 59
ERROR - 2024-07-08 15:36:39 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/set_kelas/views/form.php 49
ERROR - 2024-07-08 15:36:39 --> Severity: Notice --> Undefined index: kelas /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/set_kelas/views/form.php 59
ERROR - 2024-07-08 15:36:39 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/set_kelas/views/form.php 49
ERROR - 2024-07-08 15:36:39 --> Severity: Notice --> Undefined index: kelas /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/set_kelas/views/form.php 59
ERROR - 2024-07-08 15:36:39 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/set_kelas/views/form.php 49
ERROR - 2024-07-08 15:36:39 --> Severity: Notice --> Undefined index: kelas /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/set_kelas/views/form.php 59
ERROR - 2024-07-08 15:36:39 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/set_kelas/views/form.php 49
ERROR - 2024-07-08 15:36:39 --> Severity: Notice --> Undefined index: kelas /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/set_kelas/views/form.php 59
ERROR - 2024-07-08 15:36:39 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/set_kelas/views/form.php 49
ERROR - 2024-07-08 15:36:39 --> Severity: Notice --> Undefined index: kelas /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/set_kelas/views/form.php 59
ERROR - 2024-07-08 15:36:39 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/set_kelas/views/form.php 49
ERROR - 2024-07-08 15:36:39 --> Severity: Notice --> Undefined index: kelas /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/set_kelas/views/form.php 59
ERROR - 2024-07-08 15:36:39 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/set_kelas/views/form.php 49
ERROR - 2024-07-08 15:36:39 --> Severity: Notice --> Undefined index: kelas /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/set_kelas/views/form.php 59
ERROR - 2024-07-08 15:36:39 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/set_kelas/views/form.php 49
ERROR - 2024-07-08 15:36:39 --> Severity: Notice --> Undefined index: kelas /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/set_kelas/views/form.php 59
ERROR - 2024-07-08 15:36:39 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/set_kelas/views/form.php 49
ERROR - 2024-07-08 15:36:39 --> Severity: Notice --> Undefined index: kelas /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/set_kelas/views/form.php 59
ERROR - 2024-07-08 15:36:39 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/set_kelas/views/form.php 49
ERROR - 2024-07-08 15:36:39 --> Severity: Notice --> Undefined index: kelas /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/set_kelas/views/form.php 59
ERROR - 2024-07-08 15:36:39 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/set_kelas/views/form.php 49
ERROR - 2024-07-08 15:36:39 --> Severity: Notice --> Undefined index: kelas /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/set_kelas/views/form.php 59
ERROR - 2024-07-08 15:36:39 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/set_kelas/views/form.php 49
ERROR - 2024-07-08 15:36:39 --> Severity: Notice --> Undefined index: kelas /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/set_kelas/views/form.php 59
DEBUG - 2024-07-08 15:36:39 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/set_kelas/views/form.php
DEBUG - 2024-07-08 15:36:39 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-07-08 15:36:39 --> Final output sent to browser
DEBUG - 2024-07-08 15:36:39 --> Total execution time: 0.1038
INFO - 2024-07-08 15:36:47 --> Config Class Initialized
INFO - 2024-07-08 15:36:47 --> Hooks Class Initialized
DEBUG - 2024-07-08 15:36:47 --> UTF-8 Support Enabled
INFO - 2024-07-08 15:36:47 --> Utf8 Class Initialized
INFO - 2024-07-08 15:36:47 --> URI Class Initialized
INFO - 2024-07-08 15:36:47 --> Router Class Initialized
INFO - 2024-07-08 15:36:47 --> Output Class Initialized
INFO - 2024-07-08 15:36:47 --> Security Class Initialized
DEBUG - 2024-07-08 15:36:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-07-08 15:36:47 --> Input Class Initialized
INFO - 2024-07-08 15:36:47 --> Language Class Initialized
INFO - 2024-07-08 15:36:47 --> Language Class Initialized
INFO - 2024-07-08 15:36:47 --> Config Class Initialized
INFO - 2024-07-08 15:36:47 --> Loader Class Initialized
INFO - 2024-07-08 15:36:47 --> Helper loaded: url_helper
INFO - 2024-07-08 15:36:47 --> Helper loaded: file_helper
INFO - 2024-07-08 15:36:47 --> Helper loaded: form_helper
INFO - 2024-07-08 15:36:47 --> Helper loaded: my_helper
INFO - 2024-07-08 15:36:47 --> Database Driver Class Initialized
INFO - 2024-07-08 15:36:47 --> Session: Class initialized using 'files' driver.
INFO - 2024-07-08 15:36:47 --> Controller Class Initialized
DEBUG - 2024-07-08 15:36:47 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/data_siswa/views/list.php
DEBUG - 2024-07-08 15:36:47 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-07-08 15:36:47 --> Final output sent to browser
DEBUG - 2024-07-08 15:36:47 --> Total execution time: 0.0322
INFO - 2024-07-08 15:36:47 --> Config Class Initialized
INFO - 2024-07-08 15:36:47 --> Hooks Class Initialized
DEBUG - 2024-07-08 15:36:47 --> UTF-8 Support Enabled
INFO - 2024-07-08 15:36:47 --> Utf8 Class Initialized
INFO - 2024-07-08 15:36:47 --> URI Class Initialized
INFO - 2024-07-08 15:36:47 --> Router Class Initialized
INFO - 2024-07-08 15:36:47 --> Output Class Initialized
INFO - 2024-07-08 15:36:47 --> Security Class Initialized
DEBUG - 2024-07-08 15:36:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-07-08 15:36:47 --> Input Class Initialized
INFO - 2024-07-08 15:36:47 --> Language Class Initialized
ERROR - 2024-07-08 15:36:47 --> 404 Page Not Found: /index
INFO - 2024-07-08 15:36:47 --> Config Class Initialized
INFO - 2024-07-08 15:36:47 --> Hooks Class Initialized
DEBUG - 2024-07-08 15:36:47 --> UTF-8 Support Enabled
INFO - 2024-07-08 15:36:47 --> Utf8 Class Initialized
INFO - 2024-07-08 15:36:47 --> URI Class Initialized
INFO - 2024-07-08 15:36:47 --> Router Class Initialized
INFO - 2024-07-08 15:36:47 --> Output Class Initialized
INFO - 2024-07-08 15:36:47 --> Security Class Initialized
DEBUG - 2024-07-08 15:36:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-07-08 15:36:47 --> Input Class Initialized
INFO - 2024-07-08 15:36:47 --> Language Class Initialized
INFO - 2024-07-08 15:36:47 --> Language Class Initialized
INFO - 2024-07-08 15:36:47 --> Config Class Initialized
INFO - 2024-07-08 15:36:47 --> Loader Class Initialized
INFO - 2024-07-08 15:36:47 --> Helper loaded: url_helper
INFO - 2024-07-08 15:36:47 --> Helper loaded: file_helper
INFO - 2024-07-08 15:36:47 --> Helper loaded: form_helper
INFO - 2024-07-08 15:36:47 --> Helper loaded: my_helper
INFO - 2024-07-08 15:36:47 --> Database Driver Class Initialized
INFO - 2024-07-08 15:36:47 --> Session: Class initialized using 'files' driver.
INFO - 2024-07-08 15:36:47 --> Controller Class Initialized
INFO - 2024-07-08 15:36:51 --> Config Class Initialized
INFO - 2024-07-08 15:36:51 --> Hooks Class Initialized
DEBUG - 2024-07-08 15:36:51 --> UTF-8 Support Enabled
INFO - 2024-07-08 15:36:51 --> Utf8 Class Initialized
INFO - 2024-07-08 15:36:51 --> URI Class Initialized
INFO - 2024-07-08 15:36:51 --> Router Class Initialized
INFO - 2024-07-08 15:36:51 --> Output Class Initialized
INFO - 2024-07-08 15:36:51 --> Security Class Initialized
DEBUG - 2024-07-08 15:36:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-07-08 15:36:51 --> Input Class Initialized
INFO - 2024-07-08 15:36:51 --> Language Class Initialized
INFO - 2024-07-08 15:36:51 --> Language Class Initialized
INFO - 2024-07-08 15:36:51 --> Config Class Initialized
INFO - 2024-07-08 15:36:51 --> Loader Class Initialized
INFO - 2024-07-08 15:36:51 --> Helper loaded: url_helper
INFO - 2024-07-08 15:36:51 --> Helper loaded: file_helper
INFO - 2024-07-08 15:36:51 --> Helper loaded: form_helper
INFO - 2024-07-08 15:36:51 --> Helper loaded: my_helper
INFO - 2024-07-08 15:36:51 --> Database Driver Class Initialized
INFO - 2024-07-08 15:36:51 --> Session: Class initialized using 'files' driver.
INFO - 2024-07-08 15:36:51 --> Controller Class Initialized
DEBUG - 2024-07-08 15:36:51 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/set_kelas/views/list.php
DEBUG - 2024-07-08 15:36:51 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-07-08 15:36:51 --> Final output sent to browser
DEBUG - 2024-07-08 15:36:51 --> Total execution time: 0.0314
INFO - 2024-07-08 15:36:53 --> Config Class Initialized
INFO - 2024-07-08 15:36:53 --> Hooks Class Initialized
DEBUG - 2024-07-08 15:36:53 --> UTF-8 Support Enabled
INFO - 2024-07-08 15:36:53 --> Utf8 Class Initialized
INFO - 2024-07-08 15:36:53 --> URI Class Initialized
INFO - 2024-07-08 15:36:53 --> Router Class Initialized
INFO - 2024-07-08 15:36:53 --> Output Class Initialized
INFO - 2024-07-08 15:36:53 --> Security Class Initialized
DEBUG - 2024-07-08 15:36:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-07-08 15:36:53 --> Input Class Initialized
INFO - 2024-07-08 15:36:53 --> Language Class Initialized
INFO - 2024-07-08 15:36:53 --> Language Class Initialized
INFO - 2024-07-08 15:36:53 --> Config Class Initialized
INFO - 2024-07-08 15:36:53 --> Loader Class Initialized
INFO - 2024-07-08 15:36:53 --> Helper loaded: url_helper
INFO - 2024-07-08 15:36:53 --> Helper loaded: file_helper
INFO - 2024-07-08 15:36:53 --> Helper loaded: form_helper
INFO - 2024-07-08 15:36:53 --> Helper loaded: my_helper
INFO - 2024-07-08 15:36:53 --> Database Driver Class Initialized
INFO - 2024-07-08 15:36:53 --> Session: Class initialized using 'files' driver.
INFO - 2024-07-08 15:36:53 --> Controller Class Initialized
INFO - 2024-07-08 15:36:53 --> Database Driver Class Initialized
INFO - 2024-07-08 15:36:53 --> Config Class Initialized
INFO - 2024-07-08 15:36:53 --> Hooks Class Initialized
DEBUG - 2024-07-08 15:36:53 --> UTF-8 Support Enabled
INFO - 2024-07-08 15:36:53 --> Utf8 Class Initialized
INFO - 2024-07-08 15:36:53 --> URI Class Initialized
INFO - 2024-07-08 15:36:53 --> Router Class Initialized
INFO - 2024-07-08 15:36:53 --> Output Class Initialized
INFO - 2024-07-08 15:36:53 --> Security Class Initialized
DEBUG - 2024-07-08 15:36:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-07-08 15:36:53 --> Input Class Initialized
INFO - 2024-07-08 15:36:53 --> Language Class Initialized
INFO - 2024-07-08 15:36:53 --> Language Class Initialized
INFO - 2024-07-08 15:36:53 --> Config Class Initialized
INFO - 2024-07-08 15:36:53 --> Loader Class Initialized
INFO - 2024-07-08 15:36:53 --> Helper loaded: url_helper
INFO - 2024-07-08 15:36:53 --> Helper loaded: file_helper
INFO - 2024-07-08 15:36:53 --> Helper loaded: form_helper
INFO - 2024-07-08 15:36:53 --> Helper loaded: my_helper
INFO - 2024-07-08 15:36:53 --> Database Driver Class Initialized
INFO - 2024-07-08 15:36:53 --> Session: Class initialized using 'files' driver.
INFO - 2024-07-08 15:36:53 --> Controller Class Initialized
DEBUG - 2024-07-08 15:36:53 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/set_kelas/views/list.php
DEBUG - 2024-07-08 15:36:53 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-07-08 15:36:53 --> Final output sent to browser
DEBUG - 2024-07-08 15:36:53 --> Total execution time: 0.0337
INFO - 2024-07-08 15:36:59 --> Config Class Initialized
INFO - 2024-07-08 15:36:59 --> Hooks Class Initialized
DEBUG - 2024-07-08 15:36:59 --> UTF-8 Support Enabled
INFO - 2024-07-08 15:36:59 --> Utf8 Class Initialized
INFO - 2024-07-08 15:36:59 --> URI Class Initialized
INFO - 2024-07-08 15:36:59 --> Router Class Initialized
INFO - 2024-07-08 15:36:59 --> Output Class Initialized
INFO - 2024-07-08 15:36:59 --> Security Class Initialized
DEBUG - 2024-07-08 15:36:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-07-08 15:36:59 --> Input Class Initialized
INFO - 2024-07-08 15:36:59 --> Language Class Initialized
INFO - 2024-07-08 15:36:59 --> Language Class Initialized
INFO - 2024-07-08 15:36:59 --> Config Class Initialized
INFO - 2024-07-08 15:36:59 --> Loader Class Initialized
INFO - 2024-07-08 15:36:59 --> Helper loaded: url_helper
INFO - 2024-07-08 15:36:59 --> Helper loaded: file_helper
INFO - 2024-07-08 15:36:59 --> Helper loaded: form_helper
INFO - 2024-07-08 15:36:59 --> Helper loaded: my_helper
INFO - 2024-07-08 15:36:59 --> Database Driver Class Initialized
INFO - 2024-07-08 15:36:59 --> Session: Class initialized using 'files' driver.
INFO - 2024-07-08 15:36:59 --> Controller Class Initialized
ERROR - 2024-07-08 15:36:59 --> Severity: Notice --> Undefined index: tingkat /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/set_kelas/views/form.php 49
ERROR - 2024-07-08 15:36:59 --> Severity: Notice --> Undefined index: tingkat /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/set_kelas/views/form.php 49
ERROR - 2024-07-08 15:36:59 --> Severity: Notice --> Undefined index: tingkat /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/set_kelas/views/form.php 49
ERROR - 2024-07-08 15:36:59 --> Severity: Notice --> Undefined index: tingkat /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/set_kelas/views/form.php 49
ERROR - 2024-07-08 15:36:59 --> Severity: Notice --> Undefined index: tingkat /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/set_kelas/views/form.php 49
ERROR - 2024-07-08 15:36:59 --> Severity: Notice --> Undefined index: tingkat /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/set_kelas/views/form.php 49
ERROR - 2024-07-08 15:36:59 --> Severity: Notice --> Undefined index: tingkat /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/set_kelas/views/form.php 49
ERROR - 2024-07-08 15:36:59 --> Severity: Notice --> Undefined index: tingkat /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/set_kelas/views/form.php 49
ERROR - 2024-07-08 15:36:59 --> Severity: Notice --> Undefined index: tingkat /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/set_kelas/views/form.php 49
ERROR - 2024-07-08 15:36:59 --> Severity: Notice --> Undefined index: tingkat /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/set_kelas/views/form.php 49
ERROR - 2024-07-08 15:36:59 --> Severity: Notice --> Undefined index: tingkat /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/set_kelas/views/form.php 49
ERROR - 2024-07-08 15:36:59 --> Severity: Notice --> Undefined index: tingkat /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/set_kelas/views/form.php 49
ERROR - 2024-07-08 15:36:59 --> Severity: Notice --> Undefined index: tingkat /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/set_kelas/views/form.php 49
ERROR - 2024-07-08 15:36:59 --> Severity: Notice --> Undefined index: tingkat /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/set_kelas/views/form.php 49
ERROR - 2024-07-08 15:36:59 --> Severity: Notice --> Undefined index: tingkat /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/set_kelas/views/form.php 49
ERROR - 2024-07-08 15:36:59 --> Severity: Notice --> Undefined index: tingkat /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/set_kelas/views/form.php 49
ERROR - 2024-07-08 15:36:59 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/set_kelas/views/form.php 49
ERROR - 2024-07-08 15:36:59 --> Severity: Notice --> Undefined index: kelas /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/set_kelas/views/form.php 59
ERROR - 2024-07-08 15:36:59 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/set_kelas/views/form.php 49
ERROR - 2024-07-08 15:36:59 --> Severity: Notice --> Undefined index: kelas /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/set_kelas/views/form.php 59
ERROR - 2024-07-08 15:36:59 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/set_kelas/views/form.php 49
ERROR - 2024-07-08 15:36:59 --> Severity: Notice --> Undefined index: kelas /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/set_kelas/views/form.php 59
ERROR - 2024-07-08 15:36:59 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/set_kelas/views/form.php 49
ERROR - 2024-07-08 15:36:59 --> Severity: Notice --> Undefined index: kelas /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/set_kelas/views/form.php 59
ERROR - 2024-07-08 15:36:59 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/set_kelas/views/form.php 49
ERROR - 2024-07-08 15:36:59 --> Severity: Notice --> Undefined index: kelas /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/set_kelas/views/form.php 59
ERROR - 2024-07-08 15:36:59 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/set_kelas/views/form.php 49
ERROR - 2024-07-08 15:36:59 --> Severity: Notice --> Undefined index: kelas /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/set_kelas/views/form.php 59
ERROR - 2024-07-08 15:36:59 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/set_kelas/views/form.php 49
ERROR - 2024-07-08 15:36:59 --> Severity: Notice --> Undefined index: kelas /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/set_kelas/views/form.php 59
ERROR - 2024-07-08 15:36:59 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/set_kelas/views/form.php 49
ERROR - 2024-07-08 15:36:59 --> Severity: Notice --> Undefined index: kelas /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/set_kelas/views/form.php 59
ERROR - 2024-07-08 15:36:59 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/set_kelas/views/form.php 49
ERROR - 2024-07-08 15:36:59 --> Severity: Notice --> Undefined index: kelas /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/set_kelas/views/form.php 59
ERROR - 2024-07-08 15:36:59 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/set_kelas/views/form.php 49
ERROR - 2024-07-08 15:36:59 --> Severity: Notice --> Undefined index: kelas /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/set_kelas/views/form.php 59
ERROR - 2024-07-08 15:36:59 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/set_kelas/views/form.php 49
ERROR - 2024-07-08 15:36:59 --> Severity: Notice --> Undefined index: kelas /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/set_kelas/views/form.php 59
ERROR - 2024-07-08 15:36:59 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/set_kelas/views/form.php 49
ERROR - 2024-07-08 15:36:59 --> Severity: Notice --> Undefined index: kelas /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/set_kelas/views/form.php 59
ERROR - 2024-07-08 15:36:59 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/set_kelas/views/form.php 49
ERROR - 2024-07-08 15:36:59 --> Severity: Notice --> Undefined index: kelas /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/set_kelas/views/form.php 59
ERROR - 2024-07-08 15:36:59 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/set_kelas/views/form.php 49
ERROR - 2024-07-08 15:36:59 --> Severity: Notice --> Undefined index: kelas /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/set_kelas/views/form.php 59
ERROR - 2024-07-08 15:36:59 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/set_kelas/views/form.php 49
ERROR - 2024-07-08 15:36:59 --> Severity: Notice --> Undefined index: kelas /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/set_kelas/views/form.php 59
ERROR - 2024-07-08 15:36:59 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/set_kelas/views/form.php 49
ERROR - 2024-07-08 15:36:59 --> Severity: Notice --> Undefined index: kelas /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/set_kelas/views/form.php 59
ERROR - 2024-07-08 15:36:59 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/set_kelas/views/form.php 49
ERROR - 2024-07-08 15:36:59 --> Severity: Notice --> Undefined index: kelas /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/set_kelas/views/form.php 59
ERROR - 2024-07-08 15:36:59 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/set_kelas/views/form.php 49
ERROR - 2024-07-08 15:36:59 --> Severity: Notice --> Undefined index: kelas /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/set_kelas/views/form.php 59
ERROR - 2024-07-08 15:36:59 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/set_kelas/views/form.php 49
ERROR - 2024-07-08 15:36:59 --> Severity: Notice --> Undefined index: kelas /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/set_kelas/views/form.php 59
ERROR - 2024-07-08 15:36:59 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/set_kelas/views/form.php 49
ERROR - 2024-07-08 15:36:59 --> Severity: Notice --> Undefined index: kelas /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/set_kelas/views/form.php 59
ERROR - 2024-07-08 15:36:59 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/set_kelas/views/form.php 49
ERROR - 2024-07-08 15:36:59 --> Severity: Notice --> Undefined index: kelas /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/set_kelas/views/form.php 59
ERROR - 2024-07-08 15:36:59 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/set_kelas/views/form.php 49
ERROR - 2024-07-08 15:36:59 --> Severity: Notice --> Undefined index: kelas /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/set_kelas/views/form.php 59
ERROR - 2024-07-08 15:36:59 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/set_kelas/views/form.php 49
ERROR - 2024-07-08 15:36:59 --> Severity: Notice --> Undefined index: kelas /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/set_kelas/views/form.php 59
ERROR - 2024-07-08 15:36:59 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/set_kelas/views/form.php 49
ERROR - 2024-07-08 15:36:59 --> Severity: Notice --> Undefined index: kelas /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/set_kelas/views/form.php 59
ERROR - 2024-07-08 15:36:59 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/set_kelas/views/form.php 49
ERROR - 2024-07-08 15:36:59 --> Severity: Notice --> Undefined index: kelas /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/set_kelas/views/form.php 59
ERROR - 2024-07-08 15:36:59 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/set_kelas/views/form.php 49
ERROR - 2024-07-08 15:36:59 --> Severity: Notice --> Undefined index: kelas /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/set_kelas/views/form.php 59
ERROR - 2024-07-08 15:36:59 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/set_kelas/views/form.php 49
ERROR - 2024-07-08 15:36:59 --> Severity: Notice --> Undefined index: kelas /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/set_kelas/views/form.php 59
ERROR - 2024-07-08 15:36:59 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/set_kelas/views/form.php 49
ERROR - 2024-07-08 15:36:59 --> Severity: Notice --> Undefined index: kelas /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/set_kelas/views/form.php 59
ERROR - 2024-07-08 15:36:59 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/set_kelas/views/form.php 49
ERROR - 2024-07-08 15:36:59 --> Severity: Notice --> Undefined index: kelas /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/set_kelas/views/form.php 59
ERROR - 2024-07-08 15:36:59 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/set_kelas/views/form.php 49
ERROR - 2024-07-08 15:36:59 --> Severity: Notice --> Undefined index: kelas /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/set_kelas/views/form.php 59
ERROR - 2024-07-08 15:36:59 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/set_kelas/views/form.php 49
ERROR - 2024-07-08 15:36:59 --> Severity: Notice --> Undefined index: kelas /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/set_kelas/views/form.php 59
ERROR - 2024-07-08 15:36:59 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/set_kelas/views/form.php 49
ERROR - 2024-07-08 15:36:59 --> Severity: Notice --> Undefined index: kelas /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/set_kelas/views/form.php 59
ERROR - 2024-07-08 15:36:59 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/set_kelas/views/form.php 49
ERROR - 2024-07-08 15:36:59 --> Severity: Notice --> Undefined index: kelas /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/set_kelas/views/form.php 59
ERROR - 2024-07-08 15:36:59 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/set_kelas/views/form.php 49
ERROR - 2024-07-08 15:36:59 --> Severity: Notice --> Undefined index: kelas /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/set_kelas/views/form.php 59
ERROR - 2024-07-08 15:36:59 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/set_kelas/views/form.php 49
ERROR - 2024-07-08 15:36:59 --> Severity: Notice --> Undefined index: kelas /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/set_kelas/views/form.php 59
ERROR - 2024-07-08 15:36:59 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/set_kelas/views/form.php 49
ERROR - 2024-07-08 15:36:59 --> Severity: Notice --> Undefined index: kelas /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/set_kelas/views/form.php 59
DEBUG - 2024-07-08 15:36:59 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/set_kelas/views/form.php
DEBUG - 2024-07-08 15:36:59 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-07-08 15:36:59 --> Final output sent to browser
DEBUG - 2024-07-08 15:36:59 --> Total execution time: 0.0971
INFO - 2024-07-08 15:37:20 --> Config Class Initialized
INFO - 2024-07-08 15:37:20 --> Hooks Class Initialized
DEBUG - 2024-07-08 15:37:20 --> UTF-8 Support Enabled
INFO - 2024-07-08 15:37:20 --> Utf8 Class Initialized
INFO - 2024-07-08 15:37:20 --> URI Class Initialized
INFO - 2024-07-08 15:37:20 --> Router Class Initialized
INFO - 2024-07-08 15:37:20 --> Output Class Initialized
INFO - 2024-07-08 15:37:20 --> Security Class Initialized
DEBUG - 2024-07-08 15:37:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-07-08 15:37:20 --> Input Class Initialized
INFO - 2024-07-08 15:37:20 --> Language Class Initialized
INFO - 2024-07-08 15:37:20 --> Language Class Initialized
INFO - 2024-07-08 15:37:20 --> Config Class Initialized
INFO - 2024-07-08 15:37:20 --> Loader Class Initialized
INFO - 2024-07-08 15:37:20 --> Helper loaded: url_helper
INFO - 2024-07-08 15:37:20 --> Helper loaded: file_helper
INFO - 2024-07-08 15:37:20 --> Helper loaded: form_helper
INFO - 2024-07-08 15:37:20 --> Helper loaded: my_helper
INFO - 2024-07-08 15:37:20 --> Database Driver Class Initialized
INFO - 2024-07-08 15:37:20 --> Session: Class initialized using 'files' driver.
INFO - 2024-07-08 15:37:20 --> Controller Class Initialized
DEBUG - 2024-07-08 15:37:20 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/data_siswa/views/list.php
DEBUG - 2024-07-08 15:37:20 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-07-08 15:37:20 --> Final output sent to browser
DEBUG - 2024-07-08 15:37:20 --> Total execution time: 0.0370
INFO - 2024-07-08 15:37:21 --> Config Class Initialized
INFO - 2024-07-08 15:37:21 --> Hooks Class Initialized
DEBUG - 2024-07-08 15:37:21 --> UTF-8 Support Enabled
INFO - 2024-07-08 15:37:21 --> Utf8 Class Initialized
INFO - 2024-07-08 15:37:21 --> URI Class Initialized
INFO - 2024-07-08 15:37:21 --> Router Class Initialized
INFO - 2024-07-08 15:37:21 --> Output Class Initialized
INFO - 2024-07-08 15:37:21 --> Security Class Initialized
DEBUG - 2024-07-08 15:37:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-07-08 15:37:21 --> Input Class Initialized
INFO - 2024-07-08 15:37:21 --> Language Class Initialized
ERROR - 2024-07-08 15:37:21 --> 404 Page Not Found: /index
INFO - 2024-07-08 15:37:21 --> Config Class Initialized
INFO - 2024-07-08 15:37:21 --> Hooks Class Initialized
DEBUG - 2024-07-08 15:37:21 --> UTF-8 Support Enabled
INFO - 2024-07-08 15:37:21 --> Utf8 Class Initialized
INFO - 2024-07-08 15:37:21 --> URI Class Initialized
INFO - 2024-07-08 15:37:21 --> Router Class Initialized
INFO - 2024-07-08 15:37:21 --> Output Class Initialized
INFO - 2024-07-08 15:37:21 --> Security Class Initialized
DEBUG - 2024-07-08 15:37:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-07-08 15:37:21 --> Input Class Initialized
INFO - 2024-07-08 15:37:21 --> Language Class Initialized
INFO - 2024-07-08 15:37:21 --> Language Class Initialized
INFO - 2024-07-08 15:37:21 --> Config Class Initialized
INFO - 2024-07-08 15:37:21 --> Loader Class Initialized
INFO - 2024-07-08 15:37:21 --> Helper loaded: url_helper
INFO - 2024-07-08 15:37:21 --> Helper loaded: file_helper
INFO - 2024-07-08 15:37:21 --> Helper loaded: form_helper
INFO - 2024-07-08 15:37:21 --> Helper loaded: my_helper
INFO - 2024-07-08 15:37:21 --> Database Driver Class Initialized
INFO - 2024-07-08 15:37:21 --> Session: Class initialized using 'files' driver.
INFO - 2024-07-08 15:37:21 --> Controller Class Initialized
INFO - 2024-07-08 15:37:24 --> Config Class Initialized
INFO - 2024-07-08 15:37:24 --> Hooks Class Initialized
DEBUG - 2024-07-08 15:37:24 --> UTF-8 Support Enabled
INFO - 2024-07-08 15:37:24 --> Utf8 Class Initialized
INFO - 2024-07-08 15:37:24 --> URI Class Initialized
INFO - 2024-07-08 15:37:24 --> Router Class Initialized
INFO - 2024-07-08 15:37:24 --> Output Class Initialized
INFO - 2024-07-08 15:37:24 --> Security Class Initialized
DEBUG - 2024-07-08 15:37:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-07-08 15:37:24 --> Input Class Initialized
INFO - 2024-07-08 15:37:24 --> Language Class Initialized
INFO - 2024-07-08 15:37:24 --> Language Class Initialized
INFO - 2024-07-08 15:37:24 --> Config Class Initialized
INFO - 2024-07-08 15:37:24 --> Loader Class Initialized
INFO - 2024-07-08 15:37:24 --> Helper loaded: url_helper
INFO - 2024-07-08 15:37:24 --> Helper loaded: file_helper
INFO - 2024-07-08 15:37:24 --> Helper loaded: form_helper
INFO - 2024-07-08 15:37:24 --> Helper loaded: my_helper
INFO - 2024-07-08 15:37:24 --> Database Driver Class Initialized
INFO - 2024-07-08 15:37:24 --> Session: Class initialized using 'files' driver.
INFO - 2024-07-08 15:37:24 --> Controller Class Initialized
ERROR - 2024-07-08 15:37:24 --> Severity: Notice --> Undefined variable: status_form /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/data_siswa/views/form.php 231
DEBUG - 2024-07-08 15:37:24 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/data_siswa/views/form.php
DEBUG - 2024-07-08 15:37:24 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-07-08 15:37:24 --> Final output sent to browser
DEBUG - 2024-07-08 15:37:24 --> Total execution time: 0.0528
INFO - 2024-07-08 15:37:29 --> Config Class Initialized
INFO - 2024-07-08 15:37:29 --> Hooks Class Initialized
DEBUG - 2024-07-08 15:37:29 --> UTF-8 Support Enabled
INFO - 2024-07-08 15:37:29 --> Utf8 Class Initialized
INFO - 2024-07-08 15:37:29 --> URI Class Initialized
INFO - 2024-07-08 15:37:29 --> Router Class Initialized
INFO - 2024-07-08 15:37:29 --> Output Class Initialized
INFO - 2024-07-08 15:37:29 --> Security Class Initialized
DEBUG - 2024-07-08 15:37:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-07-08 15:37:29 --> Input Class Initialized
INFO - 2024-07-08 15:37:29 --> Language Class Initialized
INFO - 2024-07-08 15:37:29 --> Language Class Initialized
INFO - 2024-07-08 15:37:29 --> Config Class Initialized
INFO - 2024-07-08 15:37:29 --> Loader Class Initialized
INFO - 2024-07-08 15:37:29 --> Helper loaded: url_helper
INFO - 2024-07-08 15:37:29 --> Helper loaded: file_helper
INFO - 2024-07-08 15:37:29 --> Helper loaded: form_helper
INFO - 2024-07-08 15:37:29 --> Helper loaded: my_helper
INFO - 2024-07-08 15:37:29 --> Database Driver Class Initialized
INFO - 2024-07-08 15:37:29 --> Session: Class initialized using 'files' driver.
INFO - 2024-07-08 15:37:29 --> Controller Class Initialized
DEBUG - 2024-07-08 15:37:29 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/set_mapel/views/list.php
DEBUG - 2024-07-08 15:37:29 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-07-08 15:37:29 --> Final output sent to browser
DEBUG - 2024-07-08 15:37:29 --> Total execution time: 0.0418
INFO - 2024-07-08 15:37:29 --> Config Class Initialized
INFO - 2024-07-08 15:37:29 --> Hooks Class Initialized
DEBUG - 2024-07-08 15:37:29 --> UTF-8 Support Enabled
INFO - 2024-07-08 15:37:29 --> Utf8 Class Initialized
INFO - 2024-07-08 15:37:29 --> URI Class Initialized
INFO - 2024-07-08 15:37:29 --> Router Class Initialized
INFO - 2024-07-08 15:37:29 --> Output Class Initialized
INFO - 2024-07-08 15:37:29 --> Security Class Initialized
DEBUG - 2024-07-08 15:37:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-07-08 15:37:29 --> Input Class Initialized
INFO - 2024-07-08 15:37:29 --> Language Class Initialized
ERROR - 2024-07-08 15:37:29 --> 404 Page Not Found: /index
INFO - 2024-07-08 15:37:29 --> Config Class Initialized
INFO - 2024-07-08 15:37:29 --> Hooks Class Initialized
DEBUG - 2024-07-08 15:37:29 --> UTF-8 Support Enabled
INFO - 2024-07-08 15:37:29 --> Utf8 Class Initialized
INFO - 2024-07-08 15:37:29 --> URI Class Initialized
INFO - 2024-07-08 15:37:29 --> Router Class Initialized
INFO - 2024-07-08 15:37:29 --> Output Class Initialized
INFO - 2024-07-08 15:37:29 --> Security Class Initialized
DEBUG - 2024-07-08 15:37:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-07-08 15:37:29 --> Input Class Initialized
INFO - 2024-07-08 15:37:29 --> Language Class Initialized
INFO - 2024-07-08 15:37:29 --> Language Class Initialized
INFO - 2024-07-08 15:37:29 --> Config Class Initialized
INFO - 2024-07-08 15:37:29 --> Loader Class Initialized
INFO - 2024-07-08 15:37:29 --> Helper loaded: url_helper
INFO - 2024-07-08 15:37:29 --> Helper loaded: file_helper
INFO - 2024-07-08 15:37:29 --> Helper loaded: form_helper
INFO - 2024-07-08 15:37:29 --> Helper loaded: my_helper
INFO - 2024-07-08 15:37:29 --> Database Driver Class Initialized
INFO - 2024-07-08 15:37:29 --> Session: Class initialized using 'files' driver.
INFO - 2024-07-08 15:37:29 --> Controller Class Initialized
INFO - 2024-07-08 15:37:33 --> Config Class Initialized
INFO - 2024-07-08 15:37:33 --> Hooks Class Initialized
DEBUG - 2024-07-08 15:37:33 --> UTF-8 Support Enabled
INFO - 2024-07-08 15:37:33 --> Utf8 Class Initialized
INFO - 2024-07-08 15:37:33 --> URI Class Initialized
INFO - 2024-07-08 15:37:33 --> Router Class Initialized
INFO - 2024-07-08 15:37:33 --> Output Class Initialized
INFO - 2024-07-08 15:37:33 --> Security Class Initialized
DEBUG - 2024-07-08 15:37:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-07-08 15:37:33 --> Input Class Initialized
INFO - 2024-07-08 15:37:33 --> Language Class Initialized
INFO - 2024-07-08 15:37:33 --> Language Class Initialized
INFO - 2024-07-08 15:37:33 --> Config Class Initialized
INFO - 2024-07-08 15:37:33 --> Loader Class Initialized
INFO - 2024-07-08 15:37:33 --> Helper loaded: url_helper
INFO - 2024-07-08 15:37:33 --> Helper loaded: file_helper
INFO - 2024-07-08 15:37:33 --> Helper loaded: form_helper
INFO - 2024-07-08 15:37:33 --> Helper loaded: my_helper
INFO - 2024-07-08 15:37:33 --> Database Driver Class Initialized
INFO - 2024-07-08 15:37:33 --> Session: Class initialized using 'files' driver.
INFO - 2024-07-08 15:37:33 --> Controller Class Initialized
DEBUG - 2024-07-08 15:37:33 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/set_kelas/views/list.php
DEBUG - 2024-07-08 15:37:33 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-07-08 15:37:33 --> Final output sent to browser
DEBUG - 2024-07-08 15:37:33 --> Total execution time: 0.0414
INFO - 2024-07-08 15:37:35 --> Config Class Initialized
INFO - 2024-07-08 15:37:35 --> Hooks Class Initialized
DEBUG - 2024-07-08 15:37:35 --> UTF-8 Support Enabled
INFO - 2024-07-08 15:37:35 --> Utf8 Class Initialized
INFO - 2024-07-08 15:37:35 --> URI Class Initialized
INFO - 2024-07-08 15:37:35 --> Router Class Initialized
INFO - 2024-07-08 15:37:35 --> Output Class Initialized
INFO - 2024-07-08 15:37:35 --> Security Class Initialized
DEBUG - 2024-07-08 15:37:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-07-08 15:37:35 --> Input Class Initialized
INFO - 2024-07-08 15:37:35 --> Language Class Initialized
INFO - 2024-07-08 15:37:35 --> Language Class Initialized
INFO - 2024-07-08 15:37:35 --> Config Class Initialized
INFO - 2024-07-08 15:37:35 --> Loader Class Initialized
INFO - 2024-07-08 15:37:35 --> Helper loaded: url_helper
INFO - 2024-07-08 15:37:35 --> Helper loaded: file_helper
INFO - 2024-07-08 15:37:35 --> Helper loaded: form_helper
INFO - 2024-07-08 15:37:35 --> Helper loaded: my_helper
INFO - 2024-07-08 15:37:35 --> Database Driver Class Initialized
INFO - 2024-07-08 15:37:35 --> Session: Class initialized using 'files' driver.
INFO - 2024-07-08 15:37:35 --> Controller Class Initialized
ERROR - 2024-07-08 15:37:35 --> Severity: Notice --> Undefined index: tingkat /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/set_kelas/views/form.php 49
ERROR - 2024-07-08 15:37:35 --> Severity: Notice --> Undefined index: tingkat /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/set_kelas/views/form.php 49
ERROR - 2024-07-08 15:37:35 --> Severity: Notice --> Undefined index: tingkat /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/set_kelas/views/form.php 49
ERROR - 2024-07-08 15:37:35 --> Severity: Notice --> Undefined index: tingkat /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/set_kelas/views/form.php 49
ERROR - 2024-07-08 15:37:35 --> Severity: Notice --> Undefined index: tingkat /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/set_kelas/views/form.php 49
ERROR - 2024-07-08 15:37:35 --> Severity: Notice --> Undefined index: tingkat /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/set_kelas/views/form.php 49
ERROR - 2024-07-08 15:37:35 --> Severity: Notice --> Undefined index: tingkat /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/set_kelas/views/form.php 49
ERROR - 2024-07-08 15:37:35 --> Severity: Notice --> Undefined index: tingkat /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/set_kelas/views/form.php 49
ERROR - 2024-07-08 15:37:35 --> Severity: Notice --> Undefined index: tingkat /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/set_kelas/views/form.php 49
ERROR - 2024-07-08 15:37:35 --> Severity: Notice --> Undefined index: tingkat /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/set_kelas/views/form.php 49
ERROR - 2024-07-08 15:37:35 --> Severity: Notice --> Undefined index: tingkat /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/set_kelas/views/form.php 49
ERROR - 2024-07-08 15:37:35 --> Severity: Notice --> Undefined index: tingkat /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/set_kelas/views/form.php 49
ERROR - 2024-07-08 15:37:35 --> Severity: Notice --> Undefined index: tingkat /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/set_kelas/views/form.php 49
ERROR - 2024-07-08 15:37:35 --> Severity: Notice --> Undefined index: tingkat /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/set_kelas/views/form.php 49
ERROR - 2024-07-08 15:37:35 --> Severity: Notice --> Undefined index: tingkat /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/set_kelas/views/form.php 49
ERROR - 2024-07-08 15:37:35 --> Severity: Notice --> Undefined index: tingkat /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/set_kelas/views/form.php 49
ERROR - 2024-07-08 15:37:35 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/set_kelas/views/form.php 49
ERROR - 2024-07-08 15:37:35 --> Severity: Notice --> Undefined index: kelas /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/set_kelas/views/form.php 59
ERROR - 2024-07-08 15:37:35 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/set_kelas/views/form.php 49
ERROR - 2024-07-08 15:37:35 --> Severity: Notice --> Undefined index: kelas /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/set_kelas/views/form.php 59
ERROR - 2024-07-08 15:37:35 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/set_kelas/views/form.php 49
ERROR - 2024-07-08 15:37:35 --> Severity: Notice --> Undefined index: kelas /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/set_kelas/views/form.php 59
ERROR - 2024-07-08 15:37:35 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/set_kelas/views/form.php 49
ERROR - 2024-07-08 15:37:35 --> Severity: Notice --> Undefined index: kelas /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/set_kelas/views/form.php 59
ERROR - 2024-07-08 15:37:35 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/set_kelas/views/form.php 49
ERROR - 2024-07-08 15:37:35 --> Severity: Notice --> Undefined index: kelas /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/set_kelas/views/form.php 59
ERROR - 2024-07-08 15:37:35 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/set_kelas/views/form.php 49
ERROR - 2024-07-08 15:37:35 --> Severity: Notice --> Undefined index: kelas /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/set_kelas/views/form.php 59
ERROR - 2024-07-08 15:37:35 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/set_kelas/views/form.php 49
ERROR - 2024-07-08 15:37:35 --> Severity: Notice --> Undefined index: kelas /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/set_kelas/views/form.php 59
ERROR - 2024-07-08 15:37:35 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/set_kelas/views/form.php 49
ERROR - 2024-07-08 15:37:35 --> Severity: Notice --> Undefined index: kelas /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/set_kelas/views/form.php 59
ERROR - 2024-07-08 15:37:35 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/set_kelas/views/form.php 49
ERROR - 2024-07-08 15:37:35 --> Severity: Notice --> Undefined index: kelas /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/set_kelas/views/form.php 59
ERROR - 2024-07-08 15:37:35 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/set_kelas/views/form.php 49
ERROR - 2024-07-08 15:37:35 --> Severity: Notice --> Undefined index: kelas /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/set_kelas/views/form.php 59
ERROR - 2024-07-08 15:37:35 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/set_kelas/views/form.php 49
ERROR - 2024-07-08 15:37:35 --> Severity: Notice --> Undefined index: kelas /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/set_kelas/views/form.php 59
ERROR - 2024-07-08 15:37:35 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/set_kelas/views/form.php 49
ERROR - 2024-07-08 15:37:35 --> Severity: Notice --> Undefined index: kelas /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/set_kelas/views/form.php 59
ERROR - 2024-07-08 15:37:35 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/set_kelas/views/form.php 49
ERROR - 2024-07-08 15:37:35 --> Severity: Notice --> Undefined index: kelas /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/set_kelas/views/form.php 59
ERROR - 2024-07-08 15:37:35 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/set_kelas/views/form.php 49
ERROR - 2024-07-08 15:37:35 --> Severity: Notice --> Undefined index: kelas /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/set_kelas/views/form.php 59
ERROR - 2024-07-08 15:37:35 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/set_kelas/views/form.php 49
ERROR - 2024-07-08 15:37:35 --> Severity: Notice --> Undefined index: kelas /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/set_kelas/views/form.php 59
ERROR - 2024-07-08 15:37:35 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/set_kelas/views/form.php 49
ERROR - 2024-07-08 15:37:35 --> Severity: Notice --> Undefined index: kelas /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/set_kelas/views/form.php 59
ERROR - 2024-07-08 15:37:35 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/set_kelas/views/form.php 49
ERROR - 2024-07-08 15:37:35 --> Severity: Notice --> Undefined index: kelas /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/set_kelas/views/form.php 59
ERROR - 2024-07-08 15:37:35 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/set_kelas/views/form.php 49
ERROR - 2024-07-08 15:37:35 --> Severity: Notice --> Undefined index: kelas /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/set_kelas/views/form.php 59
ERROR - 2024-07-08 15:37:35 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/set_kelas/views/form.php 49
ERROR - 2024-07-08 15:37:35 --> Severity: Notice --> Undefined index: kelas /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/set_kelas/views/form.php 59
ERROR - 2024-07-08 15:37:35 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/set_kelas/views/form.php 49
ERROR - 2024-07-08 15:37:35 --> Severity: Notice --> Undefined index: kelas /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/set_kelas/views/form.php 59
ERROR - 2024-07-08 15:37:35 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/set_kelas/views/form.php 49
ERROR - 2024-07-08 15:37:35 --> Severity: Notice --> Undefined index: kelas /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/set_kelas/views/form.php 59
ERROR - 2024-07-08 15:37:35 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/set_kelas/views/form.php 49
ERROR - 2024-07-08 15:37:35 --> Severity: Notice --> Undefined index: kelas /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/set_kelas/views/form.php 59
ERROR - 2024-07-08 15:37:35 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/set_kelas/views/form.php 49
ERROR - 2024-07-08 15:37:35 --> Severity: Notice --> Undefined index: kelas /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/set_kelas/views/form.php 59
ERROR - 2024-07-08 15:37:35 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/set_kelas/views/form.php 49
ERROR - 2024-07-08 15:37:35 --> Severity: Notice --> Undefined index: kelas /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/set_kelas/views/form.php 59
ERROR - 2024-07-08 15:37:35 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/set_kelas/views/form.php 49
ERROR - 2024-07-08 15:37:35 --> Severity: Notice --> Undefined index: kelas /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/set_kelas/views/form.php 59
ERROR - 2024-07-08 15:37:35 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/set_kelas/views/form.php 49
ERROR - 2024-07-08 15:37:35 --> Severity: Notice --> Undefined index: kelas /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/set_kelas/views/form.php 59
ERROR - 2024-07-08 15:37:35 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/set_kelas/views/form.php 49
ERROR - 2024-07-08 15:37:35 --> Severity: Notice --> Undefined index: kelas /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/set_kelas/views/form.php 59
ERROR - 2024-07-08 15:37:35 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/set_kelas/views/form.php 49
ERROR - 2024-07-08 15:37:35 --> Severity: Notice --> Undefined index: kelas /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/set_kelas/views/form.php 59
ERROR - 2024-07-08 15:37:35 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/set_kelas/views/form.php 49
ERROR - 2024-07-08 15:37:35 --> Severity: Notice --> Undefined index: kelas /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/set_kelas/views/form.php 59
ERROR - 2024-07-08 15:37:35 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/set_kelas/views/form.php 49
ERROR - 2024-07-08 15:37:35 --> Severity: Notice --> Undefined index: kelas /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/set_kelas/views/form.php 59
ERROR - 2024-07-08 15:37:35 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/set_kelas/views/form.php 49
ERROR - 2024-07-08 15:37:35 --> Severity: Notice --> Undefined index: kelas /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/set_kelas/views/form.php 59
ERROR - 2024-07-08 15:37:35 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/set_kelas/views/form.php 49
ERROR - 2024-07-08 15:37:35 --> Severity: Notice --> Undefined index: kelas /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/set_kelas/views/form.php 59
ERROR - 2024-07-08 15:37:35 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/set_kelas/views/form.php 49
ERROR - 2024-07-08 15:37:35 --> Severity: Notice --> Undefined index: kelas /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/set_kelas/views/form.php 59
ERROR - 2024-07-08 15:37:35 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/set_kelas/views/form.php 49
ERROR - 2024-07-08 15:37:35 --> Severity: Notice --> Undefined index: kelas /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/set_kelas/views/form.php 59
ERROR - 2024-07-08 15:37:35 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/set_kelas/views/form.php 49
ERROR - 2024-07-08 15:37:35 --> Severity: Notice --> Undefined index: kelas /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/set_kelas/views/form.php 59
ERROR - 2024-07-08 15:37:35 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/set_kelas/views/form.php 49
ERROR - 2024-07-08 15:37:35 --> Severity: Notice --> Undefined index: kelas /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/set_kelas/views/form.php 59
DEBUG - 2024-07-08 15:37:35 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/set_kelas/views/form.php
DEBUG - 2024-07-08 15:37:35 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-07-08 15:37:35 --> Final output sent to browser
DEBUG - 2024-07-08 15:37:35 --> Total execution time: 0.0776
INFO - 2024-07-08 15:38:04 --> Config Class Initialized
INFO - 2024-07-08 15:38:04 --> Hooks Class Initialized
DEBUG - 2024-07-08 15:38:04 --> UTF-8 Support Enabled
INFO - 2024-07-08 15:38:04 --> Utf8 Class Initialized
INFO - 2024-07-08 15:38:04 --> URI Class Initialized
INFO - 2024-07-08 15:38:04 --> Router Class Initialized
INFO - 2024-07-08 15:38:04 --> Output Class Initialized
INFO - 2024-07-08 15:38:04 --> Security Class Initialized
DEBUG - 2024-07-08 15:38:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-07-08 15:38:04 --> Input Class Initialized
INFO - 2024-07-08 15:38:04 --> Language Class Initialized
INFO - 2024-07-08 15:38:04 --> Language Class Initialized
INFO - 2024-07-08 15:38:04 --> Config Class Initialized
INFO - 2024-07-08 15:38:04 --> Loader Class Initialized
INFO - 2024-07-08 15:38:04 --> Helper loaded: url_helper
INFO - 2024-07-08 15:38:04 --> Helper loaded: file_helper
INFO - 2024-07-08 15:38:04 --> Helper loaded: form_helper
INFO - 2024-07-08 15:38:04 --> Helper loaded: my_helper
INFO - 2024-07-08 15:38:04 --> Database Driver Class Initialized
INFO - 2024-07-08 15:38:04 --> Session: Class initialized using 'files' driver.
INFO - 2024-07-08 15:38:04 --> Controller Class Initialized
DEBUG - 2024-07-08 15:38:04 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/data_siswa/views/list.php
DEBUG - 2024-07-08 15:38:04 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-07-08 15:38:04 --> Final output sent to browser
DEBUG - 2024-07-08 15:38:04 --> Total execution time: 0.0306
INFO - 2024-07-08 15:38:04 --> Config Class Initialized
INFO - 2024-07-08 15:38:04 --> Hooks Class Initialized
DEBUG - 2024-07-08 15:38:04 --> UTF-8 Support Enabled
INFO - 2024-07-08 15:38:04 --> Utf8 Class Initialized
INFO - 2024-07-08 15:38:04 --> URI Class Initialized
INFO - 2024-07-08 15:38:04 --> Router Class Initialized
INFO - 2024-07-08 15:38:04 --> Output Class Initialized
INFO - 2024-07-08 15:38:04 --> Security Class Initialized
DEBUG - 2024-07-08 15:38:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-07-08 15:38:04 --> Input Class Initialized
INFO - 2024-07-08 15:38:04 --> Language Class Initialized
ERROR - 2024-07-08 15:38:04 --> 404 Page Not Found: /index
INFO - 2024-07-08 15:38:04 --> Config Class Initialized
INFO - 2024-07-08 15:38:04 --> Hooks Class Initialized
DEBUG - 2024-07-08 15:38:04 --> UTF-8 Support Enabled
INFO - 2024-07-08 15:38:04 --> Utf8 Class Initialized
INFO - 2024-07-08 15:38:04 --> URI Class Initialized
INFO - 2024-07-08 15:38:04 --> Router Class Initialized
INFO - 2024-07-08 15:38:04 --> Output Class Initialized
INFO - 2024-07-08 15:38:04 --> Security Class Initialized
DEBUG - 2024-07-08 15:38:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-07-08 15:38:04 --> Input Class Initialized
INFO - 2024-07-08 15:38:04 --> Language Class Initialized
INFO - 2024-07-08 15:38:04 --> Language Class Initialized
INFO - 2024-07-08 15:38:04 --> Config Class Initialized
INFO - 2024-07-08 15:38:04 --> Loader Class Initialized
INFO - 2024-07-08 15:38:04 --> Helper loaded: url_helper
INFO - 2024-07-08 15:38:04 --> Helper loaded: file_helper
INFO - 2024-07-08 15:38:04 --> Helper loaded: form_helper
INFO - 2024-07-08 15:38:04 --> Helper loaded: my_helper
INFO - 2024-07-08 15:38:04 --> Database Driver Class Initialized
INFO - 2024-07-08 15:38:04 --> Session: Class initialized using 'files' driver.
INFO - 2024-07-08 15:38:04 --> Controller Class Initialized
INFO - 2024-07-08 15:38:07 --> Config Class Initialized
INFO - 2024-07-08 15:38:07 --> Hooks Class Initialized
DEBUG - 2024-07-08 15:38:07 --> UTF-8 Support Enabled
INFO - 2024-07-08 15:38:07 --> Utf8 Class Initialized
INFO - 2024-07-08 15:38:07 --> URI Class Initialized
INFO - 2024-07-08 15:38:07 --> Router Class Initialized
INFO - 2024-07-08 15:38:07 --> Output Class Initialized
INFO - 2024-07-08 15:38:07 --> Security Class Initialized
DEBUG - 2024-07-08 15:38:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-07-08 15:38:07 --> Input Class Initialized
INFO - 2024-07-08 15:38:07 --> Language Class Initialized
INFO - 2024-07-08 15:38:07 --> Language Class Initialized
INFO - 2024-07-08 15:38:07 --> Config Class Initialized
INFO - 2024-07-08 15:38:07 --> Loader Class Initialized
INFO - 2024-07-08 15:38:07 --> Helper loaded: url_helper
INFO - 2024-07-08 15:38:07 --> Helper loaded: file_helper
INFO - 2024-07-08 15:38:07 --> Helper loaded: form_helper
INFO - 2024-07-08 15:38:07 --> Helper loaded: my_helper
INFO - 2024-07-08 15:38:07 --> Database Driver Class Initialized
INFO - 2024-07-08 15:38:07 --> Session: Class initialized using 'files' driver.
INFO - 2024-07-08 15:38:07 --> Controller Class Initialized
ERROR - 2024-07-08 15:38:07 --> Severity: Notice --> Undefined variable: status_form /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/data_siswa/views/form.php 231
DEBUG - 2024-07-08 15:38:07 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/data_siswa/views/form.php
DEBUG - 2024-07-08 15:38:07 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-07-08 15:38:07 --> Final output sent to browser
DEBUG - 2024-07-08 15:38:07 --> Total execution time: 0.0362
INFO - 2024-07-08 15:38:13 --> Config Class Initialized
INFO - 2024-07-08 15:38:13 --> Hooks Class Initialized
DEBUG - 2024-07-08 15:38:13 --> UTF-8 Support Enabled
INFO - 2024-07-08 15:38:13 --> Utf8 Class Initialized
INFO - 2024-07-08 15:38:13 --> URI Class Initialized
INFO - 2024-07-08 15:38:13 --> Router Class Initialized
INFO - 2024-07-08 15:38:13 --> Output Class Initialized
INFO - 2024-07-08 15:38:13 --> Security Class Initialized
DEBUG - 2024-07-08 15:38:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-07-08 15:38:13 --> Input Class Initialized
INFO - 2024-07-08 15:38:13 --> Language Class Initialized
INFO - 2024-07-08 15:38:13 --> Language Class Initialized
INFO - 2024-07-08 15:38:13 --> Config Class Initialized
INFO - 2024-07-08 15:38:13 --> Loader Class Initialized
INFO - 2024-07-08 15:38:13 --> Helper loaded: url_helper
INFO - 2024-07-08 15:38:13 --> Helper loaded: file_helper
INFO - 2024-07-08 15:38:13 --> Helper loaded: form_helper
INFO - 2024-07-08 15:38:13 --> Helper loaded: my_helper
INFO - 2024-07-08 15:38:13 --> Database Driver Class Initialized
INFO - 2024-07-08 15:38:13 --> Session: Class initialized using 'files' driver.
INFO - 2024-07-08 15:38:13 --> Controller Class Initialized
INFO - 2024-07-08 15:38:13 --> Upload Class Initialized
INFO - 2024-07-08 15:38:13 --> Language file loaded: language/english/upload_lang.php
ERROR - 2024-07-08 15:38:13 --> The upload path does not appear to be valid.
INFO - 2024-07-08 15:38:14 --> Config Class Initialized
INFO - 2024-07-08 15:38:14 --> Hooks Class Initialized
DEBUG - 2024-07-08 15:38:14 --> UTF-8 Support Enabled
INFO - 2024-07-08 15:38:14 --> Utf8 Class Initialized
INFO - 2024-07-08 15:38:14 --> URI Class Initialized
INFO - 2024-07-08 15:38:14 --> Router Class Initialized
INFO - 2024-07-08 15:38:14 --> Output Class Initialized
INFO - 2024-07-08 15:38:14 --> Security Class Initialized
DEBUG - 2024-07-08 15:38:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-07-08 15:38:14 --> Input Class Initialized
INFO - 2024-07-08 15:38:14 --> Language Class Initialized
INFO - 2024-07-08 15:38:14 --> Language Class Initialized
INFO - 2024-07-08 15:38:14 --> Config Class Initialized
INFO - 2024-07-08 15:38:14 --> Loader Class Initialized
INFO - 2024-07-08 15:38:14 --> Helper loaded: url_helper
INFO - 2024-07-08 15:38:14 --> Helper loaded: file_helper
INFO - 2024-07-08 15:38:14 --> Helper loaded: form_helper
INFO - 2024-07-08 15:38:14 --> Helper loaded: my_helper
INFO - 2024-07-08 15:38:14 --> Database Driver Class Initialized
INFO - 2024-07-08 15:38:14 --> Session: Class initialized using 'files' driver.
INFO - 2024-07-08 15:38:14 --> Controller Class Initialized
DEBUG - 2024-07-08 15:38:14 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/data_siswa/views/list.php
DEBUG - 2024-07-08 15:38:14 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-07-08 15:38:14 --> Final output sent to browser
DEBUG - 2024-07-08 15:38:14 --> Total execution time: 0.0497
INFO - 2024-07-08 15:38:14 --> Config Class Initialized
INFO - 2024-07-08 15:38:14 --> Hooks Class Initialized
DEBUG - 2024-07-08 15:38:14 --> UTF-8 Support Enabled
INFO - 2024-07-08 15:38:14 --> Utf8 Class Initialized
INFO - 2024-07-08 15:38:14 --> URI Class Initialized
INFO - 2024-07-08 15:38:14 --> Router Class Initialized
INFO - 2024-07-08 15:38:14 --> Output Class Initialized
INFO - 2024-07-08 15:38:14 --> Security Class Initialized
DEBUG - 2024-07-08 15:38:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-07-08 15:38:14 --> Input Class Initialized
INFO - 2024-07-08 15:38:14 --> Language Class Initialized
ERROR - 2024-07-08 15:38:14 --> 404 Page Not Found: /index
INFO - 2024-07-08 15:38:14 --> Config Class Initialized
INFO - 2024-07-08 15:38:14 --> Hooks Class Initialized
DEBUG - 2024-07-08 15:38:14 --> UTF-8 Support Enabled
INFO - 2024-07-08 15:38:14 --> Utf8 Class Initialized
INFO - 2024-07-08 15:38:14 --> URI Class Initialized
INFO - 2024-07-08 15:38:14 --> Router Class Initialized
INFO - 2024-07-08 15:38:14 --> Output Class Initialized
INFO - 2024-07-08 15:38:14 --> Security Class Initialized
DEBUG - 2024-07-08 15:38:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-07-08 15:38:14 --> Input Class Initialized
INFO - 2024-07-08 15:38:14 --> Language Class Initialized
INFO - 2024-07-08 15:38:14 --> Language Class Initialized
INFO - 2024-07-08 15:38:14 --> Config Class Initialized
INFO - 2024-07-08 15:38:14 --> Loader Class Initialized
INFO - 2024-07-08 15:38:14 --> Helper loaded: url_helper
INFO - 2024-07-08 15:38:14 --> Helper loaded: file_helper
INFO - 2024-07-08 15:38:14 --> Helper loaded: form_helper
INFO - 2024-07-08 15:38:14 --> Helper loaded: my_helper
INFO - 2024-07-08 15:38:14 --> Database Driver Class Initialized
INFO - 2024-07-08 15:38:14 --> Session: Class initialized using 'files' driver.
INFO - 2024-07-08 15:38:14 --> Controller Class Initialized
INFO - 2024-07-08 15:38:16 --> Config Class Initialized
INFO - 2024-07-08 15:38:16 --> Hooks Class Initialized
DEBUG - 2024-07-08 15:38:16 --> UTF-8 Support Enabled
INFO - 2024-07-08 15:38:16 --> Utf8 Class Initialized
INFO - 2024-07-08 15:38:16 --> URI Class Initialized
INFO - 2024-07-08 15:38:16 --> Router Class Initialized
INFO - 2024-07-08 15:38:16 --> Output Class Initialized
INFO - 2024-07-08 15:38:16 --> Security Class Initialized
DEBUG - 2024-07-08 15:38:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-07-08 15:38:16 --> Input Class Initialized
INFO - 2024-07-08 15:38:16 --> Language Class Initialized
INFO - 2024-07-08 15:38:16 --> Language Class Initialized
INFO - 2024-07-08 15:38:16 --> Config Class Initialized
INFO - 2024-07-08 15:38:16 --> Loader Class Initialized
INFO - 2024-07-08 15:38:16 --> Helper loaded: url_helper
INFO - 2024-07-08 15:38:16 --> Helper loaded: file_helper
INFO - 2024-07-08 15:38:16 --> Helper loaded: form_helper
INFO - 2024-07-08 15:38:16 --> Helper loaded: my_helper
INFO - 2024-07-08 15:38:16 --> Database Driver Class Initialized
INFO - 2024-07-08 15:38:16 --> Session: Class initialized using 'files' driver.
INFO - 2024-07-08 15:38:16 --> Controller Class Initialized
ERROR - 2024-07-08 15:38:16 --> Severity: Notice --> Undefined variable: status_form /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/data_siswa/views/form.php 231
DEBUG - 2024-07-08 15:38:16 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/data_siswa/views/form.php
DEBUG - 2024-07-08 15:38:16 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-07-08 15:38:16 --> Final output sent to browser
DEBUG - 2024-07-08 15:38:16 --> Total execution time: 0.0356
INFO - 2024-07-08 15:38:22 --> Config Class Initialized
INFO - 2024-07-08 15:38:22 --> Hooks Class Initialized
DEBUG - 2024-07-08 15:38:22 --> UTF-8 Support Enabled
INFO - 2024-07-08 15:38:22 --> Utf8 Class Initialized
INFO - 2024-07-08 15:38:22 --> URI Class Initialized
INFO - 2024-07-08 15:38:22 --> Router Class Initialized
INFO - 2024-07-08 15:38:22 --> Output Class Initialized
INFO - 2024-07-08 15:38:22 --> Security Class Initialized
DEBUG - 2024-07-08 15:38:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-07-08 15:38:22 --> Input Class Initialized
INFO - 2024-07-08 15:38:22 --> Language Class Initialized
INFO - 2024-07-08 15:38:22 --> Language Class Initialized
INFO - 2024-07-08 15:38:22 --> Config Class Initialized
INFO - 2024-07-08 15:38:22 --> Loader Class Initialized
INFO - 2024-07-08 15:38:22 --> Helper loaded: url_helper
INFO - 2024-07-08 15:38:22 --> Helper loaded: file_helper
INFO - 2024-07-08 15:38:22 --> Helper loaded: form_helper
INFO - 2024-07-08 15:38:22 --> Helper loaded: my_helper
INFO - 2024-07-08 15:38:22 --> Database Driver Class Initialized
INFO - 2024-07-08 15:38:22 --> Session: Class initialized using 'files' driver.
INFO - 2024-07-08 15:38:22 --> Controller Class Initialized
DEBUG - 2024-07-08 15:38:22 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/set_kelas/views/list.php
DEBUG - 2024-07-08 15:38:22 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-07-08 15:38:22 --> Final output sent to browser
DEBUG - 2024-07-08 15:38:22 --> Total execution time: 0.0553
INFO - 2024-07-08 15:38:24 --> Config Class Initialized
INFO - 2024-07-08 15:38:24 --> Hooks Class Initialized
DEBUG - 2024-07-08 15:38:24 --> UTF-8 Support Enabled
INFO - 2024-07-08 15:38:24 --> Utf8 Class Initialized
INFO - 2024-07-08 15:38:24 --> URI Class Initialized
INFO - 2024-07-08 15:38:24 --> Router Class Initialized
INFO - 2024-07-08 15:38:24 --> Output Class Initialized
INFO - 2024-07-08 15:38:24 --> Security Class Initialized
DEBUG - 2024-07-08 15:38:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-07-08 15:38:24 --> Input Class Initialized
INFO - 2024-07-08 15:38:24 --> Language Class Initialized
INFO - 2024-07-08 15:38:24 --> Language Class Initialized
INFO - 2024-07-08 15:38:24 --> Config Class Initialized
INFO - 2024-07-08 15:38:24 --> Loader Class Initialized
INFO - 2024-07-08 15:38:24 --> Helper loaded: url_helper
INFO - 2024-07-08 15:38:24 --> Helper loaded: file_helper
INFO - 2024-07-08 15:38:24 --> Helper loaded: form_helper
INFO - 2024-07-08 15:38:24 --> Helper loaded: my_helper
INFO - 2024-07-08 15:38:24 --> Database Driver Class Initialized
INFO - 2024-07-08 15:38:24 --> Session: Class initialized using 'files' driver.
INFO - 2024-07-08 15:38:24 --> Controller Class Initialized
ERROR - 2024-07-08 15:38:24 --> Severity: Notice --> Undefined index: tingkat /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/set_kelas/views/form.php 49
ERROR - 2024-07-08 15:38:24 --> Severity: Notice --> Undefined index: tingkat /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/set_kelas/views/form.php 49
ERROR - 2024-07-08 15:38:24 --> Severity: Notice --> Undefined index: tingkat /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/set_kelas/views/form.php 49
ERROR - 2024-07-08 15:38:24 --> Severity: Notice --> Undefined index: tingkat /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/set_kelas/views/form.php 49
ERROR - 2024-07-08 15:38:24 --> Severity: Notice --> Undefined index: tingkat /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/set_kelas/views/form.php 49
ERROR - 2024-07-08 15:38:24 --> Severity: Notice --> Undefined index: tingkat /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/set_kelas/views/form.php 49
ERROR - 2024-07-08 15:38:24 --> Severity: Notice --> Undefined index: tingkat /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/set_kelas/views/form.php 49
ERROR - 2024-07-08 15:38:24 --> Severity: Notice --> Undefined index: tingkat /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/set_kelas/views/form.php 49
ERROR - 2024-07-08 15:38:24 --> Severity: Notice --> Undefined index: tingkat /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/set_kelas/views/form.php 49
ERROR - 2024-07-08 15:38:24 --> Severity: Notice --> Undefined index: tingkat /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/set_kelas/views/form.php 49
ERROR - 2024-07-08 15:38:24 --> Severity: Notice --> Undefined index: tingkat /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/set_kelas/views/form.php 49
ERROR - 2024-07-08 15:38:24 --> Severity: Notice --> Undefined index: tingkat /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/set_kelas/views/form.php 49
ERROR - 2024-07-08 15:38:24 --> Severity: Notice --> Undefined index: tingkat /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/set_kelas/views/form.php 49
ERROR - 2024-07-08 15:38:24 --> Severity: Notice --> Undefined index: tingkat /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/set_kelas/views/form.php 49
ERROR - 2024-07-08 15:38:24 --> Severity: Notice --> Undefined index: tingkat /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/set_kelas/views/form.php 49
ERROR - 2024-07-08 15:38:24 --> Severity: Notice --> Undefined index: tingkat /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/set_kelas/views/form.php 49
ERROR - 2024-07-08 15:38:24 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/set_kelas/views/form.php 49
ERROR - 2024-07-08 15:38:24 --> Severity: Notice --> Undefined index: kelas /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/set_kelas/views/form.php 59
ERROR - 2024-07-08 15:38:24 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/set_kelas/views/form.php 49
ERROR - 2024-07-08 15:38:24 --> Severity: Notice --> Undefined index: kelas /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/set_kelas/views/form.php 59
ERROR - 2024-07-08 15:38:24 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/set_kelas/views/form.php 49
ERROR - 2024-07-08 15:38:24 --> Severity: Notice --> Undefined index: kelas /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/set_kelas/views/form.php 59
ERROR - 2024-07-08 15:38:24 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/set_kelas/views/form.php 49
ERROR - 2024-07-08 15:38:24 --> Severity: Notice --> Undefined index: kelas /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/set_kelas/views/form.php 59
ERROR - 2024-07-08 15:38:24 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/set_kelas/views/form.php 49
ERROR - 2024-07-08 15:38:24 --> Severity: Notice --> Undefined index: kelas /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/set_kelas/views/form.php 59
ERROR - 2024-07-08 15:38:24 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/set_kelas/views/form.php 49
ERROR - 2024-07-08 15:38:24 --> Severity: Notice --> Undefined index: kelas /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/set_kelas/views/form.php 59
ERROR - 2024-07-08 15:38:24 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/set_kelas/views/form.php 49
ERROR - 2024-07-08 15:38:24 --> Severity: Notice --> Undefined index: kelas /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/set_kelas/views/form.php 59
ERROR - 2024-07-08 15:38:24 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/set_kelas/views/form.php 49
ERROR - 2024-07-08 15:38:24 --> Severity: Notice --> Undefined index: kelas /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/set_kelas/views/form.php 59
ERROR - 2024-07-08 15:38:24 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/set_kelas/views/form.php 49
ERROR - 2024-07-08 15:38:24 --> Severity: Notice --> Undefined index: kelas /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/set_kelas/views/form.php 59
ERROR - 2024-07-08 15:38:24 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/set_kelas/views/form.php 49
ERROR - 2024-07-08 15:38:24 --> Severity: Notice --> Undefined index: kelas /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/set_kelas/views/form.php 59
ERROR - 2024-07-08 15:38:24 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/set_kelas/views/form.php 49
ERROR - 2024-07-08 15:38:24 --> Severity: Notice --> Undefined index: kelas /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/set_kelas/views/form.php 59
ERROR - 2024-07-08 15:38:24 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/set_kelas/views/form.php 49
ERROR - 2024-07-08 15:38:24 --> Severity: Notice --> Undefined index: kelas /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/set_kelas/views/form.php 59
ERROR - 2024-07-08 15:38:24 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/set_kelas/views/form.php 49
ERROR - 2024-07-08 15:38:24 --> Severity: Notice --> Undefined index: kelas /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/set_kelas/views/form.php 59
ERROR - 2024-07-08 15:38:24 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/set_kelas/views/form.php 49
ERROR - 2024-07-08 15:38:24 --> Severity: Notice --> Undefined index: kelas /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/set_kelas/views/form.php 59
ERROR - 2024-07-08 15:38:24 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/set_kelas/views/form.php 49
ERROR - 2024-07-08 15:38:24 --> Severity: Notice --> Undefined index: kelas /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/set_kelas/views/form.php 59
ERROR - 2024-07-08 15:38:24 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/set_kelas/views/form.php 49
ERROR - 2024-07-08 15:38:24 --> Severity: Notice --> Undefined index: kelas /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/set_kelas/views/form.php 59
ERROR - 2024-07-08 15:38:24 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/set_kelas/views/form.php 49
ERROR - 2024-07-08 15:38:24 --> Severity: Notice --> Undefined index: kelas /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/set_kelas/views/form.php 59
ERROR - 2024-07-08 15:38:24 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/set_kelas/views/form.php 49
ERROR - 2024-07-08 15:38:24 --> Severity: Notice --> Undefined index: kelas /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/set_kelas/views/form.php 59
ERROR - 2024-07-08 15:38:24 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/set_kelas/views/form.php 49
ERROR - 2024-07-08 15:38:24 --> Severity: Notice --> Undefined index: kelas /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/set_kelas/views/form.php 59
ERROR - 2024-07-08 15:38:24 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/set_kelas/views/form.php 49
ERROR - 2024-07-08 15:38:24 --> Severity: Notice --> Undefined index: kelas /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/set_kelas/views/form.php 59
ERROR - 2024-07-08 15:38:24 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/set_kelas/views/form.php 49
ERROR - 2024-07-08 15:38:24 --> Severity: Notice --> Undefined index: kelas /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/set_kelas/views/form.php 59
ERROR - 2024-07-08 15:38:24 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/set_kelas/views/form.php 49
ERROR - 2024-07-08 15:38:24 --> Severity: Notice --> Undefined index: kelas /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/set_kelas/views/form.php 59
ERROR - 2024-07-08 15:38:24 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/set_kelas/views/form.php 49
ERROR - 2024-07-08 15:38:24 --> Severity: Notice --> Undefined index: kelas /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/set_kelas/views/form.php 59
ERROR - 2024-07-08 15:38:24 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/set_kelas/views/form.php 49
ERROR - 2024-07-08 15:38:24 --> Severity: Notice --> Undefined index: kelas /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/set_kelas/views/form.php 59
ERROR - 2024-07-08 15:38:24 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/set_kelas/views/form.php 49
ERROR - 2024-07-08 15:38:24 --> Severity: Notice --> Undefined index: kelas /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/set_kelas/views/form.php 59
ERROR - 2024-07-08 15:38:24 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/set_kelas/views/form.php 49
ERROR - 2024-07-08 15:38:24 --> Severity: Notice --> Undefined index: kelas /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/set_kelas/views/form.php 59
ERROR - 2024-07-08 15:38:24 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/set_kelas/views/form.php 49
ERROR - 2024-07-08 15:38:24 --> Severity: Notice --> Undefined index: kelas /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/set_kelas/views/form.php 59
ERROR - 2024-07-08 15:38:24 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/set_kelas/views/form.php 49
ERROR - 2024-07-08 15:38:24 --> Severity: Notice --> Undefined index: kelas /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/set_kelas/views/form.php 59
ERROR - 2024-07-08 15:38:24 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/set_kelas/views/form.php 49
ERROR - 2024-07-08 15:38:24 --> Severity: Notice --> Undefined index: kelas /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/set_kelas/views/form.php 59
ERROR - 2024-07-08 15:38:24 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/set_kelas/views/form.php 49
ERROR - 2024-07-08 15:38:24 --> Severity: Notice --> Undefined index: kelas /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/set_kelas/views/form.php 59
ERROR - 2024-07-08 15:38:24 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/set_kelas/views/form.php 49
ERROR - 2024-07-08 15:38:24 --> Severity: Notice --> Undefined index: kelas /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/set_kelas/views/form.php 59
ERROR - 2024-07-08 15:38:24 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/set_kelas/views/form.php 49
ERROR - 2024-07-08 15:38:24 --> Severity: Notice --> Undefined index: kelas /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/set_kelas/views/form.php 59
ERROR - 2024-07-08 15:38:24 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/set_kelas/views/form.php 49
ERROR - 2024-07-08 15:38:24 --> Severity: Notice --> Undefined index: kelas /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/set_kelas/views/form.php 59
ERROR - 2024-07-08 15:38:24 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/set_kelas/views/form.php 49
ERROR - 2024-07-08 15:38:24 --> Severity: Notice --> Undefined index: kelas /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/set_kelas/views/form.php 59
ERROR - 2024-07-08 15:38:24 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/set_kelas/views/form.php 49
ERROR - 2024-07-08 15:38:24 --> Severity: Notice --> Undefined index: kelas /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/set_kelas/views/form.php 59
ERROR - 2024-07-08 15:38:24 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/set_kelas/views/form.php 49
ERROR - 2024-07-08 15:38:24 --> Severity: Notice --> Undefined index: kelas /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/set_kelas/views/form.php 59
DEBUG - 2024-07-08 15:38:24 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/set_kelas/views/form.php
DEBUG - 2024-07-08 15:38:24 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-07-08 15:38:24 --> Final output sent to browser
DEBUG - 2024-07-08 15:38:24 --> Total execution time: 0.0947
INFO - 2024-07-08 15:39:29 --> Config Class Initialized
INFO - 2024-07-08 15:39:29 --> Hooks Class Initialized
DEBUG - 2024-07-08 15:39:29 --> UTF-8 Support Enabled
INFO - 2024-07-08 15:39:29 --> Utf8 Class Initialized
INFO - 2024-07-08 15:39:29 --> URI Class Initialized
INFO - 2024-07-08 15:39:29 --> Router Class Initialized
INFO - 2024-07-08 15:39:30 --> Output Class Initialized
INFO - 2024-07-08 15:39:30 --> Security Class Initialized
DEBUG - 2024-07-08 15:39:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-07-08 15:39:30 --> Input Class Initialized
INFO - 2024-07-08 15:39:30 --> Language Class Initialized
INFO - 2024-07-08 15:39:30 --> Language Class Initialized
INFO - 2024-07-08 15:39:30 --> Config Class Initialized
INFO - 2024-07-08 15:39:30 --> Loader Class Initialized
INFO - 2024-07-08 15:39:30 --> Helper loaded: url_helper
INFO - 2024-07-08 15:39:30 --> Helper loaded: file_helper
INFO - 2024-07-08 15:39:30 --> Helper loaded: form_helper
INFO - 2024-07-08 15:39:30 --> Helper loaded: my_helper
INFO - 2024-07-08 15:39:30 --> Database Driver Class Initialized
INFO - 2024-07-08 15:39:30 --> Session: Class initialized using 'files' driver.
INFO - 2024-07-08 15:39:30 --> Controller Class Initialized
INFO - 2024-07-08 15:39:30 --> Config Class Initialized
INFO - 2024-07-08 15:39:30 --> Hooks Class Initialized
DEBUG - 2024-07-08 15:39:30 --> UTF-8 Support Enabled
INFO - 2024-07-08 15:39:30 --> Utf8 Class Initialized
INFO - 2024-07-08 15:39:30 --> URI Class Initialized
INFO - 2024-07-08 15:39:30 --> Router Class Initialized
INFO - 2024-07-08 15:39:30 --> Output Class Initialized
INFO - 2024-07-08 15:39:30 --> Security Class Initialized
DEBUG - 2024-07-08 15:39:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-07-08 15:39:30 --> Input Class Initialized
INFO - 2024-07-08 15:39:30 --> Language Class Initialized
INFO - 2024-07-08 15:39:30 --> Language Class Initialized
INFO - 2024-07-08 15:39:30 --> Config Class Initialized
INFO - 2024-07-08 15:39:30 --> Loader Class Initialized
INFO - 2024-07-08 15:39:30 --> Helper loaded: url_helper
INFO - 2024-07-08 15:39:30 --> Helper loaded: file_helper
INFO - 2024-07-08 15:39:30 --> Helper loaded: form_helper
INFO - 2024-07-08 15:39:30 --> Helper loaded: my_helper
INFO - 2024-07-08 15:39:30 --> Database Driver Class Initialized
INFO - 2024-07-08 15:39:30 --> Session: Class initialized using 'files' driver.
INFO - 2024-07-08 15:39:30 --> Controller Class Initialized
DEBUG - 2024-07-08 15:39:30 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/set_kelas/views/list.php
DEBUG - 2024-07-08 15:39:30 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-07-08 15:39:30 --> Final output sent to browser
DEBUG - 2024-07-08 15:39:30 --> Total execution time: 0.0361
INFO - 2024-07-08 15:39:35 --> Config Class Initialized
INFO - 2024-07-08 15:39:35 --> Hooks Class Initialized
DEBUG - 2024-07-08 15:39:35 --> UTF-8 Support Enabled
INFO - 2024-07-08 15:39:35 --> Utf8 Class Initialized
INFO - 2024-07-08 15:39:35 --> URI Class Initialized
INFO - 2024-07-08 15:39:35 --> Router Class Initialized
INFO - 2024-07-08 15:39:35 --> Output Class Initialized
INFO - 2024-07-08 15:39:35 --> Security Class Initialized
DEBUG - 2024-07-08 15:39:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-07-08 15:39:35 --> Input Class Initialized
INFO - 2024-07-08 15:39:35 --> Language Class Initialized
INFO - 2024-07-08 15:39:35 --> Language Class Initialized
INFO - 2024-07-08 15:39:35 --> Config Class Initialized
INFO - 2024-07-08 15:39:35 --> Loader Class Initialized
INFO - 2024-07-08 15:39:35 --> Helper loaded: url_helper
INFO - 2024-07-08 15:39:35 --> Helper loaded: file_helper
INFO - 2024-07-08 15:39:35 --> Helper loaded: form_helper
INFO - 2024-07-08 15:39:35 --> Helper loaded: my_helper
INFO - 2024-07-08 15:39:35 --> Database Driver Class Initialized
INFO - 2024-07-08 15:39:35 --> Session: Class initialized using 'files' driver.
INFO - 2024-07-08 15:39:35 --> Controller Class Initialized
DEBUG - 2024-07-08 15:39:35 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/data_siswa/views/list.php
DEBUG - 2024-07-08 15:39:35 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-07-08 15:39:35 --> Final output sent to browser
DEBUG - 2024-07-08 15:39:35 --> Total execution time: 0.0345
INFO - 2024-07-08 15:39:35 --> Config Class Initialized
INFO - 2024-07-08 15:39:35 --> Hooks Class Initialized
DEBUG - 2024-07-08 15:39:35 --> UTF-8 Support Enabled
INFO - 2024-07-08 15:39:35 --> Utf8 Class Initialized
INFO - 2024-07-08 15:39:35 --> URI Class Initialized
INFO - 2024-07-08 15:39:35 --> Router Class Initialized
INFO - 2024-07-08 15:39:35 --> Output Class Initialized
INFO - 2024-07-08 15:39:35 --> Security Class Initialized
DEBUG - 2024-07-08 15:39:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-07-08 15:39:35 --> Input Class Initialized
INFO - 2024-07-08 15:39:35 --> Language Class Initialized
ERROR - 2024-07-08 15:39:35 --> 404 Page Not Found: /index
INFO - 2024-07-08 15:39:35 --> Config Class Initialized
INFO - 2024-07-08 15:39:35 --> Hooks Class Initialized
DEBUG - 2024-07-08 15:39:35 --> UTF-8 Support Enabled
INFO - 2024-07-08 15:39:35 --> Utf8 Class Initialized
INFO - 2024-07-08 15:39:35 --> URI Class Initialized
INFO - 2024-07-08 15:39:35 --> Router Class Initialized
INFO - 2024-07-08 15:39:35 --> Output Class Initialized
INFO - 2024-07-08 15:39:35 --> Security Class Initialized
DEBUG - 2024-07-08 15:39:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-07-08 15:39:35 --> Input Class Initialized
INFO - 2024-07-08 15:39:35 --> Language Class Initialized
INFO - 2024-07-08 15:39:35 --> Language Class Initialized
INFO - 2024-07-08 15:39:35 --> Config Class Initialized
INFO - 2024-07-08 15:39:35 --> Loader Class Initialized
INFO - 2024-07-08 15:39:35 --> Helper loaded: url_helper
INFO - 2024-07-08 15:39:35 --> Helper loaded: file_helper
INFO - 2024-07-08 15:39:35 --> Helper loaded: form_helper
INFO - 2024-07-08 15:39:35 --> Helper loaded: my_helper
INFO - 2024-07-08 15:39:35 --> Database Driver Class Initialized
INFO - 2024-07-08 15:39:35 --> Session: Class initialized using 'files' driver.
INFO - 2024-07-08 15:39:35 --> Controller Class Initialized
INFO - 2024-07-08 15:42:08 --> Config Class Initialized
INFO - 2024-07-08 15:42:08 --> Hooks Class Initialized
DEBUG - 2024-07-08 15:42:08 --> UTF-8 Support Enabled
INFO - 2024-07-08 15:42:08 --> Utf8 Class Initialized
INFO - 2024-07-08 15:42:08 --> URI Class Initialized
INFO - 2024-07-08 15:42:08 --> Router Class Initialized
INFO - 2024-07-08 15:42:08 --> Output Class Initialized
INFO - 2024-07-08 15:42:08 --> Security Class Initialized
DEBUG - 2024-07-08 15:42:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-07-08 15:42:08 --> Input Class Initialized
INFO - 2024-07-08 15:42:08 --> Language Class Initialized
INFO - 2024-07-08 15:42:08 --> Language Class Initialized
INFO - 2024-07-08 15:42:08 --> Config Class Initialized
INFO - 2024-07-08 15:42:08 --> Loader Class Initialized
INFO - 2024-07-08 15:42:08 --> Helper loaded: url_helper
INFO - 2024-07-08 15:42:08 --> Helper loaded: file_helper
INFO - 2024-07-08 15:42:08 --> Helper loaded: form_helper
INFO - 2024-07-08 15:42:08 --> Helper loaded: my_helper
INFO - 2024-07-08 15:42:08 --> Database Driver Class Initialized
INFO - 2024-07-08 15:42:08 --> Session: Class initialized using 'files' driver.
INFO - 2024-07-08 15:42:08 --> Controller Class Initialized
DEBUG - 2024-07-08 15:42:08 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/data_siswa/views/form_import.php
DEBUG - 2024-07-08 15:42:08 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-07-08 15:42:08 --> Final output sent to browser
DEBUG - 2024-07-08 15:42:08 --> Total execution time: 0.0367
INFO - 2024-07-08 15:42:14 --> Config Class Initialized
INFO - 2024-07-08 15:42:14 --> Hooks Class Initialized
DEBUG - 2024-07-08 15:42:14 --> UTF-8 Support Enabled
INFO - 2024-07-08 15:42:14 --> Utf8 Class Initialized
INFO - 2024-07-08 15:42:14 --> URI Class Initialized
INFO - 2024-07-08 15:42:14 --> Router Class Initialized
INFO - 2024-07-08 15:42:14 --> Output Class Initialized
INFO - 2024-07-08 15:42:14 --> Security Class Initialized
DEBUG - 2024-07-08 15:42:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-07-08 15:42:14 --> Input Class Initialized
INFO - 2024-07-08 15:42:14 --> Language Class Initialized
INFO - 2024-07-08 15:42:14 --> Language Class Initialized
INFO - 2024-07-08 15:42:14 --> Config Class Initialized
INFO - 2024-07-08 15:42:14 --> Loader Class Initialized
INFO - 2024-07-08 15:42:14 --> Helper loaded: url_helper
INFO - 2024-07-08 15:42:14 --> Helper loaded: file_helper
INFO - 2024-07-08 15:42:14 --> Helper loaded: form_helper
INFO - 2024-07-08 15:42:14 --> Helper loaded: my_helper
INFO - 2024-07-08 15:42:14 --> Database Driver Class Initialized
INFO - 2024-07-08 15:42:14 --> Session: Class initialized using 'files' driver.
INFO - 2024-07-08 15:42:14 --> Controller Class Initialized
ERROR - 2024-07-08 15:42:14 --> Severity: 8192 --> Array and string offset access syntax with curly braces is deprecated /www/wwwroot/report.mhis.link/bangka/secondary/application/third_party/PHP_Excel/PHPExcel/Reader/Excel5.php 1862
ERROR - 2024-07-08 15:42:14 --> Severity: 8192 --> Array and string offset access syntax with curly braces is deprecated /www/wwwroot/report.mhis.link/bangka/secondary/application/third_party/PHP_Excel/PHPExcel/Reader/Excel5.php 1921
ERROR - 2024-07-08 15:42:14 --> Severity: 8192 --> Array and string offset access syntax with curly braces is deprecated /www/wwwroot/report.mhis.link/bangka/secondary/application/third_party/PHP_Excel/PHPExcel/Reader/Excel5.php 2060
ERROR - 2024-07-08 15:42:14 --> Severity: 8192 --> Array and string offset access syntax with curly braces is deprecated /www/wwwroot/report.mhis.link/bangka/secondary/application/third_party/PHP_Excel/PHPExcel/Reader/Excel5.php 2085
ERROR - 2024-07-08 15:42:14 --> Severity: 8192 --> Array and string offset access syntax with curly braces is deprecated /www/wwwroot/report.mhis.link/bangka/secondary/application/third_party/PHP_Excel/PHPExcel/Reader/Excel5.php 2095
ERROR - 2024-07-08 15:42:14 --> Severity: 8192 --> Array and string offset access syntax with curly braces is deprecated /www/wwwroot/report.mhis.link/bangka/secondary/application/third_party/PHP_Excel/PHPExcel/Reader/Excel5.php 2113
ERROR - 2024-07-08 15:42:14 --> Severity: 8192 --> Array and string offset access syntax with curly braces is deprecated /www/wwwroot/report.mhis.link/bangka/secondary/application/third_party/PHP_Excel/PHPExcel/Reader/Excel5.php 2126
ERROR - 2024-07-08 15:42:14 --> Severity: 8192 --> Array and string offset access syntax with curly braces is deprecated /www/wwwroot/report.mhis.link/bangka/secondary/application/third_party/PHP_Excel/PHPExcel/Reader/Excel5.php 2130
ERROR - 2024-07-08 15:42:14 --> Severity: 8192 --> Array and string offset access syntax with curly braces is deprecated /www/wwwroot/report.mhis.link/bangka/secondary/application/third_party/PHP_Excel/PHPExcel/Reader/Excel5.php 2212
ERROR - 2024-07-08 15:42:14 --> Severity: 8192 --> Array and string offset access syntax with curly braces is deprecated /www/wwwroot/report.mhis.link/bangka/secondary/application/third_party/PHP_Excel/PHPExcel/Reader/Excel5.php 2336
ERROR - 2024-07-08 15:42:14 --> Severity: 8192 --> Array and string offset access syntax with curly braces is deprecated /www/wwwroot/report.mhis.link/bangka/secondary/application/third_party/PHP_Excel/PHPExcel/Reader/Excel5.php 2336
ERROR - 2024-07-08 15:42:14 --> Severity: 8192 --> Array and string offset access syntax with curly braces is deprecated /www/wwwroot/report.mhis.link/bangka/secondary/application/third_party/PHP_Excel/PHPExcel/Reader/Excel5.php 2336
ERROR - 2024-07-08 15:42:14 --> Severity: 8192 --> Array and string offset access syntax with curly braces is deprecated /www/wwwroot/report.mhis.link/bangka/secondary/application/third_party/PHP_Excel/PHPExcel/Reader/Excel5.php 2352
ERROR - 2024-07-08 15:42:14 --> Severity: 8192 --> Array and string offset access syntax with curly braces is deprecated /www/wwwroot/report.mhis.link/bangka/secondary/application/third_party/PHP_Excel/PHPExcel/Reader/Excel5.php 2352
ERROR - 2024-07-08 15:42:14 --> Severity: 8192 --> Array and string offset access syntax with curly braces is deprecated /www/wwwroot/report.mhis.link/bangka/secondary/application/third_party/PHP_Excel/PHPExcel/Reader/Excel5.php 2352
ERROR - 2024-07-08 15:42:14 --> Severity: 8192 --> Array and string offset access syntax with curly braces is deprecated /www/wwwroot/report.mhis.link/bangka/secondary/application/third_party/PHP_Excel/PHPExcel/Reader/Excel5.php 2368
ERROR - 2024-07-08 15:42:14 --> Severity: 8192 --> Array and string offset access syntax with curly braces is deprecated /www/wwwroot/report.mhis.link/bangka/secondary/application/third_party/PHP_Excel/PHPExcel/Reader/Excel5.php 2368
ERROR - 2024-07-08 15:42:14 --> Severity: 8192 --> Array and string offset access syntax with curly braces is deprecated /www/wwwroot/report.mhis.link/bangka/secondary/application/third_party/PHP_Excel/PHPExcel/Reader/Excel5.php 2368
ERROR - 2024-07-08 15:42:14 --> Severity: 8192 --> Array and string offset access syntax with curly braces is deprecated /www/wwwroot/report.mhis.link/bangka/secondary/application/third_party/PHP_Excel/PHPExcel/Reader/Excel5.php 2384
ERROR - 2024-07-08 15:42:14 --> Severity: 8192 --> Array and string offset access syntax with curly braces is deprecated /www/wwwroot/report.mhis.link/bangka/secondary/application/third_party/PHP_Excel/PHPExcel/Reader/Excel5.php 2384
ERROR - 2024-07-08 15:42:14 --> Severity: 8192 --> Array and string offset access syntax with curly braces is deprecated /www/wwwroot/report.mhis.link/bangka/secondary/application/third_party/PHP_Excel/PHPExcel/Reader/Excel5.php 2384
ERROR - 2024-07-08 15:42:14 --> Severity: 8192 --> Array and string offset access syntax with curly braces is deprecated /www/wwwroot/report.mhis.link/bangka/secondary/application/third_party/PHP_Excel/PHPExcel/Reader/Excel5.php 2400
ERROR - 2024-07-08 15:42:14 --> Severity: 8192 --> Array and string offset access syntax with curly braces is deprecated /www/wwwroot/report.mhis.link/bangka/secondary/application/third_party/PHP_Excel/PHPExcel/Reader/Excel5.php 2400
ERROR - 2024-07-08 15:42:14 --> Severity: 8192 --> Array and string offset access syntax with curly braces is deprecated /www/wwwroot/report.mhis.link/bangka/secondary/application/third_party/PHP_Excel/PHPExcel/Reader/Excel5.php 2400
ERROR - 2024-07-08 15:42:14 --> Severity: 8192 --> Array and string offset access syntax with curly braces is deprecated /www/wwwroot/report.mhis.link/bangka/secondary/application/third_party/PHP_Excel/PHPExcel/Reader/Excel5.php 2416
ERROR - 2024-07-08 15:42:14 --> Severity: 8192 --> Array and string offset access syntax with curly braces is deprecated /www/wwwroot/report.mhis.link/bangka/secondary/application/third_party/PHP_Excel/PHPExcel/Reader/Excel5.php 2416
ERROR - 2024-07-08 15:42:14 --> Severity: 8192 --> Array and string offset access syntax with curly braces is deprecated /www/wwwroot/report.mhis.link/bangka/secondary/application/third_party/PHP_Excel/PHPExcel/Reader/Excel5.php 2416
ERROR - 2024-07-08 15:42:14 --> Severity: 8192 --> Array and string offset access syntax with curly braces is deprecated /www/wwwroot/report.mhis.link/bangka/secondary/application/third_party/PHP_Excel/PHPExcel/Reader/Excel5.php 2432
ERROR - 2024-07-08 15:42:14 --> Severity: 8192 --> Array and string offset access syntax with curly braces is deprecated /www/wwwroot/report.mhis.link/bangka/secondary/application/third_party/PHP_Excel/PHPExcel/Reader/Excel5.php 2432
ERROR - 2024-07-08 15:42:14 --> Severity: 8192 --> Array and string offset access syntax with curly braces is deprecated /www/wwwroot/report.mhis.link/bangka/secondary/application/third_party/PHP_Excel/PHPExcel/Reader/Excel5.php 2432
ERROR - 2024-07-08 15:42:14 --> Severity: 8192 --> Array and string offset access syntax with curly braces is deprecated /www/wwwroot/report.mhis.link/bangka/secondary/application/third_party/PHP_Excel/PHPExcel/Reader/Excel5.php 2448
ERROR - 2024-07-08 15:42:14 --> Severity: 8192 --> Array and string offset access syntax with curly braces is deprecated /www/wwwroot/report.mhis.link/bangka/secondary/application/third_party/PHP_Excel/PHPExcel/Reader/Excel5.php 2448
ERROR - 2024-07-08 15:42:14 --> Severity: 8192 --> Array and string offset access syntax with curly braces is deprecated /www/wwwroot/report.mhis.link/bangka/secondary/application/third_party/PHP_Excel/PHPExcel/Reader/Excel5.php 2448
ERROR - 2024-07-08 15:42:14 --> Severity: 8192 --> Array and string offset access syntax with curly braces is deprecated /www/wwwroot/report.mhis.link/bangka/secondary/application/third_party/PHP_Excel/PHPExcel/Reader/Excel5.php 2490
ERROR - 2024-07-08 15:42:14 --> Severity: 8192 --> Array and string offset access syntax with curly braces is deprecated /www/wwwroot/report.mhis.link/bangka/secondary/application/third_party/PHP_Excel/PHPExcel/Reader/Excel5.php 2557
ERROR - 2024-07-08 15:42:14 --> Severity: 8192 --> Array and string offset access syntax with curly braces is deprecated /www/wwwroot/report.mhis.link/bangka/secondary/application/third_party/PHP_Excel/PHPExcel/Reader/Excel5.php 2565
ERROR - 2024-07-08 15:42:14 --> Severity: 8192 --> Array and string offset access syntax with curly braces is deprecated /www/wwwroot/report.mhis.link/bangka/secondary/application/third_party/PHP_Excel/PHPExcel/Reader/Excel5.php 2744
ERROR - 2024-07-08 15:42:14 --> Severity: 8192 --> Array and string offset access syntax with curly braces is deprecated /www/wwwroot/report.mhis.link/bangka/secondary/application/third_party/PHP_Excel/PHPExcel/Reader/Excel5.php 2828
ERROR - 2024-07-08 15:42:14 --> Severity: 8192 --> Array and string offset access syntax with curly braces is deprecated /www/wwwroot/report.mhis.link/bangka/secondary/application/third_party/PHP_Excel/PHPExcel/Reader/Excel5.php 2897
ERROR - 2024-07-08 15:42:14 --> Severity: 8192 --> Array and string offset access syntax with curly braces is deprecated /www/wwwroot/report.mhis.link/bangka/secondary/application/third_party/PHP_Excel/PHPExcel/Reader/Excel5.php 2921
ERROR - 2024-07-08 15:42:14 --> Severity: 8192 --> Array and string offset access syntax with curly braces is deprecated /www/wwwroot/report.mhis.link/bangka/secondary/application/third_party/PHP_Excel/PHPExcel/Reader/Excel5.php 3820
ERROR - 2024-07-08 15:42:14 --> Severity: 8192 --> Array and string offset access syntax with curly braces is deprecated /www/wwwroot/report.mhis.link/bangka/secondary/application/third_party/PHP_Excel/PHPExcel/Reader/Excel5.php 3844
ERROR - 2024-07-08 15:42:14 --> Severity: 8192 --> Array and string offset access syntax with curly braces is deprecated /www/wwwroot/report.mhis.link/bangka/secondary/application/third_party/PHP_Excel/PHPExcel/Reader/Excel5.php 3845
ERROR - 2024-07-08 15:42:14 --> Severity: 8192 --> Array and string offset access syntax with curly braces is deprecated /www/wwwroot/report.mhis.link/bangka/secondary/application/third_party/PHP_Excel/PHPExcel/Reader/Excel5.php 3846
ERROR - 2024-07-08 15:42:14 --> Severity: 8192 --> Array and string offset access syntax with curly braces is deprecated /www/wwwroot/report.mhis.link/bangka/secondary/application/third_party/PHP_Excel/PHPExcel/Reader/Excel5.php 3860
ERROR - 2024-07-08 15:42:14 --> Severity: 8192 --> Array and string offset access syntax with curly braces is deprecated /www/wwwroot/report.mhis.link/bangka/secondary/application/third_party/PHP_Excel/PHPExcel/Reader/Excel5.php 3861
ERROR - 2024-07-08 15:42:14 --> Severity: 8192 --> Array and string offset access syntax with curly braces is deprecated /www/wwwroot/report.mhis.link/bangka/secondary/application/third_party/PHP_Excel/PHPExcel/Reader/Excel5.php 3862
ERROR - 2024-07-08 15:42:14 --> Severity: 8192 --> Array and string offset access syntax with curly braces is deprecated /www/wwwroot/report.mhis.link/bangka/secondary/application/third_party/PHP_Excel/PHPExcel/Reader/Excel5.php 3866
ERROR - 2024-07-08 15:42:14 --> Severity: 8192 --> Array and string offset access syntax with curly braces is deprecated /www/wwwroot/report.mhis.link/bangka/secondary/application/third_party/PHP_Excel/PHPExcel/Reader/Excel5.php 3868
ERROR - 2024-07-08 15:42:14 --> Severity: 8192 --> Array and string offset access syntax with curly braces is deprecated /www/wwwroot/report.mhis.link/bangka/secondary/application/third_party/PHP_Excel/PHPExcel/Reader/Excel5.php 3869
ERROR - 2024-07-08 15:42:14 --> Severity: 8192 --> Array and string offset access syntax with curly braces is deprecated /www/wwwroot/report.mhis.link/bangka/secondary/application/third_party/PHP_Excel/PHPExcel/Reader/Excel5.php 3870
ERROR - 2024-07-08 15:42:14 --> Severity: 8192 --> Array and string offset access syntax with curly braces is deprecated /www/wwwroot/report.mhis.link/bangka/secondary/application/third_party/PHP_Excel/PHPExcel/Reader/Excel5.php 3874
ERROR - 2024-07-08 15:42:14 --> Severity: 8192 --> Array and string offset access syntax with curly braces is deprecated /www/wwwroot/report.mhis.link/bangka/secondary/application/third_party/PHP_Excel/PHPExcel/Reader/Excel5.php 3876
ERROR - 2024-07-08 15:42:14 --> Severity: 8192 --> Array and string offset access syntax with curly braces is deprecated /www/wwwroot/report.mhis.link/bangka/secondary/application/third_party/PHP_Excel/PHPExcel/Reader/Excel5.php 3877
ERROR - 2024-07-08 15:42:14 --> Severity: 8192 --> Array and string offset access syntax with curly braces is deprecated /www/wwwroot/report.mhis.link/bangka/secondary/application/third_party/PHP_Excel/PHPExcel/Reader/Excel5.php 3878
ERROR - 2024-07-08 15:42:14 --> Severity: 8192 --> Array and string offset access syntax with curly braces is deprecated /www/wwwroot/report.mhis.link/bangka/secondary/application/third_party/PHP_Excel/PHPExcel/Reader/Excel5.php 3946
ERROR - 2024-07-08 15:42:14 --> Severity: 8192 --> Array and string offset access syntax with curly braces is deprecated /www/wwwroot/report.mhis.link/bangka/secondary/application/third_party/PHP_Excel/PHPExcel/Reader/Excel5.php 4013
ERROR - 2024-07-08 15:42:14 --> Severity: 8192 --> Array and string offset access syntax with curly braces is deprecated /www/wwwroot/report.mhis.link/bangka/secondary/application/third_party/PHP_Excel/PHPExcel/Reader/Excel5.php 4016
ERROR - 2024-07-08 15:42:14 --> Severity: 8192 --> Array and string offset access syntax with curly braces is deprecated /www/wwwroot/report.mhis.link/bangka/secondary/application/third_party/PHP_Excel/PHPExcel/Reader/Excel5.php 4394
ERROR - 2024-07-08 15:42:14 --> Severity: 8192 --> Array and string offset access syntax with curly braces is deprecated /www/wwwroot/report.mhis.link/bangka/secondary/application/third_party/PHP_Excel/PHPExcel/Reader/Excel5.php 4546
ERROR - 2024-07-08 15:42:14 --> Severity: 8192 --> Array and string offset access syntax with curly braces is deprecated /www/wwwroot/report.mhis.link/bangka/secondary/application/third_party/PHP_Excel/PHPExcel/Reader/Excel5.php 4548
ERROR - 2024-07-08 15:42:14 --> Severity: 8192 --> Array and string offset access syntax with curly braces is deprecated /www/wwwroot/report.mhis.link/bangka/secondary/application/third_party/PHP_Excel/PHPExcel/Reader/Excel5.php 6093
ERROR - 2024-07-08 15:42:14 --> Severity: 8192 --> Array and string offset access syntax with curly braces is deprecated /www/wwwroot/report.mhis.link/bangka/secondary/application/third_party/PHP_Excel/PHPExcel/Reader/Excel5.php 6096
ERROR - 2024-07-08 15:42:14 --> Severity: 8192 --> Array and string offset access syntax with curly braces is deprecated /www/wwwroot/report.mhis.link/bangka/secondary/application/third_party/PHP_Excel/PHPExcel/Reader/Excel5.php 6503
ERROR - 2024-07-08 15:42:14 --> Severity: 8192 --> Array and string offset access syntax with curly braces is deprecated /www/wwwroot/report.mhis.link/bangka/secondary/application/third_party/PHP_Excel/PHPExcel/Reader/Excel5.php 6506
ERROR - 2024-07-08 15:42:14 --> Severity: 8192 --> Array and string offset access syntax with curly braces is deprecated /www/wwwroot/report.mhis.link/bangka/secondary/application/third_party/PHP_Excel/PHPExcel/Reader/Excel5.php 6509
ERROR - 2024-07-08 15:42:14 --> Severity: Warning --> "continue" targeting switch is equivalent to "break". Did you mean to use "continue 2"? /www/wwwroot/report.mhis.link/bangka/secondary/application/third_party/PHP_Excel/PHPExcel/Shared/OLE.php 290
ERROR - 2024-07-08 15:42:14 --> Severity: 8192 --> Array and string offset access syntax with curly braces is deprecated /www/wwwroot/report.mhis.link/bangka/secondary/application/third_party/PHP_Excel/PHPExcel/Shared/OLE.php 450
ERROR - 2024-07-08 15:42:14 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /www/wwwroot/report.mhis.link/bangka/secondary/system/core/Exceptions.php:271) /www/wwwroot/report.mhis.link/bangka/secondary/system/helpers/url_helper.php 564
INFO - 2024-07-08 15:42:16 --> Config Class Initialized
INFO - 2024-07-08 15:42:16 --> Hooks Class Initialized
DEBUG - 2024-07-08 15:42:16 --> UTF-8 Support Enabled
INFO - 2024-07-08 15:42:16 --> Utf8 Class Initialized
INFO - 2024-07-08 15:42:16 --> URI Class Initialized
INFO - 2024-07-08 15:42:16 --> Router Class Initialized
INFO - 2024-07-08 15:42:16 --> Output Class Initialized
INFO - 2024-07-08 15:42:16 --> Security Class Initialized
DEBUG - 2024-07-08 15:42:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-07-08 15:42:16 --> Input Class Initialized
INFO - 2024-07-08 15:42:16 --> Language Class Initialized
INFO - 2024-07-08 15:42:16 --> Language Class Initialized
INFO - 2024-07-08 15:42:16 --> Config Class Initialized
INFO - 2024-07-08 15:42:16 --> Loader Class Initialized
INFO - 2024-07-08 15:42:16 --> Helper loaded: url_helper
INFO - 2024-07-08 15:42:16 --> Helper loaded: file_helper
INFO - 2024-07-08 15:42:16 --> Helper loaded: form_helper
INFO - 2024-07-08 15:42:16 --> Helper loaded: my_helper
INFO - 2024-07-08 15:42:16 --> Database Driver Class Initialized
INFO - 2024-07-08 15:42:16 --> Session: Class initialized using 'files' driver.
INFO - 2024-07-08 15:42:16 --> Controller Class Initialized
DEBUG - 2024-07-08 15:42:16 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/data_siswa/views/form_import.php
DEBUG - 2024-07-08 15:42:16 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-07-08 15:42:16 --> Final output sent to browser
DEBUG - 2024-07-08 15:42:16 --> Total execution time: 0.0319
INFO - 2024-07-08 15:42:19 --> Config Class Initialized
INFO - 2024-07-08 15:42:19 --> Hooks Class Initialized
DEBUG - 2024-07-08 15:42:19 --> UTF-8 Support Enabled
INFO - 2024-07-08 15:42:19 --> Utf8 Class Initialized
INFO - 2024-07-08 15:42:19 --> URI Class Initialized
INFO - 2024-07-08 15:42:19 --> Router Class Initialized
INFO - 2024-07-08 15:42:19 --> Output Class Initialized
INFO - 2024-07-08 15:42:19 --> Security Class Initialized
DEBUG - 2024-07-08 15:42:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-07-08 15:42:19 --> Input Class Initialized
INFO - 2024-07-08 15:42:19 --> Language Class Initialized
INFO - 2024-07-08 15:42:19 --> Language Class Initialized
INFO - 2024-07-08 15:42:19 --> Config Class Initialized
INFO - 2024-07-08 15:42:19 --> Loader Class Initialized
INFO - 2024-07-08 15:42:19 --> Helper loaded: url_helper
INFO - 2024-07-08 15:42:19 --> Helper loaded: file_helper
INFO - 2024-07-08 15:42:19 --> Helper loaded: form_helper
INFO - 2024-07-08 15:42:19 --> Helper loaded: my_helper
INFO - 2024-07-08 15:42:19 --> Database Driver Class Initialized
INFO - 2024-07-08 15:42:19 --> Session: Class initialized using 'files' driver.
INFO - 2024-07-08 15:42:19 --> Controller Class Initialized
DEBUG - 2024-07-08 15:42:19 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/data_siswa/views/list.php
DEBUG - 2024-07-08 15:42:19 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-07-08 15:42:19 --> Final output sent to browser
DEBUG - 2024-07-08 15:42:19 --> Total execution time: 0.0381
INFO - 2024-07-08 15:42:19 --> Config Class Initialized
INFO - 2024-07-08 15:42:19 --> Hooks Class Initialized
DEBUG - 2024-07-08 15:42:19 --> UTF-8 Support Enabled
INFO - 2024-07-08 15:42:19 --> Utf8 Class Initialized
INFO - 2024-07-08 15:42:19 --> URI Class Initialized
INFO - 2024-07-08 15:42:19 --> Router Class Initialized
INFO - 2024-07-08 15:42:19 --> Output Class Initialized
INFO - 2024-07-08 15:42:19 --> Security Class Initialized
DEBUG - 2024-07-08 15:42:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-07-08 15:42:19 --> Input Class Initialized
INFO - 2024-07-08 15:42:19 --> Language Class Initialized
ERROR - 2024-07-08 15:42:19 --> 404 Page Not Found: /index
INFO - 2024-07-08 15:42:19 --> Config Class Initialized
INFO - 2024-07-08 15:42:19 --> Hooks Class Initialized
DEBUG - 2024-07-08 15:42:19 --> UTF-8 Support Enabled
INFO - 2024-07-08 15:42:19 --> Utf8 Class Initialized
INFO - 2024-07-08 15:42:19 --> URI Class Initialized
INFO - 2024-07-08 15:42:19 --> Router Class Initialized
INFO - 2024-07-08 15:42:19 --> Output Class Initialized
INFO - 2024-07-08 15:42:19 --> Security Class Initialized
DEBUG - 2024-07-08 15:42:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-07-08 15:42:19 --> Input Class Initialized
INFO - 2024-07-08 15:42:19 --> Language Class Initialized
INFO - 2024-07-08 15:42:19 --> Language Class Initialized
INFO - 2024-07-08 15:42:19 --> Config Class Initialized
INFO - 2024-07-08 15:42:19 --> Loader Class Initialized
INFO - 2024-07-08 15:42:19 --> Helper loaded: url_helper
INFO - 2024-07-08 15:42:19 --> Helper loaded: file_helper
INFO - 2024-07-08 15:42:19 --> Helper loaded: form_helper
INFO - 2024-07-08 15:42:19 --> Helper loaded: my_helper
INFO - 2024-07-08 15:42:19 --> Database Driver Class Initialized
INFO - 2024-07-08 15:42:19 --> Session: Class initialized using 'files' driver.
INFO - 2024-07-08 15:42:19 --> Controller Class Initialized
INFO - 2024-07-08 15:42:21 --> Config Class Initialized
INFO - 2024-07-08 15:42:21 --> Hooks Class Initialized
DEBUG - 2024-07-08 15:42:21 --> UTF-8 Support Enabled
INFO - 2024-07-08 15:42:21 --> Utf8 Class Initialized
INFO - 2024-07-08 15:42:21 --> URI Class Initialized
INFO - 2024-07-08 15:42:21 --> Router Class Initialized
INFO - 2024-07-08 15:42:21 --> Output Class Initialized
INFO - 2024-07-08 15:42:21 --> Security Class Initialized
DEBUG - 2024-07-08 15:42:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-07-08 15:42:21 --> Input Class Initialized
INFO - 2024-07-08 15:42:21 --> Language Class Initialized
INFO - 2024-07-08 15:42:21 --> Language Class Initialized
INFO - 2024-07-08 15:42:21 --> Config Class Initialized
INFO - 2024-07-08 15:42:21 --> Loader Class Initialized
INFO - 2024-07-08 15:42:21 --> Helper loaded: url_helper
INFO - 2024-07-08 15:42:21 --> Helper loaded: file_helper
INFO - 2024-07-08 15:42:21 --> Helper loaded: form_helper
INFO - 2024-07-08 15:42:21 --> Helper loaded: my_helper
INFO - 2024-07-08 15:42:21 --> Database Driver Class Initialized
INFO - 2024-07-08 15:42:21 --> Session: Class initialized using 'files' driver.
INFO - 2024-07-08 15:42:21 --> Controller Class Initialized
INFO - 2024-07-08 15:42:25 --> Config Class Initialized
INFO - 2024-07-08 15:42:25 --> Hooks Class Initialized
DEBUG - 2024-07-08 15:42:25 --> UTF-8 Support Enabled
INFO - 2024-07-08 15:42:25 --> Utf8 Class Initialized
INFO - 2024-07-08 15:42:25 --> URI Class Initialized
INFO - 2024-07-08 15:42:25 --> Router Class Initialized
INFO - 2024-07-08 15:42:25 --> Output Class Initialized
INFO - 2024-07-08 15:42:25 --> Security Class Initialized
DEBUG - 2024-07-08 15:42:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-07-08 15:42:25 --> Input Class Initialized
INFO - 2024-07-08 15:42:25 --> Language Class Initialized
INFO - 2024-07-08 15:42:25 --> Language Class Initialized
INFO - 2024-07-08 15:42:25 --> Config Class Initialized
INFO - 2024-07-08 15:42:25 --> Loader Class Initialized
INFO - 2024-07-08 15:42:25 --> Helper loaded: url_helper
INFO - 2024-07-08 15:42:25 --> Helper loaded: file_helper
INFO - 2024-07-08 15:42:25 --> Helper loaded: form_helper
INFO - 2024-07-08 15:42:25 --> Helper loaded: my_helper
INFO - 2024-07-08 15:42:25 --> Database Driver Class Initialized
INFO - 2024-07-08 15:42:25 --> Session: Class initialized using 'files' driver.
INFO - 2024-07-08 15:42:25 --> Controller Class Initialized
INFO - 2024-07-08 15:42:25 --> Final output sent to browser
DEBUG - 2024-07-08 15:42:25 --> Total execution time: 0.0400
INFO - 2024-07-08 15:42:25 --> Config Class Initialized
INFO - 2024-07-08 15:42:25 --> Hooks Class Initialized
DEBUG - 2024-07-08 15:42:25 --> UTF-8 Support Enabled
INFO - 2024-07-08 15:42:25 --> Utf8 Class Initialized
INFO - 2024-07-08 15:42:25 --> URI Class Initialized
INFO - 2024-07-08 15:42:25 --> Router Class Initialized
INFO - 2024-07-08 15:42:25 --> Output Class Initialized
INFO - 2024-07-08 15:42:25 --> Security Class Initialized
DEBUG - 2024-07-08 15:42:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-07-08 15:42:25 --> Input Class Initialized
INFO - 2024-07-08 15:42:25 --> Language Class Initialized
ERROR - 2024-07-08 15:42:25 --> 404 Page Not Found: /index
INFO - 2024-07-08 15:42:25 --> Config Class Initialized
INFO - 2024-07-08 15:42:25 --> Hooks Class Initialized
DEBUG - 2024-07-08 15:42:25 --> UTF-8 Support Enabled
INFO - 2024-07-08 15:42:25 --> Utf8 Class Initialized
INFO - 2024-07-08 15:42:25 --> URI Class Initialized
INFO - 2024-07-08 15:42:25 --> Router Class Initialized
INFO - 2024-07-08 15:42:25 --> Output Class Initialized
INFO - 2024-07-08 15:42:25 --> Security Class Initialized
DEBUG - 2024-07-08 15:42:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-07-08 15:42:25 --> Input Class Initialized
INFO - 2024-07-08 15:42:25 --> Language Class Initialized
INFO - 2024-07-08 15:42:25 --> Language Class Initialized
INFO - 2024-07-08 15:42:25 --> Config Class Initialized
INFO - 2024-07-08 15:42:25 --> Loader Class Initialized
INFO - 2024-07-08 15:42:25 --> Helper loaded: url_helper
INFO - 2024-07-08 15:42:25 --> Helper loaded: file_helper
INFO - 2024-07-08 15:42:25 --> Helper loaded: form_helper
INFO - 2024-07-08 15:42:25 --> Helper loaded: my_helper
INFO - 2024-07-08 15:42:25 --> Database Driver Class Initialized
INFO - 2024-07-08 15:42:25 --> Session: Class initialized using 'files' driver.
INFO - 2024-07-08 15:42:25 --> Controller Class Initialized
INFO - 2024-07-08 15:42:27 --> Config Class Initialized
INFO - 2024-07-08 15:42:27 --> Hooks Class Initialized
DEBUG - 2024-07-08 15:42:27 --> UTF-8 Support Enabled
INFO - 2024-07-08 15:42:27 --> Utf8 Class Initialized
INFO - 2024-07-08 15:42:27 --> URI Class Initialized
INFO - 2024-07-08 15:42:27 --> Router Class Initialized
INFO - 2024-07-08 15:42:27 --> Output Class Initialized
INFO - 2024-07-08 15:42:27 --> Security Class Initialized
DEBUG - 2024-07-08 15:42:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-07-08 15:42:27 --> Input Class Initialized
INFO - 2024-07-08 15:42:27 --> Language Class Initialized
INFO - 2024-07-08 15:42:27 --> Language Class Initialized
INFO - 2024-07-08 15:42:27 --> Config Class Initialized
INFO - 2024-07-08 15:42:27 --> Loader Class Initialized
INFO - 2024-07-08 15:42:27 --> Helper loaded: url_helper
INFO - 2024-07-08 15:42:27 --> Helper loaded: file_helper
INFO - 2024-07-08 15:42:27 --> Helper loaded: form_helper
INFO - 2024-07-08 15:42:27 --> Helper loaded: my_helper
INFO - 2024-07-08 15:42:27 --> Database Driver Class Initialized
INFO - 2024-07-08 15:42:27 --> Session: Class initialized using 'files' driver.
INFO - 2024-07-08 15:42:27 --> Controller Class Initialized
DEBUG - 2024-07-08 15:42:27 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/set_kelas/views/list.php
DEBUG - 2024-07-08 15:42:27 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-07-08 15:42:27 --> Final output sent to browser
DEBUG - 2024-07-08 15:42:27 --> Total execution time: 0.0357
INFO - 2024-07-08 15:42:29 --> Config Class Initialized
INFO - 2024-07-08 15:42:29 --> Hooks Class Initialized
DEBUG - 2024-07-08 15:42:29 --> UTF-8 Support Enabled
INFO - 2024-07-08 15:42:29 --> Utf8 Class Initialized
INFO - 2024-07-08 15:42:29 --> URI Class Initialized
INFO - 2024-07-08 15:42:29 --> Router Class Initialized
INFO - 2024-07-08 15:42:29 --> Output Class Initialized
INFO - 2024-07-08 15:42:29 --> Security Class Initialized
DEBUG - 2024-07-08 15:42:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-07-08 15:42:29 --> Input Class Initialized
INFO - 2024-07-08 15:42:29 --> Language Class Initialized
INFO - 2024-07-08 15:42:29 --> Language Class Initialized
INFO - 2024-07-08 15:42:29 --> Config Class Initialized
INFO - 2024-07-08 15:42:29 --> Loader Class Initialized
INFO - 2024-07-08 15:42:29 --> Helper loaded: url_helper
INFO - 2024-07-08 15:42:29 --> Helper loaded: file_helper
INFO - 2024-07-08 15:42:29 --> Helper loaded: form_helper
INFO - 2024-07-08 15:42:29 --> Helper loaded: my_helper
INFO - 2024-07-08 15:42:29 --> Database Driver Class Initialized
INFO - 2024-07-08 15:42:29 --> Session: Class initialized using 'files' driver.
INFO - 2024-07-08 15:42:29 --> Controller Class Initialized
ERROR - 2024-07-08 15:42:29 --> Severity: Notice --> Undefined index: tingkat /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/set_kelas/views/form.php 49
ERROR - 2024-07-08 15:42:29 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/set_kelas/views/form.php 49
ERROR - 2024-07-08 15:42:29 --> Severity: Notice --> Undefined index: kelas /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/set_kelas/views/form.php 59
ERROR - 2024-07-08 15:42:29 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/set_kelas/views/form.php 49
ERROR - 2024-07-08 15:42:29 --> Severity: Notice --> Undefined index: kelas /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/set_kelas/views/form.php 59
ERROR - 2024-07-08 15:42:29 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/set_kelas/views/form.php 49
ERROR - 2024-07-08 15:42:29 --> Severity: Notice --> Undefined index: kelas /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/set_kelas/views/form.php 59
ERROR - 2024-07-08 15:42:29 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/set_kelas/views/form.php 49
ERROR - 2024-07-08 15:42:29 --> Severity: Notice --> Undefined index: kelas /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/set_kelas/views/form.php 59
ERROR - 2024-07-08 15:42:29 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/set_kelas/views/form.php 49
ERROR - 2024-07-08 15:42:29 --> Severity: Notice --> Undefined index: kelas /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/set_kelas/views/form.php 59
ERROR - 2024-07-08 15:42:29 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/set_kelas/views/form.php 49
ERROR - 2024-07-08 15:42:29 --> Severity: Notice --> Undefined index: kelas /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/set_kelas/views/form.php 59
ERROR - 2024-07-08 15:42:29 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/set_kelas/views/form.php 49
ERROR - 2024-07-08 15:42:29 --> Severity: Notice --> Undefined index: kelas /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/set_kelas/views/form.php 59
ERROR - 2024-07-08 15:42:29 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/set_kelas/views/form.php 49
ERROR - 2024-07-08 15:42:29 --> Severity: Notice --> Undefined index: kelas /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/set_kelas/views/form.php 59
ERROR - 2024-07-08 15:42:29 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/set_kelas/views/form.php 49
ERROR - 2024-07-08 15:42:29 --> Severity: Notice --> Undefined index: kelas /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/set_kelas/views/form.php 59
ERROR - 2024-07-08 15:42:29 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/set_kelas/views/form.php 49
ERROR - 2024-07-08 15:42:29 --> Severity: Notice --> Undefined index: kelas /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/set_kelas/views/form.php 59
ERROR - 2024-07-08 15:42:29 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/set_kelas/views/form.php 49
ERROR - 2024-07-08 15:42:29 --> Severity: Notice --> Undefined index: kelas /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/set_kelas/views/form.php 59
ERROR - 2024-07-08 15:42:29 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/set_kelas/views/form.php 49
ERROR - 2024-07-08 15:42:29 --> Severity: Notice --> Undefined index: kelas /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/set_kelas/views/form.php 59
ERROR - 2024-07-08 15:42:29 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/set_kelas/views/form.php 49
ERROR - 2024-07-08 15:42:29 --> Severity: Notice --> Undefined index: kelas /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/set_kelas/views/form.php 59
ERROR - 2024-07-08 15:42:29 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/set_kelas/views/form.php 49
ERROR - 2024-07-08 15:42:29 --> Severity: Notice --> Undefined index: kelas /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/set_kelas/views/form.php 59
ERROR - 2024-07-08 15:42:29 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/set_kelas/views/form.php 49
ERROR - 2024-07-08 15:42:29 --> Severity: Notice --> Undefined index: kelas /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/set_kelas/views/form.php 59
ERROR - 2024-07-08 15:42:29 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/set_kelas/views/form.php 49
ERROR - 2024-07-08 15:42:29 --> Severity: Notice --> Undefined index: kelas /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/set_kelas/views/form.php 59
ERROR - 2024-07-08 15:42:29 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/set_kelas/views/form.php 49
ERROR - 2024-07-08 15:42:29 --> Severity: Notice --> Undefined index: kelas /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/set_kelas/views/form.php 59
ERROR - 2024-07-08 15:42:29 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/set_kelas/views/form.php 49
ERROR - 2024-07-08 15:42:29 --> Severity: Notice --> Undefined index: kelas /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/set_kelas/views/form.php 59
ERROR - 2024-07-08 15:42:29 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/set_kelas/views/form.php 49
ERROR - 2024-07-08 15:42:29 --> Severity: Notice --> Undefined index: kelas /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/set_kelas/views/form.php 59
ERROR - 2024-07-08 15:42:29 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/set_kelas/views/form.php 49
ERROR - 2024-07-08 15:42:29 --> Severity: Notice --> Undefined index: kelas /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/set_kelas/views/form.php 59
ERROR - 2024-07-08 15:42:29 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/set_kelas/views/form.php 49
ERROR - 2024-07-08 15:42:29 --> Severity: Notice --> Undefined index: kelas /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/set_kelas/views/form.php 59
ERROR - 2024-07-08 15:42:29 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/set_kelas/views/form.php 49
ERROR - 2024-07-08 15:42:29 --> Severity: Notice --> Undefined index: kelas /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/set_kelas/views/form.php 59
ERROR - 2024-07-08 15:42:29 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/set_kelas/views/form.php 49
ERROR - 2024-07-08 15:42:29 --> Severity: Notice --> Undefined index: kelas /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/set_kelas/views/form.php 59
ERROR - 2024-07-08 15:42:29 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/set_kelas/views/form.php 49
ERROR - 2024-07-08 15:42:29 --> Severity: Notice --> Undefined index: kelas /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/set_kelas/views/form.php 59
ERROR - 2024-07-08 15:42:29 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/set_kelas/views/form.php 49
ERROR - 2024-07-08 15:42:29 --> Severity: Notice --> Undefined index: kelas /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/set_kelas/views/form.php 59
ERROR - 2024-07-08 15:42:29 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/set_kelas/views/form.php 49
ERROR - 2024-07-08 15:42:29 --> Severity: Notice --> Undefined index: kelas /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/set_kelas/views/form.php 59
ERROR - 2024-07-08 15:42:29 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/set_kelas/views/form.php 49
ERROR - 2024-07-08 15:42:29 --> Severity: Notice --> Undefined index: kelas /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/set_kelas/views/form.php 59
ERROR - 2024-07-08 15:42:29 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/set_kelas/views/form.php 49
ERROR - 2024-07-08 15:42:29 --> Severity: Notice --> Undefined index: kelas /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/set_kelas/views/form.php 59
ERROR - 2024-07-08 15:42:29 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/set_kelas/views/form.php 49
ERROR - 2024-07-08 15:42:29 --> Severity: Notice --> Undefined index: kelas /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/set_kelas/views/form.php 59
ERROR - 2024-07-08 15:42:30 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/set_kelas/views/form.php 49
ERROR - 2024-07-08 15:42:30 --> Severity: Notice --> Undefined index: kelas /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/set_kelas/views/form.php 59
ERROR - 2024-07-08 15:42:30 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/set_kelas/views/form.php 49
ERROR - 2024-07-08 15:42:30 --> Severity: Notice --> Undefined index: kelas /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/set_kelas/views/form.php 59
ERROR - 2024-07-08 15:42:30 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/set_kelas/views/form.php 49
ERROR - 2024-07-08 15:42:30 --> Severity: Notice --> Undefined index: kelas /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/set_kelas/views/form.php 59
ERROR - 2024-07-08 15:42:30 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/set_kelas/views/form.php 49
ERROR - 2024-07-08 15:42:30 --> Severity: Notice --> Undefined index: kelas /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/set_kelas/views/form.php 59
ERROR - 2024-07-08 15:42:30 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/set_kelas/views/form.php 49
ERROR - 2024-07-08 15:42:30 --> Severity: Notice --> Undefined index: kelas /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/set_kelas/views/form.php 59
ERROR - 2024-07-08 15:42:30 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/set_kelas/views/form.php 49
ERROR - 2024-07-08 15:42:30 --> Severity: Notice --> Undefined index: kelas /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/set_kelas/views/form.php 59
ERROR - 2024-07-08 15:42:30 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/set_kelas/views/form.php 49
ERROR - 2024-07-08 15:42:30 --> Severity: Notice --> Undefined index: kelas /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/set_kelas/views/form.php 59
ERROR - 2024-07-08 15:42:30 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/set_kelas/views/form.php 49
ERROR - 2024-07-08 15:42:30 --> Severity: Notice --> Undefined index: kelas /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/set_kelas/views/form.php 59
DEBUG - 2024-07-08 15:42:30 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/set_kelas/views/form.php
DEBUG - 2024-07-08 15:42:30 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-07-08 15:42:30 --> Final output sent to browser
DEBUG - 2024-07-08 15:42:30 --> Total execution time: 0.1435
INFO - 2024-07-08 15:42:42 --> Config Class Initialized
INFO - 2024-07-08 15:42:42 --> Hooks Class Initialized
DEBUG - 2024-07-08 15:42:42 --> UTF-8 Support Enabled
INFO - 2024-07-08 15:42:42 --> Utf8 Class Initialized
INFO - 2024-07-08 15:42:42 --> URI Class Initialized
INFO - 2024-07-08 15:42:42 --> Router Class Initialized
INFO - 2024-07-08 15:42:42 --> Output Class Initialized
INFO - 2024-07-08 15:42:42 --> Security Class Initialized
DEBUG - 2024-07-08 15:42:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-07-08 15:42:42 --> Input Class Initialized
INFO - 2024-07-08 15:42:42 --> Language Class Initialized
INFO - 2024-07-08 15:42:42 --> Language Class Initialized
INFO - 2024-07-08 15:42:42 --> Config Class Initialized
INFO - 2024-07-08 15:42:42 --> Loader Class Initialized
INFO - 2024-07-08 15:42:42 --> Helper loaded: url_helper
INFO - 2024-07-08 15:42:42 --> Helper loaded: file_helper
INFO - 2024-07-08 15:42:42 --> Helper loaded: form_helper
INFO - 2024-07-08 15:42:42 --> Helper loaded: my_helper
INFO - 2024-07-08 15:42:42 --> Database Driver Class Initialized
INFO - 2024-07-08 15:42:42 --> Session: Class initialized using 'files' driver.
INFO - 2024-07-08 15:42:42 --> Controller Class Initialized
INFO - 2024-07-08 15:42:43 --> Config Class Initialized
INFO - 2024-07-08 15:42:43 --> Hooks Class Initialized
DEBUG - 2024-07-08 15:42:43 --> UTF-8 Support Enabled
INFO - 2024-07-08 15:42:43 --> Utf8 Class Initialized
INFO - 2024-07-08 15:42:43 --> URI Class Initialized
INFO - 2024-07-08 15:42:43 --> Router Class Initialized
INFO - 2024-07-08 15:42:43 --> Output Class Initialized
INFO - 2024-07-08 15:42:43 --> Security Class Initialized
DEBUG - 2024-07-08 15:42:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-07-08 15:42:43 --> Input Class Initialized
INFO - 2024-07-08 15:42:43 --> Language Class Initialized
INFO - 2024-07-08 15:42:43 --> Language Class Initialized
INFO - 2024-07-08 15:42:43 --> Config Class Initialized
INFO - 2024-07-08 15:42:43 --> Loader Class Initialized
INFO - 2024-07-08 15:42:43 --> Helper loaded: url_helper
INFO - 2024-07-08 15:42:43 --> Helper loaded: file_helper
INFO - 2024-07-08 15:42:43 --> Helper loaded: form_helper
INFO - 2024-07-08 15:42:43 --> Helper loaded: my_helper
INFO - 2024-07-08 15:42:43 --> Database Driver Class Initialized
INFO - 2024-07-08 15:42:43 --> Session: Class initialized using 'files' driver.
INFO - 2024-07-08 15:42:43 --> Controller Class Initialized
DEBUG - 2024-07-08 15:42:43 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/set_kelas/views/list.php
DEBUG - 2024-07-08 15:42:43 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-07-08 15:42:43 --> Final output sent to browser
DEBUG - 2024-07-08 15:42:43 --> Total execution time: 0.0409
INFO - 2024-07-08 15:42:49 --> Config Class Initialized
INFO - 2024-07-08 15:42:49 --> Hooks Class Initialized
DEBUG - 2024-07-08 15:42:49 --> UTF-8 Support Enabled
INFO - 2024-07-08 15:42:49 --> Utf8 Class Initialized
INFO - 2024-07-08 15:42:49 --> URI Class Initialized
INFO - 2024-07-08 15:42:49 --> Router Class Initialized
INFO - 2024-07-08 15:42:49 --> Output Class Initialized
INFO - 2024-07-08 15:42:49 --> Security Class Initialized
DEBUG - 2024-07-08 15:42:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-07-08 15:42:49 --> Input Class Initialized
INFO - 2024-07-08 15:42:49 --> Language Class Initialized
INFO - 2024-07-08 15:42:49 --> Language Class Initialized
INFO - 2024-07-08 15:42:49 --> Config Class Initialized
INFO - 2024-07-08 15:42:49 --> Loader Class Initialized
INFO - 2024-07-08 15:42:49 --> Helper loaded: url_helper
INFO - 2024-07-08 15:42:49 --> Helper loaded: file_helper
INFO - 2024-07-08 15:42:49 --> Helper loaded: form_helper
INFO - 2024-07-08 15:42:49 --> Helper loaded: my_helper
INFO - 2024-07-08 15:42:49 --> Database Driver Class Initialized
INFO - 2024-07-08 15:42:49 --> Session: Class initialized using 'files' driver.
INFO - 2024-07-08 15:42:49 --> Controller Class Initialized
ERROR - 2024-07-08 15:42:49 --> Severity: Notice --> Undefined index: tingkat /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/set_kelas/views/form.php 49
ERROR - 2024-07-08 15:42:49 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/set_kelas/views/form.php 49
ERROR - 2024-07-08 15:42:49 --> Severity: Notice --> Undefined index: kelas /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/set_kelas/views/form.php 59
ERROR - 2024-07-08 15:42:49 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/set_kelas/views/form.php 49
ERROR - 2024-07-08 15:42:49 --> Severity: Notice --> Undefined index: kelas /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/set_kelas/views/form.php 59
ERROR - 2024-07-08 15:42:49 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/set_kelas/views/form.php 49
ERROR - 2024-07-08 15:42:49 --> Severity: Notice --> Undefined index: kelas /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/set_kelas/views/form.php 59
ERROR - 2024-07-08 15:42:49 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/set_kelas/views/form.php 49
ERROR - 2024-07-08 15:42:49 --> Severity: Notice --> Undefined index: kelas /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/set_kelas/views/form.php 59
ERROR - 2024-07-08 15:42:49 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/set_kelas/views/form.php 49
ERROR - 2024-07-08 15:42:49 --> Severity: Notice --> Undefined index: kelas /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/set_kelas/views/form.php 59
ERROR - 2024-07-08 15:42:49 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/set_kelas/views/form.php 49
ERROR - 2024-07-08 15:42:49 --> Severity: Notice --> Undefined index: kelas /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/set_kelas/views/form.php 59
ERROR - 2024-07-08 15:42:49 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/set_kelas/views/form.php 49
ERROR - 2024-07-08 15:42:49 --> Severity: Notice --> Undefined index: kelas /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/set_kelas/views/form.php 59
ERROR - 2024-07-08 15:42:49 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/set_kelas/views/form.php 49
ERROR - 2024-07-08 15:42:49 --> Severity: Notice --> Undefined index: kelas /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/set_kelas/views/form.php 59
ERROR - 2024-07-08 15:42:49 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/set_kelas/views/form.php 49
ERROR - 2024-07-08 15:42:49 --> Severity: Notice --> Undefined index: kelas /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/set_kelas/views/form.php 59
ERROR - 2024-07-08 15:42:49 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/set_kelas/views/form.php 49
ERROR - 2024-07-08 15:42:49 --> Severity: Notice --> Undefined index: kelas /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/set_kelas/views/form.php 59
ERROR - 2024-07-08 15:42:49 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/set_kelas/views/form.php 49
ERROR - 2024-07-08 15:42:49 --> Severity: Notice --> Undefined index: kelas /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/set_kelas/views/form.php 59
ERROR - 2024-07-08 15:42:49 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/set_kelas/views/form.php 49
ERROR - 2024-07-08 15:42:49 --> Severity: Notice --> Undefined index: kelas /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/set_kelas/views/form.php 59
ERROR - 2024-07-08 15:42:49 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/set_kelas/views/form.php 49
ERROR - 2024-07-08 15:42:49 --> Severity: Notice --> Undefined index: kelas /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/set_kelas/views/form.php 59
ERROR - 2024-07-08 15:42:49 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/set_kelas/views/form.php 49
ERROR - 2024-07-08 15:42:49 --> Severity: Notice --> Undefined index: kelas /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/set_kelas/views/form.php 59
ERROR - 2024-07-08 15:42:49 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/set_kelas/views/form.php 49
ERROR - 2024-07-08 15:42:49 --> Severity: Notice --> Undefined index: kelas /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/set_kelas/views/form.php 59
ERROR - 2024-07-08 15:42:49 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/set_kelas/views/form.php 49
ERROR - 2024-07-08 15:42:49 --> Severity: Notice --> Undefined index: kelas /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/set_kelas/views/form.php 59
ERROR - 2024-07-08 15:42:49 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/set_kelas/views/form.php 49
ERROR - 2024-07-08 15:42:49 --> Severity: Notice --> Undefined index: kelas /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/set_kelas/views/form.php 59
ERROR - 2024-07-08 15:42:49 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/set_kelas/views/form.php 49
ERROR - 2024-07-08 15:42:49 --> Severity: Notice --> Undefined index: kelas /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/set_kelas/views/form.php 59
ERROR - 2024-07-08 15:42:49 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/set_kelas/views/form.php 49
ERROR - 2024-07-08 15:42:49 --> Severity: Notice --> Undefined index: kelas /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/set_kelas/views/form.php 59
ERROR - 2024-07-08 15:42:49 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/set_kelas/views/form.php 49
ERROR - 2024-07-08 15:42:49 --> Severity: Notice --> Undefined index: kelas /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/set_kelas/views/form.php 59
ERROR - 2024-07-08 15:42:49 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/set_kelas/views/form.php 49
ERROR - 2024-07-08 15:42:49 --> Severity: Notice --> Undefined index: kelas /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/set_kelas/views/form.php 59
ERROR - 2024-07-08 15:42:49 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/set_kelas/views/form.php 49
ERROR - 2024-07-08 15:42:49 --> Severity: Notice --> Undefined index: kelas /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/set_kelas/views/form.php 59
ERROR - 2024-07-08 15:42:49 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/set_kelas/views/form.php 49
ERROR - 2024-07-08 15:42:49 --> Severity: Notice --> Undefined index: kelas /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/set_kelas/views/form.php 59
ERROR - 2024-07-08 15:42:49 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/set_kelas/views/form.php 49
ERROR - 2024-07-08 15:42:49 --> Severity: Notice --> Undefined index: kelas /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/set_kelas/views/form.php 59
ERROR - 2024-07-08 15:42:49 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/set_kelas/views/form.php 49
ERROR - 2024-07-08 15:42:49 --> Severity: Notice --> Undefined index: kelas /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/set_kelas/views/form.php 59
ERROR - 2024-07-08 15:42:49 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/set_kelas/views/form.php 49
ERROR - 2024-07-08 15:42:49 --> Severity: Notice --> Undefined index: kelas /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/set_kelas/views/form.php 59
ERROR - 2024-07-08 15:42:49 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/set_kelas/views/form.php 49
ERROR - 2024-07-08 15:42:49 --> Severity: Notice --> Undefined index: kelas /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/set_kelas/views/form.php 59
ERROR - 2024-07-08 15:42:49 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/set_kelas/views/form.php 49
ERROR - 2024-07-08 15:42:49 --> Severity: Notice --> Undefined index: kelas /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/set_kelas/views/form.php 59
ERROR - 2024-07-08 15:42:49 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/set_kelas/views/form.php 49
ERROR - 2024-07-08 15:42:49 --> Severity: Notice --> Undefined index: kelas /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/set_kelas/views/form.php 59
ERROR - 2024-07-08 15:42:49 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/set_kelas/views/form.php 49
ERROR - 2024-07-08 15:42:49 --> Severity: Notice --> Undefined index: kelas /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/set_kelas/views/form.php 59
ERROR - 2024-07-08 15:42:49 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/set_kelas/views/form.php 49
ERROR - 2024-07-08 15:42:49 --> Severity: Notice --> Undefined index: kelas /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/set_kelas/views/form.php 59
ERROR - 2024-07-08 15:42:49 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/set_kelas/views/form.php 49
ERROR - 2024-07-08 15:42:49 --> Severity: Notice --> Undefined index: kelas /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/set_kelas/views/form.php 59
ERROR - 2024-07-08 15:42:49 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/set_kelas/views/form.php 49
ERROR - 2024-07-08 15:42:49 --> Severity: Notice --> Undefined index: kelas /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/set_kelas/views/form.php 59
ERROR - 2024-07-08 15:42:49 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/set_kelas/views/form.php 49
ERROR - 2024-07-08 15:42:49 --> Severity: Notice --> Undefined index: kelas /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/set_kelas/views/form.php 59
ERROR - 2024-07-08 15:42:49 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/set_kelas/views/form.php 49
ERROR - 2024-07-08 15:42:49 --> Severity: Notice --> Undefined index: kelas /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/set_kelas/views/form.php 59
ERROR - 2024-07-08 15:42:49 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/set_kelas/views/form.php 49
ERROR - 2024-07-08 15:42:49 --> Severity: Notice --> Undefined index: kelas /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/set_kelas/views/form.php 59
DEBUG - 2024-07-08 15:42:49 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/set_kelas/views/form.php
DEBUG - 2024-07-08 15:42:49 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-07-08 15:42:49 --> Final output sent to browser
DEBUG - 2024-07-08 15:42:49 --> Total execution time: 0.0943
INFO - 2024-07-08 15:45:18 --> Config Class Initialized
INFO - 2024-07-08 15:45:18 --> Hooks Class Initialized
DEBUG - 2024-07-08 15:45:18 --> UTF-8 Support Enabled
INFO - 2024-07-08 15:45:18 --> Utf8 Class Initialized
INFO - 2024-07-08 15:45:18 --> URI Class Initialized
INFO - 2024-07-08 15:45:18 --> Router Class Initialized
INFO - 2024-07-08 15:45:18 --> Output Class Initialized
INFO - 2024-07-08 15:45:18 --> Security Class Initialized
DEBUG - 2024-07-08 15:45:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-07-08 15:45:18 --> Input Class Initialized
INFO - 2024-07-08 15:45:18 --> Language Class Initialized
INFO - 2024-07-08 15:45:18 --> Language Class Initialized
INFO - 2024-07-08 15:45:18 --> Config Class Initialized
INFO - 2024-07-08 15:45:18 --> Loader Class Initialized
INFO - 2024-07-08 15:45:18 --> Helper loaded: url_helper
INFO - 2024-07-08 15:45:18 --> Helper loaded: file_helper
INFO - 2024-07-08 15:45:18 --> Helper loaded: form_helper
INFO - 2024-07-08 15:45:18 --> Helper loaded: my_helper
INFO - 2024-07-08 15:45:18 --> Database Driver Class Initialized
INFO - 2024-07-08 15:45:18 --> Session: Class initialized using 'files' driver.
INFO - 2024-07-08 15:45:18 --> Controller Class Initialized
INFO - 2024-07-08 15:45:18 --> Config Class Initialized
INFO - 2024-07-08 15:45:18 --> Hooks Class Initialized
DEBUG - 2024-07-08 15:45:18 --> UTF-8 Support Enabled
INFO - 2024-07-08 15:45:18 --> Utf8 Class Initialized
INFO - 2024-07-08 15:45:18 --> URI Class Initialized
INFO - 2024-07-08 15:45:18 --> Router Class Initialized
INFO - 2024-07-08 15:45:18 --> Output Class Initialized
INFO - 2024-07-08 15:45:18 --> Security Class Initialized
DEBUG - 2024-07-08 15:45:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-07-08 15:45:18 --> Input Class Initialized
INFO - 2024-07-08 15:45:18 --> Language Class Initialized
INFO - 2024-07-08 15:45:18 --> Language Class Initialized
INFO - 2024-07-08 15:45:18 --> Config Class Initialized
INFO - 2024-07-08 15:45:18 --> Loader Class Initialized
INFO - 2024-07-08 15:45:18 --> Helper loaded: url_helper
INFO - 2024-07-08 15:45:18 --> Helper loaded: file_helper
INFO - 2024-07-08 15:45:18 --> Helper loaded: form_helper
INFO - 2024-07-08 15:45:18 --> Helper loaded: my_helper
INFO - 2024-07-08 15:45:18 --> Database Driver Class Initialized
INFO - 2024-07-08 15:45:18 --> Session: Class initialized using 'files' driver.
INFO - 2024-07-08 15:45:18 --> Controller Class Initialized
DEBUG - 2024-07-08 15:45:18 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/set_kelas/views/list.php
DEBUG - 2024-07-08 15:45:18 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-07-08 15:45:18 --> Final output sent to browser
DEBUG - 2024-07-08 15:45:18 --> Total execution time: 0.0820
INFO - 2024-07-08 15:45:22 --> Config Class Initialized
INFO - 2024-07-08 15:45:22 --> Hooks Class Initialized
DEBUG - 2024-07-08 15:45:22 --> UTF-8 Support Enabled
INFO - 2024-07-08 15:45:22 --> Utf8 Class Initialized
INFO - 2024-07-08 15:45:22 --> URI Class Initialized
INFO - 2024-07-08 15:45:22 --> Router Class Initialized
INFO - 2024-07-08 15:45:22 --> Output Class Initialized
INFO - 2024-07-08 15:45:22 --> Security Class Initialized
DEBUG - 2024-07-08 15:45:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-07-08 15:45:22 --> Input Class Initialized
INFO - 2024-07-08 15:45:22 --> Language Class Initialized
INFO - 2024-07-08 15:45:22 --> Language Class Initialized
INFO - 2024-07-08 15:45:22 --> Config Class Initialized
INFO - 2024-07-08 15:45:22 --> Loader Class Initialized
INFO - 2024-07-08 15:45:22 --> Helper loaded: url_helper
INFO - 2024-07-08 15:45:22 --> Helper loaded: file_helper
INFO - 2024-07-08 15:45:22 --> Helper loaded: form_helper
INFO - 2024-07-08 15:45:22 --> Helper loaded: my_helper
INFO - 2024-07-08 15:45:22 --> Database Driver Class Initialized
INFO - 2024-07-08 15:45:22 --> Session: Class initialized using 'files' driver.
INFO - 2024-07-08 15:45:22 --> Controller Class Initialized
ERROR - 2024-07-08 15:45:22 --> Severity: Notice --> Undefined index: tingkat /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/set_kelas/views/form.php 49
ERROR - 2024-07-08 15:45:22 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/set_kelas/views/form.php 49
ERROR - 2024-07-08 15:45:22 --> Severity: Notice --> Undefined index: kelas /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/set_kelas/views/form.php 59
ERROR - 2024-07-08 15:45:22 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/set_kelas/views/form.php 49
ERROR - 2024-07-08 15:45:22 --> Severity: Notice --> Undefined index: kelas /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/set_kelas/views/form.php 59
ERROR - 2024-07-08 15:45:22 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/set_kelas/views/form.php 49
ERROR - 2024-07-08 15:45:22 --> Severity: Notice --> Undefined index: kelas /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/set_kelas/views/form.php 59
ERROR - 2024-07-08 15:45:22 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/set_kelas/views/form.php 49
ERROR - 2024-07-08 15:45:22 --> Severity: Notice --> Undefined index: kelas /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/set_kelas/views/form.php 59
ERROR - 2024-07-08 15:45:22 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/set_kelas/views/form.php 49
ERROR - 2024-07-08 15:45:22 --> Severity: Notice --> Undefined index: kelas /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/set_kelas/views/form.php 59
ERROR - 2024-07-08 15:45:22 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/set_kelas/views/form.php 49
ERROR - 2024-07-08 15:45:22 --> Severity: Notice --> Undefined index: kelas /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/set_kelas/views/form.php 59
ERROR - 2024-07-08 15:45:22 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/set_kelas/views/form.php 49
ERROR - 2024-07-08 15:45:22 --> Severity: Notice --> Undefined index: kelas /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/set_kelas/views/form.php 59
ERROR - 2024-07-08 15:45:22 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/set_kelas/views/form.php 49
ERROR - 2024-07-08 15:45:22 --> Severity: Notice --> Undefined index: kelas /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/set_kelas/views/form.php 59
ERROR - 2024-07-08 15:45:22 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/set_kelas/views/form.php 49
ERROR - 2024-07-08 15:45:22 --> Severity: Notice --> Undefined index: kelas /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/set_kelas/views/form.php 59
ERROR - 2024-07-08 15:45:22 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/set_kelas/views/form.php 49
ERROR - 2024-07-08 15:45:22 --> Severity: Notice --> Undefined index: kelas /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/set_kelas/views/form.php 59
ERROR - 2024-07-08 15:45:22 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/set_kelas/views/form.php 49
ERROR - 2024-07-08 15:45:22 --> Severity: Notice --> Undefined index: kelas /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/set_kelas/views/form.php 59
ERROR - 2024-07-08 15:45:22 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/set_kelas/views/form.php 49
ERROR - 2024-07-08 15:45:22 --> Severity: Notice --> Undefined index: kelas /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/set_kelas/views/form.php 59
ERROR - 2024-07-08 15:45:22 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/set_kelas/views/form.php 49
ERROR - 2024-07-08 15:45:22 --> Severity: Notice --> Undefined index: kelas /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/set_kelas/views/form.php 59
ERROR - 2024-07-08 15:45:22 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/set_kelas/views/form.php 49
ERROR - 2024-07-08 15:45:22 --> Severity: Notice --> Undefined index: kelas /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/set_kelas/views/form.php 59
ERROR - 2024-07-08 15:45:22 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/set_kelas/views/form.php 49
ERROR - 2024-07-08 15:45:22 --> Severity: Notice --> Undefined index: kelas /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/set_kelas/views/form.php 59
ERROR - 2024-07-08 15:45:22 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/set_kelas/views/form.php 49
ERROR - 2024-07-08 15:45:22 --> Severity: Notice --> Undefined index: kelas /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/set_kelas/views/form.php 59
ERROR - 2024-07-08 15:45:22 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/set_kelas/views/form.php 49
ERROR - 2024-07-08 15:45:22 --> Severity: Notice --> Undefined index: kelas /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/set_kelas/views/form.php 59
DEBUG - 2024-07-08 15:45:22 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/set_kelas/views/form.php
DEBUG - 2024-07-08 15:45:22 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-07-08 15:45:22 --> Final output sent to browser
DEBUG - 2024-07-08 15:45:22 --> Total execution time: 0.0597
INFO - 2024-07-08 15:45:49 --> Config Class Initialized
INFO - 2024-07-08 15:45:49 --> Hooks Class Initialized
DEBUG - 2024-07-08 15:45:49 --> UTF-8 Support Enabled
INFO - 2024-07-08 15:45:49 --> Utf8 Class Initialized
INFO - 2024-07-08 15:45:49 --> URI Class Initialized
INFO - 2024-07-08 15:45:49 --> Router Class Initialized
INFO - 2024-07-08 15:45:49 --> Output Class Initialized
INFO - 2024-07-08 15:45:49 --> Security Class Initialized
DEBUG - 2024-07-08 15:45:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-07-08 15:45:49 --> Input Class Initialized
INFO - 2024-07-08 15:45:49 --> Language Class Initialized
INFO - 2024-07-08 15:45:49 --> Language Class Initialized
INFO - 2024-07-08 15:45:49 --> Config Class Initialized
INFO - 2024-07-08 15:45:49 --> Loader Class Initialized
INFO - 2024-07-08 15:45:49 --> Helper loaded: url_helper
INFO - 2024-07-08 15:45:49 --> Helper loaded: file_helper
INFO - 2024-07-08 15:45:49 --> Helper loaded: form_helper
INFO - 2024-07-08 15:45:49 --> Helper loaded: my_helper
INFO - 2024-07-08 15:45:49 --> Database Driver Class Initialized
INFO - 2024-07-08 15:45:49 --> Session: Class initialized using 'files' driver.
INFO - 2024-07-08 15:45:49 --> Controller Class Initialized
INFO - 2024-07-08 15:45:49 --> Config Class Initialized
INFO - 2024-07-08 15:45:49 --> Hooks Class Initialized
DEBUG - 2024-07-08 15:45:49 --> UTF-8 Support Enabled
INFO - 2024-07-08 15:45:49 --> Utf8 Class Initialized
INFO - 2024-07-08 15:45:49 --> URI Class Initialized
INFO - 2024-07-08 15:45:49 --> Router Class Initialized
INFO - 2024-07-08 15:45:49 --> Output Class Initialized
INFO - 2024-07-08 15:45:49 --> Security Class Initialized
DEBUG - 2024-07-08 15:45:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-07-08 15:45:49 --> Input Class Initialized
INFO - 2024-07-08 15:45:49 --> Language Class Initialized
INFO - 2024-07-08 15:45:49 --> Language Class Initialized
INFO - 2024-07-08 15:45:49 --> Config Class Initialized
INFO - 2024-07-08 15:45:49 --> Loader Class Initialized
INFO - 2024-07-08 15:45:49 --> Helper loaded: url_helper
INFO - 2024-07-08 15:45:49 --> Helper loaded: file_helper
INFO - 2024-07-08 15:45:49 --> Helper loaded: form_helper
INFO - 2024-07-08 15:45:49 --> Helper loaded: my_helper
INFO - 2024-07-08 15:45:49 --> Database Driver Class Initialized
INFO - 2024-07-08 15:45:49 --> Session: Class initialized using 'files' driver.
INFO - 2024-07-08 15:45:49 --> Controller Class Initialized
DEBUG - 2024-07-08 15:45:49 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/set_kelas/views/list.php
DEBUG - 2024-07-08 15:45:49 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-07-08 15:45:49 --> Final output sent to browser
DEBUG - 2024-07-08 15:45:49 --> Total execution time: 0.0328
INFO - 2024-07-08 15:47:45 --> Config Class Initialized
INFO - 2024-07-08 15:47:45 --> Hooks Class Initialized
DEBUG - 2024-07-08 15:47:45 --> UTF-8 Support Enabled
INFO - 2024-07-08 15:47:45 --> Utf8 Class Initialized
INFO - 2024-07-08 15:47:45 --> URI Class Initialized
DEBUG - 2024-07-08 15:47:45 --> No URI present. Default controller set.
INFO - 2024-07-08 15:47:45 --> Router Class Initialized
INFO - 2024-07-08 15:47:45 --> Output Class Initialized
INFO - 2024-07-08 15:47:45 --> Security Class Initialized
DEBUG - 2024-07-08 15:47:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-07-08 15:47:45 --> Input Class Initialized
INFO - 2024-07-08 15:47:45 --> Language Class Initialized
INFO - 2024-07-08 15:47:45 --> Language Class Initialized
INFO - 2024-07-08 15:47:45 --> Config Class Initialized
INFO - 2024-07-08 15:47:45 --> Loader Class Initialized
INFO - 2024-07-08 15:47:45 --> Helper loaded: url_helper
INFO - 2024-07-08 15:47:45 --> Helper loaded: file_helper
INFO - 2024-07-08 15:47:45 --> Helper loaded: form_helper
INFO - 2024-07-08 15:47:45 --> Helper loaded: my_helper
INFO - 2024-07-08 15:47:45 --> Database Driver Class Initialized
INFO - 2024-07-08 15:47:45 --> Session: Class initialized using 'files' driver.
INFO - 2024-07-08 15:47:45 --> Controller Class Initialized
INFO - 2024-07-08 15:47:45 --> Config Class Initialized
INFO - 2024-07-08 15:47:45 --> Hooks Class Initialized
DEBUG - 2024-07-08 15:47:45 --> UTF-8 Support Enabled
INFO - 2024-07-08 15:47:45 --> Utf8 Class Initialized
INFO - 2024-07-08 15:47:45 --> URI Class Initialized
INFO - 2024-07-08 15:47:45 --> Router Class Initialized
INFO - 2024-07-08 15:47:45 --> Output Class Initialized
INFO - 2024-07-08 15:47:45 --> Security Class Initialized
DEBUG - 2024-07-08 15:47:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-07-08 15:47:45 --> Input Class Initialized
INFO - 2024-07-08 15:47:45 --> Language Class Initialized
INFO - 2024-07-08 15:47:45 --> Language Class Initialized
INFO - 2024-07-08 15:47:45 --> Config Class Initialized
INFO - 2024-07-08 15:47:45 --> Loader Class Initialized
INFO - 2024-07-08 15:47:45 --> Helper loaded: url_helper
INFO - 2024-07-08 15:47:45 --> Helper loaded: file_helper
INFO - 2024-07-08 15:47:45 --> Helper loaded: form_helper
INFO - 2024-07-08 15:47:45 --> Helper loaded: my_helper
INFO - 2024-07-08 15:47:45 --> Database Driver Class Initialized
INFO - 2024-07-08 15:47:45 --> Session: Class initialized using 'files' driver.
INFO - 2024-07-08 15:47:45 --> Controller Class Initialized
DEBUG - 2024-07-08 15:47:45 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/login/views/login.php
DEBUG - 2024-07-08 15:47:45 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-07-08 15:47:45 --> Final output sent to browser
DEBUG - 2024-07-08 15:47:45 --> Total execution time: 0.0675
INFO - 2024-07-08 15:47:50 --> Config Class Initialized
INFO - 2024-07-08 15:47:50 --> Hooks Class Initialized
DEBUG - 2024-07-08 15:47:50 --> UTF-8 Support Enabled
INFO - 2024-07-08 15:47:50 --> Utf8 Class Initialized
INFO - 2024-07-08 15:47:50 --> URI Class Initialized
INFO - 2024-07-08 15:47:50 --> Router Class Initialized
INFO - 2024-07-08 15:47:50 --> Output Class Initialized
INFO - 2024-07-08 15:47:50 --> Security Class Initialized
DEBUG - 2024-07-08 15:47:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-07-08 15:47:50 --> Input Class Initialized
INFO - 2024-07-08 15:47:50 --> Language Class Initialized
INFO - 2024-07-08 15:47:50 --> Language Class Initialized
INFO - 2024-07-08 15:47:50 --> Config Class Initialized
INFO - 2024-07-08 15:47:50 --> Loader Class Initialized
INFO - 2024-07-08 15:47:50 --> Helper loaded: url_helper
INFO - 2024-07-08 15:47:50 --> Helper loaded: file_helper
INFO - 2024-07-08 15:47:50 --> Helper loaded: form_helper
INFO - 2024-07-08 15:47:50 --> Helper loaded: my_helper
INFO - 2024-07-08 15:47:50 --> Database Driver Class Initialized
INFO - 2024-07-08 15:47:50 --> Session: Class initialized using 'files' driver.
INFO - 2024-07-08 15:47:50 --> Controller Class Initialized
INFO - 2024-07-08 15:47:50 --> Helper loaded: cookie_helper
INFO - 2024-07-08 15:47:50 --> Final output sent to browser
DEBUG - 2024-07-08 15:47:50 --> Total execution time: 0.0361
INFO - 2024-07-08 15:47:50 --> Config Class Initialized
INFO - 2024-07-08 15:47:50 --> Hooks Class Initialized
DEBUG - 2024-07-08 15:47:50 --> UTF-8 Support Enabled
INFO - 2024-07-08 15:47:50 --> Utf8 Class Initialized
INFO - 2024-07-08 15:47:50 --> URI Class Initialized
INFO - 2024-07-08 15:47:50 --> Router Class Initialized
INFO - 2024-07-08 15:47:50 --> Output Class Initialized
INFO - 2024-07-08 15:47:50 --> Security Class Initialized
DEBUG - 2024-07-08 15:47:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-07-08 15:47:50 --> Input Class Initialized
INFO - 2024-07-08 15:47:50 --> Language Class Initialized
INFO - 2024-07-08 15:47:50 --> Language Class Initialized
INFO - 2024-07-08 15:47:50 --> Config Class Initialized
INFO - 2024-07-08 15:47:50 --> Loader Class Initialized
INFO - 2024-07-08 15:47:50 --> Helper loaded: url_helper
INFO - 2024-07-08 15:47:50 --> Helper loaded: file_helper
INFO - 2024-07-08 15:47:50 --> Helper loaded: form_helper
INFO - 2024-07-08 15:47:50 --> Helper loaded: my_helper
INFO - 2024-07-08 15:47:50 --> Database Driver Class Initialized
INFO - 2024-07-08 15:47:50 --> Session: Class initialized using 'files' driver.
INFO - 2024-07-08 15:47:50 --> Controller Class Initialized
DEBUG - 2024-07-08 15:47:50 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/home/views/v_home.php
DEBUG - 2024-07-08 15:47:50 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-07-08 15:47:50 --> Final output sent to browser
DEBUG - 2024-07-08 15:47:50 --> Total execution time: 0.0374
INFO - 2024-07-08 15:47:52 --> Config Class Initialized
INFO - 2024-07-08 15:47:52 --> Hooks Class Initialized
DEBUG - 2024-07-08 15:47:52 --> UTF-8 Support Enabled
INFO - 2024-07-08 15:47:52 --> Utf8 Class Initialized
INFO - 2024-07-08 15:47:52 --> URI Class Initialized
INFO - 2024-07-08 15:47:52 --> Router Class Initialized
INFO - 2024-07-08 15:47:52 --> Output Class Initialized
INFO - 2024-07-08 15:47:52 --> Security Class Initialized
DEBUG - 2024-07-08 15:47:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-07-08 15:47:52 --> Input Class Initialized
INFO - 2024-07-08 15:47:52 --> Language Class Initialized
INFO - 2024-07-08 15:47:52 --> Language Class Initialized
INFO - 2024-07-08 15:47:52 --> Config Class Initialized
INFO - 2024-07-08 15:47:52 --> Loader Class Initialized
INFO - 2024-07-08 15:47:52 --> Helper loaded: url_helper
INFO - 2024-07-08 15:47:52 --> Helper loaded: file_helper
INFO - 2024-07-08 15:47:52 --> Helper loaded: form_helper
INFO - 2024-07-08 15:47:52 --> Helper loaded: my_helper
INFO - 2024-07-08 15:47:52 --> Database Driver Class Initialized
INFO - 2024-07-08 15:47:52 --> Session: Class initialized using 'files' driver.
INFO - 2024-07-08 15:47:52 --> Controller Class Initialized
DEBUG - 2024-07-08 15:47:52 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/set_kelas/views/list.php
DEBUG - 2024-07-08 15:47:52 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-07-08 15:47:52 --> Final output sent to browser
DEBUG - 2024-07-08 15:47:52 --> Total execution time: 0.0343
INFO - 2024-07-08 15:47:54 --> Config Class Initialized
INFO - 2024-07-08 15:47:54 --> Hooks Class Initialized
DEBUG - 2024-07-08 15:47:54 --> UTF-8 Support Enabled
INFO - 2024-07-08 15:47:54 --> Utf8 Class Initialized
INFO - 2024-07-08 15:47:54 --> URI Class Initialized
INFO - 2024-07-08 15:47:54 --> Router Class Initialized
INFO - 2024-07-08 15:47:54 --> Output Class Initialized
INFO - 2024-07-08 15:47:54 --> Security Class Initialized
DEBUG - 2024-07-08 15:47:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-07-08 15:47:54 --> Input Class Initialized
INFO - 2024-07-08 15:47:54 --> Language Class Initialized
INFO - 2024-07-08 15:47:54 --> Language Class Initialized
INFO - 2024-07-08 15:47:54 --> Config Class Initialized
INFO - 2024-07-08 15:47:54 --> Loader Class Initialized
INFO - 2024-07-08 15:47:54 --> Helper loaded: url_helper
INFO - 2024-07-08 15:47:54 --> Helper loaded: file_helper
INFO - 2024-07-08 15:47:54 --> Helper loaded: form_helper
INFO - 2024-07-08 15:47:54 --> Helper loaded: my_helper
INFO - 2024-07-08 15:47:54 --> Database Driver Class Initialized
INFO - 2024-07-08 15:47:54 --> Session: Class initialized using 'files' driver.
INFO - 2024-07-08 15:47:54 --> Controller Class Initialized
DEBUG - 2024-07-08 15:47:54 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/tahun/views/list.php
DEBUG - 2024-07-08 15:47:54 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-07-08 15:47:54 --> Final output sent to browser
DEBUG - 2024-07-08 15:47:54 --> Total execution time: 0.0288
INFO - 2024-07-08 15:47:54 --> Config Class Initialized
INFO - 2024-07-08 15:47:54 --> Hooks Class Initialized
DEBUG - 2024-07-08 15:47:54 --> UTF-8 Support Enabled
INFO - 2024-07-08 15:47:54 --> Utf8 Class Initialized
INFO - 2024-07-08 15:47:54 --> URI Class Initialized
INFO - 2024-07-08 15:47:54 --> Router Class Initialized
INFO - 2024-07-08 15:47:54 --> Output Class Initialized
INFO - 2024-07-08 15:47:54 --> Security Class Initialized
DEBUG - 2024-07-08 15:47:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-07-08 15:47:54 --> Input Class Initialized
INFO - 2024-07-08 15:47:54 --> Language Class Initialized
ERROR - 2024-07-08 15:47:54 --> 404 Page Not Found: /index
INFO - 2024-07-08 15:47:54 --> Config Class Initialized
INFO - 2024-07-08 15:47:54 --> Hooks Class Initialized
DEBUG - 2024-07-08 15:47:54 --> UTF-8 Support Enabled
INFO - 2024-07-08 15:47:54 --> Utf8 Class Initialized
INFO - 2024-07-08 15:47:54 --> URI Class Initialized
INFO - 2024-07-08 15:47:54 --> Router Class Initialized
INFO - 2024-07-08 15:47:54 --> Output Class Initialized
INFO - 2024-07-08 15:47:54 --> Security Class Initialized
DEBUG - 2024-07-08 15:47:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-07-08 15:47:55 --> Input Class Initialized
INFO - 2024-07-08 15:47:55 --> Language Class Initialized
INFO - 2024-07-08 15:47:55 --> Language Class Initialized
INFO - 2024-07-08 15:47:55 --> Config Class Initialized
INFO - 2024-07-08 15:47:55 --> Loader Class Initialized
INFO - 2024-07-08 15:47:55 --> Helper loaded: url_helper
INFO - 2024-07-08 15:47:55 --> Helper loaded: file_helper
INFO - 2024-07-08 15:47:55 --> Helper loaded: form_helper
INFO - 2024-07-08 15:47:55 --> Helper loaded: my_helper
INFO - 2024-07-08 15:47:55 --> Database Driver Class Initialized
INFO - 2024-07-08 15:47:55 --> Session: Class initialized using 'files' driver.
INFO - 2024-07-08 15:47:55 --> Controller Class Initialized
INFO - 2024-07-08 15:48:01 --> Config Class Initialized
INFO - 2024-07-08 15:48:01 --> Hooks Class Initialized
DEBUG - 2024-07-08 15:48:01 --> UTF-8 Support Enabled
INFO - 2024-07-08 15:48:01 --> Utf8 Class Initialized
INFO - 2024-07-08 15:48:01 --> URI Class Initialized
INFO - 2024-07-08 15:48:01 --> Router Class Initialized
INFO - 2024-07-08 15:48:01 --> Output Class Initialized
INFO - 2024-07-08 15:48:01 --> Security Class Initialized
DEBUG - 2024-07-08 15:48:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-07-08 15:48:01 --> Input Class Initialized
INFO - 2024-07-08 15:48:01 --> Language Class Initialized
INFO - 2024-07-08 15:48:01 --> Language Class Initialized
INFO - 2024-07-08 15:48:01 --> Config Class Initialized
INFO - 2024-07-08 15:48:01 --> Loader Class Initialized
INFO - 2024-07-08 15:48:01 --> Helper loaded: url_helper
INFO - 2024-07-08 15:48:01 --> Helper loaded: file_helper
INFO - 2024-07-08 15:48:01 --> Helper loaded: form_helper
INFO - 2024-07-08 15:48:01 --> Helper loaded: my_helper
INFO - 2024-07-08 15:48:01 --> Database Driver Class Initialized
INFO - 2024-07-08 15:48:01 --> Session: Class initialized using 'files' driver.
INFO - 2024-07-08 15:48:01 --> Controller Class Initialized
DEBUG - 2024-07-08 15:48:01 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/tahun/views/list.php
DEBUG - 2024-07-08 15:48:01 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-07-08 15:48:01 --> Final output sent to browser
DEBUG - 2024-07-08 15:48:01 --> Total execution time: 0.0360
INFO - 2024-07-08 15:48:01 --> Config Class Initialized
INFO - 2024-07-08 15:48:01 --> Hooks Class Initialized
DEBUG - 2024-07-08 15:48:01 --> UTF-8 Support Enabled
INFO - 2024-07-08 15:48:01 --> Utf8 Class Initialized
INFO - 2024-07-08 15:48:01 --> URI Class Initialized
INFO - 2024-07-08 15:48:01 --> Router Class Initialized
INFO - 2024-07-08 15:48:01 --> Output Class Initialized
INFO - 2024-07-08 15:48:01 --> Security Class Initialized
DEBUG - 2024-07-08 15:48:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-07-08 15:48:01 --> Input Class Initialized
INFO - 2024-07-08 15:48:01 --> Language Class Initialized
ERROR - 2024-07-08 15:48:01 --> 404 Page Not Found: /index
INFO - 2024-07-08 15:48:01 --> Config Class Initialized
INFO - 2024-07-08 15:48:01 --> Hooks Class Initialized
DEBUG - 2024-07-08 15:48:01 --> UTF-8 Support Enabled
INFO - 2024-07-08 15:48:01 --> Utf8 Class Initialized
INFO - 2024-07-08 15:48:01 --> URI Class Initialized
INFO - 2024-07-08 15:48:01 --> Router Class Initialized
INFO - 2024-07-08 15:48:01 --> Output Class Initialized
INFO - 2024-07-08 15:48:01 --> Security Class Initialized
DEBUG - 2024-07-08 15:48:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-07-08 15:48:01 --> Input Class Initialized
INFO - 2024-07-08 15:48:01 --> Language Class Initialized
INFO - 2024-07-08 15:48:01 --> Language Class Initialized
INFO - 2024-07-08 15:48:01 --> Config Class Initialized
INFO - 2024-07-08 15:48:01 --> Loader Class Initialized
INFO - 2024-07-08 15:48:01 --> Helper loaded: url_helper
INFO - 2024-07-08 15:48:01 --> Helper loaded: file_helper
INFO - 2024-07-08 15:48:01 --> Helper loaded: form_helper
INFO - 2024-07-08 15:48:01 --> Helper loaded: my_helper
INFO - 2024-07-08 15:48:01 --> Database Driver Class Initialized
INFO - 2024-07-08 15:48:01 --> Session: Class initialized using 'files' driver.
INFO - 2024-07-08 15:48:01 --> Controller Class Initialized
INFO - 2024-07-08 15:48:33 --> Config Class Initialized
INFO - 2024-07-08 15:48:33 --> Hooks Class Initialized
DEBUG - 2024-07-08 15:48:33 --> UTF-8 Support Enabled
INFO - 2024-07-08 15:48:33 --> Utf8 Class Initialized
INFO - 2024-07-08 15:48:33 --> URI Class Initialized
INFO - 2024-07-08 15:48:33 --> Router Class Initialized
INFO - 2024-07-08 15:48:33 --> Output Class Initialized
INFO - 2024-07-08 15:48:33 --> Security Class Initialized
DEBUG - 2024-07-08 15:48:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-07-08 15:48:33 --> Input Class Initialized
INFO - 2024-07-08 15:48:33 --> Language Class Initialized
INFO - 2024-07-08 15:48:33 --> Language Class Initialized
INFO - 2024-07-08 15:48:33 --> Config Class Initialized
INFO - 2024-07-08 15:48:33 --> Loader Class Initialized
INFO - 2024-07-08 15:48:33 --> Helper loaded: url_helper
INFO - 2024-07-08 15:48:33 --> Helper loaded: file_helper
INFO - 2024-07-08 15:48:33 --> Helper loaded: form_helper
INFO - 2024-07-08 15:48:33 --> Helper loaded: my_helper
INFO - 2024-07-08 15:48:33 --> Database Driver Class Initialized
INFO - 2024-07-08 15:48:33 --> Session: Class initialized using 'files' driver.
INFO - 2024-07-08 15:48:33 --> Controller Class Initialized
DEBUG - 2024-07-08 15:48:33 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/set_mapel/views/list.php
DEBUG - 2024-07-08 15:48:33 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-07-08 15:48:33 --> Final output sent to browser
DEBUG - 2024-07-08 15:48:33 --> Total execution time: 0.0536
INFO - 2024-07-08 15:48:33 --> Config Class Initialized
INFO - 2024-07-08 15:48:33 --> Hooks Class Initialized
DEBUG - 2024-07-08 15:48:33 --> UTF-8 Support Enabled
INFO - 2024-07-08 15:48:33 --> Utf8 Class Initialized
INFO - 2024-07-08 15:48:33 --> URI Class Initialized
INFO - 2024-07-08 15:48:33 --> Router Class Initialized
INFO - 2024-07-08 15:48:33 --> Output Class Initialized
INFO - 2024-07-08 15:48:33 --> Security Class Initialized
DEBUG - 2024-07-08 15:48:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-07-08 15:48:33 --> Input Class Initialized
INFO - 2024-07-08 15:48:33 --> Language Class Initialized
ERROR - 2024-07-08 15:48:33 --> 404 Page Not Found: /index
INFO - 2024-07-08 15:48:33 --> Config Class Initialized
INFO - 2024-07-08 15:48:33 --> Hooks Class Initialized
DEBUG - 2024-07-08 15:48:33 --> UTF-8 Support Enabled
INFO - 2024-07-08 15:48:33 --> Utf8 Class Initialized
INFO - 2024-07-08 15:48:33 --> URI Class Initialized
INFO - 2024-07-08 15:48:33 --> Router Class Initialized
INFO - 2024-07-08 15:48:33 --> Output Class Initialized
INFO - 2024-07-08 15:48:33 --> Security Class Initialized
DEBUG - 2024-07-08 15:48:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-07-08 15:48:33 --> Input Class Initialized
INFO - 2024-07-08 15:48:33 --> Language Class Initialized
INFO - 2024-07-08 15:48:33 --> Language Class Initialized
INFO - 2024-07-08 15:48:33 --> Config Class Initialized
INFO - 2024-07-08 15:48:33 --> Loader Class Initialized
INFO - 2024-07-08 15:48:33 --> Helper loaded: url_helper
INFO - 2024-07-08 15:48:33 --> Helper loaded: file_helper
INFO - 2024-07-08 15:48:33 --> Helper loaded: form_helper
INFO - 2024-07-08 15:48:33 --> Helper loaded: my_helper
INFO - 2024-07-08 15:48:33 --> Database Driver Class Initialized
INFO - 2024-07-08 15:48:33 --> Session: Class initialized using 'files' driver.
INFO - 2024-07-08 15:48:33 --> Controller Class Initialized
INFO - 2024-07-08 15:48:43 --> Config Class Initialized
INFO - 2024-07-08 15:48:43 --> Hooks Class Initialized
DEBUG - 2024-07-08 15:48:43 --> UTF-8 Support Enabled
INFO - 2024-07-08 15:48:43 --> Utf8 Class Initialized
INFO - 2024-07-08 15:48:43 --> URI Class Initialized
INFO - 2024-07-08 15:48:43 --> Router Class Initialized
INFO - 2024-07-08 15:48:43 --> Output Class Initialized
INFO - 2024-07-08 15:48:43 --> Security Class Initialized
DEBUG - 2024-07-08 15:48:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-07-08 15:48:43 --> Input Class Initialized
INFO - 2024-07-08 15:48:43 --> Language Class Initialized
INFO - 2024-07-08 15:48:43 --> Language Class Initialized
INFO - 2024-07-08 15:48:43 --> Config Class Initialized
INFO - 2024-07-08 15:48:43 --> Loader Class Initialized
INFO - 2024-07-08 15:48:43 --> Helper loaded: url_helper
INFO - 2024-07-08 15:48:43 --> Helper loaded: file_helper
INFO - 2024-07-08 15:48:43 --> Helper loaded: form_helper
INFO - 2024-07-08 15:48:43 --> Helper loaded: my_helper
INFO - 2024-07-08 15:48:43 --> Database Driver Class Initialized
INFO - 2024-07-08 15:48:43 --> Session: Class initialized using 'files' driver.
INFO - 2024-07-08 15:48:43 --> Controller Class Initialized
DEBUG - 2024-07-08 15:48:43 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/data_guru/views/list.php
DEBUG - 2024-07-08 15:48:43 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-07-08 15:48:43 --> Final output sent to browser
DEBUG - 2024-07-08 15:48:43 --> Total execution time: 0.0349
INFO - 2024-07-08 15:48:43 --> Config Class Initialized
INFO - 2024-07-08 15:48:43 --> Hooks Class Initialized
DEBUG - 2024-07-08 15:48:43 --> UTF-8 Support Enabled
INFO - 2024-07-08 15:48:43 --> Utf8 Class Initialized
INFO - 2024-07-08 15:48:43 --> URI Class Initialized
INFO - 2024-07-08 15:48:43 --> Router Class Initialized
INFO - 2024-07-08 15:48:43 --> Output Class Initialized
INFO - 2024-07-08 15:48:43 --> Security Class Initialized
DEBUG - 2024-07-08 15:48:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-07-08 15:48:43 --> Input Class Initialized
INFO - 2024-07-08 15:48:43 --> Language Class Initialized
ERROR - 2024-07-08 15:48:43 --> 404 Page Not Found: /index
INFO - 2024-07-08 15:48:43 --> Config Class Initialized
INFO - 2024-07-08 15:48:43 --> Hooks Class Initialized
DEBUG - 2024-07-08 15:48:43 --> UTF-8 Support Enabled
INFO - 2024-07-08 15:48:43 --> Utf8 Class Initialized
INFO - 2024-07-08 15:48:43 --> URI Class Initialized
INFO - 2024-07-08 15:48:43 --> Router Class Initialized
INFO - 2024-07-08 15:48:43 --> Output Class Initialized
INFO - 2024-07-08 15:48:43 --> Security Class Initialized
DEBUG - 2024-07-08 15:48:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-07-08 15:48:43 --> Input Class Initialized
INFO - 2024-07-08 15:48:43 --> Language Class Initialized
INFO - 2024-07-08 15:48:43 --> Language Class Initialized
INFO - 2024-07-08 15:48:43 --> Config Class Initialized
INFO - 2024-07-08 15:48:43 --> Loader Class Initialized
INFO - 2024-07-08 15:48:43 --> Helper loaded: url_helper
INFO - 2024-07-08 15:48:43 --> Helper loaded: file_helper
INFO - 2024-07-08 15:48:43 --> Helper loaded: form_helper
INFO - 2024-07-08 15:48:43 --> Helper loaded: my_helper
INFO - 2024-07-08 15:48:43 --> Database Driver Class Initialized
INFO - 2024-07-08 15:48:43 --> Session: Class initialized using 'files' driver.
INFO - 2024-07-08 15:48:43 --> Controller Class Initialized
INFO - 2024-07-08 15:48:48 --> Config Class Initialized
INFO - 2024-07-08 15:48:48 --> Hooks Class Initialized
DEBUG - 2024-07-08 15:48:48 --> UTF-8 Support Enabled
INFO - 2024-07-08 15:48:48 --> Utf8 Class Initialized
INFO - 2024-07-08 15:48:48 --> URI Class Initialized
INFO - 2024-07-08 15:48:48 --> Router Class Initialized
INFO - 2024-07-08 15:48:48 --> Output Class Initialized
INFO - 2024-07-08 15:48:48 --> Security Class Initialized
DEBUG - 2024-07-08 15:48:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-07-08 15:48:48 --> Input Class Initialized
INFO - 2024-07-08 15:48:48 --> Language Class Initialized
INFO - 2024-07-08 15:48:48 --> Language Class Initialized
INFO - 2024-07-08 15:48:48 --> Config Class Initialized
INFO - 2024-07-08 15:48:48 --> Loader Class Initialized
INFO - 2024-07-08 15:48:48 --> Helper loaded: url_helper
INFO - 2024-07-08 15:48:48 --> Helper loaded: file_helper
INFO - 2024-07-08 15:48:48 --> Helper loaded: form_helper
INFO - 2024-07-08 15:48:48 --> Helper loaded: my_helper
INFO - 2024-07-08 15:48:48 --> Database Driver Class Initialized
INFO - 2024-07-08 15:48:48 --> Session: Class initialized using 'files' driver.
INFO - 2024-07-08 15:48:48 --> Controller Class Initialized
INFO - 2024-07-08 15:48:48 --> Final output sent to browser
DEBUG - 2024-07-08 15:48:48 --> Total execution time: 0.0355
INFO - 2024-07-08 15:49:48 --> Config Class Initialized
INFO - 2024-07-08 15:49:48 --> Hooks Class Initialized
DEBUG - 2024-07-08 15:49:48 --> UTF-8 Support Enabled
INFO - 2024-07-08 15:49:48 --> Utf8 Class Initialized
INFO - 2024-07-08 15:49:48 --> URI Class Initialized
INFO - 2024-07-08 15:49:48 --> Router Class Initialized
INFO - 2024-07-08 15:49:48 --> Output Class Initialized
INFO - 2024-07-08 15:49:48 --> Security Class Initialized
DEBUG - 2024-07-08 15:49:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-07-08 15:49:48 --> Input Class Initialized
INFO - 2024-07-08 15:49:48 --> Language Class Initialized
INFO - 2024-07-08 15:49:48 --> Language Class Initialized
INFO - 2024-07-08 15:49:48 --> Config Class Initialized
INFO - 2024-07-08 15:49:48 --> Loader Class Initialized
INFO - 2024-07-08 15:49:48 --> Helper loaded: url_helper
INFO - 2024-07-08 15:49:48 --> Helper loaded: file_helper
INFO - 2024-07-08 15:49:48 --> Helper loaded: form_helper
INFO - 2024-07-08 15:49:48 --> Helper loaded: my_helper
INFO - 2024-07-08 15:49:48 --> Database Driver Class Initialized
INFO - 2024-07-08 15:49:48 --> Session: Class initialized using 'files' driver.
INFO - 2024-07-08 15:49:48 --> Controller Class Initialized
INFO - 2024-07-08 15:49:48 --> Final output sent to browser
DEBUG - 2024-07-08 15:49:48 --> Total execution time: 0.0283
INFO - 2024-07-08 15:50:45 --> Config Class Initialized
INFO - 2024-07-08 15:50:45 --> Hooks Class Initialized
DEBUG - 2024-07-08 15:50:45 --> UTF-8 Support Enabled
INFO - 2024-07-08 15:50:45 --> Utf8 Class Initialized
INFO - 2024-07-08 15:50:45 --> URI Class Initialized
INFO - 2024-07-08 15:50:45 --> Router Class Initialized
INFO - 2024-07-08 15:50:45 --> Output Class Initialized
INFO - 2024-07-08 15:50:45 --> Security Class Initialized
DEBUG - 2024-07-08 15:50:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-07-08 15:50:45 --> Input Class Initialized
INFO - 2024-07-08 15:50:45 --> Language Class Initialized
INFO - 2024-07-08 15:50:45 --> Language Class Initialized
INFO - 2024-07-08 15:50:45 --> Config Class Initialized
INFO - 2024-07-08 15:50:45 --> Loader Class Initialized
INFO - 2024-07-08 15:50:45 --> Helper loaded: url_helper
INFO - 2024-07-08 15:50:45 --> Helper loaded: file_helper
INFO - 2024-07-08 15:50:45 --> Helper loaded: form_helper
INFO - 2024-07-08 15:50:45 --> Helper loaded: my_helper
INFO - 2024-07-08 15:50:45 --> Database Driver Class Initialized
INFO - 2024-07-08 15:50:45 --> Session: Class initialized using 'files' driver.
INFO - 2024-07-08 15:50:45 --> Controller Class Initialized
INFO - 2024-07-08 15:50:45 --> Final output sent to browser
DEBUG - 2024-07-08 15:50:45 --> Total execution time: 0.0329
INFO - 2024-07-08 15:51:02 --> Config Class Initialized
INFO - 2024-07-08 15:51:02 --> Hooks Class Initialized
DEBUG - 2024-07-08 15:51:02 --> UTF-8 Support Enabled
INFO - 2024-07-08 15:51:02 --> Utf8 Class Initialized
INFO - 2024-07-08 15:51:02 --> URI Class Initialized
INFO - 2024-07-08 15:51:02 --> Router Class Initialized
INFO - 2024-07-08 15:51:02 --> Output Class Initialized
INFO - 2024-07-08 15:51:02 --> Security Class Initialized
DEBUG - 2024-07-08 15:51:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-07-08 15:51:02 --> Input Class Initialized
INFO - 2024-07-08 15:51:02 --> Language Class Initialized
INFO - 2024-07-08 15:51:02 --> Language Class Initialized
INFO - 2024-07-08 15:51:02 --> Config Class Initialized
INFO - 2024-07-08 15:51:02 --> Loader Class Initialized
INFO - 2024-07-08 15:51:02 --> Helper loaded: url_helper
INFO - 2024-07-08 15:51:02 --> Helper loaded: file_helper
INFO - 2024-07-08 15:51:02 --> Helper loaded: form_helper
INFO - 2024-07-08 15:51:02 --> Helper loaded: my_helper
INFO - 2024-07-08 15:51:02 --> Database Driver Class Initialized
INFO - 2024-07-08 15:51:02 --> Session: Class initialized using 'files' driver.
INFO - 2024-07-08 15:51:02 --> Controller Class Initialized
INFO - 2024-07-08 15:51:02 --> Final output sent to browser
DEBUG - 2024-07-08 15:51:02 --> Total execution time: 0.0452
INFO - 2024-07-08 15:51:02 --> Config Class Initialized
INFO - 2024-07-08 15:51:02 --> Hooks Class Initialized
DEBUG - 2024-07-08 15:51:02 --> UTF-8 Support Enabled
INFO - 2024-07-08 15:51:02 --> Utf8 Class Initialized
INFO - 2024-07-08 15:51:02 --> URI Class Initialized
INFO - 2024-07-08 15:51:02 --> Router Class Initialized
INFO - 2024-07-08 15:51:02 --> Output Class Initialized
INFO - 2024-07-08 15:51:02 --> Security Class Initialized
DEBUG - 2024-07-08 15:51:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-07-08 15:51:02 --> Input Class Initialized
INFO - 2024-07-08 15:51:02 --> Language Class Initialized
ERROR - 2024-07-08 15:51:02 --> 404 Page Not Found: /index
INFO - 2024-07-08 15:51:02 --> Config Class Initialized
INFO - 2024-07-08 15:51:02 --> Hooks Class Initialized
DEBUG - 2024-07-08 15:51:02 --> UTF-8 Support Enabled
INFO - 2024-07-08 15:51:02 --> Utf8 Class Initialized
INFO - 2024-07-08 15:51:02 --> URI Class Initialized
INFO - 2024-07-08 15:51:02 --> Router Class Initialized
INFO - 2024-07-08 15:51:02 --> Output Class Initialized
INFO - 2024-07-08 15:51:02 --> Security Class Initialized
DEBUG - 2024-07-08 15:51:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-07-08 15:51:02 --> Input Class Initialized
INFO - 2024-07-08 15:51:02 --> Language Class Initialized
INFO - 2024-07-08 15:51:02 --> Language Class Initialized
INFO - 2024-07-08 15:51:02 --> Config Class Initialized
INFO - 2024-07-08 15:51:02 --> Loader Class Initialized
INFO - 2024-07-08 15:51:02 --> Helper loaded: url_helper
INFO - 2024-07-08 15:51:02 --> Helper loaded: file_helper
INFO - 2024-07-08 15:51:02 --> Helper loaded: form_helper
INFO - 2024-07-08 15:51:02 --> Helper loaded: my_helper
INFO - 2024-07-08 15:51:02 --> Database Driver Class Initialized
INFO - 2024-07-08 15:51:02 --> Session: Class initialized using 'files' driver.
INFO - 2024-07-08 15:51:02 --> Controller Class Initialized
INFO - 2024-07-08 15:51:13 --> Config Class Initialized
INFO - 2024-07-08 15:51:13 --> Hooks Class Initialized
DEBUG - 2024-07-08 15:51:13 --> UTF-8 Support Enabled
INFO - 2024-07-08 15:51:13 --> Utf8 Class Initialized
INFO - 2024-07-08 15:51:13 --> URI Class Initialized
INFO - 2024-07-08 15:51:13 --> Router Class Initialized
INFO - 2024-07-08 15:51:13 --> Output Class Initialized
INFO - 2024-07-08 15:51:13 --> Security Class Initialized
DEBUG - 2024-07-08 15:51:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-07-08 15:51:13 --> Input Class Initialized
INFO - 2024-07-08 15:51:13 --> Language Class Initialized
INFO - 2024-07-08 15:51:13 --> Language Class Initialized
INFO - 2024-07-08 15:51:13 --> Config Class Initialized
INFO - 2024-07-08 15:51:13 --> Loader Class Initialized
INFO - 2024-07-08 15:51:13 --> Helper loaded: url_helper
INFO - 2024-07-08 15:51:13 --> Helper loaded: file_helper
INFO - 2024-07-08 15:51:13 --> Helper loaded: form_helper
INFO - 2024-07-08 15:51:13 --> Helper loaded: my_helper
INFO - 2024-07-08 15:51:13 --> Database Driver Class Initialized
INFO - 2024-07-08 15:51:13 --> Session: Class initialized using 'files' driver.
INFO - 2024-07-08 15:51:13 --> Controller Class Initialized
INFO - 2024-07-08 15:51:13 --> Final output sent to browser
DEBUG - 2024-07-08 15:51:13 --> Total execution time: 0.0401
INFO - 2024-07-08 15:51:13 --> Config Class Initialized
INFO - 2024-07-08 15:51:13 --> Hooks Class Initialized
DEBUG - 2024-07-08 15:51:13 --> UTF-8 Support Enabled
INFO - 2024-07-08 15:51:13 --> Utf8 Class Initialized
INFO - 2024-07-08 15:51:13 --> URI Class Initialized
INFO - 2024-07-08 15:51:13 --> Router Class Initialized
INFO - 2024-07-08 15:51:13 --> Output Class Initialized
INFO - 2024-07-08 15:51:13 --> Security Class Initialized
DEBUG - 2024-07-08 15:51:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-07-08 15:51:13 --> Input Class Initialized
INFO - 2024-07-08 15:51:13 --> Language Class Initialized
ERROR - 2024-07-08 15:51:13 --> 404 Page Not Found: /index
INFO - 2024-07-08 15:51:13 --> Config Class Initialized
INFO - 2024-07-08 15:51:13 --> Hooks Class Initialized
DEBUG - 2024-07-08 15:51:13 --> UTF-8 Support Enabled
INFO - 2024-07-08 15:51:13 --> Utf8 Class Initialized
INFO - 2024-07-08 15:51:13 --> URI Class Initialized
INFO - 2024-07-08 15:51:13 --> Router Class Initialized
INFO - 2024-07-08 15:51:13 --> Output Class Initialized
INFO - 2024-07-08 15:51:13 --> Security Class Initialized
DEBUG - 2024-07-08 15:51:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-07-08 15:51:13 --> Input Class Initialized
INFO - 2024-07-08 15:51:13 --> Language Class Initialized
INFO - 2024-07-08 15:51:13 --> Language Class Initialized
INFO - 2024-07-08 15:51:13 --> Config Class Initialized
INFO - 2024-07-08 15:51:13 --> Loader Class Initialized
INFO - 2024-07-08 15:51:13 --> Helper loaded: url_helper
INFO - 2024-07-08 15:51:13 --> Helper loaded: file_helper
INFO - 2024-07-08 15:51:13 --> Helper loaded: form_helper
INFO - 2024-07-08 15:51:13 --> Helper loaded: my_helper
INFO - 2024-07-08 15:51:13 --> Database Driver Class Initialized
INFO - 2024-07-08 15:51:13 --> Session: Class initialized using 'files' driver.
INFO - 2024-07-08 15:51:13 --> Controller Class Initialized
INFO - 2024-07-08 15:51:37 --> Config Class Initialized
INFO - 2024-07-08 15:51:37 --> Hooks Class Initialized
DEBUG - 2024-07-08 15:51:37 --> UTF-8 Support Enabled
INFO - 2024-07-08 15:51:37 --> Utf8 Class Initialized
INFO - 2024-07-08 15:51:37 --> URI Class Initialized
INFO - 2024-07-08 15:51:37 --> Router Class Initialized
INFO - 2024-07-08 15:51:37 --> Output Class Initialized
INFO - 2024-07-08 15:51:37 --> Security Class Initialized
DEBUG - 2024-07-08 15:51:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-07-08 15:51:37 --> Input Class Initialized
INFO - 2024-07-08 15:51:37 --> Language Class Initialized
INFO - 2024-07-08 15:51:37 --> Language Class Initialized
INFO - 2024-07-08 15:51:37 --> Config Class Initialized
INFO - 2024-07-08 15:51:37 --> Loader Class Initialized
INFO - 2024-07-08 15:51:37 --> Helper loaded: url_helper
INFO - 2024-07-08 15:51:37 --> Helper loaded: file_helper
INFO - 2024-07-08 15:51:37 --> Helper loaded: form_helper
INFO - 2024-07-08 15:51:37 --> Helper loaded: my_helper
INFO - 2024-07-08 15:51:37 --> Database Driver Class Initialized
INFO - 2024-07-08 15:51:37 --> Session: Class initialized using 'files' driver.
INFO - 2024-07-08 15:51:37 --> Controller Class Initialized
DEBUG - 2024-07-08 15:51:37 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/data_kelas/views/list.php
DEBUG - 2024-07-08 15:51:37 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-07-08 15:51:37 --> Final output sent to browser
DEBUG - 2024-07-08 15:51:37 --> Total execution time: 0.0336
INFO - 2024-07-08 15:51:37 --> Config Class Initialized
INFO - 2024-07-08 15:51:37 --> Hooks Class Initialized
DEBUG - 2024-07-08 15:51:37 --> UTF-8 Support Enabled
INFO - 2024-07-08 15:51:37 --> Utf8 Class Initialized
INFO - 2024-07-08 15:51:37 --> URI Class Initialized
INFO - 2024-07-08 15:51:37 --> Router Class Initialized
INFO - 2024-07-08 15:51:37 --> Output Class Initialized
INFO - 2024-07-08 15:51:37 --> Security Class Initialized
DEBUG - 2024-07-08 15:51:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-07-08 15:51:37 --> Input Class Initialized
INFO - 2024-07-08 15:51:37 --> Language Class Initialized
ERROR - 2024-07-08 15:51:37 --> 404 Page Not Found: /index
INFO - 2024-07-08 15:51:37 --> Config Class Initialized
INFO - 2024-07-08 15:51:37 --> Hooks Class Initialized
DEBUG - 2024-07-08 15:51:37 --> UTF-8 Support Enabled
INFO - 2024-07-08 15:51:37 --> Utf8 Class Initialized
INFO - 2024-07-08 15:51:37 --> URI Class Initialized
INFO - 2024-07-08 15:51:37 --> Router Class Initialized
INFO - 2024-07-08 15:51:37 --> Output Class Initialized
INFO - 2024-07-08 15:51:37 --> Security Class Initialized
DEBUG - 2024-07-08 15:51:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-07-08 15:51:37 --> Input Class Initialized
INFO - 2024-07-08 15:51:37 --> Language Class Initialized
INFO - 2024-07-08 15:51:37 --> Language Class Initialized
INFO - 2024-07-08 15:51:37 --> Config Class Initialized
INFO - 2024-07-08 15:51:37 --> Loader Class Initialized
INFO - 2024-07-08 15:51:37 --> Helper loaded: url_helper
INFO - 2024-07-08 15:51:37 --> Helper loaded: file_helper
INFO - 2024-07-08 15:51:37 --> Helper loaded: form_helper
INFO - 2024-07-08 15:51:37 --> Helper loaded: my_helper
INFO - 2024-07-08 15:51:37 --> Database Driver Class Initialized
INFO - 2024-07-08 15:51:37 --> Session: Class initialized using 'files' driver.
INFO - 2024-07-08 15:51:37 --> Controller Class Initialized
INFO - 2024-07-08 15:51:45 --> Config Class Initialized
INFO - 2024-07-08 15:51:45 --> Hooks Class Initialized
DEBUG - 2024-07-08 15:51:45 --> UTF-8 Support Enabled
INFO - 2024-07-08 15:51:45 --> Utf8 Class Initialized
INFO - 2024-07-08 15:51:45 --> URI Class Initialized
INFO - 2024-07-08 15:51:45 --> Router Class Initialized
INFO - 2024-07-08 15:51:45 --> Output Class Initialized
INFO - 2024-07-08 15:51:45 --> Security Class Initialized
DEBUG - 2024-07-08 15:51:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-07-08 15:51:45 --> Input Class Initialized
INFO - 2024-07-08 15:51:45 --> Language Class Initialized
INFO - 2024-07-08 15:51:45 --> Language Class Initialized
INFO - 2024-07-08 15:51:45 --> Config Class Initialized
INFO - 2024-07-08 15:51:45 --> Loader Class Initialized
INFO - 2024-07-08 15:51:45 --> Helper loaded: url_helper
INFO - 2024-07-08 15:51:45 --> Helper loaded: file_helper
INFO - 2024-07-08 15:51:45 --> Helper loaded: form_helper
INFO - 2024-07-08 15:51:45 --> Helper loaded: my_helper
INFO - 2024-07-08 15:51:45 --> Database Driver Class Initialized
INFO - 2024-07-08 15:51:45 --> Session: Class initialized using 'files' driver.
INFO - 2024-07-08 15:51:45 --> Controller Class Initialized
DEBUG - 2024-07-08 15:51:45 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/data_mapel/views/list.php
DEBUG - 2024-07-08 15:51:45 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-07-08 15:51:45 --> Final output sent to browser
DEBUG - 2024-07-08 15:51:45 --> Total execution time: 0.0311
INFO - 2024-07-08 15:51:45 --> Config Class Initialized
INFO - 2024-07-08 15:51:45 --> Hooks Class Initialized
DEBUG - 2024-07-08 15:51:45 --> UTF-8 Support Enabled
INFO - 2024-07-08 15:51:45 --> Utf8 Class Initialized
INFO - 2024-07-08 15:51:45 --> URI Class Initialized
INFO - 2024-07-08 15:51:45 --> Router Class Initialized
INFO - 2024-07-08 15:51:45 --> Output Class Initialized
INFO - 2024-07-08 15:51:45 --> Security Class Initialized
DEBUG - 2024-07-08 15:51:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-07-08 15:51:45 --> Input Class Initialized
INFO - 2024-07-08 15:51:45 --> Language Class Initialized
ERROR - 2024-07-08 15:51:45 --> 404 Page Not Found: /index
INFO - 2024-07-08 15:51:46 --> Config Class Initialized
INFO - 2024-07-08 15:51:46 --> Hooks Class Initialized
DEBUG - 2024-07-08 15:51:46 --> UTF-8 Support Enabled
INFO - 2024-07-08 15:51:46 --> Utf8 Class Initialized
INFO - 2024-07-08 15:51:46 --> URI Class Initialized
INFO - 2024-07-08 15:51:46 --> Router Class Initialized
INFO - 2024-07-08 15:51:46 --> Output Class Initialized
INFO - 2024-07-08 15:51:46 --> Security Class Initialized
DEBUG - 2024-07-08 15:51:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-07-08 15:51:46 --> Input Class Initialized
INFO - 2024-07-08 15:51:46 --> Language Class Initialized
INFO - 2024-07-08 15:51:46 --> Language Class Initialized
INFO - 2024-07-08 15:51:46 --> Config Class Initialized
INFO - 2024-07-08 15:51:46 --> Loader Class Initialized
INFO - 2024-07-08 15:51:46 --> Helper loaded: url_helper
INFO - 2024-07-08 15:51:46 --> Helper loaded: file_helper
INFO - 2024-07-08 15:51:46 --> Helper loaded: form_helper
INFO - 2024-07-08 15:51:46 --> Helper loaded: my_helper
INFO - 2024-07-08 15:51:46 --> Database Driver Class Initialized
INFO - 2024-07-08 15:51:46 --> Session: Class initialized using 'files' driver.
INFO - 2024-07-08 15:51:46 --> Controller Class Initialized
