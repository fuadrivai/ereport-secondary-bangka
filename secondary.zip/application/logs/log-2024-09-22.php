<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2024-09-22 19:20:53 --> Config Class Initialized
INFO - 2024-09-22 19:20:53 --> Hooks Class Initialized
DEBUG - 2024-09-22 19:20:53 --> UTF-8 Support Enabled
INFO - 2024-09-22 19:20:53 --> Utf8 Class Initialized
INFO - 2024-09-22 19:20:53 --> URI Class Initialized
INFO - 2024-09-22 19:20:53 --> Router Class Initialized
INFO - 2024-09-22 19:20:53 --> Output Class Initialized
INFO - 2024-09-22 19:20:53 --> Security Class Initialized
DEBUG - 2024-09-22 19:20:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-22 19:20:53 --> Input Class Initialized
INFO - 2024-09-22 19:20:53 --> Language Class Initialized
INFO - 2024-09-22 19:20:53 --> Language Class Initialized
INFO - 2024-09-22 19:20:53 --> Config Class Initialized
INFO - 2024-09-22 19:20:53 --> Loader Class Initialized
INFO - 2024-09-22 19:20:53 --> Helper loaded: url_helper
INFO - 2024-09-22 19:20:53 --> Helper loaded: file_helper
INFO - 2024-09-22 19:20:53 --> Helper loaded: form_helper
INFO - 2024-09-22 19:20:53 --> Helper loaded: my_helper
INFO - 2024-09-22 19:20:53 --> Database Driver Class Initialized
INFO - 2024-09-22 19:20:53 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-22 19:20:53 --> Controller Class Initialized
INFO - 2024-09-22 19:20:53 --> Helper loaded: cookie_helper
INFO - 2024-09-22 19:20:53 --> Final output sent to browser
DEBUG - 2024-09-22 19:20:53 --> Total execution time: 0.1836
INFO - 2024-09-22 19:20:53 --> Config Class Initialized
INFO - 2024-09-22 19:20:53 --> Hooks Class Initialized
DEBUG - 2024-09-22 19:20:53 --> UTF-8 Support Enabled
INFO - 2024-09-22 19:20:53 --> Utf8 Class Initialized
INFO - 2024-09-22 19:20:53 --> URI Class Initialized
INFO - 2024-09-22 19:20:53 --> Router Class Initialized
INFO - 2024-09-22 19:20:53 --> Output Class Initialized
INFO - 2024-09-22 19:20:53 --> Security Class Initialized
DEBUG - 2024-09-22 19:20:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-22 19:20:53 --> Input Class Initialized
INFO - 2024-09-22 19:20:53 --> Language Class Initialized
INFO - 2024-09-22 19:20:53 --> Language Class Initialized
INFO - 2024-09-22 19:20:53 --> Config Class Initialized
INFO - 2024-09-22 19:20:53 --> Loader Class Initialized
INFO - 2024-09-22 19:20:53 --> Helper loaded: url_helper
INFO - 2024-09-22 19:20:53 --> Helper loaded: file_helper
INFO - 2024-09-22 19:20:53 --> Helper loaded: form_helper
INFO - 2024-09-22 19:20:53 --> Helper loaded: my_helper
INFO - 2024-09-22 19:20:53 --> Database Driver Class Initialized
INFO - 2024-09-22 19:20:53 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-22 19:20:53 --> Controller Class Initialized
INFO - 2024-09-22 19:20:53 --> Helper loaded: cookie_helper
INFO - 2024-09-22 19:20:53 --> Config Class Initialized
INFO - 2024-09-22 19:20:53 --> Hooks Class Initialized
DEBUG - 2024-09-22 19:20:53 --> UTF-8 Support Enabled
INFO - 2024-09-22 19:20:53 --> Utf8 Class Initialized
INFO - 2024-09-22 19:20:53 --> URI Class Initialized
INFO - 2024-09-22 19:20:53 --> Router Class Initialized
INFO - 2024-09-22 19:20:53 --> Output Class Initialized
INFO - 2024-09-22 19:20:53 --> Security Class Initialized
DEBUG - 2024-09-22 19:20:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-22 19:20:53 --> Input Class Initialized
INFO - 2024-09-22 19:20:53 --> Language Class Initialized
INFO - 2024-09-22 19:20:53 --> Language Class Initialized
INFO - 2024-09-22 19:20:53 --> Config Class Initialized
INFO - 2024-09-22 19:20:53 --> Loader Class Initialized
INFO - 2024-09-22 19:20:53 --> Helper loaded: url_helper
INFO - 2024-09-22 19:20:53 --> Helper loaded: file_helper
INFO - 2024-09-22 19:20:53 --> Helper loaded: form_helper
INFO - 2024-09-22 19:20:53 --> Helper loaded: my_helper
INFO - 2024-09-22 19:20:53 --> Database Driver Class Initialized
INFO - 2024-09-22 19:20:53 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-22 19:20:53 --> Controller Class Initialized
DEBUG - 2024-09-22 19:20:53 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/lihat_raport/views/list.php
DEBUG - 2024-09-22 19:20:53 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-09-22 19:20:53 --> Final output sent to browser
DEBUG - 2024-09-22 19:20:53 --> Total execution time: 0.0661
INFO - 2024-09-22 19:21:06 --> Config Class Initialized
INFO - 2024-09-22 19:21:06 --> Hooks Class Initialized
DEBUG - 2024-09-22 19:21:06 --> UTF-8 Support Enabled
INFO - 2024-09-22 19:21:06 --> Utf8 Class Initialized
INFO - 2024-09-22 19:21:06 --> URI Class Initialized
INFO - 2024-09-22 19:21:06 --> Router Class Initialized
INFO - 2024-09-22 19:21:06 --> Output Class Initialized
INFO - 2024-09-22 19:21:06 --> Security Class Initialized
DEBUG - 2024-09-22 19:21:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-22 19:21:06 --> Input Class Initialized
INFO - 2024-09-22 19:21:06 --> Language Class Initialized
INFO - 2024-09-22 19:21:06 --> Language Class Initialized
INFO - 2024-09-22 19:21:06 --> Config Class Initialized
INFO - 2024-09-22 19:21:06 --> Loader Class Initialized
INFO - 2024-09-22 19:21:06 --> Helper loaded: url_helper
INFO - 2024-09-22 19:21:06 --> Helper loaded: file_helper
INFO - 2024-09-22 19:21:06 --> Helper loaded: form_helper
INFO - 2024-09-22 19:21:06 --> Helper loaded: my_helper
INFO - 2024-09-22 19:21:06 --> Database Driver Class Initialized
INFO - 2024-09-22 19:21:06 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-22 19:21:06 --> Controller Class Initialized
ERROR - 2024-09-22 19:21:06 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1160
ERROR - 2024-09-22 19:21:06 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1692
ERROR - 2024-09-22 19:21:06 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1729
ERROR - 2024-09-22 19:21:07 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1767
ERROR - 2024-09-22 19:21:07 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1806
ERROR - 2024-09-22 19:21:07 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1883
ERROR - 2024-09-22 19:21:07 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1962
ERROR - 2024-09-22 19:21:07 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 2042
ERROR - 2024-09-22 19:21:07 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 2122
ERROR - 2024-09-22 19:21:07 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 2202
ERROR - 2024-09-22 19:21:07 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 2277
ERROR - 2024-09-22 19:21:07 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php 32
ERROR - 2024-09-22 19:21:07 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php 32
DEBUG - 2024-09-22 19:21:07 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php
INFO - 2024-09-22 19:21:10 --> Final output sent to browser
DEBUG - 2024-09-22 19:21:10 --> Total execution time: 4.3192
INFO - 2024-09-22 19:21:28 --> Config Class Initialized
INFO - 2024-09-22 19:21:28 --> Hooks Class Initialized
DEBUG - 2024-09-22 19:21:28 --> UTF-8 Support Enabled
INFO - 2024-09-22 19:21:28 --> Utf8 Class Initialized
INFO - 2024-09-22 19:21:28 --> URI Class Initialized
INFO - 2024-09-22 19:21:28 --> Router Class Initialized
INFO - 2024-09-22 19:21:28 --> Output Class Initialized
INFO - 2024-09-22 19:21:28 --> Security Class Initialized
DEBUG - 2024-09-22 19:21:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-22 19:21:28 --> Input Class Initialized
INFO - 2024-09-22 19:21:28 --> Language Class Initialized
INFO - 2024-09-22 19:21:28 --> Language Class Initialized
INFO - 2024-09-22 19:21:28 --> Config Class Initialized
INFO - 2024-09-22 19:21:28 --> Loader Class Initialized
INFO - 2024-09-22 19:21:28 --> Helper loaded: url_helper
INFO - 2024-09-22 19:21:28 --> Helper loaded: file_helper
INFO - 2024-09-22 19:21:28 --> Helper loaded: form_helper
INFO - 2024-09-22 19:21:28 --> Helper loaded: my_helper
INFO - 2024-09-22 19:21:28 --> Database Driver Class Initialized
INFO - 2024-09-22 19:21:28 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-22 19:21:28 --> Controller Class Initialized
DEBUG - 2024-09-22 19:21:28 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/lihat_raport/views/list.php
DEBUG - 2024-09-22 19:21:28 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-09-22 19:21:28 --> Final output sent to browser
DEBUG - 2024-09-22 19:21:28 --> Total execution time: 0.1472
