<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2024-07-22 14:35:51 --> Config Class Initialized
INFO - 2024-07-22 14:35:51 --> Hooks Class Initialized
DEBUG - 2024-07-22 14:35:51 --> UTF-8 Support Enabled
INFO - 2024-07-22 14:35:51 --> Utf8 Class Initialized
INFO - 2024-07-22 14:35:51 --> URI Class Initialized
INFO - 2024-07-22 14:35:51 --> Router Class Initialized
INFO - 2024-07-22 14:35:51 --> Output Class Initialized
INFO - 2024-07-22 14:35:51 --> Security Class Initialized
DEBUG - 2024-07-22 14:35:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-07-22 14:35:51 --> Input Class Initialized
INFO - 2024-07-22 14:35:51 --> Language Class Initialized
INFO - 2024-07-22 14:35:51 --> Language Class Initialized
INFO - 2024-07-22 14:35:51 --> Config Class Initialized
INFO - 2024-07-22 14:35:51 --> Loader Class Initialized
INFO - 2024-07-22 14:35:51 --> Helper loaded: url_helper
INFO - 2024-07-22 14:35:51 --> Helper loaded: file_helper
INFO - 2024-07-22 14:35:51 --> Helper loaded: form_helper
INFO - 2024-07-22 14:35:51 --> Helper loaded: my_helper
INFO - 2024-07-22 14:35:51 --> Database Driver Class Initialized
INFO - 2024-07-22 14:35:51 --> Session: Class initialized using 'files' driver.
INFO - 2024-07-22 14:35:51 --> Controller Class Initialized
INFO - 2024-07-22 14:35:52 --> Config Class Initialized
INFO - 2024-07-22 14:35:52 --> Hooks Class Initialized
DEBUG - 2024-07-22 14:35:52 --> UTF-8 Support Enabled
INFO - 2024-07-22 14:35:52 --> Utf8 Class Initialized
INFO - 2024-07-22 14:35:52 --> URI Class Initialized
INFO - 2024-07-22 14:35:52 --> Router Class Initialized
INFO - 2024-07-22 14:35:52 --> Output Class Initialized
INFO - 2024-07-22 14:35:52 --> Security Class Initialized
DEBUG - 2024-07-22 14:35:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-07-22 14:35:52 --> Input Class Initialized
INFO - 2024-07-22 14:35:52 --> Language Class Initialized
INFO - 2024-07-22 14:35:52 --> Language Class Initialized
INFO - 2024-07-22 14:35:52 --> Config Class Initialized
INFO - 2024-07-22 14:35:52 --> Loader Class Initialized
INFO - 2024-07-22 14:35:52 --> Helper loaded: url_helper
INFO - 2024-07-22 14:35:52 --> Helper loaded: file_helper
INFO - 2024-07-22 14:35:52 --> Helper loaded: form_helper
INFO - 2024-07-22 14:35:52 --> Helper loaded: my_helper
INFO - 2024-07-22 14:35:52 --> Database Driver Class Initialized
INFO - 2024-07-22 14:35:52 --> Session: Class initialized using 'files' driver.
INFO - 2024-07-22 14:35:52 --> Controller Class Initialized
DEBUG - 2024-07-22 14:35:52 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/login/views/login.php
DEBUG - 2024-07-22 14:35:52 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-07-22 14:35:52 --> Final output sent to browser
DEBUG - 2024-07-22 14:35:52 --> Total execution time: 0.0457
