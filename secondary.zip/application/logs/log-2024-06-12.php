<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2024-06-12 07:57:40 --> Config Class Initialized
INFO - 2024-06-12 07:57:40 --> Hooks Class Initialized
DEBUG - 2024-06-12 07:57:40 --> UTF-8 Support Enabled
INFO - 2024-06-12 07:57:40 --> Utf8 Class Initialized
INFO - 2024-06-12 07:57:40 --> URI Class Initialized
INFO - 2024-06-12 07:57:40 --> Router Class Initialized
INFO - 2024-06-12 07:57:40 --> Output Class Initialized
INFO - 2024-06-12 07:57:40 --> Security Class Initialized
DEBUG - 2024-06-12 07:57:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-12 07:57:40 --> Input Class Initialized
INFO - 2024-06-12 07:57:40 --> Language Class Initialized
INFO - 2024-06-12 07:57:40 --> Language Class Initialized
INFO - 2024-06-12 07:57:40 --> Config Class Initialized
INFO - 2024-06-12 07:57:40 --> Loader Class Initialized
INFO - 2024-06-12 07:57:40 --> Helper loaded: url_helper
INFO - 2024-06-12 07:57:40 --> Helper loaded: file_helper
INFO - 2024-06-12 07:57:40 --> Helper loaded: form_helper
INFO - 2024-06-12 07:57:40 --> Helper loaded: my_helper
INFO - 2024-06-12 07:57:40 --> Database Driver Class Initialized
INFO - 2024-06-12 07:57:40 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-12 07:57:40 --> Controller Class Initialized
DEBUG - 2024-06-12 07:57:40 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/data_ekstra/views/list.php
DEBUG - 2024-06-12 07:57:40 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-06-12 07:57:40 --> Final output sent to browser
DEBUG - 2024-06-12 07:57:40 --> Total execution time: 0.4915
INFO - 2024-06-12 07:57:41 --> Config Class Initialized
INFO - 2024-06-12 07:57:41 --> Hooks Class Initialized
DEBUG - 2024-06-12 07:57:41 --> UTF-8 Support Enabled
INFO - 2024-06-12 07:57:41 --> Utf8 Class Initialized
INFO - 2024-06-12 07:57:41 --> URI Class Initialized
INFO - 2024-06-12 07:57:41 --> Router Class Initialized
INFO - 2024-06-12 07:57:41 --> Output Class Initialized
INFO - 2024-06-12 07:57:41 --> Security Class Initialized
DEBUG - 2024-06-12 07:57:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-12 07:57:41 --> Input Class Initialized
INFO - 2024-06-12 07:57:41 --> Language Class Initialized
ERROR - 2024-06-12 07:57:41 --> 404 Page Not Found: /index
INFO - 2024-06-12 07:57:41 --> Config Class Initialized
INFO - 2024-06-12 07:57:41 --> Hooks Class Initialized
DEBUG - 2024-06-12 07:57:41 --> UTF-8 Support Enabled
INFO - 2024-06-12 07:57:41 --> Utf8 Class Initialized
INFO - 2024-06-12 07:57:41 --> URI Class Initialized
INFO - 2024-06-12 07:57:41 --> Router Class Initialized
INFO - 2024-06-12 07:57:41 --> Output Class Initialized
INFO - 2024-06-12 07:57:41 --> Security Class Initialized
DEBUG - 2024-06-12 07:57:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-12 07:57:41 --> Input Class Initialized
INFO - 2024-06-12 07:57:41 --> Language Class Initialized
INFO - 2024-06-12 07:57:41 --> Language Class Initialized
INFO - 2024-06-12 07:57:41 --> Config Class Initialized
INFO - 2024-06-12 07:57:41 --> Loader Class Initialized
INFO - 2024-06-12 07:57:41 --> Helper loaded: url_helper
INFO - 2024-06-12 07:57:41 --> Helper loaded: file_helper
INFO - 2024-06-12 07:57:41 --> Helper loaded: form_helper
INFO - 2024-06-12 07:57:41 --> Helper loaded: my_helper
INFO - 2024-06-12 07:57:41 --> Database Driver Class Initialized
INFO - 2024-06-12 07:57:41 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-12 07:57:41 --> Controller Class Initialized
INFO - 2024-06-12 16:10:28 --> Config Class Initialized
INFO - 2024-06-12 16:10:28 --> Hooks Class Initialized
DEBUG - 2024-06-12 16:10:28 --> UTF-8 Support Enabled
INFO - 2024-06-12 16:10:28 --> Utf8 Class Initialized
INFO - 2024-06-12 16:10:28 --> URI Class Initialized
INFO - 2024-06-12 16:10:28 --> Router Class Initialized
INFO - 2024-06-12 16:10:28 --> Output Class Initialized
INFO - 2024-06-12 16:10:28 --> Security Class Initialized
DEBUG - 2024-06-12 16:10:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-12 16:10:28 --> Input Class Initialized
INFO - 2024-06-12 16:10:28 --> Language Class Initialized
INFO - 2024-06-12 16:10:28 --> Language Class Initialized
INFO - 2024-06-12 16:10:28 --> Config Class Initialized
INFO - 2024-06-12 16:10:28 --> Loader Class Initialized
INFO - 2024-06-12 16:10:28 --> Helper loaded: url_helper
INFO - 2024-06-12 16:10:28 --> Helper loaded: file_helper
INFO - 2024-06-12 16:10:28 --> Helper loaded: form_helper
INFO - 2024-06-12 16:10:28 --> Helper loaded: my_helper
INFO - 2024-06-12 16:10:28 --> Database Driver Class Initialized
INFO - 2024-06-12 16:10:28 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-12 16:10:28 --> Controller Class Initialized
DEBUG - 2024-06-12 16:10:28 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/login/views/login.php
DEBUG - 2024-06-12 16:10:28 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-06-12 16:10:28 --> Final output sent to browser
DEBUG - 2024-06-12 16:10:28 --> Total execution time: 0.0738
INFO - 2024-06-12 16:10:32 --> Config Class Initialized
INFO - 2024-06-12 16:10:32 --> Hooks Class Initialized
DEBUG - 2024-06-12 16:10:32 --> UTF-8 Support Enabled
INFO - 2024-06-12 16:10:32 --> Utf8 Class Initialized
INFO - 2024-06-12 16:10:32 --> URI Class Initialized
INFO - 2024-06-12 16:10:32 --> Router Class Initialized
INFO - 2024-06-12 16:10:32 --> Output Class Initialized
INFO - 2024-06-12 16:10:32 --> Security Class Initialized
DEBUG - 2024-06-12 16:10:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-12 16:10:32 --> Input Class Initialized
INFO - 2024-06-12 16:10:32 --> Language Class Initialized
INFO - 2024-06-12 16:10:32 --> Language Class Initialized
INFO - 2024-06-12 16:10:32 --> Config Class Initialized
INFO - 2024-06-12 16:10:32 --> Loader Class Initialized
INFO - 2024-06-12 16:10:32 --> Helper loaded: url_helper
INFO - 2024-06-12 16:10:32 --> Helper loaded: file_helper
INFO - 2024-06-12 16:10:32 --> Helper loaded: form_helper
INFO - 2024-06-12 16:10:32 --> Helper loaded: my_helper
INFO - 2024-06-12 16:10:32 --> Database Driver Class Initialized
INFO - 2024-06-12 16:10:32 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-12 16:10:32 --> Controller Class Initialized
INFO - 2024-06-12 16:10:32 --> Helper loaded: cookie_helper
INFO - 2024-06-12 16:10:32 --> Final output sent to browser
DEBUG - 2024-06-12 16:10:32 --> Total execution time: 0.0613
INFO - 2024-06-12 16:10:32 --> Config Class Initialized
INFO - 2024-06-12 16:10:32 --> Hooks Class Initialized
DEBUG - 2024-06-12 16:10:32 --> UTF-8 Support Enabled
INFO - 2024-06-12 16:10:32 --> Utf8 Class Initialized
INFO - 2024-06-12 16:10:32 --> URI Class Initialized
INFO - 2024-06-12 16:10:32 --> Router Class Initialized
INFO - 2024-06-12 16:10:32 --> Output Class Initialized
INFO - 2024-06-12 16:10:32 --> Security Class Initialized
DEBUG - 2024-06-12 16:10:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-12 16:10:32 --> Input Class Initialized
INFO - 2024-06-12 16:10:32 --> Language Class Initialized
INFO - 2024-06-12 16:10:32 --> Language Class Initialized
INFO - 2024-06-12 16:10:32 --> Config Class Initialized
INFO - 2024-06-12 16:10:32 --> Loader Class Initialized
INFO - 2024-06-12 16:10:32 --> Helper loaded: url_helper
INFO - 2024-06-12 16:10:32 --> Helper loaded: file_helper
INFO - 2024-06-12 16:10:32 --> Helper loaded: form_helper
INFO - 2024-06-12 16:10:32 --> Helper loaded: my_helper
INFO - 2024-06-12 16:10:32 --> Database Driver Class Initialized
INFO - 2024-06-12 16:10:32 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-12 16:10:32 --> Controller Class Initialized
DEBUG - 2024-06-12 16:10:32 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/home/views/v_home.php
DEBUG - 2024-06-12 16:10:32 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-06-12 16:10:32 --> Final output sent to browser
DEBUG - 2024-06-12 16:10:32 --> Total execution time: 0.0537
INFO - 2024-06-12 16:10:41 --> Config Class Initialized
INFO - 2024-06-12 16:10:41 --> Hooks Class Initialized
DEBUG - 2024-06-12 16:10:41 --> UTF-8 Support Enabled
INFO - 2024-06-12 16:10:41 --> Utf8 Class Initialized
INFO - 2024-06-12 16:10:41 --> URI Class Initialized
INFO - 2024-06-12 16:10:41 --> Router Class Initialized
INFO - 2024-06-12 16:10:41 --> Output Class Initialized
INFO - 2024-06-12 16:10:41 --> Security Class Initialized
DEBUG - 2024-06-12 16:10:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-12 16:10:41 --> Input Class Initialized
INFO - 2024-06-12 16:10:41 --> Language Class Initialized
INFO - 2024-06-12 16:10:41 --> Language Class Initialized
INFO - 2024-06-12 16:10:41 --> Config Class Initialized
INFO - 2024-06-12 16:10:41 --> Loader Class Initialized
INFO - 2024-06-12 16:10:41 --> Helper loaded: url_helper
INFO - 2024-06-12 16:10:41 --> Helper loaded: file_helper
INFO - 2024-06-12 16:10:41 --> Helper loaded: form_helper
INFO - 2024-06-12 16:10:41 --> Helper loaded: my_helper
INFO - 2024-06-12 16:10:41 --> Database Driver Class Initialized
INFO - 2024-06-12 16:10:41 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-12 16:10:41 --> Controller Class Initialized
DEBUG - 2024-06-12 16:10:41 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/data_guru/views/list.php
DEBUG - 2024-06-12 16:10:41 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-06-12 16:10:41 --> Final output sent to browser
DEBUG - 2024-06-12 16:10:41 --> Total execution time: 0.0295
INFO - 2024-06-12 16:10:41 --> Config Class Initialized
INFO - 2024-06-12 16:10:41 --> Hooks Class Initialized
DEBUG - 2024-06-12 16:10:41 --> UTF-8 Support Enabled
INFO - 2024-06-12 16:10:41 --> Utf8 Class Initialized
INFO - 2024-06-12 16:10:41 --> URI Class Initialized
INFO - 2024-06-12 16:10:41 --> Router Class Initialized
INFO - 2024-06-12 16:10:41 --> Output Class Initialized
INFO - 2024-06-12 16:10:41 --> Security Class Initialized
DEBUG - 2024-06-12 16:10:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-12 16:10:41 --> Input Class Initialized
INFO - 2024-06-12 16:10:41 --> Language Class Initialized
ERROR - 2024-06-12 16:10:41 --> 404 Page Not Found: /index
INFO - 2024-06-12 16:10:41 --> Config Class Initialized
INFO - 2024-06-12 16:10:41 --> Hooks Class Initialized
DEBUG - 2024-06-12 16:10:41 --> UTF-8 Support Enabled
INFO - 2024-06-12 16:10:41 --> Utf8 Class Initialized
INFO - 2024-06-12 16:10:41 --> URI Class Initialized
INFO - 2024-06-12 16:10:41 --> Router Class Initialized
INFO - 2024-06-12 16:10:41 --> Output Class Initialized
INFO - 2024-06-12 16:10:41 --> Security Class Initialized
DEBUG - 2024-06-12 16:10:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-12 16:10:41 --> Input Class Initialized
INFO - 2024-06-12 16:10:41 --> Language Class Initialized
INFO - 2024-06-12 16:10:41 --> Language Class Initialized
INFO - 2024-06-12 16:10:41 --> Config Class Initialized
INFO - 2024-06-12 16:10:41 --> Loader Class Initialized
INFO - 2024-06-12 16:10:41 --> Helper loaded: url_helper
INFO - 2024-06-12 16:10:41 --> Helper loaded: file_helper
INFO - 2024-06-12 16:10:41 --> Helper loaded: form_helper
INFO - 2024-06-12 16:10:41 --> Helper loaded: my_helper
INFO - 2024-06-12 16:10:41 --> Database Driver Class Initialized
INFO - 2024-06-12 16:10:41 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-12 16:10:41 --> Controller Class Initialized
INFO - 2024-06-12 16:10:45 --> Config Class Initialized
INFO - 2024-06-12 16:10:45 --> Hooks Class Initialized
DEBUG - 2024-06-12 16:10:45 --> UTF-8 Support Enabled
INFO - 2024-06-12 16:10:45 --> Utf8 Class Initialized
INFO - 2024-06-12 16:10:45 --> URI Class Initialized
INFO - 2024-06-12 16:10:45 --> Router Class Initialized
INFO - 2024-06-12 16:10:45 --> Output Class Initialized
INFO - 2024-06-12 16:10:45 --> Security Class Initialized
DEBUG - 2024-06-12 16:10:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-12 16:10:45 --> Input Class Initialized
INFO - 2024-06-12 16:10:45 --> Language Class Initialized
INFO - 2024-06-12 16:10:45 --> Language Class Initialized
INFO - 2024-06-12 16:10:45 --> Config Class Initialized
INFO - 2024-06-12 16:10:45 --> Loader Class Initialized
INFO - 2024-06-12 16:10:45 --> Helper loaded: url_helper
INFO - 2024-06-12 16:10:45 --> Helper loaded: file_helper
INFO - 2024-06-12 16:10:45 --> Helper loaded: form_helper
INFO - 2024-06-12 16:10:45 --> Helper loaded: my_helper
INFO - 2024-06-12 16:10:45 --> Database Driver Class Initialized
INFO - 2024-06-12 16:10:45 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-12 16:10:45 --> Controller Class Initialized
INFO - 2024-06-12 16:10:45 --> Final output sent to browser
DEBUG - 2024-06-12 16:10:45 --> Total execution time: 0.0659
INFO - 2024-06-12 16:11:11 --> Config Class Initialized
INFO - 2024-06-12 16:11:11 --> Hooks Class Initialized
DEBUG - 2024-06-12 16:11:11 --> UTF-8 Support Enabled
INFO - 2024-06-12 16:11:11 --> Utf8 Class Initialized
INFO - 2024-06-12 16:11:11 --> URI Class Initialized
INFO - 2024-06-12 16:11:11 --> Router Class Initialized
INFO - 2024-06-12 16:11:11 --> Output Class Initialized
INFO - 2024-06-12 16:11:11 --> Security Class Initialized
DEBUG - 2024-06-12 16:11:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-12 16:11:11 --> Input Class Initialized
INFO - 2024-06-12 16:11:11 --> Language Class Initialized
INFO - 2024-06-12 16:11:11 --> Language Class Initialized
INFO - 2024-06-12 16:11:11 --> Config Class Initialized
INFO - 2024-06-12 16:11:11 --> Loader Class Initialized
INFO - 2024-06-12 16:11:11 --> Helper loaded: url_helper
INFO - 2024-06-12 16:11:11 --> Helper loaded: file_helper
INFO - 2024-06-12 16:11:11 --> Helper loaded: form_helper
INFO - 2024-06-12 16:11:11 --> Helper loaded: my_helper
INFO - 2024-06-12 16:11:11 --> Database Driver Class Initialized
INFO - 2024-06-12 16:11:11 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-12 16:11:11 --> Controller Class Initialized
INFO - 2024-06-12 16:11:11 --> Final output sent to browser
DEBUG - 2024-06-12 16:11:11 --> Total execution time: 0.0363
INFO - 2024-06-12 16:11:11 --> Config Class Initialized
INFO - 2024-06-12 16:11:11 --> Hooks Class Initialized
DEBUG - 2024-06-12 16:11:11 --> UTF-8 Support Enabled
INFO - 2024-06-12 16:11:11 --> Utf8 Class Initialized
INFO - 2024-06-12 16:11:11 --> URI Class Initialized
INFO - 2024-06-12 16:11:11 --> Router Class Initialized
INFO - 2024-06-12 16:11:11 --> Output Class Initialized
INFO - 2024-06-12 16:11:11 --> Security Class Initialized
DEBUG - 2024-06-12 16:11:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-12 16:11:11 --> Input Class Initialized
INFO - 2024-06-12 16:11:11 --> Language Class Initialized
ERROR - 2024-06-12 16:11:11 --> 404 Page Not Found: /index
INFO - 2024-06-12 16:11:11 --> Config Class Initialized
INFO - 2024-06-12 16:11:11 --> Hooks Class Initialized
DEBUG - 2024-06-12 16:11:11 --> UTF-8 Support Enabled
INFO - 2024-06-12 16:11:11 --> Utf8 Class Initialized
INFO - 2024-06-12 16:11:11 --> URI Class Initialized
INFO - 2024-06-12 16:11:11 --> Router Class Initialized
INFO - 2024-06-12 16:11:11 --> Output Class Initialized
INFO - 2024-06-12 16:11:11 --> Security Class Initialized
DEBUG - 2024-06-12 16:11:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-12 16:11:11 --> Input Class Initialized
INFO - 2024-06-12 16:11:11 --> Language Class Initialized
INFO - 2024-06-12 16:11:11 --> Language Class Initialized
INFO - 2024-06-12 16:11:11 --> Config Class Initialized
INFO - 2024-06-12 16:11:11 --> Loader Class Initialized
INFO - 2024-06-12 16:11:11 --> Helper loaded: url_helper
INFO - 2024-06-12 16:11:11 --> Helper loaded: file_helper
INFO - 2024-06-12 16:11:11 --> Helper loaded: form_helper
INFO - 2024-06-12 16:11:11 --> Helper loaded: my_helper
INFO - 2024-06-12 16:11:11 --> Database Driver Class Initialized
INFO - 2024-06-12 16:11:11 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-12 16:11:11 --> Controller Class Initialized
INFO - 2024-06-12 16:12:24 --> Config Class Initialized
INFO - 2024-06-12 16:12:24 --> Hooks Class Initialized
DEBUG - 2024-06-12 16:12:24 --> UTF-8 Support Enabled
INFO - 2024-06-12 16:12:24 --> Utf8 Class Initialized
INFO - 2024-06-12 16:12:24 --> URI Class Initialized
INFO - 2024-06-12 16:12:24 --> Router Class Initialized
INFO - 2024-06-12 16:12:24 --> Output Class Initialized
INFO - 2024-06-12 16:12:24 --> Security Class Initialized
DEBUG - 2024-06-12 16:12:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-12 16:12:24 --> Input Class Initialized
INFO - 2024-06-12 16:12:24 --> Language Class Initialized
INFO - 2024-06-12 16:12:24 --> Language Class Initialized
INFO - 2024-06-12 16:12:24 --> Config Class Initialized
INFO - 2024-06-12 16:12:24 --> Loader Class Initialized
INFO - 2024-06-12 16:12:24 --> Helper loaded: url_helper
INFO - 2024-06-12 16:12:24 --> Helper loaded: file_helper
INFO - 2024-06-12 16:12:24 --> Helper loaded: form_helper
INFO - 2024-06-12 16:12:24 --> Helper loaded: my_helper
INFO - 2024-06-12 16:12:24 --> Database Driver Class Initialized
INFO - 2024-06-12 16:12:24 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-12 16:12:24 --> Controller Class Initialized
DEBUG - 2024-06-12 16:12:24 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/data_kelas/views/list.php
DEBUG - 2024-06-12 16:12:24 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-06-12 16:12:24 --> Final output sent to browser
DEBUG - 2024-06-12 16:12:24 --> Total execution time: 0.0296
INFO - 2024-06-12 16:12:24 --> Config Class Initialized
INFO - 2024-06-12 16:12:24 --> Hooks Class Initialized
DEBUG - 2024-06-12 16:12:24 --> UTF-8 Support Enabled
INFO - 2024-06-12 16:12:24 --> Utf8 Class Initialized
INFO - 2024-06-12 16:12:24 --> URI Class Initialized
INFO - 2024-06-12 16:12:24 --> Router Class Initialized
INFO - 2024-06-12 16:12:24 --> Output Class Initialized
INFO - 2024-06-12 16:12:24 --> Security Class Initialized
DEBUG - 2024-06-12 16:12:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-12 16:12:24 --> Input Class Initialized
INFO - 2024-06-12 16:12:24 --> Language Class Initialized
ERROR - 2024-06-12 16:12:24 --> 404 Page Not Found: /index
INFO - 2024-06-12 16:12:24 --> Config Class Initialized
INFO - 2024-06-12 16:12:24 --> Hooks Class Initialized
DEBUG - 2024-06-12 16:12:24 --> UTF-8 Support Enabled
INFO - 2024-06-12 16:12:24 --> Utf8 Class Initialized
INFO - 2024-06-12 16:12:24 --> URI Class Initialized
INFO - 2024-06-12 16:12:24 --> Router Class Initialized
INFO - 2024-06-12 16:12:24 --> Output Class Initialized
INFO - 2024-06-12 16:12:24 --> Security Class Initialized
DEBUG - 2024-06-12 16:12:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-12 16:12:24 --> Input Class Initialized
INFO - 2024-06-12 16:12:24 --> Language Class Initialized
INFO - 2024-06-12 16:12:24 --> Language Class Initialized
INFO - 2024-06-12 16:12:24 --> Config Class Initialized
INFO - 2024-06-12 16:12:24 --> Loader Class Initialized
INFO - 2024-06-12 16:12:24 --> Helper loaded: url_helper
INFO - 2024-06-12 16:12:24 --> Helper loaded: file_helper
INFO - 2024-06-12 16:12:24 --> Helper loaded: form_helper
INFO - 2024-06-12 16:12:24 --> Helper loaded: my_helper
INFO - 2024-06-12 16:12:24 --> Database Driver Class Initialized
INFO - 2024-06-12 16:12:24 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-12 16:12:24 --> Controller Class Initialized
INFO - 2024-06-12 16:12:28 --> Config Class Initialized
INFO - 2024-06-12 16:12:28 --> Hooks Class Initialized
DEBUG - 2024-06-12 16:12:28 --> UTF-8 Support Enabled
INFO - 2024-06-12 16:12:28 --> Utf8 Class Initialized
INFO - 2024-06-12 16:12:28 --> URI Class Initialized
INFO - 2024-06-12 16:12:28 --> Router Class Initialized
INFO - 2024-06-12 16:12:28 --> Output Class Initialized
INFO - 2024-06-12 16:12:28 --> Security Class Initialized
DEBUG - 2024-06-12 16:12:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-12 16:12:28 --> Input Class Initialized
INFO - 2024-06-12 16:12:28 --> Language Class Initialized
INFO - 2024-06-12 16:12:28 --> Language Class Initialized
INFO - 2024-06-12 16:12:28 --> Config Class Initialized
INFO - 2024-06-12 16:12:28 --> Loader Class Initialized
INFO - 2024-06-12 16:12:28 --> Helper loaded: url_helper
INFO - 2024-06-12 16:12:28 --> Helper loaded: file_helper
INFO - 2024-06-12 16:12:28 --> Helper loaded: form_helper
INFO - 2024-06-12 16:12:28 --> Helper loaded: my_helper
INFO - 2024-06-12 16:12:28 --> Database Driver Class Initialized
INFO - 2024-06-12 16:12:28 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-12 16:12:28 --> Controller Class Initialized
DEBUG - 2024-06-12 16:12:28 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/data_siswa/views/list.php
DEBUG - 2024-06-12 16:12:28 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-06-12 16:12:28 --> Final output sent to browser
DEBUG - 2024-06-12 16:12:28 --> Total execution time: 0.0367
INFO - 2024-06-12 16:12:28 --> Config Class Initialized
INFO - 2024-06-12 16:12:28 --> Hooks Class Initialized
DEBUG - 2024-06-12 16:12:28 --> UTF-8 Support Enabled
INFO - 2024-06-12 16:12:28 --> Utf8 Class Initialized
INFO - 2024-06-12 16:12:28 --> URI Class Initialized
INFO - 2024-06-12 16:12:28 --> Router Class Initialized
INFO - 2024-06-12 16:12:28 --> Output Class Initialized
INFO - 2024-06-12 16:12:28 --> Security Class Initialized
DEBUG - 2024-06-12 16:12:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-12 16:12:28 --> Input Class Initialized
INFO - 2024-06-12 16:12:28 --> Language Class Initialized
ERROR - 2024-06-12 16:12:28 --> 404 Page Not Found: /index
INFO - 2024-06-12 16:12:28 --> Config Class Initialized
INFO - 2024-06-12 16:12:28 --> Hooks Class Initialized
DEBUG - 2024-06-12 16:12:28 --> UTF-8 Support Enabled
INFO - 2024-06-12 16:12:28 --> Utf8 Class Initialized
INFO - 2024-06-12 16:12:28 --> URI Class Initialized
INFO - 2024-06-12 16:12:28 --> Router Class Initialized
INFO - 2024-06-12 16:12:28 --> Output Class Initialized
INFO - 2024-06-12 16:12:28 --> Security Class Initialized
DEBUG - 2024-06-12 16:12:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-12 16:12:28 --> Input Class Initialized
INFO - 2024-06-12 16:12:28 --> Language Class Initialized
INFO - 2024-06-12 16:12:28 --> Language Class Initialized
INFO - 2024-06-12 16:12:28 --> Config Class Initialized
INFO - 2024-06-12 16:12:28 --> Loader Class Initialized
INFO - 2024-06-12 16:12:28 --> Helper loaded: url_helper
INFO - 2024-06-12 16:12:28 --> Helper loaded: file_helper
INFO - 2024-06-12 16:12:28 --> Helper loaded: form_helper
INFO - 2024-06-12 16:12:28 --> Helper loaded: my_helper
INFO - 2024-06-12 16:12:28 --> Database Driver Class Initialized
INFO - 2024-06-12 16:12:28 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-12 16:12:28 --> Controller Class Initialized
INFO - 2024-06-12 21:20:38 --> Config Class Initialized
INFO - 2024-06-12 21:20:38 --> Hooks Class Initialized
DEBUG - 2024-06-12 21:20:38 --> UTF-8 Support Enabled
INFO - 2024-06-12 21:20:38 --> Utf8 Class Initialized
INFO - 2024-06-12 21:20:38 --> URI Class Initialized
INFO - 2024-06-12 21:20:38 --> Router Class Initialized
INFO - 2024-06-12 21:20:38 --> Output Class Initialized
INFO - 2024-06-12 21:20:38 --> Security Class Initialized
DEBUG - 2024-06-12 21:20:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-12 21:20:38 --> Input Class Initialized
INFO - 2024-06-12 21:20:38 --> Language Class Initialized
INFO - 2024-06-12 21:20:38 --> Language Class Initialized
INFO - 2024-06-12 21:20:38 --> Config Class Initialized
INFO - 2024-06-12 21:20:38 --> Loader Class Initialized
INFO - 2024-06-12 21:20:38 --> Helper loaded: url_helper
INFO - 2024-06-12 21:20:38 --> Helper loaded: file_helper
INFO - 2024-06-12 21:20:38 --> Helper loaded: form_helper
INFO - 2024-06-12 21:20:38 --> Helper loaded: my_helper
INFO - 2024-06-12 21:20:38 --> Database Driver Class Initialized
INFO - 2024-06-12 21:20:38 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-12 21:20:38 --> Controller Class Initialized
DEBUG - 2024-06-12 21:20:38 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/login/views/login.php
DEBUG - 2024-06-12 21:20:38 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-06-12 21:20:38 --> Final output sent to browser
DEBUG - 2024-06-12 21:20:38 --> Total execution time: 0.0493
INFO - 2024-06-12 23:11:40 --> Config Class Initialized
INFO - 2024-06-12 23:11:40 --> Hooks Class Initialized
DEBUG - 2024-06-12 23:11:40 --> UTF-8 Support Enabled
INFO - 2024-06-12 23:11:40 --> Utf8 Class Initialized
INFO - 2024-06-12 23:11:40 --> URI Class Initialized
INFO - 2024-06-12 23:11:41 --> Router Class Initialized
INFO - 2024-06-12 23:11:41 --> Output Class Initialized
INFO - 2024-06-12 23:11:41 --> Security Class Initialized
DEBUG - 2024-06-12 23:11:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-12 23:11:41 --> Input Class Initialized
INFO - 2024-06-12 23:11:41 --> Language Class Initialized
INFO - 2024-06-12 23:11:41 --> Language Class Initialized
INFO - 2024-06-12 23:11:41 --> Config Class Initialized
INFO - 2024-06-12 23:11:41 --> Loader Class Initialized
INFO - 2024-06-12 23:11:41 --> Helper loaded: url_helper
INFO - 2024-06-12 23:11:41 --> Helper loaded: file_helper
INFO - 2024-06-12 23:11:41 --> Helper loaded: form_helper
INFO - 2024-06-12 23:11:41 --> Helper loaded: my_helper
INFO - 2024-06-12 23:11:41 --> Database Driver Class Initialized
INFO - 2024-06-12 23:11:41 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-12 23:11:41 --> Controller Class Initialized
INFO - 2024-06-12 23:11:41 --> Helper loaded: cookie_helper
INFO - 2024-06-12 23:11:41 --> Final output sent to browser
DEBUG - 2024-06-12 23:11:41 --> Total execution time: 0.3927
INFO - 2024-06-12 23:11:41 --> Config Class Initialized
INFO - 2024-06-12 23:11:41 --> Hooks Class Initialized
DEBUG - 2024-06-12 23:11:41 --> UTF-8 Support Enabled
INFO - 2024-06-12 23:11:41 --> Utf8 Class Initialized
INFO - 2024-06-12 23:11:41 --> URI Class Initialized
INFO - 2024-06-12 23:11:41 --> Router Class Initialized
INFO - 2024-06-12 23:11:41 --> Output Class Initialized
INFO - 2024-06-12 23:11:41 --> Security Class Initialized
DEBUG - 2024-06-12 23:11:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-12 23:11:41 --> Input Class Initialized
INFO - 2024-06-12 23:11:41 --> Language Class Initialized
INFO - 2024-06-12 23:11:41 --> Language Class Initialized
INFO - 2024-06-12 23:11:41 --> Config Class Initialized
INFO - 2024-06-12 23:11:41 --> Loader Class Initialized
INFO - 2024-06-12 23:11:41 --> Helper loaded: url_helper
INFO - 2024-06-12 23:11:41 --> Helper loaded: file_helper
INFO - 2024-06-12 23:11:41 --> Helper loaded: form_helper
INFO - 2024-06-12 23:11:41 --> Helper loaded: my_helper
INFO - 2024-06-12 23:11:41 --> Database Driver Class Initialized
INFO - 2024-06-12 23:11:41 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-12 23:11:41 --> Controller Class Initialized
INFO - 2024-06-12 23:11:41 --> Helper loaded: cookie_helper
INFO - 2024-06-12 23:11:41 --> Config Class Initialized
INFO - 2024-06-12 23:11:41 --> Hooks Class Initialized
DEBUG - 2024-06-12 23:11:41 --> UTF-8 Support Enabled
INFO - 2024-06-12 23:11:41 --> Utf8 Class Initialized
INFO - 2024-06-12 23:11:41 --> URI Class Initialized
INFO - 2024-06-12 23:11:41 --> Router Class Initialized
INFO - 2024-06-12 23:11:41 --> Output Class Initialized
INFO - 2024-06-12 23:11:41 --> Security Class Initialized
DEBUG - 2024-06-12 23:11:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-12 23:11:41 --> Input Class Initialized
INFO - 2024-06-12 23:11:41 --> Language Class Initialized
INFO - 2024-06-12 23:11:41 --> Language Class Initialized
INFO - 2024-06-12 23:11:41 --> Config Class Initialized
INFO - 2024-06-12 23:11:41 --> Loader Class Initialized
INFO - 2024-06-12 23:11:41 --> Helper loaded: url_helper
INFO - 2024-06-12 23:11:41 --> Helper loaded: file_helper
INFO - 2024-06-12 23:11:41 --> Helper loaded: form_helper
INFO - 2024-06-12 23:11:41 --> Helper loaded: my_helper
INFO - 2024-06-12 23:11:41 --> Database Driver Class Initialized
INFO - 2024-06-12 23:11:41 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-12 23:11:41 --> Controller Class Initialized
DEBUG - 2024-06-12 23:11:41 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/lihat_raport/views/list.php
DEBUG - 2024-06-12 23:11:41 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-06-12 23:11:41 --> Final output sent to browser
DEBUG - 2024-06-12 23:11:41 --> Total execution time: 0.0493
INFO - 2024-06-12 23:11:41 --> Config Class Initialized
INFO - 2024-06-12 23:11:41 --> Hooks Class Initialized
DEBUG - 2024-06-12 23:11:41 --> UTF-8 Support Enabled
INFO - 2024-06-12 23:11:41 --> Utf8 Class Initialized
INFO - 2024-06-12 23:11:41 --> URI Class Initialized
INFO - 2024-06-12 23:11:41 --> Router Class Initialized
INFO - 2024-06-12 23:11:41 --> Output Class Initialized
INFO - 2024-06-12 23:11:41 --> Security Class Initialized
DEBUG - 2024-06-12 23:11:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-12 23:11:41 --> Input Class Initialized
INFO - 2024-06-12 23:11:41 --> Language Class Initialized
INFO - 2024-06-12 23:11:41 --> Language Class Initialized
INFO - 2024-06-12 23:11:41 --> Config Class Initialized
INFO - 2024-06-12 23:11:41 --> Loader Class Initialized
INFO - 2024-06-12 23:11:41 --> Helper loaded: url_helper
INFO - 2024-06-12 23:11:41 --> Helper loaded: file_helper
INFO - 2024-06-12 23:11:41 --> Helper loaded: form_helper
INFO - 2024-06-12 23:11:41 --> Helper loaded: my_helper
INFO - 2024-06-12 23:11:42 --> Database Driver Class Initialized
INFO - 2024-06-12 23:11:42 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-12 23:11:42 --> Controller Class Initialized
INFO - 2024-06-12 23:11:42 --> Helper loaded: cookie_helper
INFO - 2024-06-12 23:11:42 --> Final output sent to browser
DEBUG - 2024-06-12 23:11:42 --> Total execution time: 0.0330
INFO - 2024-06-12 23:11:42 --> Config Class Initialized
INFO - 2024-06-12 23:11:42 --> Hooks Class Initialized
DEBUG - 2024-06-12 23:11:42 --> UTF-8 Support Enabled
INFO - 2024-06-12 23:11:42 --> Utf8 Class Initialized
INFO - 2024-06-12 23:11:42 --> URI Class Initialized
INFO - 2024-06-12 23:11:42 --> Router Class Initialized
INFO - 2024-06-12 23:11:42 --> Output Class Initialized
INFO - 2024-06-12 23:11:42 --> Security Class Initialized
DEBUG - 2024-06-12 23:11:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-12 23:11:42 --> Input Class Initialized
INFO - 2024-06-12 23:11:42 --> Language Class Initialized
INFO - 2024-06-12 23:11:42 --> Language Class Initialized
INFO - 2024-06-12 23:11:42 --> Config Class Initialized
INFO - 2024-06-12 23:11:42 --> Loader Class Initialized
INFO - 2024-06-12 23:11:42 --> Config Class Initialized
INFO - 2024-06-12 23:11:42 --> Hooks Class Initialized
DEBUG - 2024-06-12 23:11:42 --> UTF-8 Support Enabled
INFO - 2024-06-12 23:11:42 --> Utf8 Class Initialized
INFO - 2024-06-12 23:11:42 --> URI Class Initialized
INFO - 2024-06-12 23:11:42 --> Router Class Initialized
INFO - 2024-06-12 23:11:42 --> Output Class Initialized
INFO - 2024-06-12 23:11:42 --> Security Class Initialized
DEBUG - 2024-06-12 23:11:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-12 23:11:42 --> Input Class Initialized
INFO - 2024-06-12 23:11:42 --> Language Class Initialized
INFO - 2024-06-12 23:11:42 --> Language Class Initialized
INFO - 2024-06-12 23:11:42 --> Config Class Initialized
INFO - 2024-06-12 23:11:42 --> Loader Class Initialized
INFO - 2024-06-12 23:11:42 --> Helper loaded: url_helper
INFO - 2024-06-12 23:11:42 --> Helper loaded: file_helper
INFO - 2024-06-12 23:11:42 --> Helper loaded: form_helper
INFO - 2024-06-12 23:11:42 --> Helper loaded: my_helper
INFO - 2024-06-12 23:11:42 --> Helper loaded: url_helper
INFO - 2024-06-12 23:11:42 --> Helper loaded: file_helper
INFO - 2024-06-12 23:11:42 --> Helper loaded: form_helper
INFO - 2024-06-12 23:11:42 --> Helper loaded: my_helper
INFO - 2024-06-12 23:11:42 --> Database Driver Class Initialized
INFO - 2024-06-12 23:11:42 --> Database Driver Class Initialized
INFO - 2024-06-12 23:11:42 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-12 23:11:42 --> Controller Class Initialized
INFO - 2024-06-12 23:11:42 --> Helper loaded: cookie_helper
INFO - 2024-06-12 23:11:42 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-12 23:11:42 --> Controller Class Initialized
INFO - 2024-06-12 23:11:42 --> Helper loaded: cookie_helper
INFO - 2024-06-12 23:11:42 --> Config Class Initialized
INFO - 2024-06-12 23:11:42 --> Hooks Class Initialized
DEBUG - 2024-06-12 23:11:42 --> UTF-8 Support Enabled
INFO - 2024-06-12 23:11:42 --> Utf8 Class Initialized
INFO - 2024-06-12 23:11:42 --> URI Class Initialized
INFO - 2024-06-12 23:11:42 --> Router Class Initialized
INFO - 2024-06-12 23:11:42 --> Output Class Initialized
INFO - 2024-06-12 23:11:42 --> Security Class Initialized
DEBUG - 2024-06-12 23:11:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-12 23:11:42 --> Input Class Initialized
INFO - 2024-06-12 23:11:42 --> Language Class Initialized
INFO - 2024-06-12 23:11:42 --> Language Class Initialized
INFO - 2024-06-12 23:11:42 --> Config Class Initialized
INFO - 2024-06-12 23:11:42 --> Loader Class Initialized
INFO - 2024-06-12 23:11:42 --> Helper loaded: url_helper
INFO - 2024-06-12 23:11:42 --> Helper loaded: file_helper
INFO - 2024-06-12 23:11:42 --> Helper loaded: form_helper
INFO - 2024-06-12 23:11:42 --> Helper loaded: my_helper
INFO - 2024-06-12 23:11:42 --> Database Driver Class Initialized
INFO - 2024-06-12 23:11:42 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-12 23:11:42 --> Controller Class Initialized
DEBUG - 2024-06-12 23:11:42 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/lihat_raport/views/list.php
DEBUG - 2024-06-12 23:11:42 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-06-12 23:11:42 --> Final output sent to browser
DEBUG - 2024-06-12 23:11:42 --> Total execution time: 0.0286
INFO - 2024-06-12 23:11:42 --> Config Class Initialized
INFO - 2024-06-12 23:11:42 --> Hooks Class Initialized
DEBUG - 2024-06-12 23:11:42 --> UTF-8 Support Enabled
INFO - 2024-06-12 23:11:42 --> Utf8 Class Initialized
INFO - 2024-06-12 23:11:42 --> URI Class Initialized
INFO - 2024-06-12 23:11:42 --> Router Class Initialized
INFO - 2024-06-12 23:11:42 --> Output Class Initialized
INFO - 2024-06-12 23:11:42 --> Security Class Initialized
DEBUG - 2024-06-12 23:11:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-12 23:11:42 --> Input Class Initialized
INFO - 2024-06-12 23:11:42 --> Language Class Initialized
INFO - 2024-06-12 23:11:42 --> Language Class Initialized
INFO - 2024-06-12 23:11:42 --> Config Class Initialized
INFO - 2024-06-12 23:11:42 --> Loader Class Initialized
INFO - 2024-06-12 23:11:42 --> Helper loaded: url_helper
INFO - 2024-06-12 23:11:42 --> Helper loaded: file_helper
INFO - 2024-06-12 23:11:42 --> Helper loaded: form_helper
INFO - 2024-06-12 23:11:42 --> Helper loaded: my_helper
INFO - 2024-06-12 23:11:42 --> Database Driver Class Initialized
INFO - 2024-06-12 23:11:42 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-12 23:11:42 --> Controller Class Initialized
INFO - 2024-06-12 23:11:42 --> Helper loaded: cookie_helper
INFO - 2024-06-12 23:11:42 --> Final output sent to browser
DEBUG - 2024-06-12 23:11:42 --> Total execution time: 0.0398
INFO - 2024-06-12 23:11:42 --> Config Class Initialized
INFO - 2024-06-12 23:11:42 --> Hooks Class Initialized
DEBUG - 2024-06-12 23:11:42 --> UTF-8 Support Enabled
INFO - 2024-06-12 23:11:42 --> Utf8 Class Initialized
INFO - 2024-06-12 23:11:42 --> URI Class Initialized
INFO - 2024-06-12 23:11:42 --> Router Class Initialized
INFO - 2024-06-12 23:11:42 --> Output Class Initialized
INFO - 2024-06-12 23:11:42 --> Security Class Initialized
DEBUG - 2024-06-12 23:11:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-12 23:11:42 --> Input Class Initialized
INFO - 2024-06-12 23:11:42 --> Language Class Initialized
INFO - 2024-06-12 23:11:42 --> Language Class Initialized
INFO - 2024-06-12 23:11:42 --> Config Class Initialized
INFO - 2024-06-12 23:11:42 --> Loader Class Initialized
INFO - 2024-06-12 23:11:42 --> Helper loaded: url_helper
INFO - 2024-06-12 23:11:42 --> Helper loaded: file_helper
INFO - 2024-06-12 23:11:42 --> Helper loaded: form_helper
INFO - 2024-06-12 23:11:42 --> Helper loaded: my_helper
INFO - 2024-06-12 23:11:42 --> Config Class Initialized
INFO - 2024-06-12 23:11:42 --> Hooks Class Initialized
INFO - 2024-06-12 23:11:42 --> Database Driver Class Initialized
DEBUG - 2024-06-12 23:11:42 --> UTF-8 Support Enabled
INFO - 2024-06-12 23:11:42 --> Utf8 Class Initialized
INFO - 2024-06-12 23:11:42 --> URI Class Initialized
INFO - 2024-06-12 23:11:42 --> Router Class Initialized
INFO - 2024-06-12 23:11:42 --> Output Class Initialized
INFO - 2024-06-12 23:11:42 --> Security Class Initialized
DEBUG - 2024-06-12 23:11:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-12 23:11:42 --> Input Class Initialized
INFO - 2024-06-12 23:11:42 --> Language Class Initialized
INFO - 2024-06-12 23:11:42 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-12 23:11:42 --> Controller Class Initialized
INFO - 2024-06-12 23:11:42 --> Language Class Initialized
INFO - 2024-06-12 23:11:42 --> Config Class Initialized
INFO - 2024-06-12 23:11:42 --> Loader Class Initialized
INFO - 2024-06-12 23:11:42 --> Helper loaded: url_helper
INFO - 2024-06-12 23:11:42 --> Helper loaded: file_helper
INFO - 2024-06-12 23:11:42 --> Helper loaded: form_helper
INFO - 2024-06-12 23:11:42 --> Helper loaded: my_helper
INFO - 2024-06-12 23:11:42 --> Database Driver Class Initialized
INFO - 2024-06-12 23:11:43 --> Helper loaded: cookie_helper
INFO - 2024-06-12 23:11:43 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-12 23:11:43 --> Controller Class Initialized
INFO - 2024-06-12 23:11:43 --> Helper loaded: cookie_helper
INFO - 2024-06-12 23:11:43 --> Config Class Initialized
INFO - 2024-06-12 23:11:43 --> Hooks Class Initialized
DEBUG - 2024-06-12 23:11:43 --> UTF-8 Support Enabled
INFO - 2024-06-12 23:11:43 --> Utf8 Class Initialized
INFO - 2024-06-12 23:11:43 --> URI Class Initialized
INFO - 2024-06-12 23:11:43 --> Router Class Initialized
INFO - 2024-06-12 23:11:43 --> Output Class Initialized
INFO - 2024-06-12 23:11:43 --> Security Class Initialized
DEBUG - 2024-06-12 23:11:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-12 23:11:43 --> Input Class Initialized
INFO - 2024-06-12 23:11:43 --> Language Class Initialized
INFO - 2024-06-12 23:11:43 --> Language Class Initialized
INFO - 2024-06-12 23:11:43 --> Config Class Initialized
INFO - 2024-06-12 23:11:43 --> Loader Class Initialized
INFO - 2024-06-12 23:11:43 --> Helper loaded: url_helper
INFO - 2024-06-12 23:11:43 --> Helper loaded: file_helper
INFO - 2024-06-12 23:11:43 --> Helper loaded: form_helper
INFO - 2024-06-12 23:11:43 --> Helper loaded: my_helper
INFO - 2024-06-12 23:11:43 --> Database Driver Class Initialized
INFO - 2024-06-12 23:11:43 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-12 23:11:43 --> Controller Class Initialized
DEBUG - 2024-06-12 23:11:43 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/lihat_raport/views/list.php
DEBUG - 2024-06-12 23:11:43 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-06-12 23:11:43 --> Final output sent to browser
DEBUG - 2024-06-12 23:11:43 --> Total execution time: 0.0388
