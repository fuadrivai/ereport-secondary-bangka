<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2024-10-02 10:09:00 --> Config Class Initialized
INFO - 2024-10-02 10:09:00 --> Hooks Class Initialized
DEBUG - 2024-10-02 10:09:00 --> UTF-8 Support Enabled
INFO - 2024-10-02 10:09:00 --> Utf8 Class Initialized
INFO - 2024-10-02 10:09:00 --> URI Class Initialized
INFO - 2024-10-02 10:09:00 --> Router Class Initialized
INFO - 2024-10-02 10:09:00 --> Output Class Initialized
INFO - 2024-10-02 10:09:00 --> Security Class Initialized
DEBUG - 2024-10-02 10:09:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-02 10:09:00 --> Input Class Initialized
INFO - 2024-10-02 10:09:00 --> Language Class Initialized
INFO - 2024-10-02 10:09:00 --> Language Class Initialized
INFO - 2024-10-02 10:09:00 --> Config Class Initialized
INFO - 2024-10-02 10:09:00 --> Loader Class Initialized
INFO - 2024-10-02 10:09:00 --> Helper loaded: url_helper
INFO - 2024-10-02 10:09:00 --> Helper loaded: file_helper
INFO - 2024-10-02 10:09:00 --> Helper loaded: form_helper
INFO - 2024-10-02 10:09:00 --> Helper loaded: my_helper
INFO - 2024-10-02 10:09:00 --> Database Driver Class Initialized
INFO - 2024-10-02 10:09:00 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-02 10:09:00 --> Controller Class Initialized
INFO - 2024-10-02 10:09:00 --> Config Class Initialized
INFO - 2024-10-02 10:09:00 --> Hooks Class Initialized
DEBUG - 2024-10-02 10:09:00 --> UTF-8 Support Enabled
INFO - 2024-10-02 10:09:00 --> Utf8 Class Initialized
INFO - 2024-10-02 10:09:00 --> URI Class Initialized
INFO - 2024-10-02 10:09:00 --> Router Class Initialized
INFO - 2024-10-02 10:09:00 --> Output Class Initialized
INFO - 2024-10-02 10:09:00 --> Security Class Initialized
DEBUG - 2024-10-02 10:09:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-02 10:09:00 --> Input Class Initialized
INFO - 2024-10-02 10:09:00 --> Language Class Initialized
INFO - 2024-10-02 10:09:00 --> Language Class Initialized
INFO - 2024-10-02 10:09:00 --> Config Class Initialized
INFO - 2024-10-02 10:09:00 --> Loader Class Initialized
INFO - 2024-10-02 10:09:00 --> Helper loaded: url_helper
INFO - 2024-10-02 10:09:00 --> Helper loaded: file_helper
INFO - 2024-10-02 10:09:00 --> Helper loaded: form_helper
INFO - 2024-10-02 10:09:00 --> Helper loaded: my_helper
INFO - 2024-10-02 10:09:00 --> Database Driver Class Initialized
INFO - 2024-10-02 10:09:00 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-02 10:09:00 --> Controller Class Initialized
DEBUG - 2024-10-02 10:09:00 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/login/views/login.php
DEBUG - 2024-10-02 10:09:00 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-10-02 10:09:00 --> Final output sent to browser
DEBUG - 2024-10-02 10:09:00 --> Total execution time: 0.0327
INFO - 2024-10-02 10:09:04 --> Config Class Initialized
INFO - 2024-10-02 10:09:04 --> Hooks Class Initialized
DEBUG - 2024-10-02 10:09:04 --> UTF-8 Support Enabled
INFO - 2024-10-02 10:09:04 --> Utf8 Class Initialized
INFO - 2024-10-02 10:09:04 --> URI Class Initialized
INFO - 2024-10-02 10:09:04 --> Router Class Initialized
INFO - 2024-10-02 10:09:04 --> Output Class Initialized
INFO - 2024-10-02 10:09:04 --> Security Class Initialized
DEBUG - 2024-10-02 10:09:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-02 10:09:04 --> Input Class Initialized
INFO - 2024-10-02 10:09:04 --> Language Class Initialized
INFO - 2024-10-02 10:09:04 --> Language Class Initialized
INFO - 2024-10-02 10:09:04 --> Config Class Initialized
INFO - 2024-10-02 10:09:04 --> Loader Class Initialized
INFO - 2024-10-02 10:09:04 --> Helper loaded: url_helper
INFO - 2024-10-02 10:09:04 --> Helper loaded: file_helper
INFO - 2024-10-02 10:09:04 --> Helper loaded: form_helper
INFO - 2024-10-02 10:09:04 --> Helper loaded: my_helper
INFO - 2024-10-02 10:09:04 --> Database Driver Class Initialized
INFO - 2024-10-02 10:09:04 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-02 10:09:04 --> Controller Class Initialized
INFO - 2024-10-02 10:09:04 --> Helper loaded: cookie_helper
INFO - 2024-10-02 10:09:04 --> Final output sent to browser
DEBUG - 2024-10-02 10:09:04 --> Total execution time: 0.2178
INFO - 2024-10-02 10:09:04 --> Config Class Initialized
INFO - 2024-10-02 10:09:04 --> Hooks Class Initialized
DEBUG - 2024-10-02 10:09:04 --> UTF-8 Support Enabled
INFO - 2024-10-02 10:09:04 --> Utf8 Class Initialized
INFO - 2024-10-02 10:09:04 --> URI Class Initialized
INFO - 2024-10-02 10:09:04 --> Router Class Initialized
INFO - 2024-10-02 10:09:04 --> Output Class Initialized
INFO - 2024-10-02 10:09:04 --> Security Class Initialized
DEBUG - 2024-10-02 10:09:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-02 10:09:04 --> Input Class Initialized
INFO - 2024-10-02 10:09:04 --> Language Class Initialized
INFO - 2024-10-02 10:09:04 --> Language Class Initialized
INFO - 2024-10-02 10:09:04 --> Config Class Initialized
INFO - 2024-10-02 10:09:04 --> Loader Class Initialized
INFO - 2024-10-02 10:09:04 --> Helper loaded: url_helper
INFO - 2024-10-02 10:09:04 --> Helper loaded: file_helper
INFO - 2024-10-02 10:09:04 --> Helper loaded: form_helper
INFO - 2024-10-02 10:09:04 --> Helper loaded: my_helper
INFO - 2024-10-02 10:09:04 --> Database Driver Class Initialized
INFO - 2024-10-02 10:09:04 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-02 10:09:04 --> Controller Class Initialized
DEBUG - 2024-10-02 10:09:04 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/home/views/v_home_guru.php
DEBUG - 2024-10-02 10:09:04 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-10-02 10:09:04 --> Final output sent to browser
DEBUG - 2024-10-02 10:09:04 --> Total execution time: 0.0491
INFO - 2024-10-02 10:09:17 --> Config Class Initialized
INFO - 2024-10-02 10:09:17 --> Hooks Class Initialized
DEBUG - 2024-10-02 10:09:17 --> UTF-8 Support Enabled
INFO - 2024-10-02 10:09:17 --> Utf8 Class Initialized
INFO - 2024-10-02 10:09:17 --> URI Class Initialized
INFO - 2024-10-02 10:09:17 --> Router Class Initialized
INFO - 2024-10-02 10:09:17 --> Output Class Initialized
INFO - 2024-10-02 10:09:17 --> Security Class Initialized
DEBUG - 2024-10-02 10:09:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-02 10:09:17 --> Input Class Initialized
INFO - 2024-10-02 10:09:17 --> Language Class Initialized
INFO - 2024-10-02 10:09:17 --> Language Class Initialized
INFO - 2024-10-02 10:09:17 --> Config Class Initialized
INFO - 2024-10-02 10:09:17 --> Loader Class Initialized
INFO - 2024-10-02 10:09:17 --> Helper loaded: url_helper
INFO - 2024-10-02 10:09:17 --> Helper loaded: file_helper
INFO - 2024-10-02 10:09:17 --> Helper loaded: form_helper
INFO - 2024-10-02 10:09:17 --> Helper loaded: my_helper
INFO - 2024-10-02 10:09:17 --> Database Driver Class Initialized
INFO - 2024-10-02 10:09:17 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-02 10:09:17 --> Controller Class Initialized
DEBUG - 2024-10-02 10:09:17 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_absensi/views/list.php
DEBUG - 2024-10-02 10:09:17 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-10-02 10:09:17 --> Final output sent to browser
DEBUG - 2024-10-02 10:09:17 --> Total execution time: 0.0374
INFO - 2024-10-02 10:11:07 --> Config Class Initialized
INFO - 2024-10-02 10:11:07 --> Hooks Class Initialized
DEBUG - 2024-10-02 10:11:07 --> UTF-8 Support Enabled
INFO - 2024-10-02 10:11:07 --> Utf8 Class Initialized
INFO - 2024-10-02 10:11:07 --> URI Class Initialized
INFO - 2024-10-02 10:11:07 --> Router Class Initialized
INFO - 2024-10-02 10:11:07 --> Output Class Initialized
INFO - 2024-10-02 10:11:07 --> Security Class Initialized
DEBUG - 2024-10-02 10:11:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-02 10:11:07 --> Input Class Initialized
INFO - 2024-10-02 10:11:07 --> Language Class Initialized
INFO - 2024-10-02 10:11:07 --> Language Class Initialized
INFO - 2024-10-02 10:11:07 --> Config Class Initialized
INFO - 2024-10-02 10:11:07 --> Loader Class Initialized
INFO - 2024-10-02 10:11:07 --> Helper loaded: url_helper
INFO - 2024-10-02 10:11:07 --> Helper loaded: file_helper
INFO - 2024-10-02 10:11:07 --> Helper loaded: form_helper
INFO - 2024-10-02 10:11:07 --> Helper loaded: my_helper
INFO - 2024-10-02 10:11:07 --> Database Driver Class Initialized
INFO - 2024-10-02 10:11:07 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-02 10:11:07 --> Controller Class Initialized
DEBUG - 2024-10-02 10:11:07 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/view_mapel/views/v_view_mapel.php
DEBUG - 2024-10-02 10:11:07 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-10-02 10:11:07 --> Final output sent to browser
DEBUG - 2024-10-02 10:11:07 --> Total execution time: 0.0319
INFO - 2024-10-02 10:11:08 --> Config Class Initialized
INFO - 2024-10-02 10:11:08 --> Hooks Class Initialized
DEBUG - 2024-10-02 10:11:08 --> UTF-8 Support Enabled
INFO - 2024-10-02 10:11:08 --> Utf8 Class Initialized
INFO - 2024-10-02 10:11:08 --> URI Class Initialized
INFO - 2024-10-02 10:11:08 --> Router Class Initialized
INFO - 2024-10-02 10:11:08 --> Output Class Initialized
INFO - 2024-10-02 10:11:08 --> Security Class Initialized
DEBUG - 2024-10-02 10:11:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-02 10:11:08 --> Input Class Initialized
INFO - 2024-10-02 10:11:08 --> Language Class Initialized
INFO - 2024-10-02 10:11:08 --> Language Class Initialized
INFO - 2024-10-02 10:11:08 --> Config Class Initialized
INFO - 2024-10-02 10:11:08 --> Loader Class Initialized
INFO - 2024-10-02 10:11:08 --> Helper loaded: url_helper
INFO - 2024-10-02 10:11:08 --> Helper loaded: file_helper
INFO - 2024-10-02 10:11:08 --> Helper loaded: form_helper
INFO - 2024-10-02 10:11:08 --> Helper loaded: my_helper
INFO - 2024-10-02 10:11:08 --> Database Driver Class Initialized
INFO - 2024-10-02 10:11:08 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-02 10:11:08 --> Controller Class Initialized
DEBUG - 2024-10-02 10:11:08 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/views/list.php
DEBUG - 2024-10-02 10:11:08 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-10-02 10:11:08 --> Final output sent to browser
DEBUG - 2024-10-02 10:11:08 --> Total execution time: 0.0381
INFO - 2024-10-02 10:11:08 --> Config Class Initialized
INFO - 2024-10-02 10:11:08 --> Hooks Class Initialized
DEBUG - 2024-10-02 10:11:08 --> UTF-8 Support Enabled
INFO - 2024-10-02 10:11:08 --> Utf8 Class Initialized
INFO - 2024-10-02 10:11:08 --> URI Class Initialized
INFO - 2024-10-02 10:11:08 --> Router Class Initialized
INFO - 2024-10-02 10:11:08 --> Output Class Initialized
INFO - 2024-10-02 10:11:08 --> Security Class Initialized
DEBUG - 2024-10-02 10:11:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-02 10:11:08 --> Input Class Initialized
INFO - 2024-10-02 10:11:08 --> Language Class Initialized
INFO - 2024-10-02 10:11:08 --> Language Class Initialized
INFO - 2024-10-02 10:11:08 --> Config Class Initialized
INFO - 2024-10-02 10:11:08 --> Loader Class Initialized
INFO - 2024-10-02 10:11:08 --> Helper loaded: url_helper
INFO - 2024-10-02 10:11:08 --> Helper loaded: file_helper
INFO - 2024-10-02 10:11:08 --> Helper loaded: form_helper
INFO - 2024-10-02 10:11:08 --> Helper loaded: my_helper
INFO - 2024-10-02 10:11:08 --> Database Driver Class Initialized
INFO - 2024-10-02 10:11:08 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-02 10:11:08 --> Controller Class Initialized
INFO - 2024-10-02 10:11:11 --> Config Class Initialized
INFO - 2024-10-02 10:11:11 --> Hooks Class Initialized
DEBUG - 2024-10-02 10:11:11 --> UTF-8 Support Enabled
INFO - 2024-10-02 10:11:11 --> Utf8 Class Initialized
INFO - 2024-10-02 10:11:11 --> URI Class Initialized
INFO - 2024-10-02 10:11:11 --> Router Class Initialized
INFO - 2024-10-02 10:11:11 --> Output Class Initialized
INFO - 2024-10-02 10:11:11 --> Security Class Initialized
DEBUG - 2024-10-02 10:11:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-02 10:11:11 --> Input Class Initialized
INFO - 2024-10-02 10:11:11 --> Language Class Initialized
INFO - 2024-10-02 10:11:11 --> Language Class Initialized
INFO - 2024-10-02 10:11:11 --> Config Class Initialized
INFO - 2024-10-02 10:11:11 --> Loader Class Initialized
INFO - 2024-10-02 10:11:11 --> Helper loaded: url_helper
INFO - 2024-10-02 10:11:11 --> Helper loaded: file_helper
INFO - 2024-10-02 10:11:11 --> Helper loaded: form_helper
INFO - 2024-10-02 10:11:11 --> Helper loaded: my_helper
INFO - 2024-10-02 10:11:11 --> Database Driver Class Initialized
INFO - 2024-10-02 10:11:11 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-02 10:11:11 --> Controller Class Initialized
INFO - 2024-10-02 10:11:11 --> Final output sent to browser
DEBUG - 2024-10-02 10:11:11 --> Total execution time: 0.0324
INFO - 2024-10-02 10:11:14 --> Config Class Initialized
INFO - 2024-10-02 10:11:14 --> Hooks Class Initialized
DEBUG - 2024-10-02 10:11:14 --> UTF-8 Support Enabled
INFO - 2024-10-02 10:11:14 --> Utf8 Class Initialized
INFO - 2024-10-02 10:11:14 --> URI Class Initialized
INFO - 2024-10-02 10:11:14 --> Router Class Initialized
INFO - 2024-10-02 10:11:14 --> Output Class Initialized
INFO - 2024-10-02 10:11:14 --> Security Class Initialized
DEBUG - 2024-10-02 10:11:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-02 10:11:14 --> Input Class Initialized
INFO - 2024-10-02 10:11:14 --> Language Class Initialized
INFO - 2024-10-02 10:11:14 --> Language Class Initialized
INFO - 2024-10-02 10:11:14 --> Config Class Initialized
INFO - 2024-10-02 10:11:14 --> Loader Class Initialized
INFO - 2024-10-02 10:11:14 --> Helper loaded: url_helper
INFO - 2024-10-02 10:11:14 --> Helper loaded: file_helper
INFO - 2024-10-02 10:11:14 --> Helper loaded: form_helper
INFO - 2024-10-02 10:11:14 --> Helper loaded: my_helper
INFO - 2024-10-02 10:11:14 --> Database Driver Class Initialized
INFO - 2024-10-02 10:11:14 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-02 10:11:14 --> Controller Class Initialized
INFO - 2024-10-02 10:11:14 --> Final output sent to browser
DEBUG - 2024-10-02 10:11:14 --> Total execution time: 0.0420
INFO - 2024-10-02 10:11:18 --> Config Class Initialized
INFO - 2024-10-02 10:11:18 --> Hooks Class Initialized
DEBUG - 2024-10-02 10:11:18 --> UTF-8 Support Enabled
INFO - 2024-10-02 10:11:18 --> Utf8 Class Initialized
INFO - 2024-10-02 10:11:18 --> URI Class Initialized
INFO - 2024-10-02 10:11:18 --> Router Class Initialized
INFO - 2024-10-02 10:11:18 --> Output Class Initialized
INFO - 2024-10-02 10:11:18 --> Security Class Initialized
DEBUG - 2024-10-02 10:11:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-02 10:11:18 --> Input Class Initialized
INFO - 2024-10-02 10:11:18 --> Language Class Initialized
INFO - 2024-10-02 10:11:18 --> Language Class Initialized
INFO - 2024-10-02 10:11:18 --> Config Class Initialized
INFO - 2024-10-02 10:11:18 --> Loader Class Initialized
INFO - 2024-10-02 10:11:18 --> Helper loaded: url_helper
INFO - 2024-10-02 10:11:18 --> Helper loaded: file_helper
INFO - 2024-10-02 10:11:18 --> Helper loaded: form_helper
INFO - 2024-10-02 10:11:18 --> Helper loaded: my_helper
INFO - 2024-10-02 10:11:18 --> Database Driver Class Initialized
INFO - 2024-10-02 10:11:18 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-02 10:11:18 --> Controller Class Initialized
INFO - 2024-10-02 10:11:18 --> Final output sent to browser
DEBUG - 2024-10-02 10:11:18 --> Total execution time: 0.0344
INFO - 2024-10-02 10:11:20 --> Config Class Initialized
INFO - 2024-10-02 10:11:20 --> Hooks Class Initialized
DEBUG - 2024-10-02 10:11:20 --> UTF-8 Support Enabled
INFO - 2024-10-02 10:11:20 --> Utf8 Class Initialized
INFO - 2024-10-02 10:11:20 --> URI Class Initialized
INFO - 2024-10-02 10:11:20 --> Router Class Initialized
INFO - 2024-10-02 10:11:20 --> Output Class Initialized
INFO - 2024-10-02 10:11:20 --> Security Class Initialized
DEBUG - 2024-10-02 10:11:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-02 10:11:20 --> Input Class Initialized
INFO - 2024-10-02 10:11:20 --> Language Class Initialized
INFO - 2024-10-02 10:11:20 --> Language Class Initialized
INFO - 2024-10-02 10:11:20 --> Config Class Initialized
INFO - 2024-10-02 10:11:20 --> Loader Class Initialized
INFO - 2024-10-02 10:11:20 --> Helper loaded: url_helper
INFO - 2024-10-02 10:11:20 --> Helper loaded: file_helper
INFO - 2024-10-02 10:11:20 --> Helper loaded: form_helper
INFO - 2024-10-02 10:11:20 --> Helper loaded: my_helper
INFO - 2024-10-02 10:11:20 --> Database Driver Class Initialized
INFO - 2024-10-02 10:11:20 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-02 10:11:20 --> Controller Class Initialized
INFO - 2024-10-02 10:11:20 --> Final output sent to browser
DEBUG - 2024-10-02 10:11:20 --> Total execution time: 0.0540
INFO - 2024-10-02 10:11:21 --> Config Class Initialized
INFO - 2024-10-02 10:11:21 --> Hooks Class Initialized
DEBUG - 2024-10-02 10:11:21 --> UTF-8 Support Enabled
INFO - 2024-10-02 10:11:21 --> Utf8 Class Initialized
INFO - 2024-10-02 10:11:21 --> URI Class Initialized
INFO - 2024-10-02 10:11:21 --> Router Class Initialized
INFO - 2024-10-02 10:11:21 --> Output Class Initialized
INFO - 2024-10-02 10:11:21 --> Security Class Initialized
DEBUG - 2024-10-02 10:11:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-02 10:11:21 --> Input Class Initialized
INFO - 2024-10-02 10:11:21 --> Language Class Initialized
INFO - 2024-10-02 10:11:21 --> Language Class Initialized
INFO - 2024-10-02 10:11:21 --> Config Class Initialized
INFO - 2024-10-02 10:11:21 --> Loader Class Initialized
INFO - 2024-10-02 10:11:21 --> Helper loaded: url_helper
INFO - 2024-10-02 10:11:21 --> Helper loaded: file_helper
INFO - 2024-10-02 10:11:21 --> Helper loaded: form_helper
INFO - 2024-10-02 10:11:21 --> Helper loaded: my_helper
INFO - 2024-10-02 10:11:21 --> Database Driver Class Initialized
INFO - 2024-10-02 10:11:21 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-02 10:11:21 --> Controller Class Initialized
INFO - 2024-10-02 10:11:21 --> Final output sent to browser
DEBUG - 2024-10-02 10:11:21 --> Total execution time: 0.0316
INFO - 2024-10-02 10:11:25 --> Config Class Initialized
INFO - 2024-10-02 10:11:25 --> Hooks Class Initialized
DEBUG - 2024-10-02 10:11:25 --> UTF-8 Support Enabled
INFO - 2024-10-02 10:11:25 --> Utf8 Class Initialized
INFO - 2024-10-02 10:11:25 --> URI Class Initialized
INFO - 2024-10-02 10:11:25 --> Router Class Initialized
INFO - 2024-10-02 10:11:25 --> Output Class Initialized
INFO - 2024-10-02 10:11:25 --> Security Class Initialized
DEBUG - 2024-10-02 10:11:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-02 10:11:25 --> Input Class Initialized
INFO - 2024-10-02 10:11:25 --> Language Class Initialized
INFO - 2024-10-02 10:11:25 --> Language Class Initialized
INFO - 2024-10-02 10:11:25 --> Config Class Initialized
INFO - 2024-10-02 10:11:25 --> Loader Class Initialized
INFO - 2024-10-02 10:11:25 --> Helper loaded: url_helper
INFO - 2024-10-02 10:11:25 --> Helper loaded: file_helper
INFO - 2024-10-02 10:11:25 --> Helper loaded: form_helper
INFO - 2024-10-02 10:11:25 --> Helper loaded: my_helper
INFO - 2024-10-02 10:11:25 --> Database Driver Class Initialized
INFO - 2024-10-02 10:11:25 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-02 10:11:25 --> Controller Class Initialized
INFO - 2024-10-02 10:11:25 --> Final output sent to browser
DEBUG - 2024-10-02 10:11:25 --> Total execution time: 0.0372
INFO - 2024-10-02 10:11:26 --> Config Class Initialized
INFO - 2024-10-02 10:11:26 --> Hooks Class Initialized
DEBUG - 2024-10-02 10:11:26 --> UTF-8 Support Enabled
INFO - 2024-10-02 10:11:26 --> Utf8 Class Initialized
INFO - 2024-10-02 10:11:26 --> URI Class Initialized
INFO - 2024-10-02 10:11:26 --> Router Class Initialized
INFO - 2024-10-02 10:11:26 --> Output Class Initialized
INFO - 2024-10-02 10:11:26 --> Security Class Initialized
DEBUG - 2024-10-02 10:11:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-02 10:11:26 --> Input Class Initialized
INFO - 2024-10-02 10:11:26 --> Language Class Initialized
INFO - 2024-10-02 10:11:26 --> Language Class Initialized
INFO - 2024-10-02 10:11:26 --> Config Class Initialized
INFO - 2024-10-02 10:11:26 --> Loader Class Initialized
INFO - 2024-10-02 10:11:26 --> Helper loaded: url_helper
INFO - 2024-10-02 10:11:26 --> Helper loaded: file_helper
INFO - 2024-10-02 10:11:26 --> Helper loaded: form_helper
INFO - 2024-10-02 10:11:26 --> Helper loaded: my_helper
INFO - 2024-10-02 10:11:26 --> Database Driver Class Initialized
INFO - 2024-10-02 10:11:26 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-02 10:11:26 --> Controller Class Initialized
INFO - 2024-10-02 10:11:26 --> Final output sent to browser
DEBUG - 2024-10-02 10:11:26 --> Total execution time: 0.0392
INFO - 2024-10-02 10:11:30 --> Config Class Initialized
INFO - 2024-10-02 10:11:30 --> Hooks Class Initialized
DEBUG - 2024-10-02 10:11:30 --> UTF-8 Support Enabled
INFO - 2024-10-02 10:11:30 --> Utf8 Class Initialized
INFO - 2024-10-02 10:11:30 --> URI Class Initialized
INFO - 2024-10-02 10:11:30 --> Router Class Initialized
INFO - 2024-10-02 10:11:30 --> Output Class Initialized
INFO - 2024-10-02 10:11:30 --> Security Class Initialized
DEBUG - 2024-10-02 10:11:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-02 10:11:30 --> Input Class Initialized
INFO - 2024-10-02 10:11:30 --> Language Class Initialized
INFO - 2024-10-02 10:11:30 --> Language Class Initialized
INFO - 2024-10-02 10:11:30 --> Config Class Initialized
INFO - 2024-10-02 10:11:30 --> Loader Class Initialized
INFO - 2024-10-02 10:11:30 --> Helper loaded: url_helper
INFO - 2024-10-02 10:11:30 --> Helper loaded: file_helper
INFO - 2024-10-02 10:11:30 --> Helper loaded: form_helper
INFO - 2024-10-02 10:11:30 --> Helper loaded: my_helper
INFO - 2024-10-02 10:11:30 --> Database Driver Class Initialized
INFO - 2024-10-02 10:11:30 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-02 10:11:30 --> Controller Class Initialized
DEBUG - 2024-10-02 10:11:30 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/view_mapel/views/v_view_mapel.php
DEBUG - 2024-10-02 10:11:30 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-10-02 10:11:30 --> Final output sent to browser
DEBUG - 2024-10-02 10:11:30 --> Total execution time: 0.0291
INFO - 2024-10-02 10:11:33 --> Config Class Initialized
INFO - 2024-10-02 10:11:33 --> Hooks Class Initialized
DEBUG - 2024-10-02 10:11:33 --> UTF-8 Support Enabled
INFO - 2024-10-02 10:11:33 --> Utf8 Class Initialized
INFO - 2024-10-02 10:11:33 --> URI Class Initialized
INFO - 2024-10-02 10:11:33 --> Router Class Initialized
INFO - 2024-10-02 10:11:33 --> Output Class Initialized
INFO - 2024-10-02 10:11:33 --> Security Class Initialized
DEBUG - 2024-10-02 10:11:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-02 10:11:33 --> Input Class Initialized
INFO - 2024-10-02 10:11:33 --> Language Class Initialized
INFO - 2024-10-02 10:11:33 --> Language Class Initialized
INFO - 2024-10-02 10:11:33 --> Config Class Initialized
INFO - 2024-10-02 10:11:33 --> Loader Class Initialized
INFO - 2024-10-02 10:11:33 --> Helper loaded: url_helper
INFO - 2024-10-02 10:11:33 --> Helper loaded: file_helper
INFO - 2024-10-02 10:11:33 --> Helper loaded: form_helper
INFO - 2024-10-02 10:11:33 --> Helper loaded: my_helper
INFO - 2024-10-02 10:11:33 --> Database Driver Class Initialized
INFO - 2024-10-02 10:11:33 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-02 10:11:33 --> Controller Class Initialized
DEBUG - 2024-10-02 10:11:33 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_catatan_guru/views/list.php
DEBUG - 2024-10-02 10:11:33 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-10-02 10:11:33 --> Final output sent to browser
DEBUG - 2024-10-02 10:11:33 --> Total execution time: 0.0422
INFO - 2024-10-02 10:11:34 --> Config Class Initialized
INFO - 2024-10-02 10:11:34 --> Hooks Class Initialized
DEBUG - 2024-10-02 10:11:34 --> UTF-8 Support Enabled
INFO - 2024-10-02 10:11:34 --> Utf8 Class Initialized
INFO - 2024-10-02 10:11:34 --> URI Class Initialized
INFO - 2024-10-02 10:11:34 --> Router Class Initialized
INFO - 2024-10-02 10:11:34 --> Output Class Initialized
INFO - 2024-10-02 10:11:34 --> Security Class Initialized
DEBUG - 2024-10-02 10:11:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-02 10:11:34 --> Input Class Initialized
INFO - 2024-10-02 10:11:34 --> Language Class Initialized
INFO - 2024-10-02 10:11:34 --> Language Class Initialized
INFO - 2024-10-02 10:11:34 --> Config Class Initialized
INFO - 2024-10-02 10:11:34 --> Loader Class Initialized
INFO - 2024-10-02 10:11:34 --> Helper loaded: url_helper
INFO - 2024-10-02 10:11:34 --> Helper loaded: file_helper
INFO - 2024-10-02 10:11:34 --> Helper loaded: form_helper
INFO - 2024-10-02 10:11:34 --> Helper loaded: my_helper
INFO - 2024-10-02 10:11:34 --> Database Driver Class Initialized
INFO - 2024-10-02 10:11:34 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-02 10:11:34 --> Controller Class Initialized
INFO - 2024-10-02 10:11:34 --> Final output sent to browser
DEBUG - 2024-10-02 10:11:34 --> Total execution time: 0.0577
INFO - 2024-10-02 10:11:40 --> Config Class Initialized
INFO - 2024-10-02 10:11:40 --> Hooks Class Initialized
DEBUG - 2024-10-02 10:11:40 --> UTF-8 Support Enabled
INFO - 2024-10-02 10:11:40 --> Utf8 Class Initialized
INFO - 2024-10-02 10:11:40 --> URI Class Initialized
INFO - 2024-10-02 10:11:40 --> Router Class Initialized
INFO - 2024-10-02 10:11:40 --> Output Class Initialized
INFO - 2024-10-02 10:11:40 --> Security Class Initialized
DEBUG - 2024-10-02 10:11:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-02 10:11:40 --> Input Class Initialized
INFO - 2024-10-02 10:11:40 --> Language Class Initialized
INFO - 2024-10-02 10:11:40 --> Language Class Initialized
INFO - 2024-10-02 10:11:40 --> Config Class Initialized
INFO - 2024-10-02 10:11:40 --> Loader Class Initialized
INFO - 2024-10-02 10:11:40 --> Helper loaded: url_helper
INFO - 2024-10-02 10:11:40 --> Helper loaded: file_helper
INFO - 2024-10-02 10:11:40 --> Helper loaded: form_helper
INFO - 2024-10-02 10:11:40 --> Helper loaded: my_helper
INFO - 2024-10-02 10:11:40 --> Database Driver Class Initialized
INFO - 2024-10-02 10:11:40 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-02 10:11:40 --> Controller Class Initialized
DEBUG - 2024-10-02 10:11:40 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/view_mapel/views/v_view_mapel.php
DEBUG - 2024-10-02 10:11:40 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-10-02 10:11:40 --> Final output sent to browser
DEBUG - 2024-10-02 10:11:40 --> Total execution time: 0.0306
INFO - 2024-10-02 10:11:41 --> Config Class Initialized
INFO - 2024-10-02 10:11:41 --> Hooks Class Initialized
DEBUG - 2024-10-02 10:11:41 --> UTF-8 Support Enabled
INFO - 2024-10-02 10:11:41 --> Utf8 Class Initialized
INFO - 2024-10-02 10:11:41 --> URI Class Initialized
INFO - 2024-10-02 10:11:41 --> Router Class Initialized
INFO - 2024-10-02 10:11:41 --> Output Class Initialized
INFO - 2024-10-02 10:11:41 --> Security Class Initialized
DEBUG - 2024-10-02 10:11:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-02 10:11:41 --> Input Class Initialized
INFO - 2024-10-02 10:11:41 --> Language Class Initialized
INFO - 2024-10-02 10:11:41 --> Language Class Initialized
INFO - 2024-10-02 10:11:41 --> Config Class Initialized
INFO - 2024-10-02 10:11:41 --> Loader Class Initialized
INFO - 2024-10-02 10:11:41 --> Helper loaded: url_helper
INFO - 2024-10-02 10:11:41 --> Helper loaded: file_helper
INFO - 2024-10-02 10:11:41 --> Helper loaded: form_helper
INFO - 2024-10-02 10:11:41 --> Helper loaded: my_helper
INFO - 2024-10-02 10:11:41 --> Database Driver Class Initialized
INFO - 2024-10-02 10:11:41 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-02 10:11:41 --> Controller Class Initialized
DEBUG - 2024-10-02 10:11:41 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/views/list.php
DEBUG - 2024-10-02 10:11:41 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-10-02 10:11:41 --> Final output sent to browser
DEBUG - 2024-10-02 10:11:41 --> Total execution time: 0.0361
INFO - 2024-10-02 10:11:41 --> Config Class Initialized
INFO - 2024-10-02 10:11:41 --> Hooks Class Initialized
DEBUG - 2024-10-02 10:11:41 --> UTF-8 Support Enabled
INFO - 2024-10-02 10:11:41 --> Utf8 Class Initialized
INFO - 2024-10-02 10:11:41 --> URI Class Initialized
INFO - 2024-10-02 10:11:41 --> Router Class Initialized
INFO - 2024-10-02 10:11:41 --> Output Class Initialized
INFO - 2024-10-02 10:11:41 --> Security Class Initialized
DEBUG - 2024-10-02 10:11:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-02 10:11:41 --> Input Class Initialized
INFO - 2024-10-02 10:11:41 --> Language Class Initialized
INFO - 2024-10-02 10:11:41 --> Language Class Initialized
INFO - 2024-10-02 10:11:41 --> Config Class Initialized
INFO - 2024-10-02 10:11:41 --> Loader Class Initialized
INFO - 2024-10-02 10:11:41 --> Helper loaded: url_helper
INFO - 2024-10-02 10:11:41 --> Helper loaded: file_helper
INFO - 2024-10-02 10:11:41 --> Helper loaded: form_helper
INFO - 2024-10-02 10:11:41 --> Helper loaded: my_helper
INFO - 2024-10-02 10:11:41 --> Database Driver Class Initialized
INFO - 2024-10-02 10:11:41 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-02 10:11:41 --> Controller Class Initialized
INFO - 2024-10-02 10:11:42 --> Config Class Initialized
INFO - 2024-10-02 10:11:42 --> Hooks Class Initialized
DEBUG - 2024-10-02 10:11:42 --> UTF-8 Support Enabled
INFO - 2024-10-02 10:11:42 --> Utf8 Class Initialized
INFO - 2024-10-02 10:11:42 --> URI Class Initialized
INFO - 2024-10-02 10:11:42 --> Router Class Initialized
INFO - 2024-10-02 10:11:42 --> Output Class Initialized
INFO - 2024-10-02 10:11:42 --> Security Class Initialized
DEBUG - 2024-10-02 10:11:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-02 10:11:42 --> Input Class Initialized
INFO - 2024-10-02 10:11:42 --> Language Class Initialized
INFO - 2024-10-02 10:11:42 --> Language Class Initialized
INFO - 2024-10-02 10:11:42 --> Config Class Initialized
INFO - 2024-10-02 10:11:42 --> Loader Class Initialized
INFO - 2024-10-02 10:11:42 --> Helper loaded: url_helper
INFO - 2024-10-02 10:11:42 --> Helper loaded: file_helper
INFO - 2024-10-02 10:11:42 --> Helper loaded: form_helper
INFO - 2024-10-02 10:11:42 --> Helper loaded: my_helper
INFO - 2024-10-02 10:11:42 --> Database Driver Class Initialized
INFO - 2024-10-02 10:11:42 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-02 10:11:42 --> Controller Class Initialized
INFO - 2024-10-02 10:11:42 --> Final output sent to browser
DEBUG - 2024-10-02 10:11:42 --> Total execution time: 0.0334
INFO - 2024-10-02 10:11:46 --> Config Class Initialized
INFO - 2024-10-02 10:11:46 --> Hooks Class Initialized
DEBUG - 2024-10-02 10:11:46 --> UTF-8 Support Enabled
INFO - 2024-10-02 10:11:46 --> Utf8 Class Initialized
INFO - 2024-10-02 10:11:46 --> URI Class Initialized
INFO - 2024-10-02 10:11:46 --> Router Class Initialized
INFO - 2024-10-02 10:11:46 --> Output Class Initialized
INFO - 2024-10-02 10:11:46 --> Security Class Initialized
DEBUG - 2024-10-02 10:11:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-02 10:11:46 --> Input Class Initialized
INFO - 2024-10-02 10:11:46 --> Language Class Initialized
INFO - 2024-10-02 10:11:46 --> Language Class Initialized
INFO - 2024-10-02 10:11:46 --> Config Class Initialized
INFO - 2024-10-02 10:11:46 --> Loader Class Initialized
INFO - 2024-10-02 10:11:46 --> Helper loaded: url_helper
INFO - 2024-10-02 10:11:46 --> Helper loaded: file_helper
INFO - 2024-10-02 10:11:46 --> Helper loaded: form_helper
INFO - 2024-10-02 10:11:46 --> Helper loaded: my_helper
INFO - 2024-10-02 10:11:46 --> Database Driver Class Initialized
INFO - 2024-10-02 10:11:46 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-02 10:11:46 --> Controller Class Initialized
INFO - 2024-10-02 10:11:46 --> Final output sent to browser
DEBUG - 2024-10-02 10:11:46 --> Total execution time: 0.0397
INFO - 2024-10-02 10:11:49 --> Config Class Initialized
INFO - 2024-10-02 10:11:49 --> Hooks Class Initialized
DEBUG - 2024-10-02 10:11:49 --> UTF-8 Support Enabled
INFO - 2024-10-02 10:11:49 --> Utf8 Class Initialized
INFO - 2024-10-02 10:11:49 --> URI Class Initialized
INFO - 2024-10-02 10:11:49 --> Router Class Initialized
INFO - 2024-10-02 10:11:49 --> Output Class Initialized
INFO - 2024-10-02 10:11:49 --> Security Class Initialized
DEBUG - 2024-10-02 10:11:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-02 10:11:49 --> Input Class Initialized
INFO - 2024-10-02 10:11:49 --> Language Class Initialized
INFO - 2024-10-02 10:11:49 --> Language Class Initialized
INFO - 2024-10-02 10:11:49 --> Config Class Initialized
INFO - 2024-10-02 10:11:49 --> Loader Class Initialized
INFO - 2024-10-02 10:11:49 --> Helper loaded: url_helper
INFO - 2024-10-02 10:11:49 --> Helper loaded: file_helper
INFO - 2024-10-02 10:11:49 --> Helper loaded: form_helper
INFO - 2024-10-02 10:11:49 --> Helper loaded: my_helper
INFO - 2024-10-02 10:11:49 --> Database Driver Class Initialized
INFO - 2024-10-02 10:11:49 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-02 10:11:49 --> Controller Class Initialized
INFO - 2024-10-02 10:11:49 --> Final output sent to browser
DEBUG - 2024-10-02 10:11:49 --> Total execution time: 0.0546
INFO - 2024-10-02 10:11:51 --> Config Class Initialized
INFO - 2024-10-02 10:11:51 --> Hooks Class Initialized
DEBUG - 2024-10-02 10:11:51 --> UTF-8 Support Enabled
INFO - 2024-10-02 10:11:51 --> Utf8 Class Initialized
INFO - 2024-10-02 10:11:51 --> URI Class Initialized
INFO - 2024-10-02 10:11:51 --> Router Class Initialized
INFO - 2024-10-02 10:11:51 --> Output Class Initialized
INFO - 2024-10-02 10:11:51 --> Security Class Initialized
DEBUG - 2024-10-02 10:11:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-02 10:11:51 --> Input Class Initialized
INFO - 2024-10-02 10:11:51 --> Language Class Initialized
INFO - 2024-10-02 10:11:51 --> Language Class Initialized
INFO - 2024-10-02 10:11:51 --> Config Class Initialized
INFO - 2024-10-02 10:11:51 --> Loader Class Initialized
INFO - 2024-10-02 10:11:51 --> Helper loaded: url_helper
INFO - 2024-10-02 10:11:51 --> Helper loaded: file_helper
INFO - 2024-10-02 10:11:51 --> Helper loaded: form_helper
INFO - 2024-10-02 10:11:51 --> Helper loaded: my_helper
INFO - 2024-10-02 10:11:51 --> Database Driver Class Initialized
INFO - 2024-10-02 10:11:51 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-02 10:11:51 --> Controller Class Initialized
INFO - 2024-10-02 10:25:26 --> Config Class Initialized
INFO - 2024-10-02 10:25:26 --> Hooks Class Initialized
DEBUG - 2024-10-02 10:25:26 --> UTF-8 Support Enabled
INFO - 2024-10-02 10:25:26 --> Utf8 Class Initialized
INFO - 2024-10-02 10:25:26 --> URI Class Initialized
INFO - 2024-10-02 10:25:26 --> Router Class Initialized
INFO - 2024-10-02 10:25:26 --> Output Class Initialized
INFO - 2024-10-02 10:25:26 --> Security Class Initialized
DEBUG - 2024-10-02 10:25:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-02 10:25:26 --> Input Class Initialized
INFO - 2024-10-02 10:25:26 --> Language Class Initialized
INFO - 2024-10-02 10:25:26 --> Language Class Initialized
INFO - 2024-10-02 10:25:26 --> Config Class Initialized
INFO - 2024-10-02 10:25:26 --> Loader Class Initialized
INFO - 2024-10-02 10:25:26 --> Helper loaded: url_helper
INFO - 2024-10-02 10:25:26 --> Helper loaded: file_helper
INFO - 2024-10-02 10:25:26 --> Helper loaded: form_helper
INFO - 2024-10-02 10:25:26 --> Helper loaded: my_helper
INFO - 2024-10-02 10:25:26 --> Database Driver Class Initialized
INFO - 2024-10-02 10:25:26 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-02 10:25:26 --> Controller Class Initialized
DEBUG - 2024-10-02 10:25:26 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/view_mapel/views/v_view_mapel.php
DEBUG - 2024-10-02 10:25:26 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-10-02 10:25:26 --> Final output sent to browser
DEBUG - 2024-10-02 10:25:26 --> Total execution time: 0.0411
INFO - 2024-10-02 10:25:28 --> Config Class Initialized
INFO - 2024-10-02 10:25:28 --> Hooks Class Initialized
DEBUG - 2024-10-02 10:25:28 --> UTF-8 Support Enabled
INFO - 2024-10-02 10:25:28 --> Utf8 Class Initialized
INFO - 2024-10-02 10:25:28 --> URI Class Initialized
INFO - 2024-10-02 10:25:28 --> Router Class Initialized
INFO - 2024-10-02 10:25:28 --> Output Class Initialized
INFO - 2024-10-02 10:25:28 --> Security Class Initialized
DEBUG - 2024-10-02 10:25:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-02 10:25:28 --> Input Class Initialized
INFO - 2024-10-02 10:25:28 --> Language Class Initialized
INFO - 2024-10-02 10:25:28 --> Language Class Initialized
INFO - 2024-10-02 10:25:28 --> Config Class Initialized
INFO - 2024-10-02 10:25:28 --> Loader Class Initialized
INFO - 2024-10-02 10:25:28 --> Helper loaded: url_helper
INFO - 2024-10-02 10:25:28 --> Helper loaded: file_helper
INFO - 2024-10-02 10:25:28 --> Helper loaded: form_helper
INFO - 2024-10-02 10:25:28 --> Helper loaded: my_helper
INFO - 2024-10-02 10:25:28 --> Database Driver Class Initialized
INFO - 2024-10-02 10:25:28 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-02 10:25:28 --> Controller Class Initialized
DEBUG - 2024-10-02 10:25:28 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/views/list.php
DEBUG - 2024-10-02 10:25:28 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-10-02 10:25:28 --> Final output sent to browser
DEBUG - 2024-10-02 10:25:28 --> Total execution time: 0.0357
INFO - 2024-10-02 10:25:28 --> Config Class Initialized
INFO - 2024-10-02 10:25:28 --> Hooks Class Initialized
DEBUG - 2024-10-02 10:25:28 --> UTF-8 Support Enabled
INFO - 2024-10-02 10:25:28 --> Utf8 Class Initialized
INFO - 2024-10-02 10:25:28 --> URI Class Initialized
INFO - 2024-10-02 10:25:28 --> Router Class Initialized
INFO - 2024-10-02 10:25:28 --> Output Class Initialized
INFO - 2024-10-02 10:25:28 --> Security Class Initialized
DEBUG - 2024-10-02 10:25:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-02 10:25:28 --> Input Class Initialized
INFO - 2024-10-02 10:25:28 --> Language Class Initialized
INFO - 2024-10-02 10:25:28 --> Language Class Initialized
INFO - 2024-10-02 10:25:28 --> Config Class Initialized
INFO - 2024-10-02 10:25:28 --> Loader Class Initialized
INFO - 2024-10-02 10:25:28 --> Helper loaded: url_helper
INFO - 2024-10-02 10:25:28 --> Helper loaded: file_helper
INFO - 2024-10-02 10:25:28 --> Helper loaded: form_helper
INFO - 2024-10-02 10:25:28 --> Helper loaded: my_helper
INFO - 2024-10-02 10:25:28 --> Database Driver Class Initialized
INFO - 2024-10-02 10:25:28 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-02 10:25:28 --> Controller Class Initialized
INFO - 2024-10-02 10:25:29 --> Config Class Initialized
INFO - 2024-10-02 10:25:29 --> Hooks Class Initialized
DEBUG - 2024-10-02 10:25:29 --> UTF-8 Support Enabled
INFO - 2024-10-02 10:25:29 --> Utf8 Class Initialized
INFO - 2024-10-02 10:25:29 --> URI Class Initialized
INFO - 2024-10-02 10:25:29 --> Router Class Initialized
INFO - 2024-10-02 10:25:29 --> Output Class Initialized
INFO - 2024-10-02 10:25:29 --> Security Class Initialized
DEBUG - 2024-10-02 10:25:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-02 10:25:29 --> Input Class Initialized
INFO - 2024-10-02 10:25:29 --> Language Class Initialized
INFO - 2024-10-02 10:25:29 --> Language Class Initialized
INFO - 2024-10-02 10:25:29 --> Config Class Initialized
INFO - 2024-10-02 10:25:29 --> Loader Class Initialized
INFO - 2024-10-02 10:25:29 --> Helper loaded: url_helper
INFO - 2024-10-02 10:25:29 --> Helper loaded: file_helper
INFO - 2024-10-02 10:25:29 --> Helper loaded: form_helper
INFO - 2024-10-02 10:25:29 --> Helper loaded: my_helper
INFO - 2024-10-02 10:25:29 --> Database Driver Class Initialized
INFO - 2024-10-02 10:25:29 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-02 10:25:29 --> Controller Class Initialized
DEBUG - 2024-10-02 10:25:29 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/views/form.php
DEBUG - 2024-10-02 10:25:29 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-10-02 10:25:29 --> Final output sent to browser
DEBUG - 2024-10-02 10:25:29 --> Total execution time: 0.0386
INFO - 2024-10-02 10:25:35 --> Config Class Initialized
INFO - 2024-10-02 10:25:35 --> Hooks Class Initialized
DEBUG - 2024-10-02 10:25:35 --> UTF-8 Support Enabled
INFO - 2024-10-02 10:25:35 --> Utf8 Class Initialized
INFO - 2024-10-02 10:25:35 --> URI Class Initialized
INFO - 2024-10-02 10:25:35 --> Router Class Initialized
INFO - 2024-10-02 10:25:35 --> Output Class Initialized
INFO - 2024-10-02 10:25:35 --> Security Class Initialized
DEBUG - 2024-10-02 10:25:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-02 10:25:35 --> Input Class Initialized
INFO - 2024-10-02 10:25:35 --> Language Class Initialized
INFO - 2024-10-02 10:25:35 --> Language Class Initialized
INFO - 2024-10-02 10:25:35 --> Config Class Initialized
INFO - 2024-10-02 10:25:35 --> Loader Class Initialized
INFO - 2024-10-02 10:25:35 --> Helper loaded: url_helper
INFO - 2024-10-02 10:25:35 --> Helper loaded: file_helper
INFO - 2024-10-02 10:25:35 --> Helper loaded: form_helper
INFO - 2024-10-02 10:25:35 --> Helper loaded: my_helper
INFO - 2024-10-02 10:25:35 --> Database Driver Class Initialized
INFO - 2024-10-02 10:25:35 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-02 10:25:35 --> Controller Class Initialized
INFO - 2024-10-02 10:25:35 --> Config Class Initialized
INFO - 2024-10-02 10:25:35 --> Hooks Class Initialized
DEBUG - 2024-10-02 10:25:35 --> UTF-8 Support Enabled
INFO - 2024-10-02 10:25:35 --> Utf8 Class Initialized
INFO - 2024-10-02 10:25:35 --> URI Class Initialized
INFO - 2024-10-02 10:25:35 --> Router Class Initialized
INFO - 2024-10-02 10:25:35 --> Output Class Initialized
INFO - 2024-10-02 10:25:35 --> Security Class Initialized
DEBUG - 2024-10-02 10:25:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-02 10:25:35 --> Input Class Initialized
INFO - 2024-10-02 10:25:35 --> Language Class Initialized
INFO - 2024-10-02 10:25:35 --> Language Class Initialized
INFO - 2024-10-02 10:25:35 --> Config Class Initialized
INFO - 2024-10-02 10:25:35 --> Loader Class Initialized
INFO - 2024-10-02 10:25:35 --> Helper loaded: url_helper
INFO - 2024-10-02 10:25:35 --> Helper loaded: file_helper
INFO - 2024-10-02 10:25:35 --> Helper loaded: form_helper
INFO - 2024-10-02 10:25:35 --> Helper loaded: my_helper
INFO - 2024-10-02 10:25:35 --> Database Driver Class Initialized
INFO - 2024-10-02 10:25:35 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-02 10:25:35 --> Controller Class Initialized
DEBUG - 2024-10-02 10:25:35 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/views/list.php
DEBUG - 2024-10-02 10:25:35 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-10-02 10:25:35 --> Final output sent to browser
DEBUG - 2024-10-02 10:25:35 --> Total execution time: 0.0351
INFO - 2024-10-02 10:25:35 --> Config Class Initialized
INFO - 2024-10-02 10:25:35 --> Hooks Class Initialized
DEBUG - 2024-10-02 10:25:35 --> UTF-8 Support Enabled
INFO - 2024-10-02 10:25:35 --> Utf8 Class Initialized
INFO - 2024-10-02 10:25:35 --> URI Class Initialized
INFO - 2024-10-02 10:25:35 --> Router Class Initialized
INFO - 2024-10-02 10:25:35 --> Output Class Initialized
INFO - 2024-10-02 10:25:35 --> Security Class Initialized
DEBUG - 2024-10-02 10:25:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-02 10:25:35 --> Input Class Initialized
INFO - 2024-10-02 10:25:35 --> Language Class Initialized
INFO - 2024-10-02 10:25:35 --> Language Class Initialized
INFO - 2024-10-02 10:25:35 --> Config Class Initialized
INFO - 2024-10-02 10:25:35 --> Loader Class Initialized
INFO - 2024-10-02 10:25:35 --> Helper loaded: url_helper
INFO - 2024-10-02 10:25:35 --> Helper loaded: file_helper
INFO - 2024-10-02 10:25:35 --> Helper loaded: form_helper
INFO - 2024-10-02 10:25:35 --> Helper loaded: my_helper
INFO - 2024-10-02 10:25:35 --> Database Driver Class Initialized
INFO - 2024-10-02 10:25:35 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-02 10:25:35 --> Controller Class Initialized
INFO - 2024-10-02 10:25:40 --> Config Class Initialized
INFO - 2024-10-02 10:25:40 --> Hooks Class Initialized
DEBUG - 2024-10-02 10:25:40 --> UTF-8 Support Enabled
INFO - 2024-10-02 10:25:40 --> Utf8 Class Initialized
INFO - 2024-10-02 10:25:40 --> URI Class Initialized
INFO - 2024-10-02 10:25:40 --> Router Class Initialized
INFO - 2024-10-02 10:25:40 --> Output Class Initialized
INFO - 2024-10-02 10:25:40 --> Security Class Initialized
DEBUG - 2024-10-02 10:25:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-02 10:25:40 --> Input Class Initialized
INFO - 2024-10-02 10:25:40 --> Language Class Initialized
INFO - 2024-10-02 10:25:40 --> Language Class Initialized
INFO - 2024-10-02 10:25:40 --> Config Class Initialized
INFO - 2024-10-02 10:25:40 --> Loader Class Initialized
INFO - 2024-10-02 10:25:40 --> Helper loaded: url_helper
INFO - 2024-10-02 10:25:40 --> Helper loaded: file_helper
INFO - 2024-10-02 10:25:40 --> Helper loaded: form_helper
INFO - 2024-10-02 10:25:40 --> Helper loaded: my_helper
INFO - 2024-10-02 10:25:40 --> Database Driver Class Initialized
INFO - 2024-10-02 10:25:40 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-02 10:25:40 --> Controller Class Initialized
DEBUG - 2024-10-02 10:25:40 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/views/list.php
DEBUG - 2024-10-02 10:25:40 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-10-02 10:25:40 --> Final output sent to browser
DEBUG - 2024-10-02 10:25:40 --> Total execution time: 0.0371
INFO - 2024-10-02 10:25:43 --> Config Class Initialized
INFO - 2024-10-02 10:25:43 --> Hooks Class Initialized
DEBUG - 2024-10-02 10:25:43 --> UTF-8 Support Enabled
INFO - 2024-10-02 10:25:43 --> Utf8 Class Initialized
INFO - 2024-10-02 10:25:43 --> URI Class Initialized
INFO - 2024-10-02 10:25:43 --> Router Class Initialized
INFO - 2024-10-02 10:25:43 --> Output Class Initialized
INFO - 2024-10-02 10:25:43 --> Security Class Initialized
DEBUG - 2024-10-02 10:25:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-02 10:25:43 --> Input Class Initialized
INFO - 2024-10-02 10:25:43 --> Language Class Initialized
INFO - 2024-10-02 10:25:43 --> Language Class Initialized
INFO - 2024-10-02 10:25:43 --> Config Class Initialized
INFO - 2024-10-02 10:25:43 --> Loader Class Initialized
INFO - 2024-10-02 10:25:43 --> Helper loaded: url_helper
INFO - 2024-10-02 10:25:43 --> Helper loaded: file_helper
INFO - 2024-10-02 10:25:43 --> Helper loaded: form_helper
INFO - 2024-10-02 10:25:43 --> Helper loaded: my_helper
INFO - 2024-10-02 10:25:43 --> Database Driver Class Initialized
INFO - 2024-10-02 10:25:43 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-02 10:25:43 --> Controller Class Initialized
DEBUG - 2024-10-02 10:25:43 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/list.php
DEBUG - 2024-10-02 10:25:43 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-10-02 10:25:43 --> Final output sent to browser
DEBUG - 2024-10-02 10:25:43 --> Total execution time: 0.0330
INFO - 2024-10-02 10:25:46 --> Config Class Initialized
INFO - 2024-10-02 10:25:46 --> Hooks Class Initialized
DEBUG - 2024-10-02 10:25:46 --> UTF-8 Support Enabled
INFO - 2024-10-02 10:25:46 --> Utf8 Class Initialized
INFO - 2024-10-02 10:25:46 --> URI Class Initialized
INFO - 2024-10-02 10:25:46 --> Router Class Initialized
INFO - 2024-10-02 10:25:46 --> Output Class Initialized
INFO - 2024-10-02 10:25:46 --> Security Class Initialized
DEBUG - 2024-10-02 10:25:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-02 10:25:46 --> Input Class Initialized
INFO - 2024-10-02 10:25:46 --> Language Class Initialized
INFO - 2024-10-02 10:25:46 --> Language Class Initialized
INFO - 2024-10-02 10:25:46 --> Config Class Initialized
INFO - 2024-10-02 10:25:46 --> Loader Class Initialized
INFO - 2024-10-02 10:25:46 --> Helper loaded: url_helper
INFO - 2024-10-02 10:25:46 --> Helper loaded: file_helper
INFO - 2024-10-02 10:25:46 --> Helper loaded: form_helper
INFO - 2024-10-02 10:25:46 --> Helper loaded: my_helper
INFO - 2024-10-02 10:25:46 --> Database Driver Class Initialized
INFO - 2024-10-02 10:25:46 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-02 10:25:46 --> Controller Class Initialized
ERROR - 2024-10-02 10:25:46 --> Severity: Notice --> Undefined offset: 15 /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1698
ERROR - 2024-10-02 10:25:46 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1698
ERROR - 2024-10-02 10:25:46 --> Severity: Warning --> Invalid argument supplied for foreach() /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1698
ERROR - 2024-10-02 10:25:46 --> Severity: Notice --> Undefined offset: 16 /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1735
ERROR - 2024-10-02 10:25:46 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1735
ERROR - 2024-10-02 10:25:46 --> Severity: Warning --> Invalid argument supplied for foreach() /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1735
ERROR - 2024-10-02 10:25:46 --> Severity: Notice --> Undefined offset: 17 /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1773
ERROR - 2024-10-02 10:25:46 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1773
ERROR - 2024-10-02 10:25:46 --> Severity: Warning --> Invalid argument supplied for foreach() /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1773
DEBUG - 2024-10-02 10:25:46 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php
INFO - 2024-10-02 10:25:49 --> Final output sent to browser
DEBUG - 2024-10-02 10:25:49 --> Total execution time: 2.6760
INFO - 2024-10-02 10:26:50 --> Config Class Initialized
INFO - 2024-10-02 10:26:50 --> Hooks Class Initialized
DEBUG - 2024-10-02 10:26:50 --> UTF-8 Support Enabled
INFO - 2024-10-02 10:26:50 --> Utf8 Class Initialized
INFO - 2024-10-02 10:26:50 --> URI Class Initialized
INFO - 2024-10-02 10:26:50 --> Router Class Initialized
INFO - 2024-10-02 10:26:50 --> Output Class Initialized
INFO - 2024-10-02 10:26:50 --> Security Class Initialized
DEBUG - 2024-10-02 10:26:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-02 10:26:50 --> Input Class Initialized
INFO - 2024-10-02 10:26:50 --> Language Class Initialized
INFO - 2024-10-02 10:26:50 --> Language Class Initialized
INFO - 2024-10-02 10:26:50 --> Config Class Initialized
INFO - 2024-10-02 10:26:50 --> Loader Class Initialized
INFO - 2024-10-02 10:26:50 --> Helper loaded: url_helper
INFO - 2024-10-02 10:26:50 --> Helper loaded: file_helper
INFO - 2024-10-02 10:26:50 --> Helper loaded: form_helper
INFO - 2024-10-02 10:26:50 --> Helper loaded: my_helper
INFO - 2024-10-02 10:26:50 --> Database Driver Class Initialized
INFO - 2024-10-02 10:26:50 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-02 10:26:50 --> Controller Class Initialized
DEBUG - 2024-10-02 10:26:50 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/view_mapel/views/v_view_mapel.php
DEBUG - 2024-10-02 10:26:50 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-10-02 10:26:50 --> Final output sent to browser
DEBUG - 2024-10-02 10:26:50 --> Total execution time: 0.0350
INFO - 2024-10-02 10:26:51 --> Config Class Initialized
INFO - 2024-10-02 10:26:51 --> Hooks Class Initialized
DEBUG - 2024-10-02 10:26:51 --> UTF-8 Support Enabled
INFO - 2024-10-02 10:26:51 --> Utf8 Class Initialized
INFO - 2024-10-02 10:26:51 --> URI Class Initialized
INFO - 2024-10-02 10:26:51 --> Router Class Initialized
INFO - 2024-10-02 10:26:51 --> Output Class Initialized
INFO - 2024-10-02 10:26:51 --> Security Class Initialized
DEBUG - 2024-10-02 10:26:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-02 10:26:51 --> Input Class Initialized
INFO - 2024-10-02 10:26:51 --> Language Class Initialized
INFO - 2024-10-02 10:26:51 --> Language Class Initialized
INFO - 2024-10-02 10:26:51 --> Config Class Initialized
INFO - 2024-10-02 10:26:51 --> Loader Class Initialized
INFO - 2024-10-02 10:26:51 --> Helper loaded: url_helper
INFO - 2024-10-02 10:26:51 --> Helper loaded: file_helper
INFO - 2024-10-02 10:26:51 --> Helper loaded: form_helper
INFO - 2024-10-02 10:26:51 --> Helper loaded: my_helper
INFO - 2024-10-02 10:26:51 --> Database Driver Class Initialized
INFO - 2024-10-02 10:26:51 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-02 10:26:51 --> Controller Class Initialized
DEBUG - 2024-10-02 10:26:51 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/views/list.php
DEBUG - 2024-10-02 10:26:51 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-10-02 10:26:51 --> Final output sent to browser
DEBUG - 2024-10-02 10:26:51 --> Total execution time: 0.0326
INFO - 2024-10-02 10:26:51 --> Config Class Initialized
INFO - 2024-10-02 10:26:51 --> Hooks Class Initialized
DEBUG - 2024-10-02 10:26:51 --> UTF-8 Support Enabled
INFO - 2024-10-02 10:26:51 --> Utf8 Class Initialized
INFO - 2024-10-02 10:26:51 --> URI Class Initialized
INFO - 2024-10-02 10:26:51 --> Router Class Initialized
INFO - 2024-10-02 10:26:51 --> Output Class Initialized
INFO - 2024-10-02 10:26:51 --> Security Class Initialized
DEBUG - 2024-10-02 10:26:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-02 10:26:51 --> Input Class Initialized
INFO - 2024-10-02 10:26:51 --> Language Class Initialized
INFO - 2024-10-02 10:26:51 --> Language Class Initialized
INFO - 2024-10-02 10:26:51 --> Config Class Initialized
INFO - 2024-10-02 10:26:51 --> Loader Class Initialized
INFO - 2024-10-02 10:26:51 --> Helper loaded: url_helper
INFO - 2024-10-02 10:26:51 --> Helper loaded: file_helper
INFO - 2024-10-02 10:26:51 --> Helper loaded: form_helper
INFO - 2024-10-02 10:26:51 --> Helper loaded: my_helper
INFO - 2024-10-02 10:26:51 --> Database Driver Class Initialized
INFO - 2024-10-02 10:26:51 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-02 10:26:51 --> Controller Class Initialized
INFO - 2024-10-02 10:26:52 --> Config Class Initialized
INFO - 2024-10-02 10:26:52 --> Hooks Class Initialized
DEBUG - 2024-10-02 10:26:52 --> UTF-8 Support Enabled
INFO - 2024-10-02 10:26:52 --> Utf8 Class Initialized
INFO - 2024-10-02 10:26:52 --> URI Class Initialized
INFO - 2024-10-02 10:26:52 --> Router Class Initialized
INFO - 2024-10-02 10:26:52 --> Output Class Initialized
INFO - 2024-10-02 10:26:52 --> Security Class Initialized
DEBUG - 2024-10-02 10:26:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-02 10:26:52 --> Input Class Initialized
INFO - 2024-10-02 10:26:52 --> Language Class Initialized
INFO - 2024-10-02 10:26:52 --> Language Class Initialized
INFO - 2024-10-02 10:26:52 --> Config Class Initialized
INFO - 2024-10-02 10:26:52 --> Loader Class Initialized
INFO - 2024-10-02 10:26:52 --> Helper loaded: url_helper
INFO - 2024-10-02 10:26:52 --> Helper loaded: file_helper
INFO - 2024-10-02 10:26:52 --> Helper loaded: form_helper
INFO - 2024-10-02 10:26:52 --> Helper loaded: my_helper
INFO - 2024-10-02 10:26:52 --> Database Driver Class Initialized
INFO - 2024-10-02 10:26:52 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-02 10:26:52 --> Controller Class Initialized
DEBUG - 2024-10-02 10:26:52 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/views/form.php
DEBUG - 2024-10-02 10:26:52 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-10-02 10:26:52 --> Final output sent to browser
DEBUG - 2024-10-02 10:26:52 --> Total execution time: 0.0314
INFO - 2024-10-02 10:26:57 --> Config Class Initialized
INFO - 2024-10-02 10:26:57 --> Hooks Class Initialized
DEBUG - 2024-10-02 10:26:57 --> UTF-8 Support Enabled
INFO - 2024-10-02 10:26:57 --> Utf8 Class Initialized
INFO - 2024-10-02 10:26:57 --> URI Class Initialized
INFO - 2024-10-02 10:26:57 --> Router Class Initialized
INFO - 2024-10-02 10:26:57 --> Output Class Initialized
INFO - 2024-10-02 10:26:57 --> Security Class Initialized
DEBUG - 2024-10-02 10:26:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-02 10:26:57 --> Input Class Initialized
INFO - 2024-10-02 10:26:57 --> Language Class Initialized
INFO - 2024-10-02 10:26:57 --> Language Class Initialized
INFO - 2024-10-02 10:26:57 --> Config Class Initialized
INFO - 2024-10-02 10:26:57 --> Loader Class Initialized
INFO - 2024-10-02 10:26:57 --> Helper loaded: url_helper
INFO - 2024-10-02 10:26:57 --> Helper loaded: file_helper
INFO - 2024-10-02 10:26:57 --> Helper loaded: form_helper
INFO - 2024-10-02 10:26:57 --> Helper loaded: my_helper
INFO - 2024-10-02 10:26:57 --> Database Driver Class Initialized
INFO - 2024-10-02 10:26:57 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-02 10:26:57 --> Controller Class Initialized
INFO - 2024-10-02 10:26:57 --> Config Class Initialized
INFO - 2024-10-02 10:26:57 --> Hooks Class Initialized
DEBUG - 2024-10-02 10:26:57 --> UTF-8 Support Enabled
INFO - 2024-10-02 10:26:57 --> Utf8 Class Initialized
INFO - 2024-10-02 10:26:57 --> URI Class Initialized
INFO - 2024-10-02 10:26:57 --> Router Class Initialized
INFO - 2024-10-02 10:26:57 --> Output Class Initialized
INFO - 2024-10-02 10:26:57 --> Security Class Initialized
DEBUG - 2024-10-02 10:26:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-02 10:26:57 --> Input Class Initialized
INFO - 2024-10-02 10:26:57 --> Language Class Initialized
INFO - 2024-10-02 10:26:57 --> Language Class Initialized
INFO - 2024-10-02 10:26:57 --> Config Class Initialized
INFO - 2024-10-02 10:26:57 --> Loader Class Initialized
INFO - 2024-10-02 10:26:57 --> Helper loaded: url_helper
INFO - 2024-10-02 10:26:57 --> Helper loaded: file_helper
INFO - 2024-10-02 10:26:57 --> Helper loaded: form_helper
INFO - 2024-10-02 10:26:57 --> Helper loaded: my_helper
INFO - 2024-10-02 10:26:57 --> Database Driver Class Initialized
INFO - 2024-10-02 10:26:57 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-02 10:26:57 --> Controller Class Initialized
DEBUG - 2024-10-02 10:26:57 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/views/list.php
DEBUG - 2024-10-02 10:26:57 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-10-02 10:26:57 --> Final output sent to browser
DEBUG - 2024-10-02 10:26:57 --> Total execution time: 0.0294
INFO - 2024-10-02 10:26:57 --> Config Class Initialized
INFO - 2024-10-02 10:26:57 --> Hooks Class Initialized
DEBUG - 2024-10-02 10:26:57 --> UTF-8 Support Enabled
INFO - 2024-10-02 10:26:57 --> Utf8 Class Initialized
INFO - 2024-10-02 10:26:57 --> URI Class Initialized
INFO - 2024-10-02 10:26:57 --> Router Class Initialized
INFO - 2024-10-02 10:26:57 --> Output Class Initialized
INFO - 2024-10-02 10:26:57 --> Security Class Initialized
DEBUG - 2024-10-02 10:26:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-02 10:26:57 --> Input Class Initialized
INFO - 2024-10-02 10:26:57 --> Language Class Initialized
INFO - 2024-10-02 10:26:57 --> Language Class Initialized
INFO - 2024-10-02 10:26:57 --> Config Class Initialized
INFO - 2024-10-02 10:26:57 --> Loader Class Initialized
INFO - 2024-10-02 10:26:57 --> Helper loaded: url_helper
INFO - 2024-10-02 10:26:57 --> Helper loaded: file_helper
INFO - 2024-10-02 10:26:57 --> Helper loaded: form_helper
INFO - 2024-10-02 10:26:57 --> Helper loaded: my_helper
INFO - 2024-10-02 10:26:57 --> Database Driver Class Initialized
INFO - 2024-10-02 10:26:57 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-02 10:26:57 --> Controller Class Initialized
INFO - 2024-10-02 10:27:00 --> Config Class Initialized
INFO - 2024-10-02 10:27:00 --> Hooks Class Initialized
DEBUG - 2024-10-02 10:27:00 --> UTF-8 Support Enabled
INFO - 2024-10-02 10:27:00 --> Utf8 Class Initialized
INFO - 2024-10-02 10:27:00 --> URI Class Initialized
INFO - 2024-10-02 10:27:00 --> Router Class Initialized
INFO - 2024-10-02 10:27:00 --> Output Class Initialized
INFO - 2024-10-02 10:27:00 --> Security Class Initialized
DEBUG - 2024-10-02 10:27:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-02 10:27:00 --> Input Class Initialized
INFO - 2024-10-02 10:27:00 --> Language Class Initialized
INFO - 2024-10-02 10:27:00 --> Language Class Initialized
INFO - 2024-10-02 10:27:00 --> Config Class Initialized
INFO - 2024-10-02 10:27:00 --> Loader Class Initialized
INFO - 2024-10-02 10:27:00 --> Helper loaded: url_helper
INFO - 2024-10-02 10:27:00 --> Helper loaded: file_helper
INFO - 2024-10-02 10:27:00 --> Helper loaded: form_helper
INFO - 2024-10-02 10:27:00 --> Helper loaded: my_helper
INFO - 2024-10-02 10:27:00 --> Database Driver Class Initialized
INFO - 2024-10-02 10:27:00 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-02 10:27:00 --> Controller Class Initialized
DEBUG - 2024-10-02 10:27:00 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/list.php
DEBUG - 2024-10-02 10:27:00 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-10-02 10:27:00 --> Final output sent to browser
DEBUG - 2024-10-02 10:27:00 --> Total execution time: 0.0401
INFO - 2024-10-02 10:27:03 --> Config Class Initialized
INFO - 2024-10-02 10:27:03 --> Hooks Class Initialized
DEBUG - 2024-10-02 10:27:03 --> UTF-8 Support Enabled
INFO - 2024-10-02 10:27:03 --> Utf8 Class Initialized
INFO - 2024-10-02 10:27:03 --> URI Class Initialized
INFO - 2024-10-02 10:27:03 --> Router Class Initialized
INFO - 2024-10-02 10:27:03 --> Output Class Initialized
INFO - 2024-10-02 10:27:03 --> Security Class Initialized
DEBUG - 2024-10-02 10:27:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-02 10:27:03 --> Input Class Initialized
INFO - 2024-10-02 10:27:03 --> Language Class Initialized
INFO - 2024-10-02 10:27:03 --> Language Class Initialized
INFO - 2024-10-02 10:27:03 --> Config Class Initialized
INFO - 2024-10-02 10:27:03 --> Loader Class Initialized
INFO - 2024-10-02 10:27:03 --> Helper loaded: url_helper
INFO - 2024-10-02 10:27:03 --> Helper loaded: file_helper
INFO - 2024-10-02 10:27:03 --> Helper loaded: form_helper
INFO - 2024-10-02 10:27:03 --> Helper loaded: my_helper
INFO - 2024-10-02 10:27:03 --> Database Driver Class Initialized
INFO - 2024-10-02 10:27:03 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-02 10:27:03 --> Controller Class Initialized
ERROR - 2024-10-02 10:27:03 --> Severity: Notice --> Undefined offset: 15 /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1698
ERROR - 2024-10-02 10:27:03 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1698
ERROR - 2024-10-02 10:27:03 --> Severity: Warning --> Invalid argument supplied for foreach() /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1698
ERROR - 2024-10-02 10:27:03 --> Severity: Notice --> Undefined offset: 16 /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1735
ERROR - 2024-10-02 10:27:03 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1735
ERROR - 2024-10-02 10:27:03 --> Severity: Warning --> Invalid argument supplied for foreach() /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1735
ERROR - 2024-10-02 10:27:03 --> Severity: Notice --> Undefined offset: 17 /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1773
ERROR - 2024-10-02 10:27:03 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1773
ERROR - 2024-10-02 10:27:03 --> Severity: Warning --> Invalid argument supplied for foreach() /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1773
DEBUG - 2024-10-02 10:27:03 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php
INFO - 2024-10-02 10:27:05 --> Final output sent to browser
DEBUG - 2024-10-02 10:27:05 --> Total execution time: 2.5843
INFO - 2024-10-02 10:28:08 --> Config Class Initialized
INFO - 2024-10-02 10:28:08 --> Hooks Class Initialized
DEBUG - 2024-10-02 10:28:08 --> UTF-8 Support Enabled
INFO - 2024-10-02 10:28:08 --> Utf8 Class Initialized
INFO - 2024-10-02 10:28:08 --> URI Class Initialized
INFO - 2024-10-02 10:28:08 --> Router Class Initialized
INFO - 2024-10-02 10:28:08 --> Output Class Initialized
INFO - 2024-10-02 10:28:08 --> Security Class Initialized
DEBUG - 2024-10-02 10:28:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-02 10:28:08 --> Input Class Initialized
INFO - 2024-10-02 10:28:08 --> Language Class Initialized
INFO - 2024-10-02 10:28:08 --> Language Class Initialized
INFO - 2024-10-02 10:28:08 --> Config Class Initialized
INFO - 2024-10-02 10:28:08 --> Loader Class Initialized
INFO - 2024-10-02 10:28:08 --> Helper loaded: url_helper
INFO - 2024-10-02 10:28:08 --> Helper loaded: file_helper
INFO - 2024-10-02 10:28:08 --> Helper loaded: form_helper
INFO - 2024-10-02 10:28:08 --> Helper loaded: my_helper
INFO - 2024-10-02 10:28:08 --> Database Driver Class Initialized
INFO - 2024-10-02 10:28:08 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-02 10:28:08 --> Controller Class Initialized
DEBUG - 2024-10-02 10:28:08 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/view_mapel/views/v_view_mapel.php
DEBUG - 2024-10-02 10:28:08 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-10-02 10:28:08 --> Final output sent to browser
DEBUG - 2024-10-02 10:28:08 --> Total execution time: 0.0699
INFO - 2024-10-02 10:28:09 --> Config Class Initialized
INFO - 2024-10-02 10:28:09 --> Hooks Class Initialized
DEBUG - 2024-10-02 10:28:09 --> UTF-8 Support Enabled
INFO - 2024-10-02 10:28:09 --> Utf8 Class Initialized
INFO - 2024-10-02 10:28:09 --> URI Class Initialized
INFO - 2024-10-02 10:28:09 --> Router Class Initialized
INFO - 2024-10-02 10:28:09 --> Output Class Initialized
INFO - 2024-10-02 10:28:09 --> Security Class Initialized
DEBUG - 2024-10-02 10:28:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-02 10:28:09 --> Input Class Initialized
INFO - 2024-10-02 10:28:09 --> Language Class Initialized
INFO - 2024-10-02 10:28:09 --> Language Class Initialized
INFO - 2024-10-02 10:28:09 --> Config Class Initialized
INFO - 2024-10-02 10:28:09 --> Loader Class Initialized
INFO - 2024-10-02 10:28:09 --> Helper loaded: url_helper
INFO - 2024-10-02 10:28:09 --> Helper loaded: file_helper
INFO - 2024-10-02 10:28:09 --> Helper loaded: form_helper
INFO - 2024-10-02 10:28:09 --> Helper loaded: my_helper
INFO - 2024-10-02 10:28:09 --> Database Driver Class Initialized
INFO - 2024-10-02 10:28:09 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-02 10:28:09 --> Controller Class Initialized
DEBUG - 2024-10-02 10:28:09 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/views/list.php
DEBUG - 2024-10-02 10:28:09 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-10-02 10:28:09 --> Final output sent to browser
DEBUG - 2024-10-02 10:28:09 --> Total execution time: 0.0399
INFO - 2024-10-02 10:28:09 --> Config Class Initialized
INFO - 2024-10-02 10:28:09 --> Hooks Class Initialized
DEBUG - 2024-10-02 10:28:09 --> UTF-8 Support Enabled
INFO - 2024-10-02 10:28:09 --> Utf8 Class Initialized
INFO - 2024-10-02 10:28:09 --> URI Class Initialized
INFO - 2024-10-02 10:28:09 --> Router Class Initialized
INFO - 2024-10-02 10:28:09 --> Output Class Initialized
INFO - 2024-10-02 10:28:09 --> Security Class Initialized
DEBUG - 2024-10-02 10:28:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-02 10:28:09 --> Input Class Initialized
INFO - 2024-10-02 10:28:09 --> Language Class Initialized
INFO - 2024-10-02 10:28:09 --> Language Class Initialized
INFO - 2024-10-02 10:28:09 --> Config Class Initialized
INFO - 2024-10-02 10:28:09 --> Loader Class Initialized
INFO - 2024-10-02 10:28:09 --> Helper loaded: url_helper
INFO - 2024-10-02 10:28:09 --> Helper loaded: file_helper
INFO - 2024-10-02 10:28:09 --> Helper loaded: form_helper
INFO - 2024-10-02 10:28:09 --> Helper loaded: my_helper
INFO - 2024-10-02 10:28:09 --> Database Driver Class Initialized
INFO - 2024-10-02 10:28:09 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-02 10:28:09 --> Controller Class Initialized
INFO - 2024-10-02 10:28:10 --> Config Class Initialized
INFO - 2024-10-02 10:28:10 --> Hooks Class Initialized
DEBUG - 2024-10-02 10:28:11 --> UTF-8 Support Enabled
INFO - 2024-10-02 10:28:11 --> Utf8 Class Initialized
INFO - 2024-10-02 10:28:11 --> URI Class Initialized
INFO - 2024-10-02 10:28:11 --> Router Class Initialized
INFO - 2024-10-02 10:28:11 --> Output Class Initialized
INFO - 2024-10-02 10:28:11 --> Security Class Initialized
DEBUG - 2024-10-02 10:28:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-02 10:28:11 --> Input Class Initialized
INFO - 2024-10-02 10:28:11 --> Language Class Initialized
INFO - 2024-10-02 10:28:11 --> Language Class Initialized
INFO - 2024-10-02 10:28:11 --> Config Class Initialized
INFO - 2024-10-02 10:28:11 --> Loader Class Initialized
INFO - 2024-10-02 10:28:11 --> Helper loaded: url_helper
INFO - 2024-10-02 10:28:11 --> Helper loaded: file_helper
INFO - 2024-10-02 10:28:11 --> Helper loaded: form_helper
INFO - 2024-10-02 10:28:11 --> Helper loaded: my_helper
INFO - 2024-10-02 10:28:11 --> Database Driver Class Initialized
INFO - 2024-10-02 10:28:11 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-02 10:28:11 --> Controller Class Initialized
INFO - 2024-10-02 10:28:48 --> Config Class Initialized
INFO - 2024-10-02 10:28:48 --> Hooks Class Initialized
DEBUG - 2024-10-02 10:28:48 --> UTF-8 Support Enabled
INFO - 2024-10-02 10:28:48 --> Utf8 Class Initialized
INFO - 2024-10-02 10:28:48 --> URI Class Initialized
INFO - 2024-10-02 10:28:48 --> Router Class Initialized
INFO - 2024-10-02 10:28:48 --> Output Class Initialized
INFO - 2024-10-02 10:28:48 --> Security Class Initialized
DEBUG - 2024-10-02 10:28:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-02 10:28:48 --> Input Class Initialized
INFO - 2024-10-02 10:28:48 --> Language Class Initialized
INFO - 2024-10-02 10:28:48 --> Language Class Initialized
INFO - 2024-10-02 10:28:48 --> Config Class Initialized
INFO - 2024-10-02 10:28:48 --> Loader Class Initialized
INFO - 2024-10-02 10:28:48 --> Helper loaded: url_helper
INFO - 2024-10-02 10:28:48 --> Helper loaded: file_helper
INFO - 2024-10-02 10:28:48 --> Helper loaded: form_helper
INFO - 2024-10-02 10:28:48 --> Helper loaded: my_helper
INFO - 2024-10-02 10:28:48 --> Database Driver Class Initialized
INFO - 2024-10-02 10:28:48 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-02 10:28:48 --> Controller Class Initialized
INFO - 2024-10-02 10:30:28 --> Config Class Initialized
INFO - 2024-10-02 10:30:28 --> Hooks Class Initialized
DEBUG - 2024-10-02 10:30:28 --> UTF-8 Support Enabled
INFO - 2024-10-02 10:30:28 --> Utf8 Class Initialized
INFO - 2024-10-02 10:30:28 --> URI Class Initialized
INFO - 2024-10-02 10:30:28 --> Router Class Initialized
INFO - 2024-10-02 10:30:28 --> Output Class Initialized
INFO - 2024-10-02 10:30:28 --> Security Class Initialized
DEBUG - 2024-10-02 10:30:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-02 10:30:28 --> Input Class Initialized
INFO - 2024-10-02 10:30:28 --> Language Class Initialized
INFO - 2024-10-02 10:30:28 --> Language Class Initialized
INFO - 2024-10-02 10:30:28 --> Config Class Initialized
INFO - 2024-10-02 10:30:28 --> Loader Class Initialized
INFO - 2024-10-02 10:30:28 --> Helper loaded: url_helper
INFO - 2024-10-02 10:30:28 --> Helper loaded: file_helper
INFO - 2024-10-02 10:30:28 --> Helper loaded: form_helper
INFO - 2024-10-02 10:30:28 --> Helper loaded: my_helper
INFO - 2024-10-02 10:30:28 --> Database Driver Class Initialized
INFO - 2024-10-02 10:30:28 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-02 10:30:28 --> Controller Class Initialized
DEBUG - 2024-10-02 10:30:28 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/views/form.php
DEBUG - 2024-10-02 10:30:28 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-10-02 10:30:28 --> Final output sent to browser
DEBUG - 2024-10-02 10:30:28 --> Total execution time: 0.0479
INFO - 2024-10-02 10:30:33 --> Config Class Initialized
INFO - 2024-10-02 10:30:33 --> Hooks Class Initialized
DEBUG - 2024-10-02 10:30:33 --> UTF-8 Support Enabled
INFO - 2024-10-02 10:30:33 --> Utf8 Class Initialized
INFO - 2024-10-02 10:30:33 --> URI Class Initialized
INFO - 2024-10-02 10:30:33 --> Router Class Initialized
INFO - 2024-10-02 10:30:33 --> Output Class Initialized
INFO - 2024-10-02 10:30:33 --> Security Class Initialized
DEBUG - 2024-10-02 10:30:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-02 10:30:33 --> Input Class Initialized
INFO - 2024-10-02 10:30:33 --> Language Class Initialized
INFO - 2024-10-02 10:30:33 --> Language Class Initialized
INFO - 2024-10-02 10:30:33 --> Config Class Initialized
INFO - 2024-10-02 10:30:33 --> Loader Class Initialized
INFO - 2024-10-02 10:30:33 --> Helper loaded: url_helper
INFO - 2024-10-02 10:30:33 --> Helper loaded: file_helper
INFO - 2024-10-02 10:30:33 --> Helper loaded: form_helper
INFO - 2024-10-02 10:30:33 --> Helper loaded: my_helper
INFO - 2024-10-02 10:30:33 --> Database Driver Class Initialized
INFO - 2024-10-02 10:30:33 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-02 10:30:33 --> Controller Class Initialized
INFO - 2024-10-02 10:30:33 --> Config Class Initialized
INFO - 2024-10-02 10:30:33 --> Hooks Class Initialized
DEBUG - 2024-10-02 10:30:33 --> UTF-8 Support Enabled
INFO - 2024-10-02 10:30:33 --> Utf8 Class Initialized
INFO - 2024-10-02 10:30:33 --> URI Class Initialized
INFO - 2024-10-02 10:30:33 --> Router Class Initialized
INFO - 2024-10-02 10:30:33 --> Output Class Initialized
INFO - 2024-10-02 10:30:33 --> Security Class Initialized
DEBUG - 2024-10-02 10:30:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-02 10:30:33 --> Input Class Initialized
INFO - 2024-10-02 10:30:33 --> Language Class Initialized
INFO - 2024-10-02 10:30:33 --> Language Class Initialized
INFO - 2024-10-02 10:30:33 --> Config Class Initialized
INFO - 2024-10-02 10:30:33 --> Loader Class Initialized
INFO - 2024-10-02 10:30:33 --> Helper loaded: url_helper
INFO - 2024-10-02 10:30:33 --> Helper loaded: file_helper
INFO - 2024-10-02 10:30:33 --> Helper loaded: form_helper
INFO - 2024-10-02 10:30:33 --> Helper loaded: my_helper
INFO - 2024-10-02 10:30:33 --> Database Driver Class Initialized
INFO - 2024-10-02 10:30:33 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-02 10:30:33 --> Controller Class Initialized
DEBUG - 2024-10-02 10:30:33 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/views/list.php
DEBUG - 2024-10-02 10:30:33 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-10-02 10:30:33 --> Final output sent to browser
DEBUG - 2024-10-02 10:30:33 --> Total execution time: 0.0355
INFO - 2024-10-02 10:30:33 --> Config Class Initialized
INFO - 2024-10-02 10:30:33 --> Hooks Class Initialized
DEBUG - 2024-10-02 10:30:33 --> UTF-8 Support Enabled
INFO - 2024-10-02 10:30:33 --> Utf8 Class Initialized
INFO - 2024-10-02 10:30:33 --> URI Class Initialized
INFO - 2024-10-02 10:30:33 --> Router Class Initialized
INFO - 2024-10-02 10:30:33 --> Output Class Initialized
INFO - 2024-10-02 10:30:33 --> Security Class Initialized
DEBUG - 2024-10-02 10:30:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-02 10:30:33 --> Input Class Initialized
INFO - 2024-10-02 10:30:33 --> Language Class Initialized
INFO - 2024-10-02 10:30:33 --> Language Class Initialized
INFO - 2024-10-02 10:30:33 --> Config Class Initialized
INFO - 2024-10-02 10:30:33 --> Loader Class Initialized
INFO - 2024-10-02 10:30:33 --> Helper loaded: url_helper
INFO - 2024-10-02 10:30:33 --> Helper loaded: file_helper
INFO - 2024-10-02 10:30:33 --> Helper loaded: form_helper
INFO - 2024-10-02 10:30:33 --> Helper loaded: my_helper
INFO - 2024-10-02 10:30:33 --> Database Driver Class Initialized
INFO - 2024-10-02 10:30:33 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-02 10:30:33 --> Controller Class Initialized
INFO - 2024-10-02 10:30:38 --> Config Class Initialized
INFO - 2024-10-02 10:30:38 --> Hooks Class Initialized
DEBUG - 2024-10-02 10:30:38 --> UTF-8 Support Enabled
INFO - 2024-10-02 10:30:38 --> Utf8 Class Initialized
INFO - 2024-10-02 10:30:38 --> URI Class Initialized
INFO - 2024-10-02 10:30:38 --> Router Class Initialized
INFO - 2024-10-02 10:30:38 --> Output Class Initialized
INFO - 2024-10-02 10:30:38 --> Security Class Initialized
DEBUG - 2024-10-02 10:30:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-02 10:30:38 --> Input Class Initialized
INFO - 2024-10-02 10:30:38 --> Language Class Initialized
INFO - 2024-10-02 10:30:38 --> Language Class Initialized
INFO - 2024-10-02 10:30:38 --> Config Class Initialized
INFO - 2024-10-02 10:30:38 --> Loader Class Initialized
INFO - 2024-10-02 10:30:38 --> Helper loaded: url_helper
INFO - 2024-10-02 10:30:38 --> Helper loaded: file_helper
INFO - 2024-10-02 10:30:38 --> Helper loaded: form_helper
INFO - 2024-10-02 10:30:38 --> Helper loaded: my_helper
INFO - 2024-10-02 10:30:38 --> Database Driver Class Initialized
INFO - 2024-10-02 10:30:38 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-02 10:30:38 --> Controller Class Initialized
DEBUG - 2024-10-02 10:30:38 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/list.php
DEBUG - 2024-10-02 10:30:38 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-10-02 10:30:38 --> Final output sent to browser
DEBUG - 2024-10-02 10:30:38 --> Total execution time: 0.0346
INFO - 2024-10-02 10:30:40 --> Config Class Initialized
INFO - 2024-10-02 10:30:40 --> Hooks Class Initialized
DEBUG - 2024-10-02 10:30:40 --> UTF-8 Support Enabled
INFO - 2024-10-02 10:30:40 --> Utf8 Class Initialized
INFO - 2024-10-02 10:30:40 --> URI Class Initialized
INFO - 2024-10-02 10:30:40 --> Router Class Initialized
INFO - 2024-10-02 10:30:40 --> Output Class Initialized
INFO - 2024-10-02 10:30:40 --> Security Class Initialized
DEBUG - 2024-10-02 10:30:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-02 10:30:40 --> Input Class Initialized
INFO - 2024-10-02 10:30:40 --> Language Class Initialized
INFO - 2024-10-02 10:30:40 --> Language Class Initialized
INFO - 2024-10-02 10:30:40 --> Config Class Initialized
INFO - 2024-10-02 10:30:40 --> Loader Class Initialized
INFO - 2024-10-02 10:30:40 --> Helper loaded: url_helper
INFO - 2024-10-02 10:30:40 --> Helper loaded: file_helper
INFO - 2024-10-02 10:30:40 --> Helper loaded: form_helper
INFO - 2024-10-02 10:30:40 --> Helper loaded: my_helper
INFO - 2024-10-02 10:30:40 --> Database Driver Class Initialized
INFO - 2024-10-02 10:30:40 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-02 10:30:40 --> Controller Class Initialized
DEBUG - 2024-10-02 10:30:40 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/view_mapel/views/v_view_mapel.php
DEBUG - 2024-10-02 10:30:40 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-10-02 10:30:40 --> Final output sent to browser
DEBUG - 2024-10-02 10:30:40 --> Total execution time: 0.0291
INFO - 2024-10-02 10:30:41 --> Config Class Initialized
INFO - 2024-10-02 10:30:41 --> Hooks Class Initialized
DEBUG - 2024-10-02 10:30:41 --> UTF-8 Support Enabled
INFO - 2024-10-02 10:30:41 --> Utf8 Class Initialized
INFO - 2024-10-02 10:30:41 --> URI Class Initialized
INFO - 2024-10-02 10:30:41 --> Router Class Initialized
INFO - 2024-10-02 10:30:41 --> Output Class Initialized
INFO - 2024-10-02 10:30:41 --> Security Class Initialized
DEBUG - 2024-10-02 10:30:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-02 10:30:41 --> Input Class Initialized
INFO - 2024-10-02 10:30:41 --> Language Class Initialized
INFO - 2024-10-02 10:30:41 --> Language Class Initialized
INFO - 2024-10-02 10:30:41 --> Config Class Initialized
INFO - 2024-10-02 10:30:41 --> Loader Class Initialized
INFO - 2024-10-02 10:30:41 --> Helper loaded: url_helper
INFO - 2024-10-02 10:30:41 --> Helper loaded: file_helper
INFO - 2024-10-02 10:30:41 --> Helper loaded: form_helper
INFO - 2024-10-02 10:30:41 --> Helper loaded: my_helper
INFO - 2024-10-02 10:30:41 --> Database Driver Class Initialized
INFO - 2024-10-02 10:30:41 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-02 10:30:41 --> Controller Class Initialized
DEBUG - 2024-10-02 10:30:41 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/views/list.php
DEBUG - 2024-10-02 10:30:41 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-10-02 10:30:41 --> Final output sent to browser
DEBUG - 2024-10-02 10:30:41 --> Total execution time: 0.0340
INFO - 2024-10-02 10:30:42 --> Config Class Initialized
INFO - 2024-10-02 10:30:42 --> Hooks Class Initialized
DEBUG - 2024-10-02 10:30:42 --> UTF-8 Support Enabled
INFO - 2024-10-02 10:30:42 --> Utf8 Class Initialized
INFO - 2024-10-02 10:30:42 --> URI Class Initialized
INFO - 2024-10-02 10:30:42 --> Router Class Initialized
INFO - 2024-10-02 10:30:42 --> Output Class Initialized
INFO - 2024-10-02 10:30:42 --> Security Class Initialized
DEBUG - 2024-10-02 10:30:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-02 10:30:42 --> Input Class Initialized
INFO - 2024-10-02 10:30:42 --> Language Class Initialized
INFO - 2024-10-02 10:30:42 --> Language Class Initialized
INFO - 2024-10-02 10:30:42 --> Config Class Initialized
INFO - 2024-10-02 10:30:42 --> Loader Class Initialized
INFO - 2024-10-02 10:30:42 --> Helper loaded: url_helper
INFO - 2024-10-02 10:30:42 --> Helper loaded: file_helper
INFO - 2024-10-02 10:30:42 --> Helper loaded: form_helper
INFO - 2024-10-02 10:30:42 --> Helper loaded: my_helper
INFO - 2024-10-02 10:30:42 --> Database Driver Class Initialized
INFO - 2024-10-02 10:30:42 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-02 10:30:42 --> Controller Class Initialized
INFO - 2024-10-02 10:30:43 --> Config Class Initialized
INFO - 2024-10-02 10:30:43 --> Hooks Class Initialized
DEBUG - 2024-10-02 10:30:43 --> UTF-8 Support Enabled
INFO - 2024-10-02 10:30:43 --> Utf8 Class Initialized
INFO - 2024-10-02 10:30:43 --> URI Class Initialized
INFO - 2024-10-02 10:30:43 --> Router Class Initialized
INFO - 2024-10-02 10:30:43 --> Output Class Initialized
INFO - 2024-10-02 10:30:43 --> Security Class Initialized
DEBUG - 2024-10-02 10:30:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-02 10:30:43 --> Input Class Initialized
INFO - 2024-10-02 10:30:43 --> Language Class Initialized
INFO - 2024-10-02 10:30:43 --> Language Class Initialized
INFO - 2024-10-02 10:30:43 --> Config Class Initialized
INFO - 2024-10-02 10:30:43 --> Loader Class Initialized
INFO - 2024-10-02 10:30:43 --> Helper loaded: url_helper
INFO - 2024-10-02 10:30:43 --> Helper loaded: file_helper
INFO - 2024-10-02 10:30:43 --> Helper loaded: form_helper
INFO - 2024-10-02 10:30:43 --> Helper loaded: my_helper
INFO - 2024-10-02 10:30:43 --> Database Driver Class Initialized
INFO - 2024-10-02 10:30:43 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-02 10:30:43 --> Controller Class Initialized
INFO - 2024-10-02 10:30:43 --> Final output sent to browser
DEBUG - 2024-10-02 10:30:43 --> Total execution time: 0.0297
INFO - 2024-10-02 10:30:56 --> Config Class Initialized
INFO - 2024-10-02 10:30:56 --> Hooks Class Initialized
DEBUG - 2024-10-02 10:30:56 --> UTF-8 Support Enabled
INFO - 2024-10-02 10:30:56 --> Utf8 Class Initialized
INFO - 2024-10-02 10:30:56 --> URI Class Initialized
INFO - 2024-10-02 10:30:56 --> Router Class Initialized
INFO - 2024-10-02 10:30:56 --> Output Class Initialized
INFO - 2024-10-02 10:30:56 --> Security Class Initialized
DEBUG - 2024-10-02 10:30:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-02 10:30:56 --> Input Class Initialized
INFO - 2024-10-02 10:30:56 --> Language Class Initialized
INFO - 2024-10-02 10:30:56 --> Language Class Initialized
INFO - 2024-10-02 10:30:56 --> Config Class Initialized
INFO - 2024-10-02 10:30:56 --> Loader Class Initialized
INFO - 2024-10-02 10:30:56 --> Helper loaded: url_helper
INFO - 2024-10-02 10:30:56 --> Helper loaded: file_helper
INFO - 2024-10-02 10:30:56 --> Helper loaded: form_helper
INFO - 2024-10-02 10:30:56 --> Helper loaded: my_helper
INFO - 2024-10-02 10:30:56 --> Database Driver Class Initialized
INFO - 2024-10-02 10:30:56 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-02 10:30:56 --> Controller Class Initialized
DEBUG - 2024-10-02 10:30:56 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/view_mapel/views/v_view_mapel.php
DEBUG - 2024-10-02 10:30:56 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-10-02 10:30:56 --> Final output sent to browser
DEBUG - 2024-10-02 10:30:56 --> Total execution time: 0.0309
INFO - 2024-10-02 10:30:57 --> Config Class Initialized
INFO - 2024-10-02 10:30:57 --> Hooks Class Initialized
DEBUG - 2024-10-02 10:30:57 --> UTF-8 Support Enabled
INFO - 2024-10-02 10:30:57 --> Utf8 Class Initialized
INFO - 2024-10-02 10:30:57 --> URI Class Initialized
INFO - 2024-10-02 10:30:57 --> Router Class Initialized
INFO - 2024-10-02 10:30:57 --> Output Class Initialized
INFO - 2024-10-02 10:30:57 --> Security Class Initialized
DEBUG - 2024-10-02 10:30:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-02 10:30:57 --> Input Class Initialized
INFO - 2024-10-02 10:30:57 --> Language Class Initialized
INFO - 2024-10-02 10:30:57 --> Language Class Initialized
INFO - 2024-10-02 10:30:57 --> Config Class Initialized
INFO - 2024-10-02 10:30:57 --> Loader Class Initialized
INFO - 2024-10-02 10:30:57 --> Helper loaded: url_helper
INFO - 2024-10-02 10:30:57 --> Helper loaded: file_helper
INFO - 2024-10-02 10:30:57 --> Helper loaded: form_helper
INFO - 2024-10-02 10:30:57 --> Helper loaded: my_helper
INFO - 2024-10-02 10:30:57 --> Database Driver Class Initialized
INFO - 2024-10-02 10:30:57 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-02 10:30:57 --> Controller Class Initialized
DEBUG - 2024-10-02 10:30:57 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/views/list.php
DEBUG - 2024-10-02 10:30:57 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-10-02 10:30:57 --> Final output sent to browser
DEBUG - 2024-10-02 10:30:57 --> Total execution time: 0.0319
INFO - 2024-10-02 10:30:57 --> Config Class Initialized
INFO - 2024-10-02 10:30:57 --> Hooks Class Initialized
DEBUG - 2024-10-02 10:30:57 --> UTF-8 Support Enabled
INFO - 2024-10-02 10:30:57 --> Utf8 Class Initialized
INFO - 2024-10-02 10:30:57 --> URI Class Initialized
INFO - 2024-10-02 10:30:57 --> Router Class Initialized
INFO - 2024-10-02 10:30:57 --> Output Class Initialized
INFO - 2024-10-02 10:30:57 --> Security Class Initialized
DEBUG - 2024-10-02 10:30:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-02 10:30:57 --> Input Class Initialized
INFO - 2024-10-02 10:30:57 --> Language Class Initialized
INFO - 2024-10-02 10:30:57 --> Language Class Initialized
INFO - 2024-10-02 10:30:57 --> Config Class Initialized
INFO - 2024-10-02 10:30:57 --> Loader Class Initialized
INFO - 2024-10-02 10:30:57 --> Helper loaded: url_helper
INFO - 2024-10-02 10:30:57 --> Helper loaded: file_helper
INFO - 2024-10-02 10:30:57 --> Helper loaded: form_helper
INFO - 2024-10-02 10:30:57 --> Helper loaded: my_helper
INFO - 2024-10-02 10:30:57 --> Database Driver Class Initialized
INFO - 2024-10-02 10:30:57 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-02 10:30:57 --> Controller Class Initialized
INFO - 2024-10-02 10:32:35 --> Config Class Initialized
INFO - 2024-10-02 10:32:35 --> Hooks Class Initialized
DEBUG - 2024-10-02 10:32:35 --> UTF-8 Support Enabled
INFO - 2024-10-02 10:32:35 --> Utf8 Class Initialized
INFO - 2024-10-02 10:32:35 --> URI Class Initialized
INFO - 2024-10-02 10:32:35 --> Router Class Initialized
INFO - 2024-10-02 10:32:35 --> Output Class Initialized
INFO - 2024-10-02 10:32:35 --> Security Class Initialized
DEBUG - 2024-10-02 10:32:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-02 10:32:35 --> Input Class Initialized
INFO - 2024-10-02 10:32:35 --> Language Class Initialized
INFO - 2024-10-02 10:32:35 --> Language Class Initialized
INFO - 2024-10-02 10:32:35 --> Config Class Initialized
INFO - 2024-10-02 10:32:35 --> Loader Class Initialized
INFO - 2024-10-02 10:32:35 --> Helper loaded: url_helper
INFO - 2024-10-02 10:32:35 --> Helper loaded: file_helper
INFO - 2024-10-02 10:32:35 --> Helper loaded: form_helper
INFO - 2024-10-02 10:32:35 --> Helper loaded: my_helper
INFO - 2024-10-02 10:32:35 --> Database Driver Class Initialized
INFO - 2024-10-02 10:32:35 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-02 10:32:35 --> Controller Class Initialized
INFO - 2024-10-02 10:32:45 --> Config Class Initialized
INFO - 2024-10-02 10:32:45 --> Hooks Class Initialized
DEBUG - 2024-10-02 10:32:45 --> UTF-8 Support Enabled
INFO - 2024-10-02 10:32:45 --> Utf8 Class Initialized
INFO - 2024-10-02 10:32:45 --> URI Class Initialized
INFO - 2024-10-02 10:32:45 --> Router Class Initialized
INFO - 2024-10-02 10:32:45 --> Output Class Initialized
INFO - 2024-10-02 10:32:45 --> Security Class Initialized
DEBUG - 2024-10-02 10:32:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-02 10:32:45 --> Input Class Initialized
INFO - 2024-10-02 10:32:45 --> Language Class Initialized
INFO - 2024-10-02 10:32:45 --> Language Class Initialized
INFO - 2024-10-02 10:32:45 --> Config Class Initialized
INFO - 2024-10-02 10:32:45 --> Loader Class Initialized
INFO - 2024-10-02 10:32:45 --> Helper loaded: url_helper
INFO - 2024-10-02 10:32:45 --> Helper loaded: file_helper
INFO - 2024-10-02 10:32:45 --> Helper loaded: form_helper
INFO - 2024-10-02 10:32:45 --> Helper loaded: my_helper
INFO - 2024-10-02 10:32:45 --> Database Driver Class Initialized
INFO - 2024-10-02 10:32:45 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-02 10:32:45 --> Controller Class Initialized
DEBUG - 2024-10-02 10:32:45 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/views/list.php
DEBUG - 2024-10-02 10:32:45 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-10-02 10:32:45 --> Final output sent to browser
DEBUG - 2024-10-02 10:32:45 --> Total execution time: 0.0298
INFO - 2024-10-02 10:32:45 --> Config Class Initialized
INFO - 2024-10-02 10:32:45 --> Hooks Class Initialized
DEBUG - 2024-10-02 10:32:45 --> UTF-8 Support Enabled
INFO - 2024-10-02 10:32:45 --> Utf8 Class Initialized
INFO - 2024-10-02 10:32:45 --> URI Class Initialized
INFO - 2024-10-02 10:32:45 --> Router Class Initialized
INFO - 2024-10-02 10:32:45 --> Output Class Initialized
INFO - 2024-10-02 10:32:45 --> Security Class Initialized
DEBUG - 2024-10-02 10:32:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-02 10:32:45 --> Input Class Initialized
INFO - 2024-10-02 10:32:45 --> Language Class Initialized
INFO - 2024-10-02 10:32:45 --> Language Class Initialized
INFO - 2024-10-02 10:32:45 --> Config Class Initialized
INFO - 2024-10-02 10:32:45 --> Loader Class Initialized
INFO - 2024-10-02 10:32:45 --> Helper loaded: url_helper
INFO - 2024-10-02 10:32:45 --> Helper loaded: file_helper
INFO - 2024-10-02 10:32:45 --> Helper loaded: form_helper
INFO - 2024-10-02 10:32:45 --> Helper loaded: my_helper
INFO - 2024-10-02 10:32:45 --> Database Driver Class Initialized
INFO - 2024-10-02 10:32:45 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-02 10:32:45 --> Controller Class Initialized
INFO - 2024-10-02 10:32:46 --> Config Class Initialized
INFO - 2024-10-02 10:32:46 --> Hooks Class Initialized
DEBUG - 2024-10-02 10:32:46 --> UTF-8 Support Enabled
INFO - 2024-10-02 10:32:46 --> Utf8 Class Initialized
INFO - 2024-10-02 10:32:46 --> URI Class Initialized
INFO - 2024-10-02 10:32:46 --> Router Class Initialized
INFO - 2024-10-02 10:32:46 --> Output Class Initialized
INFO - 2024-10-02 10:32:46 --> Security Class Initialized
DEBUG - 2024-10-02 10:32:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-02 10:32:46 --> Input Class Initialized
INFO - 2024-10-02 10:32:46 --> Language Class Initialized
INFO - 2024-10-02 10:32:46 --> Language Class Initialized
INFO - 2024-10-02 10:32:46 --> Config Class Initialized
INFO - 2024-10-02 10:32:46 --> Loader Class Initialized
INFO - 2024-10-02 10:32:46 --> Helper loaded: url_helper
INFO - 2024-10-02 10:32:46 --> Helper loaded: file_helper
INFO - 2024-10-02 10:32:46 --> Helper loaded: form_helper
INFO - 2024-10-02 10:32:46 --> Helper loaded: my_helper
INFO - 2024-10-02 10:32:46 --> Database Driver Class Initialized
INFO - 2024-10-02 10:32:46 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-02 10:32:46 --> Controller Class Initialized
INFO - 2024-10-02 10:32:46 --> Final output sent to browser
DEBUG - 2024-10-02 10:32:46 --> Total execution time: 0.0278
INFO - 2024-10-02 10:32:55 --> Config Class Initialized
INFO - 2024-10-02 10:32:55 --> Hooks Class Initialized
DEBUG - 2024-10-02 10:32:55 --> UTF-8 Support Enabled
INFO - 2024-10-02 10:32:55 --> Utf8 Class Initialized
INFO - 2024-10-02 10:32:55 --> URI Class Initialized
INFO - 2024-10-02 10:32:55 --> Router Class Initialized
INFO - 2024-10-02 10:32:55 --> Output Class Initialized
INFO - 2024-10-02 10:32:55 --> Security Class Initialized
DEBUG - 2024-10-02 10:32:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-02 10:32:55 --> Input Class Initialized
INFO - 2024-10-02 10:32:55 --> Language Class Initialized
INFO - 2024-10-02 10:32:55 --> Language Class Initialized
INFO - 2024-10-02 10:32:55 --> Config Class Initialized
INFO - 2024-10-02 10:32:55 --> Loader Class Initialized
INFO - 2024-10-02 10:32:55 --> Helper loaded: url_helper
INFO - 2024-10-02 10:32:55 --> Helper loaded: file_helper
INFO - 2024-10-02 10:32:55 --> Helper loaded: form_helper
INFO - 2024-10-02 10:32:55 --> Helper loaded: my_helper
INFO - 2024-10-02 10:32:55 --> Database Driver Class Initialized
INFO - 2024-10-02 10:32:55 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-02 10:32:55 --> Controller Class Initialized
INFO - 2024-10-02 10:32:55 --> Final output sent to browser
DEBUG - 2024-10-02 10:32:55 --> Total execution time: 0.0390
INFO - 2024-10-02 10:32:55 --> Config Class Initialized
INFO - 2024-10-02 10:32:55 --> Hooks Class Initialized
DEBUG - 2024-10-02 10:32:55 --> UTF-8 Support Enabled
INFO - 2024-10-02 10:32:55 --> Utf8 Class Initialized
INFO - 2024-10-02 10:32:55 --> URI Class Initialized
INFO - 2024-10-02 10:32:55 --> Router Class Initialized
INFO - 2024-10-02 10:32:55 --> Output Class Initialized
INFO - 2024-10-02 10:32:55 --> Security Class Initialized
DEBUG - 2024-10-02 10:32:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-02 10:32:55 --> Input Class Initialized
INFO - 2024-10-02 10:32:55 --> Language Class Initialized
INFO - 2024-10-02 10:32:55 --> Language Class Initialized
INFO - 2024-10-02 10:32:55 --> Config Class Initialized
INFO - 2024-10-02 10:32:55 --> Loader Class Initialized
INFO - 2024-10-02 10:32:55 --> Helper loaded: url_helper
INFO - 2024-10-02 10:32:55 --> Helper loaded: file_helper
INFO - 2024-10-02 10:32:55 --> Helper loaded: form_helper
INFO - 2024-10-02 10:32:55 --> Helper loaded: my_helper
INFO - 2024-10-02 10:32:55 --> Database Driver Class Initialized
INFO - 2024-10-02 10:32:55 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-02 10:32:55 --> Controller Class Initialized
INFO - 2024-10-02 10:32:58 --> Config Class Initialized
INFO - 2024-10-02 10:32:58 --> Hooks Class Initialized
DEBUG - 2024-10-02 10:32:58 --> UTF-8 Support Enabled
INFO - 2024-10-02 10:32:58 --> Utf8 Class Initialized
INFO - 2024-10-02 10:32:58 --> URI Class Initialized
INFO - 2024-10-02 10:32:58 --> Router Class Initialized
INFO - 2024-10-02 10:32:58 --> Output Class Initialized
INFO - 2024-10-02 10:32:58 --> Security Class Initialized
DEBUG - 2024-10-02 10:32:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-02 10:32:58 --> Input Class Initialized
INFO - 2024-10-02 10:32:58 --> Language Class Initialized
INFO - 2024-10-02 10:32:58 --> Language Class Initialized
INFO - 2024-10-02 10:32:58 --> Config Class Initialized
INFO - 2024-10-02 10:32:58 --> Loader Class Initialized
INFO - 2024-10-02 10:32:58 --> Helper loaded: url_helper
INFO - 2024-10-02 10:32:58 --> Helper loaded: file_helper
INFO - 2024-10-02 10:32:58 --> Helper loaded: form_helper
INFO - 2024-10-02 10:32:58 --> Helper loaded: my_helper
INFO - 2024-10-02 10:32:58 --> Database Driver Class Initialized
INFO - 2024-10-02 10:32:58 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-02 10:32:58 --> Controller Class Initialized
INFO - 2024-10-02 10:34:18 --> Config Class Initialized
INFO - 2024-10-02 10:34:18 --> Hooks Class Initialized
DEBUG - 2024-10-02 10:34:18 --> UTF-8 Support Enabled
INFO - 2024-10-02 10:34:18 --> Utf8 Class Initialized
INFO - 2024-10-02 10:34:18 --> URI Class Initialized
INFO - 2024-10-02 10:34:18 --> Router Class Initialized
INFO - 2024-10-02 10:34:18 --> Output Class Initialized
INFO - 2024-10-02 10:34:18 --> Security Class Initialized
DEBUG - 2024-10-02 10:34:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-02 10:34:18 --> Input Class Initialized
INFO - 2024-10-02 10:34:18 --> Language Class Initialized
INFO - 2024-10-02 10:34:18 --> Language Class Initialized
INFO - 2024-10-02 10:34:18 --> Config Class Initialized
INFO - 2024-10-02 10:34:18 --> Loader Class Initialized
INFO - 2024-10-02 10:34:18 --> Helper loaded: url_helper
INFO - 2024-10-02 10:34:18 --> Helper loaded: file_helper
INFO - 2024-10-02 10:34:18 --> Helper loaded: form_helper
INFO - 2024-10-02 10:34:18 --> Helper loaded: my_helper
INFO - 2024-10-02 10:34:18 --> Database Driver Class Initialized
INFO - 2024-10-02 10:34:18 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-02 10:34:18 --> Controller Class Initialized
DEBUG - 2024-10-02 10:34:18 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/views/form.php
DEBUG - 2024-10-02 10:34:18 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-10-02 10:34:18 --> Final output sent to browser
DEBUG - 2024-10-02 10:34:18 --> Total execution time: 0.0304
INFO - 2024-10-02 10:34:23 --> Config Class Initialized
INFO - 2024-10-02 10:34:23 --> Hooks Class Initialized
DEBUG - 2024-10-02 10:34:23 --> UTF-8 Support Enabled
INFO - 2024-10-02 10:34:23 --> Utf8 Class Initialized
INFO - 2024-10-02 10:34:23 --> URI Class Initialized
INFO - 2024-10-02 10:34:23 --> Router Class Initialized
INFO - 2024-10-02 10:34:23 --> Output Class Initialized
INFO - 2024-10-02 10:34:23 --> Security Class Initialized
DEBUG - 2024-10-02 10:34:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-02 10:34:23 --> Input Class Initialized
INFO - 2024-10-02 10:34:23 --> Language Class Initialized
INFO - 2024-10-02 10:34:23 --> Language Class Initialized
INFO - 2024-10-02 10:34:23 --> Config Class Initialized
INFO - 2024-10-02 10:34:23 --> Loader Class Initialized
INFO - 2024-10-02 10:34:23 --> Helper loaded: url_helper
INFO - 2024-10-02 10:34:23 --> Helper loaded: file_helper
INFO - 2024-10-02 10:34:23 --> Helper loaded: form_helper
INFO - 2024-10-02 10:34:23 --> Helper loaded: my_helper
INFO - 2024-10-02 10:34:23 --> Database Driver Class Initialized
INFO - 2024-10-02 10:34:23 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-02 10:34:23 --> Controller Class Initialized
INFO - 2024-10-02 10:34:23 --> Config Class Initialized
INFO - 2024-10-02 10:34:23 --> Hooks Class Initialized
DEBUG - 2024-10-02 10:34:23 --> UTF-8 Support Enabled
INFO - 2024-10-02 10:34:23 --> Utf8 Class Initialized
INFO - 2024-10-02 10:34:23 --> URI Class Initialized
INFO - 2024-10-02 10:34:23 --> Router Class Initialized
INFO - 2024-10-02 10:34:23 --> Output Class Initialized
INFO - 2024-10-02 10:34:23 --> Security Class Initialized
DEBUG - 2024-10-02 10:34:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-02 10:34:23 --> Input Class Initialized
INFO - 2024-10-02 10:34:23 --> Language Class Initialized
INFO - 2024-10-02 10:34:23 --> Language Class Initialized
INFO - 2024-10-02 10:34:23 --> Config Class Initialized
INFO - 2024-10-02 10:34:23 --> Loader Class Initialized
INFO - 2024-10-02 10:34:23 --> Helper loaded: url_helper
INFO - 2024-10-02 10:34:23 --> Helper loaded: file_helper
INFO - 2024-10-02 10:34:23 --> Helper loaded: form_helper
INFO - 2024-10-02 10:34:23 --> Helper loaded: my_helper
INFO - 2024-10-02 10:34:23 --> Database Driver Class Initialized
INFO - 2024-10-02 10:34:23 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-02 10:34:23 --> Controller Class Initialized
DEBUG - 2024-10-02 10:34:23 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/views/list.php
DEBUG - 2024-10-02 10:34:23 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-10-02 10:34:23 --> Final output sent to browser
DEBUG - 2024-10-02 10:34:23 --> Total execution time: 0.0314
INFO - 2024-10-02 10:34:23 --> Config Class Initialized
INFO - 2024-10-02 10:34:23 --> Hooks Class Initialized
DEBUG - 2024-10-02 10:34:23 --> UTF-8 Support Enabled
INFO - 2024-10-02 10:34:23 --> Utf8 Class Initialized
INFO - 2024-10-02 10:34:23 --> URI Class Initialized
INFO - 2024-10-02 10:34:23 --> Router Class Initialized
INFO - 2024-10-02 10:34:23 --> Output Class Initialized
INFO - 2024-10-02 10:34:23 --> Security Class Initialized
DEBUG - 2024-10-02 10:34:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-02 10:34:23 --> Input Class Initialized
INFO - 2024-10-02 10:34:23 --> Language Class Initialized
INFO - 2024-10-02 10:34:23 --> Language Class Initialized
INFO - 2024-10-02 10:34:23 --> Config Class Initialized
INFO - 2024-10-02 10:34:23 --> Loader Class Initialized
INFO - 2024-10-02 10:34:23 --> Helper loaded: url_helper
INFO - 2024-10-02 10:34:23 --> Helper loaded: file_helper
INFO - 2024-10-02 10:34:23 --> Helper loaded: form_helper
INFO - 2024-10-02 10:34:23 --> Helper loaded: my_helper
INFO - 2024-10-02 10:34:23 --> Database Driver Class Initialized
INFO - 2024-10-02 10:34:23 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-02 10:34:23 --> Controller Class Initialized
INFO - 2024-10-02 10:56:48 --> Config Class Initialized
INFO - 2024-10-02 10:56:48 --> Hooks Class Initialized
DEBUG - 2024-10-02 10:56:48 --> UTF-8 Support Enabled
INFO - 2024-10-02 10:56:48 --> Utf8 Class Initialized
INFO - 2024-10-02 10:56:48 --> URI Class Initialized
INFO - 2024-10-02 10:56:48 --> Router Class Initialized
INFO - 2024-10-02 10:56:48 --> Output Class Initialized
INFO - 2024-10-02 10:56:48 --> Security Class Initialized
DEBUG - 2024-10-02 10:56:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-02 10:56:48 --> Input Class Initialized
INFO - 2024-10-02 10:56:48 --> Language Class Initialized
INFO - 2024-10-02 10:56:48 --> Language Class Initialized
INFO - 2024-10-02 10:56:48 --> Config Class Initialized
INFO - 2024-10-02 10:56:48 --> Loader Class Initialized
INFO - 2024-10-02 10:56:48 --> Helper loaded: url_helper
INFO - 2024-10-02 10:56:48 --> Helper loaded: file_helper
INFO - 2024-10-02 10:56:48 --> Helper loaded: form_helper
INFO - 2024-10-02 10:56:48 --> Helper loaded: my_helper
INFO - 2024-10-02 10:56:48 --> Database Driver Class Initialized
INFO - 2024-10-02 10:56:48 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-02 10:56:48 --> Controller Class Initialized
INFO - 2024-10-02 10:56:49 --> Final output sent to browser
DEBUG - 2024-10-02 10:56:49 --> Total execution time: 0.0690
INFO - 2024-10-02 10:56:52 --> Config Class Initialized
INFO - 2024-10-02 10:56:52 --> Hooks Class Initialized
DEBUG - 2024-10-02 10:56:52 --> UTF-8 Support Enabled
INFO - 2024-10-02 10:56:52 --> Utf8 Class Initialized
INFO - 2024-10-02 10:56:52 --> URI Class Initialized
INFO - 2024-10-02 10:56:52 --> Router Class Initialized
INFO - 2024-10-02 10:56:52 --> Output Class Initialized
INFO - 2024-10-02 10:56:52 --> Security Class Initialized
DEBUG - 2024-10-02 10:56:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-02 10:56:52 --> Input Class Initialized
INFO - 2024-10-02 10:56:52 --> Language Class Initialized
INFO - 2024-10-02 10:56:52 --> Language Class Initialized
INFO - 2024-10-02 10:56:52 --> Config Class Initialized
INFO - 2024-10-02 10:56:52 --> Loader Class Initialized
INFO - 2024-10-02 10:56:52 --> Helper loaded: url_helper
INFO - 2024-10-02 10:56:52 --> Helper loaded: file_helper
INFO - 2024-10-02 10:56:52 --> Helper loaded: form_helper
INFO - 2024-10-02 10:56:52 --> Helper loaded: my_helper
INFO - 2024-10-02 10:56:52 --> Database Driver Class Initialized
INFO - 2024-10-02 10:56:52 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-02 10:56:52 --> Controller Class Initialized
INFO - 2024-10-02 10:56:52 --> Final output sent to browser
DEBUG - 2024-10-02 10:56:52 --> Total execution time: 0.0315
INFO - 2024-10-02 11:05:36 --> Config Class Initialized
INFO - 2024-10-02 11:05:36 --> Hooks Class Initialized
DEBUG - 2024-10-02 11:05:36 --> UTF-8 Support Enabled
INFO - 2024-10-02 11:05:36 --> Utf8 Class Initialized
INFO - 2024-10-02 11:05:36 --> URI Class Initialized
INFO - 2024-10-02 11:05:36 --> Router Class Initialized
INFO - 2024-10-02 11:05:36 --> Output Class Initialized
INFO - 2024-10-02 11:05:36 --> Security Class Initialized
DEBUG - 2024-10-02 11:05:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-02 11:05:36 --> Input Class Initialized
INFO - 2024-10-02 11:05:36 --> Language Class Initialized
INFO - 2024-10-02 11:05:36 --> Language Class Initialized
INFO - 2024-10-02 11:05:36 --> Config Class Initialized
INFO - 2024-10-02 11:05:36 --> Loader Class Initialized
INFO - 2024-10-02 11:05:36 --> Helper loaded: url_helper
INFO - 2024-10-02 11:05:36 --> Helper loaded: file_helper
INFO - 2024-10-02 11:05:36 --> Helper loaded: form_helper
INFO - 2024-10-02 11:05:36 --> Helper loaded: my_helper
INFO - 2024-10-02 11:05:36 --> Database Driver Class Initialized
INFO - 2024-10-02 11:05:36 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-02 11:05:36 --> Controller Class Initialized
INFO - 2024-10-02 11:05:36 --> Helper loaded: cookie_helper
INFO - 2024-10-02 11:05:36 --> Final output sent to browser
DEBUG - 2024-10-02 11:05:36 --> Total execution time: 0.0296
INFO - 2024-10-02 11:05:37 --> Config Class Initialized
INFO - 2024-10-02 11:05:37 --> Hooks Class Initialized
DEBUG - 2024-10-02 11:05:37 --> UTF-8 Support Enabled
INFO - 2024-10-02 11:05:37 --> Utf8 Class Initialized
INFO - 2024-10-02 11:05:37 --> URI Class Initialized
INFO - 2024-10-02 11:05:37 --> Router Class Initialized
INFO - 2024-10-02 11:05:37 --> Output Class Initialized
INFO - 2024-10-02 11:05:37 --> Security Class Initialized
DEBUG - 2024-10-02 11:05:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-02 11:05:37 --> Input Class Initialized
INFO - 2024-10-02 11:05:37 --> Language Class Initialized
INFO - 2024-10-02 11:05:37 --> Language Class Initialized
INFO - 2024-10-02 11:05:37 --> Config Class Initialized
INFO - 2024-10-02 11:05:37 --> Loader Class Initialized
INFO - 2024-10-02 11:05:37 --> Helper loaded: url_helper
INFO - 2024-10-02 11:05:37 --> Helper loaded: file_helper
INFO - 2024-10-02 11:05:37 --> Helper loaded: form_helper
INFO - 2024-10-02 11:05:37 --> Helper loaded: my_helper
INFO - 2024-10-02 11:05:37 --> Database Driver Class Initialized
INFO - 2024-10-02 11:05:37 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-02 11:05:37 --> Controller Class Initialized
INFO - 2024-10-02 11:05:37 --> Helper loaded: cookie_helper
INFO - 2024-10-02 11:05:37 --> Config Class Initialized
INFO - 2024-10-02 11:05:37 --> Hooks Class Initialized
DEBUG - 2024-10-02 11:05:37 --> UTF-8 Support Enabled
INFO - 2024-10-02 11:05:37 --> Utf8 Class Initialized
INFO - 2024-10-02 11:05:37 --> URI Class Initialized
INFO - 2024-10-02 11:05:37 --> Router Class Initialized
INFO - 2024-10-02 11:05:37 --> Output Class Initialized
INFO - 2024-10-02 11:05:37 --> Security Class Initialized
DEBUG - 2024-10-02 11:05:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-02 11:05:37 --> Input Class Initialized
INFO - 2024-10-02 11:05:37 --> Language Class Initialized
INFO - 2024-10-02 11:05:37 --> Language Class Initialized
INFO - 2024-10-02 11:05:37 --> Config Class Initialized
INFO - 2024-10-02 11:05:37 --> Loader Class Initialized
INFO - 2024-10-02 11:05:37 --> Helper loaded: url_helper
INFO - 2024-10-02 11:05:37 --> Helper loaded: file_helper
INFO - 2024-10-02 11:05:37 --> Helper loaded: form_helper
INFO - 2024-10-02 11:05:37 --> Helper loaded: my_helper
INFO - 2024-10-02 11:05:37 --> Database Driver Class Initialized
INFO - 2024-10-02 11:05:37 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-02 11:05:37 --> Controller Class Initialized
DEBUG - 2024-10-02 11:05:37 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/lihat_raport/views/list.php
DEBUG - 2024-10-02 11:05:37 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-10-02 11:05:37 --> Final output sent to browser
DEBUG - 2024-10-02 11:05:37 --> Total execution time: 0.0302
INFO - 2024-10-02 11:05:47 --> Config Class Initialized
INFO - 2024-10-02 11:05:47 --> Hooks Class Initialized
DEBUG - 2024-10-02 11:05:47 --> UTF-8 Support Enabled
INFO - 2024-10-02 11:05:47 --> Utf8 Class Initialized
INFO - 2024-10-02 11:05:47 --> URI Class Initialized
INFO - 2024-10-02 11:05:47 --> Router Class Initialized
INFO - 2024-10-02 11:05:47 --> Output Class Initialized
INFO - 2024-10-02 11:05:47 --> Security Class Initialized
DEBUG - 2024-10-02 11:05:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-02 11:05:47 --> Input Class Initialized
INFO - 2024-10-02 11:05:47 --> Language Class Initialized
INFO - 2024-10-02 11:05:47 --> Language Class Initialized
INFO - 2024-10-02 11:05:47 --> Config Class Initialized
INFO - 2024-10-02 11:05:47 --> Loader Class Initialized
INFO - 2024-10-02 11:05:47 --> Helper loaded: url_helper
INFO - 2024-10-02 11:05:47 --> Helper loaded: file_helper
INFO - 2024-10-02 11:05:47 --> Helper loaded: form_helper
INFO - 2024-10-02 11:05:47 --> Helper loaded: my_helper
INFO - 2024-10-02 11:05:47 --> Database Driver Class Initialized
INFO - 2024-10-02 11:05:47 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-02 11:05:47 --> Controller Class Initialized
ERROR - 2024-10-02 11:05:47 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1160
ERROR - 2024-10-02 11:05:47 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1692
ERROR - 2024-10-02 11:05:47 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1729
ERROR - 2024-10-02 11:05:47 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1767
ERROR - 2024-10-02 11:05:47 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1806
ERROR - 2024-10-02 11:05:47 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1883
ERROR - 2024-10-02 11:05:47 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1962
ERROR - 2024-10-02 11:05:47 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 2042
ERROR - 2024-10-02 11:05:47 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 2122
ERROR - 2024-10-02 11:05:47 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 2202
ERROR - 2024-10-02 11:05:47 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 2277
ERROR - 2024-10-02 11:05:47 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php 32
ERROR - 2024-10-02 11:05:47 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php 32
DEBUG - 2024-10-02 11:05:47 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php
INFO - 2024-10-02 11:05:49 --> Final output sent to browser
DEBUG - 2024-10-02 11:05:49 --> Total execution time: 2.5271
INFO - 2024-10-02 11:17:32 --> Config Class Initialized
INFO - 2024-10-02 11:17:32 --> Hooks Class Initialized
DEBUG - 2024-10-02 11:17:32 --> UTF-8 Support Enabled
INFO - 2024-10-02 11:17:32 --> Utf8 Class Initialized
INFO - 2024-10-02 11:17:32 --> URI Class Initialized
INFO - 2024-10-02 11:17:32 --> Router Class Initialized
INFO - 2024-10-02 11:17:32 --> Output Class Initialized
INFO - 2024-10-02 11:17:32 --> Security Class Initialized
DEBUG - 2024-10-02 11:17:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-02 11:17:32 --> Input Class Initialized
INFO - 2024-10-02 11:17:32 --> Language Class Initialized
INFO - 2024-10-02 11:17:32 --> Language Class Initialized
INFO - 2024-10-02 11:17:32 --> Config Class Initialized
INFO - 2024-10-02 11:17:32 --> Loader Class Initialized
INFO - 2024-10-02 11:17:32 --> Helper loaded: url_helper
INFO - 2024-10-02 11:17:32 --> Helper loaded: file_helper
INFO - 2024-10-02 11:17:32 --> Helper loaded: form_helper
INFO - 2024-10-02 11:17:32 --> Helper loaded: my_helper
INFO - 2024-10-02 11:17:32 --> Database Driver Class Initialized
INFO - 2024-10-02 11:17:32 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-02 11:17:32 --> Controller Class Initialized
INFO - 2024-10-02 11:17:32 --> Config Class Initialized
INFO - 2024-10-02 11:17:32 --> Hooks Class Initialized
DEBUG - 2024-10-02 11:17:32 --> UTF-8 Support Enabled
INFO - 2024-10-02 11:17:32 --> Utf8 Class Initialized
INFO - 2024-10-02 11:17:32 --> URI Class Initialized
INFO - 2024-10-02 11:17:32 --> Router Class Initialized
INFO - 2024-10-02 11:17:32 --> Output Class Initialized
INFO - 2024-10-02 11:17:32 --> Security Class Initialized
DEBUG - 2024-10-02 11:17:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-02 11:17:32 --> Input Class Initialized
INFO - 2024-10-02 11:17:32 --> Language Class Initialized
INFO - 2024-10-02 11:17:32 --> Language Class Initialized
INFO - 2024-10-02 11:17:32 --> Config Class Initialized
INFO - 2024-10-02 11:17:32 --> Loader Class Initialized
INFO - 2024-10-02 11:17:32 --> Helper loaded: url_helper
INFO - 2024-10-02 11:17:32 --> Helper loaded: file_helper
INFO - 2024-10-02 11:17:32 --> Helper loaded: form_helper
INFO - 2024-10-02 11:17:32 --> Helper loaded: my_helper
INFO - 2024-10-02 11:17:32 --> Database Driver Class Initialized
INFO - 2024-10-02 11:17:32 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-02 11:17:32 --> Controller Class Initialized
DEBUG - 2024-10-02 11:17:32 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/login/views/login.php
DEBUG - 2024-10-02 11:17:32 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-10-02 11:17:32 --> Final output sent to browser
DEBUG - 2024-10-02 11:17:32 --> Total execution time: 0.0287
INFO - 2024-10-02 13:45:35 --> Config Class Initialized
INFO - 2024-10-02 13:45:35 --> Hooks Class Initialized
DEBUG - 2024-10-02 13:45:35 --> UTF-8 Support Enabled
INFO - 2024-10-02 13:45:35 --> Utf8 Class Initialized
INFO - 2024-10-02 13:45:35 --> URI Class Initialized
INFO - 2024-10-02 13:45:35 --> Router Class Initialized
INFO - 2024-10-02 13:45:35 --> Output Class Initialized
INFO - 2024-10-02 13:45:35 --> Security Class Initialized
DEBUG - 2024-10-02 13:45:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-02 13:45:35 --> Input Class Initialized
INFO - 2024-10-02 13:45:35 --> Language Class Initialized
INFO - 2024-10-02 13:45:35 --> Language Class Initialized
INFO - 2024-10-02 13:45:35 --> Config Class Initialized
INFO - 2024-10-02 13:45:35 --> Loader Class Initialized
INFO - 2024-10-02 13:45:35 --> Helper loaded: url_helper
INFO - 2024-10-02 13:45:35 --> Helper loaded: file_helper
INFO - 2024-10-02 13:45:35 --> Helper loaded: form_helper
INFO - 2024-10-02 13:45:35 --> Helper loaded: my_helper
INFO - 2024-10-02 13:45:35 --> Database Driver Class Initialized
INFO - 2024-10-02 13:45:35 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-02 13:45:35 --> Controller Class Initialized
INFO - 2024-10-02 13:45:35 --> Helper loaded: cookie_helper
INFO - 2024-10-02 13:45:35 --> Final output sent to browser
DEBUG - 2024-10-02 13:45:35 --> Total execution time: 0.0581
INFO - 2024-10-02 13:45:35 --> Config Class Initialized
INFO - 2024-10-02 13:45:35 --> Hooks Class Initialized
DEBUG - 2024-10-02 13:45:35 --> UTF-8 Support Enabled
INFO - 2024-10-02 13:45:35 --> Utf8 Class Initialized
INFO - 2024-10-02 13:45:35 --> URI Class Initialized
INFO - 2024-10-02 13:45:35 --> Router Class Initialized
INFO - 2024-10-02 13:45:35 --> Output Class Initialized
INFO - 2024-10-02 13:45:35 --> Security Class Initialized
DEBUG - 2024-10-02 13:45:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-02 13:45:35 --> Input Class Initialized
INFO - 2024-10-02 13:45:35 --> Language Class Initialized
INFO - 2024-10-02 13:45:35 --> Language Class Initialized
INFO - 2024-10-02 13:45:35 --> Config Class Initialized
INFO - 2024-10-02 13:45:35 --> Loader Class Initialized
INFO - 2024-10-02 13:45:35 --> Helper loaded: url_helper
INFO - 2024-10-02 13:45:35 --> Helper loaded: file_helper
INFO - 2024-10-02 13:45:35 --> Helper loaded: form_helper
INFO - 2024-10-02 13:45:35 --> Helper loaded: my_helper
INFO - 2024-10-02 13:45:35 --> Database Driver Class Initialized
INFO - 2024-10-02 13:45:35 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-02 13:45:35 --> Controller Class Initialized
DEBUG - 2024-10-02 13:45:35 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/home/views/v_home_guru.php
DEBUG - 2024-10-02 13:45:35 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-10-02 13:45:35 --> Final output sent to browser
DEBUG - 2024-10-02 13:45:35 --> Total execution time: 0.0425
INFO - 2024-10-02 13:45:38 --> Config Class Initialized
INFO - 2024-10-02 13:45:38 --> Hooks Class Initialized
DEBUG - 2024-10-02 13:45:38 --> UTF-8 Support Enabled
INFO - 2024-10-02 13:45:38 --> Utf8 Class Initialized
INFO - 2024-10-02 13:45:38 --> URI Class Initialized
INFO - 2024-10-02 13:45:38 --> Router Class Initialized
INFO - 2024-10-02 13:45:38 --> Output Class Initialized
INFO - 2024-10-02 13:45:38 --> Security Class Initialized
DEBUG - 2024-10-02 13:45:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-02 13:45:38 --> Input Class Initialized
INFO - 2024-10-02 13:45:38 --> Language Class Initialized
INFO - 2024-10-02 13:45:38 --> Language Class Initialized
INFO - 2024-10-02 13:45:38 --> Config Class Initialized
INFO - 2024-10-02 13:45:38 --> Loader Class Initialized
INFO - 2024-10-02 13:45:38 --> Helper loaded: url_helper
INFO - 2024-10-02 13:45:38 --> Helper loaded: file_helper
INFO - 2024-10-02 13:45:38 --> Helper loaded: form_helper
INFO - 2024-10-02 13:45:38 --> Helper loaded: my_helper
INFO - 2024-10-02 13:45:38 --> Database Driver Class Initialized
INFO - 2024-10-02 13:45:38 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-02 13:45:38 --> Controller Class Initialized
DEBUG - 2024-10-02 13:45:38 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/view_mapel/views/v_view_mapel.php
DEBUG - 2024-10-02 13:45:38 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-10-02 13:45:38 --> Final output sent to browser
DEBUG - 2024-10-02 13:45:38 --> Total execution time: 0.0327
INFO - 2024-10-02 13:45:43 --> Config Class Initialized
INFO - 2024-10-02 13:45:43 --> Hooks Class Initialized
DEBUG - 2024-10-02 13:45:43 --> UTF-8 Support Enabled
INFO - 2024-10-02 13:45:43 --> Utf8 Class Initialized
INFO - 2024-10-02 13:45:43 --> URI Class Initialized
INFO - 2024-10-02 13:45:43 --> Router Class Initialized
INFO - 2024-10-02 13:45:43 --> Output Class Initialized
INFO - 2024-10-02 13:45:43 --> Security Class Initialized
DEBUG - 2024-10-02 13:45:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-02 13:45:43 --> Input Class Initialized
INFO - 2024-10-02 13:45:43 --> Language Class Initialized
INFO - 2024-10-02 13:45:43 --> Language Class Initialized
INFO - 2024-10-02 13:45:43 --> Config Class Initialized
INFO - 2024-10-02 13:45:43 --> Loader Class Initialized
INFO - 2024-10-02 13:45:43 --> Helper loaded: url_helper
INFO - 2024-10-02 13:45:43 --> Helper loaded: file_helper
INFO - 2024-10-02 13:45:43 --> Helper loaded: form_helper
INFO - 2024-10-02 13:45:43 --> Helper loaded: my_helper
INFO - 2024-10-02 13:45:43 --> Database Driver Class Initialized
INFO - 2024-10-02 13:45:43 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-02 13:45:43 --> Controller Class Initialized
DEBUG - 2024-10-02 13:45:43 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/views/list.php
DEBUG - 2024-10-02 13:45:43 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-10-02 13:45:43 --> Final output sent to browser
DEBUG - 2024-10-02 13:45:43 --> Total execution time: 0.0398
INFO - 2024-10-02 13:45:43 --> Config Class Initialized
INFO - 2024-10-02 13:45:43 --> Hooks Class Initialized
DEBUG - 2024-10-02 13:45:43 --> UTF-8 Support Enabled
INFO - 2024-10-02 13:45:43 --> Utf8 Class Initialized
INFO - 2024-10-02 13:45:43 --> URI Class Initialized
INFO - 2024-10-02 13:45:43 --> Router Class Initialized
INFO - 2024-10-02 13:45:43 --> Output Class Initialized
INFO - 2024-10-02 13:45:43 --> Security Class Initialized
DEBUG - 2024-10-02 13:45:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-02 13:45:43 --> Input Class Initialized
INFO - 2024-10-02 13:45:43 --> Language Class Initialized
INFO - 2024-10-02 13:45:43 --> Language Class Initialized
INFO - 2024-10-02 13:45:43 --> Config Class Initialized
INFO - 2024-10-02 13:45:43 --> Loader Class Initialized
INFO - 2024-10-02 13:45:43 --> Helper loaded: url_helper
INFO - 2024-10-02 13:45:43 --> Helper loaded: file_helper
INFO - 2024-10-02 13:45:43 --> Helper loaded: form_helper
INFO - 2024-10-02 13:45:43 --> Helper loaded: my_helper
INFO - 2024-10-02 13:45:43 --> Database Driver Class Initialized
INFO - 2024-10-02 13:45:43 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-02 13:45:43 --> Controller Class Initialized
INFO - 2024-10-02 13:46:35 --> Config Class Initialized
INFO - 2024-10-02 13:46:35 --> Hooks Class Initialized
DEBUG - 2024-10-02 13:46:35 --> UTF-8 Support Enabled
INFO - 2024-10-02 13:46:35 --> Utf8 Class Initialized
INFO - 2024-10-02 13:46:35 --> URI Class Initialized
INFO - 2024-10-02 13:46:35 --> Router Class Initialized
INFO - 2024-10-02 13:46:35 --> Output Class Initialized
INFO - 2024-10-02 13:46:35 --> Security Class Initialized
DEBUG - 2024-10-02 13:46:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-02 13:46:35 --> Input Class Initialized
INFO - 2024-10-02 13:46:35 --> Language Class Initialized
INFO - 2024-10-02 13:46:35 --> Language Class Initialized
INFO - 2024-10-02 13:46:35 --> Config Class Initialized
INFO - 2024-10-02 13:46:35 --> Loader Class Initialized
INFO - 2024-10-02 13:46:35 --> Helper loaded: url_helper
INFO - 2024-10-02 13:46:35 --> Helper loaded: file_helper
INFO - 2024-10-02 13:46:35 --> Helper loaded: form_helper
INFO - 2024-10-02 13:46:35 --> Helper loaded: my_helper
INFO - 2024-10-02 13:46:35 --> Database Driver Class Initialized
INFO - 2024-10-02 13:46:35 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-02 13:46:35 --> Controller Class Initialized
INFO - 2024-10-02 13:46:35 --> Final output sent to browser
DEBUG - 2024-10-02 13:46:35 --> Total execution time: 0.0345
INFO - 2024-10-02 13:49:13 --> Config Class Initialized
INFO - 2024-10-02 13:49:13 --> Hooks Class Initialized
DEBUG - 2024-10-02 13:49:13 --> UTF-8 Support Enabled
INFO - 2024-10-02 13:49:13 --> Utf8 Class Initialized
INFO - 2024-10-02 13:49:13 --> URI Class Initialized
INFO - 2024-10-02 13:49:13 --> Router Class Initialized
INFO - 2024-10-02 13:49:13 --> Output Class Initialized
INFO - 2024-10-02 13:49:13 --> Security Class Initialized
DEBUG - 2024-10-02 13:49:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-02 13:49:13 --> Input Class Initialized
INFO - 2024-10-02 13:49:13 --> Language Class Initialized
INFO - 2024-10-02 13:49:13 --> Language Class Initialized
INFO - 2024-10-02 13:49:13 --> Config Class Initialized
INFO - 2024-10-02 13:49:13 --> Loader Class Initialized
INFO - 2024-10-02 13:49:13 --> Helper loaded: url_helper
INFO - 2024-10-02 13:49:13 --> Helper loaded: file_helper
INFO - 2024-10-02 13:49:13 --> Helper loaded: form_helper
INFO - 2024-10-02 13:49:13 --> Helper loaded: my_helper
INFO - 2024-10-02 13:49:13 --> Database Driver Class Initialized
INFO - 2024-10-02 13:49:13 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-02 13:49:13 --> Controller Class Initialized
INFO - 2024-10-02 13:49:13 --> Final output sent to browser
DEBUG - 2024-10-02 13:49:13 --> Total execution time: 0.1095
INFO - 2024-10-02 13:49:24 --> Config Class Initialized
INFO - 2024-10-02 13:49:24 --> Hooks Class Initialized
DEBUG - 2024-10-02 13:49:24 --> UTF-8 Support Enabled
INFO - 2024-10-02 13:49:24 --> Utf8 Class Initialized
INFO - 2024-10-02 13:49:24 --> URI Class Initialized
INFO - 2024-10-02 13:49:24 --> Router Class Initialized
INFO - 2024-10-02 13:49:24 --> Output Class Initialized
INFO - 2024-10-02 13:49:24 --> Security Class Initialized
DEBUG - 2024-10-02 13:49:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-02 13:49:24 --> Input Class Initialized
INFO - 2024-10-02 13:49:24 --> Language Class Initialized
INFO - 2024-10-02 13:49:24 --> Language Class Initialized
INFO - 2024-10-02 13:49:24 --> Config Class Initialized
INFO - 2024-10-02 13:49:24 --> Loader Class Initialized
INFO - 2024-10-02 13:49:24 --> Helper loaded: url_helper
INFO - 2024-10-02 13:49:24 --> Helper loaded: file_helper
INFO - 2024-10-02 13:49:24 --> Helper loaded: form_helper
INFO - 2024-10-02 13:49:24 --> Helper loaded: my_helper
INFO - 2024-10-02 13:49:24 --> Database Driver Class Initialized
INFO - 2024-10-02 13:49:24 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-02 13:49:24 --> Controller Class Initialized
INFO - 2024-10-02 13:49:24 --> Final output sent to browser
DEBUG - 2024-10-02 13:49:24 --> Total execution time: 0.0329
INFO - 2024-10-02 13:49:35 --> Config Class Initialized
INFO - 2024-10-02 13:49:35 --> Hooks Class Initialized
DEBUG - 2024-10-02 13:49:35 --> UTF-8 Support Enabled
INFO - 2024-10-02 13:49:35 --> Utf8 Class Initialized
INFO - 2024-10-02 13:49:35 --> URI Class Initialized
INFO - 2024-10-02 13:49:35 --> Router Class Initialized
INFO - 2024-10-02 13:49:35 --> Output Class Initialized
INFO - 2024-10-02 13:49:35 --> Security Class Initialized
DEBUG - 2024-10-02 13:49:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-02 13:49:35 --> Input Class Initialized
INFO - 2024-10-02 13:49:35 --> Language Class Initialized
INFO - 2024-10-02 13:49:35 --> Language Class Initialized
INFO - 2024-10-02 13:49:35 --> Config Class Initialized
INFO - 2024-10-02 13:49:35 --> Loader Class Initialized
INFO - 2024-10-02 13:49:35 --> Helper loaded: url_helper
INFO - 2024-10-02 13:49:35 --> Helper loaded: file_helper
INFO - 2024-10-02 13:49:35 --> Helper loaded: form_helper
INFO - 2024-10-02 13:49:35 --> Helper loaded: my_helper
INFO - 2024-10-02 13:49:35 --> Database Driver Class Initialized
INFO - 2024-10-02 13:49:35 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-02 13:49:35 --> Controller Class Initialized
INFO - 2024-10-02 13:49:35 --> Final output sent to browser
DEBUG - 2024-10-02 13:49:35 --> Total execution time: 0.0357
INFO - 2024-10-02 13:50:05 --> Config Class Initialized
INFO - 2024-10-02 13:50:05 --> Hooks Class Initialized
DEBUG - 2024-10-02 13:50:05 --> UTF-8 Support Enabled
INFO - 2024-10-02 13:50:05 --> Utf8 Class Initialized
INFO - 2024-10-02 13:50:05 --> URI Class Initialized
INFO - 2024-10-02 13:50:05 --> Router Class Initialized
INFO - 2024-10-02 13:50:05 --> Output Class Initialized
INFO - 2024-10-02 13:50:05 --> Security Class Initialized
DEBUG - 2024-10-02 13:50:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-02 13:50:05 --> Input Class Initialized
INFO - 2024-10-02 13:50:05 --> Language Class Initialized
INFO - 2024-10-02 13:50:05 --> Language Class Initialized
INFO - 2024-10-02 13:50:05 --> Config Class Initialized
INFO - 2024-10-02 13:50:05 --> Loader Class Initialized
INFO - 2024-10-02 13:50:05 --> Helper loaded: url_helper
INFO - 2024-10-02 13:50:05 --> Helper loaded: file_helper
INFO - 2024-10-02 13:50:05 --> Helper loaded: form_helper
INFO - 2024-10-02 13:50:05 --> Helper loaded: my_helper
INFO - 2024-10-02 13:50:05 --> Database Driver Class Initialized
INFO - 2024-10-02 13:50:05 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-02 13:50:05 --> Controller Class Initialized
INFO - 2024-10-02 13:50:05 --> Final output sent to browser
DEBUG - 2024-10-02 13:50:05 --> Total execution time: 0.0359
INFO - 2024-10-02 13:50:22 --> Config Class Initialized
INFO - 2024-10-02 13:50:22 --> Hooks Class Initialized
DEBUG - 2024-10-02 13:50:22 --> UTF-8 Support Enabled
INFO - 2024-10-02 13:50:22 --> Utf8 Class Initialized
INFO - 2024-10-02 13:50:22 --> URI Class Initialized
INFO - 2024-10-02 13:50:22 --> Router Class Initialized
INFO - 2024-10-02 13:50:22 --> Output Class Initialized
INFO - 2024-10-02 13:50:22 --> Security Class Initialized
DEBUG - 2024-10-02 13:50:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-02 13:50:22 --> Input Class Initialized
INFO - 2024-10-02 13:50:22 --> Language Class Initialized
INFO - 2024-10-02 13:50:22 --> Language Class Initialized
INFO - 2024-10-02 13:50:22 --> Config Class Initialized
INFO - 2024-10-02 13:50:22 --> Loader Class Initialized
INFO - 2024-10-02 13:50:22 --> Helper loaded: url_helper
INFO - 2024-10-02 13:50:22 --> Helper loaded: file_helper
INFO - 2024-10-02 13:50:22 --> Helper loaded: form_helper
INFO - 2024-10-02 13:50:22 --> Helper loaded: my_helper
INFO - 2024-10-02 13:50:22 --> Database Driver Class Initialized
INFO - 2024-10-02 13:50:22 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-02 13:50:22 --> Controller Class Initialized
INFO - 2024-10-02 13:50:22 --> Final output sent to browser
DEBUG - 2024-10-02 13:50:22 --> Total execution time: 0.0316
INFO - 2024-10-02 13:57:56 --> Config Class Initialized
INFO - 2024-10-02 13:57:56 --> Hooks Class Initialized
DEBUG - 2024-10-02 13:57:56 --> UTF-8 Support Enabled
INFO - 2024-10-02 13:57:56 --> Utf8 Class Initialized
INFO - 2024-10-02 13:57:56 --> URI Class Initialized
INFO - 2024-10-02 13:57:56 --> Router Class Initialized
INFO - 2024-10-02 13:57:56 --> Output Class Initialized
INFO - 2024-10-02 13:57:56 --> Security Class Initialized
DEBUG - 2024-10-02 13:57:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-02 13:57:56 --> Input Class Initialized
INFO - 2024-10-02 13:57:56 --> Language Class Initialized
INFO - 2024-10-02 13:57:56 --> Language Class Initialized
INFO - 2024-10-02 13:57:56 --> Config Class Initialized
INFO - 2024-10-02 13:57:56 --> Loader Class Initialized
INFO - 2024-10-02 13:57:56 --> Helper loaded: url_helper
INFO - 2024-10-02 13:57:56 --> Helper loaded: file_helper
INFO - 2024-10-02 13:57:56 --> Helper loaded: form_helper
INFO - 2024-10-02 13:57:56 --> Helper loaded: my_helper
INFO - 2024-10-02 13:57:56 --> Database Driver Class Initialized
INFO - 2024-10-02 13:57:56 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-02 13:57:56 --> Controller Class Initialized
INFO - 2024-10-02 13:57:56 --> Config Class Initialized
INFO - 2024-10-02 13:57:56 --> Hooks Class Initialized
DEBUG - 2024-10-02 13:57:56 --> UTF-8 Support Enabled
INFO - 2024-10-02 13:57:56 --> Utf8 Class Initialized
INFO - 2024-10-02 13:57:56 --> URI Class Initialized
INFO - 2024-10-02 13:57:56 --> Router Class Initialized
INFO - 2024-10-02 13:57:56 --> Output Class Initialized
INFO - 2024-10-02 13:57:56 --> Security Class Initialized
DEBUG - 2024-10-02 13:57:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-02 13:57:56 --> Input Class Initialized
INFO - 2024-10-02 13:57:56 --> Language Class Initialized
INFO - 2024-10-02 13:57:56 --> Language Class Initialized
INFO - 2024-10-02 13:57:56 --> Config Class Initialized
INFO - 2024-10-02 13:57:56 --> Loader Class Initialized
INFO - 2024-10-02 13:57:56 --> Helper loaded: url_helper
INFO - 2024-10-02 13:57:56 --> Helper loaded: file_helper
INFO - 2024-10-02 13:57:56 --> Helper loaded: form_helper
INFO - 2024-10-02 13:57:56 --> Helper loaded: my_helper
INFO - 2024-10-02 13:57:56 --> Database Driver Class Initialized
INFO - 2024-10-02 13:57:56 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-02 13:57:56 --> Controller Class Initialized
DEBUG - 2024-10-02 13:57:56 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/login/views/login.php
DEBUG - 2024-10-02 13:57:56 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-10-02 13:57:56 --> Final output sent to browser
DEBUG - 2024-10-02 13:57:56 --> Total execution time: 0.0356
INFO - 2024-10-02 13:57:59 --> Config Class Initialized
INFO - 2024-10-02 13:57:59 --> Hooks Class Initialized
DEBUG - 2024-10-02 13:57:59 --> UTF-8 Support Enabled
INFO - 2024-10-02 13:57:59 --> Utf8 Class Initialized
INFO - 2024-10-02 13:57:59 --> URI Class Initialized
INFO - 2024-10-02 13:57:59 --> Router Class Initialized
INFO - 2024-10-02 13:57:59 --> Output Class Initialized
INFO - 2024-10-02 13:57:59 --> Security Class Initialized
DEBUG - 2024-10-02 13:57:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-02 13:57:59 --> Input Class Initialized
INFO - 2024-10-02 13:57:59 --> Language Class Initialized
INFO - 2024-10-02 13:57:59 --> Language Class Initialized
INFO - 2024-10-02 13:57:59 --> Config Class Initialized
INFO - 2024-10-02 13:57:59 --> Loader Class Initialized
INFO - 2024-10-02 13:57:59 --> Helper loaded: url_helper
INFO - 2024-10-02 13:57:59 --> Helper loaded: file_helper
INFO - 2024-10-02 13:57:59 --> Helper loaded: form_helper
INFO - 2024-10-02 13:57:59 --> Helper loaded: my_helper
INFO - 2024-10-02 13:57:59 --> Database Driver Class Initialized
INFO - 2024-10-02 13:57:59 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-02 13:57:59 --> Controller Class Initialized
DEBUG - 2024-10-02 13:57:59 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/view_mapel/views/v_view_mapel.php
DEBUG - 2024-10-02 13:57:59 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-10-02 13:57:59 --> Final output sent to browser
DEBUG - 2024-10-02 13:57:59 --> Total execution time: 0.0322
INFO - 2024-10-02 13:57:59 --> Config Class Initialized
INFO - 2024-10-02 13:57:59 --> Hooks Class Initialized
DEBUG - 2024-10-02 13:57:59 --> UTF-8 Support Enabled
INFO - 2024-10-02 13:57:59 --> Utf8 Class Initialized
INFO - 2024-10-02 13:57:59 --> URI Class Initialized
INFO - 2024-10-02 13:57:59 --> Router Class Initialized
INFO - 2024-10-02 13:57:59 --> Output Class Initialized
INFO - 2024-10-02 13:57:59 --> Security Class Initialized
DEBUG - 2024-10-02 13:57:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-02 13:57:59 --> Input Class Initialized
INFO - 2024-10-02 13:57:59 --> Language Class Initialized
INFO - 2024-10-02 13:57:59 --> Language Class Initialized
INFO - 2024-10-02 13:57:59 --> Config Class Initialized
INFO - 2024-10-02 13:57:59 --> Loader Class Initialized
INFO - 2024-10-02 13:57:59 --> Helper loaded: url_helper
INFO - 2024-10-02 13:57:59 --> Helper loaded: file_helper
INFO - 2024-10-02 13:57:59 --> Helper loaded: form_helper
INFO - 2024-10-02 13:57:59 --> Helper loaded: my_helper
INFO - 2024-10-02 13:57:59 --> Database Driver Class Initialized
INFO - 2024-10-02 13:57:59 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-02 13:57:59 --> Controller Class Initialized
INFO - 2024-10-02 13:57:59 --> Helper loaded: cookie_helper
INFO - 2024-10-02 13:57:59 --> Final output sent to browser
DEBUG - 2024-10-02 13:57:59 --> Total execution time: 0.0338
INFO - 2024-10-02 13:57:59 --> Config Class Initialized
INFO - 2024-10-02 13:57:59 --> Hooks Class Initialized
DEBUG - 2024-10-02 13:57:59 --> UTF-8 Support Enabled
INFO - 2024-10-02 13:57:59 --> Utf8 Class Initialized
INFO - 2024-10-02 13:57:59 --> URI Class Initialized
INFO - 2024-10-02 13:57:59 --> Router Class Initialized
INFO - 2024-10-02 13:57:59 --> Output Class Initialized
INFO - 2024-10-02 13:57:59 --> Security Class Initialized
DEBUG - 2024-10-02 13:57:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-02 13:57:59 --> Input Class Initialized
INFO - 2024-10-02 13:57:59 --> Language Class Initialized
INFO - 2024-10-02 13:57:59 --> Language Class Initialized
INFO - 2024-10-02 13:57:59 --> Config Class Initialized
INFO - 2024-10-02 13:57:59 --> Loader Class Initialized
INFO - 2024-10-02 13:57:59 --> Helper loaded: url_helper
INFO - 2024-10-02 13:57:59 --> Helper loaded: file_helper
INFO - 2024-10-02 13:57:59 --> Helper loaded: form_helper
INFO - 2024-10-02 13:57:59 --> Helper loaded: my_helper
INFO - 2024-10-02 13:57:59 --> Database Driver Class Initialized
INFO - 2024-10-02 13:57:59 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-02 13:57:59 --> Controller Class Initialized
DEBUG - 2024-10-02 13:57:59 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/home/views/v_home_guru.php
DEBUG - 2024-10-02 13:57:59 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-10-02 13:57:59 --> Final output sent to browser
DEBUG - 2024-10-02 13:57:59 --> Total execution time: 0.0392
INFO - 2024-10-02 13:58:03 --> Config Class Initialized
INFO - 2024-10-02 13:58:03 --> Hooks Class Initialized
DEBUG - 2024-10-02 13:58:03 --> UTF-8 Support Enabled
INFO - 2024-10-02 13:58:03 --> Utf8 Class Initialized
INFO - 2024-10-02 13:58:03 --> URI Class Initialized
INFO - 2024-10-02 13:58:03 --> Router Class Initialized
INFO - 2024-10-02 13:58:03 --> Output Class Initialized
INFO - 2024-10-02 13:58:03 --> Security Class Initialized
DEBUG - 2024-10-02 13:58:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-02 13:58:03 --> Input Class Initialized
INFO - 2024-10-02 13:58:03 --> Language Class Initialized
INFO - 2024-10-02 13:58:03 --> Language Class Initialized
INFO - 2024-10-02 13:58:03 --> Config Class Initialized
INFO - 2024-10-02 13:58:03 --> Loader Class Initialized
INFO - 2024-10-02 13:58:03 --> Helper loaded: url_helper
INFO - 2024-10-02 13:58:03 --> Helper loaded: file_helper
INFO - 2024-10-02 13:58:03 --> Helper loaded: form_helper
INFO - 2024-10-02 13:58:03 --> Helper loaded: my_helper
INFO - 2024-10-02 13:58:03 --> Database Driver Class Initialized
INFO - 2024-10-02 13:58:03 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-02 13:58:03 --> Controller Class Initialized
DEBUG - 2024-10-02 13:58:03 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/view_mapel/views/v_view_mapel.php
DEBUG - 2024-10-02 13:58:03 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-10-02 13:58:03 --> Final output sent to browser
DEBUG - 2024-10-02 13:58:03 --> Total execution time: 0.0304
INFO - 2024-10-02 13:58:15 --> Config Class Initialized
INFO - 2024-10-02 13:58:15 --> Hooks Class Initialized
DEBUG - 2024-10-02 13:58:15 --> UTF-8 Support Enabled
INFO - 2024-10-02 13:58:15 --> Utf8 Class Initialized
INFO - 2024-10-02 13:58:15 --> URI Class Initialized
INFO - 2024-10-02 13:58:15 --> Router Class Initialized
INFO - 2024-10-02 13:58:15 --> Output Class Initialized
INFO - 2024-10-02 13:58:15 --> Security Class Initialized
DEBUG - 2024-10-02 13:58:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-02 13:58:15 --> Input Class Initialized
INFO - 2024-10-02 13:58:15 --> Language Class Initialized
INFO - 2024-10-02 13:58:15 --> Language Class Initialized
INFO - 2024-10-02 13:58:15 --> Config Class Initialized
INFO - 2024-10-02 13:58:15 --> Loader Class Initialized
INFO - 2024-10-02 13:58:15 --> Helper loaded: url_helper
INFO - 2024-10-02 13:58:15 --> Helper loaded: file_helper
INFO - 2024-10-02 13:58:15 --> Helper loaded: form_helper
INFO - 2024-10-02 13:58:15 --> Helper loaded: my_helper
INFO - 2024-10-02 13:58:15 --> Database Driver Class Initialized
INFO - 2024-10-02 13:58:15 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-02 13:58:15 --> Controller Class Initialized
DEBUG - 2024-10-02 13:58:15 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_icb/views/list.php
DEBUG - 2024-10-02 13:58:15 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-10-02 13:58:15 --> Final output sent to browser
DEBUG - 2024-10-02 13:58:15 --> Total execution time: 0.0385
INFO - 2024-10-02 13:58:15 --> Config Class Initialized
INFO - 2024-10-02 13:58:15 --> Hooks Class Initialized
DEBUG - 2024-10-02 13:58:15 --> UTF-8 Support Enabled
INFO - 2024-10-02 13:58:15 --> Utf8 Class Initialized
INFO - 2024-10-02 13:58:15 --> URI Class Initialized
INFO - 2024-10-02 13:58:15 --> Router Class Initialized
INFO - 2024-10-02 13:58:15 --> Output Class Initialized
INFO - 2024-10-02 13:58:15 --> Security Class Initialized
DEBUG - 2024-10-02 13:58:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-02 13:58:15 --> Input Class Initialized
INFO - 2024-10-02 13:58:15 --> Language Class Initialized
INFO - 2024-10-02 13:58:15 --> Language Class Initialized
INFO - 2024-10-02 13:58:15 --> Config Class Initialized
INFO - 2024-10-02 13:58:15 --> Loader Class Initialized
INFO - 2024-10-02 13:58:15 --> Helper loaded: url_helper
INFO - 2024-10-02 13:58:15 --> Helper loaded: file_helper
INFO - 2024-10-02 13:58:15 --> Helper loaded: form_helper
INFO - 2024-10-02 13:58:15 --> Helper loaded: my_helper
INFO - 2024-10-02 13:58:15 --> Database Driver Class Initialized
INFO - 2024-10-02 13:58:15 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-02 13:58:15 --> Controller Class Initialized
INFO - 2024-10-02 13:58:31 --> Config Class Initialized
INFO - 2024-10-02 13:58:31 --> Hooks Class Initialized
DEBUG - 2024-10-02 13:58:31 --> UTF-8 Support Enabled
INFO - 2024-10-02 13:58:31 --> Utf8 Class Initialized
INFO - 2024-10-02 13:58:31 --> URI Class Initialized
INFO - 2024-10-02 13:58:31 --> Router Class Initialized
INFO - 2024-10-02 13:58:31 --> Output Class Initialized
INFO - 2024-10-02 13:58:31 --> Security Class Initialized
DEBUG - 2024-10-02 13:58:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-02 13:58:31 --> Input Class Initialized
INFO - 2024-10-02 13:58:31 --> Language Class Initialized
INFO - 2024-10-02 13:58:31 --> Language Class Initialized
INFO - 2024-10-02 13:58:31 --> Config Class Initialized
INFO - 2024-10-02 13:58:31 --> Loader Class Initialized
INFO - 2024-10-02 13:58:31 --> Helper loaded: url_helper
INFO - 2024-10-02 13:58:31 --> Helper loaded: file_helper
INFO - 2024-10-02 13:58:31 --> Helper loaded: form_helper
INFO - 2024-10-02 13:58:31 --> Helper loaded: my_helper
INFO - 2024-10-02 13:58:31 --> Database Driver Class Initialized
INFO - 2024-10-02 13:58:31 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-02 13:58:31 --> Controller Class Initialized
DEBUG - 2024-10-02 13:58:31 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/view_mapel/views/v_view_mapel.php
DEBUG - 2024-10-02 13:58:31 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-10-02 13:58:31 --> Final output sent to browser
DEBUG - 2024-10-02 13:58:31 --> Total execution time: 0.0715
INFO - 2024-10-02 13:58:33 --> Config Class Initialized
INFO - 2024-10-02 13:58:33 --> Hooks Class Initialized
DEBUG - 2024-10-02 13:58:33 --> UTF-8 Support Enabled
INFO - 2024-10-02 13:58:33 --> Utf8 Class Initialized
INFO - 2024-10-02 13:58:33 --> URI Class Initialized
INFO - 2024-10-02 13:58:33 --> Router Class Initialized
INFO - 2024-10-02 13:58:33 --> Output Class Initialized
INFO - 2024-10-02 13:58:33 --> Security Class Initialized
DEBUG - 2024-10-02 13:58:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-02 13:58:33 --> Input Class Initialized
INFO - 2024-10-02 13:58:33 --> Language Class Initialized
INFO - 2024-10-02 13:58:33 --> Language Class Initialized
INFO - 2024-10-02 13:58:33 --> Config Class Initialized
INFO - 2024-10-02 13:58:33 --> Loader Class Initialized
INFO - 2024-10-02 13:58:33 --> Helper loaded: url_helper
INFO - 2024-10-02 13:58:33 --> Helper loaded: file_helper
INFO - 2024-10-02 13:58:33 --> Helper loaded: form_helper
INFO - 2024-10-02 13:58:33 --> Helper loaded: my_helper
INFO - 2024-10-02 13:58:33 --> Database Driver Class Initialized
INFO - 2024-10-02 13:58:33 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-02 13:58:33 --> Controller Class Initialized
DEBUG - 2024-10-02 13:58:33 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pss/views/list.php
DEBUG - 2024-10-02 13:58:33 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-10-02 13:58:33 --> Final output sent to browser
DEBUG - 2024-10-02 13:58:33 --> Total execution time: 0.0463
INFO - 2024-10-02 13:58:33 --> Config Class Initialized
INFO - 2024-10-02 13:58:33 --> Hooks Class Initialized
DEBUG - 2024-10-02 13:58:33 --> UTF-8 Support Enabled
INFO - 2024-10-02 13:58:33 --> Utf8 Class Initialized
INFO - 2024-10-02 13:58:33 --> URI Class Initialized
INFO - 2024-10-02 13:58:33 --> Router Class Initialized
INFO - 2024-10-02 13:58:33 --> Output Class Initialized
INFO - 2024-10-02 13:58:33 --> Security Class Initialized
DEBUG - 2024-10-02 13:58:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-02 13:58:33 --> Input Class Initialized
INFO - 2024-10-02 13:58:33 --> Language Class Initialized
INFO - 2024-10-02 13:58:33 --> Language Class Initialized
INFO - 2024-10-02 13:58:33 --> Config Class Initialized
INFO - 2024-10-02 13:58:33 --> Loader Class Initialized
INFO - 2024-10-02 13:58:33 --> Helper loaded: url_helper
INFO - 2024-10-02 13:58:33 --> Helper loaded: file_helper
INFO - 2024-10-02 13:58:33 --> Helper loaded: form_helper
INFO - 2024-10-02 13:58:33 --> Helper loaded: my_helper
INFO - 2024-10-02 13:58:33 --> Database Driver Class Initialized
INFO - 2024-10-02 13:58:33 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-02 13:58:33 --> Controller Class Initialized
INFO - 2024-10-02 13:58:35 --> Config Class Initialized
INFO - 2024-10-02 13:58:35 --> Hooks Class Initialized
DEBUG - 2024-10-02 13:58:35 --> UTF-8 Support Enabled
INFO - 2024-10-02 13:58:35 --> Utf8 Class Initialized
INFO - 2024-10-02 13:58:35 --> URI Class Initialized
INFO - 2024-10-02 13:58:35 --> Router Class Initialized
INFO - 2024-10-02 13:58:35 --> Output Class Initialized
INFO - 2024-10-02 13:58:35 --> Security Class Initialized
DEBUG - 2024-10-02 13:58:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-02 13:58:35 --> Input Class Initialized
INFO - 2024-10-02 13:58:35 --> Language Class Initialized
INFO - 2024-10-02 13:58:35 --> Language Class Initialized
INFO - 2024-10-02 13:58:35 --> Config Class Initialized
INFO - 2024-10-02 13:58:35 --> Loader Class Initialized
INFO - 2024-10-02 13:58:35 --> Helper loaded: url_helper
INFO - 2024-10-02 13:58:35 --> Helper loaded: file_helper
INFO - 2024-10-02 13:58:35 --> Helper loaded: form_helper
INFO - 2024-10-02 13:58:35 --> Helper loaded: my_helper
INFO - 2024-10-02 13:58:35 --> Database Driver Class Initialized
INFO - 2024-10-02 13:58:35 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-02 13:58:35 --> Controller Class Initialized
DEBUG - 2024-10-02 13:58:35 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/view_mapel/views/v_view_mapel.php
DEBUG - 2024-10-02 13:58:35 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-10-02 13:58:35 --> Final output sent to browser
DEBUG - 2024-10-02 13:58:35 --> Total execution time: 0.0336
INFO - 2024-10-02 13:58:36 --> Config Class Initialized
INFO - 2024-10-02 13:58:36 --> Hooks Class Initialized
DEBUG - 2024-10-02 13:58:36 --> UTF-8 Support Enabled
INFO - 2024-10-02 13:58:36 --> Utf8 Class Initialized
INFO - 2024-10-02 13:58:36 --> URI Class Initialized
INFO - 2024-10-02 13:58:36 --> Router Class Initialized
INFO - 2024-10-02 13:58:36 --> Output Class Initialized
INFO - 2024-10-02 13:58:36 --> Security Class Initialized
DEBUG - 2024-10-02 13:58:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-02 13:58:36 --> Input Class Initialized
INFO - 2024-10-02 13:58:36 --> Language Class Initialized
INFO - 2024-10-02 13:58:36 --> Language Class Initialized
INFO - 2024-10-02 13:58:36 --> Config Class Initialized
INFO - 2024-10-02 13:58:36 --> Loader Class Initialized
INFO - 2024-10-02 13:58:36 --> Helper loaded: url_helper
INFO - 2024-10-02 13:58:36 --> Helper loaded: file_helper
INFO - 2024-10-02 13:58:36 --> Helper loaded: form_helper
INFO - 2024-10-02 13:58:36 --> Helper loaded: my_helper
INFO - 2024-10-02 13:58:36 --> Database Driver Class Initialized
INFO - 2024-10-02 13:58:36 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-02 13:58:36 --> Controller Class Initialized
DEBUG - 2024-10-02 13:58:36 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_la/views/list.php
DEBUG - 2024-10-02 13:58:36 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-10-02 13:58:36 --> Final output sent to browser
DEBUG - 2024-10-02 13:58:36 --> Total execution time: 0.0403
INFO - 2024-10-02 13:58:37 --> Config Class Initialized
INFO - 2024-10-02 13:58:37 --> Hooks Class Initialized
DEBUG - 2024-10-02 13:58:37 --> UTF-8 Support Enabled
INFO - 2024-10-02 13:58:37 --> Utf8 Class Initialized
INFO - 2024-10-02 13:58:37 --> URI Class Initialized
INFO - 2024-10-02 13:58:37 --> Router Class Initialized
INFO - 2024-10-02 13:58:37 --> Output Class Initialized
INFO - 2024-10-02 13:58:37 --> Security Class Initialized
DEBUG - 2024-10-02 13:58:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-02 13:58:37 --> Input Class Initialized
INFO - 2024-10-02 13:58:37 --> Language Class Initialized
INFO - 2024-10-02 13:58:37 --> Language Class Initialized
INFO - 2024-10-02 13:58:37 --> Config Class Initialized
INFO - 2024-10-02 13:58:37 --> Loader Class Initialized
INFO - 2024-10-02 13:58:37 --> Helper loaded: url_helper
INFO - 2024-10-02 13:58:37 --> Helper loaded: file_helper
INFO - 2024-10-02 13:58:37 --> Helper loaded: form_helper
INFO - 2024-10-02 13:58:37 --> Helper loaded: my_helper
INFO - 2024-10-02 13:58:37 --> Database Driver Class Initialized
INFO - 2024-10-02 13:58:37 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-02 13:58:37 --> Controller Class Initialized
INFO - 2024-10-02 13:58:38 --> Config Class Initialized
INFO - 2024-10-02 13:58:38 --> Hooks Class Initialized
DEBUG - 2024-10-02 13:58:38 --> UTF-8 Support Enabled
INFO - 2024-10-02 13:58:38 --> Utf8 Class Initialized
INFO - 2024-10-02 13:58:38 --> URI Class Initialized
INFO - 2024-10-02 13:58:38 --> Router Class Initialized
INFO - 2024-10-02 13:58:38 --> Output Class Initialized
INFO - 2024-10-02 13:58:38 --> Security Class Initialized
DEBUG - 2024-10-02 13:58:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-02 13:58:38 --> Input Class Initialized
INFO - 2024-10-02 13:58:38 --> Language Class Initialized
INFO - 2024-10-02 13:58:38 --> Language Class Initialized
INFO - 2024-10-02 13:58:38 --> Config Class Initialized
INFO - 2024-10-02 13:58:38 --> Loader Class Initialized
INFO - 2024-10-02 13:58:38 --> Helper loaded: url_helper
INFO - 2024-10-02 13:58:38 --> Helper loaded: file_helper
INFO - 2024-10-02 13:58:38 --> Helper loaded: form_helper
INFO - 2024-10-02 13:58:38 --> Helper loaded: my_helper
INFO - 2024-10-02 13:58:38 --> Database Driver Class Initialized
INFO - 2024-10-02 13:58:38 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-02 13:58:38 --> Controller Class Initialized
DEBUG - 2024-10-02 13:58:38 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/view_mapel/views/v_view_mapel.php
DEBUG - 2024-10-02 13:58:38 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-10-02 13:58:38 --> Final output sent to browser
DEBUG - 2024-10-02 13:58:38 --> Total execution time: 0.0365
INFO - 2024-10-02 13:59:14 --> Config Class Initialized
INFO - 2024-10-02 13:59:14 --> Hooks Class Initialized
DEBUG - 2024-10-02 13:59:14 --> UTF-8 Support Enabled
INFO - 2024-10-02 13:59:14 --> Utf8 Class Initialized
INFO - 2024-10-02 13:59:14 --> URI Class Initialized
INFO - 2024-10-02 13:59:14 --> Router Class Initialized
INFO - 2024-10-02 13:59:14 --> Output Class Initialized
INFO - 2024-10-02 13:59:14 --> Security Class Initialized
DEBUG - 2024-10-02 13:59:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-02 13:59:14 --> Input Class Initialized
INFO - 2024-10-02 13:59:14 --> Language Class Initialized
INFO - 2024-10-02 13:59:14 --> Language Class Initialized
INFO - 2024-10-02 13:59:14 --> Config Class Initialized
INFO - 2024-10-02 13:59:14 --> Loader Class Initialized
INFO - 2024-10-02 13:59:14 --> Helper loaded: url_helper
INFO - 2024-10-02 13:59:14 --> Helper loaded: file_helper
INFO - 2024-10-02 13:59:14 --> Helper loaded: form_helper
INFO - 2024-10-02 13:59:14 --> Helper loaded: my_helper
INFO - 2024-10-02 13:59:14 --> Database Driver Class Initialized
INFO - 2024-10-02 13:59:14 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-02 13:59:14 --> Controller Class Initialized
DEBUG - 2024-10-02 13:59:14 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/view_mapel/views/v_view_mapel.php
DEBUG - 2024-10-02 13:59:14 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-10-02 13:59:14 --> Final output sent to browser
DEBUG - 2024-10-02 13:59:14 --> Total execution time: 0.0418
INFO - 2024-10-02 13:59:21 --> Config Class Initialized
INFO - 2024-10-02 13:59:21 --> Hooks Class Initialized
DEBUG - 2024-10-02 13:59:21 --> UTF-8 Support Enabled
INFO - 2024-10-02 13:59:21 --> Utf8 Class Initialized
INFO - 2024-10-02 13:59:21 --> URI Class Initialized
INFO - 2024-10-02 13:59:21 --> Router Class Initialized
INFO - 2024-10-02 13:59:21 --> Output Class Initialized
INFO - 2024-10-02 13:59:21 --> Security Class Initialized
DEBUG - 2024-10-02 13:59:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-02 13:59:21 --> Input Class Initialized
INFO - 2024-10-02 13:59:21 --> Language Class Initialized
INFO - 2024-10-02 13:59:21 --> Language Class Initialized
INFO - 2024-10-02 13:59:21 --> Config Class Initialized
INFO - 2024-10-02 13:59:21 --> Loader Class Initialized
INFO - 2024-10-02 13:59:21 --> Helper loaded: url_helper
INFO - 2024-10-02 13:59:21 --> Helper loaded: file_helper
INFO - 2024-10-02 13:59:21 --> Helper loaded: form_helper
INFO - 2024-10-02 13:59:21 --> Helper loaded: my_helper
INFO - 2024-10-02 13:59:21 --> Database Driver Class Initialized
INFO - 2024-10-02 13:59:21 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-02 13:59:21 --> Controller Class Initialized
DEBUG - 2024-10-02 13:59:21 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_absensi/views/list.php
DEBUG - 2024-10-02 13:59:21 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-10-02 13:59:21 --> Final output sent to browser
DEBUG - 2024-10-02 13:59:21 --> Total execution time: 0.0336
INFO - 2024-10-02 13:59:22 --> Config Class Initialized
INFO - 2024-10-02 13:59:22 --> Hooks Class Initialized
DEBUG - 2024-10-02 13:59:22 --> UTF-8 Support Enabled
INFO - 2024-10-02 13:59:22 --> Utf8 Class Initialized
INFO - 2024-10-02 13:59:22 --> URI Class Initialized
INFO - 2024-10-02 13:59:22 --> Router Class Initialized
INFO - 2024-10-02 13:59:22 --> Output Class Initialized
INFO - 2024-10-02 13:59:22 --> Security Class Initialized
DEBUG - 2024-10-02 13:59:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-02 13:59:22 --> Input Class Initialized
INFO - 2024-10-02 13:59:22 --> Language Class Initialized
INFO - 2024-10-02 13:59:22 --> Language Class Initialized
INFO - 2024-10-02 13:59:22 --> Config Class Initialized
INFO - 2024-10-02 13:59:22 --> Loader Class Initialized
INFO - 2024-10-02 13:59:22 --> Helper loaded: url_helper
INFO - 2024-10-02 13:59:22 --> Helper loaded: file_helper
INFO - 2024-10-02 13:59:22 --> Helper loaded: form_helper
INFO - 2024-10-02 13:59:22 --> Helper loaded: my_helper
INFO - 2024-10-02 13:59:22 --> Database Driver Class Initialized
INFO - 2024-10-02 13:59:22 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-02 13:59:22 --> Controller Class Initialized
DEBUG - 2024-10-02 13:59:22 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_absensi/views/list.php
DEBUG - 2024-10-02 13:59:22 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-10-02 13:59:22 --> Final output sent to browser
DEBUG - 2024-10-02 13:59:22 --> Total execution time: 0.0324
INFO - 2024-10-02 13:59:50 --> Config Class Initialized
INFO - 2024-10-02 13:59:50 --> Hooks Class Initialized
DEBUG - 2024-10-02 13:59:50 --> UTF-8 Support Enabled
INFO - 2024-10-02 13:59:50 --> Utf8 Class Initialized
INFO - 2024-10-02 13:59:50 --> URI Class Initialized
INFO - 2024-10-02 13:59:50 --> Router Class Initialized
INFO - 2024-10-02 13:59:50 --> Output Class Initialized
INFO - 2024-10-02 13:59:50 --> Security Class Initialized
DEBUG - 2024-10-02 13:59:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-02 13:59:50 --> Input Class Initialized
INFO - 2024-10-02 13:59:50 --> Language Class Initialized
INFO - 2024-10-02 13:59:50 --> Language Class Initialized
INFO - 2024-10-02 13:59:50 --> Config Class Initialized
INFO - 2024-10-02 13:59:50 --> Loader Class Initialized
INFO - 2024-10-02 13:59:50 --> Helper loaded: url_helper
INFO - 2024-10-02 13:59:50 --> Helper loaded: file_helper
INFO - 2024-10-02 13:59:50 --> Helper loaded: form_helper
INFO - 2024-10-02 13:59:50 --> Helper loaded: my_helper
INFO - 2024-10-02 13:59:50 --> Database Driver Class Initialized
INFO - 2024-10-02 13:59:50 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-02 13:59:50 --> Controller Class Initialized
DEBUG - 2024-10-02 13:59:50 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_catatan_homeroom/views/list.php
DEBUG - 2024-10-02 13:59:50 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-10-02 13:59:50 --> Final output sent to browser
DEBUG - 2024-10-02 13:59:50 --> Total execution time: 0.0330
INFO - 2024-10-02 13:59:50 --> Config Class Initialized
INFO - 2024-10-02 13:59:50 --> Hooks Class Initialized
DEBUG - 2024-10-02 13:59:50 --> UTF-8 Support Enabled
INFO - 2024-10-02 13:59:50 --> Utf8 Class Initialized
INFO - 2024-10-02 13:59:50 --> URI Class Initialized
INFO - 2024-10-02 13:59:50 --> Router Class Initialized
INFO - 2024-10-02 13:59:50 --> Output Class Initialized
INFO - 2024-10-02 13:59:50 --> Security Class Initialized
DEBUG - 2024-10-02 13:59:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-02 13:59:50 --> Input Class Initialized
INFO - 2024-10-02 13:59:50 --> Language Class Initialized
INFO - 2024-10-02 13:59:50 --> Language Class Initialized
INFO - 2024-10-02 13:59:50 --> Config Class Initialized
INFO - 2024-10-02 13:59:50 --> Loader Class Initialized
INFO - 2024-10-02 13:59:50 --> Helper loaded: url_helper
INFO - 2024-10-02 13:59:50 --> Helper loaded: file_helper
INFO - 2024-10-02 13:59:50 --> Helper loaded: form_helper
INFO - 2024-10-02 13:59:50 --> Helper loaded: my_helper
INFO - 2024-10-02 13:59:50 --> Database Driver Class Initialized
INFO - 2024-10-02 13:59:50 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-02 13:59:50 --> Controller Class Initialized
DEBUG - 2024-10-02 13:59:50 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_catatan_homeroom/views/list.php
DEBUG - 2024-10-02 13:59:50 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-10-02 13:59:50 --> Final output sent to browser
DEBUG - 2024-10-02 13:59:50 --> Total execution time: 0.0308
INFO - 2024-10-02 13:59:56 --> Config Class Initialized
INFO - 2024-10-02 13:59:56 --> Hooks Class Initialized
DEBUG - 2024-10-02 13:59:56 --> UTF-8 Support Enabled
INFO - 2024-10-02 13:59:56 --> Utf8 Class Initialized
INFO - 2024-10-02 13:59:56 --> URI Class Initialized
INFO - 2024-10-02 13:59:56 --> Router Class Initialized
INFO - 2024-10-02 13:59:56 --> Output Class Initialized
INFO - 2024-10-02 13:59:56 --> Security Class Initialized
DEBUG - 2024-10-02 13:59:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-02 13:59:56 --> Input Class Initialized
INFO - 2024-10-02 13:59:56 --> Language Class Initialized
INFO - 2024-10-02 13:59:56 --> Language Class Initialized
INFO - 2024-10-02 13:59:56 --> Config Class Initialized
INFO - 2024-10-02 13:59:56 --> Loader Class Initialized
INFO - 2024-10-02 13:59:56 --> Helper loaded: url_helper
INFO - 2024-10-02 13:59:56 --> Helper loaded: file_helper
INFO - 2024-10-02 13:59:56 --> Helper loaded: form_helper
INFO - 2024-10-02 13:59:56 --> Helper loaded: my_helper
INFO - 2024-10-02 13:59:56 --> Database Driver Class Initialized
INFO - 2024-10-02 13:59:56 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-02 13:59:56 --> Controller Class Initialized
DEBUG - 2024-10-02 13:59:56 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_absensi/views/list.php
DEBUG - 2024-10-02 13:59:56 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-10-02 13:59:56 --> Final output sent to browser
DEBUG - 2024-10-02 13:59:56 --> Total execution time: 0.0327
INFO - 2024-10-02 13:59:57 --> Config Class Initialized
INFO - 2024-10-02 13:59:57 --> Hooks Class Initialized
DEBUG - 2024-10-02 13:59:57 --> UTF-8 Support Enabled
INFO - 2024-10-02 13:59:57 --> Utf8 Class Initialized
INFO - 2024-10-02 13:59:57 --> URI Class Initialized
INFO - 2024-10-02 13:59:57 --> Router Class Initialized
INFO - 2024-10-02 13:59:57 --> Output Class Initialized
INFO - 2024-10-02 13:59:57 --> Security Class Initialized
DEBUG - 2024-10-02 13:59:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-02 13:59:57 --> Input Class Initialized
INFO - 2024-10-02 13:59:57 --> Language Class Initialized
INFO - 2024-10-02 13:59:57 --> Language Class Initialized
INFO - 2024-10-02 13:59:57 --> Config Class Initialized
INFO - 2024-10-02 13:59:57 --> Loader Class Initialized
INFO - 2024-10-02 13:59:57 --> Helper loaded: url_helper
INFO - 2024-10-02 13:59:57 --> Helper loaded: file_helper
INFO - 2024-10-02 13:59:57 --> Helper loaded: form_helper
INFO - 2024-10-02 13:59:57 --> Helper loaded: my_helper
INFO - 2024-10-02 13:59:57 --> Database Driver Class Initialized
INFO - 2024-10-02 13:59:57 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-02 13:59:57 --> Controller Class Initialized
DEBUG - 2024-10-02 13:59:57 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/login/views/login.php
DEBUG - 2024-10-02 13:59:57 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-10-02 13:59:57 --> Final output sent to browser
DEBUG - 2024-10-02 13:59:57 --> Total execution time: 0.0301
INFO - 2024-10-02 14:00:05 --> Config Class Initialized
INFO - 2024-10-02 14:00:05 --> Hooks Class Initialized
DEBUG - 2024-10-02 14:00:05 --> UTF-8 Support Enabled
INFO - 2024-10-02 14:00:05 --> Utf8 Class Initialized
INFO - 2024-10-02 14:00:05 --> URI Class Initialized
INFO - 2024-10-02 14:00:05 --> Router Class Initialized
INFO - 2024-10-02 14:00:05 --> Output Class Initialized
INFO - 2024-10-02 14:00:05 --> Security Class Initialized
DEBUG - 2024-10-02 14:00:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-02 14:00:05 --> Input Class Initialized
INFO - 2024-10-02 14:00:05 --> Language Class Initialized
INFO - 2024-10-02 14:00:05 --> Language Class Initialized
INFO - 2024-10-02 14:00:05 --> Config Class Initialized
INFO - 2024-10-02 14:00:05 --> Loader Class Initialized
INFO - 2024-10-02 14:00:05 --> Helper loaded: url_helper
INFO - 2024-10-02 14:00:05 --> Helper loaded: file_helper
INFO - 2024-10-02 14:00:05 --> Helper loaded: form_helper
INFO - 2024-10-02 14:00:05 --> Helper loaded: my_helper
INFO - 2024-10-02 14:00:05 --> Database Driver Class Initialized
INFO - 2024-10-02 14:00:06 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-02 14:00:06 --> Controller Class Initialized
DEBUG - 2024-10-02 14:00:06 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_ekstra/views/list.php
DEBUG - 2024-10-02 14:00:06 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-10-02 14:00:06 --> Final output sent to browser
DEBUG - 2024-10-02 14:00:06 --> Total execution time: 0.0543
INFO - 2024-10-02 14:00:17 --> Config Class Initialized
INFO - 2024-10-02 14:00:17 --> Hooks Class Initialized
DEBUG - 2024-10-02 14:00:17 --> UTF-8 Support Enabled
INFO - 2024-10-02 14:00:17 --> Utf8 Class Initialized
INFO - 2024-10-02 14:00:17 --> URI Class Initialized
INFO - 2024-10-02 14:00:17 --> Router Class Initialized
INFO - 2024-10-02 14:00:17 --> Output Class Initialized
INFO - 2024-10-02 14:00:17 --> Security Class Initialized
DEBUG - 2024-10-02 14:00:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-02 14:00:17 --> Input Class Initialized
INFO - 2024-10-02 14:00:17 --> Language Class Initialized
INFO - 2024-10-02 14:00:17 --> Language Class Initialized
INFO - 2024-10-02 14:00:17 --> Config Class Initialized
INFO - 2024-10-02 14:00:17 --> Loader Class Initialized
INFO - 2024-10-02 14:00:17 --> Helper loaded: url_helper
INFO - 2024-10-02 14:00:17 --> Helper loaded: file_helper
INFO - 2024-10-02 14:00:17 --> Helper loaded: form_helper
INFO - 2024-10-02 14:00:17 --> Helper loaded: my_helper
INFO - 2024-10-02 14:00:17 --> Database Driver Class Initialized
INFO - 2024-10-02 14:00:17 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-02 14:00:17 --> Controller Class Initialized
INFO - 2024-10-02 14:00:17 --> Final output sent to browser
DEBUG - 2024-10-02 14:00:17 --> Total execution time: 0.0341
INFO - 2024-10-02 14:00:24 --> Config Class Initialized
INFO - 2024-10-02 14:00:24 --> Hooks Class Initialized
DEBUG - 2024-10-02 14:00:24 --> UTF-8 Support Enabled
INFO - 2024-10-02 14:00:24 --> Utf8 Class Initialized
INFO - 2024-10-02 14:00:24 --> URI Class Initialized
INFO - 2024-10-02 14:00:24 --> Router Class Initialized
INFO - 2024-10-02 14:00:24 --> Output Class Initialized
INFO - 2024-10-02 14:00:24 --> Security Class Initialized
DEBUG - 2024-10-02 14:00:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-02 14:00:24 --> Input Class Initialized
INFO - 2024-10-02 14:00:24 --> Language Class Initialized
INFO - 2024-10-02 14:00:24 --> Language Class Initialized
INFO - 2024-10-02 14:00:24 --> Config Class Initialized
INFO - 2024-10-02 14:00:24 --> Loader Class Initialized
INFO - 2024-10-02 14:00:24 --> Helper loaded: url_helper
INFO - 2024-10-02 14:00:24 --> Helper loaded: file_helper
INFO - 2024-10-02 14:00:24 --> Helper loaded: form_helper
INFO - 2024-10-02 14:00:24 --> Helper loaded: my_helper
INFO - 2024-10-02 14:00:24 --> Database Driver Class Initialized
INFO - 2024-10-02 14:00:24 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-02 14:00:24 --> Controller Class Initialized
INFO - 2024-10-02 14:00:24 --> Helper loaded: cookie_helper
INFO - 2024-10-02 14:00:24 --> Final output sent to browser
DEBUG - 2024-10-02 14:00:24 --> Total execution time: 0.0370
INFO - 2024-10-02 14:00:24 --> Config Class Initialized
INFO - 2024-10-02 14:00:24 --> Hooks Class Initialized
DEBUG - 2024-10-02 14:00:24 --> UTF-8 Support Enabled
INFO - 2024-10-02 14:00:24 --> Utf8 Class Initialized
INFO - 2024-10-02 14:00:24 --> URI Class Initialized
INFO - 2024-10-02 14:00:24 --> Router Class Initialized
INFO - 2024-10-02 14:00:24 --> Output Class Initialized
INFO - 2024-10-02 14:00:24 --> Security Class Initialized
DEBUG - 2024-10-02 14:00:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-02 14:00:24 --> Input Class Initialized
INFO - 2024-10-02 14:00:24 --> Language Class Initialized
INFO - 2024-10-02 14:00:24 --> Language Class Initialized
INFO - 2024-10-02 14:00:24 --> Config Class Initialized
INFO - 2024-10-02 14:00:24 --> Loader Class Initialized
INFO - 2024-10-02 14:00:24 --> Helper loaded: url_helper
INFO - 2024-10-02 14:00:24 --> Helper loaded: file_helper
INFO - 2024-10-02 14:00:24 --> Helper loaded: form_helper
INFO - 2024-10-02 14:00:24 --> Helper loaded: my_helper
INFO - 2024-10-02 14:00:24 --> Database Driver Class Initialized
INFO - 2024-10-02 14:00:24 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-02 14:00:24 --> Controller Class Initialized
DEBUG - 2024-10-02 14:00:24 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/home/views/v_home.php
DEBUG - 2024-10-02 14:00:24 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-10-02 14:00:24 --> Final output sent to browser
DEBUG - 2024-10-02 14:00:24 --> Total execution time: 0.0357
INFO - 2024-10-02 14:00:53 --> Config Class Initialized
INFO - 2024-10-02 14:00:53 --> Hooks Class Initialized
DEBUG - 2024-10-02 14:00:53 --> UTF-8 Support Enabled
INFO - 2024-10-02 14:00:53 --> Utf8 Class Initialized
INFO - 2024-10-02 14:00:53 --> URI Class Initialized
INFO - 2024-10-02 14:00:53 --> Router Class Initialized
INFO - 2024-10-02 14:00:53 --> Output Class Initialized
INFO - 2024-10-02 14:00:53 --> Security Class Initialized
DEBUG - 2024-10-02 14:00:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-02 14:00:53 --> Input Class Initialized
INFO - 2024-10-02 14:00:53 --> Language Class Initialized
INFO - 2024-10-02 14:00:53 --> Language Class Initialized
INFO - 2024-10-02 14:00:53 --> Config Class Initialized
INFO - 2024-10-02 14:00:53 --> Loader Class Initialized
INFO - 2024-10-02 14:00:53 --> Helper loaded: url_helper
INFO - 2024-10-02 14:00:53 --> Helper loaded: file_helper
INFO - 2024-10-02 14:00:53 --> Helper loaded: form_helper
INFO - 2024-10-02 14:00:53 --> Helper loaded: my_helper
INFO - 2024-10-02 14:00:53 --> Database Driver Class Initialized
INFO - 2024-10-02 14:00:53 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-02 14:00:53 --> Controller Class Initialized
INFO - 2024-10-02 14:00:53 --> Helper loaded: cookie_helper
INFO - 2024-10-02 14:00:53 --> Config Class Initialized
INFO - 2024-10-02 14:00:53 --> Hooks Class Initialized
DEBUG - 2024-10-02 14:00:53 --> UTF-8 Support Enabled
INFO - 2024-10-02 14:00:53 --> Utf8 Class Initialized
INFO - 2024-10-02 14:00:53 --> URI Class Initialized
INFO - 2024-10-02 14:00:53 --> Router Class Initialized
INFO - 2024-10-02 14:00:53 --> Output Class Initialized
INFO - 2024-10-02 14:00:53 --> Security Class Initialized
DEBUG - 2024-10-02 14:00:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-02 14:00:53 --> Input Class Initialized
INFO - 2024-10-02 14:00:53 --> Language Class Initialized
INFO - 2024-10-02 14:00:54 --> Language Class Initialized
INFO - 2024-10-02 14:00:54 --> Config Class Initialized
INFO - 2024-10-02 14:00:54 --> Loader Class Initialized
INFO - 2024-10-02 14:00:54 --> Helper loaded: url_helper
INFO - 2024-10-02 14:00:54 --> Helper loaded: file_helper
INFO - 2024-10-02 14:00:54 --> Helper loaded: form_helper
INFO - 2024-10-02 14:00:54 --> Helper loaded: my_helper
INFO - 2024-10-02 14:00:54 --> Database Driver Class Initialized
INFO - 2024-10-02 14:00:54 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-02 14:00:54 --> Controller Class Initialized
INFO - 2024-10-02 14:00:54 --> Config Class Initialized
INFO - 2024-10-02 14:00:54 --> Hooks Class Initialized
DEBUG - 2024-10-02 14:00:54 --> UTF-8 Support Enabled
INFO - 2024-10-02 14:00:54 --> Utf8 Class Initialized
INFO - 2024-10-02 14:00:54 --> URI Class Initialized
INFO - 2024-10-02 14:00:54 --> Router Class Initialized
INFO - 2024-10-02 14:00:54 --> Output Class Initialized
INFO - 2024-10-02 14:00:54 --> Security Class Initialized
DEBUG - 2024-10-02 14:00:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-02 14:00:54 --> Input Class Initialized
INFO - 2024-10-02 14:00:54 --> Language Class Initialized
INFO - 2024-10-02 14:00:54 --> Language Class Initialized
INFO - 2024-10-02 14:00:54 --> Config Class Initialized
INFO - 2024-10-02 14:00:54 --> Loader Class Initialized
INFO - 2024-10-02 14:00:54 --> Helper loaded: url_helper
INFO - 2024-10-02 14:00:54 --> Helper loaded: file_helper
INFO - 2024-10-02 14:00:54 --> Helper loaded: form_helper
INFO - 2024-10-02 14:00:54 --> Helper loaded: my_helper
INFO - 2024-10-02 14:00:54 --> Database Driver Class Initialized
INFO - 2024-10-02 14:00:54 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-02 14:00:54 --> Controller Class Initialized
DEBUG - 2024-10-02 14:00:54 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/login/views/login.php
DEBUG - 2024-10-02 14:00:54 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-10-02 14:00:54 --> Final output sent to browser
DEBUG - 2024-10-02 14:00:54 --> Total execution time: 0.0418
INFO - 2024-10-02 14:01:05 --> Config Class Initialized
INFO - 2024-10-02 14:01:05 --> Hooks Class Initialized
DEBUG - 2024-10-02 14:01:05 --> UTF-8 Support Enabled
INFO - 2024-10-02 14:01:05 --> Utf8 Class Initialized
INFO - 2024-10-02 14:01:05 --> URI Class Initialized
INFO - 2024-10-02 14:01:05 --> Router Class Initialized
INFO - 2024-10-02 14:01:05 --> Output Class Initialized
INFO - 2024-10-02 14:01:05 --> Security Class Initialized
DEBUG - 2024-10-02 14:01:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-02 14:01:05 --> Input Class Initialized
INFO - 2024-10-02 14:01:05 --> Language Class Initialized
INFO - 2024-10-02 14:01:05 --> Language Class Initialized
INFO - 2024-10-02 14:01:05 --> Config Class Initialized
INFO - 2024-10-02 14:01:05 --> Loader Class Initialized
INFO - 2024-10-02 14:01:05 --> Helper loaded: url_helper
INFO - 2024-10-02 14:01:05 --> Helper loaded: file_helper
INFO - 2024-10-02 14:01:05 --> Helper loaded: form_helper
INFO - 2024-10-02 14:01:05 --> Helper loaded: my_helper
INFO - 2024-10-02 14:01:05 --> Database Driver Class Initialized
INFO - 2024-10-02 14:01:05 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-02 14:01:05 --> Controller Class Initialized
DEBUG - 2024-10-02 14:01:05 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_catatan_homeroom/views/list.php
DEBUG - 2024-10-02 14:01:05 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-10-02 14:01:05 --> Final output sent to browser
DEBUG - 2024-10-02 14:01:05 --> Total execution time: 0.0331
INFO - 2024-10-02 14:01:08 --> Config Class Initialized
INFO - 2024-10-02 14:01:08 --> Hooks Class Initialized
DEBUG - 2024-10-02 14:01:08 --> UTF-8 Support Enabled
INFO - 2024-10-02 14:01:08 --> Utf8 Class Initialized
INFO - 2024-10-02 14:01:08 --> URI Class Initialized
INFO - 2024-10-02 14:01:08 --> Router Class Initialized
INFO - 2024-10-02 14:01:08 --> Output Class Initialized
INFO - 2024-10-02 14:01:08 --> Security Class Initialized
DEBUG - 2024-10-02 14:01:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-02 14:01:08 --> Input Class Initialized
INFO - 2024-10-02 14:01:08 --> Language Class Initialized
INFO - 2024-10-02 14:01:08 --> Language Class Initialized
INFO - 2024-10-02 14:01:08 --> Config Class Initialized
INFO - 2024-10-02 14:01:08 --> Loader Class Initialized
INFO - 2024-10-02 14:01:08 --> Helper loaded: url_helper
INFO - 2024-10-02 14:01:08 --> Helper loaded: file_helper
INFO - 2024-10-02 14:01:08 --> Helper loaded: form_helper
INFO - 2024-10-02 14:01:08 --> Helper loaded: my_helper
INFO - 2024-10-02 14:01:08 --> Database Driver Class Initialized
INFO - 2024-10-02 14:01:08 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-02 14:01:08 --> Controller Class Initialized
INFO - 2024-10-02 14:01:08 --> Helper loaded: cookie_helper
INFO - 2024-10-02 14:01:08 --> Final output sent to browser
DEBUG - 2024-10-02 14:01:08 --> Total execution time: 0.0365
INFO - 2024-10-02 14:01:08 --> Config Class Initialized
INFO - 2024-10-02 14:01:08 --> Hooks Class Initialized
DEBUG - 2024-10-02 14:01:08 --> UTF-8 Support Enabled
INFO - 2024-10-02 14:01:08 --> Utf8 Class Initialized
INFO - 2024-10-02 14:01:08 --> URI Class Initialized
INFO - 2024-10-02 14:01:08 --> Router Class Initialized
INFO - 2024-10-02 14:01:08 --> Output Class Initialized
INFO - 2024-10-02 14:01:08 --> Security Class Initialized
DEBUG - 2024-10-02 14:01:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-02 14:01:08 --> Input Class Initialized
INFO - 2024-10-02 14:01:08 --> Language Class Initialized
INFO - 2024-10-02 14:01:08 --> Language Class Initialized
INFO - 2024-10-02 14:01:08 --> Config Class Initialized
INFO - 2024-10-02 14:01:08 --> Loader Class Initialized
INFO - 2024-10-02 14:01:08 --> Helper loaded: url_helper
INFO - 2024-10-02 14:01:08 --> Helper loaded: file_helper
INFO - 2024-10-02 14:01:08 --> Helper loaded: form_helper
INFO - 2024-10-02 14:01:08 --> Helper loaded: my_helper
INFO - 2024-10-02 14:01:08 --> Database Driver Class Initialized
INFO - 2024-10-02 14:01:08 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-02 14:01:08 --> Controller Class Initialized
DEBUG - 2024-10-02 14:01:08 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/home/views/v_home_guru.php
DEBUG - 2024-10-02 14:01:08 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-10-02 14:01:08 --> Final output sent to browser
DEBUG - 2024-10-02 14:01:08 --> Total execution time: 0.0355
INFO - 2024-10-02 14:01:15 --> Config Class Initialized
INFO - 2024-10-02 14:01:15 --> Hooks Class Initialized
DEBUG - 2024-10-02 14:01:15 --> UTF-8 Support Enabled
INFO - 2024-10-02 14:01:15 --> Utf8 Class Initialized
INFO - 2024-10-02 14:01:15 --> URI Class Initialized
INFO - 2024-10-02 14:01:15 --> Router Class Initialized
INFO - 2024-10-02 14:01:15 --> Output Class Initialized
INFO - 2024-10-02 14:01:15 --> Security Class Initialized
DEBUG - 2024-10-02 14:01:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-02 14:01:15 --> Input Class Initialized
INFO - 2024-10-02 14:01:15 --> Language Class Initialized
INFO - 2024-10-02 14:01:15 --> Language Class Initialized
INFO - 2024-10-02 14:01:15 --> Config Class Initialized
INFO - 2024-10-02 14:01:15 --> Loader Class Initialized
INFO - 2024-10-02 14:01:15 --> Helper loaded: url_helper
INFO - 2024-10-02 14:01:15 --> Helper loaded: file_helper
INFO - 2024-10-02 14:01:15 --> Helper loaded: form_helper
INFO - 2024-10-02 14:01:15 --> Helper loaded: my_helper
INFO - 2024-10-02 14:01:15 --> Database Driver Class Initialized
INFO - 2024-10-02 14:01:15 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-02 14:01:15 --> Controller Class Initialized
DEBUG - 2024-10-02 14:01:15 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/view_mapel/views/v_view_mapel.php
DEBUG - 2024-10-02 14:01:15 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-10-02 14:01:15 --> Final output sent to browser
DEBUG - 2024-10-02 14:01:15 --> Total execution time: 0.0558
INFO - 2024-10-02 14:01:20 --> Config Class Initialized
INFO - 2024-10-02 14:01:20 --> Hooks Class Initialized
DEBUG - 2024-10-02 14:01:20 --> UTF-8 Support Enabled
INFO - 2024-10-02 14:01:20 --> Utf8 Class Initialized
INFO - 2024-10-02 14:01:20 --> URI Class Initialized
INFO - 2024-10-02 14:01:20 --> Router Class Initialized
INFO - 2024-10-02 14:01:20 --> Output Class Initialized
INFO - 2024-10-02 14:01:20 --> Security Class Initialized
DEBUG - 2024-10-02 14:01:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-02 14:01:20 --> Input Class Initialized
INFO - 2024-10-02 14:01:20 --> Language Class Initialized
INFO - 2024-10-02 14:01:20 --> Language Class Initialized
INFO - 2024-10-02 14:01:20 --> Config Class Initialized
INFO - 2024-10-02 14:01:20 --> Loader Class Initialized
INFO - 2024-10-02 14:01:20 --> Helper loaded: url_helper
INFO - 2024-10-02 14:01:20 --> Helper loaded: file_helper
INFO - 2024-10-02 14:01:20 --> Helper loaded: form_helper
INFO - 2024-10-02 14:01:20 --> Helper loaded: my_helper
INFO - 2024-10-02 14:01:20 --> Database Driver Class Initialized
INFO - 2024-10-02 14:01:20 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-02 14:01:20 --> Controller Class Initialized
DEBUG - 2024-10-02 14:01:20 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_icb/views/list.php
DEBUG - 2024-10-02 14:01:20 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-10-02 14:01:20 --> Final output sent to browser
DEBUG - 2024-10-02 14:01:20 --> Total execution time: 0.0652
INFO - 2024-10-02 14:01:20 --> Config Class Initialized
INFO - 2024-10-02 14:01:20 --> Hooks Class Initialized
DEBUG - 2024-10-02 14:01:20 --> UTF-8 Support Enabled
INFO - 2024-10-02 14:01:20 --> Utf8 Class Initialized
INFO - 2024-10-02 14:01:20 --> URI Class Initialized
INFO - 2024-10-02 14:01:20 --> Router Class Initialized
INFO - 2024-10-02 14:01:20 --> Output Class Initialized
INFO - 2024-10-02 14:01:20 --> Security Class Initialized
DEBUG - 2024-10-02 14:01:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-02 14:01:20 --> Input Class Initialized
INFO - 2024-10-02 14:01:20 --> Language Class Initialized
INFO - 2024-10-02 14:01:20 --> Language Class Initialized
INFO - 2024-10-02 14:01:20 --> Config Class Initialized
INFO - 2024-10-02 14:01:20 --> Loader Class Initialized
INFO - 2024-10-02 14:01:20 --> Helper loaded: url_helper
INFO - 2024-10-02 14:01:20 --> Helper loaded: file_helper
INFO - 2024-10-02 14:01:20 --> Helper loaded: form_helper
INFO - 2024-10-02 14:01:20 --> Helper loaded: my_helper
INFO - 2024-10-02 14:01:20 --> Database Driver Class Initialized
INFO - 2024-10-02 14:01:20 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-02 14:01:20 --> Controller Class Initialized
INFO - 2024-10-02 14:01:31 --> Config Class Initialized
INFO - 2024-10-02 14:01:31 --> Hooks Class Initialized
DEBUG - 2024-10-02 14:01:31 --> UTF-8 Support Enabled
INFO - 2024-10-02 14:01:31 --> Utf8 Class Initialized
INFO - 2024-10-02 14:01:31 --> URI Class Initialized
INFO - 2024-10-02 14:01:31 --> Router Class Initialized
INFO - 2024-10-02 14:01:31 --> Output Class Initialized
INFO - 2024-10-02 14:01:31 --> Security Class Initialized
DEBUG - 2024-10-02 14:01:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-02 14:01:31 --> Input Class Initialized
INFO - 2024-10-02 14:01:31 --> Language Class Initialized
INFO - 2024-10-02 14:01:31 --> Language Class Initialized
INFO - 2024-10-02 14:01:31 --> Config Class Initialized
INFO - 2024-10-02 14:01:31 --> Loader Class Initialized
INFO - 2024-10-02 14:01:31 --> Helper loaded: url_helper
INFO - 2024-10-02 14:01:31 --> Helper loaded: file_helper
INFO - 2024-10-02 14:01:31 --> Helper loaded: form_helper
INFO - 2024-10-02 14:01:31 --> Helper loaded: my_helper
INFO - 2024-10-02 14:01:31 --> Database Driver Class Initialized
INFO - 2024-10-02 14:01:31 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-02 14:01:31 --> Controller Class Initialized
DEBUG - 2024-10-02 14:01:31 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/view_mapel/views/v_view_mapel.php
DEBUG - 2024-10-02 14:01:31 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-10-02 14:01:31 --> Final output sent to browser
DEBUG - 2024-10-02 14:01:31 --> Total execution time: 0.0289
INFO - 2024-10-02 14:01:33 --> Config Class Initialized
INFO - 2024-10-02 14:01:33 --> Hooks Class Initialized
DEBUG - 2024-10-02 14:01:33 --> UTF-8 Support Enabled
INFO - 2024-10-02 14:01:33 --> Utf8 Class Initialized
INFO - 2024-10-02 14:01:33 --> URI Class Initialized
INFO - 2024-10-02 14:01:33 --> Router Class Initialized
INFO - 2024-10-02 14:01:33 --> Output Class Initialized
INFO - 2024-10-02 14:01:33 --> Security Class Initialized
DEBUG - 2024-10-02 14:01:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-02 14:01:33 --> Input Class Initialized
INFO - 2024-10-02 14:01:33 --> Language Class Initialized
INFO - 2024-10-02 14:01:33 --> Language Class Initialized
INFO - 2024-10-02 14:01:33 --> Config Class Initialized
INFO - 2024-10-02 14:01:33 --> Loader Class Initialized
INFO - 2024-10-02 14:01:33 --> Helper loaded: url_helper
INFO - 2024-10-02 14:01:33 --> Helper loaded: file_helper
INFO - 2024-10-02 14:01:33 --> Helper loaded: form_helper
INFO - 2024-10-02 14:01:33 --> Helper loaded: my_helper
INFO - 2024-10-02 14:01:33 --> Database Driver Class Initialized
INFO - 2024-10-02 14:01:33 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-02 14:01:33 --> Controller Class Initialized
DEBUG - 2024-10-02 14:01:33 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pss/views/list.php
DEBUG - 2024-10-02 14:01:33 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-10-02 14:01:33 --> Final output sent to browser
DEBUG - 2024-10-02 14:01:33 --> Total execution time: 0.0322
INFO - 2024-10-02 14:01:33 --> Config Class Initialized
INFO - 2024-10-02 14:01:33 --> Hooks Class Initialized
DEBUG - 2024-10-02 14:01:33 --> UTF-8 Support Enabled
INFO - 2024-10-02 14:01:33 --> Utf8 Class Initialized
INFO - 2024-10-02 14:01:33 --> URI Class Initialized
INFO - 2024-10-02 14:01:33 --> Router Class Initialized
INFO - 2024-10-02 14:01:33 --> Output Class Initialized
INFO - 2024-10-02 14:01:33 --> Security Class Initialized
DEBUG - 2024-10-02 14:01:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-02 14:01:33 --> Input Class Initialized
INFO - 2024-10-02 14:01:33 --> Language Class Initialized
INFO - 2024-10-02 14:01:33 --> Language Class Initialized
INFO - 2024-10-02 14:01:33 --> Config Class Initialized
INFO - 2024-10-02 14:01:33 --> Loader Class Initialized
INFO - 2024-10-02 14:01:33 --> Helper loaded: url_helper
INFO - 2024-10-02 14:01:33 --> Helper loaded: file_helper
INFO - 2024-10-02 14:01:33 --> Helper loaded: form_helper
INFO - 2024-10-02 14:01:33 --> Helper loaded: my_helper
INFO - 2024-10-02 14:01:33 --> Database Driver Class Initialized
INFO - 2024-10-02 14:01:33 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-02 14:01:33 --> Controller Class Initialized
INFO - 2024-10-02 14:01:40 --> Config Class Initialized
INFO - 2024-10-02 14:01:40 --> Hooks Class Initialized
DEBUG - 2024-10-02 14:01:40 --> UTF-8 Support Enabled
INFO - 2024-10-02 14:01:40 --> Utf8 Class Initialized
INFO - 2024-10-02 14:01:40 --> URI Class Initialized
INFO - 2024-10-02 14:01:40 --> Router Class Initialized
INFO - 2024-10-02 14:01:40 --> Output Class Initialized
INFO - 2024-10-02 14:01:40 --> Security Class Initialized
DEBUG - 2024-10-02 14:01:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-02 14:01:40 --> Input Class Initialized
INFO - 2024-10-02 14:01:40 --> Language Class Initialized
INFO - 2024-10-02 14:01:40 --> Language Class Initialized
INFO - 2024-10-02 14:01:40 --> Config Class Initialized
INFO - 2024-10-02 14:01:40 --> Loader Class Initialized
INFO - 2024-10-02 14:01:40 --> Helper loaded: url_helper
INFO - 2024-10-02 14:01:40 --> Helper loaded: file_helper
INFO - 2024-10-02 14:01:40 --> Helper loaded: form_helper
INFO - 2024-10-02 14:01:40 --> Helper loaded: my_helper
INFO - 2024-10-02 14:01:40 --> Database Driver Class Initialized
INFO - 2024-10-02 14:01:40 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-02 14:01:40 --> Controller Class Initialized
DEBUG - 2024-10-02 14:01:40 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/view_mapel/views/v_view_mapel.php
DEBUG - 2024-10-02 14:01:40 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-10-02 14:01:40 --> Final output sent to browser
DEBUG - 2024-10-02 14:01:40 --> Total execution time: 0.0315
INFO - 2024-10-02 14:01:50 --> Config Class Initialized
INFO - 2024-10-02 14:01:50 --> Hooks Class Initialized
DEBUG - 2024-10-02 14:01:50 --> UTF-8 Support Enabled
INFO - 2024-10-02 14:01:50 --> Utf8 Class Initialized
INFO - 2024-10-02 14:01:50 --> URI Class Initialized
INFO - 2024-10-02 14:01:50 --> Router Class Initialized
INFO - 2024-10-02 14:01:50 --> Output Class Initialized
INFO - 2024-10-02 14:01:50 --> Security Class Initialized
DEBUG - 2024-10-02 14:01:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-02 14:01:50 --> Input Class Initialized
INFO - 2024-10-02 14:01:50 --> Language Class Initialized
INFO - 2024-10-02 14:01:50 --> Language Class Initialized
INFO - 2024-10-02 14:01:50 --> Config Class Initialized
INFO - 2024-10-02 14:01:50 --> Loader Class Initialized
INFO - 2024-10-02 14:01:50 --> Helper loaded: url_helper
INFO - 2024-10-02 14:01:50 --> Helper loaded: file_helper
INFO - 2024-10-02 14:01:50 --> Helper loaded: form_helper
INFO - 2024-10-02 14:01:50 --> Helper loaded: my_helper
INFO - 2024-10-02 14:01:50 --> Database Driver Class Initialized
INFO - 2024-10-02 14:01:50 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-02 14:01:50 --> Controller Class Initialized
DEBUG - 2024-10-02 14:01:50 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_la/views/list.php
DEBUG - 2024-10-02 14:01:50 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-10-02 14:01:50 --> Final output sent to browser
DEBUG - 2024-10-02 14:01:50 --> Total execution time: 0.0348
INFO - 2024-10-02 14:01:50 --> Config Class Initialized
INFO - 2024-10-02 14:01:50 --> Hooks Class Initialized
DEBUG - 2024-10-02 14:01:50 --> UTF-8 Support Enabled
INFO - 2024-10-02 14:01:50 --> Utf8 Class Initialized
INFO - 2024-10-02 14:01:50 --> URI Class Initialized
INFO - 2024-10-02 14:01:50 --> Router Class Initialized
INFO - 2024-10-02 14:01:50 --> Output Class Initialized
INFO - 2024-10-02 14:01:50 --> Security Class Initialized
DEBUG - 2024-10-02 14:01:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-02 14:01:50 --> Input Class Initialized
INFO - 2024-10-02 14:01:50 --> Language Class Initialized
INFO - 2024-10-02 14:01:50 --> Language Class Initialized
INFO - 2024-10-02 14:01:50 --> Config Class Initialized
INFO - 2024-10-02 14:01:50 --> Loader Class Initialized
INFO - 2024-10-02 14:01:50 --> Helper loaded: url_helper
INFO - 2024-10-02 14:01:50 --> Helper loaded: file_helper
INFO - 2024-10-02 14:01:50 --> Helper loaded: form_helper
INFO - 2024-10-02 14:01:50 --> Helper loaded: my_helper
INFO - 2024-10-02 14:01:50 --> Database Driver Class Initialized
INFO - 2024-10-02 14:01:50 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-02 14:01:50 --> Controller Class Initialized
INFO - 2024-10-02 14:02:03 --> Config Class Initialized
INFO - 2024-10-02 14:02:03 --> Hooks Class Initialized
DEBUG - 2024-10-02 14:02:03 --> UTF-8 Support Enabled
INFO - 2024-10-02 14:02:03 --> Utf8 Class Initialized
INFO - 2024-10-02 14:02:03 --> URI Class Initialized
INFO - 2024-10-02 14:02:03 --> Router Class Initialized
INFO - 2024-10-02 14:02:03 --> Output Class Initialized
INFO - 2024-10-02 14:02:03 --> Security Class Initialized
DEBUG - 2024-10-02 14:02:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-02 14:02:03 --> Input Class Initialized
INFO - 2024-10-02 14:02:03 --> Language Class Initialized
INFO - 2024-10-02 14:02:03 --> Language Class Initialized
INFO - 2024-10-02 14:02:03 --> Config Class Initialized
INFO - 2024-10-02 14:02:03 --> Loader Class Initialized
INFO - 2024-10-02 14:02:03 --> Helper loaded: url_helper
INFO - 2024-10-02 14:02:03 --> Helper loaded: file_helper
INFO - 2024-10-02 14:02:03 --> Helper loaded: form_helper
INFO - 2024-10-02 14:02:03 --> Helper loaded: my_helper
INFO - 2024-10-02 14:02:03 --> Database Driver Class Initialized
INFO - 2024-10-02 14:02:03 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-02 14:02:03 --> Controller Class Initialized
DEBUG - 2024-10-02 14:02:03 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/view_mapel/views/v_view_mapel.php
DEBUG - 2024-10-02 14:02:03 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-10-02 14:02:03 --> Final output sent to browser
DEBUG - 2024-10-02 14:02:03 --> Total execution time: 0.0386
INFO - 2024-10-02 14:02:08 --> Config Class Initialized
INFO - 2024-10-02 14:02:08 --> Hooks Class Initialized
DEBUG - 2024-10-02 14:02:08 --> UTF-8 Support Enabled
INFO - 2024-10-02 14:02:08 --> Utf8 Class Initialized
INFO - 2024-10-02 14:02:08 --> URI Class Initialized
INFO - 2024-10-02 14:02:08 --> Router Class Initialized
INFO - 2024-10-02 14:02:08 --> Output Class Initialized
INFO - 2024-10-02 14:02:08 --> Security Class Initialized
DEBUG - 2024-10-02 14:02:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-02 14:02:08 --> Input Class Initialized
INFO - 2024-10-02 14:02:08 --> Language Class Initialized
INFO - 2024-10-02 14:02:08 --> Language Class Initialized
INFO - 2024-10-02 14:02:08 --> Config Class Initialized
INFO - 2024-10-02 14:02:08 --> Loader Class Initialized
INFO - 2024-10-02 14:02:08 --> Helper loaded: url_helper
INFO - 2024-10-02 14:02:08 --> Helper loaded: file_helper
INFO - 2024-10-02 14:02:08 --> Helper loaded: form_helper
INFO - 2024-10-02 14:02:08 --> Helper loaded: my_helper
INFO - 2024-10-02 14:02:08 --> Database Driver Class Initialized
INFO - 2024-10-02 14:02:08 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-02 14:02:08 --> Controller Class Initialized
INFO - 2024-10-02 14:02:08 --> Helper loaded: cookie_helper
INFO - 2024-10-02 14:02:08 --> Config Class Initialized
INFO - 2024-10-02 14:02:08 --> Hooks Class Initialized
DEBUG - 2024-10-02 14:02:08 --> UTF-8 Support Enabled
INFO - 2024-10-02 14:02:08 --> Utf8 Class Initialized
INFO - 2024-10-02 14:02:08 --> URI Class Initialized
INFO - 2024-10-02 14:02:08 --> Router Class Initialized
INFO - 2024-10-02 14:02:08 --> Output Class Initialized
INFO - 2024-10-02 14:02:08 --> Security Class Initialized
DEBUG - 2024-10-02 14:02:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-02 14:02:08 --> Input Class Initialized
INFO - 2024-10-02 14:02:08 --> Language Class Initialized
INFO - 2024-10-02 14:02:08 --> Language Class Initialized
INFO - 2024-10-02 14:02:08 --> Config Class Initialized
INFO - 2024-10-02 14:02:08 --> Loader Class Initialized
INFO - 2024-10-02 14:02:08 --> Helper loaded: url_helper
INFO - 2024-10-02 14:02:08 --> Helper loaded: file_helper
INFO - 2024-10-02 14:02:08 --> Helper loaded: form_helper
INFO - 2024-10-02 14:02:08 --> Helper loaded: my_helper
INFO - 2024-10-02 14:02:08 --> Database Driver Class Initialized
INFO - 2024-10-02 14:02:08 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-02 14:02:08 --> Controller Class Initialized
INFO - 2024-10-02 14:02:08 --> Config Class Initialized
INFO - 2024-10-02 14:02:08 --> Hooks Class Initialized
DEBUG - 2024-10-02 14:02:08 --> UTF-8 Support Enabled
INFO - 2024-10-02 14:02:08 --> Utf8 Class Initialized
INFO - 2024-10-02 14:02:08 --> URI Class Initialized
INFO - 2024-10-02 14:02:08 --> Router Class Initialized
INFO - 2024-10-02 14:02:08 --> Output Class Initialized
INFO - 2024-10-02 14:02:08 --> Security Class Initialized
DEBUG - 2024-10-02 14:02:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-02 14:02:08 --> Input Class Initialized
INFO - 2024-10-02 14:02:08 --> Language Class Initialized
INFO - 2024-10-02 14:02:08 --> Language Class Initialized
INFO - 2024-10-02 14:02:08 --> Config Class Initialized
INFO - 2024-10-02 14:02:08 --> Loader Class Initialized
INFO - 2024-10-02 14:02:08 --> Helper loaded: url_helper
INFO - 2024-10-02 14:02:08 --> Helper loaded: file_helper
INFO - 2024-10-02 14:02:08 --> Helper loaded: form_helper
INFO - 2024-10-02 14:02:08 --> Helper loaded: my_helper
INFO - 2024-10-02 14:02:08 --> Database Driver Class Initialized
INFO - 2024-10-02 14:02:08 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-02 14:02:08 --> Controller Class Initialized
DEBUG - 2024-10-02 14:02:08 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/login/views/login.php
DEBUG - 2024-10-02 14:02:08 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-10-02 14:02:08 --> Final output sent to browser
DEBUG - 2024-10-02 14:02:08 --> Total execution time: 0.0301
INFO - 2024-10-02 14:02:08 --> Config Class Initialized
INFO - 2024-10-02 14:02:08 --> Hooks Class Initialized
DEBUG - 2024-10-02 14:02:08 --> UTF-8 Support Enabled
INFO - 2024-10-02 14:02:08 --> Utf8 Class Initialized
INFO - 2024-10-02 14:02:08 --> URI Class Initialized
INFO - 2024-10-02 14:02:08 --> Router Class Initialized
INFO - 2024-10-02 14:02:08 --> Output Class Initialized
INFO - 2024-10-02 14:02:08 --> Security Class Initialized
DEBUG - 2024-10-02 14:02:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-02 14:02:08 --> Input Class Initialized
INFO - 2024-10-02 14:02:08 --> Language Class Initialized
INFO - 2024-10-02 14:02:08 --> Language Class Initialized
INFO - 2024-10-02 14:02:08 --> Config Class Initialized
INFO - 2024-10-02 14:02:08 --> Loader Class Initialized
INFO - 2024-10-02 14:02:08 --> Helper loaded: url_helper
INFO - 2024-10-02 14:02:08 --> Helper loaded: file_helper
INFO - 2024-10-02 14:02:08 --> Helper loaded: form_helper
INFO - 2024-10-02 14:02:08 --> Helper loaded: my_helper
INFO - 2024-10-02 14:02:08 --> Database Driver Class Initialized
INFO - 2024-10-02 14:02:08 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-02 14:02:08 --> Controller Class Initialized
DEBUG - 2024-10-02 14:02:08 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/views/list.php
DEBUG - 2024-10-02 14:02:08 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-10-02 14:02:08 --> Final output sent to browser
DEBUG - 2024-10-02 14:02:08 --> Total execution time: 0.0350
INFO - 2024-10-02 14:02:08 --> Config Class Initialized
INFO - 2024-10-02 14:02:08 --> Hooks Class Initialized
DEBUG - 2024-10-02 14:02:08 --> UTF-8 Support Enabled
INFO - 2024-10-02 14:02:08 --> Utf8 Class Initialized
INFO - 2024-10-02 14:02:08 --> URI Class Initialized
INFO - 2024-10-02 14:02:08 --> Router Class Initialized
INFO - 2024-10-02 14:02:08 --> Output Class Initialized
INFO - 2024-10-02 14:02:08 --> Security Class Initialized
DEBUG - 2024-10-02 14:02:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-02 14:02:08 --> Input Class Initialized
INFO - 2024-10-02 14:02:08 --> Language Class Initialized
INFO - 2024-10-02 14:02:08 --> Language Class Initialized
INFO - 2024-10-02 14:02:08 --> Config Class Initialized
INFO - 2024-10-02 14:02:08 --> Loader Class Initialized
INFO - 2024-10-02 14:02:08 --> Helper loaded: url_helper
INFO - 2024-10-02 14:02:08 --> Helper loaded: file_helper
INFO - 2024-10-02 14:02:08 --> Helper loaded: form_helper
INFO - 2024-10-02 14:02:08 --> Helper loaded: my_helper
INFO - 2024-10-02 14:02:08 --> Database Driver Class Initialized
INFO - 2024-10-02 14:02:08 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-02 14:02:08 --> Controller Class Initialized
INFO - 2024-10-02 14:02:13 --> Config Class Initialized
INFO - 2024-10-02 14:02:13 --> Hooks Class Initialized
DEBUG - 2024-10-02 14:02:13 --> UTF-8 Support Enabled
INFO - 2024-10-02 14:02:13 --> Utf8 Class Initialized
INFO - 2024-10-02 14:02:13 --> URI Class Initialized
INFO - 2024-10-02 14:02:13 --> Router Class Initialized
INFO - 2024-10-02 14:02:13 --> Output Class Initialized
INFO - 2024-10-02 14:02:13 --> Security Class Initialized
DEBUG - 2024-10-02 14:02:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-02 14:02:13 --> Input Class Initialized
INFO - 2024-10-02 14:02:13 --> Language Class Initialized
INFO - 2024-10-02 14:02:13 --> Language Class Initialized
INFO - 2024-10-02 14:02:13 --> Config Class Initialized
INFO - 2024-10-02 14:02:13 --> Loader Class Initialized
INFO - 2024-10-02 14:02:13 --> Helper loaded: url_helper
INFO - 2024-10-02 14:02:13 --> Helper loaded: file_helper
INFO - 2024-10-02 14:02:13 --> Helper loaded: form_helper
INFO - 2024-10-02 14:02:13 --> Helper loaded: my_helper
INFO - 2024-10-02 14:02:13 --> Database Driver Class Initialized
INFO - 2024-10-02 14:02:13 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-02 14:02:13 --> Controller Class Initialized
INFO - 2024-10-02 14:02:13 --> Helper loaded: cookie_helper
INFO - 2024-10-02 14:02:13 --> Final output sent to browser
DEBUG - 2024-10-02 14:02:13 --> Total execution time: 0.0300
INFO - 2024-10-02 14:02:13 --> Config Class Initialized
INFO - 2024-10-02 14:02:13 --> Hooks Class Initialized
DEBUG - 2024-10-02 14:02:13 --> UTF-8 Support Enabled
INFO - 2024-10-02 14:02:13 --> Utf8 Class Initialized
INFO - 2024-10-02 14:02:13 --> URI Class Initialized
INFO - 2024-10-02 14:02:13 --> Router Class Initialized
INFO - 2024-10-02 14:02:13 --> Output Class Initialized
INFO - 2024-10-02 14:02:13 --> Security Class Initialized
DEBUG - 2024-10-02 14:02:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-02 14:02:13 --> Input Class Initialized
INFO - 2024-10-02 14:02:13 --> Language Class Initialized
INFO - 2024-10-02 14:02:13 --> Language Class Initialized
INFO - 2024-10-02 14:02:13 --> Config Class Initialized
INFO - 2024-10-02 14:02:13 --> Loader Class Initialized
INFO - 2024-10-02 14:02:13 --> Helper loaded: url_helper
INFO - 2024-10-02 14:02:13 --> Helper loaded: file_helper
INFO - 2024-10-02 14:02:13 --> Helper loaded: form_helper
INFO - 2024-10-02 14:02:13 --> Helper loaded: my_helper
INFO - 2024-10-02 14:02:13 --> Database Driver Class Initialized
INFO - 2024-10-02 14:02:13 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-02 14:02:13 --> Controller Class Initialized
DEBUG - 2024-10-02 14:02:13 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/home/views/v_home_guru.php
DEBUG - 2024-10-02 14:02:13 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-10-02 14:02:13 --> Final output sent to browser
DEBUG - 2024-10-02 14:02:13 --> Total execution time: 0.0327
INFO - 2024-10-02 14:02:21 --> Config Class Initialized
INFO - 2024-10-02 14:02:21 --> Hooks Class Initialized
DEBUG - 2024-10-02 14:02:21 --> UTF-8 Support Enabled
INFO - 2024-10-02 14:02:21 --> Utf8 Class Initialized
INFO - 2024-10-02 14:02:21 --> URI Class Initialized
INFO - 2024-10-02 14:02:21 --> Router Class Initialized
INFO - 2024-10-02 14:02:21 --> Output Class Initialized
INFO - 2024-10-02 14:02:21 --> Security Class Initialized
DEBUG - 2024-10-02 14:02:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-02 14:02:21 --> Input Class Initialized
INFO - 2024-10-02 14:02:21 --> Language Class Initialized
INFO - 2024-10-02 14:02:21 --> Language Class Initialized
INFO - 2024-10-02 14:02:21 --> Config Class Initialized
INFO - 2024-10-02 14:02:21 --> Loader Class Initialized
INFO - 2024-10-02 14:02:21 --> Helper loaded: url_helper
INFO - 2024-10-02 14:02:21 --> Helper loaded: file_helper
INFO - 2024-10-02 14:02:21 --> Helper loaded: form_helper
INFO - 2024-10-02 14:02:21 --> Helper loaded: my_helper
INFO - 2024-10-02 14:02:21 --> Database Driver Class Initialized
INFO - 2024-10-02 14:02:21 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-02 14:02:21 --> Controller Class Initialized
INFO - 2024-10-02 14:02:21 --> Final output sent to browser
DEBUG - 2024-10-02 14:02:21 --> Total execution time: 0.0338
INFO - 2024-10-02 14:02:53 --> Config Class Initialized
INFO - 2024-10-02 14:02:53 --> Hooks Class Initialized
DEBUG - 2024-10-02 14:02:53 --> UTF-8 Support Enabled
INFO - 2024-10-02 14:02:53 --> Utf8 Class Initialized
INFO - 2024-10-02 14:02:53 --> URI Class Initialized
INFO - 2024-10-02 14:02:53 --> Router Class Initialized
INFO - 2024-10-02 14:02:53 --> Output Class Initialized
INFO - 2024-10-02 14:02:53 --> Security Class Initialized
DEBUG - 2024-10-02 14:02:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-02 14:02:53 --> Input Class Initialized
INFO - 2024-10-02 14:02:53 --> Language Class Initialized
INFO - 2024-10-02 14:02:53 --> Language Class Initialized
INFO - 2024-10-02 14:02:53 --> Config Class Initialized
INFO - 2024-10-02 14:02:53 --> Loader Class Initialized
INFO - 2024-10-02 14:02:53 --> Helper loaded: url_helper
INFO - 2024-10-02 14:02:53 --> Helper loaded: file_helper
INFO - 2024-10-02 14:02:53 --> Helper loaded: form_helper
INFO - 2024-10-02 14:02:53 --> Helper loaded: my_helper
INFO - 2024-10-02 14:02:53 --> Database Driver Class Initialized
INFO - 2024-10-02 14:02:53 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-02 14:02:53 --> Controller Class Initialized
DEBUG - 2024-10-02 14:02:53 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/view_mapel/views/v_view_mapel.php
DEBUG - 2024-10-02 14:02:53 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-10-02 14:02:53 --> Final output sent to browser
DEBUG - 2024-10-02 14:02:53 --> Total execution time: 0.0469
INFO - 2024-10-02 14:02:59 --> Config Class Initialized
INFO - 2024-10-02 14:02:59 --> Hooks Class Initialized
DEBUG - 2024-10-02 14:02:59 --> UTF-8 Support Enabled
INFO - 2024-10-02 14:02:59 --> Utf8 Class Initialized
INFO - 2024-10-02 14:02:59 --> URI Class Initialized
INFO - 2024-10-02 14:02:59 --> Router Class Initialized
INFO - 2024-10-02 14:02:59 --> Output Class Initialized
INFO - 2024-10-02 14:02:59 --> Security Class Initialized
DEBUG - 2024-10-02 14:02:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-02 14:02:59 --> Input Class Initialized
INFO - 2024-10-02 14:02:59 --> Language Class Initialized
INFO - 2024-10-02 14:02:59 --> Language Class Initialized
INFO - 2024-10-02 14:02:59 --> Config Class Initialized
INFO - 2024-10-02 14:02:59 --> Loader Class Initialized
INFO - 2024-10-02 14:02:59 --> Helper loaded: url_helper
INFO - 2024-10-02 14:03:00 --> Helper loaded: file_helper
INFO - 2024-10-02 14:03:00 --> Helper loaded: form_helper
INFO - 2024-10-02 14:03:00 --> Helper loaded: my_helper
INFO - 2024-10-02 14:03:00 --> Database Driver Class Initialized
INFO - 2024-10-02 14:03:00 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-02 14:03:00 --> Controller Class Initialized
DEBUG - 2024-10-02 14:03:00 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_icb/views/list.php
DEBUG - 2024-10-02 14:03:00 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-10-02 14:03:00 --> Final output sent to browser
DEBUG - 2024-10-02 14:03:00 --> Total execution time: 0.0382
INFO - 2024-10-02 14:03:00 --> Config Class Initialized
INFO - 2024-10-02 14:03:00 --> Hooks Class Initialized
DEBUG - 2024-10-02 14:03:00 --> UTF-8 Support Enabled
INFO - 2024-10-02 14:03:00 --> Utf8 Class Initialized
INFO - 2024-10-02 14:03:00 --> URI Class Initialized
INFO - 2024-10-02 14:03:00 --> Router Class Initialized
INFO - 2024-10-02 14:03:00 --> Output Class Initialized
INFO - 2024-10-02 14:03:00 --> Security Class Initialized
DEBUG - 2024-10-02 14:03:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-02 14:03:00 --> Input Class Initialized
INFO - 2024-10-02 14:03:00 --> Language Class Initialized
INFO - 2024-10-02 14:03:00 --> Language Class Initialized
INFO - 2024-10-02 14:03:00 --> Config Class Initialized
INFO - 2024-10-02 14:03:00 --> Loader Class Initialized
INFO - 2024-10-02 14:03:00 --> Helper loaded: url_helper
INFO - 2024-10-02 14:03:00 --> Helper loaded: file_helper
INFO - 2024-10-02 14:03:00 --> Helper loaded: form_helper
INFO - 2024-10-02 14:03:00 --> Helper loaded: my_helper
INFO - 2024-10-02 14:03:00 --> Database Driver Class Initialized
INFO - 2024-10-02 14:03:00 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-02 14:03:00 --> Controller Class Initialized
INFO - 2024-10-02 14:03:02 --> Config Class Initialized
INFO - 2024-10-02 14:03:02 --> Hooks Class Initialized
DEBUG - 2024-10-02 14:03:02 --> UTF-8 Support Enabled
INFO - 2024-10-02 14:03:02 --> Utf8 Class Initialized
INFO - 2024-10-02 14:03:02 --> URI Class Initialized
INFO - 2024-10-02 14:03:02 --> Router Class Initialized
INFO - 2024-10-02 14:03:02 --> Output Class Initialized
INFO - 2024-10-02 14:03:02 --> Security Class Initialized
DEBUG - 2024-10-02 14:03:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-02 14:03:02 --> Input Class Initialized
INFO - 2024-10-02 14:03:02 --> Language Class Initialized
INFO - 2024-10-02 14:03:02 --> Language Class Initialized
INFO - 2024-10-02 14:03:02 --> Config Class Initialized
INFO - 2024-10-02 14:03:02 --> Loader Class Initialized
INFO - 2024-10-02 14:03:02 --> Helper loaded: url_helper
INFO - 2024-10-02 14:03:02 --> Helper loaded: file_helper
INFO - 2024-10-02 14:03:02 --> Helper loaded: form_helper
INFO - 2024-10-02 14:03:02 --> Helper loaded: my_helper
INFO - 2024-10-02 14:03:02 --> Database Driver Class Initialized
INFO - 2024-10-02 14:03:02 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-02 14:03:02 --> Controller Class Initialized
INFO - 2024-10-02 14:03:02 --> Final output sent to browser
DEBUG - 2024-10-02 14:03:02 --> Total execution time: 0.0530
INFO - 2024-10-02 14:03:02 --> Config Class Initialized
INFO - 2024-10-02 14:03:02 --> Hooks Class Initialized
DEBUG - 2024-10-02 14:03:02 --> UTF-8 Support Enabled
INFO - 2024-10-02 14:03:02 --> Utf8 Class Initialized
INFO - 2024-10-02 14:03:02 --> URI Class Initialized
INFO - 2024-10-02 14:03:02 --> Router Class Initialized
INFO - 2024-10-02 14:03:02 --> Output Class Initialized
INFO - 2024-10-02 14:03:02 --> Security Class Initialized
DEBUG - 2024-10-02 14:03:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-02 14:03:02 --> Input Class Initialized
INFO - 2024-10-02 14:03:02 --> Language Class Initialized
INFO - 2024-10-02 14:03:02 --> Language Class Initialized
INFO - 2024-10-02 14:03:02 --> Config Class Initialized
INFO - 2024-10-02 14:03:02 --> Loader Class Initialized
INFO - 2024-10-02 14:03:02 --> Helper loaded: url_helper
INFO - 2024-10-02 14:03:02 --> Helper loaded: file_helper
INFO - 2024-10-02 14:03:02 --> Helper loaded: form_helper
INFO - 2024-10-02 14:03:02 --> Helper loaded: my_helper
INFO - 2024-10-02 14:03:02 --> Database Driver Class Initialized
INFO - 2024-10-02 14:03:02 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-02 14:03:02 --> Controller Class Initialized
INFO - 2024-10-02 14:03:04 --> Config Class Initialized
INFO - 2024-10-02 14:03:04 --> Hooks Class Initialized
DEBUG - 2024-10-02 14:03:04 --> UTF-8 Support Enabled
INFO - 2024-10-02 14:03:04 --> Utf8 Class Initialized
INFO - 2024-10-02 14:03:04 --> URI Class Initialized
INFO - 2024-10-02 14:03:04 --> Router Class Initialized
INFO - 2024-10-02 14:03:04 --> Output Class Initialized
INFO - 2024-10-02 14:03:04 --> Security Class Initialized
DEBUG - 2024-10-02 14:03:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-02 14:03:04 --> Input Class Initialized
INFO - 2024-10-02 14:03:04 --> Language Class Initialized
INFO - 2024-10-02 14:03:04 --> Language Class Initialized
INFO - 2024-10-02 14:03:04 --> Config Class Initialized
INFO - 2024-10-02 14:03:04 --> Loader Class Initialized
INFO - 2024-10-02 14:03:04 --> Helper loaded: url_helper
INFO - 2024-10-02 14:03:04 --> Helper loaded: file_helper
INFO - 2024-10-02 14:03:04 --> Helper loaded: form_helper
INFO - 2024-10-02 14:03:04 --> Helper loaded: my_helper
INFO - 2024-10-02 14:03:04 --> Database Driver Class Initialized
INFO - 2024-10-02 14:03:04 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-02 14:03:04 --> Controller Class Initialized
INFO - 2024-10-02 14:03:04 --> Final output sent to browser
DEBUG - 2024-10-02 14:03:04 --> Total execution time: 0.0439
INFO - 2024-10-02 14:03:04 --> Config Class Initialized
INFO - 2024-10-02 14:03:04 --> Hooks Class Initialized
DEBUG - 2024-10-02 14:03:04 --> UTF-8 Support Enabled
INFO - 2024-10-02 14:03:04 --> Utf8 Class Initialized
INFO - 2024-10-02 14:03:04 --> URI Class Initialized
INFO - 2024-10-02 14:03:04 --> Router Class Initialized
INFO - 2024-10-02 14:03:04 --> Output Class Initialized
INFO - 2024-10-02 14:03:04 --> Security Class Initialized
DEBUG - 2024-10-02 14:03:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-02 14:03:04 --> Input Class Initialized
INFO - 2024-10-02 14:03:04 --> Language Class Initialized
INFO - 2024-10-02 14:03:04 --> Language Class Initialized
INFO - 2024-10-02 14:03:04 --> Config Class Initialized
INFO - 2024-10-02 14:03:04 --> Loader Class Initialized
INFO - 2024-10-02 14:03:04 --> Helper loaded: url_helper
INFO - 2024-10-02 14:03:04 --> Helper loaded: file_helper
INFO - 2024-10-02 14:03:04 --> Helper loaded: form_helper
INFO - 2024-10-02 14:03:04 --> Helper loaded: my_helper
INFO - 2024-10-02 14:03:04 --> Database Driver Class Initialized
INFO - 2024-10-02 14:03:04 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-02 14:03:04 --> Controller Class Initialized
INFO - 2024-10-02 14:03:04 --> Config Class Initialized
INFO - 2024-10-02 14:03:04 --> Hooks Class Initialized
DEBUG - 2024-10-02 14:03:04 --> UTF-8 Support Enabled
INFO - 2024-10-02 14:03:04 --> Utf8 Class Initialized
INFO - 2024-10-02 14:03:04 --> URI Class Initialized
INFO - 2024-10-02 14:03:04 --> Router Class Initialized
INFO - 2024-10-02 14:03:04 --> Output Class Initialized
INFO - 2024-10-02 14:03:04 --> Security Class Initialized
DEBUG - 2024-10-02 14:03:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-02 14:03:04 --> Input Class Initialized
INFO - 2024-10-02 14:03:04 --> Language Class Initialized
INFO - 2024-10-02 14:03:05 --> Language Class Initialized
INFO - 2024-10-02 14:03:05 --> Config Class Initialized
INFO - 2024-10-02 14:03:05 --> Loader Class Initialized
INFO - 2024-10-02 14:03:05 --> Helper loaded: url_helper
INFO - 2024-10-02 14:03:05 --> Helper loaded: file_helper
INFO - 2024-10-02 14:03:05 --> Helper loaded: form_helper
INFO - 2024-10-02 14:03:05 --> Helper loaded: my_helper
INFO - 2024-10-02 14:03:05 --> Database Driver Class Initialized
INFO - 2024-10-02 14:03:05 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-02 14:03:05 --> Controller Class Initialized
DEBUG - 2024-10-02 14:03:05 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/view_mapel/views/v_view_mapel.php
DEBUG - 2024-10-02 14:03:05 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-10-02 14:03:05 --> Final output sent to browser
DEBUG - 2024-10-02 14:03:05 --> Total execution time: 0.0315
INFO - 2024-10-02 14:03:06 --> Config Class Initialized
INFO - 2024-10-02 14:03:06 --> Hooks Class Initialized
DEBUG - 2024-10-02 14:03:06 --> UTF-8 Support Enabled
INFO - 2024-10-02 14:03:06 --> Utf8 Class Initialized
INFO - 2024-10-02 14:03:06 --> URI Class Initialized
INFO - 2024-10-02 14:03:06 --> Router Class Initialized
INFO - 2024-10-02 14:03:06 --> Output Class Initialized
INFO - 2024-10-02 14:03:06 --> Security Class Initialized
DEBUG - 2024-10-02 14:03:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-02 14:03:06 --> Input Class Initialized
INFO - 2024-10-02 14:03:06 --> Language Class Initialized
INFO - 2024-10-02 14:03:06 --> Language Class Initialized
INFO - 2024-10-02 14:03:06 --> Config Class Initialized
INFO - 2024-10-02 14:03:06 --> Loader Class Initialized
INFO - 2024-10-02 14:03:06 --> Helper loaded: url_helper
INFO - 2024-10-02 14:03:06 --> Helper loaded: file_helper
INFO - 2024-10-02 14:03:06 --> Helper loaded: form_helper
INFO - 2024-10-02 14:03:06 --> Helper loaded: my_helper
INFO - 2024-10-02 14:03:06 --> Database Driver Class Initialized
INFO - 2024-10-02 14:03:06 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-02 14:03:06 --> Controller Class Initialized
INFO - 2024-10-02 14:03:06 --> Final output sent to browser
DEBUG - 2024-10-02 14:03:06 --> Total execution time: 0.0389
INFO - 2024-10-02 14:03:06 --> Config Class Initialized
INFO - 2024-10-02 14:03:06 --> Hooks Class Initialized
DEBUG - 2024-10-02 14:03:06 --> UTF-8 Support Enabled
INFO - 2024-10-02 14:03:06 --> Utf8 Class Initialized
INFO - 2024-10-02 14:03:06 --> URI Class Initialized
INFO - 2024-10-02 14:03:06 --> Router Class Initialized
INFO - 2024-10-02 14:03:06 --> Output Class Initialized
INFO - 2024-10-02 14:03:06 --> Security Class Initialized
DEBUG - 2024-10-02 14:03:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-02 14:03:06 --> Input Class Initialized
INFO - 2024-10-02 14:03:06 --> Language Class Initialized
INFO - 2024-10-02 14:03:06 --> Language Class Initialized
INFO - 2024-10-02 14:03:06 --> Config Class Initialized
INFO - 2024-10-02 14:03:06 --> Loader Class Initialized
INFO - 2024-10-02 14:03:06 --> Helper loaded: url_helper
INFO - 2024-10-02 14:03:06 --> Helper loaded: file_helper
INFO - 2024-10-02 14:03:06 --> Helper loaded: form_helper
INFO - 2024-10-02 14:03:06 --> Helper loaded: my_helper
INFO - 2024-10-02 14:03:06 --> Database Driver Class Initialized
INFO - 2024-10-02 14:03:06 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-02 14:03:06 --> Controller Class Initialized
INFO - 2024-10-02 14:03:07 --> Config Class Initialized
INFO - 2024-10-02 14:03:07 --> Hooks Class Initialized
DEBUG - 2024-10-02 14:03:07 --> UTF-8 Support Enabled
INFO - 2024-10-02 14:03:07 --> Utf8 Class Initialized
INFO - 2024-10-02 14:03:07 --> URI Class Initialized
INFO - 2024-10-02 14:03:07 --> Router Class Initialized
INFO - 2024-10-02 14:03:07 --> Output Class Initialized
INFO - 2024-10-02 14:03:07 --> Security Class Initialized
DEBUG - 2024-10-02 14:03:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-02 14:03:07 --> Input Class Initialized
INFO - 2024-10-02 14:03:07 --> Language Class Initialized
INFO - 2024-10-02 14:03:07 --> Language Class Initialized
INFO - 2024-10-02 14:03:07 --> Config Class Initialized
INFO - 2024-10-02 14:03:07 --> Loader Class Initialized
INFO - 2024-10-02 14:03:07 --> Helper loaded: url_helper
INFO - 2024-10-02 14:03:07 --> Helper loaded: file_helper
INFO - 2024-10-02 14:03:07 --> Helper loaded: form_helper
INFO - 2024-10-02 14:03:07 --> Helper loaded: my_helper
INFO - 2024-10-02 14:03:07 --> Database Driver Class Initialized
INFO - 2024-10-02 14:03:07 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-02 14:03:07 --> Controller Class Initialized
DEBUG - 2024-10-02 14:03:07 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pss/views/list.php
DEBUG - 2024-10-02 14:03:07 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-10-02 14:03:07 --> Final output sent to browser
DEBUG - 2024-10-02 14:03:07 --> Total execution time: 0.0367
INFO - 2024-10-02 14:03:07 --> Config Class Initialized
INFO - 2024-10-02 14:03:07 --> Hooks Class Initialized
DEBUG - 2024-10-02 14:03:07 --> UTF-8 Support Enabled
INFO - 2024-10-02 14:03:07 --> Utf8 Class Initialized
INFO - 2024-10-02 14:03:07 --> URI Class Initialized
INFO - 2024-10-02 14:03:07 --> Router Class Initialized
INFO - 2024-10-02 14:03:07 --> Output Class Initialized
INFO - 2024-10-02 14:03:07 --> Security Class Initialized
DEBUG - 2024-10-02 14:03:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-02 14:03:07 --> Input Class Initialized
INFO - 2024-10-02 14:03:07 --> Language Class Initialized
INFO - 2024-10-02 14:03:07 --> Language Class Initialized
INFO - 2024-10-02 14:03:07 --> Config Class Initialized
INFO - 2024-10-02 14:03:07 --> Loader Class Initialized
INFO - 2024-10-02 14:03:07 --> Helper loaded: url_helper
INFO - 2024-10-02 14:03:07 --> Helper loaded: file_helper
INFO - 2024-10-02 14:03:07 --> Helper loaded: form_helper
INFO - 2024-10-02 14:03:07 --> Helper loaded: my_helper
INFO - 2024-10-02 14:03:07 --> Database Driver Class Initialized
INFO - 2024-10-02 14:03:07 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-02 14:03:07 --> Controller Class Initialized
INFO - 2024-10-02 14:03:08 --> Config Class Initialized
INFO - 2024-10-02 14:03:08 --> Hooks Class Initialized
DEBUG - 2024-10-02 14:03:08 --> UTF-8 Support Enabled
INFO - 2024-10-02 14:03:08 --> Utf8 Class Initialized
INFO - 2024-10-02 14:03:08 --> URI Class Initialized
INFO - 2024-10-02 14:03:08 --> Router Class Initialized
INFO - 2024-10-02 14:03:08 --> Output Class Initialized
INFO - 2024-10-02 14:03:08 --> Security Class Initialized
DEBUG - 2024-10-02 14:03:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-02 14:03:08 --> Input Class Initialized
INFO - 2024-10-02 14:03:08 --> Language Class Initialized
INFO - 2024-10-02 14:03:08 --> Language Class Initialized
INFO - 2024-10-02 14:03:08 --> Config Class Initialized
INFO - 2024-10-02 14:03:08 --> Loader Class Initialized
INFO - 2024-10-02 14:03:08 --> Helper loaded: url_helper
INFO - 2024-10-02 14:03:08 --> Helper loaded: file_helper
INFO - 2024-10-02 14:03:08 --> Helper loaded: form_helper
INFO - 2024-10-02 14:03:08 --> Helper loaded: my_helper
INFO - 2024-10-02 14:03:08 --> Database Driver Class Initialized
INFO - 2024-10-02 14:03:08 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-02 14:03:08 --> Controller Class Initialized
INFO - 2024-10-02 14:03:08 --> Final output sent to browser
DEBUG - 2024-10-02 14:03:08 --> Total execution time: 0.0348
INFO - 2024-10-02 14:03:08 --> Config Class Initialized
INFO - 2024-10-02 14:03:08 --> Hooks Class Initialized
DEBUG - 2024-10-02 14:03:08 --> UTF-8 Support Enabled
INFO - 2024-10-02 14:03:08 --> Utf8 Class Initialized
INFO - 2024-10-02 14:03:08 --> URI Class Initialized
INFO - 2024-10-02 14:03:08 --> Router Class Initialized
INFO - 2024-10-02 14:03:08 --> Output Class Initialized
INFO - 2024-10-02 14:03:08 --> Security Class Initialized
DEBUG - 2024-10-02 14:03:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-02 14:03:08 --> Input Class Initialized
INFO - 2024-10-02 14:03:08 --> Language Class Initialized
INFO - 2024-10-02 14:03:08 --> Language Class Initialized
INFO - 2024-10-02 14:03:08 --> Config Class Initialized
INFO - 2024-10-02 14:03:08 --> Loader Class Initialized
INFO - 2024-10-02 14:03:08 --> Helper loaded: url_helper
INFO - 2024-10-02 14:03:08 --> Helper loaded: file_helper
INFO - 2024-10-02 14:03:08 --> Helper loaded: form_helper
INFO - 2024-10-02 14:03:08 --> Helper loaded: my_helper
INFO - 2024-10-02 14:03:08 --> Database Driver Class Initialized
INFO - 2024-10-02 14:03:08 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-02 14:03:08 --> Controller Class Initialized
INFO - 2024-10-02 14:03:09 --> Config Class Initialized
INFO - 2024-10-02 14:03:09 --> Hooks Class Initialized
DEBUG - 2024-10-02 14:03:09 --> UTF-8 Support Enabled
INFO - 2024-10-02 14:03:09 --> Utf8 Class Initialized
INFO - 2024-10-02 14:03:09 --> URI Class Initialized
INFO - 2024-10-02 14:03:09 --> Router Class Initialized
INFO - 2024-10-02 14:03:09 --> Output Class Initialized
INFO - 2024-10-02 14:03:09 --> Security Class Initialized
DEBUG - 2024-10-02 14:03:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-02 14:03:09 --> Input Class Initialized
INFO - 2024-10-02 14:03:09 --> Language Class Initialized
INFO - 2024-10-02 14:03:09 --> Language Class Initialized
INFO - 2024-10-02 14:03:09 --> Config Class Initialized
INFO - 2024-10-02 14:03:09 --> Loader Class Initialized
INFO - 2024-10-02 14:03:09 --> Helper loaded: url_helper
INFO - 2024-10-02 14:03:09 --> Helper loaded: file_helper
INFO - 2024-10-02 14:03:09 --> Helper loaded: form_helper
INFO - 2024-10-02 14:03:09 --> Helper loaded: my_helper
INFO - 2024-10-02 14:03:09 --> Database Driver Class Initialized
INFO - 2024-10-02 14:03:09 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-02 14:03:09 --> Controller Class Initialized
INFO - 2024-10-02 14:03:10 --> Final output sent to browser
DEBUG - 2024-10-02 14:03:10 --> Total execution time: 0.0496
INFO - 2024-10-02 14:03:10 --> Config Class Initialized
INFO - 2024-10-02 14:03:10 --> Hooks Class Initialized
DEBUG - 2024-10-02 14:03:10 --> UTF-8 Support Enabled
INFO - 2024-10-02 14:03:10 --> Utf8 Class Initialized
INFO - 2024-10-02 14:03:10 --> URI Class Initialized
INFO - 2024-10-02 14:03:10 --> Router Class Initialized
INFO - 2024-10-02 14:03:10 --> Output Class Initialized
INFO - 2024-10-02 14:03:10 --> Security Class Initialized
DEBUG - 2024-10-02 14:03:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-02 14:03:10 --> Input Class Initialized
INFO - 2024-10-02 14:03:10 --> Language Class Initialized
INFO - 2024-10-02 14:03:10 --> Language Class Initialized
INFO - 2024-10-02 14:03:10 --> Config Class Initialized
INFO - 2024-10-02 14:03:10 --> Loader Class Initialized
INFO - 2024-10-02 14:03:10 --> Helper loaded: url_helper
INFO - 2024-10-02 14:03:10 --> Helper loaded: file_helper
INFO - 2024-10-02 14:03:10 --> Helper loaded: form_helper
INFO - 2024-10-02 14:03:10 --> Helper loaded: my_helper
INFO - 2024-10-02 14:03:10 --> Database Driver Class Initialized
INFO - 2024-10-02 14:03:10 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-02 14:03:10 --> Controller Class Initialized
INFO - 2024-10-02 14:03:10 --> Config Class Initialized
INFO - 2024-10-02 14:03:10 --> Hooks Class Initialized
DEBUG - 2024-10-02 14:03:10 --> UTF-8 Support Enabled
INFO - 2024-10-02 14:03:10 --> Utf8 Class Initialized
INFO - 2024-10-02 14:03:10 --> URI Class Initialized
INFO - 2024-10-02 14:03:10 --> Router Class Initialized
INFO - 2024-10-02 14:03:10 --> Output Class Initialized
INFO - 2024-10-02 14:03:10 --> Security Class Initialized
DEBUG - 2024-10-02 14:03:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-02 14:03:10 --> Input Class Initialized
INFO - 2024-10-02 14:03:10 --> Language Class Initialized
INFO - 2024-10-02 14:03:10 --> Language Class Initialized
INFO - 2024-10-02 14:03:10 --> Config Class Initialized
INFO - 2024-10-02 14:03:10 --> Loader Class Initialized
INFO - 2024-10-02 14:03:10 --> Helper loaded: url_helper
INFO - 2024-10-02 14:03:10 --> Helper loaded: file_helper
INFO - 2024-10-02 14:03:10 --> Helper loaded: form_helper
INFO - 2024-10-02 14:03:10 --> Helper loaded: my_helper
INFO - 2024-10-02 14:03:10 --> Database Driver Class Initialized
INFO - 2024-10-02 14:03:10 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-02 14:03:10 --> Controller Class Initialized
DEBUG - 2024-10-02 14:03:10 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/view_mapel/views/v_view_mapel.php
DEBUG - 2024-10-02 14:03:10 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-10-02 14:03:10 --> Final output sent to browser
DEBUG - 2024-10-02 14:03:10 --> Total execution time: 0.0329
INFO - 2024-10-02 14:03:12 --> Config Class Initialized
INFO - 2024-10-02 14:03:12 --> Hooks Class Initialized
DEBUG - 2024-10-02 14:03:12 --> UTF-8 Support Enabled
INFO - 2024-10-02 14:03:12 --> Utf8 Class Initialized
INFO - 2024-10-02 14:03:12 --> URI Class Initialized
INFO - 2024-10-02 14:03:12 --> Router Class Initialized
INFO - 2024-10-02 14:03:12 --> Output Class Initialized
INFO - 2024-10-02 14:03:12 --> Security Class Initialized
DEBUG - 2024-10-02 14:03:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-02 14:03:12 --> Input Class Initialized
INFO - 2024-10-02 14:03:12 --> Language Class Initialized
INFO - 2024-10-02 14:03:12 --> Language Class Initialized
INFO - 2024-10-02 14:03:12 --> Config Class Initialized
INFO - 2024-10-02 14:03:12 --> Loader Class Initialized
INFO - 2024-10-02 14:03:12 --> Helper loaded: url_helper
INFO - 2024-10-02 14:03:12 --> Helper loaded: file_helper
INFO - 2024-10-02 14:03:12 --> Helper loaded: form_helper
INFO - 2024-10-02 14:03:12 --> Helper loaded: my_helper
INFO - 2024-10-02 14:03:12 --> Database Driver Class Initialized
INFO - 2024-10-02 14:03:12 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-02 14:03:12 --> Controller Class Initialized
DEBUG - 2024-10-02 14:03:12 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_la/views/list.php
DEBUG - 2024-10-02 14:03:12 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-10-02 14:03:12 --> Final output sent to browser
DEBUG - 2024-10-02 14:03:12 --> Total execution time: 0.0306
INFO - 2024-10-02 14:03:12 --> Config Class Initialized
INFO - 2024-10-02 14:03:12 --> Hooks Class Initialized
DEBUG - 2024-10-02 14:03:12 --> UTF-8 Support Enabled
INFO - 2024-10-02 14:03:12 --> Utf8 Class Initialized
INFO - 2024-10-02 14:03:12 --> URI Class Initialized
INFO - 2024-10-02 14:03:12 --> Router Class Initialized
INFO - 2024-10-02 14:03:12 --> Output Class Initialized
INFO - 2024-10-02 14:03:12 --> Security Class Initialized
DEBUG - 2024-10-02 14:03:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-02 14:03:12 --> Input Class Initialized
INFO - 2024-10-02 14:03:12 --> Language Class Initialized
INFO - 2024-10-02 14:03:12 --> Language Class Initialized
INFO - 2024-10-02 14:03:12 --> Config Class Initialized
INFO - 2024-10-02 14:03:12 --> Loader Class Initialized
INFO - 2024-10-02 14:03:12 --> Helper loaded: url_helper
INFO - 2024-10-02 14:03:12 --> Helper loaded: file_helper
INFO - 2024-10-02 14:03:12 --> Helper loaded: form_helper
INFO - 2024-10-02 14:03:12 --> Helper loaded: my_helper
INFO - 2024-10-02 14:03:12 --> Database Driver Class Initialized
INFO - 2024-10-02 14:03:12 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-02 14:03:12 --> Controller Class Initialized
INFO - 2024-10-02 14:03:12 --> Config Class Initialized
INFO - 2024-10-02 14:03:12 --> Hooks Class Initialized
DEBUG - 2024-10-02 14:03:12 --> UTF-8 Support Enabled
INFO - 2024-10-02 14:03:12 --> Utf8 Class Initialized
INFO - 2024-10-02 14:03:12 --> URI Class Initialized
INFO - 2024-10-02 14:03:12 --> Router Class Initialized
INFO - 2024-10-02 14:03:12 --> Output Class Initialized
INFO - 2024-10-02 14:03:12 --> Security Class Initialized
DEBUG - 2024-10-02 14:03:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-02 14:03:12 --> Input Class Initialized
INFO - 2024-10-02 14:03:12 --> Language Class Initialized
INFO - 2024-10-02 14:03:12 --> Language Class Initialized
INFO - 2024-10-02 14:03:12 --> Config Class Initialized
INFO - 2024-10-02 14:03:12 --> Loader Class Initialized
INFO - 2024-10-02 14:03:12 --> Helper loaded: url_helper
INFO - 2024-10-02 14:03:12 --> Helper loaded: file_helper
INFO - 2024-10-02 14:03:12 --> Helper loaded: form_helper
INFO - 2024-10-02 14:03:12 --> Helper loaded: my_helper
INFO - 2024-10-02 14:03:12 --> Database Driver Class Initialized
INFO - 2024-10-02 14:03:12 --> Final output sent to browser
DEBUG - 2024-10-02 14:03:12 --> Total execution time: 0.0607
INFO - 2024-10-02 14:03:12 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-02 14:03:12 --> Controller Class Initialized
INFO - 2024-10-02 14:03:12 --> Config Class Initialized
INFO - 2024-10-02 14:03:12 --> Hooks Class Initialized
DEBUG - 2024-10-02 14:03:12 --> UTF-8 Support Enabled
INFO - 2024-10-02 14:03:12 --> Utf8 Class Initialized
INFO - 2024-10-02 14:03:12 --> URI Class Initialized
INFO - 2024-10-02 14:03:12 --> Router Class Initialized
INFO - 2024-10-02 14:03:12 --> Output Class Initialized
INFO - 2024-10-02 14:03:12 --> Security Class Initialized
DEBUG - 2024-10-02 14:03:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-02 14:03:12 --> Input Class Initialized
INFO - 2024-10-02 14:03:12 --> Language Class Initialized
INFO - 2024-10-02 14:03:12 --> Language Class Initialized
INFO - 2024-10-02 14:03:12 --> Config Class Initialized
INFO - 2024-10-02 14:03:12 --> Loader Class Initialized
INFO - 2024-10-02 14:03:12 --> Helper loaded: url_helper
INFO - 2024-10-02 14:03:12 --> Helper loaded: file_helper
INFO - 2024-10-02 14:03:12 --> Helper loaded: form_helper
INFO - 2024-10-02 14:03:12 --> Helper loaded: my_helper
INFO - 2024-10-02 14:03:12 --> Database Driver Class Initialized
INFO - 2024-10-02 14:03:12 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-02 14:03:12 --> Controller Class Initialized
INFO - 2024-10-02 14:03:15 --> Config Class Initialized
INFO - 2024-10-02 14:03:15 --> Hooks Class Initialized
DEBUG - 2024-10-02 14:03:15 --> UTF-8 Support Enabled
INFO - 2024-10-02 14:03:15 --> Utf8 Class Initialized
INFO - 2024-10-02 14:03:15 --> URI Class Initialized
INFO - 2024-10-02 14:03:15 --> Router Class Initialized
INFO - 2024-10-02 14:03:15 --> Output Class Initialized
INFO - 2024-10-02 14:03:15 --> Security Class Initialized
DEBUG - 2024-10-02 14:03:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-02 14:03:15 --> Input Class Initialized
INFO - 2024-10-02 14:03:15 --> Language Class Initialized
INFO - 2024-10-02 14:03:15 --> Language Class Initialized
INFO - 2024-10-02 14:03:15 --> Config Class Initialized
INFO - 2024-10-02 14:03:15 --> Loader Class Initialized
INFO - 2024-10-02 14:03:15 --> Helper loaded: url_helper
INFO - 2024-10-02 14:03:15 --> Helper loaded: file_helper
INFO - 2024-10-02 14:03:15 --> Helper loaded: form_helper
INFO - 2024-10-02 14:03:15 --> Helper loaded: my_helper
INFO - 2024-10-02 14:03:15 --> Database Driver Class Initialized
INFO - 2024-10-02 14:03:15 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-02 14:03:15 --> Controller Class Initialized
INFO - 2024-10-02 14:03:15 --> Final output sent to browser
DEBUG - 2024-10-02 14:03:15 --> Total execution time: 0.0292
INFO - 2024-10-02 14:03:15 --> Config Class Initialized
INFO - 2024-10-02 14:03:15 --> Hooks Class Initialized
DEBUG - 2024-10-02 14:03:15 --> UTF-8 Support Enabled
INFO - 2024-10-02 14:03:15 --> Utf8 Class Initialized
INFO - 2024-10-02 14:03:15 --> URI Class Initialized
INFO - 2024-10-02 14:03:15 --> Router Class Initialized
INFO - 2024-10-02 14:03:15 --> Output Class Initialized
INFO - 2024-10-02 14:03:15 --> Security Class Initialized
DEBUG - 2024-10-02 14:03:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-02 14:03:15 --> Input Class Initialized
INFO - 2024-10-02 14:03:15 --> Language Class Initialized
INFO - 2024-10-02 14:03:15 --> Language Class Initialized
INFO - 2024-10-02 14:03:15 --> Config Class Initialized
INFO - 2024-10-02 14:03:15 --> Loader Class Initialized
INFO - 2024-10-02 14:03:15 --> Helper loaded: url_helper
INFO - 2024-10-02 14:03:15 --> Helper loaded: file_helper
INFO - 2024-10-02 14:03:15 --> Helper loaded: form_helper
INFO - 2024-10-02 14:03:15 --> Helper loaded: my_helper
INFO - 2024-10-02 14:03:15 --> Database Driver Class Initialized
INFO - 2024-10-02 14:03:15 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-02 14:03:15 --> Controller Class Initialized
INFO - 2024-10-02 14:03:15 --> Helper loaded: cookie_helper
INFO - 2024-10-02 14:03:15 --> Config Class Initialized
INFO - 2024-10-02 14:03:15 --> Hooks Class Initialized
DEBUG - 2024-10-02 14:03:15 --> UTF-8 Support Enabled
INFO - 2024-10-02 14:03:15 --> Utf8 Class Initialized
INFO - 2024-10-02 14:03:15 --> URI Class Initialized
INFO - 2024-10-02 14:03:15 --> Router Class Initialized
INFO - 2024-10-02 14:03:15 --> Output Class Initialized
INFO - 2024-10-02 14:03:15 --> Security Class Initialized
DEBUG - 2024-10-02 14:03:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-02 14:03:15 --> Input Class Initialized
INFO - 2024-10-02 14:03:15 --> Language Class Initialized
INFO - 2024-10-02 14:03:15 --> Language Class Initialized
INFO - 2024-10-02 14:03:15 --> Config Class Initialized
INFO - 2024-10-02 14:03:15 --> Loader Class Initialized
INFO - 2024-10-02 14:03:15 --> Helper loaded: url_helper
INFO - 2024-10-02 14:03:15 --> Helper loaded: file_helper
INFO - 2024-10-02 14:03:15 --> Helper loaded: form_helper
INFO - 2024-10-02 14:03:15 --> Helper loaded: my_helper
INFO - 2024-10-02 14:03:16 --> Database Driver Class Initialized
INFO - 2024-10-02 14:03:16 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-02 14:03:16 --> Controller Class Initialized
INFO - 2024-10-02 14:03:16 --> Config Class Initialized
INFO - 2024-10-02 14:03:16 --> Hooks Class Initialized
DEBUG - 2024-10-02 14:03:16 --> UTF-8 Support Enabled
INFO - 2024-10-02 14:03:16 --> Utf8 Class Initialized
INFO - 2024-10-02 14:03:16 --> URI Class Initialized
INFO - 2024-10-02 14:03:16 --> Router Class Initialized
INFO - 2024-10-02 14:03:16 --> Output Class Initialized
INFO - 2024-10-02 14:03:16 --> Security Class Initialized
DEBUG - 2024-10-02 14:03:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-02 14:03:16 --> Input Class Initialized
INFO - 2024-10-02 14:03:16 --> Language Class Initialized
INFO - 2024-10-02 14:03:16 --> Language Class Initialized
INFO - 2024-10-02 14:03:16 --> Config Class Initialized
INFO - 2024-10-02 14:03:16 --> Loader Class Initialized
INFO - 2024-10-02 14:03:16 --> Helper loaded: url_helper
INFO - 2024-10-02 14:03:16 --> Helper loaded: file_helper
INFO - 2024-10-02 14:03:16 --> Helper loaded: form_helper
INFO - 2024-10-02 14:03:16 --> Helper loaded: my_helper
INFO - 2024-10-02 14:03:16 --> Database Driver Class Initialized
INFO - 2024-10-02 14:03:16 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-02 14:03:16 --> Controller Class Initialized
DEBUG - 2024-10-02 14:03:16 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/login/views/login.php
DEBUG - 2024-10-02 14:03:16 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-10-02 14:03:16 --> Final output sent to browser
DEBUG - 2024-10-02 14:03:16 --> Total execution time: 0.0317
INFO - 2024-10-02 14:03:17 --> Config Class Initialized
INFO - 2024-10-02 14:03:17 --> Hooks Class Initialized
DEBUG - 2024-10-02 14:03:17 --> UTF-8 Support Enabled
INFO - 2024-10-02 14:03:17 --> Utf8 Class Initialized
INFO - 2024-10-02 14:03:17 --> URI Class Initialized
INFO - 2024-10-02 14:03:17 --> Router Class Initialized
INFO - 2024-10-02 14:03:17 --> Output Class Initialized
INFO - 2024-10-02 14:03:17 --> Security Class Initialized
DEBUG - 2024-10-02 14:03:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-02 14:03:17 --> Input Class Initialized
INFO - 2024-10-02 14:03:17 --> Language Class Initialized
INFO - 2024-10-02 14:03:17 --> Language Class Initialized
INFO - 2024-10-02 14:03:17 --> Config Class Initialized
INFO - 2024-10-02 14:03:17 --> Loader Class Initialized
INFO - 2024-10-02 14:03:17 --> Helper loaded: url_helper
INFO - 2024-10-02 14:03:17 --> Helper loaded: file_helper
INFO - 2024-10-02 14:03:17 --> Helper loaded: form_helper
INFO - 2024-10-02 14:03:17 --> Helper loaded: my_helper
INFO - 2024-10-02 14:03:17 --> Database Driver Class Initialized
INFO - 2024-10-02 14:03:17 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-02 14:03:17 --> Controller Class Initialized
INFO - 2024-10-02 14:03:17 --> Final output sent to browser
DEBUG - 2024-10-02 14:03:17 --> Total execution time: 0.0611
INFO - 2024-10-02 14:03:23 --> Config Class Initialized
INFO - 2024-10-02 14:03:23 --> Hooks Class Initialized
DEBUG - 2024-10-02 14:03:23 --> UTF-8 Support Enabled
INFO - 2024-10-02 14:03:23 --> Utf8 Class Initialized
INFO - 2024-10-02 14:03:23 --> URI Class Initialized
INFO - 2024-10-02 14:03:23 --> Router Class Initialized
INFO - 2024-10-02 14:03:23 --> Output Class Initialized
INFO - 2024-10-02 14:03:23 --> Security Class Initialized
DEBUG - 2024-10-02 14:03:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-02 14:03:23 --> Input Class Initialized
INFO - 2024-10-02 14:03:23 --> Language Class Initialized
INFO - 2024-10-02 14:03:23 --> Language Class Initialized
INFO - 2024-10-02 14:03:23 --> Config Class Initialized
INFO - 2024-10-02 14:03:23 --> Loader Class Initialized
INFO - 2024-10-02 14:03:23 --> Helper loaded: url_helper
INFO - 2024-10-02 14:03:23 --> Helper loaded: file_helper
INFO - 2024-10-02 14:03:23 --> Helper loaded: form_helper
INFO - 2024-10-02 14:03:23 --> Helper loaded: my_helper
INFO - 2024-10-02 14:03:23 --> Database Driver Class Initialized
INFO - 2024-10-02 14:03:23 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-02 14:03:23 --> Controller Class Initialized
INFO - 2024-10-02 14:03:23 --> Helper loaded: cookie_helper
INFO - 2024-10-02 14:03:23 --> Final output sent to browser
DEBUG - 2024-10-02 14:03:23 --> Total execution time: 0.0298
INFO - 2024-10-02 14:03:23 --> Config Class Initialized
INFO - 2024-10-02 14:03:23 --> Hooks Class Initialized
DEBUG - 2024-10-02 14:03:23 --> UTF-8 Support Enabled
INFO - 2024-10-02 14:03:23 --> Utf8 Class Initialized
INFO - 2024-10-02 14:03:23 --> URI Class Initialized
INFO - 2024-10-02 14:03:23 --> Router Class Initialized
INFO - 2024-10-02 14:03:23 --> Output Class Initialized
INFO - 2024-10-02 14:03:23 --> Security Class Initialized
DEBUG - 2024-10-02 14:03:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-02 14:03:23 --> Input Class Initialized
INFO - 2024-10-02 14:03:23 --> Language Class Initialized
INFO - 2024-10-02 14:03:23 --> Language Class Initialized
INFO - 2024-10-02 14:03:23 --> Config Class Initialized
INFO - 2024-10-02 14:03:23 --> Loader Class Initialized
INFO - 2024-10-02 14:03:23 --> Helper loaded: url_helper
INFO - 2024-10-02 14:03:23 --> Helper loaded: file_helper
INFO - 2024-10-02 14:03:23 --> Helper loaded: form_helper
INFO - 2024-10-02 14:03:23 --> Helper loaded: my_helper
INFO - 2024-10-02 14:03:23 --> Database Driver Class Initialized
INFO - 2024-10-02 14:03:23 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-02 14:03:23 --> Controller Class Initialized
DEBUG - 2024-10-02 14:03:23 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/home/views/v_home_guru.php
DEBUG - 2024-10-02 14:03:23 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-10-02 14:03:23 --> Final output sent to browser
DEBUG - 2024-10-02 14:03:23 --> Total execution time: 0.0313
INFO - 2024-10-02 14:03:26 --> Config Class Initialized
INFO - 2024-10-02 14:03:26 --> Hooks Class Initialized
DEBUG - 2024-10-02 14:03:26 --> UTF-8 Support Enabled
INFO - 2024-10-02 14:03:26 --> Utf8 Class Initialized
INFO - 2024-10-02 14:03:26 --> URI Class Initialized
INFO - 2024-10-02 14:03:26 --> Router Class Initialized
INFO - 2024-10-02 14:03:26 --> Output Class Initialized
INFO - 2024-10-02 14:03:26 --> Security Class Initialized
DEBUG - 2024-10-02 14:03:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-02 14:03:26 --> Input Class Initialized
INFO - 2024-10-02 14:03:26 --> Language Class Initialized
INFO - 2024-10-02 14:03:26 --> Language Class Initialized
INFO - 2024-10-02 14:03:26 --> Config Class Initialized
INFO - 2024-10-02 14:03:26 --> Loader Class Initialized
INFO - 2024-10-02 14:03:26 --> Helper loaded: url_helper
INFO - 2024-10-02 14:03:26 --> Helper loaded: file_helper
INFO - 2024-10-02 14:03:26 --> Helper loaded: form_helper
INFO - 2024-10-02 14:03:26 --> Helper loaded: my_helper
INFO - 2024-10-02 14:03:26 --> Database Driver Class Initialized
INFO - 2024-10-02 14:03:26 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-02 14:03:26 --> Controller Class Initialized
INFO - 2024-10-02 14:03:26 --> Config Class Initialized
INFO - 2024-10-02 14:03:26 --> Hooks Class Initialized
DEBUG - 2024-10-02 14:03:26 --> UTF-8 Support Enabled
INFO - 2024-10-02 14:03:26 --> Utf8 Class Initialized
INFO - 2024-10-02 14:03:26 --> URI Class Initialized
INFO - 2024-10-02 14:03:26 --> Router Class Initialized
INFO - 2024-10-02 14:03:26 --> Output Class Initialized
INFO - 2024-10-02 14:03:26 --> Security Class Initialized
DEBUG - 2024-10-02 14:03:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-02 14:03:26 --> Input Class Initialized
INFO - 2024-10-02 14:03:26 --> Language Class Initialized
INFO - 2024-10-02 14:03:26 --> Language Class Initialized
INFO - 2024-10-02 14:03:26 --> Config Class Initialized
INFO - 2024-10-02 14:03:26 --> Loader Class Initialized
DEBUG - 2024-10-02 14:03:26 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/view_mapel/views/v_view_mapel.php
DEBUG - 2024-10-02 14:03:26 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-10-02 14:03:26 --> Final output sent to browser
DEBUG - 2024-10-02 14:03:26 --> Total execution time: 0.0588
INFO - 2024-10-02 14:03:26 --> Helper loaded: url_helper
INFO - 2024-10-02 14:03:26 --> Helper loaded: file_helper
INFO - 2024-10-02 14:03:26 --> Helper loaded: form_helper
INFO - 2024-10-02 14:03:26 --> Helper loaded: my_helper
INFO - 2024-10-02 14:03:26 --> Database Driver Class Initialized
INFO - 2024-10-02 14:03:26 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-02 14:03:26 --> Controller Class Initialized
DEBUG - 2024-10-02 14:03:26 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/view_mapel/views/v_view_mapel.php
DEBUG - 2024-10-02 14:03:26 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-10-02 14:03:26 --> Final output sent to browser
DEBUG - 2024-10-02 14:03:26 --> Total execution time: 0.0409
INFO - 2024-10-02 14:03:28 --> Config Class Initialized
INFO - 2024-10-02 14:03:28 --> Hooks Class Initialized
DEBUG - 2024-10-02 14:03:28 --> UTF-8 Support Enabled
INFO - 2024-10-02 14:03:28 --> Utf8 Class Initialized
INFO - 2024-10-02 14:03:28 --> URI Class Initialized
INFO - 2024-10-02 14:03:28 --> Router Class Initialized
INFO - 2024-10-02 14:03:28 --> Output Class Initialized
INFO - 2024-10-02 14:03:28 --> Security Class Initialized
DEBUG - 2024-10-02 14:03:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-02 14:03:28 --> Input Class Initialized
INFO - 2024-10-02 14:03:28 --> Language Class Initialized
INFO - 2024-10-02 14:03:28 --> Language Class Initialized
INFO - 2024-10-02 14:03:28 --> Config Class Initialized
INFO - 2024-10-02 14:03:28 --> Loader Class Initialized
INFO - 2024-10-02 14:03:28 --> Helper loaded: url_helper
INFO - 2024-10-02 14:03:28 --> Helper loaded: file_helper
INFO - 2024-10-02 14:03:28 --> Helper loaded: form_helper
INFO - 2024-10-02 14:03:28 --> Helper loaded: my_helper
INFO - 2024-10-02 14:03:28 --> Database Driver Class Initialized
INFO - 2024-10-02 14:03:28 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-02 14:03:28 --> Controller Class Initialized
DEBUG - 2024-10-02 14:03:28 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_catatan_guru/views/list.php
DEBUG - 2024-10-02 14:03:28 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-10-02 14:03:28 --> Final output sent to browser
DEBUG - 2024-10-02 14:03:28 --> Total execution time: 0.0413
INFO - 2024-10-02 14:03:30 --> Config Class Initialized
INFO - 2024-10-02 14:03:30 --> Hooks Class Initialized
DEBUG - 2024-10-02 14:03:30 --> UTF-8 Support Enabled
INFO - 2024-10-02 14:03:30 --> Utf8 Class Initialized
INFO - 2024-10-02 14:03:30 --> URI Class Initialized
INFO - 2024-10-02 14:03:30 --> Router Class Initialized
INFO - 2024-10-02 14:03:30 --> Output Class Initialized
INFO - 2024-10-02 14:03:30 --> Security Class Initialized
DEBUG - 2024-10-02 14:03:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-02 14:03:30 --> Input Class Initialized
INFO - 2024-10-02 14:03:30 --> Language Class Initialized
INFO - 2024-10-02 14:03:30 --> Language Class Initialized
INFO - 2024-10-02 14:03:30 --> Config Class Initialized
INFO - 2024-10-02 14:03:30 --> Loader Class Initialized
INFO - 2024-10-02 14:03:30 --> Helper loaded: url_helper
INFO - 2024-10-02 14:03:30 --> Helper loaded: file_helper
INFO - 2024-10-02 14:03:30 --> Helper loaded: form_helper
INFO - 2024-10-02 14:03:30 --> Helper loaded: my_helper
INFO - 2024-10-02 14:03:30 --> Database Driver Class Initialized
INFO - 2024-10-02 14:03:30 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-02 14:03:30 --> Controller Class Initialized
INFO - 2024-10-02 14:03:30 --> Final output sent to browser
DEBUG - 2024-10-02 14:03:30 --> Total execution time: 0.0374
INFO - 2024-10-02 14:03:32 --> Config Class Initialized
INFO - 2024-10-02 14:03:32 --> Hooks Class Initialized
DEBUG - 2024-10-02 14:03:32 --> UTF-8 Support Enabled
INFO - 2024-10-02 14:03:32 --> Utf8 Class Initialized
INFO - 2024-10-02 14:03:32 --> URI Class Initialized
INFO - 2024-10-02 14:03:32 --> Router Class Initialized
INFO - 2024-10-02 14:03:32 --> Output Class Initialized
INFO - 2024-10-02 14:03:32 --> Security Class Initialized
DEBUG - 2024-10-02 14:03:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-02 14:03:32 --> Input Class Initialized
INFO - 2024-10-02 14:03:32 --> Language Class Initialized
INFO - 2024-10-02 14:03:32 --> Language Class Initialized
INFO - 2024-10-02 14:03:32 --> Config Class Initialized
INFO - 2024-10-02 14:03:32 --> Loader Class Initialized
INFO - 2024-10-02 14:03:32 --> Helper loaded: url_helper
INFO - 2024-10-02 14:03:32 --> Helper loaded: file_helper
INFO - 2024-10-02 14:03:32 --> Helper loaded: form_helper
INFO - 2024-10-02 14:03:32 --> Helper loaded: my_helper
INFO - 2024-10-02 14:03:32 --> Database Driver Class Initialized
INFO - 2024-10-02 14:03:32 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-02 14:03:32 --> Controller Class Initialized
DEBUG - 2024-10-02 14:03:32 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_icb/views/list.php
DEBUG - 2024-10-02 14:03:32 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-10-02 14:03:32 --> Final output sent to browser
DEBUG - 2024-10-02 14:03:32 --> Total execution time: 0.0362
INFO - 2024-10-02 14:03:32 --> Config Class Initialized
INFO - 2024-10-02 14:03:32 --> Hooks Class Initialized
DEBUG - 2024-10-02 14:03:32 --> UTF-8 Support Enabled
INFO - 2024-10-02 14:03:32 --> Utf8 Class Initialized
INFO - 2024-10-02 14:03:32 --> URI Class Initialized
INFO - 2024-10-02 14:03:32 --> Router Class Initialized
INFO - 2024-10-02 14:03:32 --> Output Class Initialized
INFO - 2024-10-02 14:03:32 --> Security Class Initialized
DEBUG - 2024-10-02 14:03:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-02 14:03:32 --> Input Class Initialized
INFO - 2024-10-02 14:03:32 --> Language Class Initialized
INFO - 2024-10-02 14:03:32 --> Language Class Initialized
INFO - 2024-10-02 14:03:32 --> Config Class Initialized
INFO - 2024-10-02 14:03:32 --> Loader Class Initialized
INFO - 2024-10-02 14:03:32 --> Helper loaded: url_helper
INFO - 2024-10-02 14:03:32 --> Helper loaded: file_helper
INFO - 2024-10-02 14:03:32 --> Helper loaded: form_helper
INFO - 2024-10-02 14:03:32 --> Helper loaded: my_helper
INFO - 2024-10-02 14:03:32 --> Database Driver Class Initialized
INFO - 2024-10-02 14:03:32 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-02 14:03:32 --> Controller Class Initialized
INFO - 2024-10-02 14:03:48 --> Config Class Initialized
INFO - 2024-10-02 14:03:48 --> Hooks Class Initialized
DEBUG - 2024-10-02 14:03:48 --> UTF-8 Support Enabled
INFO - 2024-10-02 14:03:48 --> Utf8 Class Initialized
INFO - 2024-10-02 14:03:48 --> URI Class Initialized
INFO - 2024-10-02 14:03:48 --> Router Class Initialized
INFO - 2024-10-02 14:03:48 --> Output Class Initialized
INFO - 2024-10-02 14:03:48 --> Security Class Initialized
DEBUG - 2024-10-02 14:03:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-02 14:03:48 --> Input Class Initialized
INFO - 2024-10-02 14:03:48 --> Language Class Initialized
INFO - 2024-10-02 14:03:48 --> Language Class Initialized
INFO - 2024-10-02 14:03:48 --> Config Class Initialized
INFO - 2024-10-02 14:03:48 --> Loader Class Initialized
INFO - 2024-10-02 14:03:48 --> Helper loaded: url_helper
INFO - 2024-10-02 14:03:48 --> Helper loaded: file_helper
INFO - 2024-10-02 14:03:48 --> Helper loaded: form_helper
INFO - 2024-10-02 14:03:48 --> Helper loaded: my_helper
INFO - 2024-10-02 14:03:48 --> Database Driver Class Initialized
INFO - 2024-10-02 14:03:48 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-02 14:03:48 --> Controller Class Initialized
INFO - 2024-10-02 14:03:48 --> Final output sent to browser
DEBUG - 2024-10-02 14:03:48 --> Total execution time: 0.0336
INFO - 2024-10-02 14:03:48 --> Config Class Initialized
INFO - 2024-10-02 14:03:48 --> Hooks Class Initialized
DEBUG - 2024-10-02 14:03:48 --> UTF-8 Support Enabled
INFO - 2024-10-02 14:03:48 --> Utf8 Class Initialized
INFO - 2024-10-02 14:03:48 --> URI Class Initialized
INFO - 2024-10-02 14:03:48 --> Router Class Initialized
INFO - 2024-10-02 14:03:48 --> Output Class Initialized
INFO - 2024-10-02 14:03:48 --> Security Class Initialized
DEBUG - 2024-10-02 14:03:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-02 14:03:48 --> Input Class Initialized
INFO - 2024-10-02 14:03:48 --> Language Class Initialized
INFO - 2024-10-02 14:03:48 --> Language Class Initialized
INFO - 2024-10-02 14:03:48 --> Config Class Initialized
INFO - 2024-10-02 14:03:48 --> Loader Class Initialized
INFO - 2024-10-02 14:03:48 --> Helper loaded: url_helper
INFO - 2024-10-02 14:03:48 --> Helper loaded: file_helper
INFO - 2024-10-02 14:03:48 --> Helper loaded: form_helper
INFO - 2024-10-02 14:03:48 --> Helper loaded: my_helper
INFO - 2024-10-02 14:03:48 --> Database Driver Class Initialized
INFO - 2024-10-02 14:03:48 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-02 14:03:48 --> Controller Class Initialized
INFO - 2024-10-02 14:03:50 --> Config Class Initialized
INFO - 2024-10-02 14:03:50 --> Hooks Class Initialized
DEBUG - 2024-10-02 14:03:50 --> UTF-8 Support Enabled
INFO - 2024-10-02 14:03:50 --> Utf8 Class Initialized
INFO - 2024-10-02 14:03:50 --> URI Class Initialized
INFO - 2024-10-02 14:03:50 --> Router Class Initialized
INFO - 2024-10-02 14:03:50 --> Output Class Initialized
INFO - 2024-10-02 14:03:50 --> Security Class Initialized
DEBUG - 2024-10-02 14:03:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-02 14:03:50 --> Input Class Initialized
INFO - 2024-10-02 14:03:50 --> Language Class Initialized
INFO - 2024-10-02 14:03:50 --> Language Class Initialized
INFO - 2024-10-02 14:03:50 --> Config Class Initialized
INFO - 2024-10-02 14:03:50 --> Loader Class Initialized
INFO - 2024-10-02 14:03:50 --> Helper loaded: url_helper
INFO - 2024-10-02 14:03:50 --> Helper loaded: file_helper
INFO - 2024-10-02 14:03:50 --> Helper loaded: form_helper
INFO - 2024-10-02 14:03:50 --> Helper loaded: my_helper
INFO - 2024-10-02 14:03:50 --> Database Driver Class Initialized
INFO - 2024-10-02 14:03:50 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-02 14:03:50 --> Controller Class Initialized
INFO - 2024-10-02 14:03:50 --> Final output sent to browser
DEBUG - 2024-10-02 14:03:50 --> Total execution time: 0.0447
INFO - 2024-10-02 14:04:06 --> Config Class Initialized
INFO - 2024-10-02 14:04:06 --> Hooks Class Initialized
DEBUG - 2024-10-02 14:04:06 --> UTF-8 Support Enabled
INFO - 2024-10-02 14:04:06 --> Utf8 Class Initialized
INFO - 2024-10-02 14:04:06 --> URI Class Initialized
INFO - 2024-10-02 14:04:06 --> Router Class Initialized
INFO - 2024-10-02 14:04:06 --> Output Class Initialized
INFO - 2024-10-02 14:04:06 --> Security Class Initialized
DEBUG - 2024-10-02 14:04:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-02 14:04:06 --> Input Class Initialized
INFO - 2024-10-02 14:04:06 --> Language Class Initialized
INFO - 2024-10-02 14:04:06 --> Language Class Initialized
INFO - 2024-10-02 14:04:06 --> Config Class Initialized
INFO - 2024-10-02 14:04:06 --> Loader Class Initialized
INFO - 2024-10-02 14:04:06 --> Helper loaded: url_helper
INFO - 2024-10-02 14:04:06 --> Helper loaded: file_helper
INFO - 2024-10-02 14:04:06 --> Helper loaded: form_helper
INFO - 2024-10-02 14:04:06 --> Helper loaded: my_helper
INFO - 2024-10-02 14:04:06 --> Database Driver Class Initialized
INFO - 2024-10-02 14:04:06 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-02 14:04:06 --> Controller Class Initialized
DEBUG - 2024-10-02 14:04:06 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/view_mapel/views/v_view_mapel.php
DEBUG - 2024-10-02 14:04:06 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-10-02 14:04:06 --> Final output sent to browser
DEBUG - 2024-10-02 14:04:06 --> Total execution time: 0.0719
INFO - 2024-10-02 14:04:07 --> Config Class Initialized
INFO - 2024-10-02 14:04:07 --> Hooks Class Initialized
DEBUG - 2024-10-02 14:04:07 --> UTF-8 Support Enabled
INFO - 2024-10-02 14:04:07 --> Utf8 Class Initialized
INFO - 2024-10-02 14:04:07 --> URI Class Initialized
INFO - 2024-10-02 14:04:07 --> Router Class Initialized
INFO - 2024-10-02 14:04:07 --> Output Class Initialized
INFO - 2024-10-02 14:04:07 --> Security Class Initialized
DEBUG - 2024-10-02 14:04:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-02 14:04:07 --> Input Class Initialized
INFO - 2024-10-02 14:04:07 --> Language Class Initialized
INFO - 2024-10-02 14:04:07 --> Language Class Initialized
INFO - 2024-10-02 14:04:07 --> Config Class Initialized
INFO - 2024-10-02 14:04:07 --> Loader Class Initialized
INFO - 2024-10-02 14:04:07 --> Helper loaded: url_helper
INFO - 2024-10-02 14:04:07 --> Helper loaded: file_helper
INFO - 2024-10-02 14:04:07 --> Helper loaded: form_helper
INFO - 2024-10-02 14:04:07 --> Helper loaded: my_helper
INFO - 2024-10-02 14:04:07 --> Database Driver Class Initialized
INFO - 2024-10-02 14:04:07 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-02 14:04:07 --> Controller Class Initialized
DEBUG - 2024-10-02 14:04:07 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/views/list.php
DEBUG - 2024-10-02 14:04:07 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-10-02 14:04:07 --> Final output sent to browser
DEBUG - 2024-10-02 14:04:07 --> Total execution time: 0.0412
INFO - 2024-10-02 14:04:08 --> Config Class Initialized
INFO - 2024-10-02 14:04:08 --> Hooks Class Initialized
DEBUG - 2024-10-02 14:04:08 --> UTF-8 Support Enabled
INFO - 2024-10-02 14:04:08 --> Utf8 Class Initialized
INFO - 2024-10-02 14:04:08 --> URI Class Initialized
INFO - 2024-10-02 14:04:08 --> Router Class Initialized
INFO - 2024-10-02 14:04:08 --> Output Class Initialized
INFO - 2024-10-02 14:04:08 --> Security Class Initialized
DEBUG - 2024-10-02 14:04:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-02 14:04:08 --> Input Class Initialized
INFO - 2024-10-02 14:04:08 --> Language Class Initialized
INFO - 2024-10-02 14:04:08 --> Language Class Initialized
INFO - 2024-10-02 14:04:08 --> Config Class Initialized
INFO - 2024-10-02 14:04:08 --> Loader Class Initialized
INFO - 2024-10-02 14:04:08 --> Helper loaded: url_helper
INFO - 2024-10-02 14:04:08 --> Helper loaded: file_helper
INFO - 2024-10-02 14:04:08 --> Helper loaded: form_helper
INFO - 2024-10-02 14:04:08 --> Helper loaded: my_helper
INFO - 2024-10-02 14:04:08 --> Database Driver Class Initialized
INFO - 2024-10-02 14:04:08 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-02 14:04:08 --> Controller Class Initialized
INFO - 2024-10-02 14:04:10 --> Config Class Initialized
INFO - 2024-10-02 14:04:10 --> Hooks Class Initialized
DEBUG - 2024-10-02 14:04:10 --> UTF-8 Support Enabled
INFO - 2024-10-02 14:04:10 --> Utf8 Class Initialized
INFO - 2024-10-02 14:04:10 --> URI Class Initialized
INFO - 2024-10-02 14:04:10 --> Router Class Initialized
INFO - 2024-10-02 14:04:10 --> Output Class Initialized
INFO - 2024-10-02 14:04:10 --> Security Class Initialized
DEBUG - 2024-10-02 14:04:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-02 14:04:10 --> Input Class Initialized
INFO - 2024-10-02 14:04:10 --> Language Class Initialized
INFO - 2024-10-02 14:04:10 --> Language Class Initialized
INFO - 2024-10-02 14:04:10 --> Config Class Initialized
INFO - 2024-10-02 14:04:10 --> Loader Class Initialized
INFO - 2024-10-02 14:04:10 --> Helper loaded: url_helper
INFO - 2024-10-02 14:04:10 --> Helper loaded: file_helper
INFO - 2024-10-02 14:04:10 --> Helper loaded: form_helper
INFO - 2024-10-02 14:04:10 --> Helper loaded: my_helper
INFO - 2024-10-02 14:04:10 --> Database Driver Class Initialized
INFO - 2024-10-02 14:04:10 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-02 14:04:10 --> Controller Class Initialized
INFO - 2024-10-02 14:04:10 --> Final output sent to browser
DEBUG - 2024-10-02 14:04:10 --> Total execution time: 0.0348
INFO - 2024-10-02 14:04:12 --> Config Class Initialized
INFO - 2024-10-02 14:04:12 --> Hooks Class Initialized
DEBUG - 2024-10-02 14:04:12 --> UTF-8 Support Enabled
INFO - 2024-10-02 14:04:12 --> Utf8 Class Initialized
INFO - 2024-10-02 14:04:12 --> URI Class Initialized
INFO - 2024-10-02 14:04:12 --> Router Class Initialized
INFO - 2024-10-02 14:04:12 --> Output Class Initialized
INFO - 2024-10-02 14:04:12 --> Security Class Initialized
DEBUG - 2024-10-02 14:04:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-02 14:04:12 --> Input Class Initialized
INFO - 2024-10-02 14:04:12 --> Language Class Initialized
INFO - 2024-10-02 14:04:12 --> Language Class Initialized
INFO - 2024-10-02 14:04:12 --> Config Class Initialized
INFO - 2024-10-02 14:04:12 --> Loader Class Initialized
INFO - 2024-10-02 14:04:12 --> Helper loaded: url_helper
INFO - 2024-10-02 14:04:12 --> Helper loaded: file_helper
INFO - 2024-10-02 14:04:12 --> Helper loaded: form_helper
INFO - 2024-10-02 14:04:12 --> Helper loaded: my_helper
INFO - 2024-10-02 14:04:12 --> Database Driver Class Initialized
INFO - 2024-10-02 14:04:12 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-02 14:04:12 --> Controller Class Initialized
INFO - 2024-10-02 14:04:12 --> Final output sent to browser
DEBUG - 2024-10-02 14:04:12 --> Total execution time: 0.0327
INFO - 2024-10-02 14:04:12 --> Config Class Initialized
INFO - 2024-10-02 14:04:12 --> Hooks Class Initialized
DEBUG - 2024-10-02 14:04:12 --> UTF-8 Support Enabled
INFO - 2024-10-02 14:04:12 --> Utf8 Class Initialized
INFO - 2024-10-02 14:04:12 --> URI Class Initialized
INFO - 2024-10-02 14:04:12 --> Router Class Initialized
INFO - 2024-10-02 14:04:12 --> Output Class Initialized
INFO - 2024-10-02 14:04:12 --> Security Class Initialized
DEBUG - 2024-10-02 14:04:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-02 14:04:12 --> Input Class Initialized
INFO - 2024-10-02 14:04:12 --> Language Class Initialized
INFO - 2024-10-02 14:04:12 --> Language Class Initialized
INFO - 2024-10-02 14:04:12 --> Config Class Initialized
INFO - 2024-10-02 14:04:12 --> Loader Class Initialized
INFO - 2024-10-02 14:04:12 --> Helper loaded: url_helper
INFO - 2024-10-02 14:04:12 --> Helper loaded: file_helper
INFO - 2024-10-02 14:04:12 --> Helper loaded: form_helper
INFO - 2024-10-02 14:04:12 --> Helper loaded: my_helper
INFO - 2024-10-02 14:04:12 --> Database Driver Class Initialized
INFO - 2024-10-02 14:04:12 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-02 14:04:12 --> Controller Class Initialized
INFO - 2024-10-02 14:04:14 --> Config Class Initialized
INFO - 2024-10-02 14:04:14 --> Hooks Class Initialized
DEBUG - 2024-10-02 14:04:14 --> UTF-8 Support Enabled
INFO - 2024-10-02 14:04:14 --> Utf8 Class Initialized
INFO - 2024-10-02 14:04:14 --> URI Class Initialized
INFO - 2024-10-02 14:04:14 --> Router Class Initialized
INFO - 2024-10-02 14:04:14 --> Output Class Initialized
INFO - 2024-10-02 14:04:14 --> Security Class Initialized
DEBUG - 2024-10-02 14:04:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-02 14:04:14 --> Input Class Initialized
INFO - 2024-10-02 14:04:14 --> Language Class Initialized
INFO - 2024-10-02 14:04:14 --> Language Class Initialized
INFO - 2024-10-02 14:04:14 --> Config Class Initialized
INFO - 2024-10-02 14:04:14 --> Loader Class Initialized
INFO - 2024-10-02 14:04:14 --> Helper loaded: url_helper
INFO - 2024-10-02 14:04:14 --> Helper loaded: file_helper
INFO - 2024-10-02 14:04:14 --> Helper loaded: form_helper
INFO - 2024-10-02 14:04:14 --> Helper loaded: my_helper
INFO - 2024-10-02 14:04:14 --> Database Driver Class Initialized
INFO - 2024-10-02 14:04:14 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-02 14:04:14 --> Controller Class Initialized
INFO - 2024-10-02 14:04:14 --> Final output sent to browser
DEBUG - 2024-10-02 14:04:14 --> Total execution time: 0.0318
INFO - 2024-10-02 14:04:15 --> Config Class Initialized
INFO - 2024-10-02 14:04:15 --> Hooks Class Initialized
DEBUG - 2024-10-02 14:04:15 --> UTF-8 Support Enabled
INFO - 2024-10-02 14:04:15 --> Utf8 Class Initialized
INFO - 2024-10-02 14:04:15 --> URI Class Initialized
INFO - 2024-10-02 14:04:15 --> Router Class Initialized
INFO - 2024-10-02 14:04:15 --> Output Class Initialized
INFO - 2024-10-02 14:04:15 --> Security Class Initialized
DEBUG - 2024-10-02 14:04:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-02 14:04:15 --> Input Class Initialized
INFO - 2024-10-02 14:04:15 --> Language Class Initialized
INFO - 2024-10-02 14:04:15 --> Language Class Initialized
INFO - 2024-10-02 14:04:15 --> Config Class Initialized
INFO - 2024-10-02 14:04:15 --> Loader Class Initialized
INFO - 2024-10-02 14:04:15 --> Helper loaded: url_helper
INFO - 2024-10-02 14:04:15 --> Helper loaded: file_helper
INFO - 2024-10-02 14:04:15 --> Helper loaded: form_helper
INFO - 2024-10-02 14:04:15 --> Helper loaded: my_helper
INFO - 2024-10-02 14:04:15 --> Database Driver Class Initialized
INFO - 2024-10-02 14:04:15 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-02 14:04:15 --> Controller Class Initialized
INFO - 2024-10-02 14:04:15 --> Final output sent to browser
DEBUG - 2024-10-02 14:04:15 --> Total execution time: 0.0334
INFO - 2024-10-02 14:04:16 --> Config Class Initialized
INFO - 2024-10-02 14:04:16 --> Hooks Class Initialized
DEBUG - 2024-10-02 14:04:16 --> UTF-8 Support Enabled
INFO - 2024-10-02 14:04:16 --> Utf8 Class Initialized
INFO - 2024-10-02 14:04:16 --> URI Class Initialized
INFO - 2024-10-02 14:04:16 --> Router Class Initialized
INFO - 2024-10-02 14:04:16 --> Output Class Initialized
INFO - 2024-10-02 14:04:16 --> Security Class Initialized
DEBUG - 2024-10-02 14:04:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-02 14:04:16 --> Input Class Initialized
INFO - 2024-10-02 14:04:16 --> Language Class Initialized
INFO - 2024-10-02 14:04:16 --> Language Class Initialized
INFO - 2024-10-02 14:04:16 --> Config Class Initialized
INFO - 2024-10-02 14:04:16 --> Loader Class Initialized
INFO - 2024-10-02 14:04:16 --> Helper loaded: url_helper
INFO - 2024-10-02 14:04:16 --> Helper loaded: file_helper
INFO - 2024-10-02 14:04:16 --> Helper loaded: form_helper
INFO - 2024-10-02 14:04:16 --> Helper loaded: my_helper
INFO - 2024-10-02 14:04:16 --> Database Driver Class Initialized
INFO - 2024-10-02 14:04:16 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-02 14:04:16 --> Controller Class Initialized
INFO - 2024-10-02 14:04:25 --> Config Class Initialized
INFO - 2024-10-02 14:04:25 --> Hooks Class Initialized
DEBUG - 2024-10-02 14:04:25 --> UTF-8 Support Enabled
INFO - 2024-10-02 14:04:25 --> Utf8 Class Initialized
INFO - 2024-10-02 14:04:25 --> URI Class Initialized
INFO - 2024-10-02 14:04:25 --> Router Class Initialized
INFO - 2024-10-02 14:04:25 --> Output Class Initialized
INFO - 2024-10-02 14:04:25 --> Security Class Initialized
DEBUG - 2024-10-02 14:04:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-02 14:04:25 --> Input Class Initialized
INFO - 2024-10-02 14:04:25 --> Language Class Initialized
INFO - 2024-10-02 14:04:25 --> Language Class Initialized
INFO - 2024-10-02 14:04:25 --> Config Class Initialized
INFO - 2024-10-02 14:04:25 --> Loader Class Initialized
INFO - 2024-10-02 14:04:25 --> Helper loaded: url_helper
INFO - 2024-10-02 14:04:25 --> Helper loaded: file_helper
INFO - 2024-10-02 14:04:25 --> Helper loaded: form_helper
INFO - 2024-10-02 14:04:25 --> Helper loaded: my_helper
INFO - 2024-10-02 14:04:25 --> Database Driver Class Initialized
INFO - 2024-10-02 14:04:25 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-02 14:04:25 --> Controller Class Initialized
INFO - 2024-10-02 14:04:25 --> Final output sent to browser
DEBUG - 2024-10-02 14:04:25 --> Total execution time: 0.0750
INFO - 2024-10-02 14:04:33 --> Config Class Initialized
INFO - 2024-10-02 14:04:33 --> Hooks Class Initialized
DEBUG - 2024-10-02 14:04:33 --> UTF-8 Support Enabled
INFO - 2024-10-02 14:04:33 --> Utf8 Class Initialized
INFO - 2024-10-02 14:04:33 --> URI Class Initialized
INFO - 2024-10-02 14:04:33 --> Router Class Initialized
INFO - 2024-10-02 14:04:33 --> Output Class Initialized
INFO - 2024-10-02 14:04:33 --> Security Class Initialized
DEBUG - 2024-10-02 14:04:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-02 14:04:33 --> Input Class Initialized
INFO - 2024-10-02 14:04:33 --> Language Class Initialized
INFO - 2024-10-02 14:04:33 --> Language Class Initialized
INFO - 2024-10-02 14:04:33 --> Config Class Initialized
INFO - 2024-10-02 14:04:33 --> Loader Class Initialized
INFO - 2024-10-02 14:04:33 --> Helper loaded: url_helper
INFO - 2024-10-02 14:04:33 --> Helper loaded: file_helper
INFO - 2024-10-02 14:04:33 --> Helper loaded: form_helper
INFO - 2024-10-02 14:04:33 --> Helper loaded: my_helper
INFO - 2024-10-02 14:04:33 --> Database Driver Class Initialized
INFO - 2024-10-02 14:04:33 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-02 14:04:33 --> Controller Class Initialized
INFO - 2024-10-02 14:04:33 --> Final output sent to browser
DEBUG - 2024-10-02 14:04:33 --> Total execution time: 0.0370
INFO - 2024-10-02 14:04:33 --> Config Class Initialized
INFO - 2024-10-02 14:04:33 --> Hooks Class Initialized
DEBUG - 2024-10-02 14:04:33 --> UTF-8 Support Enabled
INFO - 2024-10-02 14:04:33 --> Utf8 Class Initialized
INFO - 2024-10-02 14:04:33 --> URI Class Initialized
INFO - 2024-10-02 14:04:33 --> Router Class Initialized
INFO - 2024-10-02 14:04:33 --> Output Class Initialized
INFO - 2024-10-02 14:04:33 --> Security Class Initialized
DEBUG - 2024-10-02 14:04:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-02 14:04:33 --> Input Class Initialized
INFO - 2024-10-02 14:04:33 --> Language Class Initialized
INFO - 2024-10-02 14:04:33 --> Language Class Initialized
INFO - 2024-10-02 14:04:33 --> Config Class Initialized
INFO - 2024-10-02 14:04:33 --> Loader Class Initialized
INFO - 2024-10-02 14:04:33 --> Helper loaded: url_helper
INFO - 2024-10-02 14:04:33 --> Helper loaded: file_helper
INFO - 2024-10-02 14:04:33 --> Helper loaded: form_helper
INFO - 2024-10-02 14:04:33 --> Helper loaded: my_helper
INFO - 2024-10-02 14:04:33 --> Database Driver Class Initialized
INFO - 2024-10-02 14:04:33 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-02 14:04:33 --> Controller Class Initialized
INFO - 2024-10-02 14:04:50 --> Config Class Initialized
INFO - 2024-10-02 14:04:50 --> Hooks Class Initialized
DEBUG - 2024-10-02 14:04:50 --> UTF-8 Support Enabled
INFO - 2024-10-02 14:04:50 --> Utf8 Class Initialized
INFO - 2024-10-02 14:04:50 --> URI Class Initialized
INFO - 2024-10-02 14:04:50 --> Router Class Initialized
INFO - 2024-10-02 14:04:50 --> Output Class Initialized
INFO - 2024-10-02 14:04:50 --> Security Class Initialized
DEBUG - 2024-10-02 14:04:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-02 14:04:50 --> Input Class Initialized
INFO - 2024-10-02 14:04:50 --> Language Class Initialized
INFO - 2024-10-02 14:04:50 --> Language Class Initialized
INFO - 2024-10-02 14:04:50 --> Config Class Initialized
INFO - 2024-10-02 14:04:50 --> Loader Class Initialized
INFO - 2024-10-02 14:04:50 --> Helper loaded: url_helper
INFO - 2024-10-02 14:04:50 --> Helper loaded: file_helper
INFO - 2024-10-02 14:04:50 --> Helper loaded: form_helper
INFO - 2024-10-02 14:04:50 --> Helper loaded: my_helper
INFO - 2024-10-02 14:04:50 --> Database Driver Class Initialized
INFO - 2024-10-02 14:04:50 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-02 14:04:50 --> Controller Class Initialized
INFO - 2024-10-02 14:05:12 --> Config Class Initialized
INFO - 2024-10-02 14:05:12 --> Hooks Class Initialized
DEBUG - 2024-10-02 14:05:12 --> UTF-8 Support Enabled
INFO - 2024-10-02 14:05:12 --> Utf8 Class Initialized
INFO - 2024-10-02 14:05:12 --> URI Class Initialized
INFO - 2024-10-02 14:05:12 --> Router Class Initialized
INFO - 2024-10-02 14:05:12 --> Output Class Initialized
INFO - 2024-10-02 14:05:12 --> Security Class Initialized
DEBUG - 2024-10-02 14:05:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-02 14:05:12 --> Input Class Initialized
INFO - 2024-10-02 14:05:12 --> Language Class Initialized
INFO - 2024-10-02 14:05:12 --> Language Class Initialized
INFO - 2024-10-02 14:05:12 --> Config Class Initialized
INFO - 2024-10-02 14:05:12 --> Loader Class Initialized
INFO - 2024-10-02 14:05:12 --> Helper loaded: url_helper
INFO - 2024-10-02 14:05:12 --> Helper loaded: file_helper
INFO - 2024-10-02 14:05:12 --> Helper loaded: form_helper
INFO - 2024-10-02 14:05:12 --> Helper loaded: my_helper
INFO - 2024-10-02 14:05:12 --> Database Driver Class Initialized
INFO - 2024-10-02 14:05:12 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-02 14:05:12 --> Controller Class Initialized
INFO - 2024-10-02 14:05:12 --> Final output sent to browser
DEBUG - 2024-10-02 14:05:12 --> Total execution time: 0.0420
INFO - 2024-10-02 14:06:04 --> Config Class Initialized
INFO - 2024-10-02 14:06:04 --> Hooks Class Initialized
DEBUG - 2024-10-02 14:06:04 --> UTF-8 Support Enabled
INFO - 2024-10-02 14:06:04 --> Utf8 Class Initialized
INFO - 2024-10-02 14:06:04 --> URI Class Initialized
INFO - 2024-10-02 14:06:04 --> Router Class Initialized
INFO - 2024-10-02 14:06:04 --> Output Class Initialized
INFO - 2024-10-02 14:06:04 --> Security Class Initialized
DEBUG - 2024-10-02 14:06:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-02 14:06:04 --> Input Class Initialized
INFO - 2024-10-02 14:06:04 --> Language Class Initialized
INFO - 2024-10-02 14:06:04 --> Language Class Initialized
INFO - 2024-10-02 14:06:04 --> Config Class Initialized
INFO - 2024-10-02 14:06:04 --> Loader Class Initialized
INFO - 2024-10-02 14:06:04 --> Helper loaded: url_helper
INFO - 2024-10-02 14:06:04 --> Helper loaded: file_helper
INFO - 2024-10-02 14:06:04 --> Helper loaded: form_helper
INFO - 2024-10-02 14:06:04 --> Helper loaded: my_helper
INFO - 2024-10-02 14:06:04 --> Database Driver Class Initialized
INFO - 2024-10-02 14:06:04 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-02 14:06:04 --> Controller Class Initialized
INFO - 2024-10-02 14:06:04 --> Final output sent to browser
DEBUG - 2024-10-02 14:06:04 --> Total execution time: 0.0357
INFO - 2024-10-02 14:06:16 --> Config Class Initialized
INFO - 2024-10-02 14:06:16 --> Hooks Class Initialized
DEBUG - 2024-10-02 14:06:16 --> UTF-8 Support Enabled
INFO - 2024-10-02 14:06:16 --> Utf8 Class Initialized
INFO - 2024-10-02 14:06:16 --> URI Class Initialized
INFO - 2024-10-02 14:06:16 --> Router Class Initialized
INFO - 2024-10-02 14:06:16 --> Output Class Initialized
INFO - 2024-10-02 14:06:16 --> Security Class Initialized
DEBUG - 2024-10-02 14:06:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-02 14:06:16 --> Input Class Initialized
INFO - 2024-10-02 14:06:16 --> Language Class Initialized
INFO - 2024-10-02 14:06:16 --> Language Class Initialized
INFO - 2024-10-02 14:06:16 --> Config Class Initialized
INFO - 2024-10-02 14:06:16 --> Loader Class Initialized
INFO - 2024-10-02 14:06:16 --> Helper loaded: url_helper
INFO - 2024-10-02 14:06:16 --> Helper loaded: file_helper
INFO - 2024-10-02 14:06:16 --> Helper loaded: form_helper
INFO - 2024-10-02 14:06:16 --> Helper loaded: my_helper
INFO - 2024-10-02 14:06:16 --> Database Driver Class Initialized
INFO - 2024-10-02 14:06:16 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-02 14:06:16 --> Controller Class Initialized
INFO - 2024-10-02 14:06:16 --> Helper loaded: cookie_helper
INFO - 2024-10-02 14:06:16 --> Config Class Initialized
INFO - 2024-10-02 14:06:16 --> Hooks Class Initialized
DEBUG - 2024-10-02 14:06:16 --> UTF-8 Support Enabled
INFO - 2024-10-02 14:06:16 --> Utf8 Class Initialized
INFO - 2024-10-02 14:06:16 --> URI Class Initialized
INFO - 2024-10-02 14:06:16 --> Router Class Initialized
INFO - 2024-10-02 14:06:16 --> Output Class Initialized
INFO - 2024-10-02 14:06:16 --> Security Class Initialized
DEBUG - 2024-10-02 14:06:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-02 14:06:16 --> Input Class Initialized
INFO - 2024-10-02 14:06:16 --> Language Class Initialized
INFO - 2024-10-02 14:06:16 --> Language Class Initialized
INFO - 2024-10-02 14:06:16 --> Config Class Initialized
INFO - 2024-10-02 14:06:16 --> Loader Class Initialized
INFO - 2024-10-02 14:06:16 --> Helper loaded: url_helper
INFO - 2024-10-02 14:06:16 --> Helper loaded: file_helper
INFO - 2024-10-02 14:06:16 --> Helper loaded: form_helper
INFO - 2024-10-02 14:06:16 --> Helper loaded: my_helper
INFO - 2024-10-02 14:06:16 --> Database Driver Class Initialized
INFO - 2024-10-02 14:06:16 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-02 14:06:16 --> Controller Class Initialized
INFO - 2024-10-02 14:06:16 --> Config Class Initialized
INFO - 2024-10-02 14:06:16 --> Hooks Class Initialized
DEBUG - 2024-10-02 14:06:16 --> UTF-8 Support Enabled
INFO - 2024-10-02 14:06:16 --> Utf8 Class Initialized
INFO - 2024-10-02 14:06:16 --> URI Class Initialized
INFO - 2024-10-02 14:06:16 --> Router Class Initialized
INFO - 2024-10-02 14:06:16 --> Output Class Initialized
INFO - 2024-10-02 14:06:16 --> Security Class Initialized
DEBUG - 2024-10-02 14:06:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-02 14:06:16 --> Input Class Initialized
INFO - 2024-10-02 14:06:16 --> Language Class Initialized
INFO - 2024-10-02 14:06:16 --> Language Class Initialized
INFO - 2024-10-02 14:06:16 --> Config Class Initialized
INFO - 2024-10-02 14:06:16 --> Loader Class Initialized
INFO - 2024-10-02 14:06:16 --> Helper loaded: url_helper
INFO - 2024-10-02 14:06:16 --> Helper loaded: file_helper
INFO - 2024-10-02 14:06:16 --> Helper loaded: form_helper
INFO - 2024-10-02 14:06:16 --> Helper loaded: my_helper
INFO - 2024-10-02 14:06:16 --> Database Driver Class Initialized
INFO - 2024-10-02 14:06:16 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-02 14:06:16 --> Controller Class Initialized
DEBUG - 2024-10-02 14:06:16 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/login/views/login.php
DEBUG - 2024-10-02 14:06:16 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-10-02 14:06:16 --> Final output sent to browser
DEBUG - 2024-10-02 14:06:16 --> Total execution time: 0.0533
INFO - 2024-10-02 14:07:31 --> Config Class Initialized
INFO - 2024-10-02 14:07:31 --> Hooks Class Initialized
DEBUG - 2024-10-02 14:07:31 --> UTF-8 Support Enabled
INFO - 2024-10-02 14:07:31 --> Utf8 Class Initialized
INFO - 2024-10-02 14:07:31 --> URI Class Initialized
INFO - 2024-10-02 14:07:31 --> Router Class Initialized
INFO - 2024-10-02 14:07:31 --> Output Class Initialized
INFO - 2024-10-02 14:07:31 --> Security Class Initialized
DEBUG - 2024-10-02 14:07:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-02 14:07:31 --> Input Class Initialized
INFO - 2024-10-02 14:07:31 --> Language Class Initialized
INFO - 2024-10-02 14:07:31 --> Language Class Initialized
INFO - 2024-10-02 14:07:31 --> Config Class Initialized
INFO - 2024-10-02 14:07:31 --> Loader Class Initialized
INFO - 2024-10-02 14:07:31 --> Helper loaded: url_helper
INFO - 2024-10-02 14:07:31 --> Helper loaded: file_helper
INFO - 2024-10-02 14:07:31 --> Helper loaded: form_helper
INFO - 2024-10-02 14:07:31 --> Helper loaded: my_helper
INFO - 2024-10-02 14:07:31 --> Database Driver Class Initialized
INFO - 2024-10-02 14:07:31 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-02 14:07:31 --> Controller Class Initialized
INFO - 2024-10-02 14:07:31 --> Helper loaded: cookie_helper
INFO - 2024-10-02 14:07:31 --> Final output sent to browser
DEBUG - 2024-10-02 14:07:31 --> Total execution time: 0.0328
INFO - 2024-10-02 14:07:31 --> Config Class Initialized
INFO - 2024-10-02 14:07:31 --> Hooks Class Initialized
DEBUG - 2024-10-02 14:07:31 --> UTF-8 Support Enabled
INFO - 2024-10-02 14:07:31 --> Utf8 Class Initialized
INFO - 2024-10-02 14:07:31 --> URI Class Initialized
INFO - 2024-10-02 14:07:31 --> Router Class Initialized
INFO - 2024-10-02 14:07:31 --> Output Class Initialized
INFO - 2024-10-02 14:07:31 --> Security Class Initialized
DEBUG - 2024-10-02 14:07:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-02 14:07:31 --> Input Class Initialized
INFO - 2024-10-02 14:07:31 --> Language Class Initialized
INFO - 2024-10-02 14:07:31 --> Language Class Initialized
INFO - 2024-10-02 14:07:31 --> Config Class Initialized
INFO - 2024-10-02 14:07:31 --> Loader Class Initialized
INFO - 2024-10-02 14:07:31 --> Helper loaded: url_helper
INFO - 2024-10-02 14:07:31 --> Helper loaded: file_helper
INFO - 2024-10-02 14:07:31 --> Helper loaded: form_helper
INFO - 2024-10-02 14:07:31 --> Helper loaded: my_helper
INFO - 2024-10-02 14:07:31 --> Database Driver Class Initialized
INFO - 2024-10-02 14:07:31 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-02 14:07:31 --> Controller Class Initialized
DEBUG - 2024-10-02 14:07:31 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/home/views/v_home_guru.php
DEBUG - 2024-10-02 14:07:31 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-10-02 14:07:31 --> Final output sent to browser
DEBUG - 2024-10-02 14:07:31 --> Total execution time: 0.0306
INFO - 2024-10-02 14:07:38 --> Config Class Initialized
INFO - 2024-10-02 14:07:38 --> Hooks Class Initialized
DEBUG - 2024-10-02 14:07:38 --> UTF-8 Support Enabled
INFO - 2024-10-02 14:07:38 --> Utf8 Class Initialized
INFO - 2024-10-02 14:07:38 --> URI Class Initialized
INFO - 2024-10-02 14:07:38 --> Router Class Initialized
INFO - 2024-10-02 14:07:38 --> Output Class Initialized
INFO - 2024-10-02 14:07:38 --> Security Class Initialized
DEBUG - 2024-10-02 14:07:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-02 14:07:38 --> Input Class Initialized
INFO - 2024-10-02 14:07:38 --> Language Class Initialized
INFO - 2024-10-02 14:07:38 --> Language Class Initialized
INFO - 2024-10-02 14:07:38 --> Config Class Initialized
INFO - 2024-10-02 14:07:38 --> Loader Class Initialized
INFO - 2024-10-02 14:07:38 --> Helper loaded: url_helper
INFO - 2024-10-02 14:07:38 --> Helper loaded: file_helper
INFO - 2024-10-02 14:07:38 --> Helper loaded: form_helper
INFO - 2024-10-02 14:07:38 --> Helper loaded: my_helper
INFO - 2024-10-02 14:07:38 --> Database Driver Class Initialized
INFO - 2024-10-02 14:07:38 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-02 14:07:38 --> Controller Class Initialized
DEBUG - 2024-10-02 14:07:38 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/view_mapel/views/v_view_mapel.php
DEBUG - 2024-10-02 14:07:38 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-10-02 14:07:38 --> Final output sent to browser
DEBUG - 2024-10-02 14:07:38 --> Total execution time: 0.0335
INFO - 2024-10-02 14:07:40 --> Config Class Initialized
INFO - 2024-10-02 14:07:40 --> Hooks Class Initialized
DEBUG - 2024-10-02 14:07:40 --> UTF-8 Support Enabled
INFO - 2024-10-02 14:07:40 --> Utf8 Class Initialized
INFO - 2024-10-02 14:07:40 --> URI Class Initialized
INFO - 2024-10-02 14:07:40 --> Router Class Initialized
INFO - 2024-10-02 14:07:40 --> Output Class Initialized
INFO - 2024-10-02 14:07:40 --> Security Class Initialized
DEBUG - 2024-10-02 14:07:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-02 14:07:40 --> Input Class Initialized
INFO - 2024-10-02 14:07:40 --> Language Class Initialized
INFO - 2024-10-02 14:07:40 --> Language Class Initialized
INFO - 2024-10-02 14:07:40 --> Config Class Initialized
INFO - 2024-10-02 14:07:40 --> Loader Class Initialized
INFO - 2024-10-02 14:07:40 --> Helper loaded: url_helper
INFO - 2024-10-02 14:07:40 --> Helper loaded: file_helper
INFO - 2024-10-02 14:07:40 --> Helper loaded: form_helper
INFO - 2024-10-02 14:07:40 --> Helper loaded: my_helper
INFO - 2024-10-02 14:07:40 --> Database Driver Class Initialized
INFO - 2024-10-02 14:07:40 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-02 14:07:40 --> Controller Class Initialized
DEBUG - 2024-10-02 14:07:40 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_catatan_guru/views/list.php
DEBUG - 2024-10-02 14:07:40 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-10-02 14:07:40 --> Final output sent to browser
DEBUG - 2024-10-02 14:07:40 --> Total execution time: 0.0386
INFO - 2024-10-02 14:07:42 --> Config Class Initialized
INFO - 2024-10-02 14:07:42 --> Hooks Class Initialized
DEBUG - 2024-10-02 14:07:42 --> UTF-8 Support Enabled
INFO - 2024-10-02 14:07:42 --> Utf8 Class Initialized
INFO - 2024-10-02 14:07:42 --> URI Class Initialized
INFO - 2024-10-02 14:07:42 --> Router Class Initialized
INFO - 2024-10-02 14:07:42 --> Output Class Initialized
INFO - 2024-10-02 14:07:42 --> Security Class Initialized
DEBUG - 2024-10-02 14:07:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-02 14:07:42 --> Input Class Initialized
INFO - 2024-10-02 14:07:42 --> Language Class Initialized
INFO - 2024-10-02 14:07:42 --> Language Class Initialized
INFO - 2024-10-02 14:07:42 --> Config Class Initialized
INFO - 2024-10-02 14:07:42 --> Loader Class Initialized
INFO - 2024-10-02 14:07:42 --> Helper loaded: url_helper
INFO - 2024-10-02 14:07:42 --> Helper loaded: file_helper
INFO - 2024-10-02 14:07:42 --> Helper loaded: form_helper
INFO - 2024-10-02 14:07:42 --> Helper loaded: my_helper
INFO - 2024-10-02 14:07:42 --> Database Driver Class Initialized
INFO - 2024-10-02 14:07:42 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-02 14:07:42 --> Controller Class Initialized
INFO - 2024-10-02 14:07:42 --> Final output sent to browser
DEBUG - 2024-10-02 14:07:42 --> Total execution time: 0.0460
INFO - 2024-10-02 14:07:52 --> Config Class Initialized
INFO - 2024-10-02 14:07:52 --> Hooks Class Initialized
DEBUG - 2024-10-02 14:07:52 --> UTF-8 Support Enabled
INFO - 2024-10-02 14:07:52 --> Utf8 Class Initialized
INFO - 2024-10-02 14:07:52 --> URI Class Initialized
INFO - 2024-10-02 14:07:52 --> Router Class Initialized
INFO - 2024-10-02 14:07:52 --> Output Class Initialized
INFO - 2024-10-02 14:07:52 --> Security Class Initialized
DEBUG - 2024-10-02 14:07:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-02 14:07:52 --> Input Class Initialized
INFO - 2024-10-02 14:07:52 --> Language Class Initialized
INFO - 2024-10-02 14:07:52 --> Language Class Initialized
INFO - 2024-10-02 14:07:52 --> Config Class Initialized
INFO - 2024-10-02 14:07:52 --> Loader Class Initialized
INFO - 2024-10-02 14:07:52 --> Helper loaded: url_helper
INFO - 2024-10-02 14:07:52 --> Helper loaded: file_helper
INFO - 2024-10-02 14:07:52 --> Helper loaded: form_helper
INFO - 2024-10-02 14:07:52 --> Helper loaded: my_helper
INFO - 2024-10-02 14:07:52 --> Database Driver Class Initialized
INFO - 2024-10-02 14:07:52 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-02 14:07:52 --> Controller Class Initialized
INFO - 2024-10-02 14:08:41 --> Config Class Initialized
INFO - 2024-10-02 14:08:41 --> Hooks Class Initialized
DEBUG - 2024-10-02 14:08:41 --> UTF-8 Support Enabled
INFO - 2024-10-02 14:08:41 --> Utf8 Class Initialized
INFO - 2024-10-02 14:08:41 --> URI Class Initialized
INFO - 2024-10-02 14:08:41 --> Router Class Initialized
INFO - 2024-10-02 14:08:41 --> Output Class Initialized
INFO - 2024-10-02 14:08:41 --> Security Class Initialized
DEBUG - 2024-10-02 14:08:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-02 14:08:41 --> Input Class Initialized
INFO - 2024-10-02 14:08:41 --> Language Class Initialized
INFO - 2024-10-02 14:08:41 --> Language Class Initialized
INFO - 2024-10-02 14:08:41 --> Config Class Initialized
INFO - 2024-10-02 14:08:41 --> Loader Class Initialized
INFO - 2024-10-02 14:08:41 --> Helper loaded: url_helper
INFO - 2024-10-02 14:08:41 --> Helper loaded: file_helper
INFO - 2024-10-02 14:08:41 --> Helper loaded: form_helper
INFO - 2024-10-02 14:08:41 --> Helper loaded: my_helper
INFO - 2024-10-02 14:08:41 --> Database Driver Class Initialized
INFO - 2024-10-02 14:08:41 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-02 14:08:41 --> Controller Class Initialized
INFO - 2024-10-02 14:08:41 --> Final output sent to browser
DEBUG - 2024-10-02 14:08:41 --> Total execution time: 0.1586
INFO - 2024-10-02 14:08:45 --> Config Class Initialized
INFO - 2024-10-02 14:08:45 --> Hooks Class Initialized
DEBUG - 2024-10-02 14:08:45 --> UTF-8 Support Enabled
INFO - 2024-10-02 14:08:45 --> Utf8 Class Initialized
INFO - 2024-10-02 14:08:45 --> URI Class Initialized
INFO - 2024-10-02 14:08:45 --> Router Class Initialized
INFO - 2024-10-02 14:08:45 --> Output Class Initialized
INFO - 2024-10-02 14:08:45 --> Security Class Initialized
DEBUG - 2024-10-02 14:08:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-02 14:08:45 --> Input Class Initialized
INFO - 2024-10-02 14:08:45 --> Language Class Initialized
INFO - 2024-10-02 14:08:45 --> Language Class Initialized
INFO - 2024-10-02 14:08:45 --> Config Class Initialized
INFO - 2024-10-02 14:08:45 --> Loader Class Initialized
INFO - 2024-10-02 14:08:45 --> Helper loaded: url_helper
INFO - 2024-10-02 14:08:45 --> Helper loaded: file_helper
INFO - 2024-10-02 14:08:45 --> Helper loaded: form_helper
INFO - 2024-10-02 14:08:45 --> Helper loaded: my_helper
INFO - 2024-10-02 14:08:45 --> Database Driver Class Initialized
INFO - 2024-10-02 14:08:45 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-02 14:08:45 --> Controller Class Initialized
INFO - 2024-10-02 14:08:45 --> Final output sent to browser
DEBUG - 2024-10-02 14:08:45 --> Total execution time: 0.0329
INFO - 2024-10-02 14:08:47 --> Config Class Initialized
INFO - 2024-10-02 14:08:47 --> Hooks Class Initialized
DEBUG - 2024-10-02 14:08:47 --> UTF-8 Support Enabled
INFO - 2024-10-02 14:08:47 --> Utf8 Class Initialized
INFO - 2024-10-02 14:08:47 --> URI Class Initialized
INFO - 2024-10-02 14:08:47 --> Router Class Initialized
INFO - 2024-10-02 14:08:47 --> Output Class Initialized
INFO - 2024-10-02 14:08:47 --> Security Class Initialized
DEBUG - 2024-10-02 14:08:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-02 14:08:47 --> Input Class Initialized
INFO - 2024-10-02 14:08:47 --> Language Class Initialized
INFO - 2024-10-02 14:08:47 --> Language Class Initialized
INFO - 2024-10-02 14:08:47 --> Config Class Initialized
INFO - 2024-10-02 14:08:47 --> Loader Class Initialized
INFO - 2024-10-02 14:08:47 --> Helper loaded: url_helper
INFO - 2024-10-02 14:08:47 --> Helper loaded: file_helper
INFO - 2024-10-02 14:08:47 --> Helper loaded: form_helper
INFO - 2024-10-02 14:08:47 --> Helper loaded: my_helper
INFO - 2024-10-02 14:08:47 --> Database Driver Class Initialized
INFO - 2024-10-02 14:08:47 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-02 14:08:47 --> Controller Class Initialized
INFO - 2024-10-02 14:08:47 --> Final output sent to browser
DEBUG - 2024-10-02 14:08:47 --> Total execution time: 0.0366
INFO - 2024-10-02 14:09:59 --> Config Class Initialized
INFO - 2024-10-02 14:09:59 --> Hooks Class Initialized
DEBUG - 2024-10-02 14:09:59 --> UTF-8 Support Enabled
INFO - 2024-10-02 14:09:59 --> Utf8 Class Initialized
INFO - 2024-10-02 14:09:59 --> URI Class Initialized
INFO - 2024-10-02 14:09:59 --> Router Class Initialized
INFO - 2024-10-02 14:09:59 --> Output Class Initialized
INFO - 2024-10-02 14:09:59 --> Security Class Initialized
DEBUG - 2024-10-02 14:09:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-02 14:09:59 --> Input Class Initialized
INFO - 2024-10-02 14:09:59 --> Language Class Initialized
INFO - 2024-10-02 14:09:59 --> Language Class Initialized
INFO - 2024-10-02 14:09:59 --> Config Class Initialized
INFO - 2024-10-02 14:09:59 --> Loader Class Initialized
INFO - 2024-10-02 14:09:59 --> Helper loaded: url_helper
INFO - 2024-10-02 14:09:59 --> Helper loaded: file_helper
INFO - 2024-10-02 14:09:59 --> Helper loaded: form_helper
INFO - 2024-10-02 14:09:59 --> Helper loaded: my_helper
INFO - 2024-10-02 14:09:59 --> Database Driver Class Initialized
INFO - 2024-10-02 14:09:59 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-02 14:09:59 --> Controller Class Initialized
INFO - 2024-10-02 14:09:59 --> Final output sent to browser
DEBUG - 2024-10-02 14:09:59 --> Total execution time: 0.0822
INFO - 2024-10-02 14:10:05 --> Config Class Initialized
INFO - 2024-10-02 14:10:05 --> Hooks Class Initialized
DEBUG - 2024-10-02 14:10:05 --> UTF-8 Support Enabled
INFO - 2024-10-02 14:10:05 --> Utf8 Class Initialized
INFO - 2024-10-02 14:10:05 --> URI Class Initialized
INFO - 2024-10-02 14:10:05 --> Router Class Initialized
INFO - 2024-10-02 14:10:05 --> Output Class Initialized
INFO - 2024-10-02 14:10:05 --> Security Class Initialized
DEBUG - 2024-10-02 14:10:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-02 14:10:05 --> Input Class Initialized
INFO - 2024-10-02 14:10:05 --> Language Class Initialized
INFO - 2024-10-02 14:10:05 --> Language Class Initialized
INFO - 2024-10-02 14:10:05 --> Config Class Initialized
INFO - 2024-10-02 14:10:05 --> Loader Class Initialized
INFO - 2024-10-02 14:10:05 --> Helper loaded: url_helper
INFO - 2024-10-02 14:10:05 --> Helper loaded: file_helper
INFO - 2024-10-02 14:10:05 --> Helper loaded: form_helper
INFO - 2024-10-02 14:10:05 --> Helper loaded: my_helper
INFO - 2024-10-02 14:10:05 --> Database Driver Class Initialized
INFO - 2024-10-02 14:10:05 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-02 14:10:05 --> Controller Class Initialized
INFO - 2024-10-02 14:10:05 --> Final output sent to browser
DEBUG - 2024-10-02 14:10:05 --> Total execution time: 0.0359
INFO - 2024-10-02 14:10:06 --> Config Class Initialized
INFO - 2024-10-02 14:10:06 --> Hooks Class Initialized
DEBUG - 2024-10-02 14:10:06 --> UTF-8 Support Enabled
INFO - 2024-10-02 14:10:06 --> Utf8 Class Initialized
INFO - 2024-10-02 14:10:06 --> URI Class Initialized
INFO - 2024-10-02 14:10:06 --> Router Class Initialized
INFO - 2024-10-02 14:10:06 --> Output Class Initialized
INFO - 2024-10-02 14:10:06 --> Security Class Initialized
DEBUG - 2024-10-02 14:10:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-02 14:10:06 --> Input Class Initialized
INFO - 2024-10-02 14:10:06 --> Language Class Initialized
INFO - 2024-10-02 14:10:06 --> Language Class Initialized
INFO - 2024-10-02 14:10:06 --> Config Class Initialized
INFO - 2024-10-02 14:10:06 --> Loader Class Initialized
INFO - 2024-10-02 14:10:06 --> Helper loaded: url_helper
INFO - 2024-10-02 14:10:06 --> Helper loaded: file_helper
INFO - 2024-10-02 14:10:06 --> Helper loaded: form_helper
INFO - 2024-10-02 14:10:06 --> Helper loaded: my_helper
INFO - 2024-10-02 14:10:06 --> Database Driver Class Initialized
INFO - 2024-10-02 14:10:06 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-02 14:10:06 --> Controller Class Initialized
INFO - 2024-10-02 14:10:06 --> Final output sent to browser
DEBUG - 2024-10-02 14:10:06 --> Total execution time: 0.0339
INFO - 2024-10-02 14:10:33 --> Config Class Initialized
INFO - 2024-10-02 14:10:33 --> Hooks Class Initialized
DEBUG - 2024-10-02 14:10:33 --> UTF-8 Support Enabled
INFO - 2024-10-02 14:10:33 --> Utf8 Class Initialized
INFO - 2024-10-02 14:10:33 --> URI Class Initialized
INFO - 2024-10-02 14:10:33 --> Router Class Initialized
INFO - 2024-10-02 14:10:33 --> Output Class Initialized
INFO - 2024-10-02 14:10:33 --> Security Class Initialized
DEBUG - 2024-10-02 14:10:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-02 14:10:33 --> Input Class Initialized
INFO - 2024-10-02 14:10:33 --> Language Class Initialized
INFO - 2024-10-02 14:10:33 --> Language Class Initialized
INFO - 2024-10-02 14:10:33 --> Config Class Initialized
INFO - 2024-10-02 14:10:33 --> Loader Class Initialized
INFO - 2024-10-02 14:10:33 --> Helper loaded: url_helper
INFO - 2024-10-02 14:10:33 --> Helper loaded: file_helper
INFO - 2024-10-02 14:10:33 --> Helper loaded: form_helper
INFO - 2024-10-02 14:10:33 --> Helper loaded: my_helper
INFO - 2024-10-02 14:10:33 --> Database Driver Class Initialized
INFO - 2024-10-02 14:10:33 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-02 14:10:33 --> Controller Class Initialized
DEBUG - 2024-10-02 14:10:33 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_catatan_guru/views/form.php
DEBUG - 2024-10-02 14:10:33 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-10-02 14:10:33 --> Final output sent to browser
DEBUG - 2024-10-02 14:10:33 --> Total execution time: 0.0832
INFO - 2024-10-02 14:10:43 --> Config Class Initialized
INFO - 2024-10-02 14:10:43 --> Hooks Class Initialized
DEBUG - 2024-10-02 14:10:43 --> UTF-8 Support Enabled
INFO - 2024-10-02 14:10:43 --> Utf8 Class Initialized
INFO - 2024-10-02 14:10:43 --> URI Class Initialized
INFO - 2024-10-02 14:10:43 --> Router Class Initialized
INFO - 2024-10-02 14:10:43 --> Output Class Initialized
INFO - 2024-10-02 14:10:43 --> Security Class Initialized
DEBUG - 2024-10-02 14:10:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-02 14:10:43 --> Input Class Initialized
INFO - 2024-10-02 14:10:43 --> Language Class Initialized
INFO - 2024-10-02 14:10:43 --> Language Class Initialized
INFO - 2024-10-02 14:10:43 --> Config Class Initialized
INFO - 2024-10-02 14:10:43 --> Loader Class Initialized
INFO - 2024-10-02 14:10:43 --> Helper loaded: url_helper
INFO - 2024-10-02 14:10:43 --> Helper loaded: file_helper
INFO - 2024-10-02 14:10:43 --> Helper loaded: form_helper
INFO - 2024-10-02 14:10:43 --> Helper loaded: my_helper
INFO - 2024-10-02 14:10:43 --> Database Driver Class Initialized
INFO - 2024-10-02 14:10:43 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-02 14:10:43 --> Controller Class Initialized
INFO - 2024-10-02 14:10:44 --> Config Class Initialized
INFO - 2024-10-02 14:10:44 --> Hooks Class Initialized
DEBUG - 2024-10-02 14:10:44 --> UTF-8 Support Enabled
INFO - 2024-10-02 14:10:44 --> Utf8 Class Initialized
INFO - 2024-10-02 14:10:44 --> URI Class Initialized
INFO - 2024-10-02 14:10:44 --> Router Class Initialized
INFO - 2024-10-02 14:10:44 --> Output Class Initialized
INFO - 2024-10-02 14:10:44 --> Security Class Initialized
DEBUG - 2024-10-02 14:10:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-02 14:10:44 --> Input Class Initialized
INFO - 2024-10-02 14:10:44 --> Language Class Initialized
INFO - 2024-10-02 14:10:44 --> Language Class Initialized
INFO - 2024-10-02 14:10:44 --> Config Class Initialized
INFO - 2024-10-02 14:10:44 --> Loader Class Initialized
INFO - 2024-10-02 14:10:44 --> Helper loaded: url_helper
INFO - 2024-10-02 14:10:44 --> Helper loaded: file_helper
INFO - 2024-10-02 14:10:44 --> Helper loaded: form_helper
INFO - 2024-10-02 14:10:44 --> Helper loaded: my_helper
INFO - 2024-10-02 14:10:44 --> Database Driver Class Initialized
INFO - 2024-10-02 14:10:44 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-02 14:10:44 --> Controller Class Initialized
DEBUG - 2024-10-02 14:10:44 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_catatan_guru/views/list.php
DEBUG - 2024-10-02 14:10:44 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-10-02 14:10:44 --> Final output sent to browser
DEBUG - 2024-10-02 14:10:44 --> Total execution time: 0.0370
INFO - 2024-10-02 14:10:46 --> Config Class Initialized
INFO - 2024-10-02 14:10:46 --> Hooks Class Initialized
DEBUG - 2024-10-02 14:10:46 --> UTF-8 Support Enabled
INFO - 2024-10-02 14:10:46 --> Utf8 Class Initialized
INFO - 2024-10-02 14:10:46 --> URI Class Initialized
INFO - 2024-10-02 14:10:46 --> Router Class Initialized
INFO - 2024-10-02 14:10:46 --> Output Class Initialized
INFO - 2024-10-02 14:10:46 --> Security Class Initialized
DEBUG - 2024-10-02 14:10:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-02 14:10:46 --> Input Class Initialized
INFO - 2024-10-02 14:10:46 --> Language Class Initialized
INFO - 2024-10-02 14:10:46 --> Language Class Initialized
INFO - 2024-10-02 14:10:46 --> Config Class Initialized
INFO - 2024-10-02 14:10:46 --> Loader Class Initialized
INFO - 2024-10-02 14:10:46 --> Helper loaded: url_helper
INFO - 2024-10-02 14:10:46 --> Helper loaded: file_helper
INFO - 2024-10-02 14:10:46 --> Helper loaded: form_helper
INFO - 2024-10-02 14:10:46 --> Helper loaded: my_helper
INFO - 2024-10-02 14:10:46 --> Database Driver Class Initialized
INFO - 2024-10-02 14:10:46 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-02 14:10:46 --> Controller Class Initialized
INFO - 2024-10-02 14:10:46 --> Final output sent to browser
DEBUG - 2024-10-02 14:10:46 --> Total execution time: 0.0411
INFO - 2024-10-02 14:10:54 --> Config Class Initialized
INFO - 2024-10-02 14:10:54 --> Hooks Class Initialized
DEBUG - 2024-10-02 14:10:54 --> UTF-8 Support Enabled
INFO - 2024-10-02 14:10:54 --> Utf8 Class Initialized
INFO - 2024-10-02 14:10:54 --> URI Class Initialized
INFO - 2024-10-02 14:10:54 --> Router Class Initialized
INFO - 2024-10-02 14:10:54 --> Output Class Initialized
INFO - 2024-10-02 14:10:54 --> Security Class Initialized
DEBUG - 2024-10-02 14:10:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-02 14:10:54 --> Input Class Initialized
INFO - 2024-10-02 14:10:54 --> Language Class Initialized
INFO - 2024-10-02 14:10:54 --> Language Class Initialized
INFO - 2024-10-02 14:10:54 --> Config Class Initialized
INFO - 2024-10-02 14:10:54 --> Loader Class Initialized
INFO - 2024-10-02 14:10:54 --> Helper loaded: url_helper
INFO - 2024-10-02 14:10:54 --> Helper loaded: file_helper
INFO - 2024-10-02 14:10:54 --> Helper loaded: form_helper
INFO - 2024-10-02 14:10:54 --> Helper loaded: my_helper
INFO - 2024-10-02 14:10:54 --> Database Driver Class Initialized
INFO - 2024-10-02 14:10:54 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-02 14:10:54 --> Controller Class Initialized
DEBUG - 2024-10-02 14:10:54 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/view_mapel/views/v_view_mapel.php
DEBUG - 2024-10-02 14:10:54 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-10-02 14:10:54 --> Final output sent to browser
DEBUG - 2024-10-02 14:10:54 --> Total execution time: 0.0375
INFO - 2024-10-02 14:10:58 --> Config Class Initialized
INFO - 2024-10-02 14:10:58 --> Hooks Class Initialized
DEBUG - 2024-10-02 14:10:58 --> UTF-8 Support Enabled
INFO - 2024-10-02 14:10:58 --> Utf8 Class Initialized
INFO - 2024-10-02 14:10:58 --> URI Class Initialized
INFO - 2024-10-02 14:10:58 --> Router Class Initialized
INFO - 2024-10-02 14:10:58 --> Output Class Initialized
INFO - 2024-10-02 14:10:58 --> Security Class Initialized
DEBUG - 2024-10-02 14:10:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-02 14:10:58 --> Input Class Initialized
INFO - 2024-10-02 14:10:58 --> Language Class Initialized
INFO - 2024-10-02 14:10:58 --> Language Class Initialized
INFO - 2024-10-02 14:10:58 --> Config Class Initialized
INFO - 2024-10-02 14:10:58 --> Loader Class Initialized
INFO - 2024-10-02 14:10:58 --> Helper loaded: url_helper
INFO - 2024-10-02 14:10:58 --> Helper loaded: file_helper
INFO - 2024-10-02 14:10:58 --> Helper loaded: form_helper
INFO - 2024-10-02 14:10:58 --> Helper loaded: my_helper
INFO - 2024-10-02 14:10:58 --> Database Driver Class Initialized
INFO - 2024-10-02 14:10:58 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-02 14:10:58 --> Controller Class Initialized
DEBUG - 2024-10-02 14:10:58 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_catatan_guru/views/list.php
DEBUG - 2024-10-02 14:10:58 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-10-02 14:10:58 --> Final output sent to browser
DEBUG - 2024-10-02 14:10:58 --> Total execution time: 0.0371
INFO - 2024-10-02 14:11:01 --> Config Class Initialized
INFO - 2024-10-02 14:11:01 --> Hooks Class Initialized
DEBUG - 2024-10-02 14:11:01 --> UTF-8 Support Enabled
INFO - 2024-10-02 14:11:01 --> Utf8 Class Initialized
INFO - 2024-10-02 14:11:01 --> URI Class Initialized
INFO - 2024-10-02 14:11:01 --> Router Class Initialized
INFO - 2024-10-02 14:11:01 --> Output Class Initialized
INFO - 2024-10-02 14:11:01 --> Security Class Initialized
DEBUG - 2024-10-02 14:11:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-02 14:11:01 --> Input Class Initialized
INFO - 2024-10-02 14:11:01 --> Language Class Initialized
INFO - 2024-10-02 14:11:01 --> Language Class Initialized
INFO - 2024-10-02 14:11:01 --> Config Class Initialized
INFO - 2024-10-02 14:11:01 --> Loader Class Initialized
INFO - 2024-10-02 14:11:01 --> Helper loaded: url_helper
INFO - 2024-10-02 14:11:01 --> Helper loaded: file_helper
INFO - 2024-10-02 14:11:01 --> Helper loaded: form_helper
INFO - 2024-10-02 14:11:01 --> Helper loaded: my_helper
INFO - 2024-10-02 14:11:01 --> Database Driver Class Initialized
INFO - 2024-10-02 14:11:01 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-02 14:11:01 --> Controller Class Initialized
INFO - 2024-10-02 14:11:26 --> Config Class Initialized
INFO - 2024-10-02 14:11:26 --> Hooks Class Initialized
DEBUG - 2024-10-02 14:11:26 --> UTF-8 Support Enabled
INFO - 2024-10-02 14:11:26 --> Utf8 Class Initialized
INFO - 2024-10-02 14:11:26 --> URI Class Initialized
INFO - 2024-10-02 14:11:26 --> Router Class Initialized
INFO - 2024-10-02 14:11:26 --> Output Class Initialized
INFO - 2024-10-02 14:11:26 --> Security Class Initialized
DEBUG - 2024-10-02 14:11:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-02 14:11:26 --> Input Class Initialized
INFO - 2024-10-02 14:11:26 --> Language Class Initialized
INFO - 2024-10-02 14:11:26 --> Language Class Initialized
INFO - 2024-10-02 14:11:26 --> Config Class Initialized
INFO - 2024-10-02 14:11:26 --> Loader Class Initialized
INFO - 2024-10-02 14:11:26 --> Helper loaded: url_helper
INFO - 2024-10-02 14:11:26 --> Helper loaded: file_helper
INFO - 2024-10-02 14:11:26 --> Helper loaded: form_helper
INFO - 2024-10-02 14:11:26 --> Helper loaded: my_helper
INFO - 2024-10-02 14:11:26 --> Database Driver Class Initialized
INFO - 2024-10-02 14:11:26 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-02 14:11:26 --> Controller Class Initialized
INFO - 2024-10-02 14:11:26 --> Final output sent to browser
DEBUG - 2024-10-02 14:11:26 --> Total execution time: 0.0604
INFO - 2024-10-02 14:11:34 --> Config Class Initialized
INFO - 2024-10-02 14:11:34 --> Hooks Class Initialized
DEBUG - 2024-10-02 14:11:34 --> UTF-8 Support Enabled
INFO - 2024-10-02 14:11:34 --> Utf8 Class Initialized
INFO - 2024-10-02 14:11:34 --> URI Class Initialized
INFO - 2024-10-02 14:11:34 --> Router Class Initialized
INFO - 2024-10-02 14:11:34 --> Output Class Initialized
INFO - 2024-10-02 14:11:34 --> Security Class Initialized
DEBUG - 2024-10-02 14:11:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-02 14:11:34 --> Input Class Initialized
INFO - 2024-10-02 14:11:34 --> Language Class Initialized
INFO - 2024-10-02 14:11:34 --> Language Class Initialized
INFO - 2024-10-02 14:11:34 --> Config Class Initialized
INFO - 2024-10-02 14:11:34 --> Loader Class Initialized
INFO - 2024-10-02 14:11:34 --> Helper loaded: url_helper
INFO - 2024-10-02 14:11:34 --> Helper loaded: file_helper
INFO - 2024-10-02 14:11:34 --> Helper loaded: form_helper
INFO - 2024-10-02 14:11:34 --> Helper loaded: my_helper
INFO - 2024-10-02 14:11:34 --> Database Driver Class Initialized
INFO - 2024-10-02 14:11:34 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-02 14:11:34 --> Controller Class Initialized
DEBUG - 2024-10-02 14:11:34 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/view_mapel/views/v_view_mapel.php
DEBUG - 2024-10-02 14:11:34 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-10-02 14:11:34 --> Final output sent to browser
DEBUG - 2024-10-02 14:11:34 --> Total execution time: 0.0381
INFO - 2024-10-02 14:11:39 --> Config Class Initialized
INFO - 2024-10-02 14:11:39 --> Hooks Class Initialized
DEBUG - 2024-10-02 14:11:39 --> UTF-8 Support Enabled
INFO - 2024-10-02 14:11:39 --> Utf8 Class Initialized
INFO - 2024-10-02 14:11:39 --> URI Class Initialized
INFO - 2024-10-02 14:11:39 --> Router Class Initialized
INFO - 2024-10-02 14:11:39 --> Output Class Initialized
INFO - 2024-10-02 14:11:39 --> Security Class Initialized
DEBUG - 2024-10-02 14:11:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-02 14:11:39 --> Input Class Initialized
INFO - 2024-10-02 14:11:39 --> Language Class Initialized
INFO - 2024-10-02 14:11:39 --> Language Class Initialized
INFO - 2024-10-02 14:11:39 --> Config Class Initialized
INFO - 2024-10-02 14:11:39 --> Loader Class Initialized
INFO - 2024-10-02 14:11:39 --> Helper loaded: url_helper
INFO - 2024-10-02 14:11:39 --> Helper loaded: file_helper
INFO - 2024-10-02 14:11:39 --> Helper loaded: form_helper
INFO - 2024-10-02 14:11:39 --> Helper loaded: my_helper
INFO - 2024-10-02 14:11:39 --> Database Driver Class Initialized
INFO - 2024-10-02 14:11:39 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-02 14:11:39 --> Controller Class Initialized
DEBUG - 2024-10-02 14:11:39 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/views/list.php
DEBUG - 2024-10-02 14:11:39 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-10-02 14:11:39 --> Final output sent to browser
DEBUG - 2024-10-02 14:11:39 --> Total execution time: 0.0326
INFO - 2024-10-02 14:11:39 --> Config Class Initialized
INFO - 2024-10-02 14:11:39 --> Hooks Class Initialized
DEBUG - 2024-10-02 14:11:39 --> UTF-8 Support Enabled
INFO - 2024-10-02 14:11:39 --> Utf8 Class Initialized
INFO - 2024-10-02 14:11:39 --> URI Class Initialized
INFO - 2024-10-02 14:11:39 --> Router Class Initialized
INFO - 2024-10-02 14:11:39 --> Output Class Initialized
INFO - 2024-10-02 14:11:39 --> Security Class Initialized
DEBUG - 2024-10-02 14:11:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-02 14:11:39 --> Input Class Initialized
INFO - 2024-10-02 14:11:39 --> Language Class Initialized
INFO - 2024-10-02 14:11:39 --> Language Class Initialized
INFO - 2024-10-02 14:11:39 --> Config Class Initialized
INFO - 2024-10-02 14:11:39 --> Loader Class Initialized
INFO - 2024-10-02 14:11:39 --> Helper loaded: url_helper
INFO - 2024-10-02 14:11:39 --> Helper loaded: file_helper
INFO - 2024-10-02 14:11:39 --> Helper loaded: form_helper
INFO - 2024-10-02 14:11:39 --> Helper loaded: my_helper
INFO - 2024-10-02 14:11:39 --> Database Driver Class Initialized
INFO - 2024-10-02 14:11:39 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-02 14:11:39 --> Controller Class Initialized
INFO - 2024-10-02 14:11:41 --> Config Class Initialized
INFO - 2024-10-02 14:11:41 --> Hooks Class Initialized
DEBUG - 2024-10-02 14:11:41 --> UTF-8 Support Enabled
INFO - 2024-10-02 14:11:41 --> Utf8 Class Initialized
INFO - 2024-10-02 14:11:41 --> URI Class Initialized
INFO - 2024-10-02 14:11:41 --> Router Class Initialized
INFO - 2024-10-02 14:11:41 --> Output Class Initialized
INFO - 2024-10-02 14:11:41 --> Security Class Initialized
DEBUG - 2024-10-02 14:11:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-02 14:11:41 --> Input Class Initialized
INFO - 2024-10-02 14:11:41 --> Language Class Initialized
INFO - 2024-10-02 14:11:41 --> Language Class Initialized
INFO - 2024-10-02 14:11:41 --> Config Class Initialized
INFO - 2024-10-02 14:11:41 --> Loader Class Initialized
INFO - 2024-10-02 14:11:41 --> Helper loaded: url_helper
INFO - 2024-10-02 14:11:41 --> Helper loaded: file_helper
INFO - 2024-10-02 14:11:41 --> Helper loaded: form_helper
INFO - 2024-10-02 14:11:41 --> Helper loaded: my_helper
INFO - 2024-10-02 14:11:41 --> Database Driver Class Initialized
INFO - 2024-10-02 14:11:41 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-02 14:11:41 --> Controller Class Initialized
INFO - 2024-10-02 14:11:41 --> Final output sent to browser
DEBUG - 2024-10-02 14:11:41 --> Total execution time: 0.0373
INFO - 2024-10-02 14:12:29 --> Config Class Initialized
INFO - 2024-10-02 14:12:29 --> Hooks Class Initialized
DEBUG - 2024-10-02 14:12:29 --> UTF-8 Support Enabled
INFO - 2024-10-02 14:12:29 --> Utf8 Class Initialized
INFO - 2024-10-02 14:12:29 --> URI Class Initialized
INFO - 2024-10-02 14:12:29 --> Router Class Initialized
INFO - 2024-10-02 14:12:29 --> Output Class Initialized
INFO - 2024-10-02 14:12:29 --> Security Class Initialized
DEBUG - 2024-10-02 14:12:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-02 14:12:29 --> Input Class Initialized
INFO - 2024-10-02 14:12:29 --> Language Class Initialized
INFO - 2024-10-02 14:12:29 --> Language Class Initialized
INFO - 2024-10-02 14:12:29 --> Config Class Initialized
INFO - 2024-10-02 14:12:29 --> Loader Class Initialized
INFO - 2024-10-02 14:12:29 --> Helper loaded: url_helper
INFO - 2024-10-02 14:12:29 --> Helper loaded: file_helper
INFO - 2024-10-02 14:12:29 --> Helper loaded: form_helper
INFO - 2024-10-02 14:12:29 --> Helper loaded: my_helper
INFO - 2024-10-02 14:12:29 --> Database Driver Class Initialized
INFO - 2024-10-02 14:12:29 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-02 14:12:29 --> Controller Class Initialized
DEBUG - 2024-10-02 14:12:29 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/view_mapel/views/v_view_mapel.php
DEBUG - 2024-10-02 14:12:29 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-10-02 14:12:29 --> Final output sent to browser
DEBUG - 2024-10-02 14:12:29 --> Total execution time: 0.0305
INFO - 2024-10-02 14:12:31 --> Config Class Initialized
INFO - 2024-10-02 14:12:31 --> Hooks Class Initialized
DEBUG - 2024-10-02 14:12:31 --> UTF-8 Support Enabled
INFO - 2024-10-02 14:12:31 --> Utf8 Class Initialized
INFO - 2024-10-02 14:12:31 --> URI Class Initialized
INFO - 2024-10-02 14:12:31 --> Router Class Initialized
INFO - 2024-10-02 14:12:31 --> Output Class Initialized
INFO - 2024-10-02 14:12:31 --> Security Class Initialized
DEBUG - 2024-10-02 14:12:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-02 14:12:31 --> Input Class Initialized
INFO - 2024-10-02 14:12:31 --> Language Class Initialized
INFO - 2024-10-02 14:12:31 --> Language Class Initialized
INFO - 2024-10-02 14:12:31 --> Config Class Initialized
INFO - 2024-10-02 14:12:31 --> Loader Class Initialized
INFO - 2024-10-02 14:12:31 --> Helper loaded: url_helper
INFO - 2024-10-02 14:12:31 --> Helper loaded: file_helper
INFO - 2024-10-02 14:12:31 --> Helper loaded: form_helper
INFO - 2024-10-02 14:12:31 --> Helper loaded: my_helper
INFO - 2024-10-02 14:12:31 --> Database Driver Class Initialized
INFO - 2024-10-02 14:12:31 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-02 14:12:31 --> Controller Class Initialized
DEBUG - 2024-10-02 14:12:31 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_icb/views/list.php
DEBUG - 2024-10-02 14:12:31 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-10-02 14:12:31 --> Final output sent to browser
DEBUG - 2024-10-02 14:12:31 --> Total execution time: 0.0378
INFO - 2024-10-02 14:12:31 --> Config Class Initialized
INFO - 2024-10-02 14:12:31 --> Hooks Class Initialized
DEBUG - 2024-10-02 14:12:31 --> UTF-8 Support Enabled
INFO - 2024-10-02 14:12:31 --> Utf8 Class Initialized
INFO - 2024-10-02 14:12:31 --> URI Class Initialized
INFO - 2024-10-02 14:12:31 --> Router Class Initialized
INFO - 2024-10-02 14:12:31 --> Output Class Initialized
INFO - 2024-10-02 14:12:31 --> Security Class Initialized
DEBUG - 2024-10-02 14:12:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-02 14:12:31 --> Input Class Initialized
INFO - 2024-10-02 14:12:31 --> Language Class Initialized
INFO - 2024-10-02 14:12:31 --> Language Class Initialized
INFO - 2024-10-02 14:12:31 --> Config Class Initialized
INFO - 2024-10-02 14:12:31 --> Loader Class Initialized
INFO - 2024-10-02 14:12:31 --> Helper loaded: url_helper
INFO - 2024-10-02 14:12:31 --> Helper loaded: file_helper
INFO - 2024-10-02 14:12:31 --> Helper loaded: form_helper
INFO - 2024-10-02 14:12:31 --> Helper loaded: my_helper
INFO - 2024-10-02 14:12:31 --> Database Driver Class Initialized
INFO - 2024-10-02 14:12:31 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-02 14:12:31 --> Controller Class Initialized
INFO - 2024-10-02 14:14:37 --> Config Class Initialized
INFO - 2024-10-02 14:14:37 --> Hooks Class Initialized
DEBUG - 2024-10-02 14:14:37 --> UTF-8 Support Enabled
INFO - 2024-10-02 14:14:37 --> Utf8 Class Initialized
INFO - 2024-10-02 14:14:37 --> URI Class Initialized
INFO - 2024-10-02 14:14:37 --> Router Class Initialized
INFO - 2024-10-02 14:14:37 --> Output Class Initialized
INFO - 2024-10-02 14:14:37 --> Security Class Initialized
DEBUG - 2024-10-02 14:14:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-02 14:14:37 --> Input Class Initialized
INFO - 2024-10-02 14:14:37 --> Language Class Initialized
INFO - 2024-10-02 14:14:37 --> Language Class Initialized
INFO - 2024-10-02 14:14:37 --> Config Class Initialized
INFO - 2024-10-02 14:14:37 --> Loader Class Initialized
INFO - 2024-10-02 14:14:37 --> Helper loaded: url_helper
INFO - 2024-10-02 14:14:37 --> Helper loaded: file_helper
INFO - 2024-10-02 14:14:37 --> Helper loaded: form_helper
INFO - 2024-10-02 14:14:37 --> Helper loaded: my_helper
INFO - 2024-10-02 14:14:37 --> Database Driver Class Initialized
INFO - 2024-10-02 14:14:37 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-02 14:14:37 --> Controller Class Initialized
DEBUG - 2024-10-02 14:14:37 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_catatan_guru/views/form.php
DEBUG - 2024-10-02 14:14:37 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-10-02 14:14:37 --> Final output sent to browser
DEBUG - 2024-10-02 14:14:37 --> Total execution time: 0.0340
INFO - 2024-10-02 14:14:45 --> Config Class Initialized
INFO - 2024-10-02 14:14:45 --> Hooks Class Initialized
DEBUG - 2024-10-02 14:14:45 --> UTF-8 Support Enabled
INFO - 2024-10-02 14:14:45 --> Utf8 Class Initialized
INFO - 2024-10-02 14:14:45 --> URI Class Initialized
INFO - 2024-10-02 14:14:45 --> Router Class Initialized
INFO - 2024-10-02 14:14:45 --> Output Class Initialized
INFO - 2024-10-02 14:14:45 --> Security Class Initialized
DEBUG - 2024-10-02 14:14:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-02 14:14:45 --> Input Class Initialized
INFO - 2024-10-02 14:14:45 --> Language Class Initialized
INFO - 2024-10-02 14:14:45 --> Language Class Initialized
INFO - 2024-10-02 14:14:45 --> Config Class Initialized
INFO - 2024-10-02 14:14:45 --> Loader Class Initialized
INFO - 2024-10-02 14:14:45 --> Helper loaded: url_helper
INFO - 2024-10-02 14:14:45 --> Helper loaded: file_helper
INFO - 2024-10-02 14:14:45 --> Helper loaded: form_helper
INFO - 2024-10-02 14:14:45 --> Helper loaded: my_helper
INFO - 2024-10-02 14:14:45 --> Database Driver Class Initialized
INFO - 2024-10-02 14:14:45 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-02 14:14:45 --> Controller Class Initialized
INFO - 2024-10-02 14:14:45 --> Config Class Initialized
INFO - 2024-10-02 14:14:45 --> Hooks Class Initialized
DEBUG - 2024-10-02 14:14:45 --> UTF-8 Support Enabled
INFO - 2024-10-02 14:14:45 --> Utf8 Class Initialized
INFO - 2024-10-02 14:14:45 --> URI Class Initialized
INFO - 2024-10-02 14:14:45 --> Router Class Initialized
INFO - 2024-10-02 14:14:45 --> Output Class Initialized
INFO - 2024-10-02 14:14:45 --> Security Class Initialized
DEBUG - 2024-10-02 14:14:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-02 14:14:45 --> Input Class Initialized
INFO - 2024-10-02 14:14:45 --> Language Class Initialized
INFO - 2024-10-02 14:14:45 --> Language Class Initialized
INFO - 2024-10-02 14:14:45 --> Config Class Initialized
INFO - 2024-10-02 14:14:45 --> Loader Class Initialized
INFO - 2024-10-02 14:14:45 --> Helper loaded: url_helper
INFO - 2024-10-02 14:14:45 --> Helper loaded: file_helper
INFO - 2024-10-02 14:14:45 --> Helper loaded: form_helper
INFO - 2024-10-02 14:14:45 --> Helper loaded: my_helper
INFO - 2024-10-02 14:14:45 --> Database Driver Class Initialized
INFO - 2024-10-02 14:14:45 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-02 14:14:45 --> Controller Class Initialized
DEBUG - 2024-10-02 14:14:45 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_catatan_guru/views/list.php
DEBUG - 2024-10-02 14:14:45 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-10-02 14:14:45 --> Final output sent to browser
DEBUG - 2024-10-02 14:14:45 --> Total execution time: 0.0443
INFO - 2024-10-02 14:14:50 --> Config Class Initialized
INFO - 2024-10-02 14:14:50 --> Hooks Class Initialized
DEBUG - 2024-10-02 14:14:50 --> UTF-8 Support Enabled
INFO - 2024-10-02 14:14:50 --> Utf8 Class Initialized
INFO - 2024-10-02 14:14:50 --> URI Class Initialized
INFO - 2024-10-02 14:14:50 --> Router Class Initialized
INFO - 2024-10-02 14:14:50 --> Output Class Initialized
INFO - 2024-10-02 14:14:50 --> Security Class Initialized
DEBUG - 2024-10-02 14:14:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-02 14:14:50 --> Input Class Initialized
INFO - 2024-10-02 14:14:50 --> Language Class Initialized
INFO - 2024-10-02 14:14:50 --> Language Class Initialized
INFO - 2024-10-02 14:14:50 --> Config Class Initialized
INFO - 2024-10-02 14:14:50 --> Loader Class Initialized
INFO - 2024-10-02 14:14:50 --> Helper loaded: url_helper
INFO - 2024-10-02 14:14:50 --> Helper loaded: file_helper
INFO - 2024-10-02 14:14:50 --> Helper loaded: form_helper
INFO - 2024-10-02 14:14:50 --> Helper loaded: my_helper
INFO - 2024-10-02 14:14:50 --> Database Driver Class Initialized
INFO - 2024-10-02 14:14:50 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-02 14:14:50 --> Controller Class Initialized
INFO - 2024-10-02 14:14:50 --> Final output sent to browser
DEBUG - 2024-10-02 14:14:50 --> Total execution time: 0.0308
INFO - 2024-10-02 14:15:56 --> Config Class Initialized
INFO - 2024-10-02 14:15:56 --> Hooks Class Initialized
DEBUG - 2024-10-02 14:15:56 --> UTF-8 Support Enabled
INFO - 2024-10-02 14:15:56 --> Utf8 Class Initialized
INFO - 2024-10-02 14:15:56 --> URI Class Initialized
INFO - 2024-10-02 14:15:56 --> Router Class Initialized
INFO - 2024-10-02 14:15:56 --> Output Class Initialized
INFO - 2024-10-02 14:15:56 --> Security Class Initialized
DEBUG - 2024-10-02 14:15:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-02 14:15:56 --> Input Class Initialized
INFO - 2024-10-02 14:15:56 --> Language Class Initialized
INFO - 2024-10-02 14:15:56 --> Language Class Initialized
INFO - 2024-10-02 14:15:56 --> Config Class Initialized
INFO - 2024-10-02 14:15:56 --> Loader Class Initialized
INFO - 2024-10-02 14:15:56 --> Helper loaded: url_helper
INFO - 2024-10-02 14:15:56 --> Helper loaded: file_helper
INFO - 2024-10-02 14:15:56 --> Helper loaded: form_helper
INFO - 2024-10-02 14:15:56 --> Helper loaded: my_helper
INFO - 2024-10-02 14:15:56 --> Database Driver Class Initialized
INFO - 2024-10-02 14:15:56 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-02 14:15:56 --> Controller Class Initialized
INFO - 2024-10-02 14:15:56 --> Final output sent to browser
DEBUG - 2024-10-02 14:15:56 --> Total execution time: 0.0374
INFO - 2024-10-02 14:16:04 --> Config Class Initialized
INFO - 2024-10-02 14:16:04 --> Hooks Class Initialized
DEBUG - 2024-10-02 14:16:04 --> UTF-8 Support Enabled
INFO - 2024-10-02 14:16:04 --> Utf8 Class Initialized
INFO - 2024-10-02 14:16:04 --> URI Class Initialized
INFO - 2024-10-02 14:16:04 --> Router Class Initialized
INFO - 2024-10-02 14:16:04 --> Output Class Initialized
INFO - 2024-10-02 14:16:04 --> Security Class Initialized
DEBUG - 2024-10-02 14:16:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-02 14:16:04 --> Input Class Initialized
INFO - 2024-10-02 14:16:04 --> Language Class Initialized
INFO - 2024-10-02 14:16:05 --> Language Class Initialized
INFO - 2024-10-02 14:16:05 --> Config Class Initialized
INFO - 2024-10-02 14:16:05 --> Loader Class Initialized
INFO - 2024-10-02 14:16:05 --> Helper loaded: url_helper
INFO - 2024-10-02 14:16:05 --> Helper loaded: file_helper
INFO - 2024-10-02 14:16:05 --> Helper loaded: form_helper
INFO - 2024-10-02 14:16:05 --> Helper loaded: my_helper
INFO - 2024-10-02 14:16:05 --> Database Driver Class Initialized
INFO - 2024-10-02 14:16:05 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-02 14:16:05 --> Controller Class Initialized
INFO - 2024-10-02 14:16:05 --> Final output sent to browser
DEBUG - 2024-10-02 14:16:05 --> Total execution time: 0.0737
INFO - 2024-10-02 14:16:20 --> Config Class Initialized
INFO - 2024-10-02 14:16:20 --> Hooks Class Initialized
DEBUG - 2024-10-02 14:16:20 --> UTF-8 Support Enabled
INFO - 2024-10-02 14:16:20 --> Utf8 Class Initialized
INFO - 2024-10-02 14:16:20 --> URI Class Initialized
INFO - 2024-10-02 14:16:20 --> Router Class Initialized
INFO - 2024-10-02 14:16:20 --> Output Class Initialized
INFO - 2024-10-02 14:16:20 --> Security Class Initialized
DEBUG - 2024-10-02 14:16:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-02 14:16:20 --> Input Class Initialized
INFO - 2024-10-02 14:16:20 --> Language Class Initialized
INFO - 2024-10-02 14:16:20 --> Language Class Initialized
INFO - 2024-10-02 14:16:20 --> Config Class Initialized
INFO - 2024-10-02 14:16:20 --> Loader Class Initialized
INFO - 2024-10-02 14:16:20 --> Helper loaded: url_helper
INFO - 2024-10-02 14:16:20 --> Helper loaded: file_helper
INFO - 2024-10-02 14:16:20 --> Helper loaded: form_helper
INFO - 2024-10-02 14:16:20 --> Helper loaded: my_helper
INFO - 2024-10-02 14:16:20 --> Database Driver Class Initialized
INFO - 2024-10-02 14:16:20 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-02 14:16:20 --> Controller Class Initialized
DEBUG - 2024-10-02 14:16:20 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/view_mapel/views/v_view_mapel.php
DEBUG - 2024-10-02 14:16:20 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-10-02 14:16:20 --> Final output sent to browser
DEBUG - 2024-10-02 14:16:20 --> Total execution time: 0.0321
INFO - 2024-10-02 14:16:26 --> Config Class Initialized
INFO - 2024-10-02 14:16:26 --> Hooks Class Initialized
DEBUG - 2024-10-02 14:16:26 --> UTF-8 Support Enabled
INFO - 2024-10-02 14:16:26 --> Utf8 Class Initialized
INFO - 2024-10-02 14:16:26 --> URI Class Initialized
INFO - 2024-10-02 14:16:26 --> Router Class Initialized
INFO - 2024-10-02 14:16:27 --> Output Class Initialized
INFO - 2024-10-02 14:16:27 --> Security Class Initialized
DEBUG - 2024-10-02 14:16:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-02 14:16:27 --> Input Class Initialized
INFO - 2024-10-02 14:16:27 --> Language Class Initialized
INFO - 2024-10-02 14:16:27 --> Language Class Initialized
INFO - 2024-10-02 14:16:27 --> Config Class Initialized
INFO - 2024-10-02 14:16:27 --> Loader Class Initialized
INFO - 2024-10-02 14:16:27 --> Helper loaded: url_helper
INFO - 2024-10-02 14:16:27 --> Helper loaded: file_helper
INFO - 2024-10-02 14:16:27 --> Helper loaded: form_helper
INFO - 2024-10-02 14:16:27 --> Helper loaded: my_helper
INFO - 2024-10-02 14:16:27 --> Database Driver Class Initialized
INFO - 2024-10-02 14:16:27 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-02 14:16:27 --> Controller Class Initialized
DEBUG - 2024-10-02 14:16:27 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pss/views/list.php
DEBUG - 2024-10-02 14:16:27 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-10-02 14:16:27 --> Final output sent to browser
DEBUG - 2024-10-02 14:16:27 --> Total execution time: 0.0722
INFO - 2024-10-02 14:16:27 --> Config Class Initialized
INFO - 2024-10-02 14:16:27 --> Hooks Class Initialized
DEBUG - 2024-10-02 14:16:27 --> UTF-8 Support Enabled
INFO - 2024-10-02 14:16:27 --> Utf8 Class Initialized
INFO - 2024-10-02 14:16:27 --> URI Class Initialized
INFO - 2024-10-02 14:16:27 --> Router Class Initialized
INFO - 2024-10-02 14:16:27 --> Output Class Initialized
INFO - 2024-10-02 14:16:27 --> Security Class Initialized
DEBUG - 2024-10-02 14:16:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-02 14:16:27 --> Input Class Initialized
INFO - 2024-10-02 14:16:27 --> Language Class Initialized
INFO - 2024-10-02 14:16:27 --> Language Class Initialized
INFO - 2024-10-02 14:16:27 --> Config Class Initialized
INFO - 2024-10-02 14:16:27 --> Loader Class Initialized
INFO - 2024-10-02 14:16:27 --> Helper loaded: url_helper
INFO - 2024-10-02 14:16:27 --> Helper loaded: file_helper
INFO - 2024-10-02 14:16:27 --> Helper loaded: form_helper
INFO - 2024-10-02 14:16:27 --> Helper loaded: my_helper
INFO - 2024-10-02 14:16:27 --> Database Driver Class Initialized
INFO - 2024-10-02 14:16:27 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-02 14:16:27 --> Controller Class Initialized
INFO - 2024-10-02 14:16:32 --> Config Class Initialized
INFO - 2024-10-02 14:16:32 --> Hooks Class Initialized
DEBUG - 2024-10-02 14:16:32 --> UTF-8 Support Enabled
INFO - 2024-10-02 14:16:32 --> Utf8 Class Initialized
INFO - 2024-10-02 14:16:32 --> URI Class Initialized
INFO - 2024-10-02 14:16:32 --> Router Class Initialized
INFO - 2024-10-02 14:16:32 --> Output Class Initialized
INFO - 2024-10-02 14:16:32 --> Security Class Initialized
DEBUG - 2024-10-02 14:16:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-02 14:16:32 --> Input Class Initialized
INFO - 2024-10-02 14:16:32 --> Language Class Initialized
INFO - 2024-10-02 14:16:32 --> Language Class Initialized
INFO - 2024-10-02 14:16:32 --> Config Class Initialized
INFO - 2024-10-02 14:16:32 --> Loader Class Initialized
INFO - 2024-10-02 14:16:32 --> Helper loaded: url_helper
INFO - 2024-10-02 14:16:32 --> Helper loaded: file_helper
INFO - 2024-10-02 14:16:32 --> Helper loaded: form_helper
INFO - 2024-10-02 14:16:32 --> Helper loaded: my_helper
INFO - 2024-10-02 14:16:32 --> Database Driver Class Initialized
INFO - 2024-10-02 14:16:32 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-02 14:16:32 --> Controller Class Initialized
INFO - 2024-10-02 14:16:32 --> Helper loaded: cookie_helper
INFO - 2024-10-02 14:16:33 --> Config Class Initialized
INFO - 2024-10-02 14:16:33 --> Hooks Class Initialized
DEBUG - 2024-10-02 14:16:33 --> UTF-8 Support Enabled
INFO - 2024-10-02 14:16:33 --> Utf8 Class Initialized
INFO - 2024-10-02 14:16:33 --> URI Class Initialized
INFO - 2024-10-02 14:16:33 --> Router Class Initialized
INFO - 2024-10-02 14:16:33 --> Output Class Initialized
INFO - 2024-10-02 14:16:33 --> Security Class Initialized
DEBUG - 2024-10-02 14:16:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-02 14:16:33 --> Input Class Initialized
INFO - 2024-10-02 14:16:33 --> Language Class Initialized
INFO - 2024-10-02 14:16:33 --> Language Class Initialized
INFO - 2024-10-02 14:16:33 --> Config Class Initialized
INFO - 2024-10-02 14:16:33 --> Loader Class Initialized
INFO - 2024-10-02 14:16:33 --> Helper loaded: url_helper
INFO - 2024-10-02 14:16:33 --> Helper loaded: file_helper
INFO - 2024-10-02 14:16:33 --> Helper loaded: form_helper
INFO - 2024-10-02 14:16:33 --> Helper loaded: my_helper
INFO - 2024-10-02 14:16:33 --> Database Driver Class Initialized
INFO - 2024-10-02 14:16:33 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-02 14:16:33 --> Controller Class Initialized
INFO - 2024-10-02 14:16:33 --> Config Class Initialized
INFO - 2024-10-02 14:16:33 --> Hooks Class Initialized
DEBUG - 2024-10-02 14:16:33 --> UTF-8 Support Enabled
INFO - 2024-10-02 14:16:33 --> Utf8 Class Initialized
INFO - 2024-10-02 14:16:33 --> URI Class Initialized
INFO - 2024-10-02 14:16:33 --> Router Class Initialized
INFO - 2024-10-02 14:16:33 --> Output Class Initialized
INFO - 2024-10-02 14:16:33 --> Security Class Initialized
DEBUG - 2024-10-02 14:16:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-02 14:16:33 --> Input Class Initialized
INFO - 2024-10-02 14:16:33 --> Language Class Initialized
INFO - 2024-10-02 14:16:33 --> Language Class Initialized
INFO - 2024-10-02 14:16:33 --> Config Class Initialized
INFO - 2024-10-02 14:16:33 --> Loader Class Initialized
INFO - 2024-10-02 14:16:33 --> Helper loaded: url_helper
INFO - 2024-10-02 14:16:33 --> Helper loaded: file_helper
INFO - 2024-10-02 14:16:33 --> Helper loaded: form_helper
INFO - 2024-10-02 14:16:33 --> Helper loaded: my_helper
INFO - 2024-10-02 14:16:33 --> Database Driver Class Initialized
INFO - 2024-10-02 14:16:33 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-02 14:16:33 --> Controller Class Initialized
DEBUG - 2024-10-02 14:16:33 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/login/views/login.php
DEBUG - 2024-10-02 14:16:33 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-10-02 14:16:33 --> Final output sent to browser
DEBUG - 2024-10-02 14:16:33 --> Total execution time: 0.0562
INFO - 2024-10-02 14:16:40 --> Config Class Initialized
INFO - 2024-10-02 14:16:40 --> Hooks Class Initialized
DEBUG - 2024-10-02 14:16:40 --> UTF-8 Support Enabled
INFO - 2024-10-02 14:16:40 --> Utf8 Class Initialized
INFO - 2024-10-02 14:16:40 --> URI Class Initialized
INFO - 2024-10-02 14:16:40 --> Router Class Initialized
INFO - 2024-10-02 14:16:40 --> Output Class Initialized
INFO - 2024-10-02 14:16:40 --> Security Class Initialized
DEBUG - 2024-10-02 14:16:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-02 14:16:40 --> Input Class Initialized
INFO - 2024-10-02 14:16:40 --> Language Class Initialized
INFO - 2024-10-02 14:16:40 --> Language Class Initialized
INFO - 2024-10-02 14:16:40 --> Config Class Initialized
INFO - 2024-10-02 14:16:40 --> Loader Class Initialized
INFO - 2024-10-02 14:16:40 --> Helper loaded: url_helper
INFO - 2024-10-02 14:16:40 --> Helper loaded: file_helper
INFO - 2024-10-02 14:16:40 --> Helper loaded: form_helper
INFO - 2024-10-02 14:16:40 --> Helper loaded: my_helper
INFO - 2024-10-02 14:16:40 --> Database Driver Class Initialized
INFO - 2024-10-02 14:16:40 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-02 14:16:40 --> Controller Class Initialized
INFO - 2024-10-02 14:16:40 --> Helper loaded: cookie_helper
INFO - 2024-10-02 14:16:40 --> Final output sent to browser
DEBUG - 2024-10-02 14:16:40 --> Total execution time: 0.0411
INFO - 2024-10-02 14:16:40 --> Config Class Initialized
INFO - 2024-10-02 14:16:40 --> Hooks Class Initialized
DEBUG - 2024-10-02 14:16:40 --> UTF-8 Support Enabled
INFO - 2024-10-02 14:16:40 --> Utf8 Class Initialized
INFO - 2024-10-02 14:16:40 --> URI Class Initialized
INFO - 2024-10-02 14:16:40 --> Router Class Initialized
INFO - 2024-10-02 14:16:40 --> Output Class Initialized
INFO - 2024-10-02 14:16:40 --> Security Class Initialized
DEBUG - 2024-10-02 14:16:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-02 14:16:40 --> Input Class Initialized
INFO - 2024-10-02 14:16:40 --> Language Class Initialized
INFO - 2024-10-02 14:16:40 --> Language Class Initialized
INFO - 2024-10-02 14:16:40 --> Config Class Initialized
INFO - 2024-10-02 14:16:40 --> Loader Class Initialized
INFO - 2024-10-02 14:16:40 --> Helper loaded: url_helper
INFO - 2024-10-02 14:16:40 --> Helper loaded: file_helper
INFO - 2024-10-02 14:16:40 --> Helper loaded: form_helper
INFO - 2024-10-02 14:16:40 --> Helper loaded: my_helper
INFO - 2024-10-02 14:16:40 --> Database Driver Class Initialized
INFO - 2024-10-02 14:16:40 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-02 14:16:40 --> Controller Class Initialized
DEBUG - 2024-10-02 14:16:40 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/home/views/v_home_guru.php
DEBUG - 2024-10-02 14:16:40 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-10-02 14:16:40 --> Final output sent to browser
DEBUG - 2024-10-02 14:16:40 --> Total execution time: 0.0542
INFO - 2024-10-02 14:16:48 --> Config Class Initialized
INFO - 2024-10-02 14:16:48 --> Hooks Class Initialized
DEBUG - 2024-10-02 14:16:48 --> UTF-8 Support Enabled
INFO - 2024-10-02 14:16:48 --> Utf8 Class Initialized
INFO - 2024-10-02 14:16:48 --> URI Class Initialized
INFO - 2024-10-02 14:16:48 --> Router Class Initialized
INFO - 2024-10-02 14:16:48 --> Output Class Initialized
INFO - 2024-10-02 14:16:48 --> Security Class Initialized
DEBUG - 2024-10-02 14:16:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-02 14:16:48 --> Input Class Initialized
INFO - 2024-10-02 14:16:48 --> Language Class Initialized
INFO - 2024-10-02 14:16:48 --> Language Class Initialized
INFO - 2024-10-02 14:16:48 --> Config Class Initialized
INFO - 2024-10-02 14:16:48 --> Loader Class Initialized
INFO - 2024-10-02 14:16:48 --> Helper loaded: url_helper
INFO - 2024-10-02 14:16:48 --> Helper loaded: file_helper
INFO - 2024-10-02 14:16:48 --> Helper loaded: form_helper
INFO - 2024-10-02 14:16:48 --> Helper loaded: my_helper
INFO - 2024-10-02 14:16:48 --> Database Driver Class Initialized
INFO - 2024-10-02 14:16:48 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-02 14:16:48 --> Controller Class Initialized
DEBUG - 2024-10-02 14:16:48 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/view_mapel/views/v_view_mapel.php
DEBUG - 2024-10-02 14:16:48 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-10-02 14:16:48 --> Final output sent to browser
DEBUG - 2024-10-02 14:16:48 --> Total execution time: 0.0303
INFO - 2024-10-02 14:16:54 --> Config Class Initialized
INFO - 2024-10-02 14:16:54 --> Hooks Class Initialized
DEBUG - 2024-10-02 14:16:54 --> UTF-8 Support Enabled
INFO - 2024-10-02 14:16:54 --> Utf8 Class Initialized
INFO - 2024-10-02 14:16:54 --> URI Class Initialized
INFO - 2024-10-02 14:16:54 --> Router Class Initialized
INFO - 2024-10-02 14:16:54 --> Output Class Initialized
INFO - 2024-10-02 14:16:54 --> Security Class Initialized
DEBUG - 2024-10-02 14:16:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-02 14:16:54 --> Input Class Initialized
INFO - 2024-10-02 14:16:54 --> Language Class Initialized
INFO - 2024-10-02 14:16:54 --> Language Class Initialized
INFO - 2024-10-02 14:16:54 --> Config Class Initialized
INFO - 2024-10-02 14:16:54 --> Loader Class Initialized
INFO - 2024-10-02 14:16:54 --> Helper loaded: url_helper
INFO - 2024-10-02 14:16:54 --> Helper loaded: file_helper
INFO - 2024-10-02 14:16:54 --> Helper loaded: form_helper
INFO - 2024-10-02 14:16:54 --> Helper loaded: my_helper
INFO - 2024-10-02 14:16:54 --> Database Driver Class Initialized
INFO - 2024-10-02 14:16:54 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-02 14:16:54 --> Controller Class Initialized
DEBUG - 2024-10-02 14:16:54 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_icb/views/list.php
DEBUG - 2024-10-02 14:16:54 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-10-02 14:16:54 --> Final output sent to browser
DEBUG - 2024-10-02 14:16:54 --> Total execution time: 0.0718
INFO - 2024-10-02 14:16:54 --> Config Class Initialized
INFO - 2024-10-02 14:16:54 --> Hooks Class Initialized
DEBUG - 2024-10-02 14:16:54 --> UTF-8 Support Enabled
INFO - 2024-10-02 14:16:54 --> Utf8 Class Initialized
INFO - 2024-10-02 14:16:54 --> URI Class Initialized
INFO - 2024-10-02 14:16:54 --> Router Class Initialized
INFO - 2024-10-02 14:16:54 --> Output Class Initialized
INFO - 2024-10-02 14:16:54 --> Security Class Initialized
DEBUG - 2024-10-02 14:16:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-02 14:16:54 --> Input Class Initialized
INFO - 2024-10-02 14:16:54 --> Language Class Initialized
INFO - 2024-10-02 14:16:54 --> Language Class Initialized
INFO - 2024-10-02 14:16:54 --> Config Class Initialized
INFO - 2024-10-02 14:16:54 --> Loader Class Initialized
INFO - 2024-10-02 14:16:54 --> Helper loaded: url_helper
INFO - 2024-10-02 14:16:54 --> Helper loaded: file_helper
INFO - 2024-10-02 14:16:54 --> Helper loaded: form_helper
INFO - 2024-10-02 14:16:54 --> Helper loaded: my_helper
INFO - 2024-10-02 14:16:54 --> Database Driver Class Initialized
INFO - 2024-10-02 14:16:54 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-02 14:16:54 --> Controller Class Initialized
INFO - 2024-10-02 14:17:10 --> Config Class Initialized
INFO - 2024-10-02 14:17:10 --> Hooks Class Initialized
DEBUG - 2024-10-02 14:17:10 --> UTF-8 Support Enabled
INFO - 2024-10-02 14:17:10 --> Utf8 Class Initialized
INFO - 2024-10-02 14:17:10 --> URI Class Initialized
INFO - 2024-10-02 14:17:10 --> Router Class Initialized
INFO - 2024-10-02 14:17:10 --> Output Class Initialized
INFO - 2024-10-02 14:17:10 --> Security Class Initialized
DEBUG - 2024-10-02 14:17:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-02 14:17:10 --> Input Class Initialized
INFO - 2024-10-02 14:17:10 --> Language Class Initialized
INFO - 2024-10-02 14:17:10 --> Language Class Initialized
INFO - 2024-10-02 14:17:10 --> Config Class Initialized
INFO - 2024-10-02 14:17:10 --> Loader Class Initialized
INFO - 2024-10-02 14:17:10 --> Helper loaded: url_helper
INFO - 2024-10-02 14:17:10 --> Helper loaded: file_helper
INFO - 2024-10-02 14:17:10 --> Helper loaded: form_helper
INFO - 2024-10-02 14:17:10 --> Helper loaded: my_helper
INFO - 2024-10-02 14:17:10 --> Database Driver Class Initialized
INFO - 2024-10-02 14:17:10 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-02 14:17:10 --> Controller Class Initialized
INFO - 2024-10-02 14:17:10 --> Final output sent to browser
DEBUG - 2024-10-02 14:17:10 --> Total execution time: 0.0318
INFO - 2024-10-02 14:17:43 --> Config Class Initialized
INFO - 2024-10-02 14:17:43 --> Hooks Class Initialized
DEBUG - 2024-10-02 14:17:43 --> UTF-8 Support Enabled
INFO - 2024-10-02 14:17:43 --> Utf8 Class Initialized
INFO - 2024-10-02 14:17:43 --> URI Class Initialized
INFO - 2024-10-02 14:17:43 --> Router Class Initialized
INFO - 2024-10-02 14:17:43 --> Output Class Initialized
INFO - 2024-10-02 14:17:43 --> Security Class Initialized
DEBUG - 2024-10-02 14:17:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-02 14:17:43 --> Input Class Initialized
INFO - 2024-10-02 14:17:43 --> Language Class Initialized
INFO - 2024-10-02 14:17:43 --> Language Class Initialized
INFO - 2024-10-02 14:17:43 --> Config Class Initialized
INFO - 2024-10-02 14:17:43 --> Loader Class Initialized
INFO - 2024-10-02 14:17:43 --> Helper loaded: url_helper
INFO - 2024-10-02 14:17:43 --> Helper loaded: file_helper
INFO - 2024-10-02 14:17:43 --> Helper loaded: form_helper
INFO - 2024-10-02 14:17:43 --> Helper loaded: my_helper
INFO - 2024-10-02 14:17:43 --> Database Driver Class Initialized
INFO - 2024-10-02 14:17:43 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-02 14:17:43 --> Controller Class Initialized
ERROR - 2024-10-02 14:17:43 --> Severity: Notice --> Undefined index: semester /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/set_kd/controllers/Set_kd.php 104
INFO - 2024-10-02 14:17:43 --> Final output sent to browser
DEBUG - 2024-10-02 14:17:43 --> Total execution time: 0.0322
INFO - 2024-10-02 14:17:49 --> Config Class Initialized
INFO - 2024-10-02 14:17:49 --> Hooks Class Initialized
DEBUG - 2024-10-02 14:17:49 --> UTF-8 Support Enabled
INFO - 2024-10-02 14:17:49 --> Utf8 Class Initialized
INFO - 2024-10-02 14:17:49 --> URI Class Initialized
INFO - 2024-10-02 14:17:49 --> Router Class Initialized
INFO - 2024-10-02 14:17:49 --> Output Class Initialized
INFO - 2024-10-02 14:17:49 --> Security Class Initialized
DEBUG - 2024-10-02 14:17:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-02 14:17:49 --> Input Class Initialized
INFO - 2024-10-02 14:17:49 --> Language Class Initialized
INFO - 2024-10-02 14:17:49 --> Language Class Initialized
INFO - 2024-10-02 14:17:49 --> Config Class Initialized
INFO - 2024-10-02 14:17:49 --> Loader Class Initialized
INFO - 2024-10-02 14:17:49 --> Helper loaded: url_helper
INFO - 2024-10-02 14:17:49 --> Helper loaded: file_helper
INFO - 2024-10-02 14:17:49 --> Helper loaded: form_helper
INFO - 2024-10-02 14:17:49 --> Helper loaded: my_helper
INFO - 2024-10-02 14:17:49 --> Database Driver Class Initialized
INFO - 2024-10-02 14:17:49 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-02 14:17:49 --> Controller Class Initialized
DEBUG - 2024-10-02 14:17:49 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_icb/views/list.php
DEBUG - 2024-10-02 14:17:49 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-10-02 14:17:49 --> Final output sent to browser
DEBUG - 2024-10-02 14:17:49 --> Total execution time: 0.0683
INFO - 2024-10-02 14:17:49 --> Config Class Initialized
INFO - 2024-10-02 14:17:49 --> Hooks Class Initialized
DEBUG - 2024-10-02 14:17:49 --> UTF-8 Support Enabled
INFO - 2024-10-02 14:17:49 --> Utf8 Class Initialized
INFO - 2024-10-02 14:17:49 --> URI Class Initialized
INFO - 2024-10-02 14:17:49 --> Router Class Initialized
INFO - 2024-10-02 14:17:49 --> Output Class Initialized
INFO - 2024-10-02 14:17:49 --> Security Class Initialized
DEBUG - 2024-10-02 14:17:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-02 14:17:49 --> Input Class Initialized
INFO - 2024-10-02 14:17:49 --> Language Class Initialized
INFO - 2024-10-02 14:17:49 --> Language Class Initialized
INFO - 2024-10-02 14:17:49 --> Config Class Initialized
INFO - 2024-10-02 14:17:49 --> Loader Class Initialized
INFO - 2024-10-02 14:17:49 --> Helper loaded: url_helper
INFO - 2024-10-02 14:17:49 --> Helper loaded: file_helper
INFO - 2024-10-02 14:17:49 --> Helper loaded: form_helper
INFO - 2024-10-02 14:17:49 --> Helper loaded: my_helper
INFO - 2024-10-02 14:17:49 --> Database Driver Class Initialized
INFO - 2024-10-02 14:17:49 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-02 14:17:49 --> Controller Class Initialized
INFO - 2024-10-02 14:17:51 --> Config Class Initialized
INFO - 2024-10-02 14:17:51 --> Hooks Class Initialized
DEBUG - 2024-10-02 14:17:51 --> UTF-8 Support Enabled
INFO - 2024-10-02 14:17:51 --> Utf8 Class Initialized
INFO - 2024-10-02 14:17:51 --> URI Class Initialized
INFO - 2024-10-02 14:17:51 --> Router Class Initialized
INFO - 2024-10-02 14:17:51 --> Output Class Initialized
INFO - 2024-10-02 14:17:51 --> Security Class Initialized
DEBUG - 2024-10-02 14:17:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-02 14:17:51 --> Input Class Initialized
INFO - 2024-10-02 14:17:51 --> Language Class Initialized
INFO - 2024-10-02 14:17:51 --> Language Class Initialized
INFO - 2024-10-02 14:17:51 --> Config Class Initialized
INFO - 2024-10-02 14:17:51 --> Loader Class Initialized
INFO - 2024-10-02 14:17:51 --> Helper loaded: url_helper
INFO - 2024-10-02 14:17:51 --> Helper loaded: file_helper
INFO - 2024-10-02 14:17:51 --> Helper loaded: form_helper
INFO - 2024-10-02 14:17:51 --> Helper loaded: my_helper
INFO - 2024-10-02 14:17:51 --> Database Driver Class Initialized
INFO - 2024-10-02 14:17:51 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-02 14:17:51 --> Controller Class Initialized
INFO - 2024-10-02 14:17:51 --> Final output sent to browser
DEBUG - 2024-10-02 14:17:51 --> Total execution time: 0.0639
INFO - 2024-10-02 14:18:04 --> Config Class Initialized
INFO - 2024-10-02 14:18:04 --> Hooks Class Initialized
DEBUG - 2024-10-02 14:18:04 --> UTF-8 Support Enabled
INFO - 2024-10-02 14:18:04 --> Utf8 Class Initialized
INFO - 2024-10-02 14:18:04 --> URI Class Initialized
INFO - 2024-10-02 14:18:04 --> Router Class Initialized
INFO - 2024-10-02 14:18:04 --> Output Class Initialized
INFO - 2024-10-02 14:18:04 --> Security Class Initialized
DEBUG - 2024-10-02 14:18:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-02 14:18:04 --> Input Class Initialized
INFO - 2024-10-02 14:18:04 --> Language Class Initialized
INFO - 2024-10-02 14:18:04 --> Language Class Initialized
INFO - 2024-10-02 14:18:04 --> Config Class Initialized
INFO - 2024-10-02 14:18:04 --> Loader Class Initialized
INFO - 2024-10-02 14:18:04 --> Helper loaded: url_helper
INFO - 2024-10-02 14:18:04 --> Helper loaded: file_helper
INFO - 2024-10-02 14:18:04 --> Helper loaded: form_helper
INFO - 2024-10-02 14:18:04 --> Helper loaded: my_helper
INFO - 2024-10-02 14:18:04 --> Database Driver Class Initialized
INFO - 2024-10-02 14:18:04 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-02 14:18:04 --> Controller Class Initialized
INFO - 2024-10-02 14:18:05 --> Final output sent to browser
DEBUG - 2024-10-02 14:18:05 --> Total execution time: 0.4906
INFO - 2024-10-02 14:18:10 --> Config Class Initialized
INFO - 2024-10-02 14:18:10 --> Hooks Class Initialized
DEBUG - 2024-10-02 14:18:10 --> UTF-8 Support Enabled
INFO - 2024-10-02 14:18:10 --> Utf8 Class Initialized
INFO - 2024-10-02 14:18:10 --> URI Class Initialized
INFO - 2024-10-02 14:18:10 --> Router Class Initialized
INFO - 2024-10-02 14:18:10 --> Output Class Initialized
INFO - 2024-10-02 14:18:10 --> Security Class Initialized
DEBUG - 2024-10-02 14:18:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-02 14:18:10 --> Input Class Initialized
INFO - 2024-10-02 14:18:10 --> Language Class Initialized
INFO - 2024-10-02 14:18:10 --> Language Class Initialized
INFO - 2024-10-02 14:18:10 --> Config Class Initialized
INFO - 2024-10-02 14:18:10 --> Loader Class Initialized
INFO - 2024-10-02 14:18:10 --> Helper loaded: url_helper
INFO - 2024-10-02 14:18:10 --> Helper loaded: file_helper
INFO - 2024-10-02 14:18:10 --> Helper loaded: form_helper
INFO - 2024-10-02 14:18:10 --> Helper loaded: my_helper
INFO - 2024-10-02 14:18:10 --> Database Driver Class Initialized
INFO - 2024-10-02 14:18:10 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-02 14:18:10 --> Controller Class Initialized
ERROR - 2024-10-02 14:18:10 --> Severity: Notice --> Undefined index: semester /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/set_kd/controllers/Set_kd.php 104
INFO - 2024-10-02 14:18:10 --> Final output sent to browser
DEBUG - 2024-10-02 14:18:10 --> Total execution time: 0.1381
INFO - 2024-10-02 14:18:12 --> Config Class Initialized
INFO - 2024-10-02 14:18:12 --> Hooks Class Initialized
DEBUG - 2024-10-02 14:18:12 --> UTF-8 Support Enabled
INFO - 2024-10-02 14:18:12 --> Utf8 Class Initialized
INFO - 2024-10-02 14:18:12 --> URI Class Initialized
INFO - 2024-10-02 14:18:12 --> Router Class Initialized
INFO - 2024-10-02 14:18:12 --> Output Class Initialized
INFO - 2024-10-02 14:18:12 --> Security Class Initialized
DEBUG - 2024-10-02 14:18:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-02 14:18:12 --> Input Class Initialized
INFO - 2024-10-02 14:18:12 --> Language Class Initialized
INFO - 2024-10-02 14:18:12 --> Language Class Initialized
INFO - 2024-10-02 14:18:12 --> Config Class Initialized
INFO - 2024-10-02 14:18:12 --> Loader Class Initialized
INFO - 2024-10-02 14:18:12 --> Helper loaded: url_helper
INFO - 2024-10-02 14:18:12 --> Helper loaded: file_helper
INFO - 2024-10-02 14:18:12 --> Helper loaded: form_helper
INFO - 2024-10-02 14:18:12 --> Helper loaded: my_helper
INFO - 2024-10-02 14:18:12 --> Database Driver Class Initialized
INFO - 2024-10-02 14:18:12 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-02 14:18:12 --> Controller Class Initialized
DEBUG - 2024-10-02 14:18:12 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_icb/views/list.php
DEBUG - 2024-10-02 14:18:12 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-10-02 14:18:12 --> Final output sent to browser
DEBUG - 2024-10-02 14:18:12 --> Total execution time: 0.0714
INFO - 2024-10-02 14:18:12 --> Config Class Initialized
INFO - 2024-10-02 14:18:12 --> Hooks Class Initialized
DEBUG - 2024-10-02 14:18:12 --> UTF-8 Support Enabled
INFO - 2024-10-02 14:18:12 --> Utf8 Class Initialized
INFO - 2024-10-02 14:18:12 --> URI Class Initialized
INFO - 2024-10-02 14:18:12 --> Router Class Initialized
INFO - 2024-10-02 14:18:12 --> Output Class Initialized
INFO - 2024-10-02 14:18:12 --> Security Class Initialized
DEBUG - 2024-10-02 14:18:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-02 14:18:12 --> Input Class Initialized
INFO - 2024-10-02 14:18:12 --> Language Class Initialized
INFO - 2024-10-02 14:18:12 --> Language Class Initialized
INFO - 2024-10-02 14:18:12 --> Config Class Initialized
INFO - 2024-10-02 14:18:12 --> Loader Class Initialized
INFO - 2024-10-02 14:18:12 --> Helper loaded: url_helper
INFO - 2024-10-02 14:18:12 --> Helper loaded: file_helper
INFO - 2024-10-02 14:18:12 --> Helper loaded: form_helper
INFO - 2024-10-02 14:18:12 --> Helper loaded: my_helper
INFO - 2024-10-02 14:18:12 --> Database Driver Class Initialized
INFO - 2024-10-02 14:18:12 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-02 14:18:12 --> Controller Class Initialized
INFO - 2024-10-02 14:18:16 --> Config Class Initialized
INFO - 2024-10-02 14:18:16 --> Hooks Class Initialized
DEBUG - 2024-10-02 14:18:16 --> UTF-8 Support Enabled
INFO - 2024-10-02 14:18:16 --> Utf8 Class Initialized
INFO - 2024-10-02 14:18:16 --> URI Class Initialized
INFO - 2024-10-02 14:18:16 --> Router Class Initialized
INFO - 2024-10-02 14:18:16 --> Output Class Initialized
INFO - 2024-10-02 14:18:16 --> Security Class Initialized
DEBUG - 2024-10-02 14:18:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-02 14:18:16 --> Input Class Initialized
INFO - 2024-10-02 14:18:16 --> Language Class Initialized
INFO - 2024-10-02 14:18:16 --> Language Class Initialized
INFO - 2024-10-02 14:18:16 --> Config Class Initialized
INFO - 2024-10-02 14:18:16 --> Loader Class Initialized
INFO - 2024-10-02 14:18:16 --> Helper loaded: url_helper
INFO - 2024-10-02 14:18:16 --> Helper loaded: file_helper
INFO - 2024-10-02 14:18:16 --> Helper loaded: form_helper
INFO - 2024-10-02 14:18:16 --> Helper loaded: my_helper
INFO - 2024-10-02 14:18:16 --> Database Driver Class Initialized
INFO - 2024-10-02 14:18:16 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-02 14:18:16 --> Controller Class Initialized
INFO - 2024-10-02 14:18:16 --> Final output sent to browser
DEBUG - 2024-10-02 14:18:16 --> Total execution time: 0.0661
INFO - 2024-10-02 14:18:29 --> Config Class Initialized
INFO - 2024-10-02 14:18:29 --> Hooks Class Initialized
DEBUG - 2024-10-02 14:18:29 --> UTF-8 Support Enabled
INFO - 2024-10-02 14:18:29 --> Utf8 Class Initialized
INFO - 2024-10-02 14:18:29 --> URI Class Initialized
INFO - 2024-10-02 14:18:29 --> Router Class Initialized
INFO - 2024-10-02 14:18:29 --> Output Class Initialized
INFO - 2024-10-02 14:18:29 --> Security Class Initialized
DEBUG - 2024-10-02 14:18:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-02 14:18:29 --> Input Class Initialized
INFO - 2024-10-02 14:18:29 --> Language Class Initialized
INFO - 2024-10-02 14:18:29 --> Language Class Initialized
INFO - 2024-10-02 14:18:29 --> Config Class Initialized
INFO - 2024-10-02 14:18:29 --> Loader Class Initialized
INFO - 2024-10-02 14:18:29 --> Helper loaded: url_helper
INFO - 2024-10-02 14:18:29 --> Helper loaded: file_helper
INFO - 2024-10-02 14:18:29 --> Helper loaded: form_helper
INFO - 2024-10-02 14:18:29 --> Helper loaded: my_helper
INFO - 2024-10-02 14:18:29 --> Database Driver Class Initialized
INFO - 2024-10-02 14:18:29 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-02 14:18:29 --> Controller Class Initialized
ERROR - 2024-10-02 14:18:29 --> Severity: Notice --> Undefined index: semester /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/set_kd/controllers/Set_kd.php 104
INFO - 2024-10-02 14:18:29 --> Final output sent to browser
DEBUG - 2024-10-02 14:18:29 --> Total execution time: 0.0633
INFO - 2024-10-02 14:18:31 --> Config Class Initialized
INFO - 2024-10-02 14:18:31 --> Hooks Class Initialized
DEBUG - 2024-10-02 14:18:31 --> UTF-8 Support Enabled
INFO - 2024-10-02 14:18:31 --> Utf8 Class Initialized
INFO - 2024-10-02 14:18:31 --> URI Class Initialized
INFO - 2024-10-02 14:18:31 --> Router Class Initialized
INFO - 2024-10-02 14:18:31 --> Output Class Initialized
INFO - 2024-10-02 14:18:31 --> Security Class Initialized
DEBUG - 2024-10-02 14:18:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-02 14:18:31 --> Input Class Initialized
INFO - 2024-10-02 14:18:31 --> Language Class Initialized
INFO - 2024-10-02 14:18:31 --> Language Class Initialized
INFO - 2024-10-02 14:18:31 --> Config Class Initialized
INFO - 2024-10-02 14:18:31 --> Loader Class Initialized
INFO - 2024-10-02 14:18:31 --> Helper loaded: url_helper
INFO - 2024-10-02 14:18:31 --> Helper loaded: file_helper
INFO - 2024-10-02 14:18:31 --> Helper loaded: form_helper
INFO - 2024-10-02 14:18:31 --> Helper loaded: my_helper
INFO - 2024-10-02 14:18:31 --> Database Driver Class Initialized
INFO - 2024-10-02 14:18:31 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-02 14:18:31 --> Controller Class Initialized
DEBUG - 2024-10-02 14:18:31 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_icb/views/list.php
DEBUG - 2024-10-02 14:18:31 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-10-02 14:18:31 --> Final output sent to browser
DEBUG - 2024-10-02 14:18:31 --> Total execution time: 0.0359
INFO - 2024-10-02 14:18:31 --> Config Class Initialized
INFO - 2024-10-02 14:18:31 --> Hooks Class Initialized
DEBUG - 2024-10-02 14:18:31 --> UTF-8 Support Enabled
INFO - 2024-10-02 14:18:31 --> Utf8 Class Initialized
INFO - 2024-10-02 14:18:31 --> URI Class Initialized
INFO - 2024-10-02 14:18:31 --> Router Class Initialized
INFO - 2024-10-02 14:18:31 --> Output Class Initialized
INFO - 2024-10-02 14:18:31 --> Security Class Initialized
DEBUG - 2024-10-02 14:18:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-02 14:18:31 --> Input Class Initialized
INFO - 2024-10-02 14:18:31 --> Language Class Initialized
INFO - 2024-10-02 14:18:31 --> Language Class Initialized
INFO - 2024-10-02 14:18:31 --> Config Class Initialized
INFO - 2024-10-02 14:18:31 --> Loader Class Initialized
INFO - 2024-10-02 14:18:31 --> Helper loaded: url_helper
INFO - 2024-10-02 14:18:31 --> Helper loaded: file_helper
INFO - 2024-10-02 14:18:31 --> Helper loaded: form_helper
INFO - 2024-10-02 14:18:31 --> Helper loaded: my_helper
INFO - 2024-10-02 14:18:31 --> Database Driver Class Initialized
INFO - 2024-10-02 14:18:31 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-02 14:18:31 --> Controller Class Initialized
INFO - 2024-10-02 14:18:35 --> Config Class Initialized
INFO - 2024-10-02 14:18:35 --> Hooks Class Initialized
DEBUG - 2024-10-02 14:18:35 --> UTF-8 Support Enabled
INFO - 2024-10-02 14:18:35 --> Utf8 Class Initialized
INFO - 2024-10-02 14:18:35 --> URI Class Initialized
INFO - 2024-10-02 14:18:35 --> Router Class Initialized
INFO - 2024-10-02 14:18:35 --> Output Class Initialized
INFO - 2024-10-02 14:18:35 --> Security Class Initialized
DEBUG - 2024-10-02 14:18:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-02 14:18:35 --> Input Class Initialized
INFO - 2024-10-02 14:18:35 --> Language Class Initialized
INFO - 2024-10-02 14:18:35 --> Language Class Initialized
INFO - 2024-10-02 14:18:35 --> Config Class Initialized
INFO - 2024-10-02 14:18:35 --> Loader Class Initialized
INFO - 2024-10-02 14:18:35 --> Helper loaded: url_helper
INFO - 2024-10-02 14:18:35 --> Helper loaded: file_helper
INFO - 2024-10-02 14:18:35 --> Helper loaded: form_helper
INFO - 2024-10-02 14:18:35 --> Helper loaded: my_helper
INFO - 2024-10-02 14:18:35 --> Database Driver Class Initialized
INFO - 2024-10-02 14:18:35 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-02 14:18:35 --> Controller Class Initialized
INFO - 2024-10-02 14:18:35 --> Final output sent to browser
DEBUG - 2024-10-02 14:18:35 --> Total execution time: 0.0426
INFO - 2024-10-02 14:18:49 --> Config Class Initialized
INFO - 2024-10-02 14:18:49 --> Hooks Class Initialized
DEBUG - 2024-10-02 14:18:49 --> UTF-8 Support Enabled
INFO - 2024-10-02 14:18:49 --> Utf8 Class Initialized
INFO - 2024-10-02 14:18:49 --> URI Class Initialized
INFO - 2024-10-02 14:18:49 --> Router Class Initialized
INFO - 2024-10-02 14:18:49 --> Output Class Initialized
INFO - 2024-10-02 14:18:49 --> Security Class Initialized
DEBUG - 2024-10-02 14:18:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-02 14:18:49 --> Input Class Initialized
INFO - 2024-10-02 14:18:49 --> Language Class Initialized
INFO - 2024-10-02 14:18:49 --> Language Class Initialized
INFO - 2024-10-02 14:18:49 --> Config Class Initialized
INFO - 2024-10-02 14:18:49 --> Loader Class Initialized
INFO - 2024-10-02 14:18:49 --> Helper loaded: url_helper
INFO - 2024-10-02 14:18:49 --> Helper loaded: file_helper
INFO - 2024-10-02 14:18:49 --> Helper loaded: form_helper
INFO - 2024-10-02 14:18:49 --> Helper loaded: my_helper
INFO - 2024-10-02 14:18:49 --> Database Driver Class Initialized
INFO - 2024-10-02 14:18:49 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-02 14:18:49 --> Controller Class Initialized
ERROR - 2024-10-02 14:18:49 --> Severity: Notice --> Undefined index: semester /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/set_kd/controllers/Set_kd.php 104
INFO - 2024-10-02 14:18:49 --> Final output sent to browser
DEBUG - 2024-10-02 14:18:49 --> Total execution time: 0.0369
INFO - 2024-10-02 14:18:51 --> Config Class Initialized
INFO - 2024-10-02 14:18:51 --> Hooks Class Initialized
DEBUG - 2024-10-02 14:18:51 --> UTF-8 Support Enabled
INFO - 2024-10-02 14:18:51 --> Utf8 Class Initialized
INFO - 2024-10-02 14:18:51 --> URI Class Initialized
INFO - 2024-10-02 14:18:51 --> Router Class Initialized
INFO - 2024-10-02 14:18:51 --> Output Class Initialized
INFO - 2024-10-02 14:18:51 --> Security Class Initialized
DEBUG - 2024-10-02 14:18:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-02 14:18:51 --> Input Class Initialized
INFO - 2024-10-02 14:18:51 --> Language Class Initialized
INFO - 2024-10-02 14:18:51 --> Language Class Initialized
INFO - 2024-10-02 14:18:51 --> Config Class Initialized
INFO - 2024-10-02 14:18:51 --> Loader Class Initialized
INFO - 2024-10-02 14:18:51 --> Helper loaded: url_helper
INFO - 2024-10-02 14:18:51 --> Helper loaded: file_helper
INFO - 2024-10-02 14:18:51 --> Helper loaded: form_helper
INFO - 2024-10-02 14:18:51 --> Helper loaded: my_helper
INFO - 2024-10-02 14:18:51 --> Database Driver Class Initialized
INFO - 2024-10-02 14:18:51 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-02 14:18:51 --> Controller Class Initialized
DEBUG - 2024-10-02 14:18:51 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_icb/views/list.php
DEBUG - 2024-10-02 14:18:51 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-10-02 14:18:51 --> Final output sent to browser
DEBUG - 2024-10-02 14:18:51 --> Total execution time: 0.0400
INFO - 2024-10-02 14:18:51 --> Config Class Initialized
INFO - 2024-10-02 14:18:51 --> Hooks Class Initialized
DEBUG - 2024-10-02 14:18:51 --> UTF-8 Support Enabled
INFO - 2024-10-02 14:18:51 --> Utf8 Class Initialized
INFO - 2024-10-02 14:18:51 --> URI Class Initialized
INFO - 2024-10-02 14:18:51 --> Router Class Initialized
INFO - 2024-10-02 14:18:51 --> Output Class Initialized
INFO - 2024-10-02 14:18:51 --> Security Class Initialized
DEBUG - 2024-10-02 14:18:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-02 14:18:51 --> Input Class Initialized
INFO - 2024-10-02 14:18:51 --> Language Class Initialized
INFO - 2024-10-02 14:18:51 --> Language Class Initialized
INFO - 2024-10-02 14:18:51 --> Config Class Initialized
INFO - 2024-10-02 14:18:51 --> Loader Class Initialized
INFO - 2024-10-02 14:18:51 --> Helper loaded: url_helper
INFO - 2024-10-02 14:18:51 --> Helper loaded: file_helper
INFO - 2024-10-02 14:18:51 --> Helper loaded: form_helper
INFO - 2024-10-02 14:18:51 --> Helper loaded: my_helper
INFO - 2024-10-02 14:18:51 --> Database Driver Class Initialized
INFO - 2024-10-02 14:18:51 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-02 14:18:51 --> Controller Class Initialized
INFO - 2024-10-02 14:18:53 --> Config Class Initialized
INFO - 2024-10-02 14:18:53 --> Hooks Class Initialized
DEBUG - 2024-10-02 14:18:53 --> UTF-8 Support Enabled
INFO - 2024-10-02 14:18:53 --> Utf8 Class Initialized
INFO - 2024-10-02 14:18:53 --> URI Class Initialized
INFO - 2024-10-02 14:18:53 --> Router Class Initialized
INFO - 2024-10-02 14:18:53 --> Output Class Initialized
INFO - 2024-10-02 14:18:53 --> Security Class Initialized
DEBUG - 2024-10-02 14:18:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-02 14:18:53 --> Input Class Initialized
INFO - 2024-10-02 14:18:53 --> Language Class Initialized
INFO - 2024-10-02 14:18:53 --> Language Class Initialized
INFO - 2024-10-02 14:18:53 --> Config Class Initialized
INFO - 2024-10-02 14:18:53 --> Loader Class Initialized
INFO - 2024-10-02 14:18:53 --> Helper loaded: url_helper
INFO - 2024-10-02 14:18:53 --> Helper loaded: file_helper
INFO - 2024-10-02 14:18:53 --> Helper loaded: form_helper
INFO - 2024-10-02 14:18:53 --> Helper loaded: my_helper
INFO - 2024-10-02 14:18:53 --> Database Driver Class Initialized
INFO - 2024-10-02 14:18:53 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-02 14:18:53 --> Controller Class Initialized
INFO - 2024-10-02 14:18:53 --> Final output sent to browser
DEBUG - 2024-10-02 14:18:53 --> Total execution time: 0.0461
INFO - 2024-10-02 14:18:58 --> Config Class Initialized
INFO - 2024-10-02 14:18:58 --> Hooks Class Initialized
DEBUG - 2024-10-02 14:18:58 --> UTF-8 Support Enabled
INFO - 2024-10-02 14:18:58 --> Utf8 Class Initialized
INFO - 2024-10-02 14:18:58 --> URI Class Initialized
INFO - 2024-10-02 14:18:58 --> Router Class Initialized
INFO - 2024-10-02 14:18:58 --> Output Class Initialized
INFO - 2024-10-02 14:18:58 --> Security Class Initialized
DEBUG - 2024-10-02 14:18:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-02 14:18:58 --> Input Class Initialized
INFO - 2024-10-02 14:18:58 --> Language Class Initialized
INFO - 2024-10-02 14:18:58 --> Language Class Initialized
INFO - 2024-10-02 14:18:58 --> Config Class Initialized
INFO - 2024-10-02 14:18:58 --> Loader Class Initialized
INFO - 2024-10-02 14:18:58 --> Helper loaded: url_helper
INFO - 2024-10-02 14:18:58 --> Helper loaded: file_helper
INFO - 2024-10-02 14:18:58 --> Helper loaded: form_helper
INFO - 2024-10-02 14:18:58 --> Helper loaded: my_helper
INFO - 2024-10-02 14:18:58 --> Database Driver Class Initialized
INFO - 2024-10-02 14:18:58 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-02 14:18:58 --> Controller Class Initialized
INFO - 2024-10-02 14:18:58 --> Final output sent to browser
DEBUG - 2024-10-02 14:18:58 --> Total execution time: 0.0627
INFO - 2024-10-02 14:19:10 --> Config Class Initialized
INFO - 2024-10-02 14:19:10 --> Hooks Class Initialized
DEBUG - 2024-10-02 14:19:10 --> UTF-8 Support Enabled
INFO - 2024-10-02 14:19:10 --> Utf8 Class Initialized
INFO - 2024-10-02 14:19:10 --> URI Class Initialized
INFO - 2024-10-02 14:19:10 --> Router Class Initialized
INFO - 2024-10-02 14:19:10 --> Output Class Initialized
INFO - 2024-10-02 14:19:10 --> Security Class Initialized
DEBUG - 2024-10-02 14:19:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-02 14:19:10 --> Input Class Initialized
INFO - 2024-10-02 14:19:10 --> Language Class Initialized
INFO - 2024-10-02 14:19:10 --> Language Class Initialized
INFO - 2024-10-02 14:19:10 --> Config Class Initialized
INFO - 2024-10-02 14:19:10 --> Loader Class Initialized
INFO - 2024-10-02 14:19:10 --> Helper loaded: url_helper
INFO - 2024-10-02 14:19:11 --> Helper loaded: file_helper
INFO - 2024-10-02 14:19:11 --> Helper loaded: form_helper
INFO - 2024-10-02 14:19:11 --> Helper loaded: my_helper
INFO - 2024-10-02 14:19:11 --> Database Driver Class Initialized
INFO - 2024-10-02 14:19:11 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-02 14:19:11 --> Controller Class Initialized
ERROR - 2024-10-02 14:19:11 --> Severity: Notice --> Undefined index: semester /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/set_kd/controllers/Set_kd.php 104
INFO - 2024-10-02 14:19:11 --> Final output sent to browser
DEBUG - 2024-10-02 14:19:11 --> Total execution time: 0.0912
INFO - 2024-10-02 14:19:29 --> Config Class Initialized
INFO - 2024-10-02 14:19:29 --> Hooks Class Initialized
DEBUG - 2024-10-02 14:19:29 --> UTF-8 Support Enabled
INFO - 2024-10-02 14:19:29 --> Utf8 Class Initialized
INFO - 2024-10-02 14:19:29 --> URI Class Initialized
INFO - 2024-10-02 14:19:29 --> Router Class Initialized
INFO - 2024-10-02 14:19:29 --> Output Class Initialized
INFO - 2024-10-02 14:19:29 --> Security Class Initialized
DEBUG - 2024-10-02 14:19:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-02 14:19:29 --> Input Class Initialized
INFO - 2024-10-02 14:19:29 --> Language Class Initialized
INFO - 2024-10-02 14:19:29 --> Language Class Initialized
INFO - 2024-10-02 14:19:29 --> Config Class Initialized
INFO - 2024-10-02 14:19:29 --> Loader Class Initialized
INFO - 2024-10-02 14:19:29 --> Helper loaded: url_helper
INFO - 2024-10-02 14:19:29 --> Helper loaded: file_helper
INFO - 2024-10-02 14:19:29 --> Helper loaded: form_helper
INFO - 2024-10-02 14:19:29 --> Helper loaded: my_helper
INFO - 2024-10-02 14:19:29 --> Database Driver Class Initialized
INFO - 2024-10-02 14:19:29 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-02 14:19:29 --> Controller Class Initialized
INFO - 2024-10-02 14:19:29 --> Final output sent to browser
DEBUG - 2024-10-02 14:19:29 --> Total execution time: 0.0480
INFO - 2024-10-02 14:19:31 --> Config Class Initialized
INFO - 2024-10-02 14:19:31 --> Hooks Class Initialized
DEBUG - 2024-10-02 14:19:31 --> UTF-8 Support Enabled
INFO - 2024-10-02 14:19:31 --> Utf8 Class Initialized
INFO - 2024-10-02 14:19:31 --> URI Class Initialized
INFO - 2024-10-02 14:19:31 --> Router Class Initialized
INFO - 2024-10-02 14:19:31 --> Output Class Initialized
INFO - 2024-10-02 14:19:31 --> Security Class Initialized
DEBUG - 2024-10-02 14:19:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-02 14:19:31 --> Input Class Initialized
INFO - 2024-10-02 14:19:31 --> Language Class Initialized
INFO - 2024-10-02 14:19:31 --> Language Class Initialized
INFO - 2024-10-02 14:19:31 --> Config Class Initialized
INFO - 2024-10-02 14:19:31 --> Loader Class Initialized
INFO - 2024-10-02 14:19:31 --> Helper loaded: url_helper
INFO - 2024-10-02 14:19:31 --> Helper loaded: file_helper
INFO - 2024-10-02 14:19:31 --> Helper loaded: form_helper
INFO - 2024-10-02 14:19:31 --> Helper loaded: my_helper
INFO - 2024-10-02 14:19:31 --> Database Driver Class Initialized
INFO - 2024-10-02 14:19:31 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-02 14:19:31 --> Controller Class Initialized
DEBUG - 2024-10-02 14:19:31 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_icb/views/list.php
DEBUG - 2024-10-02 14:19:31 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-10-02 14:19:31 --> Final output sent to browser
DEBUG - 2024-10-02 14:19:31 --> Total execution time: 0.0704
INFO - 2024-10-02 14:19:31 --> Config Class Initialized
INFO - 2024-10-02 14:19:31 --> Hooks Class Initialized
DEBUG - 2024-10-02 14:19:31 --> UTF-8 Support Enabled
INFO - 2024-10-02 14:19:31 --> Utf8 Class Initialized
INFO - 2024-10-02 14:19:31 --> URI Class Initialized
INFO - 2024-10-02 14:19:31 --> Router Class Initialized
INFO - 2024-10-02 14:19:31 --> Output Class Initialized
INFO - 2024-10-02 14:19:31 --> Security Class Initialized
DEBUG - 2024-10-02 14:19:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-02 14:19:31 --> Input Class Initialized
INFO - 2024-10-02 14:19:31 --> Language Class Initialized
INFO - 2024-10-02 14:19:31 --> Language Class Initialized
INFO - 2024-10-02 14:19:31 --> Config Class Initialized
INFO - 2024-10-02 14:19:31 --> Loader Class Initialized
INFO - 2024-10-02 14:19:31 --> Helper loaded: url_helper
INFO - 2024-10-02 14:19:31 --> Helper loaded: file_helper
INFO - 2024-10-02 14:19:31 --> Helper loaded: form_helper
INFO - 2024-10-02 14:19:31 --> Helper loaded: my_helper
INFO - 2024-10-02 14:19:31 --> Database Driver Class Initialized
INFO - 2024-10-02 14:19:31 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-02 14:19:31 --> Controller Class Initialized
INFO - 2024-10-02 14:19:32 --> Config Class Initialized
INFO - 2024-10-02 14:19:32 --> Hooks Class Initialized
DEBUG - 2024-10-02 14:19:32 --> UTF-8 Support Enabled
INFO - 2024-10-02 14:19:32 --> Utf8 Class Initialized
INFO - 2024-10-02 14:19:32 --> URI Class Initialized
INFO - 2024-10-02 14:19:32 --> Router Class Initialized
INFO - 2024-10-02 14:19:32 --> Output Class Initialized
INFO - 2024-10-02 14:19:32 --> Security Class Initialized
DEBUG - 2024-10-02 14:19:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-02 14:19:32 --> Input Class Initialized
INFO - 2024-10-02 14:19:32 --> Language Class Initialized
INFO - 2024-10-02 14:19:32 --> Language Class Initialized
INFO - 2024-10-02 14:19:32 --> Config Class Initialized
INFO - 2024-10-02 14:19:32 --> Loader Class Initialized
INFO - 2024-10-02 14:19:32 --> Helper loaded: url_helper
INFO - 2024-10-02 14:19:32 --> Helper loaded: file_helper
INFO - 2024-10-02 14:19:32 --> Helper loaded: form_helper
INFO - 2024-10-02 14:19:32 --> Helper loaded: my_helper
INFO - 2024-10-02 14:19:32 --> Database Driver Class Initialized
INFO - 2024-10-02 14:19:32 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-02 14:19:32 --> Controller Class Initialized
INFO - 2024-10-02 14:19:32 --> Final output sent to browser
DEBUG - 2024-10-02 14:19:32 --> Total execution time: 0.0311
INFO - 2024-10-02 14:19:35 --> Config Class Initialized
INFO - 2024-10-02 14:19:35 --> Hooks Class Initialized
DEBUG - 2024-10-02 14:19:35 --> UTF-8 Support Enabled
INFO - 2024-10-02 14:19:35 --> Utf8 Class Initialized
INFO - 2024-10-02 14:19:35 --> URI Class Initialized
INFO - 2024-10-02 14:19:35 --> Router Class Initialized
INFO - 2024-10-02 14:19:35 --> Output Class Initialized
INFO - 2024-10-02 14:19:35 --> Security Class Initialized
DEBUG - 2024-10-02 14:19:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-02 14:19:35 --> Input Class Initialized
INFO - 2024-10-02 14:19:35 --> Language Class Initialized
INFO - 2024-10-02 14:19:35 --> Language Class Initialized
INFO - 2024-10-02 14:19:35 --> Config Class Initialized
INFO - 2024-10-02 14:19:35 --> Loader Class Initialized
INFO - 2024-10-02 14:19:35 --> Helper loaded: url_helper
INFO - 2024-10-02 14:19:35 --> Helper loaded: file_helper
INFO - 2024-10-02 14:19:35 --> Helper loaded: form_helper
INFO - 2024-10-02 14:19:35 --> Helper loaded: my_helper
INFO - 2024-10-02 14:19:35 --> Database Driver Class Initialized
INFO - 2024-10-02 14:19:35 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-02 14:19:35 --> Controller Class Initialized
INFO - 2024-10-02 14:19:35 --> Final output sent to browser
DEBUG - 2024-10-02 14:19:35 --> Total execution time: 0.0761
INFO - 2024-10-02 14:19:35 --> Config Class Initialized
INFO - 2024-10-02 14:19:35 --> Hooks Class Initialized
DEBUG - 2024-10-02 14:19:35 --> UTF-8 Support Enabled
INFO - 2024-10-02 14:19:35 --> Utf8 Class Initialized
INFO - 2024-10-02 14:19:35 --> URI Class Initialized
INFO - 2024-10-02 14:19:35 --> Router Class Initialized
INFO - 2024-10-02 14:19:35 --> Output Class Initialized
INFO - 2024-10-02 14:19:35 --> Security Class Initialized
DEBUG - 2024-10-02 14:19:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-02 14:19:35 --> Input Class Initialized
INFO - 2024-10-02 14:19:35 --> Language Class Initialized
INFO - 2024-10-02 14:19:35 --> Language Class Initialized
INFO - 2024-10-02 14:19:35 --> Config Class Initialized
INFO - 2024-10-02 14:19:35 --> Loader Class Initialized
INFO - 2024-10-02 14:19:35 --> Helper loaded: url_helper
INFO - 2024-10-02 14:19:35 --> Helper loaded: file_helper
INFO - 2024-10-02 14:19:35 --> Helper loaded: form_helper
INFO - 2024-10-02 14:19:35 --> Helper loaded: my_helper
INFO - 2024-10-02 14:19:35 --> Database Driver Class Initialized
INFO - 2024-10-02 14:19:35 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-02 14:19:35 --> Controller Class Initialized
INFO - 2024-10-02 14:19:35 --> Final output sent to browser
DEBUG - 2024-10-02 14:19:35 --> Total execution time: 0.0319
INFO - 2024-10-02 14:19:47 --> Config Class Initialized
INFO - 2024-10-02 14:19:47 --> Hooks Class Initialized
DEBUG - 2024-10-02 14:19:47 --> UTF-8 Support Enabled
INFO - 2024-10-02 14:19:47 --> Utf8 Class Initialized
INFO - 2024-10-02 14:19:47 --> URI Class Initialized
INFO - 2024-10-02 14:19:47 --> Router Class Initialized
INFO - 2024-10-02 14:19:47 --> Output Class Initialized
INFO - 2024-10-02 14:19:47 --> Security Class Initialized
DEBUG - 2024-10-02 14:19:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-02 14:19:47 --> Input Class Initialized
INFO - 2024-10-02 14:19:47 --> Language Class Initialized
INFO - 2024-10-02 14:19:47 --> Language Class Initialized
INFO - 2024-10-02 14:19:47 --> Config Class Initialized
INFO - 2024-10-02 14:19:47 --> Loader Class Initialized
INFO - 2024-10-02 14:19:47 --> Helper loaded: url_helper
INFO - 2024-10-02 14:19:47 --> Helper loaded: file_helper
INFO - 2024-10-02 14:19:47 --> Helper loaded: form_helper
INFO - 2024-10-02 14:19:47 --> Helper loaded: my_helper
INFO - 2024-10-02 14:19:47 --> Database Driver Class Initialized
INFO - 2024-10-02 14:19:47 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-02 14:19:47 --> Controller Class Initialized
ERROR - 2024-10-02 14:19:47 --> Severity: Notice --> Undefined index: semester /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/set_kd/controllers/Set_kd.php 104
INFO - 2024-10-02 14:19:47 --> Final output sent to browser
DEBUG - 2024-10-02 14:19:47 --> Total execution time: 0.0353
INFO - 2024-10-02 14:19:49 --> Config Class Initialized
INFO - 2024-10-02 14:19:49 --> Hooks Class Initialized
DEBUG - 2024-10-02 14:19:49 --> UTF-8 Support Enabled
INFO - 2024-10-02 14:19:49 --> Utf8 Class Initialized
INFO - 2024-10-02 14:19:49 --> URI Class Initialized
INFO - 2024-10-02 14:19:49 --> Router Class Initialized
INFO - 2024-10-02 14:19:49 --> Output Class Initialized
INFO - 2024-10-02 14:19:49 --> Security Class Initialized
DEBUG - 2024-10-02 14:19:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-02 14:19:49 --> Input Class Initialized
INFO - 2024-10-02 14:19:49 --> Language Class Initialized
INFO - 2024-10-02 14:19:49 --> Language Class Initialized
INFO - 2024-10-02 14:19:49 --> Config Class Initialized
INFO - 2024-10-02 14:19:49 --> Loader Class Initialized
INFO - 2024-10-02 14:19:49 --> Helper loaded: url_helper
INFO - 2024-10-02 14:19:49 --> Helper loaded: file_helper
INFO - 2024-10-02 14:19:49 --> Helper loaded: form_helper
INFO - 2024-10-02 14:19:49 --> Helper loaded: my_helper
INFO - 2024-10-02 14:19:49 --> Database Driver Class Initialized
INFO - 2024-10-02 14:19:49 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-02 14:19:49 --> Controller Class Initialized
DEBUG - 2024-10-02 14:19:49 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_icb/views/list.php
DEBUG - 2024-10-02 14:19:49 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-10-02 14:19:49 --> Final output sent to browser
DEBUG - 2024-10-02 14:19:49 --> Total execution time: 0.0323
INFO - 2024-10-02 14:19:49 --> Config Class Initialized
INFO - 2024-10-02 14:19:49 --> Hooks Class Initialized
DEBUG - 2024-10-02 14:19:49 --> UTF-8 Support Enabled
INFO - 2024-10-02 14:19:49 --> Utf8 Class Initialized
INFO - 2024-10-02 14:19:49 --> URI Class Initialized
INFO - 2024-10-02 14:19:49 --> Router Class Initialized
INFO - 2024-10-02 14:19:49 --> Output Class Initialized
INFO - 2024-10-02 14:19:49 --> Security Class Initialized
DEBUG - 2024-10-02 14:19:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-02 14:19:49 --> Input Class Initialized
INFO - 2024-10-02 14:19:49 --> Language Class Initialized
INFO - 2024-10-02 14:19:49 --> Language Class Initialized
INFO - 2024-10-02 14:19:49 --> Config Class Initialized
INFO - 2024-10-02 14:19:49 --> Loader Class Initialized
INFO - 2024-10-02 14:19:49 --> Helper loaded: url_helper
INFO - 2024-10-02 14:19:49 --> Helper loaded: file_helper
INFO - 2024-10-02 14:19:49 --> Helper loaded: form_helper
INFO - 2024-10-02 14:19:49 --> Helper loaded: my_helper
INFO - 2024-10-02 14:19:49 --> Database Driver Class Initialized
INFO - 2024-10-02 14:19:49 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-02 14:19:49 --> Controller Class Initialized
INFO - 2024-10-02 14:19:57 --> Config Class Initialized
INFO - 2024-10-02 14:19:57 --> Hooks Class Initialized
DEBUG - 2024-10-02 14:19:57 --> UTF-8 Support Enabled
INFO - 2024-10-02 14:19:57 --> Utf8 Class Initialized
INFO - 2024-10-02 14:19:57 --> URI Class Initialized
INFO - 2024-10-02 14:19:57 --> Router Class Initialized
INFO - 2024-10-02 14:19:57 --> Output Class Initialized
INFO - 2024-10-02 14:19:57 --> Security Class Initialized
DEBUG - 2024-10-02 14:19:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-02 14:19:57 --> Input Class Initialized
INFO - 2024-10-02 14:19:57 --> Language Class Initialized
INFO - 2024-10-02 14:19:57 --> Language Class Initialized
INFO - 2024-10-02 14:19:57 --> Config Class Initialized
INFO - 2024-10-02 14:19:57 --> Loader Class Initialized
INFO - 2024-10-02 14:19:57 --> Helper loaded: url_helper
INFO - 2024-10-02 14:19:57 --> Helper loaded: file_helper
INFO - 2024-10-02 14:19:57 --> Helper loaded: form_helper
INFO - 2024-10-02 14:19:57 --> Helper loaded: my_helper
INFO - 2024-10-02 14:19:57 --> Database Driver Class Initialized
INFO - 2024-10-02 14:19:57 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-02 14:19:57 --> Controller Class Initialized
INFO - 2024-10-02 14:19:57 --> Final output sent to browser
DEBUG - 2024-10-02 14:19:57 --> Total execution time: 0.0322
INFO - 2024-10-02 14:20:02 --> Config Class Initialized
INFO - 2024-10-02 14:20:02 --> Hooks Class Initialized
DEBUG - 2024-10-02 14:20:02 --> UTF-8 Support Enabled
INFO - 2024-10-02 14:20:02 --> Utf8 Class Initialized
INFO - 2024-10-02 14:20:02 --> URI Class Initialized
INFO - 2024-10-02 14:20:02 --> Router Class Initialized
INFO - 2024-10-02 14:20:02 --> Output Class Initialized
INFO - 2024-10-02 14:20:02 --> Security Class Initialized
DEBUG - 2024-10-02 14:20:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-02 14:20:02 --> Input Class Initialized
INFO - 2024-10-02 14:20:02 --> Language Class Initialized
INFO - 2024-10-02 14:20:02 --> Language Class Initialized
INFO - 2024-10-02 14:20:02 --> Config Class Initialized
INFO - 2024-10-02 14:20:02 --> Loader Class Initialized
INFO - 2024-10-02 14:20:02 --> Helper loaded: url_helper
INFO - 2024-10-02 14:20:02 --> Helper loaded: file_helper
INFO - 2024-10-02 14:20:02 --> Helper loaded: form_helper
INFO - 2024-10-02 14:20:02 --> Helper loaded: my_helper
INFO - 2024-10-02 14:20:02 --> Database Driver Class Initialized
INFO - 2024-10-02 14:20:02 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-02 14:20:02 --> Controller Class Initialized
ERROR - 2024-10-02 14:20:02 --> Severity: Notice --> Undefined index: semester /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/set_kd/controllers/Set_kd.php 104
INFO - 2024-10-02 14:20:02 --> Final output sent to browser
DEBUG - 2024-10-02 14:20:02 --> Total execution time: 0.1566
INFO - 2024-10-02 14:20:04 --> Config Class Initialized
INFO - 2024-10-02 14:20:04 --> Hooks Class Initialized
DEBUG - 2024-10-02 14:20:04 --> UTF-8 Support Enabled
INFO - 2024-10-02 14:20:04 --> Utf8 Class Initialized
INFO - 2024-10-02 14:20:04 --> URI Class Initialized
INFO - 2024-10-02 14:20:04 --> Router Class Initialized
INFO - 2024-10-02 14:20:04 --> Output Class Initialized
INFO - 2024-10-02 14:20:04 --> Security Class Initialized
DEBUG - 2024-10-02 14:20:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-02 14:20:04 --> Input Class Initialized
INFO - 2024-10-02 14:20:04 --> Language Class Initialized
INFO - 2024-10-02 14:20:04 --> Language Class Initialized
INFO - 2024-10-02 14:20:04 --> Config Class Initialized
INFO - 2024-10-02 14:20:04 --> Loader Class Initialized
INFO - 2024-10-02 14:20:04 --> Helper loaded: url_helper
INFO - 2024-10-02 14:20:04 --> Helper loaded: file_helper
INFO - 2024-10-02 14:20:04 --> Helper loaded: form_helper
INFO - 2024-10-02 14:20:04 --> Helper loaded: my_helper
INFO - 2024-10-02 14:20:04 --> Database Driver Class Initialized
INFO - 2024-10-02 14:20:04 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-02 14:20:04 --> Controller Class Initialized
DEBUG - 2024-10-02 14:20:04 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_icb/views/list.php
DEBUG - 2024-10-02 14:20:04 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-10-02 14:20:04 --> Final output sent to browser
DEBUG - 2024-10-02 14:20:04 --> Total execution time: 0.0437
INFO - 2024-10-02 14:20:04 --> Config Class Initialized
INFO - 2024-10-02 14:20:04 --> Hooks Class Initialized
DEBUG - 2024-10-02 14:20:04 --> UTF-8 Support Enabled
INFO - 2024-10-02 14:20:04 --> Utf8 Class Initialized
INFO - 2024-10-02 14:20:04 --> URI Class Initialized
INFO - 2024-10-02 14:20:04 --> Router Class Initialized
INFO - 2024-10-02 14:20:04 --> Output Class Initialized
INFO - 2024-10-02 14:20:04 --> Security Class Initialized
DEBUG - 2024-10-02 14:20:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-02 14:20:04 --> Input Class Initialized
INFO - 2024-10-02 14:20:04 --> Language Class Initialized
INFO - 2024-10-02 14:20:04 --> Language Class Initialized
INFO - 2024-10-02 14:20:04 --> Config Class Initialized
INFO - 2024-10-02 14:20:04 --> Loader Class Initialized
INFO - 2024-10-02 14:20:04 --> Helper loaded: url_helper
INFO - 2024-10-02 14:20:04 --> Helper loaded: file_helper
INFO - 2024-10-02 14:20:04 --> Helper loaded: form_helper
INFO - 2024-10-02 14:20:04 --> Helper loaded: my_helper
INFO - 2024-10-02 14:20:04 --> Database Driver Class Initialized
INFO - 2024-10-02 14:20:04 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-02 14:20:04 --> Controller Class Initialized
INFO - 2024-10-02 14:20:11 --> Config Class Initialized
INFO - 2024-10-02 14:20:11 --> Hooks Class Initialized
DEBUG - 2024-10-02 14:20:11 --> UTF-8 Support Enabled
INFO - 2024-10-02 14:20:11 --> Utf8 Class Initialized
INFO - 2024-10-02 14:20:11 --> URI Class Initialized
INFO - 2024-10-02 14:20:11 --> Router Class Initialized
INFO - 2024-10-02 14:20:11 --> Output Class Initialized
INFO - 2024-10-02 14:20:11 --> Security Class Initialized
DEBUG - 2024-10-02 14:20:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-02 14:20:11 --> Input Class Initialized
INFO - 2024-10-02 14:20:11 --> Language Class Initialized
INFO - 2024-10-02 14:20:11 --> Language Class Initialized
INFO - 2024-10-02 14:20:11 --> Config Class Initialized
INFO - 2024-10-02 14:20:11 --> Loader Class Initialized
INFO - 2024-10-02 14:20:11 --> Helper loaded: url_helper
INFO - 2024-10-02 14:20:11 --> Helper loaded: file_helper
INFO - 2024-10-02 14:20:11 --> Helper loaded: form_helper
INFO - 2024-10-02 14:20:11 --> Helper loaded: my_helper
INFO - 2024-10-02 14:20:11 --> Database Driver Class Initialized
INFO - 2024-10-02 14:20:11 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-02 14:20:11 --> Controller Class Initialized
INFO - 2024-10-02 14:20:11 --> Final output sent to browser
DEBUG - 2024-10-02 14:20:11 --> Total execution time: 0.0337
INFO - 2024-10-02 14:20:16 --> Config Class Initialized
INFO - 2024-10-02 14:20:16 --> Hooks Class Initialized
DEBUG - 2024-10-02 14:20:16 --> UTF-8 Support Enabled
INFO - 2024-10-02 14:20:16 --> Utf8 Class Initialized
INFO - 2024-10-02 14:20:16 --> URI Class Initialized
INFO - 2024-10-02 14:20:16 --> Router Class Initialized
INFO - 2024-10-02 14:20:16 --> Output Class Initialized
INFO - 2024-10-02 14:20:16 --> Security Class Initialized
DEBUG - 2024-10-02 14:20:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-02 14:20:16 --> Input Class Initialized
INFO - 2024-10-02 14:20:16 --> Language Class Initialized
INFO - 2024-10-02 14:20:16 --> Language Class Initialized
INFO - 2024-10-02 14:20:16 --> Config Class Initialized
INFO - 2024-10-02 14:20:16 --> Loader Class Initialized
INFO - 2024-10-02 14:20:16 --> Helper loaded: url_helper
INFO - 2024-10-02 14:20:16 --> Helper loaded: file_helper
INFO - 2024-10-02 14:20:16 --> Helper loaded: form_helper
INFO - 2024-10-02 14:20:16 --> Helper loaded: my_helper
INFO - 2024-10-02 14:20:16 --> Database Driver Class Initialized
INFO - 2024-10-02 14:20:16 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-02 14:20:16 --> Controller Class Initialized
ERROR - 2024-10-02 14:20:16 --> Severity: Notice --> Undefined index: semester /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/set_kd/controllers/Set_kd.php 104
INFO - 2024-10-02 14:20:16 --> Final output sent to browser
DEBUG - 2024-10-02 14:20:16 --> Total execution time: 0.0373
INFO - 2024-10-02 14:20:18 --> Config Class Initialized
INFO - 2024-10-02 14:20:18 --> Hooks Class Initialized
DEBUG - 2024-10-02 14:20:18 --> UTF-8 Support Enabled
INFO - 2024-10-02 14:20:18 --> Utf8 Class Initialized
INFO - 2024-10-02 14:20:18 --> URI Class Initialized
INFO - 2024-10-02 14:20:18 --> Router Class Initialized
INFO - 2024-10-02 14:20:18 --> Output Class Initialized
INFO - 2024-10-02 14:20:18 --> Security Class Initialized
DEBUG - 2024-10-02 14:20:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-02 14:20:18 --> Input Class Initialized
INFO - 2024-10-02 14:20:18 --> Language Class Initialized
INFO - 2024-10-02 14:20:18 --> Language Class Initialized
INFO - 2024-10-02 14:20:18 --> Config Class Initialized
INFO - 2024-10-02 14:20:18 --> Loader Class Initialized
INFO - 2024-10-02 14:20:18 --> Helper loaded: url_helper
INFO - 2024-10-02 14:20:18 --> Helper loaded: file_helper
INFO - 2024-10-02 14:20:18 --> Helper loaded: form_helper
INFO - 2024-10-02 14:20:18 --> Helper loaded: my_helper
INFO - 2024-10-02 14:20:18 --> Database Driver Class Initialized
INFO - 2024-10-02 14:20:18 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-02 14:20:18 --> Controller Class Initialized
DEBUG - 2024-10-02 14:20:18 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_icb/views/list.php
DEBUG - 2024-10-02 14:20:18 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-10-02 14:20:18 --> Final output sent to browser
DEBUG - 2024-10-02 14:20:18 --> Total execution time: 0.0757
INFO - 2024-10-02 14:20:18 --> Config Class Initialized
INFO - 2024-10-02 14:20:18 --> Hooks Class Initialized
DEBUG - 2024-10-02 14:20:18 --> UTF-8 Support Enabled
INFO - 2024-10-02 14:20:18 --> Utf8 Class Initialized
INFO - 2024-10-02 14:20:18 --> URI Class Initialized
INFO - 2024-10-02 14:20:18 --> Router Class Initialized
INFO - 2024-10-02 14:20:18 --> Output Class Initialized
INFO - 2024-10-02 14:20:18 --> Security Class Initialized
DEBUG - 2024-10-02 14:20:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-02 14:20:18 --> Input Class Initialized
INFO - 2024-10-02 14:20:18 --> Language Class Initialized
INFO - 2024-10-02 14:20:18 --> Language Class Initialized
INFO - 2024-10-02 14:20:18 --> Config Class Initialized
INFO - 2024-10-02 14:20:18 --> Loader Class Initialized
INFO - 2024-10-02 14:20:18 --> Helper loaded: url_helper
INFO - 2024-10-02 14:20:18 --> Helper loaded: file_helper
INFO - 2024-10-02 14:20:18 --> Helper loaded: form_helper
INFO - 2024-10-02 14:20:18 --> Helper loaded: my_helper
INFO - 2024-10-02 14:20:18 --> Database Driver Class Initialized
INFO - 2024-10-02 14:20:18 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-02 14:20:18 --> Controller Class Initialized
INFO - 2024-10-02 14:20:32 --> Config Class Initialized
INFO - 2024-10-02 14:20:32 --> Hooks Class Initialized
DEBUG - 2024-10-02 14:20:32 --> UTF-8 Support Enabled
INFO - 2024-10-02 14:20:32 --> Utf8 Class Initialized
INFO - 2024-10-02 14:20:32 --> URI Class Initialized
INFO - 2024-10-02 14:20:32 --> Router Class Initialized
INFO - 2024-10-02 14:20:32 --> Output Class Initialized
INFO - 2024-10-02 14:20:32 --> Security Class Initialized
DEBUG - 2024-10-02 14:20:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-02 14:20:32 --> Input Class Initialized
INFO - 2024-10-02 14:20:32 --> Language Class Initialized
INFO - 2024-10-02 14:20:32 --> Language Class Initialized
INFO - 2024-10-02 14:20:32 --> Config Class Initialized
INFO - 2024-10-02 14:20:32 --> Loader Class Initialized
INFO - 2024-10-02 14:20:32 --> Helper loaded: url_helper
INFO - 2024-10-02 14:20:32 --> Helper loaded: file_helper
INFO - 2024-10-02 14:20:32 --> Helper loaded: form_helper
INFO - 2024-10-02 14:20:32 --> Helper loaded: my_helper
INFO - 2024-10-02 14:20:32 --> Database Driver Class Initialized
INFO - 2024-10-02 14:20:32 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-02 14:20:32 --> Controller Class Initialized
DEBUG - 2024-10-02 14:20:32 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/view_mapel/views/v_view_mapel.php
DEBUG - 2024-10-02 14:20:32 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-10-02 14:20:32 --> Final output sent to browser
DEBUG - 2024-10-02 14:20:32 --> Total execution time: 0.0450
INFO - 2024-10-02 14:20:36 --> Config Class Initialized
INFO - 2024-10-02 14:20:36 --> Hooks Class Initialized
DEBUG - 2024-10-02 14:20:36 --> UTF-8 Support Enabled
INFO - 2024-10-02 14:20:36 --> Utf8 Class Initialized
INFO - 2024-10-02 14:20:36 --> URI Class Initialized
INFO - 2024-10-02 14:20:36 --> Router Class Initialized
INFO - 2024-10-02 14:20:36 --> Output Class Initialized
INFO - 2024-10-02 14:20:36 --> Security Class Initialized
DEBUG - 2024-10-02 14:20:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-02 14:20:36 --> Input Class Initialized
INFO - 2024-10-02 14:20:36 --> Language Class Initialized
INFO - 2024-10-02 14:20:36 --> Language Class Initialized
INFO - 2024-10-02 14:20:36 --> Config Class Initialized
INFO - 2024-10-02 14:20:36 --> Loader Class Initialized
INFO - 2024-10-02 14:20:36 --> Helper loaded: url_helper
INFO - 2024-10-02 14:20:36 --> Helper loaded: file_helper
INFO - 2024-10-02 14:20:36 --> Helper loaded: form_helper
INFO - 2024-10-02 14:20:36 --> Helper loaded: my_helper
INFO - 2024-10-02 14:20:36 --> Database Driver Class Initialized
INFO - 2024-10-02 14:20:36 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-02 14:20:36 --> Controller Class Initialized
DEBUG - 2024-10-02 14:20:36 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pss/views/list.php
DEBUG - 2024-10-02 14:20:36 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-10-02 14:20:36 --> Final output sent to browser
DEBUG - 2024-10-02 14:20:36 --> Total execution time: 0.0503
INFO - 2024-10-02 14:20:36 --> Config Class Initialized
INFO - 2024-10-02 14:20:36 --> Hooks Class Initialized
DEBUG - 2024-10-02 14:20:36 --> UTF-8 Support Enabled
INFO - 2024-10-02 14:20:36 --> Utf8 Class Initialized
INFO - 2024-10-02 14:20:36 --> URI Class Initialized
INFO - 2024-10-02 14:20:36 --> Router Class Initialized
INFO - 2024-10-02 14:20:36 --> Output Class Initialized
INFO - 2024-10-02 14:20:36 --> Security Class Initialized
DEBUG - 2024-10-02 14:20:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-02 14:20:36 --> Input Class Initialized
INFO - 2024-10-02 14:20:36 --> Language Class Initialized
INFO - 2024-10-02 14:20:36 --> Language Class Initialized
INFO - 2024-10-02 14:20:36 --> Config Class Initialized
INFO - 2024-10-02 14:20:36 --> Loader Class Initialized
INFO - 2024-10-02 14:20:36 --> Helper loaded: url_helper
INFO - 2024-10-02 14:20:36 --> Helper loaded: file_helper
INFO - 2024-10-02 14:20:36 --> Helper loaded: form_helper
INFO - 2024-10-02 14:20:36 --> Helper loaded: my_helper
INFO - 2024-10-02 14:20:36 --> Database Driver Class Initialized
INFO - 2024-10-02 14:20:36 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-02 14:20:36 --> Controller Class Initialized
INFO - 2024-10-02 14:20:38 --> Config Class Initialized
INFO - 2024-10-02 14:20:38 --> Hooks Class Initialized
DEBUG - 2024-10-02 14:20:38 --> UTF-8 Support Enabled
INFO - 2024-10-02 14:20:38 --> Utf8 Class Initialized
INFO - 2024-10-02 14:20:38 --> URI Class Initialized
INFO - 2024-10-02 14:20:38 --> Router Class Initialized
INFO - 2024-10-02 14:20:38 --> Output Class Initialized
INFO - 2024-10-02 14:20:38 --> Security Class Initialized
DEBUG - 2024-10-02 14:20:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-02 14:20:38 --> Input Class Initialized
INFO - 2024-10-02 14:20:38 --> Language Class Initialized
INFO - 2024-10-02 14:20:38 --> Language Class Initialized
INFO - 2024-10-02 14:20:38 --> Config Class Initialized
INFO - 2024-10-02 14:20:38 --> Loader Class Initialized
INFO - 2024-10-02 14:20:38 --> Helper loaded: url_helper
INFO - 2024-10-02 14:20:38 --> Helper loaded: file_helper
INFO - 2024-10-02 14:20:38 --> Helper loaded: form_helper
INFO - 2024-10-02 14:20:38 --> Helper loaded: my_helper
INFO - 2024-10-02 14:20:38 --> Database Driver Class Initialized
INFO - 2024-10-02 14:20:38 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-02 14:20:38 --> Controller Class Initialized
INFO - 2024-10-02 14:20:38 --> Final output sent to browser
DEBUG - 2024-10-02 14:20:38 --> Total execution time: 0.0322
INFO - 2024-10-02 14:20:52 --> Config Class Initialized
INFO - 2024-10-02 14:20:52 --> Hooks Class Initialized
DEBUG - 2024-10-02 14:20:52 --> UTF-8 Support Enabled
INFO - 2024-10-02 14:20:52 --> Utf8 Class Initialized
INFO - 2024-10-02 14:20:52 --> URI Class Initialized
INFO - 2024-10-02 14:20:52 --> Router Class Initialized
INFO - 2024-10-02 14:20:52 --> Output Class Initialized
INFO - 2024-10-02 14:20:52 --> Security Class Initialized
DEBUG - 2024-10-02 14:20:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-02 14:20:52 --> Input Class Initialized
INFO - 2024-10-02 14:20:52 --> Language Class Initialized
INFO - 2024-10-02 14:20:52 --> Language Class Initialized
INFO - 2024-10-02 14:20:52 --> Config Class Initialized
INFO - 2024-10-02 14:20:52 --> Loader Class Initialized
INFO - 2024-10-02 14:20:52 --> Helper loaded: url_helper
INFO - 2024-10-02 14:20:52 --> Helper loaded: file_helper
INFO - 2024-10-02 14:20:52 --> Helper loaded: form_helper
INFO - 2024-10-02 14:20:52 --> Helper loaded: my_helper
INFO - 2024-10-02 14:20:52 --> Database Driver Class Initialized
INFO - 2024-10-02 14:20:53 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-02 14:20:53 --> Controller Class Initialized
ERROR - 2024-10-02 14:20:53 --> Severity: Notice --> Undefined index: semester /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/set_kd/controllers/Set_kd.php 104
INFO - 2024-10-02 14:20:53 --> Final output sent to browser
DEBUG - 2024-10-02 14:20:53 --> Total execution time: 0.0763
INFO - 2024-10-02 14:20:54 --> Config Class Initialized
INFO - 2024-10-02 14:20:54 --> Hooks Class Initialized
DEBUG - 2024-10-02 14:20:54 --> UTF-8 Support Enabled
INFO - 2024-10-02 14:20:54 --> Utf8 Class Initialized
INFO - 2024-10-02 14:20:54 --> URI Class Initialized
INFO - 2024-10-02 14:20:54 --> Router Class Initialized
INFO - 2024-10-02 14:20:54 --> Output Class Initialized
INFO - 2024-10-02 14:20:54 --> Security Class Initialized
DEBUG - 2024-10-02 14:20:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-02 14:20:54 --> Input Class Initialized
INFO - 2024-10-02 14:20:54 --> Language Class Initialized
INFO - 2024-10-02 14:20:54 --> Language Class Initialized
INFO - 2024-10-02 14:20:54 --> Config Class Initialized
INFO - 2024-10-02 14:20:54 --> Loader Class Initialized
INFO - 2024-10-02 14:20:54 --> Helper loaded: url_helper
INFO - 2024-10-02 14:20:54 --> Helper loaded: file_helper
INFO - 2024-10-02 14:20:54 --> Helper loaded: form_helper
INFO - 2024-10-02 14:20:54 --> Helper loaded: my_helper
INFO - 2024-10-02 14:20:54 --> Database Driver Class Initialized
INFO - 2024-10-02 14:20:54 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-02 14:20:54 --> Controller Class Initialized
DEBUG - 2024-10-02 14:20:54 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pss/views/list.php
DEBUG - 2024-10-02 14:20:54 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-10-02 14:20:54 --> Final output sent to browser
DEBUG - 2024-10-02 14:20:54 --> Total execution time: 0.0411
INFO - 2024-10-02 14:20:54 --> Config Class Initialized
INFO - 2024-10-02 14:20:54 --> Hooks Class Initialized
DEBUG - 2024-10-02 14:20:54 --> UTF-8 Support Enabled
INFO - 2024-10-02 14:20:54 --> Utf8 Class Initialized
INFO - 2024-10-02 14:20:54 --> URI Class Initialized
INFO - 2024-10-02 14:20:54 --> Router Class Initialized
INFO - 2024-10-02 14:20:54 --> Output Class Initialized
INFO - 2024-10-02 14:20:54 --> Security Class Initialized
DEBUG - 2024-10-02 14:20:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-02 14:20:54 --> Input Class Initialized
INFO - 2024-10-02 14:20:54 --> Language Class Initialized
INFO - 2024-10-02 14:20:54 --> Language Class Initialized
INFO - 2024-10-02 14:20:54 --> Config Class Initialized
INFO - 2024-10-02 14:20:54 --> Loader Class Initialized
INFO - 2024-10-02 14:20:54 --> Helper loaded: url_helper
INFO - 2024-10-02 14:20:54 --> Helper loaded: file_helper
INFO - 2024-10-02 14:20:54 --> Helper loaded: form_helper
INFO - 2024-10-02 14:20:54 --> Helper loaded: my_helper
INFO - 2024-10-02 14:20:54 --> Database Driver Class Initialized
INFO - 2024-10-02 14:20:54 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-02 14:20:54 --> Controller Class Initialized
INFO - 2024-10-02 14:20:56 --> Config Class Initialized
INFO - 2024-10-02 14:20:56 --> Hooks Class Initialized
DEBUG - 2024-10-02 14:20:56 --> UTF-8 Support Enabled
INFO - 2024-10-02 14:20:56 --> Utf8 Class Initialized
INFO - 2024-10-02 14:20:56 --> URI Class Initialized
INFO - 2024-10-02 14:20:56 --> Router Class Initialized
INFO - 2024-10-02 14:20:56 --> Output Class Initialized
INFO - 2024-10-02 14:20:56 --> Security Class Initialized
DEBUG - 2024-10-02 14:20:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-02 14:20:56 --> Input Class Initialized
INFO - 2024-10-02 14:20:56 --> Language Class Initialized
INFO - 2024-10-02 14:20:56 --> Language Class Initialized
INFO - 2024-10-02 14:20:56 --> Config Class Initialized
INFO - 2024-10-02 14:20:56 --> Loader Class Initialized
INFO - 2024-10-02 14:20:56 --> Helper loaded: url_helper
INFO - 2024-10-02 14:20:56 --> Helper loaded: file_helper
INFO - 2024-10-02 14:20:56 --> Helper loaded: form_helper
INFO - 2024-10-02 14:20:56 --> Helper loaded: my_helper
INFO - 2024-10-02 14:20:56 --> Database Driver Class Initialized
INFO - 2024-10-02 14:20:56 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-02 14:20:56 --> Controller Class Initialized
INFO - 2024-10-02 14:20:56 --> Final output sent to browser
DEBUG - 2024-10-02 14:20:56 --> Total execution time: 0.0348
INFO - 2024-10-02 14:21:19 --> Config Class Initialized
INFO - 2024-10-02 14:21:19 --> Hooks Class Initialized
DEBUG - 2024-10-02 14:21:19 --> UTF-8 Support Enabled
INFO - 2024-10-02 14:21:19 --> Utf8 Class Initialized
INFO - 2024-10-02 14:21:19 --> URI Class Initialized
INFO - 2024-10-02 14:21:19 --> Router Class Initialized
INFO - 2024-10-02 14:21:19 --> Output Class Initialized
INFO - 2024-10-02 14:21:19 --> Security Class Initialized
DEBUG - 2024-10-02 14:21:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-02 14:21:19 --> Input Class Initialized
INFO - 2024-10-02 14:21:19 --> Language Class Initialized
INFO - 2024-10-02 14:21:19 --> Language Class Initialized
INFO - 2024-10-02 14:21:19 --> Config Class Initialized
INFO - 2024-10-02 14:21:19 --> Loader Class Initialized
INFO - 2024-10-02 14:21:19 --> Helper loaded: url_helper
INFO - 2024-10-02 14:21:19 --> Helper loaded: file_helper
INFO - 2024-10-02 14:21:19 --> Helper loaded: form_helper
INFO - 2024-10-02 14:21:19 --> Helper loaded: my_helper
INFO - 2024-10-02 14:21:19 --> Database Driver Class Initialized
INFO - 2024-10-02 14:21:19 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-02 14:21:19 --> Controller Class Initialized
ERROR - 2024-10-02 14:21:19 --> Severity: Notice --> Undefined index: semester /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/set_kd/controllers/Set_kd.php 104
INFO - 2024-10-02 14:21:19 --> Final output sent to browser
DEBUG - 2024-10-02 14:21:19 --> Total execution time: 0.0334
INFO - 2024-10-02 14:21:21 --> Config Class Initialized
INFO - 2024-10-02 14:21:21 --> Hooks Class Initialized
DEBUG - 2024-10-02 14:21:21 --> UTF-8 Support Enabled
INFO - 2024-10-02 14:21:21 --> Utf8 Class Initialized
INFO - 2024-10-02 14:21:21 --> URI Class Initialized
INFO - 2024-10-02 14:21:21 --> Router Class Initialized
INFO - 2024-10-02 14:21:21 --> Output Class Initialized
INFO - 2024-10-02 14:21:21 --> Security Class Initialized
DEBUG - 2024-10-02 14:21:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-02 14:21:21 --> Input Class Initialized
INFO - 2024-10-02 14:21:21 --> Language Class Initialized
INFO - 2024-10-02 14:21:21 --> Language Class Initialized
INFO - 2024-10-02 14:21:21 --> Config Class Initialized
INFO - 2024-10-02 14:21:21 --> Loader Class Initialized
INFO - 2024-10-02 14:21:21 --> Helper loaded: url_helper
INFO - 2024-10-02 14:21:21 --> Helper loaded: file_helper
INFO - 2024-10-02 14:21:21 --> Helper loaded: form_helper
INFO - 2024-10-02 14:21:21 --> Helper loaded: my_helper
INFO - 2024-10-02 14:21:21 --> Database Driver Class Initialized
INFO - 2024-10-02 14:21:21 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-02 14:21:21 --> Controller Class Initialized
DEBUG - 2024-10-02 14:21:22 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pss/views/list.php
DEBUG - 2024-10-02 14:21:22 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-10-02 14:21:22 --> Final output sent to browser
DEBUG - 2024-10-02 14:21:22 --> Total execution time: 0.0443
INFO - 2024-10-02 14:21:22 --> Config Class Initialized
INFO - 2024-10-02 14:21:22 --> Hooks Class Initialized
DEBUG - 2024-10-02 14:21:22 --> UTF-8 Support Enabled
INFO - 2024-10-02 14:21:22 --> Utf8 Class Initialized
INFO - 2024-10-02 14:21:22 --> URI Class Initialized
INFO - 2024-10-02 14:21:22 --> Router Class Initialized
INFO - 2024-10-02 14:21:22 --> Output Class Initialized
INFO - 2024-10-02 14:21:22 --> Security Class Initialized
DEBUG - 2024-10-02 14:21:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-02 14:21:22 --> Input Class Initialized
INFO - 2024-10-02 14:21:22 --> Language Class Initialized
INFO - 2024-10-02 14:21:22 --> Language Class Initialized
INFO - 2024-10-02 14:21:22 --> Config Class Initialized
INFO - 2024-10-02 14:21:22 --> Loader Class Initialized
INFO - 2024-10-02 14:21:22 --> Helper loaded: url_helper
INFO - 2024-10-02 14:21:22 --> Helper loaded: file_helper
INFO - 2024-10-02 14:21:22 --> Helper loaded: form_helper
INFO - 2024-10-02 14:21:22 --> Helper loaded: my_helper
INFO - 2024-10-02 14:21:22 --> Database Driver Class Initialized
INFO - 2024-10-02 14:21:22 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-02 14:21:22 --> Controller Class Initialized
INFO - 2024-10-02 14:21:24 --> Config Class Initialized
INFO - 2024-10-02 14:21:24 --> Hooks Class Initialized
DEBUG - 2024-10-02 14:21:24 --> UTF-8 Support Enabled
INFO - 2024-10-02 14:21:24 --> Utf8 Class Initialized
INFO - 2024-10-02 14:21:24 --> URI Class Initialized
INFO - 2024-10-02 14:21:24 --> Router Class Initialized
INFO - 2024-10-02 14:21:24 --> Output Class Initialized
INFO - 2024-10-02 14:21:24 --> Security Class Initialized
DEBUG - 2024-10-02 14:21:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-02 14:21:24 --> Input Class Initialized
INFO - 2024-10-02 14:21:24 --> Language Class Initialized
INFO - 2024-10-02 14:21:24 --> Language Class Initialized
INFO - 2024-10-02 14:21:24 --> Config Class Initialized
INFO - 2024-10-02 14:21:24 --> Loader Class Initialized
INFO - 2024-10-02 14:21:24 --> Helper loaded: url_helper
INFO - 2024-10-02 14:21:24 --> Helper loaded: file_helper
INFO - 2024-10-02 14:21:24 --> Helper loaded: form_helper
INFO - 2024-10-02 14:21:24 --> Helper loaded: my_helper
INFO - 2024-10-02 14:21:24 --> Database Driver Class Initialized
INFO - 2024-10-02 14:21:24 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-02 14:21:24 --> Controller Class Initialized
INFO - 2024-10-02 14:21:24 --> Final output sent to browser
DEBUG - 2024-10-02 14:21:24 --> Total execution time: 0.0381
INFO - 2024-10-02 14:21:34 --> Config Class Initialized
INFO - 2024-10-02 14:21:34 --> Hooks Class Initialized
DEBUG - 2024-10-02 14:21:34 --> UTF-8 Support Enabled
INFO - 2024-10-02 14:21:34 --> Utf8 Class Initialized
INFO - 2024-10-02 14:21:34 --> URI Class Initialized
INFO - 2024-10-02 14:21:34 --> Router Class Initialized
INFO - 2024-10-02 14:21:34 --> Output Class Initialized
INFO - 2024-10-02 14:21:34 --> Security Class Initialized
DEBUG - 2024-10-02 14:21:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-02 14:21:34 --> Input Class Initialized
INFO - 2024-10-02 14:21:34 --> Language Class Initialized
INFO - 2024-10-02 14:21:34 --> Language Class Initialized
INFO - 2024-10-02 14:21:34 --> Config Class Initialized
INFO - 2024-10-02 14:21:34 --> Loader Class Initialized
INFO - 2024-10-02 14:21:34 --> Helper loaded: url_helper
INFO - 2024-10-02 14:21:34 --> Helper loaded: file_helper
INFO - 2024-10-02 14:21:34 --> Helper loaded: form_helper
INFO - 2024-10-02 14:21:34 --> Helper loaded: my_helper
INFO - 2024-10-02 14:21:34 --> Database Driver Class Initialized
INFO - 2024-10-02 14:21:34 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-02 14:21:34 --> Controller Class Initialized
INFO - 2024-10-02 14:21:35 --> Final output sent to browser
DEBUG - 2024-10-02 14:21:35 --> Total execution time: 0.3763
INFO - 2024-10-02 14:21:43 --> Config Class Initialized
INFO - 2024-10-02 14:21:43 --> Hooks Class Initialized
DEBUG - 2024-10-02 14:21:43 --> UTF-8 Support Enabled
INFO - 2024-10-02 14:21:43 --> Utf8 Class Initialized
INFO - 2024-10-02 14:21:43 --> URI Class Initialized
INFO - 2024-10-02 14:21:43 --> Router Class Initialized
INFO - 2024-10-02 14:21:43 --> Output Class Initialized
INFO - 2024-10-02 14:21:43 --> Security Class Initialized
DEBUG - 2024-10-02 14:21:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-02 14:21:43 --> Input Class Initialized
INFO - 2024-10-02 14:21:43 --> Language Class Initialized
INFO - 2024-10-02 14:21:43 --> Language Class Initialized
INFO - 2024-10-02 14:21:43 --> Config Class Initialized
INFO - 2024-10-02 14:21:43 --> Loader Class Initialized
INFO - 2024-10-02 14:21:43 --> Helper loaded: url_helper
INFO - 2024-10-02 14:21:43 --> Helper loaded: file_helper
INFO - 2024-10-02 14:21:43 --> Helper loaded: form_helper
INFO - 2024-10-02 14:21:43 --> Helper loaded: my_helper
INFO - 2024-10-02 14:21:43 --> Database Driver Class Initialized
INFO - 2024-10-02 14:21:43 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-02 14:21:43 --> Controller Class Initialized
ERROR - 2024-10-02 14:21:43 --> Severity: Notice --> Undefined index: semester /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/set_kd/controllers/Set_kd.php 104
INFO - 2024-10-02 14:21:43 --> Final output sent to browser
DEBUG - 2024-10-02 14:21:43 --> Total execution time: 0.1282
INFO - 2024-10-02 14:21:45 --> Config Class Initialized
INFO - 2024-10-02 14:21:45 --> Hooks Class Initialized
DEBUG - 2024-10-02 14:21:45 --> UTF-8 Support Enabled
INFO - 2024-10-02 14:21:45 --> Utf8 Class Initialized
INFO - 2024-10-02 14:21:45 --> URI Class Initialized
INFO - 2024-10-02 14:21:45 --> Router Class Initialized
INFO - 2024-10-02 14:21:45 --> Output Class Initialized
INFO - 2024-10-02 14:21:45 --> Security Class Initialized
DEBUG - 2024-10-02 14:21:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-02 14:21:45 --> Input Class Initialized
INFO - 2024-10-02 14:21:45 --> Language Class Initialized
INFO - 2024-10-02 14:21:45 --> Language Class Initialized
INFO - 2024-10-02 14:21:45 --> Config Class Initialized
INFO - 2024-10-02 14:21:45 --> Loader Class Initialized
INFO - 2024-10-02 14:21:45 --> Helper loaded: url_helper
INFO - 2024-10-02 14:21:45 --> Helper loaded: file_helper
INFO - 2024-10-02 14:21:45 --> Helper loaded: form_helper
INFO - 2024-10-02 14:21:45 --> Helper loaded: my_helper
INFO - 2024-10-02 14:21:45 --> Database Driver Class Initialized
INFO - 2024-10-02 14:21:45 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-02 14:21:45 --> Controller Class Initialized
DEBUG - 2024-10-02 14:21:45 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pss/views/list.php
DEBUG - 2024-10-02 14:21:45 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-10-02 14:21:45 --> Final output sent to browser
DEBUG - 2024-10-02 14:21:45 --> Total execution time: 0.0533
INFO - 2024-10-02 14:21:45 --> Config Class Initialized
INFO - 2024-10-02 14:21:45 --> Hooks Class Initialized
DEBUG - 2024-10-02 14:21:45 --> UTF-8 Support Enabled
INFO - 2024-10-02 14:21:45 --> Utf8 Class Initialized
INFO - 2024-10-02 14:21:45 --> URI Class Initialized
INFO - 2024-10-02 14:21:45 --> Router Class Initialized
INFO - 2024-10-02 14:21:45 --> Output Class Initialized
INFO - 2024-10-02 14:21:45 --> Security Class Initialized
DEBUG - 2024-10-02 14:21:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-02 14:21:45 --> Input Class Initialized
INFO - 2024-10-02 14:21:45 --> Language Class Initialized
INFO - 2024-10-02 14:21:45 --> Language Class Initialized
INFO - 2024-10-02 14:21:45 --> Config Class Initialized
INFO - 2024-10-02 14:21:45 --> Loader Class Initialized
INFO - 2024-10-02 14:21:45 --> Helper loaded: url_helper
INFO - 2024-10-02 14:21:45 --> Helper loaded: file_helper
INFO - 2024-10-02 14:21:45 --> Helper loaded: form_helper
INFO - 2024-10-02 14:21:45 --> Helper loaded: my_helper
INFO - 2024-10-02 14:21:45 --> Database Driver Class Initialized
INFO - 2024-10-02 14:21:45 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-02 14:21:45 --> Controller Class Initialized
INFO - 2024-10-02 14:21:48 --> Config Class Initialized
INFO - 2024-10-02 14:21:48 --> Hooks Class Initialized
DEBUG - 2024-10-02 14:21:48 --> UTF-8 Support Enabled
INFO - 2024-10-02 14:21:48 --> Utf8 Class Initialized
INFO - 2024-10-02 14:21:48 --> URI Class Initialized
INFO - 2024-10-02 14:21:48 --> Router Class Initialized
INFO - 2024-10-02 14:21:48 --> Output Class Initialized
INFO - 2024-10-02 14:21:48 --> Security Class Initialized
DEBUG - 2024-10-02 14:21:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-02 14:21:48 --> Input Class Initialized
INFO - 2024-10-02 14:21:48 --> Language Class Initialized
INFO - 2024-10-02 14:21:48 --> Language Class Initialized
INFO - 2024-10-02 14:21:48 --> Config Class Initialized
INFO - 2024-10-02 14:21:48 --> Loader Class Initialized
INFO - 2024-10-02 14:21:48 --> Helper loaded: url_helper
INFO - 2024-10-02 14:21:48 --> Helper loaded: file_helper
INFO - 2024-10-02 14:21:48 --> Helper loaded: form_helper
INFO - 2024-10-02 14:21:48 --> Helper loaded: my_helper
INFO - 2024-10-02 14:21:48 --> Database Driver Class Initialized
INFO - 2024-10-02 14:21:48 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-02 14:21:48 --> Controller Class Initialized
INFO - 2024-10-02 14:21:48 --> Final output sent to browser
DEBUG - 2024-10-02 14:21:48 --> Total execution time: 0.0377
INFO - 2024-10-02 14:22:00 --> Config Class Initialized
INFO - 2024-10-02 14:22:00 --> Hooks Class Initialized
DEBUG - 2024-10-02 14:22:00 --> UTF-8 Support Enabled
INFO - 2024-10-02 14:22:00 --> Utf8 Class Initialized
INFO - 2024-10-02 14:22:00 --> URI Class Initialized
INFO - 2024-10-02 14:22:00 --> Router Class Initialized
INFO - 2024-10-02 14:22:00 --> Output Class Initialized
INFO - 2024-10-02 14:22:00 --> Security Class Initialized
DEBUG - 2024-10-02 14:22:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-02 14:22:00 --> Input Class Initialized
INFO - 2024-10-02 14:22:00 --> Language Class Initialized
INFO - 2024-10-02 14:22:00 --> Language Class Initialized
INFO - 2024-10-02 14:22:00 --> Config Class Initialized
INFO - 2024-10-02 14:22:00 --> Loader Class Initialized
INFO - 2024-10-02 14:22:00 --> Helper loaded: url_helper
INFO - 2024-10-02 14:22:00 --> Helper loaded: file_helper
INFO - 2024-10-02 14:22:00 --> Helper loaded: form_helper
INFO - 2024-10-02 14:22:00 --> Helper loaded: my_helper
INFO - 2024-10-02 14:22:00 --> Database Driver Class Initialized
INFO - 2024-10-02 14:22:00 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-02 14:22:00 --> Controller Class Initialized
ERROR - 2024-10-02 14:22:00 --> Severity: Notice --> Undefined index: semester /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/set_kd/controllers/Set_kd.php 104
INFO - 2024-10-02 14:22:00 --> Final output sent to browser
DEBUG - 2024-10-02 14:22:00 --> Total execution time: 0.0826
INFO - 2024-10-02 14:22:02 --> Config Class Initialized
INFO - 2024-10-02 14:22:02 --> Hooks Class Initialized
DEBUG - 2024-10-02 14:22:02 --> UTF-8 Support Enabled
INFO - 2024-10-02 14:22:02 --> Utf8 Class Initialized
INFO - 2024-10-02 14:22:02 --> URI Class Initialized
INFO - 2024-10-02 14:22:02 --> Router Class Initialized
INFO - 2024-10-02 14:22:02 --> Output Class Initialized
INFO - 2024-10-02 14:22:02 --> Security Class Initialized
DEBUG - 2024-10-02 14:22:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-02 14:22:02 --> Input Class Initialized
INFO - 2024-10-02 14:22:02 --> Language Class Initialized
INFO - 2024-10-02 14:22:02 --> Language Class Initialized
INFO - 2024-10-02 14:22:02 --> Config Class Initialized
INFO - 2024-10-02 14:22:02 --> Loader Class Initialized
INFO - 2024-10-02 14:22:02 --> Helper loaded: url_helper
INFO - 2024-10-02 14:22:02 --> Helper loaded: file_helper
INFO - 2024-10-02 14:22:02 --> Helper loaded: form_helper
INFO - 2024-10-02 14:22:02 --> Helper loaded: my_helper
INFO - 2024-10-02 14:22:02 --> Database Driver Class Initialized
INFO - 2024-10-02 14:22:02 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-02 14:22:02 --> Controller Class Initialized
DEBUG - 2024-10-02 14:22:02 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pss/views/list.php
DEBUG - 2024-10-02 14:22:02 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-10-02 14:22:02 --> Final output sent to browser
DEBUG - 2024-10-02 14:22:02 --> Total execution time: 0.0361
INFO - 2024-10-02 14:22:02 --> Config Class Initialized
INFO - 2024-10-02 14:22:02 --> Hooks Class Initialized
DEBUG - 2024-10-02 14:22:02 --> UTF-8 Support Enabled
INFO - 2024-10-02 14:22:02 --> Utf8 Class Initialized
INFO - 2024-10-02 14:22:02 --> URI Class Initialized
INFO - 2024-10-02 14:22:02 --> Router Class Initialized
INFO - 2024-10-02 14:22:02 --> Output Class Initialized
INFO - 2024-10-02 14:22:02 --> Security Class Initialized
DEBUG - 2024-10-02 14:22:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-02 14:22:02 --> Input Class Initialized
INFO - 2024-10-02 14:22:02 --> Language Class Initialized
INFO - 2024-10-02 14:22:02 --> Language Class Initialized
INFO - 2024-10-02 14:22:02 --> Config Class Initialized
INFO - 2024-10-02 14:22:02 --> Loader Class Initialized
INFO - 2024-10-02 14:22:02 --> Helper loaded: url_helper
INFO - 2024-10-02 14:22:02 --> Helper loaded: file_helper
INFO - 2024-10-02 14:22:02 --> Helper loaded: form_helper
INFO - 2024-10-02 14:22:02 --> Helper loaded: my_helper
INFO - 2024-10-02 14:22:02 --> Database Driver Class Initialized
INFO - 2024-10-02 14:22:02 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-02 14:22:02 --> Controller Class Initialized
INFO - 2024-10-02 14:22:10 --> Config Class Initialized
INFO - 2024-10-02 14:22:10 --> Hooks Class Initialized
DEBUG - 2024-10-02 14:22:10 --> UTF-8 Support Enabled
INFO - 2024-10-02 14:22:10 --> Utf8 Class Initialized
INFO - 2024-10-02 14:22:10 --> URI Class Initialized
INFO - 2024-10-02 14:22:10 --> Router Class Initialized
INFO - 2024-10-02 14:22:10 --> Output Class Initialized
INFO - 2024-10-02 14:22:10 --> Security Class Initialized
DEBUG - 2024-10-02 14:22:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-02 14:22:10 --> Input Class Initialized
INFO - 2024-10-02 14:22:10 --> Language Class Initialized
INFO - 2024-10-02 14:22:10 --> Language Class Initialized
INFO - 2024-10-02 14:22:10 --> Config Class Initialized
INFO - 2024-10-02 14:22:10 --> Loader Class Initialized
INFO - 2024-10-02 14:22:10 --> Helper loaded: url_helper
INFO - 2024-10-02 14:22:10 --> Helper loaded: file_helper
INFO - 2024-10-02 14:22:10 --> Helper loaded: form_helper
INFO - 2024-10-02 14:22:10 --> Helper loaded: my_helper
INFO - 2024-10-02 14:22:10 --> Database Driver Class Initialized
INFO - 2024-10-02 14:22:10 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-02 14:22:10 --> Controller Class Initialized
INFO - 2024-10-02 14:22:10 --> Final output sent to browser
DEBUG - 2024-10-02 14:22:10 --> Total execution time: 0.0290
INFO - 2024-10-02 14:22:16 --> Config Class Initialized
INFO - 2024-10-02 14:22:16 --> Hooks Class Initialized
DEBUG - 2024-10-02 14:22:16 --> UTF-8 Support Enabled
INFO - 2024-10-02 14:22:16 --> Utf8 Class Initialized
INFO - 2024-10-02 14:22:16 --> URI Class Initialized
INFO - 2024-10-02 14:22:16 --> Router Class Initialized
INFO - 2024-10-02 14:22:16 --> Output Class Initialized
INFO - 2024-10-02 14:22:16 --> Security Class Initialized
DEBUG - 2024-10-02 14:22:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-02 14:22:16 --> Input Class Initialized
INFO - 2024-10-02 14:22:16 --> Language Class Initialized
INFO - 2024-10-02 14:22:16 --> Language Class Initialized
INFO - 2024-10-02 14:22:16 --> Config Class Initialized
INFO - 2024-10-02 14:22:16 --> Loader Class Initialized
INFO - 2024-10-02 14:22:16 --> Helper loaded: url_helper
INFO - 2024-10-02 14:22:16 --> Helper loaded: file_helper
INFO - 2024-10-02 14:22:16 --> Helper loaded: form_helper
INFO - 2024-10-02 14:22:16 --> Helper loaded: my_helper
INFO - 2024-10-02 14:22:16 --> Database Driver Class Initialized
INFO - 2024-10-02 14:22:16 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-02 14:22:16 --> Controller Class Initialized
ERROR - 2024-10-02 14:22:16 --> Severity: Notice --> Undefined index: semester /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/set_kd/controllers/Set_kd.php 104
INFO - 2024-10-02 14:22:16 --> Final output sent to browser
DEBUG - 2024-10-02 14:22:16 --> Total execution time: 0.0615
INFO - 2024-10-02 14:22:18 --> Config Class Initialized
INFO - 2024-10-02 14:22:18 --> Hooks Class Initialized
DEBUG - 2024-10-02 14:22:18 --> UTF-8 Support Enabled
INFO - 2024-10-02 14:22:18 --> Utf8 Class Initialized
INFO - 2024-10-02 14:22:18 --> URI Class Initialized
INFO - 2024-10-02 14:22:18 --> Router Class Initialized
INFO - 2024-10-02 14:22:18 --> Output Class Initialized
INFO - 2024-10-02 14:22:18 --> Security Class Initialized
DEBUG - 2024-10-02 14:22:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-02 14:22:18 --> Input Class Initialized
INFO - 2024-10-02 14:22:18 --> Language Class Initialized
INFO - 2024-10-02 14:22:18 --> Language Class Initialized
INFO - 2024-10-02 14:22:18 --> Config Class Initialized
INFO - 2024-10-02 14:22:18 --> Loader Class Initialized
INFO - 2024-10-02 14:22:18 --> Helper loaded: url_helper
INFO - 2024-10-02 14:22:18 --> Helper loaded: file_helper
INFO - 2024-10-02 14:22:18 --> Helper loaded: form_helper
INFO - 2024-10-02 14:22:18 --> Helper loaded: my_helper
INFO - 2024-10-02 14:22:18 --> Database Driver Class Initialized
INFO - 2024-10-02 14:22:18 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-02 14:22:18 --> Controller Class Initialized
DEBUG - 2024-10-02 14:22:18 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pss/views/list.php
DEBUG - 2024-10-02 14:22:18 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-10-02 14:22:18 --> Final output sent to browser
DEBUG - 2024-10-02 14:22:18 --> Total execution time: 0.0330
INFO - 2024-10-02 14:22:18 --> Config Class Initialized
INFO - 2024-10-02 14:22:18 --> Hooks Class Initialized
DEBUG - 2024-10-02 14:22:18 --> UTF-8 Support Enabled
INFO - 2024-10-02 14:22:18 --> Utf8 Class Initialized
INFO - 2024-10-02 14:22:18 --> URI Class Initialized
INFO - 2024-10-02 14:22:18 --> Router Class Initialized
INFO - 2024-10-02 14:22:18 --> Output Class Initialized
INFO - 2024-10-02 14:22:18 --> Security Class Initialized
DEBUG - 2024-10-02 14:22:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-02 14:22:18 --> Input Class Initialized
INFO - 2024-10-02 14:22:18 --> Language Class Initialized
INFO - 2024-10-02 14:22:18 --> Language Class Initialized
INFO - 2024-10-02 14:22:18 --> Config Class Initialized
INFO - 2024-10-02 14:22:18 --> Loader Class Initialized
INFO - 2024-10-02 14:22:18 --> Helper loaded: url_helper
INFO - 2024-10-02 14:22:18 --> Helper loaded: file_helper
INFO - 2024-10-02 14:22:18 --> Helper loaded: form_helper
INFO - 2024-10-02 14:22:18 --> Helper loaded: my_helper
INFO - 2024-10-02 14:22:18 --> Database Driver Class Initialized
INFO - 2024-10-02 14:22:18 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-02 14:22:18 --> Controller Class Initialized
INFO - 2024-10-02 14:22:25 --> Config Class Initialized
INFO - 2024-10-02 14:22:25 --> Hooks Class Initialized
DEBUG - 2024-10-02 14:22:25 --> UTF-8 Support Enabled
INFO - 2024-10-02 14:22:25 --> Utf8 Class Initialized
INFO - 2024-10-02 14:22:25 --> URI Class Initialized
INFO - 2024-10-02 14:22:25 --> Router Class Initialized
INFO - 2024-10-02 14:22:25 --> Output Class Initialized
INFO - 2024-10-02 14:22:25 --> Security Class Initialized
DEBUG - 2024-10-02 14:22:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-02 14:22:25 --> Input Class Initialized
INFO - 2024-10-02 14:22:25 --> Language Class Initialized
INFO - 2024-10-02 14:22:25 --> Language Class Initialized
INFO - 2024-10-02 14:22:25 --> Config Class Initialized
INFO - 2024-10-02 14:22:25 --> Loader Class Initialized
INFO - 2024-10-02 14:22:25 --> Helper loaded: url_helper
INFO - 2024-10-02 14:22:25 --> Helper loaded: file_helper
INFO - 2024-10-02 14:22:25 --> Helper loaded: form_helper
INFO - 2024-10-02 14:22:25 --> Helper loaded: my_helper
INFO - 2024-10-02 14:22:25 --> Database Driver Class Initialized
INFO - 2024-10-02 14:22:25 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-02 14:22:25 --> Controller Class Initialized
INFO - 2024-10-02 14:22:25 --> Final output sent to browser
DEBUG - 2024-10-02 14:22:25 --> Total execution time: 0.0696
INFO - 2024-10-02 14:22:36 --> Config Class Initialized
INFO - 2024-10-02 14:22:36 --> Hooks Class Initialized
DEBUG - 2024-10-02 14:22:36 --> UTF-8 Support Enabled
INFO - 2024-10-02 14:22:36 --> Utf8 Class Initialized
INFO - 2024-10-02 14:22:36 --> URI Class Initialized
INFO - 2024-10-02 14:22:36 --> Router Class Initialized
INFO - 2024-10-02 14:22:36 --> Output Class Initialized
INFO - 2024-10-02 14:22:36 --> Security Class Initialized
DEBUG - 2024-10-02 14:22:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-02 14:22:36 --> Input Class Initialized
INFO - 2024-10-02 14:22:36 --> Language Class Initialized
INFO - 2024-10-02 14:22:36 --> Language Class Initialized
INFO - 2024-10-02 14:22:36 --> Config Class Initialized
INFO - 2024-10-02 14:22:36 --> Loader Class Initialized
INFO - 2024-10-02 14:22:36 --> Helper loaded: url_helper
INFO - 2024-10-02 14:22:36 --> Helper loaded: file_helper
INFO - 2024-10-02 14:22:36 --> Helper loaded: form_helper
INFO - 2024-10-02 14:22:36 --> Helper loaded: my_helper
INFO - 2024-10-02 14:22:36 --> Database Driver Class Initialized
INFO - 2024-10-02 14:22:36 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-02 14:22:36 --> Controller Class Initialized
ERROR - 2024-10-02 14:22:36 --> Severity: Notice --> Undefined index: semester /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/set_kd/controllers/Set_kd.php 104
INFO - 2024-10-02 14:22:36 --> Final output sent to browser
DEBUG - 2024-10-02 14:22:36 --> Total execution time: 0.0311
INFO - 2024-10-02 14:22:38 --> Config Class Initialized
INFO - 2024-10-02 14:22:38 --> Hooks Class Initialized
DEBUG - 2024-10-02 14:22:38 --> UTF-8 Support Enabled
INFO - 2024-10-02 14:22:38 --> Utf8 Class Initialized
INFO - 2024-10-02 14:22:38 --> URI Class Initialized
INFO - 2024-10-02 14:22:38 --> Router Class Initialized
INFO - 2024-10-02 14:22:38 --> Output Class Initialized
INFO - 2024-10-02 14:22:38 --> Security Class Initialized
DEBUG - 2024-10-02 14:22:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-02 14:22:38 --> Input Class Initialized
INFO - 2024-10-02 14:22:38 --> Language Class Initialized
INFO - 2024-10-02 14:22:38 --> Language Class Initialized
INFO - 2024-10-02 14:22:38 --> Config Class Initialized
INFO - 2024-10-02 14:22:38 --> Loader Class Initialized
INFO - 2024-10-02 14:22:38 --> Helper loaded: url_helper
INFO - 2024-10-02 14:22:38 --> Helper loaded: file_helper
INFO - 2024-10-02 14:22:38 --> Helper loaded: form_helper
INFO - 2024-10-02 14:22:38 --> Helper loaded: my_helper
INFO - 2024-10-02 14:22:38 --> Database Driver Class Initialized
INFO - 2024-10-02 14:22:38 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-02 14:22:38 --> Controller Class Initialized
DEBUG - 2024-10-02 14:22:38 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pss/views/list.php
DEBUG - 2024-10-02 14:22:38 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-10-02 14:22:38 --> Final output sent to browser
DEBUG - 2024-10-02 14:22:38 --> Total execution time: 0.0371
INFO - 2024-10-02 14:22:38 --> Config Class Initialized
INFO - 2024-10-02 14:22:38 --> Hooks Class Initialized
DEBUG - 2024-10-02 14:22:38 --> UTF-8 Support Enabled
INFO - 2024-10-02 14:22:38 --> Utf8 Class Initialized
INFO - 2024-10-02 14:22:38 --> URI Class Initialized
INFO - 2024-10-02 14:22:38 --> Router Class Initialized
INFO - 2024-10-02 14:22:38 --> Output Class Initialized
INFO - 2024-10-02 14:22:38 --> Security Class Initialized
DEBUG - 2024-10-02 14:22:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-02 14:22:38 --> Input Class Initialized
INFO - 2024-10-02 14:22:38 --> Language Class Initialized
INFO - 2024-10-02 14:22:38 --> Language Class Initialized
INFO - 2024-10-02 14:22:38 --> Config Class Initialized
INFO - 2024-10-02 14:22:38 --> Loader Class Initialized
INFO - 2024-10-02 14:22:38 --> Helper loaded: url_helper
INFO - 2024-10-02 14:22:38 --> Helper loaded: file_helper
INFO - 2024-10-02 14:22:38 --> Helper loaded: form_helper
INFO - 2024-10-02 14:22:38 --> Helper loaded: my_helper
INFO - 2024-10-02 14:22:38 --> Database Driver Class Initialized
INFO - 2024-10-02 14:22:38 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-02 14:22:38 --> Controller Class Initialized
INFO - 2024-10-02 14:22:49 --> Config Class Initialized
INFO - 2024-10-02 14:22:49 --> Hooks Class Initialized
DEBUG - 2024-10-02 14:22:49 --> UTF-8 Support Enabled
INFO - 2024-10-02 14:22:49 --> Utf8 Class Initialized
INFO - 2024-10-02 14:22:49 --> URI Class Initialized
INFO - 2024-10-02 14:22:49 --> Router Class Initialized
INFO - 2024-10-02 14:22:49 --> Output Class Initialized
INFO - 2024-10-02 14:22:49 --> Security Class Initialized
DEBUG - 2024-10-02 14:22:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-02 14:22:49 --> Input Class Initialized
INFO - 2024-10-02 14:22:49 --> Language Class Initialized
INFO - 2024-10-02 14:22:49 --> Language Class Initialized
INFO - 2024-10-02 14:22:49 --> Config Class Initialized
INFO - 2024-10-02 14:22:49 --> Loader Class Initialized
INFO - 2024-10-02 14:22:49 --> Helper loaded: url_helper
INFO - 2024-10-02 14:22:49 --> Helper loaded: file_helper
INFO - 2024-10-02 14:22:49 --> Helper loaded: form_helper
INFO - 2024-10-02 14:22:49 --> Helper loaded: my_helper
INFO - 2024-10-02 14:22:49 --> Database Driver Class Initialized
INFO - 2024-10-02 14:22:49 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-02 14:22:49 --> Controller Class Initialized
DEBUG - 2024-10-02 14:22:49 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/view_mapel/views/v_view_mapel.php
DEBUG - 2024-10-02 14:22:49 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-10-02 14:22:49 --> Final output sent to browser
DEBUG - 2024-10-02 14:22:49 --> Total execution time: 0.0312
INFO - 2024-10-02 14:22:53 --> Config Class Initialized
INFO - 2024-10-02 14:22:53 --> Hooks Class Initialized
DEBUG - 2024-10-02 14:22:53 --> UTF-8 Support Enabled
INFO - 2024-10-02 14:22:53 --> Utf8 Class Initialized
INFO - 2024-10-02 14:22:53 --> URI Class Initialized
INFO - 2024-10-02 14:22:53 --> Router Class Initialized
INFO - 2024-10-02 14:22:53 --> Output Class Initialized
INFO - 2024-10-02 14:22:53 --> Security Class Initialized
DEBUG - 2024-10-02 14:22:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-02 14:22:53 --> Input Class Initialized
INFO - 2024-10-02 14:22:53 --> Language Class Initialized
INFO - 2024-10-02 14:22:53 --> Language Class Initialized
INFO - 2024-10-02 14:22:53 --> Config Class Initialized
INFO - 2024-10-02 14:22:53 --> Loader Class Initialized
INFO - 2024-10-02 14:22:53 --> Helper loaded: url_helper
INFO - 2024-10-02 14:22:53 --> Helper loaded: file_helper
INFO - 2024-10-02 14:22:53 --> Helper loaded: form_helper
INFO - 2024-10-02 14:22:53 --> Helper loaded: my_helper
INFO - 2024-10-02 14:22:53 --> Database Driver Class Initialized
INFO - 2024-10-02 14:22:53 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-02 14:22:53 --> Controller Class Initialized
DEBUG - 2024-10-02 14:22:53 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_la/views/list.php
DEBUG - 2024-10-02 14:22:53 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-10-02 14:22:53 --> Final output sent to browser
DEBUG - 2024-10-02 14:22:53 --> Total execution time: 0.0938
INFO - 2024-10-02 14:22:53 --> Config Class Initialized
INFO - 2024-10-02 14:22:53 --> Hooks Class Initialized
DEBUG - 2024-10-02 14:22:53 --> UTF-8 Support Enabled
INFO - 2024-10-02 14:22:53 --> Utf8 Class Initialized
INFO - 2024-10-02 14:22:53 --> URI Class Initialized
INFO - 2024-10-02 14:22:53 --> Router Class Initialized
INFO - 2024-10-02 14:22:53 --> Output Class Initialized
INFO - 2024-10-02 14:22:53 --> Security Class Initialized
DEBUG - 2024-10-02 14:22:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-02 14:22:53 --> Input Class Initialized
INFO - 2024-10-02 14:22:53 --> Language Class Initialized
INFO - 2024-10-02 14:22:53 --> Language Class Initialized
INFO - 2024-10-02 14:22:53 --> Config Class Initialized
INFO - 2024-10-02 14:22:53 --> Loader Class Initialized
INFO - 2024-10-02 14:22:53 --> Helper loaded: url_helper
INFO - 2024-10-02 14:22:53 --> Helper loaded: file_helper
INFO - 2024-10-02 14:22:53 --> Helper loaded: form_helper
INFO - 2024-10-02 14:22:53 --> Helper loaded: my_helper
INFO - 2024-10-02 14:22:53 --> Database Driver Class Initialized
INFO - 2024-10-02 14:22:53 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-02 14:22:53 --> Controller Class Initialized
INFO - 2024-10-02 14:22:55 --> Config Class Initialized
INFO - 2024-10-02 14:22:55 --> Hooks Class Initialized
DEBUG - 2024-10-02 14:22:55 --> UTF-8 Support Enabled
INFO - 2024-10-02 14:22:55 --> Utf8 Class Initialized
INFO - 2024-10-02 14:22:55 --> URI Class Initialized
INFO - 2024-10-02 14:22:55 --> Router Class Initialized
INFO - 2024-10-02 14:22:55 --> Output Class Initialized
INFO - 2024-10-02 14:22:55 --> Security Class Initialized
DEBUG - 2024-10-02 14:22:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-02 14:22:55 --> Input Class Initialized
INFO - 2024-10-02 14:22:55 --> Language Class Initialized
INFO - 2024-10-02 14:22:55 --> Language Class Initialized
INFO - 2024-10-02 14:22:55 --> Config Class Initialized
INFO - 2024-10-02 14:22:55 --> Loader Class Initialized
INFO - 2024-10-02 14:22:55 --> Helper loaded: url_helper
INFO - 2024-10-02 14:22:55 --> Helper loaded: file_helper
INFO - 2024-10-02 14:22:55 --> Helper loaded: form_helper
INFO - 2024-10-02 14:22:55 --> Helper loaded: my_helper
INFO - 2024-10-02 14:22:55 --> Database Driver Class Initialized
INFO - 2024-10-02 14:22:55 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-02 14:22:55 --> Controller Class Initialized
INFO - 2024-10-02 14:22:55 --> Final output sent to browser
DEBUG - 2024-10-02 14:22:55 --> Total execution time: 0.0556
INFO - 2024-10-02 14:22:59 --> Config Class Initialized
INFO - 2024-10-02 14:22:59 --> Hooks Class Initialized
DEBUG - 2024-10-02 14:22:59 --> UTF-8 Support Enabled
INFO - 2024-10-02 14:22:59 --> Utf8 Class Initialized
INFO - 2024-10-02 14:22:59 --> URI Class Initialized
INFO - 2024-10-02 14:22:59 --> Router Class Initialized
INFO - 2024-10-02 14:22:59 --> Output Class Initialized
INFO - 2024-10-02 14:22:59 --> Security Class Initialized
DEBUG - 2024-10-02 14:22:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-02 14:22:59 --> Input Class Initialized
INFO - 2024-10-02 14:22:59 --> Language Class Initialized
INFO - 2024-10-02 14:22:59 --> Language Class Initialized
INFO - 2024-10-02 14:22:59 --> Config Class Initialized
INFO - 2024-10-02 14:22:59 --> Loader Class Initialized
INFO - 2024-10-02 14:22:59 --> Helper loaded: url_helper
INFO - 2024-10-02 14:22:59 --> Helper loaded: file_helper
INFO - 2024-10-02 14:22:59 --> Helper loaded: form_helper
INFO - 2024-10-02 14:22:59 --> Helper loaded: my_helper
INFO - 2024-10-02 14:22:59 --> Database Driver Class Initialized
INFO - 2024-10-02 14:22:59 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-02 14:22:59 --> Controller Class Initialized
ERROR - 2024-10-02 14:22:59 --> Severity: Notice --> Undefined index: semester /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/set_kd/controllers/Set_kd.php 104
INFO - 2024-10-02 14:22:59 --> Final output sent to browser
DEBUG - 2024-10-02 14:22:59 --> Total execution time: 0.0317
INFO - 2024-10-02 14:25:32 --> Config Class Initialized
INFO - 2024-10-02 14:25:32 --> Hooks Class Initialized
DEBUG - 2024-10-02 14:25:32 --> UTF-8 Support Enabled
INFO - 2024-10-02 14:25:32 --> Utf8 Class Initialized
INFO - 2024-10-02 14:25:32 --> URI Class Initialized
INFO - 2024-10-02 14:25:32 --> Router Class Initialized
INFO - 2024-10-02 14:25:32 --> Output Class Initialized
INFO - 2024-10-02 14:25:32 --> Security Class Initialized
DEBUG - 2024-10-02 14:25:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-02 14:25:32 --> Input Class Initialized
INFO - 2024-10-02 14:25:32 --> Language Class Initialized
INFO - 2024-10-02 14:25:32 --> Language Class Initialized
INFO - 2024-10-02 14:25:32 --> Config Class Initialized
INFO - 2024-10-02 14:25:32 --> Loader Class Initialized
INFO - 2024-10-02 14:25:32 --> Helper loaded: url_helper
INFO - 2024-10-02 14:25:32 --> Helper loaded: file_helper
INFO - 2024-10-02 14:25:32 --> Helper loaded: form_helper
INFO - 2024-10-02 14:25:32 --> Helper loaded: my_helper
INFO - 2024-10-02 14:25:32 --> Database Driver Class Initialized
INFO - 2024-10-02 14:25:32 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-02 14:25:32 --> Controller Class Initialized
DEBUG - 2024-10-02 14:25:32 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_la/views/list.php
DEBUG - 2024-10-02 14:25:32 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-10-02 14:25:32 --> Final output sent to browser
DEBUG - 2024-10-02 14:25:32 --> Total execution time: 0.0361
INFO - 2024-10-02 14:25:33 --> Config Class Initialized
INFO - 2024-10-02 14:25:33 --> Hooks Class Initialized
DEBUG - 2024-10-02 14:25:33 --> UTF-8 Support Enabled
INFO - 2024-10-02 14:25:33 --> Utf8 Class Initialized
INFO - 2024-10-02 14:25:33 --> URI Class Initialized
INFO - 2024-10-02 14:25:33 --> Router Class Initialized
INFO - 2024-10-02 14:25:33 --> Output Class Initialized
INFO - 2024-10-02 14:25:33 --> Security Class Initialized
DEBUG - 2024-10-02 14:25:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-02 14:25:33 --> Input Class Initialized
INFO - 2024-10-02 14:25:33 --> Language Class Initialized
INFO - 2024-10-02 14:25:33 --> Language Class Initialized
INFO - 2024-10-02 14:25:33 --> Config Class Initialized
INFO - 2024-10-02 14:25:33 --> Loader Class Initialized
INFO - 2024-10-02 14:25:33 --> Helper loaded: url_helper
INFO - 2024-10-02 14:25:33 --> Helper loaded: file_helper
INFO - 2024-10-02 14:25:33 --> Helper loaded: form_helper
INFO - 2024-10-02 14:25:33 --> Helper loaded: my_helper
INFO - 2024-10-02 14:25:33 --> Database Driver Class Initialized
INFO - 2024-10-02 14:25:33 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-02 14:25:33 --> Controller Class Initialized
INFO - 2024-10-02 14:25:34 --> Config Class Initialized
INFO - 2024-10-02 14:25:34 --> Hooks Class Initialized
DEBUG - 2024-10-02 14:25:34 --> UTF-8 Support Enabled
INFO - 2024-10-02 14:25:34 --> Utf8 Class Initialized
INFO - 2024-10-02 14:25:34 --> URI Class Initialized
INFO - 2024-10-02 14:25:34 --> Router Class Initialized
INFO - 2024-10-02 14:25:34 --> Output Class Initialized
INFO - 2024-10-02 14:25:34 --> Security Class Initialized
DEBUG - 2024-10-02 14:25:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-02 14:25:34 --> Input Class Initialized
INFO - 2024-10-02 14:25:34 --> Language Class Initialized
INFO - 2024-10-02 14:25:34 --> Language Class Initialized
INFO - 2024-10-02 14:25:34 --> Config Class Initialized
INFO - 2024-10-02 14:25:34 --> Loader Class Initialized
INFO - 2024-10-02 14:25:34 --> Helper loaded: url_helper
INFO - 2024-10-02 14:25:34 --> Helper loaded: file_helper
INFO - 2024-10-02 14:25:34 --> Helper loaded: form_helper
INFO - 2024-10-02 14:25:34 --> Helper loaded: my_helper
INFO - 2024-10-02 14:25:34 --> Database Driver Class Initialized
INFO - 2024-10-02 14:25:34 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-02 14:25:34 --> Controller Class Initialized
INFO - 2024-10-02 14:25:34 --> Final output sent to browser
DEBUG - 2024-10-02 14:25:34 --> Total execution time: 0.0362
INFO - 2024-10-02 14:25:45 --> Config Class Initialized
INFO - 2024-10-02 14:25:45 --> Hooks Class Initialized
DEBUG - 2024-10-02 14:25:45 --> UTF-8 Support Enabled
INFO - 2024-10-02 14:25:45 --> Utf8 Class Initialized
INFO - 2024-10-02 14:25:45 --> URI Class Initialized
INFO - 2024-10-02 14:25:45 --> Router Class Initialized
INFO - 2024-10-02 14:25:45 --> Output Class Initialized
INFO - 2024-10-02 14:25:45 --> Security Class Initialized
DEBUG - 2024-10-02 14:25:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-02 14:25:45 --> Input Class Initialized
INFO - 2024-10-02 14:25:45 --> Language Class Initialized
INFO - 2024-10-02 14:25:45 --> Language Class Initialized
INFO - 2024-10-02 14:25:45 --> Config Class Initialized
INFO - 2024-10-02 14:25:45 --> Loader Class Initialized
INFO - 2024-10-02 14:25:45 --> Helper loaded: url_helper
INFO - 2024-10-02 14:25:45 --> Helper loaded: file_helper
INFO - 2024-10-02 14:25:45 --> Helper loaded: form_helper
INFO - 2024-10-02 14:25:45 --> Helper loaded: my_helper
INFO - 2024-10-02 14:25:45 --> Database Driver Class Initialized
INFO - 2024-10-02 14:25:45 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-02 14:25:45 --> Controller Class Initialized
ERROR - 2024-10-02 14:25:45 --> Severity: Notice --> Undefined index: semester /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/set_kd/controllers/Set_kd.php 104
INFO - 2024-10-02 14:25:45 --> Final output sent to browser
DEBUG - 2024-10-02 14:25:45 --> Total execution time: 0.0379
INFO - 2024-10-02 14:26:22 --> Config Class Initialized
INFO - 2024-10-02 14:26:22 --> Hooks Class Initialized
DEBUG - 2024-10-02 14:26:22 --> UTF-8 Support Enabled
INFO - 2024-10-02 14:26:22 --> Utf8 Class Initialized
INFO - 2024-10-02 14:26:22 --> URI Class Initialized
INFO - 2024-10-02 14:26:22 --> Router Class Initialized
INFO - 2024-10-02 14:26:22 --> Output Class Initialized
INFO - 2024-10-02 14:26:22 --> Security Class Initialized
DEBUG - 2024-10-02 14:26:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-02 14:26:22 --> Input Class Initialized
INFO - 2024-10-02 14:26:22 --> Language Class Initialized
INFO - 2024-10-02 14:26:22 --> Language Class Initialized
INFO - 2024-10-02 14:26:22 --> Config Class Initialized
INFO - 2024-10-02 14:26:22 --> Loader Class Initialized
INFO - 2024-10-02 14:26:22 --> Helper loaded: url_helper
INFO - 2024-10-02 14:26:22 --> Helper loaded: file_helper
INFO - 2024-10-02 14:26:22 --> Helper loaded: form_helper
INFO - 2024-10-02 14:26:22 --> Helper loaded: my_helper
INFO - 2024-10-02 14:26:22 --> Database Driver Class Initialized
INFO - 2024-10-02 14:26:23 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-02 14:26:23 --> Controller Class Initialized
DEBUG - 2024-10-02 14:26:23 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/views/form.php
DEBUG - 2024-10-02 14:26:23 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-10-02 14:26:23 --> Final output sent to browser
DEBUG - 2024-10-02 14:26:23 --> Total execution time: 0.1323
INFO - 2024-10-02 14:26:30 --> Config Class Initialized
INFO - 2024-10-02 14:26:30 --> Hooks Class Initialized
DEBUG - 2024-10-02 14:26:30 --> UTF-8 Support Enabled
INFO - 2024-10-02 14:26:30 --> Utf8 Class Initialized
INFO - 2024-10-02 14:26:30 --> URI Class Initialized
INFO - 2024-10-02 14:26:30 --> Router Class Initialized
INFO - 2024-10-02 14:26:30 --> Output Class Initialized
INFO - 2024-10-02 14:26:30 --> Security Class Initialized
DEBUG - 2024-10-02 14:26:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-02 14:26:30 --> Input Class Initialized
INFO - 2024-10-02 14:26:30 --> Language Class Initialized
INFO - 2024-10-02 14:26:30 --> Language Class Initialized
INFO - 2024-10-02 14:26:30 --> Config Class Initialized
INFO - 2024-10-02 14:26:30 --> Loader Class Initialized
INFO - 2024-10-02 14:26:30 --> Helper loaded: url_helper
INFO - 2024-10-02 14:26:30 --> Helper loaded: file_helper
INFO - 2024-10-02 14:26:30 --> Helper loaded: form_helper
INFO - 2024-10-02 14:26:30 --> Helper loaded: my_helper
INFO - 2024-10-02 14:26:30 --> Database Driver Class Initialized
INFO - 2024-10-02 14:26:30 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-02 14:26:30 --> Controller Class Initialized
INFO - 2024-10-02 14:26:30 --> Config Class Initialized
INFO - 2024-10-02 14:26:30 --> Hooks Class Initialized
DEBUG - 2024-10-02 14:26:30 --> UTF-8 Support Enabled
INFO - 2024-10-02 14:26:30 --> Utf8 Class Initialized
INFO - 2024-10-02 14:26:30 --> URI Class Initialized
INFO - 2024-10-02 14:26:30 --> Router Class Initialized
INFO - 2024-10-02 14:26:30 --> Output Class Initialized
INFO - 2024-10-02 14:26:30 --> Security Class Initialized
DEBUG - 2024-10-02 14:26:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-02 14:26:30 --> Input Class Initialized
INFO - 2024-10-02 14:26:30 --> Language Class Initialized
INFO - 2024-10-02 14:26:30 --> Language Class Initialized
INFO - 2024-10-02 14:26:30 --> Config Class Initialized
INFO - 2024-10-02 14:26:30 --> Loader Class Initialized
INFO - 2024-10-02 14:26:30 --> Helper loaded: url_helper
INFO - 2024-10-02 14:26:30 --> Helper loaded: file_helper
INFO - 2024-10-02 14:26:30 --> Helper loaded: form_helper
INFO - 2024-10-02 14:26:30 --> Helper loaded: my_helper
INFO - 2024-10-02 14:26:30 --> Database Driver Class Initialized
INFO - 2024-10-02 14:26:30 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-02 14:26:30 --> Controller Class Initialized
DEBUG - 2024-10-02 14:26:30 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/views/list.php
DEBUG - 2024-10-02 14:26:30 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-10-02 14:26:30 --> Final output sent to browser
DEBUG - 2024-10-02 14:26:30 --> Total execution time: 0.0356
INFO - 2024-10-02 14:26:30 --> Config Class Initialized
INFO - 2024-10-02 14:26:30 --> Hooks Class Initialized
DEBUG - 2024-10-02 14:26:30 --> UTF-8 Support Enabled
INFO - 2024-10-02 14:26:30 --> Utf8 Class Initialized
INFO - 2024-10-02 14:26:30 --> URI Class Initialized
INFO - 2024-10-02 14:26:30 --> Router Class Initialized
INFO - 2024-10-02 14:26:30 --> Output Class Initialized
INFO - 2024-10-02 14:26:30 --> Security Class Initialized
DEBUG - 2024-10-02 14:26:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-02 14:26:30 --> Input Class Initialized
INFO - 2024-10-02 14:26:30 --> Language Class Initialized
INFO - 2024-10-02 14:26:30 --> Language Class Initialized
INFO - 2024-10-02 14:26:30 --> Config Class Initialized
INFO - 2024-10-02 14:26:30 --> Loader Class Initialized
INFO - 2024-10-02 14:26:30 --> Helper loaded: url_helper
INFO - 2024-10-02 14:26:30 --> Helper loaded: file_helper
INFO - 2024-10-02 14:26:30 --> Helper loaded: form_helper
INFO - 2024-10-02 14:26:30 --> Helper loaded: my_helper
INFO - 2024-10-02 14:26:30 --> Database Driver Class Initialized
INFO - 2024-10-02 14:26:30 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-02 14:26:30 --> Controller Class Initialized
INFO - 2024-10-02 14:26:33 --> Config Class Initialized
INFO - 2024-10-02 14:26:33 --> Hooks Class Initialized
DEBUG - 2024-10-02 14:26:33 --> UTF-8 Support Enabled
INFO - 2024-10-02 14:26:33 --> Utf8 Class Initialized
INFO - 2024-10-02 14:26:33 --> URI Class Initialized
INFO - 2024-10-02 14:26:33 --> Router Class Initialized
INFO - 2024-10-02 14:26:33 --> Output Class Initialized
INFO - 2024-10-02 14:26:33 --> Security Class Initialized
DEBUG - 2024-10-02 14:26:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-02 14:26:33 --> Input Class Initialized
INFO - 2024-10-02 14:26:33 --> Language Class Initialized
INFO - 2024-10-02 14:26:33 --> Language Class Initialized
INFO - 2024-10-02 14:26:33 --> Config Class Initialized
INFO - 2024-10-02 14:26:33 --> Loader Class Initialized
INFO - 2024-10-02 14:26:33 --> Helper loaded: url_helper
INFO - 2024-10-02 14:26:33 --> Helper loaded: file_helper
INFO - 2024-10-02 14:26:33 --> Helper loaded: form_helper
INFO - 2024-10-02 14:26:33 --> Helper loaded: my_helper
INFO - 2024-10-02 14:26:33 --> Database Driver Class Initialized
INFO - 2024-10-02 14:26:33 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-02 14:26:33 --> Controller Class Initialized
INFO - 2024-10-02 14:26:33 --> Final output sent to browser
DEBUG - 2024-10-02 14:26:33 --> Total execution time: 0.0376
INFO - 2024-10-02 14:26:36 --> Config Class Initialized
INFO - 2024-10-02 14:26:36 --> Hooks Class Initialized
DEBUG - 2024-10-02 14:26:36 --> UTF-8 Support Enabled
INFO - 2024-10-02 14:26:36 --> Utf8 Class Initialized
INFO - 2024-10-02 14:26:36 --> URI Class Initialized
INFO - 2024-10-02 14:26:36 --> Router Class Initialized
INFO - 2024-10-02 14:26:36 --> Output Class Initialized
INFO - 2024-10-02 14:26:36 --> Security Class Initialized
DEBUG - 2024-10-02 14:26:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-02 14:26:36 --> Input Class Initialized
INFO - 2024-10-02 14:26:36 --> Language Class Initialized
INFO - 2024-10-02 14:26:36 --> Language Class Initialized
INFO - 2024-10-02 14:26:36 --> Config Class Initialized
INFO - 2024-10-02 14:26:36 --> Loader Class Initialized
INFO - 2024-10-02 14:26:36 --> Helper loaded: url_helper
INFO - 2024-10-02 14:26:36 --> Helper loaded: file_helper
INFO - 2024-10-02 14:26:36 --> Helper loaded: form_helper
INFO - 2024-10-02 14:26:36 --> Helper loaded: my_helper
INFO - 2024-10-02 14:26:36 --> Database Driver Class Initialized
INFO - 2024-10-02 14:26:36 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-02 14:26:36 --> Controller Class Initialized
INFO - 2024-10-02 14:26:36 --> Final output sent to browser
DEBUG - 2024-10-02 14:26:36 --> Total execution time: 0.0422
INFO - 2024-10-02 14:26:42 --> Config Class Initialized
INFO - 2024-10-02 14:26:42 --> Hooks Class Initialized
DEBUG - 2024-10-02 14:26:42 --> UTF-8 Support Enabled
INFO - 2024-10-02 14:26:42 --> Utf8 Class Initialized
INFO - 2024-10-02 14:26:42 --> URI Class Initialized
INFO - 2024-10-02 14:26:42 --> Router Class Initialized
INFO - 2024-10-02 14:26:42 --> Output Class Initialized
INFO - 2024-10-02 14:26:42 --> Security Class Initialized
DEBUG - 2024-10-02 14:26:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-02 14:26:42 --> Input Class Initialized
INFO - 2024-10-02 14:26:42 --> Language Class Initialized
INFO - 2024-10-02 14:26:42 --> Language Class Initialized
INFO - 2024-10-02 14:26:42 --> Config Class Initialized
INFO - 2024-10-02 14:26:42 --> Loader Class Initialized
INFO - 2024-10-02 14:26:42 --> Helper loaded: url_helper
INFO - 2024-10-02 14:26:42 --> Helper loaded: file_helper
INFO - 2024-10-02 14:26:42 --> Helper loaded: form_helper
INFO - 2024-10-02 14:26:42 --> Helper loaded: my_helper
INFO - 2024-10-02 14:26:42 --> Database Driver Class Initialized
INFO - 2024-10-02 14:26:42 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-02 14:26:42 --> Controller Class Initialized
DEBUG - 2024-10-02 14:26:42 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/views/cetak.php
INFO - 2024-10-02 14:26:42 --> Final output sent to browser
DEBUG - 2024-10-02 14:26:42 --> Total execution time: 0.2288
INFO - 2024-10-02 14:27:15 --> Config Class Initialized
INFO - 2024-10-02 14:27:15 --> Hooks Class Initialized
DEBUG - 2024-10-02 14:27:15 --> UTF-8 Support Enabled
INFO - 2024-10-02 14:27:15 --> Utf8 Class Initialized
INFO - 2024-10-02 14:27:15 --> URI Class Initialized
INFO - 2024-10-02 14:27:15 --> Router Class Initialized
INFO - 2024-10-02 14:27:15 --> Output Class Initialized
INFO - 2024-10-02 14:27:15 --> Security Class Initialized
DEBUG - 2024-10-02 14:27:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-02 14:27:15 --> Input Class Initialized
INFO - 2024-10-02 14:27:15 --> Language Class Initialized
INFO - 2024-10-02 14:27:15 --> Language Class Initialized
INFO - 2024-10-02 14:27:15 --> Config Class Initialized
INFO - 2024-10-02 14:27:15 --> Loader Class Initialized
INFO - 2024-10-02 14:27:15 --> Helper loaded: url_helper
INFO - 2024-10-02 14:27:15 --> Helper loaded: file_helper
INFO - 2024-10-02 14:27:15 --> Helper loaded: form_helper
INFO - 2024-10-02 14:27:15 --> Helper loaded: my_helper
INFO - 2024-10-02 14:27:15 --> Database Driver Class Initialized
INFO - 2024-10-02 14:27:15 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-02 14:27:15 --> Controller Class Initialized
DEBUG - 2024-10-02 14:27:15 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/view_mapel/views/v_view_mapel.php
DEBUG - 2024-10-02 14:27:15 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-10-02 14:27:15 --> Final output sent to browser
DEBUG - 2024-10-02 14:27:15 --> Total execution time: 0.0376
INFO - 2024-10-02 14:27:16 --> Config Class Initialized
INFO - 2024-10-02 14:27:16 --> Hooks Class Initialized
DEBUG - 2024-10-02 14:27:16 --> UTF-8 Support Enabled
INFO - 2024-10-02 14:27:16 --> Utf8 Class Initialized
INFO - 2024-10-02 14:27:16 --> URI Class Initialized
INFO - 2024-10-02 14:27:16 --> Router Class Initialized
INFO - 2024-10-02 14:27:16 --> Output Class Initialized
INFO - 2024-10-02 14:27:16 --> Security Class Initialized
DEBUG - 2024-10-02 14:27:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-02 14:27:16 --> Input Class Initialized
INFO - 2024-10-02 14:27:16 --> Language Class Initialized
INFO - 2024-10-02 14:27:16 --> Language Class Initialized
INFO - 2024-10-02 14:27:16 --> Config Class Initialized
INFO - 2024-10-02 14:27:16 --> Loader Class Initialized
INFO - 2024-10-02 14:27:16 --> Helper loaded: url_helper
INFO - 2024-10-02 14:27:16 --> Helper loaded: file_helper
INFO - 2024-10-02 14:27:16 --> Helper loaded: form_helper
INFO - 2024-10-02 14:27:16 --> Helper loaded: my_helper
INFO - 2024-10-02 14:27:16 --> Database Driver Class Initialized
INFO - 2024-10-02 14:27:16 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-02 14:27:16 --> Controller Class Initialized
DEBUG - 2024-10-02 14:27:16 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_catatan_guru/views/list.php
DEBUG - 2024-10-02 14:27:16 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-10-02 14:27:16 --> Final output sent to browser
DEBUG - 2024-10-02 14:27:16 --> Total execution time: 0.0497
INFO - 2024-10-02 14:27:18 --> Config Class Initialized
INFO - 2024-10-02 14:27:18 --> Hooks Class Initialized
DEBUG - 2024-10-02 14:27:18 --> UTF-8 Support Enabled
INFO - 2024-10-02 14:27:18 --> Utf8 Class Initialized
INFO - 2024-10-02 14:27:18 --> URI Class Initialized
INFO - 2024-10-02 14:27:18 --> Router Class Initialized
INFO - 2024-10-02 14:27:18 --> Output Class Initialized
INFO - 2024-10-02 14:27:18 --> Security Class Initialized
DEBUG - 2024-10-02 14:27:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-02 14:27:18 --> Input Class Initialized
INFO - 2024-10-02 14:27:18 --> Language Class Initialized
INFO - 2024-10-02 14:27:18 --> Language Class Initialized
INFO - 2024-10-02 14:27:18 --> Config Class Initialized
INFO - 2024-10-02 14:27:18 --> Loader Class Initialized
INFO - 2024-10-02 14:27:18 --> Helper loaded: url_helper
INFO - 2024-10-02 14:27:18 --> Helper loaded: file_helper
INFO - 2024-10-02 14:27:18 --> Helper loaded: form_helper
INFO - 2024-10-02 14:27:18 --> Helper loaded: my_helper
INFO - 2024-10-02 14:27:18 --> Database Driver Class Initialized
INFO - 2024-10-02 14:27:18 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-02 14:27:18 --> Controller Class Initialized
INFO - 2024-10-02 14:27:18 --> Final output sent to browser
DEBUG - 2024-10-02 14:27:18 --> Total execution time: 0.0333
INFO - 2024-10-02 14:27:21 --> Config Class Initialized
INFO - 2024-10-02 14:27:21 --> Hooks Class Initialized
DEBUG - 2024-10-02 14:27:21 --> UTF-8 Support Enabled
INFO - 2024-10-02 14:27:21 --> Utf8 Class Initialized
INFO - 2024-10-02 14:27:21 --> URI Class Initialized
INFO - 2024-10-02 14:27:21 --> Router Class Initialized
INFO - 2024-10-02 14:27:21 --> Output Class Initialized
INFO - 2024-10-02 14:27:21 --> Security Class Initialized
DEBUG - 2024-10-02 14:27:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-02 14:27:21 --> Input Class Initialized
INFO - 2024-10-02 14:27:21 --> Language Class Initialized
INFO - 2024-10-02 14:27:21 --> Language Class Initialized
INFO - 2024-10-02 14:27:21 --> Config Class Initialized
INFO - 2024-10-02 14:27:21 --> Loader Class Initialized
INFO - 2024-10-02 14:27:21 --> Helper loaded: url_helper
INFO - 2024-10-02 14:27:21 --> Helper loaded: file_helper
INFO - 2024-10-02 14:27:21 --> Helper loaded: form_helper
INFO - 2024-10-02 14:27:21 --> Helper loaded: my_helper
INFO - 2024-10-02 14:27:21 --> Database Driver Class Initialized
INFO - 2024-10-02 14:27:21 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-02 14:27:21 --> Controller Class Initialized
DEBUG - 2024-10-02 14:27:21 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_catatan_guru/views/form.php
DEBUG - 2024-10-02 14:27:21 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-10-02 14:27:21 --> Final output sent to browser
DEBUG - 2024-10-02 14:27:21 --> Total execution time: 0.1078
INFO - 2024-10-02 14:27:27 --> Config Class Initialized
INFO - 2024-10-02 14:27:27 --> Hooks Class Initialized
DEBUG - 2024-10-02 14:27:27 --> UTF-8 Support Enabled
INFO - 2024-10-02 14:27:27 --> Utf8 Class Initialized
INFO - 2024-10-02 14:27:27 --> URI Class Initialized
INFO - 2024-10-02 14:27:27 --> Router Class Initialized
INFO - 2024-10-02 14:27:27 --> Output Class Initialized
INFO - 2024-10-02 14:27:27 --> Security Class Initialized
DEBUG - 2024-10-02 14:27:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-02 14:27:27 --> Input Class Initialized
INFO - 2024-10-02 14:27:27 --> Language Class Initialized
INFO - 2024-10-02 14:27:27 --> Language Class Initialized
INFO - 2024-10-02 14:27:27 --> Config Class Initialized
INFO - 2024-10-02 14:27:27 --> Loader Class Initialized
INFO - 2024-10-02 14:27:27 --> Helper loaded: url_helper
INFO - 2024-10-02 14:27:27 --> Helper loaded: file_helper
INFO - 2024-10-02 14:27:27 --> Helper loaded: form_helper
INFO - 2024-10-02 14:27:27 --> Helper loaded: my_helper
INFO - 2024-10-02 14:27:27 --> Database Driver Class Initialized
INFO - 2024-10-02 14:27:27 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-02 14:27:27 --> Controller Class Initialized
INFO - 2024-10-02 14:27:27 --> Config Class Initialized
INFO - 2024-10-02 14:27:27 --> Hooks Class Initialized
DEBUG - 2024-10-02 14:27:27 --> UTF-8 Support Enabled
INFO - 2024-10-02 14:27:27 --> Utf8 Class Initialized
INFO - 2024-10-02 14:27:27 --> URI Class Initialized
INFO - 2024-10-02 14:27:27 --> Router Class Initialized
INFO - 2024-10-02 14:27:27 --> Output Class Initialized
INFO - 2024-10-02 14:27:27 --> Security Class Initialized
DEBUG - 2024-10-02 14:27:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-02 14:27:27 --> Input Class Initialized
INFO - 2024-10-02 14:27:27 --> Language Class Initialized
INFO - 2024-10-02 14:27:27 --> Language Class Initialized
INFO - 2024-10-02 14:27:27 --> Config Class Initialized
INFO - 2024-10-02 14:27:27 --> Loader Class Initialized
INFO - 2024-10-02 14:27:27 --> Helper loaded: url_helper
INFO - 2024-10-02 14:27:27 --> Helper loaded: file_helper
INFO - 2024-10-02 14:27:27 --> Helper loaded: form_helper
INFO - 2024-10-02 14:27:27 --> Helper loaded: my_helper
INFO - 2024-10-02 14:27:27 --> Database Driver Class Initialized
INFO - 2024-10-02 14:27:27 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-02 14:27:27 --> Controller Class Initialized
DEBUG - 2024-10-02 14:27:27 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_catatan_guru/views/list.php
DEBUG - 2024-10-02 14:27:27 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-10-02 14:27:27 --> Final output sent to browser
DEBUG - 2024-10-02 14:27:27 --> Total execution time: 0.0507
INFO - 2024-10-02 14:27:34 --> Config Class Initialized
INFO - 2024-10-02 14:27:34 --> Hooks Class Initialized
DEBUG - 2024-10-02 14:27:34 --> UTF-8 Support Enabled
INFO - 2024-10-02 14:27:34 --> Utf8 Class Initialized
INFO - 2024-10-02 14:27:34 --> URI Class Initialized
INFO - 2024-10-02 14:27:34 --> Router Class Initialized
INFO - 2024-10-02 14:27:34 --> Output Class Initialized
INFO - 2024-10-02 14:27:34 --> Security Class Initialized
DEBUG - 2024-10-02 14:27:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-02 14:27:34 --> Input Class Initialized
INFO - 2024-10-02 14:27:34 --> Language Class Initialized
INFO - 2024-10-02 14:27:34 --> Language Class Initialized
INFO - 2024-10-02 14:27:34 --> Config Class Initialized
INFO - 2024-10-02 14:27:34 --> Loader Class Initialized
INFO - 2024-10-02 14:27:34 --> Helper loaded: url_helper
INFO - 2024-10-02 14:27:34 --> Helper loaded: file_helper
INFO - 2024-10-02 14:27:34 --> Helper loaded: form_helper
INFO - 2024-10-02 14:27:34 --> Helper loaded: my_helper
INFO - 2024-10-02 14:27:34 --> Database Driver Class Initialized
INFO - 2024-10-02 14:27:34 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-02 14:27:34 --> Controller Class Initialized
INFO - 2024-10-02 14:27:34 --> Final output sent to browser
DEBUG - 2024-10-02 14:27:34 --> Total execution time: 0.0357
INFO - 2024-10-02 14:27:38 --> Config Class Initialized
INFO - 2024-10-02 14:27:38 --> Hooks Class Initialized
DEBUG - 2024-10-02 14:27:38 --> UTF-8 Support Enabled
INFO - 2024-10-02 14:27:38 --> Utf8 Class Initialized
INFO - 2024-10-02 14:27:38 --> URI Class Initialized
INFO - 2024-10-02 14:27:38 --> Router Class Initialized
INFO - 2024-10-02 14:27:38 --> Output Class Initialized
INFO - 2024-10-02 14:27:38 --> Security Class Initialized
DEBUG - 2024-10-02 14:27:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-02 14:27:38 --> Input Class Initialized
INFO - 2024-10-02 14:27:38 --> Language Class Initialized
INFO - 2024-10-02 14:27:38 --> Language Class Initialized
INFO - 2024-10-02 14:27:38 --> Config Class Initialized
INFO - 2024-10-02 14:27:38 --> Loader Class Initialized
INFO - 2024-10-02 14:27:38 --> Helper loaded: url_helper
INFO - 2024-10-02 14:27:38 --> Helper loaded: file_helper
INFO - 2024-10-02 14:27:38 --> Helper loaded: form_helper
INFO - 2024-10-02 14:27:38 --> Helper loaded: my_helper
INFO - 2024-10-02 14:27:38 --> Database Driver Class Initialized
INFO - 2024-10-02 14:27:38 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-02 14:27:38 --> Controller Class Initialized
INFO - 2024-10-02 14:28:27 --> Config Class Initialized
INFO - 2024-10-02 14:28:27 --> Hooks Class Initialized
DEBUG - 2024-10-02 14:28:27 --> UTF-8 Support Enabled
INFO - 2024-10-02 14:28:27 --> Utf8 Class Initialized
INFO - 2024-10-02 14:28:27 --> URI Class Initialized
INFO - 2024-10-02 14:28:27 --> Router Class Initialized
INFO - 2024-10-02 14:28:27 --> Output Class Initialized
INFO - 2024-10-02 14:28:27 --> Security Class Initialized
DEBUG - 2024-10-02 14:28:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-02 14:28:27 --> Input Class Initialized
INFO - 2024-10-02 14:28:27 --> Language Class Initialized
INFO - 2024-10-02 14:28:27 --> Language Class Initialized
INFO - 2024-10-02 14:28:27 --> Config Class Initialized
INFO - 2024-10-02 14:28:27 --> Loader Class Initialized
INFO - 2024-10-02 14:28:27 --> Helper loaded: url_helper
INFO - 2024-10-02 14:28:27 --> Helper loaded: file_helper
INFO - 2024-10-02 14:28:27 --> Helper loaded: form_helper
INFO - 2024-10-02 14:28:27 --> Helper loaded: my_helper
INFO - 2024-10-02 14:28:27 --> Database Driver Class Initialized
INFO - 2024-10-02 14:28:27 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-02 14:28:27 --> Controller Class Initialized
DEBUG - 2024-10-02 14:28:27 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_la/views/list.php
DEBUG - 2024-10-02 14:28:27 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-10-02 14:28:27 --> Final output sent to browser
DEBUG - 2024-10-02 14:28:27 --> Total execution time: 0.0320
INFO - 2024-10-02 14:28:27 --> Config Class Initialized
INFO - 2024-10-02 14:28:27 --> Hooks Class Initialized
DEBUG - 2024-10-02 14:28:27 --> UTF-8 Support Enabled
INFO - 2024-10-02 14:28:27 --> Utf8 Class Initialized
INFO - 2024-10-02 14:28:27 --> URI Class Initialized
INFO - 2024-10-02 14:28:27 --> Router Class Initialized
INFO - 2024-10-02 14:28:27 --> Output Class Initialized
INFO - 2024-10-02 14:28:27 --> Security Class Initialized
DEBUG - 2024-10-02 14:28:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-02 14:28:27 --> Input Class Initialized
INFO - 2024-10-02 14:28:27 --> Language Class Initialized
INFO - 2024-10-02 14:28:27 --> Language Class Initialized
INFO - 2024-10-02 14:28:27 --> Config Class Initialized
INFO - 2024-10-02 14:28:27 --> Loader Class Initialized
INFO - 2024-10-02 14:28:27 --> Helper loaded: url_helper
INFO - 2024-10-02 14:28:27 --> Helper loaded: file_helper
INFO - 2024-10-02 14:28:27 --> Helper loaded: form_helper
INFO - 2024-10-02 14:28:27 --> Helper loaded: my_helper
INFO - 2024-10-02 14:28:27 --> Database Driver Class Initialized
INFO - 2024-10-02 14:28:27 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-02 14:28:27 --> Controller Class Initialized
INFO - 2024-10-02 14:28:34 --> Config Class Initialized
INFO - 2024-10-02 14:28:34 --> Hooks Class Initialized
DEBUG - 2024-10-02 14:28:34 --> UTF-8 Support Enabled
INFO - 2024-10-02 14:28:34 --> Utf8 Class Initialized
INFO - 2024-10-02 14:28:34 --> URI Class Initialized
INFO - 2024-10-02 14:28:34 --> Router Class Initialized
INFO - 2024-10-02 14:28:34 --> Output Class Initialized
INFO - 2024-10-02 14:28:34 --> Security Class Initialized
DEBUG - 2024-10-02 14:28:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-02 14:28:34 --> Input Class Initialized
INFO - 2024-10-02 14:28:34 --> Language Class Initialized
INFO - 2024-10-02 14:28:34 --> Language Class Initialized
INFO - 2024-10-02 14:28:34 --> Config Class Initialized
INFO - 2024-10-02 14:28:34 --> Loader Class Initialized
INFO - 2024-10-02 14:28:34 --> Helper loaded: url_helper
INFO - 2024-10-02 14:28:34 --> Helper loaded: file_helper
INFO - 2024-10-02 14:28:34 --> Helper loaded: form_helper
INFO - 2024-10-02 14:28:34 --> Helper loaded: my_helper
INFO - 2024-10-02 14:28:34 --> Database Driver Class Initialized
INFO - 2024-10-02 14:28:34 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-02 14:28:34 --> Controller Class Initialized
INFO - 2024-10-02 14:28:34 --> Final output sent to browser
DEBUG - 2024-10-02 14:28:34 --> Total execution time: 0.0368
INFO - 2024-10-02 14:28:39 --> Config Class Initialized
INFO - 2024-10-02 14:28:39 --> Hooks Class Initialized
DEBUG - 2024-10-02 14:28:39 --> UTF-8 Support Enabled
INFO - 2024-10-02 14:28:39 --> Utf8 Class Initialized
INFO - 2024-10-02 14:28:39 --> URI Class Initialized
INFO - 2024-10-02 14:28:39 --> Router Class Initialized
INFO - 2024-10-02 14:28:39 --> Output Class Initialized
INFO - 2024-10-02 14:28:39 --> Security Class Initialized
DEBUG - 2024-10-02 14:28:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-02 14:28:39 --> Input Class Initialized
INFO - 2024-10-02 14:28:39 --> Language Class Initialized
INFO - 2024-10-02 14:28:39 --> Language Class Initialized
INFO - 2024-10-02 14:28:39 --> Config Class Initialized
INFO - 2024-10-02 14:28:39 --> Loader Class Initialized
INFO - 2024-10-02 14:28:39 --> Helper loaded: url_helper
INFO - 2024-10-02 14:28:39 --> Helper loaded: file_helper
INFO - 2024-10-02 14:28:39 --> Helper loaded: form_helper
INFO - 2024-10-02 14:28:39 --> Helper loaded: my_helper
INFO - 2024-10-02 14:28:39 --> Database Driver Class Initialized
INFO - 2024-10-02 14:28:39 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-02 14:28:39 --> Controller Class Initialized
ERROR - 2024-10-02 14:28:39 --> Severity: Notice --> Undefined index: semester /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/set_kd/controllers/Set_kd.php 104
INFO - 2024-10-02 14:28:39 --> Final output sent to browser
DEBUG - 2024-10-02 14:28:39 --> Total execution time: 0.0315
INFO - 2024-10-02 14:28:41 --> Config Class Initialized
INFO - 2024-10-02 14:28:41 --> Hooks Class Initialized
DEBUG - 2024-10-02 14:28:41 --> UTF-8 Support Enabled
INFO - 2024-10-02 14:28:41 --> Utf8 Class Initialized
INFO - 2024-10-02 14:28:41 --> URI Class Initialized
INFO - 2024-10-02 14:28:41 --> Router Class Initialized
INFO - 2024-10-02 14:28:41 --> Output Class Initialized
INFO - 2024-10-02 14:28:41 --> Security Class Initialized
DEBUG - 2024-10-02 14:28:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-02 14:28:41 --> Input Class Initialized
INFO - 2024-10-02 14:28:41 --> Language Class Initialized
INFO - 2024-10-02 14:28:41 --> Language Class Initialized
INFO - 2024-10-02 14:28:41 --> Config Class Initialized
INFO - 2024-10-02 14:28:41 --> Loader Class Initialized
INFO - 2024-10-02 14:28:41 --> Helper loaded: url_helper
INFO - 2024-10-02 14:28:41 --> Helper loaded: file_helper
INFO - 2024-10-02 14:28:41 --> Helper loaded: form_helper
INFO - 2024-10-02 14:28:41 --> Helper loaded: my_helper
INFO - 2024-10-02 14:28:41 --> Database Driver Class Initialized
INFO - 2024-10-02 14:28:41 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-02 14:28:41 --> Controller Class Initialized
DEBUG - 2024-10-02 14:28:41 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_la/views/list.php
DEBUG - 2024-10-02 14:28:41 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-10-02 14:28:41 --> Final output sent to browser
DEBUG - 2024-10-02 14:28:41 --> Total execution time: 0.0617
INFO - 2024-10-02 14:28:42 --> Config Class Initialized
INFO - 2024-10-02 14:28:42 --> Hooks Class Initialized
DEBUG - 2024-10-02 14:28:42 --> UTF-8 Support Enabled
INFO - 2024-10-02 14:28:42 --> Utf8 Class Initialized
INFO - 2024-10-02 14:28:42 --> URI Class Initialized
INFO - 2024-10-02 14:28:42 --> Router Class Initialized
INFO - 2024-10-02 14:28:42 --> Output Class Initialized
INFO - 2024-10-02 14:28:42 --> Security Class Initialized
DEBUG - 2024-10-02 14:28:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-02 14:28:42 --> Input Class Initialized
INFO - 2024-10-02 14:28:42 --> Language Class Initialized
INFO - 2024-10-02 14:28:42 --> Language Class Initialized
INFO - 2024-10-02 14:28:42 --> Config Class Initialized
INFO - 2024-10-02 14:28:42 --> Loader Class Initialized
INFO - 2024-10-02 14:28:42 --> Helper loaded: url_helper
INFO - 2024-10-02 14:28:42 --> Helper loaded: file_helper
INFO - 2024-10-02 14:28:42 --> Helper loaded: form_helper
INFO - 2024-10-02 14:28:42 --> Helper loaded: my_helper
INFO - 2024-10-02 14:28:42 --> Database Driver Class Initialized
INFO - 2024-10-02 14:28:42 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-02 14:28:42 --> Controller Class Initialized
INFO - 2024-10-02 14:28:49 --> Config Class Initialized
INFO - 2024-10-02 14:28:49 --> Hooks Class Initialized
DEBUG - 2024-10-02 14:28:49 --> UTF-8 Support Enabled
INFO - 2024-10-02 14:28:49 --> Utf8 Class Initialized
INFO - 2024-10-02 14:28:49 --> URI Class Initialized
INFO - 2024-10-02 14:28:49 --> Router Class Initialized
INFO - 2024-10-02 14:28:49 --> Output Class Initialized
INFO - 2024-10-02 14:28:49 --> Security Class Initialized
DEBUG - 2024-10-02 14:28:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-02 14:28:49 --> Input Class Initialized
INFO - 2024-10-02 14:28:49 --> Language Class Initialized
INFO - 2024-10-02 14:28:49 --> Language Class Initialized
INFO - 2024-10-02 14:28:49 --> Config Class Initialized
INFO - 2024-10-02 14:28:49 --> Loader Class Initialized
INFO - 2024-10-02 14:28:49 --> Helper loaded: url_helper
INFO - 2024-10-02 14:28:49 --> Helper loaded: file_helper
INFO - 2024-10-02 14:28:49 --> Helper loaded: form_helper
INFO - 2024-10-02 14:28:49 --> Helper loaded: my_helper
INFO - 2024-10-02 14:28:49 --> Database Driver Class Initialized
INFO - 2024-10-02 14:28:49 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-02 14:28:49 --> Controller Class Initialized
INFO - 2024-10-02 14:28:49 --> Final output sent to browser
DEBUG - 2024-10-02 14:28:49 --> Total execution time: 0.0284
INFO - 2024-10-02 14:28:54 --> Config Class Initialized
INFO - 2024-10-02 14:28:54 --> Hooks Class Initialized
DEBUG - 2024-10-02 14:28:54 --> UTF-8 Support Enabled
INFO - 2024-10-02 14:28:54 --> Utf8 Class Initialized
INFO - 2024-10-02 14:28:54 --> URI Class Initialized
INFO - 2024-10-02 14:28:54 --> Router Class Initialized
INFO - 2024-10-02 14:28:54 --> Output Class Initialized
INFO - 2024-10-02 14:28:54 --> Security Class Initialized
DEBUG - 2024-10-02 14:28:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-02 14:28:54 --> Input Class Initialized
INFO - 2024-10-02 14:28:54 --> Language Class Initialized
INFO - 2024-10-02 14:28:54 --> Language Class Initialized
INFO - 2024-10-02 14:28:54 --> Config Class Initialized
INFO - 2024-10-02 14:28:54 --> Loader Class Initialized
INFO - 2024-10-02 14:28:54 --> Helper loaded: url_helper
INFO - 2024-10-02 14:28:54 --> Helper loaded: file_helper
INFO - 2024-10-02 14:28:54 --> Helper loaded: form_helper
INFO - 2024-10-02 14:28:54 --> Helper loaded: my_helper
INFO - 2024-10-02 14:28:54 --> Database Driver Class Initialized
INFO - 2024-10-02 14:28:54 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-02 14:28:54 --> Controller Class Initialized
ERROR - 2024-10-02 14:28:54 --> Severity: Notice --> Undefined index: semester /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/set_kd/controllers/Set_kd.php 104
INFO - 2024-10-02 14:28:54 --> Final output sent to browser
DEBUG - 2024-10-02 14:28:54 --> Total execution time: 0.0318
INFO - 2024-10-02 14:28:56 --> Config Class Initialized
INFO - 2024-10-02 14:28:56 --> Hooks Class Initialized
DEBUG - 2024-10-02 14:28:56 --> UTF-8 Support Enabled
INFO - 2024-10-02 14:28:56 --> Utf8 Class Initialized
INFO - 2024-10-02 14:28:56 --> URI Class Initialized
INFO - 2024-10-02 14:28:56 --> Router Class Initialized
INFO - 2024-10-02 14:28:56 --> Output Class Initialized
INFO - 2024-10-02 14:28:56 --> Security Class Initialized
DEBUG - 2024-10-02 14:28:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-02 14:28:56 --> Input Class Initialized
INFO - 2024-10-02 14:28:56 --> Language Class Initialized
INFO - 2024-10-02 14:28:56 --> Language Class Initialized
INFO - 2024-10-02 14:28:56 --> Config Class Initialized
INFO - 2024-10-02 14:28:56 --> Loader Class Initialized
INFO - 2024-10-02 14:28:56 --> Helper loaded: url_helper
INFO - 2024-10-02 14:28:56 --> Helper loaded: file_helper
INFO - 2024-10-02 14:28:56 --> Helper loaded: form_helper
INFO - 2024-10-02 14:28:56 --> Helper loaded: my_helper
INFO - 2024-10-02 14:28:56 --> Database Driver Class Initialized
INFO - 2024-10-02 14:28:56 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-02 14:28:56 --> Controller Class Initialized
DEBUG - 2024-10-02 14:28:56 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_la/views/list.php
DEBUG - 2024-10-02 14:28:56 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-10-02 14:28:56 --> Final output sent to browser
DEBUG - 2024-10-02 14:28:56 --> Total execution time: 0.0300
INFO - 2024-10-02 14:28:56 --> Config Class Initialized
INFO - 2024-10-02 14:28:56 --> Hooks Class Initialized
DEBUG - 2024-10-02 14:28:56 --> UTF-8 Support Enabled
INFO - 2024-10-02 14:28:56 --> Utf8 Class Initialized
INFO - 2024-10-02 14:28:56 --> URI Class Initialized
INFO - 2024-10-02 14:28:56 --> Router Class Initialized
INFO - 2024-10-02 14:28:56 --> Output Class Initialized
INFO - 2024-10-02 14:28:56 --> Security Class Initialized
DEBUG - 2024-10-02 14:28:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-02 14:28:56 --> Input Class Initialized
INFO - 2024-10-02 14:28:56 --> Language Class Initialized
INFO - 2024-10-02 14:28:56 --> Language Class Initialized
INFO - 2024-10-02 14:28:56 --> Config Class Initialized
INFO - 2024-10-02 14:28:56 --> Loader Class Initialized
INFO - 2024-10-02 14:28:56 --> Helper loaded: url_helper
INFO - 2024-10-02 14:28:56 --> Helper loaded: file_helper
INFO - 2024-10-02 14:28:56 --> Helper loaded: form_helper
INFO - 2024-10-02 14:28:56 --> Helper loaded: my_helper
INFO - 2024-10-02 14:28:56 --> Database Driver Class Initialized
INFO - 2024-10-02 14:28:56 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-02 14:28:56 --> Controller Class Initialized
INFO - 2024-10-02 14:29:03 --> Config Class Initialized
INFO - 2024-10-02 14:29:03 --> Hooks Class Initialized
DEBUG - 2024-10-02 14:29:03 --> UTF-8 Support Enabled
INFO - 2024-10-02 14:29:03 --> Utf8 Class Initialized
INFO - 2024-10-02 14:29:03 --> URI Class Initialized
INFO - 2024-10-02 14:29:03 --> Router Class Initialized
INFO - 2024-10-02 14:29:03 --> Output Class Initialized
INFO - 2024-10-02 14:29:03 --> Security Class Initialized
DEBUG - 2024-10-02 14:29:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-02 14:29:03 --> Input Class Initialized
INFO - 2024-10-02 14:29:03 --> Language Class Initialized
INFO - 2024-10-02 14:29:03 --> Language Class Initialized
INFO - 2024-10-02 14:29:03 --> Config Class Initialized
INFO - 2024-10-02 14:29:03 --> Loader Class Initialized
INFO - 2024-10-02 14:29:03 --> Helper loaded: url_helper
INFO - 2024-10-02 14:29:03 --> Helper loaded: file_helper
INFO - 2024-10-02 14:29:03 --> Helper loaded: form_helper
INFO - 2024-10-02 14:29:03 --> Helper loaded: my_helper
INFO - 2024-10-02 14:29:03 --> Database Driver Class Initialized
INFO - 2024-10-02 14:29:03 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-02 14:29:03 --> Controller Class Initialized
INFO - 2024-10-02 14:29:03 --> Final output sent to browser
DEBUG - 2024-10-02 14:29:03 --> Total execution time: 0.0345
INFO - 2024-10-02 14:29:09 --> Config Class Initialized
INFO - 2024-10-02 14:29:09 --> Hooks Class Initialized
DEBUG - 2024-10-02 14:29:09 --> UTF-8 Support Enabled
INFO - 2024-10-02 14:29:09 --> Utf8 Class Initialized
INFO - 2024-10-02 14:29:09 --> URI Class Initialized
INFO - 2024-10-02 14:29:09 --> Router Class Initialized
INFO - 2024-10-02 14:29:09 --> Output Class Initialized
INFO - 2024-10-02 14:29:09 --> Security Class Initialized
DEBUG - 2024-10-02 14:29:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-02 14:29:09 --> Input Class Initialized
INFO - 2024-10-02 14:29:09 --> Language Class Initialized
INFO - 2024-10-02 14:29:09 --> Language Class Initialized
INFO - 2024-10-02 14:29:09 --> Config Class Initialized
INFO - 2024-10-02 14:29:09 --> Loader Class Initialized
INFO - 2024-10-02 14:29:09 --> Helper loaded: url_helper
INFO - 2024-10-02 14:29:09 --> Helper loaded: file_helper
INFO - 2024-10-02 14:29:09 --> Helper loaded: form_helper
INFO - 2024-10-02 14:29:09 --> Helper loaded: my_helper
INFO - 2024-10-02 14:29:09 --> Database Driver Class Initialized
INFO - 2024-10-02 14:29:09 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-02 14:29:09 --> Controller Class Initialized
ERROR - 2024-10-02 14:29:09 --> Severity: Notice --> Undefined index: semester /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/set_kd/controllers/Set_kd.php 104
INFO - 2024-10-02 14:29:09 --> Final output sent to browser
DEBUG - 2024-10-02 14:29:09 --> Total execution time: 0.0368
INFO - 2024-10-02 14:29:10 --> Config Class Initialized
INFO - 2024-10-02 14:29:10 --> Hooks Class Initialized
DEBUG - 2024-10-02 14:29:10 --> UTF-8 Support Enabled
INFO - 2024-10-02 14:29:10 --> Utf8 Class Initialized
INFO - 2024-10-02 14:29:10 --> URI Class Initialized
INFO - 2024-10-02 14:29:10 --> Router Class Initialized
INFO - 2024-10-02 14:29:10 --> Output Class Initialized
INFO - 2024-10-02 14:29:10 --> Security Class Initialized
DEBUG - 2024-10-02 14:29:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-02 14:29:10 --> Input Class Initialized
INFO - 2024-10-02 14:29:10 --> Language Class Initialized
INFO - 2024-10-02 14:29:10 --> Language Class Initialized
INFO - 2024-10-02 14:29:10 --> Config Class Initialized
INFO - 2024-10-02 14:29:10 --> Loader Class Initialized
INFO - 2024-10-02 14:29:10 --> Helper loaded: url_helper
INFO - 2024-10-02 14:29:10 --> Helper loaded: file_helper
INFO - 2024-10-02 14:29:10 --> Helper loaded: form_helper
INFO - 2024-10-02 14:29:10 --> Helper loaded: my_helper
INFO - 2024-10-02 14:29:10 --> Database Driver Class Initialized
INFO - 2024-10-02 14:29:10 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-02 14:29:10 --> Controller Class Initialized
DEBUG - 2024-10-02 14:29:10 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_la/views/list.php
DEBUG - 2024-10-02 14:29:10 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-10-02 14:29:10 --> Final output sent to browser
DEBUG - 2024-10-02 14:29:10 --> Total execution time: 0.0304
INFO - 2024-10-02 14:29:10 --> Config Class Initialized
INFO - 2024-10-02 14:29:10 --> Hooks Class Initialized
DEBUG - 2024-10-02 14:29:10 --> UTF-8 Support Enabled
INFO - 2024-10-02 14:29:10 --> Utf8 Class Initialized
INFO - 2024-10-02 14:29:10 --> URI Class Initialized
INFO - 2024-10-02 14:29:10 --> Router Class Initialized
INFO - 2024-10-02 14:29:10 --> Output Class Initialized
INFO - 2024-10-02 14:29:10 --> Security Class Initialized
DEBUG - 2024-10-02 14:29:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-02 14:29:10 --> Input Class Initialized
INFO - 2024-10-02 14:29:10 --> Language Class Initialized
INFO - 2024-10-02 14:29:10 --> Language Class Initialized
INFO - 2024-10-02 14:29:10 --> Config Class Initialized
INFO - 2024-10-02 14:29:10 --> Loader Class Initialized
INFO - 2024-10-02 14:29:10 --> Helper loaded: url_helper
INFO - 2024-10-02 14:29:10 --> Helper loaded: file_helper
INFO - 2024-10-02 14:29:10 --> Helper loaded: form_helper
INFO - 2024-10-02 14:29:10 --> Helper loaded: my_helper
INFO - 2024-10-02 14:29:10 --> Database Driver Class Initialized
INFO - 2024-10-02 14:29:10 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-02 14:29:10 --> Controller Class Initialized
INFO - 2024-10-02 14:33:00 --> Config Class Initialized
INFO - 2024-10-02 14:33:00 --> Hooks Class Initialized
DEBUG - 2024-10-02 14:33:00 --> UTF-8 Support Enabled
INFO - 2024-10-02 14:33:00 --> Utf8 Class Initialized
INFO - 2024-10-02 14:33:00 --> URI Class Initialized
INFO - 2024-10-02 14:33:00 --> Router Class Initialized
INFO - 2024-10-02 14:33:00 --> Output Class Initialized
INFO - 2024-10-02 14:33:00 --> Security Class Initialized
DEBUG - 2024-10-02 14:33:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-02 14:33:00 --> Input Class Initialized
INFO - 2024-10-02 14:33:00 --> Language Class Initialized
INFO - 2024-10-02 14:33:00 --> Language Class Initialized
INFO - 2024-10-02 14:33:00 --> Config Class Initialized
INFO - 2024-10-02 14:33:00 --> Loader Class Initialized
INFO - 2024-10-02 14:33:00 --> Helper loaded: url_helper
INFO - 2024-10-02 14:33:00 --> Helper loaded: file_helper
INFO - 2024-10-02 14:33:00 --> Helper loaded: form_helper
INFO - 2024-10-02 14:33:00 --> Helper loaded: my_helper
INFO - 2024-10-02 14:33:00 --> Database Driver Class Initialized
INFO - 2024-10-02 14:33:00 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-02 14:33:00 --> Controller Class Initialized
DEBUG - 2024-10-02 14:33:00 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/view_mapel/views/v_view_mapel.php
DEBUG - 2024-10-02 14:33:00 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-10-02 14:33:00 --> Final output sent to browser
DEBUG - 2024-10-02 14:33:00 --> Total execution time: 0.0312
INFO - 2024-10-02 14:33:04 --> Config Class Initialized
INFO - 2024-10-02 14:33:04 --> Hooks Class Initialized
DEBUG - 2024-10-02 14:33:04 --> UTF-8 Support Enabled
INFO - 2024-10-02 14:33:04 --> Utf8 Class Initialized
INFO - 2024-10-02 14:33:04 --> URI Class Initialized
INFO - 2024-10-02 14:33:04 --> Router Class Initialized
INFO - 2024-10-02 14:33:04 --> Output Class Initialized
INFO - 2024-10-02 14:33:04 --> Security Class Initialized
DEBUG - 2024-10-02 14:33:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-02 14:33:04 --> Input Class Initialized
INFO - 2024-10-02 14:33:04 --> Language Class Initialized
INFO - 2024-10-02 14:33:04 --> Language Class Initialized
INFO - 2024-10-02 14:33:04 --> Config Class Initialized
INFO - 2024-10-02 14:33:04 --> Loader Class Initialized
INFO - 2024-10-02 14:33:04 --> Helper loaded: url_helper
INFO - 2024-10-02 14:33:04 --> Helper loaded: file_helper
INFO - 2024-10-02 14:33:04 --> Helper loaded: form_helper
INFO - 2024-10-02 14:33:04 --> Helper loaded: my_helper
INFO - 2024-10-02 14:33:04 --> Database Driver Class Initialized
INFO - 2024-10-02 14:33:04 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-02 14:33:04 --> Controller Class Initialized
DEBUG - 2024-10-02 14:33:04 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_catatan_guru/views/list.php
DEBUG - 2024-10-02 14:33:04 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-10-02 14:33:04 --> Final output sent to browser
DEBUG - 2024-10-02 14:33:04 --> Total execution time: 0.0349
INFO - 2024-10-02 14:33:06 --> Config Class Initialized
INFO - 2024-10-02 14:33:06 --> Hooks Class Initialized
DEBUG - 2024-10-02 14:33:06 --> UTF-8 Support Enabled
INFO - 2024-10-02 14:33:06 --> Utf8 Class Initialized
INFO - 2024-10-02 14:33:06 --> URI Class Initialized
INFO - 2024-10-02 14:33:06 --> Router Class Initialized
INFO - 2024-10-02 14:33:06 --> Output Class Initialized
INFO - 2024-10-02 14:33:06 --> Security Class Initialized
DEBUG - 2024-10-02 14:33:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-02 14:33:06 --> Input Class Initialized
INFO - 2024-10-02 14:33:06 --> Language Class Initialized
INFO - 2024-10-02 14:33:06 --> Language Class Initialized
INFO - 2024-10-02 14:33:06 --> Config Class Initialized
INFO - 2024-10-02 14:33:06 --> Loader Class Initialized
INFO - 2024-10-02 14:33:06 --> Helper loaded: url_helper
INFO - 2024-10-02 14:33:06 --> Helper loaded: file_helper
INFO - 2024-10-02 14:33:06 --> Helper loaded: form_helper
INFO - 2024-10-02 14:33:06 --> Helper loaded: my_helper
INFO - 2024-10-02 14:33:06 --> Database Driver Class Initialized
INFO - 2024-10-02 14:33:06 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-02 14:33:06 --> Controller Class Initialized
INFO - 2024-10-02 14:34:52 --> Config Class Initialized
INFO - 2024-10-02 14:34:52 --> Hooks Class Initialized
DEBUG - 2024-10-02 14:34:52 --> UTF-8 Support Enabled
INFO - 2024-10-02 14:34:52 --> Utf8 Class Initialized
INFO - 2024-10-02 14:34:52 --> URI Class Initialized
INFO - 2024-10-02 14:34:52 --> Router Class Initialized
INFO - 2024-10-02 14:34:52 --> Output Class Initialized
INFO - 2024-10-02 14:34:52 --> Security Class Initialized
DEBUG - 2024-10-02 14:34:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-02 14:34:52 --> Input Class Initialized
INFO - 2024-10-02 14:34:52 --> Language Class Initialized
INFO - 2024-10-02 14:34:52 --> Language Class Initialized
INFO - 2024-10-02 14:34:52 --> Config Class Initialized
INFO - 2024-10-02 14:34:52 --> Loader Class Initialized
INFO - 2024-10-02 14:34:52 --> Helper loaded: url_helper
INFO - 2024-10-02 14:34:52 --> Helper loaded: file_helper
INFO - 2024-10-02 14:34:52 --> Helper loaded: form_helper
INFO - 2024-10-02 14:34:52 --> Helper loaded: my_helper
INFO - 2024-10-02 14:34:52 --> Database Driver Class Initialized
INFO - 2024-10-02 14:34:52 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-02 14:34:52 --> Controller Class Initialized
DEBUG - 2024-10-02 14:34:52 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_icb/views/list.php
DEBUG - 2024-10-02 14:34:52 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-10-02 14:34:52 --> Final output sent to browser
DEBUG - 2024-10-02 14:34:52 --> Total execution time: 0.0779
INFO - 2024-10-02 14:34:56 --> Config Class Initialized
INFO - 2024-10-02 14:34:56 --> Hooks Class Initialized
DEBUG - 2024-10-02 14:34:56 --> UTF-8 Support Enabled
INFO - 2024-10-02 14:34:56 --> Utf8 Class Initialized
INFO - 2024-10-02 14:34:56 --> URI Class Initialized
INFO - 2024-10-02 14:34:56 --> Router Class Initialized
INFO - 2024-10-02 14:34:56 --> Output Class Initialized
INFO - 2024-10-02 14:34:56 --> Security Class Initialized
DEBUG - 2024-10-02 14:34:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-02 14:34:56 --> Input Class Initialized
INFO - 2024-10-02 14:34:56 --> Language Class Initialized
INFO - 2024-10-02 14:34:56 --> Language Class Initialized
INFO - 2024-10-02 14:34:56 --> Config Class Initialized
INFO - 2024-10-02 14:34:56 --> Loader Class Initialized
INFO - 2024-10-02 14:34:56 --> Helper loaded: url_helper
INFO - 2024-10-02 14:34:56 --> Helper loaded: file_helper
INFO - 2024-10-02 14:34:56 --> Helper loaded: form_helper
INFO - 2024-10-02 14:34:56 --> Helper loaded: my_helper
INFO - 2024-10-02 14:34:56 --> Database Driver Class Initialized
INFO - 2024-10-02 14:34:56 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-02 14:34:56 --> Controller Class Initialized
INFO - 2024-10-02 14:38:28 --> Config Class Initialized
INFO - 2024-10-02 14:38:28 --> Hooks Class Initialized
DEBUG - 2024-10-02 14:38:28 --> UTF-8 Support Enabled
INFO - 2024-10-02 14:38:28 --> Utf8 Class Initialized
INFO - 2024-10-02 14:38:28 --> URI Class Initialized
INFO - 2024-10-02 14:38:28 --> Router Class Initialized
INFO - 2024-10-02 14:38:28 --> Output Class Initialized
INFO - 2024-10-02 14:38:28 --> Security Class Initialized
DEBUG - 2024-10-02 14:38:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-02 14:38:28 --> Input Class Initialized
INFO - 2024-10-02 14:38:28 --> Language Class Initialized
INFO - 2024-10-02 14:38:28 --> Language Class Initialized
INFO - 2024-10-02 14:38:28 --> Config Class Initialized
INFO - 2024-10-02 14:38:28 --> Loader Class Initialized
INFO - 2024-10-02 14:38:28 --> Helper loaded: url_helper
INFO - 2024-10-02 14:38:28 --> Helper loaded: file_helper
INFO - 2024-10-02 14:38:28 --> Helper loaded: form_helper
INFO - 2024-10-02 14:38:28 --> Helper loaded: my_helper
INFO - 2024-10-02 14:38:28 --> Database Driver Class Initialized
INFO - 2024-10-02 14:38:28 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-02 14:38:28 --> Controller Class Initialized
DEBUG - 2024-10-02 14:38:28 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_catatan_guru/views/form.php
DEBUG - 2024-10-02 14:38:28 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-10-02 14:38:28 --> Final output sent to browser
DEBUG - 2024-10-02 14:38:28 --> Total execution time: 0.1106
INFO - 2024-10-02 14:38:35 --> Config Class Initialized
INFO - 2024-10-02 14:38:35 --> Hooks Class Initialized
DEBUG - 2024-10-02 14:38:35 --> UTF-8 Support Enabled
INFO - 2024-10-02 14:38:35 --> Utf8 Class Initialized
INFO - 2024-10-02 14:38:35 --> URI Class Initialized
INFO - 2024-10-02 14:38:35 --> Router Class Initialized
INFO - 2024-10-02 14:38:35 --> Output Class Initialized
INFO - 2024-10-02 14:38:35 --> Security Class Initialized
DEBUG - 2024-10-02 14:38:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-02 14:38:35 --> Input Class Initialized
INFO - 2024-10-02 14:38:35 --> Language Class Initialized
INFO - 2024-10-02 14:38:35 --> Language Class Initialized
INFO - 2024-10-02 14:38:35 --> Config Class Initialized
INFO - 2024-10-02 14:38:35 --> Loader Class Initialized
INFO - 2024-10-02 14:38:35 --> Helper loaded: url_helper
INFO - 2024-10-02 14:38:35 --> Helper loaded: file_helper
INFO - 2024-10-02 14:38:35 --> Helper loaded: form_helper
INFO - 2024-10-02 14:38:35 --> Helper loaded: my_helper
INFO - 2024-10-02 14:38:35 --> Database Driver Class Initialized
INFO - 2024-10-02 14:38:35 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-02 14:38:35 --> Controller Class Initialized
INFO - 2024-10-02 14:38:35 --> Config Class Initialized
INFO - 2024-10-02 14:38:35 --> Hooks Class Initialized
DEBUG - 2024-10-02 14:38:35 --> UTF-8 Support Enabled
INFO - 2024-10-02 14:38:35 --> Utf8 Class Initialized
INFO - 2024-10-02 14:38:35 --> URI Class Initialized
INFO - 2024-10-02 14:38:35 --> Router Class Initialized
INFO - 2024-10-02 14:38:35 --> Output Class Initialized
INFO - 2024-10-02 14:38:35 --> Security Class Initialized
DEBUG - 2024-10-02 14:38:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-02 14:38:35 --> Input Class Initialized
INFO - 2024-10-02 14:38:35 --> Language Class Initialized
INFO - 2024-10-02 14:38:35 --> Language Class Initialized
INFO - 2024-10-02 14:38:35 --> Config Class Initialized
INFO - 2024-10-02 14:38:35 --> Loader Class Initialized
INFO - 2024-10-02 14:38:35 --> Helper loaded: url_helper
INFO - 2024-10-02 14:38:35 --> Helper loaded: file_helper
INFO - 2024-10-02 14:38:35 --> Helper loaded: form_helper
INFO - 2024-10-02 14:38:35 --> Helper loaded: my_helper
INFO - 2024-10-02 14:38:35 --> Database Driver Class Initialized
INFO - 2024-10-02 14:38:35 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-02 14:38:35 --> Controller Class Initialized
DEBUG - 2024-10-02 14:38:35 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_catatan_guru/views/list.php
DEBUG - 2024-10-02 14:38:35 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-10-02 14:38:35 --> Final output sent to browser
DEBUG - 2024-10-02 14:38:35 --> Total execution time: 0.0601
INFO - 2024-10-02 14:38:37 --> Config Class Initialized
INFO - 2024-10-02 14:38:37 --> Hooks Class Initialized
DEBUG - 2024-10-02 14:38:37 --> UTF-8 Support Enabled
INFO - 2024-10-02 14:38:37 --> Utf8 Class Initialized
INFO - 2024-10-02 14:38:37 --> URI Class Initialized
INFO - 2024-10-02 14:38:37 --> Router Class Initialized
INFO - 2024-10-02 14:38:37 --> Output Class Initialized
INFO - 2024-10-02 14:38:37 --> Security Class Initialized
DEBUG - 2024-10-02 14:38:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-02 14:38:37 --> Input Class Initialized
INFO - 2024-10-02 14:38:37 --> Language Class Initialized
INFO - 2024-10-02 14:38:37 --> Language Class Initialized
INFO - 2024-10-02 14:38:37 --> Config Class Initialized
INFO - 2024-10-02 14:38:37 --> Loader Class Initialized
INFO - 2024-10-02 14:38:37 --> Helper loaded: url_helper
INFO - 2024-10-02 14:38:37 --> Helper loaded: file_helper
INFO - 2024-10-02 14:38:37 --> Helper loaded: form_helper
INFO - 2024-10-02 14:38:37 --> Helper loaded: my_helper
INFO - 2024-10-02 14:38:37 --> Database Driver Class Initialized
INFO - 2024-10-02 14:38:37 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-02 14:38:37 --> Controller Class Initialized
INFO - 2024-10-02 14:38:37 --> Final output sent to browser
DEBUG - 2024-10-02 14:38:37 --> Total execution time: 0.0330
INFO - 2024-10-02 14:38:43 --> Config Class Initialized
INFO - 2024-10-02 14:38:43 --> Hooks Class Initialized
DEBUG - 2024-10-02 14:38:43 --> UTF-8 Support Enabled
INFO - 2024-10-02 14:38:43 --> Utf8 Class Initialized
INFO - 2024-10-02 14:38:43 --> URI Class Initialized
INFO - 2024-10-02 14:38:43 --> Router Class Initialized
INFO - 2024-10-02 14:38:43 --> Output Class Initialized
INFO - 2024-10-02 14:38:43 --> Security Class Initialized
DEBUG - 2024-10-02 14:38:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-02 14:38:43 --> Input Class Initialized
INFO - 2024-10-02 14:38:43 --> Language Class Initialized
INFO - 2024-10-02 14:38:43 --> Language Class Initialized
INFO - 2024-10-02 14:38:43 --> Config Class Initialized
INFO - 2024-10-02 14:38:43 --> Loader Class Initialized
INFO - 2024-10-02 14:38:43 --> Helper loaded: url_helper
INFO - 2024-10-02 14:38:43 --> Helper loaded: file_helper
INFO - 2024-10-02 14:38:43 --> Helper loaded: form_helper
INFO - 2024-10-02 14:38:43 --> Helper loaded: my_helper
INFO - 2024-10-02 14:38:43 --> Database Driver Class Initialized
INFO - 2024-10-02 14:38:43 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-02 14:38:43 --> Controller Class Initialized
DEBUG - 2024-10-02 14:38:43 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/view_mapel/views/v_view_mapel.php
DEBUG - 2024-10-02 14:38:43 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-10-02 14:38:43 --> Final output sent to browser
DEBUG - 2024-10-02 14:38:43 --> Total execution time: 0.0333
INFO - 2024-10-02 14:38:45 --> Config Class Initialized
INFO - 2024-10-02 14:38:45 --> Hooks Class Initialized
DEBUG - 2024-10-02 14:38:45 --> UTF-8 Support Enabled
INFO - 2024-10-02 14:38:45 --> Utf8 Class Initialized
INFO - 2024-10-02 14:38:45 --> URI Class Initialized
INFO - 2024-10-02 14:38:45 --> Router Class Initialized
INFO - 2024-10-02 14:38:45 --> Output Class Initialized
INFO - 2024-10-02 14:38:45 --> Security Class Initialized
DEBUG - 2024-10-02 14:38:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-02 14:38:45 --> Input Class Initialized
INFO - 2024-10-02 14:38:45 --> Language Class Initialized
INFO - 2024-10-02 14:38:45 --> Language Class Initialized
INFO - 2024-10-02 14:38:45 --> Config Class Initialized
INFO - 2024-10-02 14:38:45 --> Loader Class Initialized
INFO - 2024-10-02 14:38:45 --> Helper loaded: url_helper
INFO - 2024-10-02 14:38:45 --> Helper loaded: file_helper
INFO - 2024-10-02 14:38:45 --> Helper loaded: form_helper
INFO - 2024-10-02 14:38:45 --> Helper loaded: my_helper
INFO - 2024-10-02 14:38:45 --> Database Driver Class Initialized
INFO - 2024-10-02 14:38:45 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-02 14:38:45 --> Controller Class Initialized
DEBUG - 2024-10-02 14:38:45 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_catatan_guru/views/list.php
DEBUG - 2024-10-02 14:38:45 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-10-02 14:38:45 --> Final output sent to browser
DEBUG - 2024-10-02 14:38:45 --> Total execution time: 0.0461
INFO - 2024-10-02 14:38:47 --> Config Class Initialized
INFO - 2024-10-02 14:38:47 --> Hooks Class Initialized
DEBUG - 2024-10-02 14:38:47 --> UTF-8 Support Enabled
INFO - 2024-10-02 14:38:47 --> Utf8 Class Initialized
INFO - 2024-10-02 14:38:47 --> URI Class Initialized
INFO - 2024-10-02 14:38:47 --> Router Class Initialized
INFO - 2024-10-02 14:38:47 --> Output Class Initialized
INFO - 2024-10-02 14:38:47 --> Security Class Initialized
DEBUG - 2024-10-02 14:38:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-02 14:38:47 --> Input Class Initialized
INFO - 2024-10-02 14:38:47 --> Language Class Initialized
INFO - 2024-10-02 14:38:47 --> Language Class Initialized
INFO - 2024-10-02 14:38:47 --> Config Class Initialized
INFO - 2024-10-02 14:38:47 --> Loader Class Initialized
INFO - 2024-10-02 14:38:47 --> Helper loaded: url_helper
INFO - 2024-10-02 14:38:47 --> Helper loaded: file_helper
INFO - 2024-10-02 14:38:47 --> Helper loaded: form_helper
INFO - 2024-10-02 14:38:47 --> Helper loaded: my_helper
INFO - 2024-10-02 14:38:47 --> Database Driver Class Initialized
INFO - 2024-10-02 14:38:47 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-02 14:38:47 --> Controller Class Initialized
DEBUG - 2024-10-02 14:38:47 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_catatan_guru/views/form.php
DEBUG - 2024-10-02 14:38:47 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-10-02 14:38:47 --> Final output sent to browser
DEBUG - 2024-10-02 14:38:47 --> Total execution time: 0.0453
INFO - 2024-10-02 14:38:58 --> Config Class Initialized
INFO - 2024-10-02 14:38:58 --> Hooks Class Initialized
DEBUG - 2024-10-02 14:38:58 --> UTF-8 Support Enabled
INFO - 2024-10-02 14:38:58 --> Utf8 Class Initialized
INFO - 2024-10-02 14:38:58 --> URI Class Initialized
INFO - 2024-10-02 14:38:58 --> Router Class Initialized
INFO - 2024-10-02 14:38:58 --> Output Class Initialized
INFO - 2024-10-02 14:38:58 --> Security Class Initialized
DEBUG - 2024-10-02 14:38:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-02 14:38:58 --> Input Class Initialized
INFO - 2024-10-02 14:38:58 --> Language Class Initialized
INFO - 2024-10-02 14:38:58 --> Language Class Initialized
INFO - 2024-10-02 14:38:58 --> Config Class Initialized
INFO - 2024-10-02 14:38:58 --> Loader Class Initialized
INFO - 2024-10-02 14:38:58 --> Helper loaded: url_helper
INFO - 2024-10-02 14:38:58 --> Helper loaded: file_helper
INFO - 2024-10-02 14:38:58 --> Helper loaded: form_helper
INFO - 2024-10-02 14:38:58 --> Helper loaded: my_helper
INFO - 2024-10-02 14:38:58 --> Database Driver Class Initialized
INFO - 2024-10-02 14:38:58 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-02 14:38:58 --> Controller Class Initialized
INFO - 2024-10-02 14:38:58 --> Config Class Initialized
INFO - 2024-10-02 14:38:58 --> Hooks Class Initialized
DEBUG - 2024-10-02 14:38:58 --> UTF-8 Support Enabled
INFO - 2024-10-02 14:38:58 --> Utf8 Class Initialized
INFO - 2024-10-02 14:38:58 --> URI Class Initialized
INFO - 2024-10-02 14:38:58 --> Router Class Initialized
INFO - 2024-10-02 14:38:58 --> Output Class Initialized
INFO - 2024-10-02 14:38:58 --> Security Class Initialized
DEBUG - 2024-10-02 14:38:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-02 14:38:58 --> Input Class Initialized
INFO - 2024-10-02 14:38:58 --> Language Class Initialized
INFO - 2024-10-02 14:38:58 --> Language Class Initialized
INFO - 2024-10-02 14:38:58 --> Config Class Initialized
INFO - 2024-10-02 14:38:58 --> Loader Class Initialized
INFO - 2024-10-02 14:38:58 --> Helper loaded: url_helper
INFO - 2024-10-02 14:38:58 --> Helper loaded: file_helper
INFO - 2024-10-02 14:38:58 --> Helper loaded: form_helper
INFO - 2024-10-02 14:38:58 --> Helper loaded: my_helper
INFO - 2024-10-02 14:38:58 --> Database Driver Class Initialized
INFO - 2024-10-02 14:38:58 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-02 14:38:58 --> Controller Class Initialized
DEBUG - 2024-10-02 14:38:58 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_catatan_guru/views/list.php
DEBUG - 2024-10-02 14:38:58 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-10-02 14:38:58 --> Final output sent to browser
DEBUG - 2024-10-02 14:38:58 --> Total execution time: 0.0328
INFO - 2024-10-02 14:39:00 --> Config Class Initialized
INFO - 2024-10-02 14:39:00 --> Hooks Class Initialized
DEBUG - 2024-10-02 14:39:00 --> UTF-8 Support Enabled
INFO - 2024-10-02 14:39:00 --> Utf8 Class Initialized
INFO - 2024-10-02 14:39:00 --> URI Class Initialized
INFO - 2024-10-02 14:39:00 --> Router Class Initialized
INFO - 2024-10-02 14:39:00 --> Output Class Initialized
INFO - 2024-10-02 14:39:00 --> Security Class Initialized
DEBUG - 2024-10-02 14:39:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-02 14:39:00 --> Input Class Initialized
INFO - 2024-10-02 14:39:00 --> Language Class Initialized
INFO - 2024-10-02 14:39:00 --> Language Class Initialized
INFO - 2024-10-02 14:39:00 --> Config Class Initialized
INFO - 2024-10-02 14:39:00 --> Loader Class Initialized
INFO - 2024-10-02 14:39:00 --> Helper loaded: url_helper
INFO - 2024-10-02 14:39:00 --> Helper loaded: file_helper
INFO - 2024-10-02 14:39:00 --> Helper loaded: form_helper
INFO - 2024-10-02 14:39:00 --> Helper loaded: my_helper
INFO - 2024-10-02 14:39:00 --> Database Driver Class Initialized
INFO - 2024-10-02 14:39:00 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-02 14:39:00 --> Controller Class Initialized
INFO - 2024-10-02 14:39:00 --> Final output sent to browser
DEBUG - 2024-10-02 14:39:00 --> Total execution time: 0.0443
INFO - 2024-10-02 14:39:09 --> Config Class Initialized
INFO - 2024-10-02 14:39:09 --> Hooks Class Initialized
DEBUG - 2024-10-02 14:39:09 --> UTF-8 Support Enabled
INFO - 2024-10-02 14:39:09 --> Utf8 Class Initialized
INFO - 2024-10-02 14:39:09 --> URI Class Initialized
INFO - 2024-10-02 14:39:09 --> Router Class Initialized
INFO - 2024-10-02 14:39:09 --> Output Class Initialized
INFO - 2024-10-02 14:39:09 --> Security Class Initialized
DEBUG - 2024-10-02 14:39:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-02 14:39:09 --> Input Class Initialized
INFO - 2024-10-02 14:39:09 --> Language Class Initialized
INFO - 2024-10-02 14:39:09 --> Language Class Initialized
INFO - 2024-10-02 14:39:09 --> Config Class Initialized
INFO - 2024-10-02 14:39:09 --> Loader Class Initialized
INFO - 2024-10-02 14:39:09 --> Helper loaded: url_helper
INFO - 2024-10-02 14:39:09 --> Helper loaded: file_helper
INFO - 2024-10-02 14:39:09 --> Helper loaded: form_helper
INFO - 2024-10-02 14:39:09 --> Helper loaded: my_helper
INFO - 2024-10-02 14:39:09 --> Database Driver Class Initialized
INFO - 2024-10-02 14:39:09 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-02 14:39:09 --> Controller Class Initialized
DEBUG - 2024-10-02 14:39:10 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/view_mapel/views/v_view_mapel.php
DEBUG - 2024-10-02 14:39:10 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-10-02 14:39:10 --> Final output sent to browser
DEBUG - 2024-10-02 14:39:10 --> Total execution time: 0.0384
INFO - 2024-10-02 14:39:11 --> Config Class Initialized
INFO - 2024-10-02 14:39:11 --> Hooks Class Initialized
DEBUG - 2024-10-02 14:39:11 --> UTF-8 Support Enabled
INFO - 2024-10-02 14:39:11 --> Utf8 Class Initialized
INFO - 2024-10-02 14:39:11 --> URI Class Initialized
INFO - 2024-10-02 14:39:11 --> Router Class Initialized
INFO - 2024-10-02 14:39:11 --> Output Class Initialized
INFO - 2024-10-02 14:39:11 --> Security Class Initialized
DEBUG - 2024-10-02 14:39:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-02 14:39:11 --> Input Class Initialized
INFO - 2024-10-02 14:39:11 --> Language Class Initialized
INFO - 2024-10-02 14:39:11 --> Language Class Initialized
INFO - 2024-10-02 14:39:11 --> Config Class Initialized
INFO - 2024-10-02 14:39:11 --> Loader Class Initialized
INFO - 2024-10-02 14:39:11 --> Helper loaded: url_helper
INFO - 2024-10-02 14:39:11 --> Helper loaded: file_helper
INFO - 2024-10-02 14:39:11 --> Helper loaded: form_helper
INFO - 2024-10-02 14:39:11 --> Helper loaded: my_helper
INFO - 2024-10-02 14:39:11 --> Database Driver Class Initialized
INFO - 2024-10-02 14:39:11 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-02 14:39:11 --> Controller Class Initialized
DEBUG - 2024-10-02 14:39:11 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/views/list.php
DEBUG - 2024-10-02 14:39:11 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-10-02 14:39:11 --> Final output sent to browser
DEBUG - 2024-10-02 14:39:11 --> Total execution time: 0.0879
INFO - 2024-10-02 14:39:11 --> Config Class Initialized
INFO - 2024-10-02 14:39:11 --> Hooks Class Initialized
DEBUG - 2024-10-02 14:39:11 --> UTF-8 Support Enabled
INFO - 2024-10-02 14:39:11 --> Utf8 Class Initialized
INFO - 2024-10-02 14:39:11 --> URI Class Initialized
INFO - 2024-10-02 14:39:11 --> Router Class Initialized
INFO - 2024-10-02 14:39:11 --> Output Class Initialized
INFO - 2024-10-02 14:39:11 --> Security Class Initialized
DEBUG - 2024-10-02 14:39:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-02 14:39:11 --> Input Class Initialized
INFO - 2024-10-02 14:39:11 --> Language Class Initialized
INFO - 2024-10-02 14:39:11 --> Language Class Initialized
INFO - 2024-10-02 14:39:11 --> Config Class Initialized
INFO - 2024-10-02 14:39:11 --> Loader Class Initialized
INFO - 2024-10-02 14:39:11 --> Helper loaded: url_helper
INFO - 2024-10-02 14:39:11 --> Helper loaded: file_helper
INFO - 2024-10-02 14:39:11 --> Helper loaded: form_helper
INFO - 2024-10-02 14:39:11 --> Helper loaded: my_helper
INFO - 2024-10-02 14:39:11 --> Database Driver Class Initialized
INFO - 2024-10-02 14:39:11 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-02 14:39:11 --> Controller Class Initialized
INFO - 2024-10-02 14:39:14 --> Config Class Initialized
INFO - 2024-10-02 14:39:14 --> Hooks Class Initialized
DEBUG - 2024-10-02 14:39:14 --> UTF-8 Support Enabled
INFO - 2024-10-02 14:39:14 --> Utf8 Class Initialized
INFO - 2024-10-02 14:39:14 --> URI Class Initialized
INFO - 2024-10-02 14:39:14 --> Router Class Initialized
INFO - 2024-10-02 14:39:14 --> Output Class Initialized
INFO - 2024-10-02 14:39:14 --> Security Class Initialized
DEBUG - 2024-10-02 14:39:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-02 14:39:14 --> Input Class Initialized
INFO - 2024-10-02 14:39:14 --> Language Class Initialized
INFO - 2024-10-02 14:39:14 --> Language Class Initialized
INFO - 2024-10-02 14:39:14 --> Config Class Initialized
INFO - 2024-10-02 14:39:14 --> Loader Class Initialized
INFO - 2024-10-02 14:39:14 --> Helper loaded: url_helper
INFO - 2024-10-02 14:39:14 --> Helper loaded: file_helper
INFO - 2024-10-02 14:39:14 --> Helper loaded: form_helper
INFO - 2024-10-02 14:39:14 --> Helper loaded: my_helper
INFO - 2024-10-02 14:39:14 --> Database Driver Class Initialized
INFO - 2024-10-02 14:39:14 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-02 14:39:14 --> Controller Class Initialized
INFO - 2024-10-02 14:39:14 --> Final output sent to browser
DEBUG - 2024-10-02 14:39:14 --> Total execution time: 0.0320
INFO - 2024-10-02 14:39:17 --> Config Class Initialized
INFO - 2024-10-02 14:39:17 --> Hooks Class Initialized
DEBUG - 2024-10-02 14:39:17 --> UTF-8 Support Enabled
INFO - 2024-10-02 14:39:17 --> Utf8 Class Initialized
INFO - 2024-10-02 14:39:17 --> URI Class Initialized
INFO - 2024-10-02 14:39:17 --> Router Class Initialized
INFO - 2024-10-02 14:39:17 --> Output Class Initialized
INFO - 2024-10-02 14:39:17 --> Security Class Initialized
DEBUG - 2024-10-02 14:39:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-02 14:39:17 --> Input Class Initialized
INFO - 2024-10-02 14:39:17 --> Language Class Initialized
INFO - 2024-10-02 14:39:17 --> Language Class Initialized
INFO - 2024-10-02 14:39:17 --> Config Class Initialized
INFO - 2024-10-02 14:39:17 --> Loader Class Initialized
INFO - 2024-10-02 14:39:17 --> Helper loaded: url_helper
INFO - 2024-10-02 14:39:17 --> Helper loaded: file_helper
INFO - 2024-10-02 14:39:17 --> Helper loaded: form_helper
INFO - 2024-10-02 14:39:17 --> Helper loaded: my_helper
INFO - 2024-10-02 14:39:17 --> Database Driver Class Initialized
INFO - 2024-10-02 14:39:17 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-02 14:39:17 --> Controller Class Initialized
INFO - 2024-10-02 14:39:17 --> Final output sent to browser
DEBUG - 2024-10-02 14:39:17 --> Total execution time: 0.0656
INFO - 2024-10-02 14:39:19 --> Config Class Initialized
INFO - 2024-10-02 14:39:19 --> Hooks Class Initialized
DEBUG - 2024-10-02 14:39:19 --> UTF-8 Support Enabled
INFO - 2024-10-02 14:39:19 --> Utf8 Class Initialized
INFO - 2024-10-02 14:39:19 --> URI Class Initialized
INFO - 2024-10-02 14:39:19 --> Router Class Initialized
INFO - 2024-10-02 14:39:19 --> Output Class Initialized
INFO - 2024-10-02 14:39:19 --> Security Class Initialized
DEBUG - 2024-10-02 14:39:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-02 14:39:19 --> Input Class Initialized
INFO - 2024-10-02 14:39:19 --> Language Class Initialized
INFO - 2024-10-02 14:39:19 --> Language Class Initialized
INFO - 2024-10-02 14:39:19 --> Config Class Initialized
INFO - 2024-10-02 14:39:19 --> Loader Class Initialized
INFO - 2024-10-02 14:39:19 --> Helper loaded: url_helper
INFO - 2024-10-02 14:39:19 --> Helper loaded: file_helper
INFO - 2024-10-02 14:39:19 --> Helper loaded: form_helper
INFO - 2024-10-02 14:39:19 --> Helper loaded: my_helper
INFO - 2024-10-02 14:39:19 --> Database Driver Class Initialized
INFO - 2024-10-02 14:39:19 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-02 14:39:19 --> Controller Class Initialized
DEBUG - 2024-10-02 14:39:19 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/view_mapel/views/v_view_mapel.php
DEBUG - 2024-10-02 14:39:19 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-10-02 14:39:19 --> Final output sent to browser
DEBUG - 2024-10-02 14:39:19 --> Total execution time: 0.0317
INFO - 2024-10-02 14:39:21 --> Config Class Initialized
INFO - 2024-10-02 14:39:21 --> Hooks Class Initialized
DEBUG - 2024-10-02 14:39:21 --> UTF-8 Support Enabled
INFO - 2024-10-02 14:39:21 --> Utf8 Class Initialized
INFO - 2024-10-02 14:39:21 --> URI Class Initialized
INFO - 2024-10-02 14:39:21 --> Router Class Initialized
INFO - 2024-10-02 14:39:21 --> Output Class Initialized
INFO - 2024-10-02 14:39:21 --> Security Class Initialized
DEBUG - 2024-10-02 14:39:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-02 14:39:21 --> Input Class Initialized
INFO - 2024-10-02 14:39:21 --> Language Class Initialized
INFO - 2024-10-02 14:39:21 --> Language Class Initialized
INFO - 2024-10-02 14:39:21 --> Config Class Initialized
INFO - 2024-10-02 14:39:21 --> Loader Class Initialized
INFO - 2024-10-02 14:39:21 --> Helper loaded: url_helper
INFO - 2024-10-02 14:39:21 --> Helper loaded: file_helper
INFO - 2024-10-02 14:39:21 --> Helper loaded: form_helper
INFO - 2024-10-02 14:39:21 --> Helper loaded: my_helper
INFO - 2024-10-02 14:39:21 --> Database Driver Class Initialized
INFO - 2024-10-02 14:39:21 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-02 14:39:21 --> Controller Class Initialized
DEBUG - 2024-10-02 14:39:21 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/views/list.php
DEBUG - 2024-10-02 14:39:21 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-10-02 14:39:21 --> Final output sent to browser
DEBUG - 2024-10-02 14:39:21 --> Total execution time: 0.0327
INFO - 2024-10-02 14:39:22 --> Config Class Initialized
INFO - 2024-10-02 14:39:22 --> Hooks Class Initialized
DEBUG - 2024-10-02 14:39:22 --> UTF-8 Support Enabled
INFO - 2024-10-02 14:39:22 --> Utf8 Class Initialized
INFO - 2024-10-02 14:39:22 --> URI Class Initialized
INFO - 2024-10-02 14:39:22 --> Router Class Initialized
INFO - 2024-10-02 14:39:22 --> Output Class Initialized
INFO - 2024-10-02 14:39:22 --> Security Class Initialized
DEBUG - 2024-10-02 14:39:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-02 14:39:22 --> Input Class Initialized
INFO - 2024-10-02 14:39:22 --> Language Class Initialized
INFO - 2024-10-02 14:39:22 --> Language Class Initialized
INFO - 2024-10-02 14:39:22 --> Config Class Initialized
INFO - 2024-10-02 14:39:22 --> Loader Class Initialized
INFO - 2024-10-02 14:39:22 --> Helper loaded: url_helper
INFO - 2024-10-02 14:39:22 --> Helper loaded: file_helper
INFO - 2024-10-02 14:39:22 --> Helper loaded: form_helper
INFO - 2024-10-02 14:39:22 --> Helper loaded: my_helper
INFO - 2024-10-02 14:39:22 --> Database Driver Class Initialized
INFO - 2024-10-02 14:39:22 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-02 14:39:22 --> Controller Class Initialized
INFO - 2024-10-02 14:39:45 --> Config Class Initialized
INFO - 2024-10-02 14:39:45 --> Hooks Class Initialized
DEBUG - 2024-10-02 14:39:45 --> UTF-8 Support Enabled
INFO - 2024-10-02 14:39:45 --> Utf8 Class Initialized
INFO - 2024-10-02 14:39:45 --> URI Class Initialized
INFO - 2024-10-02 14:39:45 --> Router Class Initialized
INFO - 2024-10-02 14:39:45 --> Output Class Initialized
INFO - 2024-10-02 14:39:45 --> Security Class Initialized
DEBUG - 2024-10-02 14:39:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-02 14:39:45 --> Input Class Initialized
INFO - 2024-10-02 14:39:45 --> Language Class Initialized
INFO - 2024-10-02 14:39:45 --> Language Class Initialized
INFO - 2024-10-02 14:39:45 --> Config Class Initialized
INFO - 2024-10-02 14:39:45 --> Loader Class Initialized
INFO - 2024-10-02 14:39:45 --> Helper loaded: url_helper
INFO - 2024-10-02 14:39:45 --> Helper loaded: file_helper
INFO - 2024-10-02 14:39:45 --> Helper loaded: form_helper
INFO - 2024-10-02 14:39:45 --> Helper loaded: my_helper
INFO - 2024-10-02 14:39:45 --> Database Driver Class Initialized
INFO - 2024-10-02 14:39:45 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-02 14:39:45 --> Controller Class Initialized
INFO - 2024-10-02 14:39:45 --> Final output sent to browser
DEBUG - 2024-10-02 14:39:45 --> Total execution time: 0.0447
INFO - 2024-10-02 14:39:45 --> Config Class Initialized
INFO - 2024-10-02 14:39:45 --> Hooks Class Initialized
DEBUG - 2024-10-02 14:39:45 --> UTF-8 Support Enabled
INFO - 2024-10-02 14:39:45 --> Utf8 Class Initialized
INFO - 2024-10-02 14:39:45 --> URI Class Initialized
INFO - 2024-10-02 14:39:45 --> Router Class Initialized
INFO - 2024-10-02 14:39:45 --> Output Class Initialized
INFO - 2024-10-02 14:39:45 --> Security Class Initialized
DEBUG - 2024-10-02 14:39:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-02 14:39:45 --> Input Class Initialized
INFO - 2024-10-02 14:39:45 --> Language Class Initialized
INFO - 2024-10-02 14:39:45 --> Language Class Initialized
INFO - 2024-10-02 14:39:45 --> Config Class Initialized
INFO - 2024-10-02 14:39:45 --> Loader Class Initialized
INFO - 2024-10-02 14:39:45 --> Helper loaded: url_helper
INFO - 2024-10-02 14:39:45 --> Helper loaded: file_helper
INFO - 2024-10-02 14:39:45 --> Helper loaded: form_helper
INFO - 2024-10-02 14:39:45 --> Helper loaded: my_helper
INFO - 2024-10-02 14:39:45 --> Database Driver Class Initialized
INFO - 2024-10-02 14:39:45 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-02 14:39:45 --> Controller Class Initialized
INFO - 2024-10-02 14:40:02 --> Config Class Initialized
INFO - 2024-10-02 14:40:02 --> Hooks Class Initialized
DEBUG - 2024-10-02 14:40:02 --> UTF-8 Support Enabled
INFO - 2024-10-02 14:40:02 --> Utf8 Class Initialized
INFO - 2024-10-02 14:40:02 --> URI Class Initialized
INFO - 2024-10-02 14:40:02 --> Router Class Initialized
INFO - 2024-10-02 14:40:02 --> Output Class Initialized
INFO - 2024-10-02 14:40:02 --> Security Class Initialized
DEBUG - 2024-10-02 14:40:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-02 14:40:02 --> Input Class Initialized
INFO - 2024-10-02 14:40:02 --> Language Class Initialized
INFO - 2024-10-02 14:40:02 --> Language Class Initialized
INFO - 2024-10-02 14:40:02 --> Config Class Initialized
INFO - 2024-10-02 14:40:02 --> Loader Class Initialized
INFO - 2024-10-02 14:40:02 --> Helper loaded: url_helper
INFO - 2024-10-02 14:40:02 --> Helper loaded: file_helper
INFO - 2024-10-02 14:40:02 --> Helper loaded: form_helper
INFO - 2024-10-02 14:40:02 --> Helper loaded: my_helper
INFO - 2024-10-02 14:40:02 --> Database Driver Class Initialized
INFO - 2024-10-02 14:40:02 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-02 14:40:02 --> Controller Class Initialized
DEBUG - 2024-10-02 14:40:02 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/view_mapel/views/v_view_mapel.php
DEBUG - 2024-10-02 14:40:02 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-10-02 14:40:02 --> Final output sent to browser
DEBUG - 2024-10-02 14:40:02 --> Total execution time: 0.0359
INFO - 2024-10-02 14:40:05 --> Config Class Initialized
INFO - 2024-10-02 14:40:05 --> Hooks Class Initialized
DEBUG - 2024-10-02 14:40:05 --> UTF-8 Support Enabled
INFO - 2024-10-02 14:40:05 --> Utf8 Class Initialized
INFO - 2024-10-02 14:40:05 --> URI Class Initialized
INFO - 2024-10-02 14:40:05 --> Router Class Initialized
INFO - 2024-10-02 14:40:05 --> Output Class Initialized
INFO - 2024-10-02 14:40:05 --> Security Class Initialized
DEBUG - 2024-10-02 14:40:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-02 14:40:05 --> Input Class Initialized
INFO - 2024-10-02 14:40:05 --> Language Class Initialized
INFO - 2024-10-02 14:40:05 --> Language Class Initialized
INFO - 2024-10-02 14:40:05 --> Config Class Initialized
INFO - 2024-10-02 14:40:05 --> Loader Class Initialized
INFO - 2024-10-02 14:40:05 --> Helper loaded: url_helper
INFO - 2024-10-02 14:40:05 --> Helper loaded: file_helper
INFO - 2024-10-02 14:40:05 --> Helper loaded: form_helper
INFO - 2024-10-02 14:40:05 --> Helper loaded: my_helper
INFO - 2024-10-02 14:40:05 --> Database Driver Class Initialized
INFO - 2024-10-02 14:40:05 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-02 14:40:05 --> Controller Class Initialized
DEBUG - 2024-10-02 14:40:05 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/views/list.php
DEBUG - 2024-10-02 14:40:05 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-10-02 14:40:05 --> Final output sent to browser
DEBUG - 2024-10-02 14:40:05 --> Total execution time: 0.0405
INFO - 2024-10-02 14:40:05 --> Config Class Initialized
INFO - 2024-10-02 14:40:05 --> Hooks Class Initialized
DEBUG - 2024-10-02 14:40:05 --> UTF-8 Support Enabled
INFO - 2024-10-02 14:40:05 --> Utf8 Class Initialized
INFO - 2024-10-02 14:40:05 --> URI Class Initialized
INFO - 2024-10-02 14:40:05 --> Router Class Initialized
INFO - 2024-10-02 14:40:05 --> Output Class Initialized
INFO - 2024-10-02 14:40:05 --> Security Class Initialized
DEBUG - 2024-10-02 14:40:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-02 14:40:05 --> Input Class Initialized
INFO - 2024-10-02 14:40:05 --> Language Class Initialized
INFO - 2024-10-02 14:40:06 --> Language Class Initialized
INFO - 2024-10-02 14:40:06 --> Config Class Initialized
INFO - 2024-10-02 14:40:06 --> Loader Class Initialized
INFO - 2024-10-02 14:40:06 --> Helper loaded: url_helper
INFO - 2024-10-02 14:40:06 --> Helper loaded: file_helper
INFO - 2024-10-02 14:40:06 --> Helper loaded: form_helper
INFO - 2024-10-02 14:40:06 --> Helper loaded: my_helper
INFO - 2024-10-02 14:40:06 --> Database Driver Class Initialized
INFO - 2024-10-02 14:40:06 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-02 14:40:06 --> Controller Class Initialized
INFO - 2024-10-02 14:40:11 --> Config Class Initialized
INFO - 2024-10-02 14:40:11 --> Hooks Class Initialized
DEBUG - 2024-10-02 14:40:11 --> UTF-8 Support Enabled
INFO - 2024-10-02 14:40:11 --> Utf8 Class Initialized
INFO - 2024-10-02 14:40:11 --> URI Class Initialized
INFO - 2024-10-02 14:40:11 --> Router Class Initialized
INFO - 2024-10-02 14:40:11 --> Output Class Initialized
INFO - 2024-10-02 14:40:11 --> Security Class Initialized
DEBUG - 2024-10-02 14:40:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-02 14:40:11 --> Input Class Initialized
INFO - 2024-10-02 14:40:11 --> Language Class Initialized
INFO - 2024-10-02 14:40:11 --> Language Class Initialized
INFO - 2024-10-02 14:40:11 --> Config Class Initialized
INFO - 2024-10-02 14:40:11 --> Loader Class Initialized
INFO - 2024-10-02 14:40:11 --> Helper loaded: url_helper
INFO - 2024-10-02 14:40:11 --> Helper loaded: file_helper
INFO - 2024-10-02 14:40:11 --> Helper loaded: form_helper
INFO - 2024-10-02 14:40:11 --> Helper loaded: my_helper
INFO - 2024-10-02 14:40:11 --> Database Driver Class Initialized
INFO - 2024-10-02 14:40:11 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-02 14:40:11 --> Controller Class Initialized
INFO - 2024-10-02 14:40:11 --> Final output sent to browser
DEBUG - 2024-10-02 14:40:11 --> Total execution time: 0.0450
INFO - 2024-10-02 14:40:15 --> Config Class Initialized
INFO - 2024-10-02 14:40:15 --> Hooks Class Initialized
DEBUG - 2024-10-02 14:40:15 --> UTF-8 Support Enabled
INFO - 2024-10-02 14:40:15 --> Utf8 Class Initialized
INFO - 2024-10-02 14:40:15 --> URI Class Initialized
INFO - 2024-10-02 14:40:15 --> Router Class Initialized
INFO - 2024-10-02 14:40:15 --> Output Class Initialized
INFO - 2024-10-02 14:40:15 --> Security Class Initialized
DEBUG - 2024-10-02 14:40:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-02 14:40:15 --> Input Class Initialized
INFO - 2024-10-02 14:40:15 --> Language Class Initialized
INFO - 2024-10-02 14:40:15 --> Language Class Initialized
INFO - 2024-10-02 14:40:15 --> Config Class Initialized
INFO - 2024-10-02 14:40:15 --> Loader Class Initialized
INFO - 2024-10-02 14:40:15 --> Helper loaded: url_helper
INFO - 2024-10-02 14:40:15 --> Helper loaded: file_helper
INFO - 2024-10-02 14:40:15 --> Helper loaded: form_helper
INFO - 2024-10-02 14:40:15 --> Helper loaded: my_helper
INFO - 2024-10-02 14:40:15 --> Database Driver Class Initialized
INFO - 2024-10-02 14:40:15 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-02 14:40:15 --> Controller Class Initialized
INFO - 2024-10-02 14:43:15 --> Config Class Initialized
INFO - 2024-10-02 14:43:15 --> Hooks Class Initialized
DEBUG - 2024-10-02 14:43:15 --> UTF-8 Support Enabled
INFO - 2024-10-02 14:43:15 --> Utf8 Class Initialized
INFO - 2024-10-02 14:43:15 --> URI Class Initialized
INFO - 2024-10-02 14:43:15 --> Router Class Initialized
INFO - 2024-10-02 14:43:15 --> Output Class Initialized
INFO - 2024-10-02 14:43:15 --> Security Class Initialized
DEBUG - 2024-10-02 14:43:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-02 14:43:15 --> Input Class Initialized
INFO - 2024-10-02 14:43:15 --> Language Class Initialized
INFO - 2024-10-02 14:43:15 --> Language Class Initialized
INFO - 2024-10-02 14:43:15 --> Config Class Initialized
INFO - 2024-10-02 14:43:15 --> Loader Class Initialized
INFO - 2024-10-02 14:43:15 --> Helper loaded: url_helper
INFO - 2024-10-02 14:43:15 --> Helper loaded: file_helper
INFO - 2024-10-02 14:43:15 --> Helper loaded: form_helper
INFO - 2024-10-02 14:43:15 --> Helper loaded: my_helper
INFO - 2024-10-02 14:43:15 --> Database Driver Class Initialized
INFO - 2024-10-02 14:43:15 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-02 14:43:15 --> Controller Class Initialized
DEBUG - 2024-10-02 14:43:15 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/views/form.php
DEBUG - 2024-10-02 14:43:15 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-10-02 14:43:15 --> Final output sent to browser
DEBUG - 2024-10-02 14:43:15 --> Total execution time: 0.0342
INFO - 2024-10-02 14:43:29 --> Config Class Initialized
INFO - 2024-10-02 14:43:29 --> Hooks Class Initialized
DEBUG - 2024-10-02 14:43:29 --> UTF-8 Support Enabled
INFO - 2024-10-02 14:43:29 --> Utf8 Class Initialized
INFO - 2024-10-02 14:43:29 --> URI Class Initialized
INFO - 2024-10-02 14:43:29 --> Router Class Initialized
INFO - 2024-10-02 14:43:29 --> Output Class Initialized
INFO - 2024-10-02 14:43:29 --> Security Class Initialized
DEBUG - 2024-10-02 14:43:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-02 14:43:29 --> Input Class Initialized
INFO - 2024-10-02 14:43:29 --> Language Class Initialized
INFO - 2024-10-02 14:43:29 --> Language Class Initialized
INFO - 2024-10-02 14:43:29 --> Config Class Initialized
INFO - 2024-10-02 14:43:29 --> Loader Class Initialized
INFO - 2024-10-02 14:43:29 --> Helper loaded: url_helper
INFO - 2024-10-02 14:43:29 --> Helper loaded: file_helper
INFO - 2024-10-02 14:43:29 --> Helper loaded: form_helper
INFO - 2024-10-02 14:43:29 --> Helper loaded: my_helper
INFO - 2024-10-02 14:43:29 --> Database Driver Class Initialized
INFO - 2024-10-02 14:43:29 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-02 14:43:29 --> Controller Class Initialized
INFO - 2024-10-02 14:43:30 --> Config Class Initialized
INFO - 2024-10-02 14:43:30 --> Hooks Class Initialized
DEBUG - 2024-10-02 14:43:30 --> UTF-8 Support Enabled
INFO - 2024-10-02 14:43:30 --> Utf8 Class Initialized
INFO - 2024-10-02 14:43:30 --> URI Class Initialized
INFO - 2024-10-02 14:43:30 --> Router Class Initialized
INFO - 2024-10-02 14:43:30 --> Output Class Initialized
INFO - 2024-10-02 14:43:30 --> Security Class Initialized
DEBUG - 2024-10-02 14:43:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-02 14:43:30 --> Input Class Initialized
INFO - 2024-10-02 14:43:30 --> Language Class Initialized
INFO - 2024-10-02 14:43:30 --> Language Class Initialized
INFO - 2024-10-02 14:43:30 --> Config Class Initialized
INFO - 2024-10-02 14:43:30 --> Loader Class Initialized
INFO - 2024-10-02 14:43:30 --> Helper loaded: url_helper
INFO - 2024-10-02 14:43:30 --> Helper loaded: file_helper
INFO - 2024-10-02 14:43:30 --> Helper loaded: form_helper
INFO - 2024-10-02 14:43:30 --> Helper loaded: my_helper
INFO - 2024-10-02 14:43:30 --> Database Driver Class Initialized
INFO - 2024-10-02 14:43:30 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-02 14:43:30 --> Controller Class Initialized
DEBUG - 2024-10-02 14:43:30 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/views/list.php
DEBUG - 2024-10-02 14:43:30 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-10-02 14:43:30 --> Final output sent to browser
DEBUG - 2024-10-02 14:43:30 --> Total execution time: 0.0324
INFO - 2024-10-02 14:43:30 --> Config Class Initialized
INFO - 2024-10-02 14:43:30 --> Hooks Class Initialized
DEBUG - 2024-10-02 14:43:30 --> UTF-8 Support Enabled
INFO - 2024-10-02 14:43:30 --> Utf8 Class Initialized
INFO - 2024-10-02 14:43:30 --> URI Class Initialized
INFO - 2024-10-02 14:43:30 --> Router Class Initialized
INFO - 2024-10-02 14:43:30 --> Output Class Initialized
INFO - 2024-10-02 14:43:30 --> Security Class Initialized
DEBUG - 2024-10-02 14:43:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-02 14:43:30 --> Input Class Initialized
INFO - 2024-10-02 14:43:30 --> Language Class Initialized
INFO - 2024-10-02 14:43:30 --> Language Class Initialized
INFO - 2024-10-02 14:43:30 --> Config Class Initialized
INFO - 2024-10-02 14:43:30 --> Loader Class Initialized
INFO - 2024-10-02 14:43:30 --> Helper loaded: url_helper
INFO - 2024-10-02 14:43:30 --> Helper loaded: file_helper
INFO - 2024-10-02 14:43:30 --> Helper loaded: form_helper
INFO - 2024-10-02 14:43:30 --> Helper loaded: my_helper
INFO - 2024-10-02 14:43:30 --> Database Driver Class Initialized
INFO - 2024-10-02 14:43:30 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-02 14:43:30 --> Controller Class Initialized
INFO - 2024-10-02 14:50:57 --> Config Class Initialized
INFO - 2024-10-02 14:50:57 --> Hooks Class Initialized
DEBUG - 2024-10-02 14:50:58 --> UTF-8 Support Enabled
INFO - 2024-10-02 14:50:58 --> Utf8 Class Initialized
INFO - 2024-10-02 14:50:58 --> URI Class Initialized
INFO - 2024-10-02 14:50:58 --> Router Class Initialized
INFO - 2024-10-02 14:50:58 --> Output Class Initialized
INFO - 2024-10-02 14:50:58 --> Security Class Initialized
DEBUG - 2024-10-02 14:50:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-02 14:50:58 --> Input Class Initialized
INFO - 2024-10-02 14:50:58 --> Language Class Initialized
INFO - 2024-10-02 14:50:58 --> Language Class Initialized
INFO - 2024-10-02 14:50:58 --> Config Class Initialized
INFO - 2024-10-02 14:50:58 --> Loader Class Initialized
INFO - 2024-10-02 14:50:58 --> Helper loaded: url_helper
INFO - 2024-10-02 14:50:58 --> Helper loaded: file_helper
INFO - 2024-10-02 14:50:58 --> Helper loaded: form_helper
INFO - 2024-10-02 14:50:58 --> Helper loaded: my_helper
INFO - 2024-10-02 14:50:58 --> Database Driver Class Initialized
INFO - 2024-10-02 14:50:58 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-02 14:50:58 --> Controller Class Initialized
INFO - 2024-10-02 14:50:58 --> Final output sent to browser
DEBUG - 2024-10-02 14:50:58 --> Total execution time: 0.1590
INFO - 2024-10-02 14:51:03 --> Config Class Initialized
INFO - 2024-10-02 14:51:03 --> Hooks Class Initialized
DEBUG - 2024-10-02 14:51:03 --> UTF-8 Support Enabled
INFO - 2024-10-02 14:51:03 --> Utf8 Class Initialized
INFO - 2024-10-02 14:51:03 --> URI Class Initialized
INFO - 2024-10-02 14:51:03 --> Router Class Initialized
INFO - 2024-10-02 14:51:03 --> Output Class Initialized
INFO - 2024-10-02 14:51:03 --> Security Class Initialized
DEBUG - 2024-10-02 14:51:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-02 14:51:03 --> Input Class Initialized
INFO - 2024-10-02 14:51:03 --> Language Class Initialized
INFO - 2024-10-02 14:51:03 --> Language Class Initialized
INFO - 2024-10-02 14:51:03 --> Config Class Initialized
INFO - 2024-10-02 14:51:03 --> Loader Class Initialized
INFO - 2024-10-02 14:51:03 --> Helper loaded: url_helper
INFO - 2024-10-02 14:51:03 --> Helper loaded: file_helper
INFO - 2024-10-02 14:51:03 --> Helper loaded: form_helper
INFO - 2024-10-02 14:51:03 --> Helper loaded: my_helper
INFO - 2024-10-02 14:51:03 --> Database Driver Class Initialized
INFO - 2024-10-02 14:51:03 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-02 14:51:03 --> Controller Class Initialized
INFO - 2024-10-02 14:51:03 --> Final output sent to browser
DEBUG - 2024-10-02 14:51:03 --> Total execution time: 0.0355
INFO - 2024-10-02 14:51:13 --> Config Class Initialized
INFO - 2024-10-02 14:51:13 --> Hooks Class Initialized
DEBUG - 2024-10-02 14:51:13 --> UTF-8 Support Enabled
INFO - 2024-10-02 14:51:13 --> Utf8 Class Initialized
INFO - 2024-10-02 14:51:13 --> URI Class Initialized
INFO - 2024-10-02 14:51:13 --> Router Class Initialized
INFO - 2024-10-02 14:51:13 --> Output Class Initialized
INFO - 2024-10-02 14:51:13 --> Security Class Initialized
DEBUG - 2024-10-02 14:51:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-02 14:51:13 --> Input Class Initialized
INFO - 2024-10-02 14:51:13 --> Language Class Initialized
INFO - 2024-10-02 14:51:13 --> Language Class Initialized
INFO - 2024-10-02 14:51:13 --> Config Class Initialized
INFO - 2024-10-02 14:51:13 --> Loader Class Initialized
INFO - 2024-10-02 14:51:13 --> Helper loaded: url_helper
INFO - 2024-10-02 14:51:13 --> Helper loaded: file_helper
INFO - 2024-10-02 14:51:13 --> Helper loaded: form_helper
INFO - 2024-10-02 14:51:13 --> Helper loaded: my_helper
INFO - 2024-10-02 14:51:13 --> Database Driver Class Initialized
INFO - 2024-10-02 14:51:13 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-02 14:51:13 --> Controller Class Initialized
INFO - 2024-10-02 14:51:13 --> Final output sent to browser
DEBUG - 2024-10-02 14:51:13 --> Total execution time: 0.1515
INFO - 2024-10-02 14:57:08 --> Config Class Initialized
INFO - 2024-10-02 14:57:08 --> Hooks Class Initialized
DEBUG - 2024-10-02 14:57:08 --> UTF-8 Support Enabled
INFO - 2024-10-02 14:57:08 --> Utf8 Class Initialized
INFO - 2024-10-02 14:57:08 --> URI Class Initialized
INFO - 2024-10-02 14:57:08 --> Router Class Initialized
INFO - 2024-10-02 14:57:08 --> Output Class Initialized
INFO - 2024-10-02 14:57:08 --> Security Class Initialized
DEBUG - 2024-10-02 14:57:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-02 14:57:08 --> Input Class Initialized
INFO - 2024-10-02 14:57:08 --> Language Class Initialized
INFO - 2024-10-02 14:57:08 --> Language Class Initialized
INFO - 2024-10-02 14:57:08 --> Config Class Initialized
INFO - 2024-10-02 14:57:08 --> Loader Class Initialized
INFO - 2024-10-02 14:57:08 --> Helper loaded: url_helper
INFO - 2024-10-02 14:57:08 --> Helper loaded: file_helper
INFO - 2024-10-02 14:57:08 --> Helper loaded: form_helper
INFO - 2024-10-02 14:57:08 --> Helper loaded: my_helper
INFO - 2024-10-02 14:57:08 --> Database Driver Class Initialized
INFO - 2024-10-02 14:57:08 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-02 14:57:08 --> Controller Class Initialized
INFO - 2024-10-02 14:57:08 --> Config Class Initialized
INFO - 2024-10-02 14:57:08 --> Hooks Class Initialized
DEBUG - 2024-10-02 14:57:08 --> UTF-8 Support Enabled
INFO - 2024-10-02 14:57:08 --> Utf8 Class Initialized
INFO - 2024-10-02 14:57:08 --> URI Class Initialized
INFO - 2024-10-02 14:57:08 --> Router Class Initialized
INFO - 2024-10-02 14:57:08 --> Output Class Initialized
INFO - 2024-10-02 14:57:08 --> Security Class Initialized
DEBUG - 2024-10-02 14:57:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-02 14:57:08 --> Input Class Initialized
INFO - 2024-10-02 14:57:08 --> Language Class Initialized
INFO - 2024-10-02 14:57:08 --> Language Class Initialized
INFO - 2024-10-02 14:57:08 --> Config Class Initialized
INFO - 2024-10-02 14:57:08 --> Loader Class Initialized
INFO - 2024-10-02 14:57:08 --> Helper loaded: url_helper
INFO - 2024-10-02 14:57:08 --> Helper loaded: file_helper
INFO - 2024-10-02 14:57:08 --> Helper loaded: form_helper
INFO - 2024-10-02 14:57:08 --> Helper loaded: my_helper
INFO - 2024-10-02 14:57:08 --> Database Driver Class Initialized
INFO - 2024-10-02 14:57:08 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-02 14:57:08 --> Controller Class Initialized
DEBUG - 2024-10-02 14:57:08 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/login/views/login.php
DEBUG - 2024-10-02 14:57:08 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-10-02 14:57:08 --> Final output sent to browser
DEBUG - 2024-10-02 14:57:08 --> Total execution time: 0.0312
INFO - 2024-10-02 14:57:10 --> Config Class Initialized
INFO - 2024-10-02 14:57:10 --> Hooks Class Initialized
DEBUG - 2024-10-02 14:57:10 --> UTF-8 Support Enabled
INFO - 2024-10-02 14:57:10 --> Utf8 Class Initialized
INFO - 2024-10-02 14:57:10 --> URI Class Initialized
INFO - 2024-10-02 14:57:10 --> Router Class Initialized
INFO - 2024-10-02 14:57:10 --> Output Class Initialized
INFO - 2024-10-02 14:57:10 --> Security Class Initialized
DEBUG - 2024-10-02 14:57:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-02 14:57:10 --> Input Class Initialized
INFO - 2024-10-02 14:57:10 --> Language Class Initialized
INFO - 2024-10-02 14:57:10 --> Language Class Initialized
INFO - 2024-10-02 14:57:10 --> Config Class Initialized
INFO - 2024-10-02 14:57:10 --> Loader Class Initialized
INFO - 2024-10-02 14:57:10 --> Helper loaded: url_helper
INFO - 2024-10-02 14:57:10 --> Helper loaded: file_helper
INFO - 2024-10-02 14:57:10 --> Helper loaded: form_helper
INFO - 2024-10-02 14:57:10 --> Helper loaded: my_helper
INFO - 2024-10-02 14:57:10 --> Database Driver Class Initialized
INFO - 2024-10-02 14:57:10 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-02 14:57:10 --> Controller Class Initialized
INFO - 2024-10-02 14:57:10 --> Helper loaded: cookie_helper
INFO - 2024-10-02 14:57:10 --> Final output sent to browser
DEBUG - 2024-10-02 14:57:10 --> Total execution time: 0.0624
INFO - 2024-10-02 14:57:10 --> Config Class Initialized
INFO - 2024-10-02 14:57:10 --> Hooks Class Initialized
DEBUG - 2024-10-02 14:57:10 --> UTF-8 Support Enabled
INFO - 2024-10-02 14:57:10 --> Utf8 Class Initialized
INFO - 2024-10-02 14:57:10 --> URI Class Initialized
INFO - 2024-10-02 14:57:10 --> Router Class Initialized
INFO - 2024-10-02 14:57:10 --> Output Class Initialized
INFO - 2024-10-02 14:57:10 --> Security Class Initialized
DEBUG - 2024-10-02 14:57:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-02 14:57:10 --> Input Class Initialized
INFO - 2024-10-02 14:57:10 --> Language Class Initialized
INFO - 2024-10-02 14:57:10 --> Language Class Initialized
INFO - 2024-10-02 14:57:10 --> Config Class Initialized
INFO - 2024-10-02 14:57:10 --> Loader Class Initialized
INFO - 2024-10-02 14:57:10 --> Helper loaded: url_helper
INFO - 2024-10-02 14:57:10 --> Helper loaded: file_helper
INFO - 2024-10-02 14:57:10 --> Helper loaded: form_helper
INFO - 2024-10-02 14:57:10 --> Helper loaded: my_helper
INFO - 2024-10-02 14:57:10 --> Database Driver Class Initialized
INFO - 2024-10-02 14:57:10 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-02 14:57:10 --> Controller Class Initialized
DEBUG - 2024-10-02 14:57:10 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/home/views/v_home_guru.php
DEBUG - 2024-10-02 14:57:10 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-10-02 14:57:10 --> Final output sent to browser
DEBUG - 2024-10-02 14:57:10 --> Total execution time: 0.0295
INFO - 2024-10-02 14:57:14 --> Config Class Initialized
INFO - 2024-10-02 14:57:14 --> Hooks Class Initialized
DEBUG - 2024-10-02 14:57:14 --> UTF-8 Support Enabled
INFO - 2024-10-02 14:57:14 --> Utf8 Class Initialized
INFO - 2024-10-02 14:57:14 --> URI Class Initialized
INFO - 2024-10-02 14:57:14 --> Router Class Initialized
INFO - 2024-10-02 14:57:14 --> Output Class Initialized
INFO - 2024-10-02 14:57:14 --> Security Class Initialized
DEBUG - 2024-10-02 14:57:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-02 14:57:14 --> Input Class Initialized
INFO - 2024-10-02 14:57:14 --> Language Class Initialized
INFO - 2024-10-02 14:57:14 --> Language Class Initialized
INFO - 2024-10-02 14:57:14 --> Config Class Initialized
INFO - 2024-10-02 14:57:14 --> Loader Class Initialized
INFO - 2024-10-02 14:57:14 --> Helper loaded: url_helper
INFO - 2024-10-02 14:57:14 --> Helper loaded: file_helper
INFO - 2024-10-02 14:57:14 --> Helper loaded: form_helper
INFO - 2024-10-02 14:57:14 --> Helper loaded: my_helper
INFO - 2024-10-02 14:57:14 --> Database Driver Class Initialized
INFO - 2024-10-02 14:57:14 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-02 14:57:14 --> Controller Class Initialized
DEBUG - 2024-10-02 14:57:14 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/view_mapel/views/v_view_mapel.php
DEBUG - 2024-10-02 14:57:14 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-10-02 14:57:14 --> Final output sent to browser
DEBUG - 2024-10-02 14:57:14 --> Total execution time: 0.0647
INFO - 2024-10-02 14:57:30 --> Config Class Initialized
INFO - 2024-10-02 14:57:30 --> Hooks Class Initialized
DEBUG - 2024-10-02 14:57:30 --> UTF-8 Support Enabled
INFO - 2024-10-02 14:57:30 --> Utf8 Class Initialized
INFO - 2024-10-02 14:57:30 --> URI Class Initialized
INFO - 2024-10-02 14:57:30 --> Router Class Initialized
INFO - 2024-10-02 14:57:30 --> Output Class Initialized
INFO - 2024-10-02 14:57:30 --> Security Class Initialized
DEBUG - 2024-10-02 14:57:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-02 14:57:30 --> Input Class Initialized
INFO - 2024-10-02 14:57:30 --> Language Class Initialized
INFO - 2024-10-02 14:57:30 --> Language Class Initialized
INFO - 2024-10-02 14:57:30 --> Config Class Initialized
INFO - 2024-10-02 14:57:30 --> Loader Class Initialized
INFO - 2024-10-02 14:57:30 --> Helper loaded: url_helper
INFO - 2024-10-02 14:57:30 --> Helper loaded: file_helper
INFO - 2024-10-02 14:57:30 --> Helper loaded: form_helper
INFO - 2024-10-02 14:57:30 --> Helper loaded: my_helper
INFO - 2024-10-02 14:57:30 --> Database Driver Class Initialized
INFO - 2024-10-02 14:57:30 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-02 14:57:30 --> Controller Class Initialized
DEBUG - 2024-10-02 14:57:30 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/views/list.php
DEBUG - 2024-10-02 14:57:30 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-10-02 14:57:30 --> Final output sent to browser
DEBUG - 2024-10-02 14:57:30 --> Total execution time: 0.0751
INFO - 2024-10-02 14:57:30 --> Config Class Initialized
INFO - 2024-10-02 14:57:30 --> Hooks Class Initialized
DEBUG - 2024-10-02 14:57:30 --> UTF-8 Support Enabled
INFO - 2024-10-02 14:57:30 --> Utf8 Class Initialized
INFO - 2024-10-02 14:57:30 --> URI Class Initialized
INFO - 2024-10-02 14:57:30 --> Router Class Initialized
INFO - 2024-10-02 14:57:30 --> Output Class Initialized
INFO - 2024-10-02 14:57:30 --> Security Class Initialized
DEBUG - 2024-10-02 14:57:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-02 14:57:30 --> Input Class Initialized
INFO - 2024-10-02 14:57:30 --> Language Class Initialized
INFO - 2024-10-02 14:57:30 --> Language Class Initialized
INFO - 2024-10-02 14:57:30 --> Config Class Initialized
INFO - 2024-10-02 14:57:30 --> Loader Class Initialized
INFO - 2024-10-02 14:57:30 --> Helper loaded: url_helper
INFO - 2024-10-02 14:57:30 --> Helper loaded: file_helper
INFO - 2024-10-02 14:57:30 --> Helper loaded: form_helper
INFO - 2024-10-02 14:57:30 --> Helper loaded: my_helper
INFO - 2024-10-02 14:57:31 --> Database Driver Class Initialized
INFO - 2024-10-02 14:57:31 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-02 14:57:31 --> Controller Class Initialized
INFO - 2024-10-02 14:57:38 --> Config Class Initialized
INFO - 2024-10-02 14:57:38 --> Hooks Class Initialized
DEBUG - 2024-10-02 14:57:38 --> UTF-8 Support Enabled
INFO - 2024-10-02 14:57:38 --> Utf8 Class Initialized
INFO - 2024-10-02 14:57:38 --> URI Class Initialized
INFO - 2024-10-02 14:57:38 --> Router Class Initialized
INFO - 2024-10-02 14:57:38 --> Output Class Initialized
INFO - 2024-10-02 14:57:38 --> Security Class Initialized
DEBUG - 2024-10-02 14:57:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-02 14:57:38 --> Input Class Initialized
INFO - 2024-10-02 14:57:38 --> Language Class Initialized
INFO - 2024-10-02 14:57:38 --> Language Class Initialized
INFO - 2024-10-02 14:57:38 --> Config Class Initialized
INFO - 2024-10-02 14:57:38 --> Loader Class Initialized
INFO - 2024-10-02 14:57:38 --> Helper loaded: url_helper
INFO - 2024-10-02 14:57:38 --> Helper loaded: file_helper
INFO - 2024-10-02 14:57:38 --> Helper loaded: form_helper
INFO - 2024-10-02 14:57:38 --> Helper loaded: my_helper
INFO - 2024-10-02 14:57:38 --> Database Driver Class Initialized
INFO - 2024-10-02 14:57:38 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-02 14:57:38 --> Controller Class Initialized
INFO - 2024-10-02 14:57:38 --> Final output sent to browser
DEBUG - 2024-10-02 14:57:38 --> Total execution time: 0.0411
INFO - 2024-10-02 14:57:38 --> Config Class Initialized
INFO - 2024-10-02 14:57:38 --> Hooks Class Initialized
DEBUG - 2024-10-02 14:57:38 --> UTF-8 Support Enabled
INFO - 2024-10-02 14:57:38 --> Utf8 Class Initialized
INFO - 2024-10-02 14:57:38 --> URI Class Initialized
INFO - 2024-10-02 14:57:38 --> Router Class Initialized
INFO - 2024-10-02 14:57:38 --> Output Class Initialized
INFO - 2024-10-02 14:57:38 --> Security Class Initialized
DEBUG - 2024-10-02 14:57:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-02 14:57:38 --> Input Class Initialized
INFO - 2024-10-02 14:57:38 --> Language Class Initialized
INFO - 2024-10-02 14:57:38 --> Language Class Initialized
INFO - 2024-10-02 14:57:38 --> Config Class Initialized
INFO - 2024-10-02 14:57:38 --> Loader Class Initialized
INFO - 2024-10-02 14:57:38 --> Helper loaded: url_helper
INFO - 2024-10-02 14:57:38 --> Helper loaded: file_helper
INFO - 2024-10-02 14:57:38 --> Helper loaded: form_helper
INFO - 2024-10-02 14:57:38 --> Helper loaded: my_helper
INFO - 2024-10-02 14:57:38 --> Database Driver Class Initialized
INFO - 2024-10-02 14:57:38 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-02 14:57:38 --> Controller Class Initialized
INFO - 2024-10-02 14:57:41 --> Config Class Initialized
INFO - 2024-10-02 14:57:41 --> Hooks Class Initialized
DEBUG - 2024-10-02 14:57:41 --> UTF-8 Support Enabled
INFO - 2024-10-02 14:57:41 --> Utf8 Class Initialized
INFO - 2024-10-02 14:57:41 --> URI Class Initialized
INFO - 2024-10-02 14:57:41 --> Router Class Initialized
INFO - 2024-10-02 14:57:41 --> Output Class Initialized
INFO - 2024-10-02 14:57:41 --> Security Class Initialized
DEBUG - 2024-10-02 14:57:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-02 14:57:41 --> Input Class Initialized
INFO - 2024-10-02 14:57:41 --> Language Class Initialized
INFO - 2024-10-02 14:57:41 --> Language Class Initialized
INFO - 2024-10-02 14:57:41 --> Config Class Initialized
INFO - 2024-10-02 14:57:41 --> Loader Class Initialized
INFO - 2024-10-02 14:57:41 --> Helper loaded: url_helper
INFO - 2024-10-02 14:57:41 --> Helper loaded: file_helper
INFO - 2024-10-02 14:57:41 --> Helper loaded: form_helper
INFO - 2024-10-02 14:57:41 --> Helper loaded: my_helper
INFO - 2024-10-02 14:57:41 --> Database Driver Class Initialized
INFO - 2024-10-02 14:57:41 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-02 14:57:41 --> Controller Class Initialized
INFO - 2024-10-02 14:57:41 --> Final output sent to browser
DEBUG - 2024-10-02 14:57:41 --> Total execution time: 0.0956
INFO - 2024-10-02 14:57:41 --> Config Class Initialized
INFO - 2024-10-02 14:57:41 --> Hooks Class Initialized
DEBUG - 2024-10-02 14:57:41 --> UTF-8 Support Enabled
INFO - 2024-10-02 14:57:41 --> Utf8 Class Initialized
INFO - 2024-10-02 14:57:41 --> URI Class Initialized
INFO - 2024-10-02 14:57:41 --> Router Class Initialized
INFO - 2024-10-02 14:57:41 --> Output Class Initialized
INFO - 2024-10-02 14:57:41 --> Security Class Initialized
DEBUG - 2024-10-02 14:57:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-02 14:57:41 --> Input Class Initialized
INFO - 2024-10-02 14:57:41 --> Language Class Initialized
INFO - 2024-10-02 14:57:41 --> Language Class Initialized
INFO - 2024-10-02 14:57:41 --> Config Class Initialized
INFO - 2024-10-02 14:57:41 --> Loader Class Initialized
INFO - 2024-10-02 14:57:41 --> Helper loaded: url_helper
INFO - 2024-10-02 14:57:41 --> Helper loaded: file_helper
INFO - 2024-10-02 14:57:41 --> Helper loaded: form_helper
INFO - 2024-10-02 14:57:41 --> Helper loaded: my_helper
INFO - 2024-10-02 14:57:41 --> Database Driver Class Initialized
INFO - 2024-10-02 14:57:41 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-02 14:57:41 --> Controller Class Initialized
INFO - 2024-10-02 14:57:42 --> Config Class Initialized
INFO - 2024-10-02 14:57:42 --> Hooks Class Initialized
DEBUG - 2024-10-02 14:57:42 --> UTF-8 Support Enabled
INFO - 2024-10-02 14:57:42 --> Utf8 Class Initialized
INFO - 2024-10-02 14:57:42 --> URI Class Initialized
INFO - 2024-10-02 14:57:42 --> Router Class Initialized
INFO - 2024-10-02 14:57:42 --> Output Class Initialized
INFO - 2024-10-02 14:57:42 --> Security Class Initialized
DEBUG - 2024-10-02 14:57:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-02 14:57:42 --> Input Class Initialized
INFO - 2024-10-02 14:57:42 --> Language Class Initialized
INFO - 2024-10-02 14:57:42 --> Language Class Initialized
INFO - 2024-10-02 14:57:42 --> Config Class Initialized
INFO - 2024-10-02 14:57:42 --> Loader Class Initialized
INFO - 2024-10-02 14:57:42 --> Helper loaded: url_helper
INFO - 2024-10-02 14:57:42 --> Helper loaded: file_helper
INFO - 2024-10-02 14:57:42 --> Helper loaded: form_helper
INFO - 2024-10-02 14:57:42 --> Helper loaded: my_helper
INFO - 2024-10-02 14:57:42 --> Database Driver Class Initialized
INFO - 2024-10-02 14:57:42 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-02 14:57:42 --> Controller Class Initialized
INFO - 2024-10-02 14:57:42 --> Final output sent to browser
DEBUG - 2024-10-02 14:57:42 --> Total execution time: 0.1114
INFO - 2024-10-02 14:57:42 --> Config Class Initialized
INFO - 2024-10-02 14:57:42 --> Hooks Class Initialized
DEBUG - 2024-10-02 14:57:42 --> UTF-8 Support Enabled
INFO - 2024-10-02 14:57:42 --> Utf8 Class Initialized
INFO - 2024-10-02 14:57:42 --> URI Class Initialized
INFO - 2024-10-02 14:57:42 --> Router Class Initialized
INFO - 2024-10-02 14:57:42 --> Output Class Initialized
INFO - 2024-10-02 14:57:42 --> Security Class Initialized
DEBUG - 2024-10-02 14:57:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-02 14:57:42 --> Input Class Initialized
INFO - 2024-10-02 14:57:42 --> Language Class Initialized
INFO - 2024-10-02 14:57:43 --> Language Class Initialized
INFO - 2024-10-02 14:57:43 --> Config Class Initialized
INFO - 2024-10-02 14:57:43 --> Loader Class Initialized
INFO - 2024-10-02 14:57:43 --> Helper loaded: url_helper
INFO - 2024-10-02 14:57:43 --> Helper loaded: file_helper
INFO - 2024-10-02 14:57:43 --> Helper loaded: form_helper
INFO - 2024-10-02 14:57:43 --> Helper loaded: my_helper
INFO - 2024-10-02 14:57:43 --> Database Driver Class Initialized
INFO - 2024-10-02 14:57:43 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-02 14:57:43 --> Controller Class Initialized
INFO - 2024-10-02 14:57:44 --> Config Class Initialized
INFO - 2024-10-02 14:57:44 --> Hooks Class Initialized
DEBUG - 2024-10-02 14:57:44 --> UTF-8 Support Enabled
INFO - 2024-10-02 14:57:44 --> Utf8 Class Initialized
INFO - 2024-10-02 14:57:44 --> URI Class Initialized
INFO - 2024-10-02 14:57:44 --> Router Class Initialized
INFO - 2024-10-02 14:57:44 --> Output Class Initialized
INFO - 2024-10-02 14:57:44 --> Security Class Initialized
DEBUG - 2024-10-02 14:57:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-02 14:57:44 --> Input Class Initialized
INFO - 2024-10-02 14:57:44 --> Language Class Initialized
INFO - 2024-10-02 14:57:44 --> Language Class Initialized
INFO - 2024-10-02 14:57:44 --> Config Class Initialized
INFO - 2024-10-02 14:57:44 --> Loader Class Initialized
INFO - 2024-10-02 14:57:44 --> Helper loaded: url_helper
INFO - 2024-10-02 14:57:44 --> Helper loaded: file_helper
INFO - 2024-10-02 14:57:44 --> Helper loaded: form_helper
INFO - 2024-10-02 14:57:44 --> Helper loaded: my_helper
INFO - 2024-10-02 14:57:44 --> Database Driver Class Initialized
INFO - 2024-10-02 14:57:45 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-02 14:57:45 --> Controller Class Initialized
INFO - 2024-10-02 14:57:45 --> Final output sent to browser
DEBUG - 2024-10-02 14:57:45 --> Total execution time: 0.0462
INFO - 2024-10-02 14:57:45 --> Config Class Initialized
INFO - 2024-10-02 14:57:45 --> Hooks Class Initialized
DEBUG - 2024-10-02 14:57:45 --> UTF-8 Support Enabled
INFO - 2024-10-02 14:57:45 --> Utf8 Class Initialized
INFO - 2024-10-02 14:57:45 --> URI Class Initialized
INFO - 2024-10-02 14:57:45 --> Router Class Initialized
INFO - 2024-10-02 14:57:45 --> Output Class Initialized
INFO - 2024-10-02 14:57:45 --> Security Class Initialized
DEBUG - 2024-10-02 14:57:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-02 14:57:45 --> Input Class Initialized
INFO - 2024-10-02 14:57:45 --> Language Class Initialized
INFO - 2024-10-02 14:57:45 --> Language Class Initialized
INFO - 2024-10-02 14:57:45 --> Config Class Initialized
INFO - 2024-10-02 14:57:45 --> Loader Class Initialized
INFO - 2024-10-02 14:57:45 --> Helper loaded: url_helper
INFO - 2024-10-02 14:57:45 --> Helper loaded: file_helper
INFO - 2024-10-02 14:57:45 --> Helper loaded: form_helper
INFO - 2024-10-02 14:57:45 --> Helper loaded: my_helper
INFO - 2024-10-02 14:57:45 --> Database Driver Class Initialized
INFO - 2024-10-02 14:57:45 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-02 14:57:45 --> Controller Class Initialized
INFO - 2024-10-02 14:57:47 --> Config Class Initialized
INFO - 2024-10-02 14:57:47 --> Hooks Class Initialized
DEBUG - 2024-10-02 14:57:47 --> UTF-8 Support Enabled
INFO - 2024-10-02 14:57:47 --> Utf8 Class Initialized
INFO - 2024-10-02 14:57:47 --> URI Class Initialized
INFO - 2024-10-02 14:57:47 --> Router Class Initialized
INFO - 2024-10-02 14:57:47 --> Output Class Initialized
INFO - 2024-10-02 14:57:47 --> Security Class Initialized
DEBUG - 2024-10-02 14:57:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-02 14:57:47 --> Input Class Initialized
INFO - 2024-10-02 14:57:47 --> Language Class Initialized
INFO - 2024-10-02 14:57:47 --> Language Class Initialized
INFO - 2024-10-02 14:57:47 --> Config Class Initialized
INFO - 2024-10-02 14:57:47 --> Loader Class Initialized
INFO - 2024-10-02 14:57:47 --> Helper loaded: url_helper
INFO - 2024-10-02 14:57:47 --> Helper loaded: file_helper
INFO - 2024-10-02 14:57:47 --> Helper loaded: form_helper
INFO - 2024-10-02 14:57:47 --> Helper loaded: my_helper
INFO - 2024-10-02 14:57:47 --> Database Driver Class Initialized
INFO - 2024-10-02 14:57:47 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-02 14:57:47 --> Controller Class Initialized
INFO - 2024-10-02 14:57:47 --> Final output sent to browser
DEBUG - 2024-10-02 14:57:47 --> Total execution time: 0.0347
INFO - 2024-10-02 14:57:47 --> Config Class Initialized
INFO - 2024-10-02 14:57:47 --> Hooks Class Initialized
DEBUG - 2024-10-02 14:57:47 --> UTF-8 Support Enabled
INFO - 2024-10-02 14:57:47 --> Utf8 Class Initialized
INFO - 2024-10-02 14:57:47 --> URI Class Initialized
INFO - 2024-10-02 14:57:47 --> Router Class Initialized
INFO - 2024-10-02 14:57:47 --> Output Class Initialized
INFO - 2024-10-02 14:57:47 --> Security Class Initialized
DEBUG - 2024-10-02 14:57:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-02 14:57:47 --> Input Class Initialized
INFO - 2024-10-02 14:57:47 --> Language Class Initialized
INFO - 2024-10-02 14:57:47 --> Language Class Initialized
INFO - 2024-10-02 14:57:47 --> Config Class Initialized
INFO - 2024-10-02 14:57:47 --> Loader Class Initialized
INFO - 2024-10-02 14:57:47 --> Helper loaded: url_helper
INFO - 2024-10-02 14:57:47 --> Helper loaded: file_helper
INFO - 2024-10-02 14:57:47 --> Helper loaded: form_helper
INFO - 2024-10-02 14:57:47 --> Helper loaded: my_helper
INFO - 2024-10-02 14:57:47 --> Database Driver Class Initialized
INFO - 2024-10-02 14:57:47 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-02 14:57:47 --> Controller Class Initialized
INFO - 2024-10-02 14:57:48 --> Config Class Initialized
INFO - 2024-10-02 14:57:48 --> Hooks Class Initialized
DEBUG - 2024-10-02 14:57:48 --> UTF-8 Support Enabled
INFO - 2024-10-02 14:57:48 --> Utf8 Class Initialized
INFO - 2024-10-02 14:57:48 --> URI Class Initialized
INFO - 2024-10-02 14:57:48 --> Router Class Initialized
INFO - 2024-10-02 14:57:48 --> Output Class Initialized
INFO - 2024-10-02 14:57:48 --> Security Class Initialized
DEBUG - 2024-10-02 14:57:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-02 14:57:48 --> Input Class Initialized
INFO - 2024-10-02 14:57:48 --> Language Class Initialized
INFO - 2024-10-02 14:57:48 --> Language Class Initialized
INFO - 2024-10-02 14:57:48 --> Config Class Initialized
INFO - 2024-10-02 14:57:48 --> Loader Class Initialized
INFO - 2024-10-02 14:57:48 --> Helper loaded: url_helper
INFO - 2024-10-02 14:57:48 --> Helper loaded: file_helper
INFO - 2024-10-02 14:57:48 --> Helper loaded: form_helper
INFO - 2024-10-02 14:57:48 --> Helper loaded: my_helper
INFO - 2024-10-02 14:57:48 --> Database Driver Class Initialized
INFO - 2024-10-02 14:57:48 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-02 14:57:48 --> Controller Class Initialized
INFO - 2024-10-02 14:57:48 --> Final output sent to browser
DEBUG - 2024-10-02 14:57:48 --> Total execution time: 0.0312
INFO - 2024-10-02 14:57:58 --> Config Class Initialized
INFO - 2024-10-02 14:57:58 --> Hooks Class Initialized
DEBUG - 2024-10-02 14:57:58 --> UTF-8 Support Enabled
INFO - 2024-10-02 14:57:58 --> Utf8 Class Initialized
INFO - 2024-10-02 14:57:58 --> URI Class Initialized
INFO - 2024-10-02 14:57:58 --> Router Class Initialized
INFO - 2024-10-02 14:57:58 --> Output Class Initialized
INFO - 2024-10-02 14:57:58 --> Security Class Initialized
DEBUG - 2024-10-02 14:57:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-02 14:57:58 --> Input Class Initialized
INFO - 2024-10-02 14:57:58 --> Language Class Initialized
INFO - 2024-10-02 14:57:58 --> Language Class Initialized
INFO - 2024-10-02 14:57:58 --> Config Class Initialized
INFO - 2024-10-02 14:57:58 --> Loader Class Initialized
INFO - 2024-10-02 14:57:58 --> Helper loaded: url_helper
INFO - 2024-10-02 14:57:58 --> Helper loaded: file_helper
INFO - 2024-10-02 14:57:58 --> Helper loaded: form_helper
INFO - 2024-10-02 14:57:58 --> Helper loaded: my_helper
INFO - 2024-10-02 14:57:58 --> Database Driver Class Initialized
INFO - 2024-10-02 14:57:58 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-02 14:57:58 --> Controller Class Initialized
INFO - 2024-10-02 14:57:58 --> Final output sent to browser
DEBUG - 2024-10-02 14:57:58 --> Total execution time: 0.0773
INFO - 2024-10-02 14:57:58 --> Config Class Initialized
INFO - 2024-10-02 14:57:58 --> Hooks Class Initialized
DEBUG - 2024-10-02 14:57:58 --> UTF-8 Support Enabled
INFO - 2024-10-02 14:57:58 --> Utf8 Class Initialized
INFO - 2024-10-02 14:57:58 --> URI Class Initialized
INFO - 2024-10-02 14:57:58 --> Router Class Initialized
INFO - 2024-10-02 14:57:58 --> Output Class Initialized
INFO - 2024-10-02 14:57:58 --> Security Class Initialized
DEBUG - 2024-10-02 14:57:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-02 14:57:58 --> Input Class Initialized
INFO - 2024-10-02 14:57:58 --> Language Class Initialized
INFO - 2024-10-02 14:57:58 --> Language Class Initialized
INFO - 2024-10-02 14:57:58 --> Config Class Initialized
INFO - 2024-10-02 14:57:58 --> Loader Class Initialized
INFO - 2024-10-02 14:57:58 --> Helper loaded: url_helper
INFO - 2024-10-02 14:57:58 --> Helper loaded: file_helper
INFO - 2024-10-02 14:57:58 --> Helper loaded: form_helper
INFO - 2024-10-02 14:57:58 --> Helper loaded: my_helper
INFO - 2024-10-02 14:57:58 --> Database Driver Class Initialized
INFO - 2024-10-02 14:57:58 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-02 14:57:58 --> Controller Class Initialized
INFO - 2024-10-02 15:05:38 --> Config Class Initialized
INFO - 2024-10-02 15:05:38 --> Hooks Class Initialized
DEBUG - 2024-10-02 15:05:38 --> UTF-8 Support Enabled
INFO - 2024-10-02 15:05:38 --> Utf8 Class Initialized
INFO - 2024-10-02 15:05:38 --> URI Class Initialized
INFO - 2024-10-02 15:05:38 --> Router Class Initialized
INFO - 2024-10-02 15:05:38 --> Output Class Initialized
INFO - 2024-10-02 15:05:38 --> Security Class Initialized
DEBUG - 2024-10-02 15:05:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-02 15:05:38 --> Input Class Initialized
INFO - 2024-10-02 15:05:38 --> Language Class Initialized
INFO - 2024-10-02 15:05:38 --> Language Class Initialized
INFO - 2024-10-02 15:05:38 --> Config Class Initialized
INFO - 2024-10-02 15:05:38 --> Loader Class Initialized
INFO - 2024-10-02 15:05:38 --> Helper loaded: url_helper
INFO - 2024-10-02 15:05:38 --> Helper loaded: file_helper
INFO - 2024-10-02 15:05:38 --> Helper loaded: form_helper
INFO - 2024-10-02 15:05:38 --> Helper loaded: my_helper
INFO - 2024-10-02 15:05:39 --> Database Driver Class Initialized
INFO - 2024-10-02 15:05:39 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-02 15:05:39 --> Controller Class Initialized
DEBUG - 2024-10-02 15:05:39 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/view_mapel/views/v_view_mapel.php
DEBUG - 2024-10-02 15:05:39 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-10-02 15:05:39 --> Final output sent to browser
DEBUG - 2024-10-02 15:05:39 --> Total execution time: 0.5564
INFO - 2024-10-02 15:05:42 --> Config Class Initialized
INFO - 2024-10-02 15:05:42 --> Hooks Class Initialized
DEBUG - 2024-10-02 15:05:42 --> UTF-8 Support Enabled
INFO - 2024-10-02 15:05:42 --> Utf8 Class Initialized
INFO - 2024-10-02 15:05:42 --> URI Class Initialized
INFO - 2024-10-02 15:05:42 --> Router Class Initialized
INFO - 2024-10-02 15:05:42 --> Output Class Initialized
INFO - 2024-10-02 15:05:42 --> Security Class Initialized
DEBUG - 2024-10-02 15:05:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-02 15:05:42 --> Input Class Initialized
INFO - 2024-10-02 15:05:42 --> Language Class Initialized
INFO - 2024-10-02 15:05:42 --> Language Class Initialized
INFO - 2024-10-02 15:05:42 --> Config Class Initialized
INFO - 2024-10-02 15:05:42 --> Loader Class Initialized
INFO - 2024-10-02 15:05:42 --> Helper loaded: url_helper
INFO - 2024-10-02 15:05:42 --> Helper loaded: file_helper
INFO - 2024-10-02 15:05:42 --> Helper loaded: form_helper
INFO - 2024-10-02 15:05:42 --> Helper loaded: my_helper
INFO - 2024-10-02 15:05:42 --> Database Driver Class Initialized
INFO - 2024-10-02 15:05:42 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-02 15:05:42 --> Controller Class Initialized
DEBUG - 2024-10-02 15:05:42 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/views/list.php
DEBUG - 2024-10-02 15:05:42 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-10-02 15:05:42 --> Final output sent to browser
DEBUG - 2024-10-02 15:05:42 --> Total execution time: 0.0332
INFO - 2024-10-02 15:05:42 --> Config Class Initialized
INFO - 2024-10-02 15:05:42 --> Hooks Class Initialized
DEBUG - 2024-10-02 15:05:42 --> UTF-8 Support Enabled
INFO - 2024-10-02 15:05:42 --> Utf8 Class Initialized
INFO - 2024-10-02 15:05:42 --> URI Class Initialized
INFO - 2024-10-02 15:05:42 --> Router Class Initialized
INFO - 2024-10-02 15:05:42 --> Output Class Initialized
INFO - 2024-10-02 15:05:42 --> Security Class Initialized
DEBUG - 2024-10-02 15:05:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-02 15:05:42 --> Input Class Initialized
INFO - 2024-10-02 15:05:42 --> Language Class Initialized
INFO - 2024-10-02 15:05:42 --> Language Class Initialized
INFO - 2024-10-02 15:05:42 --> Config Class Initialized
INFO - 2024-10-02 15:05:42 --> Loader Class Initialized
INFO - 2024-10-02 15:05:42 --> Helper loaded: url_helper
INFO - 2024-10-02 15:05:42 --> Helper loaded: file_helper
INFO - 2024-10-02 15:05:42 --> Helper loaded: form_helper
INFO - 2024-10-02 15:05:42 --> Helper loaded: my_helper
INFO - 2024-10-02 15:05:42 --> Database Driver Class Initialized
INFO - 2024-10-02 15:05:42 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-02 15:05:42 --> Controller Class Initialized
INFO - 2024-10-02 15:05:44 --> Config Class Initialized
INFO - 2024-10-02 15:05:44 --> Hooks Class Initialized
DEBUG - 2024-10-02 15:05:44 --> UTF-8 Support Enabled
INFO - 2024-10-02 15:05:44 --> Utf8 Class Initialized
INFO - 2024-10-02 15:05:44 --> URI Class Initialized
INFO - 2024-10-02 15:05:44 --> Router Class Initialized
INFO - 2024-10-02 15:05:44 --> Output Class Initialized
INFO - 2024-10-02 15:05:44 --> Security Class Initialized
DEBUG - 2024-10-02 15:05:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-02 15:05:44 --> Input Class Initialized
INFO - 2024-10-02 15:05:44 --> Language Class Initialized
INFO - 2024-10-02 15:05:44 --> Language Class Initialized
INFO - 2024-10-02 15:05:44 --> Config Class Initialized
INFO - 2024-10-02 15:05:44 --> Loader Class Initialized
INFO - 2024-10-02 15:05:44 --> Helper loaded: url_helper
INFO - 2024-10-02 15:05:44 --> Helper loaded: file_helper
INFO - 2024-10-02 15:05:44 --> Helper loaded: form_helper
INFO - 2024-10-02 15:05:44 --> Helper loaded: my_helper
INFO - 2024-10-02 15:05:44 --> Database Driver Class Initialized
INFO - 2024-10-02 15:05:44 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-02 15:05:44 --> Controller Class Initialized
DEBUG - 2024-10-02 15:05:44 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/views/form.php
DEBUG - 2024-10-02 15:05:44 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-10-02 15:05:44 --> Final output sent to browser
DEBUG - 2024-10-02 15:05:44 --> Total execution time: 0.0667
INFO - 2024-10-02 15:05:49 --> Config Class Initialized
INFO - 2024-10-02 15:05:49 --> Hooks Class Initialized
DEBUG - 2024-10-02 15:05:49 --> UTF-8 Support Enabled
INFO - 2024-10-02 15:05:49 --> Utf8 Class Initialized
INFO - 2024-10-02 15:05:49 --> URI Class Initialized
INFO - 2024-10-02 15:05:49 --> Router Class Initialized
INFO - 2024-10-02 15:05:49 --> Output Class Initialized
INFO - 2024-10-02 15:05:49 --> Security Class Initialized
DEBUG - 2024-10-02 15:05:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-02 15:05:49 --> Input Class Initialized
INFO - 2024-10-02 15:05:49 --> Language Class Initialized
INFO - 2024-10-02 15:05:49 --> Language Class Initialized
INFO - 2024-10-02 15:05:49 --> Config Class Initialized
INFO - 2024-10-02 15:05:49 --> Loader Class Initialized
INFO - 2024-10-02 15:05:49 --> Helper loaded: url_helper
INFO - 2024-10-02 15:05:49 --> Helper loaded: file_helper
INFO - 2024-10-02 15:05:49 --> Helper loaded: form_helper
INFO - 2024-10-02 15:05:49 --> Helper loaded: my_helper
INFO - 2024-10-02 15:05:49 --> Database Driver Class Initialized
INFO - 2024-10-02 15:05:49 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-02 15:05:49 --> Controller Class Initialized
INFO - 2024-10-02 15:05:49 --> Config Class Initialized
INFO - 2024-10-02 15:05:49 --> Hooks Class Initialized
DEBUG - 2024-10-02 15:05:49 --> UTF-8 Support Enabled
INFO - 2024-10-02 15:05:49 --> Utf8 Class Initialized
INFO - 2024-10-02 15:05:49 --> URI Class Initialized
INFO - 2024-10-02 15:05:49 --> Router Class Initialized
INFO - 2024-10-02 15:05:49 --> Output Class Initialized
INFO - 2024-10-02 15:05:49 --> Security Class Initialized
DEBUG - 2024-10-02 15:05:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-02 15:05:49 --> Input Class Initialized
INFO - 2024-10-02 15:05:49 --> Language Class Initialized
INFO - 2024-10-02 15:05:49 --> Language Class Initialized
INFO - 2024-10-02 15:05:49 --> Config Class Initialized
INFO - 2024-10-02 15:05:49 --> Loader Class Initialized
INFO - 2024-10-02 15:05:49 --> Helper loaded: url_helper
INFO - 2024-10-02 15:05:49 --> Helper loaded: file_helper
INFO - 2024-10-02 15:05:49 --> Helper loaded: form_helper
INFO - 2024-10-02 15:05:49 --> Helper loaded: my_helper
INFO - 2024-10-02 15:05:49 --> Database Driver Class Initialized
INFO - 2024-10-02 15:05:49 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-02 15:05:49 --> Controller Class Initialized
DEBUG - 2024-10-02 15:05:49 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/views/list.php
DEBUG - 2024-10-02 15:05:49 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-10-02 15:05:49 --> Final output sent to browser
DEBUG - 2024-10-02 15:05:49 --> Total execution time: 0.0306
INFO - 2024-10-02 15:05:49 --> Config Class Initialized
INFO - 2024-10-02 15:05:49 --> Hooks Class Initialized
DEBUG - 2024-10-02 15:05:49 --> UTF-8 Support Enabled
INFO - 2024-10-02 15:05:49 --> Utf8 Class Initialized
INFO - 2024-10-02 15:05:49 --> URI Class Initialized
INFO - 2024-10-02 15:05:49 --> Router Class Initialized
INFO - 2024-10-02 15:05:49 --> Output Class Initialized
INFO - 2024-10-02 15:05:49 --> Security Class Initialized
DEBUG - 2024-10-02 15:05:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-02 15:05:49 --> Input Class Initialized
INFO - 2024-10-02 15:05:49 --> Language Class Initialized
INFO - 2024-10-02 15:05:49 --> Language Class Initialized
INFO - 2024-10-02 15:05:49 --> Config Class Initialized
INFO - 2024-10-02 15:05:49 --> Loader Class Initialized
INFO - 2024-10-02 15:05:49 --> Helper loaded: url_helper
INFO - 2024-10-02 15:05:49 --> Helper loaded: file_helper
INFO - 2024-10-02 15:05:49 --> Helper loaded: form_helper
INFO - 2024-10-02 15:05:49 --> Helper loaded: my_helper
INFO - 2024-10-02 15:05:49 --> Database Driver Class Initialized
INFO - 2024-10-02 15:05:49 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-02 15:05:49 --> Controller Class Initialized
INFO - 2024-10-02 15:05:52 --> Config Class Initialized
INFO - 2024-10-02 15:05:52 --> Hooks Class Initialized
DEBUG - 2024-10-02 15:05:52 --> UTF-8 Support Enabled
INFO - 2024-10-02 15:05:52 --> Utf8 Class Initialized
INFO - 2024-10-02 15:05:52 --> URI Class Initialized
INFO - 2024-10-02 15:05:52 --> Router Class Initialized
INFO - 2024-10-02 15:05:52 --> Output Class Initialized
INFO - 2024-10-02 15:05:52 --> Security Class Initialized
DEBUG - 2024-10-02 15:05:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-02 15:05:52 --> Input Class Initialized
INFO - 2024-10-02 15:05:52 --> Language Class Initialized
INFO - 2024-10-02 15:05:52 --> Language Class Initialized
INFO - 2024-10-02 15:05:52 --> Config Class Initialized
INFO - 2024-10-02 15:05:52 --> Loader Class Initialized
INFO - 2024-10-02 15:05:52 --> Helper loaded: url_helper
INFO - 2024-10-02 15:05:52 --> Helper loaded: file_helper
INFO - 2024-10-02 15:05:52 --> Helper loaded: form_helper
INFO - 2024-10-02 15:05:52 --> Helper loaded: my_helper
INFO - 2024-10-02 15:05:52 --> Database Driver Class Initialized
INFO - 2024-10-02 15:05:52 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-02 15:05:52 --> Controller Class Initialized
INFO - 2024-10-02 15:05:52 --> Final output sent to browser
DEBUG - 2024-10-02 15:05:52 --> Total execution time: 0.0461
INFO - 2024-10-02 15:06:13 --> Config Class Initialized
INFO - 2024-10-02 15:06:13 --> Hooks Class Initialized
DEBUG - 2024-10-02 15:06:13 --> UTF-8 Support Enabled
INFO - 2024-10-02 15:06:13 --> Utf8 Class Initialized
INFO - 2024-10-02 15:06:13 --> URI Class Initialized
INFO - 2024-10-02 15:06:13 --> Router Class Initialized
INFO - 2024-10-02 15:06:13 --> Output Class Initialized
INFO - 2024-10-02 15:06:13 --> Security Class Initialized
DEBUG - 2024-10-02 15:06:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-02 15:06:13 --> Input Class Initialized
INFO - 2024-10-02 15:06:13 --> Language Class Initialized
INFO - 2024-10-02 15:06:13 --> Language Class Initialized
INFO - 2024-10-02 15:06:13 --> Config Class Initialized
INFO - 2024-10-02 15:06:13 --> Loader Class Initialized
INFO - 2024-10-02 15:06:13 --> Helper loaded: url_helper
INFO - 2024-10-02 15:06:13 --> Helper loaded: file_helper
INFO - 2024-10-02 15:06:13 --> Helper loaded: form_helper
INFO - 2024-10-02 15:06:13 --> Helper loaded: my_helper
INFO - 2024-10-02 15:06:13 --> Database Driver Class Initialized
INFO - 2024-10-02 15:06:13 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-02 15:06:13 --> Controller Class Initialized
DEBUG - 2024-10-02 15:06:13 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/view_mapel/views/v_view_mapel.php
DEBUG - 2024-10-02 15:06:13 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-10-02 15:06:13 --> Final output sent to browser
DEBUG - 2024-10-02 15:06:13 --> Total execution time: 0.0883
INFO - 2024-10-02 15:06:19 --> Config Class Initialized
INFO - 2024-10-02 15:06:19 --> Hooks Class Initialized
DEBUG - 2024-10-02 15:06:19 --> UTF-8 Support Enabled
INFO - 2024-10-02 15:06:19 --> Utf8 Class Initialized
INFO - 2024-10-02 15:06:19 --> URI Class Initialized
INFO - 2024-10-02 15:06:19 --> Router Class Initialized
INFO - 2024-10-02 15:06:19 --> Output Class Initialized
INFO - 2024-10-02 15:06:19 --> Security Class Initialized
DEBUG - 2024-10-02 15:06:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-02 15:06:19 --> Input Class Initialized
INFO - 2024-10-02 15:06:19 --> Language Class Initialized
INFO - 2024-10-02 15:06:19 --> Language Class Initialized
INFO - 2024-10-02 15:06:19 --> Config Class Initialized
INFO - 2024-10-02 15:06:19 --> Loader Class Initialized
INFO - 2024-10-02 15:06:19 --> Helper loaded: url_helper
INFO - 2024-10-02 15:06:19 --> Helper loaded: file_helper
INFO - 2024-10-02 15:06:19 --> Helper loaded: form_helper
INFO - 2024-10-02 15:06:19 --> Helper loaded: my_helper
INFO - 2024-10-02 15:06:19 --> Database Driver Class Initialized
INFO - 2024-10-02 15:06:19 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-02 15:06:19 --> Controller Class Initialized
DEBUG - 2024-10-02 15:06:19 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/views/list.php
DEBUG - 2024-10-02 15:06:19 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-10-02 15:06:19 --> Final output sent to browser
DEBUG - 2024-10-02 15:06:19 --> Total execution time: 0.1247
INFO - 2024-10-02 15:06:19 --> Config Class Initialized
INFO - 2024-10-02 15:06:19 --> Hooks Class Initialized
DEBUG - 2024-10-02 15:06:19 --> UTF-8 Support Enabled
INFO - 2024-10-02 15:06:19 --> Utf8 Class Initialized
INFO - 2024-10-02 15:06:19 --> URI Class Initialized
INFO - 2024-10-02 15:06:19 --> Router Class Initialized
INFO - 2024-10-02 15:06:19 --> Output Class Initialized
INFO - 2024-10-02 15:06:19 --> Security Class Initialized
DEBUG - 2024-10-02 15:06:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-02 15:06:19 --> Input Class Initialized
INFO - 2024-10-02 15:06:19 --> Language Class Initialized
INFO - 2024-10-02 15:06:19 --> Language Class Initialized
INFO - 2024-10-02 15:06:19 --> Config Class Initialized
INFO - 2024-10-02 15:06:19 --> Loader Class Initialized
INFO - 2024-10-02 15:06:19 --> Helper loaded: url_helper
INFO - 2024-10-02 15:06:19 --> Helper loaded: file_helper
INFO - 2024-10-02 15:06:19 --> Helper loaded: form_helper
INFO - 2024-10-02 15:06:19 --> Helper loaded: my_helper
INFO - 2024-10-02 15:06:19 --> Database Driver Class Initialized
INFO - 2024-10-02 15:06:19 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-02 15:06:19 --> Controller Class Initialized
INFO - 2024-10-02 15:06:21 --> Config Class Initialized
INFO - 2024-10-02 15:06:21 --> Hooks Class Initialized
DEBUG - 2024-10-02 15:06:21 --> UTF-8 Support Enabled
INFO - 2024-10-02 15:06:21 --> Utf8 Class Initialized
INFO - 2024-10-02 15:06:21 --> URI Class Initialized
INFO - 2024-10-02 15:06:21 --> Router Class Initialized
INFO - 2024-10-02 15:06:21 --> Output Class Initialized
INFO - 2024-10-02 15:06:21 --> Security Class Initialized
DEBUG - 2024-10-02 15:06:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-02 15:06:21 --> Input Class Initialized
INFO - 2024-10-02 15:06:21 --> Language Class Initialized
INFO - 2024-10-02 15:06:21 --> Language Class Initialized
INFO - 2024-10-02 15:06:21 --> Config Class Initialized
INFO - 2024-10-02 15:06:21 --> Loader Class Initialized
INFO - 2024-10-02 15:06:21 --> Helper loaded: url_helper
INFO - 2024-10-02 15:06:21 --> Helper loaded: file_helper
INFO - 2024-10-02 15:06:21 --> Helper loaded: form_helper
INFO - 2024-10-02 15:06:21 --> Helper loaded: my_helper
INFO - 2024-10-02 15:06:21 --> Database Driver Class Initialized
INFO - 2024-10-02 15:06:21 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-02 15:06:21 --> Controller Class Initialized
INFO - 2024-10-02 15:06:21 --> Final output sent to browser
DEBUG - 2024-10-02 15:06:21 --> Total execution time: 0.0668
INFO - 2024-10-02 15:06:25 --> Config Class Initialized
INFO - 2024-10-02 15:06:25 --> Hooks Class Initialized
DEBUG - 2024-10-02 15:06:25 --> UTF-8 Support Enabled
INFO - 2024-10-02 15:06:25 --> Utf8 Class Initialized
INFO - 2024-10-02 15:06:25 --> URI Class Initialized
INFO - 2024-10-02 15:06:25 --> Router Class Initialized
INFO - 2024-10-02 15:06:25 --> Output Class Initialized
INFO - 2024-10-02 15:06:25 --> Security Class Initialized
DEBUG - 2024-10-02 15:06:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-02 15:06:25 --> Input Class Initialized
INFO - 2024-10-02 15:06:25 --> Language Class Initialized
INFO - 2024-10-02 15:06:25 --> Language Class Initialized
INFO - 2024-10-02 15:06:25 --> Config Class Initialized
INFO - 2024-10-02 15:06:25 --> Loader Class Initialized
INFO - 2024-10-02 15:06:25 --> Helper loaded: url_helper
INFO - 2024-10-02 15:06:25 --> Helper loaded: file_helper
INFO - 2024-10-02 15:06:25 --> Helper loaded: form_helper
INFO - 2024-10-02 15:06:25 --> Helper loaded: my_helper
INFO - 2024-10-02 15:06:25 --> Database Driver Class Initialized
INFO - 2024-10-02 15:06:25 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-02 15:06:25 --> Controller Class Initialized
INFO - 2024-10-02 15:09:30 --> Config Class Initialized
INFO - 2024-10-02 15:09:30 --> Hooks Class Initialized
DEBUG - 2024-10-02 15:09:30 --> UTF-8 Support Enabled
INFO - 2024-10-02 15:09:30 --> Utf8 Class Initialized
INFO - 2024-10-02 15:09:30 --> URI Class Initialized
INFO - 2024-10-02 15:09:30 --> Router Class Initialized
INFO - 2024-10-02 15:09:30 --> Output Class Initialized
INFO - 2024-10-02 15:09:30 --> Security Class Initialized
DEBUG - 2024-10-02 15:09:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-02 15:09:30 --> Input Class Initialized
INFO - 2024-10-02 15:09:30 --> Language Class Initialized
INFO - 2024-10-02 15:09:30 --> Language Class Initialized
INFO - 2024-10-02 15:09:30 --> Config Class Initialized
INFO - 2024-10-02 15:09:30 --> Loader Class Initialized
INFO - 2024-10-02 15:09:30 --> Helper loaded: url_helper
INFO - 2024-10-02 15:09:30 --> Helper loaded: file_helper
INFO - 2024-10-02 15:09:30 --> Helper loaded: form_helper
INFO - 2024-10-02 15:09:30 --> Helper loaded: my_helper
INFO - 2024-10-02 15:09:30 --> Database Driver Class Initialized
INFO - 2024-10-02 15:09:30 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-02 15:09:30 --> Controller Class Initialized
DEBUG - 2024-10-02 15:09:30 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/views/form.php
DEBUG - 2024-10-02 15:09:30 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-10-02 15:09:30 --> Final output sent to browser
DEBUG - 2024-10-02 15:09:30 --> Total execution time: 0.0677
INFO - 2024-10-02 15:09:35 --> Config Class Initialized
INFO - 2024-10-02 15:09:35 --> Hooks Class Initialized
DEBUG - 2024-10-02 15:09:35 --> UTF-8 Support Enabled
INFO - 2024-10-02 15:09:35 --> Utf8 Class Initialized
INFO - 2024-10-02 15:09:35 --> URI Class Initialized
INFO - 2024-10-02 15:09:35 --> Router Class Initialized
INFO - 2024-10-02 15:09:35 --> Output Class Initialized
INFO - 2024-10-02 15:09:35 --> Security Class Initialized
DEBUG - 2024-10-02 15:09:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-02 15:09:35 --> Input Class Initialized
INFO - 2024-10-02 15:09:35 --> Language Class Initialized
INFO - 2024-10-02 15:09:35 --> Language Class Initialized
INFO - 2024-10-02 15:09:35 --> Config Class Initialized
INFO - 2024-10-02 15:09:35 --> Loader Class Initialized
INFO - 2024-10-02 15:09:35 --> Helper loaded: url_helper
INFO - 2024-10-02 15:09:35 --> Helper loaded: file_helper
INFO - 2024-10-02 15:09:35 --> Helper loaded: form_helper
INFO - 2024-10-02 15:09:35 --> Helper loaded: my_helper
INFO - 2024-10-02 15:09:35 --> Database Driver Class Initialized
INFO - 2024-10-02 15:09:35 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-02 15:09:35 --> Controller Class Initialized
INFO - 2024-10-02 15:09:36 --> Config Class Initialized
INFO - 2024-10-02 15:09:36 --> Hooks Class Initialized
DEBUG - 2024-10-02 15:09:36 --> UTF-8 Support Enabled
INFO - 2024-10-02 15:09:36 --> Utf8 Class Initialized
INFO - 2024-10-02 15:09:36 --> URI Class Initialized
INFO - 2024-10-02 15:09:36 --> Router Class Initialized
INFO - 2024-10-02 15:09:36 --> Output Class Initialized
INFO - 2024-10-02 15:09:36 --> Security Class Initialized
DEBUG - 2024-10-02 15:09:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-02 15:09:36 --> Input Class Initialized
INFO - 2024-10-02 15:09:36 --> Language Class Initialized
INFO - 2024-10-02 15:09:36 --> Language Class Initialized
INFO - 2024-10-02 15:09:36 --> Config Class Initialized
INFO - 2024-10-02 15:09:36 --> Loader Class Initialized
INFO - 2024-10-02 15:09:36 --> Helper loaded: url_helper
INFO - 2024-10-02 15:09:36 --> Helper loaded: file_helper
INFO - 2024-10-02 15:09:36 --> Helper loaded: form_helper
INFO - 2024-10-02 15:09:36 --> Helper loaded: my_helper
INFO - 2024-10-02 15:09:36 --> Database Driver Class Initialized
INFO - 2024-10-02 15:09:36 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-02 15:09:36 --> Controller Class Initialized
DEBUG - 2024-10-02 15:09:36 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/views/list.php
DEBUG - 2024-10-02 15:09:36 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-10-02 15:09:36 --> Final output sent to browser
DEBUG - 2024-10-02 15:09:36 --> Total execution time: 0.0316
INFO - 2024-10-02 15:09:36 --> Config Class Initialized
INFO - 2024-10-02 15:09:36 --> Hooks Class Initialized
DEBUG - 2024-10-02 15:09:36 --> UTF-8 Support Enabled
INFO - 2024-10-02 15:09:36 --> Utf8 Class Initialized
INFO - 2024-10-02 15:09:36 --> URI Class Initialized
INFO - 2024-10-02 15:09:36 --> Router Class Initialized
INFO - 2024-10-02 15:09:36 --> Output Class Initialized
INFO - 2024-10-02 15:09:36 --> Security Class Initialized
DEBUG - 2024-10-02 15:09:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-02 15:09:36 --> Input Class Initialized
INFO - 2024-10-02 15:09:36 --> Language Class Initialized
INFO - 2024-10-02 15:09:36 --> Language Class Initialized
INFO - 2024-10-02 15:09:36 --> Config Class Initialized
INFO - 2024-10-02 15:09:36 --> Loader Class Initialized
INFO - 2024-10-02 15:09:36 --> Helper loaded: url_helper
INFO - 2024-10-02 15:09:36 --> Helper loaded: file_helper
INFO - 2024-10-02 15:09:36 --> Helper loaded: form_helper
INFO - 2024-10-02 15:09:36 --> Helper loaded: my_helper
INFO - 2024-10-02 15:09:36 --> Database Driver Class Initialized
INFO - 2024-10-02 15:09:36 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-02 15:09:36 --> Controller Class Initialized
INFO - 2024-10-02 15:09:39 --> Config Class Initialized
INFO - 2024-10-02 15:09:39 --> Hooks Class Initialized
DEBUG - 2024-10-02 15:09:39 --> UTF-8 Support Enabled
INFO - 2024-10-02 15:09:39 --> Utf8 Class Initialized
INFO - 2024-10-02 15:09:39 --> URI Class Initialized
INFO - 2024-10-02 15:09:39 --> Router Class Initialized
INFO - 2024-10-02 15:09:39 --> Output Class Initialized
INFO - 2024-10-02 15:09:39 --> Security Class Initialized
DEBUG - 2024-10-02 15:09:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-02 15:09:39 --> Input Class Initialized
INFO - 2024-10-02 15:09:39 --> Language Class Initialized
INFO - 2024-10-02 15:09:39 --> Language Class Initialized
INFO - 2024-10-02 15:09:39 --> Config Class Initialized
INFO - 2024-10-02 15:09:39 --> Loader Class Initialized
INFO - 2024-10-02 15:09:39 --> Helper loaded: url_helper
INFO - 2024-10-02 15:09:39 --> Helper loaded: file_helper
INFO - 2024-10-02 15:09:39 --> Helper loaded: form_helper
INFO - 2024-10-02 15:09:39 --> Helper loaded: my_helper
INFO - 2024-10-02 15:09:39 --> Database Driver Class Initialized
INFO - 2024-10-02 15:09:39 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-02 15:09:39 --> Controller Class Initialized
DEBUG - 2024-10-02 15:09:39 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/list.php
DEBUG - 2024-10-02 15:09:39 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-10-02 15:09:39 --> Final output sent to browser
DEBUG - 2024-10-02 15:09:39 --> Total execution time: 0.0454
INFO - 2024-10-02 15:09:41 --> Config Class Initialized
INFO - 2024-10-02 15:09:41 --> Hooks Class Initialized
DEBUG - 2024-10-02 15:09:41 --> UTF-8 Support Enabled
INFO - 2024-10-02 15:09:41 --> Utf8 Class Initialized
INFO - 2024-10-02 15:09:41 --> URI Class Initialized
INFO - 2024-10-02 15:09:41 --> Router Class Initialized
INFO - 2024-10-02 15:09:41 --> Output Class Initialized
INFO - 2024-10-02 15:09:41 --> Security Class Initialized
DEBUG - 2024-10-02 15:09:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-02 15:09:41 --> Input Class Initialized
INFO - 2024-10-02 15:09:41 --> Language Class Initialized
INFO - 2024-10-02 15:09:41 --> Language Class Initialized
INFO - 2024-10-02 15:09:41 --> Config Class Initialized
INFO - 2024-10-02 15:09:41 --> Loader Class Initialized
INFO - 2024-10-02 15:09:41 --> Helper loaded: url_helper
INFO - 2024-10-02 15:09:41 --> Helper loaded: file_helper
INFO - 2024-10-02 15:09:41 --> Helper loaded: form_helper
INFO - 2024-10-02 15:09:41 --> Helper loaded: my_helper
INFO - 2024-10-02 15:09:41 --> Database Driver Class Initialized
INFO - 2024-10-02 15:09:41 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-02 15:09:41 --> Controller Class Initialized
ERROR - 2024-10-02 15:09:41 --> Severity: Notice --> Undefined offset: 15 /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1698
ERROR - 2024-10-02 15:09:41 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1698
ERROR - 2024-10-02 15:09:41 --> Severity: Warning --> Invalid argument supplied for foreach() /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1698
ERROR - 2024-10-02 15:09:41 --> Severity: Notice --> Undefined offset: 16 /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1735
ERROR - 2024-10-02 15:09:41 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1735
ERROR - 2024-10-02 15:09:41 --> Severity: Warning --> Invalid argument supplied for foreach() /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1735
ERROR - 2024-10-02 15:09:41 --> Severity: Notice --> Undefined offset: 17 /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1773
ERROR - 2024-10-02 15:09:41 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1773
ERROR - 2024-10-02 15:09:41 --> Severity: Warning --> Invalid argument supplied for foreach() /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1773
DEBUG - 2024-10-02 15:09:41 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php
INFO - 2024-10-02 15:09:44 --> Final output sent to browser
DEBUG - 2024-10-02 15:09:44 --> Total execution time: 3.0203
INFO - 2024-10-02 15:11:05 --> Config Class Initialized
INFO - 2024-10-02 15:11:05 --> Hooks Class Initialized
DEBUG - 2024-10-02 15:11:05 --> UTF-8 Support Enabled
INFO - 2024-10-02 15:11:05 --> Utf8 Class Initialized
INFO - 2024-10-02 15:11:05 --> URI Class Initialized
INFO - 2024-10-02 15:11:05 --> Router Class Initialized
INFO - 2024-10-02 15:11:05 --> Output Class Initialized
INFO - 2024-10-02 15:11:05 --> Security Class Initialized
DEBUG - 2024-10-02 15:11:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-02 15:11:05 --> Input Class Initialized
INFO - 2024-10-02 15:11:05 --> Language Class Initialized
INFO - 2024-10-02 15:11:05 --> Language Class Initialized
INFO - 2024-10-02 15:11:05 --> Config Class Initialized
INFO - 2024-10-02 15:11:05 --> Loader Class Initialized
INFO - 2024-10-02 15:11:05 --> Helper loaded: url_helper
INFO - 2024-10-02 15:11:05 --> Helper loaded: file_helper
INFO - 2024-10-02 15:11:05 --> Helper loaded: form_helper
INFO - 2024-10-02 15:11:05 --> Helper loaded: my_helper
INFO - 2024-10-02 15:11:05 --> Database Driver Class Initialized
INFO - 2024-10-02 15:11:05 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-02 15:11:05 --> Controller Class Initialized
DEBUG - 2024-10-02 15:11:05 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/view_mapel/views/v_view_mapel.php
DEBUG - 2024-10-02 15:11:05 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-10-02 15:11:05 --> Final output sent to browser
DEBUG - 2024-10-02 15:11:05 --> Total execution time: 0.0317
INFO - 2024-10-02 15:11:07 --> Config Class Initialized
INFO - 2024-10-02 15:11:07 --> Hooks Class Initialized
DEBUG - 2024-10-02 15:11:07 --> UTF-8 Support Enabled
INFO - 2024-10-02 15:11:07 --> Utf8 Class Initialized
INFO - 2024-10-02 15:11:07 --> URI Class Initialized
INFO - 2024-10-02 15:11:07 --> Router Class Initialized
INFO - 2024-10-02 15:11:07 --> Output Class Initialized
INFO - 2024-10-02 15:11:07 --> Security Class Initialized
DEBUG - 2024-10-02 15:11:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-02 15:11:07 --> Input Class Initialized
INFO - 2024-10-02 15:11:07 --> Language Class Initialized
INFO - 2024-10-02 15:11:07 --> Language Class Initialized
INFO - 2024-10-02 15:11:07 --> Config Class Initialized
INFO - 2024-10-02 15:11:07 --> Loader Class Initialized
INFO - 2024-10-02 15:11:07 --> Helper loaded: url_helper
INFO - 2024-10-02 15:11:07 --> Helper loaded: file_helper
INFO - 2024-10-02 15:11:07 --> Helper loaded: form_helper
INFO - 2024-10-02 15:11:07 --> Helper loaded: my_helper
INFO - 2024-10-02 15:11:07 --> Database Driver Class Initialized
INFO - 2024-10-02 15:11:07 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-02 15:11:07 --> Controller Class Initialized
DEBUG - 2024-10-02 15:11:07 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/views/list.php
DEBUG - 2024-10-02 15:11:07 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-10-02 15:11:07 --> Final output sent to browser
DEBUG - 2024-10-02 15:11:07 --> Total execution time: 0.0846
INFO - 2024-10-02 15:11:08 --> Config Class Initialized
INFO - 2024-10-02 15:11:08 --> Hooks Class Initialized
DEBUG - 2024-10-02 15:11:08 --> UTF-8 Support Enabled
INFO - 2024-10-02 15:11:08 --> Utf8 Class Initialized
INFO - 2024-10-02 15:11:08 --> URI Class Initialized
INFO - 2024-10-02 15:11:08 --> Router Class Initialized
INFO - 2024-10-02 15:11:08 --> Output Class Initialized
INFO - 2024-10-02 15:11:08 --> Security Class Initialized
DEBUG - 2024-10-02 15:11:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-02 15:11:08 --> Input Class Initialized
INFO - 2024-10-02 15:11:08 --> Language Class Initialized
INFO - 2024-10-02 15:11:08 --> Language Class Initialized
INFO - 2024-10-02 15:11:08 --> Config Class Initialized
INFO - 2024-10-02 15:11:08 --> Loader Class Initialized
INFO - 2024-10-02 15:11:08 --> Helper loaded: url_helper
INFO - 2024-10-02 15:11:08 --> Helper loaded: file_helper
INFO - 2024-10-02 15:11:08 --> Helper loaded: form_helper
INFO - 2024-10-02 15:11:08 --> Helper loaded: my_helper
INFO - 2024-10-02 15:11:08 --> Database Driver Class Initialized
INFO - 2024-10-02 15:11:08 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-02 15:11:08 --> Controller Class Initialized
INFO - 2024-10-02 15:11:09 --> Config Class Initialized
INFO - 2024-10-02 15:11:09 --> Hooks Class Initialized
DEBUG - 2024-10-02 15:11:09 --> UTF-8 Support Enabled
INFO - 2024-10-02 15:11:09 --> Utf8 Class Initialized
INFO - 2024-10-02 15:11:09 --> URI Class Initialized
INFO - 2024-10-02 15:11:09 --> Router Class Initialized
INFO - 2024-10-02 15:11:09 --> Output Class Initialized
INFO - 2024-10-02 15:11:09 --> Security Class Initialized
DEBUG - 2024-10-02 15:11:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-02 15:11:09 --> Input Class Initialized
INFO - 2024-10-02 15:11:09 --> Language Class Initialized
INFO - 2024-10-02 15:11:09 --> Language Class Initialized
INFO - 2024-10-02 15:11:09 --> Config Class Initialized
INFO - 2024-10-02 15:11:09 --> Loader Class Initialized
INFO - 2024-10-02 15:11:09 --> Helper loaded: url_helper
INFO - 2024-10-02 15:11:09 --> Helper loaded: file_helper
INFO - 2024-10-02 15:11:09 --> Helper loaded: form_helper
INFO - 2024-10-02 15:11:09 --> Helper loaded: my_helper
INFO - 2024-10-02 15:11:09 --> Database Driver Class Initialized
INFO - 2024-10-02 15:11:09 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-02 15:11:09 --> Controller Class Initialized
INFO - 2024-10-02 15:11:09 --> Final output sent to browser
DEBUG - 2024-10-02 15:11:09 --> Total execution time: 0.0395
INFO - 2024-10-02 15:11:12 --> Config Class Initialized
INFO - 2024-10-02 15:11:12 --> Hooks Class Initialized
DEBUG - 2024-10-02 15:11:12 --> UTF-8 Support Enabled
INFO - 2024-10-02 15:11:12 --> Utf8 Class Initialized
INFO - 2024-10-02 15:11:12 --> URI Class Initialized
INFO - 2024-10-02 15:11:12 --> Router Class Initialized
INFO - 2024-10-02 15:11:12 --> Output Class Initialized
INFO - 2024-10-02 15:11:12 --> Security Class Initialized
DEBUG - 2024-10-02 15:11:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-02 15:11:12 --> Input Class Initialized
INFO - 2024-10-02 15:11:12 --> Language Class Initialized
INFO - 2024-10-02 15:11:12 --> Language Class Initialized
INFO - 2024-10-02 15:11:12 --> Config Class Initialized
INFO - 2024-10-02 15:11:12 --> Loader Class Initialized
INFO - 2024-10-02 15:11:12 --> Helper loaded: url_helper
INFO - 2024-10-02 15:11:12 --> Helper loaded: file_helper
INFO - 2024-10-02 15:11:12 --> Helper loaded: form_helper
INFO - 2024-10-02 15:11:12 --> Helper loaded: my_helper
INFO - 2024-10-02 15:11:12 --> Database Driver Class Initialized
INFO - 2024-10-02 15:11:12 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-02 15:11:12 --> Controller Class Initialized
INFO - 2024-10-02 15:13:16 --> Config Class Initialized
INFO - 2024-10-02 15:13:16 --> Hooks Class Initialized
DEBUG - 2024-10-02 15:13:16 --> UTF-8 Support Enabled
INFO - 2024-10-02 15:13:16 --> Utf8 Class Initialized
INFO - 2024-10-02 15:13:16 --> URI Class Initialized
INFO - 2024-10-02 15:13:16 --> Router Class Initialized
INFO - 2024-10-02 15:13:16 --> Output Class Initialized
INFO - 2024-10-02 15:13:16 --> Security Class Initialized
DEBUG - 2024-10-02 15:13:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-02 15:13:16 --> Input Class Initialized
INFO - 2024-10-02 15:13:16 --> Language Class Initialized
INFO - 2024-10-02 15:13:16 --> Language Class Initialized
INFO - 2024-10-02 15:13:16 --> Config Class Initialized
INFO - 2024-10-02 15:13:16 --> Loader Class Initialized
INFO - 2024-10-02 15:13:16 --> Helper loaded: url_helper
INFO - 2024-10-02 15:13:16 --> Helper loaded: file_helper
INFO - 2024-10-02 15:13:16 --> Helper loaded: form_helper
INFO - 2024-10-02 15:13:16 --> Helper loaded: my_helper
INFO - 2024-10-02 15:13:16 --> Database Driver Class Initialized
INFO - 2024-10-02 15:13:16 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-02 15:13:16 --> Controller Class Initialized
DEBUG - 2024-10-02 15:13:16 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/views/form.php
DEBUG - 2024-10-02 15:13:16 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-10-02 15:13:16 --> Final output sent to browser
DEBUG - 2024-10-02 15:13:16 --> Total execution time: 0.0338
INFO - 2024-10-02 15:13:21 --> Config Class Initialized
INFO - 2024-10-02 15:13:21 --> Hooks Class Initialized
DEBUG - 2024-10-02 15:13:21 --> UTF-8 Support Enabled
INFO - 2024-10-02 15:13:21 --> Utf8 Class Initialized
INFO - 2024-10-02 15:13:21 --> URI Class Initialized
INFO - 2024-10-02 15:13:21 --> Router Class Initialized
INFO - 2024-10-02 15:13:21 --> Output Class Initialized
INFO - 2024-10-02 15:13:21 --> Security Class Initialized
DEBUG - 2024-10-02 15:13:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-02 15:13:21 --> Input Class Initialized
INFO - 2024-10-02 15:13:21 --> Language Class Initialized
INFO - 2024-10-02 15:13:21 --> Language Class Initialized
INFO - 2024-10-02 15:13:21 --> Config Class Initialized
INFO - 2024-10-02 15:13:21 --> Loader Class Initialized
INFO - 2024-10-02 15:13:21 --> Helper loaded: url_helper
INFO - 2024-10-02 15:13:21 --> Helper loaded: file_helper
INFO - 2024-10-02 15:13:21 --> Helper loaded: form_helper
INFO - 2024-10-02 15:13:21 --> Helper loaded: my_helper
INFO - 2024-10-02 15:13:21 --> Database Driver Class Initialized
INFO - 2024-10-02 15:13:21 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-02 15:13:21 --> Controller Class Initialized
INFO - 2024-10-02 15:13:21 --> Config Class Initialized
INFO - 2024-10-02 15:13:21 --> Hooks Class Initialized
DEBUG - 2024-10-02 15:13:21 --> UTF-8 Support Enabled
INFO - 2024-10-02 15:13:21 --> Utf8 Class Initialized
INFO - 2024-10-02 15:13:21 --> URI Class Initialized
INFO - 2024-10-02 15:13:21 --> Router Class Initialized
INFO - 2024-10-02 15:13:21 --> Output Class Initialized
INFO - 2024-10-02 15:13:21 --> Security Class Initialized
DEBUG - 2024-10-02 15:13:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-02 15:13:21 --> Input Class Initialized
INFO - 2024-10-02 15:13:21 --> Language Class Initialized
INFO - 2024-10-02 15:13:21 --> Language Class Initialized
INFO - 2024-10-02 15:13:21 --> Config Class Initialized
INFO - 2024-10-02 15:13:21 --> Loader Class Initialized
INFO - 2024-10-02 15:13:21 --> Helper loaded: url_helper
INFO - 2024-10-02 15:13:21 --> Helper loaded: file_helper
INFO - 2024-10-02 15:13:21 --> Helper loaded: form_helper
INFO - 2024-10-02 15:13:21 --> Helper loaded: my_helper
INFO - 2024-10-02 15:13:22 --> Database Driver Class Initialized
INFO - 2024-10-02 15:13:22 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-02 15:13:22 --> Controller Class Initialized
DEBUG - 2024-10-02 15:13:22 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/views/list.php
DEBUG - 2024-10-02 15:13:22 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-10-02 15:13:22 --> Final output sent to browser
DEBUG - 2024-10-02 15:13:22 --> Total execution time: 0.1051
INFO - 2024-10-02 15:13:22 --> Config Class Initialized
INFO - 2024-10-02 15:13:22 --> Hooks Class Initialized
DEBUG - 2024-10-02 15:13:22 --> UTF-8 Support Enabled
INFO - 2024-10-02 15:13:22 --> Utf8 Class Initialized
INFO - 2024-10-02 15:13:22 --> URI Class Initialized
INFO - 2024-10-02 15:13:22 --> Router Class Initialized
INFO - 2024-10-02 15:13:22 --> Output Class Initialized
INFO - 2024-10-02 15:13:22 --> Security Class Initialized
DEBUG - 2024-10-02 15:13:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-02 15:13:22 --> Input Class Initialized
INFO - 2024-10-02 15:13:22 --> Language Class Initialized
INFO - 2024-10-02 15:13:22 --> Language Class Initialized
INFO - 2024-10-02 15:13:22 --> Config Class Initialized
INFO - 2024-10-02 15:13:22 --> Loader Class Initialized
INFO - 2024-10-02 15:13:22 --> Helper loaded: url_helper
INFO - 2024-10-02 15:13:22 --> Helper loaded: file_helper
INFO - 2024-10-02 15:13:22 --> Helper loaded: form_helper
INFO - 2024-10-02 15:13:22 --> Helper loaded: my_helper
INFO - 2024-10-02 15:13:22 --> Database Driver Class Initialized
INFO - 2024-10-02 15:13:22 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-02 15:13:22 --> Controller Class Initialized
INFO - 2024-10-02 15:13:24 --> Config Class Initialized
INFO - 2024-10-02 15:13:24 --> Hooks Class Initialized
DEBUG - 2024-10-02 15:13:24 --> UTF-8 Support Enabled
INFO - 2024-10-02 15:13:24 --> Utf8 Class Initialized
INFO - 2024-10-02 15:13:24 --> URI Class Initialized
INFO - 2024-10-02 15:13:24 --> Router Class Initialized
INFO - 2024-10-02 15:13:24 --> Output Class Initialized
INFO - 2024-10-02 15:13:24 --> Security Class Initialized
DEBUG - 2024-10-02 15:13:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-02 15:13:24 --> Input Class Initialized
INFO - 2024-10-02 15:13:24 --> Language Class Initialized
INFO - 2024-10-02 15:13:24 --> Language Class Initialized
INFO - 2024-10-02 15:13:24 --> Config Class Initialized
INFO - 2024-10-02 15:13:24 --> Loader Class Initialized
INFO - 2024-10-02 15:13:24 --> Helper loaded: url_helper
INFO - 2024-10-02 15:13:24 --> Helper loaded: file_helper
INFO - 2024-10-02 15:13:24 --> Helper loaded: form_helper
INFO - 2024-10-02 15:13:24 --> Helper loaded: my_helper
INFO - 2024-10-02 15:13:24 --> Database Driver Class Initialized
INFO - 2024-10-02 15:13:24 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-02 15:13:24 --> Controller Class Initialized
INFO - 2024-10-02 15:13:24 --> Final output sent to browser
DEBUG - 2024-10-02 15:13:24 --> Total execution time: 0.1286
INFO - 2024-10-02 15:13:38 --> Config Class Initialized
INFO - 2024-10-02 15:13:38 --> Hooks Class Initialized
DEBUG - 2024-10-02 15:13:38 --> UTF-8 Support Enabled
INFO - 2024-10-02 15:13:38 --> Utf8 Class Initialized
INFO - 2024-10-02 15:13:38 --> URI Class Initialized
INFO - 2024-10-02 15:13:38 --> Router Class Initialized
INFO - 2024-10-02 15:13:38 --> Output Class Initialized
INFO - 2024-10-02 15:13:38 --> Security Class Initialized
DEBUG - 2024-10-02 15:13:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-02 15:13:38 --> Input Class Initialized
INFO - 2024-10-02 15:13:38 --> Language Class Initialized
INFO - 2024-10-02 15:13:38 --> Language Class Initialized
INFO - 2024-10-02 15:13:38 --> Config Class Initialized
INFO - 2024-10-02 15:13:38 --> Loader Class Initialized
INFO - 2024-10-02 15:13:38 --> Helper loaded: url_helper
INFO - 2024-10-02 15:13:38 --> Helper loaded: file_helper
INFO - 2024-10-02 15:13:38 --> Helper loaded: form_helper
INFO - 2024-10-02 15:13:38 --> Helper loaded: my_helper
INFO - 2024-10-02 15:13:38 --> Database Driver Class Initialized
INFO - 2024-10-02 15:13:38 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-02 15:13:38 --> Controller Class Initialized
DEBUG - 2024-10-02 15:13:38 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/view_mapel/views/v_view_mapel.php
DEBUG - 2024-10-02 15:13:38 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-10-02 15:13:38 --> Final output sent to browser
DEBUG - 2024-10-02 15:13:38 --> Total execution time: 0.0522
INFO - 2024-10-02 15:13:40 --> Config Class Initialized
INFO - 2024-10-02 15:13:40 --> Hooks Class Initialized
DEBUG - 2024-10-02 15:13:40 --> UTF-8 Support Enabled
INFO - 2024-10-02 15:13:40 --> Utf8 Class Initialized
INFO - 2024-10-02 15:13:40 --> URI Class Initialized
INFO - 2024-10-02 15:13:40 --> Router Class Initialized
INFO - 2024-10-02 15:13:41 --> Output Class Initialized
INFO - 2024-10-02 15:13:41 --> Security Class Initialized
DEBUG - 2024-10-02 15:13:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-02 15:13:41 --> Input Class Initialized
INFO - 2024-10-02 15:13:41 --> Language Class Initialized
INFO - 2024-10-02 15:13:41 --> Language Class Initialized
INFO - 2024-10-02 15:13:41 --> Config Class Initialized
INFO - 2024-10-02 15:13:41 --> Loader Class Initialized
INFO - 2024-10-02 15:13:41 --> Helper loaded: url_helper
INFO - 2024-10-02 15:13:41 --> Helper loaded: file_helper
INFO - 2024-10-02 15:13:41 --> Helper loaded: form_helper
INFO - 2024-10-02 15:13:41 --> Helper loaded: my_helper
INFO - 2024-10-02 15:13:41 --> Database Driver Class Initialized
INFO - 2024-10-02 15:13:41 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-02 15:13:41 --> Controller Class Initialized
DEBUG - 2024-10-02 15:13:41 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/views/list.php
DEBUG - 2024-10-02 15:13:41 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-10-02 15:13:41 --> Final output sent to browser
DEBUG - 2024-10-02 15:13:41 --> Total execution time: 0.1002
INFO - 2024-10-02 15:13:41 --> Config Class Initialized
INFO - 2024-10-02 15:13:41 --> Hooks Class Initialized
DEBUG - 2024-10-02 15:13:41 --> UTF-8 Support Enabled
INFO - 2024-10-02 15:13:41 --> Utf8 Class Initialized
INFO - 2024-10-02 15:13:41 --> URI Class Initialized
INFO - 2024-10-02 15:13:41 --> Router Class Initialized
INFO - 2024-10-02 15:13:41 --> Output Class Initialized
INFO - 2024-10-02 15:13:41 --> Security Class Initialized
DEBUG - 2024-10-02 15:13:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-02 15:13:41 --> Input Class Initialized
INFO - 2024-10-02 15:13:41 --> Language Class Initialized
INFO - 2024-10-02 15:13:41 --> Language Class Initialized
INFO - 2024-10-02 15:13:41 --> Config Class Initialized
INFO - 2024-10-02 15:13:41 --> Loader Class Initialized
INFO - 2024-10-02 15:13:41 --> Helper loaded: url_helper
INFO - 2024-10-02 15:13:41 --> Helper loaded: file_helper
INFO - 2024-10-02 15:13:41 --> Helper loaded: form_helper
INFO - 2024-10-02 15:13:41 --> Helper loaded: my_helper
INFO - 2024-10-02 15:13:41 --> Database Driver Class Initialized
INFO - 2024-10-02 15:13:41 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-02 15:13:41 --> Controller Class Initialized
INFO - 2024-10-02 15:13:43 --> Config Class Initialized
INFO - 2024-10-02 15:13:43 --> Hooks Class Initialized
DEBUG - 2024-10-02 15:13:43 --> UTF-8 Support Enabled
INFO - 2024-10-02 15:13:43 --> Utf8 Class Initialized
INFO - 2024-10-02 15:13:43 --> URI Class Initialized
INFO - 2024-10-02 15:13:43 --> Router Class Initialized
INFO - 2024-10-02 15:13:43 --> Output Class Initialized
INFO - 2024-10-02 15:13:43 --> Security Class Initialized
DEBUG - 2024-10-02 15:13:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-02 15:13:43 --> Input Class Initialized
INFO - 2024-10-02 15:13:43 --> Language Class Initialized
INFO - 2024-10-02 15:13:43 --> Language Class Initialized
INFO - 2024-10-02 15:13:43 --> Config Class Initialized
INFO - 2024-10-02 15:13:43 --> Loader Class Initialized
INFO - 2024-10-02 15:13:43 --> Helper loaded: url_helper
INFO - 2024-10-02 15:13:43 --> Helper loaded: file_helper
INFO - 2024-10-02 15:13:43 --> Helper loaded: form_helper
INFO - 2024-10-02 15:13:43 --> Helper loaded: my_helper
INFO - 2024-10-02 15:13:43 --> Database Driver Class Initialized
INFO - 2024-10-02 15:13:43 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-02 15:13:43 --> Controller Class Initialized
INFO - 2024-10-02 15:13:43 --> Final output sent to browser
DEBUG - 2024-10-02 15:13:43 --> Total execution time: 0.0802
INFO - 2024-10-02 15:14:05 --> Config Class Initialized
INFO - 2024-10-02 15:14:05 --> Hooks Class Initialized
DEBUG - 2024-10-02 15:14:05 --> UTF-8 Support Enabled
INFO - 2024-10-02 15:14:05 --> Utf8 Class Initialized
INFO - 2024-10-02 15:14:05 --> URI Class Initialized
INFO - 2024-10-02 15:14:05 --> Router Class Initialized
INFO - 2024-10-02 15:14:05 --> Output Class Initialized
INFO - 2024-10-02 15:14:05 --> Security Class Initialized
DEBUG - 2024-10-02 15:14:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-02 15:14:05 --> Input Class Initialized
INFO - 2024-10-02 15:14:05 --> Language Class Initialized
INFO - 2024-10-02 15:14:05 --> Language Class Initialized
INFO - 2024-10-02 15:14:05 --> Config Class Initialized
INFO - 2024-10-02 15:14:05 --> Loader Class Initialized
INFO - 2024-10-02 15:14:05 --> Helper loaded: url_helper
INFO - 2024-10-02 15:14:05 --> Helper loaded: file_helper
INFO - 2024-10-02 15:14:05 --> Helper loaded: form_helper
INFO - 2024-10-02 15:14:05 --> Helper loaded: my_helper
INFO - 2024-10-02 15:14:05 --> Database Driver Class Initialized
INFO - 2024-10-02 15:14:05 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-02 15:14:05 --> Controller Class Initialized
INFO - 2024-10-02 15:14:05 --> Final output sent to browser
DEBUG - 2024-10-02 15:14:05 --> Total execution time: 0.0946
INFO - 2024-10-02 15:14:05 --> Config Class Initialized
INFO - 2024-10-02 15:14:05 --> Hooks Class Initialized
DEBUG - 2024-10-02 15:14:05 --> UTF-8 Support Enabled
INFO - 2024-10-02 15:14:05 --> Utf8 Class Initialized
INFO - 2024-10-02 15:14:05 --> URI Class Initialized
INFO - 2024-10-02 15:14:05 --> Router Class Initialized
INFO - 2024-10-02 15:14:05 --> Output Class Initialized
INFO - 2024-10-02 15:14:05 --> Security Class Initialized
DEBUG - 2024-10-02 15:14:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-02 15:14:05 --> Input Class Initialized
INFO - 2024-10-02 15:14:05 --> Language Class Initialized
INFO - 2024-10-02 15:14:05 --> Language Class Initialized
INFO - 2024-10-02 15:14:05 --> Config Class Initialized
INFO - 2024-10-02 15:14:05 --> Loader Class Initialized
INFO - 2024-10-02 15:14:05 --> Helper loaded: url_helper
INFO - 2024-10-02 15:14:05 --> Helper loaded: file_helper
INFO - 2024-10-02 15:14:05 --> Helper loaded: form_helper
INFO - 2024-10-02 15:14:05 --> Helper loaded: my_helper
INFO - 2024-10-02 15:14:05 --> Database Driver Class Initialized
INFO - 2024-10-02 15:14:05 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-02 15:14:05 --> Controller Class Initialized
INFO - 2024-10-02 15:14:18 --> Config Class Initialized
INFO - 2024-10-02 15:14:18 --> Hooks Class Initialized
DEBUG - 2024-10-02 15:14:18 --> UTF-8 Support Enabled
INFO - 2024-10-02 15:14:18 --> Utf8 Class Initialized
INFO - 2024-10-02 15:14:18 --> URI Class Initialized
INFO - 2024-10-02 15:14:18 --> Router Class Initialized
INFO - 2024-10-02 15:14:18 --> Output Class Initialized
INFO - 2024-10-02 15:14:18 --> Security Class Initialized
DEBUG - 2024-10-02 15:14:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-02 15:14:18 --> Input Class Initialized
INFO - 2024-10-02 15:14:18 --> Language Class Initialized
INFO - 2024-10-02 15:14:18 --> Language Class Initialized
INFO - 2024-10-02 15:14:18 --> Config Class Initialized
INFO - 2024-10-02 15:14:18 --> Loader Class Initialized
INFO - 2024-10-02 15:14:18 --> Helper loaded: url_helper
INFO - 2024-10-02 15:14:18 --> Helper loaded: file_helper
INFO - 2024-10-02 15:14:18 --> Helper loaded: form_helper
INFO - 2024-10-02 15:14:18 --> Helper loaded: my_helper
INFO - 2024-10-02 15:14:18 --> Database Driver Class Initialized
INFO - 2024-10-02 15:14:18 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-02 15:14:18 --> Controller Class Initialized
INFO - 2024-10-02 15:16:46 --> Config Class Initialized
INFO - 2024-10-02 15:16:46 --> Hooks Class Initialized
DEBUG - 2024-10-02 15:16:47 --> UTF-8 Support Enabled
INFO - 2024-10-02 15:16:47 --> Utf8 Class Initialized
INFO - 2024-10-02 15:16:47 --> URI Class Initialized
INFO - 2024-10-02 15:16:47 --> Router Class Initialized
INFO - 2024-10-02 15:16:47 --> Output Class Initialized
INFO - 2024-10-02 15:16:47 --> Security Class Initialized
DEBUG - 2024-10-02 15:16:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-02 15:16:47 --> Input Class Initialized
INFO - 2024-10-02 15:16:47 --> Language Class Initialized
INFO - 2024-10-02 15:16:47 --> Language Class Initialized
INFO - 2024-10-02 15:16:47 --> Config Class Initialized
INFO - 2024-10-02 15:16:47 --> Loader Class Initialized
INFO - 2024-10-02 15:16:47 --> Helper loaded: url_helper
INFO - 2024-10-02 15:16:47 --> Helper loaded: file_helper
INFO - 2024-10-02 15:16:47 --> Helper loaded: form_helper
INFO - 2024-10-02 15:16:47 --> Helper loaded: my_helper
INFO - 2024-10-02 15:16:47 --> Database Driver Class Initialized
INFO - 2024-10-02 15:16:47 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-02 15:16:47 --> Controller Class Initialized
DEBUG - 2024-10-02 15:16:47 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/views/form.php
DEBUG - 2024-10-02 15:16:47 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-10-02 15:16:47 --> Final output sent to browser
DEBUG - 2024-10-02 15:16:47 --> Total execution time: 0.5954
INFO - 2024-10-02 15:16:52 --> Config Class Initialized
INFO - 2024-10-02 15:16:52 --> Hooks Class Initialized
DEBUG - 2024-10-02 15:16:52 --> UTF-8 Support Enabled
INFO - 2024-10-02 15:16:52 --> Utf8 Class Initialized
INFO - 2024-10-02 15:16:52 --> URI Class Initialized
INFO - 2024-10-02 15:16:52 --> Router Class Initialized
INFO - 2024-10-02 15:16:52 --> Output Class Initialized
INFO - 2024-10-02 15:16:52 --> Security Class Initialized
DEBUG - 2024-10-02 15:16:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-02 15:16:52 --> Input Class Initialized
INFO - 2024-10-02 15:16:52 --> Language Class Initialized
INFO - 2024-10-02 15:16:52 --> Language Class Initialized
INFO - 2024-10-02 15:16:52 --> Config Class Initialized
INFO - 2024-10-02 15:16:52 --> Loader Class Initialized
INFO - 2024-10-02 15:16:52 --> Helper loaded: url_helper
INFO - 2024-10-02 15:16:52 --> Helper loaded: file_helper
INFO - 2024-10-02 15:16:52 --> Helper loaded: form_helper
INFO - 2024-10-02 15:16:52 --> Helper loaded: my_helper
INFO - 2024-10-02 15:16:52 --> Database Driver Class Initialized
INFO - 2024-10-02 15:16:52 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-02 15:16:52 --> Controller Class Initialized
INFO - 2024-10-02 15:16:52 --> Config Class Initialized
INFO - 2024-10-02 15:16:52 --> Hooks Class Initialized
DEBUG - 2024-10-02 15:16:52 --> UTF-8 Support Enabled
INFO - 2024-10-02 15:16:52 --> Utf8 Class Initialized
INFO - 2024-10-02 15:16:52 --> URI Class Initialized
INFO - 2024-10-02 15:16:52 --> Router Class Initialized
INFO - 2024-10-02 15:16:52 --> Output Class Initialized
INFO - 2024-10-02 15:16:52 --> Security Class Initialized
DEBUG - 2024-10-02 15:16:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-02 15:16:52 --> Input Class Initialized
INFO - 2024-10-02 15:16:52 --> Language Class Initialized
INFO - 2024-10-02 15:16:52 --> Language Class Initialized
INFO - 2024-10-02 15:16:52 --> Config Class Initialized
INFO - 2024-10-02 15:16:52 --> Loader Class Initialized
INFO - 2024-10-02 15:16:52 --> Helper loaded: url_helper
INFO - 2024-10-02 15:16:52 --> Helper loaded: file_helper
INFO - 2024-10-02 15:16:52 --> Helper loaded: form_helper
INFO - 2024-10-02 15:16:52 --> Helper loaded: my_helper
INFO - 2024-10-02 15:16:52 --> Database Driver Class Initialized
INFO - 2024-10-02 15:16:52 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-02 15:16:52 --> Controller Class Initialized
DEBUG - 2024-10-02 15:16:52 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/views/list.php
DEBUG - 2024-10-02 15:16:52 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-10-02 15:16:52 --> Final output sent to browser
DEBUG - 2024-10-02 15:16:52 --> Total execution time: 0.0330
INFO - 2024-10-02 15:16:52 --> Config Class Initialized
INFO - 2024-10-02 15:16:52 --> Hooks Class Initialized
DEBUG - 2024-10-02 15:16:52 --> UTF-8 Support Enabled
INFO - 2024-10-02 15:16:52 --> Utf8 Class Initialized
INFO - 2024-10-02 15:16:52 --> URI Class Initialized
INFO - 2024-10-02 15:16:52 --> Router Class Initialized
INFO - 2024-10-02 15:16:52 --> Output Class Initialized
INFO - 2024-10-02 15:16:52 --> Security Class Initialized
DEBUG - 2024-10-02 15:16:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-02 15:16:53 --> Input Class Initialized
INFO - 2024-10-02 15:16:53 --> Language Class Initialized
INFO - 2024-10-02 15:16:53 --> Language Class Initialized
INFO - 2024-10-02 15:16:53 --> Config Class Initialized
INFO - 2024-10-02 15:16:53 --> Loader Class Initialized
INFO - 2024-10-02 15:16:53 --> Helper loaded: url_helper
INFO - 2024-10-02 15:16:53 --> Helper loaded: file_helper
INFO - 2024-10-02 15:16:53 --> Helper loaded: form_helper
INFO - 2024-10-02 15:16:53 --> Helper loaded: my_helper
INFO - 2024-10-02 15:16:53 --> Database Driver Class Initialized
INFO - 2024-10-02 15:16:53 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-02 15:16:53 --> Controller Class Initialized
INFO - 2024-10-02 15:17:06 --> Config Class Initialized
INFO - 2024-10-02 15:17:06 --> Hooks Class Initialized
DEBUG - 2024-10-02 15:17:06 --> UTF-8 Support Enabled
INFO - 2024-10-02 15:17:06 --> Utf8 Class Initialized
INFO - 2024-10-02 15:17:06 --> URI Class Initialized
INFO - 2024-10-02 15:17:06 --> Router Class Initialized
INFO - 2024-10-02 15:17:06 --> Output Class Initialized
INFO - 2024-10-02 15:17:06 --> Security Class Initialized
DEBUG - 2024-10-02 15:17:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-02 15:17:06 --> Input Class Initialized
INFO - 2024-10-02 15:17:06 --> Language Class Initialized
INFO - 2024-10-02 15:17:06 --> Language Class Initialized
INFO - 2024-10-02 15:17:06 --> Config Class Initialized
INFO - 2024-10-02 15:17:06 --> Loader Class Initialized
INFO - 2024-10-02 15:17:06 --> Helper loaded: url_helper
INFO - 2024-10-02 15:17:06 --> Helper loaded: file_helper
INFO - 2024-10-02 15:17:06 --> Helper loaded: form_helper
INFO - 2024-10-02 15:17:06 --> Helper loaded: my_helper
INFO - 2024-10-02 15:17:06 --> Database Driver Class Initialized
INFO - 2024-10-02 15:17:06 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-02 15:17:06 --> Controller Class Initialized
INFO - 2024-10-02 15:17:06 --> Final output sent to browser
DEBUG - 2024-10-02 15:17:06 --> Total execution time: 0.0444
INFO - 2024-10-02 15:17:09 --> Config Class Initialized
INFO - 2024-10-02 15:17:09 --> Hooks Class Initialized
DEBUG - 2024-10-02 15:17:09 --> UTF-8 Support Enabled
INFO - 2024-10-02 15:17:09 --> Utf8 Class Initialized
INFO - 2024-10-02 15:17:09 --> URI Class Initialized
INFO - 2024-10-02 15:17:09 --> Router Class Initialized
INFO - 2024-10-02 15:17:09 --> Output Class Initialized
INFO - 2024-10-02 15:17:09 --> Security Class Initialized
DEBUG - 2024-10-02 15:17:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-02 15:17:09 --> Input Class Initialized
INFO - 2024-10-02 15:17:09 --> Language Class Initialized
INFO - 2024-10-02 15:17:09 --> Language Class Initialized
INFO - 2024-10-02 15:17:09 --> Config Class Initialized
INFO - 2024-10-02 15:17:09 --> Loader Class Initialized
INFO - 2024-10-02 15:17:09 --> Helper loaded: url_helper
INFO - 2024-10-02 15:17:09 --> Helper loaded: file_helper
INFO - 2024-10-02 15:17:09 --> Helper loaded: form_helper
INFO - 2024-10-02 15:17:09 --> Helper loaded: my_helper
INFO - 2024-10-02 15:17:09 --> Database Driver Class Initialized
INFO - 2024-10-02 15:17:09 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-02 15:17:09 --> Controller Class Initialized
INFO - 2024-10-02 15:17:09 --> Final output sent to browser
DEBUG - 2024-10-02 15:17:09 --> Total execution time: 0.0322
INFO - 2024-10-02 15:17:31 --> Config Class Initialized
INFO - 2024-10-02 15:17:31 --> Hooks Class Initialized
DEBUG - 2024-10-02 15:17:31 --> UTF-8 Support Enabled
INFO - 2024-10-02 15:17:31 --> Utf8 Class Initialized
INFO - 2024-10-02 15:17:31 --> URI Class Initialized
INFO - 2024-10-02 15:17:31 --> Router Class Initialized
INFO - 2024-10-02 15:17:31 --> Output Class Initialized
INFO - 2024-10-02 15:17:31 --> Security Class Initialized
DEBUG - 2024-10-02 15:17:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-02 15:17:31 --> Input Class Initialized
INFO - 2024-10-02 15:17:31 --> Language Class Initialized
INFO - 2024-10-02 15:17:31 --> Language Class Initialized
INFO - 2024-10-02 15:17:31 --> Config Class Initialized
INFO - 2024-10-02 15:17:31 --> Loader Class Initialized
INFO - 2024-10-02 15:17:31 --> Helper loaded: url_helper
INFO - 2024-10-02 15:17:31 --> Helper loaded: file_helper
INFO - 2024-10-02 15:17:31 --> Helper loaded: form_helper
INFO - 2024-10-02 15:17:31 --> Helper loaded: my_helper
INFO - 2024-10-02 15:17:31 --> Database Driver Class Initialized
INFO - 2024-10-02 15:17:31 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-02 15:17:31 --> Controller Class Initialized
DEBUG - 2024-10-02 15:17:31 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/view_mapel/views/v_view_mapel.php
DEBUG - 2024-10-02 15:17:31 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-10-02 15:17:31 --> Final output sent to browser
DEBUG - 2024-10-02 15:17:31 --> Total execution time: 0.1009
INFO - 2024-10-02 15:17:39 --> Config Class Initialized
INFO - 2024-10-02 15:17:39 --> Hooks Class Initialized
DEBUG - 2024-10-02 15:17:39 --> UTF-8 Support Enabled
INFO - 2024-10-02 15:17:39 --> Utf8 Class Initialized
INFO - 2024-10-02 15:17:39 --> URI Class Initialized
INFO - 2024-10-02 15:17:39 --> Router Class Initialized
INFO - 2024-10-02 15:17:39 --> Output Class Initialized
INFO - 2024-10-02 15:17:39 --> Security Class Initialized
DEBUG - 2024-10-02 15:17:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-02 15:17:39 --> Input Class Initialized
INFO - 2024-10-02 15:17:39 --> Language Class Initialized
INFO - 2024-10-02 15:17:39 --> Language Class Initialized
INFO - 2024-10-02 15:17:39 --> Config Class Initialized
INFO - 2024-10-02 15:17:39 --> Loader Class Initialized
INFO - 2024-10-02 15:17:39 --> Helper loaded: url_helper
INFO - 2024-10-02 15:17:39 --> Helper loaded: file_helper
INFO - 2024-10-02 15:17:39 --> Helper loaded: form_helper
INFO - 2024-10-02 15:17:39 --> Helper loaded: my_helper
INFO - 2024-10-02 15:17:39 --> Database Driver Class Initialized
INFO - 2024-10-02 15:17:39 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-02 15:17:39 --> Controller Class Initialized
DEBUG - 2024-10-02 15:17:39 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_icb/views/list.php
DEBUG - 2024-10-02 15:17:39 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-10-02 15:17:39 --> Final output sent to browser
DEBUG - 2024-10-02 15:17:39 --> Total execution time: 0.0397
INFO - 2024-10-02 15:17:39 --> Config Class Initialized
INFO - 2024-10-02 15:17:39 --> Hooks Class Initialized
DEBUG - 2024-10-02 15:17:39 --> UTF-8 Support Enabled
INFO - 2024-10-02 15:17:39 --> Utf8 Class Initialized
INFO - 2024-10-02 15:17:39 --> URI Class Initialized
INFO - 2024-10-02 15:17:39 --> Router Class Initialized
INFO - 2024-10-02 15:17:39 --> Output Class Initialized
INFO - 2024-10-02 15:17:39 --> Security Class Initialized
DEBUG - 2024-10-02 15:17:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-02 15:17:39 --> Input Class Initialized
INFO - 2024-10-02 15:17:39 --> Language Class Initialized
INFO - 2024-10-02 15:17:39 --> Language Class Initialized
INFO - 2024-10-02 15:17:39 --> Config Class Initialized
INFO - 2024-10-02 15:17:39 --> Loader Class Initialized
INFO - 2024-10-02 15:17:39 --> Helper loaded: url_helper
INFO - 2024-10-02 15:17:39 --> Helper loaded: file_helper
INFO - 2024-10-02 15:17:39 --> Helper loaded: form_helper
INFO - 2024-10-02 15:17:39 --> Helper loaded: my_helper
INFO - 2024-10-02 15:17:39 --> Database Driver Class Initialized
INFO - 2024-10-02 15:17:39 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-02 15:17:39 --> Controller Class Initialized
INFO - 2024-10-02 15:17:46 --> Config Class Initialized
INFO - 2024-10-02 15:17:46 --> Hooks Class Initialized
DEBUG - 2024-10-02 15:17:46 --> UTF-8 Support Enabled
INFO - 2024-10-02 15:17:46 --> Utf8 Class Initialized
INFO - 2024-10-02 15:17:46 --> URI Class Initialized
INFO - 2024-10-02 15:17:46 --> Router Class Initialized
INFO - 2024-10-02 15:17:46 --> Output Class Initialized
INFO - 2024-10-02 15:17:46 --> Security Class Initialized
DEBUG - 2024-10-02 15:17:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-02 15:17:46 --> Input Class Initialized
INFO - 2024-10-02 15:17:46 --> Language Class Initialized
INFO - 2024-10-02 15:17:46 --> Language Class Initialized
INFO - 2024-10-02 15:17:46 --> Config Class Initialized
INFO - 2024-10-02 15:17:46 --> Loader Class Initialized
INFO - 2024-10-02 15:17:46 --> Helper loaded: url_helper
INFO - 2024-10-02 15:17:46 --> Helper loaded: file_helper
INFO - 2024-10-02 15:17:46 --> Helper loaded: form_helper
INFO - 2024-10-02 15:17:46 --> Helper loaded: my_helper
INFO - 2024-10-02 15:17:46 --> Database Driver Class Initialized
INFO - 2024-10-02 15:17:46 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-02 15:17:46 --> Controller Class Initialized
INFO - 2024-10-02 15:17:46 --> Final output sent to browser
DEBUG - 2024-10-02 15:17:46 --> Total execution time: 0.0453
INFO - 2024-10-02 15:26:25 --> Config Class Initialized
INFO - 2024-10-02 15:26:25 --> Hooks Class Initialized
DEBUG - 2024-10-02 15:26:25 --> UTF-8 Support Enabled
INFO - 2024-10-02 15:26:25 --> Utf8 Class Initialized
INFO - 2024-10-02 15:26:25 --> URI Class Initialized
INFO - 2024-10-02 15:26:25 --> Router Class Initialized
INFO - 2024-10-02 15:26:25 --> Output Class Initialized
INFO - 2024-10-02 15:26:25 --> Security Class Initialized
DEBUG - 2024-10-02 15:26:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-02 15:26:25 --> Input Class Initialized
INFO - 2024-10-02 15:26:25 --> Language Class Initialized
INFO - 2024-10-02 15:26:25 --> Language Class Initialized
INFO - 2024-10-02 15:26:25 --> Config Class Initialized
INFO - 2024-10-02 15:26:25 --> Loader Class Initialized
INFO - 2024-10-02 15:26:25 --> Helper loaded: url_helper
INFO - 2024-10-02 15:26:25 --> Helper loaded: file_helper
INFO - 2024-10-02 15:26:25 --> Helper loaded: form_helper
INFO - 2024-10-02 15:26:25 --> Helper loaded: my_helper
INFO - 2024-10-02 15:26:25 --> Database Driver Class Initialized
INFO - 2024-10-02 15:26:25 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-02 15:26:25 --> Controller Class Initialized
DEBUG - 2024-10-02 15:26:25 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/view_mapel/views/v_view_mapel.php
DEBUG - 2024-10-02 15:26:25 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-10-02 15:26:25 --> Final output sent to browser
DEBUG - 2024-10-02 15:26:25 --> Total execution time: 0.0332
INFO - 2024-10-02 15:26:29 --> Config Class Initialized
INFO - 2024-10-02 15:26:29 --> Hooks Class Initialized
DEBUG - 2024-10-02 15:26:29 --> UTF-8 Support Enabled
INFO - 2024-10-02 15:26:29 --> Utf8 Class Initialized
INFO - 2024-10-02 15:26:29 --> URI Class Initialized
INFO - 2024-10-02 15:26:29 --> Router Class Initialized
INFO - 2024-10-02 15:26:29 --> Output Class Initialized
INFO - 2024-10-02 15:26:29 --> Security Class Initialized
DEBUG - 2024-10-02 15:26:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-02 15:26:29 --> Input Class Initialized
INFO - 2024-10-02 15:26:29 --> Language Class Initialized
INFO - 2024-10-02 15:26:29 --> Language Class Initialized
INFO - 2024-10-02 15:26:29 --> Config Class Initialized
INFO - 2024-10-02 15:26:29 --> Loader Class Initialized
INFO - 2024-10-02 15:26:29 --> Helper loaded: url_helper
INFO - 2024-10-02 15:26:29 --> Helper loaded: file_helper
INFO - 2024-10-02 15:26:29 --> Helper loaded: form_helper
INFO - 2024-10-02 15:26:29 --> Helper loaded: my_helper
INFO - 2024-10-02 15:26:29 --> Database Driver Class Initialized
INFO - 2024-10-02 15:26:29 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-02 15:26:29 --> Controller Class Initialized
DEBUG - 2024-10-02 15:26:29 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_catatan_guru/views/list.php
DEBUG - 2024-10-02 15:26:29 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-10-02 15:26:29 --> Final output sent to browser
DEBUG - 2024-10-02 15:26:29 --> Total execution time: 0.0325
INFO - 2024-10-02 15:26:30 --> Config Class Initialized
INFO - 2024-10-02 15:26:30 --> Hooks Class Initialized
DEBUG - 2024-10-02 15:26:30 --> UTF-8 Support Enabled
INFO - 2024-10-02 15:26:30 --> Utf8 Class Initialized
INFO - 2024-10-02 15:26:30 --> URI Class Initialized
INFO - 2024-10-02 15:26:30 --> Router Class Initialized
INFO - 2024-10-02 15:26:30 --> Output Class Initialized
INFO - 2024-10-02 15:26:30 --> Security Class Initialized
DEBUG - 2024-10-02 15:26:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-02 15:26:30 --> Input Class Initialized
INFO - 2024-10-02 15:26:30 --> Language Class Initialized
INFO - 2024-10-02 15:26:30 --> Language Class Initialized
INFO - 2024-10-02 15:26:30 --> Config Class Initialized
INFO - 2024-10-02 15:26:30 --> Loader Class Initialized
INFO - 2024-10-02 15:26:30 --> Helper loaded: url_helper
INFO - 2024-10-02 15:26:30 --> Helper loaded: file_helper
INFO - 2024-10-02 15:26:30 --> Helper loaded: form_helper
INFO - 2024-10-02 15:26:30 --> Helper loaded: my_helper
INFO - 2024-10-02 15:26:30 --> Database Driver Class Initialized
INFO - 2024-10-02 15:26:30 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-02 15:26:30 --> Controller Class Initialized
INFO - 2024-10-02 15:26:37 --> Config Class Initialized
INFO - 2024-10-02 15:26:37 --> Hooks Class Initialized
DEBUG - 2024-10-02 15:26:37 --> UTF-8 Support Enabled
INFO - 2024-10-02 15:26:37 --> Utf8 Class Initialized
INFO - 2024-10-02 15:26:37 --> URI Class Initialized
INFO - 2024-10-02 15:26:37 --> Router Class Initialized
INFO - 2024-10-02 15:26:37 --> Output Class Initialized
INFO - 2024-10-02 15:26:38 --> Security Class Initialized
DEBUG - 2024-10-02 15:26:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-02 15:26:38 --> Input Class Initialized
INFO - 2024-10-02 15:26:38 --> Language Class Initialized
INFO - 2024-10-02 15:26:38 --> Language Class Initialized
INFO - 2024-10-02 15:26:38 --> Config Class Initialized
INFO - 2024-10-02 15:26:38 --> Loader Class Initialized
INFO - 2024-10-02 15:26:38 --> Helper loaded: url_helper
INFO - 2024-10-02 15:26:38 --> Helper loaded: file_helper
INFO - 2024-10-02 15:26:38 --> Helper loaded: form_helper
INFO - 2024-10-02 15:26:38 --> Helper loaded: my_helper
INFO - 2024-10-02 15:26:38 --> Database Driver Class Initialized
INFO - 2024-10-02 15:26:38 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-02 15:26:38 --> Controller Class Initialized
DEBUG - 2024-10-02 15:26:38 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/view_mapel/views/v_view_mapel.php
DEBUG - 2024-10-02 15:26:38 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-10-02 15:26:38 --> Final output sent to browser
DEBUG - 2024-10-02 15:26:38 --> Total execution time: 0.0389
INFO - 2024-10-02 15:26:40 --> Config Class Initialized
INFO - 2024-10-02 15:26:40 --> Hooks Class Initialized
DEBUG - 2024-10-02 15:26:40 --> UTF-8 Support Enabled
INFO - 2024-10-02 15:26:40 --> Utf8 Class Initialized
INFO - 2024-10-02 15:26:40 --> URI Class Initialized
INFO - 2024-10-02 15:26:40 --> Router Class Initialized
INFO - 2024-10-02 15:26:40 --> Output Class Initialized
INFO - 2024-10-02 15:26:40 --> Security Class Initialized
DEBUG - 2024-10-02 15:26:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-02 15:26:40 --> Input Class Initialized
INFO - 2024-10-02 15:26:40 --> Language Class Initialized
INFO - 2024-10-02 15:26:40 --> Language Class Initialized
INFO - 2024-10-02 15:26:40 --> Config Class Initialized
INFO - 2024-10-02 15:26:40 --> Loader Class Initialized
INFO - 2024-10-02 15:26:40 --> Helper loaded: url_helper
INFO - 2024-10-02 15:26:40 --> Helper loaded: file_helper
INFO - 2024-10-02 15:26:40 --> Helper loaded: form_helper
INFO - 2024-10-02 15:26:40 --> Helper loaded: my_helper
INFO - 2024-10-02 15:26:40 --> Database Driver Class Initialized
INFO - 2024-10-02 15:26:40 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-02 15:26:40 --> Controller Class Initialized
DEBUG - 2024-10-02 15:26:40 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/views/list.php
DEBUG - 2024-10-02 15:26:40 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-10-02 15:26:40 --> Final output sent to browser
DEBUG - 2024-10-02 15:26:40 --> Total execution time: 0.0471
INFO - 2024-10-02 15:26:40 --> Config Class Initialized
INFO - 2024-10-02 15:26:40 --> Hooks Class Initialized
DEBUG - 2024-10-02 15:26:40 --> UTF-8 Support Enabled
INFO - 2024-10-02 15:26:40 --> Utf8 Class Initialized
INFO - 2024-10-02 15:26:40 --> URI Class Initialized
INFO - 2024-10-02 15:26:40 --> Router Class Initialized
INFO - 2024-10-02 15:26:40 --> Output Class Initialized
INFO - 2024-10-02 15:26:40 --> Security Class Initialized
DEBUG - 2024-10-02 15:26:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-02 15:26:40 --> Input Class Initialized
INFO - 2024-10-02 15:26:40 --> Language Class Initialized
INFO - 2024-10-02 15:26:40 --> Language Class Initialized
INFO - 2024-10-02 15:26:40 --> Config Class Initialized
INFO - 2024-10-02 15:26:40 --> Loader Class Initialized
INFO - 2024-10-02 15:26:40 --> Helper loaded: url_helper
INFO - 2024-10-02 15:26:40 --> Helper loaded: file_helper
INFO - 2024-10-02 15:26:40 --> Helper loaded: form_helper
INFO - 2024-10-02 15:26:40 --> Helper loaded: my_helper
INFO - 2024-10-02 15:26:40 --> Database Driver Class Initialized
INFO - 2024-10-02 15:26:40 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-02 15:26:40 --> Controller Class Initialized
INFO - 2024-10-02 15:27:29 --> Config Class Initialized
INFO - 2024-10-02 15:27:29 --> Hooks Class Initialized
DEBUG - 2024-10-02 15:27:29 --> UTF-8 Support Enabled
INFO - 2024-10-02 15:27:29 --> Utf8 Class Initialized
INFO - 2024-10-02 15:27:29 --> URI Class Initialized
INFO - 2024-10-02 15:27:29 --> Router Class Initialized
INFO - 2024-10-02 15:27:29 --> Output Class Initialized
INFO - 2024-10-02 15:27:29 --> Security Class Initialized
DEBUG - 2024-10-02 15:27:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-02 15:27:29 --> Input Class Initialized
INFO - 2024-10-02 15:27:29 --> Language Class Initialized
INFO - 2024-10-02 15:27:29 --> Language Class Initialized
INFO - 2024-10-02 15:27:29 --> Config Class Initialized
INFO - 2024-10-02 15:27:29 --> Loader Class Initialized
INFO - 2024-10-02 15:27:29 --> Helper loaded: url_helper
INFO - 2024-10-02 15:27:29 --> Helper loaded: file_helper
INFO - 2024-10-02 15:27:29 --> Helper loaded: form_helper
INFO - 2024-10-02 15:27:29 --> Helper loaded: my_helper
INFO - 2024-10-02 15:27:29 --> Database Driver Class Initialized
INFO - 2024-10-02 15:27:29 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-02 15:27:29 --> Controller Class Initialized
INFO - 2024-10-02 15:27:29 --> Final output sent to browser
DEBUG - 2024-10-02 15:27:29 --> Total execution time: 0.0656
INFO - 2024-10-02 15:27:34 --> Config Class Initialized
INFO - 2024-10-02 15:27:34 --> Hooks Class Initialized
DEBUG - 2024-10-02 15:27:34 --> UTF-8 Support Enabled
INFO - 2024-10-02 15:27:34 --> Utf8 Class Initialized
INFO - 2024-10-02 15:27:34 --> URI Class Initialized
INFO - 2024-10-02 15:27:34 --> Router Class Initialized
INFO - 2024-10-02 15:27:34 --> Output Class Initialized
INFO - 2024-10-02 15:27:34 --> Security Class Initialized
DEBUG - 2024-10-02 15:27:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-02 15:27:34 --> Input Class Initialized
INFO - 2024-10-02 15:27:34 --> Language Class Initialized
INFO - 2024-10-02 15:27:34 --> Language Class Initialized
INFO - 2024-10-02 15:27:34 --> Config Class Initialized
INFO - 2024-10-02 15:27:34 --> Loader Class Initialized
INFO - 2024-10-02 15:27:34 --> Helper loaded: url_helper
INFO - 2024-10-02 15:27:34 --> Helper loaded: file_helper
INFO - 2024-10-02 15:27:34 --> Helper loaded: form_helper
INFO - 2024-10-02 15:27:34 --> Helper loaded: my_helper
INFO - 2024-10-02 15:27:34 --> Database Driver Class Initialized
INFO - 2024-10-02 15:27:34 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-02 15:27:34 --> Controller Class Initialized
INFO - 2024-10-02 15:27:34 --> Final output sent to browser
DEBUG - 2024-10-02 15:27:34 --> Total execution time: 0.0422
INFO - 2024-10-02 15:31:21 --> Config Class Initialized
INFO - 2024-10-02 15:31:21 --> Hooks Class Initialized
DEBUG - 2024-10-02 15:31:21 --> UTF-8 Support Enabled
INFO - 2024-10-02 15:31:21 --> Utf8 Class Initialized
INFO - 2024-10-02 15:31:21 --> URI Class Initialized
INFO - 2024-10-02 15:31:21 --> Router Class Initialized
INFO - 2024-10-02 15:31:21 --> Output Class Initialized
INFO - 2024-10-02 15:31:21 --> Security Class Initialized
DEBUG - 2024-10-02 15:31:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-02 15:31:21 --> Input Class Initialized
INFO - 2024-10-02 15:31:21 --> Language Class Initialized
INFO - 2024-10-02 15:31:21 --> Language Class Initialized
INFO - 2024-10-02 15:31:21 --> Config Class Initialized
INFO - 2024-10-02 15:31:21 --> Loader Class Initialized
INFO - 2024-10-02 15:31:21 --> Helper loaded: url_helper
INFO - 2024-10-02 15:31:21 --> Helper loaded: file_helper
INFO - 2024-10-02 15:31:21 --> Helper loaded: form_helper
INFO - 2024-10-02 15:31:21 --> Helper loaded: my_helper
INFO - 2024-10-02 15:31:21 --> Database Driver Class Initialized
INFO - 2024-10-02 15:31:21 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-02 15:31:21 --> Controller Class Initialized
INFO - 2024-10-02 15:31:22 --> Final output sent to browser
DEBUG - 2024-10-02 15:31:22 --> Total execution time: 0.4191
INFO - 2024-10-02 15:33:58 --> Config Class Initialized
INFO - 2024-10-02 15:33:58 --> Hooks Class Initialized
DEBUG - 2024-10-02 15:33:58 --> UTF-8 Support Enabled
INFO - 2024-10-02 15:33:58 --> Utf8 Class Initialized
INFO - 2024-10-02 15:33:58 --> URI Class Initialized
DEBUG - 2024-10-02 15:33:58 --> No URI present. Default controller set.
INFO - 2024-10-02 15:33:58 --> Router Class Initialized
INFO - 2024-10-02 15:33:58 --> Output Class Initialized
INFO - 2024-10-02 15:33:58 --> Security Class Initialized
DEBUG - 2024-10-02 15:33:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-02 15:33:58 --> Input Class Initialized
INFO - 2024-10-02 15:33:58 --> Language Class Initialized
INFO - 2024-10-02 15:33:58 --> Language Class Initialized
INFO - 2024-10-02 15:33:58 --> Config Class Initialized
INFO - 2024-10-02 15:33:58 --> Loader Class Initialized
INFO - 2024-10-02 15:33:58 --> Helper loaded: url_helper
INFO - 2024-10-02 15:33:58 --> Helper loaded: file_helper
INFO - 2024-10-02 15:33:58 --> Helper loaded: form_helper
INFO - 2024-10-02 15:33:58 --> Helper loaded: my_helper
INFO - 2024-10-02 15:33:58 --> Database Driver Class Initialized
INFO - 2024-10-02 15:33:58 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-02 15:33:58 --> Controller Class Initialized
DEBUG - 2024-10-02 15:33:58 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/home/views/v_home_guru.php
DEBUG - 2024-10-02 15:33:58 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-10-02 15:33:58 --> Final output sent to browser
DEBUG - 2024-10-02 15:33:58 --> Total execution time: 0.0378
INFO - 2024-10-02 15:34:02 --> Config Class Initialized
INFO - 2024-10-02 15:34:02 --> Hooks Class Initialized
DEBUG - 2024-10-02 15:34:02 --> UTF-8 Support Enabled
INFO - 2024-10-02 15:34:02 --> Utf8 Class Initialized
INFO - 2024-10-02 15:34:02 --> URI Class Initialized
INFO - 2024-10-02 15:34:02 --> Router Class Initialized
INFO - 2024-10-02 15:34:02 --> Output Class Initialized
INFO - 2024-10-02 15:34:02 --> Security Class Initialized
DEBUG - 2024-10-02 15:34:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-02 15:34:02 --> Input Class Initialized
INFO - 2024-10-02 15:34:02 --> Language Class Initialized
INFO - 2024-10-02 15:34:02 --> Language Class Initialized
INFO - 2024-10-02 15:34:02 --> Config Class Initialized
INFO - 2024-10-02 15:34:02 --> Loader Class Initialized
INFO - 2024-10-02 15:34:02 --> Helper loaded: url_helper
INFO - 2024-10-02 15:34:02 --> Helper loaded: file_helper
INFO - 2024-10-02 15:34:02 --> Helper loaded: form_helper
INFO - 2024-10-02 15:34:02 --> Helper loaded: my_helper
INFO - 2024-10-02 15:34:02 --> Database Driver Class Initialized
INFO - 2024-10-02 15:34:02 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-02 15:34:02 --> Controller Class Initialized
INFO - 2024-10-02 15:34:02 --> Helper loaded: cookie_helper
INFO - 2024-10-02 15:34:02 --> Config Class Initialized
INFO - 2024-10-02 15:34:02 --> Hooks Class Initialized
DEBUG - 2024-10-02 15:34:02 --> UTF-8 Support Enabled
INFO - 2024-10-02 15:34:02 --> Utf8 Class Initialized
INFO - 2024-10-02 15:34:02 --> URI Class Initialized
INFO - 2024-10-02 15:34:02 --> Router Class Initialized
INFO - 2024-10-02 15:34:02 --> Output Class Initialized
INFO - 2024-10-02 15:34:02 --> Security Class Initialized
DEBUG - 2024-10-02 15:34:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-02 15:34:02 --> Input Class Initialized
INFO - 2024-10-02 15:34:02 --> Language Class Initialized
INFO - 2024-10-02 15:34:02 --> Language Class Initialized
INFO - 2024-10-02 15:34:02 --> Config Class Initialized
INFO - 2024-10-02 15:34:02 --> Loader Class Initialized
INFO - 2024-10-02 15:34:02 --> Helper loaded: url_helper
INFO - 2024-10-02 15:34:02 --> Helper loaded: file_helper
INFO - 2024-10-02 15:34:02 --> Helper loaded: form_helper
INFO - 2024-10-02 15:34:02 --> Helper loaded: my_helper
INFO - 2024-10-02 15:34:02 --> Database Driver Class Initialized
INFO - 2024-10-02 15:34:02 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-02 15:34:02 --> Controller Class Initialized
INFO - 2024-10-02 15:34:02 --> Config Class Initialized
INFO - 2024-10-02 15:34:02 --> Hooks Class Initialized
DEBUG - 2024-10-02 15:34:02 --> UTF-8 Support Enabled
INFO - 2024-10-02 15:34:02 --> Utf8 Class Initialized
INFO - 2024-10-02 15:34:02 --> URI Class Initialized
INFO - 2024-10-02 15:34:02 --> Router Class Initialized
INFO - 2024-10-02 15:34:02 --> Output Class Initialized
INFO - 2024-10-02 15:34:02 --> Security Class Initialized
DEBUG - 2024-10-02 15:34:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-02 15:34:02 --> Input Class Initialized
INFO - 2024-10-02 15:34:02 --> Language Class Initialized
INFO - 2024-10-02 15:34:02 --> Language Class Initialized
INFO - 2024-10-02 15:34:02 --> Config Class Initialized
INFO - 2024-10-02 15:34:02 --> Loader Class Initialized
INFO - 2024-10-02 15:34:02 --> Helper loaded: url_helper
INFO - 2024-10-02 15:34:02 --> Helper loaded: file_helper
INFO - 2024-10-02 15:34:02 --> Helper loaded: form_helper
INFO - 2024-10-02 15:34:02 --> Helper loaded: my_helper
INFO - 2024-10-02 15:34:02 --> Database Driver Class Initialized
INFO - 2024-10-02 15:34:02 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-02 15:34:02 --> Controller Class Initialized
DEBUG - 2024-10-02 15:34:02 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/login/views/login.php
DEBUG - 2024-10-02 15:34:02 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-10-02 15:34:02 --> Final output sent to browser
DEBUG - 2024-10-02 15:34:02 --> Total execution time: 0.0354
INFO - 2024-10-02 15:34:06 --> Config Class Initialized
INFO - 2024-10-02 15:34:06 --> Hooks Class Initialized
DEBUG - 2024-10-02 15:34:06 --> UTF-8 Support Enabled
INFO - 2024-10-02 15:34:06 --> Utf8 Class Initialized
INFO - 2024-10-02 15:34:06 --> URI Class Initialized
INFO - 2024-10-02 15:34:06 --> Router Class Initialized
INFO - 2024-10-02 15:34:06 --> Output Class Initialized
INFO - 2024-10-02 15:34:06 --> Security Class Initialized
DEBUG - 2024-10-02 15:34:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-02 15:34:06 --> Input Class Initialized
INFO - 2024-10-02 15:34:06 --> Language Class Initialized
INFO - 2024-10-02 15:34:06 --> Language Class Initialized
INFO - 2024-10-02 15:34:06 --> Config Class Initialized
INFO - 2024-10-02 15:34:06 --> Loader Class Initialized
INFO - 2024-10-02 15:34:06 --> Helper loaded: url_helper
INFO - 2024-10-02 15:34:06 --> Helper loaded: file_helper
INFO - 2024-10-02 15:34:06 --> Helper loaded: form_helper
INFO - 2024-10-02 15:34:06 --> Helper loaded: my_helper
INFO - 2024-10-02 15:34:06 --> Database Driver Class Initialized
INFO - 2024-10-02 15:34:06 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-02 15:34:06 --> Controller Class Initialized
INFO - 2024-10-02 15:34:06 --> Helper loaded: cookie_helper
INFO - 2024-10-02 15:34:06 --> Final output sent to browser
DEBUG - 2024-10-02 15:34:06 --> Total execution time: 0.0370
INFO - 2024-10-02 15:34:06 --> Config Class Initialized
INFO - 2024-10-02 15:34:06 --> Hooks Class Initialized
DEBUG - 2024-10-02 15:34:06 --> UTF-8 Support Enabled
INFO - 2024-10-02 15:34:06 --> Utf8 Class Initialized
INFO - 2024-10-02 15:34:06 --> URI Class Initialized
INFO - 2024-10-02 15:34:06 --> Router Class Initialized
INFO - 2024-10-02 15:34:06 --> Output Class Initialized
INFO - 2024-10-02 15:34:06 --> Security Class Initialized
DEBUG - 2024-10-02 15:34:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-02 15:34:06 --> Input Class Initialized
INFO - 2024-10-02 15:34:06 --> Language Class Initialized
INFO - 2024-10-02 15:34:06 --> Language Class Initialized
INFO - 2024-10-02 15:34:06 --> Config Class Initialized
INFO - 2024-10-02 15:34:06 --> Loader Class Initialized
INFO - 2024-10-02 15:34:06 --> Helper loaded: url_helper
INFO - 2024-10-02 15:34:06 --> Helper loaded: file_helper
INFO - 2024-10-02 15:34:06 --> Helper loaded: form_helper
INFO - 2024-10-02 15:34:06 --> Helper loaded: my_helper
INFO - 2024-10-02 15:34:06 --> Database Driver Class Initialized
INFO - 2024-10-02 15:34:06 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-02 15:34:06 --> Controller Class Initialized
DEBUG - 2024-10-02 15:34:06 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/home/views/v_home_guru.php
DEBUG - 2024-10-02 15:34:06 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-10-02 15:34:06 --> Final output sent to browser
DEBUG - 2024-10-02 15:34:06 --> Total execution time: 0.0355
INFO - 2024-10-02 15:34:10 --> Config Class Initialized
INFO - 2024-10-02 15:34:10 --> Hooks Class Initialized
DEBUG - 2024-10-02 15:34:10 --> UTF-8 Support Enabled
INFO - 2024-10-02 15:34:10 --> Utf8 Class Initialized
INFO - 2024-10-02 15:34:10 --> URI Class Initialized
INFO - 2024-10-02 15:34:10 --> Router Class Initialized
INFO - 2024-10-02 15:34:10 --> Output Class Initialized
INFO - 2024-10-02 15:34:10 --> Security Class Initialized
DEBUG - 2024-10-02 15:34:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-02 15:34:10 --> Input Class Initialized
INFO - 2024-10-02 15:34:10 --> Language Class Initialized
INFO - 2024-10-02 15:34:10 --> Language Class Initialized
INFO - 2024-10-02 15:34:10 --> Config Class Initialized
INFO - 2024-10-02 15:34:10 --> Loader Class Initialized
INFO - 2024-10-02 15:34:10 --> Helper loaded: url_helper
INFO - 2024-10-02 15:34:10 --> Helper loaded: file_helper
INFO - 2024-10-02 15:34:10 --> Helper loaded: form_helper
INFO - 2024-10-02 15:34:10 --> Helper loaded: my_helper
INFO - 2024-10-02 15:34:10 --> Database Driver Class Initialized
INFO - 2024-10-02 15:34:10 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-02 15:34:10 --> Controller Class Initialized
DEBUG - 2024-10-02 15:34:10 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/view_mapel/views/v_view_mapel.php
DEBUG - 2024-10-02 15:34:10 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-10-02 15:34:10 --> Final output sent to browser
DEBUG - 2024-10-02 15:34:10 --> Total execution time: 0.0335
INFO - 2024-10-02 15:34:12 --> Config Class Initialized
INFO - 2024-10-02 15:34:12 --> Hooks Class Initialized
DEBUG - 2024-10-02 15:34:12 --> UTF-8 Support Enabled
INFO - 2024-10-02 15:34:12 --> Utf8 Class Initialized
INFO - 2024-10-02 15:34:12 --> URI Class Initialized
INFO - 2024-10-02 15:34:12 --> Router Class Initialized
INFO - 2024-10-02 15:34:12 --> Output Class Initialized
INFO - 2024-10-02 15:34:12 --> Security Class Initialized
DEBUG - 2024-10-02 15:34:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-02 15:34:12 --> Input Class Initialized
INFO - 2024-10-02 15:34:12 --> Language Class Initialized
INFO - 2024-10-02 15:34:12 --> Language Class Initialized
INFO - 2024-10-02 15:34:12 --> Config Class Initialized
INFO - 2024-10-02 15:34:12 --> Loader Class Initialized
INFO - 2024-10-02 15:34:12 --> Helper loaded: url_helper
INFO - 2024-10-02 15:34:12 --> Helper loaded: file_helper
INFO - 2024-10-02 15:34:12 --> Helper loaded: form_helper
INFO - 2024-10-02 15:34:12 --> Helper loaded: my_helper
INFO - 2024-10-02 15:34:12 --> Database Driver Class Initialized
INFO - 2024-10-02 15:34:12 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-02 15:34:12 --> Controller Class Initialized
DEBUG - 2024-10-02 15:34:12 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/views/list.php
DEBUG - 2024-10-02 15:34:12 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-10-02 15:34:12 --> Final output sent to browser
DEBUG - 2024-10-02 15:34:12 --> Total execution time: 0.0305
INFO - 2024-10-02 15:34:12 --> Config Class Initialized
INFO - 2024-10-02 15:34:12 --> Hooks Class Initialized
DEBUG - 2024-10-02 15:34:12 --> UTF-8 Support Enabled
INFO - 2024-10-02 15:34:12 --> Utf8 Class Initialized
INFO - 2024-10-02 15:34:12 --> URI Class Initialized
INFO - 2024-10-02 15:34:12 --> Router Class Initialized
INFO - 2024-10-02 15:34:12 --> Output Class Initialized
INFO - 2024-10-02 15:34:12 --> Security Class Initialized
DEBUG - 2024-10-02 15:34:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-02 15:34:12 --> Input Class Initialized
INFO - 2024-10-02 15:34:12 --> Language Class Initialized
INFO - 2024-10-02 15:34:12 --> Language Class Initialized
INFO - 2024-10-02 15:34:12 --> Config Class Initialized
INFO - 2024-10-02 15:34:12 --> Loader Class Initialized
INFO - 2024-10-02 15:34:12 --> Helper loaded: url_helper
INFO - 2024-10-02 15:34:12 --> Helper loaded: file_helper
INFO - 2024-10-02 15:34:12 --> Helper loaded: form_helper
INFO - 2024-10-02 15:34:12 --> Helper loaded: my_helper
INFO - 2024-10-02 15:34:12 --> Database Driver Class Initialized
INFO - 2024-10-02 15:34:12 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-02 15:34:12 --> Controller Class Initialized
INFO - 2024-10-02 15:34:16 --> Config Class Initialized
INFO - 2024-10-02 15:34:16 --> Hooks Class Initialized
DEBUG - 2024-10-02 15:34:16 --> UTF-8 Support Enabled
INFO - 2024-10-02 15:34:16 --> Utf8 Class Initialized
INFO - 2024-10-02 15:34:16 --> URI Class Initialized
INFO - 2024-10-02 15:34:16 --> Router Class Initialized
INFO - 2024-10-02 15:34:16 --> Output Class Initialized
INFO - 2024-10-02 15:34:16 --> Security Class Initialized
DEBUG - 2024-10-02 15:34:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-02 15:34:16 --> Input Class Initialized
INFO - 2024-10-02 15:34:16 --> Language Class Initialized
INFO - 2024-10-02 15:34:16 --> Language Class Initialized
INFO - 2024-10-02 15:34:16 --> Config Class Initialized
INFO - 2024-10-02 15:34:16 --> Loader Class Initialized
INFO - 2024-10-02 15:34:16 --> Helper loaded: url_helper
INFO - 2024-10-02 15:34:16 --> Helper loaded: file_helper
INFO - 2024-10-02 15:34:16 --> Helper loaded: form_helper
INFO - 2024-10-02 15:34:16 --> Helper loaded: my_helper
INFO - 2024-10-02 15:34:16 --> Database Driver Class Initialized
INFO - 2024-10-02 15:34:16 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-02 15:34:16 --> Controller Class Initialized
DEBUG - 2024-10-02 15:34:16 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/view_mapel/views/v_view_mapel.php
DEBUG - 2024-10-02 15:34:16 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-10-02 15:34:16 --> Final output sent to browser
DEBUG - 2024-10-02 15:34:16 --> Total execution time: 0.0662
INFO - 2024-10-02 15:34:17 --> Config Class Initialized
INFO - 2024-10-02 15:34:17 --> Hooks Class Initialized
DEBUG - 2024-10-02 15:34:17 --> UTF-8 Support Enabled
INFO - 2024-10-02 15:34:17 --> Utf8 Class Initialized
INFO - 2024-10-02 15:34:17 --> URI Class Initialized
INFO - 2024-10-02 15:34:17 --> Router Class Initialized
INFO - 2024-10-02 15:34:17 --> Output Class Initialized
INFO - 2024-10-02 15:34:17 --> Security Class Initialized
DEBUG - 2024-10-02 15:34:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-02 15:34:17 --> Input Class Initialized
INFO - 2024-10-02 15:34:17 --> Language Class Initialized
INFO - 2024-10-02 15:34:17 --> Language Class Initialized
INFO - 2024-10-02 15:34:17 --> Config Class Initialized
INFO - 2024-10-02 15:34:17 --> Loader Class Initialized
INFO - 2024-10-02 15:34:17 --> Helper loaded: url_helper
INFO - 2024-10-02 15:34:17 --> Helper loaded: file_helper
INFO - 2024-10-02 15:34:17 --> Helper loaded: form_helper
INFO - 2024-10-02 15:34:17 --> Helper loaded: my_helper
INFO - 2024-10-02 15:34:17 --> Database Driver Class Initialized
INFO - 2024-10-02 15:34:17 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-02 15:34:17 --> Controller Class Initialized
DEBUG - 2024-10-02 15:34:17 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/views/list.php
DEBUG - 2024-10-02 15:34:17 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-10-02 15:34:17 --> Final output sent to browser
DEBUG - 2024-10-02 15:34:17 --> Total execution time: 0.0315
INFO - 2024-10-02 15:34:18 --> Config Class Initialized
INFO - 2024-10-02 15:34:18 --> Hooks Class Initialized
DEBUG - 2024-10-02 15:34:18 --> UTF-8 Support Enabled
INFO - 2024-10-02 15:34:18 --> Utf8 Class Initialized
INFO - 2024-10-02 15:34:18 --> URI Class Initialized
INFO - 2024-10-02 15:34:18 --> Router Class Initialized
INFO - 2024-10-02 15:34:18 --> Output Class Initialized
INFO - 2024-10-02 15:34:18 --> Security Class Initialized
DEBUG - 2024-10-02 15:34:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-02 15:34:18 --> Input Class Initialized
INFO - 2024-10-02 15:34:18 --> Language Class Initialized
INFO - 2024-10-02 15:34:18 --> Language Class Initialized
INFO - 2024-10-02 15:34:18 --> Config Class Initialized
INFO - 2024-10-02 15:34:18 --> Loader Class Initialized
INFO - 2024-10-02 15:34:18 --> Helper loaded: url_helper
INFO - 2024-10-02 15:34:18 --> Helper loaded: file_helper
INFO - 2024-10-02 15:34:18 --> Helper loaded: form_helper
INFO - 2024-10-02 15:34:18 --> Helper loaded: my_helper
INFO - 2024-10-02 15:34:18 --> Database Driver Class Initialized
INFO - 2024-10-02 15:34:18 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-02 15:34:18 --> Controller Class Initialized
INFO - 2024-10-02 15:34:20 --> Config Class Initialized
INFO - 2024-10-02 15:34:20 --> Hooks Class Initialized
DEBUG - 2024-10-02 15:34:20 --> UTF-8 Support Enabled
INFO - 2024-10-02 15:34:20 --> Utf8 Class Initialized
INFO - 2024-10-02 15:34:20 --> URI Class Initialized
INFO - 2024-10-02 15:34:20 --> Router Class Initialized
INFO - 2024-10-02 15:34:20 --> Output Class Initialized
INFO - 2024-10-02 15:34:20 --> Security Class Initialized
DEBUG - 2024-10-02 15:34:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-02 15:34:20 --> Input Class Initialized
INFO - 2024-10-02 15:34:20 --> Language Class Initialized
INFO - 2024-10-02 15:34:20 --> Language Class Initialized
INFO - 2024-10-02 15:34:20 --> Config Class Initialized
INFO - 2024-10-02 15:34:20 --> Loader Class Initialized
INFO - 2024-10-02 15:34:20 --> Helper loaded: url_helper
INFO - 2024-10-02 15:34:20 --> Helper loaded: file_helper
INFO - 2024-10-02 15:34:20 --> Helper loaded: form_helper
INFO - 2024-10-02 15:34:20 --> Helper loaded: my_helper
INFO - 2024-10-02 15:34:20 --> Database Driver Class Initialized
INFO - 2024-10-02 15:34:20 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-02 15:34:20 --> Controller Class Initialized
DEBUG - 2024-10-02 15:34:20 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/view_mapel/views/v_view_mapel.php
DEBUG - 2024-10-02 15:34:20 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-10-02 15:34:20 --> Final output sent to browser
DEBUG - 2024-10-02 15:34:20 --> Total execution time: 0.0295
INFO - 2024-10-02 15:34:22 --> Config Class Initialized
INFO - 2024-10-02 15:34:22 --> Hooks Class Initialized
DEBUG - 2024-10-02 15:34:22 --> UTF-8 Support Enabled
INFO - 2024-10-02 15:34:22 --> Utf8 Class Initialized
INFO - 2024-10-02 15:34:22 --> URI Class Initialized
INFO - 2024-10-02 15:34:22 --> Router Class Initialized
INFO - 2024-10-02 15:34:22 --> Output Class Initialized
INFO - 2024-10-02 15:34:22 --> Security Class Initialized
DEBUG - 2024-10-02 15:34:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-02 15:34:22 --> Input Class Initialized
INFO - 2024-10-02 15:34:22 --> Language Class Initialized
INFO - 2024-10-02 15:34:22 --> Language Class Initialized
INFO - 2024-10-02 15:34:22 --> Config Class Initialized
INFO - 2024-10-02 15:34:22 --> Loader Class Initialized
INFO - 2024-10-02 15:34:22 --> Helper loaded: url_helper
INFO - 2024-10-02 15:34:22 --> Helper loaded: file_helper
INFO - 2024-10-02 15:34:22 --> Helper loaded: form_helper
INFO - 2024-10-02 15:34:22 --> Helper loaded: my_helper
INFO - 2024-10-02 15:34:23 --> Database Driver Class Initialized
INFO - 2024-10-02 15:34:23 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-02 15:34:23 --> Controller Class Initialized
DEBUG - 2024-10-02 15:34:23 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/views/list.php
DEBUG - 2024-10-02 15:34:23 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-10-02 15:34:23 --> Final output sent to browser
DEBUG - 2024-10-02 15:34:23 --> Total execution time: 0.0540
INFO - 2024-10-02 15:34:23 --> Config Class Initialized
INFO - 2024-10-02 15:34:23 --> Hooks Class Initialized
DEBUG - 2024-10-02 15:34:23 --> UTF-8 Support Enabled
INFO - 2024-10-02 15:34:23 --> Utf8 Class Initialized
INFO - 2024-10-02 15:34:23 --> URI Class Initialized
INFO - 2024-10-02 15:34:23 --> Router Class Initialized
INFO - 2024-10-02 15:34:23 --> Output Class Initialized
INFO - 2024-10-02 15:34:23 --> Security Class Initialized
DEBUG - 2024-10-02 15:34:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-02 15:34:23 --> Input Class Initialized
INFO - 2024-10-02 15:34:23 --> Language Class Initialized
INFO - 2024-10-02 15:34:23 --> Language Class Initialized
INFO - 2024-10-02 15:34:23 --> Config Class Initialized
INFO - 2024-10-02 15:34:23 --> Loader Class Initialized
INFO - 2024-10-02 15:34:23 --> Helper loaded: url_helper
INFO - 2024-10-02 15:34:23 --> Helper loaded: file_helper
INFO - 2024-10-02 15:34:23 --> Helper loaded: form_helper
INFO - 2024-10-02 15:34:23 --> Helper loaded: my_helper
INFO - 2024-10-02 15:34:23 --> Database Driver Class Initialized
INFO - 2024-10-02 15:34:23 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-02 15:34:23 --> Controller Class Initialized
INFO - 2024-10-02 15:34:25 --> Config Class Initialized
INFO - 2024-10-02 15:34:25 --> Hooks Class Initialized
DEBUG - 2024-10-02 15:34:25 --> UTF-8 Support Enabled
INFO - 2024-10-02 15:34:25 --> Utf8 Class Initialized
INFO - 2024-10-02 15:34:25 --> URI Class Initialized
INFO - 2024-10-02 15:34:25 --> Router Class Initialized
INFO - 2024-10-02 15:34:25 --> Output Class Initialized
INFO - 2024-10-02 15:34:25 --> Security Class Initialized
DEBUG - 2024-10-02 15:34:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-02 15:34:25 --> Input Class Initialized
INFO - 2024-10-02 15:34:25 --> Language Class Initialized
INFO - 2024-10-02 15:34:25 --> Language Class Initialized
INFO - 2024-10-02 15:34:25 --> Config Class Initialized
INFO - 2024-10-02 15:34:25 --> Loader Class Initialized
INFO - 2024-10-02 15:34:25 --> Helper loaded: url_helper
INFO - 2024-10-02 15:34:25 --> Helper loaded: file_helper
INFO - 2024-10-02 15:34:25 --> Helper loaded: form_helper
INFO - 2024-10-02 15:34:25 --> Helper loaded: my_helper
INFO - 2024-10-02 15:34:25 --> Database Driver Class Initialized
INFO - 2024-10-02 15:34:25 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-02 15:34:25 --> Controller Class Initialized
INFO - 2024-10-02 15:34:25 --> Final output sent to browser
DEBUG - 2024-10-02 15:34:25 --> Total execution time: 0.0366
INFO - 2024-10-02 15:34:41 --> Config Class Initialized
INFO - 2024-10-02 15:34:41 --> Hooks Class Initialized
DEBUG - 2024-10-02 15:34:41 --> UTF-8 Support Enabled
INFO - 2024-10-02 15:34:41 --> Utf8 Class Initialized
INFO - 2024-10-02 15:34:41 --> URI Class Initialized
INFO - 2024-10-02 15:34:41 --> Router Class Initialized
INFO - 2024-10-02 15:34:41 --> Output Class Initialized
INFO - 2024-10-02 15:34:41 --> Security Class Initialized
DEBUG - 2024-10-02 15:34:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-02 15:34:41 --> Input Class Initialized
INFO - 2024-10-02 15:34:41 --> Language Class Initialized
INFO - 2024-10-02 15:34:41 --> Language Class Initialized
INFO - 2024-10-02 15:34:41 --> Config Class Initialized
INFO - 2024-10-02 15:34:41 --> Loader Class Initialized
INFO - 2024-10-02 15:34:41 --> Helper loaded: url_helper
INFO - 2024-10-02 15:34:41 --> Helper loaded: file_helper
INFO - 2024-10-02 15:34:41 --> Helper loaded: form_helper
INFO - 2024-10-02 15:34:41 --> Helper loaded: my_helper
INFO - 2024-10-02 15:34:41 --> Database Driver Class Initialized
INFO - 2024-10-02 15:34:41 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-02 15:34:41 --> Controller Class Initialized
INFO - 2024-10-02 15:34:41 --> Final output sent to browser
DEBUG - 2024-10-02 15:34:41 --> Total execution time: 0.0861
INFO - 2024-10-02 15:34:41 --> Config Class Initialized
INFO - 2024-10-02 15:34:41 --> Hooks Class Initialized
DEBUG - 2024-10-02 15:34:41 --> UTF-8 Support Enabled
INFO - 2024-10-02 15:34:41 --> Utf8 Class Initialized
INFO - 2024-10-02 15:34:41 --> URI Class Initialized
INFO - 2024-10-02 15:34:41 --> Router Class Initialized
INFO - 2024-10-02 15:34:41 --> Output Class Initialized
INFO - 2024-10-02 15:34:41 --> Security Class Initialized
DEBUG - 2024-10-02 15:34:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-02 15:34:41 --> Input Class Initialized
INFO - 2024-10-02 15:34:41 --> Language Class Initialized
INFO - 2024-10-02 15:34:41 --> Language Class Initialized
INFO - 2024-10-02 15:34:41 --> Config Class Initialized
INFO - 2024-10-02 15:34:41 --> Loader Class Initialized
INFO - 2024-10-02 15:34:41 --> Helper loaded: url_helper
INFO - 2024-10-02 15:34:41 --> Helper loaded: file_helper
INFO - 2024-10-02 15:34:41 --> Helper loaded: form_helper
INFO - 2024-10-02 15:34:41 --> Helper loaded: my_helper
INFO - 2024-10-02 15:34:41 --> Database Driver Class Initialized
INFO - 2024-10-02 15:34:41 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-02 15:34:41 --> Controller Class Initialized
INFO - 2024-10-02 15:34:42 --> Config Class Initialized
INFO - 2024-10-02 15:34:42 --> Hooks Class Initialized
DEBUG - 2024-10-02 15:34:42 --> UTF-8 Support Enabled
INFO - 2024-10-02 15:34:42 --> Utf8 Class Initialized
INFO - 2024-10-02 15:34:42 --> URI Class Initialized
INFO - 2024-10-02 15:34:42 --> Router Class Initialized
INFO - 2024-10-02 15:34:42 --> Output Class Initialized
INFO - 2024-10-02 15:34:42 --> Security Class Initialized
DEBUG - 2024-10-02 15:34:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-02 15:34:42 --> Input Class Initialized
INFO - 2024-10-02 15:34:42 --> Language Class Initialized
INFO - 2024-10-02 15:34:42 --> Language Class Initialized
INFO - 2024-10-02 15:34:42 --> Config Class Initialized
INFO - 2024-10-02 15:34:42 --> Loader Class Initialized
INFO - 2024-10-02 15:34:42 --> Helper loaded: url_helper
INFO - 2024-10-02 15:34:42 --> Helper loaded: file_helper
INFO - 2024-10-02 15:34:42 --> Helper loaded: form_helper
INFO - 2024-10-02 15:34:42 --> Helper loaded: my_helper
INFO - 2024-10-02 15:34:42 --> Database Driver Class Initialized
INFO - 2024-10-02 15:34:42 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-02 15:34:42 --> Controller Class Initialized
INFO - 2024-10-02 15:34:42 --> Final output sent to browser
DEBUG - 2024-10-02 15:34:42 --> Total execution time: 0.0287
INFO - 2024-10-02 15:34:49 --> Config Class Initialized
INFO - 2024-10-02 15:34:49 --> Hooks Class Initialized
DEBUG - 2024-10-02 15:34:49 --> UTF-8 Support Enabled
INFO - 2024-10-02 15:34:49 --> Utf8 Class Initialized
INFO - 2024-10-02 15:34:49 --> URI Class Initialized
INFO - 2024-10-02 15:34:49 --> Router Class Initialized
INFO - 2024-10-02 15:34:49 --> Output Class Initialized
INFO - 2024-10-02 15:34:49 --> Security Class Initialized
DEBUG - 2024-10-02 15:34:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-02 15:34:49 --> Input Class Initialized
INFO - 2024-10-02 15:34:49 --> Language Class Initialized
INFO - 2024-10-02 15:34:49 --> Language Class Initialized
INFO - 2024-10-02 15:34:49 --> Config Class Initialized
INFO - 2024-10-02 15:34:49 --> Loader Class Initialized
INFO - 2024-10-02 15:34:49 --> Helper loaded: url_helper
INFO - 2024-10-02 15:34:50 --> Helper loaded: file_helper
INFO - 2024-10-02 15:34:50 --> Helper loaded: form_helper
INFO - 2024-10-02 15:34:50 --> Helper loaded: my_helper
INFO - 2024-10-02 15:34:50 --> Database Driver Class Initialized
INFO - 2024-10-02 15:34:50 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-02 15:34:50 --> Controller Class Initialized
INFO - 2024-10-02 15:34:50 --> Final output sent to browser
DEBUG - 2024-10-02 15:34:50 --> Total execution time: 0.0284
INFO - 2024-10-02 15:34:54 --> Config Class Initialized
INFO - 2024-10-02 15:34:54 --> Hooks Class Initialized
DEBUG - 2024-10-02 15:34:54 --> UTF-8 Support Enabled
INFO - 2024-10-02 15:34:54 --> Utf8 Class Initialized
INFO - 2024-10-02 15:34:54 --> URI Class Initialized
INFO - 2024-10-02 15:34:54 --> Router Class Initialized
INFO - 2024-10-02 15:34:54 --> Output Class Initialized
INFO - 2024-10-02 15:34:54 --> Security Class Initialized
DEBUG - 2024-10-02 15:34:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-02 15:34:54 --> Input Class Initialized
INFO - 2024-10-02 15:34:54 --> Language Class Initialized
INFO - 2024-10-02 15:34:54 --> Language Class Initialized
INFO - 2024-10-02 15:34:54 --> Config Class Initialized
INFO - 2024-10-02 15:34:54 --> Loader Class Initialized
INFO - 2024-10-02 15:34:54 --> Helper loaded: url_helper
INFO - 2024-10-02 15:34:54 --> Helper loaded: file_helper
INFO - 2024-10-02 15:34:54 --> Helper loaded: form_helper
INFO - 2024-10-02 15:34:54 --> Helper loaded: my_helper
INFO - 2024-10-02 15:34:54 --> Database Driver Class Initialized
INFO - 2024-10-02 15:34:54 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-02 15:34:54 --> Controller Class Initialized
INFO - 2024-10-02 15:34:54 --> Final output sent to browser
DEBUG - 2024-10-02 15:34:54 --> Total execution time: 0.0333
INFO - 2024-10-02 15:34:54 --> Config Class Initialized
INFO - 2024-10-02 15:34:54 --> Hooks Class Initialized
DEBUG - 2024-10-02 15:34:54 --> UTF-8 Support Enabled
INFO - 2024-10-02 15:34:54 --> Utf8 Class Initialized
INFO - 2024-10-02 15:34:54 --> URI Class Initialized
INFO - 2024-10-02 15:34:54 --> Router Class Initialized
INFO - 2024-10-02 15:34:54 --> Output Class Initialized
INFO - 2024-10-02 15:34:54 --> Security Class Initialized
DEBUG - 2024-10-02 15:34:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-02 15:34:54 --> Input Class Initialized
INFO - 2024-10-02 15:34:54 --> Language Class Initialized
INFO - 2024-10-02 15:34:54 --> Language Class Initialized
INFO - 2024-10-02 15:34:54 --> Config Class Initialized
INFO - 2024-10-02 15:34:54 --> Loader Class Initialized
INFO - 2024-10-02 15:34:54 --> Helper loaded: url_helper
INFO - 2024-10-02 15:34:54 --> Helper loaded: file_helper
INFO - 2024-10-02 15:34:54 --> Helper loaded: form_helper
INFO - 2024-10-02 15:34:54 --> Helper loaded: my_helper
INFO - 2024-10-02 15:34:54 --> Database Driver Class Initialized
INFO - 2024-10-02 15:34:54 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-02 15:34:54 --> Controller Class Initialized
INFO - 2024-10-02 15:34:56 --> Config Class Initialized
INFO - 2024-10-02 15:34:56 --> Hooks Class Initialized
DEBUG - 2024-10-02 15:34:56 --> UTF-8 Support Enabled
INFO - 2024-10-02 15:34:56 --> Utf8 Class Initialized
INFO - 2024-10-02 15:34:56 --> URI Class Initialized
INFO - 2024-10-02 15:34:56 --> Router Class Initialized
INFO - 2024-10-02 15:34:56 --> Output Class Initialized
INFO - 2024-10-02 15:34:56 --> Security Class Initialized
DEBUG - 2024-10-02 15:34:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-02 15:34:56 --> Input Class Initialized
INFO - 2024-10-02 15:34:56 --> Language Class Initialized
INFO - 2024-10-02 15:34:56 --> Language Class Initialized
INFO - 2024-10-02 15:34:56 --> Config Class Initialized
INFO - 2024-10-02 15:34:56 --> Loader Class Initialized
INFO - 2024-10-02 15:34:56 --> Helper loaded: url_helper
INFO - 2024-10-02 15:34:56 --> Helper loaded: file_helper
INFO - 2024-10-02 15:34:56 --> Helper loaded: form_helper
INFO - 2024-10-02 15:34:56 --> Helper loaded: my_helper
INFO - 2024-10-02 15:34:56 --> Database Driver Class Initialized
INFO - 2024-10-02 15:34:56 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-02 15:34:56 --> Controller Class Initialized
INFO - 2024-10-02 15:34:56 --> Final output sent to browser
DEBUG - 2024-10-02 15:34:56 --> Total execution time: 0.0328
INFO - 2024-10-02 15:35:04 --> Config Class Initialized
INFO - 2024-10-02 15:35:04 --> Hooks Class Initialized
DEBUG - 2024-10-02 15:35:04 --> UTF-8 Support Enabled
INFO - 2024-10-02 15:35:04 --> Utf8 Class Initialized
INFO - 2024-10-02 15:35:04 --> URI Class Initialized
INFO - 2024-10-02 15:35:04 --> Router Class Initialized
INFO - 2024-10-02 15:35:04 --> Output Class Initialized
INFO - 2024-10-02 15:35:04 --> Security Class Initialized
DEBUG - 2024-10-02 15:35:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-02 15:35:04 --> Input Class Initialized
INFO - 2024-10-02 15:35:04 --> Language Class Initialized
INFO - 2024-10-02 15:35:04 --> Language Class Initialized
INFO - 2024-10-02 15:35:04 --> Config Class Initialized
INFO - 2024-10-02 15:35:04 --> Loader Class Initialized
INFO - 2024-10-02 15:35:04 --> Helper loaded: url_helper
INFO - 2024-10-02 15:35:04 --> Helper loaded: file_helper
INFO - 2024-10-02 15:35:04 --> Helper loaded: form_helper
INFO - 2024-10-02 15:35:04 --> Helper loaded: my_helper
INFO - 2024-10-02 15:35:04 --> Database Driver Class Initialized
INFO - 2024-10-02 15:35:04 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-02 15:35:04 --> Controller Class Initialized
DEBUG - 2024-10-02 15:35:04 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/view_mapel/views/v_view_mapel.php
DEBUG - 2024-10-02 15:35:04 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-10-02 15:35:04 --> Final output sent to browser
DEBUG - 2024-10-02 15:35:04 --> Total execution time: 0.0353
INFO - 2024-10-02 15:35:07 --> Config Class Initialized
INFO - 2024-10-02 15:35:07 --> Hooks Class Initialized
DEBUG - 2024-10-02 15:35:07 --> UTF-8 Support Enabled
INFO - 2024-10-02 15:35:07 --> Utf8 Class Initialized
INFO - 2024-10-02 15:35:07 --> URI Class Initialized
INFO - 2024-10-02 15:35:07 --> Router Class Initialized
INFO - 2024-10-02 15:35:07 --> Output Class Initialized
INFO - 2024-10-02 15:35:07 --> Security Class Initialized
DEBUG - 2024-10-02 15:35:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-02 15:35:07 --> Input Class Initialized
INFO - 2024-10-02 15:35:07 --> Language Class Initialized
INFO - 2024-10-02 15:35:07 --> Language Class Initialized
INFO - 2024-10-02 15:35:07 --> Config Class Initialized
INFO - 2024-10-02 15:35:07 --> Loader Class Initialized
INFO - 2024-10-02 15:35:07 --> Helper loaded: url_helper
INFO - 2024-10-02 15:35:07 --> Helper loaded: file_helper
INFO - 2024-10-02 15:35:07 --> Helper loaded: form_helper
INFO - 2024-10-02 15:35:07 --> Helper loaded: my_helper
INFO - 2024-10-02 15:35:07 --> Database Driver Class Initialized
INFO - 2024-10-02 15:35:07 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-02 15:35:07 --> Controller Class Initialized
DEBUG - 2024-10-02 15:35:07 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_icb/views/list.php
DEBUG - 2024-10-02 15:35:07 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-10-02 15:35:07 --> Final output sent to browser
DEBUG - 2024-10-02 15:35:07 --> Total execution time: 0.0418
INFO - 2024-10-02 15:35:07 --> Config Class Initialized
INFO - 2024-10-02 15:35:07 --> Hooks Class Initialized
DEBUG - 2024-10-02 15:35:07 --> UTF-8 Support Enabled
INFO - 2024-10-02 15:35:07 --> Utf8 Class Initialized
INFO - 2024-10-02 15:35:07 --> URI Class Initialized
INFO - 2024-10-02 15:35:07 --> Router Class Initialized
INFO - 2024-10-02 15:35:07 --> Output Class Initialized
INFO - 2024-10-02 15:35:07 --> Security Class Initialized
DEBUG - 2024-10-02 15:35:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-02 15:35:07 --> Input Class Initialized
INFO - 2024-10-02 15:35:07 --> Language Class Initialized
INFO - 2024-10-02 15:35:07 --> Language Class Initialized
INFO - 2024-10-02 15:35:07 --> Config Class Initialized
INFO - 2024-10-02 15:35:07 --> Loader Class Initialized
INFO - 2024-10-02 15:35:07 --> Helper loaded: url_helper
INFO - 2024-10-02 15:35:07 --> Helper loaded: file_helper
INFO - 2024-10-02 15:35:07 --> Helper loaded: form_helper
INFO - 2024-10-02 15:35:07 --> Helper loaded: my_helper
INFO - 2024-10-02 15:35:07 --> Database Driver Class Initialized
INFO - 2024-10-02 15:35:07 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-02 15:35:07 --> Controller Class Initialized
INFO - 2024-10-02 15:35:10 --> Config Class Initialized
INFO - 2024-10-02 15:35:10 --> Hooks Class Initialized
DEBUG - 2024-10-02 15:35:10 --> UTF-8 Support Enabled
INFO - 2024-10-02 15:35:10 --> Utf8 Class Initialized
INFO - 2024-10-02 15:35:10 --> URI Class Initialized
INFO - 2024-10-02 15:35:10 --> Router Class Initialized
INFO - 2024-10-02 15:35:10 --> Output Class Initialized
INFO - 2024-10-02 15:35:10 --> Security Class Initialized
DEBUG - 2024-10-02 15:35:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-02 15:35:10 --> Input Class Initialized
INFO - 2024-10-02 15:35:10 --> Language Class Initialized
INFO - 2024-10-02 15:35:10 --> Language Class Initialized
INFO - 2024-10-02 15:35:10 --> Config Class Initialized
INFO - 2024-10-02 15:35:10 --> Loader Class Initialized
INFO - 2024-10-02 15:35:10 --> Helper loaded: url_helper
INFO - 2024-10-02 15:35:10 --> Helper loaded: file_helper
INFO - 2024-10-02 15:35:10 --> Helper loaded: form_helper
INFO - 2024-10-02 15:35:10 --> Helper loaded: my_helper
INFO - 2024-10-02 15:35:10 --> Database Driver Class Initialized
INFO - 2024-10-02 15:35:10 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-02 15:35:10 --> Controller Class Initialized
DEBUG - 2024-10-02 15:35:10 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/view_mapel/views/v_view_mapel.php
DEBUG - 2024-10-02 15:35:10 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-10-02 15:35:10 --> Final output sent to browser
DEBUG - 2024-10-02 15:35:10 --> Total execution time: 0.0812
INFO - 2024-10-02 15:35:13 --> Config Class Initialized
INFO - 2024-10-02 15:35:13 --> Hooks Class Initialized
DEBUG - 2024-10-02 15:35:13 --> UTF-8 Support Enabled
INFO - 2024-10-02 15:35:13 --> Utf8 Class Initialized
INFO - 2024-10-02 15:35:13 --> URI Class Initialized
INFO - 2024-10-02 15:35:13 --> Router Class Initialized
INFO - 2024-10-02 15:35:13 --> Output Class Initialized
INFO - 2024-10-02 15:35:13 --> Security Class Initialized
DEBUG - 2024-10-02 15:35:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-02 15:35:13 --> Input Class Initialized
INFO - 2024-10-02 15:35:13 --> Language Class Initialized
INFO - 2024-10-02 15:35:13 --> Language Class Initialized
INFO - 2024-10-02 15:35:13 --> Config Class Initialized
INFO - 2024-10-02 15:35:13 --> Loader Class Initialized
INFO - 2024-10-02 15:35:13 --> Helper loaded: url_helper
INFO - 2024-10-02 15:35:13 --> Helper loaded: file_helper
INFO - 2024-10-02 15:35:13 --> Helper loaded: form_helper
INFO - 2024-10-02 15:35:13 --> Helper loaded: my_helper
INFO - 2024-10-02 15:35:13 --> Database Driver Class Initialized
INFO - 2024-10-02 15:35:13 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-02 15:35:13 --> Controller Class Initialized
DEBUG - 2024-10-02 15:35:13 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pss/views/list.php
DEBUG - 2024-10-02 15:35:13 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-10-02 15:35:13 --> Final output sent to browser
DEBUG - 2024-10-02 15:35:13 --> Total execution time: 0.0764
INFO - 2024-10-02 15:35:14 --> Config Class Initialized
INFO - 2024-10-02 15:35:14 --> Hooks Class Initialized
DEBUG - 2024-10-02 15:35:14 --> UTF-8 Support Enabled
INFO - 2024-10-02 15:35:14 --> Utf8 Class Initialized
INFO - 2024-10-02 15:35:14 --> URI Class Initialized
INFO - 2024-10-02 15:35:14 --> Router Class Initialized
INFO - 2024-10-02 15:35:14 --> Output Class Initialized
INFO - 2024-10-02 15:35:14 --> Security Class Initialized
DEBUG - 2024-10-02 15:35:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-02 15:35:14 --> Input Class Initialized
INFO - 2024-10-02 15:35:14 --> Language Class Initialized
INFO - 2024-10-02 15:35:14 --> Language Class Initialized
INFO - 2024-10-02 15:35:14 --> Config Class Initialized
INFO - 2024-10-02 15:35:14 --> Loader Class Initialized
INFO - 2024-10-02 15:35:14 --> Helper loaded: url_helper
INFO - 2024-10-02 15:35:14 --> Helper loaded: file_helper
INFO - 2024-10-02 15:35:14 --> Helper loaded: form_helper
INFO - 2024-10-02 15:35:14 --> Helper loaded: my_helper
INFO - 2024-10-02 15:35:14 --> Database Driver Class Initialized
INFO - 2024-10-02 15:35:14 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-02 15:35:14 --> Controller Class Initialized
INFO - 2024-10-02 15:35:16 --> Config Class Initialized
INFO - 2024-10-02 15:35:16 --> Hooks Class Initialized
DEBUG - 2024-10-02 15:35:16 --> UTF-8 Support Enabled
INFO - 2024-10-02 15:35:16 --> Utf8 Class Initialized
INFO - 2024-10-02 15:35:16 --> URI Class Initialized
INFO - 2024-10-02 15:35:16 --> Router Class Initialized
INFO - 2024-10-02 15:35:16 --> Output Class Initialized
INFO - 2024-10-02 15:35:16 --> Security Class Initialized
DEBUG - 2024-10-02 15:35:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-02 15:35:16 --> Input Class Initialized
INFO - 2024-10-02 15:35:16 --> Language Class Initialized
INFO - 2024-10-02 15:35:16 --> Language Class Initialized
INFO - 2024-10-02 15:35:16 --> Config Class Initialized
INFO - 2024-10-02 15:35:16 --> Loader Class Initialized
INFO - 2024-10-02 15:35:16 --> Helper loaded: url_helper
INFO - 2024-10-02 15:35:16 --> Helper loaded: file_helper
INFO - 2024-10-02 15:35:16 --> Helper loaded: form_helper
INFO - 2024-10-02 15:35:16 --> Helper loaded: my_helper
INFO - 2024-10-02 15:35:16 --> Database Driver Class Initialized
INFO - 2024-10-02 15:35:16 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-02 15:35:16 --> Controller Class Initialized
DEBUG - 2024-10-02 15:35:16 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/view_mapel/views/v_view_mapel.php
DEBUG - 2024-10-02 15:35:16 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-10-02 15:35:16 --> Final output sent to browser
DEBUG - 2024-10-02 15:35:16 --> Total execution time: 0.0336
INFO - 2024-10-02 15:35:17 --> Config Class Initialized
INFO - 2024-10-02 15:35:17 --> Hooks Class Initialized
DEBUG - 2024-10-02 15:35:17 --> UTF-8 Support Enabled
INFO - 2024-10-02 15:35:17 --> Utf8 Class Initialized
INFO - 2024-10-02 15:35:17 --> URI Class Initialized
INFO - 2024-10-02 15:35:17 --> Router Class Initialized
INFO - 2024-10-02 15:35:17 --> Output Class Initialized
INFO - 2024-10-02 15:35:17 --> Security Class Initialized
DEBUG - 2024-10-02 15:35:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-02 15:35:17 --> Input Class Initialized
INFO - 2024-10-02 15:35:17 --> Language Class Initialized
INFO - 2024-10-02 15:35:17 --> Language Class Initialized
INFO - 2024-10-02 15:35:17 --> Config Class Initialized
INFO - 2024-10-02 15:35:17 --> Loader Class Initialized
INFO - 2024-10-02 15:35:17 --> Helper loaded: url_helper
INFO - 2024-10-02 15:35:17 --> Helper loaded: file_helper
INFO - 2024-10-02 15:35:17 --> Helper loaded: form_helper
INFO - 2024-10-02 15:35:17 --> Helper loaded: my_helper
INFO - 2024-10-02 15:35:17 --> Database Driver Class Initialized
INFO - 2024-10-02 15:35:17 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-02 15:35:17 --> Controller Class Initialized
INFO - 2024-10-02 15:35:17 --> Final output sent to browser
DEBUG - 2024-10-02 15:35:17 --> Total execution time: 0.0332
INFO - 2024-10-02 15:35:17 --> Config Class Initialized
INFO - 2024-10-02 15:35:17 --> Hooks Class Initialized
DEBUG - 2024-10-02 15:35:17 --> UTF-8 Support Enabled
INFO - 2024-10-02 15:35:17 --> Utf8 Class Initialized
INFO - 2024-10-02 15:35:17 --> URI Class Initialized
INFO - 2024-10-02 15:35:17 --> Router Class Initialized
INFO - 2024-10-02 15:35:17 --> Output Class Initialized
INFO - 2024-10-02 15:35:17 --> Security Class Initialized
DEBUG - 2024-10-02 15:35:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-02 15:35:17 --> Input Class Initialized
INFO - 2024-10-02 15:35:17 --> Language Class Initialized
INFO - 2024-10-02 15:35:17 --> Language Class Initialized
INFO - 2024-10-02 15:35:17 --> Config Class Initialized
INFO - 2024-10-02 15:35:17 --> Loader Class Initialized
INFO - 2024-10-02 15:35:17 --> Helper loaded: url_helper
INFO - 2024-10-02 15:35:17 --> Helper loaded: file_helper
INFO - 2024-10-02 15:35:17 --> Helper loaded: form_helper
INFO - 2024-10-02 15:35:17 --> Helper loaded: my_helper
INFO - 2024-10-02 15:35:17 --> Database Driver Class Initialized
INFO - 2024-10-02 15:35:17 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-02 15:35:17 --> Controller Class Initialized
INFO - 2024-10-02 15:35:18 --> Config Class Initialized
INFO - 2024-10-02 15:35:18 --> Hooks Class Initialized
DEBUG - 2024-10-02 15:35:18 --> UTF-8 Support Enabled
INFO - 2024-10-02 15:35:18 --> Utf8 Class Initialized
INFO - 2024-10-02 15:35:18 --> URI Class Initialized
INFO - 2024-10-02 15:35:18 --> Router Class Initialized
INFO - 2024-10-02 15:35:18 --> Output Class Initialized
INFO - 2024-10-02 15:35:18 --> Security Class Initialized
DEBUG - 2024-10-02 15:35:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-02 15:35:18 --> Input Class Initialized
INFO - 2024-10-02 15:35:18 --> Language Class Initialized
INFO - 2024-10-02 15:35:18 --> Language Class Initialized
INFO - 2024-10-02 15:35:18 --> Config Class Initialized
INFO - 2024-10-02 15:35:18 --> Loader Class Initialized
INFO - 2024-10-02 15:35:18 --> Helper loaded: url_helper
INFO - 2024-10-02 15:35:18 --> Helper loaded: file_helper
INFO - 2024-10-02 15:35:18 --> Helper loaded: form_helper
INFO - 2024-10-02 15:35:18 --> Helper loaded: my_helper
INFO - 2024-10-02 15:35:18 --> Database Driver Class Initialized
INFO - 2024-10-02 15:35:18 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-02 15:35:18 --> Controller Class Initialized
DEBUG - 2024-10-02 15:35:18 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_la/views/list.php
DEBUG - 2024-10-02 15:35:18 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-10-02 15:35:18 --> Final output sent to browser
DEBUG - 2024-10-02 15:35:18 --> Total execution time: 0.1274
INFO - 2024-10-02 15:35:18 --> Config Class Initialized
INFO - 2024-10-02 15:35:18 --> Hooks Class Initialized
DEBUG - 2024-10-02 15:35:18 --> UTF-8 Support Enabled
INFO - 2024-10-02 15:35:18 --> Utf8 Class Initialized
INFO - 2024-10-02 15:35:18 --> URI Class Initialized
INFO - 2024-10-02 15:35:18 --> Router Class Initialized
INFO - 2024-10-02 15:35:18 --> Output Class Initialized
INFO - 2024-10-02 15:35:18 --> Security Class Initialized
DEBUG - 2024-10-02 15:35:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-02 15:35:18 --> Input Class Initialized
INFO - 2024-10-02 15:35:18 --> Language Class Initialized
INFO - 2024-10-02 15:35:18 --> Language Class Initialized
INFO - 2024-10-02 15:35:18 --> Config Class Initialized
INFO - 2024-10-02 15:35:18 --> Loader Class Initialized
INFO - 2024-10-02 15:35:18 --> Helper loaded: url_helper
INFO - 2024-10-02 15:35:18 --> Helper loaded: file_helper
INFO - 2024-10-02 15:35:18 --> Helper loaded: form_helper
INFO - 2024-10-02 15:35:18 --> Helper loaded: my_helper
INFO - 2024-10-02 15:35:18 --> Database Driver Class Initialized
INFO - 2024-10-02 15:35:18 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-02 15:35:18 --> Controller Class Initialized
INFO - 2024-10-02 15:35:20 --> Config Class Initialized
INFO - 2024-10-02 15:35:20 --> Hooks Class Initialized
DEBUG - 2024-10-02 15:35:20 --> UTF-8 Support Enabled
INFO - 2024-10-02 15:35:20 --> Utf8 Class Initialized
INFO - 2024-10-02 15:35:20 --> URI Class Initialized
INFO - 2024-10-02 15:35:20 --> Router Class Initialized
INFO - 2024-10-02 15:35:20 --> Output Class Initialized
INFO - 2024-10-02 15:35:20 --> Security Class Initialized
DEBUG - 2024-10-02 15:35:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-02 15:35:20 --> Input Class Initialized
INFO - 2024-10-02 15:35:20 --> Language Class Initialized
INFO - 2024-10-02 15:35:20 --> Language Class Initialized
INFO - 2024-10-02 15:35:20 --> Config Class Initialized
INFO - 2024-10-02 15:35:20 --> Loader Class Initialized
INFO - 2024-10-02 15:35:20 --> Helper loaded: url_helper
INFO - 2024-10-02 15:35:20 --> Helper loaded: file_helper
INFO - 2024-10-02 15:35:20 --> Helper loaded: form_helper
INFO - 2024-10-02 15:35:20 --> Helper loaded: my_helper
INFO - 2024-10-02 15:35:20 --> Database Driver Class Initialized
INFO - 2024-10-02 15:35:20 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-02 15:35:20 --> Controller Class Initialized
INFO - 2024-10-02 15:35:20 --> Final output sent to browser
DEBUG - 2024-10-02 15:35:20 --> Total execution time: 0.0434
INFO - 2024-10-02 15:35:23 --> Config Class Initialized
INFO - 2024-10-02 15:35:23 --> Hooks Class Initialized
DEBUG - 2024-10-02 15:35:23 --> UTF-8 Support Enabled
INFO - 2024-10-02 15:35:23 --> Utf8 Class Initialized
INFO - 2024-10-02 15:35:23 --> URI Class Initialized
INFO - 2024-10-02 15:35:23 --> Router Class Initialized
INFO - 2024-10-02 15:35:23 --> Output Class Initialized
INFO - 2024-10-02 15:35:23 --> Security Class Initialized
DEBUG - 2024-10-02 15:35:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-02 15:35:23 --> Input Class Initialized
INFO - 2024-10-02 15:35:23 --> Language Class Initialized
INFO - 2024-10-02 15:35:23 --> Language Class Initialized
INFO - 2024-10-02 15:35:23 --> Config Class Initialized
INFO - 2024-10-02 15:35:23 --> Loader Class Initialized
INFO - 2024-10-02 15:35:23 --> Helper loaded: url_helper
INFO - 2024-10-02 15:35:23 --> Helper loaded: file_helper
INFO - 2024-10-02 15:35:23 --> Helper loaded: form_helper
INFO - 2024-10-02 15:35:23 --> Helper loaded: my_helper
INFO - 2024-10-02 15:35:23 --> Database Driver Class Initialized
INFO - 2024-10-02 15:35:23 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-02 15:35:23 --> Controller Class Initialized
DEBUG - 2024-10-02 15:35:23 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/view_mapel/views/v_view_mapel.php
DEBUG - 2024-10-02 15:35:23 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-10-02 15:35:23 --> Final output sent to browser
DEBUG - 2024-10-02 15:35:23 --> Total execution time: 0.0408
INFO - 2024-10-02 15:35:37 --> Config Class Initialized
INFO - 2024-10-02 15:35:37 --> Hooks Class Initialized
DEBUG - 2024-10-02 15:35:37 --> UTF-8 Support Enabled
INFO - 2024-10-02 15:35:37 --> Utf8 Class Initialized
INFO - 2024-10-02 15:35:37 --> URI Class Initialized
INFO - 2024-10-02 15:35:37 --> Router Class Initialized
INFO - 2024-10-02 15:35:37 --> Output Class Initialized
INFO - 2024-10-02 15:35:37 --> Security Class Initialized
DEBUG - 2024-10-02 15:35:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-02 15:35:37 --> Input Class Initialized
INFO - 2024-10-02 15:35:37 --> Language Class Initialized
INFO - 2024-10-02 15:35:37 --> Language Class Initialized
INFO - 2024-10-02 15:35:37 --> Config Class Initialized
INFO - 2024-10-02 15:35:37 --> Loader Class Initialized
INFO - 2024-10-02 15:35:37 --> Helper loaded: url_helper
INFO - 2024-10-02 15:35:37 --> Helper loaded: file_helper
INFO - 2024-10-02 15:35:37 --> Helper loaded: form_helper
INFO - 2024-10-02 15:35:37 --> Helper loaded: my_helper
INFO - 2024-10-02 15:35:37 --> Database Driver Class Initialized
INFO - 2024-10-02 15:35:37 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-02 15:35:37 --> Controller Class Initialized
DEBUG - 2024-10-02 15:35:37 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/view_mapel/views/v_view_mapel.php
DEBUG - 2024-10-02 15:35:37 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-10-02 15:35:37 --> Final output sent to browser
DEBUG - 2024-10-02 15:35:37 --> Total execution time: 0.0372
INFO - 2024-10-02 15:52:08 --> Config Class Initialized
INFO - 2024-10-02 15:52:08 --> Hooks Class Initialized
DEBUG - 2024-10-02 15:52:08 --> UTF-8 Support Enabled
INFO - 2024-10-02 15:52:08 --> Utf8 Class Initialized
INFO - 2024-10-02 15:52:08 --> URI Class Initialized
INFO - 2024-10-02 15:52:08 --> Router Class Initialized
INFO - 2024-10-02 15:52:08 --> Output Class Initialized
INFO - 2024-10-02 15:52:08 --> Security Class Initialized
DEBUG - 2024-10-02 15:52:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-02 15:52:08 --> Input Class Initialized
INFO - 2024-10-02 15:52:08 --> Language Class Initialized
INFO - 2024-10-02 15:52:08 --> Language Class Initialized
INFO - 2024-10-02 15:52:08 --> Config Class Initialized
INFO - 2024-10-02 15:52:08 --> Loader Class Initialized
INFO - 2024-10-02 15:52:08 --> Helper loaded: url_helper
INFO - 2024-10-02 15:52:08 --> Helper loaded: file_helper
INFO - 2024-10-02 15:52:08 --> Helper loaded: form_helper
INFO - 2024-10-02 15:52:08 --> Helper loaded: my_helper
INFO - 2024-10-02 15:52:08 --> Database Driver Class Initialized
INFO - 2024-10-02 15:52:08 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-02 15:52:08 --> Controller Class Initialized
DEBUG - 2024-10-02 15:52:08 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/home/views/v_home_guru.php
DEBUG - 2024-10-02 15:52:08 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-10-02 15:52:08 --> Final output sent to browser
DEBUG - 2024-10-02 15:52:08 --> Total execution time: 0.0313
INFO - 2024-10-02 15:52:16 --> Config Class Initialized
INFO - 2024-10-02 15:52:16 --> Hooks Class Initialized
DEBUG - 2024-10-02 15:52:16 --> UTF-8 Support Enabled
INFO - 2024-10-02 15:52:16 --> Utf8 Class Initialized
INFO - 2024-10-02 15:52:16 --> URI Class Initialized
INFO - 2024-10-02 15:52:16 --> Router Class Initialized
INFO - 2024-10-02 15:52:16 --> Output Class Initialized
INFO - 2024-10-02 15:52:16 --> Security Class Initialized
DEBUG - 2024-10-02 15:52:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-02 15:52:16 --> Input Class Initialized
INFO - 2024-10-02 15:52:16 --> Language Class Initialized
INFO - 2024-10-02 15:52:16 --> Language Class Initialized
INFO - 2024-10-02 15:52:16 --> Config Class Initialized
INFO - 2024-10-02 15:52:16 --> Loader Class Initialized
INFO - 2024-10-02 15:52:16 --> Helper loaded: url_helper
INFO - 2024-10-02 15:52:16 --> Helper loaded: file_helper
INFO - 2024-10-02 15:52:16 --> Helper loaded: form_helper
INFO - 2024-10-02 15:52:16 --> Helper loaded: my_helper
INFO - 2024-10-02 15:52:16 --> Database Driver Class Initialized
INFO - 2024-10-02 15:52:16 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-02 15:52:16 --> Controller Class Initialized
DEBUG - 2024-10-02 15:52:16 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/view_mapel/views/v_view_mapel.php
DEBUG - 2024-10-02 15:52:16 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-10-02 15:52:16 --> Final output sent to browser
DEBUG - 2024-10-02 15:52:16 --> Total execution time: 0.0291
INFO - 2024-10-02 15:52:23 --> Config Class Initialized
INFO - 2024-10-02 15:52:23 --> Hooks Class Initialized
DEBUG - 2024-10-02 15:52:23 --> UTF-8 Support Enabled
INFO - 2024-10-02 15:52:23 --> Utf8 Class Initialized
INFO - 2024-10-02 15:52:23 --> URI Class Initialized
INFO - 2024-10-02 15:52:23 --> Router Class Initialized
INFO - 2024-10-02 15:52:23 --> Output Class Initialized
INFO - 2024-10-02 15:52:23 --> Security Class Initialized
DEBUG - 2024-10-02 15:52:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-02 15:52:23 --> Input Class Initialized
INFO - 2024-10-02 15:52:23 --> Language Class Initialized
INFO - 2024-10-02 15:52:23 --> Language Class Initialized
INFO - 2024-10-02 15:52:23 --> Config Class Initialized
INFO - 2024-10-02 15:52:23 --> Loader Class Initialized
INFO - 2024-10-02 15:52:23 --> Helper loaded: url_helper
INFO - 2024-10-02 15:52:23 --> Helper loaded: file_helper
INFO - 2024-10-02 15:52:23 --> Helper loaded: form_helper
INFO - 2024-10-02 15:52:23 --> Helper loaded: my_helper
INFO - 2024-10-02 15:52:23 --> Database Driver Class Initialized
INFO - 2024-10-02 15:52:23 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-02 15:52:23 --> Controller Class Initialized
DEBUG - 2024-10-02 15:52:23 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pss/views/list.php
DEBUG - 2024-10-02 15:52:23 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-10-02 15:52:23 --> Final output sent to browser
DEBUG - 2024-10-02 15:52:23 --> Total execution time: 0.0400
INFO - 2024-10-02 15:52:23 --> Config Class Initialized
INFO - 2024-10-02 15:52:23 --> Hooks Class Initialized
DEBUG - 2024-10-02 15:52:23 --> UTF-8 Support Enabled
INFO - 2024-10-02 15:52:23 --> Utf8 Class Initialized
INFO - 2024-10-02 15:52:23 --> URI Class Initialized
INFO - 2024-10-02 15:52:23 --> Router Class Initialized
INFO - 2024-10-02 15:52:23 --> Output Class Initialized
INFO - 2024-10-02 15:52:23 --> Security Class Initialized
DEBUG - 2024-10-02 15:52:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-02 15:52:23 --> Input Class Initialized
INFO - 2024-10-02 15:52:23 --> Language Class Initialized
INFO - 2024-10-02 15:52:23 --> Language Class Initialized
INFO - 2024-10-02 15:52:23 --> Config Class Initialized
INFO - 2024-10-02 15:52:23 --> Loader Class Initialized
INFO - 2024-10-02 15:52:23 --> Helper loaded: url_helper
INFO - 2024-10-02 15:52:23 --> Helper loaded: file_helper
INFO - 2024-10-02 15:52:23 --> Helper loaded: form_helper
INFO - 2024-10-02 15:52:23 --> Helper loaded: my_helper
INFO - 2024-10-02 15:52:23 --> Database Driver Class Initialized
INFO - 2024-10-02 15:52:23 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-02 15:52:23 --> Controller Class Initialized
INFO - 2024-10-02 15:52:25 --> Config Class Initialized
INFO - 2024-10-02 15:52:25 --> Hooks Class Initialized
DEBUG - 2024-10-02 15:52:25 --> UTF-8 Support Enabled
INFO - 2024-10-02 15:52:25 --> Utf8 Class Initialized
INFO - 2024-10-02 15:52:25 --> URI Class Initialized
INFO - 2024-10-02 15:52:25 --> Router Class Initialized
INFO - 2024-10-02 15:52:25 --> Output Class Initialized
INFO - 2024-10-02 15:52:25 --> Security Class Initialized
DEBUG - 2024-10-02 15:52:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-02 15:52:25 --> Input Class Initialized
INFO - 2024-10-02 15:52:25 --> Language Class Initialized
INFO - 2024-10-02 15:52:25 --> Language Class Initialized
INFO - 2024-10-02 15:52:25 --> Config Class Initialized
INFO - 2024-10-02 15:52:25 --> Loader Class Initialized
INFO - 2024-10-02 15:52:25 --> Helper loaded: url_helper
INFO - 2024-10-02 15:52:25 --> Helper loaded: file_helper
INFO - 2024-10-02 15:52:25 --> Helper loaded: form_helper
INFO - 2024-10-02 15:52:25 --> Helper loaded: my_helper
INFO - 2024-10-02 15:52:25 --> Database Driver Class Initialized
INFO - 2024-10-02 15:52:25 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-02 15:52:25 --> Controller Class Initialized
DEBUG - 2024-10-02 15:52:25 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/view_mapel/views/v_view_mapel.php
DEBUG - 2024-10-02 15:52:25 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-10-02 15:52:25 --> Final output sent to browser
DEBUG - 2024-10-02 15:52:25 --> Total execution time: 0.0286
INFO - 2024-10-02 15:52:26 --> Config Class Initialized
INFO - 2024-10-02 15:52:26 --> Hooks Class Initialized
DEBUG - 2024-10-02 15:52:26 --> UTF-8 Support Enabled
INFO - 2024-10-02 15:52:26 --> Utf8 Class Initialized
INFO - 2024-10-02 15:52:26 --> URI Class Initialized
INFO - 2024-10-02 15:52:26 --> Router Class Initialized
INFO - 2024-10-02 15:52:26 --> Output Class Initialized
INFO - 2024-10-02 15:52:26 --> Security Class Initialized
DEBUG - 2024-10-02 15:52:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-02 15:52:26 --> Input Class Initialized
INFO - 2024-10-02 15:52:26 --> Language Class Initialized
INFO - 2024-10-02 15:52:26 --> Language Class Initialized
INFO - 2024-10-02 15:52:26 --> Config Class Initialized
INFO - 2024-10-02 15:52:26 --> Loader Class Initialized
INFO - 2024-10-02 15:52:26 --> Helper loaded: url_helper
INFO - 2024-10-02 15:52:26 --> Helper loaded: file_helper
INFO - 2024-10-02 15:52:26 --> Helper loaded: form_helper
INFO - 2024-10-02 15:52:26 --> Helper loaded: my_helper
INFO - 2024-10-02 15:52:26 --> Database Driver Class Initialized
INFO - 2024-10-02 15:52:26 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-02 15:52:26 --> Controller Class Initialized
DEBUG - 2024-10-02 15:52:26 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_icb/views/list.php
DEBUG - 2024-10-02 15:52:26 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-10-02 15:52:26 --> Final output sent to browser
DEBUG - 2024-10-02 15:52:26 --> Total execution time: 0.0309
INFO - 2024-10-02 15:52:26 --> Config Class Initialized
INFO - 2024-10-02 15:52:26 --> Hooks Class Initialized
DEBUG - 2024-10-02 15:52:26 --> UTF-8 Support Enabled
INFO - 2024-10-02 15:52:26 --> Utf8 Class Initialized
INFO - 2024-10-02 15:52:26 --> URI Class Initialized
INFO - 2024-10-02 15:52:26 --> Router Class Initialized
INFO - 2024-10-02 15:52:26 --> Output Class Initialized
INFO - 2024-10-02 15:52:26 --> Security Class Initialized
DEBUG - 2024-10-02 15:52:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-02 15:52:26 --> Input Class Initialized
INFO - 2024-10-02 15:52:26 --> Language Class Initialized
INFO - 2024-10-02 15:52:26 --> Language Class Initialized
INFO - 2024-10-02 15:52:26 --> Config Class Initialized
INFO - 2024-10-02 15:52:26 --> Loader Class Initialized
INFO - 2024-10-02 15:52:26 --> Helper loaded: url_helper
INFO - 2024-10-02 15:52:26 --> Helper loaded: file_helper
INFO - 2024-10-02 15:52:26 --> Helper loaded: form_helper
INFO - 2024-10-02 15:52:26 --> Helper loaded: my_helper
INFO - 2024-10-02 15:52:26 --> Database Driver Class Initialized
INFO - 2024-10-02 15:52:26 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-02 15:52:26 --> Controller Class Initialized
INFO - 2024-10-02 15:53:16 --> Config Class Initialized
INFO - 2024-10-02 15:53:16 --> Hooks Class Initialized
DEBUG - 2024-10-02 15:53:16 --> UTF-8 Support Enabled
INFO - 2024-10-02 15:53:16 --> Utf8 Class Initialized
INFO - 2024-10-02 15:53:16 --> URI Class Initialized
INFO - 2024-10-02 15:53:16 --> Router Class Initialized
INFO - 2024-10-02 15:53:16 --> Output Class Initialized
INFO - 2024-10-02 15:53:16 --> Security Class Initialized
DEBUG - 2024-10-02 15:53:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-02 15:53:16 --> Input Class Initialized
INFO - 2024-10-02 15:53:16 --> Language Class Initialized
INFO - 2024-10-02 15:53:16 --> Language Class Initialized
INFO - 2024-10-02 15:53:16 --> Config Class Initialized
INFO - 2024-10-02 15:53:16 --> Loader Class Initialized
INFO - 2024-10-02 15:53:16 --> Helper loaded: url_helper
INFO - 2024-10-02 15:53:16 --> Helper loaded: file_helper
INFO - 2024-10-02 15:53:16 --> Helper loaded: form_helper
INFO - 2024-10-02 15:53:16 --> Helper loaded: my_helper
INFO - 2024-10-02 15:53:16 --> Database Driver Class Initialized
INFO - 2024-10-02 15:53:16 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-02 15:53:16 --> Controller Class Initialized
INFO - 2024-10-02 15:53:16 --> Final output sent to browser
DEBUG - 2024-10-02 15:53:16 --> Total execution time: 0.0354
INFO - 2024-10-02 15:53:17 --> Config Class Initialized
INFO - 2024-10-02 15:53:17 --> Hooks Class Initialized
DEBUG - 2024-10-02 15:53:17 --> UTF-8 Support Enabled
INFO - 2024-10-02 15:53:17 --> Utf8 Class Initialized
INFO - 2024-10-02 15:53:17 --> URI Class Initialized
INFO - 2024-10-02 15:53:17 --> Router Class Initialized
INFO - 2024-10-02 15:53:17 --> Output Class Initialized
INFO - 2024-10-02 15:53:17 --> Security Class Initialized
DEBUG - 2024-10-02 15:53:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-02 15:53:17 --> Input Class Initialized
INFO - 2024-10-02 15:53:17 --> Language Class Initialized
INFO - 2024-10-02 15:53:17 --> Language Class Initialized
INFO - 2024-10-02 15:53:17 --> Config Class Initialized
INFO - 2024-10-02 15:53:17 --> Loader Class Initialized
INFO - 2024-10-02 15:53:17 --> Helper loaded: url_helper
INFO - 2024-10-02 15:53:17 --> Helper loaded: file_helper
INFO - 2024-10-02 15:53:17 --> Helper loaded: form_helper
INFO - 2024-10-02 15:53:17 --> Helper loaded: my_helper
INFO - 2024-10-02 15:53:17 --> Database Driver Class Initialized
INFO - 2024-10-02 15:53:17 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-02 15:53:17 --> Controller Class Initialized
INFO - 2024-10-02 15:53:17 --> Final output sent to browser
DEBUG - 2024-10-02 15:53:17 --> Total execution time: 0.0313
INFO - 2024-10-02 15:53:20 --> Config Class Initialized
INFO - 2024-10-02 15:53:20 --> Hooks Class Initialized
DEBUG - 2024-10-02 15:53:20 --> UTF-8 Support Enabled
INFO - 2024-10-02 15:53:20 --> Utf8 Class Initialized
INFO - 2024-10-02 15:53:20 --> URI Class Initialized
INFO - 2024-10-02 15:53:20 --> Router Class Initialized
INFO - 2024-10-02 15:53:20 --> Output Class Initialized
INFO - 2024-10-02 15:53:20 --> Security Class Initialized
DEBUG - 2024-10-02 15:53:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-02 15:53:20 --> Input Class Initialized
INFO - 2024-10-02 15:53:20 --> Language Class Initialized
INFO - 2024-10-02 15:53:20 --> Language Class Initialized
INFO - 2024-10-02 15:53:20 --> Config Class Initialized
INFO - 2024-10-02 15:53:20 --> Loader Class Initialized
INFO - 2024-10-02 15:53:20 --> Helper loaded: url_helper
INFO - 2024-10-02 15:53:20 --> Helper loaded: file_helper
INFO - 2024-10-02 15:53:20 --> Helper loaded: form_helper
INFO - 2024-10-02 15:53:20 --> Helper loaded: my_helper
INFO - 2024-10-02 15:53:20 --> Database Driver Class Initialized
INFO - 2024-10-02 15:53:20 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-02 15:53:20 --> Controller Class Initialized
INFO - 2024-10-02 15:53:20 --> Final output sent to browser
DEBUG - 2024-10-02 15:53:20 --> Total execution time: 0.0636
INFO - 2024-10-02 15:53:22 --> Config Class Initialized
INFO - 2024-10-02 15:53:22 --> Hooks Class Initialized
DEBUG - 2024-10-02 15:53:22 --> UTF-8 Support Enabled
INFO - 2024-10-02 15:53:22 --> Utf8 Class Initialized
INFO - 2024-10-02 15:53:22 --> URI Class Initialized
INFO - 2024-10-02 15:53:22 --> Router Class Initialized
INFO - 2024-10-02 15:53:22 --> Output Class Initialized
INFO - 2024-10-02 15:53:22 --> Security Class Initialized
DEBUG - 2024-10-02 15:53:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-02 15:53:22 --> Input Class Initialized
INFO - 2024-10-02 15:53:22 --> Language Class Initialized
INFO - 2024-10-02 15:53:22 --> Language Class Initialized
INFO - 2024-10-02 15:53:22 --> Config Class Initialized
INFO - 2024-10-02 15:53:22 --> Loader Class Initialized
INFO - 2024-10-02 15:53:22 --> Helper loaded: url_helper
INFO - 2024-10-02 15:53:22 --> Helper loaded: file_helper
INFO - 2024-10-02 15:53:22 --> Helper loaded: form_helper
INFO - 2024-10-02 15:53:22 --> Helper loaded: my_helper
INFO - 2024-10-02 15:53:22 --> Database Driver Class Initialized
INFO - 2024-10-02 15:53:22 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-02 15:53:22 --> Controller Class Initialized
INFO - 2024-10-02 15:53:22 --> Final output sent to browser
DEBUG - 2024-10-02 15:53:22 --> Total execution time: 0.0671
INFO - 2024-10-02 15:53:24 --> Config Class Initialized
INFO - 2024-10-02 15:53:24 --> Hooks Class Initialized
DEBUG - 2024-10-02 15:53:24 --> UTF-8 Support Enabled
INFO - 2024-10-02 15:53:24 --> Utf8 Class Initialized
INFO - 2024-10-02 15:53:24 --> URI Class Initialized
INFO - 2024-10-02 15:53:24 --> Router Class Initialized
INFO - 2024-10-02 15:53:24 --> Output Class Initialized
INFO - 2024-10-02 15:53:24 --> Security Class Initialized
DEBUG - 2024-10-02 15:53:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-02 15:53:24 --> Input Class Initialized
INFO - 2024-10-02 15:53:24 --> Language Class Initialized
INFO - 2024-10-02 15:53:24 --> Language Class Initialized
INFO - 2024-10-02 15:53:24 --> Config Class Initialized
INFO - 2024-10-02 15:53:24 --> Loader Class Initialized
INFO - 2024-10-02 15:53:24 --> Helper loaded: url_helper
INFO - 2024-10-02 15:53:24 --> Helper loaded: file_helper
INFO - 2024-10-02 15:53:24 --> Helper loaded: form_helper
INFO - 2024-10-02 15:53:24 --> Helper loaded: my_helper
INFO - 2024-10-02 15:53:24 --> Database Driver Class Initialized
INFO - 2024-10-02 15:53:24 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-02 15:53:24 --> Controller Class Initialized
INFO - 2024-10-02 15:53:24 --> Final output sent to browser
DEBUG - 2024-10-02 15:53:24 --> Total execution time: 0.1009
INFO - 2024-10-02 15:53:25 --> Config Class Initialized
INFO - 2024-10-02 15:53:25 --> Hooks Class Initialized
DEBUG - 2024-10-02 15:53:25 --> UTF-8 Support Enabled
INFO - 2024-10-02 15:53:25 --> Utf8 Class Initialized
INFO - 2024-10-02 15:53:25 --> URI Class Initialized
INFO - 2024-10-02 15:53:25 --> Router Class Initialized
INFO - 2024-10-02 15:53:25 --> Output Class Initialized
INFO - 2024-10-02 15:53:25 --> Security Class Initialized
DEBUG - 2024-10-02 15:53:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-02 15:53:25 --> Input Class Initialized
INFO - 2024-10-02 15:53:25 --> Language Class Initialized
INFO - 2024-10-02 15:53:25 --> Language Class Initialized
INFO - 2024-10-02 15:53:25 --> Config Class Initialized
INFO - 2024-10-02 15:53:25 --> Loader Class Initialized
INFO - 2024-10-02 15:53:25 --> Helper loaded: url_helper
INFO - 2024-10-02 15:53:25 --> Helper loaded: file_helper
INFO - 2024-10-02 15:53:25 --> Helper loaded: form_helper
INFO - 2024-10-02 15:53:25 --> Helper loaded: my_helper
INFO - 2024-10-02 15:53:25 --> Database Driver Class Initialized
INFO - 2024-10-02 15:53:25 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-02 15:53:25 --> Controller Class Initialized
INFO - 2024-10-02 15:53:25 --> Final output sent to browser
DEBUG - 2024-10-02 15:53:25 --> Total execution time: 0.1191
INFO - 2024-10-02 15:53:27 --> Config Class Initialized
INFO - 2024-10-02 15:53:27 --> Hooks Class Initialized
DEBUG - 2024-10-02 15:53:27 --> UTF-8 Support Enabled
INFO - 2024-10-02 15:53:27 --> Utf8 Class Initialized
INFO - 2024-10-02 15:53:27 --> URI Class Initialized
INFO - 2024-10-02 15:53:27 --> Router Class Initialized
INFO - 2024-10-02 15:53:27 --> Output Class Initialized
INFO - 2024-10-02 15:53:27 --> Security Class Initialized
DEBUG - 2024-10-02 15:53:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-02 15:53:27 --> Input Class Initialized
INFO - 2024-10-02 15:53:27 --> Language Class Initialized
INFO - 2024-10-02 15:53:27 --> Language Class Initialized
INFO - 2024-10-02 15:53:27 --> Config Class Initialized
INFO - 2024-10-02 15:53:27 --> Loader Class Initialized
INFO - 2024-10-02 15:53:27 --> Helper loaded: url_helper
INFO - 2024-10-02 15:53:27 --> Helper loaded: file_helper
INFO - 2024-10-02 15:53:27 --> Helper loaded: form_helper
INFO - 2024-10-02 15:53:27 --> Helper loaded: my_helper
INFO - 2024-10-02 15:53:27 --> Database Driver Class Initialized
INFO - 2024-10-02 15:53:27 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-02 15:53:27 --> Controller Class Initialized
INFO - 2024-10-02 15:53:27 --> Final output sent to browser
DEBUG - 2024-10-02 15:53:27 --> Total execution time: 0.1368
INFO - 2024-10-02 15:53:28 --> Config Class Initialized
INFO - 2024-10-02 15:53:28 --> Hooks Class Initialized
DEBUG - 2024-10-02 15:53:28 --> UTF-8 Support Enabled
INFO - 2024-10-02 15:53:28 --> Utf8 Class Initialized
INFO - 2024-10-02 15:53:28 --> URI Class Initialized
INFO - 2024-10-02 15:53:28 --> Router Class Initialized
INFO - 2024-10-02 15:53:28 --> Output Class Initialized
INFO - 2024-10-02 15:53:28 --> Security Class Initialized
DEBUG - 2024-10-02 15:53:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-02 15:53:28 --> Input Class Initialized
INFO - 2024-10-02 15:53:28 --> Language Class Initialized
INFO - 2024-10-02 15:53:28 --> Language Class Initialized
INFO - 2024-10-02 15:53:28 --> Config Class Initialized
INFO - 2024-10-02 15:53:28 --> Loader Class Initialized
INFO - 2024-10-02 15:53:28 --> Helper loaded: url_helper
INFO - 2024-10-02 15:53:28 --> Helper loaded: file_helper
INFO - 2024-10-02 15:53:28 --> Helper loaded: form_helper
INFO - 2024-10-02 15:53:28 --> Helper loaded: my_helper
INFO - 2024-10-02 15:53:28 --> Database Driver Class Initialized
INFO - 2024-10-02 15:53:28 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-02 15:53:28 --> Controller Class Initialized
INFO - 2024-10-02 15:53:28 --> Final output sent to browser
DEBUG - 2024-10-02 15:53:28 --> Total execution time: 0.0627
INFO - 2024-10-02 15:53:33 --> Config Class Initialized
INFO - 2024-10-02 15:53:33 --> Hooks Class Initialized
DEBUG - 2024-10-02 15:53:33 --> UTF-8 Support Enabled
INFO - 2024-10-02 15:53:33 --> Utf8 Class Initialized
INFO - 2024-10-02 15:53:33 --> URI Class Initialized
INFO - 2024-10-02 15:53:33 --> Router Class Initialized
INFO - 2024-10-02 15:53:33 --> Output Class Initialized
INFO - 2024-10-02 15:53:33 --> Security Class Initialized
DEBUG - 2024-10-02 15:53:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-02 15:53:33 --> Input Class Initialized
INFO - 2024-10-02 15:53:33 --> Language Class Initialized
INFO - 2024-10-02 15:53:33 --> Language Class Initialized
INFO - 2024-10-02 15:53:33 --> Config Class Initialized
INFO - 2024-10-02 15:53:33 --> Loader Class Initialized
INFO - 2024-10-02 15:53:33 --> Helper loaded: url_helper
INFO - 2024-10-02 15:53:33 --> Helper loaded: file_helper
INFO - 2024-10-02 15:53:33 --> Helper loaded: form_helper
INFO - 2024-10-02 15:53:33 --> Helper loaded: my_helper
INFO - 2024-10-02 15:53:33 --> Database Driver Class Initialized
INFO - 2024-10-02 15:53:33 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-02 15:53:33 --> Controller Class Initialized
INFO - 2024-10-02 15:53:33 --> Final output sent to browser
DEBUG - 2024-10-02 15:53:33 --> Total execution time: 0.0380
INFO - 2024-10-02 15:54:41 --> Config Class Initialized
INFO - 2024-10-02 15:54:41 --> Hooks Class Initialized
DEBUG - 2024-10-02 15:54:41 --> UTF-8 Support Enabled
INFO - 2024-10-02 15:54:41 --> Utf8 Class Initialized
INFO - 2024-10-02 15:54:41 --> URI Class Initialized
INFO - 2024-10-02 15:54:41 --> Router Class Initialized
INFO - 2024-10-02 15:54:41 --> Output Class Initialized
INFO - 2024-10-02 15:54:41 --> Security Class Initialized
DEBUG - 2024-10-02 15:54:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-02 15:54:41 --> Input Class Initialized
INFO - 2024-10-02 15:54:41 --> Language Class Initialized
INFO - 2024-10-02 15:54:41 --> Language Class Initialized
INFO - 2024-10-02 15:54:41 --> Config Class Initialized
INFO - 2024-10-02 15:54:41 --> Loader Class Initialized
INFO - 2024-10-02 15:54:41 --> Helper loaded: url_helper
INFO - 2024-10-02 15:54:41 --> Helper loaded: file_helper
INFO - 2024-10-02 15:54:41 --> Helper loaded: form_helper
INFO - 2024-10-02 15:54:41 --> Helper loaded: my_helper
INFO - 2024-10-02 15:54:42 --> Database Driver Class Initialized
INFO - 2024-10-02 15:54:42 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-02 15:54:42 --> Controller Class Initialized
INFO - 2024-10-02 15:54:42 --> Final output sent to browser
DEBUG - 2024-10-02 15:54:42 --> Total execution time: 0.0797
INFO - 2024-10-02 16:03:30 --> Config Class Initialized
INFO - 2024-10-02 16:03:30 --> Hooks Class Initialized
DEBUG - 2024-10-02 16:03:30 --> UTF-8 Support Enabled
INFO - 2024-10-02 16:03:30 --> Utf8 Class Initialized
INFO - 2024-10-02 16:03:30 --> URI Class Initialized
INFO - 2024-10-02 16:03:30 --> Router Class Initialized
INFO - 2024-10-02 16:03:30 --> Output Class Initialized
INFO - 2024-10-02 16:03:30 --> Security Class Initialized
DEBUG - 2024-10-02 16:03:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-02 16:03:30 --> Input Class Initialized
INFO - 2024-10-02 16:03:30 --> Language Class Initialized
INFO - 2024-10-02 16:03:30 --> Language Class Initialized
INFO - 2024-10-02 16:03:30 --> Config Class Initialized
INFO - 2024-10-02 16:03:30 --> Loader Class Initialized
INFO - 2024-10-02 16:03:30 --> Helper loaded: url_helper
INFO - 2024-10-02 16:03:30 --> Helper loaded: file_helper
INFO - 2024-10-02 16:03:30 --> Helper loaded: form_helper
INFO - 2024-10-02 16:03:30 --> Helper loaded: my_helper
INFO - 2024-10-02 16:03:30 --> Database Driver Class Initialized
INFO - 2024-10-02 16:03:30 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-02 16:03:30 --> Controller Class Initialized
INFO - 2024-10-02 16:03:30 --> Final output sent to browser
DEBUG - 2024-10-02 16:03:30 --> Total execution time: 0.0781
INFO - 2024-10-02 16:22:35 --> Config Class Initialized
INFO - 2024-10-02 16:22:35 --> Hooks Class Initialized
DEBUG - 2024-10-02 16:22:35 --> UTF-8 Support Enabled
INFO - 2024-10-02 16:22:35 --> Utf8 Class Initialized
INFO - 2024-10-02 16:22:35 --> URI Class Initialized
INFO - 2024-10-02 16:22:35 --> Router Class Initialized
INFO - 2024-10-02 16:22:35 --> Output Class Initialized
INFO - 2024-10-02 16:22:35 --> Security Class Initialized
DEBUG - 2024-10-02 16:22:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-02 16:22:35 --> Input Class Initialized
INFO - 2024-10-02 16:22:35 --> Language Class Initialized
INFO - 2024-10-02 16:22:35 --> Language Class Initialized
INFO - 2024-10-02 16:22:35 --> Config Class Initialized
INFO - 2024-10-02 16:22:35 --> Loader Class Initialized
INFO - 2024-10-02 16:22:35 --> Helper loaded: url_helper
INFO - 2024-10-02 16:22:35 --> Helper loaded: file_helper
INFO - 2024-10-02 16:22:35 --> Helper loaded: form_helper
INFO - 2024-10-02 16:22:35 --> Helper loaded: my_helper
INFO - 2024-10-02 16:22:36 --> Database Driver Class Initialized
INFO - 2024-10-02 16:22:36 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-02 16:22:36 --> Controller Class Initialized
INFO - 2024-10-02 16:22:36 --> Final output sent to browser
DEBUG - 2024-10-02 16:22:36 --> Total execution time: 0.1557
INFO - 2024-10-02 16:22:36 --> Config Class Initialized
INFO - 2024-10-02 16:22:36 --> Hooks Class Initialized
DEBUG - 2024-10-02 16:22:36 --> UTF-8 Support Enabled
INFO - 2024-10-02 16:22:36 --> Utf8 Class Initialized
INFO - 2024-10-02 16:22:36 --> URI Class Initialized
INFO - 2024-10-02 16:22:36 --> Router Class Initialized
INFO - 2024-10-02 16:22:36 --> Output Class Initialized
INFO - 2024-10-02 16:22:36 --> Security Class Initialized
DEBUG - 2024-10-02 16:22:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-02 16:22:36 --> Input Class Initialized
INFO - 2024-10-02 16:22:36 --> Language Class Initialized
INFO - 2024-10-02 16:22:36 --> Language Class Initialized
INFO - 2024-10-02 16:22:36 --> Config Class Initialized
INFO - 2024-10-02 16:22:36 --> Loader Class Initialized
INFO - 2024-10-02 16:22:36 --> Helper loaded: url_helper
INFO - 2024-10-02 16:22:36 --> Helper loaded: file_helper
INFO - 2024-10-02 16:22:36 --> Helper loaded: form_helper
INFO - 2024-10-02 16:22:36 --> Helper loaded: my_helper
INFO - 2024-10-02 16:22:36 --> Database Driver Class Initialized
INFO - 2024-10-02 16:22:36 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-02 16:22:36 --> Controller Class Initialized
INFO - 2024-10-02 16:22:36 --> Final output sent to browser
DEBUG - 2024-10-02 16:22:36 --> Total execution time: 0.0307
INFO - 2024-10-02 16:22:42 --> Config Class Initialized
INFO - 2024-10-02 16:22:42 --> Hooks Class Initialized
DEBUG - 2024-10-02 16:22:42 --> UTF-8 Support Enabled
INFO - 2024-10-02 16:22:42 --> Utf8 Class Initialized
INFO - 2024-10-02 16:22:42 --> URI Class Initialized
INFO - 2024-10-02 16:22:42 --> Router Class Initialized
INFO - 2024-10-02 16:22:42 --> Output Class Initialized
INFO - 2024-10-02 16:22:42 --> Security Class Initialized
DEBUG - 2024-10-02 16:22:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-02 16:22:42 --> Input Class Initialized
INFO - 2024-10-02 16:22:42 --> Language Class Initialized
INFO - 2024-10-02 16:22:42 --> Language Class Initialized
INFO - 2024-10-02 16:22:42 --> Config Class Initialized
INFO - 2024-10-02 16:22:42 --> Loader Class Initialized
INFO - 2024-10-02 16:22:42 --> Helper loaded: url_helper
INFO - 2024-10-02 16:22:42 --> Helper loaded: file_helper
INFO - 2024-10-02 16:22:42 --> Helper loaded: form_helper
INFO - 2024-10-02 16:22:42 --> Helper loaded: my_helper
INFO - 2024-10-02 16:22:42 --> Database Driver Class Initialized
INFO - 2024-10-02 16:22:42 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-02 16:22:42 --> Controller Class Initialized
INFO - 2024-10-02 16:22:42 --> Final output sent to browser
DEBUG - 2024-10-02 16:22:42 --> Total execution time: 0.0695
INFO - 2024-10-02 16:24:14 --> Config Class Initialized
INFO - 2024-10-02 16:24:14 --> Hooks Class Initialized
DEBUG - 2024-10-02 16:24:14 --> UTF-8 Support Enabled
INFO - 2024-10-02 16:24:14 --> Utf8 Class Initialized
INFO - 2024-10-02 16:24:14 --> URI Class Initialized
INFO - 2024-10-02 16:24:14 --> Router Class Initialized
INFO - 2024-10-02 16:24:14 --> Output Class Initialized
INFO - 2024-10-02 16:24:14 --> Security Class Initialized
DEBUG - 2024-10-02 16:24:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-02 16:24:14 --> Input Class Initialized
INFO - 2024-10-02 16:24:14 --> Language Class Initialized
INFO - 2024-10-02 16:24:14 --> Language Class Initialized
INFO - 2024-10-02 16:24:14 --> Config Class Initialized
INFO - 2024-10-02 16:24:14 --> Loader Class Initialized
INFO - 2024-10-02 16:24:14 --> Helper loaded: url_helper
INFO - 2024-10-02 16:24:14 --> Helper loaded: file_helper
INFO - 2024-10-02 16:24:14 --> Helper loaded: form_helper
INFO - 2024-10-02 16:24:14 --> Helper loaded: my_helper
INFO - 2024-10-02 16:24:14 --> Database Driver Class Initialized
INFO - 2024-10-02 16:24:14 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-02 16:24:14 --> Controller Class Initialized
INFO - 2024-10-02 16:24:14 --> Final output sent to browser
DEBUG - 2024-10-02 16:24:14 --> Total execution time: 0.0348
INFO - 2024-10-02 16:24:15 --> Config Class Initialized
INFO - 2024-10-02 16:24:15 --> Hooks Class Initialized
DEBUG - 2024-10-02 16:24:15 --> UTF-8 Support Enabled
INFO - 2024-10-02 16:24:15 --> Utf8 Class Initialized
INFO - 2024-10-02 16:24:15 --> URI Class Initialized
INFO - 2024-10-02 16:24:15 --> Router Class Initialized
INFO - 2024-10-02 16:24:15 --> Output Class Initialized
INFO - 2024-10-02 16:24:15 --> Security Class Initialized
DEBUG - 2024-10-02 16:24:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-02 16:24:15 --> Input Class Initialized
INFO - 2024-10-02 16:24:15 --> Language Class Initialized
INFO - 2024-10-02 16:24:15 --> Language Class Initialized
INFO - 2024-10-02 16:24:15 --> Config Class Initialized
INFO - 2024-10-02 16:24:15 --> Loader Class Initialized
INFO - 2024-10-02 16:24:15 --> Helper loaded: url_helper
INFO - 2024-10-02 16:24:15 --> Helper loaded: file_helper
INFO - 2024-10-02 16:24:15 --> Helper loaded: form_helper
INFO - 2024-10-02 16:24:15 --> Helper loaded: my_helper
INFO - 2024-10-02 16:24:15 --> Database Driver Class Initialized
INFO - 2024-10-02 16:24:15 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-02 16:24:15 --> Controller Class Initialized
INFO - 2024-10-02 16:24:15 --> Final output sent to browser
DEBUG - 2024-10-02 16:24:15 --> Total execution time: 0.0343
INFO - 2024-10-02 16:28:41 --> Config Class Initialized
INFO - 2024-10-02 16:28:41 --> Hooks Class Initialized
DEBUG - 2024-10-02 16:28:41 --> UTF-8 Support Enabled
INFO - 2024-10-02 16:28:41 --> Utf8 Class Initialized
INFO - 2024-10-02 16:28:41 --> URI Class Initialized
INFO - 2024-10-02 16:28:41 --> Router Class Initialized
INFO - 2024-10-02 16:28:41 --> Output Class Initialized
INFO - 2024-10-02 16:28:41 --> Security Class Initialized
DEBUG - 2024-10-02 16:28:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-02 16:28:41 --> Input Class Initialized
INFO - 2024-10-02 16:28:41 --> Language Class Initialized
INFO - 2024-10-02 16:28:41 --> Language Class Initialized
INFO - 2024-10-02 16:28:41 --> Config Class Initialized
INFO - 2024-10-02 16:28:41 --> Loader Class Initialized
INFO - 2024-10-02 16:28:41 --> Helper loaded: url_helper
INFO - 2024-10-02 16:28:41 --> Helper loaded: file_helper
INFO - 2024-10-02 16:28:41 --> Helper loaded: form_helper
INFO - 2024-10-02 16:28:41 --> Helper loaded: my_helper
INFO - 2024-10-02 16:28:41 --> Database Driver Class Initialized
INFO - 2024-10-02 16:28:41 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-02 16:28:41 --> Controller Class Initialized
INFO - 2024-10-02 16:28:41 --> Final output sent to browser
DEBUG - 2024-10-02 16:28:41 --> Total execution time: 0.0327
INFO - 2024-10-02 16:34:29 --> Config Class Initialized
INFO - 2024-10-02 16:34:29 --> Hooks Class Initialized
DEBUG - 2024-10-02 16:34:29 --> UTF-8 Support Enabled
INFO - 2024-10-02 16:34:29 --> Utf8 Class Initialized
INFO - 2024-10-02 16:34:29 --> URI Class Initialized
INFO - 2024-10-02 16:34:29 --> Router Class Initialized
INFO - 2024-10-02 16:34:29 --> Output Class Initialized
INFO - 2024-10-02 16:34:29 --> Security Class Initialized
DEBUG - 2024-10-02 16:34:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-02 16:34:29 --> Input Class Initialized
INFO - 2024-10-02 16:34:29 --> Language Class Initialized
INFO - 2024-10-02 16:34:29 --> Language Class Initialized
INFO - 2024-10-02 16:34:29 --> Config Class Initialized
INFO - 2024-10-02 16:34:29 --> Loader Class Initialized
INFO - 2024-10-02 16:34:29 --> Helper loaded: url_helper
INFO - 2024-10-02 16:34:29 --> Helper loaded: file_helper
INFO - 2024-10-02 16:34:29 --> Helper loaded: form_helper
INFO - 2024-10-02 16:34:29 --> Helper loaded: my_helper
INFO - 2024-10-02 16:34:29 --> Database Driver Class Initialized
INFO - 2024-10-02 16:34:29 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-02 16:34:29 --> Controller Class Initialized
INFO - 2024-10-02 16:34:29 --> Final output sent to browser
DEBUG - 2024-10-02 16:34:29 --> Total execution time: 0.0427
INFO - 2024-10-02 16:35:01 --> Config Class Initialized
INFO - 2024-10-02 16:35:01 --> Hooks Class Initialized
DEBUG - 2024-10-02 16:35:01 --> UTF-8 Support Enabled
INFO - 2024-10-02 16:35:01 --> Utf8 Class Initialized
INFO - 2024-10-02 16:35:01 --> URI Class Initialized
INFO - 2024-10-02 16:35:01 --> Router Class Initialized
INFO - 2024-10-02 16:35:01 --> Output Class Initialized
INFO - 2024-10-02 16:35:01 --> Security Class Initialized
DEBUG - 2024-10-02 16:35:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-02 16:35:01 --> Input Class Initialized
INFO - 2024-10-02 16:35:01 --> Language Class Initialized
INFO - 2024-10-02 16:35:01 --> Language Class Initialized
INFO - 2024-10-02 16:35:01 --> Config Class Initialized
INFO - 2024-10-02 16:35:01 --> Loader Class Initialized
INFO - 2024-10-02 16:35:01 --> Helper loaded: url_helper
INFO - 2024-10-02 16:35:01 --> Helper loaded: file_helper
INFO - 2024-10-02 16:35:01 --> Helper loaded: form_helper
INFO - 2024-10-02 16:35:01 --> Helper loaded: my_helper
INFO - 2024-10-02 16:35:01 --> Database Driver Class Initialized
INFO - 2024-10-02 16:35:01 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-02 16:35:01 --> Controller Class Initialized
INFO - 2024-10-02 16:35:01 --> Final output sent to browser
DEBUG - 2024-10-02 16:35:01 --> Total execution time: 0.0658
INFO - 2024-10-02 16:35:03 --> Config Class Initialized
INFO - 2024-10-02 16:35:03 --> Hooks Class Initialized
DEBUG - 2024-10-02 16:35:03 --> UTF-8 Support Enabled
INFO - 2024-10-02 16:35:03 --> Utf8 Class Initialized
INFO - 2024-10-02 16:35:03 --> URI Class Initialized
INFO - 2024-10-02 16:35:03 --> Router Class Initialized
INFO - 2024-10-02 16:35:03 --> Output Class Initialized
INFO - 2024-10-02 16:35:03 --> Security Class Initialized
DEBUG - 2024-10-02 16:35:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-02 16:35:03 --> Input Class Initialized
INFO - 2024-10-02 16:35:03 --> Language Class Initialized
INFO - 2024-10-02 16:35:03 --> Language Class Initialized
INFO - 2024-10-02 16:35:03 --> Config Class Initialized
INFO - 2024-10-02 16:35:03 --> Loader Class Initialized
INFO - 2024-10-02 16:35:03 --> Helper loaded: url_helper
INFO - 2024-10-02 16:35:03 --> Helper loaded: file_helper
INFO - 2024-10-02 16:35:03 --> Helper loaded: form_helper
INFO - 2024-10-02 16:35:03 --> Helper loaded: my_helper
INFO - 2024-10-02 16:35:03 --> Database Driver Class Initialized
INFO - 2024-10-02 16:35:03 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-02 16:35:03 --> Controller Class Initialized
INFO - 2024-10-02 16:35:03 --> Final output sent to browser
DEBUG - 2024-10-02 16:35:03 --> Total execution time: 0.1103
INFO - 2024-10-02 16:35:19 --> Config Class Initialized
INFO - 2024-10-02 16:35:19 --> Hooks Class Initialized
DEBUG - 2024-10-02 16:35:19 --> UTF-8 Support Enabled
INFO - 2024-10-02 16:35:19 --> Utf8 Class Initialized
INFO - 2024-10-02 16:35:19 --> URI Class Initialized
INFO - 2024-10-02 16:35:19 --> Router Class Initialized
INFO - 2024-10-02 16:35:19 --> Output Class Initialized
INFO - 2024-10-02 16:35:19 --> Security Class Initialized
DEBUG - 2024-10-02 16:35:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-02 16:35:19 --> Input Class Initialized
INFO - 2024-10-02 16:35:19 --> Language Class Initialized
INFO - 2024-10-02 16:35:19 --> Language Class Initialized
INFO - 2024-10-02 16:35:19 --> Config Class Initialized
INFO - 2024-10-02 16:35:19 --> Loader Class Initialized
INFO - 2024-10-02 16:35:19 --> Helper loaded: url_helper
INFO - 2024-10-02 16:35:19 --> Helper loaded: file_helper
INFO - 2024-10-02 16:35:19 --> Helper loaded: form_helper
INFO - 2024-10-02 16:35:19 --> Helper loaded: my_helper
INFO - 2024-10-02 16:35:19 --> Database Driver Class Initialized
INFO - 2024-10-02 16:35:19 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-02 16:35:19 --> Controller Class Initialized
INFO - 2024-10-02 16:35:19 --> Final output sent to browser
DEBUG - 2024-10-02 16:35:19 --> Total execution time: 0.1940
INFO - 2024-10-02 16:35:21 --> Config Class Initialized
INFO - 2024-10-02 16:35:21 --> Hooks Class Initialized
DEBUG - 2024-10-02 16:35:21 --> UTF-8 Support Enabled
INFO - 2024-10-02 16:35:21 --> Utf8 Class Initialized
INFO - 2024-10-02 16:35:21 --> URI Class Initialized
INFO - 2024-10-02 16:35:21 --> Router Class Initialized
INFO - 2024-10-02 16:35:21 --> Output Class Initialized
INFO - 2024-10-02 16:35:21 --> Security Class Initialized
DEBUG - 2024-10-02 16:35:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-02 16:35:21 --> Input Class Initialized
INFO - 2024-10-02 16:35:21 --> Language Class Initialized
INFO - 2024-10-02 16:35:21 --> Language Class Initialized
INFO - 2024-10-02 16:35:21 --> Config Class Initialized
INFO - 2024-10-02 16:35:21 --> Loader Class Initialized
INFO - 2024-10-02 16:35:21 --> Helper loaded: url_helper
INFO - 2024-10-02 16:35:21 --> Helper loaded: file_helper
INFO - 2024-10-02 16:35:21 --> Helper loaded: form_helper
INFO - 2024-10-02 16:35:21 --> Helper loaded: my_helper
INFO - 2024-10-02 16:35:21 --> Database Driver Class Initialized
INFO - 2024-10-02 16:35:21 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-02 16:35:21 --> Controller Class Initialized
INFO - 2024-10-02 16:35:21 --> Final output sent to browser
DEBUG - 2024-10-02 16:35:21 --> Total execution time: 0.0637
INFO - 2024-10-02 16:37:42 --> Config Class Initialized
INFO - 2024-10-02 16:37:42 --> Hooks Class Initialized
DEBUG - 2024-10-02 16:37:42 --> UTF-8 Support Enabled
INFO - 2024-10-02 16:37:42 --> Utf8 Class Initialized
INFO - 2024-10-02 16:37:42 --> URI Class Initialized
INFO - 2024-10-02 16:37:42 --> Router Class Initialized
INFO - 2024-10-02 16:37:42 --> Output Class Initialized
INFO - 2024-10-02 16:37:42 --> Security Class Initialized
DEBUG - 2024-10-02 16:37:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-02 16:37:42 --> Input Class Initialized
INFO - 2024-10-02 16:37:42 --> Language Class Initialized
INFO - 2024-10-02 16:37:42 --> Language Class Initialized
INFO - 2024-10-02 16:37:42 --> Config Class Initialized
INFO - 2024-10-02 16:37:42 --> Loader Class Initialized
INFO - 2024-10-02 16:37:42 --> Helper loaded: url_helper
INFO - 2024-10-02 16:37:42 --> Helper loaded: file_helper
INFO - 2024-10-02 16:37:42 --> Helper loaded: form_helper
INFO - 2024-10-02 16:37:42 --> Helper loaded: my_helper
INFO - 2024-10-02 16:37:42 --> Database Driver Class Initialized
INFO - 2024-10-02 16:37:42 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-02 16:37:42 --> Controller Class Initialized
INFO - 2024-10-02 16:37:42 --> Final output sent to browser
DEBUG - 2024-10-02 16:37:42 --> Total execution time: 0.0596
INFO - 2024-10-02 16:37:45 --> Config Class Initialized
INFO - 2024-10-02 16:37:45 --> Hooks Class Initialized
DEBUG - 2024-10-02 16:37:45 --> UTF-8 Support Enabled
INFO - 2024-10-02 16:37:45 --> Utf8 Class Initialized
INFO - 2024-10-02 16:37:45 --> URI Class Initialized
INFO - 2024-10-02 16:37:45 --> Router Class Initialized
INFO - 2024-10-02 16:37:45 --> Output Class Initialized
INFO - 2024-10-02 16:37:45 --> Security Class Initialized
DEBUG - 2024-10-02 16:37:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-02 16:37:45 --> Input Class Initialized
INFO - 2024-10-02 16:37:45 --> Language Class Initialized
INFO - 2024-10-02 16:37:45 --> Language Class Initialized
INFO - 2024-10-02 16:37:45 --> Config Class Initialized
INFO - 2024-10-02 16:37:45 --> Loader Class Initialized
INFO - 2024-10-02 16:37:45 --> Helper loaded: url_helper
INFO - 2024-10-02 16:37:45 --> Helper loaded: file_helper
INFO - 2024-10-02 16:37:45 --> Helper loaded: form_helper
INFO - 2024-10-02 16:37:45 --> Helper loaded: my_helper
INFO - 2024-10-02 16:37:45 --> Database Driver Class Initialized
INFO - 2024-10-02 16:37:45 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-02 16:37:45 --> Controller Class Initialized
INFO - 2024-10-02 16:37:45 --> Final output sent to browser
DEBUG - 2024-10-02 16:37:45 --> Total execution time: 0.0773
INFO - 2024-10-02 16:38:00 --> Config Class Initialized
INFO - 2024-10-02 16:38:00 --> Hooks Class Initialized
DEBUG - 2024-10-02 16:38:00 --> UTF-8 Support Enabled
INFO - 2024-10-02 16:38:00 --> Utf8 Class Initialized
INFO - 2024-10-02 16:38:00 --> URI Class Initialized
INFO - 2024-10-02 16:38:00 --> Router Class Initialized
INFO - 2024-10-02 16:38:00 --> Output Class Initialized
INFO - 2024-10-02 16:38:00 --> Security Class Initialized
DEBUG - 2024-10-02 16:38:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-02 16:38:00 --> Input Class Initialized
INFO - 2024-10-02 16:38:00 --> Language Class Initialized
INFO - 2024-10-02 16:38:00 --> Language Class Initialized
INFO - 2024-10-02 16:38:00 --> Config Class Initialized
INFO - 2024-10-02 16:38:00 --> Loader Class Initialized
INFO - 2024-10-02 16:38:00 --> Helper loaded: url_helper
INFO - 2024-10-02 16:38:00 --> Helper loaded: file_helper
INFO - 2024-10-02 16:38:00 --> Helper loaded: form_helper
INFO - 2024-10-02 16:38:00 --> Helper loaded: my_helper
INFO - 2024-10-02 16:38:00 --> Database Driver Class Initialized
INFO - 2024-10-02 16:38:00 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-02 16:38:00 --> Controller Class Initialized
INFO - 2024-10-02 16:38:00 --> Final output sent to browser
DEBUG - 2024-10-02 16:38:00 --> Total execution time: 0.0530
INFO - 2024-10-02 16:38:04 --> Config Class Initialized
INFO - 2024-10-02 16:38:04 --> Hooks Class Initialized
DEBUG - 2024-10-02 16:38:04 --> UTF-8 Support Enabled
INFO - 2024-10-02 16:38:04 --> Utf8 Class Initialized
INFO - 2024-10-02 16:38:04 --> URI Class Initialized
INFO - 2024-10-02 16:38:04 --> Router Class Initialized
INFO - 2024-10-02 16:38:04 --> Output Class Initialized
INFO - 2024-10-02 16:38:04 --> Security Class Initialized
DEBUG - 2024-10-02 16:38:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-02 16:38:04 --> Input Class Initialized
INFO - 2024-10-02 16:38:04 --> Language Class Initialized
INFO - 2024-10-02 16:38:04 --> Language Class Initialized
INFO - 2024-10-02 16:38:04 --> Config Class Initialized
INFO - 2024-10-02 16:38:04 --> Loader Class Initialized
INFO - 2024-10-02 16:38:04 --> Helper loaded: url_helper
INFO - 2024-10-02 16:38:04 --> Helper loaded: file_helper
INFO - 2024-10-02 16:38:04 --> Helper loaded: form_helper
INFO - 2024-10-02 16:38:04 --> Helper loaded: my_helper
INFO - 2024-10-02 16:38:04 --> Database Driver Class Initialized
INFO - 2024-10-02 16:38:04 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-02 16:38:04 --> Controller Class Initialized
INFO - 2024-10-02 16:38:04 --> Final output sent to browser
DEBUG - 2024-10-02 16:38:04 --> Total execution time: 0.0753
INFO - 2024-10-02 16:38:41 --> Config Class Initialized
INFO - 2024-10-02 16:38:41 --> Hooks Class Initialized
DEBUG - 2024-10-02 16:38:41 --> UTF-8 Support Enabled
INFO - 2024-10-02 16:38:41 --> Utf8 Class Initialized
INFO - 2024-10-02 16:38:41 --> URI Class Initialized
INFO - 2024-10-02 16:38:41 --> Router Class Initialized
INFO - 2024-10-02 16:38:41 --> Output Class Initialized
INFO - 2024-10-02 16:38:41 --> Security Class Initialized
DEBUG - 2024-10-02 16:38:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-02 16:38:41 --> Input Class Initialized
INFO - 2024-10-02 16:38:41 --> Language Class Initialized
INFO - 2024-10-02 16:38:41 --> Language Class Initialized
INFO - 2024-10-02 16:38:41 --> Config Class Initialized
INFO - 2024-10-02 16:38:41 --> Loader Class Initialized
INFO - 2024-10-02 16:38:41 --> Helper loaded: url_helper
INFO - 2024-10-02 16:38:41 --> Helper loaded: file_helper
INFO - 2024-10-02 16:38:41 --> Helper loaded: form_helper
INFO - 2024-10-02 16:38:41 --> Helper loaded: my_helper
INFO - 2024-10-02 16:38:41 --> Database Driver Class Initialized
INFO - 2024-10-02 16:38:41 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-02 16:38:41 --> Controller Class Initialized
INFO - 2024-10-02 16:38:41 --> Final output sent to browser
DEBUG - 2024-10-02 16:38:41 --> Total execution time: 0.4013
INFO - 2024-10-02 16:38:43 --> Config Class Initialized
INFO - 2024-10-02 16:38:43 --> Hooks Class Initialized
DEBUG - 2024-10-02 16:38:43 --> UTF-8 Support Enabled
INFO - 2024-10-02 16:38:43 --> Utf8 Class Initialized
INFO - 2024-10-02 16:38:43 --> URI Class Initialized
INFO - 2024-10-02 16:38:43 --> Router Class Initialized
INFO - 2024-10-02 16:38:43 --> Output Class Initialized
INFO - 2024-10-02 16:38:43 --> Security Class Initialized
DEBUG - 2024-10-02 16:38:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-02 16:38:43 --> Input Class Initialized
INFO - 2024-10-02 16:38:43 --> Language Class Initialized
INFO - 2024-10-02 16:38:43 --> Language Class Initialized
INFO - 2024-10-02 16:38:43 --> Config Class Initialized
INFO - 2024-10-02 16:38:43 --> Loader Class Initialized
INFO - 2024-10-02 16:38:43 --> Helper loaded: url_helper
INFO - 2024-10-02 16:38:43 --> Helper loaded: file_helper
INFO - 2024-10-02 16:38:43 --> Helper loaded: form_helper
INFO - 2024-10-02 16:38:43 --> Helper loaded: my_helper
INFO - 2024-10-02 16:38:43 --> Database Driver Class Initialized
INFO - 2024-10-02 16:38:43 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-02 16:38:43 --> Controller Class Initialized
INFO - 2024-10-02 16:38:43 --> Final output sent to browser
DEBUG - 2024-10-02 16:38:43 --> Total execution time: 0.0340
INFO - 2024-10-02 16:38:45 --> Config Class Initialized
INFO - 2024-10-02 16:38:45 --> Hooks Class Initialized
DEBUG - 2024-10-02 16:38:45 --> UTF-8 Support Enabled
INFO - 2024-10-02 16:38:45 --> Utf8 Class Initialized
INFO - 2024-10-02 16:38:45 --> URI Class Initialized
INFO - 2024-10-02 16:38:45 --> Router Class Initialized
INFO - 2024-10-02 16:38:45 --> Output Class Initialized
INFO - 2024-10-02 16:38:45 --> Security Class Initialized
DEBUG - 2024-10-02 16:38:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-02 16:38:45 --> Input Class Initialized
INFO - 2024-10-02 16:38:45 --> Language Class Initialized
INFO - 2024-10-02 16:38:45 --> Language Class Initialized
INFO - 2024-10-02 16:38:45 --> Config Class Initialized
INFO - 2024-10-02 16:38:45 --> Loader Class Initialized
INFO - 2024-10-02 16:38:45 --> Helper loaded: url_helper
INFO - 2024-10-02 16:38:45 --> Helper loaded: file_helper
INFO - 2024-10-02 16:38:45 --> Helper loaded: form_helper
INFO - 2024-10-02 16:38:45 --> Helper loaded: my_helper
INFO - 2024-10-02 16:38:45 --> Database Driver Class Initialized
INFO - 2024-10-02 16:38:45 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-02 16:38:45 --> Controller Class Initialized
INFO - 2024-10-02 16:38:45 --> Final output sent to browser
DEBUG - 2024-10-02 16:38:45 --> Total execution time: 0.0333
INFO - 2024-10-02 16:39:06 --> Config Class Initialized
INFO - 2024-10-02 16:39:06 --> Hooks Class Initialized
DEBUG - 2024-10-02 16:39:06 --> UTF-8 Support Enabled
INFO - 2024-10-02 16:39:06 --> Utf8 Class Initialized
INFO - 2024-10-02 16:39:06 --> URI Class Initialized
INFO - 2024-10-02 16:39:06 --> Router Class Initialized
INFO - 2024-10-02 16:39:06 --> Output Class Initialized
INFO - 2024-10-02 16:39:06 --> Security Class Initialized
DEBUG - 2024-10-02 16:39:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-02 16:39:06 --> Input Class Initialized
INFO - 2024-10-02 16:39:06 --> Language Class Initialized
INFO - 2024-10-02 16:39:06 --> Language Class Initialized
INFO - 2024-10-02 16:39:06 --> Config Class Initialized
INFO - 2024-10-02 16:39:06 --> Loader Class Initialized
INFO - 2024-10-02 16:39:06 --> Helper loaded: url_helper
INFO - 2024-10-02 16:39:06 --> Helper loaded: file_helper
INFO - 2024-10-02 16:39:06 --> Helper loaded: form_helper
INFO - 2024-10-02 16:39:06 --> Helper loaded: my_helper
INFO - 2024-10-02 16:39:06 --> Database Driver Class Initialized
INFO - 2024-10-02 16:39:06 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-02 16:39:06 --> Controller Class Initialized
INFO - 2024-10-02 16:39:06 --> Final output sent to browser
DEBUG - 2024-10-02 16:39:06 --> Total execution time: 0.0359
INFO - 2024-10-02 16:40:12 --> Config Class Initialized
INFO - 2024-10-02 16:40:12 --> Hooks Class Initialized
DEBUG - 2024-10-02 16:40:12 --> UTF-8 Support Enabled
INFO - 2024-10-02 16:40:12 --> Utf8 Class Initialized
INFO - 2024-10-02 16:40:12 --> URI Class Initialized
INFO - 2024-10-02 16:40:12 --> Router Class Initialized
INFO - 2024-10-02 16:40:12 --> Output Class Initialized
INFO - 2024-10-02 16:40:12 --> Security Class Initialized
DEBUG - 2024-10-02 16:40:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-02 16:40:12 --> Input Class Initialized
INFO - 2024-10-02 16:40:12 --> Language Class Initialized
INFO - 2024-10-02 16:40:12 --> Language Class Initialized
INFO - 2024-10-02 16:40:12 --> Config Class Initialized
INFO - 2024-10-02 16:40:12 --> Loader Class Initialized
INFO - 2024-10-02 16:40:12 --> Helper loaded: url_helper
INFO - 2024-10-02 16:40:12 --> Helper loaded: file_helper
INFO - 2024-10-02 16:40:12 --> Helper loaded: form_helper
INFO - 2024-10-02 16:40:12 --> Helper loaded: my_helper
INFO - 2024-10-02 16:40:12 --> Database Driver Class Initialized
INFO - 2024-10-02 16:40:12 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-02 16:40:12 --> Controller Class Initialized
INFO - 2024-10-02 16:40:12 --> Final output sent to browser
DEBUG - 2024-10-02 16:40:12 --> Total execution time: 0.0526
INFO - 2024-10-02 16:40:15 --> Config Class Initialized
INFO - 2024-10-02 16:40:15 --> Hooks Class Initialized
DEBUG - 2024-10-02 16:40:15 --> UTF-8 Support Enabled
INFO - 2024-10-02 16:40:15 --> Utf8 Class Initialized
INFO - 2024-10-02 16:40:15 --> URI Class Initialized
INFO - 2024-10-02 16:40:15 --> Router Class Initialized
INFO - 2024-10-02 16:40:15 --> Output Class Initialized
INFO - 2024-10-02 16:40:15 --> Security Class Initialized
DEBUG - 2024-10-02 16:40:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-02 16:40:15 --> Input Class Initialized
INFO - 2024-10-02 16:40:15 --> Language Class Initialized
INFO - 2024-10-02 16:40:15 --> Language Class Initialized
INFO - 2024-10-02 16:40:15 --> Config Class Initialized
INFO - 2024-10-02 16:40:15 --> Loader Class Initialized
INFO - 2024-10-02 16:40:15 --> Helper loaded: url_helper
INFO - 2024-10-02 16:40:15 --> Helper loaded: file_helper
INFO - 2024-10-02 16:40:15 --> Helper loaded: form_helper
INFO - 2024-10-02 16:40:15 --> Helper loaded: my_helper
INFO - 2024-10-02 16:40:15 --> Database Driver Class Initialized
INFO - 2024-10-02 16:40:15 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-02 16:40:15 --> Controller Class Initialized
INFO - 2024-10-02 16:40:15 --> Final output sent to browser
DEBUG - 2024-10-02 16:40:15 --> Total execution time: 0.0747
INFO - 2024-10-02 16:40:16 --> Config Class Initialized
INFO - 2024-10-02 16:40:16 --> Hooks Class Initialized
DEBUG - 2024-10-02 16:40:16 --> UTF-8 Support Enabled
INFO - 2024-10-02 16:40:16 --> Utf8 Class Initialized
INFO - 2024-10-02 16:40:16 --> URI Class Initialized
INFO - 2024-10-02 16:40:16 --> Router Class Initialized
INFO - 2024-10-02 16:40:16 --> Output Class Initialized
INFO - 2024-10-02 16:40:16 --> Security Class Initialized
DEBUG - 2024-10-02 16:40:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-02 16:40:16 --> Input Class Initialized
INFO - 2024-10-02 16:40:16 --> Language Class Initialized
INFO - 2024-10-02 16:40:16 --> Language Class Initialized
INFO - 2024-10-02 16:40:16 --> Config Class Initialized
INFO - 2024-10-02 16:40:16 --> Loader Class Initialized
INFO - 2024-10-02 16:40:16 --> Helper loaded: url_helper
INFO - 2024-10-02 16:40:16 --> Helper loaded: file_helper
INFO - 2024-10-02 16:40:16 --> Helper loaded: form_helper
INFO - 2024-10-02 16:40:16 --> Helper loaded: my_helper
INFO - 2024-10-02 16:40:16 --> Database Driver Class Initialized
INFO - 2024-10-02 16:40:16 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-02 16:40:16 --> Controller Class Initialized
INFO - 2024-10-02 16:40:16 --> Final output sent to browser
DEBUG - 2024-10-02 16:40:16 --> Total execution time: 0.0687
INFO - 2024-10-02 16:40:18 --> Config Class Initialized
INFO - 2024-10-02 16:40:18 --> Hooks Class Initialized
DEBUG - 2024-10-02 16:40:18 --> UTF-8 Support Enabled
INFO - 2024-10-02 16:40:18 --> Utf8 Class Initialized
INFO - 2024-10-02 16:40:18 --> URI Class Initialized
INFO - 2024-10-02 16:40:18 --> Router Class Initialized
INFO - 2024-10-02 16:40:18 --> Output Class Initialized
INFO - 2024-10-02 16:40:18 --> Security Class Initialized
DEBUG - 2024-10-02 16:40:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-02 16:40:18 --> Input Class Initialized
INFO - 2024-10-02 16:40:18 --> Language Class Initialized
INFO - 2024-10-02 16:40:18 --> Language Class Initialized
INFO - 2024-10-02 16:40:18 --> Config Class Initialized
INFO - 2024-10-02 16:40:18 --> Loader Class Initialized
INFO - 2024-10-02 16:40:18 --> Helper loaded: url_helper
INFO - 2024-10-02 16:40:18 --> Helper loaded: file_helper
INFO - 2024-10-02 16:40:18 --> Helper loaded: form_helper
INFO - 2024-10-02 16:40:18 --> Helper loaded: my_helper
INFO - 2024-10-02 16:40:18 --> Database Driver Class Initialized
INFO - 2024-10-02 16:40:18 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-02 16:40:18 --> Controller Class Initialized
INFO - 2024-10-02 16:40:18 --> Final output sent to browser
DEBUG - 2024-10-02 16:40:18 --> Total execution time: 0.0413
INFO - 2024-10-02 16:40:18 --> Config Class Initialized
INFO - 2024-10-02 16:40:18 --> Hooks Class Initialized
DEBUG - 2024-10-02 16:40:18 --> UTF-8 Support Enabled
INFO - 2024-10-02 16:40:18 --> Utf8 Class Initialized
INFO - 2024-10-02 16:40:18 --> URI Class Initialized
INFO - 2024-10-02 16:40:18 --> Router Class Initialized
INFO - 2024-10-02 16:40:18 --> Output Class Initialized
INFO - 2024-10-02 16:40:18 --> Security Class Initialized
DEBUG - 2024-10-02 16:40:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-02 16:40:18 --> Input Class Initialized
INFO - 2024-10-02 16:40:18 --> Language Class Initialized
INFO - 2024-10-02 16:40:18 --> Language Class Initialized
INFO - 2024-10-02 16:40:18 --> Config Class Initialized
INFO - 2024-10-02 16:40:18 --> Loader Class Initialized
INFO - 2024-10-02 16:40:18 --> Helper loaded: url_helper
INFO - 2024-10-02 16:40:18 --> Helper loaded: file_helper
INFO - 2024-10-02 16:40:18 --> Helper loaded: form_helper
INFO - 2024-10-02 16:40:18 --> Helper loaded: my_helper
INFO - 2024-10-02 16:40:18 --> Database Driver Class Initialized
INFO - 2024-10-02 16:40:18 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-02 16:40:18 --> Controller Class Initialized
INFO - 2024-10-02 16:40:18 --> Final output sent to browser
DEBUG - 2024-10-02 16:40:18 --> Total execution time: 0.0721
INFO - 2024-10-02 16:41:21 --> Config Class Initialized
INFO - 2024-10-02 16:41:21 --> Hooks Class Initialized
DEBUG - 2024-10-02 16:41:21 --> UTF-8 Support Enabled
INFO - 2024-10-02 16:41:21 --> Utf8 Class Initialized
INFO - 2024-10-02 16:41:21 --> URI Class Initialized
INFO - 2024-10-02 16:41:21 --> Router Class Initialized
INFO - 2024-10-02 16:41:21 --> Output Class Initialized
INFO - 2024-10-02 16:41:21 --> Security Class Initialized
DEBUG - 2024-10-02 16:41:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-02 16:41:21 --> Input Class Initialized
INFO - 2024-10-02 16:41:21 --> Language Class Initialized
INFO - 2024-10-02 16:41:21 --> Language Class Initialized
INFO - 2024-10-02 16:41:21 --> Config Class Initialized
INFO - 2024-10-02 16:41:21 --> Loader Class Initialized
INFO - 2024-10-02 16:41:21 --> Helper loaded: url_helper
INFO - 2024-10-02 16:41:21 --> Helper loaded: file_helper
INFO - 2024-10-02 16:41:21 --> Helper loaded: form_helper
INFO - 2024-10-02 16:41:21 --> Helper loaded: my_helper
INFO - 2024-10-02 16:41:21 --> Database Driver Class Initialized
INFO - 2024-10-02 16:41:21 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-02 16:41:21 --> Controller Class Initialized
INFO - 2024-10-02 16:41:21 --> Final output sent to browser
DEBUG - 2024-10-02 16:41:21 --> Total execution time: 0.0751
INFO - 2024-10-02 16:41:22 --> Config Class Initialized
INFO - 2024-10-02 16:41:22 --> Hooks Class Initialized
DEBUG - 2024-10-02 16:41:22 --> UTF-8 Support Enabled
INFO - 2024-10-02 16:41:22 --> Utf8 Class Initialized
INFO - 2024-10-02 16:41:22 --> URI Class Initialized
INFO - 2024-10-02 16:41:22 --> Router Class Initialized
INFO - 2024-10-02 16:41:22 --> Output Class Initialized
INFO - 2024-10-02 16:41:22 --> Security Class Initialized
DEBUG - 2024-10-02 16:41:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-02 16:41:22 --> Input Class Initialized
INFO - 2024-10-02 16:41:22 --> Language Class Initialized
INFO - 2024-10-02 16:41:22 --> Language Class Initialized
INFO - 2024-10-02 16:41:22 --> Config Class Initialized
INFO - 2024-10-02 16:41:22 --> Loader Class Initialized
INFO - 2024-10-02 16:41:22 --> Helper loaded: url_helper
INFO - 2024-10-02 16:41:22 --> Helper loaded: file_helper
INFO - 2024-10-02 16:41:22 --> Helper loaded: form_helper
INFO - 2024-10-02 16:41:22 --> Helper loaded: my_helper
INFO - 2024-10-02 16:41:22 --> Database Driver Class Initialized
INFO - 2024-10-02 16:41:22 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-02 16:41:22 --> Controller Class Initialized
INFO - 2024-10-02 16:41:22 --> Final output sent to browser
DEBUG - 2024-10-02 16:41:22 --> Total execution time: 0.0313
INFO - 2024-10-02 16:42:09 --> Config Class Initialized
INFO - 2024-10-02 16:42:09 --> Hooks Class Initialized
DEBUG - 2024-10-02 16:42:09 --> UTF-8 Support Enabled
INFO - 2024-10-02 16:42:09 --> Utf8 Class Initialized
INFO - 2024-10-02 16:42:09 --> URI Class Initialized
INFO - 2024-10-02 16:42:09 --> Router Class Initialized
INFO - 2024-10-02 16:42:09 --> Output Class Initialized
INFO - 2024-10-02 16:42:09 --> Security Class Initialized
DEBUG - 2024-10-02 16:42:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-02 16:42:09 --> Input Class Initialized
INFO - 2024-10-02 16:42:09 --> Language Class Initialized
INFO - 2024-10-02 16:42:09 --> Language Class Initialized
INFO - 2024-10-02 16:42:09 --> Config Class Initialized
INFO - 2024-10-02 16:42:09 --> Loader Class Initialized
INFO - 2024-10-02 16:42:09 --> Helper loaded: url_helper
INFO - 2024-10-02 16:42:09 --> Helper loaded: file_helper
INFO - 2024-10-02 16:42:09 --> Helper loaded: form_helper
INFO - 2024-10-02 16:42:09 --> Helper loaded: my_helper
INFO - 2024-10-02 16:42:09 --> Database Driver Class Initialized
INFO - 2024-10-02 16:42:09 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-02 16:42:09 --> Controller Class Initialized
INFO - 2024-10-02 16:42:10 --> Final output sent to browser
DEBUG - 2024-10-02 16:42:10 --> Total execution time: 0.1904
INFO - 2024-10-02 16:42:12 --> Config Class Initialized
INFO - 2024-10-02 16:42:12 --> Hooks Class Initialized
DEBUG - 2024-10-02 16:42:12 --> UTF-8 Support Enabled
INFO - 2024-10-02 16:42:12 --> Utf8 Class Initialized
INFO - 2024-10-02 16:42:12 --> URI Class Initialized
INFO - 2024-10-02 16:42:12 --> Router Class Initialized
INFO - 2024-10-02 16:42:12 --> Output Class Initialized
INFO - 2024-10-02 16:42:12 --> Security Class Initialized
DEBUG - 2024-10-02 16:42:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-02 16:42:12 --> Input Class Initialized
INFO - 2024-10-02 16:42:12 --> Language Class Initialized
INFO - 2024-10-02 16:42:12 --> Language Class Initialized
INFO - 2024-10-02 16:42:12 --> Config Class Initialized
INFO - 2024-10-02 16:42:12 --> Loader Class Initialized
INFO - 2024-10-02 16:42:12 --> Helper loaded: url_helper
INFO - 2024-10-02 16:42:12 --> Helper loaded: file_helper
INFO - 2024-10-02 16:42:12 --> Helper loaded: form_helper
INFO - 2024-10-02 16:42:12 --> Helper loaded: my_helper
INFO - 2024-10-02 16:42:12 --> Database Driver Class Initialized
INFO - 2024-10-02 16:42:12 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-02 16:42:12 --> Controller Class Initialized
INFO - 2024-10-02 16:42:12 --> Final output sent to browser
DEBUG - 2024-10-02 16:42:12 --> Total execution time: 0.0412
INFO - 2024-10-02 16:42:16 --> Config Class Initialized
INFO - 2024-10-02 16:42:16 --> Hooks Class Initialized
DEBUG - 2024-10-02 16:42:16 --> UTF-8 Support Enabled
INFO - 2024-10-02 16:42:16 --> Utf8 Class Initialized
INFO - 2024-10-02 16:42:16 --> URI Class Initialized
INFO - 2024-10-02 16:42:16 --> Router Class Initialized
INFO - 2024-10-02 16:42:16 --> Output Class Initialized
INFO - 2024-10-02 16:42:16 --> Security Class Initialized
DEBUG - 2024-10-02 16:42:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-02 16:42:16 --> Input Class Initialized
INFO - 2024-10-02 16:42:16 --> Language Class Initialized
INFO - 2024-10-02 16:42:17 --> Language Class Initialized
INFO - 2024-10-02 16:42:17 --> Config Class Initialized
INFO - 2024-10-02 16:42:17 --> Loader Class Initialized
INFO - 2024-10-02 16:42:17 --> Helper loaded: url_helper
INFO - 2024-10-02 16:42:17 --> Helper loaded: file_helper
INFO - 2024-10-02 16:42:17 --> Helper loaded: form_helper
INFO - 2024-10-02 16:42:17 --> Helper loaded: my_helper
INFO - 2024-10-02 16:42:17 --> Database Driver Class Initialized
INFO - 2024-10-02 16:42:17 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-02 16:42:17 --> Controller Class Initialized
DEBUG - 2024-10-02 16:42:17 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/view_mapel/views/v_view_mapel.php
DEBUG - 2024-10-02 16:42:17 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-10-02 16:42:17 --> Final output sent to browser
DEBUG - 2024-10-02 16:42:17 --> Total execution time: 0.1119
INFO - 2024-10-02 16:42:19 --> Config Class Initialized
INFO - 2024-10-02 16:42:19 --> Hooks Class Initialized
DEBUG - 2024-10-02 16:42:19 --> UTF-8 Support Enabled
INFO - 2024-10-02 16:42:19 --> Utf8 Class Initialized
INFO - 2024-10-02 16:42:19 --> URI Class Initialized
INFO - 2024-10-02 16:42:19 --> Router Class Initialized
INFO - 2024-10-02 16:42:19 --> Output Class Initialized
INFO - 2024-10-02 16:42:19 --> Security Class Initialized
DEBUG - 2024-10-02 16:42:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-02 16:42:19 --> Input Class Initialized
INFO - 2024-10-02 16:42:19 --> Language Class Initialized
INFO - 2024-10-02 16:42:19 --> Language Class Initialized
INFO - 2024-10-02 16:42:19 --> Config Class Initialized
INFO - 2024-10-02 16:42:19 --> Loader Class Initialized
INFO - 2024-10-02 16:42:19 --> Helper loaded: url_helper
INFO - 2024-10-02 16:42:19 --> Helper loaded: file_helper
INFO - 2024-10-02 16:42:19 --> Helper loaded: form_helper
INFO - 2024-10-02 16:42:19 --> Helper loaded: my_helper
INFO - 2024-10-02 16:42:19 --> Database Driver Class Initialized
INFO - 2024-10-02 16:42:19 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-02 16:42:19 --> Controller Class Initialized
DEBUG - 2024-10-02 16:42:19 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pss/views/list.php
DEBUG - 2024-10-02 16:42:19 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-10-02 16:42:19 --> Final output sent to browser
DEBUG - 2024-10-02 16:42:19 --> Total execution time: 0.0334
INFO - 2024-10-02 16:42:19 --> Config Class Initialized
INFO - 2024-10-02 16:42:19 --> Hooks Class Initialized
DEBUG - 2024-10-02 16:42:19 --> UTF-8 Support Enabled
INFO - 2024-10-02 16:42:19 --> Utf8 Class Initialized
INFO - 2024-10-02 16:42:19 --> URI Class Initialized
INFO - 2024-10-02 16:42:19 --> Router Class Initialized
INFO - 2024-10-02 16:42:19 --> Output Class Initialized
INFO - 2024-10-02 16:42:19 --> Security Class Initialized
DEBUG - 2024-10-02 16:42:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-02 16:42:19 --> Input Class Initialized
INFO - 2024-10-02 16:42:19 --> Language Class Initialized
INFO - 2024-10-02 16:42:19 --> Language Class Initialized
INFO - 2024-10-02 16:42:19 --> Config Class Initialized
INFO - 2024-10-02 16:42:19 --> Loader Class Initialized
INFO - 2024-10-02 16:42:19 --> Helper loaded: url_helper
INFO - 2024-10-02 16:42:19 --> Helper loaded: file_helper
INFO - 2024-10-02 16:42:19 --> Helper loaded: form_helper
INFO - 2024-10-02 16:42:19 --> Helper loaded: my_helper
INFO - 2024-10-02 16:42:19 --> Database Driver Class Initialized
INFO - 2024-10-02 16:42:19 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-02 16:42:19 --> Controller Class Initialized
INFO - 2024-10-02 16:42:21 --> Config Class Initialized
INFO - 2024-10-02 16:42:21 --> Hooks Class Initialized
DEBUG - 2024-10-02 16:42:21 --> UTF-8 Support Enabled
INFO - 2024-10-02 16:42:21 --> Utf8 Class Initialized
INFO - 2024-10-02 16:42:21 --> URI Class Initialized
INFO - 2024-10-02 16:42:21 --> Router Class Initialized
INFO - 2024-10-02 16:42:21 --> Output Class Initialized
INFO - 2024-10-02 16:42:21 --> Security Class Initialized
DEBUG - 2024-10-02 16:42:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-02 16:42:21 --> Input Class Initialized
INFO - 2024-10-02 16:42:21 --> Language Class Initialized
INFO - 2024-10-02 16:42:21 --> Language Class Initialized
INFO - 2024-10-02 16:42:21 --> Config Class Initialized
INFO - 2024-10-02 16:42:21 --> Loader Class Initialized
INFO - 2024-10-02 16:42:21 --> Helper loaded: url_helper
INFO - 2024-10-02 16:42:21 --> Helper loaded: file_helper
INFO - 2024-10-02 16:42:21 --> Helper loaded: form_helper
INFO - 2024-10-02 16:42:21 --> Helper loaded: my_helper
INFO - 2024-10-02 16:42:21 --> Database Driver Class Initialized
INFO - 2024-10-02 16:42:21 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-02 16:42:21 --> Controller Class Initialized
INFO - 2024-10-02 16:42:21 --> Final output sent to browser
DEBUG - 2024-10-02 16:42:21 --> Total execution time: 0.0548
INFO - 2024-10-02 16:43:08 --> Config Class Initialized
INFO - 2024-10-02 16:43:08 --> Hooks Class Initialized
DEBUG - 2024-10-02 16:43:08 --> UTF-8 Support Enabled
INFO - 2024-10-02 16:43:08 --> Utf8 Class Initialized
INFO - 2024-10-02 16:43:08 --> URI Class Initialized
INFO - 2024-10-02 16:43:08 --> Router Class Initialized
INFO - 2024-10-02 16:43:08 --> Output Class Initialized
INFO - 2024-10-02 16:43:08 --> Security Class Initialized
DEBUG - 2024-10-02 16:43:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-02 16:43:08 --> Input Class Initialized
INFO - 2024-10-02 16:43:08 --> Language Class Initialized
INFO - 2024-10-02 16:43:08 --> Language Class Initialized
INFO - 2024-10-02 16:43:08 --> Config Class Initialized
INFO - 2024-10-02 16:43:08 --> Loader Class Initialized
INFO - 2024-10-02 16:43:08 --> Helper loaded: url_helper
INFO - 2024-10-02 16:43:08 --> Helper loaded: file_helper
INFO - 2024-10-02 16:43:08 --> Helper loaded: form_helper
INFO - 2024-10-02 16:43:08 --> Helper loaded: my_helper
INFO - 2024-10-02 16:43:08 --> Database Driver Class Initialized
INFO - 2024-10-02 16:43:08 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-02 16:43:08 --> Controller Class Initialized
INFO - 2024-10-02 16:43:08 --> Final output sent to browser
DEBUG - 2024-10-02 16:43:08 --> Total execution time: 0.5215
INFO - 2024-10-02 16:43:10 --> Config Class Initialized
INFO - 2024-10-02 16:43:10 --> Hooks Class Initialized
DEBUG - 2024-10-02 16:43:10 --> UTF-8 Support Enabled
INFO - 2024-10-02 16:43:10 --> Utf8 Class Initialized
INFO - 2024-10-02 16:43:10 --> URI Class Initialized
INFO - 2024-10-02 16:43:10 --> Router Class Initialized
INFO - 2024-10-02 16:43:10 --> Output Class Initialized
INFO - 2024-10-02 16:43:10 --> Security Class Initialized
DEBUG - 2024-10-02 16:43:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-02 16:43:10 --> Input Class Initialized
INFO - 2024-10-02 16:43:10 --> Language Class Initialized
INFO - 2024-10-02 16:43:10 --> Language Class Initialized
INFO - 2024-10-02 16:43:10 --> Config Class Initialized
INFO - 2024-10-02 16:43:10 --> Loader Class Initialized
INFO - 2024-10-02 16:43:10 --> Helper loaded: url_helper
INFO - 2024-10-02 16:43:10 --> Helper loaded: file_helper
INFO - 2024-10-02 16:43:10 --> Helper loaded: form_helper
INFO - 2024-10-02 16:43:10 --> Helper loaded: my_helper
INFO - 2024-10-02 16:43:10 --> Database Driver Class Initialized
INFO - 2024-10-02 16:43:10 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-02 16:43:10 --> Controller Class Initialized
INFO - 2024-10-02 16:43:10 --> Final output sent to browser
DEBUG - 2024-10-02 16:43:10 --> Total execution time: 0.0698
INFO - 2024-10-02 16:43:30 --> Config Class Initialized
INFO - 2024-10-02 16:43:30 --> Hooks Class Initialized
DEBUG - 2024-10-02 16:43:30 --> UTF-8 Support Enabled
INFO - 2024-10-02 16:43:30 --> Utf8 Class Initialized
INFO - 2024-10-02 16:43:30 --> URI Class Initialized
INFO - 2024-10-02 16:43:30 --> Router Class Initialized
INFO - 2024-10-02 16:43:30 --> Output Class Initialized
INFO - 2024-10-02 16:43:30 --> Security Class Initialized
DEBUG - 2024-10-02 16:43:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-02 16:43:30 --> Input Class Initialized
INFO - 2024-10-02 16:43:30 --> Language Class Initialized
INFO - 2024-10-02 16:43:30 --> Language Class Initialized
INFO - 2024-10-02 16:43:30 --> Config Class Initialized
INFO - 2024-10-02 16:43:30 --> Loader Class Initialized
INFO - 2024-10-02 16:43:30 --> Helper loaded: url_helper
INFO - 2024-10-02 16:43:30 --> Helper loaded: file_helper
INFO - 2024-10-02 16:43:30 --> Helper loaded: form_helper
INFO - 2024-10-02 16:43:30 --> Helper loaded: my_helper
INFO - 2024-10-02 16:43:30 --> Database Driver Class Initialized
INFO - 2024-10-02 16:43:30 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-02 16:43:30 --> Controller Class Initialized
INFO - 2024-10-02 16:43:30 --> Final output sent to browser
DEBUG - 2024-10-02 16:43:30 --> Total execution time: 0.3495
INFO - 2024-10-02 16:43:33 --> Config Class Initialized
INFO - 2024-10-02 16:43:33 --> Hooks Class Initialized
DEBUG - 2024-10-02 16:43:33 --> UTF-8 Support Enabled
INFO - 2024-10-02 16:43:33 --> Utf8 Class Initialized
INFO - 2024-10-02 16:43:33 --> URI Class Initialized
INFO - 2024-10-02 16:43:33 --> Router Class Initialized
INFO - 2024-10-02 16:43:33 --> Output Class Initialized
INFO - 2024-10-02 16:43:33 --> Security Class Initialized
DEBUG - 2024-10-02 16:43:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-02 16:43:33 --> Input Class Initialized
INFO - 2024-10-02 16:43:33 --> Language Class Initialized
INFO - 2024-10-02 16:43:33 --> Language Class Initialized
INFO - 2024-10-02 16:43:33 --> Config Class Initialized
INFO - 2024-10-02 16:43:33 --> Loader Class Initialized
INFO - 2024-10-02 16:43:33 --> Helper loaded: url_helper
INFO - 2024-10-02 16:43:33 --> Helper loaded: file_helper
INFO - 2024-10-02 16:43:33 --> Helper loaded: form_helper
INFO - 2024-10-02 16:43:33 --> Helper loaded: my_helper
INFO - 2024-10-02 16:43:33 --> Database Driver Class Initialized
INFO - 2024-10-02 16:43:33 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-02 16:43:33 --> Controller Class Initialized
INFO - 2024-10-02 16:43:33 --> Final output sent to browser
DEBUG - 2024-10-02 16:43:33 --> Total execution time: 0.0373
INFO - 2024-10-02 16:43:58 --> Config Class Initialized
INFO - 2024-10-02 16:43:58 --> Hooks Class Initialized
DEBUG - 2024-10-02 16:43:58 --> UTF-8 Support Enabled
INFO - 2024-10-02 16:43:58 --> Utf8 Class Initialized
INFO - 2024-10-02 16:43:58 --> URI Class Initialized
INFO - 2024-10-02 16:43:58 --> Router Class Initialized
INFO - 2024-10-02 16:43:58 --> Output Class Initialized
INFO - 2024-10-02 16:43:58 --> Security Class Initialized
DEBUG - 2024-10-02 16:43:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-02 16:43:58 --> Input Class Initialized
INFO - 2024-10-02 16:43:58 --> Language Class Initialized
INFO - 2024-10-02 16:43:58 --> Language Class Initialized
INFO - 2024-10-02 16:43:58 --> Config Class Initialized
INFO - 2024-10-02 16:43:58 --> Loader Class Initialized
INFO - 2024-10-02 16:43:58 --> Helper loaded: url_helper
INFO - 2024-10-02 16:43:58 --> Helper loaded: file_helper
INFO - 2024-10-02 16:43:58 --> Helper loaded: form_helper
INFO - 2024-10-02 16:43:58 --> Helper loaded: my_helper
INFO - 2024-10-02 16:43:58 --> Database Driver Class Initialized
INFO - 2024-10-02 16:43:58 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-02 16:43:58 --> Controller Class Initialized
INFO - 2024-10-02 16:43:58 --> Final output sent to browser
DEBUG - 2024-10-02 16:43:58 --> Total execution time: 0.0551
INFO - 2024-10-02 16:44:00 --> Config Class Initialized
INFO - 2024-10-02 16:44:00 --> Hooks Class Initialized
DEBUG - 2024-10-02 16:44:00 --> UTF-8 Support Enabled
INFO - 2024-10-02 16:44:00 --> Utf8 Class Initialized
INFO - 2024-10-02 16:44:00 --> URI Class Initialized
INFO - 2024-10-02 16:44:00 --> Router Class Initialized
INFO - 2024-10-02 16:44:00 --> Output Class Initialized
INFO - 2024-10-02 16:44:00 --> Security Class Initialized
DEBUG - 2024-10-02 16:44:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-02 16:44:00 --> Input Class Initialized
INFO - 2024-10-02 16:44:00 --> Language Class Initialized
INFO - 2024-10-02 16:44:00 --> Language Class Initialized
INFO - 2024-10-02 16:44:00 --> Config Class Initialized
INFO - 2024-10-02 16:44:00 --> Loader Class Initialized
INFO - 2024-10-02 16:44:00 --> Helper loaded: url_helper
INFO - 2024-10-02 16:44:00 --> Helper loaded: file_helper
INFO - 2024-10-02 16:44:00 --> Helper loaded: form_helper
INFO - 2024-10-02 16:44:00 --> Helper loaded: my_helper
INFO - 2024-10-02 16:44:00 --> Database Driver Class Initialized
INFO - 2024-10-02 16:44:00 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-02 16:44:00 --> Controller Class Initialized
INFO - 2024-10-02 16:44:00 --> Final output sent to browser
DEBUG - 2024-10-02 16:44:00 --> Total execution time: 0.0412
INFO - 2024-10-02 16:44:02 --> Config Class Initialized
INFO - 2024-10-02 16:44:02 --> Hooks Class Initialized
DEBUG - 2024-10-02 16:44:02 --> UTF-8 Support Enabled
INFO - 2024-10-02 16:44:02 --> Utf8 Class Initialized
INFO - 2024-10-02 16:44:02 --> URI Class Initialized
INFO - 2024-10-02 16:44:02 --> Router Class Initialized
INFO - 2024-10-02 16:44:02 --> Output Class Initialized
INFO - 2024-10-02 16:44:02 --> Security Class Initialized
DEBUG - 2024-10-02 16:44:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-02 16:44:02 --> Input Class Initialized
INFO - 2024-10-02 16:44:02 --> Language Class Initialized
INFO - 2024-10-02 16:44:02 --> Language Class Initialized
INFO - 2024-10-02 16:44:02 --> Config Class Initialized
INFO - 2024-10-02 16:44:02 --> Loader Class Initialized
INFO - 2024-10-02 16:44:02 --> Helper loaded: url_helper
INFO - 2024-10-02 16:44:02 --> Helper loaded: file_helper
INFO - 2024-10-02 16:44:02 --> Helper loaded: form_helper
INFO - 2024-10-02 16:44:02 --> Helper loaded: my_helper
INFO - 2024-10-02 16:44:02 --> Database Driver Class Initialized
INFO - 2024-10-02 16:44:02 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-02 16:44:02 --> Controller Class Initialized
INFO - 2024-10-02 16:44:02 --> Final output sent to browser
DEBUG - 2024-10-02 16:44:02 --> Total execution time: 0.0387
INFO - 2024-10-02 16:44:26 --> Config Class Initialized
INFO - 2024-10-02 16:44:26 --> Hooks Class Initialized
DEBUG - 2024-10-02 16:44:26 --> UTF-8 Support Enabled
INFO - 2024-10-02 16:44:26 --> Utf8 Class Initialized
INFO - 2024-10-02 16:44:26 --> URI Class Initialized
INFO - 2024-10-02 16:44:26 --> Router Class Initialized
INFO - 2024-10-02 16:44:26 --> Output Class Initialized
INFO - 2024-10-02 16:44:26 --> Security Class Initialized
DEBUG - 2024-10-02 16:44:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-02 16:44:26 --> Input Class Initialized
INFO - 2024-10-02 16:44:26 --> Language Class Initialized
INFO - 2024-10-02 16:44:26 --> Language Class Initialized
INFO - 2024-10-02 16:44:26 --> Config Class Initialized
INFO - 2024-10-02 16:44:26 --> Loader Class Initialized
INFO - 2024-10-02 16:44:26 --> Helper loaded: url_helper
INFO - 2024-10-02 16:44:26 --> Helper loaded: file_helper
INFO - 2024-10-02 16:44:26 --> Helper loaded: form_helper
INFO - 2024-10-02 16:44:26 --> Helper loaded: my_helper
INFO - 2024-10-02 16:44:26 --> Database Driver Class Initialized
INFO - 2024-10-02 16:44:26 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-02 16:44:26 --> Controller Class Initialized
INFO - 2024-10-02 16:44:26 --> Final output sent to browser
DEBUG - 2024-10-02 16:44:26 --> Total execution time: 0.0473
INFO - 2024-10-02 16:44:28 --> Config Class Initialized
INFO - 2024-10-02 16:44:28 --> Hooks Class Initialized
DEBUG - 2024-10-02 16:44:28 --> UTF-8 Support Enabled
INFO - 2024-10-02 16:44:28 --> Utf8 Class Initialized
INFO - 2024-10-02 16:44:28 --> URI Class Initialized
INFO - 2024-10-02 16:44:28 --> Router Class Initialized
INFO - 2024-10-02 16:44:28 --> Output Class Initialized
INFO - 2024-10-02 16:44:28 --> Security Class Initialized
DEBUG - 2024-10-02 16:44:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-02 16:44:28 --> Input Class Initialized
INFO - 2024-10-02 16:44:28 --> Language Class Initialized
INFO - 2024-10-02 16:44:28 --> Language Class Initialized
INFO - 2024-10-02 16:44:28 --> Config Class Initialized
INFO - 2024-10-02 16:44:28 --> Loader Class Initialized
INFO - 2024-10-02 16:44:28 --> Helper loaded: url_helper
INFO - 2024-10-02 16:44:28 --> Helper loaded: file_helper
INFO - 2024-10-02 16:44:28 --> Helper loaded: form_helper
INFO - 2024-10-02 16:44:28 --> Helper loaded: my_helper
INFO - 2024-10-02 16:44:28 --> Database Driver Class Initialized
INFO - 2024-10-02 16:44:28 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-02 16:44:28 --> Controller Class Initialized
INFO - 2024-10-02 16:44:28 --> Final output sent to browser
DEBUG - 2024-10-02 16:44:28 --> Total execution time: 0.0314
INFO - 2024-10-02 16:44:48 --> Config Class Initialized
INFO - 2024-10-02 16:44:48 --> Hooks Class Initialized
DEBUG - 2024-10-02 16:44:48 --> UTF-8 Support Enabled
INFO - 2024-10-02 16:44:48 --> Utf8 Class Initialized
INFO - 2024-10-02 16:44:48 --> URI Class Initialized
INFO - 2024-10-02 16:44:48 --> Router Class Initialized
INFO - 2024-10-02 16:44:48 --> Output Class Initialized
INFO - 2024-10-02 16:44:48 --> Security Class Initialized
DEBUG - 2024-10-02 16:44:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-02 16:44:48 --> Input Class Initialized
INFO - 2024-10-02 16:44:48 --> Language Class Initialized
INFO - 2024-10-02 16:44:48 --> Language Class Initialized
INFO - 2024-10-02 16:44:48 --> Config Class Initialized
INFO - 2024-10-02 16:44:48 --> Loader Class Initialized
INFO - 2024-10-02 16:44:48 --> Helper loaded: url_helper
INFO - 2024-10-02 16:44:48 --> Helper loaded: file_helper
INFO - 2024-10-02 16:44:48 --> Helper loaded: form_helper
INFO - 2024-10-02 16:44:48 --> Helper loaded: my_helper
INFO - 2024-10-02 16:44:48 --> Database Driver Class Initialized
INFO - 2024-10-02 16:44:48 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-02 16:44:48 --> Controller Class Initialized
INFO - 2024-10-02 16:44:48 --> Final output sent to browser
DEBUG - 2024-10-02 16:44:48 --> Total execution time: 0.0543
INFO - 2024-10-02 16:44:50 --> Config Class Initialized
INFO - 2024-10-02 16:44:50 --> Hooks Class Initialized
DEBUG - 2024-10-02 16:44:50 --> UTF-8 Support Enabled
INFO - 2024-10-02 16:44:50 --> Utf8 Class Initialized
INFO - 2024-10-02 16:44:50 --> URI Class Initialized
INFO - 2024-10-02 16:44:50 --> Router Class Initialized
INFO - 2024-10-02 16:44:50 --> Output Class Initialized
INFO - 2024-10-02 16:44:50 --> Security Class Initialized
DEBUG - 2024-10-02 16:44:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-02 16:44:50 --> Input Class Initialized
INFO - 2024-10-02 16:44:50 --> Language Class Initialized
INFO - 2024-10-02 16:44:50 --> Language Class Initialized
INFO - 2024-10-02 16:44:50 --> Config Class Initialized
INFO - 2024-10-02 16:44:50 --> Loader Class Initialized
INFO - 2024-10-02 16:44:50 --> Helper loaded: url_helper
INFO - 2024-10-02 16:44:50 --> Helper loaded: file_helper
INFO - 2024-10-02 16:44:50 --> Helper loaded: form_helper
INFO - 2024-10-02 16:44:50 --> Helper loaded: my_helper
INFO - 2024-10-02 16:44:50 --> Database Driver Class Initialized
INFO - 2024-10-02 16:44:50 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-02 16:44:50 --> Controller Class Initialized
INFO - 2024-10-02 16:44:50 --> Final output sent to browser
DEBUG - 2024-10-02 16:44:50 --> Total execution time: 0.0434
INFO - 2024-10-02 16:45:30 --> Config Class Initialized
INFO - 2024-10-02 16:45:30 --> Hooks Class Initialized
DEBUG - 2024-10-02 16:45:30 --> UTF-8 Support Enabled
INFO - 2024-10-02 16:45:30 --> Utf8 Class Initialized
INFO - 2024-10-02 16:45:30 --> URI Class Initialized
INFO - 2024-10-02 16:45:30 --> Router Class Initialized
INFO - 2024-10-02 16:45:30 --> Output Class Initialized
INFO - 2024-10-02 16:45:30 --> Security Class Initialized
DEBUG - 2024-10-02 16:45:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-02 16:45:30 --> Input Class Initialized
INFO - 2024-10-02 16:45:30 --> Language Class Initialized
INFO - 2024-10-02 16:45:30 --> Language Class Initialized
INFO - 2024-10-02 16:45:30 --> Config Class Initialized
INFO - 2024-10-02 16:45:30 --> Loader Class Initialized
INFO - 2024-10-02 16:45:30 --> Helper loaded: url_helper
INFO - 2024-10-02 16:45:30 --> Helper loaded: file_helper
INFO - 2024-10-02 16:45:30 --> Helper loaded: form_helper
INFO - 2024-10-02 16:45:30 --> Helper loaded: my_helper
INFO - 2024-10-02 16:45:30 --> Database Driver Class Initialized
INFO - 2024-10-02 16:45:30 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-02 16:45:30 --> Controller Class Initialized
INFO - 2024-10-02 16:45:30 --> Final output sent to browser
DEBUG - 2024-10-02 16:45:30 --> Total execution time: 0.0475
INFO - 2024-10-02 16:45:33 --> Config Class Initialized
INFO - 2024-10-02 16:45:33 --> Hooks Class Initialized
DEBUG - 2024-10-02 16:45:33 --> UTF-8 Support Enabled
INFO - 2024-10-02 16:45:33 --> Utf8 Class Initialized
INFO - 2024-10-02 16:45:33 --> URI Class Initialized
INFO - 2024-10-02 16:45:33 --> Router Class Initialized
INFO - 2024-10-02 16:45:33 --> Output Class Initialized
INFO - 2024-10-02 16:45:33 --> Security Class Initialized
DEBUG - 2024-10-02 16:45:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-02 16:45:33 --> Input Class Initialized
INFO - 2024-10-02 16:45:33 --> Language Class Initialized
INFO - 2024-10-02 16:45:33 --> Language Class Initialized
INFO - 2024-10-02 16:45:33 --> Config Class Initialized
INFO - 2024-10-02 16:45:33 --> Loader Class Initialized
INFO - 2024-10-02 16:45:33 --> Helper loaded: url_helper
INFO - 2024-10-02 16:45:33 --> Helper loaded: file_helper
INFO - 2024-10-02 16:45:33 --> Helper loaded: form_helper
INFO - 2024-10-02 16:45:33 --> Helper loaded: my_helper
INFO - 2024-10-02 16:45:33 --> Database Driver Class Initialized
INFO - 2024-10-02 16:45:33 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-02 16:45:33 --> Controller Class Initialized
DEBUG - 2024-10-02 16:45:33 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/view_mapel/views/v_view_mapel.php
DEBUG - 2024-10-02 16:45:33 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-10-02 16:45:33 --> Final output sent to browser
DEBUG - 2024-10-02 16:45:33 --> Total execution time: 0.0421
INFO - 2024-10-02 16:45:35 --> Config Class Initialized
INFO - 2024-10-02 16:45:35 --> Hooks Class Initialized
DEBUG - 2024-10-02 16:45:35 --> UTF-8 Support Enabled
INFO - 2024-10-02 16:45:35 --> Utf8 Class Initialized
INFO - 2024-10-02 16:45:35 --> URI Class Initialized
INFO - 2024-10-02 16:45:35 --> Router Class Initialized
INFO - 2024-10-02 16:45:35 --> Output Class Initialized
INFO - 2024-10-02 16:45:35 --> Security Class Initialized
DEBUG - 2024-10-02 16:45:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-02 16:45:35 --> Input Class Initialized
INFO - 2024-10-02 16:45:35 --> Language Class Initialized
INFO - 2024-10-02 16:45:35 --> Language Class Initialized
INFO - 2024-10-02 16:45:35 --> Config Class Initialized
INFO - 2024-10-02 16:45:35 --> Loader Class Initialized
INFO - 2024-10-02 16:45:35 --> Helper loaded: url_helper
INFO - 2024-10-02 16:45:35 --> Helper loaded: file_helper
INFO - 2024-10-02 16:45:35 --> Helper loaded: form_helper
INFO - 2024-10-02 16:45:35 --> Helper loaded: my_helper
INFO - 2024-10-02 16:45:35 --> Database Driver Class Initialized
INFO - 2024-10-02 16:45:35 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-02 16:45:35 --> Controller Class Initialized
DEBUG - 2024-10-02 16:45:35 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_la/views/list.php
DEBUG - 2024-10-02 16:45:35 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-10-02 16:45:35 --> Final output sent to browser
DEBUG - 2024-10-02 16:45:35 --> Total execution time: 0.0321
INFO - 2024-10-02 16:45:35 --> Config Class Initialized
INFO - 2024-10-02 16:45:35 --> Hooks Class Initialized
DEBUG - 2024-10-02 16:45:35 --> UTF-8 Support Enabled
INFO - 2024-10-02 16:45:35 --> Utf8 Class Initialized
INFO - 2024-10-02 16:45:35 --> URI Class Initialized
INFO - 2024-10-02 16:45:35 --> Router Class Initialized
INFO - 2024-10-02 16:45:35 --> Output Class Initialized
INFO - 2024-10-02 16:45:35 --> Security Class Initialized
DEBUG - 2024-10-02 16:45:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-02 16:45:35 --> Input Class Initialized
INFO - 2024-10-02 16:45:35 --> Language Class Initialized
INFO - 2024-10-02 16:45:35 --> Language Class Initialized
INFO - 2024-10-02 16:45:35 --> Config Class Initialized
INFO - 2024-10-02 16:45:35 --> Loader Class Initialized
INFO - 2024-10-02 16:45:35 --> Helper loaded: url_helper
INFO - 2024-10-02 16:45:35 --> Helper loaded: file_helper
INFO - 2024-10-02 16:45:35 --> Helper loaded: form_helper
INFO - 2024-10-02 16:45:35 --> Helper loaded: my_helper
INFO - 2024-10-02 16:45:35 --> Database Driver Class Initialized
INFO - 2024-10-02 16:45:35 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-02 16:45:35 --> Controller Class Initialized
INFO - 2024-10-02 16:45:36 --> Config Class Initialized
INFO - 2024-10-02 16:45:36 --> Hooks Class Initialized
DEBUG - 2024-10-02 16:45:36 --> UTF-8 Support Enabled
INFO - 2024-10-02 16:45:36 --> Utf8 Class Initialized
INFO - 2024-10-02 16:45:36 --> URI Class Initialized
INFO - 2024-10-02 16:45:36 --> Router Class Initialized
INFO - 2024-10-02 16:45:36 --> Output Class Initialized
INFO - 2024-10-02 16:45:36 --> Security Class Initialized
DEBUG - 2024-10-02 16:45:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-02 16:45:36 --> Input Class Initialized
INFO - 2024-10-02 16:45:36 --> Language Class Initialized
INFO - 2024-10-02 16:45:36 --> Language Class Initialized
INFO - 2024-10-02 16:45:36 --> Config Class Initialized
INFO - 2024-10-02 16:45:36 --> Loader Class Initialized
INFO - 2024-10-02 16:45:36 --> Helper loaded: url_helper
INFO - 2024-10-02 16:45:36 --> Helper loaded: file_helper
INFO - 2024-10-02 16:45:36 --> Helper loaded: form_helper
INFO - 2024-10-02 16:45:36 --> Helper loaded: my_helper
INFO - 2024-10-02 16:45:36 --> Database Driver Class Initialized
INFO - 2024-10-02 16:45:36 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-02 16:45:36 --> Controller Class Initialized
INFO - 2024-10-02 16:45:36 --> Final output sent to browser
DEBUG - 2024-10-02 16:45:36 --> Total execution time: 0.0351
INFO - 2024-10-02 16:46:09 --> Config Class Initialized
INFO - 2024-10-02 16:46:09 --> Hooks Class Initialized
DEBUG - 2024-10-02 16:46:09 --> UTF-8 Support Enabled
INFO - 2024-10-02 16:46:09 --> Utf8 Class Initialized
INFO - 2024-10-02 16:46:09 --> URI Class Initialized
INFO - 2024-10-02 16:46:09 --> Router Class Initialized
INFO - 2024-10-02 16:46:09 --> Output Class Initialized
INFO - 2024-10-02 16:46:09 --> Security Class Initialized
DEBUG - 2024-10-02 16:46:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-02 16:46:09 --> Input Class Initialized
INFO - 2024-10-02 16:46:09 --> Language Class Initialized
INFO - 2024-10-02 16:46:09 --> Language Class Initialized
INFO - 2024-10-02 16:46:09 --> Config Class Initialized
INFO - 2024-10-02 16:46:09 --> Loader Class Initialized
INFO - 2024-10-02 16:46:09 --> Helper loaded: url_helper
INFO - 2024-10-02 16:46:09 --> Helper loaded: file_helper
INFO - 2024-10-02 16:46:09 --> Helper loaded: form_helper
INFO - 2024-10-02 16:46:09 --> Helper loaded: my_helper
INFO - 2024-10-02 16:46:09 --> Database Driver Class Initialized
INFO - 2024-10-02 16:46:09 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-02 16:46:09 --> Controller Class Initialized
INFO - 2024-10-02 16:46:09 --> Final output sent to browser
DEBUG - 2024-10-02 16:46:09 --> Total execution time: 0.0732
INFO - 2024-10-02 16:46:11 --> Config Class Initialized
INFO - 2024-10-02 16:46:11 --> Hooks Class Initialized
DEBUG - 2024-10-02 16:46:11 --> UTF-8 Support Enabled
INFO - 2024-10-02 16:46:11 --> Utf8 Class Initialized
INFO - 2024-10-02 16:46:11 --> URI Class Initialized
INFO - 2024-10-02 16:46:11 --> Router Class Initialized
INFO - 2024-10-02 16:46:11 --> Output Class Initialized
INFO - 2024-10-02 16:46:11 --> Security Class Initialized
DEBUG - 2024-10-02 16:46:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-02 16:46:11 --> Input Class Initialized
INFO - 2024-10-02 16:46:11 --> Language Class Initialized
INFO - 2024-10-02 16:46:11 --> Language Class Initialized
INFO - 2024-10-02 16:46:11 --> Config Class Initialized
INFO - 2024-10-02 16:46:11 --> Loader Class Initialized
INFO - 2024-10-02 16:46:11 --> Helper loaded: url_helper
INFO - 2024-10-02 16:46:11 --> Helper loaded: file_helper
INFO - 2024-10-02 16:46:11 --> Helper loaded: form_helper
INFO - 2024-10-02 16:46:11 --> Helper loaded: my_helper
INFO - 2024-10-02 16:46:11 --> Database Driver Class Initialized
INFO - 2024-10-02 16:46:11 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-02 16:46:11 --> Controller Class Initialized
INFO - 2024-10-02 16:46:11 --> Final output sent to browser
DEBUG - 2024-10-02 16:46:11 --> Total execution time: 0.0304
INFO - 2024-10-02 16:46:12 --> Config Class Initialized
INFO - 2024-10-02 16:46:12 --> Hooks Class Initialized
DEBUG - 2024-10-02 16:46:12 --> UTF-8 Support Enabled
INFO - 2024-10-02 16:46:12 --> Utf8 Class Initialized
INFO - 2024-10-02 16:46:12 --> URI Class Initialized
INFO - 2024-10-02 16:46:12 --> Router Class Initialized
INFO - 2024-10-02 16:46:12 --> Output Class Initialized
INFO - 2024-10-02 16:46:12 --> Security Class Initialized
DEBUG - 2024-10-02 16:46:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-02 16:46:12 --> Input Class Initialized
INFO - 2024-10-02 16:46:12 --> Language Class Initialized
INFO - 2024-10-02 16:46:12 --> Language Class Initialized
INFO - 2024-10-02 16:46:12 --> Config Class Initialized
INFO - 2024-10-02 16:46:12 --> Loader Class Initialized
INFO - 2024-10-02 16:46:12 --> Helper loaded: url_helper
INFO - 2024-10-02 16:46:12 --> Helper loaded: file_helper
INFO - 2024-10-02 16:46:12 --> Helper loaded: form_helper
INFO - 2024-10-02 16:46:12 --> Helper loaded: my_helper
INFO - 2024-10-02 16:46:12 --> Database Driver Class Initialized
INFO - 2024-10-02 16:46:12 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-02 16:46:12 --> Controller Class Initialized
INFO - 2024-10-02 16:46:12 --> Final output sent to browser
DEBUG - 2024-10-02 16:46:12 --> Total execution time: 0.0398
INFO - 2024-10-02 16:46:42 --> Config Class Initialized
INFO - 2024-10-02 16:46:42 --> Hooks Class Initialized
DEBUG - 2024-10-02 16:46:42 --> UTF-8 Support Enabled
INFO - 2024-10-02 16:46:42 --> Utf8 Class Initialized
INFO - 2024-10-02 16:46:42 --> URI Class Initialized
INFO - 2024-10-02 16:46:42 --> Router Class Initialized
INFO - 2024-10-02 16:46:42 --> Output Class Initialized
INFO - 2024-10-02 16:46:42 --> Security Class Initialized
DEBUG - 2024-10-02 16:46:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-02 16:46:42 --> Input Class Initialized
INFO - 2024-10-02 16:46:42 --> Language Class Initialized
INFO - 2024-10-02 16:46:42 --> Language Class Initialized
INFO - 2024-10-02 16:46:42 --> Config Class Initialized
INFO - 2024-10-02 16:46:42 --> Loader Class Initialized
INFO - 2024-10-02 16:46:42 --> Helper loaded: url_helper
INFO - 2024-10-02 16:46:42 --> Helper loaded: file_helper
INFO - 2024-10-02 16:46:42 --> Helper loaded: form_helper
INFO - 2024-10-02 16:46:42 --> Helper loaded: my_helper
INFO - 2024-10-02 16:46:42 --> Database Driver Class Initialized
INFO - 2024-10-02 16:46:42 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-02 16:46:42 --> Controller Class Initialized
INFO - 2024-10-02 16:46:43 --> Final output sent to browser
DEBUG - 2024-10-02 16:46:43 --> Total execution time: 0.5041
INFO - 2024-10-02 16:46:44 --> Config Class Initialized
INFO - 2024-10-02 16:46:44 --> Hooks Class Initialized
DEBUG - 2024-10-02 16:46:44 --> UTF-8 Support Enabled
INFO - 2024-10-02 16:46:44 --> Utf8 Class Initialized
INFO - 2024-10-02 16:46:44 --> URI Class Initialized
INFO - 2024-10-02 16:46:44 --> Router Class Initialized
INFO - 2024-10-02 16:46:44 --> Output Class Initialized
INFO - 2024-10-02 16:46:44 --> Security Class Initialized
DEBUG - 2024-10-02 16:46:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-02 16:46:44 --> Input Class Initialized
INFO - 2024-10-02 16:46:44 --> Language Class Initialized
INFO - 2024-10-02 16:46:44 --> Language Class Initialized
INFO - 2024-10-02 16:46:44 --> Config Class Initialized
INFO - 2024-10-02 16:46:44 --> Loader Class Initialized
INFO - 2024-10-02 16:46:44 --> Helper loaded: url_helper
INFO - 2024-10-02 16:46:44 --> Helper loaded: file_helper
INFO - 2024-10-02 16:46:44 --> Helper loaded: form_helper
INFO - 2024-10-02 16:46:44 --> Helper loaded: my_helper
INFO - 2024-10-02 16:46:44 --> Database Driver Class Initialized
INFO - 2024-10-02 16:46:44 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-02 16:46:44 --> Controller Class Initialized
INFO - 2024-10-02 16:46:44 --> Final output sent to browser
DEBUG - 2024-10-02 16:46:44 --> Total execution time: 0.0775
INFO - 2024-10-02 16:46:45 --> Config Class Initialized
INFO - 2024-10-02 16:46:45 --> Hooks Class Initialized
DEBUG - 2024-10-02 16:46:45 --> UTF-8 Support Enabled
INFO - 2024-10-02 16:46:45 --> Utf8 Class Initialized
INFO - 2024-10-02 16:46:45 --> URI Class Initialized
INFO - 2024-10-02 16:46:45 --> Router Class Initialized
INFO - 2024-10-02 16:46:45 --> Output Class Initialized
INFO - 2024-10-02 16:46:45 --> Security Class Initialized
DEBUG - 2024-10-02 16:46:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-02 16:46:45 --> Input Class Initialized
INFO - 2024-10-02 16:46:45 --> Language Class Initialized
INFO - 2024-10-02 16:46:45 --> Language Class Initialized
INFO - 2024-10-02 16:46:45 --> Config Class Initialized
INFO - 2024-10-02 16:46:45 --> Loader Class Initialized
INFO - 2024-10-02 16:46:45 --> Helper loaded: url_helper
INFO - 2024-10-02 16:46:45 --> Helper loaded: file_helper
INFO - 2024-10-02 16:46:45 --> Helper loaded: form_helper
INFO - 2024-10-02 16:46:45 --> Helper loaded: my_helper
INFO - 2024-10-02 16:46:45 --> Database Driver Class Initialized
INFO - 2024-10-02 16:46:45 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-02 16:46:45 --> Controller Class Initialized
INFO - 2024-10-02 16:46:45 --> Final output sent to browser
DEBUG - 2024-10-02 16:46:45 --> Total execution time: 0.1065
INFO - 2024-10-02 16:47:21 --> Config Class Initialized
INFO - 2024-10-02 16:47:21 --> Hooks Class Initialized
DEBUG - 2024-10-02 16:47:21 --> UTF-8 Support Enabled
INFO - 2024-10-02 16:47:21 --> Utf8 Class Initialized
INFO - 2024-10-02 16:47:21 --> URI Class Initialized
INFO - 2024-10-02 16:47:21 --> Router Class Initialized
INFO - 2024-10-02 16:47:21 --> Output Class Initialized
INFO - 2024-10-02 16:47:21 --> Security Class Initialized
DEBUG - 2024-10-02 16:47:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-02 16:47:21 --> Input Class Initialized
INFO - 2024-10-02 16:47:21 --> Language Class Initialized
INFO - 2024-10-02 16:47:21 --> Language Class Initialized
INFO - 2024-10-02 16:47:21 --> Config Class Initialized
INFO - 2024-10-02 16:47:21 --> Loader Class Initialized
INFO - 2024-10-02 16:47:21 --> Helper loaded: url_helper
INFO - 2024-10-02 16:47:21 --> Helper loaded: file_helper
INFO - 2024-10-02 16:47:21 --> Helper loaded: form_helper
INFO - 2024-10-02 16:47:21 --> Helper loaded: my_helper
INFO - 2024-10-02 16:47:21 --> Database Driver Class Initialized
INFO - 2024-10-02 16:47:22 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-02 16:47:22 --> Controller Class Initialized
INFO - 2024-10-02 16:47:22 --> Final output sent to browser
DEBUG - 2024-10-02 16:47:22 --> Total execution time: 0.3697
INFO - 2024-10-02 16:47:25 --> Config Class Initialized
INFO - 2024-10-02 16:47:25 --> Hooks Class Initialized
DEBUG - 2024-10-02 16:47:25 --> UTF-8 Support Enabled
INFO - 2024-10-02 16:47:25 --> Utf8 Class Initialized
INFO - 2024-10-02 16:47:25 --> URI Class Initialized
INFO - 2024-10-02 16:47:25 --> Router Class Initialized
INFO - 2024-10-02 16:47:25 --> Output Class Initialized
INFO - 2024-10-02 16:47:25 --> Security Class Initialized
DEBUG - 2024-10-02 16:47:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-02 16:47:25 --> Input Class Initialized
INFO - 2024-10-02 16:47:25 --> Language Class Initialized
INFO - 2024-10-02 16:47:25 --> Language Class Initialized
INFO - 2024-10-02 16:47:25 --> Config Class Initialized
INFO - 2024-10-02 16:47:25 --> Loader Class Initialized
INFO - 2024-10-02 16:47:25 --> Helper loaded: url_helper
INFO - 2024-10-02 16:47:25 --> Helper loaded: file_helper
INFO - 2024-10-02 16:47:25 --> Helper loaded: form_helper
INFO - 2024-10-02 16:47:25 --> Helper loaded: my_helper
INFO - 2024-10-02 16:47:25 --> Database Driver Class Initialized
INFO - 2024-10-02 16:47:25 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-02 16:47:25 --> Controller Class Initialized
INFO - 2024-10-02 16:47:25 --> Final output sent to browser
DEBUG - 2024-10-02 16:47:25 --> Total execution time: 0.0658
INFO - 2024-10-02 16:47:48 --> Config Class Initialized
INFO - 2024-10-02 16:47:48 --> Hooks Class Initialized
DEBUG - 2024-10-02 16:47:48 --> UTF-8 Support Enabled
INFO - 2024-10-02 16:47:48 --> Utf8 Class Initialized
INFO - 2024-10-02 16:47:48 --> URI Class Initialized
INFO - 2024-10-02 16:47:48 --> Router Class Initialized
INFO - 2024-10-02 16:47:48 --> Output Class Initialized
INFO - 2024-10-02 16:47:48 --> Security Class Initialized
DEBUG - 2024-10-02 16:47:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-02 16:47:48 --> Input Class Initialized
INFO - 2024-10-02 16:47:48 --> Language Class Initialized
INFO - 2024-10-02 16:47:48 --> Language Class Initialized
INFO - 2024-10-02 16:47:48 --> Config Class Initialized
INFO - 2024-10-02 16:47:48 --> Loader Class Initialized
INFO - 2024-10-02 16:47:48 --> Helper loaded: url_helper
INFO - 2024-10-02 16:47:48 --> Helper loaded: file_helper
INFO - 2024-10-02 16:47:48 --> Helper loaded: form_helper
INFO - 2024-10-02 16:47:48 --> Helper loaded: my_helper
INFO - 2024-10-02 16:47:48 --> Database Driver Class Initialized
INFO - 2024-10-02 16:47:48 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-02 16:47:48 --> Controller Class Initialized
INFO - 2024-10-02 16:47:48 --> Final output sent to browser
DEBUG - 2024-10-02 16:47:48 --> Total execution time: 0.0844
INFO - 2024-10-02 16:47:49 --> Config Class Initialized
INFO - 2024-10-02 16:47:49 --> Hooks Class Initialized
DEBUG - 2024-10-02 16:47:49 --> UTF-8 Support Enabled
INFO - 2024-10-02 16:47:49 --> Utf8 Class Initialized
INFO - 2024-10-02 16:47:49 --> URI Class Initialized
INFO - 2024-10-02 16:47:49 --> Router Class Initialized
INFO - 2024-10-02 16:47:49 --> Output Class Initialized
INFO - 2024-10-02 16:47:49 --> Security Class Initialized
DEBUG - 2024-10-02 16:47:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-02 16:47:49 --> Input Class Initialized
INFO - 2024-10-02 16:47:49 --> Language Class Initialized
INFO - 2024-10-02 16:47:49 --> Language Class Initialized
INFO - 2024-10-02 16:47:49 --> Config Class Initialized
INFO - 2024-10-02 16:47:49 --> Loader Class Initialized
INFO - 2024-10-02 16:47:49 --> Helper loaded: url_helper
INFO - 2024-10-02 16:47:49 --> Helper loaded: file_helper
INFO - 2024-10-02 16:47:49 --> Helper loaded: form_helper
INFO - 2024-10-02 16:47:49 --> Helper loaded: my_helper
INFO - 2024-10-02 16:47:49 --> Database Driver Class Initialized
INFO - 2024-10-02 16:47:49 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-02 16:47:49 --> Controller Class Initialized
INFO - 2024-10-02 16:47:49 --> Final output sent to browser
DEBUG - 2024-10-02 16:47:49 --> Total execution time: 0.0470
INFO - 2024-10-02 16:48:14 --> Config Class Initialized
INFO - 2024-10-02 16:48:14 --> Hooks Class Initialized
DEBUG - 2024-10-02 16:48:14 --> UTF-8 Support Enabled
INFO - 2024-10-02 16:48:14 --> Utf8 Class Initialized
INFO - 2024-10-02 16:48:14 --> URI Class Initialized
INFO - 2024-10-02 16:48:14 --> Router Class Initialized
INFO - 2024-10-02 16:48:14 --> Output Class Initialized
INFO - 2024-10-02 16:48:14 --> Security Class Initialized
DEBUG - 2024-10-02 16:48:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-02 16:48:14 --> Input Class Initialized
INFO - 2024-10-02 16:48:14 --> Language Class Initialized
INFO - 2024-10-02 16:48:14 --> Language Class Initialized
INFO - 2024-10-02 16:48:14 --> Config Class Initialized
INFO - 2024-10-02 16:48:14 --> Loader Class Initialized
INFO - 2024-10-02 16:48:14 --> Helper loaded: url_helper
INFO - 2024-10-02 16:48:14 --> Helper loaded: file_helper
INFO - 2024-10-02 16:48:14 --> Helper loaded: form_helper
INFO - 2024-10-02 16:48:14 --> Helper loaded: my_helper
INFO - 2024-10-02 16:48:14 --> Database Driver Class Initialized
INFO - 2024-10-02 16:48:14 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-02 16:48:14 --> Controller Class Initialized
INFO - 2024-10-02 16:48:14 --> Final output sent to browser
DEBUG - 2024-10-02 16:48:14 --> Total execution time: 0.0594
INFO - 2024-10-02 16:48:16 --> Config Class Initialized
INFO - 2024-10-02 16:48:16 --> Hooks Class Initialized
DEBUG - 2024-10-02 16:48:16 --> UTF-8 Support Enabled
INFO - 2024-10-02 16:48:16 --> Utf8 Class Initialized
INFO - 2024-10-02 16:48:16 --> URI Class Initialized
INFO - 2024-10-02 16:48:16 --> Router Class Initialized
INFO - 2024-10-02 16:48:16 --> Output Class Initialized
INFO - 2024-10-02 16:48:16 --> Security Class Initialized
DEBUG - 2024-10-02 16:48:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-02 16:48:16 --> Input Class Initialized
INFO - 2024-10-02 16:48:16 --> Language Class Initialized
INFO - 2024-10-02 16:48:16 --> Language Class Initialized
INFO - 2024-10-02 16:48:16 --> Config Class Initialized
INFO - 2024-10-02 16:48:16 --> Loader Class Initialized
INFO - 2024-10-02 16:48:16 --> Helper loaded: url_helper
INFO - 2024-10-02 16:48:16 --> Helper loaded: file_helper
INFO - 2024-10-02 16:48:16 --> Helper loaded: form_helper
INFO - 2024-10-02 16:48:16 --> Helper loaded: my_helper
INFO - 2024-10-02 16:48:16 --> Database Driver Class Initialized
INFO - 2024-10-02 16:48:16 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-02 16:48:16 --> Controller Class Initialized
INFO - 2024-10-02 16:48:16 --> Final output sent to browser
DEBUG - 2024-10-02 16:48:16 --> Total execution time: 0.0330
INFO - 2024-10-02 16:48:17 --> Config Class Initialized
INFO - 2024-10-02 16:48:17 --> Hooks Class Initialized
DEBUG - 2024-10-02 16:48:17 --> UTF-8 Support Enabled
INFO - 2024-10-02 16:48:17 --> Utf8 Class Initialized
INFO - 2024-10-02 16:48:17 --> URI Class Initialized
INFO - 2024-10-02 16:48:17 --> Router Class Initialized
INFO - 2024-10-02 16:48:17 --> Output Class Initialized
INFO - 2024-10-02 16:48:17 --> Security Class Initialized
DEBUG - 2024-10-02 16:48:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-02 16:48:17 --> Input Class Initialized
INFO - 2024-10-02 16:48:17 --> Language Class Initialized
INFO - 2024-10-02 16:48:17 --> Language Class Initialized
INFO - 2024-10-02 16:48:17 --> Config Class Initialized
INFO - 2024-10-02 16:48:17 --> Loader Class Initialized
INFO - 2024-10-02 16:48:17 --> Helper loaded: url_helper
INFO - 2024-10-02 16:48:17 --> Helper loaded: file_helper
INFO - 2024-10-02 16:48:17 --> Helper loaded: form_helper
INFO - 2024-10-02 16:48:17 --> Helper loaded: my_helper
INFO - 2024-10-02 16:48:17 --> Database Driver Class Initialized
INFO - 2024-10-02 16:48:17 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-02 16:48:17 --> Controller Class Initialized
DEBUG - 2024-10-02 16:48:17 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/view_mapel/views/v_view_mapel.php
DEBUG - 2024-10-02 16:48:17 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-10-02 16:48:17 --> Final output sent to browser
DEBUG - 2024-10-02 16:48:17 --> Total execution time: 0.0535
INFO - 2024-10-02 16:48:21 --> Config Class Initialized
INFO - 2024-10-02 16:48:21 --> Hooks Class Initialized
DEBUG - 2024-10-02 16:48:21 --> UTF-8 Support Enabled
INFO - 2024-10-02 16:48:21 --> Utf8 Class Initialized
INFO - 2024-10-02 16:48:21 --> URI Class Initialized
INFO - 2024-10-02 16:48:21 --> Router Class Initialized
INFO - 2024-10-02 16:48:21 --> Output Class Initialized
INFO - 2024-10-02 16:48:21 --> Security Class Initialized
DEBUG - 2024-10-02 16:48:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-02 16:48:21 --> Input Class Initialized
INFO - 2024-10-02 16:48:21 --> Language Class Initialized
INFO - 2024-10-02 16:48:21 --> Language Class Initialized
INFO - 2024-10-02 16:48:21 --> Config Class Initialized
INFO - 2024-10-02 16:48:21 --> Loader Class Initialized
INFO - 2024-10-02 16:48:21 --> Helper loaded: url_helper
INFO - 2024-10-02 16:48:21 --> Helper loaded: file_helper
INFO - 2024-10-02 16:48:21 --> Helper loaded: form_helper
INFO - 2024-10-02 16:48:21 --> Helper loaded: my_helper
INFO - 2024-10-02 16:48:21 --> Database Driver Class Initialized
INFO - 2024-10-02 16:48:21 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-02 16:48:21 --> Controller Class Initialized
DEBUG - 2024-10-02 16:48:21 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/list.php
DEBUG - 2024-10-02 16:48:21 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-10-02 16:48:21 --> Final output sent to browser
DEBUG - 2024-10-02 16:48:21 --> Total execution time: 0.0984
INFO - 2024-10-02 16:48:23 --> Config Class Initialized
INFO - 2024-10-02 16:48:23 --> Hooks Class Initialized
DEBUG - 2024-10-02 16:48:23 --> UTF-8 Support Enabled
INFO - 2024-10-02 16:48:23 --> Utf8 Class Initialized
INFO - 2024-10-02 16:48:23 --> URI Class Initialized
INFO - 2024-10-02 16:48:23 --> Router Class Initialized
INFO - 2024-10-02 16:48:23 --> Output Class Initialized
INFO - 2024-10-02 16:48:23 --> Security Class Initialized
DEBUG - 2024-10-02 16:48:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-02 16:48:23 --> Input Class Initialized
INFO - 2024-10-02 16:48:23 --> Language Class Initialized
INFO - 2024-10-02 16:48:23 --> Language Class Initialized
INFO - 2024-10-02 16:48:23 --> Config Class Initialized
INFO - 2024-10-02 16:48:23 --> Loader Class Initialized
INFO - 2024-10-02 16:48:23 --> Helper loaded: url_helper
INFO - 2024-10-02 16:48:23 --> Helper loaded: file_helper
INFO - 2024-10-02 16:48:23 --> Helper loaded: form_helper
INFO - 2024-10-02 16:48:23 --> Helper loaded: my_helper
INFO - 2024-10-02 16:48:23 --> Database Driver Class Initialized
INFO - 2024-10-02 16:48:23 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-02 16:48:23 --> Controller Class Initialized
DEBUG - 2024-10-02 16:48:23 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php
INFO - 2024-10-02 16:48:26 --> Final output sent to browser
DEBUG - 2024-10-02 16:48:26 --> Total execution time: 2.9747
INFO - 2024-10-02 16:56:56 --> Config Class Initialized
INFO - 2024-10-02 16:56:56 --> Hooks Class Initialized
DEBUG - 2024-10-02 16:56:56 --> UTF-8 Support Enabled
INFO - 2024-10-02 16:56:56 --> Utf8 Class Initialized
INFO - 2024-10-02 16:56:56 --> URI Class Initialized
DEBUG - 2024-10-02 16:56:56 --> No URI present. Default controller set.
INFO - 2024-10-02 16:56:56 --> Router Class Initialized
INFO - 2024-10-02 16:56:56 --> Output Class Initialized
INFO - 2024-10-02 16:56:56 --> Security Class Initialized
DEBUG - 2024-10-02 16:56:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-02 16:56:56 --> Input Class Initialized
INFO - 2024-10-02 16:56:56 --> Language Class Initialized
INFO - 2024-10-02 16:56:56 --> Language Class Initialized
INFO - 2024-10-02 16:56:56 --> Config Class Initialized
INFO - 2024-10-02 16:56:56 --> Loader Class Initialized
INFO - 2024-10-02 16:56:56 --> Helper loaded: url_helper
INFO - 2024-10-02 16:56:56 --> Helper loaded: file_helper
INFO - 2024-10-02 16:56:56 --> Helper loaded: form_helper
INFO - 2024-10-02 16:56:56 --> Helper loaded: my_helper
INFO - 2024-10-02 16:56:56 --> Database Driver Class Initialized
INFO - 2024-10-02 16:56:56 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-02 16:56:56 --> Controller Class Initialized
DEBUG - 2024-10-02 16:56:56 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/home/views/v_home_guru.php
DEBUG - 2024-10-02 16:56:56 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-10-02 16:56:56 --> Final output sent to browser
DEBUG - 2024-10-02 16:56:56 --> Total execution time: 0.0749
INFO - 2024-10-02 16:57:03 --> Config Class Initialized
INFO - 2024-10-02 16:57:03 --> Hooks Class Initialized
DEBUG - 2024-10-02 16:57:03 --> UTF-8 Support Enabled
INFO - 2024-10-02 16:57:03 --> Utf8 Class Initialized
INFO - 2024-10-02 16:57:03 --> URI Class Initialized
INFO - 2024-10-02 16:57:03 --> Router Class Initialized
INFO - 2024-10-02 16:57:03 --> Output Class Initialized
INFO - 2024-10-02 16:57:03 --> Security Class Initialized
DEBUG - 2024-10-02 16:57:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-02 16:57:03 --> Input Class Initialized
INFO - 2024-10-02 16:57:03 --> Language Class Initialized
INFO - 2024-10-02 16:57:03 --> Language Class Initialized
INFO - 2024-10-02 16:57:03 --> Config Class Initialized
INFO - 2024-10-02 16:57:03 --> Loader Class Initialized
INFO - 2024-10-02 16:57:03 --> Helper loaded: url_helper
INFO - 2024-10-02 16:57:03 --> Helper loaded: file_helper
INFO - 2024-10-02 16:57:03 --> Helper loaded: form_helper
INFO - 2024-10-02 16:57:03 --> Helper loaded: my_helper
INFO - 2024-10-02 16:57:03 --> Database Driver Class Initialized
INFO - 2024-10-02 16:57:03 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-02 16:57:03 --> Controller Class Initialized
DEBUG - 2024-10-02 16:57:03 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/view_mapel/views/v_view_mapel.php
DEBUG - 2024-10-02 16:57:03 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-10-02 16:57:03 --> Final output sent to browser
DEBUG - 2024-10-02 16:57:03 --> Total execution time: 0.1034
INFO - 2024-10-02 16:57:15 --> Config Class Initialized
INFO - 2024-10-02 16:57:15 --> Hooks Class Initialized
DEBUG - 2024-10-02 16:57:15 --> UTF-8 Support Enabled
INFO - 2024-10-02 16:57:15 --> Utf8 Class Initialized
INFO - 2024-10-02 16:57:15 --> URI Class Initialized
DEBUG - 2024-10-02 16:57:15 --> No URI present. Default controller set.
INFO - 2024-10-02 16:57:15 --> Router Class Initialized
INFO - 2024-10-02 16:57:15 --> Output Class Initialized
INFO - 2024-10-02 16:57:15 --> Security Class Initialized
DEBUG - 2024-10-02 16:57:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-02 16:57:15 --> Input Class Initialized
INFO - 2024-10-02 16:57:15 --> Language Class Initialized
INFO - 2024-10-02 16:57:15 --> Language Class Initialized
INFO - 2024-10-02 16:57:15 --> Config Class Initialized
INFO - 2024-10-02 16:57:15 --> Loader Class Initialized
INFO - 2024-10-02 16:57:15 --> Helper loaded: url_helper
INFO - 2024-10-02 16:57:15 --> Helper loaded: file_helper
INFO - 2024-10-02 16:57:15 --> Helper loaded: form_helper
INFO - 2024-10-02 16:57:15 --> Helper loaded: my_helper
INFO - 2024-10-02 16:57:15 --> Database Driver Class Initialized
INFO - 2024-10-02 16:57:15 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-02 16:57:15 --> Controller Class Initialized
DEBUG - 2024-10-02 16:57:15 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/home/views/v_home_guru.php
DEBUG - 2024-10-02 16:57:15 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-10-02 16:57:15 --> Final output sent to browser
DEBUG - 2024-10-02 16:57:15 --> Total execution time: 0.0328
INFO - 2024-10-02 16:57:23 --> Config Class Initialized
INFO - 2024-10-02 16:57:23 --> Hooks Class Initialized
DEBUG - 2024-10-02 16:57:23 --> UTF-8 Support Enabled
INFO - 2024-10-02 16:57:23 --> Utf8 Class Initialized
INFO - 2024-10-02 16:57:23 --> URI Class Initialized
INFO - 2024-10-02 16:57:23 --> Router Class Initialized
INFO - 2024-10-02 16:57:23 --> Output Class Initialized
INFO - 2024-10-02 16:57:23 --> Security Class Initialized
DEBUG - 2024-10-02 16:57:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-02 16:57:23 --> Input Class Initialized
INFO - 2024-10-02 16:57:23 --> Language Class Initialized
INFO - 2024-10-02 16:57:23 --> Language Class Initialized
INFO - 2024-10-02 16:57:23 --> Config Class Initialized
INFO - 2024-10-02 16:57:23 --> Loader Class Initialized
INFO - 2024-10-02 16:57:23 --> Helper loaded: url_helper
INFO - 2024-10-02 16:57:23 --> Helper loaded: file_helper
INFO - 2024-10-02 16:57:23 --> Helper loaded: form_helper
INFO - 2024-10-02 16:57:23 --> Helper loaded: my_helper
INFO - 2024-10-02 16:57:23 --> Database Driver Class Initialized
INFO - 2024-10-02 16:57:23 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-02 16:57:23 --> Controller Class Initialized
DEBUG - 2024-10-02 16:57:23 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/view_mapel/views/v_view_mapel.php
DEBUG - 2024-10-02 16:57:23 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-10-02 16:57:23 --> Final output sent to browser
DEBUG - 2024-10-02 16:57:23 --> Total execution time: 0.0311
INFO - 2024-10-02 16:57:24 --> Config Class Initialized
INFO - 2024-10-02 16:57:24 --> Hooks Class Initialized
DEBUG - 2024-10-02 16:57:24 --> UTF-8 Support Enabled
INFO - 2024-10-02 16:57:24 --> Utf8 Class Initialized
INFO - 2024-10-02 16:57:24 --> URI Class Initialized
DEBUG - 2024-10-02 16:57:24 --> No URI present. Default controller set.
INFO - 2024-10-02 16:57:24 --> Router Class Initialized
INFO - 2024-10-02 16:57:24 --> Output Class Initialized
INFO - 2024-10-02 16:57:24 --> Security Class Initialized
DEBUG - 2024-10-02 16:57:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-02 16:57:24 --> Input Class Initialized
INFO - 2024-10-02 16:57:24 --> Language Class Initialized
INFO - 2024-10-02 16:57:24 --> Language Class Initialized
INFO - 2024-10-02 16:57:24 --> Config Class Initialized
INFO - 2024-10-02 16:57:24 --> Loader Class Initialized
INFO - 2024-10-02 16:57:24 --> Helper loaded: url_helper
INFO - 2024-10-02 16:57:24 --> Helper loaded: file_helper
INFO - 2024-10-02 16:57:24 --> Helper loaded: form_helper
INFO - 2024-10-02 16:57:24 --> Helper loaded: my_helper
INFO - 2024-10-02 16:57:24 --> Database Driver Class Initialized
INFO - 2024-10-02 16:57:24 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-02 16:57:24 --> Controller Class Initialized
DEBUG - 2024-10-02 16:57:24 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/home/views/v_home_guru.php
DEBUG - 2024-10-02 16:57:24 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-10-02 16:57:24 --> Final output sent to browser
DEBUG - 2024-10-02 16:57:24 --> Total execution time: 0.0274
INFO - 2024-10-02 16:57:30 --> Config Class Initialized
INFO - 2024-10-02 16:57:30 --> Hooks Class Initialized
DEBUG - 2024-10-02 16:57:30 --> UTF-8 Support Enabled
INFO - 2024-10-02 16:57:30 --> Utf8 Class Initialized
INFO - 2024-10-02 16:57:30 --> URI Class Initialized
DEBUG - 2024-10-02 16:57:30 --> No URI present. Default controller set.
INFO - 2024-10-02 16:57:30 --> Router Class Initialized
INFO - 2024-10-02 16:57:30 --> Output Class Initialized
INFO - 2024-10-02 16:57:30 --> Security Class Initialized
DEBUG - 2024-10-02 16:57:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-02 16:57:30 --> Input Class Initialized
INFO - 2024-10-02 16:57:30 --> Language Class Initialized
INFO - 2024-10-02 16:57:30 --> Language Class Initialized
INFO - 2024-10-02 16:57:30 --> Config Class Initialized
INFO - 2024-10-02 16:57:30 --> Loader Class Initialized
INFO - 2024-10-02 16:57:30 --> Helper loaded: url_helper
INFO - 2024-10-02 16:57:30 --> Helper loaded: file_helper
INFO - 2024-10-02 16:57:30 --> Helper loaded: form_helper
INFO - 2024-10-02 16:57:30 --> Helper loaded: my_helper
INFO - 2024-10-02 16:57:30 --> Database Driver Class Initialized
INFO - 2024-10-02 16:57:30 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-02 16:57:30 --> Controller Class Initialized
DEBUG - 2024-10-02 16:57:30 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/home/views/v_home_guru.php
DEBUG - 2024-10-02 16:57:30 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-10-02 16:57:30 --> Final output sent to browser
DEBUG - 2024-10-02 16:57:30 --> Total execution time: 0.0321
INFO - 2024-10-02 16:57:34 --> Config Class Initialized
INFO - 2024-10-02 16:57:34 --> Hooks Class Initialized
DEBUG - 2024-10-02 16:57:34 --> UTF-8 Support Enabled
INFO - 2024-10-02 16:57:34 --> Utf8 Class Initialized
INFO - 2024-10-02 16:57:34 --> URI Class Initialized
INFO - 2024-10-02 16:57:34 --> Router Class Initialized
INFO - 2024-10-02 16:57:34 --> Output Class Initialized
INFO - 2024-10-02 16:57:34 --> Security Class Initialized
DEBUG - 2024-10-02 16:57:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-02 16:57:34 --> Input Class Initialized
INFO - 2024-10-02 16:57:34 --> Language Class Initialized
INFO - 2024-10-02 16:57:34 --> Language Class Initialized
INFO - 2024-10-02 16:57:34 --> Config Class Initialized
INFO - 2024-10-02 16:57:34 --> Loader Class Initialized
INFO - 2024-10-02 16:57:34 --> Helper loaded: url_helper
INFO - 2024-10-02 16:57:34 --> Helper loaded: file_helper
INFO - 2024-10-02 16:57:34 --> Helper loaded: form_helper
INFO - 2024-10-02 16:57:34 --> Helper loaded: my_helper
INFO - 2024-10-02 16:57:34 --> Database Driver Class Initialized
INFO - 2024-10-02 16:57:34 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-02 16:57:34 --> Controller Class Initialized
INFO - 2024-10-02 16:57:34 --> Helper loaded: cookie_helper
INFO - 2024-10-02 16:57:34 --> Config Class Initialized
INFO - 2024-10-02 16:57:34 --> Hooks Class Initialized
DEBUG - 2024-10-02 16:57:34 --> UTF-8 Support Enabled
INFO - 2024-10-02 16:57:34 --> Utf8 Class Initialized
INFO - 2024-10-02 16:57:34 --> URI Class Initialized
INFO - 2024-10-02 16:57:34 --> Router Class Initialized
INFO - 2024-10-02 16:57:34 --> Output Class Initialized
INFO - 2024-10-02 16:57:34 --> Security Class Initialized
DEBUG - 2024-10-02 16:57:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-02 16:57:34 --> Input Class Initialized
INFO - 2024-10-02 16:57:34 --> Language Class Initialized
INFO - 2024-10-02 16:57:34 --> Language Class Initialized
INFO - 2024-10-02 16:57:34 --> Config Class Initialized
INFO - 2024-10-02 16:57:34 --> Loader Class Initialized
INFO - 2024-10-02 16:57:34 --> Helper loaded: url_helper
INFO - 2024-10-02 16:57:34 --> Helper loaded: file_helper
INFO - 2024-10-02 16:57:34 --> Helper loaded: form_helper
INFO - 2024-10-02 16:57:34 --> Helper loaded: my_helper
INFO - 2024-10-02 16:57:34 --> Database Driver Class Initialized
INFO - 2024-10-02 16:57:34 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-02 16:57:34 --> Controller Class Initialized
INFO - 2024-10-02 16:57:35 --> Config Class Initialized
INFO - 2024-10-02 16:57:35 --> Hooks Class Initialized
DEBUG - 2024-10-02 16:57:35 --> UTF-8 Support Enabled
INFO - 2024-10-02 16:57:35 --> Utf8 Class Initialized
INFO - 2024-10-02 16:57:35 --> URI Class Initialized
INFO - 2024-10-02 16:57:35 --> Router Class Initialized
INFO - 2024-10-02 16:57:35 --> Output Class Initialized
INFO - 2024-10-02 16:57:35 --> Security Class Initialized
DEBUG - 2024-10-02 16:57:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-02 16:57:35 --> Input Class Initialized
INFO - 2024-10-02 16:57:35 --> Language Class Initialized
INFO - 2024-10-02 16:57:35 --> Language Class Initialized
INFO - 2024-10-02 16:57:35 --> Config Class Initialized
INFO - 2024-10-02 16:57:35 --> Loader Class Initialized
INFO - 2024-10-02 16:57:35 --> Helper loaded: url_helper
INFO - 2024-10-02 16:57:35 --> Helper loaded: file_helper
INFO - 2024-10-02 16:57:35 --> Helper loaded: form_helper
INFO - 2024-10-02 16:57:35 --> Helper loaded: my_helper
INFO - 2024-10-02 16:57:35 --> Database Driver Class Initialized
INFO - 2024-10-02 16:57:35 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-02 16:57:35 --> Controller Class Initialized
DEBUG - 2024-10-02 16:57:35 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/login/views/login.php
DEBUG - 2024-10-02 16:57:35 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-10-02 16:57:35 --> Final output sent to browser
DEBUG - 2024-10-02 16:57:35 --> Total execution time: 0.0645
INFO - 2024-10-02 16:57:42 --> Config Class Initialized
INFO - 2024-10-02 16:57:42 --> Hooks Class Initialized
DEBUG - 2024-10-02 16:57:42 --> UTF-8 Support Enabled
INFO - 2024-10-02 16:57:42 --> Utf8 Class Initialized
INFO - 2024-10-02 16:57:42 --> URI Class Initialized
INFO - 2024-10-02 16:57:42 --> Router Class Initialized
INFO - 2024-10-02 16:57:42 --> Output Class Initialized
INFO - 2024-10-02 16:57:42 --> Security Class Initialized
DEBUG - 2024-10-02 16:57:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-02 16:57:42 --> Input Class Initialized
INFO - 2024-10-02 16:57:42 --> Language Class Initialized
INFO - 2024-10-02 16:57:42 --> Language Class Initialized
INFO - 2024-10-02 16:57:42 --> Config Class Initialized
INFO - 2024-10-02 16:57:42 --> Loader Class Initialized
INFO - 2024-10-02 16:57:42 --> Helper loaded: url_helper
INFO - 2024-10-02 16:57:42 --> Helper loaded: file_helper
INFO - 2024-10-02 16:57:42 --> Helper loaded: form_helper
INFO - 2024-10-02 16:57:42 --> Helper loaded: my_helper
INFO - 2024-10-02 16:57:42 --> Database Driver Class Initialized
INFO - 2024-10-02 16:57:42 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-02 16:57:42 --> Controller Class Initialized
INFO - 2024-10-02 16:57:42 --> Helper loaded: cookie_helper
INFO - 2024-10-02 16:57:42 --> Final output sent to browser
DEBUG - 2024-10-02 16:57:42 --> Total execution time: 0.0304
INFO - 2024-10-02 16:57:42 --> Config Class Initialized
INFO - 2024-10-02 16:57:42 --> Hooks Class Initialized
DEBUG - 2024-10-02 16:57:42 --> UTF-8 Support Enabled
INFO - 2024-10-02 16:57:42 --> Utf8 Class Initialized
INFO - 2024-10-02 16:57:42 --> URI Class Initialized
INFO - 2024-10-02 16:57:42 --> Router Class Initialized
INFO - 2024-10-02 16:57:42 --> Output Class Initialized
INFO - 2024-10-02 16:57:42 --> Security Class Initialized
DEBUG - 2024-10-02 16:57:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-02 16:57:42 --> Input Class Initialized
INFO - 2024-10-02 16:57:42 --> Language Class Initialized
INFO - 2024-10-02 16:57:42 --> Language Class Initialized
INFO - 2024-10-02 16:57:42 --> Config Class Initialized
INFO - 2024-10-02 16:57:42 --> Loader Class Initialized
INFO - 2024-10-02 16:57:42 --> Helper loaded: url_helper
INFO - 2024-10-02 16:57:42 --> Helper loaded: file_helper
INFO - 2024-10-02 16:57:42 --> Helper loaded: form_helper
INFO - 2024-10-02 16:57:42 --> Helper loaded: my_helper
INFO - 2024-10-02 16:57:42 --> Database Driver Class Initialized
INFO - 2024-10-02 16:57:42 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-02 16:57:42 --> Controller Class Initialized
DEBUG - 2024-10-02 16:57:42 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/home/views/v_home_guru.php
DEBUG - 2024-10-02 16:57:42 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-10-02 16:57:42 --> Final output sent to browser
DEBUG - 2024-10-02 16:57:42 --> Total execution time: 0.0346
INFO - 2024-10-02 16:57:49 --> Config Class Initialized
INFO - 2024-10-02 16:57:49 --> Hooks Class Initialized
DEBUG - 2024-10-02 16:57:49 --> UTF-8 Support Enabled
INFO - 2024-10-02 16:57:49 --> Utf8 Class Initialized
INFO - 2024-10-02 16:57:49 --> URI Class Initialized
INFO - 2024-10-02 16:57:49 --> Router Class Initialized
INFO - 2024-10-02 16:57:49 --> Output Class Initialized
INFO - 2024-10-02 16:57:49 --> Security Class Initialized
DEBUG - 2024-10-02 16:57:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-02 16:57:49 --> Input Class Initialized
INFO - 2024-10-02 16:57:49 --> Language Class Initialized
INFO - 2024-10-02 16:57:49 --> Language Class Initialized
INFO - 2024-10-02 16:57:49 --> Config Class Initialized
INFO - 2024-10-02 16:57:49 --> Loader Class Initialized
INFO - 2024-10-02 16:57:49 --> Helper loaded: url_helper
INFO - 2024-10-02 16:57:49 --> Helper loaded: file_helper
INFO - 2024-10-02 16:57:49 --> Helper loaded: form_helper
INFO - 2024-10-02 16:57:49 --> Helper loaded: my_helper
INFO - 2024-10-02 16:57:49 --> Database Driver Class Initialized
INFO - 2024-10-02 16:57:49 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-02 16:57:49 --> Controller Class Initialized
DEBUG - 2024-10-02 16:57:49 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/view_mapel/views/v_view_mapel.php
DEBUG - 2024-10-02 16:57:49 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-10-02 16:57:49 --> Final output sent to browser
DEBUG - 2024-10-02 16:57:49 --> Total execution time: 0.0318
INFO - 2024-10-02 16:57:51 --> Config Class Initialized
INFO - 2024-10-02 16:57:51 --> Hooks Class Initialized
DEBUG - 2024-10-02 16:57:51 --> UTF-8 Support Enabled
INFO - 2024-10-02 16:57:51 --> Utf8 Class Initialized
INFO - 2024-10-02 16:57:51 --> URI Class Initialized
INFO - 2024-10-02 16:57:51 --> Router Class Initialized
INFO - 2024-10-02 16:57:51 --> Output Class Initialized
INFO - 2024-10-02 16:57:51 --> Security Class Initialized
DEBUG - 2024-10-02 16:57:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-02 16:57:51 --> Input Class Initialized
INFO - 2024-10-02 16:57:51 --> Language Class Initialized
INFO - 2024-10-02 16:57:51 --> Language Class Initialized
INFO - 2024-10-02 16:57:51 --> Config Class Initialized
INFO - 2024-10-02 16:57:51 --> Loader Class Initialized
INFO - 2024-10-02 16:57:51 --> Helper loaded: url_helper
INFO - 2024-10-02 16:57:51 --> Helper loaded: file_helper
INFO - 2024-10-02 16:57:51 --> Helper loaded: form_helper
INFO - 2024-10-02 16:57:51 --> Helper loaded: my_helper
INFO - 2024-10-02 16:57:51 --> Database Driver Class Initialized
INFO - 2024-10-02 16:57:51 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-02 16:57:51 --> Controller Class Initialized
DEBUG - 2024-10-02 16:57:51 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/views/list.php
DEBUG - 2024-10-02 16:57:51 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-10-02 16:57:51 --> Final output sent to browser
DEBUG - 2024-10-02 16:57:51 --> Total execution time: 0.0780
INFO - 2024-10-02 16:57:51 --> Config Class Initialized
INFO - 2024-10-02 16:57:51 --> Hooks Class Initialized
DEBUG - 2024-10-02 16:57:51 --> UTF-8 Support Enabled
INFO - 2024-10-02 16:57:51 --> Utf8 Class Initialized
INFO - 2024-10-02 16:57:51 --> URI Class Initialized
INFO - 2024-10-02 16:57:51 --> Router Class Initialized
INFO - 2024-10-02 16:57:51 --> Output Class Initialized
INFO - 2024-10-02 16:57:51 --> Security Class Initialized
DEBUG - 2024-10-02 16:57:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-02 16:57:51 --> Input Class Initialized
INFO - 2024-10-02 16:57:51 --> Language Class Initialized
INFO - 2024-10-02 16:57:51 --> Language Class Initialized
INFO - 2024-10-02 16:57:51 --> Config Class Initialized
INFO - 2024-10-02 16:57:51 --> Loader Class Initialized
INFO - 2024-10-02 16:57:51 --> Helper loaded: url_helper
INFO - 2024-10-02 16:57:51 --> Helper loaded: file_helper
INFO - 2024-10-02 16:57:51 --> Helper loaded: form_helper
INFO - 2024-10-02 16:57:51 --> Helper loaded: my_helper
INFO - 2024-10-02 16:57:51 --> Database Driver Class Initialized
INFO - 2024-10-02 16:57:51 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-02 16:57:51 --> Controller Class Initialized
INFO - 2024-10-02 16:57:57 --> Config Class Initialized
INFO - 2024-10-02 16:57:57 --> Hooks Class Initialized
DEBUG - 2024-10-02 16:57:57 --> UTF-8 Support Enabled
INFO - 2024-10-02 16:57:57 --> Utf8 Class Initialized
INFO - 2024-10-02 16:57:57 --> URI Class Initialized
INFO - 2024-10-02 16:57:57 --> Router Class Initialized
INFO - 2024-10-02 16:57:57 --> Output Class Initialized
INFO - 2024-10-02 16:57:57 --> Security Class Initialized
DEBUG - 2024-10-02 16:57:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-02 16:57:57 --> Input Class Initialized
INFO - 2024-10-02 16:57:57 --> Language Class Initialized
INFO - 2024-10-02 16:57:57 --> Language Class Initialized
INFO - 2024-10-02 16:57:57 --> Config Class Initialized
INFO - 2024-10-02 16:57:57 --> Loader Class Initialized
INFO - 2024-10-02 16:57:57 --> Helper loaded: url_helper
INFO - 2024-10-02 16:57:57 --> Helper loaded: file_helper
INFO - 2024-10-02 16:57:57 --> Helper loaded: form_helper
INFO - 2024-10-02 16:57:57 --> Helper loaded: my_helper
INFO - 2024-10-02 16:57:57 --> Database Driver Class Initialized
INFO - 2024-10-02 16:57:57 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-02 16:57:57 --> Controller Class Initialized
INFO - 2024-10-02 16:57:57 --> Final output sent to browser
DEBUG - 2024-10-02 16:57:57 --> Total execution time: 0.0403
