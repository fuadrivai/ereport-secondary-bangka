<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2023-05-02 02:09:17 --> Config Class Initialized
INFO - 2023-05-02 02:09:17 --> Hooks Class Initialized
DEBUG - 2023-05-02 02:09:17 --> UTF-8 Support Enabled
INFO - 2023-05-02 02:09:17 --> Utf8 Class Initialized
INFO - 2023-05-02 02:09:17 --> URI Class Initialized
DEBUG - 2023-05-02 02:09:17 --> No URI present. Default controller set.
INFO - 2023-05-02 02:09:17 --> Router Class Initialized
INFO - 2023-05-02 02:09:17 --> Output Class Initialized
INFO - 2023-05-02 02:09:17 --> Security Class Initialized
DEBUG - 2023-05-02 02:09:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-02 02:09:17 --> Input Class Initialized
INFO - 2023-05-02 02:09:17 --> Language Class Initialized
INFO - 2023-05-02 02:09:17 --> Language Class Initialized
INFO - 2023-05-02 02:09:17 --> Config Class Initialized
INFO - 2023-05-02 02:09:17 --> Loader Class Initialized
INFO - 2023-05-02 02:09:17 --> Helper loaded: url_helper
INFO - 2023-05-02 02:09:17 --> Helper loaded: file_helper
INFO - 2023-05-02 02:09:17 --> Helper loaded: form_helper
INFO - 2023-05-02 02:09:17 --> Helper loaded: my_helper
INFO - 2023-05-02 02:09:17 --> Database Driver Class Initialized
DEBUG - 2023-05-02 02:09:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-05-02 02:09:17 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-02 02:09:17 --> Controller Class Initialized
INFO - 2023-05-02 02:09:17 --> Config Class Initialized
INFO - 2023-05-02 02:09:17 --> Hooks Class Initialized
DEBUG - 2023-05-02 02:09:17 --> UTF-8 Support Enabled
INFO - 2023-05-02 02:09:17 --> Utf8 Class Initialized
INFO - 2023-05-02 02:09:17 --> URI Class Initialized
INFO - 2023-05-02 02:09:17 --> Router Class Initialized
INFO - 2023-05-02 02:09:17 --> Output Class Initialized
INFO - 2023-05-02 02:09:17 --> Security Class Initialized
DEBUG - 2023-05-02 02:09:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-02 02:09:17 --> Input Class Initialized
INFO - 2023-05-02 02:09:17 --> Language Class Initialized
INFO - 2023-05-02 02:09:17 --> Language Class Initialized
INFO - 2023-05-02 02:09:17 --> Config Class Initialized
INFO - 2023-05-02 02:09:17 --> Loader Class Initialized
INFO - 2023-05-02 02:09:17 --> Helper loaded: url_helper
INFO - 2023-05-02 02:09:17 --> Helper loaded: file_helper
INFO - 2023-05-02 02:09:17 --> Helper loaded: form_helper
INFO - 2023-05-02 02:09:17 --> Helper loaded: my_helper
INFO - 2023-05-02 02:09:17 --> Database Driver Class Initialized
DEBUG - 2023-05-02 02:09:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-05-02 02:09:17 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-02 02:09:17 --> Controller Class Initialized
DEBUG - 2023-05-02 02:09:17 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/login/views/login.php
DEBUG - 2023-05-02 02:09:17 --> File loaded: C:\xampp\htdocs\myraportk13\application\views\template_utama.php
INFO - 2023-05-02 02:09:17 --> Final output sent to browser
DEBUG - 2023-05-02 02:09:17 --> Total execution time: 0.0641
INFO - 2023-05-02 02:09:22 --> Config Class Initialized
INFO - 2023-05-02 02:09:22 --> Hooks Class Initialized
DEBUG - 2023-05-02 02:09:22 --> UTF-8 Support Enabled
INFO - 2023-05-02 02:09:22 --> Utf8 Class Initialized
INFO - 2023-05-02 02:09:22 --> URI Class Initialized
INFO - 2023-05-02 02:09:22 --> Router Class Initialized
INFO - 2023-05-02 02:09:22 --> Output Class Initialized
INFO - 2023-05-02 02:09:22 --> Security Class Initialized
DEBUG - 2023-05-02 02:09:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-02 02:09:22 --> Input Class Initialized
INFO - 2023-05-02 02:09:22 --> Language Class Initialized
INFO - 2023-05-02 02:09:22 --> Language Class Initialized
INFO - 2023-05-02 02:09:22 --> Config Class Initialized
INFO - 2023-05-02 02:09:22 --> Loader Class Initialized
INFO - 2023-05-02 02:09:22 --> Helper loaded: url_helper
INFO - 2023-05-02 02:09:22 --> Helper loaded: file_helper
INFO - 2023-05-02 02:09:22 --> Helper loaded: form_helper
INFO - 2023-05-02 02:09:22 --> Helper loaded: my_helper
INFO - 2023-05-02 02:09:22 --> Database Driver Class Initialized
DEBUG - 2023-05-02 02:09:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-05-02 02:09:22 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-02 02:09:22 --> Controller Class Initialized
INFO - 2023-05-02 02:09:22 --> Helper loaded: cookie_helper
INFO - 2023-05-02 02:09:22 --> Final output sent to browser
DEBUG - 2023-05-02 02:09:22 --> Total execution time: 0.0825
INFO - 2023-05-02 02:09:22 --> Config Class Initialized
INFO - 2023-05-02 02:09:22 --> Hooks Class Initialized
DEBUG - 2023-05-02 02:09:22 --> UTF-8 Support Enabled
INFO - 2023-05-02 02:09:22 --> Utf8 Class Initialized
INFO - 2023-05-02 02:09:22 --> URI Class Initialized
INFO - 2023-05-02 02:09:22 --> Router Class Initialized
INFO - 2023-05-02 02:09:22 --> Output Class Initialized
INFO - 2023-05-02 02:09:22 --> Security Class Initialized
DEBUG - 2023-05-02 02:09:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-02 02:09:22 --> Input Class Initialized
INFO - 2023-05-02 02:09:22 --> Language Class Initialized
INFO - 2023-05-02 02:09:22 --> Language Class Initialized
INFO - 2023-05-02 02:09:22 --> Config Class Initialized
INFO - 2023-05-02 02:09:22 --> Loader Class Initialized
INFO - 2023-05-02 02:09:22 --> Helper loaded: url_helper
INFO - 2023-05-02 02:09:22 --> Helper loaded: file_helper
INFO - 2023-05-02 02:09:22 --> Helper loaded: form_helper
INFO - 2023-05-02 02:09:22 --> Helper loaded: my_helper
INFO - 2023-05-02 02:09:22 --> Database Driver Class Initialized
DEBUG - 2023-05-02 02:09:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-05-02 02:09:22 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-02 02:09:22 --> Controller Class Initialized
DEBUG - 2023-05-02 02:09:22 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/home/views/v_home_guru.php
DEBUG - 2023-05-02 02:09:22 --> File loaded: C:\xampp\htdocs\myraportk13\application\views\template_utama.php
INFO - 2023-05-02 02:09:22 --> Final output sent to browser
DEBUG - 2023-05-02 02:09:22 --> Total execution time: 0.0493
INFO - 2023-05-02 02:09:25 --> Config Class Initialized
INFO - 2023-05-02 02:09:25 --> Hooks Class Initialized
DEBUG - 2023-05-02 02:09:25 --> UTF-8 Support Enabled
INFO - 2023-05-02 02:09:25 --> Utf8 Class Initialized
INFO - 2023-05-02 02:09:25 --> URI Class Initialized
INFO - 2023-05-02 02:09:25 --> Router Class Initialized
INFO - 2023-05-02 02:09:25 --> Output Class Initialized
INFO - 2023-05-02 02:09:25 --> Security Class Initialized
DEBUG - 2023-05-02 02:09:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-02 02:09:25 --> Input Class Initialized
INFO - 2023-05-02 02:09:25 --> Language Class Initialized
INFO - 2023-05-02 02:09:25 --> Language Class Initialized
INFO - 2023-05-02 02:09:25 --> Config Class Initialized
INFO - 2023-05-02 02:09:25 --> Loader Class Initialized
INFO - 2023-05-02 02:09:25 --> Helper loaded: url_helper
INFO - 2023-05-02 02:09:25 --> Helper loaded: file_helper
INFO - 2023-05-02 02:09:25 --> Helper loaded: form_helper
INFO - 2023-05-02 02:09:25 --> Helper loaded: my_helper
INFO - 2023-05-02 02:09:25 --> Database Driver Class Initialized
DEBUG - 2023-05-02 02:09:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-05-02 02:09:25 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-02 02:09:25 --> Controller Class Initialized
DEBUG - 2023-05-02 02:09:25 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/n_catatan_nna/views/list.php
DEBUG - 2023-05-02 02:09:25 --> File loaded: C:\xampp\htdocs\myraportk13\application\views\template_utama.php
INFO - 2023-05-02 02:09:25 --> Final output sent to browser
DEBUG - 2023-05-02 02:09:25 --> Total execution time: 0.0661
INFO - 2023-05-02 02:09:54 --> Config Class Initialized
INFO - 2023-05-02 02:09:54 --> Hooks Class Initialized
DEBUG - 2023-05-02 02:09:54 --> UTF-8 Support Enabled
INFO - 2023-05-02 02:09:54 --> Utf8 Class Initialized
INFO - 2023-05-02 02:09:54 --> URI Class Initialized
INFO - 2023-05-02 02:09:54 --> Router Class Initialized
INFO - 2023-05-02 02:09:54 --> Output Class Initialized
INFO - 2023-05-02 02:09:54 --> Security Class Initialized
DEBUG - 2023-05-02 02:09:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-02 02:09:54 --> Input Class Initialized
INFO - 2023-05-02 02:09:54 --> Language Class Initialized
INFO - 2023-05-02 02:09:54 --> Language Class Initialized
INFO - 2023-05-02 02:09:54 --> Config Class Initialized
INFO - 2023-05-02 02:09:54 --> Loader Class Initialized
INFO - 2023-05-02 02:09:54 --> Helper loaded: url_helper
INFO - 2023-05-02 02:09:54 --> Helper loaded: file_helper
INFO - 2023-05-02 02:09:54 --> Helper loaded: form_helper
INFO - 2023-05-02 02:09:54 --> Helper loaded: my_helper
INFO - 2023-05-02 02:09:54 --> Database Driver Class Initialized
DEBUG - 2023-05-02 02:09:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-05-02 02:09:54 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-02 02:09:54 --> Controller Class Initialized
DEBUG - 2023-05-02 02:09:54 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/n_catatan_nna/views/list.php
DEBUG - 2023-05-02 02:09:54 --> File loaded: C:\xampp\htdocs\myraportk13\application\views\template_utama.php
INFO - 2023-05-02 02:09:54 --> Final output sent to browser
DEBUG - 2023-05-02 02:09:54 --> Total execution time: 0.0932
INFO - 2023-05-02 02:10:19 --> Config Class Initialized
INFO - 2023-05-02 02:10:19 --> Hooks Class Initialized
DEBUG - 2023-05-02 02:10:19 --> UTF-8 Support Enabled
INFO - 2023-05-02 02:10:19 --> Utf8 Class Initialized
INFO - 2023-05-02 02:10:19 --> URI Class Initialized
INFO - 2023-05-02 02:10:19 --> Router Class Initialized
INFO - 2023-05-02 02:10:19 --> Output Class Initialized
INFO - 2023-05-02 02:10:19 --> Security Class Initialized
DEBUG - 2023-05-02 02:10:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-02 02:10:19 --> Input Class Initialized
INFO - 2023-05-02 02:10:19 --> Language Class Initialized
INFO - 2023-05-02 02:10:19 --> Language Class Initialized
INFO - 2023-05-02 02:10:19 --> Config Class Initialized
INFO - 2023-05-02 02:10:19 --> Loader Class Initialized
INFO - 2023-05-02 02:10:19 --> Helper loaded: url_helper
INFO - 2023-05-02 02:10:19 --> Helper loaded: file_helper
INFO - 2023-05-02 02:10:19 --> Helper loaded: form_helper
INFO - 2023-05-02 02:10:19 --> Helper loaded: my_helper
INFO - 2023-05-02 02:10:19 --> Database Driver Class Initialized
DEBUG - 2023-05-02 02:10:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-05-02 02:10:19 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-02 02:10:19 --> Controller Class Initialized
DEBUG - 2023-05-02 02:10:19 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/n_catatan_nna/views/list.php
DEBUG - 2023-05-02 02:10:19 --> File loaded: C:\xampp\htdocs\myraportk13\application\views\template_utama.php
INFO - 2023-05-02 02:10:19 --> Final output sent to browser
DEBUG - 2023-05-02 02:10:19 --> Total execution time: 0.0900
INFO - 2023-05-02 02:10:41 --> Config Class Initialized
INFO - 2023-05-02 02:10:41 --> Hooks Class Initialized
DEBUG - 2023-05-02 02:10:41 --> UTF-8 Support Enabled
INFO - 2023-05-02 02:10:41 --> Utf8 Class Initialized
INFO - 2023-05-02 02:10:41 --> URI Class Initialized
INFO - 2023-05-02 02:10:41 --> Router Class Initialized
INFO - 2023-05-02 02:10:41 --> Output Class Initialized
INFO - 2023-05-02 02:10:41 --> Security Class Initialized
DEBUG - 2023-05-02 02:10:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-02 02:10:41 --> Input Class Initialized
INFO - 2023-05-02 02:10:41 --> Language Class Initialized
INFO - 2023-05-02 02:10:41 --> Language Class Initialized
INFO - 2023-05-02 02:10:41 --> Config Class Initialized
INFO - 2023-05-02 02:10:41 --> Loader Class Initialized
INFO - 2023-05-02 02:10:41 --> Helper loaded: url_helper
INFO - 2023-05-02 02:10:41 --> Helper loaded: file_helper
INFO - 2023-05-02 02:10:41 --> Helper loaded: form_helper
INFO - 2023-05-02 02:10:41 --> Helper loaded: my_helper
INFO - 2023-05-02 02:10:41 --> Database Driver Class Initialized
DEBUG - 2023-05-02 02:10:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-05-02 02:10:42 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-02 02:10:42 --> Controller Class Initialized
INFO - 2023-05-02 02:10:42 --> Final output sent to browser
DEBUG - 2023-05-02 02:10:42 --> Total execution time: 0.0663
INFO - 2023-05-02 02:10:43 --> Config Class Initialized
INFO - 2023-05-02 02:10:43 --> Hooks Class Initialized
DEBUG - 2023-05-02 02:10:43 --> UTF-8 Support Enabled
INFO - 2023-05-02 02:10:43 --> Utf8 Class Initialized
INFO - 2023-05-02 02:10:43 --> URI Class Initialized
INFO - 2023-05-02 02:10:43 --> Router Class Initialized
INFO - 2023-05-02 02:10:43 --> Output Class Initialized
INFO - 2023-05-02 02:10:43 --> Security Class Initialized
DEBUG - 2023-05-02 02:10:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-02 02:10:43 --> Input Class Initialized
INFO - 2023-05-02 02:10:43 --> Language Class Initialized
INFO - 2023-05-02 02:10:43 --> Language Class Initialized
INFO - 2023-05-02 02:10:43 --> Config Class Initialized
INFO - 2023-05-02 02:10:43 --> Loader Class Initialized
INFO - 2023-05-02 02:10:43 --> Helper loaded: url_helper
INFO - 2023-05-02 02:10:43 --> Helper loaded: file_helper
INFO - 2023-05-02 02:10:43 --> Helper loaded: form_helper
INFO - 2023-05-02 02:10:43 --> Helper loaded: my_helper
INFO - 2023-05-02 02:10:43 --> Database Driver Class Initialized
DEBUG - 2023-05-02 02:10:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-05-02 02:10:43 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-02 02:10:43 --> Controller Class Initialized
DEBUG - 2023-05-02 02:10:43 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/n_catatan_nna/views/list.php
DEBUG - 2023-05-02 02:10:43 --> File loaded: C:\xampp\htdocs\myraportk13\application\views\template_utama.php
INFO - 2023-05-02 02:10:43 --> Final output sent to browser
DEBUG - 2023-05-02 02:10:43 --> Total execution time: 0.0635
INFO - 2023-05-02 02:10:44 --> Config Class Initialized
INFO - 2023-05-02 02:10:44 --> Hooks Class Initialized
DEBUG - 2023-05-02 02:10:44 --> UTF-8 Support Enabled
INFO - 2023-05-02 02:10:44 --> Utf8 Class Initialized
INFO - 2023-05-02 02:10:44 --> URI Class Initialized
INFO - 2023-05-02 02:10:44 --> Router Class Initialized
INFO - 2023-05-02 02:10:44 --> Output Class Initialized
INFO - 2023-05-02 02:10:44 --> Security Class Initialized
DEBUG - 2023-05-02 02:10:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-02 02:10:44 --> Input Class Initialized
INFO - 2023-05-02 02:10:44 --> Language Class Initialized
INFO - 2023-05-02 02:10:44 --> Language Class Initialized
INFO - 2023-05-02 02:10:44 --> Config Class Initialized
INFO - 2023-05-02 02:10:44 --> Loader Class Initialized
INFO - 2023-05-02 02:10:44 --> Helper loaded: url_helper
INFO - 2023-05-02 02:10:44 --> Helper loaded: file_helper
INFO - 2023-05-02 02:10:44 --> Helper loaded: form_helper
INFO - 2023-05-02 02:10:44 --> Helper loaded: my_helper
INFO - 2023-05-02 02:10:44 --> Database Driver Class Initialized
DEBUG - 2023-05-02 02:10:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-05-02 02:10:44 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-02 02:10:44 --> Controller Class Initialized
DEBUG - 2023-05-02 02:10:44 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/n_catatan_nna/views/list.php
DEBUG - 2023-05-02 02:10:44 --> File loaded: C:\xampp\htdocs\myraportk13\application\views\template_utama.php
INFO - 2023-05-02 02:10:44 --> Final output sent to browser
DEBUG - 2023-05-02 02:10:44 --> Total execution time: 0.0632
INFO - 2023-05-02 02:10:58 --> Config Class Initialized
INFO - 2023-05-02 02:10:58 --> Hooks Class Initialized
DEBUG - 2023-05-02 02:10:58 --> UTF-8 Support Enabled
INFO - 2023-05-02 02:10:58 --> Utf8 Class Initialized
INFO - 2023-05-02 02:10:58 --> URI Class Initialized
INFO - 2023-05-02 02:10:58 --> Router Class Initialized
INFO - 2023-05-02 02:10:58 --> Output Class Initialized
INFO - 2023-05-02 02:10:58 --> Security Class Initialized
DEBUG - 2023-05-02 02:10:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-02 02:10:58 --> Input Class Initialized
INFO - 2023-05-02 02:10:58 --> Language Class Initialized
INFO - 2023-05-02 02:10:58 --> Language Class Initialized
INFO - 2023-05-02 02:10:58 --> Config Class Initialized
INFO - 2023-05-02 02:10:58 --> Loader Class Initialized
INFO - 2023-05-02 02:10:58 --> Helper loaded: url_helper
INFO - 2023-05-02 02:10:58 --> Helper loaded: file_helper
INFO - 2023-05-02 02:10:58 --> Helper loaded: form_helper
INFO - 2023-05-02 02:10:58 --> Helper loaded: my_helper
INFO - 2023-05-02 02:10:58 --> Database Driver Class Initialized
DEBUG - 2023-05-02 02:10:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-05-02 02:10:58 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-02 02:10:58 --> Controller Class Initialized
DEBUG - 2023-05-02 02:10:58 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/view_mapel/views/v_view_mapel.php
DEBUG - 2023-05-02 02:10:58 --> File loaded: C:\xampp\htdocs\myraportk13\application\views\template_utama.php
INFO - 2023-05-02 02:10:58 --> Final output sent to browser
DEBUG - 2023-05-02 02:10:58 --> Total execution time: 0.0674
INFO - 2023-05-02 02:10:59 --> Config Class Initialized
INFO - 2023-05-02 02:10:59 --> Hooks Class Initialized
DEBUG - 2023-05-02 02:10:59 --> UTF-8 Support Enabled
INFO - 2023-05-02 02:10:59 --> Utf8 Class Initialized
INFO - 2023-05-02 02:10:59 --> URI Class Initialized
INFO - 2023-05-02 02:10:59 --> Router Class Initialized
INFO - 2023-05-02 02:10:59 --> Output Class Initialized
INFO - 2023-05-02 02:10:59 --> Security Class Initialized
DEBUG - 2023-05-02 02:10:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-02 02:10:59 --> Input Class Initialized
INFO - 2023-05-02 02:10:59 --> Language Class Initialized
INFO - 2023-05-02 02:10:59 --> Language Class Initialized
INFO - 2023-05-02 02:10:59 --> Config Class Initialized
INFO - 2023-05-02 02:10:59 --> Loader Class Initialized
INFO - 2023-05-02 02:10:59 --> Helper loaded: url_helper
INFO - 2023-05-02 02:10:59 --> Helper loaded: file_helper
INFO - 2023-05-02 02:10:59 --> Helper loaded: form_helper
INFO - 2023-05-02 02:10:59 --> Helper loaded: my_helper
INFO - 2023-05-02 02:10:59 --> Database Driver Class Initialized
DEBUG - 2023-05-02 02:10:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-05-02 02:10:59 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-02 02:10:59 --> Controller Class Initialized
DEBUG - 2023-05-02 02:10:59 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/n_icb/views/list.php
DEBUG - 2023-05-02 02:10:59 --> File loaded: C:\xampp\htdocs\myraportk13\application\views\template_utama.php
INFO - 2023-05-02 02:10:59 --> Final output sent to browser
DEBUG - 2023-05-02 02:10:59 --> Total execution time: 0.0656
INFO - 2023-05-02 02:10:59 --> Config Class Initialized
INFO - 2023-05-02 02:10:59 --> Hooks Class Initialized
DEBUG - 2023-05-02 02:10:59 --> UTF-8 Support Enabled
INFO - 2023-05-02 02:10:59 --> Utf8 Class Initialized
INFO - 2023-05-02 02:10:59 --> URI Class Initialized
INFO - 2023-05-02 02:10:59 --> Router Class Initialized
INFO - 2023-05-02 02:10:59 --> Output Class Initialized
INFO - 2023-05-02 02:10:59 --> Security Class Initialized
DEBUG - 2023-05-02 02:10:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-02 02:10:59 --> Input Class Initialized
INFO - 2023-05-02 02:10:59 --> Language Class Initialized
INFO - 2023-05-02 02:10:59 --> Language Class Initialized
INFO - 2023-05-02 02:10:59 --> Config Class Initialized
INFO - 2023-05-02 02:10:59 --> Loader Class Initialized
INFO - 2023-05-02 02:10:59 --> Helper loaded: url_helper
INFO - 2023-05-02 02:10:59 --> Helper loaded: file_helper
INFO - 2023-05-02 02:10:59 --> Helper loaded: form_helper
INFO - 2023-05-02 02:10:59 --> Helper loaded: my_helper
INFO - 2023-05-02 02:10:59 --> Database Driver Class Initialized
DEBUG - 2023-05-02 02:10:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-05-02 02:10:59 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-02 02:10:59 --> Controller Class Initialized
INFO - 2023-05-02 02:11:52 --> Config Class Initialized
INFO - 2023-05-02 02:11:52 --> Hooks Class Initialized
DEBUG - 2023-05-02 02:11:52 --> UTF-8 Support Enabled
INFO - 2023-05-02 02:11:52 --> Utf8 Class Initialized
INFO - 2023-05-02 02:11:52 --> URI Class Initialized
INFO - 2023-05-02 02:11:52 --> Router Class Initialized
INFO - 2023-05-02 02:11:52 --> Output Class Initialized
INFO - 2023-05-02 02:11:52 --> Security Class Initialized
DEBUG - 2023-05-02 02:11:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-02 02:11:52 --> Input Class Initialized
INFO - 2023-05-02 02:11:52 --> Language Class Initialized
INFO - 2023-05-02 02:11:52 --> Language Class Initialized
INFO - 2023-05-02 02:11:52 --> Config Class Initialized
INFO - 2023-05-02 02:11:52 --> Loader Class Initialized
INFO - 2023-05-02 02:11:52 --> Helper loaded: url_helper
INFO - 2023-05-02 02:11:52 --> Helper loaded: file_helper
INFO - 2023-05-02 02:11:52 --> Helper loaded: form_helper
INFO - 2023-05-02 02:11:52 --> Helper loaded: my_helper
INFO - 2023-05-02 02:11:52 --> Database Driver Class Initialized
DEBUG - 2023-05-02 02:11:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-05-02 02:11:52 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-02 02:11:52 --> Controller Class Initialized
ERROR - 2023-05-02 02:11:52 --> Severity: Notice --> Undefined variable: detil_mp C:\xampp\htdocs\myraportk13\application\modules\n_catatan_nna\views\list.php 15
ERROR - 2023-05-02 02:11:52 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\myraportk13\application\modules\n_catatan_nna\views\list.php 15
ERROR - 2023-05-02 02:11:52 --> Severity: Notice --> Undefined variable: detil_mp C:\xampp\htdocs\myraportk13\application\modules\n_catatan_nna\views\list.php 15
ERROR - 2023-05-02 02:11:52 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\myraportk13\application\modules\n_catatan_nna\views\list.php 15
ERROR - 2023-05-02 02:11:52 --> Severity: Notice --> Undefined variable: detil_mp C:\xampp\htdocs\myraportk13\application\modules\n_catatan_nna\views\list.php 17
ERROR - 2023-05-02 02:11:52 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\myraportk13\application\modules\n_catatan_nna\views\list.php 17
ERROR - 2023-05-02 02:11:52 --> Severity: Notice --> Undefined variable: detil_mp C:\xampp\htdocs\myraportk13\application\modules\n_catatan_nna\views\list.php 17
ERROR - 2023-05-02 02:11:52 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\myraportk13\application\modules\n_catatan_nna\views\list.php 17
DEBUG - 2023-05-02 02:11:52 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/n_catatan_nna/views/list.php
DEBUG - 2023-05-02 02:11:52 --> File loaded: C:\xampp\htdocs\myraportk13\application\views\template_utama.php
INFO - 2023-05-02 02:11:52 --> Final output sent to browser
DEBUG - 2023-05-02 02:11:52 --> Total execution time: 0.1007
INFO - 2023-05-02 02:12:45 --> Config Class Initialized
INFO - 2023-05-02 02:12:45 --> Hooks Class Initialized
DEBUG - 2023-05-02 02:12:45 --> UTF-8 Support Enabled
INFO - 2023-05-02 02:12:45 --> Utf8 Class Initialized
INFO - 2023-05-02 02:12:45 --> URI Class Initialized
INFO - 2023-05-02 02:12:45 --> Router Class Initialized
INFO - 2023-05-02 02:12:45 --> Output Class Initialized
INFO - 2023-05-02 02:12:45 --> Security Class Initialized
DEBUG - 2023-05-02 02:12:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-02 02:12:45 --> Input Class Initialized
INFO - 2023-05-02 02:12:45 --> Language Class Initialized
INFO - 2023-05-02 02:12:45 --> Language Class Initialized
INFO - 2023-05-02 02:12:45 --> Config Class Initialized
INFO - 2023-05-02 02:12:45 --> Loader Class Initialized
INFO - 2023-05-02 02:12:45 --> Helper loaded: url_helper
INFO - 2023-05-02 02:12:45 --> Helper loaded: file_helper
INFO - 2023-05-02 02:12:45 --> Helper loaded: form_helper
INFO - 2023-05-02 02:12:45 --> Helper loaded: my_helper
INFO - 2023-05-02 02:12:45 --> Database Driver Class Initialized
DEBUG - 2023-05-02 02:12:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-05-02 02:12:45 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-02 02:12:45 --> Controller Class Initialized
ERROR - 2023-05-02 02:12:45 --> Severity: Notice --> Undefined variable: detil_mp C:\xampp\htdocs\myraportk13\application\modules\n_catatan_nna\views\list.php 13
ERROR - 2023-05-02 02:12:45 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\myraportk13\application\modules\n_catatan_nna\views\list.php 13
ERROR - 2023-05-02 02:12:45 --> Severity: Notice --> Undefined variable: detil_mp C:\xampp\htdocs\myraportk13\application\modules\n_catatan_nna\views\list.php 13
ERROR - 2023-05-02 02:12:45 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\myraportk13\application\modules\n_catatan_nna\views\list.php 13
ERROR - 2023-05-02 02:12:45 --> Severity: Notice --> Undefined variable: detil_mp C:\xampp\htdocs\myraportk13\application\modules\n_catatan_nna\views\list.php 15
ERROR - 2023-05-02 02:12:45 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\myraportk13\application\modules\n_catatan_nna\views\list.php 15
ERROR - 2023-05-02 02:12:45 --> Severity: Notice --> Undefined variable: detil_mp C:\xampp\htdocs\myraportk13\application\modules\n_catatan_nna\views\list.php 15
ERROR - 2023-05-02 02:12:45 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\myraportk13\application\modules\n_catatan_nna\views\list.php 15
DEBUG - 2023-05-02 02:12:45 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/n_catatan_nna/views/list.php
DEBUG - 2023-05-02 02:12:45 --> File loaded: C:\xampp\htdocs\myraportk13\application\views\template_utama.php
INFO - 2023-05-02 02:12:45 --> Final output sent to browser
DEBUG - 2023-05-02 02:12:45 --> Total execution time: 0.0947
INFO - 2023-05-02 02:13:07 --> Config Class Initialized
INFO - 2023-05-02 02:13:07 --> Hooks Class Initialized
DEBUG - 2023-05-02 02:13:07 --> UTF-8 Support Enabled
INFO - 2023-05-02 02:13:07 --> Utf8 Class Initialized
INFO - 2023-05-02 02:13:07 --> URI Class Initialized
INFO - 2023-05-02 02:13:07 --> Router Class Initialized
INFO - 2023-05-02 02:13:07 --> Output Class Initialized
INFO - 2023-05-02 02:13:07 --> Security Class Initialized
DEBUG - 2023-05-02 02:13:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-02 02:13:07 --> Input Class Initialized
INFO - 2023-05-02 02:13:07 --> Language Class Initialized
INFO - 2023-05-02 02:13:07 --> Language Class Initialized
INFO - 2023-05-02 02:13:07 --> Config Class Initialized
INFO - 2023-05-02 02:13:07 --> Loader Class Initialized
INFO - 2023-05-02 02:13:07 --> Helper loaded: url_helper
INFO - 2023-05-02 02:13:07 --> Helper loaded: file_helper
INFO - 2023-05-02 02:13:07 --> Helper loaded: form_helper
INFO - 2023-05-02 02:13:07 --> Helper loaded: my_helper
INFO - 2023-05-02 02:13:07 --> Database Driver Class Initialized
DEBUG - 2023-05-02 02:13:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-05-02 02:13:07 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-02 02:13:07 --> Controller Class Initialized
ERROR - 2023-05-02 02:13:07 --> Severity: Notice --> Undefined variable: detil_mp C:\xampp\htdocs\myraportk13\application\modules\n_catatan_nna\views\list.php 13
ERROR - 2023-05-02 02:13:07 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\myraportk13\application\modules\n_catatan_nna\views\list.php 13
ERROR - 2023-05-02 02:13:07 --> Severity: Notice --> Undefined variable: detil_mp C:\xampp\htdocs\myraportk13\application\modules\n_catatan_nna\views\list.php 13
ERROR - 2023-05-02 02:13:07 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\myraportk13\application\modules\n_catatan_nna\views\list.php 13
ERROR - 2023-05-02 02:13:07 --> Severity: Notice --> Undefined variable: detil_mp C:\xampp\htdocs\myraportk13\application\modules\n_catatan_nna\views\list.php 15
ERROR - 2023-05-02 02:13:07 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\myraportk13\application\modules\n_catatan_nna\views\list.php 15
ERROR - 2023-05-02 02:13:07 --> Severity: Notice --> Undefined variable: detil_mp C:\xampp\htdocs\myraportk13\application\modules\n_catatan_nna\views\list.php 15
ERROR - 2023-05-02 02:13:07 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\myraportk13\application\modules\n_catatan_nna\views\list.php 15
DEBUG - 2023-05-02 02:13:07 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/n_catatan_nna/views/list.php
DEBUG - 2023-05-02 02:13:07 --> File loaded: C:\xampp\htdocs\myraportk13\application\views\template_utama.php
INFO - 2023-05-02 02:13:07 --> Final output sent to browser
DEBUG - 2023-05-02 02:13:07 --> Total execution time: 0.0969
INFO - 2023-05-02 02:16:10 --> Config Class Initialized
INFO - 2023-05-02 02:16:10 --> Hooks Class Initialized
DEBUG - 2023-05-02 02:16:10 --> UTF-8 Support Enabled
INFO - 2023-05-02 02:16:10 --> Utf8 Class Initialized
INFO - 2023-05-02 02:16:10 --> URI Class Initialized
INFO - 2023-05-02 02:16:10 --> Router Class Initialized
INFO - 2023-05-02 02:16:10 --> Output Class Initialized
INFO - 2023-05-02 02:16:10 --> Security Class Initialized
DEBUG - 2023-05-02 02:16:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-02 02:16:10 --> Input Class Initialized
INFO - 2023-05-02 02:16:10 --> Language Class Initialized
INFO - 2023-05-02 02:16:10 --> Language Class Initialized
INFO - 2023-05-02 02:16:10 --> Config Class Initialized
INFO - 2023-05-02 02:16:10 --> Loader Class Initialized
INFO - 2023-05-02 02:16:10 --> Helper loaded: url_helper
INFO - 2023-05-02 02:16:10 --> Helper loaded: file_helper
INFO - 2023-05-02 02:16:10 --> Helper loaded: form_helper
INFO - 2023-05-02 02:16:10 --> Helper loaded: my_helper
INFO - 2023-05-02 02:16:10 --> Database Driver Class Initialized
DEBUG - 2023-05-02 02:16:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-05-02 02:16:10 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-02 02:16:10 --> Controller Class Initialized
DEBUG - 2023-05-02 02:16:10 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/n_catatan_nna/views/list.php
DEBUG - 2023-05-02 02:16:10 --> File loaded: C:\xampp\htdocs\myraportk13\application\views\template_utama.php
INFO - 2023-05-02 02:16:10 --> Final output sent to browser
DEBUG - 2023-05-02 02:16:10 --> Total execution time: 0.0687
INFO - 2023-05-02 02:16:29 --> Config Class Initialized
INFO - 2023-05-02 02:16:29 --> Hooks Class Initialized
DEBUG - 2023-05-02 02:16:29 --> UTF-8 Support Enabled
INFO - 2023-05-02 02:16:29 --> Utf8 Class Initialized
INFO - 2023-05-02 02:16:29 --> URI Class Initialized
INFO - 2023-05-02 02:16:29 --> Router Class Initialized
INFO - 2023-05-02 02:16:29 --> Output Class Initialized
INFO - 2023-05-02 02:16:29 --> Security Class Initialized
DEBUG - 2023-05-02 02:16:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-02 02:16:29 --> Input Class Initialized
INFO - 2023-05-02 02:16:29 --> Language Class Initialized
INFO - 2023-05-02 02:16:29 --> Language Class Initialized
INFO - 2023-05-02 02:16:29 --> Config Class Initialized
INFO - 2023-05-02 02:16:29 --> Loader Class Initialized
INFO - 2023-05-02 02:16:29 --> Helper loaded: url_helper
INFO - 2023-05-02 02:16:29 --> Helper loaded: file_helper
INFO - 2023-05-02 02:16:29 --> Helper loaded: form_helper
INFO - 2023-05-02 02:16:29 --> Helper loaded: my_helper
INFO - 2023-05-02 02:16:29 --> Database Driver Class Initialized
DEBUG - 2023-05-02 02:16:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-05-02 02:16:29 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-02 02:16:29 --> Controller Class Initialized
DEBUG - 2023-05-02 02:16:29 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/view_mapel/views/v_view_mapel.php
DEBUG - 2023-05-02 02:16:29 --> File loaded: C:\xampp\htdocs\myraportk13\application\views\template_utama.php
INFO - 2023-05-02 02:16:29 --> Final output sent to browser
DEBUG - 2023-05-02 02:16:29 --> Total execution time: 0.0436
INFO - 2023-05-02 02:16:30 --> Config Class Initialized
INFO - 2023-05-02 02:16:30 --> Hooks Class Initialized
DEBUG - 2023-05-02 02:16:30 --> UTF-8 Support Enabled
INFO - 2023-05-02 02:16:30 --> Utf8 Class Initialized
INFO - 2023-05-02 02:16:30 --> URI Class Initialized
INFO - 2023-05-02 02:16:30 --> Router Class Initialized
INFO - 2023-05-02 02:16:30 --> Output Class Initialized
INFO - 2023-05-02 02:16:30 --> Security Class Initialized
DEBUG - 2023-05-02 02:16:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-02 02:16:30 --> Input Class Initialized
INFO - 2023-05-02 02:16:30 --> Language Class Initialized
INFO - 2023-05-02 02:16:30 --> Language Class Initialized
INFO - 2023-05-02 02:16:30 --> Config Class Initialized
INFO - 2023-05-02 02:16:30 --> Loader Class Initialized
INFO - 2023-05-02 02:16:30 --> Helper loaded: url_helper
INFO - 2023-05-02 02:16:30 --> Helper loaded: file_helper
INFO - 2023-05-02 02:16:30 --> Helper loaded: form_helper
INFO - 2023-05-02 02:16:30 --> Helper loaded: my_helper
INFO - 2023-05-02 02:16:30 --> Database Driver Class Initialized
DEBUG - 2023-05-02 02:16:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-05-02 02:16:30 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-02 02:16:30 --> Controller Class Initialized
DEBUG - 2023-05-02 02:16:30 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/n_icb/views/list.php
DEBUG - 2023-05-02 02:16:30 --> File loaded: C:\xampp\htdocs\myraportk13\application\views\template_utama.php
INFO - 2023-05-02 02:16:30 --> Final output sent to browser
DEBUG - 2023-05-02 02:16:30 --> Total execution time: 0.0491
INFO - 2023-05-02 02:16:30 --> Config Class Initialized
INFO - 2023-05-02 02:16:30 --> Hooks Class Initialized
DEBUG - 2023-05-02 02:16:30 --> UTF-8 Support Enabled
INFO - 2023-05-02 02:16:30 --> Utf8 Class Initialized
INFO - 2023-05-02 02:16:30 --> URI Class Initialized
INFO - 2023-05-02 02:16:30 --> Router Class Initialized
INFO - 2023-05-02 02:16:30 --> Output Class Initialized
INFO - 2023-05-02 02:16:30 --> Security Class Initialized
DEBUG - 2023-05-02 02:16:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-02 02:16:30 --> Input Class Initialized
INFO - 2023-05-02 02:16:30 --> Language Class Initialized
INFO - 2023-05-02 02:16:30 --> Language Class Initialized
INFO - 2023-05-02 02:16:30 --> Config Class Initialized
INFO - 2023-05-02 02:16:30 --> Loader Class Initialized
INFO - 2023-05-02 02:16:30 --> Helper loaded: url_helper
INFO - 2023-05-02 02:16:30 --> Helper loaded: file_helper
INFO - 2023-05-02 02:16:30 --> Helper loaded: form_helper
INFO - 2023-05-02 02:16:30 --> Helper loaded: my_helper
INFO - 2023-05-02 02:16:30 --> Database Driver Class Initialized
DEBUG - 2023-05-02 02:16:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-05-02 02:16:30 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-02 02:16:30 --> Controller Class Initialized
INFO - 2023-05-02 02:16:32 --> Config Class Initialized
INFO - 2023-05-02 02:16:32 --> Hooks Class Initialized
DEBUG - 2023-05-02 02:16:32 --> UTF-8 Support Enabled
INFO - 2023-05-02 02:16:32 --> Utf8 Class Initialized
INFO - 2023-05-02 02:16:32 --> URI Class Initialized
INFO - 2023-05-02 02:16:32 --> Router Class Initialized
INFO - 2023-05-02 02:16:32 --> Output Class Initialized
INFO - 2023-05-02 02:16:32 --> Security Class Initialized
DEBUG - 2023-05-02 02:16:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-02 02:16:32 --> Input Class Initialized
INFO - 2023-05-02 02:16:32 --> Language Class Initialized
INFO - 2023-05-02 02:16:32 --> Language Class Initialized
INFO - 2023-05-02 02:16:32 --> Config Class Initialized
INFO - 2023-05-02 02:16:32 --> Loader Class Initialized
INFO - 2023-05-02 02:16:32 --> Helper loaded: url_helper
INFO - 2023-05-02 02:16:32 --> Helper loaded: file_helper
INFO - 2023-05-02 02:16:32 --> Helper loaded: form_helper
INFO - 2023-05-02 02:16:32 --> Helper loaded: my_helper
INFO - 2023-05-02 02:16:32 --> Database Driver Class Initialized
DEBUG - 2023-05-02 02:16:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-05-02 02:16:32 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-02 02:16:32 --> Controller Class Initialized
INFO - 2023-05-02 02:16:32 --> Helper loaded: cookie_helper
INFO - 2023-05-02 02:16:32 --> Config Class Initialized
INFO - 2023-05-02 02:16:32 --> Hooks Class Initialized
DEBUG - 2023-05-02 02:16:32 --> UTF-8 Support Enabled
INFO - 2023-05-02 02:16:32 --> Utf8 Class Initialized
INFO - 2023-05-02 02:16:32 --> URI Class Initialized
INFO - 2023-05-02 02:16:32 --> Router Class Initialized
INFO - 2023-05-02 02:16:32 --> Output Class Initialized
INFO - 2023-05-02 02:16:32 --> Security Class Initialized
DEBUG - 2023-05-02 02:16:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-02 02:16:32 --> Input Class Initialized
INFO - 2023-05-02 02:16:32 --> Language Class Initialized
INFO - 2023-05-02 02:16:32 --> Language Class Initialized
INFO - 2023-05-02 02:16:32 --> Config Class Initialized
INFO - 2023-05-02 02:16:32 --> Loader Class Initialized
INFO - 2023-05-02 02:16:32 --> Helper loaded: url_helper
INFO - 2023-05-02 02:16:32 --> Helper loaded: file_helper
INFO - 2023-05-02 02:16:32 --> Helper loaded: form_helper
INFO - 2023-05-02 02:16:32 --> Helper loaded: my_helper
INFO - 2023-05-02 02:16:32 --> Database Driver Class Initialized
DEBUG - 2023-05-02 02:16:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-05-02 02:16:32 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-02 02:16:32 --> Controller Class Initialized
INFO - 2023-05-02 02:16:33 --> Config Class Initialized
INFO - 2023-05-02 02:16:33 --> Hooks Class Initialized
DEBUG - 2023-05-02 02:16:33 --> UTF-8 Support Enabled
INFO - 2023-05-02 02:16:33 --> Utf8 Class Initialized
INFO - 2023-05-02 02:16:33 --> URI Class Initialized
INFO - 2023-05-02 02:16:33 --> Router Class Initialized
INFO - 2023-05-02 02:16:33 --> Output Class Initialized
INFO - 2023-05-02 02:16:33 --> Security Class Initialized
DEBUG - 2023-05-02 02:16:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-02 02:16:33 --> Input Class Initialized
INFO - 2023-05-02 02:16:33 --> Language Class Initialized
INFO - 2023-05-02 02:16:33 --> Language Class Initialized
INFO - 2023-05-02 02:16:33 --> Config Class Initialized
INFO - 2023-05-02 02:16:33 --> Loader Class Initialized
INFO - 2023-05-02 02:16:33 --> Helper loaded: url_helper
INFO - 2023-05-02 02:16:33 --> Helper loaded: file_helper
INFO - 2023-05-02 02:16:33 --> Helper loaded: form_helper
INFO - 2023-05-02 02:16:33 --> Helper loaded: my_helper
INFO - 2023-05-02 02:16:33 --> Database Driver Class Initialized
DEBUG - 2023-05-02 02:16:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-05-02 02:16:33 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-02 02:16:33 --> Controller Class Initialized
DEBUG - 2023-05-02 02:16:33 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/login/views/login.php
DEBUG - 2023-05-02 02:16:33 --> File loaded: C:\xampp\htdocs\myraportk13\application\views\template_utama.php
INFO - 2023-05-02 02:16:33 --> Final output sent to browser
DEBUG - 2023-05-02 02:16:33 --> Total execution time: 0.0506
INFO - 2023-05-02 02:16:46 --> Config Class Initialized
INFO - 2023-05-02 02:16:46 --> Hooks Class Initialized
DEBUG - 2023-05-02 02:16:46 --> UTF-8 Support Enabled
INFO - 2023-05-02 02:16:46 --> Utf8 Class Initialized
INFO - 2023-05-02 02:16:46 --> URI Class Initialized
INFO - 2023-05-02 02:16:46 --> Router Class Initialized
INFO - 2023-05-02 02:16:46 --> Output Class Initialized
INFO - 2023-05-02 02:16:46 --> Security Class Initialized
DEBUG - 2023-05-02 02:16:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-02 02:16:46 --> Input Class Initialized
INFO - 2023-05-02 02:16:46 --> Language Class Initialized
INFO - 2023-05-02 02:16:46 --> Language Class Initialized
INFO - 2023-05-02 02:16:46 --> Config Class Initialized
INFO - 2023-05-02 02:16:46 --> Loader Class Initialized
INFO - 2023-05-02 02:16:46 --> Helper loaded: url_helper
INFO - 2023-05-02 02:16:46 --> Helper loaded: file_helper
INFO - 2023-05-02 02:16:46 --> Helper loaded: form_helper
INFO - 2023-05-02 02:16:46 --> Helper loaded: my_helper
INFO - 2023-05-02 02:16:46 --> Database Driver Class Initialized
DEBUG - 2023-05-02 02:16:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-05-02 02:16:46 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-02 02:16:46 --> Controller Class Initialized
INFO - 2023-05-02 02:16:46 --> Helper loaded: cookie_helper
INFO - 2023-05-02 02:16:46 --> Final output sent to browser
DEBUG - 2023-05-02 02:16:46 --> Total execution time: 0.0651
INFO - 2023-05-02 02:16:46 --> Config Class Initialized
INFO - 2023-05-02 02:16:46 --> Hooks Class Initialized
DEBUG - 2023-05-02 02:16:46 --> UTF-8 Support Enabled
INFO - 2023-05-02 02:16:46 --> Utf8 Class Initialized
INFO - 2023-05-02 02:16:46 --> URI Class Initialized
INFO - 2023-05-02 02:16:46 --> Router Class Initialized
INFO - 2023-05-02 02:16:46 --> Output Class Initialized
INFO - 2023-05-02 02:16:46 --> Security Class Initialized
DEBUG - 2023-05-02 02:16:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-02 02:16:46 --> Input Class Initialized
INFO - 2023-05-02 02:16:46 --> Language Class Initialized
INFO - 2023-05-02 02:16:46 --> Language Class Initialized
INFO - 2023-05-02 02:16:46 --> Config Class Initialized
INFO - 2023-05-02 02:16:46 --> Loader Class Initialized
INFO - 2023-05-02 02:16:46 --> Helper loaded: url_helper
INFO - 2023-05-02 02:16:46 --> Helper loaded: file_helper
INFO - 2023-05-02 02:16:46 --> Helper loaded: form_helper
INFO - 2023-05-02 02:16:46 --> Helper loaded: my_helper
INFO - 2023-05-02 02:16:46 --> Database Driver Class Initialized
DEBUG - 2023-05-02 02:16:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-05-02 02:16:46 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-02 02:16:46 --> Controller Class Initialized
DEBUG - 2023-05-02 02:16:46 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/home/views/v_home_guru.php
DEBUG - 2023-05-02 02:16:46 --> File loaded: C:\xampp\htdocs\myraportk13\application\views\template_utama.php
INFO - 2023-05-02 02:16:46 --> Final output sent to browser
DEBUG - 2023-05-02 02:16:46 --> Total execution time: 0.0621
INFO - 2023-05-02 02:16:48 --> Config Class Initialized
INFO - 2023-05-02 02:16:48 --> Hooks Class Initialized
DEBUG - 2023-05-02 02:16:48 --> UTF-8 Support Enabled
INFO - 2023-05-02 02:16:48 --> Utf8 Class Initialized
INFO - 2023-05-02 02:16:48 --> URI Class Initialized
INFO - 2023-05-02 02:16:48 --> Router Class Initialized
INFO - 2023-05-02 02:16:48 --> Output Class Initialized
INFO - 2023-05-02 02:16:48 --> Security Class Initialized
DEBUG - 2023-05-02 02:16:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-02 02:16:48 --> Input Class Initialized
INFO - 2023-05-02 02:16:48 --> Language Class Initialized
INFO - 2023-05-02 02:16:48 --> Language Class Initialized
INFO - 2023-05-02 02:16:48 --> Config Class Initialized
INFO - 2023-05-02 02:16:48 --> Loader Class Initialized
INFO - 2023-05-02 02:16:48 --> Helper loaded: url_helper
INFO - 2023-05-02 02:16:48 --> Helper loaded: file_helper
INFO - 2023-05-02 02:16:48 --> Helper loaded: form_helper
INFO - 2023-05-02 02:16:48 --> Helper loaded: my_helper
INFO - 2023-05-02 02:16:48 --> Database Driver Class Initialized
DEBUG - 2023-05-02 02:16:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-05-02 02:16:48 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-02 02:16:48 --> Controller Class Initialized
DEBUG - 2023-05-02 02:16:48 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/view_mapel/views/v_view_mapel.php
DEBUG - 2023-05-02 02:16:48 --> File loaded: C:\xampp\htdocs\myraportk13\application\views\template_utama.php
INFO - 2023-05-02 02:16:48 --> Final output sent to browser
DEBUG - 2023-05-02 02:16:48 --> Total execution time: 0.0490
INFO - 2023-05-02 02:16:50 --> Config Class Initialized
INFO - 2023-05-02 02:16:50 --> Hooks Class Initialized
DEBUG - 2023-05-02 02:16:50 --> UTF-8 Support Enabled
INFO - 2023-05-02 02:16:50 --> Utf8 Class Initialized
INFO - 2023-05-02 02:16:50 --> URI Class Initialized
INFO - 2023-05-02 02:16:50 --> Router Class Initialized
INFO - 2023-05-02 02:16:50 --> Output Class Initialized
INFO - 2023-05-02 02:16:50 --> Security Class Initialized
DEBUG - 2023-05-02 02:16:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-02 02:16:50 --> Input Class Initialized
INFO - 2023-05-02 02:16:50 --> Language Class Initialized
INFO - 2023-05-02 02:16:50 --> Language Class Initialized
INFO - 2023-05-02 02:16:50 --> Config Class Initialized
INFO - 2023-05-02 02:16:50 --> Loader Class Initialized
INFO - 2023-05-02 02:16:50 --> Helper loaded: url_helper
INFO - 2023-05-02 02:16:50 --> Helper loaded: file_helper
INFO - 2023-05-02 02:16:50 --> Helper loaded: form_helper
INFO - 2023-05-02 02:16:50 --> Helper loaded: my_helper
INFO - 2023-05-02 02:16:50 --> Database Driver Class Initialized
DEBUG - 2023-05-02 02:16:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-05-02 02:16:50 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-02 02:16:50 --> Controller Class Initialized
DEBUG - 2023-05-02 02:16:50 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/n_catatan_guru/views/list.php
DEBUG - 2023-05-02 02:16:50 --> File loaded: C:\xampp\htdocs\myraportk13\application\views\template_utama.php
INFO - 2023-05-02 02:16:50 --> Final output sent to browser
DEBUG - 2023-05-02 02:16:50 --> Total execution time: 0.0617
INFO - 2023-05-02 02:16:53 --> Config Class Initialized
INFO - 2023-05-02 02:16:53 --> Hooks Class Initialized
DEBUG - 2023-05-02 02:16:53 --> UTF-8 Support Enabled
INFO - 2023-05-02 02:16:53 --> Utf8 Class Initialized
INFO - 2023-05-02 02:16:53 --> URI Class Initialized
INFO - 2023-05-02 02:16:53 --> Router Class Initialized
INFO - 2023-05-02 02:16:53 --> Output Class Initialized
INFO - 2023-05-02 02:16:53 --> Security Class Initialized
DEBUG - 2023-05-02 02:16:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-02 02:16:53 --> Input Class Initialized
INFO - 2023-05-02 02:16:53 --> Language Class Initialized
INFO - 2023-05-02 02:16:53 --> Language Class Initialized
INFO - 2023-05-02 02:16:53 --> Config Class Initialized
INFO - 2023-05-02 02:16:53 --> Loader Class Initialized
INFO - 2023-05-02 02:16:53 --> Helper loaded: url_helper
INFO - 2023-05-02 02:16:53 --> Helper loaded: file_helper
INFO - 2023-05-02 02:16:53 --> Helper loaded: form_helper
INFO - 2023-05-02 02:16:53 --> Helper loaded: my_helper
INFO - 2023-05-02 02:16:53 --> Database Driver Class Initialized
DEBUG - 2023-05-02 02:16:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-05-02 02:16:53 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-02 02:16:53 --> Controller Class Initialized
INFO - 2023-05-02 02:16:53 --> Final output sent to browser
DEBUG - 2023-05-02 02:16:53 --> Total execution time: 0.0635
INFO - 2023-05-02 04:30:26 --> Config Class Initialized
INFO - 2023-05-02 04:30:26 --> Hooks Class Initialized
DEBUG - 2023-05-02 04:30:26 --> UTF-8 Support Enabled
INFO - 2023-05-02 04:30:26 --> Utf8 Class Initialized
INFO - 2023-05-02 04:30:26 --> URI Class Initialized
INFO - 2023-05-02 04:30:26 --> Router Class Initialized
INFO - 2023-05-02 04:30:26 --> Output Class Initialized
INFO - 2023-05-02 04:30:26 --> Security Class Initialized
DEBUG - 2023-05-02 04:30:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-02 04:30:26 --> Input Class Initialized
INFO - 2023-05-02 04:30:26 --> Language Class Initialized
INFO - 2023-05-02 04:30:26 --> Language Class Initialized
INFO - 2023-05-02 04:30:26 --> Config Class Initialized
INFO - 2023-05-02 04:30:26 --> Loader Class Initialized
INFO - 2023-05-02 04:30:26 --> Helper loaded: url_helper
INFO - 2023-05-02 04:30:26 --> Helper loaded: file_helper
INFO - 2023-05-02 04:30:26 --> Helper loaded: form_helper
INFO - 2023-05-02 04:30:26 --> Helper loaded: my_helper
INFO - 2023-05-02 04:30:26 --> Database Driver Class Initialized
DEBUG - 2023-05-02 04:30:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-05-02 04:30:26 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-02 04:30:26 --> Controller Class Initialized
DEBUG - 2023-05-02 04:30:26 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/n_catatan_guru/views/list.php
DEBUG - 2023-05-02 04:30:26 --> File loaded: C:\xampp\htdocs\myraportk13\application\views\template_utama.php
INFO - 2023-05-02 04:30:26 --> Final output sent to browser
DEBUG - 2023-05-02 04:30:26 --> Total execution time: 0.1127
INFO - 2023-05-02 06:09:00 --> Config Class Initialized
INFO - 2023-05-02 06:09:00 --> Hooks Class Initialized
DEBUG - 2023-05-02 06:09:00 --> UTF-8 Support Enabled
INFO - 2023-05-02 06:09:00 --> Utf8 Class Initialized
INFO - 2023-05-02 06:09:00 --> URI Class Initialized
INFO - 2023-05-02 06:09:00 --> Router Class Initialized
INFO - 2023-05-02 06:09:00 --> Output Class Initialized
INFO - 2023-05-02 06:09:00 --> Security Class Initialized
DEBUG - 2023-05-02 06:09:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-02 06:09:00 --> Input Class Initialized
INFO - 2023-05-02 06:09:00 --> Language Class Initialized
INFO - 2023-05-02 06:09:00 --> Language Class Initialized
INFO - 2023-05-02 06:09:00 --> Config Class Initialized
INFO - 2023-05-02 06:09:00 --> Loader Class Initialized
INFO - 2023-05-02 06:09:00 --> Helper loaded: url_helper
INFO - 2023-05-02 06:09:00 --> Helper loaded: file_helper
INFO - 2023-05-02 06:09:00 --> Helper loaded: form_helper
INFO - 2023-05-02 06:09:00 --> Helper loaded: my_helper
INFO - 2023-05-02 06:09:00 --> Database Driver Class Initialized
DEBUG - 2023-05-02 06:09:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-05-02 06:09:00 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-02 06:09:00 --> Controller Class Initialized
DEBUG - 2023-05-02 06:09:01 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/n_catatan_guru/views/list.php
DEBUG - 2023-05-02 06:09:01 --> File loaded: C:\xampp\htdocs\myraportk13\application\views\template_utama.php
INFO - 2023-05-02 06:09:01 --> Final output sent to browser
DEBUG - 2023-05-02 06:09:01 --> Total execution time: 1.1869
INFO - 2023-05-02 06:09:04 --> Config Class Initialized
INFO - 2023-05-02 06:09:04 --> Hooks Class Initialized
DEBUG - 2023-05-02 06:09:04 --> UTF-8 Support Enabled
INFO - 2023-05-02 06:09:04 --> Utf8 Class Initialized
INFO - 2023-05-02 06:09:04 --> URI Class Initialized
INFO - 2023-05-02 06:09:04 --> Router Class Initialized
INFO - 2023-05-02 06:09:04 --> Output Class Initialized
INFO - 2023-05-02 06:09:04 --> Security Class Initialized
DEBUG - 2023-05-02 06:09:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-02 06:09:04 --> Input Class Initialized
INFO - 2023-05-02 06:09:04 --> Language Class Initialized
INFO - 2023-05-02 06:09:04 --> Language Class Initialized
INFO - 2023-05-02 06:09:04 --> Config Class Initialized
INFO - 2023-05-02 06:09:04 --> Loader Class Initialized
INFO - 2023-05-02 06:09:04 --> Helper loaded: url_helper
INFO - 2023-05-02 06:09:04 --> Helper loaded: file_helper
INFO - 2023-05-02 06:09:04 --> Helper loaded: form_helper
INFO - 2023-05-02 06:09:04 --> Helper loaded: my_helper
INFO - 2023-05-02 06:09:04 --> Database Driver Class Initialized
DEBUG - 2023-05-02 06:09:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-05-02 06:09:04 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-02 06:09:04 --> Controller Class Initialized
INFO - 2023-05-02 06:09:04 --> Final output sent to browser
DEBUG - 2023-05-02 06:09:04 --> Total execution time: 0.0547
INFO - 2023-05-02 06:09:05 --> Config Class Initialized
INFO - 2023-05-02 06:09:05 --> Hooks Class Initialized
DEBUG - 2023-05-02 06:09:05 --> UTF-8 Support Enabled
INFO - 2023-05-02 06:09:05 --> Utf8 Class Initialized
INFO - 2023-05-02 06:09:05 --> URI Class Initialized
INFO - 2023-05-02 06:09:05 --> Router Class Initialized
INFO - 2023-05-02 06:09:05 --> Output Class Initialized
INFO - 2023-05-02 06:09:05 --> Security Class Initialized
DEBUG - 2023-05-02 06:09:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-02 06:09:05 --> Input Class Initialized
INFO - 2023-05-02 06:09:05 --> Language Class Initialized
INFO - 2023-05-02 06:09:05 --> Language Class Initialized
INFO - 2023-05-02 06:09:05 --> Config Class Initialized
INFO - 2023-05-02 06:09:05 --> Loader Class Initialized
INFO - 2023-05-02 06:09:05 --> Helper loaded: url_helper
INFO - 2023-05-02 06:09:05 --> Helper loaded: file_helper
INFO - 2023-05-02 06:09:05 --> Helper loaded: form_helper
INFO - 2023-05-02 06:09:05 --> Helper loaded: my_helper
INFO - 2023-05-02 06:09:05 --> Database Driver Class Initialized
DEBUG - 2023-05-02 06:09:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-05-02 06:09:05 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-02 06:09:05 --> Controller Class Initialized
INFO - 2023-05-02 06:09:05 --> Final output sent to browser
DEBUG - 2023-05-02 06:09:05 --> Total execution time: 0.0702
INFO - 2023-05-02 06:09:06 --> Config Class Initialized
INFO - 2023-05-02 06:09:06 --> Hooks Class Initialized
DEBUG - 2023-05-02 06:09:06 --> UTF-8 Support Enabled
INFO - 2023-05-02 06:09:06 --> Utf8 Class Initialized
INFO - 2023-05-02 06:09:06 --> URI Class Initialized
DEBUG - 2023-05-02 06:09:06 --> No URI present. Default controller set.
INFO - 2023-05-02 06:09:06 --> Router Class Initialized
INFO - 2023-05-02 06:09:06 --> Output Class Initialized
INFO - 2023-05-02 06:09:06 --> Security Class Initialized
DEBUG - 2023-05-02 06:09:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-02 06:09:06 --> Input Class Initialized
INFO - 2023-05-02 06:09:06 --> Language Class Initialized
INFO - 2023-05-02 06:09:06 --> Language Class Initialized
INFO - 2023-05-02 06:09:06 --> Config Class Initialized
INFO - 2023-05-02 06:09:06 --> Loader Class Initialized
INFO - 2023-05-02 06:09:06 --> Helper loaded: url_helper
INFO - 2023-05-02 06:09:06 --> Helper loaded: file_helper
INFO - 2023-05-02 06:09:06 --> Helper loaded: form_helper
INFO - 2023-05-02 06:09:06 --> Helper loaded: my_helper
INFO - 2023-05-02 06:09:06 --> Database Driver Class Initialized
DEBUG - 2023-05-02 06:09:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-05-02 06:09:06 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-02 06:09:06 --> Controller Class Initialized
INFO - 2023-05-02 06:09:06 --> Config Class Initialized
INFO - 2023-05-02 06:09:06 --> Hooks Class Initialized
DEBUG - 2023-05-02 06:09:06 --> UTF-8 Support Enabled
INFO - 2023-05-02 06:09:06 --> Utf8 Class Initialized
INFO - 2023-05-02 06:09:06 --> URI Class Initialized
INFO - 2023-05-02 06:09:06 --> Router Class Initialized
INFO - 2023-05-02 06:09:06 --> Output Class Initialized
INFO - 2023-05-02 06:09:06 --> Security Class Initialized
DEBUG - 2023-05-02 06:09:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-02 06:09:06 --> Input Class Initialized
INFO - 2023-05-02 06:09:06 --> Language Class Initialized
INFO - 2023-05-02 06:09:06 --> Language Class Initialized
INFO - 2023-05-02 06:09:06 --> Config Class Initialized
INFO - 2023-05-02 06:09:06 --> Loader Class Initialized
INFO - 2023-05-02 06:09:06 --> Helper loaded: url_helper
INFO - 2023-05-02 06:09:06 --> Helper loaded: file_helper
INFO - 2023-05-02 06:09:06 --> Helper loaded: form_helper
INFO - 2023-05-02 06:09:06 --> Helper loaded: my_helper
INFO - 2023-05-02 06:09:06 --> Database Driver Class Initialized
DEBUG - 2023-05-02 06:09:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-05-02 06:09:06 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-02 06:09:06 --> Controller Class Initialized
DEBUG - 2023-05-02 06:09:06 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/login/views/login.php
DEBUG - 2023-05-02 06:09:06 --> File loaded: C:\xampp\htdocs\myraportk13\application\views\template_utama.php
INFO - 2023-05-02 06:09:06 --> Final output sent to browser
DEBUG - 2023-05-02 06:09:06 --> Total execution time: 0.1041
INFO - 2023-05-02 06:09:11 --> Config Class Initialized
INFO - 2023-05-02 06:09:11 --> Hooks Class Initialized
DEBUG - 2023-05-02 06:09:11 --> UTF-8 Support Enabled
INFO - 2023-05-02 06:09:11 --> Utf8 Class Initialized
INFO - 2023-05-02 06:09:11 --> URI Class Initialized
INFO - 2023-05-02 06:09:11 --> Router Class Initialized
INFO - 2023-05-02 06:09:11 --> Output Class Initialized
INFO - 2023-05-02 06:09:11 --> Security Class Initialized
DEBUG - 2023-05-02 06:09:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-02 06:09:11 --> Input Class Initialized
INFO - 2023-05-02 06:09:11 --> Language Class Initialized
INFO - 2023-05-02 06:09:11 --> Language Class Initialized
INFO - 2023-05-02 06:09:11 --> Config Class Initialized
INFO - 2023-05-02 06:09:11 --> Loader Class Initialized
INFO - 2023-05-02 06:09:11 --> Helper loaded: url_helper
INFO - 2023-05-02 06:09:11 --> Helper loaded: file_helper
INFO - 2023-05-02 06:09:11 --> Helper loaded: form_helper
INFO - 2023-05-02 06:09:11 --> Helper loaded: my_helper
INFO - 2023-05-02 06:09:11 --> Database Driver Class Initialized
DEBUG - 2023-05-02 06:09:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-05-02 06:09:11 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-02 06:09:11 --> Controller Class Initialized
INFO - 2023-05-02 06:09:12 --> Helper loaded: cookie_helper
INFO - 2023-05-02 06:09:12 --> Final output sent to browser
DEBUG - 2023-05-02 06:09:12 --> Total execution time: 0.0853
INFO - 2023-05-02 06:09:12 --> Config Class Initialized
INFO - 2023-05-02 06:09:12 --> Hooks Class Initialized
DEBUG - 2023-05-02 06:09:12 --> UTF-8 Support Enabled
INFO - 2023-05-02 06:09:12 --> Utf8 Class Initialized
INFO - 2023-05-02 06:09:12 --> URI Class Initialized
INFO - 2023-05-02 06:09:12 --> Router Class Initialized
INFO - 2023-05-02 06:09:12 --> Output Class Initialized
INFO - 2023-05-02 06:09:12 --> Security Class Initialized
DEBUG - 2023-05-02 06:09:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-02 06:09:12 --> Input Class Initialized
INFO - 2023-05-02 06:09:12 --> Language Class Initialized
INFO - 2023-05-02 06:09:12 --> Language Class Initialized
INFO - 2023-05-02 06:09:12 --> Config Class Initialized
INFO - 2023-05-02 06:09:12 --> Loader Class Initialized
INFO - 2023-05-02 06:09:12 --> Helper loaded: url_helper
INFO - 2023-05-02 06:09:12 --> Helper loaded: file_helper
INFO - 2023-05-02 06:09:12 --> Helper loaded: form_helper
INFO - 2023-05-02 06:09:12 --> Helper loaded: my_helper
INFO - 2023-05-02 06:09:12 --> Database Driver Class Initialized
DEBUG - 2023-05-02 06:09:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-05-02 06:09:12 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-02 06:09:12 --> Controller Class Initialized
DEBUG - 2023-05-02 06:09:12 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/home/views/v_home_guru.php
DEBUG - 2023-05-02 06:09:12 --> File loaded: C:\xampp\htdocs\myraportk13\application\views\template_utama.php
INFO - 2023-05-02 06:09:12 --> Final output sent to browser
DEBUG - 2023-05-02 06:09:12 --> Total execution time: 0.0767
INFO - 2023-05-02 06:09:15 --> Config Class Initialized
INFO - 2023-05-02 06:09:15 --> Hooks Class Initialized
DEBUG - 2023-05-02 06:09:15 --> UTF-8 Support Enabled
INFO - 2023-05-02 06:09:15 --> Utf8 Class Initialized
INFO - 2023-05-02 06:09:15 --> URI Class Initialized
INFO - 2023-05-02 06:09:15 --> Router Class Initialized
INFO - 2023-05-02 06:09:15 --> Output Class Initialized
INFO - 2023-05-02 06:09:15 --> Security Class Initialized
DEBUG - 2023-05-02 06:09:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-02 06:09:15 --> Input Class Initialized
INFO - 2023-05-02 06:09:15 --> Language Class Initialized
INFO - 2023-05-02 06:09:15 --> Language Class Initialized
INFO - 2023-05-02 06:09:15 --> Config Class Initialized
INFO - 2023-05-02 06:09:15 --> Loader Class Initialized
INFO - 2023-05-02 06:09:15 --> Helper loaded: url_helper
INFO - 2023-05-02 06:09:15 --> Helper loaded: file_helper
INFO - 2023-05-02 06:09:15 --> Helper loaded: form_helper
INFO - 2023-05-02 06:09:15 --> Helper loaded: my_helper
INFO - 2023-05-02 06:09:15 --> Database Driver Class Initialized
DEBUG - 2023-05-02 06:09:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-05-02 06:09:15 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-02 06:09:15 --> Controller Class Initialized
DEBUG - 2023-05-02 06:09:15 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/n_catatan_nna/views/list.php
DEBUG - 2023-05-02 06:09:15 --> File loaded: C:\xampp\htdocs\myraportk13\application\views\template_utama.php
INFO - 2023-05-02 06:09:15 --> Final output sent to browser
DEBUG - 2023-05-02 06:09:15 --> Total execution time: 0.1380
INFO - 2023-05-02 06:15:56 --> Config Class Initialized
INFO - 2023-05-02 06:15:56 --> Hooks Class Initialized
DEBUG - 2023-05-02 06:15:56 --> UTF-8 Support Enabled
INFO - 2023-05-02 06:15:56 --> Utf8 Class Initialized
INFO - 2023-05-02 06:15:56 --> URI Class Initialized
INFO - 2023-05-02 06:15:56 --> Router Class Initialized
INFO - 2023-05-02 06:15:56 --> Output Class Initialized
INFO - 2023-05-02 06:15:56 --> Security Class Initialized
DEBUG - 2023-05-02 06:15:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-02 06:15:56 --> Input Class Initialized
INFO - 2023-05-02 06:15:56 --> Language Class Initialized
INFO - 2023-05-02 06:15:56 --> Language Class Initialized
INFO - 2023-05-02 06:15:56 --> Config Class Initialized
INFO - 2023-05-02 06:15:56 --> Loader Class Initialized
INFO - 2023-05-02 06:15:56 --> Helper loaded: url_helper
INFO - 2023-05-02 06:15:56 --> Helper loaded: file_helper
INFO - 2023-05-02 06:15:56 --> Helper loaded: form_helper
INFO - 2023-05-02 06:15:56 --> Helper loaded: my_helper
INFO - 2023-05-02 06:15:56 --> Database Driver Class Initialized
DEBUG - 2023-05-02 06:15:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-05-02 06:15:56 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-02 06:15:56 --> Controller Class Initialized
DEBUG - 2023-05-02 06:15:56 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/n_catatan_nna/views/list.php
DEBUG - 2023-05-02 06:15:56 --> File loaded: C:\xampp\htdocs\myraportk13\application\views\template_utama.php
INFO - 2023-05-02 06:15:56 --> Final output sent to browser
DEBUG - 2023-05-02 06:15:56 --> Total execution time: 0.0921
INFO - 2023-05-02 06:16:12 --> Config Class Initialized
INFO - 2023-05-02 06:16:12 --> Hooks Class Initialized
DEBUG - 2023-05-02 06:16:12 --> UTF-8 Support Enabled
INFO - 2023-05-02 06:16:12 --> Utf8 Class Initialized
INFO - 2023-05-02 06:16:12 --> URI Class Initialized
DEBUG - 2023-05-02 06:16:12 --> No URI present. Default controller set.
INFO - 2023-05-02 06:16:12 --> Router Class Initialized
INFO - 2023-05-02 06:16:12 --> Output Class Initialized
INFO - 2023-05-02 06:16:12 --> Security Class Initialized
DEBUG - 2023-05-02 06:16:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-02 06:16:12 --> Input Class Initialized
INFO - 2023-05-02 06:16:12 --> Language Class Initialized
INFO - 2023-05-02 06:16:12 --> Language Class Initialized
INFO - 2023-05-02 06:16:12 --> Config Class Initialized
INFO - 2023-05-02 06:16:12 --> Loader Class Initialized
INFO - 2023-05-02 06:16:12 --> Helper loaded: url_helper
INFO - 2023-05-02 06:16:12 --> Helper loaded: file_helper
INFO - 2023-05-02 06:16:12 --> Helper loaded: form_helper
INFO - 2023-05-02 06:16:12 --> Helper loaded: my_helper
INFO - 2023-05-02 06:16:12 --> Database Driver Class Initialized
DEBUG - 2023-05-02 06:16:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-05-02 06:16:12 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-02 06:16:12 --> Controller Class Initialized
DEBUG - 2023-05-02 06:16:12 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/home/views/v_home_guru.php
DEBUG - 2023-05-02 06:16:12 --> File loaded: C:\xampp\htdocs\myraportk13\application\views\template_utama.php
INFO - 2023-05-02 06:16:12 --> Final output sent to browser
DEBUG - 2023-05-02 06:16:12 --> Total execution time: 0.0484
INFO - 2023-05-02 06:16:13 --> Config Class Initialized
INFO - 2023-05-02 06:16:13 --> Hooks Class Initialized
DEBUG - 2023-05-02 06:16:13 --> UTF-8 Support Enabled
INFO - 2023-05-02 06:16:13 --> Utf8 Class Initialized
INFO - 2023-05-02 06:16:13 --> URI Class Initialized
INFO - 2023-05-02 06:16:13 --> Router Class Initialized
INFO - 2023-05-02 06:16:13 --> Output Class Initialized
INFO - 2023-05-02 06:16:13 --> Security Class Initialized
DEBUG - 2023-05-02 06:16:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-02 06:16:13 --> Input Class Initialized
INFO - 2023-05-02 06:16:13 --> Language Class Initialized
INFO - 2023-05-02 06:16:13 --> Language Class Initialized
INFO - 2023-05-02 06:16:13 --> Config Class Initialized
INFO - 2023-05-02 06:16:13 --> Loader Class Initialized
INFO - 2023-05-02 06:16:13 --> Helper loaded: url_helper
INFO - 2023-05-02 06:16:13 --> Helper loaded: file_helper
INFO - 2023-05-02 06:16:13 --> Helper loaded: form_helper
INFO - 2023-05-02 06:16:13 --> Helper loaded: my_helper
INFO - 2023-05-02 06:16:13 --> Database Driver Class Initialized
DEBUG - 2023-05-02 06:16:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-05-02 06:16:13 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-02 06:16:13 --> Controller Class Initialized
DEBUG - 2023-05-02 06:16:13 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/view_mapel/views/v_view_mapel.php
DEBUG - 2023-05-02 06:16:13 --> File loaded: C:\xampp\htdocs\myraportk13\application\views\template_utama.php
INFO - 2023-05-02 06:16:13 --> Final output sent to browser
DEBUG - 2023-05-02 06:16:13 --> Total execution time: 0.1263
INFO - 2023-05-02 06:16:14 --> Config Class Initialized
INFO - 2023-05-02 06:16:14 --> Hooks Class Initialized
DEBUG - 2023-05-02 06:16:14 --> UTF-8 Support Enabled
INFO - 2023-05-02 06:16:14 --> Utf8 Class Initialized
INFO - 2023-05-02 06:16:14 --> URI Class Initialized
INFO - 2023-05-02 06:16:14 --> Router Class Initialized
INFO - 2023-05-02 06:16:14 --> Output Class Initialized
INFO - 2023-05-02 06:16:14 --> Security Class Initialized
DEBUG - 2023-05-02 06:16:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-02 06:16:14 --> Input Class Initialized
INFO - 2023-05-02 06:16:14 --> Language Class Initialized
INFO - 2023-05-02 06:16:14 --> Language Class Initialized
INFO - 2023-05-02 06:16:14 --> Config Class Initialized
INFO - 2023-05-02 06:16:14 --> Loader Class Initialized
INFO - 2023-05-02 06:16:14 --> Helper loaded: url_helper
INFO - 2023-05-02 06:16:14 --> Helper loaded: file_helper
INFO - 2023-05-02 06:16:14 --> Helper loaded: form_helper
INFO - 2023-05-02 06:16:14 --> Helper loaded: my_helper
INFO - 2023-05-02 06:16:14 --> Database Driver Class Initialized
DEBUG - 2023-05-02 06:16:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-05-02 06:16:14 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-02 06:16:14 --> Controller Class Initialized
DEBUG - 2023-05-02 06:16:14 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/n_icb/views/list.php
DEBUG - 2023-05-02 06:16:14 --> File loaded: C:\xampp\htdocs\myraportk13\application\views\template_utama.php
INFO - 2023-05-02 06:16:14 --> Final output sent to browser
DEBUG - 2023-05-02 06:16:14 --> Total execution time: 0.0938
INFO - 2023-05-02 06:16:14 --> Config Class Initialized
INFO - 2023-05-02 06:16:14 --> Hooks Class Initialized
DEBUG - 2023-05-02 06:16:14 --> UTF-8 Support Enabled
INFO - 2023-05-02 06:16:14 --> Utf8 Class Initialized
INFO - 2023-05-02 06:16:14 --> URI Class Initialized
INFO - 2023-05-02 06:16:14 --> Router Class Initialized
INFO - 2023-05-02 06:16:14 --> Output Class Initialized
INFO - 2023-05-02 06:16:14 --> Security Class Initialized
DEBUG - 2023-05-02 06:16:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-02 06:16:14 --> Input Class Initialized
INFO - 2023-05-02 06:16:14 --> Language Class Initialized
INFO - 2023-05-02 06:16:14 --> Language Class Initialized
INFO - 2023-05-02 06:16:14 --> Config Class Initialized
INFO - 2023-05-02 06:16:14 --> Loader Class Initialized
INFO - 2023-05-02 06:16:14 --> Helper loaded: url_helper
INFO - 2023-05-02 06:16:14 --> Helper loaded: file_helper
INFO - 2023-05-02 06:16:14 --> Helper loaded: form_helper
INFO - 2023-05-02 06:16:14 --> Helper loaded: my_helper
INFO - 2023-05-02 06:16:14 --> Database Driver Class Initialized
DEBUG - 2023-05-02 06:16:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-05-02 06:16:14 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-02 06:16:14 --> Controller Class Initialized
INFO - 2023-05-02 06:16:18 --> Config Class Initialized
INFO - 2023-05-02 06:16:18 --> Hooks Class Initialized
DEBUG - 2023-05-02 06:16:18 --> UTF-8 Support Enabled
INFO - 2023-05-02 06:16:18 --> Utf8 Class Initialized
INFO - 2023-05-02 06:16:18 --> URI Class Initialized
INFO - 2023-05-02 06:16:18 --> Router Class Initialized
INFO - 2023-05-02 06:16:18 --> Output Class Initialized
INFO - 2023-05-02 06:16:18 --> Security Class Initialized
DEBUG - 2023-05-02 06:16:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-02 06:16:18 --> Input Class Initialized
INFO - 2023-05-02 06:16:18 --> Language Class Initialized
INFO - 2023-05-02 06:16:18 --> Language Class Initialized
INFO - 2023-05-02 06:16:18 --> Config Class Initialized
INFO - 2023-05-02 06:16:18 --> Loader Class Initialized
INFO - 2023-05-02 06:16:18 --> Helper loaded: url_helper
INFO - 2023-05-02 06:16:18 --> Helper loaded: file_helper
INFO - 2023-05-02 06:16:18 --> Helper loaded: form_helper
INFO - 2023-05-02 06:16:18 --> Helper loaded: my_helper
INFO - 2023-05-02 06:16:18 --> Database Driver Class Initialized
DEBUG - 2023-05-02 06:16:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-05-02 06:16:18 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-02 06:16:18 --> Controller Class Initialized
INFO - 2023-05-02 06:16:18 --> Helper loaded: cookie_helper
INFO - 2023-05-02 06:16:18 --> Config Class Initialized
INFO - 2023-05-02 06:16:18 --> Hooks Class Initialized
DEBUG - 2023-05-02 06:16:18 --> UTF-8 Support Enabled
INFO - 2023-05-02 06:16:18 --> Utf8 Class Initialized
INFO - 2023-05-02 06:16:18 --> URI Class Initialized
INFO - 2023-05-02 06:16:18 --> Router Class Initialized
INFO - 2023-05-02 06:16:18 --> Output Class Initialized
INFO - 2023-05-02 06:16:18 --> Security Class Initialized
DEBUG - 2023-05-02 06:16:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-02 06:16:18 --> Input Class Initialized
INFO - 2023-05-02 06:16:18 --> Language Class Initialized
INFO - 2023-05-02 06:16:18 --> Language Class Initialized
INFO - 2023-05-02 06:16:18 --> Config Class Initialized
INFO - 2023-05-02 06:16:18 --> Loader Class Initialized
INFO - 2023-05-02 06:16:18 --> Helper loaded: url_helper
INFO - 2023-05-02 06:16:18 --> Helper loaded: file_helper
INFO - 2023-05-02 06:16:18 --> Helper loaded: form_helper
INFO - 2023-05-02 06:16:18 --> Helper loaded: my_helper
INFO - 2023-05-02 06:16:18 --> Database Driver Class Initialized
DEBUG - 2023-05-02 06:16:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-05-02 06:16:18 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-02 06:16:18 --> Controller Class Initialized
INFO - 2023-05-02 06:16:18 --> Config Class Initialized
INFO - 2023-05-02 06:16:18 --> Hooks Class Initialized
DEBUG - 2023-05-02 06:16:18 --> UTF-8 Support Enabled
INFO - 2023-05-02 06:16:18 --> Utf8 Class Initialized
INFO - 2023-05-02 06:16:18 --> URI Class Initialized
INFO - 2023-05-02 06:16:18 --> Router Class Initialized
INFO - 2023-05-02 06:16:18 --> Output Class Initialized
INFO - 2023-05-02 06:16:18 --> Security Class Initialized
DEBUG - 2023-05-02 06:16:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-02 06:16:18 --> Input Class Initialized
INFO - 2023-05-02 06:16:18 --> Language Class Initialized
INFO - 2023-05-02 06:16:18 --> Language Class Initialized
INFO - 2023-05-02 06:16:18 --> Config Class Initialized
INFO - 2023-05-02 06:16:18 --> Loader Class Initialized
INFO - 2023-05-02 06:16:18 --> Helper loaded: url_helper
INFO - 2023-05-02 06:16:18 --> Helper loaded: file_helper
INFO - 2023-05-02 06:16:18 --> Helper loaded: form_helper
INFO - 2023-05-02 06:16:18 --> Helper loaded: my_helper
INFO - 2023-05-02 06:16:18 --> Database Driver Class Initialized
DEBUG - 2023-05-02 06:16:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-05-02 06:16:18 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-02 06:16:18 --> Controller Class Initialized
DEBUG - 2023-05-02 06:16:18 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/login/views/login.php
DEBUG - 2023-05-02 06:16:18 --> File loaded: C:\xampp\htdocs\myraportk13\application\views\template_utama.php
INFO - 2023-05-02 06:16:18 --> Final output sent to browser
DEBUG - 2023-05-02 06:16:18 --> Total execution time: 0.0368
INFO - 2023-05-02 06:16:22 --> Config Class Initialized
INFO - 2023-05-02 06:16:22 --> Hooks Class Initialized
DEBUG - 2023-05-02 06:16:22 --> UTF-8 Support Enabled
INFO - 2023-05-02 06:16:22 --> Utf8 Class Initialized
INFO - 2023-05-02 06:16:22 --> URI Class Initialized
INFO - 2023-05-02 06:16:22 --> Router Class Initialized
INFO - 2023-05-02 06:16:22 --> Output Class Initialized
INFO - 2023-05-02 06:16:22 --> Security Class Initialized
DEBUG - 2023-05-02 06:16:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-02 06:16:22 --> Input Class Initialized
INFO - 2023-05-02 06:16:22 --> Language Class Initialized
INFO - 2023-05-02 06:16:22 --> Language Class Initialized
INFO - 2023-05-02 06:16:22 --> Config Class Initialized
INFO - 2023-05-02 06:16:22 --> Loader Class Initialized
INFO - 2023-05-02 06:16:22 --> Helper loaded: url_helper
INFO - 2023-05-02 06:16:22 --> Helper loaded: file_helper
INFO - 2023-05-02 06:16:22 --> Helper loaded: form_helper
INFO - 2023-05-02 06:16:22 --> Helper loaded: my_helper
INFO - 2023-05-02 06:16:22 --> Database Driver Class Initialized
DEBUG - 2023-05-02 06:16:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-05-02 06:16:22 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-02 06:16:22 --> Controller Class Initialized
INFO - 2023-05-02 06:16:22 --> Helper loaded: cookie_helper
INFO - 2023-05-02 06:16:22 --> Final output sent to browser
DEBUG - 2023-05-02 06:16:22 --> Total execution time: 0.0454
INFO - 2023-05-02 06:16:22 --> Config Class Initialized
INFO - 2023-05-02 06:16:22 --> Hooks Class Initialized
DEBUG - 2023-05-02 06:16:22 --> UTF-8 Support Enabled
INFO - 2023-05-02 06:16:22 --> Utf8 Class Initialized
INFO - 2023-05-02 06:16:22 --> URI Class Initialized
INFO - 2023-05-02 06:16:22 --> Router Class Initialized
INFO - 2023-05-02 06:16:22 --> Output Class Initialized
INFO - 2023-05-02 06:16:22 --> Security Class Initialized
DEBUG - 2023-05-02 06:16:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-02 06:16:22 --> Input Class Initialized
INFO - 2023-05-02 06:16:22 --> Language Class Initialized
INFO - 2023-05-02 06:16:22 --> Language Class Initialized
INFO - 2023-05-02 06:16:22 --> Config Class Initialized
INFO - 2023-05-02 06:16:22 --> Loader Class Initialized
INFO - 2023-05-02 06:16:22 --> Helper loaded: url_helper
INFO - 2023-05-02 06:16:22 --> Helper loaded: file_helper
INFO - 2023-05-02 06:16:22 --> Helper loaded: form_helper
INFO - 2023-05-02 06:16:22 --> Helper loaded: my_helper
INFO - 2023-05-02 06:16:22 --> Database Driver Class Initialized
DEBUG - 2023-05-02 06:16:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-05-02 06:16:22 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-02 06:16:22 --> Controller Class Initialized
DEBUG - 2023-05-02 06:16:22 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/home/views/v_home_guru.php
DEBUG - 2023-05-02 06:16:22 --> File loaded: C:\xampp\htdocs\myraportk13\application\views\template_utama.php
INFO - 2023-05-02 06:16:22 --> Final output sent to browser
DEBUG - 2023-05-02 06:16:22 --> Total execution time: 0.0506
INFO - 2023-05-02 06:16:24 --> Config Class Initialized
INFO - 2023-05-02 06:16:24 --> Hooks Class Initialized
DEBUG - 2023-05-02 06:16:24 --> UTF-8 Support Enabled
INFO - 2023-05-02 06:16:24 --> Utf8 Class Initialized
INFO - 2023-05-02 06:16:24 --> URI Class Initialized
INFO - 2023-05-02 06:16:24 --> Router Class Initialized
INFO - 2023-05-02 06:16:24 --> Output Class Initialized
INFO - 2023-05-02 06:16:24 --> Security Class Initialized
DEBUG - 2023-05-02 06:16:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-02 06:16:24 --> Input Class Initialized
INFO - 2023-05-02 06:16:24 --> Language Class Initialized
INFO - 2023-05-02 06:16:24 --> Language Class Initialized
INFO - 2023-05-02 06:16:24 --> Config Class Initialized
INFO - 2023-05-02 06:16:24 --> Loader Class Initialized
INFO - 2023-05-02 06:16:24 --> Helper loaded: url_helper
INFO - 2023-05-02 06:16:24 --> Helper loaded: file_helper
INFO - 2023-05-02 06:16:24 --> Helper loaded: form_helper
INFO - 2023-05-02 06:16:24 --> Helper loaded: my_helper
INFO - 2023-05-02 06:16:24 --> Database Driver Class Initialized
DEBUG - 2023-05-02 06:16:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-05-02 06:16:24 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-02 06:16:24 --> Controller Class Initialized
DEBUG - 2023-05-02 06:16:24 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/view_mapel/views/v_view_mapel.php
DEBUG - 2023-05-02 06:16:24 --> File loaded: C:\xampp\htdocs\myraportk13\application\views\template_utama.php
INFO - 2023-05-02 06:16:24 --> Final output sent to browser
DEBUG - 2023-05-02 06:16:24 --> Total execution time: 0.0630
INFO - 2023-05-02 06:16:26 --> Config Class Initialized
INFO - 2023-05-02 06:16:26 --> Hooks Class Initialized
DEBUG - 2023-05-02 06:16:26 --> UTF-8 Support Enabled
INFO - 2023-05-02 06:16:26 --> Utf8 Class Initialized
INFO - 2023-05-02 06:16:26 --> URI Class Initialized
INFO - 2023-05-02 06:16:26 --> Router Class Initialized
INFO - 2023-05-02 06:16:26 --> Output Class Initialized
INFO - 2023-05-02 06:16:26 --> Security Class Initialized
DEBUG - 2023-05-02 06:16:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-02 06:16:26 --> Input Class Initialized
INFO - 2023-05-02 06:16:26 --> Language Class Initialized
INFO - 2023-05-02 06:16:26 --> Language Class Initialized
INFO - 2023-05-02 06:16:26 --> Config Class Initialized
INFO - 2023-05-02 06:16:26 --> Loader Class Initialized
INFO - 2023-05-02 06:16:26 --> Helper loaded: url_helper
INFO - 2023-05-02 06:16:26 --> Helper loaded: file_helper
INFO - 2023-05-02 06:16:26 --> Helper loaded: form_helper
INFO - 2023-05-02 06:16:26 --> Helper loaded: my_helper
INFO - 2023-05-02 06:16:26 --> Database Driver Class Initialized
DEBUG - 2023-05-02 06:16:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-05-02 06:16:26 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-02 06:16:26 --> Controller Class Initialized
DEBUG - 2023-05-02 06:16:26 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/n_catatan_guru/views/list.php
DEBUG - 2023-05-02 06:16:26 --> File loaded: C:\xampp\htdocs\myraportk13\application\views\template_utama.php
INFO - 2023-05-02 06:16:26 --> Final output sent to browser
DEBUG - 2023-05-02 06:16:26 --> Total execution time: 0.0472
INFO - 2023-05-02 06:16:30 --> Config Class Initialized
INFO - 2023-05-02 06:16:30 --> Hooks Class Initialized
DEBUG - 2023-05-02 06:16:30 --> UTF-8 Support Enabled
INFO - 2023-05-02 06:16:30 --> Utf8 Class Initialized
INFO - 2023-05-02 06:16:30 --> URI Class Initialized
INFO - 2023-05-02 06:16:30 --> Router Class Initialized
INFO - 2023-05-02 06:16:30 --> Output Class Initialized
INFO - 2023-05-02 06:16:30 --> Security Class Initialized
DEBUG - 2023-05-02 06:16:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-02 06:16:30 --> Input Class Initialized
INFO - 2023-05-02 06:16:30 --> Language Class Initialized
INFO - 2023-05-02 06:16:30 --> Language Class Initialized
INFO - 2023-05-02 06:16:30 --> Config Class Initialized
INFO - 2023-05-02 06:16:30 --> Loader Class Initialized
INFO - 2023-05-02 06:16:30 --> Helper loaded: url_helper
INFO - 2023-05-02 06:16:30 --> Helper loaded: file_helper
INFO - 2023-05-02 06:16:30 --> Helper loaded: form_helper
INFO - 2023-05-02 06:16:30 --> Helper loaded: my_helper
INFO - 2023-05-02 06:16:30 --> Database Driver Class Initialized
DEBUG - 2023-05-02 06:16:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-05-02 06:16:30 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-02 06:16:30 --> Controller Class Initialized
DEBUG - 2023-05-02 06:16:30 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/view_mapel/views/v_view_mapel.php
DEBUG - 2023-05-02 06:16:30 --> File loaded: C:\xampp\htdocs\myraportk13\application\views\template_utama.php
INFO - 2023-05-02 06:16:30 --> Final output sent to browser
DEBUG - 2023-05-02 06:16:30 --> Total execution time: 0.0486
INFO - 2023-05-02 06:16:32 --> Config Class Initialized
INFO - 2023-05-02 06:16:32 --> Hooks Class Initialized
DEBUG - 2023-05-02 06:16:32 --> UTF-8 Support Enabled
INFO - 2023-05-02 06:16:32 --> Utf8 Class Initialized
INFO - 2023-05-02 06:16:32 --> URI Class Initialized
INFO - 2023-05-02 06:16:32 --> Router Class Initialized
INFO - 2023-05-02 06:16:32 --> Output Class Initialized
INFO - 2023-05-02 06:16:32 --> Security Class Initialized
DEBUG - 2023-05-02 06:16:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-02 06:16:32 --> Input Class Initialized
INFO - 2023-05-02 06:16:32 --> Language Class Initialized
INFO - 2023-05-02 06:16:32 --> Language Class Initialized
INFO - 2023-05-02 06:16:32 --> Config Class Initialized
INFO - 2023-05-02 06:16:32 --> Loader Class Initialized
INFO - 2023-05-02 06:16:32 --> Helper loaded: url_helper
INFO - 2023-05-02 06:16:32 --> Helper loaded: file_helper
INFO - 2023-05-02 06:16:32 --> Helper loaded: form_helper
INFO - 2023-05-02 06:16:32 --> Helper loaded: my_helper
INFO - 2023-05-02 06:16:32 --> Database Driver Class Initialized
DEBUG - 2023-05-02 06:16:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-05-02 06:16:32 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-02 06:16:32 --> Controller Class Initialized
DEBUG - 2023-05-02 06:16:32 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/n_catatan_guru/views/list.php
DEBUG - 2023-05-02 06:16:32 --> File loaded: C:\xampp\htdocs\myraportk13\application\views\template_utama.php
INFO - 2023-05-02 06:16:32 --> Final output sent to browser
DEBUG - 2023-05-02 06:16:32 --> Total execution time: 0.0441
INFO - 2023-05-02 06:16:36 --> Config Class Initialized
INFO - 2023-05-02 06:16:36 --> Hooks Class Initialized
DEBUG - 2023-05-02 06:16:36 --> UTF-8 Support Enabled
INFO - 2023-05-02 06:16:36 --> Utf8 Class Initialized
INFO - 2023-05-02 06:16:36 --> URI Class Initialized
INFO - 2023-05-02 06:16:36 --> Router Class Initialized
INFO - 2023-05-02 06:16:36 --> Output Class Initialized
INFO - 2023-05-02 06:16:36 --> Security Class Initialized
DEBUG - 2023-05-02 06:16:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-02 06:16:36 --> Input Class Initialized
INFO - 2023-05-02 06:16:36 --> Language Class Initialized
INFO - 2023-05-02 06:16:36 --> Language Class Initialized
INFO - 2023-05-02 06:16:36 --> Config Class Initialized
INFO - 2023-05-02 06:16:36 --> Loader Class Initialized
INFO - 2023-05-02 06:16:36 --> Helper loaded: url_helper
INFO - 2023-05-02 06:16:36 --> Helper loaded: file_helper
INFO - 2023-05-02 06:16:36 --> Helper loaded: form_helper
INFO - 2023-05-02 06:16:36 --> Helper loaded: my_helper
INFO - 2023-05-02 06:16:36 --> Database Driver Class Initialized
DEBUG - 2023-05-02 06:16:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-05-02 06:16:36 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-02 06:16:36 --> Controller Class Initialized
DEBUG - 2023-05-02 06:16:36 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/view_mapel/views/v_view_mapel.php
DEBUG - 2023-05-02 06:16:36 --> File loaded: C:\xampp\htdocs\myraportk13\application\views\template_utama.php
INFO - 2023-05-02 06:16:36 --> Final output sent to browser
DEBUG - 2023-05-02 06:16:36 --> Total execution time: 0.0463
INFO - 2023-05-02 06:16:39 --> Config Class Initialized
INFO - 2023-05-02 06:16:39 --> Hooks Class Initialized
DEBUG - 2023-05-02 06:16:39 --> UTF-8 Support Enabled
INFO - 2023-05-02 06:16:39 --> Utf8 Class Initialized
INFO - 2023-05-02 06:16:39 --> URI Class Initialized
INFO - 2023-05-02 06:16:39 --> Router Class Initialized
INFO - 2023-05-02 06:16:39 --> Output Class Initialized
INFO - 2023-05-02 06:16:39 --> Security Class Initialized
DEBUG - 2023-05-02 06:16:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-02 06:16:39 --> Input Class Initialized
INFO - 2023-05-02 06:16:39 --> Language Class Initialized
INFO - 2023-05-02 06:16:39 --> Language Class Initialized
INFO - 2023-05-02 06:16:39 --> Config Class Initialized
INFO - 2023-05-02 06:16:39 --> Loader Class Initialized
INFO - 2023-05-02 06:16:39 --> Helper loaded: url_helper
INFO - 2023-05-02 06:16:39 --> Helper loaded: file_helper
INFO - 2023-05-02 06:16:39 --> Helper loaded: form_helper
INFO - 2023-05-02 06:16:39 --> Helper loaded: my_helper
INFO - 2023-05-02 06:16:39 --> Database Driver Class Initialized
DEBUG - 2023-05-02 06:16:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-05-02 06:16:39 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-02 06:16:39 --> Controller Class Initialized
DEBUG - 2023-05-02 06:16:39 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/n_catatan_guru/views/list.php
DEBUG - 2023-05-02 06:16:39 --> File loaded: C:\xampp\htdocs\myraportk13\application\views\template_utama.php
INFO - 2023-05-02 06:16:39 --> Final output sent to browser
DEBUG - 2023-05-02 06:16:39 --> Total execution time: 0.0440
INFO - 2023-05-02 06:16:41 --> Config Class Initialized
INFO - 2023-05-02 06:16:41 --> Hooks Class Initialized
DEBUG - 2023-05-02 06:16:41 --> UTF-8 Support Enabled
INFO - 2023-05-02 06:16:41 --> Utf8 Class Initialized
INFO - 2023-05-02 06:16:41 --> URI Class Initialized
INFO - 2023-05-02 06:16:41 --> Router Class Initialized
INFO - 2023-05-02 06:16:41 --> Output Class Initialized
INFO - 2023-05-02 06:16:41 --> Security Class Initialized
DEBUG - 2023-05-02 06:16:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-02 06:16:41 --> Input Class Initialized
INFO - 2023-05-02 06:16:41 --> Language Class Initialized
INFO - 2023-05-02 06:16:41 --> Language Class Initialized
INFO - 2023-05-02 06:16:41 --> Config Class Initialized
INFO - 2023-05-02 06:16:41 --> Loader Class Initialized
INFO - 2023-05-02 06:16:41 --> Helper loaded: url_helper
INFO - 2023-05-02 06:16:41 --> Helper loaded: file_helper
INFO - 2023-05-02 06:16:41 --> Helper loaded: form_helper
INFO - 2023-05-02 06:16:41 --> Helper loaded: my_helper
INFO - 2023-05-02 06:16:41 --> Database Driver Class Initialized
DEBUG - 2023-05-02 06:16:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-05-02 06:16:41 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-02 06:16:41 --> Controller Class Initialized
DEBUG - 2023-05-02 06:16:41 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/view_mapel/views/v_view_mapel.php
DEBUG - 2023-05-02 06:16:41 --> File loaded: C:\xampp\htdocs\myraportk13\application\views\template_utama.php
INFO - 2023-05-02 06:16:41 --> Final output sent to browser
DEBUG - 2023-05-02 06:16:41 --> Total execution time: 0.0533
INFO - 2023-05-02 06:16:44 --> Config Class Initialized
INFO - 2023-05-02 06:16:44 --> Hooks Class Initialized
DEBUG - 2023-05-02 06:16:44 --> UTF-8 Support Enabled
INFO - 2023-05-02 06:16:44 --> Utf8 Class Initialized
INFO - 2023-05-02 06:16:44 --> URI Class Initialized
INFO - 2023-05-02 06:16:44 --> Router Class Initialized
INFO - 2023-05-02 06:16:44 --> Output Class Initialized
INFO - 2023-05-02 06:16:44 --> Security Class Initialized
DEBUG - 2023-05-02 06:16:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-02 06:16:44 --> Input Class Initialized
INFO - 2023-05-02 06:16:44 --> Language Class Initialized
INFO - 2023-05-02 06:16:44 --> Language Class Initialized
INFO - 2023-05-02 06:16:44 --> Config Class Initialized
INFO - 2023-05-02 06:16:44 --> Loader Class Initialized
INFO - 2023-05-02 06:16:44 --> Helper loaded: url_helper
INFO - 2023-05-02 06:16:44 --> Helper loaded: file_helper
INFO - 2023-05-02 06:16:44 --> Helper loaded: form_helper
INFO - 2023-05-02 06:16:44 --> Helper loaded: my_helper
INFO - 2023-05-02 06:16:44 --> Database Driver Class Initialized
DEBUG - 2023-05-02 06:16:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-05-02 06:16:44 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-02 06:16:44 --> Controller Class Initialized
DEBUG - 2023-05-02 06:16:44 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/n_catatan_guru/views/list.php
DEBUG - 2023-05-02 06:16:44 --> File loaded: C:\xampp\htdocs\myraportk13\application\views\template_utama.php
INFO - 2023-05-02 06:16:44 --> Final output sent to browser
DEBUG - 2023-05-02 06:16:44 --> Total execution time: 0.0560
INFO - 2023-05-02 06:18:59 --> Config Class Initialized
INFO - 2023-05-02 06:18:59 --> Hooks Class Initialized
DEBUG - 2023-05-02 06:18:59 --> UTF-8 Support Enabled
INFO - 2023-05-02 06:18:59 --> Utf8 Class Initialized
INFO - 2023-05-02 06:18:59 --> URI Class Initialized
INFO - 2023-05-02 06:18:59 --> Router Class Initialized
INFO - 2023-05-02 06:18:59 --> Output Class Initialized
INFO - 2023-05-02 06:18:59 --> Security Class Initialized
DEBUG - 2023-05-02 06:18:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-02 06:18:59 --> Input Class Initialized
INFO - 2023-05-02 06:18:59 --> Language Class Initialized
INFO - 2023-05-02 06:18:59 --> Language Class Initialized
INFO - 2023-05-02 06:18:59 --> Config Class Initialized
INFO - 2023-05-02 06:18:59 --> Loader Class Initialized
INFO - 2023-05-02 06:18:59 --> Helper loaded: url_helper
INFO - 2023-05-02 06:18:59 --> Helper loaded: file_helper
INFO - 2023-05-02 06:18:59 --> Helper loaded: form_helper
INFO - 2023-05-02 06:18:59 --> Helper loaded: my_helper
INFO - 2023-05-02 06:18:59 --> Database Driver Class Initialized
DEBUG - 2023-05-02 06:18:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-05-02 06:18:59 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-02 06:18:59 --> Controller Class Initialized
DEBUG - 2023-05-02 06:18:59 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/view_mapel/views/v_view_mapel.php
DEBUG - 2023-05-02 06:18:59 --> File loaded: C:\xampp\htdocs\myraportk13\application\views\template_utama.php
INFO - 2023-05-02 06:18:59 --> Final output sent to browser
DEBUG - 2023-05-02 06:18:59 --> Total execution time: 0.0456
INFO - 2023-05-02 06:19:04 --> Config Class Initialized
INFO - 2023-05-02 06:19:04 --> Hooks Class Initialized
DEBUG - 2023-05-02 06:19:04 --> UTF-8 Support Enabled
INFO - 2023-05-02 06:19:04 --> Utf8 Class Initialized
INFO - 2023-05-02 06:19:04 --> URI Class Initialized
INFO - 2023-05-02 06:19:04 --> Router Class Initialized
INFO - 2023-05-02 06:19:04 --> Output Class Initialized
INFO - 2023-05-02 06:19:04 --> Security Class Initialized
DEBUG - 2023-05-02 06:19:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-02 06:19:04 --> Input Class Initialized
INFO - 2023-05-02 06:19:04 --> Language Class Initialized
INFO - 2023-05-02 06:19:04 --> Language Class Initialized
INFO - 2023-05-02 06:19:04 --> Config Class Initialized
INFO - 2023-05-02 06:19:04 --> Loader Class Initialized
INFO - 2023-05-02 06:19:04 --> Helper loaded: url_helper
INFO - 2023-05-02 06:19:04 --> Helper loaded: file_helper
INFO - 2023-05-02 06:19:04 --> Helper loaded: form_helper
INFO - 2023-05-02 06:19:04 --> Helper loaded: my_helper
INFO - 2023-05-02 06:19:04 --> Database Driver Class Initialized
DEBUG - 2023-05-02 06:19:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-05-02 06:19:04 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-02 06:19:04 --> Controller Class Initialized
DEBUG - 2023-05-02 06:19:04 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/n_catatan_guru/views/list.php
DEBUG - 2023-05-02 06:19:04 --> File loaded: C:\xampp\htdocs\myraportk13\application\views\template_utama.php
INFO - 2023-05-02 06:19:04 --> Final output sent to browser
DEBUG - 2023-05-02 06:19:04 --> Total execution time: 0.0535
INFO - 2023-05-02 06:19:09 --> Config Class Initialized
INFO - 2023-05-02 06:19:09 --> Hooks Class Initialized
DEBUG - 2023-05-02 06:19:09 --> UTF-8 Support Enabled
INFO - 2023-05-02 06:19:09 --> Utf8 Class Initialized
INFO - 2023-05-02 06:19:09 --> URI Class Initialized
INFO - 2023-05-02 06:19:09 --> Router Class Initialized
INFO - 2023-05-02 06:19:09 --> Output Class Initialized
INFO - 2023-05-02 06:19:09 --> Security Class Initialized
DEBUG - 2023-05-02 06:19:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-02 06:19:09 --> Input Class Initialized
INFO - 2023-05-02 06:19:09 --> Language Class Initialized
INFO - 2023-05-02 06:19:09 --> Language Class Initialized
INFO - 2023-05-02 06:19:09 --> Config Class Initialized
INFO - 2023-05-02 06:19:09 --> Loader Class Initialized
INFO - 2023-05-02 06:19:09 --> Helper loaded: url_helper
INFO - 2023-05-02 06:19:09 --> Helper loaded: file_helper
INFO - 2023-05-02 06:19:09 --> Helper loaded: form_helper
INFO - 2023-05-02 06:19:09 --> Helper loaded: my_helper
INFO - 2023-05-02 06:19:09 --> Database Driver Class Initialized
DEBUG - 2023-05-02 06:19:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-05-02 06:19:09 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-02 06:19:09 --> Controller Class Initialized
INFO - 2023-05-02 06:19:09 --> Final output sent to browser
DEBUG - 2023-05-02 06:19:09 --> Total execution time: 0.0471
INFO - 2023-05-02 06:19:14 --> Config Class Initialized
INFO - 2023-05-02 06:19:14 --> Hooks Class Initialized
DEBUG - 2023-05-02 06:19:14 --> UTF-8 Support Enabled
INFO - 2023-05-02 06:19:14 --> Utf8 Class Initialized
INFO - 2023-05-02 06:19:14 --> URI Class Initialized
INFO - 2023-05-02 06:19:14 --> Router Class Initialized
INFO - 2023-05-02 06:19:14 --> Output Class Initialized
INFO - 2023-05-02 06:19:14 --> Security Class Initialized
DEBUG - 2023-05-02 06:19:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-02 06:19:14 --> Input Class Initialized
INFO - 2023-05-02 06:19:14 --> Language Class Initialized
INFO - 2023-05-02 06:19:14 --> Language Class Initialized
INFO - 2023-05-02 06:19:14 --> Config Class Initialized
INFO - 2023-05-02 06:19:14 --> Loader Class Initialized
INFO - 2023-05-02 06:19:14 --> Helper loaded: url_helper
INFO - 2023-05-02 06:19:14 --> Helper loaded: file_helper
INFO - 2023-05-02 06:19:14 --> Helper loaded: form_helper
INFO - 2023-05-02 06:19:14 --> Helper loaded: my_helper
INFO - 2023-05-02 06:19:14 --> Database Driver Class Initialized
DEBUG - 2023-05-02 06:19:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-05-02 06:19:14 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-02 06:19:14 --> Controller Class Initialized
DEBUG - 2023-05-02 06:19:14 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/view_mapel/views/v_view_mapel.php
DEBUG - 2023-05-02 06:19:14 --> File loaded: C:\xampp\htdocs\myraportk13\application\views\template_utama.php
INFO - 2023-05-02 06:19:14 --> Final output sent to browser
DEBUG - 2023-05-02 06:19:14 --> Total execution time: 0.0586
INFO - 2023-05-02 06:19:17 --> Config Class Initialized
INFO - 2023-05-02 06:19:17 --> Hooks Class Initialized
DEBUG - 2023-05-02 06:19:17 --> UTF-8 Support Enabled
INFO - 2023-05-02 06:19:17 --> Utf8 Class Initialized
INFO - 2023-05-02 06:19:17 --> URI Class Initialized
INFO - 2023-05-02 06:19:17 --> Router Class Initialized
INFO - 2023-05-02 06:19:17 --> Output Class Initialized
INFO - 2023-05-02 06:19:17 --> Security Class Initialized
DEBUG - 2023-05-02 06:19:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-02 06:19:17 --> Input Class Initialized
INFO - 2023-05-02 06:19:17 --> Language Class Initialized
INFO - 2023-05-02 06:19:17 --> Language Class Initialized
INFO - 2023-05-02 06:19:17 --> Config Class Initialized
INFO - 2023-05-02 06:19:17 --> Loader Class Initialized
INFO - 2023-05-02 06:19:17 --> Helper loaded: url_helper
INFO - 2023-05-02 06:19:17 --> Helper loaded: file_helper
INFO - 2023-05-02 06:19:17 --> Helper loaded: form_helper
INFO - 2023-05-02 06:19:17 --> Helper loaded: my_helper
INFO - 2023-05-02 06:19:17 --> Database Driver Class Initialized
DEBUG - 2023-05-02 06:19:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-05-02 06:19:17 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-02 06:19:17 --> Controller Class Initialized
DEBUG - 2023-05-02 06:19:17 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/n_catatan_guru/views/list.php
DEBUG - 2023-05-02 06:19:17 --> File loaded: C:\xampp\htdocs\myraportk13\application\views\template_utama.php
INFO - 2023-05-02 06:19:17 --> Final output sent to browser
DEBUG - 2023-05-02 06:19:17 --> Total execution time: 0.0628
INFO - 2023-05-02 06:19:19 --> Config Class Initialized
INFO - 2023-05-02 06:19:19 --> Hooks Class Initialized
DEBUG - 2023-05-02 06:19:19 --> UTF-8 Support Enabled
INFO - 2023-05-02 06:19:19 --> Utf8 Class Initialized
INFO - 2023-05-02 06:19:19 --> URI Class Initialized
INFO - 2023-05-02 06:19:19 --> Router Class Initialized
INFO - 2023-05-02 06:19:19 --> Output Class Initialized
INFO - 2023-05-02 06:19:19 --> Security Class Initialized
DEBUG - 2023-05-02 06:19:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-02 06:19:19 --> Input Class Initialized
INFO - 2023-05-02 06:19:19 --> Language Class Initialized
INFO - 2023-05-02 06:19:19 --> Language Class Initialized
INFO - 2023-05-02 06:19:19 --> Config Class Initialized
INFO - 2023-05-02 06:19:19 --> Loader Class Initialized
INFO - 2023-05-02 06:19:19 --> Helper loaded: url_helper
INFO - 2023-05-02 06:19:19 --> Helper loaded: file_helper
INFO - 2023-05-02 06:19:19 --> Helper loaded: form_helper
INFO - 2023-05-02 06:19:19 --> Helper loaded: my_helper
INFO - 2023-05-02 06:19:19 --> Database Driver Class Initialized
DEBUG - 2023-05-02 06:19:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-05-02 06:19:19 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-02 06:19:19 --> Controller Class Initialized
INFO - 2023-05-02 06:19:19 --> Final output sent to browser
DEBUG - 2023-05-02 06:19:19 --> Total execution time: 0.0675
INFO - 2023-05-02 06:19:22 --> Config Class Initialized
INFO - 2023-05-02 06:19:22 --> Hooks Class Initialized
DEBUG - 2023-05-02 06:19:22 --> UTF-8 Support Enabled
INFO - 2023-05-02 06:19:22 --> Utf8 Class Initialized
INFO - 2023-05-02 06:19:22 --> URI Class Initialized
INFO - 2023-05-02 06:19:22 --> Router Class Initialized
INFO - 2023-05-02 06:19:22 --> Output Class Initialized
INFO - 2023-05-02 06:19:22 --> Security Class Initialized
DEBUG - 2023-05-02 06:19:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-02 06:19:22 --> Input Class Initialized
INFO - 2023-05-02 06:19:22 --> Language Class Initialized
INFO - 2023-05-02 06:19:22 --> Language Class Initialized
INFO - 2023-05-02 06:19:22 --> Config Class Initialized
INFO - 2023-05-02 06:19:22 --> Loader Class Initialized
INFO - 2023-05-02 06:19:22 --> Helper loaded: url_helper
INFO - 2023-05-02 06:19:22 --> Helper loaded: file_helper
INFO - 2023-05-02 06:19:22 --> Helper loaded: form_helper
INFO - 2023-05-02 06:19:22 --> Helper loaded: my_helper
INFO - 2023-05-02 06:19:22 --> Database Driver Class Initialized
DEBUG - 2023-05-02 06:19:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-05-02 06:19:22 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-02 06:19:22 --> Controller Class Initialized
DEBUG - 2023-05-02 06:19:22 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/view_mapel/views/v_view_mapel.php
DEBUG - 2023-05-02 06:19:22 --> File loaded: C:\xampp\htdocs\myraportk13\application\views\template_utama.php
INFO - 2023-05-02 06:19:22 --> Final output sent to browser
DEBUG - 2023-05-02 06:19:22 --> Total execution time: 0.0482
INFO - 2023-05-02 06:19:26 --> Config Class Initialized
INFO - 2023-05-02 06:19:26 --> Hooks Class Initialized
DEBUG - 2023-05-02 06:19:26 --> UTF-8 Support Enabled
INFO - 2023-05-02 06:19:26 --> Utf8 Class Initialized
INFO - 2023-05-02 06:19:26 --> URI Class Initialized
INFO - 2023-05-02 06:19:26 --> Router Class Initialized
INFO - 2023-05-02 06:19:26 --> Output Class Initialized
INFO - 2023-05-02 06:19:26 --> Security Class Initialized
DEBUG - 2023-05-02 06:19:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-02 06:19:26 --> Input Class Initialized
INFO - 2023-05-02 06:19:26 --> Language Class Initialized
INFO - 2023-05-02 06:19:26 --> Language Class Initialized
INFO - 2023-05-02 06:19:26 --> Config Class Initialized
INFO - 2023-05-02 06:19:26 --> Loader Class Initialized
INFO - 2023-05-02 06:19:26 --> Helper loaded: url_helper
INFO - 2023-05-02 06:19:26 --> Helper loaded: file_helper
INFO - 2023-05-02 06:19:26 --> Helper loaded: form_helper
INFO - 2023-05-02 06:19:26 --> Helper loaded: my_helper
INFO - 2023-05-02 06:19:26 --> Database Driver Class Initialized
DEBUG - 2023-05-02 06:19:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-05-02 06:19:26 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-02 06:19:26 --> Controller Class Initialized
DEBUG - 2023-05-02 06:19:26 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/n_catatan_guru/views/list.php
DEBUG - 2023-05-02 06:19:26 --> File loaded: C:\xampp\htdocs\myraportk13\application\views\template_utama.php
INFO - 2023-05-02 06:19:26 --> Final output sent to browser
DEBUG - 2023-05-02 06:19:26 --> Total execution time: 0.0413
INFO - 2023-05-02 06:19:27 --> Config Class Initialized
INFO - 2023-05-02 06:19:27 --> Hooks Class Initialized
DEBUG - 2023-05-02 06:19:27 --> UTF-8 Support Enabled
INFO - 2023-05-02 06:19:27 --> Utf8 Class Initialized
INFO - 2023-05-02 06:19:27 --> URI Class Initialized
INFO - 2023-05-02 06:19:27 --> Router Class Initialized
INFO - 2023-05-02 06:19:27 --> Output Class Initialized
INFO - 2023-05-02 06:19:27 --> Security Class Initialized
DEBUG - 2023-05-02 06:19:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-02 06:19:27 --> Input Class Initialized
INFO - 2023-05-02 06:19:27 --> Language Class Initialized
INFO - 2023-05-02 06:19:27 --> Language Class Initialized
INFO - 2023-05-02 06:19:27 --> Config Class Initialized
INFO - 2023-05-02 06:19:27 --> Loader Class Initialized
INFO - 2023-05-02 06:19:27 --> Helper loaded: url_helper
INFO - 2023-05-02 06:19:27 --> Helper loaded: file_helper
INFO - 2023-05-02 06:19:27 --> Helper loaded: form_helper
INFO - 2023-05-02 06:19:27 --> Helper loaded: my_helper
INFO - 2023-05-02 06:19:27 --> Database Driver Class Initialized
DEBUG - 2023-05-02 06:19:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-05-02 06:19:27 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-02 06:19:27 --> Controller Class Initialized
INFO - 2023-05-02 06:19:27 --> Final output sent to browser
DEBUG - 2023-05-02 06:19:27 --> Total execution time: 0.0457
INFO - 2023-05-02 06:19:31 --> Config Class Initialized
INFO - 2023-05-02 06:19:31 --> Hooks Class Initialized
DEBUG - 2023-05-02 06:19:31 --> UTF-8 Support Enabled
INFO - 2023-05-02 06:19:31 --> Utf8 Class Initialized
INFO - 2023-05-02 06:19:31 --> URI Class Initialized
INFO - 2023-05-02 06:19:31 --> Router Class Initialized
INFO - 2023-05-02 06:19:31 --> Output Class Initialized
INFO - 2023-05-02 06:19:31 --> Security Class Initialized
DEBUG - 2023-05-02 06:19:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-02 06:19:31 --> Input Class Initialized
INFO - 2023-05-02 06:19:31 --> Language Class Initialized
INFO - 2023-05-02 06:19:31 --> Language Class Initialized
INFO - 2023-05-02 06:19:31 --> Config Class Initialized
INFO - 2023-05-02 06:19:31 --> Loader Class Initialized
INFO - 2023-05-02 06:19:31 --> Helper loaded: url_helper
INFO - 2023-05-02 06:19:31 --> Helper loaded: file_helper
INFO - 2023-05-02 06:19:31 --> Helper loaded: form_helper
INFO - 2023-05-02 06:19:31 --> Helper loaded: my_helper
INFO - 2023-05-02 06:19:31 --> Database Driver Class Initialized
DEBUG - 2023-05-02 06:19:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-05-02 06:19:31 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-02 06:19:31 --> Controller Class Initialized
INFO - 2023-05-02 06:19:31 --> Final output sent to browser
DEBUG - 2023-05-02 06:19:31 --> Total execution time: 0.0478
INFO - 2023-05-02 06:19:33 --> Config Class Initialized
INFO - 2023-05-02 06:19:33 --> Hooks Class Initialized
DEBUG - 2023-05-02 06:19:33 --> UTF-8 Support Enabled
INFO - 2023-05-02 06:19:33 --> Utf8 Class Initialized
INFO - 2023-05-02 06:19:33 --> URI Class Initialized
INFO - 2023-05-02 06:19:33 --> Router Class Initialized
INFO - 2023-05-02 06:19:33 --> Output Class Initialized
INFO - 2023-05-02 06:19:33 --> Security Class Initialized
DEBUG - 2023-05-02 06:19:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-02 06:19:33 --> Input Class Initialized
INFO - 2023-05-02 06:19:33 --> Language Class Initialized
INFO - 2023-05-02 06:19:33 --> Language Class Initialized
INFO - 2023-05-02 06:19:33 --> Config Class Initialized
INFO - 2023-05-02 06:19:33 --> Loader Class Initialized
INFO - 2023-05-02 06:19:33 --> Helper loaded: url_helper
INFO - 2023-05-02 06:19:33 --> Helper loaded: file_helper
INFO - 2023-05-02 06:19:33 --> Helper loaded: form_helper
INFO - 2023-05-02 06:19:33 --> Helper loaded: my_helper
INFO - 2023-05-02 06:19:33 --> Database Driver Class Initialized
DEBUG - 2023-05-02 06:19:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-05-02 06:19:33 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-02 06:19:33 --> Controller Class Initialized
DEBUG - 2023-05-02 06:19:33 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/view_mapel/views/v_view_mapel.php
DEBUG - 2023-05-02 06:19:33 --> File loaded: C:\xampp\htdocs\myraportk13\application\views\template_utama.php
INFO - 2023-05-02 06:19:33 --> Final output sent to browser
DEBUG - 2023-05-02 06:19:33 --> Total execution time: 0.0470
INFO - 2023-05-02 06:19:34 --> Config Class Initialized
INFO - 2023-05-02 06:19:34 --> Hooks Class Initialized
DEBUG - 2023-05-02 06:19:34 --> UTF-8 Support Enabled
INFO - 2023-05-02 06:19:34 --> Utf8 Class Initialized
INFO - 2023-05-02 06:19:34 --> URI Class Initialized
INFO - 2023-05-02 06:19:34 --> Router Class Initialized
INFO - 2023-05-02 06:19:34 --> Output Class Initialized
INFO - 2023-05-02 06:19:34 --> Security Class Initialized
DEBUG - 2023-05-02 06:19:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-02 06:19:34 --> Input Class Initialized
INFO - 2023-05-02 06:19:34 --> Language Class Initialized
INFO - 2023-05-02 06:19:34 --> Language Class Initialized
INFO - 2023-05-02 06:19:34 --> Config Class Initialized
INFO - 2023-05-02 06:19:34 --> Loader Class Initialized
INFO - 2023-05-02 06:19:34 --> Helper loaded: url_helper
INFO - 2023-05-02 06:19:34 --> Helper loaded: file_helper
INFO - 2023-05-02 06:19:34 --> Helper loaded: form_helper
INFO - 2023-05-02 06:19:34 --> Helper loaded: my_helper
INFO - 2023-05-02 06:19:34 --> Database Driver Class Initialized
DEBUG - 2023-05-02 06:19:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-05-02 06:19:34 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-02 06:19:34 --> Controller Class Initialized
DEBUG - 2023-05-02 06:19:34 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/n_catatan_guru/views/list.php
DEBUG - 2023-05-02 06:19:34 --> File loaded: C:\xampp\htdocs\myraportk13\application\views\template_utama.php
INFO - 2023-05-02 06:19:34 --> Final output sent to browser
DEBUG - 2023-05-02 06:19:34 --> Total execution time: 0.0491
INFO - 2023-05-02 06:19:35 --> Config Class Initialized
INFO - 2023-05-02 06:19:35 --> Hooks Class Initialized
DEBUG - 2023-05-02 06:19:35 --> UTF-8 Support Enabled
INFO - 2023-05-02 06:19:35 --> Utf8 Class Initialized
INFO - 2023-05-02 06:19:35 --> URI Class Initialized
INFO - 2023-05-02 06:19:35 --> Router Class Initialized
INFO - 2023-05-02 06:19:35 --> Output Class Initialized
INFO - 2023-05-02 06:19:35 --> Security Class Initialized
DEBUG - 2023-05-02 06:19:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-02 06:19:35 --> Input Class Initialized
INFO - 2023-05-02 06:19:35 --> Language Class Initialized
INFO - 2023-05-02 06:19:35 --> Language Class Initialized
INFO - 2023-05-02 06:19:35 --> Config Class Initialized
INFO - 2023-05-02 06:19:35 --> Loader Class Initialized
INFO - 2023-05-02 06:19:35 --> Helper loaded: url_helper
INFO - 2023-05-02 06:19:35 --> Helper loaded: file_helper
INFO - 2023-05-02 06:19:35 --> Helper loaded: form_helper
INFO - 2023-05-02 06:19:35 --> Helper loaded: my_helper
INFO - 2023-05-02 06:19:35 --> Database Driver Class Initialized
DEBUG - 2023-05-02 06:19:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-05-02 06:19:35 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-02 06:19:35 --> Controller Class Initialized
INFO - 2023-05-02 06:19:35 --> Final output sent to browser
DEBUG - 2023-05-02 06:19:35 --> Total execution time: 0.0563
INFO - 2023-05-02 06:19:38 --> Config Class Initialized
INFO - 2023-05-02 06:19:38 --> Hooks Class Initialized
DEBUG - 2023-05-02 06:19:38 --> UTF-8 Support Enabled
INFO - 2023-05-02 06:19:38 --> Utf8 Class Initialized
INFO - 2023-05-02 06:19:38 --> URI Class Initialized
INFO - 2023-05-02 06:19:38 --> Router Class Initialized
INFO - 2023-05-02 06:19:38 --> Output Class Initialized
INFO - 2023-05-02 06:19:38 --> Security Class Initialized
DEBUG - 2023-05-02 06:19:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-02 06:19:38 --> Input Class Initialized
INFO - 2023-05-02 06:19:38 --> Language Class Initialized
INFO - 2023-05-02 06:19:38 --> Language Class Initialized
INFO - 2023-05-02 06:19:38 --> Config Class Initialized
INFO - 2023-05-02 06:19:38 --> Loader Class Initialized
INFO - 2023-05-02 06:19:38 --> Helper loaded: url_helper
INFO - 2023-05-02 06:19:38 --> Helper loaded: file_helper
INFO - 2023-05-02 06:19:38 --> Helper loaded: form_helper
INFO - 2023-05-02 06:19:38 --> Helper loaded: my_helper
INFO - 2023-05-02 06:19:38 --> Database Driver Class Initialized
DEBUG - 2023-05-02 06:19:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-05-02 06:19:38 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-02 06:19:38 --> Controller Class Initialized
INFO - 2023-05-02 06:19:49 --> Config Class Initialized
INFO - 2023-05-02 06:19:49 --> Hooks Class Initialized
DEBUG - 2023-05-02 06:19:49 --> UTF-8 Support Enabled
INFO - 2023-05-02 06:19:49 --> Utf8 Class Initialized
INFO - 2023-05-02 06:19:49 --> URI Class Initialized
INFO - 2023-05-02 06:19:49 --> Router Class Initialized
INFO - 2023-05-02 06:19:49 --> Output Class Initialized
INFO - 2023-05-02 06:19:49 --> Security Class Initialized
DEBUG - 2023-05-02 06:19:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-02 06:19:49 --> Input Class Initialized
INFO - 2023-05-02 06:19:49 --> Language Class Initialized
INFO - 2023-05-02 06:19:49 --> Language Class Initialized
INFO - 2023-05-02 06:19:49 --> Config Class Initialized
INFO - 2023-05-02 06:19:49 --> Loader Class Initialized
INFO - 2023-05-02 06:19:49 --> Helper loaded: url_helper
INFO - 2023-05-02 06:19:49 --> Helper loaded: file_helper
INFO - 2023-05-02 06:19:49 --> Helper loaded: form_helper
INFO - 2023-05-02 06:19:49 --> Helper loaded: my_helper
INFO - 2023-05-02 06:19:49 --> Database Driver Class Initialized
DEBUG - 2023-05-02 06:19:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-05-02 06:19:49 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-02 06:19:49 --> Controller Class Initialized
DEBUG - 2023-05-02 06:19:49 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/view_mapel/views/v_view_mapel.php
DEBUG - 2023-05-02 06:19:49 --> File loaded: C:\xampp\htdocs\myraportk13\application\views\template_utama.php
INFO - 2023-05-02 06:19:49 --> Final output sent to browser
DEBUG - 2023-05-02 06:19:49 --> Total execution time: 0.0573
INFO - 2023-05-02 06:19:58 --> Config Class Initialized
INFO - 2023-05-02 06:19:58 --> Hooks Class Initialized
DEBUG - 2023-05-02 06:19:58 --> UTF-8 Support Enabled
INFO - 2023-05-02 06:19:58 --> Utf8 Class Initialized
INFO - 2023-05-02 06:19:58 --> URI Class Initialized
INFO - 2023-05-02 06:19:58 --> Router Class Initialized
INFO - 2023-05-02 06:19:58 --> Output Class Initialized
INFO - 2023-05-02 06:19:58 --> Security Class Initialized
DEBUG - 2023-05-02 06:19:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-02 06:19:58 --> Input Class Initialized
INFO - 2023-05-02 06:19:58 --> Language Class Initialized
INFO - 2023-05-02 06:19:58 --> Language Class Initialized
INFO - 2023-05-02 06:19:58 --> Config Class Initialized
INFO - 2023-05-02 06:19:58 --> Loader Class Initialized
INFO - 2023-05-02 06:19:58 --> Helper loaded: url_helper
INFO - 2023-05-02 06:19:58 --> Helper loaded: file_helper
INFO - 2023-05-02 06:19:58 --> Helper loaded: form_helper
INFO - 2023-05-02 06:19:58 --> Helper loaded: my_helper
INFO - 2023-05-02 06:19:58 --> Database Driver Class Initialized
DEBUG - 2023-05-02 06:19:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-05-02 06:19:58 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-02 06:19:58 --> Controller Class Initialized
DEBUG - 2023-05-02 06:19:58 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/n_catatan_guru/views/list.php
DEBUG - 2023-05-02 06:19:58 --> File loaded: C:\xampp\htdocs\myraportk13\application\views\template_utama.php
INFO - 2023-05-02 06:19:58 --> Final output sent to browser
DEBUG - 2023-05-02 06:19:58 --> Total execution time: 0.0599
INFO - 2023-05-02 06:20:11 --> Config Class Initialized
INFO - 2023-05-02 06:20:11 --> Hooks Class Initialized
DEBUG - 2023-05-02 06:20:11 --> UTF-8 Support Enabled
INFO - 2023-05-02 06:20:11 --> Utf8 Class Initialized
INFO - 2023-05-02 06:20:11 --> URI Class Initialized
INFO - 2023-05-02 06:20:11 --> Router Class Initialized
INFO - 2023-05-02 06:20:11 --> Output Class Initialized
INFO - 2023-05-02 06:20:11 --> Security Class Initialized
DEBUG - 2023-05-02 06:20:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-02 06:20:11 --> Input Class Initialized
INFO - 2023-05-02 06:20:11 --> Language Class Initialized
INFO - 2023-05-02 06:20:11 --> Language Class Initialized
INFO - 2023-05-02 06:20:11 --> Config Class Initialized
INFO - 2023-05-02 06:20:11 --> Loader Class Initialized
INFO - 2023-05-02 06:20:11 --> Helper loaded: url_helper
INFO - 2023-05-02 06:20:11 --> Helper loaded: file_helper
INFO - 2023-05-02 06:20:11 --> Helper loaded: form_helper
INFO - 2023-05-02 06:20:11 --> Helper loaded: my_helper
INFO - 2023-05-02 06:20:11 --> Database Driver Class Initialized
DEBUG - 2023-05-02 06:20:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-05-02 06:20:11 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-02 06:20:11 --> Controller Class Initialized
DEBUG - 2023-05-02 06:20:11 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/view_mapel/views/v_view_mapel.php
DEBUG - 2023-05-02 06:20:11 --> File loaded: C:\xampp\htdocs\myraportk13\application\views\template_utama.php
INFO - 2023-05-02 06:20:11 --> Final output sent to browser
DEBUG - 2023-05-02 06:20:11 --> Total execution time: 0.0498
INFO - 2023-05-02 06:20:14 --> Config Class Initialized
INFO - 2023-05-02 06:20:14 --> Hooks Class Initialized
DEBUG - 2023-05-02 06:20:14 --> UTF-8 Support Enabled
INFO - 2023-05-02 06:20:14 --> Utf8 Class Initialized
INFO - 2023-05-02 06:20:14 --> URI Class Initialized
INFO - 2023-05-02 06:20:14 --> Router Class Initialized
INFO - 2023-05-02 06:20:14 --> Output Class Initialized
INFO - 2023-05-02 06:20:14 --> Security Class Initialized
DEBUG - 2023-05-02 06:20:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-02 06:20:14 --> Input Class Initialized
INFO - 2023-05-02 06:20:14 --> Language Class Initialized
INFO - 2023-05-02 06:20:14 --> Language Class Initialized
INFO - 2023-05-02 06:20:14 --> Config Class Initialized
INFO - 2023-05-02 06:20:14 --> Loader Class Initialized
INFO - 2023-05-02 06:20:14 --> Helper loaded: url_helper
INFO - 2023-05-02 06:20:14 --> Helper loaded: file_helper
INFO - 2023-05-02 06:20:14 --> Helper loaded: form_helper
INFO - 2023-05-02 06:20:14 --> Helper loaded: my_helper
INFO - 2023-05-02 06:20:14 --> Database Driver Class Initialized
DEBUG - 2023-05-02 06:20:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-05-02 06:20:14 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-02 06:20:14 --> Controller Class Initialized
DEBUG - 2023-05-02 06:20:14 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/n_catatan_guru/views/list.php
DEBUG - 2023-05-02 06:20:14 --> File loaded: C:\xampp\htdocs\myraportk13\application\views\template_utama.php
INFO - 2023-05-02 06:20:14 --> Final output sent to browser
DEBUG - 2023-05-02 06:20:14 --> Total execution time: 0.0462
INFO - 2023-05-02 06:20:17 --> Config Class Initialized
INFO - 2023-05-02 06:20:17 --> Hooks Class Initialized
DEBUG - 2023-05-02 06:20:17 --> UTF-8 Support Enabled
INFO - 2023-05-02 06:20:17 --> Utf8 Class Initialized
INFO - 2023-05-02 06:20:17 --> URI Class Initialized
INFO - 2023-05-02 06:20:17 --> Router Class Initialized
INFO - 2023-05-02 06:20:17 --> Output Class Initialized
INFO - 2023-05-02 06:20:17 --> Security Class Initialized
DEBUG - 2023-05-02 06:20:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-02 06:20:17 --> Input Class Initialized
INFO - 2023-05-02 06:20:17 --> Language Class Initialized
INFO - 2023-05-02 06:20:17 --> Language Class Initialized
INFO - 2023-05-02 06:20:17 --> Config Class Initialized
INFO - 2023-05-02 06:20:17 --> Loader Class Initialized
INFO - 2023-05-02 06:20:17 --> Helper loaded: url_helper
INFO - 2023-05-02 06:20:17 --> Helper loaded: file_helper
INFO - 2023-05-02 06:20:17 --> Helper loaded: form_helper
INFO - 2023-05-02 06:20:17 --> Helper loaded: my_helper
INFO - 2023-05-02 06:20:17 --> Database Driver Class Initialized
DEBUG - 2023-05-02 06:20:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-05-02 06:20:17 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-02 06:20:17 --> Controller Class Initialized
DEBUG - 2023-05-02 06:20:17 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/view_mapel/views/v_view_mapel.php
DEBUG - 2023-05-02 06:20:17 --> File loaded: C:\xampp\htdocs\myraportk13\application\views\template_utama.php
INFO - 2023-05-02 06:20:17 --> Final output sent to browser
DEBUG - 2023-05-02 06:20:17 --> Total execution time: 0.0467
INFO - 2023-05-02 06:22:59 --> Config Class Initialized
INFO - 2023-05-02 06:22:59 --> Hooks Class Initialized
DEBUG - 2023-05-02 06:22:59 --> UTF-8 Support Enabled
INFO - 2023-05-02 06:22:59 --> Utf8 Class Initialized
INFO - 2023-05-02 06:22:59 --> URI Class Initialized
INFO - 2023-05-02 06:22:59 --> Router Class Initialized
INFO - 2023-05-02 06:22:59 --> Output Class Initialized
INFO - 2023-05-02 06:22:59 --> Security Class Initialized
DEBUG - 2023-05-02 06:22:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-02 06:22:59 --> Input Class Initialized
INFO - 2023-05-02 06:22:59 --> Language Class Initialized
INFO - 2023-05-02 06:22:59 --> Language Class Initialized
INFO - 2023-05-02 06:22:59 --> Config Class Initialized
INFO - 2023-05-02 06:22:59 --> Loader Class Initialized
INFO - 2023-05-02 06:22:59 --> Helper loaded: url_helper
INFO - 2023-05-02 06:22:59 --> Helper loaded: file_helper
INFO - 2023-05-02 06:22:59 --> Helper loaded: form_helper
INFO - 2023-05-02 06:22:59 --> Helper loaded: my_helper
INFO - 2023-05-02 06:22:59 --> Database Driver Class Initialized
DEBUG - 2023-05-02 06:22:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-05-02 06:22:59 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-02 06:22:59 --> Controller Class Initialized
DEBUG - 2023-05-02 06:22:59 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/n_catatan_guru/views/list.php
DEBUG - 2023-05-02 06:22:59 --> File loaded: C:\xampp\htdocs\myraportk13\application\views\template_utama.php
INFO - 2023-05-02 06:22:59 --> Final output sent to browser
DEBUG - 2023-05-02 06:22:59 --> Total execution time: 0.0433
INFO - 2023-05-02 06:25:49 --> Config Class Initialized
INFO - 2023-05-02 06:25:49 --> Hooks Class Initialized
DEBUG - 2023-05-02 06:25:49 --> UTF-8 Support Enabled
INFO - 2023-05-02 06:25:49 --> Utf8 Class Initialized
INFO - 2023-05-02 06:25:49 --> URI Class Initialized
INFO - 2023-05-02 06:25:49 --> Router Class Initialized
INFO - 2023-05-02 06:25:49 --> Output Class Initialized
INFO - 2023-05-02 06:25:49 --> Security Class Initialized
DEBUG - 2023-05-02 06:25:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-02 06:25:49 --> Input Class Initialized
INFO - 2023-05-02 06:25:49 --> Language Class Initialized
INFO - 2023-05-02 06:25:49 --> Language Class Initialized
INFO - 2023-05-02 06:25:49 --> Config Class Initialized
INFO - 2023-05-02 06:25:49 --> Loader Class Initialized
INFO - 2023-05-02 06:25:49 --> Helper loaded: url_helper
INFO - 2023-05-02 06:25:49 --> Helper loaded: file_helper
INFO - 2023-05-02 06:25:49 --> Helper loaded: form_helper
INFO - 2023-05-02 06:25:49 --> Helper loaded: my_helper
INFO - 2023-05-02 06:25:49 --> Database Driver Class Initialized
DEBUG - 2023-05-02 06:25:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-05-02 06:25:49 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-02 06:25:49 --> Controller Class Initialized
DEBUG - 2023-05-02 06:25:49 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/n_catatan_guru/views/list.php
DEBUG - 2023-05-02 06:25:49 --> File loaded: C:\xampp\htdocs\myraportk13\application\views\template_utama.php
INFO - 2023-05-02 06:25:49 --> Final output sent to browser
DEBUG - 2023-05-02 06:25:49 --> Total execution time: 0.0709
INFO - 2023-05-02 06:25:54 --> Config Class Initialized
INFO - 2023-05-02 06:25:54 --> Hooks Class Initialized
DEBUG - 2023-05-02 06:25:54 --> UTF-8 Support Enabled
INFO - 2023-05-02 06:25:54 --> Utf8 Class Initialized
INFO - 2023-05-02 06:25:54 --> URI Class Initialized
INFO - 2023-05-02 06:25:54 --> Router Class Initialized
INFO - 2023-05-02 06:25:54 --> Output Class Initialized
INFO - 2023-05-02 06:25:54 --> Security Class Initialized
DEBUG - 2023-05-02 06:25:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-02 06:25:54 --> Input Class Initialized
INFO - 2023-05-02 06:25:54 --> Language Class Initialized
INFO - 2023-05-02 06:25:54 --> Language Class Initialized
INFO - 2023-05-02 06:25:54 --> Config Class Initialized
INFO - 2023-05-02 06:25:54 --> Loader Class Initialized
INFO - 2023-05-02 06:25:54 --> Helper loaded: url_helper
INFO - 2023-05-02 06:25:54 --> Helper loaded: file_helper
INFO - 2023-05-02 06:25:54 --> Helper loaded: form_helper
INFO - 2023-05-02 06:25:54 --> Helper loaded: my_helper
INFO - 2023-05-02 06:25:54 --> Database Driver Class Initialized
DEBUG - 2023-05-02 06:25:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-05-02 06:25:54 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-02 06:25:54 --> Controller Class Initialized
DEBUG - 2023-05-02 06:25:54 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/view_mapel/views/v_view_mapel.php
DEBUG - 2023-05-02 06:25:54 --> File loaded: C:\xampp\htdocs\myraportk13\application\views\template_utama.php
INFO - 2023-05-02 06:25:54 --> Final output sent to browser
DEBUG - 2023-05-02 06:25:54 --> Total execution time: 0.0460
INFO - 2023-05-02 06:25:55 --> Config Class Initialized
INFO - 2023-05-02 06:25:55 --> Hooks Class Initialized
DEBUG - 2023-05-02 06:25:55 --> UTF-8 Support Enabled
INFO - 2023-05-02 06:25:55 --> Utf8 Class Initialized
INFO - 2023-05-02 06:25:55 --> URI Class Initialized
INFO - 2023-05-02 06:25:55 --> Router Class Initialized
INFO - 2023-05-02 06:25:55 --> Output Class Initialized
INFO - 2023-05-02 06:25:55 --> Security Class Initialized
DEBUG - 2023-05-02 06:25:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-02 06:25:55 --> Input Class Initialized
INFO - 2023-05-02 06:25:55 --> Language Class Initialized
INFO - 2023-05-02 06:25:55 --> Language Class Initialized
INFO - 2023-05-02 06:25:55 --> Config Class Initialized
INFO - 2023-05-02 06:25:55 --> Loader Class Initialized
INFO - 2023-05-02 06:25:55 --> Helper loaded: url_helper
INFO - 2023-05-02 06:25:55 --> Helper loaded: file_helper
INFO - 2023-05-02 06:25:55 --> Helper loaded: form_helper
INFO - 2023-05-02 06:25:55 --> Helper loaded: my_helper
INFO - 2023-05-02 06:25:55 --> Database Driver Class Initialized
DEBUG - 2023-05-02 06:25:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-05-02 06:25:55 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-02 06:25:55 --> Controller Class Initialized
INFO - 2023-05-02 06:25:55 --> Helper loaded: cookie_helper
INFO - 2023-05-02 06:25:55 --> Config Class Initialized
INFO - 2023-05-02 06:25:55 --> Hooks Class Initialized
DEBUG - 2023-05-02 06:25:55 --> UTF-8 Support Enabled
INFO - 2023-05-02 06:25:55 --> Utf8 Class Initialized
INFO - 2023-05-02 06:25:55 --> URI Class Initialized
INFO - 2023-05-02 06:25:55 --> Router Class Initialized
INFO - 2023-05-02 06:25:55 --> Output Class Initialized
INFO - 2023-05-02 06:25:55 --> Security Class Initialized
DEBUG - 2023-05-02 06:25:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-02 06:25:55 --> Input Class Initialized
INFO - 2023-05-02 06:25:55 --> Language Class Initialized
INFO - 2023-05-02 06:25:55 --> Language Class Initialized
INFO - 2023-05-02 06:25:55 --> Config Class Initialized
INFO - 2023-05-02 06:25:55 --> Loader Class Initialized
INFO - 2023-05-02 06:25:55 --> Helper loaded: url_helper
INFO - 2023-05-02 06:25:55 --> Helper loaded: file_helper
INFO - 2023-05-02 06:25:55 --> Helper loaded: form_helper
INFO - 2023-05-02 06:25:55 --> Helper loaded: my_helper
INFO - 2023-05-02 06:25:55 --> Database Driver Class Initialized
DEBUG - 2023-05-02 06:25:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-05-02 06:25:55 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-02 06:25:55 --> Controller Class Initialized
INFO - 2023-05-02 06:25:55 --> Config Class Initialized
INFO - 2023-05-02 06:25:55 --> Hooks Class Initialized
DEBUG - 2023-05-02 06:25:55 --> UTF-8 Support Enabled
INFO - 2023-05-02 06:25:55 --> Utf8 Class Initialized
INFO - 2023-05-02 06:25:55 --> URI Class Initialized
INFO - 2023-05-02 06:25:55 --> Router Class Initialized
INFO - 2023-05-02 06:25:55 --> Output Class Initialized
INFO - 2023-05-02 06:25:55 --> Security Class Initialized
DEBUG - 2023-05-02 06:25:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-02 06:25:55 --> Input Class Initialized
INFO - 2023-05-02 06:25:55 --> Language Class Initialized
INFO - 2023-05-02 06:25:55 --> Language Class Initialized
INFO - 2023-05-02 06:25:55 --> Config Class Initialized
INFO - 2023-05-02 06:25:55 --> Loader Class Initialized
INFO - 2023-05-02 06:25:55 --> Helper loaded: url_helper
INFO - 2023-05-02 06:25:55 --> Helper loaded: file_helper
INFO - 2023-05-02 06:25:55 --> Helper loaded: form_helper
INFO - 2023-05-02 06:25:55 --> Helper loaded: my_helper
INFO - 2023-05-02 06:25:55 --> Database Driver Class Initialized
DEBUG - 2023-05-02 06:25:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-05-02 06:25:55 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-02 06:25:55 --> Controller Class Initialized
DEBUG - 2023-05-02 06:25:55 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/login/views/login.php
DEBUG - 2023-05-02 06:25:55 --> File loaded: C:\xampp\htdocs\myraportk13\application\views\template_utama.php
INFO - 2023-05-02 06:25:55 --> Final output sent to browser
DEBUG - 2023-05-02 06:25:55 --> Total execution time: 0.0527
INFO - 2023-05-02 06:26:00 --> Config Class Initialized
INFO - 2023-05-02 06:26:00 --> Hooks Class Initialized
DEBUG - 2023-05-02 06:26:00 --> UTF-8 Support Enabled
INFO - 2023-05-02 06:26:00 --> Utf8 Class Initialized
INFO - 2023-05-02 06:26:00 --> URI Class Initialized
INFO - 2023-05-02 06:26:00 --> Router Class Initialized
INFO - 2023-05-02 06:26:00 --> Output Class Initialized
INFO - 2023-05-02 06:26:00 --> Security Class Initialized
DEBUG - 2023-05-02 06:26:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-02 06:26:00 --> Input Class Initialized
INFO - 2023-05-02 06:26:00 --> Language Class Initialized
INFO - 2023-05-02 06:26:00 --> Language Class Initialized
INFO - 2023-05-02 06:26:00 --> Config Class Initialized
INFO - 2023-05-02 06:26:00 --> Loader Class Initialized
INFO - 2023-05-02 06:26:00 --> Helper loaded: url_helper
INFO - 2023-05-02 06:26:00 --> Helper loaded: file_helper
INFO - 2023-05-02 06:26:00 --> Helper loaded: form_helper
INFO - 2023-05-02 06:26:00 --> Helper loaded: my_helper
INFO - 2023-05-02 06:26:00 --> Database Driver Class Initialized
DEBUG - 2023-05-02 06:26:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-05-02 06:26:00 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-02 06:26:00 --> Controller Class Initialized
INFO - 2023-05-02 06:26:00 --> Helper loaded: cookie_helper
INFO - 2023-05-02 06:26:00 --> Final output sent to browser
DEBUG - 2023-05-02 06:26:00 --> Total execution time: 0.0449
INFO - 2023-05-02 06:26:00 --> Config Class Initialized
INFO - 2023-05-02 06:26:00 --> Hooks Class Initialized
DEBUG - 2023-05-02 06:26:00 --> UTF-8 Support Enabled
INFO - 2023-05-02 06:26:00 --> Utf8 Class Initialized
INFO - 2023-05-02 06:26:00 --> URI Class Initialized
INFO - 2023-05-02 06:26:00 --> Router Class Initialized
INFO - 2023-05-02 06:26:00 --> Output Class Initialized
INFO - 2023-05-02 06:26:00 --> Security Class Initialized
DEBUG - 2023-05-02 06:26:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-02 06:26:00 --> Input Class Initialized
INFO - 2023-05-02 06:26:00 --> Language Class Initialized
INFO - 2023-05-02 06:26:00 --> Language Class Initialized
INFO - 2023-05-02 06:26:00 --> Config Class Initialized
INFO - 2023-05-02 06:26:00 --> Loader Class Initialized
INFO - 2023-05-02 06:26:00 --> Helper loaded: url_helper
INFO - 2023-05-02 06:26:00 --> Helper loaded: file_helper
INFO - 2023-05-02 06:26:00 --> Helper loaded: form_helper
INFO - 2023-05-02 06:26:00 --> Helper loaded: my_helper
INFO - 2023-05-02 06:26:00 --> Database Driver Class Initialized
DEBUG - 2023-05-02 06:26:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-05-02 06:26:00 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-02 06:26:00 --> Controller Class Initialized
DEBUG - 2023-05-02 06:26:00 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/home/views/v_home_guru.php
DEBUG - 2023-05-02 06:26:00 --> File loaded: C:\xampp\htdocs\myraportk13\application\views\template_utama.php
INFO - 2023-05-02 06:26:00 --> Final output sent to browser
DEBUG - 2023-05-02 06:26:00 --> Total execution time: 0.0493
INFO - 2023-05-02 06:26:03 --> Config Class Initialized
INFO - 2023-05-02 06:26:03 --> Hooks Class Initialized
DEBUG - 2023-05-02 06:26:03 --> UTF-8 Support Enabled
INFO - 2023-05-02 06:26:03 --> Utf8 Class Initialized
INFO - 2023-05-02 06:26:03 --> URI Class Initialized
INFO - 2023-05-02 06:26:03 --> Router Class Initialized
INFO - 2023-05-02 06:26:03 --> Output Class Initialized
INFO - 2023-05-02 06:26:03 --> Security Class Initialized
DEBUG - 2023-05-02 06:26:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-02 06:26:03 --> Input Class Initialized
INFO - 2023-05-02 06:26:03 --> Language Class Initialized
INFO - 2023-05-02 06:26:03 --> Language Class Initialized
INFO - 2023-05-02 06:26:03 --> Config Class Initialized
INFO - 2023-05-02 06:26:03 --> Loader Class Initialized
INFO - 2023-05-02 06:26:03 --> Helper loaded: url_helper
INFO - 2023-05-02 06:26:03 --> Helper loaded: file_helper
INFO - 2023-05-02 06:26:03 --> Helper loaded: form_helper
INFO - 2023-05-02 06:26:03 --> Helper loaded: my_helper
INFO - 2023-05-02 06:26:03 --> Database Driver Class Initialized
DEBUG - 2023-05-02 06:26:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-05-02 06:26:03 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-02 06:26:03 --> Controller Class Initialized
ERROR - 2023-05-02 06:26:03 --> Severity: error --> Exception: Too few arguments to function N_catatan_nna::index(), 0 passed in C:\xampp\htdocs\myraportk13\system\core\CodeIgniter.php on line 532 and exactly 1 expected C:\xampp\htdocs\myraportk13\application\modules\n_catatan_nna\controllers\N_catatan_nna.php 55
INFO - 2023-05-02 06:26:22 --> Config Class Initialized
INFO - 2023-05-02 06:26:22 --> Hooks Class Initialized
DEBUG - 2023-05-02 06:26:22 --> UTF-8 Support Enabled
INFO - 2023-05-02 06:26:22 --> Utf8 Class Initialized
INFO - 2023-05-02 06:26:22 --> URI Class Initialized
INFO - 2023-05-02 06:26:22 --> Router Class Initialized
INFO - 2023-05-02 06:26:22 --> Output Class Initialized
INFO - 2023-05-02 06:26:22 --> Security Class Initialized
DEBUG - 2023-05-02 06:26:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-02 06:26:22 --> Input Class Initialized
INFO - 2023-05-02 06:26:22 --> Language Class Initialized
INFO - 2023-05-02 06:26:22 --> Language Class Initialized
INFO - 2023-05-02 06:26:22 --> Config Class Initialized
INFO - 2023-05-02 06:26:22 --> Loader Class Initialized
INFO - 2023-05-02 06:26:22 --> Helper loaded: url_helper
INFO - 2023-05-02 06:26:22 --> Helper loaded: file_helper
INFO - 2023-05-02 06:26:22 --> Helper loaded: form_helper
INFO - 2023-05-02 06:26:22 --> Helper loaded: my_helper
INFO - 2023-05-02 06:26:22 --> Database Driver Class Initialized
DEBUG - 2023-05-02 06:26:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-05-02 06:26:22 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-02 06:26:22 --> Controller Class Initialized
ERROR - 2023-05-02 06:26:22 --> Severity: error --> Exception: Too few arguments to function N_catatan_nna::index(), 0 passed in C:\xampp\htdocs\myraportk13\system\core\CodeIgniter.php on line 532 and exactly 1 expected C:\xampp\htdocs\myraportk13\application\modules\n_catatan_nna\controllers\N_catatan_nna.php 55
INFO - 2023-05-02 06:26:24 --> Config Class Initialized
INFO - 2023-05-02 06:26:24 --> Hooks Class Initialized
DEBUG - 2023-05-02 06:26:24 --> UTF-8 Support Enabled
INFO - 2023-05-02 06:26:24 --> Utf8 Class Initialized
INFO - 2023-05-02 06:26:24 --> URI Class Initialized
INFO - 2023-05-02 06:26:24 --> Router Class Initialized
INFO - 2023-05-02 06:26:24 --> Output Class Initialized
INFO - 2023-05-02 06:26:24 --> Security Class Initialized
DEBUG - 2023-05-02 06:26:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-02 06:26:24 --> Input Class Initialized
INFO - 2023-05-02 06:26:24 --> Language Class Initialized
INFO - 2023-05-02 06:26:24 --> Language Class Initialized
INFO - 2023-05-02 06:26:24 --> Config Class Initialized
INFO - 2023-05-02 06:26:24 --> Loader Class Initialized
INFO - 2023-05-02 06:26:24 --> Helper loaded: url_helper
INFO - 2023-05-02 06:26:24 --> Helper loaded: file_helper
INFO - 2023-05-02 06:26:24 --> Helper loaded: form_helper
INFO - 2023-05-02 06:26:24 --> Helper loaded: my_helper
INFO - 2023-05-02 06:26:24 --> Database Driver Class Initialized
DEBUG - 2023-05-02 06:26:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-05-02 06:26:24 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-02 06:26:24 --> Controller Class Initialized
DEBUG - 2023-05-02 06:26:24 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/home/views/v_home_guru.php
DEBUG - 2023-05-02 06:26:24 --> File loaded: C:\xampp\htdocs\myraportk13\application\views\template_utama.php
INFO - 2023-05-02 06:26:24 --> Final output sent to browser
DEBUG - 2023-05-02 06:26:24 --> Total execution time: 0.0477
INFO - 2023-05-02 06:26:26 --> Config Class Initialized
INFO - 2023-05-02 06:26:26 --> Hooks Class Initialized
DEBUG - 2023-05-02 06:26:26 --> UTF-8 Support Enabled
INFO - 2023-05-02 06:26:26 --> Utf8 Class Initialized
INFO - 2023-05-02 06:26:26 --> URI Class Initialized
INFO - 2023-05-02 06:26:26 --> Router Class Initialized
INFO - 2023-05-02 06:26:26 --> Output Class Initialized
INFO - 2023-05-02 06:26:26 --> Security Class Initialized
DEBUG - 2023-05-02 06:26:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-02 06:26:26 --> Input Class Initialized
INFO - 2023-05-02 06:26:26 --> Language Class Initialized
INFO - 2023-05-02 06:26:26 --> Language Class Initialized
INFO - 2023-05-02 06:26:26 --> Config Class Initialized
INFO - 2023-05-02 06:26:26 --> Loader Class Initialized
INFO - 2023-05-02 06:26:26 --> Helper loaded: url_helper
INFO - 2023-05-02 06:26:26 --> Helper loaded: file_helper
INFO - 2023-05-02 06:26:26 --> Helper loaded: form_helper
INFO - 2023-05-02 06:26:26 --> Helper loaded: my_helper
INFO - 2023-05-02 06:26:26 --> Database Driver Class Initialized
DEBUG - 2023-05-02 06:26:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-05-02 06:26:26 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-02 06:26:26 --> Controller Class Initialized
DEBUG - 2023-05-02 06:26:26 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/view_mapel/views/v_view_mapel.php
DEBUG - 2023-05-02 06:26:26 --> File loaded: C:\xampp\htdocs\myraportk13\application\views\template_utama.php
INFO - 2023-05-02 06:26:26 --> Final output sent to browser
DEBUG - 2023-05-02 06:26:26 --> Total execution time: 0.0631
INFO - 2023-05-02 06:26:32 --> Config Class Initialized
INFO - 2023-05-02 06:26:32 --> Hooks Class Initialized
DEBUG - 2023-05-02 06:26:32 --> UTF-8 Support Enabled
INFO - 2023-05-02 06:26:32 --> Utf8 Class Initialized
INFO - 2023-05-02 06:26:32 --> URI Class Initialized
INFO - 2023-05-02 06:26:32 --> Router Class Initialized
INFO - 2023-05-02 06:26:32 --> Output Class Initialized
INFO - 2023-05-02 06:26:32 --> Security Class Initialized
DEBUG - 2023-05-02 06:26:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-02 06:26:32 --> Input Class Initialized
INFO - 2023-05-02 06:26:32 --> Language Class Initialized
INFO - 2023-05-02 06:26:32 --> Language Class Initialized
INFO - 2023-05-02 06:26:32 --> Config Class Initialized
INFO - 2023-05-02 06:26:32 --> Loader Class Initialized
INFO - 2023-05-02 06:26:32 --> Helper loaded: url_helper
INFO - 2023-05-02 06:26:32 --> Helper loaded: file_helper
INFO - 2023-05-02 06:26:32 --> Helper loaded: form_helper
INFO - 2023-05-02 06:26:32 --> Helper loaded: my_helper
INFO - 2023-05-02 06:26:32 --> Database Driver Class Initialized
DEBUG - 2023-05-02 06:26:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-05-02 06:26:32 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-02 06:26:32 --> Controller Class Initialized
ERROR - 2023-05-02 06:26:32 --> Severity: error --> Exception: Too few arguments to function N_catatan_nna::index(), 0 passed in C:\xampp\htdocs\myraportk13\system\core\CodeIgniter.php on line 532 and exactly 1 expected C:\xampp\htdocs\myraportk13\application\modules\n_catatan_nna\controllers\N_catatan_nna.php 55
INFO - 2023-05-02 06:26:36 --> Config Class Initialized
INFO - 2023-05-02 06:26:36 --> Hooks Class Initialized
DEBUG - 2023-05-02 06:26:36 --> UTF-8 Support Enabled
INFO - 2023-05-02 06:26:36 --> Utf8 Class Initialized
INFO - 2023-05-02 06:26:36 --> URI Class Initialized
INFO - 2023-05-02 06:26:36 --> Router Class Initialized
INFO - 2023-05-02 06:26:36 --> Output Class Initialized
INFO - 2023-05-02 06:26:36 --> Security Class Initialized
DEBUG - 2023-05-02 06:26:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-02 06:26:36 --> Input Class Initialized
INFO - 2023-05-02 06:26:36 --> Language Class Initialized
INFO - 2023-05-02 06:26:36 --> Language Class Initialized
INFO - 2023-05-02 06:26:36 --> Config Class Initialized
INFO - 2023-05-02 06:26:36 --> Loader Class Initialized
INFO - 2023-05-02 06:26:36 --> Helper loaded: url_helper
INFO - 2023-05-02 06:26:36 --> Helper loaded: file_helper
INFO - 2023-05-02 06:26:36 --> Helper loaded: form_helper
INFO - 2023-05-02 06:26:36 --> Helper loaded: my_helper
INFO - 2023-05-02 06:26:36 --> Database Driver Class Initialized
DEBUG - 2023-05-02 06:26:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-05-02 06:26:36 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-02 06:26:36 --> Controller Class Initialized
DEBUG - 2023-05-02 06:26:36 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/view_mapel/views/v_view_mapel.php
DEBUG - 2023-05-02 06:26:36 --> File loaded: C:\xampp\htdocs\myraportk13\application\views\template_utama.php
INFO - 2023-05-02 06:26:36 --> Final output sent to browser
DEBUG - 2023-05-02 06:26:36 --> Total execution time: 0.0452
INFO - 2023-05-02 06:26:40 --> Config Class Initialized
INFO - 2023-05-02 06:26:40 --> Hooks Class Initialized
DEBUG - 2023-05-02 06:26:40 --> UTF-8 Support Enabled
INFO - 2023-05-02 06:26:40 --> Utf8 Class Initialized
INFO - 2023-05-02 06:26:40 --> URI Class Initialized
INFO - 2023-05-02 06:26:40 --> Router Class Initialized
INFO - 2023-05-02 06:26:40 --> Output Class Initialized
INFO - 2023-05-02 06:26:40 --> Security Class Initialized
DEBUG - 2023-05-02 06:26:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-02 06:26:40 --> Input Class Initialized
INFO - 2023-05-02 06:26:40 --> Language Class Initialized
INFO - 2023-05-02 06:26:40 --> Language Class Initialized
INFO - 2023-05-02 06:26:40 --> Config Class Initialized
INFO - 2023-05-02 06:26:40 --> Loader Class Initialized
INFO - 2023-05-02 06:26:40 --> Helper loaded: url_helper
INFO - 2023-05-02 06:26:40 --> Helper loaded: file_helper
INFO - 2023-05-02 06:26:40 --> Helper loaded: form_helper
INFO - 2023-05-02 06:26:40 --> Helper loaded: my_helper
INFO - 2023-05-02 06:26:40 --> Database Driver Class Initialized
DEBUG - 2023-05-02 06:26:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-05-02 06:26:40 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-02 06:26:40 --> Controller Class Initialized
INFO - 2023-05-02 06:26:40 --> Helper loaded: cookie_helper
INFO - 2023-05-02 06:26:40 --> Config Class Initialized
INFO - 2023-05-02 06:26:40 --> Hooks Class Initialized
DEBUG - 2023-05-02 06:26:40 --> UTF-8 Support Enabled
INFO - 2023-05-02 06:26:40 --> Utf8 Class Initialized
INFO - 2023-05-02 06:26:40 --> URI Class Initialized
INFO - 2023-05-02 06:26:40 --> Router Class Initialized
INFO - 2023-05-02 06:26:40 --> Output Class Initialized
INFO - 2023-05-02 06:26:40 --> Security Class Initialized
DEBUG - 2023-05-02 06:26:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-02 06:26:40 --> Input Class Initialized
INFO - 2023-05-02 06:26:40 --> Language Class Initialized
INFO - 2023-05-02 06:26:40 --> Language Class Initialized
INFO - 2023-05-02 06:26:40 --> Config Class Initialized
INFO - 2023-05-02 06:26:40 --> Loader Class Initialized
INFO - 2023-05-02 06:26:40 --> Helper loaded: url_helper
INFO - 2023-05-02 06:26:40 --> Helper loaded: file_helper
INFO - 2023-05-02 06:26:40 --> Helper loaded: form_helper
INFO - 2023-05-02 06:26:40 --> Helper loaded: my_helper
INFO - 2023-05-02 06:26:40 --> Database Driver Class Initialized
DEBUG - 2023-05-02 06:26:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-05-02 06:26:40 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-02 06:26:40 --> Controller Class Initialized
INFO - 2023-05-02 06:26:40 --> Config Class Initialized
INFO - 2023-05-02 06:26:40 --> Hooks Class Initialized
DEBUG - 2023-05-02 06:26:40 --> UTF-8 Support Enabled
INFO - 2023-05-02 06:26:40 --> Utf8 Class Initialized
INFO - 2023-05-02 06:26:40 --> URI Class Initialized
INFO - 2023-05-02 06:26:40 --> Router Class Initialized
INFO - 2023-05-02 06:26:40 --> Output Class Initialized
INFO - 2023-05-02 06:26:40 --> Security Class Initialized
DEBUG - 2023-05-02 06:26:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-02 06:26:40 --> Input Class Initialized
INFO - 2023-05-02 06:26:40 --> Language Class Initialized
INFO - 2023-05-02 06:26:40 --> Language Class Initialized
INFO - 2023-05-02 06:26:40 --> Config Class Initialized
INFO - 2023-05-02 06:26:40 --> Loader Class Initialized
INFO - 2023-05-02 06:26:40 --> Helper loaded: url_helper
INFO - 2023-05-02 06:26:40 --> Helper loaded: file_helper
INFO - 2023-05-02 06:26:40 --> Helper loaded: form_helper
INFO - 2023-05-02 06:26:40 --> Helper loaded: my_helper
INFO - 2023-05-02 06:26:40 --> Database Driver Class Initialized
DEBUG - 2023-05-02 06:26:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-05-02 06:26:40 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-02 06:26:40 --> Controller Class Initialized
DEBUG - 2023-05-02 06:26:40 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/login/views/login.php
DEBUG - 2023-05-02 06:26:40 --> File loaded: C:\xampp\htdocs\myraportk13\application\views\template_utama.php
INFO - 2023-05-02 06:26:40 --> Final output sent to browser
DEBUG - 2023-05-02 06:26:40 --> Total execution time: 0.0380
INFO - 2023-05-02 06:26:45 --> Config Class Initialized
INFO - 2023-05-02 06:26:45 --> Hooks Class Initialized
DEBUG - 2023-05-02 06:26:45 --> UTF-8 Support Enabled
INFO - 2023-05-02 06:26:45 --> Utf8 Class Initialized
INFO - 2023-05-02 06:26:45 --> URI Class Initialized
INFO - 2023-05-02 06:26:45 --> Router Class Initialized
INFO - 2023-05-02 06:26:45 --> Output Class Initialized
INFO - 2023-05-02 06:26:45 --> Security Class Initialized
DEBUG - 2023-05-02 06:26:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-02 06:26:45 --> Input Class Initialized
INFO - 2023-05-02 06:26:45 --> Language Class Initialized
INFO - 2023-05-02 06:26:45 --> Language Class Initialized
INFO - 2023-05-02 06:26:45 --> Config Class Initialized
INFO - 2023-05-02 06:26:45 --> Loader Class Initialized
INFO - 2023-05-02 06:26:45 --> Helper loaded: url_helper
INFO - 2023-05-02 06:26:45 --> Helper loaded: file_helper
INFO - 2023-05-02 06:26:45 --> Helper loaded: form_helper
INFO - 2023-05-02 06:26:45 --> Helper loaded: my_helper
INFO - 2023-05-02 06:26:46 --> Database Driver Class Initialized
DEBUG - 2023-05-02 06:26:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-05-02 06:26:46 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-02 06:26:46 --> Controller Class Initialized
INFO - 2023-05-02 06:26:46 --> Helper loaded: cookie_helper
INFO - 2023-05-02 06:26:46 --> Final output sent to browser
DEBUG - 2023-05-02 06:26:46 --> Total execution time: 0.0697
INFO - 2023-05-02 06:26:46 --> Config Class Initialized
INFO - 2023-05-02 06:26:46 --> Hooks Class Initialized
DEBUG - 2023-05-02 06:26:46 --> UTF-8 Support Enabled
INFO - 2023-05-02 06:26:46 --> Utf8 Class Initialized
INFO - 2023-05-02 06:26:46 --> URI Class Initialized
INFO - 2023-05-02 06:26:46 --> Router Class Initialized
INFO - 2023-05-02 06:26:46 --> Output Class Initialized
INFO - 2023-05-02 06:26:46 --> Security Class Initialized
DEBUG - 2023-05-02 06:26:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-02 06:26:46 --> Input Class Initialized
INFO - 2023-05-02 06:26:46 --> Language Class Initialized
INFO - 2023-05-02 06:26:46 --> Language Class Initialized
INFO - 2023-05-02 06:26:46 --> Config Class Initialized
INFO - 2023-05-02 06:26:46 --> Loader Class Initialized
INFO - 2023-05-02 06:26:46 --> Helper loaded: url_helper
INFO - 2023-05-02 06:26:46 --> Helper loaded: file_helper
INFO - 2023-05-02 06:26:46 --> Helper loaded: form_helper
INFO - 2023-05-02 06:26:46 --> Helper loaded: my_helper
INFO - 2023-05-02 06:26:46 --> Database Driver Class Initialized
DEBUG - 2023-05-02 06:26:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-05-02 06:26:46 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-02 06:26:46 --> Controller Class Initialized
DEBUG - 2023-05-02 06:26:46 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/home/views/v_home_guru.php
DEBUG - 2023-05-02 06:26:46 --> File loaded: C:\xampp\htdocs\myraportk13\application\views\template_utama.php
INFO - 2023-05-02 06:26:46 --> Final output sent to browser
DEBUG - 2023-05-02 06:26:46 --> Total execution time: 0.0490
INFO - 2023-05-02 06:26:47 --> Config Class Initialized
INFO - 2023-05-02 06:26:47 --> Hooks Class Initialized
DEBUG - 2023-05-02 06:26:47 --> UTF-8 Support Enabled
INFO - 2023-05-02 06:26:47 --> Utf8 Class Initialized
INFO - 2023-05-02 06:26:47 --> URI Class Initialized
INFO - 2023-05-02 06:26:47 --> Router Class Initialized
INFO - 2023-05-02 06:26:47 --> Output Class Initialized
INFO - 2023-05-02 06:26:47 --> Security Class Initialized
DEBUG - 2023-05-02 06:26:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-02 06:26:47 --> Input Class Initialized
INFO - 2023-05-02 06:26:47 --> Language Class Initialized
INFO - 2023-05-02 06:26:47 --> Language Class Initialized
INFO - 2023-05-02 06:26:47 --> Config Class Initialized
INFO - 2023-05-02 06:26:47 --> Loader Class Initialized
INFO - 2023-05-02 06:26:47 --> Helper loaded: url_helper
INFO - 2023-05-02 06:26:47 --> Helper loaded: file_helper
INFO - 2023-05-02 06:26:47 --> Helper loaded: form_helper
INFO - 2023-05-02 06:26:47 --> Helper loaded: my_helper
INFO - 2023-05-02 06:26:47 --> Database Driver Class Initialized
DEBUG - 2023-05-02 06:26:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-05-02 06:26:47 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-02 06:26:47 --> Controller Class Initialized
DEBUG - 2023-05-02 06:26:47 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/view_mapel/views/v_view_mapel.php
DEBUG - 2023-05-02 06:26:47 --> File loaded: C:\xampp\htdocs\myraportk13\application\views\template_utama.php
INFO - 2023-05-02 06:26:47 --> Final output sent to browser
DEBUG - 2023-05-02 06:26:47 --> Total execution time: 0.0445
INFO - 2023-05-02 06:29:12 --> Config Class Initialized
INFO - 2023-05-02 06:29:12 --> Hooks Class Initialized
DEBUG - 2023-05-02 06:29:12 --> UTF-8 Support Enabled
INFO - 2023-05-02 06:29:12 --> Utf8 Class Initialized
INFO - 2023-05-02 06:29:12 --> URI Class Initialized
INFO - 2023-05-02 06:29:12 --> Router Class Initialized
INFO - 2023-05-02 06:29:12 --> Output Class Initialized
INFO - 2023-05-02 06:29:12 --> Security Class Initialized
DEBUG - 2023-05-02 06:29:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-02 06:29:12 --> Input Class Initialized
INFO - 2023-05-02 06:29:12 --> Language Class Initialized
INFO - 2023-05-02 06:29:12 --> Language Class Initialized
INFO - 2023-05-02 06:29:12 --> Config Class Initialized
INFO - 2023-05-02 06:29:12 --> Loader Class Initialized
INFO - 2023-05-02 06:29:12 --> Helper loaded: url_helper
INFO - 2023-05-02 06:29:12 --> Helper loaded: file_helper
INFO - 2023-05-02 06:29:12 --> Helper loaded: form_helper
INFO - 2023-05-02 06:29:12 --> Helper loaded: my_helper
INFO - 2023-05-02 06:29:12 --> Database Driver Class Initialized
DEBUG - 2023-05-02 06:29:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-05-02 06:29:12 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-02 06:29:12 --> Controller Class Initialized
INFO - 2023-05-02 06:29:12 --> Helper loaded: cookie_helper
INFO - 2023-05-02 06:29:12 --> Config Class Initialized
INFO - 2023-05-02 06:29:12 --> Hooks Class Initialized
DEBUG - 2023-05-02 06:29:12 --> UTF-8 Support Enabled
INFO - 2023-05-02 06:29:12 --> Utf8 Class Initialized
INFO - 2023-05-02 06:29:12 --> URI Class Initialized
INFO - 2023-05-02 06:29:12 --> Router Class Initialized
INFO - 2023-05-02 06:29:12 --> Output Class Initialized
INFO - 2023-05-02 06:29:12 --> Security Class Initialized
DEBUG - 2023-05-02 06:29:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-02 06:29:12 --> Input Class Initialized
INFO - 2023-05-02 06:29:12 --> Language Class Initialized
INFO - 2023-05-02 06:29:12 --> Language Class Initialized
INFO - 2023-05-02 06:29:12 --> Config Class Initialized
INFO - 2023-05-02 06:29:12 --> Loader Class Initialized
INFO - 2023-05-02 06:29:12 --> Helper loaded: url_helper
INFO - 2023-05-02 06:29:12 --> Helper loaded: file_helper
INFO - 2023-05-02 06:29:12 --> Helper loaded: form_helper
INFO - 2023-05-02 06:29:12 --> Helper loaded: my_helper
INFO - 2023-05-02 06:29:12 --> Database Driver Class Initialized
DEBUG - 2023-05-02 06:29:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-05-02 06:29:12 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-02 06:29:12 --> Controller Class Initialized
INFO - 2023-05-02 06:29:12 --> Config Class Initialized
INFO - 2023-05-02 06:29:12 --> Hooks Class Initialized
DEBUG - 2023-05-02 06:29:12 --> UTF-8 Support Enabled
INFO - 2023-05-02 06:29:12 --> Utf8 Class Initialized
INFO - 2023-05-02 06:29:12 --> URI Class Initialized
INFO - 2023-05-02 06:29:12 --> Router Class Initialized
INFO - 2023-05-02 06:29:12 --> Output Class Initialized
INFO - 2023-05-02 06:29:12 --> Security Class Initialized
DEBUG - 2023-05-02 06:29:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-02 06:29:12 --> Input Class Initialized
INFO - 2023-05-02 06:29:12 --> Language Class Initialized
INFO - 2023-05-02 06:29:12 --> Language Class Initialized
INFO - 2023-05-02 06:29:12 --> Config Class Initialized
INFO - 2023-05-02 06:29:12 --> Loader Class Initialized
INFO - 2023-05-02 06:29:12 --> Helper loaded: url_helper
INFO - 2023-05-02 06:29:12 --> Helper loaded: file_helper
INFO - 2023-05-02 06:29:12 --> Helper loaded: form_helper
INFO - 2023-05-02 06:29:12 --> Helper loaded: my_helper
INFO - 2023-05-02 06:29:12 --> Database Driver Class Initialized
DEBUG - 2023-05-02 06:29:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-05-02 06:29:12 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-02 06:29:12 --> Controller Class Initialized
DEBUG - 2023-05-02 06:29:12 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/login/views/login.php
DEBUG - 2023-05-02 06:29:12 --> File loaded: C:\xampp\htdocs\myraportk13\application\views\template_utama.php
INFO - 2023-05-02 06:29:12 --> Final output sent to browser
DEBUG - 2023-05-02 06:29:12 --> Total execution time: 0.0421
INFO - 2023-05-02 06:29:18 --> Config Class Initialized
INFO - 2023-05-02 06:29:18 --> Hooks Class Initialized
DEBUG - 2023-05-02 06:29:18 --> UTF-8 Support Enabled
INFO - 2023-05-02 06:29:18 --> Utf8 Class Initialized
INFO - 2023-05-02 06:29:18 --> URI Class Initialized
INFO - 2023-05-02 06:29:18 --> Router Class Initialized
INFO - 2023-05-02 06:29:18 --> Output Class Initialized
INFO - 2023-05-02 06:29:18 --> Security Class Initialized
DEBUG - 2023-05-02 06:29:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-02 06:29:18 --> Input Class Initialized
INFO - 2023-05-02 06:29:18 --> Language Class Initialized
INFO - 2023-05-02 06:29:19 --> Language Class Initialized
INFO - 2023-05-02 06:29:19 --> Config Class Initialized
INFO - 2023-05-02 06:29:19 --> Loader Class Initialized
INFO - 2023-05-02 06:29:19 --> Helper loaded: url_helper
INFO - 2023-05-02 06:29:19 --> Helper loaded: file_helper
INFO - 2023-05-02 06:29:19 --> Helper loaded: form_helper
INFO - 2023-05-02 06:29:19 --> Helper loaded: my_helper
INFO - 2023-05-02 06:29:19 --> Database Driver Class Initialized
DEBUG - 2023-05-02 06:29:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-05-02 06:29:19 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-02 06:29:19 --> Controller Class Initialized
INFO - 2023-05-02 06:29:19 --> Helper loaded: cookie_helper
INFO - 2023-05-02 06:29:19 --> Final output sent to browser
DEBUG - 2023-05-02 06:29:19 --> Total execution time: 0.0449
INFO - 2023-05-02 06:29:19 --> Config Class Initialized
INFO - 2023-05-02 06:29:19 --> Hooks Class Initialized
DEBUG - 2023-05-02 06:29:19 --> UTF-8 Support Enabled
INFO - 2023-05-02 06:29:19 --> Utf8 Class Initialized
INFO - 2023-05-02 06:29:19 --> URI Class Initialized
INFO - 2023-05-02 06:29:19 --> Router Class Initialized
INFO - 2023-05-02 06:29:19 --> Output Class Initialized
INFO - 2023-05-02 06:29:19 --> Security Class Initialized
DEBUG - 2023-05-02 06:29:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-02 06:29:19 --> Input Class Initialized
INFO - 2023-05-02 06:29:19 --> Language Class Initialized
INFO - 2023-05-02 06:29:19 --> Language Class Initialized
INFO - 2023-05-02 06:29:19 --> Config Class Initialized
INFO - 2023-05-02 06:29:19 --> Loader Class Initialized
INFO - 2023-05-02 06:29:19 --> Helper loaded: url_helper
INFO - 2023-05-02 06:29:19 --> Helper loaded: file_helper
INFO - 2023-05-02 06:29:19 --> Helper loaded: form_helper
INFO - 2023-05-02 06:29:19 --> Helper loaded: my_helper
INFO - 2023-05-02 06:29:19 --> Database Driver Class Initialized
DEBUG - 2023-05-02 06:29:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-05-02 06:29:19 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-02 06:29:19 --> Controller Class Initialized
DEBUG - 2023-05-02 06:29:19 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/home/views/v_home_guru.php
DEBUG - 2023-05-02 06:29:19 --> File loaded: C:\xampp\htdocs\myraportk13\application\views\template_utama.php
INFO - 2023-05-02 06:29:19 --> Final output sent to browser
DEBUG - 2023-05-02 06:29:19 --> Total execution time: 0.0474
INFO - 2023-05-02 06:29:22 --> Config Class Initialized
INFO - 2023-05-02 06:29:22 --> Hooks Class Initialized
DEBUG - 2023-05-02 06:29:22 --> UTF-8 Support Enabled
INFO - 2023-05-02 06:29:22 --> Utf8 Class Initialized
INFO - 2023-05-02 06:29:22 --> URI Class Initialized
INFO - 2023-05-02 06:29:22 --> Router Class Initialized
INFO - 2023-05-02 06:29:22 --> Output Class Initialized
INFO - 2023-05-02 06:29:22 --> Security Class Initialized
DEBUG - 2023-05-02 06:29:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-02 06:29:22 --> Input Class Initialized
INFO - 2023-05-02 06:29:22 --> Language Class Initialized
INFO - 2023-05-02 06:29:22 --> Language Class Initialized
INFO - 2023-05-02 06:29:22 --> Config Class Initialized
INFO - 2023-05-02 06:29:22 --> Loader Class Initialized
INFO - 2023-05-02 06:29:22 --> Helper loaded: url_helper
INFO - 2023-05-02 06:29:22 --> Helper loaded: file_helper
INFO - 2023-05-02 06:29:22 --> Helper loaded: form_helper
INFO - 2023-05-02 06:29:22 --> Helper loaded: my_helper
INFO - 2023-05-02 06:29:22 --> Database Driver Class Initialized
DEBUG - 2023-05-02 06:29:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-05-02 06:29:22 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-02 06:29:22 --> Controller Class Initialized
DEBUG - 2023-05-02 06:29:22 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/n_catatan_nna/views/list.php
DEBUG - 2023-05-02 06:29:22 --> File loaded: C:\xampp\htdocs\myraportk13\application\views\template_utama.php
INFO - 2023-05-02 06:29:22 --> Final output sent to browser
DEBUG - 2023-05-02 06:29:22 --> Total execution time: 0.1024
INFO - 2023-05-02 06:48:11 --> Config Class Initialized
INFO - 2023-05-02 06:48:11 --> Hooks Class Initialized
DEBUG - 2023-05-02 06:48:11 --> UTF-8 Support Enabled
INFO - 2023-05-02 06:48:11 --> Utf8 Class Initialized
INFO - 2023-05-02 06:48:11 --> URI Class Initialized
INFO - 2023-05-02 06:48:11 --> Router Class Initialized
INFO - 2023-05-02 06:48:11 --> Output Class Initialized
INFO - 2023-05-02 06:48:11 --> Security Class Initialized
DEBUG - 2023-05-02 06:48:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-02 06:48:11 --> Input Class Initialized
INFO - 2023-05-02 06:48:11 --> Language Class Initialized
INFO - 2023-05-02 06:48:11 --> Language Class Initialized
INFO - 2023-05-02 06:48:11 --> Config Class Initialized
INFO - 2023-05-02 06:48:11 --> Loader Class Initialized
INFO - 2023-05-02 06:48:11 --> Helper loaded: url_helper
INFO - 2023-05-02 06:48:11 --> Helper loaded: file_helper
INFO - 2023-05-02 06:48:11 --> Helper loaded: form_helper
INFO - 2023-05-02 06:48:11 --> Helper loaded: my_helper
INFO - 2023-05-02 06:48:11 --> Database Driver Class Initialized
DEBUG - 2023-05-02 06:48:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-05-02 06:48:11 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-02 06:48:11 --> Controller Class Initialized
DEBUG - 2023-05-02 06:48:11 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/n_catatan_nna/views/list.php
DEBUG - 2023-05-02 06:48:11 --> File loaded: C:\xampp\htdocs\myraportk13\application\views\template_utama.php
INFO - 2023-05-02 06:48:11 --> Final output sent to browser
DEBUG - 2023-05-02 06:48:11 --> Total execution time: 0.0961
INFO - 2023-05-02 06:48:22 --> Config Class Initialized
INFO - 2023-05-02 06:48:22 --> Hooks Class Initialized
DEBUG - 2023-05-02 06:48:22 --> UTF-8 Support Enabled
INFO - 2023-05-02 06:48:22 --> Utf8 Class Initialized
INFO - 2023-05-02 06:48:22 --> URI Class Initialized
INFO - 2023-05-02 06:48:22 --> Router Class Initialized
INFO - 2023-05-02 06:48:22 --> Output Class Initialized
INFO - 2023-05-02 06:48:22 --> Security Class Initialized
DEBUG - 2023-05-02 06:48:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-02 06:48:22 --> Input Class Initialized
INFO - 2023-05-02 06:48:22 --> Language Class Initialized
ERROR - 2023-05-02 06:48:22 --> 404 Page Not Found: ../modules/n_catatan_nna/controllers/N_catatan_nna/import
INFO - 2023-05-02 06:48:24 --> Config Class Initialized
INFO - 2023-05-02 06:48:24 --> Hooks Class Initialized
DEBUG - 2023-05-02 06:48:24 --> UTF-8 Support Enabled
INFO - 2023-05-02 06:48:24 --> Utf8 Class Initialized
INFO - 2023-05-02 06:48:24 --> URI Class Initialized
INFO - 2023-05-02 06:48:24 --> Router Class Initialized
INFO - 2023-05-02 06:48:24 --> Output Class Initialized
INFO - 2023-05-02 06:48:24 --> Security Class Initialized
DEBUG - 2023-05-02 06:48:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-02 06:48:24 --> Input Class Initialized
INFO - 2023-05-02 06:48:24 --> Language Class Initialized
INFO - 2023-05-02 06:48:24 --> Language Class Initialized
INFO - 2023-05-02 06:48:24 --> Config Class Initialized
INFO - 2023-05-02 06:48:24 --> Loader Class Initialized
INFO - 2023-05-02 06:48:24 --> Helper loaded: url_helper
INFO - 2023-05-02 06:48:24 --> Helper loaded: file_helper
INFO - 2023-05-02 06:48:24 --> Helper loaded: form_helper
INFO - 2023-05-02 06:48:24 --> Helper loaded: my_helper
INFO - 2023-05-02 06:48:24 --> Database Driver Class Initialized
DEBUG - 2023-05-02 06:48:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-05-02 06:48:24 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-02 06:48:24 --> Controller Class Initialized
DEBUG - 2023-05-02 06:48:24 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/n_catatan_nna/views/list.php
DEBUG - 2023-05-02 06:48:24 --> File loaded: C:\xampp\htdocs\myraportk13\application\views\template_utama.php
INFO - 2023-05-02 06:48:24 --> Final output sent to browser
DEBUG - 2023-05-02 06:48:24 --> Total execution time: 0.0443
INFO - 2023-05-02 07:03:13 --> Config Class Initialized
INFO - 2023-05-02 07:03:13 --> Hooks Class Initialized
DEBUG - 2023-05-02 07:03:13 --> UTF-8 Support Enabled
INFO - 2023-05-02 07:03:13 --> Utf8 Class Initialized
INFO - 2023-05-02 07:03:13 --> URI Class Initialized
INFO - 2023-05-02 07:03:13 --> Router Class Initialized
INFO - 2023-05-02 07:03:13 --> Output Class Initialized
INFO - 2023-05-02 07:03:13 --> Security Class Initialized
DEBUG - 2023-05-02 07:03:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-02 07:03:13 --> Input Class Initialized
INFO - 2023-05-02 07:03:13 --> Language Class Initialized
INFO - 2023-05-02 07:03:13 --> Language Class Initialized
INFO - 2023-05-02 07:03:13 --> Config Class Initialized
INFO - 2023-05-02 07:03:13 --> Loader Class Initialized
INFO - 2023-05-02 07:03:13 --> Helper loaded: url_helper
INFO - 2023-05-02 07:03:13 --> Helper loaded: file_helper
INFO - 2023-05-02 07:03:13 --> Helper loaded: form_helper
INFO - 2023-05-02 07:03:13 --> Helper loaded: my_helper
INFO - 2023-05-02 07:03:13 --> Database Driver Class Initialized
DEBUG - 2023-05-02 07:03:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-05-02 07:03:13 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-02 07:03:13 --> Controller Class Initialized
DEBUG - 2023-05-02 07:03:13 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/n_catatan_nna/views/list.php
DEBUG - 2023-05-02 07:03:13 --> File loaded: C:\xampp\htdocs\myraportk13\application\views\template_utama.php
INFO - 2023-05-02 07:03:13 --> Final output sent to browser
DEBUG - 2023-05-02 07:03:13 --> Total execution time: 0.0746
INFO - 2023-05-02 07:03:15 --> Config Class Initialized
INFO - 2023-05-02 07:03:15 --> Hooks Class Initialized
DEBUG - 2023-05-02 07:03:15 --> UTF-8 Support Enabled
INFO - 2023-05-02 07:03:15 --> Utf8 Class Initialized
INFO - 2023-05-02 07:03:15 --> URI Class Initialized
INFO - 2023-05-02 07:03:15 --> Router Class Initialized
INFO - 2023-05-02 07:03:15 --> Output Class Initialized
INFO - 2023-05-02 07:03:15 --> Security Class Initialized
DEBUG - 2023-05-02 07:03:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-02 07:03:15 --> Input Class Initialized
INFO - 2023-05-02 07:03:15 --> Language Class Initialized
INFO - 2023-05-02 07:03:15 --> Language Class Initialized
INFO - 2023-05-02 07:03:15 --> Config Class Initialized
INFO - 2023-05-02 07:03:15 --> Loader Class Initialized
INFO - 2023-05-02 07:03:15 --> Helper loaded: url_helper
INFO - 2023-05-02 07:03:15 --> Helper loaded: file_helper
INFO - 2023-05-02 07:03:15 --> Helper loaded: form_helper
INFO - 2023-05-02 07:03:15 --> Helper loaded: my_helper
INFO - 2023-05-02 07:03:15 --> Database Driver Class Initialized
DEBUG - 2023-05-02 07:03:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-05-02 07:03:15 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-02 07:03:15 --> Controller Class Initialized
INFO - 2023-05-02 07:03:15 --> Final output sent to browser
DEBUG - 2023-05-02 07:03:15 --> Total execution time: 0.1799
INFO - 2023-05-02 07:03:21 --> Config Class Initialized
INFO - 2023-05-02 07:03:21 --> Hooks Class Initialized
DEBUG - 2023-05-02 07:03:21 --> UTF-8 Support Enabled
INFO - 2023-05-02 07:03:21 --> Utf8 Class Initialized
INFO - 2023-05-02 07:03:21 --> URI Class Initialized
INFO - 2023-05-02 07:03:21 --> Router Class Initialized
INFO - 2023-05-02 07:03:21 --> Output Class Initialized
INFO - 2023-05-02 07:03:21 --> Security Class Initialized
DEBUG - 2023-05-02 07:03:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-02 07:03:21 --> Input Class Initialized
INFO - 2023-05-02 07:03:21 --> Language Class Initialized
INFO - 2023-05-02 07:03:21 --> Language Class Initialized
INFO - 2023-05-02 07:03:21 --> Config Class Initialized
INFO - 2023-05-02 07:03:21 --> Loader Class Initialized
INFO - 2023-05-02 07:03:21 --> Helper loaded: url_helper
INFO - 2023-05-02 07:03:21 --> Helper loaded: file_helper
INFO - 2023-05-02 07:03:21 --> Helper loaded: form_helper
INFO - 2023-05-02 07:03:21 --> Helper loaded: my_helper
INFO - 2023-05-02 07:03:21 --> Database Driver Class Initialized
DEBUG - 2023-05-02 07:03:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-05-02 07:03:21 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-02 07:03:21 --> Controller Class Initialized
INFO - 2023-05-02 07:03:21 --> Final output sent to browser
DEBUG - 2023-05-02 07:03:21 --> Total execution time: 0.1266
INFO - 2023-05-02 07:03:22 --> Config Class Initialized
INFO - 2023-05-02 07:03:22 --> Hooks Class Initialized
DEBUG - 2023-05-02 07:03:22 --> UTF-8 Support Enabled
INFO - 2023-05-02 07:03:22 --> Utf8 Class Initialized
INFO - 2023-05-02 07:03:22 --> URI Class Initialized
INFO - 2023-05-02 07:03:22 --> Router Class Initialized
INFO - 2023-05-02 07:03:22 --> Output Class Initialized
INFO - 2023-05-02 07:03:22 --> Security Class Initialized
DEBUG - 2023-05-02 07:03:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-02 07:03:22 --> Input Class Initialized
INFO - 2023-05-02 07:03:22 --> Language Class Initialized
INFO - 2023-05-02 07:03:22 --> Language Class Initialized
INFO - 2023-05-02 07:03:22 --> Config Class Initialized
INFO - 2023-05-02 07:03:22 --> Loader Class Initialized
INFO - 2023-05-02 07:03:22 --> Helper loaded: url_helper
INFO - 2023-05-02 07:03:22 --> Helper loaded: file_helper
INFO - 2023-05-02 07:03:22 --> Helper loaded: form_helper
INFO - 2023-05-02 07:03:22 --> Helper loaded: my_helper
INFO - 2023-05-02 07:03:22 --> Database Driver Class Initialized
DEBUG - 2023-05-02 07:03:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-05-02 07:03:22 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-02 07:03:22 --> Controller Class Initialized
DEBUG - 2023-05-02 07:03:22 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/n_catatan_nna/views/list.php
DEBUG - 2023-05-02 07:03:22 --> File loaded: C:\xampp\htdocs\myraportk13\application\views\template_utama.php
INFO - 2023-05-02 07:03:22 --> Final output sent to browser
DEBUG - 2023-05-02 07:03:22 --> Total execution time: 0.0612
INFO - 2023-05-02 07:05:27 --> Config Class Initialized
INFO - 2023-05-02 07:05:27 --> Hooks Class Initialized
DEBUG - 2023-05-02 07:05:27 --> UTF-8 Support Enabled
INFO - 2023-05-02 07:05:27 --> Utf8 Class Initialized
INFO - 2023-05-02 07:05:27 --> URI Class Initialized
INFO - 2023-05-02 07:05:27 --> Router Class Initialized
INFO - 2023-05-02 07:05:27 --> Output Class Initialized
INFO - 2023-05-02 07:05:27 --> Security Class Initialized
DEBUG - 2023-05-02 07:05:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-02 07:05:27 --> Input Class Initialized
INFO - 2023-05-02 07:05:27 --> Language Class Initialized
INFO - 2023-05-02 07:05:27 --> Language Class Initialized
INFO - 2023-05-02 07:05:27 --> Config Class Initialized
INFO - 2023-05-02 07:05:27 --> Loader Class Initialized
INFO - 2023-05-02 07:05:27 --> Helper loaded: url_helper
INFO - 2023-05-02 07:05:27 --> Helper loaded: file_helper
INFO - 2023-05-02 07:05:27 --> Helper loaded: form_helper
INFO - 2023-05-02 07:05:27 --> Helper loaded: my_helper
INFO - 2023-05-02 07:05:27 --> Database Driver Class Initialized
DEBUG - 2023-05-02 07:05:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-05-02 07:05:27 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-02 07:05:27 --> Controller Class Initialized
DEBUG - 2023-05-02 07:05:27 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/n_catatan_nna/views/list.php
DEBUG - 2023-05-02 07:05:27 --> File loaded: C:\xampp\htdocs\myraportk13\application\views\template_utama.php
INFO - 2023-05-02 07:05:27 --> Final output sent to browser
DEBUG - 2023-05-02 07:05:27 --> Total execution time: 0.0909
INFO - 2023-05-02 07:05:28 --> Config Class Initialized
INFO - 2023-05-02 07:05:28 --> Hooks Class Initialized
DEBUG - 2023-05-02 07:05:28 --> UTF-8 Support Enabled
INFO - 2023-05-02 07:05:28 --> Utf8 Class Initialized
INFO - 2023-05-02 07:05:28 --> URI Class Initialized
INFO - 2023-05-02 07:05:28 --> Router Class Initialized
INFO - 2023-05-02 07:05:28 --> Output Class Initialized
INFO - 2023-05-02 07:05:28 --> Security Class Initialized
DEBUG - 2023-05-02 07:05:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-02 07:05:28 --> Input Class Initialized
INFO - 2023-05-02 07:05:28 --> Language Class Initialized
INFO - 2023-05-02 07:05:28 --> Language Class Initialized
INFO - 2023-05-02 07:05:28 --> Config Class Initialized
INFO - 2023-05-02 07:05:28 --> Loader Class Initialized
INFO - 2023-05-02 07:05:28 --> Helper loaded: url_helper
INFO - 2023-05-02 07:05:28 --> Helper loaded: file_helper
INFO - 2023-05-02 07:05:28 --> Helper loaded: form_helper
INFO - 2023-05-02 07:05:28 --> Helper loaded: my_helper
INFO - 2023-05-02 07:05:28 --> Database Driver Class Initialized
DEBUG - 2023-05-02 07:05:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-05-02 07:05:28 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-02 07:05:28 --> Controller Class Initialized
INFO - 2023-05-02 07:10:54 --> Config Class Initialized
INFO - 2023-05-02 07:10:54 --> Hooks Class Initialized
DEBUG - 2023-05-02 07:10:54 --> UTF-8 Support Enabled
INFO - 2023-05-02 07:10:54 --> Utf8 Class Initialized
INFO - 2023-05-02 07:10:54 --> URI Class Initialized
INFO - 2023-05-02 07:10:54 --> Router Class Initialized
INFO - 2023-05-02 07:10:54 --> Output Class Initialized
INFO - 2023-05-02 07:10:54 --> Security Class Initialized
DEBUG - 2023-05-02 07:10:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-02 07:10:54 --> Input Class Initialized
INFO - 2023-05-02 07:10:54 --> Language Class Initialized
INFO - 2023-05-02 07:10:54 --> Language Class Initialized
INFO - 2023-05-02 07:10:54 --> Config Class Initialized
INFO - 2023-05-02 07:10:54 --> Loader Class Initialized
INFO - 2023-05-02 07:10:54 --> Helper loaded: url_helper
INFO - 2023-05-02 07:10:54 --> Helper loaded: file_helper
INFO - 2023-05-02 07:10:54 --> Helper loaded: form_helper
INFO - 2023-05-02 07:10:54 --> Helper loaded: my_helper
INFO - 2023-05-02 07:10:54 --> Database Driver Class Initialized
DEBUG - 2023-05-02 07:10:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-05-02 07:10:54 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-02 07:10:54 --> Controller Class Initialized
INFO - 2023-05-02 07:11:29 --> Config Class Initialized
INFO - 2023-05-02 07:11:29 --> Hooks Class Initialized
DEBUG - 2023-05-02 07:11:29 --> UTF-8 Support Enabled
INFO - 2023-05-02 07:11:29 --> Utf8 Class Initialized
INFO - 2023-05-02 07:11:29 --> URI Class Initialized
INFO - 2023-05-02 07:11:29 --> Router Class Initialized
INFO - 2023-05-02 07:11:29 --> Output Class Initialized
INFO - 2023-05-02 07:11:29 --> Security Class Initialized
DEBUG - 2023-05-02 07:11:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-02 07:11:29 --> Input Class Initialized
INFO - 2023-05-02 07:11:29 --> Language Class Initialized
INFO - 2023-05-02 07:11:29 --> Language Class Initialized
INFO - 2023-05-02 07:11:29 --> Config Class Initialized
INFO - 2023-05-02 07:11:29 --> Loader Class Initialized
INFO - 2023-05-02 07:11:29 --> Helper loaded: url_helper
INFO - 2023-05-02 07:11:29 --> Helper loaded: file_helper
INFO - 2023-05-02 07:11:29 --> Helper loaded: form_helper
INFO - 2023-05-02 07:11:29 --> Helper loaded: my_helper
INFO - 2023-05-02 07:11:29 --> Database Driver Class Initialized
DEBUG - 2023-05-02 07:11:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-05-02 07:11:29 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-02 07:11:29 --> Controller Class Initialized
INFO - 2023-05-02 07:13:23 --> Config Class Initialized
INFO - 2023-05-02 07:13:23 --> Hooks Class Initialized
DEBUG - 2023-05-02 07:13:23 --> UTF-8 Support Enabled
INFO - 2023-05-02 07:13:23 --> Utf8 Class Initialized
INFO - 2023-05-02 07:13:23 --> URI Class Initialized
INFO - 2023-05-02 07:13:23 --> Router Class Initialized
INFO - 2023-05-02 07:13:23 --> Output Class Initialized
INFO - 2023-05-02 07:13:23 --> Security Class Initialized
DEBUG - 2023-05-02 07:13:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-02 07:13:23 --> Input Class Initialized
INFO - 2023-05-02 07:13:23 --> Language Class Initialized
INFO - 2023-05-02 07:13:23 --> Language Class Initialized
INFO - 2023-05-02 07:13:23 --> Config Class Initialized
INFO - 2023-05-02 07:13:23 --> Loader Class Initialized
INFO - 2023-05-02 07:13:23 --> Helper loaded: url_helper
INFO - 2023-05-02 07:13:23 --> Helper loaded: file_helper
INFO - 2023-05-02 07:13:23 --> Helper loaded: form_helper
INFO - 2023-05-02 07:13:23 --> Helper loaded: my_helper
INFO - 2023-05-02 07:13:23 --> Database Driver Class Initialized
DEBUG - 2023-05-02 07:13:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-05-02 07:13:23 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-02 07:13:23 --> Controller Class Initialized
INFO - 2023-05-02 07:14:50 --> Config Class Initialized
INFO - 2023-05-02 07:14:50 --> Hooks Class Initialized
DEBUG - 2023-05-02 07:14:50 --> UTF-8 Support Enabled
INFO - 2023-05-02 07:14:50 --> Utf8 Class Initialized
INFO - 2023-05-02 07:14:50 --> URI Class Initialized
INFO - 2023-05-02 07:14:50 --> Router Class Initialized
INFO - 2023-05-02 07:14:50 --> Output Class Initialized
INFO - 2023-05-02 07:14:50 --> Security Class Initialized
DEBUG - 2023-05-02 07:14:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-02 07:14:50 --> Input Class Initialized
INFO - 2023-05-02 07:14:50 --> Language Class Initialized
INFO - 2023-05-02 07:14:50 --> Language Class Initialized
INFO - 2023-05-02 07:14:50 --> Config Class Initialized
INFO - 2023-05-02 07:14:50 --> Loader Class Initialized
INFO - 2023-05-02 07:14:50 --> Helper loaded: url_helper
INFO - 2023-05-02 07:14:50 --> Helper loaded: file_helper
INFO - 2023-05-02 07:14:50 --> Helper loaded: form_helper
INFO - 2023-05-02 07:14:50 --> Helper loaded: my_helper
INFO - 2023-05-02 07:14:50 --> Database Driver Class Initialized
DEBUG - 2023-05-02 07:14:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-05-02 07:14:50 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-02 07:14:50 --> Controller Class Initialized
INFO - 2023-05-02 07:16:15 --> Config Class Initialized
INFO - 2023-05-02 07:16:15 --> Hooks Class Initialized
DEBUG - 2023-05-02 07:16:15 --> UTF-8 Support Enabled
INFO - 2023-05-02 07:16:15 --> Utf8 Class Initialized
INFO - 2023-05-02 07:16:15 --> URI Class Initialized
INFO - 2023-05-02 07:16:15 --> Router Class Initialized
INFO - 2023-05-02 07:16:16 --> Output Class Initialized
INFO - 2023-05-02 07:16:16 --> Security Class Initialized
DEBUG - 2023-05-02 07:16:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-02 07:16:16 --> Input Class Initialized
INFO - 2023-05-02 07:16:16 --> Language Class Initialized
INFO - 2023-05-02 07:16:16 --> Language Class Initialized
INFO - 2023-05-02 07:16:16 --> Config Class Initialized
INFO - 2023-05-02 07:16:16 --> Loader Class Initialized
INFO - 2023-05-02 07:16:16 --> Helper loaded: url_helper
INFO - 2023-05-02 07:16:16 --> Helper loaded: file_helper
INFO - 2023-05-02 07:16:16 --> Helper loaded: form_helper
INFO - 2023-05-02 07:16:16 --> Helper loaded: my_helper
INFO - 2023-05-02 07:16:16 --> Database Driver Class Initialized
DEBUG - 2023-05-02 07:16:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-05-02 07:16:16 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-02 07:16:16 --> Controller Class Initialized
INFO - 2023-05-02 07:17:40 --> Config Class Initialized
INFO - 2023-05-02 07:17:40 --> Hooks Class Initialized
DEBUG - 2023-05-02 07:17:40 --> UTF-8 Support Enabled
INFO - 2023-05-02 07:17:40 --> Utf8 Class Initialized
INFO - 2023-05-02 07:17:40 --> URI Class Initialized
INFO - 2023-05-02 07:17:40 --> Router Class Initialized
INFO - 2023-05-02 07:17:40 --> Output Class Initialized
INFO - 2023-05-02 07:17:40 --> Security Class Initialized
DEBUG - 2023-05-02 07:17:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-02 07:17:40 --> Input Class Initialized
INFO - 2023-05-02 07:17:40 --> Language Class Initialized
INFO - 2023-05-02 07:17:40 --> Language Class Initialized
INFO - 2023-05-02 07:17:40 --> Config Class Initialized
INFO - 2023-05-02 07:17:40 --> Loader Class Initialized
INFO - 2023-05-02 07:17:40 --> Helper loaded: url_helper
INFO - 2023-05-02 07:17:40 --> Helper loaded: file_helper
INFO - 2023-05-02 07:17:40 --> Helper loaded: form_helper
INFO - 2023-05-02 07:17:40 --> Helper loaded: my_helper
INFO - 2023-05-02 07:17:40 --> Database Driver Class Initialized
DEBUG - 2023-05-02 07:17:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-05-02 07:17:40 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-02 07:17:40 --> Controller Class Initialized
INFO - 2023-05-02 07:18:28 --> Config Class Initialized
INFO - 2023-05-02 07:18:28 --> Hooks Class Initialized
DEBUG - 2023-05-02 07:18:28 --> UTF-8 Support Enabled
INFO - 2023-05-02 07:18:28 --> Utf8 Class Initialized
INFO - 2023-05-02 07:18:28 --> URI Class Initialized
INFO - 2023-05-02 07:18:28 --> Router Class Initialized
INFO - 2023-05-02 07:18:28 --> Output Class Initialized
INFO - 2023-05-02 07:18:28 --> Security Class Initialized
DEBUG - 2023-05-02 07:18:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-02 07:18:28 --> Input Class Initialized
INFO - 2023-05-02 07:18:28 --> Language Class Initialized
INFO - 2023-05-02 07:18:28 --> Language Class Initialized
INFO - 2023-05-02 07:18:28 --> Config Class Initialized
INFO - 2023-05-02 07:18:28 --> Loader Class Initialized
INFO - 2023-05-02 07:18:28 --> Helper loaded: url_helper
INFO - 2023-05-02 07:18:28 --> Helper loaded: file_helper
INFO - 2023-05-02 07:18:28 --> Helper loaded: form_helper
INFO - 2023-05-02 07:18:28 --> Helper loaded: my_helper
INFO - 2023-05-02 07:18:28 --> Database Driver Class Initialized
DEBUG - 2023-05-02 07:18:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-05-02 07:18:28 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-02 07:18:28 --> Controller Class Initialized
INFO - 2023-05-02 07:18:56 --> Config Class Initialized
INFO - 2023-05-02 07:18:56 --> Hooks Class Initialized
DEBUG - 2023-05-02 07:18:56 --> UTF-8 Support Enabled
INFO - 2023-05-02 07:18:56 --> Utf8 Class Initialized
INFO - 2023-05-02 07:18:56 --> URI Class Initialized
INFO - 2023-05-02 07:18:56 --> Router Class Initialized
INFO - 2023-05-02 07:18:56 --> Output Class Initialized
INFO - 2023-05-02 07:18:56 --> Security Class Initialized
DEBUG - 2023-05-02 07:18:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-02 07:18:56 --> Input Class Initialized
INFO - 2023-05-02 07:18:56 --> Language Class Initialized
INFO - 2023-05-02 07:18:56 --> Language Class Initialized
INFO - 2023-05-02 07:18:56 --> Config Class Initialized
INFO - 2023-05-02 07:18:56 --> Loader Class Initialized
INFO - 2023-05-02 07:18:56 --> Helper loaded: url_helper
INFO - 2023-05-02 07:18:56 --> Helper loaded: file_helper
INFO - 2023-05-02 07:18:56 --> Helper loaded: form_helper
INFO - 2023-05-02 07:18:56 --> Helper loaded: my_helper
INFO - 2023-05-02 07:18:56 --> Database Driver Class Initialized
DEBUG - 2023-05-02 07:18:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-05-02 07:18:56 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-02 07:18:56 --> Controller Class Initialized
DEBUG - 2023-05-02 07:18:56 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/n_catatan_nna/views/list.php
DEBUG - 2023-05-02 07:18:56 --> File loaded: C:\xampp\htdocs\myraportk13\application\views\template_utama.php
INFO - 2023-05-02 07:18:56 --> Final output sent to browser
DEBUG - 2023-05-02 07:18:56 --> Total execution time: 0.0377
INFO - 2023-05-02 07:18:57 --> Config Class Initialized
INFO - 2023-05-02 07:18:57 --> Hooks Class Initialized
DEBUG - 2023-05-02 07:18:57 --> UTF-8 Support Enabled
INFO - 2023-05-02 07:18:57 --> Utf8 Class Initialized
INFO - 2023-05-02 07:18:57 --> URI Class Initialized
INFO - 2023-05-02 07:18:57 --> Router Class Initialized
INFO - 2023-05-02 07:18:57 --> Output Class Initialized
INFO - 2023-05-02 07:18:57 --> Security Class Initialized
DEBUG - 2023-05-02 07:18:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-02 07:18:57 --> Input Class Initialized
INFO - 2023-05-02 07:18:57 --> Language Class Initialized
INFO - 2023-05-02 07:18:57 --> Language Class Initialized
INFO - 2023-05-02 07:18:57 --> Config Class Initialized
INFO - 2023-05-02 07:18:57 --> Loader Class Initialized
INFO - 2023-05-02 07:18:57 --> Helper loaded: url_helper
INFO - 2023-05-02 07:18:57 --> Helper loaded: file_helper
INFO - 2023-05-02 07:18:57 --> Helper loaded: form_helper
INFO - 2023-05-02 07:18:57 --> Helper loaded: my_helper
INFO - 2023-05-02 07:18:57 --> Database Driver Class Initialized
DEBUG - 2023-05-02 07:18:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-05-02 07:18:57 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-02 07:18:57 --> Controller Class Initialized
INFO - 2023-05-02 07:21:47 --> Config Class Initialized
INFO - 2023-05-02 07:21:47 --> Hooks Class Initialized
DEBUG - 2023-05-02 07:21:47 --> UTF-8 Support Enabled
INFO - 2023-05-02 07:21:47 --> Utf8 Class Initialized
INFO - 2023-05-02 07:21:47 --> URI Class Initialized
INFO - 2023-05-02 07:21:47 --> Router Class Initialized
INFO - 2023-05-02 07:21:47 --> Output Class Initialized
INFO - 2023-05-02 07:21:47 --> Security Class Initialized
DEBUG - 2023-05-02 07:21:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-02 07:21:47 --> Input Class Initialized
INFO - 2023-05-02 07:21:47 --> Language Class Initialized
INFO - 2023-05-02 07:21:48 --> Language Class Initialized
INFO - 2023-05-02 07:21:48 --> Config Class Initialized
INFO - 2023-05-02 07:21:48 --> Loader Class Initialized
INFO - 2023-05-02 07:21:48 --> Helper loaded: url_helper
INFO - 2023-05-02 07:21:48 --> Helper loaded: file_helper
INFO - 2023-05-02 07:21:48 --> Helper loaded: form_helper
INFO - 2023-05-02 07:21:48 --> Helper loaded: my_helper
INFO - 2023-05-02 07:21:48 --> Database Driver Class Initialized
DEBUG - 2023-05-02 07:21:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-05-02 07:21:48 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-02 07:21:48 --> Controller Class Initialized
ERROR - 2023-05-02 07:21:48 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near 'ON a.id_guru = d.id 
        WHERE id = 13' at line 2 - Invalid query: SELECT *
        FROM m_guru d ON a.id_guru = d.id 
        WHERE id = 13
INFO - 2023-05-02 07:21:48 --> Language file loaded: language/english/db_lang.php
INFO - 2023-05-02 07:22:08 --> Config Class Initialized
INFO - 2023-05-02 07:22:08 --> Hooks Class Initialized
DEBUG - 2023-05-02 07:22:08 --> UTF-8 Support Enabled
INFO - 2023-05-02 07:22:08 --> Utf8 Class Initialized
INFO - 2023-05-02 07:22:08 --> URI Class Initialized
INFO - 2023-05-02 07:22:08 --> Router Class Initialized
INFO - 2023-05-02 07:22:08 --> Output Class Initialized
INFO - 2023-05-02 07:22:08 --> Security Class Initialized
DEBUG - 2023-05-02 07:22:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-02 07:22:08 --> Input Class Initialized
INFO - 2023-05-02 07:22:08 --> Language Class Initialized
INFO - 2023-05-02 07:22:08 --> Language Class Initialized
INFO - 2023-05-02 07:22:08 --> Config Class Initialized
INFO - 2023-05-02 07:22:08 --> Loader Class Initialized
INFO - 2023-05-02 07:22:08 --> Helper loaded: url_helper
INFO - 2023-05-02 07:22:08 --> Helper loaded: file_helper
INFO - 2023-05-02 07:22:08 --> Helper loaded: form_helper
INFO - 2023-05-02 07:22:08 --> Helper loaded: my_helper
INFO - 2023-05-02 07:22:08 --> Database Driver Class Initialized
DEBUG - 2023-05-02 07:22:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-05-02 07:22:08 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-02 07:22:08 --> Controller Class Initialized
DEBUG - 2023-05-02 07:22:08 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/n_catatan_nna/views/list.php
DEBUG - 2023-05-02 07:22:08 --> File loaded: C:\xampp\htdocs\myraportk13\application\views\template_utama.php
INFO - 2023-05-02 07:22:08 --> Final output sent to browser
DEBUG - 2023-05-02 07:22:08 --> Total execution time: 0.0532
INFO - 2023-05-02 07:22:08 --> Config Class Initialized
INFO - 2023-05-02 07:22:08 --> Hooks Class Initialized
DEBUG - 2023-05-02 07:22:08 --> UTF-8 Support Enabled
INFO - 2023-05-02 07:22:08 --> Utf8 Class Initialized
INFO - 2023-05-02 07:22:08 --> URI Class Initialized
INFO - 2023-05-02 07:22:08 --> Router Class Initialized
INFO - 2023-05-02 07:22:08 --> Output Class Initialized
INFO - 2023-05-02 07:22:08 --> Security Class Initialized
DEBUG - 2023-05-02 07:22:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-02 07:22:08 --> Input Class Initialized
INFO - 2023-05-02 07:22:08 --> Language Class Initialized
INFO - 2023-05-02 07:22:08 --> Language Class Initialized
INFO - 2023-05-02 07:22:08 --> Config Class Initialized
INFO - 2023-05-02 07:22:08 --> Loader Class Initialized
INFO - 2023-05-02 07:22:08 --> Helper loaded: url_helper
INFO - 2023-05-02 07:22:08 --> Helper loaded: file_helper
INFO - 2023-05-02 07:22:08 --> Helper loaded: form_helper
INFO - 2023-05-02 07:22:08 --> Helper loaded: my_helper
INFO - 2023-05-02 07:22:08 --> Database Driver Class Initialized
DEBUG - 2023-05-02 07:22:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-05-02 07:22:08 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-02 07:22:08 --> Controller Class Initialized
DEBUG - 2023-05-02 07:22:08 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/n_catatan_nna/views/list.php
DEBUG - 2023-05-02 07:22:08 --> File loaded: C:\xampp\htdocs\myraportk13\application\views\template_utama.php
INFO - 2023-05-02 07:22:08 --> Final output sent to browser
DEBUG - 2023-05-02 07:22:08 --> Total execution time: 0.0432
INFO - 2023-05-02 07:22:09 --> Config Class Initialized
INFO - 2023-05-02 07:22:09 --> Hooks Class Initialized
DEBUG - 2023-05-02 07:22:09 --> UTF-8 Support Enabled
INFO - 2023-05-02 07:22:09 --> Utf8 Class Initialized
INFO - 2023-05-02 07:22:09 --> URI Class Initialized
INFO - 2023-05-02 07:22:09 --> Router Class Initialized
INFO - 2023-05-02 07:22:09 --> Output Class Initialized
INFO - 2023-05-02 07:22:09 --> Security Class Initialized
DEBUG - 2023-05-02 07:22:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-02 07:22:09 --> Input Class Initialized
INFO - 2023-05-02 07:22:09 --> Language Class Initialized
INFO - 2023-05-02 07:22:09 --> Language Class Initialized
INFO - 2023-05-02 07:22:09 --> Config Class Initialized
INFO - 2023-05-02 07:22:09 --> Loader Class Initialized
INFO - 2023-05-02 07:22:09 --> Helper loaded: url_helper
INFO - 2023-05-02 07:22:09 --> Helper loaded: file_helper
INFO - 2023-05-02 07:22:09 --> Helper loaded: form_helper
INFO - 2023-05-02 07:22:09 --> Helper loaded: my_helper
INFO - 2023-05-02 07:22:09 --> Database Driver Class Initialized
DEBUG - 2023-05-02 07:22:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-05-02 07:22:09 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-02 07:22:09 --> Controller Class Initialized
INFO - 2023-05-02 07:23:13 --> Config Class Initialized
INFO - 2023-05-02 07:23:13 --> Hooks Class Initialized
DEBUG - 2023-05-02 07:23:13 --> UTF-8 Support Enabled
INFO - 2023-05-02 07:23:13 --> Utf8 Class Initialized
INFO - 2023-05-02 07:23:13 --> URI Class Initialized
INFO - 2023-05-02 07:23:13 --> Router Class Initialized
INFO - 2023-05-02 07:23:13 --> Output Class Initialized
INFO - 2023-05-02 07:23:13 --> Security Class Initialized
DEBUG - 2023-05-02 07:23:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-02 07:23:13 --> Input Class Initialized
INFO - 2023-05-02 07:23:13 --> Language Class Initialized
INFO - 2023-05-02 07:23:13 --> Language Class Initialized
INFO - 2023-05-02 07:23:13 --> Config Class Initialized
INFO - 2023-05-02 07:23:13 --> Loader Class Initialized
INFO - 2023-05-02 07:23:13 --> Helper loaded: url_helper
INFO - 2023-05-02 07:23:13 --> Helper loaded: file_helper
INFO - 2023-05-02 07:23:13 --> Helper loaded: form_helper
INFO - 2023-05-02 07:23:13 --> Helper loaded: my_helper
INFO - 2023-05-02 07:23:13 --> Database Driver Class Initialized
DEBUG - 2023-05-02 07:23:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-05-02 07:23:13 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-02 07:23:13 --> Controller Class Initialized
INFO - 2023-05-02 07:25:01 --> Config Class Initialized
INFO - 2023-05-02 07:25:01 --> Hooks Class Initialized
DEBUG - 2023-05-02 07:25:01 --> UTF-8 Support Enabled
INFO - 2023-05-02 07:25:01 --> Utf8 Class Initialized
INFO - 2023-05-02 07:25:01 --> URI Class Initialized
INFO - 2023-05-02 07:25:01 --> Router Class Initialized
INFO - 2023-05-02 07:25:01 --> Output Class Initialized
INFO - 2023-05-02 07:25:01 --> Security Class Initialized
DEBUG - 2023-05-02 07:25:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-02 07:25:01 --> Input Class Initialized
INFO - 2023-05-02 07:25:01 --> Language Class Initialized
INFO - 2023-05-02 07:25:01 --> Language Class Initialized
INFO - 2023-05-02 07:25:01 --> Config Class Initialized
INFO - 2023-05-02 07:25:01 --> Loader Class Initialized
INFO - 2023-05-02 07:25:01 --> Helper loaded: url_helper
INFO - 2023-05-02 07:25:01 --> Helper loaded: file_helper
INFO - 2023-05-02 07:25:01 --> Helper loaded: form_helper
INFO - 2023-05-02 07:25:01 --> Helper loaded: my_helper
INFO - 2023-05-02 07:25:01 --> Database Driver Class Initialized
DEBUG - 2023-05-02 07:25:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-05-02 07:25:01 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-02 07:25:01 --> Controller Class Initialized
INFO - 2023-05-02 07:25:27 --> Config Class Initialized
INFO - 2023-05-02 07:25:27 --> Hooks Class Initialized
DEBUG - 2023-05-02 07:25:27 --> UTF-8 Support Enabled
INFO - 2023-05-02 07:25:27 --> Utf8 Class Initialized
INFO - 2023-05-02 07:25:27 --> URI Class Initialized
INFO - 2023-05-02 07:25:27 --> Router Class Initialized
INFO - 2023-05-02 07:25:27 --> Output Class Initialized
INFO - 2023-05-02 07:25:27 --> Security Class Initialized
DEBUG - 2023-05-02 07:25:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-02 07:25:27 --> Input Class Initialized
INFO - 2023-05-02 07:25:27 --> Language Class Initialized
INFO - 2023-05-02 07:25:27 --> Language Class Initialized
INFO - 2023-05-02 07:25:27 --> Config Class Initialized
INFO - 2023-05-02 07:25:27 --> Loader Class Initialized
INFO - 2023-05-02 07:25:27 --> Helper loaded: url_helper
INFO - 2023-05-02 07:25:27 --> Helper loaded: file_helper
INFO - 2023-05-02 07:25:27 --> Helper loaded: form_helper
INFO - 2023-05-02 07:25:27 --> Helper loaded: my_helper
INFO - 2023-05-02 07:25:27 --> Database Driver Class Initialized
DEBUG - 2023-05-02 07:25:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-05-02 07:25:27 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-02 07:25:27 --> Controller Class Initialized
INFO - 2023-05-02 07:27:08 --> Config Class Initialized
INFO - 2023-05-02 07:27:08 --> Hooks Class Initialized
DEBUG - 2023-05-02 07:27:08 --> UTF-8 Support Enabled
INFO - 2023-05-02 07:27:08 --> Utf8 Class Initialized
INFO - 2023-05-02 07:27:08 --> URI Class Initialized
INFO - 2023-05-02 07:27:08 --> Router Class Initialized
INFO - 2023-05-02 07:27:08 --> Output Class Initialized
INFO - 2023-05-02 07:27:08 --> Security Class Initialized
DEBUG - 2023-05-02 07:27:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-02 07:27:08 --> Input Class Initialized
INFO - 2023-05-02 07:27:08 --> Language Class Initialized
INFO - 2023-05-02 07:27:08 --> Language Class Initialized
INFO - 2023-05-02 07:27:08 --> Config Class Initialized
INFO - 2023-05-02 07:27:08 --> Loader Class Initialized
INFO - 2023-05-02 07:27:08 --> Helper loaded: url_helper
INFO - 2023-05-02 07:27:08 --> Helper loaded: file_helper
INFO - 2023-05-02 07:27:08 --> Helper loaded: form_helper
INFO - 2023-05-02 07:27:08 --> Helper loaded: my_helper
INFO - 2023-05-02 07:27:08 --> Database Driver Class Initialized
DEBUG - 2023-05-02 07:27:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-05-02 07:27:08 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-02 07:27:08 --> Controller Class Initialized
INFO - 2023-05-02 07:29:54 --> Config Class Initialized
INFO - 2023-05-02 07:29:54 --> Hooks Class Initialized
DEBUG - 2023-05-02 07:29:54 --> UTF-8 Support Enabled
INFO - 2023-05-02 07:29:54 --> Utf8 Class Initialized
INFO - 2023-05-02 07:29:54 --> URI Class Initialized
INFO - 2023-05-02 07:29:54 --> Router Class Initialized
INFO - 2023-05-02 07:29:54 --> Output Class Initialized
INFO - 2023-05-02 07:29:54 --> Security Class Initialized
DEBUG - 2023-05-02 07:29:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-02 07:29:54 --> Input Class Initialized
INFO - 2023-05-02 07:29:54 --> Language Class Initialized
INFO - 2023-05-02 07:29:54 --> Language Class Initialized
INFO - 2023-05-02 07:29:54 --> Config Class Initialized
INFO - 2023-05-02 07:29:54 --> Loader Class Initialized
INFO - 2023-05-02 07:29:54 --> Helper loaded: url_helper
INFO - 2023-05-02 07:29:54 --> Helper loaded: file_helper
INFO - 2023-05-02 07:29:54 --> Helper loaded: form_helper
INFO - 2023-05-02 07:29:54 --> Helper loaded: my_helper
INFO - 2023-05-02 07:29:54 --> Database Driver Class Initialized
DEBUG - 2023-05-02 07:29:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-05-02 07:29:54 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-02 07:29:54 --> Controller Class Initialized
INFO - 2023-05-02 07:40:31 --> Config Class Initialized
INFO - 2023-05-02 07:40:31 --> Hooks Class Initialized
DEBUG - 2023-05-02 07:40:31 --> UTF-8 Support Enabled
INFO - 2023-05-02 07:40:31 --> Utf8 Class Initialized
INFO - 2023-05-02 07:40:31 --> URI Class Initialized
INFO - 2023-05-02 07:40:31 --> Router Class Initialized
INFO - 2023-05-02 07:40:31 --> Output Class Initialized
INFO - 2023-05-02 07:40:31 --> Security Class Initialized
DEBUG - 2023-05-02 07:40:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-02 07:40:31 --> Input Class Initialized
INFO - 2023-05-02 07:40:31 --> Language Class Initialized
ERROR - 2023-05-02 07:40:31 --> Severity: Compile Error --> Cannot use [] for reading C:\xampp\htdocs\myraportk13\application\modules\n_catatan_nna\controllers\N_catatan_nna.php 132
INFO - 2023-05-02 07:40:41 --> Config Class Initialized
INFO - 2023-05-02 07:40:41 --> Hooks Class Initialized
DEBUG - 2023-05-02 07:40:41 --> UTF-8 Support Enabled
INFO - 2023-05-02 07:40:41 --> Utf8 Class Initialized
INFO - 2023-05-02 07:40:41 --> URI Class Initialized
INFO - 2023-05-02 07:40:41 --> Router Class Initialized
INFO - 2023-05-02 07:40:41 --> Output Class Initialized
INFO - 2023-05-02 07:40:41 --> Security Class Initialized
DEBUG - 2023-05-02 07:40:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-02 07:40:41 --> Input Class Initialized
INFO - 2023-05-02 07:40:41 --> Language Class Initialized
INFO - 2023-05-02 07:40:41 --> Language Class Initialized
INFO - 2023-05-02 07:40:41 --> Config Class Initialized
INFO - 2023-05-02 07:40:41 --> Loader Class Initialized
INFO - 2023-05-02 07:40:41 --> Helper loaded: url_helper
INFO - 2023-05-02 07:40:41 --> Helper loaded: file_helper
INFO - 2023-05-02 07:40:41 --> Helper loaded: form_helper
INFO - 2023-05-02 07:40:41 --> Helper loaded: my_helper
INFO - 2023-05-02 07:40:41 --> Database Driver Class Initialized
DEBUG - 2023-05-02 07:40:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-05-02 07:40:41 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-02 07:40:41 --> Controller Class Initialized
DEBUG - 2023-05-02 07:40:41 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/n_catatan_nna/views/list.php
DEBUG - 2023-05-02 07:40:41 --> File loaded: C:\xampp\htdocs\myraportk13\application\views\template_utama.php
INFO - 2023-05-02 07:40:41 --> Final output sent to browser
DEBUG - 2023-05-02 07:40:41 --> Total execution time: 0.0583
INFO - 2023-05-02 07:40:42 --> Config Class Initialized
INFO - 2023-05-02 07:40:42 --> Hooks Class Initialized
DEBUG - 2023-05-02 07:40:42 --> UTF-8 Support Enabled
INFO - 2023-05-02 07:40:42 --> Utf8 Class Initialized
INFO - 2023-05-02 07:40:42 --> URI Class Initialized
INFO - 2023-05-02 07:40:42 --> Router Class Initialized
INFO - 2023-05-02 07:40:42 --> Output Class Initialized
INFO - 2023-05-02 07:40:42 --> Security Class Initialized
DEBUG - 2023-05-02 07:40:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-02 07:40:42 --> Input Class Initialized
INFO - 2023-05-02 07:40:42 --> Language Class Initialized
INFO - 2023-05-02 07:40:42 --> Language Class Initialized
INFO - 2023-05-02 07:40:42 --> Config Class Initialized
INFO - 2023-05-02 07:40:42 --> Loader Class Initialized
INFO - 2023-05-02 07:40:42 --> Helper loaded: url_helper
INFO - 2023-05-02 07:40:42 --> Helper loaded: file_helper
INFO - 2023-05-02 07:40:42 --> Helper loaded: form_helper
INFO - 2023-05-02 07:40:42 --> Helper loaded: my_helper
INFO - 2023-05-02 07:40:42 --> Database Driver Class Initialized
DEBUG - 2023-05-02 07:40:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-05-02 07:40:42 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-02 07:40:42 --> Controller Class Initialized
ERROR - 2023-05-02 07:40:42 --> Severity: Notice --> Undefined index: nama C:\xampp\htdocs\myraportk13\application\modules\n_catatan_nna\controllers\N_catatan_nna.php 171
ERROR - 2023-05-02 07:40:42 --> Severity: Notice --> Undefined variable: d_kd C:\xampp\htdocs\myraportk13\application\modules\n_catatan_nna\controllers\N_catatan_nna.php 182
ERROR - 2023-05-02 07:40:42 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\myraportk13\application\modules\n_catatan_nna\controllers\N_catatan_nna.php 182
ERROR - 2023-05-02 07:40:42 --> Severity: Notice --> Undefined index: nama C:\xampp\htdocs\myraportk13\application\modules\n_catatan_nna\controllers\N_catatan_nna.php 171
ERROR - 2023-05-02 07:40:42 --> Severity: Notice --> Undefined variable: d_kd C:\xampp\htdocs\myraportk13\application\modules\n_catatan_nna\controllers\N_catatan_nna.php 182
ERROR - 2023-05-02 07:40:42 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\myraportk13\application\modules\n_catatan_nna\controllers\N_catatan_nna.php 182
INFO - 2023-05-02 07:41:11 --> Config Class Initialized
INFO - 2023-05-02 07:41:11 --> Hooks Class Initialized
DEBUG - 2023-05-02 07:41:11 --> UTF-8 Support Enabled
INFO - 2023-05-02 07:41:11 --> Utf8 Class Initialized
INFO - 2023-05-02 07:41:11 --> URI Class Initialized
INFO - 2023-05-02 07:41:11 --> Router Class Initialized
INFO - 2023-05-02 07:41:11 --> Output Class Initialized
INFO - 2023-05-02 07:41:11 --> Security Class Initialized
DEBUG - 2023-05-02 07:41:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-02 07:41:11 --> Input Class Initialized
INFO - 2023-05-02 07:41:11 --> Language Class Initialized
INFO - 2023-05-02 07:41:11 --> Language Class Initialized
INFO - 2023-05-02 07:41:11 --> Config Class Initialized
INFO - 2023-05-02 07:41:11 --> Loader Class Initialized
INFO - 2023-05-02 07:41:11 --> Helper loaded: url_helper
INFO - 2023-05-02 07:41:11 --> Helper loaded: file_helper
INFO - 2023-05-02 07:41:11 --> Helper loaded: form_helper
INFO - 2023-05-02 07:41:11 --> Helper loaded: my_helper
INFO - 2023-05-02 07:41:11 --> Database Driver Class Initialized
DEBUG - 2023-05-02 07:41:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-05-02 07:41:11 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-02 07:41:11 --> Controller Class Initialized
ERROR - 2023-05-02 07:41:11 --> Severity: Notice --> Undefined index: nama C:\xampp\htdocs\myraportk13\application\modules\n_catatan_nna\controllers\N_catatan_nna.php 171
ERROR - 2023-05-02 07:41:11 --> Severity: Notice --> Undefined variable: d_kd C:\xampp\htdocs\myraportk13\application\modules\n_catatan_nna\controllers\N_catatan_nna.php 182
ERROR - 2023-05-02 07:41:11 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\myraportk13\application\modules\n_catatan_nna\controllers\N_catatan_nna.php 182
ERROR - 2023-05-02 07:41:11 --> Severity: Notice --> Undefined index: nama C:\xampp\htdocs\myraportk13\application\modules\n_catatan_nna\controllers\N_catatan_nna.php 171
ERROR - 2023-05-02 07:41:11 --> Severity: Notice --> Undefined variable: d_kd C:\xampp\htdocs\myraportk13\application\modules\n_catatan_nna\controllers\N_catatan_nna.php 182
ERROR - 2023-05-02 07:41:11 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\myraportk13\application\modules\n_catatan_nna\controllers\N_catatan_nna.php 182
INFO - 2023-05-02 07:42:41 --> Config Class Initialized
INFO - 2023-05-02 07:42:41 --> Hooks Class Initialized
DEBUG - 2023-05-02 07:42:41 --> UTF-8 Support Enabled
INFO - 2023-05-02 07:42:41 --> Utf8 Class Initialized
INFO - 2023-05-02 07:42:41 --> URI Class Initialized
INFO - 2023-05-02 07:42:41 --> Router Class Initialized
INFO - 2023-05-02 07:42:41 --> Output Class Initialized
INFO - 2023-05-02 07:42:41 --> Security Class Initialized
DEBUG - 2023-05-02 07:42:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-02 07:42:41 --> Input Class Initialized
INFO - 2023-05-02 07:42:41 --> Language Class Initialized
INFO - 2023-05-02 07:42:41 --> Language Class Initialized
INFO - 2023-05-02 07:42:41 --> Config Class Initialized
INFO - 2023-05-02 07:42:41 --> Loader Class Initialized
INFO - 2023-05-02 07:42:41 --> Helper loaded: url_helper
INFO - 2023-05-02 07:42:41 --> Helper loaded: file_helper
INFO - 2023-05-02 07:42:41 --> Helper loaded: form_helper
INFO - 2023-05-02 07:42:41 --> Helper loaded: my_helper
INFO - 2023-05-02 07:42:41 --> Database Driver Class Initialized
DEBUG - 2023-05-02 07:42:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-05-02 07:42:41 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-02 07:42:41 --> Controller Class Initialized
ERROR - 2023-05-02 07:42:41 --> Severity: Notice --> Undefined index: nama C:\xampp\htdocs\myraportk13\application\modules\n_catatan_nna\controllers\N_catatan_nna.php 170
ERROR - 2023-05-02 07:42:41 --> Severity: Notice --> Undefined index: nama C:\xampp\htdocs\myraportk13\application\modules\n_catatan_nna\controllers\N_catatan_nna.php 170
INFO - 2023-05-02 07:44:47 --> Config Class Initialized
INFO - 2023-05-02 07:44:47 --> Hooks Class Initialized
DEBUG - 2023-05-02 07:44:47 --> UTF-8 Support Enabled
INFO - 2023-05-02 07:44:47 --> Utf8 Class Initialized
INFO - 2023-05-02 07:44:47 --> URI Class Initialized
INFO - 2023-05-02 07:44:47 --> Router Class Initialized
INFO - 2023-05-02 07:44:47 --> Output Class Initialized
INFO - 2023-05-02 07:44:47 --> Security Class Initialized
DEBUG - 2023-05-02 07:44:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-02 07:44:47 --> Input Class Initialized
INFO - 2023-05-02 07:44:47 --> Language Class Initialized
INFO - 2023-05-02 07:44:47 --> Language Class Initialized
INFO - 2023-05-02 07:44:47 --> Config Class Initialized
INFO - 2023-05-02 07:44:47 --> Loader Class Initialized
INFO - 2023-05-02 07:44:47 --> Helper loaded: url_helper
INFO - 2023-05-02 07:44:47 --> Helper loaded: file_helper
INFO - 2023-05-02 07:44:47 --> Helper loaded: form_helper
INFO - 2023-05-02 07:44:47 --> Helper loaded: my_helper
INFO - 2023-05-02 07:44:47 --> Database Driver Class Initialized
DEBUG - 2023-05-02 07:44:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-05-02 07:44:47 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-02 07:44:47 --> Controller Class Initialized
INFO - 2023-05-02 07:46:09 --> Config Class Initialized
INFO - 2023-05-02 07:46:09 --> Hooks Class Initialized
DEBUG - 2023-05-02 07:46:09 --> UTF-8 Support Enabled
INFO - 2023-05-02 07:46:09 --> Utf8 Class Initialized
INFO - 2023-05-02 07:46:09 --> URI Class Initialized
INFO - 2023-05-02 07:46:09 --> Router Class Initialized
INFO - 2023-05-02 07:46:09 --> Output Class Initialized
INFO - 2023-05-02 07:46:09 --> Security Class Initialized
DEBUG - 2023-05-02 07:46:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-02 07:46:09 --> Input Class Initialized
INFO - 2023-05-02 07:46:09 --> Language Class Initialized
INFO - 2023-05-02 07:46:09 --> Language Class Initialized
INFO - 2023-05-02 07:46:09 --> Config Class Initialized
INFO - 2023-05-02 07:46:09 --> Loader Class Initialized
INFO - 2023-05-02 07:46:09 --> Helper loaded: url_helper
INFO - 2023-05-02 07:46:09 --> Helper loaded: file_helper
INFO - 2023-05-02 07:46:09 --> Helper loaded: form_helper
INFO - 2023-05-02 07:46:09 --> Helper loaded: my_helper
INFO - 2023-05-02 07:46:09 --> Database Driver Class Initialized
DEBUG - 2023-05-02 07:46:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-05-02 07:46:09 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-02 07:46:09 --> Controller Class Initialized
DEBUG - 2023-05-02 07:46:09 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/n_catatan_nna/views/list.php
DEBUG - 2023-05-02 07:46:09 --> File loaded: C:\xampp\htdocs\myraportk13\application\views\template_utama.php
INFO - 2023-05-02 07:46:09 --> Final output sent to browser
DEBUG - 2023-05-02 07:46:09 --> Total execution time: 0.0319
INFO - 2023-05-02 07:46:10 --> Config Class Initialized
INFO - 2023-05-02 07:46:10 --> Hooks Class Initialized
DEBUG - 2023-05-02 07:46:10 --> UTF-8 Support Enabled
INFO - 2023-05-02 07:46:10 --> Utf8 Class Initialized
INFO - 2023-05-02 07:46:10 --> URI Class Initialized
INFO - 2023-05-02 07:46:10 --> Router Class Initialized
INFO - 2023-05-02 07:46:10 --> Output Class Initialized
INFO - 2023-05-02 07:46:10 --> Security Class Initialized
DEBUG - 2023-05-02 07:46:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-02 07:46:10 --> Input Class Initialized
INFO - 2023-05-02 07:46:10 --> Language Class Initialized
INFO - 2023-05-02 07:46:10 --> Language Class Initialized
INFO - 2023-05-02 07:46:10 --> Config Class Initialized
INFO - 2023-05-02 07:46:10 --> Loader Class Initialized
INFO - 2023-05-02 07:46:10 --> Helper loaded: url_helper
INFO - 2023-05-02 07:46:10 --> Helper loaded: file_helper
INFO - 2023-05-02 07:46:10 --> Helper loaded: form_helper
INFO - 2023-05-02 07:46:10 --> Helper loaded: my_helper
INFO - 2023-05-02 07:46:10 --> Database Driver Class Initialized
DEBUG - 2023-05-02 07:46:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-05-02 07:46:10 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-02 07:46:10 --> Controller Class Initialized
INFO - 2023-05-02 07:46:14 --> Config Class Initialized
INFO - 2023-05-02 07:46:14 --> Hooks Class Initialized
DEBUG - 2023-05-02 07:46:14 --> UTF-8 Support Enabled
INFO - 2023-05-02 07:46:14 --> Utf8 Class Initialized
INFO - 2023-05-02 07:46:14 --> URI Class Initialized
INFO - 2023-05-02 07:46:14 --> Router Class Initialized
INFO - 2023-05-02 07:46:14 --> Output Class Initialized
INFO - 2023-05-02 07:46:14 --> Security Class Initialized
DEBUG - 2023-05-02 07:46:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-02 07:46:14 --> Input Class Initialized
INFO - 2023-05-02 07:46:14 --> Language Class Initialized
INFO - 2023-05-02 07:46:14 --> Language Class Initialized
INFO - 2023-05-02 07:46:14 --> Config Class Initialized
INFO - 2023-05-02 07:46:14 --> Loader Class Initialized
INFO - 2023-05-02 07:46:14 --> Helper loaded: url_helper
INFO - 2023-05-02 07:46:14 --> Helper loaded: file_helper
INFO - 2023-05-02 07:46:14 --> Helper loaded: form_helper
INFO - 2023-05-02 07:46:14 --> Helper loaded: my_helper
INFO - 2023-05-02 07:46:14 --> Database Driver Class Initialized
DEBUG - 2023-05-02 07:46:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-05-02 07:46:14 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-02 07:46:14 --> Controller Class Initialized
DEBUG - 2023-05-02 07:46:14 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/n_catatan_nna/views/list.php
DEBUG - 2023-05-02 07:46:14 --> File loaded: C:\xampp\htdocs\myraportk13\application\views\template_utama.php
INFO - 2023-05-02 07:46:14 --> Final output sent to browser
DEBUG - 2023-05-02 07:46:14 --> Total execution time: 0.0307
INFO - 2023-05-02 07:46:16 --> Config Class Initialized
INFO - 2023-05-02 07:46:16 --> Hooks Class Initialized
DEBUG - 2023-05-02 07:46:16 --> UTF-8 Support Enabled
INFO - 2023-05-02 07:46:16 --> Utf8 Class Initialized
INFO - 2023-05-02 07:46:16 --> URI Class Initialized
INFO - 2023-05-02 07:46:16 --> Router Class Initialized
INFO - 2023-05-02 07:46:16 --> Output Class Initialized
INFO - 2023-05-02 07:46:16 --> Security Class Initialized
DEBUG - 2023-05-02 07:46:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-02 07:46:16 --> Input Class Initialized
INFO - 2023-05-02 07:46:16 --> Language Class Initialized
INFO - 2023-05-02 07:46:16 --> Language Class Initialized
INFO - 2023-05-02 07:46:16 --> Config Class Initialized
INFO - 2023-05-02 07:46:16 --> Loader Class Initialized
INFO - 2023-05-02 07:46:16 --> Helper loaded: url_helper
INFO - 2023-05-02 07:46:16 --> Helper loaded: file_helper
INFO - 2023-05-02 07:46:16 --> Helper loaded: form_helper
INFO - 2023-05-02 07:46:16 --> Helper loaded: my_helper
INFO - 2023-05-02 07:46:16 --> Database Driver Class Initialized
DEBUG - 2023-05-02 07:46:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-05-02 07:46:16 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-02 07:46:16 --> Controller Class Initialized
INFO - 2023-05-02 07:48:57 --> Config Class Initialized
INFO - 2023-05-02 07:48:57 --> Hooks Class Initialized
DEBUG - 2023-05-02 07:48:57 --> UTF-8 Support Enabled
INFO - 2023-05-02 07:48:57 --> Utf8 Class Initialized
INFO - 2023-05-02 07:48:57 --> URI Class Initialized
INFO - 2023-05-02 07:48:57 --> Router Class Initialized
INFO - 2023-05-02 07:48:57 --> Output Class Initialized
INFO - 2023-05-02 07:48:57 --> Security Class Initialized
DEBUG - 2023-05-02 07:48:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-02 07:48:57 --> Input Class Initialized
INFO - 2023-05-02 07:48:57 --> Language Class Initialized
INFO - 2023-05-02 07:48:57 --> Language Class Initialized
INFO - 2023-05-02 07:48:57 --> Config Class Initialized
INFO - 2023-05-02 07:48:57 --> Loader Class Initialized
INFO - 2023-05-02 07:48:57 --> Helper loaded: url_helper
INFO - 2023-05-02 07:48:57 --> Helper loaded: file_helper
INFO - 2023-05-02 07:48:57 --> Helper loaded: form_helper
INFO - 2023-05-02 07:48:57 --> Helper loaded: my_helper
INFO - 2023-05-02 07:48:57 --> Database Driver Class Initialized
DEBUG - 2023-05-02 07:48:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-05-02 07:48:57 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-02 07:48:57 --> Controller Class Initialized
DEBUG - 2023-05-02 07:48:57 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/n_catatan_nna/views/list.php
DEBUG - 2023-05-02 07:48:57 --> File loaded: C:\xampp\htdocs\myraportk13\application\views\template_utama.php
INFO - 2023-05-02 07:48:57 --> Final output sent to browser
DEBUG - 2023-05-02 07:48:57 --> Total execution time: 0.0328
INFO - 2023-05-02 07:51:25 --> Config Class Initialized
INFO - 2023-05-02 07:51:25 --> Hooks Class Initialized
DEBUG - 2023-05-02 07:51:25 --> UTF-8 Support Enabled
INFO - 2023-05-02 07:51:25 --> Utf8 Class Initialized
INFO - 2023-05-02 07:51:25 --> URI Class Initialized
INFO - 2023-05-02 07:51:25 --> Router Class Initialized
INFO - 2023-05-02 07:51:25 --> Output Class Initialized
INFO - 2023-05-02 07:51:25 --> Security Class Initialized
DEBUG - 2023-05-02 07:51:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-02 07:51:25 --> Input Class Initialized
INFO - 2023-05-02 07:51:25 --> Language Class Initialized
INFO - 2023-05-02 07:51:25 --> Language Class Initialized
INFO - 2023-05-02 07:51:25 --> Config Class Initialized
INFO - 2023-05-02 07:51:25 --> Loader Class Initialized
INFO - 2023-05-02 07:51:25 --> Helper loaded: url_helper
INFO - 2023-05-02 07:51:25 --> Helper loaded: file_helper
INFO - 2023-05-02 07:51:25 --> Helper loaded: form_helper
INFO - 2023-05-02 07:51:25 --> Helper loaded: my_helper
INFO - 2023-05-02 07:51:25 --> Database Driver Class Initialized
DEBUG - 2023-05-02 07:51:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-05-02 07:51:25 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-02 07:51:25 --> Controller Class Initialized
INFO - 2023-05-02 07:51:25 --> Final output sent to browser
DEBUG - 2023-05-02 07:51:25 --> Total execution time: 0.0283
INFO - 2023-05-02 07:51:26 --> Config Class Initialized
INFO - 2023-05-02 07:51:26 --> Hooks Class Initialized
DEBUG - 2023-05-02 07:51:26 --> UTF-8 Support Enabled
INFO - 2023-05-02 07:51:26 --> Utf8 Class Initialized
INFO - 2023-05-02 07:51:26 --> URI Class Initialized
INFO - 2023-05-02 07:51:26 --> Router Class Initialized
INFO - 2023-05-02 07:51:26 --> Output Class Initialized
INFO - 2023-05-02 07:51:26 --> Security Class Initialized
DEBUG - 2023-05-02 07:51:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-02 07:51:26 --> Input Class Initialized
INFO - 2023-05-02 07:51:26 --> Language Class Initialized
INFO - 2023-05-02 07:51:26 --> Language Class Initialized
INFO - 2023-05-02 07:51:26 --> Config Class Initialized
INFO - 2023-05-02 07:51:26 --> Loader Class Initialized
INFO - 2023-05-02 07:51:26 --> Helper loaded: url_helper
INFO - 2023-05-02 07:51:26 --> Helper loaded: file_helper
INFO - 2023-05-02 07:51:26 --> Helper loaded: form_helper
INFO - 2023-05-02 07:51:26 --> Helper loaded: my_helper
INFO - 2023-05-02 07:51:26 --> Database Driver Class Initialized
DEBUG - 2023-05-02 07:51:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-05-02 07:51:26 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-02 07:51:26 --> Controller Class Initialized
INFO - 2023-05-02 08:27:49 --> Config Class Initialized
INFO - 2023-05-02 08:27:49 --> Hooks Class Initialized
DEBUG - 2023-05-02 08:27:49 --> UTF-8 Support Enabled
INFO - 2023-05-02 08:27:49 --> Utf8 Class Initialized
INFO - 2023-05-02 08:27:49 --> URI Class Initialized
INFO - 2023-05-02 08:27:49 --> Router Class Initialized
INFO - 2023-05-02 08:27:49 --> Output Class Initialized
INFO - 2023-05-02 08:27:49 --> Security Class Initialized
DEBUG - 2023-05-02 08:27:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-02 08:27:49 --> Input Class Initialized
INFO - 2023-05-02 08:27:49 --> Language Class Initialized
INFO - 2023-05-02 08:27:49 --> Language Class Initialized
INFO - 2023-05-02 08:27:49 --> Config Class Initialized
INFO - 2023-05-02 08:27:49 --> Loader Class Initialized
INFO - 2023-05-02 08:27:49 --> Helper loaded: url_helper
INFO - 2023-05-02 08:27:49 --> Helper loaded: file_helper
INFO - 2023-05-02 08:27:49 --> Helper loaded: form_helper
INFO - 2023-05-02 08:27:49 --> Helper loaded: my_helper
INFO - 2023-05-02 08:27:49 --> Database Driver Class Initialized
DEBUG - 2023-05-02 08:27:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-05-02 08:27:49 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-02 08:27:49 --> Controller Class Initialized
DEBUG - 2023-05-02 08:27:49 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/n_catatan_nna/views/list.php
DEBUG - 2023-05-02 08:27:49 --> File loaded: C:\xampp\htdocs\myraportk13\application\views\template_utama.php
INFO - 2023-05-02 08:27:49 --> Final output sent to browser
DEBUG - 2023-05-02 08:27:49 --> Total execution time: 0.0812
INFO - 2023-05-02 08:27:53 --> Config Class Initialized
INFO - 2023-05-02 08:27:53 --> Hooks Class Initialized
DEBUG - 2023-05-02 08:27:53 --> UTF-8 Support Enabled
INFO - 2023-05-02 08:27:53 --> Utf8 Class Initialized
INFO - 2023-05-02 08:27:53 --> URI Class Initialized
INFO - 2023-05-02 08:27:53 --> Router Class Initialized
INFO - 2023-05-02 08:27:53 --> Output Class Initialized
INFO - 2023-05-02 08:27:53 --> Security Class Initialized
DEBUG - 2023-05-02 08:27:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-02 08:27:53 --> Input Class Initialized
INFO - 2023-05-02 08:27:53 --> Language Class Initialized
INFO - 2023-05-02 08:27:53 --> Language Class Initialized
INFO - 2023-05-02 08:27:53 --> Config Class Initialized
INFO - 2023-05-02 08:27:53 --> Loader Class Initialized
INFO - 2023-05-02 08:27:53 --> Helper loaded: url_helper
INFO - 2023-05-02 08:27:53 --> Helper loaded: file_helper
INFO - 2023-05-02 08:27:53 --> Helper loaded: form_helper
INFO - 2023-05-02 08:27:53 --> Helper loaded: my_helper
INFO - 2023-05-02 08:27:53 --> Database Driver Class Initialized
DEBUG - 2023-05-02 08:27:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-05-02 08:27:53 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-02 08:27:53 --> Controller Class Initialized
INFO - 2023-05-02 08:31:29 --> Config Class Initialized
INFO - 2023-05-02 08:31:29 --> Hooks Class Initialized
DEBUG - 2023-05-02 08:31:29 --> UTF-8 Support Enabled
INFO - 2023-05-02 08:31:29 --> Utf8 Class Initialized
INFO - 2023-05-02 08:31:29 --> URI Class Initialized
INFO - 2023-05-02 08:31:29 --> Router Class Initialized
INFO - 2023-05-02 08:31:29 --> Output Class Initialized
INFO - 2023-05-02 08:31:29 --> Security Class Initialized
DEBUG - 2023-05-02 08:31:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-02 08:31:29 --> Input Class Initialized
INFO - 2023-05-02 08:31:29 --> Language Class Initialized
INFO - 2023-05-02 08:31:29 --> Language Class Initialized
INFO - 2023-05-02 08:31:29 --> Config Class Initialized
INFO - 2023-05-02 08:31:29 --> Loader Class Initialized
INFO - 2023-05-02 08:31:29 --> Helper loaded: url_helper
INFO - 2023-05-02 08:31:29 --> Helper loaded: file_helper
INFO - 2023-05-02 08:31:29 --> Helper loaded: form_helper
INFO - 2023-05-02 08:31:29 --> Helper loaded: my_helper
INFO - 2023-05-02 08:31:29 --> Database Driver Class Initialized
DEBUG - 2023-05-02 08:31:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-05-02 08:31:29 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-02 08:31:29 --> Controller Class Initialized
ERROR - 2023-05-02 08:31:29 --> Severity: Notice --> Undefined offset: 1 C:\xampp\htdocs\myraportk13\application\modules\n_catatan_nna\controllers\N_catatan_nna.php 236
ERROR - 2023-05-02 08:31:29 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near 'AND a.tasm = '20232'' at line 7 - Invalid query: SELECT 
                                         a.id, a.id_guru, b.nama nmmapel, c.nama nmkelas, d.nama nmguru
                                         FROM t_guru_mapel a
                                         INNER JOIN m_mapel b ON a.id_mapel = b.id 
                                         INNER JOIN m_kelas c ON a.id_kelas = c.id
                                         INNER JOIN m_guru d ON a.id_guru = d.id 
                                         WHERE b.id = 8 AND c.id =  AND a.tasm = '20232'
INFO - 2023-05-02 08:31:29 --> Language file loaded: language/english/db_lang.php
INFO - 2023-05-02 08:31:57 --> Config Class Initialized
INFO - 2023-05-02 08:31:57 --> Hooks Class Initialized
DEBUG - 2023-05-02 08:31:57 --> UTF-8 Support Enabled
INFO - 2023-05-02 08:31:57 --> Utf8 Class Initialized
INFO - 2023-05-02 08:31:57 --> URI Class Initialized
INFO - 2023-05-02 08:31:57 --> Router Class Initialized
INFO - 2023-05-02 08:31:57 --> Output Class Initialized
INFO - 2023-05-02 08:31:57 --> Security Class Initialized
DEBUG - 2023-05-02 08:31:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-02 08:31:57 --> Input Class Initialized
INFO - 2023-05-02 08:31:57 --> Language Class Initialized
INFO - 2023-05-02 08:31:57 --> Language Class Initialized
INFO - 2023-05-02 08:31:57 --> Config Class Initialized
INFO - 2023-05-02 08:31:57 --> Loader Class Initialized
INFO - 2023-05-02 08:31:57 --> Helper loaded: url_helper
INFO - 2023-05-02 08:31:57 --> Helper loaded: file_helper
INFO - 2023-05-02 08:31:57 --> Helper loaded: form_helper
INFO - 2023-05-02 08:31:57 --> Helper loaded: my_helper
INFO - 2023-05-02 08:31:57 --> Database Driver Class Initialized
DEBUG - 2023-05-02 08:31:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-05-02 08:31:57 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-02 08:31:57 --> Controller Class Initialized
ERROR - 2023-05-02 08:31:57 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near 'AND c.id = 8 AND a.tasm = '20232'' at line 7 - Invalid query: SELECT 
                                         a.id, a.id_guru, b.nama nmmapel, c.nama nmkelas, d.nama nmguru
                                         FROM t_guru_mapel a
                                         INNER JOIN m_mapel b ON a.id_mapel = b.id 
                                         INNER JOIN m_kelas c ON a.id_kelas = c.id
                                         INNER JOIN m_guru d ON a.id_guru = d.id 
                                         WHERE AND c.id = 8 AND a.tasm = '20232'
INFO - 2023-05-02 08:31:57 --> Language file loaded: language/english/db_lang.php
INFO - 2023-05-02 08:32:55 --> Config Class Initialized
INFO - 2023-05-02 08:32:55 --> Hooks Class Initialized
DEBUG - 2023-05-02 08:32:55 --> UTF-8 Support Enabled
INFO - 2023-05-02 08:32:55 --> Utf8 Class Initialized
INFO - 2023-05-02 08:32:55 --> URI Class Initialized
INFO - 2023-05-02 08:32:55 --> Router Class Initialized
INFO - 2023-05-02 08:32:55 --> Output Class Initialized
INFO - 2023-05-02 08:32:55 --> Security Class Initialized
DEBUG - 2023-05-02 08:32:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-02 08:32:55 --> Input Class Initialized
INFO - 2023-05-02 08:32:55 --> Language Class Initialized
INFO - 2023-05-02 08:32:55 --> Language Class Initialized
INFO - 2023-05-02 08:32:55 --> Config Class Initialized
INFO - 2023-05-02 08:32:55 --> Loader Class Initialized
INFO - 2023-05-02 08:32:55 --> Helper loaded: url_helper
INFO - 2023-05-02 08:32:55 --> Helper loaded: file_helper
INFO - 2023-05-02 08:32:55 --> Helper loaded: form_helper
INFO - 2023-05-02 08:32:55 --> Helper loaded: my_helper
INFO - 2023-05-02 08:32:55 --> Database Driver Class Initialized
DEBUG - 2023-05-02 08:32:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-05-02 08:32:55 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-02 08:32:55 --> Controller Class Initialized
INFO - 2023-05-02 08:33:11 --> Config Class Initialized
INFO - 2023-05-02 08:33:11 --> Hooks Class Initialized
DEBUG - 2023-05-02 08:33:11 --> UTF-8 Support Enabled
INFO - 2023-05-02 08:33:11 --> Utf8 Class Initialized
INFO - 2023-05-02 08:33:11 --> URI Class Initialized
DEBUG - 2023-05-02 08:33:11 --> No URI present. Default controller set.
INFO - 2023-05-02 08:33:11 --> Router Class Initialized
INFO - 2023-05-02 08:33:11 --> Output Class Initialized
INFO - 2023-05-02 08:33:11 --> Security Class Initialized
DEBUG - 2023-05-02 08:33:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-02 08:33:11 --> Input Class Initialized
INFO - 2023-05-02 08:33:11 --> Language Class Initialized
INFO - 2023-05-02 08:33:11 --> Language Class Initialized
INFO - 2023-05-02 08:33:11 --> Config Class Initialized
INFO - 2023-05-02 08:33:11 --> Loader Class Initialized
INFO - 2023-05-02 08:33:11 --> Helper loaded: url_helper
INFO - 2023-05-02 08:33:11 --> Helper loaded: file_helper
INFO - 2023-05-02 08:33:11 --> Helper loaded: form_helper
INFO - 2023-05-02 08:33:11 --> Helper loaded: my_helper
INFO - 2023-05-02 08:33:11 --> Database Driver Class Initialized
DEBUG - 2023-05-02 08:33:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-05-02 08:33:11 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-02 08:33:11 --> Controller Class Initialized
DEBUG - 2023-05-02 08:33:11 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/home/views/v_home_guru.php
DEBUG - 2023-05-02 08:33:11 --> File loaded: C:\xampp\htdocs\myraportk13\application\views\template_utama.php
INFO - 2023-05-02 08:33:11 --> Final output sent to browser
DEBUG - 2023-05-02 08:33:11 --> Total execution time: 0.0492
INFO - 2023-05-02 08:33:16 --> Config Class Initialized
INFO - 2023-05-02 08:33:16 --> Hooks Class Initialized
DEBUG - 2023-05-02 08:33:16 --> UTF-8 Support Enabled
INFO - 2023-05-02 08:33:16 --> Utf8 Class Initialized
INFO - 2023-05-02 08:33:16 --> URI Class Initialized
INFO - 2023-05-02 08:33:16 --> Router Class Initialized
INFO - 2023-05-02 08:33:16 --> Output Class Initialized
INFO - 2023-05-02 08:33:16 --> Security Class Initialized
DEBUG - 2023-05-02 08:33:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-02 08:33:16 --> Input Class Initialized
INFO - 2023-05-02 08:33:16 --> Language Class Initialized
INFO - 2023-05-02 08:33:16 --> Language Class Initialized
INFO - 2023-05-02 08:33:16 --> Config Class Initialized
INFO - 2023-05-02 08:33:16 --> Loader Class Initialized
INFO - 2023-05-02 08:33:16 --> Helper loaded: url_helper
INFO - 2023-05-02 08:33:16 --> Helper loaded: file_helper
INFO - 2023-05-02 08:33:16 --> Helper loaded: form_helper
INFO - 2023-05-02 08:33:16 --> Helper loaded: my_helper
INFO - 2023-05-02 08:33:16 --> Database Driver Class Initialized
DEBUG - 2023-05-02 08:33:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-05-02 08:33:16 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-02 08:33:16 --> Controller Class Initialized
DEBUG - 2023-05-02 08:33:16 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/n_catatan_nna/views/list.php
DEBUG - 2023-05-02 08:33:16 --> File loaded: C:\xampp\htdocs\myraportk13\application\views\template_utama.php
INFO - 2023-05-02 08:33:16 --> Final output sent to browser
DEBUG - 2023-05-02 08:33:16 --> Total execution time: 0.0300
INFO - 2023-05-02 08:33:18 --> Config Class Initialized
INFO - 2023-05-02 08:33:18 --> Hooks Class Initialized
DEBUG - 2023-05-02 08:33:18 --> UTF-8 Support Enabled
INFO - 2023-05-02 08:33:18 --> Utf8 Class Initialized
INFO - 2023-05-02 08:33:18 --> URI Class Initialized
INFO - 2023-05-02 08:33:18 --> Router Class Initialized
INFO - 2023-05-02 08:33:18 --> Output Class Initialized
INFO - 2023-05-02 08:33:18 --> Security Class Initialized
DEBUG - 2023-05-02 08:33:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-02 08:33:18 --> Input Class Initialized
INFO - 2023-05-02 08:33:18 --> Language Class Initialized
INFO - 2023-05-02 08:33:18 --> Language Class Initialized
INFO - 2023-05-02 08:33:18 --> Config Class Initialized
INFO - 2023-05-02 08:33:18 --> Loader Class Initialized
INFO - 2023-05-02 08:33:18 --> Helper loaded: url_helper
INFO - 2023-05-02 08:33:18 --> Helper loaded: file_helper
INFO - 2023-05-02 08:33:18 --> Helper loaded: form_helper
INFO - 2023-05-02 08:33:18 --> Helper loaded: my_helper
INFO - 2023-05-02 08:33:18 --> Database Driver Class Initialized
DEBUG - 2023-05-02 08:33:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-05-02 08:33:18 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-02 08:33:18 --> Controller Class Initialized
INFO - 2023-05-02 08:35:13 --> Config Class Initialized
INFO - 2023-05-02 08:35:13 --> Hooks Class Initialized
DEBUG - 2023-05-02 08:35:13 --> UTF-8 Support Enabled
INFO - 2023-05-02 08:35:13 --> Utf8 Class Initialized
INFO - 2023-05-02 08:35:13 --> URI Class Initialized
INFO - 2023-05-02 08:35:13 --> Router Class Initialized
INFO - 2023-05-02 08:35:13 --> Output Class Initialized
INFO - 2023-05-02 08:35:13 --> Security Class Initialized
DEBUG - 2023-05-02 08:35:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-02 08:35:13 --> Input Class Initialized
INFO - 2023-05-02 08:35:13 --> Language Class Initialized
INFO - 2023-05-02 08:35:13 --> Language Class Initialized
INFO - 2023-05-02 08:35:13 --> Config Class Initialized
INFO - 2023-05-02 08:35:13 --> Loader Class Initialized
INFO - 2023-05-02 08:35:13 --> Helper loaded: url_helper
INFO - 2023-05-02 08:35:13 --> Helper loaded: file_helper
INFO - 2023-05-02 08:35:13 --> Helper loaded: form_helper
INFO - 2023-05-02 08:35:13 --> Helper loaded: my_helper
INFO - 2023-05-02 08:35:13 --> Database Driver Class Initialized
DEBUG - 2023-05-02 08:35:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-05-02 08:35:13 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-02 08:35:13 --> Controller Class Initialized
DEBUG - 2023-05-02 08:35:13 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/n_catatan_nna/views/list.php
DEBUG - 2023-05-02 08:35:13 --> File loaded: C:\xampp\htdocs\myraportk13\application\views\template_utama.php
INFO - 2023-05-02 08:35:13 --> Final output sent to browser
DEBUG - 2023-05-02 08:35:13 --> Total execution time: 0.0405
INFO - 2023-05-02 08:35:16 --> Config Class Initialized
INFO - 2023-05-02 08:35:16 --> Hooks Class Initialized
DEBUG - 2023-05-02 08:35:16 --> UTF-8 Support Enabled
INFO - 2023-05-02 08:35:16 --> Utf8 Class Initialized
INFO - 2023-05-02 08:35:16 --> URI Class Initialized
INFO - 2023-05-02 08:35:16 --> Router Class Initialized
INFO - 2023-05-02 08:35:16 --> Output Class Initialized
INFO - 2023-05-02 08:35:16 --> Security Class Initialized
DEBUG - 2023-05-02 08:35:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-02 08:35:16 --> Input Class Initialized
INFO - 2023-05-02 08:35:16 --> Language Class Initialized
ERROR - 2023-05-02 08:35:16 --> 404 Page Not Found: /index
INFO - 2023-05-02 08:35:18 --> Config Class Initialized
INFO - 2023-05-02 08:35:18 --> Hooks Class Initialized
DEBUG - 2023-05-02 08:35:18 --> UTF-8 Support Enabled
INFO - 2023-05-02 08:35:18 --> Utf8 Class Initialized
INFO - 2023-05-02 08:35:18 --> URI Class Initialized
INFO - 2023-05-02 08:35:18 --> Router Class Initialized
INFO - 2023-05-02 08:35:18 --> Output Class Initialized
INFO - 2023-05-02 08:35:18 --> Security Class Initialized
DEBUG - 2023-05-02 08:35:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-02 08:35:18 --> Input Class Initialized
INFO - 2023-05-02 08:35:18 --> Language Class Initialized
INFO - 2023-05-02 08:35:18 --> Language Class Initialized
INFO - 2023-05-02 08:35:18 --> Config Class Initialized
INFO - 2023-05-02 08:35:18 --> Loader Class Initialized
INFO - 2023-05-02 08:35:18 --> Helper loaded: url_helper
INFO - 2023-05-02 08:35:18 --> Helper loaded: file_helper
INFO - 2023-05-02 08:35:18 --> Helper loaded: form_helper
INFO - 2023-05-02 08:35:18 --> Helper loaded: my_helper
INFO - 2023-05-02 08:35:18 --> Database Driver Class Initialized
DEBUG - 2023-05-02 08:35:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-05-02 08:35:18 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-02 08:35:18 --> Controller Class Initialized
INFO - 2023-05-02 08:35:18 --> Config Class Initialized
INFO - 2023-05-02 08:35:18 --> Hooks Class Initialized
DEBUG - 2023-05-02 08:35:18 --> UTF-8 Support Enabled
INFO - 2023-05-02 08:35:18 --> Utf8 Class Initialized
INFO - 2023-05-02 08:35:18 --> URI Class Initialized
INFO - 2023-05-02 08:35:18 --> Router Class Initialized
INFO - 2023-05-02 08:35:18 --> Output Class Initialized
INFO - 2023-05-02 08:35:18 --> Security Class Initialized
DEBUG - 2023-05-02 08:35:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-02 08:35:18 --> Input Class Initialized
INFO - 2023-05-02 08:35:18 --> Language Class Initialized
ERROR - 2023-05-02 08:35:18 --> 404 Page Not Found: /index
INFO - 2023-05-02 08:36:28 --> Config Class Initialized
INFO - 2023-05-02 08:36:28 --> Hooks Class Initialized
DEBUG - 2023-05-02 08:36:28 --> UTF-8 Support Enabled
INFO - 2023-05-02 08:36:28 --> Utf8 Class Initialized
INFO - 2023-05-02 08:36:28 --> URI Class Initialized
INFO - 2023-05-02 08:36:28 --> Router Class Initialized
INFO - 2023-05-02 08:36:28 --> Output Class Initialized
INFO - 2023-05-02 08:36:28 --> Security Class Initialized
DEBUG - 2023-05-02 08:36:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-02 08:36:28 --> Input Class Initialized
INFO - 2023-05-02 08:36:28 --> Language Class Initialized
INFO - 2023-05-02 08:36:28 --> Language Class Initialized
INFO - 2023-05-02 08:36:28 --> Config Class Initialized
INFO - 2023-05-02 08:36:28 --> Loader Class Initialized
INFO - 2023-05-02 08:36:28 --> Helper loaded: url_helper
INFO - 2023-05-02 08:36:28 --> Helper loaded: file_helper
INFO - 2023-05-02 08:36:28 --> Helper loaded: form_helper
INFO - 2023-05-02 08:36:28 --> Helper loaded: my_helper
INFO - 2023-05-02 08:36:28 --> Database Driver Class Initialized
DEBUG - 2023-05-02 08:36:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-05-02 08:36:28 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-02 08:36:28 --> Controller Class Initialized
DEBUG - 2023-05-02 08:36:28 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/view_mapel/views/v_view_mapel.php
DEBUG - 2023-05-02 08:36:28 --> File loaded: C:\xampp\htdocs\myraportk13\application\views\template_utama.php
INFO - 2023-05-02 08:36:28 --> Final output sent to browser
DEBUG - 2023-05-02 08:36:28 --> Total execution time: 0.0340
INFO - 2023-05-02 08:36:28 --> Config Class Initialized
INFO - 2023-05-02 08:36:28 --> Hooks Class Initialized
DEBUG - 2023-05-02 08:36:28 --> UTF-8 Support Enabled
INFO - 2023-05-02 08:36:28 --> Utf8 Class Initialized
INFO - 2023-05-02 08:36:28 --> URI Class Initialized
INFO - 2023-05-02 08:36:28 --> Router Class Initialized
INFO - 2023-05-02 08:36:28 --> Output Class Initialized
INFO - 2023-05-02 08:36:28 --> Security Class Initialized
DEBUG - 2023-05-02 08:36:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-02 08:36:28 --> Input Class Initialized
INFO - 2023-05-02 08:36:28 --> Language Class Initialized
ERROR - 2023-05-02 08:36:28 --> 404 Page Not Found: /index
INFO - 2023-05-02 08:36:29 --> Config Class Initialized
INFO - 2023-05-02 08:36:29 --> Hooks Class Initialized
DEBUG - 2023-05-02 08:36:29 --> UTF-8 Support Enabled
INFO - 2023-05-02 08:36:29 --> Utf8 Class Initialized
INFO - 2023-05-02 08:36:29 --> URI Class Initialized
INFO - 2023-05-02 08:36:29 --> Router Class Initialized
INFO - 2023-05-02 08:36:29 --> Output Class Initialized
INFO - 2023-05-02 08:36:29 --> Security Class Initialized
DEBUG - 2023-05-02 08:36:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-02 08:36:29 --> Input Class Initialized
INFO - 2023-05-02 08:36:29 --> Language Class Initialized
INFO - 2023-05-02 08:36:29 --> Language Class Initialized
INFO - 2023-05-02 08:36:29 --> Config Class Initialized
INFO - 2023-05-02 08:36:29 --> Loader Class Initialized
INFO - 2023-05-02 08:36:29 --> Helper loaded: url_helper
INFO - 2023-05-02 08:36:29 --> Helper loaded: file_helper
INFO - 2023-05-02 08:36:29 --> Helper loaded: form_helper
INFO - 2023-05-02 08:36:29 --> Helper loaded: my_helper
INFO - 2023-05-02 08:36:29 --> Database Driver Class Initialized
DEBUG - 2023-05-02 08:36:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-05-02 08:36:29 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-02 08:36:29 --> Controller Class Initialized
DEBUG - 2023-05-02 08:36:29 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/n_icb/views/list.php
DEBUG - 2023-05-02 08:36:29 --> File loaded: C:\xampp\htdocs\myraportk13\application\views\template_utama.php
INFO - 2023-05-02 08:36:29 --> Final output sent to browser
DEBUG - 2023-05-02 08:36:29 --> Total execution time: 0.0430
INFO - 2023-05-02 08:36:29 --> Config Class Initialized
INFO - 2023-05-02 08:36:29 --> Hooks Class Initialized
DEBUG - 2023-05-02 08:36:29 --> UTF-8 Support Enabled
INFO - 2023-05-02 08:36:29 --> Utf8 Class Initialized
INFO - 2023-05-02 08:36:29 --> URI Class Initialized
INFO - 2023-05-02 08:36:29 --> Router Class Initialized
INFO - 2023-05-02 08:36:29 --> Output Class Initialized
INFO - 2023-05-02 08:36:29 --> Security Class Initialized
DEBUG - 2023-05-02 08:36:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-02 08:36:29 --> Input Class Initialized
INFO - 2023-05-02 08:36:29 --> Language Class Initialized
ERROR - 2023-05-02 08:36:29 --> 404 Page Not Found: /index
INFO - 2023-05-02 08:36:30 --> Config Class Initialized
INFO - 2023-05-02 08:36:30 --> Hooks Class Initialized
DEBUG - 2023-05-02 08:36:30 --> UTF-8 Support Enabled
INFO - 2023-05-02 08:36:30 --> Utf8 Class Initialized
INFO - 2023-05-02 08:36:30 --> URI Class Initialized
INFO - 2023-05-02 08:36:30 --> Router Class Initialized
INFO - 2023-05-02 08:36:30 --> Output Class Initialized
INFO - 2023-05-02 08:36:30 --> Security Class Initialized
DEBUG - 2023-05-02 08:36:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-02 08:36:30 --> Input Class Initialized
INFO - 2023-05-02 08:36:30 --> Language Class Initialized
INFO - 2023-05-02 08:36:30 --> Language Class Initialized
INFO - 2023-05-02 08:36:30 --> Config Class Initialized
INFO - 2023-05-02 08:36:30 --> Loader Class Initialized
INFO - 2023-05-02 08:36:30 --> Helper loaded: url_helper
INFO - 2023-05-02 08:36:30 --> Helper loaded: file_helper
INFO - 2023-05-02 08:36:30 --> Helper loaded: form_helper
INFO - 2023-05-02 08:36:30 --> Helper loaded: my_helper
INFO - 2023-05-02 08:36:30 --> Database Driver Class Initialized
DEBUG - 2023-05-02 08:36:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-05-02 08:36:30 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-02 08:36:30 --> Controller Class Initialized
INFO - 2023-05-02 08:36:31 --> Config Class Initialized
INFO - 2023-05-02 08:36:31 --> Hooks Class Initialized
DEBUG - 2023-05-02 08:36:31 --> UTF-8 Support Enabled
INFO - 2023-05-02 08:36:31 --> Utf8 Class Initialized
INFO - 2023-05-02 08:36:31 --> URI Class Initialized
INFO - 2023-05-02 08:36:31 --> Router Class Initialized
INFO - 2023-05-02 08:36:31 --> Output Class Initialized
INFO - 2023-05-02 08:36:31 --> Security Class Initialized
DEBUG - 2023-05-02 08:36:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-02 08:36:31 --> Input Class Initialized
INFO - 2023-05-02 08:36:31 --> Language Class Initialized
INFO - 2023-05-02 08:36:31 --> Language Class Initialized
INFO - 2023-05-02 08:36:31 --> Config Class Initialized
INFO - 2023-05-02 08:36:31 --> Loader Class Initialized
INFO - 2023-05-02 08:36:31 --> Helper loaded: url_helper
INFO - 2023-05-02 08:36:31 --> Helper loaded: file_helper
INFO - 2023-05-02 08:36:31 --> Helper loaded: form_helper
INFO - 2023-05-02 08:36:31 --> Helper loaded: my_helper
INFO - 2023-05-02 08:36:31 --> Database Driver Class Initialized
DEBUG - 2023-05-02 08:36:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-05-02 08:36:31 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-02 08:36:31 --> Controller Class Initialized
DEBUG - 2023-05-02 08:36:31 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/n_icb/views/form.php
DEBUG - 2023-05-02 08:36:31 --> File loaded: C:\xampp\htdocs\myraportk13\application\views\template_utama.php
INFO - 2023-05-02 08:36:31 --> Final output sent to browser
DEBUG - 2023-05-02 08:36:31 --> Total execution time: 0.0308
INFO - 2023-05-02 08:36:31 --> Config Class Initialized
INFO - 2023-05-02 08:36:31 --> Hooks Class Initialized
DEBUG - 2023-05-02 08:36:31 --> UTF-8 Support Enabled
INFO - 2023-05-02 08:36:31 --> Utf8 Class Initialized
INFO - 2023-05-02 08:36:31 --> URI Class Initialized
INFO - 2023-05-02 08:36:31 --> Router Class Initialized
INFO - 2023-05-02 08:36:31 --> Output Class Initialized
INFO - 2023-05-02 08:36:31 --> Security Class Initialized
DEBUG - 2023-05-02 08:36:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-02 08:36:31 --> Input Class Initialized
INFO - 2023-05-02 08:36:31 --> Language Class Initialized
ERROR - 2023-05-02 08:36:31 --> 404 Page Not Found: /index
INFO - 2023-05-02 08:37:18 --> Config Class Initialized
INFO - 2023-05-02 08:37:18 --> Hooks Class Initialized
DEBUG - 2023-05-02 08:37:18 --> UTF-8 Support Enabled
INFO - 2023-05-02 08:37:18 --> Utf8 Class Initialized
INFO - 2023-05-02 08:37:18 --> URI Class Initialized
DEBUG - 2023-05-02 08:37:18 --> No URI present. Default controller set.
INFO - 2023-05-02 08:37:18 --> Router Class Initialized
INFO - 2023-05-02 08:37:18 --> Output Class Initialized
INFO - 2023-05-02 08:37:18 --> Security Class Initialized
DEBUG - 2023-05-02 08:37:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-02 08:37:18 --> Input Class Initialized
INFO - 2023-05-02 08:37:18 --> Language Class Initialized
INFO - 2023-05-02 08:37:18 --> Language Class Initialized
INFO - 2023-05-02 08:37:18 --> Config Class Initialized
INFO - 2023-05-02 08:37:18 --> Loader Class Initialized
INFO - 2023-05-02 08:37:18 --> Helper loaded: url_helper
INFO - 2023-05-02 08:37:18 --> Helper loaded: file_helper
INFO - 2023-05-02 08:37:18 --> Helper loaded: form_helper
INFO - 2023-05-02 08:37:18 --> Helper loaded: my_helper
INFO - 2023-05-02 08:37:18 --> Database Driver Class Initialized
DEBUG - 2023-05-02 08:37:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-05-02 08:37:18 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-02 08:37:18 --> Controller Class Initialized
DEBUG - 2023-05-02 08:37:18 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/home/views/v_home_guru.php
DEBUG - 2023-05-02 08:37:18 --> File loaded: C:\xampp\htdocs\myraportk13\application\views\template_utama.php
INFO - 2023-05-02 08:37:18 --> Final output sent to browser
DEBUG - 2023-05-02 08:37:18 --> Total execution time: 0.0563
INFO - 2023-05-02 08:37:18 --> Config Class Initialized
INFO - 2023-05-02 08:37:18 --> Hooks Class Initialized
DEBUG - 2023-05-02 08:37:18 --> UTF-8 Support Enabled
INFO - 2023-05-02 08:37:18 --> Utf8 Class Initialized
INFO - 2023-05-02 08:37:18 --> URI Class Initialized
INFO - 2023-05-02 08:37:18 --> Router Class Initialized
INFO - 2023-05-02 08:37:18 --> Output Class Initialized
INFO - 2023-05-02 08:37:18 --> Security Class Initialized
DEBUG - 2023-05-02 08:37:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-02 08:37:18 --> Input Class Initialized
INFO - 2023-05-02 08:37:18 --> Language Class Initialized
ERROR - 2023-05-02 08:37:18 --> 404 Page Not Found: /index
INFO - 2023-05-02 08:37:22 --> Config Class Initialized
INFO - 2023-05-02 08:37:22 --> Hooks Class Initialized
DEBUG - 2023-05-02 08:37:22 --> UTF-8 Support Enabled
INFO - 2023-05-02 08:37:22 --> Utf8 Class Initialized
INFO - 2023-05-02 08:37:22 --> URI Class Initialized
INFO - 2023-05-02 08:37:22 --> Router Class Initialized
INFO - 2023-05-02 08:37:22 --> Output Class Initialized
INFO - 2023-05-02 08:37:22 --> Security Class Initialized
DEBUG - 2023-05-02 08:37:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-02 08:37:22 --> Input Class Initialized
INFO - 2023-05-02 08:37:22 --> Language Class Initialized
INFO - 2023-05-02 08:37:22 --> Language Class Initialized
INFO - 2023-05-02 08:37:22 --> Config Class Initialized
INFO - 2023-05-02 08:37:22 --> Loader Class Initialized
INFO - 2023-05-02 08:37:22 --> Helper loaded: url_helper
INFO - 2023-05-02 08:37:22 --> Helper loaded: file_helper
INFO - 2023-05-02 08:37:22 --> Helper loaded: form_helper
INFO - 2023-05-02 08:37:22 --> Helper loaded: my_helper
INFO - 2023-05-02 08:37:22 --> Database Driver Class Initialized
DEBUG - 2023-05-02 08:37:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-05-02 08:37:22 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-02 08:37:22 --> Controller Class Initialized
DEBUG - 2023-05-02 08:37:22 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/n_catatan_nna/views/list.php
DEBUG - 2023-05-02 08:37:22 --> File loaded: C:\xampp\htdocs\myraportk13\application\views\template_utama.php
INFO - 2023-05-02 08:37:22 --> Final output sent to browser
DEBUG - 2023-05-02 08:37:22 --> Total execution time: 0.0316
INFO - 2023-05-02 08:37:23 --> Config Class Initialized
INFO - 2023-05-02 08:37:23 --> Hooks Class Initialized
DEBUG - 2023-05-02 08:37:23 --> UTF-8 Support Enabled
INFO - 2023-05-02 08:37:23 --> Utf8 Class Initialized
INFO - 2023-05-02 08:37:23 --> URI Class Initialized
INFO - 2023-05-02 08:37:23 --> Router Class Initialized
INFO - 2023-05-02 08:37:23 --> Output Class Initialized
INFO - 2023-05-02 08:37:23 --> Security Class Initialized
DEBUG - 2023-05-02 08:37:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-02 08:37:23 --> Input Class Initialized
INFO - 2023-05-02 08:37:23 --> Language Class Initialized
INFO - 2023-05-02 08:37:23 --> Language Class Initialized
INFO - 2023-05-02 08:37:23 --> Config Class Initialized
INFO - 2023-05-02 08:37:23 --> Loader Class Initialized
INFO - 2023-05-02 08:37:23 --> Helper loaded: url_helper
INFO - 2023-05-02 08:37:23 --> Helper loaded: file_helper
INFO - 2023-05-02 08:37:23 --> Helper loaded: form_helper
INFO - 2023-05-02 08:37:23 --> Helper loaded: my_helper
INFO - 2023-05-02 08:37:23 --> Database Driver Class Initialized
DEBUG - 2023-05-02 08:37:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-05-02 08:37:23 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-02 08:37:23 --> Controller Class Initialized
ERROR - 2023-05-02 08:37:23 --> Severity: Notice --> Undefined index: nmmapel C:\xampp\htdocs\myraportk13\application\modules\n_catatan_nna\views\form.php 5
ERROR - 2023-05-02 08:37:23 --> Severity: Notice --> Undefined index: nmkelas C:\xampp\htdocs\myraportk13\application\modules\n_catatan_nna\views\form.php 5
ERROR - 2023-05-02 08:37:23 --> Severity: Notice --> Undefined index: nmguru C:\xampp\htdocs\myraportk13\application\modules\n_catatan_nna\views\form.php 5
ERROR - 2023-05-02 08:37:23 --> Severity: Notice --> Undefined variable: nama_form C:\xampp\htdocs\myraportk13\application\modules\n_catatan_nna\views\form.php 10
ERROR - 2023-05-02 08:37:23 --> Severity: Notice --> Undefined variable: nama_form C:\xampp\htdocs\myraportk13\application\modules\n_catatan_nna\views\form.php 10
DEBUG - 2023-05-02 08:37:23 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/n_catatan_nna/views/form.php
DEBUG - 2023-05-02 08:37:23 --> File loaded: C:\xampp\htdocs\myraportk13\application\views\template_utama.php
INFO - 2023-05-02 08:37:23 --> Final output sent to browser
DEBUG - 2023-05-02 08:37:23 --> Total execution time: 0.0317
INFO - 2023-05-02 08:37:51 --> Config Class Initialized
INFO - 2023-05-02 08:37:51 --> Hooks Class Initialized
DEBUG - 2023-05-02 08:37:51 --> UTF-8 Support Enabled
INFO - 2023-05-02 08:37:51 --> Utf8 Class Initialized
INFO - 2023-05-02 08:37:51 --> URI Class Initialized
INFO - 2023-05-02 08:37:51 --> Router Class Initialized
INFO - 2023-05-02 08:37:51 --> Output Class Initialized
INFO - 2023-05-02 08:37:51 --> Security Class Initialized
DEBUG - 2023-05-02 08:37:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-02 08:37:51 --> Input Class Initialized
INFO - 2023-05-02 08:37:51 --> Language Class Initialized
INFO - 2023-05-02 08:37:51 --> Language Class Initialized
INFO - 2023-05-02 08:37:51 --> Config Class Initialized
INFO - 2023-05-02 08:37:51 --> Loader Class Initialized
INFO - 2023-05-02 08:37:51 --> Helper loaded: url_helper
INFO - 2023-05-02 08:37:51 --> Helper loaded: file_helper
INFO - 2023-05-02 08:37:51 --> Helper loaded: form_helper
INFO - 2023-05-02 08:37:51 --> Helper loaded: my_helper
INFO - 2023-05-02 08:37:51 --> Database Driver Class Initialized
DEBUG - 2023-05-02 08:37:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-05-02 08:37:51 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-02 08:37:51 --> Controller Class Initialized
ERROR - 2023-05-02 08:37:51 --> Severity: Notice --> Undefined index: nmmapel C:\xampp\htdocs\myraportk13\application\modules\n_catatan_nna\views\form.php 5
ERROR - 2023-05-02 08:37:51 --> Severity: Notice --> Undefined index: nmkelas C:\xampp\htdocs\myraportk13\application\modules\n_catatan_nna\views\form.php 5
ERROR - 2023-05-02 08:37:51 --> Severity: Notice --> Undefined index: nmguru C:\xampp\htdocs\myraportk13\application\modules\n_catatan_nna\views\form.php 5
ERROR - 2023-05-02 08:37:51 --> Severity: Notice --> Undefined variable: nama_form C:\xampp\htdocs\myraportk13\application\modules\n_catatan_nna\views\form.php 10
ERROR - 2023-05-02 08:37:51 --> Severity: Notice --> Undefined variable: nama_form C:\xampp\htdocs\myraportk13\application\modules\n_catatan_nna\views\form.php 10
DEBUG - 2023-05-02 08:37:51 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/n_catatan_nna/views/form.php
DEBUG - 2023-05-02 08:37:51 --> File loaded: C:\xampp\htdocs\myraportk13\application\views\template_utama.php
INFO - 2023-05-02 08:37:51 --> Final output sent to browser
DEBUG - 2023-05-02 08:37:51 --> Total execution time: 0.0282
INFO - 2023-05-02 08:38:05 --> Config Class Initialized
INFO - 2023-05-02 08:38:05 --> Hooks Class Initialized
DEBUG - 2023-05-02 08:38:05 --> UTF-8 Support Enabled
INFO - 2023-05-02 08:38:05 --> Utf8 Class Initialized
INFO - 2023-05-02 08:38:05 --> URI Class Initialized
INFO - 2023-05-02 08:38:05 --> Router Class Initialized
INFO - 2023-05-02 08:38:05 --> Output Class Initialized
INFO - 2023-05-02 08:38:05 --> Security Class Initialized
DEBUG - 2023-05-02 08:38:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-02 08:38:05 --> Input Class Initialized
INFO - 2023-05-02 08:38:05 --> Language Class Initialized
INFO - 2023-05-02 08:38:05 --> Language Class Initialized
INFO - 2023-05-02 08:38:05 --> Config Class Initialized
INFO - 2023-05-02 08:38:05 --> Loader Class Initialized
INFO - 2023-05-02 08:38:05 --> Helper loaded: url_helper
INFO - 2023-05-02 08:38:05 --> Helper loaded: file_helper
INFO - 2023-05-02 08:38:05 --> Helper loaded: form_helper
INFO - 2023-05-02 08:38:05 --> Helper loaded: my_helper
INFO - 2023-05-02 08:38:05 --> Database Driver Class Initialized
DEBUG - 2023-05-02 08:38:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-05-02 08:38:05 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-02 08:38:05 --> Controller Class Initialized
ERROR - 2023-05-02 08:38:05 --> Severity: Notice --> Undefined variable: nama_form C:\xampp\htdocs\myraportk13\application\modules\n_catatan_nna\views\form.php 10
ERROR - 2023-05-02 08:38:05 --> Severity: Notice --> Undefined variable: nama_form C:\xampp\htdocs\myraportk13\application\modules\n_catatan_nna\views\form.php 10
DEBUG - 2023-05-02 08:38:05 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/n_catatan_nna/views/form.php
DEBUG - 2023-05-02 08:38:05 --> File loaded: C:\xampp\htdocs\myraportk13\application\views\template_utama.php
INFO - 2023-05-02 08:38:05 --> Final output sent to browser
DEBUG - 2023-05-02 08:38:05 --> Total execution time: 0.0353
INFO - 2023-05-02 08:39:31 --> Config Class Initialized
INFO - 2023-05-02 08:39:31 --> Hooks Class Initialized
DEBUG - 2023-05-02 08:39:31 --> UTF-8 Support Enabled
INFO - 2023-05-02 08:39:31 --> Utf8 Class Initialized
INFO - 2023-05-02 08:39:31 --> URI Class Initialized
INFO - 2023-05-02 08:39:31 --> Router Class Initialized
INFO - 2023-05-02 08:39:31 --> Output Class Initialized
INFO - 2023-05-02 08:39:31 --> Security Class Initialized
DEBUG - 2023-05-02 08:39:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-02 08:39:31 --> Input Class Initialized
INFO - 2023-05-02 08:39:31 --> Language Class Initialized
INFO - 2023-05-02 08:39:32 --> Language Class Initialized
INFO - 2023-05-02 08:39:32 --> Config Class Initialized
INFO - 2023-05-02 08:39:32 --> Loader Class Initialized
INFO - 2023-05-02 08:39:32 --> Helper loaded: url_helper
INFO - 2023-05-02 08:39:32 --> Helper loaded: file_helper
INFO - 2023-05-02 08:39:32 --> Helper loaded: form_helper
INFO - 2023-05-02 08:39:32 --> Helper loaded: my_helper
INFO - 2023-05-02 08:39:32 --> Database Driver Class Initialized
DEBUG - 2023-05-02 08:39:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-05-02 08:39:32 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-02 08:39:32 --> Controller Class Initialized
DEBUG - 2023-05-02 08:39:32 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/n_catatan_nna/views/form.php
DEBUG - 2023-05-02 08:39:32 --> File loaded: C:\xampp\htdocs\myraportk13\application\views\template_utama.php
INFO - 2023-05-02 08:39:32 --> Final output sent to browser
DEBUG - 2023-05-02 08:39:32 --> Total execution time: 0.0480
INFO - 2023-05-02 08:40:17 --> Config Class Initialized
INFO - 2023-05-02 08:40:17 --> Hooks Class Initialized
DEBUG - 2023-05-02 08:40:17 --> UTF-8 Support Enabled
INFO - 2023-05-02 08:40:17 --> Utf8 Class Initialized
INFO - 2023-05-02 08:40:17 --> URI Class Initialized
INFO - 2023-05-02 08:40:17 --> Router Class Initialized
INFO - 2023-05-02 08:40:17 --> Output Class Initialized
INFO - 2023-05-02 08:40:17 --> Security Class Initialized
DEBUG - 2023-05-02 08:40:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-02 08:40:17 --> Input Class Initialized
INFO - 2023-05-02 08:40:17 --> Language Class Initialized
ERROR - 2023-05-02 08:40:17 --> 404 Page Not Found: /index
INFO - 2023-05-02 08:40:38 --> Config Class Initialized
INFO - 2023-05-02 08:40:38 --> Hooks Class Initialized
DEBUG - 2023-05-02 08:40:38 --> UTF-8 Support Enabled
INFO - 2023-05-02 08:40:38 --> Utf8 Class Initialized
INFO - 2023-05-02 08:40:38 --> URI Class Initialized
INFO - 2023-05-02 08:40:38 --> Router Class Initialized
INFO - 2023-05-02 08:40:38 --> Output Class Initialized
INFO - 2023-05-02 08:40:38 --> Security Class Initialized
DEBUG - 2023-05-02 08:40:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-02 08:40:38 --> Input Class Initialized
INFO - 2023-05-02 08:40:38 --> Language Class Initialized
ERROR - 2023-05-02 08:40:38 --> 404 Page Not Found: ../modules/n_catatan_nna/controllers/N_catatan_nna/import_nilai
INFO - 2023-05-02 08:42:38 --> Config Class Initialized
INFO - 2023-05-02 08:42:38 --> Hooks Class Initialized
DEBUG - 2023-05-02 08:42:38 --> UTF-8 Support Enabled
INFO - 2023-05-02 08:42:38 --> Utf8 Class Initialized
INFO - 2023-05-02 08:42:38 --> URI Class Initialized
INFO - 2023-05-02 08:42:38 --> Router Class Initialized
INFO - 2023-05-02 08:42:38 --> Output Class Initialized
INFO - 2023-05-02 08:42:38 --> Security Class Initialized
DEBUG - 2023-05-02 08:42:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-02 08:42:38 --> Input Class Initialized
INFO - 2023-05-02 08:42:38 --> Language Class Initialized
INFO - 2023-05-02 08:42:38 --> Language Class Initialized
INFO - 2023-05-02 08:42:38 --> Config Class Initialized
INFO - 2023-05-02 08:42:38 --> Loader Class Initialized
INFO - 2023-05-02 08:42:38 --> Helper loaded: url_helper
INFO - 2023-05-02 08:42:38 --> Helper loaded: file_helper
INFO - 2023-05-02 08:42:38 --> Helper loaded: form_helper
INFO - 2023-05-02 08:42:38 --> Helper loaded: my_helper
INFO - 2023-05-02 08:42:38 --> Database Driver Class Initialized
DEBUG - 2023-05-02 08:42:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-05-02 08:42:38 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-02 08:42:38 --> Controller Class Initialized
DEBUG - 2023-05-02 08:42:38 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/n_catatan_nna/views/form.php
DEBUG - 2023-05-02 08:42:38 --> File loaded: C:\xampp\htdocs\myraportk13\application\views\template_utama.php
INFO - 2023-05-02 08:42:38 --> Final output sent to browser
DEBUG - 2023-05-02 08:42:38 --> Total execution time: 0.0302
INFO - 2023-05-02 08:42:38 --> Config Class Initialized
INFO - 2023-05-02 08:42:38 --> Hooks Class Initialized
DEBUG - 2023-05-02 08:42:38 --> UTF-8 Support Enabled
INFO - 2023-05-02 08:42:38 --> Utf8 Class Initialized
INFO - 2023-05-02 08:42:38 --> URI Class Initialized
INFO - 2023-05-02 08:42:38 --> Router Class Initialized
INFO - 2023-05-02 08:42:38 --> Output Class Initialized
INFO - 2023-05-02 08:42:38 --> Security Class Initialized
DEBUG - 2023-05-02 08:42:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-02 08:42:38 --> Input Class Initialized
INFO - 2023-05-02 08:42:38 --> Language Class Initialized
ERROR - 2023-05-02 08:42:38 --> 404 Page Not Found: /index
INFO - 2023-05-02 08:42:40 --> Config Class Initialized
INFO - 2023-05-02 08:42:40 --> Hooks Class Initialized
DEBUG - 2023-05-02 08:42:40 --> UTF-8 Support Enabled
INFO - 2023-05-02 08:42:40 --> Utf8 Class Initialized
INFO - 2023-05-02 08:42:40 --> URI Class Initialized
INFO - 2023-05-02 08:42:40 --> Router Class Initialized
INFO - 2023-05-02 08:42:40 --> Output Class Initialized
INFO - 2023-05-02 08:42:40 --> Security Class Initialized
DEBUG - 2023-05-02 08:42:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-02 08:42:40 --> Input Class Initialized
INFO - 2023-05-02 08:42:40 --> Language Class Initialized
INFO - 2023-05-02 08:42:40 --> Language Class Initialized
INFO - 2023-05-02 08:42:40 --> Config Class Initialized
INFO - 2023-05-02 08:42:40 --> Loader Class Initialized
INFO - 2023-05-02 08:42:40 --> Helper loaded: url_helper
INFO - 2023-05-02 08:42:40 --> Helper loaded: file_helper
INFO - 2023-05-02 08:42:40 --> Helper loaded: form_helper
INFO - 2023-05-02 08:42:40 --> Helper loaded: my_helper
INFO - 2023-05-02 08:42:40 --> Database Driver Class Initialized
DEBUG - 2023-05-02 08:42:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-05-02 08:42:40 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-02 08:42:40 --> Controller Class Initialized
DEBUG - 2023-05-02 08:42:40 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/n_catatan_nna/views/list.php
DEBUG - 2023-05-02 08:42:40 --> File loaded: C:\xampp\htdocs\myraportk13\application\views\template_utama.php
INFO - 2023-05-02 08:42:40 --> Final output sent to browser
DEBUG - 2023-05-02 08:42:40 --> Total execution time: 0.0254
INFO - 2023-05-02 08:42:40 --> Config Class Initialized
INFO - 2023-05-02 08:42:40 --> Hooks Class Initialized
DEBUG - 2023-05-02 08:42:40 --> UTF-8 Support Enabled
INFO - 2023-05-02 08:42:40 --> Utf8 Class Initialized
INFO - 2023-05-02 08:42:40 --> URI Class Initialized
INFO - 2023-05-02 08:42:40 --> Router Class Initialized
INFO - 2023-05-02 08:42:40 --> Output Class Initialized
INFO - 2023-05-02 08:42:40 --> Security Class Initialized
DEBUG - 2023-05-02 08:42:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-02 08:42:40 --> Input Class Initialized
INFO - 2023-05-02 08:42:40 --> Language Class Initialized
ERROR - 2023-05-02 08:42:40 --> 404 Page Not Found: /index
INFO - 2023-05-02 08:52:26 --> Config Class Initialized
INFO - 2023-05-02 08:52:26 --> Hooks Class Initialized
DEBUG - 2023-05-02 08:52:26 --> UTF-8 Support Enabled
INFO - 2023-05-02 08:52:26 --> Utf8 Class Initialized
INFO - 2023-05-02 08:52:26 --> URI Class Initialized
INFO - 2023-05-02 08:52:26 --> Router Class Initialized
INFO - 2023-05-02 08:52:26 --> Output Class Initialized
INFO - 2023-05-02 08:52:26 --> Security Class Initialized
DEBUG - 2023-05-02 08:52:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-02 08:52:26 --> Input Class Initialized
INFO - 2023-05-02 08:52:26 --> Language Class Initialized
INFO - 2023-05-02 08:52:26 --> Language Class Initialized
INFO - 2023-05-02 08:52:26 --> Config Class Initialized
INFO - 2023-05-02 08:52:26 --> Loader Class Initialized
INFO - 2023-05-02 08:52:26 --> Helper loaded: url_helper
INFO - 2023-05-02 08:52:26 --> Helper loaded: file_helper
INFO - 2023-05-02 08:52:26 --> Helper loaded: form_helper
INFO - 2023-05-02 08:52:26 --> Helper loaded: my_helper
INFO - 2023-05-02 08:52:26 --> Database Driver Class Initialized
DEBUG - 2023-05-02 08:52:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-05-02 08:52:26 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-02 08:52:26 --> Controller Class Initialized
DEBUG - 2023-05-02 08:52:26 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/n_catatan_nna/views/list.php
DEBUG - 2023-05-02 08:52:26 --> File loaded: C:\xampp\htdocs\myraportk13\application\views\template_utama.php
INFO - 2023-05-02 08:52:26 --> Final output sent to browser
DEBUG - 2023-05-02 08:52:26 --> Total execution time: 0.0857
INFO - 2023-05-02 08:52:26 --> Config Class Initialized
INFO - 2023-05-02 08:52:26 --> Hooks Class Initialized
DEBUG - 2023-05-02 08:52:26 --> UTF-8 Support Enabled
INFO - 2023-05-02 08:52:26 --> Utf8 Class Initialized
INFO - 2023-05-02 08:52:26 --> URI Class Initialized
INFO - 2023-05-02 08:52:26 --> Router Class Initialized
INFO - 2023-05-02 08:52:26 --> Output Class Initialized
INFO - 2023-05-02 08:52:26 --> Security Class Initialized
DEBUG - 2023-05-02 08:52:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-02 08:52:26 --> Input Class Initialized
INFO - 2023-05-02 08:52:26 --> Language Class Initialized
ERROR - 2023-05-02 08:52:26 --> 404 Page Not Found: /index
INFO - 2023-05-02 08:52:29 --> Config Class Initialized
INFO - 2023-05-02 08:52:29 --> Hooks Class Initialized
DEBUG - 2023-05-02 08:52:29 --> UTF-8 Support Enabled
INFO - 2023-05-02 08:52:29 --> Utf8 Class Initialized
INFO - 2023-05-02 08:52:29 --> URI Class Initialized
INFO - 2023-05-02 08:52:29 --> Router Class Initialized
INFO - 2023-05-02 08:52:29 --> Output Class Initialized
INFO - 2023-05-02 08:52:29 --> Security Class Initialized
DEBUG - 2023-05-02 08:52:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-02 08:52:29 --> Input Class Initialized
INFO - 2023-05-02 08:52:29 --> Language Class Initialized
INFO - 2023-05-02 08:52:29 --> Language Class Initialized
INFO - 2023-05-02 08:52:29 --> Config Class Initialized
INFO - 2023-05-02 08:52:29 --> Loader Class Initialized
INFO - 2023-05-02 08:52:29 --> Helper loaded: url_helper
INFO - 2023-05-02 08:52:29 --> Helper loaded: file_helper
INFO - 2023-05-02 08:52:29 --> Helper loaded: form_helper
INFO - 2023-05-02 08:52:29 --> Helper loaded: my_helper
INFO - 2023-05-02 08:52:29 --> Database Driver Class Initialized
DEBUG - 2023-05-02 08:52:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-05-02 08:52:29 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-02 08:52:29 --> Controller Class Initialized
DEBUG - 2023-05-02 08:52:29 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/n_catatan_nna/views/form.php
DEBUG - 2023-05-02 08:52:29 --> File loaded: C:\xampp\htdocs\myraportk13\application\views\template_utama.php
INFO - 2023-05-02 08:52:29 --> Final output sent to browser
DEBUG - 2023-05-02 08:52:29 --> Total execution time: 0.0285
INFO - 2023-05-02 08:52:30 --> Config Class Initialized
INFO - 2023-05-02 08:52:30 --> Hooks Class Initialized
DEBUG - 2023-05-02 08:52:30 --> UTF-8 Support Enabled
INFO - 2023-05-02 08:52:30 --> Utf8 Class Initialized
INFO - 2023-05-02 08:52:30 --> URI Class Initialized
INFO - 2023-05-02 08:52:30 --> Router Class Initialized
INFO - 2023-05-02 08:52:30 --> Output Class Initialized
INFO - 2023-05-02 08:52:30 --> Security Class Initialized
DEBUG - 2023-05-02 08:52:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-02 08:52:30 --> Input Class Initialized
INFO - 2023-05-02 08:52:30 --> Language Class Initialized
ERROR - 2023-05-02 08:52:30 --> 404 Page Not Found: /index
INFO - 2023-05-02 08:52:34 --> Config Class Initialized
INFO - 2023-05-02 08:52:34 --> Hooks Class Initialized
DEBUG - 2023-05-02 08:52:34 --> UTF-8 Support Enabled
INFO - 2023-05-02 08:52:34 --> Utf8 Class Initialized
INFO - 2023-05-02 08:52:34 --> URI Class Initialized
INFO - 2023-05-02 08:52:34 --> Router Class Initialized
INFO - 2023-05-02 08:52:34 --> Output Class Initialized
INFO - 2023-05-02 08:52:34 --> Security Class Initialized
DEBUG - 2023-05-02 08:52:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-02 08:52:34 --> Input Class Initialized
INFO - 2023-05-02 08:52:34 --> Language Class Initialized
INFO - 2023-05-02 08:52:34 --> Language Class Initialized
INFO - 2023-05-02 08:52:34 --> Config Class Initialized
INFO - 2023-05-02 08:52:34 --> Loader Class Initialized
INFO - 2023-05-02 08:52:34 --> Helper loaded: url_helper
INFO - 2023-05-02 08:52:34 --> Helper loaded: file_helper
INFO - 2023-05-02 08:52:34 --> Helper loaded: form_helper
INFO - 2023-05-02 08:52:34 --> Helper loaded: my_helper
INFO - 2023-05-02 08:52:34 --> Database Driver Class Initialized
DEBUG - 2023-05-02 08:52:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-05-02 08:52:34 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-02 08:52:34 --> Controller Class Initialized
ERROR - 2023-05-02 08:52:34 --> Severity: Notice --> Undefined index: tahun C:\xampp\htdocs\myraportk13\application\modules\n_catatan_nna\controllers\N_catatan_nna.php 252
INFO - 2023-05-02 08:54:11 --> Config Class Initialized
INFO - 2023-05-02 08:54:11 --> Hooks Class Initialized
DEBUG - 2023-05-02 08:54:11 --> UTF-8 Support Enabled
INFO - 2023-05-02 08:54:11 --> Utf8 Class Initialized
INFO - 2023-05-02 08:54:11 --> URI Class Initialized
INFO - 2023-05-02 08:54:11 --> Router Class Initialized
INFO - 2023-05-02 08:54:11 --> Output Class Initialized
INFO - 2023-05-02 08:54:11 --> Security Class Initialized
DEBUG - 2023-05-02 08:54:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-02 08:54:11 --> Input Class Initialized
INFO - 2023-05-02 08:54:11 --> Language Class Initialized
INFO - 2023-05-02 08:54:11 --> Language Class Initialized
INFO - 2023-05-02 08:54:11 --> Config Class Initialized
INFO - 2023-05-02 08:54:11 --> Loader Class Initialized
INFO - 2023-05-02 08:54:11 --> Helper loaded: url_helper
INFO - 2023-05-02 08:54:11 --> Helper loaded: file_helper
INFO - 2023-05-02 08:54:11 --> Helper loaded: form_helper
INFO - 2023-05-02 08:54:11 --> Helper loaded: my_helper
INFO - 2023-05-02 08:54:11 --> Database Driver Class Initialized
DEBUG - 2023-05-02 08:54:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-05-02 08:54:11 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-02 08:54:11 --> Controller Class Initialized
DEBUG - 2023-05-02 08:54:11 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/n_catatan_nna/views/form.php
DEBUG - 2023-05-02 08:54:11 --> File loaded: C:\xampp\htdocs\myraportk13\application\views\template_utama.php
INFO - 2023-05-02 08:54:11 --> Final output sent to browser
DEBUG - 2023-05-02 08:54:11 --> Total execution time: 0.0451
INFO - 2023-05-02 08:54:13 --> Config Class Initialized
INFO - 2023-05-02 08:54:13 --> Hooks Class Initialized
DEBUG - 2023-05-02 08:54:13 --> UTF-8 Support Enabled
INFO - 2023-05-02 08:54:13 --> Utf8 Class Initialized
INFO - 2023-05-02 08:54:13 --> URI Class Initialized
INFO - 2023-05-02 08:54:13 --> Router Class Initialized
INFO - 2023-05-02 08:54:13 --> Output Class Initialized
INFO - 2023-05-02 08:54:13 --> Security Class Initialized
DEBUG - 2023-05-02 08:54:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-02 08:54:13 --> Input Class Initialized
INFO - 2023-05-02 08:54:13 --> Language Class Initialized
INFO - 2023-05-02 08:54:13 --> Language Class Initialized
INFO - 2023-05-02 08:54:13 --> Config Class Initialized
INFO - 2023-05-02 08:54:13 --> Loader Class Initialized
INFO - 2023-05-02 08:54:13 --> Helper loaded: url_helper
INFO - 2023-05-02 08:54:13 --> Helper loaded: file_helper
INFO - 2023-05-02 08:54:13 --> Helper loaded: form_helper
INFO - 2023-05-02 08:54:13 --> Helper loaded: my_helper
INFO - 2023-05-02 08:54:13 --> Database Driver Class Initialized
DEBUG - 2023-05-02 08:54:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-05-02 08:54:13 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-02 08:54:13 --> Controller Class Initialized
DEBUG - 2023-05-02 08:54:13 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/n_catatan_nna/views/form.php
DEBUG - 2023-05-02 08:54:13 --> File loaded: C:\xampp\htdocs\myraportk13\application\views\template_utama.php
INFO - 2023-05-02 08:54:13 --> Final output sent to browser
DEBUG - 2023-05-02 08:54:13 --> Total execution time: 0.0260
INFO - 2023-05-02 08:54:16 --> Config Class Initialized
INFO - 2023-05-02 08:54:16 --> Hooks Class Initialized
DEBUG - 2023-05-02 08:54:16 --> UTF-8 Support Enabled
INFO - 2023-05-02 08:54:16 --> Utf8 Class Initialized
INFO - 2023-05-02 08:54:16 --> URI Class Initialized
INFO - 2023-05-02 08:54:16 --> Router Class Initialized
INFO - 2023-05-02 08:54:16 --> Output Class Initialized
INFO - 2023-05-02 08:54:16 --> Security Class Initialized
DEBUG - 2023-05-02 08:54:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-02 08:54:16 --> Input Class Initialized
INFO - 2023-05-02 08:54:16 --> Language Class Initialized
INFO - 2023-05-02 08:54:16 --> Language Class Initialized
INFO - 2023-05-02 08:54:16 --> Config Class Initialized
INFO - 2023-05-02 08:54:16 --> Loader Class Initialized
INFO - 2023-05-02 08:54:16 --> Helper loaded: url_helper
INFO - 2023-05-02 08:54:16 --> Helper loaded: file_helper
INFO - 2023-05-02 08:54:16 --> Helper loaded: form_helper
INFO - 2023-05-02 08:54:16 --> Helper loaded: my_helper
INFO - 2023-05-02 08:54:16 --> Database Driver Class Initialized
DEBUG - 2023-05-02 08:54:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-05-02 08:54:16 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-02 08:54:16 --> Controller Class Initialized
INFO - 2023-05-02 08:54:54 --> Config Class Initialized
INFO - 2023-05-02 08:54:54 --> Hooks Class Initialized
DEBUG - 2023-05-02 08:54:54 --> UTF-8 Support Enabled
INFO - 2023-05-02 08:54:54 --> Utf8 Class Initialized
INFO - 2023-05-02 08:54:54 --> URI Class Initialized
INFO - 2023-05-02 08:54:54 --> Router Class Initialized
INFO - 2023-05-02 08:54:54 --> Output Class Initialized
INFO - 2023-05-02 08:54:54 --> Security Class Initialized
DEBUG - 2023-05-02 08:54:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-02 08:54:54 --> Input Class Initialized
INFO - 2023-05-02 08:54:54 --> Language Class Initialized
INFO - 2023-05-02 08:54:54 --> Language Class Initialized
INFO - 2023-05-02 08:54:54 --> Config Class Initialized
INFO - 2023-05-02 08:54:54 --> Loader Class Initialized
INFO - 2023-05-02 08:54:54 --> Helper loaded: url_helper
INFO - 2023-05-02 08:54:54 --> Helper loaded: file_helper
INFO - 2023-05-02 08:54:54 --> Helper loaded: form_helper
INFO - 2023-05-02 08:54:54 --> Helper loaded: my_helper
INFO - 2023-05-02 08:54:54 --> Database Driver Class Initialized
DEBUG - 2023-05-02 08:54:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-05-02 08:54:54 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-02 08:54:54 --> Controller Class Initialized
DEBUG - 2023-05-02 08:54:54 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/n_catatan_nna/views/form.php
DEBUG - 2023-05-02 08:54:54 --> File loaded: C:\xampp\htdocs\myraportk13\application\views\template_utama.php
INFO - 2023-05-02 08:54:54 --> Final output sent to browser
DEBUG - 2023-05-02 08:54:54 --> Total execution time: 0.0650
INFO - 2023-05-02 08:54:56 --> Config Class Initialized
INFO - 2023-05-02 08:54:56 --> Hooks Class Initialized
DEBUG - 2023-05-02 08:54:56 --> UTF-8 Support Enabled
INFO - 2023-05-02 08:54:56 --> Utf8 Class Initialized
INFO - 2023-05-02 08:54:56 --> URI Class Initialized
INFO - 2023-05-02 08:54:56 --> Router Class Initialized
INFO - 2023-05-02 08:54:56 --> Output Class Initialized
INFO - 2023-05-02 08:54:56 --> Security Class Initialized
DEBUG - 2023-05-02 08:54:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-02 08:54:56 --> Input Class Initialized
INFO - 2023-05-02 08:54:56 --> Language Class Initialized
INFO - 2023-05-02 08:54:56 --> Language Class Initialized
INFO - 2023-05-02 08:54:56 --> Config Class Initialized
INFO - 2023-05-02 08:54:56 --> Loader Class Initialized
INFO - 2023-05-02 08:54:56 --> Helper loaded: url_helper
INFO - 2023-05-02 08:54:56 --> Helper loaded: file_helper
INFO - 2023-05-02 08:54:56 --> Helper loaded: form_helper
INFO - 2023-05-02 08:54:56 --> Helper loaded: my_helper
INFO - 2023-05-02 08:54:56 --> Database Driver Class Initialized
DEBUG - 2023-05-02 08:54:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-05-02 08:54:56 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-02 08:54:56 --> Controller Class Initialized
DEBUG - 2023-05-02 08:54:56 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/n_catatan_nna/views/list.php
DEBUG - 2023-05-02 08:54:56 --> File loaded: C:\xampp\htdocs\myraportk13\application\views\template_utama.php
INFO - 2023-05-02 08:54:56 --> Final output sent to browser
DEBUG - 2023-05-02 08:54:56 --> Total execution time: 0.0254
INFO - 2023-05-02 08:54:57 --> Config Class Initialized
INFO - 2023-05-02 08:54:57 --> Hooks Class Initialized
DEBUG - 2023-05-02 08:54:57 --> UTF-8 Support Enabled
INFO - 2023-05-02 08:54:57 --> Utf8 Class Initialized
INFO - 2023-05-02 08:54:57 --> URI Class Initialized
INFO - 2023-05-02 08:54:57 --> Router Class Initialized
INFO - 2023-05-02 08:54:57 --> Output Class Initialized
INFO - 2023-05-02 08:54:57 --> Security Class Initialized
DEBUG - 2023-05-02 08:54:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-02 08:54:57 --> Input Class Initialized
INFO - 2023-05-02 08:54:57 --> Language Class Initialized
INFO - 2023-05-02 08:54:57 --> Language Class Initialized
INFO - 2023-05-02 08:54:57 --> Config Class Initialized
INFO - 2023-05-02 08:54:57 --> Loader Class Initialized
INFO - 2023-05-02 08:54:57 --> Helper loaded: url_helper
INFO - 2023-05-02 08:54:57 --> Helper loaded: file_helper
INFO - 2023-05-02 08:54:57 --> Helper loaded: form_helper
INFO - 2023-05-02 08:54:57 --> Helper loaded: my_helper
INFO - 2023-05-02 08:54:57 --> Database Driver Class Initialized
DEBUG - 2023-05-02 08:54:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-05-02 08:54:57 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-02 08:54:57 --> Controller Class Initialized
DEBUG - 2023-05-02 08:54:57 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/n_catatan_nna/views/list.php
DEBUG - 2023-05-02 08:54:57 --> File loaded: C:\xampp\htdocs\myraportk13\application\views\template_utama.php
INFO - 2023-05-02 08:54:57 --> Final output sent to browser
DEBUG - 2023-05-02 08:54:57 --> Total execution time: 0.0251
INFO - 2023-05-02 08:54:59 --> Config Class Initialized
INFO - 2023-05-02 08:54:59 --> Hooks Class Initialized
DEBUG - 2023-05-02 08:54:59 --> UTF-8 Support Enabled
INFO - 2023-05-02 08:54:59 --> Utf8 Class Initialized
INFO - 2023-05-02 08:54:59 --> URI Class Initialized
INFO - 2023-05-02 08:54:59 --> Router Class Initialized
INFO - 2023-05-02 08:54:59 --> Output Class Initialized
INFO - 2023-05-02 08:54:59 --> Security Class Initialized
DEBUG - 2023-05-02 08:54:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-02 08:54:59 --> Input Class Initialized
INFO - 2023-05-02 08:54:59 --> Language Class Initialized
INFO - 2023-05-02 08:54:59 --> Language Class Initialized
INFO - 2023-05-02 08:54:59 --> Config Class Initialized
INFO - 2023-05-02 08:54:59 --> Loader Class Initialized
INFO - 2023-05-02 08:54:59 --> Helper loaded: url_helper
INFO - 2023-05-02 08:54:59 --> Helper loaded: file_helper
INFO - 2023-05-02 08:54:59 --> Helper loaded: form_helper
INFO - 2023-05-02 08:54:59 --> Helper loaded: my_helper
INFO - 2023-05-02 08:54:59 --> Database Driver Class Initialized
DEBUG - 2023-05-02 08:54:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-05-02 08:54:59 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-02 08:54:59 --> Controller Class Initialized
INFO - 2023-05-02 08:55:11 --> Config Class Initialized
INFO - 2023-05-02 08:55:11 --> Hooks Class Initialized
DEBUG - 2023-05-02 08:55:11 --> UTF-8 Support Enabled
INFO - 2023-05-02 08:55:11 --> Utf8 Class Initialized
INFO - 2023-05-02 08:55:11 --> URI Class Initialized
INFO - 2023-05-02 08:55:11 --> Router Class Initialized
INFO - 2023-05-02 08:55:11 --> Output Class Initialized
INFO - 2023-05-02 08:55:11 --> Security Class Initialized
DEBUG - 2023-05-02 08:55:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-02 08:55:11 --> Input Class Initialized
INFO - 2023-05-02 08:55:11 --> Language Class Initialized
INFO - 2023-05-02 08:55:11 --> Language Class Initialized
INFO - 2023-05-02 08:55:11 --> Config Class Initialized
INFO - 2023-05-02 08:55:11 --> Loader Class Initialized
INFO - 2023-05-02 08:55:11 --> Helper loaded: url_helper
INFO - 2023-05-02 08:55:11 --> Helper loaded: file_helper
INFO - 2023-05-02 08:55:11 --> Helper loaded: form_helper
INFO - 2023-05-02 08:55:11 --> Helper loaded: my_helper
INFO - 2023-05-02 08:55:11 --> Database Driver Class Initialized
DEBUG - 2023-05-02 08:55:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-05-02 08:55:11 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-02 08:55:11 --> Controller Class Initialized
DEBUG - 2023-05-02 08:55:11 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/n_catatan_nna/views/form.php
DEBUG - 2023-05-02 08:55:11 --> File loaded: C:\xampp\htdocs\myraportk13\application\views\template_utama.php
INFO - 2023-05-02 08:55:11 --> Final output sent to browser
DEBUG - 2023-05-02 08:55:11 --> Total execution time: 0.0283
INFO - 2023-05-02 08:55:15 --> Config Class Initialized
INFO - 2023-05-02 08:55:15 --> Hooks Class Initialized
DEBUG - 2023-05-02 08:55:15 --> UTF-8 Support Enabled
INFO - 2023-05-02 08:55:15 --> Utf8 Class Initialized
INFO - 2023-05-02 08:55:15 --> URI Class Initialized
INFO - 2023-05-02 08:55:15 --> Router Class Initialized
INFO - 2023-05-02 08:55:15 --> Output Class Initialized
INFO - 2023-05-02 08:55:15 --> Security Class Initialized
DEBUG - 2023-05-02 08:55:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-02 08:55:15 --> Input Class Initialized
INFO - 2023-05-02 08:55:15 --> Language Class Initialized
ERROR - 2023-05-02 08:55:15 --> 404 Page Not Found: /index
INFO - 2023-05-02 08:55:17 --> Config Class Initialized
INFO - 2023-05-02 08:55:17 --> Hooks Class Initialized
DEBUG - 2023-05-02 08:55:17 --> UTF-8 Support Enabled
INFO - 2023-05-02 08:55:17 --> Utf8 Class Initialized
INFO - 2023-05-02 08:55:17 --> URI Class Initialized
INFO - 2023-05-02 08:55:17 --> Router Class Initialized
INFO - 2023-05-02 08:55:17 --> Output Class Initialized
INFO - 2023-05-02 08:55:17 --> Security Class Initialized
DEBUG - 2023-05-02 08:55:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-02 08:55:17 --> Input Class Initialized
INFO - 2023-05-02 08:55:17 --> Language Class Initialized
INFO - 2023-05-02 08:55:17 --> Language Class Initialized
INFO - 2023-05-02 08:55:17 --> Config Class Initialized
INFO - 2023-05-02 08:55:17 --> Loader Class Initialized
INFO - 2023-05-02 08:55:17 --> Helper loaded: url_helper
INFO - 2023-05-02 08:55:17 --> Helper loaded: file_helper
INFO - 2023-05-02 08:55:17 --> Helper loaded: form_helper
INFO - 2023-05-02 08:55:17 --> Helper loaded: my_helper
INFO - 2023-05-02 08:55:17 --> Database Driver Class Initialized
DEBUG - 2023-05-02 08:55:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-05-02 08:55:17 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-02 08:55:17 --> Controller Class Initialized
INFO - 2023-05-02 08:55:59 --> Config Class Initialized
INFO - 2023-05-02 08:55:59 --> Hooks Class Initialized
DEBUG - 2023-05-02 08:55:59 --> UTF-8 Support Enabled
INFO - 2023-05-02 08:55:59 --> Utf8 Class Initialized
INFO - 2023-05-02 08:55:59 --> URI Class Initialized
INFO - 2023-05-02 08:55:59 --> Router Class Initialized
INFO - 2023-05-02 08:55:59 --> Output Class Initialized
INFO - 2023-05-02 08:55:59 --> Security Class Initialized
DEBUG - 2023-05-02 08:55:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-02 08:55:59 --> Input Class Initialized
INFO - 2023-05-02 08:55:59 --> Language Class Initialized
INFO - 2023-05-02 08:55:59 --> Language Class Initialized
INFO - 2023-05-02 08:55:59 --> Config Class Initialized
INFO - 2023-05-02 08:55:59 --> Loader Class Initialized
INFO - 2023-05-02 08:55:59 --> Helper loaded: url_helper
INFO - 2023-05-02 08:55:59 --> Helper loaded: file_helper
INFO - 2023-05-02 08:55:59 --> Helper loaded: form_helper
INFO - 2023-05-02 08:55:59 --> Helper loaded: my_helper
INFO - 2023-05-02 08:55:59 --> Database Driver Class Initialized
DEBUG - 2023-05-02 08:55:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-05-02 08:55:59 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-02 08:55:59 --> Controller Class Initialized
DEBUG - 2023-05-02 08:55:59 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/n_catatan_nna/views/form.php
DEBUG - 2023-05-02 08:55:59 --> File loaded: C:\xampp\htdocs\myraportk13\application\views\template_utama.php
INFO - 2023-05-02 08:55:59 --> Final output sent to browser
DEBUG - 2023-05-02 08:55:59 --> Total execution time: 0.0507
INFO - 2023-05-02 08:55:59 --> Config Class Initialized
INFO - 2023-05-02 08:55:59 --> Hooks Class Initialized
DEBUG - 2023-05-02 08:55:59 --> UTF-8 Support Enabled
INFO - 2023-05-02 08:55:59 --> Utf8 Class Initialized
INFO - 2023-05-02 08:55:59 --> URI Class Initialized
INFO - 2023-05-02 08:55:59 --> Router Class Initialized
INFO - 2023-05-02 08:55:59 --> Output Class Initialized
INFO - 2023-05-02 08:55:59 --> Security Class Initialized
DEBUG - 2023-05-02 08:55:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-02 08:55:59 --> Input Class Initialized
INFO - 2023-05-02 08:55:59 --> Language Class Initialized
ERROR - 2023-05-02 08:55:59 --> 404 Page Not Found: /index
INFO - 2023-05-02 08:56:01 --> Config Class Initialized
INFO - 2023-05-02 08:56:01 --> Hooks Class Initialized
DEBUG - 2023-05-02 08:56:01 --> UTF-8 Support Enabled
INFO - 2023-05-02 08:56:01 --> Utf8 Class Initialized
INFO - 2023-05-02 08:56:01 --> URI Class Initialized
INFO - 2023-05-02 08:56:01 --> Router Class Initialized
INFO - 2023-05-02 08:56:01 --> Output Class Initialized
INFO - 2023-05-02 08:56:01 --> Security Class Initialized
DEBUG - 2023-05-02 08:56:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-02 08:56:01 --> Input Class Initialized
INFO - 2023-05-02 08:56:01 --> Language Class Initialized
INFO - 2023-05-02 08:56:01 --> Language Class Initialized
INFO - 2023-05-02 08:56:01 --> Config Class Initialized
INFO - 2023-05-02 08:56:01 --> Loader Class Initialized
INFO - 2023-05-02 08:56:01 --> Helper loaded: url_helper
INFO - 2023-05-02 08:56:01 --> Helper loaded: file_helper
INFO - 2023-05-02 08:56:01 --> Helper loaded: form_helper
INFO - 2023-05-02 08:56:01 --> Helper loaded: my_helper
INFO - 2023-05-02 08:56:01 --> Database Driver Class Initialized
DEBUG - 2023-05-02 08:56:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-05-02 08:56:01 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-02 08:56:01 --> Controller Class Initialized
INFO - 2023-05-02 08:56:03 --> Config Class Initialized
INFO - 2023-05-02 08:56:03 --> Hooks Class Initialized
DEBUG - 2023-05-02 08:56:03 --> UTF-8 Support Enabled
INFO - 2023-05-02 08:56:03 --> Utf8 Class Initialized
INFO - 2023-05-02 08:56:03 --> URI Class Initialized
INFO - 2023-05-02 08:56:03 --> Router Class Initialized
INFO - 2023-05-02 08:56:03 --> Output Class Initialized
INFO - 2023-05-02 08:56:03 --> Security Class Initialized
DEBUG - 2023-05-02 08:56:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-02 08:56:03 --> Input Class Initialized
INFO - 2023-05-02 08:56:03 --> Language Class Initialized
INFO - 2023-05-02 08:56:03 --> Language Class Initialized
INFO - 2023-05-02 08:56:03 --> Config Class Initialized
INFO - 2023-05-02 08:56:03 --> Loader Class Initialized
INFO - 2023-05-02 08:56:03 --> Helper loaded: url_helper
INFO - 2023-05-02 08:56:03 --> Helper loaded: file_helper
INFO - 2023-05-02 08:56:03 --> Helper loaded: form_helper
INFO - 2023-05-02 08:56:03 --> Helper loaded: my_helper
INFO - 2023-05-02 08:56:03 --> Database Driver Class Initialized
DEBUG - 2023-05-02 08:56:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-05-02 08:56:03 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-02 08:56:03 --> Controller Class Initialized
DEBUG - 2023-05-02 08:56:03 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/n_catatan_nna/views/form.php
DEBUG - 2023-05-02 08:56:03 --> File loaded: C:\xampp\htdocs\myraportk13\application\views\template_utama.php
INFO - 2023-05-02 08:56:03 --> Final output sent to browser
DEBUG - 2023-05-02 08:56:03 --> Total execution time: 0.0504
INFO - 2023-05-02 08:56:03 --> Config Class Initialized
INFO - 2023-05-02 08:56:03 --> Hooks Class Initialized
DEBUG - 2023-05-02 08:56:03 --> UTF-8 Support Enabled
INFO - 2023-05-02 08:56:03 --> Utf8 Class Initialized
INFO - 2023-05-02 08:56:03 --> URI Class Initialized
INFO - 2023-05-02 08:56:03 --> Router Class Initialized
INFO - 2023-05-02 08:56:03 --> Output Class Initialized
INFO - 2023-05-02 08:56:03 --> Security Class Initialized
DEBUG - 2023-05-02 08:56:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-02 08:56:03 --> Input Class Initialized
INFO - 2023-05-02 08:56:03 --> Language Class Initialized
ERROR - 2023-05-02 08:56:03 --> 404 Page Not Found: /index
INFO - 2023-05-02 08:56:04 --> Config Class Initialized
INFO - 2023-05-02 08:56:04 --> Hooks Class Initialized
DEBUG - 2023-05-02 08:56:04 --> UTF-8 Support Enabled
INFO - 2023-05-02 08:56:04 --> Utf8 Class Initialized
INFO - 2023-05-02 08:56:04 --> URI Class Initialized
INFO - 2023-05-02 08:56:04 --> Router Class Initialized
INFO - 2023-05-02 08:56:04 --> Output Class Initialized
INFO - 2023-05-02 08:56:04 --> Security Class Initialized
DEBUG - 2023-05-02 08:56:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-02 08:56:04 --> Input Class Initialized
INFO - 2023-05-02 08:56:04 --> Language Class Initialized
INFO - 2023-05-02 08:56:04 --> Language Class Initialized
INFO - 2023-05-02 08:56:04 --> Config Class Initialized
INFO - 2023-05-02 08:56:04 --> Loader Class Initialized
INFO - 2023-05-02 08:56:04 --> Helper loaded: url_helper
INFO - 2023-05-02 08:56:04 --> Helper loaded: file_helper
INFO - 2023-05-02 08:56:04 --> Helper loaded: form_helper
INFO - 2023-05-02 08:56:04 --> Helper loaded: my_helper
INFO - 2023-05-02 08:56:04 --> Database Driver Class Initialized
DEBUG - 2023-05-02 08:56:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-05-02 08:56:04 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-02 08:56:04 --> Controller Class Initialized
DEBUG - 2023-05-02 08:56:04 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/n_catatan_nna/views/form.php
DEBUG - 2023-05-02 08:56:04 --> File loaded: C:\xampp\htdocs\myraportk13\application\views\template_utama.php
INFO - 2023-05-02 08:56:04 --> Final output sent to browser
DEBUG - 2023-05-02 08:56:04 --> Total execution time: 0.0823
INFO - 2023-05-02 08:56:04 --> Config Class Initialized
INFO - 2023-05-02 08:56:04 --> Hooks Class Initialized
DEBUG - 2023-05-02 08:56:04 --> UTF-8 Support Enabled
INFO - 2023-05-02 08:56:04 --> Utf8 Class Initialized
INFO - 2023-05-02 08:56:04 --> URI Class Initialized
INFO - 2023-05-02 08:56:04 --> Router Class Initialized
INFO - 2023-05-02 08:56:04 --> Output Class Initialized
INFO - 2023-05-02 08:56:04 --> Security Class Initialized
DEBUG - 2023-05-02 08:56:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-02 08:56:04 --> Input Class Initialized
INFO - 2023-05-02 08:56:04 --> Language Class Initialized
ERROR - 2023-05-02 08:56:04 --> 404 Page Not Found: /index
INFO - 2023-05-02 08:56:07 --> Config Class Initialized
INFO - 2023-05-02 08:56:07 --> Hooks Class Initialized
DEBUG - 2023-05-02 08:56:07 --> UTF-8 Support Enabled
INFO - 2023-05-02 08:56:07 --> Utf8 Class Initialized
INFO - 2023-05-02 08:56:07 --> URI Class Initialized
INFO - 2023-05-02 08:56:07 --> Router Class Initialized
INFO - 2023-05-02 08:56:07 --> Output Class Initialized
INFO - 2023-05-02 08:56:07 --> Security Class Initialized
DEBUG - 2023-05-02 08:56:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-02 08:56:07 --> Input Class Initialized
INFO - 2023-05-02 08:56:07 --> Language Class Initialized
INFO - 2023-05-02 08:56:07 --> Language Class Initialized
INFO - 2023-05-02 08:56:07 --> Config Class Initialized
INFO - 2023-05-02 08:56:07 --> Loader Class Initialized
INFO - 2023-05-02 08:56:07 --> Helper loaded: url_helper
INFO - 2023-05-02 08:56:07 --> Helper loaded: file_helper
INFO - 2023-05-02 08:56:07 --> Helper loaded: form_helper
INFO - 2023-05-02 08:56:07 --> Helper loaded: my_helper
INFO - 2023-05-02 08:56:07 --> Database Driver Class Initialized
DEBUG - 2023-05-02 08:56:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-05-02 08:56:07 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-02 08:56:07 --> Controller Class Initialized
INFO - 2023-05-02 08:56:34 --> Config Class Initialized
INFO - 2023-05-02 08:56:34 --> Hooks Class Initialized
DEBUG - 2023-05-02 08:56:34 --> UTF-8 Support Enabled
INFO - 2023-05-02 08:56:34 --> Utf8 Class Initialized
INFO - 2023-05-02 08:56:34 --> URI Class Initialized
INFO - 2023-05-02 08:56:34 --> Router Class Initialized
INFO - 2023-05-02 08:56:34 --> Output Class Initialized
INFO - 2023-05-02 08:56:34 --> Security Class Initialized
DEBUG - 2023-05-02 08:56:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-02 08:56:34 --> Input Class Initialized
INFO - 2023-05-02 08:56:34 --> Language Class Initialized
INFO - 2023-05-02 08:56:34 --> Language Class Initialized
INFO - 2023-05-02 08:56:34 --> Config Class Initialized
INFO - 2023-05-02 08:56:34 --> Loader Class Initialized
INFO - 2023-05-02 08:56:34 --> Helper loaded: url_helper
INFO - 2023-05-02 08:56:34 --> Helper loaded: file_helper
INFO - 2023-05-02 08:56:34 --> Helper loaded: form_helper
INFO - 2023-05-02 08:56:34 --> Helper loaded: my_helper
INFO - 2023-05-02 08:56:34 --> Database Driver Class Initialized
DEBUG - 2023-05-02 08:56:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-05-02 08:56:34 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-02 08:56:34 --> Controller Class Initialized
INFO - 2023-05-02 08:56:34 --> Config Class Initialized
INFO - 2023-05-02 08:56:34 --> Hooks Class Initialized
DEBUG - 2023-05-02 08:56:34 --> UTF-8 Support Enabled
INFO - 2023-05-02 08:56:34 --> Utf8 Class Initialized
INFO - 2023-05-02 08:56:34 --> URI Class Initialized
INFO - 2023-05-02 08:56:34 --> Router Class Initialized
INFO - 2023-05-02 08:56:34 --> Output Class Initialized
INFO - 2023-05-02 08:56:34 --> Security Class Initialized
DEBUG - 2023-05-02 08:56:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-02 08:56:34 --> Input Class Initialized
INFO - 2023-05-02 08:56:34 --> Language Class Initialized
INFO - 2023-05-02 08:56:34 --> Language Class Initialized
INFO - 2023-05-02 08:56:34 --> Config Class Initialized
INFO - 2023-05-02 08:56:34 --> Loader Class Initialized
INFO - 2023-05-02 08:56:35 --> Helper loaded: url_helper
INFO - 2023-05-02 08:56:35 --> Helper loaded: file_helper
INFO - 2023-05-02 08:56:35 --> Helper loaded: form_helper
INFO - 2023-05-02 08:56:35 --> Helper loaded: my_helper
INFO - 2023-05-02 08:56:35 --> Database Driver Class Initialized
DEBUG - 2023-05-02 08:56:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-05-02 08:56:35 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-02 08:56:35 --> Controller Class Initialized
INFO - 2023-05-02 08:58:26 --> Config Class Initialized
INFO - 2023-05-02 08:58:26 --> Hooks Class Initialized
DEBUG - 2023-05-02 08:58:26 --> UTF-8 Support Enabled
INFO - 2023-05-02 08:58:26 --> Utf8 Class Initialized
INFO - 2023-05-02 08:58:26 --> URI Class Initialized
INFO - 2023-05-02 08:58:26 --> Router Class Initialized
INFO - 2023-05-02 08:58:26 --> Output Class Initialized
INFO - 2023-05-02 08:58:26 --> Security Class Initialized
DEBUG - 2023-05-02 08:58:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-02 08:58:26 --> Input Class Initialized
INFO - 2023-05-02 08:58:26 --> Language Class Initialized
INFO - 2023-05-02 08:58:26 --> Language Class Initialized
INFO - 2023-05-02 08:58:26 --> Config Class Initialized
INFO - 2023-05-02 08:58:26 --> Loader Class Initialized
INFO - 2023-05-02 08:58:26 --> Helper loaded: url_helper
INFO - 2023-05-02 08:58:26 --> Helper loaded: file_helper
INFO - 2023-05-02 08:58:26 --> Helper loaded: form_helper
INFO - 2023-05-02 08:58:26 --> Helper loaded: my_helper
INFO - 2023-05-02 08:58:26 --> Database Driver Class Initialized
DEBUG - 2023-05-02 08:58:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-05-02 08:58:26 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-02 08:58:26 --> Controller Class Initialized
DEBUG - 2023-05-02 08:58:26 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/n_catatan_nna/views/form.php
DEBUG - 2023-05-02 08:58:26 --> File loaded: C:\xampp\htdocs\myraportk13\application\views\template_utama.php
INFO - 2023-05-02 08:58:26 --> Final output sent to browser
DEBUG - 2023-05-02 08:58:26 --> Total execution time: 0.0573
INFO - 2023-05-02 08:58:26 --> Config Class Initialized
INFO - 2023-05-02 08:58:26 --> Hooks Class Initialized
DEBUG - 2023-05-02 08:58:26 --> UTF-8 Support Enabled
INFO - 2023-05-02 08:58:26 --> Utf8 Class Initialized
INFO - 2023-05-02 08:58:26 --> URI Class Initialized
INFO - 2023-05-02 08:58:26 --> Router Class Initialized
INFO - 2023-05-02 08:58:26 --> Output Class Initialized
INFO - 2023-05-02 08:58:26 --> Security Class Initialized
DEBUG - 2023-05-02 08:58:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-02 08:58:26 --> Input Class Initialized
INFO - 2023-05-02 08:58:26 --> Language Class Initialized
ERROR - 2023-05-02 08:58:26 --> 404 Page Not Found: /index
INFO - 2023-05-02 08:58:27 --> Config Class Initialized
INFO - 2023-05-02 08:58:27 --> Hooks Class Initialized
DEBUG - 2023-05-02 08:58:27 --> UTF-8 Support Enabled
INFO - 2023-05-02 08:58:27 --> Utf8 Class Initialized
INFO - 2023-05-02 08:58:27 --> URI Class Initialized
INFO - 2023-05-02 08:58:27 --> Router Class Initialized
INFO - 2023-05-02 08:58:27 --> Output Class Initialized
INFO - 2023-05-02 08:58:27 --> Security Class Initialized
DEBUG - 2023-05-02 08:58:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-02 08:58:27 --> Input Class Initialized
INFO - 2023-05-02 08:58:27 --> Language Class Initialized
INFO - 2023-05-02 08:58:27 --> Language Class Initialized
INFO - 2023-05-02 08:58:27 --> Config Class Initialized
INFO - 2023-05-02 08:58:27 --> Loader Class Initialized
INFO - 2023-05-02 08:58:27 --> Helper loaded: url_helper
INFO - 2023-05-02 08:58:27 --> Helper loaded: file_helper
INFO - 2023-05-02 08:58:27 --> Helper loaded: form_helper
INFO - 2023-05-02 08:58:27 --> Helper loaded: my_helper
INFO - 2023-05-02 08:58:27 --> Database Driver Class Initialized
DEBUG - 2023-05-02 08:58:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-05-02 08:58:27 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-02 08:58:27 --> Controller Class Initialized
DEBUG - 2023-05-02 08:58:27 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/n_catatan_nna/views/form.php
DEBUG - 2023-05-02 08:58:27 --> File loaded: C:\xampp\htdocs\myraportk13\application\views\template_utama.php
INFO - 2023-05-02 08:58:27 --> Final output sent to browser
DEBUG - 2023-05-02 08:58:27 --> Total execution time: 0.0346
INFO - 2023-05-02 08:58:27 --> Config Class Initialized
INFO - 2023-05-02 08:58:27 --> Hooks Class Initialized
DEBUG - 2023-05-02 08:58:27 --> UTF-8 Support Enabled
INFO - 2023-05-02 08:58:27 --> Utf8 Class Initialized
INFO - 2023-05-02 08:58:27 --> URI Class Initialized
INFO - 2023-05-02 08:58:27 --> Router Class Initialized
INFO - 2023-05-02 08:58:27 --> Output Class Initialized
INFO - 2023-05-02 08:58:27 --> Security Class Initialized
DEBUG - 2023-05-02 08:58:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-02 08:58:27 --> Input Class Initialized
INFO - 2023-05-02 08:58:27 --> Language Class Initialized
ERROR - 2023-05-02 08:58:27 --> 404 Page Not Found: /index
INFO - 2023-05-02 08:58:30 --> Config Class Initialized
INFO - 2023-05-02 08:58:30 --> Hooks Class Initialized
DEBUG - 2023-05-02 08:58:30 --> UTF-8 Support Enabled
INFO - 2023-05-02 08:58:30 --> Utf8 Class Initialized
INFO - 2023-05-02 08:58:30 --> URI Class Initialized
INFO - 2023-05-02 08:58:30 --> Router Class Initialized
INFO - 2023-05-02 08:58:30 --> Output Class Initialized
INFO - 2023-05-02 08:58:30 --> Security Class Initialized
DEBUG - 2023-05-02 08:58:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-02 08:58:30 --> Input Class Initialized
INFO - 2023-05-02 08:58:30 --> Language Class Initialized
INFO - 2023-05-02 08:58:30 --> Language Class Initialized
INFO - 2023-05-02 08:58:30 --> Config Class Initialized
INFO - 2023-05-02 08:58:30 --> Loader Class Initialized
INFO - 2023-05-02 08:58:30 --> Helper loaded: url_helper
INFO - 2023-05-02 08:58:30 --> Helper loaded: file_helper
INFO - 2023-05-02 08:58:30 --> Helper loaded: form_helper
INFO - 2023-05-02 08:58:30 --> Helper loaded: my_helper
INFO - 2023-05-02 08:58:30 --> Database Driver Class Initialized
DEBUG - 2023-05-02 08:58:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-05-02 08:58:30 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-02 08:58:30 --> Controller Class Initialized
INFO - 2023-05-02 08:58:39 --> Config Class Initialized
INFO - 2023-05-02 08:58:39 --> Hooks Class Initialized
DEBUG - 2023-05-02 08:58:39 --> UTF-8 Support Enabled
INFO - 2023-05-02 08:58:39 --> Utf8 Class Initialized
INFO - 2023-05-02 08:58:39 --> URI Class Initialized
INFO - 2023-05-02 08:58:39 --> Router Class Initialized
INFO - 2023-05-02 08:58:39 --> Output Class Initialized
INFO - 2023-05-02 08:58:39 --> Security Class Initialized
DEBUG - 2023-05-02 08:58:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-02 08:58:39 --> Input Class Initialized
INFO - 2023-05-02 08:58:39 --> Language Class Initialized
INFO - 2023-05-02 08:58:39 --> Language Class Initialized
INFO - 2023-05-02 08:58:39 --> Config Class Initialized
INFO - 2023-05-02 08:58:39 --> Loader Class Initialized
INFO - 2023-05-02 08:58:39 --> Helper loaded: url_helper
INFO - 2023-05-02 08:58:39 --> Helper loaded: file_helper
INFO - 2023-05-02 08:58:39 --> Helper loaded: form_helper
INFO - 2023-05-02 08:58:39 --> Helper loaded: my_helper
INFO - 2023-05-02 08:58:39 --> Database Driver Class Initialized
DEBUG - 2023-05-02 08:58:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-05-02 08:58:39 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-02 08:58:39 --> Controller Class Initialized
INFO - 2023-05-02 08:59:21 --> Config Class Initialized
INFO - 2023-05-02 08:59:21 --> Hooks Class Initialized
DEBUG - 2023-05-02 08:59:21 --> UTF-8 Support Enabled
INFO - 2023-05-02 08:59:21 --> Utf8 Class Initialized
INFO - 2023-05-02 08:59:21 --> URI Class Initialized
INFO - 2023-05-02 08:59:21 --> Router Class Initialized
INFO - 2023-05-02 08:59:21 --> Output Class Initialized
INFO - 2023-05-02 08:59:21 --> Security Class Initialized
DEBUG - 2023-05-02 08:59:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-02 08:59:21 --> Input Class Initialized
INFO - 2023-05-02 08:59:21 --> Language Class Initialized
INFO - 2023-05-02 08:59:21 --> Language Class Initialized
INFO - 2023-05-02 08:59:21 --> Config Class Initialized
INFO - 2023-05-02 08:59:21 --> Loader Class Initialized
INFO - 2023-05-02 08:59:21 --> Helper loaded: url_helper
INFO - 2023-05-02 08:59:21 --> Helper loaded: file_helper
INFO - 2023-05-02 08:59:21 --> Helper loaded: form_helper
INFO - 2023-05-02 08:59:21 --> Helper loaded: my_helper
INFO - 2023-05-02 08:59:21 --> Database Driver Class Initialized
DEBUG - 2023-05-02 08:59:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-05-02 08:59:21 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-02 08:59:21 --> Controller Class Initialized
INFO - 2023-05-02 09:00:11 --> Config Class Initialized
INFO - 2023-05-02 09:00:11 --> Hooks Class Initialized
DEBUG - 2023-05-02 09:00:11 --> UTF-8 Support Enabled
INFO - 2023-05-02 09:00:11 --> Utf8 Class Initialized
INFO - 2023-05-02 09:00:11 --> URI Class Initialized
INFO - 2023-05-02 09:00:11 --> Router Class Initialized
INFO - 2023-05-02 09:00:11 --> Output Class Initialized
INFO - 2023-05-02 09:00:11 --> Security Class Initialized
DEBUG - 2023-05-02 09:00:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-02 09:00:11 --> Input Class Initialized
INFO - 2023-05-02 09:00:11 --> Language Class Initialized
INFO - 2023-05-02 09:00:11 --> Language Class Initialized
INFO - 2023-05-02 09:00:11 --> Config Class Initialized
INFO - 2023-05-02 09:00:11 --> Loader Class Initialized
INFO - 2023-05-02 09:00:11 --> Helper loaded: url_helper
INFO - 2023-05-02 09:00:11 --> Helper loaded: file_helper
INFO - 2023-05-02 09:00:11 --> Helper loaded: form_helper
INFO - 2023-05-02 09:00:11 --> Helper loaded: my_helper
INFO - 2023-05-02 09:00:11 --> Database Driver Class Initialized
DEBUG - 2023-05-02 09:00:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-05-02 09:00:11 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-02 09:00:11 --> Controller Class Initialized
INFO - 2023-05-02 09:03:40 --> Config Class Initialized
INFO - 2023-05-02 09:03:40 --> Hooks Class Initialized
DEBUG - 2023-05-02 09:03:40 --> UTF-8 Support Enabled
INFO - 2023-05-02 09:03:40 --> Utf8 Class Initialized
INFO - 2023-05-02 09:03:40 --> URI Class Initialized
INFO - 2023-05-02 09:03:40 --> Router Class Initialized
INFO - 2023-05-02 09:03:40 --> Output Class Initialized
INFO - 2023-05-02 09:03:40 --> Security Class Initialized
DEBUG - 2023-05-02 09:03:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-02 09:03:40 --> Input Class Initialized
INFO - 2023-05-02 09:03:40 --> Language Class Initialized
INFO - 2023-05-02 09:03:40 --> Language Class Initialized
INFO - 2023-05-02 09:03:40 --> Config Class Initialized
INFO - 2023-05-02 09:03:40 --> Loader Class Initialized
INFO - 2023-05-02 09:03:40 --> Helper loaded: url_helper
INFO - 2023-05-02 09:03:40 --> Helper loaded: file_helper
INFO - 2023-05-02 09:03:40 --> Helper loaded: form_helper
INFO - 2023-05-02 09:03:40 --> Helper loaded: my_helper
INFO - 2023-05-02 09:03:40 --> Database Driver Class Initialized
DEBUG - 2023-05-02 09:03:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-05-02 09:03:40 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-02 09:03:40 --> Controller Class Initialized
DEBUG - 2023-05-02 09:03:40 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/n_catatan_nna/views/form.php
DEBUG - 2023-05-02 09:03:40 --> File loaded: C:\xampp\htdocs\myraportk13\application\views\template_utama.php
INFO - 2023-05-02 09:03:40 --> Final output sent to browser
DEBUG - 2023-05-02 09:03:40 --> Total execution time: 0.0526
INFO - 2023-05-02 09:03:40 --> Config Class Initialized
INFO - 2023-05-02 09:03:40 --> Hooks Class Initialized
DEBUG - 2023-05-02 09:03:40 --> UTF-8 Support Enabled
INFO - 2023-05-02 09:03:40 --> Utf8 Class Initialized
INFO - 2023-05-02 09:03:40 --> URI Class Initialized
INFO - 2023-05-02 09:03:40 --> Router Class Initialized
INFO - 2023-05-02 09:03:40 --> Output Class Initialized
INFO - 2023-05-02 09:03:40 --> Security Class Initialized
DEBUG - 2023-05-02 09:03:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-02 09:03:41 --> Input Class Initialized
INFO - 2023-05-02 09:03:41 --> Language Class Initialized
ERROR - 2023-05-02 09:03:41 --> 404 Page Not Found: /index
INFO - 2023-05-02 09:03:41 --> Config Class Initialized
INFO - 2023-05-02 09:03:41 --> Hooks Class Initialized
DEBUG - 2023-05-02 09:03:41 --> UTF-8 Support Enabled
INFO - 2023-05-02 09:03:41 --> Utf8 Class Initialized
INFO - 2023-05-02 09:03:41 --> URI Class Initialized
INFO - 2023-05-02 09:03:41 --> Router Class Initialized
INFO - 2023-05-02 09:03:41 --> Output Class Initialized
INFO - 2023-05-02 09:03:41 --> Security Class Initialized
DEBUG - 2023-05-02 09:03:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-02 09:03:41 --> Input Class Initialized
INFO - 2023-05-02 09:03:41 --> Language Class Initialized
INFO - 2023-05-02 09:03:41 --> Language Class Initialized
INFO - 2023-05-02 09:03:41 --> Config Class Initialized
INFO - 2023-05-02 09:03:41 --> Loader Class Initialized
INFO - 2023-05-02 09:03:41 --> Helper loaded: url_helper
INFO - 2023-05-02 09:03:41 --> Helper loaded: file_helper
INFO - 2023-05-02 09:03:41 --> Helper loaded: form_helper
INFO - 2023-05-02 09:03:41 --> Helper loaded: my_helper
INFO - 2023-05-02 09:03:41 --> Database Driver Class Initialized
DEBUG - 2023-05-02 09:03:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-05-02 09:03:41 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-02 09:03:41 --> Controller Class Initialized
DEBUG - 2023-05-02 09:03:41 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/n_catatan_nna/views/form.php
DEBUG - 2023-05-02 09:03:41 --> File loaded: C:\xampp\htdocs\myraportk13\application\views\template_utama.php
INFO - 2023-05-02 09:03:41 --> Final output sent to browser
DEBUG - 2023-05-02 09:03:41 --> Total execution time: 0.0332
INFO - 2023-05-02 09:03:41 --> Config Class Initialized
INFO - 2023-05-02 09:03:41 --> Hooks Class Initialized
DEBUG - 2023-05-02 09:03:41 --> UTF-8 Support Enabled
INFO - 2023-05-02 09:03:41 --> Utf8 Class Initialized
INFO - 2023-05-02 09:03:41 --> URI Class Initialized
INFO - 2023-05-02 09:03:41 --> Router Class Initialized
INFO - 2023-05-02 09:03:41 --> Output Class Initialized
INFO - 2023-05-02 09:03:41 --> Security Class Initialized
DEBUG - 2023-05-02 09:03:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-02 09:03:41 --> Input Class Initialized
INFO - 2023-05-02 09:03:41 --> Language Class Initialized
ERROR - 2023-05-02 09:03:41 --> 404 Page Not Found: /index
INFO - 2023-05-02 09:03:44 --> Config Class Initialized
INFO - 2023-05-02 09:03:44 --> Hooks Class Initialized
DEBUG - 2023-05-02 09:03:44 --> UTF-8 Support Enabled
INFO - 2023-05-02 09:03:44 --> Utf8 Class Initialized
INFO - 2023-05-02 09:03:44 --> URI Class Initialized
INFO - 2023-05-02 09:03:44 --> Router Class Initialized
INFO - 2023-05-02 09:03:44 --> Output Class Initialized
INFO - 2023-05-02 09:03:44 --> Database Driver Class Initialized
DEBUG - 2023-05-02 09:03:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-05-02 09:03:44 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-02 09:03:44 --> Controller Class Initialized
INFO - 2023-05-02 09:03:44 --> Config Class Initialized
INFO - 2023-05-02 09:03:44 --> Hooks Class Initialized
DEBUG - 2023-05-02 09:03:44 --> UTF-8 Support Enabled
INFO - 2023-05-02 09:03:44 --> Utf8 Class Initialized
INFO - 2023-05-02 09:03:44 --> URI Class Initialized
INFO - 2023-05-02 09:03:44 --> Router Class Initialized
INFO - 2023-05-02 09:03:44 --> Output Class Initialized
INFO - 2023-05-02 09:03:44 --> Security Class Initialized
DEBUG - 2023-05-02 09:03:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-02 09:03:44 --> Input Class Initialized
INFO - 2023-05-02 09:03:44 --> Language Class Initialized
INFO - 2023-05-02 09:03:44 --> Language Class Initialized
INFO - 2023-05-02 09:03:44 --> Config Class Initialized
INFO - 2023-05-02 09:03:44 --> Loader Class Initialized
INFO - 2023-05-02 09:03:44 --> Helper loaded: url_helper
INFO - 2023-05-02 09:03:44 --> Helper loaded: file_helper
INFO - 2023-05-02 09:03:44 --> Helper loaded: form_helper
INFO - 2023-05-02 09:03:44 --> Helper loaded: my_helper
INFO - 2023-05-02 09:03:44 --> Database Driver Class Initialized
DEBUG - 2023-05-02 09:03:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-05-02 09:03:44 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-02 09:03:44 --> Controller Class Initialized
DEBUG - 2023-05-02 09:03:44 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/n_catatan_nna/views/list.php
DEBUG - 2023-05-02 09:03:44 --> File loaded: C:\xampp\htdocs\myraportk13\application\views\template_utama.php
INFO - 2023-05-02 09:03:44 --> Final output sent to browser
DEBUG - 2023-05-02 09:03:44 --> Total execution time: 0.0272
INFO - 2023-05-02 09:03:44 --> Config Class Initialized
INFO - 2023-05-02 09:03:44 --> Hooks Class Initialized
DEBUG - 2023-05-02 09:03:44 --> UTF-8 Support Enabled
INFO - 2023-05-02 09:03:44 --> Utf8 Class Initialized
INFO - 2023-05-02 09:03:44 --> URI Class Initialized
INFO - 2023-05-02 09:03:44 --> Router Class Initialized
INFO - 2023-05-02 09:03:44 --> Output Class Initialized
INFO - 2023-05-02 09:03:44 --> Security Class Initialized
DEBUG - 2023-05-02 09:03:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-02 09:03:44 --> Input Class Initialized
INFO - 2023-05-02 09:03:44 --> Language Class Initialized
ERROR - 2023-05-02 09:03:44 --> 404 Page Not Found: /index
INFO - 2023-05-02 09:03:52 --> Config Class Initialized
INFO - 2023-05-02 09:03:52 --> Hooks Class Initialized
DEBUG - 2023-05-02 09:03:52 --> UTF-8 Support Enabled
INFO - 2023-05-02 09:03:52 --> Utf8 Class Initialized
INFO - 2023-05-02 09:03:52 --> URI Class Initialized
INFO - 2023-05-02 09:03:52 --> Router Class Initialized
INFO - 2023-05-02 09:03:52 --> Output Class Initialized
INFO - 2023-05-02 09:03:52 --> Security Class Initialized
DEBUG - 2023-05-02 09:03:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-02 09:03:52 --> Input Class Initialized
INFO - 2023-05-02 09:03:52 --> Language Class Initialized
INFO - 2023-05-02 09:03:52 --> Language Class Initialized
INFO - 2023-05-02 09:03:52 --> Config Class Initialized
INFO - 2023-05-02 09:03:52 --> Loader Class Initialized
INFO - 2023-05-02 09:03:52 --> Helper loaded: url_helper
INFO - 2023-05-02 09:03:52 --> Helper loaded: file_helper
INFO - 2023-05-02 09:03:52 --> Helper loaded: form_helper
INFO - 2023-05-02 09:03:52 --> Helper loaded: my_helper
INFO - 2023-05-02 09:03:52 --> Database Driver Class Initialized
DEBUG - 2023-05-02 09:03:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-05-02 09:03:52 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-02 09:03:52 --> Controller Class Initialized
DEBUG - 2023-05-02 09:03:52 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/n_catatan_nna/views/list.php
DEBUG - 2023-05-02 09:03:52 --> File loaded: C:\xampp\htdocs\myraportk13\application\views\template_utama.php
INFO - 2023-05-02 09:03:52 --> Final output sent to browser
DEBUG - 2023-05-02 09:03:52 --> Total execution time: 0.0428
INFO - 2023-05-02 09:04:54 --> Config Class Initialized
INFO - 2023-05-02 09:04:54 --> Hooks Class Initialized
DEBUG - 2023-05-02 09:04:54 --> UTF-8 Support Enabled
INFO - 2023-05-02 09:04:54 --> Utf8 Class Initialized
INFO - 2023-05-02 09:04:54 --> URI Class Initialized
INFO - 2023-05-02 09:04:54 --> Router Class Initialized
INFO - 2023-05-02 09:04:54 --> Output Class Initialized
INFO - 2023-05-02 09:04:54 --> Security Class Initialized
DEBUG - 2023-05-02 09:04:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-02 09:04:54 --> Input Class Initialized
INFO - 2023-05-02 09:04:54 --> Language Class Initialized
INFO - 2023-05-02 09:04:54 --> Language Class Initialized
INFO - 2023-05-02 09:04:54 --> Config Class Initialized
INFO - 2023-05-02 09:04:54 --> Loader Class Initialized
INFO - 2023-05-02 09:04:54 --> Helper loaded: url_helper
INFO - 2023-05-02 09:04:54 --> Helper loaded: file_helper
INFO - 2023-05-02 09:04:54 --> Helper loaded: form_helper
INFO - 2023-05-02 09:04:54 --> Helper loaded: my_helper
INFO - 2023-05-02 09:04:54 --> Database Driver Class Initialized
DEBUG - 2023-05-02 09:04:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-05-02 09:04:54 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-02 09:04:54 --> Controller Class Initialized
DEBUG - 2023-05-02 09:04:54 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/n_catatan_nna/views/list.php
DEBUG - 2023-05-02 09:04:54 --> File loaded: C:\xampp\htdocs\myraportk13\application\views\template_utama.php
INFO - 2023-05-02 09:04:54 --> Final output sent to browser
DEBUG - 2023-05-02 09:04:54 --> Total execution time: 0.0517
INFO - 2023-05-02 09:04:56 --> Config Class Initialized
INFO - 2023-05-02 09:04:56 --> Hooks Class Initialized
DEBUG - 2023-05-02 09:04:56 --> UTF-8 Support Enabled
INFO - 2023-05-02 09:04:56 --> Utf8 Class Initialized
INFO - 2023-05-02 09:04:56 --> URI Class Initialized
INFO - 2023-05-02 09:04:56 --> Router Class Initialized
INFO - 2023-05-02 09:04:56 --> Output Class Initialized
INFO - 2023-05-02 09:04:56 --> Security Class Initialized
DEBUG - 2023-05-02 09:04:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-02 09:04:56 --> Input Class Initialized
INFO - 2023-05-02 09:04:56 --> Language Class Initialized
INFO - 2023-05-02 09:04:56 --> Language Class Initialized
INFO - 2023-05-02 09:04:56 --> Config Class Initialized
INFO - 2023-05-02 09:04:56 --> Loader Class Initialized
INFO - 2023-05-02 09:04:56 --> Helper loaded: url_helper
INFO - 2023-05-02 09:04:56 --> Helper loaded: file_helper
INFO - 2023-05-02 09:04:56 --> Helper loaded: form_helper
INFO - 2023-05-02 09:04:56 --> Helper loaded: my_helper
INFO - 2023-05-02 09:04:56 --> Database Driver Class Initialized
DEBUG - 2023-05-02 09:04:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-05-02 09:04:56 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-02 09:04:56 --> Controller Class Initialized
INFO - 2023-05-02 09:04:57 --> Config Class Initialized
INFO - 2023-05-02 09:04:57 --> Hooks Class Initialized
DEBUG - 2023-05-02 09:04:57 --> UTF-8 Support Enabled
INFO - 2023-05-02 09:04:57 --> Utf8 Class Initialized
INFO - 2023-05-02 09:04:57 --> URI Class Initialized
INFO - 2023-05-02 09:04:57 --> Router Class Initialized
INFO - 2023-05-02 09:04:57 --> Output Class Initialized
INFO - 2023-05-02 09:04:57 --> Security Class Initialized
DEBUG - 2023-05-02 09:04:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-02 09:04:57 --> Input Class Initialized
INFO - 2023-05-02 09:04:57 --> Language Class Initialized
INFO - 2023-05-02 09:04:57 --> Language Class Initialized
INFO - 2023-05-02 09:04:57 --> Config Class Initialized
INFO - 2023-05-02 09:04:57 --> Loader Class Initialized
INFO - 2023-05-02 09:04:57 --> Helper loaded: url_helper
INFO - 2023-05-02 09:04:57 --> Helper loaded: file_helper
INFO - 2023-05-02 09:04:57 --> Helper loaded: form_helper
INFO - 2023-05-02 09:04:57 --> Helper loaded: my_helper
INFO - 2023-05-02 09:04:57 --> Database Driver Class Initialized
DEBUG - 2023-05-02 09:04:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-05-02 09:04:57 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-02 09:04:57 --> Controller Class Initialized
DEBUG - 2023-05-02 09:04:57 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/n_catatan_nna/views/list.php
DEBUG - 2023-05-02 09:04:57 --> File loaded: C:\xampp\htdocs\myraportk13\application\views\template_utama.php
INFO - 2023-05-02 09:04:57 --> Final output sent to browser
DEBUG - 2023-05-02 09:04:57 --> Total execution time: 0.0270
INFO - 2023-05-02 09:04:58 --> Config Class Initialized
INFO - 2023-05-02 09:04:58 --> Hooks Class Initialized
DEBUG - 2023-05-02 09:04:58 --> UTF-8 Support Enabled
INFO - 2023-05-02 09:04:58 --> Utf8 Class Initialized
INFO - 2023-05-02 09:04:58 --> URI Class Initialized
INFO - 2023-05-02 09:04:58 --> Router Class Initialized
INFO - 2023-05-02 09:04:58 --> Output Class Initialized
INFO - 2023-05-02 09:04:58 --> Security Class Initialized
DEBUG - 2023-05-02 09:04:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-02 09:04:58 --> Input Class Initialized
INFO - 2023-05-02 09:04:58 --> Language Class Initialized
INFO - 2023-05-02 09:04:58 --> Language Class Initialized
INFO - 2023-05-02 09:04:58 --> Config Class Initialized
INFO - 2023-05-02 09:04:58 --> Loader Class Initialized
INFO - 2023-05-02 09:04:58 --> Helper loaded: url_helper
INFO - 2023-05-02 09:04:58 --> Helper loaded: file_helper
INFO - 2023-05-02 09:04:58 --> Helper loaded: form_helper
INFO - 2023-05-02 09:04:58 --> Helper loaded: my_helper
INFO - 2023-05-02 09:04:58 --> Database Driver Class Initialized
DEBUG - 2023-05-02 09:04:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-05-02 09:04:58 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-02 09:04:58 --> Controller Class Initialized
INFO - 2023-05-02 09:04:58 --> Final output sent to browser
DEBUG - 2023-05-02 09:04:58 --> Total execution time: 0.0266
INFO - 2023-05-02 09:05:00 --> Config Class Initialized
INFO - 2023-05-02 09:05:00 --> Hooks Class Initialized
DEBUG - 2023-05-02 09:05:00 --> UTF-8 Support Enabled
INFO - 2023-05-02 09:05:00 --> Utf8 Class Initialized
INFO - 2023-05-02 09:05:00 --> URI Class Initialized
INFO - 2023-05-02 09:05:00 --> Router Class Initialized
INFO - 2023-05-02 09:05:00 --> Output Class Initialized
INFO - 2023-05-02 09:05:00 --> Security Class Initialized
DEBUG - 2023-05-02 09:05:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-02 09:05:00 --> Input Class Initialized
INFO - 2023-05-02 09:05:00 --> Language Class Initialized
INFO - 2023-05-02 09:05:00 --> Language Class Initialized
INFO - 2023-05-02 09:05:00 --> Config Class Initialized
INFO - 2023-05-02 09:05:00 --> Loader Class Initialized
INFO - 2023-05-02 09:05:00 --> Helper loaded: url_helper
INFO - 2023-05-02 09:05:00 --> Helper loaded: file_helper
INFO - 2023-05-02 09:05:00 --> Helper loaded: form_helper
INFO - 2023-05-02 09:05:00 --> Helper loaded: my_helper
INFO - 2023-05-02 09:05:00 --> Database Driver Class Initialized
DEBUG - 2023-05-02 09:05:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-05-02 09:05:00 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-02 09:05:00 --> Controller Class Initialized
INFO - 2023-05-02 09:05:01 --> Config Class Initialized
INFO - 2023-05-02 09:05:01 --> Hooks Class Initialized
DEBUG - 2023-05-02 09:05:01 --> UTF-8 Support Enabled
INFO - 2023-05-02 09:05:01 --> Utf8 Class Initialized
INFO - 2023-05-02 09:05:01 --> URI Class Initialized
INFO - 2023-05-02 09:05:01 --> Router Class Initialized
INFO - 2023-05-02 09:05:01 --> Output Class Initialized
INFO - 2023-05-02 09:05:01 --> Security Class Initialized
DEBUG - 2023-05-02 09:05:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-02 09:05:01 --> Input Class Initialized
INFO - 2023-05-02 09:05:01 --> Language Class Initialized
INFO - 2023-05-02 09:05:01 --> Language Class Initialized
INFO - 2023-05-02 09:05:01 --> Config Class Initialized
INFO - 2023-05-02 09:05:01 --> Loader Class Initialized
INFO - 2023-05-02 09:05:01 --> Helper loaded: url_helper
INFO - 2023-05-02 09:05:01 --> Helper loaded: file_helper
INFO - 2023-05-02 09:05:01 --> Helper loaded: form_helper
INFO - 2023-05-02 09:05:01 --> Helper loaded: my_helper
INFO - 2023-05-02 09:05:01 --> Database Driver Class Initialized
DEBUG - 2023-05-02 09:05:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-05-02 09:05:01 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-02 09:05:01 --> Controller Class Initialized
DEBUG - 2023-05-02 09:05:01 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/n_catatan_nna/views/form.php
DEBUG - 2023-05-02 09:05:01 --> File loaded: C:\xampp\htdocs\myraportk13\application\views\template_utama.php
INFO - 2023-05-02 09:05:01 --> Final output sent to browser
DEBUG - 2023-05-02 09:05:01 --> Total execution time: 0.0502
INFO - 2023-05-02 09:05:04 --> Config Class Initialized
INFO - 2023-05-02 09:05:04 --> Hooks Class Initialized
DEBUG - 2023-05-02 09:05:04 --> UTF-8 Support Enabled
INFO - 2023-05-02 09:05:04 --> Utf8 Class Initialized
INFO - 2023-05-02 09:05:04 --> URI Class Initialized
INFO - 2023-05-02 09:05:04 --> Router Class Initialized
INFO - 2023-05-02 09:05:04 --> Output Class Initialized
INFO - 2023-05-02 09:05:04 --> Security Class Initialized
DEBUG - 2023-05-02 09:05:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-02 09:05:04 --> Input Class Initialized
INFO - 2023-05-02 09:05:04 --> Language Class Initialized
INFO - 2023-05-02 09:05:04 --> Language Class Initialized
INFO - 2023-05-02 09:05:04 --> Config Class Initialized
INFO - 2023-05-02 09:05:04 --> Loader Class Initialized
INFO - 2023-05-02 09:05:04 --> Helper loaded: url_helper
INFO - 2023-05-02 09:05:04 --> Helper loaded: file_helper
INFO - 2023-05-02 09:05:04 --> Helper loaded: form_helper
INFO - 2023-05-02 09:05:04 --> Helper loaded: my_helper
INFO - 2023-05-02 09:05:04 --> Database Driver Class Initialized
DEBUG - 2023-05-02 09:05:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-05-02 09:05:04 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-02 09:05:04 --> Controller Class Initialized
INFO - 2023-05-02 09:05:04 --> Config Class Initialized
INFO - 2023-05-02 09:05:04 --> Hooks Class Initialized
DEBUG - 2023-05-02 09:05:04 --> UTF-8 Support Enabled
INFO - 2023-05-02 09:05:04 --> Utf8 Class Initialized
INFO - 2023-05-02 09:05:04 --> URI Class Initialized
INFO - 2023-05-02 09:05:04 --> Router Class Initialized
INFO - 2023-05-02 09:05:04 --> Output Class Initialized
INFO - 2023-05-02 09:05:04 --> Security Class Initialized
DEBUG - 2023-05-02 09:05:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-02 09:05:04 --> Input Class Initialized
INFO - 2023-05-02 09:05:04 --> Language Class Initialized
INFO - 2023-05-02 09:05:04 --> Language Class Initialized
INFO - 2023-05-02 09:05:04 --> Config Class Initialized
INFO - 2023-05-02 09:05:04 --> Loader Class Initialized
INFO - 2023-05-02 09:05:04 --> Helper loaded: url_helper
INFO - 2023-05-02 09:05:04 --> Helper loaded: file_helper
INFO - 2023-05-02 09:05:04 --> Helper loaded: form_helper
INFO - 2023-05-02 09:05:04 --> Helper loaded: my_helper
INFO - 2023-05-02 09:05:04 --> Database Driver Class Initialized
DEBUG - 2023-05-02 09:05:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-05-02 09:05:04 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-02 09:05:04 --> Controller Class Initialized
DEBUG - 2023-05-02 09:05:04 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/n_catatan_nna/views/list.php
DEBUG - 2023-05-02 09:05:04 --> File loaded: C:\xampp\htdocs\myraportk13\application\views\template_utama.php
INFO - 2023-05-02 09:05:04 --> Final output sent to browser
DEBUG - 2023-05-02 09:05:04 --> Total execution time: 0.0265
INFO - 2023-05-02 09:05:39 --> Config Class Initialized
INFO - 2023-05-02 09:05:39 --> Hooks Class Initialized
DEBUG - 2023-05-02 09:05:39 --> UTF-8 Support Enabled
INFO - 2023-05-02 09:05:39 --> Utf8 Class Initialized
INFO - 2023-05-02 09:05:39 --> URI Class Initialized
INFO - 2023-05-02 09:05:39 --> Router Class Initialized
INFO - 2023-05-02 09:05:39 --> Output Class Initialized
INFO - 2023-05-02 09:05:39 --> Security Class Initialized
DEBUG - 2023-05-02 09:05:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-02 09:05:39 --> Input Class Initialized
INFO - 2023-05-02 09:05:39 --> Language Class Initialized
INFO - 2023-05-02 09:05:39 --> Language Class Initialized
INFO - 2023-05-02 09:05:39 --> Config Class Initialized
INFO - 2023-05-02 09:05:39 --> Loader Class Initialized
INFO - 2023-05-02 09:05:39 --> Helper loaded: url_helper
INFO - 2023-05-02 09:05:39 --> Helper loaded: file_helper
INFO - 2023-05-02 09:05:39 --> Helper loaded: form_helper
INFO - 2023-05-02 09:05:39 --> Helper loaded: my_helper
INFO - 2023-05-02 09:05:39 --> Database Driver Class Initialized
DEBUG - 2023-05-02 09:05:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-05-02 09:05:39 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-02 09:05:39 --> Controller Class Initialized
DEBUG - 2023-05-02 09:05:39 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/n_catatan_nna/views/list.php
DEBUG - 2023-05-02 09:05:39 --> File loaded: C:\xampp\htdocs\myraportk13\application\views\template_utama.php
INFO - 2023-05-02 09:05:39 --> Final output sent to browser
DEBUG - 2023-05-02 09:05:39 --> Total execution time: 0.0580
INFO - 2023-05-02 09:05:40 --> Config Class Initialized
INFO - 2023-05-02 09:05:40 --> Hooks Class Initialized
DEBUG - 2023-05-02 09:05:40 --> UTF-8 Support Enabled
INFO - 2023-05-02 09:05:40 --> Utf8 Class Initialized
INFO - 2023-05-02 09:05:40 --> URI Class Initialized
INFO - 2023-05-02 09:05:40 --> Router Class Initialized
INFO - 2023-05-02 09:05:40 --> Output Class Initialized
INFO - 2023-05-02 09:05:40 --> Security Class Initialized
DEBUG - 2023-05-02 09:05:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-02 09:05:40 --> Input Class Initialized
INFO - 2023-05-02 09:05:40 --> Language Class Initialized
INFO - 2023-05-02 09:05:40 --> Language Class Initialized
INFO - 2023-05-02 09:05:40 --> Config Class Initialized
INFO - 2023-05-02 09:05:40 --> Loader Class Initialized
INFO - 2023-05-02 09:05:40 --> Helper loaded: url_helper
INFO - 2023-05-02 09:05:40 --> Helper loaded: file_helper
INFO - 2023-05-02 09:05:40 --> Helper loaded: form_helper
INFO - 2023-05-02 09:05:40 --> Helper loaded: my_helper
INFO - 2023-05-02 09:05:40 --> Database Driver Class Initialized
DEBUG - 2023-05-02 09:05:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-05-02 09:05:40 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-02 09:05:40 --> Controller Class Initialized
INFO - 2023-05-02 09:05:41 --> Config Class Initialized
INFO - 2023-05-02 09:05:41 --> Hooks Class Initialized
DEBUG - 2023-05-02 09:05:41 --> UTF-8 Support Enabled
INFO - 2023-05-02 09:05:41 --> Utf8 Class Initialized
INFO - 2023-05-02 09:05:41 --> URI Class Initialized
INFO - 2023-05-02 09:05:41 --> Router Class Initialized
INFO - 2023-05-02 09:05:41 --> Output Class Initialized
INFO - 2023-05-02 09:05:41 --> Security Class Initialized
DEBUG - 2023-05-02 09:05:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-02 09:05:41 --> Input Class Initialized
INFO - 2023-05-02 09:05:41 --> Language Class Initialized
INFO - 2023-05-02 09:05:41 --> Language Class Initialized
INFO - 2023-05-02 09:05:41 --> Config Class Initialized
INFO - 2023-05-02 09:05:41 --> Loader Class Initialized
INFO - 2023-05-02 09:05:41 --> Helper loaded: url_helper
INFO - 2023-05-02 09:05:41 --> Helper loaded: file_helper
INFO - 2023-05-02 09:05:41 --> Helper loaded: form_helper
INFO - 2023-05-02 09:05:41 --> Helper loaded: my_helper
INFO - 2023-05-02 09:05:41 --> Database Driver Class Initialized
DEBUG - 2023-05-02 09:05:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-05-02 09:05:41 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-02 09:05:41 --> Controller Class Initialized
DEBUG - 2023-05-02 09:05:41 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/n_catatan_nna/views/list.php
DEBUG - 2023-05-02 09:05:41 --> File loaded: C:\xampp\htdocs\myraportk13\application\views\template_utama.php
INFO - 2023-05-02 09:05:41 --> Final output sent to browser
DEBUG - 2023-05-02 09:05:41 --> Total execution time: 0.0418
INFO - 2023-05-02 09:05:42 --> Config Class Initialized
INFO - 2023-05-02 09:05:42 --> Hooks Class Initialized
DEBUG - 2023-05-02 09:05:42 --> UTF-8 Support Enabled
INFO - 2023-05-02 09:05:42 --> Utf8 Class Initialized
INFO - 2023-05-02 09:05:42 --> URI Class Initialized
INFO - 2023-05-02 09:05:42 --> Router Class Initialized
INFO - 2023-05-02 09:05:42 --> Output Class Initialized
INFO - 2023-05-02 09:05:42 --> Security Class Initialized
DEBUG - 2023-05-02 09:05:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-02 09:05:42 --> Input Class Initialized
INFO - 2023-05-02 09:05:42 --> Language Class Initialized
INFO - 2023-05-02 09:05:42 --> Language Class Initialized
INFO - 2023-05-02 09:05:42 --> Config Class Initialized
INFO - 2023-05-02 09:05:42 --> Loader Class Initialized
INFO - 2023-05-02 09:05:42 --> Helper loaded: url_helper
INFO - 2023-05-02 09:05:42 --> Helper loaded: file_helper
INFO - 2023-05-02 09:05:42 --> Helper loaded: form_helper
INFO - 2023-05-02 09:05:42 --> Helper loaded: my_helper
INFO - 2023-05-02 09:05:42 --> Database Driver Class Initialized
DEBUG - 2023-05-02 09:05:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-05-02 09:05:42 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-02 09:05:42 --> Controller Class Initialized
INFO - 2023-05-02 09:05:42 --> Final output sent to browser
DEBUG - 2023-05-02 09:05:42 --> Total execution time: 0.0251
INFO - 2023-05-02 09:05:43 --> Config Class Initialized
INFO - 2023-05-02 09:05:43 --> Hooks Class Initialized
DEBUG - 2023-05-02 09:05:43 --> UTF-8 Support Enabled
INFO - 2023-05-02 09:05:43 --> Utf8 Class Initialized
INFO - 2023-05-02 09:05:43 --> URI Class Initialized
INFO - 2023-05-02 09:05:43 --> Router Class Initialized
INFO - 2023-05-02 09:05:43 --> Output Class Initialized
INFO - 2023-05-02 09:05:43 --> Security Class Initialized
DEBUG - 2023-05-02 09:05:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-02 09:05:43 --> Input Class Initialized
INFO - 2023-05-02 09:05:43 --> Language Class Initialized
INFO - 2023-05-02 09:05:43 --> Language Class Initialized
INFO - 2023-05-02 09:05:43 --> Config Class Initialized
INFO - 2023-05-02 09:05:43 --> Loader Class Initialized
INFO - 2023-05-02 09:05:43 --> Helper loaded: url_helper
INFO - 2023-05-02 09:05:43 --> Helper loaded: file_helper
INFO - 2023-05-02 09:05:43 --> Helper loaded: form_helper
INFO - 2023-05-02 09:05:43 --> Helper loaded: my_helper
INFO - 2023-05-02 09:05:43 --> Database Driver Class Initialized
DEBUG - 2023-05-02 09:05:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-05-02 09:05:43 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-02 09:05:43 --> Controller Class Initialized
INFO - 2023-05-02 09:05:44 --> Config Class Initialized
INFO - 2023-05-02 09:05:44 --> Hooks Class Initialized
DEBUG - 2023-05-02 09:05:44 --> UTF-8 Support Enabled
INFO - 2023-05-02 09:05:44 --> Utf8 Class Initialized
INFO - 2023-05-02 09:05:44 --> URI Class Initialized
INFO - 2023-05-02 09:05:44 --> Router Class Initialized
INFO - 2023-05-02 09:05:44 --> Output Class Initialized
INFO - 2023-05-02 09:05:44 --> Security Class Initialized
DEBUG - 2023-05-02 09:05:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-02 09:05:44 --> Input Class Initialized
INFO - 2023-05-02 09:05:44 --> Language Class Initialized
INFO - 2023-05-02 09:05:44 --> Language Class Initialized
INFO - 2023-05-02 09:05:44 --> Config Class Initialized
INFO - 2023-05-02 09:05:44 --> Loader Class Initialized
INFO - 2023-05-02 09:05:44 --> Helper loaded: url_helper
INFO - 2023-05-02 09:05:44 --> Helper loaded: file_helper
INFO - 2023-05-02 09:05:44 --> Helper loaded: form_helper
INFO - 2023-05-02 09:05:44 --> Helper loaded: my_helper
INFO - 2023-05-02 09:05:44 --> Database Driver Class Initialized
DEBUG - 2023-05-02 09:05:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-05-02 09:05:44 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-02 09:05:44 --> Controller Class Initialized
DEBUG - 2023-05-02 09:05:44 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/n_catatan_nna/views/form.php
DEBUG - 2023-05-02 09:05:44 --> File loaded: C:\xampp\htdocs\myraportk13\application\views\template_utama.php
INFO - 2023-05-02 09:05:44 --> Final output sent to browser
DEBUG - 2023-05-02 09:05:44 --> Total execution time: 0.0320
INFO - 2023-05-02 09:05:47 --> Config Class Initialized
INFO - 2023-05-02 09:05:47 --> Hooks Class Initialized
DEBUG - 2023-05-02 09:05:47 --> UTF-8 Support Enabled
INFO - 2023-05-02 09:05:47 --> Utf8 Class Initialized
INFO - 2023-05-02 09:05:47 --> URI Class Initialized
INFO - 2023-05-02 09:05:47 --> Router Class Initialized
INFO - 2023-05-02 09:05:47 --> Output Class Initialized
INFO - 2023-05-02 09:05:47 --> Security Class Initialized
DEBUG - 2023-05-02 09:05:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-02 09:05:47 --> Input Class Initialized
INFO - 2023-05-02 09:05:47 --> Language Class Initialized
INFO - 2023-05-02 09:05:47 --> Language Class Initialized
INFO - 2023-05-02 09:05:47 --> Config Class Initialized
INFO - 2023-05-02 09:05:47 --> Loader Class Initialized
INFO - 2023-05-02 09:05:47 --> Helper loaded: url_helper
INFO - 2023-05-02 09:05:47 --> Helper loaded: file_helper
INFO - 2023-05-02 09:05:47 --> Helper loaded: form_helper
INFO - 2023-05-02 09:05:47 --> Helper loaded: my_helper
INFO - 2023-05-02 09:05:47 --> Database Driver Class Initialized
DEBUG - 2023-05-02 09:05:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-05-02 09:05:47 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-02 09:05:47 --> Controller Class Initialized
INFO - 2023-05-02 09:05:47 --> Config Class Initialized
INFO - 2023-05-02 09:05:47 --> Hooks Class Initialized
DEBUG - 2023-05-02 09:05:47 --> UTF-8 Support Enabled
INFO - 2023-05-02 09:05:47 --> Utf8 Class Initialized
INFO - 2023-05-02 09:05:47 --> URI Class Initialized
INFO - 2023-05-02 09:05:47 --> Router Class Initialized
INFO - 2023-05-02 09:05:47 --> Output Class Initialized
INFO - 2023-05-02 09:05:47 --> Security Class Initialized
DEBUG - 2023-05-02 09:05:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-02 09:05:47 --> Input Class Initialized
INFO - 2023-05-02 09:05:47 --> Language Class Initialized
INFO - 2023-05-02 09:05:47 --> Language Class Initialized
INFO - 2023-05-02 09:05:47 --> Config Class Initialized
INFO - 2023-05-02 09:05:47 --> Loader Class Initialized
INFO - 2023-05-02 09:05:47 --> Helper loaded: url_helper
INFO - 2023-05-02 09:05:47 --> Helper loaded: file_helper
INFO - 2023-05-02 09:05:47 --> Helper loaded: form_helper
INFO - 2023-05-02 09:05:47 --> Helper loaded: my_helper
INFO - 2023-05-02 09:05:47 --> Database Driver Class Initialized
DEBUG - 2023-05-02 09:05:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-05-02 09:05:47 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-02 09:05:47 --> Controller Class Initialized
DEBUG - 2023-05-02 09:05:47 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/n_catatan_nna/views/list.php
DEBUG - 2023-05-02 09:05:47 --> File loaded: C:\xampp\htdocs\myraportk13\application\views\template_utama.php
INFO - 2023-05-02 09:05:47 --> Final output sent to browser
DEBUG - 2023-05-02 09:05:47 --> Total execution time: 0.0361
INFO - 2023-05-02 09:06:05 --> Config Class Initialized
INFO - 2023-05-02 09:06:05 --> Hooks Class Initialized
DEBUG - 2023-05-02 09:06:05 --> UTF-8 Support Enabled
INFO - 2023-05-02 09:06:05 --> Utf8 Class Initialized
INFO - 2023-05-02 09:06:05 --> URI Class Initialized
INFO - 2023-05-02 09:06:05 --> Router Class Initialized
INFO - 2023-05-02 09:06:05 --> Output Class Initialized
INFO - 2023-05-02 09:06:05 --> Security Class Initialized
DEBUG - 2023-05-02 09:06:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-02 09:06:05 --> Input Class Initialized
INFO - 2023-05-02 09:06:05 --> Language Class Initialized
INFO - 2023-05-02 09:06:05 --> Language Class Initialized
INFO - 2023-05-02 09:06:05 --> Config Class Initialized
INFO - 2023-05-02 09:06:05 --> Loader Class Initialized
INFO - 2023-05-02 09:06:05 --> Helper loaded: url_helper
INFO - 2023-05-02 09:06:05 --> Helper loaded: file_helper
INFO - 2023-05-02 09:06:05 --> Helper loaded: form_helper
INFO - 2023-05-02 09:06:05 --> Helper loaded: my_helper
INFO - 2023-05-02 09:06:05 --> Database Driver Class Initialized
DEBUG - 2023-05-02 09:06:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-05-02 09:06:05 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-02 09:06:05 --> Controller Class Initialized
DEBUG - 2023-05-02 09:06:05 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/n_catatan_nna/views/form.php
DEBUG - 2023-05-02 09:06:05 --> File loaded: C:\xampp\htdocs\myraportk13\application\views\template_utama.php
INFO - 2023-05-02 09:06:05 --> Final output sent to browser
DEBUG - 2023-05-02 09:06:05 --> Total execution time: 0.0265
INFO - 2023-05-02 09:06:08 --> Config Class Initialized
INFO - 2023-05-02 09:06:08 --> Hooks Class Initialized
DEBUG - 2023-05-02 09:06:08 --> UTF-8 Support Enabled
INFO - 2023-05-02 09:06:08 --> Utf8 Class Initialized
INFO - 2023-05-02 09:06:08 --> URI Class Initialized
INFO - 2023-05-02 09:06:08 --> Router Class Initialized
INFO - 2023-05-02 09:06:08 --> Output Class Initialized
INFO - 2023-05-02 09:06:08 --> Security Class Initialized
DEBUG - 2023-05-02 09:06:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-02 09:06:08 --> Input Class Initialized
INFO - 2023-05-02 09:06:08 --> Language Class Initialized
INFO - 2023-05-02 09:06:08 --> Language Class Initialized
INFO - 2023-05-02 09:06:08 --> Config Class Initialized
INFO - 2023-05-02 09:06:08 --> Loader Class Initialized
INFO - 2023-05-02 09:06:08 --> Helper loaded: url_helper
INFO - 2023-05-02 09:06:08 --> Helper loaded: file_helper
INFO - 2023-05-02 09:06:08 --> Helper loaded: form_helper
INFO - 2023-05-02 09:06:08 --> Helper loaded: my_helper
INFO - 2023-05-02 09:06:08 --> Database Driver Class Initialized
DEBUG - 2023-05-02 09:06:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-05-02 09:06:08 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-02 09:06:08 --> Controller Class Initialized
INFO - 2023-05-02 09:06:08 --> Config Class Initialized
INFO - 2023-05-02 09:06:08 --> Hooks Class Initialized
DEBUG - 2023-05-02 09:06:08 --> UTF-8 Support Enabled
INFO - 2023-05-02 09:06:08 --> Utf8 Class Initialized
INFO - 2023-05-02 09:06:08 --> URI Class Initialized
INFO - 2023-05-02 09:06:08 --> Router Class Initialized
INFO - 2023-05-02 09:06:08 --> Output Class Initialized
INFO - 2023-05-02 09:06:08 --> Security Class Initialized
DEBUG - 2023-05-02 09:06:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-02 09:06:08 --> Input Class Initialized
INFO - 2023-05-02 09:06:08 --> Language Class Initialized
INFO - 2023-05-02 09:06:08 --> Language Class Initialized
INFO - 2023-05-02 09:06:08 --> Config Class Initialized
INFO - 2023-05-02 09:06:08 --> Loader Class Initialized
INFO - 2023-05-02 09:06:08 --> Helper loaded: url_helper
INFO - 2023-05-02 09:06:08 --> Helper loaded: file_helper
INFO - 2023-05-02 09:06:08 --> Helper loaded: form_helper
INFO - 2023-05-02 09:06:08 --> Helper loaded: my_helper
INFO - 2023-05-02 09:06:08 --> Database Driver Class Initialized
DEBUG - 2023-05-02 09:06:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-05-02 09:06:08 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-02 09:06:08 --> Controller Class Initialized
DEBUG - 2023-05-02 09:06:08 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/n_catatan_nna/views/list.php
DEBUG - 2023-05-02 09:06:08 --> File loaded: C:\xampp\htdocs\myraportk13\application\views\template_utama.php
INFO - 2023-05-02 09:06:08 --> Final output sent to browser
DEBUG - 2023-05-02 09:06:08 --> Total execution time: 0.0263
INFO - 2023-05-02 09:06:11 --> Config Class Initialized
INFO - 2023-05-02 09:06:11 --> Hooks Class Initialized
DEBUG - 2023-05-02 09:06:11 --> UTF-8 Support Enabled
INFO - 2023-05-02 09:06:11 --> Utf8 Class Initialized
INFO - 2023-05-02 09:06:11 --> URI Class Initialized
INFO - 2023-05-02 09:06:11 --> Router Class Initialized
INFO - 2023-05-02 09:06:11 --> Output Class Initialized
INFO - 2023-05-02 09:06:11 --> Security Class Initialized
DEBUG - 2023-05-02 09:06:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-02 09:06:11 --> Input Class Initialized
INFO - 2023-05-02 09:06:11 --> Language Class Initialized
INFO - 2023-05-02 09:06:11 --> Language Class Initialized
INFO - 2023-05-02 09:06:11 --> Config Class Initialized
INFO - 2023-05-02 09:06:11 --> Loader Class Initialized
INFO - 2023-05-02 09:06:11 --> Helper loaded: url_helper
INFO - 2023-05-02 09:06:11 --> Helper loaded: file_helper
INFO - 2023-05-02 09:06:11 --> Helper loaded: form_helper
INFO - 2023-05-02 09:06:11 --> Helper loaded: my_helper
INFO - 2023-05-02 09:06:11 --> Database Driver Class Initialized
DEBUG - 2023-05-02 09:06:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-05-02 09:06:11 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-02 09:06:11 --> Controller Class Initialized
DEBUG - 2023-05-02 09:06:11 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/n_catatan_nna/views/form.php
DEBUG - 2023-05-02 09:06:11 --> File loaded: C:\xampp\htdocs\myraportk13\application\views\template_utama.php
INFO - 2023-05-02 09:06:11 --> Final output sent to browser
DEBUG - 2023-05-02 09:06:11 --> Total execution time: 0.0422
INFO - 2023-05-02 09:06:14 --> Config Class Initialized
INFO - 2023-05-02 09:06:14 --> Hooks Class Initialized
DEBUG - 2023-05-02 09:06:14 --> UTF-8 Support Enabled
INFO - 2023-05-02 09:06:14 --> Utf8 Class Initialized
INFO - 2023-05-02 09:06:14 --> URI Class Initialized
INFO - 2023-05-02 09:06:14 --> Router Class Initialized
INFO - 2023-05-02 09:06:14 --> Output Class Initialized
INFO - 2023-05-02 09:06:14 --> Security Class Initialized
DEBUG - 2023-05-02 09:06:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-02 09:06:14 --> Input Class Initialized
INFO - 2023-05-02 09:06:14 --> Language Class Initialized
INFO - 2023-05-02 09:06:14 --> Language Class Initialized
INFO - 2023-05-02 09:06:14 --> Config Class Initialized
INFO - 2023-05-02 09:06:14 --> Loader Class Initialized
INFO - 2023-05-02 09:06:14 --> Helper loaded: url_helper
INFO - 2023-05-02 09:06:14 --> Helper loaded: file_helper
INFO - 2023-05-02 09:06:14 --> Helper loaded: form_helper
INFO - 2023-05-02 09:06:14 --> Helper loaded: my_helper
INFO - 2023-05-02 09:06:14 --> Database Driver Class Initialized
DEBUG - 2023-05-02 09:06:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-05-02 09:06:14 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-02 09:06:14 --> Controller Class Initialized
INFO - 2023-05-02 09:06:14 --> Config Class Initialized
INFO - 2023-05-02 09:06:14 --> Hooks Class Initialized
DEBUG - 2023-05-02 09:06:14 --> UTF-8 Support Enabled
INFO - 2023-05-02 09:06:14 --> Utf8 Class Initialized
INFO - 2023-05-02 09:06:14 --> URI Class Initialized
INFO - 2023-05-02 09:06:14 --> Router Class Initialized
INFO - 2023-05-02 09:06:14 --> Output Class Initialized
INFO - 2023-05-02 09:06:14 --> Security Class Initialized
DEBUG - 2023-05-02 09:06:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-02 09:06:14 --> Input Class Initialized
INFO - 2023-05-02 09:06:14 --> Language Class Initialized
INFO - 2023-05-02 09:06:14 --> Language Class Initialized
INFO - 2023-05-02 09:06:14 --> Config Class Initialized
INFO - 2023-05-02 09:06:14 --> Loader Class Initialized
INFO - 2023-05-02 09:06:14 --> Helper loaded: url_helper
INFO - 2023-05-02 09:06:14 --> Helper loaded: file_helper
INFO - 2023-05-02 09:06:14 --> Helper loaded: form_helper
INFO - 2023-05-02 09:06:14 --> Helper loaded: my_helper
INFO - 2023-05-02 09:06:14 --> Database Driver Class Initialized
DEBUG - 2023-05-02 09:06:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-05-02 09:06:14 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-02 09:06:14 --> Controller Class Initialized
DEBUG - 2023-05-02 09:06:14 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/n_catatan_nna/views/list.php
DEBUG - 2023-05-02 09:06:14 --> File loaded: C:\xampp\htdocs\myraportk13\application\views\template_utama.php
INFO - 2023-05-02 09:06:14 --> Final output sent to browser
DEBUG - 2023-05-02 09:06:14 --> Total execution time: 0.0458
INFO - 2023-05-02 09:13:36 --> Config Class Initialized
INFO - 2023-05-02 09:13:36 --> Hooks Class Initialized
DEBUG - 2023-05-02 09:13:36 --> UTF-8 Support Enabled
INFO - 2023-05-02 09:13:36 --> Utf8 Class Initialized
INFO - 2023-05-02 09:13:36 --> URI Class Initialized
INFO - 2023-05-02 09:13:36 --> Router Class Initialized
INFO - 2023-05-02 09:13:36 --> Output Class Initialized
INFO - 2023-05-02 09:13:36 --> Security Class Initialized
DEBUG - 2023-05-02 09:13:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-02 09:13:36 --> Input Class Initialized
INFO - 2023-05-02 09:13:36 --> Language Class Initialized
INFO - 2023-05-02 09:13:36 --> Language Class Initialized
INFO - 2023-05-02 09:13:36 --> Config Class Initialized
INFO - 2023-05-02 09:13:36 --> Loader Class Initialized
INFO - 2023-05-02 09:13:36 --> Helper loaded: url_helper
INFO - 2023-05-02 09:13:36 --> Helper loaded: file_helper
INFO - 2023-05-02 09:13:36 --> Helper loaded: form_helper
INFO - 2023-05-02 09:13:36 --> Helper loaded: my_helper
INFO - 2023-05-02 09:13:36 --> Database Driver Class Initialized
DEBUG - 2023-05-02 09:13:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-05-02 09:13:36 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-02 09:13:36 --> Controller Class Initialized
DEBUG - 2023-05-02 09:13:36 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/n_catatan_nna/views/list.php
DEBUG - 2023-05-02 09:13:36 --> File loaded: C:\xampp\htdocs\myraportk13\application\views\template_utama.php
INFO - 2023-05-02 09:13:36 --> Final output sent to browser
DEBUG - 2023-05-02 09:13:36 --> Total execution time: 0.0531
INFO - 2023-05-02 09:13:37 --> Config Class Initialized
INFO - 2023-05-02 09:13:37 --> Hooks Class Initialized
DEBUG - 2023-05-02 09:13:37 --> UTF-8 Support Enabled
INFO - 2023-05-02 09:13:37 --> Utf8 Class Initialized
INFO - 2023-05-02 09:13:37 --> URI Class Initialized
INFO - 2023-05-02 09:13:37 --> Router Class Initialized
INFO - 2023-05-02 09:13:37 --> Output Class Initialized
INFO - 2023-05-02 09:13:37 --> Security Class Initialized
DEBUG - 2023-05-02 09:13:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-02 09:13:37 --> Input Class Initialized
INFO - 2023-05-02 09:13:37 --> Language Class Initialized
INFO - 2023-05-02 09:13:37 --> Language Class Initialized
INFO - 2023-05-02 09:13:37 --> Config Class Initialized
INFO - 2023-05-02 09:13:37 --> Loader Class Initialized
INFO - 2023-05-02 09:13:37 --> Helper loaded: url_helper
INFO - 2023-05-02 09:13:37 --> Helper loaded: file_helper
INFO - 2023-05-02 09:13:37 --> Helper loaded: form_helper
INFO - 2023-05-02 09:13:37 --> Helper loaded: my_helper
INFO - 2023-05-02 09:13:37 --> Database Driver Class Initialized
DEBUG - 2023-05-02 09:13:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-05-02 09:13:37 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-02 09:13:37 --> Controller Class Initialized
INFO - 2023-05-02 09:13:37 --> Final output sent to browser
DEBUG - 2023-05-02 09:13:37 --> Total execution time: 0.0248
INFO - 2023-05-02 09:13:38 --> Config Class Initialized
INFO - 2023-05-02 09:13:38 --> Hooks Class Initialized
DEBUG - 2023-05-02 09:13:38 --> UTF-8 Support Enabled
INFO - 2023-05-02 09:13:38 --> Utf8 Class Initialized
INFO - 2023-05-02 09:13:38 --> URI Class Initialized
INFO - 2023-05-02 09:13:38 --> Router Class Initialized
INFO - 2023-05-02 09:13:38 --> Output Class Initialized
INFO - 2023-05-02 09:13:38 --> Security Class Initialized
DEBUG - 2023-05-02 09:13:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-02 09:13:38 --> Input Class Initialized
INFO - 2023-05-02 09:13:38 --> Language Class Initialized
INFO - 2023-05-02 09:13:38 --> Language Class Initialized
INFO - 2023-05-02 09:13:38 --> Config Class Initialized
INFO - 2023-05-02 09:13:38 --> Loader Class Initialized
INFO - 2023-05-02 09:13:38 --> Helper loaded: url_helper
INFO - 2023-05-02 09:13:38 --> Helper loaded: file_helper
INFO - 2023-05-02 09:13:38 --> Helper loaded: form_helper
INFO - 2023-05-02 09:13:38 --> Helper loaded: my_helper
INFO - 2023-05-02 09:13:38 --> Database Driver Class Initialized
DEBUG - 2023-05-02 09:13:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-05-02 09:13:38 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-02 09:13:38 --> Controller Class Initialized
INFO - 2023-05-02 09:13:40 --> Config Class Initialized
INFO - 2023-05-02 09:13:40 --> Hooks Class Initialized
DEBUG - 2023-05-02 09:13:40 --> UTF-8 Support Enabled
INFO - 2023-05-02 09:13:40 --> Utf8 Class Initialized
INFO - 2023-05-02 09:13:40 --> URI Class Initialized
INFO - 2023-05-02 09:13:40 --> Router Class Initialized
INFO - 2023-05-02 09:13:40 --> Output Class Initialized
INFO - 2023-05-02 09:13:40 --> Security Class Initialized
DEBUG - 2023-05-02 09:13:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-02 09:13:40 --> Input Class Initialized
INFO - 2023-05-02 09:13:40 --> Language Class Initialized
INFO - 2023-05-02 09:13:40 --> Language Class Initialized
INFO - 2023-05-02 09:13:40 --> Config Class Initialized
INFO - 2023-05-02 09:13:40 --> Loader Class Initialized
INFO - 2023-05-02 09:13:40 --> Helper loaded: url_helper
INFO - 2023-05-02 09:13:40 --> Helper loaded: file_helper
INFO - 2023-05-02 09:13:40 --> Helper loaded: form_helper
INFO - 2023-05-02 09:13:40 --> Helper loaded: my_helper
INFO - 2023-05-02 09:13:40 --> Database Driver Class Initialized
DEBUG - 2023-05-02 09:13:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-05-02 09:13:40 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-02 09:13:40 --> Controller Class Initialized
DEBUG - 2023-05-02 09:13:40 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/n_catatan_nna/views/form.php
DEBUG - 2023-05-02 09:13:40 --> File loaded: C:\xampp\htdocs\myraportk13\application\views\template_utama.php
INFO - 2023-05-02 09:13:40 --> Final output sent to browser
DEBUG - 2023-05-02 09:13:40 --> Total execution time: 0.0300
INFO - 2023-05-02 09:13:43 --> Config Class Initialized
INFO - 2023-05-02 09:13:43 --> Hooks Class Initialized
DEBUG - 2023-05-02 09:13:43 --> UTF-8 Support Enabled
INFO - 2023-05-02 09:13:43 --> Utf8 Class Initialized
INFO - 2023-05-02 09:13:43 --> URI Class Initialized
INFO - 2023-05-02 09:13:43 --> Router Class Initialized
INFO - 2023-05-02 09:13:43 --> Output Class Initialized
INFO - 2023-05-02 09:13:43 --> Security Class Initialized
DEBUG - 2023-05-02 09:13:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-02 09:13:43 --> Input Class Initialized
INFO - 2023-05-02 09:13:43 --> Language Class Initialized
INFO - 2023-05-02 09:13:43 --> Language Class Initialized
INFO - 2023-05-02 09:13:43 --> Config Class Initialized
INFO - 2023-05-02 09:13:43 --> Loader Class Initialized
INFO - 2023-05-02 09:13:43 --> Helper loaded: url_helper
INFO - 2023-05-02 09:13:43 --> Helper loaded: file_helper
INFO - 2023-05-02 09:13:43 --> Helper loaded: form_helper
INFO - 2023-05-02 09:13:43 --> Helper loaded: my_helper
INFO - 2023-05-02 09:13:43 --> Database Driver Class Initialized
DEBUG - 2023-05-02 09:13:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-05-02 09:13:43 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-02 09:13:43 --> Controller Class Initialized
INFO - 2023-05-02 09:13:43 --> Config Class Initialized
INFO - 2023-05-02 09:13:43 --> Hooks Class Initialized
DEBUG - 2023-05-02 09:13:43 --> UTF-8 Support Enabled
INFO - 2023-05-02 09:13:43 --> Utf8 Class Initialized
INFO - 2023-05-02 09:13:43 --> URI Class Initialized
INFO - 2023-05-02 09:13:43 --> Router Class Initialized
INFO - 2023-05-02 09:13:43 --> Output Class Initialized
INFO - 2023-05-02 09:13:43 --> Security Class Initialized
DEBUG - 2023-05-02 09:13:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-02 09:13:43 --> Input Class Initialized
INFO - 2023-05-02 09:13:43 --> Language Class Initialized
INFO - 2023-05-02 09:13:43 --> Language Class Initialized
INFO - 2023-05-02 09:13:43 --> Config Class Initialized
INFO - 2023-05-02 09:13:43 --> Loader Class Initialized
INFO - 2023-05-02 09:13:43 --> Helper loaded: url_helper
INFO - 2023-05-02 09:13:43 --> Helper loaded: file_helper
INFO - 2023-05-02 09:13:43 --> Helper loaded: form_helper
INFO - 2023-05-02 09:13:43 --> Helper loaded: my_helper
INFO - 2023-05-02 09:13:43 --> Database Driver Class Initialized
DEBUG - 2023-05-02 09:13:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-05-02 09:13:43 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-02 09:13:43 --> Controller Class Initialized
DEBUG - 2023-05-02 09:13:43 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/n_catatan_nna/views/list.php
DEBUG - 2023-05-02 09:13:43 --> File loaded: C:\xampp\htdocs\myraportk13\application\views\template_utama.php
INFO - 2023-05-02 09:13:43 --> Final output sent to browser
DEBUG - 2023-05-02 09:13:43 --> Total execution time: 0.0245
INFO - 2023-05-02 09:25:34 --> Config Class Initialized
INFO - 2023-05-02 09:25:34 --> Hooks Class Initialized
DEBUG - 2023-05-02 09:25:34 --> UTF-8 Support Enabled
INFO - 2023-05-02 09:25:34 --> Utf8 Class Initialized
INFO - 2023-05-02 09:25:34 --> URI Class Initialized
INFO - 2023-05-02 09:25:34 --> Router Class Initialized
INFO - 2023-05-02 09:25:34 --> Output Class Initialized
INFO - 2023-05-02 09:25:34 --> Security Class Initialized
DEBUG - 2023-05-02 09:25:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-02 09:25:34 --> Input Class Initialized
INFO - 2023-05-02 09:25:34 --> Language Class Initialized
INFO - 2023-05-02 09:25:34 --> Language Class Initialized
INFO - 2023-05-02 09:25:34 --> Config Class Initialized
INFO - 2023-05-02 09:25:34 --> Loader Class Initialized
INFO - 2023-05-02 09:25:34 --> Helper loaded: url_helper
INFO - 2023-05-02 09:25:34 --> Helper loaded: file_helper
INFO - 2023-05-02 09:25:34 --> Helper loaded: form_helper
INFO - 2023-05-02 09:25:34 --> Helper loaded: my_helper
INFO - 2023-05-02 09:25:34 --> Database Driver Class Initialized
DEBUG - 2023-05-02 09:25:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-05-02 09:25:34 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-02 09:25:34 --> Controller Class Initialized
DEBUG - 2023-05-02 09:25:34 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/n_catatan_nna/views/list.php
DEBUG - 2023-05-02 09:25:34 --> File loaded: C:\xampp\htdocs\myraportk13\application\views\template_utama.php
INFO - 2023-05-02 09:25:34 --> Final output sent to browser
DEBUG - 2023-05-02 09:25:34 --> Total execution time: 0.0538
INFO - 2023-05-02 09:25:36 --> Config Class Initialized
INFO - 2023-05-02 09:25:36 --> Hooks Class Initialized
DEBUG - 2023-05-02 09:25:36 --> UTF-8 Support Enabled
INFO - 2023-05-02 09:25:36 --> Utf8 Class Initialized
INFO - 2023-05-02 09:25:36 --> URI Class Initialized
INFO - 2023-05-02 09:25:36 --> Router Class Initialized
INFO - 2023-05-02 09:25:36 --> Output Class Initialized
INFO - 2023-05-02 09:25:36 --> Security Class Initialized
DEBUG - 2023-05-02 09:25:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-02 09:25:36 --> Input Class Initialized
INFO - 2023-05-02 09:25:36 --> Language Class Initialized
INFO - 2023-05-02 09:25:36 --> Language Class Initialized
INFO - 2023-05-02 09:25:36 --> Config Class Initialized
INFO - 2023-05-02 09:25:36 --> Loader Class Initialized
INFO - 2023-05-02 09:25:36 --> Helper loaded: url_helper
INFO - 2023-05-02 09:25:36 --> Helper loaded: file_helper
INFO - 2023-05-02 09:25:36 --> Helper loaded: form_helper
INFO - 2023-05-02 09:25:36 --> Helper loaded: my_helper
INFO - 2023-05-02 09:25:36 --> Database Driver Class Initialized
DEBUG - 2023-05-02 09:25:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-05-02 09:25:36 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-02 09:25:36 --> Controller Class Initialized
INFO - 2023-05-02 09:25:36 --> Final output sent to browser
DEBUG - 2023-05-02 09:25:36 --> Total execution time: 0.0261
INFO - 2023-05-02 09:25:37 --> Config Class Initialized
INFO - 2023-05-02 09:25:37 --> Hooks Class Initialized
DEBUG - 2023-05-02 09:25:37 --> UTF-8 Support Enabled
INFO - 2023-05-02 09:25:37 --> Utf8 Class Initialized
INFO - 2023-05-02 09:25:37 --> URI Class Initialized
INFO - 2023-05-02 09:25:37 --> Router Class Initialized
INFO - 2023-05-02 09:25:37 --> Output Class Initialized
INFO - 2023-05-02 09:25:37 --> Security Class Initialized
DEBUG - 2023-05-02 09:25:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-02 09:25:37 --> Input Class Initialized
INFO - 2023-05-02 09:25:37 --> Language Class Initialized
INFO - 2023-05-02 09:25:37 --> Language Class Initialized
INFO - 2023-05-02 09:25:37 --> Config Class Initialized
INFO - 2023-05-02 09:25:37 --> Loader Class Initialized
INFO - 2023-05-02 09:25:37 --> Helper loaded: url_helper
INFO - 2023-05-02 09:25:37 --> Helper loaded: file_helper
INFO - 2023-05-02 09:25:37 --> Helper loaded: form_helper
INFO - 2023-05-02 09:25:37 --> Helper loaded: my_helper
INFO - 2023-05-02 09:25:37 --> Database Driver Class Initialized
DEBUG - 2023-05-02 09:25:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-05-02 09:25:37 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-02 09:25:37 --> Controller Class Initialized
INFO - 2023-05-02 09:25:38 --> Config Class Initialized
INFO - 2023-05-02 09:25:38 --> Hooks Class Initialized
DEBUG - 2023-05-02 09:25:38 --> UTF-8 Support Enabled
INFO - 2023-05-02 09:25:38 --> Utf8 Class Initialized
INFO - 2023-05-02 09:25:38 --> URI Class Initialized
INFO - 2023-05-02 09:25:38 --> Router Class Initialized
INFO - 2023-05-02 09:25:38 --> Output Class Initialized
INFO - 2023-05-02 09:25:38 --> Security Class Initialized
DEBUG - 2023-05-02 09:25:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-02 09:25:38 --> Input Class Initialized
INFO - 2023-05-02 09:25:38 --> Language Class Initialized
INFO - 2023-05-02 09:25:38 --> Language Class Initialized
INFO - 2023-05-02 09:25:38 --> Config Class Initialized
INFO - 2023-05-02 09:25:38 --> Loader Class Initialized
INFO - 2023-05-02 09:25:38 --> Helper loaded: url_helper
INFO - 2023-05-02 09:25:38 --> Helper loaded: file_helper
INFO - 2023-05-02 09:25:38 --> Helper loaded: form_helper
INFO - 2023-05-02 09:25:38 --> Helper loaded: my_helper
INFO - 2023-05-02 09:25:38 --> Database Driver Class Initialized
DEBUG - 2023-05-02 09:25:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-05-02 09:25:38 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-02 09:25:38 --> Controller Class Initialized
DEBUG - 2023-05-02 09:25:38 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/n_catatan_nna/views/form.php
DEBUG - 2023-05-02 09:25:38 --> File loaded: C:\xampp\htdocs\myraportk13\application\views\template_utama.php
INFO - 2023-05-02 09:25:38 --> Final output sent to browser
DEBUG - 2023-05-02 09:25:38 --> Total execution time: 0.0429
INFO - 2023-05-02 09:25:44 --> Config Class Initialized
INFO - 2023-05-02 09:25:44 --> Hooks Class Initialized
DEBUG - 2023-05-02 09:25:44 --> UTF-8 Support Enabled
INFO - 2023-05-02 09:25:44 --> Utf8 Class Initialized
INFO - 2023-05-02 09:25:44 --> URI Class Initialized
INFO - 2023-05-02 09:25:44 --> Router Class Initialized
INFO - 2023-05-02 09:25:44 --> Output Class Initialized
INFO - 2023-05-02 09:25:44 --> Security Class Initialized
DEBUG - 2023-05-02 09:25:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-02 09:25:44 --> Input Class Initialized
INFO - 2023-05-02 09:25:44 --> Language Class Initialized
INFO - 2023-05-02 09:25:44 --> Language Class Initialized
INFO - 2023-05-02 09:25:44 --> Config Class Initialized
INFO - 2023-05-02 09:25:44 --> Loader Class Initialized
INFO - 2023-05-02 09:25:44 --> Helper loaded: url_helper
INFO - 2023-05-02 09:25:44 --> Helper loaded: file_helper
INFO - 2023-05-02 09:25:44 --> Helper loaded: form_helper
INFO - 2023-05-02 09:25:44 --> Helper loaded: my_helper
INFO - 2023-05-02 09:25:44 --> Database Driver Class Initialized
DEBUG - 2023-05-02 09:25:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-05-02 09:25:44 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-02 09:25:44 --> Controller Class Initialized
INFO - 2023-05-02 09:25:44 --> Config Class Initialized
INFO - 2023-05-02 09:25:44 --> Hooks Class Initialized
DEBUG - 2023-05-02 09:25:44 --> UTF-8 Support Enabled
INFO - 2023-05-02 09:25:44 --> Utf8 Class Initialized
INFO - 2023-05-02 09:25:44 --> URI Class Initialized
INFO - 2023-05-02 09:25:44 --> Router Class Initialized
INFO - 2023-05-02 09:25:44 --> Output Class Initialized
INFO - 2023-05-02 09:25:44 --> Security Class Initialized
DEBUG - 2023-05-02 09:25:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-02 09:25:44 --> Input Class Initialized
INFO - 2023-05-02 09:25:44 --> Language Class Initialized
INFO - 2023-05-02 09:25:44 --> Language Class Initialized
INFO - 2023-05-02 09:25:44 --> Config Class Initialized
INFO - 2023-05-02 09:25:44 --> Loader Class Initialized
INFO - 2023-05-02 09:25:44 --> Helper loaded: url_helper
INFO - 2023-05-02 09:25:44 --> Helper loaded: file_helper
INFO - 2023-05-02 09:25:44 --> Helper loaded: form_helper
INFO - 2023-05-02 09:25:44 --> Helper loaded: my_helper
INFO - 2023-05-02 09:25:44 --> Database Driver Class Initialized
DEBUG - 2023-05-02 09:25:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-05-02 09:25:44 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-02 09:25:44 --> Controller Class Initialized
DEBUG - 2023-05-02 09:25:44 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/n_catatan_nna/views/list.php
DEBUG - 2023-05-02 09:25:44 --> File loaded: C:\xampp\htdocs\myraportk13\application\views\template_utama.php
INFO - 2023-05-02 09:25:44 --> Final output sent to browser
DEBUG - 2023-05-02 09:25:44 --> Total execution time: 0.0237
INFO - 2023-05-02 09:26:56 --> Config Class Initialized
INFO - 2023-05-02 09:26:56 --> Hooks Class Initialized
DEBUG - 2023-05-02 09:26:56 --> UTF-8 Support Enabled
INFO - 2023-05-02 09:26:56 --> Utf8 Class Initialized
INFO - 2023-05-02 09:26:56 --> URI Class Initialized
INFO - 2023-05-02 09:26:56 --> Router Class Initialized
INFO - 2023-05-02 09:26:56 --> Output Class Initialized
INFO - 2023-05-02 09:26:56 --> Security Class Initialized
DEBUG - 2023-05-02 09:26:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-02 09:26:56 --> Input Class Initialized
INFO - 2023-05-02 09:26:56 --> Language Class Initialized
INFO - 2023-05-02 09:26:56 --> Language Class Initialized
INFO - 2023-05-02 09:26:56 --> Config Class Initialized
INFO - 2023-05-02 09:26:56 --> Loader Class Initialized
INFO - 2023-05-02 09:26:56 --> Helper loaded: url_helper
INFO - 2023-05-02 09:26:56 --> Helper loaded: file_helper
INFO - 2023-05-02 09:26:56 --> Helper loaded: form_helper
INFO - 2023-05-02 09:26:56 --> Helper loaded: my_helper
INFO - 2023-05-02 09:26:56 --> Database Driver Class Initialized
DEBUG - 2023-05-02 09:26:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-05-02 09:26:56 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-02 09:26:56 --> Controller Class Initialized
DEBUG - 2023-05-02 09:26:56 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/n_catatan_nna/views/form.php
DEBUG - 2023-05-02 09:26:56 --> File loaded: C:\xampp\htdocs\myraportk13\application\views\template_utama.php
INFO - 2023-05-02 09:26:56 --> Final output sent to browser
DEBUG - 2023-05-02 09:26:56 --> Total execution time: 0.0473
INFO - 2023-05-02 09:27:01 --> Config Class Initialized
INFO - 2023-05-02 09:27:01 --> Hooks Class Initialized
DEBUG - 2023-05-02 09:27:01 --> UTF-8 Support Enabled
INFO - 2023-05-02 09:27:01 --> Utf8 Class Initialized
INFO - 2023-05-02 09:27:01 --> URI Class Initialized
INFO - 2023-05-02 09:27:01 --> Router Class Initialized
INFO - 2023-05-02 09:27:01 --> Output Class Initialized
INFO - 2023-05-02 09:27:01 --> Security Class Initialized
DEBUG - 2023-05-02 09:27:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-02 09:27:01 --> Input Class Initialized
INFO - 2023-05-02 09:27:01 --> Language Class Initialized
INFO - 2023-05-02 09:27:01 --> Language Class Initialized
INFO - 2023-05-02 09:27:01 --> Config Class Initialized
INFO - 2023-05-02 09:27:01 --> Loader Class Initialized
INFO - 2023-05-02 09:27:01 --> Helper loaded: url_helper
INFO - 2023-05-02 09:27:01 --> Helper loaded: file_helper
INFO - 2023-05-02 09:27:01 --> Helper loaded: form_helper
INFO - 2023-05-02 09:27:01 --> Helper loaded: my_helper
INFO - 2023-05-02 09:27:01 --> Database Driver Class Initialized
DEBUG - 2023-05-02 09:27:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-05-02 09:27:01 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-02 09:27:01 --> Controller Class Initialized
INFO - 2023-05-02 09:27:01 --> Config Class Initialized
INFO - 2023-05-02 09:27:01 --> Hooks Class Initialized
DEBUG - 2023-05-02 09:27:01 --> UTF-8 Support Enabled
INFO - 2023-05-02 09:27:01 --> Utf8 Class Initialized
INFO - 2023-05-02 09:27:01 --> URI Class Initialized
INFO - 2023-05-02 09:27:01 --> Router Class Initialized
INFO - 2023-05-02 09:27:01 --> Output Class Initialized
INFO - 2023-05-02 09:27:01 --> Security Class Initialized
DEBUG - 2023-05-02 09:27:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-02 09:27:01 --> Input Class Initialized
INFO - 2023-05-02 09:27:01 --> Language Class Initialized
INFO - 2023-05-02 09:27:01 --> Language Class Initialized
INFO - 2023-05-02 09:27:01 --> Config Class Initialized
INFO - 2023-05-02 09:27:01 --> Loader Class Initialized
INFO - 2023-05-02 09:27:01 --> Helper loaded: url_helper
INFO - 2023-05-02 09:27:01 --> Helper loaded: file_helper
INFO - 2023-05-02 09:27:01 --> Helper loaded: form_helper
INFO - 2023-05-02 09:27:01 --> Helper loaded: my_helper
INFO - 2023-05-02 09:27:01 --> Database Driver Class Initialized
DEBUG - 2023-05-02 09:27:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-05-02 09:27:01 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-02 09:27:01 --> Controller Class Initialized
DEBUG - 2023-05-02 09:27:01 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/n_catatan_nna/views/list.php
DEBUG - 2023-05-02 09:27:01 --> File loaded: C:\xampp\htdocs\myraportk13\application\views\template_utama.php
INFO - 2023-05-02 09:27:01 --> Final output sent to browser
DEBUG - 2023-05-02 09:27:01 --> Total execution time: 0.0256
INFO - 2023-05-02 09:27:03 --> Config Class Initialized
INFO - 2023-05-02 09:27:03 --> Hooks Class Initialized
DEBUG - 2023-05-02 09:27:03 --> UTF-8 Support Enabled
INFO - 2023-05-02 09:27:03 --> Utf8 Class Initialized
INFO - 2023-05-02 09:27:03 --> URI Class Initialized
INFO - 2023-05-02 09:27:03 --> Router Class Initialized
INFO - 2023-05-02 09:27:03 --> Output Class Initialized
INFO - 2023-05-02 09:27:03 --> Security Class Initialized
DEBUG - 2023-05-02 09:27:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-02 09:27:03 --> Input Class Initialized
INFO - 2023-05-02 09:27:03 --> Language Class Initialized
INFO - 2023-05-02 09:27:03 --> Language Class Initialized
INFO - 2023-05-02 09:27:03 --> Config Class Initialized
INFO - 2023-05-02 09:27:03 --> Loader Class Initialized
INFO - 2023-05-02 09:27:03 --> Helper loaded: url_helper
INFO - 2023-05-02 09:27:03 --> Helper loaded: file_helper
INFO - 2023-05-02 09:27:03 --> Helper loaded: form_helper
INFO - 2023-05-02 09:27:03 --> Helper loaded: my_helper
INFO - 2023-05-02 09:27:03 --> Database Driver Class Initialized
DEBUG - 2023-05-02 09:27:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-05-02 09:27:03 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-02 09:27:03 --> Controller Class Initialized
DEBUG - 2023-05-02 09:27:03 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/n_catatan_nna/views/list.php
DEBUG - 2023-05-02 09:27:03 --> File loaded: C:\xampp\htdocs\myraportk13\application\views\template_utama.php
INFO - 2023-05-02 09:27:03 --> Final output sent to browser
DEBUG - 2023-05-02 09:27:03 --> Total execution time: 0.0284
INFO - 2023-05-02 09:27:04 --> Config Class Initialized
INFO - 2023-05-02 09:27:04 --> Hooks Class Initialized
DEBUG - 2023-05-02 09:27:04 --> UTF-8 Support Enabled
INFO - 2023-05-02 09:27:04 --> Utf8 Class Initialized
INFO - 2023-05-02 09:27:04 --> URI Class Initialized
INFO - 2023-05-02 09:27:04 --> Router Class Initialized
INFO - 2023-05-02 09:27:04 --> Output Class Initialized
INFO - 2023-05-02 09:27:04 --> Security Class Initialized
DEBUG - 2023-05-02 09:27:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-02 09:27:04 --> Input Class Initialized
INFO - 2023-05-02 09:27:04 --> Language Class Initialized
INFO - 2023-05-02 09:27:04 --> Language Class Initialized
INFO - 2023-05-02 09:27:04 --> Config Class Initialized
INFO - 2023-05-02 09:27:04 --> Loader Class Initialized
INFO - 2023-05-02 09:27:04 --> Helper loaded: url_helper
INFO - 2023-05-02 09:27:04 --> Helper loaded: file_helper
INFO - 2023-05-02 09:27:04 --> Helper loaded: form_helper
INFO - 2023-05-02 09:27:04 --> Helper loaded: my_helper
INFO - 2023-05-02 09:27:04 --> Database Driver Class Initialized
DEBUG - 2023-05-02 09:27:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-05-02 09:27:04 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-02 09:27:04 --> Controller Class Initialized
DEBUG - 2023-05-02 09:27:04 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/n_catatan_nna/views/list.php
DEBUG - 2023-05-02 09:27:04 --> File loaded: C:\xampp\htdocs\myraportk13\application\views\template_utama.php
INFO - 2023-05-02 09:27:04 --> Final output sent to browser
DEBUG - 2023-05-02 09:27:04 --> Total execution time: 0.0274
INFO - 2023-05-02 09:27:04 --> Config Class Initialized
INFO - 2023-05-02 09:27:04 --> Hooks Class Initialized
DEBUG - 2023-05-02 09:27:04 --> UTF-8 Support Enabled
INFO - 2023-05-02 09:27:04 --> Utf8 Class Initialized
INFO - 2023-05-02 09:27:04 --> URI Class Initialized
INFO - 2023-05-02 09:27:04 --> Router Class Initialized
INFO - 2023-05-02 09:27:04 --> Output Class Initialized
INFO - 2023-05-02 09:27:04 --> Security Class Initialized
DEBUG - 2023-05-02 09:27:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-02 09:27:04 --> Input Class Initialized
INFO - 2023-05-02 09:27:04 --> Language Class Initialized
INFO - 2023-05-02 09:27:04 --> Language Class Initialized
INFO - 2023-05-02 09:27:04 --> Config Class Initialized
INFO - 2023-05-02 09:27:04 --> Loader Class Initialized
INFO - 2023-05-02 09:27:04 --> Helper loaded: url_helper
INFO - 2023-05-02 09:27:04 --> Helper loaded: file_helper
INFO - 2023-05-02 09:27:04 --> Helper loaded: form_helper
INFO - 2023-05-02 09:27:04 --> Helper loaded: my_helper
INFO - 2023-05-02 09:27:04 --> Database Driver Class Initialized
DEBUG - 2023-05-02 09:27:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-05-02 09:27:04 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-02 09:27:04 --> Controller Class Initialized
DEBUG - 2023-05-02 09:27:04 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/n_catatan_nna/views/list.php
DEBUG - 2023-05-02 09:27:04 --> File loaded: C:\xampp\htdocs\myraportk13\application\views\template_utama.php
INFO - 2023-05-02 09:27:04 --> Final output sent to browser
DEBUG - 2023-05-02 09:27:04 --> Total execution time: 0.0274
INFO - 2023-05-02 09:27:05 --> Config Class Initialized
INFO - 2023-05-02 09:27:05 --> Hooks Class Initialized
DEBUG - 2023-05-02 09:27:05 --> UTF-8 Support Enabled
INFO - 2023-05-02 09:27:05 --> Utf8 Class Initialized
INFO - 2023-05-02 09:27:05 --> URI Class Initialized
INFO - 2023-05-02 09:27:05 --> Router Class Initialized
INFO - 2023-05-02 09:27:05 --> Output Class Initialized
INFO - 2023-05-02 09:27:05 --> Security Class Initialized
DEBUG - 2023-05-02 09:27:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-02 09:27:05 --> Input Class Initialized
INFO - 2023-05-02 09:27:05 --> Language Class Initialized
INFO - 2023-05-02 09:27:05 --> Language Class Initialized
INFO - 2023-05-02 09:27:05 --> Config Class Initialized
INFO - 2023-05-02 09:27:05 --> Loader Class Initialized
INFO - 2023-05-02 09:27:05 --> Helper loaded: url_helper
INFO - 2023-05-02 09:27:05 --> Helper loaded: file_helper
INFO - 2023-05-02 09:27:05 --> Helper loaded: form_helper
INFO - 2023-05-02 09:27:05 --> Helper loaded: my_helper
INFO - 2023-05-02 09:27:05 --> Database Driver Class Initialized
DEBUG - 2023-05-02 09:27:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-05-02 09:27:05 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-02 09:27:05 --> Controller Class Initialized
DEBUG - 2023-05-02 09:27:05 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/n_catatan_nna/views/list.php
DEBUG - 2023-05-02 09:27:05 --> File loaded: C:\xampp\htdocs\myraportk13\application\views\template_utama.php
INFO - 2023-05-02 09:27:05 --> Final output sent to browser
DEBUG - 2023-05-02 09:27:05 --> Total execution time: 0.0283
INFO - 2023-05-02 09:27:05 --> Config Class Initialized
INFO - 2023-05-02 09:27:05 --> Hooks Class Initialized
DEBUG - 2023-05-02 09:27:05 --> UTF-8 Support Enabled
INFO - 2023-05-02 09:27:05 --> Utf8 Class Initialized
INFO - 2023-05-02 09:27:05 --> URI Class Initialized
INFO - 2023-05-02 09:27:05 --> Router Class Initialized
INFO - 2023-05-02 09:27:05 --> Output Class Initialized
INFO - 2023-05-02 09:27:05 --> Security Class Initialized
DEBUG - 2023-05-02 09:27:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-02 09:27:05 --> Input Class Initialized
INFO - 2023-05-02 09:27:05 --> Language Class Initialized
INFO - 2023-05-02 09:27:05 --> Language Class Initialized
INFO - 2023-05-02 09:27:05 --> Config Class Initialized
INFO - 2023-05-02 09:27:05 --> Loader Class Initialized
INFO - 2023-05-02 09:27:05 --> Helper loaded: url_helper
INFO - 2023-05-02 09:27:05 --> Helper loaded: file_helper
INFO - 2023-05-02 09:27:05 --> Helper loaded: form_helper
INFO - 2023-05-02 09:27:05 --> Helper loaded: my_helper
INFO - 2023-05-02 09:27:05 --> Database Driver Class Initialized
DEBUG - 2023-05-02 09:27:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-05-02 09:27:05 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-02 09:27:05 --> Controller Class Initialized
DEBUG - 2023-05-02 09:27:05 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/n_catatan_nna/views/list.php
DEBUG - 2023-05-02 09:27:05 --> File loaded: C:\xampp\htdocs\myraportk13\application\views\template_utama.php
INFO - 2023-05-02 09:27:05 --> Final output sent to browser
DEBUG - 2023-05-02 09:27:05 --> Total execution time: 0.0257
INFO - 2023-05-02 09:27:05 --> Config Class Initialized
INFO - 2023-05-02 09:27:05 --> Hooks Class Initialized
DEBUG - 2023-05-02 09:27:05 --> UTF-8 Support Enabled
INFO - 2023-05-02 09:27:05 --> Utf8 Class Initialized
INFO - 2023-05-02 09:27:05 --> URI Class Initialized
INFO - 2023-05-02 09:27:05 --> Router Class Initialized
INFO - 2023-05-02 09:27:05 --> Output Class Initialized
INFO - 2023-05-02 09:27:05 --> Security Class Initialized
DEBUG - 2023-05-02 09:27:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-02 09:27:05 --> Input Class Initialized
INFO - 2023-05-02 09:27:05 --> Language Class Initialized
INFO - 2023-05-02 09:27:05 --> Language Class Initialized
INFO - 2023-05-02 09:27:05 --> Config Class Initialized
INFO - 2023-05-02 09:27:05 --> Loader Class Initialized
INFO - 2023-05-02 09:27:05 --> Helper loaded: url_helper
INFO - 2023-05-02 09:27:05 --> Helper loaded: file_helper
INFO - 2023-05-02 09:27:05 --> Helper loaded: form_helper
INFO - 2023-05-02 09:27:05 --> Helper loaded: my_helper
INFO - 2023-05-02 09:27:05 --> Database Driver Class Initialized
DEBUG - 2023-05-02 09:27:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-05-02 09:27:05 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-02 09:27:05 --> Controller Class Initialized
DEBUG - 2023-05-02 09:27:05 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/n_catatan_nna/views/list.php
DEBUG - 2023-05-02 09:27:05 --> File loaded: C:\xampp\htdocs\myraportk13\application\views\template_utama.php
INFO - 2023-05-02 09:27:05 --> Final output sent to browser
DEBUG - 2023-05-02 09:27:05 --> Total execution time: 0.0387
INFO - 2023-05-02 09:27:06 --> Config Class Initialized
INFO - 2023-05-02 09:27:06 --> Hooks Class Initialized
DEBUG - 2023-05-02 09:27:06 --> UTF-8 Support Enabled
INFO - 2023-05-02 09:27:06 --> Utf8 Class Initialized
INFO - 2023-05-02 09:27:06 --> URI Class Initialized
INFO - 2023-05-02 09:27:06 --> Router Class Initialized
INFO - 2023-05-02 09:27:06 --> Output Class Initialized
INFO - 2023-05-02 09:27:06 --> Security Class Initialized
DEBUG - 2023-05-02 09:27:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-02 09:27:06 --> Input Class Initialized
INFO - 2023-05-02 09:27:06 --> Language Class Initialized
INFO - 2023-05-02 09:27:06 --> Language Class Initialized
INFO - 2023-05-02 09:27:06 --> Config Class Initialized
INFO - 2023-05-02 09:27:06 --> Loader Class Initialized
INFO - 2023-05-02 09:27:06 --> Helper loaded: url_helper
INFO - 2023-05-02 09:27:06 --> Helper loaded: file_helper
INFO - 2023-05-02 09:27:06 --> Helper loaded: form_helper
INFO - 2023-05-02 09:27:06 --> Helper loaded: my_helper
INFO - 2023-05-02 09:27:06 --> Database Driver Class Initialized
DEBUG - 2023-05-02 09:27:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-05-02 09:27:06 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-02 09:27:06 --> Controller Class Initialized
DEBUG - 2023-05-02 09:27:06 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/n_catatan_nna/views/list.php
DEBUG - 2023-05-02 09:27:06 --> File loaded: C:\xampp\htdocs\myraportk13\application\views\template_utama.php
INFO - 2023-05-02 09:27:06 --> Final output sent to browser
DEBUG - 2023-05-02 09:27:06 --> Total execution time: 0.0479
INFO - 2023-05-02 09:27:06 --> Config Class Initialized
INFO - 2023-05-02 09:27:06 --> Hooks Class Initialized
DEBUG - 2023-05-02 09:27:06 --> UTF-8 Support Enabled
INFO - 2023-05-02 09:27:06 --> Utf8 Class Initialized
INFO - 2023-05-02 09:27:06 --> URI Class Initialized
INFO - 2023-05-02 09:27:06 --> Router Class Initialized
INFO - 2023-05-02 09:27:06 --> Output Class Initialized
INFO - 2023-05-02 09:27:06 --> Security Class Initialized
DEBUG - 2023-05-02 09:27:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-02 09:27:06 --> Input Class Initialized
INFO - 2023-05-02 09:27:06 --> Language Class Initialized
INFO - 2023-05-02 09:27:06 --> Language Class Initialized
INFO - 2023-05-02 09:27:06 --> Config Class Initialized
INFO - 2023-05-02 09:27:06 --> Loader Class Initialized
INFO - 2023-05-02 09:27:06 --> Helper loaded: url_helper
INFO - 2023-05-02 09:27:06 --> Helper loaded: file_helper
INFO - 2023-05-02 09:27:06 --> Helper loaded: form_helper
INFO - 2023-05-02 09:27:06 --> Helper loaded: my_helper
INFO - 2023-05-02 09:27:06 --> Database Driver Class Initialized
DEBUG - 2023-05-02 09:27:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-05-02 09:27:06 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-02 09:27:06 --> Controller Class Initialized
DEBUG - 2023-05-02 09:27:06 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/n_catatan_nna/views/list.php
DEBUG - 2023-05-02 09:27:06 --> File loaded: C:\xampp\htdocs\myraportk13\application\views\template_utama.php
INFO - 2023-05-02 09:27:06 --> Final output sent to browser
DEBUG - 2023-05-02 09:27:06 --> Total execution time: 0.0276
INFO - 2023-05-02 09:27:07 --> Config Class Initialized
INFO - 2023-05-02 09:27:07 --> Hooks Class Initialized
DEBUG - 2023-05-02 09:27:07 --> UTF-8 Support Enabled
INFO - 2023-05-02 09:27:07 --> Utf8 Class Initialized
INFO - 2023-05-02 09:27:07 --> URI Class Initialized
INFO - 2023-05-02 09:27:07 --> Router Class Initialized
INFO - 2023-05-02 09:27:07 --> Output Class Initialized
INFO - 2023-05-02 09:27:07 --> Security Class Initialized
DEBUG - 2023-05-02 09:27:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-02 09:27:07 --> Input Class Initialized
INFO - 2023-05-02 09:27:07 --> Language Class Initialized
INFO - 2023-05-02 09:27:07 --> Language Class Initialized
INFO - 2023-05-02 09:27:07 --> Config Class Initialized
INFO - 2023-05-02 09:27:07 --> Loader Class Initialized
INFO - 2023-05-02 09:27:07 --> Helper loaded: url_helper
INFO - 2023-05-02 09:27:07 --> Helper loaded: file_helper
INFO - 2023-05-02 09:27:07 --> Helper loaded: form_helper
INFO - 2023-05-02 09:27:07 --> Helper loaded: my_helper
INFO - 2023-05-02 09:27:07 --> Database Driver Class Initialized
DEBUG - 2023-05-02 09:27:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-05-02 09:27:07 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-02 09:27:07 --> Controller Class Initialized
DEBUG - 2023-05-02 09:27:07 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/n_catatan_nna/views/list.php
DEBUG - 2023-05-02 09:27:07 --> File loaded: C:\xampp\htdocs\myraportk13\application\views\template_utama.php
INFO - 2023-05-02 09:27:07 --> Final output sent to browser
DEBUG - 2023-05-02 09:27:07 --> Total execution time: 0.0542
INFO - 2023-05-02 09:27:07 --> Config Class Initialized
INFO - 2023-05-02 09:27:07 --> Hooks Class Initialized
DEBUG - 2023-05-02 09:27:07 --> UTF-8 Support Enabled
INFO - 2023-05-02 09:27:07 --> Utf8 Class Initialized
INFO - 2023-05-02 09:27:07 --> URI Class Initialized
INFO - 2023-05-02 09:27:07 --> Router Class Initialized
INFO - 2023-05-02 09:27:07 --> Output Class Initialized
INFO - 2023-05-02 09:27:07 --> Security Class Initialized
DEBUG - 2023-05-02 09:27:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-02 09:27:07 --> Input Class Initialized
INFO - 2023-05-02 09:27:07 --> Language Class Initialized
INFO - 2023-05-02 09:27:07 --> Language Class Initialized
INFO - 2023-05-02 09:27:07 --> Config Class Initialized
INFO - 2023-05-02 09:27:07 --> Loader Class Initialized
INFO - 2023-05-02 09:27:07 --> Helper loaded: url_helper
INFO - 2023-05-02 09:27:07 --> Helper loaded: file_helper
INFO - 2023-05-02 09:27:07 --> Helper loaded: form_helper
INFO - 2023-05-02 09:27:07 --> Helper loaded: my_helper
INFO - 2023-05-02 09:27:07 --> Database Driver Class Initialized
DEBUG - 2023-05-02 09:27:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-05-02 09:27:07 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-02 09:27:07 --> Controller Class Initialized
DEBUG - 2023-05-02 09:27:07 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/n_catatan_nna/views/list.php
DEBUG - 2023-05-02 09:27:07 --> File loaded: C:\xampp\htdocs\myraportk13\application\views\template_utama.php
INFO - 2023-05-02 09:27:07 --> Final output sent to browser
DEBUG - 2023-05-02 09:27:07 --> Total execution time: 0.0272
INFO - 2023-05-02 09:27:08 --> Config Class Initialized
INFO - 2023-05-02 09:27:08 --> Hooks Class Initialized
DEBUG - 2023-05-02 09:27:08 --> UTF-8 Support Enabled
INFO - 2023-05-02 09:27:08 --> Utf8 Class Initialized
INFO - 2023-05-02 09:27:08 --> URI Class Initialized
INFO - 2023-05-02 09:27:08 --> Router Class Initialized
INFO - 2023-05-02 09:27:08 --> Output Class Initialized
INFO - 2023-05-02 09:27:08 --> Security Class Initialized
DEBUG - 2023-05-02 09:27:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-02 09:27:08 --> Input Class Initialized
INFO - 2023-05-02 09:27:08 --> Language Class Initialized
INFO - 2023-05-02 09:27:08 --> Language Class Initialized
INFO - 2023-05-02 09:27:08 --> Config Class Initialized
INFO - 2023-05-02 09:27:08 --> Loader Class Initialized
INFO - 2023-05-02 09:27:08 --> Helper loaded: url_helper
INFO - 2023-05-02 09:27:08 --> Helper loaded: file_helper
INFO - 2023-05-02 09:27:08 --> Helper loaded: form_helper
INFO - 2023-05-02 09:27:08 --> Helper loaded: my_helper
INFO - 2023-05-02 09:27:08 --> Database Driver Class Initialized
DEBUG - 2023-05-02 09:27:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-05-02 09:27:08 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-02 09:27:08 --> Controller Class Initialized
DEBUG - 2023-05-02 09:27:08 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/n_catatan_nna/views/list.php
DEBUG - 2023-05-02 09:27:08 --> File loaded: C:\xampp\htdocs\myraportk13\application\views\template_utama.php
INFO - 2023-05-02 09:27:08 --> Final output sent to browser
DEBUG - 2023-05-02 09:27:08 --> Total execution time: 0.0280
INFO - 2023-05-02 09:27:08 --> Config Class Initialized
INFO - 2023-05-02 09:27:08 --> Hooks Class Initialized
DEBUG - 2023-05-02 09:27:08 --> UTF-8 Support Enabled
INFO - 2023-05-02 09:27:08 --> Utf8 Class Initialized
INFO - 2023-05-02 09:27:08 --> URI Class Initialized
INFO - 2023-05-02 09:27:08 --> Router Class Initialized
INFO - 2023-05-02 09:27:08 --> Output Class Initialized
INFO - 2023-05-02 09:27:08 --> Security Class Initialized
DEBUG - 2023-05-02 09:27:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-02 09:27:08 --> Input Class Initialized
INFO - 2023-05-02 09:27:08 --> Language Class Initialized
INFO - 2023-05-02 09:27:08 --> Language Class Initialized
INFO - 2023-05-02 09:27:08 --> Config Class Initialized
INFO - 2023-05-02 09:27:08 --> Loader Class Initialized
INFO - 2023-05-02 09:27:08 --> Helper loaded: url_helper
INFO - 2023-05-02 09:27:08 --> Helper loaded: file_helper
INFO - 2023-05-02 09:27:08 --> Helper loaded: form_helper
INFO - 2023-05-02 09:27:08 --> Helper loaded: my_helper
INFO - 2023-05-02 09:27:08 --> Database Driver Class Initialized
DEBUG - 2023-05-02 09:27:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-05-02 09:27:08 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-02 09:27:08 --> Controller Class Initialized
DEBUG - 2023-05-02 09:27:08 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/n_catatan_nna/views/list.php
DEBUG - 2023-05-02 09:27:08 --> File loaded: C:\xampp\htdocs\myraportk13\application\views\template_utama.php
INFO - 2023-05-02 09:27:08 --> Final output sent to browser
DEBUG - 2023-05-02 09:27:08 --> Total execution time: 0.0270
INFO - 2023-05-02 09:27:08 --> Config Class Initialized
INFO - 2023-05-02 09:27:08 --> Hooks Class Initialized
DEBUG - 2023-05-02 09:27:08 --> UTF-8 Support Enabled
INFO - 2023-05-02 09:27:08 --> Utf8 Class Initialized
INFO - 2023-05-02 09:27:08 --> URI Class Initialized
INFO - 2023-05-02 09:27:08 --> Router Class Initialized
INFO - 2023-05-02 09:27:08 --> Output Class Initialized
INFO - 2023-05-02 09:27:08 --> Security Class Initialized
DEBUG - 2023-05-02 09:27:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-02 09:27:08 --> Input Class Initialized
INFO - 2023-05-02 09:27:08 --> Language Class Initialized
INFO - 2023-05-02 09:27:08 --> Language Class Initialized
INFO - 2023-05-02 09:27:08 --> Config Class Initialized
INFO - 2023-05-02 09:27:08 --> Loader Class Initialized
INFO - 2023-05-02 09:27:08 --> Helper loaded: url_helper
INFO - 2023-05-02 09:27:08 --> Helper loaded: file_helper
INFO - 2023-05-02 09:27:08 --> Helper loaded: form_helper
INFO - 2023-05-02 09:27:08 --> Helper loaded: my_helper
INFO - 2023-05-02 09:27:08 --> Database Driver Class Initialized
DEBUG - 2023-05-02 09:27:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-05-02 09:27:08 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-02 09:27:08 --> Controller Class Initialized
DEBUG - 2023-05-02 09:27:08 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/n_catatan_nna/views/list.php
DEBUG - 2023-05-02 09:27:08 --> File loaded: C:\xampp\htdocs\myraportk13\application\views\template_utama.php
INFO - 2023-05-02 09:27:08 --> Final output sent to browser
DEBUG - 2023-05-02 09:27:08 --> Total execution time: 0.0401
INFO - 2023-05-02 09:27:09 --> Config Class Initialized
INFO - 2023-05-02 09:27:09 --> Hooks Class Initialized
DEBUG - 2023-05-02 09:27:09 --> UTF-8 Support Enabled
INFO - 2023-05-02 09:27:09 --> Utf8 Class Initialized
INFO - 2023-05-02 09:27:09 --> URI Class Initialized
INFO - 2023-05-02 09:27:09 --> Router Class Initialized
INFO - 2023-05-02 09:27:09 --> Output Class Initialized
INFO - 2023-05-02 09:27:09 --> Security Class Initialized
DEBUG - 2023-05-02 09:27:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-02 09:27:09 --> Input Class Initialized
INFO - 2023-05-02 09:27:09 --> Language Class Initialized
INFO - 2023-05-02 09:27:09 --> Language Class Initialized
INFO - 2023-05-02 09:27:09 --> Config Class Initialized
INFO - 2023-05-02 09:27:09 --> Loader Class Initialized
INFO - 2023-05-02 09:27:09 --> Helper loaded: url_helper
INFO - 2023-05-02 09:27:09 --> Helper loaded: file_helper
INFO - 2023-05-02 09:27:09 --> Helper loaded: form_helper
INFO - 2023-05-02 09:27:09 --> Helper loaded: my_helper
INFO - 2023-05-02 09:27:09 --> Database Driver Class Initialized
DEBUG - 2023-05-02 09:27:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-05-02 09:27:09 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-02 09:27:09 --> Controller Class Initialized
DEBUG - 2023-05-02 09:27:09 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/n_catatan_nna/views/list.php
DEBUG - 2023-05-02 09:27:09 --> File loaded: C:\xampp\htdocs\myraportk13\application\views\template_utama.php
INFO - 2023-05-02 09:27:09 --> Final output sent to browser
DEBUG - 2023-05-02 09:27:09 --> Total execution time: 0.0271
INFO - 2023-05-02 09:27:48 --> Config Class Initialized
INFO - 2023-05-02 09:27:48 --> Hooks Class Initialized
DEBUG - 2023-05-02 09:27:48 --> UTF-8 Support Enabled
INFO - 2023-05-02 09:27:48 --> Utf8 Class Initialized
INFO - 2023-05-02 09:27:48 --> URI Class Initialized
INFO - 2023-05-02 09:27:48 --> Router Class Initialized
INFO - 2023-05-02 09:27:48 --> Output Class Initialized
INFO - 2023-05-02 09:27:48 --> Security Class Initialized
DEBUG - 2023-05-02 09:27:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-02 09:27:48 --> Input Class Initialized
INFO - 2023-05-02 09:27:48 --> Language Class Initialized
INFO - 2023-05-02 09:27:48 --> Language Class Initialized
INFO - 2023-05-02 09:27:48 --> Config Class Initialized
INFO - 2023-05-02 09:27:48 --> Loader Class Initialized
INFO - 2023-05-02 09:27:48 --> Helper loaded: url_helper
INFO - 2023-05-02 09:27:48 --> Helper loaded: file_helper
INFO - 2023-05-02 09:27:48 --> Helper loaded: form_helper
INFO - 2023-05-02 09:27:48 --> Helper loaded: my_helper
INFO - 2023-05-02 09:27:48 --> Database Driver Class Initialized
DEBUG - 2023-05-02 09:27:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-05-02 09:27:48 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-02 09:27:48 --> Controller Class Initialized
DEBUG - 2023-05-02 09:27:48 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/n_catatan_nna/views/form.php
DEBUG - 2023-05-02 09:27:48 --> File loaded: C:\xampp\htdocs\myraportk13\application\views\template_utama.php
INFO - 2023-05-02 09:27:48 --> Final output sent to browser
DEBUG - 2023-05-02 09:27:48 --> Total execution time: 0.0468
INFO - 2023-05-02 09:27:50 --> Config Class Initialized
INFO - 2023-05-02 09:27:50 --> Hooks Class Initialized
DEBUG - 2023-05-02 09:27:50 --> UTF-8 Support Enabled
INFO - 2023-05-02 09:27:50 --> Utf8 Class Initialized
INFO - 2023-05-02 09:27:50 --> URI Class Initialized
INFO - 2023-05-02 09:27:50 --> Router Class Initialized
INFO - 2023-05-02 09:27:50 --> Output Class Initialized
INFO - 2023-05-02 09:27:50 --> Security Class Initialized
DEBUG - 2023-05-02 09:27:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-02 09:27:50 --> Input Class Initialized
INFO - 2023-05-02 09:27:50 --> Language Class Initialized
INFO - 2023-05-02 09:27:50 --> Language Class Initialized
INFO - 2023-05-02 09:27:50 --> Config Class Initialized
INFO - 2023-05-02 09:27:50 --> Loader Class Initialized
INFO - 2023-05-02 09:27:50 --> Helper loaded: url_helper
INFO - 2023-05-02 09:27:50 --> Helper loaded: file_helper
INFO - 2023-05-02 09:27:50 --> Helper loaded: form_helper
INFO - 2023-05-02 09:27:50 --> Helper loaded: my_helper
INFO - 2023-05-02 09:27:50 --> Database Driver Class Initialized
DEBUG - 2023-05-02 09:27:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-05-02 09:27:50 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-02 09:27:50 --> Controller Class Initialized
INFO - 2023-05-02 09:27:50 --> Config Class Initialized
INFO - 2023-05-02 09:27:50 --> Hooks Class Initialized
DEBUG - 2023-05-02 09:27:50 --> UTF-8 Support Enabled
INFO - 2023-05-02 09:27:50 --> Utf8 Class Initialized
INFO - 2023-05-02 09:27:50 --> URI Class Initialized
INFO - 2023-05-02 09:27:50 --> Router Class Initialized
INFO - 2023-05-02 09:27:50 --> Output Class Initialized
INFO - 2023-05-02 09:27:50 --> Security Class Initialized
DEBUG - 2023-05-02 09:27:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-02 09:27:50 --> Input Class Initialized
INFO - 2023-05-02 09:27:50 --> Language Class Initialized
INFO - 2023-05-02 09:27:50 --> Language Class Initialized
INFO - 2023-05-02 09:27:50 --> Config Class Initialized
INFO - 2023-05-02 09:27:50 --> Loader Class Initialized
INFO - 2023-05-02 09:27:50 --> Helper loaded: url_helper
INFO - 2023-05-02 09:27:50 --> Helper loaded: file_helper
INFO - 2023-05-02 09:27:50 --> Helper loaded: form_helper
INFO - 2023-05-02 09:27:50 --> Helper loaded: my_helper
INFO - 2023-05-02 09:27:50 --> Database Driver Class Initialized
DEBUG - 2023-05-02 09:27:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-05-02 09:27:50 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-02 09:27:50 --> Controller Class Initialized
DEBUG - 2023-05-02 09:27:50 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/n_catatan_nna/views/list.php
DEBUG - 2023-05-02 09:27:50 --> File loaded: C:\xampp\htdocs\myraportk13\application\views\template_utama.php
INFO - 2023-05-02 09:27:50 --> Final output sent to browser
DEBUG - 2023-05-02 09:27:50 --> Total execution time: 0.0245
INFO - 2023-05-02 09:27:52 --> Config Class Initialized
INFO - 2023-05-02 09:27:52 --> Hooks Class Initialized
DEBUG - 2023-05-02 09:27:52 --> UTF-8 Support Enabled
INFO - 2023-05-02 09:27:52 --> Utf8 Class Initialized
INFO - 2023-05-02 09:27:52 --> URI Class Initialized
INFO - 2023-05-02 09:27:52 --> Router Class Initialized
INFO - 2023-05-02 09:27:52 --> Output Class Initialized
INFO - 2023-05-02 09:27:52 --> Security Class Initialized
DEBUG - 2023-05-02 09:27:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-02 09:27:52 --> Input Class Initialized
INFO - 2023-05-02 09:27:52 --> Language Class Initialized
INFO - 2023-05-02 09:27:52 --> Language Class Initialized
INFO - 2023-05-02 09:27:52 --> Config Class Initialized
INFO - 2023-05-02 09:27:52 --> Loader Class Initialized
INFO - 2023-05-02 09:27:52 --> Helper loaded: url_helper
INFO - 2023-05-02 09:27:52 --> Helper loaded: file_helper
INFO - 2023-05-02 09:27:52 --> Helper loaded: form_helper
INFO - 2023-05-02 09:27:52 --> Helper loaded: my_helper
INFO - 2023-05-02 09:27:52 --> Database Driver Class Initialized
DEBUG - 2023-05-02 09:27:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-05-02 09:27:52 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-02 09:27:52 --> Controller Class Initialized
DEBUG - 2023-05-02 09:27:52 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/n_catatan_nna/views/list.php
DEBUG - 2023-05-02 09:27:52 --> File loaded: C:\xampp\htdocs\myraportk13\application\views\template_utama.php
INFO - 2023-05-02 09:27:52 --> Final output sent to browser
DEBUG - 2023-05-02 09:27:52 --> Total execution time: 0.0519
INFO - 2023-05-02 09:28:41 --> Config Class Initialized
INFO - 2023-05-02 09:28:41 --> Hooks Class Initialized
DEBUG - 2023-05-02 09:28:41 --> UTF-8 Support Enabled
INFO - 2023-05-02 09:28:41 --> Utf8 Class Initialized
INFO - 2023-05-02 09:28:41 --> URI Class Initialized
INFO - 2023-05-02 09:28:41 --> Router Class Initialized
INFO - 2023-05-02 09:28:41 --> Output Class Initialized
INFO - 2023-05-02 09:28:41 --> Security Class Initialized
DEBUG - 2023-05-02 09:28:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-02 09:28:41 --> Input Class Initialized
INFO - 2023-05-02 09:28:41 --> Language Class Initialized
INFO - 2023-05-02 09:28:41 --> Language Class Initialized
INFO - 2023-05-02 09:28:41 --> Config Class Initialized
INFO - 2023-05-02 09:28:41 --> Loader Class Initialized
INFO - 2023-05-02 09:28:41 --> Helper loaded: url_helper
INFO - 2023-05-02 09:28:41 --> Helper loaded: file_helper
INFO - 2023-05-02 09:28:41 --> Helper loaded: form_helper
INFO - 2023-05-02 09:28:41 --> Helper loaded: my_helper
INFO - 2023-05-02 09:28:41 --> Database Driver Class Initialized
DEBUG - 2023-05-02 09:28:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-05-02 09:28:41 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-02 09:28:41 --> Controller Class Initialized
DEBUG - 2023-05-02 09:28:41 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/n_catatan_nna/views/list.php
DEBUG - 2023-05-02 09:28:41 --> File loaded: C:\xampp\htdocs\myraportk13\application\views\template_utama.php
INFO - 2023-05-02 09:28:41 --> Final output sent to browser
DEBUG - 2023-05-02 09:28:41 --> Total execution time: 0.0288
INFO - 2023-05-02 09:28:53 --> Config Class Initialized
INFO - 2023-05-02 09:28:53 --> Hooks Class Initialized
DEBUG - 2023-05-02 09:28:53 --> UTF-8 Support Enabled
INFO - 2023-05-02 09:28:53 --> Utf8 Class Initialized
INFO - 2023-05-02 09:28:53 --> URI Class Initialized
INFO - 2023-05-02 09:28:53 --> Router Class Initialized
INFO - 2023-05-02 09:28:53 --> Output Class Initialized
INFO - 2023-05-02 09:28:53 --> Security Class Initialized
DEBUG - 2023-05-02 09:28:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-02 09:28:53 --> Input Class Initialized
INFO - 2023-05-02 09:28:53 --> Language Class Initialized
INFO - 2023-05-02 09:28:53 --> Language Class Initialized
INFO - 2023-05-02 09:28:53 --> Config Class Initialized
INFO - 2023-05-02 09:28:53 --> Loader Class Initialized
INFO - 2023-05-02 09:28:53 --> Helper loaded: url_helper
INFO - 2023-05-02 09:28:53 --> Helper loaded: file_helper
INFO - 2023-05-02 09:28:53 --> Helper loaded: form_helper
INFO - 2023-05-02 09:28:53 --> Helper loaded: my_helper
INFO - 2023-05-02 09:28:53 --> Database Driver Class Initialized
DEBUG - 2023-05-02 09:28:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-05-02 09:28:53 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-02 09:28:53 --> Controller Class Initialized
INFO - 2023-05-02 09:28:53 --> Final output sent to browser
DEBUG - 2023-05-02 09:28:53 --> Total execution time: 0.0258
INFO - 2023-05-02 09:28:55 --> Config Class Initialized
INFO - 2023-05-02 09:28:55 --> Hooks Class Initialized
DEBUG - 2023-05-02 09:28:55 --> UTF-8 Support Enabled
INFO - 2023-05-02 09:28:55 --> Utf8 Class Initialized
INFO - 2023-05-02 09:28:55 --> URI Class Initialized
INFO - 2023-05-02 09:28:55 --> Router Class Initialized
INFO - 2023-05-02 09:28:55 --> Output Class Initialized
INFO - 2023-05-02 09:28:55 --> Security Class Initialized
DEBUG - 2023-05-02 09:28:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-02 09:28:55 --> Input Class Initialized
INFO - 2023-05-02 09:28:55 --> Language Class Initialized
INFO - 2023-05-02 09:28:55 --> Language Class Initialized
INFO - 2023-05-02 09:28:55 --> Config Class Initialized
INFO - 2023-05-02 09:28:55 --> Loader Class Initialized
INFO - 2023-05-02 09:28:55 --> Helper loaded: url_helper
INFO - 2023-05-02 09:28:55 --> Helper loaded: file_helper
INFO - 2023-05-02 09:28:55 --> Helper loaded: form_helper
INFO - 2023-05-02 09:28:55 --> Helper loaded: my_helper
INFO - 2023-05-02 09:28:55 --> Database Driver Class Initialized
DEBUG - 2023-05-02 09:28:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-05-02 09:28:55 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-02 09:28:55 --> Controller Class Initialized
INFO - 2023-05-02 09:30:43 --> Config Class Initialized
INFO - 2023-05-02 09:30:43 --> Hooks Class Initialized
DEBUG - 2023-05-02 09:30:43 --> UTF-8 Support Enabled
INFO - 2023-05-02 09:30:43 --> Utf8 Class Initialized
INFO - 2023-05-02 09:30:43 --> URI Class Initialized
INFO - 2023-05-02 09:30:43 --> Router Class Initialized
INFO - 2023-05-02 09:30:43 --> Output Class Initialized
INFO - 2023-05-02 09:30:43 --> Security Class Initialized
DEBUG - 2023-05-02 09:30:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-02 09:30:43 --> Input Class Initialized
INFO - 2023-05-02 09:30:43 --> Language Class Initialized
INFO - 2023-05-02 09:30:43 --> Language Class Initialized
INFO - 2023-05-02 09:30:43 --> Config Class Initialized
INFO - 2023-05-02 09:30:43 --> Loader Class Initialized
INFO - 2023-05-02 09:30:44 --> Helper loaded: url_helper
INFO - 2023-05-02 09:30:44 --> Helper loaded: file_helper
INFO - 2023-05-02 09:30:44 --> Helper loaded: form_helper
INFO - 2023-05-02 09:30:44 --> Helper loaded: my_helper
INFO - 2023-05-02 09:30:44 --> Database Driver Class Initialized
DEBUG - 2023-05-02 09:30:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-05-02 09:30:44 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-02 09:30:44 --> Controller Class Initialized
INFO - 2023-05-02 09:31:04 --> Config Class Initialized
INFO - 2023-05-02 09:31:04 --> Hooks Class Initialized
DEBUG - 2023-05-02 09:31:04 --> UTF-8 Support Enabled
INFO - 2023-05-02 09:31:04 --> Utf8 Class Initialized
INFO - 2023-05-02 09:31:04 --> URI Class Initialized
INFO - 2023-05-02 09:31:04 --> Router Class Initialized
INFO - 2023-05-02 09:31:04 --> Output Class Initialized
INFO - 2023-05-02 09:31:04 --> Security Class Initialized
DEBUG - 2023-05-02 09:31:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-02 09:31:04 --> Input Class Initialized
INFO - 2023-05-02 09:31:04 --> Language Class Initialized
INFO - 2023-05-02 09:31:04 --> Language Class Initialized
INFO - 2023-05-02 09:31:04 --> Config Class Initialized
INFO - 2023-05-02 09:31:04 --> Loader Class Initialized
INFO - 2023-05-02 09:31:04 --> Helper loaded: url_helper
INFO - 2023-05-02 09:31:04 --> Helper loaded: file_helper
INFO - 2023-05-02 09:31:04 --> Helper loaded: form_helper
INFO - 2023-05-02 09:31:04 --> Helper loaded: my_helper
INFO - 2023-05-02 09:31:04 --> Database Driver Class Initialized
DEBUG - 2023-05-02 09:31:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-05-02 09:31:04 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-02 09:31:04 --> Controller Class Initialized
DEBUG - 2023-05-02 09:31:04 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/n_catatan_nna/views/list.php
DEBUG - 2023-05-02 09:31:04 --> File loaded: C:\xampp\htdocs\myraportk13\application\views\template_utama.php
INFO - 2023-05-02 09:31:04 --> Final output sent to browser
DEBUG - 2023-05-02 09:31:04 --> Total execution time: 0.0440
INFO - 2023-05-02 09:31:05 --> Config Class Initialized
INFO - 2023-05-02 09:31:05 --> Hooks Class Initialized
DEBUG - 2023-05-02 09:31:05 --> UTF-8 Support Enabled
INFO - 2023-05-02 09:31:05 --> Utf8 Class Initialized
INFO - 2023-05-02 09:31:05 --> URI Class Initialized
INFO - 2023-05-02 09:31:05 --> Router Class Initialized
INFO - 2023-05-02 09:31:05 --> Output Class Initialized
INFO - 2023-05-02 09:31:05 --> Security Class Initialized
DEBUG - 2023-05-02 09:31:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-02 09:31:05 --> Input Class Initialized
INFO - 2023-05-02 09:31:05 --> Language Class Initialized
INFO - 2023-05-02 09:31:05 --> Language Class Initialized
INFO - 2023-05-02 09:31:05 --> Config Class Initialized
INFO - 2023-05-02 09:31:05 --> Loader Class Initialized
INFO - 2023-05-02 09:31:05 --> Helper loaded: url_helper
INFO - 2023-05-02 09:31:05 --> Helper loaded: file_helper
INFO - 2023-05-02 09:31:05 --> Helper loaded: form_helper
INFO - 2023-05-02 09:31:05 --> Helper loaded: my_helper
INFO - 2023-05-02 09:31:05 --> Database Driver Class Initialized
DEBUG - 2023-05-02 09:31:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-05-02 09:31:05 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-02 09:31:05 --> Controller Class Initialized
INFO - 2023-05-02 09:31:39 --> Config Class Initialized
INFO - 2023-05-02 09:31:39 --> Hooks Class Initialized
DEBUG - 2023-05-02 09:31:39 --> UTF-8 Support Enabled
INFO - 2023-05-02 09:31:39 --> Utf8 Class Initialized
INFO - 2023-05-02 09:31:39 --> URI Class Initialized
INFO - 2023-05-02 09:31:39 --> Router Class Initialized
INFO - 2023-05-02 09:31:39 --> Output Class Initialized
INFO - 2023-05-02 09:31:39 --> Security Class Initialized
DEBUG - 2023-05-02 09:31:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-02 09:31:39 --> Input Class Initialized
INFO - 2023-05-02 09:31:39 --> Language Class Initialized
INFO - 2023-05-02 09:31:39 --> Language Class Initialized
INFO - 2023-05-02 09:31:39 --> Config Class Initialized
INFO - 2023-05-02 09:31:39 --> Loader Class Initialized
INFO - 2023-05-02 09:31:39 --> Helper loaded: url_helper
INFO - 2023-05-02 09:31:39 --> Helper loaded: file_helper
INFO - 2023-05-02 09:31:39 --> Helper loaded: form_helper
INFO - 2023-05-02 09:31:39 --> Helper loaded: my_helper
INFO - 2023-05-02 09:31:39 --> Database Driver Class Initialized
DEBUG - 2023-05-02 09:31:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-05-02 09:31:39 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-02 09:31:39 --> Controller Class Initialized
INFO - 2023-05-02 09:51:16 --> Config Class Initialized
INFO - 2023-05-02 09:51:16 --> Hooks Class Initialized
DEBUG - 2023-05-02 09:51:16 --> UTF-8 Support Enabled
INFO - 2023-05-02 09:51:16 --> Utf8 Class Initialized
INFO - 2023-05-02 09:51:16 --> URI Class Initialized
INFO - 2023-05-02 09:51:16 --> Router Class Initialized
INFO - 2023-05-02 09:51:16 --> Output Class Initialized
INFO - 2023-05-02 09:51:16 --> Security Class Initialized
DEBUG - 2023-05-02 09:51:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-02 09:51:16 --> Input Class Initialized
INFO - 2023-05-02 09:51:16 --> Language Class Initialized
INFO - 2023-05-02 09:51:16 --> Language Class Initialized
INFO - 2023-05-02 09:51:16 --> Config Class Initialized
INFO - 2023-05-02 09:51:16 --> Loader Class Initialized
INFO - 2023-05-02 09:51:16 --> Helper loaded: url_helper
INFO - 2023-05-02 09:51:16 --> Helper loaded: file_helper
INFO - 2023-05-02 09:51:16 --> Helper loaded: form_helper
INFO - 2023-05-02 09:51:16 --> Helper loaded: my_helper
INFO - 2023-05-02 09:51:16 --> Database Driver Class Initialized
DEBUG - 2023-05-02 09:51:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-05-02 09:51:16 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-02 09:51:16 --> Controller Class Initialized
DEBUG - 2023-05-02 09:51:16 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/n_catatan_kl2/views/list.php
DEBUG - 2023-05-02 09:51:16 --> File loaded: C:\xampp\htdocs\myraportk13\application\views\template_utama.php
INFO - 2023-05-02 09:51:16 --> Final output sent to browser
DEBUG - 2023-05-02 09:51:16 --> Total execution time: 0.7010
INFO - 2023-05-02 09:51:18 --> Config Class Initialized
INFO - 2023-05-02 09:51:18 --> Hooks Class Initialized
DEBUG - 2023-05-02 09:51:18 --> UTF-8 Support Enabled
INFO - 2023-05-02 09:51:18 --> Utf8 Class Initialized
INFO - 2023-05-02 09:51:18 --> URI Class Initialized
INFO - 2023-05-02 09:51:18 --> Router Class Initialized
INFO - 2023-05-02 09:51:18 --> Output Class Initialized
INFO - 2023-05-02 09:51:18 --> Security Class Initialized
DEBUG - 2023-05-02 09:51:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-02 09:51:18 --> Input Class Initialized
INFO - 2023-05-02 09:51:18 --> Language Class Initialized
INFO - 2023-05-02 09:51:18 --> Language Class Initialized
INFO - 2023-05-02 09:51:18 --> Config Class Initialized
INFO - 2023-05-02 09:51:18 --> Loader Class Initialized
INFO - 2023-05-02 09:51:18 --> Helper loaded: url_helper
INFO - 2023-05-02 09:51:18 --> Helper loaded: file_helper
INFO - 2023-05-02 09:51:18 --> Helper loaded: form_helper
INFO - 2023-05-02 09:51:18 --> Helper loaded: my_helper
INFO - 2023-05-02 09:51:18 --> Database Driver Class Initialized
DEBUG - 2023-05-02 09:51:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-05-02 09:51:18 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-02 09:51:18 --> Controller Class Initialized
DEBUG - 2023-05-02 09:51:18 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/n_catatan_nna/views/list.php
DEBUG - 2023-05-02 09:51:18 --> File loaded: C:\xampp\htdocs\myraportk13\application\views\template_utama.php
INFO - 2023-05-02 09:51:18 --> Final output sent to browser
DEBUG - 2023-05-02 09:51:18 --> Total execution time: 0.0900
INFO - 2023-05-02 10:59:29 --> Config Class Initialized
INFO - 2023-05-02 10:59:29 --> Hooks Class Initialized
DEBUG - 2023-05-02 10:59:29 --> UTF-8 Support Enabled
INFO - 2023-05-02 10:59:29 --> Utf8 Class Initialized
INFO - 2023-05-02 10:59:29 --> URI Class Initialized
INFO - 2023-05-02 10:59:29 --> Router Class Initialized
INFO - 2023-05-02 10:59:29 --> Output Class Initialized
INFO - 2023-05-02 10:59:29 --> Security Class Initialized
DEBUG - 2023-05-02 10:59:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-02 10:59:29 --> Input Class Initialized
INFO - 2023-05-02 10:59:30 --> Language Class Initialized
INFO - 2023-05-02 10:59:30 --> Language Class Initialized
INFO - 2023-05-02 10:59:30 --> Config Class Initialized
INFO - 2023-05-02 10:59:30 --> Loader Class Initialized
INFO - 2023-05-02 10:59:30 --> Helper loaded: url_helper
INFO - 2023-05-02 10:59:30 --> Helper loaded: file_helper
INFO - 2023-05-02 10:59:30 --> Helper loaded: form_helper
INFO - 2023-05-02 10:59:30 --> Helper loaded: my_helper
INFO - 2023-05-02 10:59:30 --> Database Driver Class Initialized
DEBUG - 2023-05-02 10:59:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-05-02 10:59:30 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-02 10:59:30 --> Controller Class Initialized
DEBUG - 2023-05-02 10:59:30 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/n_catatan_nna/views/list.php
DEBUG - 2023-05-02 10:59:30 --> File loaded: C:\xampp\htdocs\myraportk13\application\views\template_utama.php
INFO - 2023-05-02 10:59:30 --> Final output sent to browser
DEBUG - 2023-05-02 10:59:30 --> Total execution time: 0.7284
INFO - 2023-05-02 11:31:21 --> Config Class Initialized
INFO - 2023-05-02 11:31:21 --> Hooks Class Initialized
DEBUG - 2023-05-02 11:31:21 --> UTF-8 Support Enabled
INFO - 2023-05-02 11:31:21 --> Utf8 Class Initialized
INFO - 2023-05-02 11:31:21 --> URI Class Initialized
INFO - 2023-05-02 11:31:21 --> Router Class Initialized
INFO - 2023-05-02 11:31:21 --> Output Class Initialized
INFO - 2023-05-02 11:31:21 --> Security Class Initialized
DEBUG - 2023-05-02 11:31:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-02 11:31:21 --> Input Class Initialized
INFO - 2023-05-02 11:31:21 --> Language Class Initialized
INFO - 2023-05-02 11:31:21 --> Language Class Initialized
INFO - 2023-05-02 11:31:21 --> Config Class Initialized
INFO - 2023-05-02 11:31:21 --> Loader Class Initialized
INFO - 2023-05-02 11:31:21 --> Helper loaded: url_helper
INFO - 2023-05-02 11:31:21 --> Helper loaded: file_helper
INFO - 2023-05-02 11:31:21 --> Helper loaded: form_helper
INFO - 2023-05-02 11:31:21 --> Helper loaded: my_helper
INFO - 2023-05-02 11:31:21 --> Database Driver Class Initialized
DEBUG - 2023-05-02 11:31:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-05-02 11:31:21 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-02 11:31:21 --> Controller Class Initialized
DEBUG - 2023-05-02 11:31:21 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/n_catatan_nna/views/list.php
DEBUG - 2023-05-02 11:31:21 --> File loaded: C:\xampp\htdocs\myraportk13\application\views\template_utama.php
INFO - 2023-05-02 11:31:21 --> Final output sent to browser
DEBUG - 2023-05-02 11:31:21 --> Total execution time: 0.4426
INFO - 2023-05-02 12:17:39 --> Config Class Initialized
INFO - 2023-05-02 12:17:39 --> Hooks Class Initialized
DEBUG - 2023-05-02 12:17:39 --> UTF-8 Support Enabled
INFO - 2023-05-02 12:17:39 --> Utf8 Class Initialized
INFO - 2023-05-02 12:17:39 --> URI Class Initialized
INFO - 2023-05-02 12:17:39 --> Router Class Initialized
INFO - 2023-05-02 12:17:39 --> Output Class Initialized
INFO - 2023-05-02 12:17:39 --> Security Class Initialized
DEBUG - 2023-05-02 12:17:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-05-02 12:17:39 --> Input Class Initialized
INFO - 2023-05-02 12:17:39 --> Language Class Initialized
INFO - 2023-05-02 12:17:39 --> Language Class Initialized
INFO - 2023-05-02 12:17:39 --> Config Class Initialized
INFO - 2023-05-02 12:17:39 --> Loader Class Initialized
INFO - 2023-05-02 12:17:39 --> Helper loaded: url_helper
INFO - 2023-05-02 12:17:39 --> Helper loaded: file_helper
INFO - 2023-05-02 12:17:39 --> Helper loaded: form_helper
INFO - 2023-05-02 12:17:40 --> Helper loaded: my_helper
INFO - 2023-05-02 12:17:40 --> Database Driver Class Initialized
DEBUG - 2023-05-02 12:17:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-05-02 12:17:40 --> Session: Class initialized using 'files' driver.
INFO - 2023-05-02 12:17:40 --> Controller Class Initialized
DEBUG - 2023-05-02 12:17:40 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/n_catatan_nna/views/list.php
DEBUG - 2023-05-02 12:17:40 --> File loaded: C:\xampp\htdocs\myraportk13\application\views\template_utama.php
INFO - 2023-05-02 12:17:40 --> Final output sent to browser
DEBUG - 2023-05-02 12:17:40 --> Total execution time: 0.9393
