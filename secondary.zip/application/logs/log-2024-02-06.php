<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2024-02-06 08:47:08 --> Config Class Initialized
INFO - 2024-02-06 08:47:08 --> Hooks Class Initialized
DEBUG - 2024-02-06 08:47:08 --> UTF-8 Support Enabled
INFO - 2024-02-06 08:47:08 --> Utf8 Class Initialized
INFO - 2024-02-06 08:47:09 --> URI Class Initialized
INFO - 2024-02-06 08:47:09 --> Router Class Initialized
INFO - 2024-02-06 08:47:09 --> Output Class Initialized
INFO - 2024-02-06 08:47:09 --> Security Class Initialized
DEBUG - 2024-02-06 08:47:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-06 08:47:09 --> Input Class Initialized
INFO - 2024-02-06 08:47:09 --> Language Class Initialized
INFO - 2024-02-06 08:47:10 --> Language Class Initialized
INFO - 2024-02-06 08:47:10 --> Config Class Initialized
INFO - 2024-02-06 08:47:10 --> Loader Class Initialized
INFO - 2024-02-06 08:47:10 --> Helper loaded: url_helper
INFO - 2024-02-06 08:47:10 --> Helper loaded: file_helper
INFO - 2024-02-06 08:47:10 --> Helper loaded: form_helper
INFO - 2024-02-06 08:47:10 --> Helper loaded: my_helper
INFO - 2024-02-06 08:47:10 --> Database Driver Class Initialized
INFO - 2024-02-06 08:47:10 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-06 08:47:10 --> Controller Class Initialized
DEBUG - 2024-02-06 08:47:10 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/login/views/login.php
DEBUG - 2024-02-06 08:47:10 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-02-06 08:47:10 --> Final output sent to browser
DEBUG - 2024-02-06 08:47:10 --> Total execution time: 2.4094
INFO - 2024-02-06 08:47:20 --> Config Class Initialized
INFO - 2024-02-06 08:47:20 --> Hooks Class Initialized
DEBUG - 2024-02-06 08:47:20 --> UTF-8 Support Enabled
INFO - 2024-02-06 08:47:20 --> Utf8 Class Initialized
INFO - 2024-02-06 08:47:20 --> URI Class Initialized
INFO - 2024-02-06 08:47:20 --> Router Class Initialized
INFO - 2024-02-06 08:47:20 --> Output Class Initialized
INFO - 2024-02-06 08:47:20 --> Security Class Initialized
DEBUG - 2024-02-06 08:47:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-06 08:47:20 --> Input Class Initialized
INFO - 2024-02-06 08:47:20 --> Language Class Initialized
INFO - 2024-02-06 08:47:20 --> Language Class Initialized
INFO - 2024-02-06 08:47:20 --> Config Class Initialized
INFO - 2024-02-06 08:47:20 --> Loader Class Initialized
INFO - 2024-02-06 08:47:20 --> Helper loaded: url_helper
INFO - 2024-02-06 08:47:20 --> Helper loaded: file_helper
INFO - 2024-02-06 08:47:20 --> Helper loaded: form_helper
INFO - 2024-02-06 08:47:20 --> Helper loaded: my_helper
INFO - 2024-02-06 08:47:20 --> Database Driver Class Initialized
INFO - 2024-02-06 08:47:20 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-06 08:47:20 --> Controller Class Initialized
INFO - 2024-02-06 08:47:20 --> Helper loaded: cookie_helper
INFO - 2024-02-06 08:47:20 --> Final output sent to browser
DEBUG - 2024-02-06 08:47:20 --> Total execution time: 0.1910
INFO - 2024-02-06 08:47:20 --> Config Class Initialized
INFO - 2024-02-06 08:47:20 --> Hooks Class Initialized
DEBUG - 2024-02-06 08:47:20 --> UTF-8 Support Enabled
INFO - 2024-02-06 08:47:20 --> Utf8 Class Initialized
INFO - 2024-02-06 08:47:20 --> URI Class Initialized
INFO - 2024-02-06 08:47:20 --> Router Class Initialized
INFO - 2024-02-06 08:47:20 --> Output Class Initialized
INFO - 2024-02-06 08:47:20 --> Security Class Initialized
DEBUG - 2024-02-06 08:47:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-06 08:47:20 --> Input Class Initialized
INFO - 2024-02-06 08:47:20 --> Language Class Initialized
INFO - 2024-02-06 08:47:20 --> Language Class Initialized
INFO - 2024-02-06 08:47:20 --> Config Class Initialized
INFO - 2024-02-06 08:47:20 --> Loader Class Initialized
INFO - 2024-02-06 08:47:20 --> Helper loaded: url_helper
INFO - 2024-02-06 08:47:20 --> Helper loaded: file_helper
INFO - 2024-02-06 08:47:20 --> Helper loaded: form_helper
INFO - 2024-02-06 08:47:20 --> Helper loaded: my_helper
INFO - 2024-02-06 08:47:20 --> Database Driver Class Initialized
INFO - 2024-02-06 08:47:20 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-06 08:47:20 --> Controller Class Initialized
DEBUG - 2024-02-06 08:47:20 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/home/views/v_home_guru.php
DEBUG - 2024-02-06 08:47:20 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-02-06 08:47:20 --> Final output sent to browser
DEBUG - 2024-02-06 08:47:20 --> Total execution time: 0.1314
INFO - 2024-02-06 08:47:24 --> Config Class Initialized
INFO - 2024-02-06 08:47:24 --> Hooks Class Initialized
DEBUG - 2024-02-06 08:47:24 --> UTF-8 Support Enabled
INFO - 2024-02-06 08:47:24 --> Utf8 Class Initialized
INFO - 2024-02-06 08:47:24 --> URI Class Initialized
INFO - 2024-02-06 08:47:24 --> Router Class Initialized
INFO - 2024-02-06 08:47:24 --> Output Class Initialized
INFO - 2024-02-06 08:47:24 --> Security Class Initialized
DEBUG - 2024-02-06 08:47:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-06 08:47:24 --> Input Class Initialized
INFO - 2024-02-06 08:47:24 --> Language Class Initialized
INFO - 2024-02-06 08:47:24 --> Language Class Initialized
INFO - 2024-02-06 08:47:24 --> Config Class Initialized
INFO - 2024-02-06 08:47:24 --> Loader Class Initialized
INFO - 2024-02-06 08:47:24 --> Helper loaded: url_helper
INFO - 2024-02-06 08:47:24 --> Helper loaded: file_helper
INFO - 2024-02-06 08:47:24 --> Helper loaded: form_helper
INFO - 2024-02-06 08:47:24 --> Helper loaded: my_helper
INFO - 2024-02-06 08:47:24 --> Database Driver Class Initialized
INFO - 2024-02-06 08:47:24 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-06 08:47:24 --> Controller Class Initialized
DEBUG - 2024-02-06 08:47:24 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/view_mapel/views/v_view_mapel.php
DEBUG - 2024-02-06 08:47:24 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-02-06 08:47:24 --> Final output sent to browser
DEBUG - 2024-02-06 08:47:24 --> Total execution time: 0.1149
INFO - 2024-02-06 08:47:37 --> Config Class Initialized
INFO - 2024-02-06 08:47:37 --> Hooks Class Initialized
DEBUG - 2024-02-06 08:47:37 --> UTF-8 Support Enabled
INFO - 2024-02-06 08:47:37 --> Utf8 Class Initialized
INFO - 2024-02-06 08:47:37 --> URI Class Initialized
INFO - 2024-02-06 08:47:37 --> Router Class Initialized
INFO - 2024-02-06 08:47:37 --> Output Class Initialized
INFO - 2024-02-06 08:47:37 --> Security Class Initialized
DEBUG - 2024-02-06 08:47:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-06 08:47:37 --> Input Class Initialized
INFO - 2024-02-06 08:47:37 --> Language Class Initialized
INFO - 2024-02-06 08:47:37 --> Language Class Initialized
INFO - 2024-02-06 08:47:37 --> Config Class Initialized
INFO - 2024-02-06 08:47:37 --> Loader Class Initialized
INFO - 2024-02-06 08:47:37 --> Helper loaded: url_helper
INFO - 2024-02-06 08:47:37 --> Helper loaded: file_helper
INFO - 2024-02-06 08:47:37 --> Helper loaded: form_helper
INFO - 2024-02-06 08:47:37 --> Helper loaded: my_helper
INFO - 2024-02-06 08:47:37 --> Database Driver Class Initialized
INFO - 2024-02-06 08:47:37 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-06 08:47:37 --> Controller Class Initialized
INFO - 2024-02-06 08:47:37 --> Helper loaded: cookie_helper
INFO - 2024-02-06 08:47:37 --> Config Class Initialized
INFO - 2024-02-06 08:47:37 --> Hooks Class Initialized
DEBUG - 2024-02-06 08:47:37 --> UTF-8 Support Enabled
INFO - 2024-02-06 08:47:37 --> Utf8 Class Initialized
INFO - 2024-02-06 08:47:37 --> URI Class Initialized
INFO - 2024-02-06 08:47:37 --> Router Class Initialized
INFO - 2024-02-06 08:47:37 --> Output Class Initialized
INFO - 2024-02-06 08:47:37 --> Security Class Initialized
DEBUG - 2024-02-06 08:47:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-06 08:47:37 --> Input Class Initialized
INFO - 2024-02-06 08:47:37 --> Language Class Initialized
INFO - 2024-02-06 08:47:37 --> Language Class Initialized
INFO - 2024-02-06 08:47:37 --> Config Class Initialized
INFO - 2024-02-06 08:47:37 --> Loader Class Initialized
INFO - 2024-02-06 08:47:37 --> Helper loaded: url_helper
INFO - 2024-02-06 08:47:37 --> Helper loaded: file_helper
INFO - 2024-02-06 08:47:37 --> Helper loaded: form_helper
INFO - 2024-02-06 08:47:37 --> Helper loaded: my_helper
INFO - 2024-02-06 08:47:37 --> Database Driver Class Initialized
INFO - 2024-02-06 08:47:37 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-06 08:47:37 --> Controller Class Initialized
INFO - 2024-02-06 08:47:37 --> Config Class Initialized
INFO - 2024-02-06 08:47:37 --> Hooks Class Initialized
DEBUG - 2024-02-06 08:47:37 --> UTF-8 Support Enabled
INFO - 2024-02-06 08:47:37 --> Utf8 Class Initialized
INFO - 2024-02-06 08:47:37 --> URI Class Initialized
INFO - 2024-02-06 08:47:37 --> Router Class Initialized
INFO - 2024-02-06 08:47:38 --> Output Class Initialized
INFO - 2024-02-06 08:47:38 --> Security Class Initialized
DEBUG - 2024-02-06 08:47:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-06 08:47:38 --> Input Class Initialized
INFO - 2024-02-06 08:47:38 --> Language Class Initialized
INFO - 2024-02-06 08:47:38 --> Language Class Initialized
INFO - 2024-02-06 08:47:38 --> Config Class Initialized
INFO - 2024-02-06 08:47:38 --> Loader Class Initialized
INFO - 2024-02-06 08:47:38 --> Helper loaded: url_helper
INFO - 2024-02-06 08:47:38 --> Helper loaded: file_helper
INFO - 2024-02-06 08:47:38 --> Helper loaded: form_helper
INFO - 2024-02-06 08:47:38 --> Helper loaded: my_helper
INFO - 2024-02-06 08:47:38 --> Database Driver Class Initialized
INFO - 2024-02-06 08:47:38 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-06 08:47:38 --> Controller Class Initialized
DEBUG - 2024-02-06 08:47:38 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/login/views/login.php
DEBUG - 2024-02-06 08:47:38 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-02-06 08:47:38 --> Final output sent to browser
DEBUG - 2024-02-06 08:47:38 --> Total execution time: 0.0800
INFO - 2024-02-06 08:52:55 --> Config Class Initialized
INFO - 2024-02-06 08:52:55 --> Hooks Class Initialized
DEBUG - 2024-02-06 08:52:55 --> UTF-8 Support Enabled
INFO - 2024-02-06 08:52:55 --> Utf8 Class Initialized
INFO - 2024-02-06 08:52:55 --> URI Class Initialized
DEBUG - 2024-02-06 08:52:55 --> No URI present. Default controller set.
INFO - 2024-02-06 08:52:55 --> Router Class Initialized
INFO - 2024-02-06 08:52:55 --> Output Class Initialized
INFO - 2024-02-06 08:52:55 --> Security Class Initialized
DEBUG - 2024-02-06 08:52:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-06 08:52:55 --> Input Class Initialized
INFO - 2024-02-06 08:52:55 --> Language Class Initialized
INFO - 2024-02-06 08:52:55 --> Language Class Initialized
INFO - 2024-02-06 08:52:55 --> Config Class Initialized
INFO - 2024-02-06 08:52:55 --> Loader Class Initialized
INFO - 2024-02-06 08:52:55 --> Helper loaded: url_helper
INFO - 2024-02-06 08:52:55 --> Helper loaded: file_helper
INFO - 2024-02-06 08:52:55 --> Helper loaded: form_helper
INFO - 2024-02-06 08:52:55 --> Helper loaded: my_helper
INFO - 2024-02-06 08:52:56 --> Database Driver Class Initialized
INFO - 2024-02-06 08:52:56 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-06 08:52:56 --> Controller Class Initialized
INFO - 2024-02-06 08:52:56 --> Config Class Initialized
INFO - 2024-02-06 08:52:56 --> Hooks Class Initialized
DEBUG - 2024-02-06 08:52:56 --> UTF-8 Support Enabled
INFO - 2024-02-06 08:52:56 --> Utf8 Class Initialized
INFO - 2024-02-06 08:52:56 --> URI Class Initialized
INFO - 2024-02-06 08:52:56 --> Router Class Initialized
INFO - 2024-02-06 08:52:56 --> Output Class Initialized
INFO - 2024-02-06 08:52:56 --> Security Class Initialized
DEBUG - 2024-02-06 08:52:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-06 08:52:56 --> Input Class Initialized
INFO - 2024-02-06 08:52:56 --> Language Class Initialized
INFO - 2024-02-06 08:52:56 --> Language Class Initialized
INFO - 2024-02-06 08:52:56 --> Config Class Initialized
INFO - 2024-02-06 08:52:56 --> Loader Class Initialized
INFO - 2024-02-06 08:52:56 --> Helper loaded: url_helper
INFO - 2024-02-06 08:52:56 --> Helper loaded: file_helper
INFO - 2024-02-06 08:52:56 --> Helper loaded: form_helper
INFO - 2024-02-06 08:52:56 --> Helper loaded: my_helper
INFO - 2024-02-06 08:52:56 --> Database Driver Class Initialized
INFO - 2024-02-06 08:52:56 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-06 08:52:56 --> Controller Class Initialized
DEBUG - 2024-02-06 08:52:56 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/login/views/login.php
DEBUG - 2024-02-06 08:52:56 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-02-06 08:52:56 --> Final output sent to browser
DEBUG - 2024-02-06 08:52:56 --> Total execution time: 0.3233
