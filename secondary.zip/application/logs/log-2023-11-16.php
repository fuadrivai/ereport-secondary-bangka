<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2023-11-16 10:10:20 --> Config Class Initialized
INFO - 2023-11-16 10:10:20 --> Hooks Class Initialized
DEBUG - 2023-11-16 10:10:20 --> UTF-8 Support Enabled
INFO - 2023-11-16 10:10:20 --> Utf8 Class Initialized
INFO - 2023-11-16 10:10:20 --> URI Class Initialized
INFO - 2023-11-16 10:10:20 --> Router Class Initialized
INFO - 2023-11-16 10:10:20 --> Output Class Initialized
INFO - 2023-11-16 10:10:20 --> Security Class Initialized
DEBUG - 2023-11-16 10:10:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-16 10:10:20 --> Input Class Initialized
INFO - 2023-11-16 10:10:20 --> Language Class Initialized
INFO - 2023-11-16 10:10:20 --> Language Class Initialized
INFO - 2023-11-16 10:10:20 --> Config Class Initialized
INFO - 2023-11-16 10:10:20 --> Loader Class Initialized
INFO - 2023-11-16 10:10:20 --> Helper loaded: url_helper
INFO - 2023-11-16 10:10:20 --> Helper loaded: file_helper
INFO - 2023-11-16 10:10:20 --> Helper loaded: form_helper
INFO - 2023-11-16 10:10:20 --> Helper loaded: my_helper
INFO - 2023-11-16 10:10:20 --> Database Driver Class Initialized
INFO - 2023-11-16 10:10:20 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-16 10:10:20 --> Controller Class Initialized
DEBUG - 2023-11-16 10:10:20 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/login/views/login.php
DEBUG - 2023-11-16 10:10:20 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-11-16 10:10:20 --> Final output sent to browser
DEBUG - 2023-11-16 10:10:20 --> Total execution time: 0.0844
