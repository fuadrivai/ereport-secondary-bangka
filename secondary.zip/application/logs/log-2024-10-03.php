<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2024-10-03 09:27:35 --> Config Class Initialized
INFO - 2024-10-03 09:27:35 --> Hooks Class Initialized
DEBUG - 2024-10-03 09:27:35 --> UTF-8 Support Enabled
INFO - 2024-10-03 09:27:35 --> Utf8 Class Initialized
INFO - 2024-10-03 09:27:35 --> URI Class Initialized
INFO - 2024-10-03 09:27:35 --> Router Class Initialized
INFO - 2024-10-03 09:27:35 --> Output Class Initialized
INFO - 2024-10-03 09:27:35 --> Security Class Initialized
DEBUG - 2024-10-03 09:27:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-03 09:27:35 --> Input Class Initialized
INFO - 2024-10-03 09:27:35 --> Language Class Initialized
INFO - 2024-10-03 09:27:35 --> Language Class Initialized
INFO - 2024-10-03 09:27:35 --> Config Class Initialized
INFO - 2024-10-03 09:27:35 --> Loader Class Initialized
INFO - 2024-10-03 09:27:35 --> Helper loaded: url_helper
INFO - 2024-10-03 09:27:35 --> Helper loaded: file_helper
INFO - 2024-10-03 09:27:35 --> Helper loaded: form_helper
INFO - 2024-10-03 09:27:35 --> Helper loaded: my_helper
INFO - 2024-10-03 09:27:35 --> Database Driver Class Initialized
INFO - 2024-10-03 09:27:35 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-03 09:27:35 --> Controller Class Initialized
INFO - 2024-10-03 09:27:35 --> Helper loaded: cookie_helper
INFO - 2024-10-03 09:27:35 --> Final output sent to browser
DEBUG - 2024-10-03 09:27:35 --> Total execution time: 0.0639
INFO - 2024-10-03 09:27:43 --> Config Class Initialized
INFO - 2024-10-03 09:27:43 --> Hooks Class Initialized
DEBUG - 2024-10-03 09:27:43 --> UTF-8 Support Enabled
INFO - 2024-10-03 09:27:43 --> Utf8 Class Initialized
INFO - 2024-10-03 09:27:43 --> URI Class Initialized
INFO - 2024-10-03 09:27:43 --> Router Class Initialized
INFO - 2024-10-03 09:27:43 --> Output Class Initialized
INFO - 2024-10-03 09:27:43 --> Security Class Initialized
DEBUG - 2024-10-03 09:27:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-03 09:27:43 --> Input Class Initialized
INFO - 2024-10-03 09:27:43 --> Language Class Initialized
INFO - 2024-10-03 09:27:43 --> Language Class Initialized
INFO - 2024-10-03 09:27:43 --> Config Class Initialized
INFO - 2024-10-03 09:27:43 --> Loader Class Initialized
INFO - 2024-10-03 09:27:43 --> Helper loaded: url_helper
INFO - 2024-10-03 09:27:43 --> Helper loaded: file_helper
INFO - 2024-10-03 09:27:43 --> Helper loaded: form_helper
INFO - 2024-10-03 09:27:43 --> Helper loaded: my_helper
INFO - 2024-10-03 09:27:43 --> Database Driver Class Initialized
INFO - 2024-10-03 09:27:43 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-03 09:27:43 --> Controller Class Initialized
INFO - 2024-10-03 09:27:43 --> Helper loaded: cookie_helper
INFO - 2024-10-03 09:27:43 --> Final output sent to browser
DEBUG - 2024-10-03 09:27:43 --> Total execution time: 0.0268
INFO - 2024-10-03 09:27:43 --> Config Class Initialized
INFO - 2024-10-03 09:27:43 --> Hooks Class Initialized
DEBUG - 2024-10-03 09:27:43 --> UTF-8 Support Enabled
INFO - 2024-10-03 09:27:43 --> Utf8 Class Initialized
INFO - 2024-10-03 09:27:43 --> URI Class Initialized
INFO - 2024-10-03 09:27:43 --> Router Class Initialized
INFO - 2024-10-03 09:27:43 --> Output Class Initialized
INFO - 2024-10-03 09:27:43 --> Security Class Initialized
DEBUG - 2024-10-03 09:27:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-03 09:27:43 --> Input Class Initialized
INFO - 2024-10-03 09:27:43 --> Language Class Initialized
INFO - 2024-10-03 09:27:43 --> Language Class Initialized
INFO - 2024-10-03 09:27:43 --> Config Class Initialized
INFO - 2024-10-03 09:27:43 --> Loader Class Initialized
INFO - 2024-10-03 09:27:43 --> Helper loaded: url_helper
INFO - 2024-10-03 09:27:43 --> Helper loaded: file_helper
INFO - 2024-10-03 09:27:43 --> Helper loaded: form_helper
INFO - 2024-10-03 09:27:43 --> Helper loaded: my_helper
INFO - 2024-10-03 09:27:43 --> Database Driver Class Initialized
INFO - 2024-10-03 09:27:43 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-03 09:27:43 --> Controller Class Initialized
INFO - 2024-10-03 09:27:43 --> Helper loaded: cookie_helper
INFO - 2024-10-03 09:27:43 --> Config Class Initialized
INFO - 2024-10-03 09:27:43 --> Hooks Class Initialized
DEBUG - 2024-10-03 09:27:43 --> UTF-8 Support Enabled
INFO - 2024-10-03 09:27:43 --> Utf8 Class Initialized
INFO - 2024-10-03 09:27:43 --> URI Class Initialized
INFO - 2024-10-03 09:27:43 --> Router Class Initialized
INFO - 2024-10-03 09:27:43 --> Output Class Initialized
INFO - 2024-10-03 09:27:43 --> Security Class Initialized
DEBUG - 2024-10-03 09:27:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-03 09:27:43 --> Input Class Initialized
INFO - 2024-10-03 09:27:43 --> Language Class Initialized
INFO - 2024-10-03 09:27:43 --> Language Class Initialized
INFO - 2024-10-03 09:27:43 --> Config Class Initialized
INFO - 2024-10-03 09:27:43 --> Loader Class Initialized
INFO - 2024-10-03 09:27:43 --> Helper loaded: url_helper
INFO - 2024-10-03 09:27:43 --> Helper loaded: file_helper
INFO - 2024-10-03 09:27:43 --> Helper loaded: form_helper
INFO - 2024-10-03 09:27:43 --> Helper loaded: my_helper
INFO - 2024-10-03 09:27:43 --> Database Driver Class Initialized
INFO - 2024-10-03 09:27:43 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-03 09:27:43 --> Controller Class Initialized
DEBUG - 2024-10-03 09:27:43 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/lihat_raport/views/list.php
DEBUG - 2024-10-03 09:27:43 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-10-03 09:27:43 --> Final output sent to browser
DEBUG - 2024-10-03 09:27:43 --> Total execution time: 0.0346
INFO - 2024-10-03 09:27:54 --> Config Class Initialized
INFO - 2024-10-03 09:27:54 --> Hooks Class Initialized
DEBUG - 2024-10-03 09:27:54 --> UTF-8 Support Enabled
INFO - 2024-10-03 09:27:54 --> Utf8 Class Initialized
INFO - 2024-10-03 09:27:54 --> URI Class Initialized
INFO - 2024-10-03 09:27:54 --> Router Class Initialized
INFO - 2024-10-03 09:27:54 --> Output Class Initialized
INFO - 2024-10-03 09:27:54 --> Security Class Initialized
DEBUG - 2024-10-03 09:27:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-03 09:27:54 --> Input Class Initialized
INFO - 2024-10-03 09:27:54 --> Language Class Initialized
INFO - 2024-10-03 09:27:55 --> Language Class Initialized
INFO - 2024-10-03 09:27:55 --> Config Class Initialized
INFO - 2024-10-03 09:27:55 --> Loader Class Initialized
INFO - 2024-10-03 09:27:55 --> Helper loaded: url_helper
INFO - 2024-10-03 09:27:55 --> Helper loaded: file_helper
INFO - 2024-10-03 09:27:55 --> Helper loaded: form_helper
INFO - 2024-10-03 09:27:55 --> Helper loaded: my_helper
INFO - 2024-10-03 09:27:55 --> Database Driver Class Initialized
INFO - 2024-10-03 09:27:55 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-03 09:27:55 --> Controller Class Initialized
ERROR - 2024-10-03 09:27:55 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1160
ERROR - 2024-10-03 09:27:55 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1692
ERROR - 2024-10-03 09:27:55 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1729
ERROR - 2024-10-03 09:27:55 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1767
ERROR - 2024-10-03 09:27:55 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1806
ERROR - 2024-10-03 09:27:55 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1883
ERROR - 2024-10-03 09:27:55 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1962
ERROR - 2024-10-03 09:27:55 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 2042
ERROR - 2024-10-03 09:27:55 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 2122
ERROR - 2024-10-03 09:27:55 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 2202
ERROR - 2024-10-03 09:27:55 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 2277
ERROR - 2024-10-03 09:27:55 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php 32
ERROR - 2024-10-03 09:27:55 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php 32
DEBUG - 2024-10-03 09:27:55 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php
INFO - 2024-10-03 09:27:57 --> Final output sent to browser
DEBUG - 2024-10-03 09:27:57 --> Total execution time: 2.4342
INFO - 2024-10-03 09:29:13 --> Config Class Initialized
INFO - 2024-10-03 09:29:13 --> Hooks Class Initialized
DEBUG - 2024-10-03 09:29:13 --> UTF-8 Support Enabled
INFO - 2024-10-03 09:29:13 --> Utf8 Class Initialized
INFO - 2024-10-03 09:29:13 --> URI Class Initialized
INFO - 2024-10-03 09:29:13 --> Router Class Initialized
INFO - 2024-10-03 09:29:13 --> Output Class Initialized
INFO - 2024-10-03 09:29:13 --> Security Class Initialized
DEBUG - 2024-10-03 09:29:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-03 09:29:13 --> Input Class Initialized
INFO - 2024-10-03 09:29:13 --> Language Class Initialized
INFO - 2024-10-03 09:29:13 --> Language Class Initialized
INFO - 2024-10-03 09:29:13 --> Config Class Initialized
INFO - 2024-10-03 09:29:13 --> Loader Class Initialized
INFO - 2024-10-03 09:29:13 --> Helper loaded: url_helper
INFO - 2024-10-03 09:29:13 --> Helper loaded: file_helper
INFO - 2024-10-03 09:29:13 --> Helper loaded: form_helper
INFO - 2024-10-03 09:29:13 --> Helper loaded: my_helper
INFO - 2024-10-03 09:29:13 --> Database Driver Class Initialized
INFO - 2024-10-03 09:29:13 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-03 09:29:13 --> Controller Class Initialized
INFO - 2024-10-03 09:29:13 --> Helper loaded: cookie_helper
INFO - 2024-10-03 09:29:13 --> Final output sent to browser
DEBUG - 2024-10-03 09:29:13 --> Total execution time: 0.0294
INFO - 2024-10-03 09:29:14 --> Config Class Initialized
INFO - 2024-10-03 09:29:14 --> Hooks Class Initialized
DEBUG - 2024-10-03 09:29:14 --> UTF-8 Support Enabled
INFO - 2024-10-03 09:29:14 --> Utf8 Class Initialized
INFO - 2024-10-03 09:29:14 --> URI Class Initialized
INFO - 2024-10-03 09:29:14 --> Router Class Initialized
INFO - 2024-10-03 09:29:14 --> Output Class Initialized
INFO - 2024-10-03 09:29:14 --> Security Class Initialized
DEBUG - 2024-10-03 09:29:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-03 09:29:14 --> Input Class Initialized
INFO - 2024-10-03 09:29:14 --> Language Class Initialized
INFO - 2024-10-03 09:29:14 --> Language Class Initialized
INFO - 2024-10-03 09:29:14 --> Config Class Initialized
INFO - 2024-10-03 09:29:14 --> Loader Class Initialized
INFO - 2024-10-03 09:29:14 --> Helper loaded: url_helper
INFO - 2024-10-03 09:29:14 --> Helper loaded: file_helper
INFO - 2024-10-03 09:29:14 --> Helper loaded: form_helper
INFO - 2024-10-03 09:29:14 --> Helper loaded: my_helper
INFO - 2024-10-03 09:29:14 --> Database Driver Class Initialized
INFO - 2024-10-03 09:29:14 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-03 09:29:14 --> Controller Class Initialized
INFO - 2024-10-03 09:29:14 --> Helper loaded: cookie_helper
INFO - 2024-10-03 09:29:14 --> Config Class Initialized
INFO - 2024-10-03 09:29:14 --> Hooks Class Initialized
DEBUG - 2024-10-03 09:29:14 --> UTF-8 Support Enabled
INFO - 2024-10-03 09:29:14 --> Utf8 Class Initialized
INFO - 2024-10-03 09:29:14 --> URI Class Initialized
INFO - 2024-10-03 09:29:14 --> Router Class Initialized
INFO - 2024-10-03 09:29:14 --> Output Class Initialized
INFO - 2024-10-03 09:29:14 --> Security Class Initialized
DEBUG - 2024-10-03 09:29:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-03 09:29:14 --> Input Class Initialized
INFO - 2024-10-03 09:29:14 --> Language Class Initialized
INFO - 2024-10-03 09:29:14 --> Language Class Initialized
INFO - 2024-10-03 09:29:14 --> Config Class Initialized
INFO - 2024-10-03 09:29:14 --> Loader Class Initialized
INFO - 2024-10-03 09:29:14 --> Helper loaded: url_helper
INFO - 2024-10-03 09:29:14 --> Helper loaded: file_helper
INFO - 2024-10-03 09:29:14 --> Helper loaded: form_helper
INFO - 2024-10-03 09:29:14 --> Helper loaded: my_helper
INFO - 2024-10-03 09:29:14 --> Database Driver Class Initialized
INFO - 2024-10-03 09:29:14 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-03 09:29:14 --> Controller Class Initialized
DEBUG - 2024-10-03 09:29:14 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/lihat_raport/views/list.php
DEBUG - 2024-10-03 09:29:14 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-10-03 09:29:14 --> Final output sent to browser
DEBUG - 2024-10-03 09:29:14 --> Total execution time: 0.0341
INFO - 2024-10-03 09:29:38 --> Config Class Initialized
INFO - 2024-10-03 09:29:38 --> Hooks Class Initialized
DEBUG - 2024-10-03 09:29:38 --> UTF-8 Support Enabled
INFO - 2024-10-03 09:29:38 --> Utf8 Class Initialized
INFO - 2024-10-03 09:29:38 --> URI Class Initialized
INFO - 2024-10-03 09:29:38 --> Router Class Initialized
INFO - 2024-10-03 09:29:38 --> Output Class Initialized
INFO - 2024-10-03 09:29:38 --> Security Class Initialized
DEBUG - 2024-10-03 09:29:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-03 09:29:38 --> Input Class Initialized
INFO - 2024-10-03 09:29:38 --> Language Class Initialized
INFO - 2024-10-03 09:29:38 --> Language Class Initialized
INFO - 2024-10-03 09:29:38 --> Config Class Initialized
INFO - 2024-10-03 09:29:38 --> Loader Class Initialized
INFO - 2024-10-03 09:29:38 --> Helper loaded: url_helper
INFO - 2024-10-03 09:29:38 --> Helper loaded: file_helper
INFO - 2024-10-03 09:29:38 --> Helper loaded: form_helper
INFO - 2024-10-03 09:29:38 --> Helper loaded: my_helper
INFO - 2024-10-03 09:29:38 --> Database Driver Class Initialized
INFO - 2024-10-03 09:29:38 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-03 09:29:38 --> Controller Class Initialized
ERROR - 2024-10-03 09:29:38 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1160
ERROR - 2024-10-03 09:29:38 --> Severity: Notice --> Undefined variable: kkmx /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1493
ERROR - 2024-10-03 09:29:38 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1692
ERROR - 2024-10-03 09:29:38 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1729
ERROR - 2024-10-03 09:29:38 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1767
ERROR - 2024-10-03 09:29:38 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1806
ERROR - 2024-10-03 09:29:38 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1883
ERROR - 2024-10-03 09:29:38 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1962
ERROR - 2024-10-03 09:29:38 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 2042
ERROR - 2024-10-03 09:29:38 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 2122
ERROR - 2024-10-03 09:29:38 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 2202
ERROR - 2024-10-03 09:29:38 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 2277
ERROR - 2024-10-03 09:29:38 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php 32
ERROR - 2024-10-03 09:29:38 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php 32
DEBUG - 2024-10-03 09:29:38 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php
INFO - 2024-10-03 09:29:41 --> Final output sent to browser
DEBUG - 2024-10-03 09:29:41 --> Total execution time: 2.2902
INFO - 2024-10-03 12:31:46 --> Config Class Initialized
INFO - 2024-10-03 12:31:46 --> Hooks Class Initialized
DEBUG - 2024-10-03 12:31:46 --> UTF-8 Support Enabled
INFO - 2024-10-03 12:31:46 --> Utf8 Class Initialized
INFO - 2024-10-03 12:31:46 --> URI Class Initialized
INFO - 2024-10-03 12:31:46 --> Router Class Initialized
INFO - 2024-10-03 12:31:46 --> Output Class Initialized
INFO - 2024-10-03 12:31:46 --> Security Class Initialized
DEBUG - 2024-10-03 12:31:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-03 12:31:46 --> Input Class Initialized
INFO - 2024-10-03 12:31:46 --> Language Class Initialized
INFO - 2024-10-03 12:31:46 --> Language Class Initialized
INFO - 2024-10-03 12:31:46 --> Config Class Initialized
INFO - 2024-10-03 12:31:46 --> Loader Class Initialized
INFO - 2024-10-03 12:31:46 --> Helper loaded: url_helper
INFO - 2024-10-03 12:31:46 --> Helper loaded: file_helper
INFO - 2024-10-03 12:31:46 --> Helper loaded: form_helper
INFO - 2024-10-03 12:31:46 --> Helper loaded: my_helper
INFO - 2024-10-03 12:31:46 --> Database Driver Class Initialized
INFO - 2024-10-03 12:31:46 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-03 12:31:46 --> Controller Class Initialized
DEBUG - 2024-10-03 12:31:46 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_icb/views/list.php
DEBUG - 2024-10-03 12:31:46 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-10-03 12:31:46 --> Final output sent to browser
DEBUG - 2024-10-03 12:31:46 --> Total execution time: 0.1183
INFO - 2024-10-03 12:31:47 --> Config Class Initialized
INFO - 2024-10-03 12:31:47 --> Hooks Class Initialized
DEBUG - 2024-10-03 12:31:47 --> UTF-8 Support Enabled
INFO - 2024-10-03 12:31:47 --> Utf8 Class Initialized
INFO - 2024-10-03 12:31:47 --> URI Class Initialized
INFO - 2024-10-03 12:31:47 --> Router Class Initialized
INFO - 2024-10-03 12:31:47 --> Output Class Initialized
INFO - 2024-10-03 12:31:47 --> Security Class Initialized
DEBUG - 2024-10-03 12:31:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-03 12:31:47 --> Input Class Initialized
INFO - 2024-10-03 12:31:47 --> Language Class Initialized
INFO - 2024-10-03 12:31:47 --> Language Class Initialized
INFO - 2024-10-03 12:31:47 --> Config Class Initialized
INFO - 2024-10-03 12:31:47 --> Loader Class Initialized
INFO - 2024-10-03 12:31:47 --> Helper loaded: url_helper
INFO - 2024-10-03 12:31:47 --> Helper loaded: file_helper
INFO - 2024-10-03 12:31:47 --> Helper loaded: form_helper
INFO - 2024-10-03 12:31:47 --> Helper loaded: my_helper
INFO - 2024-10-03 12:31:47 --> Database Driver Class Initialized
INFO - 2024-10-03 12:31:47 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-03 12:31:47 --> Controller Class Initialized
INFO - 2024-10-03 15:31:18 --> Config Class Initialized
INFO - 2024-10-03 15:31:18 --> Hooks Class Initialized
DEBUG - 2024-10-03 15:31:18 --> UTF-8 Support Enabled
INFO - 2024-10-03 15:31:18 --> Utf8 Class Initialized
INFO - 2024-10-03 15:31:18 --> URI Class Initialized
INFO - 2024-10-03 15:31:18 --> Router Class Initialized
INFO - 2024-10-03 15:31:18 --> Output Class Initialized
INFO - 2024-10-03 15:31:18 --> Security Class Initialized
DEBUG - 2024-10-03 15:31:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-03 15:31:18 --> Input Class Initialized
INFO - 2024-10-03 15:31:18 --> Language Class Initialized
INFO - 2024-10-03 15:31:18 --> Language Class Initialized
INFO - 2024-10-03 15:31:18 --> Config Class Initialized
INFO - 2024-10-03 15:31:18 --> Loader Class Initialized
INFO - 2024-10-03 15:31:18 --> Helper loaded: url_helper
INFO - 2024-10-03 15:31:18 --> Helper loaded: file_helper
INFO - 2024-10-03 15:31:18 --> Helper loaded: form_helper
INFO - 2024-10-03 15:31:18 --> Helper loaded: my_helper
INFO - 2024-10-03 15:31:18 --> Database Driver Class Initialized
INFO - 2024-10-03 15:31:18 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-03 15:31:18 --> Controller Class Initialized
DEBUG - 2024-10-03 15:31:18 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_icb/views/list.php
DEBUG - 2024-10-03 15:31:18 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-10-03 15:31:18 --> Final output sent to browser
DEBUG - 2024-10-03 15:31:18 --> Total execution time: 0.0489
INFO - 2024-10-03 15:31:19 --> Config Class Initialized
INFO - 2024-10-03 15:31:19 --> Hooks Class Initialized
DEBUG - 2024-10-03 15:31:19 --> UTF-8 Support Enabled
INFO - 2024-10-03 15:31:19 --> Utf8 Class Initialized
INFO - 2024-10-03 15:31:19 --> URI Class Initialized
INFO - 2024-10-03 15:31:19 --> Router Class Initialized
INFO - 2024-10-03 15:31:19 --> Output Class Initialized
INFO - 2024-10-03 15:31:19 --> Security Class Initialized
DEBUG - 2024-10-03 15:31:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-03 15:31:19 --> Input Class Initialized
INFO - 2024-10-03 15:31:19 --> Language Class Initialized
INFO - 2024-10-03 15:31:19 --> Language Class Initialized
INFO - 2024-10-03 15:31:19 --> Config Class Initialized
INFO - 2024-10-03 15:31:19 --> Loader Class Initialized
INFO - 2024-10-03 15:31:19 --> Helper loaded: url_helper
INFO - 2024-10-03 15:31:19 --> Helper loaded: file_helper
INFO - 2024-10-03 15:31:19 --> Helper loaded: form_helper
INFO - 2024-10-03 15:31:19 --> Helper loaded: my_helper
INFO - 2024-10-03 15:31:19 --> Database Driver Class Initialized
INFO - 2024-10-03 15:31:19 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-03 15:31:19 --> Controller Class Initialized
INFO - 2024-10-03 15:32:25 --> Config Class Initialized
INFO - 2024-10-03 15:32:25 --> Hooks Class Initialized
DEBUG - 2024-10-03 15:32:25 --> UTF-8 Support Enabled
INFO - 2024-10-03 15:32:25 --> Utf8 Class Initialized
INFO - 2024-10-03 15:32:25 --> URI Class Initialized
INFO - 2024-10-03 15:32:25 --> Router Class Initialized
INFO - 2024-10-03 15:32:25 --> Output Class Initialized
INFO - 2024-10-03 15:32:25 --> Security Class Initialized
DEBUG - 2024-10-03 15:32:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-03 15:32:25 --> Input Class Initialized
INFO - 2024-10-03 15:32:25 --> Language Class Initialized
INFO - 2024-10-03 15:32:25 --> Language Class Initialized
INFO - 2024-10-03 15:32:25 --> Config Class Initialized
INFO - 2024-10-03 15:32:25 --> Loader Class Initialized
INFO - 2024-10-03 15:32:25 --> Helper loaded: url_helper
INFO - 2024-10-03 15:32:25 --> Helper loaded: file_helper
INFO - 2024-10-03 15:32:25 --> Helper loaded: form_helper
INFO - 2024-10-03 15:32:25 --> Helper loaded: my_helper
INFO - 2024-10-03 15:32:25 --> Database Driver Class Initialized
INFO - 2024-10-03 15:32:25 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-03 15:32:25 --> Controller Class Initialized
INFO - 2024-10-03 15:32:26 --> Final output sent to browser
DEBUG - 2024-10-03 15:32:26 --> Total execution time: 0.4138
INFO - 2024-10-03 15:44:41 --> Config Class Initialized
INFO - 2024-10-03 15:44:41 --> Hooks Class Initialized
DEBUG - 2024-10-03 15:44:41 --> UTF-8 Support Enabled
INFO - 2024-10-03 15:44:41 --> Utf8 Class Initialized
INFO - 2024-10-03 15:44:41 --> URI Class Initialized
INFO - 2024-10-03 15:44:41 --> Router Class Initialized
INFO - 2024-10-03 15:44:41 --> Output Class Initialized
INFO - 2024-10-03 15:44:41 --> Security Class Initialized
DEBUG - 2024-10-03 15:44:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-03 15:44:41 --> Input Class Initialized
INFO - 2024-10-03 15:44:41 --> Language Class Initialized
INFO - 2024-10-03 15:44:41 --> Language Class Initialized
INFO - 2024-10-03 15:44:41 --> Config Class Initialized
INFO - 2024-10-03 15:44:41 --> Loader Class Initialized
INFO - 2024-10-03 15:44:41 --> Helper loaded: url_helper
INFO - 2024-10-03 15:44:41 --> Helper loaded: file_helper
INFO - 2024-10-03 15:44:41 --> Helper loaded: form_helper
INFO - 2024-10-03 15:44:41 --> Helper loaded: my_helper
INFO - 2024-10-03 15:44:41 --> Database Driver Class Initialized
INFO - 2024-10-03 15:44:41 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-03 15:44:41 --> Controller Class Initialized
INFO - 2024-10-03 15:44:41 --> Final output sent to browser
DEBUG - 2024-10-03 15:44:41 --> Total execution time: 0.0494
INFO - 2024-10-03 15:45:01 --> Config Class Initialized
INFO - 2024-10-03 15:45:01 --> Hooks Class Initialized
DEBUG - 2024-10-03 15:45:01 --> UTF-8 Support Enabled
INFO - 2024-10-03 15:45:01 --> Utf8 Class Initialized
INFO - 2024-10-03 15:45:01 --> URI Class Initialized
INFO - 2024-10-03 15:45:01 --> Router Class Initialized
INFO - 2024-10-03 15:45:01 --> Output Class Initialized
INFO - 2024-10-03 15:45:01 --> Security Class Initialized
DEBUG - 2024-10-03 15:45:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-03 15:45:01 --> Input Class Initialized
INFO - 2024-10-03 15:45:01 --> Language Class Initialized
INFO - 2024-10-03 15:45:01 --> Language Class Initialized
INFO - 2024-10-03 15:45:01 --> Config Class Initialized
INFO - 2024-10-03 15:45:01 --> Loader Class Initialized
INFO - 2024-10-03 15:45:01 --> Helper loaded: url_helper
INFO - 2024-10-03 15:45:01 --> Helper loaded: file_helper
INFO - 2024-10-03 15:45:01 --> Helper loaded: form_helper
INFO - 2024-10-03 15:45:01 --> Helper loaded: my_helper
INFO - 2024-10-03 15:45:01 --> Database Driver Class Initialized
INFO - 2024-10-03 15:45:01 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-03 15:45:01 --> Controller Class Initialized
INFO - 2024-10-03 15:45:01 --> Final output sent to browser
DEBUG - 2024-10-03 15:45:01 --> Total execution time: 0.5196
INFO - 2024-10-03 15:45:05 --> Config Class Initialized
INFO - 2024-10-03 15:45:05 --> Hooks Class Initialized
DEBUG - 2024-10-03 15:45:05 --> UTF-8 Support Enabled
INFO - 2024-10-03 15:45:05 --> Utf8 Class Initialized
INFO - 2024-10-03 15:45:05 --> URI Class Initialized
INFO - 2024-10-03 15:45:05 --> Router Class Initialized
INFO - 2024-10-03 15:45:05 --> Output Class Initialized
INFO - 2024-10-03 15:45:05 --> Security Class Initialized
DEBUG - 2024-10-03 15:45:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-03 15:45:05 --> Input Class Initialized
INFO - 2024-10-03 15:45:05 --> Language Class Initialized
INFO - 2024-10-03 15:45:05 --> Language Class Initialized
INFO - 2024-10-03 15:45:05 --> Config Class Initialized
INFO - 2024-10-03 15:45:05 --> Loader Class Initialized
INFO - 2024-10-03 15:45:05 --> Helper loaded: url_helper
INFO - 2024-10-03 15:45:05 --> Helper loaded: file_helper
INFO - 2024-10-03 15:45:05 --> Helper loaded: form_helper
INFO - 2024-10-03 15:45:05 --> Helper loaded: my_helper
INFO - 2024-10-03 15:45:05 --> Database Driver Class Initialized
INFO - 2024-10-03 15:45:05 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-03 15:45:05 --> Controller Class Initialized
INFO - 2024-10-03 15:45:05 --> Final output sent to browser
DEBUG - 2024-10-03 15:45:05 --> Total execution time: 0.2043
INFO - 2024-10-03 15:45:23 --> Config Class Initialized
INFO - 2024-10-03 15:45:23 --> Hooks Class Initialized
DEBUG - 2024-10-03 15:45:23 --> UTF-8 Support Enabled
INFO - 2024-10-03 15:45:23 --> Utf8 Class Initialized
INFO - 2024-10-03 15:45:23 --> URI Class Initialized
INFO - 2024-10-03 15:45:23 --> Router Class Initialized
INFO - 2024-10-03 15:45:23 --> Output Class Initialized
INFO - 2024-10-03 15:45:23 --> Security Class Initialized
DEBUG - 2024-10-03 15:45:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-03 15:45:23 --> Input Class Initialized
INFO - 2024-10-03 15:45:23 --> Language Class Initialized
INFO - 2024-10-03 15:45:23 --> Language Class Initialized
INFO - 2024-10-03 15:45:23 --> Config Class Initialized
INFO - 2024-10-03 15:45:23 --> Loader Class Initialized
INFO - 2024-10-03 15:45:23 --> Helper loaded: url_helper
INFO - 2024-10-03 15:45:23 --> Helper loaded: file_helper
INFO - 2024-10-03 15:45:23 --> Helper loaded: form_helper
INFO - 2024-10-03 15:45:23 --> Helper loaded: my_helper
INFO - 2024-10-03 15:45:23 --> Database Driver Class Initialized
INFO - 2024-10-03 15:45:23 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-03 15:45:23 --> Controller Class Initialized
INFO - 2024-10-03 15:45:23 --> Final output sent to browser
DEBUG - 2024-10-03 15:45:23 --> Total execution time: 0.0346
INFO - 2024-10-03 15:46:26 --> Config Class Initialized
INFO - 2024-10-03 15:46:26 --> Hooks Class Initialized
DEBUG - 2024-10-03 15:46:26 --> UTF-8 Support Enabled
INFO - 2024-10-03 15:46:26 --> Utf8 Class Initialized
INFO - 2024-10-03 15:46:26 --> URI Class Initialized
INFO - 2024-10-03 15:46:26 --> Router Class Initialized
INFO - 2024-10-03 15:46:26 --> Output Class Initialized
INFO - 2024-10-03 15:46:26 --> Security Class Initialized
DEBUG - 2024-10-03 15:46:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-03 15:46:26 --> Input Class Initialized
INFO - 2024-10-03 15:46:26 --> Language Class Initialized
INFO - 2024-10-03 15:46:26 --> Language Class Initialized
INFO - 2024-10-03 15:46:26 --> Config Class Initialized
INFO - 2024-10-03 15:46:26 --> Loader Class Initialized
INFO - 2024-10-03 15:46:26 --> Helper loaded: url_helper
INFO - 2024-10-03 15:46:26 --> Helper loaded: file_helper
INFO - 2024-10-03 15:46:26 --> Helper loaded: form_helper
INFO - 2024-10-03 15:46:26 --> Helper loaded: my_helper
INFO - 2024-10-03 15:46:26 --> Database Driver Class Initialized
INFO - 2024-10-03 15:46:26 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-03 15:46:26 --> Controller Class Initialized
INFO - 2024-10-03 15:46:26 --> Final output sent to browser
DEBUG - 2024-10-03 15:46:26 --> Total execution time: 0.1072
INFO - 2024-10-03 15:47:10 --> Config Class Initialized
INFO - 2024-10-03 15:47:10 --> Hooks Class Initialized
DEBUG - 2024-10-03 15:47:10 --> UTF-8 Support Enabled
INFO - 2024-10-03 15:47:10 --> Utf8 Class Initialized
INFO - 2024-10-03 15:47:10 --> URI Class Initialized
INFO - 2024-10-03 15:47:10 --> Router Class Initialized
INFO - 2024-10-03 15:47:10 --> Output Class Initialized
INFO - 2024-10-03 15:47:10 --> Security Class Initialized
DEBUG - 2024-10-03 15:47:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-03 15:47:10 --> Input Class Initialized
INFO - 2024-10-03 15:47:10 --> Language Class Initialized
INFO - 2024-10-03 15:47:10 --> Language Class Initialized
INFO - 2024-10-03 15:47:10 --> Config Class Initialized
INFO - 2024-10-03 15:47:10 --> Loader Class Initialized
INFO - 2024-10-03 15:47:10 --> Helper loaded: url_helper
INFO - 2024-10-03 15:47:10 --> Helper loaded: file_helper
INFO - 2024-10-03 15:47:10 --> Helper loaded: form_helper
INFO - 2024-10-03 15:47:10 --> Helper loaded: my_helper
INFO - 2024-10-03 15:47:10 --> Database Driver Class Initialized
INFO - 2024-10-03 15:47:10 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-03 15:47:10 --> Controller Class Initialized
INFO - 2024-10-03 15:47:10 --> Final output sent to browser
DEBUG - 2024-10-03 15:47:10 --> Total execution time: 0.0348
INFO - 2024-10-03 15:52:05 --> Config Class Initialized
INFO - 2024-10-03 15:52:05 --> Hooks Class Initialized
DEBUG - 2024-10-03 15:52:05 --> UTF-8 Support Enabled
INFO - 2024-10-03 15:52:05 --> Utf8 Class Initialized
INFO - 2024-10-03 15:52:05 --> URI Class Initialized
INFO - 2024-10-03 15:52:05 --> Router Class Initialized
INFO - 2024-10-03 15:52:05 --> Output Class Initialized
INFO - 2024-10-03 15:52:05 --> Security Class Initialized
DEBUG - 2024-10-03 15:52:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-03 15:52:05 --> Input Class Initialized
INFO - 2024-10-03 15:52:05 --> Language Class Initialized
INFO - 2024-10-03 15:52:05 --> Language Class Initialized
INFO - 2024-10-03 15:52:05 --> Config Class Initialized
INFO - 2024-10-03 15:52:05 --> Loader Class Initialized
INFO - 2024-10-03 15:52:05 --> Helper loaded: url_helper
INFO - 2024-10-03 15:52:05 --> Helper loaded: file_helper
INFO - 2024-10-03 15:52:05 --> Helper loaded: form_helper
INFO - 2024-10-03 15:52:05 --> Helper loaded: my_helper
INFO - 2024-10-03 15:52:05 --> Database Driver Class Initialized
INFO - 2024-10-03 15:52:05 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-03 15:52:05 --> Controller Class Initialized
INFO - 2024-10-03 15:52:05 --> Final output sent to browser
DEBUG - 2024-10-03 15:52:05 --> Total execution time: 0.0727
INFO - 2024-10-03 15:52:10 --> Config Class Initialized
INFO - 2024-10-03 15:52:10 --> Hooks Class Initialized
DEBUG - 2024-10-03 15:52:10 --> UTF-8 Support Enabled
INFO - 2024-10-03 15:52:10 --> Utf8 Class Initialized
INFO - 2024-10-03 15:52:10 --> URI Class Initialized
INFO - 2024-10-03 15:52:10 --> Router Class Initialized
INFO - 2024-10-03 15:52:10 --> Output Class Initialized
INFO - 2024-10-03 15:52:10 --> Security Class Initialized
DEBUG - 2024-10-03 15:52:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-03 15:52:10 --> Input Class Initialized
INFO - 2024-10-03 15:52:10 --> Language Class Initialized
INFO - 2024-10-03 15:52:10 --> Language Class Initialized
INFO - 2024-10-03 15:52:10 --> Config Class Initialized
INFO - 2024-10-03 15:52:10 --> Loader Class Initialized
INFO - 2024-10-03 15:52:10 --> Helper loaded: url_helper
INFO - 2024-10-03 15:52:10 --> Helper loaded: file_helper
INFO - 2024-10-03 15:52:10 --> Helper loaded: form_helper
INFO - 2024-10-03 15:52:10 --> Helper loaded: my_helper
INFO - 2024-10-03 15:52:10 --> Database Driver Class Initialized
INFO - 2024-10-03 15:52:10 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-03 15:52:10 --> Controller Class Initialized
INFO - 2024-10-03 15:52:10 --> Final output sent to browser
DEBUG - 2024-10-03 15:52:10 --> Total execution time: 0.0801
INFO - 2024-10-03 15:52:27 --> Config Class Initialized
INFO - 2024-10-03 15:52:27 --> Hooks Class Initialized
DEBUG - 2024-10-03 15:52:27 --> UTF-8 Support Enabled
INFO - 2024-10-03 15:52:27 --> Utf8 Class Initialized
INFO - 2024-10-03 15:52:27 --> URI Class Initialized
INFO - 2024-10-03 15:52:27 --> Router Class Initialized
INFO - 2024-10-03 15:52:27 --> Output Class Initialized
INFO - 2024-10-03 15:52:27 --> Security Class Initialized
DEBUG - 2024-10-03 15:52:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-03 15:52:27 --> Input Class Initialized
INFO - 2024-10-03 15:52:27 --> Language Class Initialized
INFO - 2024-10-03 15:52:27 --> Language Class Initialized
INFO - 2024-10-03 15:52:27 --> Config Class Initialized
INFO - 2024-10-03 15:52:27 --> Loader Class Initialized
INFO - 2024-10-03 15:52:27 --> Helper loaded: url_helper
INFO - 2024-10-03 15:52:27 --> Helper loaded: file_helper
INFO - 2024-10-03 15:52:27 --> Helper loaded: form_helper
INFO - 2024-10-03 15:52:27 --> Helper loaded: my_helper
INFO - 2024-10-03 15:52:27 --> Database Driver Class Initialized
INFO - 2024-10-03 15:52:27 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-03 15:52:27 --> Controller Class Initialized
INFO - 2024-10-03 15:52:27 --> Final output sent to browser
DEBUG - 2024-10-03 15:52:27 --> Total execution time: 0.0290
INFO - 2024-10-03 15:55:29 --> Config Class Initialized
INFO - 2024-10-03 15:55:29 --> Hooks Class Initialized
DEBUG - 2024-10-03 15:55:29 --> UTF-8 Support Enabled
INFO - 2024-10-03 15:55:29 --> Utf8 Class Initialized
INFO - 2024-10-03 15:55:29 --> URI Class Initialized
INFO - 2024-10-03 15:55:29 --> Router Class Initialized
INFO - 2024-10-03 15:55:29 --> Output Class Initialized
INFO - 2024-10-03 15:55:29 --> Security Class Initialized
DEBUG - 2024-10-03 15:55:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-03 15:55:29 --> Input Class Initialized
INFO - 2024-10-03 15:55:29 --> Language Class Initialized
INFO - 2024-10-03 15:55:29 --> Language Class Initialized
INFO - 2024-10-03 15:55:29 --> Config Class Initialized
INFO - 2024-10-03 15:55:29 --> Loader Class Initialized
INFO - 2024-10-03 15:55:29 --> Helper loaded: url_helper
INFO - 2024-10-03 15:55:29 --> Helper loaded: file_helper
INFO - 2024-10-03 15:55:29 --> Helper loaded: form_helper
INFO - 2024-10-03 15:55:29 --> Helper loaded: my_helper
INFO - 2024-10-03 15:55:29 --> Database Driver Class Initialized
INFO - 2024-10-03 15:55:29 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-03 15:55:29 --> Controller Class Initialized
INFO - 2024-10-03 15:55:29 --> Final output sent to browser
DEBUG - 2024-10-03 15:55:29 --> Total execution time: 0.6305
INFO - 2024-10-03 15:55:42 --> Config Class Initialized
INFO - 2024-10-03 15:55:42 --> Hooks Class Initialized
DEBUG - 2024-10-03 15:55:42 --> UTF-8 Support Enabled
INFO - 2024-10-03 15:55:42 --> Utf8 Class Initialized
INFO - 2024-10-03 15:55:42 --> URI Class Initialized
INFO - 2024-10-03 15:55:42 --> Router Class Initialized
INFO - 2024-10-03 15:55:42 --> Output Class Initialized
INFO - 2024-10-03 15:55:42 --> Security Class Initialized
DEBUG - 2024-10-03 15:55:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-03 15:55:42 --> Input Class Initialized
INFO - 2024-10-03 15:55:42 --> Language Class Initialized
INFO - 2024-10-03 15:55:42 --> Language Class Initialized
INFO - 2024-10-03 15:55:42 --> Config Class Initialized
INFO - 2024-10-03 15:55:42 --> Loader Class Initialized
INFO - 2024-10-03 15:55:42 --> Helper loaded: url_helper
INFO - 2024-10-03 15:55:42 --> Helper loaded: file_helper
INFO - 2024-10-03 15:55:42 --> Helper loaded: form_helper
INFO - 2024-10-03 15:55:42 --> Helper loaded: my_helper
INFO - 2024-10-03 15:55:42 --> Database Driver Class Initialized
INFO - 2024-10-03 15:55:42 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-03 15:55:42 --> Controller Class Initialized
INFO - 2024-10-03 15:55:42 --> Final output sent to browser
DEBUG - 2024-10-03 15:55:42 --> Total execution time: 0.0456
INFO - 2024-10-03 15:55:49 --> Config Class Initialized
INFO - 2024-10-03 15:55:49 --> Hooks Class Initialized
DEBUG - 2024-10-03 15:55:49 --> UTF-8 Support Enabled
INFO - 2024-10-03 15:55:49 --> Utf8 Class Initialized
INFO - 2024-10-03 15:55:49 --> URI Class Initialized
INFO - 2024-10-03 15:55:49 --> Router Class Initialized
INFO - 2024-10-03 15:55:49 --> Output Class Initialized
INFO - 2024-10-03 15:55:49 --> Security Class Initialized
DEBUG - 2024-10-03 15:55:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-03 15:55:49 --> Input Class Initialized
INFO - 2024-10-03 15:55:49 --> Language Class Initialized
INFO - 2024-10-03 15:55:49 --> Language Class Initialized
INFO - 2024-10-03 15:55:49 --> Config Class Initialized
INFO - 2024-10-03 15:55:49 --> Loader Class Initialized
INFO - 2024-10-03 15:55:49 --> Helper loaded: url_helper
INFO - 2024-10-03 15:55:49 --> Helper loaded: file_helper
INFO - 2024-10-03 15:55:49 --> Helper loaded: form_helper
INFO - 2024-10-03 15:55:49 --> Helper loaded: my_helper
INFO - 2024-10-03 15:55:49 --> Database Driver Class Initialized
INFO - 2024-10-03 15:55:49 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-03 15:55:49 --> Controller Class Initialized
INFO - 2024-10-03 15:55:49 --> Final output sent to browser
DEBUG - 2024-10-03 15:55:49 --> Total execution time: 0.0360
INFO - 2024-10-03 15:59:02 --> Config Class Initialized
INFO - 2024-10-03 15:59:02 --> Hooks Class Initialized
DEBUG - 2024-10-03 15:59:02 --> UTF-8 Support Enabled
INFO - 2024-10-03 15:59:02 --> Utf8 Class Initialized
INFO - 2024-10-03 15:59:02 --> URI Class Initialized
INFO - 2024-10-03 15:59:02 --> Router Class Initialized
INFO - 2024-10-03 15:59:02 --> Output Class Initialized
INFO - 2024-10-03 15:59:02 --> Security Class Initialized
DEBUG - 2024-10-03 15:59:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-03 15:59:02 --> Input Class Initialized
INFO - 2024-10-03 15:59:02 --> Language Class Initialized
INFO - 2024-10-03 15:59:02 --> Language Class Initialized
INFO - 2024-10-03 15:59:02 --> Config Class Initialized
INFO - 2024-10-03 15:59:02 --> Loader Class Initialized
INFO - 2024-10-03 15:59:02 --> Helper loaded: url_helper
INFO - 2024-10-03 15:59:02 --> Helper loaded: file_helper
INFO - 2024-10-03 15:59:02 --> Helper loaded: form_helper
INFO - 2024-10-03 15:59:02 --> Helper loaded: my_helper
INFO - 2024-10-03 15:59:02 --> Database Driver Class Initialized
INFO - 2024-10-03 15:59:02 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-03 15:59:02 --> Controller Class Initialized
INFO - 2024-10-03 15:59:02 --> Final output sent to browser
DEBUG - 2024-10-03 15:59:02 --> Total execution time: 0.0799
INFO - 2024-10-03 15:59:10 --> Config Class Initialized
INFO - 2024-10-03 15:59:10 --> Hooks Class Initialized
DEBUG - 2024-10-03 15:59:10 --> UTF-8 Support Enabled
INFO - 2024-10-03 15:59:10 --> Utf8 Class Initialized
INFO - 2024-10-03 15:59:10 --> URI Class Initialized
INFO - 2024-10-03 15:59:10 --> Router Class Initialized
INFO - 2024-10-03 15:59:10 --> Output Class Initialized
INFO - 2024-10-03 15:59:11 --> Security Class Initialized
DEBUG - 2024-10-03 15:59:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-03 15:59:11 --> Input Class Initialized
INFO - 2024-10-03 15:59:11 --> Language Class Initialized
INFO - 2024-10-03 15:59:11 --> Language Class Initialized
INFO - 2024-10-03 15:59:11 --> Config Class Initialized
INFO - 2024-10-03 15:59:11 --> Loader Class Initialized
INFO - 2024-10-03 15:59:11 --> Helper loaded: url_helper
INFO - 2024-10-03 15:59:11 --> Helper loaded: file_helper
INFO - 2024-10-03 15:59:11 --> Helper loaded: form_helper
INFO - 2024-10-03 15:59:11 --> Helper loaded: my_helper
INFO - 2024-10-03 15:59:11 --> Database Driver Class Initialized
INFO - 2024-10-03 15:59:11 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-03 15:59:11 --> Controller Class Initialized
INFO - 2024-10-03 15:59:11 --> Final output sent to browser
DEBUG - 2024-10-03 15:59:11 --> Total execution time: 0.0891
INFO - 2024-10-03 16:16:54 --> Config Class Initialized
INFO - 2024-10-03 16:16:54 --> Hooks Class Initialized
DEBUG - 2024-10-03 16:16:54 --> UTF-8 Support Enabled
INFO - 2024-10-03 16:16:54 --> Utf8 Class Initialized
INFO - 2024-10-03 16:16:54 --> URI Class Initialized
INFO - 2024-10-03 16:16:54 --> Router Class Initialized
INFO - 2024-10-03 16:16:54 --> Output Class Initialized
INFO - 2024-10-03 16:16:54 --> Security Class Initialized
DEBUG - 2024-10-03 16:16:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-03 16:16:54 --> Input Class Initialized
INFO - 2024-10-03 16:16:54 --> Language Class Initialized
INFO - 2024-10-03 16:16:54 --> Language Class Initialized
INFO - 2024-10-03 16:16:54 --> Config Class Initialized
INFO - 2024-10-03 16:16:54 --> Loader Class Initialized
INFO - 2024-10-03 16:16:54 --> Helper loaded: url_helper
INFO - 2024-10-03 16:16:54 --> Helper loaded: file_helper
INFO - 2024-10-03 16:16:54 --> Helper loaded: form_helper
INFO - 2024-10-03 16:16:54 --> Helper loaded: my_helper
INFO - 2024-10-03 16:16:54 --> Database Driver Class Initialized
INFO - 2024-10-03 16:16:54 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-03 16:16:54 --> Controller Class Initialized
INFO - 2024-10-03 16:16:54 --> Helper loaded: cookie_helper
INFO - 2024-10-03 16:16:54 --> Final output sent to browser
DEBUG - 2024-10-03 16:16:54 --> Total execution time: 0.0653
INFO - 2024-10-03 16:16:55 --> Config Class Initialized
INFO - 2024-10-03 16:16:55 --> Hooks Class Initialized
DEBUG - 2024-10-03 16:16:55 --> UTF-8 Support Enabled
INFO - 2024-10-03 16:16:55 --> Utf8 Class Initialized
INFO - 2024-10-03 16:16:55 --> URI Class Initialized
INFO - 2024-10-03 16:16:55 --> Router Class Initialized
INFO - 2024-10-03 16:16:55 --> Output Class Initialized
INFO - 2024-10-03 16:16:55 --> Security Class Initialized
DEBUG - 2024-10-03 16:16:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-03 16:16:55 --> Input Class Initialized
INFO - 2024-10-03 16:16:55 --> Language Class Initialized
INFO - 2024-10-03 16:16:55 --> Language Class Initialized
INFO - 2024-10-03 16:16:55 --> Config Class Initialized
INFO - 2024-10-03 16:16:55 --> Loader Class Initialized
INFO - 2024-10-03 16:16:55 --> Helper loaded: url_helper
INFO - 2024-10-03 16:16:55 --> Helper loaded: file_helper
INFO - 2024-10-03 16:16:55 --> Helper loaded: form_helper
INFO - 2024-10-03 16:16:55 --> Helper loaded: my_helper
INFO - 2024-10-03 16:16:55 --> Database Driver Class Initialized
INFO - 2024-10-03 16:16:55 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-03 16:16:55 --> Controller Class Initialized
INFO - 2024-10-03 16:16:55 --> Helper loaded: cookie_helper
INFO - 2024-10-03 16:16:55 --> Config Class Initialized
INFO - 2024-10-03 16:16:55 --> Hooks Class Initialized
DEBUG - 2024-10-03 16:16:55 --> UTF-8 Support Enabled
INFO - 2024-10-03 16:16:55 --> Utf8 Class Initialized
INFO - 2024-10-03 16:16:55 --> URI Class Initialized
INFO - 2024-10-03 16:16:55 --> Router Class Initialized
INFO - 2024-10-03 16:16:55 --> Output Class Initialized
INFO - 2024-10-03 16:16:55 --> Security Class Initialized
DEBUG - 2024-10-03 16:16:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-03 16:16:55 --> Input Class Initialized
INFO - 2024-10-03 16:16:55 --> Language Class Initialized
INFO - 2024-10-03 16:16:55 --> Language Class Initialized
INFO - 2024-10-03 16:16:55 --> Config Class Initialized
INFO - 2024-10-03 16:16:55 --> Loader Class Initialized
INFO - 2024-10-03 16:16:55 --> Helper loaded: url_helper
INFO - 2024-10-03 16:16:55 --> Helper loaded: file_helper
INFO - 2024-10-03 16:16:55 --> Helper loaded: form_helper
INFO - 2024-10-03 16:16:55 --> Helper loaded: my_helper
INFO - 2024-10-03 16:16:55 --> Database Driver Class Initialized
INFO - 2024-10-03 16:16:55 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-03 16:16:55 --> Controller Class Initialized
DEBUG - 2024-10-03 16:16:55 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/lihat_raport/views/list.php
DEBUG - 2024-10-03 16:16:55 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-10-03 16:16:55 --> Final output sent to browser
DEBUG - 2024-10-03 16:16:55 --> Total execution time: 0.1489
INFO - 2024-10-03 16:46:11 --> Config Class Initialized
INFO - 2024-10-03 16:46:11 --> Hooks Class Initialized
DEBUG - 2024-10-03 16:46:11 --> UTF-8 Support Enabled
INFO - 2024-10-03 16:46:11 --> Utf8 Class Initialized
INFO - 2024-10-03 16:46:11 --> URI Class Initialized
INFO - 2024-10-03 16:46:11 --> Router Class Initialized
INFO - 2024-10-03 16:46:11 --> Output Class Initialized
INFO - 2024-10-03 16:46:11 --> Security Class Initialized
DEBUG - 2024-10-03 16:46:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-03 16:46:11 --> Input Class Initialized
INFO - 2024-10-03 16:46:11 --> Language Class Initialized
INFO - 2024-10-03 16:46:11 --> Language Class Initialized
INFO - 2024-10-03 16:46:11 --> Config Class Initialized
INFO - 2024-10-03 16:46:11 --> Loader Class Initialized
INFO - 2024-10-03 16:46:11 --> Helper loaded: url_helper
INFO - 2024-10-03 16:46:11 --> Helper loaded: file_helper
INFO - 2024-10-03 16:46:11 --> Helper loaded: form_helper
INFO - 2024-10-03 16:46:11 --> Helper loaded: my_helper
INFO - 2024-10-03 16:46:11 --> Database Driver Class Initialized
INFO - 2024-10-03 16:46:11 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-03 16:46:11 --> Controller Class Initialized
INFO - 2024-10-03 16:46:11 --> Final output sent to browser
DEBUG - 2024-10-03 16:46:11 --> Total execution time: 0.1075
INFO - 2024-10-03 16:46:24 --> Config Class Initialized
INFO - 2024-10-03 16:46:24 --> Hooks Class Initialized
DEBUG - 2024-10-03 16:46:24 --> UTF-8 Support Enabled
INFO - 2024-10-03 16:46:24 --> Utf8 Class Initialized
INFO - 2024-10-03 16:46:24 --> URI Class Initialized
INFO - 2024-10-03 16:46:24 --> Router Class Initialized
INFO - 2024-10-03 16:46:24 --> Output Class Initialized
INFO - 2024-10-03 16:46:24 --> Security Class Initialized
DEBUG - 2024-10-03 16:46:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-03 16:46:24 --> Input Class Initialized
INFO - 2024-10-03 16:46:24 --> Language Class Initialized
INFO - 2024-10-03 16:46:24 --> Language Class Initialized
INFO - 2024-10-03 16:46:24 --> Config Class Initialized
INFO - 2024-10-03 16:46:24 --> Loader Class Initialized
INFO - 2024-10-03 16:46:24 --> Helper loaded: url_helper
INFO - 2024-10-03 16:46:24 --> Helper loaded: file_helper
INFO - 2024-10-03 16:46:24 --> Helper loaded: form_helper
INFO - 2024-10-03 16:46:24 --> Helper loaded: my_helper
INFO - 2024-10-03 16:46:24 --> Database Driver Class Initialized
INFO - 2024-10-03 16:46:24 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-03 16:46:24 --> Controller Class Initialized
INFO - 2024-10-03 16:46:24 --> Final output sent to browser
DEBUG - 2024-10-03 16:46:24 --> Total execution time: 0.1372
INFO - 2024-10-03 16:46:27 --> Config Class Initialized
INFO - 2024-10-03 16:46:27 --> Hooks Class Initialized
DEBUG - 2024-10-03 16:46:27 --> UTF-8 Support Enabled
INFO - 2024-10-03 16:46:27 --> Utf8 Class Initialized
INFO - 2024-10-03 16:46:27 --> URI Class Initialized
INFO - 2024-10-03 16:46:27 --> Router Class Initialized
INFO - 2024-10-03 16:46:27 --> Output Class Initialized
INFO - 2024-10-03 16:46:27 --> Security Class Initialized
DEBUG - 2024-10-03 16:46:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-03 16:46:27 --> Input Class Initialized
INFO - 2024-10-03 16:46:27 --> Language Class Initialized
INFO - 2024-10-03 16:46:27 --> Language Class Initialized
INFO - 2024-10-03 16:46:27 --> Config Class Initialized
INFO - 2024-10-03 16:46:27 --> Loader Class Initialized
INFO - 2024-10-03 16:46:27 --> Helper loaded: url_helper
INFO - 2024-10-03 16:46:27 --> Helper loaded: file_helper
INFO - 2024-10-03 16:46:27 --> Helper loaded: form_helper
INFO - 2024-10-03 16:46:27 --> Helper loaded: my_helper
INFO - 2024-10-03 16:46:27 --> Database Driver Class Initialized
INFO - 2024-10-03 16:46:27 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-03 16:46:27 --> Controller Class Initialized
INFO - 2024-10-03 16:46:27 --> Final output sent to browser
DEBUG - 2024-10-03 16:46:27 --> Total execution time: 0.0813
INFO - 2024-10-03 16:46:30 --> Config Class Initialized
INFO - 2024-10-03 16:46:30 --> Hooks Class Initialized
DEBUG - 2024-10-03 16:46:30 --> UTF-8 Support Enabled
INFO - 2024-10-03 16:46:30 --> Utf8 Class Initialized
INFO - 2024-10-03 16:46:30 --> URI Class Initialized
INFO - 2024-10-03 16:46:30 --> Router Class Initialized
INFO - 2024-10-03 16:46:30 --> Output Class Initialized
INFO - 2024-10-03 16:46:30 --> Security Class Initialized
DEBUG - 2024-10-03 16:46:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-03 16:46:30 --> Input Class Initialized
INFO - 2024-10-03 16:46:30 --> Language Class Initialized
INFO - 2024-10-03 16:46:30 --> Language Class Initialized
INFO - 2024-10-03 16:46:30 --> Config Class Initialized
INFO - 2024-10-03 16:46:30 --> Loader Class Initialized
INFO - 2024-10-03 16:46:30 --> Helper loaded: url_helper
INFO - 2024-10-03 16:46:30 --> Helper loaded: file_helper
INFO - 2024-10-03 16:46:30 --> Helper loaded: form_helper
INFO - 2024-10-03 16:46:30 --> Helper loaded: my_helper
INFO - 2024-10-03 16:46:30 --> Database Driver Class Initialized
INFO - 2024-10-03 16:46:30 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-03 16:46:30 --> Controller Class Initialized
INFO - 2024-10-03 16:46:30 --> Final output sent to browser
DEBUG - 2024-10-03 16:46:30 --> Total execution time: 0.0401
INFO - 2024-10-03 16:47:49 --> Config Class Initialized
INFO - 2024-10-03 16:47:49 --> Hooks Class Initialized
DEBUG - 2024-10-03 16:47:49 --> UTF-8 Support Enabled
INFO - 2024-10-03 16:47:49 --> Utf8 Class Initialized
INFO - 2024-10-03 16:47:49 --> URI Class Initialized
INFO - 2024-10-03 16:47:49 --> Router Class Initialized
INFO - 2024-10-03 16:47:49 --> Output Class Initialized
INFO - 2024-10-03 16:47:49 --> Security Class Initialized
DEBUG - 2024-10-03 16:47:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-03 16:47:49 --> Input Class Initialized
INFO - 2024-10-03 16:47:49 --> Language Class Initialized
INFO - 2024-10-03 16:47:49 --> Language Class Initialized
INFO - 2024-10-03 16:47:49 --> Config Class Initialized
INFO - 2024-10-03 16:47:49 --> Loader Class Initialized
INFO - 2024-10-03 16:47:49 --> Helper loaded: url_helper
INFO - 2024-10-03 16:47:49 --> Helper loaded: file_helper
INFO - 2024-10-03 16:47:49 --> Helper loaded: form_helper
INFO - 2024-10-03 16:47:49 --> Helper loaded: my_helper
INFO - 2024-10-03 16:47:49 --> Database Driver Class Initialized
INFO - 2024-10-03 16:47:49 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-03 16:47:49 --> Controller Class Initialized
INFO - 2024-10-03 16:47:49 --> Final output sent to browser
DEBUG - 2024-10-03 16:47:49 --> Total execution time: 0.3195
INFO - 2024-10-03 16:48:02 --> Config Class Initialized
INFO - 2024-10-03 16:48:02 --> Hooks Class Initialized
DEBUG - 2024-10-03 16:48:02 --> UTF-8 Support Enabled
INFO - 2024-10-03 16:48:02 --> Utf8 Class Initialized
INFO - 2024-10-03 16:48:02 --> URI Class Initialized
INFO - 2024-10-03 16:48:02 --> Router Class Initialized
INFO - 2024-10-03 16:48:02 --> Output Class Initialized
INFO - 2024-10-03 16:48:02 --> Security Class Initialized
DEBUG - 2024-10-03 16:48:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-03 16:48:02 --> Input Class Initialized
INFO - 2024-10-03 16:48:02 --> Language Class Initialized
INFO - 2024-10-03 16:48:02 --> Language Class Initialized
INFO - 2024-10-03 16:48:02 --> Config Class Initialized
INFO - 2024-10-03 16:48:02 --> Loader Class Initialized
INFO - 2024-10-03 16:48:02 --> Helper loaded: url_helper
INFO - 2024-10-03 16:48:02 --> Helper loaded: file_helper
INFO - 2024-10-03 16:48:02 --> Helper loaded: form_helper
INFO - 2024-10-03 16:48:02 --> Helper loaded: my_helper
INFO - 2024-10-03 16:48:02 --> Database Driver Class Initialized
INFO - 2024-10-03 16:48:02 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-03 16:48:02 --> Controller Class Initialized
INFO - 2024-10-03 16:48:02 --> Final output sent to browser
DEBUG - 2024-10-03 16:48:02 --> Total execution time: 0.0454
INFO - 2024-10-03 16:48:31 --> Config Class Initialized
INFO - 2024-10-03 16:48:31 --> Hooks Class Initialized
DEBUG - 2024-10-03 16:48:31 --> UTF-8 Support Enabled
INFO - 2024-10-03 16:48:31 --> Utf8 Class Initialized
INFO - 2024-10-03 16:48:31 --> URI Class Initialized
INFO - 2024-10-03 16:48:31 --> Router Class Initialized
INFO - 2024-10-03 16:48:31 --> Output Class Initialized
INFO - 2024-10-03 16:48:31 --> Security Class Initialized
DEBUG - 2024-10-03 16:48:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-03 16:48:31 --> Input Class Initialized
INFO - 2024-10-03 16:48:31 --> Language Class Initialized
INFO - 2024-10-03 16:48:31 --> Language Class Initialized
INFO - 2024-10-03 16:48:31 --> Config Class Initialized
INFO - 2024-10-03 16:48:31 --> Loader Class Initialized
INFO - 2024-10-03 16:48:31 --> Helper loaded: url_helper
INFO - 2024-10-03 16:48:31 --> Helper loaded: file_helper
INFO - 2024-10-03 16:48:31 --> Helper loaded: form_helper
INFO - 2024-10-03 16:48:31 --> Helper loaded: my_helper
INFO - 2024-10-03 16:48:31 --> Database Driver Class Initialized
INFO - 2024-10-03 16:48:31 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-03 16:48:31 --> Controller Class Initialized
INFO - 2024-10-03 16:48:31 --> Final output sent to browser
DEBUG - 2024-10-03 16:48:31 --> Total execution time: 0.0738
INFO - 2024-10-03 16:49:24 --> Config Class Initialized
INFO - 2024-10-03 16:49:24 --> Hooks Class Initialized
DEBUG - 2024-10-03 16:49:24 --> UTF-8 Support Enabled
INFO - 2024-10-03 16:49:24 --> Utf8 Class Initialized
INFO - 2024-10-03 16:49:24 --> URI Class Initialized
INFO - 2024-10-03 16:49:24 --> Router Class Initialized
INFO - 2024-10-03 16:49:24 --> Output Class Initialized
INFO - 2024-10-03 16:49:24 --> Security Class Initialized
DEBUG - 2024-10-03 16:49:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-03 16:49:24 --> Input Class Initialized
INFO - 2024-10-03 16:49:24 --> Language Class Initialized
INFO - 2024-10-03 16:49:24 --> Language Class Initialized
INFO - 2024-10-03 16:49:24 --> Config Class Initialized
INFO - 2024-10-03 16:49:24 --> Loader Class Initialized
INFO - 2024-10-03 16:49:24 --> Helper loaded: url_helper
INFO - 2024-10-03 16:49:24 --> Helper loaded: file_helper
INFO - 2024-10-03 16:49:24 --> Helper loaded: form_helper
INFO - 2024-10-03 16:49:24 --> Helper loaded: my_helper
INFO - 2024-10-03 16:49:24 --> Database Driver Class Initialized
INFO - 2024-10-03 16:49:24 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-03 16:49:24 --> Controller Class Initialized
INFO - 2024-10-03 16:49:24 --> Final output sent to browser
DEBUG - 2024-10-03 16:49:24 --> Total execution time: 0.0322
INFO - 2024-10-03 16:50:17 --> Config Class Initialized
INFO - 2024-10-03 16:50:17 --> Hooks Class Initialized
DEBUG - 2024-10-03 16:50:17 --> UTF-8 Support Enabled
INFO - 2024-10-03 16:50:17 --> Utf8 Class Initialized
INFO - 2024-10-03 16:50:17 --> URI Class Initialized
INFO - 2024-10-03 16:50:17 --> Router Class Initialized
INFO - 2024-10-03 16:50:17 --> Output Class Initialized
INFO - 2024-10-03 16:50:17 --> Security Class Initialized
DEBUG - 2024-10-03 16:50:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-03 16:50:17 --> Input Class Initialized
INFO - 2024-10-03 16:50:17 --> Language Class Initialized
INFO - 2024-10-03 16:50:17 --> Language Class Initialized
INFO - 2024-10-03 16:50:17 --> Config Class Initialized
INFO - 2024-10-03 16:50:17 --> Loader Class Initialized
INFO - 2024-10-03 16:50:17 --> Helper loaded: url_helper
INFO - 2024-10-03 16:50:17 --> Helper loaded: file_helper
INFO - 2024-10-03 16:50:17 --> Helper loaded: form_helper
INFO - 2024-10-03 16:50:17 --> Helper loaded: my_helper
INFO - 2024-10-03 16:50:17 --> Database Driver Class Initialized
INFO - 2024-10-03 16:50:17 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-03 16:50:17 --> Controller Class Initialized
INFO - 2024-10-03 16:50:17 --> Final output sent to browser
DEBUG - 2024-10-03 16:50:17 --> Total execution time: 0.0664
INFO - 2024-10-03 16:59:38 --> Config Class Initialized
INFO - 2024-10-03 16:59:38 --> Hooks Class Initialized
DEBUG - 2024-10-03 16:59:38 --> UTF-8 Support Enabled
INFO - 2024-10-03 16:59:38 --> Utf8 Class Initialized
INFO - 2024-10-03 16:59:38 --> URI Class Initialized
INFO - 2024-10-03 16:59:38 --> Router Class Initialized
INFO - 2024-10-03 16:59:38 --> Output Class Initialized
INFO - 2024-10-03 16:59:38 --> Security Class Initialized
DEBUG - 2024-10-03 16:59:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-03 16:59:38 --> Input Class Initialized
INFO - 2024-10-03 16:59:38 --> Language Class Initialized
INFO - 2024-10-03 16:59:38 --> Language Class Initialized
INFO - 2024-10-03 16:59:38 --> Config Class Initialized
INFO - 2024-10-03 16:59:38 --> Loader Class Initialized
INFO - 2024-10-03 16:59:38 --> Helper loaded: url_helper
INFO - 2024-10-03 16:59:38 --> Helper loaded: file_helper
INFO - 2024-10-03 16:59:38 --> Helper loaded: form_helper
INFO - 2024-10-03 16:59:38 --> Helper loaded: my_helper
INFO - 2024-10-03 16:59:38 --> Database Driver Class Initialized
INFO - 2024-10-03 16:59:38 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-03 16:59:38 --> Controller Class Initialized
INFO - 2024-10-03 16:59:38 --> Final output sent to browser
DEBUG - 2024-10-03 16:59:38 --> Total execution time: 0.0498
INFO - 2024-10-03 16:59:49 --> Config Class Initialized
INFO - 2024-10-03 16:59:49 --> Hooks Class Initialized
DEBUG - 2024-10-03 16:59:49 --> UTF-8 Support Enabled
INFO - 2024-10-03 16:59:49 --> Utf8 Class Initialized
INFO - 2024-10-03 16:59:49 --> URI Class Initialized
INFO - 2024-10-03 16:59:49 --> Router Class Initialized
INFO - 2024-10-03 16:59:49 --> Output Class Initialized
INFO - 2024-10-03 16:59:49 --> Security Class Initialized
DEBUG - 2024-10-03 16:59:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-03 16:59:49 --> Input Class Initialized
INFO - 2024-10-03 16:59:49 --> Language Class Initialized
INFO - 2024-10-03 16:59:49 --> Language Class Initialized
INFO - 2024-10-03 16:59:49 --> Config Class Initialized
INFO - 2024-10-03 16:59:49 --> Loader Class Initialized
INFO - 2024-10-03 16:59:49 --> Helper loaded: url_helper
INFO - 2024-10-03 16:59:49 --> Helper loaded: file_helper
INFO - 2024-10-03 16:59:49 --> Helper loaded: form_helper
INFO - 2024-10-03 16:59:49 --> Helper loaded: my_helper
INFO - 2024-10-03 16:59:49 --> Database Driver Class Initialized
INFO - 2024-10-03 16:59:49 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-03 16:59:49 --> Controller Class Initialized
INFO - 2024-10-03 16:59:49 --> Final output sent to browser
DEBUG - 2024-10-03 16:59:49 --> Total execution time: 0.0996
INFO - 2024-10-03 16:59:51 --> Config Class Initialized
INFO - 2024-10-03 16:59:51 --> Hooks Class Initialized
DEBUG - 2024-10-03 16:59:51 --> UTF-8 Support Enabled
INFO - 2024-10-03 16:59:51 --> Utf8 Class Initialized
INFO - 2024-10-03 16:59:51 --> URI Class Initialized
INFO - 2024-10-03 16:59:51 --> Router Class Initialized
INFO - 2024-10-03 16:59:51 --> Output Class Initialized
INFO - 2024-10-03 16:59:51 --> Security Class Initialized
DEBUG - 2024-10-03 16:59:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-03 16:59:51 --> Input Class Initialized
INFO - 2024-10-03 16:59:51 --> Language Class Initialized
INFO - 2024-10-03 16:59:51 --> Language Class Initialized
INFO - 2024-10-03 16:59:51 --> Config Class Initialized
INFO - 2024-10-03 16:59:51 --> Loader Class Initialized
INFO - 2024-10-03 16:59:51 --> Helper loaded: url_helper
INFO - 2024-10-03 16:59:51 --> Helper loaded: file_helper
INFO - 2024-10-03 16:59:51 --> Helper loaded: form_helper
INFO - 2024-10-03 16:59:51 --> Helper loaded: my_helper
INFO - 2024-10-03 16:59:51 --> Database Driver Class Initialized
INFO - 2024-10-03 16:59:51 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-03 16:59:51 --> Controller Class Initialized
INFO - 2024-10-03 16:59:51 --> Final output sent to browser
DEBUG - 2024-10-03 16:59:51 --> Total execution time: 0.0372
INFO - 2024-10-03 17:00:54 --> Config Class Initialized
INFO - 2024-10-03 17:00:54 --> Hooks Class Initialized
DEBUG - 2024-10-03 17:00:54 --> UTF-8 Support Enabled
INFO - 2024-10-03 17:00:54 --> Utf8 Class Initialized
INFO - 2024-10-03 17:00:54 --> URI Class Initialized
INFO - 2024-10-03 17:00:54 --> Router Class Initialized
INFO - 2024-10-03 17:00:54 --> Output Class Initialized
INFO - 2024-10-03 17:00:54 --> Security Class Initialized
DEBUG - 2024-10-03 17:00:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-03 17:00:54 --> Input Class Initialized
INFO - 2024-10-03 17:00:54 --> Language Class Initialized
INFO - 2024-10-03 17:00:54 --> Language Class Initialized
INFO - 2024-10-03 17:00:54 --> Config Class Initialized
INFO - 2024-10-03 17:00:54 --> Loader Class Initialized
INFO - 2024-10-03 17:00:54 --> Helper loaded: url_helper
INFO - 2024-10-03 17:00:54 --> Helper loaded: file_helper
INFO - 2024-10-03 17:00:54 --> Helper loaded: form_helper
INFO - 2024-10-03 17:00:54 --> Helper loaded: my_helper
INFO - 2024-10-03 17:00:54 --> Database Driver Class Initialized
INFO - 2024-10-03 17:00:54 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-03 17:00:54 --> Controller Class Initialized
INFO - 2024-10-03 17:00:54 --> Config Class Initialized
INFO - 2024-10-03 17:00:54 --> Hooks Class Initialized
DEBUG - 2024-10-03 17:00:54 --> UTF-8 Support Enabled
INFO - 2024-10-03 17:00:54 --> Utf8 Class Initialized
INFO - 2024-10-03 17:00:54 --> URI Class Initialized
INFO - 2024-10-03 17:00:54 --> Router Class Initialized
INFO - 2024-10-03 17:00:54 --> Output Class Initialized
INFO - 2024-10-03 17:00:54 --> Security Class Initialized
DEBUG - 2024-10-03 17:00:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-03 17:00:54 --> Input Class Initialized
INFO - 2024-10-03 17:00:54 --> Language Class Initialized
INFO - 2024-10-03 17:00:54 --> Language Class Initialized
INFO - 2024-10-03 17:00:54 --> Config Class Initialized
INFO - 2024-10-03 17:00:54 --> Loader Class Initialized
INFO - 2024-10-03 17:00:54 --> Helper loaded: url_helper
INFO - 2024-10-03 17:00:54 --> Helper loaded: file_helper
INFO - 2024-10-03 17:00:54 --> Helper loaded: form_helper
INFO - 2024-10-03 17:00:54 --> Helper loaded: my_helper
INFO - 2024-10-03 17:00:54 --> Database Driver Class Initialized
INFO - 2024-10-03 17:00:54 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-03 17:00:54 --> Controller Class Initialized
DEBUG - 2024-10-03 17:00:54 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/login/views/login.php
DEBUG - 2024-10-03 17:00:54 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-10-03 17:00:54 --> Final output sent to browser
DEBUG - 2024-10-03 17:00:54 --> Total execution time: 0.0401
INFO - 2024-10-03 17:01:01 --> Config Class Initialized
INFO - 2024-10-03 17:01:01 --> Hooks Class Initialized
DEBUG - 2024-10-03 17:01:01 --> UTF-8 Support Enabled
INFO - 2024-10-03 17:01:01 --> Utf8 Class Initialized
INFO - 2024-10-03 17:01:01 --> URI Class Initialized
INFO - 2024-10-03 17:01:01 --> Router Class Initialized
INFO - 2024-10-03 17:01:01 --> Output Class Initialized
INFO - 2024-10-03 17:01:01 --> Security Class Initialized
DEBUG - 2024-10-03 17:01:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-03 17:01:01 --> Input Class Initialized
INFO - 2024-10-03 17:01:01 --> Language Class Initialized
INFO - 2024-10-03 17:01:01 --> Language Class Initialized
INFO - 2024-10-03 17:01:01 --> Config Class Initialized
INFO - 2024-10-03 17:01:01 --> Loader Class Initialized
INFO - 2024-10-03 17:01:01 --> Helper loaded: url_helper
INFO - 2024-10-03 17:01:01 --> Helper loaded: file_helper
INFO - 2024-10-03 17:01:01 --> Helper loaded: form_helper
INFO - 2024-10-03 17:01:01 --> Helper loaded: my_helper
INFO - 2024-10-03 17:01:01 --> Database Driver Class Initialized
INFO - 2024-10-03 17:01:01 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-03 17:01:01 --> Controller Class Initialized
INFO - 2024-10-03 17:01:01 --> Helper loaded: cookie_helper
INFO - 2024-10-03 17:01:01 --> Final output sent to browser
DEBUG - 2024-10-03 17:01:01 --> Total execution time: 0.0712
INFO - 2024-10-03 17:01:01 --> Config Class Initialized
INFO - 2024-10-03 17:01:01 --> Hooks Class Initialized
DEBUG - 2024-10-03 17:01:01 --> UTF-8 Support Enabled
INFO - 2024-10-03 17:01:01 --> Utf8 Class Initialized
INFO - 2024-10-03 17:01:01 --> URI Class Initialized
INFO - 2024-10-03 17:01:01 --> Router Class Initialized
INFO - 2024-10-03 17:01:01 --> Output Class Initialized
INFO - 2024-10-03 17:01:01 --> Security Class Initialized
DEBUG - 2024-10-03 17:01:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-03 17:01:01 --> Input Class Initialized
INFO - 2024-10-03 17:01:01 --> Language Class Initialized
INFO - 2024-10-03 17:01:01 --> Language Class Initialized
INFO - 2024-10-03 17:01:01 --> Config Class Initialized
INFO - 2024-10-03 17:01:01 --> Loader Class Initialized
INFO - 2024-10-03 17:01:01 --> Helper loaded: url_helper
INFO - 2024-10-03 17:01:01 --> Helper loaded: file_helper
INFO - 2024-10-03 17:01:01 --> Helper loaded: form_helper
INFO - 2024-10-03 17:01:01 --> Helper loaded: my_helper
INFO - 2024-10-03 17:01:01 --> Database Driver Class Initialized
INFO - 2024-10-03 17:01:01 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-03 17:01:01 --> Controller Class Initialized
DEBUG - 2024-10-03 17:01:01 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/home/views/v_home_guru.php
DEBUG - 2024-10-03 17:01:01 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-10-03 17:01:01 --> Final output sent to browser
DEBUG - 2024-10-03 17:01:01 --> Total execution time: 0.0455
INFO - 2024-10-03 17:01:04 --> Config Class Initialized
INFO - 2024-10-03 17:01:04 --> Hooks Class Initialized
DEBUG - 2024-10-03 17:01:04 --> UTF-8 Support Enabled
INFO - 2024-10-03 17:01:04 --> Utf8 Class Initialized
INFO - 2024-10-03 17:01:04 --> URI Class Initialized
INFO - 2024-10-03 17:01:04 --> Router Class Initialized
INFO - 2024-10-03 17:01:04 --> Output Class Initialized
INFO - 2024-10-03 17:01:04 --> Security Class Initialized
DEBUG - 2024-10-03 17:01:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-03 17:01:04 --> Input Class Initialized
INFO - 2024-10-03 17:01:04 --> Language Class Initialized
INFO - 2024-10-03 17:01:04 --> Language Class Initialized
INFO - 2024-10-03 17:01:04 --> Config Class Initialized
INFO - 2024-10-03 17:01:04 --> Loader Class Initialized
INFO - 2024-10-03 17:01:04 --> Helper loaded: url_helper
INFO - 2024-10-03 17:01:04 --> Helper loaded: file_helper
INFO - 2024-10-03 17:01:04 --> Helper loaded: form_helper
INFO - 2024-10-03 17:01:04 --> Helper loaded: my_helper
INFO - 2024-10-03 17:01:04 --> Database Driver Class Initialized
INFO - 2024-10-03 17:01:04 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-03 17:01:04 --> Controller Class Initialized
DEBUG - 2024-10-03 17:01:04 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/view_mapel/views/v_view_mapel.php
DEBUG - 2024-10-03 17:01:04 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-10-03 17:01:04 --> Final output sent to browser
DEBUG - 2024-10-03 17:01:04 --> Total execution time: 0.0377
INFO - 2024-10-03 17:01:08 --> Config Class Initialized
INFO - 2024-10-03 17:01:08 --> Hooks Class Initialized
DEBUG - 2024-10-03 17:01:08 --> UTF-8 Support Enabled
INFO - 2024-10-03 17:01:08 --> Utf8 Class Initialized
INFO - 2024-10-03 17:01:08 --> URI Class Initialized
INFO - 2024-10-03 17:01:08 --> Router Class Initialized
INFO - 2024-10-03 17:01:08 --> Output Class Initialized
INFO - 2024-10-03 17:01:08 --> Security Class Initialized
DEBUG - 2024-10-03 17:01:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-03 17:01:08 --> Input Class Initialized
INFO - 2024-10-03 17:01:08 --> Language Class Initialized
INFO - 2024-10-03 17:01:08 --> Language Class Initialized
INFO - 2024-10-03 17:01:08 --> Config Class Initialized
INFO - 2024-10-03 17:01:08 --> Loader Class Initialized
INFO - 2024-10-03 17:01:08 --> Helper loaded: url_helper
INFO - 2024-10-03 17:01:08 --> Helper loaded: file_helper
INFO - 2024-10-03 17:01:08 --> Helper loaded: form_helper
INFO - 2024-10-03 17:01:08 --> Helper loaded: my_helper
INFO - 2024-10-03 17:01:08 --> Database Driver Class Initialized
INFO - 2024-10-03 17:01:08 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-03 17:01:08 --> Controller Class Initialized
DEBUG - 2024-10-03 17:01:08 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_la/views/list.php
DEBUG - 2024-10-03 17:01:08 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-10-03 17:01:08 --> Final output sent to browser
DEBUG - 2024-10-03 17:01:08 --> Total execution time: 0.0427
INFO - 2024-10-03 17:01:08 --> Config Class Initialized
INFO - 2024-10-03 17:01:08 --> Hooks Class Initialized
DEBUG - 2024-10-03 17:01:08 --> UTF-8 Support Enabled
INFO - 2024-10-03 17:01:08 --> Utf8 Class Initialized
INFO - 2024-10-03 17:01:08 --> URI Class Initialized
INFO - 2024-10-03 17:01:08 --> Router Class Initialized
INFO - 2024-10-03 17:01:08 --> Output Class Initialized
INFO - 2024-10-03 17:01:08 --> Security Class Initialized
DEBUG - 2024-10-03 17:01:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-03 17:01:08 --> Input Class Initialized
INFO - 2024-10-03 17:01:08 --> Language Class Initialized
INFO - 2024-10-03 17:01:08 --> Language Class Initialized
INFO - 2024-10-03 17:01:08 --> Config Class Initialized
INFO - 2024-10-03 17:01:08 --> Loader Class Initialized
INFO - 2024-10-03 17:01:08 --> Helper loaded: url_helper
INFO - 2024-10-03 17:01:08 --> Helper loaded: file_helper
INFO - 2024-10-03 17:01:08 --> Helper loaded: form_helper
INFO - 2024-10-03 17:01:08 --> Helper loaded: my_helper
INFO - 2024-10-03 17:01:08 --> Database Driver Class Initialized
INFO - 2024-10-03 17:01:08 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-03 17:01:08 --> Controller Class Initialized
INFO - 2024-10-03 17:01:10 --> Config Class Initialized
INFO - 2024-10-03 17:01:10 --> Hooks Class Initialized
DEBUG - 2024-10-03 17:01:10 --> UTF-8 Support Enabled
INFO - 2024-10-03 17:01:10 --> Utf8 Class Initialized
INFO - 2024-10-03 17:01:10 --> URI Class Initialized
INFO - 2024-10-03 17:01:10 --> Router Class Initialized
INFO - 2024-10-03 17:01:10 --> Output Class Initialized
INFO - 2024-10-03 17:01:10 --> Security Class Initialized
DEBUG - 2024-10-03 17:01:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-03 17:01:10 --> Input Class Initialized
INFO - 2024-10-03 17:01:10 --> Language Class Initialized
INFO - 2024-10-03 17:01:10 --> Language Class Initialized
INFO - 2024-10-03 17:01:10 --> Config Class Initialized
INFO - 2024-10-03 17:01:10 --> Loader Class Initialized
INFO - 2024-10-03 17:01:10 --> Helper loaded: url_helper
INFO - 2024-10-03 17:01:10 --> Helper loaded: file_helper
INFO - 2024-10-03 17:01:10 --> Helper loaded: form_helper
INFO - 2024-10-03 17:01:10 --> Helper loaded: my_helper
INFO - 2024-10-03 17:01:10 --> Database Driver Class Initialized
INFO - 2024-10-03 17:01:10 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-03 17:01:10 --> Controller Class Initialized
INFO - 2024-10-03 17:01:10 --> Final output sent to browser
DEBUG - 2024-10-03 17:01:10 --> Total execution time: 0.2045
INFO - 2024-10-03 17:01:25 --> Config Class Initialized
INFO - 2024-10-03 17:01:25 --> Hooks Class Initialized
DEBUG - 2024-10-03 17:01:25 --> UTF-8 Support Enabled
INFO - 2024-10-03 17:01:25 --> Utf8 Class Initialized
INFO - 2024-10-03 17:01:25 --> URI Class Initialized
INFO - 2024-10-03 17:01:25 --> Router Class Initialized
INFO - 2024-10-03 17:01:25 --> Output Class Initialized
INFO - 2024-10-03 17:01:25 --> Security Class Initialized
DEBUG - 2024-10-03 17:01:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-03 17:01:25 --> Input Class Initialized
INFO - 2024-10-03 17:01:25 --> Language Class Initialized
INFO - 2024-10-03 17:01:25 --> Language Class Initialized
INFO - 2024-10-03 17:01:25 --> Config Class Initialized
INFO - 2024-10-03 17:01:25 --> Loader Class Initialized
INFO - 2024-10-03 17:01:25 --> Helper loaded: url_helper
INFO - 2024-10-03 17:01:25 --> Helper loaded: file_helper
INFO - 2024-10-03 17:01:25 --> Helper loaded: form_helper
INFO - 2024-10-03 17:01:25 --> Helper loaded: my_helper
INFO - 2024-10-03 17:01:25 --> Database Driver Class Initialized
INFO - 2024-10-03 17:01:25 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-03 17:01:25 --> Controller Class Initialized
INFO - 2024-10-03 17:01:25 --> Final output sent to browser
DEBUG - 2024-10-03 17:01:25 --> Total execution time: 0.0824
INFO - 2024-10-03 17:02:06 --> Config Class Initialized
INFO - 2024-10-03 17:02:06 --> Hooks Class Initialized
DEBUG - 2024-10-03 17:02:06 --> UTF-8 Support Enabled
INFO - 2024-10-03 17:02:06 --> Utf8 Class Initialized
INFO - 2024-10-03 17:02:06 --> URI Class Initialized
INFO - 2024-10-03 17:02:06 --> Router Class Initialized
INFO - 2024-10-03 17:02:06 --> Output Class Initialized
INFO - 2024-10-03 17:02:06 --> Security Class Initialized
DEBUG - 2024-10-03 17:02:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-03 17:02:06 --> Input Class Initialized
INFO - 2024-10-03 17:02:06 --> Language Class Initialized
INFO - 2024-10-03 17:02:06 --> Language Class Initialized
INFO - 2024-10-03 17:02:06 --> Config Class Initialized
INFO - 2024-10-03 17:02:06 --> Loader Class Initialized
INFO - 2024-10-03 17:02:06 --> Helper loaded: url_helper
INFO - 2024-10-03 17:02:06 --> Helper loaded: file_helper
INFO - 2024-10-03 17:02:06 --> Helper loaded: form_helper
INFO - 2024-10-03 17:02:06 --> Helper loaded: my_helper
INFO - 2024-10-03 17:02:06 --> Database Driver Class Initialized
INFO - 2024-10-03 17:02:06 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-03 17:02:06 --> Controller Class Initialized
INFO - 2024-10-03 17:02:06 --> Final output sent to browser
DEBUG - 2024-10-03 17:02:06 --> Total execution time: 0.0386
INFO - 2024-10-03 17:02:45 --> Config Class Initialized
INFO - 2024-10-03 17:02:45 --> Hooks Class Initialized
DEBUG - 2024-10-03 17:02:45 --> UTF-8 Support Enabled
INFO - 2024-10-03 17:02:45 --> Utf8 Class Initialized
INFO - 2024-10-03 17:02:45 --> URI Class Initialized
INFO - 2024-10-03 17:02:45 --> Router Class Initialized
INFO - 2024-10-03 17:02:45 --> Output Class Initialized
INFO - 2024-10-03 17:02:45 --> Security Class Initialized
DEBUG - 2024-10-03 17:02:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-03 17:02:45 --> Input Class Initialized
INFO - 2024-10-03 17:02:45 --> Language Class Initialized
INFO - 2024-10-03 17:02:45 --> Language Class Initialized
INFO - 2024-10-03 17:02:45 --> Config Class Initialized
INFO - 2024-10-03 17:02:45 --> Loader Class Initialized
INFO - 2024-10-03 17:02:45 --> Helper loaded: url_helper
INFO - 2024-10-03 17:02:45 --> Helper loaded: file_helper
INFO - 2024-10-03 17:02:45 --> Helper loaded: form_helper
INFO - 2024-10-03 17:02:45 --> Helper loaded: my_helper
INFO - 2024-10-03 17:02:45 --> Database Driver Class Initialized
INFO - 2024-10-03 17:02:45 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-03 17:02:45 --> Controller Class Initialized
INFO - 2024-10-03 17:02:45 --> Final output sent to browser
DEBUG - 2024-10-03 17:02:45 --> Total execution time: 0.0859
INFO - 2024-10-03 17:02:49 --> Config Class Initialized
INFO - 2024-10-03 17:02:49 --> Hooks Class Initialized
DEBUG - 2024-10-03 17:02:49 --> UTF-8 Support Enabled
INFO - 2024-10-03 17:02:49 --> Utf8 Class Initialized
INFO - 2024-10-03 17:02:49 --> URI Class Initialized
INFO - 2024-10-03 17:02:49 --> Router Class Initialized
INFO - 2024-10-03 17:02:49 --> Output Class Initialized
INFO - 2024-10-03 17:02:49 --> Security Class Initialized
DEBUG - 2024-10-03 17:02:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-03 17:02:49 --> Input Class Initialized
INFO - 2024-10-03 17:02:49 --> Language Class Initialized
INFO - 2024-10-03 17:02:49 --> Language Class Initialized
INFO - 2024-10-03 17:02:49 --> Config Class Initialized
INFO - 2024-10-03 17:02:49 --> Loader Class Initialized
INFO - 2024-10-03 17:02:49 --> Helper loaded: url_helper
INFO - 2024-10-03 17:02:49 --> Helper loaded: file_helper
INFO - 2024-10-03 17:02:49 --> Helper loaded: form_helper
INFO - 2024-10-03 17:02:49 --> Helper loaded: my_helper
INFO - 2024-10-03 17:02:49 --> Database Driver Class Initialized
INFO - 2024-10-03 17:02:49 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-03 17:02:49 --> Controller Class Initialized
INFO - 2024-10-03 17:02:49 --> Final output sent to browser
DEBUG - 2024-10-03 17:02:49 --> Total execution time: 0.0368
INFO - 2024-10-03 17:11:38 --> Config Class Initialized
INFO - 2024-10-03 17:11:38 --> Hooks Class Initialized
DEBUG - 2024-10-03 17:11:38 --> UTF-8 Support Enabled
INFO - 2024-10-03 17:11:38 --> Utf8 Class Initialized
INFO - 2024-10-03 17:11:38 --> URI Class Initialized
INFO - 2024-10-03 17:11:38 --> Router Class Initialized
INFO - 2024-10-03 17:11:38 --> Output Class Initialized
INFO - 2024-10-03 17:11:38 --> Security Class Initialized
DEBUG - 2024-10-03 17:11:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-03 17:11:38 --> Input Class Initialized
INFO - 2024-10-03 17:11:38 --> Language Class Initialized
INFO - 2024-10-03 17:11:38 --> Language Class Initialized
INFO - 2024-10-03 17:11:38 --> Config Class Initialized
INFO - 2024-10-03 17:11:38 --> Loader Class Initialized
INFO - 2024-10-03 17:11:38 --> Helper loaded: url_helper
INFO - 2024-10-03 17:11:38 --> Helper loaded: file_helper
INFO - 2024-10-03 17:11:38 --> Helper loaded: form_helper
INFO - 2024-10-03 17:11:38 --> Helper loaded: my_helper
INFO - 2024-10-03 17:11:38 --> Database Driver Class Initialized
INFO - 2024-10-03 17:11:38 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-03 17:11:38 --> Controller Class Initialized
INFO - 2024-10-03 17:11:38 --> Config Class Initialized
INFO - 2024-10-03 17:11:38 --> Hooks Class Initialized
DEBUG - 2024-10-03 17:11:38 --> UTF-8 Support Enabled
INFO - 2024-10-03 17:11:38 --> Utf8 Class Initialized
INFO - 2024-10-03 17:11:38 --> URI Class Initialized
INFO - 2024-10-03 17:11:38 --> Router Class Initialized
INFO - 2024-10-03 17:11:38 --> Output Class Initialized
INFO - 2024-10-03 17:11:38 --> Security Class Initialized
DEBUG - 2024-10-03 17:11:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-03 17:11:38 --> Input Class Initialized
INFO - 2024-10-03 17:11:38 --> Language Class Initialized
INFO - 2024-10-03 17:11:38 --> Language Class Initialized
INFO - 2024-10-03 17:11:38 --> Config Class Initialized
INFO - 2024-10-03 17:11:38 --> Loader Class Initialized
INFO - 2024-10-03 17:11:38 --> Helper loaded: url_helper
INFO - 2024-10-03 17:11:38 --> Helper loaded: file_helper
INFO - 2024-10-03 17:11:38 --> Helper loaded: form_helper
INFO - 2024-10-03 17:11:38 --> Helper loaded: my_helper
INFO - 2024-10-03 17:11:38 --> Database Driver Class Initialized
INFO - 2024-10-03 17:11:38 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-03 17:11:38 --> Controller Class Initialized
DEBUG - 2024-10-03 17:11:38 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/login/views/login.php
DEBUG - 2024-10-03 17:11:38 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-10-03 17:11:38 --> Final output sent to browser
DEBUG - 2024-10-03 17:11:38 --> Total execution time: 0.0317
INFO - 2024-10-03 17:11:40 --> Config Class Initialized
INFO - 2024-10-03 17:11:40 --> Hooks Class Initialized
DEBUG - 2024-10-03 17:11:40 --> UTF-8 Support Enabled
INFO - 2024-10-03 17:11:40 --> Utf8 Class Initialized
INFO - 2024-10-03 17:11:40 --> URI Class Initialized
INFO - 2024-10-03 17:11:40 --> Router Class Initialized
INFO - 2024-10-03 17:11:40 --> Output Class Initialized
INFO - 2024-10-03 17:11:40 --> Security Class Initialized
DEBUG - 2024-10-03 17:11:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-03 17:11:40 --> Input Class Initialized
INFO - 2024-10-03 17:11:40 --> Language Class Initialized
INFO - 2024-10-03 17:11:40 --> Language Class Initialized
INFO - 2024-10-03 17:11:40 --> Config Class Initialized
INFO - 2024-10-03 17:11:40 --> Loader Class Initialized
INFO - 2024-10-03 17:11:40 --> Helper loaded: url_helper
INFO - 2024-10-03 17:11:40 --> Helper loaded: file_helper
INFO - 2024-10-03 17:11:40 --> Helper loaded: form_helper
INFO - 2024-10-03 17:11:40 --> Helper loaded: my_helper
INFO - 2024-10-03 17:11:40 --> Database Driver Class Initialized
INFO - 2024-10-03 17:11:40 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-03 17:11:40 --> Controller Class Initialized
INFO - 2024-10-03 17:11:40 --> Helper loaded: cookie_helper
INFO - 2024-10-03 17:11:40 --> Final output sent to browser
DEBUG - 2024-10-03 17:11:40 --> Total execution time: 0.0357
INFO - 2024-10-03 17:11:41 --> Config Class Initialized
INFO - 2024-10-03 17:11:41 --> Hooks Class Initialized
DEBUG - 2024-10-03 17:11:41 --> UTF-8 Support Enabled
INFO - 2024-10-03 17:11:41 --> Utf8 Class Initialized
INFO - 2024-10-03 17:11:41 --> URI Class Initialized
INFO - 2024-10-03 17:11:41 --> Router Class Initialized
INFO - 2024-10-03 17:11:41 --> Output Class Initialized
INFO - 2024-10-03 17:11:41 --> Security Class Initialized
DEBUG - 2024-10-03 17:11:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-03 17:11:41 --> Input Class Initialized
INFO - 2024-10-03 17:11:41 --> Language Class Initialized
INFO - 2024-10-03 17:11:41 --> Language Class Initialized
INFO - 2024-10-03 17:11:41 --> Config Class Initialized
INFO - 2024-10-03 17:11:41 --> Loader Class Initialized
INFO - 2024-10-03 17:11:41 --> Helper loaded: url_helper
INFO - 2024-10-03 17:11:41 --> Helper loaded: file_helper
INFO - 2024-10-03 17:11:41 --> Helper loaded: form_helper
INFO - 2024-10-03 17:11:41 --> Helper loaded: my_helper
INFO - 2024-10-03 17:11:41 --> Database Driver Class Initialized
INFO - 2024-10-03 17:11:41 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-03 17:11:41 --> Controller Class Initialized
DEBUG - 2024-10-03 17:11:41 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/home/views/v_home_guru.php
DEBUG - 2024-10-03 17:11:41 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-10-03 17:11:41 --> Final output sent to browser
DEBUG - 2024-10-03 17:11:41 --> Total execution time: 0.0394
INFO - 2024-10-03 17:11:44 --> Config Class Initialized
INFO - 2024-10-03 17:11:44 --> Hooks Class Initialized
DEBUG - 2024-10-03 17:11:44 --> UTF-8 Support Enabled
INFO - 2024-10-03 17:11:44 --> Utf8 Class Initialized
INFO - 2024-10-03 17:11:44 --> URI Class Initialized
INFO - 2024-10-03 17:11:44 --> Router Class Initialized
INFO - 2024-10-03 17:11:44 --> Output Class Initialized
INFO - 2024-10-03 17:11:44 --> Security Class Initialized
DEBUG - 2024-10-03 17:11:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-03 17:11:44 --> Input Class Initialized
INFO - 2024-10-03 17:11:44 --> Language Class Initialized
INFO - 2024-10-03 17:11:44 --> Language Class Initialized
INFO - 2024-10-03 17:11:44 --> Config Class Initialized
INFO - 2024-10-03 17:11:44 --> Loader Class Initialized
INFO - 2024-10-03 17:11:44 --> Helper loaded: url_helper
INFO - 2024-10-03 17:11:44 --> Helper loaded: file_helper
INFO - 2024-10-03 17:11:44 --> Helper loaded: form_helper
INFO - 2024-10-03 17:11:44 --> Helper loaded: my_helper
INFO - 2024-10-03 17:11:44 --> Database Driver Class Initialized
INFO - 2024-10-03 17:11:44 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-03 17:11:44 --> Controller Class Initialized
INFO - 2024-10-03 17:11:44 --> Final output sent to browser
DEBUG - 2024-10-03 17:11:44 --> Total execution time: 0.0667
INFO - 2024-10-03 17:11:45 --> Config Class Initialized
INFO - 2024-10-03 17:11:45 --> Hooks Class Initialized
DEBUG - 2024-10-03 17:11:45 --> UTF-8 Support Enabled
INFO - 2024-10-03 17:11:45 --> Utf8 Class Initialized
INFO - 2024-10-03 17:11:45 --> URI Class Initialized
INFO - 2024-10-03 17:11:45 --> Router Class Initialized
INFO - 2024-10-03 17:11:45 --> Output Class Initialized
INFO - 2024-10-03 17:11:45 --> Security Class Initialized
DEBUG - 2024-10-03 17:11:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-03 17:11:45 --> Input Class Initialized
INFO - 2024-10-03 17:11:45 --> Language Class Initialized
INFO - 2024-10-03 17:11:45 --> Language Class Initialized
INFO - 2024-10-03 17:11:45 --> Config Class Initialized
INFO - 2024-10-03 17:11:45 --> Loader Class Initialized
INFO - 2024-10-03 17:11:45 --> Helper loaded: url_helper
INFO - 2024-10-03 17:11:45 --> Helper loaded: file_helper
INFO - 2024-10-03 17:11:45 --> Helper loaded: form_helper
INFO - 2024-10-03 17:11:45 --> Helper loaded: my_helper
INFO - 2024-10-03 17:11:45 --> Database Driver Class Initialized
INFO - 2024-10-03 17:11:45 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-03 17:11:45 --> Controller Class Initialized
DEBUG - 2024-10-03 17:11:45 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/view_mapel/views/v_view_mapel.php
DEBUG - 2024-10-03 17:11:45 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-10-03 17:11:45 --> Final output sent to browser
DEBUG - 2024-10-03 17:11:45 --> Total execution time: 0.0314
INFO - 2024-10-03 17:11:51 --> Config Class Initialized
INFO - 2024-10-03 17:11:51 --> Hooks Class Initialized
DEBUG - 2024-10-03 17:11:51 --> UTF-8 Support Enabled
INFO - 2024-10-03 17:11:51 --> Utf8 Class Initialized
INFO - 2024-10-03 17:11:51 --> URI Class Initialized
INFO - 2024-10-03 17:11:51 --> Router Class Initialized
INFO - 2024-10-03 17:11:51 --> Output Class Initialized
INFO - 2024-10-03 17:11:51 --> Security Class Initialized
DEBUG - 2024-10-03 17:11:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-03 17:11:51 --> Input Class Initialized
INFO - 2024-10-03 17:11:51 --> Language Class Initialized
INFO - 2024-10-03 17:11:51 --> Language Class Initialized
INFO - 2024-10-03 17:11:51 --> Config Class Initialized
INFO - 2024-10-03 17:11:51 --> Loader Class Initialized
INFO - 2024-10-03 17:11:51 --> Helper loaded: url_helper
INFO - 2024-10-03 17:11:51 --> Helper loaded: file_helper
INFO - 2024-10-03 17:11:51 --> Helper loaded: form_helper
INFO - 2024-10-03 17:11:51 --> Helper loaded: my_helper
INFO - 2024-10-03 17:11:51 --> Database Driver Class Initialized
INFO - 2024-10-03 17:11:51 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-03 17:11:51 --> Controller Class Initialized
DEBUG - 2024-10-03 17:11:51 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/views/list.php
DEBUG - 2024-10-03 17:11:51 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-10-03 17:11:51 --> Final output sent to browser
DEBUG - 2024-10-03 17:11:51 --> Total execution time: 0.1032
INFO - 2024-10-03 17:11:51 --> Config Class Initialized
INFO - 2024-10-03 17:11:51 --> Hooks Class Initialized
DEBUG - 2024-10-03 17:11:51 --> UTF-8 Support Enabled
INFO - 2024-10-03 17:11:51 --> Utf8 Class Initialized
INFO - 2024-10-03 17:11:51 --> URI Class Initialized
INFO - 2024-10-03 17:11:51 --> Router Class Initialized
INFO - 2024-10-03 17:11:51 --> Output Class Initialized
INFO - 2024-10-03 17:11:51 --> Security Class Initialized
DEBUG - 2024-10-03 17:11:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-03 17:11:51 --> Input Class Initialized
INFO - 2024-10-03 17:11:51 --> Language Class Initialized
INFO - 2024-10-03 17:11:51 --> Language Class Initialized
INFO - 2024-10-03 17:11:51 --> Config Class Initialized
INFO - 2024-10-03 17:11:51 --> Loader Class Initialized
INFO - 2024-10-03 17:11:51 --> Helper loaded: url_helper
INFO - 2024-10-03 17:11:51 --> Helper loaded: file_helper
INFO - 2024-10-03 17:11:51 --> Helper loaded: form_helper
INFO - 2024-10-03 17:11:51 --> Helper loaded: my_helper
INFO - 2024-10-03 17:11:51 --> Database Driver Class Initialized
INFO - 2024-10-03 17:11:51 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-03 17:11:51 --> Controller Class Initialized
INFO - 2024-10-03 17:11:54 --> Config Class Initialized
INFO - 2024-10-03 17:11:54 --> Hooks Class Initialized
DEBUG - 2024-10-03 17:11:54 --> UTF-8 Support Enabled
INFO - 2024-10-03 17:11:54 --> Utf8 Class Initialized
INFO - 2024-10-03 17:11:54 --> URI Class Initialized
INFO - 2024-10-03 17:11:54 --> Router Class Initialized
INFO - 2024-10-03 17:11:54 --> Output Class Initialized
INFO - 2024-10-03 17:11:54 --> Security Class Initialized
DEBUG - 2024-10-03 17:11:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-03 17:11:54 --> Input Class Initialized
INFO - 2024-10-03 17:11:54 --> Language Class Initialized
INFO - 2024-10-03 17:11:54 --> Language Class Initialized
INFO - 2024-10-03 17:11:54 --> Config Class Initialized
INFO - 2024-10-03 17:11:54 --> Loader Class Initialized
INFO - 2024-10-03 17:11:54 --> Helper loaded: url_helper
INFO - 2024-10-03 17:11:54 --> Helper loaded: file_helper
INFO - 2024-10-03 17:11:54 --> Helper loaded: form_helper
INFO - 2024-10-03 17:11:54 --> Helper loaded: my_helper
INFO - 2024-10-03 17:11:54 --> Database Driver Class Initialized
INFO - 2024-10-03 17:11:54 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-03 17:11:54 --> Controller Class Initialized
INFO - 2024-10-03 17:11:54 --> Final output sent to browser
DEBUG - 2024-10-03 17:11:54 --> Total execution time: 0.0305
INFO - 2024-10-03 17:12:01 --> Config Class Initialized
INFO - 2024-10-03 17:12:01 --> Hooks Class Initialized
DEBUG - 2024-10-03 17:12:01 --> UTF-8 Support Enabled
INFO - 2024-10-03 17:12:01 --> Utf8 Class Initialized
INFO - 2024-10-03 17:12:01 --> URI Class Initialized
INFO - 2024-10-03 17:12:01 --> Router Class Initialized
INFO - 2024-10-03 17:12:01 --> Output Class Initialized
INFO - 2024-10-03 17:12:01 --> Security Class Initialized
DEBUG - 2024-10-03 17:12:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-03 17:12:01 --> Input Class Initialized
INFO - 2024-10-03 17:12:01 --> Language Class Initialized
INFO - 2024-10-03 17:12:01 --> Language Class Initialized
INFO - 2024-10-03 17:12:01 --> Config Class Initialized
INFO - 2024-10-03 17:12:01 --> Loader Class Initialized
INFO - 2024-10-03 17:12:01 --> Helper loaded: url_helper
INFO - 2024-10-03 17:12:01 --> Helper loaded: file_helper
INFO - 2024-10-03 17:12:01 --> Helper loaded: form_helper
INFO - 2024-10-03 17:12:01 --> Helper loaded: my_helper
INFO - 2024-10-03 17:12:01 --> Database Driver Class Initialized
INFO - 2024-10-03 17:12:01 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-03 17:12:01 --> Controller Class Initialized
INFO - 2024-10-03 17:12:02 --> Final output sent to browser
DEBUG - 2024-10-03 17:12:02 --> Total execution time: 0.5013
INFO - 2024-10-03 17:12:02 --> Config Class Initialized
INFO - 2024-10-03 17:12:02 --> Hooks Class Initialized
DEBUG - 2024-10-03 17:12:02 --> UTF-8 Support Enabled
INFO - 2024-10-03 17:12:02 --> Utf8 Class Initialized
INFO - 2024-10-03 17:12:02 --> URI Class Initialized
INFO - 2024-10-03 17:12:02 --> Router Class Initialized
INFO - 2024-10-03 17:12:02 --> Output Class Initialized
INFO - 2024-10-03 17:12:02 --> Security Class Initialized
DEBUG - 2024-10-03 17:12:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-03 17:12:02 --> Input Class Initialized
INFO - 2024-10-03 17:12:02 --> Language Class Initialized
INFO - 2024-10-03 17:12:02 --> Language Class Initialized
INFO - 2024-10-03 17:12:02 --> Config Class Initialized
INFO - 2024-10-03 17:12:02 --> Loader Class Initialized
INFO - 2024-10-03 17:12:02 --> Helper loaded: url_helper
INFO - 2024-10-03 17:12:02 --> Helper loaded: file_helper
INFO - 2024-10-03 17:12:02 --> Helper loaded: form_helper
INFO - 2024-10-03 17:12:02 --> Helper loaded: my_helper
INFO - 2024-10-03 17:12:02 --> Database Driver Class Initialized
INFO - 2024-10-03 17:12:02 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-03 17:12:02 --> Controller Class Initialized
INFO - 2024-10-03 17:12:07 --> Config Class Initialized
INFO - 2024-10-03 17:12:07 --> Hooks Class Initialized
DEBUG - 2024-10-03 17:12:07 --> UTF-8 Support Enabled
INFO - 2024-10-03 17:12:07 --> Utf8 Class Initialized
INFO - 2024-10-03 17:12:07 --> URI Class Initialized
INFO - 2024-10-03 17:12:07 --> Router Class Initialized
INFO - 2024-10-03 17:12:07 --> Output Class Initialized
INFO - 2024-10-03 17:12:07 --> Security Class Initialized
DEBUG - 2024-10-03 17:12:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-03 17:12:07 --> Input Class Initialized
INFO - 2024-10-03 17:12:07 --> Language Class Initialized
INFO - 2024-10-03 17:12:07 --> Language Class Initialized
INFO - 2024-10-03 17:12:07 --> Config Class Initialized
INFO - 2024-10-03 17:12:07 --> Loader Class Initialized
INFO - 2024-10-03 17:12:07 --> Helper loaded: url_helper
INFO - 2024-10-03 17:12:07 --> Helper loaded: file_helper
INFO - 2024-10-03 17:12:07 --> Helper loaded: form_helper
INFO - 2024-10-03 17:12:07 --> Helper loaded: my_helper
INFO - 2024-10-03 17:12:07 --> Database Driver Class Initialized
INFO - 2024-10-03 17:12:07 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-03 17:12:07 --> Controller Class Initialized
INFO - 2024-10-03 17:12:07 --> Final output sent to browser
DEBUG - 2024-10-03 17:12:07 --> Total execution time: 0.0470
INFO - 2024-10-03 17:12:07 --> Config Class Initialized
INFO - 2024-10-03 17:12:07 --> Hooks Class Initialized
DEBUG - 2024-10-03 17:12:07 --> UTF-8 Support Enabled
INFO - 2024-10-03 17:12:07 --> Utf8 Class Initialized
INFO - 2024-10-03 17:12:07 --> URI Class Initialized
INFO - 2024-10-03 17:12:07 --> Router Class Initialized
INFO - 2024-10-03 17:12:07 --> Output Class Initialized
INFO - 2024-10-03 17:12:07 --> Security Class Initialized
DEBUG - 2024-10-03 17:12:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-03 17:12:07 --> Input Class Initialized
INFO - 2024-10-03 17:12:07 --> Language Class Initialized
INFO - 2024-10-03 17:12:07 --> Language Class Initialized
INFO - 2024-10-03 17:12:07 --> Config Class Initialized
INFO - 2024-10-03 17:12:07 --> Loader Class Initialized
INFO - 2024-10-03 17:12:07 --> Helper loaded: url_helper
INFO - 2024-10-03 17:12:07 --> Helper loaded: file_helper
INFO - 2024-10-03 17:12:07 --> Helper loaded: form_helper
INFO - 2024-10-03 17:12:07 --> Helper loaded: my_helper
INFO - 2024-10-03 17:12:07 --> Database Driver Class Initialized
INFO - 2024-10-03 17:12:07 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-03 17:12:07 --> Controller Class Initialized
INFO - 2024-10-03 17:12:15 --> Config Class Initialized
INFO - 2024-10-03 17:12:15 --> Hooks Class Initialized
DEBUG - 2024-10-03 17:12:15 --> UTF-8 Support Enabled
INFO - 2024-10-03 17:12:15 --> Utf8 Class Initialized
INFO - 2024-10-03 17:12:15 --> URI Class Initialized
INFO - 2024-10-03 17:12:15 --> Router Class Initialized
INFO - 2024-10-03 17:12:15 --> Output Class Initialized
INFO - 2024-10-03 17:12:15 --> Security Class Initialized
DEBUG - 2024-10-03 17:12:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-03 17:12:15 --> Input Class Initialized
INFO - 2024-10-03 17:12:15 --> Language Class Initialized
INFO - 2024-10-03 17:12:15 --> Language Class Initialized
INFO - 2024-10-03 17:12:15 --> Config Class Initialized
INFO - 2024-10-03 17:12:15 --> Loader Class Initialized
INFO - 2024-10-03 17:12:15 --> Helper loaded: url_helper
INFO - 2024-10-03 17:12:15 --> Helper loaded: file_helper
INFO - 2024-10-03 17:12:15 --> Helper loaded: form_helper
INFO - 2024-10-03 17:12:15 --> Helper loaded: my_helper
INFO - 2024-10-03 17:12:15 --> Database Driver Class Initialized
INFO - 2024-10-03 17:12:15 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-03 17:12:15 --> Controller Class Initialized
INFO - 2024-10-03 17:12:29 --> Config Class Initialized
INFO - 2024-10-03 17:12:29 --> Hooks Class Initialized
DEBUG - 2024-10-03 17:12:29 --> UTF-8 Support Enabled
INFO - 2024-10-03 17:12:29 --> Utf8 Class Initialized
INFO - 2024-10-03 17:12:29 --> URI Class Initialized
INFO - 2024-10-03 17:12:29 --> Router Class Initialized
INFO - 2024-10-03 17:12:29 --> Output Class Initialized
INFO - 2024-10-03 17:12:29 --> Security Class Initialized
DEBUG - 2024-10-03 17:12:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-03 17:12:29 --> Input Class Initialized
INFO - 2024-10-03 17:12:29 --> Language Class Initialized
INFO - 2024-10-03 17:12:29 --> Language Class Initialized
INFO - 2024-10-03 17:12:29 --> Config Class Initialized
INFO - 2024-10-03 17:12:29 --> Loader Class Initialized
INFO - 2024-10-03 17:12:29 --> Helper loaded: url_helper
INFO - 2024-10-03 17:12:29 --> Helper loaded: file_helper
INFO - 2024-10-03 17:12:29 --> Helper loaded: form_helper
INFO - 2024-10-03 17:12:29 --> Helper loaded: my_helper
INFO - 2024-10-03 17:12:29 --> Database Driver Class Initialized
INFO - 2024-10-03 17:12:29 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-03 17:12:29 --> Controller Class Initialized
INFO - 2024-10-03 17:12:29 --> Final output sent to browser
DEBUG - 2024-10-03 17:12:29 --> Total execution time: 0.0654
INFO - 2024-10-03 17:12:32 --> Config Class Initialized
INFO - 2024-10-03 17:12:32 --> Hooks Class Initialized
DEBUG - 2024-10-03 17:12:32 --> UTF-8 Support Enabled
INFO - 2024-10-03 17:12:32 --> Utf8 Class Initialized
INFO - 2024-10-03 17:12:32 --> URI Class Initialized
INFO - 2024-10-03 17:12:32 --> Router Class Initialized
INFO - 2024-10-03 17:12:32 --> Output Class Initialized
INFO - 2024-10-03 17:12:32 --> Security Class Initialized
DEBUG - 2024-10-03 17:12:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-03 17:12:32 --> Input Class Initialized
INFO - 2024-10-03 17:12:32 --> Language Class Initialized
INFO - 2024-10-03 17:12:32 --> Language Class Initialized
INFO - 2024-10-03 17:12:32 --> Config Class Initialized
INFO - 2024-10-03 17:12:32 --> Loader Class Initialized
INFO - 2024-10-03 17:12:32 --> Helper loaded: url_helper
INFO - 2024-10-03 17:12:32 --> Helper loaded: file_helper
INFO - 2024-10-03 17:12:32 --> Helper loaded: form_helper
INFO - 2024-10-03 17:12:32 --> Helper loaded: my_helper
INFO - 2024-10-03 17:12:32 --> Database Driver Class Initialized
INFO - 2024-10-03 17:12:32 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-03 17:12:32 --> Controller Class Initialized
INFO - 2024-10-03 17:12:32 --> Final output sent to browser
DEBUG - 2024-10-03 17:12:32 --> Total execution time: 0.0353
INFO - 2024-10-03 17:12:34 --> Config Class Initialized
INFO - 2024-10-03 17:12:34 --> Hooks Class Initialized
DEBUG - 2024-10-03 17:12:34 --> UTF-8 Support Enabled
INFO - 2024-10-03 17:12:34 --> Utf8 Class Initialized
INFO - 2024-10-03 17:12:34 --> URI Class Initialized
INFO - 2024-10-03 17:12:34 --> Router Class Initialized
INFO - 2024-10-03 17:12:34 --> Output Class Initialized
INFO - 2024-10-03 17:12:34 --> Security Class Initialized
DEBUG - 2024-10-03 17:12:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-03 17:12:34 --> Input Class Initialized
INFO - 2024-10-03 17:12:34 --> Language Class Initialized
INFO - 2024-10-03 17:12:34 --> Language Class Initialized
INFO - 2024-10-03 17:12:34 --> Config Class Initialized
INFO - 2024-10-03 17:12:34 --> Loader Class Initialized
INFO - 2024-10-03 17:12:34 --> Helper loaded: url_helper
INFO - 2024-10-03 17:12:34 --> Helper loaded: file_helper
INFO - 2024-10-03 17:12:34 --> Helper loaded: form_helper
INFO - 2024-10-03 17:12:34 --> Helper loaded: my_helper
INFO - 2024-10-03 17:12:34 --> Database Driver Class Initialized
INFO - 2024-10-03 17:12:34 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-03 17:12:34 --> Controller Class Initialized
INFO - 2024-10-03 17:12:34 --> Final output sent to browser
DEBUG - 2024-10-03 17:12:34 --> Total execution time: 0.0471
INFO - 2024-10-03 17:12:51 --> Config Class Initialized
INFO - 2024-10-03 17:12:51 --> Hooks Class Initialized
DEBUG - 2024-10-03 17:12:51 --> UTF-8 Support Enabled
INFO - 2024-10-03 17:12:51 --> Utf8 Class Initialized
INFO - 2024-10-03 17:12:51 --> URI Class Initialized
INFO - 2024-10-03 17:12:51 --> Router Class Initialized
INFO - 2024-10-03 17:12:51 --> Output Class Initialized
INFO - 2024-10-03 17:12:51 --> Security Class Initialized
DEBUG - 2024-10-03 17:12:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-03 17:12:51 --> Input Class Initialized
INFO - 2024-10-03 17:12:51 --> Language Class Initialized
INFO - 2024-10-03 17:12:51 --> Language Class Initialized
INFO - 2024-10-03 17:12:51 --> Config Class Initialized
INFO - 2024-10-03 17:12:51 --> Loader Class Initialized
INFO - 2024-10-03 17:12:51 --> Helper loaded: url_helper
INFO - 2024-10-03 17:12:51 --> Helper loaded: file_helper
INFO - 2024-10-03 17:12:51 --> Helper loaded: form_helper
INFO - 2024-10-03 17:12:51 --> Helper loaded: my_helper
INFO - 2024-10-03 17:12:51 --> Database Driver Class Initialized
INFO - 2024-10-03 17:12:51 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-03 17:12:51 --> Controller Class Initialized
DEBUG - 2024-10-03 17:12:51 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/view_mapel/views/v_view_mapel.php
DEBUG - 2024-10-03 17:12:51 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-10-03 17:12:51 --> Final output sent to browser
DEBUG - 2024-10-03 17:12:51 --> Total execution time: 0.0725
INFO - 2024-10-03 17:12:54 --> Config Class Initialized
INFO - 2024-10-03 17:12:54 --> Hooks Class Initialized
DEBUG - 2024-10-03 17:12:54 --> UTF-8 Support Enabled
INFO - 2024-10-03 17:12:54 --> Utf8 Class Initialized
INFO - 2024-10-03 17:12:54 --> URI Class Initialized
INFO - 2024-10-03 17:12:54 --> Router Class Initialized
INFO - 2024-10-03 17:12:54 --> Output Class Initialized
INFO - 2024-10-03 17:12:54 --> Security Class Initialized
DEBUG - 2024-10-03 17:12:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-03 17:12:54 --> Input Class Initialized
INFO - 2024-10-03 17:12:54 --> Language Class Initialized
INFO - 2024-10-03 17:12:54 --> Language Class Initialized
INFO - 2024-10-03 17:12:54 --> Config Class Initialized
INFO - 2024-10-03 17:12:54 --> Loader Class Initialized
INFO - 2024-10-03 17:12:54 --> Helper loaded: url_helper
INFO - 2024-10-03 17:12:54 --> Helper loaded: file_helper
INFO - 2024-10-03 17:12:54 --> Helper loaded: form_helper
INFO - 2024-10-03 17:12:54 --> Helper loaded: my_helper
INFO - 2024-10-03 17:12:54 --> Database Driver Class Initialized
INFO - 2024-10-03 17:12:54 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-03 17:12:54 --> Controller Class Initialized
INFO - 2024-10-03 17:12:54 --> Final output sent to browser
DEBUG - 2024-10-03 17:12:54 --> Total execution time: 0.0563
INFO - 2024-10-03 17:12:54 --> Config Class Initialized
INFO - 2024-10-03 17:12:54 --> Hooks Class Initialized
DEBUG - 2024-10-03 17:12:54 --> UTF-8 Support Enabled
INFO - 2024-10-03 17:12:54 --> Utf8 Class Initialized
INFO - 2024-10-03 17:12:54 --> URI Class Initialized
INFO - 2024-10-03 17:12:54 --> Router Class Initialized
INFO - 2024-10-03 17:12:54 --> Output Class Initialized
INFO - 2024-10-03 17:12:54 --> Security Class Initialized
DEBUG - 2024-10-03 17:12:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-03 17:12:54 --> Input Class Initialized
INFO - 2024-10-03 17:12:54 --> Language Class Initialized
INFO - 2024-10-03 17:12:54 --> Language Class Initialized
INFO - 2024-10-03 17:12:54 --> Config Class Initialized
INFO - 2024-10-03 17:12:54 --> Loader Class Initialized
INFO - 2024-10-03 17:12:54 --> Helper loaded: url_helper
INFO - 2024-10-03 17:12:54 --> Helper loaded: file_helper
INFO - 2024-10-03 17:12:54 --> Helper loaded: form_helper
INFO - 2024-10-03 17:12:54 --> Helper loaded: my_helper
INFO - 2024-10-03 17:12:54 --> Database Driver Class Initialized
INFO - 2024-10-03 17:12:54 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-03 17:12:54 --> Controller Class Initialized
DEBUG - 2024-10-03 17:12:54 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/views/list.php
DEBUG - 2024-10-03 17:12:54 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-10-03 17:12:54 --> Final output sent to browser
DEBUG - 2024-10-03 17:12:54 --> Total execution time: 0.0299
INFO - 2024-10-03 17:12:54 --> Config Class Initialized
INFO - 2024-10-03 17:12:54 --> Hooks Class Initialized
DEBUG - 2024-10-03 17:12:54 --> UTF-8 Support Enabled
INFO - 2024-10-03 17:12:54 --> Utf8 Class Initialized
INFO - 2024-10-03 17:12:54 --> URI Class Initialized
INFO - 2024-10-03 17:12:54 --> Router Class Initialized
INFO - 2024-10-03 17:12:54 --> Output Class Initialized
INFO - 2024-10-03 17:12:54 --> Security Class Initialized
DEBUG - 2024-10-03 17:12:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-03 17:12:54 --> Input Class Initialized
INFO - 2024-10-03 17:12:54 --> Language Class Initialized
INFO - 2024-10-03 17:12:54 --> Language Class Initialized
INFO - 2024-10-03 17:12:54 --> Config Class Initialized
INFO - 2024-10-03 17:12:54 --> Loader Class Initialized
INFO - 2024-10-03 17:12:54 --> Helper loaded: url_helper
INFO - 2024-10-03 17:12:54 --> Helper loaded: file_helper
INFO - 2024-10-03 17:12:54 --> Helper loaded: form_helper
INFO - 2024-10-03 17:12:54 --> Helper loaded: my_helper
INFO - 2024-10-03 17:12:55 --> Database Driver Class Initialized
INFO - 2024-10-03 17:12:55 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-03 17:12:55 --> Controller Class Initialized
INFO - 2024-10-03 17:12:56 --> Config Class Initialized
INFO - 2024-10-03 17:12:56 --> Hooks Class Initialized
DEBUG - 2024-10-03 17:12:56 --> UTF-8 Support Enabled
INFO - 2024-10-03 17:12:56 --> Utf8 Class Initialized
INFO - 2024-10-03 17:12:56 --> URI Class Initialized
INFO - 2024-10-03 17:12:56 --> Router Class Initialized
INFO - 2024-10-03 17:12:56 --> Output Class Initialized
INFO - 2024-10-03 17:12:56 --> Security Class Initialized
DEBUG - 2024-10-03 17:12:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-03 17:12:56 --> Input Class Initialized
INFO - 2024-10-03 17:12:56 --> Language Class Initialized
INFO - 2024-10-03 17:12:56 --> Language Class Initialized
INFO - 2024-10-03 17:12:56 --> Config Class Initialized
INFO - 2024-10-03 17:12:56 --> Loader Class Initialized
INFO - 2024-10-03 17:12:56 --> Helper loaded: url_helper
INFO - 2024-10-03 17:12:56 --> Helper loaded: file_helper
INFO - 2024-10-03 17:12:56 --> Helper loaded: form_helper
INFO - 2024-10-03 17:12:56 --> Helper loaded: my_helper
INFO - 2024-10-03 17:12:56 --> Database Driver Class Initialized
INFO - 2024-10-03 17:12:56 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-03 17:12:56 --> Controller Class Initialized
DEBUG - 2024-10-03 17:12:56 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/view_mapel/views/v_view_mapel.php
DEBUG - 2024-10-03 17:12:56 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-10-03 17:12:56 --> Final output sent to browser
DEBUG - 2024-10-03 17:12:56 --> Total execution time: 0.0322
INFO - 2024-10-03 17:12:56 --> Config Class Initialized
INFO - 2024-10-03 17:12:56 --> Hooks Class Initialized
DEBUG - 2024-10-03 17:12:56 --> UTF-8 Support Enabled
INFO - 2024-10-03 17:12:56 --> Utf8 Class Initialized
INFO - 2024-10-03 17:12:56 --> URI Class Initialized
INFO - 2024-10-03 17:12:56 --> Router Class Initialized
INFO - 2024-10-03 17:12:56 --> Output Class Initialized
INFO - 2024-10-03 17:12:56 --> Security Class Initialized
DEBUG - 2024-10-03 17:12:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-03 17:12:56 --> Input Class Initialized
INFO - 2024-10-03 17:12:56 --> Language Class Initialized
INFO - 2024-10-03 17:12:56 --> Language Class Initialized
INFO - 2024-10-03 17:12:56 --> Config Class Initialized
INFO - 2024-10-03 17:12:56 --> Loader Class Initialized
INFO - 2024-10-03 17:12:56 --> Helper loaded: url_helper
INFO - 2024-10-03 17:12:56 --> Helper loaded: file_helper
INFO - 2024-10-03 17:12:56 --> Helper loaded: form_helper
INFO - 2024-10-03 17:12:56 --> Helper loaded: my_helper
INFO - 2024-10-03 17:12:56 --> Database Driver Class Initialized
INFO - 2024-10-03 17:12:56 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-03 17:12:56 --> Controller Class Initialized
INFO - 2024-10-03 17:12:58 --> Config Class Initialized
INFO - 2024-10-03 17:12:58 --> Hooks Class Initialized
DEBUG - 2024-10-03 17:12:58 --> UTF-8 Support Enabled
INFO - 2024-10-03 17:12:58 --> Utf8 Class Initialized
INFO - 2024-10-03 17:12:58 --> URI Class Initialized
INFO - 2024-10-03 17:12:58 --> Router Class Initialized
INFO - 2024-10-03 17:12:58 --> Output Class Initialized
INFO - 2024-10-03 17:12:58 --> Security Class Initialized
DEBUG - 2024-10-03 17:12:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-03 17:12:58 --> Input Class Initialized
INFO - 2024-10-03 17:12:58 --> Language Class Initialized
INFO - 2024-10-03 17:12:58 --> Language Class Initialized
INFO - 2024-10-03 17:12:58 --> Config Class Initialized
INFO - 2024-10-03 17:12:58 --> Loader Class Initialized
INFO - 2024-10-03 17:12:58 --> Helper loaded: url_helper
INFO - 2024-10-03 17:12:58 --> Helper loaded: file_helper
INFO - 2024-10-03 17:12:58 --> Helper loaded: form_helper
INFO - 2024-10-03 17:12:58 --> Helper loaded: my_helper
INFO - 2024-10-03 17:12:58 --> Database Driver Class Initialized
INFO - 2024-10-03 17:12:58 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-03 17:12:58 --> Controller Class Initialized
DEBUG - 2024-10-03 17:12:58 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_la/views/list.php
DEBUG - 2024-10-03 17:12:58 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-10-03 17:12:58 --> Final output sent to browser
DEBUG - 2024-10-03 17:12:58 --> Total execution time: 0.0768
INFO - 2024-10-03 17:12:58 --> Config Class Initialized
INFO - 2024-10-03 17:12:58 --> Hooks Class Initialized
DEBUG - 2024-10-03 17:12:58 --> UTF-8 Support Enabled
INFO - 2024-10-03 17:12:58 --> Utf8 Class Initialized
INFO - 2024-10-03 17:12:58 --> URI Class Initialized
INFO - 2024-10-03 17:12:58 --> Router Class Initialized
INFO - 2024-10-03 17:12:58 --> Output Class Initialized
INFO - 2024-10-03 17:12:58 --> Security Class Initialized
DEBUG - 2024-10-03 17:12:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-03 17:12:58 --> Input Class Initialized
INFO - 2024-10-03 17:12:58 --> Language Class Initialized
INFO - 2024-10-03 17:12:58 --> Language Class Initialized
INFO - 2024-10-03 17:12:58 --> Config Class Initialized
INFO - 2024-10-03 17:12:58 --> Loader Class Initialized
INFO - 2024-10-03 17:12:58 --> Helper loaded: url_helper
INFO - 2024-10-03 17:12:58 --> Helper loaded: file_helper
INFO - 2024-10-03 17:12:58 --> Helper loaded: form_helper
INFO - 2024-10-03 17:12:58 --> Helper loaded: my_helper
INFO - 2024-10-03 17:12:58 --> Database Driver Class Initialized
INFO - 2024-10-03 17:12:58 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-03 17:12:58 --> Controller Class Initialized
INFO - 2024-10-03 17:13:00 --> Config Class Initialized
INFO - 2024-10-03 17:13:00 --> Hooks Class Initialized
DEBUG - 2024-10-03 17:13:00 --> UTF-8 Support Enabled
INFO - 2024-10-03 17:13:00 --> Utf8 Class Initialized
INFO - 2024-10-03 17:13:00 --> URI Class Initialized
INFO - 2024-10-03 17:13:00 --> Router Class Initialized
INFO - 2024-10-03 17:13:00 --> Output Class Initialized
INFO - 2024-10-03 17:13:00 --> Security Class Initialized
DEBUG - 2024-10-03 17:13:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-03 17:13:00 --> Input Class Initialized
INFO - 2024-10-03 17:13:00 --> Language Class Initialized
INFO - 2024-10-03 17:13:00 --> Language Class Initialized
INFO - 2024-10-03 17:13:00 --> Config Class Initialized
INFO - 2024-10-03 17:13:00 --> Loader Class Initialized
INFO - 2024-10-03 17:13:00 --> Helper loaded: url_helper
INFO - 2024-10-03 17:13:00 --> Helper loaded: file_helper
INFO - 2024-10-03 17:13:00 --> Helper loaded: form_helper
INFO - 2024-10-03 17:13:00 --> Helper loaded: my_helper
INFO - 2024-10-03 17:13:00 --> Database Driver Class Initialized
INFO - 2024-10-03 17:13:00 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-03 17:13:00 --> Controller Class Initialized
INFO - 2024-10-03 17:13:00 --> Final output sent to browser
DEBUG - 2024-10-03 17:13:00 --> Total execution time: 0.0348
INFO - 2024-10-03 17:13:02 --> Config Class Initialized
INFO - 2024-10-03 17:13:02 --> Hooks Class Initialized
DEBUG - 2024-10-03 17:13:02 --> UTF-8 Support Enabled
INFO - 2024-10-03 17:13:02 --> Utf8 Class Initialized
INFO - 2024-10-03 17:13:02 --> URI Class Initialized
INFO - 2024-10-03 17:13:02 --> Router Class Initialized
INFO - 2024-10-03 17:13:02 --> Output Class Initialized
INFO - 2024-10-03 17:13:02 --> Security Class Initialized
DEBUG - 2024-10-03 17:13:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-03 17:13:02 --> Input Class Initialized
INFO - 2024-10-03 17:13:02 --> Language Class Initialized
INFO - 2024-10-03 17:13:02 --> Language Class Initialized
INFO - 2024-10-03 17:13:02 --> Config Class Initialized
INFO - 2024-10-03 17:13:02 --> Loader Class Initialized
INFO - 2024-10-03 17:13:02 --> Helper loaded: url_helper
INFO - 2024-10-03 17:13:02 --> Helper loaded: file_helper
INFO - 2024-10-03 17:13:02 --> Helper loaded: form_helper
INFO - 2024-10-03 17:13:02 --> Helper loaded: my_helper
INFO - 2024-10-03 17:13:02 --> Database Driver Class Initialized
INFO - 2024-10-03 17:13:02 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-03 17:13:02 --> Controller Class Initialized
INFO - 2024-10-03 17:13:02 --> Final output sent to browser
DEBUG - 2024-10-03 17:13:02 --> Total execution time: 0.0897
INFO - 2024-10-03 17:13:03 --> Config Class Initialized
INFO - 2024-10-03 17:13:03 --> Hooks Class Initialized
DEBUG - 2024-10-03 17:13:03 --> UTF-8 Support Enabled
INFO - 2024-10-03 17:13:03 --> Utf8 Class Initialized
INFO - 2024-10-03 17:13:03 --> URI Class Initialized
INFO - 2024-10-03 17:13:03 --> Router Class Initialized
INFO - 2024-10-03 17:13:03 --> Output Class Initialized
INFO - 2024-10-03 17:13:03 --> Security Class Initialized
DEBUG - 2024-10-03 17:13:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-03 17:13:03 --> Input Class Initialized
INFO - 2024-10-03 17:13:03 --> Language Class Initialized
INFO - 2024-10-03 17:13:03 --> Language Class Initialized
INFO - 2024-10-03 17:13:03 --> Config Class Initialized
INFO - 2024-10-03 17:13:03 --> Loader Class Initialized
INFO - 2024-10-03 17:13:03 --> Helper loaded: url_helper
INFO - 2024-10-03 17:13:03 --> Helper loaded: file_helper
INFO - 2024-10-03 17:13:03 --> Helper loaded: form_helper
INFO - 2024-10-03 17:13:03 --> Helper loaded: my_helper
INFO - 2024-10-03 17:13:03 --> Database Driver Class Initialized
INFO - 2024-10-03 17:13:03 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-03 17:13:03 --> Controller Class Initialized
INFO - 2024-10-03 17:13:03 --> Final output sent to browser
DEBUG - 2024-10-03 17:13:03 --> Total execution time: 0.1040
INFO - 2024-10-03 17:13:05 --> Config Class Initialized
INFO - 2024-10-03 17:13:05 --> Hooks Class Initialized
DEBUG - 2024-10-03 17:13:05 --> UTF-8 Support Enabled
INFO - 2024-10-03 17:13:05 --> Utf8 Class Initialized
INFO - 2024-10-03 17:13:05 --> URI Class Initialized
INFO - 2024-10-03 17:13:05 --> Router Class Initialized
INFO - 2024-10-03 17:13:05 --> Output Class Initialized
INFO - 2024-10-03 17:13:05 --> Security Class Initialized
DEBUG - 2024-10-03 17:13:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-03 17:13:05 --> Input Class Initialized
INFO - 2024-10-03 17:13:05 --> Language Class Initialized
INFO - 2024-10-03 17:13:05 --> Language Class Initialized
INFO - 2024-10-03 17:13:05 --> Config Class Initialized
INFO - 2024-10-03 17:13:05 --> Loader Class Initialized
INFO - 2024-10-03 17:13:05 --> Helper loaded: url_helper
INFO - 2024-10-03 17:13:05 --> Helper loaded: file_helper
INFO - 2024-10-03 17:13:05 --> Helper loaded: form_helper
INFO - 2024-10-03 17:13:05 --> Helper loaded: my_helper
INFO - 2024-10-03 17:13:05 --> Database Driver Class Initialized
INFO - 2024-10-03 17:13:05 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-03 17:13:05 --> Controller Class Initialized
INFO - 2024-10-03 17:13:05 --> Final output sent to browser
DEBUG - 2024-10-03 17:13:05 --> Total execution time: 0.0438
INFO - 2024-10-03 17:13:08 --> Config Class Initialized
INFO - 2024-10-03 17:13:08 --> Hooks Class Initialized
DEBUG - 2024-10-03 17:13:08 --> UTF-8 Support Enabled
INFO - 2024-10-03 17:13:08 --> Utf8 Class Initialized
INFO - 2024-10-03 17:13:08 --> URI Class Initialized
INFO - 2024-10-03 17:13:08 --> Router Class Initialized
INFO - 2024-10-03 17:13:08 --> Output Class Initialized
INFO - 2024-10-03 17:13:08 --> Security Class Initialized
DEBUG - 2024-10-03 17:13:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-03 17:13:08 --> Input Class Initialized
INFO - 2024-10-03 17:13:08 --> Language Class Initialized
INFO - 2024-10-03 17:13:08 --> Language Class Initialized
INFO - 2024-10-03 17:13:08 --> Config Class Initialized
INFO - 2024-10-03 17:13:08 --> Loader Class Initialized
INFO - 2024-10-03 17:13:08 --> Helper loaded: url_helper
INFO - 2024-10-03 17:13:08 --> Helper loaded: file_helper
INFO - 2024-10-03 17:13:08 --> Helper loaded: form_helper
INFO - 2024-10-03 17:13:08 --> Helper loaded: my_helper
INFO - 2024-10-03 17:13:08 --> Database Driver Class Initialized
INFO - 2024-10-03 17:13:08 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-03 17:13:08 --> Controller Class Initialized
INFO - 2024-10-03 17:13:08 --> Final output sent to browser
DEBUG - 2024-10-03 17:13:08 --> Total execution time: 0.0377
INFO - 2024-10-03 17:13:09 --> Config Class Initialized
INFO - 2024-10-03 17:13:09 --> Hooks Class Initialized
DEBUG - 2024-10-03 17:13:09 --> UTF-8 Support Enabled
INFO - 2024-10-03 17:13:09 --> Utf8 Class Initialized
INFO - 2024-10-03 17:13:09 --> URI Class Initialized
INFO - 2024-10-03 17:13:09 --> Router Class Initialized
INFO - 2024-10-03 17:13:09 --> Output Class Initialized
INFO - 2024-10-03 17:13:09 --> Security Class Initialized
DEBUG - 2024-10-03 17:13:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-03 17:13:09 --> Input Class Initialized
INFO - 2024-10-03 17:13:09 --> Language Class Initialized
INFO - 2024-10-03 17:13:09 --> Language Class Initialized
INFO - 2024-10-03 17:13:09 --> Config Class Initialized
INFO - 2024-10-03 17:13:09 --> Loader Class Initialized
INFO - 2024-10-03 17:13:09 --> Helper loaded: url_helper
INFO - 2024-10-03 17:13:09 --> Helper loaded: file_helper
INFO - 2024-10-03 17:13:09 --> Helper loaded: form_helper
INFO - 2024-10-03 17:13:09 --> Helper loaded: my_helper
INFO - 2024-10-03 17:13:09 --> Database Driver Class Initialized
INFO - 2024-10-03 17:13:09 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-03 17:13:09 --> Controller Class Initialized
DEBUG - 2024-10-03 17:13:09 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/view_mapel/views/v_view_mapel.php
DEBUG - 2024-10-03 17:13:09 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-10-03 17:13:09 --> Final output sent to browser
DEBUG - 2024-10-03 17:13:09 --> Total execution time: 0.0310
INFO - 2024-10-03 17:13:12 --> Config Class Initialized
INFO - 2024-10-03 17:13:12 --> Hooks Class Initialized
DEBUG - 2024-10-03 17:13:12 --> UTF-8 Support Enabled
INFO - 2024-10-03 17:13:12 --> Utf8 Class Initialized
INFO - 2024-10-03 17:13:12 --> URI Class Initialized
INFO - 2024-10-03 17:13:12 --> Router Class Initialized
INFO - 2024-10-03 17:13:12 --> Output Class Initialized
INFO - 2024-10-03 17:13:12 --> Security Class Initialized
DEBUG - 2024-10-03 17:13:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-03 17:13:12 --> Input Class Initialized
INFO - 2024-10-03 17:13:12 --> Language Class Initialized
INFO - 2024-10-03 17:13:12 --> Language Class Initialized
INFO - 2024-10-03 17:13:12 --> Config Class Initialized
INFO - 2024-10-03 17:13:12 --> Loader Class Initialized
INFO - 2024-10-03 17:13:12 --> Helper loaded: url_helper
INFO - 2024-10-03 17:13:12 --> Helper loaded: file_helper
INFO - 2024-10-03 17:13:12 --> Helper loaded: form_helper
INFO - 2024-10-03 17:13:12 --> Helper loaded: my_helper
INFO - 2024-10-03 17:13:12 --> Database Driver Class Initialized
INFO - 2024-10-03 17:13:12 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-03 17:13:12 --> Controller Class Initialized
DEBUG - 2024-10-03 17:13:12 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pss/views/list.php
DEBUG - 2024-10-03 17:13:12 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-10-03 17:13:12 --> Final output sent to browser
DEBUG - 2024-10-03 17:13:12 --> Total execution time: 0.0712
INFO - 2024-10-03 17:13:12 --> Config Class Initialized
INFO - 2024-10-03 17:13:12 --> Hooks Class Initialized
DEBUG - 2024-10-03 17:13:12 --> UTF-8 Support Enabled
INFO - 2024-10-03 17:13:12 --> Utf8 Class Initialized
INFO - 2024-10-03 17:13:12 --> URI Class Initialized
INFO - 2024-10-03 17:13:12 --> Router Class Initialized
INFO - 2024-10-03 17:13:12 --> Output Class Initialized
INFO - 2024-10-03 17:13:12 --> Security Class Initialized
DEBUG - 2024-10-03 17:13:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-03 17:13:12 --> Input Class Initialized
INFO - 2024-10-03 17:13:12 --> Language Class Initialized
INFO - 2024-10-03 17:13:12 --> Language Class Initialized
INFO - 2024-10-03 17:13:12 --> Config Class Initialized
INFO - 2024-10-03 17:13:12 --> Loader Class Initialized
INFO - 2024-10-03 17:13:12 --> Helper loaded: url_helper
INFO - 2024-10-03 17:13:12 --> Helper loaded: file_helper
INFO - 2024-10-03 17:13:12 --> Helper loaded: form_helper
INFO - 2024-10-03 17:13:12 --> Helper loaded: my_helper
INFO - 2024-10-03 17:13:12 --> Database Driver Class Initialized
INFO - 2024-10-03 17:13:12 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-03 17:13:12 --> Controller Class Initialized
INFO - 2024-10-03 17:13:13 --> Config Class Initialized
INFO - 2024-10-03 17:13:13 --> Hooks Class Initialized
DEBUG - 2024-10-03 17:13:13 --> UTF-8 Support Enabled
INFO - 2024-10-03 17:13:13 --> Utf8 Class Initialized
INFO - 2024-10-03 17:13:13 --> URI Class Initialized
INFO - 2024-10-03 17:13:13 --> Router Class Initialized
INFO - 2024-10-03 17:13:13 --> Output Class Initialized
INFO - 2024-10-03 17:13:13 --> Security Class Initialized
DEBUG - 2024-10-03 17:13:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-03 17:13:13 --> Input Class Initialized
INFO - 2024-10-03 17:13:13 --> Language Class Initialized
INFO - 2024-10-03 17:13:13 --> Language Class Initialized
INFO - 2024-10-03 17:13:13 --> Config Class Initialized
INFO - 2024-10-03 17:13:13 --> Loader Class Initialized
INFO - 2024-10-03 17:13:13 --> Helper loaded: url_helper
INFO - 2024-10-03 17:13:13 --> Helper loaded: file_helper
INFO - 2024-10-03 17:13:13 --> Helper loaded: form_helper
INFO - 2024-10-03 17:13:13 --> Helper loaded: my_helper
INFO - 2024-10-03 17:13:13 --> Database Driver Class Initialized
INFO - 2024-10-03 17:13:13 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-03 17:13:13 --> Controller Class Initialized
INFO - 2024-10-03 17:13:13 --> Final output sent to browser
DEBUG - 2024-10-03 17:13:13 --> Total execution time: 0.0379
INFO - 2024-10-03 17:13:46 --> Config Class Initialized
INFO - 2024-10-03 17:13:46 --> Hooks Class Initialized
DEBUG - 2024-10-03 17:13:46 --> UTF-8 Support Enabled
INFO - 2024-10-03 17:13:46 --> Utf8 Class Initialized
INFO - 2024-10-03 17:13:46 --> URI Class Initialized
INFO - 2024-10-03 17:13:46 --> Router Class Initialized
INFO - 2024-10-03 17:13:46 --> Output Class Initialized
INFO - 2024-10-03 17:13:46 --> Security Class Initialized
DEBUG - 2024-10-03 17:13:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-03 17:13:46 --> Input Class Initialized
INFO - 2024-10-03 17:13:46 --> Language Class Initialized
INFO - 2024-10-03 17:13:46 --> Language Class Initialized
INFO - 2024-10-03 17:13:46 --> Config Class Initialized
INFO - 2024-10-03 17:13:46 --> Loader Class Initialized
INFO - 2024-10-03 17:13:46 --> Helper loaded: url_helper
INFO - 2024-10-03 17:13:46 --> Helper loaded: file_helper
INFO - 2024-10-03 17:13:46 --> Helper loaded: form_helper
INFO - 2024-10-03 17:13:46 --> Helper loaded: my_helper
INFO - 2024-10-03 17:13:46 --> Database Driver Class Initialized
INFO - 2024-10-03 17:13:46 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-03 17:13:46 --> Controller Class Initialized
INFO - 2024-10-03 17:13:46 --> Final output sent to browser
DEBUG - 2024-10-03 17:13:46 --> Total execution time: 0.1167
INFO - 2024-10-03 17:14:00 --> Config Class Initialized
INFO - 2024-10-03 17:14:00 --> Hooks Class Initialized
DEBUG - 2024-10-03 17:14:00 --> UTF-8 Support Enabled
INFO - 2024-10-03 17:14:00 --> Utf8 Class Initialized
INFO - 2024-10-03 17:14:00 --> URI Class Initialized
INFO - 2024-10-03 17:14:00 --> Router Class Initialized
INFO - 2024-10-03 17:14:00 --> Output Class Initialized
INFO - 2024-10-03 17:14:00 --> Security Class Initialized
DEBUG - 2024-10-03 17:14:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-03 17:14:00 --> Input Class Initialized
INFO - 2024-10-03 17:14:00 --> Language Class Initialized
INFO - 2024-10-03 17:14:00 --> Language Class Initialized
INFO - 2024-10-03 17:14:00 --> Config Class Initialized
INFO - 2024-10-03 17:14:00 --> Loader Class Initialized
INFO - 2024-10-03 17:14:00 --> Helper loaded: url_helper
INFO - 2024-10-03 17:14:00 --> Helper loaded: file_helper
INFO - 2024-10-03 17:14:00 --> Helper loaded: form_helper
INFO - 2024-10-03 17:14:00 --> Helper loaded: my_helper
INFO - 2024-10-03 17:14:00 --> Database Driver Class Initialized
INFO - 2024-10-03 17:14:00 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-03 17:14:00 --> Controller Class Initialized
INFO - 2024-10-03 17:14:00 --> Final output sent to browser
DEBUG - 2024-10-03 17:14:00 --> Total execution time: 0.0925
INFO - 2024-10-03 17:14:03 --> Config Class Initialized
INFO - 2024-10-03 17:14:03 --> Hooks Class Initialized
DEBUG - 2024-10-03 17:14:03 --> UTF-8 Support Enabled
INFO - 2024-10-03 17:14:03 --> Utf8 Class Initialized
INFO - 2024-10-03 17:14:03 --> URI Class Initialized
INFO - 2024-10-03 17:14:03 --> Router Class Initialized
INFO - 2024-10-03 17:14:03 --> Output Class Initialized
INFO - 2024-10-03 17:14:03 --> Security Class Initialized
DEBUG - 2024-10-03 17:14:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-03 17:14:03 --> Input Class Initialized
INFO - 2024-10-03 17:14:03 --> Language Class Initialized
INFO - 2024-10-03 17:14:03 --> Language Class Initialized
INFO - 2024-10-03 17:14:03 --> Config Class Initialized
INFO - 2024-10-03 17:14:03 --> Loader Class Initialized
INFO - 2024-10-03 17:14:03 --> Helper loaded: url_helper
INFO - 2024-10-03 17:14:03 --> Helper loaded: file_helper
INFO - 2024-10-03 17:14:03 --> Helper loaded: form_helper
INFO - 2024-10-03 17:14:03 --> Helper loaded: my_helper
INFO - 2024-10-03 17:14:03 --> Database Driver Class Initialized
INFO - 2024-10-03 17:14:03 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-03 17:14:03 --> Controller Class Initialized
INFO - 2024-10-03 17:14:03 --> Final output sent to browser
DEBUG - 2024-10-03 17:14:03 --> Total execution time: 0.0576
INFO - 2024-10-03 17:14:21 --> Config Class Initialized
INFO - 2024-10-03 17:14:21 --> Hooks Class Initialized
DEBUG - 2024-10-03 17:14:21 --> UTF-8 Support Enabled
INFO - 2024-10-03 17:14:21 --> Utf8 Class Initialized
INFO - 2024-10-03 17:14:21 --> URI Class Initialized
INFO - 2024-10-03 17:14:21 --> Router Class Initialized
INFO - 2024-10-03 17:14:21 --> Output Class Initialized
INFO - 2024-10-03 17:14:21 --> Security Class Initialized
DEBUG - 2024-10-03 17:14:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-03 17:14:21 --> Input Class Initialized
INFO - 2024-10-03 17:14:21 --> Language Class Initialized
INFO - 2024-10-03 17:14:21 --> Language Class Initialized
INFO - 2024-10-03 17:14:21 --> Config Class Initialized
INFO - 2024-10-03 17:14:21 --> Loader Class Initialized
INFO - 2024-10-03 17:14:21 --> Helper loaded: url_helper
INFO - 2024-10-03 17:14:21 --> Helper loaded: file_helper
INFO - 2024-10-03 17:14:21 --> Helper loaded: form_helper
INFO - 2024-10-03 17:14:21 --> Helper loaded: my_helper
INFO - 2024-10-03 17:14:21 --> Database Driver Class Initialized
INFO - 2024-10-03 17:14:21 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-03 17:14:21 --> Controller Class Initialized
INFO - 2024-10-03 17:14:21 --> Final output sent to browser
DEBUG - 2024-10-03 17:14:21 --> Total execution time: 0.0766
INFO - 2024-10-03 17:14:24 --> Config Class Initialized
INFO - 2024-10-03 17:14:24 --> Hooks Class Initialized
DEBUG - 2024-10-03 17:14:24 --> UTF-8 Support Enabled
INFO - 2024-10-03 17:14:24 --> Utf8 Class Initialized
INFO - 2024-10-03 17:14:24 --> URI Class Initialized
INFO - 2024-10-03 17:14:24 --> Router Class Initialized
INFO - 2024-10-03 17:14:24 --> Output Class Initialized
INFO - 2024-10-03 17:14:24 --> Security Class Initialized
DEBUG - 2024-10-03 17:14:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-03 17:14:24 --> Input Class Initialized
INFO - 2024-10-03 17:14:24 --> Language Class Initialized
INFO - 2024-10-03 17:14:24 --> Language Class Initialized
INFO - 2024-10-03 17:14:24 --> Config Class Initialized
INFO - 2024-10-03 17:14:24 --> Loader Class Initialized
INFO - 2024-10-03 17:14:24 --> Helper loaded: url_helper
INFO - 2024-10-03 17:14:24 --> Helper loaded: file_helper
INFO - 2024-10-03 17:14:24 --> Helper loaded: form_helper
INFO - 2024-10-03 17:14:24 --> Helper loaded: my_helper
INFO - 2024-10-03 17:14:24 --> Database Driver Class Initialized
INFO - 2024-10-03 17:14:24 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-03 17:14:24 --> Controller Class Initialized
INFO - 2024-10-03 17:14:24 --> Final output sent to browser
DEBUG - 2024-10-03 17:14:24 --> Total execution time: 0.0367
INFO - 2024-10-03 17:14:43 --> Config Class Initialized
INFO - 2024-10-03 17:14:43 --> Hooks Class Initialized
DEBUG - 2024-10-03 17:14:43 --> UTF-8 Support Enabled
INFO - 2024-10-03 17:14:43 --> Utf8 Class Initialized
INFO - 2024-10-03 17:14:43 --> URI Class Initialized
INFO - 2024-10-03 17:14:43 --> Router Class Initialized
INFO - 2024-10-03 17:14:43 --> Output Class Initialized
INFO - 2024-10-03 17:14:43 --> Security Class Initialized
DEBUG - 2024-10-03 17:14:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-03 17:14:43 --> Input Class Initialized
INFO - 2024-10-03 17:14:43 --> Language Class Initialized
INFO - 2024-10-03 17:14:43 --> Language Class Initialized
INFO - 2024-10-03 17:14:43 --> Config Class Initialized
INFO - 2024-10-03 17:14:43 --> Loader Class Initialized
INFO - 2024-10-03 17:14:43 --> Helper loaded: url_helper
INFO - 2024-10-03 17:14:43 --> Helper loaded: file_helper
INFO - 2024-10-03 17:14:43 --> Helper loaded: form_helper
INFO - 2024-10-03 17:14:43 --> Helper loaded: my_helper
INFO - 2024-10-03 17:14:43 --> Database Driver Class Initialized
INFO - 2024-10-03 17:14:43 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-03 17:14:43 --> Controller Class Initialized
INFO - 2024-10-03 17:14:44 --> Final output sent to browser
DEBUG - 2024-10-03 17:14:44 --> Total execution time: 0.3512
INFO - 2024-10-03 17:14:50 --> Config Class Initialized
INFO - 2024-10-03 17:14:50 --> Hooks Class Initialized
DEBUG - 2024-10-03 17:14:50 --> UTF-8 Support Enabled
INFO - 2024-10-03 17:14:50 --> Utf8 Class Initialized
INFO - 2024-10-03 17:14:50 --> URI Class Initialized
INFO - 2024-10-03 17:14:50 --> Router Class Initialized
INFO - 2024-10-03 17:14:50 --> Output Class Initialized
INFO - 2024-10-03 17:14:50 --> Security Class Initialized
DEBUG - 2024-10-03 17:14:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-03 17:14:50 --> Input Class Initialized
INFO - 2024-10-03 17:14:50 --> Language Class Initialized
INFO - 2024-10-03 17:14:50 --> Language Class Initialized
INFO - 2024-10-03 17:14:50 --> Config Class Initialized
INFO - 2024-10-03 17:14:50 --> Loader Class Initialized
INFO - 2024-10-03 17:14:50 --> Helper loaded: url_helper
INFO - 2024-10-03 17:14:50 --> Helper loaded: file_helper
INFO - 2024-10-03 17:14:50 --> Helper loaded: form_helper
INFO - 2024-10-03 17:14:50 --> Helper loaded: my_helper
INFO - 2024-10-03 17:14:50 --> Database Driver Class Initialized
INFO - 2024-10-03 17:14:50 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-03 17:14:50 --> Controller Class Initialized
INFO - 2024-10-03 17:14:50 --> Final output sent to browser
DEBUG - 2024-10-03 17:14:50 --> Total execution time: 0.0332
INFO - 2024-10-03 17:14:52 --> Config Class Initialized
INFO - 2024-10-03 17:14:52 --> Hooks Class Initialized
DEBUG - 2024-10-03 17:14:52 --> UTF-8 Support Enabled
INFO - 2024-10-03 17:14:52 --> Utf8 Class Initialized
INFO - 2024-10-03 17:14:52 --> URI Class Initialized
INFO - 2024-10-03 17:14:52 --> Router Class Initialized
INFO - 2024-10-03 17:14:52 --> Output Class Initialized
INFO - 2024-10-03 17:14:52 --> Security Class Initialized
DEBUG - 2024-10-03 17:14:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-03 17:14:52 --> Input Class Initialized
INFO - 2024-10-03 17:14:52 --> Language Class Initialized
INFO - 2024-10-03 17:14:52 --> Language Class Initialized
INFO - 2024-10-03 17:14:52 --> Config Class Initialized
INFO - 2024-10-03 17:14:52 --> Loader Class Initialized
INFO - 2024-10-03 17:14:52 --> Helper loaded: url_helper
INFO - 2024-10-03 17:14:52 --> Helper loaded: file_helper
INFO - 2024-10-03 17:14:52 --> Helper loaded: form_helper
INFO - 2024-10-03 17:14:52 --> Helper loaded: my_helper
INFO - 2024-10-03 17:14:52 --> Database Driver Class Initialized
INFO - 2024-10-03 17:14:52 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-03 17:14:52 --> Controller Class Initialized
INFO - 2024-10-03 17:14:52 --> Final output sent to browser
DEBUG - 2024-10-03 17:14:52 --> Total execution time: 0.0401
INFO - 2024-10-03 17:15:24 --> Config Class Initialized
INFO - 2024-10-03 17:15:24 --> Hooks Class Initialized
DEBUG - 2024-10-03 17:15:24 --> UTF-8 Support Enabled
INFO - 2024-10-03 17:15:24 --> Utf8 Class Initialized
INFO - 2024-10-03 17:15:24 --> URI Class Initialized
INFO - 2024-10-03 17:15:24 --> Router Class Initialized
INFO - 2024-10-03 17:15:24 --> Output Class Initialized
INFO - 2024-10-03 17:15:24 --> Security Class Initialized
DEBUG - 2024-10-03 17:15:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-03 17:15:24 --> Input Class Initialized
INFO - 2024-10-03 17:15:24 --> Language Class Initialized
INFO - 2024-10-03 17:15:24 --> Language Class Initialized
INFO - 2024-10-03 17:15:24 --> Config Class Initialized
INFO - 2024-10-03 17:15:24 --> Loader Class Initialized
INFO - 2024-10-03 17:15:24 --> Helper loaded: url_helper
INFO - 2024-10-03 17:15:24 --> Helper loaded: file_helper
INFO - 2024-10-03 17:15:24 --> Helper loaded: form_helper
INFO - 2024-10-03 17:15:24 --> Helper loaded: my_helper
INFO - 2024-10-03 17:15:24 --> Database Driver Class Initialized
INFO - 2024-10-03 17:15:24 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-03 17:15:24 --> Controller Class Initialized
INFO - 2024-10-03 17:15:25 --> Final output sent to browser
DEBUG - 2024-10-03 17:15:25 --> Total execution time: 0.3408
INFO - 2024-10-03 17:15:38 --> Config Class Initialized
INFO - 2024-10-03 17:15:38 --> Hooks Class Initialized
DEBUG - 2024-10-03 17:15:38 --> UTF-8 Support Enabled
INFO - 2024-10-03 17:15:38 --> Utf8 Class Initialized
INFO - 2024-10-03 17:15:38 --> URI Class Initialized
INFO - 2024-10-03 17:15:38 --> Router Class Initialized
INFO - 2024-10-03 17:15:38 --> Output Class Initialized
INFO - 2024-10-03 17:15:38 --> Security Class Initialized
DEBUG - 2024-10-03 17:15:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-03 17:15:38 --> Input Class Initialized
INFO - 2024-10-03 17:15:38 --> Language Class Initialized
INFO - 2024-10-03 17:15:38 --> Language Class Initialized
INFO - 2024-10-03 17:15:38 --> Config Class Initialized
INFO - 2024-10-03 17:15:38 --> Loader Class Initialized
INFO - 2024-10-03 17:15:38 --> Helper loaded: url_helper
INFO - 2024-10-03 17:15:38 --> Helper loaded: file_helper
INFO - 2024-10-03 17:15:38 --> Helper loaded: form_helper
INFO - 2024-10-03 17:15:38 --> Helper loaded: my_helper
INFO - 2024-10-03 17:15:38 --> Database Driver Class Initialized
INFO - 2024-10-03 17:15:38 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-03 17:15:38 --> Controller Class Initialized
INFO - 2024-10-03 17:15:38 --> Final output sent to browser
DEBUG - 2024-10-03 17:15:38 --> Total execution time: 0.0734
INFO - 2024-10-03 17:15:40 --> Config Class Initialized
INFO - 2024-10-03 17:15:40 --> Hooks Class Initialized
DEBUG - 2024-10-03 17:15:40 --> UTF-8 Support Enabled
INFO - 2024-10-03 17:15:40 --> Utf8 Class Initialized
INFO - 2024-10-03 17:15:40 --> URI Class Initialized
INFO - 2024-10-03 17:15:40 --> Router Class Initialized
INFO - 2024-10-03 17:15:40 --> Output Class Initialized
INFO - 2024-10-03 17:15:40 --> Security Class Initialized
DEBUG - 2024-10-03 17:15:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-03 17:15:40 --> Input Class Initialized
INFO - 2024-10-03 17:15:40 --> Language Class Initialized
INFO - 2024-10-03 17:15:40 --> Language Class Initialized
INFO - 2024-10-03 17:15:40 --> Config Class Initialized
INFO - 2024-10-03 17:15:40 --> Loader Class Initialized
INFO - 2024-10-03 17:15:40 --> Helper loaded: url_helper
INFO - 2024-10-03 17:15:40 --> Helper loaded: file_helper
INFO - 2024-10-03 17:15:40 --> Helper loaded: form_helper
INFO - 2024-10-03 17:15:40 --> Helper loaded: my_helper
INFO - 2024-10-03 17:15:40 --> Database Driver Class Initialized
INFO - 2024-10-03 17:15:40 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-03 17:15:40 --> Controller Class Initialized
INFO - 2024-10-03 17:15:40 --> Final output sent to browser
DEBUG - 2024-10-03 17:15:40 --> Total execution time: 0.0323
INFO - 2024-10-03 17:16:20 --> Config Class Initialized
INFO - 2024-10-03 17:16:20 --> Hooks Class Initialized
DEBUG - 2024-10-03 17:16:20 --> UTF-8 Support Enabled
INFO - 2024-10-03 17:16:20 --> Utf8 Class Initialized
INFO - 2024-10-03 17:16:20 --> URI Class Initialized
INFO - 2024-10-03 17:16:20 --> Router Class Initialized
INFO - 2024-10-03 17:16:20 --> Output Class Initialized
INFO - 2024-10-03 17:16:20 --> Security Class Initialized
DEBUG - 2024-10-03 17:16:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-03 17:16:20 --> Input Class Initialized
INFO - 2024-10-03 17:16:20 --> Language Class Initialized
INFO - 2024-10-03 17:16:20 --> Language Class Initialized
INFO - 2024-10-03 17:16:20 --> Config Class Initialized
INFO - 2024-10-03 17:16:20 --> Loader Class Initialized
INFO - 2024-10-03 17:16:20 --> Helper loaded: url_helper
INFO - 2024-10-03 17:16:20 --> Helper loaded: file_helper
INFO - 2024-10-03 17:16:20 --> Helper loaded: form_helper
INFO - 2024-10-03 17:16:20 --> Helper loaded: my_helper
INFO - 2024-10-03 17:16:20 --> Database Driver Class Initialized
INFO - 2024-10-03 17:16:20 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-03 17:16:20 --> Controller Class Initialized
INFO - 2024-10-03 17:16:20 --> Final output sent to browser
DEBUG - 2024-10-03 17:16:20 --> Total execution time: 0.0628
INFO - 2024-10-03 17:16:28 --> Config Class Initialized
INFO - 2024-10-03 17:16:28 --> Hooks Class Initialized
DEBUG - 2024-10-03 17:16:28 --> UTF-8 Support Enabled
INFO - 2024-10-03 17:16:28 --> Utf8 Class Initialized
INFO - 2024-10-03 17:16:28 --> URI Class Initialized
INFO - 2024-10-03 17:16:28 --> Router Class Initialized
INFO - 2024-10-03 17:16:28 --> Output Class Initialized
INFO - 2024-10-03 17:16:28 --> Security Class Initialized
DEBUG - 2024-10-03 17:16:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-03 17:16:28 --> Input Class Initialized
INFO - 2024-10-03 17:16:28 --> Language Class Initialized
INFO - 2024-10-03 17:16:28 --> Language Class Initialized
INFO - 2024-10-03 17:16:28 --> Config Class Initialized
INFO - 2024-10-03 17:16:28 --> Loader Class Initialized
INFO - 2024-10-03 17:16:28 --> Helper loaded: url_helper
INFO - 2024-10-03 17:16:28 --> Helper loaded: file_helper
INFO - 2024-10-03 17:16:28 --> Helper loaded: form_helper
INFO - 2024-10-03 17:16:28 --> Helper loaded: my_helper
INFO - 2024-10-03 17:16:28 --> Database Driver Class Initialized
INFO - 2024-10-03 17:16:28 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-03 17:16:28 --> Controller Class Initialized
INFO - 2024-10-03 17:16:28 --> Final output sent to browser
DEBUG - 2024-10-03 17:16:28 --> Total execution time: 0.0720
INFO - 2024-10-03 17:16:29 --> Config Class Initialized
INFO - 2024-10-03 17:16:29 --> Hooks Class Initialized
DEBUG - 2024-10-03 17:16:29 --> UTF-8 Support Enabled
INFO - 2024-10-03 17:16:29 --> Utf8 Class Initialized
INFO - 2024-10-03 17:16:29 --> URI Class Initialized
INFO - 2024-10-03 17:16:29 --> Router Class Initialized
INFO - 2024-10-03 17:16:29 --> Output Class Initialized
INFO - 2024-10-03 17:16:29 --> Security Class Initialized
DEBUG - 2024-10-03 17:16:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-03 17:16:29 --> Input Class Initialized
INFO - 2024-10-03 17:16:29 --> Language Class Initialized
INFO - 2024-10-03 17:16:29 --> Language Class Initialized
INFO - 2024-10-03 17:16:29 --> Config Class Initialized
INFO - 2024-10-03 17:16:29 --> Loader Class Initialized
INFO - 2024-10-03 17:16:29 --> Helper loaded: url_helper
INFO - 2024-10-03 17:16:29 --> Helper loaded: file_helper
INFO - 2024-10-03 17:16:29 --> Helper loaded: form_helper
INFO - 2024-10-03 17:16:29 --> Helper loaded: my_helper
INFO - 2024-10-03 17:16:29 --> Database Driver Class Initialized
INFO - 2024-10-03 17:16:29 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-03 17:16:29 --> Controller Class Initialized
INFO - 2024-10-03 17:16:29 --> Final output sent to browser
DEBUG - 2024-10-03 17:16:29 --> Total execution time: 0.0880
INFO - 2024-10-03 17:16:30 --> Config Class Initialized
INFO - 2024-10-03 17:16:30 --> Hooks Class Initialized
DEBUG - 2024-10-03 17:16:30 --> UTF-8 Support Enabled
INFO - 2024-10-03 17:16:30 --> Utf8 Class Initialized
INFO - 2024-10-03 17:16:30 --> URI Class Initialized
INFO - 2024-10-03 17:16:30 --> Router Class Initialized
INFO - 2024-10-03 17:16:30 --> Output Class Initialized
INFO - 2024-10-03 17:16:30 --> Security Class Initialized
DEBUG - 2024-10-03 17:16:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-03 17:16:30 --> Input Class Initialized
INFO - 2024-10-03 17:16:30 --> Language Class Initialized
INFO - 2024-10-03 17:16:30 --> Language Class Initialized
INFO - 2024-10-03 17:16:30 --> Config Class Initialized
INFO - 2024-10-03 17:16:30 --> Loader Class Initialized
INFO - 2024-10-03 17:16:30 --> Helper loaded: url_helper
INFO - 2024-10-03 17:16:30 --> Helper loaded: file_helper
INFO - 2024-10-03 17:16:30 --> Helper loaded: form_helper
INFO - 2024-10-03 17:16:30 --> Helper loaded: my_helper
INFO - 2024-10-03 17:16:30 --> Database Driver Class Initialized
INFO - 2024-10-03 17:16:30 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-03 17:16:30 --> Controller Class Initialized
INFO - 2024-10-03 17:16:30 --> Final output sent to browser
DEBUG - 2024-10-03 17:16:30 --> Total execution time: 0.0453
INFO - 2024-10-03 17:16:31 --> Config Class Initialized
INFO - 2024-10-03 17:16:31 --> Hooks Class Initialized
DEBUG - 2024-10-03 17:16:31 --> UTF-8 Support Enabled
INFO - 2024-10-03 17:16:31 --> Utf8 Class Initialized
INFO - 2024-10-03 17:16:31 --> URI Class Initialized
INFO - 2024-10-03 17:16:31 --> Router Class Initialized
INFO - 2024-10-03 17:16:31 --> Output Class Initialized
INFO - 2024-10-03 17:16:31 --> Security Class Initialized
DEBUG - 2024-10-03 17:16:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-03 17:16:31 --> Input Class Initialized
INFO - 2024-10-03 17:16:31 --> Language Class Initialized
INFO - 2024-10-03 17:16:31 --> Language Class Initialized
INFO - 2024-10-03 17:16:31 --> Config Class Initialized
INFO - 2024-10-03 17:16:31 --> Loader Class Initialized
INFO - 2024-10-03 17:16:31 --> Helper loaded: url_helper
INFO - 2024-10-03 17:16:31 --> Helper loaded: file_helper
INFO - 2024-10-03 17:16:31 --> Helper loaded: form_helper
INFO - 2024-10-03 17:16:31 --> Helper loaded: my_helper
INFO - 2024-10-03 17:16:31 --> Database Driver Class Initialized
INFO - 2024-10-03 17:16:31 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-03 17:16:31 --> Controller Class Initialized
INFO - 2024-10-03 17:16:31 --> Final output sent to browser
DEBUG - 2024-10-03 17:16:31 --> Total execution time: 0.0326
INFO - 2024-10-03 17:16:32 --> Config Class Initialized
INFO - 2024-10-03 17:16:32 --> Hooks Class Initialized
DEBUG - 2024-10-03 17:16:32 --> UTF-8 Support Enabled
INFO - 2024-10-03 17:16:32 --> Utf8 Class Initialized
INFO - 2024-10-03 17:16:32 --> URI Class Initialized
INFO - 2024-10-03 17:16:32 --> Router Class Initialized
INFO - 2024-10-03 17:16:32 --> Output Class Initialized
INFO - 2024-10-03 17:16:32 --> Security Class Initialized
DEBUG - 2024-10-03 17:16:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-03 17:16:32 --> Input Class Initialized
INFO - 2024-10-03 17:16:32 --> Language Class Initialized
INFO - 2024-10-03 17:16:32 --> Language Class Initialized
INFO - 2024-10-03 17:16:32 --> Config Class Initialized
INFO - 2024-10-03 17:16:32 --> Loader Class Initialized
INFO - 2024-10-03 17:16:32 --> Helper loaded: url_helper
INFO - 2024-10-03 17:16:32 --> Helper loaded: file_helper
INFO - 2024-10-03 17:16:32 --> Helper loaded: form_helper
INFO - 2024-10-03 17:16:32 --> Helper loaded: my_helper
INFO - 2024-10-03 17:16:32 --> Database Driver Class Initialized
INFO - 2024-10-03 17:16:32 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-03 17:16:32 --> Controller Class Initialized
INFO - 2024-10-03 17:16:32 --> Final output sent to browser
DEBUG - 2024-10-03 17:16:32 --> Total execution time: 0.0396
INFO - 2024-10-03 17:16:55 --> Config Class Initialized
INFO - 2024-10-03 17:16:55 --> Hooks Class Initialized
DEBUG - 2024-10-03 17:16:55 --> UTF-8 Support Enabled
INFO - 2024-10-03 17:16:55 --> Utf8 Class Initialized
INFO - 2024-10-03 17:16:55 --> URI Class Initialized
INFO - 2024-10-03 17:16:55 --> Router Class Initialized
INFO - 2024-10-03 17:16:55 --> Output Class Initialized
INFO - 2024-10-03 17:16:55 --> Security Class Initialized
DEBUG - 2024-10-03 17:16:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-03 17:16:55 --> Input Class Initialized
INFO - 2024-10-03 17:16:55 --> Language Class Initialized
INFO - 2024-10-03 17:16:55 --> Language Class Initialized
INFO - 2024-10-03 17:16:55 --> Config Class Initialized
INFO - 2024-10-03 17:16:55 --> Loader Class Initialized
INFO - 2024-10-03 17:16:55 --> Helper loaded: url_helper
INFO - 2024-10-03 17:16:55 --> Helper loaded: file_helper
INFO - 2024-10-03 17:16:55 --> Helper loaded: form_helper
INFO - 2024-10-03 17:16:55 --> Helper loaded: my_helper
INFO - 2024-10-03 17:16:55 --> Database Driver Class Initialized
INFO - 2024-10-03 17:16:55 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-03 17:16:55 --> Controller Class Initialized
INFO - 2024-10-03 17:16:55 --> Final output sent to browser
DEBUG - 2024-10-03 17:16:55 --> Total execution time: 0.0526
INFO - 2024-10-03 17:16:59 --> Config Class Initialized
INFO - 2024-10-03 17:16:59 --> Hooks Class Initialized
DEBUG - 2024-10-03 17:16:59 --> UTF-8 Support Enabled
INFO - 2024-10-03 17:16:59 --> Utf8 Class Initialized
INFO - 2024-10-03 17:16:59 --> URI Class Initialized
INFO - 2024-10-03 17:16:59 --> Router Class Initialized
INFO - 2024-10-03 17:16:59 --> Output Class Initialized
INFO - 2024-10-03 17:16:59 --> Security Class Initialized
DEBUG - 2024-10-03 17:16:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-03 17:16:59 --> Input Class Initialized
INFO - 2024-10-03 17:16:59 --> Language Class Initialized
INFO - 2024-10-03 17:16:59 --> Language Class Initialized
INFO - 2024-10-03 17:16:59 --> Config Class Initialized
INFO - 2024-10-03 17:16:59 --> Loader Class Initialized
INFO - 2024-10-03 17:16:59 --> Helper loaded: url_helper
INFO - 2024-10-03 17:16:59 --> Helper loaded: file_helper
INFO - 2024-10-03 17:16:59 --> Helper loaded: form_helper
INFO - 2024-10-03 17:16:59 --> Helper loaded: my_helper
INFO - 2024-10-03 17:16:59 --> Database Driver Class Initialized
INFO - 2024-10-03 17:16:59 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-03 17:16:59 --> Controller Class Initialized
DEBUG - 2024-10-03 17:16:59 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/view_mapel/views/v_view_mapel.php
DEBUG - 2024-10-03 17:16:59 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-10-03 17:16:59 --> Final output sent to browser
DEBUG - 2024-10-03 17:16:59 --> Total execution time: 0.0331
INFO - 2024-10-03 17:17:03 --> Config Class Initialized
INFO - 2024-10-03 17:17:03 --> Hooks Class Initialized
DEBUG - 2024-10-03 17:17:03 --> UTF-8 Support Enabled
INFO - 2024-10-03 17:17:03 --> Utf8 Class Initialized
INFO - 2024-10-03 17:17:03 --> URI Class Initialized
INFO - 2024-10-03 17:17:03 --> Router Class Initialized
INFO - 2024-10-03 17:17:03 --> Output Class Initialized
INFO - 2024-10-03 17:17:03 --> Security Class Initialized
DEBUG - 2024-10-03 17:17:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-03 17:17:03 --> Input Class Initialized
INFO - 2024-10-03 17:17:03 --> Language Class Initialized
INFO - 2024-10-03 17:17:03 --> Language Class Initialized
INFO - 2024-10-03 17:17:03 --> Config Class Initialized
INFO - 2024-10-03 17:17:03 --> Loader Class Initialized
INFO - 2024-10-03 17:17:03 --> Helper loaded: url_helper
INFO - 2024-10-03 17:17:03 --> Helper loaded: file_helper
INFO - 2024-10-03 17:17:03 --> Helper loaded: form_helper
INFO - 2024-10-03 17:17:03 --> Helper loaded: my_helper
INFO - 2024-10-03 17:17:03 --> Database Driver Class Initialized
INFO - 2024-10-03 17:17:03 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-03 17:17:03 --> Controller Class Initialized
DEBUG - 2024-10-03 17:17:03 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/views/list.php
DEBUG - 2024-10-03 17:17:03 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-10-03 17:17:03 --> Final output sent to browser
DEBUG - 2024-10-03 17:17:03 --> Total execution time: 0.0431
INFO - 2024-10-03 17:17:03 --> Config Class Initialized
INFO - 2024-10-03 17:17:03 --> Hooks Class Initialized
DEBUG - 2024-10-03 17:17:03 --> UTF-8 Support Enabled
INFO - 2024-10-03 17:17:03 --> Utf8 Class Initialized
INFO - 2024-10-03 17:17:03 --> URI Class Initialized
INFO - 2024-10-03 17:17:03 --> Router Class Initialized
INFO - 2024-10-03 17:17:03 --> Output Class Initialized
INFO - 2024-10-03 17:17:03 --> Security Class Initialized
DEBUG - 2024-10-03 17:17:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-03 17:17:03 --> Input Class Initialized
INFO - 2024-10-03 17:17:03 --> Language Class Initialized
INFO - 2024-10-03 17:17:03 --> Language Class Initialized
INFO - 2024-10-03 17:17:03 --> Config Class Initialized
INFO - 2024-10-03 17:17:03 --> Loader Class Initialized
INFO - 2024-10-03 17:17:03 --> Helper loaded: url_helper
INFO - 2024-10-03 17:17:03 --> Helper loaded: file_helper
INFO - 2024-10-03 17:17:03 --> Helper loaded: form_helper
INFO - 2024-10-03 17:17:03 --> Helper loaded: my_helper
INFO - 2024-10-03 17:17:03 --> Database Driver Class Initialized
INFO - 2024-10-03 17:17:03 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-03 17:17:03 --> Controller Class Initialized
INFO - 2024-10-03 17:17:06 --> Config Class Initialized
INFO - 2024-10-03 17:17:06 --> Hooks Class Initialized
DEBUG - 2024-10-03 17:17:06 --> UTF-8 Support Enabled
INFO - 2024-10-03 17:17:06 --> Utf8 Class Initialized
INFO - 2024-10-03 17:17:06 --> URI Class Initialized
INFO - 2024-10-03 17:17:06 --> Router Class Initialized
INFO - 2024-10-03 17:17:06 --> Output Class Initialized
INFO - 2024-10-03 17:17:06 --> Security Class Initialized
DEBUG - 2024-10-03 17:17:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-03 17:17:06 --> Input Class Initialized
INFO - 2024-10-03 17:17:06 --> Language Class Initialized
INFO - 2024-10-03 17:17:06 --> Language Class Initialized
INFO - 2024-10-03 17:17:06 --> Config Class Initialized
INFO - 2024-10-03 17:17:06 --> Loader Class Initialized
INFO - 2024-10-03 17:17:06 --> Helper loaded: url_helper
INFO - 2024-10-03 17:17:06 --> Helper loaded: file_helper
INFO - 2024-10-03 17:17:06 --> Helper loaded: form_helper
INFO - 2024-10-03 17:17:06 --> Helper loaded: my_helper
INFO - 2024-10-03 17:17:06 --> Database Driver Class Initialized
INFO - 2024-10-03 17:17:06 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-03 17:17:06 --> Controller Class Initialized
INFO - 2024-10-03 17:17:06 --> Final output sent to browser
DEBUG - 2024-10-03 17:17:06 --> Total execution time: 0.0381
INFO - 2024-10-03 17:17:54 --> Config Class Initialized
INFO - 2024-10-03 17:17:54 --> Hooks Class Initialized
DEBUG - 2024-10-03 17:17:54 --> UTF-8 Support Enabled
INFO - 2024-10-03 17:17:54 --> Utf8 Class Initialized
INFO - 2024-10-03 17:17:54 --> URI Class Initialized
INFO - 2024-10-03 17:17:54 --> Router Class Initialized
INFO - 2024-10-03 17:17:54 --> Output Class Initialized
INFO - 2024-10-03 17:17:54 --> Security Class Initialized
DEBUG - 2024-10-03 17:17:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-03 17:17:54 --> Input Class Initialized
INFO - 2024-10-03 17:17:54 --> Language Class Initialized
INFO - 2024-10-03 17:17:54 --> Language Class Initialized
INFO - 2024-10-03 17:17:54 --> Config Class Initialized
INFO - 2024-10-03 17:17:54 --> Loader Class Initialized
INFO - 2024-10-03 17:17:54 --> Helper loaded: url_helper
INFO - 2024-10-03 17:17:54 --> Helper loaded: file_helper
INFO - 2024-10-03 17:17:54 --> Helper loaded: form_helper
INFO - 2024-10-03 17:17:54 --> Helper loaded: my_helper
INFO - 2024-10-03 17:17:54 --> Database Driver Class Initialized
INFO - 2024-10-03 17:17:54 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-03 17:17:54 --> Controller Class Initialized
DEBUG - 2024-10-03 17:17:54 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/view_mapel/views/v_view_mapel.php
DEBUG - 2024-10-03 17:17:54 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-10-03 17:17:54 --> Final output sent to browser
DEBUG - 2024-10-03 17:17:54 --> Total execution time: 0.0317
INFO - 2024-10-03 17:17:57 --> Config Class Initialized
INFO - 2024-10-03 17:17:57 --> Hooks Class Initialized
DEBUG - 2024-10-03 17:17:57 --> UTF-8 Support Enabled
INFO - 2024-10-03 17:17:57 --> Utf8 Class Initialized
INFO - 2024-10-03 17:17:57 --> URI Class Initialized
INFO - 2024-10-03 17:17:57 --> Router Class Initialized
INFO - 2024-10-03 17:17:57 --> Output Class Initialized
INFO - 2024-10-03 17:17:57 --> Security Class Initialized
DEBUG - 2024-10-03 17:17:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-03 17:17:57 --> Input Class Initialized
INFO - 2024-10-03 17:17:57 --> Language Class Initialized
INFO - 2024-10-03 17:17:57 --> Language Class Initialized
INFO - 2024-10-03 17:17:57 --> Config Class Initialized
INFO - 2024-10-03 17:17:57 --> Loader Class Initialized
INFO - 2024-10-03 17:17:57 --> Helper loaded: url_helper
INFO - 2024-10-03 17:17:57 --> Helper loaded: file_helper
INFO - 2024-10-03 17:17:57 --> Helper loaded: form_helper
INFO - 2024-10-03 17:17:57 --> Helper loaded: my_helper
INFO - 2024-10-03 17:17:57 --> Database Driver Class Initialized
INFO - 2024-10-03 17:17:57 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-03 17:17:57 --> Controller Class Initialized
DEBUG - 2024-10-03 17:17:57 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_catatan_guru/views/list.php
DEBUG - 2024-10-03 17:17:57 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-10-03 17:17:57 --> Final output sent to browser
DEBUG - 2024-10-03 17:17:57 --> Total execution time: 0.0321
INFO - 2024-10-03 17:17:59 --> Config Class Initialized
INFO - 2024-10-03 17:17:59 --> Hooks Class Initialized
DEBUG - 2024-10-03 17:17:59 --> UTF-8 Support Enabled
INFO - 2024-10-03 17:17:59 --> Utf8 Class Initialized
INFO - 2024-10-03 17:17:59 --> URI Class Initialized
INFO - 2024-10-03 17:17:59 --> Router Class Initialized
INFO - 2024-10-03 17:17:59 --> Output Class Initialized
INFO - 2024-10-03 17:17:59 --> Security Class Initialized
DEBUG - 2024-10-03 17:17:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-03 17:17:59 --> Input Class Initialized
INFO - 2024-10-03 17:17:59 --> Language Class Initialized
INFO - 2024-10-03 17:17:59 --> Language Class Initialized
INFO - 2024-10-03 17:17:59 --> Config Class Initialized
INFO - 2024-10-03 17:17:59 --> Loader Class Initialized
INFO - 2024-10-03 17:17:59 --> Helper loaded: url_helper
INFO - 2024-10-03 17:17:59 --> Helper loaded: file_helper
INFO - 2024-10-03 17:17:59 --> Helper loaded: form_helper
INFO - 2024-10-03 17:17:59 --> Helper loaded: my_helper
INFO - 2024-10-03 17:17:59 --> Database Driver Class Initialized
INFO - 2024-10-03 17:17:59 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-03 17:17:59 --> Controller Class Initialized
INFO - 2024-10-03 17:18:01 --> Config Class Initialized
INFO - 2024-10-03 17:18:01 --> Hooks Class Initialized
DEBUG - 2024-10-03 17:18:01 --> UTF-8 Support Enabled
INFO - 2024-10-03 17:18:01 --> Utf8 Class Initialized
INFO - 2024-10-03 17:18:01 --> URI Class Initialized
INFO - 2024-10-03 17:18:01 --> Router Class Initialized
INFO - 2024-10-03 17:18:01 --> Output Class Initialized
INFO - 2024-10-03 17:18:01 --> Security Class Initialized
DEBUG - 2024-10-03 17:18:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-03 17:18:01 --> Input Class Initialized
INFO - 2024-10-03 17:18:01 --> Language Class Initialized
INFO - 2024-10-03 17:18:01 --> Language Class Initialized
INFO - 2024-10-03 17:18:01 --> Config Class Initialized
INFO - 2024-10-03 17:18:01 --> Loader Class Initialized
INFO - 2024-10-03 17:18:01 --> Helper loaded: url_helper
INFO - 2024-10-03 17:18:01 --> Helper loaded: file_helper
INFO - 2024-10-03 17:18:01 --> Helper loaded: form_helper
INFO - 2024-10-03 17:18:01 --> Helper loaded: my_helper
INFO - 2024-10-03 17:18:01 --> Database Driver Class Initialized
INFO - 2024-10-03 17:18:01 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-03 17:18:01 --> Controller Class Initialized
DEBUG - 2024-10-03 17:18:01 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/view_mapel/views/v_view_mapel.php
DEBUG - 2024-10-03 17:18:01 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-10-03 17:18:01 --> Final output sent to browser
DEBUG - 2024-10-03 17:18:01 --> Total execution time: 0.0329
INFO - 2024-10-03 17:18:04 --> Config Class Initialized
INFO - 2024-10-03 17:18:04 --> Hooks Class Initialized
DEBUG - 2024-10-03 17:18:04 --> UTF-8 Support Enabled
INFO - 2024-10-03 17:18:04 --> Utf8 Class Initialized
INFO - 2024-10-03 17:18:04 --> URI Class Initialized
INFO - 2024-10-03 17:18:04 --> Router Class Initialized
INFO - 2024-10-03 17:18:04 --> Output Class Initialized
INFO - 2024-10-03 17:18:04 --> Security Class Initialized
DEBUG - 2024-10-03 17:18:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-03 17:18:04 --> Input Class Initialized
INFO - 2024-10-03 17:18:04 --> Language Class Initialized
INFO - 2024-10-03 17:18:04 --> Language Class Initialized
INFO - 2024-10-03 17:18:04 --> Config Class Initialized
INFO - 2024-10-03 17:18:04 --> Loader Class Initialized
INFO - 2024-10-03 17:18:04 --> Helper loaded: url_helper
INFO - 2024-10-03 17:18:04 --> Helper loaded: file_helper
INFO - 2024-10-03 17:18:04 --> Helper loaded: form_helper
INFO - 2024-10-03 17:18:04 --> Helper loaded: my_helper
INFO - 2024-10-03 17:18:04 --> Database Driver Class Initialized
INFO - 2024-10-03 17:18:04 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-03 17:18:04 --> Controller Class Initialized
DEBUG - 2024-10-03 17:18:04 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/views/list.php
DEBUG - 2024-10-03 17:18:04 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-10-03 17:18:04 --> Final output sent to browser
DEBUG - 2024-10-03 17:18:04 --> Total execution time: 0.0736
INFO - 2024-10-03 17:18:04 --> Config Class Initialized
INFO - 2024-10-03 17:18:04 --> Hooks Class Initialized
DEBUG - 2024-10-03 17:18:04 --> UTF-8 Support Enabled
INFO - 2024-10-03 17:18:04 --> Utf8 Class Initialized
INFO - 2024-10-03 17:18:04 --> URI Class Initialized
INFO - 2024-10-03 17:18:04 --> Router Class Initialized
INFO - 2024-10-03 17:18:04 --> Output Class Initialized
INFO - 2024-10-03 17:18:04 --> Security Class Initialized
DEBUG - 2024-10-03 17:18:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-03 17:18:04 --> Input Class Initialized
INFO - 2024-10-03 17:18:04 --> Language Class Initialized
INFO - 2024-10-03 17:18:04 --> Language Class Initialized
INFO - 2024-10-03 17:18:04 --> Config Class Initialized
INFO - 2024-10-03 17:18:04 --> Loader Class Initialized
INFO - 2024-10-03 17:18:04 --> Helper loaded: url_helper
INFO - 2024-10-03 17:18:04 --> Helper loaded: file_helper
INFO - 2024-10-03 17:18:04 --> Helper loaded: form_helper
INFO - 2024-10-03 17:18:04 --> Helper loaded: my_helper
INFO - 2024-10-03 17:18:04 --> Database Driver Class Initialized
INFO - 2024-10-03 17:18:04 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-03 17:18:04 --> Controller Class Initialized
INFO - 2024-10-03 17:18:07 --> Config Class Initialized
INFO - 2024-10-03 17:18:07 --> Hooks Class Initialized
DEBUG - 2024-10-03 17:18:07 --> UTF-8 Support Enabled
INFO - 2024-10-03 17:18:07 --> Utf8 Class Initialized
INFO - 2024-10-03 17:18:07 --> URI Class Initialized
INFO - 2024-10-03 17:18:07 --> Router Class Initialized
INFO - 2024-10-03 17:18:07 --> Output Class Initialized
INFO - 2024-10-03 17:18:07 --> Security Class Initialized
DEBUG - 2024-10-03 17:18:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-03 17:18:07 --> Input Class Initialized
INFO - 2024-10-03 17:18:07 --> Language Class Initialized
INFO - 2024-10-03 17:18:07 --> Language Class Initialized
INFO - 2024-10-03 17:18:07 --> Config Class Initialized
INFO - 2024-10-03 17:18:07 --> Loader Class Initialized
INFO - 2024-10-03 17:18:07 --> Helper loaded: url_helper
INFO - 2024-10-03 17:18:07 --> Helper loaded: file_helper
INFO - 2024-10-03 17:18:07 --> Helper loaded: form_helper
INFO - 2024-10-03 17:18:07 --> Helper loaded: my_helper
INFO - 2024-10-03 17:18:07 --> Database Driver Class Initialized
INFO - 2024-10-03 17:18:07 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-03 17:18:07 --> Controller Class Initialized
DEBUG - 2024-10-03 17:18:07 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/view_mapel/views/v_view_mapel.php
DEBUG - 2024-10-03 17:18:07 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-10-03 17:18:07 --> Final output sent to browser
DEBUG - 2024-10-03 17:18:07 --> Total execution time: 0.0387
INFO - 2024-10-03 17:18:08 --> Config Class Initialized
INFO - 2024-10-03 17:18:08 --> Hooks Class Initialized
DEBUG - 2024-10-03 17:18:08 --> UTF-8 Support Enabled
INFO - 2024-10-03 17:18:08 --> Utf8 Class Initialized
INFO - 2024-10-03 17:18:08 --> URI Class Initialized
INFO - 2024-10-03 17:18:08 --> Router Class Initialized
INFO - 2024-10-03 17:18:08 --> Output Class Initialized
INFO - 2024-10-03 17:18:08 --> Security Class Initialized
DEBUG - 2024-10-03 17:18:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-03 17:18:08 --> Input Class Initialized
INFO - 2024-10-03 17:18:08 --> Language Class Initialized
INFO - 2024-10-03 17:18:08 --> Language Class Initialized
INFO - 2024-10-03 17:18:08 --> Config Class Initialized
INFO - 2024-10-03 17:18:08 --> Loader Class Initialized
INFO - 2024-10-03 17:18:08 --> Helper loaded: url_helper
INFO - 2024-10-03 17:18:08 --> Helper loaded: file_helper
INFO - 2024-10-03 17:18:08 --> Helper loaded: form_helper
INFO - 2024-10-03 17:18:08 --> Helper loaded: my_helper
INFO - 2024-10-03 17:18:08 --> Database Driver Class Initialized
INFO - 2024-10-03 17:18:08 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-03 17:18:08 --> Controller Class Initialized
DEBUG - 2024-10-03 17:18:08 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_catatan_guru/views/list.php
DEBUG - 2024-10-03 17:18:08 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-10-03 17:18:08 --> Final output sent to browser
DEBUG - 2024-10-03 17:18:08 --> Total execution time: 0.0354
INFO - 2024-10-03 17:18:10 --> Config Class Initialized
INFO - 2024-10-03 17:18:10 --> Hooks Class Initialized
DEBUG - 2024-10-03 17:18:10 --> UTF-8 Support Enabled
INFO - 2024-10-03 17:18:10 --> Utf8 Class Initialized
INFO - 2024-10-03 17:18:10 --> URI Class Initialized
INFO - 2024-10-03 17:18:10 --> Router Class Initialized
INFO - 2024-10-03 17:18:10 --> Output Class Initialized
INFO - 2024-10-03 17:18:10 --> Security Class Initialized
DEBUG - 2024-10-03 17:18:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-03 17:18:10 --> Input Class Initialized
INFO - 2024-10-03 17:18:10 --> Language Class Initialized
INFO - 2024-10-03 17:18:10 --> Language Class Initialized
INFO - 2024-10-03 17:18:10 --> Config Class Initialized
INFO - 2024-10-03 17:18:10 --> Loader Class Initialized
INFO - 2024-10-03 17:18:10 --> Helper loaded: url_helper
INFO - 2024-10-03 17:18:10 --> Helper loaded: file_helper
INFO - 2024-10-03 17:18:10 --> Helper loaded: form_helper
INFO - 2024-10-03 17:18:10 --> Helper loaded: my_helper
INFO - 2024-10-03 17:18:10 --> Database Driver Class Initialized
INFO - 2024-10-03 17:18:10 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-03 17:18:10 --> Controller Class Initialized
INFO - 2024-10-03 17:18:11 --> Config Class Initialized
INFO - 2024-10-03 17:18:11 --> Hooks Class Initialized
DEBUG - 2024-10-03 17:18:11 --> UTF-8 Support Enabled
INFO - 2024-10-03 17:18:11 --> Utf8 Class Initialized
INFO - 2024-10-03 17:18:11 --> URI Class Initialized
INFO - 2024-10-03 17:18:11 --> Router Class Initialized
INFO - 2024-10-03 17:18:11 --> Output Class Initialized
INFO - 2024-10-03 17:18:11 --> Security Class Initialized
DEBUG - 2024-10-03 17:18:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-03 17:18:11 --> Input Class Initialized
INFO - 2024-10-03 17:18:11 --> Language Class Initialized
INFO - 2024-10-03 17:18:11 --> Language Class Initialized
INFO - 2024-10-03 17:18:11 --> Config Class Initialized
INFO - 2024-10-03 17:18:11 --> Loader Class Initialized
INFO - 2024-10-03 17:18:11 --> Helper loaded: url_helper
INFO - 2024-10-03 17:18:11 --> Helper loaded: file_helper
INFO - 2024-10-03 17:18:11 --> Helper loaded: form_helper
INFO - 2024-10-03 17:18:11 --> Helper loaded: my_helper
INFO - 2024-10-03 17:18:11 --> Database Driver Class Initialized
INFO - 2024-10-03 17:18:11 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-03 17:18:11 --> Controller Class Initialized
DEBUG - 2024-10-03 17:18:11 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/view_mapel/views/v_view_mapel.php
DEBUG - 2024-10-03 17:18:11 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-10-03 17:18:11 --> Final output sent to browser
DEBUG - 2024-10-03 17:18:11 --> Total execution time: 0.0315
INFO - 2024-10-03 17:18:12 --> Config Class Initialized
INFO - 2024-10-03 17:18:12 --> Hooks Class Initialized
DEBUG - 2024-10-03 17:18:12 --> UTF-8 Support Enabled
INFO - 2024-10-03 17:18:12 --> Utf8 Class Initialized
INFO - 2024-10-03 17:18:12 --> URI Class Initialized
INFO - 2024-10-03 17:18:12 --> Router Class Initialized
INFO - 2024-10-03 17:18:12 --> Output Class Initialized
INFO - 2024-10-03 17:18:12 --> Security Class Initialized
DEBUG - 2024-10-03 17:18:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-03 17:18:12 --> Input Class Initialized
INFO - 2024-10-03 17:18:12 --> Language Class Initialized
INFO - 2024-10-03 17:18:12 --> Language Class Initialized
INFO - 2024-10-03 17:18:12 --> Config Class Initialized
INFO - 2024-10-03 17:18:12 --> Loader Class Initialized
INFO - 2024-10-03 17:18:12 --> Helper loaded: url_helper
INFO - 2024-10-03 17:18:12 --> Helper loaded: file_helper
INFO - 2024-10-03 17:18:12 --> Helper loaded: form_helper
INFO - 2024-10-03 17:18:12 --> Helper loaded: my_helper
INFO - 2024-10-03 17:18:12 --> Database Driver Class Initialized
INFO - 2024-10-03 17:18:12 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-03 17:18:12 --> Controller Class Initialized
DEBUG - 2024-10-03 17:18:12 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_catatan_guru/views/list.php
DEBUG - 2024-10-03 17:18:12 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-10-03 17:18:12 --> Final output sent to browser
DEBUG - 2024-10-03 17:18:12 --> Total execution time: 0.0400
INFO - 2024-10-03 17:18:14 --> Config Class Initialized
INFO - 2024-10-03 17:18:14 --> Hooks Class Initialized
DEBUG - 2024-10-03 17:18:14 --> UTF-8 Support Enabled
INFO - 2024-10-03 17:18:14 --> Utf8 Class Initialized
INFO - 2024-10-03 17:18:14 --> URI Class Initialized
INFO - 2024-10-03 17:18:14 --> Router Class Initialized
INFO - 2024-10-03 17:18:14 --> Output Class Initialized
INFO - 2024-10-03 17:18:14 --> Security Class Initialized
DEBUG - 2024-10-03 17:18:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-03 17:18:14 --> Input Class Initialized
INFO - 2024-10-03 17:18:14 --> Language Class Initialized
INFO - 2024-10-03 17:18:14 --> Language Class Initialized
INFO - 2024-10-03 17:18:14 --> Config Class Initialized
INFO - 2024-10-03 17:18:14 --> Loader Class Initialized
INFO - 2024-10-03 17:18:14 --> Helper loaded: url_helper
INFO - 2024-10-03 17:18:14 --> Helper loaded: file_helper
INFO - 2024-10-03 17:18:14 --> Helper loaded: form_helper
INFO - 2024-10-03 17:18:14 --> Helper loaded: my_helper
INFO - 2024-10-03 17:18:14 --> Database Driver Class Initialized
INFO - 2024-10-03 17:18:14 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-03 17:18:14 --> Controller Class Initialized
INFO - 2024-10-03 17:18:15 --> Config Class Initialized
INFO - 2024-10-03 17:18:15 --> Hooks Class Initialized
DEBUG - 2024-10-03 17:18:15 --> UTF-8 Support Enabled
INFO - 2024-10-03 17:18:15 --> Utf8 Class Initialized
INFO - 2024-10-03 17:18:15 --> URI Class Initialized
INFO - 2024-10-03 17:18:15 --> Router Class Initialized
INFO - 2024-10-03 17:18:15 --> Output Class Initialized
INFO - 2024-10-03 17:18:15 --> Security Class Initialized
DEBUG - 2024-10-03 17:18:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-03 17:18:15 --> Input Class Initialized
INFO - 2024-10-03 17:18:15 --> Language Class Initialized
INFO - 2024-10-03 17:18:15 --> Language Class Initialized
INFO - 2024-10-03 17:18:15 --> Config Class Initialized
INFO - 2024-10-03 17:18:15 --> Loader Class Initialized
INFO - 2024-10-03 17:18:15 --> Helper loaded: url_helper
INFO - 2024-10-03 17:18:15 --> Helper loaded: file_helper
INFO - 2024-10-03 17:18:15 --> Helper loaded: form_helper
INFO - 2024-10-03 17:18:15 --> Helper loaded: my_helper
INFO - 2024-10-03 17:18:15 --> Database Driver Class Initialized
INFO - 2024-10-03 17:18:15 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-03 17:18:15 --> Controller Class Initialized
DEBUG - 2024-10-03 17:18:15 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/view_mapel/views/v_view_mapel.php
DEBUG - 2024-10-03 17:18:15 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-10-03 17:18:15 --> Final output sent to browser
DEBUG - 2024-10-03 17:18:15 --> Total execution time: 0.1060
INFO - 2024-10-03 17:22:49 --> Config Class Initialized
INFO - 2024-10-03 17:22:49 --> Hooks Class Initialized
DEBUG - 2024-10-03 17:22:49 --> UTF-8 Support Enabled
INFO - 2024-10-03 17:22:49 --> Utf8 Class Initialized
INFO - 2024-10-03 17:22:49 --> URI Class Initialized
INFO - 2024-10-03 17:22:49 --> Router Class Initialized
INFO - 2024-10-03 17:22:49 --> Output Class Initialized
INFO - 2024-10-03 17:22:49 --> Security Class Initialized
DEBUG - 2024-10-03 17:22:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-03 17:22:49 --> Input Class Initialized
INFO - 2024-10-03 17:22:49 --> Language Class Initialized
INFO - 2024-10-03 17:22:49 --> Language Class Initialized
INFO - 2024-10-03 17:22:49 --> Config Class Initialized
INFO - 2024-10-03 17:22:49 --> Loader Class Initialized
INFO - 2024-10-03 17:22:49 --> Helper loaded: url_helper
INFO - 2024-10-03 17:22:49 --> Helper loaded: file_helper
INFO - 2024-10-03 17:22:49 --> Helper loaded: form_helper
INFO - 2024-10-03 17:22:49 --> Helper loaded: my_helper
INFO - 2024-10-03 17:22:49 --> Database Driver Class Initialized
INFO - 2024-10-03 17:22:49 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-03 17:22:49 --> Controller Class Initialized
INFO - 2024-10-03 17:22:49 --> Final output sent to browser
DEBUG - 2024-10-03 17:22:49 --> Total execution time: 0.0395
INFO - 2024-10-03 17:22:49 --> Config Class Initialized
INFO - 2024-10-03 17:22:49 --> Hooks Class Initialized
DEBUG - 2024-10-03 17:22:49 --> UTF-8 Support Enabled
INFO - 2024-10-03 17:22:49 --> Utf8 Class Initialized
INFO - 2024-10-03 17:22:49 --> URI Class Initialized
INFO - 2024-10-03 17:22:49 --> Router Class Initialized
INFO - 2024-10-03 17:22:49 --> Output Class Initialized
INFO - 2024-10-03 17:22:49 --> Security Class Initialized
DEBUG - 2024-10-03 17:22:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-03 17:22:49 --> Input Class Initialized
INFO - 2024-10-03 17:22:49 --> Language Class Initialized
INFO - 2024-10-03 17:22:49 --> Language Class Initialized
INFO - 2024-10-03 17:22:49 --> Config Class Initialized
INFO - 2024-10-03 17:22:49 --> Loader Class Initialized
INFO - 2024-10-03 17:22:49 --> Helper loaded: url_helper
INFO - 2024-10-03 17:22:49 --> Helper loaded: file_helper
INFO - 2024-10-03 17:22:49 --> Helper loaded: form_helper
INFO - 2024-10-03 17:22:49 --> Helper loaded: my_helper
INFO - 2024-10-03 17:22:49 --> Database Driver Class Initialized
INFO - 2024-10-03 17:22:49 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-03 17:22:49 --> Controller Class Initialized
INFO - 2024-10-03 17:22:51 --> Config Class Initialized
INFO - 2024-10-03 17:22:51 --> Hooks Class Initialized
DEBUG - 2024-10-03 17:22:51 --> UTF-8 Support Enabled
INFO - 2024-10-03 17:22:51 --> Utf8 Class Initialized
INFO - 2024-10-03 17:22:51 --> URI Class Initialized
INFO - 2024-10-03 17:22:51 --> Router Class Initialized
INFO - 2024-10-03 17:22:51 --> Output Class Initialized
INFO - 2024-10-03 17:22:51 --> Security Class Initialized
DEBUG - 2024-10-03 17:22:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-03 17:22:51 --> Input Class Initialized
INFO - 2024-10-03 17:22:51 --> Language Class Initialized
INFO - 2024-10-03 17:22:51 --> Language Class Initialized
INFO - 2024-10-03 17:22:51 --> Config Class Initialized
INFO - 2024-10-03 17:22:51 --> Loader Class Initialized
INFO - 2024-10-03 17:22:51 --> Helper loaded: url_helper
INFO - 2024-10-03 17:22:51 --> Helper loaded: file_helper
INFO - 2024-10-03 17:22:51 --> Helper loaded: form_helper
INFO - 2024-10-03 17:22:51 --> Helper loaded: my_helper
INFO - 2024-10-03 17:22:51 --> Database Driver Class Initialized
INFO - 2024-10-03 17:22:51 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-03 17:22:51 --> Controller Class Initialized
DEBUG - 2024-10-03 17:22:51 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/view_mapel/views/v_view_mapel.php
DEBUG - 2024-10-03 17:22:51 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-10-03 17:22:51 --> Final output sent to browser
DEBUG - 2024-10-03 17:22:51 --> Total execution time: 0.0653
INFO - 2024-10-03 17:22:53 --> Config Class Initialized
INFO - 2024-10-03 17:22:53 --> Hooks Class Initialized
DEBUG - 2024-10-03 17:22:53 --> UTF-8 Support Enabled
INFO - 2024-10-03 17:22:53 --> Utf8 Class Initialized
INFO - 2024-10-03 17:22:53 --> URI Class Initialized
INFO - 2024-10-03 17:22:53 --> Router Class Initialized
INFO - 2024-10-03 17:22:53 --> Output Class Initialized
INFO - 2024-10-03 17:22:53 --> Security Class Initialized
DEBUG - 2024-10-03 17:22:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-03 17:22:53 --> Input Class Initialized
INFO - 2024-10-03 17:22:53 --> Language Class Initialized
INFO - 2024-10-03 17:22:53 --> Language Class Initialized
INFO - 2024-10-03 17:22:53 --> Config Class Initialized
INFO - 2024-10-03 17:22:53 --> Loader Class Initialized
INFO - 2024-10-03 17:22:53 --> Helper loaded: url_helper
INFO - 2024-10-03 17:22:53 --> Helper loaded: file_helper
INFO - 2024-10-03 17:22:53 --> Helper loaded: form_helper
INFO - 2024-10-03 17:22:53 --> Helper loaded: my_helper
INFO - 2024-10-03 17:22:53 --> Database Driver Class Initialized
INFO - 2024-10-03 17:22:53 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-03 17:22:53 --> Controller Class Initialized
DEBUG - 2024-10-03 17:22:53 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/views/list.php
DEBUG - 2024-10-03 17:22:53 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-10-03 17:22:53 --> Final output sent to browser
DEBUG - 2024-10-03 17:22:53 --> Total execution time: 0.0324
INFO - 2024-10-03 17:22:53 --> Config Class Initialized
INFO - 2024-10-03 17:22:53 --> Hooks Class Initialized
DEBUG - 2024-10-03 17:22:53 --> UTF-8 Support Enabled
INFO - 2024-10-03 17:22:53 --> Utf8 Class Initialized
INFO - 2024-10-03 17:22:53 --> URI Class Initialized
INFO - 2024-10-03 17:22:53 --> Router Class Initialized
INFO - 2024-10-03 17:22:53 --> Output Class Initialized
INFO - 2024-10-03 17:22:53 --> Security Class Initialized
DEBUG - 2024-10-03 17:22:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-03 17:22:53 --> Input Class Initialized
INFO - 2024-10-03 17:22:53 --> Language Class Initialized
INFO - 2024-10-03 17:22:53 --> Language Class Initialized
INFO - 2024-10-03 17:22:53 --> Config Class Initialized
INFO - 2024-10-03 17:22:53 --> Loader Class Initialized
INFO - 2024-10-03 17:22:53 --> Helper loaded: url_helper
INFO - 2024-10-03 17:22:53 --> Helper loaded: file_helper
INFO - 2024-10-03 17:22:53 --> Helper loaded: form_helper
INFO - 2024-10-03 17:22:53 --> Helper loaded: my_helper
INFO - 2024-10-03 17:22:53 --> Database Driver Class Initialized
INFO - 2024-10-03 17:22:53 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-03 17:22:53 --> Controller Class Initialized
INFO - 2024-10-03 17:22:58 --> Config Class Initialized
INFO - 2024-10-03 17:22:58 --> Hooks Class Initialized
DEBUG - 2024-10-03 17:22:58 --> UTF-8 Support Enabled
INFO - 2024-10-03 17:22:58 --> Utf8 Class Initialized
INFO - 2024-10-03 17:22:58 --> URI Class Initialized
INFO - 2024-10-03 17:22:58 --> Router Class Initialized
INFO - 2024-10-03 17:22:58 --> Output Class Initialized
INFO - 2024-10-03 17:22:58 --> Security Class Initialized
DEBUG - 2024-10-03 17:22:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-03 17:22:58 --> Input Class Initialized
INFO - 2024-10-03 17:22:58 --> Language Class Initialized
INFO - 2024-10-03 17:22:58 --> Language Class Initialized
INFO - 2024-10-03 17:22:58 --> Config Class Initialized
INFO - 2024-10-03 17:22:58 --> Loader Class Initialized
INFO - 2024-10-03 17:22:58 --> Helper loaded: url_helper
INFO - 2024-10-03 17:22:58 --> Helper loaded: file_helper
INFO - 2024-10-03 17:22:58 --> Helper loaded: form_helper
INFO - 2024-10-03 17:22:58 --> Helper loaded: my_helper
INFO - 2024-10-03 17:22:58 --> Database Driver Class Initialized
INFO - 2024-10-03 17:22:58 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-03 17:22:58 --> Controller Class Initialized
DEBUG - 2024-10-03 17:22:58 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/view_mapel/views/v_view_mapel.php
DEBUG - 2024-10-03 17:22:58 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-10-03 17:22:58 --> Final output sent to browser
DEBUG - 2024-10-03 17:22:58 --> Total execution time: 0.0550
INFO - 2024-10-03 17:23:06 --> Config Class Initialized
INFO - 2024-10-03 17:23:06 --> Hooks Class Initialized
DEBUG - 2024-10-03 17:23:06 --> UTF-8 Support Enabled
INFO - 2024-10-03 17:23:06 --> Utf8 Class Initialized
INFO - 2024-10-03 17:23:06 --> URI Class Initialized
INFO - 2024-10-03 17:23:06 --> Router Class Initialized
INFO - 2024-10-03 17:23:06 --> Output Class Initialized
INFO - 2024-10-03 17:23:06 --> Security Class Initialized
DEBUG - 2024-10-03 17:23:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-03 17:23:06 --> Input Class Initialized
INFO - 2024-10-03 17:23:06 --> Language Class Initialized
INFO - 2024-10-03 17:23:06 --> Language Class Initialized
INFO - 2024-10-03 17:23:06 --> Config Class Initialized
INFO - 2024-10-03 17:23:06 --> Loader Class Initialized
INFO - 2024-10-03 17:23:06 --> Helper loaded: url_helper
INFO - 2024-10-03 17:23:06 --> Helper loaded: file_helper
INFO - 2024-10-03 17:23:06 --> Helper loaded: form_helper
INFO - 2024-10-03 17:23:06 --> Helper loaded: my_helper
INFO - 2024-10-03 17:23:06 --> Database Driver Class Initialized
INFO - 2024-10-03 17:23:06 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-03 17:23:06 --> Controller Class Initialized
DEBUG - 2024-10-03 17:23:06 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/views/list.php
DEBUG - 2024-10-03 17:23:06 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-10-03 17:23:06 --> Final output sent to browser
DEBUG - 2024-10-03 17:23:06 --> Total execution time: 0.0371
INFO - 2024-10-03 17:23:06 --> Config Class Initialized
INFO - 2024-10-03 17:23:06 --> Hooks Class Initialized
DEBUG - 2024-10-03 17:23:06 --> UTF-8 Support Enabled
INFO - 2024-10-03 17:23:06 --> Utf8 Class Initialized
INFO - 2024-10-03 17:23:06 --> URI Class Initialized
INFO - 2024-10-03 17:23:06 --> Router Class Initialized
INFO - 2024-10-03 17:23:06 --> Output Class Initialized
INFO - 2024-10-03 17:23:06 --> Security Class Initialized
DEBUG - 2024-10-03 17:23:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-03 17:23:06 --> Input Class Initialized
INFO - 2024-10-03 17:23:06 --> Language Class Initialized
INFO - 2024-10-03 17:23:06 --> Language Class Initialized
INFO - 2024-10-03 17:23:06 --> Config Class Initialized
INFO - 2024-10-03 17:23:06 --> Loader Class Initialized
INFO - 2024-10-03 17:23:06 --> Helper loaded: url_helper
INFO - 2024-10-03 17:23:06 --> Helper loaded: file_helper
INFO - 2024-10-03 17:23:06 --> Helper loaded: form_helper
INFO - 2024-10-03 17:23:06 --> Helper loaded: my_helper
INFO - 2024-10-03 17:23:06 --> Database Driver Class Initialized
INFO - 2024-10-03 17:23:06 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-03 17:23:06 --> Controller Class Initialized
INFO - 2024-10-03 17:23:08 --> Config Class Initialized
INFO - 2024-10-03 17:23:08 --> Hooks Class Initialized
DEBUG - 2024-10-03 17:23:08 --> UTF-8 Support Enabled
INFO - 2024-10-03 17:23:08 --> Utf8 Class Initialized
INFO - 2024-10-03 17:23:08 --> URI Class Initialized
INFO - 2024-10-03 17:23:08 --> Router Class Initialized
INFO - 2024-10-03 17:23:08 --> Output Class Initialized
INFO - 2024-10-03 17:23:08 --> Security Class Initialized
DEBUG - 2024-10-03 17:23:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-03 17:23:08 --> Input Class Initialized
INFO - 2024-10-03 17:23:08 --> Language Class Initialized
INFO - 2024-10-03 17:23:08 --> Language Class Initialized
INFO - 2024-10-03 17:23:08 --> Config Class Initialized
INFO - 2024-10-03 17:23:08 --> Loader Class Initialized
INFO - 2024-10-03 17:23:08 --> Helper loaded: url_helper
INFO - 2024-10-03 17:23:08 --> Helper loaded: file_helper
INFO - 2024-10-03 17:23:08 --> Helper loaded: form_helper
INFO - 2024-10-03 17:23:08 --> Helper loaded: my_helper
INFO - 2024-10-03 17:23:08 --> Database Driver Class Initialized
INFO - 2024-10-03 17:23:08 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-03 17:23:08 --> Controller Class Initialized
INFO - 2024-10-03 17:23:08 --> Final output sent to browser
DEBUG - 2024-10-03 17:23:08 --> Total execution time: 0.0296
INFO - 2024-10-03 17:23:12 --> Config Class Initialized
INFO - 2024-10-03 17:23:12 --> Hooks Class Initialized
DEBUG - 2024-10-03 17:23:12 --> UTF-8 Support Enabled
INFO - 2024-10-03 17:23:12 --> Utf8 Class Initialized
INFO - 2024-10-03 17:23:12 --> URI Class Initialized
INFO - 2024-10-03 17:23:12 --> Router Class Initialized
INFO - 2024-10-03 17:23:12 --> Output Class Initialized
INFO - 2024-10-03 17:23:12 --> Security Class Initialized
DEBUG - 2024-10-03 17:23:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-03 17:23:12 --> Input Class Initialized
INFO - 2024-10-03 17:23:12 --> Language Class Initialized
INFO - 2024-10-03 17:23:12 --> Language Class Initialized
INFO - 2024-10-03 17:23:12 --> Config Class Initialized
INFO - 2024-10-03 17:23:12 --> Loader Class Initialized
INFO - 2024-10-03 17:23:12 --> Helper loaded: url_helper
INFO - 2024-10-03 17:23:12 --> Helper loaded: file_helper
INFO - 2024-10-03 17:23:12 --> Helper loaded: form_helper
INFO - 2024-10-03 17:23:12 --> Helper loaded: my_helper
INFO - 2024-10-03 17:23:12 --> Database Driver Class Initialized
INFO - 2024-10-03 17:23:12 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-03 17:23:12 --> Controller Class Initialized
INFO - 2024-10-03 17:23:12 --> Final output sent to browser
DEBUG - 2024-10-03 17:23:12 --> Total execution time: 0.0379
INFO - 2024-10-03 17:23:12 --> Config Class Initialized
INFO - 2024-10-03 17:23:12 --> Hooks Class Initialized
DEBUG - 2024-10-03 17:23:12 --> UTF-8 Support Enabled
INFO - 2024-10-03 17:23:12 --> Utf8 Class Initialized
INFO - 2024-10-03 17:23:12 --> URI Class Initialized
INFO - 2024-10-03 17:23:12 --> Router Class Initialized
INFO - 2024-10-03 17:23:12 --> Output Class Initialized
INFO - 2024-10-03 17:23:12 --> Security Class Initialized
DEBUG - 2024-10-03 17:23:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-03 17:23:12 --> Input Class Initialized
INFO - 2024-10-03 17:23:12 --> Language Class Initialized
INFO - 2024-10-03 17:23:12 --> Language Class Initialized
INFO - 2024-10-03 17:23:12 --> Config Class Initialized
INFO - 2024-10-03 17:23:12 --> Loader Class Initialized
INFO - 2024-10-03 17:23:12 --> Helper loaded: url_helper
INFO - 2024-10-03 17:23:12 --> Helper loaded: file_helper
INFO - 2024-10-03 17:23:12 --> Helper loaded: form_helper
INFO - 2024-10-03 17:23:12 --> Helper loaded: my_helper
INFO - 2024-10-03 17:23:12 --> Database Driver Class Initialized
INFO - 2024-10-03 17:23:12 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-03 17:23:12 --> Controller Class Initialized
INFO - 2024-10-03 17:23:25 --> Config Class Initialized
INFO - 2024-10-03 17:23:25 --> Hooks Class Initialized
DEBUG - 2024-10-03 17:23:25 --> UTF-8 Support Enabled
INFO - 2024-10-03 17:23:25 --> Utf8 Class Initialized
INFO - 2024-10-03 17:23:25 --> URI Class Initialized
INFO - 2024-10-03 17:23:25 --> Router Class Initialized
INFO - 2024-10-03 17:23:25 --> Output Class Initialized
INFO - 2024-10-03 17:23:25 --> Security Class Initialized
DEBUG - 2024-10-03 17:23:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-03 17:23:25 --> Input Class Initialized
INFO - 2024-10-03 17:23:25 --> Language Class Initialized
INFO - 2024-10-03 17:23:25 --> Language Class Initialized
INFO - 2024-10-03 17:23:25 --> Config Class Initialized
INFO - 2024-10-03 17:23:25 --> Loader Class Initialized
INFO - 2024-10-03 17:23:25 --> Helper loaded: url_helper
INFO - 2024-10-03 17:23:25 --> Helper loaded: file_helper
INFO - 2024-10-03 17:23:25 --> Helper loaded: form_helper
INFO - 2024-10-03 17:23:25 --> Helper loaded: my_helper
INFO - 2024-10-03 17:23:25 --> Database Driver Class Initialized
INFO - 2024-10-03 17:23:25 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-03 17:23:25 --> Controller Class Initialized
INFO - 2024-10-03 17:23:25 --> Final output sent to browser
DEBUG - 2024-10-03 17:23:25 --> Total execution time: 0.0288
INFO - 2024-10-03 17:23:32 --> Config Class Initialized
INFO - 2024-10-03 17:23:32 --> Hooks Class Initialized
DEBUG - 2024-10-03 17:23:32 --> UTF-8 Support Enabled
INFO - 2024-10-03 17:23:32 --> Utf8 Class Initialized
INFO - 2024-10-03 17:23:32 --> URI Class Initialized
INFO - 2024-10-03 17:23:32 --> Router Class Initialized
INFO - 2024-10-03 17:23:32 --> Output Class Initialized
INFO - 2024-10-03 17:23:32 --> Security Class Initialized
DEBUG - 2024-10-03 17:23:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-03 17:23:32 --> Input Class Initialized
INFO - 2024-10-03 17:23:32 --> Language Class Initialized
INFO - 2024-10-03 17:23:32 --> Language Class Initialized
INFO - 2024-10-03 17:23:32 --> Config Class Initialized
INFO - 2024-10-03 17:23:32 --> Loader Class Initialized
INFO - 2024-10-03 17:23:32 --> Helper loaded: url_helper
INFO - 2024-10-03 17:23:32 --> Helper loaded: file_helper
INFO - 2024-10-03 17:23:32 --> Helper loaded: form_helper
INFO - 2024-10-03 17:23:32 --> Helper loaded: my_helper
INFO - 2024-10-03 17:23:32 --> Database Driver Class Initialized
INFO - 2024-10-03 17:23:32 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-03 17:23:32 --> Controller Class Initialized
INFO - 2024-10-03 17:23:32 --> Final output sent to browser
DEBUG - 2024-10-03 17:23:32 --> Total execution time: 0.0377
INFO - 2024-10-03 17:23:32 --> Config Class Initialized
INFO - 2024-10-03 17:23:32 --> Hooks Class Initialized
DEBUG - 2024-10-03 17:23:32 --> UTF-8 Support Enabled
INFO - 2024-10-03 17:23:32 --> Utf8 Class Initialized
INFO - 2024-10-03 17:23:32 --> URI Class Initialized
INFO - 2024-10-03 17:23:32 --> Router Class Initialized
INFO - 2024-10-03 17:23:32 --> Output Class Initialized
INFO - 2024-10-03 17:23:32 --> Security Class Initialized
DEBUG - 2024-10-03 17:23:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-03 17:23:32 --> Input Class Initialized
INFO - 2024-10-03 17:23:32 --> Language Class Initialized
INFO - 2024-10-03 17:23:32 --> Language Class Initialized
INFO - 2024-10-03 17:23:32 --> Config Class Initialized
INFO - 2024-10-03 17:23:32 --> Loader Class Initialized
INFO - 2024-10-03 17:23:32 --> Helper loaded: url_helper
INFO - 2024-10-03 17:23:32 --> Helper loaded: file_helper
INFO - 2024-10-03 17:23:32 --> Helper loaded: form_helper
INFO - 2024-10-03 17:23:32 --> Helper loaded: my_helper
INFO - 2024-10-03 17:23:32 --> Database Driver Class Initialized
INFO - 2024-10-03 17:23:32 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-03 17:23:32 --> Controller Class Initialized
INFO - 2024-10-03 17:23:33 --> Config Class Initialized
INFO - 2024-10-03 17:23:33 --> Hooks Class Initialized
DEBUG - 2024-10-03 17:23:33 --> UTF-8 Support Enabled
INFO - 2024-10-03 17:23:33 --> Utf8 Class Initialized
INFO - 2024-10-03 17:23:33 --> URI Class Initialized
INFO - 2024-10-03 17:23:33 --> Router Class Initialized
INFO - 2024-10-03 17:23:33 --> Output Class Initialized
INFO - 2024-10-03 17:23:33 --> Security Class Initialized
DEBUG - 2024-10-03 17:23:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-03 17:23:33 --> Input Class Initialized
INFO - 2024-10-03 17:23:33 --> Language Class Initialized
INFO - 2024-10-03 17:23:33 --> Language Class Initialized
INFO - 2024-10-03 17:23:33 --> Config Class Initialized
INFO - 2024-10-03 17:23:33 --> Loader Class Initialized
INFO - 2024-10-03 17:23:33 --> Helper loaded: url_helper
INFO - 2024-10-03 17:23:33 --> Helper loaded: file_helper
INFO - 2024-10-03 17:23:33 --> Helper loaded: form_helper
INFO - 2024-10-03 17:23:33 --> Helper loaded: my_helper
INFO - 2024-10-03 17:23:33 --> Database Driver Class Initialized
INFO - 2024-10-03 17:23:33 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-03 17:23:33 --> Controller Class Initialized
INFO - 2024-10-03 17:23:33 --> Final output sent to browser
DEBUG - 2024-10-03 17:23:33 --> Total execution time: 0.0312
INFO - 2024-10-03 17:23:49 --> Config Class Initialized
INFO - 2024-10-03 17:23:49 --> Hooks Class Initialized
DEBUG - 2024-10-03 17:23:49 --> UTF-8 Support Enabled
INFO - 2024-10-03 17:23:49 --> Utf8 Class Initialized
INFO - 2024-10-03 17:23:49 --> URI Class Initialized
INFO - 2024-10-03 17:23:49 --> Router Class Initialized
INFO - 2024-10-03 17:23:49 --> Output Class Initialized
INFO - 2024-10-03 17:23:49 --> Security Class Initialized
DEBUG - 2024-10-03 17:23:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-03 17:23:49 --> Input Class Initialized
INFO - 2024-10-03 17:23:49 --> Language Class Initialized
INFO - 2024-10-03 17:23:49 --> Language Class Initialized
INFO - 2024-10-03 17:23:49 --> Config Class Initialized
INFO - 2024-10-03 17:23:49 --> Loader Class Initialized
INFO - 2024-10-03 17:23:49 --> Helper loaded: url_helper
INFO - 2024-10-03 17:23:49 --> Helper loaded: file_helper
INFO - 2024-10-03 17:23:49 --> Helper loaded: form_helper
INFO - 2024-10-03 17:23:49 --> Helper loaded: my_helper
INFO - 2024-10-03 17:23:49 --> Database Driver Class Initialized
INFO - 2024-10-03 17:23:49 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-03 17:23:49 --> Controller Class Initialized
INFO - 2024-10-03 17:23:49 --> Final output sent to browser
DEBUG - 2024-10-03 17:23:49 --> Total execution time: 0.0393
INFO - 2024-10-03 17:23:49 --> Config Class Initialized
INFO - 2024-10-03 17:23:49 --> Hooks Class Initialized
DEBUG - 2024-10-03 17:23:49 --> UTF-8 Support Enabled
INFO - 2024-10-03 17:23:49 --> Utf8 Class Initialized
INFO - 2024-10-03 17:23:49 --> URI Class Initialized
INFO - 2024-10-03 17:23:49 --> Router Class Initialized
INFO - 2024-10-03 17:23:49 --> Output Class Initialized
INFO - 2024-10-03 17:23:49 --> Security Class Initialized
DEBUG - 2024-10-03 17:23:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-03 17:23:49 --> Input Class Initialized
INFO - 2024-10-03 17:23:49 --> Language Class Initialized
INFO - 2024-10-03 17:23:49 --> Language Class Initialized
INFO - 2024-10-03 17:23:49 --> Config Class Initialized
INFO - 2024-10-03 17:23:49 --> Loader Class Initialized
INFO - 2024-10-03 17:23:49 --> Helper loaded: url_helper
INFO - 2024-10-03 17:23:49 --> Helper loaded: file_helper
INFO - 2024-10-03 17:23:49 --> Helper loaded: form_helper
INFO - 2024-10-03 17:23:49 --> Helper loaded: my_helper
INFO - 2024-10-03 17:23:49 --> Database Driver Class Initialized
INFO - 2024-10-03 17:23:49 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-03 17:23:49 --> Controller Class Initialized
INFO - 2024-10-03 17:23:50 --> Config Class Initialized
INFO - 2024-10-03 17:23:50 --> Hooks Class Initialized
DEBUG - 2024-10-03 17:23:50 --> UTF-8 Support Enabled
INFO - 2024-10-03 17:23:50 --> Utf8 Class Initialized
INFO - 2024-10-03 17:23:50 --> URI Class Initialized
INFO - 2024-10-03 17:23:50 --> Router Class Initialized
INFO - 2024-10-03 17:23:50 --> Output Class Initialized
INFO - 2024-10-03 17:23:50 --> Security Class Initialized
DEBUG - 2024-10-03 17:23:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-03 17:23:50 --> Input Class Initialized
INFO - 2024-10-03 17:23:50 --> Language Class Initialized
INFO - 2024-10-03 17:23:50 --> Language Class Initialized
INFO - 2024-10-03 17:23:50 --> Config Class Initialized
INFO - 2024-10-03 17:23:50 --> Loader Class Initialized
INFO - 2024-10-03 17:23:50 --> Helper loaded: url_helper
INFO - 2024-10-03 17:23:50 --> Helper loaded: file_helper
INFO - 2024-10-03 17:23:50 --> Helper loaded: form_helper
INFO - 2024-10-03 17:23:50 --> Helper loaded: my_helper
INFO - 2024-10-03 17:23:51 --> Database Driver Class Initialized
INFO - 2024-10-03 17:23:51 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-03 17:23:51 --> Controller Class Initialized
INFO - 2024-10-03 17:23:51 --> Final output sent to browser
DEBUG - 2024-10-03 17:23:51 --> Total execution time: 0.0355
INFO - 2024-10-03 17:24:04 --> Config Class Initialized
INFO - 2024-10-03 17:24:04 --> Hooks Class Initialized
DEBUG - 2024-10-03 17:24:04 --> UTF-8 Support Enabled
INFO - 2024-10-03 17:24:04 --> Utf8 Class Initialized
INFO - 2024-10-03 17:24:04 --> URI Class Initialized
INFO - 2024-10-03 17:24:04 --> Router Class Initialized
INFO - 2024-10-03 17:24:04 --> Output Class Initialized
INFO - 2024-10-03 17:24:04 --> Security Class Initialized
DEBUG - 2024-10-03 17:24:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-03 17:24:04 --> Input Class Initialized
INFO - 2024-10-03 17:24:04 --> Language Class Initialized
INFO - 2024-10-03 17:24:04 --> Language Class Initialized
INFO - 2024-10-03 17:24:04 --> Config Class Initialized
INFO - 2024-10-03 17:24:04 --> Loader Class Initialized
INFO - 2024-10-03 17:24:04 --> Helper loaded: url_helper
INFO - 2024-10-03 17:24:04 --> Helper loaded: file_helper
INFO - 2024-10-03 17:24:04 --> Helper loaded: form_helper
INFO - 2024-10-03 17:24:04 --> Helper loaded: my_helper
INFO - 2024-10-03 17:24:04 --> Database Driver Class Initialized
INFO - 2024-10-03 17:24:04 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-03 17:24:04 --> Controller Class Initialized
INFO - 2024-10-03 17:24:04 --> Final output sent to browser
DEBUG - 2024-10-03 17:24:04 --> Total execution time: 0.1159
INFO - 2024-10-03 17:24:04 --> Config Class Initialized
INFO - 2024-10-03 17:24:04 --> Hooks Class Initialized
DEBUG - 2024-10-03 17:24:04 --> UTF-8 Support Enabled
INFO - 2024-10-03 17:24:04 --> Utf8 Class Initialized
INFO - 2024-10-03 17:24:04 --> URI Class Initialized
INFO - 2024-10-03 17:24:04 --> Router Class Initialized
INFO - 2024-10-03 17:24:04 --> Output Class Initialized
INFO - 2024-10-03 17:24:04 --> Security Class Initialized
DEBUG - 2024-10-03 17:24:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-03 17:24:04 --> Input Class Initialized
INFO - 2024-10-03 17:24:04 --> Language Class Initialized
INFO - 2024-10-03 17:24:04 --> Language Class Initialized
INFO - 2024-10-03 17:24:04 --> Config Class Initialized
INFO - 2024-10-03 17:24:04 --> Loader Class Initialized
INFO - 2024-10-03 17:24:04 --> Helper loaded: url_helper
INFO - 2024-10-03 17:24:04 --> Helper loaded: file_helper
INFO - 2024-10-03 17:24:04 --> Helper loaded: form_helper
INFO - 2024-10-03 17:24:04 --> Helper loaded: my_helper
INFO - 2024-10-03 17:24:04 --> Database Driver Class Initialized
INFO - 2024-10-03 17:24:04 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-03 17:24:04 --> Controller Class Initialized
INFO - 2024-10-03 17:24:07 --> Config Class Initialized
INFO - 2024-10-03 17:24:07 --> Hooks Class Initialized
DEBUG - 2024-10-03 17:24:07 --> UTF-8 Support Enabled
INFO - 2024-10-03 17:24:07 --> Utf8 Class Initialized
INFO - 2024-10-03 17:24:07 --> URI Class Initialized
INFO - 2024-10-03 17:24:07 --> Router Class Initialized
INFO - 2024-10-03 17:24:07 --> Output Class Initialized
INFO - 2024-10-03 17:24:07 --> Security Class Initialized
DEBUG - 2024-10-03 17:24:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-03 17:24:07 --> Input Class Initialized
INFO - 2024-10-03 17:24:07 --> Language Class Initialized
INFO - 2024-10-03 17:24:07 --> Language Class Initialized
INFO - 2024-10-03 17:24:07 --> Config Class Initialized
INFO - 2024-10-03 17:24:07 --> Loader Class Initialized
INFO - 2024-10-03 17:24:07 --> Helper loaded: url_helper
INFO - 2024-10-03 17:24:07 --> Helper loaded: file_helper
INFO - 2024-10-03 17:24:07 --> Helper loaded: form_helper
INFO - 2024-10-03 17:24:07 --> Helper loaded: my_helper
INFO - 2024-10-03 17:24:07 --> Database Driver Class Initialized
INFO - 2024-10-03 17:24:07 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-03 17:24:07 --> Controller Class Initialized
INFO - 2024-10-03 17:24:07 --> Final output sent to browser
DEBUG - 2024-10-03 17:24:07 --> Total execution time: 0.0640
INFO - 2024-10-03 17:26:23 --> Config Class Initialized
INFO - 2024-10-03 17:26:23 --> Hooks Class Initialized
DEBUG - 2024-10-03 17:26:23 --> UTF-8 Support Enabled
INFO - 2024-10-03 17:26:23 --> Utf8 Class Initialized
INFO - 2024-10-03 17:26:23 --> URI Class Initialized
INFO - 2024-10-03 17:26:23 --> Router Class Initialized
INFO - 2024-10-03 17:26:23 --> Output Class Initialized
INFO - 2024-10-03 17:26:23 --> Security Class Initialized
DEBUG - 2024-10-03 17:26:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-03 17:26:23 --> Input Class Initialized
INFO - 2024-10-03 17:26:23 --> Language Class Initialized
INFO - 2024-10-03 17:26:23 --> Language Class Initialized
INFO - 2024-10-03 17:26:23 --> Config Class Initialized
INFO - 2024-10-03 17:26:23 --> Loader Class Initialized
INFO - 2024-10-03 17:26:23 --> Helper loaded: url_helper
INFO - 2024-10-03 17:26:23 --> Helper loaded: file_helper
INFO - 2024-10-03 17:26:23 --> Helper loaded: form_helper
INFO - 2024-10-03 17:26:23 --> Helper loaded: my_helper
INFO - 2024-10-03 17:26:23 --> Database Driver Class Initialized
INFO - 2024-10-03 17:26:23 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-03 17:26:23 --> Controller Class Initialized
INFO - 2024-10-03 17:26:23 --> Final output sent to browser
DEBUG - 2024-10-03 17:26:23 --> Total execution time: 0.0584
INFO - 2024-10-03 17:26:34 --> Config Class Initialized
INFO - 2024-10-03 17:26:34 --> Hooks Class Initialized
DEBUG - 2024-10-03 17:26:34 --> UTF-8 Support Enabled
INFO - 2024-10-03 17:26:34 --> Utf8 Class Initialized
INFO - 2024-10-03 17:26:34 --> URI Class Initialized
INFO - 2024-10-03 17:26:34 --> Router Class Initialized
INFO - 2024-10-03 17:26:34 --> Output Class Initialized
INFO - 2024-10-03 17:26:34 --> Security Class Initialized
DEBUG - 2024-10-03 17:26:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-03 17:26:34 --> Input Class Initialized
INFO - 2024-10-03 17:26:34 --> Language Class Initialized
INFO - 2024-10-03 17:26:34 --> Language Class Initialized
INFO - 2024-10-03 17:26:34 --> Config Class Initialized
INFO - 2024-10-03 17:26:34 --> Loader Class Initialized
INFO - 2024-10-03 17:26:34 --> Helper loaded: url_helper
INFO - 2024-10-03 17:26:34 --> Helper loaded: file_helper
INFO - 2024-10-03 17:26:34 --> Helper loaded: form_helper
INFO - 2024-10-03 17:26:34 --> Helper loaded: my_helper
INFO - 2024-10-03 17:26:34 --> Database Driver Class Initialized
INFO - 2024-10-03 17:26:34 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-03 17:26:34 --> Controller Class Initialized
INFO - 2024-10-03 17:26:34 --> Final output sent to browser
DEBUG - 2024-10-03 17:26:34 --> Total execution time: 0.0342
INFO - 2024-10-03 17:26:35 --> Config Class Initialized
INFO - 2024-10-03 17:26:35 --> Hooks Class Initialized
DEBUG - 2024-10-03 17:26:35 --> UTF-8 Support Enabled
INFO - 2024-10-03 17:26:35 --> Utf8 Class Initialized
INFO - 2024-10-03 17:26:35 --> URI Class Initialized
INFO - 2024-10-03 17:26:35 --> Router Class Initialized
INFO - 2024-10-03 17:26:35 --> Output Class Initialized
INFO - 2024-10-03 17:26:35 --> Security Class Initialized
DEBUG - 2024-10-03 17:26:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-03 17:26:35 --> Input Class Initialized
INFO - 2024-10-03 17:26:35 --> Language Class Initialized
INFO - 2024-10-03 17:26:35 --> Language Class Initialized
INFO - 2024-10-03 17:26:35 --> Config Class Initialized
INFO - 2024-10-03 17:26:35 --> Loader Class Initialized
INFO - 2024-10-03 17:26:35 --> Helper loaded: url_helper
INFO - 2024-10-03 17:26:35 --> Helper loaded: file_helper
INFO - 2024-10-03 17:26:35 --> Helper loaded: form_helper
INFO - 2024-10-03 17:26:35 --> Helper loaded: my_helper
INFO - 2024-10-03 17:26:35 --> Database Driver Class Initialized
INFO - 2024-10-03 17:26:35 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-03 17:26:35 --> Controller Class Initialized
INFO - 2024-10-03 17:26:35 --> Final output sent to browser
DEBUG - 2024-10-03 17:26:35 --> Total execution time: 0.0549
INFO - 2024-10-03 17:26:42 --> Config Class Initialized
INFO - 2024-10-03 17:26:42 --> Hooks Class Initialized
DEBUG - 2024-10-03 17:26:42 --> UTF-8 Support Enabled
INFO - 2024-10-03 17:26:42 --> Utf8 Class Initialized
INFO - 2024-10-03 17:26:42 --> URI Class Initialized
INFO - 2024-10-03 17:26:42 --> Router Class Initialized
INFO - 2024-10-03 17:26:42 --> Output Class Initialized
INFO - 2024-10-03 17:26:42 --> Security Class Initialized
DEBUG - 2024-10-03 17:26:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-03 17:26:42 --> Input Class Initialized
INFO - 2024-10-03 17:26:42 --> Language Class Initialized
INFO - 2024-10-03 17:26:42 --> Language Class Initialized
INFO - 2024-10-03 17:26:42 --> Config Class Initialized
INFO - 2024-10-03 17:26:42 --> Loader Class Initialized
INFO - 2024-10-03 17:26:42 --> Helper loaded: url_helper
INFO - 2024-10-03 17:26:42 --> Helper loaded: file_helper
INFO - 2024-10-03 17:26:42 --> Helper loaded: form_helper
INFO - 2024-10-03 17:26:42 --> Helper loaded: my_helper
INFO - 2024-10-03 17:26:42 --> Database Driver Class Initialized
INFO - 2024-10-03 17:26:42 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-03 17:26:42 --> Controller Class Initialized
INFO - 2024-10-03 17:26:42 --> Final output sent to browser
DEBUG - 2024-10-03 17:26:42 --> Total execution time: 0.0487
INFO - 2024-10-03 17:26:42 --> Config Class Initialized
INFO - 2024-10-03 17:26:42 --> Hooks Class Initialized
DEBUG - 2024-10-03 17:26:42 --> UTF-8 Support Enabled
INFO - 2024-10-03 17:26:42 --> Utf8 Class Initialized
INFO - 2024-10-03 17:26:42 --> URI Class Initialized
INFO - 2024-10-03 17:26:42 --> Router Class Initialized
INFO - 2024-10-03 17:26:42 --> Output Class Initialized
INFO - 2024-10-03 17:26:42 --> Security Class Initialized
DEBUG - 2024-10-03 17:26:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-03 17:26:42 --> Input Class Initialized
INFO - 2024-10-03 17:26:42 --> Language Class Initialized
INFO - 2024-10-03 17:26:42 --> Language Class Initialized
INFO - 2024-10-03 17:26:42 --> Config Class Initialized
INFO - 2024-10-03 17:26:42 --> Loader Class Initialized
INFO - 2024-10-03 17:26:42 --> Helper loaded: url_helper
INFO - 2024-10-03 17:26:42 --> Helper loaded: file_helper
INFO - 2024-10-03 17:26:42 --> Helper loaded: form_helper
INFO - 2024-10-03 17:26:42 --> Helper loaded: my_helper
INFO - 2024-10-03 17:26:42 --> Database Driver Class Initialized
INFO - 2024-10-03 17:26:42 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-03 17:26:42 --> Controller Class Initialized
INFO - 2024-10-03 17:26:44 --> Config Class Initialized
INFO - 2024-10-03 17:26:44 --> Hooks Class Initialized
DEBUG - 2024-10-03 17:26:44 --> UTF-8 Support Enabled
INFO - 2024-10-03 17:26:44 --> Utf8 Class Initialized
INFO - 2024-10-03 17:26:44 --> URI Class Initialized
INFO - 2024-10-03 17:26:44 --> Router Class Initialized
INFO - 2024-10-03 17:26:44 --> Output Class Initialized
INFO - 2024-10-03 17:26:44 --> Security Class Initialized
DEBUG - 2024-10-03 17:26:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-03 17:26:44 --> Input Class Initialized
INFO - 2024-10-03 17:26:44 --> Language Class Initialized
INFO - 2024-10-03 17:26:44 --> Language Class Initialized
INFO - 2024-10-03 17:26:44 --> Config Class Initialized
INFO - 2024-10-03 17:26:44 --> Loader Class Initialized
INFO - 2024-10-03 17:26:44 --> Helper loaded: url_helper
INFO - 2024-10-03 17:26:44 --> Helper loaded: file_helper
INFO - 2024-10-03 17:26:44 --> Helper loaded: form_helper
INFO - 2024-10-03 17:26:44 --> Helper loaded: my_helper
INFO - 2024-10-03 17:26:44 --> Database Driver Class Initialized
INFO - 2024-10-03 17:26:44 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-03 17:26:44 --> Controller Class Initialized
INFO - 2024-10-03 17:26:44 --> Final output sent to browser
DEBUG - 2024-10-03 17:26:44 --> Total execution time: 0.0446
INFO - 2024-10-03 17:27:56 --> Config Class Initialized
INFO - 2024-10-03 17:27:56 --> Hooks Class Initialized
DEBUG - 2024-10-03 17:27:56 --> UTF-8 Support Enabled
INFO - 2024-10-03 17:27:56 --> Utf8 Class Initialized
INFO - 2024-10-03 17:27:56 --> URI Class Initialized
INFO - 2024-10-03 17:27:56 --> Router Class Initialized
INFO - 2024-10-03 17:27:56 --> Output Class Initialized
INFO - 2024-10-03 17:27:56 --> Security Class Initialized
DEBUG - 2024-10-03 17:27:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-03 17:27:56 --> Input Class Initialized
INFO - 2024-10-03 17:27:56 --> Language Class Initialized
INFO - 2024-10-03 17:27:56 --> Language Class Initialized
INFO - 2024-10-03 17:27:56 --> Config Class Initialized
INFO - 2024-10-03 17:27:56 --> Loader Class Initialized
INFO - 2024-10-03 17:27:56 --> Helper loaded: url_helper
INFO - 2024-10-03 17:27:56 --> Helper loaded: file_helper
INFO - 2024-10-03 17:27:56 --> Helper loaded: form_helper
INFO - 2024-10-03 17:27:56 --> Helper loaded: my_helper
INFO - 2024-10-03 17:27:56 --> Database Driver Class Initialized
INFO - 2024-10-03 17:27:56 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-03 17:27:56 --> Controller Class Initialized
INFO - 2024-10-03 17:27:56 --> Final output sent to browser
DEBUG - 2024-10-03 17:27:56 --> Total execution time: 0.0552
INFO - 2024-10-03 17:28:49 --> Config Class Initialized
INFO - 2024-10-03 17:28:49 --> Hooks Class Initialized
DEBUG - 2024-10-03 17:28:49 --> UTF-8 Support Enabled
INFO - 2024-10-03 17:28:49 --> Utf8 Class Initialized
INFO - 2024-10-03 17:28:49 --> URI Class Initialized
INFO - 2024-10-03 17:28:49 --> Router Class Initialized
INFO - 2024-10-03 17:28:49 --> Output Class Initialized
INFO - 2024-10-03 17:28:49 --> Security Class Initialized
DEBUG - 2024-10-03 17:28:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-03 17:28:49 --> Input Class Initialized
INFO - 2024-10-03 17:28:49 --> Language Class Initialized
INFO - 2024-10-03 17:28:49 --> Language Class Initialized
INFO - 2024-10-03 17:28:49 --> Config Class Initialized
INFO - 2024-10-03 17:28:49 --> Loader Class Initialized
INFO - 2024-10-03 17:28:49 --> Helper loaded: url_helper
INFO - 2024-10-03 17:28:49 --> Helper loaded: file_helper
INFO - 2024-10-03 17:28:49 --> Helper loaded: form_helper
INFO - 2024-10-03 17:28:49 --> Helper loaded: my_helper
INFO - 2024-10-03 17:28:49 --> Database Driver Class Initialized
INFO - 2024-10-03 17:28:49 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-03 17:28:49 --> Controller Class Initialized
INFO - 2024-10-03 17:28:49 --> Final output sent to browser
DEBUG - 2024-10-03 17:28:49 --> Total execution time: 0.0592
