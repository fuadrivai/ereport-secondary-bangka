<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2024-07-11 00:58:10 --> Config Class Initialized
INFO - 2024-07-11 00:58:10 --> Hooks Class Initialized
DEBUG - 2024-07-11 00:58:10 --> UTF-8 Support Enabled
INFO - 2024-07-11 00:58:10 --> Utf8 Class Initialized
INFO - 2024-07-11 00:58:10 --> URI Class Initialized
INFO - 2024-07-11 00:58:10 --> Router Class Initialized
INFO - 2024-07-11 00:58:10 --> Output Class Initialized
INFO - 2024-07-11 00:58:10 --> Security Class Initialized
DEBUG - 2024-07-11 00:58:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-07-11 00:58:10 --> Input Class Initialized
INFO - 2024-07-11 00:58:10 --> Language Class Initialized
INFO - 2024-07-11 00:58:10 --> Language Class Initialized
INFO - 2024-07-11 00:58:10 --> Config Class Initialized
INFO - 2024-07-11 00:58:10 --> Loader Class Initialized
INFO - 2024-07-11 00:58:10 --> Helper loaded: url_helper
INFO - 2024-07-11 00:58:10 --> Helper loaded: file_helper
INFO - 2024-07-11 00:58:10 --> Helper loaded: form_helper
INFO - 2024-07-11 00:58:10 --> Helper loaded: my_helper
INFO - 2024-07-11 00:58:10 --> Database Driver Class Initialized
ERROR - 2024-07-11 00:58:10 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/report.mhis.link/bangka/secondary/system/database/drivers/mysqli/mysqli_driver.php 201
ERROR - 2024-07-11 00:58:10 --> Unable to connect to the database
INFO - 2024-07-11 00:58:10 --> Language file loaded: language/english/db_lang.php
INFO - 2024-07-11 00:59:20 --> Config Class Initialized
INFO - 2024-07-11 00:59:20 --> Hooks Class Initialized
DEBUG - 2024-07-11 00:59:20 --> UTF-8 Support Enabled
INFO - 2024-07-11 00:59:20 --> Utf8 Class Initialized
INFO - 2024-07-11 00:59:20 --> URI Class Initialized
INFO - 2024-07-11 00:59:20 --> Router Class Initialized
INFO - 2024-07-11 00:59:20 --> Output Class Initialized
INFO - 2024-07-11 00:59:20 --> Security Class Initialized
DEBUG - 2024-07-11 00:59:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-07-11 00:59:20 --> Input Class Initialized
INFO - 2024-07-11 00:59:20 --> Language Class Initialized
INFO - 2024-07-11 00:59:20 --> Language Class Initialized
INFO - 2024-07-11 00:59:20 --> Config Class Initialized
INFO - 2024-07-11 00:59:20 --> Loader Class Initialized
INFO - 2024-07-11 00:59:20 --> Helper loaded: url_helper
INFO - 2024-07-11 00:59:20 --> Helper loaded: file_helper
INFO - 2024-07-11 00:59:20 --> Helper loaded: form_helper
INFO - 2024-07-11 00:59:20 --> Helper loaded: my_helper
INFO - 2024-07-11 00:59:20 --> Database Driver Class Initialized
ERROR - 2024-07-11 00:59:20 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/report.mhis.link/bangka/secondary/system/database/drivers/mysqli/mysqli_driver.php 201
ERROR - 2024-07-11 00:59:20 --> Unable to connect to the database
INFO - 2024-07-11 00:59:20 --> Language file loaded: language/english/db_lang.php
INFO - 2024-07-11 00:59:52 --> Config Class Initialized
INFO - 2024-07-11 00:59:52 --> Hooks Class Initialized
DEBUG - 2024-07-11 00:59:52 --> UTF-8 Support Enabled
INFO - 2024-07-11 00:59:52 --> Utf8 Class Initialized
INFO - 2024-07-11 00:59:52 --> URI Class Initialized
INFO - 2024-07-11 00:59:52 --> Router Class Initialized
INFO - 2024-07-11 00:59:52 --> Output Class Initialized
INFO - 2024-07-11 00:59:52 --> Security Class Initialized
DEBUG - 2024-07-11 00:59:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-07-11 00:59:52 --> Input Class Initialized
INFO - 2024-07-11 00:59:52 --> Language Class Initialized
INFO - 2024-07-11 00:59:52 --> Language Class Initialized
INFO - 2024-07-11 00:59:52 --> Config Class Initialized
INFO - 2024-07-11 00:59:52 --> Loader Class Initialized
INFO - 2024-07-11 00:59:52 --> Helper loaded: url_helper
INFO - 2024-07-11 00:59:52 --> Helper loaded: file_helper
INFO - 2024-07-11 00:59:52 --> Helper loaded: form_helper
INFO - 2024-07-11 00:59:52 --> Helper loaded: my_helper
INFO - 2024-07-11 00:59:52 --> Database Driver Class Initialized
ERROR - 2024-07-11 00:59:52 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /www/wwwroot/report.mhis.link/bangka/secondary/system/database/drivers/mysqli/mysqli_driver.php 201
ERROR - 2024-07-11 00:59:52 --> Unable to connect to the database
INFO - 2024-07-11 00:59:52 --> Language file loaded: language/english/db_lang.php
