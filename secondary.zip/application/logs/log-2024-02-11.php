<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2024-02-11 10:49:02 --> Config Class Initialized
INFO - 2024-02-11 10:49:02 --> Hooks Class Initialized
DEBUG - 2024-02-11 10:49:02 --> UTF-8 Support Enabled
INFO - 2024-02-11 10:49:02 --> Utf8 Class Initialized
INFO - 2024-02-11 10:49:02 --> URI Class Initialized
INFO - 2024-02-11 10:49:02 --> Router Class Initialized
INFO - 2024-02-11 10:49:02 --> Output Class Initialized
INFO - 2024-02-11 10:49:02 --> Security Class Initialized
DEBUG - 2024-02-11 10:49:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-11 10:49:02 --> Input Class Initialized
INFO - 2024-02-11 10:49:02 --> Language Class Initialized
INFO - 2024-02-11 10:49:02 --> Language Class Initialized
INFO - 2024-02-11 10:49:02 --> Config Class Initialized
INFO - 2024-02-11 10:49:02 --> Loader Class Initialized
INFO - 2024-02-11 10:49:02 --> Helper loaded: url_helper
INFO - 2024-02-11 10:49:02 --> Helper loaded: file_helper
INFO - 2024-02-11 10:49:02 --> Helper loaded: form_helper
INFO - 2024-02-11 10:49:02 --> Helper loaded: my_helper
INFO - 2024-02-11 10:49:02 --> Database Driver Class Initialized
INFO - 2024-02-11 10:49:02 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-11 10:49:02 --> Controller Class Initialized
INFO - 2024-02-11 10:49:02 --> Helper loaded: cookie_helper
INFO - 2024-02-11 10:49:02 --> Final output sent to browser
DEBUG - 2024-02-11 10:49:02 --> Total execution time: 0.1533
INFO - 2024-02-11 10:49:03 --> Config Class Initialized
INFO - 2024-02-11 10:49:03 --> Hooks Class Initialized
DEBUG - 2024-02-11 10:49:03 --> UTF-8 Support Enabled
INFO - 2024-02-11 10:49:03 --> Utf8 Class Initialized
INFO - 2024-02-11 10:49:03 --> URI Class Initialized
INFO - 2024-02-11 10:49:03 --> Router Class Initialized
INFO - 2024-02-11 10:49:03 --> Output Class Initialized
INFO - 2024-02-11 10:49:03 --> Security Class Initialized
DEBUG - 2024-02-11 10:49:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-11 10:49:03 --> Input Class Initialized
INFO - 2024-02-11 10:49:03 --> Language Class Initialized
INFO - 2024-02-11 10:49:03 --> Language Class Initialized
INFO - 2024-02-11 10:49:03 --> Config Class Initialized
INFO - 2024-02-11 10:49:03 --> Loader Class Initialized
INFO - 2024-02-11 10:49:03 --> Helper loaded: url_helper
INFO - 2024-02-11 10:49:03 --> Helper loaded: file_helper
INFO - 2024-02-11 10:49:03 --> Helper loaded: form_helper
INFO - 2024-02-11 10:49:03 --> Helper loaded: my_helper
INFO - 2024-02-11 10:49:03 --> Database Driver Class Initialized
INFO - 2024-02-11 10:49:03 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-11 10:49:03 --> Controller Class Initialized
INFO - 2024-02-11 10:49:03 --> Helper loaded: cookie_helper
INFO - 2024-02-11 10:49:04 --> Config Class Initialized
INFO - 2024-02-11 10:49:04 --> Hooks Class Initialized
DEBUG - 2024-02-11 10:49:04 --> UTF-8 Support Enabled
INFO - 2024-02-11 10:49:04 --> Utf8 Class Initialized
INFO - 2024-02-11 10:49:04 --> URI Class Initialized
INFO - 2024-02-11 10:49:04 --> Router Class Initialized
INFO - 2024-02-11 10:49:04 --> Output Class Initialized
INFO - 2024-02-11 10:49:04 --> Security Class Initialized
DEBUG - 2024-02-11 10:49:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-11 10:49:04 --> Input Class Initialized
INFO - 2024-02-11 10:49:04 --> Language Class Initialized
INFO - 2024-02-11 10:49:04 --> Language Class Initialized
INFO - 2024-02-11 10:49:04 --> Config Class Initialized
INFO - 2024-02-11 10:49:04 --> Loader Class Initialized
INFO - 2024-02-11 10:49:04 --> Helper loaded: url_helper
INFO - 2024-02-11 10:49:04 --> Helper loaded: file_helper
INFO - 2024-02-11 10:49:04 --> Helper loaded: form_helper
INFO - 2024-02-11 10:49:04 --> Helper loaded: my_helper
INFO - 2024-02-11 10:49:04 --> Database Driver Class Initialized
INFO - 2024-02-11 10:49:04 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-11 10:49:04 --> Controller Class Initialized
DEBUG - 2024-02-11 10:49:04 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/lihat_raport/views/list.php
DEBUG - 2024-02-11 10:49:04 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-02-11 10:49:04 --> Final output sent to browser
DEBUG - 2024-02-11 10:49:04 --> Total execution time: 0.0555
INFO - 2024-02-11 10:49:04 --> Config Class Initialized
INFO - 2024-02-11 10:49:04 --> Hooks Class Initialized
DEBUG - 2024-02-11 10:49:04 --> UTF-8 Support Enabled
INFO - 2024-02-11 10:49:04 --> Utf8 Class Initialized
INFO - 2024-02-11 10:49:04 --> URI Class Initialized
INFO - 2024-02-11 10:49:04 --> Router Class Initialized
INFO - 2024-02-11 10:49:04 --> Output Class Initialized
INFO - 2024-02-11 10:49:04 --> Security Class Initialized
DEBUG - 2024-02-11 10:49:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-11 10:49:04 --> Input Class Initialized
INFO - 2024-02-11 10:49:04 --> Language Class Initialized
INFO - 2024-02-11 10:49:04 --> Language Class Initialized
INFO - 2024-02-11 10:49:04 --> Config Class Initialized
INFO - 2024-02-11 10:49:04 --> Loader Class Initialized
INFO - 2024-02-11 10:49:04 --> Helper loaded: url_helper
INFO - 2024-02-11 10:49:04 --> Helper loaded: file_helper
INFO - 2024-02-11 10:49:04 --> Helper loaded: form_helper
INFO - 2024-02-11 10:49:04 --> Helper loaded: my_helper
INFO - 2024-02-11 10:49:04 --> Database Driver Class Initialized
INFO - 2024-02-11 10:49:04 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-11 10:49:04 --> Controller Class Initialized
INFO - 2024-02-11 10:49:04 --> Helper loaded: cookie_helper
INFO - 2024-02-11 10:49:04 --> Final output sent to browser
DEBUG - 2024-02-11 10:49:04 --> Total execution time: 0.0504
INFO - 2024-02-11 10:49:04 --> Config Class Initialized
INFO - 2024-02-11 10:49:04 --> Hooks Class Initialized
DEBUG - 2024-02-11 10:49:04 --> UTF-8 Support Enabled
INFO - 2024-02-11 10:49:04 --> Utf8 Class Initialized
INFO - 2024-02-11 10:49:04 --> URI Class Initialized
INFO - 2024-02-11 10:49:04 --> Router Class Initialized
INFO - 2024-02-11 10:49:04 --> Output Class Initialized
INFO - 2024-02-11 10:49:04 --> Security Class Initialized
DEBUG - 2024-02-11 10:49:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-11 10:49:04 --> Input Class Initialized
INFO - 2024-02-11 10:49:04 --> Language Class Initialized
INFO - 2024-02-11 10:49:04 --> Language Class Initialized
INFO - 2024-02-11 10:49:04 --> Config Class Initialized
INFO - 2024-02-11 10:49:04 --> Loader Class Initialized
INFO - 2024-02-11 10:49:04 --> Helper loaded: url_helper
INFO - 2024-02-11 10:49:04 --> Helper loaded: file_helper
INFO - 2024-02-11 10:49:04 --> Helper loaded: form_helper
INFO - 2024-02-11 10:49:04 --> Helper loaded: my_helper
INFO - 2024-02-11 10:49:04 --> Database Driver Class Initialized
INFO - 2024-02-11 10:49:04 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-11 10:49:04 --> Controller Class Initialized
INFO - 2024-02-11 10:49:04 --> Helper loaded: cookie_helper
INFO - 2024-02-11 10:49:04 --> Config Class Initialized
INFO - 2024-02-11 10:49:04 --> Hooks Class Initialized
DEBUG - 2024-02-11 10:49:04 --> UTF-8 Support Enabled
INFO - 2024-02-11 10:49:04 --> Utf8 Class Initialized
INFO - 2024-02-11 10:49:04 --> URI Class Initialized
INFO - 2024-02-11 10:49:04 --> Router Class Initialized
INFO - 2024-02-11 10:49:04 --> Output Class Initialized
INFO - 2024-02-11 10:49:04 --> Security Class Initialized
DEBUG - 2024-02-11 10:49:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-11 10:49:04 --> Input Class Initialized
INFO - 2024-02-11 10:49:04 --> Language Class Initialized
INFO - 2024-02-11 10:49:04 --> Language Class Initialized
INFO - 2024-02-11 10:49:04 --> Config Class Initialized
INFO - 2024-02-11 10:49:04 --> Loader Class Initialized
INFO - 2024-02-11 10:49:04 --> Helper loaded: url_helper
INFO - 2024-02-11 10:49:04 --> Helper loaded: file_helper
INFO - 2024-02-11 10:49:04 --> Helper loaded: form_helper
INFO - 2024-02-11 10:49:04 --> Helper loaded: my_helper
INFO - 2024-02-11 10:49:04 --> Database Driver Class Initialized
INFO - 2024-02-11 10:49:04 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-11 10:49:04 --> Controller Class Initialized
INFO - 2024-02-11 10:49:04 --> Helper loaded: cookie_helper
INFO - 2024-02-11 10:49:04 --> Config Class Initialized
INFO - 2024-02-11 10:49:04 --> Hooks Class Initialized
DEBUG - 2024-02-11 10:49:04 --> UTF-8 Support Enabled
INFO - 2024-02-11 10:49:04 --> Utf8 Class Initialized
INFO - 2024-02-11 10:49:04 --> URI Class Initialized
INFO - 2024-02-11 10:49:04 --> Router Class Initialized
INFO - 2024-02-11 10:49:04 --> Output Class Initialized
INFO - 2024-02-11 10:49:04 --> Security Class Initialized
DEBUG - 2024-02-11 10:49:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-11 10:49:04 --> Input Class Initialized
INFO - 2024-02-11 10:49:04 --> Language Class Initialized
INFO - 2024-02-11 10:49:04 --> Language Class Initialized
INFO - 2024-02-11 10:49:04 --> Config Class Initialized
INFO - 2024-02-11 10:49:04 --> Loader Class Initialized
INFO - 2024-02-11 10:49:04 --> Helper loaded: url_helper
INFO - 2024-02-11 10:49:04 --> Helper loaded: file_helper
INFO - 2024-02-11 10:49:04 --> Helper loaded: form_helper
INFO - 2024-02-11 10:49:04 --> Helper loaded: my_helper
INFO - 2024-02-11 10:49:04 --> Database Driver Class Initialized
INFO - 2024-02-11 10:49:04 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-11 10:49:04 --> Controller Class Initialized
DEBUG - 2024-02-11 10:49:04 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/lihat_raport/views/list.php
DEBUG - 2024-02-11 10:49:04 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-02-11 10:49:04 --> Final output sent to browser
DEBUG - 2024-02-11 10:49:04 --> Total execution time: 0.0870
