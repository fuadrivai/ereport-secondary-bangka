<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2024-06-20 08:00:39 --> Config Class Initialized
INFO - 2024-06-20 08:00:39 --> Hooks Class Initialized
DEBUG - 2024-06-20 08:00:39 --> UTF-8 Support Enabled
INFO - 2024-06-20 08:00:39 --> Utf8 Class Initialized
INFO - 2024-06-20 08:00:39 --> URI Class Initialized
INFO - 2024-06-20 08:00:39 --> Router Class Initialized
INFO - 2024-06-20 08:00:39 --> Output Class Initialized
INFO - 2024-06-20 08:00:39 --> Security Class Initialized
DEBUG - 2024-06-20 08:00:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-20 08:00:39 --> Input Class Initialized
INFO - 2024-06-20 08:00:39 --> Language Class Initialized
INFO - 2024-06-20 08:00:39 --> Language Class Initialized
INFO - 2024-06-20 08:00:39 --> Config Class Initialized
INFO - 2024-06-20 08:00:39 --> Loader Class Initialized
INFO - 2024-06-20 08:00:39 --> Helper loaded: url_helper
INFO - 2024-06-20 08:00:39 --> Helper loaded: file_helper
INFO - 2024-06-20 08:00:39 --> Helper loaded: form_helper
INFO - 2024-06-20 08:00:39 --> Helper loaded: my_helper
INFO - 2024-06-20 08:00:39 --> Database Driver Class Initialized
INFO - 2024-06-20 08:00:39 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-20 08:00:39 --> Controller Class Initialized
DEBUG - 2024-06-20 08:00:39 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/login/views/login.php
DEBUG - 2024-06-20 08:00:39 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-06-20 08:00:39 --> Final output sent to browser
DEBUG - 2024-06-20 08:00:39 --> Total execution time: 0.0499
INFO - 2024-06-20 08:01:04 --> Config Class Initialized
INFO - 2024-06-20 08:01:04 --> Hooks Class Initialized
DEBUG - 2024-06-20 08:01:04 --> UTF-8 Support Enabled
INFO - 2024-06-20 08:01:04 --> Utf8 Class Initialized
INFO - 2024-06-20 08:01:04 --> URI Class Initialized
INFO - 2024-06-20 08:01:04 --> Router Class Initialized
INFO - 2024-06-20 08:01:04 --> Output Class Initialized
INFO - 2024-06-20 08:01:04 --> Security Class Initialized
DEBUG - 2024-06-20 08:01:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-20 08:01:04 --> Input Class Initialized
INFO - 2024-06-20 08:01:04 --> Language Class Initialized
INFO - 2024-06-20 08:01:04 --> Language Class Initialized
INFO - 2024-06-20 08:01:04 --> Config Class Initialized
INFO - 2024-06-20 08:01:04 --> Loader Class Initialized
INFO - 2024-06-20 08:01:04 --> Helper loaded: url_helper
INFO - 2024-06-20 08:01:04 --> Helper loaded: file_helper
INFO - 2024-06-20 08:01:04 --> Helper loaded: form_helper
INFO - 2024-06-20 08:01:04 --> Helper loaded: my_helper
INFO - 2024-06-20 08:01:04 --> Database Driver Class Initialized
INFO - 2024-06-20 08:01:04 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-20 08:01:04 --> Controller Class Initialized
INFO - 2024-06-20 08:01:04 --> Helper loaded: cookie_helper
INFO - 2024-06-20 08:01:04 --> Final output sent to browser
DEBUG - 2024-06-20 08:01:04 --> Total execution time: 0.0333
INFO - 2024-06-20 08:01:05 --> Config Class Initialized
INFO - 2024-06-20 08:01:05 --> Hooks Class Initialized
DEBUG - 2024-06-20 08:01:05 --> UTF-8 Support Enabled
INFO - 2024-06-20 08:01:05 --> Utf8 Class Initialized
INFO - 2024-06-20 08:01:05 --> URI Class Initialized
INFO - 2024-06-20 08:01:05 --> Router Class Initialized
INFO - 2024-06-20 08:01:05 --> Output Class Initialized
INFO - 2024-06-20 08:01:05 --> Security Class Initialized
DEBUG - 2024-06-20 08:01:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-20 08:01:05 --> Input Class Initialized
INFO - 2024-06-20 08:01:05 --> Language Class Initialized
INFO - 2024-06-20 08:01:05 --> Language Class Initialized
INFO - 2024-06-20 08:01:05 --> Config Class Initialized
INFO - 2024-06-20 08:01:05 --> Loader Class Initialized
INFO - 2024-06-20 08:01:05 --> Helper loaded: url_helper
INFO - 2024-06-20 08:01:05 --> Helper loaded: file_helper
INFO - 2024-06-20 08:01:05 --> Helper loaded: form_helper
INFO - 2024-06-20 08:01:05 --> Helper loaded: my_helper
INFO - 2024-06-20 08:01:05 --> Database Driver Class Initialized
INFO - 2024-06-20 08:01:05 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-20 08:01:05 --> Controller Class Initialized
DEBUG - 2024-06-20 08:01:05 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/home/views/v_home_guru.php
DEBUG - 2024-06-20 08:01:05 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-06-20 08:01:05 --> Final output sent to browser
DEBUG - 2024-06-20 08:01:05 --> Total execution time: 0.0362
INFO - 2024-06-20 08:01:14 --> Config Class Initialized
INFO - 2024-06-20 08:01:14 --> Hooks Class Initialized
DEBUG - 2024-06-20 08:01:14 --> UTF-8 Support Enabled
INFO - 2024-06-20 08:01:14 --> Utf8 Class Initialized
INFO - 2024-06-20 08:01:14 --> URI Class Initialized
INFO - 2024-06-20 08:01:14 --> Router Class Initialized
INFO - 2024-06-20 08:01:14 --> Output Class Initialized
INFO - 2024-06-20 08:01:14 --> Security Class Initialized
DEBUG - 2024-06-20 08:01:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-20 08:01:14 --> Input Class Initialized
INFO - 2024-06-20 08:01:14 --> Language Class Initialized
INFO - 2024-06-20 08:01:14 --> Language Class Initialized
INFO - 2024-06-20 08:01:14 --> Config Class Initialized
INFO - 2024-06-20 08:01:14 --> Loader Class Initialized
INFO - 2024-06-20 08:01:14 --> Helper loaded: url_helper
INFO - 2024-06-20 08:01:14 --> Helper loaded: file_helper
INFO - 2024-06-20 08:01:14 --> Helper loaded: form_helper
INFO - 2024-06-20 08:01:14 --> Helper loaded: my_helper
INFO - 2024-06-20 08:01:14 --> Database Driver Class Initialized
INFO - 2024-06-20 08:01:14 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-20 08:01:14 --> Controller Class Initialized
DEBUG - 2024-06-20 08:01:14 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/views/list.php
DEBUG - 2024-06-20 08:01:14 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-06-20 08:01:14 --> Final output sent to browser
DEBUG - 2024-06-20 08:01:14 --> Total execution time: 0.0632
INFO - 2024-06-20 08:01:21 --> Config Class Initialized
INFO - 2024-06-20 08:01:21 --> Hooks Class Initialized
DEBUG - 2024-06-20 08:01:21 --> UTF-8 Support Enabled
INFO - 2024-06-20 08:01:21 --> Utf8 Class Initialized
INFO - 2024-06-20 08:01:21 --> URI Class Initialized
INFO - 2024-06-20 08:01:21 --> Router Class Initialized
INFO - 2024-06-20 08:01:21 --> Output Class Initialized
INFO - 2024-06-20 08:01:21 --> Security Class Initialized
DEBUG - 2024-06-20 08:01:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-20 08:01:21 --> Input Class Initialized
INFO - 2024-06-20 08:01:21 --> Language Class Initialized
INFO - 2024-06-20 08:01:21 --> Language Class Initialized
INFO - 2024-06-20 08:01:21 --> Config Class Initialized
INFO - 2024-06-20 08:01:21 --> Loader Class Initialized
INFO - 2024-06-20 08:01:21 --> Helper loaded: url_helper
INFO - 2024-06-20 08:01:21 --> Helper loaded: file_helper
INFO - 2024-06-20 08:01:21 --> Helper loaded: form_helper
INFO - 2024-06-20 08:01:21 --> Helper loaded: my_helper
INFO - 2024-06-20 08:01:21 --> Database Driver Class Initialized
INFO - 2024-06-20 08:01:21 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-20 08:01:21 --> Controller Class Initialized
DEBUG - 2024-06-20 08:01:21 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/views/cetak_ikm.php
INFO - 2024-06-20 08:01:23 --> Final output sent to browser
DEBUG - 2024-06-20 08:01:23 --> Total execution time: 1.9980
INFO - 2024-06-20 08:01:28 --> Config Class Initialized
INFO - 2024-06-20 08:01:28 --> Hooks Class Initialized
DEBUG - 2024-06-20 08:01:28 --> UTF-8 Support Enabled
INFO - 2024-06-20 08:01:28 --> Utf8 Class Initialized
INFO - 2024-06-20 08:01:28 --> URI Class Initialized
INFO - 2024-06-20 08:01:28 --> Router Class Initialized
INFO - 2024-06-20 08:01:28 --> Output Class Initialized
INFO - 2024-06-20 08:01:28 --> Security Class Initialized
DEBUG - 2024-06-20 08:01:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-20 08:01:28 --> Input Class Initialized
INFO - 2024-06-20 08:01:28 --> Language Class Initialized
INFO - 2024-06-20 08:01:28 --> Language Class Initialized
INFO - 2024-06-20 08:01:28 --> Config Class Initialized
INFO - 2024-06-20 08:01:28 --> Loader Class Initialized
INFO - 2024-06-20 08:01:28 --> Helper loaded: url_helper
INFO - 2024-06-20 08:01:28 --> Helper loaded: file_helper
INFO - 2024-06-20 08:01:28 --> Helper loaded: form_helper
INFO - 2024-06-20 08:01:28 --> Helper loaded: my_helper
INFO - 2024-06-20 08:01:28 --> Database Driver Class Initialized
INFO - 2024-06-20 08:01:28 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-20 08:01:28 --> Controller Class Initialized
DEBUG - 2024-06-20 08:01:28 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/views/cetak_ikm.php
INFO - 2024-06-20 08:01:29 --> Final output sent to browser
DEBUG - 2024-06-20 08:01:29 --> Total execution time: 1.3916
INFO - 2024-06-20 08:01:31 --> Config Class Initialized
INFO - 2024-06-20 08:01:31 --> Hooks Class Initialized
DEBUG - 2024-06-20 08:01:31 --> UTF-8 Support Enabled
INFO - 2024-06-20 08:01:31 --> Utf8 Class Initialized
INFO - 2024-06-20 08:01:31 --> URI Class Initialized
INFO - 2024-06-20 08:01:31 --> Router Class Initialized
INFO - 2024-06-20 08:01:31 --> Output Class Initialized
INFO - 2024-06-20 08:01:31 --> Security Class Initialized
DEBUG - 2024-06-20 08:01:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-20 08:01:31 --> Input Class Initialized
INFO - 2024-06-20 08:01:31 --> Language Class Initialized
INFO - 2024-06-20 08:01:31 --> Language Class Initialized
INFO - 2024-06-20 08:01:31 --> Config Class Initialized
INFO - 2024-06-20 08:01:31 --> Loader Class Initialized
INFO - 2024-06-20 08:01:31 --> Helper loaded: url_helper
INFO - 2024-06-20 08:01:31 --> Helper loaded: file_helper
INFO - 2024-06-20 08:01:31 --> Helper loaded: form_helper
INFO - 2024-06-20 08:01:31 --> Helper loaded: my_helper
INFO - 2024-06-20 08:01:31 --> Database Driver Class Initialized
INFO - 2024-06-20 08:01:31 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-20 08:01:31 --> Controller Class Initialized
DEBUG - 2024-06-20 08:01:31 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/views/cetak_ikm.php
INFO - 2024-06-20 08:01:33 --> Final output sent to browser
DEBUG - 2024-06-20 08:01:33 --> Total execution time: 1.7639
INFO - 2024-06-20 08:01:35 --> Config Class Initialized
INFO - 2024-06-20 08:01:35 --> Hooks Class Initialized
DEBUG - 2024-06-20 08:01:35 --> UTF-8 Support Enabled
INFO - 2024-06-20 08:01:35 --> Utf8 Class Initialized
INFO - 2024-06-20 08:01:35 --> URI Class Initialized
INFO - 2024-06-20 08:01:35 --> Router Class Initialized
INFO - 2024-06-20 08:01:35 --> Output Class Initialized
INFO - 2024-06-20 08:01:35 --> Security Class Initialized
DEBUG - 2024-06-20 08:01:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-20 08:01:35 --> Input Class Initialized
INFO - 2024-06-20 08:01:35 --> Language Class Initialized
INFO - 2024-06-20 08:01:35 --> Language Class Initialized
INFO - 2024-06-20 08:01:35 --> Config Class Initialized
INFO - 2024-06-20 08:01:35 --> Loader Class Initialized
INFO - 2024-06-20 08:01:35 --> Helper loaded: url_helper
INFO - 2024-06-20 08:01:35 --> Helper loaded: file_helper
INFO - 2024-06-20 08:01:35 --> Helper loaded: form_helper
INFO - 2024-06-20 08:01:35 --> Helper loaded: my_helper
INFO - 2024-06-20 08:01:35 --> Database Driver Class Initialized
INFO - 2024-06-20 08:01:35 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-20 08:01:35 --> Controller Class Initialized
DEBUG - 2024-06-20 08:01:35 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/views/cetak_ikm.php
INFO - 2024-06-20 08:01:36 --> Final output sent to browser
DEBUG - 2024-06-20 08:01:36 --> Total execution time: 1.4237
INFO - 2024-06-20 08:01:38 --> Config Class Initialized
INFO - 2024-06-20 08:01:38 --> Hooks Class Initialized
DEBUG - 2024-06-20 08:01:38 --> UTF-8 Support Enabled
INFO - 2024-06-20 08:01:38 --> Utf8 Class Initialized
INFO - 2024-06-20 08:01:38 --> URI Class Initialized
INFO - 2024-06-20 08:01:38 --> Router Class Initialized
INFO - 2024-06-20 08:01:38 --> Output Class Initialized
INFO - 2024-06-20 08:01:38 --> Security Class Initialized
DEBUG - 2024-06-20 08:01:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-20 08:01:38 --> Input Class Initialized
INFO - 2024-06-20 08:01:38 --> Language Class Initialized
INFO - 2024-06-20 08:01:38 --> Language Class Initialized
INFO - 2024-06-20 08:01:38 --> Config Class Initialized
INFO - 2024-06-20 08:01:38 --> Loader Class Initialized
INFO - 2024-06-20 08:01:38 --> Helper loaded: url_helper
INFO - 2024-06-20 08:01:38 --> Helper loaded: file_helper
INFO - 2024-06-20 08:01:38 --> Helper loaded: form_helper
INFO - 2024-06-20 08:01:38 --> Helper loaded: my_helper
INFO - 2024-06-20 08:01:38 --> Database Driver Class Initialized
INFO - 2024-06-20 08:01:38 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-20 08:01:38 --> Controller Class Initialized
DEBUG - 2024-06-20 08:01:38 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/views/cetak_ikm.php
INFO - 2024-06-20 08:01:40 --> Final output sent to browser
DEBUG - 2024-06-20 08:01:40 --> Total execution time: 1.8054
INFO - 2024-06-20 08:01:42 --> Config Class Initialized
INFO - 2024-06-20 08:01:42 --> Hooks Class Initialized
DEBUG - 2024-06-20 08:01:42 --> UTF-8 Support Enabled
INFO - 2024-06-20 08:01:42 --> Utf8 Class Initialized
INFO - 2024-06-20 08:01:42 --> URI Class Initialized
INFO - 2024-06-20 08:01:42 --> Router Class Initialized
INFO - 2024-06-20 08:01:42 --> Output Class Initialized
INFO - 2024-06-20 08:01:42 --> Security Class Initialized
DEBUG - 2024-06-20 08:01:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-20 08:01:42 --> Input Class Initialized
INFO - 2024-06-20 08:01:42 --> Language Class Initialized
INFO - 2024-06-20 08:01:42 --> Language Class Initialized
INFO - 2024-06-20 08:01:42 --> Config Class Initialized
INFO - 2024-06-20 08:01:42 --> Loader Class Initialized
INFO - 2024-06-20 08:01:42 --> Helper loaded: url_helper
INFO - 2024-06-20 08:01:42 --> Helper loaded: file_helper
INFO - 2024-06-20 08:01:42 --> Helper loaded: form_helper
INFO - 2024-06-20 08:01:42 --> Helper loaded: my_helper
INFO - 2024-06-20 08:01:42 --> Database Driver Class Initialized
INFO - 2024-06-20 08:01:42 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-20 08:01:42 --> Controller Class Initialized
DEBUG - 2024-06-20 08:01:42 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/views/cetak_ikm.php
INFO - 2024-06-20 08:01:43 --> Final output sent to browser
DEBUG - 2024-06-20 08:01:43 --> Total execution time: 1.4111
INFO - 2024-06-20 08:01:45 --> Config Class Initialized
INFO - 2024-06-20 08:01:45 --> Hooks Class Initialized
DEBUG - 2024-06-20 08:01:45 --> UTF-8 Support Enabled
INFO - 2024-06-20 08:01:45 --> Utf8 Class Initialized
INFO - 2024-06-20 08:01:45 --> URI Class Initialized
INFO - 2024-06-20 08:01:45 --> Router Class Initialized
INFO - 2024-06-20 08:01:45 --> Output Class Initialized
INFO - 2024-06-20 08:01:45 --> Security Class Initialized
DEBUG - 2024-06-20 08:01:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-20 08:01:45 --> Input Class Initialized
INFO - 2024-06-20 08:01:45 --> Language Class Initialized
INFO - 2024-06-20 08:01:45 --> Language Class Initialized
INFO - 2024-06-20 08:01:45 --> Config Class Initialized
INFO - 2024-06-20 08:01:45 --> Loader Class Initialized
INFO - 2024-06-20 08:01:45 --> Helper loaded: url_helper
INFO - 2024-06-20 08:01:45 --> Helper loaded: file_helper
INFO - 2024-06-20 08:01:45 --> Helper loaded: form_helper
INFO - 2024-06-20 08:01:45 --> Helper loaded: my_helper
INFO - 2024-06-20 08:01:45 --> Database Driver Class Initialized
INFO - 2024-06-20 08:01:45 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-20 08:01:45 --> Controller Class Initialized
DEBUG - 2024-06-20 08:01:45 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/views/cetak_ikm.php
INFO - 2024-06-20 08:01:46 --> Final output sent to browser
DEBUG - 2024-06-20 08:01:46 --> Total execution time: 1.6474
INFO - 2024-06-20 08:01:49 --> Config Class Initialized
INFO - 2024-06-20 08:01:49 --> Hooks Class Initialized
DEBUG - 2024-06-20 08:01:49 --> UTF-8 Support Enabled
INFO - 2024-06-20 08:01:49 --> Utf8 Class Initialized
INFO - 2024-06-20 08:01:49 --> URI Class Initialized
INFO - 2024-06-20 08:01:49 --> Router Class Initialized
INFO - 2024-06-20 08:01:49 --> Output Class Initialized
INFO - 2024-06-20 08:01:49 --> Security Class Initialized
DEBUG - 2024-06-20 08:01:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-20 08:01:49 --> Input Class Initialized
INFO - 2024-06-20 08:01:49 --> Language Class Initialized
INFO - 2024-06-20 08:01:49 --> Language Class Initialized
INFO - 2024-06-20 08:01:49 --> Config Class Initialized
INFO - 2024-06-20 08:01:49 --> Loader Class Initialized
INFO - 2024-06-20 08:01:49 --> Helper loaded: url_helper
INFO - 2024-06-20 08:01:49 --> Helper loaded: file_helper
INFO - 2024-06-20 08:01:49 --> Helper loaded: form_helper
INFO - 2024-06-20 08:01:49 --> Helper loaded: my_helper
INFO - 2024-06-20 08:01:49 --> Database Driver Class Initialized
INFO - 2024-06-20 08:01:49 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-20 08:01:49 --> Controller Class Initialized
DEBUG - 2024-06-20 08:01:49 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/views/cetak_ikm.php
INFO - 2024-06-20 08:01:50 --> Final output sent to browser
DEBUG - 2024-06-20 08:01:50 --> Total execution time: 1.4388
INFO - 2024-06-20 08:01:52 --> Config Class Initialized
INFO - 2024-06-20 08:01:52 --> Hooks Class Initialized
DEBUG - 2024-06-20 08:01:52 --> UTF-8 Support Enabled
INFO - 2024-06-20 08:01:52 --> Utf8 Class Initialized
INFO - 2024-06-20 08:01:52 --> URI Class Initialized
INFO - 2024-06-20 08:01:52 --> Router Class Initialized
INFO - 2024-06-20 08:01:52 --> Output Class Initialized
INFO - 2024-06-20 08:01:52 --> Security Class Initialized
DEBUG - 2024-06-20 08:01:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-20 08:01:52 --> Input Class Initialized
INFO - 2024-06-20 08:01:52 --> Language Class Initialized
INFO - 2024-06-20 08:01:52 --> Language Class Initialized
INFO - 2024-06-20 08:01:52 --> Config Class Initialized
INFO - 2024-06-20 08:01:52 --> Loader Class Initialized
INFO - 2024-06-20 08:01:52 --> Helper loaded: url_helper
INFO - 2024-06-20 08:01:52 --> Helper loaded: file_helper
INFO - 2024-06-20 08:01:52 --> Helper loaded: form_helper
INFO - 2024-06-20 08:01:52 --> Helper loaded: my_helper
INFO - 2024-06-20 08:01:52 --> Database Driver Class Initialized
INFO - 2024-06-20 08:01:52 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-20 08:01:52 --> Controller Class Initialized
DEBUG - 2024-06-20 08:01:52 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/views/cetak_ikm.php
INFO - 2024-06-20 08:01:54 --> Final output sent to browser
DEBUG - 2024-06-20 08:01:54 --> Total execution time: 1.8410
INFO - 2024-06-20 08:01:55 --> Config Class Initialized
INFO - 2024-06-20 08:01:55 --> Hooks Class Initialized
DEBUG - 2024-06-20 08:01:55 --> UTF-8 Support Enabled
INFO - 2024-06-20 08:01:55 --> Utf8 Class Initialized
INFO - 2024-06-20 08:01:55 --> URI Class Initialized
INFO - 2024-06-20 08:01:55 --> Router Class Initialized
INFO - 2024-06-20 08:01:55 --> Output Class Initialized
INFO - 2024-06-20 08:01:55 --> Security Class Initialized
DEBUG - 2024-06-20 08:01:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-20 08:01:55 --> Input Class Initialized
INFO - 2024-06-20 08:01:55 --> Language Class Initialized
INFO - 2024-06-20 08:01:55 --> Language Class Initialized
INFO - 2024-06-20 08:01:55 --> Config Class Initialized
INFO - 2024-06-20 08:01:55 --> Loader Class Initialized
INFO - 2024-06-20 08:01:55 --> Helper loaded: url_helper
INFO - 2024-06-20 08:01:55 --> Helper loaded: file_helper
INFO - 2024-06-20 08:01:55 --> Helper loaded: form_helper
INFO - 2024-06-20 08:01:55 --> Helper loaded: my_helper
INFO - 2024-06-20 08:01:55 --> Database Driver Class Initialized
INFO - 2024-06-20 08:01:55 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-20 08:01:55 --> Controller Class Initialized
DEBUG - 2024-06-20 08:01:55 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/views/cetak_ikm.php
INFO - 2024-06-20 08:01:57 --> Final output sent to browser
DEBUG - 2024-06-20 08:01:57 --> Total execution time: 1.4670
INFO - 2024-06-20 08:02:12 --> Config Class Initialized
INFO - 2024-06-20 08:02:12 --> Hooks Class Initialized
DEBUG - 2024-06-20 08:02:12 --> UTF-8 Support Enabled
INFO - 2024-06-20 08:02:12 --> Utf8 Class Initialized
INFO - 2024-06-20 08:02:12 --> URI Class Initialized
INFO - 2024-06-20 08:02:12 --> Router Class Initialized
INFO - 2024-06-20 08:02:12 --> Output Class Initialized
INFO - 2024-06-20 08:02:12 --> Security Class Initialized
DEBUG - 2024-06-20 08:02:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-20 08:02:12 --> Input Class Initialized
INFO - 2024-06-20 08:02:12 --> Language Class Initialized
INFO - 2024-06-20 08:02:12 --> Language Class Initialized
INFO - 2024-06-20 08:02:12 --> Config Class Initialized
INFO - 2024-06-20 08:02:12 --> Loader Class Initialized
INFO - 2024-06-20 08:02:12 --> Helper loaded: url_helper
INFO - 2024-06-20 08:02:12 --> Helper loaded: file_helper
INFO - 2024-06-20 08:02:12 --> Helper loaded: form_helper
INFO - 2024-06-20 08:02:12 --> Helper loaded: my_helper
INFO - 2024-06-20 08:02:12 --> Database Driver Class Initialized
INFO - 2024-06-20 08:02:12 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-20 08:02:12 --> Controller Class Initialized
DEBUG - 2024-06-20 08:02:12 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/view_mapel/views/v_view_mapel.php
DEBUG - 2024-06-20 08:02:12 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-06-20 08:02:12 --> Final output sent to browser
DEBUG - 2024-06-20 08:02:12 --> Total execution time: 0.0615
INFO - 2024-06-20 08:02:14 --> Config Class Initialized
INFO - 2024-06-20 08:02:14 --> Hooks Class Initialized
DEBUG - 2024-06-20 08:02:14 --> UTF-8 Support Enabled
INFO - 2024-06-20 08:02:14 --> Utf8 Class Initialized
INFO - 2024-06-20 08:02:14 --> URI Class Initialized
INFO - 2024-06-20 08:02:14 --> Router Class Initialized
INFO - 2024-06-20 08:02:14 --> Output Class Initialized
INFO - 2024-06-20 08:02:14 --> Security Class Initialized
DEBUG - 2024-06-20 08:02:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-20 08:02:14 --> Input Class Initialized
INFO - 2024-06-20 08:02:14 --> Language Class Initialized
INFO - 2024-06-20 08:02:14 --> Language Class Initialized
INFO - 2024-06-20 08:02:14 --> Config Class Initialized
INFO - 2024-06-20 08:02:14 --> Loader Class Initialized
INFO - 2024-06-20 08:02:14 --> Helper loaded: url_helper
INFO - 2024-06-20 08:02:14 --> Helper loaded: file_helper
INFO - 2024-06-20 08:02:14 --> Helper loaded: form_helper
INFO - 2024-06-20 08:02:14 --> Helper loaded: my_helper
INFO - 2024-06-20 08:02:14 --> Database Driver Class Initialized
INFO - 2024-06-20 08:02:14 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-20 08:02:14 --> Controller Class Initialized
DEBUG - 2024-06-20 08:02:14 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/views/list.php
DEBUG - 2024-06-20 08:02:14 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-06-20 08:02:14 --> Final output sent to browser
DEBUG - 2024-06-20 08:02:14 --> Total execution time: 0.0648
INFO - 2024-06-20 08:02:14 --> Config Class Initialized
INFO - 2024-06-20 08:02:14 --> Hooks Class Initialized
DEBUG - 2024-06-20 08:02:14 --> UTF-8 Support Enabled
INFO - 2024-06-20 08:02:14 --> Utf8 Class Initialized
INFO - 2024-06-20 08:02:14 --> URI Class Initialized
INFO - 2024-06-20 08:02:14 --> Router Class Initialized
INFO - 2024-06-20 08:02:14 --> Output Class Initialized
INFO - 2024-06-20 08:02:14 --> Security Class Initialized
DEBUG - 2024-06-20 08:02:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-20 08:02:14 --> Input Class Initialized
INFO - 2024-06-20 08:02:14 --> Language Class Initialized
INFO - 2024-06-20 08:02:14 --> Language Class Initialized
INFO - 2024-06-20 08:02:14 --> Config Class Initialized
INFO - 2024-06-20 08:02:14 --> Loader Class Initialized
INFO - 2024-06-20 08:02:14 --> Helper loaded: url_helper
INFO - 2024-06-20 08:02:14 --> Helper loaded: file_helper
INFO - 2024-06-20 08:02:14 --> Helper loaded: form_helper
INFO - 2024-06-20 08:02:14 --> Helper loaded: my_helper
INFO - 2024-06-20 08:02:14 --> Database Driver Class Initialized
INFO - 2024-06-20 08:02:14 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-20 08:02:14 --> Controller Class Initialized
INFO - 2024-06-20 08:02:17 --> Config Class Initialized
INFO - 2024-06-20 08:02:17 --> Hooks Class Initialized
DEBUG - 2024-06-20 08:02:17 --> UTF-8 Support Enabled
INFO - 2024-06-20 08:02:17 --> Utf8 Class Initialized
INFO - 2024-06-20 08:02:17 --> URI Class Initialized
INFO - 2024-06-20 08:02:17 --> Router Class Initialized
INFO - 2024-06-20 08:02:17 --> Output Class Initialized
INFO - 2024-06-20 08:02:17 --> Security Class Initialized
DEBUG - 2024-06-20 08:02:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-20 08:02:17 --> Input Class Initialized
INFO - 2024-06-20 08:02:17 --> Language Class Initialized
INFO - 2024-06-20 08:02:17 --> Language Class Initialized
INFO - 2024-06-20 08:02:17 --> Config Class Initialized
INFO - 2024-06-20 08:02:17 --> Loader Class Initialized
INFO - 2024-06-20 08:02:17 --> Helper loaded: url_helper
INFO - 2024-06-20 08:02:17 --> Helper loaded: file_helper
INFO - 2024-06-20 08:02:17 --> Helper loaded: form_helper
INFO - 2024-06-20 08:02:17 --> Helper loaded: my_helper
INFO - 2024-06-20 08:02:17 --> Database Driver Class Initialized
INFO - 2024-06-20 08:02:17 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-20 08:02:17 --> Controller Class Initialized
INFO - 2024-06-20 08:02:17 --> Final output sent to browser
DEBUG - 2024-06-20 08:02:17 --> Total execution time: 0.0268
INFO - 2024-06-20 08:02:23 --> Config Class Initialized
INFO - 2024-06-20 08:02:23 --> Hooks Class Initialized
DEBUG - 2024-06-20 08:02:23 --> UTF-8 Support Enabled
INFO - 2024-06-20 08:02:23 --> Utf8 Class Initialized
INFO - 2024-06-20 08:02:23 --> URI Class Initialized
INFO - 2024-06-20 08:02:23 --> Router Class Initialized
INFO - 2024-06-20 08:02:23 --> Output Class Initialized
INFO - 2024-06-20 08:02:23 --> Security Class Initialized
DEBUG - 2024-06-20 08:02:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-20 08:02:23 --> Input Class Initialized
INFO - 2024-06-20 08:02:23 --> Language Class Initialized
INFO - 2024-06-20 08:02:23 --> Language Class Initialized
INFO - 2024-06-20 08:02:23 --> Config Class Initialized
INFO - 2024-06-20 08:02:23 --> Loader Class Initialized
INFO - 2024-06-20 08:02:23 --> Helper loaded: url_helper
INFO - 2024-06-20 08:02:23 --> Helper loaded: file_helper
INFO - 2024-06-20 08:02:23 --> Helper loaded: form_helper
INFO - 2024-06-20 08:02:23 --> Helper loaded: my_helper
INFO - 2024-06-20 08:02:23 --> Database Driver Class Initialized
INFO - 2024-06-20 08:02:23 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-20 08:02:23 --> Controller Class Initialized
INFO - 2024-06-20 08:02:23 --> Final output sent to browser
DEBUG - 2024-06-20 08:02:23 --> Total execution time: 0.0540
INFO - 2024-06-20 08:02:28 --> Config Class Initialized
INFO - 2024-06-20 08:02:28 --> Hooks Class Initialized
DEBUG - 2024-06-20 08:02:28 --> UTF-8 Support Enabled
INFO - 2024-06-20 08:02:28 --> Utf8 Class Initialized
INFO - 2024-06-20 08:02:28 --> URI Class Initialized
INFO - 2024-06-20 08:02:28 --> Router Class Initialized
INFO - 2024-06-20 08:02:28 --> Output Class Initialized
INFO - 2024-06-20 08:02:28 --> Security Class Initialized
DEBUG - 2024-06-20 08:02:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-20 08:02:28 --> Input Class Initialized
INFO - 2024-06-20 08:02:28 --> Language Class Initialized
INFO - 2024-06-20 08:02:28 --> Language Class Initialized
INFO - 2024-06-20 08:02:28 --> Config Class Initialized
INFO - 2024-06-20 08:02:28 --> Loader Class Initialized
INFO - 2024-06-20 08:02:28 --> Helper loaded: url_helper
INFO - 2024-06-20 08:02:28 --> Helper loaded: file_helper
INFO - 2024-06-20 08:02:28 --> Helper loaded: form_helper
INFO - 2024-06-20 08:02:28 --> Helper loaded: my_helper
INFO - 2024-06-20 08:02:28 --> Database Driver Class Initialized
INFO - 2024-06-20 08:02:28 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-20 08:02:28 --> Controller Class Initialized
INFO - 2024-06-20 08:02:28 --> Final output sent to browser
DEBUG - 2024-06-20 08:02:28 --> Total execution time: 0.0296
INFO - 2024-06-20 08:02:34 --> Config Class Initialized
INFO - 2024-06-20 08:02:34 --> Hooks Class Initialized
DEBUG - 2024-06-20 08:02:34 --> UTF-8 Support Enabled
INFO - 2024-06-20 08:02:34 --> Utf8 Class Initialized
INFO - 2024-06-20 08:02:34 --> URI Class Initialized
INFO - 2024-06-20 08:02:34 --> Router Class Initialized
INFO - 2024-06-20 08:02:34 --> Output Class Initialized
INFO - 2024-06-20 08:02:34 --> Security Class Initialized
DEBUG - 2024-06-20 08:02:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-20 08:02:34 --> Input Class Initialized
INFO - 2024-06-20 08:02:34 --> Language Class Initialized
INFO - 2024-06-20 08:02:34 --> Language Class Initialized
INFO - 2024-06-20 08:02:34 --> Config Class Initialized
INFO - 2024-06-20 08:02:34 --> Loader Class Initialized
INFO - 2024-06-20 08:02:34 --> Helper loaded: url_helper
INFO - 2024-06-20 08:02:34 --> Helper loaded: file_helper
INFO - 2024-06-20 08:02:34 --> Helper loaded: form_helper
INFO - 2024-06-20 08:02:34 --> Helper loaded: my_helper
INFO - 2024-06-20 08:02:34 --> Database Driver Class Initialized
INFO - 2024-06-20 08:02:34 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-20 08:02:34 --> Controller Class Initialized
INFO - 2024-06-20 08:02:34 --> Final output sent to browser
DEBUG - 2024-06-20 08:02:34 --> Total execution time: 0.0317
INFO - 2024-06-20 08:02:39 --> Config Class Initialized
INFO - 2024-06-20 08:02:39 --> Hooks Class Initialized
DEBUG - 2024-06-20 08:02:39 --> UTF-8 Support Enabled
INFO - 2024-06-20 08:02:39 --> Utf8 Class Initialized
INFO - 2024-06-20 08:02:39 --> URI Class Initialized
INFO - 2024-06-20 08:02:39 --> Router Class Initialized
INFO - 2024-06-20 08:02:39 --> Output Class Initialized
INFO - 2024-06-20 08:02:39 --> Security Class Initialized
DEBUG - 2024-06-20 08:02:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-20 08:02:39 --> Input Class Initialized
INFO - 2024-06-20 08:02:39 --> Language Class Initialized
INFO - 2024-06-20 08:02:39 --> Language Class Initialized
INFO - 2024-06-20 08:02:39 --> Config Class Initialized
INFO - 2024-06-20 08:02:39 --> Loader Class Initialized
INFO - 2024-06-20 08:02:39 --> Helper loaded: url_helper
INFO - 2024-06-20 08:02:39 --> Helper loaded: file_helper
INFO - 2024-06-20 08:02:39 --> Helper loaded: form_helper
INFO - 2024-06-20 08:02:39 --> Helper loaded: my_helper
INFO - 2024-06-20 08:02:39 --> Database Driver Class Initialized
INFO - 2024-06-20 08:02:40 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-20 08:02:40 --> Controller Class Initialized
INFO - 2024-06-20 08:02:40 --> Final output sent to browser
DEBUG - 2024-06-20 08:02:40 --> Total execution time: 0.0297
INFO - 2024-06-20 08:02:44 --> Config Class Initialized
INFO - 2024-06-20 08:02:44 --> Hooks Class Initialized
DEBUG - 2024-06-20 08:02:44 --> UTF-8 Support Enabled
INFO - 2024-06-20 08:02:44 --> Utf8 Class Initialized
INFO - 2024-06-20 08:02:44 --> URI Class Initialized
INFO - 2024-06-20 08:02:44 --> Router Class Initialized
INFO - 2024-06-20 08:02:44 --> Output Class Initialized
INFO - 2024-06-20 08:02:44 --> Security Class Initialized
DEBUG - 2024-06-20 08:02:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-20 08:02:44 --> Input Class Initialized
INFO - 2024-06-20 08:02:44 --> Language Class Initialized
INFO - 2024-06-20 08:02:44 --> Language Class Initialized
INFO - 2024-06-20 08:02:44 --> Config Class Initialized
INFO - 2024-06-20 08:02:44 --> Loader Class Initialized
INFO - 2024-06-20 08:02:44 --> Helper loaded: url_helper
INFO - 2024-06-20 08:02:44 --> Helper loaded: file_helper
INFO - 2024-06-20 08:02:44 --> Helper loaded: form_helper
INFO - 2024-06-20 08:02:44 --> Helper loaded: my_helper
INFO - 2024-06-20 08:02:44 --> Database Driver Class Initialized
INFO - 2024-06-20 08:02:44 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-20 08:02:44 --> Controller Class Initialized
INFO - 2024-06-20 08:02:44 --> Final output sent to browser
DEBUG - 2024-06-20 08:02:44 --> Total execution time: 0.0291
INFO - 2024-06-20 08:02:49 --> Config Class Initialized
INFO - 2024-06-20 08:02:49 --> Hooks Class Initialized
DEBUG - 2024-06-20 08:02:49 --> UTF-8 Support Enabled
INFO - 2024-06-20 08:02:49 --> Utf8 Class Initialized
INFO - 2024-06-20 08:02:49 --> URI Class Initialized
INFO - 2024-06-20 08:02:49 --> Router Class Initialized
INFO - 2024-06-20 08:02:49 --> Output Class Initialized
INFO - 2024-06-20 08:02:49 --> Security Class Initialized
DEBUG - 2024-06-20 08:02:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-20 08:02:49 --> Input Class Initialized
INFO - 2024-06-20 08:02:49 --> Language Class Initialized
INFO - 2024-06-20 08:02:49 --> Language Class Initialized
INFO - 2024-06-20 08:02:49 --> Config Class Initialized
INFO - 2024-06-20 08:02:49 --> Loader Class Initialized
INFO - 2024-06-20 08:02:49 --> Helper loaded: url_helper
INFO - 2024-06-20 08:02:49 --> Helper loaded: file_helper
INFO - 2024-06-20 08:02:49 --> Helper loaded: form_helper
INFO - 2024-06-20 08:02:49 --> Helper loaded: my_helper
INFO - 2024-06-20 08:02:49 --> Database Driver Class Initialized
INFO - 2024-06-20 08:02:49 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-20 08:02:49 --> Controller Class Initialized
INFO - 2024-06-20 08:02:49 --> Final output sent to browser
DEBUG - 2024-06-20 08:02:49 --> Total execution time: 0.0345
INFO - 2024-06-20 08:02:53 --> Config Class Initialized
INFO - 2024-06-20 08:02:53 --> Hooks Class Initialized
DEBUG - 2024-06-20 08:02:53 --> UTF-8 Support Enabled
INFO - 2024-06-20 08:02:53 --> Utf8 Class Initialized
INFO - 2024-06-20 08:02:53 --> URI Class Initialized
INFO - 2024-06-20 08:02:53 --> Router Class Initialized
INFO - 2024-06-20 08:02:53 --> Output Class Initialized
INFO - 2024-06-20 08:02:53 --> Security Class Initialized
DEBUG - 2024-06-20 08:02:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-20 08:02:53 --> Input Class Initialized
INFO - 2024-06-20 08:02:53 --> Language Class Initialized
INFO - 2024-06-20 08:02:53 --> Language Class Initialized
INFO - 2024-06-20 08:02:53 --> Config Class Initialized
INFO - 2024-06-20 08:02:53 --> Loader Class Initialized
INFO - 2024-06-20 08:02:53 --> Helper loaded: url_helper
INFO - 2024-06-20 08:02:53 --> Helper loaded: file_helper
INFO - 2024-06-20 08:02:53 --> Helper loaded: form_helper
INFO - 2024-06-20 08:02:53 --> Helper loaded: my_helper
INFO - 2024-06-20 08:02:53 --> Database Driver Class Initialized
INFO - 2024-06-20 08:02:53 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-20 08:02:53 --> Controller Class Initialized
INFO - 2024-06-20 08:02:53 --> Final output sent to browser
DEBUG - 2024-06-20 08:02:53 --> Total execution time: 0.0352
INFO - 2024-06-20 08:03:03 --> Config Class Initialized
INFO - 2024-06-20 08:03:03 --> Hooks Class Initialized
DEBUG - 2024-06-20 08:03:03 --> UTF-8 Support Enabled
INFO - 2024-06-20 08:03:03 --> Utf8 Class Initialized
INFO - 2024-06-20 08:03:03 --> URI Class Initialized
INFO - 2024-06-20 08:03:03 --> Router Class Initialized
INFO - 2024-06-20 08:03:03 --> Output Class Initialized
INFO - 2024-06-20 08:03:03 --> Security Class Initialized
DEBUG - 2024-06-20 08:03:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-20 08:03:03 --> Input Class Initialized
INFO - 2024-06-20 08:03:03 --> Language Class Initialized
INFO - 2024-06-20 08:03:03 --> Language Class Initialized
INFO - 2024-06-20 08:03:03 --> Config Class Initialized
INFO - 2024-06-20 08:03:03 --> Loader Class Initialized
INFO - 2024-06-20 08:03:03 --> Helper loaded: url_helper
INFO - 2024-06-20 08:03:03 --> Helper loaded: file_helper
INFO - 2024-06-20 08:03:03 --> Helper loaded: form_helper
INFO - 2024-06-20 08:03:03 --> Helper loaded: my_helper
INFO - 2024-06-20 08:03:03 --> Database Driver Class Initialized
INFO - 2024-06-20 08:03:03 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-20 08:03:03 --> Controller Class Initialized
INFO - 2024-06-20 08:03:03 --> Helper loaded: cookie_helper
INFO - 2024-06-20 08:03:03 --> Config Class Initialized
INFO - 2024-06-20 08:03:03 --> Hooks Class Initialized
DEBUG - 2024-06-20 08:03:03 --> UTF-8 Support Enabled
INFO - 2024-06-20 08:03:03 --> Utf8 Class Initialized
INFO - 2024-06-20 08:03:03 --> URI Class Initialized
INFO - 2024-06-20 08:03:03 --> Router Class Initialized
INFO - 2024-06-20 08:03:03 --> Output Class Initialized
INFO - 2024-06-20 08:03:03 --> Security Class Initialized
DEBUG - 2024-06-20 08:03:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-20 08:03:03 --> Input Class Initialized
INFO - 2024-06-20 08:03:03 --> Language Class Initialized
INFO - 2024-06-20 08:03:03 --> Language Class Initialized
INFO - 2024-06-20 08:03:03 --> Config Class Initialized
INFO - 2024-06-20 08:03:03 --> Loader Class Initialized
INFO - 2024-06-20 08:03:03 --> Helper loaded: url_helper
INFO - 2024-06-20 08:03:03 --> Helper loaded: file_helper
INFO - 2024-06-20 08:03:03 --> Helper loaded: form_helper
INFO - 2024-06-20 08:03:03 --> Helper loaded: my_helper
INFO - 2024-06-20 08:03:03 --> Database Driver Class Initialized
INFO - 2024-06-20 08:03:03 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-20 08:03:03 --> Controller Class Initialized
INFO - 2024-06-20 08:03:03 --> Config Class Initialized
INFO - 2024-06-20 08:03:03 --> Hooks Class Initialized
DEBUG - 2024-06-20 08:03:03 --> UTF-8 Support Enabled
INFO - 2024-06-20 08:03:03 --> Utf8 Class Initialized
INFO - 2024-06-20 08:03:03 --> URI Class Initialized
INFO - 2024-06-20 08:03:03 --> Router Class Initialized
INFO - 2024-06-20 08:03:03 --> Output Class Initialized
INFO - 2024-06-20 08:03:03 --> Security Class Initialized
DEBUG - 2024-06-20 08:03:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-20 08:03:03 --> Input Class Initialized
INFO - 2024-06-20 08:03:03 --> Language Class Initialized
INFO - 2024-06-20 08:03:03 --> Language Class Initialized
INFO - 2024-06-20 08:03:03 --> Config Class Initialized
INFO - 2024-06-20 08:03:03 --> Loader Class Initialized
INFO - 2024-06-20 08:03:03 --> Helper loaded: url_helper
INFO - 2024-06-20 08:03:03 --> Helper loaded: file_helper
INFO - 2024-06-20 08:03:03 --> Helper loaded: form_helper
INFO - 2024-06-20 08:03:03 --> Helper loaded: my_helper
INFO - 2024-06-20 08:03:03 --> Database Driver Class Initialized
INFO - 2024-06-20 08:03:03 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-20 08:03:03 --> Controller Class Initialized
DEBUG - 2024-06-20 08:03:03 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/login/views/login.php
DEBUG - 2024-06-20 08:03:03 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-06-20 08:03:03 --> Final output sent to browser
DEBUG - 2024-06-20 08:03:03 --> Total execution time: 0.0260
INFO - 2024-06-20 08:03:12 --> Config Class Initialized
INFO - 2024-06-20 08:03:12 --> Hooks Class Initialized
DEBUG - 2024-06-20 08:03:12 --> UTF-8 Support Enabled
INFO - 2024-06-20 08:03:12 --> Utf8 Class Initialized
INFO - 2024-06-20 08:03:12 --> URI Class Initialized
INFO - 2024-06-20 08:03:12 --> Router Class Initialized
INFO - 2024-06-20 08:03:12 --> Output Class Initialized
INFO - 2024-06-20 08:03:12 --> Security Class Initialized
DEBUG - 2024-06-20 08:03:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-20 08:03:12 --> Input Class Initialized
INFO - 2024-06-20 08:03:12 --> Language Class Initialized
INFO - 2024-06-20 08:03:12 --> Language Class Initialized
INFO - 2024-06-20 08:03:12 --> Config Class Initialized
INFO - 2024-06-20 08:03:12 --> Loader Class Initialized
INFO - 2024-06-20 08:03:12 --> Helper loaded: url_helper
INFO - 2024-06-20 08:03:12 --> Helper loaded: file_helper
INFO - 2024-06-20 08:03:12 --> Helper loaded: form_helper
INFO - 2024-06-20 08:03:12 --> Helper loaded: my_helper
INFO - 2024-06-20 08:03:12 --> Database Driver Class Initialized
INFO - 2024-06-20 08:03:12 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-20 08:03:12 --> Controller Class Initialized
INFO - 2024-06-20 08:03:12 --> Helper loaded: cookie_helper
INFO - 2024-06-20 08:03:12 --> Final output sent to browser
DEBUG - 2024-06-20 08:03:12 --> Total execution time: 0.0318
INFO - 2024-06-20 08:03:12 --> Config Class Initialized
INFO - 2024-06-20 08:03:12 --> Hooks Class Initialized
DEBUG - 2024-06-20 08:03:12 --> UTF-8 Support Enabled
INFO - 2024-06-20 08:03:12 --> Utf8 Class Initialized
INFO - 2024-06-20 08:03:12 --> URI Class Initialized
INFO - 2024-06-20 08:03:12 --> Router Class Initialized
INFO - 2024-06-20 08:03:12 --> Output Class Initialized
INFO - 2024-06-20 08:03:12 --> Security Class Initialized
DEBUG - 2024-06-20 08:03:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-20 08:03:12 --> Input Class Initialized
INFO - 2024-06-20 08:03:12 --> Language Class Initialized
INFO - 2024-06-20 08:03:12 --> Language Class Initialized
INFO - 2024-06-20 08:03:12 --> Config Class Initialized
INFO - 2024-06-20 08:03:12 --> Loader Class Initialized
INFO - 2024-06-20 08:03:12 --> Helper loaded: url_helper
INFO - 2024-06-20 08:03:12 --> Helper loaded: file_helper
INFO - 2024-06-20 08:03:12 --> Helper loaded: form_helper
INFO - 2024-06-20 08:03:12 --> Helper loaded: my_helper
INFO - 2024-06-20 08:03:12 --> Database Driver Class Initialized
INFO - 2024-06-20 08:03:12 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-20 08:03:12 --> Controller Class Initialized
DEBUG - 2024-06-20 08:03:12 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/home/views/v_home_guru.php
DEBUG - 2024-06-20 08:03:12 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-06-20 08:03:12 --> Final output sent to browser
DEBUG - 2024-06-20 08:03:12 --> Total execution time: 0.0287
INFO - 2024-06-20 08:03:14 --> Config Class Initialized
INFO - 2024-06-20 08:03:14 --> Hooks Class Initialized
DEBUG - 2024-06-20 08:03:14 --> UTF-8 Support Enabled
INFO - 2024-06-20 08:03:14 --> Utf8 Class Initialized
INFO - 2024-06-20 08:03:14 --> URI Class Initialized
INFO - 2024-06-20 08:03:14 --> Router Class Initialized
INFO - 2024-06-20 08:03:14 --> Output Class Initialized
INFO - 2024-06-20 08:03:14 --> Security Class Initialized
DEBUG - 2024-06-20 08:03:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-20 08:03:14 --> Input Class Initialized
INFO - 2024-06-20 08:03:14 --> Language Class Initialized
INFO - 2024-06-20 08:03:14 --> Language Class Initialized
INFO - 2024-06-20 08:03:14 --> Config Class Initialized
INFO - 2024-06-20 08:03:14 --> Loader Class Initialized
INFO - 2024-06-20 08:03:14 --> Helper loaded: url_helper
INFO - 2024-06-20 08:03:14 --> Helper loaded: file_helper
INFO - 2024-06-20 08:03:14 --> Helper loaded: form_helper
INFO - 2024-06-20 08:03:14 --> Helper loaded: my_helper
INFO - 2024-06-20 08:03:14 --> Database Driver Class Initialized
INFO - 2024-06-20 08:03:14 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-20 08:03:14 --> Controller Class Initialized
DEBUG - 2024-06-20 08:03:14 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/view_mapel/views/v_view_mapel.php
DEBUG - 2024-06-20 08:03:14 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-06-20 08:03:14 --> Final output sent to browser
DEBUG - 2024-06-20 08:03:14 --> Total execution time: 0.0267
INFO - 2024-06-20 08:03:16 --> Config Class Initialized
INFO - 2024-06-20 08:03:16 --> Hooks Class Initialized
DEBUG - 2024-06-20 08:03:16 --> UTF-8 Support Enabled
INFO - 2024-06-20 08:03:16 --> Utf8 Class Initialized
INFO - 2024-06-20 08:03:16 --> URI Class Initialized
INFO - 2024-06-20 08:03:16 --> Router Class Initialized
INFO - 2024-06-20 08:03:16 --> Output Class Initialized
INFO - 2024-06-20 08:03:16 --> Security Class Initialized
DEBUG - 2024-06-20 08:03:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-20 08:03:16 --> Input Class Initialized
INFO - 2024-06-20 08:03:16 --> Language Class Initialized
INFO - 2024-06-20 08:03:16 --> Language Class Initialized
INFO - 2024-06-20 08:03:16 --> Config Class Initialized
INFO - 2024-06-20 08:03:16 --> Loader Class Initialized
INFO - 2024-06-20 08:03:16 --> Helper loaded: url_helper
INFO - 2024-06-20 08:03:16 --> Helper loaded: file_helper
INFO - 2024-06-20 08:03:16 --> Helper loaded: form_helper
INFO - 2024-06-20 08:03:16 --> Helper loaded: my_helper
INFO - 2024-06-20 08:03:16 --> Database Driver Class Initialized
INFO - 2024-06-20 08:03:16 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-20 08:03:16 --> Controller Class Initialized
DEBUG - 2024-06-20 08:03:16 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/views/list.php
DEBUG - 2024-06-20 08:03:16 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-06-20 08:03:16 --> Final output sent to browser
DEBUG - 2024-06-20 08:03:16 --> Total execution time: 0.0320
INFO - 2024-06-20 08:03:16 --> Config Class Initialized
INFO - 2024-06-20 08:03:16 --> Hooks Class Initialized
DEBUG - 2024-06-20 08:03:16 --> UTF-8 Support Enabled
INFO - 2024-06-20 08:03:16 --> Utf8 Class Initialized
INFO - 2024-06-20 08:03:16 --> URI Class Initialized
INFO - 2024-06-20 08:03:16 --> Router Class Initialized
INFO - 2024-06-20 08:03:16 --> Output Class Initialized
INFO - 2024-06-20 08:03:16 --> Security Class Initialized
DEBUG - 2024-06-20 08:03:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-20 08:03:16 --> Input Class Initialized
INFO - 2024-06-20 08:03:16 --> Language Class Initialized
INFO - 2024-06-20 08:03:16 --> Language Class Initialized
INFO - 2024-06-20 08:03:16 --> Config Class Initialized
INFO - 2024-06-20 08:03:16 --> Loader Class Initialized
INFO - 2024-06-20 08:03:16 --> Helper loaded: url_helper
INFO - 2024-06-20 08:03:16 --> Helper loaded: file_helper
INFO - 2024-06-20 08:03:16 --> Helper loaded: form_helper
INFO - 2024-06-20 08:03:16 --> Helper loaded: my_helper
INFO - 2024-06-20 08:03:16 --> Database Driver Class Initialized
INFO - 2024-06-20 08:03:16 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-20 08:03:16 --> Controller Class Initialized
INFO - 2024-06-20 08:03:17 --> Config Class Initialized
INFO - 2024-06-20 08:03:17 --> Hooks Class Initialized
DEBUG - 2024-06-20 08:03:17 --> UTF-8 Support Enabled
INFO - 2024-06-20 08:03:17 --> Utf8 Class Initialized
INFO - 2024-06-20 08:03:17 --> URI Class Initialized
INFO - 2024-06-20 08:03:17 --> Router Class Initialized
INFO - 2024-06-20 08:03:17 --> Output Class Initialized
INFO - 2024-06-20 08:03:17 --> Security Class Initialized
DEBUG - 2024-06-20 08:03:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-20 08:03:17 --> Input Class Initialized
INFO - 2024-06-20 08:03:17 --> Language Class Initialized
INFO - 2024-06-20 08:03:17 --> Language Class Initialized
INFO - 2024-06-20 08:03:17 --> Config Class Initialized
INFO - 2024-06-20 08:03:17 --> Loader Class Initialized
INFO - 2024-06-20 08:03:17 --> Helper loaded: url_helper
INFO - 2024-06-20 08:03:17 --> Helper loaded: file_helper
INFO - 2024-06-20 08:03:17 --> Helper loaded: form_helper
INFO - 2024-06-20 08:03:17 --> Helper loaded: my_helper
INFO - 2024-06-20 08:03:17 --> Database Driver Class Initialized
INFO - 2024-06-20 08:03:17 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-20 08:03:17 --> Controller Class Initialized
INFO - 2024-06-20 08:03:20 --> Config Class Initialized
INFO - 2024-06-20 08:03:20 --> Hooks Class Initialized
DEBUG - 2024-06-20 08:03:20 --> UTF-8 Support Enabled
INFO - 2024-06-20 08:03:20 --> Utf8 Class Initialized
INFO - 2024-06-20 08:03:20 --> URI Class Initialized
INFO - 2024-06-20 08:03:20 --> Router Class Initialized
INFO - 2024-06-20 08:03:20 --> Output Class Initialized
INFO - 2024-06-20 08:03:20 --> Security Class Initialized
DEBUG - 2024-06-20 08:03:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-20 08:03:20 --> Input Class Initialized
INFO - 2024-06-20 08:03:20 --> Language Class Initialized
INFO - 2024-06-20 08:03:20 --> Language Class Initialized
INFO - 2024-06-20 08:03:20 --> Config Class Initialized
INFO - 2024-06-20 08:03:20 --> Loader Class Initialized
INFO - 2024-06-20 08:03:20 --> Helper loaded: url_helper
INFO - 2024-06-20 08:03:20 --> Helper loaded: file_helper
INFO - 2024-06-20 08:03:20 --> Helper loaded: form_helper
INFO - 2024-06-20 08:03:20 --> Helper loaded: my_helper
INFO - 2024-06-20 08:03:20 --> Database Driver Class Initialized
INFO - 2024-06-20 08:03:20 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-20 08:03:20 --> Controller Class Initialized
DEBUG - 2024-06-20 08:03:20 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/view_mapel/views/v_view_mapel.php
DEBUG - 2024-06-20 08:03:20 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-06-20 08:03:20 --> Final output sent to browser
DEBUG - 2024-06-20 08:03:20 --> Total execution time: 0.0294
INFO - 2024-06-20 08:03:21 --> Config Class Initialized
INFO - 2024-06-20 08:03:21 --> Hooks Class Initialized
DEBUG - 2024-06-20 08:03:21 --> UTF-8 Support Enabled
INFO - 2024-06-20 08:03:21 --> Utf8 Class Initialized
INFO - 2024-06-20 08:03:21 --> URI Class Initialized
INFO - 2024-06-20 08:03:21 --> Router Class Initialized
INFO - 2024-06-20 08:03:21 --> Output Class Initialized
INFO - 2024-06-20 08:03:21 --> Security Class Initialized
DEBUG - 2024-06-20 08:03:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-20 08:03:21 --> Input Class Initialized
INFO - 2024-06-20 08:03:21 --> Language Class Initialized
INFO - 2024-06-20 08:03:21 --> Language Class Initialized
INFO - 2024-06-20 08:03:21 --> Config Class Initialized
INFO - 2024-06-20 08:03:21 --> Loader Class Initialized
INFO - 2024-06-20 08:03:21 --> Helper loaded: url_helper
INFO - 2024-06-20 08:03:21 --> Helper loaded: file_helper
INFO - 2024-06-20 08:03:21 --> Helper loaded: form_helper
INFO - 2024-06-20 08:03:21 --> Helper loaded: my_helper
INFO - 2024-06-20 08:03:21 --> Database Driver Class Initialized
INFO - 2024-06-20 08:03:21 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-20 08:03:21 --> Controller Class Initialized
DEBUG - 2024-06-20 08:03:21 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/views/list.php
DEBUG - 2024-06-20 08:03:21 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-06-20 08:03:21 --> Final output sent to browser
DEBUG - 2024-06-20 08:03:21 --> Total execution time: 0.0511
INFO - 2024-06-20 08:03:22 --> Config Class Initialized
INFO - 2024-06-20 08:03:22 --> Hooks Class Initialized
DEBUG - 2024-06-20 08:03:22 --> UTF-8 Support Enabled
INFO - 2024-06-20 08:03:22 --> Utf8 Class Initialized
INFO - 2024-06-20 08:03:22 --> URI Class Initialized
INFO - 2024-06-20 08:03:22 --> Router Class Initialized
INFO - 2024-06-20 08:03:22 --> Output Class Initialized
INFO - 2024-06-20 08:03:22 --> Security Class Initialized
DEBUG - 2024-06-20 08:03:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-20 08:03:22 --> Input Class Initialized
INFO - 2024-06-20 08:03:22 --> Language Class Initialized
INFO - 2024-06-20 08:03:22 --> Language Class Initialized
INFO - 2024-06-20 08:03:22 --> Config Class Initialized
INFO - 2024-06-20 08:03:22 --> Loader Class Initialized
INFO - 2024-06-20 08:03:22 --> Helper loaded: url_helper
INFO - 2024-06-20 08:03:22 --> Helper loaded: file_helper
INFO - 2024-06-20 08:03:22 --> Helper loaded: form_helper
INFO - 2024-06-20 08:03:22 --> Helper loaded: my_helper
INFO - 2024-06-20 08:03:22 --> Database Driver Class Initialized
INFO - 2024-06-20 08:03:22 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-20 08:03:22 --> Controller Class Initialized
INFO - 2024-06-20 08:03:24 --> Config Class Initialized
INFO - 2024-06-20 08:03:24 --> Hooks Class Initialized
DEBUG - 2024-06-20 08:03:24 --> UTF-8 Support Enabled
INFO - 2024-06-20 08:03:24 --> Utf8 Class Initialized
INFO - 2024-06-20 08:03:24 --> URI Class Initialized
INFO - 2024-06-20 08:03:24 --> Router Class Initialized
INFO - 2024-06-20 08:03:24 --> Output Class Initialized
INFO - 2024-06-20 08:03:24 --> Security Class Initialized
DEBUG - 2024-06-20 08:03:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-20 08:03:24 --> Input Class Initialized
INFO - 2024-06-20 08:03:24 --> Language Class Initialized
INFO - 2024-06-20 08:03:24 --> Language Class Initialized
INFO - 2024-06-20 08:03:24 --> Config Class Initialized
INFO - 2024-06-20 08:03:24 --> Loader Class Initialized
INFO - 2024-06-20 08:03:24 --> Helper loaded: url_helper
INFO - 2024-06-20 08:03:24 --> Helper loaded: file_helper
INFO - 2024-06-20 08:03:24 --> Helper loaded: form_helper
INFO - 2024-06-20 08:03:24 --> Helper loaded: my_helper
INFO - 2024-06-20 08:03:24 --> Database Driver Class Initialized
INFO - 2024-06-20 08:03:24 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-20 08:03:24 --> Controller Class Initialized
INFO - 2024-06-20 08:04:17 --> Config Class Initialized
INFO - 2024-06-20 08:04:17 --> Hooks Class Initialized
DEBUG - 2024-06-20 08:04:17 --> UTF-8 Support Enabled
INFO - 2024-06-20 08:04:17 --> Utf8 Class Initialized
INFO - 2024-06-20 08:04:17 --> URI Class Initialized
INFO - 2024-06-20 08:04:17 --> Router Class Initialized
INFO - 2024-06-20 08:04:17 --> Output Class Initialized
INFO - 2024-06-20 08:04:17 --> Security Class Initialized
DEBUG - 2024-06-20 08:04:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-20 08:04:17 --> Input Class Initialized
INFO - 2024-06-20 08:04:17 --> Language Class Initialized
INFO - 2024-06-20 08:04:17 --> Language Class Initialized
INFO - 2024-06-20 08:04:17 --> Config Class Initialized
INFO - 2024-06-20 08:04:17 --> Loader Class Initialized
INFO - 2024-06-20 08:04:17 --> Helper loaded: url_helper
INFO - 2024-06-20 08:04:17 --> Helper loaded: file_helper
INFO - 2024-06-20 08:04:17 --> Helper loaded: form_helper
INFO - 2024-06-20 08:04:17 --> Helper loaded: my_helper
INFO - 2024-06-20 08:04:17 --> Database Driver Class Initialized
INFO - 2024-06-20 08:04:17 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-20 08:04:17 --> Controller Class Initialized
INFO - 2024-06-20 08:04:17 --> Helper loaded: cookie_helper
INFO - 2024-06-20 08:04:17 --> Config Class Initialized
INFO - 2024-06-20 08:04:17 --> Hooks Class Initialized
DEBUG - 2024-06-20 08:04:17 --> UTF-8 Support Enabled
INFO - 2024-06-20 08:04:17 --> Utf8 Class Initialized
INFO - 2024-06-20 08:04:17 --> URI Class Initialized
INFO - 2024-06-20 08:04:17 --> Router Class Initialized
INFO - 2024-06-20 08:04:17 --> Output Class Initialized
INFO - 2024-06-20 08:04:17 --> Security Class Initialized
DEBUG - 2024-06-20 08:04:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-20 08:04:17 --> Input Class Initialized
INFO - 2024-06-20 08:04:17 --> Language Class Initialized
INFO - 2024-06-20 08:04:17 --> Language Class Initialized
INFO - 2024-06-20 08:04:17 --> Config Class Initialized
INFO - 2024-06-20 08:04:17 --> Loader Class Initialized
INFO - 2024-06-20 08:04:17 --> Helper loaded: url_helper
INFO - 2024-06-20 08:04:17 --> Helper loaded: file_helper
INFO - 2024-06-20 08:04:17 --> Helper loaded: form_helper
INFO - 2024-06-20 08:04:17 --> Helper loaded: my_helper
INFO - 2024-06-20 08:04:17 --> Database Driver Class Initialized
INFO - 2024-06-20 08:04:17 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-20 08:04:17 --> Controller Class Initialized
INFO - 2024-06-20 08:04:18 --> Config Class Initialized
INFO - 2024-06-20 08:04:18 --> Hooks Class Initialized
DEBUG - 2024-06-20 08:04:18 --> UTF-8 Support Enabled
INFO - 2024-06-20 08:04:18 --> Utf8 Class Initialized
INFO - 2024-06-20 08:04:18 --> URI Class Initialized
INFO - 2024-06-20 08:04:18 --> Router Class Initialized
INFO - 2024-06-20 08:04:18 --> Output Class Initialized
INFO - 2024-06-20 08:04:18 --> Security Class Initialized
DEBUG - 2024-06-20 08:04:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-20 08:04:18 --> Input Class Initialized
INFO - 2024-06-20 08:04:18 --> Language Class Initialized
INFO - 2024-06-20 08:04:18 --> Language Class Initialized
INFO - 2024-06-20 08:04:18 --> Config Class Initialized
INFO - 2024-06-20 08:04:18 --> Loader Class Initialized
INFO - 2024-06-20 08:04:18 --> Helper loaded: url_helper
INFO - 2024-06-20 08:04:18 --> Helper loaded: file_helper
INFO - 2024-06-20 08:04:18 --> Helper loaded: form_helper
INFO - 2024-06-20 08:04:18 --> Helper loaded: my_helper
INFO - 2024-06-20 08:04:18 --> Database Driver Class Initialized
INFO - 2024-06-20 08:04:18 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-20 08:04:18 --> Controller Class Initialized
DEBUG - 2024-06-20 08:04:18 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/login/views/login.php
DEBUG - 2024-06-20 08:04:18 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-06-20 08:04:18 --> Final output sent to browser
DEBUG - 2024-06-20 08:04:18 --> Total execution time: 0.0265
INFO - 2024-06-20 08:04:28 --> Config Class Initialized
INFO - 2024-06-20 08:04:28 --> Hooks Class Initialized
DEBUG - 2024-06-20 08:04:28 --> UTF-8 Support Enabled
INFO - 2024-06-20 08:04:28 --> Utf8 Class Initialized
INFO - 2024-06-20 08:04:28 --> URI Class Initialized
INFO - 2024-06-20 08:04:28 --> Router Class Initialized
INFO - 2024-06-20 08:04:28 --> Output Class Initialized
INFO - 2024-06-20 08:04:28 --> Security Class Initialized
DEBUG - 2024-06-20 08:04:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-20 08:04:28 --> Input Class Initialized
INFO - 2024-06-20 08:04:28 --> Language Class Initialized
INFO - 2024-06-20 08:04:28 --> Language Class Initialized
INFO - 2024-06-20 08:04:28 --> Config Class Initialized
INFO - 2024-06-20 08:04:28 --> Loader Class Initialized
INFO - 2024-06-20 08:04:28 --> Helper loaded: url_helper
INFO - 2024-06-20 08:04:28 --> Helper loaded: file_helper
INFO - 2024-06-20 08:04:28 --> Helper loaded: form_helper
INFO - 2024-06-20 08:04:28 --> Helper loaded: my_helper
INFO - 2024-06-20 08:04:28 --> Database Driver Class Initialized
INFO - 2024-06-20 08:04:28 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-20 08:04:28 --> Controller Class Initialized
INFO - 2024-06-20 08:04:28 --> Helper loaded: cookie_helper
INFO - 2024-06-20 08:04:28 --> Final output sent to browser
DEBUG - 2024-06-20 08:04:28 --> Total execution time: 0.0287
INFO - 2024-06-20 08:04:28 --> Config Class Initialized
INFO - 2024-06-20 08:04:28 --> Hooks Class Initialized
DEBUG - 2024-06-20 08:04:28 --> UTF-8 Support Enabled
INFO - 2024-06-20 08:04:28 --> Utf8 Class Initialized
INFO - 2024-06-20 08:04:28 --> URI Class Initialized
INFO - 2024-06-20 08:04:28 --> Router Class Initialized
INFO - 2024-06-20 08:04:28 --> Output Class Initialized
INFO - 2024-06-20 08:04:28 --> Security Class Initialized
DEBUG - 2024-06-20 08:04:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-20 08:04:28 --> Input Class Initialized
INFO - 2024-06-20 08:04:28 --> Language Class Initialized
INFO - 2024-06-20 08:04:28 --> Language Class Initialized
INFO - 2024-06-20 08:04:28 --> Config Class Initialized
INFO - 2024-06-20 08:04:28 --> Loader Class Initialized
INFO - 2024-06-20 08:04:28 --> Helper loaded: url_helper
INFO - 2024-06-20 08:04:28 --> Helper loaded: file_helper
INFO - 2024-06-20 08:04:28 --> Helper loaded: form_helper
INFO - 2024-06-20 08:04:28 --> Helper loaded: my_helper
INFO - 2024-06-20 08:04:28 --> Database Driver Class Initialized
INFO - 2024-06-20 08:04:28 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-20 08:04:28 --> Controller Class Initialized
DEBUG - 2024-06-20 08:04:28 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/home/views/v_home_guru.php
DEBUG - 2024-06-20 08:04:28 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-06-20 08:04:28 --> Final output sent to browser
DEBUG - 2024-06-20 08:04:28 --> Total execution time: 0.0260
INFO - 2024-06-20 08:04:30 --> Config Class Initialized
INFO - 2024-06-20 08:04:30 --> Hooks Class Initialized
DEBUG - 2024-06-20 08:04:30 --> UTF-8 Support Enabled
INFO - 2024-06-20 08:04:30 --> Utf8 Class Initialized
INFO - 2024-06-20 08:04:30 --> URI Class Initialized
INFO - 2024-06-20 08:04:30 --> Router Class Initialized
INFO - 2024-06-20 08:04:30 --> Output Class Initialized
INFO - 2024-06-20 08:04:30 --> Security Class Initialized
DEBUG - 2024-06-20 08:04:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-20 08:04:30 --> Input Class Initialized
INFO - 2024-06-20 08:04:30 --> Language Class Initialized
INFO - 2024-06-20 08:04:30 --> Language Class Initialized
INFO - 2024-06-20 08:04:30 --> Config Class Initialized
INFO - 2024-06-20 08:04:30 --> Loader Class Initialized
INFO - 2024-06-20 08:04:30 --> Helper loaded: url_helper
INFO - 2024-06-20 08:04:30 --> Helper loaded: file_helper
INFO - 2024-06-20 08:04:30 --> Helper loaded: form_helper
INFO - 2024-06-20 08:04:30 --> Helper loaded: my_helper
INFO - 2024-06-20 08:04:30 --> Database Driver Class Initialized
INFO - 2024-06-20 08:04:30 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-20 08:04:30 --> Controller Class Initialized
DEBUG - 2024-06-20 08:04:30 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/view_mapel/views/v_view_mapel.php
DEBUG - 2024-06-20 08:04:30 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-06-20 08:04:30 --> Final output sent to browser
DEBUG - 2024-06-20 08:04:30 --> Total execution time: 0.0491
INFO - 2024-06-20 08:04:32 --> Config Class Initialized
INFO - 2024-06-20 08:04:32 --> Hooks Class Initialized
DEBUG - 2024-06-20 08:04:32 --> UTF-8 Support Enabled
INFO - 2024-06-20 08:04:32 --> Utf8 Class Initialized
INFO - 2024-06-20 08:04:32 --> URI Class Initialized
INFO - 2024-06-20 08:04:32 --> Router Class Initialized
INFO - 2024-06-20 08:04:32 --> Output Class Initialized
INFO - 2024-06-20 08:04:32 --> Security Class Initialized
DEBUG - 2024-06-20 08:04:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-20 08:04:32 --> Input Class Initialized
INFO - 2024-06-20 08:04:32 --> Language Class Initialized
INFO - 2024-06-20 08:04:32 --> Language Class Initialized
INFO - 2024-06-20 08:04:32 --> Config Class Initialized
INFO - 2024-06-20 08:04:32 --> Loader Class Initialized
INFO - 2024-06-20 08:04:32 --> Helper loaded: url_helper
INFO - 2024-06-20 08:04:32 --> Helper loaded: file_helper
INFO - 2024-06-20 08:04:32 --> Helper loaded: form_helper
INFO - 2024-06-20 08:04:32 --> Helper loaded: my_helper
INFO - 2024-06-20 08:04:32 --> Database Driver Class Initialized
INFO - 2024-06-20 08:04:32 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-20 08:04:32 --> Controller Class Initialized
DEBUG - 2024-06-20 08:04:32 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/views/list.php
DEBUG - 2024-06-20 08:04:32 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-06-20 08:04:32 --> Final output sent to browser
DEBUG - 2024-06-20 08:04:32 --> Total execution time: 0.0302
INFO - 2024-06-20 08:04:32 --> Config Class Initialized
INFO - 2024-06-20 08:04:32 --> Hooks Class Initialized
DEBUG - 2024-06-20 08:04:32 --> UTF-8 Support Enabled
INFO - 2024-06-20 08:04:32 --> Utf8 Class Initialized
INFO - 2024-06-20 08:04:32 --> URI Class Initialized
INFO - 2024-06-20 08:04:32 --> Router Class Initialized
INFO - 2024-06-20 08:04:32 --> Output Class Initialized
INFO - 2024-06-20 08:04:32 --> Security Class Initialized
DEBUG - 2024-06-20 08:04:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-20 08:04:32 --> Input Class Initialized
INFO - 2024-06-20 08:04:32 --> Language Class Initialized
INFO - 2024-06-20 08:04:32 --> Language Class Initialized
INFO - 2024-06-20 08:04:32 --> Config Class Initialized
INFO - 2024-06-20 08:04:32 --> Loader Class Initialized
INFO - 2024-06-20 08:04:32 --> Helper loaded: url_helper
INFO - 2024-06-20 08:04:32 --> Helper loaded: file_helper
INFO - 2024-06-20 08:04:32 --> Helper loaded: form_helper
INFO - 2024-06-20 08:04:32 --> Helper loaded: my_helper
INFO - 2024-06-20 08:04:32 --> Database Driver Class Initialized
INFO - 2024-06-20 08:04:32 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-20 08:04:32 --> Controller Class Initialized
INFO - 2024-06-20 08:04:35 --> Config Class Initialized
INFO - 2024-06-20 08:04:35 --> Hooks Class Initialized
DEBUG - 2024-06-20 08:04:35 --> UTF-8 Support Enabled
INFO - 2024-06-20 08:04:35 --> Utf8 Class Initialized
INFO - 2024-06-20 08:04:35 --> URI Class Initialized
INFO - 2024-06-20 08:04:35 --> Router Class Initialized
INFO - 2024-06-20 08:04:35 --> Output Class Initialized
INFO - 2024-06-20 08:04:35 --> Security Class Initialized
DEBUG - 2024-06-20 08:04:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-20 08:04:35 --> Input Class Initialized
INFO - 2024-06-20 08:04:35 --> Language Class Initialized
INFO - 2024-06-20 08:04:35 --> Language Class Initialized
INFO - 2024-06-20 08:04:35 --> Config Class Initialized
INFO - 2024-06-20 08:04:35 --> Loader Class Initialized
INFO - 2024-06-20 08:04:35 --> Helper loaded: url_helper
INFO - 2024-06-20 08:04:35 --> Helper loaded: file_helper
INFO - 2024-06-20 08:04:35 --> Helper loaded: form_helper
INFO - 2024-06-20 08:04:35 --> Helper loaded: my_helper
INFO - 2024-06-20 08:04:35 --> Database Driver Class Initialized
INFO - 2024-06-20 08:04:35 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-20 08:04:35 --> Controller Class Initialized
INFO - 2024-06-20 08:05:02 --> Config Class Initialized
INFO - 2024-06-20 08:05:02 --> Hooks Class Initialized
DEBUG - 2024-06-20 08:05:02 --> UTF-8 Support Enabled
INFO - 2024-06-20 08:05:02 --> Utf8 Class Initialized
INFO - 2024-06-20 08:05:02 --> URI Class Initialized
INFO - 2024-06-20 08:05:02 --> Router Class Initialized
INFO - 2024-06-20 08:05:02 --> Output Class Initialized
INFO - 2024-06-20 08:05:02 --> Security Class Initialized
DEBUG - 2024-06-20 08:05:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-20 08:05:02 --> Input Class Initialized
INFO - 2024-06-20 08:05:02 --> Language Class Initialized
INFO - 2024-06-20 08:05:02 --> Language Class Initialized
INFO - 2024-06-20 08:05:02 --> Config Class Initialized
INFO - 2024-06-20 08:05:02 --> Loader Class Initialized
INFO - 2024-06-20 08:05:02 --> Helper loaded: url_helper
INFO - 2024-06-20 08:05:02 --> Helper loaded: file_helper
INFO - 2024-06-20 08:05:02 --> Helper loaded: form_helper
INFO - 2024-06-20 08:05:02 --> Helper loaded: my_helper
INFO - 2024-06-20 08:05:02 --> Database Driver Class Initialized
INFO - 2024-06-20 08:05:02 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-20 08:05:02 --> Controller Class Initialized
INFO - 2024-06-20 08:05:02 --> Final output sent to browser
DEBUG - 2024-06-20 08:05:02 --> Total execution time: 0.0504
INFO - 2024-06-20 08:05:24 --> Config Class Initialized
INFO - 2024-06-20 08:05:24 --> Hooks Class Initialized
DEBUG - 2024-06-20 08:05:24 --> UTF-8 Support Enabled
INFO - 2024-06-20 08:05:24 --> Utf8 Class Initialized
INFO - 2024-06-20 08:05:24 --> URI Class Initialized
INFO - 2024-06-20 08:05:24 --> Router Class Initialized
INFO - 2024-06-20 08:05:24 --> Output Class Initialized
INFO - 2024-06-20 08:05:24 --> Security Class Initialized
DEBUG - 2024-06-20 08:05:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-20 08:05:24 --> Input Class Initialized
INFO - 2024-06-20 08:05:24 --> Language Class Initialized
INFO - 2024-06-20 08:05:24 --> Language Class Initialized
INFO - 2024-06-20 08:05:24 --> Config Class Initialized
INFO - 2024-06-20 08:05:24 --> Loader Class Initialized
INFO - 2024-06-20 08:05:24 --> Helper loaded: url_helper
INFO - 2024-06-20 08:05:24 --> Helper loaded: file_helper
INFO - 2024-06-20 08:05:24 --> Helper loaded: form_helper
INFO - 2024-06-20 08:05:24 --> Helper loaded: my_helper
INFO - 2024-06-20 08:05:24 --> Database Driver Class Initialized
INFO - 2024-06-20 08:05:24 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-20 08:05:24 --> Controller Class Initialized
INFO - 2024-06-20 08:05:24 --> Helper loaded: cookie_helper
INFO - 2024-06-20 08:05:24 --> Config Class Initialized
INFO - 2024-06-20 08:05:24 --> Hooks Class Initialized
DEBUG - 2024-06-20 08:05:24 --> UTF-8 Support Enabled
INFO - 2024-06-20 08:05:24 --> Utf8 Class Initialized
INFO - 2024-06-20 08:05:24 --> URI Class Initialized
INFO - 2024-06-20 08:05:24 --> Router Class Initialized
INFO - 2024-06-20 08:05:24 --> Output Class Initialized
INFO - 2024-06-20 08:05:24 --> Security Class Initialized
DEBUG - 2024-06-20 08:05:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-20 08:05:24 --> Input Class Initialized
INFO - 2024-06-20 08:05:24 --> Language Class Initialized
INFO - 2024-06-20 08:05:24 --> Language Class Initialized
INFO - 2024-06-20 08:05:24 --> Config Class Initialized
INFO - 2024-06-20 08:05:24 --> Loader Class Initialized
INFO - 2024-06-20 08:05:24 --> Helper loaded: url_helper
INFO - 2024-06-20 08:05:24 --> Helper loaded: file_helper
INFO - 2024-06-20 08:05:24 --> Helper loaded: form_helper
INFO - 2024-06-20 08:05:24 --> Helper loaded: my_helper
INFO - 2024-06-20 08:05:24 --> Database Driver Class Initialized
INFO - 2024-06-20 08:05:24 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-20 08:05:24 --> Controller Class Initialized
INFO - 2024-06-20 08:05:24 --> Config Class Initialized
INFO - 2024-06-20 08:05:24 --> Hooks Class Initialized
DEBUG - 2024-06-20 08:05:24 --> UTF-8 Support Enabled
INFO - 2024-06-20 08:05:24 --> Utf8 Class Initialized
INFO - 2024-06-20 08:05:24 --> URI Class Initialized
INFO - 2024-06-20 08:05:24 --> Router Class Initialized
INFO - 2024-06-20 08:05:24 --> Output Class Initialized
INFO - 2024-06-20 08:05:24 --> Security Class Initialized
DEBUG - 2024-06-20 08:05:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-20 08:05:24 --> Input Class Initialized
INFO - 2024-06-20 08:05:24 --> Language Class Initialized
INFO - 2024-06-20 08:05:24 --> Language Class Initialized
INFO - 2024-06-20 08:05:24 --> Config Class Initialized
INFO - 2024-06-20 08:05:24 --> Loader Class Initialized
INFO - 2024-06-20 08:05:24 --> Helper loaded: url_helper
INFO - 2024-06-20 08:05:24 --> Helper loaded: file_helper
INFO - 2024-06-20 08:05:24 --> Helper loaded: form_helper
INFO - 2024-06-20 08:05:24 --> Helper loaded: my_helper
INFO - 2024-06-20 08:05:24 --> Database Driver Class Initialized
INFO - 2024-06-20 08:05:24 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-20 08:05:24 --> Controller Class Initialized
DEBUG - 2024-06-20 08:05:24 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/login/views/login.php
DEBUG - 2024-06-20 08:05:24 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-06-20 08:05:24 --> Final output sent to browser
DEBUG - 2024-06-20 08:05:24 --> Total execution time: 0.0259
INFO - 2024-06-20 08:05:33 --> Config Class Initialized
INFO - 2024-06-20 08:05:33 --> Hooks Class Initialized
DEBUG - 2024-06-20 08:05:33 --> UTF-8 Support Enabled
INFO - 2024-06-20 08:05:33 --> Utf8 Class Initialized
INFO - 2024-06-20 08:05:33 --> URI Class Initialized
INFO - 2024-06-20 08:05:33 --> Router Class Initialized
INFO - 2024-06-20 08:05:33 --> Output Class Initialized
INFO - 2024-06-20 08:05:33 --> Security Class Initialized
DEBUG - 2024-06-20 08:05:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-20 08:05:33 --> Input Class Initialized
INFO - 2024-06-20 08:05:33 --> Language Class Initialized
INFO - 2024-06-20 08:05:33 --> Language Class Initialized
INFO - 2024-06-20 08:05:33 --> Config Class Initialized
INFO - 2024-06-20 08:05:33 --> Loader Class Initialized
INFO - 2024-06-20 08:05:33 --> Helper loaded: url_helper
INFO - 2024-06-20 08:05:33 --> Helper loaded: file_helper
INFO - 2024-06-20 08:05:33 --> Helper loaded: form_helper
INFO - 2024-06-20 08:05:33 --> Helper loaded: my_helper
INFO - 2024-06-20 08:05:33 --> Database Driver Class Initialized
INFO - 2024-06-20 08:05:33 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-20 08:05:33 --> Controller Class Initialized
INFO - 2024-06-20 08:05:33 --> Helper loaded: cookie_helper
INFO - 2024-06-20 08:05:33 --> Final output sent to browser
DEBUG - 2024-06-20 08:05:33 --> Total execution time: 0.0282
INFO - 2024-06-20 08:05:33 --> Config Class Initialized
INFO - 2024-06-20 08:05:33 --> Hooks Class Initialized
DEBUG - 2024-06-20 08:05:33 --> UTF-8 Support Enabled
INFO - 2024-06-20 08:05:33 --> Utf8 Class Initialized
INFO - 2024-06-20 08:05:33 --> URI Class Initialized
INFO - 2024-06-20 08:05:33 --> Router Class Initialized
INFO - 2024-06-20 08:05:33 --> Output Class Initialized
INFO - 2024-06-20 08:05:33 --> Security Class Initialized
DEBUG - 2024-06-20 08:05:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-20 08:05:33 --> Input Class Initialized
INFO - 2024-06-20 08:05:33 --> Language Class Initialized
INFO - 2024-06-20 08:05:33 --> Language Class Initialized
INFO - 2024-06-20 08:05:33 --> Config Class Initialized
INFO - 2024-06-20 08:05:33 --> Loader Class Initialized
INFO - 2024-06-20 08:05:33 --> Helper loaded: url_helper
INFO - 2024-06-20 08:05:33 --> Helper loaded: file_helper
INFO - 2024-06-20 08:05:33 --> Helper loaded: form_helper
INFO - 2024-06-20 08:05:33 --> Helper loaded: my_helper
INFO - 2024-06-20 08:05:33 --> Database Driver Class Initialized
INFO - 2024-06-20 08:05:33 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-20 08:05:33 --> Controller Class Initialized
DEBUG - 2024-06-20 08:05:33 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/home/views/v_home_guru.php
DEBUG - 2024-06-20 08:05:33 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-06-20 08:05:33 --> Final output sent to browser
DEBUG - 2024-06-20 08:05:33 --> Total execution time: 0.0242
INFO - 2024-06-20 08:05:41 --> Config Class Initialized
INFO - 2024-06-20 08:05:41 --> Hooks Class Initialized
DEBUG - 2024-06-20 08:05:41 --> UTF-8 Support Enabled
INFO - 2024-06-20 08:05:41 --> Utf8 Class Initialized
INFO - 2024-06-20 08:05:41 --> URI Class Initialized
INFO - 2024-06-20 08:05:41 --> Router Class Initialized
INFO - 2024-06-20 08:05:41 --> Output Class Initialized
INFO - 2024-06-20 08:05:41 --> Security Class Initialized
DEBUG - 2024-06-20 08:05:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-20 08:05:41 --> Input Class Initialized
INFO - 2024-06-20 08:05:41 --> Language Class Initialized
INFO - 2024-06-20 08:05:41 --> Language Class Initialized
INFO - 2024-06-20 08:05:41 --> Config Class Initialized
INFO - 2024-06-20 08:05:41 --> Loader Class Initialized
INFO - 2024-06-20 08:05:41 --> Helper loaded: url_helper
INFO - 2024-06-20 08:05:41 --> Helper loaded: file_helper
INFO - 2024-06-20 08:05:41 --> Helper loaded: form_helper
INFO - 2024-06-20 08:05:41 --> Helper loaded: my_helper
INFO - 2024-06-20 08:05:41 --> Database Driver Class Initialized
INFO - 2024-06-20 08:05:41 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-20 08:05:41 --> Controller Class Initialized
DEBUG - 2024-06-20 08:05:41 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/view_mapel/views/v_view_mapel.php
DEBUG - 2024-06-20 08:05:41 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-06-20 08:05:41 --> Final output sent to browser
DEBUG - 2024-06-20 08:05:41 --> Total execution time: 0.0486
INFO - 2024-06-20 08:05:50 --> Config Class Initialized
INFO - 2024-06-20 08:05:50 --> Hooks Class Initialized
DEBUG - 2024-06-20 08:05:50 --> UTF-8 Support Enabled
INFO - 2024-06-20 08:05:50 --> Utf8 Class Initialized
INFO - 2024-06-20 08:05:50 --> URI Class Initialized
INFO - 2024-06-20 08:05:50 --> Router Class Initialized
INFO - 2024-06-20 08:05:50 --> Output Class Initialized
INFO - 2024-06-20 08:05:50 --> Security Class Initialized
DEBUG - 2024-06-20 08:05:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-20 08:05:50 --> Input Class Initialized
INFO - 2024-06-20 08:05:50 --> Language Class Initialized
INFO - 2024-06-20 08:05:50 --> Language Class Initialized
INFO - 2024-06-20 08:05:50 --> Config Class Initialized
INFO - 2024-06-20 08:05:50 --> Loader Class Initialized
INFO - 2024-06-20 08:05:50 --> Helper loaded: url_helper
INFO - 2024-06-20 08:05:50 --> Helper loaded: file_helper
INFO - 2024-06-20 08:05:50 --> Helper loaded: form_helper
INFO - 2024-06-20 08:05:50 --> Helper loaded: my_helper
INFO - 2024-06-20 08:05:50 --> Database Driver Class Initialized
INFO - 2024-06-20 08:05:50 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-20 08:05:50 --> Controller Class Initialized
DEBUG - 2024-06-20 08:05:50 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/views/list.php
DEBUG - 2024-06-20 08:05:50 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-06-20 08:05:50 --> Final output sent to browser
DEBUG - 2024-06-20 08:05:50 --> Total execution time: 0.0278
INFO - 2024-06-20 08:05:50 --> Config Class Initialized
INFO - 2024-06-20 08:05:50 --> Hooks Class Initialized
DEBUG - 2024-06-20 08:05:50 --> UTF-8 Support Enabled
INFO - 2024-06-20 08:05:50 --> Utf8 Class Initialized
INFO - 2024-06-20 08:05:50 --> URI Class Initialized
INFO - 2024-06-20 08:05:50 --> Router Class Initialized
INFO - 2024-06-20 08:05:50 --> Output Class Initialized
INFO - 2024-06-20 08:05:50 --> Security Class Initialized
DEBUG - 2024-06-20 08:05:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-20 08:05:50 --> Input Class Initialized
INFO - 2024-06-20 08:05:50 --> Language Class Initialized
INFO - 2024-06-20 08:05:50 --> Language Class Initialized
INFO - 2024-06-20 08:05:50 --> Config Class Initialized
INFO - 2024-06-20 08:05:50 --> Loader Class Initialized
INFO - 2024-06-20 08:05:50 --> Helper loaded: url_helper
INFO - 2024-06-20 08:05:50 --> Helper loaded: file_helper
INFO - 2024-06-20 08:05:50 --> Helper loaded: form_helper
INFO - 2024-06-20 08:05:51 --> Helper loaded: my_helper
INFO - 2024-06-20 08:05:51 --> Database Driver Class Initialized
INFO - 2024-06-20 08:05:51 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-20 08:05:51 --> Controller Class Initialized
INFO - 2024-06-20 08:05:59 --> Config Class Initialized
INFO - 2024-06-20 08:05:59 --> Hooks Class Initialized
DEBUG - 2024-06-20 08:05:59 --> UTF-8 Support Enabled
INFO - 2024-06-20 08:05:59 --> Utf8 Class Initialized
INFO - 2024-06-20 08:05:59 --> URI Class Initialized
INFO - 2024-06-20 08:05:59 --> Router Class Initialized
INFO - 2024-06-20 08:05:59 --> Output Class Initialized
INFO - 2024-06-20 08:05:59 --> Security Class Initialized
DEBUG - 2024-06-20 08:05:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-20 08:05:59 --> Input Class Initialized
INFO - 2024-06-20 08:05:59 --> Language Class Initialized
INFO - 2024-06-20 08:05:59 --> Language Class Initialized
INFO - 2024-06-20 08:05:59 --> Config Class Initialized
INFO - 2024-06-20 08:05:59 --> Loader Class Initialized
INFO - 2024-06-20 08:05:59 --> Helper loaded: url_helper
INFO - 2024-06-20 08:05:59 --> Helper loaded: file_helper
INFO - 2024-06-20 08:05:59 --> Helper loaded: form_helper
INFO - 2024-06-20 08:05:59 --> Helper loaded: my_helper
INFO - 2024-06-20 08:05:59 --> Database Driver Class Initialized
INFO - 2024-06-20 08:05:59 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-20 08:05:59 --> Controller Class Initialized
INFO - 2024-06-20 08:06:53 --> Config Class Initialized
INFO - 2024-06-20 08:06:53 --> Hooks Class Initialized
DEBUG - 2024-06-20 08:06:53 --> UTF-8 Support Enabled
INFO - 2024-06-20 08:06:53 --> Utf8 Class Initialized
INFO - 2024-06-20 08:06:53 --> URI Class Initialized
INFO - 2024-06-20 08:06:53 --> Router Class Initialized
INFO - 2024-06-20 08:06:53 --> Output Class Initialized
INFO - 2024-06-20 08:06:53 --> Security Class Initialized
DEBUG - 2024-06-20 08:06:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-20 08:06:53 --> Input Class Initialized
INFO - 2024-06-20 08:06:53 --> Language Class Initialized
INFO - 2024-06-20 08:06:53 --> Language Class Initialized
INFO - 2024-06-20 08:06:53 --> Config Class Initialized
INFO - 2024-06-20 08:06:53 --> Loader Class Initialized
INFO - 2024-06-20 08:06:53 --> Helper loaded: url_helper
INFO - 2024-06-20 08:06:53 --> Helper loaded: file_helper
INFO - 2024-06-20 08:06:53 --> Helper loaded: form_helper
INFO - 2024-06-20 08:06:53 --> Helper loaded: my_helper
INFO - 2024-06-20 08:06:53 --> Database Driver Class Initialized
INFO - 2024-06-20 08:06:53 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-20 08:06:53 --> Controller Class Initialized
INFO - 2024-06-20 08:06:53 --> Helper loaded: cookie_helper
INFO - 2024-06-20 08:06:53 --> Config Class Initialized
INFO - 2024-06-20 08:06:53 --> Hooks Class Initialized
DEBUG - 2024-06-20 08:06:53 --> UTF-8 Support Enabled
INFO - 2024-06-20 08:06:53 --> Utf8 Class Initialized
INFO - 2024-06-20 08:06:53 --> URI Class Initialized
INFO - 2024-06-20 08:06:53 --> Router Class Initialized
INFO - 2024-06-20 08:06:53 --> Output Class Initialized
INFO - 2024-06-20 08:06:53 --> Security Class Initialized
DEBUG - 2024-06-20 08:06:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-20 08:06:53 --> Input Class Initialized
INFO - 2024-06-20 08:06:53 --> Language Class Initialized
INFO - 2024-06-20 08:06:53 --> Language Class Initialized
INFO - 2024-06-20 08:06:53 --> Config Class Initialized
INFO - 2024-06-20 08:06:53 --> Loader Class Initialized
INFO - 2024-06-20 08:06:53 --> Helper loaded: url_helper
INFO - 2024-06-20 08:06:53 --> Helper loaded: file_helper
INFO - 2024-06-20 08:06:53 --> Helper loaded: form_helper
INFO - 2024-06-20 08:06:53 --> Helper loaded: my_helper
INFO - 2024-06-20 08:06:53 --> Database Driver Class Initialized
INFO - 2024-06-20 08:06:53 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-20 08:06:53 --> Controller Class Initialized
INFO - 2024-06-20 08:06:53 --> Config Class Initialized
INFO - 2024-06-20 08:06:53 --> Hooks Class Initialized
DEBUG - 2024-06-20 08:06:53 --> UTF-8 Support Enabled
INFO - 2024-06-20 08:06:53 --> Utf8 Class Initialized
INFO - 2024-06-20 08:06:53 --> URI Class Initialized
INFO - 2024-06-20 08:06:53 --> Router Class Initialized
INFO - 2024-06-20 08:06:53 --> Output Class Initialized
INFO - 2024-06-20 08:06:53 --> Security Class Initialized
DEBUG - 2024-06-20 08:06:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-20 08:06:53 --> Input Class Initialized
INFO - 2024-06-20 08:06:53 --> Language Class Initialized
INFO - 2024-06-20 08:06:53 --> Language Class Initialized
INFO - 2024-06-20 08:06:53 --> Config Class Initialized
INFO - 2024-06-20 08:06:53 --> Loader Class Initialized
INFO - 2024-06-20 08:06:53 --> Helper loaded: url_helper
INFO - 2024-06-20 08:06:53 --> Helper loaded: file_helper
INFO - 2024-06-20 08:06:53 --> Helper loaded: form_helper
INFO - 2024-06-20 08:06:53 --> Helper loaded: my_helper
INFO - 2024-06-20 08:06:53 --> Database Driver Class Initialized
INFO - 2024-06-20 08:06:53 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-20 08:06:53 --> Controller Class Initialized
DEBUG - 2024-06-20 08:06:53 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/login/views/login.php
DEBUG - 2024-06-20 08:06:53 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-06-20 08:06:53 --> Final output sent to browser
DEBUG - 2024-06-20 08:06:53 --> Total execution time: 0.0237
INFO - 2024-06-20 08:07:02 --> Config Class Initialized
INFO - 2024-06-20 08:07:02 --> Hooks Class Initialized
DEBUG - 2024-06-20 08:07:02 --> UTF-8 Support Enabled
INFO - 2024-06-20 08:07:02 --> Utf8 Class Initialized
INFO - 2024-06-20 08:07:02 --> URI Class Initialized
INFO - 2024-06-20 08:07:02 --> Router Class Initialized
INFO - 2024-06-20 08:07:02 --> Output Class Initialized
INFO - 2024-06-20 08:07:02 --> Security Class Initialized
DEBUG - 2024-06-20 08:07:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-20 08:07:02 --> Input Class Initialized
INFO - 2024-06-20 08:07:02 --> Language Class Initialized
INFO - 2024-06-20 08:07:02 --> Language Class Initialized
INFO - 2024-06-20 08:07:02 --> Config Class Initialized
INFO - 2024-06-20 08:07:02 --> Loader Class Initialized
INFO - 2024-06-20 08:07:02 --> Helper loaded: url_helper
INFO - 2024-06-20 08:07:02 --> Helper loaded: file_helper
INFO - 2024-06-20 08:07:02 --> Helper loaded: form_helper
INFO - 2024-06-20 08:07:02 --> Helper loaded: my_helper
INFO - 2024-06-20 08:07:02 --> Database Driver Class Initialized
INFO - 2024-06-20 08:07:02 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-20 08:07:02 --> Controller Class Initialized
INFO - 2024-06-20 08:07:02 --> Helper loaded: cookie_helper
INFO - 2024-06-20 08:07:02 --> Final output sent to browser
DEBUG - 2024-06-20 08:07:02 --> Total execution time: 0.0640
INFO - 2024-06-20 08:07:02 --> Config Class Initialized
INFO - 2024-06-20 08:07:02 --> Hooks Class Initialized
DEBUG - 2024-06-20 08:07:02 --> UTF-8 Support Enabled
INFO - 2024-06-20 08:07:02 --> Utf8 Class Initialized
INFO - 2024-06-20 08:07:02 --> URI Class Initialized
INFO - 2024-06-20 08:07:02 --> Router Class Initialized
INFO - 2024-06-20 08:07:02 --> Output Class Initialized
INFO - 2024-06-20 08:07:02 --> Security Class Initialized
DEBUG - 2024-06-20 08:07:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-20 08:07:02 --> Input Class Initialized
INFO - 2024-06-20 08:07:02 --> Language Class Initialized
INFO - 2024-06-20 08:07:02 --> Language Class Initialized
INFO - 2024-06-20 08:07:02 --> Config Class Initialized
INFO - 2024-06-20 08:07:02 --> Loader Class Initialized
INFO - 2024-06-20 08:07:02 --> Helper loaded: url_helper
INFO - 2024-06-20 08:07:02 --> Helper loaded: file_helper
INFO - 2024-06-20 08:07:02 --> Helper loaded: form_helper
INFO - 2024-06-20 08:07:02 --> Helper loaded: my_helper
INFO - 2024-06-20 08:07:02 --> Database Driver Class Initialized
INFO - 2024-06-20 08:07:02 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-20 08:07:02 --> Controller Class Initialized
DEBUG - 2024-06-20 08:07:02 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/home/views/v_home_guru.php
DEBUG - 2024-06-20 08:07:02 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-06-20 08:07:02 --> Final output sent to browser
DEBUG - 2024-06-20 08:07:02 --> Total execution time: 0.0508
INFO - 2024-06-20 08:07:04 --> Config Class Initialized
INFO - 2024-06-20 08:07:04 --> Hooks Class Initialized
DEBUG - 2024-06-20 08:07:04 --> UTF-8 Support Enabled
INFO - 2024-06-20 08:07:04 --> Utf8 Class Initialized
INFO - 2024-06-20 08:07:04 --> URI Class Initialized
INFO - 2024-06-20 08:07:04 --> Router Class Initialized
INFO - 2024-06-20 08:07:04 --> Output Class Initialized
INFO - 2024-06-20 08:07:04 --> Security Class Initialized
DEBUG - 2024-06-20 08:07:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-20 08:07:04 --> Input Class Initialized
INFO - 2024-06-20 08:07:04 --> Language Class Initialized
INFO - 2024-06-20 08:07:04 --> Language Class Initialized
INFO - 2024-06-20 08:07:04 --> Config Class Initialized
INFO - 2024-06-20 08:07:04 --> Loader Class Initialized
INFO - 2024-06-20 08:07:04 --> Helper loaded: url_helper
INFO - 2024-06-20 08:07:04 --> Helper loaded: file_helper
INFO - 2024-06-20 08:07:04 --> Helper loaded: form_helper
INFO - 2024-06-20 08:07:04 --> Helper loaded: my_helper
INFO - 2024-06-20 08:07:04 --> Database Driver Class Initialized
INFO - 2024-06-20 08:07:04 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-20 08:07:04 --> Controller Class Initialized
DEBUG - 2024-06-20 08:07:04 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/view_mapel/views/v_view_mapel.php
DEBUG - 2024-06-20 08:07:04 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-06-20 08:07:04 --> Final output sent to browser
DEBUG - 2024-06-20 08:07:04 --> Total execution time: 0.0499
INFO - 2024-06-20 08:07:06 --> Config Class Initialized
INFO - 2024-06-20 08:07:06 --> Hooks Class Initialized
DEBUG - 2024-06-20 08:07:06 --> UTF-8 Support Enabled
INFO - 2024-06-20 08:07:06 --> Utf8 Class Initialized
INFO - 2024-06-20 08:07:06 --> URI Class Initialized
INFO - 2024-06-20 08:07:06 --> Router Class Initialized
INFO - 2024-06-20 08:07:06 --> Output Class Initialized
INFO - 2024-06-20 08:07:06 --> Security Class Initialized
DEBUG - 2024-06-20 08:07:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-20 08:07:06 --> Input Class Initialized
INFO - 2024-06-20 08:07:06 --> Language Class Initialized
INFO - 2024-06-20 08:07:06 --> Language Class Initialized
INFO - 2024-06-20 08:07:06 --> Config Class Initialized
INFO - 2024-06-20 08:07:06 --> Loader Class Initialized
INFO - 2024-06-20 08:07:06 --> Helper loaded: url_helper
INFO - 2024-06-20 08:07:06 --> Helper loaded: file_helper
INFO - 2024-06-20 08:07:06 --> Helper loaded: form_helper
INFO - 2024-06-20 08:07:06 --> Helper loaded: my_helper
INFO - 2024-06-20 08:07:06 --> Database Driver Class Initialized
INFO - 2024-06-20 08:07:06 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-20 08:07:06 --> Controller Class Initialized
DEBUG - 2024-06-20 08:07:06 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/views/list.php
DEBUG - 2024-06-20 08:07:06 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-06-20 08:07:06 --> Final output sent to browser
DEBUG - 2024-06-20 08:07:06 --> Total execution time: 0.0452
INFO - 2024-06-20 08:07:06 --> Config Class Initialized
INFO - 2024-06-20 08:07:06 --> Hooks Class Initialized
DEBUG - 2024-06-20 08:07:06 --> UTF-8 Support Enabled
INFO - 2024-06-20 08:07:06 --> Utf8 Class Initialized
INFO - 2024-06-20 08:07:06 --> URI Class Initialized
INFO - 2024-06-20 08:07:06 --> Router Class Initialized
INFO - 2024-06-20 08:07:06 --> Output Class Initialized
INFO - 2024-06-20 08:07:06 --> Security Class Initialized
DEBUG - 2024-06-20 08:07:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-20 08:07:06 --> Input Class Initialized
INFO - 2024-06-20 08:07:06 --> Language Class Initialized
INFO - 2024-06-20 08:07:06 --> Language Class Initialized
INFO - 2024-06-20 08:07:06 --> Config Class Initialized
INFO - 2024-06-20 08:07:06 --> Loader Class Initialized
INFO - 2024-06-20 08:07:06 --> Helper loaded: url_helper
INFO - 2024-06-20 08:07:06 --> Helper loaded: file_helper
INFO - 2024-06-20 08:07:06 --> Helper loaded: form_helper
INFO - 2024-06-20 08:07:06 --> Helper loaded: my_helper
INFO - 2024-06-20 08:07:06 --> Database Driver Class Initialized
INFO - 2024-06-20 08:07:06 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-20 08:07:06 --> Controller Class Initialized
INFO - 2024-06-20 08:07:09 --> Config Class Initialized
INFO - 2024-06-20 08:07:09 --> Hooks Class Initialized
DEBUG - 2024-06-20 08:07:09 --> UTF-8 Support Enabled
INFO - 2024-06-20 08:07:09 --> Utf8 Class Initialized
INFO - 2024-06-20 08:07:09 --> URI Class Initialized
INFO - 2024-06-20 08:07:09 --> Router Class Initialized
INFO - 2024-06-20 08:07:09 --> Output Class Initialized
INFO - 2024-06-20 08:07:09 --> Security Class Initialized
DEBUG - 2024-06-20 08:07:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-20 08:07:09 --> Input Class Initialized
INFO - 2024-06-20 08:07:09 --> Language Class Initialized
INFO - 2024-06-20 08:07:09 --> Language Class Initialized
INFO - 2024-06-20 08:07:09 --> Config Class Initialized
INFO - 2024-06-20 08:07:09 --> Loader Class Initialized
INFO - 2024-06-20 08:07:09 --> Helper loaded: url_helper
INFO - 2024-06-20 08:07:09 --> Helper loaded: file_helper
INFO - 2024-06-20 08:07:09 --> Helper loaded: form_helper
INFO - 2024-06-20 08:07:09 --> Helper loaded: my_helper
INFO - 2024-06-20 08:07:09 --> Database Driver Class Initialized
INFO - 2024-06-20 08:07:09 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-20 08:07:09 --> Controller Class Initialized
INFO - 2024-06-20 08:07:36 --> Config Class Initialized
INFO - 2024-06-20 08:07:36 --> Hooks Class Initialized
DEBUG - 2024-06-20 08:07:36 --> UTF-8 Support Enabled
INFO - 2024-06-20 08:07:36 --> Utf8 Class Initialized
INFO - 2024-06-20 08:07:36 --> URI Class Initialized
INFO - 2024-06-20 08:07:36 --> Router Class Initialized
INFO - 2024-06-20 08:07:36 --> Output Class Initialized
INFO - 2024-06-20 08:07:36 --> Security Class Initialized
DEBUG - 2024-06-20 08:07:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-20 08:07:36 --> Input Class Initialized
INFO - 2024-06-20 08:07:36 --> Language Class Initialized
INFO - 2024-06-20 08:07:36 --> Language Class Initialized
INFO - 2024-06-20 08:07:36 --> Config Class Initialized
INFO - 2024-06-20 08:07:36 --> Loader Class Initialized
INFO - 2024-06-20 08:07:36 --> Helper loaded: url_helper
INFO - 2024-06-20 08:07:36 --> Helper loaded: file_helper
INFO - 2024-06-20 08:07:36 --> Helper loaded: form_helper
INFO - 2024-06-20 08:07:36 --> Helper loaded: my_helper
INFO - 2024-06-20 08:07:36 --> Database Driver Class Initialized
INFO - 2024-06-20 08:07:36 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-20 08:07:36 --> Controller Class Initialized
INFO - 2024-06-20 08:07:36 --> Helper loaded: cookie_helper
INFO - 2024-06-20 08:07:36 --> Config Class Initialized
INFO - 2024-06-20 08:07:36 --> Hooks Class Initialized
DEBUG - 2024-06-20 08:07:36 --> UTF-8 Support Enabled
INFO - 2024-06-20 08:07:36 --> Utf8 Class Initialized
INFO - 2024-06-20 08:07:36 --> URI Class Initialized
INFO - 2024-06-20 08:07:36 --> Router Class Initialized
INFO - 2024-06-20 08:07:36 --> Output Class Initialized
INFO - 2024-06-20 08:07:36 --> Security Class Initialized
DEBUG - 2024-06-20 08:07:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-20 08:07:36 --> Input Class Initialized
INFO - 2024-06-20 08:07:36 --> Language Class Initialized
INFO - 2024-06-20 08:07:36 --> Language Class Initialized
INFO - 2024-06-20 08:07:36 --> Config Class Initialized
INFO - 2024-06-20 08:07:36 --> Loader Class Initialized
INFO - 2024-06-20 08:07:36 --> Helper loaded: url_helper
INFO - 2024-06-20 08:07:36 --> Helper loaded: file_helper
INFO - 2024-06-20 08:07:36 --> Helper loaded: form_helper
INFO - 2024-06-20 08:07:36 --> Helper loaded: my_helper
INFO - 2024-06-20 08:07:36 --> Database Driver Class Initialized
INFO - 2024-06-20 08:07:36 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-20 08:07:36 --> Controller Class Initialized
INFO - 2024-06-20 08:07:36 --> Config Class Initialized
INFO - 2024-06-20 08:07:36 --> Hooks Class Initialized
DEBUG - 2024-06-20 08:07:36 --> UTF-8 Support Enabled
INFO - 2024-06-20 08:07:36 --> Utf8 Class Initialized
INFO - 2024-06-20 08:07:36 --> URI Class Initialized
INFO - 2024-06-20 08:07:36 --> Router Class Initialized
INFO - 2024-06-20 08:07:36 --> Output Class Initialized
INFO - 2024-06-20 08:07:36 --> Security Class Initialized
DEBUG - 2024-06-20 08:07:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-20 08:07:36 --> Input Class Initialized
INFO - 2024-06-20 08:07:36 --> Language Class Initialized
INFO - 2024-06-20 08:07:36 --> Language Class Initialized
INFO - 2024-06-20 08:07:36 --> Config Class Initialized
INFO - 2024-06-20 08:07:36 --> Loader Class Initialized
INFO - 2024-06-20 08:07:36 --> Helper loaded: url_helper
INFO - 2024-06-20 08:07:36 --> Helper loaded: file_helper
INFO - 2024-06-20 08:07:36 --> Helper loaded: form_helper
INFO - 2024-06-20 08:07:36 --> Helper loaded: my_helper
INFO - 2024-06-20 08:07:36 --> Database Driver Class Initialized
INFO - 2024-06-20 08:07:36 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-20 08:07:36 --> Controller Class Initialized
DEBUG - 2024-06-20 08:07:36 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/login/views/login.php
DEBUG - 2024-06-20 08:07:36 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-06-20 08:07:36 --> Final output sent to browser
DEBUG - 2024-06-20 08:07:36 --> Total execution time: 0.0362
INFO - 2024-06-20 08:07:51 --> Config Class Initialized
INFO - 2024-06-20 08:07:51 --> Hooks Class Initialized
DEBUG - 2024-06-20 08:07:51 --> UTF-8 Support Enabled
INFO - 2024-06-20 08:07:51 --> Utf8 Class Initialized
INFO - 2024-06-20 08:07:51 --> URI Class Initialized
INFO - 2024-06-20 08:07:51 --> Router Class Initialized
INFO - 2024-06-20 08:07:51 --> Output Class Initialized
INFO - 2024-06-20 08:07:51 --> Security Class Initialized
DEBUG - 2024-06-20 08:07:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-20 08:07:51 --> Input Class Initialized
INFO - 2024-06-20 08:07:51 --> Language Class Initialized
INFO - 2024-06-20 08:07:51 --> Language Class Initialized
INFO - 2024-06-20 08:07:51 --> Config Class Initialized
INFO - 2024-06-20 08:07:51 --> Loader Class Initialized
INFO - 2024-06-20 08:07:51 --> Helper loaded: url_helper
INFO - 2024-06-20 08:07:51 --> Helper loaded: file_helper
INFO - 2024-06-20 08:07:51 --> Helper loaded: form_helper
INFO - 2024-06-20 08:07:51 --> Helper loaded: my_helper
INFO - 2024-06-20 08:07:51 --> Database Driver Class Initialized
INFO - 2024-06-20 08:07:51 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-20 08:07:51 --> Controller Class Initialized
INFO - 2024-06-20 08:07:51 --> Helper loaded: cookie_helper
INFO - 2024-06-20 08:07:51 --> Final output sent to browser
DEBUG - 2024-06-20 08:07:51 --> Total execution time: 0.0286
INFO - 2024-06-20 08:07:51 --> Config Class Initialized
INFO - 2024-06-20 08:07:51 --> Hooks Class Initialized
DEBUG - 2024-06-20 08:07:51 --> UTF-8 Support Enabled
INFO - 2024-06-20 08:07:51 --> Utf8 Class Initialized
INFO - 2024-06-20 08:07:51 --> URI Class Initialized
INFO - 2024-06-20 08:07:51 --> Router Class Initialized
INFO - 2024-06-20 08:07:51 --> Output Class Initialized
INFO - 2024-06-20 08:07:51 --> Security Class Initialized
DEBUG - 2024-06-20 08:07:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-20 08:07:51 --> Input Class Initialized
INFO - 2024-06-20 08:07:51 --> Language Class Initialized
INFO - 2024-06-20 08:07:51 --> Language Class Initialized
INFO - 2024-06-20 08:07:51 --> Config Class Initialized
INFO - 2024-06-20 08:07:51 --> Loader Class Initialized
INFO - 2024-06-20 08:07:51 --> Helper loaded: url_helper
INFO - 2024-06-20 08:07:51 --> Helper loaded: file_helper
INFO - 2024-06-20 08:07:51 --> Helper loaded: form_helper
INFO - 2024-06-20 08:07:51 --> Helper loaded: my_helper
INFO - 2024-06-20 08:07:51 --> Database Driver Class Initialized
INFO - 2024-06-20 08:07:51 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-20 08:07:51 --> Controller Class Initialized
DEBUG - 2024-06-20 08:07:51 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/home/views/v_home_guru.php
DEBUG - 2024-06-20 08:07:51 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-06-20 08:07:51 --> Final output sent to browser
DEBUG - 2024-06-20 08:07:51 --> Total execution time: 0.0259
INFO - 2024-06-20 08:07:53 --> Config Class Initialized
INFO - 2024-06-20 08:07:53 --> Hooks Class Initialized
DEBUG - 2024-06-20 08:07:53 --> UTF-8 Support Enabled
INFO - 2024-06-20 08:07:53 --> Utf8 Class Initialized
INFO - 2024-06-20 08:07:53 --> URI Class Initialized
INFO - 2024-06-20 08:07:53 --> Router Class Initialized
INFO - 2024-06-20 08:07:53 --> Output Class Initialized
INFO - 2024-06-20 08:07:53 --> Security Class Initialized
DEBUG - 2024-06-20 08:07:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-20 08:07:53 --> Input Class Initialized
INFO - 2024-06-20 08:07:53 --> Language Class Initialized
INFO - 2024-06-20 08:07:53 --> Language Class Initialized
INFO - 2024-06-20 08:07:53 --> Config Class Initialized
INFO - 2024-06-20 08:07:53 --> Loader Class Initialized
INFO - 2024-06-20 08:07:53 --> Helper loaded: url_helper
INFO - 2024-06-20 08:07:53 --> Helper loaded: file_helper
INFO - 2024-06-20 08:07:53 --> Helper loaded: form_helper
INFO - 2024-06-20 08:07:53 --> Helper loaded: my_helper
INFO - 2024-06-20 08:07:53 --> Database Driver Class Initialized
INFO - 2024-06-20 08:07:53 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-20 08:07:53 --> Controller Class Initialized
DEBUG - 2024-06-20 08:07:53 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/view_mapel/views/v_view_mapel.php
DEBUG - 2024-06-20 08:07:53 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-06-20 08:07:53 --> Final output sent to browser
DEBUG - 2024-06-20 08:07:53 --> Total execution time: 0.0455
INFO - 2024-06-20 08:07:55 --> Config Class Initialized
INFO - 2024-06-20 08:07:55 --> Hooks Class Initialized
DEBUG - 2024-06-20 08:07:55 --> UTF-8 Support Enabled
INFO - 2024-06-20 08:07:55 --> Utf8 Class Initialized
INFO - 2024-06-20 08:07:55 --> URI Class Initialized
INFO - 2024-06-20 08:07:55 --> Router Class Initialized
INFO - 2024-06-20 08:07:55 --> Output Class Initialized
INFO - 2024-06-20 08:07:55 --> Security Class Initialized
DEBUG - 2024-06-20 08:07:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-20 08:07:55 --> Input Class Initialized
INFO - 2024-06-20 08:07:55 --> Language Class Initialized
INFO - 2024-06-20 08:07:55 --> Language Class Initialized
INFO - 2024-06-20 08:07:55 --> Config Class Initialized
INFO - 2024-06-20 08:07:55 --> Loader Class Initialized
INFO - 2024-06-20 08:07:55 --> Helper loaded: url_helper
INFO - 2024-06-20 08:07:55 --> Helper loaded: file_helper
INFO - 2024-06-20 08:07:55 --> Helper loaded: form_helper
INFO - 2024-06-20 08:07:55 --> Helper loaded: my_helper
INFO - 2024-06-20 08:07:55 --> Database Driver Class Initialized
INFO - 2024-06-20 08:07:55 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-20 08:07:55 --> Controller Class Initialized
DEBUG - 2024-06-20 08:07:55 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/views/list.php
DEBUG - 2024-06-20 08:07:55 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-06-20 08:07:55 --> Final output sent to browser
DEBUG - 2024-06-20 08:07:55 --> Total execution time: 0.0835
INFO - 2024-06-20 08:07:55 --> Config Class Initialized
INFO - 2024-06-20 08:07:55 --> Hooks Class Initialized
DEBUG - 2024-06-20 08:07:55 --> UTF-8 Support Enabled
INFO - 2024-06-20 08:07:55 --> Utf8 Class Initialized
INFO - 2024-06-20 08:07:55 --> URI Class Initialized
INFO - 2024-06-20 08:07:55 --> Router Class Initialized
INFO - 2024-06-20 08:07:55 --> Output Class Initialized
INFO - 2024-06-20 08:07:55 --> Security Class Initialized
DEBUG - 2024-06-20 08:07:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-20 08:07:55 --> Input Class Initialized
INFO - 2024-06-20 08:07:55 --> Language Class Initialized
INFO - 2024-06-20 08:07:55 --> Language Class Initialized
INFO - 2024-06-20 08:07:55 --> Config Class Initialized
INFO - 2024-06-20 08:07:55 --> Loader Class Initialized
INFO - 2024-06-20 08:07:55 --> Helper loaded: url_helper
INFO - 2024-06-20 08:07:55 --> Helper loaded: file_helper
INFO - 2024-06-20 08:07:55 --> Helper loaded: form_helper
INFO - 2024-06-20 08:07:55 --> Helper loaded: my_helper
INFO - 2024-06-20 08:07:55 --> Database Driver Class Initialized
INFO - 2024-06-20 08:07:55 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-20 08:07:55 --> Controller Class Initialized
INFO - 2024-06-20 08:07:57 --> Config Class Initialized
INFO - 2024-06-20 08:07:57 --> Hooks Class Initialized
DEBUG - 2024-06-20 08:07:57 --> UTF-8 Support Enabled
INFO - 2024-06-20 08:07:57 --> Utf8 Class Initialized
INFO - 2024-06-20 08:07:57 --> URI Class Initialized
INFO - 2024-06-20 08:07:57 --> Router Class Initialized
INFO - 2024-06-20 08:07:57 --> Output Class Initialized
INFO - 2024-06-20 08:07:57 --> Security Class Initialized
DEBUG - 2024-06-20 08:07:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-20 08:07:57 --> Input Class Initialized
INFO - 2024-06-20 08:07:57 --> Language Class Initialized
INFO - 2024-06-20 08:07:57 --> Language Class Initialized
INFO - 2024-06-20 08:07:57 --> Config Class Initialized
INFO - 2024-06-20 08:07:57 --> Loader Class Initialized
INFO - 2024-06-20 08:07:57 --> Helper loaded: url_helper
INFO - 2024-06-20 08:07:57 --> Helper loaded: file_helper
INFO - 2024-06-20 08:07:57 --> Helper loaded: form_helper
INFO - 2024-06-20 08:07:57 --> Helper loaded: my_helper
INFO - 2024-06-20 08:07:57 --> Database Driver Class Initialized
INFO - 2024-06-20 08:07:57 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-20 08:07:57 --> Controller Class Initialized
INFO - 2024-06-20 08:08:07 --> Config Class Initialized
INFO - 2024-06-20 08:08:07 --> Hooks Class Initialized
DEBUG - 2024-06-20 08:08:07 --> UTF-8 Support Enabled
INFO - 2024-06-20 08:08:07 --> Utf8 Class Initialized
INFO - 2024-06-20 08:08:07 --> URI Class Initialized
INFO - 2024-06-20 08:08:07 --> Router Class Initialized
INFO - 2024-06-20 08:08:07 --> Output Class Initialized
INFO - 2024-06-20 08:08:07 --> Security Class Initialized
DEBUG - 2024-06-20 08:08:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-20 08:08:07 --> Input Class Initialized
INFO - 2024-06-20 08:08:07 --> Language Class Initialized
INFO - 2024-06-20 08:08:07 --> Language Class Initialized
INFO - 2024-06-20 08:08:07 --> Config Class Initialized
INFO - 2024-06-20 08:08:07 --> Loader Class Initialized
INFO - 2024-06-20 08:08:07 --> Helper loaded: url_helper
INFO - 2024-06-20 08:08:07 --> Helper loaded: file_helper
INFO - 2024-06-20 08:08:07 --> Helper loaded: form_helper
INFO - 2024-06-20 08:08:07 --> Helper loaded: my_helper
INFO - 2024-06-20 08:08:07 --> Database Driver Class Initialized
INFO - 2024-06-20 08:08:07 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-20 08:08:07 --> Controller Class Initialized
INFO - 2024-06-20 08:08:07 --> Config Class Initialized
INFO - 2024-06-20 08:08:07 --> Hooks Class Initialized
DEBUG - 2024-06-20 08:08:07 --> UTF-8 Support Enabled
INFO - 2024-06-20 08:08:07 --> Utf8 Class Initialized
INFO - 2024-06-20 08:08:07 --> URI Class Initialized
INFO - 2024-06-20 08:08:07 --> Router Class Initialized
INFO - 2024-06-20 08:08:07 --> Output Class Initialized
INFO - 2024-06-20 08:08:07 --> Security Class Initialized
DEBUG - 2024-06-20 08:08:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-20 08:08:07 --> Input Class Initialized
INFO - 2024-06-20 08:08:07 --> Language Class Initialized
INFO - 2024-06-20 08:08:07 --> Language Class Initialized
INFO - 2024-06-20 08:08:07 --> Config Class Initialized
INFO - 2024-06-20 08:08:07 --> Loader Class Initialized
INFO - 2024-06-20 08:08:07 --> Helper loaded: url_helper
INFO - 2024-06-20 08:08:07 --> Helper loaded: file_helper
INFO - 2024-06-20 08:08:07 --> Helper loaded: form_helper
INFO - 2024-06-20 08:08:07 --> Helper loaded: my_helper
INFO - 2024-06-20 08:08:07 --> Database Driver Class Initialized
INFO - 2024-06-20 08:08:07 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-20 08:08:07 --> Controller Class Initialized
DEBUG - 2024-06-20 08:08:07 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/login/views/login.php
DEBUG - 2024-06-20 08:08:07 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-06-20 08:08:07 --> Final output sent to browser
DEBUG - 2024-06-20 08:08:07 --> Total execution time: 0.0290
INFO - 2024-06-20 08:08:13 --> Config Class Initialized
INFO - 2024-06-20 08:08:13 --> Hooks Class Initialized
DEBUG - 2024-06-20 08:08:13 --> UTF-8 Support Enabled
INFO - 2024-06-20 08:08:13 --> Utf8 Class Initialized
INFO - 2024-06-20 08:08:13 --> URI Class Initialized
INFO - 2024-06-20 08:08:13 --> Router Class Initialized
INFO - 2024-06-20 08:08:13 --> Output Class Initialized
INFO - 2024-06-20 08:08:13 --> Security Class Initialized
DEBUG - 2024-06-20 08:08:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-20 08:08:13 --> Input Class Initialized
INFO - 2024-06-20 08:08:13 --> Language Class Initialized
INFO - 2024-06-20 08:08:13 --> Language Class Initialized
INFO - 2024-06-20 08:08:13 --> Config Class Initialized
INFO - 2024-06-20 08:08:13 --> Loader Class Initialized
INFO - 2024-06-20 08:08:13 --> Helper loaded: url_helper
INFO - 2024-06-20 08:08:13 --> Helper loaded: file_helper
INFO - 2024-06-20 08:08:13 --> Helper loaded: form_helper
INFO - 2024-06-20 08:08:13 --> Helper loaded: my_helper
INFO - 2024-06-20 08:08:13 --> Database Driver Class Initialized
INFO - 2024-06-20 08:08:13 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-20 08:08:13 --> Controller Class Initialized
INFO - 2024-06-20 08:08:13 --> Helper loaded: cookie_helper
INFO - 2024-06-20 08:08:13 --> Final output sent to browser
DEBUG - 2024-06-20 08:08:13 --> Total execution time: 0.0324
INFO - 2024-06-20 08:08:13 --> Config Class Initialized
INFO - 2024-06-20 08:08:13 --> Hooks Class Initialized
DEBUG - 2024-06-20 08:08:13 --> UTF-8 Support Enabled
INFO - 2024-06-20 08:08:13 --> Utf8 Class Initialized
INFO - 2024-06-20 08:08:13 --> URI Class Initialized
INFO - 2024-06-20 08:08:13 --> Router Class Initialized
INFO - 2024-06-20 08:08:13 --> Output Class Initialized
INFO - 2024-06-20 08:08:13 --> Security Class Initialized
DEBUG - 2024-06-20 08:08:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-20 08:08:13 --> Input Class Initialized
INFO - 2024-06-20 08:08:13 --> Language Class Initialized
INFO - 2024-06-20 08:08:13 --> Language Class Initialized
INFO - 2024-06-20 08:08:13 --> Config Class Initialized
INFO - 2024-06-20 08:08:13 --> Loader Class Initialized
INFO - 2024-06-20 08:08:13 --> Helper loaded: url_helper
INFO - 2024-06-20 08:08:13 --> Helper loaded: file_helper
INFO - 2024-06-20 08:08:13 --> Helper loaded: form_helper
INFO - 2024-06-20 08:08:13 --> Helper loaded: my_helper
INFO - 2024-06-20 08:08:13 --> Database Driver Class Initialized
INFO - 2024-06-20 08:08:13 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-20 08:08:13 --> Controller Class Initialized
DEBUG - 2024-06-20 08:08:13 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/home/views/v_home_guru.php
DEBUG - 2024-06-20 08:08:13 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-06-20 08:08:13 --> Final output sent to browser
DEBUG - 2024-06-20 08:08:13 --> Total execution time: 0.0709
INFO - 2024-06-20 08:08:17 --> Config Class Initialized
INFO - 2024-06-20 08:08:17 --> Hooks Class Initialized
DEBUG - 2024-06-20 08:08:17 --> UTF-8 Support Enabled
INFO - 2024-06-20 08:08:17 --> Utf8 Class Initialized
INFO - 2024-06-20 08:08:17 --> URI Class Initialized
INFO - 2024-06-20 08:08:17 --> Router Class Initialized
INFO - 2024-06-20 08:08:17 --> Output Class Initialized
INFO - 2024-06-20 08:08:17 --> Security Class Initialized
DEBUG - 2024-06-20 08:08:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-20 08:08:17 --> Input Class Initialized
INFO - 2024-06-20 08:08:17 --> Language Class Initialized
INFO - 2024-06-20 08:08:17 --> Language Class Initialized
INFO - 2024-06-20 08:08:17 --> Config Class Initialized
INFO - 2024-06-20 08:08:17 --> Loader Class Initialized
INFO - 2024-06-20 08:08:17 --> Helper loaded: url_helper
INFO - 2024-06-20 08:08:17 --> Helper loaded: file_helper
INFO - 2024-06-20 08:08:17 --> Helper loaded: form_helper
INFO - 2024-06-20 08:08:17 --> Helper loaded: my_helper
INFO - 2024-06-20 08:08:17 --> Database Driver Class Initialized
INFO - 2024-06-20 08:08:17 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-20 08:08:17 --> Controller Class Initialized
INFO - 2024-06-20 08:08:17 --> Helper loaded: cookie_helper
INFO - 2024-06-20 08:08:17 --> Config Class Initialized
INFO - 2024-06-20 08:08:17 --> Hooks Class Initialized
DEBUG - 2024-06-20 08:08:17 --> UTF-8 Support Enabled
INFO - 2024-06-20 08:08:17 --> Utf8 Class Initialized
INFO - 2024-06-20 08:08:17 --> URI Class Initialized
INFO - 2024-06-20 08:08:17 --> Router Class Initialized
INFO - 2024-06-20 08:08:17 --> Output Class Initialized
INFO - 2024-06-20 08:08:17 --> Security Class Initialized
DEBUG - 2024-06-20 08:08:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-20 08:08:17 --> Input Class Initialized
INFO - 2024-06-20 08:08:17 --> Language Class Initialized
INFO - 2024-06-20 08:08:17 --> Language Class Initialized
INFO - 2024-06-20 08:08:17 --> Config Class Initialized
INFO - 2024-06-20 08:08:17 --> Loader Class Initialized
INFO - 2024-06-20 08:08:17 --> Helper loaded: url_helper
INFO - 2024-06-20 08:08:17 --> Helper loaded: file_helper
INFO - 2024-06-20 08:08:17 --> Helper loaded: form_helper
INFO - 2024-06-20 08:08:17 --> Helper loaded: my_helper
INFO - 2024-06-20 08:08:17 --> Database Driver Class Initialized
INFO - 2024-06-20 08:08:17 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-20 08:08:17 --> Controller Class Initialized
INFO - 2024-06-20 08:08:17 --> Config Class Initialized
INFO - 2024-06-20 08:08:17 --> Hooks Class Initialized
DEBUG - 2024-06-20 08:08:17 --> UTF-8 Support Enabled
INFO - 2024-06-20 08:08:17 --> Utf8 Class Initialized
INFO - 2024-06-20 08:08:17 --> URI Class Initialized
INFO - 2024-06-20 08:08:17 --> Router Class Initialized
INFO - 2024-06-20 08:08:17 --> Output Class Initialized
INFO - 2024-06-20 08:08:17 --> Security Class Initialized
DEBUG - 2024-06-20 08:08:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-20 08:08:17 --> Input Class Initialized
INFO - 2024-06-20 08:08:17 --> Language Class Initialized
INFO - 2024-06-20 08:08:17 --> Language Class Initialized
INFO - 2024-06-20 08:08:17 --> Config Class Initialized
INFO - 2024-06-20 08:08:17 --> Loader Class Initialized
INFO - 2024-06-20 08:08:17 --> Helper loaded: url_helper
INFO - 2024-06-20 08:08:17 --> Helper loaded: file_helper
INFO - 2024-06-20 08:08:17 --> Helper loaded: form_helper
INFO - 2024-06-20 08:08:17 --> Helper loaded: my_helper
INFO - 2024-06-20 08:08:17 --> Database Driver Class Initialized
INFO - 2024-06-20 08:08:17 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-20 08:08:17 --> Controller Class Initialized
DEBUG - 2024-06-20 08:08:17 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/login/views/login.php
DEBUG - 2024-06-20 08:08:17 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-06-20 08:08:17 --> Final output sent to browser
DEBUG - 2024-06-20 08:08:17 --> Total execution time: 0.0308
INFO - 2024-06-20 08:08:25 --> Config Class Initialized
INFO - 2024-06-20 08:08:25 --> Hooks Class Initialized
DEBUG - 2024-06-20 08:08:25 --> UTF-8 Support Enabled
INFO - 2024-06-20 08:08:25 --> Utf8 Class Initialized
INFO - 2024-06-20 08:08:25 --> URI Class Initialized
INFO - 2024-06-20 08:08:25 --> Router Class Initialized
INFO - 2024-06-20 08:08:25 --> Output Class Initialized
INFO - 2024-06-20 08:08:25 --> Security Class Initialized
DEBUG - 2024-06-20 08:08:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-20 08:08:25 --> Input Class Initialized
INFO - 2024-06-20 08:08:25 --> Language Class Initialized
INFO - 2024-06-20 08:08:25 --> Language Class Initialized
INFO - 2024-06-20 08:08:25 --> Config Class Initialized
INFO - 2024-06-20 08:08:25 --> Loader Class Initialized
INFO - 2024-06-20 08:08:25 --> Helper loaded: url_helper
INFO - 2024-06-20 08:08:25 --> Helper loaded: file_helper
INFO - 2024-06-20 08:08:25 --> Helper loaded: form_helper
INFO - 2024-06-20 08:08:25 --> Helper loaded: my_helper
INFO - 2024-06-20 08:08:25 --> Database Driver Class Initialized
INFO - 2024-06-20 08:08:25 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-20 08:08:25 --> Controller Class Initialized
INFO - 2024-06-20 08:08:25 --> Helper loaded: cookie_helper
INFO - 2024-06-20 08:08:25 --> Final output sent to browser
DEBUG - 2024-06-20 08:08:25 --> Total execution time: 0.0276
INFO - 2024-06-20 08:08:25 --> Config Class Initialized
INFO - 2024-06-20 08:08:25 --> Hooks Class Initialized
DEBUG - 2024-06-20 08:08:25 --> UTF-8 Support Enabled
INFO - 2024-06-20 08:08:25 --> Utf8 Class Initialized
INFO - 2024-06-20 08:08:25 --> URI Class Initialized
INFO - 2024-06-20 08:08:25 --> Router Class Initialized
INFO - 2024-06-20 08:08:25 --> Output Class Initialized
INFO - 2024-06-20 08:08:25 --> Security Class Initialized
DEBUG - 2024-06-20 08:08:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-20 08:08:25 --> Input Class Initialized
INFO - 2024-06-20 08:08:25 --> Language Class Initialized
INFO - 2024-06-20 08:08:25 --> Language Class Initialized
INFO - 2024-06-20 08:08:25 --> Config Class Initialized
INFO - 2024-06-20 08:08:25 --> Loader Class Initialized
INFO - 2024-06-20 08:08:25 --> Helper loaded: url_helper
INFO - 2024-06-20 08:08:25 --> Helper loaded: file_helper
INFO - 2024-06-20 08:08:25 --> Helper loaded: form_helper
INFO - 2024-06-20 08:08:25 --> Helper loaded: my_helper
INFO - 2024-06-20 08:08:25 --> Database Driver Class Initialized
INFO - 2024-06-20 08:08:25 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-20 08:08:25 --> Controller Class Initialized
DEBUG - 2024-06-20 08:08:25 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/home/views/v_home_guru.php
DEBUG - 2024-06-20 08:08:25 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-06-20 08:08:25 --> Final output sent to browser
DEBUG - 2024-06-20 08:08:25 --> Total execution time: 0.0474
INFO - 2024-06-20 08:08:27 --> Config Class Initialized
INFO - 2024-06-20 08:08:27 --> Hooks Class Initialized
DEBUG - 2024-06-20 08:08:27 --> UTF-8 Support Enabled
INFO - 2024-06-20 08:08:27 --> Utf8 Class Initialized
INFO - 2024-06-20 08:08:27 --> URI Class Initialized
INFO - 2024-06-20 08:08:27 --> Router Class Initialized
INFO - 2024-06-20 08:08:27 --> Output Class Initialized
INFO - 2024-06-20 08:08:27 --> Security Class Initialized
DEBUG - 2024-06-20 08:08:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-20 08:08:27 --> Input Class Initialized
INFO - 2024-06-20 08:08:27 --> Language Class Initialized
INFO - 2024-06-20 08:08:27 --> Language Class Initialized
INFO - 2024-06-20 08:08:27 --> Config Class Initialized
INFO - 2024-06-20 08:08:27 --> Loader Class Initialized
INFO - 2024-06-20 08:08:27 --> Helper loaded: url_helper
INFO - 2024-06-20 08:08:27 --> Helper loaded: file_helper
INFO - 2024-06-20 08:08:27 --> Helper loaded: form_helper
INFO - 2024-06-20 08:08:27 --> Helper loaded: my_helper
INFO - 2024-06-20 08:08:27 --> Database Driver Class Initialized
INFO - 2024-06-20 08:08:27 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-20 08:08:27 --> Controller Class Initialized
DEBUG - 2024-06-20 08:08:27 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/view_mapel/views/v_view_mapel.php
DEBUG - 2024-06-20 08:08:27 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-06-20 08:08:27 --> Final output sent to browser
DEBUG - 2024-06-20 08:08:27 --> Total execution time: 0.0256
INFO - 2024-06-20 08:08:29 --> Config Class Initialized
INFO - 2024-06-20 08:08:29 --> Hooks Class Initialized
DEBUG - 2024-06-20 08:08:29 --> UTF-8 Support Enabled
INFO - 2024-06-20 08:08:29 --> Utf8 Class Initialized
INFO - 2024-06-20 08:08:29 --> URI Class Initialized
INFO - 2024-06-20 08:08:29 --> Router Class Initialized
INFO - 2024-06-20 08:08:29 --> Output Class Initialized
INFO - 2024-06-20 08:08:29 --> Security Class Initialized
DEBUG - 2024-06-20 08:08:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-20 08:08:29 --> Input Class Initialized
INFO - 2024-06-20 08:08:29 --> Language Class Initialized
INFO - 2024-06-20 08:08:29 --> Language Class Initialized
INFO - 2024-06-20 08:08:29 --> Config Class Initialized
INFO - 2024-06-20 08:08:29 --> Loader Class Initialized
INFO - 2024-06-20 08:08:29 --> Helper loaded: url_helper
INFO - 2024-06-20 08:08:29 --> Helper loaded: file_helper
INFO - 2024-06-20 08:08:29 --> Helper loaded: form_helper
INFO - 2024-06-20 08:08:29 --> Helper loaded: my_helper
INFO - 2024-06-20 08:08:29 --> Database Driver Class Initialized
INFO - 2024-06-20 08:08:29 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-20 08:08:29 --> Controller Class Initialized
DEBUG - 2024-06-20 08:08:29 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/views/list.php
DEBUG - 2024-06-20 08:08:29 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-06-20 08:08:29 --> Final output sent to browser
DEBUG - 2024-06-20 08:08:29 --> Total execution time: 0.0299
INFO - 2024-06-20 08:08:29 --> Config Class Initialized
INFO - 2024-06-20 08:08:29 --> Hooks Class Initialized
DEBUG - 2024-06-20 08:08:29 --> UTF-8 Support Enabled
INFO - 2024-06-20 08:08:29 --> Utf8 Class Initialized
INFO - 2024-06-20 08:08:29 --> URI Class Initialized
INFO - 2024-06-20 08:08:29 --> Router Class Initialized
INFO - 2024-06-20 08:08:29 --> Output Class Initialized
INFO - 2024-06-20 08:08:29 --> Security Class Initialized
DEBUG - 2024-06-20 08:08:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-20 08:08:29 --> Input Class Initialized
INFO - 2024-06-20 08:08:29 --> Language Class Initialized
INFO - 2024-06-20 08:08:29 --> Language Class Initialized
INFO - 2024-06-20 08:08:29 --> Config Class Initialized
INFO - 2024-06-20 08:08:29 --> Loader Class Initialized
INFO - 2024-06-20 08:08:29 --> Helper loaded: url_helper
INFO - 2024-06-20 08:08:29 --> Helper loaded: file_helper
INFO - 2024-06-20 08:08:29 --> Helper loaded: form_helper
INFO - 2024-06-20 08:08:29 --> Helper loaded: my_helper
INFO - 2024-06-20 08:08:29 --> Database Driver Class Initialized
INFO - 2024-06-20 08:08:29 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-20 08:08:29 --> Controller Class Initialized
INFO - 2024-06-20 08:08:31 --> Config Class Initialized
INFO - 2024-06-20 08:08:31 --> Hooks Class Initialized
DEBUG - 2024-06-20 08:08:31 --> UTF-8 Support Enabled
INFO - 2024-06-20 08:08:31 --> Utf8 Class Initialized
INFO - 2024-06-20 08:08:31 --> URI Class Initialized
INFO - 2024-06-20 08:08:31 --> Router Class Initialized
INFO - 2024-06-20 08:08:31 --> Output Class Initialized
INFO - 2024-06-20 08:08:31 --> Security Class Initialized
DEBUG - 2024-06-20 08:08:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-20 08:08:31 --> Input Class Initialized
INFO - 2024-06-20 08:08:31 --> Language Class Initialized
INFO - 2024-06-20 08:08:31 --> Language Class Initialized
INFO - 2024-06-20 08:08:31 --> Config Class Initialized
INFO - 2024-06-20 08:08:31 --> Loader Class Initialized
INFO - 2024-06-20 08:08:31 --> Helper loaded: url_helper
INFO - 2024-06-20 08:08:31 --> Helper loaded: file_helper
INFO - 2024-06-20 08:08:31 --> Helper loaded: form_helper
INFO - 2024-06-20 08:08:31 --> Helper loaded: my_helper
INFO - 2024-06-20 08:08:31 --> Database Driver Class Initialized
INFO - 2024-06-20 08:08:31 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-20 08:08:31 --> Controller Class Initialized
INFO - 2024-06-20 08:08:48 --> Config Class Initialized
INFO - 2024-06-20 08:08:48 --> Hooks Class Initialized
DEBUG - 2024-06-20 08:08:48 --> UTF-8 Support Enabled
INFO - 2024-06-20 08:08:48 --> Utf8 Class Initialized
INFO - 2024-06-20 08:08:48 --> URI Class Initialized
INFO - 2024-06-20 08:08:48 --> Router Class Initialized
INFO - 2024-06-20 08:08:48 --> Output Class Initialized
INFO - 2024-06-20 08:08:48 --> Security Class Initialized
DEBUG - 2024-06-20 08:08:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-20 08:08:48 --> Input Class Initialized
INFO - 2024-06-20 08:08:48 --> Language Class Initialized
INFO - 2024-06-20 08:08:48 --> Language Class Initialized
INFO - 2024-06-20 08:08:48 --> Config Class Initialized
INFO - 2024-06-20 08:08:48 --> Loader Class Initialized
INFO - 2024-06-20 08:08:48 --> Helper loaded: url_helper
INFO - 2024-06-20 08:08:48 --> Helper loaded: file_helper
INFO - 2024-06-20 08:08:48 --> Helper loaded: form_helper
INFO - 2024-06-20 08:08:48 --> Helper loaded: my_helper
INFO - 2024-06-20 08:08:48 --> Database Driver Class Initialized
INFO - 2024-06-20 08:08:48 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-20 08:08:48 --> Controller Class Initialized
INFO - 2024-06-20 08:08:48 --> Helper loaded: cookie_helper
INFO - 2024-06-20 08:08:48 --> Config Class Initialized
INFO - 2024-06-20 08:08:48 --> Hooks Class Initialized
DEBUG - 2024-06-20 08:08:48 --> UTF-8 Support Enabled
INFO - 2024-06-20 08:08:48 --> Utf8 Class Initialized
INFO - 2024-06-20 08:08:48 --> URI Class Initialized
INFO - 2024-06-20 08:08:48 --> Router Class Initialized
INFO - 2024-06-20 08:08:48 --> Output Class Initialized
INFO - 2024-06-20 08:08:48 --> Security Class Initialized
DEBUG - 2024-06-20 08:08:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-20 08:08:48 --> Input Class Initialized
INFO - 2024-06-20 08:08:48 --> Language Class Initialized
INFO - 2024-06-20 08:08:48 --> Language Class Initialized
INFO - 2024-06-20 08:08:48 --> Config Class Initialized
INFO - 2024-06-20 08:08:48 --> Loader Class Initialized
INFO - 2024-06-20 08:08:48 --> Helper loaded: url_helper
INFO - 2024-06-20 08:08:48 --> Helper loaded: file_helper
INFO - 2024-06-20 08:08:48 --> Helper loaded: form_helper
INFO - 2024-06-20 08:08:48 --> Helper loaded: my_helper
INFO - 2024-06-20 08:08:48 --> Database Driver Class Initialized
INFO - 2024-06-20 08:08:48 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-20 08:08:48 --> Controller Class Initialized
INFO - 2024-06-20 08:08:48 --> Config Class Initialized
INFO - 2024-06-20 08:08:48 --> Hooks Class Initialized
DEBUG - 2024-06-20 08:08:48 --> UTF-8 Support Enabled
INFO - 2024-06-20 08:08:48 --> Utf8 Class Initialized
INFO - 2024-06-20 08:08:48 --> URI Class Initialized
INFO - 2024-06-20 08:08:48 --> Router Class Initialized
INFO - 2024-06-20 08:08:48 --> Output Class Initialized
INFO - 2024-06-20 08:08:48 --> Security Class Initialized
DEBUG - 2024-06-20 08:08:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-20 08:08:48 --> Input Class Initialized
INFO - 2024-06-20 08:08:48 --> Language Class Initialized
INFO - 2024-06-20 08:08:48 --> Language Class Initialized
INFO - 2024-06-20 08:08:48 --> Config Class Initialized
INFO - 2024-06-20 08:08:48 --> Loader Class Initialized
INFO - 2024-06-20 08:08:48 --> Helper loaded: url_helper
INFO - 2024-06-20 08:08:48 --> Helper loaded: file_helper
INFO - 2024-06-20 08:08:48 --> Helper loaded: form_helper
INFO - 2024-06-20 08:08:48 --> Helper loaded: my_helper
INFO - 2024-06-20 08:08:48 --> Database Driver Class Initialized
INFO - 2024-06-20 08:08:48 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-20 08:08:48 --> Controller Class Initialized
DEBUG - 2024-06-20 08:08:48 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/login/views/login.php
DEBUG - 2024-06-20 08:08:48 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-06-20 08:08:48 --> Final output sent to browser
DEBUG - 2024-06-20 08:08:48 --> Total execution time: 0.0271
INFO - 2024-06-20 08:09:35 --> Config Class Initialized
INFO - 2024-06-20 08:09:35 --> Hooks Class Initialized
DEBUG - 2024-06-20 08:09:35 --> UTF-8 Support Enabled
INFO - 2024-06-20 08:09:35 --> Utf8 Class Initialized
INFO - 2024-06-20 08:09:35 --> URI Class Initialized
INFO - 2024-06-20 08:09:35 --> Router Class Initialized
INFO - 2024-06-20 08:09:35 --> Output Class Initialized
INFO - 2024-06-20 08:09:35 --> Security Class Initialized
DEBUG - 2024-06-20 08:09:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-20 08:09:35 --> Input Class Initialized
INFO - 2024-06-20 08:09:35 --> Language Class Initialized
INFO - 2024-06-20 08:09:35 --> Language Class Initialized
INFO - 2024-06-20 08:09:35 --> Config Class Initialized
INFO - 2024-06-20 08:09:35 --> Loader Class Initialized
INFO - 2024-06-20 08:09:35 --> Helper loaded: url_helper
INFO - 2024-06-20 08:09:35 --> Helper loaded: file_helper
INFO - 2024-06-20 08:09:35 --> Helper loaded: form_helper
INFO - 2024-06-20 08:09:35 --> Helper loaded: my_helper
INFO - 2024-06-20 08:09:35 --> Database Driver Class Initialized
INFO - 2024-06-20 08:09:35 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-20 08:09:35 --> Controller Class Initialized
INFO - 2024-06-20 08:09:35 --> Final output sent to browser
DEBUG - 2024-06-20 08:09:35 --> Total execution time: 0.0255
INFO - 2024-06-20 08:09:52 --> Config Class Initialized
INFO - 2024-06-20 08:09:52 --> Hooks Class Initialized
DEBUG - 2024-06-20 08:09:52 --> UTF-8 Support Enabled
INFO - 2024-06-20 08:09:52 --> Utf8 Class Initialized
INFO - 2024-06-20 08:09:52 --> URI Class Initialized
INFO - 2024-06-20 08:09:52 --> Router Class Initialized
INFO - 2024-06-20 08:09:52 --> Output Class Initialized
INFO - 2024-06-20 08:09:52 --> Security Class Initialized
DEBUG - 2024-06-20 08:09:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-20 08:09:52 --> Input Class Initialized
INFO - 2024-06-20 08:09:52 --> Language Class Initialized
INFO - 2024-06-20 08:09:52 --> Language Class Initialized
INFO - 2024-06-20 08:09:52 --> Config Class Initialized
INFO - 2024-06-20 08:09:52 --> Loader Class Initialized
INFO - 2024-06-20 08:09:52 --> Helper loaded: url_helper
INFO - 2024-06-20 08:09:52 --> Helper loaded: file_helper
INFO - 2024-06-20 08:09:52 --> Helper loaded: form_helper
INFO - 2024-06-20 08:09:52 --> Helper loaded: my_helper
INFO - 2024-06-20 08:09:52 --> Database Driver Class Initialized
INFO - 2024-06-20 08:09:52 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-20 08:09:52 --> Controller Class Initialized
INFO - 2024-06-20 08:09:52 --> Helper loaded: cookie_helper
INFO - 2024-06-20 08:09:52 --> Final output sent to browser
DEBUG - 2024-06-20 08:09:52 --> Total execution time: 0.0261
INFO - 2024-06-20 08:09:52 --> Config Class Initialized
INFO - 2024-06-20 08:09:52 --> Hooks Class Initialized
DEBUG - 2024-06-20 08:09:52 --> UTF-8 Support Enabled
INFO - 2024-06-20 08:09:52 --> Utf8 Class Initialized
INFO - 2024-06-20 08:09:52 --> URI Class Initialized
INFO - 2024-06-20 08:09:52 --> Router Class Initialized
INFO - 2024-06-20 08:09:52 --> Output Class Initialized
INFO - 2024-06-20 08:09:52 --> Security Class Initialized
DEBUG - 2024-06-20 08:09:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-20 08:09:52 --> Input Class Initialized
INFO - 2024-06-20 08:09:52 --> Language Class Initialized
INFO - 2024-06-20 08:09:52 --> Language Class Initialized
INFO - 2024-06-20 08:09:52 --> Config Class Initialized
INFO - 2024-06-20 08:09:52 --> Loader Class Initialized
INFO - 2024-06-20 08:09:52 --> Helper loaded: url_helper
INFO - 2024-06-20 08:09:52 --> Helper loaded: file_helper
INFO - 2024-06-20 08:09:52 --> Helper loaded: form_helper
INFO - 2024-06-20 08:09:52 --> Helper loaded: my_helper
INFO - 2024-06-20 08:09:52 --> Database Driver Class Initialized
INFO - 2024-06-20 08:09:52 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-20 08:09:52 --> Controller Class Initialized
DEBUG - 2024-06-20 08:09:52 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/home/views/v_home.php
DEBUG - 2024-06-20 08:09:52 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-06-20 08:09:52 --> Final output sent to browser
DEBUG - 2024-06-20 08:09:52 --> Total execution time: 0.0273
INFO - 2024-06-20 08:10:00 --> Config Class Initialized
INFO - 2024-06-20 08:10:00 --> Hooks Class Initialized
DEBUG - 2024-06-20 08:10:00 --> UTF-8 Support Enabled
INFO - 2024-06-20 08:10:00 --> Utf8 Class Initialized
INFO - 2024-06-20 08:10:00 --> URI Class Initialized
INFO - 2024-06-20 08:10:00 --> Router Class Initialized
INFO - 2024-06-20 08:10:00 --> Output Class Initialized
INFO - 2024-06-20 08:10:00 --> Security Class Initialized
DEBUG - 2024-06-20 08:10:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-20 08:10:00 --> Input Class Initialized
INFO - 2024-06-20 08:10:00 --> Language Class Initialized
INFO - 2024-06-20 08:10:00 --> Language Class Initialized
INFO - 2024-06-20 08:10:00 --> Config Class Initialized
INFO - 2024-06-20 08:10:00 --> Loader Class Initialized
INFO - 2024-06-20 08:10:00 --> Helper loaded: url_helper
INFO - 2024-06-20 08:10:00 --> Helper loaded: file_helper
INFO - 2024-06-20 08:10:00 --> Helper loaded: form_helper
INFO - 2024-06-20 08:10:00 --> Helper loaded: my_helper
INFO - 2024-06-20 08:10:00 --> Database Driver Class Initialized
INFO - 2024-06-20 08:10:00 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-20 08:10:00 --> Controller Class Initialized
DEBUG - 2024-06-20 08:10:00 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/data_guru/views/list.php
DEBUG - 2024-06-20 08:10:00 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-06-20 08:10:00 --> Final output sent to browser
DEBUG - 2024-06-20 08:10:00 --> Total execution time: 0.0275
INFO - 2024-06-20 08:10:00 --> Config Class Initialized
INFO - 2024-06-20 08:10:00 --> Hooks Class Initialized
DEBUG - 2024-06-20 08:10:00 --> UTF-8 Support Enabled
INFO - 2024-06-20 08:10:00 --> Utf8 Class Initialized
INFO - 2024-06-20 08:10:00 --> URI Class Initialized
INFO - 2024-06-20 08:10:00 --> Router Class Initialized
INFO - 2024-06-20 08:10:00 --> Output Class Initialized
INFO - 2024-06-20 08:10:00 --> Security Class Initialized
DEBUG - 2024-06-20 08:10:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-20 08:10:00 --> Input Class Initialized
INFO - 2024-06-20 08:10:00 --> Language Class Initialized
ERROR - 2024-06-20 08:10:00 --> 404 Page Not Found: /index
INFO - 2024-06-20 08:10:00 --> Config Class Initialized
INFO - 2024-06-20 08:10:00 --> Hooks Class Initialized
DEBUG - 2024-06-20 08:10:00 --> UTF-8 Support Enabled
INFO - 2024-06-20 08:10:00 --> Utf8 Class Initialized
INFO - 2024-06-20 08:10:00 --> URI Class Initialized
INFO - 2024-06-20 08:10:00 --> Router Class Initialized
INFO - 2024-06-20 08:10:00 --> Output Class Initialized
INFO - 2024-06-20 08:10:00 --> Security Class Initialized
DEBUG - 2024-06-20 08:10:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-20 08:10:00 --> Input Class Initialized
INFO - 2024-06-20 08:10:00 --> Language Class Initialized
INFO - 2024-06-20 08:10:00 --> Language Class Initialized
INFO - 2024-06-20 08:10:00 --> Config Class Initialized
INFO - 2024-06-20 08:10:00 --> Loader Class Initialized
INFO - 2024-06-20 08:10:00 --> Helper loaded: url_helper
INFO - 2024-06-20 08:10:00 --> Helper loaded: file_helper
INFO - 2024-06-20 08:10:00 --> Helper loaded: form_helper
INFO - 2024-06-20 08:10:00 --> Helper loaded: my_helper
INFO - 2024-06-20 08:10:00 --> Database Driver Class Initialized
INFO - 2024-06-20 08:10:00 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-20 08:10:00 --> Controller Class Initialized
INFO - 2024-06-20 08:10:09 --> Config Class Initialized
INFO - 2024-06-20 08:10:09 --> Hooks Class Initialized
DEBUG - 2024-06-20 08:10:09 --> UTF-8 Support Enabled
INFO - 2024-06-20 08:10:09 --> Utf8 Class Initialized
INFO - 2024-06-20 08:10:09 --> URI Class Initialized
INFO - 2024-06-20 08:10:09 --> Router Class Initialized
INFO - 2024-06-20 08:10:09 --> Output Class Initialized
INFO - 2024-06-20 08:10:09 --> Security Class Initialized
DEBUG - 2024-06-20 08:10:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-20 08:10:09 --> Input Class Initialized
INFO - 2024-06-20 08:10:09 --> Language Class Initialized
INFO - 2024-06-20 08:10:09 --> Language Class Initialized
INFO - 2024-06-20 08:10:09 --> Config Class Initialized
INFO - 2024-06-20 08:10:09 --> Loader Class Initialized
INFO - 2024-06-20 08:10:09 --> Helper loaded: url_helper
INFO - 2024-06-20 08:10:09 --> Helper loaded: file_helper
INFO - 2024-06-20 08:10:09 --> Helper loaded: form_helper
INFO - 2024-06-20 08:10:09 --> Helper loaded: my_helper
INFO - 2024-06-20 08:10:09 --> Database Driver Class Initialized
INFO - 2024-06-20 08:10:09 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-20 08:10:09 --> Controller Class Initialized
INFO - 2024-06-20 08:10:09 --> Helper loaded: cookie_helper
INFO - 2024-06-20 08:10:09 --> Config Class Initialized
INFO - 2024-06-20 08:10:09 --> Hooks Class Initialized
DEBUG - 2024-06-20 08:10:09 --> UTF-8 Support Enabled
INFO - 2024-06-20 08:10:09 --> Utf8 Class Initialized
INFO - 2024-06-20 08:10:09 --> URI Class Initialized
INFO - 2024-06-20 08:10:09 --> Router Class Initialized
INFO - 2024-06-20 08:10:09 --> Output Class Initialized
INFO - 2024-06-20 08:10:09 --> Security Class Initialized
DEBUG - 2024-06-20 08:10:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-20 08:10:09 --> Input Class Initialized
INFO - 2024-06-20 08:10:09 --> Language Class Initialized
INFO - 2024-06-20 08:10:09 --> Language Class Initialized
INFO - 2024-06-20 08:10:09 --> Config Class Initialized
INFO - 2024-06-20 08:10:09 --> Loader Class Initialized
INFO - 2024-06-20 08:10:09 --> Helper loaded: url_helper
INFO - 2024-06-20 08:10:09 --> Helper loaded: file_helper
INFO - 2024-06-20 08:10:09 --> Helper loaded: form_helper
INFO - 2024-06-20 08:10:09 --> Helper loaded: my_helper
INFO - 2024-06-20 08:10:09 --> Database Driver Class Initialized
INFO - 2024-06-20 08:10:09 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-20 08:10:09 --> Controller Class Initialized
INFO - 2024-06-20 08:10:09 --> Config Class Initialized
INFO - 2024-06-20 08:10:09 --> Hooks Class Initialized
DEBUG - 2024-06-20 08:10:09 --> UTF-8 Support Enabled
INFO - 2024-06-20 08:10:09 --> Utf8 Class Initialized
INFO - 2024-06-20 08:10:09 --> URI Class Initialized
INFO - 2024-06-20 08:10:09 --> Router Class Initialized
INFO - 2024-06-20 08:10:09 --> Output Class Initialized
INFO - 2024-06-20 08:10:09 --> Security Class Initialized
DEBUG - 2024-06-20 08:10:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-20 08:10:09 --> Input Class Initialized
INFO - 2024-06-20 08:10:09 --> Language Class Initialized
INFO - 2024-06-20 08:10:09 --> Language Class Initialized
INFO - 2024-06-20 08:10:09 --> Config Class Initialized
INFO - 2024-06-20 08:10:09 --> Loader Class Initialized
INFO - 2024-06-20 08:10:09 --> Helper loaded: url_helper
INFO - 2024-06-20 08:10:09 --> Helper loaded: file_helper
INFO - 2024-06-20 08:10:09 --> Helper loaded: form_helper
INFO - 2024-06-20 08:10:09 --> Helper loaded: my_helper
INFO - 2024-06-20 08:10:09 --> Database Driver Class Initialized
INFO - 2024-06-20 08:10:09 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-20 08:10:09 --> Controller Class Initialized
DEBUG - 2024-06-20 08:10:09 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/login/views/login.php
DEBUG - 2024-06-20 08:10:09 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-06-20 08:10:09 --> Final output sent to browser
DEBUG - 2024-06-20 08:10:09 --> Total execution time: 0.0266
INFO - 2024-06-20 08:10:16 --> Config Class Initialized
INFO - 2024-06-20 08:10:16 --> Hooks Class Initialized
DEBUG - 2024-06-20 08:10:16 --> UTF-8 Support Enabled
INFO - 2024-06-20 08:10:16 --> Utf8 Class Initialized
INFO - 2024-06-20 08:10:16 --> URI Class Initialized
INFO - 2024-06-20 08:10:16 --> Router Class Initialized
INFO - 2024-06-20 08:10:16 --> Output Class Initialized
INFO - 2024-06-20 08:10:16 --> Security Class Initialized
DEBUG - 2024-06-20 08:10:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-20 08:10:16 --> Input Class Initialized
INFO - 2024-06-20 08:10:16 --> Language Class Initialized
INFO - 2024-06-20 08:10:16 --> Language Class Initialized
INFO - 2024-06-20 08:10:16 --> Config Class Initialized
INFO - 2024-06-20 08:10:16 --> Loader Class Initialized
INFO - 2024-06-20 08:10:16 --> Helper loaded: url_helper
INFO - 2024-06-20 08:10:16 --> Helper loaded: file_helper
INFO - 2024-06-20 08:10:16 --> Helper loaded: form_helper
INFO - 2024-06-20 08:10:16 --> Helper loaded: my_helper
INFO - 2024-06-20 08:10:16 --> Database Driver Class Initialized
INFO - 2024-06-20 08:10:16 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-20 08:10:16 --> Controller Class Initialized
INFO - 2024-06-20 08:10:16 --> Helper loaded: cookie_helper
INFO - 2024-06-20 08:10:16 --> Final output sent to browser
DEBUG - 2024-06-20 08:10:16 --> Total execution time: 0.0482
INFO - 2024-06-20 08:10:16 --> Config Class Initialized
INFO - 2024-06-20 08:10:16 --> Hooks Class Initialized
DEBUG - 2024-06-20 08:10:16 --> UTF-8 Support Enabled
INFO - 2024-06-20 08:10:16 --> Utf8 Class Initialized
INFO - 2024-06-20 08:10:16 --> URI Class Initialized
INFO - 2024-06-20 08:10:16 --> Router Class Initialized
INFO - 2024-06-20 08:10:16 --> Output Class Initialized
INFO - 2024-06-20 08:10:16 --> Security Class Initialized
DEBUG - 2024-06-20 08:10:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-20 08:10:16 --> Input Class Initialized
INFO - 2024-06-20 08:10:16 --> Language Class Initialized
INFO - 2024-06-20 08:10:16 --> Language Class Initialized
INFO - 2024-06-20 08:10:16 --> Config Class Initialized
INFO - 2024-06-20 08:10:16 --> Loader Class Initialized
INFO - 2024-06-20 08:10:16 --> Helper loaded: url_helper
INFO - 2024-06-20 08:10:16 --> Helper loaded: file_helper
INFO - 2024-06-20 08:10:16 --> Helper loaded: form_helper
INFO - 2024-06-20 08:10:16 --> Helper loaded: my_helper
INFO - 2024-06-20 08:10:16 --> Database Driver Class Initialized
INFO - 2024-06-20 08:10:16 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-20 08:10:16 --> Controller Class Initialized
DEBUG - 2024-06-20 08:10:16 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/home/views/v_home_guru.php
DEBUG - 2024-06-20 08:10:16 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-06-20 08:10:16 --> Final output sent to browser
DEBUG - 2024-06-20 08:10:16 --> Total execution time: 0.0504
INFO - 2024-06-20 08:10:43 --> Config Class Initialized
INFO - 2024-06-20 08:10:43 --> Hooks Class Initialized
DEBUG - 2024-06-20 08:10:43 --> UTF-8 Support Enabled
INFO - 2024-06-20 08:10:43 --> Utf8 Class Initialized
INFO - 2024-06-20 08:10:43 --> URI Class Initialized
INFO - 2024-06-20 08:10:43 --> Router Class Initialized
INFO - 2024-06-20 08:10:43 --> Output Class Initialized
INFO - 2024-06-20 08:10:43 --> Security Class Initialized
DEBUG - 2024-06-20 08:10:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-20 08:10:43 --> Input Class Initialized
INFO - 2024-06-20 08:10:43 --> Language Class Initialized
INFO - 2024-06-20 08:10:43 --> Language Class Initialized
INFO - 2024-06-20 08:10:43 --> Config Class Initialized
INFO - 2024-06-20 08:10:43 --> Loader Class Initialized
INFO - 2024-06-20 08:10:43 --> Helper loaded: url_helper
INFO - 2024-06-20 08:10:44 --> Helper loaded: file_helper
INFO - 2024-06-20 08:10:44 --> Helper loaded: form_helper
INFO - 2024-06-20 08:10:44 --> Helper loaded: my_helper
INFO - 2024-06-20 08:10:44 --> Database Driver Class Initialized
INFO - 2024-06-20 08:10:44 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-20 08:10:44 --> Controller Class Initialized
DEBUG - 2024-06-20 08:10:44 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/view_mapel/views/v_view_mapel.php
DEBUG - 2024-06-20 08:10:44 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-06-20 08:10:44 --> Final output sent to browser
DEBUG - 2024-06-20 08:10:44 --> Total execution time: 0.0571
INFO - 2024-06-20 08:10:45 --> Config Class Initialized
INFO - 2024-06-20 08:10:45 --> Hooks Class Initialized
DEBUG - 2024-06-20 08:10:45 --> UTF-8 Support Enabled
INFO - 2024-06-20 08:10:45 --> Utf8 Class Initialized
INFO - 2024-06-20 08:10:45 --> URI Class Initialized
INFO - 2024-06-20 08:10:45 --> Router Class Initialized
INFO - 2024-06-20 08:10:45 --> Output Class Initialized
INFO - 2024-06-20 08:10:45 --> Security Class Initialized
DEBUG - 2024-06-20 08:10:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-20 08:10:45 --> Input Class Initialized
INFO - 2024-06-20 08:10:45 --> Language Class Initialized
INFO - 2024-06-20 08:10:45 --> Language Class Initialized
INFO - 2024-06-20 08:10:45 --> Config Class Initialized
INFO - 2024-06-20 08:10:45 --> Loader Class Initialized
INFO - 2024-06-20 08:10:45 --> Helper loaded: url_helper
INFO - 2024-06-20 08:10:45 --> Helper loaded: file_helper
INFO - 2024-06-20 08:10:45 --> Helper loaded: form_helper
INFO - 2024-06-20 08:10:45 --> Helper loaded: my_helper
INFO - 2024-06-20 08:10:45 --> Database Driver Class Initialized
INFO - 2024-06-20 08:10:45 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-20 08:10:45 --> Controller Class Initialized
DEBUG - 2024-06-20 08:10:45 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/views/list.php
DEBUG - 2024-06-20 08:10:45 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-06-20 08:10:45 --> Final output sent to browser
DEBUG - 2024-06-20 08:10:45 --> Total execution time: 0.0330
INFO - 2024-06-20 08:10:45 --> Config Class Initialized
INFO - 2024-06-20 08:10:45 --> Hooks Class Initialized
DEBUG - 2024-06-20 08:10:45 --> UTF-8 Support Enabled
INFO - 2024-06-20 08:10:45 --> Utf8 Class Initialized
INFO - 2024-06-20 08:10:45 --> URI Class Initialized
INFO - 2024-06-20 08:10:45 --> Router Class Initialized
INFO - 2024-06-20 08:10:45 --> Output Class Initialized
INFO - 2024-06-20 08:10:45 --> Security Class Initialized
DEBUG - 2024-06-20 08:10:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-20 08:10:45 --> Input Class Initialized
INFO - 2024-06-20 08:10:45 --> Language Class Initialized
INFO - 2024-06-20 08:10:45 --> Language Class Initialized
INFO - 2024-06-20 08:10:45 --> Config Class Initialized
INFO - 2024-06-20 08:10:45 --> Loader Class Initialized
INFO - 2024-06-20 08:10:45 --> Helper loaded: url_helper
INFO - 2024-06-20 08:10:45 --> Helper loaded: file_helper
INFO - 2024-06-20 08:10:45 --> Helper loaded: form_helper
INFO - 2024-06-20 08:10:45 --> Helper loaded: my_helper
INFO - 2024-06-20 08:10:45 --> Database Driver Class Initialized
INFO - 2024-06-20 08:10:45 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-20 08:10:45 --> Controller Class Initialized
INFO - 2024-06-20 08:10:48 --> Config Class Initialized
INFO - 2024-06-20 08:10:48 --> Hooks Class Initialized
DEBUG - 2024-06-20 08:10:48 --> UTF-8 Support Enabled
INFO - 2024-06-20 08:10:48 --> Utf8 Class Initialized
INFO - 2024-06-20 08:10:48 --> URI Class Initialized
INFO - 2024-06-20 08:10:48 --> Router Class Initialized
INFO - 2024-06-20 08:10:48 --> Output Class Initialized
INFO - 2024-06-20 08:10:48 --> Security Class Initialized
DEBUG - 2024-06-20 08:10:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-20 08:10:48 --> Input Class Initialized
INFO - 2024-06-20 08:10:48 --> Language Class Initialized
INFO - 2024-06-20 08:10:48 --> Language Class Initialized
INFO - 2024-06-20 08:10:48 --> Config Class Initialized
INFO - 2024-06-20 08:10:48 --> Loader Class Initialized
INFO - 2024-06-20 08:10:48 --> Helper loaded: url_helper
INFO - 2024-06-20 08:10:48 --> Helper loaded: file_helper
INFO - 2024-06-20 08:10:48 --> Helper loaded: form_helper
INFO - 2024-06-20 08:10:48 --> Helper loaded: my_helper
INFO - 2024-06-20 08:10:48 --> Database Driver Class Initialized
INFO - 2024-06-20 08:10:48 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-20 08:10:48 --> Controller Class Initialized
INFO - 2024-06-20 08:10:50 --> Config Class Initialized
INFO - 2024-06-20 08:10:50 --> Hooks Class Initialized
DEBUG - 2024-06-20 08:10:50 --> UTF-8 Support Enabled
INFO - 2024-06-20 08:10:50 --> Utf8 Class Initialized
INFO - 2024-06-20 08:10:50 --> URI Class Initialized
INFO - 2024-06-20 08:10:50 --> Router Class Initialized
INFO - 2024-06-20 08:10:50 --> Output Class Initialized
INFO - 2024-06-20 08:10:50 --> Security Class Initialized
DEBUG - 2024-06-20 08:10:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-20 08:10:50 --> Input Class Initialized
INFO - 2024-06-20 08:10:50 --> Language Class Initialized
INFO - 2024-06-20 08:10:50 --> Language Class Initialized
INFO - 2024-06-20 08:10:50 --> Config Class Initialized
INFO - 2024-06-20 08:10:50 --> Loader Class Initialized
INFO - 2024-06-20 08:10:50 --> Helper loaded: url_helper
INFO - 2024-06-20 08:10:50 --> Helper loaded: file_helper
INFO - 2024-06-20 08:10:50 --> Helper loaded: form_helper
INFO - 2024-06-20 08:10:50 --> Helper loaded: my_helper
INFO - 2024-06-20 08:10:50 --> Database Driver Class Initialized
INFO - 2024-06-20 08:10:50 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-20 08:10:50 --> Controller Class Initialized
DEBUG - 2024-06-20 08:10:50 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/view_mapel/views/v_view_mapel.php
DEBUG - 2024-06-20 08:10:50 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-06-20 08:10:50 --> Final output sent to browser
DEBUG - 2024-06-20 08:10:50 --> Total execution time: 0.0277
INFO - 2024-06-20 08:10:51 --> Config Class Initialized
INFO - 2024-06-20 08:10:51 --> Hooks Class Initialized
DEBUG - 2024-06-20 08:10:51 --> UTF-8 Support Enabled
INFO - 2024-06-20 08:10:51 --> Utf8 Class Initialized
INFO - 2024-06-20 08:10:51 --> URI Class Initialized
INFO - 2024-06-20 08:10:51 --> Router Class Initialized
INFO - 2024-06-20 08:10:51 --> Output Class Initialized
INFO - 2024-06-20 08:10:51 --> Security Class Initialized
DEBUG - 2024-06-20 08:10:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-20 08:10:51 --> Input Class Initialized
INFO - 2024-06-20 08:10:51 --> Language Class Initialized
INFO - 2024-06-20 08:10:51 --> Language Class Initialized
INFO - 2024-06-20 08:10:51 --> Config Class Initialized
INFO - 2024-06-20 08:10:51 --> Loader Class Initialized
INFO - 2024-06-20 08:10:51 --> Helper loaded: url_helper
INFO - 2024-06-20 08:10:51 --> Helper loaded: file_helper
INFO - 2024-06-20 08:10:51 --> Helper loaded: form_helper
INFO - 2024-06-20 08:10:51 --> Helper loaded: my_helper
INFO - 2024-06-20 08:10:51 --> Database Driver Class Initialized
INFO - 2024-06-20 08:10:51 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-20 08:10:51 --> Controller Class Initialized
DEBUG - 2024-06-20 08:10:51 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/views/list.php
DEBUG - 2024-06-20 08:10:51 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-06-20 08:10:51 --> Final output sent to browser
DEBUG - 2024-06-20 08:10:51 --> Total execution time: 0.0288
INFO - 2024-06-20 08:10:51 --> Config Class Initialized
INFO - 2024-06-20 08:10:51 --> Hooks Class Initialized
DEBUG - 2024-06-20 08:10:51 --> UTF-8 Support Enabled
INFO - 2024-06-20 08:10:51 --> Utf8 Class Initialized
INFO - 2024-06-20 08:10:51 --> URI Class Initialized
INFO - 2024-06-20 08:10:51 --> Router Class Initialized
INFO - 2024-06-20 08:10:51 --> Output Class Initialized
INFO - 2024-06-20 08:10:51 --> Security Class Initialized
DEBUG - 2024-06-20 08:10:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-20 08:10:51 --> Input Class Initialized
INFO - 2024-06-20 08:10:51 --> Language Class Initialized
INFO - 2024-06-20 08:10:51 --> Language Class Initialized
INFO - 2024-06-20 08:10:51 --> Config Class Initialized
INFO - 2024-06-20 08:10:51 --> Loader Class Initialized
INFO - 2024-06-20 08:10:51 --> Helper loaded: url_helper
INFO - 2024-06-20 08:10:51 --> Helper loaded: file_helper
INFO - 2024-06-20 08:10:51 --> Helper loaded: form_helper
INFO - 2024-06-20 08:10:51 --> Helper loaded: my_helper
INFO - 2024-06-20 08:10:51 --> Database Driver Class Initialized
INFO - 2024-06-20 08:10:51 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-20 08:10:51 --> Controller Class Initialized
INFO - 2024-06-20 08:10:53 --> Config Class Initialized
INFO - 2024-06-20 08:10:53 --> Hooks Class Initialized
DEBUG - 2024-06-20 08:10:53 --> UTF-8 Support Enabled
INFO - 2024-06-20 08:10:53 --> Utf8 Class Initialized
INFO - 2024-06-20 08:10:53 --> URI Class Initialized
INFO - 2024-06-20 08:10:53 --> Router Class Initialized
INFO - 2024-06-20 08:10:53 --> Output Class Initialized
INFO - 2024-06-20 08:10:53 --> Security Class Initialized
DEBUG - 2024-06-20 08:10:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-20 08:10:53 --> Input Class Initialized
INFO - 2024-06-20 08:10:53 --> Language Class Initialized
INFO - 2024-06-20 08:10:53 --> Language Class Initialized
INFO - 2024-06-20 08:10:53 --> Config Class Initialized
INFO - 2024-06-20 08:10:53 --> Loader Class Initialized
INFO - 2024-06-20 08:10:53 --> Helper loaded: url_helper
INFO - 2024-06-20 08:10:53 --> Helper loaded: file_helper
INFO - 2024-06-20 08:10:53 --> Helper loaded: form_helper
INFO - 2024-06-20 08:10:53 --> Helper loaded: my_helper
INFO - 2024-06-20 08:10:53 --> Database Driver Class Initialized
INFO - 2024-06-20 08:10:53 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-20 08:10:53 --> Controller Class Initialized
INFO - 2024-06-20 08:11:53 --> Config Class Initialized
INFO - 2024-06-20 08:11:53 --> Hooks Class Initialized
DEBUG - 2024-06-20 08:11:53 --> UTF-8 Support Enabled
INFO - 2024-06-20 08:11:53 --> Utf8 Class Initialized
INFO - 2024-06-20 08:11:53 --> URI Class Initialized
INFO - 2024-06-20 08:11:53 --> Router Class Initialized
INFO - 2024-06-20 08:11:53 --> Output Class Initialized
INFO - 2024-06-20 08:11:53 --> Security Class Initialized
DEBUG - 2024-06-20 08:11:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-20 08:11:53 --> Input Class Initialized
INFO - 2024-06-20 08:11:53 --> Language Class Initialized
INFO - 2024-06-20 08:11:53 --> Language Class Initialized
INFO - 2024-06-20 08:11:53 --> Config Class Initialized
INFO - 2024-06-20 08:11:53 --> Loader Class Initialized
INFO - 2024-06-20 08:11:53 --> Helper loaded: url_helper
INFO - 2024-06-20 08:11:53 --> Helper loaded: file_helper
INFO - 2024-06-20 08:11:53 --> Helper loaded: form_helper
INFO - 2024-06-20 08:11:53 --> Helper loaded: my_helper
INFO - 2024-06-20 08:11:53 --> Database Driver Class Initialized
INFO - 2024-06-20 08:11:53 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-20 08:11:53 --> Controller Class Initialized
DEBUG - 2024-06-20 08:11:53 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/view_mapel/views/v_view_mapel.php
DEBUG - 2024-06-20 08:11:53 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-06-20 08:11:53 --> Final output sent to browser
DEBUG - 2024-06-20 08:11:53 --> Total execution time: 0.0317
INFO - 2024-06-20 08:11:59 --> Config Class Initialized
INFO - 2024-06-20 08:11:59 --> Hooks Class Initialized
DEBUG - 2024-06-20 08:11:59 --> UTF-8 Support Enabled
INFO - 2024-06-20 08:11:59 --> Utf8 Class Initialized
INFO - 2024-06-20 08:11:59 --> URI Class Initialized
INFO - 2024-06-20 08:11:59 --> Router Class Initialized
INFO - 2024-06-20 08:11:59 --> Output Class Initialized
INFO - 2024-06-20 08:11:59 --> Security Class Initialized
DEBUG - 2024-06-20 08:11:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-20 08:11:59 --> Input Class Initialized
INFO - 2024-06-20 08:11:59 --> Language Class Initialized
INFO - 2024-06-20 08:11:59 --> Language Class Initialized
INFO - 2024-06-20 08:11:59 --> Config Class Initialized
INFO - 2024-06-20 08:11:59 --> Loader Class Initialized
INFO - 2024-06-20 08:11:59 --> Helper loaded: url_helper
INFO - 2024-06-20 08:11:59 --> Helper loaded: file_helper
INFO - 2024-06-20 08:11:59 --> Helper loaded: form_helper
INFO - 2024-06-20 08:11:59 --> Helper loaded: my_helper
INFO - 2024-06-20 08:11:59 --> Database Driver Class Initialized
INFO - 2024-06-20 08:11:59 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-20 08:11:59 --> Controller Class Initialized
DEBUG - 2024-06-20 08:11:59 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/views/list.php
DEBUG - 2024-06-20 08:11:59 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-06-20 08:11:59 --> Final output sent to browser
DEBUG - 2024-06-20 08:11:59 --> Total execution time: 0.0668
INFO - 2024-06-20 08:11:59 --> Config Class Initialized
INFO - 2024-06-20 08:11:59 --> Hooks Class Initialized
DEBUG - 2024-06-20 08:11:59 --> UTF-8 Support Enabled
INFO - 2024-06-20 08:11:59 --> Utf8 Class Initialized
INFO - 2024-06-20 08:11:59 --> URI Class Initialized
INFO - 2024-06-20 08:11:59 --> Router Class Initialized
INFO - 2024-06-20 08:11:59 --> Output Class Initialized
INFO - 2024-06-20 08:11:59 --> Security Class Initialized
DEBUG - 2024-06-20 08:11:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-20 08:11:59 --> Input Class Initialized
INFO - 2024-06-20 08:11:59 --> Language Class Initialized
INFO - 2024-06-20 08:11:59 --> Language Class Initialized
INFO - 2024-06-20 08:11:59 --> Config Class Initialized
INFO - 2024-06-20 08:11:59 --> Loader Class Initialized
INFO - 2024-06-20 08:11:59 --> Helper loaded: url_helper
INFO - 2024-06-20 08:11:59 --> Helper loaded: file_helper
INFO - 2024-06-20 08:11:59 --> Helper loaded: form_helper
INFO - 2024-06-20 08:11:59 --> Helper loaded: my_helper
INFO - 2024-06-20 08:11:59 --> Database Driver Class Initialized
INFO - 2024-06-20 08:11:59 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-20 08:11:59 --> Controller Class Initialized
INFO - 2024-06-20 08:12:52 --> Config Class Initialized
INFO - 2024-06-20 08:12:52 --> Hooks Class Initialized
DEBUG - 2024-06-20 08:12:52 --> UTF-8 Support Enabled
INFO - 2024-06-20 08:12:52 --> Utf8 Class Initialized
INFO - 2024-06-20 08:12:52 --> URI Class Initialized
INFO - 2024-06-20 08:12:52 --> Router Class Initialized
INFO - 2024-06-20 08:12:52 --> Output Class Initialized
INFO - 2024-06-20 08:12:52 --> Security Class Initialized
DEBUG - 2024-06-20 08:12:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-20 08:12:52 --> Input Class Initialized
INFO - 2024-06-20 08:12:52 --> Language Class Initialized
INFO - 2024-06-20 08:12:52 --> Language Class Initialized
INFO - 2024-06-20 08:12:52 --> Config Class Initialized
INFO - 2024-06-20 08:12:52 --> Loader Class Initialized
INFO - 2024-06-20 08:12:52 --> Helper loaded: url_helper
INFO - 2024-06-20 08:12:52 --> Helper loaded: file_helper
INFO - 2024-06-20 08:12:52 --> Helper loaded: form_helper
INFO - 2024-06-20 08:12:52 --> Helper loaded: my_helper
INFO - 2024-06-20 08:12:52 --> Database Driver Class Initialized
INFO - 2024-06-20 08:12:52 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-20 08:12:52 --> Controller Class Initialized
INFO - 2024-06-20 08:12:52 --> Final output sent to browser
DEBUG - 2024-06-20 08:12:52 --> Total execution time: 0.0606
INFO - 2024-06-20 08:12:56 --> Config Class Initialized
INFO - 2024-06-20 08:12:56 --> Hooks Class Initialized
DEBUG - 2024-06-20 08:12:56 --> UTF-8 Support Enabled
INFO - 2024-06-20 08:12:56 --> Utf8 Class Initialized
INFO - 2024-06-20 08:12:56 --> URI Class Initialized
INFO - 2024-06-20 08:12:56 --> Router Class Initialized
INFO - 2024-06-20 08:12:56 --> Output Class Initialized
INFO - 2024-06-20 08:12:56 --> Security Class Initialized
DEBUG - 2024-06-20 08:12:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-20 08:12:56 --> Input Class Initialized
INFO - 2024-06-20 08:12:56 --> Language Class Initialized
INFO - 2024-06-20 08:12:56 --> Language Class Initialized
INFO - 2024-06-20 08:12:56 --> Config Class Initialized
INFO - 2024-06-20 08:12:56 --> Loader Class Initialized
INFO - 2024-06-20 08:12:56 --> Helper loaded: url_helper
INFO - 2024-06-20 08:12:56 --> Helper loaded: file_helper
INFO - 2024-06-20 08:12:56 --> Helper loaded: form_helper
INFO - 2024-06-20 08:12:56 --> Helper loaded: my_helper
INFO - 2024-06-20 08:12:56 --> Database Driver Class Initialized
INFO - 2024-06-20 08:12:56 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-20 08:12:56 --> Controller Class Initialized
INFO - 2024-06-20 08:12:56 --> Final output sent to browser
DEBUG - 2024-06-20 08:12:56 --> Total execution time: 0.0364
INFO - 2024-06-20 08:12:56 --> Config Class Initialized
INFO - 2024-06-20 08:12:56 --> Hooks Class Initialized
DEBUG - 2024-06-20 08:12:56 --> UTF-8 Support Enabled
INFO - 2024-06-20 08:12:56 --> Utf8 Class Initialized
INFO - 2024-06-20 08:12:56 --> URI Class Initialized
INFO - 2024-06-20 08:12:56 --> Router Class Initialized
INFO - 2024-06-20 08:12:56 --> Output Class Initialized
INFO - 2024-06-20 08:12:56 --> Security Class Initialized
DEBUG - 2024-06-20 08:12:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-20 08:12:56 --> Input Class Initialized
INFO - 2024-06-20 08:12:56 --> Language Class Initialized
INFO - 2024-06-20 08:12:56 --> Language Class Initialized
INFO - 2024-06-20 08:12:56 --> Config Class Initialized
INFO - 2024-06-20 08:12:56 --> Loader Class Initialized
INFO - 2024-06-20 08:12:56 --> Helper loaded: url_helper
INFO - 2024-06-20 08:12:56 --> Helper loaded: file_helper
INFO - 2024-06-20 08:12:56 --> Helper loaded: form_helper
INFO - 2024-06-20 08:12:56 --> Helper loaded: my_helper
INFO - 2024-06-20 08:12:56 --> Database Driver Class Initialized
INFO - 2024-06-20 08:12:56 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-20 08:12:56 --> Controller Class Initialized
INFO - 2024-06-20 08:12:56 --> Final output sent to browser
DEBUG - 2024-06-20 08:12:56 --> Total execution time: 0.0354
INFO - 2024-06-20 08:12:59 --> Config Class Initialized
INFO - 2024-06-20 08:12:59 --> Hooks Class Initialized
DEBUG - 2024-06-20 08:12:59 --> UTF-8 Support Enabled
INFO - 2024-06-20 08:12:59 --> Utf8 Class Initialized
INFO - 2024-06-20 08:12:59 --> URI Class Initialized
INFO - 2024-06-20 08:12:59 --> Router Class Initialized
INFO - 2024-06-20 08:12:59 --> Output Class Initialized
INFO - 2024-06-20 08:12:59 --> Security Class Initialized
DEBUG - 2024-06-20 08:12:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-20 08:12:59 --> Input Class Initialized
INFO - 2024-06-20 08:12:59 --> Language Class Initialized
INFO - 2024-06-20 08:12:59 --> Language Class Initialized
INFO - 2024-06-20 08:12:59 --> Config Class Initialized
INFO - 2024-06-20 08:12:59 --> Loader Class Initialized
INFO - 2024-06-20 08:12:59 --> Helper loaded: url_helper
INFO - 2024-06-20 08:12:59 --> Helper loaded: file_helper
INFO - 2024-06-20 08:12:59 --> Helper loaded: form_helper
INFO - 2024-06-20 08:12:59 --> Helper loaded: my_helper
INFO - 2024-06-20 08:12:59 --> Database Driver Class Initialized
INFO - 2024-06-20 08:12:59 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-20 08:12:59 --> Controller Class Initialized
INFO - 2024-06-20 08:12:59 --> Final output sent to browser
DEBUG - 2024-06-20 08:12:59 --> Total execution time: 0.0297
INFO - 2024-06-20 08:14:23 --> Config Class Initialized
INFO - 2024-06-20 08:14:23 --> Hooks Class Initialized
DEBUG - 2024-06-20 08:14:23 --> UTF-8 Support Enabled
INFO - 2024-06-20 08:14:23 --> Utf8 Class Initialized
INFO - 2024-06-20 08:14:23 --> URI Class Initialized
INFO - 2024-06-20 08:14:23 --> Router Class Initialized
INFO - 2024-06-20 08:14:23 --> Output Class Initialized
INFO - 2024-06-20 08:14:23 --> Security Class Initialized
DEBUG - 2024-06-20 08:14:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-20 08:14:23 --> Input Class Initialized
INFO - 2024-06-20 08:14:23 --> Language Class Initialized
INFO - 2024-06-20 08:14:23 --> Language Class Initialized
INFO - 2024-06-20 08:14:23 --> Config Class Initialized
INFO - 2024-06-20 08:14:23 --> Loader Class Initialized
INFO - 2024-06-20 08:14:23 --> Helper loaded: url_helper
INFO - 2024-06-20 08:14:23 --> Helper loaded: file_helper
INFO - 2024-06-20 08:14:23 --> Helper loaded: form_helper
INFO - 2024-06-20 08:14:23 --> Helper loaded: my_helper
INFO - 2024-06-20 08:14:23 --> Database Driver Class Initialized
INFO - 2024-06-20 08:14:23 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-20 08:14:23 --> Controller Class Initialized
INFO - 2024-06-20 08:14:23 --> Final output sent to browser
DEBUG - 2024-06-20 08:14:23 --> Total execution time: 0.0423
INFO - 2024-06-20 08:14:23 --> Config Class Initialized
INFO - 2024-06-20 08:14:23 --> Hooks Class Initialized
DEBUG - 2024-06-20 08:14:23 --> UTF-8 Support Enabled
INFO - 2024-06-20 08:14:23 --> Utf8 Class Initialized
INFO - 2024-06-20 08:14:23 --> URI Class Initialized
INFO - 2024-06-20 08:14:23 --> Router Class Initialized
INFO - 2024-06-20 08:14:23 --> Output Class Initialized
INFO - 2024-06-20 08:14:23 --> Security Class Initialized
DEBUG - 2024-06-20 08:14:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-20 08:14:23 --> Input Class Initialized
INFO - 2024-06-20 08:14:23 --> Language Class Initialized
INFO - 2024-06-20 08:14:23 --> Language Class Initialized
INFO - 2024-06-20 08:14:23 --> Config Class Initialized
INFO - 2024-06-20 08:14:23 --> Loader Class Initialized
INFO - 2024-06-20 08:14:23 --> Helper loaded: url_helper
INFO - 2024-06-20 08:14:23 --> Helper loaded: file_helper
INFO - 2024-06-20 08:14:23 --> Helper loaded: form_helper
INFO - 2024-06-20 08:14:23 --> Helper loaded: my_helper
INFO - 2024-06-20 08:14:23 --> Database Driver Class Initialized
INFO - 2024-06-20 08:14:23 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-20 08:14:23 --> Controller Class Initialized
INFO - 2024-06-20 08:14:26 --> Config Class Initialized
INFO - 2024-06-20 08:14:26 --> Hooks Class Initialized
DEBUG - 2024-06-20 08:14:26 --> UTF-8 Support Enabled
INFO - 2024-06-20 08:14:26 --> Utf8 Class Initialized
INFO - 2024-06-20 08:14:26 --> URI Class Initialized
INFO - 2024-06-20 08:14:26 --> Router Class Initialized
INFO - 2024-06-20 08:14:26 --> Output Class Initialized
INFO - 2024-06-20 08:14:26 --> Security Class Initialized
DEBUG - 2024-06-20 08:14:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-20 08:14:26 --> Input Class Initialized
INFO - 2024-06-20 08:14:26 --> Language Class Initialized
INFO - 2024-06-20 08:14:26 --> Language Class Initialized
INFO - 2024-06-20 08:14:26 --> Config Class Initialized
INFO - 2024-06-20 08:14:26 --> Loader Class Initialized
INFO - 2024-06-20 08:14:26 --> Helper loaded: url_helper
INFO - 2024-06-20 08:14:26 --> Helper loaded: file_helper
INFO - 2024-06-20 08:14:26 --> Helper loaded: form_helper
INFO - 2024-06-20 08:14:26 --> Helper loaded: my_helper
INFO - 2024-06-20 08:14:26 --> Database Driver Class Initialized
INFO - 2024-06-20 08:14:26 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-20 08:14:26 --> Controller Class Initialized
INFO - 2024-06-20 08:14:26 --> Final output sent to browser
DEBUG - 2024-06-20 08:14:26 --> Total execution time: 0.0319
INFO - 2024-06-20 08:14:36 --> Config Class Initialized
INFO - 2024-06-20 08:14:36 --> Hooks Class Initialized
DEBUG - 2024-06-20 08:14:36 --> UTF-8 Support Enabled
INFO - 2024-06-20 08:14:36 --> Utf8 Class Initialized
INFO - 2024-06-20 08:14:36 --> URI Class Initialized
INFO - 2024-06-20 08:14:36 --> Router Class Initialized
INFO - 2024-06-20 08:14:36 --> Output Class Initialized
INFO - 2024-06-20 08:14:36 --> Security Class Initialized
DEBUG - 2024-06-20 08:14:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-20 08:14:36 --> Input Class Initialized
INFO - 2024-06-20 08:14:36 --> Language Class Initialized
INFO - 2024-06-20 08:14:36 --> Language Class Initialized
INFO - 2024-06-20 08:14:36 --> Config Class Initialized
INFO - 2024-06-20 08:14:36 --> Loader Class Initialized
INFO - 2024-06-20 08:14:36 --> Helper loaded: url_helper
INFO - 2024-06-20 08:14:36 --> Helper loaded: file_helper
INFO - 2024-06-20 08:14:36 --> Helper loaded: form_helper
INFO - 2024-06-20 08:14:36 --> Helper loaded: my_helper
INFO - 2024-06-20 08:14:36 --> Database Driver Class Initialized
INFO - 2024-06-20 08:14:36 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-20 08:14:36 --> Controller Class Initialized
INFO - 2024-06-20 08:14:36 --> Final output sent to browser
DEBUG - 2024-06-20 08:14:36 --> Total execution time: 0.0378
INFO - 2024-06-20 08:14:36 --> Config Class Initialized
INFO - 2024-06-20 08:14:36 --> Hooks Class Initialized
DEBUG - 2024-06-20 08:14:36 --> UTF-8 Support Enabled
INFO - 2024-06-20 08:14:36 --> Utf8 Class Initialized
INFO - 2024-06-20 08:14:36 --> URI Class Initialized
INFO - 2024-06-20 08:14:36 --> Router Class Initialized
INFO - 2024-06-20 08:14:36 --> Output Class Initialized
INFO - 2024-06-20 08:14:36 --> Security Class Initialized
DEBUG - 2024-06-20 08:14:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-20 08:14:36 --> Input Class Initialized
INFO - 2024-06-20 08:14:36 --> Language Class Initialized
INFO - 2024-06-20 08:14:36 --> Language Class Initialized
INFO - 2024-06-20 08:14:36 --> Config Class Initialized
INFO - 2024-06-20 08:14:36 --> Loader Class Initialized
INFO - 2024-06-20 08:14:36 --> Helper loaded: url_helper
INFO - 2024-06-20 08:14:36 --> Helper loaded: file_helper
INFO - 2024-06-20 08:14:36 --> Helper loaded: form_helper
INFO - 2024-06-20 08:14:36 --> Helper loaded: my_helper
INFO - 2024-06-20 08:14:36 --> Database Driver Class Initialized
INFO - 2024-06-20 08:14:36 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-20 08:14:36 --> Controller Class Initialized
INFO - 2024-06-20 08:14:36 --> Final output sent to browser
DEBUG - 2024-06-20 08:14:36 --> Total execution time: 0.0826
INFO - 2024-06-20 08:16:23 --> Config Class Initialized
INFO - 2024-06-20 08:16:23 --> Hooks Class Initialized
DEBUG - 2024-06-20 08:16:23 --> UTF-8 Support Enabled
INFO - 2024-06-20 08:16:23 --> Utf8 Class Initialized
INFO - 2024-06-20 08:16:23 --> URI Class Initialized
INFO - 2024-06-20 08:16:23 --> Router Class Initialized
INFO - 2024-06-20 08:16:23 --> Output Class Initialized
INFO - 2024-06-20 08:16:23 --> Security Class Initialized
DEBUG - 2024-06-20 08:16:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-20 08:16:23 --> Input Class Initialized
INFO - 2024-06-20 08:16:23 --> Language Class Initialized
INFO - 2024-06-20 08:16:23 --> Language Class Initialized
INFO - 2024-06-20 08:16:23 --> Config Class Initialized
INFO - 2024-06-20 08:16:23 --> Loader Class Initialized
INFO - 2024-06-20 08:16:23 --> Helper loaded: url_helper
INFO - 2024-06-20 08:16:23 --> Helper loaded: file_helper
INFO - 2024-06-20 08:16:23 --> Helper loaded: form_helper
INFO - 2024-06-20 08:16:23 --> Helper loaded: my_helper
INFO - 2024-06-20 08:16:24 --> Database Driver Class Initialized
INFO - 2024-06-20 08:16:24 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-20 08:16:24 --> Controller Class Initialized
INFO - 2024-06-20 08:16:24 --> Final output sent to browser
DEBUG - 2024-06-20 08:16:24 --> Total execution time: 0.0856
INFO - 2024-06-20 08:16:32 --> Config Class Initialized
INFO - 2024-06-20 08:16:32 --> Hooks Class Initialized
DEBUG - 2024-06-20 08:16:32 --> UTF-8 Support Enabled
INFO - 2024-06-20 08:16:32 --> Utf8 Class Initialized
INFO - 2024-06-20 08:16:32 --> URI Class Initialized
INFO - 2024-06-20 08:16:32 --> Router Class Initialized
INFO - 2024-06-20 08:16:32 --> Output Class Initialized
INFO - 2024-06-20 08:16:32 --> Security Class Initialized
DEBUG - 2024-06-20 08:16:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-20 08:16:32 --> Input Class Initialized
INFO - 2024-06-20 08:16:32 --> Language Class Initialized
INFO - 2024-06-20 08:16:32 --> Language Class Initialized
INFO - 2024-06-20 08:16:32 --> Config Class Initialized
INFO - 2024-06-20 08:16:32 --> Loader Class Initialized
INFO - 2024-06-20 08:16:32 --> Helper loaded: url_helper
INFO - 2024-06-20 08:16:32 --> Helper loaded: file_helper
INFO - 2024-06-20 08:16:32 --> Helper loaded: form_helper
INFO - 2024-06-20 08:16:32 --> Helper loaded: my_helper
INFO - 2024-06-20 08:16:32 --> Database Driver Class Initialized
INFO - 2024-06-20 08:16:32 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-20 08:16:32 --> Controller Class Initialized
INFO - 2024-06-20 08:16:32 --> Final output sent to browser
DEBUG - 2024-06-20 08:16:32 --> Total execution time: 0.0446
INFO - 2024-06-20 08:16:35 --> Config Class Initialized
INFO - 2024-06-20 08:16:35 --> Hooks Class Initialized
DEBUG - 2024-06-20 08:16:35 --> UTF-8 Support Enabled
INFO - 2024-06-20 08:16:35 --> Utf8 Class Initialized
INFO - 2024-06-20 08:16:35 --> URI Class Initialized
INFO - 2024-06-20 08:16:35 --> Router Class Initialized
INFO - 2024-06-20 08:16:35 --> Output Class Initialized
INFO - 2024-06-20 08:16:35 --> Security Class Initialized
DEBUG - 2024-06-20 08:16:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-20 08:16:35 --> Input Class Initialized
INFO - 2024-06-20 08:16:35 --> Language Class Initialized
INFO - 2024-06-20 08:16:35 --> Language Class Initialized
INFO - 2024-06-20 08:16:35 --> Config Class Initialized
INFO - 2024-06-20 08:16:35 --> Loader Class Initialized
INFO - 2024-06-20 08:16:35 --> Helper loaded: url_helper
INFO - 2024-06-20 08:16:35 --> Helper loaded: file_helper
INFO - 2024-06-20 08:16:35 --> Helper loaded: form_helper
INFO - 2024-06-20 08:16:35 --> Helper loaded: my_helper
INFO - 2024-06-20 08:16:35 --> Database Driver Class Initialized
INFO - 2024-06-20 08:16:35 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-20 08:16:35 --> Controller Class Initialized
INFO - 2024-06-20 08:16:35 --> Final output sent to browser
DEBUG - 2024-06-20 08:16:35 --> Total execution time: 0.0273
INFO - 2024-06-20 08:17:10 --> Config Class Initialized
INFO - 2024-06-20 08:17:10 --> Hooks Class Initialized
DEBUG - 2024-06-20 08:17:10 --> UTF-8 Support Enabled
INFO - 2024-06-20 08:17:10 --> Utf8 Class Initialized
INFO - 2024-06-20 08:17:10 --> URI Class Initialized
INFO - 2024-06-20 08:17:10 --> Router Class Initialized
INFO - 2024-06-20 08:17:10 --> Output Class Initialized
INFO - 2024-06-20 08:17:10 --> Security Class Initialized
DEBUG - 2024-06-20 08:17:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-20 08:17:10 --> Input Class Initialized
INFO - 2024-06-20 08:17:10 --> Language Class Initialized
INFO - 2024-06-20 08:17:10 --> Language Class Initialized
INFO - 2024-06-20 08:17:10 --> Config Class Initialized
INFO - 2024-06-20 08:17:10 --> Loader Class Initialized
INFO - 2024-06-20 08:17:10 --> Helper loaded: url_helper
INFO - 2024-06-20 08:17:10 --> Helper loaded: file_helper
INFO - 2024-06-20 08:17:10 --> Helper loaded: form_helper
INFO - 2024-06-20 08:17:10 --> Helper loaded: my_helper
INFO - 2024-06-20 08:17:10 --> Database Driver Class Initialized
INFO - 2024-06-20 08:17:10 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-20 08:17:10 --> Controller Class Initialized
INFO - 2024-06-20 08:17:10 --> Helper loaded: cookie_helper
INFO - 2024-06-20 08:17:10 --> Config Class Initialized
INFO - 2024-06-20 08:17:10 --> Hooks Class Initialized
DEBUG - 2024-06-20 08:17:10 --> UTF-8 Support Enabled
INFO - 2024-06-20 08:17:10 --> Utf8 Class Initialized
INFO - 2024-06-20 08:17:10 --> URI Class Initialized
INFO - 2024-06-20 08:17:10 --> Router Class Initialized
INFO - 2024-06-20 08:17:10 --> Output Class Initialized
INFO - 2024-06-20 08:17:10 --> Security Class Initialized
DEBUG - 2024-06-20 08:17:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-20 08:17:10 --> Input Class Initialized
INFO - 2024-06-20 08:17:10 --> Language Class Initialized
INFO - 2024-06-20 08:17:10 --> Language Class Initialized
INFO - 2024-06-20 08:17:10 --> Config Class Initialized
INFO - 2024-06-20 08:17:10 --> Loader Class Initialized
INFO - 2024-06-20 08:17:10 --> Helper loaded: url_helper
INFO - 2024-06-20 08:17:10 --> Helper loaded: file_helper
INFO - 2024-06-20 08:17:10 --> Helper loaded: form_helper
INFO - 2024-06-20 08:17:10 --> Helper loaded: my_helper
INFO - 2024-06-20 08:17:10 --> Database Driver Class Initialized
INFO - 2024-06-20 08:17:10 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-20 08:17:10 --> Controller Class Initialized
INFO - 2024-06-20 08:17:10 --> Config Class Initialized
INFO - 2024-06-20 08:17:10 --> Hooks Class Initialized
DEBUG - 2024-06-20 08:17:10 --> UTF-8 Support Enabled
INFO - 2024-06-20 08:17:10 --> Utf8 Class Initialized
INFO - 2024-06-20 08:17:10 --> URI Class Initialized
INFO - 2024-06-20 08:17:10 --> Router Class Initialized
INFO - 2024-06-20 08:17:10 --> Output Class Initialized
INFO - 2024-06-20 08:17:10 --> Security Class Initialized
DEBUG - 2024-06-20 08:17:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-20 08:17:10 --> Input Class Initialized
INFO - 2024-06-20 08:17:10 --> Language Class Initialized
INFO - 2024-06-20 08:17:10 --> Language Class Initialized
INFO - 2024-06-20 08:17:10 --> Config Class Initialized
INFO - 2024-06-20 08:17:10 --> Loader Class Initialized
INFO - 2024-06-20 08:17:10 --> Helper loaded: url_helper
INFO - 2024-06-20 08:17:10 --> Helper loaded: file_helper
INFO - 2024-06-20 08:17:10 --> Helper loaded: form_helper
INFO - 2024-06-20 08:17:10 --> Helper loaded: my_helper
INFO - 2024-06-20 08:17:10 --> Database Driver Class Initialized
INFO - 2024-06-20 08:17:10 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-20 08:17:10 --> Controller Class Initialized
DEBUG - 2024-06-20 08:17:10 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/login/views/login.php
DEBUG - 2024-06-20 08:17:10 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-06-20 08:17:10 --> Final output sent to browser
DEBUG - 2024-06-20 08:17:10 --> Total execution time: 0.0732
INFO - 2024-06-20 08:17:14 --> Config Class Initialized
INFO - 2024-06-20 08:17:14 --> Hooks Class Initialized
DEBUG - 2024-06-20 08:17:14 --> UTF-8 Support Enabled
INFO - 2024-06-20 08:17:14 --> Utf8 Class Initialized
INFO - 2024-06-20 08:17:14 --> URI Class Initialized
INFO - 2024-06-20 08:17:14 --> Router Class Initialized
INFO - 2024-06-20 08:17:14 --> Output Class Initialized
INFO - 2024-06-20 08:17:14 --> Security Class Initialized
DEBUG - 2024-06-20 08:17:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-20 08:17:15 --> Input Class Initialized
INFO - 2024-06-20 08:17:15 --> Language Class Initialized
INFO - 2024-06-20 08:17:15 --> Language Class Initialized
INFO - 2024-06-20 08:17:15 --> Config Class Initialized
INFO - 2024-06-20 08:17:15 --> Loader Class Initialized
INFO - 2024-06-20 08:17:15 --> Helper loaded: url_helper
INFO - 2024-06-20 08:17:15 --> Helper loaded: file_helper
INFO - 2024-06-20 08:17:15 --> Helper loaded: form_helper
INFO - 2024-06-20 08:17:15 --> Helper loaded: my_helper
INFO - 2024-06-20 08:17:15 --> Database Driver Class Initialized
INFO - 2024-06-20 08:17:15 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-20 08:17:15 --> Controller Class Initialized
INFO - 2024-06-20 08:17:15 --> Helper loaded: cookie_helper
INFO - 2024-06-20 08:17:15 --> Final output sent to browser
DEBUG - 2024-06-20 08:17:15 --> Total execution time: 0.0387
INFO - 2024-06-20 08:17:15 --> Config Class Initialized
INFO - 2024-06-20 08:17:15 --> Hooks Class Initialized
DEBUG - 2024-06-20 08:17:15 --> UTF-8 Support Enabled
INFO - 2024-06-20 08:17:15 --> Utf8 Class Initialized
INFO - 2024-06-20 08:17:15 --> URI Class Initialized
INFO - 2024-06-20 08:17:15 --> Router Class Initialized
INFO - 2024-06-20 08:17:15 --> Output Class Initialized
INFO - 2024-06-20 08:17:15 --> Security Class Initialized
DEBUG - 2024-06-20 08:17:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-20 08:17:15 --> Input Class Initialized
INFO - 2024-06-20 08:17:15 --> Language Class Initialized
INFO - 2024-06-20 08:17:15 --> Language Class Initialized
INFO - 2024-06-20 08:17:15 --> Config Class Initialized
INFO - 2024-06-20 08:17:15 --> Loader Class Initialized
INFO - 2024-06-20 08:17:15 --> Helper loaded: url_helper
INFO - 2024-06-20 08:17:15 --> Helper loaded: file_helper
INFO - 2024-06-20 08:17:15 --> Helper loaded: form_helper
INFO - 2024-06-20 08:17:15 --> Helper loaded: my_helper
INFO - 2024-06-20 08:17:15 --> Database Driver Class Initialized
INFO - 2024-06-20 08:17:15 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-20 08:17:15 --> Controller Class Initialized
DEBUG - 2024-06-20 08:17:15 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/home/views/v_home_guru.php
DEBUG - 2024-06-20 08:17:15 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-06-20 08:17:15 --> Final output sent to browser
DEBUG - 2024-06-20 08:17:15 --> Total execution time: 0.0289
INFO - 2024-06-20 08:17:17 --> Config Class Initialized
INFO - 2024-06-20 08:17:17 --> Hooks Class Initialized
DEBUG - 2024-06-20 08:17:17 --> UTF-8 Support Enabled
INFO - 2024-06-20 08:17:17 --> Utf8 Class Initialized
INFO - 2024-06-20 08:17:17 --> URI Class Initialized
INFO - 2024-06-20 08:17:17 --> Router Class Initialized
INFO - 2024-06-20 08:17:17 --> Output Class Initialized
INFO - 2024-06-20 08:17:17 --> Security Class Initialized
DEBUG - 2024-06-20 08:17:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-20 08:17:17 --> Input Class Initialized
INFO - 2024-06-20 08:17:17 --> Language Class Initialized
INFO - 2024-06-20 08:17:17 --> Language Class Initialized
INFO - 2024-06-20 08:17:17 --> Config Class Initialized
INFO - 2024-06-20 08:17:17 --> Loader Class Initialized
INFO - 2024-06-20 08:17:17 --> Helper loaded: url_helper
INFO - 2024-06-20 08:17:17 --> Helper loaded: file_helper
INFO - 2024-06-20 08:17:17 --> Helper loaded: form_helper
INFO - 2024-06-20 08:17:17 --> Helper loaded: my_helper
INFO - 2024-06-20 08:17:17 --> Database Driver Class Initialized
INFO - 2024-06-20 08:17:17 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-20 08:17:17 --> Controller Class Initialized
DEBUG - 2024-06-20 08:17:17 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/view_mapel/views/v_view_mapel.php
DEBUG - 2024-06-20 08:17:17 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-06-20 08:17:17 --> Final output sent to browser
DEBUG - 2024-06-20 08:17:17 --> Total execution time: 0.0602
INFO - 2024-06-20 08:17:32 --> Config Class Initialized
INFO - 2024-06-20 08:17:32 --> Hooks Class Initialized
DEBUG - 2024-06-20 08:17:32 --> UTF-8 Support Enabled
INFO - 2024-06-20 08:17:32 --> Utf8 Class Initialized
INFO - 2024-06-20 08:17:32 --> URI Class Initialized
INFO - 2024-06-20 08:17:32 --> Router Class Initialized
INFO - 2024-06-20 08:17:32 --> Output Class Initialized
INFO - 2024-06-20 08:17:32 --> Security Class Initialized
DEBUG - 2024-06-20 08:17:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-20 08:17:32 --> Input Class Initialized
INFO - 2024-06-20 08:17:32 --> Language Class Initialized
INFO - 2024-06-20 08:17:32 --> Language Class Initialized
INFO - 2024-06-20 08:17:32 --> Config Class Initialized
INFO - 2024-06-20 08:17:32 --> Loader Class Initialized
INFO - 2024-06-20 08:17:32 --> Helper loaded: url_helper
INFO - 2024-06-20 08:17:32 --> Helper loaded: file_helper
INFO - 2024-06-20 08:17:32 --> Helper loaded: form_helper
INFO - 2024-06-20 08:17:32 --> Helper loaded: my_helper
INFO - 2024-06-20 08:17:32 --> Database Driver Class Initialized
INFO - 2024-06-20 08:17:32 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-20 08:17:32 --> Controller Class Initialized
DEBUG - 2024-06-20 08:17:32 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/views/list.php
DEBUG - 2024-06-20 08:17:32 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-06-20 08:17:32 --> Final output sent to browser
DEBUG - 2024-06-20 08:17:32 --> Total execution time: 0.0439
INFO - 2024-06-20 08:17:32 --> Config Class Initialized
INFO - 2024-06-20 08:17:32 --> Hooks Class Initialized
DEBUG - 2024-06-20 08:17:32 --> UTF-8 Support Enabled
INFO - 2024-06-20 08:17:32 --> Utf8 Class Initialized
INFO - 2024-06-20 08:17:32 --> URI Class Initialized
INFO - 2024-06-20 08:17:32 --> Router Class Initialized
INFO - 2024-06-20 08:17:32 --> Output Class Initialized
INFO - 2024-06-20 08:17:32 --> Security Class Initialized
DEBUG - 2024-06-20 08:17:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-20 08:17:32 --> Input Class Initialized
INFO - 2024-06-20 08:17:32 --> Language Class Initialized
INFO - 2024-06-20 08:17:32 --> Language Class Initialized
INFO - 2024-06-20 08:17:32 --> Config Class Initialized
INFO - 2024-06-20 08:17:32 --> Loader Class Initialized
INFO - 2024-06-20 08:17:32 --> Helper loaded: url_helper
INFO - 2024-06-20 08:17:32 --> Helper loaded: file_helper
INFO - 2024-06-20 08:17:32 --> Helper loaded: form_helper
INFO - 2024-06-20 08:17:32 --> Helper loaded: my_helper
INFO - 2024-06-20 08:17:32 --> Database Driver Class Initialized
INFO - 2024-06-20 08:17:32 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-20 08:17:32 --> Controller Class Initialized
INFO - 2024-06-20 08:17:33 --> Config Class Initialized
INFO - 2024-06-20 08:17:33 --> Hooks Class Initialized
DEBUG - 2024-06-20 08:17:33 --> UTF-8 Support Enabled
INFO - 2024-06-20 08:17:33 --> Utf8 Class Initialized
INFO - 2024-06-20 08:17:33 --> URI Class Initialized
INFO - 2024-06-20 08:17:33 --> Router Class Initialized
INFO - 2024-06-20 08:17:33 --> Output Class Initialized
INFO - 2024-06-20 08:17:33 --> Security Class Initialized
DEBUG - 2024-06-20 08:17:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-20 08:17:33 --> Input Class Initialized
INFO - 2024-06-20 08:17:33 --> Language Class Initialized
INFO - 2024-06-20 08:17:33 --> Language Class Initialized
INFO - 2024-06-20 08:17:33 --> Config Class Initialized
INFO - 2024-06-20 08:17:33 --> Loader Class Initialized
INFO - 2024-06-20 08:17:33 --> Helper loaded: url_helper
INFO - 2024-06-20 08:17:33 --> Helper loaded: file_helper
INFO - 2024-06-20 08:17:33 --> Helper loaded: form_helper
INFO - 2024-06-20 08:17:33 --> Helper loaded: my_helper
INFO - 2024-06-20 08:17:33 --> Database Driver Class Initialized
INFO - 2024-06-20 08:17:33 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-20 08:17:33 --> Controller Class Initialized
INFO - 2024-06-20 08:17:49 --> Config Class Initialized
INFO - 2024-06-20 08:17:49 --> Hooks Class Initialized
DEBUG - 2024-06-20 08:17:49 --> UTF-8 Support Enabled
INFO - 2024-06-20 08:17:49 --> Utf8 Class Initialized
INFO - 2024-06-20 08:17:49 --> URI Class Initialized
INFO - 2024-06-20 08:17:49 --> Router Class Initialized
INFO - 2024-06-20 08:17:49 --> Output Class Initialized
INFO - 2024-06-20 08:17:49 --> Security Class Initialized
DEBUG - 2024-06-20 08:17:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-20 08:17:49 --> Input Class Initialized
INFO - 2024-06-20 08:17:49 --> Language Class Initialized
INFO - 2024-06-20 08:17:49 --> Language Class Initialized
INFO - 2024-06-20 08:17:49 --> Config Class Initialized
INFO - 2024-06-20 08:17:49 --> Loader Class Initialized
INFO - 2024-06-20 08:17:49 --> Helper loaded: url_helper
INFO - 2024-06-20 08:17:49 --> Helper loaded: file_helper
INFO - 2024-06-20 08:17:49 --> Helper loaded: form_helper
INFO - 2024-06-20 08:17:49 --> Helper loaded: my_helper
INFO - 2024-06-20 08:17:49 --> Database Driver Class Initialized
INFO - 2024-06-20 08:17:49 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-20 08:17:49 --> Controller Class Initialized
INFO - 2024-06-20 08:17:49 --> Helper loaded: cookie_helper
INFO - 2024-06-20 08:17:49 --> Config Class Initialized
INFO - 2024-06-20 08:17:49 --> Hooks Class Initialized
DEBUG - 2024-06-20 08:17:49 --> UTF-8 Support Enabled
INFO - 2024-06-20 08:17:49 --> Utf8 Class Initialized
INFO - 2024-06-20 08:17:49 --> URI Class Initialized
INFO - 2024-06-20 08:17:49 --> Router Class Initialized
INFO - 2024-06-20 08:17:49 --> Output Class Initialized
INFO - 2024-06-20 08:17:49 --> Security Class Initialized
DEBUG - 2024-06-20 08:17:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-20 08:17:49 --> Input Class Initialized
INFO - 2024-06-20 08:17:49 --> Language Class Initialized
INFO - 2024-06-20 08:17:49 --> Language Class Initialized
INFO - 2024-06-20 08:17:49 --> Config Class Initialized
INFO - 2024-06-20 08:17:49 --> Loader Class Initialized
INFO - 2024-06-20 08:17:49 --> Helper loaded: url_helper
INFO - 2024-06-20 08:17:49 --> Helper loaded: file_helper
INFO - 2024-06-20 08:17:49 --> Helper loaded: form_helper
INFO - 2024-06-20 08:17:49 --> Helper loaded: my_helper
INFO - 2024-06-20 08:17:49 --> Database Driver Class Initialized
INFO - 2024-06-20 08:17:49 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-20 08:17:49 --> Controller Class Initialized
INFO - 2024-06-20 08:17:49 --> Config Class Initialized
INFO - 2024-06-20 08:17:49 --> Hooks Class Initialized
DEBUG - 2024-06-20 08:17:49 --> UTF-8 Support Enabled
INFO - 2024-06-20 08:17:49 --> Utf8 Class Initialized
INFO - 2024-06-20 08:17:49 --> URI Class Initialized
INFO - 2024-06-20 08:17:49 --> Router Class Initialized
INFO - 2024-06-20 08:17:49 --> Output Class Initialized
INFO - 2024-06-20 08:17:49 --> Security Class Initialized
DEBUG - 2024-06-20 08:17:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-20 08:17:49 --> Input Class Initialized
INFO - 2024-06-20 08:17:49 --> Language Class Initialized
INFO - 2024-06-20 08:17:49 --> Language Class Initialized
INFO - 2024-06-20 08:17:49 --> Config Class Initialized
INFO - 2024-06-20 08:17:49 --> Loader Class Initialized
INFO - 2024-06-20 08:17:49 --> Helper loaded: url_helper
INFO - 2024-06-20 08:17:49 --> Helper loaded: file_helper
INFO - 2024-06-20 08:17:49 --> Helper loaded: form_helper
INFO - 2024-06-20 08:17:49 --> Helper loaded: my_helper
INFO - 2024-06-20 08:17:49 --> Database Driver Class Initialized
INFO - 2024-06-20 08:17:49 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-20 08:17:49 --> Controller Class Initialized
DEBUG - 2024-06-20 08:17:49 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/login/views/login.php
DEBUG - 2024-06-20 08:17:49 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-06-20 08:17:49 --> Final output sent to browser
DEBUG - 2024-06-20 08:17:49 --> Total execution time: 0.0270
INFO - 2024-06-20 08:17:54 --> Config Class Initialized
INFO - 2024-06-20 08:17:54 --> Hooks Class Initialized
DEBUG - 2024-06-20 08:17:54 --> UTF-8 Support Enabled
INFO - 2024-06-20 08:17:54 --> Utf8 Class Initialized
INFO - 2024-06-20 08:17:54 --> URI Class Initialized
INFO - 2024-06-20 08:17:54 --> Router Class Initialized
INFO - 2024-06-20 08:17:54 --> Output Class Initialized
INFO - 2024-06-20 08:17:54 --> Security Class Initialized
DEBUG - 2024-06-20 08:17:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-20 08:17:54 --> Input Class Initialized
INFO - 2024-06-20 08:17:54 --> Language Class Initialized
INFO - 2024-06-20 08:17:54 --> Language Class Initialized
INFO - 2024-06-20 08:17:54 --> Config Class Initialized
INFO - 2024-06-20 08:17:54 --> Loader Class Initialized
INFO - 2024-06-20 08:17:54 --> Helper loaded: url_helper
INFO - 2024-06-20 08:17:54 --> Helper loaded: file_helper
INFO - 2024-06-20 08:17:54 --> Helper loaded: form_helper
INFO - 2024-06-20 08:17:54 --> Helper loaded: my_helper
INFO - 2024-06-20 08:17:54 --> Database Driver Class Initialized
INFO - 2024-06-20 08:17:54 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-20 08:17:54 --> Controller Class Initialized
INFO - 2024-06-20 08:17:54 --> Helper loaded: cookie_helper
INFO - 2024-06-20 08:17:54 --> Final output sent to browser
DEBUG - 2024-06-20 08:17:54 --> Total execution time: 0.0972
INFO - 2024-06-20 08:17:54 --> Config Class Initialized
INFO - 2024-06-20 08:17:54 --> Hooks Class Initialized
DEBUG - 2024-06-20 08:17:54 --> UTF-8 Support Enabled
INFO - 2024-06-20 08:17:54 --> Utf8 Class Initialized
INFO - 2024-06-20 08:17:54 --> URI Class Initialized
INFO - 2024-06-20 08:17:54 --> Router Class Initialized
INFO - 2024-06-20 08:17:54 --> Output Class Initialized
INFO - 2024-06-20 08:17:54 --> Security Class Initialized
DEBUG - 2024-06-20 08:17:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-20 08:17:54 --> Input Class Initialized
INFO - 2024-06-20 08:17:54 --> Language Class Initialized
INFO - 2024-06-20 08:17:54 --> Language Class Initialized
INFO - 2024-06-20 08:17:54 --> Config Class Initialized
INFO - 2024-06-20 08:17:54 --> Loader Class Initialized
INFO - 2024-06-20 08:17:54 --> Helper loaded: url_helper
INFO - 2024-06-20 08:17:54 --> Helper loaded: file_helper
INFO - 2024-06-20 08:17:54 --> Helper loaded: form_helper
INFO - 2024-06-20 08:17:54 --> Helper loaded: my_helper
INFO - 2024-06-20 08:17:54 --> Database Driver Class Initialized
INFO - 2024-06-20 08:17:54 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-20 08:17:54 --> Controller Class Initialized
DEBUG - 2024-06-20 08:17:54 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/home/views/v_home_guru.php
DEBUG - 2024-06-20 08:17:54 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-06-20 08:17:54 --> Final output sent to browser
DEBUG - 2024-06-20 08:17:54 --> Total execution time: 0.0835
INFO - 2024-06-20 08:17:58 --> Config Class Initialized
INFO - 2024-06-20 08:17:58 --> Hooks Class Initialized
DEBUG - 2024-06-20 08:17:58 --> UTF-8 Support Enabled
INFO - 2024-06-20 08:17:58 --> Utf8 Class Initialized
INFO - 2024-06-20 08:17:58 --> URI Class Initialized
INFO - 2024-06-20 08:17:58 --> Router Class Initialized
INFO - 2024-06-20 08:17:58 --> Output Class Initialized
INFO - 2024-06-20 08:17:58 --> Security Class Initialized
DEBUG - 2024-06-20 08:17:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-20 08:17:58 --> Input Class Initialized
INFO - 2024-06-20 08:17:58 --> Language Class Initialized
INFO - 2024-06-20 08:17:58 --> Language Class Initialized
INFO - 2024-06-20 08:17:58 --> Config Class Initialized
INFO - 2024-06-20 08:17:58 --> Loader Class Initialized
INFO - 2024-06-20 08:17:58 --> Helper loaded: url_helper
INFO - 2024-06-20 08:17:58 --> Helper loaded: file_helper
INFO - 2024-06-20 08:17:58 --> Helper loaded: form_helper
INFO - 2024-06-20 08:17:58 --> Helper loaded: my_helper
INFO - 2024-06-20 08:17:58 --> Database Driver Class Initialized
INFO - 2024-06-20 08:17:58 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-20 08:17:58 --> Controller Class Initialized
DEBUG - 2024-06-20 08:17:58 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/view_mapel/views/v_view_mapel.php
DEBUG - 2024-06-20 08:17:58 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-06-20 08:17:58 --> Final output sent to browser
DEBUG - 2024-06-20 08:17:58 --> Total execution time: 0.0502
INFO - 2024-06-20 08:18:00 --> Config Class Initialized
INFO - 2024-06-20 08:18:00 --> Hooks Class Initialized
DEBUG - 2024-06-20 08:18:00 --> UTF-8 Support Enabled
INFO - 2024-06-20 08:18:00 --> Utf8 Class Initialized
INFO - 2024-06-20 08:18:00 --> URI Class Initialized
INFO - 2024-06-20 08:18:00 --> Router Class Initialized
INFO - 2024-06-20 08:18:00 --> Output Class Initialized
INFO - 2024-06-20 08:18:00 --> Security Class Initialized
DEBUG - 2024-06-20 08:18:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-20 08:18:00 --> Input Class Initialized
INFO - 2024-06-20 08:18:00 --> Language Class Initialized
INFO - 2024-06-20 08:18:00 --> Language Class Initialized
INFO - 2024-06-20 08:18:00 --> Config Class Initialized
INFO - 2024-06-20 08:18:00 --> Loader Class Initialized
INFO - 2024-06-20 08:18:00 --> Helper loaded: url_helper
INFO - 2024-06-20 08:18:00 --> Helper loaded: file_helper
INFO - 2024-06-20 08:18:00 --> Helper loaded: form_helper
INFO - 2024-06-20 08:18:00 --> Helper loaded: my_helper
INFO - 2024-06-20 08:18:00 --> Database Driver Class Initialized
INFO - 2024-06-20 08:18:00 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-20 08:18:00 --> Controller Class Initialized
DEBUG - 2024-06-20 08:18:00 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/views/list.php
DEBUG - 2024-06-20 08:18:00 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-06-20 08:18:00 --> Final output sent to browser
DEBUG - 2024-06-20 08:18:00 --> Total execution time: 0.0397
INFO - 2024-06-20 08:18:00 --> Config Class Initialized
INFO - 2024-06-20 08:18:00 --> Hooks Class Initialized
DEBUG - 2024-06-20 08:18:00 --> UTF-8 Support Enabled
INFO - 2024-06-20 08:18:00 --> Utf8 Class Initialized
INFO - 2024-06-20 08:18:00 --> URI Class Initialized
INFO - 2024-06-20 08:18:00 --> Router Class Initialized
INFO - 2024-06-20 08:18:00 --> Output Class Initialized
INFO - 2024-06-20 08:18:00 --> Security Class Initialized
DEBUG - 2024-06-20 08:18:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-20 08:18:00 --> Input Class Initialized
INFO - 2024-06-20 08:18:00 --> Language Class Initialized
INFO - 2024-06-20 08:18:00 --> Language Class Initialized
INFO - 2024-06-20 08:18:00 --> Config Class Initialized
INFO - 2024-06-20 08:18:00 --> Loader Class Initialized
INFO - 2024-06-20 08:18:00 --> Helper loaded: url_helper
INFO - 2024-06-20 08:18:00 --> Helper loaded: file_helper
INFO - 2024-06-20 08:18:00 --> Helper loaded: form_helper
INFO - 2024-06-20 08:18:00 --> Helper loaded: my_helper
INFO - 2024-06-20 08:18:00 --> Database Driver Class Initialized
INFO - 2024-06-20 08:18:00 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-20 08:18:00 --> Controller Class Initialized
INFO - 2024-06-20 08:18:02 --> Config Class Initialized
INFO - 2024-06-20 08:18:02 --> Hooks Class Initialized
DEBUG - 2024-06-20 08:18:02 --> UTF-8 Support Enabled
INFO - 2024-06-20 08:18:02 --> Utf8 Class Initialized
INFO - 2024-06-20 08:18:02 --> URI Class Initialized
INFO - 2024-06-20 08:18:02 --> Router Class Initialized
INFO - 2024-06-20 08:18:02 --> Output Class Initialized
INFO - 2024-06-20 08:18:02 --> Security Class Initialized
DEBUG - 2024-06-20 08:18:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-20 08:18:02 --> Input Class Initialized
INFO - 2024-06-20 08:18:02 --> Language Class Initialized
INFO - 2024-06-20 08:18:02 --> Language Class Initialized
INFO - 2024-06-20 08:18:02 --> Config Class Initialized
INFO - 2024-06-20 08:18:02 --> Loader Class Initialized
INFO - 2024-06-20 08:18:02 --> Helper loaded: url_helper
INFO - 2024-06-20 08:18:02 --> Helper loaded: file_helper
INFO - 2024-06-20 08:18:02 --> Helper loaded: form_helper
INFO - 2024-06-20 08:18:02 --> Helper loaded: my_helper
INFO - 2024-06-20 08:18:02 --> Database Driver Class Initialized
INFO - 2024-06-20 08:18:02 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-20 08:18:02 --> Controller Class Initialized
INFO - 2024-06-20 08:18:03 --> Config Class Initialized
INFO - 2024-06-20 08:18:03 --> Hooks Class Initialized
DEBUG - 2024-06-20 08:18:03 --> UTF-8 Support Enabled
INFO - 2024-06-20 08:18:03 --> Utf8 Class Initialized
INFO - 2024-06-20 08:18:03 --> URI Class Initialized
INFO - 2024-06-20 08:18:03 --> Router Class Initialized
INFO - 2024-06-20 08:18:03 --> Output Class Initialized
INFO - 2024-06-20 08:18:03 --> Security Class Initialized
DEBUG - 2024-06-20 08:18:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-20 08:18:03 --> Input Class Initialized
INFO - 2024-06-20 08:18:03 --> Language Class Initialized
INFO - 2024-06-20 08:18:03 --> Language Class Initialized
INFO - 2024-06-20 08:18:03 --> Config Class Initialized
INFO - 2024-06-20 08:18:03 --> Loader Class Initialized
INFO - 2024-06-20 08:18:03 --> Helper loaded: url_helper
INFO - 2024-06-20 08:18:03 --> Helper loaded: file_helper
INFO - 2024-06-20 08:18:03 --> Helper loaded: form_helper
INFO - 2024-06-20 08:18:03 --> Helper loaded: my_helper
INFO - 2024-06-20 08:18:03 --> Database Driver Class Initialized
INFO - 2024-06-20 08:18:03 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-20 08:18:03 --> Controller Class Initialized
DEBUG - 2024-06-20 08:18:03 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/view_mapel/views/v_view_mapel.php
DEBUG - 2024-06-20 08:18:03 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-06-20 08:18:03 --> Final output sent to browser
DEBUG - 2024-06-20 08:18:03 --> Total execution time: 0.0475
INFO - 2024-06-20 08:18:04 --> Config Class Initialized
INFO - 2024-06-20 08:18:04 --> Hooks Class Initialized
DEBUG - 2024-06-20 08:18:04 --> UTF-8 Support Enabled
INFO - 2024-06-20 08:18:04 --> Utf8 Class Initialized
INFO - 2024-06-20 08:18:04 --> URI Class Initialized
INFO - 2024-06-20 08:18:04 --> Router Class Initialized
INFO - 2024-06-20 08:18:04 --> Output Class Initialized
INFO - 2024-06-20 08:18:04 --> Security Class Initialized
DEBUG - 2024-06-20 08:18:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-20 08:18:04 --> Input Class Initialized
INFO - 2024-06-20 08:18:04 --> Language Class Initialized
INFO - 2024-06-20 08:18:04 --> Language Class Initialized
INFO - 2024-06-20 08:18:04 --> Config Class Initialized
INFO - 2024-06-20 08:18:04 --> Loader Class Initialized
INFO - 2024-06-20 08:18:04 --> Helper loaded: url_helper
INFO - 2024-06-20 08:18:04 --> Helper loaded: file_helper
INFO - 2024-06-20 08:18:04 --> Helper loaded: form_helper
INFO - 2024-06-20 08:18:04 --> Helper loaded: my_helper
INFO - 2024-06-20 08:18:04 --> Database Driver Class Initialized
INFO - 2024-06-20 08:18:04 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-20 08:18:04 --> Controller Class Initialized
DEBUG - 2024-06-20 08:18:04 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_icb/views/list.php
DEBUG - 2024-06-20 08:18:04 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-06-20 08:18:04 --> Final output sent to browser
DEBUG - 2024-06-20 08:18:04 --> Total execution time: 0.0287
INFO - 2024-06-20 08:18:04 --> Config Class Initialized
INFO - 2024-06-20 08:18:04 --> Hooks Class Initialized
DEBUG - 2024-06-20 08:18:04 --> UTF-8 Support Enabled
INFO - 2024-06-20 08:18:04 --> Utf8 Class Initialized
INFO - 2024-06-20 08:18:04 --> URI Class Initialized
INFO - 2024-06-20 08:18:04 --> Router Class Initialized
INFO - 2024-06-20 08:18:04 --> Output Class Initialized
INFO - 2024-06-20 08:18:04 --> Security Class Initialized
DEBUG - 2024-06-20 08:18:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-20 08:18:04 --> Input Class Initialized
INFO - 2024-06-20 08:18:04 --> Language Class Initialized
INFO - 2024-06-20 08:18:04 --> Language Class Initialized
INFO - 2024-06-20 08:18:04 --> Config Class Initialized
INFO - 2024-06-20 08:18:04 --> Loader Class Initialized
INFO - 2024-06-20 08:18:04 --> Helper loaded: url_helper
INFO - 2024-06-20 08:18:04 --> Helper loaded: file_helper
INFO - 2024-06-20 08:18:04 --> Helper loaded: form_helper
INFO - 2024-06-20 08:18:04 --> Helper loaded: my_helper
INFO - 2024-06-20 08:18:04 --> Database Driver Class Initialized
INFO - 2024-06-20 08:18:04 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-20 08:18:04 --> Controller Class Initialized
INFO - 2024-06-20 08:18:06 --> Config Class Initialized
INFO - 2024-06-20 08:18:06 --> Hooks Class Initialized
DEBUG - 2024-06-20 08:18:06 --> UTF-8 Support Enabled
INFO - 2024-06-20 08:18:06 --> Utf8 Class Initialized
INFO - 2024-06-20 08:18:06 --> URI Class Initialized
INFO - 2024-06-20 08:18:06 --> Router Class Initialized
INFO - 2024-06-20 08:18:06 --> Output Class Initialized
INFO - 2024-06-20 08:18:06 --> Security Class Initialized
DEBUG - 2024-06-20 08:18:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-20 08:18:06 --> Input Class Initialized
INFO - 2024-06-20 08:18:06 --> Language Class Initialized
INFO - 2024-06-20 08:18:06 --> Language Class Initialized
INFO - 2024-06-20 08:18:06 --> Config Class Initialized
INFO - 2024-06-20 08:18:06 --> Loader Class Initialized
INFO - 2024-06-20 08:18:06 --> Helper loaded: url_helper
INFO - 2024-06-20 08:18:06 --> Helper loaded: file_helper
INFO - 2024-06-20 08:18:06 --> Helper loaded: form_helper
INFO - 2024-06-20 08:18:06 --> Helper loaded: my_helper
INFO - 2024-06-20 08:18:06 --> Database Driver Class Initialized
INFO - 2024-06-20 08:18:06 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-20 08:18:06 --> Controller Class Initialized
INFO - 2024-06-20 08:18:07 --> Config Class Initialized
INFO - 2024-06-20 08:18:07 --> Hooks Class Initialized
DEBUG - 2024-06-20 08:18:07 --> UTF-8 Support Enabled
INFO - 2024-06-20 08:18:07 --> Utf8 Class Initialized
INFO - 2024-06-20 08:18:07 --> URI Class Initialized
INFO - 2024-06-20 08:18:07 --> Router Class Initialized
INFO - 2024-06-20 08:18:07 --> Output Class Initialized
INFO - 2024-06-20 08:18:07 --> Security Class Initialized
DEBUG - 2024-06-20 08:18:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-20 08:18:07 --> Input Class Initialized
INFO - 2024-06-20 08:18:07 --> Language Class Initialized
INFO - 2024-06-20 08:18:07 --> Language Class Initialized
INFO - 2024-06-20 08:18:07 --> Config Class Initialized
INFO - 2024-06-20 08:18:07 --> Loader Class Initialized
INFO - 2024-06-20 08:18:07 --> Helper loaded: url_helper
INFO - 2024-06-20 08:18:07 --> Helper loaded: file_helper
INFO - 2024-06-20 08:18:07 --> Helper loaded: form_helper
INFO - 2024-06-20 08:18:07 --> Helper loaded: my_helper
INFO - 2024-06-20 08:18:07 --> Database Driver Class Initialized
INFO - 2024-06-20 08:18:07 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-20 08:18:07 --> Controller Class Initialized
DEBUG - 2024-06-20 08:18:07 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/view_mapel/views/v_view_mapel.php
DEBUG - 2024-06-20 08:18:07 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-06-20 08:18:07 --> Final output sent to browser
DEBUG - 2024-06-20 08:18:07 --> Total execution time: 0.0250
INFO - 2024-06-20 08:18:08 --> Config Class Initialized
INFO - 2024-06-20 08:18:08 --> Hooks Class Initialized
DEBUG - 2024-06-20 08:18:08 --> UTF-8 Support Enabled
INFO - 2024-06-20 08:18:08 --> Utf8 Class Initialized
INFO - 2024-06-20 08:18:08 --> URI Class Initialized
INFO - 2024-06-20 08:18:08 --> Router Class Initialized
INFO - 2024-06-20 08:18:08 --> Output Class Initialized
INFO - 2024-06-20 08:18:08 --> Security Class Initialized
DEBUG - 2024-06-20 08:18:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-20 08:18:08 --> Input Class Initialized
INFO - 2024-06-20 08:18:08 --> Language Class Initialized
INFO - 2024-06-20 08:18:08 --> Language Class Initialized
INFO - 2024-06-20 08:18:08 --> Config Class Initialized
INFO - 2024-06-20 08:18:08 --> Loader Class Initialized
INFO - 2024-06-20 08:18:08 --> Helper loaded: url_helper
INFO - 2024-06-20 08:18:08 --> Helper loaded: file_helper
INFO - 2024-06-20 08:18:08 --> Helper loaded: form_helper
INFO - 2024-06-20 08:18:08 --> Helper loaded: my_helper
INFO - 2024-06-20 08:18:08 --> Database Driver Class Initialized
INFO - 2024-06-20 08:18:08 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-20 08:18:08 --> Controller Class Initialized
DEBUG - 2024-06-20 08:18:08 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pss/views/list.php
DEBUG - 2024-06-20 08:18:08 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-06-20 08:18:08 --> Final output sent to browser
DEBUG - 2024-06-20 08:18:08 --> Total execution time: 0.0308
INFO - 2024-06-20 08:18:08 --> Config Class Initialized
INFO - 2024-06-20 08:18:08 --> Hooks Class Initialized
DEBUG - 2024-06-20 08:18:08 --> UTF-8 Support Enabled
INFO - 2024-06-20 08:18:08 --> Utf8 Class Initialized
INFO - 2024-06-20 08:18:08 --> URI Class Initialized
INFO - 2024-06-20 08:18:08 --> Router Class Initialized
INFO - 2024-06-20 08:18:08 --> Output Class Initialized
INFO - 2024-06-20 08:18:08 --> Security Class Initialized
DEBUG - 2024-06-20 08:18:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-20 08:18:08 --> Input Class Initialized
INFO - 2024-06-20 08:18:08 --> Language Class Initialized
INFO - 2024-06-20 08:18:08 --> Language Class Initialized
INFO - 2024-06-20 08:18:08 --> Config Class Initialized
INFO - 2024-06-20 08:18:08 --> Loader Class Initialized
INFO - 2024-06-20 08:18:08 --> Helper loaded: url_helper
INFO - 2024-06-20 08:18:08 --> Helper loaded: file_helper
INFO - 2024-06-20 08:18:08 --> Helper loaded: form_helper
INFO - 2024-06-20 08:18:08 --> Helper loaded: my_helper
INFO - 2024-06-20 08:18:08 --> Database Driver Class Initialized
INFO - 2024-06-20 08:18:08 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-20 08:18:08 --> Controller Class Initialized
INFO - 2024-06-20 08:18:10 --> Config Class Initialized
INFO - 2024-06-20 08:18:10 --> Hooks Class Initialized
DEBUG - 2024-06-20 08:18:10 --> UTF-8 Support Enabled
INFO - 2024-06-20 08:18:10 --> Utf8 Class Initialized
INFO - 2024-06-20 08:18:10 --> URI Class Initialized
INFO - 2024-06-20 08:18:10 --> Router Class Initialized
INFO - 2024-06-20 08:18:10 --> Output Class Initialized
INFO - 2024-06-20 08:18:10 --> Security Class Initialized
DEBUG - 2024-06-20 08:18:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-20 08:18:10 --> Input Class Initialized
INFO - 2024-06-20 08:18:10 --> Language Class Initialized
INFO - 2024-06-20 08:18:10 --> Language Class Initialized
INFO - 2024-06-20 08:18:10 --> Config Class Initialized
INFO - 2024-06-20 08:18:10 --> Loader Class Initialized
INFO - 2024-06-20 08:18:10 --> Helper loaded: url_helper
INFO - 2024-06-20 08:18:10 --> Helper loaded: file_helper
INFO - 2024-06-20 08:18:10 --> Helper loaded: form_helper
INFO - 2024-06-20 08:18:10 --> Helper loaded: my_helper
INFO - 2024-06-20 08:18:10 --> Database Driver Class Initialized
INFO - 2024-06-20 08:18:10 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-20 08:18:10 --> Controller Class Initialized
INFO - 2024-06-20 08:18:11 --> Config Class Initialized
INFO - 2024-06-20 08:18:11 --> Hooks Class Initialized
DEBUG - 2024-06-20 08:18:11 --> UTF-8 Support Enabled
INFO - 2024-06-20 08:18:11 --> Utf8 Class Initialized
INFO - 2024-06-20 08:18:11 --> URI Class Initialized
INFO - 2024-06-20 08:18:11 --> Router Class Initialized
INFO - 2024-06-20 08:18:11 --> Output Class Initialized
INFO - 2024-06-20 08:18:11 --> Security Class Initialized
DEBUG - 2024-06-20 08:18:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-20 08:18:11 --> Input Class Initialized
INFO - 2024-06-20 08:18:11 --> Language Class Initialized
INFO - 2024-06-20 08:18:11 --> Language Class Initialized
INFO - 2024-06-20 08:18:11 --> Config Class Initialized
INFO - 2024-06-20 08:18:11 --> Loader Class Initialized
INFO - 2024-06-20 08:18:11 --> Helper loaded: url_helper
INFO - 2024-06-20 08:18:11 --> Helper loaded: file_helper
INFO - 2024-06-20 08:18:11 --> Helper loaded: form_helper
INFO - 2024-06-20 08:18:11 --> Helper loaded: my_helper
INFO - 2024-06-20 08:18:11 --> Database Driver Class Initialized
INFO - 2024-06-20 08:18:11 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-20 08:18:11 --> Controller Class Initialized
DEBUG - 2024-06-20 08:18:11 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/view_mapel/views/v_view_mapel.php
DEBUG - 2024-06-20 08:18:11 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-06-20 08:18:11 --> Final output sent to browser
DEBUG - 2024-06-20 08:18:11 --> Total execution time: 0.0281
INFO - 2024-06-20 08:18:15 --> Config Class Initialized
INFO - 2024-06-20 08:18:15 --> Hooks Class Initialized
DEBUG - 2024-06-20 08:18:15 --> UTF-8 Support Enabled
INFO - 2024-06-20 08:18:15 --> Utf8 Class Initialized
INFO - 2024-06-20 08:18:15 --> URI Class Initialized
INFO - 2024-06-20 08:18:15 --> Router Class Initialized
INFO - 2024-06-20 08:18:15 --> Output Class Initialized
INFO - 2024-06-20 08:18:15 --> Security Class Initialized
DEBUG - 2024-06-20 08:18:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-20 08:18:15 --> Input Class Initialized
INFO - 2024-06-20 08:18:15 --> Language Class Initialized
INFO - 2024-06-20 08:18:15 --> Language Class Initialized
INFO - 2024-06-20 08:18:15 --> Config Class Initialized
INFO - 2024-06-20 08:18:15 --> Loader Class Initialized
INFO - 2024-06-20 08:18:15 --> Helper loaded: url_helper
INFO - 2024-06-20 08:18:15 --> Helper loaded: file_helper
INFO - 2024-06-20 08:18:15 --> Helper loaded: form_helper
INFO - 2024-06-20 08:18:15 --> Helper loaded: my_helper
INFO - 2024-06-20 08:18:15 --> Database Driver Class Initialized
INFO - 2024-06-20 08:18:15 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-20 08:18:15 --> Controller Class Initialized
DEBUG - 2024-06-20 08:18:15 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_la/views/list.php
DEBUG - 2024-06-20 08:18:15 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-06-20 08:18:15 --> Final output sent to browser
DEBUG - 2024-06-20 08:18:15 --> Total execution time: 0.0312
INFO - 2024-06-20 08:18:15 --> Config Class Initialized
INFO - 2024-06-20 08:18:15 --> Hooks Class Initialized
DEBUG - 2024-06-20 08:18:15 --> UTF-8 Support Enabled
INFO - 2024-06-20 08:18:15 --> Utf8 Class Initialized
INFO - 2024-06-20 08:18:15 --> URI Class Initialized
INFO - 2024-06-20 08:18:15 --> Router Class Initialized
INFO - 2024-06-20 08:18:15 --> Output Class Initialized
INFO - 2024-06-20 08:18:15 --> Security Class Initialized
DEBUG - 2024-06-20 08:18:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-20 08:18:15 --> Input Class Initialized
INFO - 2024-06-20 08:18:15 --> Language Class Initialized
INFO - 2024-06-20 08:18:15 --> Language Class Initialized
INFO - 2024-06-20 08:18:15 --> Config Class Initialized
INFO - 2024-06-20 08:18:15 --> Loader Class Initialized
INFO - 2024-06-20 08:18:15 --> Helper loaded: url_helper
INFO - 2024-06-20 08:18:15 --> Helper loaded: file_helper
INFO - 2024-06-20 08:18:15 --> Helper loaded: form_helper
INFO - 2024-06-20 08:18:15 --> Helper loaded: my_helper
INFO - 2024-06-20 08:18:15 --> Database Driver Class Initialized
INFO - 2024-06-20 08:18:15 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-20 08:18:15 --> Controller Class Initialized
INFO - 2024-06-20 08:18:16 --> Config Class Initialized
INFO - 2024-06-20 08:18:16 --> Hooks Class Initialized
DEBUG - 2024-06-20 08:18:16 --> UTF-8 Support Enabled
INFO - 2024-06-20 08:18:16 --> Utf8 Class Initialized
INFO - 2024-06-20 08:18:16 --> URI Class Initialized
INFO - 2024-06-20 08:18:16 --> Router Class Initialized
INFO - 2024-06-20 08:18:16 --> Output Class Initialized
INFO - 2024-06-20 08:18:16 --> Security Class Initialized
DEBUG - 2024-06-20 08:18:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-20 08:18:16 --> Input Class Initialized
INFO - 2024-06-20 08:18:16 --> Language Class Initialized
INFO - 2024-06-20 08:18:16 --> Language Class Initialized
INFO - 2024-06-20 08:18:16 --> Config Class Initialized
INFO - 2024-06-20 08:18:16 --> Loader Class Initialized
INFO - 2024-06-20 08:18:16 --> Helper loaded: url_helper
INFO - 2024-06-20 08:18:16 --> Helper loaded: file_helper
INFO - 2024-06-20 08:18:16 --> Helper loaded: form_helper
INFO - 2024-06-20 08:18:16 --> Helper loaded: my_helper
INFO - 2024-06-20 08:18:16 --> Database Driver Class Initialized
INFO - 2024-06-20 08:18:16 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-20 08:18:16 --> Controller Class Initialized
INFO - 2024-06-20 08:18:18 --> Config Class Initialized
INFO - 2024-06-20 08:18:18 --> Hooks Class Initialized
DEBUG - 2024-06-20 08:18:18 --> UTF-8 Support Enabled
INFO - 2024-06-20 08:18:18 --> Utf8 Class Initialized
INFO - 2024-06-20 08:18:18 --> URI Class Initialized
INFO - 2024-06-20 08:18:18 --> Router Class Initialized
INFO - 2024-06-20 08:18:18 --> Output Class Initialized
INFO - 2024-06-20 08:18:18 --> Security Class Initialized
DEBUG - 2024-06-20 08:18:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-20 08:18:18 --> Input Class Initialized
INFO - 2024-06-20 08:18:18 --> Language Class Initialized
INFO - 2024-06-20 08:18:18 --> Language Class Initialized
INFO - 2024-06-20 08:18:18 --> Config Class Initialized
INFO - 2024-06-20 08:18:18 --> Loader Class Initialized
INFO - 2024-06-20 08:18:18 --> Helper loaded: url_helper
INFO - 2024-06-20 08:18:18 --> Helper loaded: file_helper
INFO - 2024-06-20 08:18:18 --> Helper loaded: form_helper
INFO - 2024-06-20 08:18:18 --> Helper loaded: my_helper
INFO - 2024-06-20 08:18:18 --> Database Driver Class Initialized
INFO - 2024-06-20 08:18:18 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-20 08:18:18 --> Controller Class Initialized
DEBUG - 2024-06-20 08:18:18 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/view_mapel/views/v_view_mapel.php
DEBUG - 2024-06-20 08:18:18 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-06-20 08:18:18 --> Final output sent to browser
DEBUG - 2024-06-20 08:18:18 --> Total execution time: 0.0505
INFO - 2024-06-20 08:18:20 --> Config Class Initialized
INFO - 2024-06-20 08:18:20 --> Hooks Class Initialized
DEBUG - 2024-06-20 08:18:20 --> UTF-8 Support Enabled
INFO - 2024-06-20 08:18:20 --> Utf8 Class Initialized
INFO - 2024-06-20 08:18:20 --> URI Class Initialized
INFO - 2024-06-20 08:18:20 --> Router Class Initialized
INFO - 2024-06-20 08:18:20 --> Output Class Initialized
INFO - 2024-06-20 08:18:20 --> Security Class Initialized
DEBUG - 2024-06-20 08:18:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-20 08:18:20 --> Input Class Initialized
INFO - 2024-06-20 08:18:20 --> Language Class Initialized
INFO - 2024-06-20 08:18:20 --> Language Class Initialized
INFO - 2024-06-20 08:18:20 --> Config Class Initialized
INFO - 2024-06-20 08:18:20 --> Loader Class Initialized
INFO - 2024-06-20 08:18:20 --> Helper loaded: url_helper
INFO - 2024-06-20 08:18:20 --> Helper loaded: file_helper
INFO - 2024-06-20 08:18:20 --> Helper loaded: form_helper
INFO - 2024-06-20 08:18:20 --> Helper loaded: my_helper
INFO - 2024-06-20 08:18:20 --> Database Driver Class Initialized
INFO - 2024-06-20 08:18:20 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-20 08:18:20 --> Controller Class Initialized
DEBUG - 2024-06-20 08:18:20 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/views/list.php
DEBUG - 2024-06-20 08:18:20 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-06-20 08:18:20 --> Final output sent to browser
DEBUG - 2024-06-20 08:18:20 --> Total execution time: 0.0296
INFO - 2024-06-20 08:18:20 --> Config Class Initialized
INFO - 2024-06-20 08:18:20 --> Hooks Class Initialized
DEBUG - 2024-06-20 08:18:20 --> UTF-8 Support Enabled
INFO - 2024-06-20 08:18:20 --> Utf8 Class Initialized
INFO - 2024-06-20 08:18:20 --> URI Class Initialized
INFO - 2024-06-20 08:18:20 --> Router Class Initialized
INFO - 2024-06-20 08:18:20 --> Output Class Initialized
INFO - 2024-06-20 08:18:20 --> Security Class Initialized
DEBUG - 2024-06-20 08:18:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-20 08:18:20 --> Input Class Initialized
INFO - 2024-06-20 08:18:20 --> Language Class Initialized
INFO - 2024-06-20 08:18:20 --> Language Class Initialized
INFO - 2024-06-20 08:18:20 --> Config Class Initialized
INFO - 2024-06-20 08:18:20 --> Loader Class Initialized
INFO - 2024-06-20 08:18:20 --> Helper loaded: url_helper
INFO - 2024-06-20 08:18:20 --> Helper loaded: file_helper
INFO - 2024-06-20 08:18:20 --> Helper loaded: form_helper
INFO - 2024-06-20 08:18:20 --> Helper loaded: my_helper
INFO - 2024-06-20 08:18:20 --> Database Driver Class Initialized
INFO - 2024-06-20 08:18:20 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-20 08:18:20 --> Controller Class Initialized
INFO - 2024-06-20 08:18:21 --> Config Class Initialized
INFO - 2024-06-20 08:18:21 --> Hooks Class Initialized
DEBUG - 2024-06-20 08:18:21 --> UTF-8 Support Enabled
INFO - 2024-06-20 08:18:21 --> Utf8 Class Initialized
INFO - 2024-06-20 08:18:21 --> URI Class Initialized
INFO - 2024-06-20 08:18:21 --> Router Class Initialized
INFO - 2024-06-20 08:18:21 --> Output Class Initialized
INFO - 2024-06-20 08:18:21 --> Security Class Initialized
DEBUG - 2024-06-20 08:18:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-20 08:18:21 --> Input Class Initialized
INFO - 2024-06-20 08:18:21 --> Language Class Initialized
INFO - 2024-06-20 08:18:21 --> Language Class Initialized
INFO - 2024-06-20 08:18:21 --> Config Class Initialized
INFO - 2024-06-20 08:18:21 --> Loader Class Initialized
INFO - 2024-06-20 08:18:21 --> Helper loaded: url_helper
INFO - 2024-06-20 08:18:21 --> Helper loaded: file_helper
INFO - 2024-06-20 08:18:21 --> Helper loaded: form_helper
INFO - 2024-06-20 08:18:21 --> Helper loaded: my_helper
INFO - 2024-06-20 08:18:21 --> Database Driver Class Initialized
INFO - 2024-06-20 08:18:21 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-20 08:18:21 --> Controller Class Initialized
INFO - 2024-06-20 08:18:22 --> Config Class Initialized
INFO - 2024-06-20 08:18:22 --> Hooks Class Initialized
DEBUG - 2024-06-20 08:18:22 --> UTF-8 Support Enabled
INFO - 2024-06-20 08:18:22 --> Utf8 Class Initialized
INFO - 2024-06-20 08:18:22 --> URI Class Initialized
INFO - 2024-06-20 08:18:22 --> Router Class Initialized
INFO - 2024-06-20 08:18:22 --> Output Class Initialized
INFO - 2024-06-20 08:18:22 --> Security Class Initialized
DEBUG - 2024-06-20 08:18:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-20 08:18:22 --> Input Class Initialized
INFO - 2024-06-20 08:18:22 --> Language Class Initialized
INFO - 2024-06-20 08:18:22 --> Language Class Initialized
INFO - 2024-06-20 08:18:22 --> Config Class Initialized
INFO - 2024-06-20 08:18:22 --> Loader Class Initialized
INFO - 2024-06-20 08:18:22 --> Helper loaded: url_helper
INFO - 2024-06-20 08:18:22 --> Helper loaded: file_helper
INFO - 2024-06-20 08:18:22 --> Helper loaded: form_helper
INFO - 2024-06-20 08:18:22 --> Helper loaded: my_helper
INFO - 2024-06-20 08:18:22 --> Database Driver Class Initialized
INFO - 2024-06-20 08:18:22 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-20 08:18:22 --> Controller Class Initialized
DEBUG - 2024-06-20 08:18:22 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/view_mapel/views/v_view_mapel.php
DEBUG - 2024-06-20 08:18:22 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-06-20 08:18:22 --> Final output sent to browser
DEBUG - 2024-06-20 08:18:22 --> Total execution time: 0.0264
INFO - 2024-06-20 08:18:25 --> Config Class Initialized
INFO - 2024-06-20 08:18:25 --> Hooks Class Initialized
DEBUG - 2024-06-20 08:18:25 --> UTF-8 Support Enabled
INFO - 2024-06-20 08:18:25 --> Utf8 Class Initialized
INFO - 2024-06-20 08:18:25 --> URI Class Initialized
INFO - 2024-06-20 08:18:25 --> Router Class Initialized
INFO - 2024-06-20 08:18:25 --> Output Class Initialized
INFO - 2024-06-20 08:18:25 --> Security Class Initialized
DEBUG - 2024-06-20 08:18:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-20 08:18:25 --> Input Class Initialized
INFO - 2024-06-20 08:18:25 --> Language Class Initialized
INFO - 2024-06-20 08:18:25 --> Language Class Initialized
INFO - 2024-06-20 08:18:25 --> Config Class Initialized
INFO - 2024-06-20 08:18:25 --> Loader Class Initialized
INFO - 2024-06-20 08:18:25 --> Helper loaded: url_helper
INFO - 2024-06-20 08:18:25 --> Helper loaded: file_helper
INFO - 2024-06-20 08:18:25 --> Helper loaded: form_helper
INFO - 2024-06-20 08:18:25 --> Helper loaded: my_helper
INFO - 2024-06-20 08:18:25 --> Database Driver Class Initialized
INFO - 2024-06-20 08:18:25 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-20 08:18:25 --> Controller Class Initialized
DEBUG - 2024-06-20 08:18:25 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/views/list.php
DEBUG - 2024-06-20 08:18:25 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-06-20 08:18:25 --> Final output sent to browser
DEBUG - 2024-06-20 08:18:25 --> Total execution time: 0.0302
INFO - 2024-06-20 08:18:25 --> Config Class Initialized
INFO - 2024-06-20 08:18:25 --> Hooks Class Initialized
DEBUG - 2024-06-20 08:18:25 --> UTF-8 Support Enabled
INFO - 2024-06-20 08:18:25 --> Utf8 Class Initialized
INFO - 2024-06-20 08:18:25 --> URI Class Initialized
INFO - 2024-06-20 08:18:25 --> Router Class Initialized
INFO - 2024-06-20 08:18:25 --> Output Class Initialized
INFO - 2024-06-20 08:18:25 --> Security Class Initialized
DEBUG - 2024-06-20 08:18:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-20 08:18:25 --> Input Class Initialized
INFO - 2024-06-20 08:18:25 --> Language Class Initialized
INFO - 2024-06-20 08:18:25 --> Language Class Initialized
INFO - 2024-06-20 08:18:25 --> Config Class Initialized
INFO - 2024-06-20 08:18:25 --> Loader Class Initialized
INFO - 2024-06-20 08:18:25 --> Helper loaded: url_helper
INFO - 2024-06-20 08:18:25 --> Helper loaded: file_helper
INFO - 2024-06-20 08:18:25 --> Helper loaded: form_helper
INFO - 2024-06-20 08:18:25 --> Helper loaded: my_helper
INFO - 2024-06-20 08:18:25 --> Database Driver Class Initialized
INFO - 2024-06-20 08:18:25 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-20 08:18:25 --> Controller Class Initialized
INFO - 2024-06-20 08:18:27 --> Config Class Initialized
INFO - 2024-06-20 08:18:27 --> Hooks Class Initialized
DEBUG - 2024-06-20 08:18:27 --> UTF-8 Support Enabled
INFO - 2024-06-20 08:18:27 --> Utf8 Class Initialized
INFO - 2024-06-20 08:18:27 --> URI Class Initialized
INFO - 2024-06-20 08:18:27 --> Router Class Initialized
INFO - 2024-06-20 08:18:27 --> Output Class Initialized
INFO - 2024-06-20 08:18:27 --> Security Class Initialized
DEBUG - 2024-06-20 08:18:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-20 08:18:27 --> Input Class Initialized
INFO - 2024-06-20 08:18:27 --> Language Class Initialized
INFO - 2024-06-20 08:18:27 --> Language Class Initialized
INFO - 2024-06-20 08:18:27 --> Config Class Initialized
INFO - 2024-06-20 08:18:27 --> Loader Class Initialized
INFO - 2024-06-20 08:18:27 --> Helper loaded: url_helper
INFO - 2024-06-20 08:18:27 --> Helper loaded: file_helper
INFO - 2024-06-20 08:18:27 --> Helper loaded: form_helper
INFO - 2024-06-20 08:18:27 --> Helper loaded: my_helper
INFO - 2024-06-20 08:18:27 --> Database Driver Class Initialized
INFO - 2024-06-20 08:18:27 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-20 08:18:27 --> Controller Class Initialized
INFO - 2024-06-20 08:18:29 --> Config Class Initialized
INFO - 2024-06-20 08:18:29 --> Hooks Class Initialized
DEBUG - 2024-06-20 08:18:29 --> UTF-8 Support Enabled
INFO - 2024-06-20 08:18:29 --> Utf8 Class Initialized
INFO - 2024-06-20 08:18:29 --> URI Class Initialized
INFO - 2024-06-20 08:18:29 --> Router Class Initialized
INFO - 2024-06-20 08:18:29 --> Output Class Initialized
INFO - 2024-06-20 08:18:29 --> Security Class Initialized
DEBUG - 2024-06-20 08:18:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-20 08:18:29 --> Input Class Initialized
INFO - 2024-06-20 08:18:29 --> Language Class Initialized
INFO - 2024-06-20 08:18:29 --> Language Class Initialized
INFO - 2024-06-20 08:18:29 --> Config Class Initialized
INFO - 2024-06-20 08:18:29 --> Loader Class Initialized
INFO - 2024-06-20 08:18:29 --> Helper loaded: url_helper
INFO - 2024-06-20 08:18:29 --> Helper loaded: file_helper
INFO - 2024-06-20 08:18:29 --> Helper loaded: form_helper
INFO - 2024-06-20 08:18:29 --> Helper loaded: my_helper
INFO - 2024-06-20 08:18:29 --> Database Driver Class Initialized
INFO - 2024-06-20 08:18:29 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-20 08:18:29 --> Controller Class Initialized
DEBUG - 2024-06-20 08:18:29 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/view_mapel/views/v_view_mapel.php
DEBUG - 2024-06-20 08:18:29 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-06-20 08:18:29 --> Final output sent to browser
DEBUG - 2024-06-20 08:18:29 --> Total execution time: 0.0335
INFO - 2024-06-20 08:20:49 --> Config Class Initialized
INFO - 2024-06-20 08:20:49 --> Hooks Class Initialized
DEBUG - 2024-06-20 08:20:49 --> UTF-8 Support Enabled
INFO - 2024-06-20 08:20:49 --> Utf8 Class Initialized
INFO - 2024-06-20 08:20:49 --> URI Class Initialized
INFO - 2024-06-20 08:20:49 --> Router Class Initialized
INFO - 2024-06-20 08:20:49 --> Output Class Initialized
INFO - 2024-06-20 08:20:49 --> Security Class Initialized
DEBUG - 2024-06-20 08:20:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-20 08:20:49 --> Input Class Initialized
INFO - 2024-06-20 08:20:49 --> Language Class Initialized
INFO - 2024-06-20 08:20:49 --> Language Class Initialized
INFO - 2024-06-20 08:20:49 --> Config Class Initialized
INFO - 2024-06-20 08:20:49 --> Loader Class Initialized
INFO - 2024-06-20 08:20:49 --> Helper loaded: url_helper
INFO - 2024-06-20 08:20:49 --> Helper loaded: file_helper
INFO - 2024-06-20 08:20:49 --> Helper loaded: form_helper
INFO - 2024-06-20 08:20:49 --> Helper loaded: my_helper
INFO - 2024-06-20 08:20:49 --> Database Driver Class Initialized
INFO - 2024-06-20 08:20:49 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-20 08:20:49 --> Controller Class Initialized
DEBUG - 2024-06-20 08:20:49 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/views/list.php
DEBUG - 2024-06-20 08:20:49 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-06-20 08:20:49 --> Final output sent to browser
DEBUG - 2024-06-20 08:20:49 --> Total execution time: 0.0347
INFO - 2024-06-20 08:20:51 --> Config Class Initialized
INFO - 2024-06-20 08:20:51 --> Hooks Class Initialized
DEBUG - 2024-06-20 08:20:51 --> UTF-8 Support Enabled
INFO - 2024-06-20 08:20:51 --> Utf8 Class Initialized
INFO - 2024-06-20 08:20:51 --> URI Class Initialized
INFO - 2024-06-20 08:20:51 --> Router Class Initialized
INFO - 2024-06-20 08:20:51 --> Output Class Initialized
INFO - 2024-06-20 08:20:51 --> Security Class Initialized
DEBUG - 2024-06-20 08:20:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-20 08:20:51 --> Input Class Initialized
INFO - 2024-06-20 08:20:51 --> Language Class Initialized
INFO - 2024-06-20 08:20:51 --> Language Class Initialized
INFO - 2024-06-20 08:20:51 --> Config Class Initialized
INFO - 2024-06-20 08:20:51 --> Loader Class Initialized
INFO - 2024-06-20 08:20:51 --> Helper loaded: url_helper
INFO - 2024-06-20 08:20:51 --> Helper loaded: file_helper
INFO - 2024-06-20 08:20:51 --> Helper loaded: form_helper
INFO - 2024-06-20 08:20:51 --> Helper loaded: my_helper
INFO - 2024-06-20 08:20:51 --> Database Driver Class Initialized
INFO - 2024-06-20 08:20:51 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-20 08:20:51 --> Controller Class Initialized
DEBUG - 2024-06-20 08:20:51 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/views/cetak_ikm.php
INFO - 2024-06-20 08:20:54 --> Config Class Initialized
INFO - 2024-06-20 08:20:54 --> Hooks Class Initialized
DEBUG - 2024-06-20 08:20:54 --> UTF-8 Support Enabled
INFO - 2024-06-20 08:20:54 --> Utf8 Class Initialized
INFO - 2024-06-20 08:20:54 --> URI Class Initialized
INFO - 2024-06-20 08:20:54 --> Router Class Initialized
INFO - 2024-06-20 08:20:54 --> Output Class Initialized
INFO - 2024-06-20 08:20:54 --> Security Class Initialized
DEBUG - 2024-06-20 08:20:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-20 08:20:54 --> Input Class Initialized
INFO - 2024-06-20 08:20:54 --> Language Class Initialized
INFO - 2024-06-20 08:20:54 --> Language Class Initialized
INFO - 2024-06-20 08:20:54 --> Config Class Initialized
INFO - 2024-06-20 08:20:54 --> Loader Class Initialized
INFO - 2024-06-20 08:20:54 --> Helper loaded: url_helper
INFO - 2024-06-20 08:20:54 --> Helper loaded: file_helper
INFO - 2024-06-20 08:20:54 --> Helper loaded: form_helper
INFO - 2024-06-20 08:20:54 --> Helper loaded: my_helper
INFO - 2024-06-20 08:20:54 --> Database Driver Class Initialized
INFO - 2024-06-20 08:20:55 --> Final output sent to browser
DEBUG - 2024-06-20 08:20:55 --> Total execution time: 4.2565
INFO - 2024-06-20 08:20:55 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-20 08:20:55 --> Controller Class Initialized
DEBUG - 2024-06-20 08:20:55 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/views/cetak_ikm.php
INFO - 2024-06-20 08:20:56 --> Config Class Initialized
INFO - 2024-06-20 08:20:56 --> Hooks Class Initialized
DEBUG - 2024-06-20 08:20:56 --> UTF-8 Support Enabled
INFO - 2024-06-20 08:20:56 --> Utf8 Class Initialized
INFO - 2024-06-20 08:20:56 --> URI Class Initialized
INFO - 2024-06-20 08:20:56 --> Router Class Initialized
INFO - 2024-06-20 08:20:56 --> Output Class Initialized
INFO - 2024-06-20 08:20:56 --> Security Class Initialized
DEBUG - 2024-06-20 08:20:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-20 08:20:56 --> Input Class Initialized
INFO - 2024-06-20 08:20:56 --> Language Class Initialized
INFO - 2024-06-20 08:20:56 --> Language Class Initialized
INFO - 2024-06-20 08:20:56 --> Config Class Initialized
INFO - 2024-06-20 08:20:56 --> Loader Class Initialized
INFO - 2024-06-20 08:20:56 --> Helper loaded: url_helper
INFO - 2024-06-20 08:20:56 --> Helper loaded: file_helper
INFO - 2024-06-20 08:20:56 --> Helper loaded: form_helper
INFO - 2024-06-20 08:20:56 --> Helper loaded: my_helper
INFO - 2024-06-20 08:20:56 --> Database Driver Class Initialized
INFO - 2024-06-20 08:20:58 --> Final output sent to browser
DEBUG - 2024-06-20 08:20:58 --> Total execution time: 4.2146
INFO - 2024-06-20 08:20:58 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-20 08:20:58 --> Controller Class Initialized
DEBUG - 2024-06-20 08:20:58 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/views/cetak_ikm.php
INFO - 2024-06-20 08:20:58 --> Config Class Initialized
INFO - 2024-06-20 08:20:58 --> Hooks Class Initialized
DEBUG - 2024-06-20 08:20:58 --> UTF-8 Support Enabled
INFO - 2024-06-20 08:20:58 --> Utf8 Class Initialized
INFO - 2024-06-20 08:20:58 --> URI Class Initialized
INFO - 2024-06-20 08:20:58 --> Router Class Initialized
INFO - 2024-06-20 08:20:58 --> Output Class Initialized
INFO - 2024-06-20 08:20:58 --> Security Class Initialized
DEBUG - 2024-06-20 08:20:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-20 08:20:58 --> Input Class Initialized
INFO - 2024-06-20 08:20:58 --> Language Class Initialized
INFO - 2024-06-20 08:20:58 --> Language Class Initialized
INFO - 2024-06-20 08:20:58 --> Config Class Initialized
INFO - 2024-06-20 08:20:58 --> Loader Class Initialized
INFO - 2024-06-20 08:20:58 --> Helper loaded: url_helper
INFO - 2024-06-20 08:20:58 --> Helper loaded: file_helper
INFO - 2024-06-20 08:20:58 --> Helper loaded: form_helper
INFO - 2024-06-20 08:20:58 --> Helper loaded: my_helper
INFO - 2024-06-20 08:20:58 --> Database Driver Class Initialized
INFO - 2024-06-20 08:21:00 --> Final output sent to browser
DEBUG - 2024-06-20 08:21:00 --> Total execution time: 3.8896
INFO - 2024-06-20 08:21:00 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-20 08:21:00 --> Controller Class Initialized
DEBUG - 2024-06-20 08:21:00 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/views/cetak_ikm.php
INFO - 2024-06-20 08:21:01 --> Config Class Initialized
INFO - 2024-06-20 08:21:01 --> Hooks Class Initialized
DEBUG - 2024-06-20 08:21:01 --> UTF-8 Support Enabled
INFO - 2024-06-20 08:21:01 --> Utf8 Class Initialized
INFO - 2024-06-20 08:21:01 --> URI Class Initialized
INFO - 2024-06-20 08:21:01 --> Router Class Initialized
INFO - 2024-06-20 08:21:01 --> Output Class Initialized
INFO - 2024-06-20 08:21:01 --> Security Class Initialized
DEBUG - 2024-06-20 08:21:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-20 08:21:01 --> Input Class Initialized
INFO - 2024-06-20 08:21:01 --> Language Class Initialized
INFO - 2024-06-20 08:21:01 --> Language Class Initialized
INFO - 2024-06-20 08:21:01 --> Config Class Initialized
INFO - 2024-06-20 08:21:01 --> Loader Class Initialized
INFO - 2024-06-20 08:21:01 --> Helper loaded: url_helper
INFO - 2024-06-20 08:21:01 --> Helper loaded: file_helper
INFO - 2024-06-20 08:21:01 --> Helper loaded: form_helper
INFO - 2024-06-20 08:21:01 --> Helper loaded: my_helper
INFO - 2024-06-20 08:21:01 --> Database Driver Class Initialized
INFO - 2024-06-20 08:21:02 --> Final output sent to browser
DEBUG - 2024-06-20 08:21:02 --> Total execution time: 4.0647
INFO - 2024-06-20 08:21:02 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-20 08:21:02 --> Controller Class Initialized
DEBUG - 2024-06-20 08:21:02 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/views/cetak_ikm.php
INFO - 2024-06-20 08:21:04 --> Final output sent to browser
DEBUG - 2024-06-20 08:21:04 --> Total execution time: 3.0474
INFO - 2024-06-20 08:21:06 --> Config Class Initialized
INFO - 2024-06-20 08:21:06 --> Hooks Class Initialized
DEBUG - 2024-06-20 08:21:06 --> UTF-8 Support Enabled
INFO - 2024-06-20 08:21:06 --> Utf8 Class Initialized
INFO - 2024-06-20 08:21:06 --> URI Class Initialized
INFO - 2024-06-20 08:21:06 --> Router Class Initialized
INFO - 2024-06-20 08:21:06 --> Output Class Initialized
INFO - 2024-06-20 08:21:06 --> Security Class Initialized
DEBUG - 2024-06-20 08:21:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-20 08:21:06 --> Input Class Initialized
INFO - 2024-06-20 08:21:06 --> Language Class Initialized
INFO - 2024-06-20 08:21:06 --> Language Class Initialized
INFO - 2024-06-20 08:21:06 --> Config Class Initialized
INFO - 2024-06-20 08:21:06 --> Loader Class Initialized
INFO - 2024-06-20 08:21:06 --> Helper loaded: url_helper
INFO - 2024-06-20 08:21:06 --> Helper loaded: file_helper
INFO - 2024-06-20 08:21:06 --> Helper loaded: form_helper
INFO - 2024-06-20 08:21:06 --> Helper loaded: my_helper
INFO - 2024-06-20 08:21:06 --> Database Driver Class Initialized
INFO - 2024-06-20 08:21:06 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-20 08:21:06 --> Controller Class Initialized
DEBUG - 2024-06-20 08:21:06 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/login/views/login.php
DEBUG - 2024-06-20 08:21:06 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-06-20 08:21:06 --> Final output sent to browser
DEBUG - 2024-06-20 08:21:06 --> Total execution time: 0.0272
INFO - 2024-06-20 08:21:12 --> Config Class Initialized
INFO - 2024-06-20 08:21:12 --> Hooks Class Initialized
DEBUG - 2024-06-20 08:21:12 --> UTF-8 Support Enabled
INFO - 2024-06-20 08:21:12 --> Utf8 Class Initialized
INFO - 2024-06-20 08:21:12 --> URI Class Initialized
INFO - 2024-06-20 08:21:12 --> Router Class Initialized
INFO - 2024-06-20 08:21:12 --> Output Class Initialized
INFO - 2024-06-20 08:21:12 --> Security Class Initialized
DEBUG - 2024-06-20 08:21:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-20 08:21:12 --> Input Class Initialized
INFO - 2024-06-20 08:21:12 --> Language Class Initialized
INFO - 2024-06-20 08:21:12 --> Language Class Initialized
INFO - 2024-06-20 08:21:12 --> Config Class Initialized
INFO - 2024-06-20 08:21:12 --> Loader Class Initialized
INFO - 2024-06-20 08:21:12 --> Helper loaded: url_helper
INFO - 2024-06-20 08:21:12 --> Helper loaded: file_helper
INFO - 2024-06-20 08:21:12 --> Helper loaded: form_helper
INFO - 2024-06-20 08:21:12 --> Helper loaded: my_helper
INFO - 2024-06-20 08:21:12 --> Database Driver Class Initialized
INFO - 2024-06-20 08:21:12 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-20 08:21:12 --> Controller Class Initialized
INFO - 2024-06-20 08:21:12 --> Helper loaded: cookie_helper
INFO - 2024-06-20 08:21:12 --> Final output sent to browser
DEBUG - 2024-06-20 08:21:12 --> Total execution time: 0.0384
INFO - 2024-06-20 08:21:12 --> Config Class Initialized
INFO - 2024-06-20 08:21:12 --> Hooks Class Initialized
DEBUG - 2024-06-20 08:21:12 --> UTF-8 Support Enabled
INFO - 2024-06-20 08:21:12 --> Utf8 Class Initialized
INFO - 2024-06-20 08:21:12 --> URI Class Initialized
INFO - 2024-06-20 08:21:12 --> Router Class Initialized
INFO - 2024-06-20 08:21:12 --> Output Class Initialized
INFO - 2024-06-20 08:21:12 --> Security Class Initialized
DEBUG - 2024-06-20 08:21:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-20 08:21:12 --> Input Class Initialized
INFO - 2024-06-20 08:21:12 --> Language Class Initialized
INFO - 2024-06-20 08:21:12 --> Language Class Initialized
INFO - 2024-06-20 08:21:12 --> Config Class Initialized
INFO - 2024-06-20 08:21:12 --> Loader Class Initialized
INFO - 2024-06-20 08:21:12 --> Helper loaded: url_helper
INFO - 2024-06-20 08:21:12 --> Helper loaded: file_helper
INFO - 2024-06-20 08:21:12 --> Helper loaded: form_helper
INFO - 2024-06-20 08:21:12 --> Helper loaded: my_helper
INFO - 2024-06-20 08:21:12 --> Database Driver Class Initialized
INFO - 2024-06-20 08:21:12 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-20 08:21:12 --> Controller Class Initialized
DEBUG - 2024-06-20 08:21:12 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/home/views/v_home_guru.php
DEBUG - 2024-06-20 08:21:12 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-06-20 08:21:12 --> Final output sent to browser
DEBUG - 2024-06-20 08:21:12 --> Total execution time: 0.0272
INFO - 2024-06-20 08:21:17 --> Config Class Initialized
INFO - 2024-06-20 08:21:17 --> Hooks Class Initialized
DEBUG - 2024-06-20 08:21:17 --> UTF-8 Support Enabled
INFO - 2024-06-20 08:21:17 --> Utf8 Class Initialized
INFO - 2024-06-20 08:21:17 --> URI Class Initialized
INFO - 2024-06-20 08:21:17 --> Router Class Initialized
INFO - 2024-06-20 08:21:17 --> Output Class Initialized
INFO - 2024-06-20 08:21:17 --> Security Class Initialized
DEBUG - 2024-06-20 08:21:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-20 08:21:17 --> Input Class Initialized
INFO - 2024-06-20 08:21:17 --> Language Class Initialized
INFO - 2024-06-20 08:21:17 --> Language Class Initialized
INFO - 2024-06-20 08:21:17 --> Config Class Initialized
INFO - 2024-06-20 08:21:17 --> Loader Class Initialized
INFO - 2024-06-20 08:21:17 --> Helper loaded: url_helper
INFO - 2024-06-20 08:21:17 --> Helper loaded: file_helper
INFO - 2024-06-20 08:21:17 --> Helper loaded: form_helper
INFO - 2024-06-20 08:21:17 --> Helper loaded: my_helper
INFO - 2024-06-20 08:21:17 --> Database Driver Class Initialized
INFO - 2024-06-20 08:21:17 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-20 08:21:17 --> Controller Class Initialized
DEBUG - 2024-06-20 08:21:17 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/views/list.php
DEBUG - 2024-06-20 08:21:17 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-06-20 08:21:17 --> Final output sent to browser
DEBUG - 2024-06-20 08:21:17 --> Total execution time: 0.0396
INFO - 2024-06-20 08:25:20 --> Config Class Initialized
INFO - 2024-06-20 08:25:20 --> Hooks Class Initialized
DEBUG - 2024-06-20 08:25:20 --> UTF-8 Support Enabled
INFO - 2024-06-20 08:25:20 --> Utf8 Class Initialized
INFO - 2024-06-20 08:25:20 --> URI Class Initialized
INFO - 2024-06-20 08:25:20 --> Router Class Initialized
INFO - 2024-06-20 08:25:20 --> Output Class Initialized
INFO - 2024-06-20 08:25:20 --> Security Class Initialized
DEBUG - 2024-06-20 08:25:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-20 08:25:20 --> Input Class Initialized
INFO - 2024-06-20 08:25:20 --> Language Class Initialized
INFO - 2024-06-20 08:25:20 --> Language Class Initialized
INFO - 2024-06-20 08:25:20 --> Config Class Initialized
INFO - 2024-06-20 08:25:20 --> Loader Class Initialized
INFO - 2024-06-20 08:25:20 --> Helper loaded: url_helper
INFO - 2024-06-20 08:25:20 --> Helper loaded: file_helper
INFO - 2024-06-20 08:25:20 --> Helper loaded: form_helper
INFO - 2024-06-20 08:25:20 --> Helper loaded: my_helper
INFO - 2024-06-20 08:25:20 --> Database Driver Class Initialized
INFO - 2024-06-20 08:25:20 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-20 08:25:20 --> Controller Class Initialized
DEBUG - 2024-06-20 08:25:20 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/views/cetak_ikm.php
INFO - 2024-06-20 08:25:23 --> Config Class Initialized
INFO - 2024-06-20 08:25:23 --> Hooks Class Initialized
DEBUG - 2024-06-20 08:25:23 --> UTF-8 Support Enabled
INFO - 2024-06-20 08:25:23 --> Utf8 Class Initialized
INFO - 2024-06-20 08:25:23 --> URI Class Initialized
INFO - 2024-06-20 08:25:23 --> Router Class Initialized
INFO - 2024-06-20 08:25:23 --> Output Class Initialized
INFO - 2024-06-20 08:25:23 --> Security Class Initialized
DEBUG - 2024-06-20 08:25:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-20 08:25:23 --> Input Class Initialized
INFO - 2024-06-20 08:25:23 --> Language Class Initialized
INFO - 2024-06-20 08:25:23 --> Language Class Initialized
INFO - 2024-06-20 08:25:23 --> Config Class Initialized
INFO - 2024-06-20 08:25:23 --> Loader Class Initialized
INFO - 2024-06-20 08:25:23 --> Helper loaded: url_helper
INFO - 2024-06-20 08:25:23 --> Helper loaded: file_helper
INFO - 2024-06-20 08:25:23 --> Helper loaded: form_helper
INFO - 2024-06-20 08:25:23 --> Helper loaded: my_helper
INFO - 2024-06-20 08:25:23 --> Database Driver Class Initialized
INFO - 2024-06-20 08:25:23 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-20 08:25:23 --> Controller Class Initialized
DEBUG - 2024-06-20 08:25:23 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/views/cetak_ikm.php
INFO - 2024-06-20 08:25:23 --> Final output sent to browser
DEBUG - 2024-06-20 08:25:23 --> Total execution time: 3.3953
INFO - 2024-06-20 08:25:24 --> Final output sent to browser
DEBUG - 2024-06-20 08:25:24 --> Total execution time: 1.7311
INFO - 2024-06-20 08:25:26 --> Config Class Initialized
INFO - 2024-06-20 08:25:26 --> Hooks Class Initialized
DEBUG - 2024-06-20 08:25:26 --> UTF-8 Support Enabled
INFO - 2024-06-20 08:25:26 --> Utf8 Class Initialized
INFO - 2024-06-20 08:25:26 --> URI Class Initialized
INFO - 2024-06-20 08:25:26 --> Router Class Initialized
INFO - 2024-06-20 08:25:26 --> Output Class Initialized
INFO - 2024-06-20 08:25:26 --> Security Class Initialized
DEBUG - 2024-06-20 08:25:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-20 08:25:26 --> Input Class Initialized
INFO - 2024-06-20 08:25:26 --> Language Class Initialized
INFO - 2024-06-20 08:25:26 --> Language Class Initialized
INFO - 2024-06-20 08:25:26 --> Config Class Initialized
INFO - 2024-06-20 08:25:26 --> Loader Class Initialized
INFO - 2024-06-20 08:25:26 --> Helper loaded: url_helper
INFO - 2024-06-20 08:25:26 --> Helper loaded: file_helper
INFO - 2024-06-20 08:25:26 --> Helper loaded: form_helper
INFO - 2024-06-20 08:25:26 --> Helper loaded: my_helper
INFO - 2024-06-20 08:25:26 --> Database Driver Class Initialized
INFO - 2024-06-20 08:25:26 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-20 08:25:26 --> Controller Class Initialized
DEBUG - 2024-06-20 08:25:26 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/views/cetak_ikm.php
INFO - 2024-06-20 08:25:28 --> Final output sent to browser
DEBUG - 2024-06-20 08:25:28 --> Total execution time: 1.5418
INFO - 2024-06-20 08:25:38 --> Config Class Initialized
INFO - 2024-06-20 08:25:38 --> Hooks Class Initialized
DEBUG - 2024-06-20 08:25:38 --> UTF-8 Support Enabled
INFO - 2024-06-20 08:25:38 --> Utf8 Class Initialized
INFO - 2024-06-20 08:25:38 --> URI Class Initialized
INFO - 2024-06-20 08:25:38 --> Router Class Initialized
INFO - 2024-06-20 08:25:38 --> Output Class Initialized
INFO - 2024-06-20 08:25:38 --> Security Class Initialized
DEBUG - 2024-06-20 08:25:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-20 08:25:38 --> Input Class Initialized
INFO - 2024-06-20 08:25:38 --> Language Class Initialized
INFO - 2024-06-20 08:25:38 --> Language Class Initialized
INFO - 2024-06-20 08:25:38 --> Config Class Initialized
INFO - 2024-06-20 08:25:38 --> Loader Class Initialized
INFO - 2024-06-20 08:25:38 --> Helper loaded: url_helper
INFO - 2024-06-20 08:25:38 --> Helper loaded: file_helper
INFO - 2024-06-20 08:25:38 --> Helper loaded: form_helper
INFO - 2024-06-20 08:25:38 --> Helper loaded: my_helper
INFO - 2024-06-20 08:25:38 --> Database Driver Class Initialized
INFO - 2024-06-20 08:25:38 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-20 08:25:38 --> Controller Class Initialized
DEBUG - 2024-06-20 08:25:38 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/views/cetak_ikm.php
INFO - 2024-06-20 08:25:40 --> Final output sent to browser
DEBUG - 2024-06-20 08:25:40 --> Total execution time: 1.8869
INFO - 2024-06-20 08:25:41 --> Config Class Initialized
INFO - 2024-06-20 08:25:41 --> Hooks Class Initialized
DEBUG - 2024-06-20 08:25:41 --> UTF-8 Support Enabled
INFO - 2024-06-20 08:25:41 --> Utf8 Class Initialized
INFO - 2024-06-20 08:25:41 --> URI Class Initialized
INFO - 2024-06-20 08:25:41 --> Router Class Initialized
INFO - 2024-06-20 08:25:41 --> Output Class Initialized
INFO - 2024-06-20 08:25:41 --> Security Class Initialized
DEBUG - 2024-06-20 08:25:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-20 08:25:41 --> Input Class Initialized
INFO - 2024-06-20 08:25:41 --> Language Class Initialized
INFO - 2024-06-20 08:25:41 --> Language Class Initialized
INFO - 2024-06-20 08:25:41 --> Config Class Initialized
INFO - 2024-06-20 08:25:41 --> Loader Class Initialized
INFO - 2024-06-20 08:25:41 --> Helper loaded: url_helper
INFO - 2024-06-20 08:25:41 --> Helper loaded: file_helper
INFO - 2024-06-20 08:25:41 --> Helper loaded: form_helper
INFO - 2024-06-20 08:25:41 --> Helper loaded: my_helper
INFO - 2024-06-20 08:25:41 --> Database Driver Class Initialized
INFO - 2024-06-20 08:25:41 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-20 08:25:41 --> Controller Class Initialized
DEBUG - 2024-06-20 08:25:41 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/views/cetak_ikm.php
INFO - 2024-06-20 08:25:42 --> Final output sent to browser
DEBUG - 2024-06-20 08:25:42 --> Total execution time: 1.4977
INFO - 2024-06-20 08:25:45 --> Config Class Initialized
INFO - 2024-06-20 08:25:45 --> Hooks Class Initialized
DEBUG - 2024-06-20 08:25:45 --> UTF-8 Support Enabled
INFO - 2024-06-20 08:25:45 --> Utf8 Class Initialized
INFO - 2024-06-20 08:25:45 --> URI Class Initialized
INFO - 2024-06-20 08:25:45 --> Router Class Initialized
INFO - 2024-06-20 08:25:45 --> Output Class Initialized
INFO - 2024-06-20 08:25:45 --> Security Class Initialized
DEBUG - 2024-06-20 08:25:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-20 08:25:45 --> Input Class Initialized
INFO - 2024-06-20 08:25:45 --> Language Class Initialized
INFO - 2024-06-20 08:25:45 --> Language Class Initialized
INFO - 2024-06-20 08:25:45 --> Config Class Initialized
INFO - 2024-06-20 08:25:45 --> Loader Class Initialized
INFO - 2024-06-20 08:25:45 --> Helper loaded: url_helper
INFO - 2024-06-20 08:25:45 --> Helper loaded: file_helper
INFO - 2024-06-20 08:25:45 --> Helper loaded: form_helper
INFO - 2024-06-20 08:25:45 --> Helper loaded: my_helper
INFO - 2024-06-20 08:25:45 --> Database Driver Class Initialized
INFO - 2024-06-20 08:25:45 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-20 08:25:45 --> Controller Class Initialized
DEBUG - 2024-06-20 08:25:45 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/views/cetak_ikm.php
INFO - 2024-06-20 08:25:46 --> Final output sent to browser
DEBUG - 2024-06-20 08:25:46 --> Total execution time: 1.4687
INFO - 2024-06-20 08:25:47 --> Config Class Initialized
INFO - 2024-06-20 08:25:47 --> Hooks Class Initialized
DEBUG - 2024-06-20 08:25:47 --> UTF-8 Support Enabled
INFO - 2024-06-20 08:25:47 --> Utf8 Class Initialized
INFO - 2024-06-20 08:25:47 --> URI Class Initialized
INFO - 2024-06-20 08:25:47 --> Router Class Initialized
INFO - 2024-06-20 08:25:47 --> Output Class Initialized
INFO - 2024-06-20 08:25:47 --> Security Class Initialized
DEBUG - 2024-06-20 08:25:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-20 08:25:47 --> Input Class Initialized
INFO - 2024-06-20 08:25:47 --> Language Class Initialized
INFO - 2024-06-20 08:25:47 --> Language Class Initialized
INFO - 2024-06-20 08:25:47 --> Config Class Initialized
INFO - 2024-06-20 08:25:47 --> Loader Class Initialized
INFO - 2024-06-20 08:25:47 --> Helper loaded: url_helper
INFO - 2024-06-20 08:25:47 --> Helper loaded: file_helper
INFO - 2024-06-20 08:25:47 --> Helper loaded: form_helper
INFO - 2024-06-20 08:25:47 --> Helper loaded: my_helper
INFO - 2024-06-20 08:25:47 --> Database Driver Class Initialized
INFO - 2024-06-20 08:25:47 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-20 08:25:47 --> Controller Class Initialized
DEBUG - 2024-06-20 08:25:47 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/views/cetak_ikm.php
INFO - 2024-06-20 08:25:49 --> Final output sent to browser
DEBUG - 2024-06-20 08:25:49 --> Total execution time: 1.4257
INFO - 2024-06-20 08:25:51 --> Config Class Initialized
INFO - 2024-06-20 08:25:51 --> Hooks Class Initialized
DEBUG - 2024-06-20 08:25:51 --> UTF-8 Support Enabled
INFO - 2024-06-20 08:25:51 --> Utf8 Class Initialized
INFO - 2024-06-20 08:25:51 --> URI Class Initialized
INFO - 2024-06-20 08:25:51 --> Router Class Initialized
INFO - 2024-06-20 08:25:51 --> Output Class Initialized
INFO - 2024-06-20 08:25:51 --> Security Class Initialized
DEBUG - 2024-06-20 08:25:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-20 08:25:51 --> Input Class Initialized
INFO - 2024-06-20 08:25:51 --> Language Class Initialized
INFO - 2024-06-20 08:25:51 --> Language Class Initialized
INFO - 2024-06-20 08:25:51 --> Config Class Initialized
INFO - 2024-06-20 08:25:51 --> Loader Class Initialized
INFO - 2024-06-20 08:25:51 --> Helper loaded: url_helper
INFO - 2024-06-20 08:25:51 --> Helper loaded: file_helper
INFO - 2024-06-20 08:25:51 --> Helper loaded: form_helper
INFO - 2024-06-20 08:25:51 --> Helper loaded: my_helper
INFO - 2024-06-20 08:25:51 --> Database Driver Class Initialized
INFO - 2024-06-20 08:25:51 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-20 08:25:51 --> Controller Class Initialized
DEBUG - 2024-06-20 08:25:51 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/views/cetak_ikm.php
INFO - 2024-06-20 08:25:54 --> Config Class Initialized
INFO - 2024-06-20 08:25:54 --> Hooks Class Initialized
DEBUG - 2024-06-20 08:25:54 --> UTF-8 Support Enabled
INFO - 2024-06-20 08:25:54 --> Utf8 Class Initialized
INFO - 2024-06-20 08:25:54 --> URI Class Initialized
INFO - 2024-06-20 08:25:54 --> Router Class Initialized
INFO - 2024-06-20 08:25:54 --> Output Class Initialized
INFO - 2024-06-20 08:25:54 --> Security Class Initialized
DEBUG - 2024-06-20 08:25:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-20 08:25:54 --> Input Class Initialized
INFO - 2024-06-20 08:25:54 --> Language Class Initialized
INFO - 2024-06-20 08:25:54 --> Language Class Initialized
INFO - 2024-06-20 08:25:54 --> Config Class Initialized
INFO - 2024-06-20 08:25:54 --> Loader Class Initialized
INFO - 2024-06-20 08:25:54 --> Final output sent to browser
DEBUG - 2024-06-20 08:25:54 --> Total execution time: 3.1936
INFO - 2024-06-20 08:25:54 --> Helper loaded: url_helper
INFO - 2024-06-20 08:25:54 --> Helper loaded: file_helper
INFO - 2024-06-20 08:25:54 --> Helper loaded: form_helper
INFO - 2024-06-20 08:25:54 --> Helper loaded: my_helper
INFO - 2024-06-20 08:25:54 --> Database Driver Class Initialized
INFO - 2024-06-20 08:25:54 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-20 08:25:54 --> Controller Class Initialized
DEBUG - 2024-06-20 08:25:54 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/views/cetak_ikm.php
INFO - 2024-06-20 08:25:56 --> Final output sent to browser
DEBUG - 2024-06-20 08:25:56 --> Total execution time: 1.9947
INFO - 2024-06-20 08:25:57 --> Config Class Initialized
INFO - 2024-06-20 08:25:57 --> Hooks Class Initialized
DEBUG - 2024-06-20 08:25:57 --> UTF-8 Support Enabled
INFO - 2024-06-20 08:25:57 --> Utf8 Class Initialized
INFO - 2024-06-20 08:25:57 --> URI Class Initialized
INFO - 2024-06-20 08:25:57 --> Router Class Initialized
INFO - 2024-06-20 08:25:57 --> Output Class Initialized
INFO - 2024-06-20 08:25:57 --> Security Class Initialized
DEBUG - 2024-06-20 08:25:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-20 08:25:57 --> Input Class Initialized
INFO - 2024-06-20 08:25:57 --> Language Class Initialized
INFO - 2024-06-20 08:25:57 --> Language Class Initialized
INFO - 2024-06-20 08:25:57 --> Config Class Initialized
INFO - 2024-06-20 08:25:57 --> Loader Class Initialized
INFO - 2024-06-20 08:25:57 --> Helper loaded: url_helper
INFO - 2024-06-20 08:25:57 --> Helper loaded: file_helper
INFO - 2024-06-20 08:25:57 --> Helper loaded: form_helper
INFO - 2024-06-20 08:25:57 --> Helper loaded: my_helper
INFO - 2024-06-20 08:25:57 --> Database Driver Class Initialized
INFO - 2024-06-20 08:25:57 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-20 08:25:57 --> Controller Class Initialized
DEBUG - 2024-06-20 08:25:57 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/views/cetak_ikm.php
INFO - 2024-06-20 08:25:58 --> Final output sent to browser
DEBUG - 2024-06-20 08:25:58 --> Total execution time: 1.4131
INFO - 2024-06-20 08:26:00 --> Config Class Initialized
INFO - 2024-06-20 08:26:00 --> Hooks Class Initialized
DEBUG - 2024-06-20 08:26:00 --> UTF-8 Support Enabled
INFO - 2024-06-20 08:26:00 --> Utf8 Class Initialized
INFO - 2024-06-20 08:26:00 --> URI Class Initialized
INFO - 2024-06-20 08:26:00 --> Router Class Initialized
INFO - 2024-06-20 08:26:00 --> Output Class Initialized
INFO - 2024-06-20 08:26:00 --> Security Class Initialized
DEBUG - 2024-06-20 08:26:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-20 08:26:00 --> Input Class Initialized
INFO - 2024-06-20 08:26:00 --> Language Class Initialized
INFO - 2024-06-20 08:26:00 --> Language Class Initialized
INFO - 2024-06-20 08:26:00 --> Config Class Initialized
INFO - 2024-06-20 08:26:00 --> Loader Class Initialized
INFO - 2024-06-20 08:26:00 --> Helper loaded: url_helper
INFO - 2024-06-20 08:26:00 --> Helper loaded: file_helper
INFO - 2024-06-20 08:26:00 --> Helper loaded: form_helper
INFO - 2024-06-20 08:26:00 --> Helper loaded: my_helper
INFO - 2024-06-20 08:26:00 --> Database Driver Class Initialized
INFO - 2024-06-20 08:26:00 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-20 08:26:00 --> Controller Class Initialized
DEBUG - 2024-06-20 08:26:00 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/views/cetak_ikm.php
INFO - 2024-06-20 08:26:03 --> Final output sent to browser
DEBUG - 2024-06-20 08:26:03 --> Total execution time: 2.4034
INFO - 2024-06-20 08:27:41 --> Config Class Initialized
INFO - 2024-06-20 08:27:41 --> Hooks Class Initialized
DEBUG - 2024-06-20 08:27:41 --> UTF-8 Support Enabled
INFO - 2024-06-20 08:27:41 --> Utf8 Class Initialized
INFO - 2024-06-20 08:27:41 --> URI Class Initialized
INFO - 2024-06-20 08:27:41 --> Router Class Initialized
INFO - 2024-06-20 08:27:41 --> Output Class Initialized
INFO - 2024-06-20 08:27:41 --> Security Class Initialized
DEBUG - 2024-06-20 08:27:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-20 08:27:41 --> Input Class Initialized
INFO - 2024-06-20 08:27:41 --> Language Class Initialized
INFO - 2024-06-20 08:27:41 --> Language Class Initialized
INFO - 2024-06-20 08:27:41 --> Config Class Initialized
INFO - 2024-06-20 08:27:41 --> Loader Class Initialized
INFO - 2024-06-20 08:27:41 --> Helper loaded: url_helper
INFO - 2024-06-20 08:27:41 --> Helper loaded: file_helper
INFO - 2024-06-20 08:27:41 --> Helper loaded: form_helper
INFO - 2024-06-20 08:27:41 --> Helper loaded: my_helper
INFO - 2024-06-20 08:27:41 --> Database Driver Class Initialized
INFO - 2024-06-20 08:27:41 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-20 08:27:41 --> Controller Class Initialized
ERROR - 2024-06-20 08:27:42 --> Severity: Notice --> Undefined index: projek /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1837
ERROR - 2024-06-20 08:27:42 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2024-06-20 08:27:42 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2024-06-20 08:27:42 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2024-06-20 08:27:42 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2024-06-20 08:27:42 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2024-06-20 08:27:42 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2024-06-20 08:27:42 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2024-06-20 08:27:42 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2024-06-20 08:27:42 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2024-06-20 08:27:42 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2024-06-20 08:27:42 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2024-06-20 08:27:42 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2024-06-20 08:27:42 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2024-06-20 08:27:42 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2024-06-20 08:27:42 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2024-06-20 08:27:42 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2024-06-20 08:27:42 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2024-06-20 08:27:42 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2024-06-20 08:27:42 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2024-06-20 08:27:42 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2024-06-20 08:27:42 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2024-06-20 08:27:42 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2024-06-20 08:27:42 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2024-06-20 08:27:42 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2024-06-20 08:27:42 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2024-06-20 08:27:42 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2024-06-20 08:27:42 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2024-06-20 08:27:42 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2024-06-20 08:27:42 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2024-06-20 08:27:42 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2024-06-20 08:27:42 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2024-06-20 08:27:42 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2024-06-20 08:27:42 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2024-06-20 08:27:42 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2024-06-20 08:27:42 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2024-06-20 08:27:42 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2024-06-20 08:27:42 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2024-06-20 08:27:42 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2024-06-20 08:27:42 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
DEBUG - 2024-06-20 08:27:42 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/views/cetak_projek.php
INFO - 2024-06-20 08:27:44 --> Config Class Initialized
INFO - 2024-06-20 08:27:44 --> Hooks Class Initialized
DEBUG - 2024-06-20 08:27:44 --> UTF-8 Support Enabled
INFO - 2024-06-20 08:27:44 --> Utf8 Class Initialized
INFO - 2024-06-20 08:27:44 --> URI Class Initialized
INFO - 2024-06-20 08:27:44 --> Router Class Initialized
INFO - 2024-06-20 08:27:44 --> Output Class Initialized
INFO - 2024-06-20 08:27:44 --> Security Class Initialized
DEBUG - 2024-06-20 08:27:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-20 08:27:44 --> Input Class Initialized
INFO - 2024-06-20 08:27:44 --> Language Class Initialized
INFO - 2024-06-20 08:27:44 --> Language Class Initialized
INFO - 2024-06-20 08:27:44 --> Config Class Initialized
INFO - 2024-06-20 08:27:44 --> Loader Class Initialized
INFO - 2024-06-20 08:27:44 --> Helper loaded: url_helper
INFO - 2024-06-20 08:27:44 --> Helper loaded: file_helper
INFO - 2024-06-20 08:27:44 --> Helper loaded: form_helper
INFO - 2024-06-20 08:27:44 --> Helper loaded: my_helper
INFO - 2024-06-20 08:27:44 --> Database Driver Class Initialized
INFO - 2024-06-20 08:27:46 --> Final output sent to browser
DEBUG - 2024-06-20 08:27:46 --> Total execution time: 4.7314
INFO - 2024-06-20 08:27:46 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-20 08:27:46 --> Controller Class Initialized
ERROR - 2024-06-20 08:27:46 --> Severity: Notice --> Undefined index: projek /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1837
ERROR - 2024-06-20 08:27:46 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2024-06-20 08:27:46 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2024-06-20 08:27:46 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2024-06-20 08:27:46 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2024-06-20 08:27:46 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2024-06-20 08:27:46 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2024-06-20 08:27:46 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2024-06-20 08:27:46 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2024-06-20 08:27:46 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2024-06-20 08:27:46 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2024-06-20 08:27:46 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2024-06-20 08:27:46 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2024-06-20 08:27:46 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2024-06-20 08:27:46 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2024-06-20 08:27:46 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2024-06-20 08:27:46 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2024-06-20 08:27:46 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2024-06-20 08:27:46 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2024-06-20 08:27:46 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2024-06-20 08:27:46 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2024-06-20 08:27:46 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2024-06-20 08:27:46 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2024-06-20 08:27:46 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2024-06-20 08:27:46 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2024-06-20 08:27:46 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2024-06-20 08:27:46 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2024-06-20 08:27:46 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2024-06-20 08:27:46 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2024-06-20 08:27:46 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2024-06-20 08:27:46 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2024-06-20 08:27:46 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2024-06-20 08:27:46 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2024-06-20 08:27:46 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2024-06-20 08:27:46 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2024-06-20 08:27:46 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2024-06-20 08:27:46 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2024-06-20 08:27:46 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2024-06-20 08:27:46 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2024-06-20 08:27:46 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
DEBUG - 2024-06-20 08:27:46 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/views/cetak_projek.php
INFO - 2024-06-20 08:27:46 --> Config Class Initialized
INFO - 2024-06-20 08:27:46 --> Hooks Class Initialized
DEBUG - 2024-06-20 08:27:46 --> UTF-8 Support Enabled
INFO - 2024-06-20 08:27:46 --> Utf8 Class Initialized
INFO - 2024-06-20 08:27:46 --> URI Class Initialized
INFO - 2024-06-20 08:27:46 --> Router Class Initialized
INFO - 2024-06-20 08:27:46 --> Output Class Initialized
INFO - 2024-06-20 08:27:46 --> Security Class Initialized
DEBUG - 2024-06-20 08:27:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-20 08:27:46 --> Input Class Initialized
INFO - 2024-06-20 08:27:46 --> Language Class Initialized
INFO - 2024-06-20 08:27:46 --> Language Class Initialized
INFO - 2024-06-20 08:27:46 --> Config Class Initialized
INFO - 2024-06-20 08:27:46 --> Loader Class Initialized
INFO - 2024-06-20 08:27:46 --> Helper loaded: url_helper
INFO - 2024-06-20 08:27:46 --> Helper loaded: file_helper
INFO - 2024-06-20 08:27:46 --> Helper loaded: form_helper
INFO - 2024-06-20 08:27:46 --> Helper loaded: my_helper
INFO - 2024-06-20 08:27:46 --> Database Driver Class Initialized
INFO - 2024-06-20 08:27:49 --> Config Class Initialized
INFO - 2024-06-20 08:27:49 --> Hooks Class Initialized
DEBUG - 2024-06-20 08:27:49 --> UTF-8 Support Enabled
INFO - 2024-06-20 08:27:49 --> Utf8 Class Initialized
INFO - 2024-06-20 08:27:49 --> URI Class Initialized
INFO - 2024-06-20 08:27:49 --> Router Class Initialized
INFO - 2024-06-20 08:27:49 --> Output Class Initialized
INFO - 2024-06-20 08:27:49 --> Security Class Initialized
DEBUG - 2024-06-20 08:27:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-20 08:27:49 --> Input Class Initialized
INFO - 2024-06-20 08:27:49 --> Language Class Initialized
INFO - 2024-06-20 08:27:49 --> Language Class Initialized
INFO - 2024-06-20 08:27:49 --> Config Class Initialized
INFO - 2024-06-20 08:27:49 --> Loader Class Initialized
INFO - 2024-06-20 08:27:49 --> Helper loaded: url_helper
INFO - 2024-06-20 08:27:49 --> Helper loaded: file_helper
INFO - 2024-06-20 08:27:49 --> Helper loaded: form_helper
INFO - 2024-06-20 08:27:49 --> Helper loaded: my_helper
INFO - 2024-06-20 08:27:49 --> Database Driver Class Initialized
INFO - 2024-06-20 08:27:51 --> Final output sent to browser
DEBUG - 2024-06-20 08:27:51 --> Total execution time: 7.3967
INFO - 2024-06-20 08:27:51 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-20 08:27:51 --> Controller Class Initialized
ERROR - 2024-06-20 08:27:51 --> Severity: Notice --> Undefined index: projek /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1837
ERROR - 2024-06-20 08:27:51 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2024-06-20 08:27:51 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2024-06-20 08:27:51 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2024-06-20 08:27:51 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2024-06-20 08:27:51 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2024-06-20 08:27:51 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2024-06-20 08:27:51 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2024-06-20 08:27:51 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2024-06-20 08:27:51 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2024-06-20 08:27:51 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2024-06-20 08:27:51 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2024-06-20 08:27:51 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2024-06-20 08:27:51 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2024-06-20 08:27:51 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2024-06-20 08:27:51 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2024-06-20 08:27:51 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2024-06-20 08:27:51 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2024-06-20 08:27:51 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2024-06-20 08:27:51 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2024-06-20 08:27:51 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2024-06-20 08:27:51 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2024-06-20 08:27:51 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2024-06-20 08:27:51 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2024-06-20 08:27:51 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2024-06-20 08:27:51 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2024-06-20 08:27:51 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2024-06-20 08:27:51 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2024-06-20 08:27:51 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2024-06-20 08:27:51 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2024-06-20 08:27:51 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2024-06-20 08:27:51 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2024-06-20 08:27:51 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2024-06-20 08:27:51 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2024-06-20 08:27:51 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2024-06-20 08:27:51 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2024-06-20 08:27:51 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2024-06-20 08:27:51 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2024-06-20 08:27:51 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2024-06-20 08:27:51 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
DEBUG - 2024-06-20 08:27:51 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/views/cetak_projek.php
INFO - 2024-06-20 08:27:53 --> Config Class Initialized
INFO - 2024-06-20 08:27:53 --> Hooks Class Initialized
DEBUG - 2024-06-20 08:27:53 --> UTF-8 Support Enabled
INFO - 2024-06-20 08:27:53 --> Utf8 Class Initialized
INFO - 2024-06-20 08:27:53 --> URI Class Initialized
INFO - 2024-06-20 08:27:53 --> Router Class Initialized
INFO - 2024-06-20 08:27:53 --> Output Class Initialized
INFO - 2024-06-20 08:27:53 --> Security Class Initialized
DEBUG - 2024-06-20 08:27:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-20 08:27:53 --> Input Class Initialized
INFO - 2024-06-20 08:27:53 --> Language Class Initialized
INFO - 2024-06-20 08:27:53 --> Language Class Initialized
INFO - 2024-06-20 08:27:53 --> Config Class Initialized
INFO - 2024-06-20 08:27:53 --> Loader Class Initialized
INFO - 2024-06-20 08:27:53 --> Helper loaded: url_helper
INFO - 2024-06-20 08:27:53 --> Helper loaded: file_helper
INFO - 2024-06-20 08:27:53 --> Helper loaded: form_helper
INFO - 2024-06-20 08:27:53 --> Helper loaded: my_helper
INFO - 2024-06-20 08:27:53 --> Database Driver Class Initialized
INFO - 2024-06-20 08:27:56 --> Final output sent to browser
DEBUG - 2024-06-20 08:27:56 --> Total execution time: 9.8672
INFO - 2024-06-20 08:27:56 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-20 08:27:56 --> Controller Class Initialized
ERROR - 2024-06-20 08:27:56 --> Severity: Notice --> Undefined index: projek /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1837
ERROR - 2024-06-20 08:27:56 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2024-06-20 08:27:56 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2024-06-20 08:27:56 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2024-06-20 08:27:56 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2024-06-20 08:27:56 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2024-06-20 08:27:56 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2024-06-20 08:27:56 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2024-06-20 08:27:56 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2024-06-20 08:27:56 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2024-06-20 08:27:56 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2024-06-20 08:27:56 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2024-06-20 08:27:56 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2024-06-20 08:27:56 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2024-06-20 08:27:56 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2024-06-20 08:27:56 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2024-06-20 08:27:56 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2024-06-20 08:27:56 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2024-06-20 08:27:56 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2024-06-20 08:27:56 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2024-06-20 08:27:56 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2024-06-20 08:27:56 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2024-06-20 08:27:56 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2024-06-20 08:27:56 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2024-06-20 08:27:56 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2024-06-20 08:27:56 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2024-06-20 08:27:56 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2024-06-20 08:27:56 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2024-06-20 08:27:56 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2024-06-20 08:27:56 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2024-06-20 08:27:56 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2024-06-20 08:27:56 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2024-06-20 08:27:56 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2024-06-20 08:27:56 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2024-06-20 08:27:56 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2024-06-20 08:27:56 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2024-06-20 08:27:56 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2024-06-20 08:27:56 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2024-06-20 08:27:56 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2024-06-20 08:27:56 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
DEBUG - 2024-06-20 08:27:56 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/views/cetak_projek.php
INFO - 2024-06-20 08:27:57 --> Config Class Initialized
INFO - 2024-06-20 08:27:57 --> Hooks Class Initialized
DEBUG - 2024-06-20 08:27:57 --> UTF-8 Support Enabled
INFO - 2024-06-20 08:27:57 --> Utf8 Class Initialized
INFO - 2024-06-20 08:27:57 --> URI Class Initialized
INFO - 2024-06-20 08:27:57 --> Router Class Initialized
INFO - 2024-06-20 08:27:57 --> Output Class Initialized
INFO - 2024-06-20 08:27:57 --> Security Class Initialized
DEBUG - 2024-06-20 08:27:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-20 08:27:57 --> Input Class Initialized
INFO - 2024-06-20 08:27:57 --> Language Class Initialized
INFO - 2024-06-20 08:27:57 --> Language Class Initialized
INFO - 2024-06-20 08:27:57 --> Config Class Initialized
INFO - 2024-06-20 08:27:57 --> Loader Class Initialized
INFO - 2024-06-20 08:27:57 --> Helper loaded: url_helper
INFO - 2024-06-20 08:27:57 --> Helper loaded: file_helper
INFO - 2024-06-20 08:27:57 --> Helper loaded: form_helper
INFO - 2024-06-20 08:27:57 --> Helper loaded: my_helper
INFO - 2024-06-20 08:27:57 --> Database Driver Class Initialized
INFO - 2024-06-20 08:28:02 --> Final output sent to browser
DEBUG - 2024-06-20 08:28:02 --> Total execution time: 12.6169
INFO - 2024-06-20 08:28:02 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-20 08:28:02 --> Controller Class Initialized
ERROR - 2024-06-20 08:28:02 --> Severity: Notice --> Undefined index: projek /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1837
ERROR - 2024-06-20 08:28:02 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2024-06-20 08:28:02 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2024-06-20 08:28:02 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2024-06-20 08:28:02 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2024-06-20 08:28:02 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2024-06-20 08:28:02 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2024-06-20 08:28:02 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2024-06-20 08:28:02 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2024-06-20 08:28:02 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2024-06-20 08:28:02 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2024-06-20 08:28:02 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2024-06-20 08:28:02 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2024-06-20 08:28:02 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2024-06-20 08:28:02 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2024-06-20 08:28:02 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2024-06-20 08:28:02 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2024-06-20 08:28:02 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2024-06-20 08:28:02 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2024-06-20 08:28:02 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2024-06-20 08:28:02 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2024-06-20 08:28:02 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2024-06-20 08:28:02 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2024-06-20 08:28:02 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2024-06-20 08:28:02 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2024-06-20 08:28:02 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2024-06-20 08:28:02 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2024-06-20 08:28:02 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2024-06-20 08:28:02 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2024-06-20 08:28:02 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2024-06-20 08:28:02 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2024-06-20 08:28:02 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2024-06-20 08:28:02 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2024-06-20 08:28:02 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2024-06-20 08:28:02 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2024-06-20 08:28:02 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2024-06-20 08:28:02 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2024-06-20 08:28:02 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2024-06-20 08:28:02 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2024-06-20 08:28:02 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
DEBUG - 2024-06-20 08:28:02 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/views/cetak_projek.php
INFO - 2024-06-20 08:28:03 --> Config Class Initialized
INFO - 2024-06-20 08:28:03 --> Hooks Class Initialized
DEBUG - 2024-06-20 08:28:03 --> UTF-8 Support Enabled
INFO - 2024-06-20 08:28:03 --> Utf8 Class Initialized
INFO - 2024-06-20 08:28:03 --> URI Class Initialized
INFO - 2024-06-20 08:28:03 --> Router Class Initialized
INFO - 2024-06-20 08:28:03 --> Output Class Initialized
INFO - 2024-06-20 08:28:03 --> Security Class Initialized
DEBUG - 2024-06-20 08:28:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-20 08:28:03 --> Input Class Initialized
INFO - 2024-06-20 08:28:03 --> Language Class Initialized
INFO - 2024-06-20 08:28:03 --> Language Class Initialized
INFO - 2024-06-20 08:28:03 --> Config Class Initialized
INFO - 2024-06-20 08:28:03 --> Loader Class Initialized
INFO - 2024-06-20 08:28:03 --> Helper loaded: url_helper
INFO - 2024-06-20 08:28:03 --> Helper loaded: file_helper
INFO - 2024-06-20 08:28:03 --> Helper loaded: form_helper
INFO - 2024-06-20 08:28:03 --> Helper loaded: my_helper
INFO - 2024-06-20 08:28:03 --> Database Driver Class Initialized
INFO - 2024-06-20 08:28:06 --> Config Class Initialized
INFO - 2024-06-20 08:28:06 --> Hooks Class Initialized
DEBUG - 2024-06-20 08:28:06 --> UTF-8 Support Enabled
INFO - 2024-06-20 08:28:06 --> Utf8 Class Initialized
INFO - 2024-06-20 08:28:06 --> URI Class Initialized
INFO - 2024-06-20 08:28:06 --> Router Class Initialized
INFO - 2024-06-20 08:28:06 --> Output Class Initialized
INFO - 2024-06-20 08:28:06 --> Security Class Initialized
DEBUG - 2024-06-20 08:28:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-20 08:28:06 --> Input Class Initialized
INFO - 2024-06-20 08:28:06 --> Language Class Initialized
INFO - 2024-06-20 08:28:06 --> Language Class Initialized
INFO - 2024-06-20 08:28:06 --> Config Class Initialized
INFO - 2024-06-20 08:28:06 --> Loader Class Initialized
INFO - 2024-06-20 08:28:06 --> Helper loaded: url_helper
INFO - 2024-06-20 08:28:06 --> Helper loaded: file_helper
INFO - 2024-06-20 08:28:06 --> Helper loaded: form_helper
INFO - 2024-06-20 08:28:06 --> Helper loaded: my_helper
INFO - 2024-06-20 08:28:06 --> Database Driver Class Initialized
INFO - 2024-06-20 08:28:07 --> Final output sent to browser
DEBUG - 2024-06-20 08:28:07 --> Total execution time: 14.3121
INFO - 2024-06-20 08:28:07 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-20 08:28:07 --> Controller Class Initialized
ERROR - 2024-06-20 08:28:07 --> Severity: Notice --> Undefined index: projek /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1837
ERROR - 2024-06-20 08:28:07 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2024-06-20 08:28:07 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2024-06-20 08:28:07 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2024-06-20 08:28:07 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2024-06-20 08:28:07 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2024-06-20 08:28:07 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2024-06-20 08:28:07 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2024-06-20 08:28:07 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2024-06-20 08:28:07 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2024-06-20 08:28:07 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2024-06-20 08:28:07 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2024-06-20 08:28:07 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2024-06-20 08:28:07 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2024-06-20 08:28:07 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2024-06-20 08:28:07 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2024-06-20 08:28:07 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2024-06-20 08:28:07 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2024-06-20 08:28:07 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2024-06-20 08:28:07 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2024-06-20 08:28:07 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2024-06-20 08:28:07 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2024-06-20 08:28:07 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2024-06-20 08:28:07 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2024-06-20 08:28:07 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2024-06-20 08:28:07 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2024-06-20 08:28:07 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2024-06-20 08:28:07 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2024-06-20 08:28:07 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2024-06-20 08:28:07 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2024-06-20 08:28:07 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2024-06-20 08:28:07 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2024-06-20 08:28:07 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2024-06-20 08:28:07 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2024-06-20 08:28:07 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2024-06-20 08:28:07 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2024-06-20 08:28:07 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2024-06-20 08:28:07 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2024-06-20 08:28:07 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2024-06-20 08:28:07 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
DEBUG - 2024-06-20 08:28:07 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/views/cetak_projek.php
INFO - 2024-06-20 08:28:12 --> Final output sent to browser
DEBUG - 2024-06-20 08:28:12 --> Total execution time: 15.4189
INFO - 2024-06-20 08:28:12 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-20 08:28:12 --> Controller Class Initialized
ERROR - 2024-06-20 08:28:12 --> Severity: Notice --> Undefined index: projek /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1837
ERROR - 2024-06-20 08:28:12 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2024-06-20 08:28:12 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2024-06-20 08:28:12 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2024-06-20 08:28:12 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2024-06-20 08:28:12 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2024-06-20 08:28:12 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2024-06-20 08:28:12 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2024-06-20 08:28:12 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2024-06-20 08:28:12 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2024-06-20 08:28:12 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2024-06-20 08:28:12 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2024-06-20 08:28:12 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2024-06-20 08:28:12 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2024-06-20 08:28:12 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2024-06-20 08:28:12 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2024-06-20 08:28:12 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2024-06-20 08:28:12 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2024-06-20 08:28:12 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2024-06-20 08:28:12 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2024-06-20 08:28:12 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2024-06-20 08:28:12 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2024-06-20 08:28:12 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2024-06-20 08:28:12 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2024-06-20 08:28:12 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2024-06-20 08:28:12 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2024-06-20 08:28:12 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2024-06-20 08:28:12 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2024-06-20 08:28:12 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2024-06-20 08:28:12 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2024-06-20 08:28:12 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2024-06-20 08:28:12 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2024-06-20 08:28:12 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2024-06-20 08:28:12 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2024-06-20 08:28:12 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2024-06-20 08:28:12 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2024-06-20 08:28:12 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2024-06-20 08:28:12 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2024-06-20 08:28:12 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2024-06-20 08:28:12 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
DEBUG - 2024-06-20 08:28:12 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/views/cetak_projek.php
INFO - 2024-06-20 08:28:17 --> Final output sent to browser
DEBUG - 2024-06-20 08:28:17 --> Total execution time: 14.7632
INFO - 2024-06-20 08:28:17 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-20 08:28:17 --> Controller Class Initialized
ERROR - 2024-06-20 08:28:17 --> Severity: Notice --> Undefined index: projek /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1837
ERROR - 2024-06-20 08:28:17 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2024-06-20 08:28:17 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2024-06-20 08:28:17 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2024-06-20 08:28:17 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2024-06-20 08:28:17 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2024-06-20 08:28:17 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2024-06-20 08:28:17 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2024-06-20 08:28:17 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2024-06-20 08:28:17 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2024-06-20 08:28:17 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2024-06-20 08:28:17 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2024-06-20 08:28:17 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2024-06-20 08:28:17 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2024-06-20 08:28:17 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2024-06-20 08:28:17 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2024-06-20 08:28:17 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2024-06-20 08:28:17 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2024-06-20 08:28:17 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2024-06-20 08:28:17 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2024-06-20 08:28:17 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2024-06-20 08:28:17 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2024-06-20 08:28:17 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2024-06-20 08:28:17 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2024-06-20 08:28:17 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2024-06-20 08:28:17 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2024-06-20 08:28:17 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2024-06-20 08:28:17 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2024-06-20 08:28:17 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2024-06-20 08:28:17 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2024-06-20 08:28:17 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2024-06-20 08:28:17 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2024-06-20 08:28:17 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2024-06-20 08:28:17 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2024-06-20 08:28:17 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2024-06-20 08:28:17 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2024-06-20 08:28:17 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2024-06-20 08:28:17 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2024-06-20 08:28:17 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2024-06-20 08:28:17 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
DEBUG - 2024-06-20 08:28:17 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/views/cetak_projek.php
INFO - 2024-06-20 08:28:22 --> Config Class Initialized
INFO - 2024-06-20 08:28:22 --> Hooks Class Initialized
DEBUG - 2024-06-20 08:28:22 --> UTF-8 Support Enabled
INFO - 2024-06-20 08:28:22 --> Utf8 Class Initialized
INFO - 2024-06-20 08:28:22 --> URI Class Initialized
INFO - 2024-06-20 08:28:22 --> Router Class Initialized
INFO - 2024-06-20 08:28:22 --> Output Class Initialized
INFO - 2024-06-20 08:28:22 --> Security Class Initialized
DEBUG - 2024-06-20 08:28:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-20 08:28:22 --> Input Class Initialized
INFO - 2024-06-20 08:28:22 --> Language Class Initialized
INFO - 2024-06-20 08:28:22 --> Language Class Initialized
INFO - 2024-06-20 08:28:22 --> Config Class Initialized
INFO - 2024-06-20 08:28:22 --> Loader Class Initialized
INFO - 2024-06-20 08:28:22 --> Helper loaded: url_helper
INFO - 2024-06-20 08:28:22 --> Helper loaded: file_helper
INFO - 2024-06-20 08:28:22 --> Helper loaded: form_helper
INFO - 2024-06-20 08:28:22 --> Helper loaded: my_helper
INFO - 2024-06-20 08:28:22 --> Database Driver Class Initialized
INFO - 2024-06-20 08:28:23 --> Final output sent to browser
DEBUG - 2024-06-20 08:28:23 --> Total execution time: 16.3620
INFO - 2024-06-20 08:28:23 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-20 08:28:23 --> Controller Class Initialized
ERROR - 2024-06-20 08:28:23 --> Severity: Notice --> Undefined index: projek /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1837
ERROR - 2024-06-20 08:28:23 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2024-06-20 08:28:23 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2024-06-20 08:28:23 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2024-06-20 08:28:23 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2024-06-20 08:28:23 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2024-06-20 08:28:23 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2024-06-20 08:28:23 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2024-06-20 08:28:23 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2024-06-20 08:28:23 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2024-06-20 08:28:23 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2024-06-20 08:28:23 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2024-06-20 08:28:23 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2024-06-20 08:28:23 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2024-06-20 08:28:23 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2024-06-20 08:28:23 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2024-06-20 08:28:23 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2024-06-20 08:28:23 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2024-06-20 08:28:23 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2024-06-20 08:28:23 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2024-06-20 08:28:23 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2024-06-20 08:28:23 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2024-06-20 08:28:23 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2024-06-20 08:28:23 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2024-06-20 08:28:23 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2024-06-20 08:28:23 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2024-06-20 08:28:23 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2024-06-20 08:28:23 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2024-06-20 08:28:23 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2024-06-20 08:28:23 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2024-06-20 08:28:23 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2024-06-20 08:28:23 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2024-06-20 08:28:23 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2024-06-20 08:28:23 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2024-06-20 08:28:23 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2024-06-20 08:28:23 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2024-06-20 08:28:23 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2024-06-20 08:28:23 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2024-06-20 08:28:23 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2024-06-20 08:28:23 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
DEBUG - 2024-06-20 08:28:23 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/views/cetak_projek.php
INFO - 2024-06-20 08:28:25 --> Config Class Initialized
INFO - 2024-06-20 08:28:25 --> Hooks Class Initialized
DEBUG - 2024-06-20 08:28:25 --> UTF-8 Support Enabled
INFO - 2024-06-20 08:28:25 --> Utf8 Class Initialized
INFO - 2024-06-20 08:28:25 --> URI Class Initialized
INFO - 2024-06-20 08:28:25 --> Router Class Initialized
INFO - 2024-06-20 08:28:25 --> Output Class Initialized
INFO - 2024-06-20 08:28:25 --> Security Class Initialized
DEBUG - 2024-06-20 08:28:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-20 08:28:25 --> Input Class Initialized
INFO - 2024-06-20 08:28:25 --> Language Class Initialized
INFO - 2024-06-20 08:28:25 --> Language Class Initialized
INFO - 2024-06-20 08:28:25 --> Config Class Initialized
INFO - 2024-06-20 08:28:25 --> Loader Class Initialized
INFO - 2024-06-20 08:28:25 --> Helper loaded: url_helper
INFO - 2024-06-20 08:28:25 --> Helper loaded: file_helper
INFO - 2024-06-20 08:28:25 --> Helper loaded: form_helper
INFO - 2024-06-20 08:28:25 --> Helper loaded: my_helper
INFO - 2024-06-20 08:28:25 --> Database Driver Class Initialized
INFO - 2024-06-20 08:28:27 --> Config Class Initialized
INFO - 2024-06-20 08:28:27 --> Hooks Class Initialized
DEBUG - 2024-06-20 08:28:27 --> UTF-8 Support Enabled
INFO - 2024-06-20 08:28:27 --> Utf8 Class Initialized
INFO - 2024-06-20 08:28:27 --> URI Class Initialized
INFO - 2024-06-20 08:28:27 --> Router Class Initialized
INFO - 2024-06-20 08:28:27 --> Output Class Initialized
INFO - 2024-06-20 08:28:27 --> Security Class Initialized
DEBUG - 2024-06-20 08:28:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-20 08:28:27 --> Input Class Initialized
INFO - 2024-06-20 08:28:27 --> Language Class Initialized
INFO - 2024-06-20 08:28:27 --> Language Class Initialized
INFO - 2024-06-20 08:28:27 --> Config Class Initialized
INFO - 2024-06-20 08:28:27 --> Loader Class Initialized
INFO - 2024-06-20 08:28:27 --> Helper loaded: url_helper
INFO - 2024-06-20 08:28:27 --> Helper loaded: file_helper
INFO - 2024-06-20 08:28:27 --> Helper loaded: form_helper
INFO - 2024-06-20 08:28:27 --> Helper loaded: my_helper
INFO - 2024-06-20 08:28:27 --> Database Driver Class Initialized
INFO - 2024-06-20 08:28:28 --> Final output sent to browser
DEBUG - 2024-06-20 08:28:28 --> Total execution time: 5.7519
INFO - 2024-06-20 08:28:28 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-20 08:28:28 --> Controller Class Initialized
ERROR - 2024-06-20 08:28:28 --> Severity: Notice --> Undefined index: projek /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1837
ERROR - 2024-06-20 08:28:28 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2024-06-20 08:28:28 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2024-06-20 08:28:28 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2024-06-20 08:28:28 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2024-06-20 08:28:28 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2024-06-20 08:28:28 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2024-06-20 08:28:28 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2024-06-20 08:28:28 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2024-06-20 08:28:28 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2024-06-20 08:28:28 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2024-06-20 08:28:28 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2024-06-20 08:28:28 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2024-06-20 08:28:28 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2024-06-20 08:28:28 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2024-06-20 08:28:28 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2024-06-20 08:28:28 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2024-06-20 08:28:28 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2024-06-20 08:28:28 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2024-06-20 08:28:28 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2024-06-20 08:28:28 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2024-06-20 08:28:28 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2024-06-20 08:28:28 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2024-06-20 08:28:28 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2024-06-20 08:28:28 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2024-06-20 08:28:28 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2024-06-20 08:28:28 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2024-06-20 08:28:28 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2024-06-20 08:28:28 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2024-06-20 08:28:28 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2024-06-20 08:28:28 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2024-06-20 08:28:28 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2024-06-20 08:28:28 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2024-06-20 08:28:28 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2024-06-20 08:28:28 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2024-06-20 08:28:28 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2024-06-20 08:28:28 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2024-06-20 08:28:28 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2024-06-20 08:28:28 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2024-06-20 08:28:28 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
DEBUG - 2024-06-20 08:28:28 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/views/cetak_projek.php
INFO - 2024-06-20 08:28:30 --> Config Class Initialized
INFO - 2024-06-20 08:28:30 --> Hooks Class Initialized
DEBUG - 2024-06-20 08:28:30 --> UTF-8 Support Enabled
INFO - 2024-06-20 08:28:30 --> Utf8 Class Initialized
INFO - 2024-06-20 08:28:30 --> URI Class Initialized
INFO - 2024-06-20 08:28:30 --> Router Class Initialized
INFO - 2024-06-20 08:28:30 --> Output Class Initialized
INFO - 2024-06-20 08:28:30 --> Security Class Initialized
DEBUG - 2024-06-20 08:28:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-20 08:28:30 --> Input Class Initialized
INFO - 2024-06-20 08:28:30 --> Language Class Initialized
INFO - 2024-06-20 08:28:30 --> Language Class Initialized
INFO - 2024-06-20 08:28:30 --> Config Class Initialized
INFO - 2024-06-20 08:28:30 --> Loader Class Initialized
INFO - 2024-06-20 08:28:30 --> Helper loaded: url_helper
INFO - 2024-06-20 08:28:30 --> Helper loaded: file_helper
INFO - 2024-06-20 08:28:30 --> Helper loaded: form_helper
INFO - 2024-06-20 08:28:30 --> Helper loaded: my_helper
INFO - 2024-06-20 08:28:30 --> Database Driver Class Initialized
INFO - 2024-06-20 08:28:33 --> Config Class Initialized
INFO - 2024-06-20 08:28:33 --> Hooks Class Initialized
DEBUG - 2024-06-20 08:28:33 --> UTF-8 Support Enabled
INFO - 2024-06-20 08:28:33 --> Utf8 Class Initialized
INFO - 2024-06-20 08:28:33 --> URI Class Initialized
INFO - 2024-06-20 08:28:33 --> Router Class Initialized
INFO - 2024-06-20 08:28:33 --> Output Class Initialized
INFO - 2024-06-20 08:28:34 --> Security Class Initialized
DEBUG - 2024-06-20 08:28:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-20 08:28:34 --> Input Class Initialized
INFO - 2024-06-20 08:28:34 --> Language Class Initialized
INFO - 2024-06-20 08:28:34 --> Language Class Initialized
INFO - 2024-06-20 08:28:34 --> Config Class Initialized
INFO - 2024-06-20 08:28:34 --> Loader Class Initialized
INFO - 2024-06-20 08:28:34 --> Helper loaded: url_helper
INFO - 2024-06-20 08:28:34 --> Helper loaded: file_helper
INFO - 2024-06-20 08:28:34 --> Helper loaded: form_helper
INFO - 2024-06-20 08:28:34 --> Helper loaded: my_helper
INFO - 2024-06-20 08:28:34 --> Database Driver Class Initialized
INFO - 2024-06-20 08:28:35 --> Final output sent to browser
DEBUG - 2024-06-20 08:28:35 --> Total execution time: 10.0539
INFO - 2024-06-20 08:28:35 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-20 08:28:35 --> Controller Class Initialized
ERROR - 2024-06-20 08:28:35 --> Severity: Notice --> Undefined index: projek /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1837
ERROR - 2024-06-20 08:28:35 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2024-06-20 08:28:35 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2024-06-20 08:28:35 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2024-06-20 08:28:35 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2024-06-20 08:28:35 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2024-06-20 08:28:35 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2024-06-20 08:28:35 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2024-06-20 08:28:35 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2024-06-20 08:28:35 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2024-06-20 08:28:35 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2024-06-20 08:28:35 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2024-06-20 08:28:35 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2024-06-20 08:28:35 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2024-06-20 08:28:35 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2024-06-20 08:28:35 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2024-06-20 08:28:35 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2024-06-20 08:28:35 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2024-06-20 08:28:35 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2024-06-20 08:28:35 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2024-06-20 08:28:35 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2024-06-20 08:28:35 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2024-06-20 08:28:35 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2024-06-20 08:28:35 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2024-06-20 08:28:35 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2024-06-20 08:28:35 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2024-06-20 08:28:35 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2024-06-20 08:28:35 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2024-06-20 08:28:35 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2024-06-20 08:28:35 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2024-06-20 08:28:35 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2024-06-20 08:28:35 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2024-06-20 08:28:35 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2024-06-20 08:28:35 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2024-06-20 08:28:35 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2024-06-20 08:28:35 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2024-06-20 08:28:35 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2024-06-20 08:28:35 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2024-06-20 08:28:35 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2024-06-20 08:28:35 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
DEBUG - 2024-06-20 08:28:35 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/views/cetak_projek.php
INFO - 2024-06-20 08:28:36 --> Config Class Initialized
INFO - 2024-06-20 08:28:36 --> Hooks Class Initialized
DEBUG - 2024-06-20 08:28:36 --> UTF-8 Support Enabled
INFO - 2024-06-20 08:28:36 --> Utf8 Class Initialized
INFO - 2024-06-20 08:28:36 --> URI Class Initialized
INFO - 2024-06-20 08:28:36 --> Router Class Initialized
INFO - 2024-06-20 08:28:36 --> Output Class Initialized
INFO - 2024-06-20 08:28:36 --> Security Class Initialized
DEBUG - 2024-06-20 08:28:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-20 08:28:36 --> Input Class Initialized
INFO - 2024-06-20 08:28:36 --> Language Class Initialized
INFO - 2024-06-20 08:28:36 --> Language Class Initialized
INFO - 2024-06-20 08:28:36 --> Config Class Initialized
INFO - 2024-06-20 08:28:36 --> Loader Class Initialized
INFO - 2024-06-20 08:28:36 --> Helper loaded: url_helper
INFO - 2024-06-20 08:28:36 --> Helper loaded: file_helper
INFO - 2024-06-20 08:28:36 --> Helper loaded: form_helper
INFO - 2024-06-20 08:28:36 --> Helper loaded: my_helper
INFO - 2024-06-20 08:28:36 --> Database Driver Class Initialized
INFO - 2024-06-20 08:28:40 --> Config Class Initialized
INFO - 2024-06-20 08:28:40 --> Hooks Class Initialized
DEBUG - 2024-06-20 08:28:40 --> UTF-8 Support Enabled
INFO - 2024-06-20 08:28:40 --> Utf8 Class Initialized
INFO - 2024-06-20 08:28:40 --> URI Class Initialized
INFO - 2024-06-20 08:28:40 --> Router Class Initialized
INFO - 2024-06-20 08:28:40 --> Output Class Initialized
INFO - 2024-06-20 08:28:40 --> Security Class Initialized
DEBUG - 2024-06-20 08:28:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-20 08:28:40 --> Input Class Initialized
INFO - 2024-06-20 08:28:40 --> Language Class Initialized
INFO - 2024-06-20 08:28:40 --> Language Class Initialized
INFO - 2024-06-20 08:28:40 --> Config Class Initialized
INFO - 2024-06-20 08:28:40 --> Loader Class Initialized
INFO - 2024-06-20 08:28:40 --> Helper loaded: url_helper
INFO - 2024-06-20 08:28:40 --> Helper loaded: file_helper
INFO - 2024-06-20 08:28:40 --> Helper loaded: form_helper
INFO - 2024-06-20 08:28:40 --> Helper loaded: my_helper
INFO - 2024-06-20 08:28:40 --> Database Driver Class Initialized
INFO - 2024-06-20 08:28:45 --> Final output sent to browser
DEBUG - 2024-06-20 08:28:45 --> Total execution time: 17.9126
INFO - 2024-06-20 08:28:45 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-20 08:28:45 --> Controller Class Initialized
ERROR - 2024-06-20 08:28:45 --> Severity: Notice --> Undefined index: projek /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1837
ERROR - 2024-06-20 08:28:45 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2024-06-20 08:28:45 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2024-06-20 08:28:45 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2024-06-20 08:28:45 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2024-06-20 08:28:45 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2024-06-20 08:28:45 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2024-06-20 08:28:45 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2024-06-20 08:28:45 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2024-06-20 08:28:45 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2024-06-20 08:28:45 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2024-06-20 08:28:45 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2024-06-20 08:28:45 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2024-06-20 08:28:45 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2024-06-20 08:28:45 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2024-06-20 08:28:45 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2024-06-20 08:28:45 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2024-06-20 08:28:45 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2024-06-20 08:28:45 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2024-06-20 08:28:45 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2024-06-20 08:28:45 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2024-06-20 08:28:45 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2024-06-20 08:28:45 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2024-06-20 08:28:45 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2024-06-20 08:28:45 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2024-06-20 08:28:45 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2024-06-20 08:28:45 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2024-06-20 08:28:45 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2024-06-20 08:28:45 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2024-06-20 08:28:45 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2024-06-20 08:28:45 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2024-06-20 08:28:45 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2024-06-20 08:28:45 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2024-06-20 08:28:45 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2024-06-20 08:28:45 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2024-06-20 08:28:45 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2024-06-20 08:28:45 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2024-06-20 08:28:45 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2024-06-20 08:28:45 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2024-06-20 08:28:45 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
DEBUG - 2024-06-20 08:28:45 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/views/cetak_projek.php
INFO - 2024-06-20 08:28:50 --> Final output sent to browser
DEBUG - 2024-06-20 08:28:50 --> Total execution time: 19.6566
INFO - 2024-06-20 08:28:50 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-20 08:28:50 --> Controller Class Initialized
ERROR - 2024-06-20 08:28:50 --> Severity: Notice --> Undefined index: projek /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1837
ERROR - 2024-06-20 08:28:50 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2024-06-20 08:28:50 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2024-06-20 08:28:50 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2024-06-20 08:28:50 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2024-06-20 08:28:50 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2024-06-20 08:28:50 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2024-06-20 08:28:50 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2024-06-20 08:28:50 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2024-06-20 08:28:50 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2024-06-20 08:28:50 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2024-06-20 08:28:50 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2024-06-20 08:28:50 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2024-06-20 08:28:50 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2024-06-20 08:28:50 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2024-06-20 08:28:50 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2024-06-20 08:28:50 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2024-06-20 08:28:50 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2024-06-20 08:28:50 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2024-06-20 08:28:50 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2024-06-20 08:28:50 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2024-06-20 08:28:50 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2024-06-20 08:28:50 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2024-06-20 08:28:50 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2024-06-20 08:28:50 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2024-06-20 08:28:50 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2024-06-20 08:28:50 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2024-06-20 08:28:50 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2024-06-20 08:28:50 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2024-06-20 08:28:50 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2024-06-20 08:28:50 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2024-06-20 08:28:50 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2024-06-20 08:28:50 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2024-06-20 08:28:50 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2024-06-20 08:28:50 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2024-06-20 08:28:50 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2024-06-20 08:28:50 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2024-06-20 08:28:50 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2024-06-20 08:28:50 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2024-06-20 08:28:50 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
DEBUG - 2024-06-20 08:28:50 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/views/cetak_projek.php
INFO - 2024-06-20 08:28:55 --> Final output sent to browser
DEBUG - 2024-06-20 08:28:55 --> Total execution time: 21.2052
INFO - 2024-06-20 08:28:55 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-20 08:28:55 --> Controller Class Initialized
ERROR - 2024-06-20 08:28:55 --> Severity: Notice --> Undefined index: projek /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1837
ERROR - 2024-06-20 08:28:55 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2024-06-20 08:28:55 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2024-06-20 08:28:55 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2024-06-20 08:28:55 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2024-06-20 08:28:55 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2024-06-20 08:28:55 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2024-06-20 08:28:55 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2024-06-20 08:28:55 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2024-06-20 08:28:55 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2024-06-20 08:28:55 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2024-06-20 08:28:55 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2024-06-20 08:28:55 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2024-06-20 08:28:55 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2024-06-20 08:28:55 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2024-06-20 08:28:55 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2024-06-20 08:28:55 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2024-06-20 08:28:55 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2024-06-20 08:28:55 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2024-06-20 08:28:55 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2024-06-20 08:28:55 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2024-06-20 08:28:55 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2024-06-20 08:28:55 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2024-06-20 08:28:55 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2024-06-20 08:28:55 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2024-06-20 08:28:55 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2024-06-20 08:28:55 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2024-06-20 08:28:55 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2024-06-20 08:28:55 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2024-06-20 08:28:55 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2024-06-20 08:28:55 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2024-06-20 08:28:55 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2024-06-20 08:28:55 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2024-06-20 08:28:55 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2024-06-20 08:28:55 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2024-06-20 08:28:55 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2024-06-20 08:28:55 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2024-06-20 08:28:55 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2024-06-20 08:28:55 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2024-06-20 08:28:55 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
DEBUG - 2024-06-20 08:28:55 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/views/cetak_projek.php
INFO - 2024-06-20 08:29:00 --> Final output sent to browser
DEBUG - 2024-06-20 08:29:00 --> Total execution time: 23.1708
INFO - 2024-06-20 08:29:00 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-20 08:29:00 --> Controller Class Initialized
ERROR - 2024-06-20 08:29:00 --> Severity: Notice --> Undefined index: projek /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1837
ERROR - 2024-06-20 08:29:00 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2024-06-20 08:29:00 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2024-06-20 08:29:00 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2024-06-20 08:29:00 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2024-06-20 08:29:00 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2024-06-20 08:29:00 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2024-06-20 08:29:00 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2024-06-20 08:29:00 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2024-06-20 08:29:00 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2024-06-20 08:29:00 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2024-06-20 08:29:00 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2024-06-20 08:29:00 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2024-06-20 08:29:00 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2024-06-20 08:29:00 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2024-06-20 08:29:00 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2024-06-20 08:29:00 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2024-06-20 08:29:00 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2024-06-20 08:29:00 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2024-06-20 08:29:00 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2024-06-20 08:29:00 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2024-06-20 08:29:00 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2024-06-20 08:29:00 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2024-06-20 08:29:00 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2024-06-20 08:29:00 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2024-06-20 08:29:00 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2024-06-20 08:29:00 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2024-06-20 08:29:00 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2024-06-20 08:29:00 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2024-06-20 08:29:00 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2024-06-20 08:29:00 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2024-06-20 08:29:00 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2024-06-20 08:29:00 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2024-06-20 08:29:00 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2024-06-20 08:29:00 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2024-06-20 08:29:00 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2024-06-20 08:29:00 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2024-06-20 08:29:00 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2024-06-20 08:29:00 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2024-06-20 08:29:00 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
DEBUG - 2024-06-20 08:29:00 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/views/cetak_projek.php
INFO - 2024-06-20 08:29:09 --> Final output sent to browser
DEBUG - 2024-06-20 08:29:09 --> Total execution time: 29.0579
INFO - 2024-06-20 09:22:25 --> Config Class Initialized
INFO - 2024-06-20 09:22:25 --> Hooks Class Initialized
DEBUG - 2024-06-20 09:22:25 --> UTF-8 Support Enabled
INFO - 2024-06-20 09:22:25 --> Utf8 Class Initialized
INFO - 2024-06-20 09:22:25 --> URI Class Initialized
INFO - 2024-06-20 09:22:25 --> Router Class Initialized
INFO - 2024-06-20 09:22:25 --> Output Class Initialized
INFO - 2024-06-20 09:22:25 --> Security Class Initialized
DEBUG - 2024-06-20 09:22:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-20 09:22:25 --> Input Class Initialized
INFO - 2024-06-20 09:22:25 --> Language Class Initialized
INFO - 2024-06-20 09:22:25 --> Language Class Initialized
INFO - 2024-06-20 09:22:25 --> Config Class Initialized
INFO - 2024-06-20 09:22:25 --> Loader Class Initialized
INFO - 2024-06-20 09:22:25 --> Helper loaded: url_helper
INFO - 2024-06-20 09:22:25 --> Helper loaded: file_helper
INFO - 2024-06-20 09:22:25 --> Helper loaded: form_helper
INFO - 2024-06-20 09:22:25 --> Helper loaded: my_helper
INFO - 2024-06-20 09:22:25 --> Database Driver Class Initialized
INFO - 2024-06-20 09:22:25 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-20 09:22:25 --> Controller Class Initialized
DEBUG - 2024-06-20 09:22:25 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/views/cetak_mh.php
INFO - 2024-06-20 09:22:27 --> Config Class Initialized
INFO - 2024-06-20 09:22:27 --> Hooks Class Initialized
DEBUG - 2024-06-20 09:22:27 --> UTF-8 Support Enabled
INFO - 2024-06-20 09:22:27 --> Utf8 Class Initialized
INFO - 2024-06-20 09:22:27 --> URI Class Initialized
INFO - 2024-06-20 09:22:27 --> Router Class Initialized
INFO - 2024-06-20 09:22:27 --> Output Class Initialized
INFO - 2024-06-20 09:22:27 --> Security Class Initialized
DEBUG - 2024-06-20 09:22:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-20 09:22:27 --> Input Class Initialized
INFO - 2024-06-20 09:22:27 --> Language Class Initialized
INFO - 2024-06-20 09:22:27 --> Language Class Initialized
INFO - 2024-06-20 09:22:27 --> Config Class Initialized
INFO - 2024-06-20 09:22:27 --> Loader Class Initialized
INFO - 2024-06-20 09:22:27 --> Helper loaded: url_helper
INFO - 2024-06-20 09:22:27 --> Helper loaded: file_helper
INFO - 2024-06-20 09:22:27 --> Helper loaded: form_helper
INFO - 2024-06-20 09:22:27 --> Helper loaded: my_helper
INFO - 2024-06-20 09:22:27 --> Database Driver Class Initialized
INFO - 2024-06-20 09:22:27 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-20 09:22:27 --> Controller Class Initialized
DEBUG - 2024-06-20 09:22:27 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/views/cetak_mh.php
INFO - 2024-06-20 09:22:37 --> Final output sent to browser
DEBUG - 2024-06-20 09:22:37 --> Total execution time: 12.2352
INFO - 2024-06-20 09:22:40 --> Final output sent to browser
DEBUG - 2024-06-20 09:22:40 --> Total execution time: 12.7948
INFO - 2024-06-20 09:24:59 --> Config Class Initialized
INFO - 2024-06-20 09:24:59 --> Hooks Class Initialized
DEBUG - 2024-06-20 09:24:59 --> UTF-8 Support Enabled
INFO - 2024-06-20 09:24:59 --> Utf8 Class Initialized
INFO - 2024-06-20 09:24:59 --> URI Class Initialized
INFO - 2024-06-20 09:24:59 --> Router Class Initialized
INFO - 2024-06-20 09:24:59 --> Output Class Initialized
INFO - 2024-06-20 09:24:59 --> Security Class Initialized
DEBUG - 2024-06-20 09:24:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-20 09:24:59 --> Input Class Initialized
INFO - 2024-06-20 09:24:59 --> Language Class Initialized
INFO - 2024-06-20 09:24:59 --> Language Class Initialized
INFO - 2024-06-20 09:24:59 --> Config Class Initialized
INFO - 2024-06-20 09:24:59 --> Loader Class Initialized
INFO - 2024-06-20 09:24:59 --> Helper loaded: url_helper
INFO - 2024-06-20 09:24:59 --> Helper loaded: file_helper
INFO - 2024-06-20 09:24:59 --> Helper loaded: form_helper
INFO - 2024-06-20 09:24:59 --> Helper loaded: my_helper
INFO - 2024-06-20 09:24:59 --> Database Driver Class Initialized
INFO - 2024-06-20 09:24:59 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-20 09:24:59 --> Controller Class Initialized
DEBUG - 2024-06-20 09:24:59 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/views/cetak_mh.php
INFO - 2024-06-20 09:25:02 --> Config Class Initialized
INFO - 2024-06-20 09:25:02 --> Hooks Class Initialized
DEBUG - 2024-06-20 09:25:02 --> UTF-8 Support Enabled
INFO - 2024-06-20 09:25:02 --> Utf8 Class Initialized
INFO - 2024-06-20 09:25:02 --> URI Class Initialized
INFO - 2024-06-20 09:25:02 --> Router Class Initialized
INFO - 2024-06-20 09:25:02 --> Output Class Initialized
INFO - 2024-06-20 09:25:02 --> Security Class Initialized
DEBUG - 2024-06-20 09:25:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-20 09:25:02 --> Input Class Initialized
INFO - 2024-06-20 09:25:02 --> Language Class Initialized
INFO - 2024-06-20 09:25:02 --> Language Class Initialized
INFO - 2024-06-20 09:25:02 --> Config Class Initialized
INFO - 2024-06-20 09:25:02 --> Loader Class Initialized
INFO - 2024-06-20 09:25:02 --> Helper loaded: url_helper
INFO - 2024-06-20 09:25:02 --> Helper loaded: file_helper
INFO - 2024-06-20 09:25:02 --> Helper loaded: form_helper
INFO - 2024-06-20 09:25:02 --> Helper loaded: my_helper
INFO - 2024-06-20 09:25:02 --> Database Driver Class Initialized
INFO - 2024-06-20 09:25:03 --> Final output sent to browser
DEBUG - 2024-06-20 09:25:03 --> Total execution time: 4.5194
INFO - 2024-06-20 09:25:03 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-20 09:25:03 --> Controller Class Initialized
DEBUG - 2024-06-20 09:25:03 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/views/cetak_mh.php
INFO - 2024-06-20 09:25:06 --> Config Class Initialized
INFO - 2024-06-20 09:25:06 --> Hooks Class Initialized
DEBUG - 2024-06-20 09:25:06 --> UTF-8 Support Enabled
INFO - 2024-06-20 09:25:06 --> Utf8 Class Initialized
INFO - 2024-06-20 09:25:06 --> URI Class Initialized
INFO - 2024-06-20 09:25:06 --> Router Class Initialized
INFO - 2024-06-20 09:25:06 --> Output Class Initialized
INFO - 2024-06-20 09:25:06 --> Security Class Initialized
DEBUG - 2024-06-20 09:25:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-20 09:25:06 --> Input Class Initialized
INFO - 2024-06-20 09:25:06 --> Language Class Initialized
INFO - 2024-06-20 09:25:06 --> Language Class Initialized
INFO - 2024-06-20 09:25:06 --> Config Class Initialized
INFO - 2024-06-20 09:25:06 --> Loader Class Initialized
INFO - 2024-06-20 09:25:06 --> Helper loaded: url_helper
INFO - 2024-06-20 09:25:06 --> Helper loaded: file_helper
INFO - 2024-06-20 09:25:06 --> Helper loaded: form_helper
INFO - 2024-06-20 09:25:06 --> Helper loaded: my_helper
INFO - 2024-06-20 09:25:06 --> Database Driver Class Initialized
INFO - 2024-06-20 09:25:07 --> Final output sent to browser
DEBUG - 2024-06-20 09:25:07 --> Total execution time: 5.4426
INFO - 2024-06-20 09:25:07 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-20 09:25:07 --> Controller Class Initialized
DEBUG - 2024-06-20 09:25:08 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/views/cetak_mh.php
INFO - 2024-06-20 09:25:09 --> Config Class Initialized
INFO - 2024-06-20 09:25:09 --> Hooks Class Initialized
DEBUG - 2024-06-20 09:25:09 --> UTF-8 Support Enabled
INFO - 2024-06-20 09:25:09 --> Utf8 Class Initialized
INFO - 2024-06-20 09:25:09 --> URI Class Initialized
INFO - 2024-06-20 09:25:09 --> Router Class Initialized
INFO - 2024-06-20 09:25:09 --> Output Class Initialized
INFO - 2024-06-20 09:25:09 --> Security Class Initialized
DEBUG - 2024-06-20 09:25:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-20 09:25:09 --> Input Class Initialized
INFO - 2024-06-20 09:25:09 --> Language Class Initialized
INFO - 2024-06-20 09:25:09 --> Language Class Initialized
INFO - 2024-06-20 09:25:09 --> Config Class Initialized
INFO - 2024-06-20 09:25:09 --> Loader Class Initialized
INFO - 2024-06-20 09:25:09 --> Helper loaded: url_helper
INFO - 2024-06-20 09:25:09 --> Helper loaded: file_helper
INFO - 2024-06-20 09:25:09 --> Helper loaded: form_helper
INFO - 2024-06-20 09:25:09 --> Helper loaded: my_helper
INFO - 2024-06-20 09:25:09 --> Database Driver Class Initialized
INFO - 2024-06-20 09:25:12 --> Config Class Initialized
INFO - 2024-06-20 09:25:12 --> Hooks Class Initialized
DEBUG - 2024-06-20 09:25:12 --> UTF-8 Support Enabled
INFO - 2024-06-20 09:25:12 --> Utf8 Class Initialized
INFO - 2024-06-20 09:25:12 --> URI Class Initialized
INFO - 2024-06-20 09:25:12 --> Router Class Initialized
INFO - 2024-06-20 09:25:12 --> Output Class Initialized
INFO - 2024-06-20 09:25:12 --> Security Class Initialized
DEBUG - 2024-06-20 09:25:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-20 09:25:12 --> Input Class Initialized
INFO - 2024-06-20 09:25:12 --> Language Class Initialized
INFO - 2024-06-20 09:25:12 --> Language Class Initialized
INFO - 2024-06-20 09:25:12 --> Config Class Initialized
INFO - 2024-06-20 09:25:12 --> Loader Class Initialized
INFO - 2024-06-20 09:25:12 --> Helper loaded: url_helper
INFO - 2024-06-20 09:25:12 --> Helper loaded: file_helper
INFO - 2024-06-20 09:25:12 --> Helper loaded: form_helper
INFO - 2024-06-20 09:25:12 --> Helper loaded: my_helper
INFO - 2024-06-20 09:25:12 --> Database Driver Class Initialized
INFO - 2024-06-20 09:25:13 --> Final output sent to browser
DEBUG - 2024-06-20 09:25:13 --> Total execution time: 7.6866
INFO - 2024-06-20 09:25:13 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-20 09:25:13 --> Controller Class Initialized
DEBUG - 2024-06-20 09:25:13 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/views/cetak_mh.php
INFO - 2024-06-20 09:25:16 --> Config Class Initialized
INFO - 2024-06-20 09:25:16 --> Hooks Class Initialized
DEBUG - 2024-06-20 09:25:16 --> UTF-8 Support Enabled
INFO - 2024-06-20 09:25:16 --> Utf8 Class Initialized
INFO - 2024-06-20 09:25:16 --> URI Class Initialized
INFO - 2024-06-20 09:25:16 --> Router Class Initialized
INFO - 2024-06-20 09:25:16 --> Output Class Initialized
INFO - 2024-06-20 09:25:16 --> Security Class Initialized
DEBUG - 2024-06-20 09:25:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-20 09:25:16 --> Input Class Initialized
INFO - 2024-06-20 09:25:16 --> Language Class Initialized
INFO - 2024-06-20 09:25:16 --> Language Class Initialized
INFO - 2024-06-20 09:25:16 --> Config Class Initialized
INFO - 2024-06-20 09:25:16 --> Loader Class Initialized
INFO - 2024-06-20 09:25:16 --> Helper loaded: url_helper
INFO - 2024-06-20 09:25:16 --> Helper loaded: file_helper
INFO - 2024-06-20 09:25:16 --> Helper loaded: form_helper
INFO - 2024-06-20 09:25:16 --> Helper loaded: my_helper
INFO - 2024-06-20 09:25:16 --> Database Driver Class Initialized
INFO - 2024-06-20 09:25:19 --> Config Class Initialized
INFO - 2024-06-20 09:25:19 --> Hooks Class Initialized
DEBUG - 2024-06-20 09:25:19 --> UTF-8 Support Enabled
INFO - 2024-06-20 09:25:19 --> Utf8 Class Initialized
INFO - 2024-06-20 09:25:19 --> URI Class Initialized
INFO - 2024-06-20 09:25:19 --> Router Class Initialized
INFO - 2024-06-20 09:25:19 --> Output Class Initialized
INFO - 2024-06-20 09:25:19 --> Security Class Initialized
DEBUG - 2024-06-20 09:25:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-20 09:25:19 --> Input Class Initialized
INFO - 2024-06-20 09:25:19 --> Language Class Initialized
INFO - 2024-06-20 09:25:19 --> Language Class Initialized
INFO - 2024-06-20 09:25:19 --> Config Class Initialized
INFO - 2024-06-20 09:25:19 --> Loader Class Initialized
INFO - 2024-06-20 09:25:19 --> Helper loaded: url_helper
INFO - 2024-06-20 09:25:19 --> Helper loaded: file_helper
INFO - 2024-06-20 09:25:19 --> Helper loaded: form_helper
INFO - 2024-06-20 09:25:19 --> Helper loaded: my_helper
INFO - 2024-06-20 09:25:19 --> Database Driver Class Initialized
INFO - 2024-06-20 09:25:21 --> Final output sent to browser
DEBUG - 2024-06-20 09:25:21 --> Total execution time: 11.9036
INFO - 2024-06-20 09:25:21 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-20 09:25:21 --> Controller Class Initialized
ERROR - 2024-06-20 09:25:21 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 3014
ERROR - 2024-06-20 09:25:21 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 3015
DEBUG - 2024-06-20 09:25:21 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/views/cetak_mh.php
INFO - 2024-06-20 09:25:25 --> Final output sent to browser
DEBUG - 2024-06-20 09:25:25 --> Total execution time: 12.4039
INFO - 2024-06-20 09:25:25 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-20 09:25:25 --> Controller Class Initialized
DEBUG - 2024-06-20 09:25:25 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/views/cetak_mh.php
INFO - 2024-06-20 09:25:29 --> Final output sent to browser
DEBUG - 2024-06-20 09:25:29 --> Total execution time: 13.2608
INFO - 2024-06-20 09:25:29 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-20 09:25:29 --> Controller Class Initialized
ERROR - 2024-06-20 09:25:29 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 3014
ERROR - 2024-06-20 09:25:29 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 3015
DEBUG - 2024-06-20 09:25:29 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/views/cetak_mh.php
INFO - 2024-06-20 09:25:30 --> Config Class Initialized
INFO - 2024-06-20 09:25:30 --> Hooks Class Initialized
DEBUG - 2024-06-20 09:25:30 --> UTF-8 Support Enabled
INFO - 2024-06-20 09:25:30 --> Utf8 Class Initialized
INFO - 2024-06-20 09:25:30 --> URI Class Initialized
INFO - 2024-06-20 09:25:30 --> Router Class Initialized
INFO - 2024-06-20 09:25:30 --> Output Class Initialized
INFO - 2024-06-20 09:25:30 --> Security Class Initialized
DEBUG - 2024-06-20 09:25:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-20 09:25:30 --> Input Class Initialized
INFO - 2024-06-20 09:25:30 --> Language Class Initialized
INFO - 2024-06-20 09:25:30 --> Language Class Initialized
INFO - 2024-06-20 09:25:30 --> Config Class Initialized
INFO - 2024-06-20 09:25:30 --> Loader Class Initialized
INFO - 2024-06-20 09:25:30 --> Helper loaded: url_helper
INFO - 2024-06-20 09:25:30 --> Helper loaded: file_helper
INFO - 2024-06-20 09:25:30 --> Helper loaded: form_helper
INFO - 2024-06-20 09:25:30 --> Helper loaded: my_helper
INFO - 2024-06-20 09:25:30 --> Database Driver Class Initialized
INFO - 2024-06-20 09:25:34 --> Config Class Initialized
INFO - 2024-06-20 09:25:34 --> Hooks Class Initialized
DEBUG - 2024-06-20 09:25:34 --> UTF-8 Support Enabled
INFO - 2024-06-20 09:25:34 --> Utf8 Class Initialized
INFO - 2024-06-20 09:25:34 --> URI Class Initialized
INFO - 2024-06-20 09:25:34 --> Router Class Initialized
INFO - 2024-06-20 09:25:34 --> Output Class Initialized
INFO - 2024-06-20 09:25:34 --> Security Class Initialized
DEBUG - 2024-06-20 09:25:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-20 09:25:34 --> Input Class Initialized
INFO - 2024-06-20 09:25:34 --> Language Class Initialized
INFO - 2024-06-20 09:25:34 --> Language Class Initialized
INFO - 2024-06-20 09:25:34 --> Config Class Initialized
INFO - 2024-06-20 09:25:34 --> Loader Class Initialized
INFO - 2024-06-20 09:25:34 --> Helper loaded: url_helper
INFO - 2024-06-20 09:25:34 --> Helper loaded: file_helper
INFO - 2024-06-20 09:25:34 --> Helper loaded: form_helper
INFO - 2024-06-20 09:25:34 --> Helper loaded: my_helper
INFO - 2024-06-20 09:25:34 --> Database Driver Class Initialized
INFO - 2024-06-20 09:25:34 --> Final output sent to browser
DEBUG - 2024-06-20 09:25:34 --> Total execution time: 14.7173
INFO - 2024-06-20 09:25:34 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-20 09:25:34 --> Controller Class Initialized
DEBUG - 2024-06-20 09:25:34 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/views/cetak_mh.php
INFO - 2024-06-20 09:25:37 --> Config Class Initialized
INFO - 2024-06-20 09:25:37 --> Hooks Class Initialized
DEBUG - 2024-06-20 09:25:37 --> UTF-8 Support Enabled
INFO - 2024-06-20 09:25:37 --> Utf8 Class Initialized
INFO - 2024-06-20 09:25:37 --> URI Class Initialized
INFO - 2024-06-20 09:25:37 --> Router Class Initialized
INFO - 2024-06-20 09:25:37 --> Output Class Initialized
INFO - 2024-06-20 09:25:37 --> Security Class Initialized
DEBUG - 2024-06-20 09:25:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-20 09:25:37 --> Input Class Initialized
INFO - 2024-06-20 09:25:37 --> Language Class Initialized
INFO - 2024-06-20 09:25:37 --> Language Class Initialized
INFO - 2024-06-20 09:25:37 --> Config Class Initialized
INFO - 2024-06-20 09:25:37 --> Loader Class Initialized
INFO - 2024-06-20 09:25:37 --> Helper loaded: url_helper
INFO - 2024-06-20 09:25:37 --> Helper loaded: file_helper
INFO - 2024-06-20 09:25:37 --> Helper loaded: form_helper
INFO - 2024-06-20 09:25:37 --> Helper loaded: my_helper
INFO - 2024-06-20 09:25:37 --> Database Driver Class Initialized
INFO - 2024-06-20 09:25:38 --> Final output sent to browser
DEBUG - 2024-06-20 09:25:38 --> Total execution time: 7.9539
INFO - 2024-06-20 09:25:38 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-20 09:25:38 --> Controller Class Initialized
ERROR - 2024-06-20 09:25:38 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 3014
ERROR - 2024-06-20 09:25:38 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 3015
DEBUG - 2024-06-20 09:25:38 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/views/cetak_mh.php
INFO - 2024-06-20 09:25:41 --> Config Class Initialized
INFO - 2024-06-20 09:25:41 --> Hooks Class Initialized
DEBUG - 2024-06-20 09:25:41 --> UTF-8 Support Enabled
INFO - 2024-06-20 09:25:41 --> Utf8 Class Initialized
INFO - 2024-06-20 09:25:41 --> URI Class Initialized
INFO - 2024-06-20 09:25:41 --> Router Class Initialized
INFO - 2024-06-20 09:25:41 --> Output Class Initialized
INFO - 2024-06-20 09:25:41 --> Security Class Initialized
DEBUG - 2024-06-20 09:25:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-20 09:25:41 --> Input Class Initialized
INFO - 2024-06-20 09:25:41 --> Language Class Initialized
INFO - 2024-06-20 09:25:41 --> Language Class Initialized
INFO - 2024-06-20 09:25:41 --> Config Class Initialized
INFO - 2024-06-20 09:25:41 --> Loader Class Initialized
INFO - 2024-06-20 09:25:41 --> Helper loaded: url_helper
INFO - 2024-06-20 09:25:41 --> Helper loaded: file_helper
INFO - 2024-06-20 09:25:41 --> Helper loaded: form_helper
INFO - 2024-06-20 09:25:41 --> Helper loaded: my_helper
INFO - 2024-06-20 09:25:41 --> Database Driver Class Initialized
INFO - 2024-06-20 09:25:43 --> Final output sent to browser
DEBUG - 2024-06-20 09:25:43 --> Total execution time: 9.1102
INFO - 2024-06-20 09:25:43 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-20 09:25:43 --> Controller Class Initialized
DEBUG - 2024-06-20 09:25:43 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/views/cetak_mh.php
INFO - 2024-06-20 09:25:44 --> Config Class Initialized
INFO - 2024-06-20 09:25:44 --> Hooks Class Initialized
DEBUG - 2024-06-20 09:25:44 --> UTF-8 Support Enabled
INFO - 2024-06-20 09:25:44 --> Utf8 Class Initialized
INFO - 2024-06-20 09:25:44 --> URI Class Initialized
INFO - 2024-06-20 09:25:44 --> Router Class Initialized
INFO - 2024-06-20 09:25:44 --> Output Class Initialized
INFO - 2024-06-20 09:25:44 --> Security Class Initialized
DEBUG - 2024-06-20 09:25:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-20 09:25:44 --> Input Class Initialized
INFO - 2024-06-20 09:25:44 --> Language Class Initialized
INFO - 2024-06-20 09:25:44 --> Language Class Initialized
INFO - 2024-06-20 09:25:44 --> Config Class Initialized
INFO - 2024-06-20 09:25:44 --> Loader Class Initialized
INFO - 2024-06-20 09:25:44 --> Helper loaded: url_helper
INFO - 2024-06-20 09:25:44 --> Helper loaded: file_helper
INFO - 2024-06-20 09:25:44 --> Helper loaded: form_helper
INFO - 2024-06-20 09:25:44 --> Helper loaded: my_helper
INFO - 2024-06-20 09:25:44 --> Database Driver Class Initialized
INFO - 2024-06-20 09:25:47 --> Config Class Initialized
INFO - 2024-06-20 09:25:47 --> Hooks Class Initialized
DEBUG - 2024-06-20 09:25:47 --> UTF-8 Support Enabled
INFO - 2024-06-20 09:25:47 --> Utf8 Class Initialized
INFO - 2024-06-20 09:25:47 --> URI Class Initialized
INFO - 2024-06-20 09:25:47 --> Router Class Initialized
INFO - 2024-06-20 09:25:47 --> Output Class Initialized
INFO - 2024-06-20 09:25:47 --> Security Class Initialized
DEBUG - 2024-06-20 09:25:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-20 09:25:47 --> Input Class Initialized
INFO - 2024-06-20 09:25:47 --> Language Class Initialized
INFO - 2024-06-20 09:25:47 --> Language Class Initialized
INFO - 2024-06-20 09:25:47 --> Config Class Initialized
INFO - 2024-06-20 09:25:47 --> Loader Class Initialized
INFO - 2024-06-20 09:25:47 --> Helper loaded: url_helper
INFO - 2024-06-20 09:25:47 --> Helper loaded: file_helper
INFO - 2024-06-20 09:25:47 --> Helper loaded: form_helper
INFO - 2024-06-20 09:25:47 --> Helper loaded: my_helper
INFO - 2024-06-20 09:25:47 --> Database Driver Class Initialized
INFO - 2024-06-20 09:25:48 --> Final output sent to browser
DEBUG - 2024-06-20 09:25:48 --> Total execution time: 10.4984
INFO - 2024-06-20 09:25:48 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-20 09:25:48 --> Controller Class Initialized
DEBUG - 2024-06-20 09:25:48 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/views/cetak_mh.php
INFO - 2024-06-20 09:25:52 --> Final output sent to browser
DEBUG - 2024-06-20 09:25:52 --> Total execution time: 11.2775
INFO - 2024-06-20 09:25:52 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-20 09:25:52 --> Controller Class Initialized
DEBUG - 2024-06-20 09:25:52 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/views/cetak_mh.php
INFO - 2024-06-20 09:25:59 --> Final output sent to browser
DEBUG - 2024-06-20 09:25:59 --> Total execution time: 14.8489
INFO - 2024-06-20 09:25:59 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-20 09:25:59 --> Controller Class Initialized
DEBUG - 2024-06-20 09:25:59 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/views/cetak_mh.php
INFO - 2024-06-20 09:26:06 --> Final output sent to browser
DEBUG - 2024-06-20 09:26:06 --> Total execution time: 19.1206
INFO - 2024-06-20 09:28:19 --> Config Class Initialized
INFO - 2024-06-20 09:28:19 --> Hooks Class Initialized
DEBUG - 2024-06-20 09:28:19 --> UTF-8 Support Enabled
INFO - 2024-06-20 09:28:19 --> Utf8 Class Initialized
INFO - 2024-06-20 09:28:19 --> URI Class Initialized
INFO - 2024-06-20 09:28:19 --> Router Class Initialized
INFO - 2024-06-20 09:28:19 --> Output Class Initialized
INFO - 2024-06-20 09:28:19 --> Security Class Initialized
DEBUG - 2024-06-20 09:28:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-20 09:28:19 --> Input Class Initialized
INFO - 2024-06-20 09:28:19 --> Language Class Initialized
INFO - 2024-06-20 09:28:19 --> Language Class Initialized
INFO - 2024-06-20 09:28:19 --> Config Class Initialized
INFO - 2024-06-20 09:28:19 --> Loader Class Initialized
INFO - 2024-06-20 09:28:19 --> Helper loaded: url_helper
INFO - 2024-06-20 09:28:19 --> Helper loaded: file_helper
INFO - 2024-06-20 09:28:19 --> Helper loaded: form_helper
INFO - 2024-06-20 09:28:19 --> Helper loaded: my_helper
INFO - 2024-06-20 09:28:19 --> Database Driver Class Initialized
INFO - 2024-06-20 09:28:19 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-20 09:28:19 --> Controller Class Initialized
DEBUG - 2024-06-20 09:28:19 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/views/cetak_ikm.php
INFO - 2024-06-20 09:28:21 --> Final output sent to browser
DEBUG - 2024-06-20 09:28:21 --> Total execution time: 1.8778
INFO - 2024-06-20 09:28:29 --> Config Class Initialized
INFO - 2024-06-20 09:28:29 --> Hooks Class Initialized
DEBUG - 2024-06-20 09:28:29 --> UTF-8 Support Enabled
INFO - 2024-06-20 09:28:29 --> Utf8 Class Initialized
INFO - 2024-06-20 09:28:29 --> URI Class Initialized
INFO - 2024-06-20 09:28:29 --> Router Class Initialized
INFO - 2024-06-20 09:28:29 --> Output Class Initialized
INFO - 2024-06-20 09:28:29 --> Security Class Initialized
DEBUG - 2024-06-20 09:28:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-20 09:28:29 --> Input Class Initialized
INFO - 2024-06-20 09:28:29 --> Language Class Initialized
INFO - 2024-06-20 09:28:29 --> Language Class Initialized
INFO - 2024-06-20 09:28:29 --> Config Class Initialized
INFO - 2024-06-20 09:28:29 --> Loader Class Initialized
INFO - 2024-06-20 09:28:29 --> Helper loaded: url_helper
INFO - 2024-06-20 09:28:29 --> Helper loaded: file_helper
INFO - 2024-06-20 09:28:29 --> Helper loaded: form_helper
INFO - 2024-06-20 09:28:29 --> Helper loaded: my_helper
INFO - 2024-06-20 09:28:29 --> Database Driver Class Initialized
INFO - 2024-06-20 09:28:29 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-20 09:28:29 --> Controller Class Initialized
DEBUG - 2024-06-20 09:28:29 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/views/cetak_ikm.php
INFO - 2024-06-20 09:28:31 --> Final output sent to browser
DEBUG - 2024-06-20 09:28:31 --> Total execution time: 1.8777
INFO - 2024-06-20 09:29:36 --> Config Class Initialized
INFO - 2024-06-20 09:29:36 --> Hooks Class Initialized
DEBUG - 2024-06-20 09:29:36 --> UTF-8 Support Enabled
INFO - 2024-06-20 09:29:36 --> Utf8 Class Initialized
INFO - 2024-06-20 09:29:36 --> URI Class Initialized
INFO - 2024-06-20 09:29:36 --> Router Class Initialized
INFO - 2024-06-20 09:29:36 --> Output Class Initialized
INFO - 2024-06-20 09:29:36 --> Security Class Initialized
DEBUG - 2024-06-20 09:29:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-20 09:29:36 --> Input Class Initialized
INFO - 2024-06-20 09:29:36 --> Language Class Initialized
INFO - 2024-06-20 09:29:36 --> Language Class Initialized
INFO - 2024-06-20 09:29:36 --> Config Class Initialized
INFO - 2024-06-20 09:29:36 --> Loader Class Initialized
INFO - 2024-06-20 09:29:36 --> Helper loaded: url_helper
INFO - 2024-06-20 09:29:36 --> Helper loaded: file_helper
INFO - 2024-06-20 09:29:36 --> Helper loaded: form_helper
INFO - 2024-06-20 09:29:36 --> Helper loaded: my_helper
INFO - 2024-06-20 09:29:36 --> Database Driver Class Initialized
INFO - 2024-06-20 09:29:36 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-20 09:29:36 --> Controller Class Initialized
DEBUG - 2024-06-20 09:29:36 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/views/cetak_ikm.php
INFO - 2024-06-20 09:29:37 --> Final output sent to browser
DEBUG - 2024-06-20 09:29:37 --> Total execution time: 1.7249
INFO - 2024-06-20 09:30:02 --> Config Class Initialized
INFO - 2024-06-20 09:30:02 --> Hooks Class Initialized
DEBUG - 2024-06-20 09:30:02 --> UTF-8 Support Enabled
INFO - 2024-06-20 09:30:02 --> Utf8 Class Initialized
INFO - 2024-06-20 09:30:02 --> URI Class Initialized
INFO - 2024-06-20 09:30:02 --> Router Class Initialized
INFO - 2024-06-20 09:30:02 --> Output Class Initialized
INFO - 2024-06-20 09:30:02 --> Security Class Initialized
DEBUG - 2024-06-20 09:30:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-20 09:30:02 --> Input Class Initialized
INFO - 2024-06-20 09:30:02 --> Language Class Initialized
INFO - 2024-06-20 09:30:02 --> Language Class Initialized
INFO - 2024-06-20 09:30:02 --> Config Class Initialized
INFO - 2024-06-20 09:30:02 --> Loader Class Initialized
INFO - 2024-06-20 09:30:02 --> Helper loaded: url_helper
INFO - 2024-06-20 09:30:02 --> Helper loaded: file_helper
INFO - 2024-06-20 09:30:02 --> Helper loaded: form_helper
INFO - 2024-06-20 09:30:02 --> Helper loaded: my_helper
INFO - 2024-06-20 09:30:03 --> Database Driver Class Initialized
INFO - 2024-06-20 09:30:03 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-20 09:30:03 --> Controller Class Initialized
DEBUG - 2024-06-20 09:30:03 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/views/cetak_tahfiz.php
INFO - 2024-06-20 09:30:06 --> Config Class Initialized
INFO - 2024-06-20 09:30:06 --> Hooks Class Initialized
DEBUG - 2024-06-20 09:30:06 --> UTF-8 Support Enabled
INFO - 2024-06-20 09:30:06 --> Utf8 Class Initialized
INFO - 2024-06-20 09:30:06 --> URI Class Initialized
INFO - 2024-06-20 09:30:06 --> Router Class Initialized
INFO - 2024-06-20 09:30:06 --> Output Class Initialized
INFO - 2024-06-20 09:30:06 --> Security Class Initialized
DEBUG - 2024-06-20 09:30:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-20 09:30:06 --> Input Class Initialized
INFO - 2024-06-20 09:30:06 --> Language Class Initialized
INFO - 2024-06-20 09:30:07 --> Language Class Initialized
INFO - 2024-06-20 09:30:07 --> Config Class Initialized
INFO - 2024-06-20 09:30:07 --> Loader Class Initialized
INFO - 2024-06-20 09:30:07 --> Helper loaded: url_helper
INFO - 2024-06-20 09:30:07 --> Helper loaded: file_helper
INFO - 2024-06-20 09:30:07 --> Helper loaded: form_helper
INFO - 2024-06-20 09:30:07 --> Helper loaded: my_helper
INFO - 2024-06-20 09:30:07 --> Database Driver Class Initialized
INFO - 2024-06-20 09:30:09 --> Config Class Initialized
INFO - 2024-06-20 09:30:09 --> Hooks Class Initialized
DEBUG - 2024-06-20 09:30:09 --> UTF-8 Support Enabled
INFO - 2024-06-20 09:30:09 --> Utf8 Class Initialized
INFO - 2024-06-20 09:30:09 --> URI Class Initialized
INFO - 2024-06-20 09:30:09 --> Router Class Initialized
INFO - 2024-06-20 09:30:09 --> Output Class Initialized
INFO - 2024-06-20 09:30:09 --> Security Class Initialized
DEBUG - 2024-06-20 09:30:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-20 09:30:09 --> Input Class Initialized
INFO - 2024-06-20 09:30:09 --> Language Class Initialized
INFO - 2024-06-20 09:30:10 --> Language Class Initialized
INFO - 2024-06-20 09:30:10 --> Config Class Initialized
INFO - 2024-06-20 09:30:10 --> Loader Class Initialized
INFO - 2024-06-20 09:30:10 --> Helper loaded: url_helper
INFO - 2024-06-20 09:30:10 --> Helper loaded: file_helper
INFO - 2024-06-20 09:30:10 --> Helper loaded: form_helper
INFO - 2024-06-20 09:30:10 --> Helper loaded: my_helper
INFO - 2024-06-20 09:30:10 --> Database Driver Class Initialized
INFO - 2024-06-20 09:30:11 --> Config Class Initialized
INFO - 2024-06-20 09:30:11 --> Hooks Class Initialized
DEBUG - 2024-06-20 09:30:11 --> UTF-8 Support Enabled
INFO - 2024-06-20 09:30:11 --> Utf8 Class Initialized
INFO - 2024-06-20 09:30:11 --> URI Class Initialized
INFO - 2024-06-20 09:30:11 --> Router Class Initialized
INFO - 2024-06-20 09:30:11 --> Output Class Initialized
INFO - 2024-06-20 09:30:11 --> Security Class Initialized
DEBUG - 2024-06-20 09:30:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-20 09:30:11 --> Input Class Initialized
INFO - 2024-06-20 09:30:11 --> Language Class Initialized
INFO - 2024-06-20 09:30:11 --> Language Class Initialized
INFO - 2024-06-20 09:30:11 --> Config Class Initialized
INFO - 2024-06-20 09:30:11 --> Loader Class Initialized
INFO - 2024-06-20 09:30:12 --> Helper loaded: url_helper
INFO - 2024-06-20 09:30:12 --> Helper loaded: file_helper
INFO - 2024-06-20 09:30:12 --> Helper loaded: form_helper
INFO - 2024-06-20 09:30:12 --> Helper loaded: my_helper
INFO - 2024-06-20 09:30:12 --> Database Driver Class Initialized
INFO - 2024-06-20 09:30:14 --> Final output sent to browser
DEBUG - 2024-06-20 09:30:14 --> Total execution time: 11.5463
INFO - 2024-06-20 09:30:14 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-20 09:30:14 --> Controller Class Initialized
DEBUG - 2024-06-20 09:30:14 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/views/cetak_tahfiz.php
INFO - 2024-06-20 09:30:14 --> Config Class Initialized
INFO - 2024-06-20 09:30:14 --> Hooks Class Initialized
DEBUG - 2024-06-20 09:30:14 --> UTF-8 Support Enabled
INFO - 2024-06-20 09:30:14 --> Utf8 Class Initialized
INFO - 2024-06-20 09:30:14 --> URI Class Initialized
INFO - 2024-06-20 09:30:14 --> Router Class Initialized
INFO - 2024-06-20 09:30:14 --> Output Class Initialized
INFO - 2024-06-20 09:30:14 --> Security Class Initialized
DEBUG - 2024-06-20 09:30:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-20 09:30:14 --> Input Class Initialized
INFO - 2024-06-20 09:30:14 --> Language Class Initialized
INFO - 2024-06-20 09:30:14 --> Language Class Initialized
INFO - 2024-06-20 09:30:14 --> Config Class Initialized
INFO - 2024-06-20 09:30:14 --> Loader Class Initialized
INFO - 2024-06-20 09:30:15 --> Helper loaded: url_helper
INFO - 2024-06-20 09:30:15 --> Helper loaded: file_helper
INFO - 2024-06-20 09:30:15 --> Helper loaded: form_helper
INFO - 2024-06-20 09:30:15 --> Helper loaded: my_helper
INFO - 2024-06-20 09:30:15 --> Database Driver Class Initialized
INFO - 2024-06-20 09:30:17 --> Final output sent to browser
DEBUG - 2024-06-20 09:30:17 --> Total execution time: 11.9669
INFO - 2024-06-20 09:30:17 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-20 09:30:17 --> Controller Class Initialized
DEBUG - 2024-06-20 09:30:17 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/views/cetak_tahfiz.php
INFO - 2024-06-20 09:30:18 --> Config Class Initialized
INFO - 2024-06-20 09:30:18 --> Hooks Class Initialized
DEBUG - 2024-06-20 09:30:18 --> UTF-8 Support Enabled
INFO - 2024-06-20 09:30:18 --> Utf8 Class Initialized
INFO - 2024-06-20 09:30:18 --> URI Class Initialized
INFO - 2024-06-20 09:30:18 --> Router Class Initialized
INFO - 2024-06-20 09:30:18 --> Output Class Initialized
INFO - 2024-06-20 09:30:18 --> Security Class Initialized
DEBUG - 2024-06-20 09:30:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-20 09:30:18 --> Input Class Initialized
INFO - 2024-06-20 09:30:18 --> Language Class Initialized
INFO - 2024-06-20 09:30:18 --> Language Class Initialized
INFO - 2024-06-20 09:30:18 --> Config Class Initialized
INFO - 2024-06-20 09:30:18 --> Loader Class Initialized
INFO - 2024-06-20 09:30:18 --> Helper loaded: url_helper
INFO - 2024-06-20 09:30:18 --> Helper loaded: file_helper
INFO - 2024-06-20 09:30:18 --> Helper loaded: form_helper
INFO - 2024-06-20 09:30:18 --> Helper loaded: my_helper
INFO - 2024-06-20 09:30:18 --> Database Driver Class Initialized
INFO - 2024-06-20 09:30:21 --> Final output sent to browser
DEBUG - 2024-06-20 09:30:21 --> Total execution time: 12.2119
INFO - 2024-06-20 09:30:21 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-20 09:30:21 --> Controller Class Initialized
DEBUG - 2024-06-20 09:30:21 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/views/cetak_tahfiz.php
INFO - 2024-06-20 09:30:21 --> Config Class Initialized
INFO - 2024-06-20 09:30:21 --> Hooks Class Initialized
DEBUG - 2024-06-20 09:30:21 --> UTF-8 Support Enabled
INFO - 2024-06-20 09:30:21 --> Utf8 Class Initialized
INFO - 2024-06-20 09:30:21 --> URI Class Initialized
INFO - 2024-06-20 09:30:21 --> Router Class Initialized
INFO - 2024-06-20 09:30:21 --> Output Class Initialized
INFO - 2024-06-20 09:30:21 --> Security Class Initialized
DEBUG - 2024-06-20 09:30:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-20 09:30:21 --> Input Class Initialized
INFO - 2024-06-20 09:30:21 --> Language Class Initialized
INFO - 2024-06-20 09:30:21 --> Language Class Initialized
INFO - 2024-06-20 09:30:21 --> Config Class Initialized
INFO - 2024-06-20 09:30:21 --> Loader Class Initialized
INFO - 2024-06-20 09:30:21 --> Helper loaded: url_helper
INFO - 2024-06-20 09:30:21 --> Helper loaded: file_helper
INFO - 2024-06-20 09:30:21 --> Helper loaded: form_helper
INFO - 2024-06-20 09:30:21 --> Helper loaded: my_helper
INFO - 2024-06-20 09:30:21 --> Database Driver Class Initialized
INFO - 2024-06-20 09:30:24 --> Config Class Initialized
INFO - 2024-06-20 09:30:24 --> Hooks Class Initialized
DEBUG - 2024-06-20 09:30:24 --> UTF-8 Support Enabled
INFO - 2024-06-20 09:30:24 --> Utf8 Class Initialized
INFO - 2024-06-20 09:30:24 --> URI Class Initialized
INFO - 2024-06-20 09:30:24 --> Router Class Initialized
INFO - 2024-06-20 09:30:24 --> Output Class Initialized
INFO - 2024-06-20 09:30:24 --> Security Class Initialized
DEBUG - 2024-06-20 09:30:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-20 09:30:24 --> Input Class Initialized
INFO - 2024-06-20 09:30:24 --> Language Class Initialized
INFO - 2024-06-20 09:30:24 --> Language Class Initialized
INFO - 2024-06-20 09:30:24 --> Config Class Initialized
INFO - 2024-06-20 09:30:24 --> Loader Class Initialized
INFO - 2024-06-20 09:30:24 --> Helper loaded: url_helper
INFO - 2024-06-20 09:30:24 --> Helper loaded: file_helper
INFO - 2024-06-20 09:30:24 --> Helper loaded: form_helper
INFO - 2024-06-20 09:30:24 --> Helper loaded: my_helper
INFO - 2024-06-20 09:30:24 --> Database Driver Class Initialized
INFO - 2024-06-20 09:30:25 --> Final output sent to browser
DEBUG - 2024-06-20 09:30:25 --> Total execution time: 13.6721
INFO - 2024-06-20 09:30:25 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-20 09:30:25 --> Controller Class Initialized
DEBUG - 2024-06-20 09:30:25 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/views/cetak_tahfiz.php
INFO - 2024-06-20 09:30:28 --> Final output sent to browser
DEBUG - 2024-06-20 09:30:28 --> Total execution time: 13.7508
INFO - 2024-06-20 09:30:28 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-20 09:30:28 --> Controller Class Initialized
DEBUG - 2024-06-20 09:30:28 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/views/cetak_tahfiz.php
INFO - 2024-06-20 09:30:29 --> Config Class Initialized
INFO - 2024-06-20 09:30:29 --> Hooks Class Initialized
DEBUG - 2024-06-20 09:30:29 --> UTF-8 Support Enabled
INFO - 2024-06-20 09:30:29 --> Utf8 Class Initialized
INFO - 2024-06-20 09:30:29 --> URI Class Initialized
INFO - 2024-06-20 09:30:29 --> Router Class Initialized
INFO - 2024-06-20 09:30:29 --> Output Class Initialized
INFO - 2024-06-20 09:30:29 --> Security Class Initialized
DEBUG - 2024-06-20 09:30:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-20 09:30:30 --> Input Class Initialized
INFO - 2024-06-20 09:30:30 --> Language Class Initialized
INFO - 2024-06-20 09:30:30 --> Language Class Initialized
INFO - 2024-06-20 09:30:30 --> Config Class Initialized
INFO - 2024-06-20 09:30:30 --> Loader Class Initialized
INFO - 2024-06-20 09:30:30 --> Helper loaded: url_helper
INFO - 2024-06-20 09:30:30 --> Helper loaded: file_helper
INFO - 2024-06-20 09:30:30 --> Helper loaded: form_helper
INFO - 2024-06-20 09:30:30 --> Helper loaded: my_helper
INFO - 2024-06-20 09:30:30 --> Database Driver Class Initialized
INFO - 2024-06-20 09:30:32 --> Final output sent to browser
DEBUG - 2024-06-20 09:30:32 --> Total execution time: 14.0618
INFO - 2024-06-20 09:30:32 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-20 09:30:32 --> Controller Class Initialized
DEBUG - 2024-06-20 09:30:32 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/views/cetak_tahfiz.php
INFO - 2024-06-20 09:30:32 --> Config Class Initialized
INFO - 2024-06-20 09:30:32 --> Hooks Class Initialized
DEBUG - 2024-06-20 09:30:32 --> UTF-8 Support Enabled
INFO - 2024-06-20 09:30:32 --> Utf8 Class Initialized
INFO - 2024-06-20 09:30:32 --> URI Class Initialized
INFO - 2024-06-20 09:30:32 --> Router Class Initialized
INFO - 2024-06-20 09:30:32 --> Output Class Initialized
INFO - 2024-06-20 09:30:32 --> Security Class Initialized
DEBUG - 2024-06-20 09:30:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-20 09:30:32 --> Input Class Initialized
INFO - 2024-06-20 09:30:32 --> Language Class Initialized
INFO - 2024-06-20 09:30:32 --> Language Class Initialized
INFO - 2024-06-20 09:30:32 --> Config Class Initialized
INFO - 2024-06-20 09:30:32 --> Loader Class Initialized
INFO - 2024-06-20 09:30:32 --> Helper loaded: url_helper
INFO - 2024-06-20 09:30:32 --> Helper loaded: file_helper
INFO - 2024-06-20 09:30:32 --> Helper loaded: form_helper
INFO - 2024-06-20 09:30:32 --> Helper loaded: my_helper
INFO - 2024-06-20 09:30:32 --> Database Driver Class Initialized
INFO - 2024-06-20 09:30:35 --> Config Class Initialized
INFO - 2024-06-20 09:30:35 --> Hooks Class Initialized
DEBUG - 2024-06-20 09:30:35 --> UTF-8 Support Enabled
INFO - 2024-06-20 09:30:35 --> Utf8 Class Initialized
INFO - 2024-06-20 09:30:35 --> URI Class Initialized
INFO - 2024-06-20 09:30:36 --> Router Class Initialized
INFO - 2024-06-20 09:30:36 --> Output Class Initialized
INFO - 2024-06-20 09:30:36 --> Security Class Initialized
INFO - 2024-06-20 09:30:36 --> Final output sent to browser
DEBUG - 2024-06-20 09:30:36 --> Total execution time: 14.6829
INFO - 2024-06-20 09:30:36 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-20 09:30:36 --> Controller Class Initialized
DEBUG - 2024-06-20 09:30:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-20 09:30:36 --> Input Class Initialized
INFO - 2024-06-20 09:30:36 --> Language Class Initialized
DEBUG - 2024-06-20 09:30:36 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/views/cetak_tahfiz.php
INFO - 2024-06-20 09:30:36 --> Language Class Initialized
INFO - 2024-06-20 09:30:36 --> Config Class Initialized
INFO - 2024-06-20 09:30:36 --> Loader Class Initialized
INFO - 2024-06-20 09:30:36 --> Helper loaded: url_helper
INFO - 2024-06-20 09:30:36 --> Helper loaded: file_helper
INFO - 2024-06-20 09:30:36 --> Helper loaded: form_helper
INFO - 2024-06-20 09:30:36 --> Helper loaded: my_helper
INFO - 2024-06-20 09:30:36 --> Database Driver Class Initialized
INFO - 2024-06-20 09:30:39 --> Config Class Initialized
INFO - 2024-06-20 09:30:39 --> Hooks Class Initialized
DEBUG - 2024-06-20 09:30:39 --> UTF-8 Support Enabled
INFO - 2024-06-20 09:30:39 --> Utf8 Class Initialized
INFO - 2024-06-20 09:30:39 --> URI Class Initialized
INFO - 2024-06-20 09:30:39 --> Router Class Initialized
INFO - 2024-06-20 09:30:39 --> Output Class Initialized
INFO - 2024-06-20 09:30:39 --> Security Class Initialized
DEBUG - 2024-06-20 09:30:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-20 09:30:39 --> Input Class Initialized
INFO - 2024-06-20 09:30:40 --> Language Class Initialized
INFO - 2024-06-20 09:30:40 --> Language Class Initialized
INFO - 2024-06-20 09:30:40 --> Config Class Initialized
INFO - 2024-06-20 09:30:40 --> Loader Class Initialized
INFO - 2024-06-20 09:30:40 --> Helper loaded: url_helper
INFO - 2024-06-20 09:30:40 --> Helper loaded: file_helper
INFO - 2024-06-20 09:30:40 --> Helper loaded: form_helper
INFO - 2024-06-20 09:30:40 --> Helper loaded: my_helper
INFO - 2024-06-20 09:30:40 --> Database Driver Class Initialized
INFO - 2024-06-20 09:30:44 --> Config Class Initialized
INFO - 2024-06-20 09:30:44 --> Hooks Class Initialized
DEBUG - 2024-06-20 09:30:44 --> UTF-8 Support Enabled
INFO - 2024-06-20 09:30:44 --> Utf8 Class Initialized
INFO - 2024-06-20 09:30:44 --> URI Class Initialized
INFO - 2024-06-20 09:30:44 --> Router Class Initialized
INFO - 2024-06-20 09:30:44 --> Output Class Initialized
INFO - 2024-06-20 09:30:44 --> Security Class Initialized
DEBUG - 2024-06-20 09:30:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-20 09:30:44 --> Input Class Initialized
INFO - 2024-06-20 09:30:44 --> Language Class Initialized
INFO - 2024-06-20 09:30:44 --> Language Class Initialized
INFO - 2024-06-20 09:30:44 --> Config Class Initialized
INFO - 2024-06-20 09:30:44 --> Loader Class Initialized
INFO - 2024-06-20 09:30:44 --> Helper loaded: url_helper
INFO - 2024-06-20 09:30:44 --> Helper loaded: file_helper
INFO - 2024-06-20 09:30:44 --> Helper loaded: form_helper
INFO - 2024-06-20 09:30:44 --> Helper loaded: my_helper
INFO - 2024-06-20 09:30:44 --> Database Driver Class Initialized
INFO - 2024-06-20 09:30:45 --> Final output sent to browser
DEBUG - 2024-06-20 09:30:45 --> Total execution time: 20.5473
INFO - 2024-06-20 09:30:45 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-20 09:30:45 --> Controller Class Initialized
DEBUG - 2024-06-20 09:30:45 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/views/cetak_tahfiz.php
INFO - 2024-06-20 09:30:47 --> Config Class Initialized
INFO - 2024-06-20 09:30:47 --> Hooks Class Initialized
DEBUG - 2024-06-20 09:30:47 --> UTF-8 Support Enabled
INFO - 2024-06-20 09:30:47 --> Utf8 Class Initialized
INFO - 2024-06-20 09:30:47 --> URI Class Initialized
INFO - 2024-06-20 09:30:47 --> Router Class Initialized
INFO - 2024-06-20 09:30:47 --> Output Class Initialized
INFO - 2024-06-20 09:30:47 --> Security Class Initialized
DEBUG - 2024-06-20 09:30:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-20 09:30:47 --> Input Class Initialized
INFO - 2024-06-20 09:30:47 --> Language Class Initialized
INFO - 2024-06-20 09:30:47 --> Language Class Initialized
INFO - 2024-06-20 09:30:47 --> Config Class Initialized
INFO - 2024-06-20 09:30:47 --> Loader Class Initialized
INFO - 2024-06-20 09:30:47 --> Helper loaded: url_helper
INFO - 2024-06-20 09:30:47 --> Helper loaded: file_helper
INFO - 2024-06-20 09:30:47 --> Helper loaded: form_helper
INFO - 2024-06-20 09:30:47 --> Helper loaded: my_helper
INFO - 2024-06-20 09:30:47 --> Database Driver Class Initialized
INFO - 2024-06-20 09:30:50 --> Config Class Initialized
INFO - 2024-06-20 09:30:50 --> Hooks Class Initialized
DEBUG - 2024-06-20 09:30:50 --> UTF-8 Support Enabled
INFO - 2024-06-20 09:30:50 --> Utf8 Class Initialized
INFO - 2024-06-20 09:30:50 --> URI Class Initialized
INFO - 2024-06-20 09:30:50 --> Router Class Initialized
INFO - 2024-06-20 09:30:50 --> Output Class Initialized
INFO - 2024-06-20 09:30:50 --> Security Class Initialized
DEBUG - 2024-06-20 09:30:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-20 09:30:50 --> Input Class Initialized
INFO - 2024-06-20 09:30:50 --> Language Class Initialized
INFO - 2024-06-20 09:30:51 --> Language Class Initialized
INFO - 2024-06-20 09:30:51 --> Config Class Initialized
INFO - 2024-06-20 09:30:51 --> Loader Class Initialized
INFO - 2024-06-20 09:30:51 --> Helper loaded: url_helper
INFO - 2024-06-20 09:30:51 --> Helper loaded: file_helper
INFO - 2024-06-20 09:30:51 --> Helper loaded: form_helper
INFO - 2024-06-20 09:30:51 --> Helper loaded: my_helper
INFO - 2024-06-20 09:30:51 --> Database Driver Class Initialized
INFO - 2024-06-20 09:30:53 --> Final output sent to browser
DEBUG - 2024-06-20 09:30:53 --> Total execution time: 24.2094
INFO - 2024-06-20 09:30:53 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-20 09:30:53 --> Controller Class Initialized
DEBUG - 2024-06-20 09:30:53 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/views/cetak_tahfiz.php
INFO - 2024-06-20 09:30:54 --> Config Class Initialized
INFO - 2024-06-20 09:30:54 --> Hooks Class Initialized
DEBUG - 2024-06-20 09:30:54 --> UTF-8 Support Enabled
INFO - 2024-06-20 09:30:54 --> Utf8 Class Initialized
INFO - 2024-06-20 09:30:54 --> URI Class Initialized
INFO - 2024-06-20 09:30:54 --> Router Class Initialized
INFO - 2024-06-20 09:30:54 --> Output Class Initialized
INFO - 2024-06-20 09:30:54 --> Security Class Initialized
DEBUG - 2024-06-20 09:30:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-20 09:30:54 --> Input Class Initialized
INFO - 2024-06-20 09:30:54 --> Language Class Initialized
INFO - 2024-06-20 09:30:54 --> Language Class Initialized
INFO - 2024-06-20 09:30:54 --> Config Class Initialized
INFO - 2024-06-20 09:30:54 --> Loader Class Initialized
INFO - 2024-06-20 09:30:54 --> Helper loaded: url_helper
INFO - 2024-06-20 09:30:54 --> Helper loaded: file_helper
INFO - 2024-06-20 09:30:54 --> Helper loaded: form_helper
INFO - 2024-06-20 09:30:54 --> Helper loaded: my_helper
INFO - 2024-06-20 09:30:54 --> Database Driver Class Initialized
INFO - 2024-06-20 09:31:08 --> Final output sent to browser
DEBUG - 2024-06-20 09:31:08 --> Total execution time: 35.3661
INFO - 2024-06-20 09:31:08 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-20 09:31:08 --> Controller Class Initialized
DEBUG - 2024-06-20 09:31:08 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/views/cetak_tahfiz.php
INFO - 2024-06-20 09:31:14 --> Final output sent to browser
DEBUG - 2024-06-20 09:31:14 --> Total execution time: 34.1431
INFO - 2024-06-20 09:31:14 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-20 09:31:14 --> Controller Class Initialized
DEBUG - 2024-06-20 09:31:14 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/views/cetak_tahfiz.php
INFO - 2024-06-20 09:31:17 --> Final output sent to browser
DEBUG - 2024-06-20 09:31:17 --> Total execution time: 33.1506
INFO - 2024-06-20 09:31:17 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-20 09:31:17 --> Controller Class Initialized
DEBUG - 2024-06-20 09:31:17 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/views/cetak_tahfiz.php
INFO - 2024-06-20 09:31:20 --> Final output sent to browser
DEBUG - 2024-06-20 09:31:20 --> Total execution time: 33.5774
INFO - 2024-06-20 09:31:20 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-20 09:31:20 --> Controller Class Initialized
DEBUG - 2024-06-20 09:31:20 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/views/cetak_tahfiz.php
INFO - 2024-06-20 09:31:24 --> Final output sent to browser
DEBUG - 2024-06-20 09:31:24 --> Total execution time: 33.4108
INFO - 2024-06-20 09:31:24 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-20 09:31:24 --> Controller Class Initialized
DEBUG - 2024-06-20 09:31:24 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/views/cetak_tahfiz.php
INFO - 2024-06-20 09:31:32 --> Final output sent to browser
DEBUG - 2024-06-20 09:31:32 --> Total execution time: 38.1319
INFO - 2024-06-20 09:31:32 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-20 09:31:32 --> Controller Class Initialized
DEBUG - 2024-06-20 09:31:32 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/views/cetak_tahfiz.php
INFO - 2024-06-20 09:31:37 --> Final output sent to browser
DEBUG - 2024-06-20 09:31:37 --> Total execution time: 62.0475
INFO - 2024-06-20 09:34:18 --> Config Class Initialized
INFO - 2024-06-20 09:34:18 --> Hooks Class Initialized
DEBUG - 2024-06-20 09:34:18 --> UTF-8 Support Enabled
INFO - 2024-06-20 09:34:18 --> Utf8 Class Initialized
INFO - 2024-06-20 09:34:18 --> URI Class Initialized
INFO - 2024-06-20 09:34:18 --> Router Class Initialized
INFO - 2024-06-20 09:34:18 --> Output Class Initialized
INFO - 2024-06-20 09:34:18 --> Security Class Initialized
DEBUG - 2024-06-20 09:34:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-20 09:34:18 --> Input Class Initialized
INFO - 2024-06-20 09:34:18 --> Language Class Initialized
INFO - 2024-06-20 09:34:18 --> Language Class Initialized
INFO - 2024-06-20 09:34:18 --> Config Class Initialized
INFO - 2024-06-20 09:34:18 --> Loader Class Initialized
INFO - 2024-06-20 09:34:18 --> Helper loaded: url_helper
INFO - 2024-06-20 09:34:18 --> Helper loaded: file_helper
INFO - 2024-06-20 09:34:18 --> Helper loaded: form_helper
INFO - 2024-06-20 09:34:18 --> Helper loaded: my_helper
INFO - 2024-06-20 09:34:18 --> Database Driver Class Initialized
INFO - 2024-06-20 09:34:18 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-20 09:34:18 --> Controller Class Initialized
INFO - 2024-06-20 09:34:18 --> Helper loaded: cookie_helper
INFO - 2024-06-20 09:34:18 --> Config Class Initialized
INFO - 2024-06-20 09:34:18 --> Hooks Class Initialized
DEBUG - 2024-06-20 09:34:18 --> UTF-8 Support Enabled
INFO - 2024-06-20 09:34:18 --> Utf8 Class Initialized
INFO - 2024-06-20 09:34:18 --> URI Class Initialized
INFO - 2024-06-20 09:34:18 --> Router Class Initialized
INFO - 2024-06-20 09:34:18 --> Output Class Initialized
INFO - 2024-06-20 09:34:18 --> Security Class Initialized
DEBUG - 2024-06-20 09:34:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-20 09:34:18 --> Input Class Initialized
INFO - 2024-06-20 09:34:18 --> Language Class Initialized
INFO - 2024-06-20 09:34:18 --> Language Class Initialized
INFO - 2024-06-20 09:34:18 --> Config Class Initialized
INFO - 2024-06-20 09:34:18 --> Loader Class Initialized
INFO - 2024-06-20 09:34:18 --> Helper loaded: url_helper
INFO - 2024-06-20 09:34:18 --> Helper loaded: file_helper
INFO - 2024-06-20 09:34:18 --> Helper loaded: form_helper
INFO - 2024-06-20 09:34:18 --> Helper loaded: my_helper
INFO - 2024-06-20 09:34:19 --> Database Driver Class Initialized
INFO - 2024-06-20 09:34:19 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-20 09:34:19 --> Controller Class Initialized
INFO - 2024-06-20 09:34:19 --> Config Class Initialized
INFO - 2024-06-20 09:34:19 --> Hooks Class Initialized
DEBUG - 2024-06-20 09:34:19 --> UTF-8 Support Enabled
INFO - 2024-06-20 09:34:19 --> Utf8 Class Initialized
INFO - 2024-06-20 09:34:19 --> URI Class Initialized
INFO - 2024-06-20 09:34:19 --> Router Class Initialized
INFO - 2024-06-20 09:34:19 --> Output Class Initialized
INFO - 2024-06-20 09:34:19 --> Security Class Initialized
DEBUG - 2024-06-20 09:34:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-20 09:34:19 --> Input Class Initialized
INFO - 2024-06-20 09:34:19 --> Language Class Initialized
INFO - 2024-06-20 09:34:19 --> Language Class Initialized
INFO - 2024-06-20 09:34:19 --> Config Class Initialized
INFO - 2024-06-20 09:34:19 --> Loader Class Initialized
INFO - 2024-06-20 09:34:19 --> Helper loaded: url_helper
INFO - 2024-06-20 09:34:19 --> Helper loaded: file_helper
INFO - 2024-06-20 09:34:19 --> Helper loaded: form_helper
INFO - 2024-06-20 09:34:19 --> Helper loaded: my_helper
INFO - 2024-06-20 09:34:19 --> Database Driver Class Initialized
INFO - 2024-06-20 09:34:19 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-20 09:34:19 --> Controller Class Initialized
DEBUG - 2024-06-20 09:34:19 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/login/views/login.php
DEBUG - 2024-06-20 09:34:19 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-06-20 09:34:19 --> Final output sent to browser
DEBUG - 2024-06-20 09:34:19 --> Total execution time: 0.1048
INFO - 2024-06-20 09:34:24 --> Config Class Initialized
INFO - 2024-06-20 09:34:24 --> Hooks Class Initialized
DEBUG - 2024-06-20 09:34:24 --> UTF-8 Support Enabled
INFO - 2024-06-20 09:34:24 --> Utf8 Class Initialized
INFO - 2024-06-20 09:34:24 --> URI Class Initialized
INFO - 2024-06-20 09:34:24 --> Router Class Initialized
INFO - 2024-06-20 09:34:24 --> Output Class Initialized
INFO - 2024-06-20 09:34:24 --> Security Class Initialized
DEBUG - 2024-06-20 09:34:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-20 09:34:24 --> Input Class Initialized
INFO - 2024-06-20 09:34:24 --> Language Class Initialized
INFO - 2024-06-20 09:34:24 --> Language Class Initialized
INFO - 2024-06-20 09:34:24 --> Config Class Initialized
INFO - 2024-06-20 09:34:24 --> Loader Class Initialized
INFO - 2024-06-20 09:34:24 --> Helper loaded: url_helper
INFO - 2024-06-20 09:34:24 --> Helper loaded: file_helper
INFO - 2024-06-20 09:34:24 --> Helper loaded: form_helper
INFO - 2024-06-20 09:34:24 --> Helper loaded: my_helper
INFO - 2024-06-20 09:34:24 --> Database Driver Class Initialized
INFO - 2024-06-20 09:34:24 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-20 09:34:24 --> Controller Class Initialized
INFO - 2024-06-20 09:34:24 --> Helper loaded: cookie_helper
INFO - 2024-06-20 09:34:24 --> Final output sent to browser
DEBUG - 2024-06-20 09:34:24 --> Total execution time: 0.2191
INFO - 2024-06-20 09:34:24 --> Config Class Initialized
INFO - 2024-06-20 09:34:24 --> Hooks Class Initialized
DEBUG - 2024-06-20 09:34:24 --> UTF-8 Support Enabled
INFO - 2024-06-20 09:34:24 --> Utf8 Class Initialized
INFO - 2024-06-20 09:34:24 --> URI Class Initialized
INFO - 2024-06-20 09:34:24 --> Router Class Initialized
INFO - 2024-06-20 09:34:24 --> Output Class Initialized
INFO - 2024-06-20 09:34:24 --> Security Class Initialized
DEBUG - 2024-06-20 09:34:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-20 09:34:24 --> Input Class Initialized
INFO - 2024-06-20 09:34:24 --> Language Class Initialized
INFO - 2024-06-20 09:34:24 --> Language Class Initialized
INFO - 2024-06-20 09:34:24 --> Config Class Initialized
INFO - 2024-06-20 09:34:24 --> Loader Class Initialized
INFO - 2024-06-20 09:34:24 --> Helper loaded: url_helper
INFO - 2024-06-20 09:34:24 --> Helper loaded: file_helper
INFO - 2024-06-20 09:34:24 --> Helper loaded: form_helper
INFO - 2024-06-20 09:34:24 --> Helper loaded: my_helper
INFO - 2024-06-20 09:34:24 --> Database Driver Class Initialized
INFO - 2024-06-20 09:34:24 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-20 09:34:24 --> Controller Class Initialized
DEBUG - 2024-06-20 09:34:24 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/home/views/v_home.php
DEBUG - 2024-06-20 09:34:24 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-06-20 09:34:24 --> Final output sent to browser
DEBUG - 2024-06-20 09:34:24 --> Total execution time: 0.0288
INFO - 2024-06-20 09:34:28 --> Config Class Initialized
INFO - 2024-06-20 09:34:28 --> Hooks Class Initialized
DEBUG - 2024-06-20 09:34:28 --> UTF-8 Support Enabled
INFO - 2024-06-20 09:34:28 --> Utf8 Class Initialized
INFO - 2024-06-20 09:34:28 --> URI Class Initialized
INFO - 2024-06-20 09:34:28 --> Router Class Initialized
INFO - 2024-06-20 09:34:28 --> Output Class Initialized
INFO - 2024-06-20 09:34:28 --> Security Class Initialized
DEBUG - 2024-06-20 09:34:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-20 09:34:28 --> Input Class Initialized
INFO - 2024-06-20 09:34:28 --> Language Class Initialized
INFO - 2024-06-20 09:34:28 --> Language Class Initialized
INFO - 2024-06-20 09:34:28 --> Config Class Initialized
INFO - 2024-06-20 09:34:28 --> Loader Class Initialized
INFO - 2024-06-20 09:34:28 --> Helper loaded: url_helper
INFO - 2024-06-20 09:34:28 --> Helper loaded: file_helper
INFO - 2024-06-20 09:34:28 --> Helper loaded: form_helper
INFO - 2024-06-20 09:34:28 --> Helper loaded: my_helper
INFO - 2024-06-20 09:34:28 --> Database Driver Class Initialized
INFO - 2024-06-20 09:34:28 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-20 09:34:28 --> Controller Class Initialized
DEBUG - 2024-06-20 09:34:28 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/data_siswa/views/list.php
DEBUG - 2024-06-20 09:34:28 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-06-20 09:34:28 --> Final output sent to browser
DEBUG - 2024-06-20 09:34:28 --> Total execution time: 0.0294
INFO - 2024-06-20 09:34:28 --> Config Class Initialized
INFO - 2024-06-20 09:34:28 --> Hooks Class Initialized
DEBUG - 2024-06-20 09:34:28 --> UTF-8 Support Enabled
INFO - 2024-06-20 09:34:28 --> Utf8 Class Initialized
INFO - 2024-06-20 09:34:28 --> URI Class Initialized
INFO - 2024-06-20 09:34:28 --> Router Class Initialized
INFO - 2024-06-20 09:34:28 --> Output Class Initialized
INFO - 2024-06-20 09:34:28 --> Security Class Initialized
DEBUG - 2024-06-20 09:34:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-20 09:34:28 --> Input Class Initialized
INFO - 2024-06-20 09:34:28 --> Language Class Initialized
ERROR - 2024-06-20 09:34:28 --> 404 Page Not Found: /index
INFO - 2024-06-20 09:34:28 --> Config Class Initialized
INFO - 2024-06-20 09:34:28 --> Hooks Class Initialized
DEBUG - 2024-06-20 09:34:28 --> UTF-8 Support Enabled
INFO - 2024-06-20 09:34:28 --> Utf8 Class Initialized
INFO - 2024-06-20 09:34:28 --> URI Class Initialized
INFO - 2024-06-20 09:34:28 --> Router Class Initialized
INFO - 2024-06-20 09:34:28 --> Output Class Initialized
INFO - 2024-06-20 09:34:28 --> Security Class Initialized
DEBUG - 2024-06-20 09:34:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-20 09:34:28 --> Input Class Initialized
INFO - 2024-06-20 09:34:28 --> Language Class Initialized
INFO - 2024-06-20 09:34:28 --> Language Class Initialized
INFO - 2024-06-20 09:34:28 --> Config Class Initialized
INFO - 2024-06-20 09:34:28 --> Loader Class Initialized
INFO - 2024-06-20 09:34:28 --> Helper loaded: url_helper
INFO - 2024-06-20 09:34:28 --> Helper loaded: file_helper
INFO - 2024-06-20 09:34:28 --> Helper loaded: form_helper
INFO - 2024-06-20 09:34:28 --> Helper loaded: my_helper
INFO - 2024-06-20 09:34:28 --> Database Driver Class Initialized
INFO - 2024-06-20 09:34:28 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-20 09:34:28 --> Controller Class Initialized
INFO - 2024-06-20 09:34:32 --> Config Class Initialized
INFO - 2024-06-20 09:34:32 --> Hooks Class Initialized
DEBUG - 2024-06-20 09:34:32 --> UTF-8 Support Enabled
INFO - 2024-06-20 09:34:32 --> Utf8 Class Initialized
INFO - 2024-06-20 09:34:32 --> URI Class Initialized
INFO - 2024-06-20 09:34:32 --> Router Class Initialized
INFO - 2024-06-20 09:34:32 --> Output Class Initialized
INFO - 2024-06-20 09:34:32 --> Security Class Initialized
DEBUG - 2024-06-20 09:34:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-20 09:34:32 --> Input Class Initialized
INFO - 2024-06-20 09:34:32 --> Language Class Initialized
INFO - 2024-06-20 09:34:32 --> Language Class Initialized
INFO - 2024-06-20 09:34:32 --> Config Class Initialized
INFO - 2024-06-20 09:34:32 --> Loader Class Initialized
INFO - 2024-06-20 09:34:32 --> Helper loaded: url_helper
INFO - 2024-06-20 09:34:32 --> Helper loaded: file_helper
INFO - 2024-06-20 09:34:32 --> Helper loaded: form_helper
INFO - 2024-06-20 09:34:32 --> Helper loaded: my_helper
INFO - 2024-06-20 09:34:32 --> Database Driver Class Initialized
INFO - 2024-06-20 09:34:32 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-20 09:34:32 --> Controller Class Initialized
ERROR - 2024-06-20 09:34:32 --> Severity: Notice --> Undefined variable: status_form /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/data_siswa/views/form.php 231
DEBUG - 2024-06-20 09:34:32 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/data_siswa/views/form.php
DEBUG - 2024-06-20 09:34:32 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-06-20 09:34:32 --> Final output sent to browser
DEBUG - 2024-06-20 09:34:32 --> Total execution time: 0.0363
INFO - 2024-06-20 09:34:41 --> Config Class Initialized
INFO - 2024-06-20 09:34:41 --> Hooks Class Initialized
DEBUG - 2024-06-20 09:34:41 --> UTF-8 Support Enabled
INFO - 2024-06-20 09:34:41 --> Utf8 Class Initialized
INFO - 2024-06-20 09:34:41 --> URI Class Initialized
INFO - 2024-06-20 09:34:41 --> Router Class Initialized
INFO - 2024-06-20 09:34:41 --> Output Class Initialized
INFO - 2024-06-20 09:34:41 --> Security Class Initialized
DEBUG - 2024-06-20 09:34:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-20 09:34:41 --> Input Class Initialized
INFO - 2024-06-20 09:34:41 --> Language Class Initialized
INFO - 2024-06-20 09:34:41 --> Language Class Initialized
INFO - 2024-06-20 09:34:41 --> Config Class Initialized
INFO - 2024-06-20 09:34:41 --> Loader Class Initialized
INFO - 2024-06-20 09:34:41 --> Helper loaded: url_helper
INFO - 2024-06-20 09:34:41 --> Helper loaded: file_helper
INFO - 2024-06-20 09:34:41 --> Helper loaded: form_helper
INFO - 2024-06-20 09:34:41 --> Helper loaded: my_helper
INFO - 2024-06-20 09:34:41 --> Database Driver Class Initialized
INFO - 2024-06-20 09:34:41 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-20 09:34:41 --> Controller Class Initialized
INFO - 2024-06-20 09:34:41 --> Upload Class Initialized
INFO - 2024-06-20 09:34:41 --> Language file loaded: language/english/upload_lang.php
ERROR - 2024-06-20 09:34:41 --> The upload path does not appear to be valid.
INFO - 2024-06-20 09:34:41 --> Config Class Initialized
INFO - 2024-06-20 09:34:41 --> Hooks Class Initialized
DEBUG - 2024-06-20 09:34:41 --> UTF-8 Support Enabled
INFO - 2024-06-20 09:34:41 --> Utf8 Class Initialized
INFO - 2024-06-20 09:34:41 --> URI Class Initialized
INFO - 2024-06-20 09:34:41 --> Router Class Initialized
INFO - 2024-06-20 09:34:41 --> Output Class Initialized
INFO - 2024-06-20 09:34:41 --> Security Class Initialized
DEBUG - 2024-06-20 09:34:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-20 09:34:41 --> Input Class Initialized
INFO - 2024-06-20 09:34:41 --> Language Class Initialized
INFO - 2024-06-20 09:34:41 --> Language Class Initialized
INFO - 2024-06-20 09:34:41 --> Config Class Initialized
INFO - 2024-06-20 09:34:41 --> Loader Class Initialized
INFO - 2024-06-20 09:34:41 --> Helper loaded: url_helper
INFO - 2024-06-20 09:34:41 --> Helper loaded: file_helper
INFO - 2024-06-20 09:34:41 --> Helper loaded: form_helper
INFO - 2024-06-20 09:34:41 --> Helper loaded: my_helper
INFO - 2024-06-20 09:34:41 --> Database Driver Class Initialized
INFO - 2024-06-20 09:34:41 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-20 09:34:41 --> Controller Class Initialized
DEBUG - 2024-06-20 09:34:41 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/data_siswa/views/list.php
DEBUG - 2024-06-20 09:34:41 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-06-20 09:34:41 --> Final output sent to browser
DEBUG - 2024-06-20 09:34:41 --> Total execution time: 0.0298
INFO - 2024-06-20 09:34:41 --> Config Class Initialized
INFO - 2024-06-20 09:34:41 --> Hooks Class Initialized
DEBUG - 2024-06-20 09:34:41 --> UTF-8 Support Enabled
INFO - 2024-06-20 09:34:41 --> Utf8 Class Initialized
INFO - 2024-06-20 09:34:41 --> URI Class Initialized
INFO - 2024-06-20 09:34:41 --> Router Class Initialized
INFO - 2024-06-20 09:34:41 --> Output Class Initialized
INFO - 2024-06-20 09:34:41 --> Security Class Initialized
DEBUG - 2024-06-20 09:34:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-20 09:34:41 --> Input Class Initialized
INFO - 2024-06-20 09:34:41 --> Language Class Initialized
ERROR - 2024-06-20 09:34:41 --> 404 Page Not Found: /index
INFO - 2024-06-20 09:34:41 --> Config Class Initialized
INFO - 2024-06-20 09:34:41 --> Hooks Class Initialized
DEBUG - 2024-06-20 09:34:41 --> UTF-8 Support Enabled
INFO - 2024-06-20 09:34:41 --> Utf8 Class Initialized
INFO - 2024-06-20 09:34:41 --> URI Class Initialized
INFO - 2024-06-20 09:34:41 --> Router Class Initialized
INFO - 2024-06-20 09:34:41 --> Output Class Initialized
INFO - 2024-06-20 09:34:41 --> Security Class Initialized
DEBUG - 2024-06-20 09:34:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-20 09:34:41 --> Input Class Initialized
INFO - 2024-06-20 09:34:41 --> Language Class Initialized
INFO - 2024-06-20 09:34:41 --> Language Class Initialized
INFO - 2024-06-20 09:34:41 --> Config Class Initialized
INFO - 2024-06-20 09:34:41 --> Loader Class Initialized
INFO - 2024-06-20 09:34:41 --> Helper loaded: url_helper
INFO - 2024-06-20 09:34:41 --> Helper loaded: file_helper
INFO - 2024-06-20 09:34:41 --> Helper loaded: form_helper
INFO - 2024-06-20 09:34:41 --> Helper loaded: my_helper
INFO - 2024-06-20 09:34:41 --> Database Driver Class Initialized
INFO - 2024-06-20 09:34:41 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-20 09:34:41 --> Controller Class Initialized
INFO - 2024-06-20 09:34:48 --> Config Class Initialized
INFO - 2024-06-20 09:34:48 --> Hooks Class Initialized
DEBUG - 2024-06-20 09:34:48 --> UTF-8 Support Enabled
INFO - 2024-06-20 09:34:48 --> Utf8 Class Initialized
INFO - 2024-06-20 09:34:48 --> URI Class Initialized
INFO - 2024-06-20 09:34:48 --> Router Class Initialized
INFO - 2024-06-20 09:34:48 --> Output Class Initialized
INFO - 2024-06-20 09:34:48 --> Security Class Initialized
DEBUG - 2024-06-20 09:34:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-20 09:34:48 --> Input Class Initialized
INFO - 2024-06-20 09:34:48 --> Language Class Initialized
INFO - 2024-06-20 09:34:48 --> Language Class Initialized
INFO - 2024-06-20 09:34:48 --> Config Class Initialized
INFO - 2024-06-20 09:34:48 --> Loader Class Initialized
INFO - 2024-06-20 09:34:48 --> Helper loaded: url_helper
INFO - 2024-06-20 09:34:48 --> Helper loaded: file_helper
INFO - 2024-06-20 09:34:48 --> Helper loaded: form_helper
INFO - 2024-06-20 09:34:48 --> Helper loaded: my_helper
INFO - 2024-06-20 09:34:48 --> Database Driver Class Initialized
INFO - 2024-06-20 09:34:48 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-20 09:34:48 --> Controller Class Initialized
INFO - 2024-06-20 09:34:48 --> Helper loaded: cookie_helper
INFO - 2024-06-20 09:34:48 --> Config Class Initialized
INFO - 2024-06-20 09:34:48 --> Hooks Class Initialized
DEBUG - 2024-06-20 09:34:48 --> UTF-8 Support Enabled
INFO - 2024-06-20 09:34:48 --> Utf8 Class Initialized
INFO - 2024-06-20 09:34:48 --> URI Class Initialized
INFO - 2024-06-20 09:34:48 --> Router Class Initialized
INFO - 2024-06-20 09:34:48 --> Output Class Initialized
INFO - 2024-06-20 09:34:48 --> Security Class Initialized
DEBUG - 2024-06-20 09:34:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-20 09:34:48 --> Input Class Initialized
INFO - 2024-06-20 09:34:48 --> Language Class Initialized
INFO - 2024-06-20 09:34:48 --> Language Class Initialized
INFO - 2024-06-20 09:34:48 --> Config Class Initialized
INFO - 2024-06-20 09:34:48 --> Loader Class Initialized
INFO - 2024-06-20 09:34:48 --> Helper loaded: url_helper
INFO - 2024-06-20 09:34:48 --> Helper loaded: file_helper
INFO - 2024-06-20 09:34:48 --> Helper loaded: form_helper
INFO - 2024-06-20 09:34:48 --> Helper loaded: my_helper
INFO - 2024-06-20 09:34:48 --> Database Driver Class Initialized
INFO - 2024-06-20 09:34:48 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-20 09:34:48 --> Controller Class Initialized
INFO - 2024-06-20 09:34:48 --> Config Class Initialized
INFO - 2024-06-20 09:34:48 --> Hooks Class Initialized
DEBUG - 2024-06-20 09:34:48 --> UTF-8 Support Enabled
INFO - 2024-06-20 09:34:48 --> Utf8 Class Initialized
INFO - 2024-06-20 09:34:48 --> URI Class Initialized
INFO - 2024-06-20 09:34:48 --> Router Class Initialized
INFO - 2024-06-20 09:34:48 --> Output Class Initialized
INFO - 2024-06-20 09:34:48 --> Security Class Initialized
DEBUG - 2024-06-20 09:34:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-20 09:34:48 --> Input Class Initialized
INFO - 2024-06-20 09:34:48 --> Language Class Initialized
INFO - 2024-06-20 09:34:48 --> Language Class Initialized
INFO - 2024-06-20 09:34:48 --> Config Class Initialized
INFO - 2024-06-20 09:34:48 --> Loader Class Initialized
INFO - 2024-06-20 09:34:48 --> Helper loaded: url_helper
INFO - 2024-06-20 09:34:48 --> Helper loaded: file_helper
INFO - 2024-06-20 09:34:48 --> Helper loaded: form_helper
INFO - 2024-06-20 09:34:48 --> Helper loaded: my_helper
INFO - 2024-06-20 09:34:48 --> Database Driver Class Initialized
INFO - 2024-06-20 09:34:48 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-20 09:34:48 --> Controller Class Initialized
DEBUG - 2024-06-20 09:34:48 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/login/views/login.php
DEBUG - 2024-06-20 09:34:48 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-06-20 09:34:48 --> Final output sent to browser
DEBUG - 2024-06-20 09:34:48 --> Total execution time: 0.0378
INFO - 2024-06-20 09:34:54 --> Config Class Initialized
INFO - 2024-06-20 09:34:54 --> Hooks Class Initialized
DEBUG - 2024-06-20 09:34:54 --> UTF-8 Support Enabled
INFO - 2024-06-20 09:34:54 --> Utf8 Class Initialized
INFO - 2024-06-20 09:34:54 --> URI Class Initialized
INFO - 2024-06-20 09:34:54 --> Router Class Initialized
INFO - 2024-06-20 09:34:54 --> Output Class Initialized
INFO - 2024-06-20 09:34:54 --> Security Class Initialized
DEBUG - 2024-06-20 09:34:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-20 09:34:54 --> Input Class Initialized
INFO - 2024-06-20 09:34:54 --> Language Class Initialized
INFO - 2024-06-20 09:34:54 --> Language Class Initialized
INFO - 2024-06-20 09:34:54 --> Config Class Initialized
INFO - 2024-06-20 09:34:54 --> Loader Class Initialized
INFO - 2024-06-20 09:34:54 --> Helper loaded: url_helper
INFO - 2024-06-20 09:34:54 --> Helper loaded: file_helper
INFO - 2024-06-20 09:34:54 --> Helper loaded: form_helper
INFO - 2024-06-20 09:34:54 --> Helper loaded: my_helper
INFO - 2024-06-20 09:34:54 --> Database Driver Class Initialized
INFO - 2024-06-20 09:34:54 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-20 09:34:54 --> Controller Class Initialized
INFO - 2024-06-20 09:34:54 --> Helper loaded: cookie_helper
INFO - 2024-06-20 09:34:54 --> Final output sent to browser
DEBUG - 2024-06-20 09:34:54 --> Total execution time: 0.0263
INFO - 2024-06-20 09:34:55 --> Config Class Initialized
INFO - 2024-06-20 09:34:55 --> Hooks Class Initialized
DEBUG - 2024-06-20 09:34:55 --> UTF-8 Support Enabled
INFO - 2024-06-20 09:34:55 --> Utf8 Class Initialized
INFO - 2024-06-20 09:34:55 --> URI Class Initialized
INFO - 2024-06-20 09:34:55 --> Router Class Initialized
INFO - 2024-06-20 09:34:55 --> Output Class Initialized
INFO - 2024-06-20 09:34:55 --> Security Class Initialized
DEBUG - 2024-06-20 09:34:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-20 09:34:55 --> Input Class Initialized
INFO - 2024-06-20 09:34:55 --> Language Class Initialized
INFO - 2024-06-20 09:34:55 --> Language Class Initialized
INFO - 2024-06-20 09:34:55 --> Config Class Initialized
INFO - 2024-06-20 09:34:55 --> Loader Class Initialized
INFO - 2024-06-20 09:34:55 --> Helper loaded: url_helper
INFO - 2024-06-20 09:34:55 --> Helper loaded: file_helper
INFO - 2024-06-20 09:34:55 --> Helper loaded: form_helper
INFO - 2024-06-20 09:34:55 --> Helper loaded: my_helper
INFO - 2024-06-20 09:34:55 --> Database Driver Class Initialized
INFO - 2024-06-20 09:34:55 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-20 09:34:55 --> Controller Class Initialized
DEBUG - 2024-06-20 09:34:55 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/home/views/v_home_guru.php
DEBUG - 2024-06-20 09:34:55 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-06-20 09:34:55 --> Final output sent to browser
DEBUG - 2024-06-20 09:34:55 --> Total execution time: 0.0288
INFO - 2024-06-20 09:36:02 --> Config Class Initialized
INFO - 2024-06-20 09:36:02 --> Hooks Class Initialized
DEBUG - 2024-06-20 09:36:02 --> UTF-8 Support Enabled
INFO - 2024-06-20 09:36:02 --> Utf8 Class Initialized
INFO - 2024-06-20 09:36:02 --> URI Class Initialized
INFO - 2024-06-20 09:36:02 --> Router Class Initialized
INFO - 2024-06-20 09:36:02 --> Output Class Initialized
INFO - 2024-06-20 09:36:02 --> Security Class Initialized
DEBUG - 2024-06-20 09:36:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-20 09:36:02 --> Input Class Initialized
INFO - 2024-06-20 09:36:02 --> Language Class Initialized
INFO - 2024-06-20 09:36:02 --> Language Class Initialized
INFO - 2024-06-20 09:36:02 --> Config Class Initialized
INFO - 2024-06-20 09:36:02 --> Loader Class Initialized
INFO - 2024-06-20 09:36:02 --> Helper loaded: url_helper
INFO - 2024-06-20 09:36:02 --> Helper loaded: file_helper
INFO - 2024-06-20 09:36:02 --> Helper loaded: form_helper
INFO - 2024-06-20 09:36:02 --> Helper loaded: my_helper
INFO - 2024-06-20 09:36:02 --> Database Driver Class Initialized
INFO - 2024-06-20 09:36:02 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-20 09:36:02 --> Controller Class Initialized
DEBUG - 2024-06-20 09:36:02 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/views/list.php
DEBUG - 2024-06-20 09:36:02 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-06-20 09:36:02 --> Final output sent to browser
DEBUG - 2024-06-20 09:36:02 --> Total execution time: 0.0423
INFO - 2024-06-20 09:36:06 --> Config Class Initialized
INFO - 2024-06-20 09:36:06 --> Hooks Class Initialized
DEBUG - 2024-06-20 09:36:06 --> UTF-8 Support Enabled
INFO - 2024-06-20 09:36:06 --> Utf8 Class Initialized
INFO - 2024-06-20 09:36:06 --> URI Class Initialized
INFO - 2024-06-20 09:36:06 --> Router Class Initialized
INFO - 2024-06-20 09:36:06 --> Output Class Initialized
INFO - 2024-06-20 09:36:06 --> Security Class Initialized
DEBUG - 2024-06-20 09:36:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-20 09:36:06 --> Input Class Initialized
INFO - 2024-06-20 09:36:06 --> Language Class Initialized
INFO - 2024-06-20 09:36:06 --> Language Class Initialized
INFO - 2024-06-20 09:36:06 --> Config Class Initialized
INFO - 2024-06-20 09:36:06 --> Loader Class Initialized
INFO - 2024-06-20 09:36:06 --> Helper loaded: url_helper
INFO - 2024-06-20 09:36:06 --> Helper loaded: file_helper
INFO - 2024-06-20 09:36:06 --> Helper loaded: form_helper
INFO - 2024-06-20 09:36:06 --> Helper loaded: my_helper
INFO - 2024-06-20 09:36:06 --> Database Driver Class Initialized
INFO - 2024-06-20 09:36:06 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-20 09:36:06 --> Controller Class Initialized
DEBUG - 2024-06-20 09:36:06 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/views/cetak_ikm.php
INFO - 2024-06-20 09:36:07 --> Final output sent to browser
DEBUG - 2024-06-20 09:36:07 --> Total execution time: 1.6672
INFO - 2024-06-20 09:36:31 --> Config Class Initialized
INFO - 2024-06-20 09:36:31 --> Hooks Class Initialized
DEBUG - 2024-06-20 09:36:31 --> UTF-8 Support Enabled
INFO - 2024-06-20 09:36:31 --> Utf8 Class Initialized
INFO - 2024-06-20 09:36:31 --> URI Class Initialized
INFO - 2024-06-20 09:36:31 --> Router Class Initialized
INFO - 2024-06-20 09:36:31 --> Output Class Initialized
INFO - 2024-06-20 09:36:31 --> Security Class Initialized
DEBUG - 2024-06-20 09:36:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-20 09:36:31 --> Input Class Initialized
INFO - 2024-06-20 09:36:31 --> Language Class Initialized
INFO - 2024-06-20 09:36:31 --> Language Class Initialized
INFO - 2024-06-20 09:36:31 --> Config Class Initialized
INFO - 2024-06-20 09:36:31 --> Loader Class Initialized
INFO - 2024-06-20 09:36:31 --> Helper loaded: url_helper
INFO - 2024-06-20 09:36:31 --> Helper loaded: file_helper
INFO - 2024-06-20 09:36:31 --> Helper loaded: form_helper
INFO - 2024-06-20 09:36:31 --> Helper loaded: my_helper
INFO - 2024-06-20 09:36:31 --> Database Driver Class Initialized
INFO - 2024-06-20 09:36:31 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-20 09:36:31 --> Controller Class Initialized
ERROR - 2024-06-20 09:36:31 --> Severity: Notice --> Undefined index: projek /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1837
ERROR - 2024-06-20 09:36:31 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2024-06-20 09:36:31 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2024-06-20 09:36:31 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2024-06-20 09:36:31 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2024-06-20 09:36:31 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2024-06-20 09:36:31 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2024-06-20 09:36:31 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2024-06-20 09:36:31 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2024-06-20 09:36:31 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2024-06-20 09:36:31 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2024-06-20 09:36:31 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2024-06-20 09:36:31 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2024-06-20 09:36:31 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2024-06-20 09:36:31 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2024-06-20 09:36:31 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2024-06-20 09:36:31 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2024-06-20 09:36:31 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2024-06-20 09:36:31 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2024-06-20 09:36:31 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2024-06-20 09:36:31 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2024-06-20 09:36:31 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2024-06-20 09:36:31 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2024-06-20 09:36:31 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2024-06-20 09:36:31 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2024-06-20 09:36:31 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2024-06-20 09:36:31 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2024-06-20 09:36:31 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2024-06-20 09:36:31 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2024-06-20 09:36:31 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2024-06-20 09:36:31 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2024-06-20 09:36:31 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2024-06-20 09:36:31 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2024-06-20 09:36:31 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2024-06-20 09:36:31 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2024-06-20 09:36:31 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2024-06-20 09:36:31 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2024-06-20 09:36:31 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2024-06-20 09:36:31 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2024-06-20 09:36:31 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
DEBUG - 2024-06-20 09:36:31 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/views/cetak_projek.php
INFO - 2024-06-20 09:36:34 --> Config Class Initialized
INFO - 2024-06-20 09:36:34 --> Hooks Class Initialized
DEBUG - 2024-06-20 09:36:34 --> UTF-8 Support Enabled
INFO - 2024-06-20 09:36:34 --> Utf8 Class Initialized
INFO - 2024-06-20 09:36:34 --> URI Class Initialized
INFO - 2024-06-20 09:36:35 --> Router Class Initialized
INFO - 2024-06-20 09:36:35 --> Output Class Initialized
INFO - 2024-06-20 09:36:35 --> Security Class Initialized
DEBUG - 2024-06-20 09:36:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-20 09:36:35 --> Input Class Initialized
INFO - 2024-06-20 09:36:35 --> Language Class Initialized
INFO - 2024-06-20 09:36:35 --> Language Class Initialized
INFO - 2024-06-20 09:36:35 --> Config Class Initialized
INFO - 2024-06-20 09:36:35 --> Loader Class Initialized
INFO - 2024-06-20 09:36:35 --> Helper loaded: url_helper
INFO - 2024-06-20 09:36:35 --> Helper loaded: file_helper
INFO - 2024-06-20 09:36:35 --> Helper loaded: form_helper
INFO - 2024-06-20 09:36:35 --> Helper loaded: my_helper
INFO - 2024-06-20 09:36:35 --> Database Driver Class Initialized
INFO - 2024-06-20 09:36:35 --> Final output sent to browser
DEBUG - 2024-06-20 09:36:35 --> Total execution time: 4.7539
INFO - 2024-06-20 09:36:35 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-20 09:36:35 --> Controller Class Initialized
DEBUG - 2024-06-20 09:36:35 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/views/cetak_mh.php
INFO - 2024-06-20 09:36:37 --> Config Class Initialized
INFO - 2024-06-20 09:36:37 --> Hooks Class Initialized
DEBUG - 2024-06-20 09:36:37 --> UTF-8 Support Enabled
INFO - 2024-06-20 09:36:37 --> Utf8 Class Initialized
INFO - 2024-06-20 09:36:37 --> URI Class Initialized
INFO - 2024-06-20 09:36:37 --> Router Class Initialized
INFO - 2024-06-20 09:36:37 --> Output Class Initialized
INFO - 2024-06-20 09:36:37 --> Security Class Initialized
DEBUG - 2024-06-20 09:36:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-20 09:36:37 --> Input Class Initialized
INFO - 2024-06-20 09:36:37 --> Language Class Initialized
INFO - 2024-06-20 09:36:37 --> Language Class Initialized
INFO - 2024-06-20 09:36:37 --> Config Class Initialized
INFO - 2024-06-20 09:36:37 --> Loader Class Initialized
INFO - 2024-06-20 09:36:37 --> Helper loaded: url_helper
INFO - 2024-06-20 09:36:37 --> Helper loaded: file_helper
INFO - 2024-06-20 09:36:37 --> Helper loaded: form_helper
INFO - 2024-06-20 09:36:37 --> Helper loaded: my_helper
INFO - 2024-06-20 09:36:37 --> Database Driver Class Initialized
INFO - 2024-06-20 09:36:39 --> Final output sent to browser
DEBUG - 2024-06-20 09:36:39 --> Total execution time: 4.8160
INFO - 2024-06-20 09:36:39 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-20 09:36:39 --> Controller Class Initialized
DEBUG - 2024-06-20 09:36:39 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/views/cetak_tahfiz.php
INFO - 2024-06-20 09:36:43 --> Final output sent to browser
DEBUG - 2024-06-20 09:36:43 --> Total execution time: 5.7942
INFO - 2024-06-20 09:37:38 --> Config Class Initialized
INFO - 2024-06-20 09:37:38 --> Hooks Class Initialized
DEBUG - 2024-06-20 09:37:38 --> UTF-8 Support Enabled
INFO - 2024-06-20 09:37:38 --> Utf8 Class Initialized
INFO - 2024-06-20 09:37:38 --> URI Class Initialized
INFO - 2024-06-20 09:37:38 --> Router Class Initialized
INFO - 2024-06-20 09:37:38 --> Output Class Initialized
INFO - 2024-06-20 09:37:38 --> Security Class Initialized
DEBUG - 2024-06-20 09:37:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-20 09:37:38 --> Input Class Initialized
INFO - 2024-06-20 09:37:38 --> Language Class Initialized
INFO - 2024-06-20 09:37:38 --> Language Class Initialized
INFO - 2024-06-20 09:37:38 --> Config Class Initialized
INFO - 2024-06-20 09:37:38 --> Loader Class Initialized
INFO - 2024-06-20 09:37:38 --> Helper loaded: url_helper
INFO - 2024-06-20 09:37:38 --> Helper loaded: file_helper
INFO - 2024-06-20 09:37:38 --> Helper loaded: form_helper
INFO - 2024-06-20 09:37:38 --> Helper loaded: my_helper
INFO - 2024-06-20 09:37:38 --> Database Driver Class Initialized
INFO - 2024-06-20 09:37:38 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-20 09:37:38 --> Controller Class Initialized
DEBUG - 2024-06-20 09:37:38 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/views/cetak_mh.php
INFO - 2024-06-20 09:37:43 --> Final output sent to browser
DEBUG - 2024-06-20 09:37:43 --> Total execution time: 4.2180
INFO - 2024-06-20 09:41:22 --> Config Class Initialized
INFO - 2024-06-20 09:41:22 --> Hooks Class Initialized
DEBUG - 2024-06-20 09:41:22 --> UTF-8 Support Enabled
INFO - 2024-06-20 09:41:22 --> Utf8 Class Initialized
INFO - 2024-06-20 09:41:22 --> URI Class Initialized
INFO - 2024-06-20 09:41:22 --> Router Class Initialized
INFO - 2024-06-20 09:41:22 --> Output Class Initialized
INFO - 2024-06-20 09:41:22 --> Security Class Initialized
DEBUG - 2024-06-20 09:41:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-20 09:41:22 --> Input Class Initialized
INFO - 2024-06-20 09:41:22 --> Language Class Initialized
INFO - 2024-06-20 09:41:22 --> Language Class Initialized
INFO - 2024-06-20 09:41:22 --> Config Class Initialized
INFO - 2024-06-20 09:41:22 --> Loader Class Initialized
INFO - 2024-06-20 09:41:22 --> Helper loaded: url_helper
INFO - 2024-06-20 09:41:22 --> Helper loaded: file_helper
INFO - 2024-06-20 09:41:22 --> Helper loaded: form_helper
INFO - 2024-06-20 09:41:22 --> Helper loaded: my_helper
INFO - 2024-06-20 09:41:22 --> Database Driver Class Initialized
INFO - 2024-06-20 09:41:22 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-20 09:41:22 --> Controller Class Initialized
DEBUG - 2024-06-20 09:41:22 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/view_mapel/views/v_view_mapel.php
DEBUG - 2024-06-20 09:41:22 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-06-20 09:41:22 --> Final output sent to browser
DEBUG - 2024-06-20 09:41:22 --> Total execution time: 0.0287
INFO - 2024-06-20 09:41:27 --> Config Class Initialized
INFO - 2024-06-20 09:41:27 --> Hooks Class Initialized
DEBUG - 2024-06-20 09:41:27 --> UTF-8 Support Enabled
INFO - 2024-06-20 09:41:27 --> Utf8 Class Initialized
INFO - 2024-06-20 09:41:27 --> URI Class Initialized
INFO - 2024-06-20 09:41:27 --> Router Class Initialized
INFO - 2024-06-20 09:41:27 --> Output Class Initialized
INFO - 2024-06-20 09:41:27 --> Security Class Initialized
DEBUG - 2024-06-20 09:41:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-20 09:41:27 --> Input Class Initialized
INFO - 2024-06-20 09:41:27 --> Language Class Initialized
INFO - 2024-06-20 09:41:27 --> Language Class Initialized
INFO - 2024-06-20 09:41:27 --> Config Class Initialized
INFO - 2024-06-20 09:41:27 --> Loader Class Initialized
INFO - 2024-06-20 09:41:27 --> Helper loaded: url_helper
INFO - 2024-06-20 09:41:27 --> Helper loaded: file_helper
INFO - 2024-06-20 09:41:27 --> Helper loaded: form_helper
INFO - 2024-06-20 09:41:27 --> Helper loaded: my_helper
INFO - 2024-06-20 09:41:27 --> Database Driver Class Initialized
INFO - 2024-06-20 09:41:27 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-20 09:41:27 --> Controller Class Initialized
DEBUG - 2024-06-20 09:41:27 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/views/list.php
DEBUG - 2024-06-20 09:41:27 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-06-20 09:41:27 --> Final output sent to browser
DEBUG - 2024-06-20 09:41:27 --> Total execution time: 0.0308
INFO - 2024-06-20 09:41:27 --> Config Class Initialized
INFO - 2024-06-20 09:41:27 --> Hooks Class Initialized
DEBUG - 2024-06-20 09:41:27 --> UTF-8 Support Enabled
INFO - 2024-06-20 09:41:27 --> Utf8 Class Initialized
INFO - 2024-06-20 09:41:27 --> URI Class Initialized
INFO - 2024-06-20 09:41:27 --> Router Class Initialized
INFO - 2024-06-20 09:41:27 --> Output Class Initialized
INFO - 2024-06-20 09:41:27 --> Security Class Initialized
DEBUG - 2024-06-20 09:41:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-20 09:41:27 --> Input Class Initialized
INFO - 2024-06-20 09:41:27 --> Language Class Initialized
INFO - 2024-06-20 09:41:27 --> Language Class Initialized
INFO - 2024-06-20 09:41:27 --> Config Class Initialized
INFO - 2024-06-20 09:41:27 --> Loader Class Initialized
INFO - 2024-06-20 09:41:27 --> Helper loaded: url_helper
INFO - 2024-06-20 09:41:27 --> Helper loaded: file_helper
INFO - 2024-06-20 09:41:27 --> Helper loaded: form_helper
INFO - 2024-06-20 09:41:27 --> Helper loaded: my_helper
INFO - 2024-06-20 09:41:27 --> Database Driver Class Initialized
INFO - 2024-06-20 09:41:27 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-20 09:41:27 --> Controller Class Initialized
INFO - 2024-06-20 09:41:31 --> Config Class Initialized
INFO - 2024-06-20 09:41:31 --> Hooks Class Initialized
DEBUG - 2024-06-20 09:41:31 --> UTF-8 Support Enabled
INFO - 2024-06-20 09:41:31 --> Utf8 Class Initialized
INFO - 2024-06-20 09:41:31 --> URI Class Initialized
INFO - 2024-06-20 09:41:31 --> Router Class Initialized
INFO - 2024-06-20 09:41:31 --> Output Class Initialized
INFO - 2024-06-20 09:41:31 --> Security Class Initialized
DEBUG - 2024-06-20 09:41:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-20 09:41:31 --> Input Class Initialized
INFO - 2024-06-20 09:41:31 --> Language Class Initialized
INFO - 2024-06-20 09:41:31 --> Language Class Initialized
INFO - 2024-06-20 09:41:31 --> Config Class Initialized
INFO - 2024-06-20 09:41:31 --> Loader Class Initialized
INFO - 2024-06-20 09:41:31 --> Helper loaded: url_helper
INFO - 2024-06-20 09:41:31 --> Helper loaded: file_helper
INFO - 2024-06-20 09:41:31 --> Helper loaded: form_helper
INFO - 2024-06-20 09:41:31 --> Helper loaded: my_helper
INFO - 2024-06-20 09:41:31 --> Database Driver Class Initialized
INFO - 2024-06-20 09:41:31 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-20 09:41:31 --> Controller Class Initialized
INFO - 2024-06-20 09:41:31 --> Final output sent to browser
DEBUG - 2024-06-20 09:41:31 --> Total execution time: 0.0304
INFO - 2024-06-20 09:41:38 --> Config Class Initialized
INFO - 2024-06-20 09:41:38 --> Hooks Class Initialized
DEBUG - 2024-06-20 09:41:38 --> UTF-8 Support Enabled
INFO - 2024-06-20 09:41:38 --> Utf8 Class Initialized
INFO - 2024-06-20 09:41:38 --> URI Class Initialized
INFO - 2024-06-20 09:41:38 --> Router Class Initialized
INFO - 2024-06-20 09:41:38 --> Output Class Initialized
INFO - 2024-06-20 09:41:38 --> Security Class Initialized
DEBUG - 2024-06-20 09:41:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-20 09:41:38 --> Input Class Initialized
INFO - 2024-06-20 09:41:38 --> Language Class Initialized
INFO - 2024-06-20 09:41:38 --> Language Class Initialized
INFO - 2024-06-20 09:41:38 --> Config Class Initialized
INFO - 2024-06-20 09:41:38 --> Loader Class Initialized
INFO - 2024-06-20 09:41:38 --> Helper loaded: url_helper
INFO - 2024-06-20 09:41:38 --> Helper loaded: file_helper
INFO - 2024-06-20 09:41:38 --> Helper loaded: form_helper
INFO - 2024-06-20 09:41:38 --> Helper loaded: my_helper
INFO - 2024-06-20 09:41:38 --> Database Driver Class Initialized
INFO - 2024-06-20 09:41:38 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-20 09:41:38 --> Controller Class Initialized
INFO - 2024-06-20 09:41:38 --> Final output sent to browser
DEBUG - 2024-06-20 09:41:38 --> Total execution time: 0.0843
INFO - 2024-06-20 09:44:01 --> Config Class Initialized
INFO - 2024-06-20 09:44:01 --> Hooks Class Initialized
DEBUG - 2024-06-20 09:44:01 --> UTF-8 Support Enabled
INFO - 2024-06-20 09:44:01 --> Utf8 Class Initialized
INFO - 2024-06-20 09:44:01 --> URI Class Initialized
INFO - 2024-06-20 09:44:01 --> Router Class Initialized
INFO - 2024-06-20 09:44:01 --> Output Class Initialized
INFO - 2024-06-20 09:44:01 --> Security Class Initialized
DEBUG - 2024-06-20 09:44:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-20 09:44:01 --> Input Class Initialized
INFO - 2024-06-20 09:44:01 --> Language Class Initialized
INFO - 2024-06-20 09:44:01 --> Language Class Initialized
INFO - 2024-06-20 09:44:01 --> Config Class Initialized
INFO - 2024-06-20 09:44:01 --> Loader Class Initialized
INFO - 2024-06-20 09:44:01 --> Helper loaded: url_helper
INFO - 2024-06-20 09:44:01 --> Helper loaded: file_helper
INFO - 2024-06-20 09:44:01 --> Helper loaded: form_helper
INFO - 2024-06-20 09:44:01 --> Helper loaded: my_helper
INFO - 2024-06-20 09:44:01 --> Database Driver Class Initialized
INFO - 2024-06-20 09:44:01 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-20 09:44:01 --> Controller Class Initialized
DEBUG - 2024-06-20 09:44:01 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/views/list.php
DEBUG - 2024-06-20 09:44:01 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-06-20 09:44:01 --> Final output sent to browser
DEBUG - 2024-06-20 09:44:01 --> Total execution time: 0.0439
INFO - 2024-06-20 09:44:06 --> Config Class Initialized
INFO - 2024-06-20 09:44:06 --> Hooks Class Initialized
DEBUG - 2024-06-20 09:44:06 --> UTF-8 Support Enabled
INFO - 2024-06-20 09:44:06 --> Utf8 Class Initialized
INFO - 2024-06-20 09:44:06 --> URI Class Initialized
INFO - 2024-06-20 09:44:06 --> Router Class Initialized
INFO - 2024-06-20 09:44:06 --> Output Class Initialized
INFO - 2024-06-20 09:44:06 --> Security Class Initialized
DEBUG - 2024-06-20 09:44:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-20 09:44:06 --> Input Class Initialized
INFO - 2024-06-20 09:44:06 --> Language Class Initialized
INFO - 2024-06-20 09:44:06 --> Language Class Initialized
INFO - 2024-06-20 09:44:06 --> Config Class Initialized
INFO - 2024-06-20 09:44:06 --> Loader Class Initialized
INFO - 2024-06-20 09:44:06 --> Helper loaded: url_helper
INFO - 2024-06-20 09:44:06 --> Helper loaded: file_helper
INFO - 2024-06-20 09:44:06 --> Helper loaded: form_helper
INFO - 2024-06-20 09:44:06 --> Helper loaded: my_helper
INFO - 2024-06-20 09:44:06 --> Database Driver Class Initialized
INFO - 2024-06-20 09:44:06 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-20 09:44:06 --> Controller Class Initialized
ERROR - 2024-06-20 09:44:06 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 3014
ERROR - 2024-06-20 09:44:06 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 3015
DEBUG - 2024-06-20 09:44:06 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/views/cetak_mh.php
INFO - 2024-06-20 09:44:10 --> Final output sent to browser
DEBUG - 2024-06-20 09:44:10 --> Total execution time: 4.0274
INFO - 2024-06-20 09:45:36 --> Config Class Initialized
INFO - 2024-06-20 09:45:36 --> Hooks Class Initialized
DEBUG - 2024-06-20 09:45:36 --> UTF-8 Support Enabled
INFO - 2024-06-20 09:45:36 --> Utf8 Class Initialized
INFO - 2024-06-20 09:45:36 --> URI Class Initialized
INFO - 2024-06-20 09:45:36 --> Router Class Initialized
INFO - 2024-06-20 09:45:36 --> Output Class Initialized
INFO - 2024-06-20 09:45:36 --> Security Class Initialized
DEBUG - 2024-06-20 09:45:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-20 09:45:36 --> Input Class Initialized
INFO - 2024-06-20 09:45:36 --> Language Class Initialized
INFO - 2024-06-20 09:45:36 --> Language Class Initialized
INFO - 2024-06-20 09:45:36 --> Config Class Initialized
INFO - 2024-06-20 09:45:36 --> Loader Class Initialized
INFO - 2024-06-20 09:45:36 --> Helper loaded: url_helper
INFO - 2024-06-20 09:45:36 --> Helper loaded: file_helper
INFO - 2024-06-20 09:45:36 --> Helper loaded: form_helper
INFO - 2024-06-20 09:45:36 --> Helper loaded: my_helper
INFO - 2024-06-20 09:45:36 --> Database Driver Class Initialized
INFO - 2024-06-20 09:45:36 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-20 09:45:36 --> Controller Class Initialized
DEBUG - 2024-06-20 09:45:36 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/views/list.php
DEBUG - 2024-06-20 09:45:36 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-06-20 09:45:36 --> Final output sent to browser
DEBUG - 2024-06-20 09:45:36 --> Total execution time: 0.0303
INFO - 2024-06-20 09:45:37 --> Config Class Initialized
INFO - 2024-06-20 09:45:37 --> Hooks Class Initialized
DEBUG - 2024-06-20 09:45:37 --> UTF-8 Support Enabled
INFO - 2024-06-20 09:45:37 --> Utf8 Class Initialized
INFO - 2024-06-20 09:45:37 --> URI Class Initialized
INFO - 2024-06-20 09:45:37 --> Router Class Initialized
INFO - 2024-06-20 09:45:37 --> Output Class Initialized
INFO - 2024-06-20 09:45:37 --> Security Class Initialized
DEBUG - 2024-06-20 09:45:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-20 09:45:37 --> Input Class Initialized
INFO - 2024-06-20 09:45:37 --> Language Class Initialized
INFO - 2024-06-20 09:45:37 --> Language Class Initialized
INFO - 2024-06-20 09:45:37 --> Config Class Initialized
INFO - 2024-06-20 09:45:37 --> Loader Class Initialized
INFO - 2024-06-20 09:45:37 --> Helper loaded: url_helper
INFO - 2024-06-20 09:45:37 --> Helper loaded: file_helper
INFO - 2024-06-20 09:45:37 --> Helper loaded: form_helper
INFO - 2024-06-20 09:45:37 --> Helper loaded: my_helper
INFO - 2024-06-20 09:45:37 --> Database Driver Class Initialized
INFO - 2024-06-20 09:45:37 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-20 09:45:37 --> Controller Class Initialized
DEBUG - 2024-06-20 09:45:37 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/views/list.php
DEBUG - 2024-06-20 09:45:37 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-06-20 09:45:37 --> Final output sent to browser
DEBUG - 2024-06-20 09:45:37 --> Total execution time: 0.0335
INFO - 2024-06-20 09:45:38 --> Config Class Initialized
INFO - 2024-06-20 09:45:38 --> Hooks Class Initialized
DEBUG - 2024-06-20 09:45:38 --> UTF-8 Support Enabled
INFO - 2024-06-20 09:45:38 --> Utf8 Class Initialized
INFO - 2024-06-20 09:45:38 --> URI Class Initialized
DEBUG - 2024-06-20 09:45:38 --> No URI present. Default controller set.
INFO - 2024-06-20 09:45:38 --> Router Class Initialized
INFO - 2024-06-20 09:45:38 --> Output Class Initialized
INFO - 2024-06-20 09:45:38 --> Security Class Initialized
DEBUG - 2024-06-20 09:45:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-20 09:45:38 --> Input Class Initialized
INFO - 2024-06-20 09:45:38 --> Language Class Initialized
INFO - 2024-06-20 09:45:38 --> Language Class Initialized
INFO - 2024-06-20 09:45:38 --> Config Class Initialized
INFO - 2024-06-20 09:45:38 --> Loader Class Initialized
INFO - 2024-06-20 09:45:38 --> Helper loaded: url_helper
INFO - 2024-06-20 09:45:38 --> Helper loaded: file_helper
INFO - 2024-06-20 09:45:38 --> Helper loaded: form_helper
INFO - 2024-06-20 09:45:38 --> Helper loaded: my_helper
INFO - 2024-06-20 09:45:38 --> Database Driver Class Initialized
INFO - 2024-06-20 09:45:38 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-20 09:45:38 --> Controller Class Initialized
DEBUG - 2024-06-20 09:45:38 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/home/views/v_home_guru.php
DEBUG - 2024-06-20 09:45:38 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-06-20 09:45:38 --> Final output sent to browser
DEBUG - 2024-06-20 09:45:38 --> Total execution time: 0.0271
INFO - 2024-06-20 09:45:42 --> Config Class Initialized
INFO - 2024-06-20 09:45:42 --> Hooks Class Initialized
DEBUG - 2024-06-20 09:45:42 --> UTF-8 Support Enabled
INFO - 2024-06-20 09:45:42 --> Utf8 Class Initialized
INFO - 2024-06-20 09:45:42 --> URI Class Initialized
INFO - 2024-06-20 09:45:42 --> Router Class Initialized
INFO - 2024-06-20 09:45:42 --> Output Class Initialized
INFO - 2024-06-20 09:45:42 --> Security Class Initialized
DEBUG - 2024-06-20 09:45:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-20 09:45:42 --> Input Class Initialized
INFO - 2024-06-20 09:45:42 --> Language Class Initialized
INFO - 2024-06-20 09:45:42 --> Language Class Initialized
INFO - 2024-06-20 09:45:42 --> Config Class Initialized
INFO - 2024-06-20 09:45:42 --> Loader Class Initialized
INFO - 2024-06-20 09:45:42 --> Helper loaded: url_helper
INFO - 2024-06-20 09:45:42 --> Helper loaded: file_helper
INFO - 2024-06-20 09:45:42 --> Helper loaded: form_helper
INFO - 2024-06-20 09:45:42 --> Helper loaded: my_helper
INFO - 2024-06-20 09:45:42 --> Database Driver Class Initialized
INFO - 2024-06-20 09:45:42 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-20 09:45:42 --> Controller Class Initialized
DEBUG - 2024-06-20 09:45:42 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/views/list.php
DEBUG - 2024-06-20 09:45:42 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-06-20 09:45:42 --> Final output sent to browser
DEBUG - 2024-06-20 09:45:42 --> Total execution time: 0.0447
INFO - 2024-06-20 09:45:46 --> Config Class Initialized
INFO - 2024-06-20 09:45:46 --> Hooks Class Initialized
DEBUG - 2024-06-20 09:45:46 --> UTF-8 Support Enabled
INFO - 2024-06-20 09:45:46 --> Utf8 Class Initialized
INFO - 2024-06-20 09:45:46 --> URI Class Initialized
INFO - 2024-06-20 09:45:46 --> Router Class Initialized
INFO - 2024-06-20 09:45:46 --> Output Class Initialized
INFO - 2024-06-20 09:45:46 --> Security Class Initialized
DEBUG - 2024-06-20 09:45:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-20 09:45:46 --> Input Class Initialized
INFO - 2024-06-20 09:45:46 --> Language Class Initialized
INFO - 2024-06-20 09:45:46 --> Language Class Initialized
INFO - 2024-06-20 09:45:46 --> Config Class Initialized
INFO - 2024-06-20 09:45:46 --> Loader Class Initialized
INFO - 2024-06-20 09:45:46 --> Helper loaded: url_helper
INFO - 2024-06-20 09:45:46 --> Helper loaded: file_helper
INFO - 2024-06-20 09:45:46 --> Helper loaded: form_helper
INFO - 2024-06-20 09:45:46 --> Helper loaded: my_helper
INFO - 2024-06-20 09:45:46 --> Database Driver Class Initialized
INFO - 2024-06-20 09:45:46 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-20 09:45:46 --> Controller Class Initialized
ERROR - 2024-06-20 09:45:46 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 3014
ERROR - 2024-06-20 09:45:46 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 3015
DEBUG - 2024-06-20 09:45:46 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/views/cetak_mh.php
INFO - 2024-06-20 09:45:49 --> Final output sent to browser
DEBUG - 2024-06-20 09:45:49 --> Total execution time: 3.8357
INFO - 2024-06-20 09:48:47 --> Config Class Initialized
INFO - 2024-06-20 09:48:47 --> Hooks Class Initialized
DEBUG - 2024-06-20 09:48:47 --> UTF-8 Support Enabled
INFO - 2024-06-20 09:48:47 --> Utf8 Class Initialized
INFO - 2024-06-20 09:48:47 --> URI Class Initialized
INFO - 2024-06-20 09:48:47 --> Router Class Initialized
INFO - 2024-06-20 09:48:47 --> Output Class Initialized
INFO - 2024-06-20 09:48:47 --> Security Class Initialized
DEBUG - 2024-06-20 09:48:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-20 09:48:47 --> Input Class Initialized
INFO - 2024-06-20 09:48:47 --> Language Class Initialized
INFO - 2024-06-20 09:48:47 --> Language Class Initialized
INFO - 2024-06-20 09:48:47 --> Config Class Initialized
INFO - 2024-06-20 09:48:47 --> Loader Class Initialized
INFO - 2024-06-20 09:48:47 --> Helper loaded: url_helper
INFO - 2024-06-20 09:48:47 --> Helper loaded: file_helper
INFO - 2024-06-20 09:48:47 --> Helper loaded: form_helper
INFO - 2024-06-20 09:48:47 --> Helper loaded: my_helper
INFO - 2024-06-20 09:48:47 --> Database Driver Class Initialized
INFO - 2024-06-20 09:48:47 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-20 09:48:47 --> Controller Class Initialized
DEBUG - 2024-06-20 09:48:47 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/views/cetak_mh.php
INFO - 2024-06-20 09:48:51 --> Config Class Initialized
INFO - 2024-06-20 09:48:51 --> Hooks Class Initialized
DEBUG - 2024-06-20 09:48:51 --> UTF-8 Support Enabled
INFO - 2024-06-20 09:48:51 --> Utf8 Class Initialized
INFO - 2024-06-20 09:48:51 --> URI Class Initialized
INFO - 2024-06-20 09:48:51 --> Router Class Initialized
INFO - 2024-06-20 09:48:51 --> Output Class Initialized
INFO - 2024-06-20 09:48:51 --> Security Class Initialized
DEBUG - 2024-06-20 09:48:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-20 09:48:51 --> Input Class Initialized
INFO - 2024-06-20 09:48:51 --> Language Class Initialized
INFO - 2024-06-20 09:48:51 --> Language Class Initialized
INFO - 2024-06-20 09:48:51 --> Config Class Initialized
INFO - 2024-06-20 09:48:51 --> Loader Class Initialized
INFO - 2024-06-20 09:48:51 --> Helper loaded: url_helper
INFO - 2024-06-20 09:48:51 --> Helper loaded: file_helper
INFO - 2024-06-20 09:48:51 --> Helper loaded: form_helper
INFO - 2024-06-20 09:48:51 --> Helper loaded: my_helper
INFO - 2024-06-20 09:48:51 --> Database Driver Class Initialized
INFO - 2024-06-20 09:48:51 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-20 09:48:51 --> Controller Class Initialized
ERROR - 2024-06-20 09:48:51 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 3014
ERROR - 2024-06-20 09:48:51 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 3015
DEBUG - 2024-06-20 09:48:51 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/views/cetak_mh.php
INFO - 2024-06-20 09:48:52 --> Final output sent to browser
DEBUG - 2024-06-20 09:48:52 --> Total execution time: 4.6082
INFO - 2024-06-20 09:49:02 --> Final output sent to browser
DEBUG - 2024-06-20 09:49:02 --> Total execution time: 11.0287
INFO - 2024-06-20 09:50:14 --> Config Class Initialized
INFO - 2024-06-20 09:50:14 --> Hooks Class Initialized
DEBUG - 2024-06-20 09:50:14 --> UTF-8 Support Enabled
INFO - 2024-06-20 09:50:14 --> Utf8 Class Initialized
INFO - 2024-06-20 09:50:14 --> URI Class Initialized
INFO - 2024-06-20 09:50:14 --> Router Class Initialized
INFO - 2024-06-20 09:50:14 --> Output Class Initialized
INFO - 2024-06-20 09:50:14 --> Security Class Initialized
DEBUG - 2024-06-20 09:50:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-20 09:50:14 --> Input Class Initialized
INFO - 2024-06-20 09:50:14 --> Language Class Initialized
INFO - 2024-06-20 09:50:14 --> Language Class Initialized
INFO - 2024-06-20 09:50:14 --> Config Class Initialized
INFO - 2024-06-20 09:50:14 --> Loader Class Initialized
INFO - 2024-06-20 09:50:14 --> Helper loaded: url_helper
INFO - 2024-06-20 09:50:14 --> Helper loaded: file_helper
INFO - 2024-06-20 09:50:14 --> Helper loaded: form_helper
INFO - 2024-06-20 09:50:14 --> Helper loaded: my_helper
INFO - 2024-06-20 09:50:14 --> Database Driver Class Initialized
INFO - 2024-06-20 09:50:14 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-20 09:50:14 --> Controller Class Initialized
ERROR - 2024-06-20 09:50:14 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 3014
ERROR - 2024-06-20 09:50:14 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 3015
DEBUG - 2024-06-20 09:50:14 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/views/cetak_mh.php
INFO - 2024-06-20 09:50:28 --> Final output sent to browser
DEBUG - 2024-06-20 09:50:28 --> Total execution time: 13.7661
INFO - 2024-06-20 09:54:42 --> Config Class Initialized
INFO - 2024-06-20 09:54:42 --> Hooks Class Initialized
DEBUG - 2024-06-20 09:54:42 --> UTF-8 Support Enabled
INFO - 2024-06-20 09:54:42 --> Utf8 Class Initialized
INFO - 2024-06-20 09:54:42 --> URI Class Initialized
INFO - 2024-06-20 09:54:42 --> Router Class Initialized
INFO - 2024-06-20 09:54:42 --> Output Class Initialized
INFO - 2024-06-20 09:54:42 --> Security Class Initialized
DEBUG - 2024-06-20 09:54:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-20 09:54:42 --> Input Class Initialized
INFO - 2024-06-20 09:54:42 --> Language Class Initialized
INFO - 2024-06-20 09:54:42 --> Language Class Initialized
INFO - 2024-06-20 09:54:42 --> Config Class Initialized
INFO - 2024-06-20 09:54:42 --> Loader Class Initialized
INFO - 2024-06-20 09:54:42 --> Helper loaded: url_helper
INFO - 2024-06-20 09:54:42 --> Helper loaded: file_helper
INFO - 2024-06-20 09:54:42 --> Helper loaded: form_helper
INFO - 2024-06-20 09:54:42 --> Helper loaded: my_helper
INFO - 2024-06-20 09:54:42 --> Database Driver Class Initialized
INFO - 2024-06-20 09:54:42 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-20 09:54:42 --> Controller Class Initialized
ERROR - 2024-06-20 09:54:42 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 3014
ERROR - 2024-06-20 09:54:42 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 3015
DEBUG - 2024-06-20 09:54:42 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/views/cetak_mh.php
INFO - 2024-06-20 09:54:46 --> Final output sent to browser
DEBUG - 2024-06-20 09:54:46 --> Total execution time: 4.0753
INFO - 2024-06-20 10:08:47 --> Config Class Initialized
INFO - 2024-06-20 10:08:47 --> Hooks Class Initialized
DEBUG - 2024-06-20 10:08:47 --> UTF-8 Support Enabled
INFO - 2024-06-20 10:08:47 --> Utf8 Class Initialized
INFO - 2024-06-20 10:08:47 --> URI Class Initialized
INFO - 2024-06-20 10:08:47 --> Router Class Initialized
INFO - 2024-06-20 10:08:47 --> Output Class Initialized
INFO - 2024-06-20 10:08:47 --> Security Class Initialized
DEBUG - 2024-06-20 10:08:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-20 10:08:47 --> Input Class Initialized
INFO - 2024-06-20 10:08:47 --> Language Class Initialized
INFO - 2024-06-20 10:08:47 --> Language Class Initialized
INFO - 2024-06-20 10:08:47 --> Config Class Initialized
INFO - 2024-06-20 10:08:47 --> Loader Class Initialized
INFO - 2024-06-20 10:08:47 --> Helper loaded: url_helper
INFO - 2024-06-20 10:08:47 --> Helper loaded: file_helper
INFO - 2024-06-20 10:08:47 --> Helper loaded: form_helper
INFO - 2024-06-20 10:08:47 --> Helper loaded: my_helper
INFO - 2024-06-20 10:08:47 --> Database Driver Class Initialized
INFO - 2024-06-20 10:08:47 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-20 10:08:47 --> Controller Class Initialized
ERROR - 2024-06-20 10:08:47 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 3014
ERROR - 2024-06-20 10:08:47 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 3015
DEBUG - 2024-06-20 10:08:47 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/views/cetak_mh.php
INFO - 2024-06-20 10:08:51 --> Final output sent to browser
DEBUG - 2024-06-20 10:08:51 --> Total execution time: 4.4839
INFO - 2024-06-20 10:10:16 --> Config Class Initialized
INFO - 2024-06-20 10:10:16 --> Hooks Class Initialized
DEBUG - 2024-06-20 10:10:16 --> UTF-8 Support Enabled
INFO - 2024-06-20 10:10:16 --> Utf8 Class Initialized
INFO - 2024-06-20 10:10:16 --> URI Class Initialized
INFO - 2024-06-20 10:10:16 --> Router Class Initialized
INFO - 2024-06-20 10:10:16 --> Output Class Initialized
INFO - 2024-06-20 10:10:16 --> Security Class Initialized
DEBUG - 2024-06-20 10:10:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-20 10:10:16 --> Input Class Initialized
INFO - 2024-06-20 10:10:16 --> Language Class Initialized
INFO - 2024-06-20 10:10:16 --> Language Class Initialized
INFO - 2024-06-20 10:10:16 --> Config Class Initialized
INFO - 2024-06-20 10:10:16 --> Loader Class Initialized
INFO - 2024-06-20 10:10:16 --> Helper loaded: url_helper
INFO - 2024-06-20 10:10:16 --> Helper loaded: file_helper
INFO - 2024-06-20 10:10:16 --> Helper loaded: form_helper
INFO - 2024-06-20 10:10:16 --> Helper loaded: my_helper
INFO - 2024-06-20 10:10:16 --> Database Driver Class Initialized
INFO - 2024-06-20 10:10:16 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-20 10:10:16 --> Controller Class Initialized
DEBUG - 2024-06-20 10:10:16 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/views/cetak_ikm.php
INFO - 2024-06-20 10:10:17 --> Final output sent to browser
DEBUG - 2024-06-20 10:10:17 --> Total execution time: 1.6574
INFO - 2024-06-20 10:25:01 --> Config Class Initialized
INFO - 2024-06-20 10:25:01 --> Hooks Class Initialized
DEBUG - 2024-06-20 10:25:01 --> UTF-8 Support Enabled
INFO - 2024-06-20 10:25:01 --> Utf8 Class Initialized
INFO - 2024-06-20 10:25:01 --> URI Class Initialized
INFO - 2024-06-20 10:25:01 --> Router Class Initialized
INFO - 2024-06-20 10:25:01 --> Output Class Initialized
INFO - 2024-06-20 10:25:01 --> Security Class Initialized
DEBUG - 2024-06-20 10:25:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-20 10:25:01 --> Input Class Initialized
INFO - 2024-06-20 10:25:01 --> Language Class Initialized
INFO - 2024-06-20 10:25:01 --> Language Class Initialized
INFO - 2024-06-20 10:25:01 --> Config Class Initialized
INFO - 2024-06-20 10:25:01 --> Loader Class Initialized
INFO - 2024-06-20 10:25:01 --> Helper loaded: url_helper
INFO - 2024-06-20 10:25:01 --> Helper loaded: file_helper
INFO - 2024-06-20 10:25:01 --> Helper loaded: form_helper
INFO - 2024-06-20 10:25:01 --> Helper loaded: my_helper
INFO - 2024-06-20 10:25:01 --> Database Driver Class Initialized
INFO - 2024-06-20 10:25:01 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-20 10:25:01 --> Controller Class Initialized
DEBUG - 2024-06-20 10:25:01 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/views/list.php
DEBUG - 2024-06-20 10:25:01 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-06-20 10:25:01 --> Final output sent to browser
DEBUG - 2024-06-20 10:25:01 --> Total execution time: 0.2030
INFO - 2024-06-20 10:25:06 --> Config Class Initialized
INFO - 2024-06-20 10:25:06 --> Hooks Class Initialized
DEBUG - 2024-06-20 10:25:06 --> UTF-8 Support Enabled
INFO - 2024-06-20 10:25:06 --> Utf8 Class Initialized
INFO - 2024-06-20 10:25:06 --> URI Class Initialized
INFO - 2024-06-20 10:25:06 --> Router Class Initialized
INFO - 2024-06-20 10:25:06 --> Output Class Initialized
INFO - 2024-06-20 10:25:06 --> Security Class Initialized
DEBUG - 2024-06-20 10:25:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-20 10:25:06 --> Input Class Initialized
INFO - 2024-06-20 10:25:06 --> Language Class Initialized
INFO - 2024-06-20 10:25:06 --> Language Class Initialized
INFO - 2024-06-20 10:25:06 --> Config Class Initialized
INFO - 2024-06-20 10:25:06 --> Loader Class Initialized
INFO - 2024-06-20 10:25:06 --> Helper loaded: url_helper
INFO - 2024-06-20 10:25:06 --> Helper loaded: file_helper
INFO - 2024-06-20 10:25:06 --> Helper loaded: form_helper
INFO - 2024-06-20 10:25:06 --> Helper loaded: my_helper
INFO - 2024-06-20 10:25:06 --> Database Driver Class Initialized
INFO - 2024-06-20 10:25:06 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-20 10:25:06 --> Controller Class Initialized
ERROR - 2024-06-20 10:25:06 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 3014
ERROR - 2024-06-20 10:25:06 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 3015
DEBUG - 2024-06-20 10:25:06 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/views/cetak_mh.php
INFO - 2024-06-20 10:25:11 --> Final output sent to browser
DEBUG - 2024-06-20 10:25:11 --> Total execution time: 4.6587
INFO - 2024-06-20 10:25:44 --> Config Class Initialized
INFO - 2024-06-20 10:25:44 --> Hooks Class Initialized
DEBUG - 2024-06-20 10:25:44 --> UTF-8 Support Enabled
INFO - 2024-06-20 10:25:44 --> Utf8 Class Initialized
INFO - 2024-06-20 10:25:44 --> URI Class Initialized
INFO - 2024-06-20 10:25:44 --> Router Class Initialized
INFO - 2024-06-20 10:25:44 --> Output Class Initialized
INFO - 2024-06-20 10:25:44 --> Security Class Initialized
DEBUG - 2024-06-20 10:25:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-20 10:25:44 --> Input Class Initialized
INFO - 2024-06-20 10:25:44 --> Language Class Initialized
INFO - 2024-06-20 10:25:44 --> Language Class Initialized
INFO - 2024-06-20 10:25:44 --> Config Class Initialized
INFO - 2024-06-20 10:25:44 --> Loader Class Initialized
INFO - 2024-06-20 10:25:44 --> Helper loaded: url_helper
INFO - 2024-06-20 10:25:44 --> Helper loaded: file_helper
INFO - 2024-06-20 10:25:44 --> Helper loaded: form_helper
INFO - 2024-06-20 10:25:44 --> Helper loaded: my_helper
INFO - 2024-06-20 10:25:44 --> Database Driver Class Initialized
INFO - 2024-06-20 10:25:44 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-20 10:25:44 --> Controller Class Initialized
DEBUG - 2024-06-20 10:25:44 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/views/cetak_ikm.php
INFO - 2024-06-20 10:25:46 --> Final output sent to browser
DEBUG - 2024-06-20 10:25:46 --> Total execution time: 1.9959
INFO - 2024-06-20 10:27:12 --> Config Class Initialized
INFO - 2024-06-20 10:27:12 --> Hooks Class Initialized
DEBUG - 2024-06-20 10:27:12 --> UTF-8 Support Enabled
INFO - 2024-06-20 10:27:12 --> Utf8 Class Initialized
INFO - 2024-06-20 10:27:12 --> URI Class Initialized
INFO - 2024-06-20 10:27:12 --> Router Class Initialized
INFO - 2024-06-20 10:27:12 --> Output Class Initialized
INFO - 2024-06-20 10:27:12 --> Security Class Initialized
DEBUG - 2024-06-20 10:27:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-20 10:27:12 --> Input Class Initialized
INFO - 2024-06-20 10:27:12 --> Language Class Initialized
INFO - 2024-06-20 10:27:12 --> Language Class Initialized
INFO - 2024-06-20 10:27:12 --> Config Class Initialized
INFO - 2024-06-20 10:27:12 --> Loader Class Initialized
INFO - 2024-06-20 10:27:12 --> Helper loaded: url_helper
INFO - 2024-06-20 10:27:12 --> Helper loaded: file_helper
INFO - 2024-06-20 10:27:12 --> Helper loaded: form_helper
INFO - 2024-06-20 10:27:12 --> Helper loaded: my_helper
INFO - 2024-06-20 10:27:12 --> Database Driver Class Initialized
INFO - 2024-06-20 10:27:12 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-20 10:27:12 --> Controller Class Initialized
ERROR - 2024-06-20 10:27:12 --> Severity: Notice --> Undefined index: projek /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1837
ERROR - 2024-06-20 10:27:12 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2024-06-20 10:27:12 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2024-06-20 10:27:12 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2024-06-20 10:27:12 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2024-06-20 10:27:12 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2024-06-20 10:27:12 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2024-06-20 10:27:12 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2024-06-20 10:27:12 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2024-06-20 10:27:12 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2024-06-20 10:27:12 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2024-06-20 10:27:12 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2024-06-20 10:27:12 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2024-06-20 10:27:12 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2024-06-20 10:27:12 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2024-06-20 10:27:12 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2024-06-20 10:27:12 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2024-06-20 10:27:12 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2024-06-20 10:27:12 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2024-06-20 10:27:12 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2024-06-20 10:27:12 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2024-06-20 10:27:12 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2024-06-20 10:27:12 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2024-06-20 10:27:12 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2024-06-20 10:27:12 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2024-06-20 10:27:12 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2024-06-20 10:27:12 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2024-06-20 10:27:12 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2024-06-20 10:27:12 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2024-06-20 10:27:12 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2024-06-20 10:27:12 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2024-06-20 10:27:12 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2024-06-20 10:27:12 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2024-06-20 10:27:12 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2024-06-20 10:27:12 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2024-06-20 10:27:12 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2024-06-20 10:27:12 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2024-06-20 10:27:12 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2024-06-20 10:27:12 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2024-06-20 10:27:12 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
DEBUG - 2024-06-20 10:27:12 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/views/cetak_projek.php
INFO - 2024-06-20 10:27:16 --> Final output sent to browser
DEBUG - 2024-06-20 10:27:16 --> Total execution time: 4.9130
INFO - 2024-06-20 10:27:23 --> Config Class Initialized
INFO - 2024-06-20 10:27:23 --> Hooks Class Initialized
DEBUG - 2024-06-20 10:27:23 --> UTF-8 Support Enabled
INFO - 2024-06-20 10:27:23 --> Utf8 Class Initialized
INFO - 2024-06-20 10:27:23 --> URI Class Initialized
INFO - 2024-06-20 10:27:23 --> Router Class Initialized
INFO - 2024-06-20 10:27:23 --> Output Class Initialized
INFO - 2024-06-20 10:27:23 --> Security Class Initialized
DEBUG - 2024-06-20 10:27:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-20 10:27:23 --> Input Class Initialized
INFO - 2024-06-20 10:27:23 --> Language Class Initialized
INFO - 2024-06-20 10:27:23 --> Language Class Initialized
INFO - 2024-06-20 10:27:23 --> Config Class Initialized
INFO - 2024-06-20 10:27:23 --> Loader Class Initialized
INFO - 2024-06-20 10:27:23 --> Helper loaded: url_helper
INFO - 2024-06-20 10:27:23 --> Helper loaded: file_helper
INFO - 2024-06-20 10:27:23 --> Helper loaded: form_helper
INFO - 2024-06-20 10:27:23 --> Helper loaded: my_helper
INFO - 2024-06-20 10:27:23 --> Database Driver Class Initialized
INFO - 2024-06-20 10:27:23 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-20 10:27:23 --> Controller Class Initialized
DEBUG - 2024-06-20 10:27:23 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/views/cetak_mh.php
INFO - 2024-06-20 10:27:27 --> Final output sent to browser
DEBUG - 2024-06-20 10:27:27 --> Total execution time: 4.1804
INFO - 2024-06-20 10:27:28 --> Config Class Initialized
INFO - 2024-06-20 10:27:28 --> Hooks Class Initialized
DEBUG - 2024-06-20 10:27:28 --> UTF-8 Support Enabled
INFO - 2024-06-20 10:27:28 --> Utf8 Class Initialized
INFO - 2024-06-20 10:27:28 --> URI Class Initialized
INFO - 2024-06-20 10:27:28 --> Router Class Initialized
INFO - 2024-06-20 10:27:28 --> Output Class Initialized
INFO - 2024-06-20 10:27:28 --> Security Class Initialized
DEBUG - 2024-06-20 10:27:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-20 10:27:28 --> Input Class Initialized
INFO - 2024-06-20 10:27:28 --> Language Class Initialized
INFO - 2024-06-20 10:27:28 --> Language Class Initialized
INFO - 2024-06-20 10:27:28 --> Config Class Initialized
INFO - 2024-06-20 10:27:28 --> Loader Class Initialized
INFO - 2024-06-20 10:27:28 --> Helper loaded: url_helper
INFO - 2024-06-20 10:27:28 --> Helper loaded: file_helper
INFO - 2024-06-20 10:27:28 --> Helper loaded: form_helper
INFO - 2024-06-20 10:27:28 --> Helper loaded: my_helper
INFO - 2024-06-20 10:27:28 --> Database Driver Class Initialized
INFO - 2024-06-20 10:27:28 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-20 10:27:28 --> Controller Class Initialized
DEBUG - 2024-06-20 10:27:28 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/views/cetak_tahfiz.php
INFO - 2024-06-20 10:27:32 --> Final output sent to browser
DEBUG - 2024-06-20 10:27:32 --> Total execution time: 3.6475
INFO - 2024-06-20 10:36:25 --> Config Class Initialized
INFO - 2024-06-20 10:36:25 --> Hooks Class Initialized
DEBUG - 2024-06-20 10:36:25 --> UTF-8 Support Enabled
INFO - 2024-06-20 10:36:25 --> Utf8 Class Initialized
INFO - 2024-06-20 10:36:25 --> URI Class Initialized
INFO - 2024-06-20 10:36:25 --> Router Class Initialized
INFO - 2024-06-20 10:36:25 --> Output Class Initialized
INFO - 2024-06-20 10:36:25 --> Security Class Initialized
DEBUG - 2024-06-20 10:36:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-20 10:36:25 --> Input Class Initialized
INFO - 2024-06-20 10:36:25 --> Language Class Initialized
INFO - 2024-06-20 10:36:25 --> Language Class Initialized
INFO - 2024-06-20 10:36:25 --> Config Class Initialized
INFO - 2024-06-20 10:36:25 --> Loader Class Initialized
INFO - 2024-06-20 10:36:25 --> Helper loaded: url_helper
INFO - 2024-06-20 10:36:25 --> Helper loaded: file_helper
INFO - 2024-06-20 10:36:25 --> Helper loaded: form_helper
INFO - 2024-06-20 10:36:25 --> Helper loaded: my_helper
INFO - 2024-06-20 10:36:25 --> Database Driver Class Initialized
INFO - 2024-06-20 10:36:25 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-20 10:36:25 --> Controller Class Initialized
DEBUG - 2024-06-20 10:36:25 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/list.php
DEBUG - 2024-06-20 10:36:25 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-06-20 10:36:25 --> Final output sent to browser
DEBUG - 2024-06-20 10:36:25 --> Total execution time: 0.1703
INFO - 2024-06-20 10:36:34 --> Config Class Initialized
INFO - 2024-06-20 10:36:34 --> Hooks Class Initialized
DEBUG - 2024-06-20 10:36:34 --> UTF-8 Support Enabled
INFO - 2024-06-20 10:36:34 --> Utf8 Class Initialized
INFO - 2024-06-20 10:36:34 --> URI Class Initialized
INFO - 2024-06-20 10:36:34 --> Router Class Initialized
INFO - 2024-06-20 10:36:34 --> Output Class Initialized
INFO - 2024-06-20 10:36:34 --> Security Class Initialized
DEBUG - 2024-06-20 10:36:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-20 10:36:34 --> Input Class Initialized
INFO - 2024-06-20 10:36:34 --> Language Class Initialized
INFO - 2024-06-20 10:36:34 --> Language Class Initialized
INFO - 2024-06-20 10:36:34 --> Config Class Initialized
INFO - 2024-06-20 10:36:34 --> Loader Class Initialized
INFO - 2024-06-20 10:36:34 --> Helper loaded: url_helper
INFO - 2024-06-20 10:36:34 --> Helper loaded: file_helper
INFO - 2024-06-20 10:36:34 --> Helper loaded: form_helper
INFO - 2024-06-20 10:36:34 --> Helper loaded: my_helper
INFO - 2024-06-20 10:36:34 --> Database Driver Class Initialized
INFO - 2024-06-20 10:36:34 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-20 10:36:34 --> Controller Class Initialized
DEBUG - 2024-06-20 10:36:34 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php
INFO - 2024-06-20 10:36:40 --> Final output sent to browser
DEBUG - 2024-06-20 10:36:40 --> Total execution time: 5.8564
INFO - 2024-06-20 10:37:10 --> Config Class Initialized
INFO - 2024-06-20 10:37:10 --> Hooks Class Initialized
DEBUG - 2024-06-20 10:37:10 --> UTF-8 Support Enabled
INFO - 2024-06-20 10:37:10 --> Utf8 Class Initialized
INFO - 2024-06-20 10:37:10 --> URI Class Initialized
INFO - 2024-06-20 10:37:10 --> Router Class Initialized
INFO - 2024-06-20 10:37:10 --> Output Class Initialized
INFO - 2024-06-20 10:37:10 --> Security Class Initialized
DEBUG - 2024-06-20 10:37:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-20 10:37:10 --> Input Class Initialized
INFO - 2024-06-20 10:37:10 --> Language Class Initialized
INFO - 2024-06-20 10:37:10 --> Language Class Initialized
INFO - 2024-06-20 10:37:10 --> Config Class Initialized
INFO - 2024-06-20 10:37:10 --> Loader Class Initialized
INFO - 2024-06-20 10:37:10 --> Helper loaded: url_helper
INFO - 2024-06-20 10:37:10 --> Helper loaded: file_helper
INFO - 2024-06-20 10:37:10 --> Helper loaded: form_helper
INFO - 2024-06-20 10:37:10 --> Helper loaded: my_helper
INFO - 2024-06-20 10:37:10 --> Database Driver Class Initialized
INFO - 2024-06-20 10:37:10 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-20 10:37:10 --> Controller Class Initialized
DEBUG - 2024-06-20 10:37:10 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/view_mapel/views/v_view_mapel.php
DEBUG - 2024-06-20 10:37:10 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-06-20 10:37:10 --> Final output sent to browser
DEBUG - 2024-06-20 10:37:10 --> Total execution time: 0.0267
INFO - 2024-06-20 10:38:21 --> Config Class Initialized
INFO - 2024-06-20 10:38:21 --> Hooks Class Initialized
DEBUG - 2024-06-20 10:38:21 --> UTF-8 Support Enabled
INFO - 2024-06-20 10:38:21 --> Utf8 Class Initialized
INFO - 2024-06-20 10:38:21 --> URI Class Initialized
INFO - 2024-06-20 10:38:21 --> Router Class Initialized
INFO - 2024-06-20 10:38:21 --> Output Class Initialized
INFO - 2024-06-20 10:38:21 --> Security Class Initialized
DEBUG - 2024-06-20 10:38:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-20 10:38:21 --> Input Class Initialized
INFO - 2024-06-20 10:38:21 --> Language Class Initialized
INFO - 2024-06-20 10:38:21 --> Language Class Initialized
INFO - 2024-06-20 10:38:21 --> Config Class Initialized
INFO - 2024-06-20 10:38:21 --> Loader Class Initialized
INFO - 2024-06-20 10:38:21 --> Helper loaded: url_helper
INFO - 2024-06-20 10:38:21 --> Helper loaded: file_helper
INFO - 2024-06-20 10:38:21 --> Helper loaded: form_helper
INFO - 2024-06-20 10:38:21 --> Helper loaded: my_helper
INFO - 2024-06-20 10:38:21 --> Database Driver Class Initialized
INFO - 2024-06-20 10:38:21 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-20 10:38:21 --> Controller Class Initialized
INFO - 2024-06-20 10:38:21 --> Helper loaded: cookie_helper
INFO - 2024-06-20 10:38:21 --> Config Class Initialized
INFO - 2024-06-20 10:38:21 --> Hooks Class Initialized
DEBUG - 2024-06-20 10:38:21 --> UTF-8 Support Enabled
INFO - 2024-06-20 10:38:21 --> Utf8 Class Initialized
INFO - 2024-06-20 10:38:21 --> URI Class Initialized
INFO - 2024-06-20 10:38:21 --> Router Class Initialized
INFO - 2024-06-20 10:38:21 --> Output Class Initialized
INFO - 2024-06-20 10:38:21 --> Security Class Initialized
DEBUG - 2024-06-20 10:38:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-20 10:38:21 --> Input Class Initialized
INFO - 2024-06-20 10:38:21 --> Language Class Initialized
INFO - 2024-06-20 10:38:21 --> Language Class Initialized
INFO - 2024-06-20 10:38:21 --> Config Class Initialized
INFO - 2024-06-20 10:38:21 --> Loader Class Initialized
INFO - 2024-06-20 10:38:21 --> Helper loaded: url_helper
INFO - 2024-06-20 10:38:21 --> Helper loaded: file_helper
INFO - 2024-06-20 10:38:21 --> Helper loaded: form_helper
INFO - 2024-06-20 10:38:21 --> Helper loaded: my_helper
INFO - 2024-06-20 10:38:21 --> Database Driver Class Initialized
INFO - 2024-06-20 10:38:21 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-20 10:38:21 --> Controller Class Initialized
INFO - 2024-06-20 10:38:21 --> Config Class Initialized
INFO - 2024-06-20 10:38:21 --> Hooks Class Initialized
DEBUG - 2024-06-20 10:38:21 --> UTF-8 Support Enabled
INFO - 2024-06-20 10:38:21 --> Utf8 Class Initialized
INFO - 2024-06-20 10:38:21 --> URI Class Initialized
INFO - 2024-06-20 10:38:21 --> Router Class Initialized
INFO - 2024-06-20 10:38:21 --> Output Class Initialized
INFO - 2024-06-20 10:38:21 --> Security Class Initialized
DEBUG - 2024-06-20 10:38:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-20 10:38:21 --> Input Class Initialized
INFO - 2024-06-20 10:38:21 --> Language Class Initialized
INFO - 2024-06-20 10:38:21 --> Language Class Initialized
INFO - 2024-06-20 10:38:21 --> Config Class Initialized
INFO - 2024-06-20 10:38:21 --> Loader Class Initialized
INFO - 2024-06-20 10:38:21 --> Helper loaded: url_helper
INFO - 2024-06-20 10:38:21 --> Helper loaded: file_helper
INFO - 2024-06-20 10:38:21 --> Helper loaded: form_helper
INFO - 2024-06-20 10:38:21 --> Helper loaded: my_helper
INFO - 2024-06-20 10:38:21 --> Database Driver Class Initialized
INFO - 2024-06-20 10:38:21 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-20 10:38:21 --> Controller Class Initialized
DEBUG - 2024-06-20 10:38:21 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/login/views/login.php
DEBUG - 2024-06-20 10:38:21 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-06-20 10:38:21 --> Final output sent to browser
DEBUG - 2024-06-20 10:38:21 --> Total execution time: 0.0310
INFO - 2024-06-20 10:38:28 --> Config Class Initialized
INFO - 2024-06-20 10:38:28 --> Hooks Class Initialized
DEBUG - 2024-06-20 10:38:28 --> UTF-8 Support Enabled
INFO - 2024-06-20 10:38:28 --> Utf8 Class Initialized
INFO - 2024-06-20 10:38:28 --> URI Class Initialized
INFO - 2024-06-20 10:38:28 --> Router Class Initialized
INFO - 2024-06-20 10:38:28 --> Output Class Initialized
INFO - 2024-06-20 10:38:28 --> Security Class Initialized
DEBUG - 2024-06-20 10:38:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-20 10:38:28 --> Input Class Initialized
INFO - 2024-06-20 10:38:28 --> Language Class Initialized
INFO - 2024-06-20 10:38:28 --> Language Class Initialized
INFO - 2024-06-20 10:38:28 --> Config Class Initialized
INFO - 2024-06-20 10:38:28 --> Loader Class Initialized
INFO - 2024-06-20 10:38:28 --> Helper loaded: url_helper
INFO - 2024-06-20 10:38:28 --> Helper loaded: file_helper
INFO - 2024-06-20 10:38:28 --> Helper loaded: form_helper
INFO - 2024-06-20 10:38:28 --> Helper loaded: my_helper
INFO - 2024-06-20 10:38:28 --> Database Driver Class Initialized
INFO - 2024-06-20 10:38:28 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-20 10:38:28 --> Controller Class Initialized
INFO - 2024-06-20 10:38:28 --> Helper loaded: cookie_helper
INFO - 2024-06-20 10:38:28 --> Final output sent to browser
DEBUG - 2024-06-20 10:38:28 --> Total execution time: 0.0366
INFO - 2024-06-20 10:38:28 --> Config Class Initialized
INFO - 2024-06-20 10:38:28 --> Hooks Class Initialized
DEBUG - 2024-06-20 10:38:28 --> UTF-8 Support Enabled
INFO - 2024-06-20 10:38:28 --> Utf8 Class Initialized
INFO - 2024-06-20 10:38:28 --> URI Class Initialized
INFO - 2024-06-20 10:38:28 --> Router Class Initialized
INFO - 2024-06-20 10:38:28 --> Output Class Initialized
INFO - 2024-06-20 10:38:28 --> Security Class Initialized
DEBUG - 2024-06-20 10:38:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-20 10:38:28 --> Input Class Initialized
INFO - 2024-06-20 10:38:28 --> Language Class Initialized
INFO - 2024-06-20 10:38:28 --> Language Class Initialized
INFO - 2024-06-20 10:38:28 --> Config Class Initialized
INFO - 2024-06-20 10:38:28 --> Loader Class Initialized
INFO - 2024-06-20 10:38:28 --> Helper loaded: url_helper
INFO - 2024-06-20 10:38:28 --> Helper loaded: file_helper
INFO - 2024-06-20 10:38:28 --> Helper loaded: form_helper
INFO - 2024-06-20 10:38:28 --> Helper loaded: my_helper
INFO - 2024-06-20 10:38:28 --> Database Driver Class Initialized
INFO - 2024-06-20 10:38:28 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-20 10:38:28 --> Controller Class Initialized
DEBUG - 2024-06-20 10:38:28 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/home/views/v_home.php
DEBUG - 2024-06-20 10:38:28 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-06-20 10:38:28 --> Final output sent to browser
DEBUG - 2024-06-20 10:38:28 --> Total execution time: 0.0317
INFO - 2024-06-20 10:38:31 --> Config Class Initialized
INFO - 2024-06-20 10:38:31 --> Hooks Class Initialized
DEBUG - 2024-06-20 10:38:31 --> UTF-8 Support Enabled
INFO - 2024-06-20 10:38:31 --> Utf8 Class Initialized
INFO - 2024-06-20 10:38:31 --> URI Class Initialized
INFO - 2024-06-20 10:38:31 --> Router Class Initialized
INFO - 2024-06-20 10:38:31 --> Output Class Initialized
INFO - 2024-06-20 10:38:31 --> Security Class Initialized
DEBUG - 2024-06-20 10:38:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-20 10:38:31 --> Input Class Initialized
INFO - 2024-06-20 10:38:31 --> Language Class Initialized
INFO - 2024-06-20 10:38:31 --> Language Class Initialized
INFO - 2024-06-20 10:38:31 --> Config Class Initialized
INFO - 2024-06-20 10:38:31 --> Loader Class Initialized
INFO - 2024-06-20 10:38:31 --> Helper loaded: url_helper
INFO - 2024-06-20 10:38:31 --> Helper loaded: file_helper
INFO - 2024-06-20 10:38:31 --> Helper loaded: form_helper
INFO - 2024-06-20 10:38:31 --> Helper loaded: my_helper
INFO - 2024-06-20 10:38:31 --> Database Driver Class Initialized
INFO - 2024-06-20 10:38:31 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-20 10:38:31 --> Controller Class Initialized
DEBUG - 2024-06-20 10:38:31 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/data_guru/views/list.php
DEBUG - 2024-06-20 10:38:31 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-06-20 10:38:31 --> Final output sent to browser
DEBUG - 2024-06-20 10:38:31 --> Total execution time: 0.0740
INFO - 2024-06-20 10:38:31 --> Config Class Initialized
INFO - 2024-06-20 10:38:31 --> Hooks Class Initialized
DEBUG - 2024-06-20 10:38:31 --> UTF-8 Support Enabled
INFO - 2024-06-20 10:38:31 --> Utf8 Class Initialized
INFO - 2024-06-20 10:38:31 --> URI Class Initialized
INFO - 2024-06-20 10:38:31 --> Router Class Initialized
INFO - 2024-06-20 10:38:31 --> Output Class Initialized
INFO - 2024-06-20 10:38:31 --> Security Class Initialized
DEBUG - 2024-06-20 10:38:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-20 10:38:31 --> Input Class Initialized
INFO - 2024-06-20 10:38:31 --> Language Class Initialized
ERROR - 2024-06-20 10:38:31 --> 404 Page Not Found: /index
INFO - 2024-06-20 10:38:31 --> Config Class Initialized
INFO - 2024-06-20 10:38:31 --> Hooks Class Initialized
DEBUG - 2024-06-20 10:38:31 --> UTF-8 Support Enabled
INFO - 2024-06-20 10:38:31 --> Utf8 Class Initialized
INFO - 2024-06-20 10:38:31 --> URI Class Initialized
INFO - 2024-06-20 10:38:31 --> Router Class Initialized
INFO - 2024-06-20 10:38:31 --> Output Class Initialized
INFO - 2024-06-20 10:38:31 --> Security Class Initialized
DEBUG - 2024-06-20 10:38:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-20 10:38:31 --> Input Class Initialized
INFO - 2024-06-20 10:38:31 --> Language Class Initialized
INFO - 2024-06-20 10:38:31 --> Language Class Initialized
INFO - 2024-06-20 10:38:31 --> Config Class Initialized
INFO - 2024-06-20 10:38:31 --> Loader Class Initialized
INFO - 2024-06-20 10:38:31 --> Helper loaded: url_helper
INFO - 2024-06-20 10:38:31 --> Helper loaded: file_helper
INFO - 2024-06-20 10:38:31 --> Helper loaded: form_helper
INFO - 2024-06-20 10:38:31 --> Helper loaded: my_helper
INFO - 2024-06-20 10:38:31 --> Database Driver Class Initialized
INFO - 2024-06-20 10:38:31 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-20 10:38:31 --> Controller Class Initialized
INFO - 2024-06-20 10:38:42 --> Config Class Initialized
INFO - 2024-06-20 10:38:42 --> Hooks Class Initialized
DEBUG - 2024-06-20 10:38:42 --> UTF-8 Support Enabled
INFO - 2024-06-20 10:38:42 --> Utf8 Class Initialized
INFO - 2024-06-20 10:38:42 --> URI Class Initialized
INFO - 2024-06-20 10:38:42 --> Router Class Initialized
INFO - 2024-06-20 10:38:42 --> Output Class Initialized
INFO - 2024-06-20 10:38:42 --> Security Class Initialized
DEBUG - 2024-06-20 10:38:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-20 10:38:42 --> Input Class Initialized
INFO - 2024-06-20 10:38:42 --> Language Class Initialized
INFO - 2024-06-20 10:38:42 --> Language Class Initialized
INFO - 2024-06-20 10:38:42 --> Config Class Initialized
INFO - 2024-06-20 10:38:42 --> Loader Class Initialized
INFO - 2024-06-20 10:38:42 --> Helper loaded: url_helper
INFO - 2024-06-20 10:38:42 --> Helper loaded: file_helper
INFO - 2024-06-20 10:38:42 --> Helper loaded: form_helper
INFO - 2024-06-20 10:38:42 --> Helper loaded: my_helper
INFO - 2024-06-20 10:38:42 --> Database Driver Class Initialized
INFO - 2024-06-20 10:38:42 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-20 10:38:42 --> Controller Class Initialized
DEBUG - 2024-06-20 10:38:42 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/data_mapel/views/list.php
DEBUG - 2024-06-20 10:38:42 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-06-20 10:38:42 --> Final output sent to browser
DEBUG - 2024-06-20 10:38:42 --> Total execution time: 0.0258
INFO - 2024-06-20 10:38:42 --> Config Class Initialized
INFO - 2024-06-20 10:38:42 --> Hooks Class Initialized
DEBUG - 2024-06-20 10:38:42 --> UTF-8 Support Enabled
INFO - 2024-06-20 10:38:42 --> Utf8 Class Initialized
INFO - 2024-06-20 10:38:42 --> URI Class Initialized
INFO - 2024-06-20 10:38:42 --> Router Class Initialized
INFO - 2024-06-20 10:38:42 --> Output Class Initialized
INFO - 2024-06-20 10:38:42 --> Security Class Initialized
DEBUG - 2024-06-20 10:38:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-20 10:38:42 --> Input Class Initialized
INFO - 2024-06-20 10:38:42 --> Language Class Initialized
ERROR - 2024-06-20 10:38:42 --> 404 Page Not Found: /index
INFO - 2024-06-20 10:38:42 --> Config Class Initialized
INFO - 2024-06-20 10:38:42 --> Hooks Class Initialized
DEBUG - 2024-06-20 10:38:42 --> UTF-8 Support Enabled
INFO - 2024-06-20 10:38:42 --> Utf8 Class Initialized
INFO - 2024-06-20 10:38:42 --> URI Class Initialized
INFO - 2024-06-20 10:38:42 --> Router Class Initialized
INFO - 2024-06-20 10:38:42 --> Output Class Initialized
INFO - 2024-06-20 10:38:42 --> Security Class Initialized
DEBUG - 2024-06-20 10:38:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-20 10:38:42 --> Input Class Initialized
INFO - 2024-06-20 10:38:42 --> Language Class Initialized
INFO - 2024-06-20 10:38:42 --> Language Class Initialized
INFO - 2024-06-20 10:38:42 --> Config Class Initialized
INFO - 2024-06-20 10:38:42 --> Loader Class Initialized
INFO - 2024-06-20 10:38:42 --> Helper loaded: url_helper
INFO - 2024-06-20 10:38:42 --> Helper loaded: file_helper
INFO - 2024-06-20 10:38:42 --> Helper loaded: form_helper
INFO - 2024-06-20 10:38:42 --> Helper loaded: my_helper
INFO - 2024-06-20 10:38:42 --> Database Driver Class Initialized
INFO - 2024-06-20 10:38:42 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-20 10:38:42 --> Controller Class Initialized
INFO - 2024-06-20 10:38:53 --> Config Class Initialized
INFO - 2024-06-20 10:38:53 --> Hooks Class Initialized
DEBUG - 2024-06-20 10:38:53 --> UTF-8 Support Enabled
INFO - 2024-06-20 10:38:53 --> Utf8 Class Initialized
INFO - 2024-06-20 10:38:53 --> URI Class Initialized
INFO - 2024-06-20 10:38:53 --> Router Class Initialized
INFO - 2024-06-20 10:38:53 --> Output Class Initialized
INFO - 2024-06-20 10:38:53 --> Security Class Initialized
DEBUG - 2024-06-20 10:38:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-20 10:38:53 --> Input Class Initialized
INFO - 2024-06-20 10:38:53 --> Language Class Initialized
INFO - 2024-06-20 10:38:53 --> Language Class Initialized
INFO - 2024-06-20 10:38:53 --> Config Class Initialized
INFO - 2024-06-20 10:38:53 --> Loader Class Initialized
INFO - 2024-06-20 10:38:53 --> Helper loaded: url_helper
INFO - 2024-06-20 10:38:53 --> Helper loaded: file_helper
INFO - 2024-06-20 10:38:53 --> Helper loaded: form_helper
INFO - 2024-06-20 10:38:53 --> Helper loaded: my_helper
INFO - 2024-06-20 10:38:53 --> Database Driver Class Initialized
INFO - 2024-06-20 10:38:53 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-20 10:38:53 --> Controller Class Initialized
INFO - 2024-06-20 10:38:53 --> Final output sent to browser
DEBUG - 2024-06-20 10:38:53 --> Total execution time: 0.0255
INFO - 2024-06-20 10:39:40 --> Config Class Initialized
INFO - 2024-06-20 10:39:40 --> Hooks Class Initialized
DEBUG - 2024-06-20 10:39:40 --> UTF-8 Support Enabled
INFO - 2024-06-20 10:39:40 --> Utf8 Class Initialized
INFO - 2024-06-20 10:39:40 --> URI Class Initialized
INFO - 2024-06-20 10:39:40 --> Router Class Initialized
INFO - 2024-06-20 10:39:40 --> Output Class Initialized
INFO - 2024-06-20 10:39:40 --> Security Class Initialized
DEBUG - 2024-06-20 10:39:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-20 10:39:40 --> Input Class Initialized
INFO - 2024-06-20 10:39:40 --> Language Class Initialized
INFO - 2024-06-20 10:39:40 --> Language Class Initialized
INFO - 2024-06-20 10:39:40 --> Config Class Initialized
INFO - 2024-06-20 10:39:40 --> Loader Class Initialized
INFO - 2024-06-20 10:39:40 --> Helper loaded: url_helper
INFO - 2024-06-20 10:39:40 --> Helper loaded: file_helper
INFO - 2024-06-20 10:39:40 --> Helper loaded: form_helper
INFO - 2024-06-20 10:39:40 --> Helper loaded: my_helper
INFO - 2024-06-20 10:39:40 --> Database Driver Class Initialized
INFO - 2024-06-20 10:39:40 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-20 10:39:40 --> Controller Class Initialized
INFO - 2024-06-20 10:39:40 --> Final output sent to browser
DEBUG - 2024-06-20 10:39:40 --> Total execution time: 0.0281
INFO - 2024-06-20 13:48:05 --> Config Class Initialized
INFO - 2024-06-20 13:48:05 --> Hooks Class Initialized
DEBUG - 2024-06-20 13:48:05 --> UTF-8 Support Enabled
INFO - 2024-06-20 13:48:05 --> Utf8 Class Initialized
INFO - 2024-06-20 13:48:05 --> URI Class Initialized
INFO - 2024-06-20 13:48:05 --> Router Class Initialized
INFO - 2024-06-20 13:48:05 --> Output Class Initialized
INFO - 2024-06-20 13:48:05 --> Security Class Initialized
DEBUG - 2024-06-20 13:48:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-20 13:48:05 --> Input Class Initialized
INFO - 2024-06-20 13:48:05 --> Language Class Initialized
INFO - 2024-06-20 13:48:05 --> Language Class Initialized
INFO - 2024-06-20 13:48:05 --> Config Class Initialized
INFO - 2024-06-20 13:48:05 --> Loader Class Initialized
INFO - 2024-06-20 13:48:05 --> Helper loaded: url_helper
INFO - 2024-06-20 13:48:05 --> Helper loaded: file_helper
INFO - 2024-06-20 13:48:05 --> Helper loaded: form_helper
INFO - 2024-06-20 13:48:05 --> Helper loaded: my_helper
INFO - 2024-06-20 13:48:05 --> Database Driver Class Initialized
INFO - 2024-06-20 13:48:05 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-20 13:48:05 --> Controller Class Initialized
DEBUG - 2024-06-20 13:48:05 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/login/views/login.php
DEBUG - 2024-06-20 13:48:05 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-06-20 13:48:05 --> Final output sent to browser
DEBUG - 2024-06-20 13:48:05 --> Total execution time: 0.0472
INFO - 2024-06-20 13:56:27 --> Config Class Initialized
INFO - 2024-06-20 13:56:27 --> Hooks Class Initialized
DEBUG - 2024-06-20 13:56:27 --> UTF-8 Support Enabled
INFO - 2024-06-20 13:56:27 --> Utf8 Class Initialized
INFO - 2024-06-20 13:56:27 --> URI Class Initialized
INFO - 2024-06-20 13:56:27 --> Router Class Initialized
INFO - 2024-06-20 13:56:27 --> Output Class Initialized
INFO - 2024-06-20 13:56:27 --> Security Class Initialized
DEBUG - 2024-06-20 13:56:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-20 13:56:27 --> Input Class Initialized
INFO - 2024-06-20 13:56:27 --> Language Class Initialized
INFO - 2024-06-20 13:56:27 --> Language Class Initialized
INFO - 2024-06-20 13:56:27 --> Config Class Initialized
INFO - 2024-06-20 13:56:27 --> Loader Class Initialized
INFO - 2024-06-20 13:56:27 --> Helper loaded: url_helper
INFO - 2024-06-20 13:56:27 --> Helper loaded: file_helper
INFO - 2024-06-20 13:56:27 --> Helper loaded: form_helper
INFO - 2024-06-20 13:56:27 --> Helper loaded: my_helper
INFO - 2024-06-20 13:56:27 --> Database Driver Class Initialized
INFO - 2024-06-20 13:56:27 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-20 13:56:27 --> Controller Class Initialized
DEBUG - 2024-06-20 13:56:27 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/login/views/login.php
DEBUG - 2024-06-20 13:56:27 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-06-20 13:56:27 --> Final output sent to browser
DEBUG - 2024-06-20 13:56:27 --> Total execution time: 0.1006
INFO - 2024-06-20 13:56:33 --> Config Class Initialized
INFO - 2024-06-20 13:56:33 --> Hooks Class Initialized
DEBUG - 2024-06-20 13:56:33 --> UTF-8 Support Enabled
INFO - 2024-06-20 13:56:33 --> Utf8 Class Initialized
INFO - 2024-06-20 13:56:33 --> URI Class Initialized
INFO - 2024-06-20 13:56:33 --> Router Class Initialized
INFO - 2024-06-20 13:56:33 --> Output Class Initialized
INFO - 2024-06-20 13:56:33 --> Security Class Initialized
DEBUG - 2024-06-20 13:56:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-20 13:56:33 --> Input Class Initialized
INFO - 2024-06-20 13:56:33 --> Language Class Initialized
INFO - 2024-06-20 13:56:33 --> Language Class Initialized
INFO - 2024-06-20 13:56:33 --> Config Class Initialized
INFO - 2024-06-20 13:56:33 --> Loader Class Initialized
INFO - 2024-06-20 13:56:33 --> Helper loaded: url_helper
INFO - 2024-06-20 13:56:33 --> Helper loaded: file_helper
INFO - 2024-06-20 13:56:33 --> Helper loaded: form_helper
INFO - 2024-06-20 13:56:33 --> Helper loaded: my_helper
INFO - 2024-06-20 13:56:33 --> Database Driver Class Initialized
INFO - 2024-06-20 13:56:33 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-20 13:56:33 --> Controller Class Initialized
INFO - 2024-06-20 13:56:33 --> Helper loaded: cookie_helper
INFO - 2024-06-20 13:56:33 --> Final output sent to browser
DEBUG - 2024-06-20 13:56:33 --> Total execution time: 0.0782
INFO - 2024-06-20 13:56:33 --> Config Class Initialized
INFO - 2024-06-20 13:56:33 --> Hooks Class Initialized
DEBUG - 2024-06-20 13:56:33 --> UTF-8 Support Enabled
INFO - 2024-06-20 13:56:33 --> Utf8 Class Initialized
INFO - 2024-06-20 13:56:33 --> URI Class Initialized
INFO - 2024-06-20 13:56:33 --> Router Class Initialized
INFO - 2024-06-20 13:56:33 --> Output Class Initialized
INFO - 2024-06-20 13:56:33 --> Security Class Initialized
DEBUG - 2024-06-20 13:56:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-20 13:56:33 --> Input Class Initialized
INFO - 2024-06-20 13:56:33 --> Language Class Initialized
INFO - 2024-06-20 13:56:33 --> Language Class Initialized
INFO - 2024-06-20 13:56:33 --> Config Class Initialized
INFO - 2024-06-20 13:56:33 --> Loader Class Initialized
INFO - 2024-06-20 13:56:33 --> Helper loaded: url_helper
INFO - 2024-06-20 13:56:33 --> Helper loaded: file_helper
INFO - 2024-06-20 13:56:33 --> Helper loaded: form_helper
INFO - 2024-06-20 13:56:33 --> Helper loaded: my_helper
INFO - 2024-06-20 13:56:33 --> Database Driver Class Initialized
INFO - 2024-06-20 13:56:33 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-20 13:56:33 --> Controller Class Initialized
DEBUG - 2024-06-20 13:56:33 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/home/views/v_home.php
DEBUG - 2024-06-20 13:56:33 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-06-20 13:56:33 --> Final output sent to browser
DEBUG - 2024-06-20 13:56:33 --> Total execution time: 0.0449
INFO - 2024-06-20 13:56:45 --> Config Class Initialized
INFO - 2024-06-20 13:56:45 --> Hooks Class Initialized
DEBUG - 2024-06-20 13:56:45 --> UTF-8 Support Enabled
INFO - 2024-06-20 13:56:45 --> Utf8 Class Initialized
INFO - 2024-06-20 13:56:45 --> URI Class Initialized
INFO - 2024-06-20 13:56:45 --> Router Class Initialized
INFO - 2024-06-20 13:56:45 --> Output Class Initialized
INFO - 2024-06-20 13:56:45 --> Security Class Initialized
DEBUG - 2024-06-20 13:56:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-20 13:56:45 --> Input Class Initialized
INFO - 2024-06-20 13:56:45 --> Language Class Initialized
INFO - 2024-06-20 13:56:45 --> Language Class Initialized
INFO - 2024-06-20 13:56:45 --> Config Class Initialized
INFO - 2024-06-20 13:56:45 --> Loader Class Initialized
INFO - 2024-06-20 13:56:45 --> Helper loaded: url_helper
INFO - 2024-06-20 13:56:45 --> Helper loaded: file_helper
INFO - 2024-06-20 13:56:45 --> Helper loaded: form_helper
INFO - 2024-06-20 13:56:45 --> Helper loaded: my_helper
INFO - 2024-06-20 13:56:45 --> Database Driver Class Initialized
INFO - 2024-06-20 13:56:45 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-20 13:56:45 --> Controller Class Initialized
DEBUG - 2024-06-20 13:56:45 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/tahun/views/list.php
DEBUG - 2024-06-20 13:56:45 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-06-20 13:56:45 --> Final output sent to browser
DEBUG - 2024-06-20 13:56:45 --> Total execution time: 0.0409
INFO - 2024-06-20 13:56:45 --> Config Class Initialized
INFO - 2024-06-20 13:56:45 --> Hooks Class Initialized
DEBUG - 2024-06-20 13:56:45 --> UTF-8 Support Enabled
INFO - 2024-06-20 13:56:45 --> Utf8 Class Initialized
INFO - 2024-06-20 13:56:45 --> URI Class Initialized
INFO - 2024-06-20 13:56:45 --> Router Class Initialized
INFO - 2024-06-20 13:56:45 --> Output Class Initialized
INFO - 2024-06-20 13:56:45 --> Security Class Initialized
DEBUG - 2024-06-20 13:56:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-20 13:56:45 --> Input Class Initialized
INFO - 2024-06-20 13:56:45 --> Language Class Initialized
ERROR - 2024-06-20 13:56:45 --> 404 Page Not Found: /index
INFO - 2024-06-20 13:56:45 --> Config Class Initialized
INFO - 2024-06-20 13:56:45 --> Hooks Class Initialized
DEBUG - 2024-06-20 13:56:45 --> UTF-8 Support Enabled
INFO - 2024-06-20 13:56:45 --> Utf8 Class Initialized
INFO - 2024-06-20 13:56:45 --> URI Class Initialized
INFO - 2024-06-20 13:56:45 --> Router Class Initialized
INFO - 2024-06-20 13:56:45 --> Output Class Initialized
INFO - 2024-06-20 13:56:45 --> Security Class Initialized
DEBUG - 2024-06-20 13:56:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-20 13:56:45 --> Input Class Initialized
INFO - 2024-06-20 13:56:45 --> Language Class Initialized
INFO - 2024-06-20 13:56:45 --> Language Class Initialized
INFO - 2024-06-20 13:56:45 --> Config Class Initialized
INFO - 2024-06-20 13:56:45 --> Loader Class Initialized
INFO - 2024-06-20 13:56:45 --> Helper loaded: url_helper
INFO - 2024-06-20 13:56:45 --> Helper loaded: file_helper
INFO - 2024-06-20 13:56:45 --> Helper loaded: form_helper
INFO - 2024-06-20 13:56:45 --> Helper loaded: my_helper
INFO - 2024-06-20 13:56:45 --> Database Driver Class Initialized
INFO - 2024-06-20 13:56:45 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-20 13:56:45 --> Controller Class Initialized
INFO - 2024-06-20 13:56:47 --> Config Class Initialized
INFO - 2024-06-20 13:56:47 --> Hooks Class Initialized
DEBUG - 2024-06-20 13:56:47 --> UTF-8 Support Enabled
INFO - 2024-06-20 13:56:47 --> Utf8 Class Initialized
INFO - 2024-06-20 13:56:47 --> URI Class Initialized
INFO - 2024-06-20 13:56:47 --> Router Class Initialized
INFO - 2024-06-20 13:56:47 --> Output Class Initialized
INFO - 2024-06-20 13:56:47 --> Security Class Initialized
DEBUG - 2024-06-20 13:56:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-20 13:56:47 --> Input Class Initialized
INFO - 2024-06-20 13:56:47 --> Language Class Initialized
INFO - 2024-06-20 13:56:47 --> Language Class Initialized
INFO - 2024-06-20 13:56:47 --> Config Class Initialized
INFO - 2024-06-20 13:56:47 --> Loader Class Initialized
INFO - 2024-06-20 13:56:47 --> Helper loaded: url_helper
INFO - 2024-06-20 13:56:47 --> Helper loaded: file_helper
INFO - 2024-06-20 13:56:47 --> Helper loaded: form_helper
INFO - 2024-06-20 13:56:47 --> Helper loaded: my_helper
INFO - 2024-06-20 13:56:47 --> Database Driver Class Initialized
INFO - 2024-06-20 13:56:47 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-20 13:56:47 --> Controller Class Initialized
INFO - 2024-06-20 13:56:47 --> Final output sent to browser
DEBUG - 2024-06-20 13:56:47 --> Total execution time: 0.0466
INFO - 2024-06-20 13:56:47 --> Config Class Initialized
INFO - 2024-06-20 13:56:47 --> Hooks Class Initialized
DEBUG - 2024-06-20 13:56:47 --> UTF-8 Support Enabled
INFO - 2024-06-20 13:56:47 --> Utf8 Class Initialized
INFO - 2024-06-20 13:56:47 --> URI Class Initialized
INFO - 2024-06-20 13:56:47 --> Router Class Initialized
INFO - 2024-06-20 13:56:47 --> Output Class Initialized
INFO - 2024-06-20 13:56:47 --> Security Class Initialized
DEBUG - 2024-06-20 13:56:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-20 13:56:47 --> Input Class Initialized
INFO - 2024-06-20 13:56:47 --> Language Class Initialized
ERROR - 2024-06-20 13:56:47 --> 404 Page Not Found: /index
INFO - 2024-06-20 13:56:47 --> Config Class Initialized
INFO - 2024-06-20 13:56:47 --> Hooks Class Initialized
DEBUG - 2024-06-20 13:56:47 --> UTF-8 Support Enabled
INFO - 2024-06-20 13:56:47 --> Utf8 Class Initialized
INFO - 2024-06-20 13:56:47 --> URI Class Initialized
INFO - 2024-06-20 13:56:47 --> Router Class Initialized
INFO - 2024-06-20 13:56:47 --> Output Class Initialized
INFO - 2024-06-20 13:56:47 --> Security Class Initialized
DEBUG - 2024-06-20 13:56:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-20 13:56:47 --> Input Class Initialized
INFO - 2024-06-20 13:56:47 --> Language Class Initialized
INFO - 2024-06-20 13:56:47 --> Language Class Initialized
INFO - 2024-06-20 13:56:47 --> Config Class Initialized
INFO - 2024-06-20 13:56:47 --> Loader Class Initialized
INFO - 2024-06-20 13:56:47 --> Helper loaded: url_helper
INFO - 2024-06-20 13:56:47 --> Helper loaded: file_helper
INFO - 2024-06-20 13:56:47 --> Helper loaded: form_helper
INFO - 2024-06-20 13:56:47 --> Helper loaded: my_helper
INFO - 2024-06-20 13:56:47 --> Database Driver Class Initialized
INFO - 2024-06-20 13:56:48 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-20 13:56:48 --> Controller Class Initialized
INFO - 2024-06-20 13:57:02 --> Config Class Initialized
INFO - 2024-06-20 13:57:02 --> Hooks Class Initialized
DEBUG - 2024-06-20 13:57:02 --> UTF-8 Support Enabled
INFO - 2024-06-20 13:57:02 --> Utf8 Class Initialized
INFO - 2024-06-20 13:57:02 --> URI Class Initialized
INFO - 2024-06-20 13:57:02 --> Router Class Initialized
INFO - 2024-06-20 13:57:02 --> Output Class Initialized
INFO - 2024-06-20 13:57:02 --> Security Class Initialized
DEBUG - 2024-06-20 13:57:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-20 13:57:02 --> Input Class Initialized
INFO - 2024-06-20 13:57:02 --> Language Class Initialized
INFO - 2024-06-20 13:57:02 --> Language Class Initialized
INFO - 2024-06-20 13:57:02 --> Config Class Initialized
INFO - 2024-06-20 13:57:02 --> Loader Class Initialized
INFO - 2024-06-20 13:57:02 --> Helper loaded: url_helper
INFO - 2024-06-20 13:57:02 --> Helper loaded: file_helper
INFO - 2024-06-20 13:57:02 --> Helper loaded: form_helper
INFO - 2024-06-20 13:57:02 --> Helper loaded: my_helper
INFO - 2024-06-20 13:57:02 --> Database Driver Class Initialized
INFO - 2024-06-20 13:57:02 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-20 13:57:02 --> Controller Class Initialized
INFO - 2024-06-20 13:57:02 --> Helper loaded: cookie_helper
INFO - 2024-06-20 13:57:02 --> Config Class Initialized
INFO - 2024-06-20 13:57:02 --> Hooks Class Initialized
DEBUG - 2024-06-20 13:57:02 --> UTF-8 Support Enabled
INFO - 2024-06-20 13:57:02 --> Utf8 Class Initialized
INFO - 2024-06-20 13:57:02 --> URI Class Initialized
INFO - 2024-06-20 13:57:02 --> Router Class Initialized
INFO - 2024-06-20 13:57:02 --> Output Class Initialized
INFO - 2024-06-20 13:57:02 --> Security Class Initialized
DEBUG - 2024-06-20 13:57:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-20 13:57:02 --> Input Class Initialized
INFO - 2024-06-20 13:57:02 --> Language Class Initialized
INFO - 2024-06-20 13:57:02 --> Language Class Initialized
INFO - 2024-06-20 13:57:02 --> Config Class Initialized
INFO - 2024-06-20 13:57:02 --> Loader Class Initialized
INFO - 2024-06-20 13:57:02 --> Helper loaded: url_helper
INFO - 2024-06-20 13:57:02 --> Helper loaded: file_helper
INFO - 2024-06-20 13:57:02 --> Helper loaded: form_helper
INFO - 2024-06-20 13:57:02 --> Helper loaded: my_helper
INFO - 2024-06-20 13:57:02 --> Database Driver Class Initialized
INFO - 2024-06-20 13:57:02 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-20 13:57:02 --> Controller Class Initialized
INFO - 2024-06-20 13:57:02 --> Config Class Initialized
INFO - 2024-06-20 13:57:02 --> Hooks Class Initialized
DEBUG - 2024-06-20 13:57:02 --> UTF-8 Support Enabled
INFO - 2024-06-20 13:57:02 --> Utf8 Class Initialized
INFO - 2024-06-20 13:57:02 --> URI Class Initialized
INFO - 2024-06-20 13:57:02 --> Router Class Initialized
INFO - 2024-06-20 13:57:02 --> Output Class Initialized
INFO - 2024-06-20 13:57:02 --> Security Class Initialized
DEBUG - 2024-06-20 13:57:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-20 13:57:02 --> Input Class Initialized
INFO - 2024-06-20 13:57:02 --> Language Class Initialized
INFO - 2024-06-20 13:57:02 --> Language Class Initialized
INFO - 2024-06-20 13:57:02 --> Config Class Initialized
INFO - 2024-06-20 13:57:02 --> Loader Class Initialized
INFO - 2024-06-20 13:57:02 --> Helper loaded: url_helper
INFO - 2024-06-20 13:57:02 --> Helper loaded: file_helper
INFO - 2024-06-20 13:57:02 --> Helper loaded: form_helper
INFO - 2024-06-20 13:57:02 --> Helper loaded: my_helper
INFO - 2024-06-20 13:57:02 --> Database Driver Class Initialized
INFO - 2024-06-20 13:57:02 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-20 13:57:02 --> Controller Class Initialized
DEBUG - 2024-06-20 13:57:02 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/login/views/login.php
DEBUG - 2024-06-20 13:57:02 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-06-20 13:57:02 --> Final output sent to browser
DEBUG - 2024-06-20 13:57:02 --> Total execution time: 0.0400
INFO - 2024-06-20 13:57:12 --> Config Class Initialized
INFO - 2024-06-20 13:57:12 --> Hooks Class Initialized
DEBUG - 2024-06-20 13:57:12 --> UTF-8 Support Enabled
INFO - 2024-06-20 13:57:12 --> Utf8 Class Initialized
INFO - 2024-06-20 13:57:12 --> URI Class Initialized
INFO - 2024-06-20 13:57:12 --> Router Class Initialized
INFO - 2024-06-20 13:57:12 --> Output Class Initialized
INFO - 2024-06-20 13:57:12 --> Security Class Initialized
DEBUG - 2024-06-20 13:57:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-20 13:57:12 --> Input Class Initialized
INFO - 2024-06-20 13:57:12 --> Language Class Initialized
INFO - 2024-06-20 13:57:12 --> Language Class Initialized
INFO - 2024-06-20 13:57:12 --> Config Class Initialized
INFO - 2024-06-20 13:57:12 --> Loader Class Initialized
INFO - 2024-06-20 13:57:12 --> Helper loaded: url_helper
INFO - 2024-06-20 13:57:12 --> Helper loaded: file_helper
INFO - 2024-06-20 13:57:12 --> Helper loaded: form_helper
INFO - 2024-06-20 13:57:12 --> Helper loaded: my_helper
INFO - 2024-06-20 13:57:12 --> Database Driver Class Initialized
INFO - 2024-06-20 13:57:12 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-20 13:57:12 --> Controller Class Initialized
INFO - 2024-06-20 13:57:12 --> Helper loaded: cookie_helper
INFO - 2024-06-20 13:57:12 --> Final output sent to browser
DEBUG - 2024-06-20 13:57:12 --> Total execution time: 0.0311
INFO - 2024-06-20 13:57:12 --> Config Class Initialized
INFO - 2024-06-20 13:57:12 --> Hooks Class Initialized
DEBUG - 2024-06-20 13:57:12 --> UTF-8 Support Enabled
INFO - 2024-06-20 13:57:12 --> Utf8 Class Initialized
INFO - 2024-06-20 13:57:12 --> URI Class Initialized
INFO - 2024-06-20 13:57:12 --> Router Class Initialized
INFO - 2024-06-20 13:57:12 --> Output Class Initialized
INFO - 2024-06-20 13:57:12 --> Security Class Initialized
DEBUG - 2024-06-20 13:57:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-20 13:57:12 --> Input Class Initialized
INFO - 2024-06-20 13:57:12 --> Language Class Initialized
INFO - 2024-06-20 13:57:12 --> Language Class Initialized
INFO - 2024-06-20 13:57:12 --> Config Class Initialized
INFO - 2024-06-20 13:57:12 --> Loader Class Initialized
INFO - 2024-06-20 13:57:12 --> Helper loaded: url_helper
INFO - 2024-06-20 13:57:12 --> Helper loaded: file_helper
INFO - 2024-06-20 13:57:12 --> Helper loaded: form_helper
INFO - 2024-06-20 13:57:12 --> Helper loaded: my_helper
INFO - 2024-06-20 13:57:12 --> Database Driver Class Initialized
INFO - 2024-06-20 13:57:12 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-20 13:57:12 --> Controller Class Initialized
DEBUG - 2024-06-20 13:57:12 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/home/views/v_home_guru.php
DEBUG - 2024-06-20 13:57:12 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-06-20 13:57:12 --> Final output sent to browser
DEBUG - 2024-06-20 13:57:12 --> Total execution time: 0.0516
INFO - 2024-06-20 13:57:19 --> Config Class Initialized
INFO - 2024-06-20 13:57:19 --> Hooks Class Initialized
DEBUG - 2024-06-20 13:57:19 --> UTF-8 Support Enabled
INFO - 2024-06-20 13:57:19 --> Utf8 Class Initialized
INFO - 2024-06-20 13:57:19 --> URI Class Initialized
INFO - 2024-06-20 13:57:19 --> Router Class Initialized
INFO - 2024-06-20 13:57:19 --> Output Class Initialized
INFO - 2024-06-20 13:57:19 --> Security Class Initialized
DEBUG - 2024-06-20 13:57:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-20 13:57:19 --> Input Class Initialized
INFO - 2024-06-20 13:57:19 --> Language Class Initialized
INFO - 2024-06-20 13:57:19 --> Language Class Initialized
INFO - 2024-06-20 13:57:19 --> Config Class Initialized
INFO - 2024-06-20 13:57:19 --> Loader Class Initialized
INFO - 2024-06-20 13:57:19 --> Helper loaded: url_helper
INFO - 2024-06-20 13:57:19 --> Helper loaded: file_helper
INFO - 2024-06-20 13:57:19 --> Helper loaded: form_helper
INFO - 2024-06-20 13:57:19 --> Helper loaded: my_helper
INFO - 2024-06-20 13:57:19 --> Database Driver Class Initialized
INFO - 2024-06-20 13:57:19 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-20 13:57:19 --> Controller Class Initialized
DEBUG - 2024-06-20 13:57:19 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/views/list.php
DEBUG - 2024-06-20 13:57:19 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-06-20 13:57:19 --> Final output sent to browser
DEBUG - 2024-06-20 13:57:19 --> Total execution time: 0.0407
INFO - 2024-06-20 13:57:24 --> Config Class Initialized
INFO - 2024-06-20 13:57:24 --> Hooks Class Initialized
DEBUG - 2024-06-20 13:57:24 --> UTF-8 Support Enabled
INFO - 2024-06-20 13:57:24 --> Utf8 Class Initialized
INFO - 2024-06-20 13:57:24 --> URI Class Initialized
INFO - 2024-06-20 13:57:24 --> Router Class Initialized
INFO - 2024-06-20 13:57:24 --> Output Class Initialized
INFO - 2024-06-20 13:57:24 --> Security Class Initialized
DEBUG - 2024-06-20 13:57:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-20 13:57:24 --> Input Class Initialized
INFO - 2024-06-20 13:57:24 --> Language Class Initialized
INFO - 2024-06-20 13:57:25 --> Language Class Initialized
INFO - 2024-06-20 13:57:25 --> Config Class Initialized
INFO - 2024-06-20 13:57:25 --> Loader Class Initialized
INFO - 2024-06-20 13:57:25 --> Helper loaded: url_helper
INFO - 2024-06-20 13:57:25 --> Helper loaded: file_helper
INFO - 2024-06-20 13:57:25 --> Helper loaded: form_helper
INFO - 2024-06-20 13:57:25 --> Helper loaded: my_helper
INFO - 2024-06-20 13:57:25 --> Database Driver Class Initialized
INFO - 2024-06-20 13:57:25 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-20 13:57:25 --> Controller Class Initialized
DEBUG - 2024-06-20 13:57:25 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/views/cetak_ikm.php
INFO - 2024-06-20 13:57:26 --> Final output sent to browser
DEBUG - 2024-06-20 13:57:26 --> Total execution time: 1.5963
INFO - 2024-06-20 13:57:35 --> Config Class Initialized
INFO - 2024-06-20 13:57:35 --> Hooks Class Initialized
DEBUG - 2024-06-20 13:57:35 --> UTF-8 Support Enabled
INFO - 2024-06-20 13:57:35 --> Utf8 Class Initialized
INFO - 2024-06-20 13:57:35 --> URI Class Initialized
INFO - 2024-06-20 13:57:35 --> Router Class Initialized
INFO - 2024-06-20 13:57:35 --> Output Class Initialized
INFO - 2024-06-20 13:57:35 --> Security Class Initialized
DEBUG - 2024-06-20 13:57:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-20 13:57:35 --> Input Class Initialized
INFO - 2024-06-20 13:57:35 --> Language Class Initialized
INFO - 2024-06-20 13:57:35 --> Language Class Initialized
INFO - 2024-06-20 13:57:35 --> Config Class Initialized
INFO - 2024-06-20 13:57:35 --> Loader Class Initialized
INFO - 2024-06-20 13:57:35 --> Helper loaded: url_helper
INFO - 2024-06-20 13:57:35 --> Helper loaded: file_helper
INFO - 2024-06-20 13:57:35 --> Helper loaded: form_helper
INFO - 2024-06-20 13:57:35 --> Helper loaded: my_helper
INFO - 2024-06-20 13:57:35 --> Database Driver Class Initialized
INFO - 2024-06-20 13:57:35 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-20 13:57:35 --> Controller Class Initialized
DEBUG - 2024-06-20 13:57:36 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/views/cetak_mh.php
INFO - 2024-06-20 13:57:41 --> Final output sent to browser
DEBUG - 2024-06-20 13:57:41 --> Total execution time: 5.9162
INFO - 2024-06-20 13:58:52 --> Config Class Initialized
INFO - 2024-06-20 13:58:52 --> Hooks Class Initialized
DEBUG - 2024-06-20 13:58:52 --> UTF-8 Support Enabled
INFO - 2024-06-20 13:58:52 --> Utf8 Class Initialized
INFO - 2024-06-20 13:58:52 --> URI Class Initialized
INFO - 2024-06-20 13:58:52 --> Router Class Initialized
INFO - 2024-06-20 13:58:52 --> Output Class Initialized
INFO - 2024-06-20 13:58:52 --> Security Class Initialized
DEBUG - 2024-06-20 13:58:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-20 13:58:52 --> Input Class Initialized
INFO - 2024-06-20 13:58:52 --> Language Class Initialized
INFO - 2024-06-20 13:58:52 --> Language Class Initialized
INFO - 2024-06-20 13:58:52 --> Config Class Initialized
INFO - 2024-06-20 13:58:52 --> Loader Class Initialized
INFO - 2024-06-20 13:58:52 --> Helper loaded: url_helper
INFO - 2024-06-20 13:58:52 --> Helper loaded: file_helper
INFO - 2024-06-20 13:58:52 --> Helper loaded: form_helper
INFO - 2024-06-20 13:58:52 --> Helper loaded: my_helper
INFO - 2024-06-20 13:58:52 --> Database Driver Class Initialized
INFO - 2024-06-20 13:58:52 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-20 13:58:52 --> Controller Class Initialized
ERROR - 2024-06-20 13:58:52 --> Severity: Notice --> Undefined variable: projek /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/views/cetak_projek.php 107
DEBUG - 2024-06-20 13:58:52 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/views/cetak_projek.php
INFO - 2024-06-20 13:58:55 --> Final output sent to browser
DEBUG - 2024-06-20 13:58:55 --> Total execution time: 3.0817
INFO - 2024-06-20 13:59:23 --> Config Class Initialized
INFO - 2024-06-20 13:59:23 --> Hooks Class Initialized
DEBUG - 2024-06-20 13:59:23 --> UTF-8 Support Enabled
INFO - 2024-06-20 13:59:23 --> Utf8 Class Initialized
INFO - 2024-06-20 13:59:23 --> URI Class Initialized
INFO - 2024-06-20 13:59:23 --> Router Class Initialized
INFO - 2024-06-20 13:59:23 --> Output Class Initialized
INFO - 2024-06-20 13:59:23 --> Security Class Initialized
DEBUG - 2024-06-20 13:59:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-20 13:59:23 --> Input Class Initialized
INFO - 2024-06-20 13:59:23 --> Language Class Initialized
INFO - 2024-06-20 13:59:23 --> Language Class Initialized
INFO - 2024-06-20 13:59:23 --> Config Class Initialized
INFO - 2024-06-20 13:59:23 --> Loader Class Initialized
INFO - 2024-06-20 13:59:23 --> Helper loaded: url_helper
INFO - 2024-06-20 13:59:23 --> Helper loaded: file_helper
INFO - 2024-06-20 13:59:23 --> Helper loaded: form_helper
INFO - 2024-06-20 13:59:23 --> Helper loaded: my_helper
INFO - 2024-06-20 13:59:23 --> Database Driver Class Initialized
INFO - 2024-06-20 13:59:23 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-20 13:59:23 --> Controller Class Initialized
DEBUG - 2024-06-20 13:59:23 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/views/cetak_ikm.php
INFO - 2024-06-20 13:59:24 --> Final output sent to browser
DEBUG - 2024-06-20 13:59:24 --> Total execution time: 1.6755
INFO - 2024-06-20 14:00:04 --> Config Class Initialized
INFO - 2024-06-20 14:00:04 --> Hooks Class Initialized
DEBUG - 2024-06-20 14:00:04 --> UTF-8 Support Enabled
INFO - 2024-06-20 14:00:04 --> Utf8 Class Initialized
INFO - 2024-06-20 14:00:04 --> URI Class Initialized
INFO - 2024-06-20 14:00:04 --> Router Class Initialized
INFO - 2024-06-20 14:00:04 --> Output Class Initialized
INFO - 2024-06-20 14:00:04 --> Security Class Initialized
DEBUG - 2024-06-20 14:00:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-20 14:00:04 --> Input Class Initialized
INFO - 2024-06-20 14:00:04 --> Language Class Initialized
INFO - 2024-06-20 14:00:04 --> Language Class Initialized
INFO - 2024-06-20 14:00:04 --> Config Class Initialized
INFO - 2024-06-20 14:00:04 --> Loader Class Initialized
INFO - 2024-06-20 14:00:04 --> Helper loaded: url_helper
INFO - 2024-06-20 14:00:04 --> Helper loaded: file_helper
INFO - 2024-06-20 14:00:04 --> Helper loaded: form_helper
INFO - 2024-06-20 14:00:04 --> Helper loaded: my_helper
INFO - 2024-06-20 14:00:04 --> Database Driver Class Initialized
INFO - 2024-06-20 14:00:04 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-20 14:00:04 --> Controller Class Initialized
DEBUG - 2024-06-20 14:00:04 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/views/cetak_tahfiz.php
INFO - 2024-06-20 14:00:08 --> Final output sent to browser
DEBUG - 2024-06-20 14:00:08 --> Total execution time: 4.3096
INFO - 2024-06-20 14:01:37 --> Config Class Initialized
INFO - 2024-06-20 14:01:37 --> Hooks Class Initialized
DEBUG - 2024-06-20 14:01:37 --> UTF-8 Support Enabled
INFO - 2024-06-20 14:01:37 --> Utf8 Class Initialized
INFO - 2024-06-20 14:01:37 --> URI Class Initialized
INFO - 2024-06-20 14:01:37 --> Router Class Initialized
INFO - 2024-06-20 14:01:37 --> Output Class Initialized
INFO - 2024-06-20 14:01:37 --> Security Class Initialized
DEBUG - 2024-06-20 14:01:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-20 14:01:37 --> Input Class Initialized
INFO - 2024-06-20 14:01:37 --> Language Class Initialized
INFO - 2024-06-20 14:01:37 --> Language Class Initialized
INFO - 2024-06-20 14:01:37 --> Config Class Initialized
INFO - 2024-06-20 14:01:37 --> Loader Class Initialized
INFO - 2024-06-20 14:01:37 --> Helper loaded: url_helper
INFO - 2024-06-20 14:01:37 --> Helper loaded: file_helper
INFO - 2024-06-20 14:01:37 --> Helper loaded: form_helper
INFO - 2024-06-20 14:01:37 --> Helper loaded: my_helper
INFO - 2024-06-20 14:01:37 --> Database Driver Class Initialized
INFO - 2024-06-20 14:01:37 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-20 14:01:37 --> Controller Class Initialized
DEBUG - 2024-06-20 14:01:37 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/view_kelompok/views/v_view_kelompok.php
DEBUG - 2024-06-20 14:01:37 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-06-20 14:01:37 --> Final output sent to browser
DEBUG - 2024-06-20 14:01:37 --> Total execution time: 0.2715
INFO - 2024-06-20 14:01:45 --> Config Class Initialized
INFO - 2024-06-20 14:01:45 --> Hooks Class Initialized
DEBUG - 2024-06-20 14:01:45 --> UTF-8 Support Enabled
INFO - 2024-06-20 14:01:45 --> Utf8 Class Initialized
INFO - 2024-06-20 14:01:45 --> URI Class Initialized
INFO - 2024-06-20 14:01:45 --> Router Class Initialized
INFO - 2024-06-20 14:01:45 --> Output Class Initialized
INFO - 2024-06-20 14:01:45 --> Security Class Initialized
DEBUG - 2024-06-20 14:01:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-20 14:01:45 --> Input Class Initialized
INFO - 2024-06-20 14:01:45 --> Language Class Initialized
INFO - 2024-06-20 14:01:45 --> Language Class Initialized
INFO - 2024-06-20 14:01:45 --> Config Class Initialized
INFO - 2024-06-20 14:01:45 --> Loader Class Initialized
INFO - 2024-06-20 14:01:45 --> Helper loaded: url_helper
INFO - 2024-06-20 14:01:45 --> Helper loaded: file_helper
INFO - 2024-06-20 14:01:45 --> Helper loaded: form_helper
INFO - 2024-06-20 14:01:45 --> Helper loaded: my_helper
INFO - 2024-06-20 14:01:45 --> Database Driver Class Initialized
INFO - 2024-06-20 14:01:45 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-20 14:01:45 --> Controller Class Initialized
DEBUG - 2024-06-20 14:01:45 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_prestasi/views/list.php
DEBUG - 2024-06-20 14:01:45 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-06-20 14:01:45 --> Final output sent to browser
DEBUG - 2024-06-20 14:01:45 --> Total execution time: 0.0621
INFO - 2024-06-20 14:01:45 --> Config Class Initialized
INFO - 2024-06-20 14:01:45 --> Hooks Class Initialized
DEBUG - 2024-06-20 14:01:45 --> UTF-8 Support Enabled
INFO - 2024-06-20 14:01:45 --> Utf8 Class Initialized
INFO - 2024-06-20 14:01:45 --> URI Class Initialized
INFO - 2024-06-20 14:01:45 --> Router Class Initialized
INFO - 2024-06-20 14:01:45 --> Output Class Initialized
INFO - 2024-06-20 14:01:45 --> Security Class Initialized
DEBUG - 2024-06-20 14:01:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-20 14:01:45 --> Input Class Initialized
INFO - 2024-06-20 14:01:45 --> Language Class Initialized
ERROR - 2024-06-20 14:01:45 --> 404 Page Not Found: /index
INFO - 2024-06-20 14:01:45 --> Config Class Initialized
INFO - 2024-06-20 14:01:45 --> Hooks Class Initialized
DEBUG - 2024-06-20 14:01:45 --> UTF-8 Support Enabled
INFO - 2024-06-20 14:01:45 --> Utf8 Class Initialized
INFO - 2024-06-20 14:01:45 --> URI Class Initialized
INFO - 2024-06-20 14:01:45 --> Router Class Initialized
INFO - 2024-06-20 14:01:45 --> Output Class Initialized
INFO - 2024-06-20 14:01:45 --> Security Class Initialized
DEBUG - 2024-06-20 14:01:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-20 14:01:45 --> Input Class Initialized
INFO - 2024-06-20 14:01:45 --> Language Class Initialized
INFO - 2024-06-20 14:01:45 --> Language Class Initialized
INFO - 2024-06-20 14:01:45 --> Config Class Initialized
INFO - 2024-06-20 14:01:45 --> Loader Class Initialized
INFO - 2024-06-20 14:01:45 --> Helper loaded: url_helper
INFO - 2024-06-20 14:01:45 --> Helper loaded: file_helper
INFO - 2024-06-20 14:01:45 --> Helper loaded: form_helper
INFO - 2024-06-20 14:01:45 --> Helper loaded: my_helper
INFO - 2024-06-20 14:01:45 --> Database Driver Class Initialized
INFO - 2024-06-20 14:01:45 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-20 14:01:45 --> Controller Class Initialized
INFO - 2024-06-20 14:02:03 --> Config Class Initialized
INFO - 2024-06-20 14:02:03 --> Hooks Class Initialized
DEBUG - 2024-06-20 14:02:03 --> UTF-8 Support Enabled
INFO - 2024-06-20 14:02:03 --> Utf8 Class Initialized
INFO - 2024-06-20 14:02:03 --> URI Class Initialized
INFO - 2024-06-20 14:02:03 --> Router Class Initialized
INFO - 2024-06-20 14:02:03 --> Output Class Initialized
INFO - 2024-06-20 14:02:03 --> Security Class Initialized
DEBUG - 2024-06-20 14:02:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-20 14:02:03 --> Input Class Initialized
INFO - 2024-06-20 14:02:03 --> Language Class Initialized
INFO - 2024-06-20 14:02:03 --> Language Class Initialized
INFO - 2024-06-20 14:02:03 --> Config Class Initialized
INFO - 2024-06-20 14:02:03 --> Loader Class Initialized
INFO - 2024-06-20 14:02:03 --> Helper loaded: url_helper
INFO - 2024-06-20 14:02:03 --> Helper loaded: file_helper
INFO - 2024-06-20 14:02:03 --> Helper loaded: form_helper
INFO - 2024-06-20 14:02:03 --> Helper loaded: my_helper
INFO - 2024-06-20 14:02:03 --> Database Driver Class Initialized
INFO - 2024-06-20 14:02:03 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-20 14:02:03 --> Controller Class Initialized
DEBUG - 2024-06-20 14:02:03 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/list.php
DEBUG - 2024-06-20 14:02:03 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-06-20 14:02:03 --> Final output sent to browser
DEBUG - 2024-06-20 14:02:03 --> Total execution time: 0.0382
INFO - 2024-06-20 14:02:06 --> Config Class Initialized
INFO - 2024-06-20 14:02:06 --> Hooks Class Initialized
DEBUG - 2024-06-20 14:02:06 --> UTF-8 Support Enabled
INFO - 2024-06-20 14:02:06 --> Utf8 Class Initialized
INFO - 2024-06-20 14:02:06 --> URI Class Initialized
INFO - 2024-06-20 14:02:06 --> Router Class Initialized
INFO - 2024-06-20 14:02:06 --> Output Class Initialized
INFO - 2024-06-20 14:02:06 --> Security Class Initialized
DEBUG - 2024-06-20 14:02:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-20 14:02:06 --> Input Class Initialized
INFO - 2024-06-20 14:02:06 --> Language Class Initialized
INFO - 2024-06-20 14:02:06 --> Language Class Initialized
INFO - 2024-06-20 14:02:06 --> Config Class Initialized
INFO - 2024-06-20 14:02:06 --> Loader Class Initialized
INFO - 2024-06-20 14:02:06 --> Helper loaded: url_helper
INFO - 2024-06-20 14:02:06 --> Helper loaded: file_helper
INFO - 2024-06-20 14:02:06 --> Helper loaded: form_helper
INFO - 2024-06-20 14:02:06 --> Helper loaded: my_helper
INFO - 2024-06-20 14:02:06 --> Database Driver Class Initialized
INFO - 2024-06-20 14:02:06 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-20 14:02:06 --> Controller Class Initialized
DEBUG - 2024-06-20 14:02:06 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php
INFO - 2024-06-20 14:02:09 --> Final output sent to browser
DEBUG - 2024-06-20 14:02:09 --> Total execution time: 2.8878
INFO - 2024-06-20 14:03:42 --> Config Class Initialized
INFO - 2024-06-20 14:03:42 --> Hooks Class Initialized
DEBUG - 2024-06-20 14:03:42 --> UTF-8 Support Enabled
INFO - 2024-06-20 14:03:42 --> Utf8 Class Initialized
INFO - 2024-06-20 14:03:42 --> URI Class Initialized
INFO - 2024-06-20 14:03:42 --> Router Class Initialized
INFO - 2024-06-20 14:03:42 --> Output Class Initialized
INFO - 2024-06-20 14:03:42 --> Security Class Initialized
DEBUG - 2024-06-20 14:03:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-20 14:03:42 --> Input Class Initialized
INFO - 2024-06-20 14:03:42 --> Language Class Initialized
INFO - 2024-06-20 14:03:42 --> Language Class Initialized
INFO - 2024-06-20 14:03:42 --> Config Class Initialized
INFO - 2024-06-20 14:03:42 --> Loader Class Initialized
INFO - 2024-06-20 14:03:42 --> Helper loaded: url_helper
INFO - 2024-06-20 14:03:42 --> Helper loaded: file_helper
INFO - 2024-06-20 14:03:42 --> Helper loaded: form_helper
INFO - 2024-06-20 14:03:42 --> Helper loaded: my_helper
INFO - 2024-06-20 14:03:42 --> Database Driver Class Initialized
INFO - 2024-06-20 14:03:42 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-20 14:03:42 --> Controller Class Initialized
INFO - 2024-06-20 14:03:42 --> Helper loaded: cookie_helper
INFO - 2024-06-20 14:03:42 --> Config Class Initialized
INFO - 2024-06-20 14:03:42 --> Hooks Class Initialized
DEBUG - 2024-06-20 14:03:42 --> UTF-8 Support Enabled
INFO - 2024-06-20 14:03:42 --> Utf8 Class Initialized
INFO - 2024-06-20 14:03:42 --> URI Class Initialized
INFO - 2024-06-20 14:03:42 --> Router Class Initialized
INFO - 2024-06-20 14:03:42 --> Output Class Initialized
INFO - 2024-06-20 14:03:42 --> Security Class Initialized
DEBUG - 2024-06-20 14:03:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-20 14:03:42 --> Input Class Initialized
INFO - 2024-06-20 14:03:42 --> Language Class Initialized
INFO - 2024-06-20 14:03:42 --> Language Class Initialized
INFO - 2024-06-20 14:03:42 --> Config Class Initialized
INFO - 2024-06-20 14:03:42 --> Loader Class Initialized
INFO - 2024-06-20 14:03:42 --> Helper loaded: url_helper
INFO - 2024-06-20 14:03:42 --> Helper loaded: file_helper
INFO - 2024-06-20 14:03:42 --> Helper loaded: form_helper
INFO - 2024-06-20 14:03:42 --> Helper loaded: my_helper
INFO - 2024-06-20 14:03:42 --> Database Driver Class Initialized
INFO - 2024-06-20 14:03:42 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-20 14:03:42 --> Controller Class Initialized
INFO - 2024-06-20 14:03:42 --> Config Class Initialized
INFO - 2024-06-20 14:03:42 --> Hooks Class Initialized
DEBUG - 2024-06-20 14:03:42 --> UTF-8 Support Enabled
INFO - 2024-06-20 14:03:42 --> Utf8 Class Initialized
INFO - 2024-06-20 14:03:42 --> URI Class Initialized
INFO - 2024-06-20 14:03:42 --> Router Class Initialized
INFO - 2024-06-20 14:03:42 --> Output Class Initialized
INFO - 2024-06-20 14:03:42 --> Security Class Initialized
DEBUG - 2024-06-20 14:03:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-20 14:03:42 --> Input Class Initialized
INFO - 2024-06-20 14:03:42 --> Language Class Initialized
INFO - 2024-06-20 14:03:42 --> Language Class Initialized
INFO - 2024-06-20 14:03:42 --> Config Class Initialized
INFO - 2024-06-20 14:03:42 --> Loader Class Initialized
INFO - 2024-06-20 14:03:42 --> Helper loaded: url_helper
INFO - 2024-06-20 14:03:42 --> Helper loaded: file_helper
INFO - 2024-06-20 14:03:42 --> Helper loaded: form_helper
INFO - 2024-06-20 14:03:42 --> Helper loaded: my_helper
INFO - 2024-06-20 14:03:42 --> Database Driver Class Initialized
INFO - 2024-06-20 14:03:42 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-20 14:03:42 --> Controller Class Initialized
DEBUG - 2024-06-20 14:03:42 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/login/views/login.php
DEBUG - 2024-06-20 14:03:42 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-06-20 14:03:42 --> Final output sent to browser
DEBUG - 2024-06-20 14:03:42 --> Total execution time: 0.0275
INFO - 2024-06-20 14:06:10 --> Config Class Initialized
INFO - 2024-06-20 14:06:10 --> Hooks Class Initialized
DEBUG - 2024-06-20 14:06:10 --> UTF-8 Support Enabled
INFO - 2024-06-20 14:06:10 --> Utf8 Class Initialized
INFO - 2024-06-20 14:06:10 --> URI Class Initialized
INFO - 2024-06-20 14:06:10 --> Router Class Initialized
INFO - 2024-06-20 14:06:10 --> Output Class Initialized
INFO - 2024-06-20 14:06:10 --> Security Class Initialized
DEBUG - 2024-06-20 14:06:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-20 14:06:10 --> Input Class Initialized
INFO - 2024-06-20 14:06:10 --> Language Class Initialized
INFO - 2024-06-20 14:06:10 --> Language Class Initialized
INFO - 2024-06-20 14:06:10 --> Config Class Initialized
INFO - 2024-06-20 14:06:10 --> Loader Class Initialized
INFO - 2024-06-20 14:06:10 --> Helper loaded: url_helper
INFO - 2024-06-20 14:06:10 --> Helper loaded: file_helper
INFO - 2024-06-20 14:06:10 --> Helper loaded: form_helper
INFO - 2024-06-20 14:06:10 --> Helper loaded: my_helper
INFO - 2024-06-20 14:06:10 --> Database Driver Class Initialized
INFO - 2024-06-20 14:06:10 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-20 14:06:10 --> Controller Class Initialized
DEBUG - 2024-06-20 14:06:10 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/data_mapel/views/list.php
DEBUG - 2024-06-20 14:06:10 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-06-20 14:06:10 --> Final output sent to browser
DEBUG - 2024-06-20 14:06:10 --> Total execution time: 0.1055
INFO - 2024-06-20 14:06:10 --> Config Class Initialized
INFO - 2024-06-20 14:06:10 --> Hooks Class Initialized
DEBUG - 2024-06-20 14:06:10 --> UTF-8 Support Enabled
INFO - 2024-06-20 14:06:10 --> Utf8 Class Initialized
INFO - 2024-06-20 14:06:10 --> URI Class Initialized
INFO - 2024-06-20 14:06:10 --> Router Class Initialized
INFO - 2024-06-20 14:06:10 --> Output Class Initialized
INFO - 2024-06-20 14:06:10 --> Security Class Initialized
DEBUG - 2024-06-20 14:06:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-20 14:06:10 --> Input Class Initialized
INFO - 2024-06-20 14:06:10 --> Language Class Initialized
ERROR - 2024-06-20 14:06:10 --> 404 Page Not Found: /index
INFO - 2024-06-20 14:06:10 --> Config Class Initialized
INFO - 2024-06-20 14:06:10 --> Hooks Class Initialized
DEBUG - 2024-06-20 14:06:10 --> UTF-8 Support Enabled
INFO - 2024-06-20 14:06:10 --> Utf8 Class Initialized
INFO - 2024-06-20 14:06:10 --> URI Class Initialized
INFO - 2024-06-20 14:06:10 --> Router Class Initialized
INFO - 2024-06-20 14:06:10 --> Output Class Initialized
INFO - 2024-06-20 14:06:10 --> Security Class Initialized
DEBUG - 2024-06-20 14:06:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-20 14:06:10 --> Input Class Initialized
INFO - 2024-06-20 14:06:10 --> Language Class Initialized
INFO - 2024-06-20 14:06:10 --> Language Class Initialized
INFO - 2024-06-20 14:06:10 --> Config Class Initialized
INFO - 2024-06-20 14:06:10 --> Loader Class Initialized
INFO - 2024-06-20 14:06:10 --> Helper loaded: url_helper
INFO - 2024-06-20 14:06:10 --> Helper loaded: file_helper
INFO - 2024-06-20 14:06:10 --> Helper loaded: form_helper
INFO - 2024-06-20 14:06:10 --> Helper loaded: my_helper
INFO - 2024-06-20 14:06:10 --> Database Driver Class Initialized
INFO - 2024-06-20 14:06:10 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-20 14:06:10 --> Controller Class Initialized
INFO - 2024-06-20 14:26:52 --> Config Class Initialized
INFO - 2024-06-20 14:26:52 --> Hooks Class Initialized
DEBUG - 2024-06-20 14:26:52 --> UTF-8 Support Enabled
INFO - 2024-06-20 14:26:52 --> Utf8 Class Initialized
INFO - 2024-06-20 14:26:52 --> URI Class Initialized
INFO - 2024-06-20 14:26:52 --> Router Class Initialized
INFO - 2024-06-20 14:26:52 --> Output Class Initialized
INFO - 2024-06-20 14:26:52 --> Security Class Initialized
DEBUG - 2024-06-20 14:26:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-20 14:26:52 --> Input Class Initialized
INFO - 2024-06-20 14:26:52 --> Language Class Initialized
INFO - 2024-06-20 14:26:52 --> Language Class Initialized
INFO - 2024-06-20 14:26:52 --> Config Class Initialized
INFO - 2024-06-20 14:26:52 --> Loader Class Initialized
INFO - 2024-06-20 14:26:52 --> Helper loaded: url_helper
INFO - 2024-06-20 14:26:52 --> Helper loaded: file_helper
INFO - 2024-06-20 14:26:52 --> Helper loaded: form_helper
INFO - 2024-06-20 14:26:52 --> Helper loaded: my_helper
INFO - 2024-06-20 14:26:52 --> Database Driver Class Initialized
INFO - 2024-06-20 14:26:52 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-20 14:26:52 --> Controller Class Initialized
INFO - 2024-06-20 14:26:52 --> Helper loaded: cookie_helper
INFO - 2024-06-20 14:26:52 --> Final output sent to browser
DEBUG - 2024-06-20 14:26:52 --> Total execution time: 0.0804
INFO - 2024-06-20 14:26:52 --> Config Class Initialized
INFO - 2024-06-20 14:26:52 --> Hooks Class Initialized
DEBUG - 2024-06-20 14:26:52 --> UTF-8 Support Enabled
INFO - 2024-06-20 14:26:52 --> Utf8 Class Initialized
INFO - 2024-06-20 14:26:52 --> URI Class Initialized
INFO - 2024-06-20 14:26:52 --> Router Class Initialized
INFO - 2024-06-20 14:26:52 --> Output Class Initialized
INFO - 2024-06-20 14:26:52 --> Security Class Initialized
DEBUG - 2024-06-20 14:26:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-20 14:26:52 --> Input Class Initialized
INFO - 2024-06-20 14:26:52 --> Language Class Initialized
INFO - 2024-06-20 14:26:52 --> Language Class Initialized
INFO - 2024-06-20 14:26:52 --> Config Class Initialized
INFO - 2024-06-20 14:26:52 --> Loader Class Initialized
INFO - 2024-06-20 14:26:52 --> Helper loaded: url_helper
INFO - 2024-06-20 14:26:52 --> Helper loaded: file_helper
INFO - 2024-06-20 14:26:52 --> Helper loaded: form_helper
INFO - 2024-06-20 14:26:52 --> Helper loaded: my_helper
INFO - 2024-06-20 14:26:52 --> Database Driver Class Initialized
INFO - 2024-06-20 14:26:52 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-20 14:26:52 --> Controller Class Initialized
DEBUG - 2024-06-20 14:26:52 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/home/views/v_home.php
DEBUG - 2024-06-20 14:26:52 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-06-20 14:26:52 --> Final output sent to browser
DEBUG - 2024-06-20 14:26:52 --> Total execution time: 0.1203
INFO - 2024-06-20 14:27:08 --> Config Class Initialized
INFO - 2024-06-20 14:27:08 --> Hooks Class Initialized
DEBUG - 2024-06-20 14:27:08 --> UTF-8 Support Enabled
INFO - 2024-06-20 14:27:08 --> Utf8 Class Initialized
INFO - 2024-06-20 14:27:08 --> URI Class Initialized
INFO - 2024-06-20 14:27:08 --> Router Class Initialized
INFO - 2024-06-20 14:27:08 --> Output Class Initialized
INFO - 2024-06-20 14:27:08 --> Security Class Initialized
DEBUG - 2024-06-20 14:27:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-20 14:27:08 --> Input Class Initialized
INFO - 2024-06-20 14:27:08 --> Language Class Initialized
INFO - 2024-06-20 14:27:08 --> Language Class Initialized
INFO - 2024-06-20 14:27:08 --> Config Class Initialized
INFO - 2024-06-20 14:27:08 --> Loader Class Initialized
INFO - 2024-06-20 14:27:08 --> Helper loaded: url_helper
INFO - 2024-06-20 14:27:08 --> Helper loaded: file_helper
INFO - 2024-06-20 14:27:08 --> Helper loaded: form_helper
INFO - 2024-06-20 14:27:08 --> Helper loaded: my_helper
INFO - 2024-06-20 14:27:08 --> Database Driver Class Initialized
INFO - 2024-06-20 14:27:08 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-20 14:27:08 --> Controller Class Initialized
DEBUG - 2024-06-20 14:27:08 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/set_walikelas/views/list.php
DEBUG - 2024-06-20 14:27:08 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-06-20 14:27:08 --> Final output sent to browser
DEBUG - 2024-06-20 14:27:08 --> Total execution time: 0.0745
INFO - 2024-06-20 14:27:09 --> Config Class Initialized
INFO - 2024-06-20 14:27:09 --> Hooks Class Initialized
DEBUG - 2024-06-20 14:27:09 --> UTF-8 Support Enabled
INFO - 2024-06-20 14:27:09 --> Utf8 Class Initialized
INFO - 2024-06-20 14:27:09 --> URI Class Initialized
INFO - 2024-06-20 14:27:09 --> Router Class Initialized
INFO - 2024-06-20 14:27:09 --> Output Class Initialized
INFO - 2024-06-20 14:27:09 --> Security Class Initialized
DEBUG - 2024-06-20 14:27:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-20 14:27:09 --> Input Class Initialized
INFO - 2024-06-20 14:27:09 --> Language Class Initialized
ERROR - 2024-06-20 14:27:09 --> 404 Page Not Found: /index
INFO - 2024-06-20 14:27:09 --> Config Class Initialized
INFO - 2024-06-20 14:27:09 --> Hooks Class Initialized
DEBUG - 2024-06-20 14:27:09 --> UTF-8 Support Enabled
INFO - 2024-06-20 14:27:09 --> Utf8 Class Initialized
INFO - 2024-06-20 14:27:09 --> URI Class Initialized
INFO - 2024-06-20 14:27:09 --> Router Class Initialized
INFO - 2024-06-20 14:27:09 --> Output Class Initialized
INFO - 2024-06-20 14:27:09 --> Security Class Initialized
DEBUG - 2024-06-20 14:27:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-20 14:27:09 --> Input Class Initialized
INFO - 2024-06-20 14:27:09 --> Language Class Initialized
INFO - 2024-06-20 14:27:09 --> Language Class Initialized
INFO - 2024-06-20 14:27:09 --> Config Class Initialized
INFO - 2024-06-20 14:27:09 --> Loader Class Initialized
INFO - 2024-06-20 14:27:09 --> Helper loaded: url_helper
INFO - 2024-06-20 14:27:09 --> Helper loaded: file_helper
INFO - 2024-06-20 14:27:09 --> Helper loaded: form_helper
INFO - 2024-06-20 14:27:09 --> Helper loaded: my_helper
INFO - 2024-06-20 14:27:09 --> Database Driver Class Initialized
INFO - 2024-06-20 14:27:09 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-20 14:27:09 --> Controller Class Initialized
INFO - 2024-06-20 14:27:13 --> Config Class Initialized
INFO - 2024-06-20 14:27:13 --> Hooks Class Initialized
DEBUG - 2024-06-20 14:27:13 --> UTF-8 Support Enabled
INFO - 2024-06-20 14:27:13 --> Utf8 Class Initialized
INFO - 2024-06-20 14:27:13 --> URI Class Initialized
INFO - 2024-06-20 14:27:13 --> Router Class Initialized
INFO - 2024-06-20 14:27:13 --> Output Class Initialized
INFO - 2024-06-20 14:27:13 --> Security Class Initialized
DEBUG - 2024-06-20 14:27:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-20 14:27:13 --> Input Class Initialized
INFO - 2024-06-20 14:27:13 --> Language Class Initialized
INFO - 2024-06-20 14:27:13 --> Language Class Initialized
INFO - 2024-06-20 14:27:13 --> Config Class Initialized
INFO - 2024-06-20 14:27:13 --> Loader Class Initialized
INFO - 2024-06-20 14:27:13 --> Helper loaded: url_helper
INFO - 2024-06-20 14:27:13 --> Helper loaded: file_helper
INFO - 2024-06-20 14:27:13 --> Helper loaded: form_helper
INFO - 2024-06-20 14:27:13 --> Helper loaded: my_helper
INFO - 2024-06-20 14:27:13 --> Database Driver Class Initialized
INFO - 2024-06-20 14:27:13 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-20 14:27:13 --> Controller Class Initialized
DEBUG - 2024-06-20 14:27:13 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/tahun/views/list.php
DEBUG - 2024-06-20 14:27:13 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-06-20 14:27:13 --> Final output sent to browser
DEBUG - 2024-06-20 14:27:13 --> Total execution time: 0.0718
INFO - 2024-06-20 14:27:13 --> Config Class Initialized
INFO - 2024-06-20 14:27:13 --> Hooks Class Initialized
DEBUG - 2024-06-20 14:27:13 --> UTF-8 Support Enabled
INFO - 2024-06-20 14:27:13 --> Utf8 Class Initialized
INFO - 2024-06-20 14:27:13 --> URI Class Initialized
INFO - 2024-06-20 14:27:13 --> Router Class Initialized
INFO - 2024-06-20 14:27:13 --> Output Class Initialized
INFO - 2024-06-20 14:27:13 --> Security Class Initialized
DEBUG - 2024-06-20 14:27:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-20 14:27:13 --> Input Class Initialized
INFO - 2024-06-20 14:27:13 --> Language Class Initialized
ERROR - 2024-06-20 14:27:13 --> 404 Page Not Found: /index
INFO - 2024-06-20 14:27:13 --> Config Class Initialized
INFO - 2024-06-20 14:27:13 --> Hooks Class Initialized
DEBUG - 2024-06-20 14:27:13 --> UTF-8 Support Enabled
INFO - 2024-06-20 14:27:13 --> Utf8 Class Initialized
INFO - 2024-06-20 14:27:13 --> URI Class Initialized
INFO - 2024-06-20 14:27:13 --> Router Class Initialized
INFO - 2024-06-20 14:27:13 --> Output Class Initialized
INFO - 2024-06-20 14:27:13 --> Security Class Initialized
DEBUG - 2024-06-20 14:27:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-20 14:27:13 --> Input Class Initialized
INFO - 2024-06-20 14:27:13 --> Language Class Initialized
INFO - 2024-06-20 14:27:14 --> Language Class Initialized
INFO - 2024-06-20 14:27:14 --> Config Class Initialized
INFO - 2024-06-20 14:27:14 --> Loader Class Initialized
INFO - 2024-06-20 14:27:14 --> Helper loaded: url_helper
INFO - 2024-06-20 14:27:14 --> Helper loaded: file_helper
INFO - 2024-06-20 14:27:14 --> Helper loaded: form_helper
INFO - 2024-06-20 14:27:14 --> Helper loaded: my_helper
INFO - 2024-06-20 14:27:14 --> Database Driver Class Initialized
INFO - 2024-06-20 14:27:14 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-20 14:27:14 --> Controller Class Initialized
INFO - 2024-06-20 14:27:16 --> Config Class Initialized
INFO - 2024-06-20 14:27:16 --> Hooks Class Initialized
DEBUG - 2024-06-20 14:27:16 --> UTF-8 Support Enabled
INFO - 2024-06-20 14:27:16 --> Utf8 Class Initialized
INFO - 2024-06-20 14:27:16 --> URI Class Initialized
INFO - 2024-06-20 14:27:16 --> Router Class Initialized
INFO - 2024-06-20 14:27:16 --> Output Class Initialized
INFO - 2024-06-20 14:27:16 --> Security Class Initialized
DEBUG - 2024-06-20 14:27:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-20 14:27:16 --> Input Class Initialized
INFO - 2024-06-20 14:27:16 --> Language Class Initialized
INFO - 2024-06-20 14:27:16 --> Language Class Initialized
INFO - 2024-06-20 14:27:16 --> Config Class Initialized
INFO - 2024-06-20 14:27:16 --> Loader Class Initialized
INFO - 2024-06-20 14:27:16 --> Helper loaded: url_helper
INFO - 2024-06-20 14:27:16 --> Helper loaded: file_helper
INFO - 2024-06-20 14:27:16 --> Helper loaded: form_helper
INFO - 2024-06-20 14:27:16 --> Helper loaded: my_helper
INFO - 2024-06-20 14:27:17 --> Database Driver Class Initialized
INFO - 2024-06-20 14:27:17 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-20 14:27:17 --> Controller Class Initialized
INFO - 2024-06-20 14:27:17 --> Final output sent to browser
DEBUG - 2024-06-20 14:27:17 --> Total execution time: 0.6506
INFO - 2024-06-20 14:27:17 --> Config Class Initialized
INFO - 2024-06-20 14:27:17 --> Hooks Class Initialized
DEBUG - 2024-06-20 14:27:17 --> UTF-8 Support Enabled
INFO - 2024-06-20 14:27:17 --> Utf8 Class Initialized
INFO - 2024-06-20 14:27:17 --> URI Class Initialized
INFO - 2024-06-20 14:27:17 --> Router Class Initialized
INFO - 2024-06-20 14:27:17 --> Output Class Initialized
INFO - 2024-06-20 14:27:17 --> Security Class Initialized
DEBUG - 2024-06-20 14:27:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-20 14:27:17 --> Input Class Initialized
INFO - 2024-06-20 14:27:17 --> Language Class Initialized
ERROR - 2024-06-20 14:27:17 --> 404 Page Not Found: /index
INFO - 2024-06-20 14:27:17 --> Config Class Initialized
INFO - 2024-06-20 14:27:17 --> Hooks Class Initialized
DEBUG - 2024-06-20 14:27:17 --> UTF-8 Support Enabled
INFO - 2024-06-20 14:27:17 --> Utf8 Class Initialized
INFO - 2024-06-20 14:27:17 --> URI Class Initialized
INFO - 2024-06-20 14:27:17 --> Router Class Initialized
INFO - 2024-06-20 14:27:17 --> Output Class Initialized
INFO - 2024-06-20 14:27:17 --> Security Class Initialized
DEBUG - 2024-06-20 14:27:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-20 14:27:17 --> Input Class Initialized
INFO - 2024-06-20 14:27:17 --> Language Class Initialized
INFO - 2024-06-20 14:27:17 --> Language Class Initialized
INFO - 2024-06-20 14:27:17 --> Config Class Initialized
INFO - 2024-06-20 14:27:17 --> Loader Class Initialized
INFO - 2024-06-20 14:27:17 --> Helper loaded: url_helper
INFO - 2024-06-20 14:27:17 --> Helper loaded: file_helper
INFO - 2024-06-20 14:27:17 --> Helper loaded: form_helper
INFO - 2024-06-20 14:27:17 --> Helper loaded: my_helper
INFO - 2024-06-20 14:27:17 --> Database Driver Class Initialized
INFO - 2024-06-20 14:27:17 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-20 14:27:17 --> Controller Class Initialized
INFO - 2024-06-20 14:27:24 --> Config Class Initialized
INFO - 2024-06-20 14:27:24 --> Hooks Class Initialized
DEBUG - 2024-06-20 14:27:24 --> UTF-8 Support Enabled
INFO - 2024-06-20 14:27:24 --> Utf8 Class Initialized
INFO - 2024-06-20 14:27:24 --> URI Class Initialized
INFO - 2024-06-20 14:27:24 --> Router Class Initialized
INFO - 2024-06-20 14:27:24 --> Output Class Initialized
INFO - 2024-06-20 14:27:24 --> Security Class Initialized
DEBUG - 2024-06-20 14:27:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-20 14:27:24 --> Input Class Initialized
INFO - 2024-06-20 14:27:24 --> Language Class Initialized
INFO - 2024-06-20 14:27:24 --> Language Class Initialized
INFO - 2024-06-20 14:27:24 --> Config Class Initialized
INFO - 2024-06-20 14:27:24 --> Loader Class Initialized
INFO - 2024-06-20 14:27:24 --> Helper loaded: url_helper
INFO - 2024-06-20 14:27:24 --> Helper loaded: file_helper
INFO - 2024-06-20 14:27:24 --> Helper loaded: form_helper
INFO - 2024-06-20 14:27:24 --> Helper loaded: my_helper
INFO - 2024-06-20 14:27:24 --> Database Driver Class Initialized
INFO - 2024-06-20 14:27:24 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-20 14:27:24 --> Controller Class Initialized
INFO - 2024-06-20 14:27:24 --> Helper loaded: cookie_helper
INFO - 2024-06-20 14:27:24 --> Config Class Initialized
INFO - 2024-06-20 14:27:24 --> Hooks Class Initialized
DEBUG - 2024-06-20 14:27:24 --> UTF-8 Support Enabled
INFO - 2024-06-20 14:27:24 --> Utf8 Class Initialized
INFO - 2024-06-20 14:27:24 --> URI Class Initialized
INFO - 2024-06-20 14:27:24 --> Router Class Initialized
INFO - 2024-06-20 14:27:24 --> Output Class Initialized
INFO - 2024-06-20 14:27:24 --> Security Class Initialized
DEBUG - 2024-06-20 14:27:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-20 14:27:24 --> Input Class Initialized
INFO - 2024-06-20 14:27:24 --> Language Class Initialized
INFO - 2024-06-20 14:27:24 --> Language Class Initialized
INFO - 2024-06-20 14:27:24 --> Config Class Initialized
INFO - 2024-06-20 14:27:24 --> Loader Class Initialized
INFO - 2024-06-20 14:27:24 --> Helper loaded: url_helper
INFO - 2024-06-20 14:27:24 --> Helper loaded: file_helper
INFO - 2024-06-20 14:27:24 --> Helper loaded: form_helper
INFO - 2024-06-20 14:27:24 --> Helper loaded: my_helper
INFO - 2024-06-20 14:27:24 --> Database Driver Class Initialized
INFO - 2024-06-20 14:27:24 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-20 14:27:24 --> Controller Class Initialized
INFO - 2024-06-20 14:27:24 --> Config Class Initialized
INFO - 2024-06-20 14:27:24 --> Hooks Class Initialized
DEBUG - 2024-06-20 14:27:24 --> UTF-8 Support Enabled
INFO - 2024-06-20 14:27:24 --> Utf8 Class Initialized
INFO - 2024-06-20 14:27:24 --> URI Class Initialized
INFO - 2024-06-20 14:27:24 --> Router Class Initialized
INFO - 2024-06-20 14:27:24 --> Output Class Initialized
INFO - 2024-06-20 14:27:24 --> Security Class Initialized
DEBUG - 2024-06-20 14:27:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-20 14:27:24 --> Input Class Initialized
INFO - 2024-06-20 14:27:24 --> Language Class Initialized
INFO - 2024-06-20 14:27:24 --> Language Class Initialized
INFO - 2024-06-20 14:27:24 --> Config Class Initialized
INFO - 2024-06-20 14:27:24 --> Loader Class Initialized
INFO - 2024-06-20 14:27:24 --> Helper loaded: url_helper
INFO - 2024-06-20 14:27:24 --> Helper loaded: file_helper
INFO - 2024-06-20 14:27:24 --> Helper loaded: form_helper
INFO - 2024-06-20 14:27:24 --> Helper loaded: my_helper
INFO - 2024-06-20 14:27:24 --> Database Driver Class Initialized
INFO - 2024-06-20 14:27:24 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-20 14:27:24 --> Controller Class Initialized
DEBUG - 2024-06-20 14:27:24 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/login/views/login.php
DEBUG - 2024-06-20 14:27:24 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-06-20 14:27:24 --> Final output sent to browser
DEBUG - 2024-06-20 14:27:24 --> Total execution time: 0.0410
INFO - 2024-06-20 14:27:32 --> Config Class Initialized
INFO - 2024-06-20 14:27:32 --> Hooks Class Initialized
DEBUG - 2024-06-20 14:27:32 --> UTF-8 Support Enabled
INFO - 2024-06-20 14:27:32 --> Utf8 Class Initialized
INFO - 2024-06-20 14:27:32 --> URI Class Initialized
INFO - 2024-06-20 14:27:32 --> Router Class Initialized
INFO - 2024-06-20 14:27:32 --> Output Class Initialized
INFO - 2024-06-20 14:27:32 --> Security Class Initialized
DEBUG - 2024-06-20 14:27:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-20 14:27:32 --> Input Class Initialized
INFO - 2024-06-20 14:27:32 --> Language Class Initialized
INFO - 2024-06-20 14:27:32 --> Language Class Initialized
INFO - 2024-06-20 14:27:32 --> Config Class Initialized
INFO - 2024-06-20 14:27:32 --> Loader Class Initialized
INFO - 2024-06-20 14:27:32 --> Helper loaded: url_helper
INFO - 2024-06-20 14:27:32 --> Helper loaded: file_helper
INFO - 2024-06-20 14:27:32 --> Helper loaded: form_helper
INFO - 2024-06-20 14:27:32 --> Helper loaded: my_helper
INFO - 2024-06-20 14:27:32 --> Database Driver Class Initialized
INFO - 2024-06-20 14:27:32 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-20 14:27:32 --> Controller Class Initialized
INFO - 2024-06-20 14:27:32 --> Helper loaded: cookie_helper
INFO - 2024-06-20 14:27:32 --> Final output sent to browser
DEBUG - 2024-06-20 14:27:32 --> Total execution time: 0.1355
INFO - 2024-06-20 14:27:32 --> Config Class Initialized
INFO - 2024-06-20 14:27:32 --> Hooks Class Initialized
DEBUG - 2024-06-20 14:27:32 --> UTF-8 Support Enabled
INFO - 2024-06-20 14:27:32 --> Utf8 Class Initialized
INFO - 2024-06-20 14:27:32 --> URI Class Initialized
INFO - 2024-06-20 14:27:32 --> Router Class Initialized
INFO - 2024-06-20 14:27:32 --> Output Class Initialized
INFO - 2024-06-20 14:27:32 --> Security Class Initialized
DEBUG - 2024-06-20 14:27:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-20 14:27:32 --> Input Class Initialized
INFO - 2024-06-20 14:27:32 --> Language Class Initialized
INFO - 2024-06-20 14:27:32 --> Language Class Initialized
INFO - 2024-06-20 14:27:32 --> Config Class Initialized
INFO - 2024-06-20 14:27:32 --> Loader Class Initialized
INFO - 2024-06-20 14:27:32 --> Helper loaded: url_helper
INFO - 2024-06-20 14:27:32 --> Helper loaded: file_helper
INFO - 2024-06-20 14:27:32 --> Helper loaded: form_helper
INFO - 2024-06-20 14:27:32 --> Helper loaded: my_helper
INFO - 2024-06-20 14:27:32 --> Database Driver Class Initialized
INFO - 2024-06-20 14:27:32 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-20 14:27:32 --> Controller Class Initialized
DEBUG - 2024-06-20 14:27:32 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/home/views/v_home_guru.php
DEBUG - 2024-06-20 14:27:32 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-06-20 14:27:32 --> Final output sent to browser
DEBUG - 2024-06-20 14:27:32 --> Total execution time: 0.0693
INFO - 2024-06-20 14:27:37 --> Config Class Initialized
INFO - 2024-06-20 14:27:37 --> Hooks Class Initialized
DEBUG - 2024-06-20 14:27:37 --> UTF-8 Support Enabled
INFO - 2024-06-20 14:27:37 --> Utf8 Class Initialized
INFO - 2024-06-20 14:27:37 --> URI Class Initialized
INFO - 2024-06-20 14:27:37 --> Router Class Initialized
INFO - 2024-06-20 14:27:37 --> Output Class Initialized
INFO - 2024-06-20 14:27:37 --> Security Class Initialized
DEBUG - 2024-06-20 14:27:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-20 14:27:37 --> Input Class Initialized
INFO - 2024-06-20 14:27:37 --> Language Class Initialized
INFO - 2024-06-20 14:27:37 --> Language Class Initialized
INFO - 2024-06-20 14:27:37 --> Config Class Initialized
INFO - 2024-06-20 14:27:37 --> Loader Class Initialized
INFO - 2024-06-20 14:27:37 --> Helper loaded: url_helper
INFO - 2024-06-20 14:27:37 --> Helper loaded: file_helper
INFO - 2024-06-20 14:27:37 --> Helper loaded: form_helper
INFO - 2024-06-20 14:27:37 --> Helper loaded: my_helper
INFO - 2024-06-20 14:27:37 --> Database Driver Class Initialized
INFO - 2024-06-20 14:27:37 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-20 14:27:37 --> Controller Class Initialized
DEBUG - 2024-06-20 14:27:37 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/views/list.php
DEBUG - 2024-06-20 14:27:37 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-06-20 14:27:37 --> Final output sent to browser
DEBUG - 2024-06-20 14:27:37 --> Total execution time: 0.0413
INFO - 2024-06-20 14:27:41 --> Config Class Initialized
INFO - 2024-06-20 14:27:41 --> Hooks Class Initialized
DEBUG - 2024-06-20 14:27:41 --> UTF-8 Support Enabled
INFO - 2024-06-20 14:27:41 --> Utf8 Class Initialized
INFO - 2024-06-20 14:27:41 --> URI Class Initialized
INFO - 2024-06-20 14:27:41 --> Router Class Initialized
INFO - 2024-06-20 14:27:41 --> Output Class Initialized
INFO - 2024-06-20 14:27:41 --> Security Class Initialized
DEBUG - 2024-06-20 14:27:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-20 14:27:41 --> Input Class Initialized
INFO - 2024-06-20 14:27:41 --> Language Class Initialized
INFO - 2024-06-20 14:27:41 --> Language Class Initialized
INFO - 2024-06-20 14:27:41 --> Config Class Initialized
INFO - 2024-06-20 14:27:41 --> Loader Class Initialized
INFO - 2024-06-20 14:27:41 --> Helper loaded: url_helper
INFO - 2024-06-20 14:27:41 --> Helper loaded: file_helper
INFO - 2024-06-20 14:27:41 --> Helper loaded: form_helper
INFO - 2024-06-20 14:27:41 --> Helper loaded: my_helper
INFO - 2024-06-20 14:27:41 --> Database Driver Class Initialized
INFO - 2024-06-20 14:27:41 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-20 14:27:41 --> Controller Class Initialized
ERROR - 2024-06-20 14:27:41 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 3014
ERROR - 2024-06-20 14:27:41 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 3015
DEBUG - 2024-06-20 14:27:41 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/views/cetak_mh.php
INFO - 2024-06-20 14:27:47 --> Final output sent to browser
DEBUG - 2024-06-20 14:27:47 --> Total execution time: 6.0634
INFO - 2024-06-20 20:20:42 --> Config Class Initialized
INFO - 2024-06-20 20:20:42 --> Hooks Class Initialized
DEBUG - 2024-06-20 20:20:42 --> UTF-8 Support Enabled
INFO - 2024-06-20 20:20:42 --> Utf8 Class Initialized
INFO - 2024-06-20 20:20:42 --> URI Class Initialized
INFO - 2024-06-20 20:20:42 --> Router Class Initialized
INFO - 2024-06-20 20:20:42 --> Output Class Initialized
INFO - 2024-06-20 20:20:42 --> Security Class Initialized
DEBUG - 2024-06-20 20:20:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-20 20:20:42 --> Input Class Initialized
INFO - 2024-06-20 20:20:42 --> Language Class Initialized
INFO - 2024-06-20 20:20:42 --> Language Class Initialized
INFO - 2024-06-20 20:20:42 --> Config Class Initialized
INFO - 2024-06-20 20:20:42 --> Loader Class Initialized
INFO - 2024-06-20 20:20:42 --> Helper loaded: url_helper
INFO - 2024-06-20 20:20:42 --> Helper loaded: file_helper
INFO - 2024-06-20 20:20:42 --> Helper loaded: form_helper
INFO - 2024-06-20 20:20:42 --> Helper loaded: my_helper
INFO - 2024-06-20 20:20:42 --> Database Driver Class Initialized
INFO - 2024-06-20 20:20:42 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-20 20:20:42 --> Controller Class Initialized
INFO - 2024-06-20 20:20:42 --> Helper loaded: cookie_helper
INFO - 2024-06-20 20:20:42 --> Final output sent to browser
DEBUG - 2024-06-20 20:20:42 --> Total execution time: 0.0613
INFO - 2024-06-20 20:20:42 --> Config Class Initialized
INFO - 2024-06-20 20:20:42 --> Hooks Class Initialized
DEBUG - 2024-06-20 20:20:42 --> UTF-8 Support Enabled
INFO - 2024-06-20 20:20:42 --> Utf8 Class Initialized
INFO - 2024-06-20 20:20:42 --> URI Class Initialized
INFO - 2024-06-20 20:20:42 --> Router Class Initialized
INFO - 2024-06-20 20:20:42 --> Output Class Initialized
INFO - 2024-06-20 20:20:42 --> Security Class Initialized
DEBUG - 2024-06-20 20:20:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-20 20:20:42 --> Input Class Initialized
INFO - 2024-06-20 20:20:42 --> Language Class Initialized
INFO - 2024-06-20 20:20:42 --> Language Class Initialized
INFO - 2024-06-20 20:20:42 --> Config Class Initialized
INFO - 2024-06-20 20:20:42 --> Loader Class Initialized
INFO - 2024-06-20 20:20:42 --> Helper loaded: url_helper
INFO - 2024-06-20 20:20:42 --> Helper loaded: file_helper
INFO - 2024-06-20 20:20:42 --> Helper loaded: form_helper
INFO - 2024-06-20 20:20:42 --> Helper loaded: my_helper
INFO - 2024-06-20 20:20:42 --> Database Driver Class Initialized
INFO - 2024-06-20 20:20:42 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-20 20:20:42 --> Controller Class Initialized
INFO - 2024-06-20 20:20:42 --> Helper loaded: cookie_helper
INFO - 2024-06-20 20:20:43 --> Config Class Initialized
INFO - 2024-06-20 20:20:43 --> Hooks Class Initialized
DEBUG - 2024-06-20 20:20:43 --> UTF-8 Support Enabled
INFO - 2024-06-20 20:20:43 --> Utf8 Class Initialized
INFO - 2024-06-20 20:20:43 --> URI Class Initialized
INFO - 2024-06-20 20:20:43 --> Router Class Initialized
INFO - 2024-06-20 20:20:43 --> Output Class Initialized
INFO - 2024-06-20 20:20:43 --> Security Class Initialized
DEBUG - 2024-06-20 20:20:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-20 20:20:43 --> Input Class Initialized
INFO - 2024-06-20 20:20:43 --> Language Class Initialized
INFO - 2024-06-20 20:20:43 --> Language Class Initialized
INFO - 2024-06-20 20:20:43 --> Config Class Initialized
INFO - 2024-06-20 20:20:43 --> Loader Class Initialized
INFO - 2024-06-20 20:20:43 --> Helper loaded: url_helper
INFO - 2024-06-20 20:20:43 --> Helper loaded: file_helper
INFO - 2024-06-20 20:20:43 --> Helper loaded: form_helper
INFO - 2024-06-20 20:20:43 --> Helper loaded: my_helper
INFO - 2024-06-20 20:20:43 --> Database Driver Class Initialized
INFO - 2024-06-20 20:20:43 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-20 20:20:43 --> Controller Class Initialized
DEBUG - 2024-06-20 20:20:43 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/lihat_raport/views/list.php
DEBUG - 2024-06-20 20:20:43 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-06-20 20:20:43 --> Final output sent to browser
DEBUG - 2024-06-20 20:20:43 --> Total execution time: 0.0337
INFO - 2024-06-20 20:20:45 --> Config Class Initialized
INFO - 2024-06-20 20:20:45 --> Hooks Class Initialized
DEBUG - 2024-06-20 20:20:45 --> UTF-8 Support Enabled
INFO - 2024-06-20 20:20:45 --> Utf8 Class Initialized
INFO - 2024-06-20 20:20:45 --> URI Class Initialized
INFO - 2024-06-20 20:20:45 --> Router Class Initialized
INFO - 2024-06-20 20:20:45 --> Output Class Initialized
INFO - 2024-06-20 20:20:45 --> Security Class Initialized
DEBUG - 2024-06-20 20:20:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-20 20:20:45 --> Input Class Initialized
INFO - 2024-06-20 20:20:45 --> Language Class Initialized
INFO - 2024-06-20 20:20:45 --> Language Class Initialized
INFO - 2024-06-20 20:20:45 --> Config Class Initialized
INFO - 2024-06-20 20:20:45 --> Loader Class Initialized
INFO - 2024-06-20 20:20:45 --> Helper loaded: url_helper
INFO - 2024-06-20 20:20:45 --> Helper loaded: file_helper
INFO - 2024-06-20 20:20:45 --> Helper loaded: form_helper
INFO - 2024-06-20 20:20:45 --> Helper loaded: my_helper
INFO - 2024-06-20 20:20:45 --> Database Driver Class Initialized
INFO - 2024-06-20 20:20:45 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-20 20:20:45 --> Controller Class Initialized
INFO - 2024-06-20 20:20:45 --> Helper loaded: cookie_helper
INFO - 2024-06-20 20:20:45 --> Final output sent to browser
DEBUG - 2024-06-20 20:20:45 --> Total execution time: 0.0304
INFO - 2024-06-20 20:20:45 --> Config Class Initialized
INFO - 2024-06-20 20:20:45 --> Hooks Class Initialized
DEBUG - 2024-06-20 20:20:45 --> UTF-8 Support Enabled
INFO - 2024-06-20 20:20:45 --> Utf8 Class Initialized
INFO - 2024-06-20 20:20:45 --> URI Class Initialized
INFO - 2024-06-20 20:20:45 --> Router Class Initialized
INFO - 2024-06-20 20:20:45 --> Output Class Initialized
INFO - 2024-06-20 20:20:45 --> Security Class Initialized
DEBUG - 2024-06-20 20:20:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-20 20:20:45 --> Input Class Initialized
INFO - 2024-06-20 20:20:45 --> Language Class Initialized
INFO - 2024-06-20 20:20:45 --> Language Class Initialized
INFO - 2024-06-20 20:20:45 --> Config Class Initialized
INFO - 2024-06-20 20:20:45 --> Loader Class Initialized
INFO - 2024-06-20 20:20:45 --> Helper loaded: url_helper
INFO - 2024-06-20 20:20:45 --> Helper loaded: file_helper
INFO - 2024-06-20 20:20:45 --> Helper loaded: form_helper
INFO - 2024-06-20 20:20:45 --> Helper loaded: my_helper
INFO - 2024-06-20 20:20:45 --> Database Driver Class Initialized
INFO - 2024-06-20 20:20:45 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-20 20:20:45 --> Controller Class Initialized
INFO - 2024-06-20 20:20:45 --> Helper loaded: cookie_helper
INFO - 2024-06-20 20:20:45 --> Config Class Initialized
INFO - 2024-06-20 20:20:45 --> Hooks Class Initialized
DEBUG - 2024-06-20 20:20:45 --> UTF-8 Support Enabled
INFO - 2024-06-20 20:20:45 --> Utf8 Class Initialized
INFO - 2024-06-20 20:20:45 --> URI Class Initialized
INFO - 2024-06-20 20:20:45 --> Router Class Initialized
INFO - 2024-06-20 20:20:45 --> Output Class Initialized
INFO - 2024-06-20 20:20:45 --> Security Class Initialized
DEBUG - 2024-06-20 20:20:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-20 20:20:45 --> Input Class Initialized
INFO - 2024-06-20 20:20:45 --> Language Class Initialized
INFO - 2024-06-20 20:20:45 --> Language Class Initialized
INFO - 2024-06-20 20:20:45 --> Config Class Initialized
INFO - 2024-06-20 20:20:45 --> Loader Class Initialized
INFO - 2024-06-20 20:20:45 --> Helper loaded: url_helper
INFO - 2024-06-20 20:20:45 --> Helper loaded: file_helper
INFO - 2024-06-20 20:20:45 --> Helper loaded: form_helper
INFO - 2024-06-20 20:20:45 --> Helper loaded: my_helper
INFO - 2024-06-20 20:20:45 --> Database Driver Class Initialized
INFO - 2024-06-20 20:20:45 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-20 20:20:45 --> Controller Class Initialized
DEBUG - 2024-06-20 20:20:45 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/lihat_raport/views/list.php
DEBUG - 2024-06-20 20:20:45 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-06-20 20:20:45 --> Final output sent to browser
DEBUG - 2024-06-20 20:20:45 --> Total execution time: 0.0282
INFO - 2024-06-20 20:20:48 --> Config Class Initialized
INFO - 2024-06-20 20:20:48 --> Hooks Class Initialized
DEBUG - 2024-06-20 20:20:48 --> UTF-8 Support Enabled
INFO - 2024-06-20 20:20:48 --> Utf8 Class Initialized
INFO - 2024-06-20 20:20:48 --> URI Class Initialized
INFO - 2024-06-20 20:20:48 --> Router Class Initialized
INFO - 2024-06-20 20:20:48 --> Output Class Initialized
INFO - 2024-06-20 20:20:48 --> Security Class Initialized
DEBUG - 2024-06-20 20:20:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-20 20:20:48 --> Input Class Initialized
INFO - 2024-06-20 20:20:48 --> Language Class Initialized
INFO - 2024-06-20 20:20:48 --> Language Class Initialized
INFO - 2024-06-20 20:20:48 --> Config Class Initialized
INFO - 2024-06-20 20:20:48 --> Loader Class Initialized
INFO - 2024-06-20 20:20:48 --> Helper loaded: url_helper
INFO - 2024-06-20 20:20:48 --> Helper loaded: file_helper
INFO - 2024-06-20 20:20:48 --> Helper loaded: form_helper
INFO - 2024-06-20 20:20:48 --> Helper loaded: my_helper
INFO - 2024-06-20 20:20:48 --> Database Driver Class Initialized
INFO - 2024-06-20 20:20:48 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-20 20:20:48 --> Controller Class Initialized
ERROR - 2024-06-20 20:20:48 --> Severity: Notice --> Undefined index: projek /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1837
ERROR - 2024-06-20 20:20:48 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2024-06-20 20:20:48 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2024-06-20 20:20:48 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2024-06-20 20:20:48 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2024-06-20 20:20:48 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2024-06-20 20:20:48 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2024-06-20 20:20:48 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2024-06-20 20:20:48 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2024-06-20 20:20:48 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2024-06-20 20:20:48 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2024-06-20 20:20:48 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2024-06-20 20:20:48 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2024-06-20 20:20:48 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2024-06-20 20:20:48 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2024-06-20 20:20:48 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2024-06-20 20:20:48 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2024-06-20 20:20:48 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2024-06-20 20:20:48 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2024-06-20 20:20:48 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2024-06-20 20:20:48 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2024-06-20 20:20:48 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2024-06-20 20:20:48 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2024-06-20 20:20:48 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2024-06-20 20:20:48 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2024-06-20 20:20:48 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2024-06-20 20:20:48 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2024-06-20 20:20:48 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2024-06-20 20:20:48 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2024-06-20 20:20:48 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2024-06-20 20:20:48 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2024-06-20 20:20:48 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2024-06-20 20:20:48 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2024-06-20 20:20:48 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2024-06-20 20:20:48 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2024-06-20 20:20:48 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2024-06-20 20:20:48 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2024-06-20 20:20:48 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2024-06-20 20:20:48 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2024-06-20 20:20:48 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
DEBUG - 2024-06-20 20:20:48 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/views/cetak_projek.php
INFO - 2024-06-20 20:20:53 --> Final output sent to browser
DEBUG - 2024-06-20 20:20:53 --> Total execution time: 5.3322
INFO - 2024-06-20 20:21:40 --> Config Class Initialized
INFO - 2024-06-20 20:21:40 --> Hooks Class Initialized
DEBUG - 2024-06-20 20:21:40 --> UTF-8 Support Enabled
INFO - 2024-06-20 20:21:40 --> Utf8 Class Initialized
INFO - 2024-06-20 20:21:40 --> URI Class Initialized
INFO - 2024-06-20 20:21:40 --> Router Class Initialized
INFO - 2024-06-20 20:21:40 --> Output Class Initialized
INFO - 2024-06-20 20:21:40 --> Security Class Initialized
DEBUG - 2024-06-20 20:21:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-20 20:21:40 --> Input Class Initialized
INFO - 2024-06-20 20:21:40 --> Language Class Initialized
INFO - 2024-06-20 20:21:40 --> Language Class Initialized
INFO - 2024-06-20 20:21:40 --> Config Class Initialized
INFO - 2024-06-20 20:21:40 --> Loader Class Initialized
INFO - 2024-06-20 20:21:40 --> Helper loaded: url_helper
INFO - 2024-06-20 20:21:40 --> Helper loaded: file_helper
INFO - 2024-06-20 20:21:40 --> Helper loaded: form_helper
INFO - 2024-06-20 20:21:40 --> Helper loaded: my_helper
INFO - 2024-06-20 20:21:40 --> Database Driver Class Initialized
INFO - 2024-06-20 20:21:40 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-20 20:21:40 --> Controller Class Initialized
ERROR - 2024-06-20 20:21:40 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 3014
ERROR - 2024-06-20 20:21:40 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 3015
DEBUG - 2024-06-20 20:21:40 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/views/cetak_mh.php
INFO - 2024-06-20 20:21:44 --> Final output sent to browser
DEBUG - 2024-06-20 20:21:44 --> Total execution time: 4.2833
INFO - 2024-06-20 20:22:36 --> Config Class Initialized
INFO - 2024-06-20 20:22:36 --> Hooks Class Initialized
DEBUG - 2024-06-20 20:22:36 --> UTF-8 Support Enabled
INFO - 2024-06-20 20:22:36 --> Utf8 Class Initialized
INFO - 2024-06-20 20:22:36 --> URI Class Initialized
INFO - 2024-06-20 20:22:36 --> Router Class Initialized
INFO - 2024-06-20 20:22:36 --> Output Class Initialized
INFO - 2024-06-20 20:22:36 --> Security Class Initialized
DEBUG - 2024-06-20 20:22:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-20 20:22:36 --> Input Class Initialized
INFO - 2024-06-20 20:22:36 --> Language Class Initialized
INFO - 2024-06-20 20:22:36 --> Language Class Initialized
INFO - 2024-06-20 20:22:36 --> Config Class Initialized
INFO - 2024-06-20 20:22:36 --> Loader Class Initialized
INFO - 2024-06-20 20:22:36 --> Helper loaded: url_helper
INFO - 2024-06-20 20:22:36 --> Helper loaded: file_helper
INFO - 2024-06-20 20:22:36 --> Helper loaded: form_helper
INFO - 2024-06-20 20:22:36 --> Helper loaded: my_helper
INFO - 2024-06-20 20:22:36 --> Database Driver Class Initialized
INFO - 2024-06-20 20:22:36 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-20 20:22:36 --> Controller Class Initialized
DEBUG - 2024-06-20 20:22:36 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php
INFO - 2024-06-20 20:22:38 --> Final output sent to browser
DEBUG - 2024-06-20 20:22:38 --> Total execution time: 2.4990
INFO - 2024-06-20 20:23:33 --> Config Class Initialized
INFO - 2024-06-20 20:23:33 --> Hooks Class Initialized
DEBUG - 2024-06-20 20:23:33 --> UTF-8 Support Enabled
INFO - 2024-06-20 20:23:33 --> Utf8 Class Initialized
INFO - 2024-06-20 20:23:33 --> URI Class Initialized
INFO - 2024-06-20 20:23:33 --> Router Class Initialized
INFO - 2024-06-20 20:23:33 --> Output Class Initialized
INFO - 2024-06-20 20:23:33 --> Security Class Initialized
DEBUG - 2024-06-20 20:23:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-20 20:23:33 --> Input Class Initialized
INFO - 2024-06-20 20:23:33 --> Language Class Initialized
INFO - 2024-06-20 20:23:33 --> Language Class Initialized
INFO - 2024-06-20 20:23:33 --> Config Class Initialized
INFO - 2024-06-20 20:23:33 --> Loader Class Initialized
INFO - 2024-06-20 20:23:33 --> Helper loaded: url_helper
INFO - 2024-06-20 20:23:33 --> Helper loaded: file_helper
INFO - 2024-06-20 20:23:33 --> Helper loaded: form_helper
INFO - 2024-06-20 20:23:33 --> Helper loaded: my_helper
INFO - 2024-06-20 20:23:33 --> Database Driver Class Initialized
INFO - 2024-06-20 20:23:33 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-20 20:23:33 --> Controller Class Initialized
DEBUG - 2024-06-20 20:23:33 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/views/cetak_ikm.php
INFO - 2024-06-20 20:23:34 --> Final output sent to browser
DEBUG - 2024-06-20 20:23:34 --> Total execution time: 1.8094
