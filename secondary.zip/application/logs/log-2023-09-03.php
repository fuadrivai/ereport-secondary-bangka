<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2023-09-03 18:10:39 --> Config Class Initialized
INFO - 2023-09-03 18:10:39 --> Hooks Class Initialized
DEBUG - 2023-09-03 18:10:39 --> UTF-8 Support Enabled
INFO - 2023-09-03 18:10:39 --> Utf8 Class Initialized
INFO - 2023-09-03 18:10:39 --> URI Class Initialized
INFO - 2023-09-03 18:10:39 --> Router Class Initialized
INFO - 2023-09-03 18:10:39 --> Output Class Initialized
INFO - 2023-09-03 18:10:39 --> Security Class Initialized
DEBUG - 2023-09-03 18:10:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-03 18:10:39 --> Input Class Initialized
INFO - 2023-09-03 18:10:39 --> Language Class Initialized
INFO - 2023-09-03 18:10:39 --> Language Class Initialized
INFO - 2023-09-03 18:10:39 --> Config Class Initialized
INFO - 2023-09-03 18:10:39 --> Loader Class Initialized
INFO - 2023-09-03 18:10:39 --> Helper loaded: url_helper
INFO - 2023-09-03 18:10:39 --> Helper loaded: file_helper
INFO - 2023-09-03 18:10:39 --> Helper loaded: form_helper
INFO - 2023-09-03 18:10:39 --> Helper loaded: my_helper
INFO - 2023-09-03 18:10:39 --> Database Driver Class Initialized
INFO - 2023-09-03 18:10:39 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-03 18:10:39 --> Controller Class Initialized
DEBUG - 2023-09-03 18:10:39 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/login/views/login.php
DEBUG - 2023-09-03 18:10:39 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-09-03 18:10:39 --> Final output sent to browser
DEBUG - 2023-09-03 18:10:39 --> Total execution time: 0.0836
