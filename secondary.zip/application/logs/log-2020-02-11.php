<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2020-02-11 04:38:38 --> Config Class Initialized
INFO - 2020-02-11 04:38:38 --> Hooks Class Initialized
DEBUG - 2020-02-11 04:38:39 --> UTF-8 Support Enabled
INFO - 2020-02-11 04:38:39 --> Utf8 Class Initialized
INFO - 2020-02-11 04:38:39 --> URI Class Initialized
DEBUG - 2020-02-11 04:38:39 --> No URI present. Default controller set.
INFO - 2020-02-11 04:38:39 --> Router Class Initialized
INFO - 2020-02-11 04:38:39 --> Output Class Initialized
INFO - 2020-02-11 04:38:39 --> Security Class Initialized
DEBUG - 2020-02-11 04:38:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-11 04:38:39 --> Input Class Initialized
INFO - 2020-02-11 04:38:39 --> Language Class Initialized
INFO - 2020-02-11 04:38:39 --> Language Class Initialized
INFO - 2020-02-11 04:38:39 --> Config Class Initialized
INFO - 2020-02-11 04:38:39 --> Loader Class Initialized
INFO - 2020-02-11 04:38:39 --> Helper loaded: url_helper
INFO - 2020-02-11 04:38:39 --> Helper loaded: file_helper
INFO - 2020-02-11 04:38:39 --> Helper loaded: form_helper
INFO - 2020-02-11 04:38:39 --> Helper loaded: my_helper
INFO - 2020-02-11 04:38:39 --> Database Driver Class Initialized
DEBUG - 2020-02-11 04:38:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-11 04:38:39 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-11 04:38:39 --> Controller Class Initialized
INFO - 2020-02-11 04:38:39 --> Config Class Initialized
INFO - 2020-02-11 04:38:39 --> Hooks Class Initialized
DEBUG - 2020-02-11 04:38:39 --> UTF-8 Support Enabled
INFO - 2020-02-11 04:38:39 --> Utf8 Class Initialized
INFO - 2020-02-11 04:38:39 --> URI Class Initialized
INFO - 2020-02-11 04:38:39 --> Router Class Initialized
INFO - 2020-02-11 04:38:39 --> Output Class Initialized
INFO - 2020-02-11 04:38:39 --> Security Class Initialized
DEBUG - 2020-02-11 04:38:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-11 04:38:40 --> Input Class Initialized
INFO - 2020-02-11 04:38:40 --> Language Class Initialized
INFO - 2020-02-11 04:38:40 --> Language Class Initialized
INFO - 2020-02-11 04:38:40 --> Config Class Initialized
INFO - 2020-02-11 04:38:40 --> Loader Class Initialized
INFO - 2020-02-11 04:38:40 --> Helper loaded: url_helper
INFO - 2020-02-11 04:38:40 --> Helper loaded: file_helper
INFO - 2020-02-11 04:38:40 --> Helper loaded: form_helper
INFO - 2020-02-11 04:38:40 --> Helper loaded: my_helper
INFO - 2020-02-11 04:38:40 --> Database Driver Class Initialized
DEBUG - 2020-02-11 04:38:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-11 04:38:40 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-11 04:38:40 --> Controller Class Initialized
DEBUG - 2020-02-11 04:38:40 --> File loaded: E:\xampp\htdocs\_2020\myraport\application\modules/login/views/login.php
DEBUG - 2020-02-11 04:38:40 --> File loaded: E:\xampp\htdocs\_2020\myraport\application\views\template_utama.php
INFO - 2020-02-11 04:38:40 --> Final output sent to browser
DEBUG - 2020-02-11 04:38:40 --> Total execution time: 0.3087
