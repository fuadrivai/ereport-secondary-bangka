<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2024-11-09 08:58:57 --> Config Class Initialized
INFO - 2024-11-09 08:58:57 --> Hooks Class Initialized
DEBUG - 2024-11-09 08:58:57 --> UTF-8 Support Enabled
INFO - 2024-11-09 08:58:57 --> Utf8 Class Initialized
INFO - 2024-11-09 08:58:57 --> URI Class Initialized
INFO - 2024-11-09 08:58:57 --> Router Class Initialized
INFO - 2024-11-09 08:58:57 --> Output Class Initialized
INFO - 2024-11-09 08:58:57 --> Security Class Initialized
DEBUG - 2024-11-09 08:58:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-11-09 08:58:57 --> Input Class Initialized
INFO - 2024-11-09 08:58:57 --> Language Class Initialized
INFO - 2024-11-09 08:58:57 --> Language Class Initialized
INFO - 2024-11-09 08:58:57 --> Config Class Initialized
INFO - 2024-11-09 08:58:57 --> Loader Class Initialized
INFO - 2024-11-09 08:58:57 --> Helper loaded: url_helper
INFO - 2024-11-09 08:58:57 --> Helper loaded: file_helper
INFO - 2024-11-09 08:58:57 --> Helper loaded: form_helper
INFO - 2024-11-09 08:58:57 --> Helper loaded: my_helper
INFO - 2024-11-09 08:58:57 --> Database Driver Class Initialized
INFO - 2024-11-09 08:58:57 --> Session: Class initialized using 'files' driver.
INFO - 2024-11-09 08:58:57 --> Controller Class Initialized
INFO - 2024-11-09 08:58:57 --> Helper loaded: cookie_helper
INFO - 2024-11-09 08:58:57 --> Final output sent to browser
DEBUG - 2024-11-09 08:58:57 --> Total execution time: 0.3289
INFO - 2024-11-09 08:58:58 --> Config Class Initialized
INFO - 2024-11-09 08:58:58 --> Hooks Class Initialized
DEBUG - 2024-11-09 08:58:58 --> UTF-8 Support Enabled
INFO - 2024-11-09 08:58:58 --> Utf8 Class Initialized
INFO - 2024-11-09 08:58:58 --> URI Class Initialized
INFO - 2024-11-09 08:58:58 --> Router Class Initialized
INFO - 2024-11-09 08:58:58 --> Output Class Initialized
INFO - 2024-11-09 08:58:58 --> Security Class Initialized
DEBUG - 2024-11-09 08:58:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-11-09 08:58:58 --> Input Class Initialized
INFO - 2024-11-09 08:58:58 --> Language Class Initialized
INFO - 2024-11-09 08:58:58 --> Language Class Initialized
INFO - 2024-11-09 08:58:58 --> Config Class Initialized
INFO - 2024-11-09 08:58:58 --> Loader Class Initialized
INFO - 2024-11-09 08:58:58 --> Helper loaded: url_helper
INFO - 2024-11-09 08:58:58 --> Helper loaded: file_helper
INFO - 2024-11-09 08:58:58 --> Helper loaded: form_helper
INFO - 2024-11-09 08:58:58 --> Helper loaded: my_helper
INFO - 2024-11-09 08:58:58 --> Database Driver Class Initialized
INFO - 2024-11-09 08:58:58 --> Session: Class initialized using 'files' driver.
INFO - 2024-11-09 08:58:58 --> Controller Class Initialized
INFO - 2024-11-09 08:58:58 --> Helper loaded: cookie_helper
INFO - 2024-11-09 08:58:58 --> Config Class Initialized
INFO - 2024-11-09 08:58:58 --> Hooks Class Initialized
DEBUG - 2024-11-09 08:58:58 --> UTF-8 Support Enabled
INFO - 2024-11-09 08:58:58 --> Utf8 Class Initialized
INFO - 2024-11-09 08:58:58 --> URI Class Initialized
INFO - 2024-11-09 08:58:58 --> Router Class Initialized
INFO - 2024-11-09 08:58:58 --> Output Class Initialized
INFO - 2024-11-09 08:58:58 --> Security Class Initialized
DEBUG - 2024-11-09 08:58:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-11-09 08:58:58 --> Input Class Initialized
INFO - 2024-11-09 08:58:58 --> Language Class Initialized
INFO - 2024-11-09 08:58:58 --> Language Class Initialized
INFO - 2024-11-09 08:58:58 --> Config Class Initialized
INFO - 2024-11-09 08:58:58 --> Loader Class Initialized
INFO - 2024-11-09 08:58:58 --> Helper loaded: url_helper
INFO - 2024-11-09 08:58:58 --> Helper loaded: file_helper
INFO - 2024-11-09 08:58:58 --> Helper loaded: form_helper
INFO - 2024-11-09 08:58:58 --> Helper loaded: my_helper
INFO - 2024-11-09 08:58:58 --> Database Driver Class Initialized
INFO - 2024-11-09 08:58:58 --> Session: Class initialized using 'files' driver.
INFO - 2024-11-09 08:58:58 --> Controller Class Initialized
DEBUG - 2024-11-09 08:58:58 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/lihat_raport/views/list.php
DEBUG - 2024-11-09 08:58:58 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-11-09 08:58:58 --> Final output sent to browser
DEBUG - 2024-11-09 08:58:58 --> Total execution time: 0.0542
