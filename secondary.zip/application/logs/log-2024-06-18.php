<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2024-06-18 07:33:04 --> Config Class Initialized
INFO - 2024-06-18 07:33:04 --> Hooks Class Initialized
DEBUG - 2024-06-18 07:33:04 --> UTF-8 Support Enabled
INFO - 2024-06-18 07:33:04 --> Utf8 Class Initialized
INFO - 2024-06-18 07:33:04 --> URI Class Initialized
DEBUG - 2024-06-18 07:33:04 --> No URI present. Default controller set.
INFO - 2024-06-18 07:33:04 --> Router Class Initialized
INFO - 2024-06-18 07:33:04 --> Output Class Initialized
INFO - 2024-06-18 07:33:04 --> Security Class Initialized
DEBUG - 2024-06-18 07:33:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-18 07:33:04 --> Input Class Initialized
INFO - 2024-06-18 07:33:04 --> Language Class Initialized
INFO - 2024-06-18 07:33:04 --> Language Class Initialized
INFO - 2024-06-18 07:33:04 --> Config Class Initialized
INFO - 2024-06-18 07:33:04 --> Loader Class Initialized
INFO - 2024-06-18 07:33:04 --> Helper loaded: url_helper
INFO - 2024-06-18 07:33:04 --> Helper loaded: file_helper
INFO - 2024-06-18 07:33:04 --> Helper loaded: form_helper
INFO - 2024-06-18 07:33:04 --> Helper loaded: my_helper
INFO - 2024-06-18 07:33:04 --> Database Driver Class Initialized
INFO - 2024-06-18 07:33:04 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-18 07:33:04 --> Controller Class Initialized
DEBUG - 2024-06-18 07:33:04 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/home/views/v_home_guru.php
DEBUG - 2024-06-18 07:33:04 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-06-18 07:33:04 --> Final output sent to browser
DEBUG - 2024-06-18 07:33:04 --> Total execution time: 0.0556
INFO - 2024-06-18 07:33:06 --> Config Class Initialized
INFO - 2024-06-18 07:33:06 --> Hooks Class Initialized
DEBUG - 2024-06-18 07:33:06 --> UTF-8 Support Enabled
INFO - 2024-06-18 07:33:06 --> Utf8 Class Initialized
INFO - 2024-06-18 07:33:06 --> URI Class Initialized
INFO - 2024-06-18 07:33:06 --> Router Class Initialized
INFO - 2024-06-18 07:33:06 --> Output Class Initialized
INFO - 2024-06-18 07:33:06 --> Security Class Initialized
DEBUG - 2024-06-18 07:33:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-18 07:33:06 --> Input Class Initialized
INFO - 2024-06-18 07:33:06 --> Language Class Initialized
INFO - 2024-06-18 07:33:06 --> Language Class Initialized
INFO - 2024-06-18 07:33:06 --> Config Class Initialized
INFO - 2024-06-18 07:33:06 --> Loader Class Initialized
INFO - 2024-06-18 07:33:06 --> Helper loaded: url_helper
INFO - 2024-06-18 07:33:06 --> Helper loaded: file_helper
INFO - 2024-06-18 07:33:06 --> Helper loaded: form_helper
INFO - 2024-06-18 07:33:06 --> Helper loaded: my_helper
INFO - 2024-06-18 07:33:06 --> Database Driver Class Initialized
INFO - 2024-06-18 07:33:06 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-18 07:33:06 --> Controller Class Initialized
DEBUG - 2024-06-18 07:33:06 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/view_mapel/views/v_view_mapel.php
DEBUG - 2024-06-18 07:33:06 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-06-18 07:33:06 --> Final output sent to browser
DEBUG - 2024-06-18 07:33:06 --> Total execution time: 0.0327
INFO - 2024-06-18 07:33:08 --> Config Class Initialized
INFO - 2024-06-18 07:33:08 --> Hooks Class Initialized
DEBUG - 2024-06-18 07:33:08 --> UTF-8 Support Enabled
INFO - 2024-06-18 07:33:08 --> Utf8 Class Initialized
INFO - 2024-06-18 07:33:08 --> URI Class Initialized
INFO - 2024-06-18 07:33:08 --> Router Class Initialized
INFO - 2024-06-18 07:33:08 --> Output Class Initialized
INFO - 2024-06-18 07:33:08 --> Security Class Initialized
DEBUG - 2024-06-18 07:33:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-18 07:33:08 --> Input Class Initialized
INFO - 2024-06-18 07:33:08 --> Language Class Initialized
INFO - 2024-06-18 07:33:08 --> Language Class Initialized
INFO - 2024-06-18 07:33:08 --> Config Class Initialized
INFO - 2024-06-18 07:33:08 --> Loader Class Initialized
INFO - 2024-06-18 07:33:08 --> Helper loaded: url_helper
INFO - 2024-06-18 07:33:08 --> Helper loaded: file_helper
INFO - 2024-06-18 07:33:08 --> Helper loaded: form_helper
INFO - 2024-06-18 07:33:08 --> Helper loaded: my_helper
INFO - 2024-06-18 07:33:08 --> Database Driver Class Initialized
INFO - 2024-06-18 07:33:08 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-18 07:33:08 --> Controller Class Initialized
DEBUG - 2024-06-18 07:33:08 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/views/list.php
DEBUG - 2024-06-18 07:33:08 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-06-18 07:33:08 --> Final output sent to browser
DEBUG - 2024-06-18 07:33:08 --> Total execution time: 0.0357
INFO - 2024-06-18 07:33:09 --> Config Class Initialized
INFO - 2024-06-18 07:33:09 --> Hooks Class Initialized
DEBUG - 2024-06-18 07:33:09 --> UTF-8 Support Enabled
INFO - 2024-06-18 07:33:09 --> Utf8 Class Initialized
INFO - 2024-06-18 07:33:09 --> URI Class Initialized
INFO - 2024-06-18 07:33:09 --> Router Class Initialized
INFO - 2024-06-18 07:33:09 --> Output Class Initialized
INFO - 2024-06-18 07:33:09 --> Security Class Initialized
DEBUG - 2024-06-18 07:33:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-18 07:33:09 --> Input Class Initialized
INFO - 2024-06-18 07:33:09 --> Language Class Initialized
INFO - 2024-06-18 07:33:09 --> Language Class Initialized
INFO - 2024-06-18 07:33:09 --> Config Class Initialized
INFO - 2024-06-18 07:33:09 --> Loader Class Initialized
INFO - 2024-06-18 07:33:09 --> Helper loaded: url_helper
INFO - 2024-06-18 07:33:09 --> Helper loaded: file_helper
INFO - 2024-06-18 07:33:09 --> Helper loaded: form_helper
INFO - 2024-06-18 07:33:09 --> Helper loaded: my_helper
INFO - 2024-06-18 07:33:09 --> Database Driver Class Initialized
INFO - 2024-06-18 07:33:09 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-18 07:33:09 --> Controller Class Initialized
INFO - 2024-06-18 07:33:12 --> Config Class Initialized
INFO - 2024-06-18 07:33:12 --> Hooks Class Initialized
DEBUG - 2024-06-18 07:33:12 --> UTF-8 Support Enabled
INFO - 2024-06-18 07:33:12 --> Utf8 Class Initialized
INFO - 2024-06-18 07:33:12 --> URI Class Initialized
INFO - 2024-06-18 07:33:12 --> Router Class Initialized
INFO - 2024-06-18 07:33:12 --> Output Class Initialized
INFO - 2024-06-18 07:33:12 --> Security Class Initialized
DEBUG - 2024-06-18 07:33:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-18 07:33:12 --> Input Class Initialized
INFO - 2024-06-18 07:33:12 --> Language Class Initialized
INFO - 2024-06-18 07:33:12 --> Language Class Initialized
INFO - 2024-06-18 07:33:12 --> Config Class Initialized
INFO - 2024-06-18 07:33:12 --> Loader Class Initialized
INFO - 2024-06-18 07:33:12 --> Helper loaded: url_helper
INFO - 2024-06-18 07:33:12 --> Helper loaded: file_helper
INFO - 2024-06-18 07:33:12 --> Helper loaded: form_helper
INFO - 2024-06-18 07:33:12 --> Helper loaded: my_helper
INFO - 2024-06-18 07:33:12 --> Database Driver Class Initialized
INFO - 2024-06-18 07:33:12 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-18 07:33:12 --> Controller Class Initialized
INFO - 2024-06-18 07:34:50 --> Config Class Initialized
INFO - 2024-06-18 07:34:50 --> Hooks Class Initialized
DEBUG - 2024-06-18 07:34:50 --> UTF-8 Support Enabled
INFO - 2024-06-18 07:34:50 --> Utf8 Class Initialized
INFO - 2024-06-18 07:34:50 --> URI Class Initialized
INFO - 2024-06-18 07:34:50 --> Router Class Initialized
INFO - 2024-06-18 07:34:50 --> Output Class Initialized
INFO - 2024-06-18 07:34:50 --> Security Class Initialized
DEBUG - 2024-06-18 07:34:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-18 07:34:50 --> Input Class Initialized
INFO - 2024-06-18 07:34:50 --> Language Class Initialized
INFO - 2024-06-18 07:34:50 --> Language Class Initialized
INFO - 2024-06-18 07:34:50 --> Config Class Initialized
INFO - 2024-06-18 07:34:50 --> Loader Class Initialized
INFO - 2024-06-18 07:34:50 --> Helper loaded: url_helper
INFO - 2024-06-18 07:34:50 --> Helper loaded: file_helper
INFO - 2024-06-18 07:34:50 --> Helper loaded: form_helper
INFO - 2024-06-18 07:34:50 --> Helper loaded: my_helper
INFO - 2024-06-18 07:34:50 --> Database Driver Class Initialized
INFO - 2024-06-18 07:34:50 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-18 07:34:50 --> Controller Class Initialized
INFO - 2024-06-18 07:34:50 --> Final output sent to browser
DEBUG - 2024-06-18 07:34:50 --> Total execution time: 0.0303
INFO - 2024-06-18 07:34:57 --> Config Class Initialized
INFO - 2024-06-18 07:34:57 --> Hooks Class Initialized
DEBUG - 2024-06-18 07:34:57 --> UTF-8 Support Enabled
INFO - 2024-06-18 07:34:57 --> Utf8 Class Initialized
INFO - 2024-06-18 07:34:57 --> URI Class Initialized
INFO - 2024-06-18 07:34:57 --> Router Class Initialized
INFO - 2024-06-18 07:34:57 --> Output Class Initialized
INFO - 2024-06-18 07:34:57 --> Security Class Initialized
DEBUG - 2024-06-18 07:34:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-18 07:34:57 --> Input Class Initialized
INFO - 2024-06-18 07:34:57 --> Language Class Initialized
INFO - 2024-06-18 07:34:57 --> Language Class Initialized
INFO - 2024-06-18 07:34:57 --> Config Class Initialized
INFO - 2024-06-18 07:34:57 --> Loader Class Initialized
INFO - 2024-06-18 07:34:57 --> Helper loaded: url_helper
INFO - 2024-06-18 07:34:57 --> Helper loaded: file_helper
INFO - 2024-06-18 07:34:57 --> Helper loaded: form_helper
INFO - 2024-06-18 07:34:57 --> Helper loaded: my_helper
INFO - 2024-06-18 07:34:57 --> Database Driver Class Initialized
INFO - 2024-06-18 07:34:57 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-18 07:34:57 --> Controller Class Initialized
INFO - 2024-06-18 07:34:57 --> Final output sent to browser
DEBUG - 2024-06-18 07:34:57 --> Total execution time: 0.1110
INFO - 2024-06-18 07:35:01 --> Config Class Initialized
INFO - 2024-06-18 07:35:01 --> Hooks Class Initialized
DEBUG - 2024-06-18 07:35:01 --> UTF-8 Support Enabled
INFO - 2024-06-18 07:35:01 --> Utf8 Class Initialized
INFO - 2024-06-18 07:35:01 --> URI Class Initialized
INFO - 2024-06-18 07:35:01 --> Router Class Initialized
INFO - 2024-06-18 07:35:01 --> Output Class Initialized
INFO - 2024-06-18 07:35:01 --> Security Class Initialized
DEBUG - 2024-06-18 07:35:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-18 07:35:01 --> Input Class Initialized
INFO - 2024-06-18 07:35:01 --> Language Class Initialized
INFO - 2024-06-18 07:35:01 --> Language Class Initialized
INFO - 2024-06-18 07:35:01 --> Config Class Initialized
INFO - 2024-06-18 07:35:01 --> Loader Class Initialized
INFO - 2024-06-18 07:35:01 --> Helper loaded: url_helper
INFO - 2024-06-18 07:35:01 --> Helper loaded: file_helper
INFO - 2024-06-18 07:35:01 --> Helper loaded: form_helper
INFO - 2024-06-18 07:35:01 --> Helper loaded: my_helper
INFO - 2024-06-18 07:35:01 --> Database Driver Class Initialized
INFO - 2024-06-18 07:35:01 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-18 07:35:01 --> Controller Class Initialized
INFO - 2024-06-18 07:35:50 --> Config Class Initialized
INFO - 2024-06-18 07:35:50 --> Hooks Class Initialized
DEBUG - 2024-06-18 07:35:50 --> UTF-8 Support Enabled
INFO - 2024-06-18 07:35:50 --> Utf8 Class Initialized
INFO - 2024-06-18 07:35:50 --> URI Class Initialized
DEBUG - 2024-06-18 07:35:50 --> No URI present. Default controller set.
INFO - 2024-06-18 07:35:50 --> Router Class Initialized
INFO - 2024-06-18 07:35:50 --> Output Class Initialized
INFO - 2024-06-18 07:35:50 --> Security Class Initialized
DEBUG - 2024-06-18 07:35:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-18 07:35:50 --> Input Class Initialized
INFO - 2024-06-18 07:35:50 --> Language Class Initialized
INFO - 2024-06-18 07:35:50 --> Language Class Initialized
INFO - 2024-06-18 07:35:50 --> Config Class Initialized
INFO - 2024-06-18 07:35:50 --> Loader Class Initialized
INFO - 2024-06-18 07:35:50 --> Helper loaded: url_helper
INFO - 2024-06-18 07:35:50 --> Helper loaded: file_helper
INFO - 2024-06-18 07:35:50 --> Helper loaded: form_helper
INFO - 2024-06-18 07:35:50 --> Helper loaded: my_helper
INFO - 2024-06-18 07:35:50 --> Database Driver Class Initialized
INFO - 2024-06-18 07:35:50 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-18 07:35:50 --> Controller Class Initialized
DEBUG - 2024-06-18 07:35:50 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/home/views/v_home_guru.php
DEBUG - 2024-06-18 07:35:50 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-06-18 07:35:50 --> Final output sent to browser
DEBUG - 2024-06-18 07:35:50 --> Total execution time: 0.0620
INFO - 2024-06-18 07:35:54 --> Config Class Initialized
INFO - 2024-06-18 07:35:54 --> Hooks Class Initialized
DEBUG - 2024-06-18 07:35:54 --> UTF-8 Support Enabled
INFO - 2024-06-18 07:35:54 --> Utf8 Class Initialized
INFO - 2024-06-18 07:35:54 --> URI Class Initialized
INFO - 2024-06-18 07:35:54 --> Router Class Initialized
INFO - 2024-06-18 07:35:54 --> Output Class Initialized
INFO - 2024-06-18 07:35:54 --> Security Class Initialized
DEBUG - 2024-06-18 07:35:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-18 07:35:54 --> Input Class Initialized
INFO - 2024-06-18 07:35:54 --> Language Class Initialized
INFO - 2024-06-18 07:35:54 --> Language Class Initialized
INFO - 2024-06-18 07:35:54 --> Config Class Initialized
INFO - 2024-06-18 07:35:54 --> Loader Class Initialized
INFO - 2024-06-18 07:35:54 --> Helper loaded: url_helper
INFO - 2024-06-18 07:35:54 --> Helper loaded: file_helper
INFO - 2024-06-18 07:35:54 --> Helper loaded: form_helper
INFO - 2024-06-18 07:35:54 --> Helper loaded: my_helper
INFO - 2024-06-18 07:35:54 --> Database Driver Class Initialized
INFO - 2024-06-18 07:35:54 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-18 07:35:54 --> Controller Class Initialized
DEBUG - 2024-06-18 07:35:54 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/view_mapel/views/v_view_mapel.php
DEBUG - 2024-06-18 07:35:54 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-06-18 07:35:54 --> Final output sent to browser
DEBUG - 2024-06-18 07:35:54 --> Total execution time: 0.0329
INFO - 2024-06-18 07:36:01 --> Config Class Initialized
INFO - 2024-06-18 07:36:01 --> Hooks Class Initialized
DEBUG - 2024-06-18 07:36:01 --> UTF-8 Support Enabled
INFO - 2024-06-18 07:36:01 --> Utf8 Class Initialized
INFO - 2024-06-18 07:36:01 --> URI Class Initialized
INFO - 2024-06-18 07:36:01 --> Router Class Initialized
INFO - 2024-06-18 07:36:01 --> Output Class Initialized
INFO - 2024-06-18 07:36:01 --> Security Class Initialized
DEBUG - 2024-06-18 07:36:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-18 07:36:01 --> Input Class Initialized
INFO - 2024-06-18 07:36:01 --> Language Class Initialized
INFO - 2024-06-18 07:36:01 --> Language Class Initialized
INFO - 2024-06-18 07:36:01 --> Config Class Initialized
INFO - 2024-06-18 07:36:01 --> Loader Class Initialized
INFO - 2024-06-18 07:36:01 --> Helper loaded: url_helper
INFO - 2024-06-18 07:36:01 --> Helper loaded: file_helper
INFO - 2024-06-18 07:36:01 --> Helper loaded: form_helper
INFO - 2024-06-18 07:36:01 --> Helper loaded: my_helper
INFO - 2024-06-18 07:36:01 --> Database Driver Class Initialized
INFO - 2024-06-18 07:36:01 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-18 07:36:01 --> Controller Class Initialized
INFO - 2024-06-18 07:36:01 --> Helper loaded: cookie_helper
INFO - 2024-06-18 07:36:01 --> Config Class Initialized
INFO - 2024-06-18 07:36:01 --> Hooks Class Initialized
DEBUG - 2024-06-18 07:36:01 --> UTF-8 Support Enabled
INFO - 2024-06-18 07:36:01 --> Utf8 Class Initialized
INFO - 2024-06-18 07:36:01 --> URI Class Initialized
INFO - 2024-06-18 07:36:01 --> Router Class Initialized
INFO - 2024-06-18 07:36:01 --> Output Class Initialized
INFO - 2024-06-18 07:36:01 --> Security Class Initialized
DEBUG - 2024-06-18 07:36:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-18 07:36:01 --> Input Class Initialized
INFO - 2024-06-18 07:36:01 --> Language Class Initialized
INFO - 2024-06-18 07:36:01 --> Language Class Initialized
INFO - 2024-06-18 07:36:01 --> Config Class Initialized
INFO - 2024-06-18 07:36:01 --> Loader Class Initialized
INFO - 2024-06-18 07:36:01 --> Helper loaded: url_helper
INFO - 2024-06-18 07:36:01 --> Helper loaded: file_helper
INFO - 2024-06-18 07:36:01 --> Helper loaded: form_helper
INFO - 2024-06-18 07:36:01 --> Helper loaded: my_helper
INFO - 2024-06-18 07:36:01 --> Database Driver Class Initialized
INFO - 2024-06-18 07:36:01 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-18 07:36:01 --> Controller Class Initialized
INFO - 2024-06-18 07:36:01 --> Config Class Initialized
INFO - 2024-06-18 07:36:01 --> Hooks Class Initialized
DEBUG - 2024-06-18 07:36:01 --> UTF-8 Support Enabled
INFO - 2024-06-18 07:36:01 --> Utf8 Class Initialized
INFO - 2024-06-18 07:36:01 --> URI Class Initialized
INFO - 2024-06-18 07:36:01 --> Router Class Initialized
INFO - 2024-06-18 07:36:01 --> Output Class Initialized
INFO - 2024-06-18 07:36:01 --> Security Class Initialized
DEBUG - 2024-06-18 07:36:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-18 07:36:01 --> Input Class Initialized
INFO - 2024-06-18 07:36:01 --> Language Class Initialized
INFO - 2024-06-18 07:36:01 --> Language Class Initialized
INFO - 2024-06-18 07:36:01 --> Config Class Initialized
INFO - 2024-06-18 07:36:01 --> Loader Class Initialized
INFO - 2024-06-18 07:36:01 --> Helper loaded: url_helper
INFO - 2024-06-18 07:36:01 --> Helper loaded: file_helper
INFO - 2024-06-18 07:36:01 --> Helper loaded: form_helper
INFO - 2024-06-18 07:36:01 --> Helper loaded: my_helper
INFO - 2024-06-18 07:36:01 --> Database Driver Class Initialized
INFO - 2024-06-18 07:36:01 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-18 07:36:01 --> Controller Class Initialized
DEBUG - 2024-06-18 07:36:01 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/login/views/login.php
DEBUG - 2024-06-18 07:36:01 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-06-18 07:36:01 --> Final output sent to browser
DEBUG - 2024-06-18 07:36:01 --> Total execution time: 0.0332
INFO - 2024-06-18 07:36:04 --> Config Class Initialized
INFO - 2024-06-18 07:36:04 --> Hooks Class Initialized
DEBUG - 2024-06-18 07:36:04 --> UTF-8 Support Enabled
INFO - 2024-06-18 07:36:04 --> Utf8 Class Initialized
INFO - 2024-06-18 07:36:04 --> URI Class Initialized
INFO - 2024-06-18 07:36:04 --> Router Class Initialized
INFO - 2024-06-18 07:36:04 --> Output Class Initialized
INFO - 2024-06-18 07:36:04 --> Security Class Initialized
DEBUG - 2024-06-18 07:36:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-18 07:36:04 --> Input Class Initialized
INFO - 2024-06-18 07:36:04 --> Language Class Initialized
INFO - 2024-06-18 07:36:04 --> Language Class Initialized
INFO - 2024-06-18 07:36:04 --> Config Class Initialized
INFO - 2024-06-18 07:36:04 --> Loader Class Initialized
INFO - 2024-06-18 07:36:04 --> Helper loaded: url_helper
INFO - 2024-06-18 07:36:04 --> Helper loaded: file_helper
INFO - 2024-06-18 07:36:04 --> Helper loaded: form_helper
INFO - 2024-06-18 07:36:04 --> Helper loaded: my_helper
INFO - 2024-06-18 07:36:04 --> Database Driver Class Initialized
INFO - 2024-06-18 07:36:04 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-18 07:36:04 --> Controller Class Initialized
INFO - 2024-06-18 07:36:04 --> Helper loaded: cookie_helper
INFO - 2024-06-18 07:36:04 --> Final output sent to browser
DEBUG - 2024-06-18 07:36:04 --> Total execution time: 0.0528
INFO - 2024-06-18 07:36:04 --> Config Class Initialized
INFO - 2024-06-18 07:36:04 --> Hooks Class Initialized
DEBUG - 2024-06-18 07:36:04 --> UTF-8 Support Enabled
INFO - 2024-06-18 07:36:04 --> Utf8 Class Initialized
INFO - 2024-06-18 07:36:04 --> URI Class Initialized
INFO - 2024-06-18 07:36:04 --> Router Class Initialized
INFO - 2024-06-18 07:36:04 --> Output Class Initialized
INFO - 2024-06-18 07:36:04 --> Security Class Initialized
DEBUG - 2024-06-18 07:36:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-18 07:36:04 --> Input Class Initialized
INFO - 2024-06-18 07:36:04 --> Language Class Initialized
INFO - 2024-06-18 07:36:04 --> Language Class Initialized
INFO - 2024-06-18 07:36:04 --> Config Class Initialized
INFO - 2024-06-18 07:36:04 --> Loader Class Initialized
INFO - 2024-06-18 07:36:04 --> Helper loaded: url_helper
INFO - 2024-06-18 07:36:04 --> Helper loaded: file_helper
INFO - 2024-06-18 07:36:04 --> Helper loaded: form_helper
INFO - 2024-06-18 07:36:04 --> Helper loaded: my_helper
INFO - 2024-06-18 07:36:04 --> Database Driver Class Initialized
INFO - 2024-06-18 07:36:04 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-18 07:36:04 --> Controller Class Initialized
DEBUG - 2024-06-18 07:36:04 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/home/views/v_home_guru.php
DEBUG - 2024-06-18 07:36:04 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-06-18 07:36:04 --> Final output sent to browser
DEBUG - 2024-06-18 07:36:04 --> Total execution time: 0.0318
INFO - 2024-06-18 07:36:08 --> Config Class Initialized
INFO - 2024-06-18 07:36:08 --> Hooks Class Initialized
DEBUG - 2024-06-18 07:36:08 --> UTF-8 Support Enabled
INFO - 2024-06-18 07:36:08 --> Utf8 Class Initialized
INFO - 2024-06-18 07:36:08 --> URI Class Initialized
INFO - 2024-06-18 07:36:08 --> Router Class Initialized
INFO - 2024-06-18 07:36:08 --> Output Class Initialized
INFO - 2024-06-18 07:36:08 --> Security Class Initialized
DEBUG - 2024-06-18 07:36:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-18 07:36:08 --> Input Class Initialized
INFO - 2024-06-18 07:36:08 --> Language Class Initialized
INFO - 2024-06-18 07:36:09 --> Language Class Initialized
INFO - 2024-06-18 07:36:09 --> Config Class Initialized
INFO - 2024-06-18 07:36:09 --> Loader Class Initialized
INFO - 2024-06-18 07:36:09 --> Helper loaded: url_helper
INFO - 2024-06-18 07:36:09 --> Helper loaded: file_helper
INFO - 2024-06-18 07:36:09 --> Helper loaded: form_helper
INFO - 2024-06-18 07:36:09 --> Helper loaded: my_helper
INFO - 2024-06-18 07:36:09 --> Database Driver Class Initialized
INFO - 2024-06-18 07:36:09 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-18 07:36:09 --> Controller Class Initialized
DEBUG - 2024-06-18 07:36:09 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/view_mapel/views/v_view_mapel.php
DEBUG - 2024-06-18 07:36:09 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-06-18 07:36:09 --> Final output sent to browser
DEBUG - 2024-06-18 07:36:09 --> Total execution time: 0.0348
INFO - 2024-06-18 07:36:11 --> Config Class Initialized
INFO - 2024-06-18 07:36:11 --> Hooks Class Initialized
DEBUG - 2024-06-18 07:36:11 --> UTF-8 Support Enabled
INFO - 2024-06-18 07:36:11 --> Utf8 Class Initialized
INFO - 2024-06-18 07:36:11 --> URI Class Initialized
INFO - 2024-06-18 07:36:11 --> Router Class Initialized
INFO - 2024-06-18 07:36:11 --> Output Class Initialized
INFO - 2024-06-18 07:36:11 --> Security Class Initialized
DEBUG - 2024-06-18 07:36:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-18 07:36:11 --> Input Class Initialized
INFO - 2024-06-18 07:36:11 --> Language Class Initialized
INFO - 2024-06-18 07:36:11 --> Language Class Initialized
INFO - 2024-06-18 07:36:11 --> Config Class Initialized
INFO - 2024-06-18 07:36:11 --> Loader Class Initialized
INFO - 2024-06-18 07:36:11 --> Helper loaded: url_helper
INFO - 2024-06-18 07:36:11 --> Helper loaded: file_helper
INFO - 2024-06-18 07:36:11 --> Helper loaded: form_helper
INFO - 2024-06-18 07:36:11 --> Helper loaded: my_helper
INFO - 2024-06-18 07:36:11 --> Database Driver Class Initialized
INFO - 2024-06-18 07:36:11 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-18 07:36:11 --> Controller Class Initialized
DEBUG - 2024-06-18 07:36:11 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/views/list.php
DEBUG - 2024-06-18 07:36:11 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-06-18 07:36:11 --> Final output sent to browser
DEBUG - 2024-06-18 07:36:11 --> Total execution time: 0.0310
INFO - 2024-06-18 07:36:11 --> Config Class Initialized
INFO - 2024-06-18 07:36:11 --> Hooks Class Initialized
DEBUG - 2024-06-18 07:36:11 --> UTF-8 Support Enabled
INFO - 2024-06-18 07:36:11 --> Utf8 Class Initialized
INFO - 2024-06-18 07:36:11 --> URI Class Initialized
INFO - 2024-06-18 07:36:11 --> Router Class Initialized
INFO - 2024-06-18 07:36:11 --> Output Class Initialized
INFO - 2024-06-18 07:36:11 --> Security Class Initialized
DEBUG - 2024-06-18 07:36:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-18 07:36:11 --> Input Class Initialized
INFO - 2024-06-18 07:36:11 --> Language Class Initialized
INFO - 2024-06-18 07:36:11 --> Language Class Initialized
INFO - 2024-06-18 07:36:11 --> Config Class Initialized
INFO - 2024-06-18 07:36:11 --> Loader Class Initialized
INFO - 2024-06-18 07:36:11 --> Helper loaded: url_helper
INFO - 2024-06-18 07:36:11 --> Helper loaded: file_helper
INFO - 2024-06-18 07:36:11 --> Helper loaded: form_helper
INFO - 2024-06-18 07:36:11 --> Helper loaded: my_helper
INFO - 2024-06-18 07:36:11 --> Database Driver Class Initialized
INFO - 2024-06-18 07:36:11 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-18 07:36:11 --> Controller Class Initialized
INFO - 2024-06-18 07:36:15 --> Config Class Initialized
INFO - 2024-06-18 07:36:15 --> Hooks Class Initialized
DEBUG - 2024-06-18 07:36:15 --> UTF-8 Support Enabled
INFO - 2024-06-18 07:36:15 --> Utf8 Class Initialized
INFO - 2024-06-18 07:36:15 --> URI Class Initialized
INFO - 2024-06-18 07:36:15 --> Router Class Initialized
INFO - 2024-06-18 07:36:15 --> Output Class Initialized
INFO - 2024-06-18 07:36:15 --> Security Class Initialized
DEBUG - 2024-06-18 07:36:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-18 07:36:15 --> Input Class Initialized
INFO - 2024-06-18 07:36:15 --> Language Class Initialized
INFO - 2024-06-18 07:36:15 --> Language Class Initialized
INFO - 2024-06-18 07:36:15 --> Config Class Initialized
INFO - 2024-06-18 07:36:15 --> Loader Class Initialized
INFO - 2024-06-18 07:36:15 --> Helper loaded: url_helper
INFO - 2024-06-18 07:36:15 --> Helper loaded: file_helper
INFO - 2024-06-18 07:36:15 --> Helper loaded: form_helper
INFO - 2024-06-18 07:36:15 --> Helper loaded: my_helper
INFO - 2024-06-18 07:36:15 --> Database Driver Class Initialized
INFO - 2024-06-18 07:36:15 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-18 07:36:15 --> Controller Class Initialized
INFO - 2024-06-18 07:38:32 --> Config Class Initialized
INFO - 2024-06-18 07:38:32 --> Hooks Class Initialized
DEBUG - 2024-06-18 07:38:32 --> UTF-8 Support Enabled
INFO - 2024-06-18 07:38:32 --> Utf8 Class Initialized
INFO - 2024-06-18 07:38:32 --> URI Class Initialized
INFO - 2024-06-18 07:38:32 --> Router Class Initialized
INFO - 2024-06-18 07:38:32 --> Output Class Initialized
INFO - 2024-06-18 07:38:32 --> Security Class Initialized
DEBUG - 2024-06-18 07:38:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-18 07:38:32 --> Input Class Initialized
INFO - 2024-06-18 07:38:32 --> Language Class Initialized
INFO - 2024-06-18 07:38:32 --> Language Class Initialized
INFO - 2024-06-18 07:38:32 --> Config Class Initialized
INFO - 2024-06-18 07:38:32 --> Loader Class Initialized
INFO - 2024-06-18 07:38:32 --> Helper loaded: url_helper
INFO - 2024-06-18 07:38:32 --> Helper loaded: file_helper
INFO - 2024-06-18 07:38:32 --> Helper loaded: form_helper
INFO - 2024-06-18 07:38:32 --> Helper loaded: my_helper
INFO - 2024-06-18 07:38:32 --> Database Driver Class Initialized
INFO - 2024-06-18 07:38:32 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-18 07:38:32 --> Controller Class Initialized
INFO - 2024-06-18 07:38:32 --> Final output sent to browser
DEBUG - 2024-06-18 07:38:32 --> Total execution time: 0.0394
INFO - 2024-06-18 07:38:38 --> Config Class Initialized
INFO - 2024-06-18 07:38:38 --> Hooks Class Initialized
DEBUG - 2024-06-18 07:38:38 --> UTF-8 Support Enabled
INFO - 2024-06-18 07:38:38 --> Utf8 Class Initialized
INFO - 2024-06-18 07:38:38 --> URI Class Initialized
INFO - 2024-06-18 07:38:38 --> Router Class Initialized
INFO - 2024-06-18 07:38:38 --> Output Class Initialized
INFO - 2024-06-18 07:38:38 --> Security Class Initialized
DEBUG - 2024-06-18 07:38:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-18 07:38:38 --> Input Class Initialized
INFO - 2024-06-18 07:38:38 --> Language Class Initialized
INFO - 2024-06-18 07:38:38 --> Language Class Initialized
INFO - 2024-06-18 07:38:38 --> Config Class Initialized
INFO - 2024-06-18 07:38:38 --> Loader Class Initialized
INFO - 2024-06-18 07:38:38 --> Helper loaded: url_helper
INFO - 2024-06-18 07:38:38 --> Helper loaded: file_helper
INFO - 2024-06-18 07:38:38 --> Helper loaded: form_helper
INFO - 2024-06-18 07:38:38 --> Helper loaded: my_helper
INFO - 2024-06-18 07:38:38 --> Database Driver Class Initialized
INFO - 2024-06-18 07:38:38 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-18 07:38:38 --> Controller Class Initialized
INFO - 2024-06-18 07:38:38 --> Final output sent to browser
DEBUG - 2024-06-18 07:38:38 --> Total execution time: 0.1030
INFO - 2024-06-18 07:38:43 --> Config Class Initialized
INFO - 2024-06-18 07:38:43 --> Hooks Class Initialized
DEBUG - 2024-06-18 07:38:43 --> UTF-8 Support Enabled
INFO - 2024-06-18 07:38:43 --> Utf8 Class Initialized
INFO - 2024-06-18 07:38:43 --> URI Class Initialized
INFO - 2024-06-18 07:38:43 --> Router Class Initialized
INFO - 2024-06-18 07:38:43 --> Output Class Initialized
INFO - 2024-06-18 07:38:43 --> Security Class Initialized
DEBUG - 2024-06-18 07:38:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-18 07:38:43 --> Input Class Initialized
INFO - 2024-06-18 07:38:43 --> Language Class Initialized
INFO - 2024-06-18 07:38:43 --> Language Class Initialized
INFO - 2024-06-18 07:38:43 --> Config Class Initialized
INFO - 2024-06-18 07:38:43 --> Loader Class Initialized
INFO - 2024-06-18 07:38:43 --> Helper loaded: url_helper
INFO - 2024-06-18 07:38:43 --> Helper loaded: file_helper
INFO - 2024-06-18 07:38:43 --> Helper loaded: form_helper
INFO - 2024-06-18 07:38:43 --> Helper loaded: my_helper
INFO - 2024-06-18 07:38:43 --> Database Driver Class Initialized
INFO - 2024-06-18 07:38:43 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-18 07:38:43 --> Controller Class Initialized
INFO - 2024-06-18 07:38:43 --> Final output sent to browser
DEBUG - 2024-06-18 07:38:43 --> Total execution time: 0.0310
INFO - 2024-06-18 07:38:48 --> Config Class Initialized
INFO - 2024-06-18 07:38:48 --> Hooks Class Initialized
DEBUG - 2024-06-18 07:38:48 --> UTF-8 Support Enabled
INFO - 2024-06-18 07:38:48 --> Utf8 Class Initialized
INFO - 2024-06-18 07:38:48 --> URI Class Initialized
INFO - 2024-06-18 07:38:48 --> Router Class Initialized
INFO - 2024-06-18 07:38:48 --> Output Class Initialized
INFO - 2024-06-18 07:38:48 --> Security Class Initialized
DEBUG - 2024-06-18 07:38:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-18 07:38:48 --> Input Class Initialized
INFO - 2024-06-18 07:38:48 --> Language Class Initialized
INFO - 2024-06-18 07:38:48 --> Language Class Initialized
INFO - 2024-06-18 07:38:48 --> Config Class Initialized
INFO - 2024-06-18 07:38:48 --> Loader Class Initialized
INFO - 2024-06-18 07:38:48 --> Helper loaded: url_helper
INFO - 2024-06-18 07:38:48 --> Helper loaded: file_helper
INFO - 2024-06-18 07:38:48 --> Helper loaded: form_helper
INFO - 2024-06-18 07:38:48 --> Helper loaded: my_helper
INFO - 2024-06-18 07:38:48 --> Database Driver Class Initialized
INFO - 2024-06-18 07:38:48 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-18 07:38:48 --> Controller Class Initialized
INFO - 2024-06-18 07:38:48 --> Final output sent to browser
DEBUG - 2024-06-18 07:38:48 --> Total execution time: 0.1151
INFO - 2024-06-18 07:38:53 --> Config Class Initialized
INFO - 2024-06-18 07:38:53 --> Hooks Class Initialized
DEBUG - 2024-06-18 07:38:53 --> UTF-8 Support Enabled
INFO - 2024-06-18 07:38:53 --> Utf8 Class Initialized
INFO - 2024-06-18 07:38:53 --> URI Class Initialized
INFO - 2024-06-18 07:38:53 --> Router Class Initialized
INFO - 2024-06-18 07:38:53 --> Output Class Initialized
INFO - 2024-06-18 07:38:53 --> Security Class Initialized
DEBUG - 2024-06-18 07:38:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-18 07:38:53 --> Input Class Initialized
INFO - 2024-06-18 07:38:53 --> Language Class Initialized
INFO - 2024-06-18 07:38:53 --> Language Class Initialized
INFO - 2024-06-18 07:38:53 --> Config Class Initialized
INFO - 2024-06-18 07:38:53 --> Loader Class Initialized
INFO - 2024-06-18 07:38:53 --> Helper loaded: url_helper
INFO - 2024-06-18 07:38:53 --> Helper loaded: file_helper
INFO - 2024-06-18 07:38:53 --> Helper loaded: form_helper
INFO - 2024-06-18 07:38:53 --> Helper loaded: my_helper
INFO - 2024-06-18 07:38:53 --> Database Driver Class Initialized
INFO - 2024-06-18 07:38:53 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-18 07:38:53 --> Controller Class Initialized
INFO - 2024-06-18 07:38:53 --> Final output sent to browser
DEBUG - 2024-06-18 07:38:53 --> Total execution time: 0.0348
INFO - 2024-06-18 07:38:57 --> Config Class Initialized
INFO - 2024-06-18 07:38:57 --> Hooks Class Initialized
DEBUG - 2024-06-18 07:38:57 --> UTF-8 Support Enabled
INFO - 2024-06-18 07:38:57 --> Utf8 Class Initialized
INFO - 2024-06-18 07:38:57 --> URI Class Initialized
INFO - 2024-06-18 07:38:57 --> Router Class Initialized
INFO - 2024-06-18 07:38:57 --> Output Class Initialized
INFO - 2024-06-18 07:38:57 --> Security Class Initialized
DEBUG - 2024-06-18 07:38:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-18 07:38:57 --> Input Class Initialized
INFO - 2024-06-18 07:38:57 --> Language Class Initialized
INFO - 2024-06-18 07:38:57 --> Language Class Initialized
INFO - 2024-06-18 07:38:57 --> Config Class Initialized
INFO - 2024-06-18 07:38:57 --> Loader Class Initialized
INFO - 2024-06-18 07:38:57 --> Helper loaded: url_helper
INFO - 2024-06-18 07:38:57 --> Helper loaded: file_helper
INFO - 2024-06-18 07:38:57 --> Helper loaded: form_helper
INFO - 2024-06-18 07:38:57 --> Helper loaded: my_helper
INFO - 2024-06-18 07:38:57 --> Database Driver Class Initialized
INFO - 2024-06-18 07:38:57 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-18 07:38:57 --> Controller Class Initialized
INFO - 2024-06-18 07:38:57 --> Final output sent to browser
DEBUG - 2024-06-18 07:38:57 --> Total execution time: 0.1111
INFO - 2024-06-18 07:39:02 --> Config Class Initialized
INFO - 2024-06-18 07:39:02 --> Hooks Class Initialized
DEBUG - 2024-06-18 07:39:02 --> UTF-8 Support Enabled
INFO - 2024-06-18 07:39:02 --> Utf8 Class Initialized
INFO - 2024-06-18 07:39:02 --> URI Class Initialized
INFO - 2024-06-18 07:39:02 --> Router Class Initialized
INFO - 2024-06-18 07:39:02 --> Output Class Initialized
INFO - 2024-06-18 07:39:02 --> Security Class Initialized
DEBUG - 2024-06-18 07:39:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-18 07:39:02 --> Input Class Initialized
INFO - 2024-06-18 07:39:02 --> Language Class Initialized
INFO - 2024-06-18 07:39:02 --> Language Class Initialized
INFO - 2024-06-18 07:39:02 --> Config Class Initialized
INFO - 2024-06-18 07:39:02 --> Loader Class Initialized
INFO - 2024-06-18 07:39:02 --> Helper loaded: url_helper
INFO - 2024-06-18 07:39:02 --> Helper loaded: file_helper
INFO - 2024-06-18 07:39:02 --> Helper loaded: form_helper
INFO - 2024-06-18 07:39:02 --> Helper loaded: my_helper
INFO - 2024-06-18 07:39:02 --> Database Driver Class Initialized
INFO - 2024-06-18 07:39:02 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-18 07:39:02 --> Controller Class Initialized
INFO - 2024-06-18 07:39:02 --> Final output sent to browser
DEBUG - 2024-06-18 07:39:02 --> Total execution time: 0.0334
INFO - 2024-06-18 07:39:06 --> Config Class Initialized
INFO - 2024-06-18 07:39:06 --> Hooks Class Initialized
DEBUG - 2024-06-18 07:39:06 --> UTF-8 Support Enabled
INFO - 2024-06-18 07:39:06 --> Utf8 Class Initialized
INFO - 2024-06-18 07:39:06 --> URI Class Initialized
INFO - 2024-06-18 07:39:06 --> Router Class Initialized
INFO - 2024-06-18 07:39:06 --> Output Class Initialized
INFO - 2024-06-18 07:39:06 --> Security Class Initialized
DEBUG - 2024-06-18 07:39:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-18 07:39:06 --> Input Class Initialized
INFO - 2024-06-18 07:39:06 --> Language Class Initialized
INFO - 2024-06-18 07:39:06 --> Language Class Initialized
INFO - 2024-06-18 07:39:06 --> Config Class Initialized
INFO - 2024-06-18 07:39:06 --> Loader Class Initialized
INFO - 2024-06-18 07:39:06 --> Helper loaded: url_helper
INFO - 2024-06-18 07:39:06 --> Helper loaded: file_helper
INFO - 2024-06-18 07:39:06 --> Helper loaded: form_helper
INFO - 2024-06-18 07:39:06 --> Helper loaded: my_helper
INFO - 2024-06-18 07:39:06 --> Database Driver Class Initialized
INFO - 2024-06-18 07:39:06 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-18 07:39:06 --> Controller Class Initialized
INFO - 2024-06-18 07:39:06 --> Final output sent to browser
DEBUG - 2024-06-18 07:39:06 --> Total execution time: 0.1003
INFO - 2024-06-18 07:39:09 --> Config Class Initialized
INFO - 2024-06-18 07:39:09 --> Hooks Class Initialized
DEBUG - 2024-06-18 07:39:09 --> UTF-8 Support Enabled
INFO - 2024-06-18 07:39:09 --> Utf8 Class Initialized
INFO - 2024-06-18 07:39:09 --> URI Class Initialized
INFO - 2024-06-18 07:39:09 --> Router Class Initialized
INFO - 2024-06-18 07:39:09 --> Output Class Initialized
INFO - 2024-06-18 07:39:09 --> Security Class Initialized
DEBUG - 2024-06-18 07:39:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-18 07:39:09 --> Input Class Initialized
INFO - 2024-06-18 07:39:09 --> Language Class Initialized
INFO - 2024-06-18 07:39:09 --> Language Class Initialized
INFO - 2024-06-18 07:39:09 --> Config Class Initialized
INFO - 2024-06-18 07:39:09 --> Loader Class Initialized
INFO - 2024-06-18 07:39:09 --> Helper loaded: url_helper
INFO - 2024-06-18 07:39:09 --> Helper loaded: file_helper
INFO - 2024-06-18 07:39:09 --> Helper loaded: form_helper
INFO - 2024-06-18 07:39:09 --> Helper loaded: my_helper
INFO - 2024-06-18 07:39:09 --> Database Driver Class Initialized
INFO - 2024-06-18 07:39:09 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-18 07:39:09 --> Controller Class Initialized
INFO - 2024-06-18 07:39:09 --> Final output sent to browser
DEBUG - 2024-06-18 07:39:09 --> Total execution time: 0.1520
INFO - 2024-06-18 07:39:17 --> Config Class Initialized
INFO - 2024-06-18 07:39:17 --> Hooks Class Initialized
DEBUG - 2024-06-18 07:39:17 --> UTF-8 Support Enabled
INFO - 2024-06-18 07:39:17 --> Utf8 Class Initialized
INFO - 2024-06-18 07:39:17 --> URI Class Initialized
INFO - 2024-06-18 07:39:17 --> Router Class Initialized
INFO - 2024-06-18 07:39:17 --> Output Class Initialized
INFO - 2024-06-18 07:39:17 --> Security Class Initialized
DEBUG - 2024-06-18 07:39:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-18 07:39:17 --> Input Class Initialized
INFO - 2024-06-18 07:39:17 --> Language Class Initialized
INFO - 2024-06-18 07:39:17 --> Language Class Initialized
INFO - 2024-06-18 07:39:17 --> Config Class Initialized
INFO - 2024-06-18 07:39:17 --> Loader Class Initialized
INFO - 2024-06-18 07:39:17 --> Helper loaded: url_helper
INFO - 2024-06-18 07:39:17 --> Helper loaded: file_helper
INFO - 2024-06-18 07:39:17 --> Helper loaded: form_helper
INFO - 2024-06-18 07:39:17 --> Helper loaded: my_helper
INFO - 2024-06-18 07:39:17 --> Database Driver Class Initialized
INFO - 2024-06-18 07:39:17 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-18 07:39:17 --> Controller Class Initialized
INFO - 2024-06-18 07:39:17 --> Final output sent to browser
DEBUG - 2024-06-18 07:39:17 --> Total execution time: 0.1116
INFO - 2024-06-18 07:39:20 --> Config Class Initialized
INFO - 2024-06-18 07:39:20 --> Hooks Class Initialized
DEBUG - 2024-06-18 07:39:20 --> UTF-8 Support Enabled
INFO - 2024-06-18 07:39:20 --> Utf8 Class Initialized
INFO - 2024-06-18 07:39:20 --> URI Class Initialized
INFO - 2024-06-18 07:39:20 --> Router Class Initialized
INFO - 2024-06-18 07:39:20 --> Output Class Initialized
INFO - 2024-06-18 07:39:20 --> Security Class Initialized
DEBUG - 2024-06-18 07:39:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-18 07:39:20 --> Input Class Initialized
INFO - 2024-06-18 07:39:20 --> Language Class Initialized
INFO - 2024-06-18 07:39:20 --> Language Class Initialized
INFO - 2024-06-18 07:39:20 --> Config Class Initialized
INFO - 2024-06-18 07:39:20 --> Loader Class Initialized
INFO - 2024-06-18 07:39:20 --> Helper loaded: url_helper
INFO - 2024-06-18 07:39:20 --> Helper loaded: file_helper
INFO - 2024-06-18 07:39:20 --> Helper loaded: form_helper
INFO - 2024-06-18 07:39:20 --> Helper loaded: my_helper
INFO - 2024-06-18 07:39:20 --> Database Driver Class Initialized
INFO - 2024-06-18 07:39:20 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-18 07:39:20 --> Controller Class Initialized
INFO - 2024-06-18 07:39:20 --> Final output sent to browser
DEBUG - 2024-06-18 07:39:20 --> Total execution time: 0.0304
INFO - 2024-06-18 07:39:26 --> Config Class Initialized
INFO - 2024-06-18 07:39:26 --> Hooks Class Initialized
DEBUG - 2024-06-18 07:39:26 --> UTF-8 Support Enabled
INFO - 2024-06-18 07:39:26 --> Utf8 Class Initialized
INFO - 2024-06-18 07:39:26 --> URI Class Initialized
INFO - 2024-06-18 07:39:26 --> Router Class Initialized
INFO - 2024-06-18 07:39:26 --> Output Class Initialized
INFO - 2024-06-18 07:39:26 --> Security Class Initialized
DEBUG - 2024-06-18 07:39:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-18 07:39:26 --> Input Class Initialized
INFO - 2024-06-18 07:39:26 --> Language Class Initialized
INFO - 2024-06-18 07:39:26 --> Language Class Initialized
INFO - 2024-06-18 07:39:26 --> Config Class Initialized
INFO - 2024-06-18 07:39:26 --> Loader Class Initialized
INFO - 2024-06-18 07:39:26 --> Helper loaded: url_helper
INFO - 2024-06-18 07:39:26 --> Helper loaded: file_helper
INFO - 2024-06-18 07:39:26 --> Helper loaded: form_helper
INFO - 2024-06-18 07:39:26 --> Helper loaded: my_helper
INFO - 2024-06-18 07:39:26 --> Database Driver Class Initialized
INFO - 2024-06-18 07:39:26 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-18 07:39:26 --> Controller Class Initialized
INFO - 2024-06-18 07:39:26 --> Final output sent to browser
DEBUG - 2024-06-18 07:39:26 --> Total execution time: 0.1015
INFO - 2024-06-18 07:39:29 --> Config Class Initialized
INFO - 2024-06-18 07:39:29 --> Hooks Class Initialized
DEBUG - 2024-06-18 07:39:29 --> UTF-8 Support Enabled
INFO - 2024-06-18 07:39:29 --> Utf8 Class Initialized
INFO - 2024-06-18 07:39:29 --> URI Class Initialized
INFO - 2024-06-18 07:39:29 --> Router Class Initialized
INFO - 2024-06-18 07:39:29 --> Output Class Initialized
INFO - 2024-06-18 07:39:29 --> Security Class Initialized
DEBUG - 2024-06-18 07:39:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-18 07:39:29 --> Input Class Initialized
INFO - 2024-06-18 07:39:29 --> Language Class Initialized
INFO - 2024-06-18 07:39:29 --> Language Class Initialized
INFO - 2024-06-18 07:39:29 --> Config Class Initialized
INFO - 2024-06-18 07:39:29 --> Loader Class Initialized
INFO - 2024-06-18 07:39:29 --> Helper loaded: url_helper
INFO - 2024-06-18 07:39:29 --> Helper loaded: file_helper
INFO - 2024-06-18 07:39:29 --> Helper loaded: form_helper
INFO - 2024-06-18 07:39:29 --> Helper loaded: my_helper
INFO - 2024-06-18 07:39:29 --> Database Driver Class Initialized
INFO - 2024-06-18 07:39:29 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-18 07:39:29 --> Controller Class Initialized
INFO - 2024-06-18 07:39:29 --> Final output sent to browser
DEBUG - 2024-06-18 07:39:29 --> Total execution time: 0.0311
INFO - 2024-06-18 07:39:35 --> Config Class Initialized
INFO - 2024-06-18 07:39:35 --> Hooks Class Initialized
DEBUG - 2024-06-18 07:39:35 --> UTF-8 Support Enabled
INFO - 2024-06-18 07:39:35 --> Utf8 Class Initialized
INFO - 2024-06-18 07:39:35 --> URI Class Initialized
INFO - 2024-06-18 07:39:35 --> Router Class Initialized
INFO - 2024-06-18 07:39:35 --> Output Class Initialized
INFO - 2024-06-18 07:39:35 --> Security Class Initialized
DEBUG - 2024-06-18 07:39:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-18 07:39:35 --> Input Class Initialized
INFO - 2024-06-18 07:39:35 --> Language Class Initialized
INFO - 2024-06-18 07:39:35 --> Language Class Initialized
INFO - 2024-06-18 07:39:35 --> Config Class Initialized
INFO - 2024-06-18 07:39:35 --> Loader Class Initialized
INFO - 2024-06-18 07:39:35 --> Helper loaded: url_helper
INFO - 2024-06-18 07:39:35 --> Helper loaded: file_helper
INFO - 2024-06-18 07:39:35 --> Helper loaded: form_helper
INFO - 2024-06-18 07:39:35 --> Helper loaded: my_helper
INFO - 2024-06-18 07:39:35 --> Database Driver Class Initialized
INFO - 2024-06-18 07:39:35 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-18 07:39:35 --> Controller Class Initialized
INFO - 2024-06-18 07:39:35 --> Final output sent to browser
DEBUG - 2024-06-18 07:39:35 --> Total execution time: 0.0981
INFO - 2024-06-18 07:39:38 --> Config Class Initialized
INFO - 2024-06-18 07:39:38 --> Hooks Class Initialized
DEBUG - 2024-06-18 07:39:38 --> UTF-8 Support Enabled
INFO - 2024-06-18 07:39:38 --> Utf8 Class Initialized
INFO - 2024-06-18 07:39:38 --> URI Class Initialized
INFO - 2024-06-18 07:39:38 --> Router Class Initialized
INFO - 2024-06-18 07:39:38 --> Output Class Initialized
INFO - 2024-06-18 07:39:38 --> Security Class Initialized
DEBUG - 2024-06-18 07:39:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-18 07:39:38 --> Input Class Initialized
INFO - 2024-06-18 07:39:38 --> Language Class Initialized
INFO - 2024-06-18 07:39:38 --> Language Class Initialized
INFO - 2024-06-18 07:39:38 --> Config Class Initialized
INFO - 2024-06-18 07:39:38 --> Loader Class Initialized
INFO - 2024-06-18 07:39:38 --> Helper loaded: url_helper
INFO - 2024-06-18 07:39:38 --> Helper loaded: file_helper
INFO - 2024-06-18 07:39:38 --> Helper loaded: form_helper
INFO - 2024-06-18 07:39:38 --> Helper loaded: my_helper
INFO - 2024-06-18 07:39:38 --> Database Driver Class Initialized
INFO - 2024-06-18 07:39:39 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-18 07:39:39 --> Controller Class Initialized
INFO - 2024-06-18 07:39:39 --> Final output sent to browser
DEBUG - 2024-06-18 07:39:39 --> Total execution time: 0.0695
INFO - 2024-06-18 07:39:43 --> Config Class Initialized
INFO - 2024-06-18 07:39:43 --> Hooks Class Initialized
DEBUG - 2024-06-18 07:39:43 --> UTF-8 Support Enabled
INFO - 2024-06-18 07:39:43 --> Utf8 Class Initialized
INFO - 2024-06-18 07:39:43 --> URI Class Initialized
INFO - 2024-06-18 07:39:43 --> Router Class Initialized
INFO - 2024-06-18 07:39:43 --> Output Class Initialized
INFO - 2024-06-18 07:39:43 --> Security Class Initialized
DEBUG - 2024-06-18 07:39:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-18 07:39:43 --> Input Class Initialized
INFO - 2024-06-18 07:39:43 --> Language Class Initialized
INFO - 2024-06-18 07:39:43 --> Language Class Initialized
INFO - 2024-06-18 07:39:43 --> Config Class Initialized
INFO - 2024-06-18 07:39:43 --> Loader Class Initialized
INFO - 2024-06-18 07:39:43 --> Helper loaded: url_helper
INFO - 2024-06-18 07:39:43 --> Helper loaded: file_helper
INFO - 2024-06-18 07:39:43 --> Helper loaded: form_helper
INFO - 2024-06-18 07:39:43 --> Helper loaded: my_helper
INFO - 2024-06-18 07:39:43 --> Database Driver Class Initialized
INFO - 2024-06-18 07:39:43 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-18 07:39:43 --> Controller Class Initialized
INFO - 2024-06-18 07:39:44 --> Final output sent to browser
DEBUG - 2024-06-18 07:39:44 --> Total execution time: 0.1198
INFO - 2024-06-18 07:45:41 --> Config Class Initialized
INFO - 2024-06-18 07:45:41 --> Hooks Class Initialized
DEBUG - 2024-06-18 07:45:41 --> UTF-8 Support Enabled
INFO - 2024-06-18 07:45:41 --> Utf8 Class Initialized
INFO - 2024-06-18 07:45:41 --> URI Class Initialized
INFO - 2024-06-18 07:45:41 --> Router Class Initialized
INFO - 2024-06-18 07:45:41 --> Output Class Initialized
INFO - 2024-06-18 07:45:41 --> Security Class Initialized
DEBUG - 2024-06-18 07:45:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-18 07:45:41 --> Input Class Initialized
INFO - 2024-06-18 07:45:41 --> Language Class Initialized
INFO - 2024-06-18 07:45:41 --> Language Class Initialized
INFO - 2024-06-18 07:45:41 --> Config Class Initialized
INFO - 2024-06-18 07:45:41 --> Loader Class Initialized
INFO - 2024-06-18 07:45:41 --> Helper loaded: url_helper
INFO - 2024-06-18 07:45:41 --> Helper loaded: file_helper
INFO - 2024-06-18 07:45:41 --> Helper loaded: form_helper
INFO - 2024-06-18 07:45:41 --> Helper loaded: my_helper
INFO - 2024-06-18 07:45:41 --> Database Driver Class Initialized
INFO - 2024-06-18 07:45:41 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-18 07:45:41 --> Controller Class Initialized
INFO - 2024-06-18 07:45:41 --> Final output sent to browser
DEBUG - 2024-06-18 07:45:41 --> Total execution time: 0.0608
INFO - 2024-06-18 07:45:54 --> Config Class Initialized
INFO - 2024-06-18 07:45:54 --> Hooks Class Initialized
DEBUG - 2024-06-18 07:45:54 --> UTF-8 Support Enabled
INFO - 2024-06-18 07:45:54 --> Utf8 Class Initialized
INFO - 2024-06-18 07:45:54 --> URI Class Initialized
INFO - 2024-06-18 07:45:54 --> Router Class Initialized
INFO - 2024-06-18 07:45:54 --> Output Class Initialized
INFO - 2024-06-18 07:45:54 --> Security Class Initialized
DEBUG - 2024-06-18 07:45:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-18 07:45:54 --> Input Class Initialized
INFO - 2024-06-18 07:45:54 --> Language Class Initialized
INFO - 2024-06-18 07:45:54 --> Language Class Initialized
INFO - 2024-06-18 07:45:54 --> Config Class Initialized
INFO - 2024-06-18 07:45:54 --> Loader Class Initialized
INFO - 2024-06-18 07:45:54 --> Helper loaded: url_helper
INFO - 2024-06-18 07:45:54 --> Helper loaded: file_helper
INFO - 2024-06-18 07:45:54 --> Helper loaded: form_helper
INFO - 2024-06-18 07:45:54 --> Helper loaded: my_helper
INFO - 2024-06-18 07:45:54 --> Database Driver Class Initialized
INFO - 2024-06-18 07:45:54 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-18 07:45:54 --> Controller Class Initialized
INFO - 2024-06-18 07:49:18 --> Config Class Initialized
INFO - 2024-06-18 07:49:18 --> Hooks Class Initialized
DEBUG - 2024-06-18 07:49:18 --> UTF-8 Support Enabled
INFO - 2024-06-18 07:49:18 --> Utf8 Class Initialized
INFO - 2024-06-18 07:49:18 --> URI Class Initialized
INFO - 2024-06-18 07:49:18 --> Router Class Initialized
INFO - 2024-06-18 07:49:18 --> Output Class Initialized
INFO - 2024-06-18 07:49:18 --> Security Class Initialized
DEBUG - 2024-06-18 07:49:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-18 07:49:18 --> Input Class Initialized
INFO - 2024-06-18 07:49:18 --> Language Class Initialized
INFO - 2024-06-18 07:49:18 --> Language Class Initialized
INFO - 2024-06-18 07:49:18 --> Config Class Initialized
INFO - 2024-06-18 07:49:18 --> Loader Class Initialized
INFO - 2024-06-18 07:49:18 --> Helper loaded: url_helper
INFO - 2024-06-18 07:49:18 --> Helper loaded: file_helper
INFO - 2024-06-18 07:49:18 --> Helper loaded: form_helper
INFO - 2024-06-18 07:49:18 --> Helper loaded: my_helper
INFO - 2024-06-18 07:49:18 --> Database Driver Class Initialized
INFO - 2024-06-18 07:49:18 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-18 07:49:18 --> Controller Class Initialized
INFO - 2024-06-18 07:49:18 --> Final output sent to browser
DEBUG - 2024-06-18 07:49:18 --> Total execution time: 0.1138
INFO - 2024-06-18 07:49:52 --> Config Class Initialized
INFO - 2024-06-18 07:49:52 --> Hooks Class Initialized
DEBUG - 2024-06-18 07:49:52 --> UTF-8 Support Enabled
INFO - 2024-06-18 07:49:52 --> Utf8 Class Initialized
INFO - 2024-06-18 07:49:52 --> URI Class Initialized
INFO - 2024-06-18 07:49:52 --> Router Class Initialized
INFO - 2024-06-18 07:49:52 --> Output Class Initialized
INFO - 2024-06-18 07:49:52 --> Security Class Initialized
DEBUG - 2024-06-18 07:49:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-18 07:49:52 --> Input Class Initialized
INFO - 2024-06-18 07:49:52 --> Language Class Initialized
INFO - 2024-06-18 07:49:52 --> Language Class Initialized
INFO - 2024-06-18 07:49:52 --> Config Class Initialized
INFO - 2024-06-18 07:49:52 --> Loader Class Initialized
INFO - 2024-06-18 07:49:52 --> Helper loaded: url_helper
INFO - 2024-06-18 07:49:52 --> Helper loaded: file_helper
INFO - 2024-06-18 07:49:52 --> Helper loaded: form_helper
INFO - 2024-06-18 07:49:52 --> Helper loaded: my_helper
INFO - 2024-06-18 07:49:52 --> Database Driver Class Initialized
INFO - 2024-06-18 07:49:52 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-18 07:49:52 --> Controller Class Initialized
INFO - 2024-06-18 07:49:52 --> Final output sent to browser
DEBUG - 2024-06-18 07:49:52 --> Total execution time: 0.1009
INFO - 2024-06-18 10:11:51 --> Config Class Initialized
INFO - 2024-06-18 10:11:51 --> Hooks Class Initialized
DEBUG - 2024-06-18 10:11:51 --> UTF-8 Support Enabled
INFO - 2024-06-18 10:11:51 --> Utf8 Class Initialized
INFO - 2024-06-18 10:11:51 --> URI Class Initialized
INFO - 2024-06-18 10:11:51 --> Router Class Initialized
INFO - 2024-06-18 10:11:51 --> Output Class Initialized
INFO - 2024-06-18 10:11:51 --> Security Class Initialized
DEBUG - 2024-06-18 10:11:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-18 10:11:51 --> Input Class Initialized
INFO - 2024-06-18 10:11:51 --> Language Class Initialized
INFO - 2024-06-18 10:11:51 --> Language Class Initialized
INFO - 2024-06-18 10:11:51 --> Config Class Initialized
INFO - 2024-06-18 10:11:51 --> Loader Class Initialized
INFO - 2024-06-18 10:11:51 --> Helper loaded: url_helper
INFO - 2024-06-18 10:11:51 --> Helper loaded: file_helper
INFO - 2024-06-18 10:11:51 --> Helper loaded: form_helper
INFO - 2024-06-18 10:11:51 --> Helper loaded: my_helper
INFO - 2024-06-18 10:11:51 --> Database Driver Class Initialized
INFO - 2024-06-18 10:11:51 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-18 10:11:51 --> Controller Class Initialized
DEBUG - 2024-06-18 10:11:51 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/views/list.php
DEBUG - 2024-06-18 10:11:51 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-06-18 10:11:51 --> Final output sent to browser
DEBUG - 2024-06-18 10:11:51 --> Total execution time: 0.0810
INFO - 2024-06-18 10:11:52 --> Config Class Initialized
INFO - 2024-06-18 10:11:52 --> Hooks Class Initialized
DEBUG - 2024-06-18 10:11:52 --> UTF-8 Support Enabled
INFO - 2024-06-18 10:11:52 --> Utf8 Class Initialized
INFO - 2024-06-18 10:11:52 --> URI Class Initialized
INFO - 2024-06-18 10:11:52 --> Router Class Initialized
INFO - 2024-06-18 10:11:52 --> Output Class Initialized
INFO - 2024-06-18 10:11:52 --> Security Class Initialized
DEBUG - 2024-06-18 10:11:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-18 10:11:52 --> Input Class Initialized
INFO - 2024-06-18 10:11:52 --> Language Class Initialized
INFO - 2024-06-18 10:11:52 --> Language Class Initialized
INFO - 2024-06-18 10:11:52 --> Config Class Initialized
INFO - 2024-06-18 10:11:52 --> Loader Class Initialized
INFO - 2024-06-18 10:11:52 --> Helper loaded: url_helper
INFO - 2024-06-18 10:11:52 --> Helper loaded: file_helper
INFO - 2024-06-18 10:11:52 --> Helper loaded: form_helper
INFO - 2024-06-18 10:11:52 --> Helper loaded: my_helper
INFO - 2024-06-18 10:11:52 --> Database Driver Class Initialized
INFO - 2024-06-18 10:11:52 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-18 10:11:52 --> Controller Class Initialized
INFO - 2024-06-18 10:12:30 --> Config Class Initialized
INFO - 2024-06-18 10:12:30 --> Hooks Class Initialized
DEBUG - 2024-06-18 10:12:30 --> UTF-8 Support Enabled
INFO - 2024-06-18 10:12:30 --> Utf8 Class Initialized
INFO - 2024-06-18 10:12:30 --> URI Class Initialized
DEBUG - 2024-06-18 10:12:30 --> No URI present. Default controller set.
INFO - 2024-06-18 10:12:30 --> Router Class Initialized
INFO - 2024-06-18 10:12:30 --> Output Class Initialized
INFO - 2024-06-18 10:12:30 --> Security Class Initialized
DEBUG - 2024-06-18 10:12:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-18 10:12:30 --> Input Class Initialized
INFO - 2024-06-18 10:12:30 --> Language Class Initialized
INFO - 2024-06-18 10:12:30 --> Language Class Initialized
INFO - 2024-06-18 10:12:30 --> Config Class Initialized
INFO - 2024-06-18 10:12:30 --> Loader Class Initialized
INFO - 2024-06-18 10:12:30 --> Helper loaded: url_helper
INFO - 2024-06-18 10:12:30 --> Helper loaded: file_helper
INFO - 2024-06-18 10:12:30 --> Helper loaded: form_helper
INFO - 2024-06-18 10:12:30 --> Helper loaded: my_helper
INFO - 2024-06-18 10:12:30 --> Database Driver Class Initialized
INFO - 2024-06-18 10:12:30 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-18 10:12:30 --> Controller Class Initialized
INFO - 2024-06-18 10:12:31 --> Config Class Initialized
INFO - 2024-06-18 10:12:31 --> Hooks Class Initialized
DEBUG - 2024-06-18 10:12:31 --> UTF-8 Support Enabled
INFO - 2024-06-18 10:12:31 --> Utf8 Class Initialized
INFO - 2024-06-18 10:12:31 --> URI Class Initialized
INFO - 2024-06-18 10:12:31 --> Router Class Initialized
INFO - 2024-06-18 10:12:31 --> Output Class Initialized
INFO - 2024-06-18 10:12:31 --> Security Class Initialized
DEBUG - 2024-06-18 10:12:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-18 10:12:31 --> Input Class Initialized
INFO - 2024-06-18 10:12:31 --> Language Class Initialized
INFO - 2024-06-18 10:12:31 --> Language Class Initialized
INFO - 2024-06-18 10:12:31 --> Config Class Initialized
INFO - 2024-06-18 10:12:31 --> Loader Class Initialized
INFO - 2024-06-18 10:12:31 --> Helper loaded: url_helper
INFO - 2024-06-18 10:12:31 --> Helper loaded: file_helper
INFO - 2024-06-18 10:12:31 --> Helper loaded: form_helper
INFO - 2024-06-18 10:12:31 --> Helper loaded: my_helper
INFO - 2024-06-18 10:12:31 --> Database Driver Class Initialized
INFO - 2024-06-18 10:12:31 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-18 10:12:31 --> Controller Class Initialized
DEBUG - 2024-06-18 10:12:31 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/login/views/login.php
DEBUG - 2024-06-18 10:12:31 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-06-18 10:12:31 --> Final output sent to browser
DEBUG - 2024-06-18 10:12:31 --> Total execution time: 0.0818
INFO - 2024-06-18 10:12:35 --> Config Class Initialized
INFO - 2024-06-18 10:12:35 --> Hooks Class Initialized
DEBUG - 2024-06-18 10:12:35 --> UTF-8 Support Enabled
INFO - 2024-06-18 10:12:35 --> Utf8 Class Initialized
INFO - 2024-06-18 10:12:35 --> URI Class Initialized
INFO - 2024-06-18 10:12:35 --> Router Class Initialized
INFO - 2024-06-18 10:12:35 --> Output Class Initialized
INFO - 2024-06-18 10:12:35 --> Security Class Initialized
DEBUG - 2024-06-18 10:12:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-18 10:12:35 --> Input Class Initialized
INFO - 2024-06-18 10:12:35 --> Language Class Initialized
INFO - 2024-06-18 10:12:35 --> Language Class Initialized
INFO - 2024-06-18 10:12:35 --> Config Class Initialized
INFO - 2024-06-18 10:12:35 --> Loader Class Initialized
INFO - 2024-06-18 10:12:35 --> Helper loaded: url_helper
INFO - 2024-06-18 10:12:35 --> Helper loaded: file_helper
INFO - 2024-06-18 10:12:35 --> Helper loaded: form_helper
INFO - 2024-06-18 10:12:35 --> Helper loaded: my_helper
INFO - 2024-06-18 10:12:35 --> Database Driver Class Initialized
INFO - 2024-06-18 10:12:35 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-18 10:12:35 --> Controller Class Initialized
INFO - 2024-06-18 10:12:35 --> Helper loaded: cookie_helper
INFO - 2024-06-18 10:12:35 --> Final output sent to browser
DEBUG - 2024-06-18 10:12:35 --> Total execution time: 0.0680
INFO - 2024-06-18 10:12:35 --> Config Class Initialized
INFO - 2024-06-18 10:12:35 --> Hooks Class Initialized
DEBUG - 2024-06-18 10:12:35 --> UTF-8 Support Enabled
INFO - 2024-06-18 10:12:35 --> Utf8 Class Initialized
INFO - 2024-06-18 10:12:35 --> URI Class Initialized
INFO - 2024-06-18 10:12:35 --> Router Class Initialized
INFO - 2024-06-18 10:12:35 --> Output Class Initialized
INFO - 2024-06-18 10:12:35 --> Security Class Initialized
DEBUG - 2024-06-18 10:12:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-18 10:12:35 --> Input Class Initialized
INFO - 2024-06-18 10:12:35 --> Language Class Initialized
INFO - 2024-06-18 10:12:35 --> Language Class Initialized
INFO - 2024-06-18 10:12:35 --> Config Class Initialized
INFO - 2024-06-18 10:12:35 --> Loader Class Initialized
INFO - 2024-06-18 10:12:35 --> Helper loaded: url_helper
INFO - 2024-06-18 10:12:35 --> Helper loaded: file_helper
INFO - 2024-06-18 10:12:35 --> Helper loaded: form_helper
INFO - 2024-06-18 10:12:35 --> Helper loaded: my_helper
INFO - 2024-06-18 10:12:35 --> Database Driver Class Initialized
INFO - 2024-06-18 10:12:35 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-18 10:12:35 --> Controller Class Initialized
DEBUG - 2024-06-18 10:12:35 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/home/views/v_home_guru.php
DEBUG - 2024-06-18 10:12:35 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-06-18 10:12:35 --> Final output sent to browser
DEBUG - 2024-06-18 10:12:35 --> Total execution time: 0.1059
INFO - 2024-06-18 10:12:54 --> Config Class Initialized
INFO - 2024-06-18 10:12:54 --> Hooks Class Initialized
DEBUG - 2024-06-18 10:12:54 --> UTF-8 Support Enabled
INFO - 2024-06-18 10:12:54 --> Utf8 Class Initialized
INFO - 2024-06-18 10:12:54 --> URI Class Initialized
INFO - 2024-06-18 10:12:54 --> Router Class Initialized
INFO - 2024-06-18 10:12:54 --> Output Class Initialized
INFO - 2024-06-18 10:12:54 --> Security Class Initialized
DEBUG - 2024-06-18 10:12:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-18 10:12:54 --> Input Class Initialized
INFO - 2024-06-18 10:12:54 --> Language Class Initialized
INFO - 2024-06-18 10:12:54 --> Language Class Initialized
INFO - 2024-06-18 10:12:54 --> Config Class Initialized
INFO - 2024-06-18 10:12:54 --> Loader Class Initialized
INFO - 2024-06-18 10:12:54 --> Helper loaded: url_helper
INFO - 2024-06-18 10:12:54 --> Helper loaded: file_helper
INFO - 2024-06-18 10:12:54 --> Helper loaded: form_helper
INFO - 2024-06-18 10:12:54 --> Helper loaded: my_helper
INFO - 2024-06-18 10:12:54 --> Database Driver Class Initialized
INFO - 2024-06-18 10:12:54 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-18 10:12:54 --> Controller Class Initialized
DEBUG - 2024-06-18 10:12:54 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/view_mapel/views/v_view_mapel.php
DEBUG - 2024-06-18 10:12:54 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-06-18 10:12:54 --> Final output sent to browser
DEBUG - 2024-06-18 10:12:54 --> Total execution time: 0.0294
INFO - 2024-06-18 10:13:24 --> Config Class Initialized
INFO - 2024-06-18 10:13:24 --> Hooks Class Initialized
DEBUG - 2024-06-18 10:13:24 --> UTF-8 Support Enabled
INFO - 2024-06-18 10:13:24 --> Utf8 Class Initialized
INFO - 2024-06-18 10:13:24 --> URI Class Initialized
INFO - 2024-06-18 10:13:24 --> Router Class Initialized
INFO - 2024-06-18 10:13:24 --> Output Class Initialized
INFO - 2024-06-18 10:13:24 --> Security Class Initialized
DEBUG - 2024-06-18 10:13:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-18 10:13:24 --> Input Class Initialized
INFO - 2024-06-18 10:13:24 --> Language Class Initialized
INFO - 2024-06-18 10:13:24 --> Language Class Initialized
INFO - 2024-06-18 10:13:24 --> Config Class Initialized
INFO - 2024-06-18 10:13:24 --> Loader Class Initialized
INFO - 2024-06-18 10:13:24 --> Helper loaded: url_helper
INFO - 2024-06-18 10:13:24 --> Helper loaded: file_helper
INFO - 2024-06-18 10:13:24 --> Helper loaded: form_helper
INFO - 2024-06-18 10:13:24 --> Helper loaded: my_helper
INFO - 2024-06-18 10:13:24 --> Database Driver Class Initialized
INFO - 2024-06-18 10:13:24 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-18 10:13:24 --> Controller Class Initialized
DEBUG - 2024-06-18 10:13:24 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/views/list.php
DEBUG - 2024-06-18 10:13:24 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-06-18 10:13:24 --> Final output sent to browser
DEBUG - 2024-06-18 10:13:24 --> Total execution time: 0.0294
INFO - 2024-06-18 10:13:25 --> Config Class Initialized
INFO - 2024-06-18 10:13:25 --> Hooks Class Initialized
DEBUG - 2024-06-18 10:13:25 --> UTF-8 Support Enabled
INFO - 2024-06-18 10:13:25 --> Utf8 Class Initialized
INFO - 2024-06-18 10:13:25 --> URI Class Initialized
INFO - 2024-06-18 10:13:25 --> Router Class Initialized
INFO - 2024-06-18 10:13:25 --> Output Class Initialized
INFO - 2024-06-18 10:13:25 --> Security Class Initialized
DEBUG - 2024-06-18 10:13:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-18 10:13:25 --> Input Class Initialized
INFO - 2024-06-18 10:13:25 --> Language Class Initialized
INFO - 2024-06-18 10:13:25 --> Language Class Initialized
INFO - 2024-06-18 10:13:25 --> Config Class Initialized
INFO - 2024-06-18 10:13:25 --> Loader Class Initialized
INFO - 2024-06-18 10:13:25 --> Helper loaded: url_helper
INFO - 2024-06-18 10:13:25 --> Helper loaded: file_helper
INFO - 2024-06-18 10:13:25 --> Helper loaded: form_helper
INFO - 2024-06-18 10:13:25 --> Helper loaded: my_helper
INFO - 2024-06-18 10:13:25 --> Database Driver Class Initialized
INFO - 2024-06-18 10:13:25 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-18 10:13:25 --> Controller Class Initialized
INFO - 2024-06-18 10:13:28 --> Config Class Initialized
INFO - 2024-06-18 10:13:28 --> Hooks Class Initialized
DEBUG - 2024-06-18 10:13:28 --> UTF-8 Support Enabled
INFO - 2024-06-18 10:13:28 --> Utf8 Class Initialized
INFO - 2024-06-18 10:13:28 --> URI Class Initialized
INFO - 2024-06-18 10:13:28 --> Router Class Initialized
INFO - 2024-06-18 10:13:28 --> Output Class Initialized
INFO - 2024-06-18 10:13:28 --> Security Class Initialized
DEBUG - 2024-06-18 10:13:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-18 10:13:28 --> Input Class Initialized
INFO - 2024-06-18 10:13:28 --> Language Class Initialized
INFO - 2024-06-18 10:13:28 --> Language Class Initialized
INFO - 2024-06-18 10:13:28 --> Config Class Initialized
INFO - 2024-06-18 10:13:28 --> Loader Class Initialized
INFO - 2024-06-18 10:13:28 --> Helper loaded: url_helper
INFO - 2024-06-18 10:13:28 --> Helper loaded: file_helper
INFO - 2024-06-18 10:13:28 --> Helper loaded: form_helper
INFO - 2024-06-18 10:13:28 --> Helper loaded: my_helper
INFO - 2024-06-18 10:13:28 --> Database Driver Class Initialized
INFO - 2024-06-18 10:13:28 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-18 10:13:28 --> Controller Class Initialized
DEBUG - 2024-06-18 10:13:28 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/view_mapel/views/v_view_mapel.php
DEBUG - 2024-06-18 10:13:28 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-06-18 10:13:28 --> Final output sent to browser
DEBUG - 2024-06-18 10:13:28 --> Total execution time: 0.0258
INFO - 2024-06-18 10:13:30 --> Config Class Initialized
INFO - 2024-06-18 10:13:30 --> Hooks Class Initialized
DEBUG - 2024-06-18 10:13:30 --> UTF-8 Support Enabled
INFO - 2024-06-18 10:13:30 --> Utf8 Class Initialized
INFO - 2024-06-18 10:13:30 --> URI Class Initialized
INFO - 2024-06-18 10:13:30 --> Router Class Initialized
INFO - 2024-06-18 10:13:30 --> Output Class Initialized
INFO - 2024-06-18 10:13:30 --> Security Class Initialized
DEBUG - 2024-06-18 10:13:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-18 10:13:30 --> Input Class Initialized
INFO - 2024-06-18 10:13:30 --> Language Class Initialized
INFO - 2024-06-18 10:13:30 --> Language Class Initialized
INFO - 2024-06-18 10:13:30 --> Config Class Initialized
INFO - 2024-06-18 10:13:30 --> Loader Class Initialized
INFO - 2024-06-18 10:13:30 --> Helper loaded: url_helper
INFO - 2024-06-18 10:13:30 --> Helper loaded: file_helper
INFO - 2024-06-18 10:13:30 --> Helper loaded: form_helper
INFO - 2024-06-18 10:13:30 --> Helper loaded: my_helper
INFO - 2024-06-18 10:13:30 --> Database Driver Class Initialized
INFO - 2024-06-18 10:13:30 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-18 10:13:30 --> Controller Class Initialized
DEBUG - 2024-06-18 10:13:30 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/views/list.php
DEBUG - 2024-06-18 10:13:30 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-06-18 10:13:30 --> Final output sent to browser
DEBUG - 2024-06-18 10:13:30 --> Total execution time: 0.0320
INFO - 2024-06-18 10:13:30 --> Config Class Initialized
INFO - 2024-06-18 10:13:30 --> Hooks Class Initialized
DEBUG - 2024-06-18 10:13:30 --> UTF-8 Support Enabled
INFO - 2024-06-18 10:13:30 --> Utf8 Class Initialized
INFO - 2024-06-18 10:13:30 --> URI Class Initialized
INFO - 2024-06-18 10:13:30 --> Router Class Initialized
INFO - 2024-06-18 10:13:30 --> Output Class Initialized
INFO - 2024-06-18 10:13:30 --> Security Class Initialized
DEBUG - 2024-06-18 10:13:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-18 10:13:30 --> Input Class Initialized
INFO - 2024-06-18 10:13:30 --> Language Class Initialized
INFO - 2024-06-18 10:13:30 --> Language Class Initialized
INFO - 2024-06-18 10:13:30 --> Config Class Initialized
INFO - 2024-06-18 10:13:30 --> Loader Class Initialized
INFO - 2024-06-18 10:13:30 --> Helper loaded: url_helper
INFO - 2024-06-18 10:13:30 --> Helper loaded: file_helper
INFO - 2024-06-18 10:13:30 --> Helper loaded: form_helper
INFO - 2024-06-18 10:13:30 --> Helper loaded: my_helper
INFO - 2024-06-18 10:13:30 --> Database Driver Class Initialized
INFO - 2024-06-18 10:13:30 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-18 10:13:30 --> Controller Class Initialized
INFO - 2024-06-18 10:13:35 --> Config Class Initialized
INFO - 2024-06-18 10:13:35 --> Hooks Class Initialized
DEBUG - 2024-06-18 10:13:35 --> UTF-8 Support Enabled
INFO - 2024-06-18 10:13:35 --> Utf8 Class Initialized
INFO - 2024-06-18 10:13:35 --> URI Class Initialized
INFO - 2024-06-18 10:13:35 --> Router Class Initialized
INFO - 2024-06-18 10:13:35 --> Output Class Initialized
INFO - 2024-06-18 10:13:35 --> Security Class Initialized
DEBUG - 2024-06-18 10:13:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-18 10:13:35 --> Input Class Initialized
INFO - 2024-06-18 10:13:35 --> Language Class Initialized
INFO - 2024-06-18 10:13:35 --> Language Class Initialized
INFO - 2024-06-18 10:13:35 --> Config Class Initialized
INFO - 2024-06-18 10:13:35 --> Loader Class Initialized
INFO - 2024-06-18 10:13:35 --> Helper loaded: url_helper
INFO - 2024-06-18 10:13:35 --> Helper loaded: file_helper
INFO - 2024-06-18 10:13:35 --> Helper loaded: form_helper
INFO - 2024-06-18 10:13:35 --> Helper loaded: my_helper
INFO - 2024-06-18 10:13:35 --> Database Driver Class Initialized
INFO - 2024-06-18 10:13:35 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-18 10:13:35 --> Controller Class Initialized
INFO - 2024-06-18 10:13:35 --> Final output sent to browser
DEBUG - 2024-06-18 10:13:35 --> Total execution time: 0.0283
INFO - 2024-06-18 10:13:38 --> Config Class Initialized
INFO - 2024-06-18 10:13:38 --> Hooks Class Initialized
DEBUG - 2024-06-18 10:13:38 --> UTF-8 Support Enabled
INFO - 2024-06-18 10:13:38 --> Utf8 Class Initialized
INFO - 2024-06-18 10:13:38 --> URI Class Initialized
INFO - 2024-06-18 10:13:38 --> Router Class Initialized
INFO - 2024-06-18 10:13:38 --> Output Class Initialized
INFO - 2024-06-18 10:13:38 --> Security Class Initialized
DEBUG - 2024-06-18 10:13:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-18 10:13:38 --> Input Class Initialized
INFO - 2024-06-18 10:13:38 --> Language Class Initialized
INFO - 2024-06-18 10:13:38 --> Language Class Initialized
INFO - 2024-06-18 10:13:38 --> Config Class Initialized
INFO - 2024-06-18 10:13:38 --> Loader Class Initialized
INFO - 2024-06-18 10:13:38 --> Helper loaded: url_helper
INFO - 2024-06-18 10:13:38 --> Helper loaded: file_helper
INFO - 2024-06-18 10:13:38 --> Helper loaded: form_helper
INFO - 2024-06-18 10:13:38 --> Helper loaded: my_helper
INFO - 2024-06-18 10:13:38 --> Database Driver Class Initialized
INFO - 2024-06-18 10:13:38 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-18 10:13:38 --> Controller Class Initialized
INFO - 2024-06-18 10:13:38 --> Final output sent to browser
DEBUG - 2024-06-18 10:13:38 --> Total execution time: 0.0288
INFO - 2024-06-18 10:13:44 --> Config Class Initialized
INFO - 2024-06-18 10:13:44 --> Hooks Class Initialized
DEBUG - 2024-06-18 10:13:44 --> UTF-8 Support Enabled
INFO - 2024-06-18 10:13:44 --> Utf8 Class Initialized
INFO - 2024-06-18 10:13:44 --> URI Class Initialized
INFO - 2024-06-18 10:13:44 --> Router Class Initialized
INFO - 2024-06-18 10:13:44 --> Output Class Initialized
INFO - 2024-06-18 10:13:44 --> Security Class Initialized
DEBUG - 2024-06-18 10:13:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-18 10:13:44 --> Input Class Initialized
INFO - 2024-06-18 10:13:44 --> Language Class Initialized
INFO - 2024-06-18 10:13:44 --> Language Class Initialized
INFO - 2024-06-18 10:13:44 --> Config Class Initialized
INFO - 2024-06-18 10:13:44 --> Loader Class Initialized
INFO - 2024-06-18 10:13:44 --> Helper loaded: url_helper
INFO - 2024-06-18 10:13:44 --> Helper loaded: file_helper
INFO - 2024-06-18 10:13:44 --> Helper loaded: form_helper
INFO - 2024-06-18 10:13:44 --> Helper loaded: my_helper
INFO - 2024-06-18 10:13:44 --> Database Driver Class Initialized
INFO - 2024-06-18 10:13:44 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-18 10:13:44 --> Controller Class Initialized
INFO - 2024-06-18 10:13:48 --> Config Class Initialized
INFO - 2024-06-18 10:13:48 --> Hooks Class Initialized
DEBUG - 2024-06-18 10:13:48 --> UTF-8 Support Enabled
INFO - 2024-06-18 10:13:48 --> Utf8 Class Initialized
INFO - 2024-06-18 10:13:48 --> URI Class Initialized
INFO - 2024-06-18 10:13:48 --> Router Class Initialized
INFO - 2024-06-18 10:13:48 --> Output Class Initialized
INFO - 2024-06-18 10:13:48 --> Security Class Initialized
DEBUG - 2024-06-18 10:13:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-18 10:13:48 --> Input Class Initialized
INFO - 2024-06-18 10:13:48 --> Language Class Initialized
INFO - 2024-06-18 10:13:48 --> Language Class Initialized
INFO - 2024-06-18 10:13:48 --> Config Class Initialized
INFO - 2024-06-18 10:13:48 --> Loader Class Initialized
INFO - 2024-06-18 10:13:48 --> Helper loaded: url_helper
INFO - 2024-06-18 10:13:48 --> Helper loaded: file_helper
INFO - 2024-06-18 10:13:48 --> Helper loaded: form_helper
INFO - 2024-06-18 10:13:48 --> Helper loaded: my_helper
INFO - 2024-06-18 10:13:48 --> Database Driver Class Initialized
INFO - 2024-06-18 10:13:48 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-18 10:13:48 --> Controller Class Initialized
DEBUG - 2024-06-18 10:13:48 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/views/list.php
DEBUG - 2024-06-18 10:13:48 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-06-18 10:13:48 --> Final output sent to browser
DEBUG - 2024-06-18 10:13:48 --> Total execution time: 0.0727
INFO - 2024-06-18 10:13:48 --> Config Class Initialized
INFO - 2024-06-18 10:13:48 --> Hooks Class Initialized
DEBUG - 2024-06-18 10:13:48 --> UTF-8 Support Enabled
INFO - 2024-06-18 10:13:48 --> Utf8 Class Initialized
INFO - 2024-06-18 10:13:48 --> URI Class Initialized
INFO - 2024-06-18 10:13:48 --> Router Class Initialized
INFO - 2024-06-18 10:13:48 --> Output Class Initialized
INFO - 2024-06-18 10:13:48 --> Security Class Initialized
DEBUG - 2024-06-18 10:13:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-18 10:13:48 --> Input Class Initialized
INFO - 2024-06-18 10:13:48 --> Language Class Initialized
INFO - 2024-06-18 10:13:48 --> Language Class Initialized
INFO - 2024-06-18 10:13:48 --> Config Class Initialized
INFO - 2024-06-18 10:13:48 --> Loader Class Initialized
INFO - 2024-06-18 10:13:48 --> Helper loaded: url_helper
INFO - 2024-06-18 10:13:48 --> Helper loaded: file_helper
INFO - 2024-06-18 10:13:48 --> Helper loaded: form_helper
INFO - 2024-06-18 10:13:48 --> Helper loaded: my_helper
INFO - 2024-06-18 10:13:48 --> Database Driver Class Initialized
INFO - 2024-06-18 10:13:48 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-18 10:13:48 --> Controller Class Initialized
INFO - 2024-06-18 10:14:05 --> Config Class Initialized
INFO - 2024-06-18 10:14:05 --> Hooks Class Initialized
DEBUG - 2024-06-18 10:14:05 --> UTF-8 Support Enabled
INFO - 2024-06-18 10:14:05 --> Utf8 Class Initialized
INFO - 2024-06-18 10:14:05 --> URI Class Initialized
INFO - 2024-06-18 10:14:05 --> Router Class Initialized
INFO - 2024-06-18 10:14:05 --> Output Class Initialized
INFO - 2024-06-18 10:14:05 --> Security Class Initialized
DEBUG - 2024-06-18 10:14:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-18 10:14:05 --> Input Class Initialized
INFO - 2024-06-18 10:14:05 --> Language Class Initialized
INFO - 2024-06-18 10:14:05 --> Language Class Initialized
INFO - 2024-06-18 10:14:05 --> Config Class Initialized
INFO - 2024-06-18 10:14:05 --> Loader Class Initialized
INFO - 2024-06-18 10:14:05 --> Helper loaded: url_helper
INFO - 2024-06-18 10:14:05 --> Helper loaded: file_helper
INFO - 2024-06-18 10:14:05 --> Helper loaded: form_helper
INFO - 2024-06-18 10:14:05 --> Helper loaded: my_helper
INFO - 2024-06-18 10:14:05 --> Database Driver Class Initialized
INFO - 2024-06-18 10:14:05 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-18 10:14:05 --> Controller Class Initialized
INFO - 2024-06-18 10:14:05 --> Final output sent to browser
DEBUG - 2024-06-18 10:14:05 --> Total execution time: 0.0390
INFO - 2024-06-18 10:15:50 --> Config Class Initialized
INFO - 2024-06-18 10:15:50 --> Hooks Class Initialized
DEBUG - 2024-06-18 10:15:50 --> UTF-8 Support Enabled
INFO - 2024-06-18 10:15:50 --> Utf8 Class Initialized
INFO - 2024-06-18 10:15:50 --> URI Class Initialized
INFO - 2024-06-18 10:15:50 --> Router Class Initialized
INFO - 2024-06-18 10:15:50 --> Output Class Initialized
INFO - 2024-06-18 10:15:50 --> Security Class Initialized
DEBUG - 2024-06-18 10:15:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-18 10:15:50 --> Input Class Initialized
INFO - 2024-06-18 10:15:50 --> Language Class Initialized
INFO - 2024-06-18 10:15:50 --> Language Class Initialized
INFO - 2024-06-18 10:15:50 --> Config Class Initialized
INFO - 2024-06-18 10:15:50 --> Loader Class Initialized
INFO - 2024-06-18 10:15:50 --> Helper loaded: url_helper
INFO - 2024-06-18 10:15:50 --> Helper loaded: file_helper
INFO - 2024-06-18 10:15:50 --> Helper loaded: form_helper
INFO - 2024-06-18 10:15:50 --> Helper loaded: my_helper
INFO - 2024-06-18 10:15:50 --> Database Driver Class Initialized
INFO - 2024-06-18 10:15:50 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-18 10:15:50 --> Controller Class Initialized
INFO - 2024-06-18 10:15:50 --> Final output sent to browser
DEBUG - 2024-06-18 10:15:50 --> Total execution time: 0.0491
INFO - 2024-06-18 10:16:52 --> Config Class Initialized
INFO - 2024-06-18 10:16:52 --> Hooks Class Initialized
DEBUG - 2024-06-18 10:16:52 --> UTF-8 Support Enabled
INFO - 2024-06-18 10:16:52 --> Utf8 Class Initialized
INFO - 2024-06-18 10:16:52 --> URI Class Initialized
INFO - 2024-06-18 10:16:52 --> Router Class Initialized
INFO - 2024-06-18 10:16:52 --> Output Class Initialized
INFO - 2024-06-18 10:16:52 --> Security Class Initialized
DEBUG - 2024-06-18 10:16:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-18 10:16:52 --> Input Class Initialized
INFO - 2024-06-18 10:16:52 --> Language Class Initialized
INFO - 2024-06-18 10:16:52 --> Language Class Initialized
INFO - 2024-06-18 10:16:52 --> Config Class Initialized
INFO - 2024-06-18 10:16:52 --> Loader Class Initialized
INFO - 2024-06-18 10:16:52 --> Helper loaded: url_helper
INFO - 2024-06-18 10:16:52 --> Helper loaded: file_helper
INFO - 2024-06-18 10:16:52 --> Helper loaded: form_helper
INFO - 2024-06-18 10:16:52 --> Helper loaded: my_helper
INFO - 2024-06-18 10:16:52 --> Database Driver Class Initialized
INFO - 2024-06-18 10:16:52 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-18 10:16:52 --> Controller Class Initialized
INFO - 2024-06-18 10:16:52 --> Final output sent to browser
DEBUG - 2024-06-18 10:16:52 --> Total execution time: 0.1048
INFO - 2024-06-18 10:16:55 --> Config Class Initialized
INFO - 2024-06-18 10:16:55 --> Hooks Class Initialized
DEBUG - 2024-06-18 10:16:55 --> UTF-8 Support Enabled
INFO - 2024-06-18 10:16:55 --> Utf8 Class Initialized
INFO - 2024-06-18 10:16:55 --> URI Class Initialized
INFO - 2024-06-18 10:16:55 --> Router Class Initialized
INFO - 2024-06-18 10:16:55 --> Output Class Initialized
INFO - 2024-06-18 10:16:55 --> Security Class Initialized
DEBUG - 2024-06-18 10:16:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-18 10:16:55 --> Input Class Initialized
INFO - 2024-06-18 10:16:55 --> Language Class Initialized
INFO - 2024-06-18 10:16:55 --> Language Class Initialized
INFO - 2024-06-18 10:16:55 --> Config Class Initialized
INFO - 2024-06-18 10:16:55 --> Loader Class Initialized
INFO - 2024-06-18 10:16:55 --> Helper loaded: url_helper
INFO - 2024-06-18 10:16:55 --> Helper loaded: file_helper
INFO - 2024-06-18 10:16:55 --> Helper loaded: form_helper
INFO - 2024-06-18 10:16:55 --> Helper loaded: my_helper
INFO - 2024-06-18 10:16:55 --> Database Driver Class Initialized
INFO - 2024-06-18 10:16:55 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-18 10:16:55 --> Controller Class Initialized
INFO - 2024-06-18 10:16:55 --> Final output sent to browser
DEBUG - 2024-06-18 10:16:55 --> Total execution time: 0.0302
INFO - 2024-06-18 10:16:57 --> Config Class Initialized
INFO - 2024-06-18 10:16:57 --> Hooks Class Initialized
DEBUG - 2024-06-18 10:16:57 --> UTF-8 Support Enabled
INFO - 2024-06-18 10:16:57 --> Utf8 Class Initialized
INFO - 2024-06-18 10:16:57 --> URI Class Initialized
INFO - 2024-06-18 10:16:57 --> Router Class Initialized
INFO - 2024-06-18 10:16:57 --> Output Class Initialized
INFO - 2024-06-18 10:16:57 --> Security Class Initialized
DEBUG - 2024-06-18 10:16:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-18 10:16:57 --> Input Class Initialized
INFO - 2024-06-18 10:16:57 --> Language Class Initialized
INFO - 2024-06-18 10:16:57 --> Language Class Initialized
INFO - 2024-06-18 10:16:57 --> Config Class Initialized
INFO - 2024-06-18 10:16:57 --> Loader Class Initialized
INFO - 2024-06-18 10:16:57 --> Helper loaded: url_helper
INFO - 2024-06-18 10:16:57 --> Helper loaded: file_helper
INFO - 2024-06-18 10:16:57 --> Helper loaded: form_helper
INFO - 2024-06-18 10:16:57 --> Helper loaded: my_helper
INFO - 2024-06-18 10:16:57 --> Database Driver Class Initialized
INFO - 2024-06-18 10:16:57 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-18 10:16:57 --> Controller Class Initialized
INFO - 2024-06-18 10:16:57 --> Final output sent to browser
DEBUG - 2024-06-18 10:16:57 --> Total execution time: 0.0303
INFO - 2024-06-18 10:17:03 --> Config Class Initialized
INFO - 2024-06-18 10:17:03 --> Hooks Class Initialized
DEBUG - 2024-06-18 10:17:03 --> UTF-8 Support Enabled
INFO - 2024-06-18 10:17:03 --> Utf8 Class Initialized
INFO - 2024-06-18 10:17:03 --> URI Class Initialized
INFO - 2024-06-18 10:17:03 --> Router Class Initialized
INFO - 2024-06-18 10:17:03 --> Output Class Initialized
INFO - 2024-06-18 10:17:03 --> Security Class Initialized
DEBUG - 2024-06-18 10:17:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-18 10:17:03 --> Input Class Initialized
INFO - 2024-06-18 10:17:03 --> Language Class Initialized
INFO - 2024-06-18 10:17:03 --> Language Class Initialized
INFO - 2024-06-18 10:17:03 --> Config Class Initialized
INFO - 2024-06-18 10:17:03 --> Loader Class Initialized
INFO - 2024-06-18 10:17:03 --> Helper loaded: url_helper
INFO - 2024-06-18 10:17:03 --> Helper loaded: file_helper
INFO - 2024-06-18 10:17:03 --> Helper loaded: form_helper
INFO - 2024-06-18 10:17:03 --> Helper loaded: my_helper
INFO - 2024-06-18 10:17:03 --> Database Driver Class Initialized
INFO - 2024-06-18 10:17:03 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-18 10:17:03 --> Controller Class Initialized
DEBUG - 2024-06-18 10:17:03 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/view_mapel/views/v_view_mapel.php
DEBUG - 2024-06-18 10:17:03 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-06-18 10:17:03 --> Final output sent to browser
DEBUG - 2024-06-18 10:17:03 --> Total execution time: 0.0292
INFO - 2024-06-18 10:20:13 --> Config Class Initialized
INFO - 2024-06-18 10:20:13 --> Hooks Class Initialized
DEBUG - 2024-06-18 10:20:13 --> UTF-8 Support Enabled
INFO - 2024-06-18 10:20:13 --> Utf8 Class Initialized
INFO - 2024-06-18 10:20:13 --> URI Class Initialized
INFO - 2024-06-18 10:20:13 --> Router Class Initialized
INFO - 2024-06-18 10:20:13 --> Output Class Initialized
INFO - 2024-06-18 10:20:13 --> Security Class Initialized
DEBUG - 2024-06-18 10:20:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-18 10:20:13 --> Input Class Initialized
INFO - 2024-06-18 10:20:13 --> Language Class Initialized
INFO - 2024-06-18 10:20:13 --> Language Class Initialized
INFO - 2024-06-18 10:20:13 --> Config Class Initialized
INFO - 2024-06-18 10:20:13 --> Loader Class Initialized
INFO - 2024-06-18 10:20:13 --> Helper loaded: url_helper
INFO - 2024-06-18 10:20:13 --> Helper loaded: file_helper
INFO - 2024-06-18 10:20:13 --> Helper loaded: form_helper
INFO - 2024-06-18 10:20:13 --> Helper loaded: my_helper
INFO - 2024-06-18 10:20:13 --> Database Driver Class Initialized
INFO - 2024-06-18 10:20:13 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-18 10:20:13 --> Controller Class Initialized
DEBUG - 2024-06-18 10:20:13 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/views/list.php
DEBUG - 2024-06-18 10:20:13 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-06-18 10:20:13 --> Final output sent to browser
DEBUG - 2024-06-18 10:20:13 --> Total execution time: 0.0270
INFO - 2024-06-18 10:20:14 --> Config Class Initialized
INFO - 2024-06-18 10:20:14 --> Hooks Class Initialized
DEBUG - 2024-06-18 10:20:14 --> UTF-8 Support Enabled
INFO - 2024-06-18 10:20:14 --> Utf8 Class Initialized
INFO - 2024-06-18 10:20:14 --> URI Class Initialized
INFO - 2024-06-18 10:20:14 --> Router Class Initialized
INFO - 2024-06-18 10:20:14 --> Output Class Initialized
INFO - 2024-06-18 10:20:14 --> Security Class Initialized
DEBUG - 2024-06-18 10:20:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-18 10:20:14 --> Input Class Initialized
INFO - 2024-06-18 10:20:14 --> Language Class Initialized
INFO - 2024-06-18 10:20:14 --> Language Class Initialized
INFO - 2024-06-18 10:20:14 --> Config Class Initialized
INFO - 2024-06-18 10:20:14 --> Loader Class Initialized
INFO - 2024-06-18 10:20:14 --> Helper loaded: url_helper
INFO - 2024-06-18 10:20:14 --> Helper loaded: file_helper
INFO - 2024-06-18 10:20:14 --> Helper loaded: form_helper
INFO - 2024-06-18 10:20:14 --> Helper loaded: my_helper
INFO - 2024-06-18 10:20:14 --> Database Driver Class Initialized
INFO - 2024-06-18 10:20:14 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-18 10:20:14 --> Controller Class Initialized
INFO - 2024-06-18 10:20:19 --> Config Class Initialized
INFO - 2024-06-18 10:20:19 --> Hooks Class Initialized
DEBUG - 2024-06-18 10:20:19 --> UTF-8 Support Enabled
INFO - 2024-06-18 10:20:19 --> Utf8 Class Initialized
INFO - 2024-06-18 10:20:19 --> URI Class Initialized
INFO - 2024-06-18 10:20:19 --> Router Class Initialized
INFO - 2024-06-18 10:20:19 --> Output Class Initialized
INFO - 2024-06-18 10:20:19 --> Security Class Initialized
DEBUG - 2024-06-18 10:20:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-18 10:20:19 --> Input Class Initialized
INFO - 2024-06-18 10:20:19 --> Language Class Initialized
INFO - 2024-06-18 10:20:19 --> Language Class Initialized
INFO - 2024-06-18 10:20:19 --> Config Class Initialized
INFO - 2024-06-18 10:20:19 --> Loader Class Initialized
INFO - 2024-06-18 10:20:19 --> Helper loaded: url_helper
INFO - 2024-06-18 10:20:19 --> Helper loaded: file_helper
INFO - 2024-06-18 10:20:19 --> Helper loaded: form_helper
INFO - 2024-06-18 10:20:19 --> Helper loaded: my_helper
INFO - 2024-06-18 10:20:19 --> Database Driver Class Initialized
INFO - 2024-06-18 10:20:19 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-18 10:20:19 --> Controller Class Initialized
DEBUG - 2024-06-18 10:20:19 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/view_mapel/views/v_view_mapel.php
DEBUG - 2024-06-18 10:20:19 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-06-18 10:20:19 --> Final output sent to browser
DEBUG - 2024-06-18 10:20:19 --> Total execution time: 0.0279
INFO - 2024-06-18 10:20:23 --> Config Class Initialized
INFO - 2024-06-18 10:20:23 --> Hooks Class Initialized
DEBUG - 2024-06-18 10:20:23 --> UTF-8 Support Enabled
INFO - 2024-06-18 10:20:23 --> Utf8 Class Initialized
INFO - 2024-06-18 10:20:23 --> URI Class Initialized
INFO - 2024-06-18 10:20:23 --> Router Class Initialized
INFO - 2024-06-18 10:20:23 --> Output Class Initialized
INFO - 2024-06-18 10:20:23 --> Security Class Initialized
DEBUG - 2024-06-18 10:20:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-18 10:20:23 --> Input Class Initialized
INFO - 2024-06-18 10:20:23 --> Language Class Initialized
INFO - 2024-06-18 10:20:23 --> Language Class Initialized
INFO - 2024-06-18 10:20:23 --> Config Class Initialized
INFO - 2024-06-18 10:20:23 --> Loader Class Initialized
INFO - 2024-06-18 10:20:23 --> Helper loaded: url_helper
INFO - 2024-06-18 10:20:23 --> Helper loaded: file_helper
INFO - 2024-06-18 10:20:23 --> Helper loaded: form_helper
INFO - 2024-06-18 10:20:23 --> Helper loaded: my_helper
INFO - 2024-06-18 10:20:23 --> Database Driver Class Initialized
INFO - 2024-06-18 10:20:23 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-18 10:20:23 --> Controller Class Initialized
DEBUG - 2024-06-18 10:20:23 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/views/list.php
DEBUG - 2024-06-18 10:20:23 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-06-18 10:20:23 --> Final output sent to browser
DEBUG - 2024-06-18 10:20:23 --> Total execution time: 0.0301
INFO - 2024-06-18 10:20:23 --> Config Class Initialized
INFO - 2024-06-18 10:20:23 --> Hooks Class Initialized
DEBUG - 2024-06-18 10:20:23 --> UTF-8 Support Enabled
INFO - 2024-06-18 10:20:23 --> Utf8 Class Initialized
INFO - 2024-06-18 10:20:23 --> URI Class Initialized
INFO - 2024-06-18 10:20:23 --> Router Class Initialized
INFO - 2024-06-18 10:20:23 --> Output Class Initialized
INFO - 2024-06-18 10:20:23 --> Security Class Initialized
DEBUG - 2024-06-18 10:20:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-18 10:20:23 --> Input Class Initialized
INFO - 2024-06-18 10:20:23 --> Language Class Initialized
INFO - 2024-06-18 10:20:23 --> Language Class Initialized
INFO - 2024-06-18 10:20:23 --> Config Class Initialized
INFO - 2024-06-18 10:20:23 --> Loader Class Initialized
INFO - 2024-06-18 10:20:23 --> Helper loaded: url_helper
INFO - 2024-06-18 10:20:23 --> Helper loaded: file_helper
INFO - 2024-06-18 10:20:23 --> Helper loaded: form_helper
INFO - 2024-06-18 10:20:23 --> Helper loaded: my_helper
INFO - 2024-06-18 10:20:23 --> Database Driver Class Initialized
INFO - 2024-06-18 10:20:23 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-18 10:20:23 --> Controller Class Initialized
INFO - 2024-06-18 10:20:26 --> Config Class Initialized
INFO - 2024-06-18 10:20:26 --> Hooks Class Initialized
DEBUG - 2024-06-18 10:20:26 --> UTF-8 Support Enabled
INFO - 2024-06-18 10:20:26 --> Utf8 Class Initialized
INFO - 2024-06-18 10:20:26 --> URI Class Initialized
INFO - 2024-06-18 10:20:26 --> Router Class Initialized
INFO - 2024-06-18 10:20:26 --> Output Class Initialized
INFO - 2024-06-18 10:20:26 --> Security Class Initialized
DEBUG - 2024-06-18 10:20:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-18 10:20:26 --> Input Class Initialized
INFO - 2024-06-18 10:20:26 --> Language Class Initialized
INFO - 2024-06-18 10:20:26 --> Language Class Initialized
INFO - 2024-06-18 10:20:26 --> Config Class Initialized
INFO - 2024-06-18 10:20:26 --> Loader Class Initialized
INFO - 2024-06-18 10:20:26 --> Helper loaded: url_helper
INFO - 2024-06-18 10:20:26 --> Helper loaded: file_helper
INFO - 2024-06-18 10:20:26 --> Helper loaded: form_helper
INFO - 2024-06-18 10:20:26 --> Helper loaded: my_helper
INFO - 2024-06-18 10:20:26 --> Database Driver Class Initialized
INFO - 2024-06-18 10:20:26 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-18 10:20:26 --> Controller Class Initialized
INFO - 2024-06-18 10:20:26 --> Final output sent to browser
DEBUG - 2024-06-18 10:20:26 --> Total execution time: 0.0377
INFO - 2024-06-18 10:20:29 --> Config Class Initialized
INFO - 2024-06-18 10:20:29 --> Hooks Class Initialized
DEBUG - 2024-06-18 10:20:29 --> UTF-8 Support Enabled
INFO - 2024-06-18 10:20:29 --> Utf8 Class Initialized
INFO - 2024-06-18 10:20:29 --> URI Class Initialized
INFO - 2024-06-18 10:20:29 --> Router Class Initialized
INFO - 2024-06-18 10:20:29 --> Output Class Initialized
INFO - 2024-06-18 10:20:29 --> Security Class Initialized
DEBUG - 2024-06-18 10:20:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-18 10:20:29 --> Input Class Initialized
INFO - 2024-06-18 10:20:29 --> Language Class Initialized
INFO - 2024-06-18 10:20:29 --> Language Class Initialized
INFO - 2024-06-18 10:20:29 --> Config Class Initialized
INFO - 2024-06-18 10:20:29 --> Loader Class Initialized
INFO - 2024-06-18 10:20:29 --> Helper loaded: url_helper
INFO - 2024-06-18 10:20:29 --> Helper loaded: file_helper
INFO - 2024-06-18 10:20:29 --> Helper loaded: form_helper
INFO - 2024-06-18 10:20:29 --> Helper loaded: my_helper
INFO - 2024-06-18 10:20:29 --> Database Driver Class Initialized
INFO - 2024-06-18 10:20:29 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-18 10:20:29 --> Controller Class Initialized
INFO - 2024-06-18 10:20:29 --> Final output sent to browser
DEBUG - 2024-06-18 10:20:29 --> Total execution time: 0.0289
INFO - 2024-06-18 10:20:31 --> Config Class Initialized
INFO - 2024-06-18 10:20:31 --> Hooks Class Initialized
DEBUG - 2024-06-18 10:20:31 --> UTF-8 Support Enabled
INFO - 2024-06-18 10:20:31 --> Utf8 Class Initialized
INFO - 2024-06-18 10:20:31 --> URI Class Initialized
INFO - 2024-06-18 10:20:31 --> Router Class Initialized
INFO - 2024-06-18 10:20:31 --> Output Class Initialized
INFO - 2024-06-18 10:20:31 --> Security Class Initialized
DEBUG - 2024-06-18 10:20:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-18 10:20:31 --> Input Class Initialized
INFO - 2024-06-18 10:20:31 --> Language Class Initialized
INFO - 2024-06-18 10:20:31 --> Language Class Initialized
INFO - 2024-06-18 10:20:31 --> Config Class Initialized
INFO - 2024-06-18 10:20:31 --> Loader Class Initialized
INFO - 2024-06-18 10:20:31 --> Helper loaded: url_helper
INFO - 2024-06-18 10:20:31 --> Helper loaded: file_helper
INFO - 2024-06-18 10:20:31 --> Helper loaded: form_helper
INFO - 2024-06-18 10:20:31 --> Helper loaded: my_helper
INFO - 2024-06-18 10:20:31 --> Database Driver Class Initialized
INFO - 2024-06-18 10:20:31 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-18 10:20:31 --> Controller Class Initialized
INFO - 2024-06-18 10:20:31 --> Final output sent to browser
DEBUG - 2024-06-18 10:20:31 --> Total execution time: 0.0317
INFO - 2024-06-18 10:20:53 --> Config Class Initialized
INFO - 2024-06-18 10:20:53 --> Hooks Class Initialized
DEBUG - 2024-06-18 10:20:53 --> UTF-8 Support Enabled
INFO - 2024-06-18 10:20:53 --> Utf8 Class Initialized
INFO - 2024-06-18 10:20:53 --> URI Class Initialized
INFO - 2024-06-18 10:20:53 --> Router Class Initialized
INFO - 2024-06-18 10:20:53 --> Output Class Initialized
INFO - 2024-06-18 10:20:53 --> Security Class Initialized
DEBUG - 2024-06-18 10:20:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-18 10:20:53 --> Input Class Initialized
INFO - 2024-06-18 10:20:53 --> Language Class Initialized
INFO - 2024-06-18 10:20:53 --> Language Class Initialized
INFO - 2024-06-18 10:20:53 --> Config Class Initialized
INFO - 2024-06-18 10:20:53 --> Loader Class Initialized
INFO - 2024-06-18 10:20:53 --> Helper loaded: url_helper
INFO - 2024-06-18 10:20:53 --> Helper loaded: file_helper
INFO - 2024-06-18 10:20:53 --> Helper loaded: form_helper
INFO - 2024-06-18 10:20:53 --> Helper loaded: my_helper
INFO - 2024-06-18 10:20:53 --> Database Driver Class Initialized
INFO - 2024-06-18 10:20:53 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-18 10:20:53 --> Controller Class Initialized
INFO - 2024-06-18 10:20:53 --> Final output sent to browser
DEBUG - 2024-06-18 10:20:53 --> Total execution time: 0.0409
INFO - 2024-06-18 10:21:12 --> Config Class Initialized
INFO - 2024-06-18 10:21:12 --> Hooks Class Initialized
DEBUG - 2024-06-18 10:21:12 --> UTF-8 Support Enabled
INFO - 2024-06-18 10:21:12 --> Utf8 Class Initialized
INFO - 2024-06-18 10:21:12 --> URI Class Initialized
INFO - 2024-06-18 10:21:12 --> Router Class Initialized
INFO - 2024-06-18 10:21:12 --> Output Class Initialized
INFO - 2024-06-18 10:21:12 --> Security Class Initialized
DEBUG - 2024-06-18 10:21:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-18 10:21:12 --> Input Class Initialized
INFO - 2024-06-18 10:21:12 --> Language Class Initialized
INFO - 2024-06-18 10:21:12 --> Language Class Initialized
INFO - 2024-06-18 10:21:12 --> Config Class Initialized
INFO - 2024-06-18 10:21:12 --> Loader Class Initialized
INFO - 2024-06-18 10:21:12 --> Helper loaded: url_helper
INFO - 2024-06-18 10:21:12 --> Helper loaded: file_helper
INFO - 2024-06-18 10:21:12 --> Helper loaded: form_helper
INFO - 2024-06-18 10:21:12 --> Helper loaded: my_helper
INFO - 2024-06-18 10:21:12 --> Database Driver Class Initialized
INFO - 2024-06-18 10:21:12 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-18 10:21:12 --> Controller Class Initialized
INFO - 2024-06-18 10:21:12 --> Final output sent to browser
DEBUG - 2024-06-18 10:21:12 --> Total execution time: 0.1094
INFO - 2024-06-18 10:21:15 --> Config Class Initialized
INFO - 2024-06-18 10:21:15 --> Hooks Class Initialized
DEBUG - 2024-06-18 10:21:15 --> UTF-8 Support Enabled
INFO - 2024-06-18 10:21:15 --> Utf8 Class Initialized
INFO - 2024-06-18 10:21:15 --> URI Class Initialized
INFO - 2024-06-18 10:21:15 --> Router Class Initialized
INFO - 2024-06-18 10:21:15 --> Output Class Initialized
INFO - 2024-06-18 10:21:15 --> Security Class Initialized
DEBUG - 2024-06-18 10:21:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-18 10:21:15 --> Input Class Initialized
INFO - 2024-06-18 10:21:15 --> Language Class Initialized
INFO - 2024-06-18 10:21:15 --> Language Class Initialized
INFO - 2024-06-18 10:21:15 --> Config Class Initialized
INFO - 2024-06-18 10:21:15 --> Loader Class Initialized
INFO - 2024-06-18 10:21:15 --> Helper loaded: url_helper
INFO - 2024-06-18 10:21:15 --> Helper loaded: file_helper
INFO - 2024-06-18 10:21:15 --> Helper loaded: form_helper
INFO - 2024-06-18 10:21:15 --> Helper loaded: my_helper
INFO - 2024-06-18 10:21:15 --> Database Driver Class Initialized
INFO - 2024-06-18 10:21:15 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-18 10:21:15 --> Controller Class Initialized
DEBUG - 2024-06-18 10:21:15 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/view_mapel/views/v_view_mapel.php
DEBUG - 2024-06-18 10:21:15 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-06-18 10:21:15 --> Final output sent to browser
DEBUG - 2024-06-18 10:21:15 --> Total execution time: 0.0277
INFO - 2024-06-18 10:21:18 --> Config Class Initialized
INFO - 2024-06-18 10:21:18 --> Hooks Class Initialized
DEBUG - 2024-06-18 10:21:18 --> UTF-8 Support Enabled
INFO - 2024-06-18 10:21:18 --> Utf8 Class Initialized
INFO - 2024-06-18 10:21:18 --> URI Class Initialized
INFO - 2024-06-18 10:21:18 --> Router Class Initialized
INFO - 2024-06-18 10:21:18 --> Output Class Initialized
INFO - 2024-06-18 10:21:18 --> Security Class Initialized
DEBUG - 2024-06-18 10:21:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-18 10:21:18 --> Input Class Initialized
INFO - 2024-06-18 10:21:18 --> Language Class Initialized
INFO - 2024-06-18 10:21:18 --> Language Class Initialized
INFO - 2024-06-18 10:21:18 --> Config Class Initialized
INFO - 2024-06-18 10:21:18 --> Loader Class Initialized
INFO - 2024-06-18 10:21:18 --> Helper loaded: url_helper
INFO - 2024-06-18 10:21:18 --> Helper loaded: file_helper
INFO - 2024-06-18 10:21:18 --> Helper loaded: form_helper
INFO - 2024-06-18 10:21:18 --> Helper loaded: my_helper
INFO - 2024-06-18 10:21:18 --> Database Driver Class Initialized
INFO - 2024-06-18 10:21:18 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-18 10:21:18 --> Controller Class Initialized
DEBUG - 2024-06-18 10:21:18 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_catatan_guru/views/list.php
DEBUG - 2024-06-18 10:21:18 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-06-18 10:21:18 --> Final output sent to browser
DEBUG - 2024-06-18 10:21:18 --> Total execution time: 0.0310
INFO - 2024-06-18 10:21:21 --> Config Class Initialized
INFO - 2024-06-18 10:21:21 --> Hooks Class Initialized
DEBUG - 2024-06-18 10:21:21 --> UTF-8 Support Enabled
INFO - 2024-06-18 10:21:21 --> Utf8 Class Initialized
INFO - 2024-06-18 10:21:21 --> URI Class Initialized
INFO - 2024-06-18 10:21:21 --> Router Class Initialized
INFO - 2024-06-18 10:21:21 --> Output Class Initialized
INFO - 2024-06-18 10:21:21 --> Security Class Initialized
DEBUG - 2024-06-18 10:21:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-18 10:21:21 --> Input Class Initialized
INFO - 2024-06-18 10:21:21 --> Language Class Initialized
INFO - 2024-06-18 10:21:21 --> Language Class Initialized
INFO - 2024-06-18 10:21:21 --> Config Class Initialized
INFO - 2024-06-18 10:21:21 --> Loader Class Initialized
INFO - 2024-06-18 10:21:21 --> Helper loaded: url_helper
INFO - 2024-06-18 10:21:21 --> Helper loaded: file_helper
INFO - 2024-06-18 10:21:21 --> Helper loaded: form_helper
INFO - 2024-06-18 10:21:21 --> Helper loaded: my_helper
INFO - 2024-06-18 10:21:21 --> Database Driver Class Initialized
INFO - 2024-06-18 10:21:21 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-18 10:21:21 --> Controller Class Initialized
INFO - 2024-06-18 10:21:21 --> Final output sent to browser
DEBUG - 2024-06-18 10:21:21 --> Total execution time: 0.0272
INFO - 2024-06-18 10:22:03 --> Config Class Initialized
INFO - 2024-06-18 10:22:03 --> Hooks Class Initialized
DEBUG - 2024-06-18 10:22:03 --> UTF-8 Support Enabled
INFO - 2024-06-18 10:22:03 --> Utf8 Class Initialized
INFO - 2024-06-18 10:22:03 --> URI Class Initialized
INFO - 2024-06-18 10:22:03 --> Router Class Initialized
INFO - 2024-06-18 10:22:03 --> Output Class Initialized
INFO - 2024-06-18 10:22:03 --> Security Class Initialized
DEBUG - 2024-06-18 10:22:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-18 10:22:03 --> Input Class Initialized
INFO - 2024-06-18 10:22:03 --> Language Class Initialized
INFO - 2024-06-18 10:22:03 --> Language Class Initialized
INFO - 2024-06-18 10:22:03 --> Config Class Initialized
INFO - 2024-06-18 10:22:03 --> Loader Class Initialized
INFO - 2024-06-18 10:22:03 --> Helper loaded: url_helper
INFO - 2024-06-18 10:22:03 --> Helper loaded: file_helper
INFO - 2024-06-18 10:22:03 --> Helper loaded: form_helper
INFO - 2024-06-18 10:22:03 --> Helper loaded: my_helper
INFO - 2024-06-18 10:22:03 --> Database Driver Class Initialized
INFO - 2024-06-18 10:22:03 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-18 10:22:03 --> Controller Class Initialized
INFO - 2024-06-18 10:23:17 --> Config Class Initialized
INFO - 2024-06-18 10:23:17 --> Hooks Class Initialized
DEBUG - 2024-06-18 10:23:17 --> UTF-8 Support Enabled
INFO - 2024-06-18 10:23:17 --> Utf8 Class Initialized
INFO - 2024-06-18 10:23:17 --> URI Class Initialized
INFO - 2024-06-18 10:23:17 --> Router Class Initialized
INFO - 2024-06-18 10:23:17 --> Output Class Initialized
INFO - 2024-06-18 10:23:17 --> Security Class Initialized
DEBUG - 2024-06-18 10:23:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-18 10:23:17 --> Input Class Initialized
INFO - 2024-06-18 10:23:17 --> Language Class Initialized
INFO - 2024-06-18 10:23:17 --> Language Class Initialized
INFO - 2024-06-18 10:23:17 --> Config Class Initialized
INFO - 2024-06-18 10:23:17 --> Loader Class Initialized
INFO - 2024-06-18 10:23:17 --> Helper loaded: url_helper
INFO - 2024-06-18 10:23:17 --> Helper loaded: file_helper
INFO - 2024-06-18 10:23:17 --> Helper loaded: form_helper
INFO - 2024-06-18 10:23:17 --> Helper loaded: my_helper
INFO - 2024-06-18 10:23:17 --> Database Driver Class Initialized
INFO - 2024-06-18 10:23:17 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-18 10:23:17 --> Controller Class Initialized
DEBUG - 2024-06-18 10:23:17 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_catatan_guru/views/form.php
DEBUG - 2024-06-18 10:23:17 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-06-18 10:23:17 --> Final output sent to browser
DEBUG - 2024-06-18 10:23:17 --> Total execution time: 0.0615
INFO - 2024-06-18 10:23:25 --> Config Class Initialized
INFO - 2024-06-18 10:23:25 --> Hooks Class Initialized
DEBUG - 2024-06-18 10:23:25 --> UTF-8 Support Enabled
INFO - 2024-06-18 10:23:25 --> Utf8 Class Initialized
INFO - 2024-06-18 10:23:25 --> URI Class Initialized
INFO - 2024-06-18 10:23:25 --> Router Class Initialized
INFO - 2024-06-18 10:23:25 --> Output Class Initialized
INFO - 2024-06-18 10:23:25 --> Security Class Initialized
DEBUG - 2024-06-18 10:23:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-18 10:23:25 --> Input Class Initialized
INFO - 2024-06-18 10:23:25 --> Language Class Initialized
INFO - 2024-06-18 10:23:25 --> Language Class Initialized
INFO - 2024-06-18 10:23:25 --> Config Class Initialized
INFO - 2024-06-18 10:23:25 --> Loader Class Initialized
INFO - 2024-06-18 10:23:25 --> Helper loaded: url_helper
INFO - 2024-06-18 10:23:25 --> Helper loaded: file_helper
INFO - 2024-06-18 10:23:25 --> Helper loaded: form_helper
INFO - 2024-06-18 10:23:25 --> Helper loaded: my_helper
INFO - 2024-06-18 10:23:25 --> Database Driver Class Initialized
INFO - 2024-06-18 10:23:25 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-18 10:23:25 --> Controller Class Initialized
INFO - 2024-06-18 10:23:26 --> Config Class Initialized
INFO - 2024-06-18 10:23:26 --> Hooks Class Initialized
DEBUG - 2024-06-18 10:23:26 --> UTF-8 Support Enabled
INFO - 2024-06-18 10:23:26 --> Utf8 Class Initialized
INFO - 2024-06-18 10:23:26 --> URI Class Initialized
INFO - 2024-06-18 10:23:26 --> Router Class Initialized
INFO - 2024-06-18 10:23:26 --> Output Class Initialized
INFO - 2024-06-18 10:23:26 --> Security Class Initialized
DEBUG - 2024-06-18 10:23:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-18 10:23:26 --> Input Class Initialized
INFO - 2024-06-18 10:23:26 --> Language Class Initialized
INFO - 2024-06-18 10:23:26 --> Language Class Initialized
INFO - 2024-06-18 10:23:26 --> Config Class Initialized
INFO - 2024-06-18 10:23:26 --> Loader Class Initialized
INFO - 2024-06-18 10:23:26 --> Helper loaded: url_helper
INFO - 2024-06-18 10:23:26 --> Helper loaded: file_helper
INFO - 2024-06-18 10:23:26 --> Helper loaded: form_helper
INFO - 2024-06-18 10:23:26 --> Helper loaded: my_helper
INFO - 2024-06-18 10:23:26 --> Database Driver Class Initialized
INFO - 2024-06-18 10:23:26 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-18 10:23:26 --> Controller Class Initialized
DEBUG - 2024-06-18 10:23:26 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_catatan_guru/views/list.php
DEBUG - 2024-06-18 10:23:26 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-06-18 10:23:26 --> Final output sent to browser
DEBUG - 2024-06-18 10:23:26 --> Total execution time: 0.0281
INFO - 2024-06-18 10:23:28 --> Config Class Initialized
INFO - 2024-06-18 10:23:28 --> Hooks Class Initialized
DEBUG - 2024-06-18 10:23:28 --> UTF-8 Support Enabled
INFO - 2024-06-18 10:23:28 --> Utf8 Class Initialized
INFO - 2024-06-18 10:23:28 --> URI Class Initialized
INFO - 2024-06-18 10:23:28 --> Router Class Initialized
INFO - 2024-06-18 10:23:28 --> Output Class Initialized
INFO - 2024-06-18 10:23:28 --> Security Class Initialized
DEBUG - 2024-06-18 10:23:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-18 10:23:28 --> Input Class Initialized
INFO - 2024-06-18 10:23:28 --> Language Class Initialized
INFO - 2024-06-18 10:23:28 --> Language Class Initialized
INFO - 2024-06-18 10:23:28 --> Config Class Initialized
INFO - 2024-06-18 10:23:28 --> Loader Class Initialized
INFO - 2024-06-18 10:23:28 --> Helper loaded: url_helper
INFO - 2024-06-18 10:23:28 --> Helper loaded: file_helper
INFO - 2024-06-18 10:23:28 --> Helper loaded: form_helper
INFO - 2024-06-18 10:23:28 --> Helper loaded: my_helper
INFO - 2024-06-18 10:23:28 --> Database Driver Class Initialized
INFO - 2024-06-18 10:23:28 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-18 10:23:28 --> Controller Class Initialized
INFO - 2024-06-18 10:23:28 --> Final output sent to browser
DEBUG - 2024-06-18 10:23:28 --> Total execution time: 0.0301
INFO - 2024-06-18 10:48:58 --> Config Class Initialized
INFO - 2024-06-18 10:48:58 --> Hooks Class Initialized
DEBUG - 2024-06-18 10:48:58 --> UTF-8 Support Enabled
INFO - 2024-06-18 10:48:58 --> Utf8 Class Initialized
INFO - 2024-06-18 10:48:58 --> URI Class Initialized
INFO - 2024-06-18 10:48:58 --> Router Class Initialized
INFO - 2024-06-18 10:48:58 --> Output Class Initialized
INFO - 2024-06-18 10:48:58 --> Security Class Initialized
DEBUG - 2024-06-18 10:48:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-18 10:48:58 --> Input Class Initialized
INFO - 2024-06-18 10:48:58 --> Language Class Initialized
INFO - 2024-06-18 10:48:58 --> Language Class Initialized
INFO - 2024-06-18 10:48:58 --> Config Class Initialized
INFO - 2024-06-18 10:48:58 --> Loader Class Initialized
INFO - 2024-06-18 10:48:58 --> Helper loaded: url_helper
INFO - 2024-06-18 10:48:58 --> Helper loaded: file_helper
INFO - 2024-06-18 10:48:58 --> Helper loaded: form_helper
INFO - 2024-06-18 10:48:58 --> Helper loaded: my_helper
INFO - 2024-06-18 10:48:58 --> Database Driver Class Initialized
INFO - 2024-06-18 10:48:58 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-18 10:48:58 --> Controller Class Initialized
INFO - 2024-06-18 10:48:58 --> Config Class Initialized
INFO - 2024-06-18 10:48:58 --> Hooks Class Initialized
DEBUG - 2024-06-18 10:48:58 --> UTF-8 Support Enabled
INFO - 2024-06-18 10:48:58 --> Utf8 Class Initialized
INFO - 2024-06-18 10:48:58 --> URI Class Initialized
INFO - 2024-06-18 10:48:58 --> Router Class Initialized
INFO - 2024-06-18 10:48:58 --> Output Class Initialized
INFO - 2024-06-18 10:48:58 --> Security Class Initialized
DEBUG - 2024-06-18 10:48:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-18 10:48:58 --> Input Class Initialized
INFO - 2024-06-18 10:48:58 --> Language Class Initialized
INFO - 2024-06-18 10:48:58 --> Language Class Initialized
INFO - 2024-06-18 10:48:58 --> Config Class Initialized
INFO - 2024-06-18 10:48:58 --> Loader Class Initialized
INFO - 2024-06-18 10:48:58 --> Helper loaded: url_helper
INFO - 2024-06-18 10:48:58 --> Helper loaded: file_helper
INFO - 2024-06-18 10:48:58 --> Helper loaded: form_helper
INFO - 2024-06-18 10:48:58 --> Helper loaded: my_helper
INFO - 2024-06-18 10:48:58 --> Database Driver Class Initialized
INFO - 2024-06-18 10:48:58 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-18 10:48:58 --> Controller Class Initialized
DEBUG - 2024-06-18 10:48:58 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/login/views/login.php
DEBUG - 2024-06-18 10:48:58 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-06-18 10:48:58 --> Final output sent to browser
DEBUG - 2024-06-18 10:48:58 --> Total execution time: 0.0316
INFO - 2024-06-18 10:49:03 --> Config Class Initialized
INFO - 2024-06-18 10:49:03 --> Hooks Class Initialized
DEBUG - 2024-06-18 10:49:03 --> UTF-8 Support Enabled
INFO - 2024-06-18 10:49:03 --> Utf8 Class Initialized
INFO - 2024-06-18 10:49:03 --> URI Class Initialized
INFO - 2024-06-18 10:49:03 --> Router Class Initialized
INFO - 2024-06-18 10:49:03 --> Output Class Initialized
INFO - 2024-06-18 10:49:03 --> Security Class Initialized
DEBUG - 2024-06-18 10:49:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-18 10:49:03 --> Input Class Initialized
INFO - 2024-06-18 10:49:03 --> Language Class Initialized
INFO - 2024-06-18 10:49:03 --> Language Class Initialized
INFO - 2024-06-18 10:49:03 --> Config Class Initialized
INFO - 2024-06-18 10:49:03 --> Loader Class Initialized
INFO - 2024-06-18 10:49:03 --> Helper loaded: url_helper
INFO - 2024-06-18 10:49:03 --> Helper loaded: file_helper
INFO - 2024-06-18 10:49:03 --> Helper loaded: form_helper
INFO - 2024-06-18 10:49:03 --> Helper loaded: my_helper
INFO - 2024-06-18 10:49:03 --> Database Driver Class Initialized
INFO - 2024-06-18 10:49:03 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-18 10:49:03 --> Controller Class Initialized
INFO - 2024-06-18 10:49:03 --> Helper loaded: cookie_helper
INFO - 2024-06-18 10:49:03 --> Final output sent to browser
DEBUG - 2024-06-18 10:49:03 --> Total execution time: 0.0354
INFO - 2024-06-18 10:49:03 --> Config Class Initialized
INFO - 2024-06-18 10:49:03 --> Hooks Class Initialized
DEBUG - 2024-06-18 10:49:03 --> UTF-8 Support Enabled
INFO - 2024-06-18 10:49:03 --> Utf8 Class Initialized
INFO - 2024-06-18 10:49:03 --> URI Class Initialized
INFO - 2024-06-18 10:49:03 --> Router Class Initialized
INFO - 2024-06-18 10:49:03 --> Output Class Initialized
INFO - 2024-06-18 10:49:03 --> Security Class Initialized
DEBUG - 2024-06-18 10:49:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-18 10:49:03 --> Input Class Initialized
INFO - 2024-06-18 10:49:03 --> Language Class Initialized
INFO - 2024-06-18 10:49:03 --> Language Class Initialized
INFO - 2024-06-18 10:49:03 --> Config Class Initialized
INFO - 2024-06-18 10:49:03 --> Loader Class Initialized
INFO - 2024-06-18 10:49:03 --> Helper loaded: url_helper
INFO - 2024-06-18 10:49:03 --> Helper loaded: file_helper
INFO - 2024-06-18 10:49:03 --> Helper loaded: form_helper
INFO - 2024-06-18 10:49:03 --> Helper loaded: my_helper
INFO - 2024-06-18 10:49:03 --> Database Driver Class Initialized
INFO - 2024-06-18 10:49:03 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-18 10:49:03 --> Controller Class Initialized
DEBUG - 2024-06-18 10:49:03 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/home/views/v_home_guru.php
DEBUG - 2024-06-18 10:49:03 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-06-18 10:49:03 --> Final output sent to browser
DEBUG - 2024-06-18 10:49:03 --> Total execution time: 0.0327
INFO - 2024-06-18 10:49:11 --> Config Class Initialized
INFO - 2024-06-18 10:49:11 --> Hooks Class Initialized
DEBUG - 2024-06-18 10:49:11 --> UTF-8 Support Enabled
INFO - 2024-06-18 10:49:11 --> Utf8 Class Initialized
INFO - 2024-06-18 10:49:11 --> URI Class Initialized
INFO - 2024-06-18 10:49:11 --> Router Class Initialized
INFO - 2024-06-18 10:49:11 --> Output Class Initialized
INFO - 2024-06-18 10:49:11 --> Security Class Initialized
DEBUG - 2024-06-18 10:49:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-18 10:49:11 --> Input Class Initialized
INFO - 2024-06-18 10:49:11 --> Language Class Initialized
INFO - 2024-06-18 10:49:11 --> Language Class Initialized
INFO - 2024-06-18 10:49:11 --> Config Class Initialized
INFO - 2024-06-18 10:49:11 --> Loader Class Initialized
INFO - 2024-06-18 10:49:11 --> Helper loaded: url_helper
INFO - 2024-06-18 10:49:11 --> Helper loaded: file_helper
INFO - 2024-06-18 10:49:11 --> Helper loaded: form_helper
INFO - 2024-06-18 10:49:11 --> Helper loaded: my_helper
INFO - 2024-06-18 10:49:11 --> Database Driver Class Initialized
INFO - 2024-06-18 10:49:11 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-18 10:49:11 --> Controller Class Initialized
DEBUG - 2024-06-18 10:49:11 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/view_mapel/views/v_view_mapel.php
DEBUG - 2024-06-18 10:49:11 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-06-18 10:49:11 --> Final output sent to browser
DEBUG - 2024-06-18 10:49:11 --> Total execution time: 0.0262
INFO - 2024-06-18 10:49:13 --> Config Class Initialized
INFO - 2024-06-18 10:49:13 --> Hooks Class Initialized
DEBUG - 2024-06-18 10:49:13 --> UTF-8 Support Enabled
INFO - 2024-06-18 10:49:13 --> Utf8 Class Initialized
INFO - 2024-06-18 10:49:13 --> URI Class Initialized
INFO - 2024-06-18 10:49:13 --> Router Class Initialized
INFO - 2024-06-18 10:49:13 --> Output Class Initialized
INFO - 2024-06-18 10:49:13 --> Security Class Initialized
DEBUG - 2024-06-18 10:49:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-18 10:49:13 --> Input Class Initialized
INFO - 2024-06-18 10:49:13 --> Language Class Initialized
INFO - 2024-06-18 10:49:13 --> Language Class Initialized
INFO - 2024-06-18 10:49:13 --> Config Class Initialized
INFO - 2024-06-18 10:49:13 --> Loader Class Initialized
INFO - 2024-06-18 10:49:13 --> Helper loaded: url_helper
INFO - 2024-06-18 10:49:13 --> Helper loaded: file_helper
INFO - 2024-06-18 10:49:13 --> Helper loaded: form_helper
INFO - 2024-06-18 10:49:13 --> Helper loaded: my_helper
INFO - 2024-06-18 10:49:13 --> Database Driver Class Initialized
INFO - 2024-06-18 10:49:13 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-18 10:49:13 --> Controller Class Initialized
DEBUG - 2024-06-18 10:49:13 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_catatan_guru/views/list.php
DEBUG - 2024-06-18 10:49:13 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-06-18 10:49:13 --> Final output sent to browser
DEBUG - 2024-06-18 10:49:13 --> Total execution time: 0.0336
INFO - 2024-06-18 10:49:46 --> Config Class Initialized
INFO - 2024-06-18 10:49:46 --> Hooks Class Initialized
DEBUG - 2024-06-18 10:49:46 --> UTF-8 Support Enabled
INFO - 2024-06-18 10:49:46 --> Utf8 Class Initialized
INFO - 2024-06-18 10:49:46 --> URI Class Initialized
INFO - 2024-06-18 10:49:46 --> Router Class Initialized
INFO - 2024-06-18 10:49:46 --> Output Class Initialized
INFO - 2024-06-18 10:49:46 --> Security Class Initialized
DEBUG - 2024-06-18 10:49:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-18 10:49:46 --> Input Class Initialized
INFO - 2024-06-18 10:49:46 --> Language Class Initialized
INFO - 2024-06-18 10:49:46 --> Language Class Initialized
INFO - 2024-06-18 10:49:46 --> Config Class Initialized
INFO - 2024-06-18 10:49:46 --> Loader Class Initialized
INFO - 2024-06-18 10:49:46 --> Helper loaded: url_helper
INFO - 2024-06-18 10:49:46 --> Helper loaded: file_helper
INFO - 2024-06-18 10:49:46 --> Helper loaded: form_helper
INFO - 2024-06-18 10:49:46 --> Helper loaded: my_helper
INFO - 2024-06-18 10:49:46 --> Database Driver Class Initialized
INFO - 2024-06-18 10:49:46 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-18 10:49:46 --> Controller Class Initialized
INFO - 2024-06-18 10:49:46 --> Final output sent to browser
DEBUG - 2024-06-18 10:49:46 --> Total execution time: 0.0318
INFO - 2024-06-18 10:50:39 --> Config Class Initialized
INFO - 2024-06-18 10:50:39 --> Hooks Class Initialized
DEBUG - 2024-06-18 10:50:39 --> UTF-8 Support Enabled
INFO - 2024-06-18 10:50:39 --> Utf8 Class Initialized
INFO - 2024-06-18 10:50:39 --> URI Class Initialized
INFO - 2024-06-18 10:50:39 --> Router Class Initialized
INFO - 2024-06-18 10:50:39 --> Output Class Initialized
INFO - 2024-06-18 10:50:39 --> Security Class Initialized
DEBUG - 2024-06-18 10:50:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-18 10:50:39 --> Input Class Initialized
INFO - 2024-06-18 10:50:39 --> Language Class Initialized
INFO - 2024-06-18 10:50:39 --> Language Class Initialized
INFO - 2024-06-18 10:50:39 --> Config Class Initialized
INFO - 2024-06-18 10:50:39 --> Loader Class Initialized
INFO - 2024-06-18 10:50:39 --> Helper loaded: url_helper
INFO - 2024-06-18 10:50:39 --> Helper loaded: file_helper
INFO - 2024-06-18 10:50:39 --> Helper loaded: form_helper
INFO - 2024-06-18 10:50:39 --> Helper loaded: my_helper
INFO - 2024-06-18 10:50:39 --> Database Driver Class Initialized
INFO - 2024-06-18 10:50:39 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-18 10:50:39 --> Controller Class Initialized
DEBUG - 2024-06-18 10:50:39 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/view_mapel/views/v_view_mapel.php
DEBUG - 2024-06-18 10:50:39 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-06-18 10:50:39 --> Final output sent to browser
DEBUG - 2024-06-18 10:50:39 --> Total execution time: 0.0285
INFO - 2024-06-18 10:50:40 --> Config Class Initialized
INFO - 2024-06-18 10:50:40 --> Hooks Class Initialized
DEBUG - 2024-06-18 10:50:40 --> UTF-8 Support Enabled
INFO - 2024-06-18 10:50:40 --> Utf8 Class Initialized
INFO - 2024-06-18 10:50:40 --> URI Class Initialized
INFO - 2024-06-18 10:50:40 --> Router Class Initialized
INFO - 2024-06-18 10:50:40 --> Output Class Initialized
INFO - 2024-06-18 10:50:40 --> Security Class Initialized
DEBUG - 2024-06-18 10:50:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-18 10:50:40 --> Input Class Initialized
INFO - 2024-06-18 10:50:40 --> Language Class Initialized
INFO - 2024-06-18 10:50:40 --> Language Class Initialized
INFO - 2024-06-18 10:50:40 --> Config Class Initialized
INFO - 2024-06-18 10:50:40 --> Loader Class Initialized
INFO - 2024-06-18 10:50:40 --> Helper loaded: url_helper
INFO - 2024-06-18 10:50:40 --> Helper loaded: file_helper
INFO - 2024-06-18 10:50:40 --> Helper loaded: form_helper
INFO - 2024-06-18 10:50:40 --> Helper loaded: my_helper
INFO - 2024-06-18 10:50:40 --> Database Driver Class Initialized
INFO - 2024-06-18 10:50:40 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-18 10:50:40 --> Controller Class Initialized
DEBUG - 2024-06-18 10:50:40 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/views/list.php
DEBUG - 2024-06-18 10:50:40 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-06-18 10:50:40 --> Final output sent to browser
DEBUG - 2024-06-18 10:50:40 --> Total execution time: 0.0286
INFO - 2024-06-18 10:50:41 --> Config Class Initialized
INFO - 2024-06-18 10:50:41 --> Hooks Class Initialized
DEBUG - 2024-06-18 10:50:41 --> UTF-8 Support Enabled
INFO - 2024-06-18 10:50:41 --> Utf8 Class Initialized
INFO - 2024-06-18 10:50:41 --> URI Class Initialized
INFO - 2024-06-18 10:50:41 --> Router Class Initialized
INFO - 2024-06-18 10:50:41 --> Output Class Initialized
INFO - 2024-06-18 10:50:41 --> Security Class Initialized
DEBUG - 2024-06-18 10:50:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-18 10:50:41 --> Input Class Initialized
INFO - 2024-06-18 10:50:41 --> Language Class Initialized
INFO - 2024-06-18 10:50:41 --> Language Class Initialized
INFO - 2024-06-18 10:50:41 --> Config Class Initialized
INFO - 2024-06-18 10:50:41 --> Loader Class Initialized
INFO - 2024-06-18 10:50:41 --> Helper loaded: url_helper
INFO - 2024-06-18 10:50:41 --> Helper loaded: file_helper
INFO - 2024-06-18 10:50:41 --> Helper loaded: form_helper
INFO - 2024-06-18 10:50:41 --> Helper loaded: my_helper
INFO - 2024-06-18 10:50:41 --> Database Driver Class Initialized
INFO - 2024-06-18 10:50:41 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-18 10:50:41 --> Controller Class Initialized
INFO - 2024-06-18 10:50:44 --> Config Class Initialized
INFO - 2024-06-18 10:50:44 --> Hooks Class Initialized
DEBUG - 2024-06-18 10:50:44 --> UTF-8 Support Enabled
INFO - 2024-06-18 10:50:44 --> Utf8 Class Initialized
INFO - 2024-06-18 10:50:44 --> URI Class Initialized
INFO - 2024-06-18 10:50:44 --> Router Class Initialized
INFO - 2024-06-18 10:50:44 --> Output Class Initialized
INFO - 2024-06-18 10:50:44 --> Security Class Initialized
DEBUG - 2024-06-18 10:50:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-18 10:50:44 --> Input Class Initialized
INFO - 2024-06-18 10:50:44 --> Language Class Initialized
INFO - 2024-06-18 10:50:44 --> Language Class Initialized
INFO - 2024-06-18 10:50:44 --> Config Class Initialized
INFO - 2024-06-18 10:50:44 --> Loader Class Initialized
INFO - 2024-06-18 10:50:44 --> Helper loaded: url_helper
INFO - 2024-06-18 10:50:44 --> Helper loaded: file_helper
INFO - 2024-06-18 10:50:44 --> Helper loaded: form_helper
INFO - 2024-06-18 10:50:44 --> Helper loaded: my_helper
INFO - 2024-06-18 10:50:44 --> Database Driver Class Initialized
INFO - 2024-06-18 10:50:44 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-18 10:50:44 --> Controller Class Initialized
INFO - 2024-06-18 10:50:44 --> Final output sent to browser
DEBUG - 2024-06-18 10:50:44 --> Total execution time: 0.0295
INFO - 2024-06-18 10:51:02 --> Config Class Initialized
INFO - 2024-06-18 10:51:02 --> Hooks Class Initialized
DEBUG - 2024-06-18 10:51:02 --> UTF-8 Support Enabled
INFO - 2024-06-18 10:51:02 --> Utf8 Class Initialized
INFO - 2024-06-18 10:51:02 --> URI Class Initialized
INFO - 2024-06-18 10:51:02 --> Router Class Initialized
INFO - 2024-06-18 10:51:02 --> Output Class Initialized
INFO - 2024-06-18 10:51:02 --> Security Class Initialized
DEBUG - 2024-06-18 10:51:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-18 10:51:02 --> Input Class Initialized
INFO - 2024-06-18 10:51:02 --> Language Class Initialized
INFO - 2024-06-18 10:51:02 --> Language Class Initialized
INFO - 2024-06-18 10:51:02 --> Config Class Initialized
INFO - 2024-06-18 10:51:02 --> Loader Class Initialized
INFO - 2024-06-18 10:51:02 --> Helper loaded: url_helper
INFO - 2024-06-18 10:51:02 --> Helper loaded: file_helper
INFO - 2024-06-18 10:51:02 --> Helper loaded: form_helper
INFO - 2024-06-18 10:51:02 --> Helper loaded: my_helper
INFO - 2024-06-18 10:51:02 --> Database Driver Class Initialized
INFO - 2024-06-18 10:51:03 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-18 10:51:03 --> Controller Class Initialized
INFO - 2024-06-18 10:56:41 --> Config Class Initialized
INFO - 2024-06-18 10:56:41 --> Hooks Class Initialized
DEBUG - 2024-06-18 10:56:41 --> UTF-8 Support Enabled
INFO - 2024-06-18 10:56:41 --> Utf8 Class Initialized
INFO - 2024-06-18 10:56:41 --> URI Class Initialized
INFO - 2024-06-18 10:56:41 --> Router Class Initialized
INFO - 2024-06-18 10:56:41 --> Output Class Initialized
INFO - 2024-06-18 10:56:41 --> Security Class Initialized
DEBUG - 2024-06-18 10:56:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-18 10:56:41 --> Input Class Initialized
INFO - 2024-06-18 10:56:41 --> Language Class Initialized
INFO - 2024-06-18 10:56:41 --> Language Class Initialized
INFO - 2024-06-18 10:56:41 --> Config Class Initialized
INFO - 2024-06-18 10:56:41 --> Loader Class Initialized
INFO - 2024-06-18 10:56:41 --> Helper loaded: url_helper
INFO - 2024-06-18 10:56:41 --> Helper loaded: file_helper
INFO - 2024-06-18 10:56:41 --> Helper loaded: form_helper
INFO - 2024-06-18 10:56:41 --> Helper loaded: my_helper
INFO - 2024-06-18 10:56:41 --> Database Driver Class Initialized
INFO - 2024-06-18 10:56:41 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-18 10:56:41 --> Controller Class Initialized
DEBUG - 2024-06-18 10:56:41 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/views/form.php
DEBUG - 2024-06-18 10:56:41 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-06-18 10:56:41 --> Final output sent to browser
DEBUG - 2024-06-18 10:56:41 --> Total execution time: 0.0289
INFO - 2024-06-18 10:56:50 --> Config Class Initialized
INFO - 2024-06-18 10:56:50 --> Hooks Class Initialized
DEBUG - 2024-06-18 10:56:50 --> UTF-8 Support Enabled
INFO - 2024-06-18 10:56:50 --> Utf8 Class Initialized
INFO - 2024-06-18 10:56:50 --> URI Class Initialized
INFO - 2024-06-18 10:56:50 --> Router Class Initialized
INFO - 2024-06-18 10:56:50 --> Output Class Initialized
INFO - 2024-06-18 10:56:50 --> Security Class Initialized
DEBUG - 2024-06-18 10:56:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-18 10:56:50 --> Input Class Initialized
INFO - 2024-06-18 10:56:50 --> Language Class Initialized
INFO - 2024-06-18 10:56:50 --> Language Class Initialized
INFO - 2024-06-18 10:56:50 --> Config Class Initialized
INFO - 2024-06-18 10:56:50 --> Loader Class Initialized
INFO - 2024-06-18 10:56:50 --> Helper loaded: url_helper
INFO - 2024-06-18 10:56:50 --> Helper loaded: file_helper
INFO - 2024-06-18 10:56:50 --> Helper loaded: form_helper
INFO - 2024-06-18 10:56:50 --> Helper loaded: my_helper
INFO - 2024-06-18 10:56:50 --> Database Driver Class Initialized
INFO - 2024-06-18 10:56:50 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-18 10:56:50 --> Controller Class Initialized
INFO - 2024-06-18 10:56:50 --> Config Class Initialized
INFO - 2024-06-18 10:56:50 --> Hooks Class Initialized
DEBUG - 2024-06-18 10:56:50 --> UTF-8 Support Enabled
INFO - 2024-06-18 10:56:50 --> Utf8 Class Initialized
INFO - 2024-06-18 10:56:50 --> URI Class Initialized
INFO - 2024-06-18 10:56:50 --> Router Class Initialized
INFO - 2024-06-18 10:56:50 --> Output Class Initialized
INFO - 2024-06-18 10:56:50 --> Security Class Initialized
DEBUG - 2024-06-18 10:56:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-18 10:56:50 --> Input Class Initialized
INFO - 2024-06-18 10:56:50 --> Language Class Initialized
INFO - 2024-06-18 10:56:50 --> Language Class Initialized
INFO - 2024-06-18 10:56:50 --> Config Class Initialized
INFO - 2024-06-18 10:56:50 --> Loader Class Initialized
INFO - 2024-06-18 10:56:50 --> Helper loaded: url_helper
INFO - 2024-06-18 10:56:50 --> Helper loaded: file_helper
INFO - 2024-06-18 10:56:50 --> Helper loaded: form_helper
INFO - 2024-06-18 10:56:50 --> Helper loaded: my_helper
INFO - 2024-06-18 10:56:50 --> Database Driver Class Initialized
INFO - 2024-06-18 10:56:50 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-18 10:56:50 --> Controller Class Initialized
DEBUG - 2024-06-18 10:56:50 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/views/list.php
DEBUG - 2024-06-18 10:56:50 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-06-18 10:56:50 --> Final output sent to browser
DEBUG - 2024-06-18 10:56:50 --> Total execution time: 0.0326
INFO - 2024-06-18 10:56:50 --> Config Class Initialized
INFO - 2024-06-18 10:56:50 --> Hooks Class Initialized
DEBUG - 2024-06-18 10:56:50 --> UTF-8 Support Enabled
INFO - 2024-06-18 10:56:50 --> Utf8 Class Initialized
INFO - 2024-06-18 10:56:50 --> URI Class Initialized
INFO - 2024-06-18 10:56:50 --> Router Class Initialized
INFO - 2024-06-18 10:56:50 --> Output Class Initialized
INFO - 2024-06-18 10:56:50 --> Security Class Initialized
DEBUG - 2024-06-18 10:56:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-18 10:56:50 --> Input Class Initialized
INFO - 2024-06-18 10:56:50 --> Language Class Initialized
INFO - 2024-06-18 10:56:50 --> Language Class Initialized
INFO - 2024-06-18 10:56:50 --> Config Class Initialized
INFO - 2024-06-18 10:56:50 --> Loader Class Initialized
INFO - 2024-06-18 10:56:50 --> Helper loaded: url_helper
INFO - 2024-06-18 10:56:50 --> Helper loaded: file_helper
INFO - 2024-06-18 10:56:50 --> Helper loaded: form_helper
INFO - 2024-06-18 10:56:50 --> Helper loaded: my_helper
INFO - 2024-06-18 10:56:50 --> Database Driver Class Initialized
INFO - 2024-06-18 10:56:50 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-18 10:56:50 --> Controller Class Initialized
INFO - 2024-06-18 10:56:54 --> Config Class Initialized
INFO - 2024-06-18 10:56:54 --> Hooks Class Initialized
DEBUG - 2024-06-18 10:56:54 --> UTF-8 Support Enabled
INFO - 2024-06-18 10:56:54 --> Utf8 Class Initialized
INFO - 2024-06-18 10:56:54 --> URI Class Initialized
INFO - 2024-06-18 10:56:54 --> Router Class Initialized
INFO - 2024-06-18 10:56:54 --> Output Class Initialized
INFO - 2024-06-18 10:56:54 --> Security Class Initialized
DEBUG - 2024-06-18 10:56:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-18 10:56:54 --> Input Class Initialized
INFO - 2024-06-18 10:56:54 --> Language Class Initialized
INFO - 2024-06-18 10:56:54 --> Language Class Initialized
INFO - 2024-06-18 10:56:54 --> Config Class Initialized
INFO - 2024-06-18 10:56:54 --> Loader Class Initialized
INFO - 2024-06-18 10:56:54 --> Helper loaded: url_helper
INFO - 2024-06-18 10:56:54 --> Helper loaded: file_helper
INFO - 2024-06-18 10:56:54 --> Helper loaded: form_helper
INFO - 2024-06-18 10:56:54 --> Helper loaded: my_helper
INFO - 2024-06-18 10:56:54 --> Database Driver Class Initialized
INFO - 2024-06-18 10:56:54 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-18 10:56:54 --> Controller Class Initialized
INFO - 2024-06-18 10:56:54 --> Final output sent to browser
DEBUG - 2024-06-18 10:56:54 --> Total execution time: 0.0304
INFO - 2024-06-18 10:57:03 --> Config Class Initialized
INFO - 2024-06-18 10:57:03 --> Hooks Class Initialized
DEBUG - 2024-06-18 10:57:03 --> UTF-8 Support Enabled
INFO - 2024-06-18 10:57:03 --> Utf8 Class Initialized
INFO - 2024-06-18 10:57:03 --> URI Class Initialized
INFO - 2024-06-18 10:57:03 --> Router Class Initialized
INFO - 2024-06-18 10:57:04 --> Output Class Initialized
INFO - 2024-06-18 10:57:04 --> Security Class Initialized
DEBUG - 2024-06-18 10:57:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-18 10:57:04 --> Input Class Initialized
INFO - 2024-06-18 10:57:04 --> Language Class Initialized
INFO - 2024-06-18 10:57:04 --> Language Class Initialized
INFO - 2024-06-18 10:57:04 --> Config Class Initialized
INFO - 2024-06-18 10:57:04 --> Loader Class Initialized
INFO - 2024-06-18 10:57:04 --> Helper loaded: url_helper
INFO - 2024-06-18 10:57:04 --> Helper loaded: file_helper
INFO - 2024-06-18 10:57:04 --> Helper loaded: form_helper
INFO - 2024-06-18 10:57:04 --> Helper loaded: my_helper
INFO - 2024-06-18 10:57:04 --> Database Driver Class Initialized
INFO - 2024-06-18 10:57:04 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-18 10:57:04 --> Controller Class Initialized
INFO - 2024-06-18 10:57:04 --> Final output sent to browser
DEBUG - 2024-06-18 10:57:04 --> Total execution time: 0.1127
INFO - 2024-06-18 10:57:10 --> Config Class Initialized
INFO - 2024-06-18 10:57:10 --> Hooks Class Initialized
DEBUG - 2024-06-18 10:57:10 --> UTF-8 Support Enabled
INFO - 2024-06-18 10:57:10 --> Utf8 Class Initialized
INFO - 2024-06-18 10:57:10 --> URI Class Initialized
INFO - 2024-06-18 10:57:10 --> Router Class Initialized
INFO - 2024-06-18 10:57:10 --> Output Class Initialized
INFO - 2024-06-18 10:57:10 --> Security Class Initialized
DEBUG - 2024-06-18 10:57:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-18 10:57:10 --> Input Class Initialized
INFO - 2024-06-18 10:57:10 --> Language Class Initialized
INFO - 2024-06-18 10:57:10 --> Language Class Initialized
INFO - 2024-06-18 10:57:10 --> Config Class Initialized
INFO - 2024-06-18 10:57:10 --> Loader Class Initialized
INFO - 2024-06-18 10:57:10 --> Helper loaded: url_helper
INFO - 2024-06-18 10:57:10 --> Helper loaded: file_helper
INFO - 2024-06-18 10:57:10 --> Helper loaded: form_helper
INFO - 2024-06-18 10:57:10 --> Helper loaded: my_helper
INFO - 2024-06-18 10:57:10 --> Database Driver Class Initialized
INFO - 2024-06-18 10:57:10 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-18 10:57:10 --> Controller Class Initialized
DEBUG - 2024-06-18 10:57:10 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/view_mapel/views/v_view_mapel.php
DEBUG - 2024-06-18 10:57:10 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-06-18 10:57:10 --> Final output sent to browser
DEBUG - 2024-06-18 10:57:10 --> Total execution time: 0.0237
INFO - 2024-06-18 10:57:16 --> Config Class Initialized
INFO - 2024-06-18 10:57:16 --> Hooks Class Initialized
DEBUG - 2024-06-18 10:57:16 --> UTF-8 Support Enabled
INFO - 2024-06-18 10:57:16 --> Utf8 Class Initialized
INFO - 2024-06-18 10:57:16 --> URI Class Initialized
INFO - 2024-06-18 10:57:16 --> Router Class Initialized
INFO - 2024-06-18 10:57:16 --> Output Class Initialized
INFO - 2024-06-18 10:57:16 --> Security Class Initialized
DEBUG - 2024-06-18 10:57:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-18 10:57:16 --> Input Class Initialized
INFO - 2024-06-18 10:57:16 --> Language Class Initialized
INFO - 2024-06-18 10:57:16 --> Language Class Initialized
INFO - 2024-06-18 10:57:16 --> Config Class Initialized
INFO - 2024-06-18 10:57:16 --> Loader Class Initialized
INFO - 2024-06-18 10:57:16 --> Helper loaded: url_helper
INFO - 2024-06-18 10:57:16 --> Helper loaded: file_helper
INFO - 2024-06-18 10:57:16 --> Helper loaded: form_helper
INFO - 2024-06-18 10:57:16 --> Helper loaded: my_helper
INFO - 2024-06-18 10:57:16 --> Database Driver Class Initialized
INFO - 2024-06-18 10:57:16 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-18 10:57:16 --> Controller Class Initialized
DEBUG - 2024-06-18 10:57:16 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_catatan_guru/views/list.php
DEBUG - 2024-06-18 10:57:16 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-06-18 10:57:16 --> Final output sent to browser
DEBUG - 2024-06-18 10:57:16 --> Total execution time: 0.0334
INFO - 2024-06-18 10:57:18 --> Config Class Initialized
INFO - 2024-06-18 10:57:18 --> Hooks Class Initialized
DEBUG - 2024-06-18 10:57:18 --> UTF-8 Support Enabled
INFO - 2024-06-18 10:57:18 --> Utf8 Class Initialized
INFO - 2024-06-18 10:57:18 --> URI Class Initialized
INFO - 2024-06-18 10:57:18 --> Router Class Initialized
INFO - 2024-06-18 10:57:18 --> Output Class Initialized
INFO - 2024-06-18 10:57:18 --> Security Class Initialized
DEBUG - 2024-06-18 10:57:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-18 10:57:18 --> Input Class Initialized
INFO - 2024-06-18 10:57:18 --> Language Class Initialized
INFO - 2024-06-18 10:57:18 --> Language Class Initialized
INFO - 2024-06-18 10:57:18 --> Config Class Initialized
INFO - 2024-06-18 10:57:18 --> Loader Class Initialized
INFO - 2024-06-18 10:57:18 --> Helper loaded: url_helper
INFO - 2024-06-18 10:57:18 --> Helper loaded: file_helper
INFO - 2024-06-18 10:57:18 --> Helper loaded: form_helper
INFO - 2024-06-18 10:57:18 --> Helper loaded: my_helper
INFO - 2024-06-18 10:57:18 --> Database Driver Class Initialized
INFO - 2024-06-18 10:57:18 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-18 10:57:18 --> Controller Class Initialized
INFO - 2024-06-18 10:57:18 --> Final output sent to browser
DEBUG - 2024-06-18 10:57:18 --> Total execution time: 0.0909
INFO - 2024-06-18 10:57:22 --> Config Class Initialized
INFO - 2024-06-18 10:57:22 --> Hooks Class Initialized
DEBUG - 2024-06-18 10:57:22 --> UTF-8 Support Enabled
INFO - 2024-06-18 10:57:22 --> Utf8 Class Initialized
INFO - 2024-06-18 10:57:22 --> URI Class Initialized
INFO - 2024-06-18 10:57:22 --> Router Class Initialized
INFO - 2024-06-18 10:57:22 --> Output Class Initialized
INFO - 2024-06-18 10:57:22 --> Security Class Initialized
DEBUG - 2024-06-18 10:57:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-18 10:57:22 --> Input Class Initialized
INFO - 2024-06-18 10:57:22 --> Language Class Initialized
INFO - 2024-06-18 10:57:22 --> Language Class Initialized
INFO - 2024-06-18 10:57:22 --> Config Class Initialized
INFO - 2024-06-18 10:57:22 --> Loader Class Initialized
INFO - 2024-06-18 10:57:22 --> Helper loaded: url_helper
INFO - 2024-06-18 10:57:22 --> Helper loaded: file_helper
INFO - 2024-06-18 10:57:22 --> Helper loaded: form_helper
INFO - 2024-06-18 10:57:22 --> Helper loaded: my_helper
INFO - 2024-06-18 10:57:22 --> Database Driver Class Initialized
INFO - 2024-06-18 10:57:22 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-18 10:57:22 --> Controller Class Initialized
DEBUG - 2024-06-18 10:57:22 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/view_mapel/views/v_view_mapel.php
DEBUG - 2024-06-18 10:57:22 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-06-18 10:57:22 --> Final output sent to browser
DEBUG - 2024-06-18 10:57:22 --> Total execution time: 0.0266
INFO - 2024-06-18 10:57:23 --> Config Class Initialized
INFO - 2024-06-18 10:57:23 --> Hooks Class Initialized
DEBUG - 2024-06-18 10:57:23 --> UTF-8 Support Enabled
INFO - 2024-06-18 10:57:23 --> Utf8 Class Initialized
INFO - 2024-06-18 10:57:23 --> URI Class Initialized
INFO - 2024-06-18 10:57:23 --> Router Class Initialized
INFO - 2024-06-18 10:57:23 --> Output Class Initialized
INFO - 2024-06-18 10:57:23 --> Security Class Initialized
DEBUG - 2024-06-18 10:57:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-18 10:57:23 --> Input Class Initialized
INFO - 2024-06-18 10:57:23 --> Language Class Initialized
INFO - 2024-06-18 10:57:23 --> Language Class Initialized
INFO - 2024-06-18 10:57:23 --> Config Class Initialized
INFO - 2024-06-18 10:57:23 --> Loader Class Initialized
INFO - 2024-06-18 10:57:23 --> Helper loaded: url_helper
INFO - 2024-06-18 10:57:23 --> Helper loaded: file_helper
INFO - 2024-06-18 10:57:23 --> Helper loaded: form_helper
INFO - 2024-06-18 10:57:23 --> Helper loaded: my_helper
INFO - 2024-06-18 10:57:23 --> Database Driver Class Initialized
INFO - 2024-06-18 10:57:23 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-18 10:57:23 --> Controller Class Initialized
DEBUG - 2024-06-18 10:57:23 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/views/list.php
DEBUG - 2024-06-18 10:57:23 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-06-18 10:57:23 --> Final output sent to browser
DEBUG - 2024-06-18 10:57:23 --> Total execution time: 0.0331
INFO - 2024-06-18 10:57:24 --> Config Class Initialized
INFO - 2024-06-18 10:57:24 --> Hooks Class Initialized
DEBUG - 2024-06-18 10:57:24 --> UTF-8 Support Enabled
INFO - 2024-06-18 10:57:24 --> Utf8 Class Initialized
INFO - 2024-06-18 10:57:24 --> URI Class Initialized
INFO - 2024-06-18 10:57:24 --> Router Class Initialized
INFO - 2024-06-18 10:57:24 --> Output Class Initialized
INFO - 2024-06-18 10:57:24 --> Security Class Initialized
DEBUG - 2024-06-18 10:57:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-18 10:57:24 --> Input Class Initialized
INFO - 2024-06-18 10:57:24 --> Language Class Initialized
INFO - 2024-06-18 10:57:24 --> Language Class Initialized
INFO - 2024-06-18 10:57:24 --> Config Class Initialized
INFO - 2024-06-18 10:57:24 --> Loader Class Initialized
INFO - 2024-06-18 10:57:24 --> Helper loaded: url_helper
INFO - 2024-06-18 10:57:24 --> Helper loaded: file_helper
INFO - 2024-06-18 10:57:24 --> Helper loaded: form_helper
INFO - 2024-06-18 10:57:24 --> Helper loaded: my_helper
INFO - 2024-06-18 10:57:24 --> Database Driver Class Initialized
INFO - 2024-06-18 10:57:24 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-18 10:57:24 --> Controller Class Initialized
INFO - 2024-06-18 10:57:26 --> Config Class Initialized
INFO - 2024-06-18 10:57:26 --> Hooks Class Initialized
DEBUG - 2024-06-18 10:57:26 --> UTF-8 Support Enabled
INFO - 2024-06-18 10:57:26 --> Utf8 Class Initialized
INFO - 2024-06-18 10:57:26 --> URI Class Initialized
INFO - 2024-06-18 10:57:26 --> Router Class Initialized
INFO - 2024-06-18 10:57:26 --> Output Class Initialized
INFO - 2024-06-18 10:57:26 --> Security Class Initialized
DEBUG - 2024-06-18 10:57:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-18 10:57:26 --> Input Class Initialized
INFO - 2024-06-18 10:57:26 --> Language Class Initialized
INFO - 2024-06-18 10:57:26 --> Language Class Initialized
INFO - 2024-06-18 10:57:26 --> Config Class Initialized
INFO - 2024-06-18 10:57:26 --> Loader Class Initialized
INFO - 2024-06-18 10:57:26 --> Helper loaded: url_helper
INFO - 2024-06-18 10:57:26 --> Helper loaded: file_helper
INFO - 2024-06-18 10:57:26 --> Helper loaded: form_helper
INFO - 2024-06-18 10:57:26 --> Helper loaded: my_helper
INFO - 2024-06-18 10:57:26 --> Database Driver Class Initialized
INFO - 2024-06-18 10:57:26 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-18 10:57:26 --> Controller Class Initialized
INFO - 2024-06-18 11:01:03 --> Config Class Initialized
INFO - 2024-06-18 11:01:03 --> Hooks Class Initialized
DEBUG - 2024-06-18 11:01:03 --> UTF-8 Support Enabled
INFO - 2024-06-18 11:01:03 --> Utf8 Class Initialized
INFO - 2024-06-18 11:01:03 --> URI Class Initialized
INFO - 2024-06-18 11:01:03 --> Router Class Initialized
INFO - 2024-06-18 11:01:03 --> Output Class Initialized
INFO - 2024-06-18 11:01:03 --> Security Class Initialized
DEBUG - 2024-06-18 11:01:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-18 11:01:03 --> Input Class Initialized
INFO - 2024-06-18 11:01:03 --> Language Class Initialized
INFO - 2024-06-18 11:01:03 --> Language Class Initialized
INFO - 2024-06-18 11:01:03 --> Config Class Initialized
INFO - 2024-06-18 11:01:03 --> Loader Class Initialized
INFO - 2024-06-18 11:01:03 --> Helper loaded: url_helper
INFO - 2024-06-18 11:01:03 --> Helper loaded: file_helper
INFO - 2024-06-18 11:01:03 --> Helper loaded: form_helper
INFO - 2024-06-18 11:01:03 --> Helper loaded: my_helper
INFO - 2024-06-18 11:01:03 --> Database Driver Class Initialized
INFO - 2024-06-18 11:01:03 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-18 11:01:03 --> Controller Class Initialized
DEBUG - 2024-06-18 11:01:03 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/views/form.php
DEBUG - 2024-06-18 11:01:03 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-06-18 11:01:03 --> Final output sent to browser
DEBUG - 2024-06-18 11:01:03 --> Total execution time: 0.0494
INFO - 2024-06-18 11:01:09 --> Config Class Initialized
INFO - 2024-06-18 11:01:09 --> Hooks Class Initialized
DEBUG - 2024-06-18 11:01:09 --> UTF-8 Support Enabled
INFO - 2024-06-18 11:01:09 --> Utf8 Class Initialized
INFO - 2024-06-18 11:01:09 --> URI Class Initialized
INFO - 2024-06-18 11:01:09 --> Router Class Initialized
INFO - 2024-06-18 11:01:09 --> Output Class Initialized
INFO - 2024-06-18 11:01:09 --> Security Class Initialized
DEBUG - 2024-06-18 11:01:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-18 11:01:09 --> Input Class Initialized
INFO - 2024-06-18 11:01:09 --> Language Class Initialized
INFO - 2024-06-18 11:01:09 --> Language Class Initialized
INFO - 2024-06-18 11:01:09 --> Config Class Initialized
INFO - 2024-06-18 11:01:09 --> Loader Class Initialized
INFO - 2024-06-18 11:01:09 --> Helper loaded: url_helper
INFO - 2024-06-18 11:01:09 --> Helper loaded: file_helper
INFO - 2024-06-18 11:01:09 --> Helper loaded: form_helper
INFO - 2024-06-18 11:01:09 --> Helper loaded: my_helper
INFO - 2024-06-18 11:01:09 --> Database Driver Class Initialized
INFO - 2024-06-18 11:01:09 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-18 11:01:09 --> Controller Class Initialized
INFO - 2024-06-18 11:01:10 --> Config Class Initialized
INFO - 2024-06-18 11:01:10 --> Hooks Class Initialized
DEBUG - 2024-06-18 11:01:10 --> UTF-8 Support Enabled
INFO - 2024-06-18 11:01:10 --> Utf8 Class Initialized
INFO - 2024-06-18 11:01:10 --> URI Class Initialized
INFO - 2024-06-18 11:01:10 --> Router Class Initialized
INFO - 2024-06-18 11:01:10 --> Output Class Initialized
INFO - 2024-06-18 11:01:10 --> Security Class Initialized
DEBUG - 2024-06-18 11:01:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-18 11:01:10 --> Input Class Initialized
INFO - 2024-06-18 11:01:10 --> Language Class Initialized
INFO - 2024-06-18 11:01:10 --> Language Class Initialized
INFO - 2024-06-18 11:01:10 --> Config Class Initialized
INFO - 2024-06-18 11:01:10 --> Loader Class Initialized
INFO - 2024-06-18 11:01:10 --> Helper loaded: url_helper
INFO - 2024-06-18 11:01:10 --> Helper loaded: file_helper
INFO - 2024-06-18 11:01:10 --> Helper loaded: form_helper
INFO - 2024-06-18 11:01:10 --> Helper loaded: my_helper
INFO - 2024-06-18 11:01:10 --> Database Driver Class Initialized
INFO - 2024-06-18 11:01:10 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-18 11:01:10 --> Controller Class Initialized
DEBUG - 2024-06-18 11:01:10 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/views/list.php
DEBUG - 2024-06-18 11:01:10 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-06-18 11:01:10 --> Final output sent to browser
DEBUG - 2024-06-18 11:01:10 --> Total execution time: 0.0391
INFO - 2024-06-18 11:01:10 --> Config Class Initialized
INFO - 2024-06-18 11:01:10 --> Hooks Class Initialized
DEBUG - 2024-06-18 11:01:10 --> UTF-8 Support Enabled
INFO - 2024-06-18 11:01:10 --> Utf8 Class Initialized
INFO - 2024-06-18 11:01:10 --> URI Class Initialized
INFO - 2024-06-18 11:01:10 --> Router Class Initialized
INFO - 2024-06-18 11:01:10 --> Output Class Initialized
INFO - 2024-06-18 11:01:10 --> Security Class Initialized
DEBUG - 2024-06-18 11:01:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-18 11:01:10 --> Input Class Initialized
INFO - 2024-06-18 11:01:10 --> Language Class Initialized
INFO - 2024-06-18 11:01:10 --> Language Class Initialized
INFO - 2024-06-18 11:01:10 --> Config Class Initialized
INFO - 2024-06-18 11:01:10 --> Loader Class Initialized
INFO - 2024-06-18 11:01:10 --> Helper loaded: url_helper
INFO - 2024-06-18 11:01:10 --> Helper loaded: file_helper
INFO - 2024-06-18 11:01:10 --> Helper loaded: form_helper
INFO - 2024-06-18 11:01:10 --> Helper loaded: my_helper
INFO - 2024-06-18 11:01:10 --> Database Driver Class Initialized
INFO - 2024-06-18 11:01:10 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-18 11:01:10 --> Controller Class Initialized
INFO - 2024-06-18 11:01:13 --> Config Class Initialized
INFO - 2024-06-18 11:01:13 --> Hooks Class Initialized
DEBUG - 2024-06-18 11:01:13 --> UTF-8 Support Enabled
INFO - 2024-06-18 11:01:13 --> Utf8 Class Initialized
INFO - 2024-06-18 11:01:13 --> URI Class Initialized
INFO - 2024-06-18 11:01:13 --> Router Class Initialized
INFO - 2024-06-18 11:01:13 --> Output Class Initialized
INFO - 2024-06-18 11:01:13 --> Security Class Initialized
DEBUG - 2024-06-18 11:01:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-18 11:01:13 --> Input Class Initialized
INFO - 2024-06-18 11:01:13 --> Language Class Initialized
INFO - 2024-06-18 11:01:13 --> Language Class Initialized
INFO - 2024-06-18 11:01:13 --> Config Class Initialized
INFO - 2024-06-18 11:01:13 --> Loader Class Initialized
INFO - 2024-06-18 11:01:13 --> Helper loaded: url_helper
INFO - 2024-06-18 11:01:13 --> Helper loaded: file_helper
INFO - 2024-06-18 11:01:13 --> Helper loaded: form_helper
INFO - 2024-06-18 11:01:13 --> Helper loaded: my_helper
INFO - 2024-06-18 11:01:13 --> Database Driver Class Initialized
INFO - 2024-06-18 11:01:13 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-18 11:01:13 --> Controller Class Initialized
DEBUG - 2024-06-18 11:01:13 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/views/cetak.php
INFO - 2024-06-18 11:01:13 --> Final output sent to browser
DEBUG - 2024-06-18 11:01:13 --> Total execution time: 0.1009
INFO - 2024-06-18 11:01:22 --> Config Class Initialized
INFO - 2024-06-18 11:01:22 --> Hooks Class Initialized
DEBUG - 2024-06-18 11:01:22 --> UTF-8 Support Enabled
INFO - 2024-06-18 11:01:22 --> Utf8 Class Initialized
INFO - 2024-06-18 11:01:22 --> URI Class Initialized
INFO - 2024-06-18 11:01:22 --> Router Class Initialized
INFO - 2024-06-18 11:01:22 --> Output Class Initialized
INFO - 2024-06-18 11:01:22 --> Security Class Initialized
DEBUG - 2024-06-18 11:01:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-18 11:01:22 --> Input Class Initialized
INFO - 2024-06-18 11:01:22 --> Language Class Initialized
INFO - 2024-06-18 11:01:22 --> Language Class Initialized
INFO - 2024-06-18 11:01:22 --> Config Class Initialized
INFO - 2024-06-18 11:01:22 --> Loader Class Initialized
INFO - 2024-06-18 11:01:22 --> Helper loaded: url_helper
INFO - 2024-06-18 11:01:22 --> Helper loaded: file_helper
INFO - 2024-06-18 11:01:22 --> Helper loaded: form_helper
INFO - 2024-06-18 11:01:22 --> Helper loaded: my_helper
INFO - 2024-06-18 11:01:22 --> Database Driver Class Initialized
INFO - 2024-06-18 11:01:22 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-18 11:01:22 --> Controller Class Initialized
INFO - 2024-06-18 11:01:22 --> Final output sent to browser
DEBUG - 2024-06-18 11:01:22 --> Total execution time: 0.0298
INFO - 2024-06-18 11:01:31 --> Config Class Initialized
INFO - 2024-06-18 11:01:31 --> Hooks Class Initialized
DEBUG - 2024-06-18 11:01:31 --> UTF-8 Support Enabled
INFO - 2024-06-18 11:01:31 --> Utf8 Class Initialized
INFO - 2024-06-18 11:01:31 --> URI Class Initialized
INFO - 2024-06-18 11:01:31 --> Router Class Initialized
INFO - 2024-06-18 11:01:31 --> Output Class Initialized
INFO - 2024-06-18 11:01:31 --> Security Class Initialized
DEBUG - 2024-06-18 11:01:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-18 11:01:31 --> Input Class Initialized
INFO - 2024-06-18 11:01:31 --> Language Class Initialized
INFO - 2024-06-18 11:01:31 --> Language Class Initialized
INFO - 2024-06-18 11:01:31 --> Config Class Initialized
INFO - 2024-06-18 11:01:31 --> Loader Class Initialized
INFO - 2024-06-18 11:01:31 --> Helper loaded: url_helper
INFO - 2024-06-18 11:01:31 --> Helper loaded: file_helper
INFO - 2024-06-18 11:01:31 --> Helper loaded: form_helper
INFO - 2024-06-18 11:01:31 --> Helper loaded: my_helper
INFO - 2024-06-18 11:01:31 --> Database Driver Class Initialized
INFO - 2024-06-18 11:01:31 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-18 11:01:31 --> Controller Class Initialized
INFO - 2024-06-18 11:01:31 --> Final output sent to browser
DEBUG - 2024-06-18 11:01:31 --> Total execution time: 0.1224
INFO - 2024-06-18 11:01:34 --> Config Class Initialized
INFO - 2024-06-18 11:01:34 --> Hooks Class Initialized
DEBUG - 2024-06-18 11:01:34 --> UTF-8 Support Enabled
INFO - 2024-06-18 11:01:34 --> Utf8 Class Initialized
INFO - 2024-06-18 11:01:34 --> URI Class Initialized
INFO - 2024-06-18 11:01:34 --> Router Class Initialized
INFO - 2024-06-18 11:01:34 --> Output Class Initialized
INFO - 2024-06-18 11:01:34 --> Security Class Initialized
DEBUG - 2024-06-18 11:01:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-18 11:01:34 --> Input Class Initialized
INFO - 2024-06-18 11:01:34 --> Language Class Initialized
INFO - 2024-06-18 11:01:34 --> Language Class Initialized
INFO - 2024-06-18 11:01:34 --> Config Class Initialized
INFO - 2024-06-18 11:01:34 --> Loader Class Initialized
INFO - 2024-06-18 11:01:34 --> Helper loaded: url_helper
INFO - 2024-06-18 11:01:34 --> Helper loaded: file_helper
INFO - 2024-06-18 11:01:34 --> Helper loaded: form_helper
INFO - 2024-06-18 11:01:34 --> Helper loaded: my_helper
INFO - 2024-06-18 11:01:34 --> Database Driver Class Initialized
INFO - 2024-06-18 11:01:34 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-18 11:01:34 --> Controller Class Initialized
DEBUG - 2024-06-18 11:01:34 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/views/cetak.php
INFO - 2024-06-18 11:01:34 --> Final output sent to browser
DEBUG - 2024-06-18 11:01:34 --> Total execution time: 0.0414
INFO - 2024-06-18 11:01:45 --> Config Class Initialized
INFO - 2024-06-18 11:01:45 --> Hooks Class Initialized
DEBUG - 2024-06-18 11:01:45 --> UTF-8 Support Enabled
INFO - 2024-06-18 11:01:45 --> Utf8 Class Initialized
INFO - 2024-06-18 11:01:45 --> URI Class Initialized
INFO - 2024-06-18 11:01:45 --> Router Class Initialized
INFO - 2024-06-18 11:01:45 --> Output Class Initialized
INFO - 2024-06-18 11:01:45 --> Security Class Initialized
DEBUG - 2024-06-18 11:01:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-18 11:01:45 --> Input Class Initialized
INFO - 2024-06-18 11:01:45 --> Language Class Initialized
INFO - 2024-06-18 11:01:45 --> Language Class Initialized
INFO - 2024-06-18 11:01:45 --> Config Class Initialized
INFO - 2024-06-18 11:01:45 --> Loader Class Initialized
INFO - 2024-06-18 11:01:45 --> Helper loaded: url_helper
INFO - 2024-06-18 11:01:45 --> Helper loaded: file_helper
INFO - 2024-06-18 11:01:45 --> Helper loaded: form_helper
INFO - 2024-06-18 11:01:45 --> Helper loaded: my_helper
INFO - 2024-06-18 11:01:45 --> Database Driver Class Initialized
INFO - 2024-06-18 11:01:45 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-18 11:01:45 --> Controller Class Initialized
DEBUG - 2024-06-18 11:01:45 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/view_mapel/views/v_view_mapel.php
DEBUG - 2024-06-18 11:01:45 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-06-18 11:01:45 --> Final output sent to browser
DEBUG - 2024-06-18 11:01:45 --> Total execution time: 0.0310
INFO - 2024-06-18 11:22:51 --> Config Class Initialized
INFO - 2024-06-18 11:22:51 --> Hooks Class Initialized
DEBUG - 2024-06-18 11:22:51 --> UTF-8 Support Enabled
INFO - 2024-06-18 11:22:51 --> Utf8 Class Initialized
INFO - 2024-06-18 11:22:51 --> URI Class Initialized
INFO - 2024-06-18 11:22:51 --> Router Class Initialized
INFO - 2024-06-18 11:22:51 --> Output Class Initialized
INFO - 2024-06-18 11:22:51 --> Security Class Initialized
DEBUG - 2024-06-18 11:22:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-18 11:22:51 --> Input Class Initialized
INFO - 2024-06-18 11:22:51 --> Language Class Initialized
INFO - 2024-06-18 11:22:51 --> Language Class Initialized
INFO - 2024-06-18 11:22:51 --> Config Class Initialized
INFO - 2024-06-18 11:22:51 --> Loader Class Initialized
INFO - 2024-06-18 11:22:51 --> Helper loaded: url_helper
INFO - 2024-06-18 11:22:51 --> Helper loaded: file_helper
INFO - 2024-06-18 11:22:51 --> Helper loaded: form_helper
INFO - 2024-06-18 11:22:51 --> Helper loaded: my_helper
INFO - 2024-06-18 11:22:51 --> Database Driver Class Initialized
INFO - 2024-06-18 11:22:51 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-18 11:22:51 --> Controller Class Initialized
DEBUG - 2024-06-18 11:22:51 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/home/views/v_home_guru.php
DEBUG - 2024-06-18 11:22:51 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-06-18 11:22:51 --> Final output sent to browser
DEBUG - 2024-06-18 11:22:51 --> Total execution time: 0.0315
INFO - 2024-06-18 11:22:54 --> Config Class Initialized
INFO - 2024-06-18 11:22:54 --> Hooks Class Initialized
DEBUG - 2024-06-18 11:22:54 --> UTF-8 Support Enabled
INFO - 2024-06-18 11:22:54 --> Utf8 Class Initialized
INFO - 2024-06-18 11:22:54 --> URI Class Initialized
INFO - 2024-06-18 11:22:54 --> Router Class Initialized
INFO - 2024-06-18 11:22:54 --> Output Class Initialized
INFO - 2024-06-18 11:22:54 --> Security Class Initialized
DEBUG - 2024-06-18 11:22:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-18 11:22:54 --> Input Class Initialized
INFO - 2024-06-18 11:22:54 --> Language Class Initialized
INFO - 2024-06-18 11:22:54 --> Language Class Initialized
INFO - 2024-06-18 11:22:54 --> Config Class Initialized
INFO - 2024-06-18 11:22:54 --> Loader Class Initialized
INFO - 2024-06-18 11:22:54 --> Helper loaded: url_helper
INFO - 2024-06-18 11:22:54 --> Helper loaded: file_helper
INFO - 2024-06-18 11:22:54 --> Helper loaded: form_helper
INFO - 2024-06-18 11:22:54 --> Helper loaded: my_helper
INFO - 2024-06-18 11:22:54 --> Database Driver Class Initialized
INFO - 2024-06-18 11:22:54 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-18 11:22:54 --> Controller Class Initialized
INFO - 2024-06-18 11:22:54 --> Helper loaded: cookie_helper
INFO - 2024-06-18 11:22:54 --> Config Class Initialized
INFO - 2024-06-18 11:22:54 --> Hooks Class Initialized
DEBUG - 2024-06-18 11:22:54 --> UTF-8 Support Enabled
INFO - 2024-06-18 11:22:54 --> Utf8 Class Initialized
INFO - 2024-06-18 11:22:54 --> URI Class Initialized
INFO - 2024-06-18 11:22:54 --> Router Class Initialized
INFO - 2024-06-18 11:22:54 --> Output Class Initialized
INFO - 2024-06-18 11:22:54 --> Security Class Initialized
DEBUG - 2024-06-18 11:22:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-18 11:22:54 --> Input Class Initialized
INFO - 2024-06-18 11:22:54 --> Language Class Initialized
INFO - 2024-06-18 11:22:54 --> Language Class Initialized
INFO - 2024-06-18 11:22:54 --> Config Class Initialized
INFO - 2024-06-18 11:22:54 --> Loader Class Initialized
INFO - 2024-06-18 11:22:54 --> Helper loaded: url_helper
INFO - 2024-06-18 11:22:54 --> Helper loaded: file_helper
INFO - 2024-06-18 11:22:54 --> Helper loaded: form_helper
INFO - 2024-06-18 11:22:54 --> Helper loaded: my_helper
INFO - 2024-06-18 11:22:54 --> Database Driver Class Initialized
INFO - 2024-06-18 11:22:54 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-18 11:22:54 --> Controller Class Initialized
INFO - 2024-06-18 11:22:54 --> Config Class Initialized
INFO - 2024-06-18 11:22:54 --> Hooks Class Initialized
DEBUG - 2024-06-18 11:22:54 --> UTF-8 Support Enabled
INFO - 2024-06-18 11:22:54 --> Utf8 Class Initialized
INFO - 2024-06-18 11:22:54 --> URI Class Initialized
INFO - 2024-06-18 11:22:54 --> Router Class Initialized
INFO - 2024-06-18 11:22:54 --> Output Class Initialized
INFO - 2024-06-18 11:22:54 --> Security Class Initialized
DEBUG - 2024-06-18 11:22:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-18 11:22:54 --> Input Class Initialized
INFO - 2024-06-18 11:22:54 --> Language Class Initialized
INFO - 2024-06-18 11:22:54 --> Language Class Initialized
INFO - 2024-06-18 11:22:54 --> Config Class Initialized
INFO - 2024-06-18 11:22:54 --> Loader Class Initialized
INFO - 2024-06-18 11:22:54 --> Helper loaded: url_helper
INFO - 2024-06-18 11:22:54 --> Helper loaded: file_helper
INFO - 2024-06-18 11:22:54 --> Helper loaded: form_helper
INFO - 2024-06-18 11:22:54 --> Helper loaded: my_helper
INFO - 2024-06-18 11:22:54 --> Database Driver Class Initialized
INFO - 2024-06-18 11:22:54 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-18 11:22:54 --> Controller Class Initialized
DEBUG - 2024-06-18 11:22:54 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/login/views/login.php
DEBUG - 2024-06-18 11:22:54 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-06-18 11:22:54 --> Final output sent to browser
DEBUG - 2024-06-18 11:22:54 --> Total execution time: 0.0309
INFO - 2024-06-18 11:22:58 --> Config Class Initialized
INFO - 2024-06-18 11:22:58 --> Hooks Class Initialized
DEBUG - 2024-06-18 11:22:58 --> UTF-8 Support Enabled
INFO - 2024-06-18 11:22:58 --> Utf8 Class Initialized
INFO - 2024-06-18 11:22:58 --> URI Class Initialized
INFO - 2024-06-18 11:22:58 --> Router Class Initialized
INFO - 2024-06-18 11:22:58 --> Output Class Initialized
INFO - 2024-06-18 11:22:58 --> Security Class Initialized
DEBUG - 2024-06-18 11:22:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-18 11:22:58 --> Input Class Initialized
INFO - 2024-06-18 11:22:58 --> Language Class Initialized
INFO - 2024-06-18 11:22:58 --> Language Class Initialized
INFO - 2024-06-18 11:22:58 --> Config Class Initialized
INFO - 2024-06-18 11:22:58 --> Loader Class Initialized
INFO - 2024-06-18 11:22:58 --> Helper loaded: url_helper
INFO - 2024-06-18 11:22:58 --> Helper loaded: file_helper
INFO - 2024-06-18 11:22:58 --> Helper loaded: form_helper
INFO - 2024-06-18 11:22:58 --> Helper loaded: my_helper
INFO - 2024-06-18 11:22:58 --> Database Driver Class Initialized
INFO - 2024-06-18 11:22:58 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-18 11:22:58 --> Controller Class Initialized
INFO - 2024-06-18 11:22:58 --> Helper loaded: cookie_helper
INFO - 2024-06-18 11:22:58 --> Final output sent to browser
DEBUG - 2024-06-18 11:22:58 --> Total execution time: 0.0279
INFO - 2024-06-18 11:22:59 --> Config Class Initialized
INFO - 2024-06-18 11:22:59 --> Hooks Class Initialized
DEBUG - 2024-06-18 11:22:59 --> UTF-8 Support Enabled
INFO - 2024-06-18 11:22:59 --> Utf8 Class Initialized
INFO - 2024-06-18 11:22:59 --> URI Class Initialized
INFO - 2024-06-18 11:22:59 --> Router Class Initialized
INFO - 2024-06-18 11:22:59 --> Output Class Initialized
INFO - 2024-06-18 11:22:59 --> Security Class Initialized
DEBUG - 2024-06-18 11:22:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-18 11:22:59 --> Input Class Initialized
INFO - 2024-06-18 11:22:59 --> Language Class Initialized
INFO - 2024-06-18 11:22:59 --> Language Class Initialized
INFO - 2024-06-18 11:22:59 --> Config Class Initialized
INFO - 2024-06-18 11:22:59 --> Loader Class Initialized
INFO - 2024-06-18 11:22:59 --> Helper loaded: url_helper
INFO - 2024-06-18 11:22:59 --> Helper loaded: file_helper
INFO - 2024-06-18 11:22:59 --> Helper loaded: form_helper
INFO - 2024-06-18 11:22:59 --> Helper loaded: my_helper
INFO - 2024-06-18 11:22:59 --> Database Driver Class Initialized
INFO - 2024-06-18 11:22:59 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-18 11:22:59 --> Controller Class Initialized
DEBUG - 2024-06-18 11:22:59 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/home/views/v_home_guru.php
DEBUG - 2024-06-18 11:22:59 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-06-18 11:22:59 --> Final output sent to browser
DEBUG - 2024-06-18 11:22:59 --> Total execution time: 0.0262
INFO - 2024-06-18 11:23:05 --> Config Class Initialized
INFO - 2024-06-18 11:23:05 --> Hooks Class Initialized
DEBUG - 2024-06-18 11:23:05 --> UTF-8 Support Enabled
INFO - 2024-06-18 11:23:05 --> Utf8 Class Initialized
INFO - 2024-06-18 11:23:05 --> URI Class Initialized
INFO - 2024-06-18 11:23:05 --> Router Class Initialized
INFO - 2024-06-18 11:23:05 --> Output Class Initialized
INFO - 2024-06-18 11:23:05 --> Security Class Initialized
DEBUG - 2024-06-18 11:23:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-18 11:23:05 --> Input Class Initialized
INFO - 2024-06-18 11:23:05 --> Language Class Initialized
INFO - 2024-06-18 11:23:05 --> Language Class Initialized
INFO - 2024-06-18 11:23:05 --> Config Class Initialized
INFO - 2024-06-18 11:23:05 --> Loader Class Initialized
INFO - 2024-06-18 11:23:05 --> Helper loaded: url_helper
INFO - 2024-06-18 11:23:05 --> Helper loaded: file_helper
INFO - 2024-06-18 11:23:05 --> Helper loaded: form_helper
INFO - 2024-06-18 11:23:05 --> Helper loaded: my_helper
INFO - 2024-06-18 11:23:05 --> Database Driver Class Initialized
INFO - 2024-06-18 11:23:05 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-18 11:23:05 --> Controller Class Initialized
DEBUG - 2024-06-18 11:23:05 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/view_mapel/views/v_view_mapel.php
DEBUG - 2024-06-18 11:23:05 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-06-18 11:23:05 --> Final output sent to browser
DEBUG - 2024-06-18 11:23:05 --> Total execution time: 0.0261
INFO - 2024-06-18 11:23:19 --> Config Class Initialized
INFO - 2024-06-18 11:23:19 --> Hooks Class Initialized
DEBUG - 2024-06-18 11:23:19 --> UTF-8 Support Enabled
INFO - 2024-06-18 11:23:19 --> Utf8 Class Initialized
INFO - 2024-06-18 11:23:19 --> URI Class Initialized
INFO - 2024-06-18 11:23:19 --> Router Class Initialized
INFO - 2024-06-18 11:23:19 --> Output Class Initialized
INFO - 2024-06-18 11:23:19 --> Security Class Initialized
DEBUG - 2024-06-18 11:23:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-18 11:23:19 --> Input Class Initialized
INFO - 2024-06-18 11:23:19 --> Language Class Initialized
INFO - 2024-06-18 11:23:19 --> Language Class Initialized
INFO - 2024-06-18 11:23:19 --> Config Class Initialized
INFO - 2024-06-18 11:23:19 --> Loader Class Initialized
INFO - 2024-06-18 11:23:19 --> Helper loaded: url_helper
INFO - 2024-06-18 11:23:19 --> Helper loaded: file_helper
INFO - 2024-06-18 11:23:19 --> Helper loaded: form_helper
INFO - 2024-06-18 11:23:19 --> Helper loaded: my_helper
INFO - 2024-06-18 11:23:19 --> Database Driver Class Initialized
INFO - 2024-06-18 11:23:19 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-18 11:23:19 --> Controller Class Initialized
DEBUG - 2024-06-18 11:23:19 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/views/list.php
DEBUG - 2024-06-18 11:23:19 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-06-18 11:23:19 --> Final output sent to browser
DEBUG - 2024-06-18 11:23:19 --> Total execution time: 0.0305
INFO - 2024-06-18 11:23:19 --> Config Class Initialized
INFO - 2024-06-18 11:23:19 --> Hooks Class Initialized
DEBUG - 2024-06-18 11:23:19 --> UTF-8 Support Enabled
INFO - 2024-06-18 11:23:19 --> Utf8 Class Initialized
INFO - 2024-06-18 11:23:19 --> URI Class Initialized
INFO - 2024-06-18 11:23:19 --> Router Class Initialized
INFO - 2024-06-18 11:23:19 --> Output Class Initialized
INFO - 2024-06-18 11:23:19 --> Security Class Initialized
DEBUG - 2024-06-18 11:23:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-18 11:23:19 --> Input Class Initialized
INFO - 2024-06-18 11:23:19 --> Language Class Initialized
INFO - 2024-06-18 11:23:19 --> Language Class Initialized
INFO - 2024-06-18 11:23:19 --> Config Class Initialized
INFO - 2024-06-18 11:23:19 --> Loader Class Initialized
INFO - 2024-06-18 11:23:19 --> Helper loaded: url_helper
INFO - 2024-06-18 11:23:19 --> Helper loaded: file_helper
INFO - 2024-06-18 11:23:19 --> Helper loaded: form_helper
INFO - 2024-06-18 11:23:19 --> Helper loaded: my_helper
INFO - 2024-06-18 11:23:19 --> Database Driver Class Initialized
INFO - 2024-06-18 11:23:19 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-18 11:23:19 --> Controller Class Initialized
INFO - 2024-06-18 11:23:24 --> Config Class Initialized
INFO - 2024-06-18 11:23:24 --> Hooks Class Initialized
DEBUG - 2024-06-18 11:23:24 --> UTF-8 Support Enabled
INFO - 2024-06-18 11:23:24 --> Utf8 Class Initialized
INFO - 2024-06-18 11:23:24 --> URI Class Initialized
INFO - 2024-06-18 11:23:24 --> Router Class Initialized
INFO - 2024-06-18 11:23:24 --> Output Class Initialized
INFO - 2024-06-18 11:23:24 --> Security Class Initialized
DEBUG - 2024-06-18 11:23:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-18 11:23:24 --> Input Class Initialized
INFO - 2024-06-18 11:23:24 --> Language Class Initialized
INFO - 2024-06-18 11:23:24 --> Language Class Initialized
INFO - 2024-06-18 11:23:24 --> Config Class Initialized
INFO - 2024-06-18 11:23:24 --> Loader Class Initialized
INFO - 2024-06-18 11:23:24 --> Helper loaded: url_helper
INFO - 2024-06-18 11:23:24 --> Helper loaded: file_helper
INFO - 2024-06-18 11:23:24 --> Helper loaded: form_helper
INFO - 2024-06-18 11:23:24 --> Helper loaded: my_helper
INFO - 2024-06-18 11:23:24 --> Database Driver Class Initialized
INFO - 2024-06-18 11:23:24 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-18 11:23:24 --> Controller Class Initialized
DEBUG - 2024-06-18 11:23:24 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/view_mapel/views/v_view_mapel.php
DEBUG - 2024-06-18 11:23:24 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-06-18 11:23:24 --> Final output sent to browser
DEBUG - 2024-06-18 11:23:24 --> Total execution time: 0.0593
INFO - 2024-06-18 11:23:34 --> Config Class Initialized
INFO - 2024-06-18 11:23:34 --> Hooks Class Initialized
DEBUG - 2024-06-18 11:23:34 --> UTF-8 Support Enabled
INFO - 2024-06-18 11:23:34 --> Utf8 Class Initialized
INFO - 2024-06-18 11:23:34 --> URI Class Initialized
INFO - 2024-06-18 11:23:34 --> Router Class Initialized
INFO - 2024-06-18 11:23:34 --> Output Class Initialized
INFO - 2024-06-18 11:23:34 --> Security Class Initialized
DEBUG - 2024-06-18 11:23:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-18 11:23:34 --> Input Class Initialized
INFO - 2024-06-18 11:23:34 --> Language Class Initialized
INFO - 2024-06-18 11:23:34 --> Language Class Initialized
INFO - 2024-06-18 11:23:34 --> Config Class Initialized
INFO - 2024-06-18 11:23:34 --> Loader Class Initialized
INFO - 2024-06-18 11:23:34 --> Helper loaded: url_helper
INFO - 2024-06-18 11:23:34 --> Helper loaded: file_helper
INFO - 2024-06-18 11:23:34 --> Helper loaded: form_helper
INFO - 2024-06-18 11:23:34 --> Helper loaded: my_helper
INFO - 2024-06-18 11:23:34 --> Database Driver Class Initialized
INFO - 2024-06-18 11:23:34 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-18 11:23:34 --> Controller Class Initialized
DEBUG - 2024-06-18 11:23:34 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/views/list.php
DEBUG - 2024-06-18 11:23:34 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-06-18 11:23:34 --> Final output sent to browser
DEBUG - 2024-06-18 11:23:34 --> Total execution time: 0.0309
INFO - 2024-06-18 11:23:35 --> Config Class Initialized
INFO - 2024-06-18 11:23:35 --> Hooks Class Initialized
DEBUG - 2024-06-18 11:23:35 --> UTF-8 Support Enabled
INFO - 2024-06-18 11:23:35 --> Utf8 Class Initialized
INFO - 2024-06-18 11:23:35 --> URI Class Initialized
INFO - 2024-06-18 11:23:35 --> Router Class Initialized
INFO - 2024-06-18 11:23:35 --> Output Class Initialized
INFO - 2024-06-18 11:23:35 --> Security Class Initialized
DEBUG - 2024-06-18 11:23:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-18 11:23:35 --> Input Class Initialized
INFO - 2024-06-18 11:23:35 --> Language Class Initialized
INFO - 2024-06-18 11:23:35 --> Language Class Initialized
INFO - 2024-06-18 11:23:35 --> Config Class Initialized
INFO - 2024-06-18 11:23:35 --> Loader Class Initialized
INFO - 2024-06-18 11:23:35 --> Helper loaded: url_helper
INFO - 2024-06-18 11:23:35 --> Helper loaded: file_helper
INFO - 2024-06-18 11:23:35 --> Helper loaded: form_helper
INFO - 2024-06-18 11:23:35 --> Helper loaded: my_helper
INFO - 2024-06-18 11:23:35 --> Database Driver Class Initialized
INFO - 2024-06-18 11:23:35 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-18 11:23:35 --> Controller Class Initialized
INFO - 2024-06-18 11:23:39 --> Config Class Initialized
INFO - 2024-06-18 11:23:39 --> Hooks Class Initialized
DEBUG - 2024-06-18 11:23:39 --> UTF-8 Support Enabled
INFO - 2024-06-18 11:23:39 --> Utf8 Class Initialized
INFO - 2024-06-18 11:23:39 --> URI Class Initialized
INFO - 2024-06-18 11:23:39 --> Router Class Initialized
INFO - 2024-06-18 11:23:39 --> Output Class Initialized
INFO - 2024-06-18 11:23:39 --> Security Class Initialized
DEBUG - 2024-06-18 11:23:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-18 11:23:39 --> Input Class Initialized
INFO - 2024-06-18 11:23:39 --> Language Class Initialized
INFO - 2024-06-18 11:23:39 --> Language Class Initialized
INFO - 2024-06-18 11:23:39 --> Config Class Initialized
INFO - 2024-06-18 11:23:39 --> Loader Class Initialized
INFO - 2024-06-18 11:23:39 --> Helper loaded: url_helper
INFO - 2024-06-18 11:23:39 --> Helper loaded: file_helper
INFO - 2024-06-18 11:23:39 --> Helper loaded: form_helper
INFO - 2024-06-18 11:23:39 --> Helper loaded: my_helper
INFO - 2024-06-18 11:23:39 --> Database Driver Class Initialized
INFO - 2024-06-18 11:23:39 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-18 11:23:39 --> Controller Class Initialized
DEBUG - 2024-06-18 11:23:39 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/view_mapel/views/v_view_mapel.php
DEBUG - 2024-06-18 11:23:39 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-06-18 11:23:39 --> Final output sent to browser
DEBUG - 2024-06-18 11:23:39 --> Total execution time: 0.0252
INFO - 2024-06-18 11:23:48 --> Config Class Initialized
INFO - 2024-06-18 11:23:48 --> Hooks Class Initialized
DEBUG - 2024-06-18 11:23:48 --> UTF-8 Support Enabled
INFO - 2024-06-18 11:23:48 --> Utf8 Class Initialized
INFO - 2024-06-18 11:23:48 --> URI Class Initialized
INFO - 2024-06-18 11:23:48 --> Router Class Initialized
INFO - 2024-06-18 11:23:48 --> Output Class Initialized
INFO - 2024-06-18 11:23:48 --> Security Class Initialized
DEBUG - 2024-06-18 11:23:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-18 11:23:48 --> Input Class Initialized
INFO - 2024-06-18 11:23:48 --> Language Class Initialized
INFO - 2024-06-18 11:23:48 --> Language Class Initialized
INFO - 2024-06-18 11:23:48 --> Config Class Initialized
INFO - 2024-06-18 11:23:48 --> Loader Class Initialized
INFO - 2024-06-18 11:23:48 --> Helper loaded: url_helper
INFO - 2024-06-18 11:23:48 --> Helper loaded: file_helper
INFO - 2024-06-18 11:23:49 --> Helper loaded: form_helper
INFO - 2024-06-18 11:23:49 --> Helper loaded: my_helper
INFO - 2024-06-18 11:23:49 --> Database Driver Class Initialized
INFO - 2024-06-18 11:23:49 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-18 11:23:49 --> Controller Class Initialized
DEBUG - 2024-06-18 11:23:49 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_icb/views/list.php
DEBUG - 2024-06-18 11:23:49 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-06-18 11:23:49 --> Final output sent to browser
DEBUG - 2024-06-18 11:23:49 --> Total execution time: 0.0399
INFO - 2024-06-18 11:23:49 --> Config Class Initialized
INFO - 2024-06-18 11:23:49 --> Hooks Class Initialized
DEBUG - 2024-06-18 11:23:49 --> UTF-8 Support Enabled
INFO - 2024-06-18 11:23:49 --> Utf8 Class Initialized
INFO - 2024-06-18 11:23:49 --> URI Class Initialized
INFO - 2024-06-18 11:23:49 --> Router Class Initialized
INFO - 2024-06-18 11:23:49 --> Output Class Initialized
INFO - 2024-06-18 11:23:49 --> Security Class Initialized
DEBUG - 2024-06-18 11:23:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-18 11:23:49 --> Input Class Initialized
INFO - 2024-06-18 11:23:49 --> Language Class Initialized
INFO - 2024-06-18 11:23:49 --> Language Class Initialized
INFO - 2024-06-18 11:23:49 --> Config Class Initialized
INFO - 2024-06-18 11:23:49 --> Loader Class Initialized
INFO - 2024-06-18 11:23:49 --> Helper loaded: url_helper
INFO - 2024-06-18 11:23:49 --> Helper loaded: file_helper
INFO - 2024-06-18 11:23:49 --> Helper loaded: form_helper
INFO - 2024-06-18 11:23:49 --> Helper loaded: my_helper
INFO - 2024-06-18 11:23:49 --> Database Driver Class Initialized
INFO - 2024-06-18 11:23:49 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-18 11:23:49 --> Controller Class Initialized
INFO - 2024-06-18 11:23:54 --> Config Class Initialized
INFO - 2024-06-18 11:23:54 --> Hooks Class Initialized
DEBUG - 2024-06-18 11:23:54 --> UTF-8 Support Enabled
INFO - 2024-06-18 11:23:54 --> Utf8 Class Initialized
INFO - 2024-06-18 11:23:54 --> URI Class Initialized
INFO - 2024-06-18 11:23:54 --> Router Class Initialized
INFO - 2024-06-18 11:23:54 --> Output Class Initialized
INFO - 2024-06-18 11:23:54 --> Security Class Initialized
DEBUG - 2024-06-18 11:23:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-18 11:23:54 --> Input Class Initialized
INFO - 2024-06-18 11:23:54 --> Language Class Initialized
INFO - 2024-06-18 11:23:54 --> Language Class Initialized
INFO - 2024-06-18 11:23:54 --> Config Class Initialized
INFO - 2024-06-18 11:23:54 --> Loader Class Initialized
INFO - 2024-06-18 11:23:54 --> Helper loaded: url_helper
INFO - 2024-06-18 11:23:54 --> Helper loaded: file_helper
INFO - 2024-06-18 11:23:54 --> Helper loaded: form_helper
INFO - 2024-06-18 11:23:54 --> Helper loaded: my_helper
INFO - 2024-06-18 11:23:54 --> Database Driver Class Initialized
INFO - 2024-06-18 11:23:54 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-18 11:23:54 --> Controller Class Initialized
DEBUG - 2024-06-18 11:23:54 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/view_mapel/views/v_view_mapel.php
DEBUG - 2024-06-18 11:23:54 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-06-18 11:23:54 --> Final output sent to browser
DEBUG - 2024-06-18 11:23:54 --> Total execution time: 0.0674
INFO - 2024-06-18 11:24:17 --> Config Class Initialized
INFO - 2024-06-18 11:24:17 --> Hooks Class Initialized
DEBUG - 2024-06-18 11:24:17 --> UTF-8 Support Enabled
INFO - 2024-06-18 11:24:17 --> Utf8 Class Initialized
INFO - 2024-06-18 11:24:17 --> URI Class Initialized
INFO - 2024-06-18 11:24:17 --> Router Class Initialized
INFO - 2024-06-18 11:24:17 --> Output Class Initialized
INFO - 2024-06-18 11:24:17 --> Security Class Initialized
DEBUG - 2024-06-18 11:24:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-18 11:24:17 --> Input Class Initialized
INFO - 2024-06-18 11:24:17 --> Language Class Initialized
INFO - 2024-06-18 11:24:17 --> Language Class Initialized
INFO - 2024-06-18 11:24:17 --> Config Class Initialized
INFO - 2024-06-18 11:24:17 --> Loader Class Initialized
INFO - 2024-06-18 11:24:17 --> Helper loaded: url_helper
INFO - 2024-06-18 11:24:17 --> Helper loaded: file_helper
INFO - 2024-06-18 11:24:17 --> Helper loaded: form_helper
INFO - 2024-06-18 11:24:17 --> Helper loaded: my_helper
INFO - 2024-06-18 11:24:17 --> Database Driver Class Initialized
INFO - 2024-06-18 11:24:17 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-18 11:24:17 --> Controller Class Initialized
DEBUG - 2024-06-18 11:24:17 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/views/list.php
DEBUG - 2024-06-18 11:24:17 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-06-18 11:24:17 --> Final output sent to browser
DEBUG - 2024-06-18 11:24:17 --> Total execution time: 0.0332
INFO - 2024-06-18 11:24:17 --> Config Class Initialized
INFO - 2024-06-18 11:24:17 --> Hooks Class Initialized
DEBUG - 2024-06-18 11:24:17 --> UTF-8 Support Enabled
INFO - 2024-06-18 11:24:17 --> Utf8 Class Initialized
INFO - 2024-06-18 11:24:17 --> URI Class Initialized
INFO - 2024-06-18 11:24:17 --> Router Class Initialized
INFO - 2024-06-18 11:24:17 --> Output Class Initialized
INFO - 2024-06-18 11:24:17 --> Security Class Initialized
DEBUG - 2024-06-18 11:24:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-18 11:24:17 --> Input Class Initialized
INFO - 2024-06-18 11:24:17 --> Language Class Initialized
INFO - 2024-06-18 11:24:17 --> Language Class Initialized
INFO - 2024-06-18 11:24:17 --> Config Class Initialized
INFO - 2024-06-18 11:24:17 --> Loader Class Initialized
INFO - 2024-06-18 11:24:17 --> Helper loaded: url_helper
INFO - 2024-06-18 11:24:17 --> Helper loaded: file_helper
INFO - 2024-06-18 11:24:17 --> Helper loaded: form_helper
INFO - 2024-06-18 11:24:17 --> Helper loaded: my_helper
INFO - 2024-06-18 11:24:17 --> Database Driver Class Initialized
INFO - 2024-06-18 11:24:17 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-18 11:24:17 --> Controller Class Initialized
INFO - 2024-06-18 11:24:39 --> Config Class Initialized
INFO - 2024-06-18 11:24:39 --> Hooks Class Initialized
DEBUG - 2024-06-18 11:24:39 --> UTF-8 Support Enabled
INFO - 2024-06-18 11:24:39 --> Utf8 Class Initialized
INFO - 2024-06-18 11:24:39 --> URI Class Initialized
INFO - 2024-06-18 11:24:39 --> Router Class Initialized
INFO - 2024-06-18 11:24:39 --> Output Class Initialized
INFO - 2024-06-18 11:24:39 --> Security Class Initialized
DEBUG - 2024-06-18 11:24:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-18 11:24:39 --> Input Class Initialized
INFO - 2024-06-18 11:24:39 --> Language Class Initialized
INFO - 2024-06-18 11:24:39 --> Language Class Initialized
INFO - 2024-06-18 11:24:39 --> Config Class Initialized
INFO - 2024-06-18 11:24:39 --> Loader Class Initialized
INFO - 2024-06-18 11:24:39 --> Helper loaded: url_helper
INFO - 2024-06-18 11:24:39 --> Helper loaded: file_helper
INFO - 2024-06-18 11:24:39 --> Helper loaded: form_helper
INFO - 2024-06-18 11:24:39 --> Helper loaded: my_helper
INFO - 2024-06-18 11:24:39 --> Database Driver Class Initialized
INFO - 2024-06-18 11:24:39 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-18 11:24:39 --> Controller Class Initialized
INFO - 2024-06-18 11:24:39 --> Final output sent to browser
DEBUG - 2024-06-18 11:24:39 --> Total execution time: 0.0529
INFO - 2024-06-18 11:24:41 --> Config Class Initialized
INFO - 2024-06-18 11:24:41 --> Hooks Class Initialized
DEBUG - 2024-06-18 11:24:41 --> UTF-8 Support Enabled
INFO - 2024-06-18 11:24:41 --> Utf8 Class Initialized
INFO - 2024-06-18 11:24:41 --> URI Class Initialized
INFO - 2024-06-18 11:24:41 --> Router Class Initialized
INFO - 2024-06-18 11:24:41 --> Output Class Initialized
INFO - 2024-06-18 11:24:41 --> Security Class Initialized
DEBUG - 2024-06-18 11:24:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-18 11:24:41 --> Input Class Initialized
INFO - 2024-06-18 11:24:41 --> Language Class Initialized
INFO - 2024-06-18 11:24:41 --> Language Class Initialized
INFO - 2024-06-18 11:24:41 --> Config Class Initialized
INFO - 2024-06-18 11:24:41 --> Loader Class Initialized
INFO - 2024-06-18 11:24:41 --> Helper loaded: url_helper
INFO - 2024-06-18 11:24:41 --> Helper loaded: file_helper
INFO - 2024-06-18 11:24:41 --> Helper loaded: form_helper
INFO - 2024-06-18 11:24:41 --> Helper loaded: my_helper
INFO - 2024-06-18 11:24:41 --> Database Driver Class Initialized
INFO - 2024-06-18 11:24:41 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-18 11:24:41 --> Controller Class Initialized
INFO - 2024-06-18 11:24:41 --> Final output sent to browser
DEBUG - 2024-06-18 11:24:41 --> Total execution time: 0.0289
INFO - 2024-06-18 11:25:55 --> Config Class Initialized
INFO - 2024-06-18 11:25:55 --> Hooks Class Initialized
DEBUG - 2024-06-18 11:25:55 --> UTF-8 Support Enabled
INFO - 2024-06-18 11:25:55 --> Utf8 Class Initialized
INFO - 2024-06-18 11:25:55 --> URI Class Initialized
INFO - 2024-06-18 11:25:55 --> Router Class Initialized
INFO - 2024-06-18 11:25:55 --> Output Class Initialized
INFO - 2024-06-18 11:25:55 --> Security Class Initialized
DEBUG - 2024-06-18 11:25:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-18 11:25:55 --> Input Class Initialized
INFO - 2024-06-18 11:25:55 --> Language Class Initialized
INFO - 2024-06-18 11:25:55 --> Language Class Initialized
INFO - 2024-06-18 11:25:55 --> Config Class Initialized
INFO - 2024-06-18 11:25:55 --> Loader Class Initialized
INFO - 2024-06-18 11:25:55 --> Helper loaded: url_helper
INFO - 2024-06-18 11:25:55 --> Helper loaded: file_helper
INFO - 2024-06-18 11:25:55 --> Helper loaded: form_helper
INFO - 2024-06-18 11:25:55 --> Helper loaded: my_helper
INFO - 2024-06-18 11:25:55 --> Database Driver Class Initialized
INFO - 2024-06-18 11:25:55 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-18 11:25:55 --> Controller Class Initialized
INFO - 2024-06-18 11:25:55 --> Final output sent to browser
DEBUG - 2024-06-18 11:25:55 --> Total execution time: 0.0263
INFO - 2024-06-18 11:26:00 --> Config Class Initialized
INFO - 2024-06-18 11:26:00 --> Hooks Class Initialized
DEBUG - 2024-06-18 11:26:00 --> UTF-8 Support Enabled
INFO - 2024-06-18 11:26:00 --> Utf8 Class Initialized
INFO - 2024-06-18 11:26:00 --> URI Class Initialized
INFO - 2024-06-18 11:26:00 --> Router Class Initialized
INFO - 2024-06-18 11:26:00 --> Output Class Initialized
INFO - 2024-06-18 11:26:00 --> Security Class Initialized
DEBUG - 2024-06-18 11:26:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-18 11:26:00 --> Input Class Initialized
INFO - 2024-06-18 11:26:00 --> Language Class Initialized
INFO - 2024-06-18 11:26:00 --> Language Class Initialized
INFO - 2024-06-18 11:26:00 --> Config Class Initialized
INFO - 2024-06-18 11:26:00 --> Loader Class Initialized
INFO - 2024-06-18 11:26:00 --> Helper loaded: url_helper
INFO - 2024-06-18 11:26:00 --> Helper loaded: file_helper
INFO - 2024-06-18 11:26:00 --> Helper loaded: form_helper
INFO - 2024-06-18 11:26:00 --> Helper loaded: my_helper
INFO - 2024-06-18 11:26:00 --> Database Driver Class Initialized
INFO - 2024-06-18 11:26:00 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-18 11:26:00 --> Controller Class Initialized
INFO - 2024-06-18 11:26:00 --> Final output sent to browser
DEBUG - 2024-06-18 11:26:00 --> Total execution time: 0.0295
INFO - 2024-06-18 11:30:32 --> Config Class Initialized
INFO - 2024-06-18 11:30:32 --> Hooks Class Initialized
DEBUG - 2024-06-18 11:30:32 --> UTF-8 Support Enabled
INFO - 2024-06-18 11:30:32 --> Utf8 Class Initialized
INFO - 2024-06-18 11:30:32 --> URI Class Initialized
INFO - 2024-06-18 11:30:32 --> Router Class Initialized
INFO - 2024-06-18 11:30:32 --> Output Class Initialized
INFO - 2024-06-18 11:30:32 --> Security Class Initialized
DEBUG - 2024-06-18 11:30:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-18 11:30:32 --> Input Class Initialized
INFO - 2024-06-18 11:30:32 --> Language Class Initialized
INFO - 2024-06-18 11:30:32 --> Language Class Initialized
INFO - 2024-06-18 11:30:32 --> Config Class Initialized
INFO - 2024-06-18 11:30:32 --> Loader Class Initialized
INFO - 2024-06-18 11:30:32 --> Helper loaded: url_helper
INFO - 2024-06-18 11:30:32 --> Helper loaded: file_helper
INFO - 2024-06-18 11:30:32 --> Helper loaded: form_helper
INFO - 2024-06-18 11:30:32 --> Helper loaded: my_helper
INFO - 2024-06-18 11:30:32 --> Database Driver Class Initialized
INFO - 2024-06-18 11:30:32 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-18 11:30:32 --> Controller Class Initialized
INFO - 2024-06-18 11:30:32 --> Final output sent to browser
DEBUG - 2024-06-18 11:30:32 --> Total execution time: 0.1155
INFO - 2024-06-18 11:31:04 --> Config Class Initialized
INFO - 2024-06-18 11:31:04 --> Hooks Class Initialized
DEBUG - 2024-06-18 11:31:04 --> UTF-8 Support Enabled
INFO - 2024-06-18 11:31:04 --> Utf8 Class Initialized
INFO - 2024-06-18 11:31:04 --> URI Class Initialized
INFO - 2024-06-18 11:31:04 --> Router Class Initialized
INFO - 2024-06-18 11:31:04 --> Output Class Initialized
INFO - 2024-06-18 11:31:04 --> Security Class Initialized
DEBUG - 2024-06-18 11:31:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-18 11:31:04 --> Input Class Initialized
INFO - 2024-06-18 11:31:04 --> Language Class Initialized
INFO - 2024-06-18 11:31:04 --> Language Class Initialized
INFO - 2024-06-18 11:31:04 --> Config Class Initialized
INFO - 2024-06-18 11:31:04 --> Loader Class Initialized
INFO - 2024-06-18 11:31:04 --> Helper loaded: url_helper
INFO - 2024-06-18 11:31:04 --> Helper loaded: file_helper
INFO - 2024-06-18 11:31:04 --> Helper loaded: form_helper
INFO - 2024-06-18 11:31:04 --> Helper loaded: my_helper
INFO - 2024-06-18 11:31:04 --> Database Driver Class Initialized
INFO - 2024-06-18 11:31:04 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-18 11:31:04 --> Controller Class Initialized
INFO - 2024-06-18 11:31:04 --> Final output sent to browser
DEBUG - 2024-06-18 11:31:04 --> Total execution time: 0.2666
INFO - 2024-06-18 11:31:47 --> Config Class Initialized
INFO - 2024-06-18 11:31:47 --> Hooks Class Initialized
DEBUG - 2024-06-18 11:31:47 --> UTF-8 Support Enabled
INFO - 2024-06-18 11:31:47 --> Utf8 Class Initialized
INFO - 2024-06-18 11:31:47 --> URI Class Initialized
INFO - 2024-06-18 11:31:47 --> Router Class Initialized
INFO - 2024-06-18 11:31:47 --> Output Class Initialized
INFO - 2024-06-18 11:31:47 --> Security Class Initialized
DEBUG - 2024-06-18 11:31:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-18 11:31:47 --> Input Class Initialized
INFO - 2024-06-18 11:31:47 --> Language Class Initialized
INFO - 2024-06-18 11:31:47 --> Language Class Initialized
INFO - 2024-06-18 11:31:47 --> Config Class Initialized
INFO - 2024-06-18 11:31:47 --> Loader Class Initialized
INFO - 2024-06-18 11:31:47 --> Helper loaded: url_helper
INFO - 2024-06-18 11:31:47 --> Helper loaded: file_helper
INFO - 2024-06-18 11:31:47 --> Helper loaded: form_helper
INFO - 2024-06-18 11:31:47 --> Helper loaded: my_helper
INFO - 2024-06-18 11:31:47 --> Database Driver Class Initialized
INFO - 2024-06-18 11:31:47 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-18 11:31:47 --> Controller Class Initialized
INFO - 2024-06-18 11:31:48 --> Final output sent to browser
DEBUG - 2024-06-18 11:31:48 --> Total execution time: 0.1115
INFO - 2024-06-18 11:32:17 --> Config Class Initialized
INFO - 2024-06-18 11:32:17 --> Hooks Class Initialized
DEBUG - 2024-06-18 11:32:17 --> UTF-8 Support Enabled
INFO - 2024-06-18 11:32:17 --> Utf8 Class Initialized
INFO - 2024-06-18 11:32:17 --> URI Class Initialized
INFO - 2024-06-18 11:32:17 --> Router Class Initialized
INFO - 2024-06-18 11:32:17 --> Output Class Initialized
INFO - 2024-06-18 11:32:17 --> Security Class Initialized
DEBUG - 2024-06-18 11:32:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-18 11:32:17 --> Input Class Initialized
INFO - 2024-06-18 11:32:17 --> Language Class Initialized
INFO - 2024-06-18 11:32:17 --> Language Class Initialized
INFO - 2024-06-18 11:32:17 --> Config Class Initialized
INFO - 2024-06-18 11:32:17 --> Loader Class Initialized
INFO - 2024-06-18 11:32:17 --> Helper loaded: url_helper
INFO - 2024-06-18 11:32:17 --> Helper loaded: file_helper
INFO - 2024-06-18 11:32:17 --> Helper loaded: form_helper
INFO - 2024-06-18 11:32:17 --> Helper loaded: my_helper
INFO - 2024-06-18 11:32:17 --> Database Driver Class Initialized
INFO - 2024-06-18 11:32:17 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-18 11:32:17 --> Controller Class Initialized
INFO - 2024-06-18 11:32:17 --> Final output sent to browser
DEBUG - 2024-06-18 11:32:17 --> Total execution time: 0.1134
INFO - 2024-06-18 11:33:06 --> Config Class Initialized
INFO - 2024-06-18 11:33:06 --> Hooks Class Initialized
DEBUG - 2024-06-18 11:33:06 --> UTF-8 Support Enabled
INFO - 2024-06-18 11:33:06 --> Utf8 Class Initialized
INFO - 2024-06-18 11:33:06 --> URI Class Initialized
INFO - 2024-06-18 11:33:06 --> Router Class Initialized
INFO - 2024-06-18 11:33:06 --> Output Class Initialized
INFO - 2024-06-18 11:33:06 --> Security Class Initialized
DEBUG - 2024-06-18 11:33:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-18 11:33:06 --> Input Class Initialized
INFO - 2024-06-18 11:33:06 --> Language Class Initialized
INFO - 2024-06-18 11:33:06 --> Language Class Initialized
INFO - 2024-06-18 11:33:06 --> Config Class Initialized
INFO - 2024-06-18 11:33:06 --> Loader Class Initialized
INFO - 2024-06-18 11:33:06 --> Helper loaded: url_helper
INFO - 2024-06-18 11:33:06 --> Helper loaded: file_helper
INFO - 2024-06-18 11:33:06 --> Helper loaded: form_helper
INFO - 2024-06-18 11:33:06 --> Helper loaded: my_helper
INFO - 2024-06-18 11:33:06 --> Database Driver Class Initialized
INFO - 2024-06-18 11:33:06 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-18 11:33:06 --> Controller Class Initialized
INFO - 2024-06-18 11:33:06 --> Final output sent to browser
DEBUG - 2024-06-18 11:33:06 --> Total execution time: 0.0997
INFO - 2024-06-18 11:33:11 --> Config Class Initialized
INFO - 2024-06-18 11:33:11 --> Hooks Class Initialized
DEBUG - 2024-06-18 11:33:11 --> UTF-8 Support Enabled
INFO - 2024-06-18 11:33:11 --> Utf8 Class Initialized
INFO - 2024-06-18 11:33:11 --> URI Class Initialized
INFO - 2024-06-18 11:33:11 --> Router Class Initialized
INFO - 2024-06-18 11:33:11 --> Output Class Initialized
INFO - 2024-06-18 11:33:11 --> Security Class Initialized
DEBUG - 2024-06-18 11:33:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-18 11:33:11 --> Input Class Initialized
INFO - 2024-06-18 11:33:11 --> Language Class Initialized
INFO - 2024-06-18 11:33:11 --> Language Class Initialized
INFO - 2024-06-18 11:33:11 --> Config Class Initialized
INFO - 2024-06-18 11:33:11 --> Loader Class Initialized
INFO - 2024-06-18 11:33:11 --> Helper loaded: url_helper
INFO - 2024-06-18 11:33:11 --> Helper loaded: file_helper
INFO - 2024-06-18 11:33:11 --> Helper loaded: form_helper
INFO - 2024-06-18 11:33:11 --> Helper loaded: my_helper
INFO - 2024-06-18 11:33:11 --> Database Driver Class Initialized
INFO - 2024-06-18 11:33:11 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-18 11:33:11 --> Controller Class Initialized
INFO - 2024-06-18 11:33:11 --> Final output sent to browser
DEBUG - 2024-06-18 11:33:11 --> Total execution time: 0.0281
INFO - 2024-06-18 11:34:45 --> Config Class Initialized
INFO - 2024-06-18 11:34:45 --> Hooks Class Initialized
DEBUG - 2024-06-18 11:34:45 --> UTF-8 Support Enabled
INFO - 2024-06-18 11:34:45 --> Utf8 Class Initialized
INFO - 2024-06-18 11:34:45 --> URI Class Initialized
INFO - 2024-06-18 11:34:45 --> Router Class Initialized
INFO - 2024-06-18 11:34:45 --> Output Class Initialized
INFO - 2024-06-18 11:34:45 --> Security Class Initialized
DEBUG - 2024-06-18 11:34:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-18 11:34:45 --> Input Class Initialized
INFO - 2024-06-18 11:34:45 --> Language Class Initialized
INFO - 2024-06-18 11:34:45 --> Language Class Initialized
INFO - 2024-06-18 11:34:45 --> Config Class Initialized
INFO - 2024-06-18 11:34:45 --> Loader Class Initialized
INFO - 2024-06-18 11:34:45 --> Helper loaded: url_helper
INFO - 2024-06-18 11:34:45 --> Helper loaded: file_helper
INFO - 2024-06-18 11:34:45 --> Helper loaded: form_helper
INFO - 2024-06-18 11:34:45 --> Helper loaded: my_helper
INFO - 2024-06-18 11:34:45 --> Database Driver Class Initialized
INFO - 2024-06-18 11:34:45 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-18 11:34:45 --> Controller Class Initialized
INFO - 2024-06-18 11:34:45 --> Final output sent to browser
DEBUG - 2024-06-18 11:34:45 --> Total execution time: 0.1157
INFO - 2024-06-18 11:34:51 --> Config Class Initialized
INFO - 2024-06-18 11:34:51 --> Hooks Class Initialized
DEBUG - 2024-06-18 11:34:51 --> UTF-8 Support Enabled
INFO - 2024-06-18 11:34:51 --> Utf8 Class Initialized
INFO - 2024-06-18 11:34:51 --> URI Class Initialized
INFO - 2024-06-18 11:34:51 --> Router Class Initialized
INFO - 2024-06-18 11:34:51 --> Output Class Initialized
INFO - 2024-06-18 11:34:51 --> Security Class Initialized
DEBUG - 2024-06-18 11:34:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-18 11:34:51 --> Input Class Initialized
INFO - 2024-06-18 11:34:51 --> Language Class Initialized
INFO - 2024-06-18 11:34:51 --> Language Class Initialized
INFO - 2024-06-18 11:34:51 --> Config Class Initialized
INFO - 2024-06-18 11:34:51 --> Loader Class Initialized
INFO - 2024-06-18 11:34:51 --> Helper loaded: url_helper
INFO - 2024-06-18 11:34:51 --> Helper loaded: file_helper
INFO - 2024-06-18 11:34:51 --> Helper loaded: form_helper
INFO - 2024-06-18 11:34:51 --> Helper loaded: my_helper
INFO - 2024-06-18 11:34:51 --> Database Driver Class Initialized
INFO - 2024-06-18 11:34:51 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-18 11:34:51 --> Controller Class Initialized
INFO - 2024-06-18 11:34:51 --> Final output sent to browser
DEBUG - 2024-06-18 11:34:51 --> Total execution time: 0.0507
INFO - 2024-06-18 11:35:01 --> Config Class Initialized
INFO - 2024-06-18 11:35:01 --> Hooks Class Initialized
DEBUG - 2024-06-18 11:35:01 --> UTF-8 Support Enabled
INFO - 2024-06-18 11:35:01 --> Utf8 Class Initialized
INFO - 2024-06-18 11:35:01 --> URI Class Initialized
INFO - 2024-06-18 11:35:01 --> Router Class Initialized
INFO - 2024-06-18 11:35:01 --> Output Class Initialized
INFO - 2024-06-18 11:35:01 --> Security Class Initialized
DEBUG - 2024-06-18 11:35:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-18 11:35:01 --> Input Class Initialized
INFO - 2024-06-18 11:35:01 --> Language Class Initialized
INFO - 2024-06-18 11:35:01 --> Language Class Initialized
INFO - 2024-06-18 11:35:01 --> Config Class Initialized
INFO - 2024-06-18 11:35:01 --> Loader Class Initialized
INFO - 2024-06-18 11:35:01 --> Helper loaded: url_helper
INFO - 2024-06-18 11:35:01 --> Helper loaded: file_helper
INFO - 2024-06-18 11:35:01 --> Helper loaded: form_helper
INFO - 2024-06-18 11:35:01 --> Helper loaded: my_helper
INFO - 2024-06-18 11:35:01 --> Database Driver Class Initialized
INFO - 2024-06-18 11:35:01 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-18 11:35:01 --> Controller Class Initialized
INFO - 2024-06-18 11:35:01 --> Final output sent to browser
DEBUG - 2024-06-18 11:35:01 --> Total execution time: 0.1378
INFO - 2024-06-18 11:35:07 --> Config Class Initialized
INFO - 2024-06-18 11:35:07 --> Hooks Class Initialized
DEBUG - 2024-06-18 11:35:07 --> UTF-8 Support Enabled
INFO - 2024-06-18 11:35:07 --> Utf8 Class Initialized
INFO - 2024-06-18 11:35:07 --> URI Class Initialized
INFO - 2024-06-18 11:35:07 --> Router Class Initialized
INFO - 2024-06-18 11:35:07 --> Output Class Initialized
INFO - 2024-06-18 11:35:07 --> Security Class Initialized
DEBUG - 2024-06-18 11:35:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-18 11:35:07 --> Input Class Initialized
INFO - 2024-06-18 11:35:07 --> Language Class Initialized
INFO - 2024-06-18 11:35:07 --> Language Class Initialized
INFO - 2024-06-18 11:35:07 --> Config Class Initialized
INFO - 2024-06-18 11:35:07 --> Loader Class Initialized
INFO - 2024-06-18 11:35:07 --> Helper loaded: url_helper
INFO - 2024-06-18 11:35:07 --> Helper loaded: file_helper
INFO - 2024-06-18 11:35:07 --> Helper loaded: form_helper
INFO - 2024-06-18 11:35:07 --> Helper loaded: my_helper
INFO - 2024-06-18 11:35:07 --> Database Driver Class Initialized
INFO - 2024-06-18 11:35:07 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-18 11:35:07 --> Controller Class Initialized
INFO - 2024-06-18 11:35:07 --> Final output sent to browser
DEBUG - 2024-06-18 11:35:07 --> Total execution time: 0.1055
INFO - 2024-06-18 11:35:30 --> Config Class Initialized
INFO - 2024-06-18 11:35:30 --> Hooks Class Initialized
DEBUG - 2024-06-18 11:35:30 --> UTF-8 Support Enabled
INFO - 2024-06-18 11:35:30 --> Utf8 Class Initialized
INFO - 2024-06-18 11:35:30 --> URI Class Initialized
INFO - 2024-06-18 11:35:30 --> Router Class Initialized
INFO - 2024-06-18 11:35:30 --> Output Class Initialized
INFO - 2024-06-18 11:35:30 --> Security Class Initialized
DEBUG - 2024-06-18 11:35:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-18 11:35:30 --> Input Class Initialized
INFO - 2024-06-18 11:35:30 --> Language Class Initialized
INFO - 2024-06-18 11:35:30 --> Language Class Initialized
INFO - 2024-06-18 11:35:30 --> Config Class Initialized
INFO - 2024-06-18 11:35:30 --> Loader Class Initialized
INFO - 2024-06-18 11:35:30 --> Helper loaded: url_helper
INFO - 2024-06-18 11:35:30 --> Helper loaded: file_helper
INFO - 2024-06-18 11:35:30 --> Helper loaded: form_helper
INFO - 2024-06-18 11:35:30 --> Helper loaded: my_helper
INFO - 2024-06-18 11:35:30 --> Database Driver Class Initialized
INFO - 2024-06-18 11:35:30 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-18 11:35:30 --> Controller Class Initialized
DEBUG - 2024-06-18 11:35:30 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/view_mapel/views/v_view_mapel.php
DEBUG - 2024-06-18 11:35:30 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-06-18 11:35:30 --> Final output sent to browser
DEBUG - 2024-06-18 11:35:30 --> Total execution time: 0.0257
INFO - 2024-06-18 11:35:35 --> Config Class Initialized
INFO - 2024-06-18 11:35:35 --> Hooks Class Initialized
DEBUG - 2024-06-18 11:35:35 --> UTF-8 Support Enabled
INFO - 2024-06-18 11:35:35 --> Utf8 Class Initialized
INFO - 2024-06-18 11:35:35 --> URI Class Initialized
INFO - 2024-06-18 11:35:35 --> Router Class Initialized
INFO - 2024-06-18 11:35:35 --> Output Class Initialized
INFO - 2024-06-18 11:35:35 --> Security Class Initialized
DEBUG - 2024-06-18 11:35:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-18 11:35:35 --> Input Class Initialized
INFO - 2024-06-18 11:35:35 --> Language Class Initialized
INFO - 2024-06-18 11:35:35 --> Language Class Initialized
INFO - 2024-06-18 11:35:35 --> Config Class Initialized
INFO - 2024-06-18 11:35:35 --> Loader Class Initialized
INFO - 2024-06-18 11:35:35 --> Helper loaded: url_helper
INFO - 2024-06-18 11:35:35 --> Helper loaded: file_helper
INFO - 2024-06-18 11:35:35 --> Helper loaded: form_helper
INFO - 2024-06-18 11:35:35 --> Helper loaded: my_helper
INFO - 2024-06-18 11:35:35 --> Database Driver Class Initialized
INFO - 2024-06-18 11:35:35 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-18 11:35:35 --> Controller Class Initialized
DEBUG - 2024-06-18 11:35:35 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/views/list.php
DEBUG - 2024-06-18 11:35:35 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-06-18 11:35:35 --> Final output sent to browser
DEBUG - 2024-06-18 11:35:35 --> Total execution time: 0.0295
INFO - 2024-06-18 11:35:35 --> Config Class Initialized
INFO - 2024-06-18 11:35:35 --> Hooks Class Initialized
DEBUG - 2024-06-18 11:35:35 --> UTF-8 Support Enabled
INFO - 2024-06-18 11:35:35 --> Utf8 Class Initialized
INFO - 2024-06-18 11:35:35 --> URI Class Initialized
INFO - 2024-06-18 11:35:35 --> Router Class Initialized
INFO - 2024-06-18 11:35:35 --> Output Class Initialized
INFO - 2024-06-18 11:35:35 --> Security Class Initialized
DEBUG - 2024-06-18 11:35:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-18 11:35:35 --> Input Class Initialized
INFO - 2024-06-18 11:35:35 --> Language Class Initialized
INFO - 2024-06-18 11:35:35 --> Language Class Initialized
INFO - 2024-06-18 11:35:35 --> Config Class Initialized
INFO - 2024-06-18 11:35:35 --> Loader Class Initialized
INFO - 2024-06-18 11:35:35 --> Helper loaded: url_helper
INFO - 2024-06-18 11:35:35 --> Helper loaded: file_helper
INFO - 2024-06-18 11:35:35 --> Helper loaded: form_helper
INFO - 2024-06-18 11:35:35 --> Helper loaded: my_helper
INFO - 2024-06-18 11:35:35 --> Database Driver Class Initialized
INFO - 2024-06-18 11:35:35 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-18 11:35:35 --> Controller Class Initialized
INFO - 2024-06-18 11:35:42 --> Config Class Initialized
INFO - 2024-06-18 11:35:42 --> Hooks Class Initialized
DEBUG - 2024-06-18 11:35:42 --> UTF-8 Support Enabled
INFO - 2024-06-18 11:35:42 --> Utf8 Class Initialized
INFO - 2024-06-18 11:35:42 --> URI Class Initialized
INFO - 2024-06-18 11:35:42 --> Router Class Initialized
INFO - 2024-06-18 11:35:42 --> Output Class Initialized
INFO - 2024-06-18 11:35:42 --> Security Class Initialized
DEBUG - 2024-06-18 11:35:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-18 11:35:42 --> Input Class Initialized
INFO - 2024-06-18 11:35:42 --> Language Class Initialized
INFO - 2024-06-18 11:35:42 --> Language Class Initialized
INFO - 2024-06-18 11:35:42 --> Config Class Initialized
INFO - 2024-06-18 11:35:42 --> Loader Class Initialized
INFO - 2024-06-18 11:35:42 --> Helper loaded: url_helper
INFO - 2024-06-18 11:35:42 --> Helper loaded: file_helper
INFO - 2024-06-18 11:35:42 --> Helper loaded: form_helper
INFO - 2024-06-18 11:35:42 --> Helper loaded: my_helper
INFO - 2024-06-18 11:35:42 --> Database Driver Class Initialized
INFO - 2024-06-18 11:35:42 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-18 11:35:42 --> Controller Class Initialized
INFO - 2024-06-18 11:35:42 --> Final output sent to browser
DEBUG - 2024-06-18 11:35:42 --> Total execution time: 0.0613
INFO - 2024-06-18 11:49:22 --> Config Class Initialized
INFO - 2024-06-18 11:49:22 --> Hooks Class Initialized
DEBUG - 2024-06-18 11:49:22 --> UTF-8 Support Enabled
INFO - 2024-06-18 11:49:22 --> Utf8 Class Initialized
INFO - 2024-06-18 11:49:22 --> URI Class Initialized
INFO - 2024-06-18 11:49:22 --> Router Class Initialized
INFO - 2024-06-18 11:49:22 --> Output Class Initialized
INFO - 2024-06-18 11:49:22 --> Security Class Initialized
DEBUG - 2024-06-18 11:49:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-18 11:49:22 --> Input Class Initialized
INFO - 2024-06-18 11:49:22 --> Language Class Initialized
INFO - 2024-06-18 11:49:22 --> Language Class Initialized
INFO - 2024-06-18 11:49:22 --> Config Class Initialized
INFO - 2024-06-18 11:49:22 --> Loader Class Initialized
INFO - 2024-06-18 11:49:22 --> Helper loaded: url_helper
INFO - 2024-06-18 11:49:22 --> Helper loaded: file_helper
INFO - 2024-06-18 11:49:22 --> Helper loaded: form_helper
INFO - 2024-06-18 11:49:22 --> Helper loaded: my_helper
INFO - 2024-06-18 11:49:22 --> Database Driver Class Initialized
INFO - 2024-06-18 11:49:22 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-18 11:49:22 --> Controller Class Initialized
INFO - 2024-06-18 11:49:22 --> Final output sent to browser
DEBUG - 2024-06-18 11:49:22 --> Total execution time: 0.0485
INFO - 2024-06-18 11:49:25 --> Config Class Initialized
INFO - 2024-06-18 11:49:25 --> Hooks Class Initialized
DEBUG - 2024-06-18 11:49:25 --> UTF-8 Support Enabled
INFO - 2024-06-18 11:49:25 --> Utf8 Class Initialized
INFO - 2024-06-18 11:49:25 --> URI Class Initialized
INFO - 2024-06-18 11:49:25 --> Router Class Initialized
INFO - 2024-06-18 11:49:25 --> Output Class Initialized
INFO - 2024-06-18 11:49:25 --> Security Class Initialized
DEBUG - 2024-06-18 11:49:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-18 11:49:25 --> Input Class Initialized
INFO - 2024-06-18 11:49:25 --> Language Class Initialized
INFO - 2024-06-18 11:49:25 --> Language Class Initialized
INFO - 2024-06-18 11:49:25 --> Config Class Initialized
INFO - 2024-06-18 11:49:25 --> Loader Class Initialized
INFO - 2024-06-18 11:49:25 --> Helper loaded: url_helper
INFO - 2024-06-18 11:49:25 --> Helper loaded: file_helper
INFO - 2024-06-18 11:49:25 --> Helper loaded: form_helper
INFO - 2024-06-18 11:49:25 --> Helper loaded: my_helper
INFO - 2024-06-18 11:49:25 --> Database Driver Class Initialized
INFO - 2024-06-18 11:49:25 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-18 11:49:25 --> Controller Class Initialized
INFO - 2024-06-18 11:49:25 --> Final output sent to browser
DEBUG - 2024-06-18 11:49:25 --> Total execution time: 0.0345
INFO - 2024-06-18 11:49:51 --> Config Class Initialized
INFO - 2024-06-18 11:49:51 --> Hooks Class Initialized
DEBUG - 2024-06-18 11:49:51 --> UTF-8 Support Enabled
INFO - 2024-06-18 11:49:51 --> Utf8 Class Initialized
INFO - 2024-06-18 11:49:51 --> URI Class Initialized
INFO - 2024-06-18 11:49:51 --> Router Class Initialized
INFO - 2024-06-18 11:49:51 --> Output Class Initialized
INFO - 2024-06-18 11:49:51 --> Security Class Initialized
DEBUG - 2024-06-18 11:49:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-18 11:49:51 --> Input Class Initialized
INFO - 2024-06-18 11:49:51 --> Language Class Initialized
INFO - 2024-06-18 11:49:51 --> Language Class Initialized
INFO - 2024-06-18 11:49:51 --> Config Class Initialized
INFO - 2024-06-18 11:49:51 --> Loader Class Initialized
INFO - 2024-06-18 11:49:51 --> Helper loaded: url_helper
INFO - 2024-06-18 11:49:51 --> Helper loaded: file_helper
INFO - 2024-06-18 11:49:51 --> Helper loaded: form_helper
INFO - 2024-06-18 11:49:51 --> Helper loaded: my_helper
INFO - 2024-06-18 11:49:51 --> Database Driver Class Initialized
INFO - 2024-06-18 11:49:51 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-18 11:49:51 --> Controller Class Initialized
INFO - 2024-06-18 11:49:51 --> Final output sent to browser
DEBUG - 2024-06-18 11:49:51 --> Total execution time: 0.0494
INFO - 2024-06-18 11:49:54 --> Config Class Initialized
INFO - 2024-06-18 11:49:54 --> Hooks Class Initialized
DEBUG - 2024-06-18 11:49:54 --> UTF-8 Support Enabled
INFO - 2024-06-18 11:49:54 --> Utf8 Class Initialized
INFO - 2024-06-18 11:49:54 --> URI Class Initialized
INFO - 2024-06-18 11:49:54 --> Router Class Initialized
INFO - 2024-06-18 11:49:54 --> Output Class Initialized
INFO - 2024-06-18 11:49:54 --> Security Class Initialized
DEBUG - 2024-06-18 11:49:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-18 11:49:54 --> Input Class Initialized
INFO - 2024-06-18 11:49:54 --> Language Class Initialized
INFO - 2024-06-18 11:49:54 --> Language Class Initialized
INFO - 2024-06-18 11:49:54 --> Config Class Initialized
INFO - 2024-06-18 11:49:54 --> Loader Class Initialized
INFO - 2024-06-18 11:49:54 --> Helper loaded: url_helper
INFO - 2024-06-18 11:49:54 --> Helper loaded: file_helper
INFO - 2024-06-18 11:49:54 --> Helper loaded: form_helper
INFO - 2024-06-18 11:49:54 --> Helper loaded: my_helper
INFO - 2024-06-18 11:49:54 --> Database Driver Class Initialized
INFO - 2024-06-18 11:49:54 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-18 11:49:54 --> Controller Class Initialized
INFO - 2024-06-18 11:49:54 --> Final output sent to browser
DEBUG - 2024-06-18 11:49:54 --> Total execution time: 0.0264
INFO - 2024-06-18 11:50:01 --> Config Class Initialized
INFO - 2024-06-18 11:50:01 --> Hooks Class Initialized
DEBUG - 2024-06-18 11:50:01 --> UTF-8 Support Enabled
INFO - 2024-06-18 11:50:01 --> Utf8 Class Initialized
INFO - 2024-06-18 11:50:01 --> URI Class Initialized
INFO - 2024-06-18 11:50:01 --> Router Class Initialized
INFO - 2024-06-18 11:50:01 --> Output Class Initialized
INFO - 2024-06-18 11:50:01 --> Security Class Initialized
DEBUG - 2024-06-18 11:50:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-18 11:50:01 --> Input Class Initialized
INFO - 2024-06-18 11:50:01 --> Language Class Initialized
INFO - 2024-06-18 11:50:01 --> Language Class Initialized
INFO - 2024-06-18 11:50:01 --> Config Class Initialized
INFO - 2024-06-18 11:50:01 --> Loader Class Initialized
INFO - 2024-06-18 11:50:01 --> Helper loaded: url_helper
INFO - 2024-06-18 11:50:01 --> Helper loaded: file_helper
INFO - 2024-06-18 11:50:01 --> Helper loaded: form_helper
INFO - 2024-06-18 11:50:01 --> Helper loaded: my_helper
INFO - 2024-06-18 11:50:01 --> Database Driver Class Initialized
INFO - 2024-06-18 11:50:01 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-18 11:50:01 --> Controller Class Initialized
INFO - 2024-06-18 11:50:01 --> Final output sent to browser
DEBUG - 2024-06-18 11:50:01 --> Total execution time: 0.1592
INFO - 2024-06-18 13:32:49 --> Config Class Initialized
INFO - 2024-06-18 13:32:49 --> Hooks Class Initialized
DEBUG - 2024-06-18 13:32:49 --> UTF-8 Support Enabled
INFO - 2024-06-18 13:32:49 --> Utf8 Class Initialized
INFO - 2024-06-18 13:32:49 --> URI Class Initialized
INFO - 2024-06-18 13:32:49 --> Router Class Initialized
INFO - 2024-06-18 13:32:49 --> Output Class Initialized
INFO - 2024-06-18 13:32:49 --> Security Class Initialized
DEBUG - 2024-06-18 13:32:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-18 13:32:49 --> Input Class Initialized
INFO - 2024-06-18 13:32:49 --> Language Class Initialized
INFO - 2024-06-18 13:32:49 --> Language Class Initialized
INFO - 2024-06-18 13:32:49 --> Config Class Initialized
INFO - 2024-06-18 13:32:49 --> Loader Class Initialized
INFO - 2024-06-18 13:32:49 --> Helper loaded: url_helper
INFO - 2024-06-18 13:32:49 --> Helper loaded: file_helper
INFO - 2024-06-18 13:32:49 --> Helper loaded: form_helper
INFO - 2024-06-18 13:32:49 --> Helper loaded: my_helper
INFO - 2024-06-18 13:32:49 --> Database Driver Class Initialized
INFO - 2024-06-18 13:32:49 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-18 13:32:49 --> Controller Class Initialized
DEBUG - 2024-06-18 13:32:49 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/views/list.php
DEBUG - 2024-06-18 13:32:49 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-06-18 13:32:49 --> Final output sent to browser
DEBUG - 2024-06-18 13:32:49 --> Total execution time: 0.0552
INFO - 2024-06-18 13:32:50 --> Config Class Initialized
INFO - 2024-06-18 13:32:50 --> Hooks Class Initialized
DEBUG - 2024-06-18 13:32:50 --> UTF-8 Support Enabled
INFO - 2024-06-18 13:32:50 --> Utf8 Class Initialized
INFO - 2024-06-18 13:32:50 --> URI Class Initialized
INFO - 2024-06-18 13:32:50 --> Router Class Initialized
INFO - 2024-06-18 13:32:50 --> Output Class Initialized
INFO - 2024-06-18 13:32:50 --> Security Class Initialized
DEBUG - 2024-06-18 13:32:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-18 13:32:50 --> Input Class Initialized
INFO - 2024-06-18 13:32:50 --> Language Class Initialized
INFO - 2024-06-18 13:32:50 --> Language Class Initialized
INFO - 2024-06-18 13:32:50 --> Config Class Initialized
INFO - 2024-06-18 13:32:50 --> Loader Class Initialized
INFO - 2024-06-18 13:32:50 --> Helper loaded: url_helper
INFO - 2024-06-18 13:32:50 --> Helper loaded: file_helper
INFO - 2024-06-18 13:32:50 --> Helper loaded: form_helper
INFO - 2024-06-18 13:32:50 --> Helper loaded: my_helper
INFO - 2024-06-18 13:32:50 --> Database Driver Class Initialized
INFO - 2024-06-18 13:32:50 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-18 13:32:50 --> Controller Class Initialized
INFO - 2024-06-18 13:32:56 --> Config Class Initialized
INFO - 2024-06-18 13:32:56 --> Hooks Class Initialized
DEBUG - 2024-06-18 13:32:56 --> UTF-8 Support Enabled
INFO - 2024-06-18 13:32:56 --> Utf8 Class Initialized
INFO - 2024-06-18 13:32:56 --> URI Class Initialized
DEBUG - 2024-06-18 13:32:56 --> No URI present. Default controller set.
INFO - 2024-06-18 13:32:56 --> Router Class Initialized
INFO - 2024-06-18 13:32:56 --> Output Class Initialized
INFO - 2024-06-18 13:32:56 --> Security Class Initialized
DEBUG - 2024-06-18 13:32:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-18 13:32:56 --> Input Class Initialized
INFO - 2024-06-18 13:32:56 --> Language Class Initialized
INFO - 2024-06-18 13:32:56 --> Language Class Initialized
INFO - 2024-06-18 13:32:56 --> Config Class Initialized
INFO - 2024-06-18 13:32:56 --> Loader Class Initialized
INFO - 2024-06-18 13:32:56 --> Helper loaded: url_helper
INFO - 2024-06-18 13:32:56 --> Helper loaded: file_helper
INFO - 2024-06-18 13:32:56 --> Helper loaded: form_helper
INFO - 2024-06-18 13:32:56 --> Helper loaded: my_helper
INFO - 2024-06-18 13:32:56 --> Database Driver Class Initialized
INFO - 2024-06-18 13:32:56 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-18 13:32:56 --> Controller Class Initialized
INFO - 2024-06-18 13:32:57 --> Config Class Initialized
INFO - 2024-06-18 13:32:57 --> Hooks Class Initialized
DEBUG - 2024-06-18 13:32:57 --> UTF-8 Support Enabled
INFO - 2024-06-18 13:32:57 --> Utf8 Class Initialized
INFO - 2024-06-18 13:32:57 --> URI Class Initialized
INFO - 2024-06-18 13:32:57 --> Router Class Initialized
INFO - 2024-06-18 13:32:57 --> Output Class Initialized
INFO - 2024-06-18 13:32:57 --> Security Class Initialized
DEBUG - 2024-06-18 13:32:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-18 13:32:57 --> Input Class Initialized
INFO - 2024-06-18 13:32:57 --> Language Class Initialized
INFO - 2024-06-18 13:32:57 --> Language Class Initialized
INFO - 2024-06-18 13:32:57 --> Config Class Initialized
INFO - 2024-06-18 13:32:57 --> Loader Class Initialized
INFO - 2024-06-18 13:32:57 --> Helper loaded: url_helper
INFO - 2024-06-18 13:32:57 --> Helper loaded: file_helper
INFO - 2024-06-18 13:32:57 --> Helper loaded: form_helper
INFO - 2024-06-18 13:32:57 --> Helper loaded: my_helper
INFO - 2024-06-18 13:32:57 --> Database Driver Class Initialized
INFO - 2024-06-18 13:32:57 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-18 13:32:57 --> Controller Class Initialized
DEBUG - 2024-06-18 13:32:57 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/login/views/login.php
DEBUG - 2024-06-18 13:32:57 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-06-18 13:32:57 --> Final output sent to browser
DEBUG - 2024-06-18 13:32:57 --> Total execution time: 0.0295
INFO - 2024-06-18 13:32:58 --> Config Class Initialized
INFO - 2024-06-18 13:32:58 --> Hooks Class Initialized
DEBUG - 2024-06-18 13:32:58 --> UTF-8 Support Enabled
INFO - 2024-06-18 13:32:58 --> Utf8 Class Initialized
INFO - 2024-06-18 13:32:58 --> URI Class Initialized
INFO - 2024-06-18 13:32:58 --> Router Class Initialized
INFO - 2024-06-18 13:32:58 --> Output Class Initialized
INFO - 2024-06-18 13:32:58 --> Security Class Initialized
DEBUG - 2024-06-18 13:32:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-18 13:32:58 --> Input Class Initialized
INFO - 2024-06-18 13:32:58 --> Language Class Initialized
INFO - 2024-06-18 13:32:58 --> Language Class Initialized
INFO - 2024-06-18 13:32:58 --> Config Class Initialized
INFO - 2024-06-18 13:32:58 --> Loader Class Initialized
INFO - 2024-06-18 13:32:58 --> Helper loaded: url_helper
INFO - 2024-06-18 13:32:58 --> Helper loaded: file_helper
INFO - 2024-06-18 13:32:58 --> Helper loaded: form_helper
INFO - 2024-06-18 13:32:58 --> Helper loaded: my_helper
INFO - 2024-06-18 13:32:58 --> Database Driver Class Initialized
INFO - 2024-06-18 13:32:58 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-18 13:32:58 --> Controller Class Initialized
INFO - 2024-06-18 13:32:58 --> Helper loaded: cookie_helper
INFO - 2024-06-18 13:32:58 --> Final output sent to browser
DEBUG - 2024-06-18 13:32:58 --> Total execution time: 0.0318
INFO - 2024-06-18 13:32:58 --> Config Class Initialized
INFO - 2024-06-18 13:32:58 --> Hooks Class Initialized
DEBUG - 2024-06-18 13:32:58 --> UTF-8 Support Enabled
INFO - 2024-06-18 13:32:58 --> Utf8 Class Initialized
INFO - 2024-06-18 13:32:58 --> URI Class Initialized
INFO - 2024-06-18 13:32:58 --> Router Class Initialized
INFO - 2024-06-18 13:32:58 --> Output Class Initialized
INFO - 2024-06-18 13:32:58 --> Security Class Initialized
DEBUG - 2024-06-18 13:32:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-18 13:32:58 --> Input Class Initialized
INFO - 2024-06-18 13:32:58 --> Language Class Initialized
INFO - 2024-06-18 13:32:58 --> Language Class Initialized
INFO - 2024-06-18 13:32:58 --> Config Class Initialized
INFO - 2024-06-18 13:32:58 --> Loader Class Initialized
INFO - 2024-06-18 13:32:58 --> Helper loaded: url_helper
INFO - 2024-06-18 13:32:58 --> Helper loaded: file_helper
INFO - 2024-06-18 13:32:58 --> Helper loaded: form_helper
INFO - 2024-06-18 13:32:58 --> Helper loaded: my_helper
INFO - 2024-06-18 13:32:58 --> Database Driver Class Initialized
INFO - 2024-06-18 13:32:58 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-18 13:32:58 --> Controller Class Initialized
DEBUG - 2024-06-18 13:32:58 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/home/views/v_home_guru.php
DEBUG - 2024-06-18 13:32:58 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-06-18 13:32:58 --> Final output sent to browser
DEBUG - 2024-06-18 13:32:58 --> Total execution time: 0.0306
INFO - 2024-06-18 13:33:11 --> Config Class Initialized
INFO - 2024-06-18 13:33:11 --> Hooks Class Initialized
DEBUG - 2024-06-18 13:33:11 --> UTF-8 Support Enabled
INFO - 2024-06-18 13:33:11 --> Utf8 Class Initialized
INFO - 2024-06-18 13:33:11 --> URI Class Initialized
INFO - 2024-06-18 13:33:11 --> Router Class Initialized
INFO - 2024-06-18 13:33:11 --> Output Class Initialized
INFO - 2024-06-18 13:33:11 --> Security Class Initialized
DEBUG - 2024-06-18 13:33:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-18 13:33:11 --> Input Class Initialized
INFO - 2024-06-18 13:33:11 --> Language Class Initialized
INFO - 2024-06-18 13:33:11 --> Language Class Initialized
INFO - 2024-06-18 13:33:11 --> Config Class Initialized
INFO - 2024-06-18 13:33:11 --> Loader Class Initialized
INFO - 2024-06-18 13:33:11 --> Helper loaded: url_helper
INFO - 2024-06-18 13:33:11 --> Helper loaded: file_helper
INFO - 2024-06-18 13:33:11 --> Helper loaded: form_helper
INFO - 2024-06-18 13:33:11 --> Helper loaded: my_helper
INFO - 2024-06-18 13:33:11 --> Database Driver Class Initialized
INFO - 2024-06-18 13:33:11 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-18 13:33:11 --> Controller Class Initialized
DEBUG - 2024-06-18 13:33:11 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/view_mapel/views/v_view_mapel.php
DEBUG - 2024-06-18 13:33:11 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-06-18 13:33:11 --> Final output sent to browser
DEBUG - 2024-06-18 13:33:11 --> Total execution time: 0.0340
INFO - 2024-06-18 13:33:14 --> Config Class Initialized
INFO - 2024-06-18 13:33:14 --> Hooks Class Initialized
DEBUG - 2024-06-18 13:33:14 --> UTF-8 Support Enabled
INFO - 2024-06-18 13:33:14 --> Utf8 Class Initialized
INFO - 2024-06-18 13:33:14 --> URI Class Initialized
INFO - 2024-06-18 13:33:14 --> Router Class Initialized
INFO - 2024-06-18 13:33:14 --> Output Class Initialized
INFO - 2024-06-18 13:33:14 --> Security Class Initialized
DEBUG - 2024-06-18 13:33:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-18 13:33:14 --> Input Class Initialized
INFO - 2024-06-18 13:33:14 --> Language Class Initialized
INFO - 2024-06-18 13:33:14 --> Language Class Initialized
INFO - 2024-06-18 13:33:14 --> Config Class Initialized
INFO - 2024-06-18 13:33:14 --> Loader Class Initialized
INFO - 2024-06-18 13:33:14 --> Helper loaded: url_helper
INFO - 2024-06-18 13:33:14 --> Helper loaded: file_helper
INFO - 2024-06-18 13:33:14 --> Helper loaded: form_helper
INFO - 2024-06-18 13:33:14 --> Helper loaded: my_helper
INFO - 2024-06-18 13:33:14 --> Database Driver Class Initialized
INFO - 2024-06-18 13:33:14 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-18 13:33:14 --> Controller Class Initialized
DEBUG - 2024-06-18 13:33:14 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/views/list.php
DEBUG - 2024-06-18 13:33:14 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-06-18 13:33:14 --> Final output sent to browser
DEBUG - 2024-06-18 13:33:14 --> Total execution time: 0.0301
INFO - 2024-06-18 13:33:14 --> Config Class Initialized
INFO - 2024-06-18 13:33:14 --> Hooks Class Initialized
DEBUG - 2024-06-18 13:33:14 --> UTF-8 Support Enabled
INFO - 2024-06-18 13:33:14 --> Utf8 Class Initialized
INFO - 2024-06-18 13:33:14 --> URI Class Initialized
INFO - 2024-06-18 13:33:14 --> Router Class Initialized
INFO - 2024-06-18 13:33:14 --> Output Class Initialized
INFO - 2024-06-18 13:33:14 --> Security Class Initialized
DEBUG - 2024-06-18 13:33:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-18 13:33:14 --> Input Class Initialized
INFO - 2024-06-18 13:33:14 --> Language Class Initialized
INFO - 2024-06-18 13:33:14 --> Language Class Initialized
INFO - 2024-06-18 13:33:14 --> Config Class Initialized
INFO - 2024-06-18 13:33:14 --> Loader Class Initialized
INFO - 2024-06-18 13:33:14 --> Helper loaded: url_helper
INFO - 2024-06-18 13:33:14 --> Helper loaded: file_helper
INFO - 2024-06-18 13:33:14 --> Helper loaded: form_helper
INFO - 2024-06-18 13:33:14 --> Helper loaded: my_helper
INFO - 2024-06-18 13:33:14 --> Database Driver Class Initialized
INFO - 2024-06-18 13:33:14 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-18 13:33:14 --> Controller Class Initialized
INFO - 2024-06-18 13:33:18 --> Config Class Initialized
INFO - 2024-06-18 13:33:18 --> Hooks Class Initialized
DEBUG - 2024-06-18 13:33:18 --> UTF-8 Support Enabled
INFO - 2024-06-18 13:33:18 --> Utf8 Class Initialized
INFO - 2024-06-18 13:33:18 --> URI Class Initialized
INFO - 2024-06-18 13:33:18 --> Router Class Initialized
INFO - 2024-06-18 13:33:18 --> Output Class Initialized
INFO - 2024-06-18 13:33:18 --> Security Class Initialized
DEBUG - 2024-06-18 13:33:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-18 13:33:18 --> Input Class Initialized
INFO - 2024-06-18 13:33:18 --> Language Class Initialized
INFO - 2024-06-18 13:33:18 --> Language Class Initialized
INFO - 2024-06-18 13:33:18 --> Config Class Initialized
INFO - 2024-06-18 13:33:18 --> Loader Class Initialized
INFO - 2024-06-18 13:33:18 --> Helper loaded: url_helper
INFO - 2024-06-18 13:33:18 --> Helper loaded: file_helper
INFO - 2024-06-18 13:33:18 --> Helper loaded: form_helper
INFO - 2024-06-18 13:33:18 --> Helper loaded: my_helper
INFO - 2024-06-18 13:33:18 --> Database Driver Class Initialized
INFO - 2024-06-18 13:33:18 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-18 13:33:18 --> Controller Class Initialized
INFO - 2024-06-18 13:33:18 --> Final output sent to browser
DEBUG - 2024-06-18 13:33:18 --> Total execution time: 0.0293
INFO - 2024-06-18 13:35:57 --> Config Class Initialized
INFO - 2024-06-18 13:35:57 --> Hooks Class Initialized
DEBUG - 2024-06-18 13:35:57 --> UTF-8 Support Enabled
INFO - 2024-06-18 13:35:57 --> Utf8 Class Initialized
INFO - 2024-06-18 13:35:57 --> URI Class Initialized
INFO - 2024-06-18 13:35:57 --> Router Class Initialized
INFO - 2024-06-18 13:35:57 --> Output Class Initialized
INFO - 2024-06-18 13:35:57 --> Security Class Initialized
DEBUG - 2024-06-18 13:35:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-18 13:35:57 --> Input Class Initialized
INFO - 2024-06-18 13:35:57 --> Language Class Initialized
INFO - 2024-06-18 13:35:57 --> Language Class Initialized
INFO - 2024-06-18 13:35:57 --> Config Class Initialized
INFO - 2024-06-18 13:35:57 --> Loader Class Initialized
INFO - 2024-06-18 13:35:57 --> Helper loaded: url_helper
INFO - 2024-06-18 13:35:57 --> Helper loaded: file_helper
INFO - 2024-06-18 13:35:57 --> Helper loaded: form_helper
INFO - 2024-06-18 13:35:57 --> Helper loaded: my_helper
INFO - 2024-06-18 13:35:57 --> Database Driver Class Initialized
INFO - 2024-06-18 13:35:57 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-18 13:35:57 --> Controller Class Initialized
INFO - 2024-06-18 13:35:57 --> Final output sent to browser
DEBUG - 2024-06-18 13:35:57 --> Total execution time: 0.1358
INFO - 2024-06-18 18:20:20 --> Config Class Initialized
INFO - 2024-06-18 18:20:20 --> Hooks Class Initialized
DEBUG - 2024-06-18 18:20:20 --> UTF-8 Support Enabled
INFO - 2024-06-18 18:20:20 --> Utf8 Class Initialized
INFO - 2024-06-18 18:20:20 --> URI Class Initialized
INFO - 2024-06-18 18:20:20 --> Router Class Initialized
INFO - 2024-06-18 18:20:20 --> Output Class Initialized
INFO - 2024-06-18 18:20:20 --> Security Class Initialized
DEBUG - 2024-06-18 18:20:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-18 18:20:20 --> Input Class Initialized
INFO - 2024-06-18 18:20:20 --> Language Class Initialized
INFO - 2024-06-18 18:20:20 --> Language Class Initialized
INFO - 2024-06-18 18:20:20 --> Config Class Initialized
INFO - 2024-06-18 18:20:20 --> Loader Class Initialized
INFO - 2024-06-18 18:20:20 --> Helper loaded: url_helper
INFO - 2024-06-18 18:20:20 --> Helper loaded: file_helper
INFO - 2024-06-18 18:20:20 --> Helper loaded: form_helper
INFO - 2024-06-18 18:20:20 --> Helper loaded: my_helper
INFO - 2024-06-18 18:20:20 --> Database Driver Class Initialized
INFO - 2024-06-18 18:20:20 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-18 18:20:20 --> Controller Class Initialized
ERROR - 2024-06-18 18:20:20 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_catatan_kl1/controllers/N_catatan_kl1.php 19
ERROR - 2024-06-18 18:20:20 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_catatan_kl1/controllers/N_catatan_kl1.php 20
DEBUG - 2024-06-18 18:20:20 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_catatan_kl1/views/list.php
DEBUG - 2024-06-18 18:20:20 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-06-18 18:20:20 --> Final output sent to browser
DEBUG - 2024-06-18 18:20:20 --> Total execution time: 0.0581
INFO - 2024-06-18 18:20:35 --> Config Class Initialized
INFO - 2024-06-18 18:20:35 --> Hooks Class Initialized
DEBUG - 2024-06-18 18:20:35 --> UTF-8 Support Enabled
INFO - 2024-06-18 18:20:35 --> Utf8 Class Initialized
INFO - 2024-06-18 18:20:35 --> URI Class Initialized
INFO - 2024-06-18 18:20:35 --> Router Class Initialized
INFO - 2024-06-18 18:20:35 --> Output Class Initialized
INFO - 2024-06-18 18:20:35 --> Security Class Initialized
DEBUG - 2024-06-18 18:20:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-18 18:20:35 --> Input Class Initialized
INFO - 2024-06-18 18:20:35 --> Language Class Initialized
INFO - 2024-06-18 18:20:35 --> Language Class Initialized
INFO - 2024-06-18 18:20:35 --> Config Class Initialized
INFO - 2024-06-18 18:20:35 --> Loader Class Initialized
INFO - 2024-06-18 18:20:35 --> Helper loaded: url_helper
INFO - 2024-06-18 18:20:35 --> Helper loaded: file_helper
INFO - 2024-06-18 18:20:35 --> Helper loaded: form_helper
INFO - 2024-06-18 18:20:35 --> Helper loaded: my_helper
INFO - 2024-06-18 18:20:35 --> Database Driver Class Initialized
INFO - 2024-06-18 18:20:35 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-18 18:20:35 --> Controller Class Initialized
DEBUG - 2024-06-18 18:20:35 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/login/views/login.php
DEBUG - 2024-06-18 18:20:35 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-06-18 18:20:35 --> Final output sent to browser
DEBUG - 2024-06-18 18:20:35 --> Total execution time: 0.0424
INFO - 2024-06-18 18:27:18 --> Config Class Initialized
INFO - 2024-06-18 18:27:18 --> Hooks Class Initialized
DEBUG - 2024-06-18 18:27:18 --> UTF-8 Support Enabled
INFO - 2024-06-18 18:27:18 --> Utf8 Class Initialized
INFO - 2024-06-18 18:27:18 --> URI Class Initialized
INFO - 2024-06-18 18:27:18 --> Router Class Initialized
INFO - 2024-06-18 18:27:18 --> Output Class Initialized
INFO - 2024-06-18 18:27:18 --> Security Class Initialized
DEBUG - 2024-06-18 18:27:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-18 18:27:18 --> Input Class Initialized
INFO - 2024-06-18 18:27:18 --> Language Class Initialized
INFO - 2024-06-18 18:27:18 --> Language Class Initialized
INFO - 2024-06-18 18:27:18 --> Config Class Initialized
INFO - 2024-06-18 18:27:18 --> Loader Class Initialized
INFO - 2024-06-18 18:27:18 --> Helper loaded: url_helper
INFO - 2024-06-18 18:27:18 --> Helper loaded: file_helper
INFO - 2024-06-18 18:27:18 --> Helper loaded: form_helper
INFO - 2024-06-18 18:27:18 --> Helper loaded: my_helper
INFO - 2024-06-18 18:27:18 --> Database Driver Class Initialized
INFO - 2024-06-18 18:27:18 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-18 18:27:18 --> Controller Class Initialized
INFO - 2024-06-18 18:27:18 --> Helper loaded: cookie_helper
INFO - 2024-06-18 18:27:18 --> Final output sent to browser
DEBUG - 2024-06-18 18:27:18 --> Total execution time: 0.0936
INFO - 2024-06-18 18:27:18 --> Config Class Initialized
INFO - 2024-06-18 18:27:18 --> Hooks Class Initialized
DEBUG - 2024-06-18 18:27:18 --> UTF-8 Support Enabled
INFO - 2024-06-18 18:27:18 --> Utf8 Class Initialized
INFO - 2024-06-18 18:27:18 --> URI Class Initialized
INFO - 2024-06-18 18:27:18 --> Router Class Initialized
INFO - 2024-06-18 18:27:18 --> Output Class Initialized
INFO - 2024-06-18 18:27:18 --> Security Class Initialized
DEBUG - 2024-06-18 18:27:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-18 18:27:18 --> Input Class Initialized
INFO - 2024-06-18 18:27:18 --> Language Class Initialized
INFO - 2024-06-18 18:27:18 --> Language Class Initialized
INFO - 2024-06-18 18:27:18 --> Config Class Initialized
INFO - 2024-06-18 18:27:18 --> Loader Class Initialized
INFO - 2024-06-18 18:27:18 --> Helper loaded: url_helper
INFO - 2024-06-18 18:27:18 --> Helper loaded: file_helper
INFO - 2024-06-18 18:27:18 --> Helper loaded: form_helper
INFO - 2024-06-18 18:27:18 --> Helper loaded: my_helper
INFO - 2024-06-18 18:27:18 --> Database Driver Class Initialized
INFO - 2024-06-18 18:27:18 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-18 18:27:18 --> Controller Class Initialized
DEBUG - 2024-06-18 18:27:18 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/home/views/v_home_guru.php
DEBUG - 2024-06-18 18:27:18 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-06-18 18:27:18 --> Final output sent to browser
DEBUG - 2024-06-18 18:27:18 --> Total execution time: 0.0280
INFO - 2024-06-18 18:28:10 --> Config Class Initialized
INFO - 2024-06-18 18:28:10 --> Hooks Class Initialized
DEBUG - 2024-06-18 18:28:10 --> UTF-8 Support Enabled
INFO - 2024-06-18 18:28:10 --> Utf8 Class Initialized
INFO - 2024-06-18 18:28:10 --> URI Class Initialized
INFO - 2024-06-18 18:28:10 --> Router Class Initialized
INFO - 2024-06-18 18:28:10 --> Output Class Initialized
INFO - 2024-06-18 18:28:10 --> Security Class Initialized
DEBUG - 2024-06-18 18:28:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-18 18:28:10 --> Input Class Initialized
INFO - 2024-06-18 18:28:10 --> Language Class Initialized
INFO - 2024-06-18 18:28:10 --> Language Class Initialized
INFO - 2024-06-18 18:28:10 --> Config Class Initialized
INFO - 2024-06-18 18:28:10 --> Loader Class Initialized
INFO - 2024-06-18 18:28:10 --> Helper loaded: url_helper
INFO - 2024-06-18 18:28:10 --> Helper loaded: file_helper
INFO - 2024-06-18 18:28:10 --> Helper loaded: form_helper
INFO - 2024-06-18 18:28:10 --> Helper loaded: my_helper
INFO - 2024-06-18 18:28:10 --> Database Driver Class Initialized
INFO - 2024-06-18 18:28:10 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-18 18:28:10 --> Controller Class Initialized
DEBUG - 2024-06-18 18:28:10 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/view_mapel/views/v_view_mapel.php
DEBUG - 2024-06-18 18:28:10 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-06-18 18:28:10 --> Final output sent to browser
DEBUG - 2024-06-18 18:28:10 --> Total execution time: 0.0312
INFO - 2024-06-18 18:28:25 --> Config Class Initialized
INFO - 2024-06-18 18:28:25 --> Hooks Class Initialized
DEBUG - 2024-06-18 18:28:25 --> UTF-8 Support Enabled
INFO - 2024-06-18 18:28:25 --> Utf8 Class Initialized
INFO - 2024-06-18 18:28:25 --> URI Class Initialized
INFO - 2024-06-18 18:28:25 --> Router Class Initialized
INFO - 2024-06-18 18:28:25 --> Output Class Initialized
INFO - 2024-06-18 18:28:25 --> Security Class Initialized
DEBUG - 2024-06-18 18:28:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-18 18:28:25 --> Input Class Initialized
INFO - 2024-06-18 18:28:25 --> Language Class Initialized
INFO - 2024-06-18 18:28:25 --> Language Class Initialized
INFO - 2024-06-18 18:28:25 --> Config Class Initialized
INFO - 2024-06-18 18:28:25 --> Loader Class Initialized
INFO - 2024-06-18 18:28:25 --> Helper loaded: url_helper
INFO - 2024-06-18 18:28:25 --> Helper loaded: file_helper
INFO - 2024-06-18 18:28:25 --> Helper loaded: form_helper
INFO - 2024-06-18 18:28:25 --> Helper loaded: my_helper
INFO - 2024-06-18 18:28:25 --> Database Driver Class Initialized
INFO - 2024-06-18 18:28:25 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-18 18:28:25 --> Controller Class Initialized
DEBUG - 2024-06-18 18:28:25 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/views/list.php
DEBUG - 2024-06-18 18:28:25 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-06-18 18:28:25 --> Final output sent to browser
DEBUG - 2024-06-18 18:28:25 --> Total execution time: 0.0294
INFO - 2024-06-18 18:28:25 --> Config Class Initialized
INFO - 2024-06-18 18:28:25 --> Hooks Class Initialized
DEBUG - 2024-06-18 18:28:25 --> UTF-8 Support Enabled
INFO - 2024-06-18 18:28:25 --> Utf8 Class Initialized
INFO - 2024-06-18 18:28:25 --> URI Class Initialized
INFO - 2024-06-18 18:28:25 --> Router Class Initialized
INFO - 2024-06-18 18:28:25 --> Output Class Initialized
INFO - 2024-06-18 18:28:25 --> Security Class Initialized
DEBUG - 2024-06-18 18:28:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-18 18:28:25 --> Input Class Initialized
INFO - 2024-06-18 18:28:25 --> Language Class Initialized
INFO - 2024-06-18 18:28:25 --> Language Class Initialized
INFO - 2024-06-18 18:28:25 --> Config Class Initialized
INFO - 2024-06-18 18:28:25 --> Loader Class Initialized
INFO - 2024-06-18 18:28:25 --> Helper loaded: url_helper
INFO - 2024-06-18 18:28:25 --> Helper loaded: file_helper
INFO - 2024-06-18 18:28:25 --> Helper loaded: form_helper
INFO - 2024-06-18 18:28:25 --> Helper loaded: my_helper
INFO - 2024-06-18 18:28:25 --> Database Driver Class Initialized
INFO - 2024-06-18 18:28:25 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-18 18:28:25 --> Controller Class Initialized
INFO - 2024-06-18 18:28:41 --> Config Class Initialized
INFO - 2024-06-18 18:28:41 --> Hooks Class Initialized
DEBUG - 2024-06-18 18:28:41 --> UTF-8 Support Enabled
INFO - 2024-06-18 18:28:41 --> Utf8 Class Initialized
INFO - 2024-06-18 18:28:41 --> URI Class Initialized
INFO - 2024-06-18 18:28:41 --> Router Class Initialized
INFO - 2024-06-18 18:28:41 --> Output Class Initialized
INFO - 2024-06-18 18:28:41 --> Security Class Initialized
DEBUG - 2024-06-18 18:28:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-18 18:28:41 --> Input Class Initialized
INFO - 2024-06-18 18:28:41 --> Language Class Initialized
INFO - 2024-06-18 18:28:41 --> Language Class Initialized
INFO - 2024-06-18 18:28:41 --> Config Class Initialized
INFO - 2024-06-18 18:28:41 --> Loader Class Initialized
INFO - 2024-06-18 18:28:41 --> Helper loaded: url_helper
INFO - 2024-06-18 18:28:41 --> Helper loaded: file_helper
INFO - 2024-06-18 18:28:41 --> Helper loaded: form_helper
INFO - 2024-06-18 18:28:41 --> Helper loaded: my_helper
INFO - 2024-06-18 18:28:41 --> Database Driver Class Initialized
INFO - 2024-06-18 18:28:41 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-18 18:28:41 --> Controller Class Initialized
DEBUG - 2024-06-18 18:28:41 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/view_mapel/views/v_view_mapel.php
DEBUG - 2024-06-18 18:28:41 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-06-18 18:28:41 --> Final output sent to browser
DEBUG - 2024-06-18 18:28:41 --> Total execution time: 0.0324
INFO - 2024-06-18 18:28:46 --> Config Class Initialized
INFO - 2024-06-18 18:28:46 --> Hooks Class Initialized
DEBUG - 2024-06-18 18:28:46 --> UTF-8 Support Enabled
INFO - 2024-06-18 18:28:46 --> Utf8 Class Initialized
INFO - 2024-06-18 18:28:46 --> URI Class Initialized
INFO - 2024-06-18 18:28:46 --> Router Class Initialized
INFO - 2024-06-18 18:28:46 --> Output Class Initialized
INFO - 2024-06-18 18:28:46 --> Security Class Initialized
DEBUG - 2024-06-18 18:28:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-18 18:28:46 --> Input Class Initialized
INFO - 2024-06-18 18:28:46 --> Language Class Initialized
INFO - 2024-06-18 18:28:46 --> Language Class Initialized
INFO - 2024-06-18 18:28:46 --> Config Class Initialized
INFO - 2024-06-18 18:28:46 --> Loader Class Initialized
INFO - 2024-06-18 18:28:46 --> Helper loaded: url_helper
INFO - 2024-06-18 18:28:46 --> Helper loaded: file_helper
INFO - 2024-06-18 18:28:46 --> Helper loaded: form_helper
INFO - 2024-06-18 18:28:46 --> Helper loaded: my_helper
INFO - 2024-06-18 18:28:46 --> Database Driver Class Initialized
INFO - 2024-06-18 18:28:46 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-18 18:28:46 --> Controller Class Initialized
DEBUG - 2024-06-18 18:28:46 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/views/list.php
DEBUG - 2024-06-18 18:28:46 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-06-18 18:28:46 --> Final output sent to browser
DEBUG - 2024-06-18 18:28:46 --> Total execution time: 0.0302
INFO - 2024-06-18 18:28:46 --> Config Class Initialized
INFO - 2024-06-18 18:28:46 --> Hooks Class Initialized
DEBUG - 2024-06-18 18:28:46 --> UTF-8 Support Enabled
INFO - 2024-06-18 18:28:46 --> Utf8 Class Initialized
INFO - 2024-06-18 18:28:46 --> URI Class Initialized
INFO - 2024-06-18 18:28:46 --> Router Class Initialized
INFO - 2024-06-18 18:28:46 --> Output Class Initialized
INFO - 2024-06-18 18:28:46 --> Security Class Initialized
DEBUG - 2024-06-18 18:28:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-18 18:28:46 --> Input Class Initialized
INFO - 2024-06-18 18:28:46 --> Language Class Initialized
INFO - 2024-06-18 18:28:46 --> Language Class Initialized
INFO - 2024-06-18 18:28:46 --> Config Class Initialized
INFO - 2024-06-18 18:28:46 --> Loader Class Initialized
INFO - 2024-06-18 18:28:46 --> Helper loaded: url_helper
INFO - 2024-06-18 18:28:46 --> Helper loaded: file_helper
INFO - 2024-06-18 18:28:46 --> Helper loaded: form_helper
INFO - 2024-06-18 18:28:46 --> Helper loaded: my_helper
INFO - 2024-06-18 18:28:46 --> Database Driver Class Initialized
INFO - 2024-06-18 18:28:46 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-18 18:28:46 --> Controller Class Initialized
INFO - 2024-06-18 18:29:02 --> Config Class Initialized
INFO - 2024-06-18 18:29:02 --> Hooks Class Initialized
DEBUG - 2024-06-18 18:29:02 --> UTF-8 Support Enabled
INFO - 2024-06-18 18:29:02 --> Utf8 Class Initialized
INFO - 2024-06-18 18:29:02 --> URI Class Initialized
INFO - 2024-06-18 18:29:02 --> Router Class Initialized
INFO - 2024-06-18 18:29:02 --> Output Class Initialized
INFO - 2024-06-18 18:29:02 --> Security Class Initialized
DEBUG - 2024-06-18 18:29:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-18 18:29:02 --> Input Class Initialized
INFO - 2024-06-18 18:29:02 --> Language Class Initialized
INFO - 2024-06-18 18:29:02 --> Language Class Initialized
INFO - 2024-06-18 18:29:02 --> Config Class Initialized
INFO - 2024-06-18 18:29:02 --> Loader Class Initialized
INFO - 2024-06-18 18:29:02 --> Helper loaded: url_helper
INFO - 2024-06-18 18:29:02 --> Helper loaded: file_helper
INFO - 2024-06-18 18:29:02 --> Helper loaded: form_helper
INFO - 2024-06-18 18:29:02 --> Helper loaded: my_helper
INFO - 2024-06-18 18:29:02 --> Database Driver Class Initialized
INFO - 2024-06-18 18:29:02 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-18 18:29:02 --> Controller Class Initialized
INFO - 2024-06-18 18:29:02 --> Final output sent to browser
DEBUG - 2024-06-18 18:29:02 --> Total execution time: 0.0542
INFO - 2024-06-18 18:29:13 --> Config Class Initialized
INFO - 2024-06-18 18:29:13 --> Hooks Class Initialized
DEBUG - 2024-06-18 18:29:13 --> UTF-8 Support Enabled
INFO - 2024-06-18 18:29:13 --> Utf8 Class Initialized
INFO - 2024-06-18 18:29:13 --> URI Class Initialized
INFO - 2024-06-18 18:29:13 --> Router Class Initialized
INFO - 2024-06-18 18:29:13 --> Output Class Initialized
INFO - 2024-06-18 18:29:13 --> Security Class Initialized
DEBUG - 2024-06-18 18:29:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-18 18:29:13 --> Input Class Initialized
INFO - 2024-06-18 18:29:13 --> Language Class Initialized
INFO - 2024-06-18 18:29:13 --> Language Class Initialized
INFO - 2024-06-18 18:29:13 --> Config Class Initialized
INFO - 2024-06-18 18:29:13 --> Loader Class Initialized
INFO - 2024-06-18 18:29:13 --> Helper loaded: url_helper
INFO - 2024-06-18 18:29:13 --> Helper loaded: file_helper
INFO - 2024-06-18 18:29:13 --> Helper loaded: form_helper
INFO - 2024-06-18 18:29:13 --> Helper loaded: my_helper
INFO - 2024-06-18 18:29:13 --> Database Driver Class Initialized
INFO - 2024-06-18 18:29:13 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-18 18:29:13 --> Controller Class Initialized
DEBUG - 2024-06-18 18:29:13 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/views/list.php
DEBUG - 2024-06-18 18:29:13 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-06-18 18:29:13 --> Final output sent to browser
DEBUG - 2024-06-18 18:29:13 --> Total execution time: 0.0372
INFO - 2024-06-18 18:29:20 --> Config Class Initialized
INFO - 2024-06-18 18:29:20 --> Hooks Class Initialized
DEBUG - 2024-06-18 18:29:20 --> UTF-8 Support Enabled
INFO - 2024-06-18 18:29:20 --> Utf8 Class Initialized
INFO - 2024-06-18 18:29:20 --> URI Class Initialized
INFO - 2024-06-18 18:29:20 --> Router Class Initialized
INFO - 2024-06-18 18:29:20 --> Output Class Initialized
INFO - 2024-06-18 18:29:20 --> Security Class Initialized
DEBUG - 2024-06-18 18:29:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-18 18:29:20 --> Input Class Initialized
INFO - 2024-06-18 18:29:20 --> Language Class Initialized
INFO - 2024-06-18 18:29:20 --> Language Class Initialized
INFO - 2024-06-18 18:29:20 --> Config Class Initialized
INFO - 2024-06-18 18:29:20 --> Loader Class Initialized
INFO - 2024-06-18 18:29:20 --> Helper loaded: url_helper
INFO - 2024-06-18 18:29:20 --> Helper loaded: file_helper
INFO - 2024-06-18 18:29:20 --> Helper loaded: form_helper
INFO - 2024-06-18 18:29:20 --> Helper loaded: my_helper
INFO - 2024-06-18 18:29:20 --> Database Driver Class Initialized
INFO - 2024-06-18 18:29:20 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-18 18:29:20 --> Controller Class Initialized
DEBUG - 2024-06-18 18:29:20 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/views/cetak_tahfiz.php
INFO - 2024-06-18 18:29:23 --> Final output sent to browser
DEBUG - 2024-06-18 18:29:23 --> Total execution time: 3.2527
INFO - 2024-06-18 18:32:02 --> Config Class Initialized
INFO - 2024-06-18 18:32:02 --> Hooks Class Initialized
DEBUG - 2024-06-18 18:32:02 --> UTF-8 Support Enabled
INFO - 2024-06-18 18:32:02 --> Utf8 Class Initialized
INFO - 2024-06-18 18:32:02 --> URI Class Initialized
INFO - 2024-06-18 18:32:02 --> Router Class Initialized
INFO - 2024-06-18 18:32:02 --> Output Class Initialized
INFO - 2024-06-18 18:32:02 --> Security Class Initialized
DEBUG - 2024-06-18 18:32:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-18 18:32:02 --> Input Class Initialized
INFO - 2024-06-18 18:32:02 --> Language Class Initialized
INFO - 2024-06-18 18:32:02 --> Language Class Initialized
INFO - 2024-06-18 18:32:02 --> Config Class Initialized
INFO - 2024-06-18 18:32:02 --> Loader Class Initialized
INFO - 2024-06-18 18:32:02 --> Helper loaded: url_helper
INFO - 2024-06-18 18:32:02 --> Helper loaded: file_helper
INFO - 2024-06-18 18:32:02 --> Helper loaded: form_helper
INFO - 2024-06-18 18:32:02 --> Helper loaded: my_helper
INFO - 2024-06-18 18:32:02 --> Database Driver Class Initialized
INFO - 2024-06-18 18:32:02 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-18 18:32:02 --> Controller Class Initialized
DEBUG - 2024-06-18 18:32:02 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/view_mapel/views/v_view_mapel.php
DEBUG - 2024-06-18 18:32:02 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-06-18 18:32:02 --> Final output sent to browser
DEBUG - 2024-06-18 18:32:02 --> Total execution time: 0.0451
INFO - 2024-06-18 18:32:42 --> Config Class Initialized
INFO - 2024-06-18 18:32:42 --> Hooks Class Initialized
DEBUG - 2024-06-18 18:32:42 --> UTF-8 Support Enabled
INFO - 2024-06-18 18:32:42 --> Utf8 Class Initialized
INFO - 2024-06-18 18:32:42 --> URI Class Initialized
INFO - 2024-06-18 18:32:42 --> Router Class Initialized
INFO - 2024-06-18 18:32:42 --> Output Class Initialized
INFO - 2024-06-18 18:32:42 --> Security Class Initialized
DEBUG - 2024-06-18 18:32:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-18 18:32:42 --> Input Class Initialized
INFO - 2024-06-18 18:32:42 --> Language Class Initialized
INFO - 2024-06-18 18:32:42 --> Language Class Initialized
INFO - 2024-06-18 18:32:42 --> Config Class Initialized
INFO - 2024-06-18 18:32:42 --> Loader Class Initialized
INFO - 2024-06-18 18:32:42 --> Helper loaded: url_helper
INFO - 2024-06-18 18:32:42 --> Helper loaded: file_helper
INFO - 2024-06-18 18:32:42 --> Helper loaded: form_helper
INFO - 2024-06-18 18:32:42 --> Helper loaded: my_helper
INFO - 2024-06-18 18:32:42 --> Database Driver Class Initialized
INFO - 2024-06-18 18:32:42 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-18 18:32:42 --> Controller Class Initialized
DEBUG - 2024-06-18 18:32:42 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/views/list.php
DEBUG - 2024-06-18 18:32:42 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-06-18 18:32:42 --> Final output sent to browser
DEBUG - 2024-06-18 18:32:42 --> Total execution time: 0.0321
INFO - 2024-06-18 18:32:42 --> Config Class Initialized
INFO - 2024-06-18 18:32:42 --> Hooks Class Initialized
DEBUG - 2024-06-18 18:32:42 --> UTF-8 Support Enabled
INFO - 2024-06-18 18:32:42 --> Utf8 Class Initialized
INFO - 2024-06-18 18:32:42 --> URI Class Initialized
INFO - 2024-06-18 18:32:42 --> Router Class Initialized
INFO - 2024-06-18 18:32:42 --> Output Class Initialized
INFO - 2024-06-18 18:32:42 --> Security Class Initialized
DEBUG - 2024-06-18 18:32:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-18 18:32:42 --> Input Class Initialized
INFO - 2024-06-18 18:32:42 --> Language Class Initialized
INFO - 2024-06-18 18:32:42 --> Language Class Initialized
INFO - 2024-06-18 18:32:42 --> Config Class Initialized
INFO - 2024-06-18 18:32:42 --> Loader Class Initialized
INFO - 2024-06-18 18:32:42 --> Helper loaded: url_helper
INFO - 2024-06-18 18:32:42 --> Helper loaded: file_helper
INFO - 2024-06-18 18:32:42 --> Helper loaded: form_helper
INFO - 2024-06-18 18:32:42 --> Helper loaded: my_helper
INFO - 2024-06-18 18:32:42 --> Database Driver Class Initialized
INFO - 2024-06-18 18:32:42 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-18 18:32:42 --> Controller Class Initialized
INFO - 2024-06-18 18:32:44 --> Config Class Initialized
INFO - 2024-06-18 18:32:44 --> Hooks Class Initialized
DEBUG - 2024-06-18 18:32:44 --> UTF-8 Support Enabled
INFO - 2024-06-18 18:32:44 --> Utf8 Class Initialized
INFO - 2024-06-18 18:32:44 --> URI Class Initialized
INFO - 2024-06-18 18:32:44 --> Router Class Initialized
INFO - 2024-06-18 18:32:44 --> Output Class Initialized
INFO - 2024-06-18 18:32:44 --> Security Class Initialized
DEBUG - 2024-06-18 18:32:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-18 18:32:44 --> Input Class Initialized
INFO - 2024-06-18 18:32:44 --> Language Class Initialized
INFO - 2024-06-18 18:32:44 --> Language Class Initialized
INFO - 2024-06-18 18:32:44 --> Config Class Initialized
INFO - 2024-06-18 18:32:44 --> Loader Class Initialized
INFO - 2024-06-18 18:32:44 --> Helper loaded: url_helper
INFO - 2024-06-18 18:32:44 --> Helper loaded: file_helper
INFO - 2024-06-18 18:32:44 --> Helper loaded: form_helper
INFO - 2024-06-18 18:32:44 --> Helper loaded: my_helper
INFO - 2024-06-18 18:32:44 --> Database Driver Class Initialized
INFO - 2024-06-18 18:32:44 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-18 18:32:44 --> Controller Class Initialized
INFO - 2024-06-18 18:32:44 --> Final output sent to browser
DEBUG - 2024-06-18 18:32:44 --> Total execution time: 0.0296
INFO - 2024-06-18 18:32:46 --> Config Class Initialized
INFO - 2024-06-18 18:32:46 --> Hooks Class Initialized
DEBUG - 2024-06-18 18:32:46 --> UTF-8 Support Enabled
INFO - 2024-06-18 18:32:46 --> Utf8 Class Initialized
INFO - 2024-06-18 18:32:46 --> URI Class Initialized
INFO - 2024-06-18 18:32:46 --> Router Class Initialized
INFO - 2024-06-18 18:32:46 --> Output Class Initialized
INFO - 2024-06-18 18:32:46 --> Security Class Initialized
DEBUG - 2024-06-18 18:32:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-18 18:32:46 --> Input Class Initialized
INFO - 2024-06-18 18:32:46 --> Language Class Initialized
INFO - 2024-06-18 18:32:46 --> Language Class Initialized
INFO - 2024-06-18 18:32:46 --> Config Class Initialized
INFO - 2024-06-18 18:32:46 --> Loader Class Initialized
INFO - 2024-06-18 18:32:46 --> Helper loaded: url_helper
INFO - 2024-06-18 18:32:46 --> Helper loaded: file_helper
INFO - 2024-06-18 18:32:46 --> Helper loaded: form_helper
INFO - 2024-06-18 18:32:46 --> Helper loaded: my_helper
INFO - 2024-06-18 18:32:46 --> Database Driver Class Initialized
INFO - 2024-06-18 18:32:46 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-18 18:32:46 --> Controller Class Initialized
INFO - 2024-06-18 18:32:46 --> Final output sent to browser
DEBUG - 2024-06-18 18:32:46 --> Total execution time: 0.0283
INFO - 2024-06-18 18:33:01 --> Config Class Initialized
INFO - 2024-06-18 18:33:01 --> Hooks Class Initialized
DEBUG - 2024-06-18 18:33:01 --> UTF-8 Support Enabled
INFO - 2024-06-18 18:33:01 --> Utf8 Class Initialized
INFO - 2024-06-18 18:33:01 --> URI Class Initialized
INFO - 2024-06-18 18:33:01 --> Router Class Initialized
INFO - 2024-06-18 18:33:01 --> Output Class Initialized
INFO - 2024-06-18 18:33:01 --> Security Class Initialized
DEBUG - 2024-06-18 18:33:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-18 18:33:02 --> Input Class Initialized
INFO - 2024-06-18 18:33:02 --> Language Class Initialized
INFO - 2024-06-18 18:33:02 --> Language Class Initialized
INFO - 2024-06-18 18:33:02 --> Config Class Initialized
INFO - 2024-06-18 18:33:02 --> Loader Class Initialized
INFO - 2024-06-18 18:33:02 --> Helper loaded: url_helper
INFO - 2024-06-18 18:33:02 --> Helper loaded: file_helper
INFO - 2024-06-18 18:33:02 --> Helper loaded: form_helper
INFO - 2024-06-18 18:33:02 --> Helper loaded: my_helper
INFO - 2024-06-18 18:33:02 --> Database Driver Class Initialized
INFO - 2024-06-18 18:33:02 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-18 18:33:02 --> Controller Class Initialized
DEBUG - 2024-06-18 18:33:02 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/view_mapel/views/v_view_mapel.php
DEBUG - 2024-06-18 18:33:02 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-06-18 18:33:02 --> Final output sent to browser
DEBUG - 2024-06-18 18:33:02 --> Total execution time: 0.0297
INFO - 2024-06-18 18:33:09 --> Config Class Initialized
INFO - 2024-06-18 18:33:09 --> Hooks Class Initialized
DEBUG - 2024-06-18 18:33:09 --> UTF-8 Support Enabled
INFO - 2024-06-18 18:33:09 --> Utf8 Class Initialized
INFO - 2024-06-18 18:33:09 --> URI Class Initialized
INFO - 2024-06-18 18:33:09 --> Router Class Initialized
INFO - 2024-06-18 18:33:09 --> Output Class Initialized
INFO - 2024-06-18 18:33:09 --> Security Class Initialized
DEBUG - 2024-06-18 18:33:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-18 18:33:09 --> Input Class Initialized
INFO - 2024-06-18 18:33:09 --> Language Class Initialized
INFO - 2024-06-18 18:33:09 --> Language Class Initialized
INFO - 2024-06-18 18:33:09 --> Config Class Initialized
INFO - 2024-06-18 18:33:09 --> Loader Class Initialized
INFO - 2024-06-18 18:33:09 --> Helper loaded: url_helper
INFO - 2024-06-18 18:33:09 --> Helper loaded: file_helper
INFO - 2024-06-18 18:33:09 --> Helper loaded: form_helper
INFO - 2024-06-18 18:33:09 --> Helper loaded: my_helper
INFO - 2024-06-18 18:33:09 --> Database Driver Class Initialized
INFO - 2024-06-18 18:33:09 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-18 18:33:09 --> Controller Class Initialized
DEBUG - 2024-06-18 18:33:09 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/view_mapel/views/v_view_mapel.php
DEBUG - 2024-06-18 18:33:09 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-06-18 18:33:09 --> Final output sent to browser
DEBUG - 2024-06-18 18:33:09 --> Total execution time: 0.0386
INFO - 2024-06-18 18:33:18 --> Config Class Initialized
INFO - 2024-06-18 18:33:18 --> Hooks Class Initialized
DEBUG - 2024-06-18 18:33:18 --> UTF-8 Support Enabled
INFO - 2024-06-18 18:33:18 --> Utf8 Class Initialized
INFO - 2024-06-18 18:33:18 --> URI Class Initialized
INFO - 2024-06-18 18:33:18 --> Router Class Initialized
INFO - 2024-06-18 18:33:18 --> Output Class Initialized
INFO - 2024-06-18 18:33:18 --> Security Class Initialized
DEBUG - 2024-06-18 18:33:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-18 18:33:18 --> Input Class Initialized
INFO - 2024-06-18 18:33:18 --> Language Class Initialized
INFO - 2024-06-18 18:33:18 --> Language Class Initialized
INFO - 2024-06-18 18:33:18 --> Config Class Initialized
INFO - 2024-06-18 18:33:18 --> Loader Class Initialized
INFO - 2024-06-18 18:33:18 --> Helper loaded: url_helper
INFO - 2024-06-18 18:33:18 --> Helper loaded: file_helper
INFO - 2024-06-18 18:33:18 --> Helper loaded: form_helper
INFO - 2024-06-18 18:33:18 --> Helper loaded: my_helper
INFO - 2024-06-18 18:33:18 --> Database Driver Class Initialized
INFO - 2024-06-18 18:33:18 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-18 18:33:18 --> Controller Class Initialized
DEBUG - 2024-06-18 18:33:18 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/views/list.php
DEBUG - 2024-06-18 18:33:18 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-06-18 18:33:18 --> Final output sent to browser
DEBUG - 2024-06-18 18:33:18 --> Total execution time: 0.0700
INFO - 2024-06-18 18:33:20 --> Config Class Initialized
INFO - 2024-06-18 18:33:20 --> Hooks Class Initialized
DEBUG - 2024-06-18 18:33:20 --> UTF-8 Support Enabled
INFO - 2024-06-18 18:33:20 --> Utf8 Class Initialized
INFO - 2024-06-18 18:33:20 --> URI Class Initialized
INFO - 2024-06-18 18:33:20 --> Router Class Initialized
INFO - 2024-06-18 18:33:20 --> Output Class Initialized
INFO - 2024-06-18 18:33:20 --> Security Class Initialized
DEBUG - 2024-06-18 18:33:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-18 18:33:20 --> Input Class Initialized
INFO - 2024-06-18 18:33:20 --> Language Class Initialized
INFO - 2024-06-18 18:33:20 --> Language Class Initialized
INFO - 2024-06-18 18:33:20 --> Config Class Initialized
INFO - 2024-06-18 18:33:20 --> Loader Class Initialized
INFO - 2024-06-18 18:33:20 --> Helper loaded: url_helper
INFO - 2024-06-18 18:33:20 --> Helper loaded: file_helper
INFO - 2024-06-18 18:33:20 --> Helper loaded: form_helper
INFO - 2024-06-18 18:33:20 --> Helper loaded: my_helper
INFO - 2024-06-18 18:33:20 --> Database Driver Class Initialized
INFO - 2024-06-18 18:33:20 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-18 18:33:20 --> Controller Class Initialized
DEBUG - 2024-06-18 18:33:20 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/views/cetak_tahfiz.php
INFO - 2024-06-18 18:33:24 --> Final output sent to browser
DEBUG - 2024-06-18 18:33:24 --> Total execution time: 3.5643
INFO - 2024-06-18 18:34:40 --> Config Class Initialized
INFO - 2024-06-18 18:34:40 --> Hooks Class Initialized
DEBUG - 2024-06-18 18:34:40 --> UTF-8 Support Enabled
INFO - 2024-06-18 18:34:40 --> Utf8 Class Initialized
INFO - 2024-06-18 18:34:40 --> URI Class Initialized
INFO - 2024-06-18 18:34:40 --> Router Class Initialized
INFO - 2024-06-18 18:34:40 --> Output Class Initialized
INFO - 2024-06-18 18:34:40 --> Security Class Initialized
DEBUG - 2024-06-18 18:34:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-18 18:34:40 --> Input Class Initialized
INFO - 2024-06-18 18:34:40 --> Language Class Initialized
INFO - 2024-06-18 18:34:40 --> Language Class Initialized
INFO - 2024-06-18 18:34:40 --> Config Class Initialized
INFO - 2024-06-18 18:34:40 --> Loader Class Initialized
INFO - 2024-06-18 18:34:40 --> Helper loaded: url_helper
INFO - 2024-06-18 18:34:40 --> Helper loaded: file_helper
INFO - 2024-06-18 18:34:40 --> Helper loaded: form_helper
INFO - 2024-06-18 18:34:40 --> Helper loaded: my_helper
INFO - 2024-06-18 18:34:40 --> Database Driver Class Initialized
INFO - 2024-06-18 18:34:40 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-18 18:34:40 --> Controller Class Initialized
DEBUG - 2024-06-18 18:34:40 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/view_mapel/views/v_view_mapel.php
DEBUG - 2024-06-18 18:34:40 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-06-18 18:34:40 --> Final output sent to browser
DEBUG - 2024-06-18 18:34:40 --> Total execution time: 0.1431
INFO - 2024-06-18 18:34:41 --> Config Class Initialized
INFO - 2024-06-18 18:34:41 --> Hooks Class Initialized
DEBUG - 2024-06-18 18:34:41 --> UTF-8 Support Enabled
INFO - 2024-06-18 18:34:41 --> Utf8 Class Initialized
INFO - 2024-06-18 18:34:41 --> URI Class Initialized
INFO - 2024-06-18 18:34:41 --> Router Class Initialized
INFO - 2024-06-18 18:34:41 --> Output Class Initialized
INFO - 2024-06-18 18:34:41 --> Security Class Initialized
DEBUG - 2024-06-18 18:34:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-18 18:34:41 --> Input Class Initialized
INFO - 2024-06-18 18:34:41 --> Language Class Initialized
INFO - 2024-06-18 18:34:41 --> Language Class Initialized
INFO - 2024-06-18 18:34:41 --> Config Class Initialized
INFO - 2024-06-18 18:34:41 --> Loader Class Initialized
INFO - 2024-06-18 18:34:41 --> Helper loaded: url_helper
INFO - 2024-06-18 18:34:41 --> Helper loaded: file_helper
INFO - 2024-06-18 18:34:41 --> Helper loaded: form_helper
INFO - 2024-06-18 18:34:41 --> Helper loaded: my_helper
INFO - 2024-06-18 18:34:41 --> Database Driver Class Initialized
INFO - 2024-06-18 18:34:41 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-18 18:34:41 --> Controller Class Initialized
DEBUG - 2024-06-18 18:34:41 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/views/list.php
DEBUG - 2024-06-18 18:34:41 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-06-18 18:34:41 --> Final output sent to browser
DEBUG - 2024-06-18 18:34:41 --> Total execution time: 0.0293
INFO - 2024-06-18 18:34:42 --> Config Class Initialized
INFO - 2024-06-18 18:34:42 --> Hooks Class Initialized
DEBUG - 2024-06-18 18:34:42 --> UTF-8 Support Enabled
INFO - 2024-06-18 18:34:42 --> Utf8 Class Initialized
INFO - 2024-06-18 18:34:42 --> URI Class Initialized
INFO - 2024-06-18 18:34:42 --> Router Class Initialized
INFO - 2024-06-18 18:34:42 --> Output Class Initialized
INFO - 2024-06-18 18:34:42 --> Security Class Initialized
DEBUG - 2024-06-18 18:34:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-18 18:34:42 --> Input Class Initialized
INFO - 2024-06-18 18:34:42 --> Language Class Initialized
INFO - 2024-06-18 18:34:42 --> Language Class Initialized
INFO - 2024-06-18 18:34:42 --> Config Class Initialized
INFO - 2024-06-18 18:34:42 --> Loader Class Initialized
INFO - 2024-06-18 18:34:42 --> Helper loaded: url_helper
INFO - 2024-06-18 18:34:42 --> Helper loaded: file_helper
INFO - 2024-06-18 18:34:42 --> Helper loaded: form_helper
INFO - 2024-06-18 18:34:42 --> Helper loaded: my_helper
INFO - 2024-06-18 18:34:42 --> Database Driver Class Initialized
INFO - 2024-06-18 18:34:42 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-18 18:34:42 --> Controller Class Initialized
INFO - 2024-06-18 18:34:44 --> Config Class Initialized
INFO - 2024-06-18 18:34:44 --> Hooks Class Initialized
DEBUG - 2024-06-18 18:34:44 --> UTF-8 Support Enabled
INFO - 2024-06-18 18:34:44 --> Utf8 Class Initialized
INFO - 2024-06-18 18:34:44 --> URI Class Initialized
INFO - 2024-06-18 18:34:44 --> Router Class Initialized
INFO - 2024-06-18 18:34:44 --> Output Class Initialized
INFO - 2024-06-18 18:34:44 --> Security Class Initialized
DEBUG - 2024-06-18 18:34:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-18 18:34:44 --> Input Class Initialized
INFO - 2024-06-18 18:34:44 --> Language Class Initialized
INFO - 2024-06-18 18:34:44 --> Language Class Initialized
INFO - 2024-06-18 18:34:44 --> Config Class Initialized
INFO - 2024-06-18 18:34:44 --> Loader Class Initialized
INFO - 2024-06-18 18:34:44 --> Helper loaded: url_helper
INFO - 2024-06-18 18:34:44 --> Helper loaded: file_helper
INFO - 2024-06-18 18:34:44 --> Helper loaded: form_helper
INFO - 2024-06-18 18:34:44 --> Helper loaded: my_helper
INFO - 2024-06-18 18:34:44 --> Database Driver Class Initialized
INFO - 2024-06-18 18:34:44 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-18 18:34:44 --> Controller Class Initialized
INFO - 2024-06-18 18:34:44 --> Final output sent to browser
DEBUG - 2024-06-18 18:34:44 --> Total execution time: 0.0398
INFO - 2024-06-18 18:35:02 --> Config Class Initialized
INFO - 2024-06-18 18:35:02 --> Hooks Class Initialized
DEBUG - 2024-06-18 18:35:02 --> UTF-8 Support Enabled
INFO - 2024-06-18 18:35:02 --> Utf8 Class Initialized
INFO - 2024-06-18 18:35:02 --> URI Class Initialized
INFO - 2024-06-18 18:35:02 --> Router Class Initialized
INFO - 2024-06-18 18:35:02 --> Output Class Initialized
INFO - 2024-06-18 18:35:02 --> Security Class Initialized
DEBUG - 2024-06-18 18:35:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-18 18:35:02 --> Input Class Initialized
INFO - 2024-06-18 18:35:02 --> Language Class Initialized
INFO - 2024-06-18 18:35:02 --> Language Class Initialized
INFO - 2024-06-18 18:35:02 --> Config Class Initialized
INFO - 2024-06-18 18:35:02 --> Loader Class Initialized
INFO - 2024-06-18 18:35:02 --> Helper loaded: url_helper
INFO - 2024-06-18 18:35:02 --> Helper loaded: file_helper
INFO - 2024-06-18 18:35:02 --> Helper loaded: form_helper
INFO - 2024-06-18 18:35:02 --> Helper loaded: my_helper
INFO - 2024-06-18 18:35:02 --> Database Driver Class Initialized
INFO - 2024-06-18 18:35:02 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-18 18:35:02 --> Controller Class Initialized
DEBUG - 2024-06-18 18:35:02 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/views/list.php
DEBUG - 2024-06-18 18:35:02 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-06-18 18:35:02 --> Final output sent to browser
DEBUG - 2024-06-18 18:35:02 --> Total execution time: 0.0457
INFO - 2024-06-18 18:35:04 --> Config Class Initialized
INFO - 2024-06-18 18:35:04 --> Hooks Class Initialized
DEBUG - 2024-06-18 18:35:04 --> UTF-8 Support Enabled
INFO - 2024-06-18 18:35:04 --> Utf8 Class Initialized
INFO - 2024-06-18 18:35:04 --> URI Class Initialized
INFO - 2024-06-18 18:35:04 --> Router Class Initialized
INFO - 2024-06-18 18:35:04 --> Output Class Initialized
INFO - 2024-06-18 18:35:04 --> Security Class Initialized
DEBUG - 2024-06-18 18:35:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-18 18:35:04 --> Input Class Initialized
INFO - 2024-06-18 18:35:04 --> Language Class Initialized
INFO - 2024-06-18 18:35:04 --> Language Class Initialized
INFO - 2024-06-18 18:35:04 --> Config Class Initialized
INFO - 2024-06-18 18:35:04 --> Loader Class Initialized
INFO - 2024-06-18 18:35:04 --> Helper loaded: url_helper
INFO - 2024-06-18 18:35:04 --> Helper loaded: file_helper
INFO - 2024-06-18 18:35:04 --> Helper loaded: form_helper
INFO - 2024-06-18 18:35:04 --> Helper loaded: my_helper
INFO - 2024-06-18 18:35:04 --> Database Driver Class Initialized
INFO - 2024-06-18 18:35:04 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-18 18:35:04 --> Controller Class Initialized
INFO - 2024-06-18 18:35:07 --> Config Class Initialized
INFO - 2024-06-18 18:35:07 --> Hooks Class Initialized
DEBUG - 2024-06-18 18:35:07 --> UTF-8 Support Enabled
INFO - 2024-06-18 18:35:07 --> Utf8 Class Initialized
INFO - 2024-06-18 18:35:07 --> URI Class Initialized
INFO - 2024-06-18 18:35:07 --> Router Class Initialized
INFO - 2024-06-18 18:35:07 --> Output Class Initialized
INFO - 2024-06-18 18:35:07 --> Security Class Initialized
DEBUG - 2024-06-18 18:35:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-18 18:35:07 --> Input Class Initialized
INFO - 2024-06-18 18:35:07 --> Language Class Initialized
INFO - 2024-06-18 18:35:07 --> Language Class Initialized
INFO - 2024-06-18 18:35:07 --> Config Class Initialized
INFO - 2024-06-18 18:35:07 --> Loader Class Initialized
INFO - 2024-06-18 18:35:07 --> Helper loaded: url_helper
INFO - 2024-06-18 18:35:07 --> Helper loaded: file_helper
INFO - 2024-06-18 18:35:07 --> Helper loaded: form_helper
INFO - 2024-06-18 18:35:07 --> Helper loaded: my_helper
INFO - 2024-06-18 18:35:07 --> Database Driver Class Initialized
INFO - 2024-06-18 18:35:07 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-18 18:35:07 --> Controller Class Initialized
INFO - 2024-06-18 18:35:08 --> Config Class Initialized
INFO - 2024-06-18 18:35:08 --> Hooks Class Initialized
DEBUG - 2024-06-18 18:35:08 --> UTF-8 Support Enabled
INFO - 2024-06-18 18:35:08 --> Utf8 Class Initialized
INFO - 2024-06-18 18:35:08 --> URI Class Initialized
INFO - 2024-06-18 18:35:08 --> Router Class Initialized
INFO - 2024-06-18 18:35:08 --> Output Class Initialized
INFO - 2024-06-18 18:35:08 --> Security Class Initialized
DEBUG - 2024-06-18 18:35:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-18 18:35:08 --> Input Class Initialized
INFO - 2024-06-18 18:35:08 --> Language Class Initialized
INFO - 2024-06-18 18:35:08 --> Language Class Initialized
INFO - 2024-06-18 18:35:08 --> Config Class Initialized
INFO - 2024-06-18 18:35:08 --> Loader Class Initialized
INFO - 2024-06-18 18:35:08 --> Helper loaded: url_helper
INFO - 2024-06-18 18:35:08 --> Helper loaded: file_helper
INFO - 2024-06-18 18:35:08 --> Helper loaded: form_helper
INFO - 2024-06-18 18:35:08 --> Helper loaded: my_helper
INFO - 2024-06-18 18:35:08 --> Database Driver Class Initialized
INFO - 2024-06-18 18:35:08 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-18 18:35:08 --> Controller Class Initialized
DEBUG - 2024-06-18 18:35:08 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/login/views/login.php
DEBUG - 2024-06-18 18:35:08 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-06-18 18:35:08 --> Final output sent to browser
DEBUG - 2024-06-18 18:35:08 --> Total execution time: 0.0314
INFO - 2024-06-18 18:35:10 --> Config Class Initialized
INFO - 2024-06-18 18:35:10 --> Hooks Class Initialized
DEBUG - 2024-06-18 18:35:10 --> UTF-8 Support Enabled
INFO - 2024-06-18 18:35:10 --> Utf8 Class Initialized
INFO - 2024-06-18 18:35:10 --> URI Class Initialized
INFO - 2024-06-18 18:35:10 --> Router Class Initialized
INFO - 2024-06-18 18:35:10 --> Output Class Initialized
INFO - 2024-06-18 18:35:10 --> Security Class Initialized
DEBUG - 2024-06-18 18:35:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-18 18:35:10 --> Input Class Initialized
INFO - 2024-06-18 18:35:10 --> Language Class Initialized
INFO - 2024-06-18 18:35:10 --> Language Class Initialized
INFO - 2024-06-18 18:35:10 --> Config Class Initialized
INFO - 2024-06-18 18:35:10 --> Loader Class Initialized
INFO - 2024-06-18 18:35:10 --> Helper loaded: url_helper
INFO - 2024-06-18 18:35:10 --> Helper loaded: file_helper
INFO - 2024-06-18 18:35:10 --> Helper loaded: form_helper
INFO - 2024-06-18 18:35:10 --> Helper loaded: my_helper
INFO - 2024-06-18 18:35:10 --> Database Driver Class Initialized
INFO - 2024-06-18 18:35:10 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-18 18:35:10 --> Controller Class Initialized
INFO - 2024-06-18 18:35:10 --> Helper loaded: cookie_helper
INFO - 2024-06-18 18:35:10 --> Final output sent to browser
DEBUG - 2024-06-18 18:35:10 --> Total execution time: 0.0398
INFO - 2024-06-18 18:35:10 --> Config Class Initialized
INFO - 2024-06-18 18:35:10 --> Hooks Class Initialized
DEBUG - 2024-06-18 18:35:10 --> UTF-8 Support Enabled
INFO - 2024-06-18 18:35:10 --> Utf8 Class Initialized
INFO - 2024-06-18 18:35:10 --> URI Class Initialized
INFO - 2024-06-18 18:35:10 --> Router Class Initialized
INFO - 2024-06-18 18:35:10 --> Output Class Initialized
INFO - 2024-06-18 18:35:10 --> Security Class Initialized
DEBUG - 2024-06-18 18:35:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-18 18:35:10 --> Input Class Initialized
INFO - 2024-06-18 18:35:10 --> Language Class Initialized
INFO - 2024-06-18 18:35:10 --> Language Class Initialized
INFO - 2024-06-18 18:35:10 --> Config Class Initialized
INFO - 2024-06-18 18:35:10 --> Loader Class Initialized
INFO - 2024-06-18 18:35:10 --> Helper loaded: url_helper
INFO - 2024-06-18 18:35:10 --> Helper loaded: file_helper
INFO - 2024-06-18 18:35:10 --> Helper loaded: form_helper
INFO - 2024-06-18 18:35:10 --> Helper loaded: my_helper
INFO - 2024-06-18 18:35:10 --> Database Driver Class Initialized
INFO - 2024-06-18 18:35:10 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-18 18:35:10 --> Controller Class Initialized
INFO - 2024-06-18 18:35:10 --> Final output sent to browser
DEBUG - 2024-06-18 18:35:10 --> Total execution time: 0.0395
INFO - 2024-06-18 18:35:10 --> Config Class Initialized
INFO - 2024-06-18 18:35:10 --> Hooks Class Initialized
DEBUG - 2024-06-18 18:35:10 --> UTF-8 Support Enabled
INFO - 2024-06-18 18:35:10 --> Utf8 Class Initialized
INFO - 2024-06-18 18:35:10 --> URI Class Initialized
INFO - 2024-06-18 18:35:10 --> Router Class Initialized
INFO - 2024-06-18 18:35:10 --> Output Class Initialized
INFO - 2024-06-18 18:35:10 --> Security Class Initialized
DEBUG - 2024-06-18 18:35:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-18 18:35:10 --> Input Class Initialized
INFO - 2024-06-18 18:35:10 --> Language Class Initialized
INFO - 2024-06-18 18:35:10 --> Language Class Initialized
INFO - 2024-06-18 18:35:10 --> Config Class Initialized
INFO - 2024-06-18 18:35:10 --> Loader Class Initialized
INFO - 2024-06-18 18:35:10 --> Helper loaded: url_helper
INFO - 2024-06-18 18:35:10 --> Helper loaded: file_helper
INFO - 2024-06-18 18:35:10 --> Helper loaded: form_helper
INFO - 2024-06-18 18:35:10 --> Helper loaded: my_helper
INFO - 2024-06-18 18:35:10 --> Database Driver Class Initialized
INFO - 2024-06-18 18:35:10 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-18 18:35:10 --> Controller Class Initialized
INFO - 2024-06-18 18:35:10 --> Config Class Initialized
INFO - 2024-06-18 18:35:10 --> Hooks Class Initialized
DEBUG - 2024-06-18 18:35:10 --> UTF-8 Support Enabled
INFO - 2024-06-18 18:35:10 --> Utf8 Class Initialized
INFO - 2024-06-18 18:35:10 --> URI Class Initialized
INFO - 2024-06-18 18:35:10 --> Router Class Initialized
INFO - 2024-06-18 18:35:10 --> Output Class Initialized
INFO - 2024-06-18 18:35:10 --> Security Class Initialized
DEBUG - 2024-06-18 18:35:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-18 18:35:10 --> Input Class Initialized
INFO - 2024-06-18 18:35:10 --> Language Class Initialized
INFO - 2024-06-18 18:35:10 --> Language Class Initialized
INFO - 2024-06-18 18:35:10 --> Config Class Initialized
INFO - 2024-06-18 18:35:10 --> Loader Class Initialized
INFO - 2024-06-18 18:35:10 --> Helper loaded: url_helper
INFO - 2024-06-18 18:35:10 --> Helper loaded: file_helper
INFO - 2024-06-18 18:35:10 --> Helper loaded: form_helper
INFO - 2024-06-18 18:35:10 --> Helper loaded: my_helper
INFO - 2024-06-18 18:35:10 --> Database Driver Class Initialized
INFO - 2024-06-18 18:35:10 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-18 18:35:10 --> Controller Class Initialized
DEBUG - 2024-06-18 18:35:10 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/home/views/v_home_guru.php
DEBUG - 2024-06-18 18:35:10 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-06-18 18:35:10 --> Final output sent to browser
DEBUG - 2024-06-18 18:35:10 --> Total execution time: 0.0290
INFO - 2024-06-18 18:35:11 --> Config Class Initialized
INFO - 2024-06-18 18:35:11 --> Hooks Class Initialized
DEBUG - 2024-06-18 18:35:11 --> UTF-8 Support Enabled
INFO - 2024-06-18 18:35:11 --> Utf8 Class Initialized
INFO - 2024-06-18 18:35:11 --> URI Class Initialized
INFO - 2024-06-18 18:35:11 --> Router Class Initialized
INFO - 2024-06-18 18:35:11 --> Output Class Initialized
INFO - 2024-06-18 18:35:11 --> Security Class Initialized
DEBUG - 2024-06-18 18:35:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-18 18:35:11 --> Input Class Initialized
INFO - 2024-06-18 18:35:11 --> Language Class Initialized
INFO - 2024-06-18 18:35:11 --> Language Class Initialized
INFO - 2024-06-18 18:35:11 --> Config Class Initialized
INFO - 2024-06-18 18:35:11 --> Loader Class Initialized
INFO - 2024-06-18 18:35:11 --> Helper loaded: url_helper
INFO - 2024-06-18 18:35:11 --> Helper loaded: file_helper
INFO - 2024-06-18 18:35:11 --> Helper loaded: form_helper
INFO - 2024-06-18 18:35:11 --> Helper loaded: my_helper
INFO - 2024-06-18 18:35:11 --> Database Driver Class Initialized
INFO - 2024-06-18 18:35:11 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-18 18:35:11 --> Controller Class Initialized
INFO - 2024-06-18 18:35:11 --> Final output sent to browser
DEBUG - 2024-06-18 18:35:11 --> Total execution time: 0.0494
INFO - 2024-06-18 18:35:21 --> Config Class Initialized
INFO - 2024-06-18 18:35:21 --> Hooks Class Initialized
DEBUG - 2024-06-18 18:35:21 --> UTF-8 Support Enabled
INFO - 2024-06-18 18:35:21 --> Utf8 Class Initialized
INFO - 2024-06-18 18:35:21 --> URI Class Initialized
INFO - 2024-06-18 18:35:21 --> Router Class Initialized
INFO - 2024-06-18 18:35:21 --> Output Class Initialized
INFO - 2024-06-18 18:35:21 --> Security Class Initialized
DEBUG - 2024-06-18 18:35:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-18 18:35:21 --> Input Class Initialized
INFO - 2024-06-18 18:35:21 --> Language Class Initialized
INFO - 2024-06-18 18:35:21 --> Language Class Initialized
INFO - 2024-06-18 18:35:21 --> Config Class Initialized
INFO - 2024-06-18 18:35:21 --> Loader Class Initialized
INFO - 2024-06-18 18:35:21 --> Helper loaded: url_helper
INFO - 2024-06-18 18:35:21 --> Helper loaded: file_helper
INFO - 2024-06-18 18:35:21 --> Helper loaded: form_helper
INFO - 2024-06-18 18:35:21 --> Helper loaded: my_helper
INFO - 2024-06-18 18:35:21 --> Database Driver Class Initialized
INFO - 2024-06-18 18:35:21 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-18 18:35:21 --> Controller Class Initialized
DEBUG - 2024-06-18 18:35:21 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/view_mapel/views/v_view_mapel.php
DEBUG - 2024-06-18 18:35:21 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-06-18 18:35:21 --> Final output sent to browser
DEBUG - 2024-06-18 18:35:21 --> Total execution time: 0.0383
INFO - 2024-06-18 18:35:23 --> Config Class Initialized
INFO - 2024-06-18 18:35:23 --> Hooks Class Initialized
DEBUG - 2024-06-18 18:35:23 --> UTF-8 Support Enabled
INFO - 2024-06-18 18:35:23 --> Utf8 Class Initialized
INFO - 2024-06-18 18:35:23 --> URI Class Initialized
INFO - 2024-06-18 18:35:23 --> Router Class Initialized
INFO - 2024-06-18 18:35:23 --> Output Class Initialized
INFO - 2024-06-18 18:35:23 --> Security Class Initialized
DEBUG - 2024-06-18 18:35:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-18 18:35:23 --> Input Class Initialized
INFO - 2024-06-18 18:35:23 --> Language Class Initialized
INFO - 2024-06-18 18:35:23 --> Language Class Initialized
INFO - 2024-06-18 18:35:23 --> Config Class Initialized
INFO - 2024-06-18 18:35:23 --> Loader Class Initialized
INFO - 2024-06-18 18:35:23 --> Helper loaded: url_helper
INFO - 2024-06-18 18:35:23 --> Helper loaded: file_helper
INFO - 2024-06-18 18:35:23 --> Helper loaded: form_helper
INFO - 2024-06-18 18:35:23 --> Helper loaded: my_helper
INFO - 2024-06-18 18:35:23 --> Database Driver Class Initialized
INFO - 2024-06-18 18:35:23 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-18 18:35:23 --> Controller Class Initialized
DEBUG - 2024-06-18 18:35:23 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/views/list.php
DEBUG - 2024-06-18 18:35:23 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-06-18 18:35:23 --> Final output sent to browser
DEBUG - 2024-06-18 18:35:23 --> Total execution time: 0.0484
INFO - 2024-06-18 18:35:24 --> Config Class Initialized
INFO - 2024-06-18 18:35:24 --> Hooks Class Initialized
DEBUG - 2024-06-18 18:35:24 --> UTF-8 Support Enabled
INFO - 2024-06-18 18:35:24 --> Utf8 Class Initialized
INFO - 2024-06-18 18:35:24 --> URI Class Initialized
INFO - 2024-06-18 18:35:24 --> Router Class Initialized
INFO - 2024-06-18 18:35:24 --> Output Class Initialized
INFO - 2024-06-18 18:35:24 --> Security Class Initialized
DEBUG - 2024-06-18 18:35:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-18 18:35:24 --> Input Class Initialized
INFO - 2024-06-18 18:35:24 --> Language Class Initialized
INFO - 2024-06-18 18:35:24 --> Language Class Initialized
INFO - 2024-06-18 18:35:24 --> Config Class Initialized
INFO - 2024-06-18 18:35:24 --> Loader Class Initialized
INFO - 2024-06-18 18:35:24 --> Helper loaded: url_helper
INFO - 2024-06-18 18:35:24 --> Helper loaded: file_helper
INFO - 2024-06-18 18:35:24 --> Helper loaded: form_helper
INFO - 2024-06-18 18:35:24 --> Helper loaded: my_helper
INFO - 2024-06-18 18:35:24 --> Database Driver Class Initialized
INFO - 2024-06-18 18:35:24 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-18 18:35:24 --> Controller Class Initialized
INFO - 2024-06-18 18:35:26 --> Config Class Initialized
INFO - 2024-06-18 18:35:26 --> Hooks Class Initialized
DEBUG - 2024-06-18 18:35:26 --> UTF-8 Support Enabled
INFO - 2024-06-18 18:35:26 --> Utf8 Class Initialized
INFO - 2024-06-18 18:35:26 --> URI Class Initialized
INFO - 2024-06-18 18:35:26 --> Router Class Initialized
INFO - 2024-06-18 18:35:26 --> Output Class Initialized
INFO - 2024-06-18 18:35:26 --> Security Class Initialized
DEBUG - 2024-06-18 18:35:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-18 18:35:26 --> Input Class Initialized
INFO - 2024-06-18 18:35:26 --> Language Class Initialized
INFO - 2024-06-18 18:35:26 --> Language Class Initialized
INFO - 2024-06-18 18:35:26 --> Config Class Initialized
INFO - 2024-06-18 18:35:26 --> Loader Class Initialized
INFO - 2024-06-18 18:35:26 --> Helper loaded: url_helper
INFO - 2024-06-18 18:35:26 --> Helper loaded: file_helper
INFO - 2024-06-18 18:35:26 --> Helper loaded: form_helper
INFO - 2024-06-18 18:35:26 --> Helper loaded: my_helper
INFO - 2024-06-18 18:35:26 --> Database Driver Class Initialized
INFO - 2024-06-18 18:35:26 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-18 18:35:26 --> Controller Class Initialized
INFO - 2024-06-18 18:35:26 --> Final output sent to browser
DEBUG - 2024-06-18 18:35:26 --> Total execution time: 0.0546
INFO - 2024-06-18 18:35:28 --> Config Class Initialized
INFO - 2024-06-18 18:35:28 --> Hooks Class Initialized
DEBUG - 2024-06-18 18:35:28 --> UTF-8 Support Enabled
INFO - 2024-06-18 18:35:28 --> Utf8 Class Initialized
INFO - 2024-06-18 18:35:28 --> URI Class Initialized
INFO - 2024-06-18 18:35:28 --> Router Class Initialized
INFO - 2024-06-18 18:35:28 --> Output Class Initialized
INFO - 2024-06-18 18:35:28 --> Security Class Initialized
DEBUG - 2024-06-18 18:35:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-18 18:35:28 --> Input Class Initialized
INFO - 2024-06-18 18:35:28 --> Language Class Initialized
INFO - 2024-06-18 18:35:28 --> Language Class Initialized
INFO - 2024-06-18 18:35:28 --> Config Class Initialized
INFO - 2024-06-18 18:35:28 --> Loader Class Initialized
INFO - 2024-06-18 18:35:28 --> Helper loaded: url_helper
INFO - 2024-06-18 18:35:28 --> Helper loaded: file_helper
INFO - 2024-06-18 18:35:28 --> Helper loaded: form_helper
INFO - 2024-06-18 18:35:28 --> Helper loaded: my_helper
INFO - 2024-06-18 18:35:28 --> Database Driver Class Initialized
INFO - 2024-06-18 18:35:28 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-18 18:35:28 --> Controller Class Initialized
INFO - 2024-06-18 18:35:28 --> Final output sent to browser
DEBUG - 2024-06-18 18:35:28 --> Total execution time: 0.0275
INFO - 2024-06-18 18:35:28 --> Config Class Initialized
INFO - 2024-06-18 18:35:28 --> Hooks Class Initialized
DEBUG - 2024-06-18 18:35:28 --> UTF-8 Support Enabled
INFO - 2024-06-18 18:35:28 --> Utf8 Class Initialized
INFO - 2024-06-18 18:35:28 --> URI Class Initialized
INFO - 2024-06-18 18:35:28 --> Router Class Initialized
INFO - 2024-06-18 18:35:28 --> Output Class Initialized
INFO - 2024-06-18 18:35:28 --> Security Class Initialized
DEBUG - 2024-06-18 18:35:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-18 18:35:28 --> Input Class Initialized
INFO - 2024-06-18 18:35:28 --> Language Class Initialized
INFO - 2024-06-18 18:35:28 --> Language Class Initialized
INFO - 2024-06-18 18:35:28 --> Config Class Initialized
INFO - 2024-06-18 18:35:28 --> Loader Class Initialized
INFO - 2024-06-18 18:35:28 --> Helper loaded: url_helper
INFO - 2024-06-18 18:35:28 --> Helper loaded: file_helper
INFO - 2024-06-18 18:35:28 --> Helper loaded: form_helper
INFO - 2024-06-18 18:35:28 --> Helper loaded: my_helper
INFO - 2024-06-18 18:35:28 --> Database Driver Class Initialized
INFO - 2024-06-18 18:35:28 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-18 18:35:28 --> Controller Class Initialized
INFO - 2024-06-18 18:35:30 --> Config Class Initialized
INFO - 2024-06-18 18:35:30 --> Hooks Class Initialized
DEBUG - 2024-06-18 18:35:30 --> UTF-8 Support Enabled
INFO - 2024-06-18 18:35:30 --> Utf8 Class Initialized
INFO - 2024-06-18 18:35:30 --> URI Class Initialized
INFO - 2024-06-18 18:35:30 --> Router Class Initialized
INFO - 2024-06-18 18:35:30 --> Output Class Initialized
INFO - 2024-06-18 18:35:30 --> Security Class Initialized
DEBUG - 2024-06-18 18:35:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-18 18:35:30 --> Input Class Initialized
INFO - 2024-06-18 18:35:30 --> Language Class Initialized
INFO - 2024-06-18 18:35:30 --> Language Class Initialized
INFO - 2024-06-18 18:35:30 --> Config Class Initialized
INFO - 2024-06-18 18:35:30 --> Loader Class Initialized
INFO - 2024-06-18 18:35:30 --> Helper loaded: url_helper
INFO - 2024-06-18 18:35:30 --> Helper loaded: file_helper
INFO - 2024-06-18 18:35:30 --> Helper loaded: form_helper
INFO - 2024-06-18 18:35:30 --> Helper loaded: my_helper
INFO - 2024-06-18 18:35:30 --> Database Driver Class Initialized
INFO - 2024-06-18 18:35:30 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-18 18:35:30 --> Controller Class Initialized
INFO - 2024-06-18 18:35:30 --> Final output sent to browser
DEBUG - 2024-06-18 18:35:30 --> Total execution time: 0.0623
INFO - 2024-06-18 18:35:41 --> Config Class Initialized
INFO - 2024-06-18 18:35:41 --> Hooks Class Initialized
DEBUG - 2024-06-18 18:35:41 --> UTF-8 Support Enabled
INFO - 2024-06-18 18:35:41 --> Utf8 Class Initialized
INFO - 2024-06-18 18:35:41 --> URI Class Initialized
INFO - 2024-06-18 18:35:41 --> Router Class Initialized
INFO - 2024-06-18 18:35:41 --> Output Class Initialized
INFO - 2024-06-18 18:35:41 --> Security Class Initialized
DEBUG - 2024-06-18 18:35:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-18 18:35:41 --> Input Class Initialized
INFO - 2024-06-18 18:35:41 --> Language Class Initialized
INFO - 2024-06-18 18:35:41 --> Language Class Initialized
INFO - 2024-06-18 18:35:41 --> Config Class Initialized
INFO - 2024-06-18 18:35:41 --> Loader Class Initialized
INFO - 2024-06-18 18:35:41 --> Helper loaded: url_helper
INFO - 2024-06-18 18:35:41 --> Helper loaded: file_helper
INFO - 2024-06-18 18:35:41 --> Helper loaded: form_helper
INFO - 2024-06-18 18:35:41 --> Helper loaded: my_helper
INFO - 2024-06-18 18:35:41 --> Database Driver Class Initialized
INFO - 2024-06-18 18:35:41 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-18 18:35:41 --> Controller Class Initialized
INFO - 2024-06-18 18:35:41 --> Final output sent to browser
DEBUG - 2024-06-18 18:35:41 --> Total execution time: 0.0304
INFO - 2024-06-18 18:35:41 --> Config Class Initialized
INFO - 2024-06-18 18:35:41 --> Hooks Class Initialized
DEBUG - 2024-06-18 18:35:41 --> UTF-8 Support Enabled
INFO - 2024-06-18 18:35:41 --> Utf8 Class Initialized
INFO - 2024-06-18 18:35:41 --> URI Class Initialized
INFO - 2024-06-18 18:35:41 --> Router Class Initialized
INFO - 2024-06-18 18:35:41 --> Output Class Initialized
INFO - 2024-06-18 18:35:41 --> Security Class Initialized
DEBUG - 2024-06-18 18:35:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-18 18:35:41 --> Input Class Initialized
INFO - 2024-06-18 18:35:41 --> Language Class Initialized
INFO - 2024-06-18 18:35:41 --> Language Class Initialized
INFO - 2024-06-18 18:35:41 --> Config Class Initialized
INFO - 2024-06-18 18:35:41 --> Loader Class Initialized
INFO - 2024-06-18 18:35:41 --> Helper loaded: url_helper
INFO - 2024-06-18 18:35:41 --> Helper loaded: file_helper
INFO - 2024-06-18 18:35:41 --> Helper loaded: form_helper
INFO - 2024-06-18 18:35:41 --> Helper loaded: my_helper
INFO - 2024-06-18 18:35:41 --> Database Driver Class Initialized
INFO - 2024-06-18 18:35:41 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-18 18:35:41 --> Controller Class Initialized
INFO - 2024-06-18 18:35:43 --> Config Class Initialized
INFO - 2024-06-18 18:35:43 --> Hooks Class Initialized
DEBUG - 2024-06-18 18:35:43 --> UTF-8 Support Enabled
INFO - 2024-06-18 18:35:43 --> Utf8 Class Initialized
INFO - 2024-06-18 18:35:43 --> URI Class Initialized
INFO - 2024-06-18 18:35:43 --> Router Class Initialized
INFO - 2024-06-18 18:35:43 --> Output Class Initialized
INFO - 2024-06-18 18:35:43 --> Security Class Initialized
DEBUG - 2024-06-18 18:35:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-18 18:35:43 --> Input Class Initialized
INFO - 2024-06-18 18:35:43 --> Language Class Initialized
INFO - 2024-06-18 18:35:43 --> Language Class Initialized
INFO - 2024-06-18 18:35:43 --> Config Class Initialized
INFO - 2024-06-18 18:35:43 --> Loader Class Initialized
INFO - 2024-06-18 18:35:43 --> Helper loaded: url_helper
INFO - 2024-06-18 18:35:43 --> Helper loaded: file_helper
INFO - 2024-06-18 18:35:43 --> Helper loaded: form_helper
INFO - 2024-06-18 18:35:43 --> Helper loaded: my_helper
INFO - 2024-06-18 18:35:43 --> Database Driver Class Initialized
INFO - 2024-06-18 18:35:43 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-18 18:35:43 --> Controller Class Initialized
INFO - 2024-06-18 18:35:43 --> Final output sent to browser
DEBUG - 2024-06-18 18:35:43 --> Total execution time: 0.0611
INFO - 2024-06-18 18:35:56 --> Config Class Initialized
INFO - 2024-06-18 18:35:56 --> Hooks Class Initialized
DEBUG - 2024-06-18 18:35:56 --> UTF-8 Support Enabled
INFO - 2024-06-18 18:35:56 --> Utf8 Class Initialized
INFO - 2024-06-18 18:35:56 --> URI Class Initialized
INFO - 2024-06-18 18:35:56 --> Router Class Initialized
INFO - 2024-06-18 18:35:56 --> Output Class Initialized
INFO - 2024-06-18 18:35:56 --> Security Class Initialized
DEBUG - 2024-06-18 18:35:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-18 18:35:56 --> Input Class Initialized
INFO - 2024-06-18 18:35:56 --> Language Class Initialized
INFO - 2024-06-18 18:35:56 --> Language Class Initialized
INFO - 2024-06-18 18:35:56 --> Config Class Initialized
INFO - 2024-06-18 18:35:56 --> Loader Class Initialized
INFO - 2024-06-18 18:35:56 --> Helper loaded: url_helper
INFO - 2024-06-18 18:35:56 --> Helper loaded: file_helper
INFO - 2024-06-18 18:35:56 --> Helper loaded: form_helper
INFO - 2024-06-18 18:35:56 --> Helper loaded: my_helper
INFO - 2024-06-18 18:35:56 --> Database Driver Class Initialized
INFO - 2024-06-18 18:35:56 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-18 18:35:56 --> Controller Class Initialized
INFO - 2024-06-18 18:35:56 --> Final output sent to browser
DEBUG - 2024-06-18 18:35:56 --> Total execution time: 0.0278
INFO - 2024-06-18 18:35:56 --> Config Class Initialized
INFO - 2024-06-18 18:35:56 --> Hooks Class Initialized
DEBUG - 2024-06-18 18:35:56 --> UTF-8 Support Enabled
INFO - 2024-06-18 18:35:56 --> Utf8 Class Initialized
INFO - 2024-06-18 18:35:56 --> URI Class Initialized
INFO - 2024-06-18 18:35:56 --> Router Class Initialized
INFO - 2024-06-18 18:35:56 --> Output Class Initialized
INFO - 2024-06-18 18:35:56 --> Security Class Initialized
DEBUG - 2024-06-18 18:35:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-18 18:35:56 --> Input Class Initialized
INFO - 2024-06-18 18:35:56 --> Language Class Initialized
INFO - 2024-06-18 18:35:56 --> Language Class Initialized
INFO - 2024-06-18 18:35:56 --> Config Class Initialized
INFO - 2024-06-18 18:35:56 --> Loader Class Initialized
INFO - 2024-06-18 18:35:56 --> Helper loaded: url_helper
INFO - 2024-06-18 18:35:56 --> Helper loaded: file_helper
INFO - 2024-06-18 18:35:56 --> Helper loaded: form_helper
INFO - 2024-06-18 18:35:56 --> Helper loaded: my_helper
INFO - 2024-06-18 18:35:56 --> Database Driver Class Initialized
INFO - 2024-06-18 18:35:56 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-18 18:35:56 --> Controller Class Initialized
INFO - 2024-06-18 18:35:58 --> Config Class Initialized
INFO - 2024-06-18 18:35:58 --> Hooks Class Initialized
DEBUG - 2024-06-18 18:35:58 --> UTF-8 Support Enabled
INFO - 2024-06-18 18:35:58 --> Utf8 Class Initialized
INFO - 2024-06-18 18:35:58 --> URI Class Initialized
INFO - 2024-06-18 18:35:58 --> Router Class Initialized
INFO - 2024-06-18 18:35:58 --> Output Class Initialized
INFO - 2024-06-18 18:35:58 --> Security Class Initialized
DEBUG - 2024-06-18 18:35:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-18 18:35:58 --> Input Class Initialized
INFO - 2024-06-18 18:35:58 --> Language Class Initialized
INFO - 2024-06-18 18:35:58 --> Language Class Initialized
INFO - 2024-06-18 18:35:58 --> Config Class Initialized
INFO - 2024-06-18 18:35:58 --> Loader Class Initialized
INFO - 2024-06-18 18:35:58 --> Helper loaded: url_helper
INFO - 2024-06-18 18:35:58 --> Helper loaded: file_helper
INFO - 2024-06-18 18:35:58 --> Helper loaded: form_helper
INFO - 2024-06-18 18:35:58 --> Helper loaded: my_helper
INFO - 2024-06-18 18:35:58 --> Database Driver Class Initialized
INFO - 2024-06-18 18:35:58 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-18 18:35:58 --> Controller Class Initialized
INFO - 2024-06-18 18:35:58 --> Final output sent to browser
DEBUG - 2024-06-18 18:35:58 --> Total execution time: 0.0282
INFO - 2024-06-18 18:35:59 --> Config Class Initialized
INFO - 2024-06-18 18:35:59 --> Hooks Class Initialized
DEBUG - 2024-06-18 18:35:59 --> UTF-8 Support Enabled
INFO - 2024-06-18 18:35:59 --> Utf8 Class Initialized
INFO - 2024-06-18 18:35:59 --> URI Class Initialized
INFO - 2024-06-18 18:35:59 --> Router Class Initialized
INFO - 2024-06-18 18:35:59 --> Output Class Initialized
INFO - 2024-06-18 18:35:59 --> Security Class Initialized
DEBUG - 2024-06-18 18:35:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-18 18:35:59 --> Input Class Initialized
INFO - 2024-06-18 18:35:59 --> Language Class Initialized
INFO - 2024-06-18 18:35:59 --> Language Class Initialized
INFO - 2024-06-18 18:35:59 --> Config Class Initialized
INFO - 2024-06-18 18:35:59 --> Loader Class Initialized
INFO - 2024-06-18 18:35:59 --> Helper loaded: url_helper
INFO - 2024-06-18 18:35:59 --> Helper loaded: file_helper
INFO - 2024-06-18 18:35:59 --> Helper loaded: form_helper
INFO - 2024-06-18 18:35:59 --> Helper loaded: my_helper
INFO - 2024-06-18 18:35:59 --> Database Driver Class Initialized
INFO - 2024-06-18 18:35:59 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-18 18:35:59 --> Controller Class Initialized
INFO - 2024-06-18 18:36:09 --> Config Class Initialized
INFO - 2024-06-18 18:36:09 --> Hooks Class Initialized
DEBUG - 2024-06-18 18:36:09 --> UTF-8 Support Enabled
INFO - 2024-06-18 18:36:09 --> Utf8 Class Initialized
INFO - 2024-06-18 18:36:09 --> URI Class Initialized
INFO - 2024-06-18 18:36:09 --> Router Class Initialized
INFO - 2024-06-18 18:36:09 --> Output Class Initialized
INFO - 2024-06-18 18:36:09 --> Security Class Initialized
DEBUG - 2024-06-18 18:36:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-18 18:36:09 --> Input Class Initialized
INFO - 2024-06-18 18:36:09 --> Language Class Initialized
INFO - 2024-06-18 18:36:09 --> Language Class Initialized
INFO - 2024-06-18 18:36:09 --> Config Class Initialized
INFO - 2024-06-18 18:36:09 --> Loader Class Initialized
INFO - 2024-06-18 18:36:09 --> Helper loaded: url_helper
INFO - 2024-06-18 18:36:09 --> Helper loaded: file_helper
INFO - 2024-06-18 18:36:09 --> Helper loaded: form_helper
INFO - 2024-06-18 18:36:09 --> Helper loaded: my_helper
INFO - 2024-06-18 18:36:09 --> Database Driver Class Initialized
INFO - 2024-06-18 18:36:09 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-18 18:36:09 --> Controller Class Initialized
INFO - 2024-06-18 18:36:09 --> Final output sent to browser
DEBUG - 2024-06-18 18:36:09 --> Total execution time: 0.0728
INFO - 2024-06-18 18:36:09 --> Config Class Initialized
INFO - 2024-06-18 18:36:09 --> Hooks Class Initialized
DEBUG - 2024-06-18 18:36:09 --> UTF-8 Support Enabled
INFO - 2024-06-18 18:36:09 --> Utf8 Class Initialized
INFO - 2024-06-18 18:36:09 --> URI Class Initialized
INFO - 2024-06-18 18:36:09 --> Router Class Initialized
INFO - 2024-06-18 18:36:09 --> Output Class Initialized
INFO - 2024-06-18 18:36:09 --> Security Class Initialized
DEBUG - 2024-06-18 18:36:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-18 18:36:09 --> Input Class Initialized
INFO - 2024-06-18 18:36:09 --> Language Class Initialized
INFO - 2024-06-18 18:36:09 --> Language Class Initialized
INFO - 2024-06-18 18:36:09 --> Config Class Initialized
INFO - 2024-06-18 18:36:09 --> Loader Class Initialized
INFO - 2024-06-18 18:36:09 --> Helper loaded: url_helper
INFO - 2024-06-18 18:36:09 --> Helper loaded: file_helper
INFO - 2024-06-18 18:36:09 --> Helper loaded: form_helper
INFO - 2024-06-18 18:36:09 --> Helper loaded: my_helper
INFO - 2024-06-18 18:36:09 --> Database Driver Class Initialized
INFO - 2024-06-18 18:36:09 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-18 18:36:09 --> Controller Class Initialized
INFO - 2024-06-18 18:36:10 --> Config Class Initialized
INFO - 2024-06-18 18:36:10 --> Hooks Class Initialized
DEBUG - 2024-06-18 18:36:10 --> UTF-8 Support Enabled
INFO - 2024-06-18 18:36:10 --> Utf8 Class Initialized
INFO - 2024-06-18 18:36:10 --> URI Class Initialized
INFO - 2024-06-18 18:36:10 --> Router Class Initialized
INFO - 2024-06-18 18:36:10 --> Output Class Initialized
INFO - 2024-06-18 18:36:10 --> Security Class Initialized
DEBUG - 2024-06-18 18:36:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-18 18:36:10 --> Input Class Initialized
INFO - 2024-06-18 18:36:10 --> Language Class Initialized
INFO - 2024-06-18 18:36:10 --> Language Class Initialized
INFO - 2024-06-18 18:36:10 --> Config Class Initialized
INFO - 2024-06-18 18:36:10 --> Loader Class Initialized
INFO - 2024-06-18 18:36:10 --> Helper loaded: url_helper
INFO - 2024-06-18 18:36:10 --> Helper loaded: file_helper
INFO - 2024-06-18 18:36:10 --> Helper loaded: form_helper
INFO - 2024-06-18 18:36:10 --> Helper loaded: my_helper
INFO - 2024-06-18 18:36:10 --> Database Driver Class Initialized
INFO - 2024-06-18 18:36:10 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-18 18:36:10 --> Controller Class Initialized
INFO - 2024-06-18 18:36:10 --> Final output sent to browser
DEBUG - 2024-06-18 18:36:10 --> Total execution time: 0.0289
INFO - 2024-06-18 18:36:19 --> Config Class Initialized
INFO - 2024-06-18 18:36:19 --> Hooks Class Initialized
DEBUG - 2024-06-18 18:36:19 --> UTF-8 Support Enabled
INFO - 2024-06-18 18:36:19 --> Utf8 Class Initialized
INFO - 2024-06-18 18:36:19 --> URI Class Initialized
INFO - 2024-06-18 18:36:19 --> Router Class Initialized
INFO - 2024-06-18 18:36:19 --> Output Class Initialized
INFO - 2024-06-18 18:36:19 --> Security Class Initialized
DEBUG - 2024-06-18 18:36:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-18 18:36:19 --> Input Class Initialized
INFO - 2024-06-18 18:36:19 --> Language Class Initialized
INFO - 2024-06-18 18:36:19 --> Language Class Initialized
INFO - 2024-06-18 18:36:19 --> Config Class Initialized
INFO - 2024-06-18 18:36:19 --> Loader Class Initialized
INFO - 2024-06-18 18:36:19 --> Helper loaded: url_helper
INFO - 2024-06-18 18:36:19 --> Helper loaded: file_helper
INFO - 2024-06-18 18:36:19 --> Helper loaded: form_helper
INFO - 2024-06-18 18:36:19 --> Helper loaded: my_helper
INFO - 2024-06-18 18:36:19 --> Database Driver Class Initialized
INFO - 2024-06-18 18:36:19 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-18 18:36:19 --> Controller Class Initialized
INFO - 2024-06-18 18:36:19 --> Final output sent to browser
DEBUG - 2024-06-18 18:36:19 --> Total execution time: 0.0300
INFO - 2024-06-18 18:36:19 --> Config Class Initialized
INFO - 2024-06-18 18:36:19 --> Hooks Class Initialized
DEBUG - 2024-06-18 18:36:19 --> UTF-8 Support Enabled
INFO - 2024-06-18 18:36:19 --> Utf8 Class Initialized
INFO - 2024-06-18 18:36:19 --> URI Class Initialized
INFO - 2024-06-18 18:36:19 --> Router Class Initialized
INFO - 2024-06-18 18:36:19 --> Output Class Initialized
INFO - 2024-06-18 18:36:19 --> Security Class Initialized
DEBUG - 2024-06-18 18:36:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-18 18:36:19 --> Input Class Initialized
INFO - 2024-06-18 18:36:19 --> Language Class Initialized
INFO - 2024-06-18 18:36:19 --> Language Class Initialized
INFO - 2024-06-18 18:36:19 --> Config Class Initialized
INFO - 2024-06-18 18:36:19 --> Loader Class Initialized
INFO - 2024-06-18 18:36:19 --> Helper loaded: url_helper
INFO - 2024-06-18 18:36:19 --> Helper loaded: file_helper
INFO - 2024-06-18 18:36:19 --> Helper loaded: form_helper
INFO - 2024-06-18 18:36:19 --> Helper loaded: my_helper
INFO - 2024-06-18 18:36:19 --> Database Driver Class Initialized
INFO - 2024-06-18 18:36:19 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-18 18:36:19 --> Controller Class Initialized
INFO - 2024-06-18 18:36:20 --> Config Class Initialized
INFO - 2024-06-18 18:36:20 --> Hooks Class Initialized
DEBUG - 2024-06-18 18:36:20 --> UTF-8 Support Enabled
INFO - 2024-06-18 18:36:20 --> Utf8 Class Initialized
INFO - 2024-06-18 18:36:20 --> URI Class Initialized
INFO - 2024-06-18 18:36:20 --> Router Class Initialized
INFO - 2024-06-18 18:36:20 --> Output Class Initialized
INFO - 2024-06-18 18:36:20 --> Security Class Initialized
DEBUG - 2024-06-18 18:36:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-18 18:36:20 --> Input Class Initialized
INFO - 2024-06-18 18:36:20 --> Language Class Initialized
INFO - 2024-06-18 18:36:20 --> Language Class Initialized
INFO - 2024-06-18 18:36:20 --> Config Class Initialized
INFO - 2024-06-18 18:36:20 --> Loader Class Initialized
INFO - 2024-06-18 18:36:20 --> Helper loaded: url_helper
INFO - 2024-06-18 18:36:20 --> Helper loaded: file_helper
INFO - 2024-06-18 18:36:20 --> Helper loaded: form_helper
INFO - 2024-06-18 18:36:20 --> Helper loaded: my_helper
INFO - 2024-06-18 18:36:20 --> Database Driver Class Initialized
INFO - 2024-06-18 18:36:20 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-18 18:36:20 --> Controller Class Initialized
INFO - 2024-06-18 18:36:20 --> Final output sent to browser
DEBUG - 2024-06-18 18:36:20 --> Total execution time: 0.0250
INFO - 2024-06-18 18:36:27 --> Config Class Initialized
INFO - 2024-06-18 18:36:27 --> Hooks Class Initialized
DEBUG - 2024-06-18 18:36:27 --> UTF-8 Support Enabled
INFO - 2024-06-18 18:36:27 --> Utf8 Class Initialized
INFO - 2024-06-18 18:36:27 --> URI Class Initialized
INFO - 2024-06-18 18:36:27 --> Router Class Initialized
INFO - 2024-06-18 18:36:27 --> Output Class Initialized
INFO - 2024-06-18 18:36:27 --> Security Class Initialized
DEBUG - 2024-06-18 18:36:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-18 18:36:27 --> Input Class Initialized
INFO - 2024-06-18 18:36:27 --> Language Class Initialized
INFO - 2024-06-18 18:36:27 --> Language Class Initialized
INFO - 2024-06-18 18:36:27 --> Config Class Initialized
INFO - 2024-06-18 18:36:27 --> Loader Class Initialized
INFO - 2024-06-18 18:36:27 --> Helper loaded: url_helper
INFO - 2024-06-18 18:36:27 --> Helper loaded: file_helper
INFO - 2024-06-18 18:36:27 --> Helper loaded: form_helper
INFO - 2024-06-18 18:36:27 --> Helper loaded: my_helper
INFO - 2024-06-18 18:36:27 --> Database Driver Class Initialized
INFO - 2024-06-18 18:36:27 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-18 18:36:27 --> Controller Class Initialized
INFO - 2024-06-18 18:36:27 --> Final output sent to browser
DEBUG - 2024-06-18 18:36:27 --> Total execution time: 0.0268
INFO - 2024-06-18 18:36:27 --> Config Class Initialized
INFO - 2024-06-18 18:36:27 --> Hooks Class Initialized
DEBUG - 2024-06-18 18:36:27 --> UTF-8 Support Enabled
INFO - 2024-06-18 18:36:27 --> Utf8 Class Initialized
INFO - 2024-06-18 18:36:27 --> URI Class Initialized
INFO - 2024-06-18 18:36:27 --> Router Class Initialized
INFO - 2024-06-18 18:36:27 --> Output Class Initialized
INFO - 2024-06-18 18:36:27 --> Security Class Initialized
DEBUG - 2024-06-18 18:36:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-18 18:36:27 --> Input Class Initialized
INFO - 2024-06-18 18:36:27 --> Language Class Initialized
INFO - 2024-06-18 18:36:27 --> Language Class Initialized
INFO - 2024-06-18 18:36:27 --> Config Class Initialized
INFO - 2024-06-18 18:36:27 --> Loader Class Initialized
INFO - 2024-06-18 18:36:27 --> Helper loaded: url_helper
INFO - 2024-06-18 18:36:27 --> Helper loaded: file_helper
INFO - 2024-06-18 18:36:27 --> Helper loaded: form_helper
INFO - 2024-06-18 18:36:27 --> Helper loaded: my_helper
INFO - 2024-06-18 18:36:27 --> Database Driver Class Initialized
INFO - 2024-06-18 18:36:27 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-18 18:36:27 --> Controller Class Initialized
INFO - 2024-06-18 18:36:31 --> Config Class Initialized
INFO - 2024-06-18 18:36:31 --> Hooks Class Initialized
DEBUG - 2024-06-18 18:36:31 --> UTF-8 Support Enabled
INFO - 2024-06-18 18:36:31 --> Utf8 Class Initialized
INFO - 2024-06-18 18:36:31 --> URI Class Initialized
INFO - 2024-06-18 18:36:31 --> Router Class Initialized
INFO - 2024-06-18 18:36:31 --> Output Class Initialized
INFO - 2024-06-18 18:36:31 --> Security Class Initialized
DEBUG - 2024-06-18 18:36:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-18 18:36:31 --> Input Class Initialized
INFO - 2024-06-18 18:36:31 --> Language Class Initialized
INFO - 2024-06-18 18:36:31 --> Language Class Initialized
INFO - 2024-06-18 18:36:31 --> Config Class Initialized
INFO - 2024-06-18 18:36:31 --> Loader Class Initialized
INFO - 2024-06-18 18:36:31 --> Helper loaded: url_helper
INFO - 2024-06-18 18:36:31 --> Helper loaded: file_helper
INFO - 2024-06-18 18:36:31 --> Helper loaded: form_helper
INFO - 2024-06-18 18:36:31 --> Helper loaded: my_helper
INFO - 2024-06-18 18:36:31 --> Database Driver Class Initialized
INFO - 2024-06-18 18:36:31 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-18 18:36:31 --> Controller Class Initialized
INFO - 2024-06-18 18:36:31 --> Final output sent to browser
DEBUG - 2024-06-18 18:36:31 --> Total execution time: 0.0550
INFO - 2024-06-18 18:38:09 --> Config Class Initialized
INFO - 2024-06-18 18:38:09 --> Hooks Class Initialized
DEBUG - 2024-06-18 18:38:09 --> UTF-8 Support Enabled
INFO - 2024-06-18 18:38:09 --> Utf8 Class Initialized
INFO - 2024-06-18 18:38:09 --> URI Class Initialized
INFO - 2024-06-18 18:38:09 --> Router Class Initialized
INFO - 2024-06-18 18:38:09 --> Output Class Initialized
INFO - 2024-06-18 18:38:09 --> Security Class Initialized
DEBUG - 2024-06-18 18:38:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-18 18:38:09 --> Input Class Initialized
INFO - 2024-06-18 18:38:09 --> Language Class Initialized
INFO - 2024-06-18 18:38:09 --> Language Class Initialized
INFO - 2024-06-18 18:38:09 --> Config Class Initialized
INFO - 2024-06-18 18:38:09 --> Loader Class Initialized
INFO - 2024-06-18 18:38:09 --> Helper loaded: url_helper
INFO - 2024-06-18 18:38:09 --> Helper loaded: file_helper
INFO - 2024-06-18 18:38:09 --> Helper loaded: form_helper
INFO - 2024-06-18 18:38:09 --> Helper loaded: my_helper
INFO - 2024-06-18 18:38:09 --> Database Driver Class Initialized
INFO - 2024-06-18 18:38:09 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-18 18:38:09 --> Controller Class Initialized
INFO - 2024-06-18 18:38:09 --> Final output sent to browser
DEBUG - 2024-06-18 18:38:09 --> Total execution time: 0.0268
INFO - 2024-06-18 18:38:35 --> Config Class Initialized
INFO - 2024-06-18 18:38:35 --> Hooks Class Initialized
DEBUG - 2024-06-18 18:38:35 --> UTF-8 Support Enabled
INFO - 2024-06-18 18:38:35 --> Utf8 Class Initialized
INFO - 2024-06-18 18:38:35 --> URI Class Initialized
INFO - 2024-06-18 18:38:35 --> Router Class Initialized
INFO - 2024-06-18 18:38:35 --> Output Class Initialized
INFO - 2024-06-18 18:38:35 --> Security Class Initialized
DEBUG - 2024-06-18 18:38:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-18 18:38:35 --> Input Class Initialized
INFO - 2024-06-18 18:38:35 --> Language Class Initialized
INFO - 2024-06-18 18:38:35 --> Language Class Initialized
INFO - 2024-06-18 18:38:35 --> Config Class Initialized
INFO - 2024-06-18 18:38:35 --> Loader Class Initialized
INFO - 2024-06-18 18:38:35 --> Helper loaded: url_helper
INFO - 2024-06-18 18:38:35 --> Helper loaded: file_helper
INFO - 2024-06-18 18:38:35 --> Helper loaded: form_helper
INFO - 2024-06-18 18:38:35 --> Helper loaded: my_helper
INFO - 2024-06-18 18:38:35 --> Database Driver Class Initialized
INFO - 2024-06-18 18:38:35 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-18 18:38:35 --> Controller Class Initialized
INFO - 2024-06-18 18:38:35 --> Final output sent to browser
DEBUG - 2024-06-18 18:38:35 --> Total execution time: 0.2928
INFO - 2024-06-18 18:38:38 --> Config Class Initialized
INFO - 2024-06-18 18:38:38 --> Hooks Class Initialized
DEBUG - 2024-06-18 18:38:38 --> UTF-8 Support Enabled
INFO - 2024-06-18 18:38:38 --> Utf8 Class Initialized
INFO - 2024-06-18 18:38:38 --> URI Class Initialized
INFO - 2024-06-18 18:38:38 --> Router Class Initialized
INFO - 2024-06-18 18:38:38 --> Output Class Initialized
INFO - 2024-06-18 18:38:38 --> Security Class Initialized
DEBUG - 2024-06-18 18:38:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-18 18:38:38 --> Input Class Initialized
INFO - 2024-06-18 18:38:38 --> Language Class Initialized
INFO - 2024-06-18 18:38:38 --> Language Class Initialized
INFO - 2024-06-18 18:38:38 --> Config Class Initialized
INFO - 2024-06-18 18:38:38 --> Loader Class Initialized
INFO - 2024-06-18 18:38:38 --> Helper loaded: url_helper
INFO - 2024-06-18 18:38:38 --> Helper loaded: file_helper
INFO - 2024-06-18 18:38:38 --> Helper loaded: form_helper
INFO - 2024-06-18 18:38:38 --> Helper loaded: my_helper
INFO - 2024-06-18 18:38:38 --> Database Driver Class Initialized
INFO - 2024-06-18 18:38:38 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-18 18:38:38 --> Controller Class Initialized
INFO - 2024-06-18 18:38:38 --> Final output sent to browser
DEBUG - 2024-06-18 18:38:38 --> Total execution time: 0.0311
INFO - 2024-06-18 18:38:44 --> Config Class Initialized
INFO - 2024-06-18 18:38:44 --> Hooks Class Initialized
DEBUG - 2024-06-18 18:38:44 --> UTF-8 Support Enabled
INFO - 2024-06-18 18:38:44 --> Utf8 Class Initialized
INFO - 2024-06-18 18:38:44 --> URI Class Initialized
INFO - 2024-06-18 18:38:44 --> Router Class Initialized
INFO - 2024-06-18 18:38:44 --> Output Class Initialized
INFO - 2024-06-18 18:38:44 --> Security Class Initialized
DEBUG - 2024-06-18 18:38:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-18 18:38:44 --> Input Class Initialized
INFO - 2024-06-18 18:38:44 --> Language Class Initialized
INFO - 2024-06-18 18:38:44 --> Language Class Initialized
INFO - 2024-06-18 18:38:44 --> Config Class Initialized
INFO - 2024-06-18 18:38:44 --> Loader Class Initialized
INFO - 2024-06-18 18:38:44 --> Helper loaded: url_helper
INFO - 2024-06-18 18:38:44 --> Helper loaded: file_helper
INFO - 2024-06-18 18:38:44 --> Helper loaded: form_helper
INFO - 2024-06-18 18:38:44 --> Helper loaded: my_helper
INFO - 2024-06-18 18:38:44 --> Database Driver Class Initialized
INFO - 2024-06-18 18:38:44 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-18 18:38:44 --> Controller Class Initialized
INFO - 2024-06-18 18:38:44 --> Final output sent to browser
DEBUG - 2024-06-18 18:38:44 --> Total execution time: 0.0606
INFO - 2024-06-18 18:38:49 --> Config Class Initialized
INFO - 2024-06-18 18:38:49 --> Hooks Class Initialized
DEBUG - 2024-06-18 18:38:49 --> UTF-8 Support Enabled
INFO - 2024-06-18 18:38:49 --> Utf8 Class Initialized
INFO - 2024-06-18 18:38:49 --> URI Class Initialized
INFO - 2024-06-18 18:38:49 --> Router Class Initialized
INFO - 2024-06-18 18:38:49 --> Output Class Initialized
INFO - 2024-06-18 18:38:49 --> Security Class Initialized
DEBUG - 2024-06-18 18:38:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-18 18:38:49 --> Input Class Initialized
INFO - 2024-06-18 18:38:49 --> Language Class Initialized
INFO - 2024-06-18 18:38:49 --> Language Class Initialized
INFO - 2024-06-18 18:38:49 --> Config Class Initialized
INFO - 2024-06-18 18:38:49 --> Loader Class Initialized
INFO - 2024-06-18 18:38:49 --> Helper loaded: url_helper
INFO - 2024-06-18 18:38:49 --> Helper loaded: file_helper
INFO - 2024-06-18 18:38:49 --> Helper loaded: form_helper
INFO - 2024-06-18 18:38:49 --> Helper loaded: my_helper
INFO - 2024-06-18 18:38:49 --> Database Driver Class Initialized
INFO - 2024-06-18 18:38:49 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-18 18:38:49 --> Controller Class Initialized
DEBUG - 2024-06-18 18:38:49 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/views/list.php
DEBUG - 2024-06-18 18:38:49 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-06-18 18:38:49 --> Final output sent to browser
DEBUG - 2024-06-18 18:38:49 --> Total execution time: 0.0448
INFO - 2024-06-18 18:38:51 --> Config Class Initialized
INFO - 2024-06-18 18:38:51 --> Hooks Class Initialized
DEBUG - 2024-06-18 18:38:51 --> UTF-8 Support Enabled
INFO - 2024-06-18 18:38:51 --> Utf8 Class Initialized
INFO - 2024-06-18 18:38:51 --> URI Class Initialized
INFO - 2024-06-18 18:38:51 --> Router Class Initialized
INFO - 2024-06-18 18:38:51 --> Output Class Initialized
INFO - 2024-06-18 18:38:51 --> Security Class Initialized
DEBUG - 2024-06-18 18:38:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-18 18:38:51 --> Input Class Initialized
INFO - 2024-06-18 18:38:51 --> Language Class Initialized
INFO - 2024-06-18 18:38:51 --> Language Class Initialized
INFO - 2024-06-18 18:38:51 --> Config Class Initialized
INFO - 2024-06-18 18:38:51 --> Loader Class Initialized
INFO - 2024-06-18 18:38:51 --> Helper loaded: url_helper
INFO - 2024-06-18 18:38:51 --> Helper loaded: file_helper
INFO - 2024-06-18 18:38:51 --> Helper loaded: form_helper
INFO - 2024-06-18 18:38:51 --> Helper loaded: my_helper
INFO - 2024-06-18 18:38:51 --> Database Driver Class Initialized
INFO - 2024-06-18 18:38:51 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-18 18:38:51 --> Controller Class Initialized
DEBUG - 2024-06-18 18:38:51 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/views/cetak_tahfiz.php
INFO - 2024-06-18 18:38:54 --> Final output sent to browser
DEBUG - 2024-06-18 18:38:54 --> Total execution time: 3.5029
INFO - 2024-06-18 18:40:38 --> Config Class Initialized
INFO - 2024-06-18 18:40:38 --> Hooks Class Initialized
DEBUG - 2024-06-18 18:40:38 --> UTF-8 Support Enabled
INFO - 2024-06-18 18:40:38 --> Utf8 Class Initialized
INFO - 2024-06-18 18:40:38 --> URI Class Initialized
INFO - 2024-06-18 18:40:38 --> Router Class Initialized
INFO - 2024-06-18 18:40:38 --> Output Class Initialized
INFO - 2024-06-18 18:40:38 --> Security Class Initialized
DEBUG - 2024-06-18 18:40:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-18 18:40:38 --> Input Class Initialized
INFO - 2024-06-18 18:40:38 --> Language Class Initialized
INFO - 2024-06-18 18:40:38 --> Language Class Initialized
INFO - 2024-06-18 18:40:38 --> Config Class Initialized
INFO - 2024-06-18 18:40:38 --> Loader Class Initialized
INFO - 2024-06-18 18:40:38 --> Helper loaded: url_helper
INFO - 2024-06-18 18:40:38 --> Helper loaded: file_helper
INFO - 2024-06-18 18:40:38 --> Helper loaded: form_helper
INFO - 2024-06-18 18:40:38 --> Helper loaded: my_helper
INFO - 2024-06-18 18:40:38 --> Database Driver Class Initialized
INFO - 2024-06-18 18:40:38 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-18 18:40:38 --> Controller Class Initialized
DEBUG - 2024-06-18 18:40:38 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/views/list.php
DEBUG - 2024-06-18 18:40:38 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-06-18 18:40:38 --> Final output sent to browser
DEBUG - 2024-06-18 18:40:38 --> Total execution time: 0.0577
INFO - 2024-06-18 18:40:38 --> Config Class Initialized
INFO - 2024-06-18 18:40:38 --> Hooks Class Initialized
DEBUG - 2024-06-18 18:40:38 --> UTF-8 Support Enabled
INFO - 2024-06-18 18:40:38 --> Utf8 Class Initialized
INFO - 2024-06-18 18:40:38 --> URI Class Initialized
INFO - 2024-06-18 18:40:38 --> Router Class Initialized
INFO - 2024-06-18 18:40:38 --> Output Class Initialized
INFO - 2024-06-18 18:40:38 --> Security Class Initialized
DEBUG - 2024-06-18 18:40:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-18 18:40:38 --> Input Class Initialized
INFO - 2024-06-18 18:40:38 --> Language Class Initialized
INFO - 2024-06-18 18:40:38 --> Language Class Initialized
INFO - 2024-06-18 18:40:38 --> Config Class Initialized
INFO - 2024-06-18 18:40:38 --> Loader Class Initialized
INFO - 2024-06-18 18:40:38 --> Helper loaded: url_helper
INFO - 2024-06-18 18:40:38 --> Helper loaded: file_helper
INFO - 2024-06-18 18:40:38 --> Helper loaded: form_helper
INFO - 2024-06-18 18:40:38 --> Helper loaded: my_helper
INFO - 2024-06-18 18:40:38 --> Database Driver Class Initialized
INFO - 2024-06-18 18:40:38 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-18 18:40:38 --> Controller Class Initialized
INFO - 2024-06-18 18:40:45 --> Config Class Initialized
INFO - 2024-06-18 18:40:45 --> Hooks Class Initialized
DEBUG - 2024-06-18 18:40:45 --> UTF-8 Support Enabled
INFO - 2024-06-18 18:40:45 --> Utf8 Class Initialized
INFO - 2024-06-18 18:40:45 --> URI Class Initialized
INFO - 2024-06-18 18:40:45 --> Router Class Initialized
INFO - 2024-06-18 18:40:45 --> Output Class Initialized
INFO - 2024-06-18 18:40:45 --> Security Class Initialized
DEBUG - 2024-06-18 18:40:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-18 18:40:45 --> Input Class Initialized
INFO - 2024-06-18 18:40:45 --> Language Class Initialized
INFO - 2024-06-18 18:40:45 --> Language Class Initialized
INFO - 2024-06-18 18:40:45 --> Config Class Initialized
INFO - 2024-06-18 18:40:45 --> Loader Class Initialized
INFO - 2024-06-18 18:40:45 --> Helper loaded: url_helper
INFO - 2024-06-18 18:40:45 --> Helper loaded: file_helper
INFO - 2024-06-18 18:40:45 --> Helper loaded: form_helper
INFO - 2024-06-18 18:40:45 --> Helper loaded: my_helper
INFO - 2024-06-18 18:40:45 --> Database Driver Class Initialized
INFO - 2024-06-18 18:40:45 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-18 18:40:45 --> Controller Class Initialized
INFO - 2024-06-18 18:41:13 --> Config Class Initialized
INFO - 2024-06-18 18:41:13 --> Hooks Class Initialized
DEBUG - 2024-06-18 18:41:13 --> UTF-8 Support Enabled
INFO - 2024-06-18 18:41:13 --> Utf8 Class Initialized
INFO - 2024-06-18 18:41:13 --> URI Class Initialized
INFO - 2024-06-18 18:41:13 --> Router Class Initialized
INFO - 2024-06-18 18:41:13 --> Output Class Initialized
INFO - 2024-06-18 18:41:13 --> Security Class Initialized
DEBUG - 2024-06-18 18:41:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-18 18:41:13 --> Input Class Initialized
INFO - 2024-06-18 18:41:13 --> Language Class Initialized
INFO - 2024-06-18 18:41:13 --> Language Class Initialized
INFO - 2024-06-18 18:41:13 --> Config Class Initialized
INFO - 2024-06-18 18:41:13 --> Loader Class Initialized
INFO - 2024-06-18 18:41:13 --> Helper loaded: url_helper
INFO - 2024-06-18 18:41:13 --> Helper loaded: file_helper
INFO - 2024-06-18 18:41:13 --> Helper loaded: form_helper
INFO - 2024-06-18 18:41:13 --> Helper loaded: my_helper
INFO - 2024-06-18 18:41:13 --> Database Driver Class Initialized
INFO - 2024-06-18 18:41:13 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-18 18:41:13 --> Controller Class Initialized
DEBUG - 2024-06-18 18:41:13 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/view_mapel/views/v_view_mapel.php
DEBUG - 2024-06-18 18:41:13 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-06-18 18:41:13 --> Final output sent to browser
DEBUG - 2024-06-18 18:41:13 --> Total execution time: 0.0277
INFO - 2024-06-18 18:41:16 --> Config Class Initialized
INFO - 2024-06-18 18:41:16 --> Hooks Class Initialized
DEBUG - 2024-06-18 18:41:16 --> UTF-8 Support Enabled
INFO - 2024-06-18 18:41:16 --> Utf8 Class Initialized
INFO - 2024-06-18 18:41:16 --> URI Class Initialized
INFO - 2024-06-18 18:41:16 --> Router Class Initialized
INFO - 2024-06-18 18:41:16 --> Output Class Initialized
INFO - 2024-06-18 18:41:16 --> Security Class Initialized
DEBUG - 2024-06-18 18:41:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-18 18:41:16 --> Input Class Initialized
INFO - 2024-06-18 18:41:16 --> Language Class Initialized
INFO - 2024-06-18 18:41:16 --> Language Class Initialized
INFO - 2024-06-18 18:41:16 --> Config Class Initialized
INFO - 2024-06-18 18:41:16 --> Loader Class Initialized
INFO - 2024-06-18 18:41:16 --> Helper loaded: url_helper
INFO - 2024-06-18 18:41:16 --> Helper loaded: file_helper
INFO - 2024-06-18 18:41:16 --> Helper loaded: form_helper
INFO - 2024-06-18 18:41:16 --> Helper loaded: my_helper
INFO - 2024-06-18 18:41:16 --> Database Driver Class Initialized
INFO - 2024-06-18 18:41:16 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-18 18:41:16 --> Controller Class Initialized
DEBUG - 2024-06-18 18:41:16 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/views/list.php
DEBUG - 2024-06-18 18:41:16 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-06-18 18:41:16 --> Final output sent to browser
DEBUG - 2024-06-18 18:41:16 --> Total execution time: 0.0399
INFO - 2024-06-18 18:41:16 --> Config Class Initialized
INFO - 2024-06-18 18:41:16 --> Hooks Class Initialized
DEBUG - 2024-06-18 18:41:16 --> UTF-8 Support Enabled
INFO - 2024-06-18 18:41:16 --> Utf8 Class Initialized
INFO - 2024-06-18 18:41:16 --> URI Class Initialized
INFO - 2024-06-18 18:41:16 --> Router Class Initialized
INFO - 2024-06-18 18:41:16 --> Output Class Initialized
INFO - 2024-06-18 18:41:16 --> Security Class Initialized
DEBUG - 2024-06-18 18:41:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-18 18:41:16 --> Input Class Initialized
INFO - 2024-06-18 18:41:16 --> Language Class Initialized
INFO - 2024-06-18 18:41:16 --> Language Class Initialized
INFO - 2024-06-18 18:41:16 --> Config Class Initialized
INFO - 2024-06-18 18:41:16 --> Loader Class Initialized
INFO - 2024-06-18 18:41:16 --> Helper loaded: url_helper
INFO - 2024-06-18 18:41:16 --> Helper loaded: file_helper
INFO - 2024-06-18 18:41:16 --> Helper loaded: form_helper
INFO - 2024-06-18 18:41:16 --> Helper loaded: my_helper
INFO - 2024-06-18 18:41:16 --> Database Driver Class Initialized
INFO - 2024-06-18 18:41:16 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-18 18:41:16 --> Controller Class Initialized
INFO - 2024-06-18 18:41:18 --> Config Class Initialized
INFO - 2024-06-18 18:41:18 --> Hooks Class Initialized
DEBUG - 2024-06-18 18:41:18 --> UTF-8 Support Enabled
INFO - 2024-06-18 18:41:18 --> Utf8 Class Initialized
INFO - 2024-06-18 18:41:18 --> URI Class Initialized
INFO - 2024-06-18 18:41:18 --> Router Class Initialized
INFO - 2024-06-18 18:41:18 --> Output Class Initialized
INFO - 2024-06-18 18:41:18 --> Security Class Initialized
DEBUG - 2024-06-18 18:41:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-18 18:41:18 --> Input Class Initialized
INFO - 2024-06-18 18:41:18 --> Language Class Initialized
INFO - 2024-06-18 18:41:18 --> Language Class Initialized
INFO - 2024-06-18 18:41:18 --> Config Class Initialized
INFO - 2024-06-18 18:41:18 --> Loader Class Initialized
INFO - 2024-06-18 18:41:18 --> Helper loaded: url_helper
INFO - 2024-06-18 18:41:18 --> Helper loaded: file_helper
INFO - 2024-06-18 18:41:18 --> Helper loaded: form_helper
INFO - 2024-06-18 18:41:18 --> Helper loaded: my_helper
INFO - 2024-06-18 18:41:18 --> Database Driver Class Initialized
INFO - 2024-06-18 18:41:18 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-18 18:41:18 --> Controller Class Initialized
INFO - 2024-06-18 18:41:18 --> Final output sent to browser
DEBUG - 2024-06-18 18:41:18 --> Total execution time: 0.0534
INFO - 2024-06-18 18:41:20 --> Config Class Initialized
INFO - 2024-06-18 18:41:20 --> Hooks Class Initialized
DEBUG - 2024-06-18 18:41:20 --> UTF-8 Support Enabled
INFO - 2024-06-18 18:41:20 --> Utf8 Class Initialized
INFO - 2024-06-18 18:41:20 --> URI Class Initialized
INFO - 2024-06-18 18:41:20 --> Router Class Initialized
INFO - 2024-06-18 18:41:20 --> Output Class Initialized
INFO - 2024-06-18 18:41:20 --> Security Class Initialized
DEBUG - 2024-06-18 18:41:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-18 18:41:20 --> Input Class Initialized
INFO - 2024-06-18 18:41:20 --> Language Class Initialized
INFO - 2024-06-18 18:41:20 --> Language Class Initialized
INFO - 2024-06-18 18:41:20 --> Config Class Initialized
INFO - 2024-06-18 18:41:20 --> Loader Class Initialized
INFO - 2024-06-18 18:41:20 --> Helper loaded: url_helper
INFO - 2024-06-18 18:41:20 --> Helper loaded: file_helper
INFO - 2024-06-18 18:41:20 --> Helper loaded: form_helper
INFO - 2024-06-18 18:41:20 --> Helper loaded: my_helper
INFO - 2024-06-18 18:41:20 --> Database Driver Class Initialized
INFO - 2024-06-18 18:41:20 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-18 18:41:20 --> Controller Class Initialized
INFO - 2024-06-18 18:41:20 --> Final output sent to browser
DEBUG - 2024-06-18 18:41:20 --> Total execution time: 0.0293
INFO - 2024-06-18 18:41:23 --> Config Class Initialized
INFO - 2024-06-18 18:41:23 --> Hooks Class Initialized
DEBUG - 2024-06-18 18:41:23 --> UTF-8 Support Enabled
INFO - 2024-06-18 18:41:23 --> Utf8 Class Initialized
INFO - 2024-06-18 18:41:23 --> URI Class Initialized
INFO - 2024-06-18 18:41:23 --> Router Class Initialized
INFO - 2024-06-18 18:41:23 --> Output Class Initialized
INFO - 2024-06-18 18:41:23 --> Security Class Initialized
DEBUG - 2024-06-18 18:41:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-18 18:41:23 --> Input Class Initialized
INFO - 2024-06-18 18:41:23 --> Language Class Initialized
INFO - 2024-06-18 18:41:23 --> Language Class Initialized
INFO - 2024-06-18 18:41:23 --> Config Class Initialized
INFO - 2024-06-18 18:41:23 --> Loader Class Initialized
INFO - 2024-06-18 18:41:23 --> Helper loaded: url_helper
INFO - 2024-06-18 18:41:23 --> Helper loaded: file_helper
INFO - 2024-06-18 18:41:23 --> Helper loaded: form_helper
INFO - 2024-06-18 18:41:23 --> Helper loaded: my_helper
INFO - 2024-06-18 18:41:23 --> Database Driver Class Initialized
INFO - 2024-06-18 18:41:23 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-18 18:41:23 --> Controller Class Initialized
DEBUG - 2024-06-18 18:41:23 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/view_mapel/views/v_view_mapel.php
DEBUG - 2024-06-18 18:41:23 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-06-18 18:41:23 --> Final output sent to browser
DEBUG - 2024-06-18 18:41:23 --> Total execution time: 0.0276
INFO - 2024-06-18 18:41:25 --> Config Class Initialized
INFO - 2024-06-18 18:41:25 --> Hooks Class Initialized
DEBUG - 2024-06-18 18:41:25 --> UTF-8 Support Enabled
INFO - 2024-06-18 18:41:25 --> Utf8 Class Initialized
INFO - 2024-06-18 18:41:25 --> URI Class Initialized
INFO - 2024-06-18 18:41:25 --> Router Class Initialized
INFO - 2024-06-18 18:41:25 --> Output Class Initialized
INFO - 2024-06-18 18:41:25 --> Security Class Initialized
DEBUG - 2024-06-18 18:41:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-18 18:41:25 --> Input Class Initialized
INFO - 2024-06-18 18:41:25 --> Language Class Initialized
INFO - 2024-06-18 18:41:25 --> Language Class Initialized
INFO - 2024-06-18 18:41:25 --> Config Class Initialized
INFO - 2024-06-18 18:41:25 --> Loader Class Initialized
INFO - 2024-06-18 18:41:25 --> Helper loaded: url_helper
INFO - 2024-06-18 18:41:25 --> Helper loaded: file_helper
INFO - 2024-06-18 18:41:25 --> Helper loaded: form_helper
INFO - 2024-06-18 18:41:25 --> Helper loaded: my_helper
INFO - 2024-06-18 18:41:25 --> Database Driver Class Initialized
INFO - 2024-06-18 18:41:25 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-18 18:41:25 --> Controller Class Initialized
DEBUG - 2024-06-18 18:41:25 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_catatan_guru/views/list.php
DEBUG - 2024-06-18 18:41:25 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-06-18 18:41:25 --> Final output sent to browser
DEBUG - 2024-06-18 18:41:25 --> Total execution time: 0.0327
INFO - 2024-06-18 18:41:30 --> Config Class Initialized
INFO - 2024-06-18 18:41:30 --> Hooks Class Initialized
DEBUG - 2024-06-18 18:41:30 --> UTF-8 Support Enabled
INFO - 2024-06-18 18:41:30 --> Utf8 Class Initialized
INFO - 2024-06-18 18:41:30 --> URI Class Initialized
INFO - 2024-06-18 18:41:30 --> Router Class Initialized
INFO - 2024-06-18 18:41:30 --> Output Class Initialized
INFO - 2024-06-18 18:41:30 --> Security Class Initialized
DEBUG - 2024-06-18 18:41:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-18 18:41:30 --> Input Class Initialized
INFO - 2024-06-18 18:41:30 --> Language Class Initialized
INFO - 2024-06-18 18:41:30 --> Language Class Initialized
INFO - 2024-06-18 18:41:30 --> Config Class Initialized
INFO - 2024-06-18 18:41:30 --> Loader Class Initialized
INFO - 2024-06-18 18:41:30 --> Helper loaded: url_helper
INFO - 2024-06-18 18:41:30 --> Helper loaded: file_helper
INFO - 2024-06-18 18:41:30 --> Helper loaded: form_helper
INFO - 2024-06-18 18:41:30 --> Helper loaded: my_helper
INFO - 2024-06-18 18:41:30 --> Database Driver Class Initialized
INFO - 2024-06-18 18:41:30 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-18 18:41:30 --> Controller Class Initialized
INFO - 2024-06-18 18:41:30 --> Final output sent to browser
DEBUG - 2024-06-18 18:41:30 --> Total execution time: 0.0251
INFO - 2024-06-18 18:41:41 --> Config Class Initialized
INFO - 2024-06-18 18:41:41 --> Hooks Class Initialized
DEBUG - 2024-06-18 18:41:41 --> UTF-8 Support Enabled
INFO - 2024-06-18 18:41:41 --> Utf8 Class Initialized
INFO - 2024-06-18 18:41:41 --> URI Class Initialized
INFO - 2024-06-18 18:41:41 --> Router Class Initialized
INFO - 2024-06-18 18:41:41 --> Output Class Initialized
INFO - 2024-06-18 18:41:41 --> Security Class Initialized
DEBUG - 2024-06-18 18:41:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-18 18:41:41 --> Input Class Initialized
INFO - 2024-06-18 18:41:41 --> Language Class Initialized
INFO - 2024-06-18 18:41:41 --> Language Class Initialized
INFO - 2024-06-18 18:41:41 --> Config Class Initialized
INFO - 2024-06-18 18:41:41 --> Loader Class Initialized
INFO - 2024-06-18 18:41:41 --> Helper loaded: url_helper
INFO - 2024-06-18 18:41:41 --> Helper loaded: file_helper
INFO - 2024-06-18 18:41:41 --> Helper loaded: form_helper
INFO - 2024-06-18 18:41:41 --> Helper loaded: my_helper
INFO - 2024-06-18 18:41:41 --> Database Driver Class Initialized
INFO - 2024-06-18 18:41:41 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-18 18:41:41 --> Controller Class Initialized
DEBUG - 2024-06-18 18:41:41 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/view_mapel/views/v_view_mapel.php
DEBUG - 2024-06-18 18:41:41 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-06-18 18:41:41 --> Final output sent to browser
DEBUG - 2024-06-18 18:41:41 --> Total execution time: 0.0246
INFO - 2024-06-18 18:44:57 --> Config Class Initialized
INFO - 2024-06-18 18:44:57 --> Hooks Class Initialized
DEBUG - 2024-06-18 18:44:57 --> UTF-8 Support Enabled
INFO - 2024-06-18 18:44:57 --> Utf8 Class Initialized
INFO - 2024-06-18 18:44:57 --> URI Class Initialized
INFO - 2024-06-18 18:44:57 --> Router Class Initialized
INFO - 2024-06-18 18:44:57 --> Output Class Initialized
INFO - 2024-06-18 18:44:57 --> Security Class Initialized
DEBUG - 2024-06-18 18:44:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-18 18:44:57 --> Input Class Initialized
INFO - 2024-06-18 18:44:57 --> Language Class Initialized
INFO - 2024-06-18 18:44:57 --> Language Class Initialized
INFO - 2024-06-18 18:44:57 --> Config Class Initialized
INFO - 2024-06-18 18:44:57 --> Loader Class Initialized
INFO - 2024-06-18 18:44:57 --> Helper loaded: url_helper
INFO - 2024-06-18 18:44:57 --> Helper loaded: file_helper
INFO - 2024-06-18 18:44:57 --> Helper loaded: form_helper
INFO - 2024-06-18 18:44:57 --> Helper loaded: my_helper
INFO - 2024-06-18 18:44:57 --> Database Driver Class Initialized
INFO - 2024-06-18 18:44:57 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-18 18:44:57 --> Controller Class Initialized
DEBUG - 2024-06-18 18:44:57 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/views/form.php
DEBUG - 2024-06-18 18:44:57 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-06-18 18:44:57 --> Final output sent to browser
DEBUG - 2024-06-18 18:44:57 --> Total execution time: 0.0345
INFO - 2024-06-18 18:45:03 --> Config Class Initialized
INFO - 2024-06-18 18:45:03 --> Hooks Class Initialized
DEBUG - 2024-06-18 18:45:03 --> UTF-8 Support Enabled
INFO - 2024-06-18 18:45:03 --> Utf8 Class Initialized
INFO - 2024-06-18 18:45:03 --> URI Class Initialized
INFO - 2024-06-18 18:45:03 --> Router Class Initialized
INFO - 2024-06-18 18:45:03 --> Output Class Initialized
INFO - 2024-06-18 18:45:03 --> Security Class Initialized
DEBUG - 2024-06-18 18:45:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-18 18:45:03 --> Input Class Initialized
INFO - 2024-06-18 18:45:03 --> Language Class Initialized
INFO - 2024-06-18 18:45:03 --> Language Class Initialized
INFO - 2024-06-18 18:45:03 --> Config Class Initialized
INFO - 2024-06-18 18:45:03 --> Loader Class Initialized
INFO - 2024-06-18 18:45:03 --> Helper loaded: url_helper
INFO - 2024-06-18 18:45:03 --> Helper loaded: file_helper
INFO - 2024-06-18 18:45:03 --> Helper loaded: form_helper
INFO - 2024-06-18 18:45:03 --> Helper loaded: my_helper
INFO - 2024-06-18 18:45:03 --> Database Driver Class Initialized
INFO - 2024-06-18 18:45:03 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-18 18:45:03 --> Controller Class Initialized
INFO - 2024-06-18 18:45:03 --> Config Class Initialized
INFO - 2024-06-18 18:45:03 --> Hooks Class Initialized
DEBUG - 2024-06-18 18:45:03 --> UTF-8 Support Enabled
INFO - 2024-06-18 18:45:03 --> Utf8 Class Initialized
INFO - 2024-06-18 18:45:03 --> URI Class Initialized
INFO - 2024-06-18 18:45:03 --> Router Class Initialized
INFO - 2024-06-18 18:45:03 --> Output Class Initialized
INFO - 2024-06-18 18:45:03 --> Security Class Initialized
DEBUG - 2024-06-18 18:45:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-18 18:45:03 --> Input Class Initialized
INFO - 2024-06-18 18:45:03 --> Language Class Initialized
INFO - 2024-06-18 18:45:03 --> Language Class Initialized
INFO - 2024-06-18 18:45:03 --> Config Class Initialized
INFO - 2024-06-18 18:45:03 --> Loader Class Initialized
INFO - 2024-06-18 18:45:03 --> Helper loaded: url_helper
INFO - 2024-06-18 18:45:03 --> Helper loaded: file_helper
INFO - 2024-06-18 18:45:03 --> Helper loaded: form_helper
INFO - 2024-06-18 18:45:03 --> Helper loaded: my_helper
INFO - 2024-06-18 18:45:03 --> Database Driver Class Initialized
INFO - 2024-06-18 18:45:03 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-18 18:45:03 --> Controller Class Initialized
DEBUG - 2024-06-18 18:45:03 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/views/list.php
DEBUG - 2024-06-18 18:45:03 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-06-18 18:45:03 --> Final output sent to browser
DEBUG - 2024-06-18 18:45:03 --> Total execution time: 0.0333
INFO - 2024-06-18 18:45:04 --> Config Class Initialized
INFO - 2024-06-18 18:45:04 --> Hooks Class Initialized
DEBUG - 2024-06-18 18:45:04 --> UTF-8 Support Enabled
INFO - 2024-06-18 18:45:04 --> Utf8 Class Initialized
INFO - 2024-06-18 18:45:04 --> URI Class Initialized
INFO - 2024-06-18 18:45:04 --> Router Class Initialized
INFO - 2024-06-18 18:45:04 --> Output Class Initialized
INFO - 2024-06-18 18:45:04 --> Security Class Initialized
DEBUG - 2024-06-18 18:45:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-18 18:45:04 --> Input Class Initialized
INFO - 2024-06-18 18:45:04 --> Language Class Initialized
INFO - 2024-06-18 18:45:04 --> Language Class Initialized
INFO - 2024-06-18 18:45:04 --> Config Class Initialized
INFO - 2024-06-18 18:45:04 --> Loader Class Initialized
INFO - 2024-06-18 18:45:04 --> Helper loaded: url_helper
INFO - 2024-06-18 18:45:04 --> Helper loaded: file_helper
INFO - 2024-06-18 18:45:04 --> Helper loaded: form_helper
INFO - 2024-06-18 18:45:04 --> Helper loaded: my_helper
INFO - 2024-06-18 18:45:04 --> Database Driver Class Initialized
INFO - 2024-06-18 18:45:04 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-18 18:45:04 --> Controller Class Initialized
INFO - 2024-06-18 18:45:26 --> Config Class Initialized
INFO - 2024-06-18 18:45:26 --> Hooks Class Initialized
DEBUG - 2024-06-18 18:45:26 --> UTF-8 Support Enabled
INFO - 2024-06-18 18:45:26 --> Utf8 Class Initialized
INFO - 2024-06-18 18:45:26 --> URI Class Initialized
INFO - 2024-06-18 18:45:26 --> Router Class Initialized
INFO - 2024-06-18 18:45:26 --> Output Class Initialized
INFO - 2024-06-18 18:45:26 --> Security Class Initialized
DEBUG - 2024-06-18 18:45:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-18 18:45:26 --> Input Class Initialized
INFO - 2024-06-18 18:45:26 --> Language Class Initialized
INFO - 2024-06-18 18:45:26 --> Language Class Initialized
INFO - 2024-06-18 18:45:26 --> Config Class Initialized
INFO - 2024-06-18 18:45:26 --> Loader Class Initialized
INFO - 2024-06-18 18:45:26 --> Helper loaded: url_helper
INFO - 2024-06-18 18:45:26 --> Helper loaded: file_helper
INFO - 2024-06-18 18:45:26 --> Helper loaded: form_helper
INFO - 2024-06-18 18:45:26 --> Helper loaded: my_helper
INFO - 2024-06-18 18:45:26 --> Database Driver Class Initialized
INFO - 2024-06-18 18:45:26 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-18 18:45:26 --> Controller Class Initialized
INFO - 2024-06-18 18:45:26 --> Final output sent to browser
DEBUG - 2024-06-18 18:45:26 --> Total execution time: 0.0307
INFO - 2024-06-18 18:45:47 --> Config Class Initialized
INFO - 2024-06-18 18:45:47 --> Hooks Class Initialized
DEBUG - 2024-06-18 18:45:47 --> UTF-8 Support Enabled
INFO - 2024-06-18 18:45:47 --> Utf8 Class Initialized
INFO - 2024-06-18 18:45:47 --> URI Class Initialized
INFO - 2024-06-18 18:45:47 --> Router Class Initialized
INFO - 2024-06-18 18:45:47 --> Output Class Initialized
INFO - 2024-06-18 18:45:47 --> Security Class Initialized
DEBUG - 2024-06-18 18:45:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-18 18:45:47 --> Input Class Initialized
INFO - 2024-06-18 18:45:47 --> Language Class Initialized
INFO - 2024-06-18 18:45:47 --> Language Class Initialized
INFO - 2024-06-18 18:45:47 --> Config Class Initialized
INFO - 2024-06-18 18:45:47 --> Loader Class Initialized
INFO - 2024-06-18 18:45:47 --> Helper loaded: url_helper
INFO - 2024-06-18 18:45:47 --> Helper loaded: file_helper
INFO - 2024-06-18 18:45:47 --> Helper loaded: form_helper
INFO - 2024-06-18 18:45:47 --> Helper loaded: my_helper
INFO - 2024-06-18 18:45:47 --> Database Driver Class Initialized
INFO - 2024-06-18 18:45:47 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-18 18:45:47 --> Controller Class Initialized
DEBUG - 2024-06-18 18:45:47 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/views/list.php
DEBUG - 2024-06-18 18:45:47 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-06-18 18:45:47 --> Final output sent to browser
DEBUG - 2024-06-18 18:45:47 --> Total execution time: 0.0382
INFO - 2024-06-18 18:45:49 --> Config Class Initialized
INFO - 2024-06-18 18:45:49 --> Hooks Class Initialized
DEBUG - 2024-06-18 18:45:49 --> UTF-8 Support Enabled
INFO - 2024-06-18 18:45:49 --> Utf8 Class Initialized
INFO - 2024-06-18 18:45:49 --> URI Class Initialized
INFO - 2024-06-18 18:45:49 --> Router Class Initialized
INFO - 2024-06-18 18:45:49 --> Output Class Initialized
INFO - 2024-06-18 18:45:49 --> Security Class Initialized
DEBUG - 2024-06-18 18:45:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-18 18:45:49 --> Input Class Initialized
INFO - 2024-06-18 18:45:49 --> Language Class Initialized
INFO - 2024-06-18 18:45:49 --> Language Class Initialized
INFO - 2024-06-18 18:45:49 --> Config Class Initialized
INFO - 2024-06-18 18:45:49 --> Loader Class Initialized
INFO - 2024-06-18 18:45:49 --> Helper loaded: url_helper
INFO - 2024-06-18 18:45:49 --> Helper loaded: file_helper
INFO - 2024-06-18 18:45:49 --> Helper loaded: form_helper
INFO - 2024-06-18 18:45:49 --> Helper loaded: my_helper
INFO - 2024-06-18 18:45:49 --> Database Driver Class Initialized
INFO - 2024-06-18 18:45:49 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-18 18:45:49 --> Controller Class Initialized
DEBUG - 2024-06-18 18:45:49 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/views/cetak_tahfiz.php
INFO - 2024-06-18 18:45:56 --> Config Class Initialized
INFO - 2024-06-18 18:45:56 --> Hooks Class Initialized
DEBUG - 2024-06-18 18:45:56 --> UTF-8 Support Enabled
INFO - 2024-06-18 18:45:56 --> Utf8 Class Initialized
INFO - 2024-06-18 18:45:56 --> URI Class Initialized
INFO - 2024-06-18 18:45:56 --> Router Class Initialized
INFO - 2024-06-18 18:45:56 --> Output Class Initialized
INFO - 2024-06-18 18:45:56 --> Security Class Initialized
DEBUG - 2024-06-18 18:45:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-18 18:45:56 --> Input Class Initialized
INFO - 2024-06-18 18:45:56 --> Language Class Initialized
INFO - 2024-06-18 18:45:56 --> Language Class Initialized
INFO - 2024-06-18 18:45:56 --> Config Class Initialized
INFO - 2024-06-18 18:45:56 --> Loader Class Initialized
INFO - 2024-06-18 18:45:56 --> Helper loaded: url_helper
INFO - 2024-06-18 18:45:56 --> Helper loaded: file_helper
INFO - 2024-06-18 18:45:56 --> Helper loaded: form_helper
INFO - 2024-06-18 18:45:56 --> Helper loaded: my_helper
INFO - 2024-06-18 18:45:56 --> Database Driver Class Initialized
INFO - 2024-06-18 18:45:56 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-18 18:45:56 --> Controller Class Initialized
DEBUG - 2024-06-18 18:45:56 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/views/cetak_tahfiz.php
INFO - 2024-06-18 18:45:59 --> Final output sent to browser
DEBUG - 2024-06-18 18:45:59 --> Total execution time: 3.3394
INFO - 2024-06-18 18:46:06 --> Config Class Initialized
INFO - 2024-06-18 18:46:06 --> Hooks Class Initialized
DEBUG - 2024-06-18 18:46:06 --> UTF-8 Support Enabled
INFO - 2024-06-18 18:46:06 --> Utf8 Class Initialized
INFO - 2024-06-18 18:46:06 --> URI Class Initialized
INFO - 2024-06-18 18:46:06 --> Router Class Initialized
INFO - 2024-06-18 18:46:06 --> Output Class Initialized
INFO - 2024-06-18 18:46:06 --> Security Class Initialized
DEBUG - 2024-06-18 18:46:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-18 18:46:06 --> Input Class Initialized
INFO - 2024-06-18 18:46:06 --> Language Class Initialized
INFO - 2024-06-18 18:46:06 --> Language Class Initialized
INFO - 2024-06-18 18:46:06 --> Config Class Initialized
INFO - 2024-06-18 18:46:06 --> Loader Class Initialized
INFO - 2024-06-18 18:46:06 --> Helper loaded: url_helper
INFO - 2024-06-18 18:46:06 --> Helper loaded: file_helper
INFO - 2024-06-18 18:46:06 --> Helper loaded: form_helper
INFO - 2024-06-18 18:46:06 --> Helper loaded: my_helper
INFO - 2024-06-18 18:46:06 --> Database Driver Class Initialized
INFO - 2024-06-18 18:46:06 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-18 18:46:06 --> Controller Class Initialized
DEBUG - 2024-06-18 18:46:06 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/views/cetak.php
INFO - 2024-06-18 18:46:06 --> Final output sent to browser
DEBUG - 2024-06-18 18:46:06 --> Total execution time: 0.1014
INFO - 2024-06-18 18:46:35 --> Config Class Initialized
INFO - 2024-06-18 18:46:35 --> Hooks Class Initialized
DEBUG - 2024-06-18 18:46:35 --> UTF-8 Support Enabled
INFO - 2024-06-18 18:46:35 --> Utf8 Class Initialized
INFO - 2024-06-18 18:46:35 --> URI Class Initialized
INFO - 2024-06-18 18:46:35 --> Router Class Initialized
INFO - 2024-06-18 18:46:35 --> Output Class Initialized
INFO - 2024-06-18 18:46:35 --> Security Class Initialized
DEBUG - 2024-06-18 18:46:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-18 18:46:35 --> Input Class Initialized
INFO - 2024-06-18 18:46:35 --> Language Class Initialized
INFO - 2024-06-18 18:46:35 --> Language Class Initialized
INFO - 2024-06-18 18:46:35 --> Config Class Initialized
INFO - 2024-06-18 18:46:35 --> Loader Class Initialized
INFO - 2024-06-18 18:46:35 --> Helper loaded: url_helper
INFO - 2024-06-18 18:46:35 --> Helper loaded: file_helper
INFO - 2024-06-18 18:46:35 --> Helper loaded: form_helper
INFO - 2024-06-18 18:46:35 --> Helper loaded: my_helper
INFO - 2024-06-18 18:46:35 --> Database Driver Class Initialized
INFO - 2024-06-18 18:46:35 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-18 18:46:35 --> Controller Class Initialized
DEBUG - 2024-06-18 18:46:35 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/views/form.php
DEBUG - 2024-06-18 18:46:35 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-06-18 18:46:35 --> Final output sent to browser
DEBUG - 2024-06-18 18:46:35 --> Total execution time: 0.0316
INFO - 2024-06-18 18:46:40 --> Config Class Initialized
INFO - 2024-06-18 18:46:40 --> Hooks Class Initialized
DEBUG - 2024-06-18 18:46:40 --> UTF-8 Support Enabled
INFO - 2024-06-18 18:46:40 --> Utf8 Class Initialized
INFO - 2024-06-18 18:46:40 --> URI Class Initialized
INFO - 2024-06-18 18:46:40 --> Router Class Initialized
INFO - 2024-06-18 18:46:40 --> Output Class Initialized
INFO - 2024-06-18 18:46:40 --> Security Class Initialized
DEBUG - 2024-06-18 18:46:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-18 18:46:40 --> Input Class Initialized
INFO - 2024-06-18 18:46:40 --> Language Class Initialized
INFO - 2024-06-18 18:46:40 --> Language Class Initialized
INFO - 2024-06-18 18:46:40 --> Config Class Initialized
INFO - 2024-06-18 18:46:40 --> Loader Class Initialized
INFO - 2024-06-18 18:46:40 --> Helper loaded: url_helper
INFO - 2024-06-18 18:46:40 --> Helper loaded: file_helper
INFO - 2024-06-18 18:46:40 --> Helper loaded: form_helper
INFO - 2024-06-18 18:46:40 --> Helper loaded: my_helper
INFO - 2024-06-18 18:46:40 --> Database Driver Class Initialized
INFO - 2024-06-18 18:46:40 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-18 18:46:40 --> Controller Class Initialized
INFO - 2024-06-18 18:46:40 --> Config Class Initialized
INFO - 2024-06-18 18:46:40 --> Hooks Class Initialized
DEBUG - 2024-06-18 18:46:40 --> UTF-8 Support Enabled
INFO - 2024-06-18 18:46:40 --> Utf8 Class Initialized
INFO - 2024-06-18 18:46:40 --> URI Class Initialized
INFO - 2024-06-18 18:46:40 --> Router Class Initialized
INFO - 2024-06-18 18:46:40 --> Output Class Initialized
INFO - 2024-06-18 18:46:40 --> Security Class Initialized
DEBUG - 2024-06-18 18:46:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-18 18:46:40 --> Input Class Initialized
INFO - 2024-06-18 18:46:40 --> Language Class Initialized
INFO - 2024-06-18 18:46:40 --> Language Class Initialized
INFO - 2024-06-18 18:46:40 --> Config Class Initialized
INFO - 2024-06-18 18:46:40 --> Loader Class Initialized
INFO - 2024-06-18 18:46:40 --> Helper loaded: url_helper
INFO - 2024-06-18 18:46:40 --> Helper loaded: file_helper
INFO - 2024-06-18 18:46:40 --> Helper loaded: form_helper
INFO - 2024-06-18 18:46:40 --> Helper loaded: my_helper
INFO - 2024-06-18 18:46:40 --> Database Driver Class Initialized
INFO - 2024-06-18 18:46:40 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-18 18:46:40 --> Controller Class Initialized
DEBUG - 2024-06-18 18:46:40 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/views/list.php
DEBUG - 2024-06-18 18:46:40 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-06-18 18:46:40 --> Final output sent to browser
DEBUG - 2024-06-18 18:46:40 --> Total execution time: 0.0398
INFO - 2024-06-18 18:46:40 --> Config Class Initialized
INFO - 2024-06-18 18:46:40 --> Hooks Class Initialized
DEBUG - 2024-06-18 18:46:40 --> UTF-8 Support Enabled
INFO - 2024-06-18 18:46:40 --> Utf8 Class Initialized
INFO - 2024-06-18 18:46:40 --> URI Class Initialized
INFO - 2024-06-18 18:46:40 --> Router Class Initialized
INFO - 2024-06-18 18:46:40 --> Output Class Initialized
INFO - 2024-06-18 18:46:40 --> Security Class Initialized
DEBUG - 2024-06-18 18:46:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-18 18:46:40 --> Input Class Initialized
INFO - 2024-06-18 18:46:40 --> Language Class Initialized
INFO - 2024-06-18 18:46:40 --> Language Class Initialized
INFO - 2024-06-18 18:46:40 --> Config Class Initialized
INFO - 2024-06-18 18:46:40 --> Loader Class Initialized
INFO - 2024-06-18 18:46:40 --> Helper loaded: url_helper
INFO - 2024-06-18 18:46:40 --> Helper loaded: file_helper
INFO - 2024-06-18 18:46:40 --> Helper loaded: form_helper
INFO - 2024-06-18 18:46:40 --> Helper loaded: my_helper
INFO - 2024-06-18 18:46:40 --> Database Driver Class Initialized
INFO - 2024-06-18 18:46:40 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-18 18:46:40 --> Controller Class Initialized
INFO - 2024-06-18 18:46:43 --> Config Class Initialized
INFO - 2024-06-18 18:46:43 --> Hooks Class Initialized
DEBUG - 2024-06-18 18:46:43 --> UTF-8 Support Enabled
INFO - 2024-06-18 18:46:43 --> Utf8 Class Initialized
INFO - 2024-06-18 18:46:43 --> URI Class Initialized
INFO - 2024-06-18 18:46:43 --> Router Class Initialized
INFO - 2024-06-18 18:46:43 --> Output Class Initialized
INFO - 2024-06-18 18:46:43 --> Security Class Initialized
DEBUG - 2024-06-18 18:46:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-18 18:46:43 --> Input Class Initialized
INFO - 2024-06-18 18:46:43 --> Language Class Initialized
INFO - 2024-06-18 18:46:43 --> Language Class Initialized
INFO - 2024-06-18 18:46:43 --> Config Class Initialized
INFO - 2024-06-18 18:46:43 --> Loader Class Initialized
INFO - 2024-06-18 18:46:43 --> Helper loaded: url_helper
INFO - 2024-06-18 18:46:43 --> Helper loaded: file_helper
INFO - 2024-06-18 18:46:43 --> Helper loaded: form_helper
INFO - 2024-06-18 18:46:43 --> Helper loaded: my_helper
INFO - 2024-06-18 18:46:43 --> Database Driver Class Initialized
INFO - 2024-06-18 18:46:43 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-18 18:46:43 --> Controller Class Initialized
INFO - 2024-06-18 18:46:43 --> Final output sent to browser
DEBUG - 2024-06-18 18:46:43 --> Total execution time: 0.0266
INFO - 2024-06-18 18:46:48 --> Config Class Initialized
INFO - 2024-06-18 18:46:48 --> Hooks Class Initialized
DEBUG - 2024-06-18 18:46:48 --> UTF-8 Support Enabled
INFO - 2024-06-18 18:46:48 --> Utf8 Class Initialized
INFO - 2024-06-18 18:46:48 --> URI Class Initialized
INFO - 2024-06-18 18:46:48 --> Router Class Initialized
INFO - 2024-06-18 18:46:48 --> Output Class Initialized
INFO - 2024-06-18 18:46:48 --> Security Class Initialized
DEBUG - 2024-06-18 18:46:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-18 18:46:48 --> Input Class Initialized
INFO - 2024-06-18 18:46:48 --> Language Class Initialized
INFO - 2024-06-18 18:46:48 --> Language Class Initialized
INFO - 2024-06-18 18:46:48 --> Config Class Initialized
INFO - 2024-06-18 18:46:48 --> Loader Class Initialized
INFO - 2024-06-18 18:46:48 --> Helper loaded: url_helper
INFO - 2024-06-18 18:46:48 --> Helper loaded: file_helper
INFO - 2024-06-18 18:46:48 --> Helper loaded: form_helper
INFO - 2024-06-18 18:46:48 --> Helper loaded: my_helper
INFO - 2024-06-18 18:46:48 --> Database Driver Class Initialized
INFO - 2024-06-18 18:46:48 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-18 18:46:48 --> Controller Class Initialized
INFO - 2024-06-18 18:46:48 --> Final output sent to browser
DEBUG - 2024-06-18 18:46:48 --> Total execution time: 0.0423
INFO - 2024-06-18 18:46:53 --> Config Class Initialized
INFO - 2024-06-18 18:46:53 --> Hooks Class Initialized
DEBUG - 2024-06-18 18:46:53 --> UTF-8 Support Enabled
INFO - 2024-06-18 18:46:53 --> Utf8 Class Initialized
INFO - 2024-06-18 18:46:53 --> URI Class Initialized
INFO - 2024-06-18 18:46:53 --> Router Class Initialized
INFO - 2024-06-18 18:46:53 --> Output Class Initialized
INFO - 2024-06-18 18:46:53 --> Security Class Initialized
DEBUG - 2024-06-18 18:46:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-18 18:46:53 --> Input Class Initialized
INFO - 2024-06-18 18:46:53 --> Language Class Initialized
INFO - 2024-06-18 18:46:53 --> Language Class Initialized
INFO - 2024-06-18 18:46:53 --> Config Class Initialized
INFO - 2024-06-18 18:46:53 --> Loader Class Initialized
INFO - 2024-06-18 18:46:53 --> Helper loaded: url_helper
INFO - 2024-06-18 18:46:53 --> Helper loaded: file_helper
INFO - 2024-06-18 18:46:53 --> Helper loaded: form_helper
INFO - 2024-06-18 18:46:53 --> Helper loaded: my_helper
INFO - 2024-06-18 18:46:53 --> Database Driver Class Initialized
INFO - 2024-06-18 18:46:53 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-18 18:46:53 --> Controller Class Initialized
DEBUG - 2024-06-18 18:46:53 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/views/cetak.php
INFO - 2024-06-18 18:46:53 --> Final output sent to browser
DEBUG - 2024-06-18 18:46:53 --> Total execution time: 0.1081
INFO - 2024-06-18 18:49:15 --> Config Class Initialized
INFO - 2024-06-18 18:49:15 --> Hooks Class Initialized
DEBUG - 2024-06-18 18:49:15 --> UTF-8 Support Enabled
INFO - 2024-06-18 18:49:15 --> Utf8 Class Initialized
INFO - 2024-06-18 18:49:15 --> URI Class Initialized
INFO - 2024-06-18 18:49:15 --> Router Class Initialized
INFO - 2024-06-18 18:49:15 --> Output Class Initialized
INFO - 2024-06-18 18:49:15 --> Security Class Initialized
DEBUG - 2024-06-18 18:49:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-18 18:49:15 --> Input Class Initialized
INFO - 2024-06-18 18:49:15 --> Language Class Initialized
INFO - 2024-06-18 18:49:15 --> Language Class Initialized
INFO - 2024-06-18 18:49:15 --> Config Class Initialized
INFO - 2024-06-18 18:49:15 --> Loader Class Initialized
INFO - 2024-06-18 18:49:15 --> Helper loaded: url_helper
INFO - 2024-06-18 18:49:15 --> Helper loaded: file_helper
INFO - 2024-06-18 18:49:15 --> Helper loaded: form_helper
INFO - 2024-06-18 18:49:15 --> Helper loaded: my_helper
INFO - 2024-06-18 18:49:15 --> Database Driver Class Initialized
INFO - 2024-06-18 18:49:15 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-18 18:49:15 --> Controller Class Initialized
DEBUG - 2024-06-18 18:49:15 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/view_mapel/views/v_view_mapel.php
DEBUG - 2024-06-18 18:49:15 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-06-18 18:49:15 --> Final output sent to browser
DEBUG - 2024-06-18 18:49:15 --> Total execution time: 0.0267
INFO - 2024-06-18 18:49:22 --> Config Class Initialized
INFO - 2024-06-18 18:49:22 --> Hooks Class Initialized
DEBUG - 2024-06-18 18:49:22 --> UTF-8 Support Enabled
INFO - 2024-06-18 18:49:22 --> Utf8 Class Initialized
INFO - 2024-06-18 18:49:22 --> URI Class Initialized
INFO - 2024-06-18 18:49:22 --> Router Class Initialized
INFO - 2024-06-18 18:49:22 --> Output Class Initialized
INFO - 2024-06-18 18:49:22 --> Security Class Initialized
DEBUG - 2024-06-18 18:49:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-18 18:49:22 --> Input Class Initialized
INFO - 2024-06-18 18:49:22 --> Language Class Initialized
INFO - 2024-06-18 18:49:22 --> Language Class Initialized
INFO - 2024-06-18 18:49:22 --> Config Class Initialized
INFO - 2024-06-18 18:49:22 --> Loader Class Initialized
INFO - 2024-06-18 18:49:22 --> Helper loaded: url_helper
INFO - 2024-06-18 18:49:22 --> Helper loaded: file_helper
INFO - 2024-06-18 18:49:22 --> Helper loaded: form_helper
INFO - 2024-06-18 18:49:22 --> Helper loaded: my_helper
INFO - 2024-06-18 18:49:22 --> Database Driver Class Initialized
INFO - 2024-06-18 18:49:22 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-18 18:49:22 --> Controller Class Initialized
DEBUG - 2024-06-18 18:49:22 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/views/list.php
DEBUG - 2024-06-18 18:49:22 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-06-18 18:49:22 --> Final output sent to browser
DEBUG - 2024-06-18 18:49:22 --> Total execution time: 0.0299
INFO - 2024-06-18 18:49:22 --> Config Class Initialized
INFO - 2024-06-18 18:49:22 --> Hooks Class Initialized
DEBUG - 2024-06-18 18:49:22 --> UTF-8 Support Enabled
INFO - 2024-06-18 18:49:22 --> Utf8 Class Initialized
INFO - 2024-06-18 18:49:22 --> URI Class Initialized
INFO - 2024-06-18 18:49:22 --> Router Class Initialized
INFO - 2024-06-18 18:49:22 --> Output Class Initialized
INFO - 2024-06-18 18:49:22 --> Security Class Initialized
DEBUG - 2024-06-18 18:49:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-18 18:49:22 --> Input Class Initialized
INFO - 2024-06-18 18:49:22 --> Language Class Initialized
INFO - 2024-06-18 18:49:22 --> Language Class Initialized
INFO - 2024-06-18 18:49:22 --> Config Class Initialized
INFO - 2024-06-18 18:49:22 --> Loader Class Initialized
INFO - 2024-06-18 18:49:22 --> Helper loaded: url_helper
INFO - 2024-06-18 18:49:22 --> Helper loaded: file_helper
INFO - 2024-06-18 18:49:22 --> Helper loaded: form_helper
INFO - 2024-06-18 18:49:22 --> Helper loaded: my_helper
INFO - 2024-06-18 18:49:22 --> Database Driver Class Initialized
INFO - 2024-06-18 18:49:22 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-18 18:49:22 --> Controller Class Initialized
INFO - 2024-06-18 19:15:33 --> Config Class Initialized
INFO - 2024-06-18 19:15:33 --> Hooks Class Initialized
DEBUG - 2024-06-18 19:15:33 --> UTF-8 Support Enabled
INFO - 2024-06-18 19:15:33 --> Utf8 Class Initialized
INFO - 2024-06-18 19:15:33 --> URI Class Initialized
INFO - 2024-06-18 19:15:33 --> Router Class Initialized
INFO - 2024-06-18 19:15:33 --> Output Class Initialized
INFO - 2024-06-18 19:15:33 --> Security Class Initialized
DEBUG - 2024-06-18 19:15:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-18 19:15:33 --> Input Class Initialized
INFO - 2024-06-18 19:15:33 --> Language Class Initialized
INFO - 2024-06-18 19:15:33 --> Language Class Initialized
INFO - 2024-06-18 19:15:33 --> Config Class Initialized
INFO - 2024-06-18 19:15:33 --> Loader Class Initialized
INFO - 2024-06-18 19:15:33 --> Helper loaded: url_helper
INFO - 2024-06-18 19:15:33 --> Helper loaded: file_helper
INFO - 2024-06-18 19:15:33 --> Helper loaded: form_helper
INFO - 2024-06-18 19:15:33 --> Helper loaded: my_helper
INFO - 2024-06-18 19:15:33 --> Database Driver Class Initialized
INFO - 2024-06-18 19:15:33 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-18 19:15:33 --> Controller Class Initialized
ERROR - 2024-06-18 19:15:33 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 3014
ERROR - 2024-06-18 19:15:33 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 3015
DEBUG - 2024-06-18 19:15:33 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/views/cetak_mh.php
INFO - 2024-06-18 19:15:37 --> Final output sent to browser
DEBUG - 2024-06-18 19:15:37 --> Total execution time: 4.3615
INFO - 2024-06-18 19:15:38 --> Config Class Initialized
INFO - 2024-06-18 19:15:38 --> Hooks Class Initialized
DEBUG - 2024-06-18 19:15:38 --> UTF-8 Support Enabled
INFO - 2024-06-18 19:15:38 --> Utf8 Class Initialized
INFO - 2024-06-18 19:15:38 --> URI Class Initialized
INFO - 2024-06-18 19:15:38 --> Router Class Initialized
INFO - 2024-06-18 19:15:38 --> Output Class Initialized
INFO - 2024-06-18 19:15:38 --> Security Class Initialized
DEBUG - 2024-06-18 19:15:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-18 19:15:38 --> Input Class Initialized
INFO - 2024-06-18 19:15:38 --> Language Class Initialized
INFO - 2024-06-18 19:15:38 --> Language Class Initialized
INFO - 2024-06-18 19:15:38 --> Config Class Initialized
INFO - 2024-06-18 19:15:38 --> Loader Class Initialized
INFO - 2024-06-18 19:15:38 --> Helper loaded: url_helper
INFO - 2024-06-18 19:15:38 --> Helper loaded: file_helper
INFO - 2024-06-18 19:15:38 --> Helper loaded: form_helper
INFO - 2024-06-18 19:15:38 --> Helper loaded: my_helper
INFO - 2024-06-18 19:15:38 --> Database Driver Class Initialized
INFO - 2024-06-18 19:15:38 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-18 19:15:38 --> Controller Class Initialized
DEBUG - 2024-06-18 19:15:38 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/views/cetak_ikm.php
INFO - 2024-06-18 19:15:40 --> Final output sent to browser
DEBUG - 2024-06-18 19:15:40 --> Total execution time: 1.6932
INFO - 2024-06-18 19:16:14 --> Config Class Initialized
INFO - 2024-06-18 19:16:14 --> Hooks Class Initialized
DEBUG - 2024-06-18 19:16:14 --> UTF-8 Support Enabled
INFO - 2024-06-18 19:16:14 --> Utf8 Class Initialized
INFO - 2024-06-18 19:16:14 --> URI Class Initialized
INFO - 2024-06-18 19:16:14 --> Router Class Initialized
INFO - 2024-06-18 19:16:14 --> Output Class Initialized
INFO - 2024-06-18 19:16:14 --> Security Class Initialized
DEBUG - 2024-06-18 19:16:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-18 19:16:14 --> Input Class Initialized
INFO - 2024-06-18 19:16:14 --> Language Class Initialized
INFO - 2024-06-18 19:16:14 --> Language Class Initialized
INFO - 2024-06-18 19:16:14 --> Config Class Initialized
INFO - 2024-06-18 19:16:14 --> Loader Class Initialized
INFO - 2024-06-18 19:16:14 --> Helper loaded: url_helper
INFO - 2024-06-18 19:16:14 --> Helper loaded: file_helper
INFO - 2024-06-18 19:16:14 --> Helper loaded: form_helper
INFO - 2024-06-18 19:16:14 --> Helper loaded: my_helper
INFO - 2024-06-18 19:16:14 --> Database Driver Class Initialized
INFO - 2024-06-18 19:16:14 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-18 19:16:14 --> Controller Class Initialized
DEBUG - 2024-06-18 19:16:14 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/views/cetak_ikm.php
INFO - 2024-06-18 19:16:16 --> Final output sent to browser
DEBUG - 2024-06-18 19:16:16 --> Total execution time: 1.7198
INFO - 2024-06-18 19:21:32 --> Config Class Initialized
INFO - 2024-06-18 19:21:32 --> Hooks Class Initialized
DEBUG - 2024-06-18 19:21:32 --> UTF-8 Support Enabled
INFO - 2024-06-18 19:21:32 --> Utf8 Class Initialized
INFO - 2024-06-18 19:21:32 --> URI Class Initialized
INFO - 2024-06-18 19:21:32 --> Router Class Initialized
INFO - 2024-06-18 19:21:32 --> Output Class Initialized
INFO - 2024-06-18 19:21:32 --> Security Class Initialized
DEBUG - 2024-06-18 19:21:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-18 19:21:32 --> Input Class Initialized
INFO - 2024-06-18 19:21:32 --> Language Class Initialized
INFO - 2024-06-18 19:21:32 --> Language Class Initialized
INFO - 2024-06-18 19:21:32 --> Config Class Initialized
INFO - 2024-06-18 19:21:32 --> Loader Class Initialized
INFO - 2024-06-18 19:21:32 --> Helper loaded: url_helper
INFO - 2024-06-18 19:21:32 --> Helper loaded: file_helper
INFO - 2024-06-18 19:21:32 --> Helper loaded: form_helper
INFO - 2024-06-18 19:21:32 --> Helper loaded: my_helper
INFO - 2024-06-18 19:21:32 --> Database Driver Class Initialized
INFO - 2024-06-18 19:21:32 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-18 19:21:32 --> Controller Class Initialized
ERROR - 2024-06-18 19:21:32 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 3014
ERROR - 2024-06-18 19:21:32 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 3015
DEBUG - 2024-06-18 19:21:32 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/views/cetak_mh.php
INFO - 2024-06-18 19:21:36 --> Final output sent to browser
DEBUG - 2024-06-18 19:21:36 --> Total execution time: 4.0690
INFO - 2024-06-18 21:21:11 --> Config Class Initialized
INFO - 2024-06-18 21:21:11 --> Hooks Class Initialized
DEBUG - 2024-06-18 21:21:11 --> UTF-8 Support Enabled
INFO - 2024-06-18 21:21:11 --> Utf8 Class Initialized
INFO - 2024-06-18 21:21:11 --> URI Class Initialized
INFO - 2024-06-18 21:21:11 --> Router Class Initialized
INFO - 2024-06-18 21:21:11 --> Output Class Initialized
INFO - 2024-06-18 21:21:11 --> Security Class Initialized
DEBUG - 2024-06-18 21:21:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-18 21:21:11 --> Input Class Initialized
INFO - 2024-06-18 21:21:11 --> Language Class Initialized
INFO - 2024-06-18 21:21:11 --> Language Class Initialized
INFO - 2024-06-18 21:21:11 --> Config Class Initialized
INFO - 2024-06-18 21:21:11 --> Loader Class Initialized
INFO - 2024-06-18 21:21:11 --> Helper loaded: url_helper
INFO - 2024-06-18 21:21:11 --> Helper loaded: file_helper
INFO - 2024-06-18 21:21:11 --> Helper loaded: form_helper
INFO - 2024-06-18 21:21:11 --> Helper loaded: my_helper
INFO - 2024-06-18 21:21:11 --> Database Driver Class Initialized
INFO - 2024-06-18 21:21:11 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-18 21:21:11 --> Controller Class Initialized
DEBUG - 2024-06-18 21:21:11 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/views/list.php
DEBUG - 2024-06-18 21:21:11 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-06-18 21:21:11 --> Final output sent to browser
DEBUG - 2024-06-18 21:21:11 --> Total execution time: 0.0471
INFO - 2024-06-18 21:21:14 --> Config Class Initialized
INFO - 2024-06-18 21:21:14 --> Hooks Class Initialized
DEBUG - 2024-06-18 21:21:14 --> UTF-8 Support Enabled
INFO - 2024-06-18 21:21:14 --> Utf8 Class Initialized
INFO - 2024-06-18 21:21:14 --> URI Class Initialized
INFO - 2024-06-18 21:21:14 --> Router Class Initialized
INFO - 2024-06-18 21:21:14 --> Output Class Initialized
INFO - 2024-06-18 21:21:14 --> Security Class Initialized
DEBUG - 2024-06-18 21:21:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-18 21:21:14 --> Input Class Initialized
INFO - 2024-06-18 21:21:14 --> Language Class Initialized
INFO - 2024-06-18 21:21:14 --> Language Class Initialized
INFO - 2024-06-18 21:21:14 --> Config Class Initialized
INFO - 2024-06-18 21:21:14 --> Loader Class Initialized
INFO - 2024-06-18 21:21:14 --> Helper loaded: url_helper
INFO - 2024-06-18 21:21:14 --> Helper loaded: file_helper
INFO - 2024-06-18 21:21:14 --> Helper loaded: form_helper
INFO - 2024-06-18 21:21:14 --> Helper loaded: my_helper
INFO - 2024-06-18 21:21:14 --> Database Driver Class Initialized
INFO - 2024-06-18 21:21:14 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-18 21:21:14 --> Controller Class Initialized
DEBUG - 2024-06-18 21:21:14 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/views/list.php
DEBUG - 2024-06-18 21:21:14 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-06-18 21:21:14 --> Final output sent to browser
DEBUG - 2024-06-18 21:21:14 --> Total execution time: 0.0315
INFO - 2024-06-18 21:21:21 --> Config Class Initialized
INFO - 2024-06-18 21:21:21 --> Hooks Class Initialized
DEBUG - 2024-06-18 21:21:21 --> UTF-8 Support Enabled
INFO - 2024-06-18 21:21:21 --> Utf8 Class Initialized
INFO - 2024-06-18 21:21:21 --> URI Class Initialized
INFO - 2024-06-18 21:21:21 --> Router Class Initialized
INFO - 2024-06-18 21:21:21 --> Output Class Initialized
INFO - 2024-06-18 21:21:21 --> Security Class Initialized
DEBUG - 2024-06-18 21:21:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-18 21:21:21 --> Input Class Initialized
INFO - 2024-06-18 21:21:21 --> Language Class Initialized
INFO - 2024-06-18 21:21:21 --> Language Class Initialized
INFO - 2024-06-18 21:21:21 --> Config Class Initialized
INFO - 2024-06-18 21:21:21 --> Loader Class Initialized
INFO - 2024-06-18 21:21:21 --> Helper loaded: url_helper
INFO - 2024-06-18 21:21:21 --> Helper loaded: file_helper
INFO - 2024-06-18 21:21:21 --> Helper loaded: form_helper
INFO - 2024-06-18 21:21:21 --> Helper loaded: my_helper
INFO - 2024-06-18 21:21:21 --> Database Driver Class Initialized
INFO - 2024-06-18 21:21:21 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-18 21:21:21 --> Controller Class Initialized
DEBUG - 2024-06-18 21:21:21 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_catatan_kl1/views/list.php
DEBUG - 2024-06-18 21:21:21 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-06-18 21:21:21 --> Final output sent to browser
DEBUG - 2024-06-18 21:21:21 --> Total execution time: 0.0303
INFO - 2024-06-18 21:22:00 --> Config Class Initialized
INFO - 2024-06-18 21:22:00 --> Hooks Class Initialized
DEBUG - 2024-06-18 21:22:00 --> UTF-8 Support Enabled
INFO - 2024-06-18 21:22:00 --> Utf8 Class Initialized
INFO - 2024-06-18 21:22:00 --> URI Class Initialized
INFO - 2024-06-18 21:22:00 --> Router Class Initialized
INFO - 2024-06-18 21:22:00 --> Output Class Initialized
INFO - 2024-06-18 21:22:00 --> Security Class Initialized
DEBUG - 2024-06-18 21:22:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-18 21:22:00 --> Input Class Initialized
INFO - 2024-06-18 21:22:00 --> Language Class Initialized
INFO - 2024-06-18 21:22:00 --> Language Class Initialized
INFO - 2024-06-18 21:22:00 --> Config Class Initialized
INFO - 2024-06-18 21:22:00 --> Loader Class Initialized
INFO - 2024-06-18 21:22:00 --> Helper loaded: url_helper
INFO - 2024-06-18 21:22:00 --> Helper loaded: file_helper
INFO - 2024-06-18 21:22:00 --> Helper loaded: form_helper
INFO - 2024-06-18 21:22:00 --> Helper loaded: my_helper
INFO - 2024-06-18 21:22:00 --> Database Driver Class Initialized
INFO - 2024-06-18 21:22:00 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-18 21:22:00 --> Controller Class Initialized
INFO - 2024-06-18 21:22:01 --> Final output sent to browser
DEBUG - 2024-06-18 21:22:01 --> Total execution time: 0.2023
INFO - 2024-06-18 21:22:11 --> Config Class Initialized
INFO - 2024-06-18 21:22:11 --> Hooks Class Initialized
DEBUG - 2024-06-18 21:22:11 --> UTF-8 Support Enabled
INFO - 2024-06-18 21:22:11 --> Utf8 Class Initialized
INFO - 2024-06-18 21:22:11 --> URI Class Initialized
INFO - 2024-06-18 21:22:11 --> Router Class Initialized
INFO - 2024-06-18 21:22:11 --> Output Class Initialized
INFO - 2024-06-18 21:22:11 --> Security Class Initialized
DEBUG - 2024-06-18 21:22:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-18 21:22:11 --> Input Class Initialized
INFO - 2024-06-18 21:22:11 --> Language Class Initialized
INFO - 2024-06-18 21:22:11 --> Language Class Initialized
INFO - 2024-06-18 21:22:11 --> Config Class Initialized
INFO - 2024-06-18 21:22:11 --> Loader Class Initialized
INFO - 2024-06-18 21:22:11 --> Helper loaded: url_helper
INFO - 2024-06-18 21:22:11 --> Helper loaded: file_helper
INFO - 2024-06-18 21:22:11 --> Helper loaded: form_helper
INFO - 2024-06-18 21:22:11 --> Helper loaded: my_helper
INFO - 2024-06-18 21:22:11 --> Database Driver Class Initialized
INFO - 2024-06-18 21:22:11 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-18 21:22:11 --> Controller Class Initialized
DEBUG - 2024-06-18 21:22:11 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/views/list.php
DEBUG - 2024-06-18 21:22:11 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-06-18 21:22:11 --> Final output sent to browser
DEBUG - 2024-06-18 21:22:11 --> Total execution time: 0.0358
INFO - 2024-06-18 21:22:20 --> Config Class Initialized
INFO - 2024-06-18 21:22:20 --> Hooks Class Initialized
DEBUG - 2024-06-18 21:22:20 --> UTF-8 Support Enabled
INFO - 2024-06-18 21:22:20 --> Utf8 Class Initialized
INFO - 2024-06-18 21:22:20 --> URI Class Initialized
INFO - 2024-06-18 21:22:20 --> Router Class Initialized
INFO - 2024-06-18 21:22:20 --> Output Class Initialized
INFO - 2024-06-18 21:22:20 --> Security Class Initialized
DEBUG - 2024-06-18 21:22:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-18 21:22:20 --> Input Class Initialized
INFO - 2024-06-18 21:22:20 --> Language Class Initialized
INFO - 2024-06-18 21:22:20 --> Language Class Initialized
INFO - 2024-06-18 21:22:20 --> Config Class Initialized
INFO - 2024-06-18 21:22:20 --> Loader Class Initialized
INFO - 2024-06-18 21:22:20 --> Helper loaded: url_helper
INFO - 2024-06-18 21:22:20 --> Helper loaded: file_helper
INFO - 2024-06-18 21:22:20 --> Helper loaded: form_helper
INFO - 2024-06-18 21:22:20 --> Helper loaded: my_helper
INFO - 2024-06-18 21:22:20 --> Database Driver Class Initialized
INFO - 2024-06-18 21:22:20 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-18 21:22:20 --> Controller Class Initialized
DEBUG - 2024-06-18 21:22:20 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/views/cetak_ikm.php
INFO - 2024-06-18 21:22:22 --> Final output sent to browser
DEBUG - 2024-06-18 21:22:22 --> Total execution time: 1.7412
INFO - 2024-06-18 21:23:34 --> Config Class Initialized
INFO - 2024-06-18 21:23:34 --> Hooks Class Initialized
DEBUG - 2024-06-18 21:23:34 --> UTF-8 Support Enabled
INFO - 2024-06-18 21:23:34 --> Utf8 Class Initialized
INFO - 2024-06-18 21:23:34 --> URI Class Initialized
INFO - 2024-06-18 21:23:34 --> Router Class Initialized
INFO - 2024-06-18 21:23:34 --> Output Class Initialized
INFO - 2024-06-18 21:23:34 --> Security Class Initialized
DEBUG - 2024-06-18 21:23:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-18 21:23:34 --> Input Class Initialized
INFO - 2024-06-18 21:23:34 --> Language Class Initialized
INFO - 2024-06-18 21:23:34 --> Language Class Initialized
INFO - 2024-06-18 21:23:34 --> Config Class Initialized
INFO - 2024-06-18 21:23:34 --> Loader Class Initialized
INFO - 2024-06-18 21:23:34 --> Helper loaded: url_helper
INFO - 2024-06-18 21:23:34 --> Helper loaded: file_helper
INFO - 2024-06-18 21:23:34 --> Helper loaded: form_helper
INFO - 2024-06-18 21:23:34 --> Helper loaded: my_helper
INFO - 2024-06-18 21:23:34 --> Database Driver Class Initialized
INFO - 2024-06-18 21:23:34 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-18 21:23:34 --> Controller Class Initialized
ERROR - 2024-06-18 21:23:34 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 3014
ERROR - 2024-06-18 21:23:34 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 3015
DEBUG - 2024-06-18 21:23:34 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/views/cetak_mh.php
INFO - 2024-06-18 21:23:39 --> Final output sent to browser
DEBUG - 2024-06-18 21:23:39 --> Total execution time: 4.3291
INFO - 2024-06-18 21:24:44 --> Config Class Initialized
INFO - 2024-06-18 21:24:44 --> Hooks Class Initialized
DEBUG - 2024-06-18 21:24:44 --> UTF-8 Support Enabled
INFO - 2024-06-18 21:24:44 --> Utf8 Class Initialized
INFO - 2024-06-18 21:24:44 --> URI Class Initialized
INFO - 2024-06-18 21:24:44 --> Router Class Initialized
INFO - 2024-06-18 21:24:44 --> Output Class Initialized
INFO - 2024-06-18 21:24:44 --> Security Class Initialized
DEBUG - 2024-06-18 21:24:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-18 21:24:44 --> Input Class Initialized
INFO - 2024-06-18 21:24:44 --> Language Class Initialized
INFO - 2024-06-18 21:24:44 --> Language Class Initialized
INFO - 2024-06-18 21:24:44 --> Config Class Initialized
INFO - 2024-06-18 21:24:44 --> Loader Class Initialized
INFO - 2024-06-18 21:24:44 --> Helper loaded: url_helper
INFO - 2024-06-18 21:24:44 --> Helper loaded: file_helper
INFO - 2024-06-18 21:24:44 --> Helper loaded: form_helper
INFO - 2024-06-18 21:24:44 --> Helper loaded: my_helper
INFO - 2024-06-18 21:24:44 --> Database Driver Class Initialized
INFO - 2024-06-18 21:24:44 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-18 21:24:44 --> Controller Class Initialized
DEBUG - 2024-06-18 21:24:44 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/views/list.php
DEBUG - 2024-06-18 21:24:44 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-06-18 21:24:44 --> Final output sent to browser
DEBUG - 2024-06-18 21:24:44 --> Total execution time: 0.0306
INFO - 2024-06-18 21:24:44 --> Config Class Initialized
INFO - 2024-06-18 21:24:44 --> Hooks Class Initialized
DEBUG - 2024-06-18 21:24:44 --> UTF-8 Support Enabled
INFO - 2024-06-18 21:24:44 --> Utf8 Class Initialized
INFO - 2024-06-18 21:24:44 --> URI Class Initialized
INFO - 2024-06-18 21:24:44 --> Router Class Initialized
INFO - 2024-06-18 21:24:44 --> Output Class Initialized
INFO - 2024-06-18 21:24:44 --> Security Class Initialized
DEBUG - 2024-06-18 21:24:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-18 21:24:44 --> Input Class Initialized
INFO - 2024-06-18 21:24:44 --> Language Class Initialized
INFO - 2024-06-18 21:24:44 --> Language Class Initialized
INFO - 2024-06-18 21:24:44 --> Config Class Initialized
INFO - 2024-06-18 21:24:44 --> Loader Class Initialized
INFO - 2024-06-18 21:24:44 --> Helper loaded: url_helper
INFO - 2024-06-18 21:24:44 --> Helper loaded: file_helper
INFO - 2024-06-18 21:24:44 --> Helper loaded: form_helper
INFO - 2024-06-18 21:24:44 --> Helper loaded: my_helper
INFO - 2024-06-18 21:24:44 --> Database Driver Class Initialized
INFO - 2024-06-18 21:24:44 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-18 21:24:44 --> Controller Class Initialized
INFO - 2024-06-18 21:24:48 --> Config Class Initialized
INFO - 2024-06-18 21:24:48 --> Hooks Class Initialized
DEBUG - 2024-06-18 21:24:48 --> UTF-8 Support Enabled
INFO - 2024-06-18 21:24:48 --> Utf8 Class Initialized
INFO - 2024-06-18 21:24:48 --> URI Class Initialized
DEBUG - 2024-06-18 21:24:48 --> No URI present. Default controller set.
INFO - 2024-06-18 21:24:48 --> Router Class Initialized
INFO - 2024-06-18 21:24:48 --> Output Class Initialized
INFO - 2024-06-18 21:24:48 --> Security Class Initialized
DEBUG - 2024-06-18 21:24:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-18 21:24:48 --> Input Class Initialized
INFO - 2024-06-18 21:24:48 --> Language Class Initialized
INFO - 2024-06-18 21:24:48 --> Language Class Initialized
INFO - 2024-06-18 21:24:48 --> Config Class Initialized
INFO - 2024-06-18 21:24:48 --> Loader Class Initialized
INFO - 2024-06-18 21:24:48 --> Helper loaded: url_helper
INFO - 2024-06-18 21:24:48 --> Helper loaded: file_helper
INFO - 2024-06-18 21:24:48 --> Helper loaded: form_helper
INFO - 2024-06-18 21:24:48 --> Helper loaded: my_helper
INFO - 2024-06-18 21:24:48 --> Database Driver Class Initialized
INFO - 2024-06-18 21:24:48 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-18 21:24:48 --> Controller Class Initialized
INFO - 2024-06-18 21:24:48 --> Config Class Initialized
INFO - 2024-06-18 21:24:48 --> Hooks Class Initialized
DEBUG - 2024-06-18 21:24:48 --> UTF-8 Support Enabled
INFO - 2024-06-18 21:24:48 --> Utf8 Class Initialized
INFO - 2024-06-18 21:24:48 --> URI Class Initialized
INFO - 2024-06-18 21:24:48 --> Router Class Initialized
INFO - 2024-06-18 21:24:48 --> Output Class Initialized
INFO - 2024-06-18 21:24:48 --> Security Class Initialized
DEBUG - 2024-06-18 21:24:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-18 21:24:48 --> Input Class Initialized
INFO - 2024-06-18 21:24:48 --> Language Class Initialized
INFO - 2024-06-18 21:24:48 --> Language Class Initialized
INFO - 2024-06-18 21:24:48 --> Config Class Initialized
INFO - 2024-06-18 21:24:48 --> Loader Class Initialized
INFO - 2024-06-18 21:24:48 --> Helper loaded: url_helper
INFO - 2024-06-18 21:24:48 --> Helper loaded: file_helper
INFO - 2024-06-18 21:24:48 --> Helper loaded: form_helper
INFO - 2024-06-18 21:24:48 --> Helper loaded: my_helper
INFO - 2024-06-18 21:24:48 --> Database Driver Class Initialized
INFO - 2024-06-18 21:24:48 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-18 21:24:48 --> Controller Class Initialized
DEBUG - 2024-06-18 21:24:48 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/login/views/login.php
DEBUG - 2024-06-18 21:24:48 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-06-18 21:24:48 --> Final output sent to browser
DEBUG - 2024-06-18 21:24:48 --> Total execution time: 0.0303
INFO - 2024-06-18 21:24:52 --> Config Class Initialized
INFO - 2024-06-18 21:24:52 --> Hooks Class Initialized
DEBUG - 2024-06-18 21:24:52 --> UTF-8 Support Enabled
INFO - 2024-06-18 21:24:52 --> Utf8 Class Initialized
INFO - 2024-06-18 21:24:52 --> URI Class Initialized
INFO - 2024-06-18 21:24:52 --> Router Class Initialized
INFO - 2024-06-18 21:24:52 --> Output Class Initialized
INFO - 2024-06-18 21:24:52 --> Security Class Initialized
DEBUG - 2024-06-18 21:24:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-18 21:24:52 --> Input Class Initialized
INFO - 2024-06-18 21:24:52 --> Language Class Initialized
INFO - 2024-06-18 21:24:52 --> Language Class Initialized
INFO - 2024-06-18 21:24:52 --> Config Class Initialized
INFO - 2024-06-18 21:24:52 --> Loader Class Initialized
INFO - 2024-06-18 21:24:52 --> Helper loaded: url_helper
INFO - 2024-06-18 21:24:52 --> Helper loaded: file_helper
INFO - 2024-06-18 21:24:52 --> Helper loaded: form_helper
INFO - 2024-06-18 21:24:52 --> Helper loaded: my_helper
INFO - 2024-06-18 21:24:52 --> Database Driver Class Initialized
INFO - 2024-06-18 21:24:52 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-18 21:24:52 --> Controller Class Initialized
INFO - 2024-06-18 21:24:52 --> Helper loaded: cookie_helper
INFO - 2024-06-18 21:24:52 --> Final output sent to browser
DEBUG - 2024-06-18 21:24:52 --> Total execution time: 0.0378
INFO - 2024-06-18 21:24:52 --> Config Class Initialized
INFO - 2024-06-18 21:24:52 --> Hooks Class Initialized
DEBUG - 2024-06-18 21:24:52 --> UTF-8 Support Enabled
INFO - 2024-06-18 21:24:52 --> Utf8 Class Initialized
INFO - 2024-06-18 21:24:52 --> URI Class Initialized
INFO - 2024-06-18 21:24:52 --> Router Class Initialized
INFO - 2024-06-18 21:24:52 --> Output Class Initialized
INFO - 2024-06-18 21:24:52 --> Security Class Initialized
DEBUG - 2024-06-18 21:24:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-18 21:24:52 --> Input Class Initialized
INFO - 2024-06-18 21:24:52 --> Language Class Initialized
INFO - 2024-06-18 21:24:52 --> Language Class Initialized
INFO - 2024-06-18 21:24:52 --> Config Class Initialized
INFO - 2024-06-18 21:24:52 --> Loader Class Initialized
INFO - 2024-06-18 21:24:52 --> Helper loaded: url_helper
INFO - 2024-06-18 21:24:52 --> Helper loaded: file_helper
INFO - 2024-06-18 21:24:52 --> Helper loaded: form_helper
INFO - 2024-06-18 21:24:52 --> Helper loaded: my_helper
INFO - 2024-06-18 21:24:52 --> Database Driver Class Initialized
INFO - 2024-06-18 21:24:52 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-18 21:24:52 --> Controller Class Initialized
DEBUG - 2024-06-18 21:24:52 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/home/views/v_home_guru.php
DEBUG - 2024-06-18 21:24:52 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-06-18 21:24:52 --> Final output sent to browser
DEBUG - 2024-06-18 21:24:52 --> Total execution time: 0.0312
INFO - 2024-06-18 21:24:54 --> Config Class Initialized
INFO - 2024-06-18 21:24:54 --> Hooks Class Initialized
DEBUG - 2024-06-18 21:24:54 --> UTF-8 Support Enabled
INFO - 2024-06-18 21:24:54 --> Utf8 Class Initialized
INFO - 2024-06-18 21:24:54 --> URI Class Initialized
INFO - 2024-06-18 21:24:54 --> Router Class Initialized
INFO - 2024-06-18 21:24:54 --> Output Class Initialized
INFO - 2024-06-18 21:24:54 --> Security Class Initialized
DEBUG - 2024-06-18 21:24:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-18 21:24:54 --> Input Class Initialized
INFO - 2024-06-18 21:24:54 --> Language Class Initialized
INFO - 2024-06-18 21:24:54 --> Language Class Initialized
INFO - 2024-06-18 21:24:54 --> Config Class Initialized
INFO - 2024-06-18 21:24:54 --> Loader Class Initialized
INFO - 2024-06-18 21:24:54 --> Helper loaded: url_helper
INFO - 2024-06-18 21:24:54 --> Helper loaded: file_helper
INFO - 2024-06-18 21:24:54 --> Helper loaded: form_helper
INFO - 2024-06-18 21:24:54 --> Helper loaded: my_helper
INFO - 2024-06-18 21:24:54 --> Database Driver Class Initialized
INFO - 2024-06-18 21:24:54 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-18 21:24:54 --> Controller Class Initialized
DEBUG - 2024-06-18 21:24:54 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/view_mapel/views/v_view_mapel.php
DEBUG - 2024-06-18 21:24:54 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-06-18 21:24:54 --> Final output sent to browser
DEBUG - 2024-06-18 21:24:54 --> Total execution time: 0.0272
INFO - 2024-06-18 21:24:57 --> Config Class Initialized
INFO - 2024-06-18 21:24:57 --> Hooks Class Initialized
DEBUG - 2024-06-18 21:24:57 --> UTF-8 Support Enabled
INFO - 2024-06-18 21:24:57 --> Utf8 Class Initialized
INFO - 2024-06-18 21:24:57 --> URI Class Initialized
INFO - 2024-06-18 21:24:57 --> Router Class Initialized
INFO - 2024-06-18 21:24:57 --> Output Class Initialized
INFO - 2024-06-18 21:24:57 --> Security Class Initialized
DEBUG - 2024-06-18 21:24:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-18 21:24:57 --> Input Class Initialized
INFO - 2024-06-18 21:24:57 --> Language Class Initialized
INFO - 2024-06-18 21:24:57 --> Language Class Initialized
INFO - 2024-06-18 21:24:57 --> Config Class Initialized
INFO - 2024-06-18 21:24:57 --> Loader Class Initialized
INFO - 2024-06-18 21:24:57 --> Helper loaded: url_helper
INFO - 2024-06-18 21:24:57 --> Helper loaded: file_helper
INFO - 2024-06-18 21:24:57 --> Helper loaded: form_helper
INFO - 2024-06-18 21:24:57 --> Helper loaded: my_helper
INFO - 2024-06-18 21:24:57 --> Database Driver Class Initialized
INFO - 2024-06-18 21:24:57 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-18 21:24:57 --> Controller Class Initialized
DEBUG - 2024-06-18 21:24:57 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/views/list.php
DEBUG - 2024-06-18 21:24:57 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-06-18 21:24:57 --> Final output sent to browser
DEBUG - 2024-06-18 21:24:57 --> Total execution time: 0.0290
INFO - 2024-06-18 21:24:57 --> Config Class Initialized
INFO - 2024-06-18 21:24:57 --> Hooks Class Initialized
DEBUG - 2024-06-18 21:24:57 --> UTF-8 Support Enabled
INFO - 2024-06-18 21:24:57 --> Utf8 Class Initialized
INFO - 2024-06-18 21:24:57 --> URI Class Initialized
INFO - 2024-06-18 21:24:57 --> Router Class Initialized
INFO - 2024-06-18 21:24:57 --> Output Class Initialized
INFO - 2024-06-18 21:24:57 --> Security Class Initialized
DEBUG - 2024-06-18 21:24:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-18 21:24:57 --> Input Class Initialized
INFO - 2024-06-18 21:24:57 --> Language Class Initialized
INFO - 2024-06-18 21:24:57 --> Language Class Initialized
INFO - 2024-06-18 21:24:57 --> Config Class Initialized
INFO - 2024-06-18 21:24:57 --> Loader Class Initialized
INFO - 2024-06-18 21:24:57 --> Helper loaded: url_helper
INFO - 2024-06-18 21:24:57 --> Helper loaded: file_helper
INFO - 2024-06-18 21:24:57 --> Helper loaded: form_helper
INFO - 2024-06-18 21:24:57 --> Helper loaded: my_helper
INFO - 2024-06-18 21:24:57 --> Database Driver Class Initialized
INFO - 2024-06-18 21:24:57 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-18 21:24:57 --> Controller Class Initialized
INFO - 2024-06-18 21:25:02 --> Config Class Initialized
INFO - 2024-06-18 21:25:02 --> Hooks Class Initialized
DEBUG - 2024-06-18 21:25:02 --> UTF-8 Support Enabled
INFO - 2024-06-18 21:25:02 --> Utf8 Class Initialized
INFO - 2024-06-18 21:25:02 --> URI Class Initialized
INFO - 2024-06-18 21:25:02 --> Router Class Initialized
INFO - 2024-06-18 21:25:02 --> Output Class Initialized
INFO - 2024-06-18 21:25:02 --> Security Class Initialized
DEBUG - 2024-06-18 21:25:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-18 21:25:02 --> Input Class Initialized
INFO - 2024-06-18 21:25:02 --> Language Class Initialized
INFO - 2024-06-18 21:25:02 --> Language Class Initialized
INFO - 2024-06-18 21:25:02 --> Config Class Initialized
INFO - 2024-06-18 21:25:02 --> Loader Class Initialized
INFO - 2024-06-18 21:25:02 --> Helper loaded: url_helper
INFO - 2024-06-18 21:25:02 --> Helper loaded: file_helper
INFO - 2024-06-18 21:25:02 --> Helper loaded: form_helper
INFO - 2024-06-18 21:25:02 --> Helper loaded: my_helper
INFO - 2024-06-18 21:25:02 --> Database Driver Class Initialized
INFO - 2024-06-18 21:25:02 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-18 21:25:02 --> Controller Class Initialized
INFO - 2024-06-18 21:25:02 --> Final output sent to browser
DEBUG - 2024-06-18 21:25:02 --> Total execution time: 0.0339
INFO - 2024-06-18 21:25:11 --> Config Class Initialized
INFO - 2024-06-18 21:25:11 --> Hooks Class Initialized
DEBUG - 2024-06-18 21:25:11 --> UTF-8 Support Enabled
INFO - 2024-06-18 21:25:11 --> Utf8 Class Initialized
INFO - 2024-06-18 21:25:11 --> URI Class Initialized
INFO - 2024-06-18 21:25:11 --> Router Class Initialized
INFO - 2024-06-18 21:25:11 --> Output Class Initialized
INFO - 2024-06-18 21:25:11 --> Security Class Initialized
DEBUG - 2024-06-18 21:25:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-18 21:25:11 --> Input Class Initialized
INFO - 2024-06-18 21:25:11 --> Language Class Initialized
INFO - 2024-06-18 21:25:11 --> Language Class Initialized
INFO - 2024-06-18 21:25:11 --> Config Class Initialized
INFO - 2024-06-18 21:25:11 --> Loader Class Initialized
INFO - 2024-06-18 21:25:11 --> Helper loaded: url_helper
INFO - 2024-06-18 21:25:11 --> Helper loaded: file_helper
INFO - 2024-06-18 21:25:11 --> Helper loaded: form_helper
INFO - 2024-06-18 21:25:11 --> Helper loaded: my_helper
INFO - 2024-06-18 21:25:11 --> Database Driver Class Initialized
INFO - 2024-06-18 21:25:11 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-18 21:25:11 --> Controller Class Initialized
INFO - 2024-06-18 21:27:50 --> Config Class Initialized
INFO - 2024-06-18 21:27:50 --> Hooks Class Initialized
DEBUG - 2024-06-18 21:27:50 --> UTF-8 Support Enabled
INFO - 2024-06-18 21:27:50 --> Utf8 Class Initialized
INFO - 2024-06-18 21:27:50 --> URI Class Initialized
INFO - 2024-06-18 21:27:50 --> Router Class Initialized
INFO - 2024-06-18 21:27:50 --> Output Class Initialized
INFO - 2024-06-18 21:27:50 --> Security Class Initialized
DEBUG - 2024-06-18 21:27:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-18 21:27:50 --> Input Class Initialized
INFO - 2024-06-18 21:27:50 --> Language Class Initialized
INFO - 2024-06-18 21:27:50 --> Language Class Initialized
INFO - 2024-06-18 21:27:50 --> Config Class Initialized
INFO - 2024-06-18 21:27:50 --> Loader Class Initialized
INFO - 2024-06-18 21:27:50 --> Helper loaded: url_helper
INFO - 2024-06-18 21:27:50 --> Helper loaded: file_helper
INFO - 2024-06-18 21:27:50 --> Helper loaded: form_helper
INFO - 2024-06-18 21:27:50 --> Helper loaded: my_helper
INFO - 2024-06-18 21:27:50 --> Database Driver Class Initialized
INFO - 2024-06-18 21:27:50 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-18 21:27:50 --> Controller Class Initialized
DEBUG - 2024-06-18 21:27:50 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/views/cetak.php
INFO - 2024-06-18 21:27:50 --> Final output sent to browser
DEBUG - 2024-06-18 21:27:50 --> Total execution time: 0.0995
INFO - 2024-06-18 21:28:07 --> Config Class Initialized
INFO - 2024-06-18 21:28:07 --> Hooks Class Initialized
DEBUG - 2024-06-18 21:28:07 --> UTF-8 Support Enabled
INFO - 2024-06-18 21:28:07 --> Utf8 Class Initialized
INFO - 2024-06-18 21:28:07 --> URI Class Initialized
INFO - 2024-06-18 21:28:07 --> Router Class Initialized
INFO - 2024-06-18 21:28:07 --> Output Class Initialized
INFO - 2024-06-18 21:28:07 --> Security Class Initialized
DEBUG - 2024-06-18 21:28:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-18 21:28:07 --> Input Class Initialized
INFO - 2024-06-18 21:28:07 --> Language Class Initialized
INFO - 2024-06-18 21:28:07 --> Language Class Initialized
INFO - 2024-06-18 21:28:07 --> Config Class Initialized
INFO - 2024-06-18 21:28:07 --> Loader Class Initialized
INFO - 2024-06-18 21:28:07 --> Helper loaded: url_helper
INFO - 2024-06-18 21:28:07 --> Helper loaded: file_helper
INFO - 2024-06-18 21:28:07 --> Helper loaded: form_helper
INFO - 2024-06-18 21:28:07 --> Helper loaded: my_helper
INFO - 2024-06-18 21:28:07 --> Database Driver Class Initialized
INFO - 2024-06-18 21:28:07 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-18 21:28:07 --> Controller Class Initialized
DEBUG - 2024-06-18 21:28:07 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/views/form.php
DEBUG - 2024-06-18 21:28:07 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-06-18 21:28:07 --> Final output sent to browser
DEBUG - 2024-06-18 21:28:07 --> Total execution time: 0.0575
INFO - 2024-06-18 21:28:17 --> Config Class Initialized
INFO - 2024-06-18 21:28:17 --> Hooks Class Initialized
DEBUG - 2024-06-18 21:28:17 --> UTF-8 Support Enabled
INFO - 2024-06-18 21:28:17 --> Utf8 Class Initialized
INFO - 2024-06-18 21:28:17 --> URI Class Initialized
INFO - 2024-06-18 21:28:17 --> Router Class Initialized
INFO - 2024-06-18 21:28:17 --> Output Class Initialized
INFO - 2024-06-18 21:28:17 --> Security Class Initialized
DEBUG - 2024-06-18 21:28:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-18 21:28:17 --> Input Class Initialized
INFO - 2024-06-18 21:28:17 --> Language Class Initialized
INFO - 2024-06-18 21:28:17 --> Language Class Initialized
INFO - 2024-06-18 21:28:17 --> Config Class Initialized
INFO - 2024-06-18 21:28:17 --> Loader Class Initialized
INFO - 2024-06-18 21:28:17 --> Helper loaded: url_helper
INFO - 2024-06-18 21:28:17 --> Helper loaded: file_helper
INFO - 2024-06-18 21:28:17 --> Helper loaded: form_helper
INFO - 2024-06-18 21:28:17 --> Helper loaded: my_helper
INFO - 2024-06-18 21:28:17 --> Database Driver Class Initialized
INFO - 2024-06-18 21:28:17 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-18 21:28:17 --> Controller Class Initialized
INFO - 2024-06-18 21:28:18 --> Config Class Initialized
INFO - 2024-06-18 21:28:18 --> Hooks Class Initialized
DEBUG - 2024-06-18 21:28:18 --> UTF-8 Support Enabled
INFO - 2024-06-18 21:28:18 --> Utf8 Class Initialized
INFO - 2024-06-18 21:28:18 --> URI Class Initialized
INFO - 2024-06-18 21:28:18 --> Router Class Initialized
INFO - 2024-06-18 21:28:18 --> Output Class Initialized
INFO - 2024-06-18 21:28:18 --> Security Class Initialized
DEBUG - 2024-06-18 21:28:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-18 21:28:18 --> Input Class Initialized
INFO - 2024-06-18 21:28:18 --> Language Class Initialized
INFO - 2024-06-18 21:28:18 --> Language Class Initialized
INFO - 2024-06-18 21:28:18 --> Config Class Initialized
INFO - 2024-06-18 21:28:18 --> Loader Class Initialized
INFO - 2024-06-18 21:28:18 --> Helper loaded: url_helper
INFO - 2024-06-18 21:28:18 --> Helper loaded: file_helper
INFO - 2024-06-18 21:28:18 --> Helper loaded: form_helper
INFO - 2024-06-18 21:28:18 --> Helper loaded: my_helper
INFO - 2024-06-18 21:28:18 --> Database Driver Class Initialized
INFO - 2024-06-18 21:28:18 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-18 21:28:18 --> Controller Class Initialized
DEBUG - 2024-06-18 21:28:18 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/views/list.php
DEBUG - 2024-06-18 21:28:18 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-06-18 21:28:18 --> Final output sent to browser
DEBUG - 2024-06-18 21:28:18 --> Total execution time: 0.0294
INFO - 2024-06-18 21:28:18 --> Config Class Initialized
INFO - 2024-06-18 21:28:18 --> Hooks Class Initialized
DEBUG - 2024-06-18 21:28:18 --> UTF-8 Support Enabled
INFO - 2024-06-18 21:28:18 --> Utf8 Class Initialized
INFO - 2024-06-18 21:28:18 --> URI Class Initialized
INFO - 2024-06-18 21:28:18 --> Router Class Initialized
INFO - 2024-06-18 21:28:18 --> Output Class Initialized
INFO - 2024-06-18 21:28:18 --> Security Class Initialized
DEBUG - 2024-06-18 21:28:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-18 21:28:18 --> Input Class Initialized
INFO - 2024-06-18 21:28:18 --> Language Class Initialized
INFO - 2024-06-18 21:28:18 --> Language Class Initialized
INFO - 2024-06-18 21:28:18 --> Config Class Initialized
INFO - 2024-06-18 21:28:18 --> Loader Class Initialized
INFO - 2024-06-18 21:28:18 --> Helper loaded: url_helper
INFO - 2024-06-18 21:28:18 --> Helper loaded: file_helper
INFO - 2024-06-18 21:28:18 --> Helper loaded: form_helper
INFO - 2024-06-18 21:28:18 --> Helper loaded: my_helper
INFO - 2024-06-18 21:28:18 --> Database Driver Class Initialized
INFO - 2024-06-18 21:28:18 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-18 21:28:18 --> Controller Class Initialized
INFO - 2024-06-18 21:28:25 --> Config Class Initialized
INFO - 2024-06-18 21:28:25 --> Hooks Class Initialized
DEBUG - 2024-06-18 21:28:25 --> UTF-8 Support Enabled
INFO - 2024-06-18 21:28:25 --> Utf8 Class Initialized
INFO - 2024-06-18 21:28:25 --> URI Class Initialized
INFO - 2024-06-18 21:28:25 --> Router Class Initialized
INFO - 2024-06-18 21:28:25 --> Output Class Initialized
INFO - 2024-06-18 21:28:25 --> Security Class Initialized
DEBUG - 2024-06-18 21:28:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-18 21:28:25 --> Input Class Initialized
INFO - 2024-06-18 21:28:25 --> Language Class Initialized
INFO - 2024-06-18 21:28:25 --> Language Class Initialized
INFO - 2024-06-18 21:28:25 --> Config Class Initialized
INFO - 2024-06-18 21:28:25 --> Loader Class Initialized
INFO - 2024-06-18 21:28:25 --> Helper loaded: url_helper
INFO - 2024-06-18 21:28:25 --> Helper loaded: file_helper
INFO - 2024-06-18 21:28:25 --> Helper loaded: form_helper
INFO - 2024-06-18 21:28:25 --> Helper loaded: my_helper
INFO - 2024-06-18 21:28:25 --> Database Driver Class Initialized
INFO - 2024-06-18 21:28:25 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-18 21:28:25 --> Controller Class Initialized
DEBUG - 2024-06-18 21:28:25 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/views/cetak.php
INFO - 2024-06-18 21:28:25 --> Final output sent to browser
DEBUG - 2024-06-18 21:28:25 --> Total execution time: 0.1193
INFO - 2024-06-18 21:28:55 --> Config Class Initialized
INFO - 2024-06-18 21:28:55 --> Hooks Class Initialized
DEBUG - 2024-06-18 21:28:55 --> UTF-8 Support Enabled
INFO - 2024-06-18 21:28:55 --> Utf8 Class Initialized
INFO - 2024-06-18 21:28:55 --> URI Class Initialized
INFO - 2024-06-18 21:28:55 --> Router Class Initialized
INFO - 2024-06-18 21:28:55 --> Output Class Initialized
INFO - 2024-06-18 21:28:55 --> Security Class Initialized
DEBUG - 2024-06-18 21:28:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-18 21:28:55 --> Input Class Initialized
INFO - 2024-06-18 21:28:55 --> Language Class Initialized
INFO - 2024-06-18 21:28:55 --> Language Class Initialized
INFO - 2024-06-18 21:28:55 --> Config Class Initialized
INFO - 2024-06-18 21:28:55 --> Loader Class Initialized
INFO - 2024-06-18 21:28:55 --> Helper loaded: url_helper
INFO - 2024-06-18 21:28:55 --> Helper loaded: file_helper
INFO - 2024-06-18 21:28:55 --> Helper loaded: form_helper
INFO - 2024-06-18 21:28:55 --> Helper loaded: my_helper
INFO - 2024-06-18 21:28:55 --> Database Driver Class Initialized
INFO - 2024-06-18 21:28:55 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-18 21:28:55 --> Controller Class Initialized
INFO - 2024-06-18 21:28:55 --> Final output sent to browser
DEBUG - 2024-06-18 21:28:55 --> Total execution time: 0.0343
INFO - 2024-06-18 21:29:01 --> Config Class Initialized
INFO - 2024-06-18 21:29:01 --> Hooks Class Initialized
DEBUG - 2024-06-18 21:29:01 --> UTF-8 Support Enabled
INFO - 2024-06-18 21:29:01 --> Utf8 Class Initialized
INFO - 2024-06-18 21:29:01 --> URI Class Initialized
INFO - 2024-06-18 21:29:01 --> Router Class Initialized
INFO - 2024-06-18 21:29:01 --> Output Class Initialized
INFO - 2024-06-18 21:29:01 --> Security Class Initialized
DEBUG - 2024-06-18 21:29:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-18 21:29:01 --> Input Class Initialized
INFO - 2024-06-18 21:29:01 --> Language Class Initialized
INFO - 2024-06-18 21:29:01 --> Language Class Initialized
INFO - 2024-06-18 21:29:01 --> Config Class Initialized
INFO - 2024-06-18 21:29:01 --> Loader Class Initialized
INFO - 2024-06-18 21:29:01 --> Helper loaded: url_helper
INFO - 2024-06-18 21:29:01 --> Helper loaded: file_helper
INFO - 2024-06-18 21:29:01 --> Helper loaded: form_helper
INFO - 2024-06-18 21:29:01 --> Helper loaded: my_helper
INFO - 2024-06-18 21:29:01 --> Database Driver Class Initialized
INFO - 2024-06-18 21:29:01 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-18 21:29:01 --> Controller Class Initialized
DEBUG - 2024-06-18 21:29:01 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/view_mapel/views/v_view_mapel.php
DEBUG - 2024-06-18 21:29:01 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-06-18 21:29:01 --> Final output sent to browser
DEBUG - 2024-06-18 21:29:01 --> Total execution time: 0.0390
INFO - 2024-06-18 21:29:03 --> Config Class Initialized
INFO - 2024-06-18 21:29:03 --> Hooks Class Initialized
DEBUG - 2024-06-18 21:29:03 --> UTF-8 Support Enabled
INFO - 2024-06-18 21:29:03 --> Utf8 Class Initialized
INFO - 2024-06-18 21:29:03 --> URI Class Initialized
INFO - 2024-06-18 21:29:03 --> Router Class Initialized
INFO - 2024-06-18 21:29:03 --> Output Class Initialized
INFO - 2024-06-18 21:29:03 --> Security Class Initialized
DEBUG - 2024-06-18 21:29:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-18 21:29:03 --> Input Class Initialized
INFO - 2024-06-18 21:29:03 --> Language Class Initialized
INFO - 2024-06-18 21:29:03 --> Language Class Initialized
INFO - 2024-06-18 21:29:03 --> Config Class Initialized
INFO - 2024-06-18 21:29:03 --> Loader Class Initialized
INFO - 2024-06-18 21:29:03 --> Helper loaded: url_helper
INFO - 2024-06-18 21:29:03 --> Helper loaded: file_helper
INFO - 2024-06-18 21:29:03 --> Helper loaded: form_helper
INFO - 2024-06-18 21:29:03 --> Helper loaded: my_helper
INFO - 2024-06-18 21:29:03 --> Database Driver Class Initialized
INFO - 2024-06-18 21:29:03 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-18 21:29:03 --> Controller Class Initialized
DEBUG - 2024-06-18 21:29:03 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_catatan_guru/views/list.php
DEBUG - 2024-06-18 21:29:03 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-06-18 21:29:03 --> Final output sent to browser
DEBUG - 2024-06-18 21:29:03 --> Total execution time: 0.0407
INFO - 2024-06-18 21:29:05 --> Config Class Initialized
INFO - 2024-06-18 21:29:05 --> Hooks Class Initialized
DEBUG - 2024-06-18 21:29:05 --> UTF-8 Support Enabled
INFO - 2024-06-18 21:29:05 --> Utf8 Class Initialized
INFO - 2024-06-18 21:29:05 --> URI Class Initialized
INFO - 2024-06-18 21:29:05 --> Router Class Initialized
INFO - 2024-06-18 21:29:05 --> Output Class Initialized
INFO - 2024-06-18 21:29:05 --> Security Class Initialized
DEBUG - 2024-06-18 21:29:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-18 21:29:05 --> Input Class Initialized
INFO - 2024-06-18 21:29:05 --> Language Class Initialized
INFO - 2024-06-18 21:29:05 --> Language Class Initialized
INFO - 2024-06-18 21:29:05 --> Config Class Initialized
INFO - 2024-06-18 21:29:05 --> Loader Class Initialized
INFO - 2024-06-18 21:29:05 --> Helper loaded: url_helper
INFO - 2024-06-18 21:29:05 --> Helper loaded: file_helper
INFO - 2024-06-18 21:29:05 --> Helper loaded: form_helper
INFO - 2024-06-18 21:29:05 --> Helper loaded: my_helper
INFO - 2024-06-18 21:29:05 --> Database Driver Class Initialized
INFO - 2024-06-18 21:29:05 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-18 21:29:05 --> Controller Class Initialized
INFO - 2024-06-18 21:29:05 --> Final output sent to browser
DEBUG - 2024-06-18 21:29:05 --> Total execution time: 0.0286
INFO - 2024-06-18 21:34:29 --> Config Class Initialized
INFO - 2024-06-18 21:34:29 --> Hooks Class Initialized
DEBUG - 2024-06-18 21:34:29 --> UTF-8 Support Enabled
INFO - 2024-06-18 21:34:29 --> Utf8 Class Initialized
INFO - 2024-06-18 21:34:29 --> URI Class Initialized
INFO - 2024-06-18 21:34:29 --> Router Class Initialized
INFO - 2024-06-18 21:34:29 --> Output Class Initialized
INFO - 2024-06-18 21:34:29 --> Security Class Initialized
DEBUG - 2024-06-18 21:34:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-18 21:34:29 --> Input Class Initialized
INFO - 2024-06-18 21:34:29 --> Language Class Initialized
INFO - 2024-06-18 21:34:29 --> Language Class Initialized
INFO - 2024-06-18 21:34:29 --> Config Class Initialized
INFO - 2024-06-18 21:34:29 --> Loader Class Initialized
INFO - 2024-06-18 21:34:29 --> Helper loaded: url_helper
INFO - 2024-06-18 21:34:29 --> Helper loaded: file_helper
INFO - 2024-06-18 21:34:29 --> Helper loaded: form_helper
INFO - 2024-06-18 21:34:29 --> Helper loaded: my_helper
INFO - 2024-06-18 21:34:29 --> Database Driver Class Initialized
INFO - 2024-06-18 21:34:29 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-18 21:34:29 --> Controller Class Initialized
DEBUG - 2024-06-18 21:34:29 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_catatan_kl1/views/list.php
DEBUG - 2024-06-18 21:34:29 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-06-18 21:34:29 --> Final output sent to browser
DEBUG - 2024-06-18 21:34:29 --> Total execution time: 0.0577
INFO - 2024-06-18 21:36:12 --> Config Class Initialized
INFO - 2024-06-18 21:36:12 --> Hooks Class Initialized
DEBUG - 2024-06-18 21:36:12 --> UTF-8 Support Enabled
INFO - 2024-06-18 21:36:12 --> Utf8 Class Initialized
INFO - 2024-06-18 21:36:12 --> URI Class Initialized
INFO - 2024-06-18 21:36:12 --> Router Class Initialized
INFO - 2024-06-18 21:36:12 --> Output Class Initialized
INFO - 2024-06-18 21:36:12 --> Security Class Initialized
DEBUG - 2024-06-18 21:36:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-18 21:36:12 --> Input Class Initialized
INFO - 2024-06-18 21:36:12 --> Language Class Initialized
INFO - 2024-06-18 21:36:12 --> Language Class Initialized
INFO - 2024-06-18 21:36:12 --> Config Class Initialized
INFO - 2024-06-18 21:36:12 --> Loader Class Initialized
INFO - 2024-06-18 21:36:12 --> Helper loaded: url_helper
INFO - 2024-06-18 21:36:12 --> Helper loaded: file_helper
INFO - 2024-06-18 21:36:12 --> Helper loaded: form_helper
INFO - 2024-06-18 21:36:12 --> Helper loaded: my_helper
INFO - 2024-06-18 21:36:12 --> Database Driver Class Initialized
INFO - 2024-06-18 21:36:12 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-18 21:36:12 --> Controller Class Initialized
INFO - 2024-06-18 21:36:12 --> Final output sent to browser
DEBUG - 2024-06-18 21:36:12 --> Total execution time: 0.0360
INFO - 2024-06-18 21:36:25 --> Config Class Initialized
INFO - 2024-06-18 21:36:25 --> Hooks Class Initialized
DEBUG - 2024-06-18 21:36:25 --> UTF-8 Support Enabled
INFO - 2024-06-18 21:36:25 --> Utf8 Class Initialized
INFO - 2024-06-18 21:36:25 --> URI Class Initialized
INFO - 2024-06-18 21:36:25 --> Router Class Initialized
INFO - 2024-06-18 21:36:25 --> Output Class Initialized
INFO - 2024-06-18 21:36:25 --> Security Class Initialized
DEBUG - 2024-06-18 21:36:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-18 21:36:25 --> Input Class Initialized
INFO - 2024-06-18 21:36:25 --> Language Class Initialized
INFO - 2024-06-18 21:36:25 --> Language Class Initialized
INFO - 2024-06-18 21:36:25 --> Config Class Initialized
INFO - 2024-06-18 21:36:25 --> Loader Class Initialized
INFO - 2024-06-18 21:36:25 --> Helper loaded: url_helper
INFO - 2024-06-18 21:36:25 --> Helper loaded: file_helper
INFO - 2024-06-18 21:36:25 --> Helper loaded: form_helper
INFO - 2024-06-18 21:36:25 --> Helper loaded: my_helper
INFO - 2024-06-18 21:36:25 --> Database Driver Class Initialized
INFO - 2024-06-18 21:36:25 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-18 21:36:25 --> Controller Class Initialized
DEBUG - 2024-06-18 21:36:25 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_catatan_guru/views/form.php
DEBUG - 2024-06-18 21:36:25 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-06-18 21:36:25 --> Final output sent to browser
DEBUG - 2024-06-18 21:36:25 --> Total execution time: 0.0307
INFO - 2024-06-18 21:36:34 --> Config Class Initialized
INFO - 2024-06-18 21:36:34 --> Hooks Class Initialized
DEBUG - 2024-06-18 21:36:34 --> UTF-8 Support Enabled
INFO - 2024-06-18 21:36:34 --> Utf8 Class Initialized
INFO - 2024-06-18 21:36:34 --> URI Class Initialized
INFO - 2024-06-18 21:36:34 --> Router Class Initialized
INFO - 2024-06-18 21:36:34 --> Output Class Initialized
INFO - 2024-06-18 21:36:34 --> Security Class Initialized
DEBUG - 2024-06-18 21:36:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-18 21:36:34 --> Input Class Initialized
INFO - 2024-06-18 21:36:34 --> Language Class Initialized
INFO - 2024-06-18 21:36:34 --> Language Class Initialized
INFO - 2024-06-18 21:36:34 --> Config Class Initialized
INFO - 2024-06-18 21:36:34 --> Loader Class Initialized
INFO - 2024-06-18 21:36:34 --> Helper loaded: url_helper
INFO - 2024-06-18 21:36:34 --> Helper loaded: file_helper
INFO - 2024-06-18 21:36:34 --> Helper loaded: form_helper
INFO - 2024-06-18 21:36:34 --> Helper loaded: my_helper
INFO - 2024-06-18 21:36:34 --> Database Driver Class Initialized
INFO - 2024-06-18 21:36:34 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-18 21:36:34 --> Controller Class Initialized
INFO - 2024-06-18 21:36:35 --> Config Class Initialized
INFO - 2024-06-18 21:36:35 --> Hooks Class Initialized
DEBUG - 2024-06-18 21:36:35 --> UTF-8 Support Enabled
INFO - 2024-06-18 21:36:35 --> Utf8 Class Initialized
INFO - 2024-06-18 21:36:35 --> URI Class Initialized
INFO - 2024-06-18 21:36:35 --> Router Class Initialized
INFO - 2024-06-18 21:36:35 --> Output Class Initialized
INFO - 2024-06-18 21:36:35 --> Security Class Initialized
DEBUG - 2024-06-18 21:36:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-18 21:36:35 --> Input Class Initialized
INFO - 2024-06-18 21:36:35 --> Language Class Initialized
INFO - 2024-06-18 21:36:35 --> Language Class Initialized
INFO - 2024-06-18 21:36:35 --> Config Class Initialized
INFO - 2024-06-18 21:36:35 --> Loader Class Initialized
INFO - 2024-06-18 21:36:35 --> Helper loaded: url_helper
INFO - 2024-06-18 21:36:35 --> Helper loaded: file_helper
INFO - 2024-06-18 21:36:35 --> Helper loaded: form_helper
INFO - 2024-06-18 21:36:35 --> Helper loaded: my_helper
INFO - 2024-06-18 21:36:35 --> Database Driver Class Initialized
INFO - 2024-06-18 21:36:35 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-18 21:36:35 --> Controller Class Initialized
DEBUG - 2024-06-18 21:36:35 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_catatan_guru/views/list.php
DEBUG - 2024-06-18 21:36:35 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-06-18 21:36:35 --> Final output sent to browser
DEBUG - 2024-06-18 21:36:35 --> Total execution time: 0.0269
INFO - 2024-06-18 21:36:40 --> Config Class Initialized
INFO - 2024-06-18 21:36:40 --> Hooks Class Initialized
DEBUG - 2024-06-18 21:36:40 --> UTF-8 Support Enabled
INFO - 2024-06-18 21:36:40 --> Utf8 Class Initialized
INFO - 2024-06-18 21:36:40 --> URI Class Initialized
INFO - 2024-06-18 21:36:40 --> Router Class Initialized
INFO - 2024-06-18 21:36:40 --> Output Class Initialized
INFO - 2024-06-18 21:36:40 --> Security Class Initialized
DEBUG - 2024-06-18 21:36:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-18 21:36:40 --> Input Class Initialized
INFO - 2024-06-18 21:36:40 --> Language Class Initialized
INFO - 2024-06-18 21:36:40 --> Language Class Initialized
INFO - 2024-06-18 21:36:40 --> Config Class Initialized
INFO - 2024-06-18 21:36:40 --> Loader Class Initialized
INFO - 2024-06-18 21:36:40 --> Helper loaded: url_helper
INFO - 2024-06-18 21:36:40 --> Helper loaded: file_helper
INFO - 2024-06-18 21:36:40 --> Helper loaded: form_helper
INFO - 2024-06-18 21:36:40 --> Helper loaded: my_helper
INFO - 2024-06-18 21:36:40 --> Database Driver Class Initialized
INFO - 2024-06-18 21:36:40 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-18 21:36:40 --> Controller Class Initialized
INFO - 2024-06-18 21:36:40 --> Final output sent to browser
DEBUG - 2024-06-18 21:36:40 --> Total execution time: 0.0262
INFO - 2024-06-18 21:36:43 --> Config Class Initialized
INFO - 2024-06-18 21:36:43 --> Hooks Class Initialized
DEBUG - 2024-06-18 21:36:43 --> UTF-8 Support Enabled
INFO - 2024-06-18 21:36:43 --> Utf8 Class Initialized
INFO - 2024-06-18 21:36:43 --> URI Class Initialized
INFO - 2024-06-18 21:36:43 --> Router Class Initialized
INFO - 2024-06-18 21:36:43 --> Output Class Initialized
INFO - 2024-06-18 21:36:43 --> Security Class Initialized
DEBUG - 2024-06-18 21:36:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-18 21:36:43 --> Input Class Initialized
INFO - 2024-06-18 21:36:43 --> Language Class Initialized
INFO - 2024-06-18 21:36:43 --> Language Class Initialized
INFO - 2024-06-18 21:36:43 --> Config Class Initialized
INFO - 2024-06-18 21:36:43 --> Loader Class Initialized
INFO - 2024-06-18 21:36:43 --> Helper loaded: url_helper
INFO - 2024-06-18 21:36:43 --> Helper loaded: file_helper
INFO - 2024-06-18 21:36:43 --> Helper loaded: form_helper
INFO - 2024-06-18 21:36:43 --> Helper loaded: my_helper
INFO - 2024-06-18 21:36:43 --> Database Driver Class Initialized
INFO - 2024-06-18 21:36:43 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-18 21:36:43 --> Controller Class Initialized
DEBUG - 2024-06-18 21:36:43 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/view_mapel/views/v_view_mapel.php
DEBUG - 2024-06-18 21:36:43 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-06-18 21:36:43 --> Final output sent to browser
DEBUG - 2024-06-18 21:36:43 --> Total execution time: 0.0370
INFO - 2024-06-18 21:36:46 --> Config Class Initialized
INFO - 2024-06-18 21:36:46 --> Hooks Class Initialized
DEBUG - 2024-06-18 21:36:46 --> UTF-8 Support Enabled
INFO - 2024-06-18 21:36:46 --> Utf8 Class Initialized
INFO - 2024-06-18 21:36:46 --> URI Class Initialized
INFO - 2024-06-18 21:36:46 --> Router Class Initialized
INFO - 2024-06-18 21:36:46 --> Output Class Initialized
INFO - 2024-06-18 21:36:46 --> Security Class Initialized
DEBUG - 2024-06-18 21:36:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-18 21:36:46 --> Input Class Initialized
INFO - 2024-06-18 21:36:46 --> Language Class Initialized
INFO - 2024-06-18 21:36:46 --> Language Class Initialized
INFO - 2024-06-18 21:36:46 --> Config Class Initialized
INFO - 2024-06-18 21:36:46 --> Loader Class Initialized
INFO - 2024-06-18 21:36:46 --> Helper loaded: url_helper
INFO - 2024-06-18 21:36:46 --> Helper loaded: file_helper
INFO - 2024-06-18 21:36:46 --> Helper loaded: form_helper
INFO - 2024-06-18 21:36:46 --> Helper loaded: my_helper
INFO - 2024-06-18 21:36:46 --> Database Driver Class Initialized
INFO - 2024-06-18 21:36:46 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-18 21:36:46 --> Controller Class Initialized
DEBUG - 2024-06-18 21:36:46 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/views/list.php
DEBUG - 2024-06-18 21:36:46 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-06-18 21:36:46 --> Final output sent to browser
DEBUG - 2024-06-18 21:36:46 --> Total execution time: 0.0312
INFO - 2024-06-18 21:36:46 --> Config Class Initialized
INFO - 2024-06-18 21:36:46 --> Hooks Class Initialized
DEBUG - 2024-06-18 21:36:46 --> UTF-8 Support Enabled
INFO - 2024-06-18 21:36:46 --> Utf8 Class Initialized
INFO - 2024-06-18 21:36:46 --> URI Class Initialized
INFO - 2024-06-18 21:36:46 --> Router Class Initialized
INFO - 2024-06-18 21:36:46 --> Output Class Initialized
INFO - 2024-06-18 21:36:46 --> Security Class Initialized
DEBUG - 2024-06-18 21:36:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-18 21:36:46 --> Input Class Initialized
INFO - 2024-06-18 21:36:46 --> Language Class Initialized
INFO - 2024-06-18 21:36:46 --> Language Class Initialized
INFO - 2024-06-18 21:36:46 --> Config Class Initialized
INFO - 2024-06-18 21:36:46 --> Loader Class Initialized
INFO - 2024-06-18 21:36:46 --> Helper loaded: url_helper
INFO - 2024-06-18 21:36:46 --> Helper loaded: file_helper
INFO - 2024-06-18 21:36:46 --> Helper loaded: form_helper
INFO - 2024-06-18 21:36:46 --> Helper loaded: my_helper
INFO - 2024-06-18 21:36:46 --> Database Driver Class Initialized
INFO - 2024-06-18 21:36:46 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-18 21:36:46 --> Controller Class Initialized
INFO - 2024-06-18 21:36:49 --> Config Class Initialized
INFO - 2024-06-18 21:36:49 --> Hooks Class Initialized
DEBUG - 2024-06-18 21:36:49 --> UTF-8 Support Enabled
INFO - 2024-06-18 21:36:49 --> Utf8 Class Initialized
INFO - 2024-06-18 21:36:49 --> URI Class Initialized
INFO - 2024-06-18 21:36:49 --> Router Class Initialized
INFO - 2024-06-18 21:36:49 --> Output Class Initialized
INFO - 2024-06-18 21:36:49 --> Security Class Initialized
DEBUG - 2024-06-18 21:36:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-18 21:36:49 --> Input Class Initialized
INFO - 2024-06-18 21:36:49 --> Language Class Initialized
INFO - 2024-06-18 21:36:49 --> Language Class Initialized
INFO - 2024-06-18 21:36:49 --> Config Class Initialized
INFO - 2024-06-18 21:36:49 --> Loader Class Initialized
INFO - 2024-06-18 21:36:49 --> Helper loaded: url_helper
INFO - 2024-06-18 21:36:49 --> Helper loaded: file_helper
INFO - 2024-06-18 21:36:49 --> Helper loaded: form_helper
INFO - 2024-06-18 21:36:49 --> Helper loaded: my_helper
INFO - 2024-06-18 21:36:49 --> Database Driver Class Initialized
INFO - 2024-06-18 21:36:49 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-18 21:36:49 --> Controller Class Initialized
DEBUG - 2024-06-18 21:36:49 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/views/form.php
DEBUG - 2024-06-18 21:36:49 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-06-18 21:36:49 --> Final output sent to browser
DEBUG - 2024-06-18 21:36:49 --> Total execution time: 0.0316
INFO - 2024-06-18 21:36:55 --> Config Class Initialized
INFO - 2024-06-18 21:36:55 --> Hooks Class Initialized
DEBUG - 2024-06-18 21:36:55 --> UTF-8 Support Enabled
INFO - 2024-06-18 21:36:55 --> Utf8 Class Initialized
INFO - 2024-06-18 21:36:55 --> URI Class Initialized
INFO - 2024-06-18 21:36:55 --> Router Class Initialized
INFO - 2024-06-18 21:36:55 --> Output Class Initialized
INFO - 2024-06-18 21:36:55 --> Security Class Initialized
DEBUG - 2024-06-18 21:36:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-18 21:36:55 --> Input Class Initialized
INFO - 2024-06-18 21:36:55 --> Language Class Initialized
INFO - 2024-06-18 21:36:55 --> Language Class Initialized
INFO - 2024-06-18 21:36:55 --> Config Class Initialized
INFO - 2024-06-18 21:36:55 --> Loader Class Initialized
INFO - 2024-06-18 21:36:55 --> Helper loaded: url_helper
INFO - 2024-06-18 21:36:55 --> Helper loaded: file_helper
INFO - 2024-06-18 21:36:55 --> Helper loaded: form_helper
INFO - 2024-06-18 21:36:55 --> Helper loaded: my_helper
INFO - 2024-06-18 21:36:55 --> Database Driver Class Initialized
INFO - 2024-06-18 21:36:55 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-18 21:36:55 --> Controller Class Initialized
INFO - 2024-06-18 21:36:55 --> Config Class Initialized
INFO - 2024-06-18 21:36:55 --> Hooks Class Initialized
DEBUG - 2024-06-18 21:36:55 --> UTF-8 Support Enabled
INFO - 2024-06-18 21:36:55 --> Utf8 Class Initialized
INFO - 2024-06-18 21:36:55 --> URI Class Initialized
INFO - 2024-06-18 21:36:55 --> Router Class Initialized
INFO - 2024-06-18 21:36:55 --> Output Class Initialized
INFO - 2024-06-18 21:36:55 --> Security Class Initialized
DEBUG - 2024-06-18 21:36:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-18 21:36:55 --> Input Class Initialized
INFO - 2024-06-18 21:36:55 --> Language Class Initialized
INFO - 2024-06-18 21:36:55 --> Language Class Initialized
INFO - 2024-06-18 21:36:55 --> Config Class Initialized
INFO - 2024-06-18 21:36:55 --> Loader Class Initialized
INFO - 2024-06-18 21:36:55 --> Helper loaded: url_helper
INFO - 2024-06-18 21:36:55 --> Helper loaded: file_helper
INFO - 2024-06-18 21:36:55 --> Helper loaded: form_helper
INFO - 2024-06-18 21:36:55 --> Helper loaded: my_helper
INFO - 2024-06-18 21:36:55 --> Database Driver Class Initialized
INFO - 2024-06-18 21:36:55 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-18 21:36:55 --> Controller Class Initialized
DEBUG - 2024-06-18 21:36:55 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/views/list.php
DEBUG - 2024-06-18 21:36:55 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-06-18 21:36:55 --> Final output sent to browser
DEBUG - 2024-06-18 21:36:55 --> Total execution time: 0.0328
INFO - 2024-06-18 21:36:56 --> Config Class Initialized
INFO - 2024-06-18 21:36:56 --> Hooks Class Initialized
DEBUG - 2024-06-18 21:36:56 --> UTF-8 Support Enabled
INFO - 2024-06-18 21:36:56 --> Utf8 Class Initialized
INFO - 2024-06-18 21:36:56 --> URI Class Initialized
INFO - 2024-06-18 21:36:56 --> Router Class Initialized
INFO - 2024-06-18 21:36:56 --> Output Class Initialized
INFO - 2024-06-18 21:36:56 --> Security Class Initialized
DEBUG - 2024-06-18 21:36:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-18 21:36:56 --> Input Class Initialized
INFO - 2024-06-18 21:36:56 --> Language Class Initialized
INFO - 2024-06-18 21:36:56 --> Language Class Initialized
INFO - 2024-06-18 21:36:56 --> Config Class Initialized
INFO - 2024-06-18 21:36:56 --> Loader Class Initialized
INFO - 2024-06-18 21:36:56 --> Helper loaded: url_helper
INFO - 2024-06-18 21:36:56 --> Helper loaded: file_helper
INFO - 2024-06-18 21:36:56 --> Helper loaded: form_helper
INFO - 2024-06-18 21:36:56 --> Helper loaded: my_helper
INFO - 2024-06-18 21:36:56 --> Database Driver Class Initialized
INFO - 2024-06-18 21:36:56 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-18 21:36:56 --> Controller Class Initialized
INFO - 2024-06-18 21:36:59 --> Config Class Initialized
INFO - 2024-06-18 21:36:59 --> Hooks Class Initialized
DEBUG - 2024-06-18 21:36:59 --> UTF-8 Support Enabled
INFO - 2024-06-18 21:36:59 --> Utf8 Class Initialized
INFO - 2024-06-18 21:36:59 --> URI Class Initialized
INFO - 2024-06-18 21:36:59 --> Router Class Initialized
INFO - 2024-06-18 21:36:59 --> Output Class Initialized
INFO - 2024-06-18 21:36:59 --> Security Class Initialized
DEBUG - 2024-06-18 21:36:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-18 21:36:59 --> Input Class Initialized
INFO - 2024-06-18 21:36:59 --> Language Class Initialized
INFO - 2024-06-18 21:36:59 --> Language Class Initialized
INFO - 2024-06-18 21:36:59 --> Config Class Initialized
INFO - 2024-06-18 21:36:59 --> Loader Class Initialized
INFO - 2024-06-18 21:36:59 --> Helper loaded: url_helper
INFO - 2024-06-18 21:36:59 --> Helper loaded: file_helper
INFO - 2024-06-18 21:36:59 --> Helper loaded: form_helper
INFO - 2024-06-18 21:36:59 --> Helper loaded: my_helper
INFO - 2024-06-18 21:36:59 --> Database Driver Class Initialized
INFO - 2024-06-18 21:36:59 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-18 21:36:59 --> Controller Class Initialized
DEBUG - 2024-06-18 21:36:59 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/views/cetak.php
INFO - 2024-06-18 21:36:59 --> Final output sent to browser
DEBUG - 2024-06-18 21:36:59 --> Total execution time: 0.0943
INFO - 2024-06-18 21:38:42 --> Config Class Initialized
INFO - 2024-06-18 21:38:42 --> Hooks Class Initialized
DEBUG - 2024-06-18 21:38:42 --> UTF-8 Support Enabled
INFO - 2024-06-18 21:38:42 --> Utf8 Class Initialized
INFO - 2024-06-18 21:38:42 --> URI Class Initialized
INFO - 2024-06-18 21:38:42 --> Router Class Initialized
INFO - 2024-06-18 21:38:42 --> Output Class Initialized
INFO - 2024-06-18 21:38:42 --> Security Class Initialized
DEBUG - 2024-06-18 21:38:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-18 21:38:42 --> Input Class Initialized
INFO - 2024-06-18 21:38:42 --> Language Class Initialized
INFO - 2024-06-18 21:38:42 --> Language Class Initialized
INFO - 2024-06-18 21:38:42 --> Config Class Initialized
INFO - 2024-06-18 21:38:42 --> Loader Class Initialized
INFO - 2024-06-18 21:38:42 --> Helper loaded: url_helper
INFO - 2024-06-18 21:38:42 --> Helper loaded: file_helper
INFO - 2024-06-18 21:38:42 --> Helper loaded: form_helper
INFO - 2024-06-18 21:38:42 --> Helper loaded: my_helper
INFO - 2024-06-18 21:38:42 --> Database Driver Class Initialized
INFO - 2024-06-18 21:38:42 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-18 21:38:42 --> Controller Class Initialized
INFO - 2024-06-18 21:38:42 --> Final output sent to browser
DEBUG - 2024-06-18 21:38:42 --> Total execution time: 0.1541
INFO - 2024-06-18 21:38:50 --> Config Class Initialized
INFO - 2024-06-18 21:38:50 --> Hooks Class Initialized
DEBUG - 2024-06-18 21:38:50 --> UTF-8 Support Enabled
INFO - 2024-06-18 21:38:50 --> Utf8 Class Initialized
INFO - 2024-06-18 21:38:50 --> URI Class Initialized
INFO - 2024-06-18 21:38:50 --> Router Class Initialized
INFO - 2024-06-18 21:38:50 --> Output Class Initialized
INFO - 2024-06-18 21:38:50 --> Security Class Initialized
DEBUG - 2024-06-18 21:38:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-18 21:38:50 --> Input Class Initialized
INFO - 2024-06-18 21:38:50 --> Language Class Initialized
INFO - 2024-06-18 21:38:50 --> Language Class Initialized
INFO - 2024-06-18 21:38:50 --> Config Class Initialized
INFO - 2024-06-18 21:38:50 --> Loader Class Initialized
INFO - 2024-06-18 21:38:50 --> Helper loaded: url_helper
INFO - 2024-06-18 21:38:50 --> Helper loaded: file_helper
INFO - 2024-06-18 21:38:50 --> Helper loaded: form_helper
INFO - 2024-06-18 21:38:50 --> Helper loaded: my_helper
INFO - 2024-06-18 21:38:50 --> Database Driver Class Initialized
INFO - 2024-06-18 21:38:50 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-18 21:38:50 --> Controller Class Initialized
DEBUG - 2024-06-18 21:38:50 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/view_mapel/views/v_view_mapel.php
DEBUG - 2024-06-18 21:38:50 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-06-18 21:38:50 --> Final output sent to browser
DEBUG - 2024-06-18 21:38:50 --> Total execution time: 0.0519
INFO - 2024-06-18 21:38:54 --> Config Class Initialized
INFO - 2024-06-18 21:38:54 --> Hooks Class Initialized
DEBUG - 2024-06-18 21:38:54 --> UTF-8 Support Enabled
INFO - 2024-06-18 21:38:54 --> Utf8 Class Initialized
INFO - 2024-06-18 21:38:54 --> URI Class Initialized
INFO - 2024-06-18 21:38:54 --> Router Class Initialized
INFO - 2024-06-18 21:38:54 --> Output Class Initialized
INFO - 2024-06-18 21:38:54 --> Security Class Initialized
DEBUG - 2024-06-18 21:38:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-18 21:38:54 --> Input Class Initialized
INFO - 2024-06-18 21:38:54 --> Language Class Initialized
INFO - 2024-06-18 21:38:54 --> Language Class Initialized
INFO - 2024-06-18 21:38:54 --> Config Class Initialized
INFO - 2024-06-18 21:38:54 --> Loader Class Initialized
INFO - 2024-06-18 21:38:54 --> Helper loaded: url_helper
INFO - 2024-06-18 21:38:54 --> Helper loaded: file_helper
INFO - 2024-06-18 21:38:54 --> Helper loaded: form_helper
INFO - 2024-06-18 21:38:54 --> Helper loaded: my_helper
INFO - 2024-06-18 21:38:54 --> Database Driver Class Initialized
INFO - 2024-06-18 21:38:54 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-18 21:38:54 --> Controller Class Initialized
DEBUG - 2024-06-18 21:38:54 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/views/list.php
DEBUG - 2024-06-18 21:38:54 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-06-18 21:38:54 --> Final output sent to browser
DEBUG - 2024-06-18 21:38:54 --> Total execution time: 0.0302
INFO - 2024-06-18 21:38:54 --> Config Class Initialized
INFO - 2024-06-18 21:38:54 --> Hooks Class Initialized
DEBUG - 2024-06-18 21:38:54 --> UTF-8 Support Enabled
INFO - 2024-06-18 21:38:54 --> Utf8 Class Initialized
INFO - 2024-06-18 21:38:54 --> URI Class Initialized
INFO - 2024-06-18 21:38:54 --> Router Class Initialized
INFO - 2024-06-18 21:38:54 --> Output Class Initialized
INFO - 2024-06-18 21:38:54 --> Security Class Initialized
DEBUG - 2024-06-18 21:38:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-18 21:38:54 --> Input Class Initialized
INFO - 2024-06-18 21:38:54 --> Language Class Initialized
INFO - 2024-06-18 21:38:54 --> Language Class Initialized
INFO - 2024-06-18 21:38:54 --> Config Class Initialized
INFO - 2024-06-18 21:38:54 --> Loader Class Initialized
INFO - 2024-06-18 21:38:54 --> Helper loaded: url_helper
INFO - 2024-06-18 21:38:54 --> Helper loaded: file_helper
INFO - 2024-06-18 21:38:54 --> Helper loaded: form_helper
INFO - 2024-06-18 21:38:54 --> Helper loaded: my_helper
INFO - 2024-06-18 21:38:54 --> Database Driver Class Initialized
INFO - 2024-06-18 21:38:54 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-18 21:38:54 --> Controller Class Initialized
INFO - 2024-06-18 21:38:58 --> Config Class Initialized
INFO - 2024-06-18 21:38:58 --> Hooks Class Initialized
DEBUG - 2024-06-18 21:38:58 --> UTF-8 Support Enabled
INFO - 2024-06-18 21:38:58 --> Utf8 Class Initialized
INFO - 2024-06-18 21:38:58 --> URI Class Initialized
INFO - 2024-06-18 21:38:58 --> Router Class Initialized
INFO - 2024-06-18 21:38:58 --> Output Class Initialized
INFO - 2024-06-18 21:38:58 --> Security Class Initialized
DEBUG - 2024-06-18 21:38:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-18 21:38:58 --> Input Class Initialized
INFO - 2024-06-18 21:38:58 --> Language Class Initialized
INFO - 2024-06-18 21:38:58 --> Language Class Initialized
INFO - 2024-06-18 21:38:58 --> Config Class Initialized
INFO - 2024-06-18 21:38:58 --> Loader Class Initialized
INFO - 2024-06-18 21:38:58 --> Helper loaded: url_helper
INFO - 2024-06-18 21:38:58 --> Helper loaded: file_helper
INFO - 2024-06-18 21:38:58 --> Helper loaded: form_helper
INFO - 2024-06-18 21:38:58 --> Helper loaded: my_helper
INFO - 2024-06-18 21:38:58 --> Database Driver Class Initialized
INFO - 2024-06-18 21:38:58 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-18 21:38:58 --> Controller Class Initialized
DEBUG - 2024-06-18 21:38:58 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/view_mapel/views/v_view_mapel.php
DEBUG - 2024-06-18 21:38:58 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-06-18 21:38:58 --> Final output sent to browser
DEBUG - 2024-06-18 21:38:58 --> Total execution time: 0.0353
INFO - 2024-06-18 21:39:00 --> Config Class Initialized
INFO - 2024-06-18 21:39:00 --> Hooks Class Initialized
DEBUG - 2024-06-18 21:39:00 --> UTF-8 Support Enabled
INFO - 2024-06-18 21:39:00 --> Utf8 Class Initialized
INFO - 2024-06-18 21:39:00 --> URI Class Initialized
INFO - 2024-06-18 21:39:00 --> Router Class Initialized
INFO - 2024-06-18 21:39:00 --> Output Class Initialized
INFO - 2024-06-18 21:39:00 --> Security Class Initialized
DEBUG - 2024-06-18 21:39:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-18 21:39:00 --> Input Class Initialized
INFO - 2024-06-18 21:39:00 --> Language Class Initialized
INFO - 2024-06-18 21:39:00 --> Language Class Initialized
INFO - 2024-06-18 21:39:00 --> Config Class Initialized
INFO - 2024-06-18 21:39:00 --> Loader Class Initialized
INFO - 2024-06-18 21:39:00 --> Helper loaded: url_helper
INFO - 2024-06-18 21:39:00 --> Helper loaded: file_helper
INFO - 2024-06-18 21:39:00 --> Helper loaded: form_helper
INFO - 2024-06-18 21:39:00 --> Helper loaded: my_helper
INFO - 2024-06-18 21:39:00 --> Database Driver Class Initialized
INFO - 2024-06-18 21:39:00 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-18 21:39:00 --> Controller Class Initialized
DEBUG - 2024-06-18 21:39:00 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/views/list.php
DEBUG - 2024-06-18 21:39:00 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-06-18 21:39:00 --> Final output sent to browser
DEBUG - 2024-06-18 21:39:00 --> Total execution time: 0.0758
INFO - 2024-06-18 21:39:00 --> Config Class Initialized
INFO - 2024-06-18 21:39:00 --> Hooks Class Initialized
DEBUG - 2024-06-18 21:39:00 --> UTF-8 Support Enabled
INFO - 2024-06-18 21:39:00 --> Utf8 Class Initialized
INFO - 2024-06-18 21:39:00 --> URI Class Initialized
INFO - 2024-06-18 21:39:00 --> Router Class Initialized
INFO - 2024-06-18 21:39:00 --> Output Class Initialized
INFO - 2024-06-18 21:39:00 --> Security Class Initialized
DEBUG - 2024-06-18 21:39:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-18 21:39:00 --> Input Class Initialized
INFO - 2024-06-18 21:39:00 --> Language Class Initialized
INFO - 2024-06-18 21:39:00 --> Language Class Initialized
INFO - 2024-06-18 21:39:00 --> Config Class Initialized
INFO - 2024-06-18 21:39:00 --> Loader Class Initialized
INFO - 2024-06-18 21:39:00 --> Helper loaded: url_helper
INFO - 2024-06-18 21:39:00 --> Helper loaded: file_helper
INFO - 2024-06-18 21:39:00 --> Helper loaded: form_helper
INFO - 2024-06-18 21:39:00 --> Helper loaded: my_helper
INFO - 2024-06-18 21:39:00 --> Database Driver Class Initialized
INFO - 2024-06-18 21:39:00 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-18 21:39:00 --> Controller Class Initialized
INFO - 2024-06-18 21:39:03 --> Config Class Initialized
INFO - 2024-06-18 21:39:03 --> Hooks Class Initialized
DEBUG - 2024-06-18 21:39:03 --> UTF-8 Support Enabled
INFO - 2024-06-18 21:39:03 --> Utf8 Class Initialized
INFO - 2024-06-18 21:39:03 --> URI Class Initialized
INFO - 2024-06-18 21:39:03 --> Router Class Initialized
INFO - 2024-06-18 21:39:03 --> Output Class Initialized
INFO - 2024-06-18 21:39:03 --> Security Class Initialized
DEBUG - 2024-06-18 21:39:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-18 21:39:03 --> Input Class Initialized
INFO - 2024-06-18 21:39:03 --> Language Class Initialized
INFO - 2024-06-18 21:39:03 --> Language Class Initialized
INFO - 2024-06-18 21:39:03 --> Config Class Initialized
INFO - 2024-06-18 21:39:03 --> Loader Class Initialized
INFO - 2024-06-18 21:39:03 --> Helper loaded: url_helper
INFO - 2024-06-18 21:39:03 --> Helper loaded: file_helper
INFO - 2024-06-18 21:39:03 --> Helper loaded: form_helper
INFO - 2024-06-18 21:39:03 --> Helper loaded: my_helper
INFO - 2024-06-18 21:39:03 --> Database Driver Class Initialized
INFO - 2024-06-18 21:39:03 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-18 21:39:03 --> Controller Class Initialized
INFO - 2024-06-18 21:39:03 --> Final output sent to browser
DEBUG - 2024-06-18 21:39:03 --> Total execution time: 0.0317
INFO - 2024-06-18 22:41:46 --> Config Class Initialized
INFO - 2024-06-18 22:41:46 --> Hooks Class Initialized
DEBUG - 2024-06-18 22:41:46 --> UTF-8 Support Enabled
INFO - 2024-06-18 22:41:46 --> Utf8 Class Initialized
INFO - 2024-06-18 22:41:46 --> URI Class Initialized
INFO - 2024-06-18 22:41:46 --> Router Class Initialized
INFO - 2024-06-18 22:41:46 --> Output Class Initialized
INFO - 2024-06-18 22:41:46 --> Security Class Initialized
DEBUG - 2024-06-18 22:41:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-18 22:41:46 --> Input Class Initialized
INFO - 2024-06-18 22:41:46 --> Language Class Initialized
INFO - 2024-06-18 22:41:46 --> Language Class Initialized
INFO - 2024-06-18 22:41:46 --> Config Class Initialized
INFO - 2024-06-18 22:41:46 --> Loader Class Initialized
INFO - 2024-06-18 22:41:46 --> Helper loaded: url_helper
INFO - 2024-06-18 22:41:46 --> Helper loaded: file_helper
INFO - 2024-06-18 22:41:46 --> Helper loaded: form_helper
INFO - 2024-06-18 22:41:46 --> Helper loaded: my_helper
INFO - 2024-06-18 22:41:46 --> Database Driver Class Initialized
INFO - 2024-06-18 22:41:46 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-18 22:41:46 --> Controller Class Initialized
DEBUG - 2024-06-18 22:41:46 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/views/list.php
DEBUG - 2024-06-18 22:41:46 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-06-18 22:41:46 --> Final output sent to browser
DEBUG - 2024-06-18 22:41:46 --> Total execution time: 0.0478
INFO - 2024-06-18 22:41:47 --> Config Class Initialized
INFO - 2024-06-18 22:41:47 --> Hooks Class Initialized
DEBUG - 2024-06-18 22:41:47 --> UTF-8 Support Enabled
INFO - 2024-06-18 22:41:47 --> Utf8 Class Initialized
INFO - 2024-06-18 22:41:47 --> URI Class Initialized
INFO - 2024-06-18 22:41:47 --> Router Class Initialized
INFO - 2024-06-18 22:41:47 --> Output Class Initialized
INFO - 2024-06-18 22:41:47 --> Security Class Initialized
DEBUG - 2024-06-18 22:41:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-18 22:41:47 --> Input Class Initialized
INFO - 2024-06-18 22:41:47 --> Language Class Initialized
INFO - 2024-06-18 22:41:47 --> Language Class Initialized
INFO - 2024-06-18 22:41:47 --> Config Class Initialized
INFO - 2024-06-18 22:41:47 --> Loader Class Initialized
INFO - 2024-06-18 22:41:47 --> Helper loaded: url_helper
INFO - 2024-06-18 22:41:47 --> Helper loaded: file_helper
INFO - 2024-06-18 22:41:47 --> Helper loaded: form_helper
INFO - 2024-06-18 22:41:47 --> Helper loaded: my_helper
INFO - 2024-06-18 22:41:47 --> Database Driver Class Initialized
INFO - 2024-06-18 22:41:47 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-18 22:41:47 --> Controller Class Initialized
INFO - 2024-06-18 22:41:51 --> Config Class Initialized
INFO - 2024-06-18 22:41:51 --> Hooks Class Initialized
DEBUG - 2024-06-18 22:41:51 --> UTF-8 Support Enabled
INFO - 2024-06-18 22:41:51 --> Utf8 Class Initialized
INFO - 2024-06-18 22:41:51 --> URI Class Initialized
INFO - 2024-06-18 22:41:51 --> Router Class Initialized
INFO - 2024-06-18 22:41:51 --> Output Class Initialized
INFO - 2024-06-18 22:41:51 --> Security Class Initialized
DEBUG - 2024-06-18 22:41:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-18 22:41:51 --> Input Class Initialized
INFO - 2024-06-18 22:41:51 --> Language Class Initialized
INFO - 2024-06-18 22:41:51 --> Language Class Initialized
INFO - 2024-06-18 22:41:51 --> Config Class Initialized
INFO - 2024-06-18 22:41:51 --> Loader Class Initialized
INFO - 2024-06-18 22:41:51 --> Helper loaded: url_helper
INFO - 2024-06-18 22:41:51 --> Helper loaded: file_helper
INFO - 2024-06-18 22:41:51 --> Helper loaded: form_helper
INFO - 2024-06-18 22:41:51 --> Helper loaded: my_helper
INFO - 2024-06-18 22:41:51 --> Database Driver Class Initialized
INFO - 2024-06-18 22:41:51 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-18 22:41:51 --> Controller Class Initialized
DEBUG - 2024-06-18 22:41:51 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_catatan_kl1/views/list.php
DEBUG - 2024-06-18 22:41:51 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-06-18 22:41:51 --> Final output sent to browser
DEBUG - 2024-06-18 22:41:51 --> Total execution time: 0.0296
INFO - 2024-06-18 22:41:56 --> Config Class Initialized
INFO - 2024-06-18 22:41:56 --> Hooks Class Initialized
DEBUG - 2024-06-18 22:41:56 --> UTF-8 Support Enabled
INFO - 2024-06-18 22:41:56 --> Utf8 Class Initialized
INFO - 2024-06-18 22:41:56 --> URI Class Initialized
INFO - 2024-06-18 22:41:56 --> Router Class Initialized
INFO - 2024-06-18 22:41:56 --> Output Class Initialized
INFO - 2024-06-18 22:41:56 --> Security Class Initialized
DEBUG - 2024-06-18 22:41:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-18 22:41:56 --> Input Class Initialized
INFO - 2024-06-18 22:41:56 --> Language Class Initialized
INFO - 2024-06-18 22:41:56 --> Language Class Initialized
INFO - 2024-06-18 22:41:56 --> Config Class Initialized
INFO - 2024-06-18 22:41:56 --> Loader Class Initialized
INFO - 2024-06-18 22:41:56 --> Helper loaded: url_helper
INFO - 2024-06-18 22:41:56 --> Helper loaded: file_helper
INFO - 2024-06-18 22:41:56 --> Helper loaded: form_helper
INFO - 2024-06-18 22:41:56 --> Helper loaded: my_helper
INFO - 2024-06-18 22:41:56 --> Database Driver Class Initialized
INFO - 2024-06-18 22:41:56 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-18 22:41:56 --> Controller Class Initialized
DEBUG - 2024-06-18 22:41:56 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_catatan_kl2/views/list.php
DEBUG - 2024-06-18 22:41:56 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-06-18 22:41:56 --> Final output sent to browser
DEBUG - 2024-06-18 22:41:56 --> Total execution time: 0.0299
INFO - 2024-06-18 23:05:26 --> Config Class Initialized
INFO - 2024-06-18 23:05:26 --> Hooks Class Initialized
DEBUG - 2024-06-18 23:05:26 --> UTF-8 Support Enabled
INFO - 2024-06-18 23:05:26 --> Utf8 Class Initialized
INFO - 2024-06-18 23:05:26 --> URI Class Initialized
INFO - 2024-06-18 23:05:26 --> Router Class Initialized
INFO - 2024-06-18 23:05:26 --> Output Class Initialized
INFO - 2024-06-18 23:05:26 --> Security Class Initialized
DEBUG - 2024-06-18 23:05:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-18 23:05:26 --> Input Class Initialized
INFO - 2024-06-18 23:05:26 --> Language Class Initialized
INFO - 2024-06-18 23:05:26 --> Language Class Initialized
INFO - 2024-06-18 23:05:26 --> Config Class Initialized
INFO - 2024-06-18 23:05:26 --> Loader Class Initialized
INFO - 2024-06-18 23:05:26 --> Helper loaded: url_helper
INFO - 2024-06-18 23:05:26 --> Helper loaded: file_helper
INFO - 2024-06-18 23:05:26 --> Helper loaded: form_helper
INFO - 2024-06-18 23:05:26 --> Helper loaded: my_helper
INFO - 2024-06-18 23:05:26 --> Database Driver Class Initialized
INFO - 2024-06-18 23:05:26 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-18 23:05:26 --> Controller Class Initialized
INFO - 2024-06-18 23:05:26 --> Final output sent to browser
DEBUG - 2024-06-18 23:05:26 --> Total execution time: 0.0391
INFO - 2024-06-18 23:09:43 --> Config Class Initialized
INFO - 2024-06-18 23:09:43 --> Hooks Class Initialized
DEBUG - 2024-06-18 23:09:43 --> UTF-8 Support Enabled
INFO - 2024-06-18 23:09:43 --> Utf8 Class Initialized
INFO - 2024-06-18 23:09:43 --> URI Class Initialized
INFO - 2024-06-18 23:09:43 --> Router Class Initialized
INFO - 2024-06-18 23:09:43 --> Output Class Initialized
INFO - 2024-06-18 23:09:43 --> Security Class Initialized
DEBUG - 2024-06-18 23:09:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-18 23:09:43 --> Input Class Initialized
INFO - 2024-06-18 23:09:43 --> Language Class Initialized
INFO - 2024-06-18 23:09:43 --> Language Class Initialized
INFO - 2024-06-18 23:09:43 --> Config Class Initialized
INFO - 2024-06-18 23:09:43 --> Loader Class Initialized
INFO - 2024-06-18 23:09:43 --> Helper loaded: url_helper
INFO - 2024-06-18 23:09:43 --> Helper loaded: file_helper
INFO - 2024-06-18 23:09:43 --> Helper loaded: form_helper
INFO - 2024-06-18 23:09:43 --> Helper loaded: my_helper
INFO - 2024-06-18 23:09:43 --> Database Driver Class Initialized
INFO - 2024-06-18 23:09:43 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-18 23:09:43 --> Controller Class Initialized
DEBUG - 2024-06-18 23:09:43 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/views/list.php
DEBUG - 2024-06-18 23:09:43 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-06-18 23:09:43 --> Final output sent to browser
DEBUG - 2024-06-18 23:09:43 --> Total execution time: 0.0781
INFO - 2024-06-18 23:09:50 --> Config Class Initialized
INFO - 2024-06-18 23:09:50 --> Hooks Class Initialized
DEBUG - 2024-06-18 23:09:50 --> UTF-8 Support Enabled
INFO - 2024-06-18 23:09:50 --> Utf8 Class Initialized
INFO - 2024-06-18 23:09:50 --> URI Class Initialized
INFO - 2024-06-18 23:09:50 --> Router Class Initialized
INFO - 2024-06-18 23:09:50 --> Output Class Initialized
INFO - 2024-06-18 23:09:50 --> Security Class Initialized
DEBUG - 2024-06-18 23:09:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-18 23:09:50 --> Input Class Initialized
INFO - 2024-06-18 23:09:50 --> Language Class Initialized
INFO - 2024-06-18 23:09:50 --> Language Class Initialized
INFO - 2024-06-18 23:09:50 --> Config Class Initialized
INFO - 2024-06-18 23:09:50 --> Loader Class Initialized
INFO - 2024-06-18 23:09:50 --> Helper loaded: url_helper
INFO - 2024-06-18 23:09:50 --> Helper loaded: file_helper
INFO - 2024-06-18 23:09:50 --> Helper loaded: form_helper
INFO - 2024-06-18 23:09:50 --> Helper loaded: my_helper
INFO - 2024-06-18 23:09:50 --> Database Driver Class Initialized
INFO - 2024-06-18 23:09:50 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-18 23:09:50 --> Controller Class Initialized
DEBUG - 2024-06-18 23:09:50 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/view_mapel/views/v_view_mapel.php
DEBUG - 2024-06-18 23:09:50 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-06-18 23:09:50 --> Final output sent to browser
DEBUG - 2024-06-18 23:09:50 --> Total execution time: 0.0366
INFO - 2024-06-18 23:10:00 --> Config Class Initialized
INFO - 2024-06-18 23:10:00 --> Hooks Class Initialized
DEBUG - 2024-06-18 23:10:00 --> UTF-8 Support Enabled
INFO - 2024-06-18 23:10:00 --> Utf8 Class Initialized
INFO - 2024-06-18 23:10:00 --> URI Class Initialized
INFO - 2024-06-18 23:10:00 --> Router Class Initialized
INFO - 2024-06-18 23:10:00 --> Output Class Initialized
INFO - 2024-06-18 23:10:00 --> Security Class Initialized
DEBUG - 2024-06-18 23:10:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-18 23:10:00 --> Input Class Initialized
INFO - 2024-06-18 23:10:00 --> Language Class Initialized
INFO - 2024-06-18 23:10:00 --> Language Class Initialized
INFO - 2024-06-18 23:10:00 --> Config Class Initialized
INFO - 2024-06-18 23:10:00 --> Loader Class Initialized
INFO - 2024-06-18 23:10:00 --> Helper loaded: url_helper
INFO - 2024-06-18 23:10:00 --> Helper loaded: file_helper
INFO - 2024-06-18 23:10:00 --> Helper loaded: form_helper
INFO - 2024-06-18 23:10:00 --> Helper loaded: my_helper
INFO - 2024-06-18 23:10:00 --> Database Driver Class Initialized
INFO - 2024-06-18 23:10:00 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-18 23:10:00 --> Controller Class Initialized
DEBUG - 2024-06-18 23:10:00 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/views/list.php
DEBUG - 2024-06-18 23:10:00 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-06-18 23:10:00 --> Final output sent to browser
DEBUG - 2024-06-18 23:10:00 --> Total execution time: 0.0776
INFO - 2024-06-18 23:10:00 --> Config Class Initialized
INFO - 2024-06-18 23:10:00 --> Hooks Class Initialized
DEBUG - 2024-06-18 23:10:00 --> UTF-8 Support Enabled
INFO - 2024-06-18 23:10:00 --> Utf8 Class Initialized
INFO - 2024-06-18 23:10:00 --> URI Class Initialized
INFO - 2024-06-18 23:10:00 --> Router Class Initialized
INFO - 2024-06-18 23:10:00 --> Output Class Initialized
INFO - 2024-06-18 23:10:00 --> Security Class Initialized
DEBUG - 2024-06-18 23:10:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-18 23:10:00 --> Input Class Initialized
INFO - 2024-06-18 23:10:00 --> Language Class Initialized
INFO - 2024-06-18 23:10:00 --> Language Class Initialized
INFO - 2024-06-18 23:10:00 --> Config Class Initialized
INFO - 2024-06-18 23:10:00 --> Loader Class Initialized
INFO - 2024-06-18 23:10:00 --> Helper loaded: url_helper
INFO - 2024-06-18 23:10:00 --> Helper loaded: file_helper
INFO - 2024-06-18 23:10:00 --> Helper loaded: form_helper
INFO - 2024-06-18 23:10:00 --> Helper loaded: my_helper
INFO - 2024-06-18 23:10:00 --> Database Driver Class Initialized
INFO - 2024-06-18 23:10:00 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-18 23:10:00 --> Controller Class Initialized
DEBUG - 2024-06-18 23:10:00 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/views/list.php
DEBUG - 2024-06-18 23:10:00 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-06-18 23:10:00 --> Final output sent to browser
DEBUG - 2024-06-18 23:10:00 --> Total execution time: 0.0369
INFO - 2024-06-18 23:10:01 --> Config Class Initialized
INFO - 2024-06-18 23:10:01 --> Hooks Class Initialized
DEBUG - 2024-06-18 23:10:01 --> UTF-8 Support Enabled
INFO - 2024-06-18 23:10:01 --> Utf8 Class Initialized
INFO - 2024-06-18 23:10:01 --> URI Class Initialized
INFO - 2024-06-18 23:10:01 --> Router Class Initialized
INFO - 2024-06-18 23:10:01 --> Output Class Initialized
INFO - 2024-06-18 23:10:01 --> Security Class Initialized
DEBUG - 2024-06-18 23:10:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-18 23:10:01 --> Input Class Initialized
INFO - 2024-06-18 23:10:01 --> Language Class Initialized
INFO - 2024-06-18 23:10:01 --> Language Class Initialized
INFO - 2024-06-18 23:10:01 --> Config Class Initialized
INFO - 2024-06-18 23:10:01 --> Loader Class Initialized
INFO - 2024-06-18 23:10:01 --> Helper loaded: url_helper
INFO - 2024-06-18 23:10:01 --> Helper loaded: file_helper
INFO - 2024-06-18 23:10:01 --> Helper loaded: form_helper
INFO - 2024-06-18 23:10:01 --> Helper loaded: my_helper
INFO - 2024-06-18 23:10:01 --> Database Driver Class Initialized
INFO - 2024-06-18 23:10:01 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-18 23:10:01 --> Controller Class Initialized
INFO - 2024-06-18 23:10:05 --> Config Class Initialized
INFO - 2024-06-18 23:10:05 --> Hooks Class Initialized
DEBUG - 2024-06-18 23:10:05 --> UTF-8 Support Enabled
INFO - 2024-06-18 23:10:05 --> Utf8 Class Initialized
INFO - 2024-06-18 23:10:05 --> URI Class Initialized
INFO - 2024-06-18 23:10:05 --> Router Class Initialized
INFO - 2024-06-18 23:10:05 --> Output Class Initialized
INFO - 2024-06-18 23:10:05 --> Security Class Initialized
DEBUG - 2024-06-18 23:10:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-18 23:10:05 --> Input Class Initialized
INFO - 2024-06-18 23:10:05 --> Language Class Initialized
INFO - 2024-06-18 23:10:05 --> Language Class Initialized
INFO - 2024-06-18 23:10:05 --> Config Class Initialized
INFO - 2024-06-18 23:10:05 --> Loader Class Initialized
INFO - 2024-06-18 23:10:05 --> Helper loaded: url_helper
INFO - 2024-06-18 23:10:05 --> Helper loaded: file_helper
INFO - 2024-06-18 23:10:05 --> Helper loaded: form_helper
INFO - 2024-06-18 23:10:05 --> Helper loaded: my_helper
INFO - 2024-06-18 23:10:05 --> Database Driver Class Initialized
INFO - 2024-06-18 23:10:05 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-18 23:10:05 --> Controller Class Initialized
DEBUG - 2024-06-18 23:10:05 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/view_mapel/views/v_view_mapel.php
DEBUG - 2024-06-18 23:10:05 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-06-18 23:10:05 --> Final output sent to browser
DEBUG - 2024-06-18 23:10:05 --> Total execution time: 0.0316
INFO - 2024-06-18 23:10:08 --> Config Class Initialized
INFO - 2024-06-18 23:10:08 --> Hooks Class Initialized
DEBUG - 2024-06-18 23:10:08 --> UTF-8 Support Enabled
INFO - 2024-06-18 23:10:08 --> Utf8 Class Initialized
INFO - 2024-06-18 23:10:08 --> URI Class Initialized
INFO - 2024-06-18 23:10:08 --> Router Class Initialized
INFO - 2024-06-18 23:10:08 --> Output Class Initialized
INFO - 2024-06-18 23:10:08 --> Security Class Initialized
DEBUG - 2024-06-18 23:10:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-18 23:10:08 --> Input Class Initialized
INFO - 2024-06-18 23:10:08 --> Language Class Initialized
INFO - 2024-06-18 23:10:08 --> Language Class Initialized
INFO - 2024-06-18 23:10:08 --> Config Class Initialized
INFO - 2024-06-18 23:10:08 --> Loader Class Initialized
INFO - 2024-06-18 23:10:08 --> Helper loaded: url_helper
INFO - 2024-06-18 23:10:08 --> Helper loaded: file_helper
INFO - 2024-06-18 23:10:08 --> Helper loaded: form_helper
INFO - 2024-06-18 23:10:08 --> Helper loaded: my_helper
INFO - 2024-06-18 23:10:08 --> Database Driver Class Initialized
INFO - 2024-06-18 23:10:08 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-18 23:10:08 --> Controller Class Initialized
DEBUG - 2024-06-18 23:10:08 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_catatan_guru/views/list.php
DEBUG - 2024-06-18 23:10:08 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-06-18 23:10:08 --> Final output sent to browser
DEBUG - 2024-06-18 23:10:08 --> Total execution time: 0.0318
INFO - 2024-06-18 23:10:10 --> Config Class Initialized
INFO - 2024-06-18 23:10:10 --> Hooks Class Initialized
DEBUG - 2024-06-18 23:10:10 --> UTF-8 Support Enabled
INFO - 2024-06-18 23:10:10 --> Utf8 Class Initialized
INFO - 2024-06-18 23:10:10 --> URI Class Initialized
INFO - 2024-06-18 23:10:10 --> Router Class Initialized
INFO - 2024-06-18 23:10:10 --> Output Class Initialized
INFO - 2024-06-18 23:10:10 --> Security Class Initialized
DEBUG - 2024-06-18 23:10:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-18 23:10:10 --> Input Class Initialized
INFO - 2024-06-18 23:10:10 --> Language Class Initialized
INFO - 2024-06-18 23:10:10 --> Language Class Initialized
INFO - 2024-06-18 23:10:10 --> Config Class Initialized
INFO - 2024-06-18 23:10:10 --> Loader Class Initialized
INFO - 2024-06-18 23:10:10 --> Helper loaded: url_helper
INFO - 2024-06-18 23:10:10 --> Helper loaded: file_helper
INFO - 2024-06-18 23:10:10 --> Helper loaded: form_helper
INFO - 2024-06-18 23:10:10 --> Helper loaded: my_helper
INFO - 2024-06-18 23:10:10 --> Database Driver Class Initialized
INFO - 2024-06-18 23:10:10 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-18 23:10:10 --> Controller Class Initialized
INFO - 2024-06-18 23:10:10 --> Final output sent to browser
DEBUG - 2024-06-18 23:10:10 --> Total execution time: 0.0353
INFO - 2024-06-18 23:13:00 --> Config Class Initialized
INFO - 2024-06-18 23:13:00 --> Hooks Class Initialized
DEBUG - 2024-06-18 23:13:00 --> UTF-8 Support Enabled
INFO - 2024-06-18 23:13:00 --> Utf8 Class Initialized
INFO - 2024-06-18 23:13:00 --> URI Class Initialized
INFO - 2024-06-18 23:13:00 --> Router Class Initialized
INFO - 2024-06-18 23:13:00 --> Output Class Initialized
INFO - 2024-06-18 23:13:00 --> Security Class Initialized
DEBUG - 2024-06-18 23:13:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-18 23:13:00 --> Input Class Initialized
INFO - 2024-06-18 23:13:00 --> Language Class Initialized
INFO - 2024-06-18 23:13:00 --> Language Class Initialized
INFO - 2024-06-18 23:13:00 --> Config Class Initialized
INFO - 2024-06-18 23:13:00 --> Loader Class Initialized
INFO - 2024-06-18 23:13:00 --> Helper loaded: url_helper
INFO - 2024-06-18 23:13:00 --> Helper loaded: file_helper
INFO - 2024-06-18 23:13:00 --> Helper loaded: form_helper
INFO - 2024-06-18 23:13:00 --> Helper loaded: my_helper
INFO - 2024-06-18 23:13:00 --> Database Driver Class Initialized
INFO - 2024-06-18 23:13:00 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-18 23:13:00 --> Controller Class Initialized
INFO - 2024-06-18 23:13:01 --> Final output sent to browser
DEBUG - 2024-06-18 23:13:01 --> Total execution time: 0.5288
INFO - 2024-06-18 23:13:04 --> Config Class Initialized
INFO - 2024-06-18 23:13:04 --> Hooks Class Initialized
DEBUG - 2024-06-18 23:13:04 --> UTF-8 Support Enabled
INFO - 2024-06-18 23:13:04 --> Utf8 Class Initialized
INFO - 2024-06-18 23:13:04 --> URI Class Initialized
INFO - 2024-06-18 23:13:04 --> Router Class Initialized
INFO - 2024-06-18 23:13:04 --> Output Class Initialized
INFO - 2024-06-18 23:13:04 --> Security Class Initialized
DEBUG - 2024-06-18 23:13:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-18 23:13:04 --> Input Class Initialized
INFO - 2024-06-18 23:13:04 --> Language Class Initialized
INFO - 2024-06-18 23:13:04 --> Language Class Initialized
INFO - 2024-06-18 23:13:04 --> Config Class Initialized
INFO - 2024-06-18 23:13:04 --> Loader Class Initialized
INFO - 2024-06-18 23:13:04 --> Helper loaded: url_helper
INFO - 2024-06-18 23:13:04 --> Helper loaded: file_helper
INFO - 2024-06-18 23:13:04 --> Helper loaded: form_helper
INFO - 2024-06-18 23:13:04 --> Helper loaded: my_helper
INFO - 2024-06-18 23:13:04 --> Database Driver Class Initialized
INFO - 2024-06-18 23:13:04 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-18 23:13:04 --> Controller Class Initialized
DEBUG - 2024-06-18 23:13:04 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/view_mapel/views/v_view_mapel.php
DEBUG - 2024-06-18 23:13:04 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-06-18 23:13:04 --> Final output sent to browser
DEBUG - 2024-06-18 23:13:04 --> Total execution time: 0.0294
INFO - 2024-06-18 23:13:15 --> Config Class Initialized
INFO - 2024-06-18 23:13:15 --> Hooks Class Initialized
DEBUG - 2024-06-18 23:13:15 --> UTF-8 Support Enabled
INFO - 2024-06-18 23:13:15 --> Utf8 Class Initialized
INFO - 2024-06-18 23:13:15 --> URI Class Initialized
INFO - 2024-06-18 23:13:15 --> Router Class Initialized
INFO - 2024-06-18 23:13:15 --> Output Class Initialized
INFO - 2024-06-18 23:13:15 --> Security Class Initialized
DEBUG - 2024-06-18 23:13:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-18 23:13:15 --> Input Class Initialized
INFO - 2024-06-18 23:13:15 --> Language Class Initialized
INFO - 2024-06-18 23:13:15 --> Language Class Initialized
INFO - 2024-06-18 23:13:15 --> Config Class Initialized
INFO - 2024-06-18 23:13:15 --> Loader Class Initialized
INFO - 2024-06-18 23:13:15 --> Helper loaded: url_helper
INFO - 2024-06-18 23:13:15 --> Helper loaded: file_helper
INFO - 2024-06-18 23:13:15 --> Helper loaded: form_helper
INFO - 2024-06-18 23:13:15 --> Helper loaded: my_helper
INFO - 2024-06-18 23:13:15 --> Database Driver Class Initialized
INFO - 2024-06-18 23:13:15 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-18 23:13:15 --> Controller Class Initialized
DEBUG - 2024-06-18 23:13:15 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/views/list.php
DEBUG - 2024-06-18 23:13:15 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-06-18 23:13:15 --> Final output sent to browser
DEBUG - 2024-06-18 23:13:15 --> Total execution time: 0.0282
INFO - 2024-06-18 23:13:16 --> Config Class Initialized
INFO - 2024-06-18 23:13:16 --> Hooks Class Initialized
DEBUG - 2024-06-18 23:13:16 --> UTF-8 Support Enabled
INFO - 2024-06-18 23:13:16 --> Utf8 Class Initialized
INFO - 2024-06-18 23:13:16 --> URI Class Initialized
INFO - 2024-06-18 23:13:16 --> Router Class Initialized
INFO - 2024-06-18 23:13:16 --> Output Class Initialized
INFO - 2024-06-18 23:13:16 --> Security Class Initialized
DEBUG - 2024-06-18 23:13:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-18 23:13:16 --> Input Class Initialized
INFO - 2024-06-18 23:13:16 --> Language Class Initialized
INFO - 2024-06-18 23:13:16 --> Language Class Initialized
INFO - 2024-06-18 23:13:16 --> Config Class Initialized
INFO - 2024-06-18 23:13:16 --> Loader Class Initialized
INFO - 2024-06-18 23:13:16 --> Helper loaded: url_helper
INFO - 2024-06-18 23:13:16 --> Helper loaded: file_helper
INFO - 2024-06-18 23:13:16 --> Helper loaded: form_helper
INFO - 2024-06-18 23:13:16 --> Helper loaded: my_helper
INFO - 2024-06-18 23:13:16 --> Database Driver Class Initialized
INFO - 2024-06-18 23:13:16 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-18 23:13:16 --> Controller Class Initialized
INFO - 2024-06-18 23:13:25 --> Config Class Initialized
INFO - 2024-06-18 23:13:25 --> Hooks Class Initialized
DEBUG - 2024-06-18 23:13:25 --> UTF-8 Support Enabled
INFO - 2024-06-18 23:13:25 --> Utf8 Class Initialized
INFO - 2024-06-18 23:13:25 --> URI Class Initialized
INFO - 2024-06-18 23:13:25 --> Router Class Initialized
INFO - 2024-06-18 23:13:25 --> Output Class Initialized
INFO - 2024-06-18 23:13:25 --> Security Class Initialized
DEBUG - 2024-06-18 23:13:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-18 23:13:25 --> Input Class Initialized
INFO - 2024-06-18 23:13:25 --> Language Class Initialized
INFO - 2024-06-18 23:13:25 --> Language Class Initialized
INFO - 2024-06-18 23:13:25 --> Config Class Initialized
INFO - 2024-06-18 23:13:25 --> Loader Class Initialized
INFO - 2024-06-18 23:13:25 --> Helper loaded: url_helper
INFO - 2024-06-18 23:13:25 --> Helper loaded: file_helper
INFO - 2024-06-18 23:13:25 --> Helper loaded: form_helper
INFO - 2024-06-18 23:13:25 --> Helper loaded: my_helper
INFO - 2024-06-18 23:13:25 --> Database Driver Class Initialized
INFO - 2024-06-18 23:13:25 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-18 23:13:25 --> Controller Class Initialized
INFO - 2024-06-18 23:13:25 --> Final output sent to browser
DEBUG - 2024-06-18 23:13:25 --> Total execution time: 0.0264
INFO - 2024-06-18 23:13:42 --> Config Class Initialized
INFO - 2024-06-18 23:13:42 --> Hooks Class Initialized
DEBUG - 2024-06-18 23:13:42 --> UTF-8 Support Enabled
INFO - 2024-06-18 23:13:42 --> Utf8 Class Initialized
INFO - 2024-06-18 23:13:42 --> URI Class Initialized
INFO - 2024-06-18 23:13:42 --> Router Class Initialized
INFO - 2024-06-18 23:13:42 --> Output Class Initialized
INFO - 2024-06-18 23:13:42 --> Security Class Initialized
DEBUG - 2024-06-18 23:13:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-18 23:13:42 --> Input Class Initialized
INFO - 2024-06-18 23:13:42 --> Language Class Initialized
INFO - 2024-06-18 23:13:42 --> Language Class Initialized
INFO - 2024-06-18 23:13:42 --> Config Class Initialized
INFO - 2024-06-18 23:13:42 --> Loader Class Initialized
INFO - 2024-06-18 23:13:42 --> Helper loaded: url_helper
INFO - 2024-06-18 23:13:42 --> Helper loaded: file_helper
INFO - 2024-06-18 23:13:42 --> Helper loaded: form_helper
INFO - 2024-06-18 23:13:42 --> Helper loaded: my_helper
INFO - 2024-06-18 23:13:42 --> Database Driver Class Initialized
INFO - 2024-06-18 23:13:42 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-18 23:13:42 --> Controller Class Initialized
INFO - 2024-06-18 23:13:42 --> Final output sent to browser
DEBUG - 2024-06-18 23:13:42 --> Total execution time: 0.0269
INFO - 2024-06-18 23:13:43 --> Config Class Initialized
INFO - 2024-06-18 23:13:43 --> Hooks Class Initialized
DEBUG - 2024-06-18 23:13:43 --> UTF-8 Support Enabled
INFO - 2024-06-18 23:13:43 --> Utf8 Class Initialized
INFO - 2024-06-18 23:13:43 --> URI Class Initialized
INFO - 2024-06-18 23:13:43 --> Router Class Initialized
INFO - 2024-06-18 23:13:43 --> Output Class Initialized
INFO - 2024-06-18 23:13:43 --> Security Class Initialized
DEBUG - 2024-06-18 23:13:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-18 23:13:43 --> Input Class Initialized
INFO - 2024-06-18 23:13:43 --> Language Class Initialized
INFO - 2024-06-18 23:13:43 --> Language Class Initialized
INFO - 2024-06-18 23:13:43 --> Config Class Initialized
INFO - 2024-06-18 23:13:43 --> Loader Class Initialized
INFO - 2024-06-18 23:13:43 --> Helper loaded: url_helper
INFO - 2024-06-18 23:13:43 --> Helper loaded: file_helper
INFO - 2024-06-18 23:13:43 --> Helper loaded: form_helper
INFO - 2024-06-18 23:13:43 --> Helper loaded: my_helper
INFO - 2024-06-18 23:13:43 --> Database Driver Class Initialized
INFO - 2024-06-18 23:13:43 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-18 23:13:43 --> Controller Class Initialized
INFO - 2024-06-18 23:13:43 --> Final output sent to browser
DEBUG - 2024-06-18 23:13:43 --> Total execution time: 0.0294
INFO - 2024-06-18 23:13:44 --> Config Class Initialized
INFO - 2024-06-18 23:13:44 --> Hooks Class Initialized
DEBUG - 2024-06-18 23:13:44 --> UTF-8 Support Enabled
INFO - 2024-06-18 23:13:44 --> Utf8 Class Initialized
INFO - 2024-06-18 23:13:44 --> URI Class Initialized
INFO - 2024-06-18 23:13:44 --> Router Class Initialized
INFO - 2024-06-18 23:13:44 --> Output Class Initialized
INFO - 2024-06-18 23:13:44 --> Security Class Initialized
DEBUG - 2024-06-18 23:13:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-18 23:13:44 --> Input Class Initialized
INFO - 2024-06-18 23:13:44 --> Language Class Initialized
INFO - 2024-06-18 23:13:44 --> Language Class Initialized
INFO - 2024-06-18 23:13:44 --> Config Class Initialized
INFO - 2024-06-18 23:13:44 --> Loader Class Initialized
INFO - 2024-06-18 23:13:44 --> Helper loaded: url_helper
INFO - 2024-06-18 23:13:44 --> Helper loaded: file_helper
INFO - 2024-06-18 23:13:44 --> Helper loaded: form_helper
INFO - 2024-06-18 23:13:44 --> Helper loaded: my_helper
INFO - 2024-06-18 23:13:44 --> Database Driver Class Initialized
INFO - 2024-06-18 23:13:44 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-18 23:13:44 --> Controller Class Initialized
INFO - 2024-06-18 23:13:45 --> Config Class Initialized
INFO - 2024-06-18 23:13:45 --> Hooks Class Initialized
DEBUG - 2024-06-18 23:13:45 --> UTF-8 Support Enabled
INFO - 2024-06-18 23:13:45 --> Utf8 Class Initialized
INFO - 2024-06-18 23:13:45 --> URI Class Initialized
INFO - 2024-06-18 23:13:45 --> Router Class Initialized
INFO - 2024-06-18 23:13:45 --> Output Class Initialized
INFO - 2024-06-18 23:13:45 --> Security Class Initialized
DEBUG - 2024-06-18 23:13:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-18 23:13:45 --> Input Class Initialized
INFO - 2024-06-18 23:13:45 --> Language Class Initialized
INFO - 2024-06-18 23:13:45 --> Language Class Initialized
INFO - 2024-06-18 23:13:45 --> Config Class Initialized
INFO - 2024-06-18 23:13:45 --> Loader Class Initialized
INFO - 2024-06-18 23:13:45 --> Helper loaded: url_helper
INFO - 2024-06-18 23:13:45 --> Helper loaded: file_helper
INFO - 2024-06-18 23:13:45 --> Helper loaded: form_helper
INFO - 2024-06-18 23:13:45 --> Helper loaded: my_helper
INFO - 2024-06-18 23:13:45 --> Database Driver Class Initialized
INFO - 2024-06-18 23:13:45 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-18 23:13:45 --> Controller Class Initialized
INFO - 2024-06-18 23:13:45 --> Final output sent to browser
DEBUG - 2024-06-18 23:13:45 --> Total execution time: 0.0307
INFO - 2024-06-18 23:13:51 --> Config Class Initialized
INFO - 2024-06-18 23:13:51 --> Hooks Class Initialized
DEBUG - 2024-06-18 23:13:51 --> UTF-8 Support Enabled
INFO - 2024-06-18 23:13:51 --> Utf8 Class Initialized
INFO - 2024-06-18 23:13:51 --> URI Class Initialized
INFO - 2024-06-18 23:13:51 --> Router Class Initialized
INFO - 2024-06-18 23:13:51 --> Output Class Initialized
INFO - 2024-06-18 23:13:51 --> Security Class Initialized
DEBUG - 2024-06-18 23:13:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-18 23:13:51 --> Input Class Initialized
INFO - 2024-06-18 23:13:51 --> Language Class Initialized
INFO - 2024-06-18 23:13:51 --> Language Class Initialized
INFO - 2024-06-18 23:13:51 --> Config Class Initialized
INFO - 2024-06-18 23:13:51 --> Loader Class Initialized
INFO - 2024-06-18 23:13:51 --> Helper loaded: url_helper
INFO - 2024-06-18 23:13:51 --> Helper loaded: file_helper
INFO - 2024-06-18 23:13:51 --> Helper loaded: form_helper
INFO - 2024-06-18 23:13:51 --> Helper loaded: my_helper
INFO - 2024-06-18 23:13:51 --> Database Driver Class Initialized
INFO - 2024-06-18 23:13:51 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-18 23:13:51 --> Controller Class Initialized
DEBUG - 2024-06-18 23:13:51 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/views/list.php
DEBUG - 2024-06-18 23:13:51 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-06-18 23:13:51 --> Final output sent to browser
DEBUG - 2024-06-18 23:13:51 --> Total execution time: 0.0282
INFO - 2024-06-18 23:13:53 --> Config Class Initialized
INFO - 2024-06-18 23:13:53 --> Hooks Class Initialized
DEBUG - 2024-06-18 23:13:53 --> UTF-8 Support Enabled
INFO - 2024-06-18 23:13:53 --> Utf8 Class Initialized
INFO - 2024-06-18 23:13:53 --> URI Class Initialized
INFO - 2024-06-18 23:13:53 --> Router Class Initialized
INFO - 2024-06-18 23:13:53 --> Output Class Initialized
INFO - 2024-06-18 23:13:53 --> Security Class Initialized
DEBUG - 2024-06-18 23:13:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-18 23:13:53 --> Input Class Initialized
INFO - 2024-06-18 23:13:53 --> Language Class Initialized
INFO - 2024-06-18 23:13:53 --> Language Class Initialized
INFO - 2024-06-18 23:13:53 --> Config Class Initialized
INFO - 2024-06-18 23:13:53 --> Loader Class Initialized
INFO - 2024-06-18 23:13:53 --> Helper loaded: url_helper
INFO - 2024-06-18 23:13:53 --> Helper loaded: file_helper
INFO - 2024-06-18 23:13:53 --> Helper loaded: form_helper
INFO - 2024-06-18 23:13:53 --> Helper loaded: my_helper
INFO - 2024-06-18 23:13:53 --> Database Driver Class Initialized
INFO - 2024-06-18 23:13:53 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-18 23:13:53 --> Controller Class Initialized
INFO - 2024-06-18 23:13:57 --> Config Class Initialized
INFO - 2024-06-18 23:13:57 --> Hooks Class Initialized
DEBUG - 2024-06-18 23:13:57 --> UTF-8 Support Enabled
INFO - 2024-06-18 23:13:57 --> Utf8 Class Initialized
INFO - 2024-06-18 23:13:57 --> URI Class Initialized
INFO - 2024-06-18 23:13:57 --> Router Class Initialized
INFO - 2024-06-18 23:13:57 --> Output Class Initialized
INFO - 2024-06-18 23:13:57 --> Security Class Initialized
DEBUG - 2024-06-18 23:13:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-18 23:13:57 --> Input Class Initialized
INFO - 2024-06-18 23:13:57 --> Language Class Initialized
INFO - 2024-06-18 23:13:57 --> Language Class Initialized
INFO - 2024-06-18 23:13:57 --> Config Class Initialized
INFO - 2024-06-18 23:13:57 --> Loader Class Initialized
INFO - 2024-06-18 23:13:57 --> Helper loaded: url_helper
INFO - 2024-06-18 23:13:57 --> Helper loaded: file_helper
INFO - 2024-06-18 23:13:57 --> Helper loaded: form_helper
INFO - 2024-06-18 23:13:57 --> Helper loaded: my_helper
INFO - 2024-06-18 23:13:57 --> Database Driver Class Initialized
INFO - 2024-06-18 23:13:57 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-18 23:13:57 --> Controller Class Initialized
INFO - 2024-06-18 23:13:57 --> Final output sent to browser
DEBUG - 2024-06-18 23:13:57 --> Total execution time: 0.0253
INFO - 2024-06-18 23:14:19 --> Config Class Initialized
INFO - 2024-06-18 23:14:19 --> Hooks Class Initialized
DEBUG - 2024-06-18 23:14:19 --> UTF-8 Support Enabled
INFO - 2024-06-18 23:14:19 --> Utf8 Class Initialized
INFO - 2024-06-18 23:14:19 --> URI Class Initialized
INFO - 2024-06-18 23:14:19 --> Router Class Initialized
INFO - 2024-06-18 23:14:19 --> Output Class Initialized
INFO - 2024-06-18 23:14:19 --> Security Class Initialized
DEBUG - 2024-06-18 23:14:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-18 23:14:19 --> Input Class Initialized
INFO - 2024-06-18 23:14:19 --> Language Class Initialized
INFO - 2024-06-18 23:14:19 --> Language Class Initialized
INFO - 2024-06-18 23:14:19 --> Config Class Initialized
INFO - 2024-06-18 23:14:19 --> Loader Class Initialized
INFO - 2024-06-18 23:14:19 --> Helper loaded: url_helper
INFO - 2024-06-18 23:14:19 --> Helper loaded: file_helper
INFO - 2024-06-18 23:14:19 --> Helper loaded: form_helper
INFO - 2024-06-18 23:14:19 --> Helper loaded: my_helper
INFO - 2024-06-18 23:14:19 --> Database Driver Class Initialized
INFO - 2024-06-18 23:14:19 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-18 23:14:19 --> Controller Class Initialized
INFO - 2024-06-18 23:14:19 --> Final output sent to browser
DEBUG - 2024-06-18 23:14:19 --> Total execution time: 0.0311
INFO - 2024-06-18 23:14:19 --> Config Class Initialized
INFO - 2024-06-18 23:14:19 --> Hooks Class Initialized
DEBUG - 2024-06-18 23:14:19 --> UTF-8 Support Enabled
INFO - 2024-06-18 23:14:19 --> Utf8 Class Initialized
INFO - 2024-06-18 23:14:19 --> URI Class Initialized
INFO - 2024-06-18 23:14:19 --> Router Class Initialized
INFO - 2024-06-18 23:14:19 --> Output Class Initialized
INFO - 2024-06-18 23:14:19 --> Security Class Initialized
DEBUG - 2024-06-18 23:14:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-18 23:14:19 --> Input Class Initialized
INFO - 2024-06-18 23:14:19 --> Language Class Initialized
INFO - 2024-06-18 23:14:19 --> Language Class Initialized
INFO - 2024-06-18 23:14:19 --> Config Class Initialized
INFO - 2024-06-18 23:14:19 --> Loader Class Initialized
INFO - 2024-06-18 23:14:19 --> Helper loaded: url_helper
INFO - 2024-06-18 23:14:19 --> Helper loaded: file_helper
INFO - 2024-06-18 23:14:19 --> Helper loaded: form_helper
INFO - 2024-06-18 23:14:19 --> Helper loaded: my_helper
INFO - 2024-06-18 23:14:19 --> Database Driver Class Initialized
INFO - 2024-06-18 23:14:19 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-18 23:14:19 --> Controller Class Initialized
INFO - 2024-06-18 23:14:21 --> Config Class Initialized
INFO - 2024-06-18 23:14:21 --> Hooks Class Initialized
DEBUG - 2024-06-18 23:14:21 --> UTF-8 Support Enabled
INFO - 2024-06-18 23:14:21 --> Utf8 Class Initialized
INFO - 2024-06-18 23:14:21 --> URI Class Initialized
INFO - 2024-06-18 23:14:21 --> Router Class Initialized
INFO - 2024-06-18 23:14:21 --> Output Class Initialized
INFO - 2024-06-18 23:14:21 --> Security Class Initialized
DEBUG - 2024-06-18 23:14:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-18 23:14:21 --> Input Class Initialized
INFO - 2024-06-18 23:14:21 --> Language Class Initialized
INFO - 2024-06-18 23:14:21 --> Language Class Initialized
INFO - 2024-06-18 23:14:21 --> Config Class Initialized
INFO - 2024-06-18 23:14:21 --> Loader Class Initialized
INFO - 2024-06-18 23:14:21 --> Helper loaded: url_helper
INFO - 2024-06-18 23:14:21 --> Helper loaded: file_helper
INFO - 2024-06-18 23:14:21 --> Helper loaded: form_helper
INFO - 2024-06-18 23:14:21 --> Helper loaded: my_helper
INFO - 2024-06-18 23:14:21 --> Database Driver Class Initialized
INFO - 2024-06-18 23:14:21 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-18 23:14:21 --> Controller Class Initialized
INFO - 2024-06-18 23:14:21 --> Final output sent to browser
DEBUG - 2024-06-18 23:14:21 --> Total execution time: 0.0261
INFO - 2024-06-18 23:14:48 --> Config Class Initialized
INFO - 2024-06-18 23:14:48 --> Hooks Class Initialized
DEBUG - 2024-06-18 23:14:48 --> UTF-8 Support Enabled
INFO - 2024-06-18 23:14:48 --> Utf8 Class Initialized
INFO - 2024-06-18 23:14:48 --> URI Class Initialized
INFO - 2024-06-18 23:14:48 --> Router Class Initialized
INFO - 2024-06-18 23:14:48 --> Output Class Initialized
INFO - 2024-06-18 23:14:48 --> Security Class Initialized
DEBUG - 2024-06-18 23:14:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-18 23:14:48 --> Input Class Initialized
INFO - 2024-06-18 23:14:48 --> Language Class Initialized
INFO - 2024-06-18 23:14:48 --> Language Class Initialized
INFO - 2024-06-18 23:14:48 --> Config Class Initialized
INFO - 2024-06-18 23:14:48 --> Loader Class Initialized
INFO - 2024-06-18 23:14:48 --> Helper loaded: url_helper
INFO - 2024-06-18 23:14:48 --> Helper loaded: file_helper
INFO - 2024-06-18 23:14:48 --> Helper loaded: form_helper
INFO - 2024-06-18 23:14:48 --> Helper loaded: my_helper
INFO - 2024-06-18 23:14:48 --> Database Driver Class Initialized
INFO - 2024-06-18 23:14:48 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-18 23:14:48 --> Controller Class Initialized
INFO - 2024-06-18 23:14:48 --> Final output sent to browser
DEBUG - 2024-06-18 23:14:48 --> Total execution time: 0.0283
INFO - 2024-06-18 23:14:48 --> Config Class Initialized
INFO - 2024-06-18 23:14:48 --> Hooks Class Initialized
DEBUG - 2024-06-18 23:14:48 --> UTF-8 Support Enabled
INFO - 2024-06-18 23:14:48 --> Utf8 Class Initialized
INFO - 2024-06-18 23:14:48 --> URI Class Initialized
INFO - 2024-06-18 23:14:48 --> Router Class Initialized
INFO - 2024-06-18 23:14:48 --> Output Class Initialized
INFO - 2024-06-18 23:14:48 --> Security Class Initialized
DEBUG - 2024-06-18 23:14:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-18 23:14:48 --> Input Class Initialized
INFO - 2024-06-18 23:14:48 --> Language Class Initialized
INFO - 2024-06-18 23:14:48 --> Language Class Initialized
INFO - 2024-06-18 23:14:48 --> Config Class Initialized
INFO - 2024-06-18 23:14:48 --> Loader Class Initialized
INFO - 2024-06-18 23:14:48 --> Helper loaded: url_helper
INFO - 2024-06-18 23:14:48 --> Helper loaded: file_helper
INFO - 2024-06-18 23:14:48 --> Helper loaded: form_helper
INFO - 2024-06-18 23:14:48 --> Helper loaded: my_helper
INFO - 2024-06-18 23:14:48 --> Database Driver Class Initialized
INFO - 2024-06-18 23:14:48 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-18 23:14:48 --> Controller Class Initialized
INFO - 2024-06-18 23:14:49 --> Config Class Initialized
INFO - 2024-06-18 23:14:49 --> Hooks Class Initialized
DEBUG - 2024-06-18 23:14:49 --> UTF-8 Support Enabled
INFO - 2024-06-18 23:14:49 --> Utf8 Class Initialized
INFO - 2024-06-18 23:14:49 --> URI Class Initialized
INFO - 2024-06-18 23:14:49 --> Router Class Initialized
INFO - 2024-06-18 23:14:49 --> Output Class Initialized
INFO - 2024-06-18 23:14:49 --> Security Class Initialized
DEBUG - 2024-06-18 23:14:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-18 23:14:49 --> Input Class Initialized
INFO - 2024-06-18 23:14:49 --> Language Class Initialized
INFO - 2024-06-18 23:14:49 --> Language Class Initialized
INFO - 2024-06-18 23:14:49 --> Config Class Initialized
INFO - 2024-06-18 23:14:49 --> Loader Class Initialized
INFO - 2024-06-18 23:14:49 --> Helper loaded: url_helper
INFO - 2024-06-18 23:14:49 --> Helper loaded: file_helper
INFO - 2024-06-18 23:14:49 --> Helper loaded: form_helper
INFO - 2024-06-18 23:14:49 --> Helper loaded: my_helper
INFO - 2024-06-18 23:14:49 --> Database Driver Class Initialized
INFO - 2024-06-18 23:14:49 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-18 23:14:49 --> Controller Class Initialized
INFO - 2024-06-18 23:14:49 --> Final output sent to browser
DEBUG - 2024-06-18 23:14:49 --> Total execution time: 0.0513
INFO - 2024-06-18 23:15:01 --> Config Class Initialized
INFO - 2024-06-18 23:15:01 --> Hooks Class Initialized
DEBUG - 2024-06-18 23:15:01 --> UTF-8 Support Enabled
INFO - 2024-06-18 23:15:01 --> Utf8 Class Initialized
INFO - 2024-06-18 23:15:01 --> URI Class Initialized
INFO - 2024-06-18 23:15:01 --> Router Class Initialized
INFO - 2024-06-18 23:15:01 --> Output Class Initialized
INFO - 2024-06-18 23:15:01 --> Security Class Initialized
DEBUG - 2024-06-18 23:15:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-18 23:15:01 --> Input Class Initialized
INFO - 2024-06-18 23:15:01 --> Language Class Initialized
INFO - 2024-06-18 23:15:01 --> Language Class Initialized
INFO - 2024-06-18 23:15:01 --> Config Class Initialized
INFO - 2024-06-18 23:15:01 --> Loader Class Initialized
INFO - 2024-06-18 23:15:01 --> Helper loaded: url_helper
INFO - 2024-06-18 23:15:01 --> Helper loaded: file_helper
INFO - 2024-06-18 23:15:01 --> Helper loaded: form_helper
INFO - 2024-06-18 23:15:01 --> Helper loaded: my_helper
INFO - 2024-06-18 23:15:01 --> Database Driver Class Initialized
INFO - 2024-06-18 23:15:01 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-18 23:15:01 --> Controller Class Initialized
INFO - 2024-06-18 23:15:01 --> Final output sent to browser
DEBUG - 2024-06-18 23:15:01 --> Total execution time: 0.0416
INFO - 2024-06-18 23:15:02 --> Config Class Initialized
INFO - 2024-06-18 23:15:02 --> Hooks Class Initialized
DEBUG - 2024-06-18 23:15:02 --> UTF-8 Support Enabled
INFO - 2024-06-18 23:15:02 --> Utf8 Class Initialized
INFO - 2024-06-18 23:15:02 --> URI Class Initialized
INFO - 2024-06-18 23:15:02 --> Router Class Initialized
INFO - 2024-06-18 23:15:02 --> Output Class Initialized
INFO - 2024-06-18 23:15:02 --> Security Class Initialized
DEBUG - 2024-06-18 23:15:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-18 23:15:02 --> Input Class Initialized
INFO - 2024-06-18 23:15:02 --> Language Class Initialized
INFO - 2024-06-18 23:15:02 --> Language Class Initialized
INFO - 2024-06-18 23:15:02 --> Config Class Initialized
INFO - 2024-06-18 23:15:02 --> Loader Class Initialized
INFO - 2024-06-18 23:15:02 --> Helper loaded: url_helper
INFO - 2024-06-18 23:15:02 --> Helper loaded: file_helper
INFO - 2024-06-18 23:15:02 --> Helper loaded: form_helper
INFO - 2024-06-18 23:15:02 --> Helper loaded: my_helper
INFO - 2024-06-18 23:15:02 --> Database Driver Class Initialized
INFO - 2024-06-18 23:15:02 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-18 23:15:02 --> Controller Class Initialized
INFO - 2024-06-18 23:15:05 --> Config Class Initialized
INFO - 2024-06-18 23:15:05 --> Hooks Class Initialized
DEBUG - 2024-06-18 23:15:05 --> UTF-8 Support Enabled
INFO - 2024-06-18 23:15:05 --> Utf8 Class Initialized
INFO - 2024-06-18 23:15:05 --> URI Class Initialized
INFO - 2024-06-18 23:15:05 --> Router Class Initialized
INFO - 2024-06-18 23:15:05 --> Output Class Initialized
INFO - 2024-06-18 23:15:05 --> Security Class Initialized
DEBUG - 2024-06-18 23:15:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-18 23:15:05 --> Input Class Initialized
INFO - 2024-06-18 23:15:05 --> Language Class Initialized
INFO - 2024-06-18 23:15:05 --> Language Class Initialized
INFO - 2024-06-18 23:15:05 --> Config Class Initialized
INFO - 2024-06-18 23:15:05 --> Loader Class Initialized
INFO - 2024-06-18 23:15:05 --> Helper loaded: url_helper
INFO - 2024-06-18 23:15:05 --> Helper loaded: file_helper
INFO - 2024-06-18 23:15:05 --> Helper loaded: form_helper
INFO - 2024-06-18 23:15:05 --> Helper loaded: my_helper
INFO - 2024-06-18 23:15:05 --> Database Driver Class Initialized
INFO - 2024-06-18 23:15:05 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-18 23:15:05 --> Controller Class Initialized
INFO - 2024-06-18 23:15:05 --> Final output sent to browser
DEBUG - 2024-06-18 23:15:05 --> Total execution time: 0.0296
INFO - 2024-06-18 23:15:22 --> Config Class Initialized
INFO - 2024-06-18 23:15:22 --> Hooks Class Initialized
DEBUG - 2024-06-18 23:15:22 --> UTF-8 Support Enabled
INFO - 2024-06-18 23:15:22 --> Utf8 Class Initialized
INFO - 2024-06-18 23:15:22 --> URI Class Initialized
INFO - 2024-06-18 23:15:22 --> Router Class Initialized
INFO - 2024-06-18 23:15:22 --> Output Class Initialized
INFO - 2024-06-18 23:15:22 --> Security Class Initialized
DEBUG - 2024-06-18 23:15:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-18 23:15:22 --> Input Class Initialized
INFO - 2024-06-18 23:15:22 --> Language Class Initialized
INFO - 2024-06-18 23:15:22 --> Language Class Initialized
INFO - 2024-06-18 23:15:22 --> Config Class Initialized
INFO - 2024-06-18 23:15:22 --> Loader Class Initialized
INFO - 2024-06-18 23:15:22 --> Helper loaded: url_helper
INFO - 2024-06-18 23:15:22 --> Helper loaded: file_helper
INFO - 2024-06-18 23:15:22 --> Helper loaded: form_helper
INFO - 2024-06-18 23:15:22 --> Helper loaded: my_helper
INFO - 2024-06-18 23:15:22 --> Database Driver Class Initialized
INFO - 2024-06-18 23:15:22 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-18 23:15:22 --> Controller Class Initialized
INFO - 2024-06-18 23:15:22 --> Final output sent to browser
DEBUG - 2024-06-18 23:15:22 --> Total execution time: 0.0267
INFO - 2024-06-18 23:15:23 --> Config Class Initialized
INFO - 2024-06-18 23:15:23 --> Hooks Class Initialized
DEBUG - 2024-06-18 23:15:23 --> UTF-8 Support Enabled
INFO - 2024-06-18 23:15:23 --> Utf8 Class Initialized
INFO - 2024-06-18 23:15:23 --> URI Class Initialized
INFO - 2024-06-18 23:15:23 --> Router Class Initialized
INFO - 2024-06-18 23:15:23 --> Output Class Initialized
INFO - 2024-06-18 23:15:23 --> Security Class Initialized
DEBUG - 2024-06-18 23:15:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-18 23:15:23 --> Input Class Initialized
INFO - 2024-06-18 23:15:23 --> Language Class Initialized
INFO - 2024-06-18 23:15:23 --> Language Class Initialized
INFO - 2024-06-18 23:15:23 --> Config Class Initialized
INFO - 2024-06-18 23:15:23 --> Loader Class Initialized
INFO - 2024-06-18 23:15:23 --> Helper loaded: url_helper
INFO - 2024-06-18 23:15:23 --> Helper loaded: file_helper
INFO - 2024-06-18 23:15:23 --> Helper loaded: form_helper
INFO - 2024-06-18 23:15:23 --> Helper loaded: my_helper
INFO - 2024-06-18 23:15:23 --> Database Driver Class Initialized
INFO - 2024-06-18 23:15:23 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-18 23:15:23 --> Controller Class Initialized
INFO - 2024-06-18 23:15:25 --> Config Class Initialized
INFO - 2024-06-18 23:15:25 --> Hooks Class Initialized
DEBUG - 2024-06-18 23:15:25 --> UTF-8 Support Enabled
INFO - 2024-06-18 23:15:25 --> Utf8 Class Initialized
INFO - 2024-06-18 23:15:25 --> URI Class Initialized
INFO - 2024-06-18 23:15:25 --> Router Class Initialized
INFO - 2024-06-18 23:15:25 --> Output Class Initialized
INFO - 2024-06-18 23:15:25 --> Security Class Initialized
DEBUG - 2024-06-18 23:15:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-18 23:15:25 --> Input Class Initialized
INFO - 2024-06-18 23:15:25 --> Language Class Initialized
INFO - 2024-06-18 23:15:25 --> Language Class Initialized
INFO - 2024-06-18 23:15:25 --> Config Class Initialized
INFO - 2024-06-18 23:15:25 --> Loader Class Initialized
INFO - 2024-06-18 23:15:25 --> Helper loaded: url_helper
INFO - 2024-06-18 23:15:25 --> Helper loaded: file_helper
INFO - 2024-06-18 23:15:25 --> Helper loaded: form_helper
INFO - 2024-06-18 23:15:25 --> Helper loaded: my_helper
INFO - 2024-06-18 23:15:25 --> Database Driver Class Initialized
INFO - 2024-06-18 23:15:25 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-18 23:15:25 --> Controller Class Initialized
INFO - 2024-06-18 23:15:25 --> Final output sent to browser
DEBUG - 2024-06-18 23:15:25 --> Total execution time: 0.0294
INFO - 2024-06-18 23:15:35 --> Config Class Initialized
INFO - 2024-06-18 23:15:35 --> Hooks Class Initialized
DEBUG - 2024-06-18 23:15:35 --> UTF-8 Support Enabled
INFO - 2024-06-18 23:15:35 --> Utf8 Class Initialized
INFO - 2024-06-18 23:15:35 --> URI Class Initialized
INFO - 2024-06-18 23:15:35 --> Router Class Initialized
INFO - 2024-06-18 23:15:35 --> Output Class Initialized
INFO - 2024-06-18 23:15:35 --> Security Class Initialized
DEBUG - 2024-06-18 23:15:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-18 23:15:35 --> Input Class Initialized
INFO - 2024-06-18 23:15:35 --> Language Class Initialized
INFO - 2024-06-18 23:15:35 --> Language Class Initialized
INFO - 2024-06-18 23:15:35 --> Config Class Initialized
INFO - 2024-06-18 23:15:35 --> Loader Class Initialized
INFO - 2024-06-18 23:15:35 --> Helper loaded: url_helper
INFO - 2024-06-18 23:15:35 --> Helper loaded: file_helper
INFO - 2024-06-18 23:15:35 --> Helper loaded: form_helper
INFO - 2024-06-18 23:15:35 --> Helper loaded: my_helper
INFO - 2024-06-18 23:15:35 --> Database Driver Class Initialized
INFO - 2024-06-18 23:15:35 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-18 23:15:35 --> Controller Class Initialized
INFO - 2024-06-18 23:15:35 --> Final output sent to browser
DEBUG - 2024-06-18 23:15:35 --> Total execution time: 0.0577
INFO - 2024-06-18 23:15:36 --> Config Class Initialized
INFO - 2024-06-18 23:15:36 --> Hooks Class Initialized
DEBUG - 2024-06-18 23:15:36 --> UTF-8 Support Enabled
INFO - 2024-06-18 23:15:36 --> Utf8 Class Initialized
INFO - 2024-06-18 23:15:36 --> URI Class Initialized
INFO - 2024-06-18 23:15:36 --> Router Class Initialized
INFO - 2024-06-18 23:15:36 --> Output Class Initialized
INFO - 2024-06-18 23:15:36 --> Security Class Initialized
DEBUG - 2024-06-18 23:15:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-18 23:15:36 --> Input Class Initialized
INFO - 2024-06-18 23:15:36 --> Language Class Initialized
INFO - 2024-06-18 23:15:36 --> Language Class Initialized
INFO - 2024-06-18 23:15:36 --> Config Class Initialized
INFO - 2024-06-18 23:15:36 --> Loader Class Initialized
INFO - 2024-06-18 23:15:36 --> Helper loaded: url_helper
INFO - 2024-06-18 23:15:36 --> Helper loaded: file_helper
INFO - 2024-06-18 23:15:36 --> Helper loaded: form_helper
INFO - 2024-06-18 23:15:36 --> Helper loaded: my_helper
INFO - 2024-06-18 23:15:36 --> Database Driver Class Initialized
INFO - 2024-06-18 23:15:36 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-18 23:15:36 --> Controller Class Initialized
INFO - 2024-06-18 23:15:40 --> Config Class Initialized
INFO - 2024-06-18 23:15:40 --> Hooks Class Initialized
DEBUG - 2024-06-18 23:15:40 --> UTF-8 Support Enabled
INFO - 2024-06-18 23:15:40 --> Utf8 Class Initialized
INFO - 2024-06-18 23:15:40 --> URI Class Initialized
INFO - 2024-06-18 23:15:40 --> Router Class Initialized
INFO - 2024-06-18 23:15:40 --> Output Class Initialized
INFO - 2024-06-18 23:15:40 --> Security Class Initialized
DEBUG - 2024-06-18 23:15:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-18 23:15:40 --> Input Class Initialized
INFO - 2024-06-18 23:15:40 --> Language Class Initialized
INFO - 2024-06-18 23:15:40 --> Language Class Initialized
INFO - 2024-06-18 23:15:40 --> Config Class Initialized
INFO - 2024-06-18 23:15:40 --> Loader Class Initialized
INFO - 2024-06-18 23:15:40 --> Helper loaded: url_helper
INFO - 2024-06-18 23:15:40 --> Helper loaded: file_helper
INFO - 2024-06-18 23:15:40 --> Helper loaded: form_helper
INFO - 2024-06-18 23:15:40 --> Helper loaded: my_helper
INFO - 2024-06-18 23:15:40 --> Database Driver Class Initialized
INFO - 2024-06-18 23:15:40 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-18 23:15:40 --> Controller Class Initialized
INFO - 2024-06-18 23:15:40 --> Final output sent to browser
DEBUG - 2024-06-18 23:15:40 --> Total execution time: 0.0245
INFO - 2024-06-18 23:17:02 --> Config Class Initialized
INFO - 2024-06-18 23:17:02 --> Hooks Class Initialized
DEBUG - 2024-06-18 23:17:02 --> UTF-8 Support Enabled
INFO - 2024-06-18 23:17:02 --> Utf8 Class Initialized
INFO - 2024-06-18 23:17:02 --> URI Class Initialized
INFO - 2024-06-18 23:17:02 --> Router Class Initialized
INFO - 2024-06-18 23:17:02 --> Output Class Initialized
INFO - 2024-06-18 23:17:02 --> Security Class Initialized
DEBUG - 2024-06-18 23:17:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-18 23:17:02 --> Input Class Initialized
INFO - 2024-06-18 23:17:02 --> Language Class Initialized
INFO - 2024-06-18 23:17:02 --> Language Class Initialized
INFO - 2024-06-18 23:17:02 --> Config Class Initialized
INFO - 2024-06-18 23:17:02 --> Loader Class Initialized
INFO - 2024-06-18 23:17:02 --> Helper loaded: url_helper
INFO - 2024-06-18 23:17:02 --> Helper loaded: file_helper
INFO - 2024-06-18 23:17:02 --> Helper loaded: form_helper
INFO - 2024-06-18 23:17:02 --> Helper loaded: my_helper
INFO - 2024-06-18 23:17:02 --> Database Driver Class Initialized
INFO - 2024-06-18 23:17:02 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-18 23:17:02 --> Controller Class Initialized
INFO - 2024-06-18 23:17:02 --> Final output sent to browser
DEBUG - 2024-06-18 23:17:02 --> Total execution time: 0.0792
INFO - 2024-06-18 23:17:02 --> Config Class Initialized
INFO - 2024-06-18 23:17:02 --> Hooks Class Initialized
DEBUG - 2024-06-18 23:17:02 --> UTF-8 Support Enabled
INFO - 2024-06-18 23:17:02 --> Utf8 Class Initialized
INFO - 2024-06-18 23:17:02 --> URI Class Initialized
INFO - 2024-06-18 23:17:02 --> Router Class Initialized
INFO - 2024-06-18 23:17:02 --> Output Class Initialized
INFO - 2024-06-18 23:17:02 --> Security Class Initialized
DEBUG - 2024-06-18 23:17:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-18 23:17:02 --> Input Class Initialized
INFO - 2024-06-18 23:17:02 --> Language Class Initialized
INFO - 2024-06-18 23:17:02 --> Language Class Initialized
INFO - 2024-06-18 23:17:02 --> Config Class Initialized
INFO - 2024-06-18 23:17:02 --> Loader Class Initialized
INFO - 2024-06-18 23:17:02 --> Helper loaded: url_helper
INFO - 2024-06-18 23:17:02 --> Helper loaded: file_helper
INFO - 2024-06-18 23:17:02 --> Helper loaded: form_helper
INFO - 2024-06-18 23:17:02 --> Helper loaded: my_helper
INFO - 2024-06-18 23:17:02 --> Database Driver Class Initialized
INFO - 2024-06-18 23:17:02 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-18 23:17:02 --> Controller Class Initialized
INFO - 2024-06-18 23:17:04 --> Config Class Initialized
INFO - 2024-06-18 23:17:04 --> Hooks Class Initialized
DEBUG - 2024-06-18 23:17:04 --> UTF-8 Support Enabled
INFO - 2024-06-18 23:17:04 --> Utf8 Class Initialized
INFO - 2024-06-18 23:17:04 --> URI Class Initialized
INFO - 2024-06-18 23:17:04 --> Router Class Initialized
INFO - 2024-06-18 23:17:04 --> Output Class Initialized
INFO - 2024-06-18 23:17:04 --> Security Class Initialized
DEBUG - 2024-06-18 23:17:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-18 23:17:04 --> Input Class Initialized
INFO - 2024-06-18 23:17:04 --> Language Class Initialized
INFO - 2024-06-18 23:17:04 --> Language Class Initialized
INFO - 2024-06-18 23:17:04 --> Config Class Initialized
INFO - 2024-06-18 23:17:04 --> Loader Class Initialized
INFO - 2024-06-18 23:17:04 --> Helper loaded: url_helper
INFO - 2024-06-18 23:17:04 --> Helper loaded: file_helper
INFO - 2024-06-18 23:17:04 --> Helper loaded: form_helper
INFO - 2024-06-18 23:17:04 --> Helper loaded: my_helper
INFO - 2024-06-18 23:17:04 --> Database Driver Class Initialized
INFO - 2024-06-18 23:17:04 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-18 23:17:04 --> Controller Class Initialized
INFO - 2024-06-18 23:17:04 --> Final output sent to browser
DEBUG - 2024-06-18 23:17:04 --> Total execution time: 0.0539
INFO - 2024-06-18 23:18:48 --> Config Class Initialized
INFO - 2024-06-18 23:18:48 --> Hooks Class Initialized
DEBUG - 2024-06-18 23:18:48 --> UTF-8 Support Enabled
INFO - 2024-06-18 23:18:48 --> Utf8 Class Initialized
INFO - 2024-06-18 23:18:48 --> URI Class Initialized
INFO - 2024-06-18 23:18:48 --> Router Class Initialized
INFO - 2024-06-18 23:18:48 --> Output Class Initialized
INFO - 2024-06-18 23:18:48 --> Security Class Initialized
DEBUG - 2024-06-18 23:18:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-18 23:18:48 --> Input Class Initialized
INFO - 2024-06-18 23:18:48 --> Language Class Initialized
INFO - 2024-06-18 23:18:48 --> Language Class Initialized
INFO - 2024-06-18 23:18:48 --> Config Class Initialized
INFO - 2024-06-18 23:18:48 --> Loader Class Initialized
INFO - 2024-06-18 23:18:48 --> Helper loaded: url_helper
INFO - 2024-06-18 23:18:48 --> Helper loaded: file_helper
INFO - 2024-06-18 23:18:48 --> Helper loaded: form_helper
INFO - 2024-06-18 23:18:48 --> Helper loaded: my_helper
INFO - 2024-06-18 23:18:48 --> Database Driver Class Initialized
INFO - 2024-06-18 23:18:48 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-18 23:18:48 --> Controller Class Initialized
INFO - 2024-06-18 23:18:48 --> Final output sent to browser
DEBUG - 2024-06-18 23:18:48 --> Total execution time: 0.0607
INFO - 2024-06-18 23:18:54 --> Config Class Initialized
INFO - 2024-06-18 23:18:54 --> Hooks Class Initialized
DEBUG - 2024-06-18 23:18:54 --> UTF-8 Support Enabled
INFO - 2024-06-18 23:18:54 --> Utf8 Class Initialized
INFO - 2024-06-18 23:18:54 --> URI Class Initialized
INFO - 2024-06-18 23:18:54 --> Router Class Initialized
INFO - 2024-06-18 23:18:54 --> Output Class Initialized
INFO - 2024-06-18 23:18:54 --> Security Class Initialized
DEBUG - 2024-06-18 23:18:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-18 23:18:54 --> Input Class Initialized
INFO - 2024-06-18 23:18:54 --> Language Class Initialized
INFO - 2024-06-18 23:18:54 --> Language Class Initialized
INFO - 2024-06-18 23:18:54 --> Config Class Initialized
INFO - 2024-06-18 23:18:54 --> Loader Class Initialized
INFO - 2024-06-18 23:18:54 --> Helper loaded: url_helper
INFO - 2024-06-18 23:18:54 --> Helper loaded: file_helper
INFO - 2024-06-18 23:18:54 --> Helper loaded: form_helper
INFO - 2024-06-18 23:18:54 --> Helper loaded: my_helper
INFO - 2024-06-18 23:18:54 --> Database Driver Class Initialized
INFO - 2024-06-18 23:18:54 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-18 23:18:54 --> Controller Class Initialized
INFO - 2024-06-18 23:18:54 --> Final output sent to browser
DEBUG - 2024-06-18 23:18:54 --> Total execution time: 0.0317
INFO - 2024-06-18 23:20:03 --> Config Class Initialized
INFO - 2024-06-18 23:20:03 --> Hooks Class Initialized
DEBUG - 2024-06-18 23:20:03 --> UTF-8 Support Enabled
INFO - 2024-06-18 23:20:03 --> Utf8 Class Initialized
INFO - 2024-06-18 23:20:03 --> URI Class Initialized
INFO - 2024-06-18 23:20:03 --> Router Class Initialized
INFO - 2024-06-18 23:20:03 --> Output Class Initialized
INFO - 2024-06-18 23:20:03 --> Security Class Initialized
DEBUG - 2024-06-18 23:20:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-18 23:20:03 --> Input Class Initialized
INFO - 2024-06-18 23:20:03 --> Language Class Initialized
INFO - 2024-06-18 23:20:03 --> Language Class Initialized
INFO - 2024-06-18 23:20:03 --> Config Class Initialized
INFO - 2024-06-18 23:20:03 --> Loader Class Initialized
INFO - 2024-06-18 23:20:03 --> Helper loaded: url_helper
INFO - 2024-06-18 23:20:03 --> Helper loaded: file_helper
INFO - 2024-06-18 23:20:03 --> Helper loaded: form_helper
INFO - 2024-06-18 23:20:03 --> Helper loaded: my_helper
INFO - 2024-06-18 23:20:03 --> Database Driver Class Initialized
INFO - 2024-06-18 23:20:03 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-18 23:20:03 --> Controller Class Initialized
INFO - 2024-06-18 23:20:03 --> Final output sent to browser
DEBUG - 2024-06-18 23:20:03 --> Total execution time: 0.0595
INFO - 2024-06-18 23:20:09 --> Config Class Initialized
INFO - 2024-06-18 23:20:09 --> Hooks Class Initialized
DEBUG - 2024-06-18 23:20:09 --> UTF-8 Support Enabled
INFO - 2024-06-18 23:20:09 --> Utf8 Class Initialized
INFO - 2024-06-18 23:20:09 --> URI Class Initialized
INFO - 2024-06-18 23:20:09 --> Router Class Initialized
INFO - 2024-06-18 23:20:09 --> Output Class Initialized
INFO - 2024-06-18 23:20:09 --> Security Class Initialized
DEBUG - 2024-06-18 23:20:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-18 23:20:09 --> Input Class Initialized
INFO - 2024-06-18 23:20:09 --> Language Class Initialized
INFO - 2024-06-18 23:20:09 --> Language Class Initialized
INFO - 2024-06-18 23:20:09 --> Config Class Initialized
INFO - 2024-06-18 23:20:09 --> Loader Class Initialized
INFO - 2024-06-18 23:20:09 --> Helper loaded: url_helper
INFO - 2024-06-18 23:20:09 --> Helper loaded: file_helper
INFO - 2024-06-18 23:20:09 --> Helper loaded: form_helper
INFO - 2024-06-18 23:20:09 --> Helper loaded: my_helper
INFO - 2024-06-18 23:20:09 --> Database Driver Class Initialized
INFO - 2024-06-18 23:20:10 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-18 23:20:10 --> Controller Class Initialized
INFO - 2024-06-18 23:20:10 --> Final output sent to browser
DEBUG - 2024-06-18 23:20:10 --> Total execution time: 0.0312
INFO - 2024-06-18 23:20:46 --> Config Class Initialized
INFO - 2024-06-18 23:20:46 --> Hooks Class Initialized
DEBUG - 2024-06-18 23:20:46 --> UTF-8 Support Enabled
INFO - 2024-06-18 23:20:46 --> Utf8 Class Initialized
INFO - 2024-06-18 23:20:46 --> URI Class Initialized
INFO - 2024-06-18 23:20:46 --> Router Class Initialized
INFO - 2024-06-18 23:20:46 --> Output Class Initialized
INFO - 2024-06-18 23:20:46 --> Security Class Initialized
DEBUG - 2024-06-18 23:20:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-18 23:20:46 --> Input Class Initialized
INFO - 2024-06-18 23:20:46 --> Language Class Initialized
INFO - 2024-06-18 23:20:46 --> Language Class Initialized
INFO - 2024-06-18 23:20:46 --> Config Class Initialized
INFO - 2024-06-18 23:20:46 --> Loader Class Initialized
INFO - 2024-06-18 23:20:46 --> Helper loaded: url_helper
INFO - 2024-06-18 23:20:46 --> Helper loaded: file_helper
INFO - 2024-06-18 23:20:46 --> Helper loaded: form_helper
INFO - 2024-06-18 23:20:46 --> Helper loaded: my_helper
INFO - 2024-06-18 23:20:46 --> Database Driver Class Initialized
INFO - 2024-06-18 23:20:46 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-18 23:20:46 --> Controller Class Initialized
INFO - 2024-06-18 23:20:46 --> Final output sent to browser
DEBUG - 2024-06-18 23:20:46 --> Total execution time: 0.0502
INFO - 2024-06-18 23:21:03 --> Config Class Initialized
INFO - 2024-06-18 23:21:03 --> Hooks Class Initialized
DEBUG - 2024-06-18 23:21:03 --> UTF-8 Support Enabled
INFO - 2024-06-18 23:21:03 --> Utf8 Class Initialized
INFO - 2024-06-18 23:21:03 --> URI Class Initialized
INFO - 2024-06-18 23:21:03 --> Router Class Initialized
INFO - 2024-06-18 23:21:03 --> Output Class Initialized
INFO - 2024-06-18 23:21:03 --> Security Class Initialized
DEBUG - 2024-06-18 23:21:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-18 23:21:03 --> Input Class Initialized
INFO - 2024-06-18 23:21:03 --> Language Class Initialized
INFO - 2024-06-18 23:21:03 --> Language Class Initialized
INFO - 2024-06-18 23:21:03 --> Config Class Initialized
INFO - 2024-06-18 23:21:03 --> Loader Class Initialized
INFO - 2024-06-18 23:21:03 --> Helper loaded: url_helper
INFO - 2024-06-18 23:21:03 --> Helper loaded: file_helper
INFO - 2024-06-18 23:21:03 --> Helper loaded: form_helper
INFO - 2024-06-18 23:21:03 --> Helper loaded: my_helper
INFO - 2024-06-18 23:21:03 --> Database Driver Class Initialized
INFO - 2024-06-18 23:21:03 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-18 23:21:03 --> Controller Class Initialized
INFO - 2024-06-18 23:21:03 --> Final output sent to browser
DEBUG - 2024-06-18 23:21:03 --> Total execution time: 0.0320
INFO - 2024-06-18 23:21:22 --> Config Class Initialized
INFO - 2024-06-18 23:21:22 --> Hooks Class Initialized
DEBUG - 2024-06-18 23:21:22 --> UTF-8 Support Enabled
INFO - 2024-06-18 23:21:22 --> Utf8 Class Initialized
INFO - 2024-06-18 23:21:22 --> URI Class Initialized
INFO - 2024-06-18 23:21:22 --> Router Class Initialized
INFO - 2024-06-18 23:21:22 --> Output Class Initialized
INFO - 2024-06-18 23:21:22 --> Security Class Initialized
DEBUG - 2024-06-18 23:21:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-18 23:21:22 --> Input Class Initialized
INFO - 2024-06-18 23:21:22 --> Language Class Initialized
INFO - 2024-06-18 23:21:22 --> Language Class Initialized
INFO - 2024-06-18 23:21:22 --> Config Class Initialized
INFO - 2024-06-18 23:21:22 --> Loader Class Initialized
INFO - 2024-06-18 23:21:22 --> Helper loaded: url_helper
INFO - 2024-06-18 23:21:22 --> Helper loaded: file_helper
INFO - 2024-06-18 23:21:22 --> Helper loaded: form_helper
INFO - 2024-06-18 23:21:22 --> Helper loaded: my_helper
INFO - 2024-06-18 23:21:22 --> Database Driver Class Initialized
INFO - 2024-06-18 23:21:22 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-18 23:21:22 --> Controller Class Initialized
INFO - 2024-06-18 23:21:22 --> Final output sent to browser
DEBUG - 2024-06-18 23:21:22 --> Total execution time: 0.0426
INFO - 2024-06-18 23:21:32 --> Config Class Initialized
INFO - 2024-06-18 23:21:32 --> Hooks Class Initialized
DEBUG - 2024-06-18 23:21:32 --> UTF-8 Support Enabled
INFO - 2024-06-18 23:21:32 --> Utf8 Class Initialized
INFO - 2024-06-18 23:21:32 --> URI Class Initialized
INFO - 2024-06-18 23:21:32 --> Router Class Initialized
INFO - 2024-06-18 23:21:32 --> Output Class Initialized
INFO - 2024-06-18 23:21:32 --> Security Class Initialized
DEBUG - 2024-06-18 23:21:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-18 23:21:32 --> Input Class Initialized
INFO - 2024-06-18 23:21:32 --> Language Class Initialized
INFO - 2024-06-18 23:21:32 --> Language Class Initialized
INFO - 2024-06-18 23:21:32 --> Config Class Initialized
INFO - 2024-06-18 23:21:32 --> Loader Class Initialized
INFO - 2024-06-18 23:21:32 --> Helper loaded: url_helper
INFO - 2024-06-18 23:21:32 --> Helper loaded: file_helper
INFO - 2024-06-18 23:21:32 --> Helper loaded: form_helper
INFO - 2024-06-18 23:21:32 --> Helper loaded: my_helper
INFO - 2024-06-18 23:21:32 --> Database Driver Class Initialized
INFO - 2024-06-18 23:21:32 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-18 23:21:32 --> Controller Class Initialized
INFO - 2024-06-18 23:21:32 --> Final output sent to browser
DEBUG - 2024-06-18 23:21:32 --> Total execution time: 0.1328
INFO - 2024-06-18 23:22:34 --> Config Class Initialized
INFO - 2024-06-18 23:22:34 --> Hooks Class Initialized
DEBUG - 2024-06-18 23:22:34 --> UTF-8 Support Enabled
INFO - 2024-06-18 23:22:34 --> Utf8 Class Initialized
INFO - 2024-06-18 23:22:34 --> URI Class Initialized
INFO - 2024-06-18 23:22:34 --> Router Class Initialized
INFO - 2024-06-18 23:22:34 --> Output Class Initialized
INFO - 2024-06-18 23:22:34 --> Security Class Initialized
DEBUG - 2024-06-18 23:22:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-18 23:22:34 --> Input Class Initialized
INFO - 2024-06-18 23:22:34 --> Language Class Initialized
INFO - 2024-06-18 23:22:34 --> Language Class Initialized
INFO - 2024-06-18 23:22:34 --> Config Class Initialized
INFO - 2024-06-18 23:22:34 --> Loader Class Initialized
INFO - 2024-06-18 23:22:34 --> Helper loaded: url_helper
INFO - 2024-06-18 23:22:34 --> Helper loaded: file_helper
INFO - 2024-06-18 23:22:34 --> Helper loaded: form_helper
INFO - 2024-06-18 23:22:34 --> Helper loaded: my_helper
INFO - 2024-06-18 23:22:34 --> Database Driver Class Initialized
INFO - 2024-06-18 23:22:34 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-18 23:22:34 --> Controller Class Initialized
INFO - 2024-06-18 23:22:34 --> Final output sent to browser
DEBUG - 2024-06-18 23:22:34 --> Total execution time: 0.0448
INFO - 2024-06-18 23:22:39 --> Config Class Initialized
INFO - 2024-06-18 23:22:39 --> Hooks Class Initialized
DEBUG - 2024-06-18 23:22:39 --> UTF-8 Support Enabled
INFO - 2024-06-18 23:22:39 --> Utf8 Class Initialized
INFO - 2024-06-18 23:22:39 --> URI Class Initialized
INFO - 2024-06-18 23:22:39 --> Router Class Initialized
INFO - 2024-06-18 23:22:39 --> Output Class Initialized
INFO - 2024-06-18 23:22:39 --> Security Class Initialized
DEBUG - 2024-06-18 23:22:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-18 23:22:39 --> Input Class Initialized
INFO - 2024-06-18 23:22:39 --> Language Class Initialized
INFO - 2024-06-18 23:22:39 --> Language Class Initialized
INFO - 2024-06-18 23:22:39 --> Config Class Initialized
INFO - 2024-06-18 23:22:39 --> Loader Class Initialized
INFO - 2024-06-18 23:22:39 --> Helper loaded: url_helper
INFO - 2024-06-18 23:22:39 --> Helper loaded: file_helper
INFO - 2024-06-18 23:22:39 --> Helper loaded: form_helper
INFO - 2024-06-18 23:22:39 --> Helper loaded: my_helper
INFO - 2024-06-18 23:22:39 --> Database Driver Class Initialized
INFO - 2024-06-18 23:22:39 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-18 23:22:39 --> Controller Class Initialized
INFO - 2024-06-18 23:22:39 --> Final output sent to browser
DEBUG - 2024-06-18 23:22:39 --> Total execution time: 0.0331
INFO - 2024-06-18 23:23:08 --> Config Class Initialized
INFO - 2024-06-18 23:23:08 --> Hooks Class Initialized
DEBUG - 2024-06-18 23:23:08 --> UTF-8 Support Enabled
INFO - 2024-06-18 23:23:08 --> Utf8 Class Initialized
INFO - 2024-06-18 23:23:08 --> URI Class Initialized
INFO - 2024-06-18 23:23:08 --> Router Class Initialized
INFO - 2024-06-18 23:23:08 --> Output Class Initialized
INFO - 2024-06-18 23:23:08 --> Security Class Initialized
DEBUG - 2024-06-18 23:23:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-18 23:23:08 --> Input Class Initialized
INFO - 2024-06-18 23:23:08 --> Language Class Initialized
INFO - 2024-06-18 23:23:08 --> Language Class Initialized
INFO - 2024-06-18 23:23:08 --> Config Class Initialized
INFO - 2024-06-18 23:23:08 --> Loader Class Initialized
INFO - 2024-06-18 23:23:08 --> Helper loaded: url_helper
INFO - 2024-06-18 23:23:08 --> Helper loaded: file_helper
INFO - 2024-06-18 23:23:08 --> Helper loaded: form_helper
INFO - 2024-06-18 23:23:08 --> Helper loaded: my_helper
INFO - 2024-06-18 23:23:08 --> Database Driver Class Initialized
INFO - 2024-06-18 23:23:09 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-18 23:23:09 --> Controller Class Initialized
DEBUG - 2024-06-18 23:23:09 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/view_mapel/views/v_view_mapel.php
DEBUG - 2024-06-18 23:23:09 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-06-18 23:23:09 --> Final output sent to browser
DEBUG - 2024-06-18 23:23:09 --> Total execution time: 0.0370
INFO - 2024-06-18 23:23:22 --> Config Class Initialized
INFO - 2024-06-18 23:23:22 --> Hooks Class Initialized
DEBUG - 2024-06-18 23:23:22 --> UTF-8 Support Enabled
INFO - 2024-06-18 23:23:22 --> Utf8 Class Initialized
INFO - 2024-06-18 23:23:22 --> URI Class Initialized
INFO - 2024-06-18 23:23:22 --> Router Class Initialized
INFO - 2024-06-18 23:23:22 --> Output Class Initialized
INFO - 2024-06-18 23:23:22 --> Security Class Initialized
DEBUG - 2024-06-18 23:23:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-18 23:23:22 --> Input Class Initialized
INFO - 2024-06-18 23:23:22 --> Language Class Initialized
INFO - 2024-06-18 23:23:22 --> Language Class Initialized
INFO - 2024-06-18 23:23:22 --> Config Class Initialized
INFO - 2024-06-18 23:23:22 --> Loader Class Initialized
INFO - 2024-06-18 23:23:22 --> Helper loaded: url_helper
INFO - 2024-06-18 23:23:22 --> Helper loaded: file_helper
INFO - 2024-06-18 23:23:22 --> Helper loaded: form_helper
INFO - 2024-06-18 23:23:22 --> Helper loaded: my_helper
INFO - 2024-06-18 23:23:22 --> Database Driver Class Initialized
INFO - 2024-06-18 23:23:22 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-18 23:23:22 --> Controller Class Initialized
DEBUG - 2024-06-18 23:23:22 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/view_mapel/views/v_view_mapel.php
DEBUG - 2024-06-18 23:23:22 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-06-18 23:23:22 --> Final output sent to browser
DEBUG - 2024-06-18 23:23:22 --> Total execution time: 0.0404
INFO - 2024-06-18 23:23:27 --> Config Class Initialized
INFO - 2024-06-18 23:23:27 --> Hooks Class Initialized
DEBUG - 2024-06-18 23:23:27 --> UTF-8 Support Enabled
INFO - 2024-06-18 23:23:27 --> Utf8 Class Initialized
INFO - 2024-06-18 23:23:27 --> URI Class Initialized
INFO - 2024-06-18 23:23:27 --> Router Class Initialized
INFO - 2024-06-18 23:23:27 --> Output Class Initialized
INFO - 2024-06-18 23:23:27 --> Security Class Initialized
DEBUG - 2024-06-18 23:23:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-18 23:23:27 --> Input Class Initialized
INFO - 2024-06-18 23:23:27 --> Language Class Initialized
INFO - 2024-06-18 23:23:27 --> Language Class Initialized
INFO - 2024-06-18 23:23:27 --> Config Class Initialized
INFO - 2024-06-18 23:23:27 --> Loader Class Initialized
INFO - 2024-06-18 23:23:27 --> Helper loaded: url_helper
INFO - 2024-06-18 23:23:27 --> Helper loaded: file_helper
INFO - 2024-06-18 23:23:27 --> Helper loaded: form_helper
INFO - 2024-06-18 23:23:27 --> Helper loaded: my_helper
INFO - 2024-06-18 23:23:27 --> Database Driver Class Initialized
INFO - 2024-06-18 23:23:27 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-18 23:23:27 --> Controller Class Initialized
DEBUG - 2024-06-18 23:23:27 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/views/list.php
DEBUG - 2024-06-18 23:23:27 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-06-18 23:23:27 --> Final output sent to browser
DEBUG - 2024-06-18 23:23:27 --> Total execution time: 0.0527
INFO - 2024-06-18 23:23:27 --> Config Class Initialized
INFO - 2024-06-18 23:23:27 --> Hooks Class Initialized
DEBUG - 2024-06-18 23:23:27 --> UTF-8 Support Enabled
INFO - 2024-06-18 23:23:27 --> Utf8 Class Initialized
INFO - 2024-06-18 23:23:27 --> URI Class Initialized
INFO - 2024-06-18 23:23:27 --> Router Class Initialized
INFO - 2024-06-18 23:23:27 --> Output Class Initialized
INFO - 2024-06-18 23:23:27 --> Security Class Initialized
DEBUG - 2024-06-18 23:23:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-18 23:23:27 --> Input Class Initialized
INFO - 2024-06-18 23:23:27 --> Language Class Initialized
INFO - 2024-06-18 23:23:27 --> Language Class Initialized
INFO - 2024-06-18 23:23:27 --> Config Class Initialized
INFO - 2024-06-18 23:23:27 --> Loader Class Initialized
INFO - 2024-06-18 23:23:27 --> Helper loaded: url_helper
INFO - 2024-06-18 23:23:27 --> Helper loaded: file_helper
INFO - 2024-06-18 23:23:27 --> Helper loaded: form_helper
INFO - 2024-06-18 23:23:27 --> Helper loaded: my_helper
INFO - 2024-06-18 23:23:27 --> Database Driver Class Initialized
INFO - 2024-06-18 23:23:27 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-18 23:23:27 --> Controller Class Initialized
INFO - 2024-06-18 23:23:29 --> Config Class Initialized
INFO - 2024-06-18 23:23:29 --> Hooks Class Initialized
DEBUG - 2024-06-18 23:23:29 --> UTF-8 Support Enabled
INFO - 2024-06-18 23:23:29 --> Utf8 Class Initialized
INFO - 2024-06-18 23:23:29 --> URI Class Initialized
INFO - 2024-06-18 23:23:29 --> Router Class Initialized
INFO - 2024-06-18 23:23:29 --> Output Class Initialized
INFO - 2024-06-18 23:23:29 --> Security Class Initialized
DEBUG - 2024-06-18 23:23:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-18 23:23:29 --> Input Class Initialized
INFO - 2024-06-18 23:23:29 --> Language Class Initialized
INFO - 2024-06-18 23:23:29 --> Language Class Initialized
INFO - 2024-06-18 23:23:29 --> Config Class Initialized
INFO - 2024-06-18 23:23:29 --> Loader Class Initialized
INFO - 2024-06-18 23:23:29 --> Helper loaded: url_helper
INFO - 2024-06-18 23:23:29 --> Helper loaded: file_helper
INFO - 2024-06-18 23:23:29 --> Helper loaded: form_helper
INFO - 2024-06-18 23:23:29 --> Helper loaded: my_helper
INFO - 2024-06-18 23:23:29 --> Database Driver Class Initialized
INFO - 2024-06-18 23:23:29 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-18 23:23:29 --> Controller Class Initialized
INFO - 2024-06-18 23:23:29 --> Final output sent to browser
DEBUG - 2024-06-18 23:23:29 --> Total execution time: 0.0407
INFO - 2024-06-18 23:23:43 --> Config Class Initialized
INFO - 2024-06-18 23:23:43 --> Hooks Class Initialized
DEBUG - 2024-06-18 23:23:43 --> UTF-8 Support Enabled
INFO - 2024-06-18 23:23:43 --> Utf8 Class Initialized
INFO - 2024-06-18 23:23:43 --> URI Class Initialized
INFO - 2024-06-18 23:23:43 --> Router Class Initialized
INFO - 2024-06-18 23:23:43 --> Output Class Initialized
INFO - 2024-06-18 23:23:43 --> Security Class Initialized
DEBUG - 2024-06-18 23:23:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-18 23:23:43 --> Input Class Initialized
INFO - 2024-06-18 23:23:43 --> Language Class Initialized
INFO - 2024-06-18 23:23:43 --> Language Class Initialized
INFO - 2024-06-18 23:23:43 --> Config Class Initialized
INFO - 2024-06-18 23:23:43 --> Loader Class Initialized
INFO - 2024-06-18 23:23:43 --> Helper loaded: url_helper
INFO - 2024-06-18 23:23:43 --> Helper loaded: file_helper
INFO - 2024-06-18 23:23:43 --> Helper loaded: form_helper
INFO - 2024-06-18 23:23:43 --> Helper loaded: my_helper
INFO - 2024-06-18 23:23:43 --> Database Driver Class Initialized
INFO - 2024-06-18 23:23:43 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-18 23:23:43 --> Controller Class Initialized
DEBUG - 2024-06-18 23:23:43 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/views/list.php
DEBUG - 2024-06-18 23:23:43 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-06-18 23:23:43 --> Final output sent to browser
DEBUG - 2024-06-18 23:23:43 --> Total execution time: 0.0350
INFO - 2024-06-18 23:23:48 --> Config Class Initialized
INFO - 2024-06-18 23:23:48 --> Hooks Class Initialized
DEBUG - 2024-06-18 23:23:48 --> UTF-8 Support Enabled
INFO - 2024-06-18 23:23:48 --> Utf8 Class Initialized
INFO - 2024-06-18 23:23:48 --> URI Class Initialized
INFO - 2024-06-18 23:23:48 --> Router Class Initialized
INFO - 2024-06-18 23:23:48 --> Output Class Initialized
INFO - 2024-06-18 23:23:48 --> Security Class Initialized
DEBUG - 2024-06-18 23:23:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-18 23:23:48 --> Input Class Initialized
INFO - 2024-06-18 23:23:48 --> Language Class Initialized
INFO - 2024-06-18 23:23:48 --> Language Class Initialized
INFO - 2024-06-18 23:23:48 --> Config Class Initialized
INFO - 2024-06-18 23:23:48 --> Loader Class Initialized
INFO - 2024-06-18 23:23:49 --> Helper loaded: url_helper
INFO - 2024-06-18 23:23:49 --> Helper loaded: file_helper
INFO - 2024-06-18 23:23:49 --> Helper loaded: form_helper
INFO - 2024-06-18 23:23:49 --> Helper loaded: my_helper
INFO - 2024-06-18 23:23:49 --> Database Driver Class Initialized
INFO - 2024-06-18 23:23:49 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-18 23:23:49 --> Controller Class Initialized
DEBUG - 2024-06-18 23:23:49 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/views/cetak_ikm.php
INFO - 2024-06-18 23:23:51 --> Final output sent to browser
DEBUG - 2024-06-18 23:23:51 --> Total execution time: 2.3622
INFO - 2024-06-18 23:24:18 --> Config Class Initialized
INFO - 2024-06-18 23:24:18 --> Hooks Class Initialized
DEBUG - 2024-06-18 23:24:18 --> UTF-8 Support Enabled
INFO - 2024-06-18 23:24:18 --> Utf8 Class Initialized
INFO - 2024-06-18 23:24:18 --> URI Class Initialized
INFO - 2024-06-18 23:24:18 --> Router Class Initialized
INFO - 2024-06-18 23:24:18 --> Output Class Initialized
INFO - 2024-06-18 23:24:18 --> Security Class Initialized
DEBUG - 2024-06-18 23:24:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-18 23:24:18 --> Input Class Initialized
INFO - 2024-06-18 23:24:18 --> Language Class Initialized
INFO - 2024-06-18 23:24:18 --> Language Class Initialized
INFO - 2024-06-18 23:24:18 --> Config Class Initialized
INFO - 2024-06-18 23:24:18 --> Loader Class Initialized
INFO - 2024-06-18 23:24:18 --> Helper loaded: url_helper
INFO - 2024-06-18 23:24:18 --> Helper loaded: file_helper
INFO - 2024-06-18 23:24:18 --> Helper loaded: form_helper
INFO - 2024-06-18 23:24:18 --> Helper loaded: my_helper
INFO - 2024-06-18 23:24:18 --> Database Driver Class Initialized
INFO - 2024-06-18 23:24:18 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-18 23:24:18 --> Controller Class Initialized
DEBUG - 2024-06-18 23:24:18 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/views/cetak_tahfiz.php
INFO - 2024-06-18 23:24:21 --> Final output sent to browser
DEBUG - 2024-06-18 23:24:21 --> Total execution time: 3.4889
INFO - 2024-06-18 23:24:42 --> Config Class Initialized
INFO - 2024-06-18 23:24:42 --> Hooks Class Initialized
DEBUG - 2024-06-18 23:24:42 --> UTF-8 Support Enabled
INFO - 2024-06-18 23:24:42 --> Utf8 Class Initialized
INFO - 2024-06-18 23:24:42 --> URI Class Initialized
INFO - 2024-06-18 23:24:42 --> Router Class Initialized
INFO - 2024-06-18 23:24:42 --> Output Class Initialized
INFO - 2024-06-18 23:24:42 --> Security Class Initialized
DEBUG - 2024-06-18 23:24:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-18 23:24:42 --> Input Class Initialized
INFO - 2024-06-18 23:24:42 --> Language Class Initialized
INFO - 2024-06-18 23:24:42 --> Language Class Initialized
INFO - 2024-06-18 23:24:42 --> Config Class Initialized
INFO - 2024-06-18 23:24:42 --> Loader Class Initialized
INFO - 2024-06-18 23:24:42 --> Helper loaded: url_helper
INFO - 2024-06-18 23:24:42 --> Helper loaded: file_helper
INFO - 2024-06-18 23:24:42 --> Helper loaded: form_helper
INFO - 2024-06-18 23:24:42 --> Helper loaded: my_helper
INFO - 2024-06-18 23:24:42 --> Database Driver Class Initialized
INFO - 2024-06-18 23:24:42 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-18 23:24:42 --> Controller Class Initialized
DEBUG - 2024-06-18 23:24:42 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/view_mapel/views/v_view_mapel.php
DEBUG - 2024-06-18 23:24:42 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-06-18 23:24:42 --> Final output sent to browser
DEBUG - 2024-06-18 23:24:42 --> Total execution time: 0.0487
INFO - 2024-06-18 23:24:45 --> Config Class Initialized
INFO - 2024-06-18 23:24:45 --> Hooks Class Initialized
DEBUG - 2024-06-18 23:24:45 --> UTF-8 Support Enabled
INFO - 2024-06-18 23:24:45 --> Utf8 Class Initialized
INFO - 2024-06-18 23:24:45 --> URI Class Initialized
INFO - 2024-06-18 23:24:45 --> Router Class Initialized
INFO - 2024-06-18 23:24:45 --> Output Class Initialized
INFO - 2024-06-18 23:24:45 --> Security Class Initialized
DEBUG - 2024-06-18 23:24:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-18 23:24:45 --> Input Class Initialized
INFO - 2024-06-18 23:24:45 --> Language Class Initialized
INFO - 2024-06-18 23:24:45 --> Language Class Initialized
INFO - 2024-06-18 23:24:45 --> Config Class Initialized
INFO - 2024-06-18 23:24:45 --> Loader Class Initialized
INFO - 2024-06-18 23:24:45 --> Helper loaded: url_helper
INFO - 2024-06-18 23:24:45 --> Helper loaded: file_helper
INFO - 2024-06-18 23:24:45 --> Helper loaded: form_helper
INFO - 2024-06-18 23:24:45 --> Helper loaded: my_helper
INFO - 2024-06-18 23:24:45 --> Database Driver Class Initialized
INFO - 2024-06-18 23:24:45 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-18 23:24:45 --> Controller Class Initialized
DEBUG - 2024-06-18 23:24:45 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/views/list.php
DEBUG - 2024-06-18 23:24:45 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-06-18 23:24:45 --> Final output sent to browser
DEBUG - 2024-06-18 23:24:45 --> Total execution time: 0.0356
INFO - 2024-06-18 23:24:45 --> Config Class Initialized
INFO - 2024-06-18 23:24:45 --> Hooks Class Initialized
DEBUG - 2024-06-18 23:24:45 --> UTF-8 Support Enabled
INFO - 2024-06-18 23:24:45 --> Utf8 Class Initialized
INFO - 2024-06-18 23:24:45 --> URI Class Initialized
INFO - 2024-06-18 23:24:45 --> Router Class Initialized
INFO - 2024-06-18 23:24:45 --> Output Class Initialized
INFO - 2024-06-18 23:24:45 --> Security Class Initialized
DEBUG - 2024-06-18 23:24:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-18 23:24:45 --> Input Class Initialized
INFO - 2024-06-18 23:24:45 --> Language Class Initialized
INFO - 2024-06-18 23:24:45 --> Language Class Initialized
INFO - 2024-06-18 23:24:45 --> Config Class Initialized
INFO - 2024-06-18 23:24:45 --> Loader Class Initialized
INFO - 2024-06-18 23:24:45 --> Helper loaded: url_helper
INFO - 2024-06-18 23:24:45 --> Helper loaded: file_helper
INFO - 2024-06-18 23:24:45 --> Helper loaded: form_helper
INFO - 2024-06-18 23:24:45 --> Helper loaded: my_helper
INFO - 2024-06-18 23:24:45 --> Database Driver Class Initialized
INFO - 2024-06-18 23:24:45 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-18 23:24:45 --> Controller Class Initialized
INFO - 2024-06-18 23:24:46 --> Config Class Initialized
INFO - 2024-06-18 23:24:46 --> Hooks Class Initialized
DEBUG - 2024-06-18 23:24:46 --> UTF-8 Support Enabled
INFO - 2024-06-18 23:24:46 --> Utf8 Class Initialized
INFO - 2024-06-18 23:24:46 --> URI Class Initialized
INFO - 2024-06-18 23:24:46 --> Router Class Initialized
INFO - 2024-06-18 23:24:46 --> Output Class Initialized
INFO - 2024-06-18 23:24:46 --> Security Class Initialized
DEBUG - 2024-06-18 23:24:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-18 23:24:46 --> Input Class Initialized
INFO - 2024-06-18 23:24:46 --> Language Class Initialized
INFO - 2024-06-18 23:24:46 --> Language Class Initialized
INFO - 2024-06-18 23:24:46 --> Config Class Initialized
INFO - 2024-06-18 23:24:46 --> Loader Class Initialized
INFO - 2024-06-18 23:24:46 --> Helper loaded: url_helper
INFO - 2024-06-18 23:24:46 --> Helper loaded: file_helper
INFO - 2024-06-18 23:24:46 --> Helper loaded: form_helper
INFO - 2024-06-18 23:24:46 --> Helper loaded: my_helper
INFO - 2024-06-18 23:24:46 --> Database Driver Class Initialized
INFO - 2024-06-18 23:24:46 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-18 23:24:46 --> Controller Class Initialized
INFO - 2024-06-18 23:24:46 --> Final output sent to browser
DEBUG - 2024-06-18 23:24:46 --> Total execution time: 0.0262
INFO - 2024-06-18 23:24:52 --> Config Class Initialized
INFO - 2024-06-18 23:24:52 --> Hooks Class Initialized
DEBUG - 2024-06-18 23:24:52 --> UTF-8 Support Enabled
INFO - 2024-06-18 23:24:52 --> Utf8 Class Initialized
INFO - 2024-06-18 23:24:52 --> URI Class Initialized
INFO - 2024-06-18 23:24:52 --> Router Class Initialized
INFO - 2024-06-18 23:24:52 --> Output Class Initialized
INFO - 2024-06-18 23:24:52 --> Security Class Initialized
DEBUG - 2024-06-18 23:24:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-18 23:24:52 --> Input Class Initialized
INFO - 2024-06-18 23:24:52 --> Language Class Initialized
INFO - 2024-06-18 23:24:52 --> Language Class Initialized
INFO - 2024-06-18 23:24:52 --> Config Class Initialized
INFO - 2024-06-18 23:24:52 --> Loader Class Initialized
INFO - 2024-06-18 23:24:52 --> Helper loaded: url_helper
INFO - 2024-06-18 23:24:52 --> Helper loaded: file_helper
INFO - 2024-06-18 23:24:52 --> Helper loaded: form_helper
INFO - 2024-06-18 23:24:52 --> Helper loaded: my_helper
INFO - 2024-06-18 23:24:52 --> Database Driver Class Initialized
INFO - 2024-06-18 23:24:52 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-18 23:24:52 --> Controller Class Initialized
DEBUG - 2024-06-18 23:24:52 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/view_mapel/views/v_view_mapel.php
DEBUG - 2024-06-18 23:24:52 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-06-18 23:24:52 --> Final output sent to browser
DEBUG - 2024-06-18 23:24:52 --> Total execution time: 0.0294
INFO - 2024-06-18 23:24:56 --> Config Class Initialized
INFO - 2024-06-18 23:24:56 --> Hooks Class Initialized
DEBUG - 2024-06-18 23:24:56 --> UTF-8 Support Enabled
INFO - 2024-06-18 23:24:56 --> Utf8 Class Initialized
INFO - 2024-06-18 23:24:56 --> URI Class Initialized
INFO - 2024-06-18 23:24:56 --> Router Class Initialized
INFO - 2024-06-18 23:24:56 --> Output Class Initialized
INFO - 2024-06-18 23:24:56 --> Security Class Initialized
DEBUG - 2024-06-18 23:24:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-18 23:24:56 --> Input Class Initialized
INFO - 2024-06-18 23:24:56 --> Language Class Initialized
INFO - 2024-06-18 23:24:56 --> Language Class Initialized
INFO - 2024-06-18 23:24:56 --> Config Class Initialized
INFO - 2024-06-18 23:24:56 --> Loader Class Initialized
INFO - 2024-06-18 23:24:56 --> Helper loaded: url_helper
INFO - 2024-06-18 23:24:56 --> Helper loaded: file_helper
INFO - 2024-06-18 23:24:56 --> Helper loaded: form_helper
INFO - 2024-06-18 23:24:56 --> Helper loaded: my_helper
INFO - 2024-06-18 23:24:56 --> Database Driver Class Initialized
INFO - 2024-06-18 23:24:56 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-18 23:24:56 --> Controller Class Initialized
DEBUG - 2024-06-18 23:24:56 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_catatan_guru/views/list.php
DEBUG - 2024-06-18 23:24:56 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-06-18 23:24:56 --> Final output sent to browser
DEBUG - 2024-06-18 23:24:56 --> Total execution time: 0.0289
INFO - 2024-06-18 23:24:57 --> Config Class Initialized
INFO - 2024-06-18 23:24:57 --> Hooks Class Initialized
DEBUG - 2024-06-18 23:24:57 --> UTF-8 Support Enabled
INFO - 2024-06-18 23:24:57 --> Utf8 Class Initialized
INFO - 2024-06-18 23:24:57 --> URI Class Initialized
INFO - 2024-06-18 23:24:57 --> Router Class Initialized
INFO - 2024-06-18 23:24:57 --> Output Class Initialized
INFO - 2024-06-18 23:24:57 --> Security Class Initialized
DEBUG - 2024-06-18 23:24:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-18 23:24:57 --> Input Class Initialized
INFO - 2024-06-18 23:24:57 --> Language Class Initialized
INFO - 2024-06-18 23:24:57 --> Language Class Initialized
INFO - 2024-06-18 23:24:57 --> Config Class Initialized
INFO - 2024-06-18 23:24:57 --> Loader Class Initialized
INFO - 2024-06-18 23:24:57 --> Helper loaded: url_helper
INFO - 2024-06-18 23:24:57 --> Helper loaded: file_helper
INFO - 2024-06-18 23:24:57 --> Helper loaded: form_helper
INFO - 2024-06-18 23:24:57 --> Helper loaded: my_helper
INFO - 2024-06-18 23:24:57 --> Database Driver Class Initialized
INFO - 2024-06-18 23:24:57 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-18 23:24:57 --> Controller Class Initialized
INFO - 2024-06-18 23:24:57 --> Final output sent to browser
DEBUG - 2024-06-18 23:24:57 --> Total execution time: 0.0297
INFO - 2024-06-18 23:25:12 --> Config Class Initialized
INFO - 2024-06-18 23:25:12 --> Hooks Class Initialized
DEBUG - 2024-06-18 23:25:12 --> UTF-8 Support Enabled
INFO - 2024-06-18 23:25:12 --> Utf8 Class Initialized
INFO - 2024-06-18 23:25:12 --> URI Class Initialized
INFO - 2024-06-18 23:25:12 --> Router Class Initialized
INFO - 2024-06-18 23:25:12 --> Output Class Initialized
INFO - 2024-06-18 23:25:12 --> Security Class Initialized
DEBUG - 2024-06-18 23:25:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-18 23:25:12 --> Input Class Initialized
INFO - 2024-06-18 23:25:12 --> Language Class Initialized
INFO - 2024-06-18 23:25:12 --> Language Class Initialized
INFO - 2024-06-18 23:25:12 --> Config Class Initialized
INFO - 2024-06-18 23:25:12 --> Loader Class Initialized
INFO - 2024-06-18 23:25:12 --> Helper loaded: url_helper
INFO - 2024-06-18 23:25:12 --> Helper loaded: file_helper
INFO - 2024-06-18 23:25:12 --> Helper loaded: form_helper
INFO - 2024-06-18 23:25:12 --> Helper loaded: my_helper
INFO - 2024-06-18 23:25:12 --> Database Driver Class Initialized
INFO - 2024-06-18 23:25:12 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-18 23:25:12 --> Controller Class Initialized
DEBUG - 2024-06-18 23:25:12 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/view_mapel/views/v_view_mapel.php
DEBUG - 2024-06-18 23:25:12 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-06-18 23:25:12 --> Final output sent to browser
DEBUG - 2024-06-18 23:25:12 --> Total execution time: 0.0280
INFO - 2024-06-18 23:25:16 --> Config Class Initialized
INFO - 2024-06-18 23:25:16 --> Hooks Class Initialized
DEBUG - 2024-06-18 23:25:16 --> UTF-8 Support Enabled
INFO - 2024-06-18 23:25:16 --> Utf8 Class Initialized
INFO - 2024-06-18 23:25:16 --> URI Class Initialized
INFO - 2024-06-18 23:25:16 --> Router Class Initialized
INFO - 2024-06-18 23:25:16 --> Output Class Initialized
INFO - 2024-06-18 23:25:16 --> Security Class Initialized
DEBUG - 2024-06-18 23:25:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-18 23:25:16 --> Input Class Initialized
INFO - 2024-06-18 23:25:16 --> Language Class Initialized
INFO - 2024-06-18 23:25:16 --> Language Class Initialized
INFO - 2024-06-18 23:25:16 --> Config Class Initialized
INFO - 2024-06-18 23:25:16 --> Loader Class Initialized
INFO - 2024-06-18 23:25:16 --> Helper loaded: url_helper
INFO - 2024-06-18 23:25:16 --> Helper loaded: file_helper
INFO - 2024-06-18 23:25:16 --> Helper loaded: form_helper
INFO - 2024-06-18 23:25:16 --> Helper loaded: my_helper
INFO - 2024-06-18 23:25:16 --> Database Driver Class Initialized
INFO - 2024-06-18 23:25:16 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-18 23:25:16 --> Controller Class Initialized
DEBUG - 2024-06-18 23:25:16 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_catatan_guru/views/list.php
DEBUG - 2024-06-18 23:25:16 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-06-18 23:25:16 --> Final output sent to browser
DEBUG - 2024-06-18 23:25:16 --> Total execution time: 0.0406
INFO - 2024-06-18 23:25:17 --> Config Class Initialized
INFO - 2024-06-18 23:25:17 --> Hooks Class Initialized
DEBUG - 2024-06-18 23:25:17 --> UTF-8 Support Enabled
INFO - 2024-06-18 23:25:17 --> Utf8 Class Initialized
INFO - 2024-06-18 23:25:17 --> URI Class Initialized
INFO - 2024-06-18 23:25:17 --> Router Class Initialized
INFO - 2024-06-18 23:25:17 --> Output Class Initialized
INFO - 2024-06-18 23:25:17 --> Security Class Initialized
DEBUG - 2024-06-18 23:25:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-18 23:25:17 --> Input Class Initialized
INFO - 2024-06-18 23:25:17 --> Language Class Initialized
INFO - 2024-06-18 23:25:17 --> Language Class Initialized
INFO - 2024-06-18 23:25:17 --> Config Class Initialized
INFO - 2024-06-18 23:25:17 --> Loader Class Initialized
INFO - 2024-06-18 23:25:17 --> Helper loaded: url_helper
INFO - 2024-06-18 23:25:17 --> Helper loaded: file_helper
INFO - 2024-06-18 23:25:17 --> Helper loaded: form_helper
INFO - 2024-06-18 23:25:17 --> Helper loaded: my_helper
INFO - 2024-06-18 23:25:17 --> Database Driver Class Initialized
INFO - 2024-06-18 23:25:17 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-18 23:25:17 --> Controller Class Initialized
INFO - 2024-06-18 23:25:17 --> Final output sent to browser
DEBUG - 2024-06-18 23:25:17 --> Total execution time: 0.0261
INFO - 2024-06-18 23:25:19 --> Config Class Initialized
INFO - 2024-06-18 23:25:19 --> Hooks Class Initialized
DEBUG - 2024-06-18 23:25:19 --> UTF-8 Support Enabled
INFO - 2024-06-18 23:25:19 --> Utf8 Class Initialized
INFO - 2024-06-18 23:25:19 --> URI Class Initialized
INFO - 2024-06-18 23:25:19 --> Router Class Initialized
INFO - 2024-06-18 23:25:19 --> Output Class Initialized
INFO - 2024-06-18 23:25:19 --> Security Class Initialized
DEBUG - 2024-06-18 23:25:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-18 23:25:19 --> Input Class Initialized
INFO - 2024-06-18 23:25:19 --> Language Class Initialized
INFO - 2024-06-18 23:25:19 --> Language Class Initialized
INFO - 2024-06-18 23:25:19 --> Config Class Initialized
INFO - 2024-06-18 23:25:19 --> Loader Class Initialized
INFO - 2024-06-18 23:25:19 --> Helper loaded: url_helper
INFO - 2024-06-18 23:25:19 --> Helper loaded: file_helper
INFO - 2024-06-18 23:25:19 --> Helper loaded: form_helper
INFO - 2024-06-18 23:25:19 --> Helper loaded: my_helper
INFO - 2024-06-18 23:25:19 --> Database Driver Class Initialized
INFO - 2024-06-18 23:25:19 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-18 23:25:19 --> Controller Class Initialized
DEBUG - 2024-06-18 23:25:19 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/view_mapel/views/v_view_mapel.php
DEBUG - 2024-06-18 23:25:19 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-06-18 23:25:19 --> Final output sent to browser
DEBUG - 2024-06-18 23:25:19 --> Total execution time: 0.0262
INFO - 2024-06-18 23:25:21 --> Config Class Initialized
INFO - 2024-06-18 23:25:21 --> Hooks Class Initialized
DEBUG - 2024-06-18 23:25:21 --> UTF-8 Support Enabled
INFO - 2024-06-18 23:25:21 --> Utf8 Class Initialized
INFO - 2024-06-18 23:25:21 --> URI Class Initialized
INFO - 2024-06-18 23:25:21 --> Router Class Initialized
INFO - 2024-06-18 23:25:21 --> Output Class Initialized
INFO - 2024-06-18 23:25:21 --> Security Class Initialized
DEBUG - 2024-06-18 23:25:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-18 23:25:21 --> Input Class Initialized
INFO - 2024-06-18 23:25:21 --> Language Class Initialized
INFO - 2024-06-18 23:25:21 --> Language Class Initialized
INFO - 2024-06-18 23:25:21 --> Config Class Initialized
INFO - 2024-06-18 23:25:21 --> Loader Class Initialized
INFO - 2024-06-18 23:25:21 --> Helper loaded: url_helper
INFO - 2024-06-18 23:25:21 --> Helper loaded: file_helper
INFO - 2024-06-18 23:25:21 --> Helper loaded: form_helper
INFO - 2024-06-18 23:25:21 --> Helper loaded: my_helper
INFO - 2024-06-18 23:25:21 --> Database Driver Class Initialized
INFO - 2024-06-18 23:25:21 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-18 23:25:21 --> Controller Class Initialized
DEBUG - 2024-06-18 23:25:21 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_catatan_guru/views/list.php
DEBUG - 2024-06-18 23:25:21 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-06-18 23:25:21 --> Final output sent to browser
DEBUG - 2024-06-18 23:25:21 --> Total execution time: 0.0309
INFO - 2024-06-18 23:25:22 --> Config Class Initialized
INFO - 2024-06-18 23:25:22 --> Hooks Class Initialized
DEBUG - 2024-06-18 23:25:22 --> UTF-8 Support Enabled
INFO - 2024-06-18 23:25:22 --> Utf8 Class Initialized
INFO - 2024-06-18 23:25:22 --> URI Class Initialized
INFO - 2024-06-18 23:25:22 --> Router Class Initialized
INFO - 2024-06-18 23:25:22 --> Output Class Initialized
INFO - 2024-06-18 23:25:22 --> Security Class Initialized
DEBUG - 2024-06-18 23:25:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-18 23:25:22 --> Input Class Initialized
INFO - 2024-06-18 23:25:22 --> Language Class Initialized
INFO - 2024-06-18 23:25:22 --> Language Class Initialized
INFO - 2024-06-18 23:25:22 --> Config Class Initialized
INFO - 2024-06-18 23:25:22 --> Loader Class Initialized
INFO - 2024-06-18 23:25:22 --> Helper loaded: url_helper
INFO - 2024-06-18 23:25:22 --> Helper loaded: file_helper
INFO - 2024-06-18 23:25:22 --> Helper loaded: form_helper
INFO - 2024-06-18 23:25:22 --> Helper loaded: my_helper
INFO - 2024-06-18 23:25:22 --> Database Driver Class Initialized
INFO - 2024-06-18 23:25:22 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-18 23:25:22 --> Controller Class Initialized
DEBUG - 2024-06-18 23:25:22 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/view_mapel/views/v_view_mapel.php
DEBUG - 2024-06-18 23:25:22 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-06-18 23:25:22 --> Final output sent to browser
DEBUG - 2024-06-18 23:25:22 --> Total execution time: 0.0616
INFO - 2024-06-18 23:25:24 --> Config Class Initialized
INFO - 2024-06-18 23:25:24 --> Hooks Class Initialized
DEBUG - 2024-06-18 23:25:24 --> UTF-8 Support Enabled
INFO - 2024-06-18 23:25:24 --> Utf8 Class Initialized
INFO - 2024-06-18 23:25:24 --> URI Class Initialized
INFO - 2024-06-18 23:25:24 --> Router Class Initialized
INFO - 2024-06-18 23:25:24 --> Output Class Initialized
INFO - 2024-06-18 23:25:24 --> Security Class Initialized
DEBUG - 2024-06-18 23:25:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-18 23:25:24 --> Input Class Initialized
INFO - 2024-06-18 23:25:24 --> Language Class Initialized
INFO - 2024-06-18 23:25:24 --> Language Class Initialized
INFO - 2024-06-18 23:25:24 --> Config Class Initialized
INFO - 2024-06-18 23:25:24 --> Loader Class Initialized
INFO - 2024-06-18 23:25:24 --> Helper loaded: url_helper
INFO - 2024-06-18 23:25:24 --> Helper loaded: file_helper
INFO - 2024-06-18 23:25:24 --> Helper loaded: form_helper
INFO - 2024-06-18 23:25:24 --> Helper loaded: my_helper
INFO - 2024-06-18 23:25:24 --> Database Driver Class Initialized
INFO - 2024-06-18 23:25:24 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-18 23:25:24 --> Controller Class Initialized
DEBUG - 2024-06-18 23:25:24 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/views/list.php
DEBUG - 2024-06-18 23:25:24 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-06-18 23:25:24 --> Final output sent to browser
DEBUG - 2024-06-18 23:25:24 --> Total execution time: 0.0359
INFO - 2024-06-18 23:25:24 --> Config Class Initialized
INFO - 2024-06-18 23:25:24 --> Hooks Class Initialized
DEBUG - 2024-06-18 23:25:24 --> UTF-8 Support Enabled
INFO - 2024-06-18 23:25:24 --> Utf8 Class Initialized
INFO - 2024-06-18 23:25:24 --> URI Class Initialized
INFO - 2024-06-18 23:25:24 --> Router Class Initialized
INFO - 2024-06-18 23:25:24 --> Output Class Initialized
INFO - 2024-06-18 23:25:24 --> Security Class Initialized
DEBUG - 2024-06-18 23:25:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-18 23:25:24 --> Input Class Initialized
INFO - 2024-06-18 23:25:24 --> Language Class Initialized
INFO - 2024-06-18 23:25:24 --> Language Class Initialized
INFO - 2024-06-18 23:25:24 --> Config Class Initialized
INFO - 2024-06-18 23:25:24 --> Loader Class Initialized
INFO - 2024-06-18 23:25:24 --> Helper loaded: url_helper
INFO - 2024-06-18 23:25:24 --> Helper loaded: file_helper
INFO - 2024-06-18 23:25:24 --> Helper loaded: form_helper
INFO - 2024-06-18 23:25:24 --> Helper loaded: my_helper
INFO - 2024-06-18 23:25:24 --> Database Driver Class Initialized
INFO - 2024-06-18 23:25:24 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-18 23:25:24 --> Controller Class Initialized
INFO - 2024-06-18 23:25:26 --> Config Class Initialized
INFO - 2024-06-18 23:25:26 --> Hooks Class Initialized
DEBUG - 2024-06-18 23:25:26 --> UTF-8 Support Enabled
INFO - 2024-06-18 23:25:26 --> Utf8 Class Initialized
INFO - 2024-06-18 23:25:26 --> URI Class Initialized
INFO - 2024-06-18 23:25:26 --> Router Class Initialized
INFO - 2024-06-18 23:25:26 --> Output Class Initialized
INFO - 2024-06-18 23:25:26 --> Security Class Initialized
DEBUG - 2024-06-18 23:25:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-18 23:25:26 --> Input Class Initialized
INFO - 2024-06-18 23:25:26 --> Language Class Initialized
INFO - 2024-06-18 23:25:26 --> Language Class Initialized
INFO - 2024-06-18 23:25:26 --> Config Class Initialized
INFO - 2024-06-18 23:25:26 --> Loader Class Initialized
INFO - 2024-06-18 23:25:26 --> Helper loaded: url_helper
INFO - 2024-06-18 23:25:26 --> Helper loaded: file_helper
INFO - 2024-06-18 23:25:26 --> Helper loaded: form_helper
INFO - 2024-06-18 23:25:26 --> Helper loaded: my_helper
INFO - 2024-06-18 23:25:26 --> Database Driver Class Initialized
INFO - 2024-06-18 23:25:26 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-18 23:25:26 --> Controller Class Initialized
INFO - 2024-06-18 23:25:26 --> Final output sent to browser
DEBUG - 2024-06-18 23:25:26 --> Total execution time: 0.0294
INFO - 2024-06-18 23:28:38 --> Config Class Initialized
INFO - 2024-06-18 23:28:38 --> Hooks Class Initialized
DEBUG - 2024-06-18 23:28:38 --> UTF-8 Support Enabled
INFO - 2024-06-18 23:28:38 --> Utf8 Class Initialized
INFO - 2024-06-18 23:28:38 --> URI Class Initialized
INFO - 2024-06-18 23:28:38 --> Router Class Initialized
INFO - 2024-06-18 23:28:38 --> Output Class Initialized
INFO - 2024-06-18 23:28:38 --> Security Class Initialized
DEBUG - 2024-06-18 23:28:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-18 23:28:38 --> Input Class Initialized
INFO - 2024-06-18 23:28:38 --> Language Class Initialized
INFO - 2024-06-18 23:28:38 --> Language Class Initialized
INFO - 2024-06-18 23:28:38 --> Config Class Initialized
INFO - 2024-06-18 23:28:38 --> Loader Class Initialized
INFO - 2024-06-18 23:28:38 --> Helper loaded: url_helper
INFO - 2024-06-18 23:28:38 --> Helper loaded: file_helper
INFO - 2024-06-18 23:28:38 --> Helper loaded: form_helper
INFO - 2024-06-18 23:28:38 --> Helper loaded: my_helper
INFO - 2024-06-18 23:28:38 --> Database Driver Class Initialized
INFO - 2024-06-18 23:28:38 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-18 23:28:38 --> Controller Class Initialized
INFO - 2024-06-18 23:28:38 --> Final output sent to browser
DEBUG - 2024-06-18 23:28:38 --> Total execution time: 0.1158
INFO - 2024-06-18 23:28:44 --> Config Class Initialized
INFO - 2024-06-18 23:28:44 --> Hooks Class Initialized
DEBUG - 2024-06-18 23:28:44 --> UTF-8 Support Enabled
INFO - 2024-06-18 23:28:44 --> Utf8 Class Initialized
INFO - 2024-06-18 23:28:44 --> URI Class Initialized
INFO - 2024-06-18 23:28:44 --> Router Class Initialized
INFO - 2024-06-18 23:28:44 --> Output Class Initialized
INFO - 2024-06-18 23:28:44 --> Security Class Initialized
DEBUG - 2024-06-18 23:28:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-18 23:28:44 --> Input Class Initialized
INFO - 2024-06-18 23:28:44 --> Language Class Initialized
INFO - 2024-06-18 23:28:44 --> Language Class Initialized
INFO - 2024-06-18 23:28:44 --> Config Class Initialized
INFO - 2024-06-18 23:28:44 --> Loader Class Initialized
INFO - 2024-06-18 23:28:44 --> Helper loaded: url_helper
INFO - 2024-06-18 23:28:44 --> Helper loaded: file_helper
INFO - 2024-06-18 23:28:44 --> Helper loaded: form_helper
INFO - 2024-06-18 23:28:44 --> Helper loaded: my_helper
INFO - 2024-06-18 23:28:44 --> Database Driver Class Initialized
INFO - 2024-06-18 23:28:44 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-18 23:28:44 --> Controller Class Initialized
DEBUG - 2024-06-18 23:28:44 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/view_mapel/views/v_view_mapel.php
DEBUG - 2024-06-18 23:28:44 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-06-18 23:28:44 --> Final output sent to browser
DEBUG - 2024-06-18 23:28:44 --> Total execution time: 0.0387
INFO - 2024-06-18 23:28:48 --> Config Class Initialized
INFO - 2024-06-18 23:28:48 --> Hooks Class Initialized
DEBUG - 2024-06-18 23:28:48 --> UTF-8 Support Enabled
INFO - 2024-06-18 23:28:48 --> Utf8 Class Initialized
INFO - 2024-06-18 23:28:48 --> URI Class Initialized
INFO - 2024-06-18 23:28:48 --> Router Class Initialized
INFO - 2024-06-18 23:28:48 --> Output Class Initialized
INFO - 2024-06-18 23:28:48 --> Security Class Initialized
DEBUG - 2024-06-18 23:28:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-18 23:28:48 --> Input Class Initialized
INFO - 2024-06-18 23:28:48 --> Language Class Initialized
INFO - 2024-06-18 23:28:48 --> Language Class Initialized
INFO - 2024-06-18 23:28:48 --> Config Class Initialized
INFO - 2024-06-18 23:28:48 --> Loader Class Initialized
INFO - 2024-06-18 23:28:48 --> Helper loaded: url_helper
INFO - 2024-06-18 23:28:48 --> Helper loaded: file_helper
INFO - 2024-06-18 23:28:48 --> Helper loaded: form_helper
INFO - 2024-06-18 23:28:48 --> Helper loaded: my_helper
INFO - 2024-06-18 23:28:48 --> Database Driver Class Initialized
INFO - 2024-06-18 23:28:48 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-18 23:28:48 --> Controller Class Initialized
DEBUG - 2024-06-18 23:28:48 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/views/list.php
DEBUG - 2024-06-18 23:28:48 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-06-18 23:28:48 --> Final output sent to browser
DEBUG - 2024-06-18 23:28:48 --> Total execution time: 0.0309
INFO - 2024-06-18 23:28:48 --> Config Class Initialized
INFO - 2024-06-18 23:28:48 --> Hooks Class Initialized
DEBUG - 2024-06-18 23:28:48 --> UTF-8 Support Enabled
INFO - 2024-06-18 23:28:48 --> Utf8 Class Initialized
INFO - 2024-06-18 23:28:48 --> URI Class Initialized
INFO - 2024-06-18 23:28:48 --> Router Class Initialized
INFO - 2024-06-18 23:28:48 --> Output Class Initialized
INFO - 2024-06-18 23:28:48 --> Security Class Initialized
DEBUG - 2024-06-18 23:28:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-18 23:28:48 --> Input Class Initialized
INFO - 2024-06-18 23:28:48 --> Language Class Initialized
INFO - 2024-06-18 23:28:48 --> Language Class Initialized
INFO - 2024-06-18 23:28:48 --> Config Class Initialized
INFO - 2024-06-18 23:28:48 --> Loader Class Initialized
INFO - 2024-06-18 23:28:48 --> Helper loaded: url_helper
INFO - 2024-06-18 23:28:48 --> Helper loaded: file_helper
INFO - 2024-06-18 23:28:48 --> Helper loaded: form_helper
INFO - 2024-06-18 23:28:48 --> Helper loaded: my_helper
INFO - 2024-06-18 23:28:48 --> Database Driver Class Initialized
INFO - 2024-06-18 23:28:48 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-18 23:28:48 --> Controller Class Initialized
INFO - 2024-06-18 23:28:50 --> Config Class Initialized
INFO - 2024-06-18 23:28:50 --> Hooks Class Initialized
DEBUG - 2024-06-18 23:28:50 --> UTF-8 Support Enabled
INFO - 2024-06-18 23:28:50 --> Utf8 Class Initialized
INFO - 2024-06-18 23:28:50 --> URI Class Initialized
INFO - 2024-06-18 23:28:50 --> Router Class Initialized
INFO - 2024-06-18 23:28:50 --> Output Class Initialized
INFO - 2024-06-18 23:28:50 --> Security Class Initialized
DEBUG - 2024-06-18 23:28:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-18 23:28:50 --> Input Class Initialized
INFO - 2024-06-18 23:28:50 --> Language Class Initialized
INFO - 2024-06-18 23:28:50 --> Language Class Initialized
INFO - 2024-06-18 23:28:50 --> Config Class Initialized
INFO - 2024-06-18 23:28:50 --> Loader Class Initialized
INFO - 2024-06-18 23:28:50 --> Helper loaded: url_helper
INFO - 2024-06-18 23:28:50 --> Helper loaded: file_helper
INFO - 2024-06-18 23:28:50 --> Helper loaded: form_helper
INFO - 2024-06-18 23:28:50 --> Helper loaded: my_helper
INFO - 2024-06-18 23:28:50 --> Database Driver Class Initialized
INFO - 2024-06-18 23:28:50 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-18 23:28:50 --> Controller Class Initialized
DEBUG - 2024-06-18 23:28:50 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/view_mapel/views/v_view_mapel.php
DEBUG - 2024-06-18 23:28:50 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-06-18 23:28:50 --> Final output sent to browser
DEBUG - 2024-06-18 23:28:50 --> Total execution time: 0.0275
INFO - 2024-06-18 23:28:53 --> Config Class Initialized
INFO - 2024-06-18 23:28:53 --> Hooks Class Initialized
DEBUG - 2024-06-18 23:28:53 --> UTF-8 Support Enabled
INFO - 2024-06-18 23:28:53 --> Utf8 Class Initialized
INFO - 2024-06-18 23:28:53 --> URI Class Initialized
INFO - 2024-06-18 23:28:53 --> Router Class Initialized
INFO - 2024-06-18 23:28:53 --> Output Class Initialized
INFO - 2024-06-18 23:28:53 --> Security Class Initialized
DEBUG - 2024-06-18 23:28:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-18 23:28:53 --> Input Class Initialized
INFO - 2024-06-18 23:28:53 --> Language Class Initialized
INFO - 2024-06-18 23:28:53 --> Language Class Initialized
INFO - 2024-06-18 23:28:53 --> Config Class Initialized
INFO - 2024-06-18 23:28:53 --> Loader Class Initialized
INFO - 2024-06-18 23:28:53 --> Helper loaded: url_helper
INFO - 2024-06-18 23:28:53 --> Helper loaded: file_helper
INFO - 2024-06-18 23:28:53 --> Helper loaded: form_helper
INFO - 2024-06-18 23:28:53 --> Helper loaded: my_helper
INFO - 2024-06-18 23:28:53 --> Database Driver Class Initialized
INFO - 2024-06-18 23:28:53 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-18 23:28:53 --> Controller Class Initialized
DEBUG - 2024-06-18 23:28:53 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/views/list.php
DEBUG - 2024-06-18 23:28:53 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-06-18 23:28:53 --> Final output sent to browser
DEBUG - 2024-06-18 23:28:53 --> Total execution time: 0.0266
INFO - 2024-06-18 23:28:53 --> Config Class Initialized
INFO - 2024-06-18 23:28:53 --> Hooks Class Initialized
DEBUG - 2024-06-18 23:28:53 --> UTF-8 Support Enabled
INFO - 2024-06-18 23:28:53 --> Utf8 Class Initialized
INFO - 2024-06-18 23:28:53 --> URI Class Initialized
INFO - 2024-06-18 23:28:53 --> Router Class Initialized
INFO - 2024-06-18 23:28:53 --> Output Class Initialized
INFO - 2024-06-18 23:28:53 --> Security Class Initialized
DEBUG - 2024-06-18 23:28:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-18 23:28:53 --> Input Class Initialized
INFO - 2024-06-18 23:28:53 --> Language Class Initialized
INFO - 2024-06-18 23:28:53 --> Language Class Initialized
INFO - 2024-06-18 23:28:53 --> Config Class Initialized
INFO - 2024-06-18 23:28:53 --> Loader Class Initialized
INFO - 2024-06-18 23:28:53 --> Helper loaded: url_helper
INFO - 2024-06-18 23:28:53 --> Helper loaded: file_helper
INFO - 2024-06-18 23:28:53 --> Helper loaded: form_helper
INFO - 2024-06-18 23:28:53 --> Helper loaded: my_helper
INFO - 2024-06-18 23:28:53 --> Database Driver Class Initialized
INFO - 2024-06-18 23:28:53 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-18 23:28:53 --> Controller Class Initialized
INFO - 2024-06-18 23:28:54 --> Config Class Initialized
INFO - 2024-06-18 23:28:54 --> Hooks Class Initialized
DEBUG - 2024-06-18 23:28:54 --> UTF-8 Support Enabled
INFO - 2024-06-18 23:28:54 --> Utf8 Class Initialized
INFO - 2024-06-18 23:28:54 --> URI Class Initialized
INFO - 2024-06-18 23:28:54 --> Router Class Initialized
INFO - 2024-06-18 23:28:54 --> Output Class Initialized
INFO - 2024-06-18 23:28:54 --> Security Class Initialized
DEBUG - 2024-06-18 23:28:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-18 23:28:54 --> Input Class Initialized
INFO - 2024-06-18 23:28:54 --> Language Class Initialized
INFO - 2024-06-18 23:28:54 --> Language Class Initialized
INFO - 2024-06-18 23:28:54 --> Config Class Initialized
INFO - 2024-06-18 23:28:54 --> Loader Class Initialized
INFO - 2024-06-18 23:28:54 --> Helper loaded: url_helper
INFO - 2024-06-18 23:28:54 --> Helper loaded: file_helper
INFO - 2024-06-18 23:28:54 --> Helper loaded: form_helper
INFO - 2024-06-18 23:28:54 --> Helper loaded: my_helper
INFO - 2024-06-18 23:28:54 --> Database Driver Class Initialized
INFO - 2024-06-18 23:28:54 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-18 23:28:54 --> Controller Class Initialized
INFO - 2024-06-18 23:28:54 --> Final output sent to browser
DEBUG - 2024-06-18 23:28:54 --> Total execution time: 0.0334
INFO - 2024-06-18 23:29:19 --> Config Class Initialized
INFO - 2024-06-18 23:29:19 --> Hooks Class Initialized
DEBUG - 2024-06-18 23:29:19 --> UTF-8 Support Enabled
INFO - 2024-06-18 23:29:19 --> Utf8 Class Initialized
INFO - 2024-06-18 23:29:19 --> URI Class Initialized
INFO - 2024-06-18 23:29:19 --> Router Class Initialized
INFO - 2024-06-18 23:29:19 --> Output Class Initialized
INFO - 2024-06-18 23:29:19 --> Security Class Initialized
DEBUG - 2024-06-18 23:29:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-18 23:29:19 --> Input Class Initialized
INFO - 2024-06-18 23:29:19 --> Language Class Initialized
INFO - 2024-06-18 23:29:19 --> Language Class Initialized
INFO - 2024-06-18 23:29:19 --> Config Class Initialized
INFO - 2024-06-18 23:29:19 --> Loader Class Initialized
INFO - 2024-06-18 23:29:19 --> Helper loaded: url_helper
INFO - 2024-06-18 23:29:19 --> Helper loaded: file_helper
INFO - 2024-06-18 23:29:19 --> Helper loaded: form_helper
INFO - 2024-06-18 23:29:19 --> Helper loaded: my_helper
INFO - 2024-06-18 23:29:19 --> Database Driver Class Initialized
INFO - 2024-06-18 23:29:19 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-18 23:29:19 --> Controller Class Initialized
INFO - 2024-06-18 23:29:19 --> Final output sent to browser
DEBUG - 2024-06-18 23:29:19 --> Total execution time: 0.0577
INFO - 2024-06-18 23:30:00 --> Config Class Initialized
INFO - 2024-06-18 23:30:00 --> Hooks Class Initialized
DEBUG - 2024-06-18 23:30:00 --> UTF-8 Support Enabled
INFO - 2024-06-18 23:30:00 --> Utf8 Class Initialized
INFO - 2024-06-18 23:30:00 --> URI Class Initialized
INFO - 2024-06-18 23:30:00 --> Router Class Initialized
INFO - 2024-06-18 23:30:00 --> Output Class Initialized
INFO - 2024-06-18 23:30:00 --> Security Class Initialized
DEBUG - 2024-06-18 23:30:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-18 23:30:00 --> Input Class Initialized
INFO - 2024-06-18 23:30:00 --> Language Class Initialized
INFO - 2024-06-18 23:30:00 --> Language Class Initialized
INFO - 2024-06-18 23:30:00 --> Config Class Initialized
INFO - 2024-06-18 23:30:00 --> Loader Class Initialized
INFO - 2024-06-18 23:30:00 --> Helper loaded: url_helper
INFO - 2024-06-18 23:30:00 --> Helper loaded: file_helper
INFO - 2024-06-18 23:30:00 --> Helper loaded: form_helper
INFO - 2024-06-18 23:30:00 --> Helper loaded: my_helper
INFO - 2024-06-18 23:30:00 --> Database Driver Class Initialized
INFO - 2024-06-18 23:30:00 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-18 23:30:00 --> Controller Class Initialized
DEBUG - 2024-06-18 23:30:00 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/view_mapel/views/v_view_mapel.php
DEBUG - 2024-06-18 23:30:00 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-06-18 23:30:00 --> Final output sent to browser
DEBUG - 2024-06-18 23:30:00 --> Total execution time: 0.0265
INFO - 2024-06-18 23:30:03 --> Config Class Initialized
INFO - 2024-06-18 23:30:03 --> Hooks Class Initialized
DEBUG - 2024-06-18 23:30:03 --> UTF-8 Support Enabled
INFO - 2024-06-18 23:30:03 --> Utf8 Class Initialized
INFO - 2024-06-18 23:30:03 --> URI Class Initialized
INFO - 2024-06-18 23:30:03 --> Router Class Initialized
INFO - 2024-06-18 23:30:03 --> Output Class Initialized
INFO - 2024-06-18 23:30:03 --> Security Class Initialized
DEBUG - 2024-06-18 23:30:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-18 23:30:03 --> Input Class Initialized
INFO - 2024-06-18 23:30:03 --> Language Class Initialized
INFO - 2024-06-18 23:30:03 --> Language Class Initialized
INFO - 2024-06-18 23:30:03 --> Config Class Initialized
INFO - 2024-06-18 23:30:03 --> Loader Class Initialized
INFO - 2024-06-18 23:30:03 --> Helper loaded: url_helper
INFO - 2024-06-18 23:30:03 --> Helper loaded: file_helper
INFO - 2024-06-18 23:30:03 --> Helper loaded: form_helper
INFO - 2024-06-18 23:30:03 --> Helper loaded: my_helper
INFO - 2024-06-18 23:30:03 --> Database Driver Class Initialized
INFO - 2024-06-18 23:30:03 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-18 23:30:03 --> Controller Class Initialized
DEBUG - 2024-06-18 23:30:03 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/views/list.php
DEBUG - 2024-06-18 23:30:03 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-06-18 23:30:03 --> Final output sent to browser
DEBUG - 2024-06-18 23:30:03 --> Total execution time: 0.0380
INFO - 2024-06-18 23:30:03 --> Config Class Initialized
INFO - 2024-06-18 23:30:03 --> Hooks Class Initialized
DEBUG - 2024-06-18 23:30:03 --> UTF-8 Support Enabled
INFO - 2024-06-18 23:30:03 --> Utf8 Class Initialized
INFO - 2024-06-18 23:30:03 --> URI Class Initialized
INFO - 2024-06-18 23:30:03 --> Router Class Initialized
INFO - 2024-06-18 23:30:03 --> Output Class Initialized
INFO - 2024-06-18 23:30:03 --> Security Class Initialized
DEBUG - 2024-06-18 23:30:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-18 23:30:03 --> Input Class Initialized
INFO - 2024-06-18 23:30:03 --> Language Class Initialized
INFO - 2024-06-18 23:30:03 --> Language Class Initialized
INFO - 2024-06-18 23:30:03 --> Config Class Initialized
INFO - 2024-06-18 23:30:03 --> Loader Class Initialized
INFO - 2024-06-18 23:30:03 --> Helper loaded: url_helper
INFO - 2024-06-18 23:30:03 --> Helper loaded: file_helper
INFO - 2024-06-18 23:30:03 --> Helper loaded: form_helper
INFO - 2024-06-18 23:30:03 --> Helper loaded: my_helper
INFO - 2024-06-18 23:30:03 --> Database Driver Class Initialized
INFO - 2024-06-18 23:30:03 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-18 23:30:03 --> Controller Class Initialized
INFO - 2024-06-18 23:30:04 --> Config Class Initialized
INFO - 2024-06-18 23:30:04 --> Hooks Class Initialized
DEBUG - 2024-06-18 23:30:04 --> UTF-8 Support Enabled
INFO - 2024-06-18 23:30:04 --> Utf8 Class Initialized
INFO - 2024-06-18 23:30:04 --> URI Class Initialized
INFO - 2024-06-18 23:30:04 --> Router Class Initialized
INFO - 2024-06-18 23:30:04 --> Output Class Initialized
INFO - 2024-06-18 23:30:04 --> Security Class Initialized
DEBUG - 2024-06-18 23:30:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-18 23:30:04 --> Input Class Initialized
INFO - 2024-06-18 23:30:04 --> Language Class Initialized
INFO - 2024-06-18 23:30:04 --> Language Class Initialized
INFO - 2024-06-18 23:30:04 --> Config Class Initialized
INFO - 2024-06-18 23:30:04 --> Loader Class Initialized
INFO - 2024-06-18 23:30:04 --> Helper loaded: url_helper
INFO - 2024-06-18 23:30:04 --> Helper loaded: file_helper
INFO - 2024-06-18 23:30:04 --> Helper loaded: form_helper
INFO - 2024-06-18 23:30:04 --> Helper loaded: my_helper
INFO - 2024-06-18 23:30:04 --> Database Driver Class Initialized
INFO - 2024-06-18 23:30:04 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-18 23:30:04 --> Controller Class Initialized
INFO - 2024-06-18 23:30:04 --> Final output sent to browser
DEBUG - 2024-06-18 23:30:04 --> Total execution time: 0.0719
INFO - 2024-06-18 23:30:06 --> Config Class Initialized
INFO - 2024-06-18 23:30:06 --> Hooks Class Initialized
DEBUG - 2024-06-18 23:30:06 --> UTF-8 Support Enabled
INFO - 2024-06-18 23:30:06 --> Utf8 Class Initialized
INFO - 2024-06-18 23:30:06 --> URI Class Initialized
INFO - 2024-06-18 23:30:06 --> Router Class Initialized
INFO - 2024-06-18 23:30:06 --> Output Class Initialized
INFO - 2024-06-18 23:30:06 --> Security Class Initialized
DEBUG - 2024-06-18 23:30:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-18 23:30:06 --> Input Class Initialized
INFO - 2024-06-18 23:30:06 --> Language Class Initialized
INFO - 2024-06-18 23:30:06 --> Language Class Initialized
INFO - 2024-06-18 23:30:06 --> Config Class Initialized
INFO - 2024-06-18 23:30:06 --> Loader Class Initialized
INFO - 2024-06-18 23:30:06 --> Helper loaded: url_helper
INFO - 2024-06-18 23:30:06 --> Helper loaded: file_helper
INFO - 2024-06-18 23:30:06 --> Helper loaded: form_helper
INFO - 2024-06-18 23:30:06 --> Helper loaded: my_helper
INFO - 2024-06-18 23:30:06 --> Database Driver Class Initialized
INFO - 2024-06-18 23:30:06 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-18 23:30:06 --> Controller Class Initialized
INFO - 2024-06-18 23:30:06 --> Final output sent to browser
DEBUG - 2024-06-18 23:30:06 --> Total execution time: 0.0540
INFO - 2024-06-18 23:30:11 --> Config Class Initialized
INFO - 2024-06-18 23:30:11 --> Hooks Class Initialized
DEBUG - 2024-06-18 23:30:11 --> UTF-8 Support Enabled
INFO - 2024-06-18 23:30:11 --> Utf8 Class Initialized
INFO - 2024-06-18 23:30:11 --> URI Class Initialized
INFO - 2024-06-18 23:30:11 --> Router Class Initialized
INFO - 2024-06-18 23:30:11 --> Output Class Initialized
INFO - 2024-06-18 23:30:11 --> Security Class Initialized
DEBUG - 2024-06-18 23:30:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-18 23:30:11 --> Input Class Initialized
INFO - 2024-06-18 23:30:11 --> Language Class Initialized
INFO - 2024-06-18 23:30:11 --> Language Class Initialized
INFO - 2024-06-18 23:30:11 --> Config Class Initialized
INFO - 2024-06-18 23:30:11 --> Loader Class Initialized
INFO - 2024-06-18 23:30:11 --> Helper loaded: url_helper
INFO - 2024-06-18 23:30:11 --> Helper loaded: file_helper
INFO - 2024-06-18 23:30:11 --> Helper loaded: form_helper
INFO - 2024-06-18 23:30:11 --> Helper loaded: my_helper
INFO - 2024-06-18 23:30:11 --> Database Driver Class Initialized
INFO - 2024-06-18 23:30:11 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-18 23:30:11 --> Controller Class Initialized
INFO - 2024-06-18 23:30:11 --> Final output sent to browser
DEBUG - 2024-06-18 23:30:11 --> Total execution time: 0.0261
INFO - 2024-06-18 23:31:27 --> Config Class Initialized
INFO - 2024-06-18 23:31:27 --> Hooks Class Initialized
DEBUG - 2024-06-18 23:31:27 --> UTF-8 Support Enabled
INFO - 2024-06-18 23:31:27 --> Utf8 Class Initialized
INFO - 2024-06-18 23:31:27 --> URI Class Initialized
INFO - 2024-06-18 23:31:27 --> Router Class Initialized
INFO - 2024-06-18 23:31:27 --> Output Class Initialized
INFO - 2024-06-18 23:31:27 --> Security Class Initialized
DEBUG - 2024-06-18 23:31:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-18 23:31:27 --> Input Class Initialized
INFO - 2024-06-18 23:31:27 --> Language Class Initialized
INFO - 2024-06-18 23:31:27 --> Language Class Initialized
INFO - 2024-06-18 23:31:27 --> Config Class Initialized
INFO - 2024-06-18 23:31:27 --> Loader Class Initialized
INFO - 2024-06-18 23:31:27 --> Helper loaded: url_helper
INFO - 2024-06-18 23:31:27 --> Helper loaded: file_helper
INFO - 2024-06-18 23:31:27 --> Helper loaded: form_helper
INFO - 2024-06-18 23:31:27 --> Helper loaded: my_helper
INFO - 2024-06-18 23:31:27 --> Database Driver Class Initialized
INFO - 2024-06-18 23:31:27 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-18 23:31:27 --> Controller Class Initialized
INFO - 2024-06-18 23:31:27 --> Final output sent to browser
DEBUG - 2024-06-18 23:31:27 --> Total execution time: 0.1241
INFO - 2024-06-18 23:31:30 --> Config Class Initialized
INFO - 2024-06-18 23:31:30 --> Hooks Class Initialized
DEBUG - 2024-06-18 23:31:30 --> UTF-8 Support Enabled
INFO - 2024-06-18 23:31:30 --> Utf8 Class Initialized
INFO - 2024-06-18 23:31:30 --> URI Class Initialized
INFO - 2024-06-18 23:31:30 --> Router Class Initialized
INFO - 2024-06-18 23:31:30 --> Output Class Initialized
INFO - 2024-06-18 23:31:30 --> Security Class Initialized
DEBUG - 2024-06-18 23:31:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-18 23:31:30 --> Input Class Initialized
INFO - 2024-06-18 23:31:30 --> Language Class Initialized
INFO - 2024-06-18 23:31:30 --> Language Class Initialized
INFO - 2024-06-18 23:31:30 --> Config Class Initialized
INFO - 2024-06-18 23:31:30 --> Loader Class Initialized
INFO - 2024-06-18 23:31:30 --> Helper loaded: url_helper
INFO - 2024-06-18 23:31:30 --> Helper loaded: file_helper
INFO - 2024-06-18 23:31:30 --> Helper loaded: form_helper
INFO - 2024-06-18 23:31:30 --> Helper loaded: my_helper
INFO - 2024-06-18 23:31:30 --> Database Driver Class Initialized
INFO - 2024-06-18 23:31:30 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-18 23:31:30 --> Controller Class Initialized
INFO - 2024-06-18 23:31:30 --> Final output sent to browser
DEBUG - 2024-06-18 23:31:30 --> Total execution time: 0.0339
INFO - 2024-06-18 23:31:41 --> Config Class Initialized
INFO - 2024-06-18 23:31:41 --> Hooks Class Initialized
DEBUG - 2024-06-18 23:31:41 --> UTF-8 Support Enabled
INFO - 2024-06-18 23:31:41 --> Utf8 Class Initialized
INFO - 2024-06-18 23:31:41 --> URI Class Initialized
INFO - 2024-06-18 23:31:41 --> Router Class Initialized
INFO - 2024-06-18 23:31:41 --> Output Class Initialized
INFO - 2024-06-18 23:31:41 --> Security Class Initialized
DEBUG - 2024-06-18 23:31:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-18 23:31:41 --> Input Class Initialized
INFO - 2024-06-18 23:31:41 --> Language Class Initialized
INFO - 2024-06-18 23:31:41 --> Language Class Initialized
INFO - 2024-06-18 23:31:41 --> Config Class Initialized
INFO - 2024-06-18 23:31:41 --> Loader Class Initialized
INFO - 2024-06-18 23:31:41 --> Helper loaded: url_helper
INFO - 2024-06-18 23:31:41 --> Helper loaded: file_helper
INFO - 2024-06-18 23:31:41 --> Helper loaded: form_helper
INFO - 2024-06-18 23:31:41 --> Helper loaded: my_helper
INFO - 2024-06-18 23:31:41 --> Database Driver Class Initialized
INFO - 2024-06-18 23:31:41 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-18 23:31:41 --> Controller Class Initialized
INFO - 2024-06-18 23:31:41 --> Final output sent to browser
DEBUG - 2024-06-18 23:31:41 --> Total execution time: 0.0520
INFO - 2024-06-18 23:33:04 --> Config Class Initialized
INFO - 2024-06-18 23:33:04 --> Hooks Class Initialized
DEBUG - 2024-06-18 23:33:04 --> UTF-8 Support Enabled
INFO - 2024-06-18 23:33:04 --> Utf8 Class Initialized
INFO - 2024-06-18 23:33:04 --> URI Class Initialized
INFO - 2024-06-18 23:33:04 --> Router Class Initialized
INFO - 2024-06-18 23:33:04 --> Output Class Initialized
INFO - 2024-06-18 23:33:04 --> Security Class Initialized
DEBUG - 2024-06-18 23:33:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-18 23:33:04 --> Input Class Initialized
INFO - 2024-06-18 23:33:04 --> Language Class Initialized
INFO - 2024-06-18 23:33:04 --> Language Class Initialized
INFO - 2024-06-18 23:33:04 --> Config Class Initialized
INFO - 2024-06-18 23:33:04 --> Loader Class Initialized
INFO - 2024-06-18 23:33:04 --> Helper loaded: url_helper
INFO - 2024-06-18 23:33:04 --> Helper loaded: file_helper
INFO - 2024-06-18 23:33:04 --> Helper loaded: form_helper
INFO - 2024-06-18 23:33:04 --> Helper loaded: my_helper
INFO - 2024-06-18 23:33:04 --> Database Driver Class Initialized
INFO - 2024-06-18 23:33:04 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-18 23:33:04 --> Controller Class Initialized
INFO - 2024-06-18 23:33:05 --> Final output sent to browser
DEBUG - 2024-06-18 23:33:05 --> Total execution time: 0.1173
INFO - 2024-06-18 23:33:08 --> Config Class Initialized
INFO - 2024-06-18 23:33:08 --> Hooks Class Initialized
DEBUG - 2024-06-18 23:33:08 --> UTF-8 Support Enabled
INFO - 2024-06-18 23:33:08 --> Utf8 Class Initialized
INFO - 2024-06-18 23:33:08 --> URI Class Initialized
INFO - 2024-06-18 23:33:08 --> Router Class Initialized
INFO - 2024-06-18 23:33:08 --> Output Class Initialized
INFO - 2024-06-18 23:33:08 --> Security Class Initialized
DEBUG - 2024-06-18 23:33:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-18 23:33:08 --> Input Class Initialized
INFO - 2024-06-18 23:33:08 --> Language Class Initialized
INFO - 2024-06-18 23:33:08 --> Language Class Initialized
INFO - 2024-06-18 23:33:08 --> Config Class Initialized
INFO - 2024-06-18 23:33:08 --> Loader Class Initialized
INFO - 2024-06-18 23:33:08 --> Helper loaded: url_helper
INFO - 2024-06-18 23:33:08 --> Helper loaded: file_helper
INFO - 2024-06-18 23:33:08 --> Helper loaded: form_helper
INFO - 2024-06-18 23:33:08 --> Helper loaded: my_helper
INFO - 2024-06-18 23:33:08 --> Database Driver Class Initialized
INFO - 2024-06-18 23:33:08 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-18 23:33:08 --> Controller Class Initialized
INFO - 2024-06-18 23:33:08 --> Final output sent to browser
DEBUG - 2024-06-18 23:33:08 --> Total execution time: 0.0432
INFO - 2024-06-18 23:34:39 --> Config Class Initialized
INFO - 2024-06-18 23:34:39 --> Hooks Class Initialized
DEBUG - 2024-06-18 23:34:39 --> UTF-8 Support Enabled
INFO - 2024-06-18 23:34:39 --> Utf8 Class Initialized
INFO - 2024-06-18 23:34:39 --> URI Class Initialized
INFO - 2024-06-18 23:34:39 --> Router Class Initialized
INFO - 2024-06-18 23:34:39 --> Output Class Initialized
INFO - 2024-06-18 23:34:39 --> Security Class Initialized
DEBUG - 2024-06-18 23:34:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-18 23:34:39 --> Input Class Initialized
INFO - 2024-06-18 23:34:39 --> Language Class Initialized
INFO - 2024-06-18 23:34:39 --> Language Class Initialized
INFO - 2024-06-18 23:34:39 --> Config Class Initialized
INFO - 2024-06-18 23:34:39 --> Loader Class Initialized
INFO - 2024-06-18 23:34:39 --> Helper loaded: url_helper
INFO - 2024-06-18 23:34:39 --> Helper loaded: file_helper
INFO - 2024-06-18 23:34:39 --> Helper loaded: form_helper
INFO - 2024-06-18 23:34:39 --> Helper loaded: my_helper
INFO - 2024-06-18 23:34:39 --> Database Driver Class Initialized
INFO - 2024-06-18 23:34:39 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-18 23:34:39 --> Controller Class Initialized
INFO - 2024-06-18 23:34:39 --> Final output sent to browser
DEBUG - 2024-06-18 23:34:39 --> Total execution time: 0.1068
INFO - 2024-06-18 23:34:44 --> Config Class Initialized
INFO - 2024-06-18 23:34:44 --> Hooks Class Initialized
DEBUG - 2024-06-18 23:34:44 --> UTF-8 Support Enabled
INFO - 2024-06-18 23:34:44 --> Utf8 Class Initialized
INFO - 2024-06-18 23:34:44 --> URI Class Initialized
INFO - 2024-06-18 23:34:44 --> Router Class Initialized
INFO - 2024-06-18 23:34:44 --> Output Class Initialized
INFO - 2024-06-18 23:34:44 --> Security Class Initialized
DEBUG - 2024-06-18 23:34:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-18 23:34:44 --> Input Class Initialized
INFO - 2024-06-18 23:34:44 --> Language Class Initialized
INFO - 2024-06-18 23:34:44 --> Language Class Initialized
INFO - 2024-06-18 23:34:44 --> Config Class Initialized
INFO - 2024-06-18 23:34:44 --> Loader Class Initialized
INFO - 2024-06-18 23:34:44 --> Helper loaded: url_helper
INFO - 2024-06-18 23:34:44 --> Helper loaded: file_helper
INFO - 2024-06-18 23:34:44 --> Helper loaded: form_helper
INFO - 2024-06-18 23:34:44 --> Helper loaded: my_helper
INFO - 2024-06-18 23:34:44 --> Database Driver Class Initialized
INFO - 2024-06-18 23:34:44 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-18 23:34:44 --> Controller Class Initialized
INFO - 2024-06-18 23:34:44 --> Final output sent to browser
DEBUG - 2024-06-18 23:34:44 --> Total execution time: 0.0307
INFO - 2024-06-18 23:38:03 --> Config Class Initialized
INFO - 2024-06-18 23:38:03 --> Hooks Class Initialized
DEBUG - 2024-06-18 23:38:03 --> UTF-8 Support Enabled
INFO - 2024-06-18 23:38:03 --> Utf8 Class Initialized
INFO - 2024-06-18 23:38:03 --> URI Class Initialized
INFO - 2024-06-18 23:38:03 --> Router Class Initialized
INFO - 2024-06-18 23:38:03 --> Output Class Initialized
INFO - 2024-06-18 23:38:03 --> Security Class Initialized
DEBUG - 2024-06-18 23:38:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-18 23:38:03 --> Input Class Initialized
INFO - 2024-06-18 23:38:03 --> Language Class Initialized
INFO - 2024-06-18 23:38:03 --> Language Class Initialized
INFO - 2024-06-18 23:38:03 --> Config Class Initialized
INFO - 2024-06-18 23:38:03 --> Loader Class Initialized
INFO - 2024-06-18 23:38:03 --> Helper loaded: url_helper
INFO - 2024-06-18 23:38:03 --> Helper loaded: file_helper
INFO - 2024-06-18 23:38:03 --> Helper loaded: form_helper
INFO - 2024-06-18 23:38:03 --> Helper loaded: my_helper
INFO - 2024-06-18 23:38:03 --> Database Driver Class Initialized
INFO - 2024-06-18 23:38:03 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-18 23:38:03 --> Controller Class Initialized
INFO - 2024-06-18 23:38:03 --> Final output sent to browser
DEBUG - 2024-06-18 23:38:03 --> Total execution time: 0.1137
INFO - 2024-06-18 23:38:06 --> Config Class Initialized
INFO - 2024-06-18 23:38:06 --> Hooks Class Initialized
DEBUG - 2024-06-18 23:38:06 --> UTF-8 Support Enabled
INFO - 2024-06-18 23:38:06 --> Utf8 Class Initialized
INFO - 2024-06-18 23:38:06 --> URI Class Initialized
INFO - 2024-06-18 23:38:06 --> Router Class Initialized
INFO - 2024-06-18 23:38:06 --> Output Class Initialized
INFO - 2024-06-18 23:38:06 --> Security Class Initialized
DEBUG - 2024-06-18 23:38:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-18 23:38:06 --> Input Class Initialized
INFO - 2024-06-18 23:38:06 --> Language Class Initialized
INFO - 2024-06-18 23:38:06 --> Language Class Initialized
INFO - 2024-06-18 23:38:06 --> Config Class Initialized
INFO - 2024-06-18 23:38:06 --> Loader Class Initialized
INFO - 2024-06-18 23:38:06 --> Helper loaded: url_helper
INFO - 2024-06-18 23:38:06 --> Helper loaded: file_helper
INFO - 2024-06-18 23:38:06 --> Helper loaded: form_helper
INFO - 2024-06-18 23:38:06 --> Helper loaded: my_helper
INFO - 2024-06-18 23:38:06 --> Database Driver Class Initialized
INFO - 2024-06-18 23:38:06 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-18 23:38:06 --> Controller Class Initialized
INFO - 2024-06-18 23:38:06 --> Final output sent to browser
DEBUG - 2024-06-18 23:38:06 --> Total execution time: 0.0470
INFO - 2024-06-18 23:39:50 --> Config Class Initialized
INFO - 2024-06-18 23:39:50 --> Hooks Class Initialized
DEBUG - 2024-06-18 23:39:50 --> UTF-8 Support Enabled
INFO - 2024-06-18 23:39:50 --> Utf8 Class Initialized
INFO - 2024-06-18 23:39:50 --> URI Class Initialized
INFO - 2024-06-18 23:39:50 --> Router Class Initialized
INFO - 2024-06-18 23:39:50 --> Output Class Initialized
INFO - 2024-06-18 23:39:50 --> Security Class Initialized
DEBUG - 2024-06-18 23:39:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-18 23:39:50 --> Input Class Initialized
INFO - 2024-06-18 23:39:50 --> Language Class Initialized
INFO - 2024-06-18 23:39:50 --> Language Class Initialized
INFO - 2024-06-18 23:39:50 --> Config Class Initialized
INFO - 2024-06-18 23:39:50 --> Loader Class Initialized
INFO - 2024-06-18 23:39:50 --> Helper loaded: url_helper
INFO - 2024-06-18 23:39:50 --> Helper loaded: file_helper
INFO - 2024-06-18 23:39:50 --> Helper loaded: form_helper
INFO - 2024-06-18 23:39:50 --> Helper loaded: my_helper
INFO - 2024-06-18 23:39:50 --> Database Driver Class Initialized
INFO - 2024-06-18 23:39:50 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-18 23:39:50 --> Controller Class Initialized
INFO - 2024-06-18 23:39:50 --> Final output sent to browser
DEBUG - 2024-06-18 23:39:50 --> Total execution time: 0.1102
INFO - 2024-06-18 23:39:53 --> Config Class Initialized
INFO - 2024-06-18 23:39:53 --> Hooks Class Initialized
DEBUG - 2024-06-18 23:39:53 --> UTF-8 Support Enabled
INFO - 2024-06-18 23:39:53 --> Utf8 Class Initialized
INFO - 2024-06-18 23:39:53 --> URI Class Initialized
INFO - 2024-06-18 23:39:53 --> Router Class Initialized
INFO - 2024-06-18 23:39:53 --> Output Class Initialized
INFO - 2024-06-18 23:39:53 --> Security Class Initialized
DEBUG - 2024-06-18 23:39:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-18 23:39:53 --> Input Class Initialized
INFO - 2024-06-18 23:39:53 --> Language Class Initialized
INFO - 2024-06-18 23:39:53 --> Language Class Initialized
INFO - 2024-06-18 23:39:53 --> Config Class Initialized
INFO - 2024-06-18 23:39:53 --> Loader Class Initialized
INFO - 2024-06-18 23:39:53 --> Helper loaded: url_helper
INFO - 2024-06-18 23:39:53 --> Helper loaded: file_helper
INFO - 2024-06-18 23:39:53 --> Helper loaded: form_helper
INFO - 2024-06-18 23:39:53 --> Helper loaded: my_helper
INFO - 2024-06-18 23:39:53 --> Database Driver Class Initialized
INFO - 2024-06-18 23:39:53 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-18 23:39:53 --> Controller Class Initialized
INFO - 2024-06-18 23:39:53 --> Final output sent to browser
DEBUG - 2024-06-18 23:39:53 --> Total execution time: 0.0398
INFO - 2024-06-18 23:48:30 --> Config Class Initialized
INFO - 2024-06-18 23:48:30 --> Hooks Class Initialized
DEBUG - 2024-06-18 23:48:30 --> UTF-8 Support Enabled
INFO - 2024-06-18 23:48:30 --> Utf8 Class Initialized
INFO - 2024-06-18 23:48:30 --> URI Class Initialized
INFO - 2024-06-18 23:48:30 --> Router Class Initialized
INFO - 2024-06-18 23:48:30 --> Output Class Initialized
INFO - 2024-06-18 23:48:30 --> Security Class Initialized
DEBUG - 2024-06-18 23:48:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-18 23:48:30 --> Input Class Initialized
INFO - 2024-06-18 23:48:30 --> Language Class Initialized
INFO - 2024-06-18 23:48:30 --> Language Class Initialized
INFO - 2024-06-18 23:48:30 --> Config Class Initialized
INFO - 2024-06-18 23:48:30 --> Loader Class Initialized
INFO - 2024-06-18 23:48:30 --> Helper loaded: url_helper
INFO - 2024-06-18 23:48:30 --> Helper loaded: file_helper
INFO - 2024-06-18 23:48:30 --> Helper loaded: form_helper
INFO - 2024-06-18 23:48:30 --> Helper loaded: my_helper
INFO - 2024-06-18 23:48:30 --> Database Driver Class Initialized
INFO - 2024-06-18 23:48:30 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-18 23:48:30 --> Controller Class Initialized
INFO - 2024-06-18 23:48:30 --> Final output sent to browser
DEBUG - 2024-06-18 23:48:30 --> Total execution time: 0.0705
INFO - 2024-06-18 23:51:33 --> Config Class Initialized
INFO - 2024-06-18 23:51:33 --> Hooks Class Initialized
DEBUG - 2024-06-18 23:51:33 --> UTF-8 Support Enabled
INFO - 2024-06-18 23:51:33 --> Utf8 Class Initialized
INFO - 2024-06-18 23:51:33 --> URI Class Initialized
INFO - 2024-06-18 23:51:33 --> Router Class Initialized
INFO - 2024-06-18 23:51:33 --> Output Class Initialized
INFO - 2024-06-18 23:51:33 --> Security Class Initialized
DEBUG - 2024-06-18 23:51:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-18 23:51:33 --> Input Class Initialized
INFO - 2024-06-18 23:51:33 --> Language Class Initialized
INFO - 2024-06-18 23:51:33 --> Language Class Initialized
INFO - 2024-06-18 23:51:33 --> Config Class Initialized
INFO - 2024-06-18 23:51:33 --> Loader Class Initialized
INFO - 2024-06-18 23:51:33 --> Helper loaded: url_helper
INFO - 2024-06-18 23:51:33 --> Helper loaded: file_helper
INFO - 2024-06-18 23:51:33 --> Helper loaded: form_helper
INFO - 2024-06-18 23:51:33 --> Helper loaded: my_helper
INFO - 2024-06-18 23:51:33 --> Database Driver Class Initialized
INFO - 2024-06-18 23:51:33 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-18 23:51:33 --> Controller Class Initialized
INFO - 2024-06-18 23:51:33 --> Final output sent to browser
DEBUG - 2024-06-18 23:51:33 --> Total execution time: 0.3386
INFO - 2024-06-18 23:51:35 --> Config Class Initialized
INFO - 2024-06-18 23:51:35 --> Hooks Class Initialized
DEBUG - 2024-06-18 23:51:35 --> UTF-8 Support Enabled
INFO - 2024-06-18 23:51:35 --> Utf8 Class Initialized
INFO - 2024-06-18 23:51:35 --> URI Class Initialized
INFO - 2024-06-18 23:51:35 --> Router Class Initialized
INFO - 2024-06-18 23:51:35 --> Output Class Initialized
INFO - 2024-06-18 23:51:35 --> Security Class Initialized
DEBUG - 2024-06-18 23:51:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-18 23:51:35 --> Input Class Initialized
INFO - 2024-06-18 23:51:35 --> Language Class Initialized
INFO - 2024-06-18 23:51:35 --> Language Class Initialized
INFO - 2024-06-18 23:51:35 --> Config Class Initialized
INFO - 2024-06-18 23:51:35 --> Loader Class Initialized
INFO - 2024-06-18 23:51:35 --> Helper loaded: url_helper
INFO - 2024-06-18 23:51:35 --> Helper loaded: file_helper
INFO - 2024-06-18 23:51:35 --> Helper loaded: form_helper
INFO - 2024-06-18 23:51:35 --> Helper loaded: my_helper
INFO - 2024-06-18 23:51:35 --> Database Driver Class Initialized
INFO - 2024-06-18 23:51:35 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-18 23:51:35 --> Controller Class Initialized
INFO - 2024-06-18 23:51:35 --> Final output sent to browser
DEBUG - 2024-06-18 23:51:35 --> Total execution time: 0.0371
INFO - 2024-06-18 23:52:47 --> Config Class Initialized
INFO - 2024-06-18 23:52:47 --> Hooks Class Initialized
DEBUG - 2024-06-18 23:52:47 --> UTF-8 Support Enabled
INFO - 2024-06-18 23:52:47 --> Utf8 Class Initialized
INFO - 2024-06-18 23:52:47 --> URI Class Initialized
INFO - 2024-06-18 23:52:47 --> Router Class Initialized
INFO - 2024-06-18 23:52:47 --> Output Class Initialized
INFO - 2024-06-18 23:52:47 --> Security Class Initialized
DEBUG - 2024-06-18 23:52:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-18 23:52:47 --> Input Class Initialized
INFO - 2024-06-18 23:52:47 --> Language Class Initialized
INFO - 2024-06-18 23:52:47 --> Language Class Initialized
INFO - 2024-06-18 23:52:47 --> Config Class Initialized
INFO - 2024-06-18 23:52:47 --> Loader Class Initialized
INFO - 2024-06-18 23:52:47 --> Helper loaded: url_helper
INFO - 2024-06-18 23:52:47 --> Helper loaded: file_helper
INFO - 2024-06-18 23:52:47 --> Helper loaded: form_helper
INFO - 2024-06-18 23:52:47 --> Helper loaded: my_helper
INFO - 2024-06-18 23:52:47 --> Database Driver Class Initialized
INFO - 2024-06-18 23:52:47 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-18 23:52:47 --> Controller Class Initialized
INFO - 2024-06-18 23:52:47 --> Final output sent to browser
DEBUG - 2024-06-18 23:52:47 --> Total execution time: 0.3616
INFO - 2024-06-18 23:52:50 --> Config Class Initialized
INFO - 2024-06-18 23:52:50 --> Hooks Class Initialized
DEBUG - 2024-06-18 23:52:50 --> UTF-8 Support Enabled
INFO - 2024-06-18 23:52:50 --> Utf8 Class Initialized
INFO - 2024-06-18 23:52:50 --> URI Class Initialized
INFO - 2024-06-18 23:52:50 --> Router Class Initialized
INFO - 2024-06-18 23:52:50 --> Output Class Initialized
INFO - 2024-06-18 23:52:50 --> Security Class Initialized
DEBUG - 2024-06-18 23:52:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-18 23:52:50 --> Input Class Initialized
INFO - 2024-06-18 23:52:50 --> Language Class Initialized
INFO - 2024-06-18 23:52:50 --> Language Class Initialized
INFO - 2024-06-18 23:52:50 --> Config Class Initialized
INFO - 2024-06-18 23:52:50 --> Loader Class Initialized
INFO - 2024-06-18 23:52:50 --> Helper loaded: url_helper
INFO - 2024-06-18 23:52:50 --> Helper loaded: file_helper
INFO - 2024-06-18 23:52:50 --> Helper loaded: form_helper
INFO - 2024-06-18 23:52:50 --> Helper loaded: my_helper
INFO - 2024-06-18 23:52:50 --> Database Driver Class Initialized
INFO - 2024-06-18 23:52:50 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-18 23:52:50 --> Controller Class Initialized
DEBUG - 2024-06-18 23:52:50 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/view_mapel/views/v_view_mapel.php
DEBUG - 2024-06-18 23:52:50 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-06-18 23:52:50 --> Final output sent to browser
DEBUG - 2024-06-18 23:52:50 --> Total execution time: 0.0282
INFO - 2024-06-18 23:52:54 --> Config Class Initialized
INFO - 2024-06-18 23:52:54 --> Hooks Class Initialized
DEBUG - 2024-06-18 23:52:54 --> UTF-8 Support Enabled
INFO - 2024-06-18 23:52:54 --> Utf8 Class Initialized
INFO - 2024-06-18 23:52:54 --> URI Class Initialized
INFO - 2024-06-18 23:52:54 --> Router Class Initialized
INFO - 2024-06-18 23:52:54 --> Output Class Initialized
INFO - 2024-06-18 23:52:54 --> Security Class Initialized
DEBUG - 2024-06-18 23:52:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-18 23:52:54 --> Input Class Initialized
INFO - 2024-06-18 23:52:54 --> Language Class Initialized
INFO - 2024-06-18 23:52:54 --> Language Class Initialized
INFO - 2024-06-18 23:52:54 --> Config Class Initialized
INFO - 2024-06-18 23:52:54 --> Loader Class Initialized
INFO - 2024-06-18 23:52:54 --> Helper loaded: url_helper
INFO - 2024-06-18 23:52:54 --> Helper loaded: file_helper
INFO - 2024-06-18 23:52:54 --> Helper loaded: form_helper
INFO - 2024-06-18 23:52:54 --> Helper loaded: my_helper
INFO - 2024-06-18 23:52:54 --> Database Driver Class Initialized
INFO - 2024-06-18 23:52:54 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-18 23:52:54 --> Controller Class Initialized
DEBUG - 2024-06-18 23:52:54 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_prestasi/views/list.php
DEBUG - 2024-06-18 23:52:54 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-06-18 23:52:54 --> Final output sent to browser
DEBUG - 2024-06-18 23:52:54 --> Total execution time: 0.0272
INFO - 2024-06-18 23:52:54 --> Config Class Initialized
INFO - 2024-06-18 23:52:54 --> Hooks Class Initialized
DEBUG - 2024-06-18 23:52:54 --> UTF-8 Support Enabled
INFO - 2024-06-18 23:52:54 --> Utf8 Class Initialized
INFO - 2024-06-18 23:52:54 --> URI Class Initialized
INFO - 2024-06-18 23:52:54 --> Router Class Initialized
INFO - 2024-06-18 23:52:54 --> Output Class Initialized
INFO - 2024-06-18 23:52:54 --> Security Class Initialized
DEBUG - 2024-06-18 23:52:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-18 23:52:54 --> Input Class Initialized
INFO - 2024-06-18 23:52:54 --> Language Class Initialized
ERROR - 2024-06-18 23:52:54 --> 404 Page Not Found: /index
INFO - 2024-06-18 23:52:54 --> Config Class Initialized
INFO - 2024-06-18 23:52:54 --> Hooks Class Initialized
DEBUG - 2024-06-18 23:52:54 --> UTF-8 Support Enabled
INFO - 2024-06-18 23:52:54 --> Utf8 Class Initialized
INFO - 2024-06-18 23:52:54 --> URI Class Initialized
INFO - 2024-06-18 23:52:54 --> Router Class Initialized
INFO - 2024-06-18 23:52:54 --> Output Class Initialized
INFO - 2024-06-18 23:52:54 --> Security Class Initialized
DEBUG - 2024-06-18 23:52:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-18 23:52:54 --> Input Class Initialized
INFO - 2024-06-18 23:52:54 --> Language Class Initialized
INFO - 2024-06-18 23:52:54 --> Language Class Initialized
INFO - 2024-06-18 23:52:54 --> Config Class Initialized
INFO - 2024-06-18 23:52:54 --> Loader Class Initialized
INFO - 2024-06-18 23:52:54 --> Helper loaded: url_helper
INFO - 2024-06-18 23:52:54 --> Helper loaded: file_helper
INFO - 2024-06-18 23:52:54 --> Helper loaded: form_helper
INFO - 2024-06-18 23:52:54 --> Helper loaded: my_helper
INFO - 2024-06-18 23:52:54 --> Database Driver Class Initialized
INFO - 2024-06-18 23:52:54 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-18 23:52:54 --> Controller Class Initialized
INFO - 2024-06-18 23:52:59 --> Config Class Initialized
INFO - 2024-06-18 23:52:59 --> Hooks Class Initialized
DEBUG - 2024-06-18 23:52:59 --> UTF-8 Support Enabled
INFO - 2024-06-18 23:52:59 --> Utf8 Class Initialized
INFO - 2024-06-18 23:52:59 --> URI Class Initialized
INFO - 2024-06-18 23:52:59 --> Router Class Initialized
INFO - 2024-06-18 23:52:59 --> Output Class Initialized
INFO - 2024-06-18 23:52:59 --> Security Class Initialized
DEBUG - 2024-06-18 23:52:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-18 23:52:59 --> Input Class Initialized
INFO - 2024-06-18 23:52:59 --> Language Class Initialized
INFO - 2024-06-18 23:52:59 --> Language Class Initialized
INFO - 2024-06-18 23:52:59 --> Config Class Initialized
INFO - 2024-06-18 23:52:59 --> Loader Class Initialized
INFO - 2024-06-18 23:52:59 --> Helper loaded: url_helper
INFO - 2024-06-18 23:52:59 --> Helper loaded: file_helper
INFO - 2024-06-18 23:52:59 --> Helper loaded: form_helper
INFO - 2024-06-18 23:52:59 --> Helper loaded: my_helper
INFO - 2024-06-18 23:52:59 --> Database Driver Class Initialized
INFO - 2024-06-18 23:52:59 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-18 23:52:59 --> Controller Class Initialized
DEBUG - 2024-06-18 23:52:59 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/views/list.php
DEBUG - 2024-06-18 23:52:59 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-06-18 23:52:59 --> Final output sent to browser
DEBUG - 2024-06-18 23:52:59 --> Total execution time: 0.0336
INFO - 2024-06-18 23:53:03 --> Config Class Initialized
INFO - 2024-06-18 23:53:03 --> Hooks Class Initialized
DEBUG - 2024-06-18 23:53:03 --> UTF-8 Support Enabled
INFO - 2024-06-18 23:53:03 --> Utf8 Class Initialized
INFO - 2024-06-18 23:53:03 --> URI Class Initialized
INFO - 2024-06-18 23:53:03 --> Router Class Initialized
INFO - 2024-06-18 23:53:03 --> Output Class Initialized
INFO - 2024-06-18 23:53:03 --> Security Class Initialized
DEBUG - 2024-06-18 23:53:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-18 23:53:03 --> Input Class Initialized
INFO - 2024-06-18 23:53:03 --> Language Class Initialized
INFO - 2024-06-18 23:53:03 --> Language Class Initialized
INFO - 2024-06-18 23:53:03 --> Config Class Initialized
INFO - 2024-06-18 23:53:03 --> Loader Class Initialized
INFO - 2024-06-18 23:53:03 --> Helper loaded: url_helper
INFO - 2024-06-18 23:53:03 --> Helper loaded: file_helper
INFO - 2024-06-18 23:53:03 --> Helper loaded: form_helper
INFO - 2024-06-18 23:53:03 --> Helper loaded: my_helper
INFO - 2024-06-18 23:53:03 --> Database Driver Class Initialized
INFO - 2024-06-18 23:53:03 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-18 23:53:03 --> Controller Class Initialized
DEBUG - 2024-06-18 23:53:03 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/views/cetak_ikm.php
INFO - 2024-06-18 23:53:05 --> Final output sent to browser
DEBUG - 2024-06-18 23:53:05 --> Total execution time: 1.5911
INFO - 2024-06-18 23:53:25 --> Config Class Initialized
INFO - 2024-06-18 23:53:25 --> Hooks Class Initialized
DEBUG - 2024-06-18 23:53:25 --> UTF-8 Support Enabled
INFO - 2024-06-18 23:53:25 --> Utf8 Class Initialized
INFO - 2024-06-18 23:53:25 --> URI Class Initialized
INFO - 2024-06-18 23:53:25 --> Router Class Initialized
INFO - 2024-06-18 23:53:25 --> Output Class Initialized
INFO - 2024-06-18 23:53:25 --> Security Class Initialized
DEBUG - 2024-06-18 23:53:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-18 23:53:25 --> Input Class Initialized
INFO - 2024-06-18 23:53:25 --> Language Class Initialized
INFO - 2024-06-18 23:53:25 --> Language Class Initialized
INFO - 2024-06-18 23:53:25 --> Config Class Initialized
INFO - 2024-06-18 23:53:25 --> Loader Class Initialized
INFO - 2024-06-18 23:53:25 --> Helper loaded: url_helper
INFO - 2024-06-18 23:53:25 --> Helper loaded: file_helper
INFO - 2024-06-18 23:53:25 --> Helper loaded: form_helper
INFO - 2024-06-18 23:53:25 --> Helper loaded: my_helper
INFO - 2024-06-18 23:53:25 --> Database Driver Class Initialized
INFO - 2024-06-18 23:53:26 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-18 23:53:26 --> Controller Class Initialized
ERROR - 2024-06-18 23:53:26 --> Severity: Notice --> Undefined index: projek /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1837
ERROR - 2024-06-18 23:53:26 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2024-06-18 23:53:26 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2024-06-18 23:53:26 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2024-06-18 23:53:26 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2024-06-18 23:53:26 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2024-06-18 23:53:26 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2024-06-18 23:53:26 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2024-06-18 23:53:26 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2024-06-18 23:53:26 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2024-06-18 23:53:26 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2024-06-18 23:53:26 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2024-06-18 23:53:26 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2024-06-18 23:53:26 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2024-06-18 23:53:26 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2024-06-18 23:53:26 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2024-06-18 23:53:26 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2024-06-18 23:53:26 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2024-06-18 23:53:26 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2024-06-18 23:53:26 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2024-06-18 23:53:26 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2024-06-18 23:53:26 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2024-06-18 23:53:26 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2024-06-18 23:53:26 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2024-06-18 23:53:26 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2024-06-18 23:53:26 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2024-06-18 23:53:26 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2024-06-18 23:53:26 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2024-06-18 23:53:26 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2024-06-18 23:53:26 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2024-06-18 23:53:26 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2024-06-18 23:53:26 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2024-06-18 23:53:26 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2024-06-18 23:53:26 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2024-06-18 23:53:26 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2024-06-18 23:53:26 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2024-06-18 23:53:26 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2024-06-18 23:53:26 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2024-06-18 23:53:26 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2024-06-18 23:53:26 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
DEBUG - 2024-06-18 23:53:26 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/views/cetak_projek.php
INFO - 2024-06-18 23:53:31 --> Final output sent to browser
DEBUG - 2024-06-18 23:53:31 --> Total execution time: 5.2376
INFO - 2024-06-18 23:54:09 --> Config Class Initialized
INFO - 2024-06-18 23:54:09 --> Hooks Class Initialized
DEBUG - 2024-06-18 23:54:09 --> UTF-8 Support Enabled
INFO - 2024-06-18 23:54:09 --> Utf8 Class Initialized
INFO - 2024-06-18 23:54:09 --> URI Class Initialized
INFO - 2024-06-18 23:54:09 --> Router Class Initialized
INFO - 2024-06-18 23:54:09 --> Output Class Initialized
INFO - 2024-06-18 23:54:09 --> Security Class Initialized
DEBUG - 2024-06-18 23:54:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-18 23:54:09 --> Input Class Initialized
INFO - 2024-06-18 23:54:09 --> Language Class Initialized
INFO - 2024-06-18 23:54:09 --> Language Class Initialized
INFO - 2024-06-18 23:54:09 --> Config Class Initialized
INFO - 2024-06-18 23:54:09 --> Loader Class Initialized
INFO - 2024-06-18 23:54:09 --> Helper loaded: url_helper
INFO - 2024-06-18 23:54:09 --> Helper loaded: file_helper
INFO - 2024-06-18 23:54:09 --> Helper loaded: form_helper
INFO - 2024-06-18 23:54:09 --> Helper loaded: my_helper
INFO - 2024-06-18 23:54:09 --> Database Driver Class Initialized
INFO - 2024-06-18 23:54:09 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-18 23:54:09 --> Controller Class Initialized
ERROR - 2024-06-18 23:54:09 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 3014
ERROR - 2024-06-18 23:54:09 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 3015
DEBUG - 2024-06-18 23:54:09 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/views/cetak_mh.php
INFO - 2024-06-18 23:54:13 --> Final output sent to browser
DEBUG - 2024-06-18 23:54:13 --> Total execution time: 3.9807
INFO - 2024-06-18 23:54:34 --> Config Class Initialized
INFO - 2024-06-18 23:54:34 --> Hooks Class Initialized
DEBUG - 2024-06-18 23:54:34 --> UTF-8 Support Enabled
INFO - 2024-06-18 23:54:34 --> Utf8 Class Initialized
INFO - 2024-06-18 23:54:34 --> URI Class Initialized
INFO - 2024-06-18 23:54:34 --> Router Class Initialized
INFO - 2024-06-18 23:54:34 --> Output Class Initialized
INFO - 2024-06-18 23:54:34 --> Security Class Initialized
DEBUG - 2024-06-18 23:54:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-18 23:54:34 --> Input Class Initialized
INFO - 2024-06-18 23:54:34 --> Language Class Initialized
INFO - 2024-06-18 23:54:34 --> Language Class Initialized
INFO - 2024-06-18 23:54:34 --> Config Class Initialized
INFO - 2024-06-18 23:54:34 --> Loader Class Initialized
INFO - 2024-06-18 23:54:34 --> Helper loaded: url_helper
INFO - 2024-06-18 23:54:34 --> Helper loaded: file_helper
INFO - 2024-06-18 23:54:34 --> Helper loaded: form_helper
INFO - 2024-06-18 23:54:34 --> Helper loaded: my_helper
INFO - 2024-06-18 23:54:34 --> Database Driver Class Initialized
INFO - 2024-06-18 23:54:34 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-18 23:54:34 --> Controller Class Initialized
DEBUG - 2024-06-18 23:54:34 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/views/cetak_tahfiz.php
INFO - 2024-06-18 23:54:38 --> Final output sent to browser
DEBUG - 2024-06-18 23:54:38 --> Total execution time: 3.2441
INFO - 2024-06-18 23:55:00 --> Config Class Initialized
INFO - 2024-06-18 23:55:00 --> Hooks Class Initialized
DEBUG - 2024-06-18 23:55:00 --> UTF-8 Support Enabled
INFO - 2024-06-18 23:55:00 --> Utf8 Class Initialized
INFO - 2024-06-18 23:55:00 --> URI Class Initialized
INFO - 2024-06-18 23:55:00 --> Router Class Initialized
INFO - 2024-06-18 23:55:00 --> Output Class Initialized
INFO - 2024-06-18 23:55:00 --> Security Class Initialized
DEBUG - 2024-06-18 23:55:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-18 23:55:00 --> Input Class Initialized
INFO - 2024-06-18 23:55:00 --> Language Class Initialized
INFO - 2024-06-18 23:55:00 --> Language Class Initialized
INFO - 2024-06-18 23:55:00 --> Config Class Initialized
INFO - 2024-06-18 23:55:00 --> Loader Class Initialized
INFO - 2024-06-18 23:55:00 --> Helper loaded: url_helper
INFO - 2024-06-18 23:55:00 --> Helper loaded: file_helper
INFO - 2024-06-18 23:55:00 --> Helper loaded: form_helper
INFO - 2024-06-18 23:55:00 --> Helper loaded: my_helper
INFO - 2024-06-18 23:55:00 --> Database Driver Class Initialized
INFO - 2024-06-18 23:55:00 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-18 23:55:00 --> Controller Class Initialized
DEBUG - 2024-06-18 23:55:00 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/view_mapel/views/v_view_mapel.php
DEBUG - 2024-06-18 23:55:00 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-06-18 23:55:00 --> Final output sent to browser
DEBUG - 2024-06-18 23:55:00 --> Total execution time: 0.0285
INFO - 2024-06-18 23:55:02 --> Config Class Initialized
INFO - 2024-06-18 23:55:02 --> Hooks Class Initialized
DEBUG - 2024-06-18 23:55:02 --> UTF-8 Support Enabled
INFO - 2024-06-18 23:55:02 --> Utf8 Class Initialized
INFO - 2024-06-18 23:55:02 --> URI Class Initialized
INFO - 2024-06-18 23:55:02 --> Router Class Initialized
INFO - 2024-06-18 23:55:02 --> Output Class Initialized
INFO - 2024-06-18 23:55:02 --> Security Class Initialized
DEBUG - 2024-06-18 23:55:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-18 23:55:02 --> Input Class Initialized
INFO - 2024-06-18 23:55:02 --> Language Class Initialized
INFO - 2024-06-18 23:55:02 --> Language Class Initialized
INFO - 2024-06-18 23:55:02 --> Config Class Initialized
INFO - 2024-06-18 23:55:02 --> Loader Class Initialized
INFO - 2024-06-18 23:55:02 --> Helper loaded: url_helper
INFO - 2024-06-18 23:55:02 --> Helper loaded: file_helper
INFO - 2024-06-18 23:55:02 --> Helper loaded: form_helper
INFO - 2024-06-18 23:55:02 --> Helper loaded: my_helper
INFO - 2024-06-18 23:55:02 --> Database Driver Class Initialized
INFO - 2024-06-18 23:55:02 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-18 23:55:02 --> Controller Class Initialized
DEBUG - 2024-06-18 23:55:02 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/views/list.php
DEBUG - 2024-06-18 23:55:02 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-06-18 23:55:02 --> Final output sent to browser
DEBUG - 2024-06-18 23:55:02 --> Total execution time: 0.0312
INFO - 2024-06-18 23:55:02 --> Config Class Initialized
INFO - 2024-06-18 23:55:02 --> Hooks Class Initialized
DEBUG - 2024-06-18 23:55:02 --> UTF-8 Support Enabled
INFO - 2024-06-18 23:55:02 --> Utf8 Class Initialized
INFO - 2024-06-18 23:55:02 --> URI Class Initialized
INFO - 2024-06-18 23:55:02 --> Router Class Initialized
INFO - 2024-06-18 23:55:02 --> Output Class Initialized
INFO - 2024-06-18 23:55:02 --> Security Class Initialized
DEBUG - 2024-06-18 23:55:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-18 23:55:02 --> Input Class Initialized
INFO - 2024-06-18 23:55:02 --> Language Class Initialized
INFO - 2024-06-18 23:55:02 --> Language Class Initialized
INFO - 2024-06-18 23:55:02 --> Config Class Initialized
INFO - 2024-06-18 23:55:02 --> Loader Class Initialized
INFO - 2024-06-18 23:55:02 --> Helper loaded: url_helper
INFO - 2024-06-18 23:55:02 --> Helper loaded: file_helper
INFO - 2024-06-18 23:55:02 --> Helper loaded: form_helper
INFO - 2024-06-18 23:55:02 --> Helper loaded: my_helper
INFO - 2024-06-18 23:55:02 --> Database Driver Class Initialized
INFO - 2024-06-18 23:55:02 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-18 23:55:02 --> Controller Class Initialized
INFO - 2024-06-18 23:55:04 --> Config Class Initialized
INFO - 2024-06-18 23:55:04 --> Hooks Class Initialized
DEBUG - 2024-06-18 23:55:04 --> UTF-8 Support Enabled
INFO - 2024-06-18 23:55:04 --> Utf8 Class Initialized
INFO - 2024-06-18 23:55:04 --> URI Class Initialized
INFO - 2024-06-18 23:55:04 --> Router Class Initialized
INFO - 2024-06-18 23:55:04 --> Output Class Initialized
INFO - 2024-06-18 23:55:04 --> Security Class Initialized
DEBUG - 2024-06-18 23:55:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-18 23:55:04 --> Input Class Initialized
INFO - 2024-06-18 23:55:04 --> Language Class Initialized
INFO - 2024-06-18 23:55:04 --> Language Class Initialized
INFO - 2024-06-18 23:55:04 --> Config Class Initialized
INFO - 2024-06-18 23:55:04 --> Loader Class Initialized
INFO - 2024-06-18 23:55:04 --> Helper loaded: url_helper
INFO - 2024-06-18 23:55:04 --> Helper loaded: file_helper
INFO - 2024-06-18 23:55:04 --> Helper loaded: form_helper
INFO - 2024-06-18 23:55:04 --> Helper loaded: my_helper
INFO - 2024-06-18 23:55:04 --> Database Driver Class Initialized
INFO - 2024-06-18 23:55:04 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-18 23:55:04 --> Controller Class Initialized
INFO - 2024-06-18 23:55:04 --> Final output sent to browser
DEBUG - 2024-06-18 23:55:04 --> Total execution time: 0.0352
INFO - 2024-06-18 23:55:16 --> Config Class Initialized
INFO - 2024-06-18 23:55:16 --> Hooks Class Initialized
DEBUG - 2024-06-18 23:55:16 --> UTF-8 Support Enabled
INFO - 2024-06-18 23:55:16 --> Utf8 Class Initialized
INFO - 2024-06-18 23:55:16 --> URI Class Initialized
INFO - 2024-06-18 23:55:16 --> Router Class Initialized
INFO - 2024-06-18 23:55:16 --> Output Class Initialized
INFO - 2024-06-18 23:55:16 --> Security Class Initialized
DEBUG - 2024-06-18 23:55:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-18 23:55:16 --> Input Class Initialized
INFO - 2024-06-18 23:55:16 --> Language Class Initialized
INFO - 2024-06-18 23:55:16 --> Language Class Initialized
INFO - 2024-06-18 23:55:16 --> Config Class Initialized
INFO - 2024-06-18 23:55:16 --> Loader Class Initialized
INFO - 2024-06-18 23:55:16 --> Helper loaded: url_helper
INFO - 2024-06-18 23:55:16 --> Helper loaded: file_helper
INFO - 2024-06-18 23:55:16 --> Helper loaded: form_helper
INFO - 2024-06-18 23:55:16 --> Helper loaded: my_helper
INFO - 2024-06-18 23:55:16 --> Database Driver Class Initialized
INFO - 2024-06-18 23:55:16 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-18 23:55:16 --> Controller Class Initialized
INFO - 2024-06-18 23:55:16 --> Final output sent to browser
DEBUG - 2024-06-18 23:55:16 --> Total execution time: 0.1016
INFO - 2024-06-18 23:55:20 --> Config Class Initialized
INFO - 2024-06-18 23:55:20 --> Hooks Class Initialized
DEBUG - 2024-06-18 23:55:20 --> UTF-8 Support Enabled
INFO - 2024-06-18 23:55:20 --> Utf8 Class Initialized
INFO - 2024-06-18 23:55:20 --> URI Class Initialized
INFO - 2024-06-18 23:55:20 --> Router Class Initialized
INFO - 2024-06-18 23:55:20 --> Output Class Initialized
INFO - 2024-06-18 23:55:20 --> Security Class Initialized
DEBUG - 2024-06-18 23:55:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-18 23:55:20 --> Input Class Initialized
INFO - 2024-06-18 23:55:20 --> Language Class Initialized
INFO - 2024-06-18 23:55:20 --> Language Class Initialized
INFO - 2024-06-18 23:55:20 --> Config Class Initialized
INFO - 2024-06-18 23:55:20 --> Loader Class Initialized
INFO - 2024-06-18 23:55:20 --> Helper loaded: url_helper
INFO - 2024-06-18 23:55:20 --> Helper loaded: file_helper
INFO - 2024-06-18 23:55:20 --> Helper loaded: form_helper
INFO - 2024-06-18 23:55:20 --> Helper loaded: my_helper
INFO - 2024-06-18 23:55:20 --> Database Driver Class Initialized
INFO - 2024-06-18 23:55:20 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-18 23:55:20 --> Controller Class Initialized
DEBUG - 2024-06-18 23:55:20 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/view_mapel/views/v_view_mapel.php
DEBUG - 2024-06-18 23:55:20 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-06-18 23:55:20 --> Final output sent to browser
DEBUG - 2024-06-18 23:55:20 --> Total execution time: 0.0261
INFO - 2024-06-18 23:55:24 --> Config Class Initialized
INFO - 2024-06-18 23:55:24 --> Hooks Class Initialized
DEBUG - 2024-06-18 23:55:24 --> UTF-8 Support Enabled
INFO - 2024-06-18 23:55:24 --> Utf8 Class Initialized
INFO - 2024-06-18 23:55:24 --> URI Class Initialized
INFO - 2024-06-18 23:55:24 --> Router Class Initialized
INFO - 2024-06-18 23:55:24 --> Output Class Initialized
INFO - 2024-06-18 23:55:24 --> Security Class Initialized
DEBUG - 2024-06-18 23:55:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-18 23:55:24 --> Input Class Initialized
INFO - 2024-06-18 23:55:24 --> Language Class Initialized
INFO - 2024-06-18 23:55:24 --> Language Class Initialized
INFO - 2024-06-18 23:55:24 --> Config Class Initialized
INFO - 2024-06-18 23:55:24 --> Loader Class Initialized
INFO - 2024-06-18 23:55:24 --> Helper loaded: url_helper
INFO - 2024-06-18 23:55:24 --> Helper loaded: file_helper
INFO - 2024-06-18 23:55:24 --> Helper loaded: form_helper
INFO - 2024-06-18 23:55:24 --> Helper loaded: my_helper
INFO - 2024-06-18 23:55:24 --> Database Driver Class Initialized
INFO - 2024-06-18 23:55:24 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-18 23:55:24 --> Controller Class Initialized
DEBUG - 2024-06-18 23:55:24 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/views/list.php
DEBUG - 2024-06-18 23:55:24 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-06-18 23:55:24 --> Final output sent to browser
DEBUG - 2024-06-18 23:55:24 --> Total execution time: 0.0397
INFO - 2024-06-18 23:55:25 --> Config Class Initialized
INFO - 2024-06-18 23:55:25 --> Hooks Class Initialized
DEBUG - 2024-06-18 23:55:25 --> UTF-8 Support Enabled
INFO - 2024-06-18 23:55:25 --> Utf8 Class Initialized
INFO - 2024-06-18 23:55:25 --> URI Class Initialized
INFO - 2024-06-18 23:55:25 --> Router Class Initialized
INFO - 2024-06-18 23:55:25 --> Output Class Initialized
INFO - 2024-06-18 23:55:25 --> Security Class Initialized
DEBUG - 2024-06-18 23:55:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-18 23:55:25 --> Input Class Initialized
INFO - 2024-06-18 23:55:25 --> Language Class Initialized
INFO - 2024-06-18 23:55:25 --> Language Class Initialized
INFO - 2024-06-18 23:55:25 --> Config Class Initialized
INFO - 2024-06-18 23:55:25 --> Loader Class Initialized
INFO - 2024-06-18 23:55:25 --> Helper loaded: url_helper
INFO - 2024-06-18 23:55:25 --> Helper loaded: file_helper
INFO - 2024-06-18 23:55:25 --> Helper loaded: form_helper
INFO - 2024-06-18 23:55:25 --> Helper loaded: my_helper
INFO - 2024-06-18 23:55:25 --> Database Driver Class Initialized
INFO - 2024-06-18 23:55:25 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-18 23:55:25 --> Controller Class Initialized
DEBUG - 2024-06-18 23:55:25 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/views/cetak_tahfiz.php
INFO - 2024-06-18 23:55:29 --> Final output sent to browser
DEBUG - 2024-06-18 23:55:29 --> Total execution time: 3.5897
INFO - 2024-06-18 23:55:56 --> Config Class Initialized
INFO - 2024-06-18 23:55:56 --> Hooks Class Initialized
DEBUG - 2024-06-18 23:55:56 --> UTF-8 Support Enabled
INFO - 2024-06-18 23:55:56 --> Utf8 Class Initialized
INFO - 2024-06-18 23:55:56 --> URI Class Initialized
INFO - 2024-06-18 23:55:56 --> Router Class Initialized
INFO - 2024-06-18 23:55:56 --> Output Class Initialized
INFO - 2024-06-18 23:55:56 --> Security Class Initialized
DEBUG - 2024-06-18 23:55:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-18 23:55:56 --> Input Class Initialized
INFO - 2024-06-18 23:55:56 --> Language Class Initialized
INFO - 2024-06-18 23:55:56 --> Language Class Initialized
INFO - 2024-06-18 23:55:56 --> Config Class Initialized
INFO - 2024-06-18 23:55:56 --> Loader Class Initialized
INFO - 2024-06-18 23:55:56 --> Helper loaded: url_helper
INFO - 2024-06-18 23:55:56 --> Helper loaded: file_helper
INFO - 2024-06-18 23:55:56 --> Helper loaded: form_helper
INFO - 2024-06-18 23:55:56 --> Helper loaded: my_helper
INFO - 2024-06-18 23:55:56 --> Database Driver Class Initialized
INFO - 2024-06-18 23:55:56 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-18 23:55:56 --> Controller Class Initialized
DEBUG - 2024-06-18 23:55:56 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/views/cetak_tahfiz.php
INFO - 2024-06-18 23:56:00 --> Final output sent to browser
DEBUG - 2024-06-18 23:56:00 --> Total execution time: 4.4894
INFO - 2024-06-18 23:57:03 --> Config Class Initialized
INFO - 2024-06-18 23:57:03 --> Hooks Class Initialized
DEBUG - 2024-06-18 23:57:03 --> UTF-8 Support Enabled
INFO - 2024-06-18 23:57:03 --> Utf8 Class Initialized
INFO - 2024-06-18 23:57:03 --> URI Class Initialized
INFO - 2024-06-18 23:57:03 --> Router Class Initialized
INFO - 2024-06-18 23:57:03 --> Output Class Initialized
INFO - 2024-06-18 23:57:03 --> Security Class Initialized
DEBUG - 2024-06-18 23:57:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-18 23:57:03 --> Input Class Initialized
INFO - 2024-06-18 23:57:03 --> Language Class Initialized
INFO - 2024-06-18 23:57:03 --> Language Class Initialized
INFO - 2024-06-18 23:57:03 --> Config Class Initialized
INFO - 2024-06-18 23:57:03 --> Loader Class Initialized
INFO - 2024-06-18 23:57:03 --> Helper loaded: url_helper
INFO - 2024-06-18 23:57:03 --> Helper loaded: file_helper
INFO - 2024-06-18 23:57:03 --> Helper loaded: form_helper
INFO - 2024-06-18 23:57:03 --> Helper loaded: my_helper
INFO - 2024-06-18 23:57:03 --> Database Driver Class Initialized
INFO - 2024-06-18 23:57:03 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-18 23:57:03 --> Controller Class Initialized
DEBUG - 2024-06-18 23:57:03 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/login/views/login.php
DEBUG - 2024-06-18 23:57:03 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-06-18 23:57:03 --> Final output sent to browser
DEBUG - 2024-06-18 23:57:03 --> Total execution time: 0.0343
INFO - 2024-06-18 23:57:09 --> Config Class Initialized
INFO - 2024-06-18 23:57:09 --> Hooks Class Initialized
DEBUG - 2024-06-18 23:57:09 --> UTF-8 Support Enabled
INFO - 2024-06-18 23:57:09 --> Utf8 Class Initialized
INFO - 2024-06-18 23:57:09 --> URI Class Initialized
INFO - 2024-06-18 23:57:09 --> Router Class Initialized
INFO - 2024-06-18 23:57:09 --> Output Class Initialized
INFO - 2024-06-18 23:57:09 --> Security Class Initialized
DEBUG - 2024-06-18 23:57:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-18 23:57:09 --> Input Class Initialized
INFO - 2024-06-18 23:57:09 --> Language Class Initialized
INFO - 2024-06-18 23:57:09 --> Language Class Initialized
INFO - 2024-06-18 23:57:09 --> Config Class Initialized
INFO - 2024-06-18 23:57:09 --> Loader Class Initialized
INFO - 2024-06-18 23:57:09 --> Helper loaded: url_helper
INFO - 2024-06-18 23:57:09 --> Helper loaded: file_helper
INFO - 2024-06-18 23:57:09 --> Helper loaded: form_helper
INFO - 2024-06-18 23:57:09 --> Helper loaded: my_helper
INFO - 2024-06-18 23:57:09 --> Database Driver Class Initialized
INFO - 2024-06-18 23:57:09 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-18 23:57:09 --> Controller Class Initialized
INFO - 2024-06-18 23:57:09 --> Helper loaded: cookie_helper
INFO - 2024-06-18 23:57:09 --> Final output sent to browser
DEBUG - 2024-06-18 23:57:09 --> Total execution time: 0.0352
INFO - 2024-06-18 23:57:09 --> Config Class Initialized
INFO - 2024-06-18 23:57:09 --> Hooks Class Initialized
DEBUG - 2024-06-18 23:57:09 --> UTF-8 Support Enabled
INFO - 2024-06-18 23:57:09 --> Utf8 Class Initialized
INFO - 2024-06-18 23:57:09 --> URI Class Initialized
INFO - 2024-06-18 23:57:09 --> Router Class Initialized
INFO - 2024-06-18 23:57:09 --> Output Class Initialized
INFO - 2024-06-18 23:57:09 --> Security Class Initialized
DEBUG - 2024-06-18 23:57:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-18 23:57:09 --> Input Class Initialized
INFO - 2024-06-18 23:57:09 --> Language Class Initialized
INFO - 2024-06-18 23:57:09 --> Language Class Initialized
INFO - 2024-06-18 23:57:09 --> Config Class Initialized
INFO - 2024-06-18 23:57:09 --> Loader Class Initialized
INFO - 2024-06-18 23:57:09 --> Helper loaded: url_helper
INFO - 2024-06-18 23:57:09 --> Helper loaded: file_helper
INFO - 2024-06-18 23:57:09 --> Helper loaded: form_helper
INFO - 2024-06-18 23:57:09 --> Helper loaded: my_helper
INFO - 2024-06-18 23:57:09 --> Database Driver Class Initialized
INFO - 2024-06-18 23:57:09 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-18 23:57:09 --> Controller Class Initialized
DEBUG - 2024-06-18 23:57:09 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/home/views/v_home_guru.php
DEBUG - 2024-06-18 23:57:09 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-06-18 23:57:09 --> Final output sent to browser
DEBUG - 2024-06-18 23:57:09 --> Total execution time: 0.0306
INFO - 2024-06-18 23:57:14 --> Config Class Initialized
INFO - 2024-06-18 23:57:14 --> Hooks Class Initialized
DEBUG - 2024-06-18 23:57:14 --> UTF-8 Support Enabled
INFO - 2024-06-18 23:57:14 --> Utf8 Class Initialized
INFO - 2024-06-18 23:57:14 --> URI Class Initialized
INFO - 2024-06-18 23:57:14 --> Router Class Initialized
INFO - 2024-06-18 23:57:14 --> Output Class Initialized
INFO - 2024-06-18 23:57:14 --> Security Class Initialized
DEBUG - 2024-06-18 23:57:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-18 23:57:14 --> Input Class Initialized
INFO - 2024-06-18 23:57:14 --> Language Class Initialized
INFO - 2024-06-18 23:57:14 --> Language Class Initialized
INFO - 2024-06-18 23:57:14 --> Config Class Initialized
INFO - 2024-06-18 23:57:14 --> Loader Class Initialized
INFO - 2024-06-18 23:57:14 --> Helper loaded: url_helper
INFO - 2024-06-18 23:57:14 --> Helper loaded: file_helper
INFO - 2024-06-18 23:57:14 --> Helper loaded: form_helper
INFO - 2024-06-18 23:57:14 --> Helper loaded: my_helper
INFO - 2024-06-18 23:57:14 --> Database Driver Class Initialized
INFO - 2024-06-18 23:57:14 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-18 23:57:14 --> Controller Class Initialized
DEBUG - 2024-06-18 23:57:14 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/views/list.php
DEBUG - 2024-06-18 23:57:14 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-06-18 23:57:14 --> Final output sent to browser
DEBUG - 2024-06-18 23:57:14 --> Total execution time: 0.0310
INFO - 2024-06-18 23:57:19 --> Config Class Initialized
INFO - 2024-06-18 23:57:19 --> Hooks Class Initialized
DEBUG - 2024-06-18 23:57:19 --> UTF-8 Support Enabled
INFO - 2024-06-18 23:57:19 --> Utf8 Class Initialized
INFO - 2024-06-18 23:57:19 --> URI Class Initialized
INFO - 2024-06-18 23:57:19 --> Router Class Initialized
INFO - 2024-06-18 23:57:19 --> Output Class Initialized
INFO - 2024-06-18 23:57:19 --> Security Class Initialized
DEBUG - 2024-06-18 23:57:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-18 23:57:19 --> Input Class Initialized
INFO - 2024-06-18 23:57:19 --> Language Class Initialized
INFO - 2024-06-18 23:57:19 --> Language Class Initialized
INFO - 2024-06-18 23:57:19 --> Config Class Initialized
INFO - 2024-06-18 23:57:19 --> Loader Class Initialized
INFO - 2024-06-18 23:57:19 --> Helper loaded: url_helper
INFO - 2024-06-18 23:57:19 --> Helper loaded: file_helper
INFO - 2024-06-18 23:57:19 --> Helper loaded: form_helper
INFO - 2024-06-18 23:57:19 --> Helper loaded: my_helper
INFO - 2024-06-18 23:57:19 --> Database Driver Class Initialized
INFO - 2024-06-18 23:57:19 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-18 23:57:19 --> Controller Class Initialized
DEBUG - 2024-06-18 23:57:19 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/views/cetak_tahfiz.php
INFO - 2024-06-18 23:57:23 --> Final output sent to browser
DEBUG - 2024-06-18 23:57:23 --> Total execution time: 3.8840
