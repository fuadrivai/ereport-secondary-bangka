<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2023-12-01 09:14:21 --> Config Class Initialized
INFO - 2023-12-01 09:14:21 --> Hooks Class Initialized
DEBUG - 2023-12-01 09:14:21 --> UTF-8 Support Enabled
INFO - 2023-12-01 09:14:21 --> Utf8 Class Initialized
INFO - 2023-12-01 09:14:21 --> URI Class Initialized
INFO - 2023-12-01 09:14:21 --> Router Class Initialized
INFO - 2023-12-01 09:14:21 --> Output Class Initialized
INFO - 2023-12-01 09:14:21 --> Security Class Initialized
DEBUG - 2023-12-01 09:14:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-01 09:14:21 --> Input Class Initialized
INFO - 2023-12-01 09:14:21 --> Language Class Initialized
INFO - 2023-12-01 09:14:21 --> Language Class Initialized
INFO - 2023-12-01 09:14:21 --> Config Class Initialized
INFO - 2023-12-01 09:14:21 --> Loader Class Initialized
INFO - 2023-12-01 09:14:21 --> Helper loaded: url_helper
INFO - 2023-12-01 09:14:21 --> Helper loaded: file_helper
INFO - 2023-12-01 09:14:21 --> Helper loaded: form_helper
INFO - 2023-12-01 09:14:21 --> Helper loaded: my_helper
INFO - 2023-12-01 09:14:21 --> Database Driver Class Initialized
INFO - 2023-12-01 09:14:21 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-01 09:14:21 --> Controller Class Initialized
DEBUG - 2023-12-01 09:14:21 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/views/list.php
DEBUG - 2023-12-01 09:14:21 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-12-01 09:14:21 --> Final output sent to browser
DEBUG - 2023-12-01 09:14:21 --> Total execution time: 0.1173
INFO - 2023-12-01 09:14:21 --> Config Class Initialized
INFO - 2023-12-01 09:14:21 --> Hooks Class Initialized
DEBUG - 2023-12-01 09:14:21 --> UTF-8 Support Enabled
INFO - 2023-12-01 09:14:21 --> Utf8 Class Initialized
INFO - 2023-12-01 09:14:21 --> URI Class Initialized
INFO - 2023-12-01 09:14:21 --> Router Class Initialized
INFO - 2023-12-01 09:14:21 --> Output Class Initialized
INFO - 2023-12-01 09:14:21 --> Security Class Initialized
DEBUG - 2023-12-01 09:14:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-01 09:14:21 --> Input Class Initialized
INFO - 2023-12-01 09:14:21 --> Language Class Initialized
INFO - 2023-12-01 09:14:21 --> Language Class Initialized
INFO - 2023-12-01 09:14:21 --> Config Class Initialized
INFO - 2023-12-01 09:14:21 --> Loader Class Initialized
INFO - 2023-12-01 09:14:21 --> Helper loaded: url_helper
INFO - 2023-12-01 09:14:21 --> Helper loaded: file_helper
INFO - 2023-12-01 09:14:21 --> Helper loaded: form_helper
INFO - 2023-12-01 09:14:21 --> Helper loaded: my_helper
INFO - 2023-12-01 09:14:21 --> Database Driver Class Initialized
INFO - 2023-12-01 09:14:21 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-01 09:14:21 --> Controller Class Initialized
INFO - 2023-12-01 09:14:28 --> Config Class Initialized
INFO - 2023-12-01 09:14:28 --> Hooks Class Initialized
DEBUG - 2023-12-01 09:14:28 --> UTF-8 Support Enabled
INFO - 2023-12-01 09:14:28 --> Utf8 Class Initialized
INFO - 2023-12-01 09:14:28 --> URI Class Initialized
INFO - 2023-12-01 09:14:28 --> Router Class Initialized
INFO - 2023-12-01 09:14:28 --> Output Class Initialized
INFO - 2023-12-01 09:14:28 --> Security Class Initialized
DEBUG - 2023-12-01 09:14:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-01 09:14:28 --> Input Class Initialized
INFO - 2023-12-01 09:14:28 --> Language Class Initialized
INFO - 2023-12-01 09:14:28 --> Language Class Initialized
INFO - 2023-12-01 09:14:28 --> Config Class Initialized
INFO - 2023-12-01 09:14:28 --> Loader Class Initialized
INFO - 2023-12-01 09:14:28 --> Helper loaded: url_helper
INFO - 2023-12-01 09:14:28 --> Helper loaded: file_helper
INFO - 2023-12-01 09:14:28 --> Helper loaded: form_helper
INFO - 2023-12-01 09:14:28 --> Helper loaded: my_helper
INFO - 2023-12-01 09:14:28 --> Database Driver Class Initialized
INFO - 2023-12-01 09:14:28 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-01 09:14:28 --> Controller Class Initialized
INFO - 2023-12-01 09:14:28 --> Final output sent to browser
DEBUG - 2023-12-01 09:14:28 --> Total execution time: 0.1242
INFO - 2023-12-01 09:14:36 --> Config Class Initialized
INFO - 2023-12-01 09:14:36 --> Hooks Class Initialized
DEBUG - 2023-12-01 09:14:36 --> UTF-8 Support Enabled
INFO - 2023-12-01 09:14:36 --> Utf8 Class Initialized
INFO - 2023-12-01 09:14:36 --> URI Class Initialized
INFO - 2023-12-01 09:14:36 --> Router Class Initialized
INFO - 2023-12-01 09:14:36 --> Output Class Initialized
INFO - 2023-12-01 09:14:36 --> Security Class Initialized
DEBUG - 2023-12-01 09:14:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-01 09:14:36 --> Input Class Initialized
INFO - 2023-12-01 09:14:36 --> Language Class Initialized
INFO - 2023-12-01 09:14:36 --> Language Class Initialized
INFO - 2023-12-01 09:14:36 --> Config Class Initialized
INFO - 2023-12-01 09:14:36 --> Loader Class Initialized
INFO - 2023-12-01 09:14:36 --> Helper loaded: url_helper
INFO - 2023-12-01 09:14:36 --> Helper loaded: file_helper
INFO - 2023-12-01 09:14:36 --> Helper loaded: form_helper
INFO - 2023-12-01 09:14:36 --> Helper loaded: my_helper
INFO - 2023-12-01 09:14:36 --> Database Driver Class Initialized
INFO - 2023-12-01 09:14:36 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-01 09:14:36 --> Controller Class Initialized
INFO - 2023-12-01 09:14:36 --> Final output sent to browser
DEBUG - 2023-12-01 09:14:36 --> Total execution time: 0.1250
INFO - 2023-12-01 09:14:42 --> Config Class Initialized
INFO - 2023-12-01 09:14:42 --> Hooks Class Initialized
DEBUG - 2023-12-01 09:14:42 --> UTF-8 Support Enabled
INFO - 2023-12-01 09:14:42 --> Utf8 Class Initialized
INFO - 2023-12-01 09:14:42 --> URI Class Initialized
INFO - 2023-12-01 09:14:42 --> Router Class Initialized
INFO - 2023-12-01 09:14:42 --> Output Class Initialized
INFO - 2023-12-01 09:14:42 --> Security Class Initialized
DEBUG - 2023-12-01 09:14:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-01 09:14:42 --> Input Class Initialized
INFO - 2023-12-01 09:14:42 --> Language Class Initialized
INFO - 2023-12-01 09:14:42 --> Language Class Initialized
INFO - 2023-12-01 09:14:42 --> Config Class Initialized
INFO - 2023-12-01 09:14:42 --> Loader Class Initialized
INFO - 2023-12-01 09:14:42 --> Helper loaded: url_helper
INFO - 2023-12-01 09:14:42 --> Helper loaded: file_helper
INFO - 2023-12-01 09:14:42 --> Helper loaded: form_helper
INFO - 2023-12-01 09:14:42 --> Helper loaded: my_helper
INFO - 2023-12-01 09:14:42 --> Database Driver Class Initialized
INFO - 2023-12-01 09:14:42 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-01 09:14:42 --> Controller Class Initialized
INFO - 2023-12-01 09:14:42 --> Final output sent to browser
DEBUG - 2023-12-01 09:14:42 --> Total execution time: 0.0451
INFO - 2023-12-01 09:14:52 --> Config Class Initialized
INFO - 2023-12-01 09:14:52 --> Hooks Class Initialized
DEBUG - 2023-12-01 09:14:52 --> UTF-8 Support Enabled
INFO - 2023-12-01 09:14:52 --> Utf8 Class Initialized
INFO - 2023-12-01 09:14:52 --> URI Class Initialized
INFO - 2023-12-01 09:14:52 --> Router Class Initialized
INFO - 2023-12-01 09:14:52 --> Output Class Initialized
INFO - 2023-12-01 09:14:52 --> Security Class Initialized
DEBUG - 2023-12-01 09:14:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-01 09:14:52 --> Input Class Initialized
INFO - 2023-12-01 09:14:52 --> Language Class Initialized
INFO - 2023-12-01 09:14:52 --> Language Class Initialized
INFO - 2023-12-01 09:14:52 --> Config Class Initialized
INFO - 2023-12-01 09:14:52 --> Loader Class Initialized
INFO - 2023-12-01 09:14:52 --> Helper loaded: url_helper
INFO - 2023-12-01 09:14:52 --> Helper loaded: file_helper
INFO - 2023-12-01 09:14:52 --> Helper loaded: form_helper
INFO - 2023-12-01 09:14:52 --> Helper loaded: my_helper
INFO - 2023-12-01 09:14:52 --> Database Driver Class Initialized
INFO - 2023-12-01 09:14:52 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-01 09:14:52 --> Controller Class Initialized
INFO - 2023-12-01 09:14:52 --> Final output sent to browser
DEBUG - 2023-12-01 09:14:52 --> Total execution time: 0.0447
INFO - 2023-12-01 09:15:00 --> Config Class Initialized
INFO - 2023-12-01 09:15:00 --> Hooks Class Initialized
DEBUG - 2023-12-01 09:15:00 --> UTF-8 Support Enabled
INFO - 2023-12-01 09:15:00 --> Utf8 Class Initialized
INFO - 2023-12-01 09:15:00 --> URI Class Initialized
INFO - 2023-12-01 09:15:00 --> Router Class Initialized
INFO - 2023-12-01 09:15:00 --> Output Class Initialized
INFO - 2023-12-01 09:15:00 --> Security Class Initialized
DEBUG - 2023-12-01 09:15:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-01 09:15:00 --> Input Class Initialized
INFO - 2023-12-01 09:15:00 --> Language Class Initialized
INFO - 2023-12-01 09:15:00 --> Language Class Initialized
INFO - 2023-12-01 09:15:00 --> Config Class Initialized
INFO - 2023-12-01 09:15:00 --> Loader Class Initialized
INFO - 2023-12-01 09:15:00 --> Helper loaded: url_helper
INFO - 2023-12-01 09:15:00 --> Helper loaded: file_helper
INFO - 2023-12-01 09:15:00 --> Helper loaded: form_helper
INFO - 2023-12-01 09:15:00 --> Helper loaded: my_helper
INFO - 2023-12-01 09:15:00 --> Database Driver Class Initialized
INFO - 2023-12-01 09:15:00 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-01 09:15:00 --> Controller Class Initialized
INFO - 2023-12-01 09:15:00 --> Final output sent to browser
DEBUG - 2023-12-01 09:15:00 --> Total execution time: 0.3836
INFO - 2023-12-01 09:15:20 --> Config Class Initialized
INFO - 2023-12-01 09:15:20 --> Hooks Class Initialized
DEBUG - 2023-12-01 09:15:20 --> UTF-8 Support Enabled
INFO - 2023-12-01 09:15:20 --> Utf8 Class Initialized
INFO - 2023-12-01 09:15:20 --> URI Class Initialized
INFO - 2023-12-01 09:15:20 --> Router Class Initialized
INFO - 2023-12-01 09:15:20 --> Output Class Initialized
INFO - 2023-12-01 09:15:20 --> Security Class Initialized
DEBUG - 2023-12-01 09:15:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-01 09:15:20 --> Input Class Initialized
INFO - 2023-12-01 09:15:20 --> Language Class Initialized
INFO - 2023-12-01 09:15:20 --> Language Class Initialized
INFO - 2023-12-01 09:15:20 --> Config Class Initialized
INFO - 2023-12-01 09:15:20 --> Loader Class Initialized
INFO - 2023-12-01 09:15:20 --> Helper loaded: url_helper
INFO - 2023-12-01 09:15:20 --> Helper loaded: file_helper
INFO - 2023-12-01 09:15:20 --> Helper loaded: form_helper
INFO - 2023-12-01 09:15:20 --> Helper loaded: my_helper
INFO - 2023-12-01 09:15:20 --> Database Driver Class Initialized
INFO - 2023-12-01 09:15:20 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-01 09:15:20 --> Controller Class Initialized
INFO - 2023-12-01 09:15:20 --> Final output sent to browser
DEBUG - 2023-12-01 09:15:20 --> Total execution time: 0.0847
INFO - 2023-12-01 09:15:23 --> Config Class Initialized
INFO - 2023-12-01 09:15:23 --> Hooks Class Initialized
DEBUG - 2023-12-01 09:15:23 --> UTF-8 Support Enabled
INFO - 2023-12-01 09:15:23 --> Utf8 Class Initialized
INFO - 2023-12-01 09:15:23 --> URI Class Initialized
INFO - 2023-12-01 09:15:23 --> Router Class Initialized
INFO - 2023-12-01 09:15:23 --> Output Class Initialized
INFO - 2023-12-01 09:15:23 --> Security Class Initialized
DEBUG - 2023-12-01 09:15:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-01 09:15:23 --> Input Class Initialized
INFO - 2023-12-01 09:15:23 --> Language Class Initialized
INFO - 2023-12-01 09:15:23 --> Language Class Initialized
INFO - 2023-12-01 09:15:23 --> Config Class Initialized
INFO - 2023-12-01 09:15:23 --> Loader Class Initialized
INFO - 2023-12-01 09:15:23 --> Helper loaded: url_helper
INFO - 2023-12-01 09:15:23 --> Helper loaded: file_helper
INFO - 2023-12-01 09:15:23 --> Helper loaded: form_helper
INFO - 2023-12-01 09:15:23 --> Helper loaded: my_helper
INFO - 2023-12-01 09:15:23 --> Database Driver Class Initialized
INFO - 2023-12-01 09:15:23 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-01 09:15:23 --> Controller Class Initialized
INFO - 2023-12-01 09:15:23 --> Final output sent to browser
DEBUG - 2023-12-01 09:15:23 --> Total execution time: 0.0472
INFO - 2023-12-01 09:16:20 --> Config Class Initialized
INFO - 2023-12-01 09:16:20 --> Hooks Class Initialized
DEBUG - 2023-12-01 09:16:20 --> UTF-8 Support Enabled
INFO - 2023-12-01 09:16:20 --> Utf8 Class Initialized
INFO - 2023-12-01 09:16:20 --> URI Class Initialized
INFO - 2023-12-01 09:16:20 --> Router Class Initialized
INFO - 2023-12-01 09:16:20 --> Output Class Initialized
INFO - 2023-12-01 09:16:20 --> Security Class Initialized
DEBUG - 2023-12-01 09:16:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-01 09:16:20 --> Input Class Initialized
INFO - 2023-12-01 09:16:20 --> Language Class Initialized
INFO - 2023-12-01 09:16:20 --> Language Class Initialized
INFO - 2023-12-01 09:16:20 --> Config Class Initialized
INFO - 2023-12-01 09:16:20 --> Loader Class Initialized
INFO - 2023-12-01 09:16:20 --> Helper loaded: url_helper
INFO - 2023-12-01 09:16:20 --> Helper loaded: file_helper
INFO - 2023-12-01 09:16:20 --> Helper loaded: form_helper
INFO - 2023-12-01 09:16:20 --> Helper loaded: my_helper
INFO - 2023-12-01 09:16:20 --> Database Driver Class Initialized
INFO - 2023-12-01 09:16:20 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-01 09:16:20 --> Controller Class Initialized
INFO - 2023-12-01 09:16:20 --> Final output sent to browser
DEBUG - 2023-12-01 09:16:20 --> Total execution time: 0.1702
