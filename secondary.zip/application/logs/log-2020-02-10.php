<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2020-02-10 02:35:17 --> Config Class Initialized
INFO - 2020-02-10 02:35:17 --> Hooks Class Initialized
DEBUG - 2020-02-10 02:35:17 --> UTF-8 Support Enabled
INFO - 2020-02-10 02:35:17 --> Utf8 Class Initialized
INFO - 2020-02-10 02:35:17 --> URI Class Initialized
DEBUG - 2020-02-10 02:35:17 --> No URI present. Default controller set.
INFO - 2020-02-10 02:35:17 --> Router Class Initialized
INFO - 2020-02-10 02:35:17 --> Output Class Initialized
INFO - 2020-02-10 02:35:17 --> Security Class Initialized
DEBUG - 2020-02-10 02:35:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-10 02:35:17 --> Input Class Initialized
INFO - 2020-02-10 02:35:17 --> Language Class Initialized
INFO - 2020-02-10 02:35:18 --> Language Class Initialized
INFO - 2020-02-10 02:35:18 --> Config Class Initialized
INFO - 2020-02-10 02:35:18 --> Loader Class Initialized
INFO - 2020-02-10 02:35:18 --> Helper loaded: url_helper
INFO - 2020-02-10 02:35:18 --> Helper loaded: file_helper
INFO - 2020-02-10 02:35:18 --> Helper loaded: form_helper
INFO - 2020-02-10 02:35:18 --> Helper loaded: my_helper
INFO - 2020-02-10 02:35:18 --> Database Driver Class Initialized
DEBUG - 2020-02-10 02:35:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-10 02:35:18 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-10 02:35:18 --> Controller Class Initialized
INFO - 2020-02-10 02:35:18 --> Config Class Initialized
INFO - 2020-02-10 02:35:18 --> Hooks Class Initialized
DEBUG - 2020-02-10 02:35:18 --> UTF-8 Support Enabled
INFO - 2020-02-10 02:35:18 --> Utf8 Class Initialized
INFO - 2020-02-10 02:35:18 --> URI Class Initialized
INFO - 2020-02-10 02:35:18 --> Router Class Initialized
INFO - 2020-02-10 02:35:18 --> Output Class Initialized
INFO - 2020-02-10 02:35:18 --> Security Class Initialized
DEBUG - 2020-02-10 02:35:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-10 02:35:18 --> Input Class Initialized
INFO - 2020-02-10 02:35:18 --> Language Class Initialized
INFO - 2020-02-10 02:35:18 --> Language Class Initialized
INFO - 2020-02-10 02:35:18 --> Config Class Initialized
INFO - 2020-02-10 02:35:18 --> Loader Class Initialized
INFO - 2020-02-10 02:35:18 --> Helper loaded: url_helper
INFO - 2020-02-10 02:35:18 --> Helper loaded: file_helper
INFO - 2020-02-10 02:35:18 --> Helper loaded: form_helper
INFO - 2020-02-10 02:35:18 --> Helper loaded: my_helper
INFO - 2020-02-10 02:35:18 --> Database Driver Class Initialized
DEBUG - 2020-02-10 02:35:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-10 02:35:18 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-10 02:35:18 --> Controller Class Initialized
DEBUG - 2020-02-10 02:35:18 --> File loaded: E:\xampp\htdocs\_2020\myraport\application\modules/login/views/login.php
DEBUG - 2020-02-10 02:35:18 --> File loaded: E:\xampp\htdocs\_2020\myraport\application\views\template_utama.php
INFO - 2020-02-10 02:35:18 --> Final output sent to browser
DEBUG - 2020-02-10 02:35:18 --> Total execution time: 0.3528
INFO - 2020-02-10 02:35:35 --> Config Class Initialized
INFO - 2020-02-10 02:35:36 --> Hooks Class Initialized
DEBUG - 2020-02-10 02:35:36 --> UTF-8 Support Enabled
INFO - 2020-02-10 02:35:36 --> Utf8 Class Initialized
INFO - 2020-02-10 02:35:36 --> URI Class Initialized
INFO - 2020-02-10 02:35:36 --> Router Class Initialized
INFO - 2020-02-10 02:35:36 --> Output Class Initialized
INFO - 2020-02-10 02:35:36 --> Security Class Initialized
DEBUG - 2020-02-10 02:35:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-10 02:35:36 --> Input Class Initialized
INFO - 2020-02-10 02:35:36 --> Language Class Initialized
INFO - 2020-02-10 02:35:36 --> Language Class Initialized
INFO - 2020-02-10 02:35:36 --> Config Class Initialized
INFO - 2020-02-10 02:35:36 --> Loader Class Initialized
INFO - 2020-02-10 02:35:36 --> Helper loaded: url_helper
INFO - 2020-02-10 02:35:36 --> Helper loaded: file_helper
INFO - 2020-02-10 02:35:36 --> Helper loaded: form_helper
INFO - 2020-02-10 02:35:36 --> Helper loaded: my_helper
INFO - 2020-02-10 02:35:36 --> Database Driver Class Initialized
DEBUG - 2020-02-10 02:35:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-10 02:35:36 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-10 02:35:36 --> Controller Class Initialized
INFO - 2020-02-10 02:35:36 --> Helper loaded: cookie_helper
INFO - 2020-02-10 02:35:36 --> Final output sent to browser
DEBUG - 2020-02-10 02:35:36 --> Total execution time: 0.3018
INFO - 2020-02-10 02:35:36 --> Config Class Initialized
INFO - 2020-02-10 02:35:36 --> Hooks Class Initialized
DEBUG - 2020-02-10 02:35:36 --> UTF-8 Support Enabled
INFO - 2020-02-10 02:35:36 --> Utf8 Class Initialized
INFO - 2020-02-10 02:35:36 --> URI Class Initialized
INFO - 2020-02-10 02:35:36 --> Router Class Initialized
INFO - 2020-02-10 02:35:36 --> Output Class Initialized
INFO - 2020-02-10 02:35:36 --> Security Class Initialized
DEBUG - 2020-02-10 02:35:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-10 02:35:36 --> Input Class Initialized
INFO - 2020-02-10 02:35:36 --> Language Class Initialized
INFO - 2020-02-10 02:35:36 --> Language Class Initialized
INFO - 2020-02-10 02:35:36 --> Config Class Initialized
INFO - 2020-02-10 02:35:36 --> Loader Class Initialized
INFO - 2020-02-10 02:35:36 --> Helper loaded: url_helper
INFO - 2020-02-10 02:35:36 --> Helper loaded: file_helper
INFO - 2020-02-10 02:35:36 --> Helper loaded: form_helper
INFO - 2020-02-10 02:35:36 --> Helper loaded: my_helper
INFO - 2020-02-10 02:35:36 --> Database Driver Class Initialized
DEBUG - 2020-02-10 02:35:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-10 02:35:36 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-10 02:35:36 --> Controller Class Initialized
DEBUG - 2020-02-10 02:35:36 --> File loaded: E:\xampp\htdocs\_2020\myraport\application\modules/home/views/v_home.php
DEBUG - 2020-02-10 02:35:36 --> File loaded: E:\xampp\htdocs\_2020\myraport\application\views\template_utama.php
INFO - 2020-02-10 02:35:36 --> Final output sent to browser
DEBUG - 2020-02-10 02:35:36 --> Total execution time: 0.3719
INFO - 2020-02-10 02:35:50 --> Config Class Initialized
INFO - 2020-02-10 02:35:50 --> Hooks Class Initialized
DEBUG - 2020-02-10 02:35:50 --> UTF-8 Support Enabled
INFO - 2020-02-10 02:35:50 --> Utf8 Class Initialized
INFO - 2020-02-10 02:35:50 --> URI Class Initialized
INFO - 2020-02-10 02:35:50 --> Router Class Initialized
INFO - 2020-02-10 02:35:50 --> Output Class Initialized
INFO - 2020-02-10 02:35:50 --> Security Class Initialized
DEBUG - 2020-02-10 02:35:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-10 02:35:50 --> Input Class Initialized
INFO - 2020-02-10 02:35:50 --> Language Class Initialized
INFO - 2020-02-10 02:35:50 --> Language Class Initialized
INFO - 2020-02-10 02:35:50 --> Config Class Initialized
INFO - 2020-02-10 02:35:50 --> Loader Class Initialized
INFO - 2020-02-10 02:35:50 --> Helper loaded: url_helper
INFO - 2020-02-10 02:35:50 --> Helper loaded: file_helper
INFO - 2020-02-10 02:35:50 --> Helper loaded: form_helper
INFO - 2020-02-10 02:35:50 --> Helper loaded: my_helper
INFO - 2020-02-10 02:35:50 --> Database Driver Class Initialized
DEBUG - 2020-02-10 02:35:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-10 02:35:50 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-10 02:35:50 --> Controller Class Initialized
DEBUG - 2020-02-10 02:35:50 --> File loaded: E:\xampp\htdocs\_2020\myraport\application\modules/data_siswa/views/list.php
DEBUG - 2020-02-10 02:35:50 --> File loaded: E:\xampp\htdocs\_2020\myraport\application\views\template_utama.php
INFO - 2020-02-10 02:35:50 --> Final output sent to browser
DEBUG - 2020-02-10 02:35:50 --> Total execution time: 0.3340
INFO - 2020-02-10 02:35:51 --> Config Class Initialized
INFO - 2020-02-10 02:35:51 --> Hooks Class Initialized
DEBUG - 2020-02-10 02:35:51 --> UTF-8 Support Enabled
INFO - 2020-02-10 02:35:51 --> Utf8 Class Initialized
INFO - 2020-02-10 02:35:51 --> URI Class Initialized
INFO - 2020-02-10 02:35:51 --> Router Class Initialized
INFO - 2020-02-10 02:35:51 --> Output Class Initialized
INFO - 2020-02-10 02:35:51 --> Security Class Initialized
DEBUG - 2020-02-10 02:35:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-10 02:35:51 --> Input Class Initialized
INFO - 2020-02-10 02:35:51 --> Language Class Initialized
INFO - 2020-02-10 02:35:51 --> Language Class Initialized
INFO - 2020-02-10 02:35:51 --> Config Class Initialized
INFO - 2020-02-10 02:35:51 --> Loader Class Initialized
INFO - 2020-02-10 02:35:51 --> Helper loaded: url_helper
INFO - 2020-02-10 02:35:51 --> Helper loaded: file_helper
INFO - 2020-02-10 02:35:51 --> Helper loaded: form_helper
INFO - 2020-02-10 02:35:51 --> Helper loaded: my_helper
INFO - 2020-02-10 02:35:51 --> Database Driver Class Initialized
DEBUG - 2020-02-10 02:35:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-10 02:35:51 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-10 02:35:51 --> Controller Class Initialized
INFO - 2020-02-10 02:35:52 --> Config Class Initialized
INFO - 2020-02-10 02:35:52 --> Hooks Class Initialized
DEBUG - 2020-02-10 02:35:52 --> UTF-8 Support Enabled
INFO - 2020-02-10 02:35:52 --> Utf8 Class Initialized
INFO - 2020-02-10 02:35:52 --> URI Class Initialized
INFO - 2020-02-10 02:35:52 --> Router Class Initialized
INFO - 2020-02-10 02:35:52 --> Output Class Initialized
INFO - 2020-02-10 02:35:52 --> Security Class Initialized
DEBUG - 2020-02-10 02:35:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-10 02:35:52 --> Input Class Initialized
INFO - 2020-02-10 02:35:52 --> Language Class Initialized
INFO - 2020-02-10 02:35:52 --> Language Class Initialized
INFO - 2020-02-10 02:35:52 --> Config Class Initialized
INFO - 2020-02-10 02:35:52 --> Loader Class Initialized
INFO - 2020-02-10 02:35:52 --> Helper loaded: url_helper
INFO - 2020-02-10 02:35:52 --> Helper loaded: file_helper
INFO - 2020-02-10 02:35:52 --> Helper loaded: form_helper
INFO - 2020-02-10 02:35:52 --> Helper loaded: my_helper
INFO - 2020-02-10 02:35:52 --> Database Driver Class Initialized
DEBUG - 2020-02-10 02:35:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-10 02:35:52 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-10 02:35:52 --> Controller Class Initialized
ERROR - 2020-02-10 02:35:52 --> Severity: Notice --> Undefined variable: status_form E:\xampp\htdocs\_2020\myraport\application\modules\data_siswa\views\form.php 223
DEBUG - 2020-02-10 02:35:52 --> File loaded: E:\xampp\htdocs\_2020\myraport\application\modules/data_siswa/views/form.php
DEBUG - 2020-02-10 02:35:52 --> File loaded: E:\xampp\htdocs\_2020\myraport\application\views\template_utama.php
INFO - 2020-02-10 02:35:52 --> Final output sent to browser
DEBUG - 2020-02-10 02:35:52 --> Total execution time: 0.3770
INFO - 2020-02-10 02:39:27 --> Config Class Initialized
INFO - 2020-02-10 02:39:27 --> Hooks Class Initialized
DEBUG - 2020-02-10 02:39:27 --> UTF-8 Support Enabled
INFO - 2020-02-10 02:39:27 --> Utf8 Class Initialized
INFO - 2020-02-10 02:39:27 --> URI Class Initialized
INFO - 2020-02-10 02:39:27 --> Router Class Initialized
INFO - 2020-02-10 02:39:27 --> Output Class Initialized
INFO - 2020-02-10 02:39:27 --> Security Class Initialized
DEBUG - 2020-02-10 02:39:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-10 02:39:27 --> Input Class Initialized
INFO - 2020-02-10 02:39:27 --> Language Class Initialized
INFO - 2020-02-10 02:39:27 --> Language Class Initialized
INFO - 2020-02-10 02:39:27 --> Config Class Initialized
INFO - 2020-02-10 02:39:27 --> Loader Class Initialized
INFO - 2020-02-10 02:39:27 --> Helper loaded: url_helper
INFO - 2020-02-10 02:39:27 --> Helper loaded: file_helper
INFO - 2020-02-10 02:39:27 --> Helper loaded: form_helper
INFO - 2020-02-10 02:39:27 --> Helper loaded: my_helper
INFO - 2020-02-10 02:39:27 --> Database Driver Class Initialized
DEBUG - 2020-02-10 02:39:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-10 02:39:27 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-10 02:39:27 --> Controller Class Initialized
ERROR - 2020-02-10 02:39:27 --> Severity: Notice --> Undefined index: mode E:\xampp\htdocs\_2020\myraport\application\modules\data_siswa\views\form.php 9
ERROR - 2020-02-10 02:39:27 --> Severity: Notice --> Undefined index: nis E:\xampp\htdocs\_2020\myraport\application\modules\data_siswa\views\form.php 15
ERROR - 2020-02-10 02:39:27 --> Severity: Notice --> Undefined index: nisn E:\xampp\htdocs\_2020\myraport\application\modules\data_siswa\views\form.php 21
ERROR - 2020-02-10 02:39:27 --> Severity: Notice --> Undefined index: jk E:\xampp\htdocs\_2020\myraport\application\modules\data_siswa\views\form.php 33
ERROR - 2020-02-10 02:39:27 --> Severity: Notice --> Undefined index: tmp_lahir E:\xampp\htdocs\_2020\myraport\application\modules\data_siswa\views\form.php 42
ERROR - 2020-02-10 02:39:27 --> Severity: Notice --> Undefined index: tgl_lahir E:\xampp\htdocs\_2020\myraport\application\modules\data_siswa\views\form.php 48
ERROR - 2020-02-10 02:39:27 --> Severity: Notice --> Undefined index: agama E:\xampp\htdocs\_2020\myraport\application\modules\data_siswa\views\form.php 54
ERROR - 2020-02-10 02:39:27 --> Severity: Notice --> Undefined index: status E:\xampp\htdocs\_2020\myraport\application\modules\data_siswa\views\form.php 60
ERROR - 2020-02-10 02:39:27 --> Severity: Notice --> Undefined index: anakke E:\xampp\htdocs\_2020\myraport\application\modules\data_siswa\views\form.php 66
ERROR - 2020-02-10 02:39:27 --> Severity: Notice --> Undefined index: alamat E:\xampp\htdocs\_2020\myraport\application\modules\data_siswa\views\form.php 74
ERROR - 2020-02-10 02:39:27 --> Severity: Notice --> Undefined index: notelp E:\xampp\htdocs\_2020\myraport\application\modules\data_siswa\views\form.php 80
ERROR - 2020-02-10 02:39:27 --> Severity: Notice --> Undefined index: sek_asal E:\xampp\htdocs\_2020\myraport\application\modules\data_siswa\views\form.php 88
ERROR - 2020-02-10 02:39:27 --> Severity: Notice --> Undefined index: sek_asal_alamat E:\xampp\htdocs\_2020\myraport\application\modules\data_siswa\views\form.php 94
ERROR - 2020-02-10 02:39:27 --> Severity: Notice --> Undefined index: diterima_kelas E:\xampp\htdocs\_2020\myraport\application\modules\data_siswa\views\form.php 102
ERROR - 2020-02-10 02:39:27 --> Severity: Notice --> Undefined index: diterima_tgl E:\xampp\htdocs\_2020\myraport\application\modules\data_siswa\views\form.php 108
ERROR - 2020-02-10 02:39:27 --> Severity: Notice --> Undefined index: ijazah_no E:\xampp\htdocs\_2020\myraport\application\modules\data_siswa\views\form.php 114
ERROR - 2020-02-10 02:39:27 --> Severity: Notice --> Undefined index: ijazah_thn E:\xampp\htdocs\_2020\myraport\application\modules\data_siswa\views\form.php 120
ERROR - 2020-02-10 02:39:27 --> Severity: Notice --> Undefined index: skhun_no E:\xampp\htdocs\_2020\myraport\application\modules\data_siswa\views\form.php 126
ERROR - 2020-02-10 02:39:27 --> Severity: Notice --> Undefined index: skhun_thn E:\xampp\htdocs\_2020\myraport\application\modules\data_siswa\views\form.php 132
ERROR - 2020-02-10 02:39:27 --> Severity: Notice --> Undefined index: ortu_ayah E:\xampp\htdocs\_2020\myraport\application\modules\data_siswa\views\form.php 141
ERROR - 2020-02-10 02:39:27 --> Severity: Notice --> Undefined index: ortu_ibu E:\xampp\htdocs\_2020\myraport\application\modules\data_siswa\views\form.php 147
ERROR - 2020-02-10 02:39:27 --> Severity: Notice --> Undefined index: ortu_alamat E:\xampp\htdocs\_2020\myraport\application\modules\data_siswa\views\form.php 153
ERROR - 2020-02-10 02:39:27 --> Severity: Notice --> Undefined index: ortu_notelp E:\xampp\htdocs\_2020\myraport\application\modules\data_siswa\views\form.php 159
ERROR - 2020-02-10 02:39:27 --> Severity: Notice --> Undefined index: ortu_ayah_pkj E:\xampp\htdocs\_2020\myraport\application\modules\data_siswa\views\form.php 167
ERROR - 2020-02-10 02:39:27 --> Severity: Notice --> Undefined index: ortu_ibu_pkj E:\xampp\htdocs\_2020\myraport\application\modules\data_siswa\views\form.php 173
ERROR - 2020-02-10 02:39:27 --> Severity: Notice --> Undefined index: wali E:\xampp\htdocs\_2020\myraport\application\modules\data_siswa\views\form.php 179
ERROR - 2020-02-10 02:39:27 --> Severity: Notice --> Undefined index: wali_alamat E:\xampp\htdocs\_2020\myraport\application\modules\data_siswa\views\form.php 185
ERROR - 2020-02-10 02:39:27 --> Severity: Notice --> Undefined index: notelp_rumah E:\xampp\htdocs\_2020\myraport\application\modules\data_siswa\views\form.php 191
ERROR - 2020-02-10 02:39:27 --> Severity: Notice --> Undefined index: wali_pkj E:\xampp\htdocs\_2020\myraport\application\modules\data_siswa\views\form.php 197
ERROR - 2020-02-10 02:39:27 --> Severity: Notice --> Undefined variable: status_form E:\xampp\htdocs\_2020\myraport\application\modules\data_siswa\views\form.php 223
DEBUG - 2020-02-10 02:39:27 --> File loaded: E:\xampp\htdocs\_2020\myraport\application\modules/data_siswa/views/form.php
DEBUG - 2020-02-10 02:39:27 --> File loaded: E:\xampp\htdocs\_2020\myraport\application\views\template_utama.php
INFO - 2020-02-10 02:39:27 --> Final output sent to browser
DEBUG - 2020-02-10 02:39:27 --> Total execution time: 0.6338
INFO - 2020-02-10 02:39:37 --> Config Class Initialized
INFO - 2020-02-10 02:39:37 --> Hooks Class Initialized
DEBUG - 2020-02-10 02:39:37 --> UTF-8 Support Enabled
INFO - 2020-02-10 02:39:37 --> Utf8 Class Initialized
INFO - 2020-02-10 02:39:37 --> URI Class Initialized
INFO - 2020-02-10 02:39:37 --> Router Class Initialized
INFO - 2020-02-10 02:39:37 --> Output Class Initialized
INFO - 2020-02-10 02:39:37 --> Security Class Initialized
DEBUG - 2020-02-10 02:39:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-10 02:39:37 --> Input Class Initialized
INFO - 2020-02-10 02:39:37 --> Language Class Initialized
INFO - 2020-02-10 02:39:37 --> Language Class Initialized
INFO - 2020-02-10 02:39:37 --> Config Class Initialized
INFO - 2020-02-10 02:39:37 --> Loader Class Initialized
INFO - 2020-02-10 02:39:37 --> Helper loaded: url_helper
INFO - 2020-02-10 02:39:37 --> Helper loaded: file_helper
INFO - 2020-02-10 02:39:37 --> Helper loaded: form_helper
INFO - 2020-02-10 02:39:37 --> Helper loaded: my_helper
INFO - 2020-02-10 02:39:37 --> Database Driver Class Initialized
DEBUG - 2020-02-10 02:39:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-10 02:39:37 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-10 02:39:37 --> Controller Class Initialized
ERROR - 2020-02-10 02:39:37 --> Severity: Notice --> Undefined variable: status_form E:\xampp\htdocs\_2020\myraport\application\modules\data_siswa\views\form.php 223
DEBUG - 2020-02-10 02:39:37 --> File loaded: E:\xampp\htdocs\_2020\myraport\application\modules/data_siswa/views/form.php
DEBUG - 2020-02-10 02:39:37 --> File loaded: E:\xampp\htdocs\_2020\myraport\application\views\template_utama.php
INFO - 2020-02-10 02:39:37 --> Final output sent to browser
DEBUG - 2020-02-10 02:39:37 --> Total execution time: 0.3248
INFO - 2020-02-10 02:40:50 --> Config Class Initialized
INFO - 2020-02-10 02:40:50 --> Hooks Class Initialized
DEBUG - 2020-02-10 02:40:50 --> UTF-8 Support Enabled
INFO - 2020-02-10 02:40:50 --> Utf8 Class Initialized
INFO - 2020-02-10 02:40:50 --> URI Class Initialized
INFO - 2020-02-10 02:40:50 --> Router Class Initialized
INFO - 2020-02-10 02:40:50 --> Output Class Initialized
INFO - 2020-02-10 02:40:50 --> Security Class Initialized
DEBUG - 2020-02-10 02:40:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-10 02:40:50 --> Input Class Initialized
INFO - 2020-02-10 02:40:51 --> Language Class Initialized
INFO - 2020-02-10 02:40:51 --> Language Class Initialized
INFO - 2020-02-10 02:40:51 --> Config Class Initialized
INFO - 2020-02-10 02:40:51 --> Loader Class Initialized
INFO - 2020-02-10 02:40:51 --> Helper loaded: url_helper
INFO - 2020-02-10 02:40:51 --> Helper loaded: file_helper
INFO - 2020-02-10 02:40:51 --> Helper loaded: form_helper
INFO - 2020-02-10 02:40:51 --> Helper loaded: my_helper
INFO - 2020-02-10 02:40:51 --> Database Driver Class Initialized
DEBUG - 2020-02-10 02:40:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-10 02:40:51 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-10 02:40:51 --> Controller Class Initialized
DEBUG - 2020-02-10 02:40:51 --> File loaded: E:\xampp\htdocs\_2020\myraport\application\modules/data_mapel/views/list.php
DEBUG - 2020-02-10 02:40:51 --> File loaded: E:\xampp\htdocs\_2020\myraport\application\views\template_utama.php
INFO - 2020-02-10 02:40:51 --> Final output sent to browser
DEBUG - 2020-02-10 02:40:51 --> Total execution time: 0.4099
INFO - 2020-02-10 02:40:51 --> Config Class Initialized
INFO - 2020-02-10 02:40:51 --> Hooks Class Initialized
DEBUG - 2020-02-10 02:40:51 --> UTF-8 Support Enabled
INFO - 2020-02-10 02:40:51 --> Utf8 Class Initialized
INFO - 2020-02-10 02:40:51 --> URI Class Initialized
INFO - 2020-02-10 02:40:51 --> Router Class Initialized
INFO - 2020-02-10 02:40:51 --> Output Class Initialized
INFO - 2020-02-10 02:40:51 --> Security Class Initialized
DEBUG - 2020-02-10 02:40:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-10 02:40:51 --> Input Class Initialized
INFO - 2020-02-10 02:40:51 --> Language Class Initialized
INFO - 2020-02-10 02:40:51 --> Language Class Initialized
INFO - 2020-02-10 02:40:51 --> Config Class Initialized
INFO - 2020-02-10 02:40:51 --> Loader Class Initialized
INFO - 2020-02-10 02:40:51 --> Helper loaded: url_helper
INFO - 2020-02-10 02:40:51 --> Helper loaded: file_helper
INFO - 2020-02-10 02:40:51 --> Helper loaded: form_helper
INFO - 2020-02-10 02:40:51 --> Helper loaded: my_helper
INFO - 2020-02-10 02:40:51 --> Database Driver Class Initialized
DEBUG - 2020-02-10 02:40:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-10 02:40:51 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-10 02:40:51 --> Controller Class Initialized
INFO - 2020-02-10 02:40:52 --> Config Class Initialized
INFO - 2020-02-10 02:40:52 --> Hooks Class Initialized
DEBUG - 2020-02-10 02:40:52 --> UTF-8 Support Enabled
INFO - 2020-02-10 02:40:52 --> Utf8 Class Initialized
INFO - 2020-02-10 02:40:52 --> URI Class Initialized
INFO - 2020-02-10 02:40:52 --> Router Class Initialized
INFO - 2020-02-10 02:40:52 --> Output Class Initialized
INFO - 2020-02-10 02:40:52 --> Security Class Initialized
DEBUG - 2020-02-10 02:40:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-10 02:40:52 --> Input Class Initialized
INFO - 2020-02-10 02:40:52 --> Language Class Initialized
INFO - 2020-02-10 02:40:52 --> Language Class Initialized
INFO - 2020-02-10 02:40:52 --> Config Class Initialized
INFO - 2020-02-10 02:40:53 --> Loader Class Initialized
INFO - 2020-02-10 02:40:53 --> Helper loaded: url_helper
INFO - 2020-02-10 02:40:53 --> Helper loaded: file_helper
INFO - 2020-02-10 02:40:53 --> Helper loaded: form_helper
INFO - 2020-02-10 02:40:53 --> Helper loaded: my_helper
INFO - 2020-02-10 02:40:53 --> Database Driver Class Initialized
DEBUG - 2020-02-10 02:40:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-10 02:40:53 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-10 02:40:53 --> Controller Class Initialized
INFO - 2020-02-10 02:40:53 --> Final output sent to browser
DEBUG - 2020-02-10 02:40:53 --> Total execution time: 0.3353
INFO - 2020-02-10 02:41:03 --> Config Class Initialized
INFO - 2020-02-10 02:41:03 --> Hooks Class Initialized
DEBUG - 2020-02-10 02:41:03 --> UTF-8 Support Enabled
INFO - 2020-02-10 02:41:03 --> Utf8 Class Initialized
INFO - 2020-02-10 02:41:03 --> URI Class Initialized
INFO - 2020-02-10 02:41:03 --> Router Class Initialized
INFO - 2020-02-10 02:41:03 --> Output Class Initialized
INFO - 2020-02-10 02:41:03 --> Security Class Initialized
DEBUG - 2020-02-10 02:41:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-10 02:41:03 --> Input Class Initialized
INFO - 2020-02-10 02:41:04 --> Language Class Initialized
INFO - 2020-02-10 02:41:04 --> Language Class Initialized
INFO - 2020-02-10 02:41:04 --> Config Class Initialized
INFO - 2020-02-10 02:41:04 --> Loader Class Initialized
INFO - 2020-02-10 02:41:04 --> Helper loaded: url_helper
INFO - 2020-02-10 02:41:04 --> Helper loaded: file_helper
INFO - 2020-02-10 02:41:04 --> Helper loaded: form_helper
INFO - 2020-02-10 02:41:04 --> Helper loaded: my_helper
INFO - 2020-02-10 02:41:04 --> Database Driver Class Initialized
DEBUG - 2020-02-10 02:41:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-10 02:41:04 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-10 02:41:04 --> Controller Class Initialized
DEBUG - 2020-02-10 02:41:04 --> File loaded: E:\xampp\htdocs\_2020\myraport\application\modules/set_kelas/views/list.php
DEBUG - 2020-02-10 02:41:04 --> File loaded: E:\xampp\htdocs\_2020\myraport\application\views\template_utama.php
INFO - 2020-02-10 02:41:04 --> Final output sent to browser
DEBUG - 2020-02-10 02:41:04 --> Total execution time: 0.4408
INFO - 2020-02-10 02:41:07 --> Config Class Initialized
INFO - 2020-02-10 02:41:07 --> Hooks Class Initialized
DEBUG - 2020-02-10 02:41:07 --> UTF-8 Support Enabled
INFO - 2020-02-10 02:41:07 --> Utf8 Class Initialized
INFO - 2020-02-10 02:41:07 --> URI Class Initialized
DEBUG - 2020-02-10 02:41:07 --> No URI present. Default controller set.
INFO - 2020-02-10 02:41:07 --> Router Class Initialized
INFO - 2020-02-10 02:41:07 --> Output Class Initialized
INFO - 2020-02-10 02:41:07 --> Security Class Initialized
DEBUG - 2020-02-10 02:41:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-10 02:41:07 --> Input Class Initialized
INFO - 2020-02-10 02:41:07 --> Language Class Initialized
INFO - 2020-02-10 02:41:07 --> Language Class Initialized
INFO - 2020-02-10 02:41:07 --> Config Class Initialized
INFO - 2020-02-10 02:41:07 --> Loader Class Initialized
INFO - 2020-02-10 02:41:07 --> Helper loaded: url_helper
INFO - 2020-02-10 02:41:07 --> Helper loaded: file_helper
INFO - 2020-02-10 02:41:07 --> Helper loaded: form_helper
INFO - 2020-02-10 02:41:07 --> Helper loaded: my_helper
INFO - 2020-02-10 02:41:07 --> Database Driver Class Initialized
DEBUG - 2020-02-10 02:41:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-10 02:41:07 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-10 02:41:07 --> Controller Class Initialized
DEBUG - 2020-02-10 02:41:07 --> File loaded: E:\xampp\htdocs\_2020\myraport\application\modules/home/views/v_home.php
DEBUG - 2020-02-10 02:41:07 --> File loaded: E:\xampp\htdocs\_2020\myraport\application\views\template_utama.php
INFO - 2020-02-10 02:41:07 --> Final output sent to browser
DEBUG - 2020-02-10 02:41:07 --> Total execution time: 0.3271
INFO - 2020-02-10 02:46:23 --> Config Class Initialized
INFO - 2020-02-10 02:46:23 --> Hooks Class Initialized
DEBUG - 2020-02-10 02:46:23 --> UTF-8 Support Enabled
INFO - 2020-02-10 02:46:23 --> Utf8 Class Initialized
INFO - 2020-02-10 02:46:23 --> URI Class Initialized
INFO - 2020-02-10 02:46:23 --> Router Class Initialized
INFO - 2020-02-10 02:46:23 --> Output Class Initialized
INFO - 2020-02-10 02:46:23 --> Security Class Initialized
DEBUG - 2020-02-10 02:46:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-10 02:46:23 --> Input Class Initialized
INFO - 2020-02-10 02:46:23 --> Language Class Initialized
INFO - 2020-02-10 02:46:23 --> Language Class Initialized
INFO - 2020-02-10 02:46:23 --> Config Class Initialized
INFO - 2020-02-10 02:46:23 --> Loader Class Initialized
INFO - 2020-02-10 02:46:23 --> Helper loaded: url_helper
INFO - 2020-02-10 02:46:23 --> Helper loaded: file_helper
INFO - 2020-02-10 02:46:23 --> Helper loaded: form_helper
INFO - 2020-02-10 02:46:23 --> Helper loaded: my_helper
INFO - 2020-02-10 02:46:23 --> Database Driver Class Initialized
DEBUG - 2020-02-10 02:46:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-10 02:46:23 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-10 02:46:23 --> Controller Class Initialized
DEBUG - 2020-02-10 02:46:23 --> File loaded: E:\xampp\htdocs\_2020\myraport\application\modules/data_siswa/views/list.php
DEBUG - 2020-02-10 02:46:23 --> File loaded: E:\xampp\htdocs\_2020\myraport\application\views\template_utama.php
INFO - 2020-02-10 02:46:23 --> Final output sent to browser
DEBUG - 2020-02-10 02:46:23 --> Total execution time: 0.2661
INFO - 2020-02-10 02:46:24 --> Config Class Initialized
INFO - 2020-02-10 02:46:24 --> Hooks Class Initialized
DEBUG - 2020-02-10 02:46:24 --> UTF-8 Support Enabled
INFO - 2020-02-10 02:46:24 --> Utf8 Class Initialized
INFO - 2020-02-10 02:46:24 --> URI Class Initialized
INFO - 2020-02-10 02:46:24 --> Router Class Initialized
INFO - 2020-02-10 02:46:24 --> Output Class Initialized
INFO - 2020-02-10 02:46:24 --> Security Class Initialized
DEBUG - 2020-02-10 02:46:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-10 02:46:24 --> Input Class Initialized
INFO - 2020-02-10 02:46:24 --> Language Class Initialized
INFO - 2020-02-10 02:46:24 --> Language Class Initialized
INFO - 2020-02-10 02:46:24 --> Config Class Initialized
INFO - 2020-02-10 02:46:24 --> Loader Class Initialized
INFO - 2020-02-10 02:46:24 --> Helper loaded: url_helper
INFO - 2020-02-10 02:46:24 --> Helper loaded: file_helper
INFO - 2020-02-10 02:46:24 --> Helper loaded: form_helper
INFO - 2020-02-10 02:46:24 --> Helper loaded: my_helper
INFO - 2020-02-10 02:46:24 --> Database Driver Class Initialized
DEBUG - 2020-02-10 02:46:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-10 02:46:24 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-10 02:46:24 --> Controller Class Initialized
INFO - 2020-02-10 02:46:25 --> Config Class Initialized
INFO - 2020-02-10 02:46:25 --> Hooks Class Initialized
DEBUG - 2020-02-10 02:46:25 --> UTF-8 Support Enabled
INFO - 2020-02-10 02:46:25 --> Utf8 Class Initialized
INFO - 2020-02-10 02:46:25 --> URI Class Initialized
INFO - 2020-02-10 02:46:25 --> Router Class Initialized
INFO - 2020-02-10 02:46:25 --> Output Class Initialized
INFO - 2020-02-10 02:46:25 --> Security Class Initialized
DEBUG - 2020-02-10 02:46:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-10 02:46:25 --> Input Class Initialized
INFO - 2020-02-10 02:46:25 --> Language Class Initialized
INFO - 2020-02-10 02:46:25 --> Language Class Initialized
INFO - 2020-02-10 02:46:25 --> Config Class Initialized
INFO - 2020-02-10 02:46:25 --> Loader Class Initialized
INFO - 2020-02-10 02:46:25 --> Helper loaded: url_helper
INFO - 2020-02-10 02:46:25 --> Helper loaded: file_helper
INFO - 2020-02-10 02:46:25 --> Helper loaded: form_helper
INFO - 2020-02-10 02:46:25 --> Helper loaded: my_helper
INFO - 2020-02-10 02:46:25 --> Database Driver Class Initialized
DEBUG - 2020-02-10 02:46:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-10 02:46:25 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-10 02:46:25 --> Controller Class Initialized
ERROR - 2020-02-10 02:46:25 --> Severity: Notice --> Undefined index: diterima_tgl E:\xampp\htdocs\_2020\myraport\application\modules\data_siswa\views\form.php 116
ERROR - 2020-02-10 02:46:25 --> Severity: Notice --> Undefined index: ijazah_no E:\xampp\htdocs\_2020\myraport\application\modules\data_siswa\views\form.php 122
ERROR - 2020-02-10 02:46:25 --> Severity: Notice --> Undefined index: ijazah_thn E:\xampp\htdocs\_2020\myraport\application\modules\data_siswa\views\form.php 128
ERROR - 2020-02-10 02:46:25 --> Severity: Notice --> Undefined index: skhun_no E:\xampp\htdocs\_2020\myraport\application\modules\data_siswa\views\form.php 134
ERROR - 2020-02-10 02:46:25 --> Severity: Notice --> Undefined index: skhun_thn E:\xampp\htdocs\_2020\myraport\application\modules\data_siswa\views\form.php 140
ERROR - 2020-02-10 02:46:25 --> Severity: Notice --> Undefined index: ortu_ayah E:\xampp\htdocs\_2020\myraport\application\modules\data_siswa\views\form.php 149
ERROR - 2020-02-10 02:46:25 --> Severity: Notice --> Undefined index: ortu_ibu E:\xampp\htdocs\_2020\myraport\application\modules\data_siswa\views\form.php 155
ERROR - 2020-02-10 02:46:25 --> Severity: Notice --> Undefined index: ortu_alamat E:\xampp\htdocs\_2020\myraport\application\modules\data_siswa\views\form.php 161
ERROR - 2020-02-10 02:46:25 --> Severity: Notice --> Undefined index: ortu_notelp E:\xampp\htdocs\_2020\myraport\application\modules\data_siswa\views\form.php 167
ERROR - 2020-02-10 02:46:25 --> Severity: Notice --> Undefined index: ortu_ayah_pkj E:\xampp\htdocs\_2020\myraport\application\modules\data_siswa\views\form.php 175
ERROR - 2020-02-10 02:46:25 --> Severity: Notice --> Undefined index: ortu_ibu_pkj E:\xampp\htdocs\_2020\myraport\application\modules\data_siswa\views\form.php 181
ERROR - 2020-02-10 02:46:25 --> Severity: Notice --> Undefined index: wali E:\xampp\htdocs\_2020\myraport\application\modules\data_siswa\views\form.php 187
ERROR - 2020-02-10 02:46:25 --> Severity: Notice --> Undefined index: wali_alamat E:\xampp\htdocs\_2020\myraport\application\modules\data_siswa\views\form.php 193
ERROR - 2020-02-10 02:46:25 --> Severity: Notice --> Undefined index: notelp_rumah E:\xampp\htdocs\_2020\myraport\application\modules\data_siswa\views\form.php 199
ERROR - 2020-02-10 02:46:25 --> Severity: Notice --> Undefined index: wali_pkj E:\xampp\htdocs\_2020\myraport\application\modules\data_siswa\views\form.php 205
ERROR - 2020-02-10 02:46:25 --> Severity: Notice --> Undefined variable: status_form E:\xampp\htdocs\_2020\myraport\application\modules\data_siswa\views\form.php 231
DEBUG - 2020-02-10 02:46:25 --> File loaded: E:\xampp\htdocs\_2020\myraport\application\modules/data_siswa/views/form.php
DEBUG - 2020-02-10 02:46:25 --> File loaded: E:\xampp\htdocs\_2020\myraport\application\views\template_utama.php
INFO - 2020-02-10 02:46:25 --> Final output sent to browser
DEBUG - 2020-02-10 02:46:25 --> Total execution time: 0.4707
INFO - 2020-02-10 02:46:43 --> Config Class Initialized
INFO - 2020-02-10 02:46:43 --> Hooks Class Initialized
DEBUG - 2020-02-10 02:46:43 --> UTF-8 Support Enabled
INFO - 2020-02-10 02:46:43 --> Utf8 Class Initialized
INFO - 2020-02-10 02:46:43 --> URI Class Initialized
INFO - 2020-02-10 02:46:43 --> Router Class Initialized
INFO - 2020-02-10 02:46:43 --> Output Class Initialized
INFO - 2020-02-10 02:46:43 --> Security Class Initialized
DEBUG - 2020-02-10 02:46:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-10 02:46:43 --> Input Class Initialized
INFO - 2020-02-10 02:46:43 --> Language Class Initialized
INFO - 2020-02-10 02:46:43 --> Language Class Initialized
INFO - 2020-02-10 02:46:43 --> Config Class Initialized
INFO - 2020-02-10 02:46:43 --> Loader Class Initialized
INFO - 2020-02-10 02:46:43 --> Helper loaded: url_helper
INFO - 2020-02-10 02:46:43 --> Helper loaded: file_helper
INFO - 2020-02-10 02:46:43 --> Helper loaded: form_helper
INFO - 2020-02-10 02:46:43 --> Helper loaded: my_helper
INFO - 2020-02-10 02:46:43 --> Database Driver Class Initialized
DEBUG - 2020-02-10 02:46:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-10 02:46:43 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-10 02:46:43 --> Controller Class Initialized
ERROR - 2020-02-10 02:46:43 --> Severity: Notice --> Undefined index: diterima_tgl E:\xampp\htdocs\_2020\myraport\application\modules\data_siswa\views\form.php 116
ERROR - 2020-02-10 02:46:44 --> Severity: Notice --> Undefined index: ijazah_no E:\xampp\htdocs\_2020\myraport\application\modules\data_siswa\views\form.php 122
ERROR - 2020-02-10 02:46:44 --> Severity: Notice --> Undefined index: ijazah_thn E:\xampp\htdocs\_2020\myraport\application\modules\data_siswa\views\form.php 128
ERROR - 2020-02-10 02:46:44 --> Severity: Notice --> Undefined index: skhun_no E:\xampp\htdocs\_2020\myraport\application\modules\data_siswa\views\form.php 134
ERROR - 2020-02-10 02:46:44 --> Severity: Notice --> Undefined index: skhun_thn E:\xampp\htdocs\_2020\myraport\application\modules\data_siswa\views\form.php 140
ERROR - 2020-02-10 02:46:44 --> Severity: Notice --> Undefined index: ortu_ayah E:\xampp\htdocs\_2020\myraport\application\modules\data_siswa\views\form.php 149
ERROR - 2020-02-10 02:46:44 --> Severity: Notice --> Undefined index: ortu_ibu E:\xampp\htdocs\_2020\myraport\application\modules\data_siswa\views\form.php 155
ERROR - 2020-02-10 02:46:44 --> Severity: Notice --> Undefined index: ortu_alamat E:\xampp\htdocs\_2020\myraport\application\modules\data_siswa\views\form.php 161
ERROR - 2020-02-10 02:46:44 --> Severity: Notice --> Undefined index: ortu_notelp E:\xampp\htdocs\_2020\myraport\application\modules\data_siswa\views\form.php 167
ERROR - 2020-02-10 02:46:44 --> Severity: Notice --> Undefined index: ortu_ayah_pkj E:\xampp\htdocs\_2020\myraport\application\modules\data_siswa\views\form.php 175
ERROR - 2020-02-10 02:46:44 --> Severity: Notice --> Undefined index: ortu_ibu_pkj E:\xampp\htdocs\_2020\myraport\application\modules\data_siswa\views\form.php 181
ERROR - 2020-02-10 02:46:44 --> Severity: Notice --> Undefined index: wali E:\xampp\htdocs\_2020\myraport\application\modules\data_siswa\views\form.php 187
ERROR - 2020-02-10 02:46:44 --> Severity: Notice --> Undefined index: wali_alamat E:\xampp\htdocs\_2020\myraport\application\modules\data_siswa\views\form.php 193
ERROR - 2020-02-10 02:46:44 --> Severity: Notice --> Undefined index: notelp_rumah E:\xampp\htdocs\_2020\myraport\application\modules\data_siswa\views\form.php 199
ERROR - 2020-02-10 02:46:44 --> Severity: Notice --> Undefined index: wali_pkj E:\xampp\htdocs\_2020\myraport\application\modules\data_siswa\views\form.php 205
ERROR - 2020-02-10 02:46:44 --> Severity: Notice --> Undefined variable: status_form E:\xampp\htdocs\_2020\myraport\application\modules\data_siswa\views\form.php 231
DEBUG - 2020-02-10 02:46:44 --> File loaded: E:\xampp\htdocs\_2020\myraport\application\modules/data_siswa/views/form.php
DEBUG - 2020-02-10 02:46:44 --> File loaded: E:\xampp\htdocs\_2020\myraport\application\views\template_utama.php
INFO - 2020-02-10 02:46:44 --> Final output sent to browser
DEBUG - 2020-02-10 02:46:44 --> Total execution time: 0.4979
INFO - 2020-02-10 02:46:55 --> Config Class Initialized
INFO - 2020-02-10 02:46:55 --> Hooks Class Initialized
DEBUG - 2020-02-10 02:46:55 --> UTF-8 Support Enabled
INFO - 2020-02-10 02:46:55 --> Utf8 Class Initialized
INFO - 2020-02-10 02:46:55 --> URI Class Initialized
INFO - 2020-02-10 02:46:55 --> Router Class Initialized
INFO - 2020-02-10 02:46:55 --> Output Class Initialized
INFO - 2020-02-10 02:46:55 --> Security Class Initialized
DEBUG - 2020-02-10 02:46:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-10 02:46:55 --> Input Class Initialized
INFO - 2020-02-10 02:46:55 --> Language Class Initialized
INFO - 2020-02-10 02:46:55 --> Language Class Initialized
INFO - 2020-02-10 02:46:55 --> Config Class Initialized
INFO - 2020-02-10 02:46:55 --> Loader Class Initialized
INFO - 2020-02-10 02:46:55 --> Helper loaded: url_helper
INFO - 2020-02-10 02:46:55 --> Helper loaded: file_helper
INFO - 2020-02-10 02:46:55 --> Helper loaded: form_helper
INFO - 2020-02-10 02:46:55 --> Helper loaded: my_helper
INFO - 2020-02-10 02:46:55 --> Database Driver Class Initialized
DEBUG - 2020-02-10 02:46:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-10 02:46:55 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-10 02:46:55 --> Controller Class Initialized
ERROR - 2020-02-10 02:46:55 --> Severity: Notice --> Undefined index: diterima_tgl E:\xampp\htdocs\_2020\myraport\application\modules\data_siswa\views\form.php 116
ERROR - 2020-02-10 02:46:55 --> Severity: Notice --> Undefined index: ijazah_no E:\xampp\htdocs\_2020\myraport\application\modules\data_siswa\views\form.php 122
ERROR - 2020-02-10 02:46:55 --> Severity: Notice --> Undefined index: ijazah_thn E:\xampp\htdocs\_2020\myraport\application\modules\data_siswa\views\form.php 128
ERROR - 2020-02-10 02:46:55 --> Severity: Notice --> Undefined index: skhun_no E:\xampp\htdocs\_2020\myraport\application\modules\data_siswa\views\form.php 134
ERROR - 2020-02-10 02:46:55 --> Severity: Notice --> Undefined index: skhun_thn E:\xampp\htdocs\_2020\myraport\application\modules\data_siswa\views\form.php 140
ERROR - 2020-02-10 02:46:55 --> Severity: Notice --> Undefined index: ortu_ayah E:\xampp\htdocs\_2020\myraport\application\modules\data_siswa\views\form.php 149
ERROR - 2020-02-10 02:46:55 --> Severity: Notice --> Undefined index: ortu_ibu E:\xampp\htdocs\_2020\myraport\application\modules\data_siswa\views\form.php 155
ERROR - 2020-02-10 02:46:55 --> Severity: Notice --> Undefined index: ortu_alamat E:\xampp\htdocs\_2020\myraport\application\modules\data_siswa\views\form.php 161
ERROR - 2020-02-10 02:46:55 --> Severity: Notice --> Undefined index: ortu_notelp E:\xampp\htdocs\_2020\myraport\application\modules\data_siswa\views\form.php 167
ERROR - 2020-02-10 02:46:55 --> Severity: Notice --> Undefined index: ortu_ayah_pkj E:\xampp\htdocs\_2020\myraport\application\modules\data_siswa\views\form.php 175
ERROR - 2020-02-10 02:46:55 --> Severity: Notice --> Undefined index: ortu_ibu_pkj E:\xampp\htdocs\_2020\myraport\application\modules\data_siswa\views\form.php 181
ERROR - 2020-02-10 02:46:55 --> Severity: Notice --> Undefined index: wali E:\xampp\htdocs\_2020\myraport\application\modules\data_siswa\views\form.php 187
ERROR - 2020-02-10 02:46:55 --> Severity: Notice --> Undefined index: wali_alamat E:\xampp\htdocs\_2020\myraport\application\modules\data_siswa\views\form.php 193
ERROR - 2020-02-10 02:46:55 --> Severity: Notice --> Undefined index: notelp_rumah E:\xampp\htdocs\_2020\myraport\application\modules\data_siswa\views\form.php 199
ERROR - 2020-02-10 02:46:55 --> Severity: Notice --> Undefined index: wali_pkj E:\xampp\htdocs\_2020\myraport\application\modules\data_siswa\views\form.php 205
ERROR - 2020-02-10 02:46:55 --> Severity: Notice --> Undefined variable: status_form E:\xampp\htdocs\_2020\myraport\application\modules\data_siswa\views\form.php 231
DEBUG - 2020-02-10 02:46:55 --> File loaded: E:\xampp\htdocs\_2020\myraport\application\modules/data_siswa/views/form.php
DEBUG - 2020-02-10 02:46:55 --> File loaded: E:\xampp\htdocs\_2020\myraport\application\views\template_utama.php
INFO - 2020-02-10 02:46:55 --> Final output sent to browser
DEBUG - 2020-02-10 02:46:55 --> Total execution time: 0.5394
INFO - 2020-02-10 02:47:58 --> Config Class Initialized
INFO - 2020-02-10 02:47:58 --> Hooks Class Initialized
DEBUG - 2020-02-10 02:47:58 --> UTF-8 Support Enabled
INFO - 2020-02-10 02:47:58 --> Utf8 Class Initialized
INFO - 2020-02-10 02:47:58 --> URI Class Initialized
INFO - 2020-02-10 02:47:58 --> Router Class Initialized
INFO - 2020-02-10 02:47:58 --> Output Class Initialized
INFO - 2020-02-10 02:47:58 --> Security Class Initialized
DEBUG - 2020-02-10 02:47:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-10 02:47:58 --> Input Class Initialized
INFO - 2020-02-10 02:47:58 --> Language Class Initialized
INFO - 2020-02-10 02:47:58 --> Language Class Initialized
INFO - 2020-02-10 02:47:58 --> Config Class Initialized
INFO - 2020-02-10 02:47:58 --> Loader Class Initialized
INFO - 2020-02-10 02:47:58 --> Helper loaded: url_helper
INFO - 2020-02-10 02:47:58 --> Helper loaded: file_helper
INFO - 2020-02-10 02:47:58 --> Helper loaded: form_helper
INFO - 2020-02-10 02:47:58 --> Helper loaded: my_helper
INFO - 2020-02-10 02:47:58 --> Database Driver Class Initialized
DEBUG - 2020-02-10 02:47:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-10 02:47:58 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-10 02:47:58 --> Controller Class Initialized
ERROR - 2020-02-10 02:47:58 --> Severity: Notice --> Undefined index: diterima_tgl E:\xampp\htdocs\_2020\myraport\application\modules\data_siswa\views\form.php 115
ERROR - 2020-02-10 02:47:58 --> Severity: Notice --> Undefined index: ijazah_no E:\xampp\htdocs\_2020\myraport\application\modules\data_siswa\views\form.php 121
ERROR - 2020-02-10 02:47:58 --> Severity: Notice --> Undefined index: ijazah_thn E:\xampp\htdocs\_2020\myraport\application\modules\data_siswa\views\form.php 127
ERROR - 2020-02-10 02:47:58 --> Severity: Notice --> Undefined index: skhun_no E:\xampp\htdocs\_2020\myraport\application\modules\data_siswa\views\form.php 133
ERROR - 2020-02-10 02:47:58 --> Severity: Notice --> Undefined index: skhun_thn E:\xampp\htdocs\_2020\myraport\application\modules\data_siswa\views\form.php 139
ERROR - 2020-02-10 02:47:58 --> Severity: Notice --> Undefined index: ortu_ayah E:\xampp\htdocs\_2020\myraport\application\modules\data_siswa\views\form.php 148
ERROR - 2020-02-10 02:47:58 --> Severity: Notice --> Undefined index: ortu_ibu E:\xampp\htdocs\_2020\myraport\application\modules\data_siswa\views\form.php 154
ERROR - 2020-02-10 02:47:58 --> Severity: Notice --> Undefined index: ortu_alamat E:\xampp\htdocs\_2020\myraport\application\modules\data_siswa\views\form.php 160
ERROR - 2020-02-10 02:47:58 --> Severity: Notice --> Undefined index: ortu_notelp E:\xampp\htdocs\_2020\myraport\application\modules\data_siswa\views\form.php 166
ERROR - 2020-02-10 02:47:58 --> Severity: Notice --> Undefined index: ortu_ayah_pkj E:\xampp\htdocs\_2020\myraport\application\modules\data_siswa\views\form.php 174
ERROR - 2020-02-10 02:47:58 --> Severity: Notice --> Undefined index: ortu_ibu_pkj E:\xampp\htdocs\_2020\myraport\application\modules\data_siswa\views\form.php 180
ERROR - 2020-02-10 02:47:58 --> Severity: Notice --> Undefined index: wali E:\xampp\htdocs\_2020\myraport\application\modules\data_siswa\views\form.php 186
ERROR - 2020-02-10 02:47:58 --> Severity: Notice --> Undefined index: wali_alamat E:\xampp\htdocs\_2020\myraport\application\modules\data_siswa\views\form.php 192
ERROR - 2020-02-10 02:47:58 --> Severity: Notice --> Undefined index: notelp_rumah E:\xampp\htdocs\_2020\myraport\application\modules\data_siswa\views\form.php 198
ERROR - 2020-02-10 02:47:58 --> Severity: Notice --> Undefined index: wali_pkj E:\xampp\htdocs\_2020\myraport\application\modules\data_siswa\views\form.php 204
ERROR - 2020-02-10 02:47:58 --> Severity: Notice --> Undefined variable: status_form E:\xampp\htdocs\_2020\myraport\application\modules\data_siswa\views\form.php 230
DEBUG - 2020-02-10 02:47:58 --> File loaded: E:\xampp\htdocs\_2020\myraport\application\modules/data_siswa/views/form.php
DEBUG - 2020-02-10 02:47:58 --> File loaded: E:\xampp\htdocs\_2020\myraport\application\views\template_utama.php
INFO - 2020-02-10 02:47:58 --> Final output sent to browser
DEBUG - 2020-02-10 02:47:58 --> Total execution time: 0.5205
INFO - 2020-02-10 02:48:22 --> Config Class Initialized
INFO - 2020-02-10 02:48:22 --> Hooks Class Initialized
DEBUG - 2020-02-10 02:48:22 --> UTF-8 Support Enabled
INFO - 2020-02-10 02:48:22 --> Utf8 Class Initialized
INFO - 2020-02-10 02:48:22 --> URI Class Initialized
INFO - 2020-02-10 02:48:22 --> Router Class Initialized
INFO - 2020-02-10 02:48:22 --> Output Class Initialized
INFO - 2020-02-10 02:48:22 --> Security Class Initialized
DEBUG - 2020-02-10 02:48:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-10 02:48:22 --> Input Class Initialized
INFO - 2020-02-10 02:48:22 --> Language Class Initialized
INFO - 2020-02-10 02:48:22 --> Language Class Initialized
INFO - 2020-02-10 02:48:22 --> Config Class Initialized
INFO - 2020-02-10 02:48:22 --> Loader Class Initialized
INFO - 2020-02-10 02:48:22 --> Helper loaded: url_helper
INFO - 2020-02-10 02:48:22 --> Helper loaded: file_helper
INFO - 2020-02-10 02:48:22 --> Helper loaded: form_helper
INFO - 2020-02-10 02:48:22 --> Helper loaded: my_helper
INFO - 2020-02-10 02:48:22 --> Database Driver Class Initialized
DEBUG - 2020-02-10 02:48:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-10 02:48:22 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-10 02:48:22 --> Controller Class Initialized
ERROR - 2020-02-10 02:48:22 --> Severity: Notice --> Undefined variable: status_form E:\xampp\htdocs\_2020\myraport\application\modules\data_siswa\views\form.php 230
DEBUG - 2020-02-10 02:48:22 --> File loaded: E:\xampp\htdocs\_2020\myraport\application\modules/data_siswa/views/form.php
DEBUG - 2020-02-10 02:48:22 --> File loaded: E:\xampp\htdocs\_2020\myraport\application\views\template_utama.php
INFO - 2020-02-10 02:48:22 --> Final output sent to browser
DEBUG - 2020-02-10 02:48:22 --> Total execution time: 0.3440
INFO - 2020-02-10 02:48:47 --> Config Class Initialized
INFO - 2020-02-10 02:48:47 --> Hooks Class Initialized
DEBUG - 2020-02-10 02:48:47 --> UTF-8 Support Enabled
INFO - 2020-02-10 02:48:47 --> Utf8 Class Initialized
INFO - 2020-02-10 02:48:47 --> URI Class Initialized
INFO - 2020-02-10 02:48:47 --> Router Class Initialized
INFO - 2020-02-10 02:48:47 --> Output Class Initialized
INFO - 2020-02-10 02:48:47 --> Security Class Initialized
DEBUG - 2020-02-10 02:48:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-10 02:48:47 --> Input Class Initialized
INFO - 2020-02-10 02:48:47 --> Language Class Initialized
INFO - 2020-02-10 02:48:47 --> Language Class Initialized
INFO - 2020-02-10 02:48:47 --> Config Class Initialized
INFO - 2020-02-10 02:48:47 --> Loader Class Initialized
INFO - 2020-02-10 02:48:47 --> Helper loaded: url_helper
INFO - 2020-02-10 02:48:47 --> Helper loaded: file_helper
INFO - 2020-02-10 02:48:48 --> Helper loaded: form_helper
INFO - 2020-02-10 02:48:48 --> Helper loaded: my_helper
INFO - 2020-02-10 02:48:48 --> Database Driver Class Initialized
DEBUG - 2020-02-10 02:48:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-10 02:48:48 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-10 02:48:48 --> Controller Class Initialized
ERROR - 2020-02-10 02:48:48 --> Severity: Notice --> Undefined variable: status_form E:\xampp\htdocs\_2020\myraport\application\modules\data_siswa\views\form.php 231
DEBUG - 2020-02-10 02:48:48 --> File loaded: E:\xampp\htdocs\_2020\myraport\application\modules/data_siswa/views/form.php
DEBUG - 2020-02-10 02:48:48 --> File loaded: E:\xampp\htdocs\_2020\myraport\application\views\template_utama.php
INFO - 2020-02-10 02:48:48 --> Final output sent to browser
DEBUG - 2020-02-10 02:48:48 --> Total execution time: 0.3562
INFO - 2020-02-10 02:55:17 --> Config Class Initialized
INFO - 2020-02-10 02:55:17 --> Hooks Class Initialized
DEBUG - 2020-02-10 02:55:17 --> UTF-8 Support Enabled
INFO - 2020-02-10 02:55:17 --> Utf8 Class Initialized
INFO - 2020-02-10 02:55:17 --> URI Class Initialized
INFO - 2020-02-10 02:55:17 --> Router Class Initialized
INFO - 2020-02-10 02:55:17 --> Output Class Initialized
INFO - 2020-02-10 02:55:17 --> Security Class Initialized
DEBUG - 2020-02-10 02:55:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-10 02:55:17 --> Input Class Initialized
INFO - 2020-02-10 02:55:17 --> Language Class Initialized
INFO - 2020-02-10 02:55:17 --> Language Class Initialized
INFO - 2020-02-10 02:55:17 --> Config Class Initialized
INFO - 2020-02-10 02:55:17 --> Loader Class Initialized
INFO - 2020-02-10 02:55:17 --> Helper loaded: url_helper
INFO - 2020-02-10 02:55:17 --> Helper loaded: file_helper
INFO - 2020-02-10 02:55:17 --> Helper loaded: form_helper
INFO - 2020-02-10 02:55:17 --> Helper loaded: my_helper
INFO - 2020-02-10 02:55:17 --> Database Driver Class Initialized
DEBUG - 2020-02-10 02:55:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-10 02:55:17 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-10 02:55:17 --> Controller Class Initialized
ERROR - 2020-02-10 02:55:17 --> Severity: Notice --> Undefined variable: status_form E:\xampp\htdocs\_2020\myraport\application\modules\data_siswa\views\form.php 231
DEBUG - 2020-02-10 02:55:17 --> File loaded: E:\xampp\htdocs\_2020\myraport\application\modules/data_siswa/views/form.php
DEBUG - 2020-02-10 02:55:17 --> File loaded: E:\xampp\htdocs\_2020\myraport\application\views\template_utama.php
INFO - 2020-02-10 02:55:17 --> Final output sent to browser
DEBUG - 2020-02-10 02:55:17 --> Total execution time: 0.3606
