<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2023-06-26 04:43:04 --> Config Class Initialized
INFO - 2023-06-26 04:43:04 --> Hooks Class Initialized
DEBUG - 2023-06-26 04:43:04 --> UTF-8 Support Enabled
INFO - 2023-06-26 04:43:04 --> Utf8 Class Initialized
INFO - 2023-06-26 04:43:04 --> URI Class Initialized
DEBUG - 2023-06-26 04:43:05 --> No URI present. Default controller set.
INFO - 2023-06-26 04:43:05 --> Router Class Initialized
INFO - 2023-06-26 04:43:05 --> Output Class Initialized
INFO - 2023-06-26 04:43:05 --> Security Class Initialized
DEBUG - 2023-06-26 04:43:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-26 04:43:05 --> Input Class Initialized
INFO - 2023-06-26 04:43:05 --> Language Class Initialized
INFO - 2023-06-26 04:43:05 --> Language Class Initialized
INFO - 2023-06-26 04:43:05 --> Config Class Initialized
INFO - 2023-06-26 04:43:05 --> Loader Class Initialized
INFO - 2023-06-26 04:43:05 --> Helper loaded: url_helper
INFO - 2023-06-26 04:43:05 --> Helper loaded: file_helper
INFO - 2023-06-26 04:43:05 --> Helper loaded: form_helper
INFO - 2023-06-26 04:43:05 --> Helper loaded: my_helper
INFO - 2023-06-26 04:43:05 --> Database Driver Class Initialized
DEBUG - 2023-06-26 04:43:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-06-26 04:43:05 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-26 04:43:05 --> Controller Class Initialized
INFO - 2023-06-26 04:43:05 --> Config Class Initialized
INFO - 2023-06-26 04:43:05 --> Hooks Class Initialized
DEBUG - 2023-06-26 04:43:05 --> UTF-8 Support Enabled
INFO - 2023-06-26 04:43:05 --> Utf8 Class Initialized
INFO - 2023-06-26 04:43:05 --> URI Class Initialized
INFO - 2023-06-26 04:43:05 --> Router Class Initialized
INFO - 2023-06-26 04:43:05 --> Output Class Initialized
INFO - 2023-06-26 04:43:05 --> Security Class Initialized
DEBUG - 2023-06-26 04:43:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-26 04:43:05 --> Input Class Initialized
INFO - 2023-06-26 04:43:05 --> Language Class Initialized
INFO - 2023-06-26 04:43:05 --> Language Class Initialized
INFO - 2023-06-26 04:43:05 --> Config Class Initialized
INFO - 2023-06-26 04:43:05 --> Loader Class Initialized
INFO - 2023-06-26 04:43:05 --> Helper loaded: url_helper
INFO - 2023-06-26 04:43:05 --> Helper loaded: file_helper
INFO - 2023-06-26 04:43:05 --> Helper loaded: form_helper
INFO - 2023-06-26 04:43:05 --> Helper loaded: my_helper
INFO - 2023-06-26 04:43:05 --> Database Driver Class Initialized
DEBUG - 2023-06-26 04:43:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-06-26 04:43:05 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-26 04:43:05 --> Controller Class Initialized
DEBUG - 2023-06-26 04:43:05 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/login/views/login.php
DEBUG - 2023-06-26 04:43:05 --> File loaded: C:\xampp\htdocs\myraportk13\application\views\template_utama.php
INFO - 2023-06-26 04:43:05 --> Final output sent to browser
DEBUG - 2023-06-26 04:43:05 --> Total execution time: 0.1086
INFO - 2023-06-26 04:43:21 --> Config Class Initialized
INFO - 2023-06-26 04:43:21 --> Hooks Class Initialized
DEBUG - 2023-06-26 04:43:21 --> UTF-8 Support Enabled
INFO - 2023-06-26 04:43:21 --> Utf8 Class Initialized
INFO - 2023-06-26 04:43:21 --> URI Class Initialized
INFO - 2023-06-26 04:43:21 --> Router Class Initialized
INFO - 2023-06-26 04:43:21 --> Output Class Initialized
INFO - 2023-06-26 04:43:21 --> Security Class Initialized
DEBUG - 2023-06-26 04:43:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-26 04:43:21 --> Input Class Initialized
INFO - 2023-06-26 04:43:21 --> Language Class Initialized
INFO - 2023-06-26 04:43:21 --> Language Class Initialized
INFO - 2023-06-26 04:43:21 --> Config Class Initialized
INFO - 2023-06-26 04:43:21 --> Loader Class Initialized
INFO - 2023-06-26 04:43:21 --> Helper loaded: url_helper
INFO - 2023-06-26 04:43:21 --> Helper loaded: file_helper
INFO - 2023-06-26 04:43:21 --> Helper loaded: form_helper
INFO - 2023-06-26 04:43:21 --> Helper loaded: my_helper
INFO - 2023-06-26 04:43:21 --> Database Driver Class Initialized
DEBUG - 2023-06-26 04:43:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-06-26 04:43:21 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-26 04:43:21 --> Controller Class Initialized
INFO - 2023-06-26 04:43:21 --> Helper loaded: cookie_helper
INFO - 2023-06-26 04:43:21 --> Final output sent to browser
DEBUG - 2023-06-26 04:43:21 --> Total execution time: 0.1344
INFO - 2023-06-26 04:43:21 --> Config Class Initialized
INFO - 2023-06-26 04:43:21 --> Hooks Class Initialized
DEBUG - 2023-06-26 04:43:21 --> UTF-8 Support Enabled
INFO - 2023-06-26 04:43:21 --> Utf8 Class Initialized
INFO - 2023-06-26 04:43:21 --> URI Class Initialized
INFO - 2023-06-26 04:43:21 --> Router Class Initialized
INFO - 2023-06-26 04:43:21 --> Output Class Initialized
INFO - 2023-06-26 04:43:21 --> Security Class Initialized
DEBUG - 2023-06-26 04:43:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-26 04:43:21 --> Input Class Initialized
INFO - 2023-06-26 04:43:21 --> Language Class Initialized
INFO - 2023-06-26 04:43:21 --> Language Class Initialized
INFO - 2023-06-26 04:43:21 --> Config Class Initialized
INFO - 2023-06-26 04:43:21 --> Loader Class Initialized
INFO - 2023-06-26 04:43:21 --> Helper loaded: url_helper
INFO - 2023-06-26 04:43:21 --> Helper loaded: file_helper
INFO - 2023-06-26 04:43:21 --> Helper loaded: form_helper
INFO - 2023-06-26 04:43:21 --> Helper loaded: my_helper
INFO - 2023-06-26 04:43:21 --> Database Driver Class Initialized
DEBUG - 2023-06-26 04:43:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-06-26 04:43:21 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-26 04:43:21 --> Controller Class Initialized
DEBUG - 2023-06-26 04:43:21 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/home/views/v_home_guru.php
DEBUG - 2023-06-26 04:43:21 --> File loaded: C:\xampp\htdocs\myraportk13\application\views\template_utama.php
INFO - 2023-06-26 04:43:21 --> Final output sent to browser
DEBUG - 2023-06-26 04:43:21 --> Total execution time: 0.1226
INFO - 2023-06-26 04:43:25 --> Config Class Initialized
INFO - 2023-06-26 04:43:25 --> Hooks Class Initialized
DEBUG - 2023-06-26 04:43:25 --> UTF-8 Support Enabled
INFO - 2023-06-26 04:43:25 --> Utf8 Class Initialized
INFO - 2023-06-26 04:43:25 --> URI Class Initialized
INFO - 2023-06-26 04:43:25 --> Router Class Initialized
INFO - 2023-06-26 04:43:25 --> Output Class Initialized
INFO - 2023-06-26 04:43:25 --> Security Class Initialized
DEBUG - 2023-06-26 04:43:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-26 04:43:25 --> Input Class Initialized
INFO - 2023-06-26 04:43:25 --> Language Class Initialized
INFO - 2023-06-26 04:43:25 --> Language Class Initialized
INFO - 2023-06-26 04:43:25 --> Config Class Initialized
INFO - 2023-06-26 04:43:25 --> Loader Class Initialized
INFO - 2023-06-26 04:43:25 --> Helper loaded: url_helper
INFO - 2023-06-26 04:43:25 --> Helper loaded: file_helper
INFO - 2023-06-26 04:43:25 --> Helper loaded: form_helper
INFO - 2023-06-26 04:43:25 --> Helper loaded: my_helper
INFO - 2023-06-26 04:43:25 --> Database Driver Class Initialized
DEBUG - 2023-06-26 04:43:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-06-26 04:43:25 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-26 04:43:25 --> Controller Class Initialized
DEBUG - 2023-06-26 04:43:25 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/n_catatan_bi/views/list.php
DEBUG - 2023-06-26 04:43:25 --> File loaded: C:\xampp\htdocs\myraportk13\application\views\template_utama.php
INFO - 2023-06-26 04:43:25 --> Final output sent to browser
DEBUG - 2023-06-26 04:43:25 --> Total execution time: 0.1207
INFO - 2023-06-26 04:43:34 --> Config Class Initialized
INFO - 2023-06-26 04:43:34 --> Hooks Class Initialized
DEBUG - 2023-06-26 04:43:34 --> UTF-8 Support Enabled
INFO - 2023-06-26 04:43:34 --> Utf8 Class Initialized
INFO - 2023-06-26 04:43:34 --> URI Class Initialized
INFO - 2023-06-26 04:43:34 --> Router Class Initialized
INFO - 2023-06-26 04:43:34 --> Output Class Initialized
INFO - 2023-06-26 04:43:34 --> Security Class Initialized
DEBUG - 2023-06-26 04:43:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-26 04:43:34 --> Input Class Initialized
INFO - 2023-06-26 04:43:34 --> Language Class Initialized
INFO - 2023-06-26 04:43:34 --> Language Class Initialized
INFO - 2023-06-26 04:43:34 --> Config Class Initialized
INFO - 2023-06-26 04:43:34 --> Loader Class Initialized
INFO - 2023-06-26 04:43:34 --> Helper loaded: url_helper
INFO - 2023-06-26 04:43:34 --> Helper loaded: file_helper
INFO - 2023-06-26 04:43:34 --> Helper loaded: form_helper
INFO - 2023-06-26 04:43:34 --> Helper loaded: my_helper
INFO - 2023-06-26 04:43:34 --> Database Driver Class Initialized
DEBUG - 2023-06-26 04:43:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-06-26 04:43:34 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-26 04:43:34 --> Controller Class Initialized
DEBUG - 2023-06-26 04:43:35 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/cetak_raport_pts/views/list.php
DEBUG - 2023-06-26 04:43:35 --> File loaded: C:\xampp\htdocs\myraportk13\application\views\template_utama.php
INFO - 2023-06-26 04:43:35 --> Final output sent to browser
DEBUG - 2023-06-26 04:43:35 --> Total execution time: 0.0970
INFO - 2023-06-26 04:43:37 --> Config Class Initialized
INFO - 2023-06-26 04:43:37 --> Hooks Class Initialized
DEBUG - 2023-06-26 04:43:37 --> UTF-8 Support Enabled
INFO - 2023-06-26 04:43:37 --> Utf8 Class Initialized
INFO - 2023-06-26 04:43:37 --> URI Class Initialized
INFO - 2023-06-26 04:43:37 --> Router Class Initialized
INFO - 2023-06-26 04:43:37 --> Output Class Initialized
INFO - 2023-06-26 04:43:37 --> Security Class Initialized
DEBUG - 2023-06-26 04:43:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-26 04:43:37 --> Input Class Initialized
INFO - 2023-06-26 04:43:37 --> Language Class Initialized
INFO - 2023-06-26 04:43:37 --> Language Class Initialized
INFO - 2023-06-26 04:43:37 --> Config Class Initialized
INFO - 2023-06-26 04:43:37 --> Loader Class Initialized
INFO - 2023-06-26 04:43:37 --> Helper loaded: url_helper
INFO - 2023-06-26 04:43:37 --> Helper loaded: file_helper
INFO - 2023-06-26 04:43:37 --> Helper loaded: form_helper
INFO - 2023-06-26 04:43:37 --> Helper loaded: my_helper
INFO - 2023-06-26 04:43:37 --> Database Driver Class Initialized
DEBUG - 2023-06-26 04:43:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-06-26 04:43:37 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-26 04:43:37 --> Controller Class Initialized
DEBUG - 2023-06-26 04:43:37 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/cetak_raport_pts/views/cetak_pts_mh.php
INFO - 2023-06-26 04:43:39 --> Final output sent to browser
DEBUG - 2023-06-26 04:43:39 --> Total execution time: 2.6917
INFO - 2023-06-26 04:43:51 --> Config Class Initialized
INFO - 2023-06-26 04:43:51 --> Hooks Class Initialized
DEBUG - 2023-06-26 04:43:51 --> UTF-8 Support Enabled
INFO - 2023-06-26 04:43:51 --> Utf8 Class Initialized
INFO - 2023-06-26 04:43:51 --> URI Class Initialized
INFO - 2023-06-26 04:43:51 --> Router Class Initialized
INFO - 2023-06-26 04:43:51 --> Output Class Initialized
INFO - 2023-06-26 04:43:51 --> Security Class Initialized
DEBUG - 2023-06-26 04:43:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-26 04:43:51 --> Input Class Initialized
INFO - 2023-06-26 04:43:51 --> Language Class Initialized
ERROR - 2023-06-26 04:43:51 --> 404 Page Not Found: ../modules/cetak_raport_pts/controllers/Cetak_raport_pts/preschool
INFO - 2023-06-26 04:44:49 --> Config Class Initialized
INFO - 2023-06-26 04:44:49 --> Hooks Class Initialized
DEBUG - 2023-06-26 04:44:49 --> UTF-8 Support Enabled
INFO - 2023-06-26 04:44:49 --> Utf8 Class Initialized
INFO - 2023-06-26 04:44:49 --> URI Class Initialized
INFO - 2023-06-26 04:44:49 --> Router Class Initialized
INFO - 2023-06-26 04:44:49 --> Output Class Initialized
INFO - 2023-06-26 04:44:49 --> Security Class Initialized
DEBUG - 2023-06-26 04:44:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-26 04:44:49 --> Input Class Initialized
INFO - 2023-06-26 04:44:49 --> Language Class Initialized
INFO - 2023-06-26 04:44:49 --> Language Class Initialized
INFO - 2023-06-26 04:44:49 --> Config Class Initialized
INFO - 2023-06-26 04:44:49 --> Loader Class Initialized
INFO - 2023-06-26 04:44:49 --> Helper loaded: url_helper
INFO - 2023-06-26 04:44:49 --> Helper loaded: file_helper
INFO - 2023-06-26 04:44:49 --> Helper loaded: form_helper
INFO - 2023-06-26 04:44:49 --> Helper loaded: my_helper
INFO - 2023-06-26 04:44:49 --> Database Driver Class Initialized
DEBUG - 2023-06-26 04:44:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-06-26 04:44:49 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-26 04:44:49 --> Controller Class Initialized
DEBUG - 2023-06-26 04:44:49 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/cetak_raport_pts/views/cetak_pts_preschool.php
INFO - 2023-06-26 04:44:51 --> Final output sent to browser
DEBUG - 2023-06-26 04:44:51 --> Total execution time: 1.7121
INFO - 2023-06-26 04:45:14 --> Config Class Initialized
INFO - 2023-06-26 04:45:14 --> Hooks Class Initialized
DEBUG - 2023-06-26 04:45:14 --> UTF-8 Support Enabled
INFO - 2023-06-26 04:45:14 --> Utf8 Class Initialized
INFO - 2023-06-26 04:45:14 --> URI Class Initialized
DEBUG - 2023-06-26 04:45:14 --> No URI present. Default controller set.
INFO - 2023-06-26 04:45:14 --> Router Class Initialized
INFO - 2023-06-26 04:45:14 --> Output Class Initialized
INFO - 2023-06-26 04:45:14 --> Security Class Initialized
DEBUG - 2023-06-26 04:45:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-26 04:45:14 --> Input Class Initialized
INFO - 2023-06-26 04:45:14 --> Language Class Initialized
INFO - 2023-06-26 04:45:14 --> Language Class Initialized
INFO - 2023-06-26 04:45:14 --> Config Class Initialized
INFO - 2023-06-26 04:45:14 --> Loader Class Initialized
INFO - 2023-06-26 04:45:14 --> Helper loaded: url_helper
INFO - 2023-06-26 04:45:14 --> Helper loaded: file_helper
INFO - 2023-06-26 04:45:14 --> Helper loaded: form_helper
INFO - 2023-06-26 04:45:14 --> Helper loaded: my_helper
INFO - 2023-06-26 04:45:14 --> Database Driver Class Initialized
DEBUG - 2023-06-26 04:45:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-06-26 04:45:14 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-26 04:45:14 --> Controller Class Initialized
DEBUG - 2023-06-26 04:45:14 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/home/views/v_home_guru.php
DEBUG - 2023-06-26 04:45:14 --> File loaded: C:\xampp\htdocs\myraportk13\application\views\template_utama.php
INFO - 2023-06-26 04:45:14 --> Final output sent to browser
DEBUG - 2023-06-26 04:45:14 --> Total execution time: 0.0546
INFO - 2023-06-26 04:47:17 --> Config Class Initialized
INFO - 2023-06-26 04:47:17 --> Hooks Class Initialized
DEBUG - 2023-06-26 04:47:17 --> UTF-8 Support Enabled
INFO - 2023-06-26 04:47:17 --> Utf8 Class Initialized
INFO - 2023-06-26 04:47:17 --> URI Class Initialized
DEBUG - 2023-06-26 04:47:17 --> No URI present. Default controller set.
INFO - 2023-06-26 04:47:17 --> Router Class Initialized
INFO - 2023-06-26 04:47:17 --> Output Class Initialized
INFO - 2023-06-26 04:47:17 --> Security Class Initialized
DEBUG - 2023-06-26 04:47:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-26 04:47:17 --> Input Class Initialized
INFO - 2023-06-26 04:47:17 --> Language Class Initialized
INFO - 2023-06-26 04:47:17 --> Language Class Initialized
INFO - 2023-06-26 04:47:17 --> Config Class Initialized
INFO - 2023-06-26 04:47:17 --> Loader Class Initialized
INFO - 2023-06-26 04:47:17 --> Helper loaded: url_helper
INFO - 2023-06-26 04:47:17 --> Helper loaded: file_helper
INFO - 2023-06-26 04:47:17 --> Helper loaded: form_helper
INFO - 2023-06-26 04:47:17 --> Helper loaded: my_helper
INFO - 2023-06-26 04:47:17 --> Database Driver Class Initialized
DEBUG - 2023-06-26 04:47:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-06-26 04:47:17 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-26 04:47:17 --> Controller Class Initialized
DEBUG - 2023-06-26 04:47:17 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/home/views/v_home_guru.php
DEBUG - 2023-06-26 04:47:17 --> File loaded: C:\xampp\htdocs\myraportk13\application\views\template_utama.php
INFO - 2023-06-26 04:47:17 --> Final output sent to browser
DEBUG - 2023-06-26 04:47:17 --> Total execution time: 0.0681
INFO - 2023-06-26 04:47:52 --> Config Class Initialized
INFO - 2023-06-26 04:47:52 --> Hooks Class Initialized
DEBUG - 2023-06-26 04:47:52 --> UTF-8 Support Enabled
INFO - 2023-06-26 04:47:52 --> Utf8 Class Initialized
INFO - 2023-06-26 04:47:52 --> URI Class Initialized
DEBUG - 2023-06-26 04:47:52 --> No URI present. Default controller set.
INFO - 2023-06-26 04:47:52 --> Router Class Initialized
INFO - 2023-06-26 04:47:52 --> Output Class Initialized
INFO - 2023-06-26 04:47:52 --> Security Class Initialized
DEBUG - 2023-06-26 04:47:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-26 04:47:52 --> Input Class Initialized
INFO - 2023-06-26 04:47:52 --> Language Class Initialized
INFO - 2023-06-26 04:47:52 --> Language Class Initialized
INFO - 2023-06-26 04:47:52 --> Config Class Initialized
INFO - 2023-06-26 04:47:52 --> Loader Class Initialized
INFO - 2023-06-26 04:47:52 --> Helper loaded: url_helper
INFO - 2023-06-26 04:47:52 --> Helper loaded: file_helper
INFO - 2023-06-26 04:47:52 --> Helper loaded: form_helper
INFO - 2023-06-26 04:47:52 --> Helper loaded: my_helper
INFO - 2023-06-26 04:47:52 --> Database Driver Class Initialized
DEBUG - 2023-06-26 04:47:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-06-26 04:47:52 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-26 04:47:52 --> Controller Class Initialized
DEBUG - 2023-06-26 04:47:52 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/home/views/v_home_guru.php
DEBUG - 2023-06-26 04:47:52 --> File loaded: C:\xampp\htdocs\myraportk13\application\views\template_utama.php
INFO - 2023-06-26 04:47:52 --> Final output sent to browser
DEBUG - 2023-06-26 04:47:52 --> Total execution time: 0.0726
INFO - 2023-06-26 04:49:25 --> Config Class Initialized
INFO - 2023-06-26 04:49:25 --> Hooks Class Initialized
DEBUG - 2023-06-26 04:49:25 --> UTF-8 Support Enabled
INFO - 2023-06-26 04:49:25 --> Utf8 Class Initialized
INFO - 2023-06-26 04:49:25 --> URI Class Initialized
DEBUG - 2023-06-26 04:49:25 --> No URI present. Default controller set.
INFO - 2023-06-26 04:49:25 --> Router Class Initialized
INFO - 2023-06-26 04:49:25 --> Output Class Initialized
INFO - 2023-06-26 04:49:25 --> Security Class Initialized
DEBUG - 2023-06-26 04:49:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-26 04:49:25 --> Input Class Initialized
INFO - 2023-06-26 04:49:25 --> Language Class Initialized
INFO - 2023-06-26 04:49:25 --> Language Class Initialized
INFO - 2023-06-26 04:49:25 --> Config Class Initialized
INFO - 2023-06-26 04:49:25 --> Loader Class Initialized
INFO - 2023-06-26 04:49:25 --> Helper loaded: url_helper
INFO - 2023-06-26 04:49:25 --> Helper loaded: file_helper
INFO - 2023-06-26 04:49:25 --> Helper loaded: form_helper
INFO - 2023-06-26 04:49:25 --> Helper loaded: my_helper
INFO - 2023-06-26 04:49:25 --> Database Driver Class Initialized
DEBUG - 2023-06-26 04:49:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-06-26 04:49:25 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-26 04:49:25 --> Controller Class Initialized
DEBUG - 2023-06-26 04:49:25 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/home/views/v_home_guru.php
DEBUG - 2023-06-26 04:49:25 --> File loaded: C:\xampp\htdocs\myraportk13\application\views\template_utama.php
INFO - 2023-06-26 04:49:25 --> Final output sent to browser
DEBUG - 2023-06-26 04:49:25 --> Total execution time: 0.0835
INFO - 2023-06-26 04:50:45 --> Config Class Initialized
INFO - 2023-06-26 04:50:45 --> Hooks Class Initialized
DEBUG - 2023-06-26 04:50:45 --> UTF-8 Support Enabled
INFO - 2023-06-26 04:50:45 --> Utf8 Class Initialized
INFO - 2023-06-26 04:50:45 --> URI Class Initialized
INFO - 2023-06-26 04:50:45 --> Router Class Initialized
INFO - 2023-06-26 04:50:45 --> Output Class Initialized
INFO - 2023-06-26 04:50:45 --> Security Class Initialized
DEBUG - 2023-06-26 04:50:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-26 04:50:45 --> Input Class Initialized
INFO - 2023-06-26 04:50:45 --> Language Class Initialized
INFO - 2023-06-26 04:50:45 --> Language Class Initialized
INFO - 2023-06-26 04:50:45 --> Config Class Initialized
INFO - 2023-06-26 04:50:45 --> Loader Class Initialized
INFO - 2023-06-26 04:50:45 --> Helper loaded: url_helper
INFO - 2023-06-26 04:50:45 --> Helper loaded: file_helper
INFO - 2023-06-26 04:50:45 --> Helper loaded: form_helper
INFO - 2023-06-26 04:50:45 --> Helper loaded: my_helper
INFO - 2023-06-26 04:50:45 --> Database Driver Class Initialized
DEBUG - 2023-06-26 04:50:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-06-26 04:50:45 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-26 04:50:45 --> Controller Class Initialized
DEBUG - 2023-06-26 04:50:45 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/view_mapel/views/v_view_mapel.php
DEBUG - 2023-06-26 04:50:45 --> File loaded: C:\xampp\htdocs\myraportk13\application\views\template_utama.php
INFO - 2023-06-26 04:50:45 --> Final output sent to browser
DEBUG - 2023-06-26 04:50:45 --> Total execution time: 0.0438
INFO - 2023-06-26 04:51:16 --> Config Class Initialized
INFO - 2023-06-26 04:51:16 --> Hooks Class Initialized
DEBUG - 2023-06-26 04:51:16 --> UTF-8 Support Enabled
INFO - 2023-06-26 04:51:16 --> Utf8 Class Initialized
INFO - 2023-06-26 04:51:16 --> URI Class Initialized
INFO - 2023-06-26 04:51:16 --> Router Class Initialized
INFO - 2023-06-26 04:51:16 --> Output Class Initialized
INFO - 2023-06-26 04:51:16 --> Security Class Initialized
DEBUG - 2023-06-26 04:51:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-26 04:51:16 --> Input Class Initialized
INFO - 2023-06-26 04:51:16 --> Language Class Initialized
INFO - 2023-06-26 04:51:16 --> Language Class Initialized
INFO - 2023-06-26 04:51:16 --> Config Class Initialized
INFO - 2023-06-26 04:51:16 --> Loader Class Initialized
INFO - 2023-06-26 04:51:16 --> Helper loaded: url_helper
INFO - 2023-06-26 04:51:16 --> Helper loaded: file_helper
INFO - 2023-06-26 04:51:16 --> Helper loaded: form_helper
INFO - 2023-06-26 04:51:16 --> Helper loaded: my_helper
INFO - 2023-06-26 04:51:16 --> Database Driver Class Initialized
DEBUG - 2023-06-26 04:51:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-06-26 04:51:16 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-26 04:51:16 --> Controller Class Initialized
DEBUG - 2023-06-26 04:51:16 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/view_mapel/views/v_view_mapel.php
DEBUG - 2023-06-26 04:51:16 --> File loaded: C:\xampp\htdocs\myraportk13\application\views\template_utama.php
INFO - 2023-06-26 04:51:16 --> Final output sent to browser
DEBUG - 2023-06-26 04:51:16 --> Total execution time: 0.0780
INFO - 2023-06-26 04:51:19 --> Config Class Initialized
INFO - 2023-06-26 04:51:19 --> Hooks Class Initialized
DEBUG - 2023-06-26 04:51:19 --> UTF-8 Support Enabled
INFO - 2023-06-26 04:51:19 --> Utf8 Class Initialized
INFO - 2023-06-26 04:51:19 --> URI Class Initialized
INFO - 2023-06-26 04:51:19 --> Router Class Initialized
INFO - 2023-06-26 04:51:19 --> Output Class Initialized
INFO - 2023-06-26 04:51:19 --> Security Class Initialized
DEBUG - 2023-06-26 04:51:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-26 04:51:19 --> Input Class Initialized
INFO - 2023-06-26 04:51:19 --> Language Class Initialized
INFO - 2023-06-26 04:51:19 --> Language Class Initialized
INFO - 2023-06-26 04:51:19 --> Config Class Initialized
INFO - 2023-06-26 04:51:19 --> Loader Class Initialized
INFO - 2023-06-26 04:51:19 --> Helper loaded: url_helper
INFO - 2023-06-26 04:51:19 --> Helper loaded: file_helper
INFO - 2023-06-26 04:51:19 --> Helper loaded: form_helper
INFO - 2023-06-26 04:51:19 --> Helper loaded: my_helper
INFO - 2023-06-26 04:51:19 --> Database Driver Class Initialized
DEBUG - 2023-06-26 04:51:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-06-26 04:51:19 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-26 04:51:19 --> Controller Class Initialized
DEBUG - 2023-06-26 04:51:19 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/riwayat_mengajar/views/list.php
DEBUG - 2023-06-26 04:51:19 --> File loaded: C:\xampp\htdocs\myraportk13\application\views\template_utama.php
INFO - 2023-06-26 04:51:19 --> Final output sent to browser
DEBUG - 2023-06-26 04:51:19 --> Total execution time: 0.0416
INFO - 2023-06-26 04:51:22 --> Config Class Initialized
INFO - 2023-06-26 04:51:22 --> Hooks Class Initialized
DEBUG - 2023-06-26 04:51:22 --> UTF-8 Support Enabled
INFO - 2023-06-26 04:51:22 --> Utf8 Class Initialized
INFO - 2023-06-26 04:51:22 --> URI Class Initialized
INFO - 2023-06-26 04:51:22 --> Router Class Initialized
INFO - 2023-06-26 04:51:22 --> Output Class Initialized
INFO - 2023-06-26 04:51:22 --> Security Class Initialized
DEBUG - 2023-06-26 04:51:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-26 04:51:22 --> Input Class Initialized
INFO - 2023-06-26 04:51:22 --> Language Class Initialized
INFO - 2023-06-26 04:51:22 --> Language Class Initialized
INFO - 2023-06-26 04:51:22 --> Config Class Initialized
INFO - 2023-06-26 04:51:22 --> Loader Class Initialized
INFO - 2023-06-26 04:51:22 --> Helper loaded: url_helper
INFO - 2023-06-26 04:51:22 --> Helper loaded: file_helper
INFO - 2023-06-26 04:51:22 --> Helper loaded: form_helper
INFO - 2023-06-26 04:51:22 --> Helper loaded: my_helper
INFO - 2023-06-26 04:51:22 --> Database Driver Class Initialized
DEBUG - 2023-06-26 04:51:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-06-26 04:51:22 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-26 04:51:22 --> Controller Class Initialized
DEBUG - 2023-06-26 04:51:22 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/view_mapel/views/v_view_mapel.php
DEBUG - 2023-06-26 04:51:22 --> File loaded: C:\xampp\htdocs\myraportk13\application\views\template_utama.php
INFO - 2023-06-26 04:51:22 --> Final output sent to browser
DEBUG - 2023-06-26 04:51:22 --> Total execution time: 0.0425
INFO - 2023-06-26 04:51:46 --> Config Class Initialized
INFO - 2023-06-26 04:51:46 --> Hooks Class Initialized
DEBUG - 2023-06-26 04:51:46 --> UTF-8 Support Enabled
INFO - 2023-06-26 04:51:46 --> Utf8 Class Initialized
INFO - 2023-06-26 04:51:46 --> URI Class Initialized
INFO - 2023-06-26 04:51:46 --> Router Class Initialized
INFO - 2023-06-26 04:51:46 --> Output Class Initialized
INFO - 2023-06-26 04:51:46 --> Security Class Initialized
DEBUG - 2023-06-26 04:51:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-26 04:51:46 --> Input Class Initialized
INFO - 2023-06-26 04:51:46 --> Language Class Initialized
INFO - 2023-06-26 04:51:46 --> Language Class Initialized
INFO - 2023-06-26 04:51:46 --> Config Class Initialized
INFO - 2023-06-26 04:51:46 --> Loader Class Initialized
INFO - 2023-06-26 04:51:46 --> Helper loaded: url_helper
INFO - 2023-06-26 04:51:46 --> Helper loaded: file_helper
INFO - 2023-06-26 04:51:46 --> Helper loaded: form_helper
INFO - 2023-06-26 04:51:46 --> Helper loaded: my_helper
INFO - 2023-06-26 04:51:46 --> Database Driver Class Initialized
DEBUG - 2023-06-26 04:51:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-06-26 04:51:46 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-26 04:51:46 --> Controller Class Initialized
DEBUG - 2023-06-26 04:51:46 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/riwayat_mengajar/views/list.php
DEBUG - 2023-06-26 04:51:46 --> File loaded: C:\xampp\htdocs\myraportk13\application\views\template_utama.php
INFO - 2023-06-26 04:51:46 --> Final output sent to browser
DEBUG - 2023-06-26 04:51:46 --> Total execution time: 0.0413
INFO - 2023-06-26 04:51:54 --> Config Class Initialized
INFO - 2023-06-26 04:51:54 --> Hooks Class Initialized
DEBUG - 2023-06-26 04:51:54 --> UTF-8 Support Enabled
INFO - 2023-06-26 04:51:54 --> Utf8 Class Initialized
INFO - 2023-06-26 04:51:54 --> URI Class Initialized
INFO - 2023-06-26 04:51:54 --> Router Class Initialized
INFO - 2023-06-26 04:51:54 --> Output Class Initialized
INFO - 2023-06-26 04:51:54 --> Security Class Initialized
DEBUG - 2023-06-26 04:51:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-26 04:51:54 --> Input Class Initialized
INFO - 2023-06-26 04:51:54 --> Language Class Initialized
INFO - 2023-06-26 04:51:54 --> Language Class Initialized
INFO - 2023-06-26 04:51:54 --> Config Class Initialized
INFO - 2023-06-26 04:51:54 --> Loader Class Initialized
INFO - 2023-06-26 04:51:54 --> Helper loaded: url_helper
INFO - 2023-06-26 04:51:54 --> Helper loaded: file_helper
INFO - 2023-06-26 04:51:54 --> Helper loaded: form_helper
INFO - 2023-06-26 04:51:54 --> Helper loaded: my_helper
INFO - 2023-06-26 04:51:54 --> Database Driver Class Initialized
DEBUG - 2023-06-26 04:51:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-06-26 04:51:54 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-26 04:51:54 --> Controller Class Initialized
DEBUG - 2023-06-26 04:51:54 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/n_sikap_sp/views/list.php
DEBUG - 2023-06-26 04:51:54 --> File loaded: C:\xampp\htdocs\myraportk13\application\views\template_utama.php
INFO - 2023-06-26 04:51:54 --> Final output sent to browser
DEBUG - 2023-06-26 04:51:54 --> Total execution time: 0.0467
INFO - 2023-06-26 04:51:56 --> Config Class Initialized
INFO - 2023-06-26 04:51:56 --> Hooks Class Initialized
DEBUG - 2023-06-26 04:51:56 --> UTF-8 Support Enabled
INFO - 2023-06-26 04:51:56 --> Utf8 Class Initialized
INFO - 2023-06-26 04:51:56 --> URI Class Initialized
INFO - 2023-06-26 04:51:56 --> Router Class Initialized
INFO - 2023-06-26 04:51:56 --> Output Class Initialized
INFO - 2023-06-26 04:51:56 --> Security Class Initialized
DEBUG - 2023-06-26 04:51:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-26 04:51:56 --> Input Class Initialized
INFO - 2023-06-26 04:51:56 --> Language Class Initialized
INFO - 2023-06-26 04:51:56 --> Language Class Initialized
INFO - 2023-06-26 04:51:56 --> Config Class Initialized
INFO - 2023-06-26 04:51:56 --> Loader Class Initialized
INFO - 2023-06-26 04:51:56 --> Helper loaded: url_helper
INFO - 2023-06-26 04:51:56 --> Helper loaded: file_helper
INFO - 2023-06-26 04:51:56 --> Helper loaded: form_helper
INFO - 2023-06-26 04:51:56 --> Helper loaded: my_helper
INFO - 2023-06-26 04:51:56 --> Database Driver Class Initialized
DEBUG - 2023-06-26 04:51:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-06-26 04:51:56 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-26 04:51:56 --> Controller Class Initialized
DEBUG - 2023-06-26 04:51:56 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/n_sikap_so/views/list.php
DEBUG - 2023-06-26 04:51:56 --> File loaded: C:\xampp\htdocs\myraportk13\application\views\template_utama.php
INFO - 2023-06-26 04:51:56 --> Final output sent to browser
DEBUG - 2023-06-26 04:51:56 --> Total execution time: 0.0551
INFO - 2023-06-26 04:52:05 --> Config Class Initialized
INFO - 2023-06-26 04:52:05 --> Hooks Class Initialized
DEBUG - 2023-06-26 04:52:05 --> UTF-8 Support Enabled
INFO - 2023-06-26 04:52:05 --> Utf8 Class Initialized
INFO - 2023-06-26 04:52:05 --> URI Class Initialized
INFO - 2023-06-26 04:52:05 --> Router Class Initialized
INFO - 2023-06-26 04:52:05 --> Output Class Initialized
INFO - 2023-06-26 04:52:05 --> Security Class Initialized
DEBUG - 2023-06-26 04:52:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-26 04:52:05 --> Input Class Initialized
INFO - 2023-06-26 04:52:05 --> Language Class Initialized
INFO - 2023-06-26 04:52:05 --> Language Class Initialized
INFO - 2023-06-26 04:52:05 --> Config Class Initialized
INFO - 2023-06-26 04:52:05 --> Loader Class Initialized
INFO - 2023-06-26 04:52:05 --> Helper loaded: url_helper
INFO - 2023-06-26 04:52:05 --> Helper loaded: file_helper
INFO - 2023-06-26 04:52:05 --> Helper loaded: form_helper
INFO - 2023-06-26 04:52:05 --> Helper loaded: my_helper
INFO - 2023-06-26 04:52:05 --> Database Driver Class Initialized
DEBUG - 2023-06-26 04:52:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-06-26 04:52:05 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-26 04:52:05 --> Controller Class Initialized
DEBUG - 2023-06-26 04:52:05 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/n_catatan_kl1/views/list.php
DEBUG - 2023-06-26 04:52:05 --> File loaded: C:\xampp\htdocs\myraportk13\application\views\template_utama.php
INFO - 2023-06-26 04:52:05 --> Final output sent to browser
DEBUG - 2023-06-26 04:52:05 --> Total execution time: 0.0653
INFO - 2023-06-26 04:52:25 --> Config Class Initialized
INFO - 2023-06-26 04:52:25 --> Hooks Class Initialized
DEBUG - 2023-06-26 04:52:25 --> UTF-8 Support Enabled
INFO - 2023-06-26 04:52:25 --> Utf8 Class Initialized
INFO - 2023-06-26 04:52:25 --> URI Class Initialized
INFO - 2023-06-26 04:52:25 --> Router Class Initialized
INFO - 2023-06-26 04:52:25 --> Output Class Initialized
INFO - 2023-06-26 04:52:25 --> Security Class Initialized
DEBUG - 2023-06-26 04:52:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-26 04:52:25 --> Input Class Initialized
INFO - 2023-06-26 04:52:25 --> Language Class Initialized
INFO - 2023-06-26 04:52:25 --> Language Class Initialized
INFO - 2023-06-26 04:52:25 --> Config Class Initialized
INFO - 2023-06-26 04:52:25 --> Loader Class Initialized
INFO - 2023-06-26 04:52:25 --> Helper loaded: url_helper
INFO - 2023-06-26 04:52:25 --> Helper loaded: file_helper
INFO - 2023-06-26 04:52:25 --> Helper loaded: form_helper
INFO - 2023-06-26 04:52:25 --> Helper loaded: my_helper
INFO - 2023-06-26 04:52:25 --> Database Driver Class Initialized
DEBUG - 2023-06-26 04:52:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-06-26 04:52:25 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-26 04:52:25 --> Controller Class Initialized
DEBUG - 2023-06-26 04:52:25 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/n_absensi/views/list.php
DEBUG - 2023-06-26 04:52:25 --> File loaded: C:\xampp\htdocs\myraportk13\application\views\template_utama.php
INFO - 2023-06-26 04:52:25 --> Final output sent to browser
DEBUG - 2023-06-26 04:52:25 --> Total execution time: 0.0444
INFO - 2023-06-26 04:52:27 --> Config Class Initialized
INFO - 2023-06-26 04:52:27 --> Hooks Class Initialized
DEBUG - 2023-06-26 04:52:27 --> UTF-8 Support Enabled
INFO - 2023-06-26 04:52:27 --> Utf8 Class Initialized
INFO - 2023-06-26 04:52:27 --> URI Class Initialized
INFO - 2023-06-26 04:52:27 --> Router Class Initialized
INFO - 2023-06-26 04:52:27 --> Output Class Initialized
INFO - 2023-06-26 04:52:27 --> Security Class Initialized
DEBUG - 2023-06-26 04:52:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-26 04:52:27 --> Input Class Initialized
INFO - 2023-06-26 04:52:27 --> Language Class Initialized
INFO - 2023-06-26 04:52:27 --> Language Class Initialized
INFO - 2023-06-26 04:52:27 --> Config Class Initialized
INFO - 2023-06-26 04:52:27 --> Loader Class Initialized
INFO - 2023-06-26 04:52:27 --> Helper loaded: url_helper
INFO - 2023-06-26 04:52:27 --> Helper loaded: file_helper
INFO - 2023-06-26 04:52:27 --> Helper loaded: form_helper
INFO - 2023-06-26 04:52:27 --> Helper loaded: my_helper
INFO - 2023-06-26 04:52:27 --> Database Driver Class Initialized
DEBUG - 2023-06-26 04:52:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-06-26 04:52:27 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-26 04:52:27 --> Controller Class Initialized
DEBUG - 2023-06-26 04:52:27 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/n_ekstra/views/list.php
DEBUG - 2023-06-26 04:52:27 --> File loaded: C:\xampp\htdocs\myraportk13\application\views\template_utama.php
INFO - 2023-06-26 04:52:27 --> Final output sent to browser
DEBUG - 2023-06-26 04:52:27 --> Total execution time: 0.0530
INFO - 2023-06-26 04:52:31 --> Config Class Initialized
INFO - 2023-06-26 04:52:31 --> Hooks Class Initialized
DEBUG - 2023-06-26 04:52:31 --> UTF-8 Support Enabled
INFO - 2023-06-26 04:52:31 --> Utf8 Class Initialized
INFO - 2023-06-26 04:52:31 --> URI Class Initialized
INFO - 2023-06-26 04:52:31 --> Router Class Initialized
INFO - 2023-06-26 04:52:31 --> Output Class Initialized
INFO - 2023-06-26 04:52:31 --> Security Class Initialized
DEBUG - 2023-06-26 04:52:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-26 04:52:31 --> Input Class Initialized
INFO - 2023-06-26 04:52:31 --> Language Class Initialized
INFO - 2023-06-26 04:52:31 --> Language Class Initialized
INFO - 2023-06-26 04:52:31 --> Config Class Initialized
INFO - 2023-06-26 04:52:31 --> Loader Class Initialized
INFO - 2023-06-26 04:52:31 --> Helper loaded: url_helper
INFO - 2023-06-26 04:52:31 --> Helper loaded: file_helper
INFO - 2023-06-26 04:52:31 --> Helper loaded: form_helper
INFO - 2023-06-26 04:52:31 --> Helper loaded: my_helper
INFO - 2023-06-26 04:52:31 --> Database Driver Class Initialized
DEBUG - 2023-06-26 04:52:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-06-26 04:52:31 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-26 04:52:31 --> Controller Class Initialized
DEBUG - 2023-06-26 04:52:31 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/n_prestasi/views/list.php
DEBUG - 2023-06-26 04:52:31 --> File loaded: C:\xampp\htdocs\myraportk13\application\views\template_utama.php
INFO - 2023-06-26 04:52:31 --> Final output sent to browser
DEBUG - 2023-06-26 04:52:31 --> Total execution time: 0.0443
INFO - 2023-06-26 04:52:31 --> Config Class Initialized
INFO - 2023-06-26 04:52:31 --> Hooks Class Initialized
DEBUG - 2023-06-26 04:52:31 --> UTF-8 Support Enabled
INFO - 2023-06-26 04:52:31 --> Utf8 Class Initialized
INFO - 2023-06-26 04:52:31 --> URI Class Initialized
INFO - 2023-06-26 04:52:31 --> Router Class Initialized
INFO - 2023-06-26 04:52:31 --> Output Class Initialized
INFO - 2023-06-26 04:52:31 --> Security Class Initialized
DEBUG - 2023-06-26 04:52:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-26 04:52:31 --> Input Class Initialized
INFO - 2023-06-26 04:52:31 --> Language Class Initialized
INFO - 2023-06-26 04:52:31 --> Language Class Initialized
INFO - 2023-06-26 04:52:31 --> Config Class Initialized
INFO - 2023-06-26 04:52:31 --> Loader Class Initialized
INFO - 2023-06-26 04:52:31 --> Helper loaded: url_helper
INFO - 2023-06-26 04:52:31 --> Helper loaded: file_helper
INFO - 2023-06-26 04:52:31 --> Helper loaded: form_helper
INFO - 2023-06-26 04:52:31 --> Helper loaded: my_helper
INFO - 2023-06-26 04:52:31 --> Database Driver Class Initialized
DEBUG - 2023-06-26 04:52:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-06-26 04:52:31 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-26 04:52:31 --> Controller Class Initialized
INFO - 2023-06-26 04:52:41 --> Config Class Initialized
INFO - 2023-06-26 04:52:41 --> Hooks Class Initialized
DEBUG - 2023-06-26 04:52:41 --> UTF-8 Support Enabled
INFO - 2023-06-26 04:52:41 --> Utf8 Class Initialized
INFO - 2023-06-26 04:52:41 --> URI Class Initialized
DEBUG - 2023-06-26 04:52:41 --> No URI present. Default controller set.
INFO - 2023-06-26 04:52:41 --> Router Class Initialized
INFO - 2023-06-26 04:52:41 --> Output Class Initialized
INFO - 2023-06-26 04:52:41 --> Security Class Initialized
DEBUG - 2023-06-26 04:52:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-26 04:52:41 --> Input Class Initialized
INFO - 2023-06-26 04:52:41 --> Language Class Initialized
INFO - 2023-06-26 04:52:41 --> Language Class Initialized
INFO - 2023-06-26 04:52:41 --> Config Class Initialized
INFO - 2023-06-26 04:52:41 --> Loader Class Initialized
INFO - 2023-06-26 04:52:41 --> Helper loaded: url_helper
INFO - 2023-06-26 04:52:41 --> Helper loaded: file_helper
INFO - 2023-06-26 04:52:41 --> Helper loaded: form_helper
INFO - 2023-06-26 04:52:41 --> Helper loaded: my_helper
INFO - 2023-06-26 04:52:41 --> Database Driver Class Initialized
DEBUG - 2023-06-26 04:52:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-06-26 04:52:41 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-26 04:52:41 --> Controller Class Initialized
DEBUG - 2023-06-26 04:52:41 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/home/views/v_home_guru.php
DEBUG - 2023-06-26 04:52:41 --> File loaded: C:\xampp\htdocs\myraportk13\application\views\template_utama.php
INFO - 2023-06-26 04:52:41 --> Final output sent to browser
DEBUG - 2023-06-26 04:52:41 --> Total execution time: 0.0454
INFO - 2023-06-26 04:52:43 --> Config Class Initialized
INFO - 2023-06-26 04:52:43 --> Hooks Class Initialized
DEBUG - 2023-06-26 04:52:43 --> UTF-8 Support Enabled
INFO - 2023-06-26 04:52:43 --> Utf8 Class Initialized
INFO - 2023-06-26 04:52:43 --> URI Class Initialized
INFO - 2023-06-26 04:52:43 --> Router Class Initialized
INFO - 2023-06-26 04:52:43 --> Output Class Initialized
INFO - 2023-06-26 04:52:43 --> Security Class Initialized
DEBUG - 2023-06-26 04:52:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-26 04:52:43 --> Input Class Initialized
INFO - 2023-06-26 04:52:43 --> Language Class Initialized
INFO - 2023-06-26 04:52:43 --> Language Class Initialized
INFO - 2023-06-26 04:52:43 --> Config Class Initialized
INFO - 2023-06-26 04:52:43 --> Loader Class Initialized
INFO - 2023-06-26 04:52:43 --> Helper loaded: url_helper
INFO - 2023-06-26 04:52:43 --> Helper loaded: file_helper
INFO - 2023-06-26 04:52:43 --> Helper loaded: form_helper
INFO - 2023-06-26 04:52:43 --> Helper loaded: my_helper
INFO - 2023-06-26 04:52:43 --> Database Driver Class Initialized
DEBUG - 2023-06-26 04:52:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-06-26 04:52:43 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-26 04:52:43 --> Controller Class Initialized
DEBUG - 2023-06-26 04:52:43 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/n_sikap_sp/views/list.php
DEBUG - 2023-06-26 04:52:43 --> File loaded: C:\xampp\htdocs\myraportk13\application\views\template_utama.php
INFO - 2023-06-26 04:52:43 --> Final output sent to browser
DEBUG - 2023-06-26 04:52:43 --> Total execution time: 0.0410
INFO - 2023-06-26 04:52:44 --> Config Class Initialized
INFO - 2023-06-26 04:52:44 --> Hooks Class Initialized
DEBUG - 2023-06-26 04:52:44 --> UTF-8 Support Enabled
INFO - 2023-06-26 04:52:44 --> Utf8 Class Initialized
INFO - 2023-06-26 04:52:44 --> URI Class Initialized
INFO - 2023-06-26 04:52:44 --> Router Class Initialized
INFO - 2023-06-26 04:52:44 --> Output Class Initialized
INFO - 2023-06-26 04:52:44 --> Security Class Initialized
DEBUG - 2023-06-26 04:52:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-26 04:52:44 --> Input Class Initialized
INFO - 2023-06-26 04:52:44 --> Language Class Initialized
INFO - 2023-06-26 04:52:44 --> Language Class Initialized
INFO - 2023-06-26 04:52:44 --> Config Class Initialized
INFO - 2023-06-26 04:52:44 --> Loader Class Initialized
INFO - 2023-06-26 04:52:44 --> Helper loaded: url_helper
INFO - 2023-06-26 04:52:44 --> Helper loaded: file_helper
INFO - 2023-06-26 04:52:44 --> Helper loaded: form_helper
INFO - 2023-06-26 04:52:44 --> Helper loaded: my_helper
INFO - 2023-06-26 04:52:44 --> Database Driver Class Initialized
DEBUG - 2023-06-26 04:52:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-06-26 04:52:44 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-26 04:52:44 --> Controller Class Initialized
DEBUG - 2023-06-26 04:52:44 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/n_sikap_so/views/list.php
DEBUG - 2023-06-26 04:52:44 --> File loaded: C:\xampp\htdocs\myraportk13\application\views\template_utama.php
INFO - 2023-06-26 04:52:44 --> Final output sent to browser
DEBUG - 2023-06-26 04:52:44 --> Total execution time: 0.0418
INFO - 2023-06-26 04:52:45 --> Config Class Initialized
INFO - 2023-06-26 04:52:45 --> Hooks Class Initialized
DEBUG - 2023-06-26 04:52:45 --> UTF-8 Support Enabled
INFO - 2023-06-26 04:52:45 --> Utf8 Class Initialized
INFO - 2023-06-26 04:52:45 --> URI Class Initialized
INFO - 2023-06-26 04:52:45 --> Router Class Initialized
INFO - 2023-06-26 04:52:45 --> Output Class Initialized
INFO - 2023-06-26 04:52:45 --> Security Class Initialized
DEBUG - 2023-06-26 04:52:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-26 04:52:45 --> Input Class Initialized
INFO - 2023-06-26 04:52:45 --> Language Class Initialized
INFO - 2023-06-26 04:52:45 --> Language Class Initialized
INFO - 2023-06-26 04:52:45 --> Config Class Initialized
INFO - 2023-06-26 04:52:45 --> Loader Class Initialized
INFO - 2023-06-26 04:52:45 --> Helper loaded: url_helper
INFO - 2023-06-26 04:52:45 --> Helper loaded: file_helper
INFO - 2023-06-26 04:52:45 --> Helper loaded: form_helper
INFO - 2023-06-26 04:52:45 --> Helper loaded: my_helper
INFO - 2023-06-26 04:52:45 --> Database Driver Class Initialized
DEBUG - 2023-06-26 04:52:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-06-26 04:52:45 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-26 04:52:45 --> Controller Class Initialized
DEBUG - 2023-06-26 04:52:45 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/n_sikap_sp/views/list.php
DEBUG - 2023-06-26 04:52:45 --> File loaded: C:\xampp\htdocs\myraportk13\application\views\template_utama.php
INFO - 2023-06-26 04:52:45 --> Final output sent to browser
DEBUG - 2023-06-26 04:52:45 --> Total execution time: 0.0427
INFO - 2023-06-26 04:52:46 --> Config Class Initialized
INFO - 2023-06-26 04:52:46 --> Hooks Class Initialized
DEBUG - 2023-06-26 04:52:46 --> UTF-8 Support Enabled
INFO - 2023-06-26 04:52:46 --> Utf8 Class Initialized
INFO - 2023-06-26 04:52:46 --> URI Class Initialized
INFO - 2023-06-26 04:52:46 --> Router Class Initialized
INFO - 2023-06-26 04:52:46 --> Output Class Initialized
INFO - 2023-06-26 04:52:46 --> Security Class Initialized
DEBUG - 2023-06-26 04:52:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-26 04:52:46 --> Input Class Initialized
INFO - 2023-06-26 04:52:46 --> Language Class Initialized
INFO - 2023-06-26 04:52:46 --> Language Class Initialized
INFO - 2023-06-26 04:52:46 --> Config Class Initialized
INFO - 2023-06-26 04:52:46 --> Loader Class Initialized
INFO - 2023-06-26 04:52:46 --> Helper loaded: url_helper
INFO - 2023-06-26 04:52:46 --> Helper loaded: file_helper
INFO - 2023-06-26 04:52:46 --> Helper loaded: form_helper
INFO - 2023-06-26 04:52:46 --> Helper loaded: my_helper
INFO - 2023-06-26 04:52:46 --> Database Driver Class Initialized
DEBUG - 2023-06-26 04:52:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-06-26 04:52:46 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-26 04:52:46 --> Controller Class Initialized
DEBUG - 2023-06-26 04:52:46 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/n_sikap_so/views/list.php
DEBUG - 2023-06-26 04:52:46 --> File loaded: C:\xampp\htdocs\myraportk13\application\views\template_utama.php
INFO - 2023-06-26 04:52:46 --> Final output sent to browser
DEBUG - 2023-06-26 04:52:46 --> Total execution time: 0.0437
INFO - 2023-06-26 04:53:09 --> Config Class Initialized
INFO - 2023-06-26 04:53:09 --> Hooks Class Initialized
DEBUG - 2023-06-26 04:53:09 --> UTF-8 Support Enabled
INFO - 2023-06-26 04:53:09 --> Utf8 Class Initialized
INFO - 2023-06-26 04:53:09 --> URI Class Initialized
INFO - 2023-06-26 04:53:09 --> Router Class Initialized
INFO - 2023-06-26 04:53:09 --> Output Class Initialized
INFO - 2023-06-26 04:53:09 --> Security Class Initialized
DEBUG - 2023-06-26 04:53:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-26 04:53:09 --> Input Class Initialized
INFO - 2023-06-26 04:53:09 --> Language Class Initialized
ERROR - 2023-06-26 04:53:09 --> 404 Page Not Found: ../modules/cetak_raport_pts/controllers/Cetak_raport_pts/cetak_primary
INFO - 2023-06-26 04:53:20 --> Config Class Initialized
INFO - 2023-06-26 04:53:20 --> Hooks Class Initialized
DEBUG - 2023-06-26 04:53:20 --> UTF-8 Support Enabled
INFO - 2023-06-26 04:53:20 --> Utf8 Class Initialized
INFO - 2023-06-26 04:53:20 --> URI Class Initialized
INFO - 2023-06-26 04:53:20 --> Router Class Initialized
INFO - 2023-06-26 04:53:20 --> Output Class Initialized
INFO - 2023-06-26 04:53:20 --> Security Class Initialized
DEBUG - 2023-06-26 04:53:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-26 04:53:20 --> Input Class Initialized
INFO - 2023-06-26 04:53:20 --> Language Class Initialized
INFO - 2023-06-26 04:53:20 --> Language Class Initialized
INFO - 2023-06-26 04:53:20 --> Config Class Initialized
INFO - 2023-06-26 04:53:20 --> Loader Class Initialized
INFO - 2023-06-26 04:53:20 --> Helper loaded: url_helper
INFO - 2023-06-26 04:53:20 --> Helper loaded: file_helper
INFO - 2023-06-26 04:53:20 --> Helper loaded: form_helper
INFO - 2023-06-26 04:53:20 --> Helper loaded: my_helper
INFO - 2023-06-26 04:53:20 --> Database Driver Class Initialized
DEBUG - 2023-06-26 04:53:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-06-26 04:53:20 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-26 04:53:20 --> Controller Class Initialized
DEBUG - 2023-06-26 04:53:20 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/cetak_raport_pts/views/cetak_pts_sd.php
INFO - 2023-06-26 04:53:21 --> Final output sent to browser
DEBUG - 2023-06-26 04:53:21 --> Total execution time: 0.8830
INFO - 2023-06-26 04:53:38 --> Config Class Initialized
INFO - 2023-06-26 04:53:38 --> Hooks Class Initialized
DEBUG - 2023-06-26 04:53:38 --> UTF-8 Support Enabled
INFO - 2023-06-26 04:53:38 --> Utf8 Class Initialized
INFO - 2023-06-26 04:53:38 --> URI Class Initialized
INFO - 2023-06-26 04:53:38 --> Router Class Initialized
INFO - 2023-06-26 04:53:38 --> Output Class Initialized
INFO - 2023-06-26 04:53:38 --> Security Class Initialized
DEBUG - 2023-06-26 04:53:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-26 04:53:38 --> Input Class Initialized
INFO - 2023-06-26 04:53:38 --> Language Class Initialized
INFO - 2023-06-26 04:53:38 --> Language Class Initialized
INFO - 2023-06-26 04:53:38 --> Config Class Initialized
INFO - 2023-06-26 04:53:38 --> Loader Class Initialized
INFO - 2023-06-26 04:53:38 --> Helper loaded: url_helper
INFO - 2023-06-26 04:53:38 --> Helper loaded: file_helper
INFO - 2023-06-26 04:53:38 --> Helper loaded: form_helper
INFO - 2023-06-26 04:53:38 --> Helper loaded: my_helper
INFO - 2023-06-26 04:53:38 --> Database Driver Class Initialized
DEBUG - 2023-06-26 04:53:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-06-26 04:53:38 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-26 04:53:38 --> Controller Class Initialized
DEBUG - 2023-06-26 04:53:38 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/cetak_raport_pts/views/cetak_pts_mh.php
INFO - 2023-06-26 04:53:40 --> Final output sent to browser
DEBUG - 2023-06-26 04:53:40 --> Total execution time: 1.3353
INFO - 2023-06-26 04:54:11 --> Config Class Initialized
INFO - 2023-06-26 04:54:11 --> Hooks Class Initialized
DEBUG - 2023-06-26 04:54:11 --> UTF-8 Support Enabled
INFO - 2023-06-26 04:54:11 --> Utf8 Class Initialized
INFO - 2023-06-26 04:54:11 --> URI Class Initialized
INFO - 2023-06-26 04:54:11 --> Router Class Initialized
INFO - 2023-06-26 04:54:11 --> Output Class Initialized
INFO - 2023-06-26 04:54:11 --> Security Class Initialized
DEBUG - 2023-06-26 04:54:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-26 04:54:11 --> Input Class Initialized
INFO - 2023-06-26 04:54:11 --> Language Class Initialized
INFO - 2023-06-26 04:54:11 --> Language Class Initialized
INFO - 2023-06-26 04:54:11 --> Config Class Initialized
INFO - 2023-06-26 04:54:11 --> Loader Class Initialized
INFO - 2023-06-26 04:54:11 --> Helper loaded: url_helper
INFO - 2023-06-26 04:54:11 --> Helper loaded: file_helper
INFO - 2023-06-26 04:54:11 --> Helper loaded: form_helper
INFO - 2023-06-26 04:54:11 --> Helper loaded: my_helper
INFO - 2023-06-26 04:54:11 --> Database Driver Class Initialized
DEBUG - 2023-06-26 04:54:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-06-26 04:54:11 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-26 04:54:11 --> Controller Class Initialized
DEBUG - 2023-06-26 04:54:11 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/n_sikap_so/views/list.php
DEBUG - 2023-06-26 04:54:11 --> File loaded: C:\xampp\htdocs\myraportk13\application\views\template_utama.php
INFO - 2023-06-26 04:54:11 --> Final output sent to browser
DEBUG - 2023-06-26 04:54:11 --> Total execution time: 0.0789
INFO - 2023-06-26 04:54:15 --> Config Class Initialized
INFO - 2023-06-26 04:54:15 --> Hooks Class Initialized
DEBUG - 2023-06-26 04:54:15 --> UTF-8 Support Enabled
INFO - 2023-06-26 04:54:15 --> Utf8 Class Initialized
INFO - 2023-06-26 04:54:15 --> URI Class Initialized
DEBUG - 2023-06-26 04:54:15 --> No URI present. Default controller set.
INFO - 2023-06-26 04:54:15 --> Router Class Initialized
INFO - 2023-06-26 04:54:15 --> Output Class Initialized
INFO - 2023-06-26 04:54:15 --> Security Class Initialized
DEBUG - 2023-06-26 04:54:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-26 04:54:15 --> Input Class Initialized
INFO - 2023-06-26 04:54:15 --> Language Class Initialized
INFO - 2023-06-26 04:54:15 --> Language Class Initialized
INFO - 2023-06-26 04:54:15 --> Config Class Initialized
INFO - 2023-06-26 04:54:15 --> Loader Class Initialized
INFO - 2023-06-26 04:54:15 --> Helper loaded: url_helper
INFO - 2023-06-26 04:54:15 --> Helper loaded: file_helper
INFO - 2023-06-26 04:54:15 --> Helper loaded: form_helper
INFO - 2023-06-26 04:54:15 --> Helper loaded: my_helper
INFO - 2023-06-26 04:54:15 --> Database Driver Class Initialized
DEBUG - 2023-06-26 04:54:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-06-26 04:54:15 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-26 04:54:15 --> Controller Class Initialized
DEBUG - 2023-06-26 04:54:15 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/home/views/v_home_guru.php
DEBUG - 2023-06-26 04:54:15 --> File loaded: C:\xampp\htdocs\myraportk13\application\views\template_utama.php
INFO - 2023-06-26 04:54:15 --> Final output sent to browser
DEBUG - 2023-06-26 04:54:15 --> Total execution time: 0.0492
INFO - 2023-06-26 07:59:41 --> Config Class Initialized
INFO - 2023-06-26 07:59:41 --> Hooks Class Initialized
DEBUG - 2023-06-26 07:59:41 --> UTF-8 Support Enabled
INFO - 2023-06-26 07:59:41 --> Utf8 Class Initialized
INFO - 2023-06-26 07:59:41 --> URI Class Initialized
DEBUG - 2023-06-26 07:59:41 --> No URI present. Default controller set.
INFO - 2023-06-26 07:59:41 --> Router Class Initialized
INFO - 2023-06-26 07:59:41 --> Output Class Initialized
INFO - 2023-06-26 07:59:41 --> Security Class Initialized
DEBUG - 2023-06-26 07:59:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-26 07:59:41 --> Input Class Initialized
INFO - 2023-06-26 07:59:41 --> Language Class Initialized
INFO - 2023-06-26 07:59:41 --> Language Class Initialized
INFO - 2023-06-26 07:59:41 --> Config Class Initialized
INFO - 2023-06-26 07:59:41 --> Loader Class Initialized
INFO - 2023-06-26 07:59:41 --> Helper loaded: url_helper
INFO - 2023-06-26 07:59:41 --> Helper loaded: file_helper
INFO - 2023-06-26 07:59:41 --> Helper loaded: form_helper
INFO - 2023-06-26 07:59:41 --> Helper loaded: my_helper
INFO - 2023-06-26 07:59:41 --> Database Driver Class Initialized
DEBUG - 2023-06-26 07:59:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-06-26 07:59:41 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-26 07:59:41 --> Controller Class Initialized
INFO - 2023-06-26 07:59:41 --> Config Class Initialized
INFO - 2023-06-26 07:59:41 --> Hooks Class Initialized
DEBUG - 2023-06-26 07:59:41 --> UTF-8 Support Enabled
INFO - 2023-06-26 07:59:41 --> Utf8 Class Initialized
INFO - 2023-06-26 07:59:41 --> URI Class Initialized
INFO - 2023-06-26 07:59:41 --> Router Class Initialized
INFO - 2023-06-26 07:59:41 --> Output Class Initialized
INFO - 2023-06-26 07:59:41 --> Security Class Initialized
DEBUG - 2023-06-26 07:59:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-06-26 07:59:41 --> Input Class Initialized
INFO - 2023-06-26 07:59:41 --> Language Class Initialized
INFO - 2023-06-26 07:59:41 --> Language Class Initialized
INFO - 2023-06-26 07:59:41 --> Config Class Initialized
INFO - 2023-06-26 07:59:41 --> Loader Class Initialized
INFO - 2023-06-26 07:59:41 --> Helper loaded: url_helper
INFO - 2023-06-26 07:59:41 --> Helper loaded: file_helper
INFO - 2023-06-26 07:59:41 --> Helper loaded: form_helper
INFO - 2023-06-26 07:59:41 --> Helper loaded: my_helper
INFO - 2023-06-26 07:59:41 --> Database Driver Class Initialized
DEBUG - 2023-06-26 07:59:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-06-26 07:59:41 --> Session: Class initialized using 'files' driver.
INFO - 2023-06-26 07:59:41 --> Controller Class Initialized
DEBUG - 2023-06-26 07:59:41 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/login/views/login.php
DEBUG - 2023-06-26 07:59:41 --> File loaded: C:\xampp\htdocs\myraportk13\application\views\template_utama.php
INFO - 2023-06-26 07:59:41 --> Final output sent to browser
DEBUG - 2023-06-26 07:59:41 --> Total execution time: 0.0559
