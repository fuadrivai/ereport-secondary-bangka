<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2023-10-18 15:11:22 --> Config Class Initialized
INFO - 2023-10-18 15:11:22 --> Hooks Class Initialized
DEBUG - 2023-10-18 15:11:22 --> UTF-8 Support Enabled
INFO - 2023-10-18 15:11:22 --> Utf8 Class Initialized
INFO - 2023-10-18 15:11:22 --> URI Class Initialized
DEBUG - 2023-10-18 15:11:22 --> No URI present. Default controller set.
INFO - 2023-10-18 15:11:22 --> Router Class Initialized
INFO - 2023-10-18 15:11:22 --> Output Class Initialized
INFO - 2023-10-18 15:11:22 --> Security Class Initialized
DEBUG - 2023-10-18 15:11:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-18 15:11:22 --> Input Class Initialized
INFO - 2023-10-18 15:11:22 --> Language Class Initialized
INFO - 2023-10-18 15:11:22 --> Language Class Initialized
INFO - 2023-10-18 15:11:22 --> Config Class Initialized
INFO - 2023-10-18 15:11:22 --> Loader Class Initialized
INFO - 2023-10-18 15:11:22 --> Helper loaded: url_helper
INFO - 2023-10-18 15:11:22 --> Helper loaded: file_helper
INFO - 2023-10-18 15:11:22 --> Helper loaded: form_helper
INFO - 2023-10-18 15:11:22 --> Helper loaded: my_helper
INFO - 2023-10-18 15:11:22 --> Database Driver Class Initialized
INFO - 2023-10-18 15:11:22 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-18 15:11:22 --> Controller Class Initialized
INFO - 2023-10-18 15:11:22 --> Config Class Initialized
INFO - 2023-10-18 15:11:22 --> Hooks Class Initialized
DEBUG - 2023-10-18 15:11:22 --> UTF-8 Support Enabled
INFO - 2023-10-18 15:11:22 --> Utf8 Class Initialized
INFO - 2023-10-18 15:11:22 --> URI Class Initialized
INFO - 2023-10-18 15:11:22 --> Router Class Initialized
INFO - 2023-10-18 15:11:22 --> Output Class Initialized
INFO - 2023-10-18 15:11:22 --> Security Class Initialized
DEBUG - 2023-10-18 15:11:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-18 15:11:22 --> Input Class Initialized
INFO - 2023-10-18 15:11:22 --> Language Class Initialized
INFO - 2023-10-18 15:11:22 --> Language Class Initialized
INFO - 2023-10-18 15:11:22 --> Config Class Initialized
INFO - 2023-10-18 15:11:22 --> Loader Class Initialized
INFO - 2023-10-18 15:11:22 --> Helper loaded: url_helper
INFO - 2023-10-18 15:11:22 --> Helper loaded: file_helper
INFO - 2023-10-18 15:11:22 --> Helper loaded: form_helper
INFO - 2023-10-18 15:11:22 --> Helper loaded: my_helper
INFO - 2023-10-18 15:11:22 --> Database Driver Class Initialized
INFO - 2023-10-18 15:11:22 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-18 15:11:22 --> Controller Class Initialized
DEBUG - 2023-10-18 15:11:22 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/login/views/login.php
DEBUG - 2023-10-18 15:11:22 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-10-18 15:11:22 --> Final output sent to browser
DEBUG - 2023-10-18 15:11:22 --> Total execution time: 0.0394
INFO - 2023-10-18 15:11:34 --> Config Class Initialized
INFO - 2023-10-18 15:11:34 --> Hooks Class Initialized
DEBUG - 2023-10-18 15:11:34 --> UTF-8 Support Enabled
INFO - 2023-10-18 15:11:34 --> Utf8 Class Initialized
INFO - 2023-10-18 15:11:34 --> URI Class Initialized
INFO - 2023-10-18 15:11:34 --> Router Class Initialized
INFO - 2023-10-18 15:11:34 --> Output Class Initialized
INFO - 2023-10-18 15:11:34 --> Security Class Initialized
DEBUG - 2023-10-18 15:11:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-18 15:11:34 --> Input Class Initialized
INFO - 2023-10-18 15:11:34 --> Language Class Initialized
INFO - 2023-10-18 15:11:34 --> Language Class Initialized
INFO - 2023-10-18 15:11:34 --> Config Class Initialized
INFO - 2023-10-18 15:11:34 --> Loader Class Initialized
INFO - 2023-10-18 15:11:34 --> Helper loaded: url_helper
INFO - 2023-10-18 15:11:34 --> Helper loaded: file_helper
INFO - 2023-10-18 15:11:34 --> Helper loaded: form_helper
INFO - 2023-10-18 15:11:34 --> Helper loaded: my_helper
INFO - 2023-10-18 15:11:34 --> Database Driver Class Initialized
INFO - 2023-10-18 15:11:34 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-18 15:11:34 --> Controller Class Initialized
INFO - 2023-10-18 15:11:34 --> Final output sent to browser
DEBUG - 2023-10-18 15:11:34 --> Total execution time: 0.0406
INFO - 2023-10-18 15:11:39 --> Config Class Initialized
INFO - 2023-10-18 15:11:39 --> Hooks Class Initialized
DEBUG - 2023-10-18 15:11:39 --> UTF-8 Support Enabled
INFO - 2023-10-18 15:11:39 --> Utf8 Class Initialized
INFO - 2023-10-18 15:11:39 --> URI Class Initialized
INFO - 2023-10-18 15:11:39 --> Router Class Initialized
INFO - 2023-10-18 15:11:39 --> Output Class Initialized
INFO - 2023-10-18 15:11:39 --> Security Class Initialized
DEBUG - 2023-10-18 15:11:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-18 15:11:39 --> Input Class Initialized
INFO - 2023-10-18 15:11:39 --> Language Class Initialized
INFO - 2023-10-18 15:11:39 --> Language Class Initialized
INFO - 2023-10-18 15:11:39 --> Config Class Initialized
INFO - 2023-10-18 15:11:39 --> Loader Class Initialized
INFO - 2023-10-18 15:11:39 --> Helper loaded: url_helper
INFO - 2023-10-18 15:11:39 --> Helper loaded: file_helper
INFO - 2023-10-18 15:11:39 --> Helper loaded: form_helper
INFO - 2023-10-18 15:11:39 --> Helper loaded: my_helper
INFO - 2023-10-18 15:11:39 --> Database Driver Class Initialized
INFO - 2023-10-18 15:11:39 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-18 15:11:39 --> Controller Class Initialized
INFO - 2023-10-18 15:11:39 --> Helper loaded: cookie_helper
INFO - 2023-10-18 15:11:39 --> Final output sent to browser
DEBUG - 2023-10-18 15:11:39 --> Total execution time: 0.0522
INFO - 2023-10-18 15:11:40 --> Config Class Initialized
INFO - 2023-10-18 15:11:40 --> Hooks Class Initialized
DEBUG - 2023-10-18 15:11:40 --> UTF-8 Support Enabled
INFO - 2023-10-18 15:11:40 --> Utf8 Class Initialized
INFO - 2023-10-18 15:11:40 --> URI Class Initialized
INFO - 2023-10-18 15:11:40 --> Router Class Initialized
INFO - 2023-10-18 15:11:40 --> Output Class Initialized
INFO - 2023-10-18 15:11:40 --> Security Class Initialized
DEBUG - 2023-10-18 15:11:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-18 15:11:40 --> Input Class Initialized
INFO - 2023-10-18 15:11:40 --> Language Class Initialized
INFO - 2023-10-18 15:11:40 --> Language Class Initialized
INFO - 2023-10-18 15:11:40 --> Config Class Initialized
INFO - 2023-10-18 15:11:40 --> Loader Class Initialized
INFO - 2023-10-18 15:11:40 --> Helper loaded: url_helper
INFO - 2023-10-18 15:11:40 --> Helper loaded: file_helper
INFO - 2023-10-18 15:11:40 --> Helper loaded: form_helper
INFO - 2023-10-18 15:11:40 --> Helper loaded: my_helper
INFO - 2023-10-18 15:11:40 --> Database Driver Class Initialized
INFO - 2023-10-18 15:11:40 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-18 15:11:40 --> Controller Class Initialized
DEBUG - 2023-10-18 15:11:40 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/home/views/v_home.php
DEBUG - 2023-10-18 15:11:40 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-10-18 15:11:40 --> Final output sent to browser
DEBUG - 2023-10-18 15:11:40 --> Total execution time: 0.0634
INFO - 2023-10-18 15:11:58 --> Config Class Initialized
INFO - 2023-10-18 15:11:58 --> Hooks Class Initialized
DEBUG - 2023-10-18 15:11:58 --> UTF-8 Support Enabled
INFO - 2023-10-18 15:11:58 --> Utf8 Class Initialized
INFO - 2023-10-18 15:11:58 --> URI Class Initialized
INFO - 2023-10-18 15:11:58 --> Router Class Initialized
INFO - 2023-10-18 15:11:58 --> Output Class Initialized
INFO - 2023-10-18 15:11:58 --> Security Class Initialized
DEBUG - 2023-10-18 15:11:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-18 15:11:58 --> Input Class Initialized
INFO - 2023-10-18 15:11:58 --> Language Class Initialized
INFO - 2023-10-18 15:11:58 --> Language Class Initialized
INFO - 2023-10-18 15:11:58 --> Config Class Initialized
INFO - 2023-10-18 15:11:58 --> Loader Class Initialized
INFO - 2023-10-18 15:11:58 --> Helper loaded: url_helper
INFO - 2023-10-18 15:11:58 --> Helper loaded: file_helper
INFO - 2023-10-18 15:11:58 --> Helper loaded: form_helper
INFO - 2023-10-18 15:11:58 --> Helper loaded: my_helper
INFO - 2023-10-18 15:11:58 --> Database Driver Class Initialized
INFO - 2023-10-18 15:11:58 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-18 15:11:58 --> Controller Class Initialized
DEBUG - 2023-10-18 15:11:58 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/data_siswa/views/list.php
DEBUG - 2023-10-18 15:11:58 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-10-18 15:11:58 --> Final output sent to browser
DEBUG - 2023-10-18 15:11:58 --> Total execution time: 0.0416
INFO - 2023-10-18 15:11:58 --> Config Class Initialized
INFO - 2023-10-18 15:11:58 --> Hooks Class Initialized
DEBUG - 2023-10-18 15:11:58 --> UTF-8 Support Enabled
INFO - 2023-10-18 15:11:58 --> Utf8 Class Initialized
INFO - 2023-10-18 15:11:58 --> URI Class Initialized
INFO - 2023-10-18 15:11:58 --> Router Class Initialized
INFO - 2023-10-18 15:11:58 --> Output Class Initialized
INFO - 2023-10-18 15:11:58 --> Security Class Initialized
DEBUG - 2023-10-18 15:11:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-18 15:11:58 --> Input Class Initialized
INFO - 2023-10-18 15:11:58 --> Language Class Initialized
ERROR - 2023-10-18 15:11:58 --> 404 Page Not Found: /index
INFO - 2023-10-18 15:11:58 --> Config Class Initialized
INFO - 2023-10-18 15:11:58 --> Hooks Class Initialized
DEBUG - 2023-10-18 15:11:58 --> UTF-8 Support Enabled
INFO - 2023-10-18 15:11:58 --> Utf8 Class Initialized
INFO - 2023-10-18 15:11:58 --> URI Class Initialized
INFO - 2023-10-18 15:11:58 --> Router Class Initialized
INFO - 2023-10-18 15:11:58 --> Output Class Initialized
INFO - 2023-10-18 15:11:58 --> Security Class Initialized
DEBUG - 2023-10-18 15:11:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-18 15:11:58 --> Input Class Initialized
INFO - 2023-10-18 15:11:58 --> Language Class Initialized
INFO - 2023-10-18 15:11:58 --> Language Class Initialized
INFO - 2023-10-18 15:11:58 --> Config Class Initialized
INFO - 2023-10-18 15:11:58 --> Loader Class Initialized
INFO - 2023-10-18 15:11:58 --> Helper loaded: url_helper
INFO - 2023-10-18 15:11:58 --> Helper loaded: file_helper
INFO - 2023-10-18 15:11:58 --> Helper loaded: form_helper
INFO - 2023-10-18 15:11:58 --> Helper loaded: my_helper
INFO - 2023-10-18 15:11:58 --> Database Driver Class Initialized
INFO - 2023-10-18 15:11:58 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-18 15:11:58 --> Controller Class Initialized
INFO - 2023-10-18 15:12:03 --> Config Class Initialized
INFO - 2023-10-18 15:12:03 --> Hooks Class Initialized
DEBUG - 2023-10-18 15:12:03 --> UTF-8 Support Enabled
INFO - 2023-10-18 15:12:03 --> Utf8 Class Initialized
INFO - 2023-10-18 15:12:03 --> URI Class Initialized
INFO - 2023-10-18 15:12:03 --> Router Class Initialized
INFO - 2023-10-18 15:12:03 --> Output Class Initialized
INFO - 2023-10-18 15:12:03 --> Security Class Initialized
DEBUG - 2023-10-18 15:12:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-18 15:12:03 --> Input Class Initialized
INFO - 2023-10-18 15:12:03 --> Language Class Initialized
INFO - 2023-10-18 15:12:03 --> Language Class Initialized
INFO - 2023-10-18 15:12:03 --> Config Class Initialized
INFO - 2023-10-18 15:12:03 --> Loader Class Initialized
INFO - 2023-10-18 15:12:03 --> Helper loaded: url_helper
INFO - 2023-10-18 15:12:03 --> Helper loaded: file_helper
INFO - 2023-10-18 15:12:03 --> Helper loaded: form_helper
INFO - 2023-10-18 15:12:03 --> Helper loaded: my_helper
INFO - 2023-10-18 15:12:03 --> Database Driver Class Initialized
INFO - 2023-10-18 15:12:03 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-18 15:12:03 --> Controller Class Initialized
