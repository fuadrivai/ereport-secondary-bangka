<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2024-07-29 14:08:15 --> Config Class Initialized
INFO - 2024-07-29 14:08:15 --> Hooks Class Initialized
DEBUG - 2024-07-29 14:08:15 --> UTF-8 Support Enabled
INFO - 2024-07-29 14:08:15 --> Utf8 Class Initialized
INFO - 2024-07-29 14:08:15 --> URI Class Initialized
INFO - 2024-07-29 14:08:15 --> Router Class Initialized
INFO - 2024-07-29 14:08:15 --> Output Class Initialized
INFO - 2024-07-29 14:08:15 --> Security Class Initialized
DEBUG - 2024-07-29 14:08:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-07-29 14:08:15 --> Input Class Initialized
INFO - 2024-07-29 14:08:15 --> Language Class Initialized
INFO - 2024-07-29 14:08:15 --> Language Class Initialized
INFO - 2024-07-29 14:08:15 --> Config Class Initialized
INFO - 2024-07-29 14:08:15 --> Loader Class Initialized
INFO - 2024-07-29 14:08:15 --> Helper loaded: url_helper
INFO - 2024-07-29 14:08:15 --> Helper loaded: file_helper
INFO - 2024-07-29 14:08:15 --> Helper loaded: form_helper
INFO - 2024-07-29 14:08:15 --> Helper loaded: my_helper
INFO - 2024-07-29 14:08:15 --> Database Driver Class Initialized
INFO - 2024-07-29 14:08:15 --> Session: Class initialized using 'files' driver.
INFO - 2024-07-29 14:08:15 --> Controller Class Initialized
INFO - 2024-07-29 14:08:15 --> Helper loaded: cookie_helper
INFO - 2024-07-29 14:08:15 --> Final output sent to browser
DEBUG - 2024-07-29 14:08:15 --> Total execution time: 0.0897
INFO - 2024-07-29 14:08:15 --> Config Class Initialized
INFO - 2024-07-29 14:08:15 --> Hooks Class Initialized
DEBUG - 2024-07-29 14:08:15 --> UTF-8 Support Enabled
INFO - 2024-07-29 14:08:15 --> Utf8 Class Initialized
INFO - 2024-07-29 14:08:15 --> URI Class Initialized
INFO - 2024-07-29 14:08:15 --> Router Class Initialized
INFO - 2024-07-29 14:08:15 --> Output Class Initialized
INFO - 2024-07-29 14:08:15 --> Security Class Initialized
DEBUG - 2024-07-29 14:08:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-07-29 14:08:15 --> Input Class Initialized
INFO - 2024-07-29 14:08:15 --> Language Class Initialized
INFO - 2024-07-29 14:08:15 --> Language Class Initialized
INFO - 2024-07-29 14:08:15 --> Config Class Initialized
INFO - 2024-07-29 14:08:15 --> Loader Class Initialized
INFO - 2024-07-29 14:08:15 --> Helper loaded: url_helper
INFO - 2024-07-29 14:08:15 --> Helper loaded: file_helper
INFO - 2024-07-29 14:08:15 --> Helper loaded: form_helper
INFO - 2024-07-29 14:08:15 --> Helper loaded: my_helper
INFO - 2024-07-29 14:08:15 --> Database Driver Class Initialized
INFO - 2024-07-29 14:08:15 --> Session: Class initialized using 'files' driver.
INFO - 2024-07-29 14:08:15 --> Controller Class Initialized
INFO - 2024-07-29 14:08:15 --> Helper loaded: cookie_helper
INFO - 2024-07-29 14:08:15 --> Config Class Initialized
INFO - 2024-07-29 14:08:15 --> Hooks Class Initialized
DEBUG - 2024-07-29 14:08:15 --> UTF-8 Support Enabled
INFO - 2024-07-29 14:08:15 --> Utf8 Class Initialized
INFO - 2024-07-29 14:08:15 --> URI Class Initialized
INFO - 2024-07-29 14:08:15 --> Router Class Initialized
INFO - 2024-07-29 14:08:15 --> Output Class Initialized
INFO - 2024-07-29 14:08:15 --> Security Class Initialized
DEBUG - 2024-07-29 14:08:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-07-29 14:08:15 --> Input Class Initialized
INFO - 2024-07-29 14:08:15 --> Language Class Initialized
INFO - 2024-07-29 14:08:15 --> Language Class Initialized
INFO - 2024-07-29 14:08:15 --> Config Class Initialized
INFO - 2024-07-29 14:08:15 --> Loader Class Initialized
INFO - 2024-07-29 14:08:15 --> Helper loaded: url_helper
INFO - 2024-07-29 14:08:15 --> Helper loaded: file_helper
INFO - 2024-07-29 14:08:15 --> Helper loaded: form_helper
INFO - 2024-07-29 14:08:15 --> Helper loaded: my_helper
INFO - 2024-07-29 14:08:15 --> Database Driver Class Initialized
INFO - 2024-07-29 14:08:15 --> Session: Class initialized using 'files' driver.
INFO - 2024-07-29 14:08:15 --> Controller Class Initialized
DEBUG - 2024-07-29 14:08:15 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/lihat_raport/views/list.php
DEBUG - 2024-07-29 14:08:15 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-07-29 14:08:15 --> Final output sent to browser
DEBUG - 2024-07-29 14:08:15 --> Total execution time: 0.0472
INFO - 2024-07-29 21:06:59 --> Config Class Initialized
INFO - 2024-07-29 21:06:59 --> Hooks Class Initialized
DEBUG - 2024-07-29 21:06:59 --> UTF-8 Support Enabled
INFO - 2024-07-29 21:06:59 --> Utf8 Class Initialized
INFO - 2024-07-29 21:06:59 --> URI Class Initialized
INFO - 2024-07-29 21:06:59 --> Router Class Initialized
INFO - 2024-07-29 21:06:59 --> Output Class Initialized
INFO - 2024-07-29 21:06:59 --> Security Class Initialized
DEBUG - 2024-07-29 21:06:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-07-29 21:06:59 --> Input Class Initialized
INFO - 2024-07-29 21:06:59 --> Language Class Initialized
INFO - 2024-07-29 21:06:59 --> Language Class Initialized
INFO - 2024-07-29 21:06:59 --> Config Class Initialized
INFO - 2024-07-29 21:06:59 --> Loader Class Initialized
INFO - 2024-07-29 21:06:59 --> Helper loaded: url_helper
INFO - 2024-07-29 21:06:59 --> Helper loaded: file_helper
INFO - 2024-07-29 21:06:59 --> Helper loaded: form_helper
INFO - 2024-07-29 21:06:59 --> Helper loaded: my_helper
INFO - 2024-07-29 21:06:59 --> Database Driver Class Initialized
INFO - 2024-07-29 21:06:59 --> Session: Class initialized using 'files' driver.
INFO - 2024-07-29 21:06:59 --> Controller Class Initialized
INFO - 2024-07-29 21:06:59 --> Helper loaded: cookie_helper
INFO - 2024-07-29 21:06:59 --> Final output sent to browser
DEBUG - 2024-07-29 21:06:59 --> Total execution time: 0.0929
INFO - 2024-07-29 21:06:59 --> Config Class Initialized
INFO - 2024-07-29 21:06:59 --> Hooks Class Initialized
DEBUG - 2024-07-29 21:06:59 --> UTF-8 Support Enabled
INFO - 2024-07-29 21:06:59 --> Utf8 Class Initialized
INFO - 2024-07-29 21:06:59 --> URI Class Initialized
INFO - 2024-07-29 21:06:59 --> Router Class Initialized
INFO - 2024-07-29 21:06:59 --> Output Class Initialized
INFO - 2024-07-29 21:06:59 --> Security Class Initialized
DEBUG - 2024-07-29 21:06:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-07-29 21:06:59 --> Input Class Initialized
INFO - 2024-07-29 21:06:59 --> Language Class Initialized
INFO - 2024-07-29 21:06:59 --> Language Class Initialized
INFO - 2024-07-29 21:06:59 --> Config Class Initialized
INFO - 2024-07-29 21:06:59 --> Loader Class Initialized
INFO - 2024-07-29 21:06:59 --> Helper loaded: url_helper
INFO - 2024-07-29 21:06:59 --> Helper loaded: file_helper
INFO - 2024-07-29 21:06:59 --> Helper loaded: form_helper
INFO - 2024-07-29 21:06:59 --> Helper loaded: my_helper
INFO - 2024-07-29 21:06:59 --> Database Driver Class Initialized
INFO - 2024-07-29 21:06:59 --> Session: Class initialized using 'files' driver.
INFO - 2024-07-29 21:06:59 --> Controller Class Initialized
INFO - 2024-07-29 21:06:59 --> Helper loaded: cookie_helper
INFO - 2024-07-29 21:06:59 --> Config Class Initialized
INFO - 2024-07-29 21:06:59 --> Hooks Class Initialized
DEBUG - 2024-07-29 21:06:59 --> UTF-8 Support Enabled
INFO - 2024-07-29 21:06:59 --> Utf8 Class Initialized
INFO - 2024-07-29 21:06:59 --> URI Class Initialized
INFO - 2024-07-29 21:06:59 --> Router Class Initialized
INFO - 2024-07-29 21:06:59 --> Output Class Initialized
INFO - 2024-07-29 21:06:59 --> Security Class Initialized
DEBUG - 2024-07-29 21:06:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-07-29 21:06:59 --> Input Class Initialized
INFO - 2024-07-29 21:06:59 --> Language Class Initialized
INFO - 2024-07-29 21:06:59 --> Language Class Initialized
INFO - 2024-07-29 21:06:59 --> Config Class Initialized
INFO - 2024-07-29 21:06:59 --> Loader Class Initialized
INFO - 2024-07-29 21:06:59 --> Helper loaded: url_helper
INFO - 2024-07-29 21:06:59 --> Helper loaded: file_helper
INFO - 2024-07-29 21:06:59 --> Helper loaded: form_helper
INFO - 2024-07-29 21:06:59 --> Helper loaded: my_helper
INFO - 2024-07-29 21:06:59 --> Database Driver Class Initialized
INFO - 2024-07-29 21:06:59 --> Session: Class initialized using 'files' driver.
INFO - 2024-07-29 21:06:59 --> Controller Class Initialized
DEBUG - 2024-07-29 21:06:59 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/lihat_raport/views/list.php
DEBUG - 2024-07-29 21:06:59 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-07-29 21:06:59 --> Final output sent to browser
DEBUG - 2024-07-29 21:06:59 --> Total execution time: 0.0339
